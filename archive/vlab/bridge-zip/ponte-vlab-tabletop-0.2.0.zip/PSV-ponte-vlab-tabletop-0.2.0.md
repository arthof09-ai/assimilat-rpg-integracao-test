# PSV — Ponte VLAB ↔ Tabletop 0.2.0

## Identificação e resultado

Branch local: `test/tabletop-vlab-bridge-poc`.
Commit de fonte: `c1054f9c6a4db1f7a0068ae5c8c773944ec69fbf`.
Incremento: recibos persistentes consultáveis no backend existente, tradutor TEST
sem estado e solicitação tática bloqueada na fronteira do VLAB. Sem outro servidor,
sem outbox nova, sem alteração ao TEST36, sem push, PR, merge ou deploy.

## ANTES → DEPOIS

Antes, deduplicação não oferecia ao cliente uma consulta do resultado após perder
a confirmação. Agora `schema_version:2` estende somente `submit/receipt_query`, no
mesmo `POST /bridge`, com resultado imutável por sala + identidade do servidor + ID.
Reenvio idêntico recupera o recibo original; corpo diferente com mesmo ID falha.
Estado/evento/ID/recibo têm COMMIT atômico; rejeições válidas também são duráveis.
Os seis envelopes v1 permanecem operacionais, sem conversão de CREATE em JOIN.

## Proveniência e preservação

`bad50082621f5ddebb157088949dccac8e6aa8ca` é o commit de fonte anterior.
`7fd03324209ee44d2314ac86609b17293542bef1` é seu filho direto e adiciona
somente ZIP + SHA, sem modificar fontes. Evidência: `evidence/git-provenance.json`
e `provenance/source-history.txt`. A divergência foi explicada por Git real.
41/41 arquivos anteriores preservados byte a byte. ZIP anterior intacto:
367.597 bytes, 44 entradas, SHA `80aa408adabcd3c8e9fb2267d7efeb5ee4b9a3ef5e22c618a9d814bb98b751a3`. Ele não é duplicado no novo pacote.

## Alterações de código e finalidade

- `authority.py`: transação de recibos SQLite, consulta por dono, idempotência,
  rejeições duráveis e fronteira tática bloqueada; mesma autoridade de sala.
- `receipt_contract.py`: validação JSON/DTO/digest separada do processo local.
- `client.ts` e `type_contract.ts`: API v2 tipada e verificação de respostas,
  UNKNOWN sem decisão inventada, compatibilidade v1 preservada.
- `room_adapter.ts`: JOIN/RESYNC/INTENT/ACK/query experimentais, sem journal.
- `translation.json`: 17 traduções/limitações/rejeições verificadas em testes.
- `test_receipts.py` e `test_room_adapter.mjs`: regressões de persistência,
  falhas, concorrência, projeção e interoperabilidade local.
- `integration_example.mjs`: handoff executável para o Desenvolvedor.
- `run_checks.py`, configuração e documentação: execução e recibo reproduzíveis.

Diff exato (17 arquivos):

```text
M	experiments/tabletop_vlab_bridge/COMPATIBILITY.md
A	experiments/tabletop_vlab_bridge/INTEGRATION.md
M	experiments/tabletop_vlab_bridge/README.md
M	experiments/tabletop_vlab_bridge/authority.py
M	experiments/tabletop_vlab_bridge/client.ts
A	experiments/tabletop_vlab_bridge/integration_example.mjs
M	experiments/tabletop_vlab_bridge/package-lock.json
M	experiments/tabletop_vlab_bridge/package.json
A	experiments/tabletop_vlab_bridge/receipt_contract.py
A	experiments/tabletop_vlab_bridge/room_adapter.ts
M	experiments/tabletop_vlab_bridge/run_checks.py
M	experiments/tabletop_vlab_bridge/test_authority.py
A	experiments/tabletop_vlab_bridge/test_receipts.py
A	experiments/tabletop_vlab_bridge/test_room_adapter.mjs
A	experiments/tabletop_vlab_bridge/translation.json
M	experiments/tabletop_vlab_bridge/tsconfig.json
M	experiments/tabletop_vlab_bridge/type_contract.ts
```

## Testes efetivamente executados

| Verificação | Resultado e escopo |
|---|---|
| Requisitos iniciais contra baseline | 3/3 falharam como esperado: 2 failures, 1 error; `p0-before.log` |
| Primeira correção P0 | 3/3 PASS; `p0-after.log` |
| Suíte final da ponte | 61/61 Python PASS, UNIT + HTTP local sintético |
| Suítes Node dentro de dois testes Python | 15/15 + 23/23 = 38/38 PASS; não somar como 38 testes Python extras |
| TypeScript 5.9.3 | strict + erasableSyntaxOnly PASS, exit 0 |
| Regressão original do repositório | 55/55 PASS; fontes originais preservadas |
| Compatibilidade Node 22.16.0 | 2/2 wrappers Python, com 38/38 Node HTTP PASS e flag strip-types |
| Demonstrações | projeções de três clientes sintéticos + recuperação/ação bloqueada PASS |
| Matriz máquina-legível | 17/17 linhas exercitadas, positivas e negativas |
| Patch completo e incremental | git apply --check + aplicação + igualdade 24/24 fontes PASS |
| Cloudflare/VLAB/Android físico | 0 execuções; HOLD |

Logs finais: `evidence/final/contract.log`, `receipt.json`, `typecheck.log`,
`integration-flow.json`; demais logs têm nomes correspondentes. Log vazio de tsc
é acompanhado de exit 0 no recibo. Node22 foi verificado em release oficial com
SHA; não foi repetida toda a suíte 61 nessa versão. Nenhum runtime/dependência
binário, SQLite de campanha ou node_modules integra este ZIP.

Comandos utilizados (resultados atuais em `evidence/`; reprodução em pasta nova):

```sh
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund
python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/integration-results
# Somente no repositório original, com seus tests/ existentes:
python3 -m unittest discover -s tests -v
# Para Node 22.16 no PATH (os dois wrappers executam 15 + 23 casos Node):
NODE_OPTIONS=--experimental-strip-types PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_authority.HttpAndTypeScriptTests.test_typescript_client_over_real_http test_receipts.ReceiptTests.test_typed_room_adapter_and_machine_matrix_over_real_http -v
```

Python usado: 3.12.14. Node principal: 24.19.0. Python requer 3.11+.
Node >=24.12 dispensa flag; Node22.16 exige `--experimental-strip-types` para .ts.

## Resultado funcional observável

`evidence/final/integration-flow.json` contém recibos efetivamente gerados.
A intenção `handoff-lost` teve recibo
`receipt-2a937b1eeed647fc98d59e7830f91f65`, ACCEPTED/APPLIED, revisão 1/event-1.
Após confirmação descartada e novo adaptador, query e reenvio devolveram esse
mesmo recibo, sem segundo efeito. O teste Python independente encerra o socket
do servidor **depois de COMMIT**, termina o processo, reabre o arquivo SQLite em
novo processo e recupera por HTTP o resultado original. É falha injetada local
reproduzível, não queda de infraestrutura remota.

`handoff-attack` retornou
`receipt-284da6c5414b48208b829c00be19925a`, REJECTED/MECHANICS_UNAVAILABLE,
sem mudança da revisão, evento ou recursos. Query recuperou a rejeição idêntica.
O primeiro ponto que exige VLAB é adjudicar a ação autorizada após validação de
esquema/identidade/revisão. Nenhuma fórmula de dano, PA, Vida ou Alma foi criada.

## Contrato e compatibilidade TEST36/PESQ015

Contrato nativo v2 e exemplos integrais: `experiments/tabletop_vlab_bridge/INTEGRATION.md`.
Mapeamentos máquina-legíveis: `translation.json` no mesmo diretório.
`commandId → client_action_id`, `baseRevision → expected_revision`,
`roomId → room_id`, `actorId → actor_id`. JOIN/RESYNC usam view autorizada,
INTENT usa submit e RECEIPT_QUERY consulta persistência autoritativa.
ACCEPTED/REJECTED exigem recibo terminal. Ausência, interrupção ou erro sem recibo
continuam UNKNOWN; não criam ID novo automaticamente nem presumem rejeição.
CREATE é administração separada; RESYNC não promete histórico integral.

Adaptador usa namespace explícito `assim.tabletop.room.bridge.test.v2`.
É experimental reversível, não contrato externo canonizado. Relatórios canônicos
de RUN013/PESQ015 foram consultados no Notion existente; seus binários Library
não estavam acessíveis por URL Drive nas ferramentas desta rodada. Portanto não
se afirma comparação byte a byte, execução das suítes 411/180 ou plug-in direto.
Falta confrontar o wire real, callbacks existentes e projeção `n/walls/units/markers`.
MOVE_VISUAL_TEST, seq inferido, aliases administrativos e namespaces não verificados
são recusados. Nenhuma outbox nem interface oficial do Desenvolvedor foi alterada.

## Segurança e persistência

Identidade deriva exclusivamente de tokens FIXTURE no servidor; campos role,
profile e participantId não elevam acesso. É autorização TEST, não login real.
ACL de ator é validada antes de aplicar efeito. Todos os fixtures são membros
de todas as salas TEST: membership/convites/revogação de produção estão HOLD.
Consulta de outro dono e ID inexistente retornam a mesma ausência, sem vazamento.
Erros sanitizados não incluem trace ou payload. Projeções são reconstruídas antes
de transmitir, e recibos não carregam snapshot privado. Objetos/listas/tipos extras,
registros corrompidos, digest adulterado, body/resposta fora do limite e identidade
reutilizada têm testes negativos. Digest não é MAC contra administrador de banco.

Testadas duas intenções na mesma revisão, mesmo ID concorrente, falha INSERT/antes
COMMIT, rollback total e perda após COMMIT, queries repetidas e reinício. Limites:
512 recibos/sala sem eviction, corpo 4KiB, resposta 64KiB; capacidade esgotada falha
fechada. Rejeição terminal consome ID. Intent v1 sem recibo nunca recebe backfill
fabricado. Restore não apaga decisões já confirmadas nem libera IDs.
Revisão lexical e manual: somente fontes e dados sintéticos; nenhum código privado
VLAB, dado de Party/campanha, credencial real ou informação Mestre-only real.
Os canários FAKE_MASTER_ONLY/FAKE_P1_ONLY são dados de teste deliberados.

## Arquitetura A e viabilidade de implantação

Parecer: manter Python/VLAB como executor mecânico exclusivo e uma autoridade de
sala para identidade, autorização, revisão, ordem, persistência, recibos e projeção.
O contrato portátil foi separado, mas CPython local não comprova Python Workers.
`http.server`, sockets/threads e SQLite por arquivo precisam adaptação em Workers;
filesystem efêmero não é persistência. Durable Objects exigem APIs/transações
próprias, WSS e ciclo de sessão. Nenhum wrangler/miniflare/workerd foi encontrado.
R$0 adicional em serviços nesta rodada; plano/hospedagem/permanência gratuitos não
foram homologados. Nenhum deploy, conta ou recurso remoto foi criado.
WSS/DO é alternativa futura a comparar em runtime autorizado; não há segundo
backend definitivo. Uma futura chamada mecânica remota precisa idempotência e
reconciliação próprias, pois não está atomicamente dentro de SQLite local.

## Artefatos, integridade e aplicação

- 24 arquivos de fonte/doc/configuração, sem pacote anterior embutido.
- `patches/incremental-from-7fd0332.patch`: alterações desta rodada.
- `patches/complete-from-046f6cc.patch`: ponte inteira sobre a base original.
- `MANIFEST.json`: bytes + SHA-256 dos payloads; `SHA256SUMS`: payloads + manifesto.
- `VERSION.json`: gates máquina-legíveis. Evidências e proveniência incluídas.
- `.zip.sha256` externo: hash do ZIP fechado, evitando hash circular.

No repositório com a baseline correspondente, use apenas um patch:

```sh
git apply --check patches/incremental-from-7fd0332.patch
git apply patches/incremental-from-7fd0332.patch
# Para a base 046f6cc sem ponte, use o patch completo em vez do incremental.
sha256sum -c SHA256SUMS
```

Os dois patches foram realmente aplicados em árvores temporárias separadas e
produziram exatamente os 24 arquivos atuais, sem tocar os 41 originais.
O novo ZIP será um arquivo novo no Drive privado existente, sem substituir o
anterior. Os links/IDs e a verificação de download serão entregues no recibo da
interface após envio e reabertura, não inventados neste documento fechado.

No Android: abrir a pasta privada
https://drive.google.com/drive/folders/1RPl9yOjGrhO73vfRU0jmmGHZkvkKHG1B
com a conta autorizada, localizar `ponte-vlab-tabletop-0.2.0.zip`, tocar ⋮ e
Fazer download. Baixar também `.zip.sha256` e este PSV. Acesso Android físico não
foi testado; esses são passos do aplicativo, não homologação Android.

Prompt ao Coordenador: “Na pasta privada RPG ASSIMILAÇÃO, abra
ponte-vlab-tabletop-0.2.0.zip e PSV-ponte-vlab-tabletop-0.2.0.md. Confira o SHA
externo, MANIFEST.json e SHA256SUMS. Audite receipt_query/submit v2, matriz
translation.json, integração HTTP e rejeição MECHANICS_UNAVAILABLE. Preserve
UNKNOWN sem recibo e não integre o wire externo sem confrontar os arquivos
originais TEST36/PESQ015. Commit de fonte: c1054f9c6a4db1f7a0068ae5c8c773944ec69fbf.”

## Limites, continuidade e NAC-PASS-02

`FAKE_RULES_FOR_TRANSPORT_TEST` permanece explícito.
`VLAB_SOURCE_NOT_AVAILABLE`, `PYTHON_TS_EQUIVALENCE_NOT_TESTED`,
`ANDROID_REAL_NOT_TESTED`, `VLAB_PRODUCTION_HOLD` preservados.
P0: PASS UNIT/LOCAL_HTTP; P1: PASS tradução experimental, HOLD wire externo;
P2: PASS fronteira sintética, HOLD auth real; P3: PASS transporte bloqueado;
P4: PASS handoff local; P5: HOLD infraestrutura real, 0 testes Cloudflare.
Não há combate VLAB, multiplayer remoto homologado ou prova de três Android.

LAST-VERIFIED-UNIT: recibo persistente pós-COMMIT/reboot, matriz 17/17,
projeção e solicitação tática bloqueada com recuperação, todos demonstrados.
FIRST-PENDING: confrontar bytes/contrato TEST36/PESQ015 e projeção autoritativa
de mapa, sem inventar equivalência de namespace/topologia.
NEXT: conectar a fronteira existente ao recibo real; depois gates de autenticação,
WSS/persistência remota/Android e ABI VLAB mediante evidência e autorização.
NO-REPEAT: POC anterior, engine, outbox/journal TEST36, Arena visual e pesquisas.
NAC-PASS-02: aprovação proporcional somente do incremento TEST local; gates
externos explícitos permanecem HOLD. Nenhuma publicação ou merge autorizado.
