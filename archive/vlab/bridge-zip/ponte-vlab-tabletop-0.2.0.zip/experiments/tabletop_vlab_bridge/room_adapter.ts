/** TEST bridge only. No outbox, game rules, topology synthesis or second server.
 * Exact TEST36 binary wire is pending; this namespace is deliberately distinct.
 */
import { BridgeClient, validateJsonTree } from "./client.ts";
import type { ActorId, Projection, Receipt, SubmitV2, TacticalAction } from "./client.ts";

export const ROOM_SCHEMA = "assim.tabletop.room.bridge.test.v2" as const;
type RoomBase<T extends string> = { schema: typeof ROOM_SCHEMA; type: T; roomId: string };
export type RoomIntent = RoomBase<"INTENT"> & { commandId: string; baseRevision: number;
  actorId: ActorId; action: { kind: "FAKE_SET_LABEL"; label: string } | TacticalAction };
export type RoomQuery = RoomBase<"RECEIPT_QUERY"> & { commandId: string };
export type RoomFrame = RoomBase<"JOIN"> | RoomBase<"RESYNC"> | RoomIntent | RoomQuery;
export type RoomReply =
  { schema: typeof ROOM_SCHEMA; type: "WELCOME"; roomId: string; revision: number; view: Projection } |
  { schema: typeof ROOM_SCHEMA; type: "ACK"; roomId: string; commandId: string;
    status: "ACCEPTED" | "REJECTED" | "UNKNOWN"; code: string; receipt: Receipt | null };

export class ProtocolError extends Error {
  readonly outcome = "NOT_SENT";
  readonly code: "INVALID_FRAME" | "UNSUPPORTED_ACTION" | "FORBIDDEN" | "ROOM_UNAVAILABLE";
  constructor(code: "INVALID_FRAME" | "UNSUPPORTED_ACTION" | "FORBIDDEN" | "ROOM_UNAVAILABLE") {
    super(code); this.code = code;
  }
}

function requireFrame(ok: unknown): asserts ok { if (!ok) throw new ProtocolError("INVALID_FRAME"); }
function object(value: unknown): asserts value is Record<string, unknown> {
  requireFrame(value !== null && typeof value === "object" && !Array.isArray(value));
}
function fields(value: Record<string, unknown>, allowed: string[]) {
  requireFrame(Object.keys(value).sort().join(",") === [...allowed].sort().join(","));
}
function identifier(value: unknown) { requireFrame(typeof value === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(value)); }
function unsigned(value: unknown, limit: number) { requireFrame(Number.isInteger(value) && Number(value) >= 0 && Number(value) <= limit); }

export function validateFrame(value: unknown): asserts value is RoomFrame {
  try { validateJsonTree(value); } catch { throw new ProtocolError("INVALID_FRAME"); }
  object(value); requireFrame(value.schema === ROOM_SCHEMA); identifier(value.roomId);
  const base = ["schema", "type", "roomId"];
  if (value.type === "JOIN" || value.type === "RESYNC") { fields(value, base); return; }
  if (value.type === "RECEIPT_QUERY") { fields(value, [...base, "commandId"]); identifier(value.commandId); return; }
  requireFrame(value.type === "INTENT");
  fields(value, [...base, "commandId", "baseRevision", "actorId", "action"]);
  identifier(value.commandId); unsigned(value.baseRevision, 2147483647);
  requireFrame(typeof value.actorId === "string" && ["actor-m", "actor-1", "actor-2"].includes(value.actorId));
  object(value.action);
  if (value.action.kind === "FAKE_SET_LABEL") {
    fields(value.action, ["kind", "label"]);
    requireFrame(typeof value.action.label === "string" && [...value.action.label].length >= 1 &&
      [...value.action.label].length <= 80 && !/[\x00-\x1f]/.test(value.action.label));
  } else if (value.action.kind === "ATTACK_REQUEST") {
    fields(value.action, ["kind", "target", "turn_id", "context"]);
    identifier(value.action.turn_id);
    object(value.action.context); fields(value.action.context, ["scene_id", "ability_id"]);
    identifier(value.action.context.scene_id); identifier(value.action.context.ability_id);
    object(value.action.target);
    if (value.action.target.kind === "UNIT") {
      fields(value.action.target, ["kind", "actor_id"]); identifier(value.action.target.actor_id);
    } else {
      requireFrame(value.action.target.kind === "AREA"); fields(value.action.target, ["kind", "x", "y", "radius"]);
      unsigned(value.action.target.x, 19); unsigned(value.action.target.y, 19); unsigned(value.action.target.radius, 4);
    }
  } else throw new ProtocolError("UNSUPPORTED_ACTION");
}

export class RoomV2Adapter {
  private readonly bridge: BridgeClient;
  constructor(bridge: BridgeClient) { this.bridge = bridge; }

  async exchange(input: RoomFrame): Promise<RoomReply> {
    // Validate and capture before awaiting; a caller cannot mutate queued intent.
    validateFrame(input);
    const frame = JSON.parse(JSON.stringify(input)) as RoomFrame;
    if (frame.type === "JOIN" || frame.type === "RESYNC") {
      const reply = await this.bridge.request({ schema_version: 1, op: "view", room_id: frame.roomId });
      if (!reply.ok) throw new ProtocolError(reply.error.code === "FORBIDDEN" ? "FORBIDDEN" : "ROOM_UNAVAILABLE");
      return { schema: ROOM_SCHEMA, type: "WELCOME", roomId: frame.roomId, revision: reply.revision, view: reply.view };
    }
    const common = { schema_version: 2 as const, room_id: frame.roomId, client_action_id: frame.commandId };
    const request = frame.type === "RECEIPT_QUERY" ? { ...common, op: "receipt_query" as const } : {
      ...common, op: "submit" as const, actor_id: frame.actorId, expected_revision: frame.baseRevision,
      ...(frame.action.kind === "FAKE_SET_LABEL" ? { effect: frame.action } : { action: frame.action }),
    } satisfies SubmitV2;
    const reply = await this.bridge.requestV2(request);
    // Neither protocol errors nor NOT_FOUND are durable REJECTED receipts.
    if (!reply.ok) return { schema: ROOM_SCHEMA, type: "ACK", roomId: frame.roomId,
      commandId: frame.commandId, status: "UNKNOWN", code: reply.error.code, receipt: null };
    if (reply.op === "receipt_query" && reply.lookup === "NOT_FOUND") return {
      schema: ROOM_SCHEMA, type: "ACK", roomId: frame.roomId, commandId: frame.commandId,
      status: "UNKNOWN", code: "NOT_FOUND", receipt: null };
    const receipt = reply.receipt;
    if (!receipt) throw new ProtocolError("INVALID_FRAME");
    return { schema: ROOM_SCHEMA, type: "ACK", roomId: frame.roomId,
      commandId: frame.commandId, status: receipt.status, code: receipt.code, receipt };
  }
}
