"""Reproducible local receipt; no CI/deploy or remote writes. Stdlib only."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path

from authority import Authority, make_server

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path)
    parser.add_argument("--tsc", help="Optional existing compiler path, otherwise local node_modules or PATH")
    args = parser.parse_args()
    # Intermediate evidence stays in work/, outside source. Caller may export it.
    results = args.results or Path.cwd() / "work" / "bridge-poc-results"
    results.mkdir(parents=True, exist_ok=True)
    compiler = args.tsc or str(HERE / "node_modules" / ".bin" / "tsc")
    if not Path(compiler).exists():
        compiler = shutil.which("tsc")
    receipt = {"timestamp_utc": datetime.now(timezone.utc).isoformat(),
               "mode": "FAKE_RULES_FOR_TRANSPORT_TEST", "python": sys.version.split()[0],
               "node": subprocess.check_output(["node", "--version"], text=True).strip(),
               "GH": "GH-NOT-RUN", "source": "VLAB_SOURCE_NOT_AVAILABLE",
               "mechanics": "PYTHON_TS_EQUIVALENCE_NOT_TESTED", "android": "ANDROID_REAL_NOT_TESTED",
               "production": "VLAB_PRODUCTION_HOLD", "seed": "fixed synthetic labels; no random rules"}
    checks = []
    commands = [("contract", [sys.executable, "-m", "unittest", "discover", "-s", str(HERE), "-p", "test_*.py", "-v"])]
    if compiler:
        commands.append(("typecheck", [compiler, "-p", str(HERE / "tsconfig.json")]))
    else:
        checks.append({"name": "typecheck", "status": "NOT_RUN", "reason": "TSC_NOT_AVAILABLE"})
    for name, command in commands:
        proc = subprocess.run(command, cwd=HERE, text=True, capture_output=True, timeout=120)
        log = proc.stdout + proc.stderr
        (results / f"{name}.log").write_text(log)
        record = {"name": name, "command": command, "exit_code": proc.returncode,
                  "status": "PASS" if proc.returncode == 0 else "FAIL"}
        if name == "contract":
            found = re.search(r"Ran (\d+) tests", log)
            record["python_tests"] = int(found[1]) if found else None
            node_counts = [int(x) for x in re.findall(r"(?:ℹ|#) tests (\d+)", log)]
            record["nested_node_suites"] = node_counts
            record["nested_node_tests"] = sum(node_counts)
            record["counting_note"] = "Python count includes orchestration tests running the Node suites; do not sum as independent cases."
        checks.append(record)
    if all(x["status"] == "PASS" for x in checks):
        with tempfile.TemporaryDirectory() as temp:
            server = make_server(Authority(Path(temp) / "demo.sqlite"))
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
            try:
                demo = subprocess.run(["node", str(HERE / "demo.mjs")], text=True, capture_output=True,
                    env=os.environ | {"BRIDGE_URL": f"http://127.0.0.1:{server.server_port}/bridge"}, timeout=30)
                if demo.returncode == 0:
                    payload = json.loads(demo.stdout)
                    for role in ["player1", "player2"]:
                        raw = json.dumps(payload[role])
                        for secret in ["FAKE_MASTER_ONLY", "FAKE_MASTER_ACTOR_NOTE", "master_note", "private_notes",
                                       "FAKE_P2_ONLY" if role == "player1" else "FAKE_P1_ONLY"]:
                            assert secret not in raw
                    (results / "projections.json").write_text(json.dumps(payload, indent=2) + "\n")
                checks.append({"name": "three_client_demo", "status": "PASS" if demo.returncode == 0 else "FAIL",
                               "exit_code": demo.returncode})
                (results / "demo.log").write_text(demo.stderr)
                handoff = subprocess.run(["node", str(HERE / "integration_example.mjs")], text=True, capture_output=True,
                    env=os.environ | {"BRIDGE_URL": f"http://127.0.0.1:{server.server_port}/bridge"}, timeout=30)
                if handoff.returncode == 0:
                    payload = json.loads(handoff.stdout)
                    assert payload["recovered"] == payload["identicalResend"]
                    assert payload["tacticalBlocked"] == payload["tacticalReceiptRecovered"]
                    assert payload["stateUnchangedByAttack"] and not payload["officialVlabExecuted"]
                    (results / "integration-flow.json").write_text(json.dumps(payload, indent=2) + "\n")
                (results / "integration-demo.log").write_text(handoff.stderr)
                checks.append({"name": "receipt_tactical_handoff", "scope": "LOCAL_HTTP_SYNTHETIC",
                               "status": "PASS" if handoff.returncode == 0 else "FAIL", "exit_code": handoff.returncode})
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=5)
    receipt["checks"] = checks
    receipt["protocol_extension"] = {"native_schema": 2, "operations": ["submit", "receipt_query"],
                                     "room_adapter": "EXPERIMENTAL_TEST_ONLY", "mechanical_state": "MECHANICS_UNAVAILABLE"}
    receipt["files_sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sorted(HERE.iterdir()) if p.is_file()}
    passed = all(x["status"] == "PASS" for x in checks)
    receipt["status"] = "LOCAL-TEST-PASS" if passed else "LOCAL-TEST-FAIL_OR_NOT_RUN"
    receipt["contract"] = "CONTRACT_TEST_PASS" if passed else "HOLD"
    receipt["transport"] = "MOCK_TRANSPORT_PASS" if passed else "HOLD"
    (results / "receipt.json").write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(receipt, indent=2, ensure_ascii=False))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
