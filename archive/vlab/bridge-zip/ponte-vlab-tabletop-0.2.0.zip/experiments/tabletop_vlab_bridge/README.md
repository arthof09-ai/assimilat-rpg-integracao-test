# Ponte de contrato Python ↔ TypeScript — TEST isolado

**Versão 0.2.0:** consulta persistente de recibos e adaptador experimental estão
em `INTEGRATION.md`. A matriz executável é `translation.json`; a versão v1
documentada abaixo continua preservada. Os relatórios anteriores são históricos.

`FAKE_RULES_FOR_TRANSPORT_TEST`. O único efeito é **atribuir um rótulo sintético**.
Não existe cálculo de dano, PA, crítico, defesa, transformação ou regra VLAB.
`VLAB_SOURCE_NOT_AVAILABLE`: nenhuma fonte R315 foi obtida, importada ou convertida.
O experimento usa o diretório `experiments/` da bancada existente.

## Executar

Python 3.11+ com SQLite e Node 24.12+ executam os testes funcionais sem instalação.
Node 22.16 também foi testado, usando `NODE_OPTIONS=--experimental-strip-types`.
O Node remove os tipos ao executar `.ts`; a checagem estática é uma etapa distinta.
TypeScript 5.9.3 é a única dependência de desenvolvimento, fixada pelo lockfile.
Na raiz do repositório:

```sh
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund
python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/bridge-results
python3 -m unittest discover -s tests -v
```

Com compilador já disponível, dispense a instalação e passe `--tsc /caminho/tsc`.
O runner grava logs, hashes, recibo e três projeções em `--results`. Sem compilador,
registra `NOT_RUN` e retorna erro: execução de `.ts` não se faz passar por typecheck.
Sockets loopback devem ser permitidos pelo ambiente de execução.

Para uma demonstração manual, escolha um caminho **SQLite TEST novo** fora das fontes:

```sh
mkdir -p work
python3 experiments/tabletop_vlab_bridge/authority.py --db work/bridge-demo.sqlite --port 8765
```

Em outro terminal, usando o mesmo Node:

```sh
BRIDGE_URL=http://127.0.0.1:8765/bridge node experiments/tabletop_vlab_bridge/demo.mjs
```

O demo cria sua sala uma vez; para repetir sem alterar esse banco, escolha outro banco
TEST. Ctrl+C encerra o servidor. Não exponha esse processo ou banco a outra máquina.
As identidades `FAKE_TEST_MASTER`, `FAKE_TEST_PLAYER1`, `FAKE_TEST_PLAYER2` são
fixtures públicas deliberadas. Não constituem login ou credenciais de produção.

## Contrato v1

`POST /bridge`, JSON UTF-8, `Authorization: Bearer <fixture>`. Papel e ator são
derivados da sessão do servidor; o corpo nunca concede identidade ou privilégio.
As três sessões participam de todas as salas sintéticas deste TEST. Criar sala,
checkpoint e restaurar são operações exclusivas do Mestre. Cada player controla
somente seu próprio ator; o Mestre pode atribuir rótulos a qualquer ator sintético.

Todos os pedidos têm exatamente `schema_version: 1`, `op`, `room_id`, mais:

| Envelope `op` | Campos adicionais obrigatórios |
| --- | --- |
| `create` | `client_action_id`, `expected_revision` (0) |
| `view` | nenhum |
| `submit` | `client_action_id`, `expected_revision`, `actor_id`, `effect: {kind: "FAKE_SET_LABEL", label}` |
| `history` | `after_revision` |
| `checkpoint` | `client_action_id`, `expected_revision` |
| `restore` | `client_action_id`, `expected_revision`, `checkpoint_id` |

Os tipos discriminados estão em `client.ts`; a autoridade Python valida os campos
exatos e os tipos antes de executar. Campos extras em qualquer envelope/efeito,
chaves JSON duplicadas, `__proto__`, `prototype` e `constructor` são rejeitados.
`schema_version` e revisões não aceitam booleanos nem números fracionários.
IDs: 1–64 caracteres ASCII alfanuméricos, `_` ou `-`; revisões entre 0 e 2³¹−1.
Rótulos: 1–80 caracteres Unicode, UTF-8 válido, sem controles. A apresentação
usa `textContent`; rótulos não são interpretados como HTML.

Sucesso: `schema_version`, `op` correspondente, `ok:true`, `room_id`, `revision`.
Operações com intenção retornam `client_action_id`; `submit`/`restore` também
retornam `public_event_id` (`event-N`, escopado à sala). `checkpoint` retorna só um
identificador opaco, sem bytes do snapshot. Todos, exceto `history`, retornam `view`.
`history` retorna `events` públicos ordenados após `after_revision`. Evento de
restore contém somente a projeção filtrada para a sessão que consulta o histórico.

Erro tem sempre **somente** este envelope, sem eco do pedido, estado ou exceção:

```json
{"schema_version":1,"op":"error","ok":false,"error":{"code":"STALE_REVISION"}}
```

| Código tipado | HTTP | Efeito da tentativa |
| --- | --- | --- |
| `STALE_REVISION` | 409 | nenhum; reconciliar antes de uma nova intenção |
| `DUPLICATE_INTENT` | 409 | nenhum; ID já consumido, mesmo com corpo diferente |
| `FORBIDDEN` | 403 | nenhum; inclui ator alheio e sala ausente |
| `INVALID_SCHEMA` | 400 | nenhum |
| `UNKNOWN_EFFECT` | 400 | nenhum; mecânica real não é suportada |
| `LIMIT_EXCEEDED` | 413 | nenhum |
| `INTERNAL_ERROR` | 500 | transação revertida; detalhe privado omitido |

Se não houver recibo válido (timeout, queda, resposta inválida), o cliente lança
`TransportUnknown` com `outcome: "UNKNOWN"`. Uma falha de rede não comprova rejeição.
Consulte `view`/`history` e tente o **mesmo** `client_action_id`; não invente outro ID.
O cliente serializa sua fila, captura o comando antes de enfileirar e nunca altera
`expected_revision`. Clientes diferentes competem na transação do servidor.

## Persistência, projeção e limites

`BEGIN IMMEDIATE` serializa também duas instâncias com o mesmo arquivo SQLite.
Estado, evento e deduplicação são gravados em uma transação com `synchronous=FULL`.
Qualquer falha de execução, persistência ou tamanho de resposta reverte tudo.
O servidor reconstruído usa checkpoint privado mais eventos posteriores; testes
comparam esse resultado ao replay integral e aos payloads antes da queda.
Restaurar gera outro evento e **aumenta** a revisão; os IDs já consumidos permanecem
na tabela de intenções, inclusive os de efeitos revertidos pelo restore.
Checkpoint não muda revisão pública, pois não altera o estado visível.

Projeções são montadas por allowlist no Python **antes** da serialização:

| Papel | Campos de `view` além de `mode`, `role`, `actors` públicos |
| --- | --- |
| Mestre | `master_note`, `private_notes` sintéticos |
| Player1 | `own_actor_id: actor-1`, `own_note: FAKE_P1_ONLY` |
| Player2 | `own_actor_id: actor-2`, `own_note: FAKE_P2_ONLY` |

Players não recebem notas do Mestre ou do outro player, checkpoint bruto,
fingerprint, journal ou hashes/head internos. Testes examinam sucesso, erros,
histórico com restore e cold restart. O cliente também rejeita respostas com
campos inesperados; essa verificação não substitui a filtragem no servidor.
As notas `FAKE_*` estão no código exclusivamente como marcadores de teste.

Limites: corpo 4.096 bytes; resposta 65.536 bytes; profundidade 12; 8 salas;
128 eventos e 16 checkpoints por sala. Sem truncamento silencioso. Se um histórico
exceder o teto de resposta, retorna `LIMIT_EXCEEDED`; consulte uma revisão mais
recente. HTTP exige tamanho explícito, recusa transfer encoding, não habilita CORS
e marca respostas `no-store`. Os logs HTTP não incluem pedidos ou credenciais.

Este mock não oferece autenticação real, TLS/WSS, revogação, persistência em
hardware auditado, múltiplos dispositivos ou integração Pages. O banco contém
estado privado **sintético**, é artefato backend e nunca deve ser enviado a player.
Controle de acesso por sala real e autenticação exigem outro gate antes de produção.

## Preservação do TEST32

Nenhum arquivo existente, workflow ou front-end é modificado. TEST32 vive em
`gh-pages`, commit público `0aa9bc817844fa4ce0e16a2103a3a89988df577c`; a bancada main
não contém esses arquivos. A CSP original usa `connect-src 'none'` e o workspace
contém estado local do Mestre: não acoplar a ponte simplesmente trocando esse
workspace por um payload de rede ou enviando-o inteiro a players.

Uma integração futura deve ter modo de leitura separado que só renderize a
projeção recebida. Este POC fornece `present()` e não altera editor, FOV, tokens,
save/replay ou a CSP. Não faz mapeamento de ator para coordenadas inexistentes.

`verify_test32.py` aceita os quatro arquivos públicos obtidos **separadamente** no
commit fixado, valida Git blob SHA e executa oito checks no Chromium já disponível:
carregamento, tokens, FOV 4→8, reposicionamento, replay, save/reload, validação e
ausência de exceções. Não instala browser nem conecta a ponte ao front-end.

```sh
python3 experiments/tabletop_vlab_bridge/verify_test32.py --source-dir work/test32 --results work/test32-results
```

Isso é smoke de uma baseline inalterada em emulação mobile, não a bateria histórica
integral do Tabletop nem Android físico. Leia `ASSESSMENT.md` para parecer A/B e HOLDs.

Continuação: `COMPATIBILITY.md` compara os seis envelopes efetivos com PESQ-013 v2
e TEST34 documentados; `FOLLOWUP_RECEIPT.md` registra a correção de projeções com
canários aninhados, testes específicos e o bloqueio real de exportação desta sessão.
