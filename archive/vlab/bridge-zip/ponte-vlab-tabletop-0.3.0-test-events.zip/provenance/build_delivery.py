"""Build a new private TEST artifact from committed sources and executed evidence."""
import hashlib
import io
import json
import re
import subprocess
import tempfile
import zipfile
from pathlib import Path

REPO = Path('/workspace/assimilat-rpg-integracao-test')
WORK = Path('/workspace/work/test37-integration')
OUT = WORK / 'delivery'
PREFIX = 'experiments/tabletop_vlab_bridge/'
BASE = 'c1054f9c6a4db1f7a0068ae5c8c773944ec69fbf'
ORIGINAL = '046f6cc3d67ab6f8ae9a5c6eda6eaf03cd8d2267'
COMMIT = 'ad73e4fde6ce283e9f85913fb8ad3c639a59c3fb'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pretty(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def main():
    assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
    assert not git('status', '--porcelain')
    OUT.mkdir(parents=True, exist_ok=True)
    source_names = [p for p in git('ls-tree', '-r', '--name-only', COMMIT, '--', PREFIX).decode().splitlines()
                    if '/delivery/' not in p]
    data = {name: git('show', f'{COMMIT}:{name}') for name in source_names}
    assert len(data) == 29
    receipt = json.loads((WORK / 'final/receipt.json').read_text())
    for name, digest in receipt['files_sha256'].items():
        assert sha(data[PREFIX + name]) == digest
    assert receipt['status'] == 'LOCAL-TEST-PASS'
    assert receipt['checks'][0]['python_tests'] == 68
    assert receipt['checks'][0]['nested_node_tests'] == 50
    for name in ['authority.py', 'receipt_contract.py']:
        assert data[PREFIX + name] == git('show', BASE + ':' + PREFIX + name)
    original_names = git('ls-tree', '-r', '--name-only', ORIGINAL).decode().splitlines()
    assert len(original_names) == 41
    assert all((REPO / p).read_bytes() == git('show', ORIGINAL + ':' + p) for p in original_names)
    previous_zip = Path('/workspace/work/bridge-integration/delivery/ponte-vlab-tabletop-0.2.0.zip')
    assert sha(previous_zip.read_bytes()) == '31b8a9ea23d6751baeb73be328b705674c929553ccb81e61a0df495df5937fd3'

    diff_options = ['--binary', '--full-index', '--', PREFIX, f':(exclude){PREFIX}delivery/**']
    patches = [('incremental-from-c1054f9.patch', BASE), ('complete-from-046f6cc.patch', ORIGINAL)]
    patch_proofs = []
    for name, before in patches:
        patch = git('diff', before, COMMIT, *diff_options)
        data['patches/' + name] = patch
        with tempfile.TemporaryDirectory(prefix='bridge-events-patch-') as temp:
            root = Path(temp)
            subprocess.run(['git', 'init', '-q'], cwd=root, check=True)
            if before == BASE:
                for path in git('ls-tree', '-r', '--name-only', before, '--', PREFIX).decode().splitlines():
                    if '/delivery/' in path:
                        continue
                    dest = root / path
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(git('show', before + ':' + path))
            for args in [['apply', '--check', '-'], ['apply', '-']]:
                subprocess.run(['git', *args], input=patch, cwd=root, check=True)
            actual = {p.relative_to(root).as_posix(): p.read_bytes()
                      for p in (root / PREFIX).rglob('*') if p.is_file()}
            assert actual == {name: data[name] for name in source_names}
        patch_proofs.append({'name':name,'base':before,'git_apply_check':'PASS',
                             'git_apply':'PASS','source_equality':'29/29'})
    data['evidence/patch-reproduction.json'] = pretty(patch_proofs)
    for path in sorted((WORK / 'final').rglob('*')):
        if path.is_file():
            data['evidence/final/' + path.relative_to(WORK / 'final').as_posix()] = path.read_bytes()
    for name in ['source-access.json', 'canonical-recheck.json', 'runtime-current.json',
                 'security-and-provenance.json', 'red-against-020.json', 'red-against-020.log',
                 'node22-events.log']:
        data['evidence/' + name] = (WORK / name).read_bytes()
    data['provenance/changes.txt'] = git('diff', '--stat', BASE, COMMIT)
    data['provenance/history.txt'] = git('log', '-3', '--format=%H%nparents: %P%n%s')
    data['provenance/build_delivery.py'] = Path(__file__).read_bytes()
    gates = {
        'version':'0.3.0','source_commit':COMMIT,'baseline_commit':BASE,
        'branch':'test/tabletop-vlab-bridge-poc','classification':'PARTIAL_ADVANCE_SOURCE_HOLD',
        'capabilities_new':[
            'EVENT_QUERY -> existing authorized history -> typed EVENT_BATCH preserving source kind/ID/revision',
            'Stateless inbound display selection: duplicate suppression, gap detection and strict event/projection validation'],
        'new_tests':{'Python':7,'Node_nested_in_one_Python_test':12},
        'current_suite':{'Python':68,'Node_nested':[15,12,23],'TypeScript':'PASS'},
        'protected_backend_files_unchanged':['authority.py','receipt_contract.py'],
        'original_repository_files_preserved':41,
        'gates':{
            'G1':'HOLD_TEST37_AND_PESQ016_BYTES_UNAVAILABLE',
            'G2':'HOLD_NO_REAL_TEST37_CLIENT_EXECUTED',
            'G3':'0.2.0_LOCAL_RECOVERY_REGRESSION_PASS; TEST37_INTEROPERABILITY_HOLD',
            'G4':'PARTIAL_PROPOSED_BRIDGE_EVENT_BOUNDARY_PASS; FRONTEND_AND_MOVE_HOLD',
            'G5':'PASS_TEST_LOCAL_HTTP_RAW_BYTES_ONLY; PRODUCTION_AUTH_HOLD',
            'G6':'PASS_BLOCKED_TRANSPORT_ONLY_MECHANICS_UNAVAILABLE; VLAB_HOLD',
            'G7':'HOLD_REMOTE_AUTH_WSS_ANDROID_PRODUCTION'},
        'external_frontend_tests_executed':0,'external_research_tests_executed':0,
        'cloudflare_tests':0,'WSS_tests':0,'push_PR_merge_deploy':False,
        'holds':['VLAB_SOURCE_NOT_AVAILABLE','PYTHON_TS_EQUIVALENCE_NOT_TESTED',
                 'ANDROID_REAL_NOT_TESTED','VLAB_PRODUCTION_HOLD'],
        'NAC_PASS_02':'PROPORTIONAL_LOCAL_TEST_ONLY; NO_EXTERNAL_GATE_PROMOTION'}
    data['VERSION.json'] = pretty(gates)
    report = f'''# PSV — Ponte 0.3.0 / eventos e preparação TEST37

## Resultado e versão

**Avanço parcial verificado; integração vertical com TEST37 NÃO comprovada.**
Branch `test/tabletop-vlab-bridge-poc`; commit `{COMMIT}`.
Baseline 0.2.0 `{BASE}` preservada, ZIP SHA
`31b8a9ea23d6751baeb73be328b705674c929553ccb81e61a0df495df5937fd3` intacto.
Nenhum push, PR, merge, deploy, publicação pública ou recurso pago.

## ANTES → DEPOIS e produtividade

Antes, o backend já tinha histórico com tipo e projeção, mas RoomV2Adapter 0.2.0
não oferecia passagem desses eventos. EVENT_QUERY resultava em INVALID_FRAME.
Agora, a mesma autoridade e o mesmo endpoint fornecem histórico ao adaptador,
que entrega EVENT_BATCH com ROOM_UPDATED, sourceKind, eventId e revision.
Nenhum label/restore é anunciado como MOVE_CONFIRMED.

**Duas capacidades novas:** consulta de eventos tipados; seleção pura de eventos
para apresentação, com deduplicação/replay, detecção de lacunas e rejeição estrita.
Também foi ampliada a prova de segurança em bytes HTTP antes da adaptação.
**Zero integrações físicas TEST37 e zero defeitos do frontend corrigidos aqui.**
Não contar regressões antigas como novas funcionalidades.

## Acesso às fontes e impedimento preciso

Foram reabertos Laboratório canônico, LONG-RUN-01 §§15–16, GH-RP-01 e Diário.
O último marco inicial era CP-INOV-ORDEM-CODEX-POST020-20261024-001. A rechecagem
detectou CP-INOV-ORDEM-PESQUISADOR-POST016-20261024-001, PREPARADO, sem execução
nova ou mudança do mandato Codex. Nenhuma norma, writer, lease ou epoch criado.

O Notion informa os pacotes e hashes, mas declara que seu registro é documental,
sem ZIP anexado. A pasta Drive, buscas por nome/MIME e consulta somente leitura
ao repositório não localizaram TEST37/PESQ016. Não há ferramenta Library nesta
instância. download_file aceita Sediment; libfile não pode ser usado como tal.

São necessários acessos de leitura aos pacotes **já preservados**, sem refazê-los:

- TEST37: `libfile_9d54666fc1dc81919892771b5885bd97`, 4.900.496 B, SHA
  `5f1b49ab4477d1459bf8421bf4c58349dfa506e45895da379a78fc87da41912c`.
- PESQ016: `libfile_40bd1ece2d488191904b9cf0cfc0b8ac`, 34.018 B, SHA
  `d59b10b58e94253f02463fb98c98084e59dcd11ce8e15edf4ab7c374ba58e8f6`.

Via mínima: URLs privadas Drive legíveis pela conta conectada ou materialização
Library autorizada. Foi solicitada informação de links enquanto o trabalho
independente avançava. As tentativas ficam em `evidence/source-access.json`.
Não se afirma inspeção física de room-client.js, room-v2-adapter.js ou scripts
PESQ016. Não se usou cliente fictício com nome TEST37 para fabricar integração.

## Alterações

- `room_adapter.ts`: EVENT_QUERY sobre history existente; eventos identificados;
  selectNewEvents sem armazenamento, retry ou confirmação de intenção.
- `client.ts`: exporta um wrapper de validação que reutiliza os mesmos checks de
  histórico/role, sem modificar métodos de transporte existentes.
- `test_event_boundary.py/.mjs`: suíte nova e captura de bytes HTTP de fixtures.
- `type_contract.ts`: nega movimento falso e role extra em consulta de eventos.
- `test37_differential.json`: 14 requisitos, refs físicas locais e externas HOLD.
- `test37_semantic_vectors.json`: fragmentos para regressão pelo Desenvolvedor,
  sem patch instalado nem envelope externo completo inventado.
- guia EVENTS_TEST37.md, README, runner e versão/lockfile: execução/proveniência.

12 arquivos adicionados/modificados. Authority e receipt_contract byte-idênticos;
41/41 arquivos originais anteriores à ponte intactos. Nenhuma fonte externa privada
incluída. Nenhuma dependência nova; TypeScript 5.9.3 continua apenas devDependency.

## Prova e denominadores

| Verificação | Resultado real |
|---|---|
| Teste novo contra cópia exata c1054f9 | RED: 1 Python wrapper / 1 Node selecionado falham INVALID_FRAME, exit 1 |
| Suíte atual completa da ponte | 68/68 Python PASS |
| Node internos à suíte Python | 15 + 12 + 23 = 50/50 PASS; não somar como Python extra |
| Incremento novo | 7/7 Python, um contendo 12/12 Node; after hook de bytes não é outro teste |
| Regressões da ponte | 61 Python / 38 Node anteriores, incluídos no total atual |
| TypeScript | strict + erasableSyntaxOnly PASS, exit 0 |
| Node 22.16.0 | 7/7 Python do módulo novo, contendo 12/12 Node, strip-types PASS |
| Patches | aplicação/check reais + igualdade 29/29 fontes |
| Suíte original 55 do repositório | NÃO reexecutada nesta rodada; 41 fontes inalteradas |
| Cliente TEST37 / PESQ016 | 0 testes físicos nesta instância; HOLD |
| WSS, Cloudflare, Android, VLAB oficial | 0 execuções; HOLD |

Os resultados são UNIT e LOCAL_HTTP sintético. As regressões completas da ponte
foram apropriadas porque cliente/adaptador compartilhados mudaram. A suíte geral
do repositório não foi repetida sem necessidade. Uma asserção nova inicialmente
exigia Content-Type sem charset; foi corrigida no teste para aceitar JSON UTF-8
legítimo. Não apresentar esse ajuste de harness como defeito do backend.

Logs: `evidence/final/contract.log`, `typecheck.log`, `receipt.json`,
`node22-events.log`, `red-against-020.log/json`. A matriz referencia testes cujo
nome aparece no log aprovado, mas mantém testes externos NOT_RUN.
Timestamp UTC observado pelo runner: {receipt['timestamp_utc']}.
Não alegamos duração de programação com base em “Pensou por”.

Comandos de reprodução:

```sh
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund
PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_event_boundary -v
BRIDGE_EVENT_WIRE_LOG="$PWD/work/event-wire.json" BRIDGE_SECURITY_WIRE_DIR="$PWD/work/security-wire" python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/events-results
# Node22.16 no PATH:
NODE_OPTIONS=--experimental-strip-types PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_event_boundary -v
```

Criar `work/` antes da captura opcional. Node principal v24.19.0, Python3.12.14.
O runner inclui demonstrações anteriores como regressão, não novidade TEST37.

## Wire e eventos demonstrados

Input novo: `{{schema:assim.tabletop.room.bridge.test.v2,type:EVENT_QUERY,roomId,afterRevision}}`.
Tradução: `schema_version:1,op:history,room_id,after_revision`, no POST /bridge
existente. Resposta: EVENT_BATCH, sequência de EVENT com kind ROOM_UPDATED e
sourceKind FAKE_SET_LABEL ou FAKE_RESTORE. Exemplos completos e API tipada no guia.
`evidence/final/event-wire.json` captura bytes reais antes da tradução. Não há
WebSocket, push ou outro servidor por trás desta demonstração.

selectNewEvents exige sala, cursor e papel de sessão conhecidos. Replays antigos
são descartados, sem retroceder cursor; lote com lacuna retorna GAP sem aplicação.
Sequência invertida/duplicada internamente, evento desconhecido, falso movimento,
objeto extra ou projeção de outro role falha fechada. Não há outbox nova.

ROOM_UPDATED não confirma intenção; evento público não permite consultar recibo
privado. O cursor de apresentação é independente da persistência autoritativa.
O consumidor deve avançar seu cursor só depois de aplicar a apresentação e deve
vinculá-lo à identidade/sala/sessão. Não se inventa seq/epoch de outro contrato.

## Estado do problema semântico do frontend

O RED ROOM_UPDATED → MOVE_CONFIRMED é evidência documental da PESQ016, não execução
nova nossa. Não foi produzido GREEN do TEST37 indisponível. A ponte agora preserva
tipo original e não emite movimento. VETORES propostos distinguem ROOM_UPDATED de
MOVE_VISUAL_TEST. Movimento positivo necessita modelo autoritativo de mapa e fonte
real, e não é simulado com FAKE_SET_LABEL. Correção de room-v2-adapter.js original
continua pertencendo ao Desenvolvedor. A matriz não declara wire canonizado.

## Recibos e recuperação

Todo o mecanismo 0.2.0 permaneceu intacto e passou na regressão, inclusive socket
encerrado após COMMIT, processo morto/reiniciado, query HTTP e recibo original.
O avanço desta rodada é que consulta de eventos/replay não fabrica ACK/recibo ou
resolve UNKNOWN indevidamente. **Não comprova P3 interoperável com TEST37.**
Mesmo ID com corpo diferente, revisão obsoleta, concorrência, dono do recibo e
rejeições duráveis continuam protegidos; não se criou outbox nem novo ID de retry.

## Segurança antes da transmissão

Novos testes HTTP inspecionam os bytes antes de BridgeClient/adaptação/render.
Unknown metadata Mestre-only em snapshot restore é omitida. Contêineres em campos
escalares, tipos administrativos/futuros falsificados, role/participant/profile
extras e exceção interna com canário resultam em rejeição sanitizada. Consultar
histórico público não concede recibo de outro emissor. Comando em ator alheio
retorna rejeição durável e não adiciona evento. Seis capturas negativas estão em
`evidence/final/security-wire/`. Não há ocultação de UI como barreira de segurança.

Tokens FAKE_TEST são fixtures deliberadas, não login. Todos pertencem às salas
TEST. Não há membership/convite/revogação real, TLS, WSS, Party ou três aparelhos.
Revisão lexical/manual dos fontes/logs/patches: somente fixtures e canários; sem
VLAB privado, campanha real, credenciais ou notas Mestre-only reais.

## VLAB e infraestrutura

ATTACK_REQUEST usa o contrato v2 existente. No teste novo, rejeição
MECHANICS_UNAVAILABLE é persistida/consultada enquanto histórico e cursor ficam
inalterados. Nenhum dano, PA, Vida, Alma, alvo legal ou sucesso é calculado.
ABI real exige identificador idempotente, contexto autorizado e decisão mecânica
competente versionada. O contrato atual mantém mechanical_result_ref:null;
receber decisão real exigirá validação/versão adequada e reconciliação externa.
Somente VLAB adjudica. A sala mantém identidade/ACL/revisão/recibo/projeção.

http.server/threads/sockets/SQLite por arquivo são dependências locais; DO não
substitui esse banco por simples troca de nome. Probes atuais não acharam
wrangler/workerd/miniflare. 0 Cloudflare/WSS, sem deploy ou outra autoridade
definitiva, R$0 adicional em serviços. Análise 0.2.0 preservada, sem reescrita.

## Artefatos e custódia

Pacote novo `ponte-vlab-tabletop-0.3.0-test-events.zip`, sem sobrescrever 0.2.0.
29 fontes/documentos/configs; patch incremental c1054f9 e completo 046f6cc;
capturas, logs, matrizes, provas, VERSION.json, MANIFEST.json e SHA256SUMS.
Ambos patches foram aplicados em árvores temporárias e comparados byte a byte.
O hash do ZIP fechado fica no sidecar externo, evitando hash circular.
URLs/IDs e verificação de download serão fornecidos após readback real, não
antecipados neste relatório. Nenhum fonte privado de outro executor foi copiado.

No Android, abrir a pasta privada existente:
https://drive.google.com/drive/folders/1RPl9yOjGrhO73vfRU0jmmGHZkvkKHG1B
e escolher o ZIP 0.3.0 → ⋮ → Fazer download. Baixar também SHA e PSV. Esses passos
não constituem execução em Android físico.

## Gates, continuidade e NAC-PASS-02

G1 HOLD: bytes externos indisponíveis. G2 HOLD: nenhum cliente TEST37 executado.
G3 baseline local PASS; interoperabilidade de recuperação TEST37 HOLD.
G4 parcial: fronteira própria preserva ROOM_UPDATED; frontend/movimento pendentes.
G5 PASS TEST LOCAL_HTTP somente. G6 PASS limitado ao bloqueio; combate VLAB HOLD.
G7 HOLD: auth/servidor remoto/WSS/Android não homologados.
NAC-PASS-02 proporcional; não promover um gate por outro ter passado.

LAST-VERIFIED-UNIT: evento identificado do backend existente até a fronteira
proposta, replay/gap e bytes HTTP negativos; pacote e recibo conforme readback.
FIRST-PENDING: materializar TEST37/PESQ016 pelos acessos existentes para confronto
de namespace, envelopes, callbacks, journal e projeção de mapa reais.
NEXT: executar cliente/validadores genuínos contra a mesma autoridade; ajustar
apenas a fronteira competente e entregar vetores/patch candidato ao Desenvolvedor.
NO-REPEAT: ponte 0.2.0, recibos, SQLite, Arena visual/journal, PESQ016, motor e
outro backend. Não reconstruir nem alegar conclusão da integração oficial.

`FAKE_RULES_FOR_TRANSPORT_TEST`, `VLAB_SOURCE_NOT_AVAILABLE`,
`PYTHON_TS_EQUIVALENCE_NOT_TESTED`, `ANDROID_REAL_NOT_TESTED`,
`VLAB_PRODUCTION_HOLD` preservados. GH-NOT-RUN.
'''
    report_name = 'PSV-ponte-vlab-tabletop-0.3.0.md'
    data[report_name] = report.encode()
    patterns = [rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',rb'gh[pousr]_[A-Za-z0-9]{30,}',
                rb'AKIA[A-Z0-9]{16}',rb'AIza[A-Za-z0-9_-]{35}',rb'ya29\.[A-Za-z0-9_-]{25,}']
    findings = [name for name, content in data.items() if any(re.search(p,content) for p in patterns)]
    assert not findings, findings
    data['evidence/package-review.json'] = pretty({'status':'PASS_LOCAL_SYNTHETIC_SCOPE',
        'credential_pattern_findings':findings,'source_files':29,'original_files_unchanged':41,
        'external_frontend_or_research_code_copied':False,'previous_zip_preserved':True})
    manifest = {'version':'0.3.0','source_commit':COMMIT,'baseline_commit':BASE,
        'files':[{'path':name,'bytes':len(blob),'sha256':sha(blob)} for name,blob in sorted(data.items())],
        'excluded_from_manifest':['MANIFEST.json','SHA256SUMS']}
    data['MANIFEST.json'] = pretty(manifest)
    data['SHA256SUMS'] = ''.join(f'{sha(blob)}  {name}\n' for name,blob in sorted(data.items())).encode()
    target = OUT / 'ponte-vlab-tabletop-0.3.0-test-events.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,blob in sorted(data.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,24,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16;z.writestr(info,blob,compresslevel=9)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))==len(data)
        assert all(z.read(name)==blob for name,blob in data.items())
    digest = sha(target.read_bytes())
    (OUT/(target.name+'.sha256')).write_text(f'{digest}  {target.name}\n')
    (OUT/report_name).write_bytes(data[report_name])
    result={'status':'PASS_LOCAL_PACKAGE','version':'0.3.0','source_commit':COMMIT,
        'zip':str(target),'sha256':digest,'bytes':target.stat().st_size,'entries':len(data),
        'manifest_files':len(manifest['files']),'sha256sum_records':len(data)-1,'patch_proofs':patch_proofs,
        'classification':'PARTIAL_ADVANCE; TEST37_PHYSICAL_AND_VERTICAL_HOLD'}
    (OUT/'build-receipt.json').write_bytes(pretty(result))
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
