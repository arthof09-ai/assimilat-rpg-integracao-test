# PSV — Ponte 0.3.0 / eventos e preparação TEST37

## Resultado e versão

**Avanço parcial verificado; integração vertical com TEST37 NÃO comprovada.**
Branch `test/tabletop-vlab-bridge-poc`; commit `ad73e4fde6ce283e9f85913fb8ad3c639a59c3fb`.
Baseline 0.2.0 `c1054f9c6a4db1f7a0068ae5c8c773944ec69fbf` preservada, ZIP SHA
`31b8a9ea23d6751baeb73be328b705674c929553ccb81e61a0df495df5937fd3` intacto.
Nenhum push, PR, merge, deploy, publicação pública ou recurso pago.

## ANTES → DEPOIS e produtividade

Antes, o backend já tinha histórico com tipo e projeção, mas RoomV2Adapter 0.2.0
não oferecia passagem desses eventos. EVENT_QUERY resultava em INVALID_FRAME.
Agora, a mesma autoridade e o mesmo endpoint fornecem histórico ao adaptador,
que entrega EVENT_BATCH com ROOM_UPDATED, sourceKind, eventId e revision.
Nenhum label/restore é anunciado como MOVE_CONFIRMED.

**Duas capacidades novas:** consulta de eventos tipados; seleção pura de eventos
para apresentação, com deduplicação/replay, detecção de lacunas e rejeição estrita.
Também foi ampliada a prova de segurança em bytes HTTP antes da adaptação.
**Zero integrações físicas TEST37 e zero defeitos do frontend corrigidos aqui.**
Não contar regressões antigas como novas funcionalidades.

## Acesso às fontes e impedimento preciso

Foram reabertos Laboratório canônico, LONG-RUN-01 §§15–16, GH-RP-01 e Diário.
O último marco inicial era CP-INOV-ORDEM-CODEX-POST020-20261024-001. A rechecagem
detectou CP-INOV-ORDEM-PESQUISADOR-POST016-20261024-001, PREPARADO, sem execução
nova ou mudança do mandato Codex. Nenhuma norma, writer, lease ou epoch criado.

O Notion informa os pacotes e hashes, mas declara que seu registro é documental,
sem ZIP anexado. A pasta Drive, buscas por nome/MIME e consulta somente leitura
ao repositório não localizaram TEST37/PESQ016. Não há ferramenta Library nesta
instância. download_file aceita Sediment; libfile não pode ser usado como tal.

São necessários acessos de leitura aos pacotes **já preservados**, sem refazê-los:

- TEST37: `libfile_9d54666fc1dc81919892771b5885bd97`, 4.900.496 B, SHA
  `5f1b49ab4477d1459bf8421bf4c58349dfa506e45895da379a78fc87da41912c`.
- PESQ016: `libfile_40bd1ece2d488191904b9cf0cfc0b8ac`, 34.018 B, SHA
  `d59b10b58e94253f02463fb98c98084e59dcd11ce8e15edf4ab7c374ba58e8f6`.

Via mínima: URLs privadas Drive legíveis pela conta conectada ou materialização
Library autorizada. Foi solicitada informação de links enquanto o trabalho
independente avançava. As tentativas ficam em `evidence/source-access.json`.
Não se afirma inspeção física de room-client.js, room-v2-adapter.js ou scripts
PESQ016. Não se usou cliente fictício com nome TEST37 para fabricar integração.

## Alterações

- `room_adapter.ts`: EVENT_QUERY sobre history existente; eventos identificados;
  selectNewEvents sem armazenamento, retry ou confirmação de intenção.
- `client.ts`: exporta um wrapper de validação que reutiliza os mesmos checks de
  histórico/role, sem modificar métodos de transporte existentes.
- `test_event_boundary.py/.mjs`: suíte nova e captura de bytes HTTP de fixtures.
- `type_contract.ts`: nega movimento falso e role extra em consulta de eventos.
- `test37_differential.json`: 14 requisitos, refs físicas locais e externas HOLD.
- `test37_semantic_vectors.json`: fragmentos para regressão pelo Desenvolvedor,
  sem patch instalado nem envelope externo completo inventado.
- guia EVENTS_TEST37.md, README, runner e versão/lockfile: execução/proveniência.

12 arquivos adicionados/modificados. Authority e receipt_contract byte-idênticos;
41/41 arquivos originais anteriores à ponte intactos. Nenhuma fonte externa privada
incluída. Nenhuma dependência nova; TypeScript 5.9.3 continua apenas devDependency.

## Prova e denominadores

| Verificação | Resultado real |
|---|---|
| Teste novo contra cópia exata c1054f9 | RED: 1 Python wrapper / 1 Node selecionado falham INVALID_FRAME, exit 1 |
| Suíte atual completa da ponte | 68/68 Python PASS |
| Node internos à suíte Python | 15 + 12 + 23 = 50/50 PASS; não somar como Python extra |
| Incremento novo | 7/7 Python, um contendo 12/12 Node; after hook de bytes não é outro teste |
| Regressões da ponte | 61 Python / 38 Node anteriores, incluídos no total atual |
| TypeScript | strict + erasableSyntaxOnly PASS, exit 0 |
| Node 22.16.0 | 7/7 Python do módulo novo, contendo 12/12 Node, strip-types PASS |
| Patches | aplicação/check reais + igualdade 29/29 fontes |
| Suíte original 55 do repositório | NÃO reexecutada nesta rodada; 41 fontes inalteradas |
| Cliente TEST37 / PESQ016 | 0 testes físicos nesta instância; HOLD |
| WSS, Cloudflare, Android, VLAB oficial | 0 execuções; HOLD |

Os resultados são UNIT e LOCAL_HTTP sintético. As regressões completas da ponte
foram apropriadas porque cliente/adaptador compartilhados mudaram. A suíte geral
do repositório não foi repetida sem necessidade. Uma asserção nova inicialmente
exigia Content-Type sem charset; foi corrigida no teste para aceitar JSON UTF-8
legítimo. Não apresentar esse ajuste de harness como defeito do backend.

Logs: `evidence/final/contract.log`, `typecheck.log`, `receipt.json`,
`node22-events.log`, `red-against-020.log/json`. A matriz referencia testes cujo
nome aparece no log aprovado, mas mantém testes externos NOT_RUN.
Timestamp UTC observado pelo runner: 2026-10-24T15:42:04.447934+00:00.
Não alegamos duração de programação com base em “Pensou por”.

Comandos de reprodução:

```sh
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund
PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_event_boundary -v
BRIDGE_EVENT_WIRE_LOG="$PWD/work/event-wire.json" BRIDGE_SECURITY_WIRE_DIR="$PWD/work/security-wire" python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/events-results
# Node22.16 no PATH:
NODE_OPTIONS=--experimental-strip-types PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_event_boundary -v
```

Criar `work/` antes da captura opcional. Node principal v24.19.0, Python3.12.14.
O runner inclui demonstrações anteriores como regressão, não novidade TEST37.

## Wire e eventos demonstrados

Input novo: `{schema:assim.tabletop.room.bridge.test.v2,type:EVENT_QUERY,roomId,afterRevision}`.
Tradução: `schema_version:1,op:history,room_id,after_revision`, no POST /bridge
existente. Resposta: EVENT_BATCH, sequência de EVENT com kind ROOM_UPDATED e
sourceKind FAKE_SET_LABEL ou FAKE_RESTORE. Exemplos completos e API tipada no guia.
`evidence/final/event-wire.json` captura bytes reais antes da tradução. Não há
WebSocket, push ou outro servidor por trás desta demonstração.

selectNewEvents exige sala, cursor e papel de sessão conhecidos. Replays antigos
são descartados, sem retroceder cursor; lote com lacuna retorna GAP sem aplicação.
Sequência invertida/duplicada internamente, evento desconhecido, falso movimento,
objeto extra ou projeção de outro role falha fechada. Não há outbox nova.

ROOM_UPDATED não confirma intenção; evento público não permite consultar recibo
privado. O cursor de apresentação é independente da persistência autoritativa.
O consumidor deve avançar seu cursor só depois de aplicar a apresentação e deve
vinculá-lo à identidade/sala/sessão. Não se inventa seq/epoch de outro contrato.

## Estado do problema semântico do frontend

O RED ROOM_UPDATED → MOVE_CONFIRMED é evidência documental da PESQ016, não execução
nova nossa. Não foi produzido GREEN do TEST37 indisponível. A ponte agora preserva
tipo original e não emite movimento. VETORES propostos distinguem ROOM_UPDATED de
MOVE_VISUAL_TEST. Movimento positivo necessita modelo autoritativo de mapa e fonte
real, e não é simulado com FAKE_SET_LABEL. Correção de room-v2-adapter.js original
continua pertencendo ao Desenvolvedor. A matriz não declara wire canonizado.

## Recibos e recuperação

Todo o mecanismo 0.2.0 permaneceu intacto e passou na regressão, inclusive socket
encerrado após COMMIT, processo morto/reiniciado, query HTTP e recibo original.
O avanço desta rodada é que consulta de eventos/replay não fabrica ACK/recibo ou
resolve UNKNOWN indevidamente. **Não comprova P3 interoperável com TEST37.**
Mesmo ID com corpo diferente, revisão obsoleta, concorrência, dono do recibo e
rejeições duráveis continuam protegidos; não se criou outbox nem novo ID de retry.

## Segurança antes da transmissão

Novos testes HTTP inspecionam os bytes antes de BridgeClient/adaptação/render.
Unknown metadata Mestre-only em snapshot restore é omitida. Contêineres em campos
escalares, tipos administrativos/futuros falsificados, role/participant/profile
extras e exceção interna com canário resultam em rejeição sanitizada. Consultar
histórico público não concede recibo de outro emissor. Comando em ator alheio
retorna rejeição durável e não adiciona evento. Seis capturas negativas estão em
`evidence/final/security-wire/`. Não há ocultação de UI como barreira de segurança.

Tokens FAKE_TEST são fixtures deliberadas, não login. Todos pertencem às salas
TEST. Não há membership/convite/revogação real, TLS, WSS, Party ou três aparelhos.
Revisão lexical/manual dos fontes/logs/patches: somente fixtures e canários; sem
VLAB privado, campanha real, credenciais ou notas Mestre-only reais.

## VLAB e infraestrutura

ATTACK_REQUEST usa o contrato v2 existente. No teste novo, rejeição
MECHANICS_UNAVAILABLE é persistida/consultada enquanto histórico e cursor ficam
inalterados. Nenhum dano, PA, Vida, Alma, alvo legal ou sucesso é calculado.
ABI real exige identificador idempotente, contexto autorizado e decisão mecânica
competente versionada. O contrato atual mantém mechanical_result_ref:null;
receber decisão real exigirá validação/versão adequada e reconciliação externa.
Somente VLAB adjudica. A sala mantém identidade/ACL/revisão/recibo/projeção.

http.server/threads/sockets/SQLite por arquivo são dependências locais; DO não
substitui esse banco por simples troca de nome. Probes atuais não acharam
wrangler/workerd/miniflare. 0 Cloudflare/WSS, sem deploy ou outra autoridade
definitiva, R$0 adicional em serviços. Análise 0.2.0 preservada, sem reescrita.

## Artefatos e custódia

Pacote novo `ponte-vlab-tabletop-0.3.0-test-events.zip`, sem sobrescrever 0.2.0.
29 fontes/documentos/configs; patch incremental c1054f9 e completo 046f6cc;
capturas, logs, matrizes, provas, VERSION.json, MANIFEST.json e SHA256SUMS.
Ambos patches foram aplicados em árvores temporárias e comparados byte a byte.
O hash do ZIP fechado fica no sidecar externo, evitando hash circular.
URLs/IDs e verificação de download serão fornecidos após readback real, não
antecipados neste relatório. Nenhum fonte privado de outro executor foi copiado.

No Android, abrir a pasta privada existente:
https://drive.google.com/drive/folders/1RPl9yOjGrhO73vfRU0jmmGHZkvkKHG1B
e escolher o ZIP 0.3.0 → ⋮ → Fazer download. Baixar também SHA e PSV. Esses passos
não constituem execução em Android físico.

## Gates, continuidade e NAC-PASS-02

G1 HOLD: bytes externos indisponíveis. G2 HOLD: nenhum cliente TEST37 executado.
G3 baseline local PASS; interoperabilidade de recuperação TEST37 HOLD.
G4 parcial: fronteira própria preserva ROOM_UPDATED; frontend/movimento pendentes.
G5 PASS TEST LOCAL_HTTP somente. G6 PASS limitado ao bloqueio; combate VLAB HOLD.
G7 HOLD: auth/servidor remoto/WSS/Android não homologados.
NAC-PASS-02 proporcional; não promover um gate por outro ter passado.

LAST-VERIFIED-UNIT: evento identificado do backend existente até a fronteira
proposta, replay/gap e bytes HTTP negativos; pacote e recibo conforme readback.
FIRST-PENDING: materializar TEST37/PESQ016 pelos acessos existentes para confronto
de namespace, envelopes, callbacks, journal e projeção de mapa reais.
NEXT: executar cliente/validadores genuínos contra a mesma autoridade; ajustar
apenas a fronteira competente e entregar vetores/patch candidato ao Desenvolvedor.
NO-REPEAT: ponte 0.2.0, recibos, SQLite, Arena visual/journal, PESQ016, motor e
outro backend. Não reconstruir nem alegar conclusão da integração oficial.

`FAKE_RULES_FOR_TRANSPORT_TEST`, `VLAB_SOURCE_NOT_AVAILABLE`,
`PYTHON_TS_EQUIVALENCE_NOT_TESTED`, `ANDROID_REAL_NOT_TESTED`,
`VLAB_PRODUCTION_HOLD` preservados. GH-NOT-RUN.
