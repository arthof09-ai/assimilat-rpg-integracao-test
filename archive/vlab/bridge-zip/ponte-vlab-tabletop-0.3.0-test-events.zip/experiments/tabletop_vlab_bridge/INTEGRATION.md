# Ponte 0.2.0 — recibos persistentes e fronteira tática TEST

Continuação na mesma branch `test/tabletop-vlab-bridge-poc`, sem criar outra sala
autoritativa, backend oficial, outbox ou interface visual. Apenas rótulos sintéticos
podem ser aplicados. VLAB continua a autoridade mecânica exclusiva.

## Proveniência confirmada, sem reescrever histórico

`bad50082621f5ddebb157088949dccac8e6aa8ca` contém os fontes da entrega anterior.
Seu filho direto `7fd03324209ee44d2314ac86609b17293542bef1` acrescenta **somente**
`delivery/ponte-vlab-tabletop-test.zip` e `.zip.sha256`; não altera fonte.
O recibo dentro daquele ZIP nomeia o commit de fonte, não o commit que adicionou
a embalagem. Relação demonstrada por `git show`, parent e diff locais:

```sh
git show --format=fuller --stat 7fd03324209ee44d2314ac86609b17293542bef1
git diff --stat bad50082621f5ddebb157088949dccac8e6aa8ca 7fd03324209ee44d2314ac86609b17293542bef1
```

O ZIP anterior de 367.597 B / 44 entradas / SHA-256
`80aa408adabcd3c8e9fb2267d7efeb5ee4b9a3ef5e22c618a9d814bb98b751a3`
permanece intacto no Git e no Drive, para rollback. Nenhuma divergência foi apagada
ou corrigida artificialmente. O novo pacote identifica seu próprio commit de fonte.

## O bloqueio eliminado

Antes: o ID deduplicado evitava reaplicação, mas não havia resultado consultável
por intenção. Depois: **no mesmo Authority/SQLite**, schema v2 acrescenta `submit`
com recibo durável e `receipt_query`. Os seis envelopes `schema_version:1`
continuam com o comportamento original, inclusive DUPLICATE_INTENT em reenvio v1.
O teste que antes tratava 2 como versão desconhecida usa agora 999; a nova versão
é deliberadamente aceita e tem validação própria, não é relaxamento de campos v1.

O teste inicial de três requisitos novos falhou contra a baseline; passou após a
extensão. Uma falha inicial no adaptador identificou TypeScript parameter-property
incompatível com strip-only; foi removida e o typecheck passou a exigir
`erasableSyntaxOnly`. Não confundir diagnóstico de sintaxe/runtime com regras VLAB.

## Contrato nativo mínimo v2, sobre o HTTP existente

Mesmo `POST /bridge`, UTF-8, `Content-Type: application/json`, Bearer fixture.
Não há endpoint novo, CORS habilitado, WebSocket ou autenticação de produção.

Envio sintético:

```json
{"schema_version":2,"op":"submit","room_id":"demo","client_action_id":"same-id","expected_revision":0,"actor_id":"actor-1","effect":{"kind":"FAKE_SET_LABEL","label":"Transport OK"}}
```

Consulta pelo mesmo ID, em qualquer revisão atual:

```json
{"schema_version":2,"op":"receipt_query","room_id":"demo","client_action_id":"same-id"}
```

`submit` retorna HTTP 200, `ok:true` e `receipt`. Isso significa que o envelope foi
processado; **o efeito só foi aceito se `receipt.status === "ACCEPTED"`**.
`receipt_query` retorna `lookup: FOUND` com o mesmo recibo, ou `NOT_FOUND` com null.
Nenhuma consulta pode especificar outro participante. Chave do recibo:
`room_id + principal derivado no servidor + client_action_id`.

Recibo versionado, campos exatos:

```json
{"receipt_version":1,"receipt_id":"receipt-0123456789abcdef0123456789abcdef","client_action_id":"same-id","status":"ACCEPTED","revision":1,"code":"APPLIED","public_event_id":"event-1","mechanics":"NOT_REQUESTED","mechanical_result_ref":null}
```

O UUID acima ilustra o formato; demonstração gera IDs reais, não usa esse literal.
O recibo não inclui workspace, nota privada, ator/alvo arbitrário, snapshot bruto,
fingerprint ou journal. É um resultado mínimo imutável da intenção; consulte view
depois para obter o estado **atual**. Restore pode ter revertido o efeito, mas não
apaga o fato histórico nem libera o ID para reaplicação.

| Situação | Semântica |
| --- | --- |
| Primeiro efeito válido | Estado, evento, intenção e recibo ACCEPTED numa transação |
| Mesmo ID + mesmo comando | Mesmo recibo original; nenhuma segunda aplicação |
| Mesmo ID + conteúdo diferente | HTTP 409 ID_REUSE_CONFLICT; original continua consultável |
| Revisão obsoleta / ator alheio / efeito não suportado | Recibo REJECTED durável, sem alteração do estado/eventos |
| Erro de schema, token inválido, sala ausente ou teto de recibos | Erro sanitizado, sem efeito nem novo recibo |
| Falha SQLite antes de COMMIT | Rollback de estado/evento/intenção/recibo; sem confirmação terminal |
| Queda depois de COMMIT | UNKNOWN no cliente; consulta recupera o resultado persistido |
| Recibo ausente ou de outro participante | Mesmo NOT_FOUND, sem revelar existência; preservar UNKNOWN |
| ID antigo aceito somente por v1 | Não fabricar recibo; NOT_FOUND continua UNKNOWN, reenvio v2 bloqueado |

Rejeições v2 válidas consomem o ID, inclusive depois de outra ação avançar a
revisão. Não reutilizar o mesmo ID para corrigir/reformular uma intenção terminal.
Após UNKNOWN, jamais criar automaticamente outra ID ou reenviar com corpo mudado.
O payload canônico é comparado em campo privado; não existe conversão silenciosa
de tipos ou revisão. A ordem das chaves JSON não muda a identidade da intenção.

`BEGIN IMMEDIATE` e SAVEPOINT protegem o trabalho da ação e seu recibo. Rejeição
de negócio reverte só a ação e grava a decisão terminal; erro de persistência ou
projeção reverte a transação completa. A nova tabela é criada sem alterar registros
legados. Não há backfill fictício, TTL ou eviction de recibos antigos.
Teto explícito: 512 recibos por sala; corpo 4 KiB, resposta 64 KiB, 128 eventos,
16 checkpoints, 8 salas. Falhas de capacidade não autorizam apagar o histórico.

## Adaptador de transporte, sem substituir TEST36

`RoomV2Adapter.exchange()` é uma tradução **sem estado/outbox**, apoiada no mesmo
BridgeClient. `translation.json` é a matriz máquina-legível: 17 linhas de suporte,
limitação ou rejeição, e mapeamento de campos. Os testes executam cada linha e
verificam a cobertura da matriz. Não é somente uma tabela de relatório.

```text
roomId -> room_id
commandId -> client_action_id
baseRevision -> expected_revision
actorId -> actor_id
JOIN/RESYNC -> view v1 -> WELCOME com projeção atual
INTENT.FAKE_SET_LABEL -> submit v2 -> ACK com recibo
RECEIPT_QUERY -> receipt_query v2 -> ACK com recibo, ou UNKNOWN
INTENT.ATTACK_REQUEST -> submit v2 -> recibo REJECTED/MECHANICS_UNAVAILABLE
```

Schema explícito da camada testada: `assim.tabletop.room.bridge.test.v2`.
O namespace é distinto de presentation.v1 e da proposta externa não inspecionada
em bytes. JOIN nunca cria sala; bootstrap é operação administrativa v1 separada.
RESYNC retorna snapshot atual, não histórico integral. Não se inventa seq a partir
de revision; campos seq/profile/role/participantId inesperados são recusados.
CREATE/CHECKPOINT/RESTORE não têm alias nesse adaptador, nem para Mestre.

WELCOME contém a projeção de três atores de rótulo TEST, não `snapshot.n/walls/units/markers`.
`MOVE_VISUAL_TEST` é recusado: não existem coordenadas autoritativas homologadas
nesse mock. Portanto esta versão elimina o bloqueio servidor/recibo, mas **não**
prova plug-in direto sem adaptação no room-v2-adapter.js oficial.

### Integração com RUN-013 / PESQ-015: prova versus dependência

As seções RUN-013, PESQ-INOV-20261023-015 e a auditoria da Coordenação foram lidas
no [Laboratório existente](https://app.notion.com/p/401c2b324ede809585d3d1907c194df9).
Busca no Drive por TEST36 e PESQ não retornou os ZIPs; os IDs citados são Library,
não Sediment ou arquivos baixáveis pelo conector disponível. Foi solicitada uma
URL Drive enquanto o P0 avançava. Sem esses bytes não alegar leitura literal,
execução de suas suítes ou compatibilidade de todos os campos externos.

Comprovado aqui: transporte dos conceitos documentados JOIN/INTENT/ACK/query/resync,
recibo real do backend SQLite, autorização fixture e fronteira tática bloqueada.
Pendente: conferir namespace, envelopes, callbacks do transportFactory, nomes
de campos e projeção de mapa nos arquivos originais TEST36/PESQ015. Essa deve ser
adaptação pequena no contrato único escolhido pelo responsável, não outro servidor.
O journal existente do TEST36 continua dono das intenções pendentes do navegador.
Nenhum arquivo do Desenvolvedor foi editado, reimplementado ou incluído no pacote.

## Primeira solicitação tática e primeira dependência mecânica

O SubmitV2 permite alternativamente `action`, sem `effect`:

```json
{"schema_version":2,"op":"submit","room_id":"demo","client_action_id":"attack-id","expected_revision":1,"actor_id":"actor-1","action":{"kind":"ATTACK_REQUEST","target":{"kind":"UNIT","actor_id":"actor-2"},"turn_id":"turn-test-1","context":{"scene_id":"scene-test-1","ability_id":"basic-attack"}}}
```

Também se aceita um alvo de transporte `AREA` com x/y 0–19 e radius 0–4.
Esses são apenas tetos de serialização, **não regras de alcance, área ou mapa**.
Scene/turn/ability são referências opacas, não iniciativa ou habilidade homologada.
O backend verifica esquema, identidade/ator e revisão. A próxima operação seria
pedir ao executor VLAB a decisão mecânica autorizada. Como não há ABI instalada,
persiste REJECTED/MECHANICS_UNAVAILABLE, sem evento, nova revisão, movimento ou
alteração de Vida/Alma/PA/dano. `mechanical_result_ref` continua null; qualquer
referência mecânica inventada é rejeitada pelo cliente/contrato.

Essa rejeição é recuperável por query após reboot. ATK, defesa, reações, turn-start
e recursos reais não são calculados. A integração futura exige ABI competente e
idempotência também no executor: uma chamada remota não fica atomicamente coberta
pela transação SQLite local. Uma só autoridade de sala coordena o transporte e
os recibos; somente VLAB determina mecânica, sem engine duplicada.

## Exemplo executável para o Desenvolvedor

```sh
mkdir -p work
python3 experiments/tabletop_vlab_bridge/authority.py --db work/integration-fresh.sqlite --port 8765
# Outro terminal, Node >=24 ou Node 22.16 com o flag abaixo:
BRIDGE_URL=http://127.0.0.1:8765/bridge node experiments/tabletop_vlab_bridge/integration_example.mjs
```

O exemplo gera três projeções, perde propositalmente uma confirmação no chamador,
reconecta por adaptador novo, consulta o mesmo ID, compara o recibo ao reenvio,
solicita ataque bloqueado e recupera sua rejeição, demonstra ator alheio e query
sem direito. Tudo usa HTTP/TCP real em localhost, um host, identidades inventadas.
Há um teste separado que fecha **a conexão do servidor após COMMIT**, mata o
processo e consulta por TCP num processo novo. Não é queda de infraestrutura remota.

Use `requestV2()` ou `RoomV2Adapter.exchange()` na fronteira do transportFactory
existente quando o contrato exato for confrontado. A biblioteca não cria journal,
não armazena token no navegador e não faz retry ou gera ID automaticamente.
Só exiba os campos validados de WELCOME/receipt; somente recibo terminal confirmado
permite sair de UNKNOWN. NOT_FOUND e erro sem recibo não limpam a intenção.

## Segurança e resistência testadas

Projeções são reconstruídas no servidor antes de serializar; recibos são mínimos
e escopados à identidade derivada do token. ACL de ator não depende do papel
escolhido pelo cliente. DEMO é uma fixture, não login ou membership de produção.
Todos os perfis sintéticos continuam membros das salas de teste; auth por sala,
convites, sessões/epoch e revogação reais permanecem HOLD.

Canários em objetos/listas/campos adicionais, registros adulterados, IDs trocados,
revisões concorrentes, falhas INSERT/antes COMMIT, perda pós COMMIT e resposta
excessiva têm testes. Digest de recibo detecta corrupção acidental; não é MAC nem
defesa contra um administrador que possa reescrever banco e digest juntos. Mesmo
com digest recalculado, contêineres/campos desconhecidos são recusados por DTO.
Erros não ecoam pedido, traces ou estado privado. Nenhum SQLite entra no ZIP.

## Dependências e viabilidade, sem deploy

Separação física: `receipt_contract.py` usa apenas json/hashlib/re, sem banco,
sockets ou threads; é candidato portátil testado em CPython. `authority.py` mantém
SQLite por arquivo, BEGIN/PRAGMA, ThreadingHTTPServer e CLI local. O cliente usa
fetch/URL/AbortController/TypedArrays e TypeScript somente em desenvolvimento.
`runtime-dependencies.json` registra os imports e probes realmente executados.

Não foram encontrados wrangler, miniflare, workerd, vitest ou pool Workers no
ambiente. **0 testes Cloudflare/DO**, sem instalação dessas ferramentas, conta,
deploy, cobrança ou backend remoto. A presença de Python Workers não implica
threads/SQLite CPython persistentes: adaptar fetch, storage/transactionSync, ciclo
de sessão, WSS e recuperação; filesystem efêmero não serve como durabilidade.
Fontes de referência já consultadas: [Python stdlib](https://developers.cloudflare.com/workers/languages/python/stdlib/),
[DO SQLite](https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/).
Não se declara medição ou limite atual de conta Cloudflare nesta execução.

Parecer A: manter Python mecânico e executor existente, com um owner de sala e
contrato/recibos definidos, primeiro integração local/LAN TEST autorizada. Host
permanente grátis, TLS e disponibilidade Android ainda não demonstrados. DO é
opção futura de sala/transporte após teste do runtime; portar toda a engine é
desnecessário e aumenta divergência. Nesta rodada custo adicional de serviços R$0.

## Runtimes e testes reproduzíveis

Python 3.12.14 e Node 24.19.0 foram usados aqui; o backend requer Python 3.11+.
Node 22.16.0 foi materializado de release oficial com SHA conferido, apenas em work/,
e os 38 testes Node por HTTP passaram também com:

```sh
NODE_OPTIONS=--experimental-strip-types python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/integration-results
```

Com Node >=24.12 o flag não é necessário. Node 22 exige flag para executar .ts;
sem ele, ERR_UNKNOWN_FILE_EXTENSION é requisito de runtime, não decisão mecânica.
TypeScript strict e `erasableSyntaxOnly` verificam a fronteira de tipos/sintaxe.

```sh
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund
python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/integration-results
python3 -m unittest discover -s tests -v
```

Contagens finais, comandos completos e hashes ficam em receipt.json/logs do pacote.
Node é executado dentro de testes Python; não somar como testes Python distintos.
Não foram reexecutadas suítes de outros executores, VLAB nem Android físico.

`VLAB_SOURCE_NOT_AVAILABLE`, `PYTHON_TS_EQUIVALENCE_NOT_TESTED`,
`ANDROID_REAL_NOT_TESTED`, `VLAB_PRODUCTION_HOLD` preservados; GH-NOT-RUN.
LAST: recibo persistente/projeção/matriz/ataque bloqueado demonstrados no HTTP local.
FIRST-PENDING: bytes/contrato exato TEST36/PESQ015 e projeção de mapa competente.
NEXT: adaptar a fronteira existente com recibos reais e então gates auth/WSS/Android
e ABI VLAB. NO-REPEAT: outbox TEST36, POC original, engine, editor/FOV/HUD, pesquisas
encerradas e antigo bloqueio de entrega Drive. Gate proporcional TEST local apenas.
