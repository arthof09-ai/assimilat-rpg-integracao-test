import test from 'node:test';
import assert from 'node:assert/strict';
import { BridgeClient, TransportUnknown, present, MODE } from './client.ts';

const url = process.env.BRIDGE_URL;
const master = new BridgeClient(url, 'FAKE_TEST_MASTER', 'master');
const p1 = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1');
const p2 = new BridgeClient(url, 'FAKE_TEST_PLAYER2', 'player2');
const base = (op, extra = {}) => ({ schema_version: 1, op, room_id: 'wire', ...extra });
const cmd = (id, rev, actor = 'actor-1', label = 'Wire label') => base('submit', {
  client_action_id: id, expected_revision: rev, actor_id: actor,
  effect: { kind: 'FAKE_SET_LABEL', label },
});
const view = () => base('view');
const safe = (reply, role) => {
  for (const field of ['FAKE_MASTER_ONLY', 'FAKE_MASTER_ACTOR_NOTE', 'master_note', 'private_notes',
    'head', 'journal', 'snapshot', 'fingerprint', 'checkpoint_id',
    role === 'player1' ? 'FAKE_P2_ONLY' : 'FAKE_P1_ONLY']) {
    assert(!JSON.stringify(reply).includes(field), `player payload leaked ${field}`);
  }
};
let revision = 0;

test('create, three authenticated identities and server-filtered projections', async () => {
  const created = await master.request(base('create', { client_action_id: 'create', expected_revision: 0 }));
  assert.equal(created.ok, true); assert.equal(created.op, 'create');
  const [m, one, two] = await Promise.all([master.request(view()), p1.request(view()), p2.request(view())]);
  assert.equal(m.view.master_note, 'FAKE_MASTER_ONLY');
  assert.equal(one.view.own_note, 'FAKE_P1_ONLY'); assert.equal(two.view.own_note, 'FAKE_P2_ONLY');
  safe(one, 'player1'); safe(two, 'player2');
});

test('one client serializes two intents and preserves caller-supplied revisions', async () => {
  const replies = await Promise.all([p1.request(cmd('ordered-1', 0)), p1.request(cmd('ordered-2', 1))]);
  assert.deepEqual(replies.map(x => x.revision), [1, 2]);
  assert.deepEqual(replies.map(x => x.public_event_id), ['event-1', 'event-2']); revision = 2;
});

test('two concurrent clients: exactly one accept and one STALE_REVISION', async () => {
  const replies = await Promise.all([p1.request(cmd('race-1', revision)),
    p2.request(cmd('race-2', revision, 'actor-2'))]);
  assert.equal(replies.filter(x => x.ok).length, 1);
  assert.equal(replies.find(x => !x.ok).error.code, 'STALE_REVISION'); revision++;
  replies.forEach((x, i) => safe(x, i ? 'player2' : 'player1'));
});

test('duplicate and changed-payload duplicate cannot apply a second effect', async () => {
  const first = await p1.request(cmd('unique', revision)); assert.equal(first.ok, true); revision++;
  for (const label of ['Wire label', 'Different']) {
    const repeat = await p1.request(cmd('unique', revision - 1, 'actor-1', label));
    assert.equal(repeat.error.code, 'DUPLICATE_INTENT'); safe(repeat, 'player1');
  }
  assert.equal((await p1.request(view())).revision, revision);
});

test('forbidden, malformed, unknown effect: no mutation and no private error echo', async () => {
  const attempts = [cmd('bad-owner', revision, 'actor-2'),
    { ...cmd('bad-field', revision), head: 'FAKE_MASTER_ONLY' },
    { ...cmd('unknown', revision), effect: { kind: 'DAMAGE', label: 'test' } }];
  const replies = [];
  for (const attempt of attempts) replies.push(await p1.request(attempt));
  assert.deepEqual(replies.map(x => x.error.code), ['FORBIDDEN', 'INVALID_SCHEMA', 'UNKNOWN_EFFECT']);
  replies.forEach(x => safe(x, 'player1'));
  assert.equal((await p1.request(view())).revision, revision);
});

test('checkpoint/restore and history never send the private restore snapshot to players', async () => {
  const cp = await master.request(base('checkpoint', { client_action_id: 'cp', expected_revision: revision }));
  const before = (await p1.request(view())).view;
  await p1.request(cmd('after-cp', revision, 'actor-1', 'Replaced')); revision++;
  const restored = await master.request(base('restore', { client_action_id: 'restore', expected_revision: revision,
    checkpoint_id: cp.checkpoint_id })); revision++;
  assert.equal(restored.revision, revision);
  assert.deepEqual((await p1.request(view())).view, before);
  for (const [client, role] of [[p1, 'player1'], [p2, 'player2']]) {
    const history = await client.request(base('history', { after_revision: 0 }));
    assert.equal(history.events.at(-1).kind, 'FAKE_RESTORE'); safe(history, role);
    const denied = await client.request(base('restore', { client_action_id: 'denied', expected_revision: revision,
      checkpoint_id: cp.checkpoint_id }));
    assert.equal(denied.error.code, 'FORBIDDEN'); safe(denied, role);
  }
  assert.equal((await p1.request(cmd('after-cp', revision))).error.code, 'DUPLICATE_INTENT');
});

test('lost HTTP receipt is UNKNOWN, reconnect/retry same ID applies only once', async () => {
  const lost = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, async (...args) => {
    const reply = await fetch(...args); await reply.arrayBuffer(); throw new Error('lost acknowledgement');
  });
  const original = cmd('lost-ack', revision, 'actor-1', 'Committed once');
  await assert.rejects(lost.request(original), TransportUnknown); revision++;
  const reconnect = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1');
  assert.equal((await reconnect.request(view())).revision, revision);
  const repeated = await reconnect.request(original);
  assert.equal(repeated.error.code, 'DUPLICATE_INTENT'); safe(repeated, 'player1');
});

test('failed request does not poison the serialized queue', async () => {
  const replies = await Promise.all([p1.request(cmd('stale-queue', 0)), p1.request(view())]);
  assert.equal(replies[0].error.code, 'STALE_REVISION'); assert.equal(replies[1].revision, revision);
});

test('queued intent is immutable if caller mutates original object', async () => {
  const original = cmd('capture', revision, 'actor-1', 'Captured');
  const pending = p1.request(original); original.actor_id = 'actor-2'; original.effect.label = 'Changed after enqueue';
  const reply = await pending; assert.equal(reply.ok, true); revision++;
  assert.equal(reply.view.actors.find(x => x.actor_id === 'actor-1').label, 'Captured');
});

test('presentation is text-only, with no HTML interpretation or adjudication', async () => {
  const reply = await p1.request(cmd('html', revision, 'actor-1', '<img src=x onerror=alert(1)>')); revision++;
  const target = { textContent: '' }; present(target, reply.view);
  assert.equal(target.textContent, JSON.stringify(reply.view, null, 2));
  assert.equal(reply.view.mode, MODE);
});

test('prototype keys, accessors, custom prototypes and large outbound payloads are rejected', async () => {
  for (const attack of [JSON.parse('{"__proto__":{"polluted":true}}'),
    JSON.parse('{"effect":{"constructor":{"prototype":{"polluted":true}}}}'),
    Object.create({ role: 'master' }), { get op() { throw new Error('getter invoked'); } },
    { toJSON() { throw new Error('toJSON invoked'); } },
    { ...view(), extra: 'x'.repeat(5000) }]) {
    await assert.rejects(p1.request(attack), TransportUnknown);
  }
  assert.equal({}.polluted, undefined);
});

const fake = value => async () => new Response(JSON.stringify(value), {
  status: 200, headers: { 'Content-Type': 'application/json' },
});
test('client rejects contaminated player replies, error echoes, bad versions and wrong operation', async () => {
  const valid = await p1.request(view());
  for (const polluted of [
    { ...valid, view: { ...valid.view, master_note: 'FAKE_MASTER_ONLY' } },
    { ...valid, snapshot: { secret: 'FAKE_MASTER_ONLY' } },
    { ...valid, schema_version: 2 }, { ...valid, op: 'checkpoint' },
    { schema_version: 1, op: 'error', ok: false, error: { code: 'FORBIDDEN', state: 'FAKE_MASTER_ONLY' } },
    { ...valid, view: { ...valid.view, role: 'master' } },
    JSON.parse('{"__proto__":{"polluted":true}}'),
  ]) {
    const client = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, fake(polluted));
    await assert.rejects(client.request(view()), TransportUnknown);
  }
});

test('oversized inbound response and malformed UTF-8 never reach presentation', async () => {
  for (const body of ['x'.repeat(65537), new Uint8Array([255])]) {
    const client = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, async () =>
      new Response(body, { headers: { 'Content-Type': 'application/json' } }));
    await assert.rejects(client.request(view()), TransportUnknown);
  }
});

test('timeout is UNKNOWN and queue can be used after timeout', async () => {
  let count = 0;
  const client = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 30, (...args) => {
    count++;
    if (count > 1) return fetch(...args);
    return new Promise((_, reject) => args[1].signal.addEventListener('abort', () => reject(new Error('timeout'))));
  });
  await assert.rejects(client.request(view()), TransportUnknown);
  assert.equal((await client.request(view())).revision, revision);
});

test('remote endpoints and URL credentials cannot be used by this TEST client', () => {
  for (const endpoint of ['https://example.com/bridge', 'http://127.0.0.1:1/bridge?token=x',
    'http://user:pass@127.0.0.1:1/bridge']) {
    assert.throws(() => new BridgeClient(endpoint, 'FAKE_TEST_PLAYER1', 'player1'), TransportUnknown);
  }
});
