# Parecer de evolução A/B — sem fonte VLAB real

23/10/2026. `VLAB_SOURCE_NOT_AVAILABLE`. Este parecer avalia arquitetura, não ABI
comprovada, equivalência mecânica ou versão live do VLAB. O ZIP privado R315 não
estava nas áreas diretamente disponíveis (anexos, Library, shared e inputs).
Não foi procurado no repositório público ou importado de outra operação.

| Critério | A — executor Python privado, transporte separado | B — conversão parcial futura, somente módulos autorizados |
| --- | --- | --- |
| Autoridade | Python continua dono do resultado e transação; HTTP/WSS encaminha intenção e filtra projeções | Definir um único executor por versão/sala; TS portado exige comparação com a referência Python |
| Custo | POC local já executa sem serviço novo; host permanente gratuito e disponibilidade ainda não demonstrados | Portabilidade pode reduzir processos, mas desenvolvimento e manutenção crescem; gratuidade da hospedagem real também precisa de prova |
| Dependências | CPython, SQLite e dependências reais ainda por inventariar com fonte autorizada | Compilação TS e runtime JS; módulos nativos, filesystem, SQLite e efeitos externos podem inviabilizar recorte puro |
| Android | Navegador pode consumir HTTPS/WSS; celular não precisa executar Python. Disponibilidade do host, internet móvel e retomada precisam ser medidas | Cliente continua leve; portar lógica para o navegador não autoriza revelar regras ou estado privado. Execução autoritativa deve permanecer em backend confiável |
| Cloudflare | Worker/DO pode ser transporte, mas não assumir que Python/SQLite local executará sem adaptação. Pyodide, filesystem efêmero e API SQLite de DO têm semânticas diferentes | TS é compatível com o modelo de execução Workers/DO, condicionado a APIs, limites de CPU/storage e persistência homologada |
| SQLite e falhas | Tratar lock/busy, disco cheio, perda de host, journal, migração, backup consistente e retomada com dedup. Evitar escrita dupla independente no transporte e executor | SQLite de DO/D1 não equivale a `sqlite3`/arquivo CPython. Migração de transações, ordenação e snapshots exige testes específicos |
| Divergência | Menor risco de duplicar mecânica, mas adaptador pode mapear parâmetros/recibos incorretamente | Maior risco: inteiros Python vs JS (53 bits), arredondamento, float, RNG, ordenação, null/bool, erros, serialização e versões |
| Prova necessária | Contrato real autorizado, estados/ações/erros homologados, projeções, timeout UNKNOWN, atomicidade fim a fim, crash/restart e integração Android HTTPS/WSS | Aprovação e licença por módulo; corpus diferencial congelado, testes de fronteira/propriedades e replay byte/semanticamente equivalente; bloquear qualquer divergência relevante |

**Parecer:** A é o próximo experimento condicionado ao responsável VLAB fornecer
uma interface privada aprovada e ao host gratuito ser provado. A conexão ao executor
real não foi feita. B só deve começar para módulos expressamente permitidos e
com equivalência diferencial demonstrada; não há evidência para conversão total.
As duas rotas devem manter segredos, hashes/journal e regras privadas no backend.

Os testes desta entrega comprovam transporte sintético e transações SQLite locais.
Não validam bibliotecas VLAB, comportamento mecânico, quotas Cloudflare, rede
móvel, energia do Android, cold starts de plataforma ou disponibilidade 24×7.

Referências públicas de plataforma para a próxima auditoria, sem alegar teste:

- https://developers.cloudflare.com/workers/languages/python/
- https://developers.cloudflare.com/workers/languages/python/stdlib/
- https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/
- https://www.sqlite.org/atomiccommit.html

## Governança e próxima ação

`CONTRACT_TEST_PASS` e `MOCK_TRANSPORT_PASS` só qualificam os logs locais anexados
ao recibo da execução. `PYTHON↔TS_EQUIVALENCE_NOT_TESTED`, `ANDROID_REAL_NOT_TESTED`
e `VLAB_PRODUCTION_HOLD` permanecem. Resultados antigos de GitHub não certificam
esta branch; `GH-NOT-RUN` para o POC.

A ordem atual autoriza implementação e teste local e proíbe merge/publicação.
As instruções documentais sobre diário/PR não provocam escrita automática em
Notion, Inbox ou GitHub. Leituras de contexto não conferem writer nem ACK.

FIRST-PENDING: revisão humana do contrato e das projeções desta entrega; depois,
responsável VLAB pode fornecer interface/fonte privada autorizada para um teste
local de compatibilidade. Nenhuma equivalência deve ser inferida deste mock.

Rollback: como a mudança só adiciona `experiments/tabletop_vlab_bridge/`, não
incorpore a branch para manter o comportamento anterior. Para desfazer uma futura
incorporação autorizada, reverta seu commit em outra branch de revisão; preserve
os bancos TEST e evidências antes de qualquer limpeza. Não há migração de main,
gh-pages, origens, fichas ou sistemas externos a reverter nesta entrega.
