"""Pure receipt DTO/corruption contract. No DB, sockets, threads or VLAB.

CPython-tested portable candidate; not certified on Pyodide/Cloudflare.
Digest detects accidental corruption, not a malicious database owner (no MAC).
"""
import hashlib
import json
import re

RECEIPT_KEYS = {"receipt_version", "receipt_id", "client_action_id", "status", "revision",
                "code", "public_event_id", "mechanics", "mechanical_result_ref"}
REJECTION_CODES = {"FORBIDDEN", "STALE_REVISION", "UNKNOWN_EFFECT", "LIMIT_EXCEEDED", "MECHANICS_UNAVAILABLE"}


def validate_receipt(value, action_id, max_revision=128):
    def invalid():
        raise ValueError("invalid stored receipt")
    if type(value) is not dict or set(value) != RECEIPT_KEYS:
        invalid()
    if type(value["receipt_version"]) is not int or value["receipt_version"] != 1:
        invalid()
    if type(value["receipt_id"]) is not str or not re.fullmatch(r"receipt-[0-9a-f]{32}", value["receipt_id"]):
        invalid()
    if value["client_action_id"] != action_id or type(value["revision"]) is not int or not 0 <= value["revision"] <= max_revision:
        invalid()
    if type(value["status"]) is not str or type(value["code"]) is not str:
        invalid()
    if value["mechanical_result_ref"] is not None:
        invalid()
    if value["status"] == "ACCEPTED":
        if value["revision"] < 1 or value["code"] != "APPLIED" or value["public_event_id"] != f"event-{value['revision']}" or value["mechanics"] != "NOT_REQUESTED":
            invalid()
    elif value["status"] == "REJECTED":
        if value["code"] not in REJECTION_CODES or value["public_event_id"] is not None:
            invalid()
        expected = "MECHANICS_UNAVAILABLE" if value["code"] == "MECHANICS_UNAVAILABLE" else "NOT_REQUESTED"
        if value["mechanics"] != expected:
            invalid()
    else:
        invalid()
    return {key: value[key] for key in sorted(RECEIPT_KEYS)}


def receipt_digest(room, principal, action_id, fingerprint, value):
    raw = json.dumps([room, principal, action_id, fingerprint, value], ensure_ascii=False,
                     sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()
