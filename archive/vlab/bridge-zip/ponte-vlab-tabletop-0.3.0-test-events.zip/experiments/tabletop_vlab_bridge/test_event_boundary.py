"""Real existing HTTP authority; new event-boundary tests, no substitute frontend."""
import os
import copy
import http.client
import json
import sqlite3
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import patch
from pathlib import Path

import authority as a


class EventBoundaryTests(unittest.TestCase):
    def test_event_contract_over_existing_http_authority(self):
        with tempfile.TemporaryDirectory() as temp:
            server = a.make_server(a.Authority(Path(temp) / 'boundary.sqlite'))
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                command = ['node', '--test']
                if os.environ.get('EVENT_TEST_PATTERN'):
                    command.append('--test-name-pattern=' + os.environ['EVENT_TEST_PATTERN'])
                command.append(str(Path(__file__).with_suffix('.mjs')))
                proc = subprocess.run(command, text=True, capture_output=True, timeout=60,
                    env=os.environ | {'BRIDGE_URL': f'http://127.0.0.1:{server.server_port}/bridge'})
                print(proc.stdout, end='')
                self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=5)


class BoundaryWireSecurityTests(unittest.TestCase):
    """Inspect HTTP response bytes before any TS validation/adaptation/rendering."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'wire.sqlite'
        self.authority = a.Authority(self.path)
        self.server = a.make_server(self.authority)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.stop)
        self.wire = []
        self.base = {'schema_version': 1, 'room_id': 'wire'}
        self.history = self.base | {'op': 'history', 'after_revision': 0}
        self.canary = 'FAKE_WIRE_MASTER_NESTED_CANARY'
        status, _ = self.send(self.base | {'op': 'create', 'client_action_id': 'create', 'expected_revision': 0}, 'MASTER')
        self.assertEqual(status, 200)

    def stop(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=5)

    def tearDown(self):
        if os.environ.get('BRIDGE_SECURITY_WIRE_DIR'):
            output = Path(os.environ['BRIDGE_SECURITY_WIRE_DIR'])
            output.mkdir(parents=True, exist_ok=True)
            (output / (self._testMethodName + '.json')).write_text(json.dumps({
                'scope': 'LOCAL_HTTP_RAW_BYTES_FIXTURES_ONLY_NOT_TEST37', 'wire': self.wire}, indent=2) + '\n')

    def send(self, request, role='PLAYER1'):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            connection.request('POST', '/bridge', a.encode(request), {'Content-Type': 'application/json',
                'Authorization': 'Bearer FAKE_TEST_' + role})
            response = connection.getresponse()
            raw = response.read()
            self.wire.append({'role': role, 'request': request, 'status': response.status,
                              'response_utf8': raw.decode('utf-8')})
            self.assertEqual(response.getheader('Content-Type').split(';', 1)[0].strip(), 'application/json')
            self.assertEqual(response.getheader('Cache-Control'), 'no-store')
            if role != 'MASTER':
                for marker in [self.canary, 'FAKE_MASTER_ONLY', 'FAKE_MASTER_ACTOR_NOTE',
                               'master_note', 'private_notes', 'Traceback', 'fingerprint', 'checkpoint_id',
                               'FAKE_P2_ONLY' if role == 'PLAYER1' else 'FAKE_P1_ONLY']:
                    self.assertNotIn(marker.encode(), raw)
            return response.status, raw
        finally:
            connection.close()

    def event(self, value):
        with sqlite3.connect(self.path) as db:
            db.execute('DELETE FROM events')
            db.execute('UPDATE rooms SET revision=1')
            db.execute('INSERT INTO events VALUES (?,?,?)', ('wire', 1, a.encode(value)))

    def test_restore_nested_unknown_master_metadata_omitted_before_http_bytes(self):
        state = copy.deepcopy(a.SEED)
        state['internalMasterOnly'] = {'deep': [{'value': self.canary}]}
        state['actors']['actor-1']['private_metadata'] = {'value': self.canary}
        self.event({'kind': 'FAKE_RESTORE', 'public_event_id': 'event-1', 'snapshot': state,
                    'admin_metadata': {'value': self.canary}})
        for role in ['PLAYER1', 'PLAYER2']:
            status, raw = self.send(self.history, role)
            self.assertEqual(status, 200)
            payload = json.loads(raw)
            self.assertEqual(payload['events'][0]['view']['role'], role.lower())
            self.assertEqual(set(payload['events'][0]), {'revision', 'public_event_id', 'kind', 'view'})

    def test_nested_container_in_known_event_scalars_never_leaves_http_server(self):
        for field in ['kind', 'public_event_id', 'actor_id', 'label']:
            for value in [{'master_only': self.canary}, [self.canary], None, True]:
                with self.subTest(field=field, value_type=type(value).__name__):
                    event = {'kind': 'FAKE_SET_LABEL', 'public_event_id': 'event-1',
                             'actor_id': 'actor-1', 'label': 'Synthetic'}
                    event[field] = value
                    self.event(event)
                    status, raw = self.send(self.history)
                    self.assertEqual(status, 500)
                    self.assertEqual(json.loads(raw)['error']['code'], 'INTERNAL_ERROR')

    def test_forged_admin_and_unknown_event_kinds_fail_closed_before_transmission(self):
        for kind in ['ROOM_UPDATED', 'MOVE_CONFIRMED', 'MOVE_VISUAL_TEST', 'ADMIN_RESTORE', 'FUTURE_EVENT']:
            self.event({'kind': kind, 'public_event_id': 'event-1', 'master_only': self.canary})
            status, raw = self.send(self.history)
            self.assertEqual(status, 500)
            self.assertEqual(json.loads(raw)['error']['code'], 'INTERNAL_ERROR')

    def test_payload_identity_history_override_and_administrative_alias_rejected(self):
        for extra in [{'role': 'master'}, {'participantId': 'master'},
                      {'profile': {'role': 'master', 'private': self.canary}}, {'include_private': True}]:
            self.assertEqual(self.send(self.history | extra)[0], 400)
        for op in ['checkpoint', 'restore', 'create']:
            req = self.base | {'op': op, 'client_action_id': 'admin-' + op, 'expected_revision': 0}
            if op == 'restore':
                req['checkpoint_id'] = 'cp-does-not-exist'
            self.assertEqual(self.send(req)[0], 403)
        self.assertEqual(self.send(self.history, 'UNKNOWN')[0], 403)
        self.assertEqual(self.send(self.history | {'room_id': 'missing'})[0], 403)

    def test_public_history_is_not_authorization_to_read_another_principals_receipt(self):
        submit = self.base | {'schema_version': 2, 'op': 'submit', 'client_action_id': 'owner-intent',
            'expected_revision': 0, 'actor_id': 'actor-1', 'effect': {'kind': 'FAKE_SET_LABEL', 'label': 'Public label'}}
        status, raw = self.send(submit)
        self.assertEqual(status, 200)
        original = json.loads(raw)['receipt']
        status, raw = self.send(self.history, 'PLAYER2')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)['events'][0]['public_event_id'], original['public_event_id'])
        query = {'schema_version': 2, 'op': 'receipt_query', 'room_id': 'wire', 'client_action_id': 'owner-intent'}
        status, raw = self.send(query, 'PLAYER2')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)['lookup'], 'NOT_FOUND')
        self.assertIsNone(json.loads(raw)['receipt'])
        wrong_actor = submit | {'client_action_id': 'other-unit', 'expected_revision': 1}
        status, raw = self.send(wrong_actor, 'PLAYER2')
        self.assertEqual(json.loads(raw)['receipt']['code'], 'FORBIDDEN')
        self.assertEqual(json.loads(self.send(self.history)[1])['revision'], 1)

    def test_raw_error_bytes_do_not_expose_internal_exception_or_private_state(self):
        self.event({'kind': 'FAKE_SET_LABEL', 'public_event_id': 'event-1', 'actor_id': 'actor-1', 'label': 'Safe'})
        with patch.object(a, 'public_event', side_effect=RuntimeError(self.canary)):
            status, raw = self.send(self.history)
        self.assertEqual(status, 500)
        self.assertEqual(json.loads(raw), {'schema_version': 1, 'op': 'error', 'ok': False,
                                         'error': {'code': 'INTERNAL_ERROR'}})


if __name__ == '__main__':
    unittest.main()
