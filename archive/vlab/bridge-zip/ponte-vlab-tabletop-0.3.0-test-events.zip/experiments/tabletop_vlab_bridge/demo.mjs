/** Three real TypeScript HTTP clients; only synthetic labels and fixture notes. */
import { BridgeClient } from './client.ts';
const url = process.env.BRIDGE_URL;
const master = new BridgeClient(url, 'FAKE_TEST_MASTER', 'master');
const one = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1');
const two = new BridgeClient(url, 'FAKE_TEST_PLAYER2', 'player2');
const base = op => ({ schema_version: 1, op, room_id: 'demo-projections' });
const created = await master.request({ ...base('create'), client_action_id: 'demo-create', expected_revision: 0 });
if (!created.ok) throw Error(created.error.code);
const applied = await one.request({ ...base('submit'), client_action_id: 'demo-label', expected_revision: 0,
  actor_id: 'actor-1', effect: { kind: 'FAKE_SET_LABEL', label: 'Transport OK' } });
if (!applied.ok) throw Error(applied.error.code);
const projections = {};
for (const [role, client] of [['master', master], ['player1', one], ['player2', two]]) {
  const reply = await client.request(base('view'));
  if (!reply.ok) throw Error(reply.error.code);
  projections[role] = reply;
}
console.log(JSON.stringify(projections, null, 2));
