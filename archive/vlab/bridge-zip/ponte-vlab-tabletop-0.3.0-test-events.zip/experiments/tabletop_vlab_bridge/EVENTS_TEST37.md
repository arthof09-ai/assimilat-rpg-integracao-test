# 0.3.0 — eventos tipados; integração física TEST37 ainda HOLD

## Resultado e classificação

A ponte 0.2.0 foi preservada. A nova capacidade é consultar eventos pelo
adaptador, mantendo tipo, ID e revisão, e selecionar eventos ainda não exibidos.
Backend, banco, recibos e modelo de atores não foram reimplementados.
`authority.py` e `receipt_contract.py` permanecem byte-idênticos ao commit
`c1054f9c6a4db1f7a0068ae5c8c773944ec69fbf`.

**Esta versão não comprova integração com o cliente TEST37.** O namespace
`assim.tabletop.room.bridge.test.v2` continua experimental e distinto do wire
externo. Os arquivos `room-client.js`/`room-v2-adapter.js` e a PESQ016 não estavam
materializados. Não foram fabricados cliente TEST37, envelopes completos,
correção instalada no frontend ou testes de interoperabilidade física.

O Notion canônico foi reaberto, incluindo RUN014, PESQ016, auditoria dos três
executores e a ordem POST020. A página explicitamente qualifica seus registros
como documentais, sem ZIP anexado. Drive/listagem/buscas e GitHub somente leitura
não localizaram os dois pacotes. `libfile_*` não é um ID Sediment e não pode ser
passado a `download_file`. O inventário desta instância não oferece materialização
da Biblioteca Mestre. O mínimo necessário é acesso de leitura aos **pacotes já
existentes**, por URL privada Drive ou ferramenta autorizada Library; não refazer
os pacotes. Evidência e hashes esperados: `evidence/source-access.json` no ZIP.

## Pendência própria demonstrada por RED → GREEN

Na baseline, uma consulta de eventos pelo adaptador resultava em INVALID_FRAME,
apesar de o backend já ter histórico filtrado. O teste novo falhou antes da
alteração e passou depois. Isso demonstra a falta de passagem de eventos na
ponte; **não** reproduz o RED do frontend relatado pelo Pesquisador.

O RED `ROOM_UPDATED → MOVE_CONFIRMED` continua **RELATADO por PESQ016** até que os
bytes externos possam ser executados aqui. `test37_semantic_vectors.json` entrega
fragmentos de regressão ao Desenvolvedor. Não é patch do arquivo original nem
esquema completo de wire. Nenhum arquivo do Desenvolvedor foi editado ou copiado
para o pacote desta versão.

## Extensão pequena sobre o histórico existente

Entrada pelo mesmo RoomV2Adapter (não é uma nova operação HTTP):

```json
{"schema":"assim.tabletop.room.bridge.test.v2","type":"EVENT_QUERY","roomId":"demo","afterRevision":0}
```

O adaptador solicita `schema_version:1, op:history, after_revision:0` ao mesmo
`POST /bridge`. BridgeClient valida tipos, campos exatos, identidade da sala,
projeção e sequência antes de produzir a resposta traduzida:

```json
{"schema":"assim.tabletop.room.bridge.test.v2","type":"EVENT_BATCH","roomId":"demo","afterRevision":0,"revision":1,"events":[{"type":"EVENT","roomId":"demo","revision":1,"eventId":"event-1","kind":"ROOM_UPDATED","sourceKind":"FAKE_SET_LABEL","data":{"actorId":"actor-1","label":"Synthetic"}}]}
```

`FAKE_RESTORE` também é ROOM_UPDATED, com `sourceKind:FAKE_RESTORE` e
`data.view` já projetado para quem consulta. Não são expostos checkpoint_id,
snapshot privado, fingerprint, token, ID de comando de outro emissor ou journal.
Todos os demais tipos nativos são recusados. Não há fallback de evento
desconhecido para atualização ou movimento.

Revisões/IDs referem-se exclusivamente ao journal desta sala TEST, não seq
canonizado do TEST37. EVENT_QUERY é leitura explícita do histórico; JOIN/RESYNC
continuam apenas view/snapshot atual. CREATE permanece administração separada.
Os limites existentes de corpo/resposta e os 128 eventos continuam aplicados.
Falha de capacidade/histórico requer ação explícita, sem inventar snapshot parcial.

## Seleção de eventos para apresentação

```js
import { selectNewEvents } from './room_adapter.ts';
const batch = await adapter.exchange({schema: ROOM_SCHEMA, type: 'EVENT_QUERY',
  roomId, afterRevision: displayedRevision});
const next = selectNewEvents(batch, roomId, displayedRevision, boundRole);
if (next.status === 'GAP') {
  // Obter RESYNC autorizado. Não tocar animação nem assumir resultado do comando.
} else {
  // next.events são somente atualizações genéricas. Nunca mover por esse kind.
  // Atualizar displayedRevision somente após aplicar a apresentação com sucesso.
}
```

A função é pura: não armazena estado, não cria outbox/journal, não executa retry,
não gera IDs, não confirma intenção nem interpreta mecânica. O chamador fornece
um cursor vinculado à sala e à identidade/sessão; deve descartá-lo ao mudar sessão.
`boundRole` é o papel da sessão, jamais um campo privilegiado vindo do frame.

- APPLY: somente o sufixo ainda não observado; preserva revisão/ID/tipo.
- DUPLICATE: nenhuma aplicação; nunca diminui a revisão do chamador.
- GAP: nenhum evento aplicado; exige estado autorizado antes de continuar.
- Evento desconhecido, campos extras, sequência incompleta/invertida, ID errado,
  getters, sala/papel incompatível: ProtocolError, nenhum lote aplicado.

Isto não fornece lease/epoch nem proteção contra reescrita maliciosa de todo o
banco. Não cria semântica de movimento; não existe modelo de mapa autoritativo
na baseline para aplicar MOVE_VISUAL_TEST legitimamente.

## Recibos e combate continuam independentes da apresentação

Um evento público pode aparecer para outro participante; isso não concede
acesso ao recibo privado. EVENT/ROOM_UPDATED não resolve UNKNOWN no journal do
cliente. Somente RECEIPT_QUERY do dono e recibo terminal validado o resolvem.
Ausência continua UNKNOWN; não gerar nova intenção para compensar confirmação
perdida. Não inferir execução mecânica de ACCEPTED/APPLIED: o único efeito
aplicável continua sendo um rótulo sintético de transporte.

ATTACK_REQUEST mantém a fronteira v2 existente e retorna recibo persistente
REJECTED/MECHANICS_UNAVAILABLE. Teste novo demonstra que isso não gera evento
de movimento/atualização nem avança o cursor. A revisão e o histórico permanecem
iguais, e a rejeição é recuperável por query.

ABI necessária (PROPOSTA, não homologada): entrada correlacionada por
sala + ID estável + ator autorizado + revisão + ação/alvo/turno/contexto mínimo;
saída com decisão competente, referência idempotente e dados/eventos que a sala
possa validar, persistir e projetar. O contrato atual não aceita uma referência
mecânica inventada: exige null. Uma ABI real exigirá versão/validação próprias
e reconciliação da chamada externa; SQLite não torna essa chamada atomicamente
parte da transação local. Só VLAB decide dano/PA/Vida/Alma e legalidade mecânica.

## Reprodução e provas

```sh
# Na raiz do pacote extraído/repositório; Node >=24.12, ou Node22 com flag:
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund
PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_event_boundary -v
python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/bridge-events-results
```

O teste Python usa a Authority existente e HTTP/TCP local. Uma suíte Node utiliza
BridgeClient/RoomV2Adapter reais da ponte; não o cliente externo indisponível.
Testes de corrupção inspecionam bytes HTTP antes de qualquer validação TypeScript
ou ocultação visual. A captura registra request e response sintéticos, sem token
de Authorization. MIME application/json com charset é aceito: uma asserção nova
excessivamente estrita no teste foi corrigida; isso não foi defeito do servidor.
Os denominadores finais e comandos efetivos estão em receipt.json e no PSV.

Node22 exige `NODE_OPTIONS=--experimental-strip-types`; tipo/sintaxe são checados
separadamente pelo tsc strict/erasableSyntaxOnly. Nenhuma dependência nova.
Os 41 arquivos anteriores ao experimento continuam preservados. Não é necessário
reexecutar a suíte geral desses arquivos inalterados para afirmar o novo delta.

`test37_differential.json` contém os requisitos e o próximo responsável. Campos
externos não inspecionados têm wire_value:null e testes físicos NOT_RUN, para
evitar equivalência inventada. As referências locais são do commit 0.2.0 lido;
os hashes dos arquivos atuais são dados pelo recibo e pelo manifesto.

## Gates e sucessão

G1/G2: HOLD por ausência dos bytes TEST37/PESQ016. G3: baseline de recibos
preservada; recuperação interoperável com TEST37 ainda HOLD. G4: PASS somente
fronteira proposta da ponte; correção do frontend pendente do Desenvolvedor.
G5: PASS TEST para os caminhos HTTP executados e dados sintéticos; auth real HOLD.
G6: PASS limitado ao bloqueio de transporte; VLAB/combate HOLD. G7: HOLD.
NAC-PASS-02 proporcional; nenhum gate externo é promovido pelo teste local.

Python local depende de http.server/threads/sockets/SQLite por arquivo. Durable
Objects e Python Workers têm storage/transações/ciclo de sessão próprios; o
levantamento 0.2.0 foi preservado. Nenhum novo runtime Cloudflare disponível,
0 testes WSS/DO, sem deploy, custos adicionais ou outra autoridade definitiva.

LAST-VERIFIED-UNIT: eventos identificados da autoridade existente até a fronteira
proposta, replay/gap e inspeção de bytes HTTP. FIRST-PENDING: materializar os dois
pacotes existentes e executar cliente/validadores reais. NEXT: confrontar o wire
e conectar o transporte do Desenvolvedor sem outra outbox. NO-REPEAT: 0.2.0,
recibos/SQLite, TEST37 visual/journal, PESQ016, motores e outro backend.
`FAKE_RULES_FOR_TRANSPORT_TEST`, `VLAB_SOURCE_NOT_AVAILABLE`,
`PYTHON_TS_EQUIVALENCE_NOT_TESTED`, `ANDROID_REAL_NOT_TESTED`,
`VLAB_PRODUCTION_HOLD` permanecem explícitos.
