import test, { before } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { BridgeClient, TransportUnknown } from './client.ts';
import { RoomV2Adapter, ROOM_SCHEMA, ProtocolError } from './room_adapter.ts';

const url = process.env.BRIDGE_URL;
const clients = Object.fromEntries([
  ['master', 'FAKE_TEST_MASTER'], ['player1', 'FAKE_TEST_PLAYER1'], ['player2', 'FAKE_TEST_PLAYER2'],
].map(([role, token]) => [role, new BridgeClient(url, token, role)]));
const rooms = Object.fromEntries(Object.entries(clients).map(([role, client]) => [role, new RoomV2Adapter(client)]));
const roomId = 'adapter-test';
const frame = (type, fields = {}) => ({ schema: ROOM_SCHEMA, type, roomId, ...fields });
const intent = (id = 'adapter-1', revision = 0, actorId = 'actor-1', label = 'Adapter OK') => frame('INTENT', {
  commandId: id, baseRevision: revision, actorId, action: { kind: 'FAKE_SET_LABEL', label },
});
const tactical = () => ({ kind: 'ATTACK_REQUEST', turn_id: 'turn-test-1',
  target: { kind: 'UNIT', actor_id: 'actor-2' }, context: { scene_id: 'scene-test-1', ability_id: 'basic-attack' } });
const covered = new Set();
const mark = id => covered.add(id);
let original;
function safe(value, role = 'player1') {
  const text = JSON.stringify(value);
  for (const secret of ['FAKE_MASTER_ONLY', 'FAKE_MASTER_ACTOR_NOTE', 'master_note', 'private_notes',
    'fingerprint', 'FAKE_CORRUPT_SECRET', role === 'player1' ? 'FAKE_P2_ONLY' : 'FAKE_P1_ONLY']) {
    assert(!text.includes(secret), `private bytes emitted: ${secret}`);
  }
}

before(async () => {
  const created = await clients.master.request({ schema_version: 1, op: 'create', room_id: roomId,
    client_action_id: 'adapter-create', expected_revision: 0 });
  assert.equal(created.ok, true);
});

test('join_view', async () => {
  const [m, p1, p2] = await Promise.all(Object.values(rooms).map(x => x.exchange(frame('JOIN'))));
  assert.equal(m.type, 'WELCOME'); assert.equal(p1.revision, 0);
  assert.equal(m.view.master_note, 'FAKE_MASTER_ONLY');
  assert.equal(p1.view.own_note, 'FAKE_P1_ONLY'); assert.equal(p2.view.own_note, 'FAKE_P2_ONLY');
  safe(p1); safe(p2, 'player2'); mark('join_view');
});
test('intent_label', async () => {
  original = await rooms.player1.exchange(intent());
  assert.equal(original.status, 'ACCEPTED'); assert.equal(original.receipt.revision, 1);
  assert.equal(original.commandId, original.receipt.client_action_id);
  safe(original); mark('intent_label');
});
test('receipt_query', async () => {
  const found = await rooms.player1.exchange(frame('RECEIPT_QUERY', { commandId: 'adapter-1' }));
  assert.deepEqual(found, original); mark('receipt_query');
});
test('resync_view', async () => {
  const snapshot = await rooms.player1.exchange(frame('RESYNC'));
  assert.equal(snapshot.revision, 1); assert(!('events' in snapshot));
  assert.equal(snapshot.view.actors.find(x => x.actor_id === 'actor-1').label, 'Adapter OK');
  safe(snapshot); mark('resync_view');
});
test('effect_once', async () => {
  assert.deepEqual(await rooms.player1.exchange(intent()), original);
  const history = await clients.player1.request({ schema_version: 1, op: 'history', room_id: roomId, after_revision: 0 });
  assert.equal(history.events.length, 1); mark('effect_once');
});
test('id_conflict', async () => {
  const result = await rooms.player1.exchange(intent('adapter-1', 0, 'actor-1', 'Changed ID body'));
  assert.equal(result.code, 'ID_REUSE_CONFLICT'); assert.equal(result.status, 'UNKNOWN');
  assert.deepEqual(await rooms.player1.exchange(frame('RECEIPT_QUERY', { commandId: 'adapter-1' })), original);
  safe(result); mark('id_conflict');
});
test('receipt_scope', async () => {
  const result = await rooms.player2.exchange(frame('RECEIPT_QUERY', { commandId: 'adapter-1' }));
  assert.equal(result.status, 'UNKNOWN'); assert.equal(result.code, 'NOT_FOUND'); assert.equal(result.receipt, null);
  safe(result, 'player2'); mark('receipt_scope');
});
test('missing_unknown', async () => {
  const result = await rooms.player1.exchange(frame('RECEIPT_QUERY', { commandId: 'missing' }));
  assert.equal(result.status, 'UNKNOWN'); assert.equal(result.receipt, null); mark('missing_unknown');
});
test('attack_hold', async () => {
  const before = await rooms.player1.exchange(frame('RESYNC'));
  const req = frame('INTENT', { commandId: 'attack', actorId: 'actor-1', baseRevision: 1, action: tactical() });
  const blocked = await rooms.player1.exchange(req);
  assert.equal(blocked.status, 'REJECTED'); assert.equal(blocked.code, 'MECHANICS_UNAVAILABLE');
  assert.equal(blocked.receipt.mechanical_result_ref, null); assert.equal(blocked.receipt.public_event_id, null);
  assert.deepEqual(await rooms.player1.exchange(frame('RECEIPT_QUERY', { commandId: 'attack' })), blocked);
  assert.deepEqual(await rooms.player1.exchange(frame('RESYNC')), before);
  safe(blocked); mark('attack_hold');
});
for (const [id, type] of [['create_not_join', 'CREATE'], ['checkpoint_admin', 'CHECKPOINT'], ['restore_admin', 'RESTORE']]) {
  test(id, async () => {
    for (const role of ['master', 'player1', 'player2']) {
      await assert.rejects(rooms[role].exchange(frame(type)), ProtocolError);
    }
    if (type === 'CREATE') {
      await assert.rejects(rooms.player1.exchange(frame('JOIN', { expected_revision: 0 })), ProtocolError);
      await assert.rejects(rooms.player1.exchange({ ...frame('JOIN'), roomId: 'not-created-by-join' }), ProtocolError);
      const created = await clients.master.request({ schema_version: 1, op: 'create', room_id: 'not-created-by-join',
        client_action_id: 'separate-bootstrap', expected_revision: 0 });
      assert.equal(created.ok, true);
    }
    mark(id);
  });
}
test('move_topology_hold', async () => {
  await assert.rejects(rooms.player1.exchange({ ...intent('move', 1), action: { kind: 'MOVE_VISUAL_TEST', x: 2, y: 1 } }),
    error => error instanceof ProtocolError && error.code === 'UNSUPPORTED_ACTION' && error.outcome === 'NOT_SENT');
  mark('move_topology_hold');
});
test('identity_payload', async () => {
  for (const field of ['role', 'profile', 'participantId']) {
    await assert.rejects(rooms.player1.exchange({ ...intent(), [field]: 'master' }), ProtocolError);
  }
  const denied = await rooms.player2.exchange(intent('denied-unit', 1, 'actor-1'));
  assert.equal(denied.status, 'REJECTED'); assert.equal(denied.code, 'FORBIDDEN'); safe(denied, 'player2');
  mark('identity_payload');
});
test('version_namespace', async () => {
  for (const schema of ['assim.tabletop.room.presentation.v1', 2, null]) {
    await assert.rejects(rooms.player1.exchange({ ...frame('JOIN'), schema }), ProtocolError);
  }
  mark('version_namespace');
});
test('sequence_not_inferred', async () => {
  await assert.rejects(rooms.player1.exchange({ ...intent(), seq: 1 }), ProtocolError);
  mark('sequence_not_inferred');
});
test('legacy_receipt', async () => {
  await clients.player1.request({ schema_version: 1, op: 'submit', room_id: roomId,
    client_action_id: 'legacy-only', expected_revision: 1, actor_id: 'actor-1', effect: { kind: 'FAKE_SET_LABEL', label: 'Legacy preserved' } });
  const result = await rooms.player1.exchange(frame('RECEIPT_QUERY', { commandId: 'legacy-only' }));
  assert.equal(result.status, 'UNKNOWN'); assert.equal(result.code, 'NOT_FOUND'); mark('legacy_receipt');
});
test('lost confirmation uses same ID, query through a fresh adapter', async () => {
  const lostBridge = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, async (...args) => {
    const response = await fetch(...args); await response.arrayBuffer(); throw Error('discard reply after commit');
  });
  const lost = new RoomV2Adapter(lostBridge);
  const request = intent('lost-v2', 2);
  await assert.rejects(lost.exchange(request), TransportUnknown);
  const recovered = await rooms.player1.exchange(frame('RECEIPT_QUERY', { commandId: 'lost-v2' }));
  assert.equal(recovered.status, 'ACCEPTED'); assert.equal(recovered.receipt.revision, 3);
  assert.deepEqual(await rooms.player1.exchange(request), recovered); safe(recovered);
});
test('nested request attacks fail before send without poisoning client queue', async () => {
  const poisoned = [JSON.parse('{"__proto__":{"polluted":true}}'), { ...intent(), action: { kind: 'FAKE_SET_LABEL', label: { secret: 'FAKE_CORRUPT_SECRET' } } },
    { ...intent(), action: { ...tactical(), context: { scene_id: 'scene', ability_id: 'attack', admin: { secret: true } } } },
    { ...intent(), actorId: [] }];
  for (const value of poisoned) await assert.rejects(rooms.player1.exchange(value), ProtocolError);
  assert.equal({}.polluted, undefined);
  assert.equal((await rooms.player1.exchange(frame('RESYNC'))).revision, 3);
});
test('strict receipt validation rejects contaminated replies even if frontend would hide fields', async () => {
  const base = { schema_version: 2, op: 'receipt_query', ok: true, room_id: roomId, lookup: 'FOUND', receipt: original.receipt };
  for (const receipt of [{ ...original.receipt, master_note: 'FAKE_CORRUPT_SECRET' },
    { ...original.receipt, code: { secret: 'FAKE_CORRUPT_SECRET' } },
    { ...original.receipt, mechanical_result_ref: 'invented-mechanics' },
    { ...original.receipt, client_action_id: 'wrong-id' }]) {
    const mock = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, async () => new Response(JSON.stringify({ ...base, receipt }),
      { headers: { 'Content-Type': 'application/json' } }));
    await assert.rejects(mock.requestV2({ schema_version: 2, op: 'receipt_query', room_id: roomId, client_action_id: 'adapter-1' }), TransportUnknown);
  }
});
test('server internal failure without a durable receipt remains UNKNOWN', async () => {
  const mock = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, async () => new Response(JSON.stringify({
    schema_version: 2, op: 'error', ok: false, error: { code: 'INTERNAL_ERROR' },
  }), { status: 500, headers: { 'Content-Type': 'application/json' } }));
  await assert.rejects(mock.requestV2({ schema_version: 2, op: 'receipt_query', room_id: roomId, client_action_id: 'adapter-1' }), TransportUnknown);
});
test('JavaScript callers cannot mix v1 and v2 client methods or send mismatched versions', async () => {
  let transmitted = 0;
  const guard = new BridgeClient(url, 'FAKE_TEST_PLAYER1', 'player1', 3000, async () => {
    transmitted++; throw Error('wrong version reached network');
  });
  await assert.rejects(guard.request({ schema_version: 2, op: 'receipt_query', room_id: roomId, client_action_id: 'adapter-1' }), TransportUnknown);
  await assert.rejects(guard.requestV2({ schema_version: 1, op: 'view', room_id: roomId }), TransportUnknown);
  assert.equal(transmitted, 0);
});
test('all machine-readable translation rows have executed positive or rejection cases', () => {
  const matrix = JSON.parse(readFileSync(new URL('./translation.json', import.meta.url)));
  assert.equal(matrix.room_schema, ROOM_SCHEMA);
  assert.deepEqual([...covered].sort(), matrix.mappings.map(x => x.test).sort());
  assert.equal(new Set(matrix.mappings.map(x => x.id)).size, matrix.mappings.length);
});
