/** Executable developer handoff: same authority, no UI rewrite or outbox. */
import assert from 'node:assert/strict';
import { BridgeClient, TransportUnknown } from './client.ts';
import { RoomV2Adapter, ROOM_SCHEMA } from './room_adapter.ts';

const endpoint = process.env.BRIDGE_URL;
const roomId = 'integration-handoff';
const master = new BridgeClient(endpoint, 'FAKE_TEST_MASTER', 'master');
const one = new BridgeClient(endpoint, 'FAKE_TEST_PLAYER1', 'player1');
const two = new BridgeClient(endpoint, 'FAKE_TEST_PLAYER2', 'player2');
const adapters = { master: new RoomV2Adapter(master), player1: new RoomV2Adapter(one), player2: new RoomV2Adapter(two) };
const frame = (type, fields = {}) => ({ schema: ROOM_SCHEMA, type, roomId, ...fields });
const created = await master.request({ schema_version: 1, op: 'create', room_id: roomId,
  client_action_id: 'handoff-bootstrap', expected_revision: 0 });
assert.equal(created.ok, true);
const initial = {};
for (const [role, adapter] of Object.entries(adapters)) initial[role] = await adapter.exchange(frame('JOIN'));

// Only the response is lost here; a separate Python test closes the real TCP
// connection after COMMIT, kills the OS process and reopens the persistent DB.
const lossy = new BridgeClient(endpoint, 'FAKE_TEST_PLAYER1', 'player1', 3000, async (...args) => {
  const response = await fetch(...args); await response.arrayBuffer(); throw Error('discard confirmation');
});
const original = frame('INTENT', { commandId: 'handoff-lost', actorId: 'actor-1', baseRevision: 0,
  action: { kind: 'FAKE_SET_LABEL', label: 'Persistent receipt OK' } });
await assert.rejects(new RoomV2Adapter(lossy).exchange(original), TransportUnknown);
const recovered = await adapters.player1.exchange(frame('RECEIPT_QUERY', { commandId: original.commandId }));
assert.equal(recovered.status, 'ACCEPTED');
const repeated = await adapters.player1.exchange(original);
assert.deepEqual(repeated, recovered);

const tactical = frame('INTENT', { commandId: 'handoff-attack', actorId: 'actor-1', baseRevision: 1,
  action: { kind: 'ATTACK_REQUEST', turn_id: 'turn-test-1', target: { kind: 'UNIT', actor_id: 'actor-2' },
    context: { scene_id: 'scene-test-1', ability_id: 'basic-attack' } } });
const beforeAttack = await adapters.player1.exchange(frame('RESYNC'));
const blocked = await adapters.player1.exchange(tactical);
assert.equal(blocked.status, 'REJECTED'); assert.equal(blocked.code, 'MECHANICS_UNAVAILABLE');
const blockedRecovered = await adapters.player1.exchange(frame('RECEIPT_QUERY', { commandId: tactical.commandId }));
assert.deepEqual(blockedRecovered, blocked);
assert.deepEqual(await adapters.player1.exchange(frame('RESYNC')), beforeAttack);
const denied = await adapters.player2.exchange(frame('INTENT', { commandId: 'handoff-denied', actorId: 'actor-1',
  baseRevision: 1, action: { kind: 'FAKE_SET_LABEL', label: 'not authorized' } }));
assert.equal(denied.code, 'FORBIDDEN'); assert.equal(denied.status, 'REJECTED');
const otherReceipt = await adapters.player2.exchange(frame('RECEIPT_QUERY', { commandId: original.commandId }));
assert.equal(otherReceipt.status, 'UNKNOWN'); assert.equal(otherReceipt.receipt, null);
const final = {};
for (const [role, adapter] of Object.entries(adapters)) final[role] = await adapter.exchange(frame('RESYNC'));
for (const role of ['player1', 'player2']) {
  const raw = JSON.stringify(final[role]);
  assert(!raw.includes('master_note') && !raw.includes('private_notes') && !raw.includes('FAKE_MASTER_ONLY'));
}
console.log(JSON.stringify({ mode: 'FAKE_RULES_FOR_TRANSPORT_TEST', scope: 'LOCAL_HTTP',
  scenario: 'SUBMIT_COMMIT_ACK_LOST_RECONNECT_RECEIPT_QUERY_ORIGINAL_RESULT', initial,
  requested: original, confirmationLost: 'UNKNOWN', recovered, identicalResend: repeated,
  tacticalRequested: tactical, tacticalBlocked: blocked, tacticalReceiptRecovered: blockedRecovered,
  unauthorizedActor: denied, unauthorizedReceiptQuery: otherReceipt, final,
  stateUnchangedByAttack: true, officialVlabExecuted: false }, null, 2));
