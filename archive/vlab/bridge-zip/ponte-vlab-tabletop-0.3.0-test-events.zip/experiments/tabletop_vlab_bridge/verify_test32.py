"""Optional TEST32 baseline browser checks against separately fetched PUBLIC files.

Never downloads sources, modifies gh-pages or imports the new bridge into TEST32.
Requires the pre-existing optional Playwright runtime/browser, not a project dep.
"""
import argparse
import functools
import hashlib
import json
import shutil
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

REF = "0aa9bc817844fa4ce0e16a2103a3a89988df577c"
BLOBS = {"app.js": "566666f4c6e9c98e1d3b9afa9012be2ccaff1bb5",
         "index.html": "04f9d26a8cb9206ebae909c56819dcb279051579",
         "styles.css": "6eddad8c6e296a8e216a439da9b97bf52b5412ad",
         "README.md": "bb773f25d0f9a086fc133141ba90b0dcc010db15"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    args = parser.parse_args(); args.results.mkdir(parents=True, exist_ok=True)
    verified = {}
    for name, expected in BLOBS.items():
        raw = (args.source_dir / name).read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        assert actual == expected, (name, actual)
        verified[name] = {"git_blob": actual, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    from playwright.sync_api import sync_playwright
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, *_args):
            pass
    handler = functools.partial(Quiet, directory=str(args.source_dir))
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    checks = []
    try:
        with sync_playwright() as runtime:
            browser = runtime.chromium.launch(headless=True, executable_path=shutil.which("chromium"))
            browser_version = browser.version
            context = browser.new_context(viewport={"width": 412, "height": 915}, is_mobile=True, has_touch=True)
            page = context.new_page(); errors = []; page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(f"http://127.0.0.1:{server.server_port}/", wait_until="networkidle")
            page.wait_for_function("Boolean(window.__tabletopTEST)")
            assert page.locator(".tag").inner_text().startswith("TEST 32")
            assert page.locator("#board .tile").count() == 49
            checks.append("load_49_cells")
            assert page.evaluate("__tabletopTEST.scene().units.length") == 3
            checks.append("three_synthetic_tokens")
            page.locator("#layerFov").check(); page.locator("#fovRadius").select_option("4")
            small = page.evaluate("__tabletopTEST.fovNow().length")
            page.locator("#fovRadius").select_option("8")
            large = page.evaluate("__tabletopTEST.fovNow().length")
            assert 0 < small <= large <= 49
            checks.append("fov_4_to_8")
            page.evaluate("__tabletopTEST.mode('place'); __tabletopTEST.cell(2,1)")
            assert page.evaluate("__tabletopTEST.scene().units[0].x") == 2
            checks.append("synthetic_reposition")
            page.evaluate("__tabletopTEST.capture()")
            assert page.evaluate("__tabletopTEST.validateReplay(__tabletopTEST.makeReplay())")
            checks.append("synthetic_replay_valid")
            page.locator("#save").click()
            before = page.evaluate("__tabletopTEST.state()")
            page.reload(wait_until="networkidle")
            assert page.evaluate("__tabletopTEST.state()") == before
            checks.append("save_reload_same_state")
            assert page.evaluate("__tabletopTEST.validateWorkspace(__tabletopTEST.state())")
            checks.append("workspace_valid_after_reload")
            assert not errors, errors
            checks.append("no_browser_exceptions")
            page.screenshot(path=str(args.results / "test32-mobile-emulation.png"), full_page=True)
            browser.close()
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)
    result = {"ref": REF, "files": verified, "checks": checks, "pass": len(checks), "fail": 0,
              "browser_version": browser_version,
              "scope": "Unmodified TEST32, Chromium mobile viewport emulation; no bridge injection or physical Android"}
    (args.results / "test32.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
