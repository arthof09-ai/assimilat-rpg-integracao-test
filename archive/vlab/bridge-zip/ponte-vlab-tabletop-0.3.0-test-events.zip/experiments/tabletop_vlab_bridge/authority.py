"""FAKE_RULES_FOR_TRANSPORT_TEST. Local TEST authority, NEVER a game engine.

Only a synthetic label assignment. No VLAB imports or mechanical adjudication.
SQLite commits state, ordered event and dedup receipt in ONE transaction.
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import sqlite3
import uuid
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from receipt_contract import REJECTION_CODES, receipt_digest, validate_receipt

SCHEMA_VERSION = 1
MAX_BODY = 4096
MAX_RESPONSE = 65536
MAX_EVENTS = 128
MAX_CHECKPOINTS = 16
MAX_ROOMS = 8
MAX_RECEIPTS = 512
MODE = "FAKE_RULES_FOR_TRANSPORT_TEST"
# PUBLIC, deliberately fake test identities. Not production credentials.
SESSIONS = {"FAKE_TEST_MASTER": ("master", "actor-m"),
            "FAKE_TEST_PLAYER1": ("player1", "actor-1"),
            "FAKE_TEST_PLAYER2": ("player2", "actor-2")}
SEED = {"actors": {
    "actor-m": {"label": "Synthetic M", "private_note": "FAKE_MASTER_ACTOR_NOTE"},
    "actor-1": {"label": "Synthetic P1", "private_note": "FAKE_P1_ONLY"},
    "actor-2": {"label": "Synthetic P2", "private_note": "FAKE_P2_ONLY"}},
    "master_note": "FAKE_MASTER_ONLY"}
ERROR_STATUS = {"INVALID_SCHEMA": 400, "FORBIDDEN": 403, "STALE_REVISION": 409,
                "DUPLICATE_INTENT": 409, "UNKNOWN_EFFECT": 400,
                "LIMIT_EXCEEDED": 413, "INTERNAL_ERROR": 500}
ERROR_STATUS.update(ID_REUSE_CONFLICT=409, MECHANICS_UNAVAILABLE=409)
FORBIDDEN_KEYS = {"__proto__", "prototype", "constructor"}
IDENTIFIER = re.compile(r"[A-Za-z0-9_-]{1,64}\Z", re.ASCII)


class Fault(Exception):
    def __init__(self, code: str):
        self.code = code


class ReplyLost(ConnectionError):
    """Only a server-side TEST fault hook may drop a committed reply."""


def fail(code="INVALID_SCHEMA"):
    raise Fault(code)


def exact(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        fail()


def identifier(value):
    if type(value) is not str or not IDENTIFIER.fullmatch(value):
        fail()


def integer(value):
    if type(value) is not int or not 0 <= value <= 2**31 - 1:
        fail()


def safe_tree(value, depth=0):
    if depth > 12:
        fail()
    if type(value) is dict:
        for key, child in value.items():
            if key in FORBIDDEN_KEYS:
                fail()
            safe_tree(child, depth + 1)
    elif type(value) is list:
        for child in value:
            safe_tree(child, depth + 1)


def pairs(items):
    result = {}
    for key, value in items:
        if key in result or key in FORBIDDEN_KEYS:
            fail()
        result[key] = value
    return result


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def parse(raw):
    if len(raw) > MAX_BODY:
        fail("LIMIT_EXCEEDED")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                           parse_constant=lambda _: fail())
        safe_tree(value)
        return value
    except (ValueError, UnicodeError, RecursionError):
        fail()


def validate(req):
    if type(req) is dict and type(req.get("schema_version")) is int and req["schema_version"] == 2:
        validate_v2(req)
        return
    if type(req) is not dict or req.get("schema_version") != SCHEMA_VERSION:
        fail()
    if type(req["schema_version"]) is not int:
        fail()
    op = req.get("op")
    if type(op) is not str:
        fail()
    extra = {"create": {"client_action_id", "expected_revision"}, "view": set(),
             "submit": {"client_action_id", "expected_revision", "actor_id", "effect"},
             "history": {"after_revision"},
             "checkpoint": {"client_action_id", "expected_revision"},
             "restore": {"client_action_id", "expected_revision", "checkpoint_id"}}
    if op not in extra:
        fail()
    exact(req, {"schema_version", "op", "room_id"} | extra[op])
    identifier(req["room_id"])
    for field in ("client_action_id", "actor_id", "checkpoint_id"):
        if field in req:
            identifier(req[field])
    for field in ("expected_revision", "after_revision"):
        if field in req:
            integer(req[field])
    if op == "submit":
        exact(req["effect"], {"kind", "label"})
        effect = req["effect"]
        if type(effect["kind"]) is not str:
            fail()
        if type(effect["label"]) is not str or not 1 <= len(effect["label"]) <= 80:
            fail()
        # Prevent invalid UTF-8/surrogates even when escaped in JSON.
        try:
            effect["label"].encode("utf-8")
        except UnicodeError:
            fail()
        if any(ord(c) < 32 for c in effect["label"]):
            fail()


def validate_v2(req):
    op = req.get("op")
    if type(op) is not str or op not in {"submit", "receipt_query"}:
        fail()
    fields = {"schema_version", "op", "room_id", "client_action_id"}
    if op == "submit":
        fields |= {"expected_revision", "actor_id"}
        if ("effect" in req) == ("action" in req):
            fail()
        fields.add("effect" if "effect" in req else "action")
    exact(req, fields)
    identifier(req["room_id"])
    identifier(req["client_action_id"])
    if op == "receipt_query":
        return
    integer(req["expected_revision"])
    identifier(req["actor_id"])
    if "effect" in req:
        # Reuse the exact legacy effect validator, not another implementation.
        legacy = dict(req, schema_version=1)
        validate(legacy)
        return
    action = req["action"]
    exact(action, {"kind", "target", "turn_id", "context"})
    identifier(action["kind"])
    identifier(action["turn_id"])
    exact(action["context"], {"scene_id", "ability_id"})
    identifier(action["context"]["scene_id"])
    identifier(action["context"]["ability_id"])
    target = action["target"]
    if type(target) is not dict or type(target.get("kind")) is not str:
        fail()
    if target["kind"] == "UNIT":
        exact(target, {"kind", "actor_id"})
        identifier(target["actor_id"])
    elif target["kind"] == "AREA":
        exact(target, {"kind", "x", "y", "radius"})
        for key in ("x", "y", "radius"):
            integer(target[key])
        if target["x"] > 19 or target["y"] > 19 or target["radius"] > 4:
            fail()
    else:
        fail()


def receipt_projection(value, action_id):
    return validate_receipt(value, action_id, MAX_EVENTS)


def reduce_event(state, event):
    """Private deterministic replay; never exported as a player journal."""
    result = copy.deepcopy(state)
    if event["kind"] == "FAKE_SET_LABEL":
        result["actors"][event["actor_id"]]["label"] = event["label"]
    elif event["kind"] == "FAKE_RESTORE":
        result = copy.deepcopy(event["snapshot"])
    else:
        raise ValueError("invalid private event")
    return result


def output_text(value, limit=160):
    """Reject containers in scalar DTO fields, even after backend corruption."""
    if type(value) is not str or not 1 <= len(value) <= limit:
        fail("INTERNAL_ERROR")
    try:
        value.encode("utf-8")
    except UnicodeError:
        fail("INTERNAL_ERROR")
    if any(ord(c) < 32 for c in value):
        fail("INTERNAL_ERROR")
    return value


def output_actors(state):
    if type(state) is not dict or type(state.get("actors")) is not dict:
        fail("INTERNAL_ERROR")
    actors = state["actors"]
    if set(actors) != set(SEED["actors"]) or any(type(v) is not dict for v in actors.values()):
        fail("INTERNAL_ERROR")
    return actors


def projection(state, role, actor):
    # Rebuild every nested DTO and validate scalars BEFORE serialization.
    # Extra metadata is omitted; containers replacing scalars fail closed.
    actors = output_actors(state)
    result = {"mode": MODE, "role": role, "actors": [
        {"actor_id": key, "label": output_text(actors[key]["label"], 80)}
        for key in sorted(SEED["actors"])]}
    if role == "master":
        result["master_note"] = output_text(state["master_note"])
        result["private_notes"] = {key: output_text(actors[key]["private_note"])
                                   for key in sorted(SEED["actors"])}
    else:
        result["own_actor_id"] = actor
        result["own_note"] = output_text(actors[actor]["private_note"])
    return result


def public_event(event, revision, role, actor):
    if type(event) is not dict or type(event.get("kind")) is not str:
        fail("INTERNAL_ERROR")
    if type(event.get("public_event_id")) is not str or event["public_event_id"] != f"event-{revision}":
        fail("INTERNAL_ERROR")
    result = {"revision": revision, "public_event_id": event["public_event_id"], "kind": event["kind"]}
    if event["kind"] == "FAKE_SET_LABEL":
        actor_id = event.get("actor_id")
        if type(actor_id) is not str or actor_id not in SEED["actors"]:
            fail("INTERNAL_ERROR")
        result.update(actor_id=actor_id, label=output_text(event["label"], 80))
    elif event["kind"] == "FAKE_RESTORE":
        result["view"] = projection(event["snapshot"], role, actor)
    else:
        fail("INTERNAL_ERROR")
    return result


class Authority:
    def __init__(self, database):
        self.database = str(database)
        # Independent connection per request; BEGIN IMMEDIATE also serializes
        # competing Authority instances/processes using the same SQLite file.
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS rooms (
                    room_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, state TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events (
                    room_id TEXT, revision INTEGER, data TEXT NOT NULL,
                    PRIMARY KEY(room_id, revision));
                CREATE TABLE IF NOT EXISTS intents (
                    room_id TEXT, principal TEXT, action_id TEXT, fingerprint TEXT NOT NULL,
                    PRIMARY KEY(room_id, principal, action_id));
                CREATE TABLE IF NOT EXISTS checkpoints (
                    room_id TEXT, checkpoint_id TEXT, revision INTEGER, state TEXT NOT NULL,
                    PRIMARY KEY(room_id, checkpoint_id));
                CREATE TABLE IF NOT EXISTS receipts (
                    room_id TEXT, principal TEXT, action_id TEXT, fingerprint TEXT NOT NULL,
                    receipt TEXT NOT NULL, digest TEXT NOT NULL,
                    PRIMARY KEY(room_id, principal, action_id));
            """)
            # Real cold recovery: start from a server-owned checkpoint + replay.
            db.execute("BEGIN IMMEDIATE")
            for room, revision in db.execute("SELECT room_id,revision FROM rooms").fetchall():
                state, rebuilt_revision = self.replay(db, room, True)
                if revision != rebuilt_revision:
                    raise ValueError("recovery revision mismatch")
                db.execute("UPDATE rooms SET state=? WHERE room_id=?", (encode(state), room))

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.database, timeout=5)
        try:
            db.execute("PRAGMA synchronous=FULL")
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def replay(db, room, use_checkpoint=False):
        state, revision = copy.deepcopy(SEED), 0
        if use_checkpoint:
            cp = db.execute("SELECT revision,state FROM checkpoints WHERE room_id=? "
                            "ORDER BY revision DESC LIMIT 1", (room,)).fetchone()
            if cp:
                revision, raw = cp
                state = json.loads(raw)
        for rev, raw in db.execute("SELECT revision,data FROM events WHERE room_id=? "
                                   "AND revision>? ORDER BY revision", (room, revision)):
            if rev != revision + 1:
                raise ValueError("recovery gap")
            state = reduce_event(state, json.loads(raw))
            revision = rev
        return state, revision

    def handle(self, raw, token):
        version = 1
        try:
            if token not in SESSIONS:
                fail("FORBIDDEN")
            req = parse(raw)
            if type(req) is dict and type(req.get("schema_version")) is int and req["schema_version"] == 2:
                version = 2
            validate(req)
            role, actor = SESSIONS[token]
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                result = self.dispatch_v2(db, req, role, actor) if version == 2 else self.dispatch(db, req, role, actor)
                serialized = encode(result).encode("utf-8")
                if len(serialized) > MAX_RESPONSE:
                    fail("LIMIT_EXCEEDED")
                if version == 2 and req["op"] == "submit":
                    self._fault("before_commit")
            if version == 2 and req["op"] == "submit":
                self._fault("after_commit")
            return 200, serialized
        except ReplyLost:
            raise
        except Fault as exc:
            code = exc.code
        except Exception:
            # No exception text, request echo, traceback or private state on wire.
            code = "INTERNAL_ERROR"
        return ERROR_STATUS[code], encode({"schema_version": version, "op": "error",
                                          "ok": False, "error": {"code": code}}).encode()

    def _fault(self, _point):
        """No-op in normal use; tests inject faults without client-controlled flags."""

    def load_receipt(self, db, room, role, action_id):
        row = db.execute("SELECT fingerprint,receipt,digest FROM receipts WHERE room_id=? AND principal=? AND action_id=?",
                         (room, role, action_id)).fetchone()
        if row is None:
            return None
        fingerprint, raw, digest = row
        if type(fingerprint) is not str or len(fingerprint.encode()) > MAX_BODY or type(raw) is not str or len(raw.encode()) > MAX_BODY:
            fail("INTERNAL_ERROR")
        stored = json.loads(raw, object_pairs_hook=pairs)
        if digest != receipt_digest(room, role, action_id, fingerprint, stored):
            fail("INTERNAL_ERROR")
        return fingerprint, receipt_projection(stored, action_id)

    def dispatch_v2(self, db, req, role, actor):
        room, action_id = req["room_id"], req["client_action_id"]
        row = db.execute("SELECT revision FROM rooms WHERE room_id=?", (room,)).fetchone()
        if row is None:
            fail("FORBIDDEN")
        original = self.load_receipt(db, room, role, action_id)
        result = {"schema_version": 2, "op": req["op"], "ok": True, "room_id": room}
        if req["op"] == "receipt_query":
            # Deliberately indistinguishable: missing ID versus another principal's ID.
            result.update(lookup="FOUND" if original else "NOT_FOUND", receipt=original[1] if original else None)
            return result
        fingerprint = encode(req)
        if original:
            if original[0] != fingerprint:
                fail("ID_REUSE_CONFLICT")
            result["receipt"] = original[1]
            return result
        # Never invent receipts for effects accepted by legacy v1 before migration.
        if db.execute("SELECT 1 FROM intents WHERE room_id=? AND principal=? AND action_id=?",
                      (room, role, action_id)).fetchone():
            fail("DUPLICATE_INTENT")
        if db.execute("SELECT count(*) FROM receipts WHERE room_id=?", (room,)).fetchone()[0] >= MAX_RECEIPTS:
            fail("LIMIT_EXCEEDED")
        revision, status, code, event_id = row[0], "REJECTED", None, None
        db.execute("SAVEPOINT receipt_effect")
        try:
            if "action" in req:
                if req["actor_id"] not in SEED["actors"] or (role != "master" and req["actor_id"] != actor):
                    fail("FORBIDDEN")
                if req["expected_revision"] != revision:
                    fail("STALE_REVISION")
                if req["action"]["kind"] != "ATTACK_REQUEST":
                    fail("UNKNOWN_EFFECT")
                target = req["action"]["target"]
                if target["kind"] == "UNIT" and target["actor_id"] not in SEED["actors"]:
                    fail("FORBIDDEN")
                # First mechanical operation would be the approved VLAB ABI.
                # None is installed. Never adjudicate or mutate resources here.
                fail("MECHANICS_UNAVAILABLE")
            accepted = self.dispatch(db, dict(req, schema_version=1), role, actor)
            revision, status, code = accepted["revision"], "ACCEPTED", "APPLIED"
            event_id = accepted["public_event_id"]
        except Fault as exc:
            if exc.code not in REJECTION_CODES:
                raise
            db.execute("ROLLBACK TO receipt_effect")
            code = exc.code
        finally:
            db.execute("RELEASE receipt_effect")
        receipt = {"receipt_version": 1, "receipt_id": "receipt-" + uuid.uuid4().hex,
                   "client_action_id": action_id, "status": status, "revision": revision,
                   "code": code, "public_event_id": event_id,
                   "mechanics": "MECHANICS_UNAVAILABLE" if code == "MECHANICS_UNAVAILABLE" else "NOT_REQUESTED",
                   "mechanical_result_ref": None}
        receipt = receipt_projection(receipt, action_id)
        # Rejected valid intentions are terminal too, preventing later ID reuse.
        db.execute("INSERT OR IGNORE INTO intents VALUES (?,?,?,?)", (room, role, action_id, fingerprint))
        self._fault("before_receipt_insert")
        db.execute("INSERT INTO receipts VALUES (?,?,?,?,?,?)", (room, role, action_id, fingerprint,
                   encode(receipt), receipt_digest(room, role, action_id, fingerprint, receipt)))
        result["receipt"] = receipt
        return result

    def dispatch(self, db, req, role, actor):
        op, room = req["op"], req["room_id"]
        if op in {"create", "checkpoint", "restore"} and role != "master":
            fail("FORBIDDEN")
        if op == "submit":
            if req["actor_id"] not in SEED["actors"] or (role != "master" and req["actor_id"] != actor):
                fail("FORBIDDEN")
            if req["effect"]["kind"] != "FAKE_SET_LABEL":
                fail("UNKNOWN_EFFECT")
        row = db.execute("SELECT revision,state FROM rooms WHERE room_id=?", (room,)).fetchone()
        if op != "create" and row is None:
            # Missing/unauthorized room indistinguishable; no room existence echo.
            fail("FORBIDDEN")
        revision, state = (row[0], json.loads(row[1])) if row else (0, copy.deepcopy(SEED))
        if "client_action_id" in req:
            old = db.execute("SELECT fingerprint FROM intents WHERE room_id=? AND principal=? "
                             "AND action_id=?", (room, role, req["client_action_id"])).fetchone()
            if old:
                # Same ID, same/different payload BOTH reject, never another effect.
                fail("DUPLICATE_INTENT")
            if req["expected_revision"] != revision:
                fail("STALE_REVISION")
        result = {"schema_version": SCHEMA_VERSION, "op": op, "ok": True,
                  "room_id": room, "revision": revision}
        if op == "create":
            if row:
                fail("INVALID_SCHEMA")
            if db.execute("SELECT count(*) FROM rooms").fetchone()[0] >= MAX_ROOMS:
                fail("LIMIT_EXCEEDED")
            db.execute("INSERT INTO rooms VALUES (?,?,?)", (room, 0, encode(state)))
        elif op in {"submit", "restore"}:
            if revision >= MAX_EVENTS:
                fail("LIMIT_EXCEEDED")
            if op == "restore":
                cp = db.execute("SELECT state FROM checkpoints WHERE room_id=? AND checkpoint_id=?",
                                (room, req["checkpoint_id"])).fetchone()
                if not cp:
                    fail("INVALID_SCHEMA")
                event = {"kind": "FAKE_RESTORE", "snapshot": json.loads(cp[0])}
            else:
                event = {"kind": "FAKE_SET_LABEL", "actor_id": req["actor_id"],
                         "label": req["effect"]["label"]}
            revision += 1
            event["public_event_id"] = f"event-{revision}"
            state = reduce_event(state, event)
            db.execute("INSERT INTO events VALUES (?,?,?)", (room, revision, encode(event)))
            db.execute("UPDATE rooms SET revision=?,state=? WHERE room_id=?",
                       (revision, encode(state), room))
            result.update(revision=revision, public_event_id=event["public_event_id"])
        elif op == "checkpoint":
            if db.execute("SELECT count(*) FROM checkpoints WHERE room_id=?", (room,)).fetchone()[0] >= MAX_CHECKPOINTS:
                fail("LIMIT_EXCEEDED")
            cp_id = "cp-" + uuid.uuid4().hex
            db.execute("INSERT INTO checkpoints VALUES (?,?,?,?)", (room, cp_id, revision, encode(state)))
            result["checkpoint_id"] = cp_id
        elif op == "history":
            if req["after_revision"] > revision:
                fail("STALE_REVISION")
            events = []
            for rev, raw in db.execute("SELECT revision,data FROM events WHERE room_id=? AND revision>? "
                                       "ORDER BY revision", (room, req["after_revision"])):
                event = json.loads(raw)
                # Restore history contains a role-filtered replacement projection,
                # NEVER the private restore snapshot or checkpoint identifier.
                events.append(public_event(event, rev, role, actor))
            result["events"] = events
        if "client_action_id" in req:
            db.execute("INSERT INTO intents VALUES (?,?,?,?)",
                       (room, role, req["client_action_id"], encode(req)))
            result["client_action_id"] = req["client_action_id"]
        if op != "history":
            result["view"] = projection(state, role, actor)
        return result


class LocalServer(ThreadingHTTPServer):
    daemon_threads = True


def make_server(authority, port=0):
    class Handler(BaseHTTPRequestHandler):
        # No request paths, credentials, bodies or private exceptions in logs.
        def log_message(self, *_args):
            pass

        def send_error(self, _code, _message=None, _explain=None):
            # BaseHTTPRequestHandler otherwise echoes method/path in HTML errors.
            body = encode({"schema_version": 1, "op": "error", "ok": False,
                           "error": {"code": "INVALID_SCHEMA"}}).encode()
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            def transport_error(code):
                return ERROR_STATUS[code], encode({"schema_version": 1, "op": "error", "ok": False,
                                                  "error": {"code": code}}).encode()
            self.connection.settimeout(5)
            try:
                lengths = self.headers.get_all("Content-Length", [])
                if self.path != "/bridge" or len(lengths) != 1 or self.headers.get("Transfer-Encoding"):
                    status, body = transport_error("INVALID_SCHEMA")
                elif self.headers.get("Content-Type") != "application/json":
                    status, body = transport_error("INVALID_SCHEMA")
                elif not lengths[0].isdigit() or int(lengths[0]) > MAX_BODY:
                    status, body = transport_error("LIMIT_EXCEEDED")
                elif len(self.headers.get_all("Authorization", [])) != 1:
                    status, body = transport_error("FORBIDDEN")
                else:
                    auth = self.headers["Authorization"]
                    token = auth[7:] if auth.startswith("Bearer ") else ""
                    raw = self.rfile.read(int(lengths[0]))
                    if len(raw) != int(lengths[0]):
                        status, body = transport_error("INVALID_SCHEMA")
                    else:
                        status, body = authority.handle(raw, token)
            except ReplyLost:
                self.close_connection = True
                return
            except Exception:
                status, body = transport_error("INVALID_SCHEMA")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Connection", "close")
            # Deliberately no CORS. This is loopback TEST, not Pages integration.
            self.end_headers()
            self.wfile.write(body)
    return LocalServer(("127.0.0.1", port), Handler)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=MODE)
    parser.add_argument("--db", type=Path, required=True, help="TEST SQLite path, outside sources")
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()
    server = make_server(Authority(args.db), args.port)
    print(json.dumps({"mode": MODE, "url": f"http://127.0.0.1:{server.server_port}/bridge"}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
