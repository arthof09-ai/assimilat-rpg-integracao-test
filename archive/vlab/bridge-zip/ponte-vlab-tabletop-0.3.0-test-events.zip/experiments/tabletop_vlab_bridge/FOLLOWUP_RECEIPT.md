# Recibo da continuação — ANTES → DEPOIS

23/10/2026. Mesma branch `test/tabletop-vlab-bridge-poc`, a partir de
`3f5caadfd376a63a949ca63815c0b68a0ea73a57`. Fontes originais/histórico preservados.

## ANTES confirmado

O ZIP anterior (321.284 bytes) foi verificado por SHA-256, CRC e manifesto:
`3c128ce9476fb544f913495ff8476d1b37bd3258e4638884a0db5146ea307b24`.
14 arquivos de fonte conferidos contra hashes do recibo e bytes Git;
41/41 arquivos da base preservados. Logs originais existem: 28 Python PASS,
um deles executando 15 Node PASS; TS strict PASS, 55 regressões PASS e 8 checks
TEST32 PASS. São resultados da execução original, não novos reruns nesta rodada.

Achado: projeção allowlist copiava o valor de campos permitidos sem garantir
que continuassem escalares. Um objeto aninhado adulterado diretamente no banco
podia sair por `actors[].label`, `own_note` ou campos de eventos. Também um ator
adicionado ao banco podia aparecer no roster. Não se demonstrou vetor remoto,
dados reais ou vazamento de VLAB. O cenário é corrupção local/backend deliberada.

`test_projection_security.py` foi executado **antes** da correção:
6 métodos de teste; 8 registros de falha (incluem subtests), exit 1.
O canário é `FAKE_NESTED_MASTER_CANARY`, inteiramente sintético.
Log: `evidence/continuation/security-before.log` no pacote.

## DEPOIS

`authority.py` passa a reconstruir os DTOs com validação de tipos escalares,
conjunto fixo de atores sintéticos e eventos, em projeções atuais e no histórico
de restore. Metadados extras são omitidos; corrupção em campo permitido falha
com INTERNAL_ERROR sem eco/canário. Falha na projeção após submit reverte estado,
evento e intenção dentro da transação existente. Nenhum envelope foi adicionado
ou alterado e o cliente TypeScript permaneceu byte-idêntico.

Verificação proporcional, sem repetir toda a suíte:

```sh
python3 -m unittest discover -s experiments/tabletop_vlab_bridge -p test_projection_security.py -v
PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest -v \
  test_authority.ContractTests.test_projections_distinct_server_side \
  test_authority.ContractTests.test_all_player_success_and_failure_payloads_after_restore_are_safe \
  test_authority.ContractTests.test_snapshot_plus_replay_equals_full_replay \
  test_authority.ContractTests.test_player_history_and_views_are_identical_and_safe_after_cold_restore \
  test_authority.ContractTests.test_sqlite_failure_after_event_and_state_write_is_atomic \
  test_authority.ContractTests.test_six_distinct_envelopes_and_authorized_action \
  test_authority.HttpAndTypeScriptTests.test_typescript_client_over_real_http
```

Resultado: **6 testes novos PASS, 7 regressões selecionadas PASS**, uma das sete
executa **15 testes Node PASS** por HTTP real. Não somar Node como casos Python
independentes. Logs AFTER e regressão no pacote. Cliente/tsconfig/type tests não
mudaram, então usa-se a prova estática anterior com conferência dos hashes.
55 testes legados e smoke TEST32 não foram repetidos: seus arquivos permaneceram
idênticos e esta correção não altera front-end nem código compartilhado.

## Compatibilidade e entrega

`COMPATIBILITY.md` contém matriz C/P/T e separa fonte C em bytes de evidência
documental P/T. Sem acesso aos binários Library externos, não se alega comparação
linha a linha, hash externo conferido ou teste integrado TEST34/PESQ013.

Exportação nativa continua **EXPORT_BLOCKED**: não há ferramenta de upload de
arquivo de workspace/anexo/Library oferecida a este executor. A ferramenta
`download_file` só importa uploads Sediment; não exporta. O caminho de outputs da
sessão em `/codex/browser/` não pôde ser criado por filesystem somente leitura.
Nenhum arquivo foi confirmado como baixável na interface. Caminhos /workspace
e ZIP íntegro local não são entrega ao Mestre. Não inventar botão ou link funcional.

A alternativa preparada é publicar, **somente após autorização expressa**, a
branch TEST original com código/documentos e dois arquivos de distribuição:
ZIP único e SHA-256. Sem PR/merge/deploy, sem tocar main/gh-pages. Antes de publicar,
conferir ref remota ausente ou igual ao esperado, nomes do diff e segredos; depois
fazer readback dos bytes remotos e devolver link GitHub de download fixado no SHA.
O SHA/manifesto exatos e o plano final estão nos artefatos desta continuação.

`VLAB_SOURCE_NOT_AVAILABLE`, `PYTHON_TS_EQUIVALENCE_NOT_TESTED`,
`ANDROID_REAL_NOT_TESTED`, `VLAB_PRODUCTION_HOLD`, `GH-NOT-RUN` preservados.
Não houve push/PR/merge/deploy, escrita Notion/Party/fichas ou execução de VLAB.
