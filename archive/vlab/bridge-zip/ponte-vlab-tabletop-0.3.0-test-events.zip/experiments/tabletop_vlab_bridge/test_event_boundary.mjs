/** Proposed bridge boundary; DOES NOT import or impersonate unavailable TEST37. */
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { BridgeClient, TransportUnknown } from './client.ts';
import * as room from './room_adapter.ts';

const url = process.env.BRIDGE_URL;
const roomId = 'event-boundary';
const rawWire = [];
const capturedFetch = role => async (...args) => {
  const response = await fetch(...args);
  rawWire.push({ role, request: JSON.parse(args[1].body), status: response.status,
    body: await response.clone().text() });
  return response;
};
const tokens = { master: 'FAKE_TEST_MASTER', player1: 'FAKE_TEST_PLAYER1', player2: 'FAKE_TEST_PLAYER2' };
const clients = Object.fromEntries(Object.entries(tokens).map(([role, token]) =>
  [role, new BridgeClient(url, token, role, 3000, capturedFetch(role))]));
const adapters = Object.fromEntries(Object.entries(clients).map(([role, client]) => [role, new room.RoomV2Adapter(client)]));
const frame = (type, extra = {}) => ({ schema: room.ROOM_SCHEMA, type, roomId, ...extra });
const events = (afterRevision = 0, role = 'player1') => adapters[role].exchange(frame('EVENT_QUERY', { afterRevision }));
let receipt, checkpoint;

before(async () => {
  assert.equal((await clients.master.request({ schema_version: 1, op: 'create', room_id: roomId,
    client_action_id: 'bootstrap', expected_revision: 0 })).ok, true);
  checkpoint = await clients.master.request({ schema_version: 1, op: 'checkpoint', room_id: roomId,
    client_action_id: 'checkpoint', expected_revision: 0 });
  receipt = await adapters.player1.exchange(frame('INTENT', { commandId: 'label-once', actorId: 'actor-1',
    baseRevision: 0, action: { kind: 'FAKE_SET_LABEL', label: 'Semantic boundary' } }));
});

test('new capability: typed event query preserves ROOM_UPDATED and source identity', async () => {
  const batch = await events();
  assert.equal(batch.type, 'EVENT_BATCH'); assert.equal(batch.revision, 1); assert.equal(batch.afterRevision, 0);
  assert.equal(batch.events.length, 1);
  assert.deepEqual(batch.events[0], { type: 'EVENT', roomId, eventId: 'event-1', revision: 1,
    kind: 'ROOM_UPDATED', sourceKind: 'FAKE_SET_LABEL', data: { actorId: 'actor-1', label: 'Semantic boundary' } });
  assert.equal(batch.events[0].eventId, receipt.receipt.public_event_id);
  assert(!JSON.stringify(batch).includes('MOVE_CONFIRMED'));
});

test('new capability: repeated history after reconnect preserves identity and no second effect', async () => {
  const first = await events();
  const fresh = new room.RoomV2Adapter(new BridgeClient(url, tokens.player1, 'player1'));
  assert.deepEqual(await fresh.exchange(frame('EVENT_QUERY', { afterRevision: 0 })), first);
  const queried = await fresh.exchange(frame('RECEIPT_QUERY', { commandId: 'label-once' }));
  assert.deepEqual(queried, receipt);
  assert.deepEqual(await events(1), { schema: room.ROOM_SCHEMA, type: 'EVENT_BATCH', roomId,
    afterRevision: 1, revision: 1, events: [] });
});

test('consumer applies once, discards duplicate replay and never moves its cursor backwards', async () => {
  const batch = await events();
  const next = room.selectNewEvents(batch, roomId, 0, 'player1');
  assert.equal(next.status, 'APPLY'); assert.equal(next.revision, 1); assert.equal(next.events.length, 1);
  const repeated = room.selectNewEvents(batch, roomId, 1, 'player1');
  assert.equal(repeated.status, 'DUPLICATE'); assert.deepEqual(repeated.events, []);
  const old = room.selectNewEvents(batch, roomId, 2, 'player1');
  assert.equal(old.revision, 2); assert.deepEqual(old.events, []);
});

test('consumer refuses unknown and falsely declared movement without changing caller state', async () => {
  const batch = await events();
  for (const kind of ['MOVE_CONFIRMED', 'MOVE_VISUAL_TEST', 'ADMIN_RESTORE', 'FUTURE_EVENT', null]) {
    const poisoned = structuredClone(batch); poisoned.events[0].kind = kind;
    assert.throws(() => room.selectNewEvents(poisoned, roomId, 0, 'player1'), room.ProtocolError);
  }
  const poisoned = structuredClone(batch); poisoned.events[0].sourceKind = 'MOVE_VISUAL_TEST';
  assert.throws(() => room.selectNewEvents(poisoned, roomId, 0, 'player1'), room.ProtocolError);
});

test('consumer rejects nested contamination, extra fields, getters and wrong room', async () => {
  const batch = await events();
  const bad = [];
  for (const path of ['batch', 'event', 'data']) {
    const value = structuredClone(batch);
    (path === 'batch' ? value : path === 'event' ? value.events[0] : value.events[0].data).master_only = { secret: 'FAKE_NESTED_CANARY' };
    bad.push(value);
  }
  const nested = structuredClone(batch); nested.events[0].data.label = { private: 'FAKE_NESTED_CANARY' }; bad.push(nested);
  const wrong = structuredClone(batch); wrong.events[0].roomId = 'another-room'; bad.push(wrong);
  const wrongId = structuredClone(batch); wrongId.events[0].eventId = 'event-99'; bad.push(wrongId);
  const getter = structuredClone(batch);
  Object.defineProperty(getter.events[0], 'data', { enumerable: true, get() { throw Error('getter invoked'); } });
  bad.push(getter);
  for (const value of bad) assert.throws(() => room.selectNewEvents(value, roomId, 0, 'player1'), room.ProtocolError);
});

test('unknown native event on transport fails closed, never becomes a generic update or move', async () => {
  const native = { schema_version: 1, op: 'history', ok: true, room_id: roomId, revision: 1,
    events: [{ revision: 1, public_event_id: 'event-1', kind: 'FUTURE_EVENT', master_only: 'FAKE_NESTED_CANARY' }] };
  const client = new BridgeClient(url, tokens.player1, 'player1', 3000, async () =>
    new Response(JSON.stringify(native), { headers: { 'Content-Type': 'application/json' } }));
  await assert.rejects(new room.RoomV2Adapter(client).exchange(frame('EVENT_QUERY', { afterRevision: 0 })), TransportUnknown);
});

test('restore remains a generic update with a filtered replacement, never a move or admin command', async () => {
  const restored = await clients.master.request({ schema_version: 1, op: 'restore', room_id: roomId,
    client_action_id: 'restore-once', expected_revision: 1, checkpoint_id: checkpoint.checkpoint_id });
  assert.equal(restored.revision, 2);
  for (const role of ['player1', 'player2', 'master']) {
    const batch = await events(1, role);
    assert.equal(batch.events[0].kind, 'ROOM_UPDATED'); assert.equal(batch.events[0].sourceKind, 'FAKE_RESTORE');
    assert.equal(batch.events[0].data.view.role, role);
    assert(!JSON.stringify(batch).includes('checkpoint_id'));
    assert.equal(room.selectNewEvents(batch, roomId, 1, role).status, 'APPLY');
    if (role !== 'master') {
      assert(!JSON.stringify(batch).includes('FAKE_MASTER_ONLY'));
      assert(!JSON.stringify(batch).includes('private_notes'));
    }
  }
});

test('consumer requires resync on a gap and rejects out-of-order or duplicate events within a batch', async () => {
  const tail = await events(1);
  assert.deepEqual(room.selectNewEvents(tail, roomId, 0, 'player1'), { status: 'GAP', revision: 0, events: [] });
  const batch = await events();
  const reversed = { ...batch, events: [...batch.events].reverse() };
  assert.throws(() => room.selectNewEvents(reversed, roomId, 0, 'player1'), room.ProtocolError);
  const duplicate = { ...batch, events: [batch.events[0], batch.events[0]] };
  assert.throws(() => room.selectNewEvents(duplicate, roomId, 0, 'player1'), room.ProtocolError);
  const partial = { ...batch, events: [batch.events[0]] };
  assert.throws(() => room.selectNewEvents(partial, roomId, 0, 'player1'), room.ProtocolError);
  const overlap = room.selectNewEvents(batch, roomId, 1, 'player1');
  assert.equal(overlap.status, 'APPLY'); assert.equal(overlap.events.length, 1); assert.equal(overlap.events[0].revision, 2);
});

test('restore projection bound to one recipient cannot be reused for another role', async () => {
  const master = await events(1, 'master');
  assert.throws(() => room.selectNewEvents(master, roomId, 1, 'player1'), room.ProtocolError);
  const p1 = await events(1, 'player1');
  assert.throws(() => room.selectNewEvents(p1, roomId, 1, 'player2'), room.ProtocolError);
});

test('EVENT_QUERY is read-only and rejects payload role elevation or admin/history bypass aliases', async () => {
  for (const extra of [{ role: 'master' }, { participantId: 'master' }, { profile: { role: 'master' } },
    { afterRevision: true }, { afterRevision: -1 }, { afterRevision: 129 }, { history: 'all' }]) {
    await assert.rejects(adapters.player1.exchange(frame('EVENT_QUERY', { afterRevision: 0, ...extra })), room.ProtocolError);
  }
  const batch = await events();
  assert.equal(batch.revision, 2);
  for (const type of ['CREATE', 'CHECKPOINT', 'RESTORE', 'EVENT']) {
    await assert.rejects(adapters.player1.exchange(frame(type)), room.ProtocolError);
  }
  assert.equal((await events()).revision, 2);
});

after(() => {
  const histories = rawWire.filter(x => x.request.op === 'history');
  assert(histories.length >= 8);
  for (const item of histories.filter(x => x.role !== 'master')) {
    assert.equal(item.status, 200);
    for (const secret of ['FAKE_MASTER_ONLY', 'master_note', 'private_notes', 'checkpoint_id', 'fingerprint',
      item.role === 'player1' ? 'FAKE_P2_ONLY' : 'FAKE_P1_ONLY']) assert(!item.body.includes(secret));
  }
  if (process.env.BRIDGE_EVENT_WIRE_LOG) writeFileSync(process.env.BRIDGE_EVENT_WIRE_LOG,
    JSON.stringify({ scope: 'LOCAL_HTTP_PROPOSED_BOUNDARY_NOT_TEST37', wire: rawWire }, null, 2) + '\n');
});

test('public room events do not resolve a private UNKNOWN or fabricate a command receipt', async () => {
  const batch = await events(0, 'player2');
  const projected = room.selectNewEvents(batch, roomId, 0, 'player2');
  assert.equal(projected.status, 'APPLY'); assert.equal(projected.events.length, 2);
  for (const event of projected.events) {
    assert(!('receipt' in event)); assert(!('commandId' in event)); assert(!('status' in event));
  }
  const absent = await adapters.player2.exchange(frame('RECEIPT_QUERY', { commandId: 'label-once' }));
  assert.equal(absent.status, 'UNKNOWN'); assert.equal(absent.receipt, null);
});

test('blocked tactical receipt recovers independently of the event display cursor', async () => {
  const before = await events();
  const attack = frame('INTENT', { commandId: 'blocked-boundary-attack', actorId: 'actor-1', baseRevision: 2,
    action: { kind: 'ATTACK_REQUEST', turn_id: 'turn-test-1', target: { kind: 'UNIT', actor_id: 'actor-2' },
      context: { scene_id: 'scene-test-1', ability_id: 'basic-attack' } } });
  const blocked = await adapters.player1.exchange(attack);
  assert.equal(blocked.status, 'REJECTED'); assert.equal(blocked.code, 'MECHANICS_UNAVAILABLE');
  assert.equal(blocked.receipt.public_event_id, null); assert.equal(blocked.receipt.mechanical_result_ref, null);
  assert.deepEqual(await adapters.player1.exchange(frame('RECEIPT_QUERY', { commandId: attack.commandId })), blocked);
  assert.deepEqual(await events(), before);
  assert.equal(room.selectNewEvents(before, roomId, 2, 'player1').status, 'DUPLICATE');
});
