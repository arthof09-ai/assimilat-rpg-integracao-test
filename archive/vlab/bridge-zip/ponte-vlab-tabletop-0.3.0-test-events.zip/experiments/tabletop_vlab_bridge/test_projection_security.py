"""Canaries for backend DTO filtering; no real private data or remote exploit."""
import copy
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

import authority as a

CANARY = "FAKE_NESTED_MASTER_CANARY"
BASE = {"schema_version": 1, "room_id": "projection-security"}


class ProjectionSecurityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "fixture.sqlite"
        self.engine = a.Authority(self.path)
        create = BASE | {"op": "create", "client_action_id": "create", "expected_revision": 0}
        self.assertEqual(self.call(create, "FAKE_TEST_MASTER")[0], 200)

    def call(self, req, token="FAKE_TEST_PLAYER1"):
        status, raw = self.engine.handle(a.encode(req).encode(), token)
        self.assertNotIn(CANARY.encode(), raw, "server emitted a nested master canary")
        return status, json.loads(raw)

    def poison_state(self, field):
        state = copy.deepcopy(a.SEED)
        if field == "actor":
            state["actors"][CANARY] = {"label": "Synthetic", "private_note": CANARY}
        else:
            state["actors"]["actor-1"][field] = {"text": "synthetic", "internalMasterOnly": CANARY}
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE rooms SET state=?", (a.encode(state),))

    def test_nested_label_and_note_never_leave_backend(self):
        for field in ["label", "private_note"]:
            with self.subTest(field=field):
                self.poison_state(field)
                for token in ["FAKE_TEST_PLAYER1", "FAKE_TEST_PLAYER2"]:
                    status, reply = self.call(BASE | {"op": "view"}, token)
                    # A corrupt value must fail closed, never become a nested DTO.
                    if token.endswith("PLAYER1") or field == "label":
                        self.assertEqual(status, 500)
                        self.assertEqual(reply["error"]["code"], "INTERNAL_ERROR")

    def test_unexpected_actor_never_leaks_identifier(self):
        self.poison_state("actor")
        self.assertEqual(self.call(BASE | {"op": "view"})[0], 500)

    def test_unknown_nested_metadata_is_omitted_in_valid_projection(self):
        state = copy.deepcopy(a.SEED)
        state["internalMasterOnly"] = {"value": CANARY}
        state["actors"]["actor-1"]["adminSourceId"] = CANARY
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE rooms SET state=?", (a.encode(state),))
        for token in ["FAKE_TEST_PLAYER1", "FAKE_TEST_PLAYER2"]:
            status, reply = self.call(BASE | {"op": "view"}, token)
            self.assertEqual(status, 200)
            self.assertEqual(reply["view"]["actors"][0], {"actor_id": "actor-1", "label": "Synthetic P1"})

    def test_history_valid_fields_cannot_carry_nested_objects(self):
        for field in ["label", "public_event_id", "kind", "actor_id"]:
            with self.subTest(field=field):
                event = {"kind": "FAKE_SET_LABEL", "actor_id": "actor-1", "label": "Synthetic",
                         "public_event_id": "event-1"}
                event[field] = {"internalMasterOnly": CANARY}
                with sqlite3.connect(self.path) as db:
                    db.execute("DELETE FROM events")
                    db.execute("UPDATE rooms SET revision=1")
                    db.execute("INSERT INTO events VALUES (?,?,?)", (BASE["room_id"], 1, a.encode(event)))
                status, reply = self.call(BASE | {"op": "history", "after_revision": 0})
                self.assertEqual(status, 500)
                self.assertEqual(reply["error"]["code"], "INTERNAL_ERROR")

    def test_restore_history_snapshot_is_filtered_before_wire(self):
        state = copy.deepcopy(a.SEED)
        state["actors"]["actor-1"]["adminSourceId"] = CANARY
        event = {"kind": "FAKE_RESTORE", "snapshot": state, "public_event_id": "event-1"}
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE rooms SET revision=1")
            db.execute("INSERT INTO events VALUES (?,?,?)", (BASE["room_id"], 1, a.encode(event)))
        for token in ["FAKE_TEST_PLAYER1", "FAKE_TEST_PLAYER2"]:
            self.assertEqual(self.call(BASE | {"op": "history", "after_revision": 0}, token)[0], 200)
        state["actors"]["actor-1"]["label"] = {"internalMasterOnly": CANARY}
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE events SET data=?", (a.encode(event),))
        self.assertEqual(self.call(BASE | {"op": "history", "after_revision": 0})[0], 500)

    def test_invalid_projection_after_submit_rolls_back_all_writes(self):
        self.poison_state("private_note")
        with sqlite3.connect(self.path) as db:
            before = db.execute("SELECT revision,state FROM rooms").fetchone()
            intent_count = db.execute("SELECT count(*) FROM intents").fetchone()[0]
        command = BASE | {"op": "submit", "client_action_id": "unsafe-projection", "expected_revision": 0,
                          "actor_id": "actor-1", "effect": {"kind": "FAKE_SET_LABEL", "label": "Synthetic"}}
        self.assertEqual(self.call(command)[0], 500)
        with sqlite3.connect(self.path) as db:
            self.assertEqual(db.execute("SELECT revision,state FROM rooms").fetchone(), before)
            self.assertEqual(db.execute("SELECT count(*) FROM intents").fetchone()[0], intent_count)
            self.assertEqual(db.execute("SELECT count(*) FROM events").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main()
