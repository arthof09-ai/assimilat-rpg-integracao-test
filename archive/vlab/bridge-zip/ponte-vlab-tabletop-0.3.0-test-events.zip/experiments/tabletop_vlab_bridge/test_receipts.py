"""Server-owned durable receipts. Pure TEST, no VLAB or browser outbox."""
import json
import os
import concurrent.futures
import copy
import http.client
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import authority as a


def command(action_id="receipt-1", revision=0, actor="actor-1", label="Receipt label"):
    return {"schema_version": 2, "op": "submit", "room_id": "receipts",
            "client_action_id": action_id, "expected_revision": revision, "actor_id": actor,
            "effect": {"kind": "FAKE_SET_LABEL", "label": label}}


def query(action_id="receipt-1"):
    return {"schema_version": 2, "op": "receipt_query", "room_id": "receipts",
            "client_action_id": action_id}


def attack(action_id="attack-1", revision=0, actor="actor-1"):
    req = command(action_id, revision, actor)
    del req["effect"]
    req["action"] = {"kind": "ATTACK_REQUEST", "target": {"kind": "UNIT", "actor_id": "actor-2"},
                     "turn_id": "turn-test-1", "context": {"scene_id": "scene-test-1", "ability_id": "basic-attack"}}
    return req


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "receipt.sqlite"
        self.authority = a.Authority(self.path)
        create = {"schema_version": 1, "op": "create", "room_id": "receipts",
                  "client_action_id": "create", "expected_revision": 0}
        self.assertEqual(self.call(create, "FAKE_TEST_MASTER")[0], 200)

    def call(self, request, token="FAKE_TEST_PLAYER1"):
        status, raw = self.authority.handle(a.encode(request).encode(), token)
        return status, json.loads(raw)

    def stored(self):
        with sqlite3.connect(self.path) as db:
            return {table: db.execute(f"SELECT * FROM {table} ORDER BY 1,2,3").fetchall()
                    for table in ["rooms", "events", "intents", "receipts", "checkpoints"]}

    def safe(self, reply):
        raw = a.encode(reply)
        for marker in ["FAKE_MASTER_ONLY", "FAKE_P2_ONLY", "master_note", "private_notes", "fingerprint",
                       "journal", "traceback", "FAKE_CORRUPT_SECRET"]:
            self.assertNotIn(marker, raw)

    def test_committed_result_recovered_after_ack_loss_and_cold_open(self):
        status, applied = self.call(command())
        self.assertEqual(status, 200)
        original = applied["receipt"]
        self.assertEqual(original["status"], "ACCEPTED")
        # The caller discards the response, then reopens persistence.
        self.authority = a.Authority(self.path)
        status, recovered = self.call(query())
        self.assertEqual(status, 200)
        self.assertEqual(recovered["lookup"], "FOUND")
        self.assertEqual(recovered["receipt"], original)
        self.assertEqual(self.call(command())[1]["receipt"], original)
        with sqlite3.connect(self.path) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM events").fetchone()[0], 1)

    def test_id_reuse_different_content_is_conflict_without_second_effect(self):
        self.call(command())
        status, reply = self.call(command(label="different"))
        self.assertEqual(status, 409)
        self.assertEqual(reply["error"]["code"], "ID_REUSE_CONFLICT")

    def test_other_participant_cannot_read_receipt_and_missing_is_unknown(self):
        self.call(command())
        first = self.call(query(), "FAKE_TEST_PLAYER2")
        second = self.call(query("missing"), "FAKE_TEST_PLAYER2")
        self.assertEqual(first, second)
        self.assertEqual(first[1]["lookup"], "NOT_FOUND")
        self.assertIsNone(first[1]["receipt"])

    def test_terminal_stale_rejection_is_persisted_and_never_reused(self):
        rejected = self.call(command("stale", 7))[1]["receipt"]
        self.assertEqual((rejected["status"], rejected["code"], rejected["revision"]), ("REJECTED", "STALE_REVISION", 0))
        self.call(command("advance"))
        self.assertEqual(self.call(command("stale", 7))[1]["receipt"], rejected)
        self.assertEqual(self.call(query("stale"))[1]["receipt"], rejected)
        self.assertEqual(self.call(command("stale", 1))[1]["error"]["code"], "ID_REUSE_CONFLICT")
        legacy = dict(command("stale", 1), schema_version=1)
        self.assertEqual(self.call(legacy)[1]["error"]["code"], "DUPLICATE_INTENT")

    def test_forbidden_actor_has_only_own_private_receipt(self):
        status, reply = self.call(command(actor="actor-m"))
        self.assertEqual(status, 200)
        self.assertEqual(reply["receipt"]["code"], "FORBIDDEN")
        self.safe(reply)
        self.assertEqual(self.call(query(), "FAKE_TEST_MASTER")[1]["lookup"], "NOT_FOUND")
        self.assertEqual(len(self.stored()["events"]), 0)

    def test_unknown_token_cannot_lookup_or_submit(self):
        for value in [query(), command()]:
            status, reply = self.call(value, "WRONG_TOKEN")
            self.assertEqual(status, 403)
            self.safe(reply)
        self.assertEqual(len(self.stored()["receipts"]), 0)

    def test_query_rejects_hostile_types_and_owner_override_without_writes(self):
        self.call(command())
        before = self.stored()
        attacks = [dict(query(), **{field: value}) for field, value in [
            ("principal", "master"), ("role", "master"), ("participantId", "player2"),
            ("actor_id", "actor-m"), ("client_action_id", []), ("client_action_id", {}),
            ("client_action_id", None), ("client_action_id", True), ("client_action_id", "x" * 65),
            ("room_id", {"internalMasterOnly": "FAKE_CORRUPT_SECRET"}), ("op", ["receipt_query"]),
            ("constructor", {"prototype": {"secret": "FAKE_CORRUPT_SECRET"}})]]
        for request in attacks:
            status, reply = self.call(request)
            self.assertEqual(status, 400)
            self.safe(reply)
        self.assertEqual(self.stored(), before)

    def test_corrupt_principal_binding_fails_closed_before_receipt_send(self):
        self.call(command())
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE receipts SET principal='player2'")
        status, reply = self.call(query(), "FAKE_TEST_PLAYER2")
        self.assertEqual(status, 500)
        self.safe(reply)
        self.assertEqual(self.call(query())[1]["lookup"], "NOT_FOUND")

    def test_native_v2_admin_names_never_alias_legacy_admin_operations(self):
        before = self.stored()
        for operation in ["create", "checkpoint", "restore", "JOIN", "history"]:
            request = dict(query(), op=operation)
            status, reply = self.call(request)
            self.assertEqual(status, 400)
            self.safe(reply)
        self.assertEqual(self.stored(), before)

    def test_same_id_distinct_principal_and_room_are_isolated(self):
        first = self.call(command())[1]["receipt"]
        second = self.call(command(revision=1, actor="actor-2"), "FAKE_TEST_PLAYER2")[1]["receipt"]
        self.assertNotEqual(first["receipt_id"], second["receipt_id"])
        other = dict(query(), room_id="missing")
        self.assertEqual(self.call(other)[0], 403)
        self.assertEqual(self.call(query())[1]["receipt"], first)

    def test_repeat_query_has_no_writes_and_same_result(self):
        first = self.call(command())[1]["receipt"]
        before = self.stored()
        for _ in range(3):
            self.assertEqual(self.call(query())[1]["receipt"], first)
        self.assertEqual(before, self.stored())

    def test_missing_receipt_does_not_manufacture_legacy_result(self):
        legacy = dict(command(), schema_version=1)
        self.assertEqual(self.call(legacy)[0], 200)
        self.assertEqual(self.call(query())[1]["lookup"], "NOT_FOUND")
        self.assertEqual(self.call(command())[1]["error"]["code"], "DUPLICATE_INTENT")
        self.assertEqual(len(self.stored()["events"]), 1)

    def test_two_authorities_race_one_accept_one_rejection_receipt(self):
        other = a.Authority(self.path)
        barrier = threading.Barrier(2)
        def run(i):
            barrier.wait()
            backend = [self.authority, other][i]
            status, raw = backend.handle(a.encode(command(f"race-{i}")).encode(), "FAKE_TEST_PLAYER1")
            self.assertEqual(status, 200)
            return json.loads(raw)["receipt"]
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            replies = list(pool.map(run, [0, 1]))
        self.assertEqual(sorted(x["status"] for x in replies), ["ACCEPTED", "REJECTED"])
        self.assertEqual(next(x for x in replies if x["status"] == "REJECTED")["code"], "STALE_REVISION")
        self.assertEqual(len(self.stored()["events"]), 1)
        self.assertEqual(len(self.stored()["receipts"]), 2)

    def test_concurrent_same_id_returns_identical_receipt_once(self):
        barrier = threading.Barrier(2)
        def run(_):
            barrier.wait()
            return self.call(command())
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            replies = list(pool.map(run, [0, 1]))
        self.assertEqual(replies[0], replies[1])
        self.assertEqual(len(self.stored()["events"]), 1)

    def test_fault_before_commit_and_receipt_insert_rolls_back_everything(self):
        before = self.stored()
        for point in ["before_commit", "before_receipt_insert"]:
            def inject(at):
                if at == point:
                    raise RuntimeError("FAKE_CORRUPT_SECRET")
            with patch.object(self.authority, "_fault", side_effect=inject):
                status, reply = self.call(command())
            self.assertEqual(status, 500)
            self.safe(reply)
            self.assertEqual(self.stored(), before)
            self.assertEqual(self.call(query())[1]["lookup"], "NOT_FOUND")
        self.assertEqual(self.call(command())[1]["receipt"]["status"], "ACCEPTED")

    def test_sqlite_receipt_insert_failure_rolls_back_effect(self):
        before = self.stored()
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TRIGGER refuse_receipt BEFORE INSERT ON receipts BEGIN SELECT RAISE(ABORT,'FAKE_CORRUPT_SECRET'); END")
        status, reply = self.call(command())
        self.assertEqual(status, 500)
        self.safe(reply)
        self.assertEqual(self.stored(), before)

    def test_response_limit_failure_rolls_back_effect_and_receipt(self):
        before = self.stored()
        with patch.object(a, "MAX_RESPONSE", 10):
            self.assertEqual(self.call(command())[0], 413)
        self.assertEqual(self.stored(), before)

    def test_receipts_survive_checkpoint_restore_without_revision_rollback(self):
        cp = {"schema_version": 1, "op": "checkpoint", "room_id": "receipts", "client_action_id": "cp", "expected_revision": 0}
        checkpoint = self.call(cp, "FAKE_TEST_MASTER")[1]["checkpoint_id"]
        original = self.call(command())[1]["receipt"]
        restore = dict(cp, op="restore", client_action_id="restore", expected_revision=1, checkpoint_id=checkpoint)
        self.assertEqual(self.call(restore, "FAKE_TEST_MASTER")[1]["revision"], 2)
        self.authority = a.Authority(self.path)
        self.assertEqual(self.call(query())[1]["receipt"], original)
        self.assertEqual(self.call(command())[1]["receipt"], original)
        self.assertEqual(len(self.stored()["events"]), 2)

    def test_tactical_request_reaches_mechanics_hold_and_rejection_is_recoverable(self):
        before = self.stored()
        status, reply = self.call(attack())
        self.assertEqual(status, 200)
        receipt = reply["receipt"]
        self.assertEqual((receipt["status"], receipt["code"], receipt["mechanics"]),
                         ("REJECTED", "MECHANICS_UNAVAILABLE", "MECHANICS_UNAVAILABLE"))
        self.assertIsNone(receipt["mechanical_result_ref"])
        self.assertIsNone(receipt["public_event_id"])
        self.assertEqual(self.stored()["rooms"], before["rooms"])
        self.assertEqual(self.stored()["events"], before["events"])
        self.authority = a.Authority(self.path)
        self.assertEqual(self.call(query("attack-1"))[1]["receipt"], receipt)
        self.assertEqual(self.call(attack())[1]["receipt"], receipt)
        self.safe(reply)

    def test_tactical_acl_revision_unknown_effect_and_area(self):
        for req, code in [(attack(actor="actor-2"), "FORBIDDEN"), (attack(revision=7), "STALE_REVISION")]:
            req["client_action_id"] = code
            self.assertEqual(self.call(req)[1]["receipt"]["code"], code)
        req = attack("area")
        req["action"]["target"] = {"kind": "AREA", "x": 3, "y": 2, "radius": 1}
        self.assertEqual(self.call(req)[1]["receipt"]["code"], "MECHANICS_UNAVAILABLE")
        req = attack("unsupported")
        req["action"]["kind"] = "DEFENSE_REQUEST"
        self.assertEqual(self.call(req)[1]["receipt"]["code"], "UNKNOWN_EFFECT")

    def test_schema_fields_nested_types_and_limits_do_not_reserve_ids(self):
        before = self.stored()
        values = []
        for key, value in [("role", "master"), ("participantId", "master"), ("expected_revision", True),
                           ("actor_id", []), ("schema_version", True), ("client_action_id", "x" * 65)]:
            values.append(dict(command(), **{key: value}))
        for key in ["__proto__", "constructor", "prototype"]:
            req = command(); req["effect"][key] = {"internalMasterOnly": "FAKE_CORRUPT_SECRET"}; values.append(req)
        for value in [{}, [], 4, None]:
            req = attack(); req["action"]["target"] = value; values.append(req)
        req = attack(); req["action"]["context"]["master_note"] = "FAKE_CORRUPT_SECRET"; values.append(req)
        req = attack(); req["action"]["target"] = {"kind": "AREA", "x": 20, "y": 2, "radius": 1}; values.append(req)
        for req in values:
            status, reply = self.call(req)
            self.assertEqual(status, 400)
            self.safe(reply)
        self.assertEqual(self.authority.handle(b" " * 4097, "FAKE_TEST_PLAYER1")[0], 413)
        self.assertEqual(self.stored(), before)

    def test_receipt_corruption_digest_and_scalar_allowlist_fail_closed(self):
        original = self.call(command())[1]["receipt"]
        with sqlite3.connect(self.path) as db:
            fp = db.execute("SELECT fingerprint FROM receipts").fetchone()[0]
        for field in ["code", "receipt_id", "mechanics", "public_event_id", "extra"]:
            poisoned = dict(original, **{field: {"internalMasterOnly": "FAKE_CORRUPT_SECRET"}})
            for valid_digest in [False, True]:
                digest = a.receipt_digest("receipts", "player1", "receipt-1", fp, poisoned) if valid_digest else "broken"
                with sqlite3.connect(self.path) as db:
                    db.execute("UPDATE receipts SET receipt=?,digest=?", (a.encode(poisoned), digest))
                status, reply = self.call(query())
                self.assertEqual(status, 500)
                self.safe(reply)
        # Another participant does not even read the poisoned owner's record.
        self.assertEqual(self.call(query(), "FAKE_TEST_PLAYER2")[1]["lookup"], "NOT_FOUND")

    def test_poisoned_projection_during_submit_does_not_leave_receipt(self):
        state = copy.deepcopy(a.SEED)
        state["actors"]["actor-1"]["private_note"] = {"internalMasterOnly": "FAKE_CORRUPT_SECRET"}
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE rooms SET state=?", (a.encode(state),))
        before = self.stored()
        status, reply = self.call(command())
        self.assertEqual(status, 500)
        self.safe(reply)
        self.assertEqual(self.stored(), before)

    def test_receipt_capacity_is_explicit_and_never_evicts_old_results(self):
        with patch.object(a, "MAX_RECEIPTS", 1):
            original = self.call(command())[1]["receipt"]
            self.assertEqual(self.call(command("second", 1))[0], 413)
            self.assertEqual(self.call(query())[1]["receipt"], original)

    def test_legacy_database_migration_does_not_change_legacy_data(self):
        self.call(dict(command(), schema_version=1))
        with sqlite3.connect(self.path) as db:
            db.execute("DROP TABLE receipts")
            before = {table: db.execute(f"SELECT * FROM {table}").fetchall() for table in ["rooms", "events", "intents"]}
        self.authority = a.Authority(self.path)
        with sqlite3.connect(self.path) as db:
            after = {table: db.execute(f"SELECT * FROM {table}").fetchall() for table in before}
        self.assertEqual(before, after)
        self.assertEqual(self.call(query())[1]["lookup"], "NOT_FOUND")

    def test_real_http_lost_ack_then_process_restart_and_receipt_query(self):
        here = Path(__file__).resolve().parent
        child = """import json,sys,authority
backend=authority.Authority(sys.argv[1])
def inject(point):
    if point=='after_commit': raise authority.ReplyLost()
backend._fault=inject
server=authority.make_server(backend)
print(json.dumps({'port':server.server_port}),flush=True)
server.serve_forever()
"""
        proc = subprocess.Popen([sys.executable, "-c", child, str(self.path)], cwd=here,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            line = proc.stdout.readline()
            self.assertTrue(line)
            port = json.loads(line)["port"]
            connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
            connection.request("POST", "/bridge", json.dumps(command()),
                               {"Content-Type": "application/json", "Authorization": "Bearer FAKE_TEST_PLAYER1"})
            with self.assertRaises(http.client.RemoteDisconnected):
                connection.getresponse()
            connection.close()
            with sqlite3.connect(self.path) as db:
                original = json.loads(db.execute("SELECT receipt FROM receipts").fetchone()[0])
            proc.kill(); proc.wait(timeout=5)
        finally:
            if proc.poll() is None: proc.kill(); proc.wait(timeout=5)
            proc.stdout.close(); proc.stderr.close()

        # A fresh OS process and fresh TCP connection, same durable file.
        proc = subprocess.Popen([sys.executable, str(here / "authority.py"), "--db", str(self.path)],
                                cwd=here, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            info = json.loads(proc.stdout.readline())
            port = int(info["url"].split(":")[2].split("/")[0])
            connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
            connection.request("POST", "/bridge", json.dumps(query()),
                               {"Content-Type": "application/json", "Authorization": "Bearer FAKE_TEST_PLAYER1"})
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            recovered = json.loads(response.read())["receipt"]
            self.assertEqual(recovered, original)
            self.assertEqual(recovered["status"], "ACCEPTED")
            connection.close()
        finally:
            proc.kill(); proc.wait(timeout=5)
            proc.stdout.close(); proc.stderr.close()

    def test_typed_room_adapter_and_machine_matrix_over_real_http(self):
        server = a.make_server(self.authority)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            proc = subprocess.run(["node", "--test", str(Path(__file__).with_name("test_room_adapter.mjs"))],
                env=os.environ | {"BRIDGE_URL": f"http://127.0.0.1:{server.server_port}/bridge"},
                text=True, capture_output=True, timeout=60)
            print(proc.stdout, end="")
            self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
