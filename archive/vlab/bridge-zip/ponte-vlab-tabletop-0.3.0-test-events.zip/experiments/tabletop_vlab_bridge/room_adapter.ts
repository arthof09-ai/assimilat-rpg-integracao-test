/** TEST bridge only. No outbox, game rules, topology synthesis or second server.
 * Exact TEST36 binary wire is pending; this namespace is deliberately distinct.
 */
import { BridgeClient, validateJsonTree, validatePublicHistory } from "./client.ts";
import type { ActorId, Projection, PublicEvent, Receipt, Role, SubmitV2, TacticalAction } from "./client.ts";

export const ROOM_SCHEMA = "assim.tabletop.room.bridge.test.v2" as const;
type RoomBase<T extends string> = { schema: typeof ROOM_SCHEMA; type: T; roomId: string };
export type RoomIntent = RoomBase<"INTENT"> & { commandId: string; baseRevision: number;
  actorId: ActorId; action: { kind: "FAKE_SET_LABEL"; label: string } | TacticalAction };
export type RoomQuery = RoomBase<"RECEIPT_QUERY"> & { commandId: string };
export type EventQuery = RoomBase<"EVENT_QUERY"> & { afterRevision: number };
export type RoomEvent = { type: "EVENT"; roomId: string; revision: number; eventId: string; kind: "ROOM_UPDATED" } & (
  { sourceKind: "FAKE_SET_LABEL"; data: { actorId: ActorId; label: string } } |
  { sourceKind: "FAKE_RESTORE"; data: { view: Projection } }
);
export type EventBatch = RoomBase<"EVENT_BATCH"> & { afterRevision: number; revision: number; events: RoomEvent[] };
export type RoomFrame = RoomBase<"JOIN"> | RoomBase<"RESYNC"> | RoomIntent | RoomQuery | EventQuery;
export type RoomReply =
  { schema: typeof ROOM_SCHEMA; type: "WELCOME"; roomId: string; revision: number; view: Projection } |
  { schema: typeof ROOM_SCHEMA; type: "ACK"; roomId: string; commandId: string;
    status: "ACCEPTED" | "REJECTED" | "UNKNOWN"; code: string; receipt: Receipt | null } | EventBatch;

export class ProtocolError extends Error {
  readonly outcome = "NOT_SENT";
  readonly code: "INVALID_FRAME" | "UNSUPPORTED_ACTION" | "FORBIDDEN" | "ROOM_UNAVAILABLE";
  constructor(code: "INVALID_FRAME" | "UNSUPPORTED_ACTION" | "FORBIDDEN" | "ROOM_UNAVAILABLE") {
    super(code); this.code = code;
  }
}

function requireFrame(ok: unknown): asserts ok { if (!ok) throw new ProtocolError("INVALID_FRAME"); }
function object(value: unknown): asserts value is Record<string, unknown> {
  requireFrame(value !== null && typeof value === "object" && !Array.isArray(value));
}
function fields(value: Record<string, unknown>, allowed: string[]) {
  requireFrame(Object.keys(value).sort().join(",") === [...allowed].sort().join(","));
}
function identifier(value: unknown) { requireFrame(typeof value === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(value)); }
function unsigned(value: unknown, limit: number) { requireFrame(Number.isInteger(value) && Number(value) >= 0 && Number(value) <= limit); }

export function validateFrame(value: unknown): asserts value is RoomFrame {
  try { validateJsonTree(value); } catch { throw new ProtocolError("INVALID_FRAME"); }
  object(value); requireFrame(value.schema === ROOM_SCHEMA); identifier(value.roomId);
  const base = ["schema", "type", "roomId"];
  if (value.type === "JOIN" || value.type === "RESYNC") { fields(value, base); return; }
  if (value.type === "EVENT_QUERY") {
    fields(value, [...base, "afterRevision"]); unsigned(value.afterRevision, 128); return;
  }
  if (value.type === "RECEIPT_QUERY") { fields(value, [...base, "commandId"]); identifier(value.commandId); return; }
  requireFrame(value.type === "INTENT");
  fields(value, [...base, "commandId", "baseRevision", "actorId", "action"]);
  identifier(value.commandId); unsigned(value.baseRevision, 2147483647);
  requireFrame(typeof value.actorId === "string" && ["actor-m", "actor-1", "actor-2"].includes(value.actorId));
  object(value.action);
  if (value.action.kind === "FAKE_SET_LABEL") {
    fields(value.action, ["kind", "label"]);
    requireFrame(typeof value.action.label === "string" && [...value.action.label].length >= 1 &&
      [...value.action.label].length <= 80 && !/[\x00-\x1f]/.test(value.action.label));
  } else if (value.action.kind === "ATTACK_REQUEST") {
    fields(value.action, ["kind", "target", "turn_id", "context"]);
    identifier(value.action.turn_id);
    object(value.action.context); fields(value.action.context, ["scene_id", "ability_id"]);
    identifier(value.action.context.scene_id); identifier(value.action.context.ability_id);
    object(value.action.target);
    if (value.action.target.kind === "UNIT") {
      fields(value.action.target, ["kind", "actor_id"]); identifier(value.action.target.actor_id);
    } else {
      requireFrame(value.action.target.kind === "AREA"); fields(value.action.target, ["kind", "x", "y", "radius"]);
      unsigned(value.action.target.x, 19); unsigned(value.action.target.y, 19); unsigned(value.action.target.radius, 4);
    }
  } else throw new ProtocolError("UNSUPPORTED_ACTION");
}

function eventFrame(event: PublicEvent, roomId: string): RoomEvent {
  const common = { type: "EVENT" as const, roomId, revision: event.revision,
    eventId: event.public_event_id, kind: "ROOM_UPDATED" as const };
  // Neither label assignment nor restore is movement. Preserve original kind.
  return event.kind === "FAKE_SET_LABEL" ? { ...common, sourceKind: event.kind,
    data: { actorId: event.actor_id, label: event.label } } : {
    ...common, sourceKind: event.kind, data: { view: event.view } };
}

/** Inbound display cursor ONLY: caller owns its room/session-scoped revision.
 * No command journal, receipt inference, storage, retry or authority is added.
 * Unknown/malformed frames throw; gaps require an authorized snapshot/resync.
 */
export function selectNewEvents(input: unknown, roomId: string, cursor: number, role: Role): {
  status: "APPLY" | "DUPLICATE" | "GAP"; revision: number; events: RoomEvent[];
} {
  try {
    validateJsonTree(input); identifier(roomId); unsigned(cursor, 128);
    requireFrame(["master", "player1", "player2"].includes(role));
    object(input); fields(input, ["schema", "type", "roomId", "afterRevision", "revision", "events"]);
    requireFrame(input.schema === ROOM_SCHEMA && input.type === "EVENT_BATCH" && input.roomId === roomId);
    unsigned(input.afterRevision, 128); unsigned(input.revision, 128);
    requireFrame(Array.isArray(input.events) && input.events.length <= 128);
    const nativeEvents = input.events.map((event: unknown) => {
      object(event); fields(event, ["type", "roomId", "revision", "eventId", "kind", "sourceKind", "data"]);
      requireFrame(event.type === "EVENT" && event.roomId === roomId && event.kind === "ROOM_UPDATED");
      object(event.data);
      const common = { revision: event.revision, public_event_id: event.eventId, kind: event.sourceKind };
      if (event.sourceKind === "FAKE_SET_LABEL") {
        fields(event.data, ["actorId", "label"]);
        return { ...common, actor_id: event.data.actorId, label: event.data.label };
      }
      requireFrame(event.sourceKind === "FAKE_RESTORE"); fields(event.data, ["view"]);
      return { ...common, view: event.data.view };
    });
    validatePublicHistory({ schema_version: 1, op: "history", ok: true, room_id: roomId,
      revision: input.revision, events: nativeEvents }, roomId, Number(input.afterRevision), role);
    const batch = input as EventBatch;
    if (batch.afterRevision > cursor) return { status: "GAP", revision: cursor, events: [] };
    const fresh = batch.events.filter(event => event.revision > cursor);
    // Snapshot cursor may already include all of this old response. Never rewind.
    return { status: fresh.length ? "APPLY" : "DUPLICATE", revision: Math.max(cursor, batch.revision),
      events: JSON.parse(JSON.stringify(fresh)) as RoomEvent[] };
  } catch { throw new ProtocolError("INVALID_FRAME"); }
}

export class RoomV2Adapter {
  private readonly bridge: BridgeClient;
  constructor(bridge: BridgeClient) { this.bridge = bridge; }

  async exchange(input: RoomFrame): Promise<RoomReply> {
    // Validate and capture before awaiting; a caller cannot mutate queued intent.
    validateFrame(input);
    const frame = JSON.parse(JSON.stringify(input)) as RoomFrame;
    if (frame.type === "JOIN" || frame.type === "RESYNC") {
      const reply = await this.bridge.request({ schema_version: 1, op: "view", room_id: frame.roomId });
      if (!reply.ok) throw new ProtocolError(reply.error.code === "FORBIDDEN" ? "FORBIDDEN" : "ROOM_UNAVAILABLE");
      return { schema: ROOM_SCHEMA, type: "WELCOME", roomId: frame.roomId, revision: reply.revision, view: reply.view };
    }
    if (frame.type === "EVENT_QUERY") {
      const reply = await this.bridge.request({ schema_version: 1, op: "history", room_id: frame.roomId,
        after_revision: frame.afterRevision });
      if (!reply.ok) throw new ProtocolError(reply.error.code === "FORBIDDEN" ? "FORBIDDEN" : "ROOM_UNAVAILABLE");
      return { schema: ROOM_SCHEMA, type: "EVENT_BATCH", roomId: frame.roomId,
        afterRevision: frame.afterRevision, revision: reply.revision,
        events: reply.events.map(event => eventFrame(event, frame.roomId)) };
    }
    const common = { schema_version: 2 as const, room_id: frame.roomId, client_action_id: frame.commandId };
    const request = frame.type === "RECEIPT_QUERY" ? { ...common, op: "receipt_query" as const } : {
      ...common, op: "submit" as const, actor_id: frame.actorId, expected_revision: frame.baseRevision,
      ...(frame.action.kind === "FAKE_SET_LABEL" ? { effect: frame.action } : { action: frame.action }),
    } satisfies SubmitV2;
    const reply = await this.bridge.requestV2(request);
    // Neither protocol errors nor NOT_FOUND are durable REJECTED receipts.
    if (!reply.ok) return { schema: ROOM_SCHEMA, type: "ACK", roomId: frame.roomId,
      commandId: frame.commandId, status: "UNKNOWN", code: reply.error.code, receipt: null };
    if (reply.op === "receipt_query" && reply.lookup === "NOT_FOUND") return {
      schema: ROOM_SCHEMA, type: "ACK", roomId: frame.roomId, commandId: frame.commandId,
      status: "UNKNOWN", code: "NOT_FOUND", receipt: null };
    const receipt = reply.receipt;
    if (!receipt) throw new ProtocolError("INVALID_FRAME");
    return { schema: ROOM_SCHEMA, type: "ACK", roomId: frame.roomId,
      commandId: frame.commandId, status: receipt.status, code: receipt.code, receipt };
  }
}
