import type { Submit, Reply, Request } from "./client.ts";
import type { ReceiptQuery, SubmitV2 } from "./client.ts";
import type { RoomIntent } from "./room_adapter.ts";
const good: Submit = { schema_version: 1, op: "submit", room_id: "demo", actor_id: "actor-1",
  client_action_id: "intent", expected_revision: 0, effect: { kind: "FAKE_SET_LABEL", label: "test" } };
const request: Request = good;
// Negative compile gates: these MUST remain type errors.
// @ts-expect-error No canonical mechanics in this contract
const mechanical: Submit = { ...good, effect: { kind: "DAMAGE", label: "test" } };
// @ts-expect-error Unknown top-level fields are forbidden
const elevated: Submit = { ...good, role: "master" };
// @ts-expect-error A submit must carry a revision
const missing: Submit = { schema_version: 1, op: "submit", room_id: "demo" };
function narrow(reply: Reply<"history">) {
  if (reply.ok) return reply.events;
  return reply.error.code;
}
void [request, mechanical, elevated, missing, narrow];
const receiptQuery: ReceiptQuery = { schema_version: 2, op: "receipt_query", room_id: "demo", client_action_id: "same-id" };
const tactical: SubmitV2 = { schema_version: 2, op: "submit", room_id: "demo", client_action_id: "attack-id",
  expected_revision: 0, actor_id: "actor-1", action: { kind: "ATTACK_REQUEST", turn_id: "turn-test-1",
    target: { kind: "UNIT", actor_id: "actor-2" }, context: { scene_id: "scene-test-1", ability_id: "basic-attack" } } };
// @ts-expect-error Query identity is server-bound, never payload-supplied
const queryOther: ReceiptQuery = { ...receiptQuery, participantId: "player2" };
// @ts-expect-error Admin operations are not room intentions
const admin: RoomIntent = { schema: "assim.tabletop.room.bridge.test.v2", type: "RESTORE", roomId: "demo" };
void [receiptQuery, tactical, queryOther, admin];
import type { EventQuery, RoomEvent } from "./room_adapter.ts";
const eventQuery: EventQuery = { schema: "assim.tabletop.room.bridge.test.v2", type: "EVENT_QUERY", roomId: "demo", afterRevision: 0 };
// @ts-expect-error A generic update is not movement, and topology is unavailable.
const fakeMove: RoomEvent = { type: "EVENT", roomId: "demo", revision: 1, eventId: "event-1", kind: "MOVE_CONFIRMED", sourceKind: "FAKE_SET_LABEL", data: { actorId: "actor-1", label: "test" } };
// @ts-expect-error Event queries cannot carry another principal.
const queryPrivate: EventQuery = { ...eventQuery, role: "master" };
void [eventQuery, fakeMove, queryPrivate];
