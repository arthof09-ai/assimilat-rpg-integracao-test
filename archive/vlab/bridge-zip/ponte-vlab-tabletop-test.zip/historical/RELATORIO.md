# Resultado — ponte de contrato Python ↔ TypeScript

Missão executada em 23/10/2026, TEST isolado, sem publicação. Código no mesmo
repositório autorizado, apenas em `experiments/tabletop_vlab_bridge/`.

| Evidência | Resultado |
| --- | --- |
| Branch local | `test/tabletop-vlab-bridge-poc` |
| Commit local | `3f5caadfd376a63a949ca63815c0b68a0ea73a57` |
| Base preservada | `046f6cc3d67ab6f8ae9a5c6eda6eaf03cd8d2267` |
| Diff | 14 arquivos novos, 1.615 linhas; zero arquivos existentes alterados |
| Preservação | 41/41 arquivos originais idênticos em bytes; árvore Git limpa |
| Python | 28 PASS, 0 FAIL, 0 ERROR |
| Node | 15 PASS, 0 FAIL; executados por UM dos 28 testes Python; não somar como independentes |
| TypeScript 5.9.3 | checagem estrita PASS, incluindo três casos negativos de tipagem |
| Testes existentes | 55 PASS, 0 FAIL |
| TEST32 | 8 checks PASS, 0 FAIL; Chromium 154.0.8037.57, tela/toque emulados |
| Demonstração | três clientes TypeScript HTTP reais e três projeções diferentes |
| Patch | `git apply --check` + aplicação em repositório descartável + 14 arquivos byte-idênticos PASS |

`CONTRACT_TEST_PASS` · `MOCK_TRANSPORT_PASS` · `LOCAL-TEST-PASS`.
`PYTHON↔TS_EQUIVALENCE_NOT_TESTED` · `ANDROID_REAL_NOT_TESTED` · `VLAB_PRODUCTION_HOLD`.
`VLAB_SOURCE_NOT_AVAILABLE` · `GH-NOT-RUN` para esta implementação nova.

## O que foi implementado e demonstrado

- Autoridade Python stdlib/SQLite + cliente TypeScript tipado sobre HTTP loopback.
  Único efeito: `FAKE_SET_LABEL`, sob `FAKE_RULES_FOR_TRANSPORT_TEST`.
- Seis envelopes separados `create/view/submit/history/checkpoint/restore`,
  `schema_version`, sala, ator, ID de intenção, revisão esperada e ID público de evento.
  Erros exigidos e dois erros adicionais de limite/falha interna são tipados.
- Mestre + Player1 + Player2 sintéticos. Papel vem da sessão fixture no servidor.
  Player não controla outro ator e não cria/restaura checkpoint.
- Fila serial no cliente e transação `BEGIN IMMEDIATE` no servidor. Corrida entre
  duas revisões aceita só uma; duplicatas sequenciais/simultâneas aplicam um efeito.
- Estado, evento e dedup são atômicos; falha SQLite injetada depois das primeiras
  escritas reverte toda a transação. Rejeições não reservam ID nem alteram estado.
- Recuperação por checkpoint privado + replay determinístico. Restore aumenta a
  revisão e preserva IDs consumidos. Processo real foi morto após commit com
  recibo descartado; retomada/retry manteve um único efeito.
- Projeção filtrada por allowlist no Python antes do envio. Testes verificam
  views, sucessos, erros de execução, histórico de restore e cold restart.
- Schema estrito, rejeição de campos extras/prototype pollution, JSON com chaves
  duplicadas, UTF-8 inválido, revisões inválidas e limites de corpo/resposta/estado.
  Respostas de falha não ecoam pedido, exceção ou estado privado.
- Timeout do cliente é `UNKNOWN`, nunca falsa rejeição; reconciliação e retry
  usam o mesmo ID. O hook de apresentação usa somente `textContent`.

## Comandos reais e logs

Executados no checkout `/workspace/assimilat-rpg-integracao-test`:

```sh
npm ci --prefix experiments/tabletop_vlab_bridge --ignore-scripts --no-audit --no-fund --cache /workspace/work/npm-cache
python3 experiments/tabletop_vlab_bridge/run_checks.py --results /workspace/work/bridge-poc/final
python3 -m unittest discover -s tests -v
python3 experiments/tabletop_vlab_bridge/verify_test32.py --source-dir /workspace/work/bridge-poc/test32 --results /workspace/work/bridge-poc/test32-results
git diff --cached --check
```

O runner executou `python3 -m unittest discover ... -p test_*.py -v`, que abriu
servidor real e invocou `node --test test_client.mjs`, e executou `tsc -p tsconfig.json`.
Os comandos completos, versões e hashes constam de `receipt.json`; a saída real
está em `evidence/contract.log`, `evidence/typecheck.log` (vazio, exit 0),
`evidence/legacy-tests.log` e `evidence/test32.json`. `projections.json` foi produzido
por `demo.mjs` consumindo o servidor Python, não escrito manualmente.

Na primeira tentativa sem liberação de sockets, três testes retornaram erros de
ambiente EPERM; o comando foi repetido com a capacidade de rede do runtime e passou.
O browser padrão Playwright não estava instalado; usou-se `/usr/bin/chromium`
já disponível, sem baixar outro navegador. Nenhuma dessas tentativas é relatada
como aprovação. Os números acima são da execução final.

## As três projeções

Na demonstração todos receberam revisão 1 e os mesmos três rótulos públicos,
incluindo `actor-1: Transport OK`. Campos adicionais:

| Sessão | Campos sintéticos recebidos |
| --- | --- |
| Mestre | `master_note: FAKE_MASTER_ONLY`, notas privadas dos três atores |
| Player1 | `own_actor_id: actor-1`, `own_note: FAKE_P1_ONLY` |
| Player2 | `own_actor_id: actor-2`, `own_note: FAKE_P2_ONLY` |

Esses marcadores são fixtures públicas do teste, não informações de campanha.
Players não receberam os marcadores do Mestre ou do outro player. Nenhum payload
contém `head`, journal privado ou hashes internos. Consulte os JSON completos.

## TEST32 preservado e limites da prova

`gh-pages` foi lida pelo conector, no commit
`0aa9bc817844fa4ce0e16a2103a3a89988df577c`. Seus quatro arquivos públicos foram
copiados apenas para `work/`, com cada Git blob SHA verificado. Os hashes SHA-256
e tamanhos estão em `evidence/test32.json`. Os oito checks exercitaram grade 7×7,
três tokens, FOV 4→8, reposicionamento, replay, save/reload, validação do workspace
e ausência de exceções. Captura em `evidence/test32-mobile-emulation.png`.

Não foi alterado front-end, CSP (`connect-src 'none'`), editor ou armazenamento.
O POC não foi conectado à página pública. Esse smoke não é a suíte histórica
integral nem teste de Android físico ou de rede entre dispositivos.

## Segurança, escopo e fontes

Leituras autorizadas: missão anexada, AGENTS, diretriz GH-RP-01, Diário do laboratório
e os três checkpoints indicados no Laboratório do Inovador. Nenhuma escrita Notion,
Inbox, OP VLAB, Party, fichas, fontes ou sistema canônico. O pedido atual prevaleceu
sobre rotinas documentais de PR/diário: não foi feita publicação automática.

O ZIP privado R315 não estava diretamente disponível nas áreas locais inspecionadas.
Não foi buscado no repositório público. Nenhum hash dessa fonte foi conferido e
nenhuma ABI/mecânica real ou equivalência Python↔TS foi testada. R315 não foi tomado
como estado live. O mock não importa VLAB, fontes antigas, dados de campanha ou anexos.

A varredura do diff e revisão manual dos 14 arquivos novos não encontrou padrões
de credenciais nem importações de fontes privadas. `evidence/security.json` registra
escopo e limites: isso não é certificação universal de ausência de segredos.
As únicas identidades são as fixtures `FAKE_TEST_*`. O banco permanece backend.

Foram instalados apenas TypeScript de desenvolvimento e usado Python/Node/Chromium
existentes. Nenhuma conta, serviço, faturamento, framework grande ou cloud foi criado.
Nenhuma chamada de deploy, merge, push ou criação de PR foi efetuada. As refs remotas
main/gh-pages foram relidas e continuavam nos mesmos commits. CI antiga da base não
certifica este POC; a CI nova é `GH-NOT-RUN`.

## Parecer A/B, risco e FIRST-PENDING

**A recomendado como próximo experimento condicionado:** manter executor Python
privado e adicionar adaptador HTTP/WSS com transporte separado. Reduz duplicação,
mas host gratuito/disponibilidade, bibliotecas, SQLite, timeout entre serviços e
atomicidade fim a fim ainda precisam de prova. Não assumir que Python Workers ou
SQLite de Durable Objects executam `sqlite3`/filesystem CPython sem adaptação.

**B apenas após autorização por módulo:** converter recortes homologados e comparar
com a referência Python, cobrindo inteiros/float, arredondamento, RNG, serialização,
ordenamento, erros, snapshots e persistência. Custo de manutenção e divergência é
maior. Não há evidência para conversão total. A comparação detalhada está em
`experiments/tabletop_vlab_bridge/ASSESSMENT.md` no pacote.

Limites atuais: fixtures públicas sem autenticação real/revogação/TLS; HTTP local,
sem WSS, Cloudflare ou dispositivos reais; SQLite local com falhas injetadas e
process kill, sem certificação de disco/power loss; fonte real ausente.

FIRST-PENDING: revisão humana do contrato e das projeções. Integração real exige
interface/fonte privada permitida pelo responsável VLAB e provas próprias; Android
físico e hospedagem gratuita seguem pendentes. Não há autorização de promoção.

Rollback: não incorporar a branch mantém o estado anterior. A alteração é só aditiva.
Para uma futura incorporação autorizada, reverta o commit em branch de revisão,
preservando bancos TEST/evidências. Não há migração externa a desfazer agora.

## Pacote local

`bridge.patch`, fonte, logs, recibo, projeções, screenshot e manifestos fazem parte
do ZIP local. O patch foi aplicado e comparado byte a byte em cópia descartável.
`SHA256SUMS.txt` permite verificar os membros. Nenhum banco, node_modules,
cache, fonte privada ou byte do TEST32 está no ZIP.

O diretório de saída de downloads indicado pela sessão, sob `/codex/browser/`, não
pôde ser criado: filesystem somente leitura/permissão negada, inclusive com a
capacidade de filesystem solicitada à ferramenta. A execução e o pacote foram
preservados em `/workspace/work/bridge-poc/delivery/`; não se alega link de download
funcional nesta sessão. Esse bloqueio não impediu código, testes, commit local ou patch.
