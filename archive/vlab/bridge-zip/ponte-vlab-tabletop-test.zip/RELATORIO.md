# Continuação verificada da ponte — entrega ainda bloqueada

23/10/2026. Mesmo repositório/branch. Nenhuma publicação, PR, merge, deploy ou escrita
em Notion/Party/fichas. Código original e histórico preservados.

Commit inicial: `3f5caadfd376a63a949ca63815c0b68a0ea73a57`.
Commit de fonte corrigida: `bad50082621f5ddebb157088949dccac8e6aa8ca`.
Base: `046f6cc3d67ab6f8ae9a5c6eda6eaf03cd8d2267`.
Branch: `test/tabletop-vlab-bridge-poc`.

## Conteúdo e integridade

17 arquivos de fonte/documentação atuais; os 14 originais foram conferidos antes
da correção. 41/41 arquivos da base permanecem byte-idênticos. O pacote original
continua preservado no workspace com SHA `3c128ce9476fb544f913495ff8476d1b37bd3258e4638884a0db5146ea307b24`.
Não está aninhado neste ZIP, para evitar duas versões executáveis da autoridade.
Logs e recibo originais estão identificados em historical/ e evidence/original/.

`bridge.patch` é o patch completo de fonte entre a base e o commit corrigido.
`correction-from-original.patch` mostra só a continuação, cinco arquivos alterados:
authority.py, README.md, COMPATIBILITY.md, FOLLOWUP_RECEIPT.md e test_projection_security.py.
O ZIP de distribuição e seu SHA externo são embalagens, não conteúdo recursivo
do patch de fonte. Manifesto traz tamanho/hash de cada payload; SHA256SUMS inclui
também o manifesto. Nenhum manifesto inclui o próprio hash, evitando circularidade.

## Prova real de testes, sem rerun integral

| Prova | Resultado | Momento |
| --- | --- | --- |
| Suíte original Python | 28 PASS, um executa 15 Node PASS | Logs originais preservados |
| TypeScript strict | PASS | Fonte cliente/config byte-idênticos; não repetido |
| Testes legados | 55 PASS | Originais inalterados; não repetidos |
| Smoke TEST32 | 8 PASS em Chromium emulado | Sem alteração do frontend; não repetido |
| Novos testes aninhados ANTES | 6 métodos, 8 registros de falha com subtests, exit 1 | Executados nesta continuação |
| Novos testes aninhados DEPOIS | 6 PASS, zero falhas | Executados nesta continuação |
| Regressões selecionadas DEPOIS | 7 PASS, um executa 15 Node PASS | Executados nesta continuação |

Não se somam as contagens aninhadas como métodos independentes. O recibo JSON
aponta logs reais. A correção impede contêineres em campos escalares e ator
inesperado de sair nos DTOs; remove metadata extra e reverte submit quando a
projeção falha. O canário é inventado e a adulteração foi direta em banco TEST;
não há prova de vetor remoto, nem uso de segredo real.

## Contrato e comparação

O contrato efetivo permanece v1 e seis envelopes `create/view/submit/history/checkpoint/restore`.
Veja README.md e client.ts dentro de experiments/tabletop_vlab_bridge/.
`COMPATIBILITY.md` nesse diretório traz a matriz detalhada de operações, campos,
papéis e responsabilidades, com fontes próximas das afirmações.

Equivalências funcionais: client_action_id ↔ commandId ↔ intentId;
expected_revision ↔ baseRevision. Room create não equivale a JOIN.
view se aproxima de snapshot/WELCOME/RESYNC. checkpoint/restore não têm
contraparte pública documentada. Identidade fixture deriva do servidor; perfis
DEMO não são autenticação. Evento público e seq não são recibo de comando.

C lida com perda pós-COMMIT como UNKNOWN e retry do mesmo ID não reaplica efeito.
Mas não há RECEIPT_QUERY, recibo consultável por ID, vínculo do histórico ao ID
de intenção nem pending persistente. Essa diferença v2 segue HOLD, sem criação
de servidor ou reescrita TEST34. A matriz P/T é DOCUMENTAL: seus binários Library
não estão acessíveis nesta instância. Não se alegam hashes externos conferidos,
comparação linha a linha nem integração executada.

Parecer A: Python mantém autoridade mecânica; uma única autoridade de sala
coordena sessão/ACL/revisão/recibos/projeção. Transporte separado não implica
atomicidade distribuída com o executor. Dano/PA/crítico/defesa/transformação/RNG
dependem exclusivamente da ABI VLAB homologada; aqui só há rótulos fictícios.

Python Workers tem runtime Pyodide, filesystem efêmero e limitações de threading.
DO SQLite usa API própria e transações storage, não sqlite3 por arquivo/BEGIN.
Não executamos essa POC nem VLAB em Cloudflare. Fontes oficiais e inferências
estão distinguidas na matriz; não se promete hospedagem gratuita permanente.

## Segurança e pontos HOLD

Varredura de credenciais mais revisão manual do diff/pacote: nenhum token real,
fonte privada VLAB, dados Party, NPC privado ou objeto Mestre-only real incluído.
Só fixtures FAKE_TEST_* e canários sintéticos. Não exportar SQLite/node_modules,
cache, binários externos de pesquisa ou bytes do TEST32. Scanner não constitui
certificação universal de ausência de segredos ou autorização de produção.

Permanecem VLAB_SOURCE_NOT_AVAILABLE, PYTHON_TS_EQUIVALENCE_NOT_TESTED,
ANDROID_REAL_NOT_TESTED, VLAB_PRODUCTION_HOLD e GH-NOT-RUN.
FIRST-PENDING: entregar arquivo recuperável; depois revisão do contrato-alvo,
receipt query/pending, auth e ABI permitida. Não inferir compatibilidade mecânica.

## Recuperação no Android: situação real e alternativa para aprovação

**Neste momento não há download confirmado na interface Codex.** O diretório
de resultados /codex/browser/... não pode ser criado (filesystem somente leitura)
e não há ferramenta de upload de workspace/Library/anexo disponível. download_file
é somente entrada Sediment. Não há acesso ao painel Android para verificar botões;
não se anuncia arquivo acessível por mera existência em /workspace ou link local.

Alternativa executável, SOMENTE após autorização: publicar a mesma branch TEST
no repositório público arthof09-ai/assimilat-rpg-integracao-test. O payload será
17 arquivos auditados de fonte/documentação e 2 de distribuição:
`experiments/tabletop_vlab_bridge/delivery/ponte-vlab-tabletop-test.zip` e
`experiments/tabletop_vlab_bridge/delivery/ponte-vlab-tabletop-test.zip.sha256`.
Nenhuma outra alteração de branch existente, PR, merge, deploy ou release.
Antes, revalidar ref ausente e diff; depois, ler bytes remotos e conferir SHA,
e fornecer URL GitHub raw fixada no commit. Os workflows existentes de push
locais estão limitados a main; não há garantia de CI nova nem de Android físico.

Após publicação AUTORIZADA e leitura de retorno, passos previstos para o Mestre:
1. Na mesma conversa/tarefa do Codex, toque no link HTTPS de download que será fornecido.
2. Se o aplicativo abrir o navegador, continue no Chrome Android e confirme Baixar.
3. Abra Files/Meus Arquivos → Downloads e localize ponte-vlab-tabletop-test.zip.
4. Use Compartilhar para enviar esse único ZIP ao Coordenador; envie também o SHA-256 textual.
5. O Coordenador confere SHA do ZIP, extrai e valida SHA256SUMS.txt antes de executar.
Esses passos são condicionais; o link ainda NÃO foi criado nem testado no aparelho.

Documentação oficial: https://help.openai.com/en/articles/20001545-using-codex-cloud
descreve retomada da tarefa original; https://learn.chatgpt.com/docs/mobile
descreve revisão de arquivos/diffs no telefone. Nenhuma dessas páginas confirma
uma ferramenta de exportação disponível a este executor específico.

Rollback: não incorporar a branch conserva o comportamento anterior. Qualquer
remoção remota futura deve receber autorização; não se usa force push ou reset
destrutivo nesta entrega. Os 41 originais e o commit inicial ficam preservados.
