/** FAKE_RULES_FOR_TRANSPORT_TEST. Typed transport; no game rules. */
export const SCHEMA_VERSION = 1 as const;
export const MODE = "FAKE_RULES_FOR_TRANSPORT_TEST" as const;
export type Role = "master" | "player1" | "player2";
export type ActorId = "actor-m" | "actor-1" | "actor-2";
export type ErrorCode = "STALE_REVISION" | "DUPLICATE_INTENT" | "FORBIDDEN" |
  "INVALID_SCHEMA" | "UNKNOWN_EFFECT" | "LIMIT_EXCEEDED" | "INTERNAL_ERROR";
type Base<O extends string> = { schema_version: 1; op: O; room_id: string };
type Intent = { client_action_id: string; expected_revision: number };
export type Create = Base<"create"> & Intent;
export type View = Base<"view">;
export type Submit = Base<"submit"> & Intent & {
  actor_id: ActorId; effect: { kind: "FAKE_SET_LABEL"; label: string };
};
export type History = Base<"history"> & { after_revision: number };
export type Checkpoint = Base<"checkpoint"> & Intent;
export type Restore = Base<"restore"> & Intent & { checkpoint_id: string };
export type Request = Create | View | Submit | History | Checkpoint | Restore;
export type ActorView = { actor_id: ActorId; label: string };
type CommonView = { mode: typeof MODE; actors: ActorView[] };
export type MasterView = CommonView & {
  role: "master"; master_note: string; private_notes: Record<ActorId, string>;
};
export type PlayerView = CommonView & {
  role: "player1" | "player2"; own_actor_id: ActorId; own_note: string;
};
export type Projection = MasterView | PlayerView;
export type PublicEvent = { revision: number; public_event_id: string } & (
  { kind: "FAKE_SET_LABEL"; actor_id: ActorId; label: string } |
  { kind: "FAKE_RESTORE"; view: Projection }
);
type Success<O extends Request["op"]> = Base<O> & { ok: true; revision: number };
export type ReplyMap = {
  create: Success<"create"> & { client_action_id: string; view: Projection };
  view: Success<"view"> & { view: Projection };
  submit: Success<"submit"> & { client_action_id: string; public_event_id: string; view: Projection };
  history: Success<"history"> & { events: PublicEvent[] };
  checkpoint: Success<"checkpoint"> & { client_action_id: string; checkpoint_id: string; view: Projection };
  restore: Success<"restore"> & { client_action_id: string; public_event_id: string; view: Projection };
};
export type ErrorReply = { schema_version: 1; op: "error"; ok: false; error: { code: ErrorCode } };
export type Reply<O extends Request["op"]> = ReplyMap[O] | ErrorReply;

/** A network failure is NOT a server rejection. Reconcile view/history, then
 * retry the SAME client_action_id. Never guess a new intent after timeout. */
export class TransportUnknown extends Error {
  readonly outcome = "UNKNOWN";
  constructor() { super("Transport outcome unknown; reconcile before retry"); }
}

const forbidden = new Set(["__proto__", "prototype", "constructor"]);
const codes = new Set<ErrorCode>(["STALE_REVISION", "DUPLICATE_INTENT", "FORBIDDEN",
  "INVALID_SCHEMA", "UNKNOWN_EFFECT", "LIMIT_EXCEEDED", "INTERNAL_ERROR"]);
const actorIds = ["actor-1", "actor-2", "actor-m"];
const decoder = new TextDecoder("utf-8", { fatal: true });
type Obj = Record<string, unknown>;
function check(ok: unknown): asserts ok {
  if (!ok) throw new TransportUnknown();
}
function obj(value: unknown): asserts value is Obj {
  check(value !== null && typeof value === "object" && !Array.isArray(value));
  check(Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
function keys(value: Obj, expected: string[]) {
  check(Object.keys(value).sort().join(",") === [...expected].sort().join(","));
}
function tree(value: unknown, depth = 0): void {
  check(depth <= 12);
  check(value === null || ["object", "string", "boolean", "number"].includes(typeof value));
  if (typeof value === "number") check(Number.isFinite(value));
  if (value !== null && typeof value === "object") {
    if (!Array.isArray(value)) obj(value);
    for (const key of Object.keys(value)) {
      check(!forbidden.has(key));
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      check(descriptor && "value" in descriptor); // never invoke accessors
      tree(descriptor.value, depth + 1);
    }
  }
}
function int(value: unknown) {
  check(Number.isInteger(value) && Number(value) >= 0 && Number(value) <= 2147483647);
}
function id(value: unknown) {
  check(typeof value === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(value));
}
function label(value: unknown) {
  check(typeof value === "string" && [...value].length >= 1 && [...value].length <= 80 && !/[\x00-\x1f]/.test(value));
}
function view(value: unknown, role: Role) {
  obj(value);
  check(value.mode === MODE && value.role === role);
  const base = ["mode", "role", "actors"];
  keys(value, base.concat(role === "master" ? ["master_note", "private_notes"] : ["own_actor_id", "own_note"]));
  check(Array.isArray(value.actors) && value.actors.length === 3);
  const found: string[] = [];
  for (const actor of value.actors) {
    obj(actor); keys(actor, ["actor_id", "label"]);
    check(typeof actor.actor_id === "string" && actorIds.includes(actor.actor_id));
    label(actor.label); found.push(actor.actor_id);
  }
  check(found.sort().join(",") === actorIds.join(","));
  if (role === "master") {
    check(typeof value.master_note === "string");
    obj(value.private_notes); keys(value.private_notes, actorIds);
    check(Object.values(value.private_notes).every(x => typeof x === "string"));
  } else {
    check(value.own_actor_id === (role === "player1" ? "actor-1" : "actor-2"));
    check(typeof value.own_note === "string");
  }
}

function validateReply(value: unknown, req: Request, role: Role, status: number) {
  tree(value); obj(value);
  check(value.schema_version === SCHEMA_VERSION);
  if (value.ok === false) {
    keys(value, ["schema_version", "op", "ok", "error"]);
    check(value.op === "error"); obj(value.error); keys(value.error, ["code"]);
    check(codes.has(value.error.code as ErrorCode));
    const expectedStatus: Record<ErrorCode, number> = { INVALID_SCHEMA: 400, FORBIDDEN: 403,
      STALE_REVISION: 409, DUPLICATE_INTENT: 409, UNKNOWN_EFFECT: 400,
      LIMIT_EXCEEDED: 413, INTERNAL_ERROR: 500 };
    check(status === expectedStatus[value.error.code as ErrorCode]);
    return;
  }
  check(status === 200 && value.ok === true && value.op === req.op && value.room_id === req.room_id);
  int(value.revision);
  let extras: string[] = [];
  if (req.op === "history") {
    extras = ["events"];
    check(Array.isArray(value.events) && value.events.length <= 128);
    let previous = req.after_revision;
    for (const event of value.events) {
      obj(event); int(event.revision); id(event.public_event_id);
      check(event.revision === previous + 1); previous = Number(event.revision);
      check(event.public_event_id === `event-${event.revision}`);
      if (event.kind === "FAKE_SET_LABEL") {
        keys(event, ["revision", "public_event_id", "kind", "actor_id", "label"]);
        check(typeof event.actor_id === "string" && actorIds.includes(event.actor_id)); label(event.label);
      } else {
        check(event.kind === "FAKE_RESTORE");
        keys(event, ["revision", "public_event_id", "kind", "view"]); view(event.view, role);
      }
    }
    check(previous === value.revision);
  } else {
    extras = ["view"]; view(value.view, role);
    if (req.op !== "view") {
      extras.push("client_action_id"); check(value.client_action_id === req.client_action_id);
    }
    if (req.op === "submit" || req.op === "restore") {
      extras.push("public_event_id"); id(value.public_event_id);
      check(value.revision === req.expected_revision + 1);
      check(value.public_event_id === `event-${value.revision}`);
    }
    if (req.op === "checkpoint") { extras.push("checkpoint_id"); id(value.checkpoint_id); }
    if (req.op === "create" || req.op === "checkpoint") check(value.revision === req.expected_revision);
  }
  keys(value, ["schema_version", "op", "ok", "room_id", "revision", ...extras]);
}

export class BridgeClient {
  private queue: Promise<unknown> = Promise.resolve();
  private readonly endpoint: string;
  private readonly token: string;
  private readonly role: Role;
  private readonly timeoutMs: number;
  private readonly send: typeof fetch;

  constructor(endpoint: string, token: string, role: Role, timeoutMs = 3000, send: typeof fetch = fetch) {
    const url = new URL(endpoint);
    // This artifact is deliberately loopback-only. No accidental remote writes.
    check(url.protocol === "http:" && url.hostname === "127.0.0.1" && url.pathname === "/bridge" &&
      !url.username && !url.password && !url.search && !url.hash);
    this.endpoint = endpoint; this.token = token; this.role = role;
    this.timeoutMs = timeoutMs; this.send = send;
  }

  request<T extends Request>(req: T): Promise<Reply<T["op"]>> {
    // Capture now: caller mutation cannot change an already queued intent.
    let body: string;
    try {
      tree(req); body = JSON.stringify(req);
      check(new TextEncoder().encode(body).byteLength <= 4096);
    } catch { return Promise.reject(new TransportUnknown()); }
    const captured = JSON.parse(body) as T;
    const result = this.queue.then(() => this.exchange(captured, body));
    this.queue = result.catch(() => undefined); // a failed request cannot poison queue
    return result;
  }

  private async exchange<T extends Request>(req: T, body: string): Promise<Reply<T["op"]>> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.send(this.endpoint, { method: "POST", body,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.token}` },
        signal: controller.signal, redirect: "error", cache: "no-store" });
      check(response.headers.get("content-type")?.startsWith("application/json"));
      check(response.body); const reader = response.body.getReader();
      const chunks: Uint8Array[] = []; let size = 0;
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.length; check(size <= 65536); chunks.push(value);
        }
      } catch (err) { await reader.cancel(); throw err; }
      const joined = new Uint8Array(size); let offset = 0;
      for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.length; }
      const value: unknown = JSON.parse(decoder.decode(joined));
      validateReply(value, req, this.role, response.status);
      return value as Reply<T["op"]>; // full runtime allowlist checked above
    } catch { throw new TransportUnknown(); }
    finally { clearTimeout(timer); }
  }
}

/** Optional read-only presentation hook. No HTML injection or adjudication. */
export function present(target: Pick<HTMLElement, "textContent">, received: Projection): void {
  target.textContent = JSON.stringify(received, null, 2);
}
