"""Synthetic contract, security, persistence and real loopback HTTP tests."""
import concurrent.futures
import copy
import http.client
import json
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import authority as a

HERE = Path(__file__).resolve().parent
TOKENS = {role: token for token, (role, _) in a.SESSIONS.items()}


def request(op, **fields):
    return dict(schema_version=1, op=op, room_id="demo", **fields)


def intent(op, action="i1", rev=0, **fields):
    return request(op, client_action_id=action, expected_revision=rev, **fields)


def submit(action="i1", rev=0, actor="actor-1", label="Changed"):
    return intent("submit", action, rev, actor_id=actor,
                  effect={"kind": "FAKE_SET_LABEL", "label": label})


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "test.sqlite"
        self.engine = a.Authority(self.path)
        self.call(intent("create", "create"), "master")

    def call(self, value, role="player1", engine=None):
        status, raw = (engine or self.engine).handle(a.encode(value).encode(), TOKENS[role])
        return status, json.loads(raw)

    def state(self):
        return self.call(request("view"), "master")[1]

    def counts(self):
        with sqlite3.connect(self.path) as db:
            return {table: db.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
                    for table in ["rooms", "events", "intents", "checkpoints"]}

    def rejects_without_mutation(self, value, code, role="player1"):
        before, counts = self.state(), self.counts()
        status, reply = self.call(value, role)
        self.assertEqual(status, a.ERROR_STATUS[code])
        self.assertEqual(reply, {"schema_version": 1, "op": "error", "ok": False, "error": {"code": code}})
        self.assertEqual(self.state(), before)
        self.assertEqual(self.counts(), counts)

    def player_safe(self, reply, role):
        raw = a.encode(reply)
        for marker in ["FAKE_MASTER_ONLY", "FAKE_MASTER_ACTOR_NOTE", "master_note", "private_notes",
                       "head", "journal", "fingerprint", "snapshot", "checkpoint_id",
                       "FAKE_P2_ONLY" if role == "player1" else "FAKE_P1_ONLY"]:
            self.assertNotIn(marker, raw)

    def test_six_distinct_envelopes_and_authorized_action(self):
        self.assertEqual(self.call(submit())[0], 200)
        current = self.state()
        self.assertEqual(current["revision"], 1)
        self.assertEqual(self.call(request("history", after_revision=0))[1]["events"][0]["public_event_id"], "event-1")
        cp = self.call(intent("checkpoint", "cp", 1), "master")[1]
        restored = self.call(intent("restore", "restore", 1, checkpoint_id=cp["checkpoint_id"]), "master")[1]
        self.assertEqual(restored["revision"], 2)
        self.assertEqual(restored["op"], "restore")

    def test_projections_distinct_server_side(self):
        views = {role: self.call(request("view"), role)[1] for role in TOKENS}
        self.assertIn("master_note", views["master"]["view"])
        self.assertEqual(views["player1"]["view"]["own_note"], "FAKE_P1_ONLY")
        self.assertEqual(views["player2"]["view"]["own_note"], "FAKE_P2_ONLY")
        self.assertNotEqual(views["player1"], views["player2"])
        for role in ["player1", "player2"]:
            self.player_safe(views[role], role)

    def test_duplicate_once_even_payload_changed(self):
        self.assertEqual(self.call(submit())[0], 200)
        self.rejects_without_mutation(submit(), "DUPLICATE_INTENT")
        self.rejects_without_mutation(submit(label="Different"), "DUPLICATE_INTENT")
        self.assertEqual(self.counts()["events"], 1)

    def test_same_action_id_other_principal_is_separate(self):
        self.call(submit())
        self.assertEqual(self.call(submit(rev=1, actor="actor-2"), "player2")[0], 200)

    def test_simultaneous_duplicate_has_only_one_effect(self):
        barrier = threading.Barrier(2)
        def work(_):
            barrier.wait()
            return self.call(submit())
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            replies = list(pool.map(work, [0, 1]))
        self.assertEqual(sorted(x[0] for x in replies), [200, 409])
        self.assertEqual([x[1]["error"]["code"] for x in replies if x[0] != 200], ["DUPLICATE_INTENT"])
        self.assertEqual(self.counts()["events"], 1)

    def test_two_concurrent_revisions_one_accept_one_conflict(self):
        other = a.Authority(self.path)
        barrier = threading.Barrier(2)
        def work(i):
            barrier.wait()
            return self.call(submit(f"race-{i}"), engine=[self.engine, other][i])
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            replies = list(pool.map(work, [0, 1]))
        self.assertEqual(sorted(x[0] for x in replies), [200, 409])
        self.assertEqual([x[1]["error"]["code"] for x in replies if x[0] != 200], ["STALE_REVISION"])
        self.assertEqual(self.counts()["events"], 1)

    def test_stale_no_mutation_or_intent_reservation(self):
        self.rejects_without_mutation(submit(rev=8), "STALE_REVISION")
        self.assertEqual(self.call(submit())[0], 200)

    def test_forbidden_actor_and_unknown_actor(self):
        for actor in ["actor-2", "actor-m", "unknown"]:
            self.rejects_without_mutation(submit(actor=actor), "FORBIDDEN")

    def test_unknown_effect_never_becomes_game_engine(self):
        for kind in ["DAMAGE", "PA", "CRITICAL", "DEFENSE", "TRANSFORM", "HEAL"]:
            req = submit(); req["effect"]["kind"] = kind
            self.rejects_without_mutation(req, "UNKNOWN_EFFECT")

    def test_player_cannot_create_checkpoint_or_restore(self):
        cp = self.call(intent("checkpoint", "cp"), "master")[1]["checkpoint_id"]
        for role in ["player1", "player2"]:
            for req in [intent("create", "other"), intent("checkpoint", "cp"), intent("restore", "r", checkpoint_id=cp)]:
                self.rejects_without_mutation(req, "FORBIDDEN", role)

    def test_missing_room_and_bad_token_are_generic(self):
        req = request("view"); req["room_id"] = "missing"
        self.rejects_without_mutation(req, "FORBIDDEN")
        status, body = self.engine.handle(b'{"master_note":"echo-secret"}', "wrong")
        self.assertEqual(status, 403)
        self.assertNotIn(b"echo-secret", body)

    def test_all_player_success_and_failure_payloads_after_restore_are_safe(self):
        cp = self.call(intent("checkpoint", "cp"), "master")[1]["checkpoint_id"]
        self.call(submit(actor="actor-m"), "master")
        self.call(intent("restore", "r", 1, checkpoint_id=cp), "master")
        for role, actor in [("player1", "actor-1"), ("player2", "actor-2")]:
            values = [request("view"), request("history", after_revision=0),
                      submit("ok-" + role, self.state()["revision"], actor),
                      submit("stale", 0, actor), intent("checkpoint", "denied"),
                      intent("restore", "denied2", checkpoint_id=cp),
                      request("history", after_revision=999)]
            for value in values:
                self.player_safe(self.call(value, role)[1], role)
            with patch.object(a, "projection", side_effect=RuntimeError("FAKE_MASTER_ONLY")):
                status, body = self.call(request("view"), role)
            self.assertEqual(status, 500)
            self.player_safe(body, role)

    def test_invalid_fields_and_nested_injection(self):
        for field in ["role", "head", "journal", "master_note", "revision", "actor_owner"]:
            req = submit(); req[field] = "FAKE_MASTER_ONLY"
            self.rejects_without_mutation(req, "INVALID_SCHEMA")
        for key in ["__proto__", "constructor", "prototype"]:
            req = submit(); req["effect"][key] = {"polluted": True}
            self.rejects_without_mutation(req, "INVALID_SCHEMA")

    def test_duplicate_json_keys_malformed_utf8_and_depth(self):
        values = [b'{"schema_version":1,"schema_version":1}', b'\xff', b'{', b'NaN', b'null',
                  b'[' * 20 + b'0' + b']' * 20,
                  b'{"__proto__":{"polluted":true}}']
        for raw in values:
            status, body = self.engine.handle(raw, TOKENS["player1"])
            self.assertEqual(status, 400)
            self.player_safe(json.loads(body), "player1")

    def test_wrong_types_versions_numbers_and_labels(self):
        for field, value in [("schema_version", True), ("schema_version", 2), ("op", []),
                             ("expected_revision", True), ("expected_revision", -1),
                             ("expected_revision", 0.0), ("expected_revision", 2**53),
                             ("room_id", "../demo"), ("actor_id", {})]:
            req = submit(); req[field] = value
            self.rejects_without_mutation(req, "INVALID_SCHEMA")
        for value in ["", "x" * 81, "line\nbreak", "\ud800", 12, {}]:
            req = submit(); req["effect"]["label"] = value
            # encode escapes surrogate to test wire parser without leaking into logs
            raw = json.dumps(req).encode()
            self.assertEqual(self.engine.handle(raw, TOKENS["player1"])[0], 400)

    def test_body_size_limit(self):
        self.assertEqual(self.engine.handle(b" " * (a.MAX_BODY + 1), TOKENS["player1"])[0], 413)

    def test_room_checkpoint_and_event_limits(self):
        with patch.object(a, "MAX_ROOMS", 1):
            req = intent("create", "another"); req["room_id"] = "other"
            self.rejects_without_mutation(req, "LIMIT_EXCEEDED", "master")
        with patch.object(a, "MAX_CHECKPOINTS", 1):
            self.call(intent("checkpoint", "cp1"), "master")
            self.rejects_without_mutation(intent("checkpoint", "cp2"), "LIMIT_EXCEEDED", "master")
        with patch.object(a, "MAX_EVENTS", 1):
            self.call(submit())
            self.rejects_without_mutation(submit("i2", 1), "LIMIT_EXCEEDED")

    def test_response_size_failure_rolls_back(self):
        before, counts = self.state(), self.counts()
        with patch.object(a, "MAX_RESPONSE", 10):
            status, reply = self.call(submit())
            self.assertEqual(status, 413)
            self.assertEqual(reply["error"]["code"], "LIMIT_EXCEEDED")
        self.assertEqual(self.state(), before)
        self.assertEqual(self.counts(), counts)

    def test_injected_execution_exception_rolls_back_and_is_redacted(self):
        with patch.object(a, "reduce_event", side_effect=RuntimeError("FAKE_MASTER_ONLY")):
            self.rejects_without_mutation(submit(), "INTERNAL_ERROR")

    def test_sqlite_failure_after_event_and_state_write_is_atomic(self):
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TRIGGER fail_intent BEFORE INSERT ON intents BEGIN "
                       "SELECT RAISE(ABORT, 'FAKE_MASTER_ONLY'); END")
        self.rejects_without_mutation(submit(), "INTERNAL_ERROR")
        with sqlite3.connect(self.path) as db:
            db.execute("DROP TRIGGER fail_intent")
        self.assertEqual(self.call(submit())[0], 200)

    def test_snapshot_plus_replay_equals_full_replay(self):
        self.call(submit())
        self.call(intent("checkpoint", "cp1", 1), "master")
        self.call(submit("i2", 1, label="After checkpoint"))
        with self.engine.connect() as db:
            full = self.engine.replay(db, "demo")
            recovered = self.engine.replay(db, "demo", True)
        self.assertEqual(full, recovered)
        self.assertEqual(full[1], 2)
        self.assertEqual(a.projection(full[0], "master", "actor-m"), self.state()["view"])

    def test_restore_is_monotonic_and_dedup_survives_rollback(self):
        cp = self.call(intent("checkpoint", "cp"), "master")[1]["checkpoint_id"]
        self.call(submit())
        self.call(intent("restore", "r", 1, checkpoint_id=cp), "master")
        self.assertEqual(self.state()["revision"], 2)
        self.assertEqual(self.state()["view"]["actors"][0]["label"], "Synthetic P1")
        self.rejects_without_mutation(submit(), "DUPLICATE_INTENT")
        self.rejects_without_mutation(submit("new", 0), "STALE_REVISION")
        with self.engine.connect() as db:
            self.assertEqual(self.engine.replay(db, "demo"), self.engine.replay(db, "demo", True))

    def test_cold_rebuild_ignores_materialized_cache_and_retains_dedup(self):
        self.call(submit())
        self.call(intent("checkpoint", "cp", 1), "master")
        self.call(submit("i2", 1, label="Cold resume"))
        expected = self.state()
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE rooms SET state=?", (a.encode(a.SEED),))
        restarted = a.Authority(self.path)
        self.assertEqual(self.call(request("view"), "master", restarted)[1], expected)
        self.assertEqual(self.call(submit("i2", 1), engine=restarted)[1]["error"]["code"], "DUPLICATE_INTENT")

    def test_player_history_and_views_are_identical_and_safe_after_cold_restore(self):
        cp = self.call(intent("checkpoint", "cp"), "master")[1]["checkpoint_id"]
        self.call(submit())
        self.call(intent("restore", "r", 1, checkpoint_id=cp), "master")
        self.call(submit("after-restore", 2))
        before = {role: [self.call(value, role)[1] for value in
                         [request("view"), request("history", after_revision=0)]]
                  for role in ["player1", "player2"]}
        restarted = a.Authority(self.path)
        for role in before:
            for i, value in enumerate([request("view"), request("history", after_revision=0)]):
                reply = self.call(value, role, restarted)[1]
                self.assertEqual(reply, before[role][i])
                self.player_safe(reply, role)

    def test_real_process_kill_resume_after_commit_ack_lost(self):
        process = subprocess.Popen([sys.executable, str(HERE / "authority.py"), "--db", str(self.path)],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            info = json.loads(process.stdout.readline())
            port = int(info["url"].split(":")[2].split("/")[0])
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
            conn.request("POST", "/bridge", json.dumps(submit()),
                         {"Content-Type": "application/json", "Authorization": "Bearer FAKE_TEST_PLAYER1"})
            # HTTP status means commit completed, but intentionally discard receipt.
            response = conn.getresponse(); self.assertEqual(response.status, 200)
            process.kill(); process.wait(timeout=5); conn.close()
        finally:
            if process.poll() is None:
                process.kill(); process.wait(timeout=5)
            process.stdout.close(); process.stderr.close()
        restarted = a.Authority(self.path)
        self.assertEqual(self.call(submit(), engine=restarted)[1]["error"]["code"], "DUPLICATE_INTENT")
        self.assertEqual(self.call(request("view"), engine=restarted)[1]["revision"], 1)

    def test_recovery_gap_fails_closed(self):
        self.call(submit()); self.call(submit("i2", 1))
        with sqlite3.connect(self.path) as db:
            db.execute("DELETE FROM events WHERE revision=1")
        with self.assertRaises(ValueError):
            a.Authority(self.path)


class HttpAndTypeScriptTests(unittest.TestCase):
    def test_typescript_client_over_real_http(self):
        with tempfile.TemporaryDirectory() as temp:
            server = a.make_server(a.Authority(Path(temp) / "wire.sqlite"))
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                result = subprocess.run(["node", "--test", str(HERE / "test_client.mjs")],
                    env=__import__("os").environ | {"BRIDGE_URL": f"http://127.0.0.1:{server.server_port}/bridge"},
                    text=True, capture_output=True, timeout=60)
                print(result.stdout, end="")
                self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_http_bad_envelopes_do_not_echo_or_bypass_auth(self):
        with tempfile.TemporaryDirectory() as temp:
            server = a.make_server(a.Authority(Path(temp) / "wire.sqlite"))
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
            try:
                cases = [("/wrong", b"FAKE_MASTER_ONLY", {"Content-Type": "application/json"}, 400),
                         ("/bridge", b"{}", {"Content-Type": "text/plain"}, 400),
                         ("/bridge", b"{}", {"Content-Type": "application/json"}, 403),
                         ("/bridge", b" " * 4097, {"Content-Type": "application/json"}, 413),
                         ("/bridge", b"{}", {"Content-Type": "application/json", "Transfer-Encoding": "chunked"}, 400)]
                for path, body, headers, status in cases:
                    conn = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=5)
                    conn.request("POST", path, body, headers)
                    reply = conn.getresponse(); self.assertEqual(reply.status, status)
                    self.assertEqual(reply.getheader("Cache-Control"), "no-store")
                    self.assertIsNone(reply.getheader("Access-Control-Allow-Origin"))
                    self.assertNotIn(b"FAKE_MASTER_ONLY", reply.read()); conn.close()
                conn = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=5)
                conn.request("FAKE_MASTER_ONLY", "/FAKE_MASTER_ONLY")
                response = conn.getresponse()
                self.assertEqual(response.status, 400)
                self.assertNotIn(b"FAKE_MASTER_ONLY", response.read()); conn.close()
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
