import type { Submit, Reply, Request } from "./client.ts";
const good: Submit = { schema_version: 1, op: "submit", room_id: "demo", actor_id: "actor-1",
  client_action_id: "intent", expected_revision: 0, effect: { kind: "FAKE_SET_LABEL", label: "test" } };
const request: Request = good;
// Negative compile gates: these MUST remain type errors.
// @ts-expect-error No canonical mechanics in this contract
const mechanical: Submit = { ...good, effect: { kind: "DAMAGE", label: "test" } };
// @ts-expect-error Unknown top-level fields are forbidden
const elevated: Submit = { ...good, role: "master" };
// @ts-expect-error A submit must carry a revision
const missing: Submit = { schema_version: 1, op: "submit", room_id: "demo" };
function narrow(reply: Reply<"history">) {
  if (reply.ok) return reply.events;
  return reply.error.code;
}
void [request, mechanical, elevated, missing, narrow];
