# Diferencial — contrato Codex v1 × PESQ-013 v2 × TEST34

23/10/2026. Continuação do experimento original `3f5caad`, mesma branch TEST.
Não há implementação de novo servidor, tradução v2 ou alteração do TEST34.

## Fontes e nível de evidência

- **C — BYTES_VERIFIED:** `authority.py`, `client.ts` e testes do checkout local.
  Commit inicial `3f5caadfd376a63a949ca63815c0b68a0ea73a57`; correção incremental
  documentada em `FOLLOWUP_RECEIPT.md` e no recibo do pacote.
- **P — DOCUMENTARY:** [Laboratório do Inovador](https://app.notion.com/p/401c2b324ede809585d3d1907c194df9),
  seção `PESQ-INOV-20261023-013`, proposta de contrato de sala v2.
- **T — DOCUMENTARY:** mesma página, `RUN-011`, cliente sintético TEST34,
  e adendo `CP-INOV-TRIAGEM-3-FRENTES-CODEX-RUN011-PESQ013-20261023-001` de coordenação.
  A coordenação relata ter lido os arquivos em bytes; esta instância **não** os leu.
- GitHub `gh-pages` consultado nesta continuação permanece no TEST32,
  `0aa9bc817844fa4ce0e16a2103a3a89988df577c`, sem `room-client.js`.
  Os ZIPs TEST34/PESQ013 estão identificados no Notion como arquivos de Library,
  mas não estão anexados à página nem disponíveis às ferramentas atuais.

Assim, esta é uma matriz do contrato C efetivo versus P/T documentados, **não**
uma auditoria linha a linha dos binários externos nem teste diferencial integrado.
Não copiamos conteúdo bruto MESTRE-ONLY, fontes VLAB, Party ou pacotes externos.
Nomes de campos não documentados abaixo permanecem NÃO CONFIRMADOS.

## Matriz de operações

| Codex efetivo C | PESQ-013 P | TEST34 T | Equivalência / adaptação necessária |
| --- | --- | --- | --- |
| `create` | `JOIN` | `ROOM_JOIN` | **Não equivalentes.** C cria estado da sala; JOIN estabelece participação/conexão a uma sala. Separar bootstrap administrativo de associação/autenticação. |
| `view` | `WELCOME` e recuperação por `RESYNC` | `ROOM_JOINED` / `ROOM_SNAPSHOT` | Equivalência parcial de snapshot projetado. C é pull HTTP; P/T têm ciclo de sessão/eventos. WELCOME não é resposta de criação da sala. |
| `submit` | `INTENT` → `ACK` | `ROOM_INTENT` → `ROOM_EVENT` / `ROOM_REJECT` | Equivalência de intenção, não de formato ou confirmação. Traduzir versão, correlação, revisão e resultado; não tratar qualquer ROOM_EVENT como recibo da intenção pendente. |
| `history` | `RESYNC` (sem API de histórico integral comprovada no registro) | `ROOM_EVENT`, `ROOM_RESYNC` | Eventos/revisão têm propósito parecido. Resync é reparo de estado, não necessariamente replay integral; política de retenção/cursor/snapshot exige definição. |
| `checkpoint` | Sem correspondente documentado | Sem correspondente documentado | Ato administrativo privado C, ID opaco apenas ao Mestre. Não inventar mensagem pública equivalente. |
| `restore` | Sem correspondente documentado | Sem correspondente documentado | C restaura snapshot sintético com nova revisão e dedup preservado. Restauração mecânica real pertence ao backend/VLAB autorizado e exige contrato próprio. |

## Matriz de campos e semânticas

| Conceito | C implementado | P documentado | T documentado | Decisão para compatibilização futura |
| --- | --- | --- | --- | --- |
| Versão | `schema_version: 1` | protocolo v2; discriminador literal não disponível | namespace `assim.tabletop.room.presentation.v1` | Três domínios/versionamentos distintos; nunca renomear envelopes sem negociação e validação. |
| Discriminador | `op` com seis valores lowercase | JOIN/WELCOME/INTENT/ACK/RECEIPT_QUERY/RESYNC | ROOM_JOIN/ROOM_JOINED/ROOM_INTENT/ROOM_EVENT/ROOM_SNAPSHOT/ROOM_REJECT/ROOM_RESYNC | Formatos incompatíveis diretamente; nome do campo discriminador P/T não confirmado em bytes. |
| Sala | `room_id` | identidade da sala, nome wire não confirmado | fixture `arena-test`, nome wire não confirmado | Mapear explicitamente, validar membership; não confundir criar sala com entrar. |
| Intenção idempotente | `client_action_id` | `commandId` | `intentId` | Equivalência funcional de correlação. Definir escopo sala+principal, fingerprint e retenção; não gerar ID novo após UNKNOWN. |
| Revisão esperada | `expected_revision` | `baseRevision` | `revision`/controle de sequência documentados; revisão esperada exata não confirmada | C/P equivalentes como precondição otimista. Em T distinguir revisão recebida da base usada no envio. |
| Revisão resultante | `revision`, monotônica inclusive restore | revisão autoritativa | `revision` e `seq` | Revisão e sequência de transporte não são intercambiáveis. Sem transição automática C→seq. |
| Ator alvo | `actor_id` | sessão determina identidade; campo do alvo não confirmado | `actorId` referido na projeção | Identificador de objeto não prova autorização. Mapear ator pertencente à sessão no servidor. |
| Identidade/papel | Bearer fixture → tabela servidor `SESSIONS` | identidade derivada do servidor; auth real ainda HOLD | perfis DEMO selecionáveis | Seleção DEMO é somente UI; não deve conceder permissão no transporte futuro. Strings literais de roles P/T não auditadas aqui. |
| Evento público | `public_event_id: event-N`, por sala | recibo/evento; campo ID exato não confirmado | `seq` e ROOM_EVENT | Evento, sequência e commandId são entidades diferentes. Não equiparar seus IDs. |
| Ação | apenas `effect.kind: FAKE_SET_LABEL` | MOVE/END_TURN sintéticos na pesquisa; VLAB real HOLD | `MOVE_REQUEST` sintético | Nenhuma equivalência mecânica. Não transformar SET_LABEL em movimento nem inventar XY/dano/PA. |
| Aceite | `ok:true`, resposta de operação | ACK `ACCEPTED` | evento/snapshot confirmado pela fixture | Exigir correlação exata, persistência anterior e revisão/resultado; ACK não é apenas socket.send bem-sucedido. |
| Rejeição | `ok:false`, erro tipado sem eco | ACK `REJECTED` | ROOM_REJECT | Podem ser traduzidos apenas quando resultado final é conhecido. Timeout não é rejeição. |
| Resultado incerto | exceção `TransportUnknown.outcome=UNKNOWN` | estado `UNKNOWN` | pending em RAM; perdas relatadas no adendo | C distingue incerteza de rejeição, mas não persiste pending nem resolve automaticamente reload. T precisa adaptação pelo seu responsável. |
| Recuperação por intenção | dedup durável impede reaplicação; erro DUPLICATE_INTENT | `RECEIPT_QUERY`, recibo persistido com estado/evento | não documentado | **Lacuna C/T:** C não armazena resposta/resultado consultável por ID, nem histórico correlacionado a client_action_id. Não alegar equivalência a RECEIPT_QUERY. |
| Projeção | DTO allowlist no Python, por sessão; correção de tipos aninhados nesta continuação | filtragem recursiva antes de SEND | fixture com payload por papel; backend real não conectado | Só a autoridade confiável pode filtrar antes da transmissão. Validação no cliente/CSS não remove bytes já vazados. |
| Transporte | HTTP loopback, fila por cliente, sem push | WebSocket e WSS local na pesquisa | `transportFactory` substituível, sem rede externa | Uma fábrica substituível permite adaptação futura, mas não elimina auth, reconciliação, framing, CORS/CSP ou WSS. |
| Resync | `view` + `history(after_revision)` | RESYNC e WELCOME | ROOM_RESYNC após lacuna de seq | Snapshot atual não resolve sozinho uma intenção com resultado desconhecido. Necessário consultar recibo além do estado. |
| Hibernação/epoch | nenhum | proposta DO; revalidar sessão/epoch | epoch local ignora callbacks antigos | Epoch cliente evita callback velho, não valida identidade no servidor nem implementa hibernação DO. |
| Tetos | 4 KiB pedido / 64 KiB resposta, 128 eventos | pesquisa documenta 8 KiB de aplicativo | allowlist da fixture; teto exato não confirmado | Negociar o menor limite aplicável; não confundir teto aplicativo com limite da plataforma. |

## Perda de confirmação depois de COMMIT

**C:** estado/evento/registro de intenção são gravados numa transação. Se a resposta
se perde, o cliente lança UNKNOWN. Reenvio manual do mesmo ID é recusado como
DUPLICATE_INTENT, inclusive após reboot: não ocorre segundo efeito. Isso foi
executado no teste original. Porém a tabela contém fingerprint, não recibo
ACCEPTED/REJECTED recuperável. `history` não liga eventos a client_action_id.
Não se pode afirmar que view/history revelam inequivocamente o resultado original,
especialmente depois de outras ações/restore. O chamador também precisa conservar
o comando: C não persiste pending após reload. Essa é uma lacuna de convergência,
não uma garantia já implementada do v2. Não se alterou o wire v1 nesta entrega.

**P:** exige resultado durável e consulta de recibo com o mesmo commandId após
UNKNOWN. O registro descreve testes de perda pós-COMMIT e reentrada/reboot.
Não os reexecutamos nem declaramos integração da POC com esse protocolo.

**T:** o adendo da coordenação relata que disconnect/reset/JOINED/SNAPSHOT e erro
de send limpam pending em RAM. O responsável TEST34 deve persistir intenção/ID
antes do envio, manter UNKNOWN e consultar recibo antes de permitir substituição.
Nenhum arquivo TEST34 foi modificado por esta instância.

## Identidade e segurança da projeção

C usa três tokens `FAKE_TEST_*` deliberadamente públicos. O token deriva papel/ator
fixo no servidor, e actor_id do pedido é conferido contra essa sessão. Todos esses
perfis participam de todas as salas TEST; não há login, convites, revogação ou ACL
real por sala. O roster público sintético contém três atores; não certifica regra
de ocultação de atores da campanha. Player recebe só rótulos públicos e própria
nota; Mestre recebe notas sintéticas. Nenhuma fonte VLAB entra nessa tabela.

O defeito corrigido foi copiar um contêiner inesperado no lugar de um escalar
permitido após adulteração local do banco. Agora cada ator/evento é reconstruído,
metadados extras são omitidos, campos escalares exigem strings válidas e atores
inesperados falham antes da serialização. Falha após submit reverte a transação.
O teste examina bytes emitidos, não só DOM. Isso não classifica automaticamente
uma string secreta mal rotulada como pública; política de visibilidade continua
sendo responsabilidade da autoridade e dos contratos homologados.

## Autoridade de sala versus autoridade mecânica

| Autoridade da sala/integração | Exclusivo do VLAB mecânico autorizado |
| --- | --- |
| Sessões/membership/ACL, serialização de intenções, revisão, IDs e recibos, dedup, ordenação, snapshots de apresentação, resync, projeções e quotas de transporte | Validade mecânica da ação, dano, PA, crítico, defesa, transformação, RNG e recibo mecânico canônico |
| Encaminhar uma intenção validada ao executor e associar a resposta ao recibo da sala | Executar a mecânica uma única vez com identificação/revisão reconhecidas pela interface oficial |
| Checkpoint/restore da sala sintética conforme contrato | Restore mecânico e invariantes de combate, somente se a ABI homologada o permitir |

Parecer **A**: preservar Python como autoridade mecânica; manter **um único owner
do estado autoritativo da sala**, sem três backends concorrentes. Transporte pode
ser separado, mas uma chamada HTTP ao Python dentro de uma transação local não
cria atomicidade distribuída. Antes de integração real definir intenção idempotente
também no executor, reconciliação de recibos após falha intermediária e política
de recuperação que não deixe sala e executor com dois resultados independentes.
O mock atual é prova de transporte sintético, não o executor VLAB.

## Cloudflare / Python Workers — limite comprovado e inferência

A documentação atual admite Python Workers e Durable Objects via bindings; isso
não comprova este programa ou VLAB nessa plataforma. O entrypoint é um handler do
runtime, não `ThreadingHTTPServer`. **Inferência de engenharia:** o CLI CPython,
threads/socket server e banco sqlite3 por caminho local usados aqui precisam de
adaptador de runtime e persistência; não são portabilidade demonstrada.
[Python Workers](https://developers.cloudflare.com/workers/languages/python/).

Python Workers executa via Pyodide/CPython WebAssembly; `threading` e
`multiprocessing` podem ser importados, mas não são funcionais segundo a documentação.
Seu filesystem é em memória; arquivos não são prova de persistência
entre requisições/isolates. Conferir módulos limitados e dependências reais antes
de qualquer adaptação. [Standard library/filesystem](https://developers.cloudflare.com/workers/languages/python/stdlib/).

Em DO SQLite, a API é `ctx.storage.sql` e transações do storage; `sql.exec` não
aceita BEGIN/SAVEPOINT. `transactionSync` exige callback síncrono e reverte em
exceção. **Inferência:** `sqlite3.connect`, PRAGMA e BEGIN IMMEDIATE desta POC não
são substituições diretas dessa API. Um await para executor remoto não cabe na
mesma transação síncrona. [DO storage](https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/).

Nenhum runtime Cloudflare, eviction/hibernação, dependência VLAB, conta/cota ou custo
de hospedagem foi testado. Não declarar CPython/Python Workers equivalentes nem
garantia de serviço gratuito permanente. A escolha A continua condicionada à ABI
privada permitida e testes próprios; B parcial exige autorização por módulo e
corpus diferencial. Conversão total não é recomendada com esta evidência.

Estados preservados: `VLAB_SOURCE_NOT_AVAILABLE`,
`PYTHON_TS_EQUIVALENCE_NOT_TESTED` (alias ASCII do status anterior com ↔),
`ANDROID_REAL_NOT_TESTED`, `VLAB_PRODUCTION_HOLD`.
