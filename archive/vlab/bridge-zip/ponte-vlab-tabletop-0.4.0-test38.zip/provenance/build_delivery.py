import hashlib,json,subprocess,tempfile,zipfile
from pathlib import Path

REPO=Path('/workspace/assimilat-rpg-integracao-test')
WORK=Path('/workspace/work/test38-integration')
OUT=WORK/'delivery'
PREFIX='experiments/tabletop_vlab_bridge/'
BASE='ad73e4fde6ce283e9f85913fb8ad3c639a59c3fb'
COMMIT='5b3f0635a652c9e3949d9fcee67ccef23d31519d'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def sha(blob):return hashlib.sha256(blob).hexdigest()
def pretty(obj):return (json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 assert git('rev-parse','HEAD').decode().strip()==COMMIT and not git('status','--porcelain')
 names=[n for n in git('ls-tree','-r','--name-only',COMMIT,'--',PREFIX).decode().splitlines() if '/delivery/' not in n]
 assert len(names)==40
 data={n:git('show',COMMIT+':'+n) for n in names}
 receipt=json.loads((WORK/'final/receipt.json').read_text())
 assert receipt['status']=='LOCAL-TEST-PASS'
 for n,digest in receipt['files_sha256'].items():assert sha(data[PREFIX+n])==digest
 previous=Path('/workspace/work/test37-integration/delivery/ponte-vlab-tabletop-0.3.0-test-events.zip')
 assert sha(previous.read_bytes())=='78760b79e842f83625daf8c17c2f1bf56c1320a9b35408f949f6fbf82648afda'
 for name in ['baseline-030-red.json','baseline-030-red.log','metadata-red.log','upstream-semantic.log','security-provenance.json']:
  data['evidence/'+name]=(WORK/name).read_bytes()
 for p in sorted((WORK/'final').rglob('*')):
  if p.is_file():data['evidence/final/'+p.relative_to(WORK/'final').as_posix()]=p.read_bytes()
 proofs=[]
 for patch_name,base in [('incremental-from-ad73e4f.patch',BASE),('complete-from-046f6cc.patch','046f6cc3d67ab6f8ae9a5c6eda6eaf03cd8d2267')]:
  patch=git('diff',base,COMMIT,'--binary','--full-index','--',PREFIX,':(exclude)'+PREFIX+'delivery/**')
  data['patches/'+patch_name]=patch
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);subprocess.run(['git','init','-q'],cwd=root,check=True)
   if base==BASE:
    for n in git('ls-tree','-r','--name-only',base,'--',PREFIX).decode().splitlines():
     if '/delivery/' in n:continue
     p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(git('show',base+':'+n))
   for args in [['apply','--check','-'],['apply','-']]:subprocess.run(['git',*args],cwd=root,input=patch,check=True)
   actual={p.relative_to(root).as_posix():p.read_bytes() for p in (root/PREFIX).rglob('*') if p.is_file()}
   assert actual=={n:data[n] for n in names}
  proofs.append({'patch':patch_name,'git_apply_check':'PASS','applied_sources_equal':'40/40'})
 data['evidence/patch-proofs.json']=pretty(proofs)
 data['provenance/history.txt']=git('log','-3','--format=%H%nparents: %P%n%s')
 data['provenance/build_delivery.py']=Path(__file__).read_bytes()
 gates=json.loads(data[PREFIX+'arena_compatibility.json'])['gates']
 data['VERSION.json']=pretty({'version':'0.4.0','source_commit':COMMIT,'baseline_commit':BASE,
  'branch':'test/tabletop-vlab-bridge-poc','gates':gates,'physical_frontend':'TEST38 original five files',
  'scope':'CHROMIUM_LINUX_LOCAL_HTTP_SYNTHETIC_VISUAL','push_PR_merge_deploy':False,
  'holds':['VLAB_SOURCE_NOT_AVAILABLE','PYTHON_TS_EQUIVALENCE_NOT_TESTED','ANDROID_REAL_NOT_TESTED','VLAB_PRODUCTION_HOLD']})
 flow=json.loads((WORK/'final/arena/browser-wire.json').read_text())
 report=f'''# PSV — Ponte 0.4.0 / integração física TEST38

**ANTES → DEPOIS:** a ponte 0.3.0 e o TEST38 rejeitavam mutuamente seus envelopes.
Agora os módulos reais TEST38 comunicam com a mesma Authority HTTP/SQLite,
importam uma cena visual explicitamente, enviam intenção, recebem evento/ACK e
apresentam posição/recibo. Uma confirmação perdida após COMMIT é recuperada
pelo cliente original após matar e reiniciar o processo servidor, sem reaplicar.

**VERSÃO:** branch test/tabletop-vlab-bridge-poc, commit `{COMMIT}`.
Baseline `{BASE}` e seus pacotes preservados. 41 arquivos anteriores à ponte
intactos, 5 arquivos TEST38 copiados byte a byte, sem edição do original. O
receipt_contract.py permanece igual; um único receipt writer foi compartilhado.

**FONTES FÍSICAS:** TEST38 SHA 085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c,
CRC e manifesto 46/46; PESQ017 SHA ef8329c42ff49064e6863577079204c97f6d23907ffef300ca53cb64a0c1ea32,
CRC e manifesto 31/31. Usados os anexos diretamente, sem novo bloqueio Library.
Relatórios/canários PESQ017 confrontados; nenhum overlay de recibo foi importado.

**FUNCIONALIDADE NOVA:** um fluxo vertical visual reutilizável, com recuperação.
Incompatibilidades resolvidas: JOIN/identidade fixture vinculada; WELCOME geométrico;
mapa/bindings de origem explícita; ACK/recibo persistido; RESYNC/SNAPSHOT;
RECEIPT NOT_FOUND/UNKNOWN; lote HTTP separado em frames v2 reais; projeção por
destinatário. Uma tabela máquina-legível e refs dos testes estão em
arena_compatibility.json e TEST38_PROVENANCE.json, junto aos fontes.

**DEMOSTRAÇÃO MANUAL** (PC/navegador, Python+SQLite, sem Node/build para abrir):

```sh
mkdir -p work
python3 experiments/tabletop_vlab_bridge/authority.py --db work/arena-test.sqlite --arena --port 8765
```

Abrir http://127.0.0.1:8765/ no mesmo computador. Clicar no banner **Mestre TEST:
importar cena atual**. No painel Sala compartilhada escolher v2 e Player1,
entrar, selecionar E e um destino vazio. A posição/ACCEPTED aparece no quadro
da Sala existente (`roomGrid`). O guia ARENA_TEST38.md detalha limites e passos.
O editor/Arena principal e o botão de ataque NÃO foram integrados por este
executor. Não se apresenta esse quadro remoto como batalha oficial ou sync
automático do editor. Integração da ação tática é do Desenvolvedor.

**GEOMETRIA:** vem da scene() real do frontend por importação explícita Mestre
TEST. Não existe mapa inventado a partir de labels ou bootstrap automático.
Bindings u1→actor-1/p1, u2→actor-2/p2, u3→actor-m/NPC são explícitos. Origem e
hash ficam no genesis do mesmo SQLite. Fonte sintética não vira campanha canônica.
Viewers/ownership são conferidos no servidor, markers Mestre-only, recursos e
notas do editor não são importados. Limite desta fatia: três unidades.

**RECIBO REAL RECUPERADO:** commandId `{flow['recovered_id']}`,
receipt_id `{flow['persisted_receipt']['receipt_id']}`, revisão 2/event-2.
Teste observou UNKNOWN após socket fechado pós-COMMIT, preservou ID/journal,
reiniciou processo, recuperou o recibo idêntico e posição x=3/y=2. Exatamente
dois eventos para duas intenções visuais; reenvio da primeira não criou terceiro.
RECEIPT_QUERY usa o dono; ausência/alheio responde NOT_FOUND, não rejeição.

**EVENTOS / ORDEM:** o lote de saída é validado pelo validador original TEST38
e separado em EVENT/ACK, não em mensagem EVENT_BATCH desconhecida. Não converter
FAKE_SET_LABEL em movimento. A correção ROOM_UPDATED→MOVE_CONFIRMED já feita
pelo Desenvolvedor foi preservada e sua regressão 2/2 passou, sem nova conquista.
Seq é persistido e esta fatia exige um evento por revisão; igualdade é verificada,
não inferida como regra universal de VLAB. RESYNC é SNAPSHOT atual, não histórico.

**PROVAS EXECUTADAS:**

| Prova | Resultado |
|---|---|
| Baseline 0.3.0 contra novo requisito | RED: bootstrap geométrico rejeitado, exit1 |
| Falha nova de metadados corrompidos | RED: sessionEpoch aninhado; GREEN após validação antes dos bytes |
| Novos testes | 8/8 Python, um navegador real incluído |
| Suíte atual completa da ponte | 76/76 Python PASS, contendo 50/50 Node (15+12+23) |
| TypeScript 5.9.3 | strict PASS, exit0 |
| Regressão semântica original TEST38 | 2/2 PASS, separada dos novos testes |
| Patches completo e incremental | aplicação/check + igualdade de 40/40 fontes PASS |
| Suíte geral antiga 55 | não repetida: seus 41 fontes intactos |
| VLAB oficial, WSS, Cloudflare, Android físico | 0 execuções; HOLD |

Comandos efetivos/reprodução:

```sh
PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_arena_integration -v
python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/arena-checks
```

Testes browser exigem Playwright Python e Chromium. Ambiente: Python3.12.14,
Node24.19, Chromium154 Linux. Node/tsc são para regressão, não para servir a UI.
Timestamps UTC observados no receipt.json; não alegar minutos de programação.
Os 68 testes anteriores são regressões, não funcionalidades novas.

**SEGURANÇA:** inspecionados bytes HTTP antes da adaptação. JOIN com ticket de
outro papel, unidade alheia, campos adicionais, nesting, Origin externo e estado
corrompido rejeitados/sanitizados. P1/P2 recebem somente unidades autorizadas.
Uma segunda página real p2 executou JOIN/RESYNC sem receber u1/u3 ou comando p1.
Isso é teste de projeção no mesmo host; não prova dois dispositivos nem auth real.
Tokens FAKE_TEST são públicos e deliberados. Interface original é MESTRE-SIDE TEST,
não aplicativo Party homologado. Nenhum dado real de Party/campanha/VLAB ou
credencial real entrou no pacote. Erros não ecoam estado/trace privado.

**VLAB:** ATTACK_REQUEST existente continua MECHANICS_UNAVAILABLE com recibo
persistente e zero alteração de recursos/eventos. A primeira operação mecânica
depende de ABI competente/homologada e vínculo tático frontend→sala→VLAB.
Não calcular dano/PA/Vida/Alma nem promover motor antigo/fixture a oficial.

**GATES:** A PASS módulos físicos/HTTP local; B PASS movimento visual TEST;
C PASS perda pós-COMMIT + reinício real local + cliente original; D PASS somente
projeção HTTP e identidades sintéticas. E HOLD ABI VLAB; F HOLD aparelhos distintos.
NAC-PASS-02 proporcional: nenhum PASS de combate ou produção.

**CUSTÓDIA:** ZIP novo 0.4.0 com 40 fontes/config/docs (incluindo cinco originais
TEST38), patches, logs, capturas PNG e wire, manifesto e SHA. Sem sobrescrever
0.3.0. O hash do ZIP fechado fica no sidecar externo, evitando circularidade.
Download/links serão verificados após envio ao Drive privado e registrados no
recibo da entrega. Sem push, PR, merge, deploy ou custo adicional em serviços.

**LAST-VERIFIED-UNIT:** TEST38 real→HTTP→COMMIT/recibo→UNKNOWN→restart→TEST38,
com apresentação no quadro da Sala e inspeção de bytes. **FIRST-PENDING:** ABI
VLAB e ligação do botão tático da Arena principal pelo executor responsável.
**NEXT:** integrar esse frontend ao mesmo caminho e testar uma decisão oficial
quando disponível/autorizada. **NO-REPEAT:** Arena, outbox/journal, backend,
recibos, bug TEST38 corrigido, pesquisas e motores.

VLAB_SOURCE_NOT_AVAILABLE; PYTHON_TS_EQUIVALENCE_NOT_TESTED;
ANDROID_REAL_NOT_TESTED; VLAB_PRODUCTION_HOLD. GH-NOT-RUN.
'''
 report_name='PSV-ponte-vlab-tabletop-0.4.0.md';data[report_name]=report.encode()
 manifest={'version':'0.4.0','source_commit':COMMIT,'baseline':BASE,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(data.items())]}
 data['MANIFEST.json']=pretty(manifest)
 data['SHA256SUMS']=''.join(f'{sha(b)}  {n}\n' for n,b in sorted(data.items())).encode()
 target=OUT/'ponte-vlab-tabletop-0.4.0-test38.zip'
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(data.items()):
   info=zipfile.ZipInfo(n,date_time=(2026,10,24,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b,compresslevel=9)
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(data)
  assert all(z.read(n)==b for n,b in data.items())
 digest=sha(target.read_bytes());(OUT/(target.name+'.sha256')).write_text(f'{digest}  {target.name}\n');(OUT/report_name).write_bytes(data[report_name])
 proof={'status':'PASS_LOCAL_PACKAGE','commit':COMMIT,'bytes':target.stat().st_size,'entries':len(data),'manifest_files':len(manifest['files']),'sha256sum_records':len(data)-1,'sha256':digest,'patches':proofs}
 (OUT/'build-receipt.json').write_bytes(pretty(proof));print(json.dumps(proof,indent=2))

if __name__=='__main__':main()
