"""Physical TEST38 browser + existing HTTP/SQLite Authority, synthetic visual only."""
import copy
import hashlib
import http.client
import json
import os
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path

import authority as a
import arena_room as ar

HERE=Path(__file__).resolve().parent
OUT=Path(os.environ.get('ARENA_EVIDENCE_DIR', str(HERE.parents[1]/'work'/'arena-evidence')))


def bootstrap():
    # Unit tests only. Browser test imports coordinates from actual TEST38 scene().
    return {'schema_version':3,'op':'arena_bootstrap','room_id':'arena-test',
        'snapshot':{'sceneId':'test-scene','n':7,'walls':['3,3'],'markers':[{'id':'secret_marker','x':0,'y':0,'label':'FAKE_MASTER_MARKER'}],
          'units':[{'id':'u1','name':'P1 TEST','mark':'E','team':'ally','ownerId':'p1','x':1,'y':1},
                   {'id':'u2','name':'FAKE_P2_UNIT','mark':'C','team':'ally','ownerId':'p2','x':1,'y':3}]},
        'bindings':{'u1':{'actor_id':'actor-1','viewers':['gm','p1']},'u2':{'actor_id':'actor-2','viewers':['gm','p2']}},
        'provenance':{'source':'TEST38_EXPLICIT_VISUAL_IMPORT','frontend_sha256':ar.FRONTEND_SHA}}


def frame(message_type,**kw):return {'schema_version':3,'op':'arena','frame':{'v':2,'type':message_type,'roomId':'arena-test',**kw}}
def move(command='move_1',revision=0,x=2,y=2,unit='u1'):
    return frame('INTENT',commandId=command,baseRevision=revision,kind='MOVE_VISUAL_TEST',unitId=unit,payload={'x':x,'y':y})


class ArenaAuthorityTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'arena.sqlite';self.backend=a.Authority(self.path)
        self.assertEqual(self.call(bootstrap(),'MASTER')[0],200)

    def call(self,p,profile='PLAYER1'):
        status,raw=self.backend.handle(a.encode(p).encode(),'FAKE_TEST_'+profile)
        if profile!='MASTER':
            for private in ['FAKE_MASTER_MARKER','FAKE_MASTER_ONLY','private_notes','FAKE_P2_UNIT','fingerprint','FAKE_NESTED_SECRET']:
                self.assertNotIn(private,raw.decode())
        return status,json.loads(raw)

    def test_approved_snapshot_ack_resync_not_found_and_shared_receipt(self):
        joined=self.call(frame('JOIN',ticket='test-local-p1'))[1]['frames'][0]
        self.assertEqual([u['id'] for u in joined['snapshot']['units']],['u1'])
        applied=self.call(move())[1];receipt=applied['receipt']
        self.assertEqual([f['type'] for f in applied['frames']],['EVENT','ACK'])
        self.assertEqual(applied['frames'][0]['kind'],'MOVE_VISUAL_TEST')
        self.assertEqual(self.call(move())[1]['receipt'],receipt)
        self.backend=a.Authority(self.path)
        self.assertEqual(self.call(frame('RECEIPT_QUERY',commandId='move_1'))[1]['receipt'],receipt)
        resync=self.call(frame('RESYNC',afterRevision=0))[1]['frames'][0]
        self.assertEqual(resync['type'],'SNAPSHOT');self.assertEqual(resync['revision'],1)
        miss=self.call(frame('RECEIPT_QUERY',commandId='missing'))[1]
        self.assertEqual(miss['frames'][0]['status'],'NOT_FOUND');self.assertIsNone(miss['receipt'])
        with sqlite3.connect(self.path) as db:self.assertEqual(db.execute('SELECT count(*) FROM events').fetchone()[0],1)

    def test_acl_ticket_forgery_conflict_stale_and_terminal_rejection(self):
        self.assertEqual(self.call(frame('JOIN',ticket='test-local-gm'))[0],403)
        denied=self.call(move(unit='u2'))[1];self.assertEqual(denied['frames'][0]['reason'],'UNAUTHORIZED')
        self.assertEqual(self.call(frame('RECEIPT_QUERY',commandId='move_1'))[1]['receipt'],denied['receipt'])
        # Different identity cannot recover another's terminal result.
        raw=self.backend.handle(a.encode(frame('RECEIPT_QUERY',commandId='move_1')).encode(),'FAKE_TEST_PLAYER2')[1]
        self.assertEqual(json.loads(raw)['frames'][0]['status'],'NOT_FOUND')
        self.assertEqual(self.call(move(x=3))[0],409)
        self.assertEqual(self.call(move('valid'))[1]['receipt']['status'],'ACCEPTED')
        stale=self.call(move('stale',0,x=4))[1]
        self.assertEqual(stale['receipt']['code'],'STALE_REVISION')
        self.assertEqual(self.call(move('stale',0,x=4))[1]['receipt'],stale['receipt'])

    def test_malformed_and_nested_wire_or_stored_snapshot_fail_before_projection(self):
        for field,value in [('role','master'),('payload',{'x':2,'y':2,'private':{'value':'FAKE_NESTED_SECRET'}}),('unitId',[]),('baseRevision',True)]:
            req=move();req['frame'][field]=value;self.assertEqual(self.call(req)[0],400)
        with sqlite3.connect(self.path) as db:
            state=json.loads(db.execute('SELECT state FROM rooms').fetchone()[0])
            state['visual']['snapshot']['units'][0]['name']={'secret':'FAKE_NESTED_SECRET'}
            db.execute('UPDATE rooms SET state=?',(a.encode(state),))
        self.assertNotEqual(self.call(frame('JOIN',ticket='test-local-p1'))[0],200)

    def test_reserved_metadata_corruption_never_reaches_wire(self):
        with sqlite3.connect(self.path) as db:original=db.execute('SELECT state FROM rooms').fetchone()[0]
        for key in ['sessionEpoch','seq','scene_sha256']:
            state=json.loads(original);state['visual'][key]={'private':'FAKE_NESTED_SECRET'}
            with sqlite3.connect(self.path) as db:db.execute('UPDATE rooms SET state=?',(a.encode(state),))
            self.assertNotEqual(self.call(frame('JOIN',ticket='test-local-p1'))[0],200)

    def test_transaction_rollback_and_concurrent_revision(self):
        def fail_commit(point):
            if point=='before_commit':raise RuntimeError('injected')
        self.backend._fault=fail_commit
        self.assertEqual(self.call(move())[0],500)
        self.backend._fault=lambda point:None
        self.assertEqual(self.call(frame('RECEIPT_QUERY',commandId='move_1'))[1]['frames'][0]['status'],'NOT_FOUND')
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            values=list(pool.map(lambda req:self.call(req)[1]['receipt'],[move('race_a'),move('race_b',x=4)]))
        self.assertEqual(sorted(r['status'] for r in values),['ACCEPTED','REJECTED'])

    def test_label_is_not_movement_and_tactical_request_stops_at_vlab_boundary(self):
        common={'schema_version':2,'op':'submit','room_id':'arena-test','client_action_id':'label_attempt',
                'expected_revision':0,'actor_id':'actor-1'}
        label=common|{'effect':{'kind':'FAKE_SET_LABEL','label':'Never movement'}}
        self.assertEqual(self.call(label)[1]['receipt']['code'],'UNKNOWN_EFFECT')
        attack=common|{'client_action_id':'attack_hold','action':{'kind':'ATTACK_REQUEST','turn_id':'turn-test-1',
            'target':{'kind':'UNIT','actor_id':'actor-2'},'context':{'scene_id':'test-scene','ability_id':'basic-attack'}}}
        receipt=self.call(attack)[1]['receipt']
        self.assertEqual(receipt['code'],'MECHANICS_UNAVAILABLE');self.assertIsNone(receipt['mechanical_result_ref'])
        self.assertIsNone(receipt['public_event_id'])
        query={'schema_version':2,'op':'receipt_query','room_id':'arena-test','client_action_id':'attack_hold'}
        self.assertEqual(self.call(query)[1]['receipt'],receipt)
        with sqlite3.connect(self.path) as db:
            self.assertEqual(db.execute('SELECT count(*) FROM events').fetchone()[0],0)
            self.assertEqual(db.execute('SELECT revision FROM rooms').fetchone()[0],0)

    def test_raw_http_projection_errors_origin_and_recipient_boundaries(self):
        server=a.make_server(self.backend);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        captures=[]
        try:
            def send(req,token='FAKE_TEST_PLAYER1',origin=None):
                c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
                headers={'Content-Type':'application/json','Authorization':'Bearer '+token}
                if origin:headers['Origin']=origin
                c.request('POST','/bridge',a.encode(req),headers);r=c.getresponse();raw=r.read().decode();status=r.status
                self.assertIsNone(r.getheader('Access-Control-Allow-Origin'));c.close()
                for secret in ['FAKE_NESTED_SECRET','FAKE_MASTER_MARKER','FAKE_P2_UNIT','private_notes','Traceback']:
                    self.assertNotIn(secret,raw)
                captures.append({'status':status,'request':req,'response':raw});return status
            self.assertEqual(send(frame('JOIN',ticket='test-local-p1')),200)
            self.assertEqual(send(frame('JOIN',ticket='test-local-gm')),403)
            self.assertEqual(send(frame('JOIN',ticket='test-local-p1'),origin='https://untrusted.invalid'),403)
            bad=move();bad['frame']['profile']={'role':'gm','secret':'FAKE_NESTED_SECRET'}
            self.assertEqual(send(bad),400)
            with sqlite3.connect(self.path) as db:
                state=json.loads(db.execute('SELECT state FROM rooms').fetchone()[0])
                state['visual']['sessionEpoch']={'private':'FAKE_NESTED_SECRET'}
                db.execute('UPDATE rooms SET state=?',(a.encode(state),))
            self.assertNotEqual(send(frame('JOIN',ticket='test-local-p1')),200)
            OUT.mkdir(parents=True,exist_ok=True)
            (OUT/'negative-http-wire.json').write_text(json.dumps(captures,indent=2)+'\n')
        finally:server.shutdown();server.server_close();thread.join(timeout=5)


class PhysicalTEST38Browser(unittest.TestCase):
    def test_browser_visual_commit_lost_socket_restart_receipt_and_render(self):
        from playwright.sync_api import sync_playwright
        OUT.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory() as temp:
            db=Path(temp)/'browser.sqlite'
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            proc=None
            def start(drop=False):
                nonlocal proc
                child='''import sys,json,authority as a
b=a.Authority(sys.argv[1]); armed=sys.argv[3]=='drop'
def fault(point):
 global armed
 if point=='after_commit' and armed:
  armed=False
  raise a.ReplyLost()
b._fault=fault
s=a.make_server(b,int(sys.argv[2]),arena_assets=True)
print('READY',flush=True);s.serve_forever()
'''
                proc=subprocess.Popen([sys.executable,'-c',child,str(db),str(port),'drop' if drop else 'normal'],cwd=HERE,
                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                self.assertEqual(proc.stdout.readline().strip(),'READY')
            def stop():
                if proc and proc.poll() is None:proc.kill();proc.wait(timeout=5)
                if proc:proc.stdout.close();proc.stderr.close()
            start()
            try:
                with sync_playwright() as pw:
                    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                    page=browser.new_page(viewport={'width':1100,'height':850})
                    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                    page.goto(f'http://127.0.0.1:{port}/')
                    page.wait_for_function('() => !!window.PonteTEST')
                    source=page.evaluate('window.__tabletopTEST.scene()')
                    page.click('#bridgeImport');page.wait_for_function('() => document.getElementById("bridgeResult").textContent.includes("SHA")')
                    page.select_option('#roomProtocol','v2');page.select_option('#roomProfile','p1');page.click('#roomConnect')
                    page.wait_for_function('() => window.TabletopRoomTEST.client.connected')
                    snap=page.evaluate('window.TabletopRoomTEST.client.snapshot')
                    self.assertEqual(snap['units'][0]['x'],source['units'][0]['x'])
                    self.assertEqual(snap['units'][0]['id'],'u1')
                    page.locator('#roomGrid .roomCell').nth(8).click();page.locator('#roomGrid .roomCell').nth(16).click()
                    page.wait_for_function('() => window.TabletopRoomTEST.client.lastReceipt?.status==="ACCEPTED"')
                    self.assertEqual(page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].x'),2)
                    self.assertEqual(page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].y'),2)
                    self.assertIn('ACCEPTED',page.inner_text('#roomLastOutcome'))
                    self.assertEqual(page.evaluate('window.TabletopRoomTEST.client.lastRoomEvent.kind'),'MOVE_CONFIRMED')
                    # Native same-origin process restarts, existing JS and journal remain.
                    page.click('#roomDisconnect');stop();start(drop=True)
                    page.click('#roomConnect');page.wait_for_function('() => window.TabletopRoomTEST.client.connected')
                    page.locator('#roomGrid .roomCell').nth(16).click();page.locator('#roomGrid .roomCell').nth(17).click()
                    page.wait_for_function('() => window.TabletopRoomTEST.client.status==="unknown"')
                    pending=page.evaluate('[...window.TabletopRoomTEST.client.pending.values()][0].payload.intentId')
                    with sqlite3.connect(db) as sql:
                        saved=json.loads(sql.execute('SELECT receipt FROM receipts WHERE action_id=?',(pending,)).fetchone()[0])
                        self.assertEqual(sql.execute('SELECT count(*) FROM events').fetchone()[0],2)
                    self.assertEqual(saved['status'],'ACCEPTED')
                    page.screenshot(path=str(OUT/'TEST38_UNKNOWN.png'),full_page=True)
                    stop();start()
                    page.click('#roomConnect')
                    page.wait_for_function('() => window.TabletopRoomTEST.client.connected && window.TabletopRoomTEST.client.lastReceipt?.status==="ACCEPTED" && window.TabletopRoomTEST.client.pending.size===0')
                    self.assertEqual(page.evaluate('window.TabletopRoomTEST.client.lastReceipt.intentId'),pending)
                    self.assertEqual(page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].x'),3)
                    page.click('#roomResync');page.wait_for_timeout(150)
                    self.assertTrue(page.evaluate('window.TabletopRoomTEST.client.connected'))
                    replay=page.evaluate('''async () => {const sent=window.PonteTEST.wire.find(x=>x.request.frame?.type==='INTENT').request;
                      return await window.PonteTEST.request(sent,'p1');}''')
                    self.assertEqual(replay['receipt']['revision'],1)
                    with sqlite3.connect(db) as sql:self.assertEqual(sql.execute('SELECT count(*) FROM events').fetchone()[0],2)
                    wire=page.evaluate('window.PonteTEST.wire')
                    query=[x for x in wire if x['request'].get('frame',{}).get('type')=='RECEIPT_QUERY'][-1]
                    self.assertEqual(json.loads(query['body'])['receipt'],saved)
                    for item in wire:
                        if item['profile']=='p1':
                            for marker in ['private_notes','FAKE_MASTER_ONLY','Conjurador','Criatura','"u2"','"u3"']:
                                self.assertNotIn(marker,item['body'])
                    other=browser.new_page();other.goto(f'http://127.0.0.1:{port}/')
                    other.wait_for_function('() => !!window.PonteTEST')
                    other.select_option('#roomProtocol','v2');other.select_option('#roomProfile','p2');other.click('#roomConnect')
                    other.wait_for_function('() => window.TabletopRoomTEST.client.connected')
                    self.assertEqual(other.evaluate('window.TabletopRoomTEST.client.snapshot.units.map(u=>u.id)'),['u2'])
                    other.click('#roomResync');other.wait_for_timeout(100)
                    other_wire=other.evaluate('window.PonteTEST.wire')
                    for item in other_wire:
                        self.assertNotIn('"u1"',item['body']);self.assertNotIn('"u3"',item['body'])
                        self.assertNotIn(pending,item['body'])
                    self.assertFalse(errors,errors)
                    page.screenshot(path=str(OUT/'TEST38_RECEIPT_RECOVERED.png'),full_page=True)
                    (OUT/'browser-wire.json').write_text(json.dumps({'scope':'CHROMIUM_LINUX_LOCAL_HTTP_REAL_TEST38_SYNTHETIC_VISUAL',
                        'source_scene':source,'recovered_id':pending,'persisted_receipt':saved,'wire':wire,'player2_wire':other_wire,'page_errors':errors,
                        'official_mechanics':False,'events_applied':2},indent=2)+'\n')
                    browser.close()
            finally:stop()


if __name__=='__main__':unittest.main()
