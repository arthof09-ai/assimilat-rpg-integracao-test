"""TEST38 extension of the existing Authority/transaction/receipt store. No mechanics."""
import copy
import hashlib
import json
import re
import uuid

FRONTEND_SHA = '085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c'
PROFILES = {'master': 'gm', 'player1': 'p1', 'player2': 'p2'}
ACTORS = {'actor-m': None, 'actor-1': 'p1', 'actor-2': 'p2'}


def check(ok):
    if not ok:
        import authority as a
        a.fail('INVALID_SCHEMA')


def exact(obj, keys):
    check(type(obj) is dict and set(obj) == set(keys))


def ident(value):
    check(type(value) is str and re.fullmatch('[a-z][a-z0-9_-]{0,31}', value) and value not in {'constructor','prototype','__proto__'})


def nat(value, limit=128):
    check(type(value) is int and 0 <= value <= limit)


def text(value, maximum):
    check(type(value) is str and 1 <= len(value.encode('utf-16-le'))//2 <= maximum and
          not any(ord(c) < 32 or c in '<>' for c in value))


def snapshot(s):
    exact(s, ['sceneId','n','walls','units','markers']); ident(s['sceneId'])
    check(type(s['n']) is int and s['n'] in [5,7,10,20])
    check(type(s['walls']) is list and len(s['walls']) <= s['n']**2)
    check(type(s['units']) is list and 1 <= len(s['units']) <= 3)
    check(type(s['markers']) is list and len(s['markers']) <= 40)
    walls=set()
    for cell in s['walls']:
        check(type(cell) is str and re.fullmatch('(0|[1-9][0-9]*),(0|[1-9][0-9]*)', cell))
        x,y=map(int,cell.split(','));nat(x,s['n']-1);nat(y,s['n']-1)
        check(cell not in walls);walls.add(cell)
    occupied=set();ids=set()
    for u in s['units']:
        exact(u,['id','name','mark','team','ownerId','x','y']);ident(u['id'])
        text(u['name'],45);text(u['mark'],2)
        check(u['team'] in ['ally','enemy','neutral'] and u['ownerId'] in [None,'gm','p1','p2'])
        nat(u['x'],s['n']-1);nat(u['y'],s['n']-1)
        cell=f"{u['x']},{u['y']}";check(cell not in occupied and cell not in walls and u['id'] not in ids)
        occupied.add(cell);ids.add(u['id'])
    markers=set()
    for m in s['markers']:
        exact(m,['id','x','y','label']);ident(m['id']);text(m['label'],100)
        nat(m['x'],s['n']-1);nat(m['y'],s['n']-1);check(m['id'] not in markers);markers.add(m['id'])


def validate(req):
    check(type(req) is dict and req.get('schema_version') == 3)
    if req.get('op') == 'arena_bootstrap':
        exact(req,['schema_version','op','room_id','snapshot','bindings','provenance'])
        check(req['room_id']=='arena-test');snapshot(req['snapshot'])
        exact(req['provenance'],['source','frontend_sha256'])
        check(req['provenance']=={'source':'TEST38_EXPLICIT_VISUAL_IMPORT','frontend_sha256':FRONTEND_SHA})
        bindings=req['bindings'];exact(bindings,[u['id'] for u in req['snapshot']['units']])
        actors=set()
        for u in req['snapshot']['units']:
            b=bindings[u['id']];exact(b,['actor_id','viewers'])
            check(type(b['actor_id']) is str and b['actor_id'] in ACTORS and b['actor_id'] not in actors)
            actors.add(b['actor_id']);check(u['ownerId']==ACTORS[b['actor_id']])
            check(type(b['viewers']) is list and all(type(x) is str and x in ['gm','p1','p2'] for x in b['viewers']))
            check(len(b['viewers'])==len(set(b['viewers'])) and 'gm' in b['viewers'])
            check(u['ownerId'] is None or u['ownerId'] in b['viewers'])
        return
    exact(req,['schema_version','op','frame']);check(req['op']=='arena')
    f=req['frame'];check(type(f) is dict and type(f.get('v')) is int and f['v']==2 and f.get('roomId')=='arena-test')
    common=['v','type','roomId'];kind=f.get('type')
    if kind=='JOIN':
        exact(f,common+['ticket']);check(type(f['ticket']) is str and f['ticket'] in ['test-local-gm','test-local-p1','test-local-p2'])
    elif kind=='RESYNC':exact(f,common+['afterRevision']);nat(f['afterRevision'])
    elif kind=='RECEIPT_QUERY':exact(f,common+['commandId']);ident(f['commandId'])
    elif kind=='INTENT':
        exact(f,common+['commandId','baseRevision','kind','unitId','payload']);ident(f['commandId']);ident(f['unitId'])
        nat(f['baseRevision']);check(f['kind']=='MOVE_VISUAL_TEST');exact(f['payload'],['x','y'])
        nat(f['payload']['x'],19);nat(f['payload']['y'],19)
    else:check(False)


def projection(visual, profile):
    exact(visual,['snapshot','bindings','provenance','scene_sha256','seq','sessionEpoch'])
    nat(visual['seq']);nat(visual['sessionEpoch'],2**53-1);check(visual['sessionEpoch']>0)
    check(type(visual['scene_sha256']) is str and re.fullmatch('[0-9a-f]{64}',visual['scene_sha256']))
    s=visual['snapshot'];snapshot(s)
    # Revalidate stored audience metadata, never serialize arbitrary nested state.
    validate({'schema_version':3,'op':'arena_bootstrap','room_id':'arena-test','snapshot':s,
              'bindings':visual['bindings'],'provenance':visual['provenance']})
    out={k:copy.deepcopy(s[k]) for k in ['sceneId','n','walls']}
    out['units']=[dict(u) for u in s['units'] if profile in visual['bindings'][u['id']]['viewers']]
    # Imported markers are MASTER-ONLY in this first slice; never silently public.
    out['markers']=copy.deepcopy(s['markers']) if profile=='gm' else []
    return out


def reduce(state,event):
    exact(event,['kind','unit_id','x','y','command_id','seq','public_event_id'])
    check(event['kind']=='TEST38_VISUAL_MOVE');ident(event['unit_id']);ident(event['command_id'])
    nat(event['seq']);check(event['public_event_id']==f"event-{event['seq']}")
    result=copy.deepcopy(state);v=result['visual'];s=v['snapshot'];snapshot(s)
    check(event['seq']==v['seq']+1);nat(event['x'],s['n']-1);nat(event['y'],s['n']-1)
    u=next(x for x in s['units'] if x['id']==event['unit_id'])
    check((u['x'],u['y'])!=(event['x'],event['y']))
    check(f"{event['x']},{event['y']}" not in s['walls'])
    check(not any(x['id']!=u['id'] and (x['x'],x['y'])==(event['x'],event['y']) for x in s['units']))
    u['x'],u['y']=event['x'],event['y'];v['seq']=event['seq'];projection(v,'gm')
    return result


def frame_receipt(receipt, room, command):
    base={'v':2,'type':'ACK','roomId':room,'commandId':command,'status':receipt['status']}
    if receipt['status']=='ACCEPTED':base.update(revision=receipt['revision'],eventId=receipt['public_event_id'])
    else:
        reason={'FORBIDDEN':'UNAUTHORIZED','STALE_REVISION':'STALE_REVISION','UNKNOWN_EFFECT':'INVALID_INTENT',
                'MECHANICS_UNAVAILABLE':'MECHANICS_HOLD','LIMIT_EXCEEDED':'ROOM_ERROR'}[receipt['code']]
        base.update(reason=reason,currentRevision=receipt['revision'])
    return base


def dispatch(authority,db,req,role,actor):
    import authority as a
    profile=PROFILES[role];room='arena-test'
    if req['op']=='arena_bootstrap':
        if role!='master':a.fail('FORBIDDEN')
        if db.execute('SELECT 1 FROM rooms WHERE room_id=?',(room,)).fetchone():a.fail('INVALID_SCHEMA')
        if db.execute('SELECT count(*) FROM rooms').fetchone()[0]>=a.MAX_ROOMS:a.fail('LIMIT_EXCEEDED')
        scene_hash=hashlib.sha256(a.encode(req['snapshot']).encode()).hexdigest()
        state=copy.deepcopy(a.SEED);state['visual']={k:copy.deepcopy(req[k]) for k in ['snapshot','bindings','provenance']}
        state['visual'].update(scene_sha256=scene_hash,seq=0,sessionEpoch=uuid.uuid4().int % (2**52)+1)
        projection(state['visual'],'gm')
        db.execute('INSERT INTO rooms VALUES (?,?,?)',(room,0,a.encode(state)))
        db.execute('INSERT INTO arena_genesis VALUES (?,?)',(room,a.encode(state)))
        return {'schema_version':3,'op':'arena_bootstrap','ok':True,'revision':0,'scene_sha256':scene_hash}
    f=req['frame'];row=db.execute('SELECT revision,state FROM rooms WHERE room_id=?',(room,)).fetchone()
    if not row:a.fail('FORBIDDEN')
    revision,state=row[0],json.loads(row[1]);v=state['visual'];projected=projection(v,profile)
    if v['seq']!=revision:a.fail('INTERNAL_ERROR') # explicit one-event/one-revision TEST38 constraint
    base={'v':2,'roomId':room};frames=[];receipt=None
    if f['type']=='JOIN':
        if f['ticket']!='test-local-'+profile:a.fail('FORBIDDEN')
        frames=[base|{'type':'WELCOME','participantId':profile,'role':'MASTER' if role=='master' else 'PLAYER',
             'revision':revision,'sessionEpoch':v['sessionEpoch'],'snapshot':projected,
             'members':[{'id':p,'label':p+' TEST','role':'MASTER' if p=='gm' else 'PLAYER'} for p in ['gm','p1','p2']]}]
    elif f['type']=='RESYNC':
        if f['afterRevision']>revision:a.fail('STALE_REVISION')
        frames=[base|{'type':'SNAPSHOT','revision':revision,'snapshot':projected}]
    else:
        command=f['commandId'];original=authority.load_receipt(db,room,role,command)
        if f['type']=='RECEIPT_QUERY':
            if original:receipt=original[1];frames=[frame_receipt(receipt,room,command)]
            else:frames=[base|{'type':'RECEIPT','commandId':command,'status':'NOT_FOUND'}]
        elif original:
            if original[0]!=a.encode(req):a.fail('ID_REUSE_CONFLICT')
            receipt=original[1];frames=[frame_receipt(receipt,room,command),base|{'type':'SNAPSHOT','revision':revision,'snapshot':projected}]
        else:
            if db.execute('SELECT 1 FROM intents WHERE room_id=? AND principal=? AND action_id=?',(room,role,command)).fetchone():a.fail('DUPLICATE_INTENT')
            if db.execute('SELECT count(*) FROM receipts WHERE room_id=?',(room,)).fetchone()[0]>=a.MAX_RECEIPTS:a.fail('LIMIT_EXCEEDED')
            u=next((x for x in v['snapshot']['units'] if x['id']==f['unitId']),None)
            code=None
            if not u or (profile!='gm' and u['ownerId']!=profile):code='FORBIDDEN'
            elif f['baseRevision']!=revision:code='STALE_REVISION'
            elif revision>=a.MAX_EVENTS:code='LIMIT_EXCEEDED'
            else:
                x,y=f['payload']['x'],f['payload']['y'];s=v['snapshot']
                if x>=s['n'] or y>=s['n'] or (x,y)==(u['x'],u['y']) or f'{x},{y}' in s['walls'] or any(z['id']!=u['id'] and (z['x'],z['y'])==(x,y) for z in s['units']):code='UNKNOWN_EFFECT'
            event_id=None
            if code is None:
                revision+=1;event_id=f'event-{revision}'
                event={'kind':'TEST38_VISUAL_MOVE','unit_id':u['id'],'x':x,'y':y,'command_id':command,'seq':v['seq']+1,'public_event_id':event_id}
                state=reduce(state,event);v=state['visual'];projected=projection(v,profile)
                db.execute('INSERT INTO events VALUES (?,?,?)',(room,revision,a.encode(event)))
                db.execute('UPDATE rooms SET revision=?,state=? WHERE room_id=?',(revision,a.encode(state),room))
                frames=[base|{'type':'EVENT','revision':revision,'commandId':command,'kind':'MOVE_VISUAL_TEST','actorId':u['id'],'snapshot':projected}]
            receipt=authority.store_receipt(db,room,role,command,a.encode(req),revision,
                'REJECTED' if code else 'ACCEPTED',code or 'APPLIED',event_id)
            frames.append(frame_receipt(receipt,room,command))
    return {'schema_version':3,'op':'arena','ok':True,'frames':frames,'receipt':receipt}
