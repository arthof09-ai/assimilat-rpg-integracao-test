/* Codex integration harness: unchanged TEST38 modules + existing loopback HTTP.
 * Public FAKE tokens only. No outbox, mechanics, WebSocket or real login.
 */
(()=>{'use strict';
const tokens={gm:'FAKE_TEST_MASTER',p1:'FAKE_TEST_PLAYER1',p2:'FAKE_TEST_PLAYER2'};
const wire=[];let loseNext=false;
async function request(payload,profile){
 const response=await fetch('/bridge',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+tokens[profile]},body:JSON.stringify(payload)});
 const bytes=await response.text();wire.push({profile,request:payload,status:response.status,body:bytes});
 const p=JSON.parse(bytes);if(!response.ok||p.ok!==true)throw Error('Autoridade indisponível; preservar UNKNOWN');
 if(payload.frame?.type==='INTENT'&&loseNext){loseNext=false;throw Error('Confirmação descartada após COMMIT TEST');}
 return p;
}
function transportFactory({onMessage,onClose}){
 const profile=document.getElementById('roomProfile').value;let closed=false,queue=Promise.resolve();
 return {send:raw=>{
  if(closed)throw Error('Transporte encerrado');
  const frame=JSON.parse(raw);if(!window.TabletopRoomV2TEST.validV2Outgoing(frame))throw Error('Wire TEST38 inválido');
  queue=queue.then(async()=>{
   if(closed)return;const p=await request({schema_version:3,op:'arena',frame},profile);
   if(p.schema_version!==3||p.op!=='arena'||!Array.isArray(p.frames)||p.frames.length>2||
      !p.frames.every(f=>window.TabletopRoomV2TEST.validV2Response(f)))throw Error('Lote inválido');
   for(const f of p.frames){if(!closed)onMessage(JSON.stringify(f));}
  }).catch(()=>{if(!closed){closed=true;onClose();}});
 },close:()=>{if(!closed){closed=true;onClose();}}};
}
// Only this separate harness replaces the DEMO transport factory. Original bytes stay intact.
window.TabletopRoomV2TEST.mockV2TransportFactory=transportFactory;
const banner=document.createElement('section');banner.className='card';
const title=document.createElement('p');title.textContent='PONTE HTTP LOCAL TEST · cena importada explicitamente · MECÂNICA VLAB HOLD. Use a sala v2 abaixo para mover visualmente e consultar recibos persistentes.';
const importButton=document.createElement('button');importButton.className='btn';importButton.id='bridgeImport';
importButton.textContent='Mestre TEST: importar cena atual (u1→p1, u2→p2, u3→NPC)';
const result=document.createElement('p');result.id='bridgeResult';result.textContent='Cena ainda não importada no servidor. Nenhum dado oficial ou combate.';
importButton.onclick=async()=>{
 try{
  const scene=window.__tabletopTEST.scene();const binding={u1:['actor-1','p1'],u2:['actor-2','p2'],u3:['actor-m',null]};
  const snapshot={sceneId:scene.id,n:scene.n,walls:scene.walls,units:scene.units.map(u=>{
   if(!binding[u.id])throw Error('Mapeamento explícito necessário');
   return {id:u.id,name:u.name,mark:u.mark,team:u.team,ownerId:binding[u.id][1],x:u.x,y:u.y};
  }),markers:scene.markers.map(m=>({id:m.id,x:m.x,y:m.y,label:m.label}))};
  const bindings=Object.fromEntries(snapshot.units.map(u=>[u.id,{actor_id:binding[u.id][0],viewers:u.ownerId?['gm',u.ownerId]:['gm']} ]));
  const reply=await request({schema_version:3,op:'arena_bootstrap',room_id:'arena-test',snapshot,bindings,
   provenance:{source:'TEST38_EXPLICIT_VISUAL_IMPORT',frontend_sha256:'085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c'}},'gm');
  result.textContent='Cena visual TEST importada · SHA '+reply.scene_sha256+' · sala v2 pronta. Não é combate.';
 }catch(_e){result.textContent='Importação não aplicada. Verifique sala existente, geometria e mapeamento; preserve o banco.';}
};
banner.append(title,importButton,result);document.querySelector('main').prepend(banner);
window.PonteTEST={wire,request,transportFactory,loseNextConfirmation:()=>{loseNext=true;}};
})();
