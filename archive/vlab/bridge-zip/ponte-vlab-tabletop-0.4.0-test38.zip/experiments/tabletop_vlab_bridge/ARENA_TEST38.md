# Ponte 0.4.0 — TEST38 real até recibo persistente

Esta versão fecha um fluxo visual TEST entre **os módulos originais TEST38** e a
Authority HTTP/SQLite existente. Não é batalha VLAB nem sincronização remota.
`room-client.js`, `room-v2-adapter.js`, `app.js`, HTML/CSS em vendor/test38 são
cópias byte-idênticas dos anexos verificados. Nenhum original foi editado.
O bug ROOM_UPDATED→MOVE_CONFIRMED já corrigido no TEST38 é apenas regressão.

## Executar manualmente em PC/navegador

Requisitos do produto TEST: Python 3.11+ com SQLite e navegador atual. Node,
TypeScript e Playwright são necessários apenas para executar as respectivas suítes.
Na raiz do pacote extraído, escolher um banco TEST novo fora dos fontes:

```sh
mkdir -p work
python3 experiments/tabletop_vlab_bridge/authority.py --db work/arena-test.sqlite --arena --port 8765
```

1. Abrir `http://127.0.0.1:8765/` nesse mesmo computador.
2. No banner da ponte, clicar **Mestre TEST: importar cena atual**. Essa ação
   explícita copia a geometria da cena ativa real do editor TEST38, sem recursos
   de ficha. A confirmação mostra o hash da cena importada.
3. No painel **Sala compartilhada**, escolher protocolo **Candidato v2 + recibos**
   e perfil **Player 1 DEMO**, depois **Entrar na bancada**.
4. No quadro desse painel, selecionar a unidade E e uma casa vazia. A posição
   muda após EVENT autorizado; o resultado ACCEPTED aparece no resumo de recibos.
5. Recarregar estado usa SNAPSHOT. Sair/entrar preserva e consulta intenção UNKNOWN.

O alvo desta integração é o quadro `roomGrid` e o RoomClient existentes. A Arena
principal/editor e o botão de ataque continuam locais: não foram remendados para
consumir PA, Vida, recursos ou snapshots remotos. Integrar essa apresentação e
enviar ataques pertence ao Desenvolvedor. O banner diferencia este HTTP real
das descrições históricas de “fixture” preservadas no frontend original.

O processo só escuta 127.0.0.1. Não é acesso do celular a um PC, hospedagem pública
ou produto offline com servidor embutido. Android físico não foi testado. O pacote
permite reprodução em PC; não se afirma que o Mestre já dispõe desse runtime.

## Origem geométrica e autorização TEST

Não há mapa default no servidor nem coordenada derivada de label. Importação
`arena_bootstrap` exige o token fixture Mestre, sala ainda inexistente, projeção
estrita `sceneId,n,walls,units,markers`, proveniência explícita e bindings.
O harness lê `window.__tabletopTEST.scene()` da aplicação original e seleciona
somente campos visuais. Os recursos hp/soul/pa, notas e dados de ficha não entram.

O mapeamento inicial é deliberado e visível: u1→actor-1/p1, u2→actor-2/p2,
u3→actor-m/NPC. Não se atribui owner pelo nome do token. Uma cena com IDs diferentes
é recusada até receber bindings explícitos. Limite desta fatia: 3 unidades.
O dono e os viewers são validados pelo servidor; cada owner precisa ser viewer,
gm sempre é viewer. Marcadores importados ficam Mestre-only nesta fatia.
Paredes/grade são geometria pública explicitamente importada; unidades não
autorizadas são removidas antes de serializar. Não se usa FOV da UI como segurança.

A origem é **estado visual sintético TEST38 importado sob ação explícita**,
não dado canônico da campanha. O hash computado pelo servidor e o genesis SQLite
registram essa origem, sem afirmar autenticidade de campanha por um hash.
Não reimportar sobre uma sala existente: preservar banco e histórico; escolher
um banco TEST novo se for outra sessão de laboratório.

## Contrato efetivo, sem substituir cliente ou backend

Mesmo POST /bridge, JSON, mesmo servidor loopback. Schema nativo 1/2 preservados.
Schema 3 acrescenta bootstrap e um wrapper para os frames **v:2 reais TEST38**:

```json
{"schema_version":3,"op":"arena","frame":{"v":2,"type":"JOIN","roomId":"arena-test","ticket":"test-local-p1"}}
```

Bearer é fixture e vincula a identidade no servidor. O ticket JOIN precisa
coincidir com essa identidade; não concede privilégio. Escolher GM no browser
não é login real. Todos os tokens FAKE_TEST_* são públicos, propositalmente TEST.

```json
{"schema_version":3,"op":"arena","frame":{"v":2,"type":"INTENT","roomId":"arena-test","commandId":"move_1","baseRevision":0,"kind":"MOVE_VISUAL_TEST","unitId":"u1","payload":{"x":2,"y":2}}}
```

Saída nativa: `schema_version:3, op:arena, ok:true, frames:[...], receipt`.
O transporte separa o lote, valida **todos** os frames com o validador original
TEST38 e os entrega ao adaptador original. Não se injeta EVENT_BATCH desconhecido
no cliente, que aceita apenas WELCOME/SNAPSHOT/EVENT/ACK/RECEIPT. EVENT_BATCH da
0.3.0 continua API experimental legada separada, sem equivalência falsa.

- JOIN → WELCOME com identidade vinculada, memberships, epoch persistido e mapa.
- RESYNC → SNAPSHOT atual autorizado; nunca um segundo WELCOME nem histórico total.
- INTENT visual válido → EVENT MOVE_VISUAL_TEST + ACK ACCEPTED, no mesmo lote.
- RECEIPT_QUERY encontrado → ACK original; ausente/alheio → RECEIPT NOT_FOUND.
- NOT_FOUND permanece UNKNOWN no cliente original; nenhuma nova ID ou outbox.
- Erro sem recibo (ex. ID_REUSE_CONFLICT) não vira rejeição terminal inventada;
  transporte encerra e preserva UNKNOWN, permitindo consultar a intenção original.
- FORBIDDEN durável → UNAUTHORIZED; STALE_REVISION → STALE_REVISION;
  UNKNOWN_EFFECT visual → INVALID_INTENT; mecânica ausente → MECHANICS_HOLD.

O campo completo receipt_id fica no recibo nativo/captura. O frontend original
interpreta ACK pelo commandId/status/revisão; não foi modificado para mostrar UUID.

## Uma autoridade e um recibo

Authority.handle mantém BEGIN IMMEDIATE. A extensão usa **as mesmas rooms,
events, intents e receipts**, e o mesmo load_receipt/store_receipt/digest/DTO.
O writer do recibo 0.2 foi extraído como função compartilhada, sem outro serviço
ou outra outbox. arena_genesis é apenas a origem visual persistida para replay.
Estado, evento e recibo fazem COMMIT juntos; erro antes do COMMIT reverte tudo.

O único novo efeito é trocar XY de uma unidade visual autorizada, sem alcance,
caminho, PA, dano, Vida ou adjudicação VLAB. Rótulos não viram movimento.
Writes legados label/checkpoint/restore nessa sala visual são bloqueados, sem
quebrar as salas legadas: isso evita misturar journals com semânticas diferentes.

Sequência é persistida no evento/genesis e revisões continuam no estado da sala.
Esta fatia exige **um evento visual aceito por revisão**; o servidor verifica a
igualdade seq/revision antes de responder. O adaptador TEST38 original deriva
seq de revision: compatibilidade foi demonstrada sob esse invariante explícito,
não declarada como regra geral de sala/VLAB. Rejeições não avançam nenhum deles.
Eventos mecânicos múltiplos por revisão exigirão evolução deliberada do contrato.

## Provas reproduzíveis

```sh
PYTHONPATH=experiments/tabletop_vlab_bridge python3 -m unittest test_arena_integration -v
python3 experiments/tabletop_vlab_bridge/run_checks.py --results work/arena-checks
```

Suíte de browser requer Playwright Python e Chromium disponível em /usr/bin/chromium
neste ambiente; o produto manual acima não depende desses testadores.
O teste abre a página por HTTP real, importa cena da API real, clica unidade/destino,
confere posição e texto ACCEPTED. Depois o servidor fecha o socket **após COMMIT**,
o cliente registra UNKNOWN e mantém a intenção; o teste mata/reinicia o processo,
reconecta pelo cliente original e compara o recibo ao persistido no SQLite.
Reenvio do primeiro comando mantém seu recibo e o número de eventos igual.
Uma segunda página usa p2 e recebe apenas a unidade autorizada via JOIN/RESYNC.
São contextos Chromium no mesmo host, não dois dispositivos ou WSS.

Capturas incluem request, bytes de resposta anteriores à adaptação, UUID real do
recibo e screenshots de UNKNOWN e recuperação. Não registram Authorization.
Testes adicionais cobrem papel forjado, unidade alheia, ID alterado, revisão
obsoleta/concorrente, rollback, corrupção aninhada e Origin não permitido.
Um RED novo descobriu sessionEpoch aninhado em estado corrompido; validação de
metadados reservados agora o bloqueia antes dos bytes. Não é correção do TEST38.

## VLAB e próximos gates

Ataque não é movimento. ATTACK_REQUEST v2 existente continua retornando recibo
MECHANICS_UNAVAILABLE durável, sem evento/revisão/recursos; o teste da nova sala
também prova esse bloqueio. O botão tático original continua NÃO ENVIADA.
Para a primeira batalha faltam ABI VLAB competente/homologada e ligação do
comando tático da Arena pelo responsável frontend. Não executar engine antiga
ou inventar cálculo para trocar esse HOLD por PASS.

Gates A/B/C/D: somente no escopo TEST38 original + HTTP local + identidades
sintéticas + movimento visual. Gates E/F permanecem HOLD. Não há autenticação
real, push entre dispositivos, WebSocket, hospedagem ou Cloudflare homologados.
O custo adicional em serviços é R$0. Nenhum deploy, PR, push ou merge.

`VLAB_SOURCE_NOT_AVAILABLE`, `PYTHON_TS_EQUIVALENCE_NOT_TESTED`,
`ANDROID_REAL_NOT_TESTED`, `VLAB_PRODUCTION_HOLD` preservados.
LAST: cliente real→evento/recibo→reinício→cliente real demonstrado.
FIRST-PENDING: ABI VLAB e integração do botão tático na Arena principal.
NEXT: handoff ao Desenvolvedor usando esse mesmo transporte/recibo; depois
decisão mecânica oficial autorizada. NO-REPEAT: Arena, outbox, backend, bug TEST38
já corrigido, motor e pesquisa encerrada.
