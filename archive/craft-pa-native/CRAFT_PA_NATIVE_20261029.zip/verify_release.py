"""Verify and run existing CRAFT/PA sources offline; never publishes or fabricates."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def run(args, cwd):
    result = subprocess.run([sys.executable, '-B', *args], cwd=cwd,
                            capture_output=True, text=True, timeout=60)
    log = result.stdout + result.stderr
    if result.returncode:
        raise RuntimeError(log)
    print(log.strip())
    return log

def main():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for rel, expected in manifest['files'].items():
        actual = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('SOURCE_HASH_MISMATCH: ' + rel)
    logs = []
    logs.append(run(['-m', 'unittest', '-q', 'test_ponte_pa_craft_r27',
                     'engine_r26.test_r26_decisao'], ROOT / 'provider_r27'))
    logs.append(run(['-m', 'unittest', '-q', 'test_qmc05'],
                    ROOT / 'CRAFT-QMC04' / 'QMC-05'))
    logs.append(run(['-m', 'unittest', '-q', 'test_native_acceptance'], ROOT))
    logs.append(run(['R03_REPLAY_COLD.py'], ROOT / 'readonly_r03'))
    expected_counts = [48, 47, 8]
    for log, count in zip(logs[:3], expected_counts):
        if f'Ran {count} tests' not in log or 'OK' not in log:
            raise ValueError('UNEXPECTED_TEST_COUNT')
    if 'COLD_REPLAY_PASS' not in logs[3] or '46' not in logs[3]:
        raise ValueError('READONLY_COLD_REPLAY_NOT_CONFIRMED')
    print(json.dumps({'status': 'LOCAL-TEST-PASS', 'tests': 149,
        'suites': {'provider_original': 48, 'qmc_original': 47,
                   'native_acceptance': 8, 'readonly_consumer_original': 46},
        'hashed_files': len(manifest['files']), 'remote_writes': 0,
        'scope': 'Consulta assistida CRAFT/PA; não produz estoque ou aprova rank automaticamente'},
        ensure_ascii=False))

if __name__ == '__main__':
    main()
