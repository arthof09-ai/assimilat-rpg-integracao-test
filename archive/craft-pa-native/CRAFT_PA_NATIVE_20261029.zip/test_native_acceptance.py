"""Acceptance tests for the recovered native entrypoint; no pricing engine."""
import copy
import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
QMC = ROOT / 'CRAFT-QMC04' / 'QMC-05'
sys.path.insert(0, str(QMC))
import qmc05
import pa_r28_native as adapter

URLS = {
    'lamina': '3edc2b324ede816f98a1fa7babd3c0d3',
    'topazio': '3edc2b324ede81f9b294edf33c354250',
    'acolchoada': '3edc2b324ede81a9a1cfc83817895e8a',
}

def current(name):
    raw = (ROOT / 'live-inputs' / (name + '.txt')).read_text().rstrip('\n')
    return qmc05.analyze(raw, 'https://app.notion.com/p/' + URLS[name])

class NativeAcceptance(unittest.TestCase):
    def test_current_three_sources_reach_real_provider(self):
        for name in URLS:
            with self.subTest(name=name):
                out = adapter.integrar_qualificado(current(name))
                self.assertEqual(out['origem']['uuid'], URLS[name])
                self.assertEqual(out['call_chain'][-1], 'r26.avaliar')
                self.assertEqual(out['provider_contract'], 'PA-CRAFT-QMC05-COMPAT-R27/1.0.0-TEST')

    def test_historical_unknown_cost_is_not_zero(self):
        out = adapter.integrar_qualificado(current('lamina'))
        self.assertIsNone(out['historico']['r27']['pa_por_dia'])
        self.assertIsNone(out['historico']['projecao_energetica'])
        self.assertFalse(out['historico']['alteracao_no_original'])

    def test_unknown_mode_and_duration_survive(self):
        out = adapter.integrar_qualificado(current('lamina'))
        self.assertEqual(out['origem']['effect_count'], 2)
        self.assertEqual(out['historico']['efeitos_sem_modalidade'][0]['effect_id'], 'E02')
        self.assertIsNone(out['origem']['effects'][0]['duration']['exact_seconds'])

    def test_source_mismatch_stops_before_quote(self):
        value = current('lamina')
        value['structured_effects']['item_uuid'] = '0' * 32
        with self.assertRaises(adapter.R28ContractError):
            adapter.integrar_qualificado(value)

    def test_missing_grounding_stops_before_quote(self):
        value = current('lamina')
        value['structured_effects']['status'] = 'UNVERIFIED'
        with self.assertRaises(adapter.R28ContractError):
            adapter.integrar_qualificado(value)

    def test_unproven_project_does_not_become_recipe(self):
        proposal = {'modo': 'PROJETO_E3_TEST', 'fonte_qmc05_uuid': URLS['lamina'],
                    'item_novo': 'Somente caso de rejeição', 'rank_item': 'Prata',
                    'efeitos_selecionados': [{'effect_id': 'E99'}]}
        with self.assertRaises(adapter.R28ContractError):
            adapter.integrar_qualificado(current('lamina'), proposal)

    def test_native_cli_runs_provider_on_current_readback(self):
        result = subprocess.run([sys.executable, '-B', str(QMC / 'qmc05.py'),
            '--url', 'https://app.notion.com/p/' + URLS['lamina'],
            '--readback', str(ROOT / 'live-inputs' / 'lamina.txt'), '--pa-r28'],
            capture_output=True, text=True, check=True, timeout=20)
        value = json.loads(result.stdout)
        self.assertEqual(value['contrato'], adapter.SCHEMA)
        self.assertEqual(value['origem']['effect_count'], 2)

    def test_no_input_mutation_or_external_write(self):
        value = current('lamina')
        previous = copy.deepcopy(value)
        result = adapter.integrar_qualificado(value)
        self.assertEqual(value, previous)
        for field in ('notion_write', 'PARTY_WRITE', 'primeiro_write'):
            self.assertFalse(result['governanca'][field])

if __name__ == '__main__':
    unittest.main()
