#!/usr/bin/env python3
"""Gera pareceres usando o CÓDIGO EXISTENTE; não reescreve fichas/receitas."""
import json,sys,hashlib,zlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import qmc05
OLD=ROOT.parent/'QMC-04/input';LAB=ROOT.parent/'QMC-04/replica_laboratorio'
ALL={
 'topazio':('3edc2b324ede81f9b294edf33c354250',OLD/'topazio_readback.txt',OLD/'topazio_anchor.json'),
 'acolchoada':('3edc2b324ede81a9a1cfc83817895e8a',OLD/'acolchoada_readback.txt',OLD/'acolchoada_anchor.json'),
 'espelho':('3edc2b324ede817188f3deff656edc1f',OLD/'espelho_holdout.txt',OLD/'espelho_holdout_anchor.json'),
 'lamina_holdout':('3edc2b324ede816f98a1fa7babd3c0d3',ROOT/'holdout/lamina.txt',None),
 'selo_holdout':('3edc2b324ede81769f26d68a8a42aab6',ROOT/'holdout/selo.txt',None),
}
SESSION={'lamina_holdout':('1972','b2a9c9eb','2026-10-03T13:19:53.073Z'),
         'selo_holdout':('1558','df9cf32f','2026-10-03T05:36:58.895Z')}
outputs={}
for label,(id,fn,anchor_path) in ALL.items():
 raw=fn.read_text().rstrip('\n')
 if anchor_path:anchor=json.loads(anchor_path.read_text())
 else:
  nb,crc,asof=SESSION[label]
  assert len(raw.encode('utf8'))==int(nb) and qmc05.qmc04.crc32(raw)==crc
  anchor={'kind':'CONNECTOR_OBSERVATION','uuid':id,'utf8_bytes':int(nb),'crc32':crc,'as_of':asof}
 x=qmc05.analyze(raw,'https://app.notion.com/p/'+id,anchor)
 assert x['state']=='QMC05_PARECER_DOCUMENTAL_TEST',x
 (ROOT/'outputs'/f'PARECER-{label.upper()}.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'outputs'/f'CONSULTA-{label.upper()}.md').write_text(qmc05.conversational(x)+'\n')
 outputs[label]=x
# Real LAB 3 states, two deltas, zero canonical mutations.
raw=[(LAB/f'v{i}_readback.txt').read_text().rstrip('\n') for i in range(3)]
a=json.loads((LAB/'anchors.json').read_text())['states'];uid='3fdc2b324ede815fa3e3efa3182d4a5e'
revs=[qmc05.version_semantic(raw[0],raw[1],uid,a[0],a[1]),qmc05.version_semantic(raw[1],raw[2],uid,a[1],a[2])]
(ROOT/'outputs'/'REVISOES-LAB-PARECER-QMC05.json').write_text(json.dumps(revs,ensure_ascii=False,indent=2)+'\n')
# Composite engineering
pairs=[('topazio','acolchoada','Posso empilhar os dois no mesmo espaço do Anel Dimensional?'),
       ('topazio','acolchoada','Posso usar os dois juntos equipados?'),
       ('topazio','topazio','Duas unidades idênticas podem empilhar no Anel Dimensional?'),
       ('selo_holdout','lamina_holdout','Posso instalar esta inscrição nesta arma?'),
       ('lamina_holdout','acolchoada','Habilidades passivas interferem uma na outra?')]
results=[{'items':[x,y],'result':qmc05.compatibility(outputs[x]['qmc04'],outputs[y]['qmc04'],q)} for x,y,q in pairs]
# Control with actual Esmeralda archived QMC-03: source qmc04 imports independently, no anchor from chat => NOT ATTESTED.
es=ROOT.parent/'QMC-03/verified_transfers/esmeralda_tool_response.txt'
if es.is_file():
 eraw=es.read_text().rstrip('\n');ex=qmc05.qmc04.qualified_chat(eraw,'https://app.notion.com/p/3edc2b324ede81e28548ef18833a7078')
 results.append({'items':['esmeralda_baseline_qmc03','topazio'],'result':qmc05.compatibility(ex,outputs['topazio']['qmc04'],'Pode a Esmeralda alimentar especificamente o Topázio de Velocidade?'),
                 'source_provenance':'Esmeralda no corpus QMC03, retomada local sem âncora de sessão atual'})
(ROOT/'outputs'/'COMPATIBILIDADE-MULTIFATORIAL.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
# media truthful. Exactly 5 referenced QMC03/04 + holdout Lamina, none downloaded/inspected.
media=[]
for label in ALL:
 x=outputs[label]
 for v in x['qmc04']['media']:
  media.append({'uuid':x['qmc04']['identity']['uuid'],'item':label,'reference':v['reference'],
        'signed_url_resolution':'VERIFIED_FOR_ORIGINAL_QMC03_QMC04_5' if label in ['topazio','acolchoada','espelho'] else 'NOT_TESTED_FOR_THIS_HOLDOUT',
        'download':'BLOQUEADO_E_OU_NAO_TENTADO','bytes':None,'sha256_of_media_bytes':None,'visual_inspection':'NAO_REALIZADA','R_IMG':'PENDENTE'})
# Add esmeralda/lanca baseline refs
for label in ('esmeralda','lanca'):
 from pathlib import Path
 import re
 oldtext=(ROOT.parent/'QMC-03/verified_transfers'/(label+'_tool_response.txt'))
 if oldtext.is_file():
  for m in re.finditer(r'notion-file-block://[^)\s]+',oldtext.read_text()):
   media.append({'uuid':'3edc2b324ede81e28548ef18833a7078' if label=='esmeralda' else '3edc2b324ede81ecbae3cf4b0cf274e5',
      'item':label,'reference':m.group(0),'signed_url_resolution':'VERIFIED_20261018','download':'BLOQUEADO','bytes':None,
      'sha256_of_media_bytes':None,'visual_inspection':'NAO_REALIZADA','R_IMG':'PENDENTE'})
if not any(x['item']=='lanca' for x in media):
 media.append({'uuid':'3edc2b324ede81ecbae3cf4b0cf274e5','item':'lanca',
  'reference':'notion-file-block://119c2b32-4ede-834e-af07-81440138b59e/77373ed8-7ab3-4823-af57-a33fe8ebb21c?space_id=dd9375f6-576f-4742-974b-be0df0796b9d&name=Untitled.png',
  'signed_url_resolution':'VERIFIED_20261018_BY_NOTION_CONNECTOR','download':'BLOQUEADO','bytes':None,
  'sha256_of_media_bytes':None,'visual_inspection':'NAO_REALIZADA','R_IMG':'PENDENTE'})
assert len(media)==6,len(media)
(ROOT/'outputs'/'MIDIA-RIMG-INDICE-6-SEM-BYTES.json').write_text(json.dumps(media,ensure_ascii=False,indent=2)+'\n')
# PA readiness, stored R05 actual receipt separate
summary={'QMC_VERSION':'05','new_holdout_total':3,'passed_holdout':2,'rejected_transfer':1,
 'historical_verified_uuids':21,'new_verified_uuids':2,'cumulative_uuids':23,
 'families_in_new_holdout':2,'modes_covered':['ARMA','INSCRICAO_ENCANTAMENTO'],
 'all_analysis_sources':list(ALL),'qualified_this_run':len(ALL),
 'rimg_referenced_count':len(media),'rimg_inspected':0,
 'versions_lab_readbacks':3,'versions_lab_transitions':2,
 'compatibility_cases':len(results),
 'notes':'Nenhum holdout fica como ficha oficial escrita pelo CRAFT; documento e software apenas.'}
(ROOT/'outputs'/'RESULTADOS-QMC05.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
