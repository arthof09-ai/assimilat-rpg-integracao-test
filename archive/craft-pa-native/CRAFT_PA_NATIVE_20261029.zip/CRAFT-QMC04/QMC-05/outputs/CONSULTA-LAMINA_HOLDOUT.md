**Lâmina Eclipse** — ARMA; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede816f98a1fa7babd3c0d3 (estado fornecido pela ferramenta: 2026-10-03T13:19:53.073Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Eclipse Total: Quando ativada, a espada envolve o portador em sombras, tornando-o quase invisível aos olhos dos inimigos. | magnitude: sem magnitude numérica documentada; modalidade: ATIVACAO_DESCRITA_MAS_ACAO_NAO_DEFINIDA; condição: Quando ativada; duração: NAO_DOCUMENTADA.

- Corte Lunar: uma vez por noite, a lâmina libera uma onda de energia lunar que pode cortar através de magia. | magnitude: sem magnitude numérica documentada; modalidade: USO_CONDICIONAL_SEM_TIPO_DE_ACAO; condição: uma vez por noite; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.
