**Espelho Verdade Oculta** — ARTEFATO; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f (estado fornecido pela ferramenta: 2026-10-03T19:35:28.359Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Quem ficar na frente desse espelho, perde 15 pontos de carisma temporário | magnitude: perde 15 pontos de carisma; modalidade: MODALIDADE_NAO_DETERMINADA; condição: Quem ficar na frente desse espelho; duração: TEMPORARIA_SEM_DURACAO_EXATA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.
