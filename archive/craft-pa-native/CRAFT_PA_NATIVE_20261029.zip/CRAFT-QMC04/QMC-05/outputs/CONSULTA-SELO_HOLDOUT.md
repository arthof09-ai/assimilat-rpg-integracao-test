**Inscrição de Selamento (P) (CG)** — INSCRICAO_ENCANTAMENTO; rank: Prata.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81769f26d68a8a42aab6 (estado fornecido pela ferramenta: 2026-10-03T05:36:58.895Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Efeito Mágico: O objeto encantado se torna um receptáculo para espíritos, mantendo-os seguramente selados dentro. O selo é resistente e só pode ser quebrado por magias específicas de desencantamento ou por pessoas com um alto nível de conhecimento mágico. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.
