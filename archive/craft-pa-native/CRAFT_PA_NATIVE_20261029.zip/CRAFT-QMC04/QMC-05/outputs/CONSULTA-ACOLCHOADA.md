**Acolchoada Aurora** — ARMADURA; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a (estado fornecido pela ferramenta: 2026-10-03T13:19:10.151Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Escudo do Amanhecer: A armadura é capaz de absorver o primeiro golpe de um inimigo ao amanhecer, protegendo a usuária de danos. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: ao amanhecer / primeiro golpe; duração: NAO_DOCUMENTADA.

- Calor do Sol Nascente: Ela mantém a usuária aquecida em climas frios, emulando o calor suave do sol nascente. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: em climas frios; duração: NAO_DOCUMENTADA.

- Renovação Diária: A cada novo amanhecer, a armadura repara pequenos danos sofridos no dia anterior. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: A cada novo amanhecer; duração: NAO_DOCUMENTADA.

- Defesa: +8 CA e -5m de deslocamento | magnitude: +8 CA; -5m de deslocamento; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.
