**Topázio de Velocidade** — ARTEFATO; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250 (estado fornecido pela ferramenta: 2026-10-03T19:35:15.711Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Aumenta a agilidade e a velocidade do portador temporariamente. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: TEMPORARIA_SEM_DURACAO_EXATA.

- Duplica sua velocidade e da +5 de destreza | magnitude: Duplica sua velocidade; +5 de destreza; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.
