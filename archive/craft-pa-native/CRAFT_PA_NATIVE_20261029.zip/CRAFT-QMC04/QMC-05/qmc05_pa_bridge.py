#!/usr/bin/env python3
"""CRAFT QMC05 ↔ PA R05 TEST: chama validador EXTERNO real e conserva os bloqueios.

Nenhuma cópia/alteração de lógica de cálculo PA; o fornecedor deve ser entregue pelo
Comestre competente como pacote íntegro. Este arquivo NÃO é um segundo motor de PA.
"""
from __future__ import annotations
import hashlib,importlib.util,json,sys
from pathlib import Path

EXPECTED_FILENAME='PA_UNIVERSAL_R05_TEST_20261017.zip'
RECEIPT_VERSION='CRAFT-PA-R05-OBSERVED-TEST-1'


def import_external_wire(r05_root:Path):
    wire=Path(r05_root)/'R05_CODE'/'qmc_pa_r05_wire.py'
    if not wire.is_file():raise FileNotFoundError('PACOTE_PA_R05_NAO_RECUPERADO')
    sys.path.insert(0,str(wire.parent))
    spec=importlib.util.spec_from_file_location('qmc05_external_PA_R05_wire',wire)
    if not spec or not spec.loader:raise RuntimeError('CONTRATO_PA_R05_INACESSIVEL')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod,hashlib.sha256(wire.read_bytes()).hexdigest()


def bridge(r05_root:Path, qmc_source:dict):
    wire,digest=import_external_wire(r05_root)
    try:
        payload=wire.wrap_qualified_source(qmc_source)
        test_verdict=wire.strict_local_validation(payload)
        native_probe=wire.native_qmc_probe(payload)
    except Exception as exc:
        return {'status':'REJEITADO_POR_VALIDADOR_ORIGINAL_PA_R05',
                'error_type':type(exc).__name__,'reason':str(exc), 'production':'HOLD'}
    msg=payload['message']
    return {'status':'INTERCAMBIO_REAL_PA_R05_TEST_SEM_ACEITE_NATIVO',
        'version':RECEIPT_VERSION, 'provider_code':'PA-R05-ATTRIBUTE-MESTRE',
        'provider_contract':msg['contract'],'provider_wire_sha256':digest,
        'item_uuid':msg.get('uuid'),'source_url':msg.get('source_url'),
        'historical_daily_pa':msg.get('daily_pa'),'historical_activation_pa':msg.get('activation_pa_values'),
        'source_sha256_excerpt':msg.get('qualified_excerpt_sha256'),
        'pa_validation':test_verdict,'native_qmc02':native_probe,
        'provider_approval':'TEST_NO_RELEASE','natively_accepted':False,
        'pa_official_approved':False, 'new_recipes':0,'production':'HOLD',
        'note':'QMC-05 executa o adaptador ORIGINAL R05. Não implementa fórmula energética; payload limitado à fonte QMC-02 já qualificada.'}


def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--pa-r05-root',required=True);p.add_argument('--qmc02-sources-json',required=True);p.add_argument('--uuid',required=True);p.add_argument('--out')
    ns=p.parse_args();root=Path(ns.pa_r05_root)
    sources=json.loads(Path(ns.qmc02_sources_json).read_text())['sources'];matched=[x for x in sources if x.get('uuid')==ns.uuid]
    if len(matched)!=1:raise SystemExit('UUID not unique in original QMC-02 corpus')
    result=bridge(root,matched[0]);txt=json.dumps(result,ensure_ascii=False,indent=2)
    if ns.out:Path(ns.out).write_text(txt+'\n')
    else:print(txt)
    if result['status']!='INTERCAMBIO_REAL_PA_R05_TEST_SEM_ACEITE_NATIVO':raise SystemExit(2)
if __name__=='__main__':main()
