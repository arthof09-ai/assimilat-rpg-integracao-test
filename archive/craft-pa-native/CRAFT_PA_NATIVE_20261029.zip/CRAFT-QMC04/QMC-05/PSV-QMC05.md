# PSV — CRAFT QMC-05 · Engenharia Mecânica / Intercâmbio Energético TEST

**AS-OF:** 18/10/2026 (local, evidência Notion observada pode ter `as of` de 03/10); execução/readback código local nesta sessão.
**OPERATION:** `OP-ARQ-RIN-REC-01`. **IDENTIDADE:** CM-000002 / WS0001 por determinação do Mestre; **INSTANCE-ID não comprovado** neste runtime. **AMBIENTE:** MESTRE-SIDE.
**BASELINE:** QMC-04 SHA-256 `121708d005e154775c5cb63ac7064449cc22a4b6ca79bba95238943aa330d7a4`, intacta; QMC-01–03 preservadas. QMC-04 IBX-110 `ACK` de `CM-000001-I0009`, reaberta nesta sessão.

## LER / ANTES
- QMC-04: consultor ChatGPT URL→Notion→bancada, 21 fichas, 127/127 testes, imagem 0/5, PA contrato candidato, 3 estados LAB e 2 deltas.
- Pacotes QMC-03 e QMC-04 fisicamente abertos; restauração do log `baseline_tests.log` de 3.715 bytes, SHA-256 `e6f8e3a542381408ccdef176f466eb37fed2f6da8c234b9621c91a26cc601bc3`. **48/48 arquivos do QMC-03 íntegros** na nova árvore, o original QMC-04 81/81 conferido via verificador. Nenhum arquivo anterior reescrito.

## EXECUTAR / DEPOIS — capacidades concretas novas
1. **EFFECT-STRUCTURED-CANDIDATE-1**, processo de efeitos via código, com evidência literal e modalidade não presumida: Topázio velocidade ×2 e +5 DES; Acolchoada +8 CA e −5m, efeitos condicionais ao amanhecer; Espelho −15 CAR temporário de duração incerta. Sem converter ao PA.
2. **Holdout:** 3 fontes novas Mestre consultadas: [Lâmina Eclipse](https://app.notion.com/p/3edc2b324ede816f98a1fa7babd3c0d3) (ARMA, 2 efeitos); [Inscrição de Selamento](https://app.notion.com/p/3edc2b324ede81769f26d68a8a42aab6) (INSCRICAO_ENCANTAMENTO; receita histórica ≠ ocorrência instalada); [Véu de Eärendil](https://app.notion.com/p/3edc2b324ede813e8efaf8de2050fd9b) (consulta feita, **transferência rejeitada por divergência**, NÃO qualificada). Duas fichas novas qualificadas **2/3**, uma rejeitada **1/3**, sem inventar resultados. Acumulado documental **23 UUIDs = 21+2**, **não é censo**. Módulos comprovados continuam 7/8, aprimoramentos aplicados 0.
3. **Interoperabilidade PA R05 REAL em laboratório**: recuperado `PA_UNIVERSAL_R05_TEST_20261017.zip`, SHA `6f69fd1ef197851e128c2fc7becbad1f2a14a1438e7bf9ac71742b835f99078e`; o CRAFT invocou `R05_CODE/qmc_pa_r05_wire.py`, `wrap_qualified_source`, `strict_local_validation` e `native_qmc_probe` do fornecedor existente sobre **Bota Caminho Veloz**. Saída: **18 PA/dia e 5 PA/uso** documentados, `RECEBIDO_R05_TEST_FORA_DO_ENTRYPOINT_NATIVO`; validador nativo QMC-02 original respondeu **`INTERFACE_EXTERNA_NAO_CONTRATADA`**. Forged hash/custo e troca UUID foram rejeitados. Testes externos R05 **5/5 PASS**. NÃO foi escrita fórmula PA, e o sistema competente segue **TEST_NO_RELEASE**. Pacote mais recente PA P0 R07 recuperado para metadados de estado: 94 linhas em auditoria, decisões energéticas ainda pendentes, sem conclusão/homologação de modelo universal; **nenhum dado Party importado para o CRAFT**.
4. **Versões físicas LAB integradas ao parecer**: 3 readbacks existentes e 2 transições: primeira alterou custo TEST 7→12 PA, título e efeito; segunda alterou somente redação. `version_semantic` distingue mudança mecânica da editorial; zero fichas oficiais alteradas.
5. **Compatibilidade composta**: 6 perguntas com resultados [1 incompatível no mesmo espaço do Anel, 2 condicionais, 3 indeterminados], com domínios físico, mecânico, documental e energético separados. Uso conjunto de armadura+artefato = INDETERMINADO sem regra específica, não proibição universal. Instalar inscrição na Lâmina = INDETERMINADO (sem prova de instalação/compatibilidade).
6. **R-IMG:** seis imagens referenciadas em seis páginas Mestre (5 anteriores, 1 da Lâmina). Resolução de URL assinada pelo Notion conferida para **5/5 referências antigas**; tentativas de download para o runtime falharam (container download exige URL vista, chamada web de arquivo privado retornou erro e ambiente Python não alcança DNS). **0/6 bytes recuperados, 0/6 inspeções visuais e 0 hashes de mídia.** Exigência de imagem permanece pendente, sem descrição inventada.

## DENOMINATORS / EXECUÇÃO
- Baseline: QMC01/02 **37/37**, QMC03 **40/40**, QMC04 **50/50** = **127/127 regressões** reproduzidas.
- Novos testes de QMC05: **47/47 testes semânticos, versões, compatibilidade e ingresso** (incluem casos adversariais; não contar em dobro).
- Testes reais do fornecedor PA R05: **5/5**, separados e condicionados ao pacote de outro executor.
- **Total único executado nesta entrega: 179/179** = 127 + 47 + 5 (sem contar novamente adversariais).
- Fontes novas consultadas: 3; fontes novas qualificadas via transferência fiel: 2; 1 cópia rejeitada. Corpus acumulado QMC: 23 UUIDs, 7/8 módulos; este novo delta 2 famílias holdout.
- Casos compostos: 6; revisões LAB: 3 estados e 2 deltas; mídias: 6 referências, 0 bytes/0 inspeções.

## Proveniência e limitações
O conector Notion Mestre é executado por ChatGPT, e a bancada recebe wrapper integral por transferência assistida; o Executor preserva âncora de bytes/CRC independente da cópia. **Não é ligação autônoma Python↔Notion, não é assinatura Notion, nem frescor garantido.** Conector devolveu `as of` de 03/10/2026 para as fichas. A tentativa inicial de passar VÉU e SELO por Base64 teve divergência; a de SELO foi recuperada por transferência literal completa e CRC exato; a de VÉU segue isolada como rejeição. Não usar trecho adulterado como fonte.

## GOVERNANÇA / NAC-PASS
**NO-NEW-RECIPES:** 0 receitas novas (mágicas, mundanas, experimentais, derivações), 0 BOMs autorais, 0 REC-ID, 0 itens ou ativações; fontes e receitas históricas apenas consultadas. **NO-REPEAT:** códigos QMC01–04, R48, FC36, BACKFILL-30 preservados; nenhuma execução histórica reconstruída/reescrita. **UNKNOWN-EFFECT:** C19-021 permanece UNKNOWN-EFFECT; não foi reexecutado.
**AUTHORITY/WRITER:** LAB e leituras autorizadas; nenhum writer produtivo, lease, epoch ou fencing reivindicado. Escrituras de ficha Mestre/Party/O Primeiro **0**. Receitas e produção HOLD; F5 RED; RC5 0/30.
**NAC-PASS proporcional:** PASS local para retorno de leitura, efeito estruturado, versão LAB, transferência de holdout, adaptador TEST de fornecedor PA e testes. **HOLD** para imagens R-IMG, API/contrato PA homologado, receita/fábrica, aprimoramento canônico aplicado, produção e universalidade.

## LAST-VERIFIED-UNIT / FIRST-PENDING
**LAST-VERIFIED-UNIT:** código QMC05 `structured_effects` executado com duas fontes novas; interop real PA R05 e seis consultas multifatoriais testadas, sem mutar baseline.
**FIRST-PENDING:** caminho binário autorizado que efetivamente entregue bytes de mídia Notion para inspeção R-IMG, seguido de aceite NATIVO da interface PA pelo Executor CRAFT com autoridade específica, e exemplo Mestre de aprimoramento aplicado.
**CONFLICTS:** imagens inacessíveis, fonte desatualizada do conector, original QMC02 não aceita resposta PA_R05, uma transferência de Véu falhou; nenhuma decisão normativamente presumida.
**NEXT-5:** (1) obter mídia binária sem endpoint temporário quebrado e inspecionar; (2) criar gate nativo do PA R05 na QMC em cópia autorizada, mantendo teste de falsificação e bloqueio de produção; (3) novo holdout multicategoria com versões atuais; (4) demonstração legítima de aprimoramento aplicado ou bloqueio documentado; (5) confirmar contrato PA mais recente/homologado antes de qualquer release.
**TARGET-REMAINDER:** leitura Notion criptograficamente não assinada, R-IMG 0/6, APR 0 positivos, PA produção sem homologação; dados de PA R07 do outro executor permanecem seu domínio, não resolver por inferência.

**Sinalização final:** ENTREGA FUNCIONAL TEST — NÃO HOMOLOGAÇÃO.
