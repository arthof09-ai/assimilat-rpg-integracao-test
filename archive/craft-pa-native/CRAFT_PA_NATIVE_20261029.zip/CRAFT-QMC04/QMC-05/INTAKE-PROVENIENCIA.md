# Comprovante de readback Mestre e transferências · TEST

- Original QMC-04 ZIP SHA-256 `121708d005e154775c5cb63ac7064449cc22a4b6ca79bba95238943aa330d7a4`: recuperado localmente, 81/81 manifesto e 127/127 regressões PASS.
- Original QMC-03 ZIP SHA-256 `e76058eac20d545bfcd1b4749efadf743f11c55e264b22a60b6108f2aa327248`: recuperado, 48/48 integrantes originais na árvore de entrega QMC-05 sem alteração de bytes.
- Leituras de fichas Mestre novas foram feitas em `mcp__Notion__fetch` autorizado, sem copiar fontes Party:
  - Lâmina Eclipse `3edc2b324ede816f98a1fa7babd3c0d3`, 1972 bytes, CRC32 `b2a9c9eb`, `as of 2026-10-03T13:19:53.073Z`, pass por pipeline completo.
  - Inscrição de Selamento `3edc2b324ede81769f26d68a8a42aab6`, 1558 bytes, CRC32 `df9cf32f`, `as of 2026-10-03T05:36:58.895Z`, pass após segunda estratégia de transporte integral; preservada primeira cópia corrompida separadamente.
  - Véu de Eärendil `3edc2b324ede813e8efaf8de2050fd9b`, **TRANSFERÊNCIA REJEITADA**: a ferramenta mostrava 2184 bytes e CRC32 `7b03a728`, a cópia recebeu 2193 bytes e CRC32 `62e60b5b`. NÃO contar como consulta qualificada no motor.
- Conexão Notion→Python exige transporte assistido pelo Comestre, e localmente não há assinatura criptográfica do Notion. CRC32 não é assinatura nem prova temporal de frescor.
- Cinco referências antigas de mídia foram resolvidas como URLs assinadas pelo conector durante esta execução; NÃO foram obtidos os bytes. Falha de ferramenta `container.download`: exigência de URL vista no fluxo web; tentativa web de mídia confidencial retornou acesso indisponível, e o ambiente Python não dispõe de DNS externo. Nenhum hash de imagem é incluído.
- R05 PA real recuperado da Biblioteca; sua cópia é dependência EXTERNA. O pacote QMC05 contém somente código adaptador read-only e recibos Mestre-side; não incorpora corpus do PA nem dados da Party.
