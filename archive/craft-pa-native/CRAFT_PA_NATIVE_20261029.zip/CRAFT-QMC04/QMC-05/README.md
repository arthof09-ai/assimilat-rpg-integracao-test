# QMC-05 — Consultor de Efeitos Mecânicos de Itens · MESTRE-SIDE

**Operação existente:** OP-ARQ-RIN-REC-01 · **CM-000002 / CM-000002-WS0001** (identidade funcional, INSTANCE-ID não assumida) · **Produção HOLD, F5 RED, C19-021 UNKNOWN**.

## O que mudou sobre QMC-04

- `qmc05.py` é extensão aditiva, importa `../QMC-04/qmc04.py` que importa QMC-03 e QMC-02. **Nenhum motor reimplementado.** Extrai `EFFECT-STRUCTURED-CANDIDATE-1`, magnitudes CA, deslocamento, Destreza, velocidade, Carisma, dados literais e condições. Detecta negação explícita e nunca cobra PA automaticamente.
- `qmc05_pa_bridge.py` invoca **o código REAL do sistema PA R05, read-only**, se o pacote deste Executor estiver materializado no ambiente. O R05 produz e valida recibo TEST 18 PA/dia e 5 PA/uso da Bota; a **validação nativa QMC-02 recusa** `INTERFACE_EXTERNA_NAO_CONTRATADA`. Não invocar fornecedor falsificado. Sem o pacote real, não contar teste de integração como executado.
- Gera parecer conversacional de cinco fichas já lidas por ferramenta Notion Mestre, duas das quais holdout novas: Lâmina Eclipse e Inscrição de Selamento. O Mestre **não prepara arquivos**; o Comestre realiza a transferência verificada.
- Reutiliza as três revisões da réplica LAB existente (NÃO são fichas canônicas) e classifica diferença mecânica vs puramente editorial.
- `compatibility` separa armazenamento, energia e mecânica. Nunca promove compatibilidade genérica a instalação/uso real autorizado.
- Índice de seis referências Notion R-IMG. **0/6 imagens baixadas e visualmente inspecionadas:** URLs assinadas pelo conector, download bloqueado por ferramentas; nenhum SHA de bytes reais foi inventado.

## Recuperação do ZIP QMC03 original

O original QMC-04 SHA-256 `121708d005e154775c5cb63ac7064449cc22a4b6ca79bba95238943aa330d7a4` permanece na Biblioteca. A QMC-05 restaura **sem editar bytes** `CRAFT-QMC04/baseline_tests.log` da distribuição QMC-03 original, com **3.715 bytes** e SHA-256 `e6f8e3a542381408ccdef176f466eb37fed2f6da8c234b9621c91a26cc601bc3`. Comparação QMC-03: 48/48 arquivos idênticos. Todos os arquivos do ZIP QMC-04 original continuam byte-a-byte idênticos na distribuição QMC-05.

## Executar na pasta raiz `CRAFT-QMC04/`

```
python -m unittest discover -s QMC-02/qmc02 -p 'test_*.py' -q
python -m unittest discover -s QMC-03 -p 'test_qmc03.py' -q
python -m unittest discover -s QMC-04 -p 'test_qmc04.py' -q
python -m unittest discover -s QMC-05 -p 'test_qmc05.py' -q
python QMC-05/build_qmc05_delivery.py
python QMC-05/qmc05.py --url https://app.notion.com/p/3edc2b324ede816f98a1fa7babd3c0d3 --readback QMC-05/holdout/lamina.txt
python verify_manifest.py
```

**Dependência externa somente para PA R05 REAL em TEST:** recuperar o ZIP original `PA_UNIVERSAL_R05_TEST_20261017.zip` (SHA-256 `6f69fd1ef197851e128c2fc7becbad1f2a14a1438e7bf9ac71742b835f99078e`) da Biblioteca de COMESTRE; extraí-lo fora desta distribuição e apontar `PA_R05_ROOT` para seu diretório `PA_UNIVERSAL_R05_TEST_20261017`:

```
PA_R05_ROOT=/caminho/PA_UNIVERSAL_R05_TEST_20261017 python -m unittest discover -s QMC-05 -p 'test_pa_r05_external.py' -v
python QMC-05/qmc05_pa_bridge.py --pa-r05-root /caminho/PA_UNIVERSAL_R05_TEST_20261017 --qmc02-sources-json QMC-02/qmc02/source_readbacks.json --uuid 3edc2b324ede8135b199fd0cdbb5463c
```

**Nenhum motor energético, chave, token, URL assinada temporária, custo hipotético ou dado Party incluído no ZIP CRAFT.** O Mestre pode mandar URL no ChatGPT; o Comestre usa o conector Notion Mestre com ID de conta autorizado, transfere wrapper integral, confere com âncora observada nessa consulta e executa CLI. A partir de arquivos isolados, CRC32 não autentica Notion nem garante frescor. Textos da fonte `as of` 03/10/2026 são estados observáveis retornados, não revisão do dia.

**Estados:** PROJETO/TEST, não fabricação. Receitas novas 0; REC-ID 0; atualização ficha Mestre 0; Party/O Primeiro 0; RC5 0/30 histórico, produção HOLD.
