"""Testes só se pacote real do fornecedor PA_R05 presente; NUNCA simulam aprovação."""
import os,copy,sys,json,unittest,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import qmc05_pa_bridge as bridge

class TestProviderR05(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        var=os.getenv('PA_R05_ROOT')
        if not var:raise unittest.SkipTest('PA_R05_ROOT não fornecido; não contar como integração real.')
        cls.root=Path(var)
        cls.wire,_=bridge.import_external_wire(cls.root)
        base=ROOT.parent/'QMC-02/qmc02/source_readbacks.json'
        cls.original=[s for s in json.loads(base.read_text())['sources'] if s['uuid']=='3edc2b324ede8135b199fd0cdbb5463c'][0]
    def test_01_original_provider_reconciles_bota(self):
        r=bridge.bridge(self.root,self.original)
        self.assertEqual(r['status'],'INTERCAMBIO_REAL_PA_R05_TEST_SEM_ACEITE_NATIVO')
        self.assertEqual(r['historical_daily_pa'],18)
        self.assertEqual(r['historical_activation_pa'],[5])
    def test_02_provider_local_validation_not_official(self):
        r=bridge.bridge(self.root,self.original)
        self.assertEqual(r['pa_validation']['status'],'RECEBIDO_R05_TEST_FORA_DO_ENTRYPOINT_NATIVO')
        self.assertFalse(r['pa_validation']['native_qmc_accepted'])
    def test_03_native_qmc02_remains_closed(self):
        r=bridge.bridge(self.root,self.original)
        self.assertEqual(r['native_qmc02']['native_return']['status'],'INTERFACE_EXTERNA_NAO_CONTRATADA')
    def test_04_modified_source_hash_recomputed_not_trusted(self):
        tampered=copy.deepcopy(self.original)
        txt=tampered['content'];self.assertIn('18 PA',txt)
        tampered['content']=txt.replace('18 PA','180 PA')
        tampered['declared_content_sha256']=hashlib.sha256(tampered['content'].encode()).hexdigest()
        r=bridge.bridge(self.root,tampered)
        self.assertEqual(r['status'],'REJEITADO_POR_VALIDADOR_ORIGINAL_PA_R05')
    def test_05_false_pa_identity_rejected(self):
        tampered=copy.deepcopy(self.original);tampered['uuid']='3edc2b324ede81a9a1cfc83817895e8a'
        r=bridge.bridge(self.root,tampered)
        self.assertEqual(r['status'],'REJEITADO_POR_VALIDADOR_ORIGINAL_PA_R05')
if __name__=='__main__':unittest.main()
