import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import qmc05
qmc04=qmc05.qmc04
OLD=ROOT.parent/'QMC-04/input'
URLS={'topazio':'3edc2b324ede81f9b294edf33c354250','acolchoada':'3edc2b324ede81a9a1cfc83817895e8a','espelho':'3edc2b324ede817188f3deff656edc1f','lamina':'3edc2b324ede816f98a1fa7babd3c0d3','selo':'3edc2b324ede81769f26d68a8a42aab6'}

def get(nm):
    if nm=='espelho':raw=(OLD/'espelho_holdout.txt').read_text().rstrip('\n');a=json.loads((OLD/'espelho_holdout_anchor.json').read_text())
    elif nm=='selo':
        raw=(ROOT/'holdout/selo.txt').read_text();meta=json.loads((ROOT/'holdout/transfer_integrity.json').read_text())['SELO'];a={'kind':'CONNECTOR_OBSERVATION','uuid':URLS['selo'],'utf8_bytes':meta['expected_bytes'],'crc32':meta['expected_crc32'],'as_of':'2026-10-03T05:36:58.895Z'}
    elif nm=='lamina':
        raw=(ROOT/'holdout/lamina.txt').read_text();meta=json.loads((ROOT/'holdout/transfer_integrity.json').read_text())['LAMINA'];a={'kind':'CONNECTOR_OBSERVATION','uuid':URLS['lamina'],'utf8_bytes':meta['expected_bytes'],'crc32':meta['expected_crc32'],'as_of':'2026-10-03T13:19:53.073Z'}
    else:raw=(OLD/(nm+'_readback.txt')).read_text().rstrip('\n');a=json.loads((OLD/(nm+'_anchor.json')).read_text())
    return qmc05.analyze(raw,'https://app.notion.com/p/'+URLS[nm],a)

class QMC05Semantics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.t=get('topazio');cls.a=get('acolchoada');cls.e=get('espelho');cls.l=get('lamina');cls.s=get('selo')
    def test_01_topazio_valid(self):self.assertEqual(self.t['state'],'QMC05_PARECER_DOCUMENTAL_TEST')
    def test_02_topazio_x2(self):self.assertIn(('VELOCIDADE_MULTIPLICADOR',2),[(z['property'],z['value']) for e in self.t['structured_effects']['effects'] for z in e['magnitudes']])
    def test_03_topazio_plus5_des(self):self.assertIn(('DESTREZA',5),[(z['property'],z['value']) for e in self.t['structured_effects']['effects'] for z in e['magnitudes']])
    def test_04_topazio_pa_unknown_not_zero(self):self.assertEqual(self.t['energy_exchange']['costs_documented']['daily'],[])
    def test_05_topazio_rank_preserved(self):self.assertEqual(self.t['qmc04']['identity']['rank'],'Sem classificação')
    def test_06_topazio_no_duration_invention(self):self.assertFalse(any(e['duration']['exact_seconds'] for e in self.t['structured_effects']['effects']))
    def test_07_armor_four_effects(self):self.assertEqual(self.a['structured_effects']['count'],4)
    def test_08_armor_ca8(self):self.assertIn(('CA',8),[(z['property'],z['value']) for e in self.a['structured_effects']['effects'] for z in e['magnitudes']])
    def test_09_armor_movement_negative5(self):self.assertIn(('DESLOCAMENTO_M',-5),[(z['property'],z['value']) for e in self.a['structured_effects']['effects'] for z in e['magnitudes']])
    def test_10_armor_shield_no_reaction(self):
        e=[x for x in self.a['structured_effects']['effects'] if 'Escudo do Amanhecer' in x['literal']][0]
        self.assertNotIn('REAÇÃO',e['mode'])
    def test_11_armor_repair_not_charge(self):self.assertTrue(all(e['frequency'] is None for e in self.a['structured_effects']['effects']))
    def test_12_armor_amanehcer_condition(self):
        e=[x for x in self.a['structured_effects']['effects'] if 'Renovação Diária' in x['literal']][0]
        self.assertTrue(any('amanhecer' in k for k in e['conditions']))
    def test_13_armor_rimg_not_inspected(self):self.assertEqual(self.a['visual_evidence']['inspected'],0)
    def test_14_espelho_minus15(self):self.assertIn(('CARISMA',-15),[(z['property'],z['value']) for e in self.e['structured_effects']['effects'] for z in e['magnitudes']])
    def test_15_espelho_duration_unknown_exact(self):self.assertIsNone(self.e['structured_effects']['effects'][0]['duration']['exact_seconds'])
    def test_16_espelho_no_active(self):self.assertEqual(self.e['structured_effects']['effects'][0]['mode'],'MODALIDADE_NAO_DETERMINADA')
    def test_17_holdout_lamina_valid(self):self.assertEqual(self.l['state'],'QMC05_PARECER_DOCUMENTAL_TEST')
    def test_18_holdout_lamina_two_effects(self):self.assertEqual(self.l['structured_effects']['count'],2)
    def test_19_holdout_night_frequency(self):self.assertTrue(any('uma vez por noite' in str(e['frequency']) for e in self.l['structured_effects']['effects']))
    def test_20_holdout_no_pa_assumed(self):self.assertFalse(self.l['energy_exchange']['costs_documented']['daily'])
    def test_21_holdout_no_named_input_registration(self):self.assertNotIn('Lâmina Eclipse',Path(qmc05.__file__).read_text())
    def test_22_all_effect_magnitudes_literal(self):
        for item in (self.t,self.a,self.e,self.l,self.s):
            for e in item['structured_effects']['effects']:
                for m in e['magnitudes']:self.assertIn(m['literal'],e['literal'])
    def test_23_no_recipes(self):self.assertTrue(all(x['new_recipes']==0 for x in (self.t,self.a,self.e,self.l,self.s)))
    def test_24_energy_mock_denied(self):self.assertFalse(qmc05.verify_energy_response({'kind':'MOCK'})['official'])
    def test_25_energy_prod_fake_denied(self):self.assertEqual(qmc05.verify_energy_response({'kind':'PROD','contract_version':'v1'})['state'],'FORNECEDOR_NAO_ATESTADO')
    def test_26_energy_wrong_version(self):self.assertEqual(qmc05.verify_energy_response({'kind':'PROD','provider_id':'x','contract_version':'v0'},{'authority_readback_verified':True,'provider_id':'x','contract_version':'v1'})['state'],'FORNECEDOR_OU_VERSAO_DIVERGENTE')
    def test_27_pa_payload_no_cost_calculator(self):self.assertIsNone(self.t['energy_exchange']['return_official_cost'])
    def test_28_pa_no_activation(self):self.assertFalse(self.t['energy_exchange']['activation_authorized'])
    def test_29_comparison_natural_question_indeterminate(self):
        v=qmc05.compatibility(self.t['qmc04'],self.a['qmc04'],'Posso usar os dois juntos?');self.assertEqual(v['state'],'INDETERMINADO')
    def test_30_comparison_shared_space_negative(self):
        v=qmc05.compatibility(self.t['qmc04'],self.a['qmc04'],'Empilhar no Anel Dimensional?');self.assertEqual(v['domains']['physical'],'INCOMPATIVEL_VERIFICADO')
    def test_31_comparison_identical_conditional(self):
        v=qmc05.compatibility(self.t['qmc04'],self.t['qmc04'],'Empilhar no Anel Dimensional?');self.assertEqual(v['state'],'CONDICIONAL')
    def test_32_media_signed_url_not_inspection(self):
        q=copy.deepcopy(self.t['qmc04']);ref=q['media'][0]['reference'];r=qmc05.media_receipt(q,[{'reference':ref,'signed_url_obtained':True}]);self.assertEqual(r['media'][0]['state'],'URL_RESOLVIDA_BYTES_NAO_ADQUIRIDOS');self.assertEqual(r['inspected'],0)
    def test_33_transfer_holdout_mismatch_quarantined(self):
        x=json.loads((ROOT/'holdout/transfer_integrity.json').read_text());self.assertEqual(x['VEU']['status'],'DIVERGENCIA_TRANSITO_REJEITADA')
    def test_34_transfer_seal_mismatch_quarantined(self):
        x=json.loads((ROOT/'holdout/transfer_integrity.json').read_text());self.assertEqual(x['SELO']['status'],'TRANSFERENCIA_CONFERIDA_ALTERNATIVA_WRAPPER_COMPLETO');self.assertEqual(x['SELO']['initial_base64_copy'],'DIVERGENCIA_TRANSITO_REJEITADA')
    def test_35_holdout_lamina_transfer_verified(self):
        x=json.loads((ROOT/'holdout/transfer_integrity.json').read_text());self.assertEqual(x['LAMINA']['status'],'TRANSFERENCIA_CONFERIDA')
    def test_36_semantic_text_from_execution(self):self.assertIn('carisma',qmc05.conversational(self.e).lower())
    def test_37_rimg_explanatory(self):self.assertIn('INCOMPLETA',self.t['visual_evidence']['rule_R_IMG'])
    def test_38_rule_no_auto_universal_daily(self):self.assertIsNone(self.a['energy_exchange']['provider_contract'])
    def test_44_holdout_inscription_admitted(self):self.assertEqual(self.s['state'],'QMC05_PARECER_DOCUMENTAL_TEST')
    def test_45_holdout_inscription_historical_recipe_not_installation(self):
        self.assertEqual(self.s['qmc04']['identity']['family'],'INSCRICAO_ENCANTAMENTO');self.assertIn('INS_PADRAO_INSTALADO',str(self.s['qmc04']['baseline_qmc03']['item']['pending']))
    def test_46_negative_magnitude_not_applied(self):
        x=copy.deepcopy(self.a['qmc04']);x['additional_effects']['effects']=[{'literal':'Não concede +5 CA nem dá defesa universal.'}];struct=qmc05.structured_effects(x);self.assertEqual(struct['effects'][0]['magnitudes'],[]);self.assertTrue(struct['effects'][0]['negated_benefit'])
    def test_47_holder_not_notional_fabrication(self):self.assertEqual(self.s['new_recipes'],0)

class QMC05Revisions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        lab=ROOT.parent/'QMC-04/replica_laboratorio';cls.raw=[(lab/f'v{x}_readback.txt').read_text().rstrip('\n') for x in range(3)];cls.anchors=json.loads((lab/'anchors.json').read_text())['states'];cls.uid='3fdc2b324ede815fa3e3efa3182d4a5e'
    def test_39_physical_change_cost_and_effect(self):
        x=qmc05.version_semantic(self.raw[0],self.raw[1],self.uid,self.anchors[0],self.anchors[1]);self.assertTrue(x['mechanical_change']);self.assertIn('CUSTO_ENERGETICO_DOCUMENTAL_TEST',[y['domain'] for y in x['changes']]);self.assertIn('EFEITO_MECANICO_TEXTUAL_TEST',[y['domain'] for y in x['changes']])
    def test_40_only_editorial(self):
        x=qmc05.version_semantic(self.raw[1],self.raw[2],self.uid,self.anchors[1],self.anchors[2]);self.assertFalse(x['mechanical_change']);self.assertEqual([y['domain'] for y in x['changes']],['APENAS_EDITORIAL'])
    def test_41_stale_blocked(self):
        x=qmc05.version_semantic(self.raw[2],self.raw[0],self.uid,self.anchors[2],self.anchors[0]);self.assertEqual(x['state'],'VERSAO_BLOQUEADA')
    def test_42_equal_no_delta(self):
        x=qmc05.version_semantic(self.raw[0],self.raw[0],self.uid,self.anchors[0],self.anchors[0]);self.assertEqual(x['state'],'SEM_DELTA')
    def test_43_fake_cost_in_clone_blocked(self):
        r=self.raw[1].replace('12 PA','120 PA');x=qmc05.version_semantic(self.raw[0],r,self.uid,self.anchors[0],self.anchors[1]);self.assertEqual(x['state'],'VERSAO_BLOQUEADA')

if __name__=='__main__':unittest.main()
