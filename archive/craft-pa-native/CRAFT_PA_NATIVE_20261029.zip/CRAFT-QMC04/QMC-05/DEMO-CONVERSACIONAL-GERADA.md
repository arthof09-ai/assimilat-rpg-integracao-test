# Consultas QMC-05 geradas pelo código

**Produção** HOLD · **Receitas** 0 · imagens não inspecionadas · dados `as-of` do conector.

## topazio

**Topázio de Velocidade** — ARTEFATO; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250 (estado fornecido pela ferramenta: 2026-10-03T19:35:15.711Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Aumenta a agilidade e a velocidade do portador temporariamente. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: TEMPORARIA_SEM_DURACAO_EXATA.

- Duplica sua velocidade e da +5 de destreza | magnitude: Duplica sua velocidade; +5 de destreza; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.

---

## acolchoada

**Acolchoada Aurora** — ARMADURA; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a (estado fornecido pela ferramenta: 2026-10-03T13:19:10.151Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Escudo do Amanhecer: A armadura é capaz de absorver o primeiro golpe de um inimigo ao amanhecer, protegendo a usuária de danos. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: ao amanhecer / primeiro golpe; duração: NAO_DOCUMENTADA.

- Calor do Sol Nascente: Ela mantém a usuária aquecida em climas frios, emulando o calor suave do sol nascente. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: em climas frios; duração: NAO_DOCUMENTADA.

- Renovação Diária: A cada novo amanhecer, a armadura repara pequenos danos sofridos no dia anterior. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: A cada novo amanhecer; duração: NAO_DOCUMENTADA.

- Defesa: +8 CA e -5m de deslocamento | magnitude: +8 CA; -5m de deslocamento; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.

---

## espelho

**Espelho Verdade Oculta** — ARTEFATO; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f (estado fornecido pela ferramenta: 2026-10-03T19:35:28.359Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Quem ficar na frente desse espelho, perde 15 pontos de carisma temporário | magnitude: perde 15 pontos de carisma; modalidade: MODALIDADE_NAO_DETERMINADA; condição: Quem ficar na frente desse espelho; duração: TEMPORARIA_SEM_DURACAO_EXATA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.

---

## lamina_holdout

**Lâmina Eclipse** — ARMA; rank: Sem classificação.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede816f98a1fa7babd3c0d3 (estado fornecido pela ferramenta: 2026-10-03T13:19:53.073Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Eclipse Total: Quando ativada, a espada envolve o portador em sombras, tornando-o quase invisível aos olhos dos inimigos. | magnitude: sem magnitude numérica documentada; modalidade: ATIVACAO_DESCRITA_MAS_ACAO_NAO_DEFINIDA; condição: Quando ativada; duração: NAO_DOCUMENTADA.

- Corte Lunar: uma vez por noite, a lâmina libera uma onda de energia lunar que pode cortar através de magia. | magnitude: sem magnitude numérica documentada; modalidade: USO_CONDICIONAL_SEM_TIPO_DE_ACAO; condição: uma vez por noite; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.

---

## selo_holdout

**Inscrição de Selamento (P) (CG)** — INSCRICAO_ENCANTAMENTO; rank: Prata.

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81769f26d68a8a42aab6 (estado fornecido pela ferramenta: 2026-10-03T05:36:58.895Z; atualização de hoje não comprovada).

**Efeitos com evidência literal:**

- Efeito Mágico: O objeto encantado se torna um receptáculo para espíritos, mantendo-os seguramente selados dentro. O selo é resistente e só pode ser quebrado por magias específicas de desencantamento ou por pessoas com um alto nível de conhecimento mágico. | magnitude: sem magnitude numérica documentada; modalidade: MODALIDADE_NAO_DETERMINADA; condição: sem gatilho específico demonstrado; duração: NAO_DOCUMENTADA.

**PA/dia:** PENDENTE. **PA/ativação:** PENDENTE. **PA ambíguo:** PENDENTE.

**Imagem:** INCOMPLETA_ATE_INSPECAO_VISUAL_REAL; não inspecionada visualmente.

**Interoperabilidade PA:** dados estruturados prontos; fornecedor e contrato real ainda não validados.

**Uso/fabricação oficiais:** NÃO AUTORIZADOS. Receitas novas PROIBIDAS; produção HOLD.
