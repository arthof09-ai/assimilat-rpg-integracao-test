import unittest,tempfile,pathlib,json,copy,hashlib
from intake_r70 import inspect
BASE=pathlib.Path(__file__).parent
CASES=BASE/'R69_CASES_MASTER_ONLY.json'
SOURCE=json.loads(CASES.read_text())['cases']

def fresh():
 return {'schema':'ASSIMILACAO_R69_REVIEW_LOCAL_V1','status':'PARECER_AUTODECLARADO_NAO_HOMOLOGADO',
'reviewer_self_declared':'SELF-DECLARED-TEST-NOT-A-REAL-REVIEWER',
'source_package_sha256':'ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9',
'source_review_zip_sha256':'626ffaf777ea12caa8c3dab492042154f3324142c5b430dad8aded48797f38bb',
'reviewed_by_independent_party_verified':False,'authority_approval':False,'pa_official':None,
'items':[{'case_id':r['id'],'image_sha256':r['sha256'],'action':'texto TEST','mechanic':'efeito TEST','limits':'limite TEST','comparators':'fonte TEST','opinion':'proposta TEST, não é parecer humano','state':'PROPOSTA_NAO_HOMOLOGADA'} for r in SOURCE]}

class Tests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.t.name)/'review.json';self.o=fresh()
 def tearDown(self):self.t.cleanup()
 def result(self,data=None):
  self.p.write_bytes(json.dumps(self.o if data is None else data,ensure_ascii=False).encode() if not isinstance(data,bytes) else data)
  return inspect(self.p,CASES)
 def bad(self,reason=None,data=None):
  r=self.result(data);self.assertEqual(r['status'],'REJECTED');
  if reason:self.assertTrue(r['reason'].startswith(reason),r)
 def test_01_complete_but_not_authenticated(self):
  r=self.result();self.assertEqual(r['status'],'STRUCTURALLY_COMPLETE_UNAUTHENTICATED');self.assertFalse(r['reviewer_independence_verified']);self.assertEqual(r['e0_homologated'],0);self.assertIsNone(r['official_PA']);self.assertEqual(r['metrics']['structurally_filled'],14)
 def test_02_blank_draft(self):
  self.o['status']='RASCUNHO_LOCAL_NAO_VERIFICADO'
  for x in self.o['items']:x.update({k:'' for k in ('action','mechanic','limits','comparators','opinion')});x['state']='NAO_INICIADO'
  r=self.result();self.assertEqual(r['status'],'PARTIAL_UNAUTHENTICATED');self.assertEqual(r['metrics']['partial'],14)
 def test_03_valid_abstention(self):
  for x in self.o['items']:x.update(state='ABSTENCAO',limits='Não há fonte suficiente',opinion='')
  r=self.result();self.assertEqual(r['status'],'STRUCTURALLY_COMPLETE_UNAUTHENTICATED');self.assertEqual(r['metrics']['abstentions_self_declared'],14)
 def test_04_abstention_without_reason(self):
  for x in self.o['items']:x.update(state='ABSTENCAO',limits='')
  self.assertEqual(self.result()['status'],'PARTIAL_UNAUTHENTICATED')
 def test_05_missing_field(self):del self.o['items'][0]['action'];self.bad('RECORD_SCHEMA')
 def test_06_extra_field(self):self.o['items'][0]['rank_homologado']='Lendário';self.bad('RECORD_SCHEMA')
 def test_07_forged_independent(self):self.o['reviewed_by_independent_party_verified']=True;self.bad('AUTHORITY')
 def test_08_forged_authority(self):self.o['authority_approval']=True;self.bad('AUTHORITY')
 def test_09_official_pa_not_null(self):self.o['pa_official']=42;self.bad('AUTHORITY')
 def test_10_status_forged(self):self.o['status']='AUTENTICADO';self.bad('FORGED')
 def test_11_wrong_anchor(self):self.o['source_package_sha256']='0'*64;self.bad('SOURCE_ANCHOR')
 def test_12_wrong_peer_anchor(self):self.o['source_review_zip_sha256']='0'*64;self.bad('SOURCE_ANCHOR')
 def test_13_wrong_image_hash(self):self.o['items'][4]['image_sha256']='bad';self.bad('CASE_BINDING')
 def test_14_reordered_roster(self):self.o['items'][0],self.o['items'][1]=self.o['items'][1],self.o['items'][0];self.bad('CASE_BINDING')
 def test_15_duplicate_id(self):self.o['items'][3]=self.o['items'][2];self.bad('CASE_BINDING')
 def test_16_missing_case(self):self.o['items'].pop();self.bad('REVIEW_ROSTER')
 def test_17_wrong_state(self):self.o['items'][0]['state']='PASS';self.bad('STATE_INVALID')
 def test_18_bool_field(self):self.o['items'][0]['mechanic']=True;self.bad('FIELD_INVALID')
 def test_19_length_overflow(self):self.o['items'][0]['action']='X'*4001;self.bad('FIELD_INVALID')
 def test_20_duplicate_json_global_key(self):
  b=json.dumps(self.o).encode();b=b.replace(b'"authority_approval": false',b'"authority_approval": false,"authority_approval": false');self.bad('INPUT_ERROR_DuplicateKey',b)
 def test_21_json_nan(self):self.bad('INPUT_ERROR_ValueError',json.dumps(self.o).replace('"pa_official": null','"pa_official": NaN').encode())
 def test_22_invalid_utf8(self):self.bad('INPUT_ERROR_UnicodeDecodeError',b'\xff\xfe')
 def test_23_oversize(self):self.bad('OVERSIZE',b'x'*1500001)
 def test_24_wrong_schema(self):self.o['schema']='R68';self.bad('SCHEMA')
 def test_25_extra_top_field(self):self.o['external_auth_claim']=True;self.bad('TOP_LEVEL')
 def test_26_missing_top(self):del self.o['items'];self.bad('TOP_LEVEL')
 def test_27_reviewer_too_long(self):self.o['reviewer_self_declared']='X'*121;self.bad('REVIEWER_LABEL')
 def test_28_missing_input_file(self):self.assertEqual(inspect(self.p,CASES)['status'],'REJECTED')
 def test_29_tamper_cases_manifest(self):
  p=pathlib.Path(self.t.name)/'cases.json';p.write_bytes(CASES.read_bytes()+b'\n');self.p.write_text(json.dumps(self.o));self.assertEqual(inspect(self.p,p)['reason'],'PINNED_CASES_CHANGED')
 def test_30_status_none(self):self.o['status']=None;self.bad('FORGED')
 def test_31_pa_zero_is_forged(self):self.o['pa_official']=0;self.bad('AUTHORITY')
 def test_32_self_declared_reviewer_is_not_proof(self):
  self.o['reviewer_self_declared']='Professor com licença plena';r=self.result();self.assertFalse(r['reviewer_identity_authenticated'])
if __name__=='__main__':unittest.main(verbosity=2)
