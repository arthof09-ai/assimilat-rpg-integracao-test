"""R70: fail-closed, read-only schema triage for R69 self-declared reviewer JSON.
Do NOT confuse syntactic validity with reviewer independence, signature, authority, or official RE/PA.
"""
from __future__ import annotations
import json,hashlib
from pathlib import Path
from collections import Counter

SOURCE_R69_CASES_SHA='f22ffd7a781aafc2a0f2552be2a636df4dda437e8aecf4aafe27f79efa39bd07'
EXPECTED_R69_SOURCE='ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9'
EXPECTED_R66_PEER='626ffaf777ea12caa8c3dab492042154f3324142c5b430dad8aded48797f38bb'
EXPECTED_STATE={'NAO_INICIADO','EM_ANALISE','ABSTENCAO','PROPOSTA_NAO_HOMOLOGADA'}
LENGTH={'action':4000,'mechanic':8000,'limits':6000,'comparators':6000,'opinion':5000,'state':35}
EXPECTED_TOP={'schema','status','reviewer_self_declared','source_package_sha256','source_review_zip_sha256','reviewed_by_independent_party_verified','authority_approval','pa_official','items'}
EXPECTED_RECORD={'case_id','image_sha256',*LENGTH}

class DuplicateKey(ValueError):pass

def obj_no_dup(pairs):
    d={}
    for k,v in pairs:
        if k in d:raise DuplicateKey('DUPLICATE_JSON_KEY')
        d[k]=v
    return d

def reject_constant(s):raise ValueError('NONFINITE_JSON_CONSTANT_'+s)

def report(status,reason='',metrics=None):
    return {'status':status,'reason':reason,'syntactic_integrity_only':True,
       'reviewer_identity_authenticated':False,'reviewer_independence_verified':False,
       'canonization_authorized':False,'e0_homologated':0,'official_PA':None,
       'notion_write':False,'party_write':False,'craft_production':'HOLD',
       'metrics':metrics or {}}

def inspect(input_path, cases_path):
    try:
        blob=Path(input_path).read_bytes();base=Path(cases_path).read_bytes()
        if len(blob)>1_500_000:return report('REJECTED','OVERSIZE_REVIEW_FILE')
        if hashlib.sha256(base).hexdigest()!=SOURCE_R69_CASES_SHA:return report('REJECTED','PINNED_CASES_CHANGED')
        known=json.loads(base)['cases'];obj=json.loads(blob.decode('utf8'),object_pairs_hook=obj_no_dup,parse_constant=reject_constant)
        if type(obj) is not dict or set(obj)!=EXPECTED_TOP:return report('REJECTED','TOP_LEVEL_SCHEMA_MISMATCH')
        if obj['schema']!='ASSIMILACAO_R69_REVIEW_LOCAL_V1':return report('REJECTED','SCHEMA_VERSION_MISMATCH')
        if obj['status'] not in ('RASCUNHO_LOCAL_NAO_VERIFICADO','PARECER_AUTODECLARADO_NAO_HOMOLOGADO'):
            return report('REJECTED','FORGED_OR_UNKNOWN_STATUS')
        if obj['source_package_sha256']!=EXPECTED_R69_SOURCE or obj['source_review_zip_sha256']!=EXPECTED_R66_PEER:
            return report('REJECTED','SOURCE_ANCHOR_MISMATCH')
        if obj['reviewed_by_independent_party_verified'] is not False or obj['authority_approval'] is not False or obj['pa_official'] is not None:
            return report('REJECTED','AUTHORITY_OR_OFFICIAL_PA_FORGED')
        rid=obj['reviewer_self_declared']
        if type(rid) is not str or len(rid)>120:return report('REJECTED','REVIEWER_LABEL_INVALID')
        records=obj['items']
        if not isinstance(records,list) or len(records)!=len(known) or len(records)!=14:return report('REJECTED','REVIEW_ROSTER_SIZE')
        counted=Counter();filled=abstentions=proposals=partial=0
        for i,(rec,source) in enumerate(zip(records,known)):
            if type(rec) is not dict or set(rec)!=EXPECTED_RECORD:return report('REJECTED','RECORD_SCHEMA_'+str(i))
            if rec['case_id']!=source['id'] or rec['image_sha256']!=source['sha256']:
                return report('REJECTED','CASE_BINDING_MISMATCH_'+str(i))
            counted[rec['case_id']]+=1
            for k,maxlen in LENGTH.items():
                if type(rec[k]) is not str or len(rec[k])>maxlen:return report('REJECTED','FIELD_INVALID_'+k+'_'+str(i))
            state=rec['state']
            if state not in EXPECTED_STATE:return report('REJECTED','STATE_INVALID_'+str(i))
            if state=='ABSTENCAO':
                abstentions+=1
                if rec['limits'].strip():filled+=1
                else:partial+=1
            elif state=='PROPOSTA_NAO_HOMOLOGADA':
                proposals+=1
                if all(rec[k].strip() for k in ('action','mechanic','limits','comparators','opinion')):filled+=1
                else:partial+=1
            else:partial+=1
        if len(counted)!=14 or any(v!=1 for v in counted.values()):return report('REJECTED','DUPLICATE_CASES')
        status='STRUCTURALLY_COMPLETE_UNAUTHENTICATED' if filled==14 else 'PARTIAL_UNAUTHENTICATED'
        return report(status,'NO_INDEPENDENT_REVIEW_PROVEN',{'records_received_as_untrusted_input':len(records),'structurally_filled':filled,'partial':partial,'proposals_self_declared':proposals,'abstentions_self_declared':abstentions})
    except (OSError,UnicodeError,ValueError,TypeError,KeyError,IndexError,OverflowError) as e:
        return report('REJECTED','INPUT_ERROR_'+type(e).__name__)

if __name__=='__main__':
    import sys
    if len(sys.argv)!=3:raise SystemExit('usage: python intake_r70.py <review-file.json> <R69_CASES_MASTER_ONLY.json>')
    print(json.dumps(inspect(sys.argv[1],sys.argv[2]),ensure_ascii=False,indent=2))
