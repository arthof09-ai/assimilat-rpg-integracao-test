# PA-R70 — Gate de entrada de pareceres do R69 (MESTRE-ONLY TEST)

**Propósito:** impedir que um rascunho ou parecer autodeclarado, mesmo estruturalmente completo, seja confundido com revisão independente autenticada, decisão E0, classificação RE canônica ou custo oficial de PA.

Validador `intake_r70.py` **somente lê** um JSON do R69 e um roster local SHA-pinned. Rejeita chaves extras/faltantes, duplicações JSON, NaN, tamanho excessivo, versões ou fontes incorretas, ordem/IDs/hashes trocados, estados inventados, campos inválidos e qualquer `authority_approval=true`, `reviewed_by_independent_party_verified=true` ou `pa_official` diferente de `null`.

**Saídas:** `REJECTED`, `PARTIAL_UNAUTHENTICATED`, ou `STRUCTURALLY_COMPLETE_UNAUTHENTICATED`. Mesmo `STRUCTURALLY_COMPLETE` é somente **completude estrutural de texto autodeclarado**, jamais verificação da pessoa, independência, cognição, ciência ou autoridade. `e0_homologated=0`, `official_PA=null`, `craft_production=HOLD`, `notion_write=false`, `party_write=false` em todos os caminhos. Os exemplos nos testes são inteiramente sintéticos e **não equivalem a pareceres reais recebidos**.

**Reproduzir:** `python test_r70.py` = 32/32 PASS. Integração Chromium R69→R70: configurar `R69_HTML=/caminho/ASSIMILACAO_R69_REVISAO_OFFLINE_TEST.html python integration_r69_r70.py`; 4/4 PASS. A imagem/HTML R69 não é duplicada no pacote técnico R70 — consultar R69 persistido na Biblioteca Mestre. Sem escrita em Notion (R64–R70 continuam pendentes de reconciliação autorizada) e sem envio ao revisor.

**Proveniência:** roster `R69_CASES_MASTER_ONLY.json` recuperado do ZIP R69 e fixado por SHA. Source R66 SHA `ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9`; R66 neutral SHA `626ffaf777ea12caa8c3dab492042154f3324142c5b430dad8aded48797f38bb`.

**LAST-VERIFIED:** R70 32 unitários + 4 integração; somente software TEST.
**FIRST-PENDING:** obter e autenticar pareceres reais de avaliadores independentes sob escopo autorizado (0/14); E0 0/4.
**NEXT:** conciliar prova canônica/Atlas, apresentar conclusões ao decisor legítimo e só depois tratar custos. Não alterar R26/R27, nenhuma classificação ou receita sem adjudicação.
**NO-REPEAT:** hardening R66/R67, leitor R69 e validação R70; não transformar relatórios sintéticos em fato.
