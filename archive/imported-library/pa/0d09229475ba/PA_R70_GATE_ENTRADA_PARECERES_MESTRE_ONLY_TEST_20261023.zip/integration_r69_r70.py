"""Cross-component TEST: Chromium export from R69 -> local strict R70 intake. Synthetic fixtures only."""
import unittest,tempfile,pathlib,json,sys,os
from playwright.sync_api import sync_playwright
from intake_r70 import inspect
D=pathlib.Path(__file__).parent
HTML=pathlib.Path(os.environ.get('R69_HTML',str(D/'ASSIMILACAO_R69_REVISAO_OFFLINE_TEST.html'))).read_text(encoding='utf8')
CASES=D/'R69_CASES_MASTER_ONLY.json'
class Integration(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.pw.stop()
 def setUp(self):
  self.c=self.browser.new_context(viewport={'width':390,'height':844},accept_downloads=True);self.p=self.c.new_page();self.p.set_content(HTML,wait_until='load')
  self.t=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.t.name)/'sample.json'
 def tearDown(self):self.c.close();self.t.cleanup()
 def export(self):
  with self.p.expect_download() as download:self.p.locator('#export').click()
  download.value.save_as(self.path)
  return inspect(self.path,CASES)
 def test_01_real_empty_browser_export_partial(self):
  r=self.export();self.assertEqual(r['status'],'PARTIAL_UNAUTHENTICATED');self.assertFalse(r['reviewer_identity_authenticated'])
 def test_02_one_card_browser_export_partial(self):
  self.p.locator('#action').fill('TEST');self.p.locator('#mechanic').fill('TEST');self.p.locator('#limits').fill('TEST');self.p.locator('#comparators').fill('TEST');self.p.locator('#opinion').fill('TEST');self.p.locator('#state').select_option('PROPOSTA_NAO_HOMOLOGADA')
  r=self.export();self.assertEqual(r['metrics']['structurally_filled'],1);self.assertEqual(r['status'],'PARTIAL_UNAUTHENTICATED')
 def test_03_synthetic_14_complete_still_unauthenticated(self):
  for i in range(14):
   for k in ['action','mechanic','limits','comparators','opinion']:self.p.locator('#'+k).fill('DADO SINTETICO NÃO É PARECER')
   self.p.locator('#state').select_option('PROPOSTA_NAO_HOMOLOGADA')
   if i<13:self.p.locator('#next').click()
  r=self.export();self.assertEqual(r['status'],'STRUCTURALLY_COMPLETE_UNAUTHENTICATED');self.assertFalse(r['reviewer_independence_verified']);self.assertEqual(r['e0_homologated'],0)
 def test_04_browser_exports_reject_forged_authority(self):
  r=self.export();ob=json.loads(self.path.read_text());ob['authority_approval']=True;self.path.write_text(json.dumps(ob))
  self.assertEqual(inspect(self.path,CASES)['status'],'REJECTED')
if __name__=='__main__':unittest.main(verbosity=2)
