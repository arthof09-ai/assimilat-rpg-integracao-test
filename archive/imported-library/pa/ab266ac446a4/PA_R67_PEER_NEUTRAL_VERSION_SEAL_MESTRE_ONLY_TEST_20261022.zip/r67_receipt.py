"""Minimal additive version lock for R66 neutral reviewer ZIP. TEST only, no sending."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile,BadZipFile

R66_OUTER_SHA = 'ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9'
R66_NEUTRAL_ZIP_SHA = '626ffaf777ea12caa8c3dab492042154f3324142c5b430dad8aded48797f38bb'


def hold(reason):
 return {'status':'HOLD_R67_REVIEWER_PACKAGE_TAMPERED','reason':reason,
  'submission_authorized':False,'submitted':False,'reviewer_responses':0,'individual_effect_E0':0,
  'official_PA':None,'production':'HOLD','party_write':False,'notion_write':False}


def sha(b):return sha256(b).hexdigest()


def check(outer_r66, proposed_reviewer_zip):
 try:
  outer=Path(outer_r66).read_bytes()
  if sha(outer)!=R66_OUTER_SHA:return hold('R66_OUTER_MASTER_ANCHOR_CHANGED')
  with ZipFile(outer_r66) as z:
   trusted=z.read('PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip')
  if sha(trusted)!=R66_NEUTRAL_ZIP_SHA:return hold('R66_REGISTERED_NEUTRAL_NOT_FOUND')
  actual=Path(proposed_reviewer_zip).read_bytes()
  if sha(actual)!=R66_NEUTRAL_ZIP_SHA:return hold('REVIEWER_ZIP_BYTES_NOT_PINNED')
  if actual!=trusted:return hold('NOT_EXACTLY_REGISTERED_ZIP')
  with ZipFile(proposed_reviewer_zip) as z:
   if z.testzip() is not None:return hold('ZIP_CRC_FAILURE')
   if z.comment or any(x.comment or x.extra for x in z.infolist()):return hold('ZIP_METADATA_NOT_ALLOWED')
  return {'status':'R67_EXACT_R66_NEUTRAL_ZIP_REGISTERED_NOT_SENT',
   'reviewer_images':14,'visual_titles_masked':True,'semantic_clues_possible':True,
   'submission_authorized':False,'submitted':False,'reviewer_responses':0,
   'individual_effect_E0':0,'official_PA':None,'production':'HOLD',
   'party_write':False,'notion_write':False}
 except (KeyError,ValueError,TypeError,OSError,BadZipFile,PermissionError,EOFError) as exc:
  return hold('INVALID_INPUT_'+type(exc).__name__)
