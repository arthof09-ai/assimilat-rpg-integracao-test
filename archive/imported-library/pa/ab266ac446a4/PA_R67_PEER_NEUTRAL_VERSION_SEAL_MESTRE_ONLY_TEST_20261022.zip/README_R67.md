# PA R67 — Trava de versão sobre pacote neutro R66

**MESTRE-SIDE TEST, não enviado, não homologado.** Auditoria adversarial revelou que o validador R66 aceitaria uma abreviação de rank escondida no arquivo de instruções: `B/P/ON` não estava na lista de palavras proibidas. A correção **não reescreve R66**: o gate aditivo R67 fixa o hash do pacote inteiro de leitura e do arquivo Mestre que o contém, além de conferir igualdade exata dos bytes. Qualquer modificação de imagem, texto, CSV ou metadados do ZIP é HOLD, ainda que hashes internos sejam reajustados.

- SHA256 pacote completo R66 Mestre: `ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9`.
- SHA256 ZIP neutro da revisão: `626ffaf777ea12caa8c3dab492042154f3324142c5b430dad8aded48797f38bb`.
- Instâncias/notas originais R60–R66 continuam imutáveis; não gera novos motores, classificação, item, receita ou recursos.
- Limite: SHA fixado no código **não é assinatura de terceiro**, não prova cegamento psicológico ou ausência de nomes no texto mecânico. Revisor humano nunca recebeu este material: **0/14 respostas**. Classificações RE E0 oficiais: **0/4**. Produção, PA oficial, F5/RC5 HOLD, Party/O Primeiro NO-WRITE.

Este ZIP é **somente delta de QA**. Para reproduzir `test_r67.py`, ter o pacote R66 original verificado e seu ZIP interno no diretório de trabalho que o teste referencia, ou ajustar caminhos locais sem alterar os hashes fixados. Não enviar nenhuma dessas cópias à Party. Checkpoint documental Notion R64+ continua PENDENTE por bloqueio de segurança registrado no R65; não contornar por outro endpoint.
