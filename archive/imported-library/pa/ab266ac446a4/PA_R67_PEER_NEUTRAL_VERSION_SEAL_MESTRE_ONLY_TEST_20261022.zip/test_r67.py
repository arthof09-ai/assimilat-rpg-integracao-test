from __future__ import annotations
import io,sys,unittest,tempfile,zipfile,os
from pathlib import Path
from r67_receipt import check,sha,R66_NEUTRAL_ZIP_SHA,R66_OUTER_SHA

class R67Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.outer=Path(os.environ.get('PA_R66_OUTER','/mnt/data/pa_sucessao/PA_R66_CARTOES_MECANICOS_NEUTROS_MESTRE_ONLY_TEST_20261022.zip'))
  cls.peer=Path(os.environ.get('PA_R66_PEER','/mnt/data/pa_sucessao/r66_neutral_cards/PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip'))
  cls.tmp=tempfile.TemporaryDirectory();cls.temp=Path(cls.tmp.name)
  with zipfile.ZipFile(cls.peer) as z:cls.members={i.filename:z.read(i.filename) for i in z.infolist()}
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def forged(self,updates=None,comment=b'',extra=None):
  c=dict(self.members);c.update(updates or {});p=self.temp/(self.id().split('.')[-1]+'.zip')
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
   z.comment=comment
   for k,b in c.items():z.writestr(k,b)
   if extra:z.writestr(extra,b'foo')
  return p
 def deny(self,peer=None,outer=None):self.assertEqual(check(outer or self.outer,peer or self.peer)['status'],'HOLD_R67_REVIEWER_PACKAGE_TAMPERED')
 def test_01_original_allowed_but_unsent(self):
  r=check(self.outer,self.peer);self.assertEqual(r['status'],'R67_EXACT_R66_NEUTRAL_ZIP_REGISTERED_NOT_SENT');self.assertFalse(r['submission_authorized'])
 def test_02_readme_abbreviations_injected(self):self.deny(peer=self.forged({'LEIA_ANTES.md':self.members['LEIA_ANTES.md']+b'\nESCALA B/P/ON\n'}))
 def test_03_conflicting_csv_header(self):self.deny(peer=self.forged({'RESPOSTAS_14.csv':self.members['RESPOSTAS_14.csv'].replace(b'acao',b'nivel')}))
 def test_04_mutate_png(self):
  key=sorted(p for p in self.members if p.endswith('.png'))[0]
  self.deny(peer=self.forged({key:self.members[key][:-8]+b'xxxxYYYY'}))
 def test_05_zip_comment(self):self.deny(peer=self.forged(comment=b'B/P/ON'))
 def test_06_unexpected_file(self):self.deny(peer=self.forged(extra='oracle.txt'))
 def test_07_previous_r60_is_not_new_version(self):
  path=Path(os.environ.get('PA_R60_LEGACY','/mnt/data/pa_sucessao/r65_receipt_pinned/PA_R60_PEER14_CEGO_SEM_GABARITO_MESTRE_ONLY_TEST_20261022.zip'));self.deny(peer=path)
 def test_08_outer_unavailable(self):self.deny(outer=self.temp/'missing.zip')
 def test_09_outer_tampered(self):
  p=self.temp/'outer-fake.zip';p.write_bytes(self.outer.read_bytes()+b'X');self.deny(outer=p)
 def test_10_peer_unavailable(self):self.deny(peer=self.temp/'missing.zip')
 def test_11_pinned_outer_sha(self):self.assertEqual(sha(self.outer.read_bytes()),R66_OUTER_SHA)
 def test_12_pinned_peer_sha(self):self.assertEqual(sha(self.peer.read_bytes()),R66_NEUTRAL_ZIP_SHA)
if __name__=='__main__':unittest.main(verbosity=2)
