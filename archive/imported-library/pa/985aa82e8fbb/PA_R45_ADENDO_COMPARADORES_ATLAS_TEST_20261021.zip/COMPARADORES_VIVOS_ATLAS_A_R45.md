# PA / R45 — Comparadores vivos adicionais (MESTRE-SIDE, TEST)

**Estado:** VERIFICADOS quanto à existência do texto citado nas fontes canônicas, PROVISÓRIO quanto ao juízo RE. Não atualiza técnica ou ficha original. Pesquisa efetuada depois de congelar os 26 candidatos (SHA `2f1e88e3c7980cf376ed2ec76816dec48d3f4779bec55a9f6e3bf5687e799a5e`). Estes comparadores NÃO foram usados para fabricar a concordância histórica de 8/26.

## Fontes consultadas e autoridade

- PR-ECO-01 — Atlas Canônico A: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab — método dominante, poder real, 14 eixos e três comparadores. Rótulo/valor de venda não define potência.
- DMG-RANK-01 v1.1: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e — dano médio e bandas padrão **apenas** após RE por efeito; valor de origem explícito não deve ser recalculado como se ausente.
- Dong Goui, Prata 2: https://app.notion.com/p/b06c2b324ede8279a0f4014c14125a98 — ficha Mestre com 3d8+6 de arma (conforme também citado no DMG). A ficha guarda mais de uma versão/bloco; aqui não misturar evolução nem itens distintos.
- Gorrok (caçador): https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474 — explosão 4d6 em área de 9 metros, armamento 5d8, Pele de Pedra +2 CA e +15 vida por 2d6 turnos. DMG cita Gorrok O1, mas a página consultada não fornece por si uma ficha completa de comparação limpa de RE atual; se usar O1, remeter à autoridade DMG-RANK em vez de deduzir por inferência.
- Fonte das 26 técnicas de exame: https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff . As fotos derivam do material de outro RPG, com níveis estrangeiros e custos de PA nativos ausentes.

## Casos exemplares por família

| ID opaco e título Mestre-only | Magnitude base explícita | Âncora nativa relevante | Parecer parcial |
|---|---|---|---|
| TEC-1808CAC63847 — Rajada Mística | 1d10 força = DME 5,5 em um feixe; feixes aumentam conforme nível da origem | DMG banda Bronze 4–18; Bronze é impacto local simples | Bronze E2 **somente no componente base** é compatível; rank da versão multifeixes ainda E3 |
| TEC-B0D00FDE2408 — Raio de Fogo | 1d10 fogo = DME 5,5, incêndio de objeto condicional | Mesma banda Bronze e condição ambiental | Bronze E2 para dano base; versatilidade, escala e custo dependem de adaptação |
| TEC-968D29765EB1 — Orbe Cromática | 3d8 = DME 13,5 em um alvo, com escolha de seis elementos | Dong Goui P2 tem arma 3d8+6 = DME 19,5; Gorrok registra 4d6 = DME 14 em 9m de área | Escolha elemental é vantagem real, mas comparar apenas DME com arma ou ataque de área seria enganoso. Prata E3 apenas como proposta inicial, não canonizar |
| TEC-6B84A461C262 — Escudo Arcano | +5 CA por até um turno e proteção contra mísseis mágicos | Gorrok possui +2 CA/+15 vida por 2d6 turnos | São dois perfis defensivos com permanência e usuário diferentes. O bônus +5 não deve ser levado literalmente à escala de CA Assimilação sem comparador de defesa. Prata E3 permanece insuficiente |
| TEC-39F038CF281E — Imobilizar Pessoa | Paralisia de um humanoide por até 1 min, resistência Sabedoria inicial e por turno, concentração | Atlas A destaca controle e bypass; receita P2 Prata vedação tem objeto/magia contida, não é controle de humanoide tático equivalente | Não deduzir Lendário pelo rótulo, nem descartar possibilidade de RE superior por controle. Ouro E3 e faixa Prata–Ouro Negro provisórios; requer NPC comparador e adaptação de salvaguarda |

## Resultado útil de engenharia

A decomposição em 67 subefeitos deixa explícito por que o rank base por dano **não é o rank completo**: Rajada pode gerar vários feixes, Orbe acrescenta versatilidade, Toque Chocante nega reação, Faca de Gelo tem explosão independente, Escudo afeta defesa e imunidade, e Imobilizar é controle severo sem dano. O comparador de apenas um atributo não substitui os 14 eixos do Atlas.

**CHECKPOINT:** Cinco famílias receberam exemplares reais do sistema; nenhuma teve certificação integral de três comparadores. NÃO elevar contador de adjudicação Atlas de 0. Pendência seguinte: obter comparador vivo atual de controle mental e de proteção reativa, revisar escala de ações, e obter voto do Mestre sobre qualquer reclassificação oficial.
