import unittest
import math
import pa_engine as e

class TestCorpusAndHistorical(unittest.TestCase):
    def test_01_cohort_54(self):self.assertEqual(e.stats()['physical_pages'],54)
    def test_02_cohort_composition(self):self.assertEqual([e.stats()['families'][f]['total'] for f in ('armas','armaduras','roupas_acessorios','artefatos')],[19,7,13,15])
    def test_03_extra_7(self):self.assertEqual(e.stats('ALL_61')['physical_pages'],61)
    def test_04_unique_uuid(self):self.assertEqual(e.stats('ALL_61')['distinct_page_ids'],61)
    def test_05_arco_daily(self):self.assertEqual(e.lookup('Arco Exterminador Elemental (L)')['pa_daily']['value'],64)
    def test_06_amplificador(self):self.assertEqual(e.lookup('Amplificador de Atributo')['pa_daily']['value'],15)
    def test_07_bota_dual(self):
        a=e.lookup('Bota Caminho Veloz');self.assertEqual((a['pa_daily']['value'],a['pa_activation']['value']),(18,5))
    def test_08_amuleto_dual(self):
        a=e.lookup('Amuleto Tempo Eterno');self.assertEqual((a['pa_daily']['value'],a['pa_activation']['value']),(15,15))
    def test_09_armour_double_account(self):
        a=e.lookup('SOMBRA SUSSURRANTE');self.assertEqual(a['pa_daily']['value'],34);self.assertIn('Já somado',a['mechanics_summary'])
    def test_10_interpret_by_rule(self):
        self.assertEqual(e.lookup('Sabedoria Ancestral')['pa_daily']['classification'],'REGRA_R_PA_DIA')
    def test_11_ambiguous_midpage_not_rule(self):
        a=e.lookup('AMANTE DAS SOMBRAS');self.assertIsNone(a['pa_daily']['value']);self.assertEqual(a['cost_unqualified']['value'],21)
    def test_12_unknown_unit_not_pa(self):
        a=e.lookup('Lança Sopro Congelante');self.assertIsNone(a['pa_daily']['value']);self.assertEqual(a['cost_unqualified']['value'],24)
    def test_13_missing_not_zero(self):self.assertIsNone(e.lookup('Vestes Guardião Cosmo')['pa_daily']['value'])
    def test_14_duplicate_identity(self):
        with self.assertRaises(ValueError): e.lookup('Amuleto')

class TestReadAndAccounting(unittest.TestCase):
    def test_15_bare_last_line(self):
        z=e.parse_cost_lines('Amuleto concede +3 SAB\n15 PA');self.assertEqual(z['occurrences'][0]['status'],'INTERPRETADA_R_PA_DIA')
    def test_16_bare_not_last(self):
        z=e.parse_cost_lines('Custo: 21 PA\nConcede +3 SAB');self.assertFalse(z['occurrences'])
    def test_17_context_activation(self):
        z=e.parse_cost_lines('20 PA para ativar');self.assertEqual(z['occurrences'][0]['kind'],'activation')
    def test_18_context_day(self):
        z=e.parse_cost_lines('35 PA por dia');self.assertEqual(z['occurrences'][0]['kind'],'daily')
    def test_19_context_turn(self):
        z=e.parse_cost_lines('2 PA por turno');self.assertEqual(z['occurrences'][0]['kind'],'turn')
    def test_20_context_is_not_daily(self):
        z=e.parse_cost_lines('20 PA para ativar');self.assertEqual(len([x for x in z['occurrences'] if x['kind']=='daily']),0)
    def test_21_no_item_scope(self):self.assertFalse(e.parse_cost_lines('15 PA',item_record=False)['occurrences'])
    def test_22_known_subtotal(self):
        z=e.costs_for_equipped(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'])
        self.assertEqual(z['historical_daily_total'],119)
    def test_23_partial_not_total(self):
        z=e.costs_for_equipped(['Arco Exterminador Elemental (L)','Vestes Guardião Cosmo']);self.assertIsNone(z['historical_daily_total'])
    def test_24_duplicate_equipment_fails(self):
        with self.assertRaises(ValueError):e.costs_for_equipped(['Arco Exterminador Elemental (L)']*2)
    def test_25_pa_livre_formula(self):
        z=e.costs_for_equipped(['Arco Exterminador Elemental (L)'],pa_total=100,pa_committed_other=20)
        self.assertEqual(z['pa_livre_before_undefined_item_daily_accounting'],80)
    def test_26_no_auto_convert(self):
        z=e.costs_for_equipped(['Arco Exterminador Elemental (L)'],pa_total=100,pa_committed_other=20)
        self.assertEqual(z['daily_cost_allocation_to_committed_or_debited'],'PENDENTE_REGRA_DE_COBRANCA')
    def test_27_activation_shortfall_no_colapse(self):
        self.assertEqual(e.activation_check(10,'Bota Caminho Veloz')['status'],'COBERTURA_NUMERICA')
        z=e.activation_check(3,'Bota Caminho Veloz');self.assertEqual(z['status'],'INSUFICIENTE_NUMERICAMENTE');self.assertIn('nao generalizado',z['consequence'])
    def test_28_usage_scoped(self):
        z=e.costs_for_equipped(['Bota Caminho Veloz'],usage={'Bota Caminho Veloz':2});self.assertEqual(z['hypothetical_daily_budget_if_daily_is_debit'],28)
        self.assertEqual(z['historical_daily_total'],18)

class TestModelsAndCounterfactuals(unittest.TestCase):
    def test_T1_passive_vs_active_no_fake_numbers(self):
        a={'name':'T1','effects':[{'id':'x','kind':'damage','value':20,'modality':'passive'}]}
        b={'name':'T1','effects':[{'id':'x','kind':'damage','value':20,'modality':'active'}]}
        x=e.predict_new(a);y=e.predict_new(b)
        self.assertEqual(x['daily_missing_rates_for'],['x']);self.assertEqual(y['activation_missing_rates_for'],['x'])
    def test_T2_intensity_without_rates(self):
        for n in (5,10,20):
            x=e.predict_new({'effects':[{'id':'d','kind':'damage','value':n,'modality':'passive'}]});self.assertIsNone(x['pa_day_estimate'])
    def test_T3_repeat_changes_damage_not_pa(self):
        self.assertEqual(e.damage_delta(10,20,0,3)['hypothetical_expected_marginal_damage'],3*e.damage_delta(10,20,0,1)['hypothetical_expected_marginal_damage'])
    def test_T4_rank_ignored_in_proposal(self):
        item={'effects':[{'id':'str','kind':'attribute','value':3,'modality':'passive'}]}
        self.assertEqual(e.predict_new({**item,'rank':'Bronze'},'PROPOSTA',{'attribute':5})['pa_day_estimate'],e.predict_new({**item,'rank':'Lendario'},'PROPOSTA',{'attribute':5})['pa_day_estimate'])
    def test_T5_user_ignored_in_item_cost(self):
        base={'effects':[{'id':'x','kind':'attribute','value':3,'modality':'passive'}]}
        self.assertEqual(e.predict_new({**base,'user':'A'},'PROPOSTA',{'attribute':5})['pa_day_estimate'],e.predict_new({**base,'user':'B'},'PROPOSTA',{'attribute':5})['pa_day_estimate'])
    def test_T6_no_double_component(self):
        with self.assertRaises(ValueError):e.predict_new({'effects':[{'id':'x','kind':'ca','value':2},{'id':'x','kind':'ca','value':2}]},'PROPOSTA',{'ca':10})
    def test_T7_multi_equipment_semantics(self):
        z=e.costs_for_equipped(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'],pa_total=180,pa_committed_other=20)
        self.assertEqual(z['historical_daily_total'],119);self.assertEqual(z['pa_livre_before_undefined_item_daily_accounting'],160)
    def test_T8_marginal_effect_with_own_rate(self):
        a={'effects':[{'id':'ca','kind':'ca','value':6},{'id':'con','kind':'attribute','value':10}]}
        b={'effects':[{'id':'ca','kind':'ca','value':6}]}
        ra={'ca':2,'attribute':5}
        self.assertEqual(e.predict_new(a,'PROPOSTA',ra)['pa_day_estimate']-e.predict_new(b,'PROPOSTA',ra)['pa_day_estimate'],50)
    def test_T9_missing_rate_refusal(self):
        z=e.predict_new({'effects':[{'id':'ca','kind':'ca','value':6},{'id':'rd','kind':'rd','value':15},{'id':'con','kind':'attribute','value':10}]},'PROPOSTA',{'attribute':5})
        self.assertIsNone(z['pa_day_estimate']);self.assertEqual(z['hypothetical_known_daily_subtotal'],50)
    def test_T10_historical_contradiction_preserved(self):
        a=e.lookup('Arco Exterminador Elemental (L)'); p=e.predict_new({'effects':[{'id':'bonus','kind':'damage','value':20}]},'PROPOSTA',{'damage':1})
        self.assertEqual(a['pa_daily']['value'],64);self.assertEqual(p['pa_day_estimate'],20);self.assertTrue(p['historical_cost_changed'] is False)
    def test_damage_rd_exact(self):
        z=e.damage_delta(10,20,25,1,1,1,1);self.assertEqual(z['marginal_post_rd_per_eligible_hit'],5)
    def test_damage_eligibility_half(self):
        z=e.damage_delta(10,20,0,4,.5,1,.5);self.assertEqual(z['hypothetical_expected_marginal_damage'],20)
    def test_no_arbitrary_rate(self):self.assertEqual(e.damage_delta(10)['pa_daily_cost'],'NAO_ESTIMAVEL_SEM_TAXA_ESTRATIFICADA')
    def test_proposal_attr_hypothesis_only(self):
        z=e.hypothesis_attributes(10);self.assertEqual(z['hypothetical_component_pa_day'],50);self.assertEqual(z['whole_item_pa_day'],'NAO_INFERIDO')
    def test_compare_no_causality(self):
        x=e.compare_items('Bota Caminho Veloz','Traje águia celeste');self.assertEqual(x['delta_known_pa_day'],2);self.assertIn('NAO_EQUIVALE',x['numeric_comparison'])
    def test_holdout_not_false_independent(self):self.assertFalse(e.holdout_plan()['genuine_independent_holdout'])
    def test_historical_stats(self):
        x=e.stats();self.assertEqual(x['explicit_daily_count'],12);self.assertEqual(x['interpreted_daily_count'],2);self.assertEqual(x['recorded_activation_count'],5);self.assertEqual(x['dual_daily_activation_count'],4)


class TestUnknownNotZero(unittest.TestCase):
    def test_only_active_not_zero_daily(self):
        out=e.predict_new({'effects':[{'id':'blast','kind':'damage','value':20,'modality':'active'}]},'PROPOSTA',{'activation:damage':2})
        self.assertIsNone(out['pa_day_estimate']);self.assertEqual(out['pa_activation_estimate'],40)
        self.assertEqual(out['daily_availability_of_active_only_items'],'PENDENTE_NAO_ASSUMIR_ZERO')
    def test_only_passive_no_activation(self):
        out=e.predict_new({'effects':[{'id':'a','kind':'attribute','value':3,'modality':'passive'}]},'PROPOSTA',{'attribute':5})
        self.assertIsNone(out['pa_activation_estimate']);self.assertEqual(out['pa_day_estimate'],15)

if __name__=='__main__': unittest.main()
