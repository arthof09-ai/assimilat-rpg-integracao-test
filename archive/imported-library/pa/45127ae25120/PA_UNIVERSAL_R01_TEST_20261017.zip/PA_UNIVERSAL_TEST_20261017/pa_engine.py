"""PA x CRAFT single experimental read-only evaluator / v0.2 (17 Oct 2026).
- Historical records are never overwritten by analytic predictions.
- 'PA/day' does not assert PA committed vs actually spent.
- Proposal parameters are explicit and hypothetical; no automatic canonical cost.
- Input via Python functions or JSON CLI; works in ordinary ChatGPT by interpreting replies.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import re
import statistics
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

HERE=Path(__file__).resolve().parent
DATA=HERE/'corpus_pa_v1.json'
RULE='R-PA-DIA'
RULE_URL='https://app.notion.com/p/3eec2b324ede8148a5b3ee17df578535'
SOURCE_MAGIC='https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373'

def load():
    return json.loads(DATA.read_text(encoding='utf-8'))['items']

def _flat(s):
    return ''.join(c for c in unicodedata.normalize('NFD',s.casefold()) if unicodedata.category(c)!='Mn').strip()

def _get_item(identifier):
    rows=load()
    q=_flat(str(identifier))
    matching=[r for r in rows if _flat(r['item_id'])==q or _flat(r['name'])==q or _flat(r['source_url'])==q]
    if len(matching)!=1: raise ValueError(f'Identidade deve resolver a uma unica ficha: {identifier} (matches={len(matching)})')
    return matching[0]

def lookup(identifier):
    r=_get_item(identifier)
    return {'mode':'HISTORICO','item_id':r['item_id'],'name':r['name'],'family':r['family'],
        'rank_public':r['rank_public'],'cohort':r['cohort'],'source_url':r['source_url'],
        'mechanics_summary':r['mechanics_summary'],'pa_daily':r['pa_daily'],
        'pa_activation':r['pa_activation'],'cost_unqualified':r['cost_unqualified'],
        'pa_accounting_semantics':r['pa_semantics'],
        'historical_unchanged':True,'lineage_cluster':r['lineage_cluster'],
        'warning':'Ausencia nao significa custo zero; PA/dia nao e automaticamente PA comprometido.'}

def costs_for_equipped(ids, pa_total=None, pa_committed_other=None, usage=None):
    """Partial costs remain explicitly partial. Usage is dict uuid/name->nonnegative integer activations."""
    if len(ids)!=len(set(ids)): raise ValueError('Identidades duplicadas na configuracao')
    rows=[lookup(x) for x in ids]
    daily=sum(x['pa_daily']['value'] for x in rows if x['pa_daily']['value'] is not None)
    unknown=[x['name'] for x in rows if x['pa_daily']['value'] is None]
    usage=usage or {}
    per_activations={}
    activation_consumption=0
    unknown_activation=[]
    for x in rows:
        n=next((count for key,count in usage.items() if _flat(str(key)) in (_flat(x['item_id']),_flat(x['name']))),0)
        if not isinstance(n,int) or isinstance(n,bool) or n<0: raise ValueError('Uso de habilidade deve ser inteiro nao negativo')
        val=x['pa_activation']['value']
        if n and val is None: unknown_activation.append(x['name'])
        if val is not None:
            per_activations[x['name']]={'pa_each':val,'uses_requested':n,'subtotal_pa':val*n,'classification':x['pa_activation']['classification']}
            activation_consumption+=val*n
    result={'mode':'CONFIGURACAO','items_count':len(rows), 'historical_daily_known_subtotal':daily,
        'historical_daily_total':daily if not unknown else None,'daily_unknown_items':unknown,
        'daily_total_status':'SOMA_HISTORICA_COMPLETA' if not unknown else 'APENAS_SUBTOTAL',
        'activation_costs':per_activations,'requested_activation_known_subtotal':activation_consumption,
        'activation_unknown_for_requested_uses':unknown_activation,
        'warning_no_temporal_addition':'PA por dia e PA por ativacao sao unidades distintas e nao foram somados.',
        'daily_cost_allocation_to_committed_or_debited':'PENDENTE_REGRA_DE_COBRANCA',
        'historical_unchanged':True}
    if not unknown and not unknown_activation:
        result['hypothetical_daily_budget_if_daily_is_debit']=daily+activation_consumption
        result['hypothetical_daily_budget_status']='SOMENTE_SE_CUSTOS_DIARIOS_FOREM_DEBITOS_E_USOS_OCORREREM_NO_MESMO_DIA'
    if pa_total is not None or pa_committed_other is not None:
        if pa_total is None or pa_committed_other is None: raise ValueError('PA Total e PA comprometido externo devem ser fornecidos juntos')
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0 for v in (pa_total,pa_committed_other)) or pa_committed_other>pa_total:
            raise ValueError('Valores PA Total/comprometido invalidos')
        free=pa_total-pa_committed_other
        result['pa_livre_before_undefined_item_daily_accounting']=free
        result['activation_affordability_from_known_other_commits']='INSUFICIENTE' if activation_consumption>free else 'COBERTURA_NUMERICA_PARCIAL'
        result['activation_item_colapse']='NAO_DEDUZIDO: regra de falha de conjuracao nao prova efeito de item'
    return result


def activation_check(pa_free,identifier):
    if not isinstance(pa_free,(int,float)) or not math.isfinite(pa_free) or pa_free<0: raise ValueError('PA Livre invalido')
    r=lookup(identifier);cost=r['pa_activation']['value']
    return {'item':r['name'],'pa_livre':pa_free,'cost':cost,
        'status':'CUSTO_DESCONHECIDO' if cost is None else ('COBERTURA_NUMERICA' if pa_free>=cost else 'INSUFICIENTE_NUMERICAMENTE'),
        'no_effect_applied':True,
        'consequence':'PENDENTE_PARA_USO_DE_ITEM; colapso de magia forcada nao generalizado',
        'reference_magic_system':SOURCE_MAGIC}


def parse_cost_lines(body,item_record=True):
    """Strict, context-sensitive mini-parser. Do not parse unrelated text; returns occurrences, not automatically total.
    Bare N PA defaults daily only when isolated in the final meaningful item mechanics line.
    """
    if not isinstance(body,str): raise ValueError('Esperado texto')
    lines=[re.sub(r'\s+',' ',x.strip()) for x in body.splitlines() if x.strip()]
    results=[]
    daily_pat=re.compile(r'\b(?P<n>\d+)\s*(?:de\s+)?PA\s*(?:por\s+dia|/dia)\b',re.I)
    activation_pat=re.compile(r'\b(?P<n>\d+)\s*(?:de\s+)?PA\s*(?:para\s+ativar|por\s+ativa[cç][aã]o|para\s+usar)\b',re.I)
    turn_pat=re.compile(r'\b(?P<n>\d+)\s*(?:de\s+)?PA\s*(?:por\s+turno|/turno)\b',re.I)
    for index,line in enumerate(lines):
        if line.lower().startswith(('fonte:', 'referencia:', 'referência:')): continue
        for kind,pat in (('daily',daily_pat),('activation',activation_pat),('turn',turn_pat)):
            for match in pat.finditer(line):
                results.append({'line':index+1,'kind':kind,'value':int(match.group('n')),'status':'EXPLICITA','literal':match.group(0)})
    # R-PA-DIA: no activation/turn trigger, final independent cost line, not a passing figure in prose.
    if lines and item_record:
        last=lines[-1]
        bare=re.fullmatch(r'(?:[-*>\s]*)(?:(?:Custo|Gasto)\s*[:\-]?\s*)?(\d+)\s*(?:de\s+)?PA\.?',last,flags=re.I)
        if bare and not daily_pat.search(last) and not activation_pat.search(last):
            results.append({'line':len(lines),'kind':'daily','value':int(bare.group(1)),'status':'INTERPRETADA_R_PA_DIA','literal':last,'rule':RULE,'rule_url':RULE_URL})
    return {'occurrences':results,'classification':'INTERPRETACAO_DE_CUSTOS_NAO_TOTALIZACAO','item_record':item_record,'pending':'contexto e unidade de ocorrencias nao enquadradas exigem revisao'}


def hypothesis_attributes(points, pa_per_point=5):
    if not all(isinstance(x,(int,float)) and math.isfinite(x) and x>=0 for x in (points,pa_per_point)):
        raise ValueError('Pontos/taxa devem ser numeros positivos')
    return {'hypothesis':'H1_5_PA_PER_POINT','points':points,'assumed_rate_pa_day_per_point':pa_per_point,'hypothetical_component_pa_day':points*pa_per_point,'status':'HIPOTESE_MESTRE_SUSTENTADA_POR_UM_EXEMPLO_PURO_NAO_UNIVERSAL','source':'https://app.notion.com/p/3c6c2b324ede82baa4a801de533a5975','whole_item_pa_day':'NAO_INFERIDO'}


def predict_new(item,mode='ANALITICO',rates=None):
    """Models only user-selected rates and source-known costs. No fabricated rate for damage/CA/RD etc.
    effects [{id,kind,value,modality,unit, known_pa_daily?,known_pa_activation?}]
    rates may explicitly provide kind -> PA/day per unit, and "activation:kind" -> PA/use per unit.
    """
    if mode not in ('ANALITICO','PROPOSTA'): raise ValueError('Novo item aceita ANALITICO ou PROPOSTA')
    if not isinstance(item,dict): raise ValueError('Entrada objeto')
    rates=rates or {}
    effects=item.get('effects',[])
    if not isinstance(effects,list): raise ValueError('effects lista')
    if len([e.get('id') for e in effects]) != len(set(e.get('id') for e in effects)):
        raise ValueError('IDs de efeito duplicados: evitar contagem dupla')
    proposed_daily=0;proposed_act=0;components=[];incomplete_daily=[];incomplete_act=[]
    for e in effects:
        k=e.get('kind');v=e.get('value')
        if not isinstance(k,str) or not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) or v<0:
            raise ValueError('Efeito requer kind e magnitude nao negativa')
        modality=e.get('modality','passive')
        if modality not in ('passive','active','hybrid'): raise ValueError('modality')
        row={'id':e['id'],'kind':k,'value':v,'modality':modality,'source':'EFEITO_DESCRITO_PELO_USUARIO'}
        if 'known_pa_daily' in e:
            x=e['known_pa_daily']
            if not isinstance(x,(int,float)) or x<0: raise ValueError('known_pa_daily invalido')
            row['historical_daily_whole_effect']=x # not decomposed with proposed rates
        if mode=='PROPOSTA' and k in rates and modality in ('passive','hybrid'):
            rat=rates[k]
            if not isinstance(rat,(int,float)) or rat<0 or not math.isfinite(rat): raise ValueError('Taxa invalida')
            val=v*rat;row['hypothetical_daily_component']=val;row['assumed_daily_rate']=rat;proposed_daily+=val
        else:
            if modality in ('passive','hybrid'): incomplete_daily.append(e['id'])
        ak='activation:'+k
        if mode=='PROPOSTA' and ak in rates and modality in ('active','hybrid'):
            rat=rates[ak]
            if not isinstance(rat,(int,float)) or rat<0 or not math.isfinite(rat): raise ValueError('Taxa invalida')
            val=v*rat;row['hypothetical_activation_component']=val;row['assumed_activation_rate']=rat;proposed_act+=val
        else:
            if modality in ('active','hybrid'): incomplete_act.append(e['id'])
        components.append(row)
    return {'mode':mode,'item':item.get('name','Novo item'), 'family':item.get('family'), 'components':components,
        'pa_day_estimate':proposed_daily if mode=='PROPOSTA' and not incomplete_daily and any(x['modality'] in ('passive','hybrid') for x in components) else None,
        'pa_activation_estimate':proposed_act if mode=='PROPOSTA' and not incomplete_act and any(x['modality'] in ('active','hybrid') for x in components) else None,
        'hypothetical_known_daily_subtotal':proposed_daily if mode=='PROPOSTA' and any(x['modality'] in ('passive','hybrid') for x in components) else None,
        'hypothetical_known_activation_subtotal':proposed_act if mode=='PROPOSTA' and any(x['modality'] in ('active','hybrid') for x in components) else None,
        'daily_availability_of_active_only_items':'PENDENTE_NAO_ASSUMIR_ZERO' if any(x['modality']=='active' for x in components) else None,
        'daily_missing_rates_for':incomplete_daily,'activation_missing_rates_for':incomplete_act,
        'rates_basis':'PARAMETROS EXPLICITAMENTE FORNECIDOS PARA CENARIO, NAO VALIDOS NO CANONE',
        'no_auto_rank_multiplier':True,'canonized':False,'historical_cost_changed':False,
        'status':'ESTIMATIVA_CONDICIONAL_NAO_CANONICA' if mode=='PROPOSTA' else 'ANALISE_SEM_COEFICIENTES_CALIBRADOS'}


def damage_delta(base_damage,bonus=20,rd=0,attempts=1,p_hit=1,targets=1,eligibility=1):
    """Exact conditional Δ after numeric RD for deterministic base_damage; not PA conversion.
    Applicability p_hit/eligibility are scenario assumptions, not campaign frequencies.
    """
    nums=(base_damage,bonus,rd,attempts,p_hit,targets,eligibility)
    if not all(isinstance(x,(int,float)) and math.isfinite(x) for x in nums):raise ValueError('Parametros numericos')
    if any(x<0 for x in nums) or not(0<=p_hit<=1) or not(0<=eligibility<=1): raise ValueError('Parametros fora do intervalo')
    per=max(0,base_damage+bonus-rd)-max(0,base_damage-rd)
    return {'base_damage':base_damage,'bonus':bonus,'rd':rd,'marginal_post_rd_per_eligible_hit':per,
       'assumed_attempts':attempts,'assumed_hit_probability':p_hit,'assumed_targets':targets,
       'assumed_condition_probability':eligibility,
       'hypothetical_expected_marginal_damage':per*attempts*p_hit*targets*eligibility,
       'pa_daily_cost':'NAO_ESTIMAVEL_SEM_TAXA_ESTRATIFICADA','status':'CENARIO_ANALITICO_NAO_COMBATE_REAL'}



def compare_items(first,second):
    a,b=lookup(first),lookup(second)
    x,y=a['pa_daily']['value'],b['pa_daily']['value']
    return {'mode':'COMPARACAO_HISTORICA','first':a,'second':b,
      'delta_known_pa_day':(y-x) if x is not None and y is not None else None,
      'numeric_comparison':'NAO_EQUIVALE_A_COEFICIENTE_CAUSAL: modalidades/ranks/efeitos diferentes',
      'cost_unit_consistent': x is not None and y is not None,
      'historical_unchanged':True}

def _quantile(sorted_data,p):
    if not sorted_data:return None
    q=(len(sorted_data)-1)*p;a=math.floor(q);b=math.ceil(q);return sorted_data[a] if a==b else sorted_data[a]+(sorted_data[b]-sorted_data[a])*(q-a)

def stats(cohort='MAPA_T01_54'):
    rows=[r for r in load() if cohort=='ALL_61' or r['cohort']==cohort]
    fam=defaultdict(lambda:Counter());explicit=[];interpreted=[];dual=[]
    for x in rows:
        f=fam[x['family']];f['total']+=1
        s=x['pa_daily']['classification'];f[s]+=1
        if s=='EXPLICITA':explicit.append(x['pa_daily']['value'])
        if s=='REGRA_R_PA_DIA':interpreted.append(x['pa_daily']['value'])
        if x['pa_activation']['value'] is not None:
            f['activation_documented']+=1
            if x['pa_daily']['value'] is not None:dual.append(x['item_id'])
    z=sorted(explicit)
    clusters={x['lineage_cluster'] for x in rows}
    return {'cohort':cohort,'physical_pages':len(rows),'distinct_page_ids':len({x['item_id'] for x in rows}),
      'provisional_effect_lineage_clusters':len(clusters),
      'distinct_effects':'NAO_DETERMINAVEL_NESTA_EXTRACAO_RESUMIDA',
      'families':{k:dict(v) for k,v in fam.items()},
      'explicit_daily_count':len(explicit),'interpreted_daily_count':len(interpreted),
      'recorded_activation_count':sum(x['pa_activation']['value'] is not None for x in rows),
      'dual_daily_activation_count':len(dual),'dual_item_ids':dual,
      'explicit_daily_values_sorted':z,'explicit_daily_median':statistics.median(z) if z else None,
      'explicit_daily_q1':_quantile(z,.25),'explicit_daily_q3':_quantile(z,.75),
      'explicit_daily_IQR':_quantile(z,.75)-_quantile(z,.25) if z else None,
      'missing_not_zero':sum(x['pa_daily']['value'] is None for x in rows),
      'exclusion':'Nulos excluidos, itens/efeitos nao convertidos em observacoes independentes',
      'warning':'Distribuicao com selecao, mistura de familia e confusao de efeitos. Estatisticas descritivas, NAO coeficientes causais.'}


def holdout_plan():
    """Retrospective grouping. Already viewed -> not independent scientific holdout."""
    cluster={};rows=load()
    for r in rows:
        key=r['lineage_cluster']
        cluster[key]='RESERVA_RETROSPECTIVA' if int(hashlib.sha256(key.encode()).hexdigest()[:8],16)%5==0 else 'EXPLORATORIO'
    return {'items_total':len(rows),'groups_total':len(cluster),'items_reserve':sum(cluster[r['lineage_cluster']]=='RESERVA_RETROSPECTIVA' for r in rows),
      'groups_reserve':sum(v=='RESERVA_RETROSPECTIVA' for v in cluster.values()),
      'split':{r['item_id']:cluster[r['lineage_cluster']] for r in rows},
      'genuine_independent_holdout':False,
      'reason':'Custos dos 61 itens ja observados no ciclo; split retrospectivo valida regressao tecnica, nao capacidade preditiva independente.',
      'future_preregistered_rule':'Para novas fontes NAO lidas: UUID/linhagem antes de abrir; sha256(linhagem) % 5 == 0 reservado; calcular erro so apos congelar parametros.'}

def main():
    p=argparse.ArgumentParser(description='Sistema PA TEST – nunca altera Notion')
    p.add_argument('mode',choices=['lookup','compare','config','activation','hypothesis','parse','propose','analyze','damage','stats','holdout','demo'])
    p.add_argument('args',nargs='*')
    a=p.parse_args();b=a.args
    if a.mode=='lookup':v=lookup(' '.join(b))
    elif a.mode=='compare':v=compare_items(b[0],b[1])
    elif a.mode=='config':v=costs_for_equipped(b)
    elif a.mode=='activation':v=activation_check(float(b[0]),' '.join(b[1:]))
    elif a.mode=='hypothesis':v=hypothesis_attributes(float(b[0]))
    elif a.mode=='parse':v=parse_cost_lines('\n'.join(b))
    elif a.mode in ('propose','analyze'):
        x=json.loads(Path(b[0]).read_text(encoding='utf-8'))
        v=predict_new(x['item'],'PROPOSTA' if a.mode=='propose' else 'ANALITICO',x.get('rates'))
    elif a.mode=='damage':v=damage_delta(*(float(y) for y in b))
    elif a.mode=='stats':v=stats(b[0] if b else 'MAPA_T01_54')
    elif a.mode=='holdout':v=holdout_plan()
    else:v={'censo54':stats(),'attr3':hypothesis_attributes(3),'ambiguous21':lookup('AMANTE DAS SOMBRAS'),
            'dual':lookup('Bota Caminho Veloz'),'rd_damage':damage_delta(15,20,25,3,.6,1,1),
            'proposed_armor':predict_new({'name':'Armadura +6CA +15RD +10CON','effects':[{'id':'ca','kind':'ca','value':6},{'id':'rd','kind':'rd','value':15},{'id':'con','kind':'attribute','value':10}]},'PROPOSTA',{'attribute':5}),
            'multi':costs_for_equipped(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'])}
    print(json.dumps(v,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
