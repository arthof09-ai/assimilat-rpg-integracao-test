"""Independent local structural checker; NOT third-party science / NAC-PASS approval."""
from pathlib import Path
import json,hashlib
from collections import Counter
P=Path(__file__).resolve().parent
z=json.loads((P/'corpus_pa_v1.json').read_text('utf-8'))
r=z['items'];cohort=[x for x in r if x['cohort']=='MAPA_T01_54']
assert len(cohort)==54 and len(r)==61
assert len({x['item_id'] for x in r})==61
assert Counter(x['family'] for x in cohort)=={'armas':19,'armaduras':7,'roupas_acessorios':13,'artefatos':15}
assert Counter(x['pa_daily']['classification'] for x in cohort)=={'AUSENTE':38,'EXPLICITA':12,'REGRA_R_PA_DIA':2,'UNIDADE_NAO_DECLARADA':1,'CUSTO_SEM_PERIODO':1}
assert sum(x['pa_activation']['value'] is not None for x in cohort)==5
assert sum(x['pa_daily']['value'] is not None and x['pa_activation']['value'] is not None for x in cohort)==4
assert sum(x['cost_unqualified'] is not None for x in cohort)==2
for x in r:
    assert x['source_url'].endswith(x['item_id']) and len(x['item_id'])==32
    assert x['is_canonical_cost_changed'] is False
    for unit in ('pa_daily','pa_activation'):
        v=x[unit]['value']
        assert v is None or isinstance(v,int) and v>=0
    if x['pa_daily']['classification'] in ('EXPLICITA','REGRA_R_PA_DIA'):
        assert x['pa_daily']['value'] is not None
assert len({x['lineage_cluster'] for x in cohort})==53
print(json.dumps({'status':'PASS_VERIFICADOR_LOCAL_INDEPENDENTE_DA_API_DO_MOTOR','pages_bounded':54,'extra_pages':7,'ids_unique':61,'cov_exact_explicit_daily':12,'cov_interpreted_daily':2,'cov_uncertain':2,'cov_absent':38,'activation_documented':5,'dual':4,'hash_corpus':hashlib.sha256((P/'corpus_pa_v1.json').read_bytes()).hexdigest(),'science_independent_audit':False,'production_release':False},ensure_ascii=False,indent=2))
