"""20 dano: parametrizacao EXCLUSIVAMENTE ilustrativa; no PA coefficients."""
from pa_engine import damage_delta
from pathlib import Path
import json
cases=[
 ('uma_vez_no_dia',1,1,1),('por_ativacao_dois_ataques',2,1,1),
 ('em_cada_ataque_tres',3,1,1),('condicional_metade_dos_alvos_tres_ataques',3,.5,1),
 ('area_dois_alvos_tres_ataques',3,1,2)
]
rows=[]
for name,att,elig,targ in cases:
    x=damage_delta(base_damage=15,bonus=20,rd=25,attempts=att,p_hit=.6,targets=targ,eligibility=elig)
    rows.append({'scenario':name,'assumption':'Exemplo sintético Dbase15, RD25, probabilidade de acerto=.6 fixada como hipótese','result':x})
p=Path(__file__).resolve().parent/'cenarios_20_dano.json'
p.write_text(json.dumps({'purpose':'Variacao de valor de uso mecanico NAO determina taxas PA','scenarios':rows},ensure_ascii=False,indent=2),encoding='utf-8')
print(p)
