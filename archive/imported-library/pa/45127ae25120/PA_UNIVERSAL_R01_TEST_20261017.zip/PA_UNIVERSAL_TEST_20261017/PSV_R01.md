# PSV — PA-CORPUS / Calculadora de PA R01 — 17/10/2026

**AS-OF:** 17/10/2026, captura Notion Mestre e cálculo local no mesmo turno.

**IDENTIDADE:** responsável funcional designado pelo Mestre em chat. Não foi localizado ASSIGNMENT canônico individual comprovando COMESTRE-ID/INSTANCE-ID/WS desta instância; não herda CM-000002 nem writer.

**OPERATION:** frente científica PA sob dependência CRAFT `OP-ARQ-RIN-REC-01`; cadastro próprio NÃO CONFIRMADO. Não criar OP paralela.

**BASELINE:** PR-ECO-01 Anexos A–D, Kit Econômico, R-PA-DIA no Motor Econômico, Sistema de Magia, Sistema de Combate, DMG-RANK-01 v1.1, CRAFT IBX-105/106 e mapa T-01 54/54. Todas as autoridades somente leitura.

**LAST-VERIFIED-UNIT:** avaliador PA v0.2 local, fonte Notion Mestre 54/54 fichas T-01 + 7 externas, corpus JSON 61 IDs, 47 testes regressivos locais PASS, auditor local separado; arquivo recuperável/hash no manifesto. Sem mutação Notion.

**FIRST-PENDING:** ampliar para inscrições/matrizes/aprimoramentos; explicitar se PA/dia é reserva comprometida ou débito de ciclo e como liberar; obter pares independentes para H1/H2/H3/H4; validação científica holdout genuíno; autoridade documental e futura homologação.

**CORPUS:** 54 páginas físicas indexadas, 54 reabertas; 19 armas, 7 armaduras, 13 roupas/acessórios e 15 artefatos; 7 comparadores externos (61/61 distintos). Efeitos e unidades causais N/D; páginas ≠ efeitos independentes. No núcleo 12 PA/dia explícitos, 2 interpretados, 2 ambíguos, 38 sem custo diário localizado; 5 ativações identificadas; 4 duais.

**H1:** 5 PA/dia por 1 atributo em único comparador puro (+3/15). Inferência universal NÃO identificável. +10 CON pode gerar cenário de componente 50 PA/dia, nunca total involuntário.

**H2:** coexistência de diário + ativação em 4 casos, prêmio marginal passivo/ativo NÃO identificável.

**H3:** potência e custos heterogêneos; sem isolamento causal para forma por rank.

**H4:** +20 dano — taxa energética não identificável; arcos/amuletos/mantos confundidos por outros poderes. Fórmula marginal pós-RD e cenários de frequência, acerto, alcance e alvos implementados sem falsa taxa.

**OUTROS COEFICIENTES:** CA, RD, RDM, movimento, cura/controle/área sem taxas isoladas validadas. Taxa paramétrica PROPOSTA exige entrada explícita.

**MODELO:** custo diário documentado é grandeza independente de ativação. Novo item: C_dia = soma(c_i) se e somente se todos os c_i forem justificados; parcelas sem taxa tornam total PENDENTE. Custos por evento preservam sua dimensão. Para dano com RD numérica: ΔD_posRD = max(0, D_base + bonus - RD) - max(0,D_base - RD). Cenário esperado = ΔD_posRD × tentativas × p(acerto) × alvos × elegibilidade. NÃO é conversão PA.

**CALCULADORA:** lookup histórico, R-PA-DIA contextual, múltiplos itens, cheque aritmético de PA Livre, H1 condicional, avaliação paramétrica sem falsa precisão, comparadores, cenários de dano pós-RD, estatística descritiva, cláusulas de bloqueio de dupla contagem. Testes locais por 45 casos.

**HOLDOUT:** teste de repartição por hash/linhagem executável RETROSPECTIVO; não independente porque custos já vistos. Holdout genuíno futuro só após congelar coeficientes antes de revelar custos de fichas novas.

**CONFLITOS:** R-PA-DIA não cobre automaticamente PA no meio de fichas. `AMANTE DAS SOMBRAS` 21 PA no início PENDENTE temporal; `Lança Sopro Congelante` “24 por dia” sem unidade PA PENDENTE. `IMPERIAL` e `Veste Dragão Ascendente`: texto de efeitos e custo coincide, identidade/linhagem física não reconciliada. `SOMBRA SUSSURRANTE` 7 PA/dia “já somado”, proibir adicionar aos 34.

**UNKNOWN-EFFECT:** nenhuma escrita remota nesta atividade; UNKNOWN-EFFECT histórico CRAFT C19-021 permanece aberto/fora do escopo PA.

**AUTHORITY/WRITER:** Mestre autorizou pesquisa/TEST em conversa. Não foi demonstrado COMESTRE-ID operacional, writer, epoch ou lease Notion. REC-LIB, Party, CRAFT canônico, O Primeiro = NO-WRITE; F5 RED, produção HOLD.

**NAC-PASS:** gate documental/científico de fechamento CANÔNICO PENDENTE. Somente testes e integridade locais PASS; sem homologação por outro auditor, sem regra promovida.

**NO-REPEAT:** reutilizado MVP anterior de 10 casos, PR-ECO, corpus T-01, IBX-105/106, DMG-RANK 1.1 e motores CRAFT. Não criar nova família normativa nem refazer dados das páginas como se inéditos.

**NEXT-5:** (1) censo energético de inscrições/matrizes/aprimoramentos com IDs e custos; (2) auditar colisões/versões e semântica PA comprometido versus débito, com decisão mínima do Mestre se a norma não resolver; (3) pares de atributo/defesa/ativação com denominares por cluster; (4) conectar DMG para +20 dano com controle de acerto/RD/frequência; (5) congelar modelo e executar holdout prospectivo, revisão NAC-NORM e contrato de entrega para CRAFT quando permitido.

**TARGET-REMAINDER:** etapas 2,4–10 permanecem PARCIAIS/PENDENTES (além do escopo limitado desta entrega), não confundir 45/47 testes com 10/10 etapas ou cobertura universal.
