"""Builds provenance-locked first-pass corpus from physically reopened Notion Master item pages (17/10/2026).
This is an audited *bounded cohort*, not a full-world census. Content is manually transcribed from source pages;
no automated claim of extraction coverage for every property/effect.
"""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
# name | notion uuid | family | public rank | PA/day | daily classification | PA/activation | activation classification | searchable mechanics excerpt
RAW='''
3 Facas Voadoras (L)|3edc2b324ede81a89afcc91f36354baf|armas|Lendário|-|AUSENTE|-|AUSENTE|3 adagas com assimilação, invisibilidade e restrição de portador
Arco Exterminador Elemental (L)|3edc2b324ede8156849bf1aae0ce9fb5|armas|Lendário|64|EXPLICITA|-|AUSENTE|dano intrínseco 8d8+25; bônus contra elementais +8d12+10; +15 Percepção para rastrear elementais
Espada Chamas Vivas (ON)|3edc2b324ede81018124d63cd8508ea2|armas|Ouro Negro|-|AUSENTE|-|AUSENTE|dano da arma 5d10+5d8+15, afinidade de fogo
Adaga da Serpente Enfeitiçada (ON)|3edc2b324ede811787a0de913622b14d|armas|Ouro Negro|35|REGRA_R_PA_DIA|-|AUSENTE|dano base 5d4+5d8+10; veneno 3d12 por turno após salvaguarda CON CD25; 35 de PA no final da ficha
Espada do Lendário|3edc2b324ede81ab9e22e168f6d939a9|armas|Lendário|600|EXPLICITA|-|AUSENTE|14d20+14d12+14d8+14d10+390+FOR; +60 FOR; +75 ataque; condição material crítica
Espada Meteoro do Deus Trovão|3edc2b324ede8196bc6ad16aecc886d9|armas|Sem classificação|-|AUSENTE|-|AUSENTE|mecânica não explicitada na ficha disponível
katana Anoitecer Sussurrante|3edc2b324ede8112b27ce850b2be5f6c|armas|Sem classificação|-|AUSENTE|-|AUSENTE|+2 Furtividade, +6 em pouca luz; onda de corte 1/dia; +3 Reflexo
Lâmina Crepuscular|3edc2b324ede81eea6cdef8d94375fe3|armas|Sem classificação|-|AUSENTE|-|AUSENTE|-2 CA no inimigo; +2 CA para o portador
Mini Arco Luz Estelar|3edc2b324ede81de9958e371e916e89f|armas|Sem classificação|-|AUSENTE|-|AUSENTE|+4 para acertar; flechas de luz e eficácia contextual
Fúria ancestral|3edc2b324ede8145a7b1f1046e72da00|armas|Sem classificação|-|AUSENTE|-|AUSENTE|aura de chamas azuis; retorno de arma lançada
Aurora Guardiã|3edc2b324ede816dbc0be60e9b3e042c|armas|Sem classificação|-|AUSENTE|-|AUSENTE|absorção de magia; invocação 1/dia
Reflexo Astral|3edc2b324ede813e87cdfad79239a1b6|armas|Sem classificação|-|AUSENTE|-|AUSENTE|ilusões, barreira astral, navegação
Besta de Caça|3edc2b324ede815a8ce2e56147e253bd|armas|Sem classificação|-|AUSENTE|-|AUSENTE|+15 acerto a 20m; dardos espectrais
Chamas do Firmamento|3edc2b324ede813b9851e8190c77adc1|armas|Sem classificação|-|AUSENTE|-|AUSENTE|explosão de fogo estelar e telecinese
Sussurro dos Ventos|3edc2b324ede817e83edc7d77cedac3b|armas|Sem classificação|-|AUSENTE|-|AUSENTE|falar com espíritos e mover-se silenciosamente
Oráculo das Marés|3edc2b324ede81c0a4b8eb8d44610b03|armas|Sem classificação|-|AUSENTE|-|AUSENTE|vórtice de arrasto; caminhar sobre água
Lâmina Eclipse|3edc2b324ede816f98a1fa7babd3c0d3|armas|Sem classificação|-|AUSENTE|-|AUSENTE|invisibilidade ativada; corte lunar 1/noite
Lança Sopro Congelante|3edc2b324ede81ecbae3cf4b0cf274e5|armas|Sem classificação|-|UNIDADE_NAO_DECLARADA|8|CONTEXTO_ATIVO|efeito ativo 4d6+INT seguido de 8 PA; 4d8 dano; 24 por dia sem unidade PA escrita
Caçador relâmpago|3edc2b324ede81158cb9d548338e3a01|armas|Sem classificação|-|AUSENTE|-|AUSENTE|ficha incompleta
Armadura Guardiã Elemental (ON)|3edc2b324ede8127a576ee01c44bd1d4|armaduras|Ouro Negro|55|EXPLICITA|-|AUSENTE|armadura pesada CA12; RD35, +8 salvaguarda e +6 CA contra elementais
Manto de Abismo|3edc2b324ede81a5b09dc45deac36b43|armaduras|Sem classificação|-|AUSENTE|-|AUSENTE|defesa+11,15RM,10RF; teleporte 5m uma vez/turno; absorver magia 1/dia
Constelação Guardiã|3edc2b324ede8199a197efe7f31596f9|armaduras|Sem classificação|-|AUSENTE|-|AUSENTE|CA+11, +10 dano, resistência mágica; barreira 2/dia, visão noturna
Vestes de Lydandra|3edc2b324ede813f80c1dc8f23f05ec8|armaduras|Sem classificação|-|AUSENTE|-|AUSENTE|CA+5, reflexo+5, movimento+4m, percepção+5, barreira 1/dia por 10min
Acolchoada Aurora|3edc2b324ede81a9a1cfc83817895e8a|armaduras|Sem classificação|-|AUSENTE|-|AUSENTE|CA+8, deslocamento-5m, proteger primeiro golpe ao amanhecer
Véu de Eärendil|3edc2b324ede813e8efaf8de2050fd9b|armaduras|Sem classificação|-|AUSENTE|-|AUSENTE|CA+2, Furtividade+6 em pouca luz, camuflagem ativada
SOMBRA SUSSURRANTE|3edc2b324ede812c9b54c261934696e6|armaduras|Sem classificação|34|EXPLICITA|6|CONTEXTO_ATIVO|+8 CA +5 RF +3 RM; +2 dano/acerto/furtividade; invisibilidade 1 turno 6PA; trecho 7 PA/dia marcado Já somado; recuperar 3PA ao receber magia
Capa das Sombras|3edc2b324ede81a7a1fbe093824c817a|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|furtividade nas sombras
Luva Silêncio Arcano|3edc2b324ede8166ad88d00376581bd9|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|silêncio, neutralizar magia vocal, telepatia ao toque
Serenidade Celestial|3edc2b324ede81469af1f21fcca0ee9d|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|+3 Sabedoria; +2 CA
Dança Histórica|3edc2b324ede81f38f72d200ed3795f6|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|+2 Destreza e +2 Força
Vestes Guardião Cosmo|3edc2b324ede816d9f36dc6bf73d485b|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|+8 Destreza, 10 RDM
Vestes Sopro do Dragão|3edc2b324ede813ca515f35965bdfc6e|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|+4 Carisma e +5 Persuasão; vento de baixa intensidade
Vestes de Visão Astral|3edc2b324ede81bf9ca8d5d79b06e060|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|+6 Percepção
Manto Lunar|3edc2b324ede81fba3bcdcf2207ac947|roupas_acessorios|Sem classificação|-|AUSENTE|-|AUSENTE|+6 Furtividade lunar, +8 sob lua cheia
AMANTE DAS SOMBRAS|3edc2b324ede81b8b545db7b9e96b178|roupas_acessorios|Sem classificação|-|CUSTO_SEM_PERIODO| - |AUSENTE|Custo: 21 PA em bloco inicial não é valor isolado ao final; +2 Destreza, +2 Sabedoria, +3 Furtividade; evitar duplicar os bônus no resumo e nas habilidades
Bota Caminho Veloz|3edc2b324ede8135b199fd0cdbb5463c|roupas_acessorios|Sem classificação|18|EXPLICITA|5|CONTEXTO_ATIVO|+6m deslocamento, sem rastros, adaptação de terreno; ativo +8m 5 PA
Traje águia celeste|3edc2b324ede816cbad5ca3880ce144d|roupas_acessorios|Sem classificação|20|EXPLICITA|4|CONTEXTO_ATIVO|+4 Percepção, +2 CA contra ataque; ativação salto 4,5m 4PA por turno elegível
Veste Dragão Ascendente|3edc2b324ede81948c88f917a40e50fa|roupas_acessorios|Sem classificação|25|EXPLICITA|-|AUSENTE|+5 Reflexo, +4 acerto, +4m movimento, +15 RDM somente algumas magias
IMPERIAL|3edc2b324ede817897f1cdf5dea0cb70|roupas_acessorios|Sem classificação|25|EXPLICITA|-|AUSENTE|texto de efeitos e PA idêntico ao Vestes Dragão Ascendente; equivalência de fonte não conclusiva
Coroa Reino Esplendor|3edc2b324ede8144a3aed184b14275d4|artefatos|Sem classificação|112|EXPLICITA|-|AUSENTE|visão no escuro; 10 cargas com feitiços, regenera 1d6+3 cargas ao amanhecer; sintonia simbiótica
Pulseira da Rocha Magica|3edc2b324ede81948833eb6f4a5ef488|artefatos|Sem classificação|15|EXPLICITA|-|AUSENTE|imunidade petrificação e cargas finitas de Flesh to Stone e Stone Shape
Orbe do tempo|3edc2b324ede81e89dddf0b3bcb96605|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|visão de eventos passados; salvaguarda SAB para alvo involuntário
Onix de Proteção|3edc2b324ede8115a287e69daf383b38|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|consome o próprio ônix como Reação para proteção de ataque, não implica PA=0
Esmeralda de Energia|3edc2b324ede81e28548ef18833a7078|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|armazenamento de energia que dissipa ao amanhecer
Topázio de Velocidade|3edc2b324ede81f9b294edf33c354250|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|velocidade duplicada temporariamente, +5 DES
Visão além|3edc2b324ede8134adfaca5e1100b95c|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|visão noturna, percepção invisibilidade, clarividência limitada
Luva Enigma|3edc2b324ede8111a81fc7bc55d4f267|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|pequena manipulação de probabilidades
Bracalete Florestal|3edc2b324ede81689d93e290a1dc2ca4|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|crescimento de plantas e cura de toxinas abaixo de Prata
Anel dos Noves Destinos|3edc2b324ede81e0a1d3ed67e3e98a5f|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|sorte grande 1/semana
Sabedoria Ancestral|3edc2b324ede815699adc0412e96ea2b|artefatos|Sem classificação|20|REGRA_R_PA_DIA|-|AUSENTE|+10 SAB, ler textos antigos, telepatia, memória perfeita, PA isolado no final da parte mecânica
Amuleto Tempo Eterno|3edc2b324ede8132bbc8f857f4b276c4|artefatos|Sem classificação|15|EXPLICITA|15|EXPLICITA|15 PA para ativar, 15 PA por dia, uma ativação a cada 2 dias
Espelho Verdade Oculta|3edc2b324ede817188f3deff656edc1f|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|remove temporariamente 15 Carisma do alvo diante do espelho
Amuleto da Noite Estrelada|3edc2b324ede81d180adc65dfaa5c35e|artefatos|Sem classificação|-|AUSENTE|-|AUSENTE|visão submarina, proteção de ruídos, navegação
Colar cadente|3edc2b324ede810daba2cc509677856c|artefatos|Sem classificação|14|EXPLICITA|-|AUSENTE|+2 SAB, ou +4 SOB estrelas; condição modifica magnitude
'''
rows=[]
for line in RAW.strip().splitlines():
    parts=[p.strip() for p in line.split('|')]
    if len(parts)!=9: raise ValueError((len(parts),line))
    name,uuid,family,rank,daily,dstatus,active,astatus,mechanics=parts
    cost_day=int(daily) if daily!='-' else None
    cost_active=int(active) if active!='-' else None
    if dstatus in ('EXPLICITA','REGRA_R_PA_DIA') and cost_day is None: raise ValueError(name)
    rows.append(dict(item_id=uuid, name=name,family=family,rank_public=rank,source_url=f'https://app.notion.com/p/{uuid}',source_type='NOTION_MASTER',cohort='MAPA_T01_54',as_of='2026-10-17',mechanics_summary=mechanics,pa_daily=dict(value=cost_day,classification=dstatus,unit='PA/dia' if cost_day is not None else None),pa_activation=dict(value=cost_active,classification=astatus,unit='PA/ativacao' if cost_active is not None else None),source_read='FICHA_REABERTA_17_10',completeness='EXTRACAO_INICIAL_DIRECIONADA'))
assert len(rows)==54 and len({x['item_id'] for x in rows})==54
from collections import Counter
assert Counter(r['family'] for r in rows)=={'armas':19,'armaduras':7,'roupas_acessorios':13,'artefatos':15}
extra='''
Amplificador de Atributo|3c6c2b324ede82baa4a801de533a5975|acessorios_extra|-|15|EXPLICITA|-|AUSENTE|+3 pontos em um atributo, único comparador puramente identificável: 5PA por ponto de atributo
Manto do Arquimago|8afc2b324ede82e69dd101b9b9c663e3|acessorios_extra|-|60|EXPLICITA|-|AUSENTE|+30 dano mágico, +8 CD, defesa base e proteções diversas; confunde coeficiente de dano
Olho Mágico|2c7c2b324ede837d87e781ee6adaeca4|artefatos_extra|-|24|EXPLICITA|-|AUSENTE|efeitos não descritos no corpo consultado
(AI) Amuleto de Inteligência|0c4c2b324ede83dd8e1881b52a79e326|acessorios_extra|-|30|REGRA_R_PA_DIA|-|AUSENTE|+10 Inteligência e +20 dano mágico OU +20 Resistência Mágica, 30PA isolado ao final; não isola preços
Braçadeira do Pulmão de Ferro|3f5c2b324ede81eaa080cad94c16dd3b|acessorios_extra|Ouro|-|AUSENTE|15|EXPLICITA|filtro de partículas por 10 minutos e RD ambiental 20; +6 salvaguarda CON condicional, 1 uso/descanso 8h
Inscrição da Aurora que Rompe Correntes|3f5c2b324ede818296fbd64921861d83|inscricoes_extra|Lendário|-|AUSENTE|60|EXPLICITA|Reação de purificação +18 salvaguarda específica, 60PA ativação, preparada até 7 dias ou disparo
Botas do Vento Cortante|71dc2b324ede8293b062818c22959d8c|acessorios_extra|-|-|AUSENTE|-|AUSENTE|+25 DES +20 Reflexo +50m mobilidade, passivos, 5 ativos de uso limitado, PA não declarado
'''
for line in extra.strip().splitlines():
    name,uuid,family,rank,daily,dstatus,active,astatus,mechanics=[p.strip() for p in line.split('|')]
    rows.append(dict(item_id=uuid,name=name,family=family,rank_public=rank if rank!='-' else None,source_url=f'https://app.notion.com/p/{uuid}',source_type='NOTION_MASTER',cohort='EXTRA_COMPARADORES_7',as_of='2026-10-17',mechanics_summary=mechanics,pa_daily=dict(value=int(daily) if daily!='-' else None,classification=dstatus,unit='PA/dia' if daily!='-' else None),pa_activation=dict(value=int(active) if active!='-' else None,classification=astatus,unit='PA/ativacao' if active!='-' else None),source_read='FICHA_REABERTA_17_10',completeness='EXTRACAO_INICIAL_DIRECIONADA'))
assert len(rows)==61 and len({x['item_id'] for x in rows})==61
for r in rows:
    r['lineage_cluster']='POSSIVEL_IDENTIDADE_EFEITOS_VESTE_DRAGAO' if r['name'] in ('Veste Dragão Ascendente','IMPERIAL') else r['item_id']
    r['cost_unqualified']={'value':21,'text':'Custo: 21 PA em bloco inicial'} if r['name']=='AMANTE DAS SOMBRAS' else ({'value':24,'text':'24 por dia sem unidade PA'} if r['name']=='Lança Sopro Congelante' else None)
    r['pa_semantics']='NAO_VERIFICADO_COMPROMISSO_VERSUS_DEBITO'
    r['is_canonical_cost_changed']=False
metadata={'dataset_id':'PA-CENSO-T01-54-PLUS7-20261017-R01','provenance':'Notion Mestre. 54 fichas diretas do MAPA T-01 reabertas, mais 7 comparadores externos; recorte fechado, não universo exaustivo','source_index':'https://app.notion.com/p/3eec2b324ede8128be14fc6eda17f67e','as_of':'2026-10-17','status':'CORPUS_TEST_FONTE_FISICA_LIDA_EXTRACAO_RESUMIDA_MANUAL','dedup':'UUID único; IMPERIAL/Veste Dragão têm textos iguais de efeito e possível dependência, apenas sinalizada; não assumir duas unidades estatísticas independentes em holdout','cost_statuses':['EXPLICITA','REGRA_R_PA_DIA','CONTEXTO_ATIVO','UNIDADE_NAO_DECLARADA','CUSTO_SEM_PERIODO','AUSENTE'],'known_gaps':['não é censo de inscrições, matrizes e aprimoramentos','efeitos são resumos de fonte, não extração token-a-token exaustiva','sem classificação concluída de FIP individual','diário não é automaticamente PA comprometido ou debitado'], 'items':rows}
(ROOT/'corpus_pa_v1.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
print('WROTE',ROOT/'corpus_pa_v1.json',len(rows))
