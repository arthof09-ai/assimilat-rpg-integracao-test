# Calculadora Universal de PA — R01 / TEST — 17/10/2026

**MESTRE-SIDE.** Produto funcional experimental no mesmo fluxo PA↔CRAFT iniciado no MVP 17/10; **não** é norma nova, não publica dados à Party, não altera fichas, não cria REC-ID, não fabrica itens nem altera preços. O motor usa somente `corpus_pa_v1.json`, sem internet ou dependência de computador do Mestre. O Comestre pode aplicar diretamente as funções em conversa no ChatGPT.

## Resultado verificável desta entrega

- Primeiro censo **delimitado**: 54/54 páginas listadas em `MAPA T-01` reabertas em Notion Mestre, 19 armas + 7 armaduras + 13 roupas/acessórios + 15 artefatos. Mais **7 fontes específicas externas ao mapa**: Amplificador de Atributo, Manto do Arquimago, Olho Mágico, Amuleto de Inteligência, Braçadeira do Pulmão de Ferro, Inscrição da Aurora que Rompe Correntes e Botas do Vento Cortante. **61 páginas físicas distintas**, não censo global.
- Classificadas no núcleo de 54: **12 custos diários explícitos**, **2 interpretados por R-PA-DIA**, **2 ambiguidades sem valor diário fechado**, **38 sem custo diário localizado**. `12+2+2+38=54`.
- **5 custos por ativação** classificados no núcleo; **4 dessas fichas também têm PA diário**. O corpus ampliado 61 inclui mais duas ativações explícitas de itens externos.
- `IMPERIAL` e `Veste Dragão Ascendente` têm o mesmo texto de efeitos e PA/dia; foram marcados como **possível dependência de linhagem**, não declarados como duas observações independentes nem fundidos fisicamente. Assim: 54 identidades-página, 53 clusters provisórios de texto/linhagem.
- Especificamente `SOMBRA SUSSURRANTE` possui 34 PA/dia, invisibilidade por 6 PA e uma linha de **7 PA/dia (já somado)**: **não** adicionar 7 aos 34.
- As fichas com PA diário **não** resolvem se sua cobrança representa reserva comprometida ou débito diário de PA. `PA Total - PA comprometido = PA Livre` continua a identidade de ficha. Não aplicar automaticamente a regra de exaustão por **conjuração forçada** aos itens.

## Uso direto do motor

```bash
python pa_engine.py demo
python pa_engine.py stats
python pa_engine.py stats ALL_61
python pa_engine.py lookup 'Bota Caminho Veloz'
python pa_engine.py compare 'Bota Caminho Veloz' 'Traje águia celeste'
python pa_engine.py config 'Bota Caminho Veloz' 'Amuleto Tempo Eterno'
python pa_engine.py activation 4 'Bota Caminho Veloz'
python pa_engine.py hypothesis 10
python pa_engine.py damage 15 20 25 3 0.6 1 1
python pa_engine.py propose exemplo_armadura.json
python pa_engine.py analyze exemplo_armadura.json
python pa_engine.py holdout
python -m unittest -v test_pa_engine.py
python auditor_local.py
```

**Modos:**
- `HISTÓRICO`: devolve exatamente o custo explícito da ficha ou interpretação controlada R-PA-DIA. Ausência não é zero.
- `ANALÍTICO`: identifica eixos de custo, explica o que falta e faz cálculos **mecânicos** válidos como marginal pós-RD; não fabrica coeficientes.
- `PROPOSTA`: somente usa coeficientes **explícitos fornecidos pelo Mestre** ou rotulados como hipótese; não altera histórico. Se faltar qualquer coeficiente necessário, o **total permanece `null`**, e uma **parcela condicional** não é convertida em custo total.

## Contrato de integração com CRAFT (modelo mínimo)

```json
{
  "item_id": "UUID-DA-FICHA",
  "family": "armas | armaduras | roupas_acessorios | artefatos | inscricoes_extra",
  "historical": {
    "pa_daily": {"value": null, "classification": "AUSENTE"},
    "pa_activation": {"value": null, "classification": "AUSENTE"},
    "cost_unqualified": null
  },
  "analytic": {"daily_missing_rates_for": ["ca", "rd"], "confidence": "NAO_CALIBRADA"},
  "proposal": {"pa_day_estimate": null, "ratios_are_user_assumptions": true},
  "pa_daily_semantics": "PENDENTE_COMPROMISSO_VERSUS_DEBITO",
  "notion_write": false, "craft_release": false
}
```

Em CRAFT, o calculador **informa custo**, não projeta BOM, não decide RC5, não grava nem publica receitas. O CRAFT mantém a própria competência e seu STOP/F5 RED até autorização competente.

## Três regras de qualidade

1. **Custo documental prevalece:** histórico 64 PA/dia do Arco permanece 64, mesmo se alguma proposta sugerir valor diferente.
2. **R-PA-DIA contextual:** `30 PA` isolado no final da ficha de item pode ser interpretado como diário, salvo evidência textual contrária. `Custo: 21 PA` no meio de uma ficha não passa automaticamente. `24 por dia` sem a unidade PA não passa automaticamente. Gatilho de habilidade, por turno ou ativação prevalece.
3. **Não há coeficiente causal automático para dano, CA, RD, RDM ou mobilidade**. Conjeturas aceitas como cenários precisam trazer fonte, condições e autor humano.

## Relação H1: 5 PA por atributo

Fonte: Amplificador de Atributo (+3 em um atributo, 15 PA/dia) dá a **taxa aritmética observada** 15/3=5 num caso puro. Não há amostra com suficiente variação independente por atributo, rank e magnitude para concluir universalidade. Uma hipótese aplicada a +10 CON fornece **50 PA/dia apenas para esse componente condicional**; não calcula total de uma armadura que também forneça CA/RD.

## H2: passivo vs ativo

Quatro itens físicos mapeados apresentam **ambos** os custos: SOMBRA SUSSURRANTE (34/dia +6/ativação); Bota Caminho Veloz (18/dia +5/ativação); Traje águia celeste (20/dia +4/ativação); Amuleto Tempo Eterno (15/dia +15/ativação). Nenhum deles identifica isoladamente o *prêmio de manutenção do passivo* contra uma **habilidade mecanicamente igual** apenas ativa. Portanto há **coexistência histórica verificada**, não coeficiente passivo/ativo estimável.

## H3: potência

Na primeira coorte, a Es​pada do Lendário tem 600/dia com +60 FOR, +75 ataque e dano enorme, enquanto a Coroa Reino Esplendor tem 112/dia com cargas e efeitos variados. Sem pares de poder, modalidade e família controlados, não há função geral potência→PA estimável. Rank nominal isolado não serve de multiplicador.

## H4: +20 dano

- Amuleto de Inteligência: `+20 de dano mágico OU 20 Resistência Mágica` +10 INT, `30 PA` terminal interpretado R-PA-DIA; **não é um item puro +20 dano**.
- Manto do Arquimago: +30 dano mágico, +8 CD e múltiplas proteções com 60 PA/dia; também confunde os componentes.
- Arco Exterminador Elemental: bônus condicionado +8d12+10 contra elementais, 64/dia além de dano intrínseco.

**Resultado:** a taxa PA/dia por ponto de dano **não é identificável** com esses casos. Cenários com Δdano+20 podem quantificar dano esperado com base numérica, RD, ataques, condições, probabilidade de acerto e número de alvos, mas não converter dano em PA sem coeficiente sustentado.

## Fronteira científica

**Validado localmente:** Python padrão, tipos, zeros, nulos, somas, interpretação contextual, regressões contrafactuais, seleção retrospectiva de clusters, marginal de dano pós-RD e preservação histórica. **Não validado:** efeitos reais em combate, custos PA de novos itens, holdout independente de novos dados, causa dos custos históricos, lançamento produtivo ou NAC-PASS terminal.

**Arquivos:** `build_corpus.py` gera `corpus_pa_v1.json`; `pa_engine.py` é o único avaliador; `test_pa_engine.py` executa regressões; `auditor_local.py` confere invariantes independentes da API do motor; `exemplo_armadura.json` e `exemplo_espada_dano.json` são entradas demonstrativas; `demonstracoes.json` registra saídas; `PSV_R01.md` traz estado e pendências; `MANIFEST_SHA256.json` confere integridade do pacote.
