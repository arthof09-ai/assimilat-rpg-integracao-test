"""MESTRE-SIDE / TEST — comparação diagnóstica de classificadores, SEM acurácia cega.

Usa exclusivamente as 12 mecânicas textuais e etiquetas de *padrões completos* do R42.
Não estima RE de efeitos individuais nem substitui R26/R27. Não toca Notion.
Estruturas/pesos predefinidos, sem ajuste de hiperparâmetros contra o holdout.
"""
import argparse, zipfile, json, hashlib, collections, statistics
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, accuracy_score, confusion_matrix
from sklearn.metrics.pairwise import cosine_similarity

EXPECTED_R42_SHA='6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800'
NAMES=['Bronze','Prata','Ouro','Ouro Negro','Lendário']

def corpus_from_original(zip_path):
    b=Path(zip_path).read_bytes()
    sha=hashlib.sha256(b).hexdigest()
    if sha!=EXPECTED_R42_SHA: raise ValueError('R42 unexpected SHA; refuse uncontrolled dataset')
    with zipfile.ZipFile(zip_path) as z:
        if z.testzip() is not None: raise ValueError('R42 CRC')
        source=z.read('benchmark_data_r42.py').decode()
        import ast
        mod=ast.parse(source)
        values=[node.value for node in mod.body if isinstance(node,ast.Assign) for t in node.targets if isinstance(t,ast.Name) and t.id=='CASES']
        if len(values)!=1:raise ValueError('R42 CASES')
        data=ast.literal_eval(values[0])
        if len(data)!=12 or len(set(x[0] for x in data))!=12:raise ValueError('denominator or duplicate')
        return sha,data

def predict_fixed(train_text,train_y,test_text,model):
    if model=='majority':
        counts=collections.Counter(train_y)
        return sorted(counts,key=lambda lab:(-counts[lab],NAMES.index(lab)))[0]
    if model=='word-nearest':
        vec=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=False,norm='l2')
        arr=vec.fit_transform(train_text+[test_text])
        sim=cosine_similarity(arr[-1],arr[:-1])[0]
        return train_y[max(range(len(sim)),key=lambda j:sim[j])]
    if model=='char-svm':
        vec=TfidfVectorizer(analyzer='char',ngram_range=(3,5),min_df=1,sublinear_tf=True)
        xx=vec.fit_transform(train_text)
        yy=vec.transform([test_text])
        clf=LinearSVC(C=1.0,class_weight='balanced',random_state=0)
        return str(clf.fit(xx,train_y).predict(yy)[0])
    if model=='word-logreg':
        vec=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True)
        xx=vec.fit_transform(train_text)
        yy=vec.transform([test_text])
        clf=LogisticRegression(C=1.0,max_iter=1000,class_weight='balanced',random_state=0)
        return str(clf.fit(xx,train_y).predict(yy)[0])
    raise ValueError(model)

def score(data):
    labs=[x[1] for x in data];obs=sorted(set(labs),key=NAMES.index)
    all_results={}
    for model in ['majority','word-nearest','char-svm','word-logreg']:
        rows=[]
        for idx,(uid,gold,text) in enumerate(data):
            training=[v for j,v in enumerate(data) if j!=idx]
            assert all(uid!=v[0] for v in training)
            pred=predict_fixed([x[2] for x in training],[x[1] for x in training],text,model)
            rows.append({'source_id_sha256':hashlib.sha256(uid.encode()).hexdigest()[:16],
                         'gold_pattern_rank':gold,'predicted_pattern_rank':pred,'correct':pred==gold,
                         'train_size':len(training),'note':'only rank of full inscription'})
        preds=[x['predicted_pattern_rank'] for x in rows]
        accuracy=accuracy_score(labs,preds)
        all_results[model]={'n':12,'correct':sum(x['correct'] for x in rows),
                            'accuracy':round(accuracy,6),
                            'balanced_accuracy_observed_classes':round(balanced_accuracy_score(labs,preds),6),
                            'confusion_classes':obs,
                            'confusion_counts':confusion_matrix(labs,preds,labels=obs).tolist(),
                            'predictions':rows}
    return {'design':'exploratory-predefined-four-model LOO, NOT independently blind, no tuning on test gold',
            'scope':'12 R42 textual full inscriptions, NOT 26 image-based techniques, NOT component RE',
            'n':12,'labels':dict(collections.Counter(labs)),'unique_singleton_class':[l for l,c in collections.Counter(labs).items() if c==1],
            'models':all_results,'recommendation':'Do not promote any method on this tiny/singleton-class corpus; image mechanics still missing.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('r42_zip');p.add_argument('--out',default='PA_R42_BASELINES_RESULTADOS_TEST.json');a=p.parse_args()
    h,d=corpus_from_original(a.r42_zip)
    res=score(d);res['source_zip_sha256']=h
    Path(a.out).write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:{'correct':v['correct'],'n':v['n'],'balanced':v['balanced_accuracy_observed_classes']} for k,v in res['models'].items()},ensure_ascii=False))
if __name__=='__main__':main()
