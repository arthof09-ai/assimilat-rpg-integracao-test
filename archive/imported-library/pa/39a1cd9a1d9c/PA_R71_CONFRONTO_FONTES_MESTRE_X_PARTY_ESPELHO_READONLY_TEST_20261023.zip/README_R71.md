# PA-R71 — Diferenciação de superfícies: Catálogo Mestre × Party (Mestre — Espelho)

**MESTRE-ONLY / TEST documental / somente leitura.** Busca focal: quatro efeitos individuais E0 pendentes do R57. A investigação produziu um achado de proveniência que impede uma ação errada: páginas de mesmo nome em **duas árvores Notion diferentes** não são necessariamente duplicatas canônicas. Os comparadores de R62 continuam apenas parciais, sem solução oficial do E0.

## Diferenças observadas em páginas vivas (23/10/2026)

| Efeito | Catálogo Mestre (Itens/Técnicas & Pergaminhos) | Party (Mestre — Espelho)/INVENTÁRIO/Catálogo/Magias | Interpretação |
|---|---:|---:|---|
| Repreensão Infernal | 2.785.000 MED | 6.785.000 MED | Preços distintos em superfícies diferentes; **não sobrescrever** |
| Vínculo Com a Besta | 1.560.000 MED | 4.560.000 MED | Preços distintos em superfícies diferentes; **não sobrescrever** |
| Toque Chocante | 4.100.000 MED | 4.100.000 MED | Valor coincide; páginas ainda são objetos distintos |
| Orbe Cromática | 8.760.000 MED | Não encontrado neste recorte focal | Ausência de segundo resultado **não demonstra ausência global** |

### URLs de evidência — Catálogo Mestre
- [Repreensão Infernal](https://app.notion.com/p/3edc2b324ede816fb2bed9b071790a96)
- [Vínculo Com a Besta](https://app.notion.com/p/3edc2b324ede81c5b989eb157f7ce817)
- [Toque Chocante](https://app.notion.com/p/3edc2b324ede81f79aaaeb6c8c10729e)
- [Orbe Cromática](https://app.notion.com/p/3edc2b324ede81f0975ae7f082c71a1c)

### URLs de evidência — Party (Mestre — Espelho) — NÃO PUBLICAR / NÃO ESCREVER
- [Repreensão Infernal](https://app.notion.com/p/987c2b324ede831fa34081d1f5ec10b5)
- [Vínculo Com a Besta](https://app.notion.com/p/bb0c2b324ede839488fc016e6b6917c0)
- [Toque Chocante](https://app.notion.com/p/909c2b324ede8351ae0901bbca9a2769)

## Limites de evidência

- Preço de ficha, classificação nominal de **técnica**, classificação de **item**, rank do **efeito individual RE** e custo de **PA** são conceitos distintos. A menção a `Ouro (O)` ou `Ouro Negro (ON)` nos títulos ou callouts não adjudica E0.
- Proveniência da Party foi fisicamente verificada na cadeia de ancestrais (Party do Mestre — Espelho → INVENTÁRIO → Catálogo → Magias). Não foi inspecionado o binding/sync da Party Oficial das Players nesta rodada; portanto, **não afirmar que o espelho está desatualizado**, não alterar preços, nem sincronizar.
- Nenhuma página foi criada, arquivada, movida ou editada; nenhuma alteração canônica ou de produção foi feita. A diferença pode resultar de estado comercial/cópia/histórico; causa **PENDENTE**.
- Os valores foram extraídos do texto do Notion; não houve reabertura da imagem embutida para auditar seus pixels. Identidade da fonte visual e consistência preço-texto/imagem, quando relevante, continuam PENDENTES.

**LAST-VERIFIED:** sete páginas Mestre readback, cadeia de ancestrais verificada para seis, 3 comparações efetivas, 1 registro sem contraparte neste recorte. **FIRST-PENDING:** determinar se preços distintos são intencionais com base em autoridade/fonte respectiva; não substituir fontes. **NEXT:** homologação E0 separada via pareceres independentes autorizados, com R69/R70 como ferramentas TEST; não usar preço como proxy. **NO-REPEAT:** não voltar a tratar página de Party espelho como duplicata indevida de Itens Mestre.
