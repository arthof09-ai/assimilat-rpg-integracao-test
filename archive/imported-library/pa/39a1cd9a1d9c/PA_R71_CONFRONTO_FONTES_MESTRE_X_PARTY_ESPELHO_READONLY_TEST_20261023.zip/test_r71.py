import json, unittest
from pathlib import Path
p=Path(__file__).parent
D=json.loads((p/'R71_SURFACE_COMPARE.json').read_text())
class Test(unittest.TestCase):
 def test_01_four_effects(self):self.assertEqual(len(D['cases']),4)
 def test_02_distinct_page_ids(self):
  pages=[v['id'] for c in D['cases'] for v in (c['catalog_master'],c['party_master_mirror']) if v]
  self.assertEqual(len(pages),len(set(pages)))
 def test_03_count_readbacks(self):self.assertEqual(sum(1 for c in D['cases'] if c['party_master_mirror']),3)
 def test_04_price_difference_reprim(self):self.assertEqual(D['cases'][0]['party_master_mirror']['price_med']-D['cases'][0]['catalog_master']['price_med'],4000000)
 def test_05_price_difference_vinculo(self):self.assertEqual(D['cases'][1]['party_master_mirror']['price_med']-D['cases'][1]['catalog_master']['price_med'],3000000)
 def test_06_price_same_toque(self):self.assertEqual(D['cases'][2]['party_master_mirror']['price_med'],D['cases'][2]['catalog_master']['price_med'])
 def test_07_no_party_write(self):self.assertFalse(D['interpretation']['party_mirror_write_authorized'])
 def test_08_no_e0_adjudication(self):self.assertEqual(D['interpretation']['mechanical_effect_E0_adjudicated'],0)
 def test_09_no_official_pa(self):self.assertFalse(D['interpretation']['official_pa_assigned'])
 def test_10_no_price_rank_proxy(self):self.assertFalse(D['interpretation']['price_usable_as_effect_rank'])
 def test_11_no_duplicate_delete(self):self.assertFalse(D['interpretation']['same_title_implies_same_canonical_object'])
 def test_12_party_parents(self):self.assertTrue(all('Party (Mestre — Espelho)' in c['party_master_mirror']['parent'] for c in D['cases'] if c['party_master_mirror']))
if __name__=='__main__':unittest.main(verbosity=2)
