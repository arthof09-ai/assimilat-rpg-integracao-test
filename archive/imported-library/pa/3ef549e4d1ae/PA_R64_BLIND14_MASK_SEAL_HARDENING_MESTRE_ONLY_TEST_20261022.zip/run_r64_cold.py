import subprocess,sys,json
from pathlib import Path
r=Path(__file__).resolve().parent
p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r64.py','-q'],cwd=r,text=True,capture_output=True,timeout=100)
if p.returncode or 'Ran 38 tests' not in p.stderr:raise RuntimeError(p.stderr[-4000:])
print(json.dumps({'status':'PASS_R64_BLIND_SEAL_ENFORCED','new_tests':38,'image_substitution_exploit_R60':True,'text_spoiler_exploit_R60':True,'R60_blind_case_count':14,'E0_adjudicated':0,'independent_review_received':0,'production':'HOLD','notion_write':0,'party_write':0},sort_keys=True))
