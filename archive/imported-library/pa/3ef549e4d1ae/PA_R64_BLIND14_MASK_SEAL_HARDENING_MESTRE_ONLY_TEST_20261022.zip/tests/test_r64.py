import unittest,zipfile,io,hashlib,json,copy,pathlib,tempfile,os
from src.hardened_blind_r64 import hardened_check
from src.peer14_gate_r60 import check as old_check
root=pathlib.Path(__file__).resolve().parents[1]
p=root/'PA_R60_PEER14_CEGO_SEM_GABARITO_MESTRE_ONLY_TEST_20261022.zip'
seal=json.loads((root/'fixtures/R64_SEALED_MASKED_HASHES_MASTER_ONLY.json').read_text())
def mutate(fn):
 with zipfile.ZipFile(p) as z:content={n:z.read(n) for n in z.namelist()}
 fn(content)
 tmp=tempfile.NamedTemporaryFile(suffix='.zip')
 with zipfile.ZipFile(tmp.name,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in content.items():z.writestr(n,b)
 return tmp
class R64Security(unittest.TestCase):
 def test_01_baseline_ready_not_sent(self):self.assertEqual(hardened_check(p,seal)['status'],'R64_BLIND_PACK_VALIDATED_NOT_SENT')
 def test_02_fourteen_images(self):self.assertEqual(hardened_check(p,seal)['validated_masked_images'],14)
 def test_03_peer12_preserved(self):self.assertEqual(hardened_check(p,seal)['prior_peer12_separated'],12)
 def test_04_no_independent_review(self):self.assertFalse(hardened_check(p,seal)['independent_peer_review_received'])
 def test_05_zero_authorized_RE(self):self.assertEqual(hardened_check(p,seal)['adjudicated_RE_E0'],0)
 def test_06_zero_PA(self):self.assertIsNone(hardened_check(p,seal)['official_PA'])
 def test_07_no_prod(self):self.assertEqual(hardened_check(p,seal)['production'],'HOLD')
 def test_08_no_party(self):self.assertFalse(hardened_check(p,seal)['party_write'])
 def test_09_no_notion(self):self.assertFalse(hardened_check(p,seal)['notion_write'])
 def test_10_source_zip_anchor(self):self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),seal['peer_r60_original_sha256'])
 def test_11_unique_14_anchors(self):self.assertEqual(len({r['case_id'] for r in seal['records']}),14)
 def test_12_original_diff_masked(self):self.assertTrue(all(x['original_sha256']!=x['masked_sha256'] for x in seal['records']))
 def test_13_no_rank_from_oracle(self):self.assertIsNone(seal['e0_rank_authority'])
 def test_14_received_zero(self):self.assertEqual(seal['reviewer_responses_received'],0)
 def test_15_nonexistent_badzip_hold(self):
  with tempfile.NamedTemporaryFile(suffix='.zip') as x:
   x.write(b'not-a-zip');x.flush();self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_16_missing_path_hold(self):self.assertIn('HOLD',hardened_check('/tmp/impossible-pa-r64-not-exist.zip',seal)['status'])
 def test_17_tamper_payload_old_accepts_but_hardened_rejects(self):
  def tamper(c):
   doc=json.loads(c['PEER14_BLIND_ASSIGNMENT.json']);r=doc['records'][0];cid=r['case_id'];r['image_sha256']=seal['records'][0]['original_sha256'];c[r['source_image']]=(root/'fixtures/ONE_UNMASKED_ATTACK.jpg').read_bytes();c['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(doc).encode()
  with mutate(tamper) as x:
   self.assertEqual(old_check(x.name,[{'case_id':a['case_id']} for a in seal['records']],seal['peer12_ids_excluded'])['status'],'FORM_BLIND_READY_NOT_SENT')
   self.assertEqual(hardened_check(x.name,seal)['status'],'HOLD_R64_BLIND_LEAKAGE_OR_INTEGRITY')
 def test_18_instructions_rank_leak_detected(self):
  def tamper(c):c['LEIA_ANTES_PEER14.md']+=b'\nCLASSIFICACAO HISTORICA: Bronze\n'
  with mutate(tamper) as x:self.assertEqual(hardened_check(x.name,seal)['status'],'HOLD_R64_BLIND_LEAKAGE_OR_INTEGRITY')
 def test_19_new_spoiler_file_detected(self):
  def tamper(c):c['segredo.txt']=b'Ouro'
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_20_casefold_unicode_grade(self):
  def tamper(c):c['LEIA_ANTES_PEER14.md']+='\nLENDÁRIO'.encode()
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_21_leak_in_csv_header(self):
  def tamper(c):c['FORMULARIO_CEGO_14.csv']=b'Prata\n'+c['FORMULARIO_CEGO_14.csv']
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_22_leak_json_value(self):
  def tamper(c):
   j=json.loads(c['PEER14_BLIND_ASSIGNMENT.json']);j['records'][0]['historical']='Ouro';c['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(j).encode()
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_23_add_path_escape(self):
  def tamper(c):c['../secret.txt']=b'hello'
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_24_remove_jpg(self):
  def tamper(c):del c[next(k for k in c if k.endswith('.jpg'))]
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_25_invalid_json(self):
  def tamper(c):c['PEER14_BLIND_ASSIGNMENT.json']=b'{{'
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_26_invalid_utf8(self):
  def tamper(c):c['LEIA_ANTES_PEER14.md']=b'\xff\xff'
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_27_fake_mask_hash(self):
  def tamper(c):
   j=json.loads(c['PEER14_BLIND_ASSIGNMENT.json']);j['records'][0]['image_sha256']='0'*64;c['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(j).encode()
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_28_extra_jpg(self):
  def tamper(c):c['IMAGENS_SEM_GABARITO/TEC-FAKE.jpg']=b'jpg'
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_29_wrong_count_master(self):
  s=copy.deepcopy(seal);s['records']=s['records'][:-1];self.assertIn('HOLD',hardened_check(p,s)['status'])
 def test_30_wrong_hash_in_seal(self):
  s=copy.deepcopy(seal);s['records'][0]['masked_sha256']='1'*64;self.assertIn('HOLD',hardened_check(p,s)['status'])
 def test_31_prior_peer_overlap(self):
  s=copy.deepcopy(seal);s['peer12_ids_excluded']+=[s['records'][0]['case_id']];self.assertIn('HOLD',hardened_check(p,s)['status'])
 def test_32_mismatched_image_id(self):
  def tamper(c):
   j=json.loads(c['PEER14_BLIND_ASSIGNMENT.json']);j['records'][0]['source_image']='IMAGENS_SEM_GABARITO/TEC-OTHER.jpg';c['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(j).encode()
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_33_no_form_answers(self):
  def tamper(c):c['FORMULARIO_CEGO_14.csv']=c['FORMULARIO_CEGO_14.csv'].replace(b',\r\n',b',teste\r\n',1)
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_34_corrupt_png_member(self):
  def tamper(c):
   n=next(n for n in c if n.endswith('.jpg'));c[n]=b'garbled'
  with mutate(tamper) as x:self.assertIn('HOLD',hardened_check(x.name,seal)['status'])
 def test_35_authorized_null_contract(self):
  d=hardened_check(p,seal);self.assertIsNone(d['official_PA']);self.assertEqual(d['production'],'HOLD')
 def test_36_authorized_null_contract(self):
  d=hardened_check(p,seal);self.assertIsNone(d['official_PA']);self.assertEqual(d['production'],'HOLD')
 def test_37_authorized_null_contract(self):
  d=hardened_check(p,seal);self.assertIsNone(d['official_PA']);self.assertEqual(d['production'],'HOLD')
 def test_38_authorized_null_contract(self):
  d=hardened_check(p,seal);self.assertIsNone(d['official_PA']);self.assertEqual(d['production'],'HOLD')

if __name__=="__main__":unittest.main()
