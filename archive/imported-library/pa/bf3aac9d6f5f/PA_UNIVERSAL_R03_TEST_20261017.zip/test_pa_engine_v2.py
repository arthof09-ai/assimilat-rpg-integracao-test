import copy,unittest
import pa_engine_v2 as M

class Integrity(unittest.TestCase):
 def test_censo_95(self):self.assertEqual(M.census()['total_pages'],95)
 def test_unique_ids(self):self.assertEqual(M.census()['different_uuids'],95)
 def test_lineage_cluster(self):self.assertEqual(M.census()['lineage_clusters_provisional'],94)
 def test_family_ins_battle(self):self.assertEqual(M.census()['per_family']['inscricoes_batalha']['pages'],17)
 def test_family_ins_ench(self):self.assertEqual(M.census()['per_family']['inscricoes_encantamento']['pages'],9)
 def test_family_matrices(self):self.assertEqual(M.census()['per_family']['matrizes']['pages'],8)
 def test_daily_18(self):self.assertEqual(M.census()['daily_with_numeric_value'],18)
 def test_activation_7(self):self.assertEqual(M.census()['activation_with_numeric_value'],7)
 def test_unknown_never_zero(self):self.assertEqual(M.historical('Matriz de Cultivo')['pa_daily']['value'],None)
 def test_R_PA_DIA_amuleto(self):self.assertEqual(M.historical('Amuleto Tempo Eterno')['pa_daily']['value'],15) if False else self.assertEqual(M.historical('Amuleto Tempo Eterno')['pa_daily']['value'],15)
 def test_R_PA_DIA_sabedoria(self):self.assertEqual(M.historical('Sabedoria Ancestral')['pa_daily']['classification'],'REGRA_R_PA_DIA')
 def test_bad_lookup(self):
  with self.assertRaises(ValueError):M.historical('Item que não existe')
 def test_no_rebalance(self):self.assertEqual(M.historical('Arco Exterminador Elemental (L)')['pa_daily']['value'],64)

class Hypotheses(unittest.TestCase):
 def test_H1_pure(self):self.assertEqual(M.attribute_h1_audit()['pure_ratio'],5)
 def test_H1_conditional_counterexamples(self):self.assertFalse(M.attribute_h1_audit()['nonnegative_additive_model_compatible_with_uniform_5'])
 def test_H1_discount30(self):
  z=M.attribute_h1_audit()['conditional_stress_violations'];self.assertTrue(any(x['minimum_rebate_if_all_attribute_points_cost_5']==30 for x in z))
 def test_H1_unqualified_excluded(self):self.assertTrue(any('AMANTE DAS SOMBRAS' in a for a in M.attribute_h1_audit()['excluded_due_unqualified_period']))
 def test_H1_no_assertion_universal(self):self.assertIn('HIPOTESE',M.attribute_h1_audit()['scientific_status'])

class Damage20(unittest.TestCase):
 def test_five_scenarios(self):self.assertEqual(len(M.incremental_damage_20()['outcomes']),5)
 def test_scenario_one(self):self.assertEqual(M.incremental_damage_20()['outcomes'][0]['expected_extra_damage_after_RD'],6)
 def test_scenario_area(self):self.assertEqual(M.incremental_damage_20()['outcomes'][4]['expected_extra_damage_after_RD'],36)
 def test_no_fabricated_pa(self):self.assertTrue(all(x['pa_daily'] is None for x in M.incremental_damage_20()['outcomes']))
 def test_effect_RD_threshold(self):self.assertEqual(M.incremental_damage_20(base=15,rd=100)['outcomes'][2]['expected_extra_damage_after_RD'],0)
 def test_high_hit_invalid(self):
  with self.assertRaises(ValueError):M.incremental_damage_20(hit=1.1)
 def test_negative_damage_invalid(self):
  with self.assertRaises(ValueError):M.incremental_damage_20(base=-1)

class Budget(unittest.TestCase):
 def test_multi_119(self):self.assertEqual(M.budget(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'],300,80)['known_daily_subtotal_pa_day'],119)
 def test_no_free_claim_unknown(self):self.assertNotIn('scenario_free_after_commitment',M.budget(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'],300,80))
 def test_scenario_commit_101(self):self.assertEqual(M.budget(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'],300,80,'COMMIT')['scenario_free_after_commitment'],101)
 def test_scenario_debit(self):self.assertEqual(M.budget(['Arco Exterminador Elemental (L)','Armadura Guardiã Elemental (ON)'],300,80,'DEBIT')['scenario_pa_current_if_debited_from_full_total'],181)
 def test_missing_conserves_null(self):self.assertIsNone(M.budget(['Matriz de Cultivo','Arco Exterminador Elemental (L)'],300)['daily_total_pa_day'])
 def test_two_boot_activations(self):self.assertEqual(M.budget(['Bota Caminho Veloz'],300,0,uses={'Bota Caminho Veloz':2})['known_activation_subtotal_pa_per_set_of_uses'],10)
 def test_activation_unknown_null(self):self.assertTrue(M.budget(['Matriz de Cultivo'],300,0,uses={'Matriz de Cultivo':1})['missing_activation'])
 def test_invalid_PA(self):
  with self.assertRaises(ValueError):M.budget(['Bota Caminho Veloz'],80,100)
 def test_duplicate_equip(self):
  with self.assertRaises(ValueError):M.budget(['Bota Caminho Veloz','Bota Caminho Veloz'],300)

class ContrafactualTests(unittest.TestCase):
 def base(self,modality='passive',value=20,rank='Prata'):
  return {'name':'+20','rank':rank,'effects':[{'id':'buff','kind':'damage','value':value,'modality':modality}]}
 def test_T1_same_power_active_vs_passive(self):
  a=M.quote_new(self.base(),{'damage':3,'activation:damage':.5});b=M.quote_new(self.base('active'),{'damage':3,'activation:damage':.5});self.assertEqual(a['pa_day_estimate'],60);self.assertEqual(b['pa_activation_estimate'],10);self.assertIsNone(b['pa_day_estimate'])
 def test_T2_magnitudes(self):
  v=[M.quote_new(self.base(value=x),{'damage':2})['pa_day_estimate'] for x in (5,10,20)];self.assertEqual(v,[10,20,40])
 def test_T3_repeated_activation(self):
  self.assertEqual(M.budget(['Bota Caminho Veloz'],300,0,uses={'Bota Caminho Veloz':3})['known_activation_subtotal_pa_per_set_of_uses'],15)
 def test_T4_nominal_rank(self):
  a=M.quote_new(self.base(rank='Bronze'),{'damage':2});b=M.quote_new(self.base(rank='Lendário'),{'damage':2});self.assertEqual(a['pa_day_estimate'],b['pa_day_estimate'])
 def test_T5_change_user_only(self):
  x=self.base();x['user_level']=1;y=copy.deepcopy(x);y['user_level']=25
  self.assertEqual(M.quote_new(x,{'damage':2})['pa_day_estimate'],M.quote_new(y,{'damage':2})['pa_day_estimate'])
 def test_T6_no_duplicate(self):
  x=self.base();x['effects'].append({'id':'same','same_mechanical_effect_as':'buff','kind':'damage','value':20,'modality':'passive'})
  v=M.quote_new(x,{'damage':2});self.assertEqual(v['pa_day_estimate'],40);self.assertEqual(len(v['duplicate_effect_groups_ignored']),1)
 def test_T7_pa_dia_vs_committed(self):
  x=M.budget(['Bota Caminho Veloz'],100,10)
  self.assertEqual(x['pa_free_pre_item_accounting'],90);self.assertNotIn('scenario_free_after_commitment',x)
 def test_T8_remove_component(self):
  x={'effects':[{'id':'a','kind':'damage','value':10,'modality':'passive'},{'id':'b','kind':'attribute','value':2,'modality':'passive'}]}
  a=M.quote_new(x,{'damage':2,'attribute':5});y=copy.deepcopy(x);y['effects'].pop();b=M.quote_new(y,{'damage':2,'attribute':5})
  self.assertEqual(a['pa_day_estimate']-b['pa_day_estimate'],10)
 def test_T9_missing_rates_null(self):self.assertIsNone(M.quote_new(self.base())['pa_day_estimate'])
 def test_T10_historical_scenario_no_rewrite(self):
  before=M.historical('Arco Exterminador Elemental (L)')['pa_daily']['value']
  M.quote_new(self.base(),{'damage':99})
  self.assertEqual(M.historical('Arco Exterminador Elemental (L)')['pa_daily']['value'],before)
 def test_synergy_without_decision(self):
  x=self.base();x['effects'][0]['synergy_candidate']=True
  self.assertIsNone(M.quote_new(x,{'damage':2})['pa_day_estimate'])
 def test_no_rates_no_precision(self):
  x={'effects':[{'id':'a','kind':'attribute','value':10,'modality':'passive'},{'id':'b','kind':'ca','value':6,'modality':'passive'}]}
  self.assertIsNone(M.quote_new(x,{'attribute':5})['pa_day_estimate'])
 def test_contract(self):
  x=M.contract_craft('Bota Caminho Veloz');self.assertTrue(x['production_hold']);self.assertEqual(x['historical']['daily']['value'],18)
 def test_retrospective_not_independent(self):self.assertFalse(M.diagnose_holdout()['retrospective_reserve_independence'])

if __name__=='__main__':unittest.main()
