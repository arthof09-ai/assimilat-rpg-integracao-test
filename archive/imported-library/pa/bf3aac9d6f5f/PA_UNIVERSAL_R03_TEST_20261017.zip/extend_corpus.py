import json,copy,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
base=json.loads((P/'corpus_pa_v1.json').read_text('utf8'))
# 34 distinct Notion pages, checked by fetching content on 17/10/2026.
# Each line: id, name, family, public rank, concise observed effect, explicit PA detection.
src='''
3edc2b324ede8147b943dc9d9492e513|Inscrição Contato Vital|inscricoes_batalha|Prata|Vínculo contratual com punição por desobediência
3edc2b324ede81b68ccdfa6d22d2c67c|Inscrição Faca Voadora Solar|inscricoes_batalha|Ouro|Invocação de facas solares contra alvos
3edc2b324ede8110ab28c351e33f9db7|Inscrição Vento Ártico Nevasca|inscricoes_batalha|Prata|Nevasca localizada que reduz visibilidade
3edc2b324ede81eb93a4f5e5754a877f|Inscrição Verdadeira Nevasca|inscricoes_batalha|Prata|Nevasca em área ampla com controle de mobilidade
3edc2b324ede8199a440e7db47a235a9|Inscrição Escudo Dourado Santo|inscricoes_batalha|Ouro Negro|Escudo com raio de quatro metros
3edc2b324ede81db863bc3dc08ac197d|Inscrição Tempestade Sol Radiante|inscricoes_batalha|Ouro Negro|Tempestade solar com dano e suporte
3edc2b324ede812c84a9d29fc71be93b|Inscrição Guardiã Divina|inscricoes_batalha|Ouro|Barreira protetora pessoal espiritual
3edc2b324ede814daf4dfc2ecb2bb43f|Inscrição Invasão Explosiva|inscricoes_batalha|Ouro|Explosão de choque e chamas
3edc2b324ede81289089e771fb5e5a32|Inscrição Explosão Repentina|inscricoes_batalha|Prata|Armadilha de explosão de fogo regenerável duas vezes
3edc2b324ede81d4b33af525dccd0c6e|Inscrição Selo da Alma|inscricoes_batalha|Ouro Negro|Selo de vínculo espiritual com besta
3edc2b324ede8129a93ec70cd3167931|Inscrição Algemas da Alma|inscricoes_batalha|Ouro|Algemas invisíveis de vínculo espiritual
3edc2b324ede816abc05c3931e0e2d51|Inscrição Garrafa Explosão de Sangue|inscricoes_batalha|Prata|Explosão disparada por selo ou quebra de garrafa
3edc2b324ede81338cacde914dbfa13d|Inscrição Despertar Linhagem|inscricoes_batalha|Ouro Negro|Despertar linhagem ancestral latente
3edc2b324ede81c19e7fd4a80256f776|Inscrição Bomba Dracônica|inscricoes_batalha|Ouro Negro|Explosão cataclísmica em pedra da alma
3edc2b324ede81999055d1ae5dd164e4|Inscrição Grilhões do Tempo|inscricoes_batalha|Lendário|Restrição temporal e movimento
3edc2b324ede818dbbb5de269a8c138f|Inscrição Eclipse Astral|inscricoes_batalha|Lendário|Eclipse com bônus aliados e ocultação inimigos
3edc2b324ede81a28d05d128b5a4efdd|Inscrição Fúria do Leviatã|inscricoes_batalha|Prata|Onda de água ofensiva
3edc2b324ede814591bbe9b1a9eac5f0|Inscrição Vento Ártico Encantamento|inscricoes_encantamento|Bronze|Resistência ao frio e agilidade com aura de desaceleração
3edc2b324ede81fd8234c99548adf6de|Inscrição Flamejante Sagrado|inscricoes_encantamento|Bronze|Dano de fogo adicional e proteção de frio
3edc2b324ede81b590c1ee796ca9cfae|Inscrição Raio Poente|inscricoes_encantamento|Bronze|Paralisia temporária e energia elétrica
3edc2b324ede816c98e1c541bd9011a8|Inscrição Chama Relâmpago|inscricoes_encantamento|Prata|Dano por fogo e choque elétrico
3edc2b324ede81b9a769d4ede0c4605e|Inscrição Terra Fértil|inscricoes_encantamento|Prata|Fertilidade e crescimento de plantas
3edc2b324ede81328244cb03c1baf85d|Inscrição Sombras Enganosas|inscricoes_encantamento|Ouro|Quase invisibilidade do objeto e portador
3edc2b324ede81769f26d68a8a42aab6|Inscrição de Selamento|inscricoes_encantamento|Prata|Selo de receptáculo espiritual
3edc2b324ede81adab3dd3a7f9fe921d|Inscrição de Vedação|inscricoes_encantamento|Prata|Vedação e estabilização mágica
3edc2b324ede816bac13cb656a31677a|Inscrição Reflexo das Profundezas|inscricoes_encantamento|Prata|Reflexão e respiração subaquática
3edc2b324ede813686edff9348a893ad|Matriz de Invocação|matrizes|Sem classificação|Família de matrizes de invocação; sem efeito quantitativo claro
3edc2b324ede81d68e1bec250fc5291f|Matriz de Combate|matrizes|Sem classificação|Família de matrizes de combate; ficha sumária
3edc2b324ede81fe98faf689b2750291|Matriz de Cultivo|matrizes|Sem classificação|Crescimento acelerado de plantas e ervas
3edc2b324ede8105bed0cf904c88da3b|Matriz Ilusória|matrizes|Sem classificação|Ilusões e ocultação de ambientes
3edc2b324ede817cbb5fe01c7ee99a88|Matriz Espacial|matrizes|Sem classificação|Portais e transporte espacial e temporal
3edc2b324ede81478ae5e1b3addb93b3|Matriz de Proteção|matrizes|Sem classificação|Proteção de local e aprisionamento temporário
3edc2b324ede8166b3aed4b90f7a0a86|Matriz Espacial dos 10 Milênios|matrizes|Lendário|Proteção contra bestas com fraqueza de abertura por humanos
3edc2b324ede81119927f733aafc8af5|Matriz Dança das Estrelas Cadentes|matrizes|Lendário|Dano de chuva de estrelas e buffs aliados
'''
rows=[]
for line in src.strip().splitlines():
    p=line.split('|');assert len(p)==5,line
    id,name,family,rank,effects=p
    rows.append({'item_id':id,'name':name,'family':family,'rank_public':rank,
      'source_url':'https://app.notion.com/p/'+id,'source_type':'NOTION_MASTER',
      'cohort':'INDEX_INSCRIPTIONS_MATRICES_34','as_of':'2026-10-17','mechanics_summary':effects,
      'pa_daily':{'value':None,'classification':'AUSENTE','unit':None},
      'pa_activation':{'value':None,'classification':'AUSENTE','unit':None},
      'source_read':'FICHA_REABERTA_17_10','completeness':'EXTRACAO_INICIAL_DIRECIONADA',
      'lineage_cluster':id,'cost_unqualified':None,
      'pa_semantics':'NAO_VERIFICADO_COMPROMISSO_VERSUS_DEBITO',
      'is_canonical_cost_changed':False,'evidence_note':'Nenhuma cobrança numerica PA identificada no conteúdo da ficha consultada; NAO equivale a custo zero. Para inscrições/matrizes pode haver custo em execução ou em outra fonte.'})
assert len(rows)==34
ids={r['item_id'] for r in base['items']}
assert not ids.intersection(x['item_id'] for x in rows)
base['items'].extend(rows)
base['dataset_id']='PA-CENSO-95-T01-INSCRI-MATRIZ-20261017-R02'
base['provenance']='61 fichas R01 +17 inscrições batalha+9 inscrições encantamento+8 matrizes verificadas por UUID individual em Notion Mestre'
base['status']='CORPUS_TEST_EXTENDIDO_NAO_CENSO_GLOBAL'
base['known_gaps']+=['matrizes/inscrições sem custo localizado não equivalem zero PA','índices externos e aprimoramentos fora dos três diretórios ainda abertos','dados raw de fichas históricas devem ser congelados em snapshot versionado numa futura revisão física completa','contexto de PA de inscrição pode depender de aplicador/receita/sistema específico']
(P/'corpus_pa_v2.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(P/'censo_v2_resumo.json').write_text(json.dumps({'total':len(base['items']),'T01_54':54,'extra_R01':7,'novas_inscricoes_batalha':17,'novas_inscricoes_encantamento':9,'novas_matrizes':8,'costos_diarios_novos_detectados':0,'historical_daily_preserved':True,'sha256_corpus':hashlib.sha256((P/'corpus_pa_v2.json').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('EXTENDED',len(base['items']))
