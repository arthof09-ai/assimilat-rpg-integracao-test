"""Analytic descriptive tags, NOT rank/FIP power audit; no new normative Atlas authority."""
from pathlib import Path
import json,re
import pa_engine_v2 as pa
P=Path(__file__).resolve().parent
TAGS={
 'bonus_atributos':['destreza','força','sabedoria','inteligência','carisma','constituição','atributo','+60 for','+10 int','+8 des'],
 'dano_ofensivo':['dano','explosão','chama','fogo','facas','onda','trovão','corte','tempestade','disparo','ataque'],
 'defesa':['defesa','resistência','ca','rd','rdm','barreira','escudo','proteção','armadura','reflexo','salvaguarda'],
 'movimento':['velocidade','movimento','agilidade','deslocamento','teleporte','portais','voo','espacial'],
 'controle':['selamento','selo','algemas','vínculo','aprision','ilusão','ilusão','paralis','desaceler','congel','control','invisib'],
 'utilidade':['leitura','memória','visão','percepção','rastros','telepatia','clima','fertilidade','crescimento','purifica','respirar'],
 'cura':['cura','regeneração','recupera'],
 'invocacao':['invoca','invocação','invocar'],
}
def derive(x):
 s=x['mechanics_summary'].lower(); tags=sorted(k for k,pat in TAGS.items() if any(y in s for y in pat));return {'item_id':x['item_id'],'source_url':x['source_url'],'source_family':x['family'],'historical_effect_summary':x['mechanics_summary'],
  'public_rank_as_source':x['rank_public'],'effect_rank_atlas':None,'FIP':None,'analytic_tags':tags,'tag_status':'INFERIDO_POR_PADROES_DE_TEXTO_PARA_TRIAGEM; EXIGE_ATLAS_MANUAL',
  'effect_atomic_count':None,'confidence':'RESUMO_INICIAL_SEM_VERIFICACAO_ATOMICA','pa_daily':x['pa_daily'],'pa_activation':x['pa_activation']}
rows=[derive(x) for x in pa.records()];assert len(rows)==95
(P/'atlas_energetico_analitico_v2.json').write_text(json.dumps({'status':'ANALISE_DESCRITIVA_NAO_ATLAS_CANONICO','denominator_item_pages':95,'effect_units_not_yet_atomized':True,'rows':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'pages_annotated':len(rows),'groups_with_at_least_one_analytic_tag':sum(bool(x['analytic_tags']) for x in rows),'power_rank_manually_validated':0,'atomic_effect_units_identified':None},ensure_ascii=False))
if __name__=='__main__':pass
