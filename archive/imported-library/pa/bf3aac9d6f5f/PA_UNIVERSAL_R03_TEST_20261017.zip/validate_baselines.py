"""Retrospective leave-one-lineage-out sanity baseline only, not independent holdout.
Median-only forecasts intentionally naive: diagnoses how inadequate universal PA cost is.
"""
from pathlib import Path
from statistics import median,mean
import json,math
import pa_engine_v2 as M
P=Path(__file__).resolve().parent
rows=[r for r in M.records() if r['pa_daily']['value'] is not None]
pred=[]
for r in rows:
 train=[x for x in rows if x['lineage_cluster'] != r['lineage_cluster']]
 family=[x for x in train if x['family']==r['family']]
 baseline=median(x['pa_daily']['value'] for x in train)
 family_median=median(x['pa_daily']['value'] for x in family) if len({x['lineage_cluster'] for x in family})>=2 else None
 pred.append({'id':r['item_id'],'name':r['name'],'family':r['family'],'cluster':r['lineage_cluster'],'cost':r['pa_daily']['value'],'baseline_global':baseline,'abs_error_global':abs(r['pa_daily']['value']-baseline),'baseline_family_if_two_train_clusters':family_median,'abs_error_family':abs(r['pa_daily']['value']-family_median) if family_median is not None else None})
abs_err=[x['abs_error_global'] for x in pred]
fam=[x['abs_error_family'] for x in pred if x['abs_error_family'] is not None]
out={'kind':'RETROSPECTIVE_LINEAGE_GROUPED_LEAVE_ONE_OUT_MEDIAN_ONLY','global_cost_observations':len(pred),'observed_cost_lineage_clusters':len(set(x['cluster'] for x in pred)),'global_baseline_MAE':mean(abs_err),'global_baseline_MdAE':median(abs_err),'global_baseline_max_abs_error':max(abs_err),'family_evaluable_observations':len(fam),'family_baseline_MAE':mean(fam) if fam else None,'family_baseline_MdAE':median(fam) if fam else None,'does_not_validate_universal_rate':True,'independent_holdout':False,'conclusion':'Cost-only median predicts badly because effects/potency/modalities differ; numbers are not parametric scientific validation','predictions':pred}
(P/'retro_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in out.items() if k!='predictions'},ensure_ascii=False,indent=2))
