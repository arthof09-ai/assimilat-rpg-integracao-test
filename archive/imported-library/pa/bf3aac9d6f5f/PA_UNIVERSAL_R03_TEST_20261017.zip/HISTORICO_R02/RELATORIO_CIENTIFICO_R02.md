# Sistema Universal de PA — R02 · ciência aplicada e motor TEST

**AS-OF:** 17/10/2026. **Ambiente:** MESTRE-SIDE. **Autorização:** ordem científica do Mestre de 17/10/2026. **OP vinculada:** `OP-ARQ-RIN-REC-01` apenas como dependência CRAFT; o Executor PA não herdou writer, workstream, epoch ou lease. **Cânone de itens:** imutável. **Produto:** avaliação de custo histórico, auditoria de hipóteses, cenários e simulador, não norma homologada.

## 1. Autoridades e cadeia de dependência

- **Poder:** PR-ECO-01 Anexo A/Atlas (metodologia canônica; dados vivos), https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- **Econômico:** Motor de Classificação, Criação e Precificação (R-PA-DIA, passagem poder antes preço), https://app.notion.com/p/3eec2b324ede8148a5b3ee17df578535
- **Árvore:** Anexo C PR-ECO-01 (nós, unidades, provenance, anti-dupla contagem), https://app.notion.com/p/3eec2b324ede8102b3f3e6c8851ad1e7
- **Sistema de Magia:** identidade `PA Total − PA comprometido = PA Livre`; exaustão espiritual explicitamente relativa a **conjurar sem PA Livre suficiente**, não generalizada a outros itens, https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373
- **Criação de Ficha:** PA comprometido é ocupação contínua por equipamentos, técnicas ou efeitos; documento não classifica automaticamente cada custo `PA/dia`, https://app.notion.com/p/3ebc2b324ede81449222f3c06b840613
- **Sistema de Combate:** ações, reações, defesa, RD e dano aplicado, https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0
- **DMG-RANK-01 v1.1:** apenas mecanismo de dano-base quando falta número histórico, não substitui fonte específica nem tarifa de PA, https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- **CRAFT/PR-ITEM-02:** apenas consumidor do contrato PA↔CRAFT; produção HOLD e nova receita não autorizada, https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4
- **BOOTSTRAP-COMESTRE**, diretriz `COORD-RESULT-FIRST-20261017-001`, NAC-CONT-03, NAC-NORM-01, NAC-PASS: o gate para norma/produção permanece externo e não executado nesta instância. Nenhum registro remoto foi modificado.

## 2. Censo de fontes

O mapa inicial T-01 contém 54 fichas: 19 armas, 7 armaduras, 13 roupas/acessórios e 15 artefatos. R01 já lera as 54 e sete fichas de comparação externas. R02 reabriu os dois índices de inscrições e o índice de matrizes, seguindo os UUIDs de **17 inscrições de batalha, 9 inscrições de encantamento e 8 matrizes**, cada página individualmente. A soma é **95 IDs físicos distintos**; clusters provisórios de linhagem 94, porque duas fichas reutilizam texto mecânico substancialmente igual (IMPERIAL / Veste Dragão Ascendente). A presença de fichas em índice não torna os itens estatisticamente independentes em mecanismo ou custo.

- **PA diário numérico:** 18/95 páginas; 15 explícitas e 3 por R-PA-DIA. **PA por ativação numérico:** 7/95; quatro páginas documentam ambos. **Sem PA diário numérico classificado:** 77/95 (inclui 2 custos de período não assegurado). Total de ocorrências e efeitos atômicos: **não auditado**, não confundir com páginas.
- **17+9+8 fichas de inscrição/matriz:** nenhum custo PA explícito numericamante localizado nas páginas consultadas. Isso não prova consumo zero: outras fontes, receitas ou aplicação podem determinar o custo. São projetos de inscrição/matriz e não necessariamente equipamentos equipáveis.
- **Distribuição dos 15 PA/dia explícitos** (inclui outlier): mediana 25 PA/dia. Estatística meramente descritiva, sem causalidade nem amostra representativa. `censo_95.json` preserva família/denominador; `corpus_pa_v2.json` contém cada UUID, URL, resumo, rank textual e modalidade.
- **Limite de cobertura:** 95 páginas = 100% apenas do *recorte declarado* de 54+7+34. Universo total de itens, aprimoramentos e outras fichas não delimitado; inventário de efeitos atômicos também não fechado.

## 3. Modelo de unidades

A árvore energética de uma ficha `i` precisa representar **vetores** e não um escalar:

```
E_i = (PA/dia, PA/ativação, PA/turno, PA/evento, PA/carga, PA de manutenção)
```

Cada componente só é informado se a fonte o sustenta ou se for expressamente calculado em modo PROPOSTA com parâmetros do usuário. Não se convertem grandezas distintas sem cenário temporal conhecido. Um custo global histórico de 60 PA/dia por três efeitos **não identifica** três parcelas de 20. Se a ficha registra «7 PA/dia (já somado)» a parcela adicional não deve ser somada outra vez.

**Orçamento de equipamentos:** `D_conhecido = Σ custo_diário_i` (apenas conhecidos), `A_conhecido = Σ usos_ij × custo_por_ativação_ij` (para ativações realmente consideradas). Uma série contém desconhecido, portanto `D_total = null` enquanto faltar custo. Não converter automaticamente `D_conhecido` em `PA_comprometido`: cenários alternativos COMMIT/DEBIT/UNKNOWN estão implementados em `budget()`, com etiquetas explícitas.

**Novo item por proposta explícita:** dado um conjunto de efeitos distintos, com taxa `r_k` para cada família:

`C_diário^PROPOSTA = Σ (intensidade_efeito_k × r_k) + Σ interações_j`.

A fórmula acima **é arquitetura condicional de cálculo**, não descoberta de aditividade canônica. Se falta taxa, falta efeito atômico, ou sinergia é desconhecida: `C_total = null`. Efeitos descritos por aliases do mesmo grupo são contados uma vez. Rank/FIP não introduzem multiplicadores sem evidência.

## 4. H1 — Atributos

O [Amplificador de Atributo](https://app.notion.com/p/3c6c2b324ede82baa4a801de533a5975) tem +3 atributos e 15 PA/dia, **1 exemplo puro compatível com 5**. Não demonstra igualdade por classe, attribute, escala ou temporalidade.

**Novo teste de falsificação condicional (R02):**

| Fonte | Atributos | PA/dia | PA/ponto apenas como razão bruta | Desconto ou interação necessária SE 5 PA/ponto e parcelas não negativas |
|---|---|---|---|---|
| Amplificador de Atributo | +3 atributo | 15 explícito | 5 | 0 |
| [Sabedoria Ancestral](https://app.notion.com/p/3edc2b324ede815699adc0412e96ea2b) | +10 SAB, mais telepatia, memória, leitura | 20 por R-PA-DIA | 2 | pelo menos 30 PA |
| [Amuleto de Inteligência](https://app.notion.com/p/0c4c2b324ede83dd8e1881b52a79e326) | +10 INT, além de +20 dano mágico OU proteção mágica | 30 por R-PA-DIA | 3 | pelo menos 20 PA |
| [Colar cadente](https://app.notion.com/p/3edc2b324ede810daba2cc509677856c) | +2 SAB (até +4 sob luz de estrelas) | 14 explícito | 7 basal, mas condicional | 0 |

**Teorema de restrição:** se todos os atributos custam `c ≥ 0` PA/dia por ponto, o item custa a soma de parcelas **não negativas** sem descontos ou sinergia, então a observação Sabedoria Ancestral impõe `10c ≤ 20`, logo `c ≤ 2`. O caso puro impõe `c = 5`. Portanto **não existe único c** que satisfaça ambos sob essas hipóteses. O Amuleto independente impõe `c ≤ 3`. Isso NÃO prova que a lembrança do Mestre esteja errada: pode haver diferenças de formulação/rank/usuário, descontos de combinação, custos legados, ativação/temporalidade, ou classificação incompleta. Exige decisão/mais pares. `AMANTE DAS SOMBRAS` tem 21 PA sem período confirmado no bloco inicial e foi corretamente EXCLUÍDA desta análise de PA diário.

**Nível de evidência:** um caso de referência confirma a razão histórica; duas fichas desafiam universalidade aditiva simples; custo marginal por atributo ainda **não calibrado**.

## 5. H2 — Passivos/ativos

Quatro itens do recorte possuem simultaneamente custos diários e por ativação:

| Item | Diário | Ativação | Cuidado |
|---|---:|---:|---|
| Sombra Sussurrante | 34 | 6 | 7 PA/dia já somado, sem soma adicional |
| Bota Caminho Veloz | 18 | 5 | Efeito ativo +8 m e vários passivos |
| Traje Águia Celeste | 20 | 4 | Ativo pulo, passivos percepção e CA condicional |
| Amuleto Tempo Eterno | 15 | 15 | Uma ativação a cada dois dias |

As **razões entre PA/dia e PA/uso não são relações válidas de potência**: unidades diferentes e habilidades não equivalentes. Sem par funcional idêntico ativo/passivo com duração e frequência controladas, o prêmio do passivo não é estimável. Cenários T1 e T3 apenas verificam tratamento diferente das modalidades.

## 6. H3 — Potência/rank

Os 18 custos observáveis abrangem itens e efeitos distintos; exemplos de 600 PA/dia (Espada do Lendário), 112 (Coroa Reino Esplendor) e 15 (Pulseira Rocha) não oferecem independência para estimar a inclinação do poder. A classificação pública encontrada e a classe de efeito/FIP por Atlas não foram individualmente homologadas nesta coleta. `atlas_energetico_analitico_v2.json` associa **95 resumos de efeitos**, com **81 etiquetas exploratórias não normativas** recuperadas por palavras-chave; não é decomposição atômica nem substitui o Atlas.

**Diagnóstico quantitativo de modelo simplista:** leave-one-*lineage*-out retrospectivo usando mediana única das 18 fichas diárias resulta **MAE = 47,39 PA/dia**, erro mediano absoluto 10, pior erro 575. Usar mediana por família nos 15 casos com comparadores suficientes ainda dá **MAE ≈ 87,37 PA/dia** (afetado fortemente por outlier). Isso demonstra que **mediana/rank/família isolados não bastam**; tais números **não** constituem holdout independente nem prova de poder preditivo.

## 7. H4 — Dano adicional +20

O dano intrínseco da arma e o adicional oferecido ao portador são variáveis distintas. Para dano-base determinístico `d`, bônus `b`, RD por acerto `R`, o incremento pós-RD em um acerto elegível é:

`delta_aplicado = max(0, d+b−R) − max(0,d−R)`.

Para cenários de `N` tentativas, `p_acerto`, `p_elegibilidade` e `alvos`, o **ganho esperado analítico** é `N × p_acerto × p_elegibilidade × alvos × delta_aplicado`. Não confundir com empiria de combate: acerto/RD não são invariáveis em todos os mundos, alvos podem depender, golpes críticos e resistência podem mudar a equação e devem requerer parâmetros específicos.

**Com d=15, b=20, RD=25, p_acerto=0,6:** 1 aplicação=6 pontos incrementais esperados; ativação com 2 aplicações=12; 3 ataques=18; 3 ataques com 50% da condição=9; 3 ataques em 2 alvos=36. Todos são **dano**, não PA. Se o Mestre algum dia aprovar/validar uma taxa `ρ` em PA por dano marginal esperado, os valores seriam `6ρ`, `12ρ`, `18ρ`, `9ρ`, `36ρ`, sem transformar `ρ` em cânone neste relatório.

O Amuleto de Inteligência (+20 dano mágico **OU** resistência mágica, +10 INT, 30 PA interpretados) e o Manto do Arquimago (+30 dano mágico e múltiplos bônus, 60 PA/dia) são confusos quanto à parcela de dano; nenhuma tarifa PA/+20 foi estimada. Uma espada que sempre acrescente +20 só pode receber cenário condicional ou **PENDENTE**, não número supostamente validado.

## 8. Outros coeficientes

CA, RD, RDM, salvaguardas, iniciativa, velocidade, cura, regeneração, controle, duração, área e alvo foram tratados como **dimensões analíticas**. Nenhuma taxa marginal universal identificada. O contraste Armadura Guardiã Elemental com itens de CA/defesa não identifica preço do +6 CA sem simultaneamente lidar com base da armadura, 35 RD contra elementais e +8 salvaguardas. O mesmo vale para Bota Caminho Veloz (6 m/dia e ativo +8 m), que mistura silêncio e adaptação.

## 9. Testes / holdout

O pacote R02 executa as 47 regressões R01 e 48 verificações R02, incluindo os 10 contrafactuais T1–T10 da ordem (os testes simulam invariantes e condições explícitas, não calibram poderes históricos). O verificador independente de invariantes do modelo confere UUIDs, contagem 95 e integridade de fonte: local, **não** auditoria externa.

**Holdout real de previsão = 0**, pois a coorte inteira foi vista antes de calibrar um modelo e as classes de custo têm poucos comparadores. Um split retrospectivo por hash de linhagem só valida infraestrutura e ausência de vazamento óbvio, **não** generalização estatística. Também não existem coeficientes estimados que permitam calcular MAE de uma futura fórmula PA universal sem hipótese arbitrária. `retro_validation.json` é apenas diagnóstico de **baseline mediana**, não validação de fórmula final.

## 10. Contrato CRAFT e prontidão

`contract_craft(item_id)` emite custo diário classificado, custo por ativação, fonte, efeitos resumidos, incerteza temporal, status e **production_hold=true**. O sistema não edita ficha, não cria receita, não grava Notion, não toca Party e não decide RC5; continua a interoperar com `pa_engine.py` R01, sem motor concorrente. `CALCULADORA_MOBILE_OFFLINE.html` oferece consulta local das 95 fichas, orçamento hipotético e proposta paramétrica, compatível com navegador móvel, sem exigir Python do Mestre.

**Conclusão científica responsável:** existe uma calculadora TEST útil para custo histórico e cenários. A regra universal numérica ainda não foi identificada: a evidência histórica atual contém contradições contra a extrapolação linear aditiva simples e não contém pares controlados suficientes para calibrar demais eixos. Não é legítimo declarar missão perfeita ou liberação de CRAFT com esse estado.

## Quatro classes finais

| REGRA HISTÓRICA VERIFICADA | INFERÊNCIA EMPÍRICA | PROPOSTA DE REGRA | DECISÃO NECESSÁRIA DO MESTRE |
|---|---|---|---|
| R-PA-DIA, escopo contextual | 3 custos normalizados nessa coorte | Parser aplica regra sem transcrever total falso | Nenhuma, preservar regra existente |
| `PA Total − PA comprometido = PA Livre` | `PA/dia` não prova sozinho alocação da reserva | Cenários COMMIT/DEBIT/UNKNOWN | Classificar cobrança/retenção/liberação onde o cânone omitir |
| Amplificador +3 = 15/dia | 5 PA/ponto em **um caso**, universal aditivo incompatível com outras fichas | Coeficiente por modalidade/atributo + política de composição, sujeito a novos pares | Concordância do Mestre sobre escopo da memória H1 e exceções |
| Quatro itens com PA/dia e PA/atv | coexistência real | Vetor temporal e contador de usos | Não inventar prêmio de passivo sem pares |
| Custos ofensivos explícitos de itens preservados | +20 dano sem taxa isolada | Equações marginais e sensibilidade de ρ | Aprovação futura de taxa somente após evidência ou escolha autoral |
| CRAFT HOLD, sem receita nova | Motor TEST tem contrato de consulta | Teste controlado de integração | Writer legítimo, auditoria e gate NAC-PASS, autorização específica de liberação |
