# PA Universal R02 · Entrega MESTRE-SIDE

**Entrega R02 em TEST; NÃO norma completa ou homologada.** Continuidade incrementativa de PA R01 com 95 páginas individuais lidas de Notion Mestre. Reutiliza `pa_engine.py` original R01 e incorpora `pa_engine_v2.py`, corpus `corpus_pa_v2.json`, atlas analítico (não normativo), H1 como teste de identificabilidade, cenários H4 +20 dano, orçamento com três modos de cobrança e contrato CRAFT.

## Mestre pelo celular

Abra `CALCULADORA_MOBILE_OFFLINE.html` em navegador de celular. Ela tem filtro de 95 itens, custos históricos, comparação de PA simultâneo e cálculo **PROPOSTA** só com taxas fornecidas. Todos os dados estão embutidos no HTML; não requer servidor, internet, planilha, login nem Python. Nenhuma alteração remota é feita.

**Também pode perguntar diretamente ao Comestre no ChatGPT:** “Consulte o PA histórico da Bota Caminho Veloz”, “Demonstre +20 de dano sob RD 25”, “Use H1 condicional para +10 CON” — sem executar nada no seu celular.

## Com código (teste de executor)

```bash
python pa_engine_v2.py census
python pa_engine_v2.py lookup 'Bota Caminho Veloz'
python pa_engine_v2.py craft 'Bota Caminho Veloz'
python pa_engine_v2.py h1
python pa_engine_v2.py damage20
python pa_engine_v2.py budget 'Arco Exterminador Elemental (L)' 'Armadura Guardiã Elemental (ON)'
python pa_engine_v2.py quote entrada_exemplo_armadura.json
python validate_baselines.py
python -m unittest -v test_pa_engine.py test_pa_engine_v2.py
python auditor_v2.py
```

## Alertas de leitura

- `95 páginas` não são `95 observações com custo`: existem apenas 18 PA/dia numéricos, 7 ativações.
- `PA/dia` não prova reserva comprometida ou débito diário.
- O episódio de colapso por magia forçada não é regra geral para falha de item.
- `AMANTE DAS SOMBRAS` tem 21 PA de periodicidade não confirmada; não foi tratada como custo diário em H1.
- `R-PA-DIA` interpreta PA numérico sem gatilho ao final da ficha, respeitando contexto.
- Todos os coeficientes para item novo são hipotéticos e explicitamente fornecidos; uma previsão incompleta retorna null.
- O contrato não dá permissão de fabricar itens ou receitas; CRAFT em HOLD.

Veja `RELATORIO_CIENTIFICO_R02.md` para dados, equações, fontes, limites e decisões. Veja `PSV_R02.md` para handoff.
