"""R03 incremental PA source expansion: 108 source UUIDs; 2 multi-activation items; upgrades guarded.
Uses R02 hypothesis/math/proposal rather than a competing engine. No writes.
"""
from pathlib import Path
from collections import Counter,defaultdict
import copy,hashlib,math,json,statistics,argparse
import pa_engine_v2 as prev
import pa_engine as legacy
P=Path(__file__).resolve().parent
DATA=P/'corpus_pa_v3.json'

def records():return json.loads(DATA.read_text('utf8'))['items']

def get(identifier):
 q=legacy._flat(str(identifier));l=[r for r in records() if q in (legacy._flat(r['item_id']),legacy._flat(r['name']),legacy._flat(r['source_url']))]
 if len(l)!=1:raise ValueError('Identidade deve ter um único resultado: '+str(identifier))
 return copy.deepcopy(l[0])

def historical(identifier):
 r=get(identifier)
 return {'mode':'HISTORICO','id':r['item_id'],'item':r['name'],'family':r['family'],'url':r['source_url'],
   'pa_daily':r['pa_daily'],'pa_activation':r['pa_activation'], 'activation_abilities':r.get('pa_activation_occurrences',[]),
   'uncertainty':r['cost_unqualified'],'rank_as_source':r['rank_public'],'summary':r['mechanics_summary'],
   'equipable_or_upgrade':r.get('object_type','equipamento'), 'historical_preserved':True,'no_production_write':True,
   'pa_semantics':r['pa_semantics'],'lineage_cluster':r['lineage_cluster']}

def census():
 rs=records();groups=defaultdict(Counter)
 for r in rs:
  g=groups[r['family']];g['pages']+=1;g['daily_'+r['pa_daily']['classification']]+=1
  g['with_any_activation']+= bool(r['pa_activation']['value'] is not None or r.get('pa_activation_occurrences',[]))
 explicit=[r['pa_daily']['value'] for r in rs if r['pa_daily']['classification']=='EXPLICITA']
 known=[r for r in rs if r['pa_daily']['value'] is not None]
 return {'pages':len(rs),'distinct_uuids':len(set(r['item_id'] for r in rs)),
    'lineage_clusters_provisional':len(set(r['lineage_cluster'] for r in rs)),
    'cohorts':dict(Counter(r['cohort'] for r in rs)), 'families':{k:dict(v) for k,v in groups.items()},
    'daily_explicit':len(explicit),'daily_R_PA_DIA':sum(r['pa_daily']['classification']=='REGRA_R_PA_DIA' for r in rs),
    'daily_numeric':len(known),'daily_missing_or_ambiguous':len(rs)-len(known),
    'activation_item_records':sum(r['pa_activation']['value'] is not None or r.get('pa_activation_occurrences',[])!=[] for r in rs),
    'activation_ability_costs':sum((bool(r['pa_activation']['value'] is not None)+len(r.get('pa_activation_occurrences',[]))) for r in rs),
    'daily_and_activation_items':sum(r['pa_daily']['value'] is not None and (r['pa_activation']['value'] is not None or r.get('pa_activation_occurrences',[])!=[]) for r in rs),
    'explicit_daily_median':statistics.median(explicit), 'effects_atomic_denominator':'NAO_FECHADO',
    'global_population_denominator':'ABERTO', 'upgrade_pages':sum(r['family']=='aprimoramentos' for r in rs),
    'source_index':'MAPA T-01, inscrição/matriz índices e índice de Aprimoramentos, além de comparadores de busca','caution':'Aprimoramentos não são objetos equipáveis independentes; PA de melhoria não somado automaticamente ao PA de equipamento'}

def budget(item_ids,pa_total,committed_external=0,daily_semantics='UNKNOWN',uses=None):
 if daily_semantics not in ('UNKNOWN','COMMIT','DEBIT'):raise ValueError('semantics')
 if not isinstance(item_ids,list) or len(item_ids)!=len(set(item_ids)):raise ValueError('Itens duplicados')
 if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and x>=0 for x in (pa_total,committed_external)) or committed_external>pa_total:raise ValueError('PA invalido')
 items=[historical(i) for i in item_ids]
 if any(i['equipable_or_upgrade']=='aprimoramento_aplicavel' for i in items):raise ValueError('Aprimoramento não é equipamento autônomo: vincular ao item-base e reconciliar sobreposição')
 known=sum(i['pa_daily']['value'] or 0 for i in items)
 missing=[i['item'] for i in items if i['pa_daily']['value'] is None]
 out={'mode':'CONFIGURACAO_R03_TEST','equipped_item_count':len(items),'daily_known_subtotal':known,'daily_total':None if missing else known,
   'missing_daily':missing,'pa_total':pa_total,'external_committed':committed_external,'pa_free_before_item_daily':pa_total-committed_external,
   'daily_semantics':daily_semantics,'daily_accounting_canonical':'PENDENTE','no_effect_applied':True,'spell_failure_not_generalized':True}
 use_total=0;unresolved=[];usage=[]
 for key,count in (uses or {}).items():
  if not isinstance(count,int) or isinstance(count,bool) or count<0:raise ValueError('Contagem usos inválida')
  source,sep,ability=key.partition('#');r=historical(source)
  if r['id'] not in {i['id'] for i in items}:raise ValueError('Uso de item não equipado')
  if r['activation_abilities']:
   matches=[x for x in r['activation_abilities'] if x['ability_id']==ability]
   if not matches:raise ValueError('Ficha possui múltiplas habilidades; selecionar #ACT_1 ou #ACT_2 para evitar cobrança incorreta')
   price=matches[0]['value'];title=matches[0]['name']
  else:
   if sep:raise ValueError('Item não possui habilidade registrada sob esse ID')
   price=r['pa_activation']['value'];title='ativa_documentada'
  if price is None:
   if count:unresolved.append(r['item'])
  else:
   use_total+=price*count;usage.append({'item':r['item'],'ability':title,'count':count,'cost_per_activation':price,'usage_pa_subtotal':price*count})
 out['usage_detail']=usage;out['known_activation_subtotal_for_requested_uses']=use_total;out['unknown_activation_requests']=unresolved
 if daily_semantics=='COMMIT' and not missing:
  remaining=pa_total-committed_external-known
  out['scenario_free_after_daily_commit']=remaining if remaining>=0 else None
  out['scenario_has_numerical_coverage']=remaining>=use_total and not unresolved
 if daily_semantics=='DEBIT' and not missing:
  out['scenario_current_PA_after_daily_if_current_equated_to_total']=pa_total-known if known<=pa_total else None
  out['scenario_total_after_uses_if_same_pool']=pa_total-known-use_total if known+use_total<=pa_total and not unresolved else None
  out['warning']='Hipótese de gasto em PA Total inicial; recuperação e retenção não confirmadas'
 return out

def quote_new(item,rates=None):return prev.quote_new(item,rates)
def h1():return prev.attribute_h1_audit()
def damage20():return prev.incremental_damage_20()
def baseline():
 vals=[r['pa_daily']['value'] for r in records() if r['pa_daily']['value'] is not None]
 return {'known_n':len(vals),'simple_median_pa_day':statistics.median(vals),'no_coefficient_estimated':True}
def craft(identifier):
 r=historical(identifier)
 return {'contract':'PA_TO_CRAFT_R03_TEST','id':r['id'],'source':r['url'],'kind':r['equipable_or_upgrade'],
 'daily':r['pa_daily'],'activation':r['pa_activation'],'activation_abilities':r['activation_abilities'],
 'unqualified':r['uncertainty'],'PA_day_semantics':'PENDENTE_COMPROMISSO_VERSUS_DEBITO',
 'requires_base_item_linkage':r['equipable_or_upgrade']=='aprimoramento_aplicavel',
 'historical_unchanged':True,'production_hold':True,'recipe_writes_permitted':False}

def holdout():
 rs=records();gr={}
 for r in rs:
  k=r['lineage_cluster'];gr[k]='retro_reserve' if int(hashlib.sha256(k.encode()).hexdigest()[:8],16)%5==0 else 'development'
 return {'n_pages':len(rs),'n_groups':len(gr),'n_retro_reserved_groups':sum(x=='retro_reserve' for x in gr.values()),'independent_holdout':False,'coefficient_forecast_holdout_n':0,'generalization_error':None}

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['census','lookup','h1','damage20','budget','quote','craft','baseline','holdout']);p.add_argument('args',nargs='*');a=p.parse_args()
 if a.mode=='census':v=census()
 elif a.mode=='lookup':v=historical(' '.join(a.args))
 elif a.mode=='h1':v=h1()
 elif a.mode=='damage20':v=damage20()
 elif a.mode=='baseline':v=baseline()
 elif a.mode=='holdout':v=holdout()
 elif a.mode=='craft':v=craft(' '.join(a.args))
 elif a.mode=='budget':v=budget(a.args,300,80)
 else:
  data=json.loads(Path(a.args[0]).read_text('utf8'));v=quote_new(data['item'],data.get('rates'))
 print(json.dumps(v,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
