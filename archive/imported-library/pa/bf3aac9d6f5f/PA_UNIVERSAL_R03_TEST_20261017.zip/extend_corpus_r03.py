import json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
D=json.loads((P/'corpus_pa_v2.json').read_text('utf8'))
# 10 named historical upgrades + 3 distinct historical items outside the 95-page corpus;
# every source was individually fetched from Notion Mestre 17 Oct 2026.
# Fields: UUID|NAME|FAMILY|PUBLIC RANK|SUMMARY|PA/DAY|SPECIAL
src='''
a23c2b324ede829bb8168165991577ff|Armadura de Zephyr (L)|armaduras_extra|Lendário|+11 CA +15 DES +15m deslocamento +25 ataque +50 dano de Vento por turno; PA já somado|90|
a70c2b324ede83c2ac490135cd512e9f|Lâmina Aurora Boreal|armas_extra|Sem classificação|Bônus dano e atributos +5 CAR +7 FOR +3 CON; ativas cegueira e dano radiante; aprimoramento -16 PA sem escopo temporal seguro|95|ATV:6:Luz da Aurora;ATV:7:Harmonia dos Elementos;AMBIGUO:-16_PA_APRIMORAMENTO
9efc2b324ede8250a37981fb1fef45dd|CAJADO VÓRTEX SOMBRIO|armas_extra|Sem classificação|+3d6 em magias sombra +1d6 fogo +2 CD +outros bônus; ativas escuridão e gravidade|21|ATV:6:Força Negra;ATV:14:Gravidade Abissal
5f7c2b324ede83de9c7a81fcb19b0195|Armadura Anã|aprimoramentos|Sem classificação|+2 CA com penalidade de movimento e reação contra empurrão|6|
1d2c2b324ede8343be42810a0b54f1d2|Adamante|aprimoramentos|Sem classificação|Críticos recebidos tornam-se ataques normais|7|
559c2b324ede829a9139813d4899b07a|Invulnerabilidade|aprimoramentos|Sem classificação|Resistência não mágica com ativação de imunidade 30 s 2 vezes ao dia (PA por ativação não dito)|15|
16cc2b324ede831290f801af40e0e5bc|Mitral|aprimoramentos|Sem classificação|Remove penalidade de furtividade/requisito FOR e devolve até +3m deslocamento|8|
eb6c2b324ede83eaab08812d52473dc1|Resistência|aprimoramentos|Sem classificação|Resistência a tipo escolhido de dano; PA ausente||
be9c2b324ede83108c3d016dc6ffba91|Marítima|aprimoramentos|Sem classificação|Deslocamento natação e emergência à superfície|8|
6c2c2b324ede83a7b7dc013f94eb052c|Duro de Matar|aprimoramentos|Sem classificação|Ignorar dano fatal 1 vez ao dia|14|
383c2b324ede820ab38881abbe91ac60|Mobilidade|aprimoramentos|Sem classificação|+2 CA condicional durante movimento|7|
c42c2b324ede8259995e81a2461f46e2|Olhos nas Costas|aprimoramentos|Sem classificação|Reação especial a flanqueamento primeiro evento combate|11|
e56c2b324ede82a898bb8137c2d8d0f3|Vitalidade|aprimoramentos|Sem classificação|+1 PV por nível e acumula ao repetir melhoria|8|
'''
rows=[]
for l in src.strip().splitlines():
 x=l.split('|');assert len(x)==7,x
 id,name,fam,rank,effect,paday,special=x;act=[];amb=[]
 for part in special.split(';'):
  if part.startswith('ATV:'):
   _,cost,title=part.split(':',2);act.append({'ability_id':f'ACT_{len(act)+1}','name':title,'value':int(cost),'unit':'PA/ativação','classification':'CONTEXTO_ATIVO','provenance':'ficha Notion'})
  elif part.startswith('AMBIGUO:'):amb.append(part.split(':',1)[1])
 record={'item_id':id,'name':name,'family':fam,'rank_public':rank,'source_url':'https://app.notion.com/p/'+id,'source_type':'NOTION_MASTER',
   'cohort':'EXTRA_THREE_AND_UPGRADE_TEN','as_of':'2026-10-17','mechanics_summary':effect,
   'pa_daily':{'value':int(paday) if paday else None,'classification':'EXPLICITA' if paday else 'AUSENTE','unit':'PA/dia' if paday else None},
   'pa_activation':{'value':None,'classification':'MULTIPLAS_ATIVAS' if len(act)>1 else 'AUSENTE','unit':None},
   'pa_activation_occurrences':act,'source_read':'FICHA_REABERTA_17_10','completeness':'EXTRACAO_DIRECIONADA_TEXTUAL',
   'lineage_cluster':id,'cost_unqualified':{'literal':amb,'status':'PENDENTE'} if amb else None,
   'pa_semantics':'NAO_VERIFICADO_COMPROMISSO_VERSUS_DEBITO','is_canonical_cost_changed':False,
   'object_type':'aprimoramento_aplicavel' if fam=='aprimoramentos' else 'equipamento',
   'evidence_note':'Upgrade não equivale automaticamente a equipamento independente; deve ser combinado com base no contrato com CRAFT.'}
 rows.append(record)
assert len(rows)==13;assert not {x['item_id'] for x in D['items']}.intersection(x['item_id'] for x in rows)
D['items'].extend(rows)
D['dataset_id']='PA-CENSO-108-R03-20261017'
D['provenance']='61 R01 + 34 inscrições/matrizes R02 + 3 equipamentos extra + 10 aprimoramentos reais indexados'
D['status']='TEST_R03_NAO_CENSO_GLOBAL'
D['known_gaps']+=['PA do item adicional pode ser composição de aprimoramento, sem duplicar', 'Lâmina Aurora Boreal registra -16 PA em aprimoramento sem semântica debit/credito validada','duas novas fichas possuem duas habilidades ativas com custos diferentes; não agregar como PA/ativação única']
(P/'corpus_pa_v3.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('CORPUS',len(D['items']))
