"""Separate read-only data auditor, no import of the PA calculator or model (not third-party audit)."""
import json,hashlib,re
from pathlib import Path
from collections import Counter
P=Path(__file__).resolve().parent
D=json.loads((P/'corpus_pa_v2.json').read_text('utf8'))
r=D['items'];assert len(r)==95
assert len({x['item_id'] for x in r})==95
assert Counter(x['cohort'] for x in r)=={'MAPA_T01_54':54,'EXTRA_COMPARADORES_7':7,'INDEX_INSCRIPTIONS_MATRICES_34':34}
assert Counter(x['family'] for x in r if x['cohort']=='INDEX_INSCRIPTIONS_MATRICES_34')=={'inscricoes_batalha':17,'inscricoes_encantamento':9,'matrizes':8}
for a in r:
 assert re.fullmatch('[0-9a-f]{32}',a['item_id'])
 assert a['source_url']=='https://app.notion.com/p/'+a['item_id']
 assert a['pa_daily']['value'] is None or isinstance(a['pa_daily']['value'],int) and a['pa_daily']['value']>=0
 assert a['pa_activation']['value'] is None or isinstance(a['pa_activation']['value'],int) and a['pa_activation']['value']>=0
 assert a['is_canonical_cost_changed'] is False
 assert a['pa_semantics']=='NAO_VERIFICADO_COMPROMISSO_VERSUS_DEBITO'
assert len([a for a in r if a['pa_daily']['value'] is not None])==18
assert Counter(a['pa_daily']['classification'] for a in r)['EXPLICITA']==15
assert Counter(a['pa_daily']['classification'] for a in r)['REGRA_R_PA_DIA']==3
assert sum(a['pa_activation']['value'] is not None for a in r)==7
assert not any(a['pa_daily']['value'] is not None for a in r if a['cohort']=='INDEX_INSCRIPTIONS_MATRICES_34')
A={x['name']:x for x in r}
assert A['Arco Exterminador Elemental (L)']['pa_daily']['value']==64
assert A['Bota Caminho Veloz']['pa_daily']['value']==18
assert A['AMANTE DAS SOMBRAS']['pa_daily']['value'] is None
assert A['Sabedoria Ancestral']['pa_daily']['value']==20
assert A['Sabedoria Ancestral']['pa_daily']['classification']=='REGRA_R_PA_DIA'
assert any(x['name']=='(AI) Amuleto de Inteligência' and x['pa_daily']['value']==30 for x in r)
page=(P/'CALCULADORA_MOBILE_OFFLINE.html').read_text('utf8')
assert page.count('3edc2b324ede')>=54 and page.count('https://app.notion.com/p/')>=95
for k in ['MESTRE-SIDE','PA/dia','INDETERMINADO','H1']:assert k in page
out={'status':'PASS_INDEPENDENT_LOCAL_STRUCTURE_CHECK','items':95,'ids_unique':95,'explicit_daily':15,'interpreted_daily':3,'activation_known':7,'inscriptions_matrices_new_without_PA':34,'mobile_HTML_local_only':True,'hash_corpus':hashlib.sha256((P/'corpus_pa_v2.json').read_bytes()).hexdigest(),'notion_write':False,'external_scientific_audit':False,'NAC_PASS_terminal':False}
(P/'auditoria_local_resultado.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(out,ensure_ascii=False,indent=2))
