"""Read-only independent STRUCTURAL verifier, not independent scientific validation or NAC-PASS."""
from collections import Counter
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
old=json.loads((P/'corpus_pa_v2.json').read_text('utf8'))['items'];new=json.loads((P/'corpus_pa_v3.json').read_text('utf8'))['items']
assert len(old)==95 and len(new)==108
past={x['item_id']:x for x in old};now={x['item_id']:x for x in new}
assert len(now)==108
for key,orig in past.items():
 assert now[key]==orig, 'Historical baseline modified '+key
assert len(set(now)-set(past))==13
assert Counter(x['family'] for x in new if x['cohort']=='EXTRA_THREE_AND_UPGRADE_TEN')=={'aprimoramentos':10,'armas_extra':2,'armaduras_extra':1}
for x in new:
 assert re.fullmatch('[0-9a-f]{32}',x['item_id'])
 assert x['source_url']=='https://app.notion.com/p/'+x['item_id']
 assert x['pa_daily']['value'] is None or isinstance(x['pa_daily']['value'],int) and x['pa_daily']['value']>=0
 assert x['is_canonical_cost_changed'] is False
 assert x['pa_semantics']=='NAO_VERIFICADO_COMPROMISSO_VERSUS_DEBITO'
 for a in x.get('pa_activation_occurrences',[]):
  assert a['value']>=0 and a['unit']=='PA/ativação' and a['ability_id']
assert sum(x['pa_daily']['value'] is not None for x in new)==30
assert sum(x['pa_daily']['classification']=='EXPLICITA' for x in new)==27
assert sum(x['pa_daily']['classification']=='REGRA_R_PA_DIA' for x in new)==3
assert sum(bool(x['pa_activation']['value'] is not None or x.get('pa_activation_occurrences',[])) for x in new)==9
assert sum((x['pa_activation']['value'] is not None)+len(x.get('pa_activation_occurrences',[])) for x in new)==11
assert sum(x['pa_daily']['value'] is not None and bool(x['pa_activation']['value'] is not None or x.get('pa_activation_occurrences',[])) for x in new)==6
name={x['name']:x for x in new}
assert name['Lâmina Aurora Boreal']['pa_daily']['value']==95
assert [a['value'] for a in name['Lâmina Aurora Boreal']['pa_activation_occurrences']]==[6,7]
assert [a['value'] for a in name['CAJADO VÓRTEX SOMBRIO']['pa_activation_occurrences']]==[6,14]
assert name['Lâmina Aurora Boreal']['cost_unqualified']['literal']==['-16_PA_APRIMORAMENTO']
assert name['Mobilidade']['pa_daily']['value']==7
assert name['Vitalidade']['pa_daily']['value']==8
assert name['Resistência']['pa_daily']['value'] is None
s=(P/'CALCULADORA_MOBILE_OFFLINE.html').read_text('utf8')
assert s.count('https://app.notion.com/p/')>=108 and '108 fichas' in s and 'data-use' in s
assert '<script>' in s and '</script>' in s and 'TOTAL DIÁRIO' in s
m={'status':'PASS_INDEPENDENT_LOCAL_STRUCTURE_CHECK','pages':108,'new_records':13,'baseline_95_unchanged':True,
 'daily_explicit':27,'daily_R_PA_DIA':3,'daily_numeric':30,'activation_items':9,'activation_abilities':11,
 'reported_tests_from_unittest':'128_PASS','mobile_contains_108_sources':True,'NAC_PASS_terminal':False,
 'third_party_science_audit':False,'notion_mutation':False,'sha256_corpus':hashlib.sha256((P/'corpus_pa_v3.json').read_bytes()).hexdigest()}
(P/'auditoria_local_R03.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(m,ensure_ascii=False,indent=2))
