# OP PA↔CRAFT — Parecer Científico R03 · 17/10/2026

## Status e natureza

**TEST funcional, MESTRE-SIDE, sem liberação canônica.** Resultado vinculado à pesquisa autorizada do Mestre e dependência `OP-ARQ-RIN-REC-01`, mas não reivindica writer/lease/epoch/Assignment ou identidade de CM-000002 do CRAFT. Toda a base histórico-me-cânica foi preservada. Nenhuma escrita Notion ou Party executada.

## Fontes e denominadores

Corpus R01 de 61 identidades do Notion (54 do MAPA T-01, sete comparadores extras). R02 adicionou 17 inscrições batalha, nove inscrições encantamento, oito matrizes, todas individualmente consultadas. R03 reabriu **10 aprimoramentos históricos do índice real** e **três equipamentos** adicionais: Armadura de Zephyr, Lâmina Aurora Boreal e Cajado Vórtex Sombrio.

- **108/108** fichas recuperadas dentro do **escopo selecionado declarado**, **107** clusters de texto/linhagem provisórios; universo global aberto, sem alegação de 100% do RPG.
- **30/108** páginas possuem PA/dia numérico (**27 explícitos + 3 interpretados R-PA-DIA**); **78/108** não permitem valor diário numérico seguro. **9/108** páginas possuem habilidades com custo por ativação; **11 custos de habilidades** ao todo porque Lâmina Aurora Boreal e Cajado Vórtex Sombrio possuem duas cada; seis itens têm ambos os tipos de custo. O índice da ficha é contagem de páginas, não de poderes atômicos.
- **10 aprimoramentos são modificações de equipamento**, não dez equipamentos adicionais vestíveis. Nove têm PA/dia numérico e um não. Em composição, usar item-base e prevenir somar novamente efeitos já incluídos.
- Entre os **27 custos diários explícitos**, a mediana é **18 PA/dia**; essa distribuição mistura equipamentos e aprimoramentos e não é parâmetro de equilíbrio. Baseline estatístico ingênuo de mediana única usando leave-one-lineage-out retrospectivo nas 30 fichas conhecidas: MAE=**37,03 PA/dia**, mediana do erro absoluto 11, erro máximo 580. Não validar coeficientes com esse ensaio exploratório.
- `atlas_energetico_analitico_v3.json` oferece etiquetas de triagem textual para **108/108 resumos**, 92 dos quais possuem pelo menos uma etiqueta; **FIP por efeito e denominador atômico ainda não auditados**. A etiqueta inferida não é Atlas canônico novo.

## H1 — +5 PA por atributo

**VERIFICADO como exemplo:** Amplificador de Atributo, +3 no atributo, 15 PA/dia. Razão 5/atributo em um caso puro.

**INFERÊNCIA condicionada:** se todos os pontos custassem os mesmos 5 PA/dia, as parcelas de efeitos fossem não negativas e **aditivas sem desconto/interação**, [Sabedoria Ancestral](https://app.notion.com/p/3edc2b324ede815699adc0412e96ea2b) (+10 SAB, telepatia, memória, leitura, 20 PA por R-PA-DIA) precisaria de compensação energética de pelo menos **30 PA**; [Amuleto de Inteligência](https://app.notion.com/p/0c4c2b324ede83dd8e1881b52a79e326) (+10 INT, +20 dano mágico OU resistência mágica, 30 PA por R-PA-DIA) precisaria de **20 PA**. Sob aditividade não negativa o primeiro impõe `c ≤ 2`, o segundo `c ≤ 3`, contradizendo `c=5` do exemplar puro. Isso não nega a memória do Mestre: efeitos podem ter sistemas diferentes, descontos, condições, custos históricos heterogêneos, ou fontes incompletas. **Não canonizar nenhuma taxa universal.**

**Novo comparador:** [Lâmina Aurora Boreal](https://app.notion.com/p/a70c2b324ede83c2ac490135cd512e9f) +5 CAR +7 FOR +3 CON (15 pontos-base) entre diversos poderes por 95 PA/dia: a proposta de 5/pt demandaria 75 para atributos, restando 20 para os demais componentes na hipótese aditiva. **Não identifica** 5/pt, mas informa confronto futuro com engenharia do efeito e upgrade `-16 PA` que não tem período claro.

`AMANTE DAS SOMBRAS`: 21 PA localizado no início, com duração não comprovada; excluído da regressão de PA diário. `IMPERIAL` e `Veste Dragão Ascendente`: descrições iguais, cluster de linhagem único provisório para não treinar/validar como duas observações independentes.

## H2 — Ativa e passiva

Antes, quatro itens da coorte original apresentavam os dois custos. Nesta etapa, dois itens adicionais ampliam para **seis**. **Novidade importante:**

| Ficha | Diário | Ativação 1 | Ativação 2 |
|---|---:|---:|---:|
| [Lâmina Aurora Boreal](https://app.notion.com/p/a70c2b324ede83c2ac490135cd512e9f) | 95 | Luz da Aurora 6 | Harmonia dos Elementos 7 |
| [Cajado Vórtex Sombrio](https://app.notion.com/p/9efc2b324ede8250a37981fb1fef45dd) | 21 | Força Negra 6 | Gravidade Abissal 14 |

Não pode haver uma coluna única “PA/ativação = média 6,5” porque habilidades têm gatilhos e funções diferentes. O avaliador agora obriga ID específico de habilidade.

[Invulnerabilidade](https://app.notion.com/p/559c2b324ede829a9139813d4899b07a) possui **15 PA/dia** com propriedade passiva e ação de imunidade temporária de usos limitados, mas **não traz PA/ativação adicional** na ficha recuperada. Ausência não significa zero. A hipótese histórica de prêmio passivo não se torna taxa universal por esses casos; são necessários pares mecanicamente equivalentes por duração, cooldown, disponibilidade e condições.

## H3 — Potência, rank e efeito do usuário

O [Aprimoramento Vitalidade](https://app.notion.com/p/e56c2b324ede82a898bb8137c2d8d0f3) registra **+1 PV por nível de personagem, 8 PA/dia**, podendo acumular-se em aplicações distintas. Assim, em cenário hipotético de nível 1 versus 16, **o mesmo aprimoramento** entrega +1 versus +16 PV sem que a ficha altere seu PA/dia. Não mudar automaticamente o preço em PA pelo nível do usuário. O efeito inerente do item é uma **função de escalonamento**; a potência entregue depende do estado do portador.

[Armadura de Zephyr](https://app.notion.com/p/a23c2b324ede829bb8168165991577ff) entrega +11 CA, +15 DES, +15 m, +25 ataque e +50 dano de Vento por turno por **90 PA/dia já somados**. O registro não atribui valores independentes às cinco parcelas. **Custo total conhecido não identifica coeficiente de dano por ponto**, mesmo em um item fortemente ofensivo.

## H4 — +20 dano adicional

Mantém-se a equação da etapa anterior de dano efetivo incremental por acerto elegível: `Δ = max(0,d+20−RD)−max(0,d−RD)`, sujeita a regras competentes de ataque/defesa, resistência, críticos, área e repetições. Com `d=15`, `RD=25`, `p_acerto=0,6`: 1 aplicação→6 dano esperado marginal; ativação de duas aplicações→12; 3 ataques→18; 3 ataques com alvo elegível 50%→9; 3 ataques em dois alvos→36. **Nenhum deles é custo PA.** Para convertir, falta coeficiente `ρ` com modalidade própria. O motor retorna `PA=null` e fórmula condicional, não uma falsa faixa.

Não se deve obter tarifa de +20 a partir de +50 vento/turno da Zephyr: mecanismo diferente, com múltiplos bônus e total compartilhado.

## H5 — Defesa e mobilidade

[**Aprimoramento Mobilidade**](https://app.notion.com/p/383c2b324ede820ab38881abbe91ac60) documenta **+2 CA quando realizar ação de movimento, 7 PA/dia**. É um comparador histórico particularmente útil para **CA condicional**, razão bruta **3,5 PA/dia por ponto de CA condicional** na sua própria ficha. Não significa que qualquer CA custe 3,5.

[**Armadura Anã**](https://app.notion.com/p/5f7c2b324ede83de9c7a81fcb19b0195) oferece +2 CA, penalidade de -2 m e reação especial de redução de movimento forçado, **6 PA/dia**. Não é equivalente à Mobilidade, portanto a diferença de um PA/dia não isola preço da permanência.

[**Adamante**](https://app.notion.com/p/1d2c2b324ede8343be42810a0b54f1d2), 7 PA/dia, converte críticos recebidos em ataques normais. [**Marítima**](https://app.notion.com/p/be9c2b324ede83108c3d016dc6ffba91), 8 PA/dia, fornece deslocamento de natação e emergência à superfície. [**Mitral**](https://app.notion.com/p/16cc2b324ede831290f801af40e0e5bc), 8 PA/dia, elimina certos entraves e recupera até +3 m. Esses são comparadores para famílias específicas, não coeficientes gerais de CA/RD/RDM/movimento.

## Modelo R03 e validação

1. **HISTÓRICO:** custa exatamente o registrado e separa R-PA-DIA, múltiplas ativas, semântica de PA/dia e upgrades aplicáveis; nunca escreve de volta.
2. **ANALÍTICO:** identifica dimensões, condição do alvo, cenário de dano após RD e limites de identificabilidade; evita usar rank/MED como multiplicadores.
3. **PROPOSTA:** apenas taxas **explicitamente informadas como hipótese do interlocutor**, todas unidades relevantes conhecidas, sem sinergia não resolvida e sem duplicação de alias. Campos de taxa pendentes ⇒ total `null`.
4. **MÚLTIPLOS ITENS:** subtotal diário histórico sem concluir compromisso ou débito; usos por ID único de habilidade e total de ativações separado. Upgrade não pode entrar como equipamento independente; requer ligação ao item-base.
5. **R03 TEST:** 47 testes R01 + 48 R02 + 33 R03 = **128 regressões locais PASS**. Código da UI móvel validado sintaticamente em Node; auditoria estrutural local separada, não auditoria científica independente nem NAC-PASS.

**HOLDOUT:** nenhum modelo de custo energético novo possui erro de previsão validado fora de conjunto visto. Um LOO retrospectivo da mediana com 30 observações não substitui holdout congelado. O sistema **não está pronto para definir PA definitivo de receitas**.

## Quadro de decisões

| REGRA HISTÓRICA VERIFICADA | INFERÊNCIA EMPÍRICA | PROPOSTA DE REGRA | DECISÃO NECESSÁRIA DO MESTRE |
|---|---|---|---|
| R-PA-DIA e 30 custos diários observados | Dados misturam itens, upgrades e modalidades | Corpus por família/versão/linhagem e unidade | Nenhuma alteração na regra R-PA-DIA |
| Amplificador +3 = 15 PA/dia | 5 é um caso, incompatible com modelo aditivo sem desconto em dois itens | Família de modelos com interações e exceções explícitas | Resolver escopo de H1 só após comparar receitas/outros pares |
| 6 itens com diário e ativação, 2 com 2 ativas | PA de habilidade não é atributo simples do item | IDs de habilidade e contagem de usos por gatilho | Não fixar custo ativo desconhecido como 0 |
| Mobilidade +2 CA condicional =7 PA/dia | razão de 3,5 para um comparador específico | calibrar por modo, limite e família | Não generalizar para toda CA |
| Vitalidade +1PV/nível = 8 PA/dia | benefício escala com usuário sem alteração textual no custo | representar função de efeito e vínculo com usuário | Decidir quando a escala do usuário deve influenciar PA novo |
| Sistema de Magia define PA comprometido/livre | PA/dia não determina automaticamente tipo de cobrança | COMMIT/DEBIT/UNKNOWN sem efeito real | Esclarecer comprometimento/liberação/recuperação em itens ainda ambíguos |
| Regra do CRAFT HOLD | Calcular energia em TEST não libera receita | Contrato read-only `PA_TO_CRAFT_R03_TEST` | Auditoria, NAC-PASS, homologação e release legítimo |

**Estado honesto de conclusão:** etapa 3 consolidada como avaliador funcional; etapas de censo e modelagem avançaram, mas calibração universal, holdout e gates finais continuam pendentes por falta de observações suficientes e autorização normativa. Não há conclusão perfeita/homologada nesta entrega.
