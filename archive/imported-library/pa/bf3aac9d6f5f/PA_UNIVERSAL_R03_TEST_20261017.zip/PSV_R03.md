# PSV / HANDOFF — R03 · SISTEMA UNIVERSAL DE PA

**AS-OF:** 17/10/2026; 13 fichas adicionais individualmente recuperadas do Notion Mestre após R02.

**IDENTIDADE:** executor funcional da frente PA nesta conversa; COMESTRE-ID, INSTANCE-ID, Assignment, workstream próprios não confirmados. **AUTHORITY/WRITER:** ordem humana para pesquisa TEST, sem writer/lease/epoch de Notion/CRAFT, sem promoção Party ou produção.

**OPERATION:** dependência de CRAFT `OP-ARQ-RIN-REC-01`; não se cria OP concorrente ou se herda o seu writer. **BASELINE:** R01 (61 fichas/47 testes), R02 (95 fichas/48 testes adicionais) preservadas, R-PA-DIA e PR-ECO/Atlas/Sistema Magia/DMG-RANK v1.1 inalterados.

**LAST-VERIFIED-UNIT:** R03 108 UUIDs /107 linhagens provisórias, 30 custos diários (27 explícitos/3 por R-PA-DIA), 9 itens com ativação e 11 custos de habilidade, 6 com diário+ativação; duas fichas multiativa; 10 aprimoramentos separados de equipamentos; calculadora HTML offline 108 fontes e 128 testes locais PASS.

**FIRST-PENDING:** fontes inéditas e comparadores de mesmo efeito com custos completos, semântica de cobrança e FIP por efeito, coeficientes calibrados e holdout prospectivo independente.

**NO-REPEAT:** motor `pa_engine.py` R01 e `pa_engine_v2.py` R02 reutilizados, sem refazer DMG, PR-ECO, VLAB nem implementar outro CRAFT.

**CORPUS:** 54 T01 +7 extras R01 +17 batalhas+9 encantamentos+8 matrizes R02 +3 equipamentos+10 aprimoramentos R03 =108 páginas. Global não delimitado; ocorrência mecânica atômica não contada. 78 páginas sem PA diário numérico reconhecido. Não imputar zero; 107 clusters são provisórios, não 107 itens estatisticamente independentes calibráveis.

**H1:** exemplo puro 5 PA/atributo e dois casos de tensão contra tarifa linear/aditiva não negativa (SAB +10/20 PA e INT +10/30 PA), sem concluir lei.

**H2:** 6 híbridos, 2 itens com duas ativas, sem coeficiente de prêmio de passivo.

**H3:** efeito nominal de item separado de escalonamento do portador, caso Vitalidade +1 PV/nível por 8 PA/dia; sem multiplicador automático rank.

**H4:** +20 dano marginal pós-RD cinco cenários executados, sem taxa PA/dano verificável; Zephyr +50 vento/turno 90 PA/dia com outros bônus não isola taxa.

**OUTROS COEFICIENTES:** aprimoramento Mobilidade +2 CA condicional=7 PA/dia (razão 3,5 apenas naquele contexto); CA/RD/RDM/movimento, defesa/controle demais não identificados globalmente.

**MODELO:** vetor de custos por unidade temporal; somatórios históricos apenas para conhecidos; propostas com taxas explícitas, IDs para múltiplas habilidades e bloqueio de dupla contagem; orçamento COMMIT/DEBIT/UNKNOWN sem alegação de regra nova.

**CALCULADORA:** R03 funcional HISTÓRICO, ANÁLISE, PROPOSTA condicionada; 108 fontes no HTML autocontido para celular; 128 testes locais, auditorias estruturais e integridade do ZIP.

**HOLDOUT:** 0 previsões de coeficiente verificadas em amostra independente; LOO retrospectivo de mediana (30 custos) MAE 37,03 PA, NÃO é holdout. Conclusão estatística limitada.

**CONFLITOS:** interpretações R-PA-DIA vs custo isolado contextual; Sombra 7 PA/dia já somado; AMANTE 21 PA sem período; aprimoramento -16 PA da Lâmina Boreal sem período; dupla leitura textual IMPERIAL/Veste Dragão; PA comprometido vs débito; H1 universal vs dois outros itens.

**UNKNOWN-EFFECT:** ZERO mutações remotas desta instância com efeito desconhecido; histórico C19-021 CRAFT permanece fora de escopo.

**NAC-PASS:** testes locais PASS, NAC-PASS de norma/produção não executado/homologado; writer não demonstrado. **CRAFT permanece HOLD**, receitas novas não liberadas.

**NEXT-5:** 1. novos custos e pares independentes 2. governança semântica PA diária 3. Atlas por efeito com FIP canônico 4. ajuste e holdout prospectivo pré-registrado 5. auditoria normativo-científica, NAC-PASS e integração CRAFT autorizada.

**TARGET-REMAINDER:** critérios científicos e normativos completos sem denominador global fechado; NÃO DECLARAR 100%.
