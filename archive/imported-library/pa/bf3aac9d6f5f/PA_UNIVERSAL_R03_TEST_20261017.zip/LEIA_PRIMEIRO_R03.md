# CALCULADORA UNIVERSAL DE PA — R03 · TEST

**Este é o pacote MAIS RECENTE deste ciclo (17/10/2026), não homologado.**

O Executor continuou o mesmo motor R01 → R02 → R03 em vez de recomeçar. R03 tem **108 fichas reais distintas recuperadas do Notion Mestre** (54 T-01, 7 comparadores, 17 inscrições batalha, 9 inscrições encantamento, 8 matrizes, 3 equipamentos adicionais, 10 aprimoramentos); não é censo global completo. A ciência encontrou 30 páginas com PA/dia numérico e 11 habilidades com custo por ativação (9 páginas). Múltiplas ativas por um mesmo item agora são componentes independentes.

## Uso sem computador, diretamente pelo Mestre

- **Abra `CALCULADORA_MOBILE_OFFLINE.html` no celular** (arquivo HTML autocontido): busca as 108 fichas, seleciona equipamentos, permite informar número de ativações para habilidades com custos diferentes, mostra PA diário conhecido e incompleto, separa cenários de PA comprometido ou debitado, realiza proposta somente com taxas declaradas pelo usuário.
- Em conversa com o Comestre, peça: "Leia a Lâmina Aurora Boreal", "Quanto consome o Cajado Vórtex Sombrio usando 2 vezes Força Negra e 1 vez Gravidade?", "Analise +2 CA condicionados a movimento", "Calcule meu orçamento de PA em modo sem regra de cobrança". O Comestre pode consultar os resultados do corpus sem exigir instalação local.
- `R03` **não altera Notion/Party, não faz receitas, não libera CRAFT**. Qualquer número para efeito novo dependente de taxa não aprovada aparecerá como cenário condicional ou INDETERMINADO.

## Uso técnico em TEST

```bash
python pa_engine_v3.py census
python pa_engine_v3.py lookup 'Lâmina Aurora Boreal'
python pa_engine_v3.py lookup 'Mobilidade'
python pa_engine_v3.py craft 'Lâmina Aurora Boreal'
python pa_engine_v3.py h1
python pa_engine_v3.py damage20
python pa_engine_v3.py budget 'Lâmina Aurora Boreal' 'Arco Exterminador Elemental (L)'
python pa_engine_v3.py quote entrada_exemplo_armadura.json
python validate_baselines_v3.py
python -m unittest -q test_pa_engine.py test_pa_engine_v2.py test_pa_engine_v3.py
python auditor_v3.py
```

Para acionar múltiplas habilidades **sem confundir custos**:

```python
from pa_engine_v3 import budget
print(budget(['Lâmina Aurora Boreal'],300,0,'UNKNOWN',{
 'Lâmina Aurora Boreal#ACT_1':1, # Luz da Aurora: 6 PA
 'Lâmina Aurora Boreal#ACT_2':2  # Harmonia dos Elementos: 7 PA cada
}))
```

Retorna gasto de **20 PA pelos usos informados** separado de **95 PA/dia históricos**, sem somá-los sob unidade temporal indevida.

## Limitações e integridade

- **NÃO há coeficiente universal calibrado**: um exemplo puro suporta 5 PA/ponto de atributo, mas duas fontes desafiam seu uso como fórmula aditiva não negativa universal.
- Aprimoramentos **não podem ser equipados independentemente** no orçamento: devem ser aplicados a um item-base com reconciliação de bônus sobrepostos.
- `-16 PA` de um aprimoramento da Lâmina Aurora Boreal não é interpretado como desconto diário automático: contexto ainda insuficiente.
- Para o custo 7 PA/dia do Aprimoramento Mobilidade, o efeito +2 CA é **condicional ao movimento**; 3,5 PA/ponto CA **neste único exemplo** não é tarifa de CA universal.
- Vitalidade entrega +1 PV por nível por 8 PA/dia, evidenciando que o efeito pode escalar com nível do usuário sem automaticamente mudar o custo histórico.
- PA/dia **não está universalmente classificado** como PA comprometido ou débito diário, e falha por uso de item não herda automaticamente consequência de conjuração forçada.
- A validação técnica executou **128 testes locais** (47 R01 + 48 R02 + 33 R03) e verificações estruturais independentes do código, não NAC-PASS de homologação.
- Holdout independente de **previsão de coeficientes = 0**; o LOO retrospectivo da mediana não constitui generalização independente.

**Leia `RELATORIO_CIENTIFICO_R03.md` e `PSV_R03.md` antes de decidir regras.** `HISTORICO_R02` preserva documentação de estágio anterior; dados R01/R02 permanecem versionados separadamente.
