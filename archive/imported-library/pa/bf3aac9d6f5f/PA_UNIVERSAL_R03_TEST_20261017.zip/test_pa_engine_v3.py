import unittest
import pa_engine_v3 as m
class Censo(unittest.TestCase):
 def test_n108(self):self.assertEqual(m.census()['pages'],108)
 def test_uniq(self):self.assertEqual(m.census()['distinct_uuids'],108)
 def test_cluster(self):self.assertEqual(m.census()['lineage_clusters_provisional'],107)
 def test_13(self):self.assertEqual(m.census()['cohorts']['EXTRA_THREE_AND_UPGRADE_TEN'],13)
 def test_upgrade10(self):self.assertEqual(m.census()['upgrade_pages'],10)
 def test_daily30(self):self.assertEqual(m.census()['daily_numeric'],30)
 def test_daily_explicit27(self):self.assertEqual(m.census()['daily_explicit'],27)
 def test_daily_R3(self):self.assertEqual(m.census()['daily_R_PA_DIA'],3)
 def test_unknown78(self):self.assertEqual(m.census()['daily_missing_or_ambiguous'],78)
 def test_active_items9(self):self.assertEqual(m.census()['activation_item_records'],9)
 def test_active_abilities11(self):self.assertEqual(m.census()['activation_ability_costs'],11)
 def test_dual6(self):self.assertEqual(m.census()['daily_and_activation_items'],6)
class Activations(unittest.TestCase):
 def test_aurora_two(self):self.assertEqual([a['value'] for a in m.historical('Lâmina Aurora Boreal')['activation_abilities']],[6,7])
 def test_cajado_two(self):self.assertEqual([a['value'] for a in m.historical('CAJADO VÓRTEX SOMBRIO')['activation_abilities']],[6,14])
 def test_cost_separate(self):
  b=m.budget(['Lâmina Aurora Boreal'],300,0,uses={'Lâmina Aurora Boreal#ACT_1':1,'Lâmina Aurora Boreal#ACT_2':2})
  self.assertEqual(b['known_activation_subtotal_for_requested_uses'],20)
 def test_cost_separate_cajado(self):
  b=m.budget(['CAJADO VÓRTEX SOMBRIO'],300,0,uses={'CAJADO VÓRTEX SOMBRIO#ACT_1':2,'CAJADO VÓRTEX SOMBRIO#ACT_2':1})
  self.assertEqual(b['known_activation_subtotal_for_requested_uses'],26)
 def test_no_aggregate_multi(self):
  with self.assertRaises(ValueError):m.budget(['Lâmina Aurora Boreal'],300,0,uses={'Lâmina Aurora Boreal':1})
 def test_hypothesis_commit(self):self.assertEqual(m.budget(['Lâmina Aurora Boreal'],200,50,'COMMIT')['scenario_free_after_daily_commit'],55)
 def test_hypothesis_unknown(self):self.assertNotIn('scenario_free_after_daily_commit',m.budget(['Lâmina Aurora Boreal'],200,50))
 def test_no_overcount_zephyr(self):self.assertEqual(m.historical('Armadura de Zephyr (L)')['pa_daily']['value'],90)
 def test_aprimoramento_not_equipped(self):
  with self.assertRaises(ValueError):m.budget(['Mobilidade'],200)
 def test_upgrade_contract_hold(self):self.assertTrue(m.craft('Mobilidade')['requires_base_item_linkage'])
 def test_ambiguous_minus16(self):self.assertEqual(m.historical('Lâmina Aurora Boreal')['pa_daily']['value'],95)
 def test_mobility_daily7(self):self.assertEqual(m.historical('Mobilidade')['pa_daily']['value'],7)
 def test_critical_normal7(self):self.assertEqual(m.historical('Adamante')['pa_daily']['value'],7)
 def test_zero_not_assumed(self):self.assertIsNone(m.historical('Resistência')['pa_daily']['value'])
 def test_h1_preserved(self):self.assertEqual(m.h1()['pure_ratio'],5)
 def test_quote_absence_null(self):self.assertIsNone(m.quote_new({'effects':[{'id':'CA','kind':'ca','value':6,'modality':'passive'}]})['pa_day_estimate'])
 def test_historical_stays_readonly(self):self.assertEqual(m.historical('Arco Exterminador Elemental (L)')['pa_daily']['value'],64)
 def test_holdout_true_false(self):self.assertFalse(m.holdout()['independent_holdout'])
 def test_craft_multi(self):self.assertEqual(len(m.craft('CAJADO VÓRTEX SOMBRIO')['activation_abilities']),2)
 def test_invalid_negative_use(self):
  with self.assertRaises(ValueError):m.budget(['Lâmina Aurora Boreal'],300,uses={'Lâmina Aurora Boreal#ACT_1':-1})
 def test_bad_ability(self):
  with self.assertRaises(ValueError):m.budget(['Lâmina Aurora Boreal'],300,uses={'Lâmina Aurora Boreal#FICTICIO':1})

if __name__=='__main__':unittest.main()
