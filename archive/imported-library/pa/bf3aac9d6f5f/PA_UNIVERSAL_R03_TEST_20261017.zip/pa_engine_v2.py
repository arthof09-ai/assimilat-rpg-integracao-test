"""PA TEST R02: single lineage of the existing PA-R01 engine.
Always respects historical costs; confidence, uncertainty and unknown effects are explicit.
Sources: Notion Mestre 17-Oct-2026; speculative numerical forecasts require rates supplied by caller.
No Notion/Party/CRAFT production writes.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,math,statistics
from collections import Counter,defaultdict
from pathlib import Path
import pa_engine as r01
P=Path(__file__).resolve().parent
CORPUS=P/'corpus_pa_v2.json'

def records():
    return json.loads(CORPUS.read_text('utf8'))['items']

def get(identifier):
    q=r01._flat(str(identifier))
    match=[r for r in records() if q in (r01._flat(r['name']), r01._flat(r['item_id']),r01._flat(r['source_url']))]
    if len(match)!=1:raise ValueError(f'Item não unívoco: {identifier}, candidatos {len(match)}')
    return copy.deepcopy(match[0])

def historical(identifier):
    r=get(identifier)
    return {'mode':'HISTORICO','id':r['item_id'],'item':r['name'],'family':r['family'],'url':r['source_url'],'lineage_cluster':r['lineage_cluster'],'effect_summary':r['mechanics_summary'],'rank':r['rank_public'],'pa_daily':r['pa_daily'],'pa_activation':r['pa_activation'],'uncertainty':r['cost_unqualified'],'pa_semantics':r['pa_semantics'],'record_status':r['completeness'],'historical_preserved':True,'production_permission':False}

def census():
    rs=records();coh=defaultdict(Counter)
    for r in rs:
        c=coh[r['family']];c['pages']+=1;c['daily_'+r['pa_daily']['classification']]+=1
        c['activation_known']+=r['pa_activation']['value'] is not None
    known=[r['pa_daily']['value'] for r in rs if r['pa_daily']['classification']=='EXPLICITA']
    costs=[r['pa_daily']['value'] for r in rs if r['pa_daily']['value'] is not None]
    ret={'total_pages':len(rs),'different_uuids':len({r['item_id'] for r in rs}),
      'lineage_clusters_provisional':len({r['lineage_cluster'] for r in rs}),
      'cohorts':dict(Counter(r['cohort'] for r in rs)),
      'per_family':{k:dict(v) for k,v in coh.items()},
      'daily_explicit':len(known),'daily_by_R_PA_DIA':sum(r['pa_daily']['classification']=='REGRA_R_PA_DIA' for r in rs),
      'daily_with_numeric_value':len(costs),'daily_not_numerically_classified':len(rs)-len(costs),
      'activation_with_numeric_value':sum(r['pa_activation']['value'] is not None for r in rs),
      'daily_and_activation':sum(r['pa_daily']['value'] is not None and r['pa_activation']['value'] is not None for r in rs),
      'distinct_effects':'NAO_DETERMINADO: extração dos efeitos inicialmente resumida',
      'daily_explicit_median':statistics.median(known) if known else None,
      'canonical_global_population_denominator':'ABERTO',
      'no_zero_imputation':True,'source':'Notion Mestre; 54 T01 + 7 comparadores + 34 fichas de inscrições e matrizes'}
    return ret

def attribute_h1_audit():
    """Partial identification: nonnegative additive independent effects *if* assumed.
    NOT a proof that historical items were priced additively or on identical rules.
    """
    rows=[
     {'id':'3c6c2b324ede82baa4a801de533a5975','name':'Amplificador de Atributo','attribute_points':3,'attribute_type':'qualquer atributo','daily_pa':15,'other_effects':'nenhum outro benefício indicado','cost_provenance':'EXPLICITA','pure_effect':True},
     {'id':'3edc2b324ede815699adc0412e96ea2b','name':'Sabedoria Ancestral','attribute_points':10,'attribute_type':'SAB','daily_pa':20,'other_effects':'telepatia, memória e leitura','cost_provenance':'R_PA_DIA','pure_effect':False},
     {'id':'0c4c2b324ede83dd8e1881b52a79e326','name':'Amuleto de Inteligência','attribute_points':10,'attribute_type':'INT','daily_pa':30,'other_effects':'alternativa +20 dano mágico OU resistência mágica','cost_provenance':'R_PA_DIA','pure_effect':False},
     {'id':'3edc2b324ede810daba2cc509677856c','name':'Colar cadente','attribute_points':2,'attribute_type':'SAB diurna; +4 condicional','daily_pa':14,'other_effects':'bônus noturno variável','cost_provenance':'EXPLICITA','pure_effect':False},
     {'id':'3edc2b324ede81ab9e22e168f6d939a9','name':'Espada do Lendário','attribute_points':60,'attribute_type':'FOR','daily_pa':600,'other_effects':'dano intrínseco muito elevado e +75 ataque','cost_provenance':'EXPLICITA','pure_effect':False},
    ]
    for x in rows:
        x['naive_ratio_PA_per_point']=round(x['daily_pa']/x['attribute_points'],4)
        x['conditional_upper_bound_if_nonneggative_additive']=x['daily_pa']/x['attribute_points']
        x['required_discount_PA_if_5_per_point']=max(0,5*x['attribute_points']-x['daily_pa'])
        x['url']='https://app.notion.com/p/'+x['id']
    violations=[x for x in rows if x['required_discount_PA_if_5_per_point']>0]
    return {'excluded_due_unqualified_period':['AMANTE DAS SOMBRAS: 21 PA em bloco inicial; R01 classifica CUSTO_SEM_PERIODO, portanto NÃO entra nas observações PA/dia'], 'hypothesis':'H1 - tarifa universal de 5 PA/dia por ponto base','pure_points_observed':3,'pure_cost_observed':15,'pure_ratio':5,
      'records_tested':rows,'nonnegative_additive_model_compatible_with_uniform_5':len(violations)==0,
      'conditional_stress_violations':[{'item':x['name'],'daily_pa':x['daily_pa'],'minimum_rebate_if_all_attribute_points_cost_5':x['required_discount_PA_if_5_per_point']} for x in violations],
      'inference':'Se todos os pontos + efeitos tivessem parcelas independentes aditivas e não negativas, H1 universal =5 contradiz dois registros multifuncionais. Para conciliá-los, precisa descontos/sinergias, diferentes tabelas, contexto ou exceções; nada disso é canonizado.',
      'scientific_status':'H1 UM CASO PURO; HIPOTESE UNIVERSAL INCOMPATIVEL COM ADITIVIDADE NAO_NEGATIVA SIMPLES; CAUSA INDETERMINADA'}

def budget(item_ids, pa_total, committed_external=0, daily_semantics='UNKNOWN', uses=None):
    """No actual effect is applied. Periodic debit and commitment require separate, explicit scenario selection."""
    if daily_semantics not in ('UNKNOWN','COMMIT','DEBIT'):raise ValueError('Escolha UNKNOWN, COMMIT, DEBIT')
    if not isinstance(item_ids,list) or len(item_ids)!=len(set(item_ids)):raise ValueError('Item duplicado')
    if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0 for v in (pa_total,committed_external)) or committed_external>pa_total:raise ValueError('PA invalido')
    r=[historical(i) for i in item_ids]
    daily=sum(x['pa_daily']['value'] for x in r if x['pa_daily']['value'] is not None)
    daily_missing=[x['item'] for x in r if x['pa_daily']['value'] is None]
    free_pre=pa_total-committed_external
    raw_uses=uses or {}
    use_cost=0;missing_use_cost=[];use_breakdown=[]
    for i,count in raw_uses.items():
        if not isinstance(count,int) or isinstance(count,bool) or count<0:raise ValueError('Usos devem ser inteiros >=0')
        ritem=historical(i)
        if ritem['id'] not in {x['id'] for x in r}:raise ValueError('Uso de item nao equipado')
        a=ritem['pa_activation']['value']
        if a is None:
            if count:missing_use_cost.append(ritem['item'])
        else:
            use_cost+=a*count
            use_breakdown.append({'item':ritem['item'],'uses':count,'cost_per_use':a,'total':count*a})
    out={'mode':'CENARIO_SEM_ESCRITA','items':len(r),'known_daily_subtotal_pa_day':daily,'daily_total_pa_day':None if daily_missing else daily,
       'missing_daily':daily_missing,'known_activation_subtotal_pa_per_set_of_uses':use_cost,
       'missing_activation':missing_use_cost,'activation_breakdown':use_breakdown,
       'pa_total':pa_total,'committed_external':committed_external,'pa_free_pre_item_accounting':free_pre,
       'semantics':daily_semantics,'semantics_historical':'PA/dia das fichas nao identificado necessariamente como COMMIT ou DEBIT',
       'no_cast_exhaustion_generalization':True,'historical_unchanged':True}
    if daily_semantics=='COMMIT' and not daily_missing:
        out['scenario_free_after_commitment']=free_pre-daily if daily<=free_pre else None
        out['can_reserve_all_in_scenario']=daily<=free_pre
        out['activation_sufficiency_under_scenario']=(out['scenario_free_after_commitment'] is not None and use_cost<=out['scenario_free_after_commitment'] and not missing_use_cost)
    elif daily_semantics=='DEBIT' and not daily_missing:
        out['scenario_pa_current_if_debited_from_full_total']=pa_total-daily if daily<=pa_total else None
        out['scenario_budget_after_daily_and_uses']=pa_total-daily-use_cost if daily+use_cost<=pa_total and not missing_use_cost else None
        out['warning_current_total_assumption']='Calcular saldo apos debito requer PA atual e regras de recuperação; usar PA Total no exemplo e somente uma hipótese.'
    elif daily_semantics=='UNKNOWN':out['scenario_totals']='PENDENTE_ESCOLHA_DE_REGRA; nao somar/deduzir'
    return out

def _positive_num(x,label):
    if not isinstance(x,(int,float)) or isinstance(x,bool) or not math.isfinite(x) or x<0:raise ValueError(label)
    return x

def incremental_damage_20(*,base=15,rd=25,hit=0.6,attempts=3,eligibility=0.5,targets=2):
    for n,v in [('base',base),('rd',rd),('hit',hit),('attempts',attempts),('eligibility',eligibility),('targets',targets)]:_positive_num(v,n)
    if hit>1 or eligibility>1:raise ValueError('probabilidades de 0 a 1')
    contexts=[('UMA_VEZ_POR_DIA',1,1,1),('ATIVACAO_DUAS_APLICACOES',2,1,1),('TODOS_TRES_ATAQUES',attempts,1,1),('ALVO_CONDICIONAL',attempts,eligibility,1),('AREA_DOIS_ALVOS',attempts,1,targets)]
    data=[]
    for tag,attempt_count,pr,n_target in contexts:
        d=r01.damage_delta(base,20,rd,attempt_count,hit,n_target,pr)
        data.append({'scenario':tag,'expected_extra_damage_after_RD':d['hypothetical_expected_marginal_damage'],
          'per_hit_marginal_after_RD':d['marginal_post_rd_per_eligible_hit'],'pa_daily':None,'pa_activation':None,
          'equation_PA_if_rate_per_expected_marginal_damage_were_hypothetically_supplied':f'{d["hypothetical_expected_marginal_damage"]} × rho_PA_por_dano_marginal_esperado',
          'status':'DANO_CALCULAVEL_PA_NAO_IDENTIFICADO','assumptions':{'base_damage':base,'RD':rd,'p_hit':hit,'eligible_attacks':attempt_count,'targets':n_target,'eligible_condition_probability':pr}})
    return {'status':'CONTRAFATUAL_NAO_HOMOLOGADO','historical_pa_rates_calibrated':False,'outcomes':data,
       'important':'RD aplica-se ao dano efetivo em cada acerto; contas hipotéticas de 0..1 probabilidade, não extração de chance real; equipamento fornece bonus e não dano-base.'}

def quote_new(item, rates=None, *, rate_author='SCENARIO_USUARIO', allow_proposed_interaction=False):
    """A mathematically complete conditional estimate requires every effect's rate and every interaction's decision.
    Interaction shared parent can mean duplicate, not added; independent effects remain additive only as proposal.
    Uses R01 predict_new to preserve one engine and prior regressions.
    """
    if not isinstance(item,dict):raise ValueError('item deve ser JSON')
    effects=item.get('effects',[]);seen=set();canonical=[];duplicates=[]
    for e in effects:
        x=dict(e);code=x.get('id');effect_key=x.get('same_mechanical_effect_as',code)
        if not code or not isinstance(effect_key,str):raise ValueError('effect ID necessario')
        if effect_key in seen:
            duplicates.append({'id':code,'duplicate_of':effect_key});continue
        seen.add(effect_key);canonical.append(x)
    # Every shared bonus in alias group counted once; genuine synergies remain UNKNOWN absent cited rule.
    normalized={**item,'effects':canonical}
    out=r01.predict_new(normalized,mode='PROPOSTA' if rates else 'ANALITICO',rates=rates or {})
    out['duplicate_effect_groups_ignored']=duplicates
    out['rate_author']=rate_author if rates else None
    out['rate_validated_by_independent_holdout']=False
    out['synergies_evaluated']=False
    out['synergy_unknown']=any(e.get('synergy_candidate') for e in canonical)
    if out['synergy_unknown'] and not allow_proposed_interaction:
        out['pa_day_estimate']=None;out['pa_activation_estimate']=None
        out['status']='TOTAL_HOLD_INTERACAO_NAO_IDENTIFICADA'
    out['rule_status']='PROPOSTA_NAO_CANONICA' if rates else 'ANALITICO'
    out['double_count_avoidance']='Aliased same_mechanical_effect_as shares a single effect group'
    out['no_historical_overwrite']=True
    return out

def diagnose_holdout():
    rows=records();group={}
    for r in rows:
        g=r['lineage_cluster'];group[g]='reserved_retrospective' if int(hashlib.sha256(g.encode()).hexdigest()[:8],16)%5==0 else 'development_exploration'
    return {'pages_total':len(rows),'groups_total':len(group),'retrospective_reserved_groups':sum(v=='reserved_retrospective' for v in group.values()),
     'retrospective_reserve_independence':False,'pre_registered_genuine_holdout_n':0,'generalization_error':None,
     'restriction':'Não afirmar validação independente; todos os custos do corpus já foram vistos antes do freeze de coeficientes',
     'prospective_freeze_needed':'Snapshot de coeficientes, pré-seleção de novas identidades/linhagens não lidas, métricas MAE e cobertura por família, sem usar treino na avaliação'}

def contract_craft(identifier):
    r=historical(identifier)
    return {'contract':'PA_TO_CRAFT_V2_TEST','schema_version':'2.0','item_id':r['id'],'source':r['url'],
        'historical':{'daily':r['pa_daily'],'activation':r['pa_activation'],'raw_unqualified':r['uncertainty']},
        'analytic':{'effects_summary':r['effect_summary'],'power_rank':r['rank'],'coefficients_calibrated':False,'pending':'unrecorded charges, duration, PA/day accounting'},
        'proposal':None,'pa_accounting':r['pa_semantics'],'overwrite':False,'production_hold':True,'recipe_creation_authority':False}

def cli():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['census','lookup','h1','damage20','holdout','craft','budget','quote']);p.add_argument('args',nargs='*');a=p.parse_args()
    if a.mode=='census':v=census()
    elif a.mode=='lookup':v=historical(' '.join(a.args))
    elif a.mode=='h1':v=attribute_h1_audit()
    elif a.mode=='damage20':v=incremental_damage_20()
    elif a.mode=='holdout':v=diagnose_holdout()
    elif a.mode=='craft':v=contract_craft(' '.join(a.args))
    elif a.mode=='budget':v=budget(a.args,300,80)
    else:
        inp=json.loads(Path(a.args[0]).read_text('utf8'))
        v=quote_new(inp['item'],inp.get('rates'))
    print(json.dumps(v,ensure_ascii=False,indent=2))
if __name__=='__main__':cli()
