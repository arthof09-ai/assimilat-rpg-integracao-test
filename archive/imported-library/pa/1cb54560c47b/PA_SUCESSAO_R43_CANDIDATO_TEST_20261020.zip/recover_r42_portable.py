"""Reexecuta o R42 autentico recuperando fixture R21 de R23 sem inventar dados.

Nao modifica artefatos historicos; so extrai pacote em diretório efemero e cria
fixture compat no endereco absoluto ja exigido pela suite antiga. Fail closed se
um arquivo preexistente nao corresponder aos bytes do R23 aninhado.
"""
import argparse,hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path
EXPECTED_R42='6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800'
EXPECTED_R21='e70cb8774e0a5e4ba8704c4007c660363b3860222cc01febb9a83b0290315532'
R21_ABSOLUTE=Path('/mnt/data/pa_r21_work/ATIVACOES_HISTORICAS_R21.csv')
R23_REL=Path('parents/engine_r26/baseline_r25/BASELINE_R23_IMUTAVEL.zip')
R21_MEMBER='compat_r21/ATIVACOES_HISTORICAS_R21.csv'

def sha(b):return hashlib.sha256(b).hexdigest()
def safe_extract(z:zipfile.ZipFile,target:Path):
    target=target.resolve()
    for name in z.namelist():
        p=(target/name).resolve()
        if not p.is_relative_to(target):raise ValueError('UNSAFE_ZIP_PATH')
    z.extractall(target)

def run(pack:Path):
    if sha(pack.read_bytes())!=EXPECTED_R42:raise ValueError('R42_HASH_MISMATCH')
    with tempfile.TemporaryDirectory(prefix='pa_r42_cold_r43_') as td:
        target=Path(td)
        with zipfile.ZipFile(pack) as z:
            if z.testzip() is not None:raise ValueError('R42_ZIP_CRC')
            safe_extract(z,target)
        with zipfile.ZipFile(target/R23_REL) as z23:
            if z23.testzip() is not None:raise ValueError('R23_ZIP_CRC')
            r21=z23.read(R21_MEMBER)
        if sha(r21)!=EXPECTED_R21:raise ValueError('R21_HISTORICAL_FIXTURE_SHA')
        created=False
        if R21_ABSOLUTE.exists():
            if sha(R21_ABSOLUTE.read_bytes())!=EXPECTED_R21:
                raise ValueError('ABSOLUTE_R21_PATH_CONFLICT_NO_OVERWRITE')
        else:
            R21_ABSOLUTE.parent.mkdir(parents=True,exist_ok=True)
            R21_ABSOLUTE.write_bytes(r21);created=True
        try:
            p=subprocess.run([sys.executable,'RUN_R42_COLD.py'],cwd=target,text=True,capture_output=True)
            if p.returncode:raise RuntimeError('COLD_REPLAY_FAIL '+p.stdout[-2000:]+' '+p.stderr[-3000:])
            result=json.loads(p.stdout[p.stdout.find('{'):p.stdout.rfind('}')+1])
            if result['total_distinct_tests']!=563 or result['status']!='PASS_R42_COLD_TEST':raise RuntimeError('R42_TEST_COUNT')
            result['compatibility_r21_fixture_sha256']=EXPECTED_R21
            result['compatibility_r21_created_by_r43']=created
            result['compatibility_r21_origin']=f'{R23_REL}:{R21_MEMBER}'
            result['r42_source_sha256']=EXPECTED_R42
            return result
        finally:
            if created and R21_ABSOLUTE.exists() and sha(R21_ABSOLUTE.read_bytes())==EXPECTED_R21:
                R21_ABSOLUTE.unlink()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('r42_zip',type=Path);a=ap.parse_args()
    print(json.dumps(run(a.r42_zip),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
