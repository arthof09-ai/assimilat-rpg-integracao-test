"""PA pós-R42: parecer de incidência A/B/C, SEM cálculo concorrente de PA.

Use como envelope de consulta, nunca como regra canônica, writer ou autorização de fabricação.
"""
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass(frozen=True)
class Incidence:
    mechanism: str
    installed: bool
    own_item_ability_demonstrated: bool
    observed_effect_provenance: str
    debtor: Optional[str]
    pa_per_day: Optional[int]
    pa_per_activation: Optional[int]
    pa_installation: Optional[int]
    pa_maintenance: Optional[int]
    prospective_e3_per_day: Optional[int]
    prospective_e3_per_activation: Optional[int]
    prospective_e3_two_uses: Optional[int]
    status: str
    authority_action: str
    document_source: str

NOTION_IBX118 = 'https://app.notion.com/p/3ffc2b324ede8119beb8c7c6d1d50bfe'
SOURCES = {
  'herb': 'https://app.notion.com/p/3edc2b324ede81deb8cec70bf5ca7150',
  'crystal': 'https://app.notion.com/p/3edc2b324ede818b9d7ad75d42f2afa2',
  'enchantment': 'https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6',
  'p2': 'https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8',
  'lab': 'https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00'
}

def qualify(mechanism: str) -> Incidence:
    """Never charges based on source magic, inscription *plans*, or estimated effects."""
    if mechanism == 'A_H1_INTRINSIC_SOURCE':
        return Incidence(
            mechanism,False,False,'MESTRE_H1_TEST_QUALITATIVE',
            None,None,None,None,None,None,None,None,
            'HOLD_ENERGY_RULE_NOT_IDENTIFIED',
            'Identificar norma para incidencia em suporte sem habilidade propria; NULL nao significa 0.',
            SOURCES['herb']+' ; '+SOURCES['crystal']+' ; '+SOURCES['lab'])
    if mechanism == 'B_H2_P2_SEAL':
        return Incidence(
            mechanism,False,False,'P2_SOURCE_TEXT_ONLY; INSTALLATION_NOT_OBSERVED',
            None,None,None,None,None,None,None,None,
            'HOLD_INSTALLATION_AND_ENERGY_RULE',
            'Separar custos de materiais/energia do procedimento de debito de PA; P2/oleo possuem inconsistencias de BOM-processo.',
            SOURCES['p2']+' ; '+SOURCES['enchantment'])
    if mechanism == 'C_H2_OWN_INSTALLED_ABILITY':
        return Incidence(
            mechanism,False,False,'NOT_DEMONSTRATED; ONLY_PRIOR_E3_DESIGN',
            None,None,None,None,None,12,7,26,
            'HOLD_NOT_INSTALLED_PROSPECTIVE_E3_ONLY',
            'Nao aplicar proposta 12 PA/dia +7/ativacao ao H1, nem cobrar antes de demonstrar instalacao e confirmar RI/RE.',
            SOURCES['enchantment']+' ; '+SOURCES['lab'])
    raise ValueError('UNKNOWN_MECHANISM_FAIL_CLOSED')

def public_receipt() -> dict:
    cases=[asdict(qualify(x)) for x in ('A_H1_INTRINSIC_SOURCE','B_H2_P2_SEAL','C_H2_OWN_INSTALLED_ABILITY')]
    return {
      'protocol':'PA-CRAFT-H1-H2-INCIDENCIA-20261020-001 — PARECER TECNICO TEST, NAO DECISAO CANONICA',
      'source_ibx':NOTION_IBX118,
      'identity':'PA_FUNCTIONAL_SUCCESSOR_NO_CRAFT_WRITER',
      'canonical_changes':0,'party_writes':0,'o_primeiro_writes':0,
      'status':'HOLD_NORMATIVE_INCIDENT_PROD','cases':cases,
      'interpretation':'Cenario C e somente orcamento E3 de projeto de item com poderes proprios. A/B sem taxa comprovada; todo custo efetivo NULL.',
      'responsible':'Mestre/autoridade normativa PA para lacuna de incidencia; executor CRAFT para ensaios H2 materiais, sem equiparar contextos.'
    }
