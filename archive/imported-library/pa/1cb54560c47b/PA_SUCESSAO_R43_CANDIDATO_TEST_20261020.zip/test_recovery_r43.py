import unittest,io,zipfile,tempfile
from pathlib import Path
from recover_r42_portable import sha,safe_extract,EXPECTED_R21,EXPECTED_R42
class RecoveryTests(unittest.TestCase):
    def test_expected_full_hash_len(self):self.assertEqual(len(EXPECTED_R42),64)
    def test_expected_r21_hash_len(self):self.assertEqual(len(EXPECTED_R21),64)
    def test_safe_extraction_allows_regular_member(self):
        with tempfile.TemporaryDirectory() as p:
            zbuf=io.BytesIO()
            with zipfile.ZipFile(zbuf,'w') as z:z.writestr('safe/f.txt','abc')
            with zipfile.ZipFile(io.BytesIO(zbuf.getvalue())) as z:safe_extract(z,Path(p))
            self.assertEqual((Path(p)/'safe/f.txt').read_text(),'abc')
    def test_safe_extraction_blocks_traversal(self):
        with tempfile.TemporaryDirectory() as p:
            zbuf=io.BytesIO()
            with zipfile.ZipFile(zbuf,'w') as z:z.writestr('../unsafe.txt','abc')
            with zipfile.ZipFile(io.BytesIO(zbuf.getvalue())) as z:
                with self.assertRaisesRegex(ValueError,'UNSAFE_ZIP_PATH'):safe_extract(z,Path(p))
    def test_hash_changes_if_bytes_modified(self):self.assertNotEqual(sha(b'a'),sha(b'b'))
if __name__=='__main__':unittest.main(verbosity=2)
