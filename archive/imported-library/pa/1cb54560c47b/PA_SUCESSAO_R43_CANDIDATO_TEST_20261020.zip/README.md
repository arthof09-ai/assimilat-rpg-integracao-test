# R43 CANDIDATO / TEST — sucessão do sistema PA

Não é R43 canônica reservada, nem entrega PROD. Recuperação de 20/10/2026 em MESTRE-SIDE.

A R42 foi materializada da Biblioteca do Mestre sem mudança, pacote SHA-256 6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800, e os 284 arquivos do manifesto/563 testes foram novamente comprovados em replay frio.

**Portabilidade descoberta:** o teste R22 embutido em R39 dependia de `/mnt/data/pa_r21_work/ATIVACOES_HISTORICAS_R21.csv`, ausente numa sessão nova. O CSV histórico de 16 entradas foi recuperado byte a byte do ZIP `BASELINE_R23_IMUTAVEL.zip`, membro `compat_r21/ATIVACOES_HISTORICAS_R21.csv`, SHA e70cb8774e0a5e4ba8704c4007c660363b3860222cc01febb9a83b0290315532. A dependência restaurada levou o replay integral R42 a PASS. O motor R26/R27 permaneceu intacto. Para sucessão futura, usar script de reconstituição dessa dependência a partir do pacote original, sem inventar fixtures.

**Mídias:** 26/26 técnicas classificadas têm 1 referência de mídia cada e seus URLs assinados foram resolvidos na consulta Notion Mestre. 27/28 fichas da coleção possuem mídia (uma das duas Sem classificação não contém bloco de imagem). Não foram recebidos bytes no container: egress HTTPS indisponível neste ambiente; não há visualização validada, hash da mídia, transcrição nem previsão verdadeiramente cega. Acúria das 26 = NULL, n=0. Não pontuar os 12 padrões R42 como se fossem as 26 técnicas.

**IBX-118:** matriz A/B/C em `PARECER_IBX118.json`; H1 preserva propriedade intrínseca em TEST mas não prova habilidade própria de suporte. B = inscrição P2 ainda não instalada. C = habilidades próprias E3 não instaladas. Custos efetivos A/B/C NULL; 12/dia+7/uso+26 com dois usos apenas orçamento E3 de C. Parecer preparatório, não ACK, decisão canônica, nem patch.

Comandos locais: `python -m unittest test_incidence_r43.py -v`; `python build_artifact_r43.py` apenas em diretório de preparação, se houver. Não inserir dados no Notion ou Party pelo script.

FIRST-PENDING: extração binária validada de pelo menos uma mecânica; avaliação cega antes da abertura de gabarito; decisão de autoridade sobre incidência A/B/C; manutenção do HOLD F5/C19.
