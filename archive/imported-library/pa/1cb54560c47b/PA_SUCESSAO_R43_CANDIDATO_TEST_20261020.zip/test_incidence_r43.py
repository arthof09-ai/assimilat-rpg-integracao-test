import unittest
from incidence_r43 import qualify,public_receipt

class R43Tests(unittest.TestCase):
    def test_three_separate_mechanisms(self):
        x=public_receipt()['cases'];self.assertEqual(len(x),3);self.assertEqual(len({i['mechanism'] for i in x}),3)
    def test_a_null_pa_is_not_zero(self):
        a=qualify('A_H1_INTRINSIC_SOURCE');self.assertIsNone(a.pa_per_day);self.assertIsNone(a.pa_per_activation)
    def test_a_not_installed(self):
        a=qualify('A_H1_INTRINSIC_SOURCE');self.assertFalse(a.installed);self.assertFalse(a.own_item_ability_demonstrated)
    def test_a_has_mestre_h1_provenance(self):self.assertIn('MESTRE_H1',qualify('A_H1_INTRINSIC_SOURCE').observed_effect_provenance)
    def test_b_prevents_transfer_assumption(self):self.assertFalse(qualify('B_H2_P2_SEAL').installed)
    def test_b_no_installation_fee_inferred(self):self.assertIsNone(qualify('B_H2_P2_SEAL').pa_installation)
    def test_b_no_maintenance_fee_inferred(self):self.assertIsNone(qualify('B_H2_P2_SEAL').pa_maintenance)
    def test_c_prospect_only(self):
        c=qualify('C_H2_OWN_INSTALLED_ABILITY');self.assertEqual((c.prospective_e3_per_day,c.prospective_e3_per_activation,c.prospective_e3_two_uses),(12,7,26));self.assertIsNone(c.pa_per_day)
    def test_c_not_installed(self):self.assertFalse(qualify('C_H2_OWN_INSTALLED_ABILITY').installed)
    def test_c_no_past_charge(self):self.assertIsNone(qualify('C_H2_OWN_INSTALLED_ABILITY').pa_per_activation)
    def test_no_debtor_invented(self):
        for c in public_receipt()['cases']:self.assertIsNone(c['debtor'])
    def test_all_actual_pa_unknown(self):
        for c in public_receipt()['cases']:
            for key in ['pa_per_day','pa_per_activation','pa_installation','pa_maintenance']:
                self.assertIsNone(c[key],(c['mechanism'],key))
    def test_no_writes(self):
        x=public_receipt();self.assertEqual((x['canonical_changes'],x['party_writes'],x['o_primeiro_writes']),(0,0,0))
    def test_unknown_mechanism_fails(self):
        with self.assertRaisesRegex(ValueError,'FAIL_CLOSED'):qualify('D_FREE_MAGIC')
    def test_rin_not_used_as_re(self):self.assertNotIn('RIn=RE',repr(public_receipt()))
    def test_source_nonempty(self):
        for c in public_receipt()['cases']:self.assertTrue(c['document_source'].startswith('https://app.notion.com/p/'))
    def test_status_hold(self):self.assertTrue(all('HOLD' in c['status'] for c in public_receipt()['cases']))
    def test_h1_not_charged_from_c(self):
        self.assertIsNone(qualify('A_H1_INTRINSIC_SOURCE').prospective_e3_per_day)
        self.assertEqual(qualify('C_H2_OWN_INSTALLED_ABILITY').prospective_e3_per_day,12)
if __name__=='__main__':unittest.main(verbosity=2)
