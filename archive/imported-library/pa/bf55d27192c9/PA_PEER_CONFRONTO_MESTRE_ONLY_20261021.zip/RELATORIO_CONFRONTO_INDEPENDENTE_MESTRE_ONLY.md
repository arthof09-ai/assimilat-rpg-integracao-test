# PA / Assimilação — confronto controlado entre R45 congelada e parecer externo relatado

**Data:** 21/10/2026. **Público:** Mestre-only. **Estado:** comparação parcial verificável; nenhum RE foi canonizado.

## Evidência de origem

- **R45 realmente recuperada:** PA_IMG26_ATLAS_CRAFT_R45_MESTRE_ONLY_TEST_20261021.zip; `FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json` SHA-256 `2f1e88e3c7980cf376ed2ec76816dec48d3f4779bec55a9f6e3bf5687e799a5e` confere com arquivo de hash armazenado. 26/26 entradas originais; 12 IDs reconciliados com a auditoria R46.
- **Peer:** tabela e declaração copiadas da mensagem do Mestre. O arquivo ZIP independente, seu CSV, relatório e hashes individuais **não foram anexados neste turno**. SHA-256 final informado pelo segundo Comestre: `d5fa1054b6e296d893e182a735efb24f2053ffdf28bbcecae7da552318b93435`, **não verificado aqui**.
- **Independência:** o segundo Comestre declara ausência de acesso à R45/R46 e uma exposição conhecida pelo Atlas no caso TEC-E3532F6A98AC; a independência é **relatada**, não certificada por auditor externo nesta comparação.

## Comparação por caso

| Identificador | Técnica | R45 congelada | Faixa R45 | Peer relatado | Evidência peer | Situação |
|---|---|---|---|---|---|---|
| TEC-0E7493058FC8 | Falar com animais | Prata | Bronze–Prata | Prata | E3 | Igual |
| TEC-39F038CF281E | Imobilizar pessoa | Ouro | Prata–Ouro Negro | Ouro | E3 | Igual |
| TEC-3A1BC9C77ED8 | Destruição lancinante | Prata | Bronze–Prata | Prata | E3 | Igual |
| TEC-7F4A4B423743 | Repreensão Infernal | Bronze | Bronze–Prata | Prata | E2 | Peer 1 acima |
| TEC-9668762A6DAC | Enfeitiçar pessoa | Prata | Prata–Ouro | Prata | E3 | Igual |
| TEC-968D29765EB1 | Orbe cromática | Prata | Bronze–Prata | Bronze | E2 | Peer 1 abaixo |
| TEC-988589FB9716 | Servo invisível | Prata | Bronze–Prata | Prata | E3 | Igual |
| TEC-AC33D1C9DD16 | Vínculo com a besta | Prata | Bronze–Prata | Bronze | E2 | Peer 1 abaixo |
| TEC-C71526491A42 | Amizade animal | Prata | Bronze–Ouro | Prata | E3 | Igual |
| TEC-D9EF9388353A | Toque chocante | Prata | Bronze–Prata | Bronze | E2 | Peer 1 abaixo |
| TEC-E229A1361599 | Destruição trovejante | Prata | Bronze–Prata | Prata | E3 | Igual |
| TEC-E3532F6A98AC | Proteção contra lâminas | Prata | Bronze–Ouro | INSUFICIENTE | E3 | Exposto; abstenção |

## Estatística descritiva e interpretação

- **7/11 concordâncias exatas (63.6%)**, **4/11 divergências de um patamar**, nenhuma divergência superior.
- **11/11 classificações propostas pelo outro avaliador contidas nas faixas R45 previamente congeladas.** Faixas amplas reduzem a força probatória desse resultado.
- As quatro divergências envolvem pareceres peer E2; sete concordâncias peer E3. **E2 não garante correção**, e o próprio Atlas exige comparadores equivalentes e contexto.
- **Kappa de Cohen nominal ≈ 0.185**, limitado por amostra pequena, seleção enviesada de 12 outliers e concentração de previsões no rank Prata. Não declarar validação científica do motor nem precisão de rank.
- O rank histórico do Mestre não é gabarito absoluto, sobretudo porque os 12 casos foram escolhidos justamente por discordância prévia.

## Quatro divergências a adjudicar (sem escolher vencedor)

1. **Repreensão Infernal:** R45 Bronze / peer Prata. Comparar retaliação 2d10, condição de ter sofrido dano, custo de Reação, salvaguarda; efeito de ação pode justificar prêmio de poder.
2. **Orbe Cromática:** R45 Prata / peer Bronze. DME=13,5 em 3d8, escolha de tipo elemental, fraqueza e versatilidade; não contar seis danos simultâneos. Bandas de DMG não são classificador exclusivo.
3. **Vínculo com a Besta:** R45 Prata / peer Bronze. Telepatia somente com besta aliada, inteligência limitada, duração e alcance, sem dominação nem criar espírito; confrontar com fontes de família.
4. **Toque Chocante:** R45 Prata / peer Bronze. DME=4,5 em 1d8, mas remove a Reação adversária; estudar valor tático contra defender/esquivar/refletir conforme Sistema de Combate.

## Caso exposto

- **Proteção Contra Lâminas:** R45 Prata/faixa Bronze–Ouro e peer INSUFICIENTE por exposição conhecida. Não inserir no denominador 11 e não interpretar abstenção como discordância. O texto visual corrigido indica **1 AÇÃO** (não reação) na fonte importada. Necessária revisão sem exposição e conversão da defesa estrangeira.

## Próximos gates

1. **Receber ZIP independente exato**, conferir SHA-256 alegado, 9 entradas declaradas, 12 IDs/hashes e 21 verificações alegadas. Só então validar integridade e conteúdo; em caso de divergência, preservar parecer original e emitir errata separada.
2. Auditar os **quatro E2 discordantes** com três comparadores verdadeiramente distintos, fonte viva/família e a diferença entre dano, controle e ação; registro de evidência E0–E3.
3. Verificar criticamente o caso exposto via novo parecer cego, sem revelar R45 e o legado.
4. Somente após adjudicação, avaliar melhoria do classificador e regressões do custo PA R26/R27; não mudar motor nem fichas até autorização.
5. CRAFT P2/óleo/H2 continuam frente separada, sem efeito mágico material demonstrado e sem inferir PA zero.

**Gate NAC-PASS proporcional:** PASS confronto aritmético e SHA do congelamento R45; HOLD prova material do ZIP peer, adjudicação E0/E1 e qualquer promoção canônica.
