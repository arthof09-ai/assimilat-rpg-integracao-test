"""Cold integration regression orchestrator of already-existing TEST R64–R69 artifacts.
No PA/rank engine, no production, no authority or Notion access. Requires source ZIPs separately.
"""
from __future__ import annotations
import hashlib,zipfile,json,tempfile,subprocess,os,sys,re,shutil
from pathlib import Path

EXPECTED={
 64:('PA_R64_BLIND14_MASK_SEAL_HARDENING_MESTRE_ONLY_TEST_20261022.zip','3ef549e4d1ae457cc878b6010c8275810f70294f702b6817878d7d6a8ce5498a',38),
 65:('PA_R65_PEER_PINNED_READBACK_MESTRE_ONLY_TEST_20261022.zip','8d545f0fc0d8ed1b57fb4013974800f41fdc7415ad73175cb6a7f628b613e7f4',25),
 66:('PA_R66_CARTOES_MECANICOS_NEUTROS_MESTRE_ONLY_TEST_20261022.zip','ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9',25),
 67:('PA_R67_PEER_NEUTRAL_VERSION_SEAL_MESTRE_ONLY_TEST_20261022.zip','ab266ac446a43286e57cbc7daa0153dde0f4603f7cd381e26a1eb42eec671343',12),
 68:('PA_R68_ACTION_CONCENTRATION_FOREIGN_ADAPTER_HOLD_MESTRE_ONLY_TEST_20261022.zip','4ac7b7ef2fbdea2e2f232b4d5100d28e74a6051c78a441a2469c8a404c2055b9',20),
 69:('PA_R69_R45_R57_PROVENIENCIA_DISCORDANTE_MESTRE_ONLY_TEST_20261022.zip','a599fd7928284173c0e817b65e482f7850ee8de57881663e12fba8b6f20346bc',15),
}
MANIFEST_KEYS={64:'sha256',65:'files_sha256',66:'files',67:'files',68:'files',69:'files'}
PA_ROOT=Path('/mnt/data/pa_sucessao')

def sha(b:bytes):return hashlib.sha256(b).hexdigest()

def verify_archive(f:Path,num:int,expected_sha:str):
 if not f.is_file():raise RuntimeError(f'MISSING_SOURCE_{num}')
 if sha(f.read_bytes())!=expected_sha:raise RuntimeError(f'REPLAY_SOURCE_{num}_HASH_CHANGED')
 with zipfile.ZipFile(f) as z:
  if z.testzip() is not None:raise RuntimeError(f'R{num}_CRC_BAD')
  manifest_name=f'MANIFEST_R{num}.json';m=json.loads(z.read(manifest_name));members=set(z.namelist())
  dic=m[MANIFEST_KEYS[num]]
  if not isinstance(dic,dict) or not dic:raise RuntimeError(f'R{num}_INVALID_MANIFEST')
  for name,digest in dic.items():
   if name not in members or sha(z.read(name))!=digest:raise RuntimeError(f'R{num}_MANIFEST_FILE_MISMATCH:{name}')
 return {'archive_sha256':expected_sha,'manifest_members':len(dic),'zip_member_count':len(members)}

def replay(root:Path=PA_ROOT):
 paths={i:root/EXPECTED[i][0] for i in EXPECTED}
 meta={i:verify_archive(paths[i],i,EXPECTED[i][1]) for i in EXPECTED}
 # Exact hashed source chain for R69: no silent substitute for the older original artifacts.
 for key,pathname,digest in [
  ('R47',root/'sources/PA_R47_ROBUSTEZ_PA_CRAFT_MESTRE_ONLY_TEST_20261021.zip','ec59d0f7f5916b74cc9b673398a2c890f762824bd1936eaf495598e5ab79b510'),
  ('R53',root/'PA_R53_SUCESSAO_FRESCOR_13_FONTES_MESTRE_ONLY_TEST_20261022.zip','e0c5cb5fe0c7dad0a8d39bd0fe23bd199a9687ea48f097bf5a7ed6eab6705738'),
  ('R57',root/'PA_R57_DOSSIER_E0_AUTHORITY_MESTRE_ONLY_TEST_20261022.zip','bfba9afe9b0c6e02411c11abcaf6aec5c90b23a2d382e7656ce4edb6efa5b22e')]:
  if not pathname.is_file() or sha(pathname.read_bytes())!=digest:raise RuntimeError('ORIGINAL_'+key+'_MISSING_OR_CHANGED')
 suites=[]
 with tempfile.TemporaryDirectory(prefix='pa_r70_regression_') as td:
  base=Path(td)
  for i,f in paths.items():
   folder=base/f'r{i}';folder.mkdir()
   with zipfile.ZipFile(f) as z:z.extractall(folder)
  # R67 original tests expect extracted R66 peer asset, and the old R60 peer from R65.
  z66=base/'r66/PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip'
  z60=base/'r65/PA_R60_PEER14_CEGO_SEM_GABARITO_MESTRE_ONLY_TEST_20261022.zip'
  for n in range(64,70):
   env={**os.environ,
    'PA_R66_OUTER':str(paths[66]),
    'PA_R66_PEER':str(z66),
    'PA_R60_LEGACY':str(z60),
    'R66_TECHNICAL_ARCHIVE':str(paths[66]),
    'PA_SOURCE_ROOT':str(root)}
   script={64:'run_r64_cold.py',65:'run_r65_cold.py',66:'test_r66.py',67:'test_r67.py',68:'tests_r68.py',69:'test_r69.py'}[n]
   run=subprocess.run([sys.executable,script],cwd=base/f'r{n}',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=160)
   combined=run.stdout+'\n'+run.stderr
   expected=EXPECTED[n][2]
   if n in (64,65):
    if run.returncode:raise RuntimeError(f'R{n}_REPLAY_FAILED:'+combined[-500:])
    # prior runners test expected count internally and write JSON to stdout
    summary=json.loads(run.stdout.strip());
    if not summary['status'].startswith('PASS'):raise RuntimeError(f'R{n}_REPLAY_MISSTATUS')
   else:
    if run.returncode or re.search(r'Ran\s+'+str(expected)+r'\s+tests',combined) is None:raise RuntimeError(f'R{n}_REPLAY_FAILED:'+combined[-500:])
   suites.append({'R':n,'tests':expected,'result':'PASS_QA_TEST_ONLY','external_writes':0,
    'source_sha256':meta[n]['archive_sha256'],'manifest_files_checked':meta[n]['manifest_members']})
 results={'status':'PASS_R70_COLD_REPLAY_CROSS_SUITE_ONLY','total_runs':sum(a['tests'] for a in suites),
 'distinct_suites':len(suites),'no_combined_new_unit_engine':True,'suites':suites,
 'r45_vs_r57_unresolved':4,'foreign_bonus_techniques':4,'concentration_foreign_techniques':8,
 'independent_peer_reviews_received':0,'individual_RE_E0':0,'official_PA':None,'craft_production':'HOLD',
 'notion_write':False,'party_write':False,'o_primeiro_write':False,
 'notion_documentation_sync':'R64-R70 PENDING, NOTION WRITER SAFETY DENIED PREVIOUSLY'}
 return results

if __name__=='__main__':
 root=Path(sys.argv[1]) if len(sys.argv)>1 else PA_ROOT
 result=replay(root);print(json.dumps(result,ensure_ascii=False,indent=2))
