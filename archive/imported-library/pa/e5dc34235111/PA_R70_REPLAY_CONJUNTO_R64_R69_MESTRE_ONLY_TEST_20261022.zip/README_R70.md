# R70 — Replay frio das seis frentes anteriores (R64–R69)

**Objetivo:** evitar relatórios soltos e repetição manual no celular. Um único comando local com insumos anteriores já persistidos, sem criar um motor de PA/CRAFT paralelo.

`python run_r70.py /mnt/data/pa_sucessao`

Pré-requisito: ter os ZIPs R64–R69 e as fontes R47/R53/R57 nas mesmas posições. A execução primeiro compara SHA256 completos, CRCs e manifestos internos, extrai cada versão para um diretório temporário isolado, então executa os 6 testes originais em sequência. Para revalidar o próprio orquestrador: `python test_r70.py`.

A execução nesta rodada realizou **135/135 testes de suites existentes**: R64=38; R65=25; R66=25; R67=12; R68=20; R69=15. Não são 135 novos testes de R70. Testes próprios do orquestrador: 8. R70 preserva a denominação das suítes, executa readback local e produz JSON. Não há envio de revisão cega, homologação E0 nem custo PA novo.

Status científicos persistem: pacote cego não enviado; 0/14 pareceres; quatro propostas R45/R57 de atribuição divergente; quatro cartas com ação-bônus estrangeira; oito com (C) estrangeiro; rank RE individual 0 adjudicados; fabricação RC5 HOLD. Notion continua sincronizado somente até R63, porque a gravação do R64 foi rejeitada por mecanismo de segurança. Nunca usar o runner para simular writer, criar alternativa a um bloqueio ou mexer em Party/O Primeiro.
