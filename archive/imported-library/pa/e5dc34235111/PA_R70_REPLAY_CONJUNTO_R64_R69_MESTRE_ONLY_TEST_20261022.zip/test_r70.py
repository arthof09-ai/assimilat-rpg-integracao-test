import unittest,tempfile,zipfile,json,hashlib
from pathlib import Path
from run_r70 import verify_archive,EXPECTED,PA_ROOT,sha
class SourceGateTests(unittest.TestCase):
 def test_six_real_sources_verify(self):
  for n,(name,digest,_) in EXPECTED.items():self.assertTrue(verify_archive(PA_ROOT/name,n,digest)['manifest_members']>0)
 def test_source_missing(self):
  with self.assertRaisesRegex(RuntimeError,'MISSING_SOURCE'):verify_archive(Path('/not_real/test.zip'),64,'00')
 def test_source_tampered(self):
  with tempfile.TemporaryDirectory() as td:
   fake=Path(td)/'corrupt.zip';fake.write_bytes((PA_ROOT/EXPECTED[64][0]).read_bytes()+b'x')
   with self.assertRaisesRegex(RuntimeError,'HASH_CHANGED'):verify_archive(fake,64,EXPECTED[64][1])
 def test_wrong_source_rank(self):
  with self.assertRaisesRegex(RuntimeError,'HASH_CHANGED'):verify_archive(PA_ROOT/EXPECTED[69][0],68,EXPECTED[68][1])
 def test_corrupt_internal_file_detected_even_with_outer_hash_given(self):
  with tempfile.TemporaryDirectory() as td:
   src=PA_ROOT/EXPECTED[68][0];p=Path(td)/'changed.zip'
   with zipfile.ZipFile(src) as zi,zipfile.ZipFile(p,'w') as zo:
    for x in zi.infolist():
     v=zi.read(x.filename)
     if x.filename=='README_R68.md':v+=b'UNVERIFIED RANK: PRATA'
     zo.writestr(x.filename,v)
   with self.assertRaisesRegex(RuntimeError,'MANIFEST_FILE_MISMATCH'):verify_archive(p,68,sha(p.read_bytes()))
 def test_zip_unexpected_content_detects_pinned_sha(self):
  with tempfile.TemporaryDirectory() as td:
   fake=Path(td)/'not_source.zip';fake.write_bytes(b'not zip')
   with self.assertRaisesRegex(Exception,'HASH_CHANGED'):verify_archive(fake,65,EXPECTED[65][1])
 def test_exact_expected_count(self):self.assertEqual(sum(v[2] for v in EXPECTED.values()),135)
 def test_test_only_does_not_import_Notion(self):
  source=(Path(__file__).resolve().parent/'run_r70.py').read_text()
  self.assertNotIn('notion_update_page',source)
  self.assertNotIn('notion_create_page',source)
  self.assertNotIn('mcp__Notion__',source)
if __name__=='__main__':unittest.main(verbosity=2)
