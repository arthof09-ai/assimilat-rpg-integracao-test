import copy,json,tempfile,os,unittest
from pathlib import Path
from validate_r69 import check
ROOT=Path(os.environ.get('PA_SOURCE_ROOT','/mnt/data/pa_sucessao'))
R47=ROOT/'sources/PA_R47_ROBUSTEZ_PA_CRAFT_MESTRE_ONLY_TEST_20261021.zip'
R53=ROOT/'PA_R53_SUCESSAO_FRESCOR_13_FONTES_MESTRE_ONLY_TEST_20261022.zip'
R57=ROOT/'PA_R57_DOSSIER_E0_AUTHORITY_MESTRE_ONLY_TEST_20261022.zip'
DOC=Path(__file__).resolve().parent/'R69_R45_VS_R57_SOURCE_MISMATCH_MASTER_ONLY.json'
class Tests(unittest.TestCase):
 def setUp(self):self.d=json.loads(DOC.read_text())
 def gate(self,fun):
  d=copy.deepcopy(self.d);fun(d)
  with tempfile.TemporaryDirectory() as td:
   f=Path(td)/'tmp.json';f.write_text(json.dumps(d,ensure_ascii=False))
   return check(f,R47,R53,R57)
 def test_baseline(self):self.assertTrue(check(DOC,R47,R53,R57)['status'].startswith('PASS'))
 def test_four_different_ranks(self):self.assertEqual(sum(r['r45_r57_test_disagreement'] for r in self.d['records']),4)
 def test_20_source_text_files(self):self.assertEqual(len(self.d['r26_source_files_examined']),20)
 def test_no_E0(self):self.assertEqual(sum(r['official_effect_RE_E0'] is not None for r in self.d['records']),0)
 def test_forged_rank(self):self.assertIn('FAKE',self.gate(lambda d:d['records'][0].update(official_effect_RE_E0='Bronze'))['reason'])
 def test_forged_PA(self):self.assertIn('FAKE',self.gate(lambda d:d['records'][0].update(official_PA=8))['reason'])
 def test_change_R45(self):self.assertIn('PROVENANCE',self.gate(lambda d:d['records'][0].update(r45_scientific_proposal_TEST='Ouro'))['reason'])
 def test_change_R57(self):self.assertIn('PROVENANCE',self.gate(lambda d:d['records'][0].update(r57_said_R26_scientific_proposal_TEST='Ouro'))['reason'])
 def test_fake_R26(self):self.assertIn('R26',self.gate(lambda d:d['records'][0].update(r57_assertion_corrob_by_available_PA_R26_sources=True))['reason'])
 def test_nominal_is_NOT_RE(self):self.assertIn('RANK_LAYER',self.gate(lambda d:d['records'][0].update(historical_nominal_rank_is_not_effect_RE=False))['reason'])
 def test_missing_case(self):self.assertIn('COUNT',self.gate(lambda d:d['records'].pop())['reason'])
 def test_duplicate_case(self):self.assertIn('COUNT',self.gate(lambda d:d['records'][1].update(case_id=d['records'][0]['case_id']))['reason'])
 def test_bad_sourcefile_list(self):self.assertIn('R26_FILES',self.gate(lambda d:d.update(r26_source_files_examined=[]))['reason'])
 def test_fake_status(self):self.assertIn('STATUS',self.gate(lambda d:d['statuses'].update(r26_rank_attribution_validated=4))['reason'])
 def test_bad_notion_link(self):self.assertIn('NOTION',self.gate(lambda d:d['records'][0].update(notion_url='https://fake.local'))['reason'])
if __name__=='__main__':unittest.main(verbosity=2)
