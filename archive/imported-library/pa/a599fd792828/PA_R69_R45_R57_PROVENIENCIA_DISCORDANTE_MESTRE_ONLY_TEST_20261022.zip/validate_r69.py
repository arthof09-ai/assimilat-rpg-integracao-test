"""Non-promotional scientific source chain check of 4 disputed TEST effect proposals."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json
SHA={'r47':'ec59d0f7f5916b74cc9b673398a2c890f762824bd1936eaf495598e5ab79b510',
 'r53':'e0c5cb5fe0c7dad0a8d39bd0fe23bd199a9687ea48f097bf5a7ed6eab6705738',
 'r57':'bfba9afe9b0c6e02411c11abcaf6aec5c90b23a2d382e7656ce4edb6efa5b22e'}

def hold(x):return {'status':'HOLD_R69_SOURCE_PROVENANCE','reason':x,'official_pa':None,'e0':0,'Notion_writes':0,'Party_writes':0}

def check(dossier,r47,r53,r57):
 try:
  sources={'r47':Path(r47),'r53':Path(r53),'r57':Path(r57)}
  for n,p in sources.items():
   if hashlib.sha256(p.read_bytes()).hexdigest()!=SHA[n]:return hold('WRONG_SOURCE_ARCHIVE_'+n)
  d=json.loads(Path(dossier).read_text(encoding='utf8'))
  with ZipFile(r47) as z:
   raw=json.loads(z.read('input/REFERENCE_R45_INPUT/CORPUS_MECANICO_MANUAL_CEGO.json'))['cases']
   adaptation={x['case_id']:x for x in json.loads(z.read('input/R46_26_NATIVE_ADAPTATION_GATE.json'))}
  with ZipFile(r57) as z:doc={x['case_id']:x for x in json.loads(z.read('R57_ADJUDICATION_DOCKET.json'))['cases']}
  with ZipFile(r53) as z:
   texts=[n for n in z.namelist() if n.startswith('baseline_r26/') and not n.startswith('baseline_r26/baseline_r25/') and n.endswith(('.py','.md','.txt','.json','.csv','.log'))]
   source_texts={n:z.read(n).decode('utf8',errors='replace').casefold() for n in texts}
  if d.get('r26_source_files_examined')!=texts:return hold('R26_FILES_CHANGED')
  if d.get('statuses')!={'r45_r57_disagreements':4,'r26_rank_attribution_validated':0,'notion_page_readbacks':4,'effect_RE_E0':0,'official_PA':None,'party_no_write':True,'notion_no_write':True}:return hold('STATUS_FALSIFIED')
  c=d.get('records',[])
  if len(c)!=4 or len(set(r['case_id'] for r in c))!=4:return hold('WRONG_CASE_COUNT')
  raw={x['case_id']:x for x in raw}
  if {x['case_id'] for x in c}!=set(doc):return hold('CASE_ID_SOURCE_MISMATCH')
  for r in c:
   cid=r['case_id'];o=raw[cid];p=doc[cid];n=adaptation[cid]
   for key,a in [('r45_source_image_sha256',o['explicit_source_image_sha256']),('r45_scientific_proposal_TEST',o['rank_proposal_test_only']),('r45_candidate_range',o['candidate_range']),('r57_said_R26_scientific_proposal_TEST',p['native_R26_proposal_TEST_ONLY']),('r46_native_rank_gate',n['native_rank_gate'])]:
    if r.get(key)!=a:return hold('PROVENANCE_FIELD_CHANGED_'+key)
   if r.get('name_master_only')!=p['name']:return hold('NAME_CHANGED')
   if not r.get('r45_r57_test_disagreement') or o['rank_proposal_test_only']==p['native_R26_proposal_TEST_ONLY']:return hold('CONFLICT_MISLABELED')
   if any(r.get(key) is not None for key in ['r46_native_RE_adjudicated','r46_native_PA_cost','official_effect_RE_E0','official_PA']):return hold('FAKE_AUTHORITY_OR_PA')
   if r.get('r57_assertion_corrob_by_available_PA_R26_sources') is not False:return hold('FAKE_R26_PROVENANCE')
   if any(p['name'].casefold() in text for text in source_texts.values()):return hold('R26_HAS_EVIDENCE_REASSESS')
   if r.get('notion_url')!='https://app.notion.com/p/'+r['notion_uuid']:return hold('NOTION_URL_MISMATCH')
   if not r.get('historical_nominal_rank_is_not_effect_RE'):return hold('RANK_LAYER_MERGED')
  return {'status':'PASS_R69_SOURCE_DISCREPANCY_EVIDENCED_NOT_RESOLVED','discrepancies':4,'R26_pa_source_files_searched':len(texts),
       'no_matching_name_in_frozen_PA_R26':4,'historical_nominal_not_effect_RE':4,
       'E0_homologated':0,'official_PA':None,'Notion_writes':0,'Party_writes':0}
 except (OSError,KeyError,IndexError,TypeError,ValueError) as e:return hold('INVALID_'+type(e).__name__)
