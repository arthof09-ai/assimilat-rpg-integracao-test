import json, pathlib, hashlib, collections, statistics, zipfile
D=pathlib.Path('/mnt/data/PA_RANK_R06_DELIVERY')
J=json.loads((D/'CENSO_CLASSIFICACAO_PA_RANK.json').read_text());rows=J['rows'];daily=[r for r in rows if r['pa_dia_historico'] is not None]
S=json.loads((D/'RESUMO_PA_POR_RANK.json').read_text())['summary']
R=['Bronze','Prata','Ouro','Ouro Negro','Lendário','PENDENTE']
cohorts=[('CATALOGO_MESTRE_INDEXADO','Catálogo Mestre'),('PARTY_MESTRE_ESPELHO','Espelho Mestre da Party')]
A='''# Sistema Universal de PA — Classificação por rank e auditoria dos custos diários

**AS-OF:** 17/10/2026 · **Ambiente:** MESTRE-SIDE · **Operação:** continuidade da responsabilidade PA existente; não foi criado OP-ID. · **Baseline:** R01–R05 · **Produção e receitas:** HOLD.

## Determinações do Mestre (autoridade expressa, não regressão)

| Componente contínuo | Regra de manutenção |
|---|---:|
| +1 ponto de atributo | **5 PA/dia** |
| +1 ponto de dano **adicional** | **1 PA/dia** |
| +1 m de deslocamento **adicional** | **1 PA/dia** |
| +1 ponto de bônus em teste de ataque | **1 PA/dia** |
| +1 CA **produzida por magia** | **1 PA/dia** |

**Interpretação operacional declarada:** “1 teste de ataque” foi lido como **+1 de bônus em um teste de ataque**; não como uma cobrança por rolagem. Arma comum, armadura física, CA-base, dano-base, salvaguarda, Reflexo, RDM, RD, cura, controle, CD de magias, cargas, dados de dano variável, alcance e teleportes não receberam taxas fictícias. Custos por uso não foram convertidos em custos por dia.

## Escopo e cuidado com o denominador

- 108 UUIDs da R03 (88 catálogo Mestre, 18 Espelho, 2 semicanônicos), recuperados no pacote R05.
- 74 UUIDs da expansão R05 (55 Mestre fora do índice, 17 Espelho, 2 semicanônicos), com duplicação reconciliada.
- 52 UUIDs adicionais desta rodada (ampliação dirigida do Espelho), após deduplicação.
- **União: 234 UUIDs** = 143 catálogo Mestre + 87 Espelho + 4 semicanônicos.
- **94 fichas com valor fixo diário numérico:** 14 catálogo Mestre (12 explícitos + 2 R-PA-DIA); 80 Espelho (78 explícitos + 2 R-PA-DIA).
- 1 custo variável (10 PA/dia por anel), versões históricas alternativas e linhas sem unidade foram preservadas separadamente e não inflam o denominador.
- **Não é censo exaustivo de todo o Notion.** Itens no Espelho não são tratados como amostras independentes autorizadas do catálogo Mestre. Itens sem PA numérico não viram custo zero.

O Atlas Canônico ordena **classificar pela potência do efeito, sem ver preço/PA**, e distingue rank público de FIP interna. As propostas E3 não foram canonizadas e estão abertas a inspeção de imagem, comparação com sistema/personagem/efeito e fronteira de patamar. Zero estrelas de item foram inventadas.

## Distribuição histórica de PA/dia por rank

Os valores são **gastos históricos observados**, não coeficientes de PA calculados por rank. Os ranks E3 são uma alocação provisória, portanto todas as estatísticas abaixo são **exploratórias**.

### Catálogo Mestre — 14 UUIDs com PA/dia

| Rank documental ou técnico | N | Mediana PA/dia | Mín–máx PA/dia | E0 documental | E3 técnico |
|---|---:|---:|---:|---:|---:|
'''
for r in R:
 x=S['CATALOGO_MESTRE_INDEXADO']['por_rank'][r]
 fmt=lambda v:'—' if v is None else str(int(v)) if float(v).is_integer() else str(v).replace('.',',')
 A+=f"| {r} | {x['fichas_uuids']} | {fmt(x['mediana_PA_dia'])} | {fmt(x['min_PA_dia'])}–{fmt(x['max_PA_dia'])} | {x['N_rank_documental']} | {x['N_rank_analitico_nao_oficial']} |\n"
A+='''
Os únicos ranks documentais no subconjunto Mestre com PA/dia são **2 Ouro Negro** (Adaga Serpente 35, Armadura Guardiã Elemental 55) e **2 Lendário** (Arco Exterminador Elemental 64, Espada do Lendário 600). A Espada é um **outlier degradado**; portanto, 332 PA/dia (mediana Lendário de dois itens) **não é tarifa Lendária**, e a mediana Ouro Negro de 45 em dois itens também não é parâmetro universal. Não existem observações Mestre **Bronze** com PA/dia e rank documental nesta coorte.

### Espelho Mestre da Party — 80 UUIDs com PA/dia

| Rank documental ou técnico | N | Mediana PA/dia | Mín–máx PA/dia |
|---|---:|---:|---:|
'''
for r in R:
 x=S['PARTY_MESTRE_ESPELHO']['por_rank'][r]
 fmt=lambda v:'—' if v is None else str(int(v)) if float(v).is_integer() else str(v).replace('.',',')
 A+=f"| {r} | {x['fichas_uuids']} | {fmt(x['mediana_PA_dia'])} | {fmt(x['min_PA_dia'])}–{fmt(x['max_PA_dia'])} |\n"
A+='''
As **80 fichas do Espelho** incluem a Adaga Mortal Jaku com rank nominal Lendário explícito e outras **77 pré-classificações** E3, além de **2 pendências de rank**. Não representam uma amostra independente do catálogo Mestre; distribuições separadas por desenho.

## Divergências objetivas e parcialidades

| Item | Histórico | Parcela calculável pela nova regra | Diagnóstico |
|---|---:|---:|---|
| [Sabedoria Ancestral](https://app.notion.com/p/3edc2b324ede815699adc0412e96ea2b) | 20 PA (R-PA-DIA) | +10 SAB = **50 PA/dia** | Insuficiência ≥30 PA/dia só pelo atributo; comunicação e memória não tarifadas. |
| [Colar Cadente](https://app.notion.com/p/3edc2b324ede810daba2cc509677856c) | 14 PA/dia | +2 SAB =10, sob estrelas +4 SAB =**20** | Conflito de 6 PA no modo estelar, se bônus total =+4. |
| [Amuleto de Inteligência — Espelho](https://app.notion.com/p/0c4c2b324ede83dd8e1881b52a79e326) | 30 PA (R-PA-DIA) | +10 INT =**50 PA/dia** | Déficit mínimo 20; variante +20 dano aumenta diferença, RDM permanece desconhecida. |
| [Armadura de Zephyr — Espelho](https://app.notion.com/p/a23c2b324ede829bb8168165991577ff) | 90 PA/dia | +15 DES=75, +15m=15, +25 ataque=25, +50 dano/turno=50; **165** | Déficit condicional ≥75 PA; CA física +11 **não foi tarifada**. |
| [Manto de Proteção — Espelho](https://app.notion.com/p/761c2b324ede8201be5081ea69e97f10) | 10 PA/dia | +2 CA mágica =**2** | Excesso 8 sem benefício textual adicional; marcar para correção, não inventar manutenção-base. |
| [Bota Caminho Veloz](https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c) | 18 PA/dia + 5 por uso | +6m = **6 PA/dia** | Outros 12 PA históricos não identificam custos de atravessar terreno/não deixar rastros. |
| [Arremessável — Espelho](https://app.notion.com/p/a09c2b324ede823cafb60158afb31a46) | 11 PA/dia | +3 ataque +8 dano = **11** | Coincidência numérica não tarifa o retorno gratuito da arma. |

**Cuidados:** o custo isolado de +390 ou dados da fórmula da Espada do Lendário NÃO foi presumido como “bônus de dano adicional”. Seu subtotal seguro pelas novas regras é +60 FOR (300 PA/dia) +75 ataque (75 PA/dia) = **375 PA/dia**, restando 225 historicamente sem decomposição.

## Variantes, ambiguidades e dependência

- **Sabedoria Ancestral, Adaga Serpente, Amuleto Inteligência e Escudo Sentinela:** diário depende de R-PA-DIA; no relatório há flags e URL.
- **IMPERIAL / Veste Dragão:** 2 páginas, texto e custo 25 iguais, **1 linhagem textual provisória**; contar duas fichas físicas, não duas origens técnicas independentes.
- **Olhos nas Costas** (arma/armadura) e **Talismãs Bem/Mal**: duas famílias de efeitos correlatos no Espelho; não duplicar poder ao calibrar.
- **Anel Dimensional, Trespassar e Impacto Estonteante:** versões históricas V1/V2 com custos diferentes guardadas separadamente; **1 UUID por página**, apenas a variante V2 do relatório entra no resumo.
- **Amuleto Extensor:** 10 PA/dia por anel inserido, depende de N; fora do relatório de valores fixos.
- **Manto Ilusório:** texto “44 por dia” SEM unidade; não registrar 44 PA/dia.
- **Magia Implacável:** texto “+8 PA por.” sem frequência; não registrar 8 PA/dia.
- **CA física:** +11 CA da Armadura de Zephyr, +8 CA de Bastião e Armadura Anã são atributos do equipamento físico até prova de fração mágica; nunca aplicar 1 PA/CA por suposição.
- **Custo por uso:** não converter em PA/dia; há objetos com manutenção e ativação simultâneas.

## Pendências de classificação (não inventar Bronze)

1. **Amuleto Tempo Eterno** — 15 PA/dia, texto informa tempo mais rápido, mas não quantifica escala/efeito; sem rank técnico justificável.
2. **Olho Mágico** — 24 PA/dia no Espelho, mecânica textual ausente.
3. **Amuleto da Dor** — 14 PA/dia no Espelho, mecânica textual ausente.

## Governança de registros — ZERO CONTAMINAÇÃO

Esta entrega foi produzida **fora do Notion**, exclusivamente nos arquivos deste pacote. Não foi anexado relatório, diário, PSV ou anotação a fichas de itens, bestas, NPCs ou Party. No Notion, eventual registro deve ser endereçado pelo responsável competente **somente ao Diário/Inbox/Assignment oficial previstos na governança**, com writer/lease verificados; as páginas de conteúdo preservam apenas o conteúdo da entidade. Nenhum rank provisório E3 foi escrito em ficha pública. No-work on CRAFT recipes; C19-021 UNKNOWN e produção HOLD preservados.

## Arquivos de auditoria

- `MAPA_PA_DIA_POR_RANK_20261017.xlsx`: visão por rank e abas Mestre, Espelho, Auditoria e Regras.
- `SOMENTE_ITENS_COM_PA_DIA.csv`: 94 linhas com UUID, URL, família, rank, selo, valor e pendências.
- `CENSO_PA_CLASSIFICACAO_ORDENAVEL.csv`: 234 páginas, inclusive sem valor de PA/dia.
- `CENSO_CLASSIFICACAO_PA_RANK.json`: dados estruturados completos.
- `RESUMO_PA_POR_RANK.json`: denominadores e estatísticas.
- `VARIANTES_E_UNIDADES_INDETERMINADAS.json`: versões e casos sem unidade clara.
- `CATALOGO_COMPLETO_RANQUEADO.md`: lista completa com todos os 94 itens.

**Aceite proporcional:** censo e pré-classificação por efeitos concluídos neste recorte; classificação definitiva E3, cobertura global, coeficientes desconhecidos, holdout nativo CRAFT e NAC-PASS produtivo permanecem HOLD.
'''
(D/'RELATORIO_MESTRE_RANK_PA.md').write_text(A,encoding='utf-8')

B='''# Catálogo completo — fichas com gasto numérico de PA/dia

**17/10/2026 · MESTRE-SIDE · Somente fontes Mestre ou Espelho Mestre — Party NO-WRITE.**

Legenda: **E0** = rank explicitamente documentado na respectiva fonte; **E3** = pré-classificação de trabalho, **não canônica**; **PENDENTE** = descrição insuficiente. **RPA** = custo diário interpretado por R-PA-DIA, ainda condicional à verificação do contexto. O PA é custo histórico, **não preço recalculado**. Fontes do Espelho não entram na calibração Mestre.
'''
for source,name in cohorts:
 B+=f'\n## {name}\n'
 for rank in R:
  filt=[x for x in daily if x['fonte']==source and (x['rank_analitico'] or 'PENDENTE')==rank]
  if not filt:continue
  B+=f'\n### {rank} — {len(filt)} páginas\n\n| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |\n|---|---:|---|---|---|\n'
  for x in sorted(filt,key=lambda y:y['pa_dia_historico']):
   rk='E0' if x['rank_documental'] else 'E3' if x['rank_analitico'] else 'PENDENTE'
   mod=' (RPA)' if x['modalidade'] in ('REGRA_R_PA_DIA','R_PA_DIA','R_PA_DIA_INFERIDA') else ''
   note=(x['justificativa'] or x['pendencias']).replace('|','/').replace('\n',' ')[:135]
   B+=f"| [{x['item']}]({x['url']}) | {x['pa_dia_historico']}{mod} | {x['rank_analitico'] or 'PENDENTE'} | {rk} | {note} |\n"
 B+='\n'
(D/'CATALOGO_COMPLETO_RANQUEADO.md').write_text(B,encoding='utf-8')

PSV='''# PSV — R05 Continuidade PA-RANK-01

**AS-OF:** 17/10/2026 (data-base da autorização e dos documentos auditados). **IDENTIDADE/OPERATION:** executor PA existente; ID/OP não declarados sem prova do registro competente. **BASELINE:** R01–R05 imutável. **LAST-VERIFIED-UNIT:** união por UUID dos corpora recuperados R03 e R05 e fichas do Notion reabertas nesta rodada; XLSX, CSV, JSON, matriz por rank, recibos de conflito e arquivo ZIP verificável. **FIRST-PENDING:** inspeção completa de imagens/comparadores e validação competente de cada rank E3; disponibilidade de catálogo completo além dos índices; autorização de writer/registro.

**DENOMINATORS:** 234 UUIDs únicos rastreados (143 Mestre, 87 Espelho, 4 incubação); 94 valores numéricos diários fixos (14 Mestre, 80 Espelho); 4 rank documentais Mestre, 9 propostas rank E3 Mestre, 1 Mestre rank indeterminado; 1 rank explícito do Espelho, 77 pré-ranks E3 do Espelho, 2 indeterminados; 12 PA/dia explícitos Mestre +2 RPA, 78 explícitos Espelho +2 RPA. R05 mantinha 182; incremento líquido neste recorte =52 UUIDs. Linhagens conservadoras dentro dos diários: Mestre13 / Espelho78; sem prova de independência amostral universal.

**NO-REPEAT:** R05 motor e QMC-02 não alterados; regressões históricas não foram recontadas. **CONFLICTS:** Sabedoria Ancestral+10 SAB 20 PA; Colar cadente+4 sob estrelas14 PA; Amuleto INT no Espelho +10INT 30 PA; Armadura Zephyr +15DES+15m+25acerto+50 dano, 90 PA; atributos/dados-base e CA física devem ser distinguidos; RPA da Adaga35 pendente de reconciliação. **UNKNOWN-EFFECT:** C19-021 inalterado. **AUTHORITY/WRITER:** autorização do Mestre para pesquisar, calcular e classificar; nenhuma writer/lease Notion oficialmente atestada, então **ZERO ESCRITAS NOTION**, sobretudo em conteúdo/Party. **SCIENCE:** cinco coeficientes por decisão do Mestre; rank E3 por Atlas, custo observado não vira coeficiente por rank. **CRAFT:** sem mutações; QMC produção HOLD. **NAC-PASS:** teste de artefato local pode ser validado, gate canônico/produtivo não executado.

**NEXT-5:** (1) Classificações E3 por inspeção integral imagem+três comparadores; (2) cotejar universo de equipamentos Mestre fora dos índices; (3) reconciliação R-PA-DIA e custos históricos conflitantes sem alterar fichas; (4) derivar parcelas restantes por decisões expressas em família, modalidade e duração; (5) registrar em Diário/Inbox autorizado com readback e encaminhar rank+parecer ao CRAFT quando escritor competente aceitar.
'''
(D/'PSV_CONTINUIDADE_PA_RANK.md').write_text(PSV,encoding='utf-8')
print('REPORT',len(A),'FULL',len(B),'PSV',len(PSV))
