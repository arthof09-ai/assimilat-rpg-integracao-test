from __future__ import annotations
import json, csv, statistics, collections, hashlib, os, pathlib, zipfile, re
from datetime import datetime
base=pathlib.Path('/mnt/data/PA_RANK_R06_WORK')
root=base/'PA_UNIVERSAL_R05_TEST_20261017'
old=json.loads((root/'BASELINES/R04_EXTRAIDO/PA_UNIVERSAL_R04_TEST_20261017/BASELINE_PA_R03/corpus_pa_v3.json').read_text())['items']
audit=json.loads((root/'BASELINES/R04_EXTRAIDO/PA_UNIVERSAL_R04_TEST_20261017/CORPUS_ORIGEM_AUDITADA_R04.json').read_text())['rows']
origin={x['uuid']:x for x in audit}
records={}
for it in old:
 uid=it['item_id']; au=origin[uid];pa=au.get('pa_daily');src=au['surface'];
 rank=it.get('rank_public'); rank=rank if rank in ['Bronze','Prata','Ouro','Ouro Negro','Lendário'] else None
 if uid=='a23c2b324ede829bb8168165991577ff':rank=None  # (L) no título da ficha Espelho não equivale a E0 confirmado
 records[uid]={
 'uuid':uid,'item':it['name'],'url':it['source_url'],'fonte':src,'familia':it.get('family') or '',
 'pa_dia_historico':pa,'modalidade':(it.get('pa_daily') or {}).get('classification','AUSENTE'),
 'rank_documental':rank,'rank_analitico':rank,'selo_rank':'E0_DOCUMENTAL' if rank else 'NAO_ANALISADO',
 'efeitos_resumidos':it.get('mechanics_summary','') or '',
 'justificativa':'Rank documental registrado na ficha do catálogo.' if rank else '',
 'pendencias':'', 'linha_independente':it.get('lineage_cluster') or uid,
 'verificado_conector':'BASELINE_R04_R05_RELATADO_E_COTEJADO_PARCIALMENTE_NESTE_TURNO','versao_doc':'R05_BASELINE',
 'nota_modalidade':'', 'pa_ativacao':(it.get('pa_activation') or {}).get('value'),
 'autoridade_rank':'FICHA_CATALOGO_MESTRE' if rank else 'PENDENTE', 'a_reconciliar':False,
 'base_direta_da_regra':None,'delta_sinal':'NAO_APLICADO'}

# Valores retirados de fichas físicas do Notion, neste turno. Ordem: UUID | Nome | PA/dia | família | rank proposto | eixos | grau | justificação.
# E3 = pré-classificação de trabalho, NÃO alteração da ficha.
raw='''
65fc2b324ede838d9e5181b614b8da6a|Mira Apurada|4|Arma aprimoramento|Bronze|+3 ataque condicional; exige ação de movimento|E3|Aperfeiçoamento preciso, restrito ao alvo e turno.
140c2b324ede82d7995901575507a36a|Juramento|16|Arma aprimoramento|Ouro|alvo jurado; vantagem ataque; cobertura ignorada; +3d8 dano; maldição|E3|Rastreio e neutralização de cobertura mais dano contra um alvo persistente.
aeec2b324ede83f69a110153bde2fc86|Defensora|11|Arma aprimoramento|Prata|+3 ataque/dano; bônus transferível à CA temporariamente|E3|Especialização marcial com conversão defensiva por turno.
92bc2b324ede83be863b01a5d6aba48b|Alerta|8|Arma aprimoramento|Prata|não surpreendido; vantagem iniciativa; alerta ao dormir|E3|Percepção protetora confiável, tática individual.
b0bc2b324ede8347832201d7b0c9572c|Viciada|7|Arma aprimoramento|Prata|+12 dano no crítico|E3|Dano condicionado a acerto crítico.
a09c2b324ede823cafb60158afb31a46|Arremessável|11|Arma aprimoramento|Prata|+3 ataque/+8 dano arremesso; arma retorna Ação Livre|E3|Ofensiva recorrente e retorno sem perda de ação.
647c2b324ede822787a8011d2002490c|Relâmpago Avassalador|25|Arma aprimoramento|Ouro|linha 36m largura 3m 4d6 em área; +4d8 alvo; 1/dia|E3|Área, controle de alcance e dano elétrico relevante em encontro.
377c2b324ede82f9b4a181aed3e10f5a|Decepadora|20|Arma aprimoramento|Ouro Negro|crítico +30 dano e possível decepar membro|E3|Possibilidade de perda de membro ultrapassa bônus ofensivo comum.
7d9c2b324ede83698dc381e76c958649|Sangramento|19|Arma aprimoramento|Ouro|DoT 1d6 por ferida acumulativa; impede cura exceto descansos|E3|Negação de cura, múltiplas aplicações e duração em combate.
442c2b324ede82c7a1520173d0d45cfd|Vorpal|25|Arma aprimoramento|Ouro Negro|+3 ataque/+9 dano; ignora resistência; decapitação no crítico|E3|Bypass e execução potencial em crítico, com imunidades descritas.
9e9c2b324ede82e3a83d019717e0d51c|Arma Mortal|8|Arma aprimoramento|Prata|margem crítica melhorada em 1|E3|Amplificação precisa com efeito exclusivamente ofensivo.
a8ec2b324ede83e9b69a81affb4e1447|Impacto Estonteante|11|Arma aprimoramento|Ouro|V2: -3 ataque/-6 dano no adversário e derrubar sob salvaguarda|E3|Controle repetível além de penalidade ofensiva; V1 8 PA preservada.
9e8c2b324ede82dda72581434c7a7ce5|Trespassar|14|Arma aprimoramento|Ouro|V2: ataque adicional sem limite na rodada após abate|E3|Economia de ações escalável por abates; V1 10 PA preservada.
064c2b324ede8304b2d301e0835cc0c4|Exterminadora de Monstros|8|Arma aprimoramento|Prata|+8 dano vs Grandes; nega bônus de tamanho em manobras|E3|Especialização situacional, sem escopo universal.
54fc2b324ede8349862001ed2929ac98|Foco Arcano|7|Arma aprimoramento|Prata|+1 CD de magia; permite aprimoramentos de cajado|E3|Especialização de canalização de magia.
e87c2b324ede8240842d0145e2496568|Escudo Apanhador de Flechas|14|Escudo aprimoramento|Prata|+2 CA vs projéteis; redirecionamento por Reação|E3|Proteção de aliados seletiva por reação.
1f4c2b324ede823c8339815f36a2f2ae|Escudo de Atração de Projéteis|15|Escudo aprimoramento|Prata|resistência contra projéteis de armas; maldição truncada|E3|Mitigação específica, maldição pendente.
99cc2b324ede82b2870b8141b72829cd|Escudo de Proteção Contra Magia|16|Escudo aprimoramento|Ouro|vantagem salvaguardas mágicas; desvantagem ataque magias; RDM15|E3|Defesa mágica ampla com múltiplas camadas.
29ac2b324ede82d8a46e814c05fcfb77|Escudo Sentinela|15|Escudo aprimoramento|Prata|vantagem iniciativa e Percepção|E3|Antecipação e vigilância; R-PA-DIA inferido por linha final.
fc0c2b324ede82a2a2cf01796265a4c2|Olhos nas Costas (arma)|11|Arma aprimoramento|Prata|reação imediata ao flanqueamento; ataque e +1.5m|E3|Mesmo texto da versão armadura; dependência de linhagem.
f25c2b324ede83caaffa81b3fc5a6485|Alcance Aprimorado|6|Arma aprimoramento|Bronze|+3m de alcance em magias do cajado|E3|Ampliação de alcance local simples, não deslocamento.
9b7c2b324ede83f4af7e01c90cb6efaf|Eficiência Mágica|6|Arma aprimoramento|Prata|reduz 2 PA do custo de preparação de magias de dano|E3|Economia recorrente de recurso mágico.
da4c2b324ede827d97180107a0d52b6e|Magias Devastadoras|16|Arma aprimoramento|Ouro|duas magias sobem uma categoria de dado|E3|Aumento ofensivo em duas técnicas persistentes.
b8ac2b324ede827e9dbf81061dcde8d4|Magia Aprimorada|6|Arma aprimoramento|Prata|+1d6+1 dano em magias|E3|Amplificação ofensiva direta limitada.
b67c2b324ede8393a34f81f2162ab84a|Força Bruta|12|Arma aprimoramento|Ouro|ignora 15 de resistência a energia em magias|E3|Bypass de resistência contra múltiplos efeitos.
c5fc2b324ede8311b20c015f84694644|Sai da Frente|8|Arma aprimoramento|Ouro|aliados beneficiados por evasão contra magia área própria|E3|Permite ofensiva em área sem fogo amigo mecânico.
96ac2b324ede82199f5b812bf2b0210b|Potencializar Magia|22|Arma aprimoramento|Ouro Negro|aumenta valores numéricos variáveis da magia 50%|E3|Escalonamento proporcional da potência em múltiplas magias.
15cc2b324ede832589b801eb0e0d2554|Estender Magia|8|Arma aprimoramento|Prata|duplica duração de magia|E3|Ampliação de sustentação temporal, dependente da magia.
780c2b324ede82f69ae8818e612b7ad2|Anel de Evasão|13|Artefato Espelho|Ouro|converte falha em resistência DES em sucesso por Reação; 3 cargas|E3|Garantia limitada contra falhas, alta confiabilidade.
cf3c2b324ede82d49d7981a926c0bd52|Anel de Queda Suave|15|Artefato Espelho|Prata|proteção contra queda, descida controlada|E3|Mobilidade vertical e segurança situacional.
758c2b324ede82b0a49b81b94d15cfc5|Anel de Andar na Água|14|Artefato Espelho|Ouro|travessia de líquidos como solo|E3|Bypass de terreno aquático contínuo.
041c2b324ede83f5a9ae8131af38c2b9|Anel de Cativar Criaturas|27|Artefato Espelho|Ouro|controle de bestas por duas magias; 3 cargas|E3|Controle de criaturas com limite de cargas e CD16.
274c2b324ede82c7b8358196fd0e5b52|Anel de Escudo Mental|35|Artefato Espelho|Ouro Negro|imunidade a leitura mental, +12 salvaguarda e 25 RM mental|E3|Negação mental e resistências substanciais amplas.
81bc2b324ede8282b47781c7d616708b|Anel de Resistência|22|Artefato Espelho|Prata|resistência a um tipo de dano selecionado|E3|Proteção permanente, mas específica ao elemento.
f76c2b324ede835ca8de01e778e4ff12|Chifre do Alarme Silencioso|5|Artefato Espelho|Bronze|sinalização secreta a um aliado até 500m; 4 cargas|E3|Suporte informacional sem ofensiva/controle.
f53c2b324ede83149b588191fa2496ce|Diamante de Sangue|34|Artefato Espelho|Ouro|rastreia parente consanguíneo por sangue; localiza distância/direção|E3|Rastreio seletivo a longa distância não quantificada.
bb4c2b324ede8249af01013102807a0e|Máscara do Dragão Negro|70|Artefato Espelho|Lendário|múltiplas imunidades, CA condicional, visão, regeneração, resistência lendária|E3|Conjunto de defesas e bypass com repercussão estratégica; classe pendente de benchmarks completos.
045c2b324ede83b9bee381dec251e087|Olho de Ersatz|12|Artefato Espelho|Bronze|substituição ocular com visão comum|E3|Reparo funcional pessoal sem percepção extraordinária.
83ec2b324ede82e4b28b01c5f2f5dd98|Óculos Noturnos S.P|15|Artefato Espelho|Prata|visão escura 10m adicional|E3|Percepção especializada local.
a54c2b324ede8397ac238132b5927431|Amuleto da Dor|14|Artefato Espelho|PENDENTE|não há efeito textual documentado|E3|Rank impossível sem mecânica; PA isolado insuficiente.
cabc2b324ede83acb24e8105c082c6b0|Tiara Intelectual|65|Artefato Espelho|Ouro|INT vai a 20 se abaixo de 20|E3|Alteração de atributo dependente do usuário, não bônus fixo; exigir INT anterior.
570c2b324ede8333abe281e55dd13713|Talismã Pura Bondade|26|Artefato Espelho|Ouro|4d6/8d6 radiante em toque e fim de turno de portador hostil|E3|Dano reativo persistente contra perfis definidos.
25dc2b324ede828bae40819b5068b040|Talismã Mal Supremo|26|Artefato Espelho|Ouro|4d6/8d6 necrótico em toque e fim de turno de portador hostil|E3|Versão espelhada do talismã, dependente da família técnica.
298c2b324ede8287a59581a988b13d3c|Sucesso Atrai Sucesso|18|Artefato Espelho|Ouro|margem crítica acumula em cada crítico durante combate|E3|Escalonamento ofensivo ao longo do encontro.
2b9c2b324ede835d9e8501cbbe90d44a|Amuleto dos Ventos|12|Artefato Espelho|Prata|+4m deslocamento e +2 Reflexo, levitação|E3|Mobilidade pessoal e Reflexo, alcance/voo incertos.
24ec2b324ede82eea4b9018eb01eb219|Botas de Pegadas Falsas|12|Roupa Espelho|Bronze|disfarça pegadas como outro humanoide|E3|Engano local sem combate.
3d5c2b324ede8243a47d01ff084ebdd2|Botas do Inverno|20|Roupa Espelho|Prata|resiste frio e ignora terreno difícil de neve/gelo|E3|Sobrevivência e mobilidade em bioma específico.
591c2b324ede838691148122c83c19d5|Manto da Arachnida|34|Roupa Espelho|Ouro|escalada, imunidade teias, resistência veneno e magia área 1/dia|E3|Conjunto de travessia e controle de terreno.
426c2b324ede833a89ba81706507f192|Manto de Elvenkind|8|Roupa Espelho|Prata|camuflagem e vantagem furtividade|E3|Especialização furtiva persistente.
ba0c2b324ede834c920d01390e3aac12|Manto da Moda|12|Roupa Espelho|Bronze|alteração cosmética de aparência|E3|Utilidade social localizada, sem mecânica de combate.
05dc2b324ede8272a0b58113edf5466e|Manto Resistência Mágica|15|Roupa Espelho|Prata|vantagem +3 salvaguarda contra feitiços|E3|Defesa contra magia por salvaguarda.
c1bc2b324ede82409f3b01eb327bb75b|Manopla de Combatente 2.0 S.P|52|Armadura Espelho|Ouro Negro|CON sobe para 20 se abaixo; +3d8+8 dano e cura equivalente|E3|Amplificação ofensiva com cura e atributo, dependente do portador.
622c2b324ede8213a609818e7ef09a9a|Bastião de Virilia|24|Armadura Espelho|Ouro|+2 FOR, +8 CA físico incerto, RDM10 fogo, intimidação; -5m|E3|Defesa elemental e presença de combate, CA física não tarifada.
663c2b324ede83a4a63f01e0c184a35a|Arco Justiça Celestial|18|Arma Espelho|Prata|visão penumbra, +6 percepção, dano variável por ações sem magnitude|E3|Percepção persistente; dano condicional insuficiente para rank alto.
fcac2b324ede8260a9cf01d141dae809|Adaga de Envenenamento Mortal|26|Arma Espelho|Ouro|+2 ataque/dano; 3d10 veneno e condição 1min, limite 2 ativações|E3|Veneno com condição e limite, acima de dano puro.
66ac2b324ede82118e97011ed3a526d3|Anel Dimensional Vinculado V²|8|Artefato Espelho|Ouro|espaço extradimensional 1m³, compartilhamento vinculado|E3|Bypass espacial e acesso compartilhado; V1 de 6 PA preservada.
089c2b324ede837c9e590174fcc33291|Couraça de Eos|24|Armadura Espelho|Ouro|+2 SAB, CA +2, cura 6 PV por turno 4-8h, clarão 6 PA/uso|E3|Cura repetível com defesa e debuff ativo.
56cc2b324ede823586be01440f7a68ef|Bracelete da Calma|21|Artefato Espelho|Ouro|+3 SAB, resistência mágica elemental, absorção 10PA/uso|E3|Proteção e restauração de recursos, múltiplas funções.
d6fc2b324ede82e0b26981462a737826|Relicário dos Segredos|30|Artefato Espelho|Ouro|imunidade esquecimento, memória armazenável 15PA/uso|E3|Proteção e preservação de informação importante.
376c2b324ede8394b3ff81fe4cc2d1cc|Adaga Mortal Jaku|385|Arma Espelho|Lendário|+20 DES,+10m, +7d8 veneno, crítico furtivo garantido, teleporte e controle|E0_FICHA|Lendária textual e mecânica de ataque/controle excepcional, demais relações pendentes.
761c2b324ede8201be5081ea69e97f10|Manto de Proteção|10|Roupa Espelho|Bronze|+2 CA constante, origem mágica do bônus|E3|Defesa simples e localizada.
2d5c2b324ede8276a13a01d7a4525c74|Manto Olhar Verdadeiro|36|Roupa Espelho|Ouro|visão 360, +8 Percepção, invisibilidade e plano etéreo|E3|Detecção ampla incluindo alvos normalmente ocultos.
0e9c2b324ede833dbee501f46a9fb06f|Manto Ilusório| |Roupa Espelho|Ouro|+10 CA após teste percepção CD20; efeito suprimido ao receber dano|E3|Custo escrito 44 por dia SEM unidade; não imputar PA.
'''

for line in raw.strip().splitlines():
 parts=line.split('|')
 if len(parts)!=8:raise ValueError((len(parts),line))
 uid,name,pa,fam,rank,eff,selo,why=parts
 pa=int(pa) if pa.strip() else None
 if uid in records:
  rr=records[uid]
  # sempre preservar fonte do R04
  if rr['pa_dia_historico'] is None and pa is not None: rr['pa_dia_historico']=pa
  elif rr['pa_dia_historico'] is not None and pa is not None and rr['pa_dia_historico']!=pa:raise ValueError(('conflicting historical',name,rr['pa_dia_historico'],pa))
 else:
  rr={'uuid':uid,'item':name,'url':'https://app.notion.com/p/'+uid,'fonte':'PARTY_MESTRE_ESPELHO','familia':fam,'pa_dia_historico':pa,
      'modalidade':'EXPLICITA' if pa is not None else 'SEM_UNIDADE','rank_documental':None,'rank_analitico':None,'selo_rank':'NAO_ANALISADO','efeitos_resumidos':'','justificativa':'','pendencias':'','linha_independente':uid,'verificado_conector':'NOTION_FICHA_REABERTA_TURNO','versao_doc':'ASOF_PAGINA_20260930','nota_modalidade':'','pa_ativacao':None,'autoridade_rank':'PENDENTE','a_reconciliar':False,'base_direta_da_regra':None,'delta_sinal':'NAO_APLICADO'}
  records[uid]=rr
 rr['efeitos_resumidos']=eff
 rr['justificativa']=why
 if uid=='376c2b324ede8394b3ff81fe4cc2d1cc':
  rr['rank_documental']='Lendário'
  rr['rank_analitico']='Lendário'
  rr['autoridade_rank']='ROTULO_EXPLICITO_FICHA_ESPELHO'
  rr['selo_rank']='E0_ROTULO_ESPELHO_SEM_CANONIZACAO_MESTRE'
 if not rr['rank_documental']:
  rr['rank_analitico']=rank if rank!='PENDENTE' else None
  rr['selo_rank']=selo if rank!='PENDENTE' else 'E3_INSUFICIENTE'
  rr['autoridade_rank']='CLASSIFICACAO_ANALITICA_NAO_CANONIZADA'
 if uid=='29ac2b324ede82d8a46e814c05fcfb77':rr['modalidade']='R_PA_DIA_INFERIDA'
 if uid=='66ac2b324ede82118e97011ed3a526d3':
  rr['nota_modalidade']='V1 6 PA/dia; V² 8 PA/dia na mesma página; valor escolhido é V², sujeito a confirmação de versão em uso.'
 if uid=='a8ec2b324ede83e9b69a81affb4e1447':rr['nota_modalidade']='V1 8 PA/dia, V² 11 PA/dia. Retida V² apenas na coorte principal.'
 if uid=='9e8c2b324ede82dda72581434c7a7ce5':rr['nota_modalidade']='V1 10 PA/dia, V² 14 PA/dia. Retida V² apenas na coorte principal.'

# Pré-classificação exclusivamente por potência/efeito (não usa custo de PA nem MED).
proposals={
'3edc2b324ede812c9b54c261934696e6':('Ouro','Defesa multifuncional, furtividade, invisibilidade curta e recuperação PA sob condição; falta benchmark visual.'),
'3edc2b324ede8135b199fd0cdbb5463c':('Ouro','Atravessar superfícies aquáticas/instáveis, furtividade e bônus móvel; bypass do terreno eleva além de bônus simples.'),
'3edc2b324ede816cbad5ca3880ce144d':('Prata','Percepção +4, CA condicional +2 e salto 4,5m ativável; versatilidade pessoal restrita.'),
'3edc2b324ede81948c88f917a40e50fa':('Ouro','Precisão, Reflexo, deslocamento e RDM contra magias determinadas em conjunto.'),
'3edc2b324ede817897f1cdf5dea0cb70':('Ouro','Texto mecânico idêntico ao da Veste Dragão, dependência de linhagem não encerrada.'),
'3edc2b324ede8144a3aed184b14275d4':('Ouro Negro','Amplo repertório de magias de controle/execução e visão no escuro, limitado por cargas e maldição; equivalência mecânica das magias externas pendente.'),
'3edc2b324ede81948833eb6f4a5ef488':('Ouro Negro','Imunidade a petrificação e conjuração de transformar em pedra com risco de retorno e exaustão do item.'),
'3edc2b324ede815699adc0412e96ea2b':('Ouro','+10 SAB e suporte cognitivo/telepático persistente, alcance da telepatia não delimitado.'),
'3edc2b324ede8132bbc8f857f4b276c4':(None,'Sem magnitude quantificada do tempo acelerado; impossível definir efeito dominante, comparadores e rank.'),
'3edc2b324ede810daba2cc509677856c':('Prata','+2 SAB permanente, +4 SAB à luz das estrelas: bônus restrito e local.'),
'3c6c2b324ede82baa4a801de533a5975':('Prata','+3 atributo pessoal, magnitude pequena; sem outros efeitos descritos.'),
'8afc2b324ede82e69dd101b9b9c663e3':('Ouro Negro','Dano mágico +30, CD +8, CA substitutiva e defesa mágica, múltiplos efeitos avançados.'),
'2c7c2b324ede837d87e781ee6adaeca4':(None,'Olho Mágico sem descrição mecânica textual; rank deve aguardar ficha integral/imagem.'),
'0c4c2b324ede83dd8e1881b52a79e326':('Ouro','+10 INT e +20 dano mágico ou resistência mágica; complexo e versátil, mas modalidades alternativas.'),
'a23c2b324ede829bb8168165991577ff':('Lendário','+15 DES, +15m, +25 ataque e +50 dano de Vento por turno; efeito extremo, rank L indicado no título (não substitui validação).'),
'a70c2b324ede83c2ac490135cd512e9f':('Ouro Negro','Bônus combinados de atributos, múltiplos danos radiantes e cegueira; custo individual das sobreposições pendente.'),
'9efc2b324ede8250a37981fb1fef45dd':('Ouro','Amplificação de sombras, CD e controle gravitacional com ataques mágicos múltiplos.'),
'5f7c2b324ede83de9c7a81fcb19b0195':('Bronze','+2 CA da armadura e penalidade de peso/movimento; origem física incerta.'),
'1d2c2b324ede8343be42810a0b54f1d2':('Prata','Anula acertos críticos, proteção passiva confiável.'),
'559c2b324ede829a9139813d4899b07a':('Ouro Negro','Resistência não mágica e imunidade temporária a dano não mágico, 2/dia.'),
'16cc2b324ede831290f801af40e0e5bc':('Prata','Remoção de penalidades de armadura e restauração de movimento; não +3m absoluto.'),
'be9c2b324ede83108c3d016dc6ffba91':('Ouro','Natação igual à caminhada e salvaguarda contra submersão inconsciente.'),
'6c2c2b324ede83a7b7dc013f94eb052c':('Ouro Negro','Evita fatalidade uma vez por dia; bypass de morte com forte restrição.'),
'383c2b324ede820ab38881abbe91ac60':('Prata','+2 CA condicional à ação de movimento; benefício tático curto.'),
'c42c2b324ede8259995e81a2461f46e2':('Prata','Reação de ataque e movimento ao ser flanqueado pela primeira vez.'),
'e56c2b324ede82a898bb8137c2d8d0f3':('Prata','PV por nível de personagem, dependente do usuário; escala exige contenção e análise.'),
}
for uid,(rank,why) in proposals.items():
 rr=records[uid]
 if rr['rank_documental']:
  raise ValueError(('replacing documented rank',uid,rr['rank_documental']))
 rr['rank_analitico']=rank
 rr['justificativa']=why
 rr['selo_rank']='E3_PRE_CLASSIFICACAO' if rank else 'E3_INSUFICIENTE'
 rr['autoridade_rank']='CLASSIFICACAO_ANALITICA_NAO_CANONIZADA'

# Linhagens não independentes / ocorrências de mesma habilidade.
records['3edc2b324ede817897f1cdf5dea0cb70']['linha_independente']='EQUIV_VESTE_DRAGAO_IMPERIAL'
records['3edc2b324ede81948c88f917a40e50fa']['linha_independente']='EQUIV_VESTE_DRAGAO_IMPERIAL'
records['fc0c2b324ede82a2a2cf01796265a4c2']['linha_independente']='EQUIV_OLHOS_COSTAS_11'
records['c42c2b324ede8259995e81a2461f46e2']['linha_independente']='EQUIV_OLHOS_COSTAS_11'
records['570c2b324ede8333abe281e55dd13713']['linha_independente']='TALISMA_DANO_TOQUE_4D6_8D6'
records['25dc2b324ede828bae40819b5068b040']['linha_independente']='TALISMA_DANO_TOQUE_4D6_8D6'

# Preciso distinguir custos históricos de parcela dos coeficientes Mestre.
# Unidade: +1 atributo=5 PA/dia, +1 bônus dano=1, +1m aumento caminhada=1, +1 ponto bonus teste ATAQUE=1,
# +1 CA MÁGICA=1; CA física/mundana não recebe tarifa.
# NÃO transformar dados da arma, regeneração, resistências, RDM, CD, Reflexos, buffs temporários em coeficiente geral.
known={
'3edc2b324ede8135b199fd0cdbb5463c':[('movimento',6)],
'3edc2b324ede816cbad5ca3880ce144d':[('ca_magica',2)],
'3edc2b324ede81948c88f917a40e50fa':[('acerto',4),('movimento',4)],
'3edc2b324ede817897f1cdf5dea0cb70':[('acerto',4),('movimento',4)],
'3edc2b324ede815699adc0412e96ea2b':[('atributo',10)],
'3edc2b324ede810daba2cc509677856c':[('atributo',2)],
'3edc2b324ede812c9b54c261934696e6':[('dano',2),('acerto',2)],
'3c6c2b324ede82baa4a801de533a5975':[('atributo',3)],
'0c4c2b324ede83dd8e1881b52a79e326':[('atributo',10),('dano',20)], # somente variante dano, alternativa RDM não somada.
'a23c2b324ede829bb8168165991577ff':[('atributo',15),('movimento',15),('acerto',25),('dano',50)],
'a70c2b324ede83c2ac490135cd512e9f':[('atributo',15)],
'65fc2b324ede838d9e5181b614b8da6a':[('acerto',3)],
'aeec2b324ede83f69a110153bde2fc86':[('acerto',3),('dano',3)], # max repartição, não 2 simultaneos!
'b0bc2b324ede8347832201d7b0c9572c':[('dano',12)],
'a09c2b324ede823cafb60158afb31a46':[('acerto',3),('dano',8)],
'442c2b324ede82c7a1520173d0d45cfd':[('acerto',3),('dano',9)],
'064c2b324ede8304b2d301e0835cc0c4':[('dano',8)],
'383c2b324ede820ab38881abbe91ac60':[('ca_magica',2)],
'761c2b324ede8201be5081ea69e97f10':[('ca_magica',2)],
'2b9c2b324ede835d9e8501cbbe90d44a':[('movimento',4)],
'622c2b324ede8213a609818e7ef09a9a':[('atributo',2)],
'089c2b324ede837c9e590174fcc33291':[('atributo',2)],
'56cc2b324ede823586be01440f7a68ef':[('atributo',3)],
'376c2b324ede8394b3ff81fe4cc2d1cc':[('atributo',20),('movimento',10)],
'fcac2b324ede8260a9cf01d141dae809':[('acerto',2),('dano',2)],
}
weights={'atributo':5,'dano':1,'movimento':1,'acerto':1,'ca_magica':1}
for uid,v in known.items():
 rr=records[uid];rr['base_direta_da_regra']=sum(weights[x]*num for x,num in v)
 rr['formula_identificada']=' + '.join(f'{num} {x} × {weights[x]}' for x,num in v)
 if uid=='aeec2b324ede83f69a110153bde2fc86':
  rr['base_direta_da_regra']=3
  rr['formula_identificada']='3 PA/dia de bônus redistribuível entre acerto, dano e CA; não somar configurações mutuamente exclusivas'
 if uid=='0c4c2b324ede83dd8e1881b52a79e326':
  rr['base_direta_da_regra']=50
  rr['formula_identificada']='+10 INT = 50 PA/dia; efeito alternativo (+20 dano mágico OU 20 RM) pode elevar 20 no ramo de dano, sem somar RM; unidade histórica R-PA-DIA'
 if uid=='3edc2b324ede810daba2cc509677856c':
  rr['nota_modalidade']='Sob luz estelar, SAB total é +4: parcela mínima condicionada = 20 PA/dia (histórico 14); sem luz, +2 =10.'
 if uid=='3edc2b324ede812c9b54c261934696e6':
  rr['nota_modalidade']='7 PA/dia do aprimoramento Mobilidade JÁ incluídos em 34; os bônus listados reaparecem no bloco de habilidades, sem soma duplicada.'
 if uid=='a70c2b324ede83c2ac490135cd512e9f':
  rr['nota_modalidade']='Aprimoramento +8 dano/+3 ataque/-16 PA, dados de dano e sobreposições exigem adjudicação antes de calcular total.'
 if rr['pa_dia_historico'] is not None:
  if rr['base_direta_da_regra']>rr['pa_dia_historico']:
   rr['delta_sinal']='PISO_REGRA_SUPERA_HISTORICO'
   rr['a_reconciliar']=True
  elif rr['base_direta_da_regra']==rr['pa_dia_historico']:
   rr['delta_sinal']='SUBTOTAL_IGUAL_HISTORICO_NAO_EXCLUI_OUTROS_EFEITOS'
  else:rr['delta_sinal']='SUBTOTAL_INFERIOR_TOTAL_OUTROS_EFEITOS_NAO_IDENTIFICADOS'
 else:rr['delta_sinal']='PA_DIA_SEM_VALOR'

# As variantes de armadura podem ser físicas; salvo determinação da fonte, NÂO tarifar CA.
for uid in ['5f7c2b324ede83de9c7a81fcb19b0195','622c2b324ede8213a609818e7ef09a9a','3edc2b324ede812c9b54c261934696e6']:
 records[uid]['pendencias']='Separar CA própria da armadura de CA adicional de encantamento; não taxar CA-base física.'

# Históricos diários não implicam identidade energética dos componentes restantes.
for r in records.values():
 if r['pa_dia_historico'] is None:continue
 if not r['rank_documental'] and not r['rank_analitico']:
  r['pendencias']=(r['pendencias']+' | ' if r['pendencias'] else '')+'Rank indeterminado: não atribuir Bronze por falta de informações.'
 if r['selo_rank'].startswith('E3'):
  r['pendencias']=(r['pendencias']+' | ' if r['pendencias'] else '')+'Classificação E3 preliminar; inspeção de imagem e três comparadores Atlas ainda pendentes.'
 if r['base_direta_da_regra'] is None:
  r['pendencias']=(r['pendencias']+' | ' if r['pendencias'] else '')+'Efeitos sem parcela isolável nos cinco coeficientes do Mestre; preservar PA histórico sem inventar decomposição.'
 elif r['pa_dia_historico'] != r['base_direta_da_regra']:
  r['pendencias']=(r['pendencias']+' | ' if r['pendencias'] else '')+'Diferença entre PA histórico e subtotal conhecido não constitui preço provado das demais habilidades; requer reconciliação por modalidade.'
 if r['modalidade'] in ('R_PA_DIA','R_PA_DIA_INFERIDA','REGRA_R_PA_DIA'):
  r['pendencias']=(r['pendencias']+' | ' if r['pendencias'] else '')+'Custo diário inferido por R-PA-DIA; reavaliar contexto e última linha.'

records['3edc2b324ede811787a0de913622b14d']['pendencias']='35 de PA em linha final; interpretação R-PA-DIA em disputa com parecer CRAFT original; preservar como CONDICIONAL, não explícito.'
records['a54c2b324ede8397ac238132b5927431']['pendencias']='Somente 14 PA/dia e preço: mecânica não escrita; requer fonte/imagem; rank INDETERMINADO.'
records['2c7c2b324ede837d87e781ee6adaeca4']['pendencias']='24 PA/dia, sem mecânica textual; rank INDETERMINADO.'
records['0e9c2b324ede833dbee501f46a9fb06f']['pendencias']='44 por dia SEM PA; não incluir na distribuição PA confirmada, ainda que haja forte contexto energético.'

# casuística com componente único/pareado e inconsistências.
conditions=[
('Sabedoria Ancestral','3edc2b324ede815699adc0412e96ea2b','+10 SAB','50 PA/dia','20 PA inferidos','CONFLITO_30','Apenas atributo já exige 50, sem precificar telepatia e memória.'),
('Colar cadente (sob estrelas)','3edc2b324ede810daba2cc509677856c','+4 SAB','20 PA/dia','14 PA/dia','CONFLITO_6','Modo normal +2 SAB =10 PA/dia; modo estelar total +4 SAB =20, não 30.'),
('Amuleto de Inteligência (Espelho)','0c4c2b324ede83dd8e1881b52a79e326','+10 INT','50 PA/dia','30 PA sem unidade','CONFLITO_MINIMO_20_CONDICIONAL','Unidade histórica inferida R-PA-DIA; variante +20 dano eleva a exigência se simultânea.'),
('Armadura de Zephyr (Espelho)','a23c2b324ede829bb8168165991577ff','+15 DES, +15m, +25 ataque, +50 dano','165 PA/dia','90 PA/dia','CONFLITO_75','Não inclui +11 CA física, nem outros efeitos. Precisar distinguir +50 dano por turno de bônus de dano.'),
('Manto de Proteção (Espelho)','761c2b324ede8201be5081ea69e97f10','+2 CA mágica','2 PA/dia','10 PA/dia','DIFERENCA_8','Se realmente único efeito, excesso histórico requer explicação; não presumir tarifa básica.'),
('Mira Apurada (Espelho)','65fc2b324ede838d9e5181b614b8da6a','+3 teste ataque com ação de movimento','3 PA/dia','4 PA/dia','DIFERENCA_1','Condição de mira pode justificar ajuste ainda sem regra de ajuste.'),
('Arremessável (Espelho)','a09c2b324ede823cafb60158afb31a46','+3 ataque e +8 dano','11 PA/dia','11 PA/dia','SUBTOTAL_FECHA','Retorno automático de arma não tem custo determinado; não confundir coincidência com validação total.'),
('Bota Caminho Veloz','3edc2b324ede8135b199fd0cdbb5463c','+6m passivo','6 PA/dia','18 PA/dia','OUTROS_EFEITOS_12','Sem rastros e atravessar superfícies permanecem sem tarifa; habilidade +8m é por ativação 5PA.'),
('Veste Dragão Ascendente','3edc2b324ede81948c88f917a40e50fa','+4 teste de ataque e +4m','8 PA/dia','25 PA/dia','OUTROS_EFEITOS_17','Reflexos +5 e RDM15 ainda não possuem tarifa; 17 não é estimativa isolada deles.'),
('Espada do Lendário','3edc2b324ede81ab9e22e168f6d939a9','+60 FOR e +75 teste de ataque','375 PA/dia','600 PA/dia','OUTROS_EFEITOS_225','Dado base e +390 fórmula de dano não foram equiparados a bônus adicional sem prova.'),
]

# Registro extras com taxa diária variável, versões e ausência de unidade (não contadas como custo PA diário fixo).
variable=[
 {'uuid':'77ac2b324ede82dbb87201d3130f0106','item':'Amuleto Extensor','url':'https://app.notion.com/p/77ac2b324ede82dbb87201d3130f0106','fonte':'PARTY_MESTRE_ESPELHO','custo':'10 PA/dia × N anéis no amuleto','comentario':'N variável; não incluir como 10 PA fixos.'},
 {'uuid':'a8ec2b324ede83e9b69a81affb4e1447','item':'Impacto Estonteante V1','url':'https://app.notion.com/p/a8ec2b324ede83e9b69a81affb4e1447','fonte':'PARTY_MESTRE_ESPELHO','custo':'8 PA/dia V1','comentario':'V2 11 PA/dia é a linha ativa do dataset; não dupla contagem.'},
 {'uuid':'9e8c2b324ede82dda72581434c7a7ce5','item':'Trespassar V1','url':'https://app.notion.com/p/9e8c2b324ede82dda72581434c7a7ce5','fonte':'PARTY_MESTRE_ESPELHO','custo':'10 PA/dia V1','comentario':'V2 14 PA/dia é a linha ativa do dataset; não dupla contagem.'},
 {'uuid':'66ac2b324ede82118e97011ed3a526d3','item':'Anel Dimensional V1','url':'https://app.notion.com/p/66ac2b324ede82118e97011ed3a526d3','fonte':'PARTY_MESTRE_ESPELHO','custo':'6 PA/dia V1','comentario':'V2 8 PA/dia é a linha ativa do dataset; sem duplicar UUID.'},
 {'uuid':'0e9c2b324ede833dbee501f46a9fb06f','item':'Manto Ilusório','url':'https://app.notion.com/p/0e9c2b324ede833dbee501f46a9fb06f','fonte':'PARTY_MESTRE_ESPELHO','custo':'44 por dia; sem unidade PA','comentario':'Não promover a 44 PA/dia.'},
 {'uuid':'621c2b324ede8203b55b01828ff0c069','item':'Magia Implacável','url':'https://app.notion.com/p/621c2b324ede8203b55b01828ff0c069','fonte':'PARTY_MESTRE_ESPELHO','custo':'+8 PA por.','comentario':'Frequência incompleta; não é PA/dia confirmado.'},
]

# Reconcilia também os 74 UUIDs adicionais da R05 (55 Mestre em consumíveis/técnicas,
# 17 Espelho e 2 semicanônicos). Não voltar de 182 para 171 por omissão de lote histórico.
r05=json.loads((root/'RESULTADOS/CORPUS_EXPANSAO_R05.json').read_text())['new_records']
tech_names=['Rajada Mística (B)','Criar Fogueira (B)','Sentido Bestial (P)','Faca de Gelo (P)','Lufada (P)','Marca do Caçador (P)','Raio de Fogo (P)','Ataque Certeiro (P)','Golpe de Zephyr (O)','Proteção Contra Lâminas (ON)','Destruição Trovejante (O)','Vínculo Com a Besta (O)','Repreensão Infernal (O)','Servo Invisível (O)','Benção (O)','Perdição (O)','Destruição Lancinante (O)','Toque Chocante (O)','Escudo Arcano (O)','Golpe Constritor (O)','Saraivada de Espinhos (O)','Amizade Animal (ON)','Enfeitiçar Pessoa (ON)','Orbe Cromática (ON)','Falar Com Criaturas (ON)','Imobilizar Pessoa (L)','Passos do Vazio','Tabela do Caos']
pill_names=['Pílula Concentração da Alma','Pílula Melhoramento Corporal Escarlate','Pílula de Melhoria Aprimorada','Pílula Renascimento do Reino da Alma','Pílula Visão Noturna','Pílula Assimilação Espiritual','Pílula da Desintoxicação','Pílula Essência do Abismo','Pílula de Melhoria','Pílula das Nove Transformações','Pílula Nutrição da Alma','Pílula de Salvamento Chen','Pílula de Vitalidade','Pílula Visão na Penumbra','Pílula do Vinho Quente','Pílula Agregação da Alma','Pílula Facilitadora de Avanço','Pílula Melhoramento da Alma','Pílula Realçamento Corporal','Pílula de Recuperação']
pot_names=['Óleo de Vedação','Poção de Liquidação','Poção de Paralisia','Poção Furiosa','Poção Pasta Nuvem','Poção Troca Atributos','Porção Rastreadora']
for i,entry in enumerate([x for x in r05 if x.get('source_domain') in ('MESTRE_CATALOGO_INDICE','MESTRE_CATALOGO_CONSUMIVEL')]):
 if i<28:entry['nome_calibracao']=tech_names[i];entry['familia_calibracao']='tecnicas_pergaminhos'
 elif i<48:entry['nome_calibracao']=pill_names[i-28];entry['familia_calibracao']='pilulas'
 else:entry['nome_calibracao']=pot_names[i-48];entry['familia_calibracao']='pocoes'
extra_mirror={
 'e25c2b324ede82bdb9c1014d4ffc5e76':('Ouro','Arma inteligente ricocheteia automaticamente por inimigos enquanto acertar.','Ofensiva multialvo sem limite de ricochetes determinado.'),
 '933c2b324ede82d8916481c591f5b842':('Ouro','Opala de inscrição confere resistência ao frio e infusão de fogo +1d6 em armas.','Efeito varia pela categoria de equipamento, sem tarifar 1d6 como bônus fixo.'),
}
for ex in r05:
 uid=ex['uuid']
 if uid in records:continue
 domain=ex.get('source_domain')
 if ex.get('source_type')=='ESPELHO_PARTY':
  src='PARTY_MESTRE_ESPELHO';fam='acessorios_aprimoramento';name=ex['name'];pa=ex.get('daily_pa_text_observed_noncalibration')
 elif ex.get('source_type')=='MESTRE_SEMICANONICO':
  src='MESTRE_SEMICANONICO_INCUBACAO';fam='artefatos_semicanonicos';name=ex['name'];pa=None
 else:
  src='CATALOGO_MESTRE_FORA_INDICE_88';fam=ex.get('familia_calibracao','tecnicas_pilulas_pocoes');name=ex.get('nome_calibracao') or uid;pa=None
 rk,eff,why=extra_mirror.get(uid,(None,'Ficha consultada sem custo PA/dia numérico tipado','Sem preço energético não entra na classificação solicitada.'))
 records[uid]={'uuid':uid,'item':name,'url':ex['url'],'fonte':src,'familia':fam,'pa_dia_historico':pa,
  'modalidade':'EXPLICITA' if pa is not None else 'AUSENTE',
  'rank_documental':None,'rank_analitico':rk,'selo_rank':'E3_PRE_CLASSIFICACAO' if rk else 'NAO_ANALISADO',
  'efeitos_resumidos':eff,'justificativa':why,'pendencias':'Classificação E3 não canonizada; imagem e três comparadores ainda pendentes.' if rk else '',
  'linha_independente':uid,'verificado_conector':'R05_BASELINE_RECONCILIADO_E_REABERTURA_DIRIGIDA',
  'versao_doc':'R05_BASELINE','nota_modalidade':'','pa_ativacao':None,
  'autoridade_rank':'CLASSIFICACAO_ANALITICA_NAO_CANONIZADA' if rk else 'PENDENTE',
  'a_reconciliar':False,'base_direta_da_regra':None,'delta_sinal':'NAO_APLICADO'}

rows=list(records.values());rows.sort(key=lambda r:(r['fonte'],r['familia'],r['item'].lower(),r['uuid']))
daily=[r for r in rows if isinstance(r['pa_dia_historico'],int)]
rank_order=['Bronze','Prata','Ouro','Ouro Negro','Lendário',None]
def stats(items):
 v=[x['pa_dia_historico'] for x in items]
 return {'fichas_uuids':len(v),'linhagens_conservadoras':len(set(x['linha_independente'] for x in items)),
  'min_PA_dia':min(v) if v else None,'mediana_PA_dia':statistics.median(v) if v else None,
  'max_PA_dia':max(v) if v else None,'media_PA_dia':round(statistics.mean(v),2) if v else None,
  'soma_PA_dia_amostra_NAO_ORCAMENTO':sum(v),'N_rank_documental':sum(bool(x['rank_documental']) for x in items),
  'N_rank_analitico_nao_oficial':sum(not x['rank_documental'] and bool(x['rank_analitico']) for x in items),
  'N_R_PA_DIA':sum(x['modalidade'] in ('R_PA_DIA','R_PA_DIA_INFERIDA','REGRA_R_PA_DIA') for x in items),
  'N_explicita_sem_RPA':sum(x['modalidade'] not in ('R_PA_DIA','R_PA_DIA_INFERIDA','REGRA_R_PA_DIA') for x in items)}
summary={}
for scope in ['CATALOGO_MESTRE_INDEXADO','PARTY_MESTRE_ESPELHO']:
 d=[x for x in daily if x['fonte']==scope]
 summary[scope]={'total':stats(d),'por_rank':{r or 'PENDENTE':stats([x for x in d if x['rank_analitico']==r]) for r in rank_order},
 'apenas_rank_documental':{r:stats([x for x in d if x['rank_documental']==r]) for r in rank_order if r}}

total_count=collections.Counter(x['fonte'] for x in rows)
# anexos extra não categorizados no censo da R03, mas fichas auditadas pontualmente. Informação de completeness explicitada.
metadata={'as_of':'2026-10-17','operation':'CONTINUIDADE_PA_R05_RANK_01_NAO_NOVA_OPERACAO','baseline':'PA_R05',
 'sources':{'atlas':'https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab','motor':'https://app.notion.com/p/3eec2b324ede8148a5b3ee17df578535'},
 'master_rules':weights,'note_attack':'1 ponto de BÔNUS em teste de ataque, não uma rolagem por ataque.',
 'note_ca':'somente CA obtida por magia, nunca CA inerente à armadura.',
 'denominator':{'baseline_r03_distinct_uuids':len(old),'baseline_r05_distinct_uuids':182,'new_uuids_since_R05':len(records)-182,'new_uuids_since_R03':len(records)-len(old),'unique_rows_total':len(rows),'historic_PA_day_fixed':len(daily),
  'rows_by_source':dict(total_count)},
 'coverage_limit':'União sem duplicatas do censo R03 (108), expansão R05 (74) e ampliação dirigida adicional do Espelho (52); NÃO representa universo de todas as páginas do Notion.'}

out=pathlib.Path('/mnt/data/PA_RANK_R06_DELIVERY');out.mkdir(exist_ok=True)
json.dump({'metadata':metadata,'rows':rows},open(out/'CENSO_CLASSIFICACAO_PA_RANK.json','w'),ensure_ascii=False,indent=2)
json.dump({'metadata':metadata,'summary':summary},open(out/'RESUMO_PA_POR_RANK.json','w'),ensure_ascii=False,indent=2)
json.dump(conditions,open(out/'AUDITORIA_COEFICIENTES_E_CONFLITOS.json','w'),ensure_ascii=False,indent=2)
json.dump(variable,open(out/'VARIANTES_E_UNIDADES_INDETERMINADAS.json','w'),ensure_ascii=False,indent=2)
fields=['uuid','item','fonte','familia','pa_dia_historico','modalidade','rank_documental','rank_analitico','selo_rank','base_direta_da_regra','delta_sinal','linha_independente','efeitos_resumidos','justificativa','pendencias','nota_modalidade','url','verificado_conector','versao_doc','autoridade_rank']
with open(out/'CENSO_PA_CLASSIFICACAO_ORDENAVEL.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore',delimiter=';');w.writeheader();w.writerows(rows)
with open(out/'SOMENTE_ITENS_COM_PA_DIA.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore',delimiter=';');w.writeheader();w.writerows(daily)
print(json.dumps({'metadata':metadata,'by_rank':summary},ensure_ascii=False,indent=2)[:15000])
