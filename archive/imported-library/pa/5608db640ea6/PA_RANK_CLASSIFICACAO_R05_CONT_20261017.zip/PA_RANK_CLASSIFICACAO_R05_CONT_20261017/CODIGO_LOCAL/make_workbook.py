import json, pathlib
from artifact_tool import Workbook, SpreadsheetFile
DIR=pathlib.Path('/mnt/data/PA_RANK_R06_DELIVERY')
js=json.loads((DIR/'CENSO_CLASSIFICACAO_PA_RANK.json').read_text())
items=[x for x in js['rows'] if isinstance(x.get('pa_dia_historico'),int)]
summary=json.loads((DIR/'RESUMO_PA_POR_RANK.json').read_text())['summary']
RANKS=['Bronze','Prata','Ouro','Ouro Negro','Lendário','PENDENTE']
wb=Workbook.create()
main=wb.worksheets.add('Resumo por rank')
master=wb.worksheets.add('Mestre')
mirror=wb.worksheets.add('Espelho')
conflicts=wb.worksheets.add('Auditoria regras')
methods=wb.worksheets.add('Regras e escopo')

header={'fill':'#163046','font':{'bold':True,'color':'#FFFFFF'},'row_height':29,'vertical_alignment':'center','wrap_text':True}
sub={'fill':'#EAF3F7','font':{'bold':True,'color':'#163046'},'row_height':27,'vertical_alignment':'center','wrap_text':True}
small={'font':{'color':'#566577','size':10}}

main.merge_cells('A1:K2')
main.get_range('A1').values=[['MAPA DE PA/DIA POR CLASSIFICAÇÃO — ASSIMILAÇÃO | MESTRE-SIDE']]
main.get_range('A1:K2').format={'fill':'#102F40','font':{'color':'#FFFFFF','bold':True,'size':17},'row_height':28,'vertical_alignment':'center'}
main.merge_cells('A3:K3')
main.get_range('A3').values=[['CONTINUIDADE R05 · Dados históricos separados por domínio · ranks analíticos E3 NÃO CANONIZADOS · 17/10/2026']]
main.get_range('A3:K3').format={'fill':'#DFEDF1','font':{'color':'#183548','size':10},'row_height':26}
main.get_range('A5:E5').values=[['Catálogo Mestre — fichas com PA/dia',14,'Espelho — fichas com PA/dia',80,'Total do recorte']]
main.get_range('F5').formulas=[['=B5+D5']]
main.get_range('A5:F5').format=sub
main.get_range('A7:K7').values=[['Rank','Mestre N','Mestre mínimo','Mestre mediana','Mestre máximo','Espelho N','Espelho mínimo','Espelho mediana','Espelho máximo','Mestre E0','Mestre E3']]
main.get_range('A7:K7').format=header
body=[]
for rank in RANKS:
 sm=summary['CATALOGO_MESTRE_INDEXADO']['por_rank'][rank]
 se=summary['PARTY_MESTRE_ESPELHO']['por_rank'][rank]
 def v(x):return x if x is not None else None
 body.append([rank,sm['fichas_uuids'],v(sm['min_PA_dia']),v(sm['mediana_PA_dia']),v(sm['max_PA_dia']),se['fichas_uuids'],v(se['min_PA_dia']),v(se['mediana_PA_dia']),v(se['max_PA_dia']),sm['N_rank_documental'],sm['N_rank_analitico_nao_oficial']])
main.get_range('A8:K13').values=body
main.merge_cells('A15:K15');main.get_range('A15').values=[['O quadro mistura ranks DOCUMENTAIS E0 e pré-ranks E3. Use para exploração, não como tarifa por rank. N=0 não significa PA=0.']]
main.merge_cells('A16:K16');main.get_range('A16').values=[['Catálogo Mestre: 12 custos explícitos + 2 dependentes de R-PA-DIA; Espelho: 78 explícitos + 2 R-PA-DIA. Nenhuma fonte da Party foi alterada.']]
main.merge_cells('A17:K17');main.get_range('A17').values=[['Duas peças Mestre com textos coincidentes (IMPERIAL / Veste Dragão) e duas pares Espelho compartilham linhagens; N da tabela conta UUIDs.']]
main.merge_cells('A18:K18');main.get_range('A18').values=[['Para cálculo energético NÃO usar as medianas por rank como coeficientes. Atlas classifica efeito sem olhar PA e sem usar preço.']]
main.get_range('A15:K18').format.wrap_text=True
main.get_range('A15:K18').format.row_height=28
main.get_range('A15:K18').format.font.color='#40566A'
for col,w in {'A':19,'B':12,'C':15,'D':17,'E':15,'F':13,'G':16,'H':18,'I':17,'J':14,'K':14}.items():
 main.get_range(f'{col}:{col}').format.column_width=w
try:
 chart=main.charts.add('bar',main.get_range('A7:B13'))
 chart.title_text='Fichas Mestre por rank (E0 e E3)'
 chart.bar_options.direction='column'
 chart.set_position('B21','J39')
except Exception as e:print('chart skipped',str(e)[:250])

columns=['Item','Família','PA/dia histórico','Rank analítico','Grau da classificação','Rank da ficha','Piso coeficientes Mestre','Histórico – piso','Modalidade diária','Pendências','Efeitos dominantes','Fonte (URL)','UUID','Linhagem textual']
def format_items(sh,values):
 sh.merge_cells('A1:N2');sh.get_range('A1').values=[[('CATÁLOGO MESTRE' if sh.name=='Mestre' else 'ESPELHO MESTRE / PARTY')+' · ITENS COM CUSTO DE PA/DIA']]
 sh.get_range('A1:N2').format={'fill':'#102F40','font':{'bold':True,'color':'#FFFFFF','size':16},'row_height':27,'vertical_alignment':'center'}
 sh.get_range('A3:N3').values=[columns];sh.get_range('A3:N3').format=header
 mat=[]
 for r in values:
  mat.append([r['item'],r['familia'],r['pa_dia_historico'],r['rank_analitico'] or 'PENDENTE',r['selo_rank'],r['rank_documental'] or '',r['base_direta_da_regra'],None,r['modalidade'],r['pendencias'] or r['nota_modalidade'],r['efeitos_resumidos'],r['url'],r['uuid'],r['linha_independente']])
 if mat:
  n=3+len(mat)
  sh.get_range(f'A4:N{n}').values=mat
  for k in range(4,n+1):
   sh.get_range(f'H{k}').formulas=[[f'=IF(ISNUMBER(G{k}),C{k}-G{k},"")']]
  sh.get_range(f'C4:H{n}').set_number_format('0.##')
  sh.get_range(f'D4:E{n}').format.column_width=19
  sh.get_range(f'I4:K{n}').format.wrap_text=True
  sh.get_range(f'G4:H{n}').conditional_formats.add_cell_is({'operator':'lessThan','formula':0,'format':{'fill':'#FBE2E2','font':{'color':'#9D1A21','bold':True}}})
  try:sh.tables.add(f'A3:N{n}',True,'Table'+sh.name)
  except Exception as e:print('table skipped',sh.name,str(e)[:150])
  sh.freeze_panes.freeze_rows(3)
 for c,w in {'A':37,'B':22,'C':17,'D':18,'E':25,'F':17,'G':22,'H':19,'I':22,'J':48,'K':48,'L':47,'M':37,'N':38}.items():sh.get_range(f'{c}:{c}').format.column_width=w
 sh.get_range('A3:N3').format.row_height=36

master_values=sorted((x for x in items if x['fonte']=='CATALOGO_MESTRE_INDEXADO'),key=lambda x:(x['rank_analitico'] or 'Z',x['pa_dia_historico']))
mirror_values=sorted((x for x in items if x['fonte']=='PARTY_MESTRE_ESPELHO'),key=lambda x:(x['rank_analitico'] or 'Z',x['pa_dia_historico']))
format_items(master,master_values)
format_items(mirror,mirror_values)

con=json.loads((DIR/'AUDITORIA_COEFICIENTES_E_CONFLITOS.json').read_text())
conflicts.merge_cells('A1:G2');conflicts.get_range('A1').values=[['AUDITORIA DOS COEFICIENTES DO MESTRE · SEM MODIFICAÇÃO DAS FICHAS']]
conflicts.get_range('A1:G2').format={'fill':'#102F40','font':{'bold':True,'color':'#FFFFFF','size':14},'row_height':28}
conflicts.get_range('A3:G3').values=[['Item','UUID','Componentes','Exigência calculável','Valor antigo','Condição','Justificativa / limite']]
conflicts.get_range('A3:G3').format=header
conflicts.get_range(f'A4:G{3+len(con)}').values=[list(q) for q in con]
for c,w in {'A':35,'B':36,'C':46,'D':24,'E':24,'F':32,'G':70}.items():conflicts.get_range(f'{c}:{c}').format.column_width=w
conflicts.freeze_panes.freeze_rows(3)

methods.merge_cells('A1:F2');methods.get_range('A1').values=[['REGRAS E GOVERNANÇA · R05 CONTINUIDADE']]
methods.get_range('A1:F2').format={'fill':'#102F40','font':{'bold':True,'color':'#FFFFFF','size':14},'row_height':28}
lines=[
 ['Regra 1','+1 atributo permanente','5 PA/dia','Decisão expressa do Mestre','Não tarifa níveis, modificadores temporários ou atributos-alvo condicionais sem magnitude efetiva.',''],
 ['Regra 2','+1 dano adicional','1 PA/dia','Decisão expressa do Mestre','Não tarifar todo dano-base da arma; dados variáveis exigem definição de média/máximo.',''],
 ['Regra 3','+1m deslocamento adicional','1 PA/dia','Decisão expressa do Mestre','Não equiparar +alcance, teleporte, voo ou velocidade de natação à corrida sem decisão.',''],
 ['Regra 4','+1 ponto em teste de ataque','1 PA/dia','Decisão expressa do Mestre','Interpretação operacional: bônus no valor do teste, não custo de cada teste realizado.',''],
 ['Regra 5','+1 CA oriunda de magia','1 PA/dia','Decisão expressa do Mestre','Excluir CA própria da armadura e bônus do escudo físico; CA condicional anotada.',''],
 ['R-PA-DIA','N PA no final da ficha','custo diário interpretado','Motor de Classificação PR-ECO','Somente sem contexto ativo/turno/golpe contraditório; preservar status inferido.','https://app.notion.com/p/3eec2b324ede8148a5b3ee17df578535'],
 ['CLASSIFICAÇÃO','E0: rank explícito','Documental, Mestre ou Espelho','Atlas de Poder A','Não derivar rank de PA/dia, preço MED ou rank do usuário.','https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'],
 ['CLASSIFICAÇÃO','E3: pré-rank','Provisório, não canônico','Atlas de Poder A','Inspeção de imagens, comparadores 3/eixos e classificação final competentes ainda pendentes.','https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'],
 ['DOMÍNIOS','Catálogo Mestre e Espelho','NÃO COMBINAR PARA INFERÊNCIA','MESTRE-SIDE','Distribuições empíricas separadas e com linhagens; fonte Party-Espelho não serve de calibração canônica Mestre.',''],
 ['PROIBIÇÕES','Nunca registrar auditoria na ficha','NO-WRITE','Ordem expressa do Mestre 17/10','Sem mutações Notion; diários e decisões apenas em destinos governados por writer autorizado.',''],
 ['LIMITAÇÃO','Corpus rastreado = 234 UUIDs','NÃO UNIVERSO GLOBAL','Baseline R03 + anexos','Itens com custo numérico fixo identificados =94; variável e sem unidade guardados fora das estatísticas.',''],
]
methods.get_range('A4:F4').values=[['Tipo','Efeito','Parâmetro','Autoridade','Observação / exceção','Fonte URL']]
methods.get_range('A4:F4').format=header
methods.get_range(f'A5:F{4+len(lines)}').values=lines
for c,w in {'A':20,'B':43,'C':32,'D':36,'E':95,'F':55}.items():methods.get_range(f'{c}:{c}').format.column_width=w
methods.freeze_panes.freeze_rows(4)

path=DIR/'MAPA_PA_DIA_POR_RANK_20261017.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(path))
print('OUTPUT',path, path.stat().st_size)
try:
 print('Dashboard inspection',wb.inspect({'kind':'table','range':'Resumo por rank!A7:K13','include':'values,formulas','table_max_rows':7,'table_max_cols':11}).ndjson[:1600])
except Exception as e:print('inspect skipped',str(e)[:200])
