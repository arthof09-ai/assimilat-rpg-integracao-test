# Sistema Universal de PA — Classificação por rank e auditoria dos custos diários

**AS-OF:** 17/10/2026 · **Ambiente:** MESTRE-SIDE · **Operação:** continuidade da responsabilidade PA existente; não foi criado OP-ID. · **Baseline:** R01–R05 · **Produção e receitas:** HOLD.

## Determinações do Mestre (autoridade expressa, não regressão)

| Componente contínuo | Regra de manutenção |
|---|---:|
| +1 ponto de atributo | **5 PA/dia** |
| +1 ponto de dano **adicional** | **1 PA/dia** |
| +1 m de deslocamento **adicional** | **1 PA/dia** |
| +1 ponto de bônus em teste de ataque | **1 PA/dia** |
| +1 CA **produzida por magia** | **1 PA/dia** |

**Interpretação operacional declarada:** “1 teste de ataque” foi lido como **+1 de bônus em um teste de ataque**; não como uma cobrança por rolagem. Arma comum, armadura física, CA-base, dano-base, salvaguarda, Reflexo, RDM, RD, cura, controle, CD de magias, cargas, dados de dano variável, alcance e teleportes não receberam taxas fictícias. Custos por uso não foram convertidos em custos por dia.

## Escopo e cuidado com o denominador

- 108 UUIDs da R03 (88 catálogo Mestre, 18 Espelho, 2 semicanônicos), recuperados no pacote R05.
- 74 UUIDs da expansão R05 (55 Mestre fora do índice, 17 Espelho, 2 semicanônicos), com duplicação reconciliada.
- 52 UUIDs adicionais desta rodada (ampliação dirigida do Espelho), após deduplicação.
- **União: 234 UUIDs** = 143 catálogo Mestre + 87 Espelho + 4 semicanônicos.
- **94 fichas com valor fixo diário numérico:** 14 catálogo Mestre (12 explícitos + 2 R-PA-DIA); 80 Espelho (78 explícitos + 2 R-PA-DIA).
- 1 custo variável (10 PA/dia por anel), versões históricas alternativas e linhas sem unidade foram preservadas separadamente e não inflam o denominador.
- **Não é censo exaustivo de todo o Notion.** Itens no Espelho não são tratados como amostras independentes autorizadas do catálogo Mestre. Itens sem PA numérico não viram custo zero.

O Atlas Canônico ordena **classificar pela potência do efeito, sem ver preço/PA**, e distingue rank público de FIP interna. As propostas E3 não foram canonizadas e estão abertas a inspeção de imagem, comparação com sistema/personagem/efeito e fronteira de patamar. Zero estrelas de item foram inventadas.

## Distribuição histórica de PA/dia por rank

Os valores são **gastos históricos observados**, não coeficientes de PA calculados por rank. Os ranks E3 são uma alocação provisória, portanto todas as estatísticas abaixo são **exploratórias**.

### Catálogo Mestre — 14 UUIDs com PA/dia

| Rank documental ou técnico | N | Mediana PA/dia | Mín–máx PA/dia | E0 documental | E3 técnico |
|---|---:|---:|---:|---:|---:|
| Bronze | 0 | — | —–— | 0 | 0 |
| Prata | 2 | 17 | 14–20 | 0 | 2 |
| Ouro | 5 | 25 | 18–34 | 0 | 5 |
| Ouro Negro | 4 | 45 | 15–112 | 2 | 2 |
| Lendário | 2 | 332 | 64–600 | 2 | 0 |
| PENDENTE | 1 | 15 | 15–15 | 0 | 0 |

Os únicos ranks documentais no subconjunto Mestre com PA/dia são **2 Ouro Negro** (Adaga Serpente 35, Armadura Guardiã Elemental 55) e **2 Lendário** (Arco Exterminador Elemental 64, Espada do Lendário 600). A Espada é um **outlier degradado**; portanto, 332 PA/dia (mediana Lendário de dois itens) **não é tarifa Lendária**, e a mediana Ouro Negro de 45 em dois itens também não é parâmetro universal. Não existem observações Mestre **Bronze** com PA/dia e rank documental nesta coorte.

### Espelho Mestre da Party — 80 UUIDs com PA/dia

| Rank documental ou técnico | N | Mediana PA/dia | Mín–máx PA/dia |
|---|---:|---:|---:|
| Bronze | 8 | 8 | 4–12 |
| Prata | 28 | 11 | 6–22 |
| Ouro | 30 | 20 | 8–65 |
| Ouro Negro | 9 | 25 | 14–95 |
| Lendário | 3 | 90 | 70–385 |
| PENDENTE | 2 | 19 | 14–24 |

As **80 fichas do Espelho** incluem a Adaga Mortal Jaku com rank nominal Lendário explícito e outras **77 pré-classificações** E3, além de **2 pendências de rank**. Não representam uma amostra independente do catálogo Mestre; distribuições separadas por desenho.

## Divergências objetivas e parcialidades

| Item | Histórico | Parcela calculável pela nova regra | Diagnóstico |
|---|---:|---:|---|
| [Sabedoria Ancestral](https://app.notion.com/p/3edc2b324ede815699adc0412e96ea2b) | 20 PA (R-PA-DIA) | +10 SAB = **50 PA/dia** | Insuficiência ≥30 PA/dia só pelo atributo; comunicação e memória não tarifadas. |
| [Colar Cadente](https://app.notion.com/p/3edc2b324ede810daba2cc509677856c) | 14 PA/dia | +2 SAB =10, sob estrelas +4 SAB =**20** | Conflito de 6 PA no modo estelar, se bônus total =+4. |
| [Amuleto de Inteligência — Espelho](https://app.notion.com/p/0c4c2b324ede83dd8e1881b52a79e326) | 30 PA (R-PA-DIA) | +10 INT =**50 PA/dia** | Déficit mínimo 20; variante +20 dano aumenta diferença, RDM permanece desconhecida. |
| [Armadura de Zephyr — Espelho](https://app.notion.com/p/a23c2b324ede829bb8168165991577ff) | 90 PA/dia | +15 DES=75, +15m=15, +25 ataque=25, +50 dano/turno=50; **165** | Déficit condicional ≥75 PA; CA física +11 **não foi tarifada**. |
| [Manto de Proteção — Espelho](https://app.notion.com/p/761c2b324ede8201be5081ea69e97f10) | 10 PA/dia | +2 CA mágica =**2** | Excesso 8 sem benefício textual adicional; marcar para correção, não inventar manutenção-base. |
| [Bota Caminho Veloz](https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c) | 18 PA/dia + 5 por uso | +6m = **6 PA/dia** | Outros 12 PA históricos não identificam custos de atravessar terreno/não deixar rastros. |
| [Arremessável — Espelho](https://app.notion.com/p/a09c2b324ede823cafb60158afb31a46) | 11 PA/dia | +3 ataque +8 dano = **11** | Coincidência numérica não tarifa o retorno gratuito da arma. |

**Cuidados:** o custo isolado de +390 ou dados da fórmula da Espada do Lendário NÃO foi presumido como “bônus de dano adicional”. Seu subtotal seguro pelas novas regras é +60 FOR (300 PA/dia) +75 ataque (75 PA/dia) = **375 PA/dia**, restando 225 historicamente sem decomposição.

## Variantes, ambiguidades e dependência

- **Sabedoria Ancestral, Adaga Serpente, Amuleto Inteligência e Escudo Sentinela:** diário depende de R-PA-DIA; no relatório há flags e URL.
- **IMPERIAL / Veste Dragão:** 2 páginas, texto e custo 25 iguais, **1 linhagem textual provisória**; contar duas fichas físicas, não duas origens técnicas independentes.
- **Olhos nas Costas** (arma/armadura) e **Talismãs Bem/Mal**: duas famílias de efeitos correlatos no Espelho; não duplicar poder ao calibrar.
- **Anel Dimensional, Trespassar e Impacto Estonteante:** versões históricas V1/V2 com custos diferentes guardadas separadamente; **1 UUID por página**, apenas a variante V2 do relatório entra no resumo.
- **Amuleto Extensor:** 10 PA/dia por anel inserido, depende de N; fora do relatório de valores fixos.
- **Manto Ilusório:** texto “44 por dia” SEM unidade; não registrar 44 PA/dia.
- **Magia Implacável:** texto “+8 PA por.” sem frequência; não registrar 8 PA/dia.
- **CA física:** +11 CA da Armadura de Zephyr, +8 CA de Bastião e Armadura Anã são atributos do equipamento físico até prova de fração mágica; nunca aplicar 1 PA/CA por suposição.
- **Custo por uso:** não converter em PA/dia; há objetos com manutenção e ativação simultâneas.

## Pendências de classificação (não inventar Bronze)

1. **Amuleto Tempo Eterno** — 15 PA/dia, texto informa tempo mais rápido, mas não quantifica escala/efeito; sem rank técnico justificável.
2. **Olho Mágico** — 24 PA/dia no Espelho, mecânica textual ausente.
3. **Amuleto da Dor** — 14 PA/dia no Espelho, mecânica textual ausente.

## Governança de registros — ZERO CONTAMINAÇÃO

Esta entrega foi produzida **fora do Notion**, exclusivamente nos arquivos deste pacote. Não foi anexado relatório, diário, PSV ou anotação a fichas de itens, bestas, NPCs ou Party. No Notion, eventual registro deve ser endereçado pelo responsável competente **somente ao Diário/Inbox/Assignment oficial previstos na governança**, com writer/lease verificados; as páginas de conteúdo preservam apenas o conteúdo da entidade. Nenhum rank provisório E3 foi escrito em ficha pública. No-work on CRAFT recipes; C19-021 UNKNOWN e produção HOLD preservados.

## Arquivos de auditoria

- `MAPA_PA_DIA_POR_RANK_20261017.xlsx`: visão por rank e abas Mestre, Espelho, Auditoria e Regras.
- `SOMENTE_ITENS_COM_PA_DIA.csv`: 94 linhas com UUID, URL, família, rank, selo, valor e pendências.
- `CENSO_PA_CLASSIFICACAO_ORDENAVEL.csv`: 234 páginas, inclusive sem valor de PA/dia.
- `CENSO_CLASSIFICACAO_PA_RANK.json`: dados estruturados completos.
- `RESUMO_PA_POR_RANK.json`: denominadores e estatísticas.
- `VARIANTES_E_UNIDADES_INDETERMINADAS.json`: versões e casos sem unidade clara.
- `CATALOGO_COMPLETO_RANQUEADO.md`: lista completa com todos os 94 itens.

**Aceite proporcional:** censo e pré-classificação por efeitos concluídos neste recorte; classificação definitiva E3, cobertura global, coeficientes desconhecidos, holdout nativo CRAFT e NAC-PASS produtivo permanecem HOLD.
