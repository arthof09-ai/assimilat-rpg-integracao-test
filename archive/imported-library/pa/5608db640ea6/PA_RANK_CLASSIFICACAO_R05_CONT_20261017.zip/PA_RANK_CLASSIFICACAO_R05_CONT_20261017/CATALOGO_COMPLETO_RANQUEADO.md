# Catálogo completo — fichas com gasto numérico de PA/dia

**17/10/2026 · MESTRE-SIDE · Somente fontes Mestre ou Espelho Mestre — Party NO-WRITE.**

Legenda: **E0** = rank explicitamente documentado na respectiva fonte; **E3** = pré-classificação de trabalho, **não canônica**; **PENDENTE** = descrição insuficiente. **RPA** = custo diário interpretado por R-PA-DIA, ainda condicional à verificação do contexto. O PA é custo histórico, **não preço recalculado**. Fontes do Espelho não entram na calibração Mestre.

## Catálogo Mestre

### Prata — 2 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Colar cadente](https://app.notion.com/p/3edc2b324ede810daba2cc509677856c) | 14 | Prata | E3 | +2 SAB permanente, +4 SAB à luz das estrelas: bônus restrito e local. |
| [Traje águia celeste](https://app.notion.com/p/3edc2b324ede816cbad5ca3880ce144d) | 20 | Prata | E3 | Percepção +4, CA condicional +2 e salto 4,5m ativável; versatilidade pessoal restrita. |

### Ouro — 5 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Bota Caminho Veloz](https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c) | 18 | Ouro | E3 | Atravessar superfícies aquáticas/instáveis, furtividade e bônus móvel; bypass do terreno eleva além de bônus simples. |
| [Sabedoria Ancestral](https://app.notion.com/p/3edc2b324ede815699adc0412e96ea2b) | 20 (RPA) | Ouro | E3 | +10 SAB e suporte cognitivo/telepático persistente, alcance da telepatia não delimitado. |
| [IMPERIAL](https://app.notion.com/p/3edc2b324ede817897f1cdf5dea0cb70) | 25 | Ouro | E3 | Texto mecânico idêntico ao da Veste Dragão, dependência de linhagem não encerrada. |
| [Veste Dragão Ascendente](https://app.notion.com/p/3edc2b324ede81948c88f917a40e50fa) | 25 | Ouro | E3 | Precisão, Reflexo, deslocamento e RDM contra magias determinadas em conjunto. |
| [SOMBRA SUSSURRANTE](https://app.notion.com/p/3edc2b324ede812c9b54c261934696e6) | 34 | Ouro | E3 | Defesa multifuncional, furtividade, invisibilidade curta e recuperação PA sob condição; falta benchmark visual. |

### Ouro Negro — 4 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Pulseira da Rocha Magica](https://app.notion.com/p/3edc2b324ede81948833eb6f4a5ef488) | 15 | Ouro Negro | E3 | Imunidade a petrificação e conjuração de transformar em pedra com risco de retorno e exaustão do item. |
| [Adaga da Serpente Enfeitiçada (ON)](https://app.notion.com/p/3edc2b324ede811787a0de913622b14d) | 35 (RPA) | Ouro Negro | E0 | Rank documental registrado na ficha do catálogo. |
| [Armadura Guardiã Elemental (ON)](https://app.notion.com/p/3edc2b324ede8127a576ee01c44bd1d4) | 55 | Ouro Negro | E0 | Rank documental registrado na ficha do catálogo. |
| [Coroa Reino Esplendor](https://app.notion.com/p/3edc2b324ede8144a3aed184b14275d4) | 112 | Ouro Negro | E3 | Amplo repertório de magias de controle/execução e visão no escuro, limitado por cargas e maldição; equivalência mecânica das magias ext |

### Lendário — 2 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Arco Exterminador Elemental (L)](https://app.notion.com/p/3edc2b324ede8156849bf1aae0ce9fb5) | 64 | Lendário | E0 | Rank documental registrado na ficha do catálogo. |
| [Espada do Lendário](https://app.notion.com/p/3edc2b324ede81ab9e22e168f6d939a9) | 600 | Lendário | E0 | Rank documental registrado na ficha do catálogo. |

### PENDENTE — 1 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Amuleto Tempo Eterno](https://app.notion.com/p/3edc2b324ede8132bbc8f857f4b276c4) | 15 | PENDENTE | PENDENTE | Sem magnitude quantificada do tempo acelerado; impossível definir efeito dominante, comparadores e rank. |


## Espelho Mestre da Party

### Bronze — 8 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Mira Apurada](https://app.notion.com/p/65fc2b324ede838d9e5181b614b8da6a) | 4 | Bronze | E3 | Aperfeiçoamento preciso, restrito ao alvo e turno. |
| [Chifre do Alarme Silencioso](https://app.notion.com/p/f76c2b324ede835ca8de01e778e4ff12) | 5 | Bronze | E3 | Suporte informacional sem ofensiva/controle. |
| [Alcance Aprimorado](https://app.notion.com/p/f25c2b324ede83caaffa81b3fc5a6485) | 6 | Bronze | E3 | Ampliação de alcance local simples, não deslocamento. |
| [Armadura Anã](https://app.notion.com/p/5f7c2b324ede83de9c7a81fcb19b0195) | 6 | Bronze | E3 | +2 CA da armadura e penalidade de peso/movimento; origem física incerta. |
| [Manto de Proteção](https://app.notion.com/p/761c2b324ede8201be5081ea69e97f10) | 10 | Bronze | E3 | Defesa simples e localizada. |
| [Olho de Ersatz](https://app.notion.com/p/045c2b324ede83b9bee381dec251e087) | 12 | Bronze | E3 | Reparo funcional pessoal sem percepção extraordinária. |
| [Botas de Pegadas Falsas](https://app.notion.com/p/24ec2b324ede82eea4b9018eb01eb219) | 12 | Bronze | E3 | Engano local sem combate. |
| [Manto da Moda](https://app.notion.com/p/ba0c2b324ede834c920d01390e3aac12) | 12 | Bronze | E3 | Utilidade social localizada, sem mecânica de combate. |

### Prata — 28 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Eficiência Mágica](https://app.notion.com/p/9b7c2b324ede83f4af7e01c90cb6efaf) | 6 | Prata | E3 | Economia recorrente de recurso mágico. |
| [Magia Aprimorada](https://app.notion.com/p/b8ac2b324ede827e9dbf81061dcde8d4) | 6 | Prata | E3 | Amplificação ofensiva direta limitada. |
| [Foco Arcano](https://app.notion.com/p/54fc2b324ede8349862001ed2929ac98) | 7 | Prata | E3 | Especialização de canalização de magia. |
| [Viciada](https://app.notion.com/p/b0bc2b324ede8347832201d7b0c9572c) | 7 | Prata | E3 | Dano condicionado a acerto crítico. |
| [Adamante](https://app.notion.com/p/1d2c2b324ede8343be42810a0b54f1d2) | 7 | Prata | E3 | Anula acertos críticos, proteção passiva confiável. |
| [Mobilidade](https://app.notion.com/p/383c2b324ede820ab38881abbe91ac60) | 7 | Prata | E3 | +2 CA condicional à ação de movimento; benefício tático curto. |
| [Alerta](https://app.notion.com/p/92bc2b324ede83be863b01a5d6aba48b) | 8 | Prata | E3 | Percepção protetora confiável, tática individual. |
| [Arma Mortal](https://app.notion.com/p/9e9c2b324ede82e3a83d019717e0d51c) | 8 | Prata | E3 | Amplificação precisa com efeito exclusivamente ofensivo. |
| [Estender Magia](https://app.notion.com/p/15cc2b324ede832589b801eb0e0d2554) | 8 | Prata | E3 | Ampliação de sustentação temporal, dependente da magia. |
| [Exterminadora de Monstros](https://app.notion.com/p/064c2b324ede8304b2d301e0835cc0c4) | 8 | Prata | E3 | Especialização situacional, sem escopo universal. |
| [Manto de Elvenkind](https://app.notion.com/p/426c2b324ede833a89ba81706507f192) | 8 | Prata | E3 | Especialização furtiva persistente. |
| [Mitral](https://app.notion.com/p/16cc2b324ede831290f801af40e0e5bc) | 8 | Prata | E3 | Remoção de penalidades de armadura e restauração de movimento; não +3m absoluto. |
| [Vitalidade](https://app.notion.com/p/e56c2b324ede82a898bb8137c2d8d0f3) | 8 | Prata | E3 | PV por nível de personagem, dependente do usuário; escala exige contenção e análise. |
| [Arremessável](https://app.notion.com/p/a09c2b324ede823cafb60158afb31a46) | 11 | Prata | E3 | Ofensiva recorrente e retorno sem perda de ação. |
| [Defensora](https://app.notion.com/p/aeec2b324ede83f69a110153bde2fc86) | 11 | Prata | E3 | Especialização marcial com conversão defensiva por turno. |
| [Olhos nas Costas (arma)](https://app.notion.com/p/fc0c2b324ede82a2a2cf01796265a4c2) | 11 | Prata | E3 | Mesmo texto da versão armadura; dependência de linhagem. |
| [Olhos nas Costas](https://app.notion.com/p/c42c2b324ede8259995e81a2461f46e2) | 11 | Prata | E3 | Reação de ataque e movimento ao ser flanqueado pela primeira vez. |
| [Amuleto dos Ventos](https://app.notion.com/p/2b9c2b324ede835d9e8501cbbe90d44a) | 12 | Prata | E3 | Mobilidade pessoal e Reflexo, alcance/voo incertos. |
| [Escudo Apanhador de Flechas](https://app.notion.com/p/e87c2b324ede8240842d0145e2496568) | 14 | Prata | E3 | Proteção de aliados seletiva por reação. |
| [Anel de Queda Suave](https://app.notion.com/p/cf3c2b324ede82d49d7981a926c0bd52) | 15 | Prata | E3 | Mobilidade vertical e segurança situacional. |
| [Óculos Noturnos S.P](https://app.notion.com/p/83ec2b324ede82e4b28b01c5f2f5dd98) | 15 | Prata | E3 | Percepção especializada local. |
| [Escudo de Atração de Projéteis](https://app.notion.com/p/1f4c2b324ede823c8339815f36a2f2ae) | 15 | Prata | E3 | Mitigação específica, maldição pendente. |
| [Escudo Sentinela](https://app.notion.com/p/29ac2b324ede82d8a46e814c05fcfb77) | 15 (RPA) | Prata | E3 | Antecipação e vigilância; R-PA-DIA inferido por linha final. |
| [Manto Resistência Mágica](https://app.notion.com/p/05dc2b324ede8272a0b58113edf5466e) | 15 | Prata | E3 | Defesa contra magia por salvaguarda. |
| [Amplificador de Atributo](https://app.notion.com/p/3c6c2b324ede82baa4a801de533a5975) | 15 | Prata | E3 | +3 atributo pessoal, magnitude pequena; sem outros efeitos descritos. |
| [Arco Justiça Celestial](https://app.notion.com/p/663c2b324ede83a4a63f01e0c184a35a) | 18 | Prata | E3 | Percepção persistente; dano condicional insuficiente para rank alto. |
| [Botas do Inverno](https://app.notion.com/p/3d5c2b324ede8243a47d01ff084ebdd2) | 20 | Prata | E3 | Sobrevivência e mobilidade em bioma específico. |
| [Anel de Resistência](https://app.notion.com/p/81bc2b324ede8282b47781c7d616708b) | 22 | Prata | E3 | Proteção permanente, mas específica ao elemento. |

### Ouro — 30 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Sai da Frente](https://app.notion.com/p/c5fc2b324ede8311b20c015f84694644) | 8 | Ouro | E3 | Permite ofensiva em área sem fogo amigo mecânico. |
| [Anel Dimensional Vinculado V²](https://app.notion.com/p/66ac2b324ede82118e97011ed3a526d3) | 8 | Ouro | E3 | Bypass espacial e acesso compartilhado; V1 de 6 PA preservada. |
| [Marítima](https://app.notion.com/p/be9c2b324ede83108c3d016dc6ffba91) | 8 | Ouro | E3 | Natação igual à caminhada e salvaguarda contra submersão inconsciente. |
| [Impacto Estonteante](https://app.notion.com/p/a8ec2b324ede83e9b69a81affb4e1447) | 11 | Ouro | E3 | Controle repetível além de penalidade ofensiva; V1 8 PA preservada. |
| [Força Bruta](https://app.notion.com/p/b67c2b324ede8393a34f81f2162ab84a) | 12 | Ouro | E3 | Bypass de resistência contra múltiplos efeitos. |
| [Anel de Evasão](https://app.notion.com/p/780c2b324ede82f69ae8818e612b7ad2) | 13 | Ouro | E3 | Garantia limitada contra falhas, alta confiabilidade. |
| [Arma Inteligente](https://app.notion.com/p/e25c2b324ede82bdb9c1014d4ffc5e76) | 13 | Ouro | E3 | Ofensiva multialvo sem limite de ricochetes determinado. |
| [Trespassar](https://app.notion.com/p/9e8c2b324ede82dda72581434c7a7ce5) | 14 | Ouro | E3 | Economia de ações escalável por abates; V1 10 PA preservada. |
| [Anel de Andar na Água](https://app.notion.com/p/758c2b324ede82b0a49b81b94d15cfc5) | 14 | Ouro | E3 | Bypass de terreno aquático contínuo. |
| [Juramento](https://app.notion.com/p/140c2b324ede82d7995901575507a36a) | 16 | Ouro | E3 | Rastreio e neutralização de cobertura mais dano contra um alvo persistente. |
| [Magias Devastadoras](https://app.notion.com/p/da4c2b324ede827d97180107a0d52b6e) | 16 | Ouro | E3 | Aumento ofensivo em duas técnicas persistentes. |
| [Escudo de Proteção Contra Magia](https://app.notion.com/p/99cc2b324ede82b2870b8141b72829cd) | 16 | Ouro | E3 | Defesa mágica ampla com múltiplas camadas. |
| [Opala de Inscrição Ild](https://app.notion.com/p/933c2b324ede82d8916481c591f5b842) | 16 | Ouro | E3 | Efeito varia pela categoria de equipamento, sem tarifar 1d6 como bônus fixo. |
| [Sucesso Atrai Sucesso](https://app.notion.com/p/298c2b324ede8287a59581a988b13d3c) | 18 | Ouro | E3 | Escalonamento ofensivo ao longo do encontro. |
| [Sangramento](https://app.notion.com/p/7d9c2b324ede83698dc381e76c958649) | 19 | Ouro | E3 | Negação de cura, múltiplas aplicações e duração em combate. |
| [Bracelete da Calma](https://app.notion.com/p/56cc2b324ede823586be01440f7a68ef) | 21 | Ouro | E3 | Proteção e restauração de recursos, múltiplas funções. |
| [CAJADO VÓRTEX SOMBRIO](https://app.notion.com/p/9efc2b324ede8250a37981fb1fef45dd) | 21 | Ouro | E3 | Amplificação de sombras, CD e controle gravitacional com ataques mágicos múltiplos. |
| [Bastião de Virilia](https://app.notion.com/p/622c2b324ede8213a609818e7ef09a9a) | 24 | Ouro | E3 | Defesa elemental e presença de combate, CA física não tarifada. |
| [Couraça de Eos](https://app.notion.com/p/089c2b324ede837c9e590174fcc33291) | 24 | Ouro | E3 | Cura repetível com defesa e debuff ativo. |
| [Relâmpago Avassalador](https://app.notion.com/p/647c2b324ede822787a8011d2002490c) | 25 | Ouro | E3 | Área, controle de alcance e dano elétrico relevante em encontro. |
| [Adaga de Envenenamento Mortal](https://app.notion.com/p/fcac2b324ede8260a9cf01d141dae809) | 26 | Ouro | E3 | Veneno com condição e limite, acima de dano puro. |
| [Talismã Mal Supremo](https://app.notion.com/p/25dc2b324ede828bae40819b5068b040) | 26 | Ouro | E3 | Versão espelhada do talismã, dependente da família técnica. |
| [Talismã Pura Bondade](https://app.notion.com/p/570c2b324ede8333abe281e55dd13713) | 26 | Ouro | E3 | Dano reativo persistente contra perfis definidos. |
| [Anel de Cativar Criaturas](https://app.notion.com/p/041c2b324ede83f5a9ae8131af38c2b9) | 27 | Ouro | E3 | Controle de criaturas com limite de cargas e CD16. |
| [Relicário dos Segredos](https://app.notion.com/p/d6fc2b324ede82e0b26981462a737826) | 30 | Ouro | E3 | Proteção e preservação de informação importante. |
| [(AI) Amuleto de Inteligência](https://app.notion.com/p/0c4c2b324ede83dd8e1881b52a79e326) | 30 (RPA) | Ouro | E3 | +10 INT e +20 dano mágico ou resistência mágica; complexo e versátil, mas modalidades alternativas. |
| [Diamante de Sangue](https://app.notion.com/p/f53c2b324ede83149b588191fa2496ce) | 34 | Ouro | E3 | Rastreio seletivo a longa distância não quantificada. |
| [Manto da Arachnida](https://app.notion.com/p/591c2b324ede838691148122c83c19d5) | 34 | Ouro | E3 | Conjunto de travessia e controle de terreno. |
| [Manto Olhar Verdadeiro](https://app.notion.com/p/2d5c2b324ede8276a13a01d7a4525c74) | 36 | Ouro | E3 | Detecção ampla incluindo alvos normalmente ocultos. |
| [Tiara Intelectual](https://app.notion.com/p/cabc2b324ede83acb24e8105c082c6b0) | 65 | Ouro | E3 | Alteração de atributo dependente do usuário, não bônus fixo; exigir INT anterior. |

### Ouro Negro — 9 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Duro de Matar](https://app.notion.com/p/6c2c2b324ede83a7b7dc013f94eb052c) | 14 | Ouro Negro | E3 | Evita fatalidade uma vez por dia; bypass de morte com forte restrição. |
| [Invulnerabilidade](https://app.notion.com/p/559c2b324ede829a9139813d4899b07a) | 15 | Ouro Negro | E3 | Resistência não mágica e imunidade temporária a dano não mágico, 2/dia. |
| [Decepadora](https://app.notion.com/p/377c2b324ede82f9b4a181aed3e10f5a) | 20 | Ouro Negro | E3 | Possibilidade de perda de membro ultrapassa bônus ofensivo comum. |
| [Potencializar Magia](https://app.notion.com/p/96ac2b324ede82199f5b812bf2b0210b) | 22 | Ouro Negro | E3 | Escalonamento proporcional da potência em múltiplas magias. |
| [Vorpal](https://app.notion.com/p/442c2b324ede82c7a1520173d0d45cfd) | 25 | Ouro Negro | E3 | Bypass e execução potencial em crítico, com imunidades descritas. |
| [Anel de Escudo Mental](https://app.notion.com/p/274c2b324ede82c7b8358196fd0e5b52) | 35 | Ouro Negro | E3 | Negação mental e resistências substanciais amplas. |
| [Manopla de Combatente 2.0 S.P](https://app.notion.com/p/c1bc2b324ede82409f3b01eb327bb75b) | 52 | Ouro Negro | E3 | Amplificação ofensiva com cura e atributo, dependente do portador. |
| [Manto do Arquimago](https://app.notion.com/p/8afc2b324ede82e69dd101b9b9c663e3) | 60 | Ouro Negro | E3 | Dano mágico +30, CD +8, CA substitutiva e defesa mágica, múltiplos efeitos avançados. |
| [Lâmina Aurora Boreal](https://app.notion.com/p/a70c2b324ede83c2ac490135cd512e9f) | 95 | Ouro Negro | E3 | Bônus combinados de atributos, múltiplos danos radiantes e cegueira; custo individual das sobreposições pendente. |

### Lendário — 3 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Máscara do Dragão Negro](https://app.notion.com/p/bb4c2b324ede8249af01013102807a0e) | 70 | Lendário | E3 | Conjunto de defesas e bypass com repercussão estratégica; classe pendente de benchmarks completos. |
| [Armadura de Zephyr (L)](https://app.notion.com/p/a23c2b324ede829bb8168165991577ff) | 90 | Lendário | E3 | +15 DES, +15m, +25 ataque e +50 dano de Vento por turno; efeito extremo, rank L indicado no título (não substitui validação). |
| [Adaga Mortal Jaku](https://app.notion.com/p/376c2b324ede8394b3ff81fe4cc2d1cc) | 385 | Lendário | E0 | Lendária textual e mecânica de ataque/controle excepcional, demais relações pendentes. |

### PENDENTE — 2 páginas

| Item | PA/dia histórico | Rank | Base do rank | Evidência essencial / pendências |
|---|---:|---|---|---|
| [Amuleto da Dor](https://app.notion.com/p/a54c2b324ede8397ac238132b5927431) | 14 | PENDENTE | PENDENTE | Rank impossível sem mecânica; PA isolado insuficiente. |
| [Olho Mágico](https://app.notion.com/p/2c7c2b324ede837d87e781ee6adaeca4) | 24 | PENDENTE | PENDENTE | Olho Mágico sem descrição mecânica textual; rank deve aguardar ficha integral/imagem. |

