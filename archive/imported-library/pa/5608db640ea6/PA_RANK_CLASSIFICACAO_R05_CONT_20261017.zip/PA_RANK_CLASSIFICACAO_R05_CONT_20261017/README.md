# PA / classificação por rank — entrega read-only

Este pacote é continuação da OP/atribuição PA existente, **não nova operação**, baseado nas evidências R01–R05 recuperadas. Usa coeficientes expressos pelo Mestre em 17/10/2026, sem substituir regras canônicas com números extrapolados. **Nenhuma página do Notion foi editada** e **nenhum registro operacional foi inserido em página de item, besta ou NPC**. Qualquer commit futuro exige destino regulado, writer e readback.

**Abrir primeiro:** `RELATORIO_MESTRE_RANK_PA.md` e `MAPA_PA_DIA_POR_RANK_20261017.xlsx`. A aba `Mestre` contém 14 linhas de PA/dia, `Espelho` 80. `CATALOGO_COMPLETO_RANQUEADO.md` oferece os 94 itens em texto com URL.

**Estados:** rank E0 = documental; E3 = pré-classificação técnica do Atlas, não canônica; PENDENTE = mecânica insuficiente. Não existem tarifas de PA por rank; as medianas são estatísticas descritivas do recorte e não regras. Fontes do Espelho são só comparações, nunca fonte independente oficial.

**Identidade e autoria:** sem reassumir instância, writer ou lease; sem receitas novas; produção CRAFT HOLD. C19-021 UNKNOWN intocado. Preservar versões R01–R05 independentemente deste pacote, não editar baseline. O script em `CODIGO_LOCAL` reconcilia os três extratos originais e lê as transcrições dirigidas; não existe ponte Notion→Python autenticada em tempo de execução. As transcrições geradas deste turno devem ser reabertas no Notion pelo auditor se houver alteração de fonte.

**Fontes reguladoras:** Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab ; Motor: https://app.notion.com/p/3eec2b324ede8148a5b3ee17df578535 .

**Reprodução local:** o script `CODIGO_LOCAL/build_rank_pa.py` usa caminho fixo da pasta de recuperação R05 deste ambiente. Para executar noutro ambiente, extraia os arquivos correspondentes do pacote R05 na hierarquia esperada ou adapte o caminho explicitamente. O XLSX foi gerado com artifact_tool usando `CODIGO_LOCAL/make_workbook.py`; números do resumo calculados pelo código e retidos no JSON.
