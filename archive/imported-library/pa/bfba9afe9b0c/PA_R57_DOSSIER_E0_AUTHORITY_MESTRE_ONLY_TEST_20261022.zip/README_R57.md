# PA R57 — Dossiê de adjudicação (Mestre-side / TEST)
Escopo: leitura/reconciliação; NÃO substitui o Atlas, NÃO homologa RE, NÃO implanta motor.

## Achado normativo novo
DMG-RANK-01 **não é classificador**: recebe RE/FIP derivados do Atlas e produz orçamento de dano. Sistema de Magia admite versões de uma mesma magia com classificações diferentes. Por isso, nem o dano nem o rank do conjurador podem substituir uma decisão de RE da versão exata.

## Quatro decisões retidas
1. **Repreensão Infernal** — R26 candidato TEST: Prata; eixo compartilhado: fire_damage; comparadores parciais: Raio de Fogo, Criar Fogueira; diferença crítica: reactive_trigger_vs_action, received_damage_trigger, 60ft_reactive_target, save_half_vs_ranged_attack_or_area. **E0 = PENDENTE; custo PA e produção = HOLD.**
2. **Orbe Cromática** — R26 candidato TEST: Bronze; eixo compartilhado: ranged_magic_damage; comparadores parciais: Rajada Mística, Raio de Fogo; diferença crítica: six_way_element_choice_not_present_in_reference, 3d8_vs_1d10, risk_from_element_choice_not_adjudicated. **E0 = PENDENTE; custo PA e produção = HOLD.**
3. **Vínculo Com a Besta** — R26 candidato TEST: Bronze; eixo compartilhado: animal_information; comparadores parciais: Sentido Bestial; diferença crítica: telepathic_communication_vs_borrowed_senses, 10min_vs_1h, friendly_INT_condition_vs_willing_touch, mutual_line_of_sight_vs_blind_deaf_user. **E0 = PENDENTE; custo PA e produção = HOLD.**
4. **Toque Chocante** — R26 candidato TEST: Bronze; eixo compartilhado: single_target_damage; comparadores parciais: Raio de Fogo, Rajada Mística; diferença crítica: melee_touch_vs_ranged_attack, denies_reactions_vs_no_reaction_control, 1d8_lightning_vs_1d10_fire_or_force. **E0 = PENDENTE; custo PA e produção = HOLD.**

## Três divergências históricas (não são erros demonstrados)
- Lufada: Notion Prata versus R45 TEST Bronze. Imagem original SHA256 9628427072e8e693e46c79f7e53bb78fb2499bdd21a1c66b49bbcf54fa17f6a9.
- Raio de Fogo: Notion Prata versus R45 TEST Bronze. Imagem original SHA256 98d3325a92acfe84f7acfaaa5547b26088a26a7117653e2b0225c9a98b1ddaac.
- Ataque Certeiro: Notion Prata versus R45 TEST Bronze. Imagem original SHA256 ad0df13fbbb21993f0a9932e4779c409a6d20c0708aa02a8723765e4521bc356.

## Gate de autoridade
Antes de atribuir rank, readback da decisão expressa, prova de versão mecânica e comparador homólogo não circular. Tratar E353 e 14 avaliações blind separadamente. Nenhum E0 autorizado.

## Fontes
- PR-ECO-01 Atlas A: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Sistema de Magia: https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373
- DMG-RANK-01: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- AUD-DMG-RANK-QUALITY-01: https://app.notion.com/p/3f3c2b324ede8162be5bed7ac9f06b59
- Técnicas & Pergaminhos: https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff

## Preservação
R53–R56 inalterados. Item, recurso, receita, PA oficial, Party e O Primeiro não modificados.
