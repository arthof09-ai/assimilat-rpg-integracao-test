import pathlib,json,zipfile,hashlib,csv
P=pathlib.Path('/mnt/data/PA_P0_RECONCILIACAO_R07_20261017')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
with (P/'AUDITORIA_94_ORIGINAL_FIRST.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter=';'))
assert len(rows)==94
assert len(set(x['uuid'] for x in rows))==94
assert sum(x['original_lido_agora']=='SIM' for x in rows)==5
assert sum(x['estado_corrigido']=='CORRECAO_TEST_NAO_APLICADA' for x in rows)==3
assert rows[[x['item'] for x in rows].index('Decepadora')]['uuid']=='377c2b324ede82f9b4a181aed3e10f5a'
assert rows[[x['item'] for x in rows].index('Impacto Estonteante')]['uuid']=='a8ec2b324ede83e9b69a81affb4e1447'
assert sum(x['rank_analitico']=='' for x in rows)==3
# verify workbook XML container, binary signatures
with zipfile.ZipFile(P/'PA_P0_R07_MATRIZ_CONSOLIDADA.xlsx') as z:
 assert z.testzip() is None
 assert any(x.startswith('xl/worksheets/sheet') for x in z.namelist())
 # 6 tabs
 assert sum(x.startswith('xl/worksheets/sheet') and x.endswith('.xml') for x in z.namelist())==6
fixes=json.loads((P/'PATCH_ORIGINAL_FIRST_PARTY_GATE.json').read_text(encoding='utf-8'))
assert len(fixes)==3 and all(not x['escrita_executada'] and not x['party_write_permit'] for x in fixes)
conf=json.loads((P/'CONFLITOS_UUID_CORRIGIDOS.json').read_text(encoding='utf-8'))
assert any(x['item']=='Decepadora' and x['uuid']=='377c2b324ede82f9b4a181aed3e10f5a' for x in conf)
assert all(x['item']!='Impacto Estonteante' or x['uuid']!='377c2b324ede82f9b4a181aed3e10f5a' for x in conf)
files=[f for f in P.iterdir() if f.is_file() and f.name not in ['MANIFESTO_R07.json'] and f.suffix!='.py']
manifest={'asof':'2026-10-17','revision':'P0-R07','notion_writes':0,'baseline_preserved':True,'files':[{'name':f.name,'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(files)]}
(P/'MANIFESTO_R07.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
archive=pathlib.Path('/mnt/data/PA_P0_R07_READBACK_ORIGEM_20261017.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(P.iterdir()):
  if f.is_file():z.write(f,arcname=f.name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(x['name'])).hexdigest()==x['sha256'] for x in manifest['files'])
print('R07 PASS: audited=',len(rows),'party_orig_readbacks=',5,'patches_TEST=',len(fixes),'rank_E3=',9,'rank_unidentifiable=',3,'UUID_fix=',1,'archive_files=',len(zipfile.ZipFile(archive).namelist()),'zip_bytes=',archive.stat().st_size,'sha256=',sha(archive))
