# P0-4 — Plano de correção de conteúdo (não executado no Notion)

Autoridade do Mestre: +1 atributo=5 PA/dia, +1 dano=1 PA/dia, +1 m deslocamento=1 PA/dia, +1 teste ataque=1 PA/dia, +1 CA mágica=1 PA/dia. Fonte original Party foi **fisicamente reaberta** pelo conector, sem autorização de escrita adquirida.

## Três substituições precisas na origem Party

1. Mira Apurada: `4 PA por dia` → `3 PA por dia` (bônus condicional de +3 ataque).
2. Manto de Proteção: `10 PA por dia` → `2 PA por dia` (+2 CA por manto mágico).
3. Mobilidade: `7 PA por dia` → `2 PA por dia` (+2 CA mágica condicional por movimento).

**Cuidado:** P0 prévio endereçava apenas os UUIDs do Espelho; isso não respeita a hierarquia de sincronização. Agora cada alteração candidata aponta PRIMEIRO ao UUID original Party, com UUID Espelho apenas para verificação do sistema de sincronização competente. O escritor original Party deve obter gate independente, fazer preimage/diff, modificar só linha de custo, readback e reconciliar no Espelho por SYNC; NUNCA substituir manualmente o Espelho antes da origem. Sem writer, todas permanecem propostas TEST.

## Mestre com conflitos não numéricos fechados

- Sabedoria Ancestral: 20 PA isolados no fim versus +10 SAB equivalente a 50 PA/dia; telepatia/memória/leitura não tarifadas. Total **indeterminado**, piso de atributos 50.
- Colar Cadente: +2 SAB custa 10, sob estrelas +4 SAB custa 20. Regime de custo temporal **não homologado**; não inventar taxa diária única.
- Armadura de Zephyr (Espelho): +15 DES+15m+25 ataque ⇒ 115 PA/dia, acima de 90 históricos; +50 dano por turno é tema distinto, condicional de frequência. +11 CA estrutural não tarifada como mágica.
- Decepadora: o UUID correto é `377c2b324ede82f9b4a181aed3e10f5a` (e não `a8ec...`, que corresponde ao Impacto Estonteante). +30 dano apenas no crítico; modulação por frequência pendente.
- Viciada: +12 dano no crítico, modulação por frequência pendente.
- Amuleto de Inteligência: fonte Espelho, 30 PA isolados; +10 INT exige 50 PA/dia de atributos, dano +20 ramo alternativo; não gravar Party por inferência.

## REG-ROUTE-03

Não inserir neste conteúdo das fichas ANTES/DEPOIS, auditorias, timestamps ou rastros de execução. Logs vão apenas ao Diário/OP competente. No momento: zero writes, nenhuma licença de writer herdada, NAC-PASS canônico HOLD.
