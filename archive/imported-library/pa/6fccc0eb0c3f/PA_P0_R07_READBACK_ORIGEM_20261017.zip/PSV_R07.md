# PSV — P0 R07 · Reabertura de fontes originais e correção de proveniência

**AS-OF** 17/10/2026, MESTRE-SIDE. **Baseline** PA R05/R06/P0 preservada. **Identidade/OP** atribuição funcional da frente PA por ordem do Mestre; COMESTRE-ID, INSTANCE-ID e writer NÃO COMPROVADOS. Não criar outra operação.

**LAST-VERIFIED** 94/94 linhas baselines auditadas; originais Party 5/5 lidos fisicamente, em especial 3/3 substituições de custo e 2/2 fichas sem mecânica. Histórico Mestre do Amuleto Tempo Eterno reaberto, mesma falta de magnitude temporal. UUID Decepadora na lista de conflitos corrigido com identidade da matriz 94.

**P0-1** 94/94 analisados, 33 componentes numericamente tarifáveis e 61 sem parcela tarifável; não equivale a total correto de 94 itens.

**P0-2** Nove hipóteses de rank catalogadas e comparadas aos eixos Atlas em E3. Nenhuma declarada rank oficial; requer benchmarks e gate competente.

**P0-3** Três efeitos indeterminados após buscas dos originais: Amuleto Tempo Eterno sem fator/duração; Amuleto da Dor e Olho Mágico sem mecânica em original Party. O Atlas §3 autoriza classificar como SEM CLASSIFICAÇÃO DE PODER até dados; NÃO atribuir uma das 5 categorias arbitrariamente.

**P0-4** Três patches de efeito único foram normalizados ORIGINAL_PARTY_FIRST, seguidos por SYNC espelho, ao contrário do patch anterior. Zero writes canônicos/Party/Espelho; writer/lease não demonstrado. Seis conflitos compostos mantidos sem custo final inventado.

**NO-REPEAT** preservar pacotes R01-R06/P0 e não executar baterias antigas. **AUTHORITY** leitura Notion permitida, escrita física não adquirida. **UNKNOWN-EFFECT** C19-021 preservado. **NAC-PASS** TEST local apenas. **Production/CRAFT** HOLD, novas receitas proibidas.

**TERMINAL_P0** não pode declarar 4/4: P0-1 encerrada documentalmente, P0-2 reavaliada 9/9 porém não canonizada, P0-3 bloqueada por conteúdo faltante, P0-4 preparada mas sem permissão de escrita/autoridade Party. O status não será manipulado para esconder lacunas.
