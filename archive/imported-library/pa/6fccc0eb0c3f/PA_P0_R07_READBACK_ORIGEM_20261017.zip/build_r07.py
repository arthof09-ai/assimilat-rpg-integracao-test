#!/usr/bin/env python3
# Reconciliacao incremental sobre o baseline R06/P0, preservando-o imutavel.
from __future__ import annotations
import csv,json,hashlib,pathlib,collections,statistics,zipfile
P=pathlib.Path('/mnt/data/PA_P0_RECONCILIACAO_R07_20261017')
SRC=pathlib.Path('/mnt/data/PA_P0_AUDITORIA_20261017')
R06=pathlib.Path('/mnt/data/PA_RANK_R06_DELIVERY')
source=json.loads((SRC/'AUDITORIA_INTEGRAL_94.json').read_text(encoding='utf-8'))
rows=source['rows']
assert len(rows)==94 and len({x['uuid'] for x in rows})==94
assert sum(x['fonte']=='CATALOGO_MESTRE_INDEXADO' for x in rows)==14
assert sum(x['fonte']=='PARTY_MESTRE_ESPELHO' for x in rows)==80
ranks=json.loads((SRC/'RANKS_MESTRE_9_ATLAS.json').read_text(encoding='utf-8'))
assert len(ranks)==9
pending=json.loads((SRC/'RANKS_3_INDETERMINAVEIS.json').read_text(encoding='utf-8'))
assert len(pending)==3
# Readbacks executados via Notion Party original; testemunho codigo-derivado apenas preserva fatos de leitura.
party_originals={
'a54c2b324ede8397ac238132b5927431': {'orig_id':'29e9c16dd49582f6a7a281617dd427cd','name':'Amuleto da Dor','pa':14,'fragment':'3.856.000 MED | 14 PA por dia','evidencia_efeito':False,'last':'2026-10-02T17:50:20.289Z'},
'2c7c2b324ede837d87e781ee6adaeca4': {'orig_id':'de79c16dd49583158cbb0116a45de7fa','name':'Olho Mágico','pa':24,'fragment':'24 PA por dia | —MED','evidencia_efeito':False,'last':'2026-10-02T17:50:20.474Z'},
'65fc2b324ede838d9e5181b614b8da6a': {'orig_id':'4219c16dd495821d86db0162f009e523','name':'Mira Apurada','pa':4,'fragment':'+3 em jogadas de ataque à distância quando mira | 4 PA por dia','evidencia_efeito':True,'last':'2026-10-02T17:50:23.035Z'},
'761c2b324ede8201be5081ea69e97f10': {'orig_id':'1199c16dd49582d28c82816f25f7e2fc','name':'Manto de Proteção','pa':10,'fragment':'Você ganha um bônus de +2 na CA. 10 PA por dia.','evidencia_efeito':True,'last':'2026-10-02T17:50:20.354Z'},
'383c2b324ede820ab38881abbe91ac60': {'orig_id':'fc89c16dd4958243ba2e81abebd42145','name':'Mobilidade','pa':7,'fragment':'+2 CA ao deslocar com ação de movimento | 7 PA por dia','evidencia_efeito':True,'last':'2026-10-02T17:50:24.337Z'},
}
for u,p in party_originals.items():
 assert any(x['uuid']==u and int(x['pa_dia_historico'])==p['pa'] for x in rows)
 p['original_url']='https://app.notion.com/p/'+p.pop('orig_id')
 p['espelho_url']='https://app.notion.com/p/'+u
 p['modo']='VERIFICADO_LEITURA_ORIGINAL_PARTY_SEM_ESCRITA'
# True textual omission in master legacy re-opened.
pending_master=next(x for x in pending if x['item']=='Amuleto Tempo Eterno')
assert pending_master['url_legado'].endswith('6d8c2b324ede82a0ad1e8147f52bbf10')
originality={u:{'origem_original':p['original_url'],'verificado_readback':'2026-10-17','mecanica_presente':p['evidencia_efeito']} for u,p in party_originals.items()}
(P/'READBACK_PARTY_ORIGINAL_5.json').write_text(json.dumps(party_originals,ensure_ascii=False,indent=2),encoding='utf-8')
# Correcoes dirigidas ao original Party SOMENTE pelo writer de Party; o espelho segue SYNC e nao recebe patch manual.
patch=[]
for u,new_cost in [('65fc2b324ede838d9e5181b614b8da6a',3),('761c2b324ede8201be5081ea69e97f10',2),('383c2b324ede820ab38881abbe91ac60',2)]:
 e=party_originals[u]
 patch.append({'item':e['name'],'party_original_url':e['original_url'],'espelho_url':e['espelho_url'],
  'custo_observado_original_PA_dia':e['pa'],'custo_regra_determinado_mestre_PA_dia':new_cost,
  'delta_proposto':new_cost-e['pa'],'regra':'1 ataque = 1 PA/dia' if new_cost==3 else '1 CA magica = 1 PA/dia',
  'modo_correto':'ESCRITOR_PARTY_GATED_CORRIGE_ORIGINAL; SISTEMA_SYNC_ATUALIZA_ESPELHO; READBACK_EM_AMBOS',
  'party_write_permit':False,'escrita_executada':False,'status':'TEST_PREPARED_GATED',
  'no_ficha_operational_record':True})
(P/'PATCH_ORIGINAL_FIRST_PARTY_GATE.json').write_text(json.dumps(patch,ensure_ascii=False,indent=2),encoding='utf-8')
# Corrigir conflito de identidade presente apenas no RELATORIO de P0, nao na auditoria dos 94.
errs=json.loads((SRC/'CONFLITOS_PARA_DECISAO_DO_MESTRE.json').read_text(encoding='utf-8'))
fix_count=0
for e in errs:
 if e['item']=='Decepadora' and e['uuid']=='a8ec2b324ede83e9b69a81affb4e1447':
  e['uuid']='377c2b324ede82f9b4a181aed3e10f5a'; e['url']='https://app.notion.com/p/'+e['uuid'];fix_count+=1
assert fix_count==1
for x in errs:
 assert any(r['uuid']==x['uuid'] and (r['item']==x['item'] or x['item']=='(AI) Amuleto de Inteligência') for r in rows),(x['item'],x['uuid'])
(P/'CONFLITOS_UUID_CORRIGIDOS.json').write_text(json.dumps(errs,ensure_ascii=False,indent=2),encoding='utf-8')
# Claims correspond to genuine evidence levels, no retcon.
rank_dispositions=[]
for v in ranks:
 rank_dispositions.append({'item':v['item'],'uuid':v['uuid'],'categoria_aplicavel':'RANK_PROVISORIO_ATLAS_E3',
 'rank_candidato':v['rank_proposto'],'evidencia':'E3','canonica':False,
 'motivo':v['faltantes'],'prova_mecanica':v['evidencia_mecanica'],'fonte':v['fonte_url']})
for v in pending:
 rank_dispositions.append({'item':v['item'],'uuid':v['uuid'],'categoria_aplicavel':'SEM_CLASSIFICACAO_DE_PODER_POR_INSUFICIENCIA',
 'rank_candidato':None,'evidencia':'E3_INSUFICIENTE','canonica':False,
 'motivo':v['dado_minimo_exigido'],'prova_mecanica':v['motivo'],'fonte':v['url']})
assert len(rank_dispositions)==12
(P/'DISPOSICAO_RANK_ATLAS_12.json').write_text(json.dumps(rank_dispositions,ensure_ascii=False,indent=2),encoding='utf-8')
# Registros canonicamente exatos do escopo (nao 100% dos custos aprovados).
flags=collections.Counter(x['auditoria_p0']['status'] for x in rows)
assert sum(flags.values())==94
assert sum(any(c['pa_dia_regra'] for c in x['auditoria_p0']['componentes']) for x in rows)==33
ranks_known=collections.Counter((x['fonte'],x['rank_analitico'] or 'SEM_RANK') for x in rows)
summary={'date':'2026-10-17','baseline':'PA P0/R06, read-only','auditoria':{'n_total':94,'n_mestre':14,'n_espelho':80,'n_parcela_tarifada':33,'n_indeterminado_sem_parcela':61,'flags':flags},
'rank':{'rank_provisorio_e3_mestre_reavaliado':9,'sem_rank_por_dado_ausente':3,'rank_canonicamente_novo':0,'status':'ATLAS_E3_COM_INSUFICIENCIA_EXPLICITA'},
'correcoes':{'replacements_test':len(patch),'readbacks_originais_party':len(party_originals),'original_party_physically_modified':0,'espelho_physically_modified':0,'mestre_physically_modified':0,'writer_legitimo':'NAO_COMPROVADO'},
'blocked':{'dados_faltantes':True,'writer_lease_party':True,'writer_mestre':True,'nac_pass_canonic':True},'per_rank_fichas':{f'{a}|{b}':n for (a,b),n in ranks_known.items()}}
(P/'METRICAS_GATES_R07.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,default=dict),encoding='utf8')
fields=['uuid','item','fonte','familia','rank_documental','rank_analitico','selo_rank','pa_dia_historico','modalidade','custo_incondicional','custo_condicional','status_auditoria','efeitos_sem_coeficiente','original_party_url','original_lido_agora','estado_corrigido','url_espelho']
with (P/'AUDITORIA_94_ORIGINAL_FIRST.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields,delimiter=';');w.writeheader()
 for x in rows:
  a=x['auditoria_p0'];u=x['uuid'];orig=originality.get(u,{});p=next((c for c in patch if c['espelho_url']==x['url']),None)
  w.writerow({'uuid':u,'item':x['item'],'fonte':x['fonte'],'familia':x['familia'],'rank_documental':x['rank_documental'],
  'rank_analitico':x['rank_analitico'],'selo_rank':x['selo_rank'],'pa_dia_historico':x['pa_dia_historico'],'modalidade':x['modalidade'],
  'custo_incondicional':a['pa_dia_incondicional_identificado'],'custo_condicional':a['pa_dia_condicional_sem_desconto'],
  'status_auditoria':a['status'],'efeitos_sem_coeficiente':' | '.join(a['nao_precificados']),'original_party_url':orig.get('origem_original',''),
  'original_lido_agora':'SIM' if u in originality else 'NAO_REVALIDADO_NESTE_INCREMENTO',
  'estado_corrigido':'CORRECAO_TEST_NAO_APLICADA' if p else 'CONSERVADO_HISTORICO','url_espelho':x['url']})
(P/'CORRECOES_CONTEUDO_APENAS.md').write_text('''# P0-4 — Plano de correção de conteúdo (não executado no Notion)

Autoridade do Mestre: +1 atributo=5 PA/dia, +1 dano=1 PA/dia, +1 m deslocamento=1 PA/dia, +1 teste ataque=1 PA/dia, +1 CA mágica=1 PA/dia. Fonte original Party foi **fisicamente reaberta** pelo conector, sem autorização de escrita adquirida.

## Três substituições precisas na origem Party

1. Mira Apurada: `4 PA por dia` → `3 PA por dia` (bônus condicional de +3 ataque).
2. Manto de Proteção: `10 PA por dia` → `2 PA por dia` (+2 CA por manto mágico).
3. Mobilidade: `7 PA por dia` → `2 PA por dia` (+2 CA mágica condicional por movimento).

**Cuidado:** P0 prévio endereçava apenas os UUIDs do Espelho; isso não respeita a hierarquia de sincronização. Agora cada alteração candidata aponta PRIMEIRO ao UUID original Party, com UUID Espelho apenas para verificação do sistema de sincronização competente. O escritor original Party deve obter gate independente, fazer preimage/diff, modificar só linha de custo, readback e reconciliar no Espelho por SYNC; NUNCA substituir manualmente o Espelho antes da origem. Sem writer, todas permanecem propostas TEST.

## Mestre com conflitos não numéricos fechados

- Sabedoria Ancestral: 20 PA isolados no fim versus +10 SAB equivalente a 50 PA/dia; telepatia/memória/leitura não tarifadas. Total **indeterminado**, piso de atributos 50.
- Colar Cadente: +2 SAB custa 10, sob estrelas +4 SAB custa 20. Regime de custo temporal **não homologado**; não inventar taxa diária única.
- Armadura de Zephyr (Espelho): +15 DES+15m+25 ataque ⇒ 115 PA/dia, acima de 90 históricos; +50 dano por turno é tema distinto, condicional de frequência. +11 CA estrutural não tarifada como mágica.
- Decepadora: o UUID correto é `377c2b324ede82f9b4a181aed3e10f5a` (e não `a8ec...`, que corresponde ao Impacto Estonteante). +30 dano apenas no crítico; modulação por frequência pendente.
- Viciada: +12 dano no crítico, modulação por frequência pendente.
- Amuleto de Inteligência: fonte Espelho, 30 PA isolados; +10 INT exige 50 PA/dia de atributos, dano +20 ramo alternativo; não gravar Party por inferência.

## REG-ROUTE-03

Não inserir neste conteúdo das fichas ANTES/DEPOIS, auditorias, timestamps ou rastros de execução. Logs vão apenas ao Diário/OP competente. No momento: zero writes, nenhuma licença de writer herdada, NAC-PASS canônico HOLD.
''',encoding='utf8')
(P/'PSV_R07.md').write_text('''# PSV — P0 R07 · Reabertura de fontes originais e correção de proveniência

**AS-OF** 17/10/2026, MESTRE-SIDE. **Baseline** PA R05/R06/P0 preservada. **Identidade/OP** atribuição funcional da frente PA por ordem do Mestre; COMESTRE-ID, INSTANCE-ID e writer NÃO COMPROVADOS. Não criar outra operação.

**LAST-VERIFIED** 94/94 linhas baselines auditadas; originais Party 5/5 lidos fisicamente, em especial 3/3 substituições de custo e 2/2 fichas sem mecânica. Histórico Mestre do Amuleto Tempo Eterno reaberto, mesma falta de magnitude temporal. UUID Decepadora na lista de conflitos corrigido com identidade da matriz 94.

**P0-1** 94/94 analisados, 33 componentes numericamente tarifáveis e 61 sem parcela tarifável; não equivale a total correto de 94 itens.

**P0-2** Nove hipóteses de rank catalogadas e comparadas aos eixos Atlas em E3. Nenhuma declarada rank oficial; requer benchmarks e gate competente.

**P0-3** Três efeitos indeterminados após buscas dos originais: Amuleto Tempo Eterno sem fator/duração; Amuleto da Dor e Olho Mágico sem mecânica em original Party. O Atlas §3 autoriza classificar como SEM CLASSIFICAÇÃO DE PODER até dados; NÃO atribuir uma das 5 categorias arbitrariamente.

**P0-4** Três patches de efeito único foram normalizados ORIGINAL_PARTY_FIRST, seguidos por SYNC espelho, ao contrário do patch anterior. Zero writes canônicos/Party/Espelho; writer/lease não demonstrado. Seis conflitos compostos mantidos sem custo final inventado.

**NO-REPEAT** preservar pacotes R01-R06/P0 e não executar baterias antigas. **AUTHORITY** leitura Notion permitida, escrita física não adquirida. **UNKNOWN-EFFECT** C19-021 preservado. **NAC-PASS** TEST local apenas. **Production/CRAFT** HOLD, novas receitas proibidas.

**TERMINAL_P0** não pode declarar 4/4: P0-1 encerrada documentalmente, P0-2 reavaliada 9/9 porém não canonizada, P0-3 bloqueada por conteúdo faltante, P0-4 preparada mas sem permissão de escrita/autoridade Party. O status não será manipulado para esconder lacunas.
''',encoding='utf8')
print('reconciled',len(rows),'flags',dict(flags),'correction uuid fix',fix_count,'readbacks original',len(party_originals))
