from __future__ import annotations
import pathlib,json,csv
from artifact_tool import Workbook, SpreadsheetFile
P=pathlib.Path('/mnt/data/PA_P0_RECONCILIACAO_R07_20261017')
with (P/'AUDITORIA_94_ORIGINAL_FIRST.csv').open(encoding='utf-8-sig',newline='') as f: source=list(csv.DictReader(f,delimiter=';'))
original=json.loads((P/'READBACK_PARTY_ORIGINAL_5.json').read_text())
patch=json.loads((P/'PATCH_ORIGINAL_FIRST_PARTY_GATE.json').read_text())
rank=json.loads((P/'DISPOSICAO_RANK_ATLAS_12.json').read_text())
conflicts=json.loads((P/'CONFLITOS_UUID_CORRIGIDOS.json').read_text())
wb=Workbook.create()
main=wb.worksheets.add('Auditoria 94')
headers=['UUID','Item','Origem','Família','Rank documental','Rank técnico','Selo','PA histórico/dia','Modalidade','PA fixo identificável','PA condicional','Classe auditoria','Efeitos sem tarifa','Original Party','Original reaberto','Situação correção','Fonte Mestre espelho']
main.get_range('A1:Q1').values=[headers]
data=[]
for a in source:
 data.append([a['uuid'],a['item'],a['fonte'],a['familia'],a['rank_documental'],a['rank_analitico'],a['selo_rank'],int(a['pa_dia_historico']),a['modalidade'],int(a['custo_incondicional']),int(a['custo_condicional']),a['status_auditoria'],a['efeitos_sem_coeficiente'],a['original_party_url'],a['original_lido_agora'],a['estado_corrigido'],a['url_espelho']])
main.get_range('A2:Q95').values=data
main.get_range('A1:Q1').format={'fill':'#142A40','font':{'bold':True,'color':'#FFFFFF'},'row_height':34,'wrap_text':True}
main.freeze_panes.freeze_rows(1)
for c,w in [('A',33),('B',30),('C',26),('D',20),('E',16),('F',17),('G',19),('H',16),('I',16),('J',20),('K',18),('L',29),('M',38),('N',42),('O',23),('P',28),('Q',42)]:main.get_range(f'{c}:{c}').format.column_width=w
main.get_range('H2:K95').set_number_format('0')
main.get_range('A2:Q95').format.row_height=21
main.tables.add('A1:Q95',True,'Audit94P0R07')

report=wb.worksheets.add('Painel P0')
report.get_range('A1:E1').values=[['Pendência','Escopo verificado','Ganho real','Pendência impeditiva','Estado']]
report.get_range('A2:E5').values=[
['P0-1','94/94 fichas','33 parcelas conhecidas; 61 sem coeficiente','94 preços totais não reconciliados','PASS DOCUMENTAL'],
['P0-2','9/9 Mestre reavaliados','9 ranks E3 rastreáveis','Classificação canônica 0/9','HOLD CANÔNICO'],
['P0-3','3/3 originais/legado investigados','3 lacunas comprovadas; sem inventar rank','Função de 2 itens + intensidade do efeito temporal','SEM CLASSIFICAÇÃO E3'],
['P0-4','3 patches fonte-original-ready','Party source links e diff mínimo','0 writer Party / 0 writes / sync externo','HOLD ESCRITA'],
]
report.get_range('A7:D7').values=[['Medida','Quantidade','Origem','Semântica']]
report.get_range('A8:D15').values=[
['Fichas totais',94,'Mestre+Espelho','UUID físicos no corpus fechado'],
['Fichas Mestre',14,'RPG/Itens','Não confundir com Espelho'],
['Fichas Espelho',80,'Mestre-Espelho','Não independentes do Party original'],
['Parcela numérica disponível',33,'5 tarifas do Mestre','Não implica custo total validado'],
['Sem parcela precificável',61,'5 tarifas do Mestre','Sem interpolar custos restantes'],
['Rank E3 Mestre',9,'Atlas §3/§7','Técnico, não canônico'],
['Rank sem mecânica',3,'Atlas §3.7/§4','Não inferir por preço nem PA'],
['Writes canônicos',0,'Gates','Party/Mestre/Espelho intactos'],
]
report.get_range('A1:E1').format={'fill':'#142A40','font':{'bold':True,'color':'#FFFFFF'},'row_height':32}
report.get_range('A7:D7').format={'fill':'#184B62','font':{'bold':True,'color':'#FFFFFF'},'row_height':28}
for c,w in [('A',26),('B',37),('C',41),('D',54),('E',27)]:report.get_range(f'{c}:{c}').format.column_width=w
report.get_range('A2:E15').format.wrap_text=True
report.get_range('A2:E5').format.row_height=56
report.freeze_panes.freeze_rows(1)

orig=wb.worksheets.add('Originais Party')
orig.get_range('A1:F1').values=[['Item','Custo original PA/dia','Fonte original Party','Fonte Espelho','Efeito documentado','Leitura original']]
orig.get_range('A2:F6').values=[[v['name'],v['pa'],v['original_url'],v['espelho_url'],'SIM' if v['evidencia_efeito'] else 'NAO',v['last']] for v in original.values()]
orig.get_range('A1:F1').format={'fill':'#142A40','font':{'bold':True,'color':'#FFFFFF'},'row_height':28}
for c,w in [('A',28),('B',24),('C',45),('D',44),('E',26),('F',33)]:orig.get_range(f'{c}:{c}').format.column_width=w
orig.freeze_panes.freeze_rows(1)

rank_sheet=wb.worksheets.add('Rank Atlas 12')
rank_sheet.get_range('A1:G1').values=[['Item','UUID','Rank candidato','Atlas selo','Estado classificação','Lacuna para validação','Fonte']]
rank_sheet.get_range('A2:G13').values=[[x['item'],x['uuid'],x['rank_candidato'] or '',x['evidencia'],x['categoria_aplicavel'],x['motivo'],x['fonte']] for x in rank]
rank_sheet.get_range('A1:G1').format={'fill':'#142A40','font':{'bold':True,'color':'#FFFFFF'},'row_height':30}
for c,w in [('A',31),('B',34),('C',18),('D',23),('E',39),('F',60),('G',45)]:rank_sheet.get_range(f'{c}:{c}').format.column_width=w
rank_sheet.get_range('A2:G13').format.wrap_text=True
rank_sheet.get_range('A2:G13').format.row_height=52
rank_sheet.freeze_panes.freeze_rows(1)

changes=wb.worksheets.add('Correção Fonte Primeiro')
changes.get_range('A1:H1').values=[['Item','PA histórico','PA regra','Delta','Fonte original Party','Espelho','Writer','Situação']]
changes.get_range('A2:H4').values=[[x['item'],x['custo_observado_original_PA_dia'],x['custo_regra_determinado_mestre_PA_dia'],x['delta_proposto'],x['party_original_url'],x['espelho_url'],'SEM AUTORIDADE','CANDIDATO TEST NÃO APLICADO'] for x in patch]
changes.get_range('A1:H1').format={'fill':'#142A40','font':{'bold':True,'color':'#FFFFFF'},'row_height':34}
for c,w in [('A',30),('B',19),('C',19),('D',14),('E',45),('F',44),('G',21),('H',35)]:changes.get_range(f'{c}:{c}').format.column_width=w
changes.freeze_panes.freeze_rows(1)

conf=wb.worksheets.add('Conflitos 6')
conf.get_range('A1:F1').values=[['Item','UUID correto','Histórico','Regra/limiar','Por que não corrigir total','Fonte']]
conf.get_range('A2:F7').values=[[x['item'],x['uuid'],x['historico'],x['minimo_ou_condicao'],x['por_que_nao_escrever_total'],x['url']] for x in conflicts]
conf.get_range('A1:F1').format={'fill':'#142A40','font':{'bold':True,'color':'#FFFFFF'},'row_height':33}
for c,w in [('A',29),('B',34),('C',25),('D',54),('E',69),('F',47)]:conf.get_range(f'{c}:{c}').format.column_width=w
conf.get_range('A2:F7').format.row_height=52
conf.get_range('A2:F7').format.wrap_text=True
conf.freeze_panes.freeze_rows(1)

out=P/'PA_P0_R07_MATRIZ_CONSOLIDADA.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('saved',out,out.stat().st_size,'sheets',wb.inspect({'kind':'sheet','include':'id,name'}).ndjson[:800])
