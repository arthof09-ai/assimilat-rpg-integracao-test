import subprocess,sys,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text())
for filename,h in manifest.items():
 f=root/filename
 if not f.exists() or hashlib.sha256(f.read_bytes()).hexdigest()!=h:raise SystemExit('INVALID_MANIFEST:'+filename)
p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=root,capture_output=True,text=True)
out=p.stdout+p.stderr
if p.returncode or 'Ran 11 tests' not in out or 'OK' not in out:raise SystemExit(out[-2500:])
print(json.dumps({'PASS':True,'test_count':11,'source_sha_verified':len(manifest),'scientific_accuracy':None,'rank_promoted':False}))
