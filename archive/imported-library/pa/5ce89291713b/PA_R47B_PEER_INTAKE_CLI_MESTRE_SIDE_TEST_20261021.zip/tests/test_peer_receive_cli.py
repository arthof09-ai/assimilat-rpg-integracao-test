import unittest,sys,io,csv,tempfile,zipfile,subprocess,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from peer_receive_cli import ingest_file,main,DEFAULT_TEMPLATE
from peer_intake_v2 import COLS,IntegrityError
from peer_intake_v2 import read_csv_checked
A='https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'
B='https://app.notion.com/p/b06c2b324ede8279a0f4014c14125a98'
C='https://app.notion.com/p/3edc2b324ede81b696b0d75191b7a5ec'

class TestReceiveCLI(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  
  with zipfile.ZipFile(DEFAULT_TEMPLATE) as z:
   cls.rows=read_csv_checked(z.read('peer_review_blank.csv'))
  for r in cls.rows:
   r.update(proposed_RE='Prata',system_comparator_url=A,live_comparator_url=B,family_comparator_url=C,
            mechanical_rationale='Este efeito foi comparado em termos de alcance, capacidade e limitações com fontes atuais; a proposta não foi aprovada.',
            limitations='Existem limitações de duração e economia de ação ainda a comparar em fonte de semelhante alcance.',
            reviewer_attestation='YES',independent_oracle_not_opened='YES')
  cls.csvbuf=io.StringIO();w=csv.DictWriter(cls.csvbuf,fieldnames=COLS);w.writeheader();w.writerows(cls.rows)
 def test_01_csv_good(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'peer_filled.csv';f.write_text(self.csvbuf.getvalue());r=ingest_file(f);self.assertEqual(r['batch_intake'],'FORM_COMPLETE_NOT_SCIENTIFICALLY_VALIDATED')
 def test_02_zip_good(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'peer_filled.zip'
   with zipfile.ZipFile(f,'w') as z:z.writestr('results.csv',self.csvbuf.getvalue())
   self.assertEqual(ingest_file(f)['form_row_passed'],12)
 def test_03_reject_blank_template(self):
  r=ingest_file(DEFAULT_TEMPLATE) if False else None
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'peer_blank.csv'
   with zipfile.ZipFile(DEFAULT_TEMPLATE) as z:f.write_bytes(z.read('peer_review_blank.csv'))
   self.assertEqual(ingest_file(f)['batch_intake'],'REJECT_OR_HOLD')
 def test_04_extra_csv_not_allowed(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'peer_filled.zip'
   with zipfile.ZipFile(f,'w') as z:z.writestr('a.csv',self.csvbuf.getvalue());z.writestr('b.csv',self.csvbuf.getvalue())
   with self.assertRaises(IntegrityError):ingest_file(f)
 def test_05_prior_rank_leak_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'peer_filled.zip'
   with zipfile.ZipFile(f,'w') as z:z.writestr('results.csv',self.csvbuf.getvalue());z.writestr('R45_oracle.txt','X')
   with self.assertRaises(IntegrityError):ingest_file(f)
 def test_06_wrong_ext(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'response.pdf';f.write_text(self.csvbuf.getvalue())
   with self.assertRaises(IntegrityError):ingest_file(f)
 def test_07_cli_out_success(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'response.csv';out=Path(t)/'out.json';f.write_text(self.csvbuf.getvalue());rc=main(['--submission',str(f),'--output',str(out)]);self.assertEqual(rc,0);self.assertEqual(json.loads(out.read_text())['canonical_changes'] if 'canonical_changes' in json.loads(out.read_text()) else json.loads(out.read_text())['automatically_canonized'],0)
 def test_08_cli_out_error(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'response.xls';out=Path(t)/'out.json';f.write_text('foo');rc=main(['--submission',str(f),'--output',str(out)]);self.assertEqual(rc,2);self.assertEqual(json.loads(out.read_text())['status'],'REJECTED_INPUT')
 def test_09_cli_out_incomplete(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'response.csv';out=Path(t)/'out.json';f.write_text(self.csvbuf.getvalue().splitlines()[0]+'\n');rc=main(['--submission',str(f),'--output',str(out)]);self.assertEqual(rc,3)
 def test_10_dont_touch_baseline_template(self):
  import hashlib
  b=hashlib.sha256(DEFAULT_TEMPLATE.read_bytes()).hexdigest()
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'response.csv';f.write_text(self.csvbuf.getvalue());ingest_file(f)
  self.assertEqual(b,hashlib.sha256(DEFAULT_TEMPLATE.read_bytes()).hexdigest())
 def test_11_no_truth_claim(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'response.csv';f.write_text(self.csvbuf.getvalue());r=ingest_file(f)
   self.assertIsNone(r['scientific_accuracy']);self.assertFalse(r['fully_verified_peer_independence']);self.assertFalse(r['result_is_accuracy'])
if __name__=='__main__':unittest.main()
