# PA R47B — Recebimento das 12 avaliações cegas (MESTRE-SIDE / TEST)

Esta ferramenta está pronta para uso **quando o outro Comestre entregar a planilha**, e somente depois de ele congelar suas previsões. **Não executar a análise antecipadamente**: ainda não existe submissão independente nesta operação.

A ferramenta **não** lê relatórios R45/R46 nem ranks históricos. Ela confere consistência de 12 linhas, 12 hashes das imagens derivadas, CSV/ZIP sem duplicações e a assinatura declaratória da independência. Os três links de comparadores continuam exigindo auditoria semântica humana/Comestre; campos preenchidos não significam comparadores idôneos. A saída só pode ser `FORM_COMPLETE_NOT_SCIENTIFICALLY_VALIDATED` ou `REJECT_OR_HOLD` / erro.

Para executar, após receber o arquivo preenchido:

```bash
python peer_receive_cli.py --submission /caminho/peer_review_preenchido.csv --output relatorio_admissibilidade.json
```

Para pacote ZIP entregue pelo avaliador:

```bash
python peer_receive_cli.py --submission /caminho/peer_review_preenchido.zip --output relatorio_admissibilidade.json
```

Se faltar informação a resposta será recusada/pendente; `INSUFICIENTE` é permitido com lacuna técnica explícita e **não exige três comparadores impossíveis**. A aplicação não faz writes em Notion/Party/O Primeiro, não altera o score histórico, não decide PA e não canoniza RE.

**Apenas depois dessa etapa:** consultar as fontes Notion correspondentes a cada comparador, certificar que pertencem a funções distintas e estão vigentes, confrontar a avaliação congelada com a minha versão R45 (comparar *concordância*, não *acurácia*). Manter pareceres históricos Mestre-only.

Suíte digital própria de 11 testes, além das 96 verificações do pacote R47 A (os testes do A não são repetidos nem recontados neste bundle).
