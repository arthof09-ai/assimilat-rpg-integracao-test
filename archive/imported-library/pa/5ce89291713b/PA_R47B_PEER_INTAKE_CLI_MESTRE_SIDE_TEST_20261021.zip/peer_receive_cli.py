"""Operational TEST CLI to ingest the future peer response without opening ranks.

Usage:
    python peer_receive_cli.py --submission /path/peer_review_filled.csv --output intake.json
or  python peer_receive_cli.py --submission /path/peer_review.zip --output intake.json

Only validates scientific *form*. Full Notion source equivalence, identity,
adjudication and agreement against another assessor are separate, post-freeze.
"""
from __future__ import annotations
import argparse,json,zipfile,io,sys
from pathlib import Path
from peer_intake_v2 import (read_csv_checked,assess_rows,load_peer_template,
                           verified_zip_entries,IntegrityError,BAD_COLUMNS)
ROOT=Path(__file__).resolve().parent
DEFAULT_TEMPLATE=ROOT/'source/PEER_TEMPLATE_12_SEM_GABARITO.zip'


def ingest_file(submitted:Path,template:Path=DEFAULT_TEMPLATE):
    expected=load_peer_template(template)
    if submitted.stat().st_size>60_000_000:raise IntegrityError('submission too large')
    if submitted.suffix.lower()=='.csv':
        data=submitted.read_bytes()
    elif submitted.suffix.lower()=='.zip':
        blob=submitted.read_bytes()
        entries=verified_zip_entries(blob)
        if any(('oraculo' in x.casefold() or 'gabarito' in x.casefold() or 'legacy_rank' in x.casefold() or 'r45' in x.casefold() or 'r46' in x.casefold()) for x in entries):
            raise IntegrityError('review package appears contaminated with earlier ranks')
        candidates=[x for x in entries if x.casefold().endswith('.csv')]
        if len(candidates)!=1:raise IntegrityError('submission must contain exactly one CSV')
        with zipfile.ZipFile(io.BytesIO(blob)) as z:data=z.read(candidates[0])
    else:raise IntegrityError('submit CSV or ZIP')
    result=assess_rows(read_csv_checked(data),expected)
    result['source']='EXTERNAL_REVIEWER_SUBMISSION_UNATTESTED'
    result['historical_oracle_read']=False
    result['result_is_accuracy']=False
    result['recorded_canonical_change']=False
    return result


def main(argv=None):
    parser=argparse.ArgumentParser(description='Validate 12 blind PA review rows, never canonize.')
    parser.add_argument('--submission',type=Path,required=True)
    parser.add_argument('--template',type=Path,default=DEFAULT_TEMPLATE)
    parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args(argv)
    try:
        r=ingest_file(a.submission,a.template)
        a.output.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'status':r['batch_intake'],'n':r['received_rows'],'form_passed':r['form_row_passed'],
                          'canonical_changes':r['automatically_canonized']},ensure_ascii=False))
        return 0 if r['batch_intake']=='FORM_COMPLETE_NOT_SCIENTIFICALLY_VALIDATED' else 3
    except (IntegrityError,zipfile.BadZipFile,ValueError) as e:
        a.output.write_text(json.dumps({'status':'REJECTED_INPUT','reason':str(e),'canonical_changes':0},indent=2))
        print('REJECTED_INPUT',e,file=sys.stderr)
        return 2
if __name__=='__main__':sys.exit(main())
