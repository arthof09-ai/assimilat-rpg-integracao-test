"""Sealed roster builder, run ONLY in Master-side prep. Do not give oracle to classifier.
Source: live Notion 'Técnicas & Pergaminhos' listing; 26 previously re-fetched.
"""
import hashlib,json,secrets
from pathlib import Path
SRC='https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff'
# This array is a Master-side source mapping, not a scientific truth.
ROSTER=[
 ('3edc2b324ede8132b862ce2d6efc860a','Bronze'),
 ('3edc2b324ede8165a948c6b6c6c9ab62','Bronze'),
 ('3edc2b324ede81319cbaf75263c48326','Prata'),
 ('3edc2b324ede8118a6dce655e4a9b884','Prata'),
 ('3edc2b324ede81559680d84589ccfb0f','Prata'),
 ('3edc2b324ede81cda339e07d2ccb64ce','Prata'),
 ('3edc2b324ede8136a10ce73a25d04b3a','Prata'),
 ('3edc2b324ede81eead95fb791a31b0e0','Prata'),
 ('3edc2b324ede81c8a686c4740ad5dc57','Ouro'),
 ('3edc2b324ede81b2b59af3663ea006ec','Ouro Negro'),
 ('3edc2b324ede81c5945ee5cbb1d6a59d','Ouro'),
 ('3edc2b324ede81c5b989eb157f7ce817','Ouro'),
 ('3edc2b324ede816fb2bed9b071790a96','Ouro'),
 ('3edc2b324ede81218562dbce3eb3124a','Ouro'),
 ('3edc2b324ede81a0a72af24c15df234a','Ouro'),
 ('3edc2b324ede81fab67cd15d31615852','Ouro'),
 ('3edc2b324ede81e3953ad588986b81be','Ouro'),
 ('3edc2b324ede81f79aaaeb6c8c10729e','Ouro'),
 ('3edc2b324ede816c8caae26f25e60379','Ouro'),
 ('3edc2b324ede816ea8dae4a171d1d467','Ouro'),
 ('3edc2b324ede81328e2ddeaf4ac3f848','Ouro'),
 ('3edc2b324ede8125a87ec820ba101cf6','Ouro Negro'),
 ('3edc2b324ede81fd9147d9518152e6a9','Ouro Negro'),
 ('3edc2b324ede81f0975ae7f082c71a1c','Ouro Negro'),
 ('3edc2b324ede8132a019f922defa6b57','Ouro Negro'),
 ('3edc2b324ede813f9795d406af37b1b9','Lendário'),
]
def build(oracle_path,public_path):
    if len(ROSTER)!=26 or len(set(x[0] for x in ROSTER))!=26:raise ValueError('roster integrity')
    salt=secrets.token_hex(32)
    oracle={'scope':'MESTRE_ONLY_NO_PARTY','historical_labels_are_NOT_ground_truth':True,'source_collection':SRC,'secret_salt':salt,'items':[]}
    public={'scope':'BLIND_TEST_NO_HISTORICAL_LABELS','denominator':26,'media_authenticated_count':0,'mechanics_verified_count':0,'eligible_blind_predictions':0,'items':[]}
    for src_id,rank in ROSTER:
        opaque=hashlib.sha256((salt+src_id).encode()).hexdigest()[:16]
        oracle['items'].append({'opaque_id':opaque,'source_page_url':'https://app.notion.com/p/'+src_id,'historical_rank':rank,'authoritative_rank':None})
        public['items'].append({'opaque_id':opaque,'media_bytes_sha256':None,'mechanics_text_sha256':None,'mechanics_text':None,'prediction':None,'status':'WAITING_AUTHENTIC_IMAGE_BYTES'})
    b=json.dumps(oracle,indent=2,ensure_ascii=False).encode()
    oracle_path.write_bytes(b)
    public['oracle_frozen_sha256']=hashlib.sha256(b).hexdigest()
    public_path.write_text(json.dumps(public,indent=2,ensure_ascii=False),encoding='utf-8')
    return public['oracle_frozen_sha256']
if __name__=='__main__':
 import sys
 print(build(Path(sys.argv[1]),Path(sys.argv[2])))
