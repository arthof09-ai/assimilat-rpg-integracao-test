# Cetro — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Bronze (RI_PROVISORIO_POR_EFEITO_DOMINANTE_E3)
**Bônus diretos:** {"FOR": 0, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 0, "ca_magica": 0}; tarifa identificada 0 PA/dia.

## Habilidades propostas
- **Fagulha** — ATIVA; RE Bronze (E3_PROPOSTO); diário: 3; por uso: 3; usos simulados: 0.
  - Mecânica recebida: Com uma ação padrão, causa 3d6 de dano em um único alvo.
  - Referências/ressalvas: DME 10.5; candidato por banda oficial DMG para alvo único, Ação Padrão, sem bypass. Necessita revisão das condições..

## Consumo energético prospectivo
- Piso item: 8 PA/dia.
- Parcela diária identificada: 3 PA/dia.
- **Prévia diária condicional:** 8 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 8 PA.
- Estado: SIMULACAO_CONDICIONAL; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: Fagulha: HIPOTESE_E3.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
