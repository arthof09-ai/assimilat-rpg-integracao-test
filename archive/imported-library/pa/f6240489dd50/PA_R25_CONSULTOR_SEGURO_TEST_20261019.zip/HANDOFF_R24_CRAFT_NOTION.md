# Handoff técnico R24 · CRAFT / Notion / Classificação / VLAB

**Workstream existente:** Sistema de Consumo de PA de Itens Mágicos / OP-ARQ-RIN-REC-01 (CRAFT). **Ambiente:** MESTRE-SIDE; `PRODUÇÃO=HOLD`. Nenhuma identidade de instância, reserva, fencing, writer, epoch ou lease assumida. **Sem mudança em Party, O Primeiro, fichas históricas, Sistema de Magia, DMG-RANK ou VLAB.**

## 1. Ação preparada para o CRAFT

Contrato de entrada `analyze_item(descrição em português, uses={nome:usos})`; saída JSON `name`, `item_rank`, `item_rank_status`, `numeric_components`, `numeric_pa_day`, `abilities[]` com cada `kind`, `rank`, `rank_evidence`, `rank_alternativas`, `spatial`, `comparators`, `cost_pa_day`, `cost_pa_use`, `warnings`, `costs.{floor,day_effects,day,activations,total,quote_state,known_lower_bound_day,mathematical_completeness}`, `can_publish=False`, `can_write_notion=False`. `as_ficha()` produz prévia Mestre legível.

Importante: a API é **módulo local TEST**, não endpoint nativo e não instalação automática na interface do CRAFT. CRAFT precisa legitimamente integrar/reusar código ou contratá-lo sob sua operação; proibido declarar ACK por handoff escrito somente em ZIP.

## 2. Regra e sequência de classificação

**Efeito e especificação** → verificar modalidade/identidade/duplicata → interpretar alcance com R23 e evidência de origem → Atlas 14 eixos, comparadores sistêmico/vivo/família, FIP interna → RE E0/E1/E2/E3 → RI do efeito dominante e conjunto → tarifas de atributos, habilidades e piso → cenário de usos → prévia e aprovação do Mestre → transação autorizada/registro.

Rank do item e custo em PA não podem retroalimentar rank da habilidade. Um RI elevado pode conter REs inferiores; um RE acima do RI declarado dispara conflito. Se o usuário não fornecer rank, o motor tenta propor, mas encerra com `HOLD_RE` quando não sustenta avaliação independente.

## 3. Autoridades canônicas não duplicar

- Atlas `https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab`
- Sistema de Magia `https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373`
- DMG-RANK-01 v1.1 `https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e`
- PR-ITEM-02 `https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4`
- OP CRAFT `https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516`

A diretriz de alcance do Mestre foi comunicada no chat mas o registro normativo na mãe competente NÃO foi verificado. Somente hierarquia Mestres→mães vigentes com governança NAC-NORM-01; atualizar uma mãe existente, nunca criar norma paralela.

## 4. Segurança/integridade

- Item histórico: não recalcular PA oficial; consulta `source_kind=HISTORICO` serve para diagnóstico. Item vinculado à Party: origem é Party, Mestre apenas espelha, read-only por padrão.
- Exposição Mestre-only: não compartilhar pesquisas, benchmarks secretos, trade-offs internos, saldos privados ou fichas Mestre com Party.
- `CA física` não cobrar como mágica; `+atributo` tem tarifa numérica, não adicionar passiva decorativa pelo nome. Segundo benefício independente pede decomposição explícita/justificada.
- Habilidade que recupera PA requer análise de loop de energia; carga não vira PA por conversão implícita; qualificação `E3` nunca é E0.
- Estados de produção de receita e ficha: projeto/TEST separados de RC5/PS/P4.

## 5. Gate oficial pendente

Executar governança existente antes de qualquer mutação oficial: BOOTSTRAP-COMESTRE; NAC-CONT-03 `LER → ANTES → autoriz./reserva legítima → executar → reopen/readback → DEPOIS`; NAC-NORM-01 para regra nova; NAC-PASS-02 proporcional ao risco; writer/lease/fencing real quando necessário. Houve ZERO Notion writes nesta execução.

`NAC-PASS-TEST`: 52/52 local e 40/40 compatibilidade; 12 fichas TEST. `NAC-PASS-NORM/PRODUÇÃO`: HOLD (sem aceite independente, sem integração native CRAFT, sem promoção). Histórico original de R22/R23 preservado em ZIP com hashes no manifesto.

## 6. Ponto exato de retomada

Abrir `PSV_R24_RELATORIO_FINAL.md` e `DEMONSTRACOES_CONVERSACIONAIS_R24.json`; validar as 12 fichas e a suíte limpa. Próximo delta material: leitura mecânica das técnicas em imagens, completar especificações faltantes das 67/99, confrontar divergências 11/32 com comparadores físicos, aprovar tipologia bônus numérico × habilidade, habilitar R24 no workflow nativo CRAFT com write-set e migração normativa autorizados. Não refazer R01–R23 nem recomputar histórico antigo por rank proposto.
