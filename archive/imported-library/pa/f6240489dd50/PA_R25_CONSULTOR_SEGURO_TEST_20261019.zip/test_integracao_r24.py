"""Integration regression R24: categorical independence, contracts and explainability."""
import unittest
from motor_conversacional_r24 import *

class IntegrationR24(unittest.TestCase):
    def test_numeric_only_not_skill(self):
        a=analyze_item('Item: Anel\nRank do item: Bronze\nHabilidade passiva: Mega-força: +2 Força')
        self.assertEqual(a['costs']['day'],10)
        self.assertEqual(a['abilities'][0]['kind'],'NUMERICO_SEM_HABILIDADE_INDEPENDENTE')
    def test_detect_duplicate_stat(self):
        a=analyze_item('Item: Anel\nRank do item: Bronze\nBônus: +3 FOR\nHabilidade passiva: Força: +3 FOR')
        self.assertEqual(a['costs']['day'],15)
        self.assertIn('DUPLICADA',' '.join(a['warnings']))
    def test_rank_provided_by_master_distinct_from_item(self):
        a=analyze_item('Item: Selo\nRank do item: Lendário\nHabilidade ativa Bronze: Fagulha: Causa 3d6 de dano num alvo único.')
        self.assertEqual(a['abilities'][0]['rank'],'Bronze')
        self.assertTrue(a['abilities'][0]['rank_evidence'].startswith('E0_MESTRE'))
        self.assertEqual(a['costs']['day'],90)
    def test_no_paid_to_upgrade_rank(self):
        a=rank_infer('Com ação padrão causa 8d10 de dano em alvo único, custo 900 PA')
        b=rank_infer('Com ação padrão causa 8d10 de dano em alvo único, custo 1 PA')
        self.assertEqual(a['rank'],b['rank'])
    def test_ability_same_effect_duplicate(self):
        a=analyze_item('Item: Cinto\nRank do item: Ouro\nHabilidade ativa: Feixe I: Causa 8d10 de dano a um alvo único\nHabilidade ativa: Feixe II: Causa 8d10 de dano a um alvo único')
        self.assertEqual(len(a['abilities']),1)
        self.assertIn('DUPLICADA',' '.join(a['warnings']))
    def test_separate_activation_costs(self):
        a=analyze_item('Item: Vareta\nRank do item: Ouro\nHabilidade ativa: Chama: Causa 8d10 de dano a um alvo único',uses={'Chama':3})
        self.assertEqual(a['costs']['day'],21)
        self.assertEqual(a['costs']['activations'],42)
        self.assertEqual(a['costs']['total'],63)
    def test_zero_usage_still_daily(self):
        a=analyze_item('Item: Vareta\nRank do item: Ouro\nHabilidade ativa: Chama: Causa 8d10 de dano a um alvo único')
        self.assertEqual(a['costs']['day'],21)
        self.assertEqual(a['costs']['activations'],0)
    def test_rank_mismatch_warn(self):
        a=analyze_item('Item: Selador\nRank do item: Bronze\nHabilidade ativa Lendário: Negar Morte: Permite ressuscitar o usuário')
        self.assertTrue(any('CONFLITO_ITEM_RANK' in s for s in a['warnings']))
    def test_unknown_utility_does_not_force_rank(self):
        a=analyze_item('Item: Amuleto\nHabilidade passiva: Poder: É capaz de mudar os caminhos da existência')
        self.assertIsNone(a['item_rank'])
    def test_closure_daily_status(self):
        a=analyze_item('Item: Manopla\nRank do item: Prata\nBônus: +2 FOR')
        self.assertEqual(a['costs']['mathematical_completeness'],'CALCULO_FECHADO_SOMENTE_EM_TEST')
        self.assertFalse(a['can_publish'])
    def test_incomplete_bonus_state(self):
        a=analyze_item('Item: Manopla\nRank do item: Prata\nBônus: +8 RDF')
        self.assertEqual(a['costs']['mathematical_completeness'],'INCOMPLETA_OU_E3')
        self.assertTrue(any('BONUS_NAO_RECONHECIDO' in x for x in a['warnings']))
    def test_source_ledger_lookup(self):
        a=consultar_pesquisa_r22('Traje águia celeste','Voo da Águia')
        self.assertIsNotNone(a);self.assertIn('https://app.notion.com',a['fonte'])
    def test_same_historical_effect_no_write(self):
        a=analyze_item('Item: Traje águia celeste\nHabilidade ativa: Voo da Águia: Com uma ação salta 4,5m',source_kind='HISTORICO')
        self.assertTrue(a['abilities'][0]['study_r22']);self.assertFalse(a['can_write_notion'])
    def test_no_rewrite_historical_PA(self):
        a=analyze_item('Item: Traje águia celeste\nRank do item: Prata\nHabilidade ativa: Voo da Águia: Como ação de movimento salta 4,5m; 4 PA por uso histórico',source_kind='HISTORICO')
        self.assertFalse(a['can_publish']);self.assertIn('LEGADO',','.join(a['warnings']))
    def test_circle_default_trace(self):
        a=analyze_item('Item: Arma\nHabilidade ativa: Trovão: Com ação padrão cria círculo de raio 3 metros e causa 8d10 de dano')
        geo=a['abilities'][0]['spatial'];self.assertEqual(geo['raio']['valor'],3);self.assertEqual(geo['alcance']['valor'],9)
        self.assertEqual(geo['alcance']['origem'],'ALCANCE_REGRA_GERAL_MESTRE')
    def test_explicit_circular_range_kept(self):
        a=analyze_item('Item: Arma\nHabilidade ativa: Trovão: Com ação padrão cria círculo de raio 3 metros; alcance 18 metros; causa 8d10 de dano')
        geo=a['abilities'][0]['spatial'];self.assertEqual(geo['raio']['valor'],3);self.assertEqual(geo['alcance']['valor'],18)
        self.assertEqual(geo['alcance']['origem'],'ALCANCE_EXPLÍCITO')
    def test_multiple_targets_no_cone(self):
        a=analyze_item('Habilidade ativa: Tempestade: Com uma ação cobre os inimigos ao redor com choque')
        self.assertEqual(a['abilities'][0]['spatial']['forma'],'INDEFINIDA')
    def test_no_invented_radius_for_gravity(self):
        a=analyze_item('Habilidade ativa: Gravidade Abissal: Cria campo de gravidade que prende inimigos')
        self.assertIsNone(a['abilities'][0]['spatial']['raio']['valor'])
        self.assertIsNone(a['abilities'][0]['rank'])
    def test_armor_CA_is_physical(self):
        a=analyze_item('Item: Armadura de Zephyr\nRank do item: Lendário\nBônus: +15 DES; +11 CA de armadura física; +25 ataque; +15m de deslocamento')
        self.assertEqual(a['numeric_pa_day'],115)
        self.assertEqual(a['costs']['day'],115)
    def test_no_force_global_cost_for_legacy(self):
        a=analyze_item('Item: Armadura de Zephyr\nRank do item: Lendário\nBônus: +15 DES; +25 ataque; +15m de deslocamento',source_kind='HISTORICO')
        self.assertNotEqual(a['costs']['quote_state'],'PUBLISHED')
    def test_fixtures_immaterial_to_notion(self):
        a=analyze_item('Item: Cinto\nRank do item: Bronze\nBônus: +1 FOR')
        self.assertFalse(a['can_write_notion'])
    def test_source_kind_not_rank_signal(self):
        s='Item: Cristal\nHabilidade ativa: Fagulha: Causa 8d10 de dano a um alvo único'
        a=analyze_item(s,source_kind='HISTORICO')
        b=analyze_item(s,source_kind='NOVO_TEST')
        self.assertEqual(a['abilities'][0]['rank'],b['abilities'][0]['rank'])
    def test_dme_band_boundary(self):
        a=rank_infer('Causa 3d6 de dano em alvo único')
        self.assertEqual(a['rank'],'Bronze')
        self.assertEqual(a['evidence'],'E3_PROPOSTO')
    def test_multi_rider_not_numeric_simple(self):
        a=rank_infer('Ataca e causa 3d8+8 de dano por turno, envenena e imobiliza por 4 turnos')
        self.assertNotEqual(a['evidence'],'E0')
    def test_pa_positive_guard(self):
        a=rank_infer('Ao receber magia, recupera 3 PA automaticamente')
        self.assertIsNone(a['rank'])
    def test_recovery_not_per_turn_falsely_ranked(self):
        a=rank_infer('Recupera 6 pontos de vida por turno até a próxima cena')
        self.assertIsNone(a['rank'])

if __name__=='__main__':unittest.main(verbosity=2)
