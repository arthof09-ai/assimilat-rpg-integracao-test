# Armadura de Zephyr — PREVIEW MESTRE R25 / TEST
**Estado:** HOLD · **Produção:** HOLD
**Rank do item:** Lendário (DECLARADO_PELO_USUARIO_NAO_COMPROVA_RANK_CANONICO)

## Habilidades e tarifas por componente
Nenhuma habilidade individual validada na extração.
- Excluído conscientemente do PA mágico: +11 CA de armadura física (CA_FISICA_SEM_TARIFA_MAGICA)
- Pendente de tarifa/especificação: +50 de dano de Vento por turno (DANO_RECORRENTE_EXIGE_ANALISE_DE_DURACAO_E_EFEITO)

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: PENDENTE PA/dia
- Subtotal parcial conhecido (não representa custo final): 115 PA/dia
- Piso do RI candidato: 90 PA/dia
- **Diário simulado:** PENDENTE PA/dia
- **Usos simulados:** PENDENTE PA
- **Total no cenário:** PENDENTE PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: LEGADO_DIAGNOSTICO_SEM_REPRECIFICACAO.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": 90, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- DANO_RECORRENTE_NAO_TARIFA_FIXA_POR_GOLPE
- LINHAS_NAO_SEGMENTADAS_PODEM_CONTER_HABILIDADES
- TEXTO_FORA_DA_GRAMATICA_EXAMINAR:['90 PA por dia']
- BENEFICIO_SEM_TARIFA_NAO_EQUIVALE_A_PA_ZERO
- ITEM_HISTORICO_NAO_REPRECIFICAR_NEM_SOMAR_TARIFA_NOVA

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
