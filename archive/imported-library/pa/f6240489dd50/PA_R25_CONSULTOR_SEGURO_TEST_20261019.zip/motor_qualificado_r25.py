"""R25 | CONSULTOR PA/ATLAS COM GATES DE CONFIABILIDADE | MESTRE-SIDE / TEST.

Extension of immutable R24, R23, R22.  Does not assert a universal classifier;
separates individual evidence, provisional ranking and conditional PA scenarios.
No Notion/Party write; uses an existing lab and source research when available.

API: avaliar(descricao, usos=None, origem='NOVO_TEST', evidencias=None)
CLI: python motor_qualificado_r25.py <textfile> [<usos.json>]
"""
from __future__ import annotations
from pathlib import Path
from typing import Any
from math import floor
import re, unicodedata, json, copy

import motor_conversacional_r24 as r24
from baseline_r22.rank_guard_r22 import BASE, FLOOR, RANKS, Effect, estimate_new_item

HERE=Path(__file__).resolve().parent

# Message means 'provenance in current input', NOT canonicity.
RANK_DESIGNADO = 'RANK_INTENCAO_DECLARADA_SEM_E0_DOCUMENTAL'
RANK_PROPOSTO = 'RANK_E3_SUGERIDO_DE_BENCHMARK'
RANK_PENDENTE = 'RANK_PENDENTE_DE_COMPARADORES'
SOURCES={'atlas':r24.ATLAS_URL,'dmg':r24.DMG_URL,'magia':r24.MAGIA_URL}


def norm(t: str)->str:
    t=unicodedata.normalize('NFD',t.lower())
    return ''.join(c for c in t if unicodedata.category(c)!='Mn')


def _find_pa_explicit(text: str)->dict:
    s=norm(text)
    def _match(pat):
        m=re.search(pat,s)
        return int(m.group(1)) if m else None
    return {
        'pa_dia_textual':_match(r'(?<!\d)(\d+)\s*pa\s*(?:por\s+dia|/\s*dia|diari[oa])\b'),
        'pa_por_uso_textual':_match(r'(?<!\d)(\d+)\s*pa\s*(?:por\s+(?:ativacao|uso)|para\s+ativar|/\s*(?:uso|ativacao))\b'),
        'pa_avulso_sem_gatilho': _match(r'(?<!\d)(\d+)\s*pa\s*(?:\.|$)')
    }


def _parse_free_text(text: str) ->tuple[str,list[str],str]:
    """Simple natural-language router: consciously bounded to a single effect.

    It refuses to decompose compound powers or invent a skill for every stat.
    Original text is preserved in the audit.  The generated structured text is
    always TEST with an explicit extraction trace.
    """
    s=norm(text).strip()
    trace=[]
    if '\n' in text or re.search(r'^\s*(?:item|nome|bonus|habilidade)\s*:',s):
        return text,[], 'ESTRUTURADO_DECLARADO'
    if len(text)>4000:
        return text,['TEXTO_LIVRE_LONGO_EXIGE_SEGMENTACAO'], 'TEXTO_LIVRE_NAO_RECONCILIADO'
    # Multiple functional components are not automatically packed as one skill.
    verbs=[r'\b(?:dispar[ae]|lan[çc]a|atira|causa\s+\d+d\d+|cura|regenera)\b',
           r'\b(?:invisibilidade|invisivel|teleport|imobiliza|paralisa|controla|invoca)\b',
           r'\b(?:salta|salto|voa|voar|protege\s+contra|escudo\s+de)\b']
    categories=sum(bool(re.search(p,s)) for p in verbs)
    compound=bool(re.search(r'\b(?:alem disso|e tambem|e ainda|tambem pode|ou pode|e permite|duas habilidades|tres habilidades)\b',s))
    # Allow explicit stat prefix AND one functional power. Never auto-cost another.
    bonus_pat=r'\+\s*\d+\s*(?:de\s*)?(?:forca|destreza|constituicao|inteligencia|sabedoria|carisma|for\b|des\b|con\b|int\b|sab\b|car\b)'
    bonus=[m.group(0) for m in re.finditer(bonus_pat,s)]
    if compound or categories>1 or len(bonus)>1:
        return text,['EFEITOS_COMPOSTOS_EM_TEXTO_LIVRE_SEPARAR_HABILIDADES'], 'TEXTO_LIVRE_NAO_RECONCILIADO'
    name='Item mágico proposto'
    mm=re.search(r'\b(?:chamad[oa]|denominad[oa]|nomead[oa])\s+[\"“]?([\w\s]{3,48})(?=[\"”.,;]|\s+(?:que|com|capaz)|$)',text,re.I)
    if mm:
        rawname=mm.group(1).strip(' \"“”').strip()
        name=re.split(r'\s+(?:que|quando|capaz|com|se)\b',rawname,1,flags=re.I)[0][:55]
    else:
        mf=re.search(r'\b(anel|botas?|armadura|varinha|cajado|espada|cetro|manto|colar|amuleto|bracelete|escudo|manoplas?)\b',norm(text))
        if mf:name=mf.group(1).capitalize()+' (sem nome definido)'
    lines=[f'Item: {name}']
    mr=re.search(r'(?:item|equipamento)\s+(?:de\s+)?(?:rank|classificacao)\s+(bronze|prata|ouro negro|ouro|lend[aá]rio)',s)
    if mr:lines.append('Rank do item: '+mr.group(1))
    if bonus: lines.append('Bônus: '+'; '.join(bonus))
    if categories==0 and bonus:
        return '\n'.join(lines), ['RANK_ITEM_NAO_AUTO_INFERIDO_DE_BONUS_NUMERICOS'], 'LIVRE_BONUS_RECONHECIDO'
    if categories==0:
        return text,['EFEITO_LIVRE_SEM_CATEGORIA_MECANICA_IDENTIFICAVEL'], 'TEXTO_LIVRE_NAO_RECONCILIADO'
    # One effect. Determine kind from explicit action/selection, else leave pending.
    if re.search(r'\b(?:ativar|acionar|com (?:uma )?acao|usando (?:uma )?acao|com sua acao|pode usar|permite\s+ativar|lancar uma magia)\b',s):
        mode='ativa'
    elif re.search(r'\b(?:permanentemente|sempre que|automaticamente|enquanto (?:usa|equipa|vest[ei]))\b',s):
        mode='passiva'
    else:mode=''
    if not mode:
        lines.append('Habilidade: Efeito livre: '+text)
        trace.append('MODALIDADE_NAO_EVIDENCIADA')
    else:
        lines.append(f'Habilidade {mode}: Efeito livre: {text}')
    # Mechanic segmentation has one identified effect; still never a canonical E0.
    trace.append('EXTRACAO_LIVRE_UNICA_SEM_ATESTAR_EXAUSTIVIDADE') if (bonus or '\n' in text) else None
    return '\n'.join(lines),trace,'LIVRE_UNICO_EFEITO_EXTRAIDO'


def _contradiction(ability: dict)->list[str]:
    s=norm(ability.get('text',''))
    problems=[]
    kd=ability.get('kind_declared')
    if kd=='PASSIVA' and re.search(r'\b(?:como uma acao|(?:pode )?usar sua reacao|usa sua reacao|ao ativar|para ativar|ativa voluntariamente|gasta uma acao)\b',s):
        problems.append('MODALIDADE_DECLARADA_PASSIVA_CONTRADIZ_ACAO_ATIVAVEL')
    if kd=='ATIVA' and re.search(r'\b(?:permanentemente|automaticamente sem acao|sempre ativa sem acao)\b',s):
        problems.append('MODALIDADE_DECLARADA_ATIVA_CONTRADIZ_PERMANENCIA')
    return problems


def _numeric_inspection(parsed:dict)->list[str]:
    issues=[]
    # The same named source must not appear in several independently charged fields.
    all_nums=[]
    for x in parsed['bonuses']:
        for m in re.finditer(r'\+\s*(\d+)\s*(?:de\s*)?(?:forca|destreza|constituicao|inteligencia|sabedoria|carisma|for\b|des\b|con\b|int\b|sab\b|car\b)',norm(x)):
            all_nums.append(m.group(0).replace(' ',''))
        if re.search(r'\b(?:condicional|so quando|apenas quando|durante|em combate|se\s+\w+)\b',norm(x)):
            issues.append('BONUS_NUMERICO_CONDICIONAL_NAO_TARIFAR_AUTOMATICAMENTE')
        # _numeric_components currently parses integers only for non-attribute axes.
        if re.search(r'\+\s*\d+(?:[,.]\d+)?\s*(?:reflexo|salvaguarda|rd\b|rdm\b|rdf\b)',norm(x)):
            issues.append('TARIFA_DE_REFLEXO_SALVAGUARDA_RD_NAO_DEFINIDA_POR_MESTRE')
    if len(all_nums)!=len(set(all_nums)):
        issues.append('BONUS_IDENTICO_REPETIDO_EXIGE_DESAMBIGUACAO_DE_ORIGEM')
    return list(dict.fromkeys(issues))




def _audit_numeric_charges(parsed:dict)->dict:
    """Independent R25 audit of known, permanent quantitative modifiers.

    Never reuse R24's unqualified flat-damage parse for damage-per-turn,
    conditional effects, reflex/RD without a tariff, or physical armor CA.
    All exclusions carry their original text and a reason.
    """
    vals={'FOR':0,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0,
          'dano':0,'ataque':0,'deslocamento_m':0,'ca_magica':0}
    blocked=[];noncharged=[];unpriced=[];seen_numeric=[]
    for line in parsed['bonuses']:
        chunks=re.split(r'[;,|]|\s+e\s+(?=\+)',line)
        for raw in chunks:
            t=norm(raw.strip())
            if not t:continue
            if re.search(r'\+\s*\d+[.,]\d+',t):
                blocked.append('BONUS_FRACIONARIO_NAO_ARREDONDAR_SEM_REGRA')
                unpriced.append({'trecho':raw.strip(),'motivo':'BONUS_FRACIONARIO_EXIGE_REGRA_EXPLICITA'})
                continue
            # An enchanted armor may have a physical CA rating and a separate
            # magical increment; do not infer its magical increment from name.
            if re.search(r'\+\s*\d+\s*(?:de\s*)?ca\s+de\s+armadura\s+magica',t):
                blocked.append('CA_ARMADURA_MAGICA_NAO_PROVA_BONUS_CA_ENCANTADO')
                unpriced.append({'trecho':raw.strip(),'motivo':'DIFERENCIAR_CA_CHASSI_E_BONUS_ENCANTADO'})
                continue
            # Explicit physical CA is *not magical tariff*; distinguish from
            # ambiguous CA where the mechanism really is unknown.
            if re.search(r'\+\s*\d+\s*(?:de\s*)?(?:ca|classe de armadura)\b',t) and re.search(r'\b(?:armadura fisica|ca de armadura|armadura leve|armadura media|armadura pesada|fisic[ao])\b',t) and not re.search(r'\b(?:ca magica|encantamento)\b',t):
                noncharged.append({'trecho':raw.strip(),'motivo':'CA_FISICA_SEM_TARIFA_MAGICA'})
                continue
            if re.search(r'\+\s*\d+[^;,.]*\b(?:dano|danos)\b[^;,.]*\b(?:por turno|por rodada|a cada turno|por segundo)\b',t):
                blocked.append('DANO_RECORRENTE_NAO_TARIFA_FIXA_POR_GOLPE')
                unpriced.append({'trecho':raw.strip(),'motivo':'DANO_RECORRENTE_EXIGE_ANALISE_DE_DURACAO_E_EFEITO'})
                continue
            if re.search(r'\b(?:somente|apenas|se o|se a|quando|enquanto|contra|durante|temporariamente|temporario|condicional)\b',t):
                blocked.append('BONUS_CONDICIONAL_NAO_EQUIVALE_A_MODIFICADOR_PERMANENTE')
                unpriced.append({'trecho':raw.strip(),'motivo':'CONDICAO_OU_DURACAO_A_APURAR'})
                continue
            numerico_bruto=re.sub(r'(?<=\d)\s+em\s+(?=testes?\s+(?:de|do)\s+(?:ataque|acerto))',' ',raw.strip(),flags=re.I)
            n,warning=r24.numeric_components(numerico_bruto)
            if warning:
                blocked.extend('EIXO_NUMERICO_INCOMPLETO:'+x for x in warning)
                unpriced.append({'trecho':raw.strip(),'motivo':'TARIFA_OU_NATUREZA_NAO_DEFINIDA'})
                continue
            for k,v in n.items():
                if not v:continue
                if (k,v) in seen_numeric:
                    blocked.append('BONUS_IDENTICO_REPETIDO_EXIGE_PROVENIENCIA')
                    unpriced.append({'trecho':raw.strip(),'motivo':'MESMO_VALOR_EIXO_JA_LISTADO_NOUTRA_PARCELA'})
                    continue
                seen_numeric.append((k,v))
                vals[k]+=v
    return {'componentes_cobraveis':vals,'subtotal_reconhecido_pa':r24.numeric_pa(vals),
            'nao_cobrados_conhecidos':noncharged,'componentes_nao_precificados':unpriced,
            'bloqueios':list(dict.fromkeys(blocked))}


def _normalize_numeric_passives(converted:str)->tuple[str,list[dict],list[str]]:
    """Separate a passive containing *only known numeric statistics* from a
    functional ability. No second flat skill tariff for decorative names.
    Refuse conditional/temporary boosts and any unknown tariff axis.
    """
    parsed=r24.parse_item(converted)
    remove=[];seen=set(norm(x.strip()) for x in parsed['bonuses']);warnings=[]
    for a in parsed['abilities']:
        if a.get('kind_declared')!='PASSIVA':continue
        t=a['text'].strip()
        if not t.startswith('+'):continue
        if re.search(r'\b(?:durante|turnos|se|condicional|uma vez|temporari|ate o|por rodada)\b',norm(t)):
            continue
        n,w=r24.numeric_components(t)
        count=len(re.findall(r'\+\s*\d+',t))
        if w or count!=sum(1 for v in n.values() if v>0):continue
        if not count:continue
        remove.append({'nome':a['name'],'texto':a['text'],'componente':n})
    if not remove:return converted,[],warnings
    result=[]
    for line in converted.splitlines():
        if re.match(r'\s*habilidade\s+passiva\b',norm(line)):
            target=next((x for x in remove if x['texto'].strip() in line and x['nome'] in line),None)
            if target:
                if norm(target['texto']) in seen:
                    warnings.append('BONUS_PASSIVO_NOMEADO_DUPLICADO_NA_LISTA:'+target['nome'])
                    continue
                seen.add(norm(target['texto']))
                result.append('Bônus: '+target['texto'])
                continue
        result.append(line)
    return '\n'.join(result),remove,warnings

def _strict_effect_gates(raw_ability:dict, interpretation:dict)->dict:
    """Guard against rank guesses using bands outside DMG's declared scope."""
    s=norm(raw_ability.get('text',''))
    issues=_contradiction(raw_ability)
    axes=interpretation.get('axis') or []
    is_dice=bool(re.search(r'\b\d+\s*d\s*\d+\b',s))
    has_damage=bool(re.search(r'\b(?:dano|causa|inflige|sofre)\b',s))
    ambiguity=['imunidade total','nega a morte','destino','teletransporte','reviver']
    if any(x in s for x in ambiguity):issues.append('BYPASS_REQUER_REFERENCIA_E_LIMITES')
    # Damage expression may be unrelated to the rank (e.g. a character's other attacks).
    conditional_damage=bool(re.search(r'\b(?:dano extra|dano adicional|bonus de dano|acrescenta|critico|acerto critico|se acertar|sangramento|veneno|atravessando)\b|(?:\dd\d+[^.;]{0,30}\b(?:de dano|dano)\s+por\s+(?:turno|rodada))|\b(?:so|apenas|exclusivamente)\s+contra\b',s))
    geometry=bool(re.search(r'\b(?:cone|circulo|circular|raio\s+de|linha|em area|area de|varios alvos|todos os alvos|todos os inimigos|multiplos|cada criatura)\b',s))
    control=bool(re.search(r'\b(?:imobiliza|paralisa|cego|cega|atordoa|enfeitica|petrifica|gravidade|silencia|empurra|derruba|medo|aprisiona|congela|teletransporta)\b',s))
    multihit=bool(re.search(r'\b(?:tres golpes|dois golpes|multiplos projeteis|cada flecha|ataques adicionais|duas vezes por acao|varias vezes)\b',s))
    user_stat=bool(re.search(r'\+\s*(?:for\b|des\b|con\b|int\b|sab\b|car\b|ff\b)',s))
    if is_dice and has_damage:
        if geometry:issues.append('DME_PADRAO_DMGRANK_INVALIDO_PARA_AREA_OU_LINHA')
        if control:issues.append('DME_PADRAO_DMGRANK_INVALIDO_PARA_CONTROLE_COM_RIDER')
        if conditional_damage:issues.append('DME_NAO_EQUIVALE_A_DANO_INTRINSECO_ISOLADO')
        if multihit:issues.append('DME_MULTI_HIT_EXIGE_ORCAMENTO_POR_ACAO')
        if user_stat:issues.append('DME_CONTEM_ATRIBUTO_DO_USUARIO')
        if len(re.findall(r'\b\d+\s*d\s*\d+\b',s))>1:issues.append('MULTIPLOS_POOLS_DANO_EXIGEM_IDENTIFICACAO_DE_MODOS')
        if re.search(r'\b(?:cura|vida|recupera|resistencia|escudo|protecao)\b',s):issues.append('EFEITO_MISTO_OFENSIVO_SUPORTE')
        # Ensure 100% action Padrão and one target for the *standard* DMG band.
        if not re.search(r'\b(?:acao padrao|acao\s+padrao|uma acao padrao)\b',s):
            issues.append('DME_PADRAO_SEM_ACAO_PADRAO_CONFIRMADA')
        if not re.search(r'\b(?:alvo unico|um unico alvo|num unico alvo|num alvo|em um alvo|a um alvo|um alvo|um inimigo|uma criatura)\b',s):
            issues.append('DME_PADRAO_SEM_ALVO_UNICO_CONFIRMADO')
    if re.search(r'\b(?:sempre que|cada vez que|ao receber|quando sofrer)\b',s) and re.search(r'\b(?:gera|ganha|recupera|restaura)\s*\d+\s*pa\b',s):
        issues.append('RECURSIVIDADE_DE_PA_SEM_LIMITE_EXPLICITO')
    if re.search(r'\b(?:controla todo|faz qualquer|invencivel|infinit[oa]|sem limite|qualquer coisa)\b',s):
        issues.append('PODER_SEM_LIMITES_VERIFICAVEIS')
    if re.search(r'\b(?:aumenta|concede|ganha)\s*\+\s*\d+\s*(?:for|des|con|int|sab|car|forca|destreza|inteligencia|constituicao|sabedoria|carisma)\b',s) and re.search(r'\b(?:por\s+\d+\s+turno|temporaria|durante)\b',s):
        issues.append('BUFF_TEMPORARIO_NAO_DUPLICAR_TARIFA_PERMANENTE')
    return {'issues':list(dict.fromkeys(issues)), 'scope': 'DMG_PADRAO_VALIDO' if is_dice and has_damage and not issues else 'PRECISA_ATLAS_COMPLETO', 'axes':axes}


def _confidence_gates(ability:dict, old:dict, raw_ability:dict, context:dict, origin:str)->dict:
    g=_strict_effect_gates(raw_ability,old)
    issues=list(g['issues']); rank=old.get('rank')
    # Internal hypotheses are not independent human or E0 ground truth.
    declared=raw_ability.get('rank_declared')
    if declared:
        if any(x in issues for x in ('DME_PADRAO_DMGRANK_INVALIDO_PARA_AREA_OU_LINHA','DME_NAO_EQUIVALE_A_DANO_INTRINSECO_ISOLADO')):
            issues.append('RANK_DECLARADO_DEVE_SER_ESTRESSADO_COM_ATLAS')
        if g['scope']=='DMG_PADRAO_VALIDO' and declared in r24.BANDS:
            dme,extra=r24.read_dice(raw_ability.get('text',''))
            lo,hi,_=r24.BANDS[declared]
            if dme is not None and not extra and not lo<=dme<=hi:
                issues.append('RANK_DECLARADO_DISSONANTE_BANDA_DMGRANK')
        return {'candidate':declared,'usable_for_provisional_cost':not bool(issues),
                'certification':RANK_DESIGNADO,'issues':list(dict.fromkeys(issues)),
                'confidence':'DESIGN_INFORMADO_NAO_CANONICO','status':'VALIDACAO_DE_DESIGN' if not issues else 'HOLD_COM_CONFLITO'}
    if not rank:
        return {'candidate':None,'usable_for_provisional_cost':False,
                'certification':RANK_PENDENTE,'issues':list(dict.fromkeys(issues))+['RE_SEM_RANK_ADMISSIVEL'],
                'confidence':'SEM_CONCLUSAO','status':'HOLD_EVIDENCIA'}
    if rank not in RANKS:
        return {'candidate':None,'usable_for_provisional_cost':False,
                'certification':RANK_PENDENTE,'issues':list(dict.fromkeys(issues))+['RANK_FORA_DO_ATLAS'],
                'confidence':'SEM_CONCLUSAO','status':'HOLD_EVIDENCIA'}
    if issues:
        return {'candidate':rank,'usable_for_provisional_cost':False,
                'certification':RANK_PROPOSTO,'issues':issues,
                'confidence':'NAO_CALIBRADO','status':'HOLD_RE_CLASSIFICAR_PELO_ATLAS'}
    # A numerical isolated attack can at least be a testable E3 proposal.
    if g['scope']=='DMG_PADRAO_VALIDO':
        return {'candidate':rank,'usable_for_provisional_cost':True,
                'certification':RANK_PROPOSTO,'issues':[],
                'confidence':'E3_CONDICIONAL_AO_DMGRANK','status':'CANDIDATO_E3'}
    # Non-damage heuristics retain a *suggestion*, but are NOT a tariff-ready rank.
    return {'candidate':rank,'usable_for_provisional_cost':False,
            'certification':RANK_PROPOSTO,'issues':['SEM_BENCHMARK_E0_INDEPENDENTE_DA_HABILIDADE'],
            'confidence':'E3_COMPARADORES_FRACOS','status':'HOLD_COMPARADORES'}



def _comparadores_fornecidos_gate(name:str, evidence:dict|None, original:dict)->dict:
    """Controlled *E3* widening: reviewer-supplied evidence is not automatically
    authenticated from URLs. Enough independent comparators + full mechanics
    can enable a provisional quote, never E0/P4 or official costs.
    """
    if not evidence:return original
    if not isinstance(evidence,dict):return original
    rank=evidence.get('rank_candidato')
    if rank not in RANKS:
        return {**original,'usable_for_provisional_cost':False,
                'status':'HOLD_EVIDENCIA_RANK_AUSENTE',
                'issues':list(original['issues'])+['EVIDENCIA_EXTERNA_SEM_RE_CANDIDATO']}
    required=('gatilho','alvo','duracao','resultado','limites')
    fields=evidence.get('mecanica',{})
    if not isinstance(fields,dict) or any(not str(fields.get(k,'')).strip() for k in required):
        return {**original,'usable_for_provisional_cost':False,
                'status':'HOLD_MECANICA_INCOMPLETA',
                'issues':list(original['issues'])+['CINCO_CAMPOS_MECANICOS_NECESSARIOS']}
    comps=evidence.get('comparadores',[])
    if not isinstance(comps,list):comps=[]
    admissible=[]
    for c in comps:
        if not isinstance(c,dict):continue
        tp=c.get('tipo')
        url=c.get('fonte','')
        reason=str(c.get('comparacao','')).strip()
        if tp in ('sistemico','vivo','familia') and url.startswith('https://app.notion.com/p/') and len(reason)>=18:
            # Price-only/PA-only observations cannot classify power.
            n=norm(reason)
            if re.fullmatch(r'.*(?:custa|preco|med)\s*\d+.*',n) and not re.search(r'\b(?:dano|controle|alcance|area|duracao|alvo|cd|resistencia|cura|defesa|efeito|mobilidade)\b',n):
                continue
            admissible.append((tp,url))
    if len({x[0] for x in admissible})<2 or len({x[1] for x in admissible})<2:
        return {**original,'usable_for_provisional_cost':False,
                'status':'HOLD_COMPARADORES_INSUFICIENTES',
                'issues':list(original['issues'])+['MINIMO_2_COMPARADORES_DISTINTOS_E_MECANICOS']}
    # Any substantive contradictions detected by direct mechanics are not
    # overridden by pasted references.
    hard=[x for x in original['issues'] if x not in ('SEM_BENCHMARK_E0_INDEPENDENTE_DA_HABILIDADE','RE_SEM_RANK_ADMISSIVEL')]
    if hard:
        return {**original,'usable_for_provisional_cost':False,
                'status':'HOLD_CONFLITO_MECANICO_APESAR_DE_FONTES',
                'issues':hard+['COMPARADORES_NAO_SUPRIMEM_CONFLITOS']}
    if original['candidate'] and original['candidate'] != rank:
        return {**original,'usable_for_provisional_cost':False,
                'status':'HOLD_DIVERGENCIA_COM_RANK_E3',
                'issues':['PARECER_DE_COMPARADORES_DIVERGE_DO_CLASSIFICADOR_INICIAL']}
    return {**original,'candidate':rank,'usable_for_provisional_cost':True,
            'status':'CANDIDATO_E3_COM_COMPARADORES_FORNECIDOS',
            'confidence':'E3_COMPARADORES_FORNECIDOS_NAO_AUTENTICADOS_PELO_MOTOR',
            'certification':'RE_CANDIDATO_APOIADO_EM_EVIDENCIA_FORNECIDA',
            'issues':[],'evidence_urls':[z[1] for z in admissible]}

def avaliar(descricao:str, *, usos:dict[str,int]|None=None,
            origem:str='NOVO_TEST', evidencias:dict[str,Any]|None=None)->dict:
    """Safe consultative interface from description to *reviewable* sheet.

    Every result is experimental. A proposed rank with no source-backed basis
    or unresolved mechanics returns HOLD, not a definitive price. An ability
    with missing rank never silently counts as zero.
    """
    if origem not in ('NOVO_TEST','HISTORICO'):raise ValueError('origem invalida')
    if not isinstance(descricao,str) or not descricao.strip():raise ValueError('descricao vazia')
    if usos is not None and (not isinstance(usos,dict) or any(type(n)!=int or n<0 for n in usos.values())):
        raise ValueError('usos devem ser inteiros nao negativos')
    converted,extraction_issues,extraction_state=_parse_free_text(descricao)
    if extraction_state=='TEXTO_LIVRE_NAO_RECONCILIADO':
        return {'status':'HOLD_SEGMENTACAO','name':'Item descrito livremente',
                'input':descricao,'conversion':None,'extraction_status':extraction_state,
                'issues':extraction_issues,'abilities':[],'numeric_pa_day':None,
                'pa':{'daily_scenario_pa':None,'activation_scenario_pa':None,'total_scenario_pa':None,
                      'confirmed_daily_pa':None,'bounds':'NAO_CALCULAVEL'},
                'canonical_write':False,'official_classification':False,
                'review_required':True,'reason':'Separar habilidades independentes antes de cobrar PA'}
    converted,numeric_only_sources,normalization_issues=_normalize_numeric_passives(converted)
    parsed=r24.parse_item(converted)
    base=r24.analyze_item(converted,uses=usos,source_kind=origem)
    audit_num=_audit_numeric_charges(parsed)
    issues=list(extraction_issues)+normalization_issues+audit_num['bloqueios']
    if parsed['unparsed']:issues.append('LINHAS_NAO_SEGMENTADAS_PODEM_CONTER_HABILIDADES')
    if base['warnings']:
        for w in base['warnings']:
            if w.startswith(('POSSIVEL_MULTIHABILIDADE','DESCRICAO_IDÊNTICA','CONFLITO_ITEM','TEXTO_FORA_DA')):
                issues.append(w)
    if _find_pa_explicit(descricao)['pa_avulso_sem_gatilho'] is not None and origem=='NOVO_TEST':
        issues.append('PA_AVULSO_NOVO_SEM_GATILHO_NAO_PROVA_TARIFA')
    abilities=[]
    if len(base['abilities']) != len(parsed['abilities']):
        issues.append('HABILIDADES_DUPLICADAS_OU_MAL_SEGMENTADAS')
    for i,old in enumerate(base['abilities']):
        ra=parsed['abilities'][i] if i<len(parsed['abilities']) else {'name':old['name'],'text':old['text']}
        if old['kind']=='NUMERICO_SEM_HABILIDADE_INDEPENDENTE':
            gate={'candidate':None,'usable_for_provisional_cost':False,'certification':'NAO_HABILIDADE',
                  'issues':[], 'status':'BONUS_NUMERICO_SOMENTE','confidence':'MECANICA_NUMERICA'}
        else:
            gate=_confidence_gates(old,old,ra,{},origem)
            if evidencias and isinstance(evidencias,dict):
                gate=_comparadores_fornecidos_gate(a_name:=old['name'],evidencias.get(a_name),gate)
        if old['kind'] not in ('ATIVA','PASSIVA','NUMERICO_SEM_HABILIDADE_INDEPENDENTE'):
            gate['issues'].append('ATIVA_VS_PASSIVA_NAO_DECIDIDO');gate['usable_for_provisional_cost']=False
            gate['status']='HOLD_MODALIDADE'
        if len(base['abilities']) != len(parsed['abilities']):gate['usable_for_provisional_cost']=False
        vals=copy.deepcopy(old)
        vals['qualidade_rank']=gate
        vals['tabela_tarifa_candidatos']={r:{'PA_dia':BASE[r] if old['kind']=='PASSIVA' else floor(BASE[r]/2) if old['kind']=='ATIVA' else None, 'PA_uso':floor(BASE[r]*.6) if old['kind']=='ATIVA' else 0} for r in old.get('rank_alternativas',[]) if r in BASE}
        # Strictly remove ability tariff if basis is not usable, but preserve a
        # *display-only* E3 candidate and its alternatives for Mestre review.
        if old['kind']=='NUMERICO_SEM_HABILIDADE_INDEPENDENTE':
            vals['custo_pa_dia_validado']=0; vals['custo_pa_uso_validado']=0
        elif gate['usable_for_provisional_cost'] and old['kind'] in ('ATIVA','PASSIVA'):
            chosen=gate['candidate']
            vals['custo_pa_dia_validado']= BASE[chosen] if old['kind']=='PASSIVA' else floor(BASE[chosen]/2)
            vals['custo_pa_uso_validado']= floor(BASE[chosen]*0.6) if old['kind']=='ATIVA' else 0
        else:
            vals['custo_pa_dia_validado']=None;vals['custo_pa_uso_validado']=None
        abilities.append(vals)
    irank=base['item_rank']
    ri_state='DECLARADO_PELO_USUARIO_NAO_COMPROVA_RANK_CANONICO' if parsed['item_rank_declared'] else 'RI_INFERIDO_E3' if irank else 'RI_INDETERMINADO'
    for a in abilities:
        if a['qualidade_rank']['issues']:
            issues.extend(f'{a["name"]}: {z}' for z in a['qualidade_rank']['issues'])
    # Check item rank not lower than effect candidate; lower-rank skill may live
    # in higher-rank item, vice-versa needs a power review.
    if irank:
        for a in abilities:
            cand=a['qualidade_rank']['candidate']
            if cand in RANKS and RANKS.index(cand)>RANKS.index(irank):
                issues.append(f'RI_ITEM_INFERIOR_AO_EFEITO:{a["name"]}')
    if audit_num['componentes_nao_precificados']:issues.append('BENEFICIO_SEM_TARIFA_NAO_EQUIVALE_A_PA_ZERO')
    # The noncanonical numerical sum is computed only if all numeric fields
    # were recognized with unambiguous permanent effects.
    numerically_clean=not audit_num['bloqueios'] and not any(('BONUS_PASSIVO_NOMEADO_DUPLICADO' in s or 'BONUS_IDENTICO_REPETIDO' in s) for s in issues)
    complete=bool(irank and numerically_clean and not parsed['unparsed'] and not extraction_issues
                  and not any(a['custo_pa_dia_validado'] is None for a in abilities)
                  and not any('RI_ITEM_INFERIOR_AO_EFEITO' in s for s in issues))
    # If no rate is guaranteed, do not call a *hypothesis* a physical lower bound.
    scenario=None; activation=None; total=None; day_effects=None
    if irank:
        qualified=[Effect(a['id'],a['qualidade_rank']['candidate'],a['kind'],'E3',uses=a['uses'])
                   for a in abilities if a['custo_pa_dia_validado'] is not None and a['kind'] in ('PASSIVA','ATIVA')]
        calc=estimate_new_item(irank,qualified,audit_num['subtotal_reconhecido_pa'])
        if numerically_clean:
            day_effects=calc['day_effects']
        if complete:
            scenario=calc['day'];activation=calc['activations'];total=calc['total']
    explicit=_find_pa_explicit(descricao)
    # Old values never get overwritten by prospective calculation.
    if origem=='HISTORICO':
        issues.append('ITEM_HISTORICO_NAO_REPRECIFICAR_NEM_SOMAR_TARIFA_NOVA')
        complete=False;scenario=None;activation=None;total=None
    issues=list(dict.fromkeys(issues))
    quote_state=('SIMULACAO_E3_CONDICIONAL' if complete and origem!='HISTORICO'
                 else 'LEGADO_DIAGNOSTICO_SEM_REPRECIFICACAO' if origem=='HISTORICO'
                 else 'HOLD_CUSTO_TOTAL_INDETERMINADO')
    result={
        'status':'PREVIA_CONDICIONAL' if complete and origem!='HISTORICO' else 'HOLD',
        'name':base['name'], 'input':descricao,'conversion':converted,
        'extraction_status':extraction_state,'item_rank_candidate':irank,
        'item_rank_evidence':ri_state,'abilities':abilities,
        'numeric_only_passives_preserved':numeric_only_sources,
        'numeric_components':audit_num['componentes_cobraveis'], 'numeric_pa_day':audit_num['subtotal_reconhecido_pa'] if numerically_clean else None,
        'numeric_audit':audit_num,
        'issues':issues,'source_kind':origem,'explicit_pa_historic_or_claimed':explicit,
        'pa':{'known_numerical_components_pa':audit_num['subtotal_reconhecido_pa'] if numerically_clean else None,
              'identified_subtotal_without_unpriced_effects_pa':audit_num['subtotal_reconhecido_pa'],
              'item_floor_pa':FLOOR[irank] if irank else None,
              'daily_effects_scenario_pa':day_effects if complete else None,
              'daily_scenario_pa':scenario,'activation_scenario_pa':activation,
              'total_scenario_pa':total,'confirmed_daily_pa':None,
              'bounds':'CENARIO_COM_RANKS_E3_NAO_LIMITE_FISICO' if complete else 'NAO_CALCULAVEL',
              'quote_state':quote_state},
        'review_required':True,'official_classification':False,'evidence_gate':'FONTES_EXTRAS_NAO_VALIDAM_SOZINHAS_A_FONTE_NO_NOTION',
        'canonical_write':False,'party_write':False,
        'authority_basis':SOURCES,
        'next_action':'MESTRE_REVISA_RANKS_E3_E_HOMOLOGA_DESIGN' if complete else 'COMPLEMENTAR_PARAMETROS_E_COMPARADORES_ANTES_DE_TARIFAR'}
    return result


def ficha(result:dict)->str:
    lines=[f'# {result["name"]} — PREVIEW MESTRE R25 / TEST',
           '**Estado:** '+result['status']+' · **Produção:** HOLD',
           f'**Rank do item:** {result.get("item_rank_candidate") or "INDETERMINADO"} ({result.get("item_rank_evidence", "sem evidencia")})',
           '', '## Habilidades e tarifas por componente']
    if not result['abilities']:lines.append('Nenhuma habilidade individual validada na extração.')
    for a in result['abilities']:
        g=a['qualidade_rank'];n=a['name'];
        lines.append(f'- **{n}** — {a["kind"]}; RE candidato **{g["candidate"] or "PENDENTE"}**; estado **{g["status"]}**; '+
                     f'PA/dia **{a["custo_pa_dia_validado"] if a["custo_pa_dia_validado"] is not None else "PENDENTE"}**; '+
                     f'PA/ativação **{a["custo_pa_uso_validado"] if a["custo_pa_uso_validado"] is not None else "PENDENTE"}**.')
        lines.append(f'  - Texto recebido: {a["text"]}')
        if g['issues']:lines.append('  - Pendências específicas: '+'; '.join(g['issues']))
        spatial=a.get('spatial')
        if spatial:
            desc=[]
            for fld in ('alcance','raio','extensao','origem'):
                v=spatial.get(fld)
                if isinstance(v,dict):
                    desc.append(f'{fld}={v.get("valor", "?")} ({v.get("origem", "?")})')
            lines.append('  - Geometria: '+spatial.get('forma','?')+'; '+'; '.join(desc))
            if spatial.get('ressalvas'):lines.append('  - Ressalvas espaciais: '+'; '.join(spatial['ressalvas']))
        if a.get('tabela_tarifa_candidatos') and a['custo_pa_dia_validado'] is None:
            lines.append('  - Tarifas sob RANKS HIPOTÉTICOS (não usar como preço fechado): '+json.dumps(a['tabela_tarifa_candidatos'],ensure_ascii=False))
    for bonus in result.get('numeric_only_passives_preserved',[]):
        lines.append('- **'+bonus['nome']+'**: apenas bônus numéricos permanentes; cobra somente tarifa por atributo/estatística, não habilidade adicional.')
    num_audit=result.get('numeric_audit',{})
    for x in num_audit.get('nao_cobrados_conhecidos',[]):lines.append('- Excluído conscientemente do PA mágico: '+x['trecho']+' ('+x['motivo']+')')
    for x in num_audit.get('componentes_nao_precificados',[]):lines.append('- Pendente de tarifa/especificação: '+x['trecho']+' ('+x['motivo']+')')
    p=result['pa'];lines.extend(['','## PA de novos itens (não altera custos históricos)',
        f'- Bônus numéricos reconhecidos: {p.get("known_numerical_components_pa") if p.get("known_numerical_components_pa") is not None else "PENDENTE"} PA/dia',
        f'- Subtotal parcial conhecido (não representa custo final): {p.get("identified_subtotal_without_unpriced_effects_pa")} PA/dia',
        f'- Piso do RI candidato: {p.get("item_floor_pa") if p.get("item_floor_pa") is not None else "PENDENTE"} PA/dia',
        f'- **Diário simulado:** {p.get("daily_scenario_pa") if p.get("daily_scenario_pa") is not None else "PENDENTE"} PA/dia',
        f'- **Usos simulados:** {p.get("activation_scenario_pa") if p.get("activation_scenario_pa") is not None else "PENDENTE"} PA',
        f'- **Total no cenário:** {p.get("total_scenario_pa") if p.get("total_scenario_pa") is not None else "PENDENTE"} PA',
        f'- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: {p.get("quote_state","HOLD_SEGMENTACAO")}.',
        f'- Custos já escritos no texto (apenas contexto histórico/declaração): {json.dumps(result.get("explicit_pa_historic_or_claimed",{}),ensure_ascii=False)}.',
        '', '## Pendências e próxima ação'])
    for x in result['issues'][:40]:lines.append('- '+x)
    if not result['issues']:lines.append('- Nenhuma lacuna local impeditiva; ranks E3 e produção seguem sem validação independente.')
    lines.extend(['', '**Fonte de poder:** '+SOURCES['atlas'], '**Fonte de dano:** '+SOURCES['dmg'],
                  '', '**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**'])
    return '\n'.join(lines)+'\n'


if __name__=='__main__':
    import sys
    if len(sys.argv)<2:raise SystemExit('Uso: python motor_qualificado_r25.py descricao.txt [usos.json]')
    text=Path(sys.argv[1]).read_text(encoding='utf-8')
    uses=json.loads(Path(sys.argv[2]).read_text('utf-8')) if len(sys.argv)>2 else None
    print(ficha(avaliar(text,usos=uses)))
