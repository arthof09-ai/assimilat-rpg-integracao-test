"""R23 TEST — Interpretador subsidiário de alcance do Mestre, sem editar fichas.

Autoridade: diretriz expressa do Mestre 19/10/2026, MESTRE-SIDE.
Somente MAGIA e HABILIDADE_MAGICA_ITEM; aplicação caso a caso e SEM custo PA implícito.
Dados específicos sempre prevalecem independentemente (alcance, raio, extensão, origem).
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import hypot, isfinite
from typing import Optional

ALCANCE_EXPLICITO = 'ALCANCE_EXPLÍCITO'
ALCANCE_REGRA_GERAL_MESTRE = 'ALCANCE_REGRA_GERAL_MESTRE'
ALCANCE_PENDENTE = 'ALCANCE_PENDENTE'
NAO_APLICAVEL = 'NÃO_APLICÁVEL'

FORMAS = {'ALVO_UNICO', 'CONE', 'CIRCULAR', 'LINHA', 'OUTRA', 'INDEFINIDA', 'AUTOCONJURADOR'}
FUNCOES = {'OFENSIVA', 'DEFENSIVA', 'UTILITARIA', 'MISTA', 'INDEFINIDA'}
FONTES = {'MAGIA', 'HABILIDADE_MAGICA_ITEM', 'HABILIDADE_NAO_MAGICA', 'EFEITO_NUMERICO'}

@dataclass(frozen=True)
class Especificacao:
    id: str
    fonte_tipo: str = 'MAGIA'
    funcao: str = 'INDEFINIDA'
    forma: str = 'INDEFINIDA'
    alcance_m: Optional[float] = None     # distancia conjurador->alvo ou conjurador->centro, se documentado
    raio_m: Optional[float] = None        # area circular
    extensao_m: Optional[float] = None   # comprimento de cone, ou linha se explicitamente definido
    origem: Optional[str] = None         # origem textual explicitamente documentada, não presumida
    abertura_cone_graus: Optional[float] = None   # propriedade específica; não há padrão mestre
    alvos: Optional[int] = None         # contagem expressa; não inferir por 'inimigos'
    regra_especifica: Optional[str] = None

class RegraInvalida(ValueError):
    pass

def _param(valor: Optional[float], campo: str) -> dict:
    if valor is None:
        return {'valor': None, 'origem': ALCANCE_PENDENTE}
    if isinstance(valor, bool) or not isinstance(valor, (int,float)) or not isfinite(valor) or valor < 0:
        raise RegraInvalida(f'{campo} deve ser numero finito nao negativo ou None')
    return {'valor': float(valor), 'origem': ALCANCE_EXPLICITO}

def aplicar_regra_mestre(spec: Especificacao) -> dict:
    """Normaliza geometria por parâmetro, preserva evidência e não atribui rank/PA.

    'CONE': o Mestre fixou extensão e origem; **não** fixou abertura angular.
    Geometria não escrita não é inferida pelo número de alvos.
    """
    if spec.fonte_tipo not in FONTES or spec.funcao not in FUNCOES or spec.forma not in FORMAS:
        raise RegraInvalida('tipo, funcao ou geometria não reconhecidos')
    if spec.alvos is not None and (type(spec.alvos) is not int or spec.alvos < 1):
        raise RegraInvalida('alvos devem ser inteiro >= 1')
    if spec.abertura_cone_graus is not None:
        a=spec.abertura_cone_graus
        if isinstance(a, bool) or not isinstance(a, (int,float)) or not isfinite(a) or not 0<a<=360:
            raise RegraInvalida('abertura cone deve estar entre 0 e 360 graus')
    if spec.origem is not None and not str(spec.origem).strip():
        raise RegraInvalida('origem explícita vazia')

    fields = {'alcance': _param(spec.alcance_m,'alcance_m'),
              'raio':_param(spec.raio_m,'raio_m'),
              'extensao':_param(spec.extensao_m,'extensao_m')}
    source_is_magic = spec.fonte_tipo in {'MAGIA', 'HABILIDADE_MAGICA_ITEM'}
    acoes=[]; ressalvas=[]
    if spec.origem is not None:
        origin={'valor':spec.origem,'origem':ALCANCE_EXPLICITO}
    else:
        origin={'valor':None,'origem':ALCANCE_PENDENTE}
    if not source_is_magic:
        acoes.append('NAO_APLICAR_PADRAO_A_EFEITO_NAO_MAGICO')
    elif spec.forma=='ALVO_UNICO':
        if spec.alvos not in (None,1):
            ressalvas.append('FORMA_ALVO_UNICO_INCOMPATIVEL_COM_ALVOS_MULTIPLOS')
        elif spec.funcao=='OFENSIVA' and fields['alcance']['valor'] is None:
            if spec.origem is not None and spec.origem not in ('conjurador','portador_conjurador'):
                ressalvas.append('ORIGEM_ESPECIFICA_DISTINTA_EXIGE_ANALISE_REFERENCIAL_DE_ALCANCE')
            else:
                fields['alcance']={'valor':9.0,'origem':ALCANCE_REGRA_GERAL_MESTRE}
                acoes.append('ALVO_UNICO_OFENSIVO_PADRAO_9M')
        elif spec.funcao!='OFENSIVA':
            acoes.append('NAO_APLICAR_9M_A_MAGIA_NAO_OFENSIVA_DE_ALVO_UNICO')
    elif spec.forma=='CONE':
        if spec.funcao=='OFENSIVA':
            if fields['extensao']['valor'] is None:
                fields['extensao']={'valor':4.5,'origem':ALCANCE_REGRA_GERAL_MESTRE}
                acoes.append('CONE_OFENSIVO_PADRAO_4_5M')
            if origin['valor'] is None:
                origin={'valor':'conjurador','origem':ALCANCE_REGRA_GERAL_MESTRE}
                acoes.append('CONE_ORIGEM_CONJURADOR')
            if spec.abertura_cone_graus is None:
                ressalvas.append('ABERTURA_ANGULAR_NAO_FIXADA_PELA_DIRETRIZ')
        else:
            ressalvas.append('CONE_NAO_OFENSIVO_SEM_PADRAO_DE_EXTENSAO')
    elif spec.forma=='CIRCULAR':
        if fields['alcance']['valor'] is None:
            if spec.origem is not None and spec.origem not in ('ponto_escolhido_pelo_conjurador','ponto_escolhido'):
                ressalvas.append('CENTRO_EXPLICITO_FIXO_OU_ORIGEM_ESPECIAL_NAO_CONVERTER_PARA_ALCANCE_9M')
            else:
                fields['alcance']={'valor':9.0,'origem':ALCANCE_REGRA_GERAL_MESTRE}
                acoes.append('CENTRO_CIRCULAR_ATE_9M')
        if fields['raio']['valor'] is None:
            fields['raio']={'valor':6.0,'origem':ALCANCE_REGRA_GERAL_MESTRE}
            acoes.append('RAIO_CIRCULAR_6M')
        if origin['valor'] is None:
            origin={'valor':'ponto_escolhido_pelo_conjurador','origem':ALCANCE_REGRA_GERAL_MESTRE}
            acoes.append('CENTRO_ESCOLHIDO_PELO_CONJURADOR')
    elif spec.forma in ('LINHA','OUTRA','INDEFINIDA','AUTOCONJURADOR'):
        acoes.append('SEM_PADRAO_SUBSIDIARIO_PARA_ESTA_FORMA')

    if spec.forma=='INDEFINIDA':
        ressalvas.append('MULTIPLOS_ALVOS_NAO_DETERMINAM_GEOMETRIA')
    if spec.forma=='LINHA':
        ressalvas.append('MAGIA_EM_LINHA_NAO_RECEBE_CONE_OU_CIRCULO_POR_PADRAO')
    if not source_is_magic and any(x['origem']==ALCANCE_REGRA_GERAL_MESTRE for x in fields.values()):
        raise AssertionError('fallback erroneamente aplicado a não-magia')
    estado='PADRAO_APLICADO' if any(x['origem']==ALCANCE_REGRA_GERAL_MESTRE for x in [*fields.values(),origin]) else 'SEM_PADRAO_APLICADO'
    return {'id':spec.id, 'fonte_tipo':spec.fonte_tipo, 'funcao':spec.funcao, 'forma':spec.forma,
            'alcance': fields['alcance'],'raio':fields['raio'],'extensao':fields['extensao'],
            'origem':origin,
            'diametro_m':2*fields['raio']['valor'] if spec.forma=='CIRCULAR' and fields['raio']['valor'] is not None else None,
            'abertura_cone_graus':spec.abertura_cone_graus,
            'estado':estado,'acoes':acoes, 'ressalvas':ressalvas,
            'rank_habilidade':None, 'delta_pa_por_geometria':0,
            'classificacao': 'RE_DEVE_SER_CLASSIFICADO_SEPARADAMENTE_PELO_ATLAS',
            'fonte_regra':'ORDEM DO MESTRE - REGRA GERAL DE ALCANCE DE MAGIAS - 2026-10-19'}

def area_circular_contem(*, caster:tuple[float,float], centro:tuple[float,float],
                          alvo:tuple[float,float], alcance_centro_m:float, raio_m:float)->dict:
    """Checagem planar determinista, não resolve linha de visão nem altura, nem imunidade."""
    for n in (*caster,*centro,*alvo,alcance_centro_m,raio_m):
        if not isinstance(n,(int,float)) or not isfinite(n):raise RegraInvalida('coordenadas não finitas')
    if alcance_centro_m<0 or raio_m<0:raise RegraInvalida('alcance e raio devem ser não negativos')
    dist_centro=hypot(centro[0]-caster[0],centro[1]-caster[1])
    dist_alvo=hypot(alvo[0]-centro[0],alvo[1]-centro[1])
    eps=1e-9
    return {'centro_valido':dist_centro<=alcance_centro_m+eps,
            'alvo_na_area':dist_alvo<=raio_m+eps,
            'distancia_conjurador_ao_centro_m':dist_centro,
            'distancia_alvo_ao_centro_m':dist_alvo,
            'atinge_alvo':dist_centro<=alcance_centro_m+eps and dist_alvo<=raio_m+eps,
            'alvo_conjurador_auto_imune': False, # não presume imunidade; efeito pode ou não atingi-lo
            'plano':'2D_TEST; altura, obstrução e autoimunidade dependem de regra específica'}
