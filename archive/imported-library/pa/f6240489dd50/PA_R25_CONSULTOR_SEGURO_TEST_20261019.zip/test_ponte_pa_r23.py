import csv,json,unittest
from pathlib import Path
from baseline_r22.rank_guard_r22 import Effect,GateError
from alcance_mestre_r23 import Especificacao
from ponte_pa_r23 import EfeitoComAlcance,simular_novo_item
D=Path(__file__).parent
class TestPontePA(unittest.TestCase):
    def test_pa_imutavel_9m_para_15m(self):
        e=Effect('golpe','Ouro','ATIVA','E2',uses=2)
        n=simular_novo_item('Ouro',[EfeitoComAlcance(e,Especificacao('golpe',funcao='OFENSIVA',forma='ALVO_UNICO'))])
        x=simular_novo_item('Ouro',[EfeitoComAlcance(e,Especificacao('golpe',funcao='OFENSIVA',forma='ALVO_UNICO',alcance_m=15))])
        self.assertEqual(n['pa_r22'],x['pa_r22']);self.assertEqual(n['pa_r22']['total'],49)
        self.assertEqual((n['geometrias'][0]['alcance']['valor'],x['geometrias'][0]['alcance']['valor']),(9,15))
    def test_circular_nao_aumenta_pa_sozinha(self):
        e=Effect('exp','Prata','ATIVA','E2',uses=1)
        x=simular_novo_item('Prata',[EfeitoComAlcance(e,Especificacao('exp',funcao='OFENSIVA',forma='CIRCULAR'))])
        self.assertEqual(x['delta_pa_do_alcance_mestre'],0)
        self.assertEqual((x['pa_r22']['day'],x['pa_r22']['activations'],x['pa_r22']['total']),(11,7,18))
    def test_cone_angulo_pendente_vlab(self):
        e=Effect('con','Bronze','ATIVA','E3',uses=1)
        x=simular_novo_item('Bronze',[EfeitoComAlcance(e,Especificacao('con',funcao='OFENSIVA',forma='CONE'))])
        self.assertEqual(x['gates_vlab'][0]['gate_vlab'],'TARGET_RESOLUTION_HOLD_ANGULO')
        self.assertEqual(x['pa_r22']['total'],11)
        self.assertTrue(x['pa_r22']['warnings'])
    def test_vinculo_efeitos_falha(self):
        with self.assertRaises(GateError):
            simular_novo_item('Ouro',[EfeitoComAlcance(Effect('a','Ouro','ATIVA','E2'),Especificacao('b',funcao='OFENSIVA',forma='CONE'))])
    def test_sem_habilidade_piso_preservado(self):
        a=simular_novo_item('Ouro Negro',[],numeric_pa=200)
        self.assertEqual(a['pa_r22']['total'],200)
        self.assertEqual(a['geometrias'],[])
    def test_caso_matriz_32_e_99(self):
        z=json.loads((D/'CASOS_ALCANCE_R23.json').read_text(encoding='utf-8'))
        self.assertEqual(len(z),32)
        self.assertEqual(sum(x['id'].startswith('REAL-') for x in z),18)
        self.assertEqual(sum(x['id'].startswith('FIX-') for x in z),14)
        for x in z:
            self.assertIsNone(x['saida']['rank_habilidade'])
            self.assertEqual(x['saida']['delta_pa_por_geometria'],0)
            if x['id'].startswith('REAL-'):
                self.assertTrue(x['fonte'].startswith('https://app.notion.com/p/'))
        with (D/'INDICE_99_TRIAGEM_R23.csv').open(encoding='utf-8-sig',newline='') as f:
            self.assertEqual(len(list(csv.DictReader(f,delimiter=';'))),99)
if __name__=='__main__':unittest.main()
