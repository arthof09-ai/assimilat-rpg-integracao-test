# PSV R25 — Aperfeiçoamento do Motor de Consumo de PA

**MESTRE-SIDE · 19/10/2026 · CONTINUIDADE R24 → R25 · PRODUÇÃO HOLD**

## Veredito executivo

O consultor experimental foi efetivamente melhorado: interpreta alguns textos livres completos, calcula o consumo quando há RE/RI e mecânica suficientes, produz ficha Mestre e detecta armadilhas que antes levavam a uma precisão falsa. **Não está provado que classifica corretamente qualquer habilidade desconhecida e ainda não existe integração nativa CRAFT/Notion.** Testar no laboratório não dá permissão para alterar o RPG.

| Unidade | Resultado real | Estado |
|---|---:|---|
| Suíte R25 de qualidade, regressão adversarial e metamórfica | 71/71 PASS | TEST VERIFICADO |
| Regressão intacta R22, R23, R24 | 92/92 PASS | TEST VERIFICADO |
| Demonstrações conversacionais geradas | 12/12 arquivos de ficha | TEST VERIFICADO |
| Demonstrações com cenário E3 calculável | 6/12 | PROPOSTO, NÃO HOMOLOGADO |
| Demonstrações em HOLD legítimo | 5/12 | PENDÊNCIA RASTREADA |
| Demonstrações que exigem segmentação de texto livre | 1/12 | HOLD SEGMENTAÇÃO |
| Corpus textual anterior R22 auditado | 99/99 | AUDITADO, NÃO CLASSIFICADO E0 |
| Corpus textual anterior elegível ao cálculo sem fonte adicional | 0/99 | SEM EVIDÊNCIA SUFICIENTE |
| Alterações em Notion, CRAFT, VLAB, Party, O Primeiro | 0 | NÃO EXECUTADAS |

**Nota metodológica:** 99 são observações RESUMIDAS do R22 e NÃO representam a população completa de habilidades do RPG. Os 26 rótulos nominais E0 entre 28 técnicas não são gabaritos mecânicos enquanto os efeitos relevantes permanecerem em imagem sem interpretação fonte-verificada. A taxa de acerto da classificação universal é **DESCONHECIDA**, nunca 100% ou 0% apenas por contagem de HOLD.

## DELTA físico e código preservado

O R25 é `motor_qualificado_r25.py`, um wrapper isolado que importa o `motor_conversacional_r24.py` original sem editar nenhuma linha. O R24 e seus baselines R22/R23 são mantidos no ZIP original. Inclui 71 testes R25, 92 regressões anteriores, 12 demonstrações, triagem 99, manual de conversa e documento de integração condicionado.

### Falhas identificadas e correções verificáveis

1. **DME simples aplicado indevidamente a área/cone/linha/múltiplos alvos, riders de controle, dano por turno e crítico.** Corrigido com gate de escopo: a banda original do DMG só propõe RE em dano intrínseco simples, alvo único, ação padrão, sem bypass. Outros casos ficam em HOLD até aplicação do Atlas completo.
2. **RE declarado incoerente com dano.** Hoje um RE Ouro declarado em um efeito padrão `100d100` gera bloqueio `RANK_DECLARADO_DISSONANTE_BANDA_DMGRANK` em vez de aceitação silenciosa.
3. **Parcela E3 cobrada como taxa fechada.** Separados `item_rank_candidate`, `qualidade_rank`, `tabela_tarifa_candidatos`, `daily_scenario_pa` versus `confirmed_daily_pa=None`. Lacuna => custo total indeterminado, não zero nem suposto limite inferior absoluto.
4. **Passiva decorativa de bônus estatísticos cobrada duas vezes.** Exemplo: `Habilidade passiva: Vigor: +2 FOR; +3 ataque` vira somente tarifa numérica de 13 PA/dia, sem tarifa funcional extra. Duplicatas entre duas seções geram HOLD para verificar origem.
5. **CA física/CA de armadura mágica e dano por turno mal interpretados.** CA explicitamente física é excluída da tarifa de CA mágica; armadura mágica sem decomposição da CA é ambígua. `+50 dano de Vento por turno` deixa de virar +50 de dano fixo por golpe. Zephyr tem parcelas identificadas +15 DES=75, +25 ataque=25, +15m=15, somando 115 PA/dia em **apenas três eixos**; +11 CA física excluída, +50 dano/turno pendente. O custo histórico de 90 PA/dia continua INALTERADO. Não concluir que 115 é seu novo custo correto.
6. **Descrições livres contendo poderes diferentes reduzidas a uma habilidade fictícia.** O parser aceita efeitos únicos explícitos, ou vai para `HOLD_SEGMENTACAO` se várias funções estiverem misturadas. A meta é reduzir falsas somas, não esconder omissões.
7. **Passivas rotuladas mas que exigem reação/ação voluntária** e habilidades ativas declaradas como permanentes recebem conflito, sem escolha automática de modalidade.
8. **Taxas de atributos fracionários sem regra.** `+2,5 FOR` é HOLD; o R24 poderia truncar silenciosamente. Repetição de eixo+mesma magnitude também exige exame.
9. **Comparadores de habilidades não ofensivas.** Novo contrato opcional `evidencias`: exige gatilho, alvo, duração, resultado, limites e pelo menos 2 comparadores mecânicos distintos, com fonte e análise, para formar uma PRÉVIA E3. URLs não são automaticamente autenticados pelo script. Nenhum E3 vira E0/P4 por esse gate.
10. **Itens antigos e custo explícito.** `origem=HISTORICO` preserva despesas originais documentadas como contexto e recusa recálculo/commit automático com tarifas novas.

## Demonstração funcional

| Caso | Entrada | Saída |
|---|---|---|
| R25-01 | "Crie um cajado que dispara 8d10 de dano num único alvo com uma ação padrão" (nenhum rank informado) | RE/RI Ouro **E3 proposto**, piso Ouro 21 PA/dia, 14 PA/uso; sem usos selecionados = 21 PA no dia **condicional** |
| R25-02 | Mesmo efeito, duas ativações | 21 PA/dia + 28 PA em ativações = **49 PA no cenário** |
| R25-03 | Manoplas Prata, +2 FOR e +3 ataque como passiva *somente numérica* | **13 PA/dia**, sem sobretaxa de habilidade |
| R25-08 | Botas Ouro, +2 DES/+3m, passiva Prata, ativa Bronze usada 2× | **28 PA/dia + 6 PA de ativações = 34 PA** cenário condicional, ranks fornecidos no exemplo |
| R25-09 | Passiva de rastros com duas comparações textuais indicadas e mecânica especificada | Tarifa Prata **E3 apoiada em fontes FORNECIDAS, ainda não autenticadas automaticamente**; item Ouro fica no piso 21 PA/dia |
| R25-06 | Explosão circular 8d10 | HOLD classificação por área (não usar banda ofensiva padrão do DMG) |
| R25-07 | Armadura de Zephyr histórica | 90 PA/dia histórico intacto; 115 PA/dia de parcelas numéricas identificadas NÃO reprecifica o legado |
| R25-10 | Anel invisibilidade + teleporte + regeneração em parágrafo único | HOLD_SEGMENTACAO, sem valor inventado |

## Regras Mestre reproduzidas

| RE | Passiva PA/dia | Ativa PA/dia | Ativa por uso | Piso RI PA/dia |
|---|---:|---:|---:|---:|
| Bronze | 6 | 3 | 3 | 8 |
| Prata | 12 | 6 | 7 | 11 |
| Ouro | 24 | 12 | 14 | 21 |
| Ouro Negro | 35 | 17 | 21 | 35 |
| Lendário | 50 | 25 | 30 | 90 |

O alcance Mestre R23 permanece subsidiário às condições escritas: alvo único ofensivo 9m, cone ofensivo 4,5m desde conjurador, círculo raio 6m com centro até 9m, com origem de cada parâmetro rastreada. **Alcance não autoriza multiplicar PA**.

## Evidência canônica e limites de implantação

Reabridas em leitura 19/10/2026 as quatro fontes Mestres atuais: [PR-ECO-01 Atlas](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab), [DMG-RANK v1.1](https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e), [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373) e [OP CRAFT](https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516). Os dados normativos sobre alcance e tarifas ainda não foram fisicamente gravados pelo executor. A OP CRAFT consultada registra `F5=RED`, fencing sem demonstração e `C19-021 UNKNOWN` no checkpoint de 09/10/2026. Não alegar que aquele checkpoint necessariamente resolve estados posteriores.

## Portões restantes para o P0 GLOBAL

1. **Corpus de referência real:** recuperar/descrever corretamente técnicas cujos efeitos ficam só em imagem, reconciliar habilidades comparáveis em cada eixo, obter gabarito independente de RE e medir precisão/cobertura contra E0 (não concordância E3 consigo mesmo). Esta etapa ainda não foi feita de forma exaustiva.
2. **Habilidades qualitativas:** cobertura automática de invisibilidade, controle, imunidade, teleporte, suporte e efeitos mistos depende de potencia, duração, resistências, economia de ações, alcance, limites e fontes; não há lei universal numérica para isso, então falso fecho é proibido.
3. **Integração nativa:** R25 fornece API Python importável e protocolo para o ChatGPT, mas não é um plugin/serviço instalado no CRAFT ou hook persistente do Notion. CRAFT exige contrato e execução com acesso técnico legitimamente autorizado.
4. **Registro oficial das decisões Mestre:** usar normas e páginas competentes existentes, NAC-CONT-03/NAC-NORM-01/NAC-PASS; escritor/exclusividade/lease/fencing não provados neste trabalho. `Party` e `O Primeiro` preservados sem escrita.

## Estado e ponto exato de retomada

**R24 → R25 local:** 71/71 testes novos e 92/92 regressões, 12 fichas; pacote imutável com manifesto/hash e clean replay. `NAC-PASS TEST` = PASS PROPORCIONAL após extração; `NAC-PASS PRODUÇÃO/NOTION` = HOLD. `P0 GLOBAL` não encerrado.

**NEXT:** partir de `motor_qualificado_r25.py` + `CORPUS_99_R25.csv` e atacar primeiro as fichas E0 de técnicas/mechanics em imagem e casos de defesa/controle sem 2 comparadores. Depois provar um lote cego com gabarito físico e conectar ao fluxo CRAFT sob governança. Nunca refazer motores R01–R24, criar laboratório concorrente, nem recalcular PA histórico automaticamente.
