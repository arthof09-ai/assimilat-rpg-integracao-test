# CRAFT / PA R25 — Matriz de integração CANÔNICA PENDENTE, sem escrita

**Este documento NÃO foi registrado no Notion; é um handoff técnico para aplicação autorizada à estrutura preexistente. Não criar novas normas, laboratórios nem duplicatas.**

## Fontes já existentes reabertas em leitura 19/10/2026

- PR-ECO-01 — Anexo A — Atlas Canônico de Poder por Rank: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- DMG-RANK-01 v1.1 (oficial e vigente): https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- Sistema de Magia: https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373
- OP-ARQ-RIN-REC-01 / CRAFT: https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516

**PRE-STATE da OP CRAFT observada:** F5 P0/RED, writer/fencing de C19 sem comprovação, `C19-021 UNKNOWN`, RC5 0/30 naquele checkpoint. Não inferir estado presente de produção por ausência de atualização; não escrever no target material sem gate.

## Decisões expressas do Mestre disponíveis no chat, ainda sem readback normativo

1. Para cada NOVO item: piso de manutenção por RI Bronze 8, Prata 11, Ouro 21, Ouro Negro 35, Lendário 90 PA/dia. Histórico NÃO recalculado por isso.
2. Para habilidades de NOVOS itens: tarifa passiva RE 6/12/24/35/50; tarifa ativa diária floor(metade) 3/6/12/17/25; tarifa de ativação floor(0.6*original) 3/7/14/21/30 por uso.
3. RI do item é independente do RE das habilidades, e itens podem ter somente atributos/bônus sem uma habilidade funcional.
4. Alcance subsidiário quando falta parâmetro específico: alvo único ofensivo 9m; cone ofensivo 4,5m a partir do conjurador; área circular raio 6m com centro escolhido até 9m. Fonte explícita prevalece campo a campo, inclusive origem fixada no conjurador. Sem inventar geometria para 'inimigos próximos'.
5. CA física NÃO automaticamente recebe a tarifa de CA mágica. Dano por turno deve permanecer distinto de dano adicional por golpe. A recomendação de impedir cobrança dupla de passivas com nome decorativo é **PROPOSTA INTERPRETATIVA R25** para validação, não nova regra oficial por ato deste executor.

## Write-set proposto depois de governança válida

- Sistema de Magia: registrar diretriz de alcance em sua seção de normas existente, com precedência e proveniência por campo, sem redefinir ação, custo PA ou CDs.
- Fonte competente do Sistema de Consumo de PA existente: aplicar as decisões explícitas de tarifas/pisos no corpo da autoridade existente, sem criar autoridade paralela. Preservar seu histórico.
- CRAFT: adicionar somente bridge/ref à fonte PA, metodologia Atlas e API experimental; integração do runtime depende de contrato, validação, writer e readback. Não alterar receitas, RC5, estoque, economia nem fichas por arrasto.
- VLAB: divulgar contrato de geometria/alcance como **entrada espacial**, sem entregar regras PA para produzir ataques fora do escopo.
- Party/O Primeiro: 0 escrita ou vazamento Mestre-only.

## Checklist real de fechamento

`LER fonte atual e governança → ANTES/fingerprint → anti-duplicata → conferir autoridade, writer/lease/fence → reservar write-set → aplicar patch mínimo → REOPEN/VERIFY → DEPOIS/PSV → NAC-NORM-01 e NAC-PASS-02`.

Sem essa sequência, **R25 TEST PASS não é NORM/PRODUÇÃO PASS**. É necessário medir também acurácia contra gabarito E0 com mecânica recuperada, não somente consenso de faixas E3. R22 preserva 26 rótulos E0 nominais de técnicas, mas muitas mecânicas estão exclusivamente em imagem; completar esse corpus é trabalho material ainda pendente.
