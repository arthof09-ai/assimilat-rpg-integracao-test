# PA R25 — Aperfeiçoamento incremental do consultor (MESTRE-SIDE / TEST)

Preserva os motores e ZIPs R22–R24 originais sem modificar, integra uma camada não destrutiva de qualificação de rank, cobrança e evidência, e impede que simulações incompletas pareçam custos definitivos.

## Principal entrada

```bash
PYTHONPATH=.:baseline_r22 python motor_qualificado_r25.py descricao.txt
```

Ou `from motor_qualificado_r25 import avaliar, ficha`.

## Diretório

- `motor_qualificado_r25.py`: camada conservadora de evidência, cobrança e ficha; importa `motor_conversacional_r24.py` intacto.
- `test_r25_qualidade.py`: 71 casos de teste fixos e metamórficos, com centenas de variantes internas.
- `REGRESSAO_R22_R24_R25.log`: 92 testes anteriores PASS; motores antigos NÃO foram alterados.
- `GERAR_DEMONSTRACOES_R25.py`: 12 fichas TEST com casos defensivos, ofensivos, legado, alcance, area, rank conflitante e tarifa diária.
- `avaliar_corpus_r25.py`, `CORPUS_99_R25.csv`: auditoria do antigo corpus textual resumido, sem confundir E3 com verdade; as 99 observações permaneceram bloqueadas para tarifa sem evidência suficiente.
- `PROTOCOLO_CONVERSACIONAL_R25.md`: protocolo de análise em conversa.
- `INTEGRACAO_CANONICA_PENDENTE_R25.md`: handoff e write-set condicionado aos gates do Notion.
- `BASELINE_R24_IMUTAVEL.zip`: pacote R24 original, autenticado por SHA/CRC.
- `MANIFEST_R25.json`: hashes e tamanhos de cada arquivo do pacote.

## Convenções

`PREVIA_CONDICIONAL`: cálculo de cenário TEST, com RE/RI E3 ou design declarado, sujeito a aprovação e validação independente.

`HOLD`: falta classificação ou condições suficientes; PA/dia e PA/uso totais não são inventados.

`HOLD_SEGMENTACAO`: texto livre mistura vários efeitos; separar a mecânica antes de cobrar tarifa por habilidade.

`HISTORICO`: consulta somente para diagnóstico; valor PA explícito antigo preservado, não recalculado nem escrito.

**REGRAS DO MESTRE preservadas**: base passiva 6/12/24/35/50; ativa-dia 3/6/12/17/25; ativa-uso 3/7/14/21/30; pisos 8/11/21/35/90; alcance Mestre R23 com precedência da ficha. 

## Limites importantes

- Nenhum classificador puramente textual pode adivinhar parâmetros mecânicos ausentes. A classificação universal de toda habilidade permanece NÃO COMPROVADA.
- No índice histórico R22, rótulos E3 são hipóteses. Um comparador URL sem leitura independente não prova potência.
- A camada R25 não é instalação nativa dentro do CRAFT, não altera canône e não adquiriu writer, lease ou epoch no Notion.
