# Armadura de Exemplo — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Ouro (RN_ITEM_DECLARADO_PARA_DESIGN)
**Bônus diretos:** {"FOR": 0, "DES": 15, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 25, "deslocamento_m": 0, "ca_magica": 0}; tarifa identificada 100 PA/dia.

## Habilidades propostas
Nenhuma habilidade funcional identificada.

## Consumo energético prospectivo
- Piso item: 21 PA/dia.
- Parcela diária identificada: 100 PA/dia.
- **Prévia diária condicional:** 100 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 100 PA.
- Estado: SIMULACAO_CONDICIONAL; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: CA_AMBIGUA_OU_FISICA_NAO_TARIFAR: +11 ca de armadura fisica.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
