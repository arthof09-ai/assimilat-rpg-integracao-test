# Fluxo operacional conversacional R25 — TEST / MESTRE-SIDE

**Objetivo:** o Mestre descreve um item em português comum; o Comestre separa a mecânica de cada habilidade, encontra comparadores e produz uma prévia de PA sem exigir rank fornecido. Quando evidência não sustenta uma classificação, a resposta é PENDÊNCIA EXATA, não preço inventado.

## Ordem de execução

1. Ler descrição completa. Preservar texto original, intenções e eventuais referências do Notion. Uma frase pode reunir vários poderes; não reduzir tudo a uma habilidade universal. Extrair separadamente **bônus numéricos permanentes**, **passivas funcionais**, **ativas escolhidas**, **gatilhos automáticos**, **múltiplos modos** e **efeitos indefinidos**.
2. Recuperar o **PR-ECO-01 Atlas** vigente por Notion e a família mecânica no Sistema de Magia/Combate/DMG. Distinguir E0 documento, E1 convergência, E2 benchmark e E3 hipótese. Não usar PA, preço MED ou classificação do portador para atribuir RE.
3. Para cada habilidade, registrar gatilho, ação, alvo, geometria, alcance, CD/teste/salvaguarda, duração, magnitude, recarga, condições, efeitos secundários, natureza e limitações. Usar somente os padrões de alcance determinados pelo Mestre em 19/10/2026 quando aplicáveis, conservando fonte explícita versus fallback.
4. No eixo ofensivo, usar **DMG-RANK v1.1** por banda direta **apenas** quando for dano intrínseco simples, Ação Padrão, alvo único, sem riders/área/bypass/dano recorrente/atributo externo. Todo caso misto deve consultar Atlas completo; nunca atribuir automaticamente o mesmo RE só por DME.
5. Buscar idealmente os três comparadores do Atlas: **sistêmico**, **vivo** e **mesma família**. Pelo menos dois distintos com análise mecânica para uma prévia E3 apoiada; URLs sozinhas não autenticam fonte. Reabrir fontes relevantes fisicamente quando for decisão material. Habilidade sem RE fundamentado => `HOLD`, ainda que o item possua rank publicado.
6. Rank da habilidade (`RE`) **não é** rank do item (`RI`). O item pode ter só bônus estatísticos e pode conter habilidades inferiores à própria classe. RE superior ao RI proposto é conflito de design, requer revisão.
7. Aplicar as decisões do Mestre para NOVOS ITENS: passiva base **6/12/24/35/50 PA/dia**; ativa dia `floor(base/2)` **3/6/12/17/25**; ativação `floor(0.6*base)` **3/7/14/21/30 PA por uso**. Piso item **8/11/21/35/90 PA/dia** por RI. Soma diária = `max(piso_RI, taxas_bonuses_validas + taxas_habilidades)`, com PA de usos adicional.
8. **Anti-dupla cobrança:** passiva que apenas renomeia o mesmo +ATR ou +ataque já cobrado numericamente NÃO gera tarifa extra de habilidade; uma habilidade funcional nova e independente exige registro específico. CA de armadura física não é automaticamente CA mágica; +dano *por turno* não equivale a +dano fixo *por golpe*; taxa de reflexos/RD sem decisão específica fica pendente.
9. Se alguma parcela da ficha não puder ser classificada, mostre **subtotal conhecido separado**, propostas de RE/E3 e custos por rank apenas hipotéticos. **NÃO** publique soma total como definitiva ou como 'limite inferior' quando RI/RE são E3. Para legado, somente registrar o custo histórico; nenhuma reprecificação automática.
10. Emitir ficha Mestre PREVIEW com evidências, condições, custo diário, PA/uso, cenários, pendências e aprovação necessária. Jamais afirmar P4 ou atualizar Notion/Party sem autorização competente, NAC-CONT-03, NAC-NORM-01 e NAC-PASS; writer/lease não se herdam.

## Como responder diante de texto livre incompleto

Dar análise parcial de boa qualidade e **uma pendência específica de maior impacto**: por exemplo, `Gravidade Abissal`: geometria, duração, salvaguarda, alcance e limites desconhecidos; RE e custo integral permanecem pendentes. Não exigir que o Mestre forneça rank — a responsabilidade de pesquisar é do Comestre.

## Interface reusável

```python
from motor_qualificado_r25 import avaliar, ficha
parecer = avaliar("Crie um cajado que dispara 8d10 de dano num único alvo com uma ação padrão.")
print(ficha(parecer))
```

O `avaliar()` recebe também `usos={nome:quantidade}`, `origem='HISTORICO'` e `evidencias={nome:{rank_candidato, mecanica, comparadores}}`. Argumentos adicionais continuam E3/documento de pesquisa; não transformam links em fonte fisicamente verificada.
