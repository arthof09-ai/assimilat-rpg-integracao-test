"""R25 source-scoped, adversarial and metamorphic gates.  TEST ONLY."""
import unittest, random, json, csv, sys, re
from pathlib import Path
from motor_qualificado_r25 import avaliar, ficha, _parse_free_text, _find_pa_explicit
from baseline_r22.rank_guard_r22 import BASE,FLOOR,tariff,RANKS

FOCUS='Item: Varinha\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano em um único alvo.'
BASE_BLIND='Item: Cetro\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano em um único alvo.'
BYPASS='Item: Anel\nHabilidade ativa: Salvaguarda Absoluta: Ao falhar numa salvaguarda pode usar uma reação para obter sucesso uma vez por dia.'
PASS='Item: Botas\nRank do item: Ouro\nHabilidade passiva: Passos sem Pegadas: Enquanto equipadas não deixam rastros em terreno natural, mas não ocultam som.'

GOOD={'Passos sem Pegadas':{'rank_candidato':'Prata',
    'mecanica':{'gatilho':'equipado','alvo':'portador','duracao':'enquanto equipado','resultado':'não deixa rastros em terreno natural','limites':'não apaga sons'},
    'comparadores':[
        {'tipo':'sistemico','fonte':'https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab','comparacao':'Atlas Prata mobilidade ou rastreio especializado, duracao' },
        {'tipo':'familia','fonte':'https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c','comparacao':'Bota com passiva de deixar de produzir pegadas, alvo portador'}
    ]}}


def analysis(s,**kw):return avaliar(s,**kw)

class FixedCases(unittest.TestCase):
    def test_001_legacy_tariffs(self):
        for r,p,a,u in [('Bronze',6,3,3),('Prata',12,6,7),('Ouro',24,12,14),('Ouro Negro',35,17,21),('Lendário',50,25,30)]:
            self.assertEqual(tuple(tariff(r).values()),(p,a,u))
    def test_002_floor_all(self):self.assertEqual(tuple(FLOOR.values()),(8,11,21,35,90))
    def test_003_simple_free_prose(self):
        x=analysis('Crie um cajado que dispara 8d10 de dano num único alvo com uma ação padrão.')
        self.assertEqual(x['status'],'PREVIA_CONDICIONAL');self.assertEqual(x['item_rank_candidate'],'Ouro')
        self.assertEqual(x['pa']['daily_scenario_pa'],21)
    def test_004_simple_with_two_uses(self):
        x=analysis(FOCUS,usos={'Feixe':2});self.assertEqual(x['pa']['total_scenario_pa'],49)
    def test_005_no_pretend_E0(self):
        x=analysis(FOCUS);self.assertFalse(x['official_classification']);self.assertIsNone(x['pa']['confirmed_daily_pa'])
    def test_006_tariff_rank_independent_item(self):
        x=analysis('Item: Espada\nRank do item: Lendário\nHabilidade ativa Bronze: Golpe: Com uma ação padrão, causa 3d6 de dano em um único alvo.')
        self.assertEqual(x['abilities'][0]['custo_pa_uso_validado'],3);self.assertEqual(x['pa']['item_floor_pa'],90)
    def test_007_no_skill_stats(self):
        x=analysis('Item: Manopla\nRank do item: Prata\nBônus: +2 FOR; +3 ataque; +1 CA mágica')
        self.assertEqual(x['pa']['daily_scenario_pa'],14)
    def test_008_no_double_decorative_stat(self):
        x=analysis('Item: Anel\nRank do item: Bronze\nHabilidade passiva: Força Livre: +3 FOR')
        self.assertEqual(x['pa']['daily_scenario_pa'],15)
    def test_009_multi_numeric_passive_only(self):
        x=analysis('Item: Luvas\nRank do item: Bronze\nHabilidade passiva: Força do Boi: +2 FOR; +3 de ataque')
        self.assertEqual(x['pa']['daily_scenario_pa'],13);self.assertFalse(x['abilities']);self.assertEqual(len(x['numeric_only_passives_preserved']),1)
    def test_010_duplicate_stat(self):
        x=analysis('Item: Luvas\nRank do item: Bronze\nBônus: +2 FOR; +3 de ataque\nHabilidade passiva: Força do Boi: +2 FOR; +3 de ataque')
        self.assertEqual(x['status'],'HOLD');self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_011_area_not_simple_band(self):
        x=analysis('Item: Cajado\nHabilidade ativa: Nova: Com uma ação padrão, causa 8d10 de dano em uma área circular de raio 6 metros.')
        self.assertEqual(x['status'],'HOLD');self.assertTrue(any('AREA' in q for q in x['issues']))
    def test_012_cone_not_simple_band(self):
        x=analysis('Item: Vara\nHabilidade ativa: Cone: Com uma ação padrão, causa 8d10 de dano em cone de 4,5m.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_013_line_not_simple_band(self):
        x=analysis('Item: Vara\nHabilidade ativa: Linha: Com uma ação padrão, causa 8d10 de dano em linha de 12m.')
        self.assertEqual(x['status'],'HOLD')
    def test_014_multiple_targets_not_single(self):
        x=analysis('Item: Arco\nHabilidade ativa: Chuva: Com uma ação padrão, causa 8d10 de dano contra múltiplos alvos.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_015_control_rider(self):
        x=analysis('Item: Arco\nHabilidade ativa: Chuva: Com uma ação padrão, causa 8d10 de dano a um alvo e paralisa ele por 2 turnos.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_016_multihit(self):
        x=analysis('Item: Cajado\nHabilidade ativa: Flechas: Com uma ação padrão, causa 8d10 de dano em um alvo com múltiplos projéteis.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_017_dot(self):
        x=analysis('Item: Anel\nHabilidade ativa: Veneno: Com uma ação padrão, causa 8d10 de dano por turno a um alvo.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_018_once_per_turn_is_not_dot(self):
        x=analysis('Item: Cajado\nHabilidade ativa: Chama: Com uma ação padrão, causa 8d10 de dano em um único alvo. Uma vez por turno.')
        self.assertEqual(x['status'],'PREVIA_CONDICIONAL')
    def test_019_conditional_damage(self):
        x=analysis('Item: Machado\nHabilidade ativa: Extra: Com uma ação padrão, causa 8d10 de dano extra contra sombras em um alvo.')
        self.assertEqual(x['status'],'HOLD')
    def test_020_critical(self):
        x=analysis('Item: Machado\nHabilidade ativa: Extra: Com uma ação padrão, causa 8d10 de dano num alvo quando for crítico.')
        self.assertEqual(x['status'],'HOLD')
    def test_021_external_attribute(self):
        x=analysis('Item: Machado\nHabilidade ativa: Extra: Com uma ação padrão, causa 8d10+FOR de dano num alvo.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_022_no_action_confirmation(self):
        x=analysis('Item: Machado\nHabilidade ativa: Extra: Causa 8d10 de dano num alvo.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_023_no_target_confirmation(self):
        x=analysis('Item: Machado\nHabilidade ativa: Extra: Com uma ação padrão, causa 8d10 de dano.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_024_declared_rank_power_conflict(self):
        x=analysis('Item: Espada\nRank do item: Ouro\nHabilidade ativa Ouro: Ruína: Com uma ação padrão causa 100d100 de dano em um único alvo.')
        self.assertIsNone(x['pa']['daily_scenario_pa']);self.assertTrue(any('DISSONANTE' in s for s in x['issues']))
    def test_025_declared_rank_not_e0(self):
        x=analysis('Item: Espada\nRank do item: Ouro\nHabilidade ativa Ouro: Golpe: Com uma ação padrão causa 8d10 de dano em um único alvo.')
        self.assertIn('SEM_E0',x['abilities'][0]['qualidade_rank']['certification'])
    def test_026_e3_no_production(self):
        x=analysis(FOCUS);self.assertFalse(x['canonical_write']);self.assertFalse(x['party_write'])
    def test_027_legacy_preservation(self):
        text='Item: Bota Caminho Veloz\nRank do item: Ouro\nHabilidade ativa: Passo: Ao ativar ganha velocidade +8 metros, 5 PA por ativação histórica.\n18 PA por dia.'
        x=analysis(text,origem='HISTORICO');self.assertEqual(x['status'],'HOLD');self.assertIsNone(x['pa']['total_scenario_pa']);self.assertEqual(x['explicit_pa_historic_or_claimed']['pa_dia_textual'],18)
    def test_028_legacy_5_pa(self):
        x=analysis('Item: Bota\nHabilidade ativa: A: Ao ativar ganha +8m de deslocamento, 5 PA por ativação.',origem='HISTORICO')
        self.assertEqual(x['explicit_pa_historic_or_claimed']['pa_por_uso_textual'],5)
    def test_029_name_rank_false(self):
        x=analysis('Item: Espada do Lendário\nHabilidade ativa: Mistério: Uma força misteriosa provoca fenômenos.')
        self.assertIsNone(x['item_rank_candidate'])
    def test_030_rank_not_pa(self):
        a=analysis(FOCUS);b=analysis(FOCUS.replace('em um único alvo.','em um único alvo. 9999 PA por ativação.'))
        self.assertEqual(a['item_rank_candidate'],b['item_rank_candidate'])
    def test_031_passive_reaction_contradiction(self):
        x=analysis('Item: Anel\nRank do item: Prata\nHabilidade passiva Prata: Negação: Pode usar sua reação para bloquear um golpe.')
        self.assertEqual(x['status'],'HOLD')
    def test_032_active_permanent_contradiction(self):
        x=analysis('Item: Anel\nRank do item: Prata\nHabilidade ativa Prata: Escudo: Automaticamente sem ação permanece sempre ativo.')
        self.assertEqual(x['status'],'HOLD')
    def test_033_bypass_requires_benchmarks(self):
        x=analysis(BYPASS);self.assertEqual(x['status'],'HOLD')
    def test_034_guard_pa_loop(self):
        x=analysis('Item: Anel\nHabilidade passiva: Absorção: Sempre que recebe dano recupera 5 PA.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_035_physical_ca_not_charged(self):
        x=analysis('Item: Armadura\nRank do item: Ouro\nBônus: +11 CA armadura física; +15 DES; +25 ataque')
        self.assertEqual(x['pa']['daily_scenario_pa'],100)
        self.assertEqual(x['numeric_components']['ca_magica'],0)
    def test_036_missing_tariff_axis(self):
        x=analysis('Item: Manto\nRank do item: Prata\nBônus: +5 Reflexo; +4 ataque')
        self.assertEqual(x['status'],'HOLD')
    def test_037_free_multiple_effects(self):
        x=analysis('Quero um anel que deixa invisível e também teletransporta inimigos.')
        self.assertEqual(x['status'],'HOLD_SEGMENTACAO')
    def test_038_free_stat_only_no_item_rank(self):
        x=analysis('Um anel que dá +2 de força.')
        self.assertNotEqual(x['status'],'PREVIA_CONDICIONAL')
    def test_039_invalid_use_neg(self):
        with self.assertRaises(ValueError):analysis(FOCUS,usos={'Feixe':-1})
    def test_040_invalid_use_bool(self):
        with self.assertRaises(ValueError):analysis(FOCUS,usos={'Feixe':True})
    def test_041_invalid_use_float(self):
        with self.assertRaises(ValueError):analysis(FOCUS,usos={'Feixe':1.2})
    def test_042_unexpected_origin(self):
        with self.assertRaises(ValueError):analysis(FOCUS,origem='PARTY_WRITER')
    def test_043_empty(self):
        with self.assertRaises(ValueError):analysis('')
    def test_044_outputs_ficha(self):
        out=ficha(analysis(FOCUS));self.assertIn('PREVIEW MESTRE',out);self.assertIn('PRODUÇÃO',out.upper())
    def test_045_item_rank_lower_than_effect(self):
        x=analysis('Item: Espada\nRank do item: Bronze\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano em um único alvo.')
        self.assertEqual(x['status'],'HOLD');self.assertTrue(any('INFERIOR' in s for s in x['issues']))
    def test_046_user_provided_two_sources_can_quote_e3(self):
        x=analysis(PASS,evidencias=GOOD);self.assertEqual(x['status'],'PREVIA_CONDICIONAL');self.assertEqual(x['pa']['daily_scenario_pa'],21)
    def test_047_sources_not_e0(self):
        x=analysis(PASS,evidencias=GOOD);self.assertIsNone(x['pa']['confirmed_daily_pa']);self.assertFalse(x['official_classification'])
    def test_048_one_source_insufficient(self):
        ed=json.loads(json.dumps(GOOD));ed['Passos sem Pegadas']['comparadores'].pop()
        x=analysis(PASS,evidencias=ed);self.assertEqual(x['status'],'HOLD')
    def test_049_same_source_not_two(self):
        ed=json.loads(json.dumps(GOOD));ed['Passos sem Pegadas']['comparadores'][1]['fonte']=ed['Passos sem Pegadas']['comparadores'][0]['fonte']
        x=analysis(PASS,evidencias=ed);self.assertEqual(x['status'],'HOLD')
    def test_050_missing_fields(self):
        ed=json.loads(json.dumps(GOOD));ed['Passos sem Pegadas']['mecanica'].pop('limites')
        x=analysis(PASS,evidencias=ed);self.assertEqual(x['status'],'HOLD')
    def test_051_rank_disagrees_old_proposal(self):
        ed=json.loads(json.dumps(GOOD));ed['Passos sem Pegadas']['rank_candidato']='Lendário'
        x=analysis(PASS,evidencias=ed);self.assertEqual(x['status'],'HOLD')
    def test_052_sources_cannot_fix_mechanic_conflict(self):
        ed=json.loads(json.dumps(GOOD));ed['Feixe']=ed.pop('Passos sem Pegadas')
        ed['Feixe']['rank_candidato']='Ouro'
        x=analysis('Item: Cajado\nHabilidade ativa: Feixe: Com uma ação padrão causa 8d10 de dano em cone de 4,5m.',evidencias=ed)
        self.assertEqual(x['status'],'HOLD')
    def test_053_no_partial_as_lower_bound(self):
        x=analysis(BYPASS);self.assertEqual(x['pa']['bounds'],'NAO_CALCULAVEL')
    def test_054_numerical_pa_dont_modify_rank(self):
        a=analysis(FOCUS);b=analysis(FOCUS.replace('em um único alvo.','em um único alvo. 1200 PA por ativação.'))
        self.assertEqual(a['item_rank_candidate'],b['item_rank_candidate'])
    def test_055_uses_consumption_linear(self):
        for n in (0,1,2,3,6,12):
            x=analysis(FOCUS,usos={'Feixe':n});self.assertEqual(x['pa']['total_scenario_pa'],21+14*n)
    def test_056_passive_no_uses(self):
        with self.assertRaises(Exception):analysis('Item: Botas\nRank do item: Prata\nHabilidade passiva: A: Enquanto equipa não deixa rastros',usos={'A':1})
    def test_057_unpriced_effect_not_zero(self):
        x=analysis('Item: Cetro\nRank do item: Ouro\nHabilidade ativa: Tempestade: Controle total dos ventos.')
        self.assertIsNone(x['pa']['total_scenario_pa'])
    def test_058_rank_alternatives_present(self):
        x=analysis(FOCUS);self.assertTrue(x['abilities'][0]['tabela_tarifa_candidatos'])
    def test_059_warnings_stable(self):
        x=analysis(FOCUS);self.assertFalse(any('E0' in a['qualidade_rank']['confidence'] for a in x['abilities']))
    def test_060_no_truncating_hard_hold(self):
        x=analysis('Um item mágico que dá invisibilidade e voo e também teleporte e cura total.')
        self.assertEqual(x['status'],'HOLD_SEGMENTACAO')


    def test_065_truly_ambiguous_ca(self):
        x=analysis('Item: Armadura\nRank do item: Ouro\nBônus: +11 CA; +15 DES')
        self.assertEqual(x['status'],'HOLD')
        self.assertIsNone(x['pa']['daily_scenario_pa'])
    def test_066_zephyr_damage_per_turn_excluded(self):
        s='Item: Armadura Zephyr\nRank do item: Lendário\nBônus: +15 DES; +25 em testes de ataque; +15m de deslocamento; +11 CA de armadura física; +50 de dano de Vento por turno\n90 PA por dia'
        x=analysis(s,origem='HISTORICO')
        self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],115)
        self.assertEqual(x['numeric_components']['dano'],0)
        self.assertEqual(x['explicit_pa_historic_or_claimed']['pa_dia_textual'],90)
        self.assertIsNone(x['pa']['daily_scenario_pa'])
    def test_067_damage_per_turn_new_item_not_just_flat_damage(self):
        x=analysis('Item: Armadura\nRank do item: Ouro\nBônus: +50 de dano de Vento por turno')
        self.assertEqual(x['status'],'HOLD')
        self.assertIsNone(x['pa']['daily_scenario_pa'])
        self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],0)


    def test_068_duplicate_stat_by_different_text(self):
        a='Item: Anel\nRank do item: Ouro\nBônus: +2 FOR\nHabilidade passiva: Vigor: +2 FOR; +3 ataque'
        x=analysis(a)
        self.assertEqual(x['status'],'HOLD')
        self.assertTrue(any('BONUS_IDENTICO_REPETIDO' in z for z in x['issues']))
    def test_069_fractional_stat_is_not_silently_truncated(self):
        x=analysis('Item: Anel\nRank do item: Bronze\nBônus: +2,5 FOR')
        self.assertEqual(x['status'],'HOLD')
        self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],0)
    def test_070_magical_armor_chassis_ca_not_auto_billed(self):
        x=analysis('Item: Armadura\nRank do item: Prata\nBônus: +11 CA de armadura mágica')
        self.assertEqual(x['status'],'HOLD')
        self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],0)
    def test_071_magical_ca_bonus_explicit_is_billed(self):
        x=analysis('Item: Capa\nRank do item: Bronze\nBônus: +2 CA mágica')
        self.assertEqual(x['pa']['daily_scenario_pa'],8)
        self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],2)

class Metamorphic(unittest.TestCase):
    def test_061_pa_cost_does_not_set_rank_100(self):
        original=analysis(FOCUS)
        for n in range(1,101):
            suff=f' Custa {n*7} PA por ativação e preço {n*999} MED.'
            alt=analysis(FOCUS.replace('em um único alvo.','em um único alvo.'+suff))
            self.assertEqual(original['item_rank_candidate'],alt['item_rank_candidate'])
    def test_062_no_writes_variants_50(self):
        for i in range(50):
            s=f'Item: Teste {i}\nHabilidade ativa: Fogo: Com uma ação padrão, causa {1+i%9}d6 de dano em um único alvo.'
            a=analysis(s)
            self.assertFalse(a['canonical_write']);self.assertFalse(a['party_write'])
    def test_063_legacy_not_priced_50(self):
        for i in range(50):
            s=f'Item: Antigo {i}\nRank do item: Ouro\nBônus: +{i+1} FOR\n{i+3} PA por dia'
            a=analysis(s,origem='HISTORICO');self.assertIsNone(a['pa']['total_scenario_pa'])
    def test_064_overlaps_never_e0_100(self):
        for n in range(1,101):
            s=f'Item: Cetro\nHabilidade ativa: Poder: Com uma ação padrão, causa {n}d6 de dano em um único alvo.'
            a=analysis(s)
            self.assertFalse(a['official_classification']);self.assertIsNone(a['pa']['confirmed_daily_pa'])

if __name__=='__main__':unittest.main(verbosity=2)
