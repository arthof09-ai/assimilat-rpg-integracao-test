# Armadura — PREVIEW MESTRE R25 / TEST
**Estado:** HOLD · **Produção:** HOLD
**Rank do item:** Bronze (DECLARADO_PELO_USUARIO_NAO_COMPROVA_RANK_CANONICO)

## Habilidades e tarifas por componente
- **Lança Catastrófica** — ATIVA; RE candidato **Bronze**; estado **HOLD_COM_CONFLITO**; PA/dia **PENDENTE**; PA/ativação **PENDENTE**.
  - Texto recebido: Com uma ação padrão, causa 100d100 de dano em um único alvo.
  - Pendências específicas: RANK_DECLARADO_DISSONANTE_BANDA_DMGRANK
  - Geometria: ALVO_UNICO; alcance=9.0 (ALCANCE_REGRA_GERAL_MESTRE); raio=None (ALCANCE_PENDENTE); extensao=None (ALCANCE_PENDENTE); origem=None (ALCANCE_PENDENTE)
  - Tarifas sob RANKS HIPOTÉTICOS (não usar como preço fechado): {"Bronze": {"PA_dia": 3, "PA_uso": 3}}

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: 0 PA/dia
- Subtotal parcial conhecido (não representa custo final): 0 PA/dia
- Piso do RI candidato: 8 PA/dia
- **Diário simulado:** PENDENTE PA/dia
- **Usos simulados:** PENDENTE PA
- **Total no cenário:** PENDENTE PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: HOLD_CUSTO_TOTAL_INDETERMINADO.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": null, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- Lança Catastrófica: RANK_DECLARADO_DISSONANTE_BANDA_DMGRANK

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
