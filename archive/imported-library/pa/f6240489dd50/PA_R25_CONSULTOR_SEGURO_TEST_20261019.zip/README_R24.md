# R24 · Motor Conversacional de Consumo de PA · Ambiente TEST/MESTRE-SIDE

## Entrega funcional

O motor aceita descrição de item em português, separa bônus numéricos e habilidades, propõe Rank de Efeito (RE) a partir de critérios já canônicos do Atlas/DMG, distingue modalidade passiva/ativa, normaliza geometrias pela diretriz de alcance do Mestre, cobra as tarifas estabelecidas, aplica o piso do Rank do Item (RI) e devolve ficha em Markdown e JSON com evidência e ressalvas. **Não** cria fichas canônicas, não autentica rank E3 automaticamente, não publica Notion e não altera históricos.

- `motor_conversacional_r24.py`: função `analyze_item(text, uses={...})`, `as_ficha(resultado)` e CLI por stdin/arquivo. Não precisa conexão de rede.
- `test_motor_conversacional_r24.py` + `test_integracao_r24.py`: 52 casos unitários e de integração.
- `alcance_mestre_r23.py`, `ponte_pa_r23.py`, `baseline_r22/rank_guard_r22.py`: cópias **byte-idênticas** das implementações originais, com regressão separada 40 testes.
- `FIXTURES_R24.json` e `DEMONSTRACOES_CONVERSACIONAIS_R24.json`: 12 descrições de ponta a ponta e resultados correspondentes.
- `FICHA_N*.md`: 12 fichas TEST resultantes (exemplos independentes, não canonizados).
- `AVALIACAO_CORPUS_99_R24.csv`: análise das 99 linhas textuais já existentes em R22; compara com rótulos **E3** prévios, não com gabarito humano.
- `PA_R24_MOTOR_CONVERSACIONAL_TEST_20261019.xlsx`: simulador fórmula-dirigido, tarifas, painel, demonstrações, auditoria 99 e fontes.
- `PSV_R24_RELATORIO_FINAL.md`: resultado, critérios, limites e continuidade.
- `HANDOFF_R24_CRAFT_NOTION.md`: integração futura sem assumir writer, lease, epoch ou autorização Party.
- `BASELINE_R22_IMUTAVEL.zip` e `BASELINE_R23_IMUTAVEL.zip`: preservação das entregas anteriores.

## Executar localmente (opcional ao Mestre, que utiliza somente a conversa)

```bash
python motor_conversacional_r24.py exemplo.txt
python -m unittest test_motor_conversacional_r24 test_integracao_r24 -v
PYTHONPATH=.:./baseline_r22 python -m unittest baseline_r22.test_rank_guard_r22 test_alcance_mestre_r23 test_ponte_pa_r23 -v
python evaluate_r24.py
```

### Exemplo de descrição

```text
Item: Botas da Trilha Serena
Rank do item: Ouro
Bônus: +2 Destreza; +3m de deslocamento
Habilidade passiva: Passos sem Pegadas: Enquanto equipadas, não deixam rastros em terreno natural; efeito apenas no portador e sem ocultar o som.
Habilidade ativa: Salto Curto: Com uma ação de movimento, o portador salta 4,5 metros para um ponto visível, uma vez por turno.
```

No exemplo, se Salto Curto for usado **duas vezes**, a prévia condicional é 28 PA/dia + 6 PA de ativações = 34 PA naquele dia. Os dois RE são E3; não representam classificações já aprovadas.

## Fronteiras importantes

- Rank e potência: Atlas PR-ECO-01 existente; dano quando ausente: DMG-RANK-01 v1.1; alcance: determinação expressa do Mestre. O classificador não é norma substituta.
- PA diário base para novos itens: pisos 8 / 11 / 21 / 35 / 90. Habilidade PASSIVA: 6 / 12 / 24 / 35 / 50 PA/dia; ATIVA: 3 / 6 / 12 / 17 / 25 PA/dia; ATIVA por uso: 3 / 7 / 14 / 21 / 30 PA. Truncamento sempre para baixo.
- Fonte com apenas título, custo de PA ou item de rank conhecido não estabelece automaticamente RE da habilidade.
- Valores incompletos nunca representam custo total oficial. `known_lower_bound_day` é apenas parcela demonstrável sujeita ao RI usado.
- Nota de integridade: as comparações com 99 R22 são fracas (E3 prévio), portanto **não demonstram acurácia sobre habilidades inéditas**.
- Original Party é autoridade; Notion não foi modificado; produção HOLD, `NAC-PASS` final pendente.
