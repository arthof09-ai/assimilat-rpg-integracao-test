"""Empirical audit against 99 R22 records. R22 E3 labels are not gold truth."""
import csv,json
from pathlib import Path
from collections import Counter
from motor_conversacional_r24 import rank_infer,ability_kind,RANKS,norm,consultar_pesquisa_r22,analyze_item,as_ficha
ROOT=Path(__file__).parent
rows=list(csv.DictReader((ROOT/'baseline_r22/HABILIDADES_ITENS_R22.csv').open(encoding='utf-8-sig',newline=''),delimiter=';'))
report=[];total=Counter(); notes=[]
for row in rows:
 r=rank_infer(row['mecanica']); status=r['status']; total[status]+=1
 previous=row['RE_preliminar'];within=None
 if r['rank']:
  if '–' in previous:
   lo,hi=previous.split('–',1)
   within=lo in RANKS and hi in RANKS and RANKS.index(lo)<=RANKS.index(r['rank'])<=RANKS.index(hi)
  elif previous in RANKS:within=(previous==r['rank'])
  else:within=None
  total['comparacao_e3_possivel' if within is not None else 'comparacao_e3_impossivel']+=1
  if within is True:total['dentro_da_faixa_anterior_e3']+=1
  if within is False:total['fora_da_faixa_anterior_e3']+=1
 kind,_=ability_kind(row['mecanica'])
 report.append({'item':row['item'],'habilidade':row['habilidade'],'modalidade_r22':row['modalidade'],'modalidade_inferida_de_texto_parcial':kind or 'PENDENTE','eixo_r22':row['eixo_primario'],'re_r22_e3':previous,'re_r24_candidato':r['rank'] or 'HOLD','estado':status,'dentro_da_faixa_r22_e3':within,'justificativa':r['reason'],'risco':'; '.join(r['warnings']),'fonte':row['fonte']})
assert len(rows)==99
with (ROOT/'AVALIACAO_CORPUS_99_R24.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(report[0]),delimiter=';');w.writeheader();w.writerows(report)
fixtures=json.loads((ROOT/'FIXTURES_R24.json').read_text('utf-8'))
demos=[]
for f in fixtures:
 case=analyze_item(f['text'],uses=f.get('uses'),source_kind=f.get('source_kind','NOVO_TEST'))
 demos.append({'id':f['id'],'input':f['text'],'response':case})
 (ROOT/f'FICHA_{f["id"]}.md').write_text(as_ficha(case),'utf-8')
(ROOT/'DEMONSTRACOES_CONVERSACIONAIS_R24.json').write_text(json.dumps(demos,ensure_ascii=False,indent=2)+'\n','utf-8')
sums={'n_r22':len(rows),'states':dict(total),'n_demos':len(demos),'caveats':['R22 E3 são hipóteses, não verdade de rank; concordância não significa acurácia','ausência de revisão humana e fontes vivas não equivale a 100% de classificação','codificação local TEST e não integração nativa CRAFT/Notion']}
(ROOT/'AVALIACAO_R24.json').write_text(json.dumps(sums,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(sums,ensure_ascii=False,indent=2))
