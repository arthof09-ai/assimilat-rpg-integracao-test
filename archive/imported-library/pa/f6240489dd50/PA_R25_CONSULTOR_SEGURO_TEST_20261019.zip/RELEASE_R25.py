"""Deterministic release: byte immutable R24, manifest, CRC and clean replay."""
from pathlib import Path
import hashlib,json,zipfile,shutil
W=Path(__file__).parent
ORIGINAL=Path('/mnt/data/PA_R24_CONSULTOR_PONTA_A_PONTA_TEST_20261019.zip')
DEST=Path('/mnt/data/PA_R25_CONSULTOR_SEGURO_TEST_20261019.zip')
REL=Path('/mnt/data/pa_r25_release')
if REL.exists():shutil.rmtree(REL)
REL.mkdir()
# First copy and verify every R24 original member unchanged.
with zipfile.ZipFile(ORIGINAL) as z:
    assert z.testzip() is None
    original_names=z.namelist()
    assert len(original_names)==43
    for name in original_names:
        out=REL/name
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_bytes(z.read(name))
        assert hashlib.sha256(out.read_bytes()).digest()==hashlib.sha256(z.read(name)).digest()
# Embedded byte-authenticated baseline.
shutil.copy2(ORIGINAL,REL/'BASELINE_R24_IMUTAVEL.zip')
new=[
'motor_qualificado_r25.py','test_r25_qualidade.py','avaliar_corpus_r25.py','GERAR_DEMONSTRACOES_R25.py',
'RELEASE_R25.py','PROTOCOLO_CONVERSACIONAL_R25.md','INTEGRACAO_CANONICA_PENDENTE_R25.md',
'README_R25.md','PSV_R25_RELATORIO_FINAL.md','TESTES_R25.log','REGRESSAO_R22_R24_R25.log',
'CORPUS_99_R25.csv','AUDITORIA_CORPUS_R25.json','DEMONSTRACOES_R25.json']
new += [f'FICHA_R25-{n:02d}-{title}.md' for n,title in [
(1,'TEXTO-LIVRE-SEM-RANK'),(2,'ATIVACOES'),(3,'PASSIVA-NUMERICA'),
(4,'DEFESA-SEM-EVIDENCIA'),(5,'RANK-DISSONANTE'),(6,'AREA-NAO-AUTO-RANK'),
(7,'LEGADO-ZEPHYR'),(8,'PASSIVA-ATIVA-MISTA'),(9,'FONTE-COMPARATIVA-E3'),
(10,'COMPOSTO-LIVRE'),(11,'DANO-RECORRENTE'),(12,'CA-FISICA-EXCLUIDA')]]
assert len(new)==26,len(new)
for n in new:
    assert (W/n).exists(),n
    # Manifest entries include no symlinks, and no renamed original baseline paths.
    assert n not in original_names,n
    shutil.copy2(W/n,REL/n)
assert hashlib.sha256((REL/'BASELINE_R24_IMUTAVEL.zip').read_bytes()).digest()==hashlib.sha256(ORIGINAL.read_bytes()).digest()

entries={}
for p in sorted(REL.rglob('*')):
    if p.is_file():
        b=p.read_bytes();entries[p.relative_to(REL).as_posix()]={'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}
manifest={'release':'R25','date':'2026-10-19','original_r24_zip_sha256':hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
          'original_r24_member_count':len(original_names), 'original_r24_unchanged':True,
          'baseline_r22_r23_r24_unmodified':True, 'production':'HOLD','party_writes':0,'notion_writes':0,
          'r25_quality_tests':71,'r22_r24_regression_tests':92,
          'archive_members_excluding_manifest':len(entries), 'entries':entries}
(REL/'MANIFEST_R25.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
if DEST.exists():DEST.unlink()
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(REL.rglob('*')):
        if not p.is_file():continue
        name=p.relative_to(REL).as_posix()
        zi=zipfile.ZipInfo(name,date_time=(2026,10,19,20,30,0))
        zi.compress_type=zipfile.ZIP_DEFLATED
        zi.external_attr=0o644<<16
        z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(entries)+1
    for path,row in entries.items():
        by=z.read(path)
        assert hashlib.sha256(by).hexdigest()==row['sha256'] and len(by)==row['size'],path
    z.read('MANIFEST_R25.json')
print(json.dumps({'zip':str(DEST),'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),
                  'size':DEST.stat().st_size,'members':len(entries)+1,'original_r24_member_count':len(original_names),
                  'crc':'PASS','manifest':'PASS'},ensure_ascii=False))
