# Amuleto — PREVIEW MESTRE R25 / TEST
**Estado:** HOLD · **Produção:** HOLD
**Rank do item:** INDETERMINADO (RI_INDETERMINADO)

## Habilidades e tarifas por componente
- **Resistência da Aurora** — PASSIVA; RE candidato **PENDENTE**; estado **HOLD_EVIDENCIA**; PA/dia **PENDENTE**; PA/ativação **PENDENTE**.
  - Texto recebido: Enquanto equipado protege contra dano mental e impede interferência no pensamento.
  - Pendências específicas: RE_SEM_RANK_ADMISSIVEL
  - Geometria: INDEFINIDA; alcance=None (ALCANCE_PENDENTE); raio=None (ALCANCE_PENDENTE); extensao=None (ALCANCE_PENDENTE); origem=None (ALCANCE_PENDENTE)
  - Ressalvas espaciais: MULTIPLOS_ALVOS_NAO_DETERMINAM_GEOMETRIA
  - Tarifas sob RANKS HIPOTÉTICOS (não usar como preço fechado): {"Bronze": {"PA_dia": 6, "PA_uso": 0}, "Prata": {"PA_dia": 12, "PA_uso": 0}, "Ouro": {"PA_dia": 24, "PA_uso": 0}, "Ouro Negro": {"PA_dia": 35, "PA_uso": 0}, "Lendário": {"PA_dia": 50, "PA_uso": 0}}

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: 0 PA/dia
- Subtotal parcial conhecido (não representa custo final): 0 PA/dia
- Piso do RI candidato: PENDENTE PA/dia
- **Diário simulado:** PENDENTE PA/dia
- **Usos simulados:** PENDENTE PA
- **Total no cenário:** PENDENTE PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: HOLD_CUSTO_TOTAL_INDETERMINADO.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": null, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- Resistência da Aurora: RE_SEM_RANK_ADMISSIVEL

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
