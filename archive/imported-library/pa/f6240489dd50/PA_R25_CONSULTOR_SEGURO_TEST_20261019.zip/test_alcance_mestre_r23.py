"""Testes focados R23: parâmetro específico > fallback > lacuna."""
import unittest
from alcance_mestre_r23 import (
    Especificacao, aplicar_regra_mestre, area_circular_contem, RegraInvalida,
    ALCANCE_EXPLICITO, ALCANCE_REGRA_GERAL_MESTRE, ALCANCE_PENDENTE)

class TesteAlcanceMestre(unittest.TestCase):
    def solve(self, **kw):return aplicar_regra_mestre(Especificacao(id='fixture', **kw))
    def test_alvo_unico_ofensivo_padrao(self):
        d=self.solve(funcao='OFENSIVA',forma='ALVO_UNICO',alvos=1)
        self.assertEqual(d['alcance'],{'valor':9.,'origem':ALCANCE_REGRA_GERAL_MESTRE})
        self.assertIsNone(d['raio']['valor'])
        self.assertEqual(d['delta_pa_por_geometria'],0)
    def test_alvo_unico_especifico_15(self):
        d=self.solve(funcao='OFENSIVA',forma='ALVO_UNICO',alcance_m=15)
        self.assertEqual(d['alcance'],{'valor':15.,'origem':ALCANCE_EXPLICITO})
    def test_alvo_unico_nao_ofensivo_nao_default(self):
        d=self.solve(funcao='DEFENSIVA',forma='ALVO_UNICO',alvos=1)
        self.assertIsNone(d['alcance']['valor'])
    def test_alvo_unico_multiplo_conflito(self):
        d=self.solve(funcao='OFENSIVA',forma='ALVO_UNICO',alvos=3)
        self.assertIsNone(d['alcance']['valor'])
        self.assertIn('FORMA_ALVO_UNICO_INCOMPATIVEL_COM_ALVOS_MULTIPLOS',d['ressalvas'])
    def test_cone_padrao(self):
        d=self.solve(funcao='OFENSIVA',forma='CONE')
        self.assertEqual(d['origem'],{'valor':'conjurador','origem':ALCANCE_REGRA_GERAL_MESTRE})
        self.assertEqual(d['extensao']['valor'],4.5)
        self.assertIn('ABERTURA_ANGULAR_NAO_FIXADA_PELA_DIRETRIZ',d['ressalvas'])
    def test_cone_extensao_especifica_6(self):
        d=self.solve(funcao='OFENSIVA',forma='CONE',extensao_m=6)
        self.assertEqual(d['extensao']['valor'],6)
        self.assertEqual(d['extensao']['origem'],ALCANCE_EXPLICITO)
    def test_cone_origem_especifica_permite_outro_ponto(self):
        d=self.solve(funcao='OFENSIVA',forma='CONE',origem='ponto_5m')
        self.assertEqual(d['origem']['valor'],'ponto_5m')
        self.assertEqual(d['origem']['origem'],ALCANCE_EXPLICITO)
    def test_cone_angulo_explicito(self):
        d=self.solve(funcao='OFENSIVA',forma='CONE',abertura_cone_graus=60)
        self.assertNotIn('ABERTURA_ANGULAR_NAO_FIXADA_PELA_DIRETRIZ',d['ressalvas'])
    def test_cone_utilitario_pendente(self):
        d=self.solve(funcao='UTILITARIA',forma='CONE')
        self.assertEqual(d['extensao']['origem'],ALCANCE_PENDENTE)
    def test_circular_padrao_duas_dimensoes(self):
        d=self.solve(funcao='OFENSIVA',forma='CIRCULAR')
        self.assertEqual((d['alcance']['valor'],d['raio']['valor'],d['diametro_m']),(9,6,12))
        self.assertEqual(d['origem']['valor'],'ponto_escolhido_pelo_conjurador')
    def test_circular_raio_3_explicito_alcance_padrao(self):
        d=self.solve(funcao='OFENSIVA',forma='CIRCULAR',raio_m=3)
        self.assertEqual(d['raio']['origem'],ALCANCE_EXPLICITO)
        self.assertEqual((d['alcance']['valor'],d['raio']['valor']),(9,3))
    def test_circular_alcance18_explicito_raio_padrao(self):
        d=self.solve(funcao='OFENSIVA',forma='CIRCULAR',alcance_m=18)
        self.assertEqual(d['alcance']['origem'],ALCANCE_EXPLICITO)
        self.assertEqual((d['alcance']['valor'],d['raio']['valor']),(18,6))
    def test_circular_tudo_explicito(self):
        d=self.solve(funcao='UTILITARIA',forma='CIRCULAR',alcance_m=4,raio_m=2,origem='próprio item')
        self.assertEqual(d['raio']['origem'],ALCANCE_EXPLICITO)
        self.assertEqual(d['alcance']['origem'],ALCANCE_EXPLICITO)
        self.assertEqual(d['origem']['origem'],ALCANCE_EXPLICITO)
    def test_circular_utilitaria_tambem_recebe_padrao(self):
        d=self.solve(funcao='UTILITARIA',forma='CIRCULAR')
        self.assertEqual((d['alcance']['valor'],d['raio']['valor']),(9,6))
    def test_linha_nao_converte(self):
        d=self.solve(funcao='OFENSIVA',forma='LINHA',extensao_m=36)
        self.assertIsNone(d['raio']['valor'])
        self.assertEqual(d['extensao']['valor'],36)
    def test_geometria_indefinida_nao_inventar(self):
        d=self.solve(funcao='OFENSIVA',forma='INDEFINIDA',alvos=3)
        self.assertIsNone(d['alcance']['valor'])
        self.assertIsNone(d['raio']['valor'])
    def test_efeito_nao_magico_ignora_padrao(self):
        d=self.solve(fonte_tipo='HABILIDADE_NAO_MAGICA',funcao='OFENSIVA',forma='ALVO_UNICO')
        self.assertEqual(d['alcance']['origem'],ALCANCE_PENDENTE)
    def test_item_magico_partilha_regra(self):
        d=self.solve(fonte_tipo='HABILIDADE_MAGICA_ITEM',funcao='OFENSIVA',forma='CIRCULAR')
        self.assertEqual(d['alcance']['valor'],9)
    def test_alvo_unico_alcance_zero_especifico_preservado(self):
        d=self.solve(funcao='OFENSIVA',forma='ALVO_UNICO',alcance_m=0)
        self.assertEqual(d['alcance']['valor'],0)
        self.assertEqual(d['alcance']['origem'],ALCANCE_EXPLICITO)
    def test_area_9_centro_6_raio_borda_mais_proxima(self):
        d=area_circular_contem(caster=(0,0),centro=(9,0),alvo=(3,0),alcance_centro_m=9,raio_m=6)
        self.assertTrue(d['atinge_alvo'])
        self.assertFalse(area_circular_contem(caster=(0,0),centro=(9,0),alvo=(0,0),alcance_centro_m=9,raio_m=6)['atinge_alvo'])
    def test_area_auto_inclusao_se_menor_6(self):
        d=area_circular_contem(caster=(0,0),centro=(5,0),alvo=(0,0),alcance_centro_m=9,raio_m=6)
        self.assertTrue(d['atinge_alvo'])
        self.assertFalse(d['alvo_conjurador_auto_imune'])
    def test_centro_fora_9_invalido(self):
        d=area_circular_contem(caster=(0,0),centro=(9.001,0),alvo=(9.001,0),alcance_centro_m=9,raio_m=6)
        self.assertFalse(d['centro_valido'])
        self.assertFalse(d['atinge_alvo'])
    def test_explicito_negativo_invalido(self):
        with self.assertRaises(RegraInvalida):self.solve(funcao='OFENSIVA',forma='CIRCULAR',raio_m=-2)
    def test_alvo_unico_origem_remota_nao_forcar_9m(self):
        d=self.solve(funcao='OFENSIVA',forma='ALVO_UNICO',origem='ponto_fixo_remoto')
        self.assertEqual(d['alcance']['origem'],ALCANCE_PENDENTE)
        self.assertIn('ORIGEM_ESPECIFICA_DISTINTA_EXIGE_ANALISE_REFERENCIAL_DE_ALCANCE',d['ressalvas'])
    def test_circular_centrada_conjurador_origem_fixa(self):
        d=self.solve(funcao='OFENSIVA',forma='CIRCULAR',origem='conjurador')
        self.assertIsNone(d['alcance']['valor'])
        self.assertEqual(d['raio']['valor'],6)
        self.assertIn('CENTRO_EXPLICITO_FIXO_OU_ORIGEM_ESPECIAL_NAO_CONVERTER_PARA_ALCANCE_9M',d['ressalvas'])
    def test_infinito_rejeitado(self):
        with self.assertRaises(RegraInvalida):self.solve(funcao='OFENSIVA',forma='CIRCULAR',alcance_m=float('inf'))
    def test_cone_abertura_invalida(self):
        with self.assertRaises(RegraInvalida):self.solve(funcao='OFENSIVA',forma='CONE',abertura_cone_graus=0)
    def test_pendente_rank_sem_custo(self):
        d=self.solve(funcao='OFENSIVA',forma='CIRCULAR')
        self.assertIsNone(d['rank_habilidade'])
        self.assertEqual(d['delta_pa_por_geometria'],0)

if __name__=='__main__':unittest.main()
