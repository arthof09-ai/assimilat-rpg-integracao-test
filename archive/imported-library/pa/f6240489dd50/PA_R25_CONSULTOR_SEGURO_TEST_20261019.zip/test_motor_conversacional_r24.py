import unittest, json
from pathlib import Path
from motor_conversacional_r24 import *
from baseline_r22.rank_guard_r22 import tariff

FIXTURES=json.loads((Path(__file__).parent/'FIXTURES_R24.json').read_text('utf-8'))
class TestR24(unittest.TestCase):
    def test_01_tarifas_60(self):
        exp={'Bronze':(6,3,3),'Prata':(12,6,7),'Ouro':(24,12,14),'Ouro Negro':(35,17,21),'Lendário':(50,25,30)}
        for r,(p,a,u) in exp.items():
            t=tariff(r);self.assertEqual((t['passiva_por_dia'],t['ativa_por_dia'],t['ativa_por_uso']),(p,a,u))
    def test_02_floor(self):
        self.assertEqual(FLOOR,{'Bronze':8,'Prata':11,'Ouro':21,'Ouro Negro':35,'Lendário':90})
    def test_03_numerics(self):
        n,w=numeric_components('+2 FOR; +3 de ataque; +1 CA mágica; +4m de deslocamento; +5 dano')
        self.assertEqual(numeric_pa(n),23)
        self.assertFalse(w,w)
    def test_04_unpriced_CA_physical(self):
        n,w=numeric_components('+11 CA de armadura física')
        self.assertEqual(numeric_pa(n),0);self.assertTrue(w)
    def test_05_ability_passive(self):
        self.assertEqual(ability_kind('Enquanto equipado impede pegadas',None)[0],'PASSIVA')
    def test_06_ability_active(self):
        self.assertEqual(ability_kind('Ao ativar com uma ação produz luz',None)[0],'ATIVA')
    def test_07_ambiguous(self):
        self.assertIsNone(ability_kind('Invoca a queda das estrelas',None)[0])
    def test_08_independent_rank_PA(self):
        a=rank_infer('Causa 8d10 de dano em um único alvo')
        b=rank_infer('Causa 8d10 de dano em um único alvo, 500 PA por ativação e item Bronze')
        self.assertEqual(a['rank'],b['rank'])
    def test_09_no_auto_notion(self):
        for f in FIXTURES:
            r=analyze_item(f['text'],uses=f.get('uses'),source_kind=f.get('source_kind','NOVO_TEST'))
            self.assertFalse(r['can_publish']);self.assertFalse(r['can_write_notion'])
    def test_10_demo_ranks(self):
        for f in FIXTURES:
            if 'expected_rank' in f:
                r=analyze_item(f['text'],uses=f.get('uses'))
                got=r['abilities'][0]['rank'] if r['abilities'] else r['item_rank']
                self.assertEqual(got,f['expected_rank'],f['id'])
    def test_11_demo_energy(self):
        for f in FIXTURES:
            r=analyze_item(f['text'],uses=f.get('uses'))
            p=r['costs']
            if 'expected_daily' in f:self.assertEqual(p['day'],f['expected_daily'],f['id'])
            if 'expected_activation' in f:self.assertEqual(p['activations'],f['expected_activation'],f['id'])
            if 'expected_total' in f:self.assertEqual(p['total'],f['expected_total'],f['id'])
    def test_12_geometry(self):
        for f in FIXTURES:
            r=analyze_item(f['text'],uses=f.get('uses'))
            if not r['abilities'] or not r['abilities'][0]['spatial']:continue
            s=r['abilities'][0]['spatial']
            if 'expected_range' in f:self.assertEqual(s['alcance']['valor'],f['expected_range'])
            if 'expected_circle_radius' in f:
                self.assertEqual(s['raio']['valor'],f['expected_circle_radius']);self.assertEqual(s['alcance']['valor'],f['expected_circle_range'])
    def test_13_historic_unchanged(self):
        f=next(i for i in FIXTURES if i.get('source_kind')=='HISTORICO')
        r=analyze_item(f['text'],source_kind='HISTORICO')
        self.assertTrue(any('LEGADO' in z for z in r['warnings']))
    def test_14_no_extra_charge_named_stat(self):
        f=next(f for f in FIXTURES if f['id']=='N04-PASS-ATRIBUTO-NAO-DUPLO')
        r=analyze_item(f['text']);self.assertEqual(r['costs']['day'],15)
        self.assertEqual(r['abilities'][0]['kind'],'NUMERICO_SEM_HABILIDADE_INDEPENDENTE')
    def test_15_rank_unset_without_evidence(self):
        r=analyze_item('Item: Anel\nHabilidade ativa: Mistério: Controla gravidade num campo não definido')
        self.assertIsNone(r['item_rank']);self.assertIsNone(r['costs']['total'])
    def test_16_no_cost_based_rank(self):
        for c in ['12 PA por dia','2000000 MED','500 PA para ativar']:
            x=rank_infer('Causa 8d10 de dano contra um alvo '+c)
            self.assertEqual(x['rank'],'Ouro')
    def test_17_duplicate_ids(self):
        with self.assertRaises(Exception):
            estimate_new_item('Bronze',[Effect('X','Bronze','ATIVA','E3'),Effect('X','Bronze','ATIVA','E3')])
    def test_18_no_mutation_old(self):
        x=analyze_item(FIXTURES[7]['text'],source_kind='HISTORICO')
        self.assertEqual(x['source_kind'],'HISTORICO');self.assertFalse(x['can_write_notion'])
    def test_19_invalid_use(self):
        with self.assertRaises(InterpretacaoPendente):analyze_item('Habilidade ativa: Brilho: Ao ativar gera luz',uses={'Brilho':-1})
    def test_20_stat_only_with_floor(self):
        x=analyze_item('Item: Capa\nRank do item: Ouro Negro\nBônus: +2 FOR')
        self.assertEqual(x['costs']['day'],35)
    def test_21_ability_rank_not_item_rank(self):
        r=analyze_item('Item: Escudo\nRank do item: Lendário\nHabilidade ativa: Pulo: Com uma ação, salta 4,5m')
        self.assertEqual(r['abilities'][0]['rank'],'Bronze')
        self.assertEqual(r['costs']['floor'],90)
        self.assertEqual(r['abilities'][0]['cost_pa_use'],3)
    def test_22_no_multiple_targets_cone_from_words(self):
        r=analyze_item('Habilidade ativa: Puxão: Com uma ação puxa inimigos próximos')
        self.assertEqual(r['abilities'][0]['spatial']['forma'],'INDEFINIDA')
    def test_23_no_pa_by_geometry(self):
        a=rank_infer('Causa 8d10 de dano contra um alvo. Alcance 9 metros')
        b=rank_infer('Causa 8d10 de dano contra um alvo. Alcance 15 metros')
        self.assertEqual(a['rank'],b['rank'])
    def test_24_ficha(self):
        s=as_ficha(analyze_item(FIXTURES[0]['text'],uses=FIXTURES[0]['uses']))
        self.assertIn('49 PA',s);self.assertIn('PRODUÇÃO: HOLD',s)
    def test_25_no_rank_from_name(self):
        r=analyze_item('Item: Espada do Lendário\nHabilidade ativa: Mistério: Emite energia misteriosa')
        self.assertIsNone(r['abilities'][0]['rank'])
    def test_26_naive_inconclusive(self):
        for s in ['descobre todos os segredos','se torna invencível','pode fazer qualquer coisa']:
            r=rank_infer(s)
            self.assertEqual(r['status'],'HOLD_RE')

if __name__=='__main__':unittest.main(verbosity=2)
