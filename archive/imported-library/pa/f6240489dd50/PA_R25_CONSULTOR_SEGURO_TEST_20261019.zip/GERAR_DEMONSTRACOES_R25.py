"""Reusable conversational acceptance cases, distinct from reference samples."""
from motor_qualificado_r25 import avaliar, ficha
from pathlib import Path
import json
P=Path(__file__).parent
cases=[
 {'id':'R25-01-TEXTO-LIVRE-SEM-RANK','description':'Crie um cajado que dispara 8d10 de dano num único alvo com uma ação padrão.'},
 {'id':'R25-02-ATIVACOES','description':'Item: Varinha da Chama Direta\nHabilidade ativa: Lança de Chamas: Com uma ação padrão, causa 8d10 de dano de fogo em um único alvo; efeito instantâneo, alcance 9 metros. Uma vez por turno.', 'uses':{'Lança de Chamas':2}},
 {'id':'R25-03-PASSIVA-NUMERICA','description':'Item: Manoplas\nRank do item: Prata\nHabilidade passiva: Vigor: +2 FOR; +3 de ataque'},
 {'id':'R25-04-DEFESA-SEM-EVIDENCIA','description':'Item: Amuleto\nHabilidade passiva: Resistência da Aurora: Enquanto equipado protege contra dano mental e impede interferência no pensamento.'},
 {'id':'R25-05-RANK-DISSONANTE','description':'Item: Armadura\nRank do item: Bronze\nHabilidade ativa Bronze: Lança Catastrófica: Com uma ação padrão, causa 100d100 de dano em um único alvo.'},
 {'id':'R25-06-AREA-NAO-AUTO-RANK','description':'Item: Cetro\nHabilidade ativa: Explosão de Chamas: Com uma ação padrão, causa 8d10 de dano de fogo numa área circular de raio 3 metros.'},
 {'id':'R25-07-LEGADO-ZEPHYR','description':'Item: Armadura de Zephyr\nRank do item: Lendário\nBônus: +15 DES; +25 em Testes de Ataque; +15m de deslocamento; +11 CA de armadura física; +50 de dano de Vento por turno\n90 PA por dia','source_kind':'HISTORICO'},
 {'id':'R25-08-PASSIVA-ATIVA-MISTA','description':'Item: Botas da Trilha Serena\nRank do item: Ouro\nBônus: +2 DES; +3m de deslocamento\nHabilidade passiva Prata: Passos sem Pegadas: Enquanto equipadas, não deixam rastros em terreno natural; sem ocultar som.\nHabilidade ativa Bronze: Salto Curto: Com uma ação de movimento, salta 4,5 metros uma vez por turno.', 'uses':{'Salto Curto':2}},
 {'id':'R25-09-FONTE-COMPARATIVA-E3','description':'Item: Botas\nRank do item: Ouro\nHabilidade passiva: Passos sem Pegadas: Enquanto equipadas não deixam rastros em terreno natural, sem ocultar som.',
  'evidencias':{'Passos sem Pegadas':{'rank_candidato':'Prata','mecanica':{'gatilho':'equipado','alvo':'portador','duracao':'enquanto equipado','resultado':'não deixa rastros em terreno natural','limites':'não impede detecção por som'},'comparadores':[{'tipo':'sistemico','fonte':'https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab','comparacao':'Atlas Prata especialização tática consistente para furtividade e rastreio'}, {'tipo':'familia','fonte':'https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c','comparacao':'Item anterior documenta passos sem pegadas como recurso de ocultação de rastros'}]}}},
 {'id':'R25-10-COMPOSTO-LIVRE','description':'Quero um anel que dê invisibilidade e também teleporte aliados e regenere 10 PA por rodada.'},
 {'id':'R25-11-DANO-RECORRENTE','description':'Item: Anel\nRank do item: Ouro\nBônus: +50 de dano de Vento por turno.'},
 {'id':'R25-12-CA-FISICA-EXCLUIDA','description':'Item: Armadura do Explorador\nRank do item: Prata\nBônus: +11 CA de armadura física; +2 FOR; +3 em testes de ataque'},
]
output=[]
for d in cases:
    result=avaliar(d['description'],usos=d.get('uses'),origem=d.get('source_kind','NOVO_TEST'),evidencias=d.get('evidencias'))
    (P/f"FICHA_{d['id']}.md").write_text(ficha(result),'utf-8')
    output.append({'id':d['id'],'original':d,'outcome':result})
(P/'DEMONSTRACOES_R25.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n','utf-8')
for d in output:
    r=d['outcome'];p=r['pa']
    print(d['id'], r['status'], r.get('item_rank_candidate'),p['daily_scenario_pa'],p['activation_scenario_pa'],p['total_scenario_pa'])
