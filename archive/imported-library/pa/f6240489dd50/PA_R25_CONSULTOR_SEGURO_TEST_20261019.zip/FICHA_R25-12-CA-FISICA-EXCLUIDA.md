# Armadura do Explorador — PREVIEW MESTRE R25 / TEST
**Estado:** PREVIA_CONDICIONAL · **Produção:** HOLD
**Rank do item:** Prata (DECLARADO_PELO_USUARIO_NAO_COMPROVA_RANK_CANONICO)

## Habilidades e tarifas por componente
Nenhuma habilidade individual validada na extração.
- Excluído conscientemente do PA mágico: +11 CA de armadura física (CA_FISICA_SEM_TARIFA_MAGICA)

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: 13 PA/dia
- Subtotal parcial conhecido (não representa custo final): 13 PA/dia
- Piso do RI candidato: 11 PA/dia
- **Diário simulado:** 13 PA/dia
- **Usos simulados:** 0 PA
- **Total no cenário:** 13 PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: SIMULACAO_E3_CONDICIONAL.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": null, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- Nenhuma lacuna local impeditiva; ranks E3 e produção seguem sem validação independente.

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
