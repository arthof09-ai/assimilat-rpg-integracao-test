# Cajado Orbital — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** PENDENTE (RI_PENDENTE_SEM_EVIDENCIA)
**Bônus diretos:** {"FOR": 0, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 0, "ca_magica": 0}; tarifa identificada 0 PA/dia.

## Habilidades propostas
- **Gravidade Abissal** — ATIVA; RE PENDENTE (E3_INSUFICIENTE); diário: PENDENTE; por uso: PENDENTE; usos simulados: 0.
  - Mecânica recebida: Prende os inimigos num campo de gravidade, sem limites especificados.
  - Referências/ressalvas: Controle complexo sem CD/duração/limites verificáveis..

## Consumo energético prospectivo
- Piso item: PENDENTE PA/dia.
- Parcela diária identificada: PENDENTE PA/dia.
- **Prévia diária condicional:** PENDENTE PA/dia.
- Ativações no cenário: PENDENTE PA.
- **Prévia total no cenário:** PENDENTE PA.
- Estado: HOLD_RI_SEM_RANK; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: Gravidade Abissal: RE_INDETERMINADO.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
