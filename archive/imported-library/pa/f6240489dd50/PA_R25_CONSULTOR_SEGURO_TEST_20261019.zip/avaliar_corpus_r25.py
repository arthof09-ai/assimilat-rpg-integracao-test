"""99 historical R22 observations triaged with R25 conservative gates.
R22 labels E3 are not independently verified ground truth.
"""
import csv,collections,json
from pathlib import Path
from motor_qualificado_r25 import avaliar, norm
P=Path(__file__).parent
src=P/'baseline_r22/HABILIDADES_ITENS_R22.csv'
rows=list(csv.DictReader(src.open(encoding='utf-8-sig'),delimiter=';'))
logs=[];C=collections.Counter()
for i,row in enumerate(rows):
    # Distinct skill identity. Note: no item rank is passed, because the rank of
    # an item is NOT ground truth for RE.
    mode=row['modalidade']
    start=('Habilidade '+('ativa' if mode=='ATIVA' else 'passiva')+':') if mode in ('ATIVA','PASSIVA') else 'Habilidade:'
    spec=f'Item: {row["item"]}\n{start} {row["habilidade"]}: {row["mecanica"]}'
    try:
        out=avaliar(spec,origem='HISTORICO')
        a=out['abilities'][0] if out['abilities'] else None
        r=a['qualidade_rank'] if a else {}
        approved=False
        status=r.get('status','NO_SKILL')
        candidate=r.get('candidate')
        C[status]+=1
        C['R25_RATE_USABLE']+=int(bool(r.get('usable_for_provisional_cost')))
        C['HOLD']+=int(not bool(r.get('usable_for_provisional_cost')))
        C['R22_PREVIOUS_E3_RANGE_RECORDED']+=int(row.get('RE_preliminar','').strip() not in ('','INDETERMINADO'))
        logs.append({'ordinal':i+1,'item':row['item'],'habilidade':row['habilidade'],
                     'tipo_r22':mode,'eixo_r22':row['eixo_primario'],'re_anterior_r22_e3':row['RE_preliminar'],
                     'r25_sugestao_sem_preco':candidate or '', 'r25_status':status,
                     'r25_tarifa_permitida_em_test':bool(r.get('usable_for_provisional_cost')),
                     'issues':' | '.join(r.get('issues',[])), 'origem_fonte':row['fonte']})
    except Exception as e:
        C['EXCEPTION']+=1
        logs.append({'ordinal':i+1,'item':row['item'],'habilidade':row['habilidade'],
                     'tipo_r22':mode,'eixo_r22':row['eixo_primario'],'re_anterior_r22_e3':row['RE_preliminar'],
                     'r25_sugestao_sem_preco':'','r25_status':'EXCEPTION',
                     'r25_tarifa_permitida_em_test':False,'issues':str(e),'origem_fonte':row['fonte']})
with (P/'CORPUS_99_R25.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=logs[0].keys(),delimiter=';');w.writeheader();w.writerows(logs)
report={'n':len(logs),'counts':dict(C),'caveat':'R25 conservative historical triage; no independent classification accuracy measurement; R22 E3 not ground truth; old item PA immutable'}
(P/'AUDITORIA_CORPUS_R25.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
