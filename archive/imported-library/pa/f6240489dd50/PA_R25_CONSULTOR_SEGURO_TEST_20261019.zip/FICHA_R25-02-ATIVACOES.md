# Varinha da Chama Direta — PREVIEW MESTRE R25 / TEST
**Estado:** PREVIA_CONDICIONAL · **Produção:** HOLD
**Rank do item:** Ouro (RI_INFERIDO_E3)

## Habilidades e tarifas por componente
- **Lança de Chamas** — ATIVA; RE candidato **Ouro**; estado **CANDIDATO_E3**; PA/dia **12**; PA/ativação **14**.
  - Texto recebido: Com uma ação padrão, causa 8d10 de dano de fogo em um único alvo; efeito instantâneo, alcance 9 metros. Uma vez por turno.
  - Geometria: ALVO_UNICO; alcance=9.0 (ALCANCE_EXPLÍCITO); raio=None (ALCANCE_PENDENTE); extensao=None (ALCANCE_PENDENTE); origem=None (ALCANCE_PENDENTE)

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: 0 PA/dia
- Subtotal parcial conhecido (não representa custo final): 0 PA/dia
- Piso do RI candidato: 21 PA/dia
- **Diário simulado:** 21 PA/dia
- **Usos simulados:** 28 PA
- **Total no cenário:** 49 PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: SIMULACAO_E3_CONDICIONAL.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": null, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- Nenhuma lacuna local impeditiva; ranks E3 e produção seguem sem validação independente.

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
