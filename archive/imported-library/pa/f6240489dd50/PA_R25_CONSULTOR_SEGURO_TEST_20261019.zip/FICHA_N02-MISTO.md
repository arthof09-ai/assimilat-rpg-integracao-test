# Botas da Trilha Serena — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Ouro (RN_ITEM_DECLARADO_PARA_DESIGN)
**Bônus diretos:** {"FOR": 0, "DES": 2, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 3, "ca_magica": 0}; tarifa identificada 13 PA/dia.

## Habilidades propostas
- **Passos sem Pegadas** — PASSIVA; RE Prata (E3_PROPOSTO); diário: 12; por uso: 0; usos simulados: 0.
  - Mecânica recebida: Enquanto equipadas, não deixam rastros em terreno natural; efeito apenas no portador e sem ocultar o som.
  - Referências/ressalvas: Ocultação de rastros condicionada ao terreno e rastreadores; é HIPÓTESE ancorada no Atlas, não regra de corte..
- **Salto Curto** — ATIVA; RE Bronze (E3_PROPOSTO); diário: 3; por uso: 3; usos simulados: 2.
  - Mecânica recebida: Com uma ação de movimento, o portador salta 4,5 metros para um ponto visível, uma vez por turno.
  - Referências/ressalvas: Salto localizado, alcance e frequência decidem; é HIPÓTESE ancorada no Atlas, não regra de corte..

## Consumo energético prospectivo
- Piso item: 21 PA/dia.
- Parcela diária identificada: 28 PA/dia.
- **Prévia diária condicional:** 28 PA/dia.
- Ativações no cenário: 6 PA.
- **Prévia total no cenário:** 34 PA.
- Estado: SIMULACAO_CONDICIONAL; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: Passos sem Pegadas: HIPOTESE_E3; Salto Curto: HIPOTESE_E3.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
