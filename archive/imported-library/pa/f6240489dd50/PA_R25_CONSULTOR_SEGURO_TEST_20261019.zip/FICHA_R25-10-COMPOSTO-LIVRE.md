# Item descrito livremente — PREVIEW MESTRE R25 / TEST
**Estado:** HOLD_SEGMENTACAO · **Produção:** HOLD
**Rank do item:** INDETERMINADO (sem evidencia)

## Habilidades e tarifas por componente
Nenhuma habilidade individual validada na extração.

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: PENDENTE PA/dia
- Subtotal parcial conhecido (não representa custo final): None PA/dia
- Piso do RI candidato: PENDENTE PA/dia
- **Diário simulado:** PENDENTE PA/dia
- **Usos simulados:** PENDENTE PA
- **Total no cenário:** PENDENTE PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: HOLD_SEGMENTACAO.
- Custos já escritos no texto (apenas contexto histórico/declaração): {}.

## Pendências e próxima ação
- EFEITOS_COMPOSTOS_EM_TEXTO_LIVRE_SEPARAR_HABILIDADES

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
