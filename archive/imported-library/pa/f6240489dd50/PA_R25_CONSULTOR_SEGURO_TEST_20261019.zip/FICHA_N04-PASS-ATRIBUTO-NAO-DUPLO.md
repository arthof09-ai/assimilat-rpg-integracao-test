# Anel da Força Simples — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Bronze (RN_ITEM_DECLARADO_PARA_DESIGN)
**Bônus diretos:** {"FOR": 3, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 0, "ca_magica": 0}; tarifa identificada 15 PA/dia.

## Habilidades propostas
- **Força Livre** — NUMERICO_SEM_HABILIDADE_INDEPENDENTE; RE PENDENTE (NAO_APLICAVEL); diário: 0; por uso: 0; usos simulados: 0.
  - Mecânica recebida: +3 FOR
  - Referências/ressalvas: +ATRIBUTO: tarifa numérica, não duplicar tarifa habilidade.

## Consumo energético prospectivo
- Piso item: 8 PA/dia.
- Parcela diária identificada: 15 PA/dia.
- **Prévia diária condicional:** 15 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 15 PA.
- Estado: PREVIA_VALIDAR_NAC; completude: CALCULO_FECHADO_SOMENTE_EM_TEST; não é valor oficial.
- Pendências: sem alertas mecânicos locais; validação oficial ainda exigida.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
