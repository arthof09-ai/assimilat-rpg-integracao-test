# Anel da Última Chance — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Ouro Negro (RI_PROVISORIO_POR_EFEITO_DOMINANTE_E3)
**Bônus diretos:** {"FOR": 0, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 0, "ca_magica": 0}; tarifa identificada 0 PA/dia.

## Habilidades propostas
- **Reação Salvadora** — ATIVA; RE Ouro Negro (E3_PROPOSTO); diário: 17; por uso: 21; usos simulados: 0.
  - Mecânica recebida: Ao falhar em uma salvaguarda, pode usar uma reação para converter a falha em sucesso uma vez por dia.
  - Referências/ressalvas: Bypass de morte/salvaguarda; alta variância por limite; é HIPÓTESE ancorada no Atlas, não regra de corte..

## Consumo energético prospectivo
- Piso item: 35 PA/dia.
- Parcela diária identificada: 17 PA/dia.
- **Prévia diária condicional:** 35 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 35 PA.
- Estado: SIMULACAO_CONDICIONAL; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: Reação Salvadora: HIPOTESE_E3.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
