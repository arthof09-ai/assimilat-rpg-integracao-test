"""R24 | CONSULTOR PA/ATLAS TEST | MESTRE-SIDE

Interpretador conversacional e auditor de custos prospectivos. Não é fonte canônica
nem altera qualquer ficha. Classificações desconhecidas são hipóteses E3 e só
viram ficha publicável após revisão e autoridade competente.

Lê texto em português: linhas 'Item:', 'Bônus:', 'Habilidade ativa/passiva:'.
Também suporta texto livre como entrada, com travas para ambiguidade.
Usa motores originais de R22/R23 como dependências imutáveis.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import floor
from pathlib import Path
from typing import Any
import re, json, unicodedata, csv

from baseline_r22.rank_guard_r22 import BASE, FLOOR, RANKS, Effect, estimate_new_item
from alcance_mestre_r23 import Especificacao, aplicar_regra_mestre

HERE=Path(__file__).resolve().parent
ATLAS_URL='https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'
DMG_URL='https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e'
MAGIA_URL='https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373'
BENCHMARKS={
 'mobilidade':[('salto 4,5m, Traje Águia (RE E3)', 'https://app.notion.com/p/3edc2b324ede816cbad5ca3880ce144d'),('acréscimo +8m, Bota (RE E3)', 'https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c')],
 'defesa':[('proteção ambiental +20 RD, Braçadeira Ouro; rank do ITEM somente', 'https://app.notion.com/p/3f5c2b324ede81eaa080cad94c16dd3b'),('+18 salvaguarda/reação, Inscrição Lendária; rank do ITEM somente', 'https://app.notion.com/p/3f5c2b324ede818296fbd64921861d83')],
 'controle':[('cegueira por um turno, Couraça Eos sem RE E0','https://app.notion.com/p/089c2b324ede837c9e590174fcc33291'),('prender movimento, Cajado Vórtex descrição incompleta', 'https://app.notion.com/p/9efc2b324ede8250a37981fb1fef45dd')],
 'percepcao':[('Percepção +4 e CA condicional no Traje Águia', 'https://app.notion.com/p/3edc2b324ede816cbad5ca3880ce144d'),('Visão na penumbra e +6 percepção, Arco Justiça', 'https://app.notion.com/p/663c2b324ede83a4a63f01e0c184a35a')],
 'cura':[('3d6 Vida temporária por uso, Bracelete', 'https://app.notion.com/p/48cc2b324ede8318a51f81f51bcb1f46'),('Resiliência regenerativa, Couraça Eos', 'https://app.notion.com/p/089c2b324ede837c9e59-0174fcc33291'.replace('-',''))],
 'bypass':[('ignorar dano fatal, Duro de Matar (RE E3)', 'https://app.notion.com/p/6c2c2b324ede83a7b7dc013f94eb052c'),('substituir falha por sucesso, Anel de Evasão (RE E3)', 'https://app.notion.com/p/780c2b324ede82f69ae8818e612b7ad2')],
 'ofensiva':[('DMG-RANK-01 tabelas DME intrínseco por RE', DMG_URL),('Adaga Ouro Negro, dano+veneno, rank do ITEM','https://app.notion.com/p/3edc2b324ede811787a0de913622b14d'),('Dong Goui, Espiritualista Prata 2, inclui 3d8+6; atributos do usuário separados','https://app.notion.com/p/b06c2b324ede8279a0f4014c14125a98'),('Gorrok, referência Ouro 1 no Atlas, Explosão de Terra 4d6 e arma 5d8; contextual','https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474'),('Pan Tueimor, Ouro Negro 1, ficha mista com equipamentos/transformações','https://app.notion.com/p/8f6c2b324ede82c88e5d8184dc3a3b90'),('Eketerina, Lendário, efeitos próprios e de equipamentos misturados; não centro isolado','https://app.notion.com/p/ca0c2b324ede827d93b701336aa8334b')],
}
# Esta tabela não é uma regra nova de rank. É apenas índice de bandas oficiais
# exclusivas da hipótese de dano simples: ação padrão, 1 alvo, sem hard-control/bypass.
BANDS={'Bronze':(4,18,10.5),'Prata':(14,36,24.5),'Ouro':(22,62,40),'Ouro Negro':(38,96,64),'Lendário':(58,160,103)}

class InterpretacaoPendente(ValueError):pass

def norm(s):
    s=unicodedata.normalize('NFD', s.lower())
    return ''.join(c for c in s if unicodedata.category(c)!='Mn')

def rank_mention(s:str)->str|None:
    ss=norm(s).replace('  ',' ')
    for name in ('Ouro Negro','Lendário','Bronze','Prata','Ouro'):
        if re.search(r'(?<!\w)'+norm(name)+r'(?!\w)',ss):return name
    return None

def read_dice(s:str)->tuple[float|None, bool]:
    """DME only for *isolated intrínseco* known expression; exclude user attribute.
    Returns (dme, uncertain_due_to_external_stat).
    """
    v=norm(s)
    if not re.search(r'\b\d+d\d+\b',v):return None, False
    groups=list(re.finditer(r'(\d+)\s*d\s*(\d+)',v))
    if not groups:return None,False
    uncertain=bool(re.search(r'\+\s*(for|int|des|con|sab|car|ff)\b|\bdano\b[^.;]{0,22}\bpor turno\b|\bse acertar\b|\bveneno\b',v))
    if re.search(r'\b(dano adicional|dano extra|bonus de dano|acrescenta|aumenta|\+)\b',v) and 'dano' in v and not re.search(r'\bcausa\b|\binflige\b|\bcada\b|\blanca\b',v):
        uncertain=True
    dme=sum(int(g.group(1))*(int(g.group(2))+1)/2 for g in groups)
    # Literal flat constant tightly adjacent to damage expression. Ignore + attributes.
    tail=v[groups[-1].end():]
    m=re.match(r'\s*\+\s*(\d+)\b',tail)
    if m:dme+=int(m.group(1))
    return dme,uncertain

def numeric_components(line:str):
    """No charge for armor physical CA; +stat=5, +bonus dano/m=1, +attack=1,
    CA only when explicitly magical; malformed/ambiguous clauses get warning.
    Expects numeric additions, not intrinsic weapon damage pool, total CA, or conditional buffs.
    """
    txt=norm(line)
    vals={'FOR':0,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0,'dano':0,'ataque':0,'deslocamento_m':0,'ca_magica':0}
    warnings=[]
    if not txt.strip():return vals,warnings
    chunks=re.split(r'[;,|]|\s+e\s+(?=\+)',txt)
    for c in chunks:
        c=c.strip()
        if not c:continue
        m=re.search(r'\+\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?(forca|destreza|constituicao|inteligencia|sabedoria|carisma|for\b|des\b|con\b|int\b|sab\b|car\b)',c)
        if m:
            k={'forca':'FOR','for':'FOR','destreza':'DES','des':'DES','constituicao':'CON','con':'CON','inteligencia':'INT','int':'INT','sabedoria':'SAB','sab':'SAB','carisma':'CAR','car':'CAR'}[m.group(2)]
            vals[k]+=int(float(m.group(1).replace(',','.')));continue
        m=re.search(r'\+\s*(\d+)\s*(?:de\s*)?(?:metros?|m\b)\s*(?:de\s*)?(?:deslocamento|movimento|velocidade)',c)
        if not m:m=re.search(r'\+\s*(\d+)\s*(?:de\s*)?(?:deslocamento|movimento|velocidade)\s*(?:m|metros?)?',c)
        if m:
            vals['deslocamento_m']+=int(m.group(1));continue
        m=re.search(r'\+\s*(\d+)\s*(?:de\s*)?(?:bonus\s*(?:em|no)?\s*)?(?:testes?\s*(?:de|do)?\s*)?(?:ataque|acerto)',c)
        if m:
            vals['ataque']+=int(m.group(1));continue
        m=re.search(r'\+\s*(\d+)\s*(?:de\s*)?(?:dano|pontos?\s*de\s*dano)(?!\s*\w*dice)',c)
        if m and not re.search(r'\dd\d',c):
            vals['dano']+=int(m.group(1));continue
        m=re.search(r'\+\s*(\d+)\s*(?:de\s*)?(?:ca|classe de armadura)\b',c)
        if m:
            if 'magica' in c or 'encantamento' in c:vals['ca_magica']+=int(m.group(1))
            else:warnings.append('CA_AMBIGUA_OU_FISICA_NAO_TARIFAR: '+c)
            continue
        warnings.append('BONUS_NAO_RECONHECIDO_OU_CONDICIONAL: '+c)
    return vals,warnings


def numeric_pa(nums:dict)->int:
    return 5*sum(nums[k] for k in ('FOR','DES','CON','INT','SAB','CAR'))+sum(nums[k] for k in ('dano','ataque','deslocamento_m','ca_magica'))


def ability_kind(body:str,declared:str|None=None):
    if declared=='ATIVA':return 'ATIVA','EXPLICITA'
    if declared=='PASSIVA':return 'PASSIVA','EXPLICITA'
    t=norm(body)
    if re.search(r'\b(sempre que|automaticamente|enquanto|continuamente|sem precisar ativar|passivamente)\b',t) and not re.search(r'\bpode (?:escolher|usar (?:sua |uma )?(?:acao|reacao)|ativar|acionar)\b',t):
        return 'PASSIVA','INFERIDA_GATILHO_AUTOMATICO'
    if re.search(r'\b(ao ativar|quando ativad[ao]|ativacao|voce pode usar uma acao|pode usar sua reacao|pode escolher ativar|acionar|uma vez por dia voce pode|como uma acao|gastar \d+ cargas?)\b',t):
        return 'ATIVA','INFERIDA_ESCOLHA_ACAO'
    return None,'GATILHO_AMBIGUO'


def dimension_and_spatial(identifier:str,body:str):
    t=norm(body)
    magic=not bool(re.search(r'\b(fisico nao magico|mundano)\b',t))
    if re.search(r'\bcone\b',t):form='CONE'
    elif re.search(r'\b(circulo|circular|esfera de raio|area circular|raio de \d+ metros?)\b',t):form='CIRCULAR'
    elif re.search(r'\b(linha|linha reta)\b',t):form='LINHA'
    elif re.search(r'\b(alvo unico|um unico alvo|um inimigo|um alvo)\b',t):form='ALVO_UNICO'
    elif re.search(r'\b(proprio portador|em si mesmo|ao usuario|em voce mesmo|ao seu corpo)\b',t):form='AUTOCONJURADOR'
    else:form='INDEFINIDA'
    offensive=bool(re.search(r'\b(dano|causa|inflige|dispara|atira|ataque|congela|paralisa|imobiliza|prende|empurra|cega|golpe|rajada)\b',t))
    fun='OFENSIVA' if offensive else 'UTILITARIA'
    range_m=None;radius=None;extent=None
    # Parse explicit geometries strictly context-specific.
    m=re.search(r'(?:alcance(?:\s+de)?|atinge\s+ate|alvo\s+a\s+ate)\s*:?\s*(\d+(?:[.,]\d+)?)\s*m(?:etros?)?\b',t)
    if m:range_m=float(m.group(1).replace(',','.'))
    m=re.search(r'raio\s*(?:de|:)?\s*(\d+(?:[.,]\d+)?)\s*m(?:etros?)?\b',t)
    if m:radius=float(m.group(1).replace(',','.'))
    if form=='CONE':
        m=re.search(r'cone\s*(?:de|com alcance de|de alcance)\s*(\d+(?:[.,]\d+)?)\s*m(?:etros?)?\b',t)
        if m:extent=float(m.group(1).replace(',','.'))
    if form=='LINHA':
        m=re.search(r'linha\s*(?:de|com)\s*(\d+(?:[.,]\d+)?)\s*m(?:etros?)?\b',t)
        if m:extent=float(m.group(1).replace(',','.'))
    origin='conjurador' if form=='CONE' and re.search(r'\bpartindo do conjurador\b',t) else None
    if form=='CIRCULAR' and re.search(r'\bcentrad[oa] no conjurador\b',t):origin='conjurador'
    s=Especificacao(id=identifier,fonte_tipo='HABILIDADE_MAGICA_ITEM' if magic else 'HABILIDADE_NAO_MAGICA',funcao=fun,forma=form,alcance_m=range_m,raio_m=radius,extensao_m=extent,origem=origin)
    return aplicar_regra_mestre(s)


def axis_of(s):
    v=norm(s)
    patterns=[('bypass',r'\b(ignora? dano fatal|morrer|morte|ressuscit|revive|decapit|corta a cabeca|garante sucesso|sucesso automatico|falha.*sucesso|imune a dano|imunidade|controla.*tempo|parar o tempo|teletransporta|teleporte|le mente|controla mente)\b'),
        ('controle',r'\b(imobiliza|paralisa|prende|cega|cegueira|silencia|atordoa|enfeitica|hipnotiza|petrifica|gravidade|controle mental)\b'),
        ('ofensiva',r'\b(dano|ataque|dispara|explosao|raio de energia|projetil|golpe)\b'),
        ('cura',r'\b(cura|recupera.*vida|regenera|vida temporaria|restauracao)\b'),
        ('defesa',r'\b(escudo|resistencia|salvaguarda|absorve dano|reducao de dano|rd |rdf|rdm|protecao)\b'),
        ('mobilidade',r'\b(salto|deslocamento|voo|voar|velocidade|andar na agua|atravessa|passa por)\b'),
        ('percepcao',r'\b(ve.*invisivel|percepcao|visao|detecta|rastrea|visao escura|penumbra|ouvir)\b'),
        ('invocacao',r'\b(invoca|cria uma criatura|conjura um servo)\b')]
    found=[k for k,p in patterns if re.search(p,v)]
    return found or ['utilidade']


def rank_infer(body:str, declared_rank:str|None=None)->dict:
    """Propose RE without ever using item rank, PA or price.

    The next human/Atlas consultation adjudicates the proposal. E3 persists unless
    this specific effect's rank is explicitly authored by Mestre (caller supplied).
    """
    text=norm(body)
    axes=axis_of(body)
    evidence=[{'tipo':'sistemico','fonte':ATLAS_URL,'motivo':'Atlas 14 eixos, efeito dominante, bypass, FIP e limites'}]
    warnings=[]
    for k in axes:
        for title,url in BENCHMARKS.get(k,[]):
            evidence.append({'tipo':'efeito_familia','fonte':url,'motivo':title})
    if 'ofensiva' in axes:
        evidence.append({'tipo':'sistemico_dmg','fonte':DMG_URL,'motivo':'bandas oficiais apenas para dano intrínseco simples padrão'})
    if declared_rank:
        return {'rank':declared_rank,'alternativas':[declared_rank],'evidence':'E0_MESTRE_EXPLICITO_EFEITO', 'reason':'Rank DECLARADO pelo Mestre para a habilidade; não é inferência de custo.', 'warnings':warnings,'axes':axes,'comparators':evidence,'status':'RE_DECLARADO_VALIDAR_DESIGN'}
    # Incomplete general effects cannot be force-ranked.
    if re.search(r'\b(gravidade|domina|controle total|campo de energia|poder misterioso|manipula realidade)\b',text) and not re.search(r'\b(cd\s*\d+|salvaguarda|por \d+ turnos|\d+ segundo|\d+ minuto|\buma vez por dia\b)',text):
        return {'rank':None,'alternativas':list(RANKS),'evidence':'E3_INSUFICIENTE','reason':'Controle complexo sem CD/duração/limites verificáveis.', 'warnings':['FALTAM_PARAMETROS_CRITICOS'], 'axes':axes,'comparators':evidence,'status':'HOLD_RE'}
    # Multicomponent/unbounded effects cannot be inferred from one stat or small dice.
    if re.search(r'\b(por turno|a cada turno|todo turno)\b',text) and (re.search(r'\b(cura|recupera|regenera|sangra|ferimento|veneno)\b',text) or re.search(r'\bdano\b[^.;]{0,20}\bpor turno\b',text)) and not re.search(r'\bdurante\s+\d+\s+turnos\b',text):
        return {'rank':None,'alternativas':list(RANKS),'evidence':'E3_INSUFICIENTE','reason':'Efeito recorrente sem horizonte de duração/ticks confiável; impacto acumulado indeterminado.', 'warnings':['FALTAM_DURACAO_E_ACUMULO'], 'axes':axes,'comparators':evidence,'status':'HOLD_RE'}
    if re.search(r'\b(recupera|gera)\s*\d+\s*pa\b',text) and re.search(r'\b(ao receber|sempre que|automaticamente)\b',text):
        return {'rank':None,'alternativas':list(RANKS),'evidence':'E3_INSUFICIENTE','reason':'Efeito de PA positivo, falta contrato de frequência/anti-loop.', 'warnings':['RISCO_PA_INFINITO'], 'axes':axes,'comparators':evidence,'status':'HOLD_RE'}
    dmg,unknown=read_dice(body)
    if dmg is not None and 'ofensiva' in axes and len(axes)==1 and not unknown:
        fits=[r for r,(a,b,center) in BANDS.items() if a<=dmg<=b]
        if not fits:
            return {'rank':None,'alternativas':list(RANKS),'evidence':'E3_INSUFICIENTE','reason':'DME fora das bandas oficiais padrão ou expressão incompleta.', 'warnings':['REVISAR_DME_E_TIPO_DE_ENTREGA'],'axes':axes,'comparators':evidence,'status':'HOLD_RE'}
        proposal=min(fits,key=lambda r:(abs(dmg-BANDS[r][2]),RANKS.index(r)))
        if len(fits)>1:warnings.append('BANDAS_OFENSIVAS_SOBREPOSTAS:'+','.join(fits))
        return {'rank':proposal,'alternativas':fits,'evidence':'E3_PROPOSTO','reason':f'DME {dmg:g}; candidato por banda oficial DMG para alvo único, Ação Padrão, sem bypass. Necessita revisão das condições.', 'warnings':warnings,'axes':axes,'comparators':evidence,'status':'RE_PROVISORIO'}
    # Conservative family heuristics, NEVER canonical standards.
    rules=[(r'\b(ressuscita|revive|altera destino|controla o tempo|nega a morte)\b','Lendário',['Ouro Negro','Lendário'],'Bypass potencialmente estratégico'),
           (r'\b(decapita|falha.*sucesso|ignorar? o dano fatal|impede.*morte|imune a todo dano)\b','Ouro Negro',['Ouro Negro','Lendário'],'Bypass de morte/salvaguarda; alta variância por limite'),
           (r'\b(teletransporta|teleporte|voa livremente|controle mental)\b','Ouro Negro',['Ouro','Ouro Negro','Lendário'],'Bypass relevante de espaço/controle; escala depende das limitações'),
           (r'\b(invisivel|invisibilidade|cegueira|cega)\b','Prata',['Prata','Ouro'],'Camuflagem ou negação breve exige duração e contramedidas'),
           (r'\b(resistencia (?:a|de)|reduz.*dano|rdf|rdm)\b','Prata',['Prata','Ouro','Ouro Negro'],'Defesa especializada; intensidade e amplitude decidem RE'),
           (r'\b(sem deixar rastros|nao deixa rastros|nao deixam rastros|sem pegadas|apaga suas pegadas)\b','Prata',['Bronze','Prata'],'Ocultação de rastros condicionada ao terreno e rastreadores'),
           (r'\b(atraves?sa.*agua|andar na agua|passar.*agua)\b','Prata',['Bronze','Prata','Ouro'],'Travessia ambiental; permanência e restrições decidem'),
           (r'\b(salta|salto|pulo)\b','Bronze',['Bronze','Prata'],'Salto localizado, alcance e frequência decidem'),
           (r'\b(percepcao|enxerga|rastreia|rastrear|detecta|visao)\b','Bronze',['Bronze','Prata','Ouro'],'Percepção depende de alcance, precisão e resistências'),
           (r'\b(deslocamento|velocidade)\b','Prata',['Bronze','Prata','Ouro'],'Mobilidade quantitativa, duração e economia de ação decidem'),
           (r'\b(recupera|cura|vida temporaria)\b','Bronze',['Bronze','Prata','Ouro'],'Cura/proteção depende de intensidade e alvo')]
    for regex,r,alternatives,why in rules:
        if re.search(regex,text):
            return {'rank':r,'alternativas':alternatives,'evidence':'E3_PROPOSTO','reason':why+'; é HIPÓTESE ancorada no Atlas, não regra de corte.', 'warnings':warnings+['CONFIRMAR_COMPARADORES_E_CONDICOES'], 'axes':axes,'comparators':evidence,'status':'RE_PROVISORIO'}
    return {'rank':None,'alternativas':list(RANKS),'evidence':'E3_INSUFICIENTE','reason':'Texto não discriminou magnitude, eixo ou condições suficiente para RE confiável.', 'warnings':['PRECISA_ESPECIFICACAO_MECANICA'], 'axes':axes,'comparators':evidence,'status':'HOLD_RE'}


def parse_item(text:str)->dict:
    """Conversational extraction with overt uncertainty and no external model dependency."""
    if not text or not text.strip():raise InterpretacaoPendente('descrição vazia')
    name='Item mágico proposto'; irank=None; bonuses=[]; ability=[]; unknown=[]
    for raw in text.splitlines():
        line=raw.strip(' \t-*•')
        if not line:continue
        mt=re.match(r'(?:item|nome)\s*:\s*(.+)',line,re.I)
        if mt:name=mt.group(1).strip();continue
        mt=re.match(r'(?:rank\s+do\s+item|classificacao\s+do\s+item)\s*:\s*(.+)',norm(line),re.I)
        if mt:irank=rank_mention(mt.group(1));continue
        mt=re.match(r'(?:bonus|atributos|estatisticas)\s*:\s*(.+)',norm(line),re.I)
        if mt:bonuses.append(raw.split(':',1)[1].strip());continue
        mt=re.match(r'(?:habilidade\s*)?(passiva|ativa|atv|pass)(?:\s*\[?(ouro negro|lend[aá]rio|bronze|prata|ouro)\]?)?\s*:?\s*(.+)',line,re.I)
        if mt:
            kind='PASSIVA' if norm(mt.group(1)) in ('passiva','pass') else 'ATIVA'
            declared_rank=rank_mention(mt.group(2)) if mt.group(2) else None
            chunk=mt.group(3)
            if ':' in chunk:abname,body=chunk.split(':',1)
            else:abname,body=f'Habilidade {len(ability)+1}',chunk
            ability.append({'name':abname.strip(),'text':body.strip(),'kind_declared':kind,'rank_declared':declared_rank})
            continue
        mt=re.match(r'(?:habilidade|efeito)\s*:\s*(.+)',line,re.I)
        if mt:
            chunk=mt.group(1)
            if ':' in chunk:abname,body=chunk.split(':',1)
            else:abname,body=f'Habilidade {len(ability)+1}',chunk
            ability.append({'name':abname.strip(),'text':body.strip(),'kind_declared':None,'rank_declared':None});continue
        unknown.append(line)
    # Free-form single paragraph: useful triage, never pretend full decomposition.
    if not ability and not bonuses and unknown:
        combined=' '.join(unknown)
        intro=re.search(r'(?:item|anel|armadura|bota|amuleto|espada|bracelete)\s+(?:chamado\s+)?["“]?([\w\s]{3,35})',combined,re.I)
        if intro:name=intro.group(1).split(' que ')[0].strip(' "“”.,')
        m=re.search(r'(?:concede?|fornece?|oferece?)\s+(\+\s*\d+\s*(?:de\s*)?(?:forca|destreza|sabedoria|carisma|inteligencia|constituicao|deslocamento))',norm(combined))
        if m:bonuses.append(m.group(1))
        ability.append({'name':'Efeito identificado em texto livre','text':combined,'kind_declared':None,'rank_declared':None})
        unknown=['TEXTO_LIVRE_NAO_SEGMENTADO: conferir se há efeitos independentes']
    return {'name':name,'item_rank_declared':irank,'bonuses':bonuses,'abilities':ability,'unparsed':unknown}


def consultar_pesquisa_r22(item:str,habilidade:str)->dict|None:
    """Recupera pesquisa anterior sem validar sua E3 e sem tocar em valores legado."""
    p=HERE/'baseline_r22'/'HABILIDADES_ITENS_R22.csv'
    with p.open(encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f,delimiter=';'):
            if norm(row['item']).strip()==norm(item).strip() and norm(row['habilidade']).strip()==norm(habilidade).strip():
                return {'re_faixa_preliminar':row['RE_preliminar'],'fonte':row['fonte'],'evidencia':row['selo_RE'],'observacoes':row['lacunas'],'modalidade_registro':row['modalidade']}
    return None


def analyze_item(description:str, *, uses:dict[str,int]|None=None, source_kind:str='NOVO_TEST')->dict:
    """End-to-end preview. Negative result can still be useful as a partial draft.
    *No official writes*. For existing items only diagnostic, never repricing.
    """
    parsed=parse_item(description)
    abilities=[];warnings=[];numeric={'FOR':0,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0,'dano':0,'ataque':0,'deslocamento_m':0,'ca_magica':0}
    for line in parsed['bonuses']:
        n,w=numeric_components(line)
        for k,v in n.items():numeric[k]+=v
        warnings.extend(w)
    total_num=numeric_pa(numeric)
    rank_candidates=[]
    seen_mechanics=set()
    for i,a in enumerate(parsed['abilities'],1):
        fingerprint=norm(a['text']).strip(' .;')
        if fingerprint in seen_mechanics:
            warnings.append(f'{a["name"]}: DESCRICAO_IDÊNTICA_DUPLICADA_NA_MESMA_FICHA')
            # Never double-charge an identical effect; keep it in unparsed ledger.
            parsed['unparsed'].append(f'DUPLICATA: {a["name"]}')
            continue
        seen_mechanics.add(fingerprint)
        kind,kind_evidence=ability_kind(a['text'],a['kind_declared'])
        if re.search(r'\b(e tambem pode|ou pode ativar|tambem concede uma habilidade)\b',norm(a['text'])):
            warnings.append(f'{a["name"]}: POSSIVEL_MULTIHABILIDADE_SEM_SEPARACAO')
        # A pure +stat called passive is not charged as independent ability.
        pure_stat=bool(re.fullmatch(r'\s*\+\s*\d+\s*(?:de\s*)?(?:forca|destreza|constituicao|inteligencia|sabedoria|carisma|for|des|con|int|sab|car)\s*[.!]?\s*',norm(a['text'])))
        if pure_stat and kind=='PASSIVA':
            n,w=numeric_components(a['text'])
            dup=any(v and numeric[k]>=v for k,v in n.items())
            if dup:warnings.append(f'{a["name"]}: BONIFICACAO_DUPLICADA_NA_LISTA_E_HABILIDADE')
            for k,v in n.items():
                if not dup:numeric[k]+=v
            total_num=numeric_pa(numeric)
            abilities.append({'id':f'HB-{i:02}', 'name':a['name'],'text':a['text'],'kind':'NUMERICO_SEM_HABILIDADE_INDEPENDENTE','kind_evidence':kind_evidence,'rank':None,'rank_alternativas':[],'rank_evidence':'NAO_APLICAVEL','axis':['atributo'],'cost_pa_day':0,'cost_pa_use':0,'uses':0,'spatial':None,'comparators':[ATLAS_URL],'notes':['+ATRIBUTO: tarifa numérica, não duplicar tarifa habilidade'],'source_kind':source_kind})
            continue
        reff=rank_infer(a['text'],a.get('rank_declared'))
        spatial=dimension_and_spatial(f'HB-{i:02}',a['text'])
        chosen=reff['rank']
        estudo_r22=consultar_pesquisa_r22(parsed['name'],a['name']) if source_kind=='HISTORICO' else None
        count=0 if uses is None else uses.get(a['name'],0)
        if not isinstance(count,int) or isinstance(count,bool) or count<0:raise InterpretacaoPendente('usos devem ser inteiro não negativo')
        if kind != 'ATIVA' and count>0:raise InterpretacaoPendente('usos em habilidade não ativa')
        cost_day=(BASE[chosen] if kind=='PASSIVA' else floor(BASE[chosen]/2) if kind=='ATIVA' else None) if chosen else None
        cost_use=floor(BASE[chosen]*0.6) if chosen and kind=='ATIVA' else 0 if kind=='PASSIVA' else None
        if kind is None:warnings.append(f'{a["name"]}: MODALIDADE_NAO_DECIDIDA')
        if chosen is None:warnings.append(f'{a["name"]}: RE_INDETERMINADO')
        if reff['status']=='RE_PROVISORIO':warnings.append(f'{a["name"]}: HIPOTESE_E3')
        if chosen:rank_candidates.append(chosen)
        abilities.append({'id':f'HB-{i:02}', 'name':a['name'],'text':a['text'],'kind':kind or 'PENDENTE','kind_evidence':kind_evidence,'rank':chosen,'rank_alternativas':reff['alternativas'],'rank_evidence':reff['evidence'],'axis':reff['axes'],'rank_reason':reff['reason'],'rank_warnings':reff['warnings'],'cost_pa_day':cost_day,'cost_pa_use':cost_use,'uses':count,'spatial':spatial,'comparators':reff['comparators'],'notes':reff['warnings'],'study_r22':estudo_r22,'source_kind':source_kind})
    declared=parsed['item_rank_declared']
    ri=declared or (max(rank_candidates,key=lambda r:RANKS.index(r)) if rank_candidates else None)
    rank_state='RN_ITEM_DECLARADO_PARA_DESIGN' if declared else 'RI_PROVISORIO_POR_EFEITO_DOMINANTE_E3' if ri else 'RI_PENDENTE_SEM_EVIDENCIA'
    if declared and rank_candidates and RANKS.index(declared)<max(RANKS.index(r) for r in rank_candidates):
        warnings.append('CONFLITO_ITEM_RANK_INFERIOR_AO_RE_CANDIDATO: revisar Atlas, efeitos e rank público')
    tariff_effects=[]
    for a in abilities:
        if a['kind'] in ('ATIVA','PASSIVA') and a['rank']:
            tariff_effects.append(Effect(identifier=a['id'],rank=a['rank'],kind=a['kind'],evidence='E3',uses=a['uses']))
    closed=bool(ri and all(a['rank'] and a['kind'] in ('PASSIVA','ATIVA','NUMERICO_SEM_HABILIDADE_INDEPENDENTE') for a in abilities) and not parsed['unparsed'] and not warnings and not any('CONFLITO' in w for w in warnings))
    # Candidate summaries may be calculated but are *never* falsely final.
    if ri:
        pa=estimate_new_item(ri,tariff_effects,total_num)
        # rank inference E3 => final can never be asserted until approval;
        pa['quote_state']='SIMULACAO_CONDICIONAL' if any(a['rank_evidence'].startswith('E3') for a in abilities) or warnings else 'PREVIA_VALIDAR_NAC'
        if not closed:pa['approved_daily_pa']=None;pa['approved_total_pa']=None
        else:pa['approved_daily_pa']=None;pa['approved_total_pa']=None # no official commit in TEST
    else:pa={'day_effects':None,'floor':None,'day':None,'activations':None,'total':None,'quote_state':'HOLD_RI_SEM_RANK','approved_daily_pa':None,'approved_total_pa':None}
    if parsed['unparsed']:warnings.append('TEXTO_FORA_DA_GRAMATICA_EXAMINAR:'+repr(parsed['unparsed'][:2]))
    if source_kind=='HISTORICO':warnings.append('LEGADO_IMUTAVEL_DIAGNOSTICO_SEM_REPRECIFICAR')
    # A quote is a lower bound whenever some driver is unspecified; E3 never binds canon.
    incomplete=bool(warnings or any(a['kind'] in ('PENDENTE',) or (a['rank'] is None and a['kind']!='NUMERICO_SEM_HABILIDADE_INDEPENDENTE') for a in abilities) or ri is None)
    pa['known_lower_bound_day']=pa.get('day') if ri else None
    pa['mathematical_completeness']='INCOMPLETA_OU_E3' if incomplete else 'CALCULO_FECHADO_SOMENTE_EM_TEST'
    pa['production_promotion']='HOLD_NAC_NORM_PASS'
    # If no abilities, stats-only can be computed only if RI stated.
    return {'name':parsed['name'],'item_rank':ri,'item_rank_status':rank_state,'numeric_components':numeric,'numeric_pa_day':total_num,'abilities':abilities,'costs':pa,'warnings':warnings,'ready_for_master_preview':True,'can_publish':False,'can_write_notion':False,'classification_independent_of_cost':True,'source_kind':source_kind,'next_action':'APROVACAO_MESTRE_E_GATES_NAC' if ri and all(a['rank'] for a in abilities) else 'COMPLEMENTAR_EVIDENCIA_MECANICA_OU_RI'}


def as_ficha(r:dict)->str:
    title=r['name'];pa=r['costs'];parts=[f'# {title} — FICHA PREVIEW MESTRE / TEST',f'**Classificação do item:** {r["item_rank"] or "PENDENTE"} ({r["item_rank_status"]})',f'**Bônus diretos:** {json.dumps(r["numeric_components"],ensure_ascii=False)}; tarifa identificada {r["numeric_pa_day"]} PA/dia.','', '## Habilidades propostas']
    if not r['abilities']:parts.append('Nenhuma habilidade funcional identificada.')
    for a in r['abilities']:
        parts.extend([f'- **{a["name"]}** — {a["kind"]}; RE {a["rank"] or "PENDENTE"} ({a["rank_evidence"]}); diário: {a["cost_pa_day"] if a["cost_pa_day"] is not None else "PENDENTE"}; por uso: {a["cost_pa_use"] if a["cost_pa_use"] is not None else "PENDENTE"}; usos simulados: {a["uses"]}.',f'  - Mecânica recebida: {a["text"]}',f'  - Referências/ressalvas: {a.get("rank_reason", "; ".join(a["notes"]))}.'])
        if a.get('study_r22'):parts.append(f'  - R22 anterior: faixa {a["study_r22"]["re_faixa_preliminar"]} (E3, NÃO CONFIRMADO); {a["study_r22"]["fonte"]}')
    parts.extend(['','## Consumo energético prospectivo',f'- Piso item: {pa.get("floor") if pa.get("floor") is not None else "PENDENTE"} PA/dia.',f'- Parcela diária identificada: {pa.get("day_effects") if pa.get("day_effects") is not None else "PENDENTE"} PA/dia.',f'- **Prévia diária condicional:** {pa.get("day") if pa.get("day") is not None else "PENDENTE"} PA/dia.',f'- Ativações no cenário: {pa.get("activations") if pa.get("activations") is not None else "PENDENTE"} PA.',f'- **Prévia total no cenário:** {pa.get("total") if pa.get("total") is not None else "PENDENTE"} PA.',f'- Estado: {pa["quote_state"]}; completude: {pa.get("mathematical_completeness")}; não é valor oficial.',f'- Pendências: {"; ".join(r["warnings"]) if r["warnings"] else "sem alertas mecânicos locais; validação oficial ainda exigida"}.',f'- Origem Atlas: {ATLAS_URL}',f'- Fonte DMG: {DMG_URL}','','**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**'])
    return '\n'.join(parts)+'\n'

if __name__=='__main__':
    import sys
    if len(sys.argv)>1:
        raw=Path(sys.argv[1]).read_text('utf-8') if Path(sys.argv[1]).exists() else ' '.join(sys.argv[1:])
    else:raw=sys.stdin.read()
    out=analyze_item(raw)
    print(as_ficha(out))
