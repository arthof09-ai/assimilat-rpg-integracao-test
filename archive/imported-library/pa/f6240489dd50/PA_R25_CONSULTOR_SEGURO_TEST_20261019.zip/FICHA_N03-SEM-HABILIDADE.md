# Manoplas do Artífice — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Prata (RN_ITEM_DECLARADO_PARA_DESIGN)
**Bônus diretos:** {"FOR": 2, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 3, "deslocamento_m": 0, "ca_magica": 1}; tarifa identificada 14 PA/dia.

## Habilidades propostas
Nenhuma habilidade funcional identificada.

## Consumo energético prospectivo
- Piso item: 11 PA/dia.
- Parcela diária identificada: 14 PA/dia.
- **Prévia diária condicional:** 14 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 14 PA.
- Estado: PREVIA_VALIDAR_NAC; completude: CALCULO_FECHADO_SOMENTE_EM_TEST; não é valor oficial.
- Pendências: sem alertas mecânicos locais; validação oficial ainda exigida.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
