# Talismã Solar — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Ouro (RI_PROVISORIO_POR_EFEITO_DOMINANTE_E3)
**Bônus diretos:** {"FOR": 0, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 0, "ca_magica": 0}; tarifa identificada 0 PA/dia.

## Habilidades propostas
- **Feixe** — ATIVA; RE Ouro (E3_PROPOSTO); diário: 12; por uso: 14; usos simulados: 0.
  - Mecânica recebida: Causa 8d10 de dano a um único alvo. 500 PA para ativar.
  - Referências/ressalvas: DME 44; candidato por banda oficial DMG para alvo único, Ação Padrão, sem bypass. Necessita revisão das condições..

## Consumo energético prospectivo
- Piso item: 21 PA/dia.
- Parcela diária identificada: 12 PA/dia.
- **Prévia diária condicional:** 21 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 21 PA.
- Estado: SIMULACAO_CONDICIONAL; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: Feixe: HIPOTESE_E3.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
