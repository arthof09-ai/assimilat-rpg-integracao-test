"""R22 TEST: ranking admissibility and PA calculation; does not infer ranks from money or PA."""
from dataclasses import dataclass
from math import floor
from typing import Optional

RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário')
BASE={'Bronze':6,'Prata':12,'Ouro':24,'Ouro Negro':35,'Lendário':50}
FLOOR={'Bronze':8,'Prata':11,'Ouro':21,'Ouro Negro':35,'Lendário':90}

@dataclass(frozen=True)
class Effect:
    identifier: str
    rank: str
    kind: str  # PASSIVA | ATIVA
    evidence: str  # E0 | E1 | E2 | E3
    uses: int = 0
    is_numeric_only: bool = False

class GateError(ValueError):
    pass

def classify_readiness(*, effect_written: bool, source: str, mechanics_fields: dict,
                       evidence: str, comparators: dict,
                       rank_of_item: str = '', activation_pa_legacy: Optional[int]=None):
    """Puts effects in an evidence state; deliberately *does not return a rank*."""
    if not effect_written or not source.startswith('https://app.notion.com/p/'):
        return 'PENDENTE_FONTE_OU_MECANICA'
    if evidence not in ('E0','E1','E2','E3'):
        return 'PENDENTE_SELO'
    # Economic and item-rank parameters are intentionally not read for rank determination.
    required=('trigger','target','duration','outcome','limits')
    if any(not mechanics_fields.get(k) for k in required):
        return 'RE_PROVISORIO_GAPS_MECANICOS'
    if sum(bool(comparators.get(k)) for k in ('system','living','family'))<2:
        return 'RE_PROVISORIO_COMPARADORES_INSUFICIENTES'
    if evidence=='E3':
        return 'RE_CANDIDATO_E3_REVISAO'
    return 'RE_ADMISSIVEL_PARA_AUDITORIA'

def tariff(rank:str):
    if rank not in BASE: raise GateError('rank não reconhecido')
    return {'passiva_por_dia':BASE[rank], 'ativa_por_dia':floor(BASE[rank]/2),
            'ativa_por_uso':floor(BASE[rank]*.6)}

def estimate_new_item(item_rank:str, effects:list[Effect], numeric_pa:int=0):
    if item_rank not in FLOOR:raise GateError('rank do item inválido')
    if numeric_pa<0:raise GateError('tarifa numérica negativa')
    ids=[e.identifier for e in effects]
    if len(ids)!=len(set(ids)):raise GateError('mesma habilidade contada duas vezes')
    day=numeric_pa; activations=0; warnings=[]
    for e in effects:
        if e.rank not in BASE:raise GateError('habilidade sem rank para cálculo')
        if e.kind not in ('PASSIVA','ATIVA'):raise GateError('gatilho escolha não resolvido em PASSIVA/ATIVA')
        if e.uses<0:raise GateError('usos negativos')
        if e.kind=='PASSIVA' and e.uses!=0:raise GateError('passiva com usos')
        if e.evidence not in ('E0','E1','E2','E3'):raise GateError('sem selo de evidência')
        if e.evidence=='E3':warnings.append(e.identifier+': rank ainda E3')
        if e.is_numeric_only:
            # Avoid charging a decorative name as a new skill when same modifier is already numeric.
            warnings.append(e.identifier+': conferir duplicidade com bônus numéricos')
        day+=BASE[e.rank] if e.kind=='PASSIVA' else floor(BASE[e.rank]/2)
        activations+= e.uses*floor(BASE[e.rank]*.6) if e.kind=='ATIVA' else 0
    minimum=FLOOR[item_rank]
    return {'item_rank':item_rank,'day_effects':day,'floor':minimum,'day':max(day,minimum),
            'activations':activations,'total':max(day,minimum)+activations,'warnings':warnings,
            'production_status':'TEST_ONLY_NOT_NOTION'}
