import csv,unittest,collections
from rank_guard_r22 import RANKS,BASE,FLOOR,Effect,tariff,estimate_new_item,classify_readiness,GateError
from pathlib import Path
D=Path(__file__).parent

def read_file(fn):
 with (D/fn).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=';'))
class R22(unittest.TestCase):
 def test_census_counts(self):
  a=read_file('HABILIDADES_ITENS_R22.csv');b=read_file('BENCHMARKS_TECNICAS_28_R22.csv');c=read_file('REGISTRO_ITENS_94_R22.csv')
  self.assertEqual(len(a),99);self.assertEqual(len(b),28);self.assertEqual(len(c),94)
  self.assertEqual(len({x['uuid'] for x in a}),48)
  self.assertEqual(collections.Counter(x['modalidade'] for x in a),{'PASSIVA':67,'ATIVA':28,'GATILHO_ESCOLHA':4})
  self.assertEqual(sum(bool(x['pa_ativacao_historico']) for x in a),16)
  self.assertEqual(collections.Counter(x['habilidade'] for x in b).most_common(1)[0][1],1)
  self.assertEqual(collections.Counter(x['rank_documental'] for x in b),{'Bronze':2,'Prata':6,'Ouro':12,'Ouro Negro':5,'Lendário':1,'Sem classificação':2})
  self.assertTrue(all(x['mecanica_legivel']=='PENDENTE_IMAGEM' for x in b))
  self.assertTrue(all(x['fonte'].startswith('https://app.notion.com/p/') for x in a+b+c))
  self.assertFalse(any(x['selo_RE'].startswith('E0') for x in a))
  self.assertEqual(len({(x['uuid'],x['habilidade']) for x in a}),len(a))
 def test_r21_activations_unchanged(self):
  source=Path('/mnt/data/pa_r21_work/ATIVACOES_HISTORICAS_R21.csv')
  with source.open(encoding='utf-8-sig',newline='') as f:
   previous=list(csv.DictReader(f))
  current=read_file('HABILIDADES_ITENS_R22.csv')
  keyed={(x['uuid'],x['habilidade']):x for x in current}
  self.assertEqual(len(previous),16)
  for p in previous:
   row=keyed[(p['item_uuid'],p['ability'])]
   self.assertEqual(int(row['pa_ativacao_historico']),int(p['activation_pa']))
   self.assertEqual(row['fonte'],p['source_link'])
 def test_tariff(self):
  for name,values in {'Bronze':(6,3,3),'Prata':(12,6,7),'Ouro':(24,12,14),'Ouro Negro':(35,17,21),'Lendário':(50,25,30)}.items():
   self.assertEqual(tuple(tariff(name).values()),values)
 def test_scenarios(self):
  a=estimate_new_item('Ouro Negro',[Effect('pB','Bronze','PASSIVA','E3'),Effect('aO','Ouro','ATIVA','E3',1),Effect('aON','Ouro Negro','ATIVA','E3',1)])
  self.assertEqual((a['day_effects'],a['day'],a['activations'],a['total']),(35,35,35,70))
  z=estimate_new_item('Lendário',[],numeric_pa=0)
  self.assertEqual((z['day'],z['total']),(90,90))
  z=estimate_new_item('Bronze',[Effect('aB','Bronze','ATIVA','E2',3)])
  self.assertEqual((z['day'],z['activations'],z['total']),(8,9,17))
 def test_gate(self):
  fields={k:'x' for k in ['trigger','target','duration','outcome','limits']}
  c={'system':'x','living':'y','family':'z'}
  x=classify_readiness(effect_written=True,source='https://app.notion.com/p/abcdef',mechanics_fields=fields,evidence='E2',comparators=c,rank_of_item='Lendário',activation_pa_legacy=60)
  y=classify_readiness(effect_written=True,source='https://app.notion.com/p/abcdef',mechanics_fields=fields,evidence='E2',comparators=c,rank_of_item='Bronze',activation_pa_legacy=4)
  self.assertEqual(x,y) # blind to price, energy, item rank
  self.assertEqual(classify_readiness(effect_written=True,source='https://app.notion.com/p/abcdef',mechanics_fields={'trigger':'x'},evidence='E2',comparators=c),'RE_PROVISORIO_GAPS_MECANICOS')
  self.assertEqual(classify_readiness(effect_written=True,source='https://app.notion.com/p/abcdef',mechanics_fields=fields,evidence='E3',comparators=c),'RE_CANDIDATO_E3_REVISAO')
 def test_blocks(self):
  bad=[[Effect('dup','Prata','PASSIVA','E0'),Effect('dup','Prata','ATIVA','E0')],[Effect('x','Ouro','GATILHO_ESCOLHA','E0')],[Effect('x','Ouro','PASSIVA','E0',1)]]
  for test in bad:
   with self.assertRaises(GateError):estimate_new_item('Ouro',test)
  with self.assertRaises(GateError):estimate_new_item('Ouro',[], -1)
if __name__=='__main__':unittest.main(verbosity=2)
