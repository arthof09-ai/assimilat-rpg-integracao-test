# Botas da Trilha Serena — PREVIEW MESTRE R25 / TEST
**Estado:** PREVIA_CONDICIONAL · **Produção:** HOLD
**Rank do item:** Ouro (DECLARADO_PELO_USUARIO_NAO_COMPROVA_RANK_CANONICO)

## Habilidades e tarifas por componente
- **Passos sem Pegadas** — PASSIVA; RE candidato **Prata**; estado **VALIDACAO_DE_DESIGN**; PA/dia **12**; PA/ativação **0**.
  - Texto recebido: Enquanto equipadas, não deixam rastros em terreno natural; sem ocultar som.
  - Geometria: INDEFINIDA; alcance=None (ALCANCE_PENDENTE); raio=None (ALCANCE_PENDENTE); extensao=None (ALCANCE_PENDENTE); origem=None (ALCANCE_PENDENTE)
  - Ressalvas espaciais: MULTIPLOS_ALVOS_NAO_DETERMINAM_GEOMETRIA
- **Salto Curto** — ATIVA; RE candidato **Bronze**; estado **VALIDACAO_DE_DESIGN**; PA/dia **3**; PA/ativação **3**.
  - Texto recebido: Com uma ação de movimento, salta 4,5 metros uma vez por turno.
  - Geometria: INDEFINIDA; alcance=None (ALCANCE_PENDENTE); raio=None (ALCANCE_PENDENTE); extensao=None (ALCANCE_PENDENTE); origem=None (ALCANCE_PENDENTE)
  - Ressalvas espaciais: MULTIPLOS_ALVOS_NAO_DETERMINAM_GEOMETRIA

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: 13 PA/dia
- Subtotal parcial conhecido (não representa custo final): 13 PA/dia
- Piso do RI candidato: 21 PA/dia
- **Diário simulado:** 28 PA/dia
- **Usos simulados:** 6 PA
- **Total no cenário:** 34 PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: SIMULACAO_E3_CONDICIONAL.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": null, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- Nenhuma lacuna local impeditiva; ranks E3 e produção seguem sem validação independente.

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
