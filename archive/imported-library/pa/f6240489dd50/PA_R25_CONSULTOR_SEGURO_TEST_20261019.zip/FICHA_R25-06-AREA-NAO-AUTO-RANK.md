# Cetro — PREVIEW MESTRE R25 / TEST
**Estado:** HOLD · **Produção:** HOLD
**Rank do item:** Ouro (RI_INFERIDO_E3)

## Habilidades e tarifas por componente
- **Explosão de Chamas** — ATIVA; RE candidato **Ouro**; estado **HOLD_RE_CLASSIFICAR_PELO_ATLAS**; PA/dia **PENDENTE**; PA/ativação **PENDENTE**.
  - Texto recebido: Com uma ação padrão, causa 8d10 de dano de fogo numa área circular de raio 3 metros.
  - Pendências específicas: DME_PADRAO_DMGRANK_INVALIDO_PARA_AREA_OU_LINHA; DME_PADRAO_SEM_ALVO_UNICO_CONFIRMADO
  - Geometria: CIRCULAR; alcance=9.0 (ALCANCE_REGRA_GERAL_MESTRE); raio=3.0 (ALCANCE_EXPLÍCITO); extensao=None (ALCANCE_PENDENTE); origem=ponto_escolhido_pelo_conjurador (ALCANCE_REGRA_GERAL_MESTRE)
  - Tarifas sob RANKS HIPOTÉTICOS (não usar como preço fechado): {"Ouro": {"PA_dia": 12, "PA_uso": 14}, "Ouro Negro": {"PA_dia": 17, "PA_uso": 21}}

## PA de novos itens (não altera custos históricos)
- Bônus numéricos reconhecidos: 0 PA/dia
- Subtotal parcial conhecido (não representa custo final): 0 PA/dia
- Piso do RI candidato: 21 PA/dia
- **Diário simulado:** PENDENTE PA/dia
- **Usos simulados:** PENDENTE PA
- **Total no cenário:** PENDENTE PA
- Valor diário homologado: **NÃO EXISTE**. Estado do cálculo: HOLD_CUSTO_TOTAL_INDETERMINADO.
- Custos já escritos no texto (apenas contexto histórico/declaração): {"pa_dia_textual": null, "pa_por_uso_textual": null, "pa_avulso_sem_gatilho": null}.

## Pendências e próxima ação
- Explosão de Chamas: DME_PADRAO_DMGRANK_INVALIDO_PARA_AREA_OU_LINHA
- Explosão de Chamas: DME_PADRAO_SEM_ALVO_UNICO_CONFIRMADO

**Fonte de poder:** https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
**Fonte de dano:** https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**SEM ALTERAÇÃO EM CANÔNE, NOTION, PARTY OU CRAFT PRODUTIVO.**
