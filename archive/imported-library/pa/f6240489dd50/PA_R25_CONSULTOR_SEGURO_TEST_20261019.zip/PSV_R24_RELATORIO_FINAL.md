# PSV R24 — Relatório final de fechamento da fronteira conversacional de PA
**DATA:** 19/10/2026 · **Workstream:** PA de Itens Mágicos, conectado à OP-ARQ-RIN-REC-01 · **MESTRE-SIDE** · **R22/R23 intactos**

## 1. Pergunta e resposta
**Pergunta:** completar classificação desconhecida automática, cálculo sem rank pré-fornecido e conversa `descrição → classificação → custo PA → ficha para aprovação`.

**Resposta:** a cadeia TEST está **funcional e executada ponta a ponta**. Sua automática operação determinística não é universal nem suficientemente precisa para declarar autonomia canônica: 32/99 hipóteses E3 e 67/99 HOLD documentados, conforme dados R22. Portanto **P0 TEST de prévia funcional é entregue; conclusão oficial e rank confiável para qualquer habilidade são PENDENTES**. Declarar 100% seria falso.

## 2. Métodos, autoridades e normas
- Recuperação de código original de `baseline_r22/rank_guard_r22.py` e `alcance_mestre_r23.py`, ambos copiados sem alteração; testes R22/R23 repetidos.
- Notion Mestre reaberto em leitura: Atlas, DMG-RANK v1.1, Sistema Magia, OP CRAFT, Braçadeira do Pulmão de Ferro (Ouro), Inscrição Aurora (Lendário), Armadura de Zephyr, Sombra Sussurrante e comparadores de personagens Dong Goui (P2), Gorrok (O1 conforme Atlas), Pan Tueimor (ON1) e Eketerina Lendária. Fontes usadas com ressalva de separar poder do usuário/itens.
- A regra de alcance do Mestre aplicada conforme R23 para alvo único 9m, cone ofensivo 4,5m, círculo de raio 6m e centro até 9m, salvo especificação própria. Origem de cada campo rastreada, sem sobretaxa por alcance.
- Rank em duas camadas: RE da habilidade e RI do item não se confundem. DME ofensivo simples pode produzir RE *candidato* usando bandas vigentes do DMG; efeitos qualitativos e bypass sujeitos ao Atlas e a fontes; RE desconhecido => HOLD sem adivinhação.
- Produção e Notion sem writes; caráter experimental nunca recebe status oficial por repetição de testes.

## 3. Regras do Mestre reproduzidas

| Rank | Passiva PA/dia | Ativa PA/dia | Ativa PA/uso | Piso RI PA/dia |
|---|---:|---:|---:|---:|
| Bronze | 6 | 3 | 3 | 8 |
| Prata | 12 | 6 | 7 | 11 |
| Ouro | 24 | 12 | 14 | 21 |
| Ouro Negro | 35 | 17 | 21 | 35 |
| Lendário | 50 | 25 | 30 | 90 |

`PA_item/dia = MAX(piso(RI), custo_bônus_numéricos + Σ tarifa(RE,passiva/ativa))`; `PA_USOS = Σ( floor(0,6×BASE_RE) × usos )`; total por cenário = dia + usos. Independentemente da condição de ativação, contribuição ativa diária é metade truncada. Quando falta RE/RI ou existem efeitos não precificados, o cálculo é **condicional/incompleto**, nunca custo final oficial.

## 4. Execução real, verificações

- **12/12 descrições de demonstração** processadas, cada uma com ficha Markdown e JSON.
- **52/52 testes novos** unitários/integrados locais PASS.
- **40/40 testes R22/R23** reexecutados PASS (6 do gate R22 + 34 do R23).
- **99/99 observações R22 triadas**. Em 32 casos o algoritmo propôs um RE E3; em 67 fez HOLD. Nas 32 propostas, 21 situaram-se dentro das faixas E3 antigas e 11 fora. **Isto não é taxa de acerto**, pois os rótulos E3 prévios não são gabarito. Não afirmar que 99 correspondem a todo o universo de habilidades.
- **28 técnicas/pseudopergaminhos R22** possuem índice de ranks 26 E0 nominais/2 sem rank; mecânica em imagem ainda não toda materializada textualmente. As 94 páginas históricas não foram todas reinterpretadas aqui; registros existentes preservados.

## 5. Casos demonstrados

**D1 — Varinha da Chama Direta (novo, sem rank fornecido):** uma habilidade ativa de 8d10 de dano intrínseco médio 44, ação padrão, alvo único. R24 propõe RE Ouro E3 pelo centro da banda DMG; RI Ouro E3 por efeito dominante. Ativa 12 PA/dia; piso Ouro 21 PA/dia; 14 PA por uso. Dois usos => **21 + 28 = 49 PA**. Parcela não aprovada: RE/RI E3, condição de combate e fronteira.

**D2 — Botas da Trilha Serena (novo, RI Ouro declarado):** +2 DES = 10 PA/dia; +3m = 3 PA/dia; Passos sem Pegadas proposta RE Prata E3 =12 PA/dia; Salto Curto proposta RE Bronze E3 =3 PA/dia e 3 PA/uso. Parcela diária = 28; piso Ouro = 21; duas ativações = 6 => **34 PA no dia**. Ficha demonstrativa não é item existente.

**D3 — Manoplas do Artífice (novo, RI Prata declarado):** +2 FOR = 10 PA/dia, +3 em ataque = 3, +1 CA *magicamente comprovada* =1; nenhuma habilidade. Piso 11; **14 PA/dia**. Prova de no-skill.

**D4 — Cajado Orbital (novo):** apenas “prende inimigos num campo gravitacional”. Sem CD/duração/limites/geometria; RE e RI HOLD; valor final PA **PENDENTE**, com lacunas identificadas, não 0.

**D5 — Armadura de Zephyr (histórica):** ficha física reaberta; +15 DES, +25 ataque, +15m, +11 CA de armadura física e +50 dano de vento *por turno*; legado **90 PA/dia intocado**. Apenas os três componentes quantitativos tarifáveis conhecidos somam 115 PA/dia para uma hipotética nova criação. Não se somou a CA física nem se converteu +50/turno em 50 por golpe; não é recálculo oficial.

## 6. Diagnóstico de confiabilidade e P0

| Meta | Verificação | Estado |
|---|---|---|
| `Texto → efeitos/modalidade` | Gramática assistida, avisos em texto não segmentado, 52 testes | **TEST FUNCIONAL**; língua natural irrestrita não validada |
| `RE sem pré-informação do Mestre` | DMG/Atlas e comparadores; 99 triagens, 32 E3/67 HOLD | **PARCIAL**, rank universal confiável não demonstrado |
| `RI sem pré-informação` | Efeito dominante propõe RI E3, sinaliza conflitos | **TEST FUNCIONAL/PROVISÓRIO** |
| `RE/RI → tarifa e PA` | 52 novos + 40 regressões | **TEST FUNCIONAL** |
| `Prévia Mestre pronta para decisão` | 12 fichas de demonstração | **TEST FUNCIONAL** |
| `Sync Notion/Magia/CRAFT/Party` | nenhuma escrita/ACK/lease verificado | **HOLD/DEPENDÊNCIA EXTERNA** |
| `NAC-PASS produção` | ausência gate independente/registro/canônico | **HOLD** |

## 7. Descobertas adversariais e correções

1. Rank do item não define rank da habilidade, nem fonte de PA diz potência. Independência coberta em testes.
2. Dano 8d10 tem DME 44 e bandas **sobrepostas** Ouro/Ouro Negro; Ouro é E3 candidato por centralidade, não prova absoluta.
3. Ativas de baixo RE em item alto pagam tarifa própria; piso aplica-se ao RI do conjunto.
4. Falta de geometria real de um “campo gravitacional” não autoriza círculo; regra geral só quando geometria identificada.
5. Custo já calculado de bônus atributo não recebe cobrança extra por nome “passiva” de pura estatística. Proposta de interpretação do Mestre sobre duplo débito, não adendo normativo homologado.
6. Triggers sem decisão nem ação explícita têm modalidade PENDENTE, protegendo contra falsa tarifa.
7. Itens antigos com custos explícitos nunca são reprecificados nem gravados.
8. O mecanismo de interpretação por padrões tem **limite de cobertura** e não substitui discernimento do Comestre, testemunho de fonte e gate humano.

## 8. Pendências residuais reais e retomada

- **P0-RANK:** construir/validar benchmarks mecânicos de referências E0, ler imagens de técnicas, reconciliar 11 divergências E3 e 67 HOLD, confrontar nos 14 eixos (não só dano), auditar itens e seus REs independentemente. Uma hipótese E3 bem fundamentada ainda precisa de aceite quando existir risco canônico.
- **P0-FLOW-NATIVE:** incorporar ou contratar a API R24 dentro do CRAFT/ChatGPT móvel (hoje executável apenas como script, a conversa do Comestre pode executar sua lógica mas não existe plugin CRAFT integrado). Não reivindicar roteamento automático futuro sem atualização de fluxo.
- **P0-NORM:** registrar decisões de tarifas e alcance na autoridade competente com governança NAC-NORM-01; writer/lease não herdado, zero Notion writes nesta sessão. Teste proporcional NAC-PASS local PASS; promoção final HOLD.
- **P0-CONT:** check de anti-duplicata, histórico e separação Mestre↔Party na integração. R22/23 ZIP preservados; não recriar novo laboratório.

**Veredito:** `FECHAMENTO TEST DA CAPACIDADE PONTA-A-PONTA = VERIFICADO; CLASSIFICADOR UNIVERSAL CONFIÁVEL = NÃO COMPROVADO; INTEGRAÇÃO/CANONIZAÇÃO = HOLD; P0 GLOBAL = NÃO ENCERRADO.` Nenhuma promessa de trabalho em segundo plano.
