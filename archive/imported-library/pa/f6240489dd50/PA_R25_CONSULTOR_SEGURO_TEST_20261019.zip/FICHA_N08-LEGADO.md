# Bota Caminho Veloz — FICHA PREVIEW MESTRE / TEST
**Classificação do item:** Ouro (RN_ITEM_DECLARADO_PARA_DESIGN)
**Bônus diretos:** {"FOR": 0, "DES": 0, "CON": 0, "INT": 0, "SAB": 0, "CAR": 0, "dano": 0, "ataque": 0, "deslocamento_m": 6, "ca_magica": 0}; tarifa identificada 6 PA/dia.

## Habilidades propostas
- **Velocidade Sobrenatural** — ATIVA; RE Prata (E3_PROPOSTO); diário: 6; por uso: 7; usos simulados: 0.
  - Mecânica recebida: Ao ativar, ganha +8m de deslocamento por 1 turno, 5 PA por ativação histórica.
  - Referências/ressalvas: Mobilidade quantitativa, duração e economia de ação decidem; é HIPÓTESE ancorada no Atlas, não regra de corte..
  - R22 anterior: faixa Prata–Ouro (E3, NÃO CONFIRMADO); https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c

## Consumo energético prospectivo
- Piso item: 21 PA/dia.
- Parcela diária identificada: 12 PA/dia.
- **Prévia diária condicional:** 21 PA/dia.
- Ativações no cenário: 0 PA.
- **Prévia total no cenário:** 21 PA.
- Estado: SIMULACAO_CONDICIONAL; completude: INCOMPLETA_OU_E3; não é valor oficial.
- Pendências: Velocidade Sobrenatural: HIPOTESE_E3; LEGADO_IMUTAVEL_DIAGNOSTICO_SEM_REPRECIFICAR.
- Origem Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Fonte DMG: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

**PRODUÇÃO: HOLD. Sem gravação no Notion, Party ou outro workspace.**
