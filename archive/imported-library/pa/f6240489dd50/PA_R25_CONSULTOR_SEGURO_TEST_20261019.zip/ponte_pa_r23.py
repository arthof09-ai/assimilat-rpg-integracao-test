"""Ponte experimental não-invasiva R23: aplica alcance interpretativo, reusa tarifas R22.
Não classifica RE por distância, não reescreve o item e não modifica o motor R22.
"""
from __future__ import annotations
from dataclasses import dataclass
from alcance_mestre_r23 import Especificacao, aplicar_regra_mestre
from baseline_r22.rank_guard_r22 import Effect,estimate_new_item, GateError

@dataclass(frozen=True)
class EfeitoComAlcance:
    efeito: Effect
    geometria: Especificacao

def simular_novo_item(item_rank: str, efeitos: list[EfeitoComAlcance], numeric_pa: int=0):
    if any(e.efeito.identifier != e.geometria.id for e in efeitos):
        raise GateError('id do RE/efeito diverge do ID geometrico: vinculo ambíguo')
    if len({e.geometria.id for e in efeitos}) != len(efeitos):
        raise GateError('efeito duplicado')
    dim=[aplicar_regra_mestre(e.geometria) for e in efeitos]
    custos=estimate_new_item(item_rank,[e.efeito for e in efeitos],numeric_pa)
    # ZERO multiplicador de PA por alcance: classificador RE é independente e upstream.
    if any(d['delta_pa_por_geometria'] for d in dim):
        raise AssertionError('proibido custo extra de alcance sem regra competente')
    espacial=[]
    for d in dim:
        if d['forma']=='CONE' and 'ABERTURA_ANGULAR_NAO_FIXADA_PELA_DIRETRIZ' in d['ressalvas']:
            tipo='TARGET_RESOLUTION_HOLD_ANGULO'
        elif d['forma']=='CIRCULAR' and d['alcance']['valor'] is not None and d['raio']['valor'] is not None:
            tipo='VALIDAR_CENTRO_ALVOS_POSICOES_EOL'
        elif d['forma']=='ALVO_UNICO' and d['alcance']['valor'] is not None:
            tipo='VALIDAR_DISTANCIA_UNICA'
        elif d['forma'] in ('INDEFINIDA','LINHA','OUTRA'):
            tipo='GEOMETRIA_INCOMPLETA_OU_ESPECIAL'
        else:
            tipo='SEM_FALLBACK_RELEVANTE'
        espacial.append({'id':d['id'],'gate_vlab':tipo})
    return {'pa_r22':custos,'geometrias':dim,'gates_vlab':espacial,
            'delta_pa_do_alcance_mestre':0,'state':'TEST_ONLY','canonical_write':False,
            'recalculo_de_fichas_antigas':False}
