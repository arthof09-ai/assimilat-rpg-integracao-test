# PSV — PA R20 / DECISÃO DO MESTRE E ESTATÍSTICA POR RANK

**AS-OF:** 19/10/2026 · **MESTRE-SIDE** · **Estado:** TEST LOCAL · **Produção:** HOLD · **CRAFT F5:** RED · **C19-021:** UNKNOWN-EFFECT.
**Operação existente:** OP-ARQ-RIN-REC-01 (PA como subsistema). **Identidade / writer / lease / epoch / fencing:** não reivindicados.
**Baseline imutável:** R09 (94 registros), R06 (94 auditorias). Nenhuma nova operação, receita, produto ou ficha oficial criada.

## 1. DECISÃO EXPRESSA DO MESTRE — CUSTOS NOVOS
- Bronze **8 PA/dia**; Prata **11 PA/dia**; Ouro **21 PA/dia**; Ouro Negro **35 PA/dia**; Lendário **90 PA/dia**.
- O piso se aplica a TODO novo item classificado com efeito mágico, **inclusive itens sem poder passivo e apenas com habilidades ativáveis**.
- Regra conceitual: `PA_dia_novo = max(custo_diario_efeitos_reconhecidos, piso_rank)`. Ativação e manutenção continuam modalidades separadas; não há dispensa automática do piso nem dupla cobrança da mesma parcela.
- O Atlas PR-ECO-01 classifica o poder antes da cotação de PA. Não derivar rank de custo de PA; FIP é interna, item não recebe estrelas públicas.
- Itens históricos **não serão reprecificados nem corrigidos**. A decisão do Mestre é vinculante para o trabalho experimental; publicação normativa física no Notion **ainda não realizada**.
- Os cinco pisos coincidem com as MEDIANAS observadas da coorte R09, e NÃO com suas médias aritméticas. Essa distinção é mantida documentalmente.

## 2. DENOMINADOR E MEDIANAS HISTÓRICAS
| Rank | N | Histórico mín. | Histórico média | Histórico mediana | Histórico máx. | Antigos abaixo do novo piso |
|---|---:|---:|---:|---:|---:|---:|
| Bronze | 8 | 4 | 8.38 | 8 | 12 | 4 |
| Prata | 30 | 6 | 11.67 | 11 | 22 | 13 |
| Ouro | 35 | 8 | 22.09 | 21 | 65 | 17 |
| Ouro Negro | 13 | 14 | 42.69 | 35 | 112 | 6 |
| Lendário | 5 | 64 | 241.80 | 90 | 600 | 2 |

**Escopo:** 94 registros: 5 classificações E0 documentais, 86 ranks estimados E3, 3 sem rank. Todas as médias misturam famílias e tipos de efeito; não representam todo o catálogo. Os antigos abaixo dos pisos permanecem inalterados.

## 3. MATRIZ DOS BÔNUS NUMÉRICOS POR RANK
| Rank | Eixo | N independente | Mínimo observado | Média observada | Máximo observado |
|---|---|---:|---:|---:|---:|
| Bronze | Bônus de atributos por item (pontos) | 0 | — | — | — |
| Bronze | Dano fixo adicional condicionado/por acerto | 0 | — | — | — |
| Bronze | Aumento numérico de CA (origem separada) | 2 | 2 | 2 | 2 |
| Bronze | Bônus de teste de ataque | 1 | 3 | 3 | 3 |
| Bronze | Deslocamento adicional (m) | 0 | — | — | — |
| Prata | Bônus de atributos por item (pontos) | 2 | 2 | 2.5 | 3 |
| Prata | Dano fixo adicional condicionado/por acerto | 5 | 1 | 6.4 | 12 |
| Prata | Aumento numérico de CA (origem separada) | 4 | 2 | 2.25 | 3 |
| Prata | Bônus de teste de ataque | 2 | 3 | 3 | 3 |
| Prata | Deslocamento adicional (m) | 1 | 4 | 4 | 4 |
| Ouro | Bônus de atributos por item (pontos) | 5 | 2 | 5.4 | 10 |
| Ouro | Dano fixo adicional condicionado/por acerto | 4 | 2 | 6.5 | 20 |
| Ouro | Aumento numérico de CA (origem separada) | 1 | 2 | 2 | 2 |
| Ouro | Bônus de teste de ataque | 3 | 2 | 2.6667 | 4 |
| Ouro | Deslocamento adicional (m) | 2 | 4 | 5 | 6 |
| Ouro Negro | Bônus de atributos por item (pontos) | 1 | 15 | 15 | 15 |
| Ouro Negro | Dano fixo adicional condicionado/por acerto | 4 | 8 | 19.25 | 30 |
| Ouro Negro | Aumento numérico de CA (origem separada) | 1 | 6 | 6 | 6 |
| Ouro Negro | Bônus de teste de ataque | 2 | 3 | 3 | 3 |
| Ouro Negro | Deslocamento adicional (m) | 0 | — | — | — |
| Lendário | Bônus de atributos por item (pontos) | 3 | 15 | 31.6667 | 60 |
| Lendário | Dano fixo adicional condicionado/por acerto | 1 | 10 | 10 | 10 |
| Lendário | Aumento numérico de CA (origem separada) | 1 | 11 | 11 | 11 |
| Lendário | Bônus de teste de ataque | 2 | 25 | 50 | 75 |
| Lendário | Deslocamento adicional (m) | 2 | 10 | 12.5 | 15 |

**Interpretação:** ausência amostral não vale zero. N pequenos (1–2) não validam curva universal. Min/max são fatos observados nesta coorte, não autorização de cap ou piso mecânico por rank. Ranks em grande parte E3 necessitam conferência Atlas antes de oficialização.
**Condicionalidade:** a estatística de dano por acerto inclui amostras condicionais (crítico, alvo, arma/magia/ramo); ler `OBSERVACOES_BONUS_R20.csv` antes de aplicar benchmark. Zephyr +50 dano/turno fica fora desse eixo; dano intrínseco de arma não é equivalente a bônus; FIP/RI não decorrem de PA. CA física/estrutural nunca recebe automaticamente tarifa de CA comprovadamente mágica.
**Dependência:** IMPERIAL e Veste Dragão Ascendente possuem texto possivelmente duplicado; IMPERIAL foi retirado da análise de bônus independentes, sem remoção do corpus histórico de PA. Colar cadente +2 SAB usual / +4 SOB estrelas é cenário alternativo, não duas amostras somadas.

## 4. FUNCIONALIDADE DEMONSTRADA — R20 TEST
- `pa_r20_floor_atlas.py` aplica pisos por rank sem modificar módulos R05/R10/R11; é uma extensão experimental desacoplada.
- Caso Bronze `+1 DES`: custo componente 5, piso 8, quote 8 PA/dia.
- Caso Ouro `+3 atributo` e ativação `6 PA` duas vezes: subtotal 15, piso 21, dia 21 + 12 ativações = 33 PA no cenário.
- Caso Prata só ativação 12 PA/uso: piso 11 PA/dia + 12 PA por uma ativação = 23 PA no cenário.
- Caso Lendário somente ativável, custo ativação ausente: piso 90 PA/dia continua conhecido; custo de uso fica **INDETERMINADO**, não zero.
- Caso efeitos adicionais desconhecidos: motor fornece piso como LIMITE INFERIOR, nunca total fechado.
- `PA_R20_PISOS_ATLAS_EIXOS_TEST_20261019.xlsx`: cinco abas (Regras, Bônus por rank, Observações, Corpus 94, Simulador novo), fórmulas de cenário, fontes e comparações históricas.

## 5. TESTE / RASTREABILIDADE / PASS
- R06/R09 ZIP originals validados por SHA256 esperado; linhas 94/94 reconciliadas por UUID.
- 27/27 testes locais R20 passaram; relatório em `TESTES_R20.log`; 49 observações individuais, 25 grupos rank×eixo (inclusive vazios explicitamente).
- Zero escrita Notion, Party, espelho ou receitas oficiais; alteração oficial do objetivo/norma de PA no Notion **PENDENTE** de rota de autorização/reserva/registro NAC-CONT-03 e gate normativo correspondente.
- **NAC-PASS proporcional:** PASS local (código, estatística e planilha); HOLD para publicação normativa, homologação de métricas de bônus, atribuição E3 canônica e integração nativa CRAFT.

## 6. NEXT / NÃO REPETIR
1. Depurar o grau de confiança de cada RI E3 pelo Atlas canônico com dois/três comparadores, sem usar PA como insumo da classificação; registrar classificação semicanônica sem alterar a ficha histórica.
2. Ampliar a amostra efetiva por eixo (especialmente dano/CA/atributo Bronze e CA Ouro/ON/Lendário); conservar família, gatilho, disponibilidade, duração, per hit/per turn, stack e fonte.
3. Recalcular médias e percentis em subcoortes comparáveis; comparar monotonicidade entre ranks e testar generalização com holdout de fontes Mestre independentes.
4. Validar se pisos por rank devem receber modificadores dependentes do perfil ativo e de quantidade de usos, sem revogar a obrigação diária recém decidida.
5. Sob writer/documentação competente, consolidar formalmente a decisão de pisos e escopo prospectivo no lugar canônico existente; integração ao CRAFT somente com ACK e gate.
**FIRST-PENDING:** canonização documental autorizada; ampliar evidência e normalizar modalidades para evitar falsa precisão em bônus por rank. **NO-REPEAT:** R01–R19 baselines, fichas/custos antigos, CRAFT/F5 receitas.
