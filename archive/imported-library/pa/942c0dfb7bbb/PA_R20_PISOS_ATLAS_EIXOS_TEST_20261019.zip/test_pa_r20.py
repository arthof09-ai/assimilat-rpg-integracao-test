import unittest
from pathlib import Path
from pa_r20_floor_atlas import quote_new_item,run,FLOORS
ROOT=Path(__file__).resolve().parent
R09=ROOT/'PA_P0_R09_CORRIGENDA_TEST_20261018.zip'
R06=ROOT/'PA_P0_AUDITORIA_94_RANKS_CORRECOES_TEST_20261017.zip'
class TestR20(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.data=run(R09,R06)
 def test_floors_master(self):self.assertEqual(list(FLOORS.values()),[8,11,21,35,90])
 def test_unactivated_still_floor(self):self.assertEqual(quote_new_item(rank='Lendário')['daily_total_pa_day'],90)
 def test_bronze_1des_floor(self):self.assertEqual(quote_new_item(rank='Bronze',attributes=1)['daily_total_pa_day'],8)
 def test_bronze_above_floor(self):self.assertEqual(quote_new_item(rank='Bronze',attributes=4)['daily_total_pa_day'],20)
 def test_gold_floor_activation(self):
  q=quote_new_item(rank='Ouro',attributes=3,activation_per_use=6,uses=2)
  self.assertEqual((q['daily_total_pa_day'],q['daily_plus_activations_today_pa']),(21,33))
 def test_active_only_still_floor(self):
  q=quote_new_item(rank='Prata',activation_per_use=12,uses=1)
  self.assertEqual((q['daily_total_pa_day'],q['daily_plus_activations_today_pa']),(11,23))
 def test_unknown_activation_not_zero(self):
  q=quote_new_item(rank='Prata',uses=1)
  self.assertIsNone(q['activation_cost_today_pa'])
 def test_unknown_effects_total_unknown(self):
  q=quote_new_item(rank='Ouro Negro',attributes=2,effect_scope_closed=False)
  self.assertIsNone(q['daily_total_pa_day']);self.assertEqual(q['daily_lower_bound_pa'],35)
 def test_unranked_rejected(self):
  with self.assertRaises(ValueError):quote_new_item(rank=None)
 def test_negative_rejected(self):
  with self.assertRaises(ValueError):quote_new_item(rank='Prata',fixed_damage=-1)
 def test_non_finite_rejected(self):
  with self.assertRaises(ValueError):quote_new_item(rank='Prata',attributes='NaN')
 def test_fractional_uses_rejected(self):
  with self.assertRaises(ValueError):quote_new_item(rank='Prata',uses=.5)
 def test_baseline_94(self):self.assertEqual(self.data['counts']['total'],94)
 def test_rank_evidence(self):self.assertEqual((self.data['counts']['E0'],self.data['counts']['E3'],self.data['counts']['sem_rank']),(5,86,3))
 def test_rank_counts(self):self.assertEqual([x['n_items'] for x in self.data['historical_stats']],[8,30,35,13,5])
 def test_mediana_matches_floors(self):self.assertEqual([x['mediana_historica_pa_dia'] for x in self.data['historical_stats']],[8,11,21,35,90])
 def test_old_items_below_floor_unchanged(self):self.assertEqual([x['historicos_abaixo_do_piso'] for x in self.data['historical_stats']],[4,13,17,6,2])
 def test_no_official_writes(self):self.assertEqual(sum(self.data[k] for k in ('notion_writes','party_writes','historical_cost_edits')),0)
 def test_exclude_zephyr_per_turn(self):
  obs=self.data['observations']; self.assertFalse(any(x['item']=='Armadura de Zephyr (L)' and x['eixo']=='dano_fixo_por_acerto' for x in obs))
  self.assertTrue(any(x['eixo']=='dano_por_turno' and x['valor']==50 for x in self.data['excluded_or_split']))
 def test_zephyr_attributes(self):
  self.assertTrue(any(x['item']=='Armadura de Zephyr (L)' and x['eixo']=='atributos_total_item' and x['valor']==15 for x in self.data['observations']))
 def test_lamina_bonuses(self):
  ob={(x['item'],x['eixo']):x['valor'] for x in self.data['observations']}
  self.assertEqual(ob['Lâmina Aurora Boreal','atributos_total_item'],15)
  self.assertEqual(ob['Lâmina Aurora Boreal','bonus_ataque'],3)
  self.assertEqual(ob['Lâmina Aurora Boreal','dano_fixo_por_acerto'],8)
 def test_no_imperial_double_count(self):self.assertFalse(any(x['item']=='IMPERIAL' for x in self.data['observations']))
 def test_colar_conditional_not_stacked(self):
  ob=[x for x in self.data['observations'] if x['item']=='Colar cadente' and x['eixo']=='atributos_total_item'];self.assertEqual(ob[0]['valor'],2)
  self.assertTrue(any(x['item']=='Colar cadente' and x['valor']==4 for x in self.data['excluded_or_split']))
 def test_no_zero_samples_imputed(self):
  r=[x for x in self.data['metric_stats'] if x['rank']=='Bronze' and x['eixo']=='atributos_total_item'][0]
  self.assertEqual(r['n_independente'],0);self.assertIsNone(r['media_observada'])
 def test_ca_not_magical_assumption(self):
  r=[x for x in self.data['observations'] if x['item']=='Armadura de Zephyr (L)' and x['eixo']=='bonus_ca'][0]
  self.assertIn('não tarifar CA mágica',r['condicao'])
 def test_sample_axis_means(self):
  ss={(x['rank'],x['eixo']):x for x in self.data['metric_stats']}
  self.assertEqual(ss['Prata','dano_fixo_por_acerto']['media_observada'],6.4)
  self.assertEqual(ss['Ouro','atributos_total_item']['media_observada'],5.4)
 def test_no_rescored_ranks_from_pa(self):self.assertEqual(self.data['rank_classification_order'],'ATLAS_PR_ECO_01_ANTES_DE_CONSULTAR_PA')
if __name__=='__main__':unittest.main(verbosity=2)
