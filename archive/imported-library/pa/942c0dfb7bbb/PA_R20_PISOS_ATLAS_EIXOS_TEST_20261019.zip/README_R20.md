# PA R20 TEST — continuação de R11–R19

Este pacote é **adição local** ao subsistema energético PA da OP-ARQ-RIN-REC-01. Não substitui os artefatos históricos nem os altera.

## Reexecutar

```bash
python -m unittest test_pa_r20.py -v
python -c "from pa_r20_floor_atlas import run; print(run('PA_P0_R09_CORRIGENDA_TEST_20261018.zip','PA_P0_AUDITORIA_94_RANKS_CORRECOES_TEST_20261017.zip')['counts'])"
```

As duas fontes ZIP são mantidas byte a byte com hashes validados no código. `ANALISE_R20.json` e CSV contêm o relatório de números. A planilha contém a matriz de bônus e um simulador para **novos** itens.

Não use o arquivo para alterar custos/ranks/fichas existentes. Classifique item via Atlas A e depois consulte os pisos. O custo variável por ativação não é inferido do piso diário. `0` não significa custo desconhecido.

## Autoridade

Pisos: decisão humana do Mestre em 19/10/2026, ainda sem confirmação de escrita normativa Notion. Demais estatísticas: observacionais e dependentes do corpus documental R06/R09, na maioria ranks E3. Produção HOLD, CRAFT F5 RED.
