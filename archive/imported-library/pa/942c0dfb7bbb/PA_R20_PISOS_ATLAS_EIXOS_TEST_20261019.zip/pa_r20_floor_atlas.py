"""PA R20 TEST — extensão interpretativa dos R09/R11 existentes.

Não altera baselines, custos históricos, rank canônico, fichas Party ou operação CRAFT.
Pisos são DECISÃO EXPLÍCITA DO MESTRE em 19/10/2026, não inferência estatística.
"""
from __future__ import annotations
import csv, hashlib, io, json, statistics, zipfile
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

RANKS = ('Bronze', 'Prata', 'Ouro', 'Ouro Negro', 'Lendário')
FLOORS = {'Bronze': 8, 'Prata': 11, 'Ouro': 21, 'Ouro Negro': 35, 'Lendário': 90}
RATES = {'atributo':5, 'dano_fixo':1, 'movimento_adicional_m':1, 'bonus_ataque':1, 'ca_magica':1}
BASELINE_SHA = {
 'PA_P0_R09_CORRIGENDA_TEST_20261018.zip':'90ceedc8513b09fe6b6938d0c747a4eba77feb854f8834b791791de9fd320d90',
 'PA_P0_AUDITORIA_94_RANKS_CORRECOES_TEST_20261017.zip':'6d00306079ac4578d0191d424742a3c746c2a9f73327b9d8563e9267b4f25eb6'
}

def verify_file(path):
    p=Path(path)
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    expected=BASELINE_SHA.get(p.name)
    if expected is not None and digest!=expected:
        raise ValueError(f'Baseline SHA diferente: {p.name} {digest}')
    return digest

def read_baselines(r09_zip, r06_zip):
    verify_file(r09_zip);verify_file(r06_zip)
    with zipfile.ZipFile(r09_zip) as z:
        prior=list(csv.DictReader(io.StringIO(z.read('AUDITORIA_94_RECONCILIADA_R09.csv').decode('utf-8-sig')),delimiter=';'))
    with zipfile.ZipFile(r06_zip) as z:
        earlier=json.loads(z.read('PA_P0_AUDITORIA_20261017/AUDITORIA_INTEGRAL_94.json'))['rows']
    if len(prior)!=94 or len(earlier)!=94: raise ValueError('Universo documental diferente de 94')
    a={x['uuid']:x for x in prior};b={x['uuid']:x for x in earlier}
    if len(a)!=94 or len(b)!=94 or set(a)!=set(b):raise ValueError('Identidade das fichas divergente')
    return prior,b

def classify_r09(row):
    rank=row.get('rank_documental') or row.get('rank_e3') or None
    if rank is not None and rank not in FLOORS:raise ValueError(f'rank desconhecido: {rank}')
    return rank

def _positive(x,name):
    if x is None:return None
    if isinstance(x,bool):raise ValueError(f'{name} inválido')
    try:v=Decimal(str(x))
    except (InvalidOperation,ValueError,TypeError):raise ValueError(f'{name} inválido')
    if not v.is_finite() or v<0: raise ValueError(f'{name} negativo ou não finito')
    return v

def quote_new_item(*, rank, attributes=0, fixed_damage=0, movement_m=0, attack_bonus=0,
                   magical_ca=0, other_daily_known=0, activation_per_use=None, uses=0,
                   effect_scope_closed=True, rank_evidence='E3'):
    """Cotação de novo item; exige rank determinado INDEPENDENTEMENTE do PA.

    `other_daily_known` é valor já estabelecido pelo sistema externo, NÃO calculado aqui.
    Se efeitos não fechados, daily_quote é limite inferior e não valor total homologável.
    O custo de ativação é independente do piso; unknown != 0.
    """
    if rank not in FLOORS: raise ValueError('rank de item válido é obrigatório antes de precificar')
    if rank_evidence not in ('E0','E1','E2','E3'):raise ValueError('selo Atlas inválido')
    if type(uses)!=int or uses<0: raise ValueError('usos inteiros >=0 obrigatórios')
    fields={'attributes':attributes,'fixed_damage':fixed_damage,'movement_m':movement_m,
            'attack_bonus':attack_bonus,'magical_ca':magical_ca,'other_daily_known':other_daily_known}
    numeric={k:_positive(v,k) for k,v in fields.items()}
    subtotal=Decimal(5)*numeric['attributes']+numeric['fixed_damage']+numeric['movement_m']+numeric['attack_bonus']+numeric['magical_ca']+numeric['other_daily_known']
    floor=Decimal(FLOORS[rank]); daily=max(subtotal,floor)
    activation=_positive(activation_per_use,'activation_per_use')
    if uses and activation is None: activation_today=None
    else:activation_today=Decimal(0) if uses==0 else activation*uses
    total_today=None if activation_today is None else daily+activation_today
    return {'rank':rank,'rank_evidence':rank_evidence,'floor_pa_day':int(floor),
            'identified_subtotal_pa_day':float(subtotal),'daily_lower_bound_pa':float(daily),
            'is_daily_total_fully_quotable':bool(effect_scope_closed),
            'daily_total_pa_day':float(daily) if effect_scope_closed else None,
            'activation_per_use_pa':None if activation is None else float(activation),
            'activations_today':uses,'activation_cost_today_pa':None if activation_today is None else float(activation_today),
            'daily_plus_activations_today_pa':float(total_today) if total_today is not None and effect_scope_closed else None,
            'nonretroactive':True,'historical_item_edited':False,
            'confidence':'DECISAO_MESTRE_PISOS_TEST_NAO_PUBLICADO_NOTION'}

def historic_rank_stats(prior):
    grouped=defaultdict(list);counts=Counter()
    for r in prior:
        rank=classify_r09(r)
        counts['total']+=1
        if rank is None:
            counts['sem_rank']+=1;continue
        cost=int(r['historico_pa_dia'])
        if cost<0:raise ValueError('PA histórico negativo')
        grouped[rank].append(cost)
        counts[r['status_rank']]+=1
    out=[]
    for rank in RANKS:
        vs=grouped[rank]
        if not vs:raise ValueError(f'sem amostra: {rank}')
        p=FLOORS[rank]
        out.append({'rank':rank,'piso_mestre_novas_criacoes_pa_dia':p,'n_items':len(vs),
                    'min_historico_pa_dia':min(vs),'max_historico_pa_dia':max(vs),
                    'media_historica_pa_dia':round(statistics.mean(vs),4),
                    'mediana_historica_pa_dia':statistics.median(vs),
                    'historicos_abaixo_do_piso':sum(v<p for v in vs),
                    'historicos_iguais_ao_piso':sum(v==p for v in vs),
                    'historicos_acima_do_piso':sum(v>p for v in vs),
                    'rank_e0':sum(1 for r in prior if classify_r09(r)==rank and r['status_rank']=='E0'),
                    'rank_e3':sum(1 for r in prior if classify_r09(r)==rank and r['status_rank']=='E3')})
    return out,dict(counts)

# Leitura adicional da fonte de origem (Mestre-side), sem alterar a leitura R09/R06:
# - +8 dano e +3 ataque de aprimoramento: Lâmina Aurora Boreal, Notion Mestre espelho
#   https://app.notion.com/p/a70c2b324ede83c2ac490135cd512e9f
# - +2 CA da Couraça de Eos; +2 CA Anã estrutural; +3 CA Defensora sob troca.
# - +11 CA da Zephyr é armadura física, NÃO bônus de CA mágica precificável.
# - A modalidade +50 dano de Zephyr é POR TURNO, separada dos aumentos por acerto.
ADDITIONAL_BONUSES={
 ('Lâmina Aurora Boreal','dano_fixo_por_acerto'):(8,'aprimoramento +8 dano; escopo de empilhamento pendente','https://app.notion.com/p/a70c2b324ede83c2ac490135cd512e9f'),
 ('Lâmina Aurora Boreal','bonus_ataque'):(3,'aprimoramento +3 teste de ataque','https://app.notion.com/p/a70c2b324ede83c2ac490135cd512e9f'),
 ('Armadura Anã','bonus_ca'):(2,'bônus estrutural de armadura; NÃO comprovadamente mágico',None),
 ('Defensora','bonus_ca'):(3,'transferência temporária de ataque para CA; mutuamente exclusiva',None),
 ('Couraça de Eos','bonus_ca'):(2,'+2 CA informado; origem mágica não estabelecida',None),
 ('Armadura de Zephyr (L)','bonus_ca'):(11,'bônus CA de armadura leve, origem física; não tarifar CA mágica','https://app.notion.com/p/a23c2b324ede829bb8168165991577ff'),
}

METRICS=('atributos_total_item','dano_fixo_por_acerto','bonus_ca','bonus_ataque','movimento_adicional_m')
UNITS={'atributos_total_item':'pontos de atributos','dano_fixo_por_acerto':'pontos fixos por acerto/condição',
       'bonus_ca':'pontos de CA','bonus_ataque':'pontos em teste de ataque','movimento_adicional_m':'metros de deslocamento'}

def extract_observations(prior, earlier_by_id):
    observations=[];byname={r['item']:r for r in prior}
    if len(byname)!=94:raise ValueError('nomes duplicados no corpus: revisar identidade')
    for r in prior:
        rank=classify_r09(r)
        if rank is None:continue
        x=earlier_by_id[r['uuid']]
        if r['item'] != x['item']:raise ValueError('Nome da origem não confere')
        if r['item']=='IMPERIAL': continue # provável duplicata textual da Veste; retirar APENAS da amostra independente de efeitos
        comps=x['auditoria_p0'].get('componentes',[])
        by_metric=defaultdict(list)
        for c in comps:
            typ=c['tipo'];val=int(c['magnitude']);mode=c['modalidade']
            if val<=0:continue
            metric={'atributo':'atributos_total_item','dano_fixo':'dano_fixo_por_acerto',
                    'ca_magica':'bonus_ca','bonus_ataque':'bonus_ataque',
                    'movimento_adicional_m':'movimento_adicional_m'}.get(typ)
            if not metric:continue
            if typ=='atributo' and mode!='permanente':continue # Colar sob estrelas é cenário alternativo, não somar em média-base
            if typ=='dano_fixo' and mode=='por_turno_condicional':continue # unidade temporal incompatível com dano por acerto
            by_metric[metric].append((val,mode,c.get('evidencia','')))
        for metric,cs in by_metric.items():
            total=sum(v for v,_,_ in cs)
            notes=' | '.join(str(m) for _,m,_ in cs)
            if r['item']=='Manto de Proteção' and metric=='bonus_ca':notes+=' | origem mágica pendente de comprovação Party'
            if r['item']=='Mobilidade' and metric=='bonus_ca':notes+=' | bônus condicional de esquiva, não comprova origem mágica'
            if r['item']=='Armadura Guardiã Elemental (ON)' and metric=='bonus_ca':notes+=' | somente contra elementais'
            observations.append({'uuid':r['uuid'],'item':r['item'],'rank':rank,'status_rank':r['status_rank'],
                         'eixo':metric,'unidade':UNITS[metric],'valor':total,'condicao':notes,
                         'fonte':'R06_EFEITOS_RESUMIDOS+R09_RANK','url_fonte':r['url_fonte'] or r['url_original'],
                         'nota':'observação, NÃO limite oficial do rank'})
        for (name,metric),(val,note,url) in ADDITIONAL_BONUSES.items():
            if r['item']!=name:continue
            if metric in by_metric: raise ValueError(f'componente já contado, evitar duplicata: {name} {metric}')
            observations.append({'uuid':r['uuid'],'item':name,'rank':rank,'status_rank':r['status_rank'],
                         'eixo':metric,'unidade':UNITS[metric],'valor':val,'condicao':note,
                         'fonte':'FONTE_EXTRA_R20','url_fonte':url or r['url_fonte'] or r['url_original'],
                         'nota':'parcela isolada/observada, NÃO total do item'})
    # Checagens de unidade temporal e fontes divergentes (fora da média por acerto).
    exclusions=[
     {'item':'Armadura de Zephyr (L)','rank':'Lendário','eixo':'dano_por_turno','valor':50,
      'causa':'+50 dano de Vento POR TURNO; não é o mesmo que +50 por acerto',
      'url':'https://app.notion.com/p/a23c2b324ede829bb8168165991577ff'},
     {'item':'Espada do Lendário','rank':'Lendário','eixo':'dano_intrinseco','valor':390,
      'causa':'390 em fórmula intrínseca da arma, não bônus adicional fixo ao portador'},
     {'item':'Colar cadente','rank':'Prata','eixo':'atributo_condicional','valor':4,
      'causa':'+2 SAB usual, +4 SAB sob estrelas; cenário alternativo ao bônus de base +2'},
     {'item':'IMPERIAL','rank':'Ouro','eixo':'multieixo','valor':None,
      'causa':'texto possivelmente duplicado da Veste Dragão Ascendente; não contar duas amostras independentes'},
     {'item':'SOMBRA SUSSURRANTE','rank':'Ouro','eixo':'bonus_ca','valor':8,
      'causa':'+8 é CA-base de armadura com proveniência física/incerta, não delta isolado de CA mágica'},
     {'item':'Bastião de Virilia','rank':'Ouro','eixo':'bonus_ca','valor':8,
      'causa':'+8 CA física sob proveniência inconclusiva; não computar como bônus mágico'},
     {'item':'Manto do Arquimago','rank':'Ouro Negro','eixo':'bonus_ca','valor':18,
      'causa':'CA-base substitutiva 18+DES, não bônus +18 CA'},
    ]
    obskeys=[(x['uuid'],x['eixo']) for x in observations]
    if len(obskeys)!=len(set(obskeys)):raise ValueError('Duplicação por item/eixo detectada')
    return observations,exclusions

def observed_stats(observations):
    groups=defaultdict(list)
    for x in observations:groups[(x['rank'],x['eixo'])].append(x)
    out=[]
    for rank in RANKS:
        for metric in METRICS:
            rows=groups[(rank,metric)];a=[r['valor'] for r in rows]
            out.append({'rank':rank,'eixo':metric,'unidade':UNITS[metric],
                        'n_independente':len(a),'minimo_observado':min(a) if a else None,
                        'maximo_observado':max(a) if a else None,
                        'media_observada':round(statistics.mean(a),4) if a else None,
                        'mediana_observada':statistics.median(a) if a else None,
                        'n_rank_documental_e0':sum(r['status_rank']=='E0' for r in rows),
                        'n_rank_inferido_e3':sum(r['status_rank']=='E3' for r in rows),
                        'observacao':'AMOSTRA_EXPLORATORIA_NAO_LIMITE_CANONICO; efeitos condicionais identificados nas linhas'})
    return out

def run(r09_zip,r06_zip):
    rows,earlier=read_baselines(r09_zip,r06_zip)
    history,counts=historic_rank_stats(rows)
    obs,excluded=extract_observations(rows,earlier)
    summary=observed_stats(obs)
    return {'status':'R20_TEST_LOCAL_SEM_ESCRITA_CANONICA','as_of':'2026-10-19',
            'governance':'MESTRE_SIDE_P0_PRODUCAO_HOLD',
            'decision':'PISOS_POR_RANK_OBRIGATORIOS_PARA_NOVOS_ITENS_INCLUSIVE_SOMENTE_ATIVAVEIS',
            'rank_classification_order':'ATLAS_PR_ECO_01_ANTES_DE_CONSULTAR_PA',
            'floors_pa_day':FLOORS,'five_rates_pa_day':RATES,
            'historical_stats':history,'counts':counts,'metric_stats':summary,
            'observations':obs,'excluded_or_split':excluded,
            'sample_quality':{'historical_items':len(rows),'classified_items':len(rows)-counts.get('sem_rank',0),
                'ranks_e0':counts.get('E0',0),'ranks_e3':counts.get('E3',0),
                'note':'E3 semicanonico; antigos não reajustados, duplicatas de texto retiradas apenas dos bônus'},
            'baseline_sha256':{Path(p).name:verify_file(p) for p in (r09_zip,r06_zip)},
            'notion_writes':0,'party_writes':0,'historical_cost_edits':0,'proposed_new_recipes':0}
