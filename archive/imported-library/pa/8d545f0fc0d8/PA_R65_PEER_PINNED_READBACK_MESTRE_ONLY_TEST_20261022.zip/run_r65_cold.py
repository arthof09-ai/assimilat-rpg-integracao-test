import subprocess,sys,json
from pathlib import Path
r=Path(__file__).resolve().parent
p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r65.py','-q'],cwd=r,text=True,capture_output=True,timeout=90)
if p.returncode or 'Ran 25 tests' not in p.stderr:raise RuntimeError(p.stderr)
print(json.dumps({'status':'PASS_R65_ORIGINAL_SOURCE_PINNED','R65_tests':25,'R64_bypass_reproduced':2,'peer_responses_received':0,'E0_adjudicated':0,'production':'HOLD','party_write':False},sort_keys=True))
