"""Hardens the *already existing* R60 blind readiness gate with a sealed image identity.
Never adjudicates ranks or forwards a package. If anything fails, fails CLOSED.
"""
from __future__ import annotations
import zipfile,json,hashlib,unicodedata
from src.peer14_gate_r60 import check as old_check

FIXED_TEXT={'PEER14_BLIND_ASSIGNMENT.json','FORMULARIO_CEGO_14.csv','LEIA_ANTES_PEER14.md'}

def _normalize(s):
 return ''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.combining(c)).casefold()
def deny(code):
 return {'status':'HOLD_R64_BLIND_LEAKAGE_OR_INTEGRITY','issues':[code],
 'blind_ready':False,'independent_peer_review_received':False,'adjudicated_RE_E0':0,
 'official_PA':None,'notion_write':False,'party_write':False,'production':'HOLD'}

def hardened_check(blind_zip, sealed):
 try:
  with zipfile.ZipFile(blind_zip) as z:
   members=z.infolist();names=[n.filename for n in members]
   if len(names)!=len(set(names)):return deny('DUPLICATE_ZIP_MEMBER_NAME')
   if any(n.file_size>8_000_000 for n in members) or sum(n.file_size for n in members)>15_000_000:return deny('ZIP_OVERSIZE')
   if any('/../' in '/'+n or n.startswith('/') or '\\' in n for n in names):return deny('ZIP_PATH_OUTSIDE_PACK')
   expected_records=sealed['records'];anchor={r['case_id']:r for r in expected_records}
   if len(anchor)!=14 or len(expected_records)!=14:return deny('SEALED_MASTER_DENOMINATOR_BAD')
   allowed=FIXED_TEXT | {f'IMAGENS_SEM_GABARITO/{c}.jpg' for c in anchor}
   if set(names)!=allowed:return deny('UNEXPECTED_OR_MISSING_BLIND_PACKAGE_MEMBER')
   if z.testzip() is not None:return deny('ZIP_CRC_FAILURE')
   doc=json.loads(z.read('PEER14_BLIND_ASSIGNMENT.json'))
   records=doc['records']; ids=[r['case_id'] for r in records]
   if len(ids)!=14 or set(ids)!=set(anchor) or len(set(ids))!=14:return deny('ROSTER_MISMATCH')
   if set(ids)&set(sealed['peer12_ids_excluded']):return deny('PEER12_LEAKAGE')
   for r in records:
    cid=r['case_id']; expected=anchor[cid]['masked_sha256'];p=f'IMAGENS_SEM_GABARITO/{cid}.jpg'
    actual=hashlib.sha256(z.read(p)).hexdigest()
    if actual!=expected or r.get('image_sha256')!=expected:return deny('SEALED_MASKED_SHA_MISMATCH')
    if actual==anchor[cid]['original_sha256']:return deny('UNMASKED_ORIGINAL_IMAGE_IN_BLIND_PACKAGE')
    if r.get('source_image')!=p:return deny('IMAGE_ID_LINK_MISMATCH')
   # Inspect *all* text blocks, not only the JSON fields checked in R60.
   for n in FIXED_TEXT:
    data=_normalize(z.read(n).decode('utf-8'))
    if any(grade in data for grade in ('bronze','prata','ouro','lendario')):
     return deny('GRADE_ORACLE_LEAK_IN_TEXT:'+n)
   # Original gate still validates CSV blank rows, source IDs, and other fields.
   r60_master=[{'case_id':r['case_id']} for r in expected_records]
   result=old_check(blind_zip,r60_master,sealed['peer12_ids_excluded'])
   if result['status']!='FORM_BLIND_READY_NOT_SENT':return deny('ORIGINAL_R60_GATE_FAILURE')
   return {'status':'R64_BLIND_PACK_VALIDATED_NOT_SENT','issues':[],
    'blind_ready':True,'validated_masked_images':14,'prior_peer12_separated':12,
    'independent_peer_review_received':False,'adjudicated_RE_E0':0,
    'official_PA':None,'notion_write':False,'party_write':False,'production':'HOLD'}
 except (KeyError,ValueError,TypeError,UnicodeError,zipfile.BadZipFile,EOFError,LookupError,AttributeError) as e:
  return deny('INVALID_PACKAGE_OR_SCHEMA:'+type(e).__name__)
 except OSError as e:
  return deny('INACCESSIBLE_PACKAGE:'+type(e).__name__)
