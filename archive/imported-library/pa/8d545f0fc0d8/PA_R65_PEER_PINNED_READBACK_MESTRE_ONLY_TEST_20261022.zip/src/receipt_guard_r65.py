"""R65 read-only seal gate, explicitly pinned to archived original R60 peer package and R64 hash list.

This checks static TEST package integrity; does not authenticate Notion page authorship, evaluate game balance, or grant a reviewer authorization.
"""
import hashlib,zipfile,json,os
from src.hardened_blind_r64 import hardened_check
R60_PEER_SHA256='6118f4d2ba1843f2796ea92fa371029d247d4c795cf059786afbe862d86964ca'
R64_SEAL_SHA256='f154cb60262439be4d881d1437756e855c47d50006910c56b4779a73a94524c6'
R60_OUTER_SOURCE_SHA256='33a96470fd1abdcd7c217241197f1d46d4c4aeb7dd163b230700421bbcce1835'

def deny(code):
 return {'status':'HOLD_R65_ORIGINAL_SEAL_OR_METADATA_INVALID','issues':[code],'peer_submission_authorized':False,'independent_review_received':0,'rank_E0_decided':0,'PA_production':None,'party_write':False,'notion_write':False,'production':'HOLD'}

def check_pinned(peer_zip, seal_file):
 try:
  zip_bytes=open(peer_zip,'rb').read();seal_bytes=open(seal_file,'rb').read()
  if hashlib.sha256(zip_bytes).hexdigest()!=R60_PEER_SHA256:return deny('R60_PEER_ZIP_SHA_CHANGED')
  if hashlib.sha256(seal_bytes).hexdigest()!=R64_SEAL_SHA256:return deny('MASTER_SEAL_SHA_CHANGED')
  source=json.loads(seal_bytes)
  if source['source_r60_outer_zip_sha256']!=R60_OUTER_SOURCE_SHA256:return deny('ORIGIN_WRONG')
  if source['peer_r60_original_sha256']!=R60_PEER_SHA256:return deny('PEER_WRONG')
  with zipfile.ZipFile(peer_zip) as z:
   if z.comment:return deny('ZIP_GLOBAL_COMMENT_FORBIDDEN')
   for n in z.infolist():
    if n.comment or n.extra:return deny('ZIP_MEMBER_COMMENT_OR_EXTRA_FORBIDDEN')
    if n.flag_bits & 1:return deny('ZIP_ENCRYPTED_MEMBER_FORBIDDEN')
  r=hardened_check(peer_zip,source)
  if r['status']!='R64_BLIND_PACK_VALIDATED_NOT_SENT':return deny('R64_REJECTED')
  return {'status':'R65_R60_PEER_PACKAGE_HASH_PINNED_NOT_SENT','issues':[],'original_R60_SHA256':R60_PEER_SHA256,
   'R64_seal_sha256':R64_SEAL_SHA256,'masked_images_verified':14,'independent_review_received':0,'rank_E0_decided':0,
   'peer_submission_authorized':False,'PA_production':None,'party_write':False,'notion_write':False,'production':'HOLD'}
 except (KeyError,TypeError,ValueError,UnicodeError,zipfile.BadZipFile,PermissionError,FileNotFoundError,OSError) as e:
  return deny('INPUT_OR_PACKAGE_ERROR:'+type(e).__name__)
