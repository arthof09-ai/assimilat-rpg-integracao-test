"""Strict structural controls on an external 14-case review. Zero authority is inferred.
This is a validation tool; always record review status separately from adjudication.
"""
from __future__ import annotations
import hashlib,json,zipfile,csv,io,re
from pathlib import Path
BANNED=('historical_nominal_technique_rank','legacy_rank','notion_page_url','notion_page_id','rank_proposal_test_only','provisional_rank','canonical_re','expected_rank','oracle','gabarito')

def check(peer_zip,master_meta,peer12_ids,answers=None):
 issues=[]
 with zipfile.ZipFile(peer_zip) as z:
  if z.testzip():issues.append('ZIP_CRC_INVALID')
  files=z.namelist(); records=json.loads(z.read('PEER14_BLIND_ASSIGNMENT.json'))['records']
  ids=[x.get('case_id') for x in records]
  if len(ids)!=14 or len(set(ids))!=14:issues.append('14_UNIQUE_CASES_REQUIRED')
  if set(ids)&set(peer12_ids):issues.append('PEER12_CONTAMINATION')
  images=[p for p in files if p.startswith('IMAGENS_SEM_GABARITO/') and p.endswith('.jpg')]
  if len(images)!=14:issues.append('14_IMAGES_REQUIRED')
  if sorted(x['source_image'] for x in records)!=sorted(images):issues.append('IMAGE_CASE_LINK_INVALID')
  for x in records:
   if x.get('verdict') is not None or x.get('reviewer_submission') is not None:issues.append('REVIEW_NOT_BLANK')
   if any(k in BANNED for k in x.keys()):issues.append('BLIND_METADATA_LEAK')
   if x.get('source_image') in files and hashlib.sha256(z.read(x['source_image'])).hexdigest()!=x.get('image_sha256'):issues.append('IMAGE_SHA_MISMATCH')
  s=z.read('PEER14_BLIND_ASSIGNMENT.json').decode()
  if any(v in s for v in ('Bronze','Prata','Ouro','Lendário','Lendario')):issues.append('RANK_LEAK_IN_ASSIGNMENT')
  form=list(csv.reader(io.StringIO(z.read('FORMULARIO_CEGO_14.csv').decode())))
  if len(form)!=15 or sorted(x[0] for x in form[1:])!=sorted(ids):issues.append('CSV_DENOMINATOR_MISMATCH')
  if any(any(v.strip() for v in row[1:]) for row in form[1:]):issues.append('CSV_PREPOPULATED_ANSWERS')
 if len(master_meta)!=14 or {x['case_id'] for x in master_meta}!=set(ids):issues.append('MASTER_METADATA_MISMATCH')
 if answers is not None:issues.append('REVIEW_IS_NOT_AUTHORITY')
 return {'status':'FORM_BLIND_READY_NOT_SENT' if not issues else 'HOLD_R60_BLIND_PACK','issues':sorted(set(issues)),
 'independent_peer_review_received':False,'adjudicated_RE_E0':0,'authoritative_PA':None,'party_write':False,
 'notion_write':False,'production':'HOLD'}
