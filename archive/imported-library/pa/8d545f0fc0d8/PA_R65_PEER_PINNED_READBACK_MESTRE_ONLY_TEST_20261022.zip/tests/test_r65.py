import unittest,json,hashlib,pathlib,tempfile,zipfile,copy
from src.receipt_guard_r65 import check_pinned,R60_PEER_SHA256,R64_SEAL_SHA256
from src.hardened_blind_r64 import hardened_check
root=pathlib.Path(__file__).resolve().parents[1]
peer=root/'PA_R60_PEER14_CEGO_SEM_GABARITO_MESTRE_ONLY_TEST_20261022.zip'
seal=root/'fixtures/R64_SEALED_MASKED_HASHES_MASTER_ONLY.json'
def edit_peer(change):
 with zipfile.ZipFile(peer) as z:cont={n:z.read(n) for n in z.namelist()}
 fd=tempfile.NamedTemporaryFile(suffix='.zip')
 with zipfile.ZipFile(fd.name,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in cont.items():z.writestr(n,b)
  change(z,cont)
 return fd
class R65Tests(unittest.TestCase):
 def test_01_ready_hash_pinned(self):self.assertEqual(check_pinned(peer,seal)['status'],'R65_R60_PEER_PACKAGE_HASH_PINNED_NOT_SENT')
 def test_02_peer_hash(self):self.assertEqual(hashlib.sha256(peer.read_bytes()).hexdigest(),R60_PEER_SHA256)
 def test_03_master_seal_hash(self):self.assertEqual(hashlib.sha256(seal.read_bytes()).hexdigest(),R64_SEAL_SHA256)
 def test_04_fourteen_images(self):self.assertEqual(check_pinned(peer,seal)['masked_images_verified'],14)
 def test_05_not_submitted(self):self.assertFalse(check_pinned(peer,seal)['peer_submission_authorized'])
 def test_06_rank_zero(self):self.assertEqual(check_pinned(peer,seal)['rank_E0_decided'],0)
 def test_07_peer_response_zero(self):self.assertEqual(check_pinned(peer,seal)['independent_review_received'],0)
 def test_08_production_hold(self):self.assertEqual(check_pinned(peer,seal)['production'],'HOLD')
 def test_09_no_party_write(self):self.assertFalse(check_pinned(peer,seal)['party_write'])
 def test_10_no_notion_write(self):self.assertFalse(check_pinned(peer,seal)['notion_write'])
 def test_11_old_r64_fails_to_detect_global_zip_comment(self):
  with tempfile.NamedTemporaryFile(suffix='.zip') as x:
   with zipfile.ZipFile(peer) as zsrc,zipfile.ZipFile(x.name,'w') as z:
    for i in zsrc.infolist():z.writestr(i,zsrc.read(i.filename))
    z.comment=b'CLASSIFICACAO HISTORICA: Bronze'
   self.assertEqual(hardened_check(x.name,json.loads(seal.read_text()))['status'],'R64_BLIND_PACK_VALIDATED_NOT_SENT')
   self.assertIn('HOLD',check_pinned(x.name,seal)['status'])
 def test_12_tamper_master_and_image_old_r64_accepts(self):
  forged=copy.deepcopy(json.loads(seal.read_text()))
  with tempfile.NamedTemporaryFile(suffix='.zip') as x:
   with zipfile.ZipFile(peer) as z:cont={n:z.read(n) for n in z.namelist()}
   j=json.loads(cont['PEER14_BLIND_ASSIGNMENT.json']);r=j['records'][0]
   b=b'forged content without canonical masking';h=hashlib.sha256(b).hexdigest()
   cont[r['source_image']]=b;r['image_sha256']=h;forged['records'][0]['masked_sha256']=h
   cont['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(j).encode()
   with zipfile.ZipFile(x.name,'w',zipfile.ZIP_DEFLATED) as z:
    for k,v in cont.items():z.writestr(k,v)
   self.assertEqual(hardened_check(x.name,forged)['status'],'R64_BLIND_PACK_VALIDATED_NOT_SENT')
   self.assertIn('HOLD',check_pinned(x.name,seal)['status'])
 def test_13_forged_seal_modification(self):
  with tempfile.NamedTemporaryFile(suffix='.json') as x:
   j=json.loads(seal.read_text());j['records'][0]['masked_sha256']='1'*64;x.write(json.dumps(j).encode());x.flush()
   self.assertIn('HOLD',check_pinned(peer,x.name)['status'])
 def test_14_spoiler_comment_as_hex(self):
  with tempfile.NamedTemporaryFile(suffix='.zip') as x:
   with zipfile.ZipFile(peer) as zsrc,zipfile.ZipFile(x.name,'w') as z:
    for i in zsrc.infolist():z.writestr(i,zsrc.read(i.filename))
    z.comment=b'Prata'
   self.assertIn('HOLD',check_pinned(x.name,seal)['status'])
 def test_15_peer_missing(self):self.assertIn('HOLD',check_pinned('/tmp/ABSENT_R65_PEER_9949382.zip',seal)['status'])
 def test_16_seal_missing(self):self.assertIn('HOLD',check_pinned(peer,'/tmp/ABSENT_R65_SEAL_9949382.json')['status'])
 def test_17_wrong_peer_file(self):self.assertIn('HOLD',check_pinned(seal,seal)['status'])
 def test_18_wrong_seal_file(self):self.assertIn('HOLD',check_pinned(peer,peer)['status'])
 def test_19_archive_excludes_historical_oracle(self):
  with zipfile.ZipFile(peer) as z:self.assertNotIn('MASTER_ONLY', ' '.join(z.namelist()))
 def test_20_image_members(self):
  with zipfile.ZipFile(peer) as z:self.assertEqual(sum(n.endswith('.jpg') for n in z.namelist()),14)
 def test_21_no_zip_comment_baseline(self):
  with zipfile.ZipFile(peer) as z:self.assertFalse(z.comment)
 def test_22_no_member_metadata_comment_baseline(self):
  with zipfile.ZipFile(peer) as z:self.assertTrue(all(not i.comment and not i.extra for i in z.infolist()))
 def test_23_exact_ROSTER(self):
  with zipfile.ZipFile(peer) as z:self.assertEqual(len(json.loads(z.read('PEER14_BLIND_ASSIGNMENT.json'))['records']),14)
 def test_24_no_production_cost(self):self.assertIsNone(check_pinned(peer,seal)['PA_production'])
 def test_25_invariant_no_adjudication(self):self.assertEqual(check_pinned(peer,seal)['rank_E0_decided'],0)
