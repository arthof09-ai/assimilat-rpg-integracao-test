# Missão isolada de revisão — 1 imagem sem classificação prévia

**Comestre avaliador distinto, Mestre-only, TEST.** O objetivo é avaliar somente a mecânica do JPG recebido, sem ouvir/classificar ranks anteriores. **Não executar esta missão com um revisor que já conhece a classificação da técnica**; revisor anterior ficou exposto à identificação no Atlas §18.

**Precaução especial de cegamento**: o Atlas A canônico completo contém uma menção nominal e classificação desta técnica. Para esta etapa experimental, NÃO abrir a seção §18 do Atlas nem pesquisar o nome/código do JPG no Notion ou nos estudos PA R45-R48 antes de congelar. Consulte os princípios do Atlas descritos abaixo, que são um resumo parcial read-only sem classificação particular, e fontes independentes como Sistema de Combate/Magia e DMG-RANK-01; anote precisamente o que não pôde verificar. Se encontrar a classificação acidentalmente, marque EXPOSTO e não entregue resultado como cego.

**Princípios selecionados do Atlas A, sem identidade de efeito (resumo de regras)**: distinguir rank nominal de personagem (RN), rank de efeito (RE), item (RI), insumo (RIn), usuário (RU); classificar o efeito que existe, não o preço nem o rank do portador; avaliar poder dominante confiável por defesa, área, duração, economia de ações, condições, bypass e confiabilidade; exigir comparadores mecânicos adequados; E0 documento explicitamente canônico, E1 fontes atuais coerentes, E2 inferência por benchmark, E3 provisório; se dados mecânicos insuficientes, registrar INSUFICIENTE. Não use esse resumo como substituto definitivo do Atlas para canonizar.

**Tarefa**: identificar todos os efeitos verificáveis no JPG, funcionamento narrado, efeitos que dependem de interpretação estrangeira, 3 classes de comparadores (ou pendência se inexistente), rank ou faixa PROPOSTA com grau E0-E3, contraprova, necessidade de conversão e custo PA desconhecido. Os elementos estrangeiros não convertem automaticamente para RD, fração, CA ou PA. Congele parecer e hash ANTES de qualquer consulta ao Atlas completo ou parecer anterior. Não canonizar.

Fonte do Atlas completo **não abra antes do congelamento**: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
Sistema de Combate: https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0
Sistema de Magia: https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373
DMG-RANK: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e

O material fornecido não contém a classificação anterior, as faixas anteriores, os nomes dos avaliadores nem relatórios Mestre-only R45-R48. A integridade do hash da imagem garante identidade de bytes, não independência psicológica.
