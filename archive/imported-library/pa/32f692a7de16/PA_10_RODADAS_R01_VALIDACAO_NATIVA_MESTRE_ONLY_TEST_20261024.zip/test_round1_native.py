"""Rodada 1/10: read-only tests against the EXISTING R26 and R22 implementation.
No new PA engine, no Notion writes. Original source remains in an extracted R51 snapshot.
"""
import hashlib,sys,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
B=ROOT/'working'/'baseline_r26'
sys.path.insert(0,str(B));sys.path.insert(0,str(B/'baseline_r25'/'baseline_r22'))
from parecer_semicanonico_r26 import avaliar,BASE as BASE26,FLOORS as FLOOR26
from rank_guard_r22 import Effect,estimate_new_item,tariff,BASE as BASE22,FLOOR as FLOOR22
RANKS=['Bronze','Prata','Ouro','Ouro Negro','Lendário']
BASE=[6,12,24,35,50];PASS=[6,12,24,35,50];DAY=[3,6,12,17,25];USE=[3,7,14,21,30];MIN=[8,11,21,35,90]
REPORT=[]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

class NativePA(unittest.TestCase):
 def test_00_source_snapshot_immutable(self):
  self.assertEqual(sha(B/'parecer_semicanonico_r26.py'),'7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8')
  self.assertEqual(sha(B/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py'),'b43305818e8424b1c4eee65f11858732c961a9ef024b941b09e94c8269003257')
 def test_01_five_rank_baselines(self):
  self.assertEqual([BASE26[x] for x in RANKS],BASE)
  self.assertEqual([BASE22[x] for x in RANKS],BASE)
  self.assertEqual([FLOOR26[x] for x in RANKS],MIN)
  self.assertEqual([FLOOR22[x] for x in RANKS],MIN)
  self.assertEqual([tuple(tariff(x).values()) for x in RANKS], list(zip(PASS,DAY,USE)))
 def test_02_native_scenarios_10(self):
  for i,rank in enumerate(RANKS):
   for kind in ['PASSIVA','ATIVA']:
    with self.subTest(rank=rank,kind=kind):
     txt=(f'Item: Talismã Testado\nRank do item: {rank}\n'
          f'Habilidade passiva {rank}: Luz: Enquanto equipado, emite luz fraca.' if kind=='PASSIVA' else
          f'Item: Talismã Testado\nRank do item: {rank}\n'
          f'Habilidade ativa {rank}: Feixe: Com uma ação padrão, causa dano contra um inimigo.')
     name='Luz' if kind=='PASSIVA' else 'Feixe'
     uses=0 if kind=='PASSIVA' else 2
     native=avaliar(txt,usos={name:uses} if uses else None)
     pa=native['r26']['cenario_pa']
     actual=native['r26']['pareceres'][0]
     older=estimate_new_item(rank,[Effect(name,rank,kind,'E3',uses)])
     expect_daily=max(MIN[i], PASS[i] if kind=='PASSIVA' else DAY[i])
     expect_use=0 if kind=='PASSIVA' else 2*USE[i]
     self.assertEqual(actual['rank_efeito_recomendado'],rank)
     self.assertEqual(actual['pa_dia_pelo_rank_proposto'],PASS[i] if kind=='PASSIVA' else DAY[i])
     self.assertEqual(actual['pa_uso_pelo_rank_proposto'],0 if kind=='PASSIVA' else USE[i])
     self.assertEqual((pa['pa_dia'],pa['pa_ativacoes'],pa['total_dia']),(expect_daily,expect_use,expect_daily+expect_use))
     self.assertEqual((older['day'],older['activations'],older['total']),(pa['pa_dia'],pa['pa_ativacoes'],pa['total_dia']))
     self.assertEqual(pa['rank_item'],rank)
     self.assertEqual(native['r26']['producao'],'HOLD')
     self.assertFalse(native.get('canonical_write'))
     self.assertFalse(native.get('official_classification'))
     self.assertIn('E3',pa['natureza'])
     REPORT.append({'item_rank':rank,'effect_rank':rank,'kind':kind,'uses':uses,'native_r26':{'day':pa['pa_dia'],'activations':pa['pa_ativacoes'],'total':pa['total_dia']},'native_r22':{'day':older['day'],'activations':older['activations'],'total':older['total']},'comparison':'MATCH','status':'TEST_E3_NOT_PROD'})
 def test_03_historical_cost_not_repriced(self):
  x=avaliar('Item: Bota Caminho Veloz\nRank do item: Ouro\nHabilidade ativa: Velocidade: +8m\n18 PA por dia',origem='HISTORICO')
  self.assertEqual(x['r26']['veredito'],'ANALISE_HISTORICA_SEM_REPRECIFICACAO')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_04_wrong_rank_item_cannot_produce_valid_total(self):
  x=avaliar('Item: Espada\nRank do item: Bronze\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano em um único alvo.')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_05_insufficient_effect_mechanics_stays_unpriced(self):
  x=avaliar('Quero um anel que torna invisível e também teletransporta inimigos.')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_06_numeric_bonus_with_floor(self):
  x=avaliar('Item: Manoplas\nRank do item: Prata\nBônus: +2 FOR')
  self.assertEqual(x['r26']['cenario_pa']['pa_dia'],11)
 def test_07_duplicate_effect_ids_rejected_older_native(self):
  from rank_guard_r22 import GateError
  with self.assertRaises(GateError):
   estimate_new_item('Ouro',[Effect('same','Bronze','PASSIVA','E3'),Effect('same','Prata','ATIVA','E3',1)])

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(NativePA)
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 assert result.wasSuccessful()
 assert len(REPORT)==10
 obj={'checkpoint':'PA-10-R01','source':'native R26 + native R22 as packaged in unmodified PA R51 source','scenario_cases':len(REPORT),'unittest_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'source_sha256':{'r26':sha(B/'parecer_semicanonico_r26.py'),'r22':sha(B/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py')},'cases':REPORT,'production':'HOLD','official_decisions':0,'remote_writes':0,'interpretation':'No canonical RE certification or PA actual expenditure. Reference contract from Mestre errata and E3 calculation.'}
 out=ROOT/'R01_NATIVE_SCENARIOS.json'
 out.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 print('OUTPUT',out)
