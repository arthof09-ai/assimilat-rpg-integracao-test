# PSV — PA / Rodada 1 de 10 — Checkpoint MESTRE-ONLY / TEST

**Data:** 24/10/2026. **Função:** Comestre Sistema Universal de PA, MESTRE-SIDE. **Operação existente:** cálculo e consulta universal PA para o CRAFT, com prazo expresso do Mestre de no máximo 10 rodadas de execução. **Contador pós-rodada:** `1/10 executada`, `9/10 restantes`. Consultas preparatórias e perguntas do Mestre não consumiram contagem. Não iniciar nova OP, não substituir R26/R27, não assumir COMESTRE-ID/writer/lease/epoch não validados.

## MISSÃO / ANTES

O Mestre considera o PA suficiente para aplicação geral; demandou prova de uso e liberação ordenada ao CRAFT em até 10 rodadas, sem caça indefinida de pendências. Estado ANTES comprovado em checkpoint preparatório `PA_PREPARACAO_10_RODADAS_MESTRE_ONLY_20261024.md`; R71 QA e Biblioteca prévios; R26/R27 não reexecutados na preparação. Notion Mestre PR-ITEM-02, handoff R29–R39 e LONG-RUN-01 foram reabertos nesta rodada, com precedência da errata Mestre de 20/10: motor R26/R27 CORRETO; pré-validador CRAFT v1.1 fora incorreto e teve corrigenda v1.2. Sem escrita Notion, Party ou CRAFT.

## DEPOIS — TESTES FÍSICOS REALMENTE EXECUTADOS

1. **Fonte original congelada R26:** recuperada do R51 preexistente `PA_R51_FENCE_PROVENIENCIA_R39_MESTRE_ONLY_TEST_20261021.zip`, SHA-256 `635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f`, 114 membros, manifesto **113/113 SHA PASS**, ZIP **CRC PASS**. `baseline_r26/parecer_semicanonico_r26.py` SHA `7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8`. Módulo nativo anterior R22 `rank_guard_r22.py` SHA `b43305818e8424b1c4eee65f11858732c961a9ef024b941b09e94c8269003257`. Origens intocadas.
2. **Replay R51 físico:** `run_cold.py` executado na extração local: 35/35 novos R51 e 26/26 nativos R26; comparou resultados congelados R50 byte-identical. **61/61 métodos de teste PASS**. A nota R39 de `510/510` é evidência histórica **NÃO reexecutada** nesse replay.
3. **Regressão herdada R22–R25:** primeira tentativa 162/163 aprovações com um ERRO causado pela ausência de `/mnt/data/pa_r21_work/ATIVACOES_HISTORICAS_R21.csv`. CSV foi encontrado no histórico imutável `BASELINE_R23_IMUTAVEL.zip`, membro `compat_r21/ATIVACOES_HISTORICAS_R21.csv`, SHA `e70cb8774e0a5e4ba8704c4007c660363b3860222cc01febb9a83b0290315532`. A fixture original foi restaurada *temporariamente*, a suíte foi reexecutada **163/163 PASS**, e a pasta criada foi removida. **Sem alteração do teste nem da lógica nativa**. A primeira falha ambiental é preservada, não apagada.
4. **R01 teste nativo novo:** `test_round1_native.py` executou **8/8 métodos PASS**, incluindo matriz de dez invocações reais a `parecer_semicanonico_r26.avaliar` nos cinco ranks com passivas e ativas ×2 usos. A saída R26 coincidiu exatamente com `rank_guard_r22.estimate_new_item` em **10/10 cenários**. Tarifas base 6/12/24/35/50; passiva 100%; ativa/dia floor 50%; ativa/uso floor 60%; piso item 8/11/21/35/90. Histórico não reprecificado; rank item inferior ao efeito não gera total legitimado; mecânica insuficiente não gera PA fechado; bônus numérico +2 FOR Prata respeitou piso 11; duplicação de ID recusada.
5. **Replay autocontido adicional:** `R01_REPLAY_COLD.py` usa arquivo R51 original embutido e reexecutou, em diretório temporário limpo, os blocos 61+163+8, restaurando e removendo fixture R21; saída dos dez casos **byte-idêntica** ao JSON congelado `R01_NATIVE_SCENARIOS.json`, SHA `70d37d13dde6345777c6803b2045f36bed6652a4e06ad3f4c1bd44b70fb1687e`.

**Contagem sem duplicação entre suítes:** `61 + 163 + 8 = 232/232 métodos TEST PASS`. Os dez cenários são subcasos do método R01 `test_02_native_scenarios_10`, portanto **não adicionar 10 novamente ao numerador 232**. O replay frio é conferência de reproduzibilidade dos mesmos testes, NÃO outro conjunto de 232. Sem reexecução nativa independente de R27 nesta rodada.

### Tabela de cenários R26/R22 concordantes

| Item=efeito | Passiva PA/dia total | Ativa PA/dia, 2 usos, total cenário |
|---|---:|---:|
| Bronze | 8 | 8 + 6 = 14 |
| Prata | 12 | 11 + 14 = 25 |
| Ouro | 24 | 21 + 28 = 49 |
| Ouro Negro | 35 | 35 + 42 = 77 |
| Lendário | 90 | 90 + 60 = 150 |

## CLASSIFICAÇÃO E GATES

**VERIFICADO em TEST:** bytes da fonte R51 e 113 checksums, 232/232 métodos PASS, 10/10 exemplos R26↔R22, restauração reversível de fixture, resultado do replay frio, Notion PR-ITEM/handoff reabertos. **DOCUMENTADO, NÃO REEXECUTADO:** R39 510/510, R27→R26 integração de consulta, CRAFT v1.2 errata. **PENDENTE:** localizar/reexecutar o executável nativo R27 do fornecedor ou fazer reconciliação proporcional com evidência de integração já existente; casos compostos/ranks cruzados/pisos/bônus/entradas inválidas em matriz R02; TEE PROD não comprovado. **HOLD:** F5 RED, C19-021 UNKNOWN, RC5 físico, writer/lease/epoch CRAFT, homologação RE/E0 individual, pareceres independentes 0/14. **Sem escrita:** Party/O Primeiro, Notion Mestre, fichas, receitas, runtime CRAFT, custos históricos, registros E0.

## FRONTEIRA DE RETOMADA — PRÓXIMA RODADA 2/10

**LAST-VERIFIED:** PA-R01, 232/232 PASS e reexecução fria reprodutível, R26/R22 imutáveis. **FIRST-PENDING:** R02 — matriz positiva/negativa de usos reais com múltiplos efeitos, ranks distintos RI/RE, pisos, bônus, cenários de custo desconhecido e histórico. **NEXT:** (1) revalidar este checkpoint/cópia Biblioteca/contador e os hashes fontes; (2) procurar **dirigidamente** o R27 original sem reconstruí-lo, marcando `PENDENTE` caso não recuperável; (3) executar matriz R02 por chamada original `R26.avaliar` e/ou `R22.estimate_new_item` com oráculos canônicos; (4) testar entradas malformadas/gates, casos compostos e conferir resultados; (5) preservar evidência, registrar R02, preparar R03; sem mudar CRAFT/Notion se writer ausente. **NO-REPEAT:** não reimplementar motor; não executar 232 regressões repetidamente sem necessidade, exceto regressão fria quando mudança/risk exigir; não reabrir errata 50%/60%, R66–R71 ou pareceres 14 como precondição universal.

## REPRODUÇÃO E SUCESSÃO

O pacote R01 contém `SOURCE_PA_R51_FROZEN.zip` (**fonte histórica imutável para reprodução, NÃO outro motor**), `R01_REPLAY_COLD.py`, `test_round1_native.py`, `replay_legacy_fixture.py`, matriz JSON, logs, hashes e checkpoint. Num diretório com Python 3.11+ sem biblioteca extra: `python R01_REPLAY_COLD.py`. Esta chamada extrai fonte congelada para `tempfile`, executa três blocos, restaura apenas durante o teste o CSV R21 de caminho absoluto, remove tudo e compara SHA do resultado. **Se `/mnt/data/pa_r21_work` já existir, o replay se recusa a escrever ali.** Não modificar originais, não promover resultado E3 em E0.

**NAC-PASS proporcional:** PASS-TEST somente para integridade/replay aritmético descritos; **PROD/HOMOLOGAÇÃO RE/CRAFT continuam NÃO APROVADOS**. Se o arquivo não estiver na Biblioteca ou readback não coincidir, marcar persistência HOLD e preservar arquivo local sem declarar upload.
