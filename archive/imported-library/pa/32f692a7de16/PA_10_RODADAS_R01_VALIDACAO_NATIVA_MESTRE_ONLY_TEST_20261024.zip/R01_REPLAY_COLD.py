"""Self-contained read-only TEST proof from the immutable R51 archive.
R26/R22 source stays unmodified. Never operates in Notion/Party/CRAFT production.
"""
from pathlib import Path
import hashlib,zipfile,shutil,tempfile,subprocess,os,sys,json
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'SOURCE_PA_R51_FROZEN.zip'
EXPECTED_SHA='635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def run(*args,cwd=None):
 p=subprocess.run([sys.executable,*args],cwd=cwd,env=os.environ.copy(),capture_output=True,text=True)
 if p.returncode:raise RuntimeError(f'FAIL {args} (rc={p.returncode})\n{p.stdout[-2400:]}\n{p.stderr[-2400:]}')
 return p.stdout+'\n'+p.stderr

def main():
 assert sha(SRC)==EXPECTED_SHA, 'WRONG_SOURCE_SHA'
 with tempfile.TemporaryDirectory(prefix='pa_r01_clean_') as tmp:
  folder=Path(tmp)
  target=folder/'working';target.mkdir()
  with zipfile.ZipFile(SRC) as z:
   assert z.testzip() is None
   for x in z.namelist():
    dest=(target/x).resolve()
    assert dest.is_relative_to(target.resolve()),'ZIP_TRAVERSAL'
   z.extractall(target)
  for name in ['test_round1_native.py','replay_legacy_fixture.py']:
   shutil.copy2(ROOT/name,folder/name)
  out1=run('run_cold.py',cwd=target)
  assert '"R51_new_tests": 35' in out1 and '"native_R26_tests": 26' in out1
  out2=run('replay_legacy_fixture.py',cwd=folder)
  assert 'Ran 163 tests' in out2 and 'OK' in out2
  out3=run('test_round1_native.py',cwd=folder)
  assert 'Ran 8 tests' in out3 and 'OK' in out3
  frozen=ROOT/'R01_NATIVE_SCENARIOS.json'
  assert (folder/frozen.name).read_bytes()==frozen.read_bytes(),'R01_NATIVE_OUTPUT_CHANGED'
  return {'cold_replay':'PASS','r51_tests':35,'r26_tests':26,'r22_r25_inherited_tests':163,'r01_methods':8,'r01_scenarios':10,'total_unittest_methods_unique':232,'source_archive_sha256':sha(SRC),'R01_scenarios_sha256':sha(frozen),'fixture_restored_then_deleted':not Path('/mnt/data/pa_r21_work').exists(),'offline_only':True,'production_write':0,'canonical_PA_change':0}

if __name__=='__main__':
 result=main()
 print(json.dumps(result,sort_keys=True,ensure_ascii=False))
