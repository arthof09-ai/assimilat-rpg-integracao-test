from pathlib import Path
import hashlib,zipfile,subprocess,sys,os,json
root=Path(__file__).resolve().parent
source=root/'working/baseline_r26/baseline_r25/BASELINE_R23_IMUTAVEL.zip'
target=Path('/mnt/data/pa_r21_work/ATIVACOES_HISTORICAS_R21.csv')
assert not target.parent.exists(), 'REFUSE_TO_CHANGE_EXISTING_LEGACY_PATH'
with zipfile.ZipFile(source) as z:
 assert z.testzip() is None
 raw=z.read('compat_r21/ATIVACOES_HISTORICAS_R21.csv')
sha=hashlib.sha256(raw).hexdigest()
target.parent.mkdir(parents=True)
try:
 target.write_bytes(raw)
 assert target.read_bytes()==raw
 cwd=source.parent
 env=os.environ.copy();env['PYTHONPATH']=str(cwd)+os.pathsep+str(cwd/'baseline_r22')
 cmd=[sys.executable,'-m','unittest','-q','test_r25_qualidade','test_integracao_r24','test_motor_conversacional_r24','test_alcance_mestre_r23','test_ponte_pa_r23','baseline_r22.test_rank_guard_r22']
 r=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True)
 record={'source_archive':str(source),'fixture_member':'compat_r21/ATIVACOES_HISTORICAS_R21.csv','fixture_sha256':sha,'fixture_bytes':len(raw),'command':' '.join(cmd),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'ephemeral_fixture':True}
 (root/'r25_r22_legacy_restored.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
 print(r.stderr[-1500:]);print('EXIT',r.returncode,'fixture SHA',sha)
finally:
 target.unlink(missing_ok=True)
 target.parent.rmdir()
 assert not target.exists()
if r.returncode:raise SystemExit(r.returncode)
