"""R50 experimental read-only input gate in front of existing R26.

It NEVER mutates upstream R26 or claims source provenance proved by a URL.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, re
from urllib.parse import urlsplit, unquote

UUID_RE=re.compile(r'^[0-9a-f]{32}$')
VALID_ROLES=('sistemico','vivo','familia')

@dataclass(frozen=True)
class Verdict:
    eligible: bool
    state: str
    unique_sources: tuple[str,...]
    direct_sources: tuple[str,...]
    reasons: tuple[str,...]
    sanitized_comparators: tuple[dict,...]


def notion_id(url:str)->str:
    if not isinstance(url,str) or len(url)>512 or '\\' in url or any(ord(c)<32 for c in url):
        raise ValueError('SOURCE_URL_INVALID')
    p=urlsplit(url)
    if p.scheme!='https' or p.netloc!='app.notion.com' or p.username or p.password or p.fragment:
        raise ValueError('NOTION_ORIGIN_INVALID')
    if not re.fullmatch(r'/p/(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})/?',p.path,flags=re.I):
        raise ValueError('NOTION_PATH_INVALID')
    if p.query and not re.fullmatch(r'pvs=(?:204|205|206|207)',p.query):
        raise ValueError('NOTION_QUERY_UNTRUSTED')
    slug=p.path.split('/')[2].replace('-','').lower()
    if not UUID_RE.fullmatch(slug):raise ValueError('SOURCE_UUID_INVALID')
    return slug


def source_registry(path:Path)->dict:
    doc=json.loads(path.read_text(encoding='utf-8'))
    sources=doc['sources']
    ids=[x['id'] for x in sources]
    if len(ids)!=len(set(ids)):raise ValueError('SOURCE_REGISTRY_DUPLICATE_UUID')
    if not all(UUID_RE.fullmatch(i) for i in ids):raise ValueError('SOURCE_REGISTRY_INVALID_UUID')
    if any(x.get('anchor_checked_in_Notion_fetch_on')!='2026-10-21' or x.get('anchor_match_readback') is not True or not x.get('last_edited_at_from_Notion_fetch','').endswith('Z') for x in sources):
        raise ValueError('SOURCE_ANCHOR_NOT_VERIFIED_IN_CHECKPOINT')
    if any(x.get('effect_rank_adjudicated') is not False for x in sources):
        raise ValueError('NO_INDEPENDENT_EFFECT_RANK_VERIFIED')
    return {r['id']:r for r in sources}


def fence(comparators:list[dict], registry:dict, *, effect_mechanism:str)->Verdict:
    """Only assert safe-to-forward evidence count; never prove semantic correctness."""
    reasons=[];found={};all_ids=[];lineage_seen=set();direct=[]
    for c in comparators:
        try: uid=notion_id(c['url'])
        except (KeyError,ValueError,TypeError) as exc:
            reasons.append('URL_INVALID_OR_UNTRUSTED');continue
        src=registry.get(uid)
        if src is None:
            reasons.append('SOURCE_NOT_IN_FETCHED_REGISTRY');continue
        family=src.get('lineage_group',uid)
        role=c.get('tipo')
        if role not in VALID_ROLES or role!=src['role']:
            reasons.append('ROLE_MISMATCH_OR_NOT_PROVEN');continue
        explanatory=c.get('comparacao_mecanica','')
        if not isinstance(explanatory,str) or len(explanatory.strip())<24:
            reasons.append('MECHANICAL_COMPARISON_ABSENT');continue
        anchor=c.get('source_anchor')
        if not isinstance(anchor,str) or anchor!=src['verbatim_anchor']:
            reasons.append('SOURCE_QUOTE_MISMATCH');continue
        # Only *accepted* evidence can reserve this UUID. Otherwise, a forged or
        # erroneous first occurrence suppresses legitimate later evidence.
        if uid in all_ids:
            reasons.append('UUID_DUPLICATE_VARIANT_QUERY');continue
        if family in lineage_seen:
            reasons.append('MIRROR_TEXT_REPRESENTATION_NOT_INDEPENDENT');continue
        all_ids.append(uid)
        lineage_seen.add(family)
        found[uid]={'url':'https://app.notion.com/p/'+uid,
                    'tipo':role,'comparacao_mecanica':explanatory}
        # Matching mechanism alone is not sufficient for RE; comparator's isolated rank
        # must itself be adjudicated, currently none in this registry.
        if src['mechanism']==effect_mechanism and src['effect_rank_adjudicated']:
            direct.append(uid)
    if not found:reasons.append('ZERO_USABLE_RESEARCH')
    if len(direct)<2:reasons.append('FAMILY_MATCH_RANK_COMPARATORS_INSUFFICIENT')
    return Verdict(bool(found),'EVIDENCE_FOR_ADVISORY_ONLY' if found else 'HOLD_INPUT',
                   tuple(found),tuple(direct),tuple(dict.fromkeys(reasons)),tuple(found.values()))


def sanitize_for_r26(ability_name:str, proposed_rank:str, justification:str,
                     comparisons:list[dict],registry:dict,mechanism:str)->dict:
    v=fence(comparisons,registry,effect_mechanism=mechanism)
    if not v.eligible:
        return {'pesquisa':{},'fence':v}
    # Passing a semicanonical rank remains only a proposal; it is not a certified RE.
    research={ability_name:{'rank_sugerido':proposed_rank,'justificativa':justification,
                  'comparadores':list(v.sanitized_comparators)}}
    return {'pesquisa':research,'fence':v}


def wrap_native_result(native:dict,check:Verdict)->dict:
    """Protect downstream integrations from treating R26 estimated scenario as authorized PA."""
    summary=[{'ability':p.get('habilidade'),'candidate':p.get('rank_efeito_recomendado'),
              'native_status':p.get('estado'),'native_confidence':p.get('confianca')}
             for p in native.get('r26',{}).get('pareceres',[])]
    return {'native_advisory_summary':summary,
            'source_gate':{'state':check.state,'independent_page_count':len(check.unique_sources),
                'effect_rank_adjudicated_source_count':len(check.direct_sources),'reasons':check.reasons},
            'canonical_RE':None,'authorized_pa_daily':None,'authorized_pa_use':None,
            'physical_item_produced':False,'read_only':True,
            'status':'TEST_ADVISORY_NO_CANONICAL_PROMOTION'}
