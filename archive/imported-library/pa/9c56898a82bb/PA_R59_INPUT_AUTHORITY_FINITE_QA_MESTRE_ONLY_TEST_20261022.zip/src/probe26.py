"""Strict rank-free 26 mechanical summaries passed to original R26 without pesquisa.

This is not an evaluation of authoritative accuracy: source is R45 manual summaries,
not the original card images directly, and native R26 has no official rank oracle.
"""
import json,sys
from pathlib import Path
from runner import prepare

ALLOWED={'case_id','visual_mechanic_summary','effect_family','source_damage_expression','source_duration',
         'source_activation','source_range','target_count_or_area','observed_mechanic_facts',
         'source_save','explicit_source_image_sha256'}

def corpus(root:Path):
    raw=json.loads((root/'fixtures/visual_mechanics26_no_ranks.json').read_text())
    if raw['n']!=26 or len(raw['cases'])!=26:raise ValueError('NOT_26')
    ids=[r['case_id'] for r in raw['cases']]
    if len(set(ids))!=26:raise ValueError('DUPLICATE_ID')
    for c in raw['cases']:
        if set(c)!=ALLOWED:raise ValueError('RANK_OR_EXTRA_FIELD_LEAKAGE')
        if not isinstance(c['case_id'],str) or not c['case_id'].startswith('TEC-'):raise ValueError('ID_INVALID')
    return raw['cases']

def description(c):
    facts=[f'Mecânica: {c["visual_mechanic_summary"]}.',f'Condições: {c["observed_mechanic_facts"]}.']
    for k,label in [('source_damage_expression','Dano na fonte'),('source_duration','Duração na fonte'),
                    ('source_activation','Ação na fonte'),('source_range','Alcance na fonte'),
                    ('target_count_or_area','Alvos/área'),('source_save','Salvaguarda da fonte')]:
        if c.get(k) is not None:facts.append(f'{label}: {c[k]}.')
    return f'Item: Amostra experimental sem rank\nHabilidade ativa: Técnica importada: '+ ' '.join(facts)

def run(root:Path,engine:Path):
    evaluate,_=prepare(engine)
    rec=[]
    for c in corpus(root):
        raw=evaluate(description(c),pesquisa={})
        p=raw['r26']['pareceres']
        # R26 is a native advisor, no inferred costs are exported from this runner.
        rec.append({'case_id':c['case_id'],'image_sha256':c['explicit_source_image_sha256'],
          'ability_count':len(p),'native_candidates':[{'candidate':x.get('rank_efeito_recomendado'),
            'native_confidence':x.get('confianca'),'status':x.get('estado')} for x in p],
          'production_item_rank':None,'authoritative_RE':None,'authorized_PA':None})
    return {'source_scope':'PA_R45_MANUAL_IMAGE_SUMMARIES_FIELDS_ONLY_NO_RANKS',
       'n':len(rec),'rows':rec,
       'native_rank_candidates':sum(any(x.get('candidate') for x in r['native_candidates']) for r in rec),
       'authoritative_RE_finalized':0,'PA_authorized':0,
       'interpretation':'Indicates parser and automatic RE candidate coverage only; no gold label evaluation or model promotion.'}
