"""R52 experimental adapter for the *existing* R26; no production auth.

Strict source pinning, separate mechanical source suitability from evidence of
an adjudicated effect rank, and track unknown physical outcomes as UNKNOWN.
No native RPG rules or recipes are changed by this module.
"""
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path
from typing import Any
from source_fence import source_registry, fence, sanitize_for_r26

EXPECTED_REGISTRY_SHA='82d32f7349a4ebc96904a879d0562aab2b396a1f2e4d6df432415ae429eae25c'
EXPECTED_R26_SHA='7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8'
VALID_RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário')
ROOT=Path(__file__).resolve().parents[1]

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def pinned_registry(path:Path|None=None)->dict:
    """Enforce the R51 registry snapshot. Future sources require intentional release."""
    path=Path(path or ROOT/'fixtures/sources.json')
    if sha(path)!=EXPECTED_REGISTRY_SHA:
        raise ValueError('REGISTRY_NOT_PINNED_REVIEW_REQUIRED')
    return source_registry(path)

def verify_native(path:Path|None=None):
    path=Path(path or ROOT/'baseline_r26/parecer_semicanonico_r26.py')
    if sha(path)!=EXPECTED_R26_SHA:
        raise ValueError('R26_NATIVE_HASH_MISMATCH')
    return True

def stage_effect_e0_claim(claim:dict, registry:dict)->dict:
    """An E0 *claim* can be recorded for review; never self-certifies an RE.

    A source URL/Notion page, title, item/actor rank or model assertion do not
    prove isolated effect rank, competent authority, or source freshness.
    """
    if not isinstance(claim,dict): raise ValueError('CLAIM_MUST_BE_OBJECT')
    c_id=claim.get('source_uuid')
    known=c_id in registry if isinstance(c_id,str) else False
    rank=claim.get('proposed_effect_RE')
    evidence=claim.get('effect_mechanics_quote')
    authority=claim.get('authorizing_master_decision_id')
    errors=[]
    if not known: errors.append('SOURCE_NOT_IN_PINNED_REGISTRY')
    if rank not in VALID_RANKS: errors.append('INVALID_EFFECT_RANK_CLAIM')
    if not isinstance(evidence,str) or len(evidence.strip())<40:
        errors.append('ISOLATED_MECHANICS_EVIDENCE_INSUFFICIENT')
    if not isinstance(authority,str) or not re.fullmatch(r'[A-Z0-9][A-Z0-9_.:-]{5,127}',authority):
        errors.append('MASTER_DECISION_REFERENCE_ABSENT')
    if known:
        src=registry[c_id]
        if src.get('effect_rank_adjudicated') is not False:
            errors.append('PINNED_REGISTRY_INCONSISTENT')
        if src.get('rank_scope','').startswith(('actor_rank','item_aggregate')):
            errors.append('RN_OR_RI_CANNOT_PROVE_ISOLATED_RE')
    # Merely declaring a decision ID does not authenticate the human decision.
    # A separate authorized readback and formal gate must update a NEW registry.
    return {'state':'REJECT_INCOMPLETE_E0_CLAIM' if errors else 'HOLD_EXTERNAL_AUTHORITY_READBACK',
       'errors':errors,'claim_source_uuid':c_id,'claim_rank':rank if rank in VALID_RANKS else None,
       'authorizing_decision_reference':authority if isinstance(authority,str) else None,
       'source_is_registered':known,'authority_verified':False,
       'isolated_RE_E0_verified':False,'sufficient_to_promote':False,
       'next':'Verify authority and exact isolated effect mechanics in live canonical Notion; release a new registry with a verified changed scope, then rerun governances gates.'}

def source_freshness_readback(observations:dict, registry:dict)->dict:
    """Check exact source censo, anchor & last_edited; never auth E0 or future state."""
    if not isinstance(observations,dict) or not isinstance(observations.get('observations'),list):
        raise ValueError('READBACK_SCHEMA_INVALID')
    obs=observations['observations']
    by_id={}
    for row in obs:
        if not isinstance(row,dict) or row.get('id') in by_id:
            raise ValueError('READBACK_DUPLICATE_OR_INVALID_ROW')
        by_id[row.get('id')]=row
    failures=[]
    if set(by_id)!=set(registry): failures.append('READBACK_CENSUS_DIFFERENT')
    for uid,ref in registry.items():
        row=by_id.get(uid)
        if row is None:continue
        if row.get('page_last_edited_at')!=ref.get('last_edited_at_from_Notion_fetch'):
            failures.append('PAGE_EDITED_SINCE_SOURCE_SNAPSHOT:'+uid)
        if row.get('verbatim_anchor')!=ref.get('verbatim_anchor') or row.get('anchor_present_in_fetched_text') is not True or row.get('truncated') is not False:
            failures.append('MECHANICAL_ANCHOR_MISMATCH_OR_TRUNCATION:'+uid)
    return {'status':'REFERENCE_READBACK_STABLE_ASOF_DATE_ONLY' if not failures else 'HOLD_SOURCE_REFRESH_REQUIRED',
            'date':observations.get('asof_date'), 'n_registered':len(registry),
            'n_observed':len(by_id),'failures':failures, 'continuous_source_authentication':False,
            'certifies_individual_effect_RE':False}

def assess(case:dict, registry:dict)->dict:
    if not isinstance(case,dict): raise ValueError('CASE_MUST_BE_OBJECT')
    for k in ('case_id','ability','description','peer','justification','mechanism','sources'):
        if k not in case: raise ValueError('CASE_FIELD_MISSING_'+k)
    if case['peer'] not in VALID_RANKS:
        raise ValueError('UNSUPPORTED_PROPOSED_RANK')
    if not isinstance(case['sources'],list) or len(case['sources'])>30:
        raise ValueError('CASE_SOURCES_INVALID')
    srcs=[]
    for uid in case['sources']:
        if not isinstance(uid,str) or uid not in registry:
            raise ValueError('CASE_SOURCE_OUTSIDE_PINNED_REGISTRY')
        z=registry[uid]
        srcs.append({'url':'https://app.notion.com/p/'+uid,
                     'tipo':z['role'],'source_anchor':z['verbatim_anchor'],
                     'comparacao_mecanica':z['qualifier']})
    rv=sanitize_for_r26(case['ability'],case['peer'],case['justification'],srcs,registry,case['mechanism'])
    sys.path.insert(0,str(ROOT/'baseline_r26'))
    sys.path.insert(0,str(ROOT/'baseline_r26/baseline_r25'))
    from parecer_semicanonico_r26 import avaliar
    native=avaliar(case['description'],pesquisa=rv['pesquisa'])
    ns=[{'name':p.get('habilidade'),'proposed_rank_native':p.get('rank_efeito_recomendado'),
         'native_confidence':p.get('confianca'), 'native_state':p.get('estado')}
        for p in native.get('r26',{}).get('pareceres',[])]
    return {'case_id':case['case_id'],'state':'ADVISORY_ONLY_INCOMPLETE_E0_SUPPORT',
        'native_r26_outputs':ns,
        'unique_source_count':len(rv['fence'].unique_sources),
        'isolated_E0_comparators':len(rv['fence'].direct_sources),
        'evidence_live_verified_at_current_run':False,
        'evidence_snapshot_asof':'2026-10-21',
        'canonical_RE':None,'authorized_pa_daily':None,'authorized_pa_use':None,
        'real_pa_consumed':None,
        'physical_item_produced':None,'magical_effect_installed':None,
        'production_attempted_by_this_test':False,'source_normalization_pass':rv['fence'].eligible,
        'scientific_correctness_verified':False,'notion_write':False,'party_write':False,
        'authority_approval':None,
        'note':'Native confidence is NOT individual-effect RE evidence or production approval.'}

def generate(root:Path=ROOT):
    verify_native(root/'baseline_r26/parecer_semicanonico_r26.py')
    reg=pinned_registry(root/'fixtures/sources.json')
    raw=json.loads((root/'fixtures/four_cases.json').read_text('utf-8'))['cases']
    if len(raw)!=4 or len({c['case_id'] for c in raw})!=4:
        raise ValueError('FOUR_CASE_CENSUS_INVALID')
    out=[assess(case,reg) for case in raw]
    return {'checkpoint':'PA_R52_GATEWAY_TEST','source_hash':EXPECTED_REGISTRY_SHA,
           'native_r26_hash':EXPECTED_R26_SHA,'n':len(out),'records':out,
           'canonical_RE_authorized':0,'pa_authorized':0,'material_actions':0,
           'future_E0_intake_status':'STAGING_WITH_OUT_OF_BAND_AUTHORITY_VALIDATION_REQUIRED',
           'no_remote_writes':True}

if __name__=='__main__':
    print(json.dumps(generate(),sort_keys=True,ensure_ascii=False,indent=2))
