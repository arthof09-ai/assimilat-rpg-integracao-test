"""R53 dated readback attestation of existing R52, not another PA motor.

The authoritative source observations must be made outside this offline code.
A matching snapshot is NOT a signature, an effect-rank decision, or PROD.
"""
from __future__ import annotations
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from gateway_r52 import pinned_registry,source_freshness_readback,sha,verify_native
PARENT_R52_SHA='01ad80ddf0a650e733d02a34ff0f28a629f1833da8cb133b92fbf19c1bdfb282'


def audit_readback(doc:dict,registry:dict,*,inspection_date:str='2026-10-22')->dict:
    if not isinstance(doc,dict) or doc.get('asof_date')!=inspection_date or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',inspection_date):
        raise ValueError('READBACK_DATE_MISMATCH_OR_UNVERIFIED')
    if doc.get('source')!='Notion direct fetch, account MESTRE, 13 page IDs, manually reconciled outputs':
        raise ValueError('READBACK_SOURCE_CLASS_UNEXPECTED')
    if doc.get('no_official_writes') is not True:
        raise ValueError('READBACK_WRITER_SCOPE_INCONSISTENT')
    if doc.get('e0_individual_effect_adjudicated')!=0:
        raise ValueError('E0_CLAIM_NOT_SUPPORTED_BY_COHORT')
    observations=doc.get('observations')
    if not isinstance(observations,list):raise ValueError('READBACK_OBSERVATIONS_INVALID')
    unknown_truncation=[]
    invalid=[]
    for row in observations:
        if not isinstance(row,dict) or not isinstance(row.get('id'),str):
            raise ValueError('READBACK_INVALID_ID')
        if row.get('truncated') is None or row.get('truncation_metadata_reported') is not True:
            unknown_truncation.append(row['id'])
        if row.get('anchor_presence_method')!='literal_found_in_fetched_page_text':
            invalid.append(row['id'])
    # Feed fail-closed statuses to existing R52 checker; never silently replace
    # an unreported truncation flag with false just to obtain a PASS.
    result=source_freshness_readback(doc,registry)
    matches=sum(1 for row in observations if row.get('id') in registry and
        row.get('page_last_edited_at')==registry[row['id']].get('last_edited_at_from_Notion_fetch') and
        row.get('verbatim_anchor')==registry[row['id']].get('verbatim_anchor') and
        row.get('anchor_present_in_fetched_text') is True)
    verified_exact=matches==len(registry)==len(observations) and not invalid
    return {'checkpoint':'PA_R53_READBACK_TEST','date':inspection_date,
       'source_count_expected':len(registry),'source_count_observed':len(observations),
       'source_text_and_version_matches':matches,
       'source_text_and_version_reconciled':verified_exact,
       'full_source_truncation_proved':len(unknown_truncation)==0,
       'truncation_metadata_unavailable_count':len(unknown_truncation),
       'r52_checker_status':result['status'],
       'status':'HOLD_FULL_SOURCE_PROOF_METADATA_UNAVAILABLE' if unknown_truncation else
           ('SOURCE_SNAPSHOT_MATCH_TEST_NOT_AUTHENTICATION' if verified_exact and not result['failures'] else 'HOLD_SOURCE_REFRESH_REQUIRED'),
       'e0_adjudications':0,'canonical_RE':None,'official_pa_authorized':None,
       'real_pa_consumed':None,'physical_item_produced':None,
       'continuous_source_authentication':False,'notion_write':False,'party_write':False,
       'adjudication_gate':'EXTERNAL_COMPETENT_AUTHORITY_REQUIRED',
       'limitations':'Notion tool fetch provided last-edited and matching excerpts, but no explicit truncation metadata/signature. No RE, costs or magic promoted.'}

def generate():
    verify_native()
    r=pinned_registry()
    data=json.loads((ROOT/'evidence/NOTION_READBACK_R53_ASOF_20261022.json').read_text('utf-8'))
    return audit_readback(data,r)

if __name__=='__main__':print(json.dumps(generate(),ensure_ascii=False,sort_keys=True,indent=2))
