"""R50 safe R26 adapter; must run ONLY in TEST with an immutable R42 source."""
from __future__ import annotations
import hashlib, json, os, sys
from pathlib import Path
from source_fence import source_registry,sanitize_for_r26,wrap_native_result

def sha(b):return hashlib.sha256(b).hexdigest()

def prepare(engine:Path):
    sys.path.insert(0,str(engine));sys.path.insert(0,str(engine/'baseline_r25'))
    from parecer_semicanonico_r26 import avaliar, _research_quality
    return avaliar,_research_quality

def generate(root:Path,engine:Path)->dict:
    avaliar,native_quality=prepare(engine)
    raw=json.loads((root/'fixtures/four_cases.json').read_text())
    registry=source_registry(root/'fixtures/sources.json')
    cases=[]
    for case in raw['cases']:
        comparisons=[]
        for sid in case['sources']:
            src=registry[sid]
            comparisons.append({'url':'https://app.notion.com/p/'+sid+'?pvs=204',
                'tipo':src['role'], 'source_anchor':src['verbatim_anchor'],
                'comparacao_mecanica':src['qualifier']})
        advisory=sanitize_for_r26(case['ability'],case['peer'],case['justification'],
                                   comparisons,registry,case['mechanism'])
        original=avaliar(case['description'],pesquisa=advisory['pesquisa'])
        protected=wrap_native_result(original,advisory['fence'])
        cases.append({'case_id':case['case_id'],'R45_frozen':case['R45'],
                      'peer_frozen':case['peer'],'source_count':len(advisory['fence'].unique_sources),
                      'n_effect_rank_adjudicated_comparators':len(advisory['fence'].direct_sources),
                      'source_gate':protected['source_gate'],
                      'provenance_per_source':[{'id':sid,'title':registry[sid]['title'],
                          'document_kind':registry[sid]['role'],'scope':registry[sid]['rank_scope'],
                          'mechanism':registry[sid]['mechanism'],
                          'equivalent_mechanism':registry[sid]['mechanism']==case['mechanism'],
                          'isolated_effect_RE_adjudicated':registry[sid]['effect_rank_adjudicated']}
                          for sid in case['sources']],
                      'native_advisory_summary':protected['native_advisory_summary'],
                      'canonical_RE':protected['canonical_RE'],
                      'authorized_pa_daily':protected['authorized_pa_daily'],
                      'authorized_pa_use':protected['authorized_pa_use'],
                      'status':protected['status']})
    u='https://app.notion.com/p/836c2b324ede83e2aae6016379ef2135'
    d=[{'url':u+'?pvs=204','tipo':'familia','source_anchor':'16 PA por dia','comparacao_mecanica':'Retaliação corpo a corpo depois de dano sofrido, uso de Reação com arma.'},
       {'url':u+'?pvs=205','tipo':'vivo','source_anchor':'16 PA por dia','comparacao_mecanica':'Retaliação corpo a corpo depois de dano sofrido, uso de Reação com arma.'}]
    before=native_quality(d)
    assert before['comparadores_documentados']==2 and before['tipos_distintos']==2
    from source_fence import fence
    after=fence(d,registry,effect_mechanism='REACTIVE_FIRE_SAVE_AT_RANGE')
    assert len(after.unique_sources)==1 and len(after.direct_sources)==0
    return {'scope':'R50_TEST_MESTRE_SIDE_NOT_RANK_AUTHORITY',
       'upstream_R42_SHA256':'6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800',
       'known_native_r26_duplicate_bug':{'old_doc_count':before['comparadores_documentados'],
          'old_distinct_types':before['tipos_distintos'], 'real_unique_UUID_count':len(after.unique_sources),
          'native_implementation_modified':False},
       'cases':cases,'count':len(cases),
       'canonical_RE_finalized':0,'PA_authorized':0,
       'notes':['As of Notion references were fetched on 2026-10-21; this script does not authenticate sources at replay time.',
          'Item rank, actor rank, normative document and individual effect rank remain different evidence kinds.',
          'R26 native PA scenarios must not be treated as authorized cost; neither source URLs nor AI agreement equal independent adjudication.']}

def store(root,engine):
    obj=generate(root,engine)
    p=root/'outputs'/'r50_results.json'
    p.write_text(json.dumps(obj,sort_keys=True,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return obj
