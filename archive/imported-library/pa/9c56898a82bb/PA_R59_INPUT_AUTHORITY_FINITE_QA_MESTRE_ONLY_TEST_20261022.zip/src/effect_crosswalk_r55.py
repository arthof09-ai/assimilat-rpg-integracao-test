"""R55 image-backed, provenance-preserving comparison: NEVER authorizes effect RE.
Not a classifier or new PA / DMG motor; only QA of externally inspected visual facts.
"""
from __future__ import annotations
import hashlib,json,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def verify_eight_images(crosswalk):
 rows=crosswalk['records'];errors=[]
 if len(rows)!=8 or len({r['case_id'] for r in rows})!=8:errors.append('8_INDEPENDENT_IMAGE_CASES_REQUIRED')
 for r in rows:
  path=ROOT/r['image_path']
  if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=r['original_image_sha256']:
   errors.append('IMAGE_SHA_FAIL:'+r['case_id'])
  if r.get('re_adjudicated_E0') is not False:errors.append('E0_CANNOT_BE_INFERRED_FROM_IMAGE:'+r['case_id'])
  if r.get('level_scaling')!='FOREIGN_LEVEL_NOT_ASSIMILACAO_RANK':errors.append('FOREIGN_LEVEL_SCALE_MISUSED:'+r['case_id'])
  if not all(r.get(k) for k in ['action_original','duration_original','range_original','observed_mechanic_family','notion_source_url']):
   errors.append('MECHANICS_OR_SOURCE_INCOMPLETE:'+r['case_id'])
 return {'status':'IMAGE_AND_SOURCE_SHA_MATCH_TEST' if not errors else 'HOLD_CROSSWALK_INTEGRITY',
  'images_checked':len(rows),'errors':errors,'canonical_RE_authorized':0,'official_pa_authorized':None,'prod_gate':'HOLD'}
def compare_four(crosswalk,comparisons):
 known={r['name'] for r in crosswalk['records']};rows=comparisons['cases'];issues=[]
 if len(rows)!=4 or len({r['target'] for r in rows})!=4:issues.append('FOUR_TARGETS_REQUIRED')
 for r in rows:
  if not set(r.get('closest_visual_sources',[])).issubset(known):issues.append('UNKNOWN_CANDIDATE:'+r['target'])
  if not r.get('not_equivalent'):issues.append('FALSE_EQUIVALENCE_UNJUSTIFIED:'+r['target'])
  if r.get('candidate_effect_RE_E0') is not None:issues.append('CANONICAL_RANK_CLAIM_UNAUTHORIZED:'+r['target'])
 return {'status':'HOLD_FOUR_EFFECT_SUBRANK_DECISIONS','target_count':len(rows),'full_homologous_comparators_proven':0,
  'partial_analogues_indexed':len(rows) if not issues else None,'issues':issues,'adjudications':0,
  'official_pa_consumed':None,'party_write':False,'notion_write':False,'prod_gate':'HOLD'}
def disagreement_census(crosswalk):
 rows=crosswalk['records']
 mismatches=[r['name'] for r in rows if not r['agreement_nominal_vs_R45_TEST']]
 return {'nominal_vs_provisional_TEST_conflict_numerator':len(mismatches),'denominator':len(rows),
  'disagreement_names':sorted(mismatches),'meaning':'Disagreement is not objective classification accuracy; both are unadjudicated as isolated effect RE.',
  'rank_decisions':0}
