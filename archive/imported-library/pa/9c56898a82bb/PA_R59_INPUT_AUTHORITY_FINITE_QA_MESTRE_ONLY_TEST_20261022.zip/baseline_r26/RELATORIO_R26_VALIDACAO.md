# R26 — Relatório de Aperfeiçoamento do Critério Semicanônico

**Data:** 19/10/2026 · **Modo:** MESTRE-SIDE / TEST · **Continuidade:** R25, sem reconstruir R22–R25 · **Produção:** HOLD

## Decisão do Mestre aplicada

O objetivo não é acertar 100% e se abster diante de incerteza, e sim reunir o máximo possível de informações, semelhanças e contraindicações, produzir o melhor julgamento de RE/RI com nível de confiança e mantê-lo utilizável de forma semicanônica até decisão contrária do Mestre. **Não substituir investigação profunda por heurística superficial.** A decisão altera a rigidez da política R25 para decisões de classificação; não revoga NAC-CONT-03, NAC-NORM-01, NAC-PASS ou PR-SC-01 para mutações físicas e riscos relevantes.

## Pesquisa documental efetivamente reaberta

- PR-ECO-01 Atlas: fonte da classificação, seus eixos, comparadores e revisão de rank.
- DMG-RANK-01: fonte da banda ofensiva para casos de alvo único e ação padrão.
- PR-SC-01: PS ≠ P4, classes SC-0–SC-4 e JIT-SC; SC-3/4 exige decisão Mestre para PS material.
- Sistema de Magia: magia pode progredir rank e alterar potência/alcance/duração.
- Bota Caminho Veloz, SOMBRA SUSSURRANTE, Anel de Evasão, Duro de Matar, Inscrição Aurora e Braçadeira Pulmão de Ferro: fichas Mestre recuperadas diretamente para comparação. Rank documental do **item** não atribui automaticamente RE E0 à habilidade.

## Reavaliação do corpus R25

99 observações, das quais 32 receberam candidato E3 do motor antigo e 67 não. Comparação dos 32 candidatos com as faixas preliminares E3 anteriores: **21 dentro; 11 fora**. As 11 divergências não provam 11 erros, pois o gabarito anterior também era E3, mas são sinais concretos para revisão. Arquivo `AUDITORIA_99_R26.csv` identifica os 99 casos e os 11 alvos. Evitar vender 32/99 como índice de acurácia.

## Entrega implementada

- `parecer_semicanonico_r26.py`: extensão **não destrutiva** do R25. Desacopla classificação e confiança; aceita comparadores qualitativos em vez de exigir automaticamente duas fontes para todo caso; informa semicanonicidade revisável em MESTRE-SIDE; diferencia risco de item vs RE; calcula cenários quando dados suficientes; mantém itens históricos sem reprecificação; evita tratar URL ou rank fornecido como prova física E0.
- `EXEMPLOS_COMPARATIVOS_R26.py`: cinco casos demonstrativos e fichas, com justificativa mecânica e fontes.
- `test_r26_decisao.py`: testes adversariais e de regressão da política.
- Baseline R25 preservado, incluindo seus R22/R23/R24 e documentação. Nenhum arquivo antigo modificado.

## Resultado mensurável

- R26: **26/26** testes de política e motor PASS.
- Regressão R22–R25 reexecutada: **163/163** PASS.
- Casos criados: 5 fichas; quatro com custos de cenário, uma com rank hipotético mas custo integral pendente por falta de mecânica.
- Manifesto SHA/CRC e extração limpa verificam integridade do pacote (verificar a saída anexada deste mesmo lote).

## Limitações reais preservadas

1. Comparadores e justificativas fornecidos externamente não se autoautenticam; fatos E0 demandam leitura física de fontes atuais. O protótipo exibe essa restrição.
2. Confiança não equivale a porcentagem de acerto calibrada. Não existe amostra canônica independente suficiente para medir universalidade ou 100%.
3. 99 resumos de efeitos não cobrem integralmente o RPG; vídeos/imagens de técnicas e habilidades ocultas ainda podem alterar pareceres.
4. A classificação semicanônica em conversa não equivale a promoção automática de uma ficha física Notion para PS/P4; situações SC3/SC4 ou evento material passam pelo PR-SC-01.
5. Integração de escrita no Notion/CRAFT continua submetida ao controle de writer e à situação STOP/F5; não foi promovida em esta execução.

## Ponto de retomada

Usar o classificador R26 para analisar cada nova criação/efeito, *pesquisando de fato* Atlas, família e comparadores, emitir parecer e custo quando possível. Para o corpus herdado, priorizar 11 divergências de faixa e depois os 67 sem candidato, por criticidade mecânica e disponibilidade de fonte, evitando nova varredura repetida por contagem. Reavaliar e corrigir pontualmente decisões à medida que novas fontes surgirem; não pedir ao Mestre classificar tudo por conta própria.
