# PARECER R26 — MESTRE-SIDE / SEMICANONICIDADE
**Status:** PARECER_COM_CONSUMO_ESTIMADO_SEMICANONICO
**Hierarquia:** decisão expressa do Mestre > cânone competente > parecer semicanônico > inferência.
**Semicanônico:** aplicável como parecer operacional revisável até correção do Mestre; não promove automaticamente item/ficha a P4, nem grava no Notion.
## Poderes analisados
- **Passos sem Pegadas** [PASSIVA]: **Prata** · confiança **MEDIA** · risco **SC-1** · PA/dia **12** · PA/uso **0**
  - Evidência: CLASSIFICACAO_COMPARATIVA_PROPOSTA_EM_PESQUISA; NAO_E0_AUTOMATICO; JUSTIFICATIVA:Tarefa especializada de ocultação de rastros: não concede invisibilidade ou teleporte e não impede outros meios de perseguição; comparador vivo do catálogo também vincula esse efeito a mobilidade.
  - Comparador: https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c
  - Comparador: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
  - Lacuna controlada: Não garante escapar de identificação por cheiro, magia ou rastreamento não baseado em pegadas.
## Consumo
**12 PA/dia + 0 PA/ativações = 12 PA no cenário.**
**Natureza:** PARECER_E3_SEMICANONICO_REVOGAVEL, nao P4 nem escrita oficial
## Rastreabilidade e autoridade
Notion: **PENDENTE; nenhum writer ou PS fisico inferido**
Party: **ZERO ESCRITA**; F5/CRAFT produtivo: **HOLD**.
Riscos SC-3/SC-4 necessitam decisão Mestre antes de PS material e revisão JIT-SC antes de consequência decisiva.

Fontes: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab, https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e, https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373, https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1
