"""R26 / Mestre-side / TEST. Non-authoritative advisor layered on immutable R25.

Operational change by explicit Mestre decision on 2026-10-19:
  an informed classification judgment may be semi-canonical/revisable without
  perfect evidence; rank and evidential confidence are separate.
Does not write Notion or Party, cannot canonize material or publish rules.
"""
from __future__ import annotations
import copy, sys, json, re
from pathlib import Path
from math import floor
from typing import Any

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'baseline_r25'))
import motor_qualificado_r25 as R25

RANKS=['Bronze','Prata','Ouro','Ouro Negro','Lendário']
BASE={'Bronze':6,'Prata':12,'Ouro':24,'Ouro Negro':35,'Lendário':50}
FLOORS={'Bronze':8,'Prata':11,'Ouro':21,'Ouro Negro':35,'Lendário':90}

# Source URLs read in Notion in this conversational work, NOT claims of full
# mechanical comparison or ongoing fresh authentication in another session.
SOURCES={
 'atlas':'https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab',
 'dmg':'https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e',
 'magia':'https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373',
 'semicanon':'https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1',
}
# Risk is NOT determined by RE alone. These triggers demand more scrutiny,
# JIT and possibly explicit authority, not silence or an automatic downgrade.
HIGH_RISK=(r'\b(?:morte instantanea|decapita|reviver|ressuscita|imortal|'
           r'paralisa tudo|controle total|reverte o tempo|sem limites|'
           r'imunidade absoluta|imunidade total|domina toda|qualquer criatura)\b')
RELEVANT_CONFLICTS=('DISSONANTE','CONTRADIZ','DUPLICADO','INFERIOR_AO_EFEITO',
                    'MULTIHABILIDADE','EXTERNO','SEM_LIMITES','RECURSIVIDADE')


def _normalize_rank(x):
    if not isinstance(x,str):return None
    n=R25.norm(x.strip())
    return next((v for v in RANKS if R25.norm(v)==n),None)


def _research_quality(comps):
    """Does not mistake a valid URL for verified content."""
    unique={}; kinds=set()
    for c in comps:
        if not isinstance(c,dict):continue
        u=c.get('url','');m=c.get('comparacao_mecanica','');kind=c.get('tipo','')
        if not isinstance(u,str) or not u.startswith('https://app.notion.com/p/') or len(str(m).strip())<24:
            continue
        if kind not in ('sistemico','vivo','familia'):continue
        unique[u]=(kind,m);kinds.add(kind)
    return {'comparadores_documentados':len(unique),
            'tipos_distintos':len({v[0] for v in unique.values()}),
            'urls':list(unique.keys()),
            'limite':'URLs e justificativas inseridas nao comprovam por si leitura Notion ou concordancia mecanica'}


def avaliar(descricao: str, *, origem='NOVO_TEST', usos=None, pesquisa=None)->dict:
    """Respond with best-supported judgment, confidence, revision controls.

    pesquisa={'Nome habilidade': {'rank_sugerido':'Prata',
      'justificativa':'...', 'comparadores':[{'url':'...','tipo':'familia',
      'comparacao_mecanica':'...'}], 'limites':['...'],
      'risco':'SC-1|SC-2|SC-3|SC-4'}}
    Supplied research is never automatically promoted to physically VERIFIED.
    """
    if pesquisa is None:pesquisa={}
    if not isinstance(pesquisa,dict):raise ValueError('pesquisa invalida')
    raw=R25.avaliar(descricao,usos=usos,origem=origem)
    result=copy.deepcopy(raw)
    result['r26']={'rank_item_proveniencia':result.get('item_rank_evidence'), 'politica':'DECISAO_EXPRESSA_MESTRE_20261019_SEMICANONICO_REVOGAVEL',
                   'fonte_metodo':SOURCES,
                   'registro_notion':'PENDENTE; nenhum writer ou PS fisico inferido',
                   'producao':'HOLD', 'pareceres':[], 'veredito':'PENDENTE'}
    if origem=='HISTORICO':
        result['r26']['veredito']='ANALISE_HISTORICA_SEM_REPRECIFICACAO'
        return result
    for a in raw.get('abilities',[]):
        n=a['name'];old=a.get('qualidade_rank',{}); q=pesquisa.get(n,{})
        if not isinstance(q,dict):q={}
        candidate=_normalize_rank(q.get('rank_sugerido')) or _normalize_rank(old.get('candidate'))
        supplied_candidate=bool(_normalize_rank(q.get('rank_sugerido')))
        qualified_research=bool(len(str(q.get('justificativa','')).strip())>=35 and _research_quality(q.get('comparadores',[]))['comparadores_documentados']>=1)
        if supplied_candidate and not qualified_research:
            reasons_unsubstantiated=True
            candidate=_normalize_rank(old.get('candidate'))
            supplied_candidate=False
        else: reasons_unsubstantiated=False
        reasons=[];comp=_research_quality(q.get('comparadores',[]))
        if reasons_unsubstantiated:reasons.append('RANK_INFORMADO_SEM_JUSTIFICATIVA_E_COMPARADOR; NAO_SUBSTITUI_ANALISE')
        if supplied_candidate:reasons.append('CLASSIFICACAO_COMPARATIVA_PROPOSTA_EM_PESQUISA; NAO_E0_AUTOMATICO')
        elif candidate:reasons.append('CANDIDATO_E3_MOTOR_ANTERIOR; NAO_APROVACAO_OFICIAL')
        else:reasons.append('SEM_RANK_INDIVIDUAL_MECANICAMENTE_DEFENSAVEL')
        if str(q.get('justificativa','')).strip():reasons.append('JUSTIFICATIVA:'+str(q['justificativa'])[:350])
        conflict=[x for x in old.get('issues',[]) if any(w in x for w in RELEVANT_CONFLICTS)]
        if conflict:reasons.append('CONFLITO_MECANICO:'+','.join(conflict))
        if not candidate:
            status='PENDENTE_INFERENCIA; buscar mais fontes e formular hipotese';confidence='INDETERMINADA'
        elif supplied_candidate and comp['comparadores_documentados']>=2 and comp['tipos_distintos']>=2 and not conflict:
            status='PARECER_SEMICANONICO_COMPARATIVO';confidence='MEDIA'
        elif (supplied_candidate or comp['comparadores_documentados']>=1) and not conflict:
            status='PARECER_SEMICANONICO_COM_RESSALVAS';confidence='BAIXA_A_MEDIA'
        else:
            status='PARECER_PRELIMINAR_E3';confidence='BAIXA'
        if conflict:
            status='PARECER_CONFLITUOSO_EXIGE_REVISAO_PRIORITARIA';confidence='BAIXA'
        s=R25.norm(a.get('text',''))
        risk=q.get('risco') if q.get('risco') in ('SC-0','SC-1','SC-2','SC-3','SC-4') else 'SC-A-AVALIAR'
        if re.search(HIGH_RISK,s) and risk not in ('SC-3','SC-4'):
            risk='SC-3_4_AVALIAR'
        if risk in ('SC-3','SC-4','SC-3_4_AVALIAR'):
            reasons.append('RISCO_ALTO: JIT-SC E DECISAO MESTRE ANTES DE CONSEQUENCIA MATERIAL')
        if comp['comparadores_documentados']==0:reasons.append('SEM_COMPARADOR_MECANICO_ADICIONAL_NESTA_ENTRADA')
        pa_day=BASE[candidate] if candidate and a['kind']=='PASSIVA' else floor(BASE[candidate]/2) if candidate and a['kind']=='ATIVA' else None
        pa_use=floor(BASE[candidate]*.6) if candidate and a['kind']=='ATIVA' else 0 if candidate and a['kind']=='PASSIVA' else None
        result['r26']['pareceres'].append({
            'habilidade':n,'modalidade':a['kind'],'rank_efeito_recomendado':candidate,
            'confianca':confidence,'selo':'E3-PARECER' if candidate else 'E3-INCONCLUSIVO',
            'estado':status,'risco':risk,'comparadores':comp,
            'justificativa_e_ressalvas':reasons,'lacunas':q.get('limites',[]),
            'pa_dia_pelo_rank_proposto':pa_day,'pa_uso_pelo_rank_proposto':pa_use,
            'nao_altera_custo_historico':True,
        })
    qualified=result['r26']['pareceres']
    all_ranked=all(p['rank_efeito_recomendado'] and p['modalidade'] in ('ATIVA','PASSIVA','NUMERICO_SEM_HABILIDADE_INDEPENDENTE') for p in qualified)
    numeric=result.get('numeric_audit',{})
    numeric_clear=not numeric.get('bloqueios',[]) and not numeric.get('componentes_nao_precificados',[])
    hard_global=('BONUS_IDENTICO_REPETIDO','BONUS_FRACIONARIO','CA_ARMADURA_MAGICA','DANO_RECORRENTE','HABILIDADES_DUPLICADAS', 'RI_ITEM_INFERIOR_AO_EFEITO','TARIFA_DE_', 'ATIVA_VS_PASSIVA')
    mechanically_clean=not any(any(k in v for k in hard_global) for v in result.get('issues',[]))
    mechanically_clean=mechanically_clean and not result.get('extraction_status','').startswith('TEXTO_LIVRE_NAO_RECONCILIADO')
    # Keep the distinction RI != max(RE): when item rank is not known, show
    # individual tariffs and explicitly decline a closed daily total.
    ri=_normalize_rank(result.get('item_rank_candidate'))
    critical_mechanics_incomplete=any(p.get('lacunas') and any(any(k in R25.norm(str(v)) for k in ('pendente','ausente','falta','indefinido','desconhecid','geometria','duracao','alvo','salvaguarda','cd ')) for v in p['lacunas']) for p in qualified)
    if all_ranked and numeric_clear and mechanically_clean and ri and not critical_mechanics_incomplete and not any(p['estado'].startswith('PARECER_CONFLITUOSO') for p in qualified):
        daily_bonuses=int(numeric.get('subtotal_reconhecido_pa',0))
        monthly=0;activations=0
        for p in qualified:
            monthly+=p['pa_dia_pelo_rank_proposto'] or 0
            a=next((x for x in result['abilities'] if x['name']==p['habilidade']),None)
            activations+=(p['pa_uso_pelo_rank_proposto'] or 0)*int((a or {}).get('uses',0))
        daily=max(FLOORS[ri],daily_bonuses+monthly)
        result['r26']['cenario_pa']={'rank_item':ri,'piso_item':FLOORS[ri],
                                  'componentes_numericos_pa_dia':daily_bonuses,
                                  'taxas_habilidades_pa_dia':monthly,'pa_dia':daily,
                                  'pa_ativacoes':activations,'total_dia':daily+activations,
                                  'natureza':'PARECER_E3_SEMICANONICO_REVOGAVEL, nao P4 nem escrita oficial',
                                  'rank_item_e3_inferido': not bool(result.get('item_rank_evidence','').startswith('DECLARADO'))}
        result['r26']['veredito']='PARECER_COM_CONSUMO_ESTIMADO_SEMICANONICO'
    else:
        result['r26']['veredito']='PARECER_PARCIAL_RANKS_E_TARIFAS; NECESSITA_COMPLEMENTAR_RI_OU_MECANICA'
        if critical_mechanics_incomplete:result['r26']['pendencia_critica']='Uma ou mais lacunas da mecanica alteram a potencia; nao fechar PA total com hipotese de area/duracao/limite.'
    if not qualified and ri and numeric_clear and mechanically_clean and result.get('status')!='HOLD_SEGMENTACAO':
        result['r26']['cenario_pa']={'rank_item':ri,'pa_dia':max(FLOORS[ri],int(numeric.get('subtotal_reconhecido_pa',0))),
                                  'pa_ativacoes':0,'total_dia':max(FLOORS[ri],int(numeric.get('subtotal_reconhecido_pa',0))),
                                  'natureza':'SEMI_CANONICO_SEM_HABILIDADE, TEST'}
        result['r26']['veredito']='PARECER_COM_CONSUMO_ESTIMADO_SEMICANONICO'
    return result


def ficha(r):
    q=r['r26'];lines=['# PARECER R26 — MESTRE-SIDE / SEMICANONICIDADE',
     '**Status:** '+q['veredito'],
     '**Hierarquia:** decisão expressa do Mestre > cânone competente > parecer semicanônico > inferência.',
     '**Semicanônico:** aplicável como parecer operacional revisável até correção do Mestre; não promove automaticamente item/ficha a P4, nem grava no Notion.',
     '## Poderes analisados']
    for a in q['pareceres']:
        lines.append(f"- **{a['habilidade']}** [{a['modalidade']}]: **{a['rank_efeito_recomendado'] or 'AINDA INDETERMINADO'}** · confiança **{a['confianca']}** · risco **{a['risco']}** · PA/dia **{a['pa_dia_pelo_rank_proposto'] if a['pa_dia_pelo_rank_proposto'] is not None else 'PENDENTE'}** · PA/uso **{a['pa_uso_pelo_rank_proposto'] if a['pa_uso_pelo_rank_proposto'] is not None else 'PENDENTE'}**")
        lines.append('  - Evidência: '+'; '.join(a['justificativa_e_ressalvas']))
        for u in a['comparadores']['urls']:lines.append('  - Comparador: '+u)
        for l in a['lacunas']:lines.append('  - Lacuna controlada: '+l)
    lines+=['## Consumo']
    if 'cenario_pa' in q:
        p=q['cenario_pa'];lines.append(f"**{p['pa_dia']} PA/dia + {p['pa_ativacoes']} PA/ativações = {p['total_dia']} PA no cenário.**")
        lines.append('**Natureza:** '+p['natureza'])
    else:lines.append('**Total não fechado**; preferências de rank por habilidade podem ser usadas para análise comparativa, faltam elementos para somar corretamente.')
    lines+=['## Rastreabilidade e autoridade',f"Notion: **{q['registro_notion']}**",'Party: **ZERO ESCRITA**; F5/CRAFT produtivo: **HOLD**.',
    'Riscos SC-3/SC-4 necessitam decisão Mestre antes de PS material e revisão JIT-SC antes de consequência decisiva.','',
    'Fontes: '+', '.join(q['fonte_metodo'].values())]
    return '\n'.join(lines)+'\n'
