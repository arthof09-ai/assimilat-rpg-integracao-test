import csv
from pathlib import Path
P=Path(__file__).parent
RANKS=['Bronze','Prata','Ouro','Ouro Negro','Lendário']
source=P/'baseline_r25'/'CORPUS_99_R25.csv'
rows=list(csv.DictReader(source.open(encoding='utf-8-sig'),delimiter=';'))
out=[];cnt={'SEM_CANDIDATO':0,'E3_DENTRO_FAIXA_ANTIGA':0,'E3_FORA_FAIXA_ANTIGA':0,'FAIXA_ANTIGA_NAO_COMPARAVEL':0}
for row in rows:
 rank=row.get('r25_sugestao_sem_preco','');band=row.get('re_anterior_r22_e3','').split('(')[0].strip();bands=[v.strip() for v in band.split('–')]
 if rank not in RANKS: status='SEM_CANDIDATO'
 elif any(v not in RANKS for v in bands):status='FAIXA_ANTIGA_NAO_COMPARAVEL'
 elif RANKS.index(bands[0]) <= RANKS.index(rank) <= RANKS.index(bands[-1]):status='E3_DENTRO_FAIXA_ANTIGA'
 else:status='E3_FORA_FAIXA_ANTIGA'
 cnt[status]+=1
 out.append({'ordinal':row['ordinal'],'item':row['item'],'habilidade':row['habilidade'],'re_r22_faixa_e3':band,'re_r25_heuristico_e3':rank,'diagnostico_comparativo':status,'nota':'Divergência entre duas hipóteses E3: exige revisão; não prova erro do rank novo nem validade do antigo.' if status=='E3_FORA_FAIXA_ANTIGA' else 'Faixa R22 nao equivale a gabarito canônico.','fonte':row['origem_fonte']})
with (P/'AUDITORIA_99_R26.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=out[0].keys(),delimiter=';');w.writeheader();w.writerows(out)
(P/'AUDITORIA_99_RESUMO.txt').write_text(str({'total':len(rows),**cnt})+'\n',encoding='utf-8')
print('Corpus R26:',len(rows),cnt)
