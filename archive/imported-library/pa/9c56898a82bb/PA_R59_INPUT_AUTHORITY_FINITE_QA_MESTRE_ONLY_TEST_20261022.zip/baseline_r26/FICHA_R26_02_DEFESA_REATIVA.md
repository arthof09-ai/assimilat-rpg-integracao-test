# PARECER R26 — MESTRE-SIDE / SEMICANONICIDADE
**Status:** PARECER_COM_CONSUMO_ESTIMADO_SEMICANONICO
**Hierarquia:** decisão expressa do Mestre > cânone competente > parecer semicanônico > inferência.
**Semicanônico:** aplicável como parecer operacional revisável até correção do Mestre; não promove automaticamente item/ficha a P4, nem grava no Notion.
## Poderes analisados
- **Refazer Destino** [ATIVA]: **Ouro Negro** · confiança **MEDIA** · risco **SC-3** · PA/dia **17** · PA/uso **21**
  - Evidência: CLASSIFICACAO_COMPARATIVA_PROPOSTA_EM_PESQUISA; NAO_E0_AUTOMATICO; JUSTIFICATIVA:Bypass parcial e decisivo: negar falha numa salvaguarda de DES é superior a pequeno bônus de teste, mas limitado a uma modalidade, reação e uso diário; comparação com inscrição Lendária que adiciona +18 sem sucesso garantido.; RISCO_ALTO: JIT-SC E DECISAO MESTRE ANTES DE CONSEQUENCIA MATERIAL
  - Comparador: https://app.notion.com/p/780c2b324ede82f69ae8818e612b7ad2
  - Comparador: https://app.notion.com/p/3f5c2b324ede818296fbd64921861d83
  - Comparador: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
  - Lacuna controlada: A expressão uma vez por dia deve prevalecer sobre as três cargas da fonte histórica, pois este é novo item com limitação própria.
  - Lacuna controlada: Confiança média compara efeitos, não transforma rank documental do anel em E0 da habilidade.
## Consumo
**35 PA/dia + 21 PA/ativações = 56 PA no cenário.**
**Natureza:** PARECER_E3_SEMICANONICO_REVOGAVEL, nao P4 nem escrita oficial
## Rastreabilidade e autoridade
Notion: **PENDENTE; nenhum writer ou PS fisico inferido**
Party: **ZERO ESCRITA**; F5/CRAFT produtivo: **HOLD**.
Riscos SC-3/SC-4 necessitam decisão Mestre antes de PS material e revisão JIT-SC antes de consequência decisiva.

Fontes: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab, https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e, https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373, https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1
