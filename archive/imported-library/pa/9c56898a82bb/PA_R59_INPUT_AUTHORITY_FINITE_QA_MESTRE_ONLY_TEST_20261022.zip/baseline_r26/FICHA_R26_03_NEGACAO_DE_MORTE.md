# PARECER R26 — MESTRE-SIDE / SEMICANONICIDADE
**Status:** PARECER_COM_CONSUMO_ESTIMADO_SEMICANONICO
**Hierarquia:** decisão expressa do Mestre > cânone competente > parecer semicanônico > inferência.
**Semicanônico:** aplicável como parecer operacional revisável até correção do Mestre; não promove automaticamente item/ficha a P4, nem grava no Notion.
## Poderes analisados
- **Duro de Matar** [ATIVA]: **Lendário** · confiança **MEDIA** · risco **SC-3** · PA/dia **25** · PA/uso **30**
  - Evidência: CLASSIFICACAO_COMPARATIVA_PROPOSTA_EM_PESQUISA; NAO_E0_AUTOMATICO; JUSTIFICATIVA:Nega integralmente um golpe que reduziria a Vida a zero e constitui bypass qualitativo de dano, limitado a uma ativação diária e uma reação, em vez de apenas amortecer a perda de Vida.; RISCO_ALTO: JIT-SC E DECISAO MESTRE ANTES DE CONSEQUENCIA MATERIAL
  - Comparador: https://app.notion.com/p/6c2c2b324ede83a7b7dc013f94eb052c
  - Comparador: https://app.notion.com/p/780c2b324ede82f69ae8818e612b7ad2
  - Comparador: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
  - Lacuna controlada: Morte instantânea sem dano não está automaticamente coberta por Duro de Matar; o exemplo é sintético e precisa definição própria.
  - Lacuna controlada: Revisar impacto estratégico e JIT-SC antes de uso em evento decisivo.
## Consumo
**90 PA/dia + 30 PA/ativações = 120 PA no cenário.**
**Natureza:** PARECER_E3_SEMICANONICO_REVOGAVEL, nao P4 nem escrita oficial
## Rastreabilidade e autoridade
Notion: **PENDENTE; nenhum writer ou PS fisico inferido**
Party: **ZERO ESCRITA**; F5/CRAFT produtivo: **HOLD**.
Riscos SC-3/SC-4 necessitam decisão Mestre antes de PS material e revisão JIT-SC antes de consequência decisiva.

Fontes: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab, https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e, https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373, https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1
