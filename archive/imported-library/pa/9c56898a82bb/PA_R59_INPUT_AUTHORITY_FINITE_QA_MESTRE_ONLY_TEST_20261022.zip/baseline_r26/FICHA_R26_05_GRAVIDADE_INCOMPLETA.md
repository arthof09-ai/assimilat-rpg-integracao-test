# PARECER R26 — MESTRE-SIDE / SEMICANONICIDADE
**Status:** PARECER_PARCIAL_RANKS_E_TARIFAS; NECESSITA_COMPLEMENTAR_RI_OU_MECANICA
**Hierarquia:** decisão expressa do Mestre > cânone competente > parecer semicanônico > inferência.
**Semicanônico:** aplicável como parecer operacional revisável até correção do Mestre; não promove automaticamente item/ficha a P4, nem grava no Notion.
## Poderes analisados
- **Gravidade Abissal** [ATIVA]: **Ouro Negro** · confiança **BAIXA_A_MEDIA** · risco **SC-3** · PA/dia **17** · PA/uso **21**
  - Evidência: CLASSIFICACAO_COMPARATIVA_PROPOSTA_EM_PESQUISA; NAO_E0_AUTOMATICO; JUSTIFICATIVA:Controle de deslocamento em campo gravitacional é compatível com o perfil avançado do Ouro Negro, mas falta CD, duração, área, número de alvos e contramedidas; parecer de baixa confiança e sem cálculo fechado.; RISCO_ALTO: JIT-SC E DECISAO MESTRE ANTES DE CONSEQUENCIA MATERIAL
  - Comparador: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
  - Lacuna controlada: Geometria do campo não é automaticamente circular; alcance e raio pendentes.
  - Lacuna controlada: CD e salvaguarda ausentes.
  - Lacuna controlada: Duração, número de alvos e contramedidas pendentes.
## Consumo
**Total não fechado**; preferências de rank por habilidade podem ser usadas para análise comparativa, faltam elementos para somar corretamente.
## Rastreabilidade e autoridade
Notion: **PENDENTE; nenhum writer ou PS fisico inferido**
Party: **ZERO ESCRITA**; F5/CRAFT produtivo: **HOLD**.
Riscos SC-3/SC-4 necessitam decisão Mestre antes de PS material e revisão JIT-SC antes de consequência decisiva.

Fontes: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab, https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e, https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373, https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1
