# ADENDO OPERACIONAL R26 — CLASSIFICAÇÃO SEMICANÔNICA (MESTRE-SIDE)

**Autoridade:** determinação expressa do Mestre em 19/10/2026, posterior ao R25. **Objeto:** método de julgamento de Rank de Efeito (RE), Rank de Item (RI) e custo de PA em criações prospectivas. **Estado de implementação:** TEST local reproduzível; registro documental Notion PENDENTE. **Nenhuma mutação de Party, original Mestre, CRAFT produtivo ou regras canônicas.**

## Nova interpretação vinculante

O Comestre deve investigar a mecânica, consultar as informações disponíveis e comparar efeitos análogos **antes de fechar seu parecer**. Não se exige acerto factual 100% para propor RE/RI: uma classificação consciente, fundamentada e auditável é **válida semicanonicamente em seu escopo** até decisão contrária do Mestre, mas não deve ser confundida com P4, registro físico PS da ficha ou conhecimento compartilhável à Party. Dúvida razoável não é proibição de julgar. O rótulo E3 não transforma um bom raciocínio em palpite. As normas específicas PR-SC-01 e NAC-NORM-01 continuam governando materialização/promulgação e riscos SC-3/4.

## Roteiro de análise antes de determinar rank

1. Recuperar descrição e origem documental completas, incluindo imagem quando relevante e acessível. Registrar a transcrição, não supor conteúdo de imagens não lidas.
2. Segmentar bônus simples, passivas funcionais, ativas, gatilhos, efeitos recorrentes e modos. Diferenciar habilidade e mero nome de bônus.
3. Descrever o efeito mecânico real: alvo/forma/alcance, ação, salvaguarda, duração, frequência, potencial de repetição, CD, magnitude, limitações, risco de bypass. Aplicar fallback do Mestre somente quando aplicável e com a proveniência correta.
4. **Cegueira econômica:** não olhar PA histórico, preço MED, título do item ou rank do portador para *escolher* o RE.
5. Encontrar comparadores: (A) sistêmico Atlas/Magia/DMG/Combate, (B) criatura/personagem real, (C) efeito da mesma família. Dar preferência à **comparabilidade causal**, não à quantidade artificial de links. Procurar contraexemplos e limites.
6. Propor **um rank principal** Bronze/Prata/Ouro/Ouro Negro/Lendário, FIP interna se útil, mais 1 alternativa se houver incerteza de fronteira. Se as descrições forem incompatíveis/indeterminadas, ainda dar hipótese e lacunas quando houver base suficiente; não usar uma hipótese como gabarito.
7. Rotular a **confiança do parecer separadamente** da procedência: ALTA (fontes convergentes, mecânicas completas, ausência de conflito material), MÉDIA (efeito bem caracterizado e comparadores razoavelmente aderentes), BAIXA (analogia distante ou restrições de poder pendentes), INDETERMINADA (material insuficiente para escolher sequer hipótese). E0/E1/E2/E3 continuam selos **de procedência** e não porcentagens de acerto; este protótipo classifica inferências comparativas como E3.
8. Aplicar tarifas Mestre para **novos itens**, mantendo rank da habilidade separado do rank do objeto: passiva +100% de 6/12/24/35/50 PA/dia; ativa diária +floor(50%) = 3/6/12/17/25; cada uso +floor(60%) = 3/7/14/21/30 PA. Piso item 8/11/21/35/90. **Não duplicar bônus numérico** já integralmente representado numa passiva; não inventar eixo sem tarifa.
9. Emitir ficha com parecer RE/RI, confiança, links, semelhanças/diferenças, objeções fortes, tarifas, cenário de usos, limites e Estado PS/P4 diferenciado. Quando o efeito ainda não tem duração, área ou salvaguarda suficientes para uma soma fechada, exibir **o rank sugerido e tarifas correspondentes**, mas manter o custo integral condicional — sem confundir isso com obrigação de se abster de classificar.
10. Aplicar governança **no ponto de efeito material**: a decisão do Mestre posterior substitui parecer sem retcon automático; SC-3/4 requerem autorização competente antes da admissão de conteúdo material em PS; JIT-SC antes de combate, recompensa, produção, transação relevante. Notion requer writer/reserva/antes/depois/readback e NAC-PASS; fichas da Party jamais recebem segredo Mestre-only. Não duplicar Atlas ou criar norma concorrente.

## O que mudou sobre R25

**Antes:** sem 2 URLs mecânicos distintos, HOLD em quase todas as habilidades não ofensivas. **Agora:** pesquisar ativamente e oferecer o melhor parecer suportado, mesmo com uma comparação forte ou confiança baixa, em vez de requisitar links ao Mestre. Comparadores alternativos e as incertezas ficam visíveis. Não confundir rótulo de rank enviado pelo usuário com estudo — rank sem fundamento e sem mecânica comparável continua não demonstrado.

## Exemplo de correção e limites

- Passos sem Pegadas: proposta Prata, confiança média por efeito tático específico, comparação com Bota Caminho Veloz e perfil do Atlas. Não alterar 18 PA/dia históricos da bota; preço de novo item Prata com passiva = 12 PA/dia.
- Refazer Destino: como reação, sucesso no lugar de falha em salvaguarda DES 1/dia. Parecer Ouro Negro, confiança média, compara Anel de Evasão e Inscrição Aurora Lendária +18 (que **não garante sucesso**). SC-3 por bypass; novo item ON = piso 35 PA/dia +21 PA/uso; JIT-SC para uso estratégico.
- Gravidade Abissal: Ouro Negro é hipótese contextual, confiança baixa, sem direito de supor geometria circular, CD, duração ou salvar. Tarifa se confirmar ATIVA ON seria 17 PA/dia +21/uso; total fica **condicionado** à mecânica definitiva.

## Autonomia e rastreabilidade

A autoridade do Mestre para revisar não exige microaprovação de todo parecer normal. Mas **semicanonicidade editorial, permissão de escrita e maturidade PS/P4 são camadas diferentes**. Versões e ocorrências passadas são preservadas até retcon explícito. O Comestre não pode declarar que publicou a decisão no Notion só porque a analisou no chat.
