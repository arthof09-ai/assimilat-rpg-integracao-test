import unittest
from parecer_semicanonico_r26 import avaliar, ficha

A='https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'
B='https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c'
C='https://app.notion.com/p/780c2b324ede82f69ae8818e612b7ad2'
D='https://app.notion.com/p/3f5c2b324ede818296fbd64921861d83'

PASS='Item: Botas\nRank do item: Prata\nHabilidade passiva: Passos sem Pegadas: Enquanto equipa, você não deixa pegadas.'
GOOD={'Passos sem Pegadas':{'rank_sugerido':'Prata','justificativa':'A ocultação de pegadas é uma utilidade focada, inferior à invisibilidade mas relevante para rastreio e fuga',
       'comparadores':[{'url':B,'tipo':'familia','comparacao_mecanica':'A Bota Caminho Veloz apresenta ausência de rastros e adaptação a terreno em modo passivo.'},
                       {'url':A,'tipo':'sistemico','comparacao_mecanica':'O Atlas atribui a Prata a função tática específica e reserva Ouro para impactos amplos.'}],
       'risco':'SC-1'}}
ATT='Item: Cajado\nRank do item: Ouro\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano em um único alvo.'

class R26(unittest.TestCase):
 def test_01_prior_strict_hold_is_now_judgment(self):
  x=avaliar(PASS,pesquisa=GOOD);self.assertEqual(x['status'],'HOLD');self.assertEqual(x['r26']['veredito'],'PARECER_COM_CONSUMO_ESTIMADO_SEMICANONICO')
 def test_02_rank_and_confidence(self):
  p=avaliar(PASS,pesquisa=GOOD)['r26']['pareceres'][0];self.assertEqual(p['rank_efeito_recomendado'],'Prata');self.assertEqual(p['confianca'],'MEDIA')
 def test_03_passive_math(self):
  self.assertEqual(avaliar(PASS,pesquisa=GOOD)['r26']['cenario_pa']['total_dia'],12)
 def test_04_price_does_not_decide_rank(self):
  a=avaliar(ATT);b=avaliar(ATT.replace('em um único alvo.','em um único alvo. 9999 PA para ativar.'));self.assertEqual(a['r26']['pareceres'][0]['rank_efeito_recomendado'],b['r26']['pareceres'][0]['rank_efeito_recomendado'])
 def test_05_free_bad_label_isnt_evidence(self):
  x=avaliar(PASS,pesquisa={'Passos sem Pegadas':{'rank_sugerido':'Lendário'}});self.assertIsNone(x['r26']['pareceres'][0]['rank_efeito_recomendado'])
 def test_06_no_url_is_not_comparator(self):
  e={'Passos sem Pegadas':{'rank_sugerido':'Prata','justificativa':'A falta de rastros é funcional e comparável à utilidade tática de rastreamento','comparadores':[{'url':'http://fake','tipo':'familia','comparacao_mecanica':'Tem detalhes suficientes para analisar a mecânica da ocultação.'}]}}
  x=avaliar(PASS,pesquisa=e);self.assertIsNone(x['r26']['pareceres'][0]['rank_efeito_recomendado'])
 def test_07_single_comparator_low_medium_not_hold(self):
  e={'Passos sem Pegadas':{**GOOD['Passos sem Pegadas'],'comparadores':GOOD['Passos sem Pegadas']['comparadores'][:1]}}
  x=avaliar(PASS,pesquisa=e);self.assertEqual(x['r26']['pareceres'][0]['confianca'],'BAIXA_A_MEDIA');self.assertEqual(x['r26']['cenario_pa']['pa_dia'],12)
 def test_08_two_comparators_not_E0(self):
  x=avaliar(PASS,pesquisa=GOOD);self.assertFalse(x['official_classification']);self.assertFalse(x['canonical_write'])
 def test_09_simple_damage_dmgbands(self):
  x=avaliar(ATT,usos={'Feixe':2});self.assertEqual(x['r26']['pareceres'][0]['rank_efeito_recomendado'],'Ouro');self.assertEqual(x['r26']['cenario_pa']['total_dia'],49)
 def test_10_mixed_ranks_use_each_rank_fee(self):
  q='Item: Botas\nRank do item: Ouro\nHabilidade passiva: Passos sem Pegadas: Enquanto equipa, você não deixa pegadas.\nHabilidade ativa Bronze: Salto: Com uma ação, salta de um ponto até outro.'
  x=avaliar(q,pesquisa=GOOD,usos={'Salto':2});p=x['r26']['pareceres'];self.assertEqual(p[0]['pa_dia_pelo_rank_proposto'],12);self.assertEqual(p[1]['pa_dia_pelo_rank_proposto'],3);self.assertEqual(p[1]['pa_uso_pelo_rank_proposto'],3)
 def test_11_no_item_rank_no_total(self):
  x=avaliar(ATT.replace('Rank do item: Ouro\n',''));self.assertTrue(x['r26']['cenario_pa']['rank_item_e3_inferido'])
 def test_12_historic_no_reprice(self):
  x=avaliar('Item: Bota Caminho Veloz\nRank do item: Ouro\nHabilidade ativa: Velocidade: +8m\n18 PA por dia',origem='HISTORICO')
  self.assertEqual(x['r26']['veredito'],'ANALISE_HISTORICA_SEM_REPRECIFICACAO');self.assertNotIn('cenario_pa',x['r26'])
 def test_13_compound_no_false_total(self):
  x=avaliar('Quero um anel que torna invisível e também teletransporta inimigos.')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_14_ri_lower_than_re_no_auto_bill(self):
  x=avaliar('Item: Espada\nRank do item: Bronze\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano em um único alvo.')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_15_ambiguous_ca_no_total(self):
  x=avaliar('Item: Armadura\nRank do item: Ouro\nBônus: +11 CA; +15 DES')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_16_numerics_no_skill_tariff(self):
  x=avaliar('Item: Manoplas\nRank do item: Prata\nBônus: +2 FOR')
  self.assertEqual(x['r26']['cenario_pa']['total_dia'],11)
 def test_17_bypass_high_risk_not_auto_downgraded(self):
  z='Item: Anel\nRank do item: Lendário\nHabilidade ativa Lendário: Morte Instantânea: Uma reação causa morte instantânea.'
  x=avaliar(z,pesquisa={'Morte Instantânea':{'risco':'SC-1'}})
  self.assertEqual(x['r26']['pareceres'][0]['risco'],'SC-3_4_AVALIAR')
 def test_18_ranks_daily_table(self):
  from parecer_semicanonico_r26 import BASE
  self.assertEqual(BASE,{'Bronze':6,'Prata':12,'Ouro':24,'Ouro Negro':35,'Lendário':50})
 def test_19_new_active_60percent(self):
  from math import floor
  from parecer_semicanonico_r26 import BASE
  self.assertEqual([floor(BASE[x]*.6) for x in BASE],[3,7,14,21,30])
 def test_20_odd_halves(self):
  self.assertEqual(35//2,17)
 def test_21_sources_are_not_three_independent_if_same(self):
  e={'Passos sem Pegadas':{**GOOD['Passos sem Pegadas'],'comparadores':[GOOD['Passos sem Pegadas']['comparadores'][0]]*2}}
  x=avaliar(PASS,pesquisa=e)
  self.assertEqual(x['r26']['pareceres'][0]['comparadores']['comparadores_documentados'],1)
 def test_22_ficha_has_revision(self):
  f=ficha(avaliar(PASS,pesquisa=GOOD));self.assertIn('revisável',f);self.assertIn('PENDENTE',f)
 def test_23_no_notional_P4(self):
  x=avaliar(ATT);self.assertFalse(x['official_classification']);self.assertIn('nao P4',x['r26']['cenario_pa']['natureza'])
 def test_25_missing_gravity_mechanics_no_closed_total(self):
  s='Item: Cajado\nRank do item: Ouro Negro\nHabilidade ativa: Gravidade: Cria um campo de gravidade que prende adversários.'
  e={'Gravidade':{'rank_sugerido':'Ouro Negro','justificativa':'Controle gravitacional sobre múltiplos inimigos parece patamar de elite mas carece de duração e área',
      'comparadores':[{'url':A,'tipo':'sistemico','comparacao_mecanica':'O Atlas atribui controle avançado e múltiplos alvos a efeitos de Ouro Negro.'}],
      'limites':['Geometria pendente','Duração ausente','CD pendente']}}
  x=avaliar(s,pesquisa=e)
  self.assertEqual(x['r26']['pareceres'][0]['rank_efeito_recomendado'],'Ouro Negro')
  self.assertNotIn('cenario_pa',x['r26'])
 def test_26_no_escalation_if_risk_sc3_4(self):
  s='Item: Anel\nRank do item: Lendário\nHabilidade ativa: Negação: Com sua reação impede a morte instantânea.'
  x=avaliar(s)
  self.assertEqual(x['r26']['pareceres'][0]['risco'],'SC-3_4_AVALIAR')
  self.assertFalse(x['canonical_write'])
 def test_24_invalid_research_payload(self):
  with self.assertRaises(ValueError):avaliar(ATT,pesquisa=[])

if __name__=='__main__': unittest.main(verbosity=2)
