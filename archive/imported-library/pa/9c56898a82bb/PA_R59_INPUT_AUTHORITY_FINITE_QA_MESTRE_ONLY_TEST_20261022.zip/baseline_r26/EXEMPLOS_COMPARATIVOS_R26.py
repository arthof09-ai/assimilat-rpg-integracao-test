import json
from pathlib import Path
from parecer_semicanonico_r26 import avaliar, ficha, SOURCES
P=Path(__file__).parent
AT=SOURCES['atlas'];DMG=SOURCES['dmg']
BOTA='https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c'
EVA='https://app.notion.com/p/780c2b324ede82f69ae8818e612b7ad2'
AUR='https://app.notion.com/p/3f5c2b324ede818296fbd64921861d83'
DUR='https://app.notion.com/p/6c2c2b324ede83a7b7dc013f94eb052c'
VOR='https://app.notion.com/p/442c2b324ede82c7a1520173d0d45cfd'

def c(url,tipo,desc):return dict(url=url,tipo=tipo,comparacao_mecanica=desc)

CASES=[
 {'id':'01_RASTROS_PASSIVA','descricao':'Item: Botas dos Rastros Ocultos\nRank do item: Prata\nHabilidade passiva: Passos sem Pegadas: Enquanto equipa as botas, não deixa rastros físicos.',
  'pesquisa':{'Passos sem Pegadas':{'rank_sugerido':'Prata','risco':'SC-1',
  'justificativa':'Tarefa especializada de ocultação de rastros: não concede invisibilidade ou teleporte e não impede outros meios de perseguição; comparador vivo do catálogo também vincula esse efeito a mobilidade.',
  'comparadores':[c(BOTA,'familia','Bota Caminho Veloz preserva a passiva Passos sem Pegadas, distinta de sua ativa de mais 8m.'),c(AT,'sistemico','O Atlas descreve o patamar Prata como solução eficiente de um problema tático específico.')],
  'limites':['Não garante escapar de identificação por cheiro, magia ou rastreamento não baseado em pegadas.']}}},
 {'id':'02_DEFESA_REATIVA','descricao':'Item: Anel de Evasão Aprimorada\nRank do item: Ouro Negro\nHabilidade ativa: Refazer Destino: Quando falha em salvaguarda de Destreza, pode usar sua reação para convertê-la em sucesso uma vez por dia.',
  'usos':{'Refazer Destino':1},'pesquisa':{'Refazer Destino':{'rank_sugerido':'Ouro Negro','risco':'SC-3',
  'justificativa':'Bypass parcial e decisivo: negar falha numa salvaguarda de DES é superior a pequeno bônus de teste, mas limitado a uma modalidade, reação e uso diário; comparação com inscrição Lendária que adiciona +18 sem sucesso garantido.',
  'comparadores':[c(EVA,'familia','Anel de Evasão permite transformar falha em sucesso gastando reação e carga, recuperando só uma carga por dia.'),c(AUR,'familia','Inscrição Aurora Lendária dá +18 à salvaguarda contra quatro estados nocivos, mas não torna o sucesso automático.'),c(AT,'sistemico','Atlas classifica bypass, confiabilidade, recarga, quantidade de alvos e limitação efetiva como eixos de rank.')],
  'limites':['A expressão uma vez por dia deve prevalecer sobre as três cargas da fonte histórica, pois este é novo item com limitação própria.', 'Confiança média compara efeitos, não transforma rank documental do anel em E0 da habilidade.']}}},
 {'id':'03_NEGACAO_DE_MORTE','descricao':'Item: Amuleto da Última Chance\nRank do item: Lendário\nHabilidade ativa: Duro de Matar: Uma vez por dia, quando recebe golpe que reduziria sua Vida a zero, ativa como reação para ignorar completamente esse golpe.',
  'usos':{'Duro de Matar':1},'pesquisa':{'Duro de Matar':{'rank_sugerido':'Lendário','risco':'SC-3',
  'justificativa':'Nega integralmente um golpe que reduziria a Vida a zero e constitui bypass qualitativo de dano, limitado a uma ativação diária e uma reação, em vez de apenas amortecer a perda de Vida.',
  'comparadores':[c(DUR,'familia','Duro de Matar histórico permite ignorar dano que levaria o portador a 0 ou menos PV uma vez por dia.'),c(EVA,'familia','Anel de Evasão demonstra a família de converter consequência negativa de uma salvaguarda com reação e recursos.'),c(AT,'sistemico','Atlas exige tratar negar morte e bypass como eixos de poder qualitativos e não apenas magnitude média de dano.')],
  'limites':['Morte instantânea sem dano não está automaticamente coberta por Duro de Matar; o exemplo é sintético e precisa definição própria.', 'Revisar impacto estratégico e JIT-SC antes de uso em evento decisivo.']}}},
 {'id':'04_DANO_SIMPLES','descricao':'Item: Cajado do Feixe Dourado\nRank do item: Ouro\nHabilidade ativa: Feixe: Com uma ação padrão, causa 8d10 de dano mágico em um único alvo.',
  'usos':{'Feixe':2},'pesquisa':{},
  'observacao':'8d10 tem DME 44, centro da banda Ouro 22–62 para alvo único/ação padrão. Valor derivado da norma DMG-RANK, não de preço/PA.'},
 {'id':'05_GRAVIDADE_INCOMPLETA','descricao':'Item: Cajado da Gravidade\nRank do item: Ouro Negro\nHabilidade ativa: Gravidade Abissal: Cria um campo de gravidade que prende adversários.',
 'pesquisa':{'Gravidade Abissal':{'rank_sugerido':'Ouro Negro','risco':'SC-3',
  'justificativa':'Controle de deslocamento em campo gravitacional é compatível com o perfil avançado do Ouro Negro, mas falta CD, duração, área, número de alvos e contramedidas; parecer de baixa confiança e sem cálculo fechado.',
  'comparadores':[c(AT,'sistemico','Atlas descreve controle avançado e limitação real de duração, área, salvaguarda e bypass para classificar Ouro Negro.')],
  'limites':['Geometria do campo não é automaticamente circular; alcance e raio pendentes.', 'CD e salvaguarda ausentes.', 'Duração, número de alvos e contramedidas pendentes.']}}},
]
result=[]
for case in CASES:
    out=avaliar(case['descricao'],usos=case.get('usos'),pesquisa=case['pesquisa'])
    (P/f"FICHA_R26_{case['id']}.md").write_text(ficha(out),encoding='utf-8')
    result.append({'caso':case['id'],'entrada':case['descricao'],'fonte_referencia':'FONTES_NOTION_FISICAMENTE_LIDAS_20261019' if case['pesquisa'] else 'DMG-RANK_LIDO_20261019',
                   'ranks':[(v['habilidade'],v['rank_efeito_recomendado'],v['confianca'],v['risco']) for v in out['r26']['pareceres']],
                   'cenario_pa':out['r26'].get('cenario_pa'), 'status':out['r26']['veredito'], 'observacao':case.get('observacao','')})
(P/'EXEMPLOS_RESULTADOS_R26.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for r in result:print(r['caso'],r['ranks'],r['status'],r['cenario_pa'])
