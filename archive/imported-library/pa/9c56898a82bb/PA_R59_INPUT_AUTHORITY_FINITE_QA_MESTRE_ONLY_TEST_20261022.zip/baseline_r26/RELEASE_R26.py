import hashlib,json,zipfile,shutil,subprocess,sys,os
from pathlib import Path
src=Path(__file__).parent
zip_path=src.parent/'PA_R26_CLASSIFICACAO_SEMICANONICA_TEST_20261019.zip'
manifest={'package':'PA-R26-20261019','environment':'TEST / MESTRE-SIDE','policy':'Decisao Mestre: julgamento semicanonico revisavel, confiança graduada','files':{}}
files=[]
for p in sorted(src.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or p.name in ('MANIFEST_R26.json',):continue
 if any(z in p.parts for z in ('pa_r25_release','pa_r25_replay_clean')):continue
 files.append(p)
for p in files:
 name=p.relative_to(src).as_posix();by=p.read_bytes()
 manifest['files'][name]={'sha256':hashlib.sha256(by).hexdigest(),'bytes':len(by)}
(src/'MANIFEST_R26.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in files:z.write(p,p.relative_to(src).as_posix())
 z.write(src/'MANIFEST_R26.json','MANIFEST_R26.json')
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(manifest['files'])|{'MANIFEST_R26.json'}
 for name,obj in manifest['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==obj['sha256']
clean=src.parent/'pa_r26_clean_replay'
if clean.exists():shutil.rmtree(clean)
clean.mkdir()
with zipfile.ZipFile(zip_path) as z:z.extractall(clean)
for name,obj in manifest['files'].items():assert hashlib.sha256((clean/name).read_bytes()).hexdigest()==obj['sha256']
base=clean/'baseline_r25'
tests=[(clean,[sys.executable,'-m','unittest','-q','test_r26_decisao']),
       (base,[sys.executable,'-m','unittest','-q','test_r25_qualidade','test_integracao_r24','test_motor_conversacional_r24','test_alcance_mestre_r23','test_ponte_pa_r23','baseline_r22.test_rank_guard_r22'])]
for cwd,args in tests:
 env=os.environ.copy();env['PYTHONPATH']=str(cwd) +(os.pathsep+str(base/'baseline_r22') if cwd==base else '')
 p=subprocess.run(args,cwd=cwd,env=env,text=True,capture_output=True)
 print('TEST',cwd.name,'RC',p.returncode,p.stdout[-150:],p.stderr[-400:]);assert p.returncode==0
for fn in ('EXEMPLOS_COMPARATIVOS_R26.py','AUDITAR_CORPUS_R26.py'):
 p=subprocess.run([sys.executable,fn],cwd=clean,env={**os.environ,'PYTHONPATH':str(clean)},text=True,capture_output=True)
 assert p.returncode==0,(p.stdout,p.stderr)
 compare=['EXEMPLOS_RESULTADOS_R26.json','AUDITORIA_99_R26.csv','AUDITORIA_99_RESUMO.txt']
 for name in compare:
  assert (clean/name).read_bytes()==(src/name).read_bytes(),name
 print('REPRODUCED',fn)
print('ZIP',str(zip_path),'BYTES',zip_path.stat().st_size,'SHA256',hashlib.sha256(zip_path.read_bytes()).hexdigest(),'FILES',len(manifest['files'])+1)
