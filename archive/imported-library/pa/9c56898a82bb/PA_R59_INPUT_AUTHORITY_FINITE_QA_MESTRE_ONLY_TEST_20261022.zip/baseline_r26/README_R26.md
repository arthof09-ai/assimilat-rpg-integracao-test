# R26 — Parecer Semicanônico e Consumo de PA (TEST)

Requer Python 3.11+ e nenhuma biblioteca adicional. `baseline_r25/` preserva o motor anterior e suas fontes anteriores.

```
cd pa_r26_work
python -m unittest -q test_r26_decisao
cd baseline_r25
PYTHONPATH=.:baseline_r22 python -m unittest -q test_r25_qualidade test_integracao_r24 test_motor_conversacional_r24 test_alcance_mestre_r23 test_ponte_pa_r23 baseline_r22.test_rank_guard_r22
cd ..
python EXEMPLOS_COMPARATIVOS_R26.py
python AUDITAR_CORPUS_R26.py
```

O novo API: `from parecer_semicanonico_r26 import avaliar,ficha`; `parecer=avaliar(descricao,pesquisa={nome: {'rank_sugerido':'Prata','justificativa':'texto','comparadores':[{'url':'https://app.notion.com/p/...','tipo':'familia','comparacao_mecanica':'...'}]}})`; `print(ficha(parecer))`. Rank sugerido sem justificativa e fonte comparativa não passa por pesquisa. Laudo numérico é cenário semicanônico quando completo, não reprecificação histórica.

Não escreve Notion, Party ou CRAFT produtivo.
