#!/usr/bin/env python3
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
old=subprocess.run([sys.executable,'run_r55_cold.py'],cwd=ROOT,capture_output=True,text=True,timeout=270)
if old.returncode:raise RuntimeError(old.stderr[-3000:])
a=json.loads(old.stdout);assert a['total_test_runs_this_chain']==210
new=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r56.py','-q'],cwd=ROOT,capture_output=True,text=True,timeout=100)
if new.returncode or 'Ran 73 tests' not in new.stderr:raise RuntimeError(new.stderr[-3000:])
print(json.dumps({'status':'PASS_R56_COLD_TEST','inherited_test_runs_R53_R55':210,'new_R56_module_QA_tests':73,
 'current_chain_total':283,'canonical_modules_reused':5,'new_modules':0,'new_recipes':0,'new_resources':0,
 'E0_sub_effect_adjudication':0,'prod_gate':'HOLD','official_pa':None,'notion_writes':0,'party_writes':0},sort_keys=True))
