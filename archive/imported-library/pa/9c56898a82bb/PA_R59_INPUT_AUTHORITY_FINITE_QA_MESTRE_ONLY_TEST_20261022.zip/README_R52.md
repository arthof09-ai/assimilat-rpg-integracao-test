# PA R52 — Cadastro E0 controlado, frescor das fontes e estados desconhecidos (TEST Mestre-only)

## Escopo

A R52 é um **adaptador experimental read-only** sobre o R26 e o fence R51 existentes; não cria ou instala motor de custos, não substitui PR-ECO-01, NAC-NORM nem mecanismos de homologação. Foi elaborada sobre o último checkpoint verificado `PA-R51A-R42-563-INTEGRAL-20261021-001`. O R51 e o R26 são preservados integralmente por hashes no manifesto pai.

## Novos defeitos de contrato diagnosticados

1. O cadastro R51 rejeitava toda fonte com `effect_rank_adjudicated=True`. É correto para as 13 fontes **atualmente sem RE individual homologado**, mas, sem um estágio explícito de transição, impossibilita receber uma futura fonte E0 legítima. A R52 permite **registrar uma alegação E0 apenas como solicitação de revisão**. Mesmo com UUID, rank, trecho mecânico extenso e um texto de decisão do Mestre, o resultado obrigatório é `HOLD_EXTERNAL_AUTHORITY_READBACK`. Uma string de decisão NÃO prova assinatura, autoridade, vigência ou escopo. O supervisor autorizado precisará verificar a decisão diretamente no Notion, o mecanismo isolado e aprovar nova versão do cadastro; isso não está implementado como promoção automática.
2. `physical_item_produced=False` no resumo R50 era mais forte que a evidência: a execução TEST não fabricou nada, mas não sabe se um exemplar foi produzido em outro contexto. A R52 diferencia `production_attempted_by_this_test=False` de `physical_item_produced=null`, assim como `magical_effect_installed=null`, `real_pa_consumed=null`. `null` não significa custo zero, impossibilidade, nem existência.
3. A verdade documental não é permanente. 13 páginas Notion do cadastro foram relidas neste ciclo, com **13 trechos mecânicos presentes e 13 horários de última edição idênticos** à versão R51. O auditor de frescor local exige 13/13 identidade de página, âncora e edição para aceitar somente o snapshot **de 21/10/2026**. Qualquer ausência, truncamento ou mudança passa a `HOLD_SOURCE_REFRESH_REQUIRED`. O JSON de leitura é um registro de chamadas de ferramenta, NÃO assinatura criptográfica do Notion nem garantia de frescor futuro.
4. As quatro disputas Bronze/Prata foram consultadas novamente no R26 original por meio do adapter R51. O R26 emite confiança `MEDIA` a todos os quatro pareceres, mas o cadastro ainda contém **0 comparadores cujo RE individual equivalente tenha sido adjudicado**. R52 separa explicitamente confiança nativa de prova para E0. **0 ranks, PA ou produção homologados**.

## Reprodutibilidade

O diretório é compatível com a R51 e transporta seus arquivos-base imutáveis. `R52_DELTA_MANIFEST.json` cobre a implementação, os testes, as saídas e o relato de frescor; o `MANIFEST_SHA256.json` da R51 cobre os arquivos-base.

```bash
python run_r52_cold.py
```

Saída esperada: `PASS_R52_COLD`: **39 testes novos R52**, **35 testes anteriores R51** e **26 testes originais R26**; total 100 execuções de testes nessas três suítes, sem converter os 563 casos R42 de outra execução em testes novos R52. Também confere 113 hashes da R51, todos os hashes delta e os quatro resultados sem promoção, com snapshot 13/13.

Os testes locais modelam documentos e falhas de entrada. Não demonstram independência científica, autenticidade de uma decisão E0, acurácia contra um rank verdadeiro, transferência de magia, inventário físico ou fábrica RC5/F5. Testes automáticos são TEST, não NAC-PASS global.

## Situação de trabalho

**PASS:** análise do defeito de contrato; estágio E0 que não se autopromove; separação ausência de produção versus desconhecimento; reconciliação das 13 fontes na data do estudo; quatro casos preservados; hashes e regressões locais. **HOLD:** verificação de qualquer futura decisão E0 pela autoridade, patch produtivo do R26, comparadores mecanicamente equivalentes Bronze/Prata, avaliação independente das 14 restantes e E353, adaptação das regras estrangeiras, custos de PA autorizados, CRAFT P2/óleo e instalação mágica.

**Sigilo:** MESTRE-SIDE; contém casos com parecer peer e fonte de exame. Não enviar à Party nem a revisores cegos. Não criar duplicatas de operações existentes. Ponto de retomada: `PA-R52-E0-STAGING-20261021-001` no LAB Mestre, condicionado a gravação e releitura no Notion.
