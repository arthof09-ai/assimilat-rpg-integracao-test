#!/usr/bin/env python3
import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
prev=subprocess.run([sys.executable,'run_r56_cold.py'],cwd=root,capture_output=True,text=True,timeout=300)
if prev.returncode:raise RuntimeError('BASELINE_FAIL:'+prev.stderr[-2500:])
a=json.loads(prev.stdout)
assert a['current_chain_total']==283 and a['E0_sub_effect_adjudication']==0
for tag,n in [('r58',21),('r59',50)]:
 x=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p',f'test_{tag}.py','-q'],cwd=root,capture_output=True,text=True,timeout=120)
 if x.returncode or f'Ran {n} tests' not in x.stderr:raise RuntimeError(f'{tag} FAIL:'+x.stderr[-2800:])
print(json.dumps({'status':'PASS_R59_COLD_TEST','baseline_R53_R56':283,'R58':21,'R59_new':50,'total_current_suite_runs':354,
 'E0_authorized':0,'production':'HOLD','official_PA':None,'party_writes':0,'notion_writes':0},sort_keys=True))
