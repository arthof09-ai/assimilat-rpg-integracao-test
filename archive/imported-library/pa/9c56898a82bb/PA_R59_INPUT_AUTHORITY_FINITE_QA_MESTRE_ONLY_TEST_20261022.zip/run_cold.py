#!/usr/bin/env python3
"""R51 isolated cold replay. Offline; no remote writes; no magical experiment claims."""
from pathlib import Path
import hashlib,json,subprocess,sys,os
ROOT=Path(__file__).resolve().parent
SHA26='7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(cmd,cwd=None,env=None):
 p=subprocess.run(cmd,cwd=cwd or ROOT,text=True,capture_output=True,env=env)
 if p.returncode:raise RuntimeError('TEST_FAILED '+str(cmd)+' '+p.stdout[-1500:]+' '+p.stderr[-1500:])
 return p.stdout+'\n'+p.stderr

def main():
 manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
 for name,expected in manifest['files'].items():
  assert sha(ROOT/name)==expected,('HASH',name)
 assert sha(ROOT/'baseline_r26/parecer_semicanonico_r26.py')==SHA26,'NATIVE_R26_MUTATION'
 native=run([sys.executable,'-m','unittest','-q','test_r26_decisao'],ROOT/'baseline_r26',
            {**os.environ,'PYTHONPATH':str(ROOT/'baseline_r26')})
 assert 'Ran 26 tests' in native and 'OK' in native
 new=run([sys.executable,'-m','unittest','discover','-s','tests','-p','test*.py','-q'])
 assert 'Ran 35 tests' in new and 'OK' in new,(new[-1000:])
 sys.path.insert(0,str(ROOT/'src'))
 from contract_r51 import derive
 c=(json.dumps(derive(),sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode('utf8')
 assert c==(ROOT/'outputs/R51_COST_EVIDENCE_SEPARATION.json').read_bytes()
 readback=json.loads((ROOT/'evidence/NOTION_READBACK_13_ASOF.json').read_text())
 assert readback['source_count']==13 and readback['all_anchors_confirmed'] is True
 r39=json.loads((ROOT/'fixtures/RECIBO_REPLAY_R39.json').read_text())
 assert r39['total_suites_formal_tests']==510 and r39['originais_preservados']['r26_sha']==SHA26
 print(json.dumps({'checkpoint':'PA_R51_TEST','status':'PASS_COLD_REPLAY','manifest_files':len(manifest['files']),
     'R51_new_tests':35,'native_R26_tests':26,'R50_frozen_outputs_byte_identical':True,
     'r39_510_run_evidence_included_not_replayed_in_this_runner':True,
     'physical_magic_verified':False,'canonical_RE_approved':0,'official_pa_spend':0,
     'remote_writes':0,'notion_asof_sources_documented':13},sort_keys=True))
if __name__=='__main__':main()
