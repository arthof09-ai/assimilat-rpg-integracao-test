#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=ROOT/'PA_R52_FENCE_E0_STAGING_MESTRE_ONLY_TEST_20261021.zip'
# The R52 parent is shipped alongside this R53 delta bundle (not modified).
if parent.is_file() and sha(parent)!='01ad80ddf0a650e733d02a34ff0f28a629f1833da8cb133b92fbf19c1bdfb282':
 raise AssertionError('PARENT_ZIP_HASH_CHANGED')
base=subprocess.run([sys.executable,'run_r52_cold.py'],cwd=ROOT,capture_output=True,text=True,timeout=90)
if base.returncode!=0:raise RuntimeError(base.stderr+base.stdout)
v=json.loads(base.stdout);assert v['status']=='PASS_R52_COLD' and v['new_r52_tests']==39 and v['original_r51_tests']==35 and v['native_r26_tests']==26
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r53.py','-q'],cwd=ROOT,capture_output=True,text=True,timeout=45)
if r.returncode!=0:raise RuntimeError(r.stderr+ r.stdout)
assert 'Ran 18 tests' in r.stderr, r.stderr
sys.path.insert(0,str(ROOT/'src'))
from freshness_guard_r53 import generate
out=generate()
assert out['source_text_and_version_matches']==13 and out['status']=='HOLD_FULL_SOURCE_PROOF_METADATA_UNAVAILABLE'
print(json.dumps({'status':'PASS_R53_COLD_TEST','r52_formal_tests':100,'r53_new_tests':18,
 'total_test_runs_unique_suites':118,'notion_source_texts_and_dates_rechecked':13,
 'canonical_RE_authorized':0,'official_pa_consumed':0,
 'full_document_integrity':'UNKNOWN_NOT_EXPOSED', 'prod_gate':'HOLD',
 'party_writes':0,'notion_writes':0},sort_keys=True))
