#!/usr/bin/env python3
"""Replays unchanged R51 release suites and new R52, each with its own censo."""
from pathlib import Path
import json,hashlib,sys,subprocess,os
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def run(cmd,cwd=ROOT,env=None):
    r=subprocess.run(cmd,text=True,capture_output=True,cwd=cwd,env=env,timeout=40)
    if r.returncode:raise RuntimeError('FAILED '+str(cmd)+'\n'+r.stderr[-1000:]+'\n'+r.stdout[-1000:])
    return r.stdout+'\n'+r.stderr

def main():
    r51=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())['files']
    for n,h in r51.items():assert digest(ROOT/n)==h,('PARENT_R51_HASH',n)
    new=json.loads((ROOT/'R52_DELTA_MANIFEST.json').read_text())['files']
    for n,h in new.items():assert digest(ROOT/n)==h,('R52_HASH',n)
    env={**os.environ,'PYTHONPATH':str(ROOT/'baseline_r26')}
    native=run([sys.executable,'-m','unittest','-q','test_r26_decisao'],ROOT/'baseline_r26',env)
    assert 'Ran 26 tests' in native and 'OK' in native
    r51test=run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r51.py','-q'])
    assert 'Ran 35 tests' in r51test and 'OK' in r51test,r51test[-1000:]
    r52test=run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r52.py','-q'])
    assert 'Ran 39 tests' in r52test and 'OK' in r52test,r52test[-1000:]
    sys.path.insert(0,str(ROOT/'src'))
    from gateway_r52 import generate,EXPECTED_R26_SHA,EXPECTED_REGISTRY_SHA,sha
    assert sha(ROOT/'fixtures/sources.json')==EXPECTED_REGISTRY_SHA
    assert sha(ROOT/'baseline_r26/parecer_semicanonico_r26.py')==EXPECTED_R26_SHA
    output=json.dumps(generate(ROOT),sort_keys=True,ensure_ascii=False,indent=2)+'\n'
    assert output==(ROOT/'outputs/r52_gateway_four_cases.json').read_text('utf-8')
    assert all(r['canonical_RE'] is None and r['physical_item_produced'] is None for r in json.loads(output)['records'])
    assert digest(ROOT/'outputs/r50_results.json')=='25c6016ba7953e9da853054cc32710f146d01330ef281e65d2d786b7584ed696'
    from gateway_r52 import pinned_registry,source_freshness_readback
    fresh=source_freshness_readback(json.loads((ROOT/'evidence/NOTION_READBACK_R52_ASOF_20261021.json').read_text()),pinned_registry())
    assert fresh['status']=='REFERENCE_READBACK_STABLE_ASOF_DATE_ONLY' and fresh['n_observed']==13
    print(json.dumps({'status':'PASS_R52_COLD','parent_R51_manifest_files':len(r51),
      'r52_delta_manifest_files':len(new),'new_r52_tests':39,'original_r51_tests':35,'native_r26_tests':26,
      'four_e2_cases':4,'canonical_RE_authorized':0,'official_pa_authorized':0,
      'physical_item_produced':'UNKNOWN','actual_production_this_run':False,
      'remote_writes':0,'source_registry_readback':'PINNED_ASOF_20261021'},sort_keys=True))
if __name__=='__main__':main()
