# PA-R51 — FENCE de evidência corrigido, regressões e contrato PA/CRAFT — MESTRE-ONLY TEST

Operação de aperfeiçoamento sobre o **R26 existente** e o adaptador **R50**, nunca substituindo sua governança, algoritmo de rank, tarifário ou código canônico. Preparado para o Mestre do RPG Assimilação.

## Defeito reproduzido no R50 e correção TEST

O R50 reservava um UUID Notion em `all_ids` ANTES de comprovar se a citação, o papel e o comparador desse UUID eram admissíveis. Assim, uma entrada contendo um excerto falso seguida do excerto legítimo na mesma página terminava com `eligible=False` e ZERO fontes. Inverter a ordem terminava com `eligible=True` e uma fonte. **Bug de contaminação por ordem**, não de acurácia do rank.

`src/source_fence_r50_original.py` é cópia byte-idêntica do módulo R50. `src/source_fence.py` é a correção mínima proposta: validar primeiro; só então reservar o UUID aceito, com deduplicação por UUID e `lineage_group`. A família de páginas distintas de Tento com o mesmo texto da Retaliação continua uma única linhagem. Em um lote com citações falsas e verdadeiras, os falsos continuam rejeitados e geram razões explícitas.

- 35/35 novos testes R51 cobrindo permutações, papéis falsos, excertos falsos, páginas-espelho, host inválido, quatro comparações nativas preservadas, 26 consultas sem rank e contrato de recibo PA/CRAFT.
- 49/49 testes R50 anteriores executados em reprodução fria independente e 26/26 testes nativos R26 reproduzidos, com código original intacto.
- Replay R39 `RUN_R39_RELEASE.py` completado efetivamente neste turno: **510/510** testes; R42 13/13 e fábrica R48 original 40/40 rodados SEPARADAMENTE. A execução monolítica `RUN_R42_COLD.py` chegou ao limite e não emitiu PASS; a afirmação de 563 refere-se apenas à soma das três suítes individuais efetivamente concluídas, não a esse comando integrado.
- Referências Notion: 13/13 páginas abertas neste turno com os 13 trechos específicos presentes. `evidence/NOTION_READBACK_13_ASOF.json` descreve leitura observada; não prova conteúdo futuro e seu registro é testemunho da chamada, não assinatura de Notion.

## Contrato de informação transversal

`src/contract_r51.py` é apenas um **projetor READ-ONLY** dos recibos reais de cenário TEST R39 de Botas e Pingente:

- Botas: 25 PA/dia + 6 PA no cenário de ativação = 31;
- Pingente: 12 PA/dia + 14 PA de ativações = 26;
- **Rank de efeito individual, custo autorizado, PA efetivamente debitado, efeito mágico instalado e observado são desconhecidos/NÃO VERIFICADOS**. O campo de 'desconhecido' não é false nem zero. O status do fabricante PROD continua HOLD.

O contrato recusa recibos sem gate de produção HOLD, prova E0 indevidamente inserida, gastos aritmeticamente inconsistentes ou declaração de writer/lease. Não autentica física/operadores nem aplica recursos. Esta é uma resposta direta à ideia existente da Inbox PA de separar custo, classificação e eficácia, não uma nova engine ou tabela tarifária.

## Reproduzir

`python run_cold.py` valida SHA de todos os arquivos, replay 35/35, testes nativos R26 26/26, reproduz as quatro consultas R50 e as 26 entradas sem rank e confirma ambos contra os outputs CONGELADOS R50. `evidence/R39_R51_STDOUT.log` contém o comprovante do RUN_R39_RELEASE realizado externamente a este ZIP; o presente ZIP não transporta todos os pais R39 e não afirma executar a suíte de 510 dentro deste runner. A execução histórica completa pode ser reproduzida diretamente do ZIP original R42 (SHA `6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800`).

Este pacote leva uma cópia congelada dos arquivos necessários do R26 para teste, que não constitui motor paralelo autorizado de produção. Nenhum arquivo fonte do RPG, receita P2, custo canônico, Party, O Primeiro, Notion ou item físico é alterado pela execução Python.

## Gates

PASS de **correção TEST em adaptador**, reprodutibilidade, recibos READ-ONLY. HOLD para adoção do gateway em runtime R26/R27, adjudicação de RE, recalibração por benchmarks E0 independentes, interface produtiva e experiência material CRAFT P2/H2/RC5. Não entregue este pacote Mestre-only a revisores cegos.
