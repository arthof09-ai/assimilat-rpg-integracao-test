#!/usr/bin/env python3
import json,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
r53=subprocess.run([sys.executable,'run_r53_cold.py'],cwd=ROOT,capture_output=True,text=True,timeout=180)
if r53.returncode:raise AssertionError('R53_REGRESSION_FAIL: '+r53.stderr[-2000:])
parent=json.loads(r53.stdout)
assert parent['total_test_runs_unique_suites']==118
new=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r54.py','-q'],cwd=ROOT,capture_output=True,text=True,timeout=80)
if new.returncode or 'Ran 60 tests' not in new.stderr:raise AssertionError('R54_REGRESSION_FAIL: '+new.stderr[-2500:])
sys.path.insert(0,str(ROOT/'src'))
from item_resource_qc_r54 import audit_item,audit_resource,review_techniques_as_candidates
D=json.loads((ROOT/'fixtures/r54_readiness_inputs.json').read_text())
T=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text())
assert review_techniques_as_candidates(T,[])['e0_effects_authorized']==0
item=audit_item(D['item_test_only'],D['resource_registry'])
resource=audit_resource(D['known_resource_case'],D['resource_registry'])
assert resource['state']=='REUSE_EXISTING' and item['production_gate']=='HOLD'
print(json.dumps({'status':'PASS_R54_COLD_TEST','R53_test_runs':118,'R54_new_tests':60,
  'total_test_runs_current_cycle':178,'bronze_nominal_techniques':2,'prata_nominal_techniques':6,
  'isolated_effect_E0_authorized':0,'existing_resource_reuse':1,'new_resources':0,
  'R26_R53_unmodified':True,'official_pa_consumed':0,'prod_gate':'HOLD',
  'notion_writes':0,'party_writes':0,'o_primeiro_writes':0},sort_keys=True))
