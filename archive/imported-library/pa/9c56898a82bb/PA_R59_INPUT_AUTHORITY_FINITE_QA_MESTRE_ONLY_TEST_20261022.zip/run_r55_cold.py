#!/usr/bin/env python3
import subprocess,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
old=subprocess.run([sys.executable,'run_r54_cold.py'],cwd=ROOT,capture_output=True,text=True,timeout=240)
if old.returncode:raise RuntimeError(old.stderr[-4000:])
b=json.loads(old.stdout);assert b['total_test_runs_current_cycle']==178
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r55.py','-q'],cwd=ROOT,capture_output=True,text=True,timeout=80)
if r.returncode or 'Ran 32 tests' not in r.stderr:raise RuntimeError(r.stderr[-3000:])
sys.path.insert(0,str(ROOT/'src'))
from effect_crosswalk_r55 import verify_eight_images,compare_four,disagreement_census
x=json.loads((ROOT/'evidence/R55_VISUAL_8_TECHNIQUES_AND_CROSSWALK.json').read_text());c=json.loads((ROOT/'evidence/R55_FOUR_E2_COMPARATOR_DIFFERENCES.json').read_text())
assert verify_eight_images(x)['errors']==[] and compare_four(x,c)['issues']==[]
print(json.dumps({'status':'PASS_R55_COLD_TEST','R54_R53_legacy_test_runs':178,'R55_new_tests':32,
 'total_test_runs_this_chain':210,'original_images_recovered_and_sha_verified':8,
 'historical_label_vs_R45_provisional_disagreements':3,'historical_label_denominator':8,
 'four_case_partial_analogues':4,'four_case_full_homologues_adjudicated':0,
 'canonical_effect_RE_adjudications':0,'official_pa_consumed':0,'prod_gate':'HOLD','notion_writes':0,'party_writes':0},sort_keys=True))
