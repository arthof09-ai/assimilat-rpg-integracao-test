import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from item_resource_qc_r54 import audit_item,audit_resource,review_techniques_as_candidates,canon,CATEGORIES
D=json.loads((ROOT/'fixtures/r54_readiness_inputs.json').read_text()); REG=D['resource_registry']; ITEM=D['item_test_only']; RESOURCE=D['known_resource_case']
class R54(unittest.TestCase):
 def item(self,**changes):
  d=copy.deepcopy(ITEM);d.update(changes);return audit_item(d,REG)
 def res(self,**changes):
  d=copy.deepcopy(RESOURCE);d.update(changes);return audit_resource(d,REG)
 def test_01_original_item_not_created(self):self.assertFalse(self.item()['official_item_created'])
 def test_02_no_real_pa(self):self.assertIsNone(self.item()['official_pa_consumed'])
 def test_03_no_magic(self):self.assertIsNone(self.item()['magical_effect_installed'])
 def test_04_no_official_world_write(self):self.assertFalse(self.item()['notion_write'])
 def test_05_no_party_write(self):self.assertFalse(self.item()['party_write'])
 def test_06_no_o_primeiro_write(self):self.assertFalse(self.item()['o_primeiro_write'])
 def test_07_no_rc5(self):self.assertFalse(self.item()['rc5_authorized'])
 def test_08_bom_process_reconciled(self):self.assertTrue(self.item()['reconciled_bom_process'])
 def test_09_unknown_energy_blocks(self):self.assertIn('ORIGINAL_PA_ENVELOPE_NOT_PRESENT',self.item()['blocking_reasons'])
 def test_10_no_effect_E0(self):self.assertIn('EFFECT_0_E0_AUTHORITY_MISSING',self.item()['blocking_reasons'])
 def test_11_yield_unknown(self):self.assertIn('YIELD_UNKNOWN_BLOCKS_RC5',self.item()['blocking_reasons'])
 def test_12_misroute(self):self.assertIn('WRONG_CANONICAL_MODULE',self.item(rec_mod='REC-MOD-ARM-01')['blocking_reasons'])
 def test_13_stars_for_item(self):self.assertIn('RI_UNKNOWN',self.item(RI='Prata 2★')['blocking_reasons'])
 def test_14_no_rank_inherit(self):self.assertIn('RIN_RI_RE_CROSS_INHERITANCE',self.item(ri_from_resource=True)['blocking_reasons'])
 def test_15_unauthorized_pa(self):self.assertIn('OFFICIAL_PA_DIRECT_INPUT_NOT_ALLOWED',self.item(official_pa_daily=999)['blocking_reasons'])
 def test_16_false_prod(self):self.assertIn('AUTOMATIC_AUTHORITY_CLAIM_PROHIBITED',self.item(approval_claim='PROD')['blocking_reasons'])
 def test_17_existing_first(self):self.assertIn('EXISTING_FIRST_NOT_PROVED',self.item(existing_search_done=False)['blocking_reasons'])
 def test_18_existing_equivalent(self):self.assertIn('REUSE_EXISTING_ITEM_BEFORE_NEW_ONE',self.item(existing_equivalent=True)['blocking_reasons'])
 def test_19_missing_section(self):self.assertTrue(any(s.startswith('PR_ITEM_I_XIII_MISSING:') for s in self.item(sections_reviewed=['identidade'])['blocking_reasons']))
 def test_20_mestre_only_layer(self):self.assertIn('MESTRE_LAYER_INCOMPLETE',self.item(mestre_only_complete=False)['blocking_reasons'])
 def test_21_party_projection(self):self.assertIn('PLAYER_PROJECTION_NOT_SAFE',self.item(player_projection_safe=False)['blocking_reasons'])
 def test_22_unconsumed_bom(self):self.assertTrue(any(s.startswith('BOM_UNCONSUMED:') for s in self.item(process=[{'action':'x','consumes':[]}])['blocking_reasons']))
 def test_23_missing_bom_resource(self):self.assertIn('BOM_0_RESOURCE_UNRESOLVED',self.item(bom=[{'id':'FAKE','quantity':1,'unit':'u','role':'x','RIn':'Prata'}])['blocking_reasons'])
 def test_24_process_orphan(self):self.assertTrue(any(s.startswith('PROCESS_USE_NOT_IN_BOM:') for s in self.item(process=[{'action':'x','consumes':['NO_SUCH']}])['blocking_reasons']))
 def test_25_intermediate_orphan(self):self.assertIn('INTERMEDIATE_ORPHAN',self.item(process=[{'action':'mix','consumes':[r['id'] for r in REG.values()],'uses_intermediates':['UNCREATED']}])['blocking_reasons'])
 def test_26_zero_quantity(self):
  bom=copy.deepcopy(ITEM['bom']);bom[0]['quantity']=0;self.assertIn('BOM_0_QUANTITY_UNIT_MISSING',self.item(bom=bom)['blocking_reasons'])
 def test_27_no_role(self):
  bom=copy.deepcopy(ITEM['bom']);bom[0]['role']='';self.assertIn('BOM_0_ROLE_MISSING',self.item(bom=bom)['blocking_reasons'])
 def test_28_auto_transfer(self):
  bom=copy.deepcopy(ITEM['bom']);bom[0]['auto_power_transfer']=True;self.assertIn('BOM_0_TRANSFER_NOT_DEMONSTRATED',self.item(bom=bom)['blocking_reasons'])
 def test_29_false_qa_magic(self):
  effects=copy.deepcopy(ITEM['effects']);effects[0]['magic_installed']=True;self.assertIn('EFFECT_0_INSTALLATION_CLAIM_NOT_PROVEN',self.item(effects=effects)['blocking_reasons'])
 def test_30_no_pa_suggestion(self):
  effects=copy.deepcopy(ITEM['effects']);effects[0]['PA_suggested']=300;self.assertIn('EFFECT_0_ENERGY_CLAIM_NOT_AUTHORIZED',self.item(effects=effects)['blocking_reasons'])
 def test_31_negative_yield(self):self.assertIn('YIELD_INVALID',self.item(approved_units=-3)['blocking_reasons'])
 def test_32_bom_bool_qty(self):
  bom=copy.deepcopy(ITEM['bom']);bom[0]['quantity']=True;self.assertIn('BOM_0_QUANTITY_UNIT_MISSING',self.item(bom=bom)['blocking_reasons'])
 def test_33_resource_reuse(self):self.assertEqual(self.res()['state'],'REUSE_EXISTING')
 def test_34_resource_alias_normalization(self):self.assertEqual(self.res(name='FIBRA-DE CASCA BOREAL')['state'],'REUSE_EXISTING')
 def test_35_resource_no_duplicate_id(self):self.assertEqual(self.res()['existing_id'],'3f3c2b324ede815ab04ace5bd1074e79')
 def test_36_resource_novel_missing_search(self):self.assertTrue(any('BUSCA_CRN_INCOMPLETE:' in s for s in self.res(name='NOVO TEST',search_checked=[])['blocking_reasons']))
 def test_37_resource_p3_requires_geo(self):self.assertIn('GEO_SOURCE_REQUIRED',self.res(name='NOVO TEST',geography_source=None)['blocking_reasons'])
 def test_38_resource_p3_requires_ecology(self):self.assertIn('ECOLOGY_SOURCE_REQUIRED',self.res(name='NOVO TEST',ecology_source=None)['blocking_reasons'])
 def test_39_resource_p3_requires_function(self):self.assertIn('RESOURCE_INNATE_FUNCTION_UNPROVEN',self.res(name='NOVO TEST',function_independent_of_recipe='')['blocking_reasons'])
 def test_40_resource_no_p4(self):self.assertIn('AUTHORITY_PROMOTION_NOT_ALLOWED_BY_QA',self.res(name='NOVO TEST',approved_p4=True)['blocking_reasons'])
 def test_41_resource_no_new_id(self):self.assertIn('AUTHORITATIVE_VALUE_OR_ID_NOT_ALLOWED',self.res(name='NOVO TEST',new_crn_id='CRN-MADE-UP')['blocking_reasons'])
 def test_42_resource_no_rin_inherit(self):self.assertIn('CANNOT_INHERIT_RE_OR_RI_FROM_RIN',self.res(name='NOVO TEST',re_rank_from_rin=True)['blocking_reasons'])
 def test_43_resource_still_not_p4_even_valid_candidate(self):
  v=self.res(name='NOVO TEST');self.assertEqual(v['state'],'P3_DOSSIER_CANDIDATE_TEST_ONLY');self.assertFalse(v['official_item_created'])
 def test_44_resource_no_precise_med(self):self.assertIn('AUTHORITATIVE_VALUE_OR_ID_NOT_ALLOWED',self.res(name='NOVO TEST',precise_med=500)['blocking_reasons'])
 def test_45_catalog_eight(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());self.assertEqual(len(r['records']),8)
 def test_46_catalog_two_six(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());self.assertEqual(review_techniques_as_candidates(r,[])['source_nominal_rank_census'],{'Bronze':2,'Prata':6})
 def test_47_catalog_no_e0(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());self.assertEqual(review_techniques_as_candidates(r,[])['e0_effects_authorized'],0)
 def test_48_catalog_immune_to_fake_e0(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());r['records'][0]['isolated_effect_RE_adjudicated']=True;self.assertIn('E0_CLAIM_INADMISSIBLE_WITHOUT_AUTHORITY',review_techniques_as_candidates(r,[])['issues'])
 def test_49_catalog_needs_8_distinct(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());r['records'][1]['page_id']=r['records'][0]['page_id'];self.assertIn('8_UNIQUE_SOURCES_REQUIRED',review_techniques_as_candidates(r,[])['issues'])
 def test_50_no_image_mechanics_inferred(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());r['records'][0]['mechanics_source']='decoded_magic_by_name';self.assertIn('UNVERIFIED_IMAGE_MECHANICS_CLAIM',review_techniques_as_candidates(r,[])['issues'])
 def test_51_technique_rank_not_pa(self):
  r=json.loads((ROOT/'evidence/BRONZE_PRATA_8_DIRECT_READBACK_R54.json').read_text());self.assertIsNone(review_techniques_as_candidates(r,[])['official_pa_consumed'])
 def test_52_public_star_not_item(self):self.assertEqual(CATEGORIES['acessorio'],'REC-MOD-EQA-01')
 def test_53_canonicalization_accent(self):self.assertEqual(canon('Erva da Luz do Norte'),canon('erva-da-luz do norte'))
 def test_54_no_prod_with_forged_full_fixture(self):
  fx=copy.deepcopy(ITEM);fx['effects'][0]['individual_E0_adjudication']=True;fx['effects'][0]['authority_source_direct_readback']='claimed';fx['approved_units']=1;fx['qa_material']='claimed';fx['qa_magic']='claimed';fx['energy_receipt_source_r26_r27']='claimed';fx['economy_source']='claimed'
  out=audit_item(fx,REG);self.assertEqual(out['state'],'DESIGN_QA_TEST_ONLY');self.assertEqual(out['production_gate'],'HOLD');self.assertFalse(out['rc5_authorized'])
 def test_55_artifact_misroute(self):self.assertIn('WRONG_CANONICAL_MODULE',self.item(category='artefato')['blocking_reasons'])
 def test_56_error_on_unknown_rank(self):self.assertIn('RI_UNKNOWN',self.item(RI='Divino')['blocking_reasons'])
 def test_57_error_on_missing_effect_duration(self):
  e=copy.deepcopy(ITEM['effects']);e[0]['duration']='';self.assertIn('EFFECT_0_MECHANICS_INCOMPLETE',self.item(effects=e)['blocking_reasons'])
 def test_58_resource_not_recipe(self):self.assertNotEqual(self.res()['kind'],'item')
 def test_59_no_historical_rin_credit(self):self.assertEqual(REG['Cristal de Aurora Boreal']['evidence'],'E2/PS')
 def test_60_five_modules(self):self.assertEqual(len(CATEGORIES),5)
if __name__=='__main__':unittest.main()
