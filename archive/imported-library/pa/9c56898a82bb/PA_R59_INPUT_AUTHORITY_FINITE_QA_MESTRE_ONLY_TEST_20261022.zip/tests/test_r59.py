import unittest,json,copy,math,random
from src.qa_intake_r59 import run_resource,run_item,run_module,run_substitution
from src.hardened_route_r58 import run_item as base_item,run_resource as base_resource,run_module as base_module,run_substitution as base_sub
REG={'cristal':{'id':'c1','name':'Cristal Aurora'},'erva':{'id':'e1','name':'Erva da Luz'}}
class R59Boundary(unittest.TestCase):
 def test_001_duplicate_ids(self):
  reg={'a':{'id':'x','name':'x'},'b':{'id':'x','name':'y'}}
  self.assertEqual(run_item({},reg)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_002_duplicate_alias_accents(self):
  reg={'agua pura':{'id':'a','name':'a'},'ÁGUA-PURA':{'id':'b','name':'b'}}
  self.assertIn('COLLIDING_CANONICAL',run_resource({},reg)['blocking_reasons'][0])
 def test_003_empty_name(self):
  for reg in ({'x':{'id':'','name':'a'}},{'x':{'id':'a','name':''}},{'':{'id':'a','name':'b'}}):
   self.assertEqual(run_resource({},reg)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_004_empty_source_id(self):
  self.assertEqual(run_substitution({'source_id':' ','role':'a','maturity':'P4'},{'source_id':'b','role':'a','maturity':'P4'},{'substitution_grade':'S1'})['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_005_bool_units(self):
  for x in (True,False,-1,1.0,float('nan'),'3'):
   with self.subTest(x=x):self.assertEqual(run_item({'approved_units':x},REG).get('status'),'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_006_valid_units_not_evidence(self):
  for x in (0,1,50):self.assertNotEqual(run_item({'approved_units':x},REG).get('status'),'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_007_bad_quantity(self):
  for x in (True,False,0,-2,'1',None,float('nan'),float('inf'),float('-inf'),[],{}):
   with self.subTest(x=str(x)):self.assertEqual(run_item({'bom':[{'id':'c1','quantity':x}]},REG).get('status'),'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_008_good_quantity(self):
  for x in (1,.5,2.5):self.assertNotEqual(run_item({'bom':[{'id':'c1','quantity':x}]},REG).get('status'),'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_009_duplicate_bom_id(self):
  self.assertEqual(run_item({'bom':[{'id':'c1','quantity':1},{'id':'c1','quantity':2}]},REG)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_010_staged_e0_boolean(self):
  for e in ({'individual_E0_adjudication':True},{'authority_source_direct_readback':'https://example.org'},{'authority_source_direct_readback':True}):
   self.assertEqual(run_item({'effects':[e]},REG)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_011_without_e0_claim_parity(self):
  x={'RI':'Prata','category':'acessorio','bom':[{'id':'c1','quantity':1}]}
  self.assertEqual(run_item(x,REG),base_item(x,REG))
 def test_012_existing_resource_parity(self):
  x={'name':'Cristal Aurora','aliases':[]};self.assertEqual(run_resource(x,REG),base_resource(x,REG))
 def test_013_unknown_good_resource_parity(self):
  x={'name':'Mineral Novo','aliases':[]};self.assertEqual(run_resource(x,REG),base_resource(x,REG))
 def test_014_valid_substitution_parity(self):
  a={'source_id':'c1','role':'suporte','maturity':'P4'};b={'source_id':'e1','role':'suporte','maturity':'P4'};c={'substitution_grade':'S1'}
  self.assertEqual(run_substitution(a,b,c),base_sub(a,b,c))
 def test_015_module_parity(self):
  x={'source_id':'c1','steps':[]};self.assertEqual(run_module('arma',x),base_module('arma',x))
 def test_016_module_nonstring_ref(self):
  for v in ('',4,[],{},None):
   if v is None:continue
   self.assertEqual(run_module('arma',{'source_id':v,'steps':[]})['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_017_no_self_e0(self):
  x={'effects':[{'individual_E0_adjudication':True,'RE':'Prata','authority_source_direct_readback':'true'}]}
  y=run_item(x,REG);self.assertIsNone(y['canonical_RE']);self.assertEqual(y['production_gate'],'HOLD')
 def test_018_no_party_write(self):
  for v in [run_item({},REG),run_resource({},REG),run_module('arma',{}),run_substitution({}, {}, {})]:
   self.assertFalse(v['party_write']);self.assertFalse(v['notion_write'])
 def test_019_unicode_normalization_collision(self):
  r={'MUSGO-DO-NORTE':{'id':'m','name':'Musgo'},'musgo do norte':{'id':'n','name':'Musgo2'}}
  self.assertEqual(run_item({},r)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_020_duplicate_proposal_alias(self):
  x={'name':'Raíz Lunar','aliases':['RAIZ LUNAR']};self.assertIn('DUPLICATE',run_resource(x,REG)['blocking_reasons'][0])
 def test_021_malformed_origins_untrusted(self):
  for v in [None,[],{},2,'']:self.assertEqual(run_item({}, {'x':v})['production_gate'],'HOLD')
 def test_022_gigantic_numeric_finite(self):
  self.assertNotEqual(run_item({'bom':[{'id':'c1','quantity':1e308}]},REG).get('status'),'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_023_foreign_rank_not_E0(self):
  d={'effects':[{'RE':'Prata','individual_E0_adjudication':True,'authority_source_direct_readback':'foreign_level_2'}]}
  self.assertEqual(run_item(d,REG)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_024_unknown_source_ref_not_promote(self):
  self.assertEqual(run_item({'effects':[{'authority_source_direct_readback':'unknown'}]},REG)['status'],'HOLD_EVIDENCE_OR_SCHEMA_R59')
 def test_025_empty_registry_allowed_but_hold(self):
  self.assertEqual(run_item({}, {})['production_gate'],'HOLD')
 def test_026_name_case_source_matching(self):
  self.assertEqual(run_resource({'name':'CRISTAL'},REG)['state'],'REUSE_EXISTING')
 def test_027_different_valid_aliases(self):
  self.assertEqual(run_resource({'name':'Mineral Novo','aliases':['Quartzito']},REG),base_resource({'name':'Mineral Novo','aliases':['Quartzito']},REG))
 def test_028_valid_no_claim_effect_parity(self):
  x={'effects':[{'RE':'Bronze','mechanic':'visao','duration':'1h','activation':'acao','limits':'distancia'}]}
  self.assertEqual(run_item(x,REG),base_item(x,REG))
 def test_029_duplicate_ids_no_leak(self):
  r={'x':{'id':'same','name':'a'},'y':{'id':'same','name':'b'}}
  x=run_resource({},r);self.assertIsNone(x['canonical_RE'])
 def test_030_numeric_zero_bool_not_permitted(self):
  for x in [0,False]:self.assertEqual(run_item({'bom':[{'id':'c1','quantity':x}]},REG).get('status'),'HOLD_EVIDENCE_OR_SCHEMA_R59')

# Additional batch-based adversarial tests use fixed seeds for reproducibility
 def test_031_deterministic_adversarial(self):
  rng=random.Random(31)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_032_deterministic_adversarial(self):
  rng=random.Random(32)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_033_deterministic_adversarial(self):
  rng=random.Random(33)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_034_deterministic_adversarial(self):
  rng=random.Random(34)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_035_deterministic_adversarial(self):
  rng=random.Random(35)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_036_deterministic_adversarial(self):
  rng=random.Random(36)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_037_deterministic_adversarial(self):
  rng=random.Random(37)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_038_deterministic_adversarial(self):
  rng=random.Random(38)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_039_deterministic_adversarial(self):
  rng=random.Random(39)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_040_deterministic_adversarial(self):
  rng=random.Random(40)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_041_deterministic_adversarial(self):
  rng=random.Random(41)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_042_deterministic_adversarial(self):
  rng=random.Random(42)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_043_deterministic_adversarial(self):
  rng=random.Random(43)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_044_deterministic_adversarial(self):
  rng=random.Random(44)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_045_deterministic_adversarial(self):
  rng=random.Random(45)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_046_deterministic_adversarial(self):
  rng=random.Random(46)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_047_deterministic_adversarial(self):
  rng=random.Random(47)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_048_deterministic_adversarial(self):
  rng=random.Random(48)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_049_deterministic_adversarial(self):
  rng=random.Random(49)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])
 def test_050_deterministic_adversarial(self):
  rng=random.Random(50)
  variants=[{'bom':[{'id':'c1','quantity':float('nan')}]},{'effects':[{'individual_E0_adjudication':True}]},{'approved_units':True},{'bom':[{'id':'c1','quantity':float('inf')}]}]
  for _ in range(20):
   result=run_item(rng.choice(variants),REG)
   self.assertIn(result['status'],('HOLD_EVIDENCE_OR_SCHEMA_R59',))
   self.assertEqual(result['production_gate'],'HOLD')
   self.assertIsNone(result['canonical_RE'])

if __name__=="__main__":unittest.main()
