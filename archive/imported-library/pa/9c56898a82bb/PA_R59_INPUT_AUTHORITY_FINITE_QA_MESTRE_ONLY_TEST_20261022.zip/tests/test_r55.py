import unittest,copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from effect_crosswalk_r55 import verify_eight_images,compare_four,disagreement_census
X=json.loads((ROOT/'evidence/R55_VISUAL_8_TECHNIQUES_AND_CROSSWALK.json').read_text())
C=json.loads((ROOT/'evidence/R55_FOUR_E2_COMPARATOR_DIFFERENCES.json').read_text())
class R55(unittest.TestCase):
 def test_01_eight_images(self):self.assertEqual(verify_eight_images(X)['images_checked'],8)
 def test_02_shas_valid(self):self.assertEqual(verify_eight_images(X)['errors'],[])
 def test_03_four_cases(self):self.assertEqual(compare_four(X,C)['target_count'],4)
 def test_04_four_not_homolog(self):self.assertEqual(compare_four(X,C)['full_homologous_comparators_proven'],0)
 def test_05_rank_none(self):self.assertEqual(compare_four(X,C)['adjudications'],0)
 def test_06_three_disagreements(self):self.assertEqual(disagreement_census(X)['nominal_vs_provisional_TEST_conflict_numerator'],3)
 def test_07_disagree_name_lufada(self):self.assertIn('Lufada',disagreement_census(X)['disagreement_names'])
 def test_08_disagree_name_raio(self):self.assertIn('Raio de Fogo',disagreement_census(X)['disagreement_names'])
 def test_09_disagree_name_ataque(self):self.assertIn('Ataque Certeiro',disagreement_census(X)['disagreement_names'])
 def test_10_original_no_writes(self):self.assertFalse(compare_four(X,C)['notion_write'])
 def test_11_pa_unknown_not_zero(self):self.assertIsNone(compare_four(X,C)['official_pa_consumed'])
 def test_12_no_party(self):self.assertFalse(compare_four(X,C)['party_write'])
 def test_13_cannot_fake_sha(self):
  d=copy.deepcopy(X);d['records'][0]['original_image_sha256']='0'*64;self.assertTrue(any('IMAGE_SHA_FAIL' in e for e in verify_eight_images(d)['errors']))
 def test_14_cannot_fake_E0(self):
  d=copy.deepcopy(X);d['records'][0]['re_adjudicated_E0']=True;self.assertTrue(any('E0_CANNOT_BE_INFERRED' in e for e in verify_eight_images(d)['errors']))
 def test_15_foreign_level_no_rank(self):
  d=copy.deepcopy(X);d['records'][0]['level_scaling']='MAP_LEVEL_TO_RANK';self.assertTrue(any('FOREIGN_LEVEL_SCALE_MISUSED' in e for e in verify_eight_images(d)['errors']))
 def test_16_missing_mechanics(self):
  d=copy.deepcopy(X);d['records'][0]['action_original']=None;self.assertTrue(any('MECHANICS_OR_SOURCE_INCOMPLETE' in e for e in verify_eight_images(d)['errors']))
 def test_17_fake_duplicate_image_id(self):
  d=copy.deepcopy(X);d['records'][0]['case_id']=d['records'][1]['case_id'];self.assertIn('8_INDEPENDENT_IMAGE_CASES_REQUIRED',verify_eight_images(d)['errors'])
 def test_18_cannot_claim_re_from_analogue(self):
  d=copy.deepcopy(C);d['cases'][0]['candidate_effect_RE_E0']='Prata';self.assertIn('CANONICAL_RANK_CLAIM_UNAUTHORIZED:'+d['cases'][0]['target'],compare_four(X,d)['issues'])
 def test_19_unmatched_id_not_source(self):
  d=copy.deepcopy(C);d['cases'][0]['closest_visual_sources']=['not-a-real-page'];self.assertTrue(any('UNKNOWN_CANDIDATE' in e for e in compare_four(X,d)['issues']))
 def test_20_refuse_false_equivalence(self):
  d=copy.deepcopy(C);d['cases'][0]['not_equivalent']=[];self.assertTrue(any('FALSE_EQUIVALENCE' in e for e in compare_four(X,d)['issues']) )
 def test_21_duplicate_target(self):
  d=copy.deepcopy(C);d['cases'][0]['target']=d['cases'][1]['target'];self.assertIn('FOUR_TARGETS_REQUIRED',compare_four(X,d)['issues'])
 def test_22_two_bronze_labels(self):self.assertEqual(sum(r['notion_nominal_rank']=='Bronze' for r in X['records']),2)
 def test_23_six_silver_labels(self):self.assertEqual(sum(r['notion_nominal_rank']=='Prata' for r in X['records']),6)
 def test_24_r45_only_informational(self):self.assertTrue(all(r['authority']=='HISTORICAL_TECHNIQUE_LABEL_NOT_INDIVIDUAL_RE' for r in X['records']))
 def test_25_same_title_name_mapped(self):self.assertEqual(len({r['name'] for r in X['records']}),8)
 def test_26_image_path_root(self):self.assertTrue(all(r['image_path'].startswith('evidence/source_visual_eight/') for r in X['records']))
 def test_27_infer_not_price(self):self.assertTrue(all('notion_source_url' in r for r in X['records']))
 def test_28_labels_do_not_price(self):self.assertTrue(all(r['re_adjudicated_E0'] is False for r in X['records']))
 def test_29_lufada_force_save(self):self.assertIn('resistencia_forca',str([r for r in X['records'] if r['name']=='Lufada'][0]['mechanical_conditions_original']))
 def test_30_raio_no_reaction_suppression(self):self.assertNotIn('reacao',str([r for r in X['records'] if r['name']=='Raio de Fogo'][0]['mechanical_conditions_original']))
 def test_31_r47_provenance(self):self.assertEqual(len(X['source_r47_sha256']),64)
 def test_32_act_bonus_marca(self):self.assertEqual([r for r in X['records'] if r['name']=='Marca do Caçador'][0]['action_original'],'acao_bonus')
if __name__=='__main__':unittest.main()
