from pathlib import Path
import unittest, sys, json, tempfile, hashlib, copy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from gateway_r52 import (pinned_registry, verify_native, stage_effect_e0_claim,
                         assess,generate,sha,VALID_RANKS,EXPECTED_R26_SHA,EXPECTED_REGISTRY_SHA)
from source_fence import fence, source_registry,notion_id
REG=pinned_registry()
CASES=json.loads((ROOT/'fixtures/four_cases.json').read_text())['cases']
ONE=CASES[0]

def claim(**kw):
    d={'source_uuid':'836c2b324ede83e2aae6016379ef2135',
       'proposed_effect_RE':'Prata',
       'effect_mechanics_quote':'Retaliação a um ataque sofrido com Reação, segundo a habilidade escrita.',
       'authorizing_master_decision_id':'MESTRE-DECISAO-E0-R52'}
    d.update(kw);return d

class RegistryAndAuthTests(unittest.TestCase):
    def test_pinned_hash(self): self.assertEqual(sha(ROOT/'fixtures/sources.json'),EXPECTED_REGISTRY_SHA)
    def test_pinned_native_hash(self): self.assertEqual(sha(ROOT/'baseline_r26/parecer_semicanonico_r26.py'),EXPECTED_R26_SHA)
    def test_registry_existing(self): self.assertEqual(len(REG),13)
    def test_13_effects_not_e0(self): self.assertEqual(sum(bool(s['effect_rank_adjudicated']) for s in REG.values()),0)
    def test_reject_forged_registry_true(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'sources.json';s=json.loads((ROOT/'fixtures/sources.json').read_text());s['sources'][0]['effect_rank_adjudicated']=True;path.write_text(json.dumps(s))
            with self.assertRaisesRegex(ValueError,'NOT_PINNED'):pinned_registry(path)
    def test_reject_registry_with_added_fake_source(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'sources.json';s=json.loads((ROOT/'fixtures/sources.json').read_text());s['sources'].append(copy.deepcopy(s['sources'][0]));path.write_text(json.dumps(s))
            with self.assertRaisesRegex(ValueError,'NOT_PINNED'):pinned_registry(path)
    def test_reject_mutated_r26_code(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'parecer_semicanonico_r26.py';path.write_text('print(123)')
            with self.assertRaisesRegex(ValueError,'R26_NATIVE_HASH'):verify_native(path)
    def test_no_canonical_promotion_by_freeform_claim(self):
        c=stage_effect_e0_claim(claim(),REG)
        self.assertEqual(c['state'],'HOLD_EXTERNAL_AUTHORITY_READBACK');self.assertFalse(c['sufficient_to_promote'])
        self.assertFalse(c['authority_verified']);self.assertFalse(c['isolated_RE_E0_verified'])
    def test_named_master_decision_is_not_cryptographic_proof(self):
        for x in ['MESTRE-DECISAO-E0-R52','MESTRE-FAKE-NOT-VERIFIED']:
            c=stage_effect_e0_claim(claim(authorizing_master_decision_id=x),REG)
            self.assertFalse(c['authority_verified'])
    def test_item_rank_not_effect_rank(self):
        c=stage_effect_e0_claim(claim(source_uuid='3f5c2b324ede81f5ac62fb940204cdac'),REG)
        self.assertIn('RN_OR_RI_CANNOT_PROVE_ISOLATED_RE',c['errors'])
    def test_actor_rank_not_effect_rank(self):
        c=stage_effect_e0_claim(claim(source_uuid='b06c2b324ede8279a0f4014c14125a98'),REG)
        self.assertIn('RN_OR_RI_CANNOT_PROVE_ISOLATED_RE',c['errors'])
    def test_invalid_rank_claim(self):
        for s in ['',None,'Bronze 1','Divino','Prata; PRODUCAO=PASS']:
            c=stage_effect_e0_claim(claim(proposed_effect_RE=s),REG)
            self.assertIn('INVALID_EFFECT_RANK_CLAIM',c['errors'])
    def test_no_master_decision(self):
        for s in [None,'', 'OK','MESTRE 1','MESTRE@1']:
            c=stage_effect_e0_claim(claim(authorizing_master_decision_id=s),REG)
            self.assertIn('MASTER_DECISION_REFERENCE_ABSENT',c['errors'])
    def test_absent_proof(self):
        c=stage_effect_e0_claim(claim(effect_mechanics_quote='some magic'),REG)
        self.assertIn('ISOLATED_MECHANICS_EVIDENCE_INSUFFICIENT',c['errors'])
    def test_unknown_source(self):
        c=stage_effect_e0_claim(claim(source_uuid='f'*32),REG)
        self.assertIn('SOURCE_NOT_IN_PINNED_REGISTRY',c['errors'])
    def test_nonobject(self):
        for v in [None,[],True]:
            with self.assertRaisesRegex(ValueError,'CLAIM_MUST_BE_OBJECT'):stage_effect_e0_claim(v,REG)
    def test_registry_immutability(self):
        before=sha(ROOT/'fixtures/sources.json');stage_effect_e0_claim(claim(),REG);self.assertEqual(sha(ROOT/'fixtures/sources.json'),before)

class GatewayTests(unittest.TestCase):
    def test_four_real_cases(self):
        v=generate(ROOT);self.assertEqual(v['n'],4);self.assertEqual(v['canonical_RE_authorized'],0)
        self.assertEqual(len({r['case_id'] for r in v['records']}),4)
    def test_four_media_not_promoted(self):
        v=generate(ROOT)
        for r in v['records']:
            self.assertEqual(r['native_r26_outputs'][0]['native_confidence'],'MEDIA')
            self.assertIsNone(r['canonical_RE']);self.assertEqual(r['isolated_E0_comparators'],0)
    def test_physical_unknown_is_null_not_false(self):
        for r in generate(ROOT)['records']:
            for s in ['physical_item_produced','magical_effect_installed','real_pa_consumed']:
                self.assertIsNone(r[s]);self.assertFalse(r['production_attempted_by_this_test'])
    def test_four_pa_authorization_absent(self):
        for r in generate(ROOT)['records']:
            self.assertIsNone(r['authorized_pa_daily']);self.assertIsNone(r['authorized_pa_use'])
    def test_no_remote_write(self):
        for r in generate(ROOT)['records']:
            self.assertFalse(r['notion_write']);self.assertFalse(r['party_write'])
    def test_rank_injection_rejected(self):
        x=copy.deepcopy(ONE);x['peer']='Lendário / WROTE_OFFICIAL'
        with self.assertRaisesRegex(ValueError,'UNSUPPORTED_PROPOSED_RANK'):assess(x,REG)
    def test_unsupported_source_rejected(self):
        x=copy.deepcopy(ONE);x['sources']=['a'*32]
        with self.assertRaisesRegex(ValueError,'OUTSIDE_PINNED_REGISTRY'):assess(x,REG)
    def test_unsupported_source_type_rejected(self):
        x=copy.deepcopy(ONE);x['sources']=['oops',23]
        with self.assertRaisesRegex(ValueError,'OUTSIDE_PINNED_REGISTRY'):assess(x,REG)
    def test_missing_case_id_rejected(self):
        x=copy.deepcopy(ONE);del x['case_id']
        with self.assertRaisesRegex(ValueError,'CASE_FIELD_MISSING'):assess(x,REG)
    def test_bad_sources_count_rejected(self):
        x=copy.deepcopy(ONE);x['sources']=['836c2b324ede83e2aae6016379ef2135']*31
        with self.assertRaisesRegex(ValueError,'CASE_SOURCES_INVALID'):assess(x,REG)
    def test_asof_not_live(self):
        for r in generate(ROOT)['records']:
            self.assertEqual(r['evidence_snapshot_asof'],'2026-10-21')
            self.assertFalse(r['evidence_live_verified_at_current_run'])
    def test_submitted_rank_not_equivalent_to_proof(self):
        x=copy.deepcopy(ONE)
        for rank in VALID_RANKS:
            x['peer']=rank;out=assess(x,REG)
            self.assertIsNone(out['canonical_RE']);self.assertIsNone(out['authority_approval'])
    def test_frozen_native_result_shape_not_changed(self):
        # Parent R51 was copied intact and receives no rewrite from R52.
        self.assertEqual(sha(ROOT/'src/source_fence.py'),'113801458392e95692423a01b00849c337987e07a8987b0fc6b98b3dad8b9b96')
        self.assertEqual(sha(ROOT/'outputs/r50_results.json'),'25c6016ba7953e9da853054cc32710f146d01330ef281e65d2d786b7584ed696')
        self.assertEqual(sha(ROOT/'outputs/r50_26_native_probe.json'),'ed9993f11c32e375e2db2301791db231be793d9c297e038a8f291b107cc507eb')
        self.assertEqual(len(json.loads((ROOT/'outputs/r50_results.json').read_text())['cases']),4)
    def test_actual_pinned_registry_tento_lineage(self):
        aa='d3fc2b324ede83c3a1bb01356904ce06';bb='33fc2b324ede830284c1819bfe775d2c'
        self.assertEqual(REG[aa]['lineage_group'],REG[bb]['lineage_group'])
        self.assertNotEqual(aa,bb)
    def test_canonical_is_none_even_with_many_sources(self):
        x=copy.deepcopy(ONE);x['sources']=list(REG)
        out=assess(x,REG)
        self.assertIsNone(out['canonical_RE']);self.assertEqual(out['isolated_E0_comparators'],0)

if __name__=='__main__':unittest.main()

from gateway_r52 import source_freshness_readback
class FreshnessTests(unittest.TestCase):
    def setUp(self):
        self.obs=json.loads((ROOT/'evidence/NOTION_READBACK_R52_ASOF_20261021.json').read_text())
    def test_13_identical_live_readback_asof(self):
        v=source_freshness_readback(self.obs,REG)
        self.assertEqual(v['status'],'REFERENCE_READBACK_STABLE_ASOF_DATE_ONLY')
        self.assertEqual(v['n_observed'],13)
        self.assertFalse(v['certifies_individual_effect_RE'])
    def test_changed_page_date_blocks(self):
        x=copy.deepcopy(self.obs);x['observations'][0]['page_last_edited_at']='2026-10-22T10:00:00Z'
        v=source_freshness_readback(x,REG)
        self.assertEqual(v['status'],'HOLD_SOURCE_REFRESH_REQUIRED')
    def test_changed_mechanical_quote_blocks(self):
        x=copy.deepcopy(self.obs);x['observations'][0]['verbatim_anchor']='ALTERED'
        self.assertEqual(source_freshness_readback(x,REG)['status'],'HOLD_SOURCE_REFRESH_REQUIRED')
    def test_fetch_truncation_blocks(self):
        x=copy.deepcopy(self.obs);x['observations'][0]['truncated']=True
        self.assertEqual(source_freshness_readback(x,REG)['status'],'HOLD_SOURCE_REFRESH_REQUIRED')
    def test_missing_one_page_blocks(self):
        x=copy.deepcopy(self.obs);x['observations']=x['observations'][:-1]
        self.assertEqual(source_freshness_readback(x,REG)['status'],'HOLD_SOURCE_REFRESH_REQUIRED')
    def test_duplicate_page_rejected(self):
        x=copy.deepcopy(self.obs);x['observations'].append(copy.deepcopy(x['observations'][0]))
        with self.assertRaisesRegex(ValueError,'DUPLICATE'):source_freshness_readback(x,REG)
    def test_untrusted_malformed_schema(self):
        with self.assertRaisesRegex(ValueError,'SCHEMA'):source_freshness_readback(None,REG)
