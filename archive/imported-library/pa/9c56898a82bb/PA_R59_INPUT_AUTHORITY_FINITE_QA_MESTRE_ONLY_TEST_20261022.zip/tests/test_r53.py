import unittest,copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from gateway_r52 import pinned_registry
from freshness_guard_r53 import audit_readback,generate
class R53Test(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.reg=pinned_registry();cls.data=json.loads((ROOT/'evidence/NOTION_READBACK_R53_ASOF_20261022.json').read_text())
 def test_01_baseline_13_recovered(self):self.assertEqual(len(self.reg),13)
 def test_02_new_13_matches(self):self.assertEqual(generate()['source_text_and_version_matches'],13)
 def test_03_claim_remains_none(self):self.assertIsNone(generate()['canonical_RE'])
 def test_04_cost_remains_none(self):self.assertIsNone(generate()['official_pa_authorized'])
 def test_05_truncation_unknown_not_forged(self):self.assertEqual(generate()['truncation_metadata_unavailable_count'],13)
 def test_06_weak_source_does_not_pass(self):self.assertEqual(generate()['status'],'HOLD_FULL_SOURCE_PROOF_METADATA_UNAVAILABLE')
 def test_07_no_prod_or_party(self):self.assertFalse(generate()['party_write'] or generate()['notion_write'])
 def test_08_wrong_date_fails(self):
  d=copy.deepcopy(self.data);d['asof_date']='2027-01-01'
  with self.assertRaises(ValueError):audit_readback(d,self.reg)
 def test_09_missing_source_changes_verification(self):
  d=copy.deepcopy(self.data);d['observations'].pop()
  self.assertFalse(audit_readback(d,self.reg)['source_text_and_version_reconciled'])
 def test_10_changed_anchor_changes_verification(self):
  d=copy.deepcopy(self.data);d['observations'][0]['verbatim_anchor']='ABC'
  self.assertFalse(audit_readback(d,self.reg)['source_text_and_version_reconciled'])
 def test_11_changed_edit_changes_verification(self):
  d=copy.deepcopy(self.data);d['observations'][0]['page_last_edited_at']='2026-10-22T00:00:00Z'
  self.assertFalse(audit_readback(d,self.reg)['source_text_and_version_reconciled'])
 def test_12_untrusted_source_class_rejected(self):
  d=copy.deepcopy(self.data);d['source']='AUTHORITATIVE_SIGNED'
  with self.assertRaises(ValueError):audit_readback(d,self.reg)
 def test_13_tampered_effect_rank_rejected(self):
  d=copy.deepcopy(self.data);d['e0_individual_effect_adjudicated']=1
  with self.assertRaises(ValueError):audit_readback(d,self.reg)
 def test_14_claimed_remote_write_rejected(self):
  d=copy.deepcopy(self.data);d['no_official_writes']=False
  with self.assertRaises(ValueError):audit_readback(d,self.reg)
 def test_15_cannot_pretend_truncation_known(self):
  d=copy.deepcopy(self.data)
  for x in d['observations']:x['truncated']=False
  self.assertEqual(audit_readback(d,self.reg)['status'],'HOLD_FULL_SOURCE_PROOF_METADATA_UNAVAILABLE')
 def test_16_forged_anchor_method_rejected(self):
  d=copy.deepcopy(self.data);d['observations'][0]['anchor_presence_method']='guessed'
  self.assertFalse(audit_readback(d,self.reg)['source_text_and_version_reconciled'])
 def test_17_unsupported_id_bad(self):
  d=copy.deepcopy(self.data);d['observations'][0]['id']=None
  with self.assertRaises(ValueError):audit_readback(d,self.reg)
 def test_18_proper_date_but_claim_unauthenticated(self):
  v=generate();self.assertFalse(v['continuous_source_authentication']);self.assertEqual(v['e0_adjudications'],0)
if __name__=='__main__':unittest.main()
