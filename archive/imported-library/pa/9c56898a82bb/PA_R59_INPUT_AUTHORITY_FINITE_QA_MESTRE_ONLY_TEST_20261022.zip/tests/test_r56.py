import unittest,copy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from module_contract_r56 import MODULES,SEQUENCE,audit_module,audit_substitution
class R56(unittest.TestCase):
 @staticmethod
 def fixture(cat):
  mod,fields=MODULES[cat];d={'module':mod,'source_id':'TEST-ONLY-SOURCE','steps':list(SEQUENCE[cat])}
  d.update({name:'TEST_DOCUMENTED_REQUIREMENT_NOT_PHYSICAL_PROOF' for name in fields})
  if cat=='artefato':d['replicabilidade']='prototipo'
  return d
 def test_01_routing_five(self):self.assertEqual(len(MODULES),5)
 def test_02_correct_families(self):self.assertEqual(set(MODULES),{'arma','armadura','acessorio','artefato','inscricao'})
 def test_03_no_new_item(self):self.assertFalse(audit_module('arma',self.fixture('arma'))['new_item'])
 def test_04_no_recipe(self):self.assertFalse(audit_module('arma',self.fixture('arma'))['new_recipe'])
 def test_05_not_physical_qa(self):self.assertFalse(audit_module('armadura',self.fixture('armadura'))['material_qa_certified'])
 def test_06_no_re(self):self.assertIsNone(audit_module('inscricao',self.fixture('inscricao'))['canonical_RE'])
 def test_07_no_pa(self):self.assertIsNone(audit_module('artefato',self.fixture('artefato'))['authorized_pa'])
 def test_08_no_prod(self):self.assertEqual(audit_module('acessorio',self.fixture('acessorio'))['production'],'HOLD')
 def test_09_unknown_type(self):self.assertEqual(audit_module('other',{})['status'],'HOLD_UNKNOWN_CANON_MODULE')
 def test_10_missing_module(self):self.assertIn('MODULE_MISMATCH',audit_module('arma',{})['issues'])
 def test_11_misroute_armor(self):self.assertIn('MODULE_MISMATCH',audit_module('armadura',self.fixture('arma'))['issues'])
 def test_12_missing_source(self):
  x=self.fixture('artefato');x.pop('source_id');self.assertIn('SOURCE_REQUIRED',audit_module('artefato',x)['issues'])
 def test_13_wrong_stage_order(self):
  x=self.fixture('inscricao');x['steps'].reverse();self.assertIn('MODULE_SEQUENCE_INCOMPLETE_OR_UNORDERED',audit_module('inscricao',x)['issues'])
 def test_14_invented_magic(self):
  x=self.fixture('arma');x['magic_transferred']=True;self.assertIn('MAGIC_TRANSFER_NOT_VERIFIED',audit_module('arma',x)['issues'])
 def test_15_self_approve(self):
  x=self.fixture('acessorio');x['self_approved']=True;self.assertIn('APPROVAL_ESCALATION_FORBIDDEN',audit_module('acessorio',x)['issues'])
 def test_16_invented_recharge(self):
  x=self.fixture('artefato');x['charges_invented']=True;self.assertIn('CHARGES_OR_REPAIR_NOT_PROVED',audit_module('artefato',x)['issues'])
 def test_17_artifact_unico_no_recipe(self):
  x=self.fixture('artefato');x['replicabilidade']='unico';x['new_recipe']=True;self.assertIn('UNIQUE_ARTIFACT_RECIPE_FORBIDDEN',audit_module('artefato',x)['issues'])
 def test_18_artifact_unknown_replication(self):
  x=self.fixture('artefato');x['replicabilidade']='super_poder';self.assertIn('REPLICABILITY_UNASSESSED',audit_module('artefato',x)['issues'])
 def test_19_inscription_secret(self):
  x=self.fixture('inscricao');x['knowledge_visible_to_players']=True;self.assertIn('SECRET_FORMULA_DISCLOSURE_FORBIDDEN',audit_module('inscricao',x)['issues'])
 def test_20_inscription_no_install(self):
  x=self.fixture('inscricao');x['magic_installed_claim']=True;self.assertIn('INSTALLATION_CANNOT_BE_ASSUMED',audit_module('inscricao',x)['issues'])
 def test_21_accessory_separate_effects(self):
  x=self.fixture('acessorio');x['passive_active_merged']=True;self.assertIn('PASSIVE_ACTIVE_MUST_BE_DISTINCT',audit_module('acessorio',x)['issues'])
 def test_22_weapon_damage_not_rank(self):
  x=self.fixture('arma');x['rank_from_damage_only']=True;self.assertIn('DMG_IS_NOT_AUTOMATIC_RE_RANK',audit_module('arma',x)['issues'])
 def test_23_armor_no_rin_ca(self):
  x=self.fixture('armadura');x['ca_from_rin']=True;self.assertIn('DEFENSE_NOT_SUM_OF_RIN',audit_module('armadura',x)['issues'])
 def test_24_all_five_complete_check_only(self):
  for c in MODULES:self.assertEqual(audit_module(c,self.fixture(c))['status'],'LAB_SPEC_CHECK_COMPLETE_ONLY')
 def test_25_substitution_same_resource(self):self.assertEqual(audit_substitution({'source_id':'ONE'},{'source_id':'ONE'}, {})['status'],'REUSE_SAME_RESOURCE_NO_CHANGE')
 def test_26_substitution_no_p4(self):self.assertEqual(self.sub()['status'],'HOLD_SUBSTITUTION_EVIDENCE')
 def test_27_substitution_no_pa(self):self.assertIsNone(self.sub()['authorized_pa'])
 def test_28_substitution_no_new_resource(self):self.assertFalse(self.sub()['new_resource'])
 def test_29_substitution_no_recipe(self):self.assertFalse(self.sub()['new_recipe'])
 def test_30_substitution_no_party(self):self.assertFalse(self.sub()['party_write'])
 @staticmethod
 def sub(**over):
  a={'source_id':'one','role':'ligante','maturity':'P4'};b={'source_id':'two','role':'ligante','maturity':'PS'};p={'substitution_grade':'S1','compatibility_test':None};p.update(over)
  return audit_substitution(a,b,p)
 def test_31_substitution_ps_not_p4(self):self.assertIn('UNAPPROVED_SOURCE_MATURITY',self.sub()['issues'])
 def test_32_compatibility_unknown(self):self.assertIn('COMPATIBILITY_UNTESTED',self.sub()['issues'])
 def test_33_rin_auto_power(self):self.assertIn('MAGICAL_POWER_TRANSFER_NOT_DEMONSTRATED',self.sub(inherit_rin_as_re=True)['issues'])
 def test_34_invented_recipe(self):self.assertIn('RECIPE_CREATION_UNAUTHORIZED',self.sub(new_recipe_id='NEW')['issues'])
 def test_35_invented_unchanged_rank(self):self.assertIn('RANK_UNCHANGED_NOT_PROVED',self.sub(rank_unchanged_by_assumption=True)['issues'])
 def test_36_magic_install(self):self.assertIn('MAGIC_INSTALLATION_NOT_PROVED',self.sub(automatic_install=True)['issues'])
 def test_37_grade_wrong(self):self.assertIn('SUBSTITUTION_CLASS_UNKNOWN',self.sub(substitution_grade='S100')['issues'])
 def test_38_missing_original_id(self):self.assertIn('PHYSICAL_SOURCE_REFERENCE_REQUIRED',audit_substitution({}, {'source_id':'b'}, {})['issues'])
 def test_39_function_difference(self):self.assertIn('FUNCTIONAL_ROLE_NOT_EQUIVALENT',audit_substitution({'source_id':'a','role':'ativo','maturity':'P4'},{'source_id':'b','role':'ligante','maturity':'P4'},{'substitution_grade':'S1','compatibility_test':'Test'})['issues'])
 def test_40_homolog_claim_still_not_allowed(self):
  v=audit_substitution({'source_id':'a','role':'ligante','maturity':'P4'},{'source_id':'b','role':'ligante','maturity':'P4'}, {'substitution_grade':'S1','compatibility_test':'TEST'})
  self.assertEqual(v['status'],'LAB_SUBSTITUTION_CANDIDATE_ONLY');self.assertFalse(v['RC5'])

# Generated independent missing-field unit tests, five real modules x their canonical mandatory fields.
def missing_field_test(cat,field):
 def f(self):
  x=self.fixture(cat);x[field]=''
  self.assertIn('MISSING_MODULE_FIELD:'+field,audit_module(cat,x)['issues'])
 return f
for cat,(_,fields) in MODULES.items():
 for i,field in enumerate(fields):
  setattr(R56,'test_required_'+cat+'_'+str(i).zfill(2),missing_field_test(cat,field))
if __name__=='__main__':unittest.main()
