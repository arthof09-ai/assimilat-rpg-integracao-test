"""R51 tests: input sanitation is advisory only. No Notion or RPG write."""
from __future__ import annotations
import unittest, sys, json, hashlib, tempfile, random
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from source_fence import source_registry, fence, sanitize_for_r26,wrap_native_result,notion_id
from runner import generate
from probe26 import run as probe26_run, corpus
REG=source_registry(HERE/'fixtures/sources.json')
RET='836c2b324ede83e2aae6016379ef2135'
MECH='REACTIVE_FIRE_SAVE_AT_RANGE'

def comp(uid=RET, *, quote=None,role=None,url=None,comparison=None):
 x=REG[uid]
 return {'url':url or 'https://app.notion.com/p/'+uid,'tipo':role or x['role'],
         'source_anchor':x['verbatim_anchor'] if quote is None else quote,
         'comparacao_mecanica': x['qualifier'] if comparison is None else comparison}

class DefensiveOrderTests(unittest.TestCase):
 def test_bad_quote_precedes_genuine(self):
  v=fence([comp(quote='FALSE_TEXT'),comp()],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
  self.assertIn('SOURCE_QUOTE_MISMATCH',v.reasons)
 def test_genuine_precedes_bad_quote(self):
  v=fence([comp(),comp(quote='FALSE_TEXT')],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
 def test_false_role_first(self):
  v=fence([comp(role='vivo'),comp()],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
 def test_absent_anchor_first(self):
  x=comp();del x['source_anchor']
  v=fence([x,comp()],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
 def test_short_explanation_first(self):
  v=fence([comp(comparison='nope'),comp()],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
 def test_unknown_source_first_then_valid(self):
  x=comp();x['url']='https://app.notion.com/p/'+'b'*32
  v=fence([x,comp()],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
 def test_malicious_url_first_then_valid(self):
  x=comp();x['url']='https://app.notion.com.evil.org/p/'+RET
  v=fence([x,comp()],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
 def test_two_accepted_variants_one(self):
  a,b=comp(),comp();a['url']+='?pvs=204';b['url']+='?pvs=205'
  v=fence([a,b],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(RET,))
  self.assertIn('UUID_DUPLICATE_VARIANT_QUERY',v.reasons)
 def test_perm_three_invalid_one_valid(self):
  choices=[comp(quote='false'),comp(role='vivo'),comp(comparison='x'),comp()]
  import itertools
  for p in itertools.permutations(choices):
   v=fence(list(p),REG,effect_mechanism=MECH)
   self.assertEqual(v.unique_sources,(RET,))
 def test_untrusted_all_fails(self):
  v=fence([comp(quote='X'),comp(role='vivo')],REG,effect_mechanism=MECH)
  self.assertFalse(v.eligible)
  self.assertIn('ZERO_USABLE_RESEARCH',v.reasons)
 def test_identity_distinct_mirrors(self):
  aa='d3fc2b324ede83c3a1bb01356904ce06';bb='33fc2b324ede830284c1819bfe775d2c'
  for order in [[aa,bb],[bb,aa]]:
   v=fence([comp(x) for x in order],REG,effect_mechanism=MECH)
   self.assertEqual(len(v.unique_sources),1)
   self.assertIn('MIRROR_TEXT_REPRESENTATION_NOT_INDEPENDENT',v.reasons)
 def test_wrong_first_mirror_valid_second(self):
  aa='d3fc2b324ede83c3a1bb01356904ce06';bb='33fc2b324ede830284c1819bfe775d2c'
  v=fence([comp(aa,quote='X'),comp(bb)],REG,effect_mechanism=MECH)
  self.assertEqual(v.unique_sources,(bb,))
 def test_all_references_stay_uncertified(self):
  for s in REG.values():
   self.assertIs(s['effect_rank_adjudicated'],False)
   self.assertEqual(fence([comp(s['id'])],REG,effect_mechanism=s['mechanism']).direct_sources,())
 def test_registry_false_adjudication_rejected(self):
  raw=json.loads((HERE/'fixtures/sources.json').read_text())
  raw['sources'][0]['effect_rank_adjudicated']=True
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'s.json';p.write_text(json.dumps(raw))
   with self.assertRaisesRegex(ValueError,'NO_INDEPENDENT_EFFECT_RANK_VERIFIED'):
    source_registry(p)
 def test_output_never_promotes(self):
  v=fence([comp()],REG,effect_mechanism=MECH)
  x=wrap_native_result({'r26':{'pareceres':[{'habilidade':'Z','rank_efeito_recomendado':'Lendário','estado':'PARECER_SEMICANONICO_COMPARATIVO','confianca':'MEDIA'}]},'pa_por_dia':123456},v)
  self.assertEqual(x['status'],'TEST_ADVISORY_NO_CANONICAL_PROMOTION')
  self.assertIsNone(x['canonical_RE'])
  self.assertIsNone(x['authorized_pa_use'])
  self.assertIsNone(x['authorized_pa_daily'])
  self.assertNotIn('pa_por_dia',str(x))
 def test_fake_proof_does_not_get_production_status(self):
  for proposed in ['Bronze','Prata','Ouro','Ouro Negro','Lendário']:
   v=sanitize_for_r26('fake',proposed,'Texto de contexto suficiente e coerente para teste documental.',[comp()],REG,MECH)
   self.assertTrue(v['fence'].eligible)
   x=wrap_native_result({},v['fence'])
   self.assertEqual(x['status'],'TEST_ADVISORY_NO_CANONICAL_PROMOTION')
 def test_no_catalog_price_info(self):
  raw=(HERE/'fixtures/visual_mechanics26_no_ranks.json').read_text().lower()
  for x in ['rank_proposal_test_only','candidate_range','r45_frozen','peer_frozen','med_price','historic_rank']:
   self.assertNotIn(x,raw)
 def test_count_exact_26(self):self.assertEqual(len(corpus(HERE)),26)
 def test_snapshot_not_live_auth(self):
  self.assertEqual(len(REG),13)
  self.assertTrue(all(x['anchor_checked_in_Notion_fetch_on']=='2026-10-21' for x in REG.values()))
  self.assertTrue(all(x['anchor_match_readback'] is True for x in REG.values()))
 def test_reordered_input_semantic_set(self):
  ids=list(REG)
  random.Random(51).shuffle(ids)
  a=fence([comp(s) for s in ids],REG,effect_mechanism=MECH)
  b=fence([comp(s) for s in ids[::-1]],REG,effect_mechanism=MECH)
  self.assertEqual({REG[uid].get("lineage_group",uid) for uid in a.unique_sources},{REG[uid].get("lineage_group",uid) for uid in b.unique_sources})
 def test_long_payload_disallowed(self):
  x=comp();x['url']='https://app.notion.com/p/'+RET+'?'+'a'*550
  self.assertFalse(fence([x],REG,effect_mechanism=MECH).eligible)
 def test_invalid_host_disallowed(self):
  for host in ['app.notion.com.evil.org','notion.com','app.notion.com:443','APP.NOTION.COM']:
   x=comp(url='https://'+host+'/p/'+RET)
   v=fence([x],REG,effect_mechanism=MECH)
   self.assertFalse(v.eligible,host)

class NativeRegressionTests(unittest.TestCase):
 def test_patch_only_accepted_uuid_tracking(self):
  before=(HERE/'src/source_fence_r50_original.py').read_text()
  after=(HERE/'src/source_fence.py').read_text()
  old="""        if uid in all_ids:\n            reasons.append('UUID_DUPLICATE_VARIANT_QUERY');continue\n        all_ids.append(uid)\n        src=registry.get(uid)"""
  new="""        src=registry.get(uid)"""
  self.assertEqual(before.count(old),1)
  self.assertIn(new,after)
  self.assertIn('# Only *accepted* evidence can reserve this UUID.',after)
 def test_native_four_identical(self):
  result=generate(HERE,HERE/'baseline_r26')
  raw=(json.dumps(result,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
  self.assertEqual(raw,(HERE/'outputs/r50_results.json').read_bytes())
  self.assertEqual(result['canonical_RE_finalized'],0)
  self.assertEqual(result['PA_authorized'],0)
 def test_native26_identical(self):
  result=probe26_run(HERE,HERE/'baseline_r26')
  raw=(json.dumps(result,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
  self.assertEqual(raw,(HERE/'outputs/r50_26_native_probe.json').read_bytes())
  self.assertEqual(result['native_rank_candidates'],11)
  self.assertEqual(result['n']-result['native_rank_candidates'],15)
 def test_r26_upstream_original_hash(self):
  h=hashlib.sha256((HERE/'baseline_r26/parecer_semicanonico_r26.py').read_bytes()).hexdigest()
  self.assertEqual(h,'7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8')

if __name__=='__main__':unittest.main()

from contract_r51 import derive
class CostEvidenceContractTests(unittest.TestCase):
 def test_two_real_receipts(self):
  d=derive();self.assertEqual(len(d['records']),2)
 def test_expected_botas_scenario(self):
  d=derive()['records'][0];self.assertEqual(d['case_id'],'botas')
  self.assertEqual(d['scenario_pa'],{'daily':25,'activation_sum':6,'sum':31})
 def test_expected_pingente_scenario(self):
  d=derive()['records'][1];self.assertEqual(d['case_id'],'pingente')
  self.assertEqual(d['scenario_pa'],{'daily':12,'activation_sum':14,'sum':26})
 def test_null_not_false_when_unobserved(self):
  for d in derive()['records']:
   self.assertIsNone(d['re_individual_authoritative'])
   self.assertIsNone(d['official_pa_authorization'])
   self.assertIsNone(d['real_pa_consumed'])
   self.assertEqual(d['effect_measured'],'UNVERIFIED')
 def test_two_distinct_receipt_hashes(self):
  d=derive()['records'];self.assertNotEqual(d[0]['source_sha256'],d[1]['source_sha256'])
 def test_rejects_external_write_claim(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td)
   for n in ['RECIBO_BOTAS_R39.json','RECIBO_PINGENTE_R39.json']:
    (td/n).write_bytes((HERE/'fixtures'/n).read_bytes())
   p=td/'RECIBO_BOTAS_R39.json';obj=json.loads(p.read_text());obj['notion_write']=True;p.write_text(json.dumps(obj))
   with self.assertRaisesRegex(ValueError,'UNTRUSTED_WRITE_OR_LEASE'):derive(td)
 def test_rejects_fake_production(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td)
   for n in ['RECIBO_BOTAS_R39.json','RECIBO_PINGENTE_R39.json']:
    (td/n).write_bytes((HERE/'fixtures'/n).read_bytes())
   p=td/'RECIBO_PINGENTE_R39.json';obj=json.loads(p.read_text());obj['gate_nac_prod']='PASS';p.write_text(json.dumps(obj))
   with self.assertRaisesRegex(ValueError,'PRODUCTION_GATE_NOT_HOLD'):derive(td)
 def test_rejects_invalid_arithmetic(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td)
   for n in ['RECIBO_BOTAS_R39.json','RECIBO_PINGENTE_R39.json']:
    (td/n).write_bytes((HERE/'fixtures'/n).read_bytes())
   p=td/'RECIBO_PINGENTE_R39.json';obj=json.loads(p.read_text());obj['pa_total_cenario']=100;p.write_text(json.dumps(obj))
   with self.assertRaisesRegex(ValueError,'INVALID_SCENARIO_ARITHMETIC'):derive(td)
 def test_rejects_false_e0(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td)
   for n in ['RECIBO_BOTAS_R39.json','RECIBO_PINGENTE_R39.json']:
    (td/n).write_bytes((HERE/'fixtures'/n).read_bytes())
   p=td/'RECIBO_BOTAS_R39.json';obj=json.loads(p.read_text());obj['estado_evidencia']='E0_VERIFICADO';p.write_text(json.dumps(obj))
   with self.assertRaisesRegex(ValueError,'EFFECT_RANK_EVIDENCE_UNKNOWN'):derive(td)
