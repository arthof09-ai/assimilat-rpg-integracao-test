# Assinatura científica — 14 técnicas restantes do Assimilação

**MESTRE-SIDE / TEST / sem gabarito, sem rank legado, sem parecer de outro Comestre.**

Este conjunto de 14 IDs é precisamente o complemento de 26 imagens totais menos os 12 IDs já avaliados em outro estudo independente. Não representa nova amostra aleatória nem conjunto balanceado por rank (os ranks permanecem desconhecidos aqui).

1. Verifique SHA de 14 imagens e complete o CSV mantendo ids e hashes intactos.
2. Leia as imagens sem pesquisar códigos nem páginas históricas das técnicas; os rodapés dos níveis do sistema de origem foram ocultados, mas o texto restante pode mencionar escalonamentos estrangeiros: NÃO usar esses níveis como RE do Assimilação.
3. Consulte Atlas A, DMG-RANK-01, Sistema de Magia e Combate; não leia os estudos PA R45/R46/R47/R48 nem oráculos legados ou correspondências de técnicas.
4. Procure comparadores de regra, personagem/besta e efeito/família; explicite semelhanças, diferenças e lacunas. Registre E0–E3 com origem do dado e se o referencial é RN do portador ou RE de efeito.
5. Quando dados forem insuficientes, INSUFICIENTE é resultado válido; custos PA não informados devem permanecer PENDENTES, nunca zero.
6. Não altere fichas originais ou regras. Se o Atlas trouxer rank explícito de uma técnica antes de congelar sua própria previsão, registre contaminação e segrege o caso; não disfarce como parecer cego.
7. Congele os 14 pareceres e seu SHA antes de qualquer confronto histórico; entregue ZIP/CSV/relatório Mestre-only.

**Atenção:** o Comestre que já produziu a R45 conhece vários destes casos; este kit destina-se a outro avaliador que ainda não estudou as classificações. Não expor Party ou O Primeiro.
