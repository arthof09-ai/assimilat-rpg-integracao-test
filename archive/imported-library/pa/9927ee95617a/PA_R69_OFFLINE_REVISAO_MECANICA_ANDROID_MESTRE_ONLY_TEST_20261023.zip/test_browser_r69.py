import json, pathlib, unittest, tempfile, hashlib, zipfile, io
from playwright.sync_api import sync_playwright
D=pathlib.Path(__file__).parent
HTML=D/'ASSIMILACAO_R69_REVISAO_OFFLINE_TEST.html'
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.pw.stop()
 def setUp(self):
  self.context=self.browser.new_context(viewport={'width':390,'height':844},accept_downloads=True);self.page=self.context.new_page();self.external=[];self.errors=[]
  self.page.on('request',lambda r:self.external.append(r.url) if not r.url.startswith('file:') else None)
  self.page.on('pageerror',lambda e:self.errors.append(str(e)))
  self.page.set_content(HTML.read_text(encoding='utf-8'),wait_until='load',timeout=30000)
 def tearDown(self): self.context.close()
 def test_01_card_count(self):
  self.assertEqual(self.page.locator('#cardTitle').inner_text(),'Técnica 01 / 14');self.assertEqual(self.page.locator('#caseImage').evaluate('(x)=>x.naturalWidth'),760)
  self.page.locator('#next').click();self.assertEqual(self.page.locator('#cardTitle').inner_text(),'Técnica 02 / 14')
  self.page.locator('#prev').click();self.assertEqual(self.page.locator('#cardTitle').inner_text(),'Técnica 01 / 14')
 def test_02_store_navigate(self):
  self.page.locator('#action').fill('Uma ação padrão');self.page.locator('#opinion').fill('Proposta preliminar');self.page.locator('#state').select_option('PROPOSTA_NAO_HOMOLOGADA');self.page.locator('#next').click();self.page.locator('#prev').click();self.assertEqual(self.page.locator('#action').input_value(),'Uma ação padrão');self.assertIn('1/14',self.page.locator('#progress').inner_text())
 def test_03_export_json(self):
  self.page.locator('#reviewer').fill('Revisor X');self.page.locator('#mechanic').fill('Prova em TEST');self.page.locator('#state').select_option('EM_ANALISE')
  with self.page.expect_download() as down:self.page.locator('#export').click()
  d=down.value;f=pathlib.Path(tempfile.mkdtemp())/d.suggested_filename;d.save_as(f);ob=json.loads(f.read_text())
  self.assertEqual(len(ob['items']),14);self.assertEqual(ob['items'][0]['mechanic'],'Prova em TEST');self.assertEqual(ob['reviewer_self_declared'],'Revisor X');self.assertFalse(ob['authority_approval']);self.assertIsNone(ob['pa_official']);self.assertEqual(ob['status'],'PARECER_AUTODECLARADO_NAO_HOMOLOGADO')
 def test_04_reimport_and_reject_wrong_hash(self):
  with self.page.expect_download() as down:self.page.locator('#saveDraft').click()
  d=down.value;f=pathlib.Path(tempfile.mkdtemp())/'draft.json';d.save_as(f)
  obj=json.loads(f.read_text());obj['items'][0]['action']='Importado sem rede';f.write_text(json.dumps(obj));self.page.locator('#file').set_input_files(str(f))
  self.assertEqual(self.page.locator('#action').input_value(),'Importado sem rede');obj['items'][0]['image_sha256']='0'*64;f.write_text(json.dumps(obj));self.page.locator('#file').set_input_files(str(f))
  self.assertIn('Importação recusada',self.page.locator('#feedback').inner_text());self.assertEqual(self.page.locator('#action').input_value(),'Importado sem rede')
 def test_05_tampered_duplicate_ids(self):
  with self.page.expect_download() as down:self.page.locator('#saveDraft').click()
  f=pathlib.Path(tempfile.mkdtemp())/'draft.json';down.value.save_as(f);obj=json.loads(f.read_text());obj['items'][1]=obj['items'][0];f.write_text(json.dumps(obj));self.page.locator('#file').set_input_files(str(f));self.assertIn('recusada',self.page.locator('#feedback').inner_text())
 def test_06_mobile_no_horizontal_scroll(self):
  self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),390);self.assertEqual(self.external,[]);self.assertEqual(self.errors,[])
 def test_07_all_cards(self):
  for i in range(14):
   self.assertEqual(self.page.locator('#caseImage').evaluate('(x)=>x.naturalWidth'),760)
   self.assertIn('/ 14',self.page.locator('#cardTitle').inner_text())
   if i!=13:self.page.locator('#next').click()
  self.assertTrue(self.page.locator('#next').is_disabled());self.assertEqual(self.external,[])
 def test_08_empty_export_no_faked_status(self):
  with self.page.expect_download() as down:self.page.locator('#export').click()
  f=pathlib.Path(tempfile.mkdtemp())/'draft.json';down.value.save_as(f);data=json.loads(f.read_text());self.assertEqual([x['state'] for x in data['items']],['NAO_INICIADO']*14)
 def test_09_file_reject_oversize(self):
  f=pathlib.Path(tempfile.mkdtemp())/'huge.json';f.write_text('x'*1500001);self.page.locator('#file').set_input_files(str(f));self.assertIn('recusada',self.page.locator('#feedback').inner_text())
 def test_11_zoom_for_android(self):
  self.page.locator('#zoomOpen').click();self.assertTrue(self.page.locator('#zoom').evaluate('(x)=>x.open'))
  self.assertEqual(self.page.locator('#zoomImage').evaluate('(x)=>x.naturalWidth'),760)
  self.page.locator('#zoomClose').click();self.assertFalse(self.page.locator('#zoom').evaluate('(x)=>x.open'))
 def test_12_file_picker_hidden_until_button(self):
  self.assertFalse(self.page.locator('#file').is_visible());self.assertTrue(self.page.locator('#importButton').is_visible())
 def test_10_security_no_external_links(self):
  self.assertEqual(self.page.locator('a').count(),0);self.assertEqual(self.page.locator('form').count(),0);self.assertEqual(self.external,[]);self.assertEqual(self.errors,[])
if __name__=='__main__':unittest.main(verbosity=2)
