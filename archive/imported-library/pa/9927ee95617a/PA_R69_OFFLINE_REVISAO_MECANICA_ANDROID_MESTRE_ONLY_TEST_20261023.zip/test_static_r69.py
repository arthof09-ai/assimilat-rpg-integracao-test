import unittest,re,json,hashlib,base64,zipfile,io,html.parser
from pathlib import Path
D=Path(__file__).resolve().parent
H=(D/'ASSIMILACAO_R69_REVISAO_OFFLINE_TEST.html').read_text(encoding='utf8')
M=json.loads((D/'R69_CASES_MASTER_ONLY.json').read_text())
class StaticQA(unittest.TestCase):
 def test_01_fourteen_images(self):self.assertEqual(H.count('data:image/png;base64,'),14)
 def test_02_exact_id_roster(self):
  for c in M['cases']:self.assertEqual(H.count(c['id']),1)
 def test_03_sha_embedded(self):
  payloads=re.findall(r'data:image/png;base64,([a-zA-Z0-9+/=]+)',H)
  hashes=[hashlib.sha256(base64.b64decode(t)).hexdigest() for t in payloads]
  self.assertEqual(hashes,[c['sha256'] for c in M['cases']])
 def test_04_r66_pin(self):self.assertIn(M['source_r66_sha256'],H)
 def test_05_r67_pin(self):self.assertIn(M['source_neutral_zip_sha256'],H)
 def test_06_offline_csp(self):self.assertIn("connect-src 'none'",H);self.assertIn("form-action 'none'",H)
 def test_07_no_external_url(self):self.assertNotIn('https://',H);self.assertNotIn('http://',H)
 def test_08_no_network_primitives(self):
  for pat in [r'\bfetch\s*\(',r'XMLHttpRequest',r'WebSocket',r'sendBeacon',r'<iframe',r'<form']:
   self.assertIsNone(re.search(pat,H,flags=re.I))
 def test_09_no_form_autosubmit(self):self.assertIn('reviewed_by_independent_party_verified:false',H);self.assertIn('authority_approval:false',H)
 def test_10_mobile(self):self.assertIn('@media(max-width:740px)',H)
 def test_11_accessible_alt(self):self.assertIn('alt="Cartão de mecânica',H)
 def test_12_safety_labels(self):self.assertIn('NÃO ENVIADO',H);self.assertIn('não homologado',H.lower())
 def test_13_export_limits(self):self.assertIn('f.size>1500000',H)
 def test_14_css_js_single_file(self):self.assertEqual(H.count('<script>'),1);self.assertEqual(H.count('<style>'),1)
 def test_15_no_peers_faked(self):self.assertEqual(M['independent_reviewers'],0);self.assertEqual(M['e0_homologations'],0)
if __name__=='__main__':unittest.main(verbosity=2)
