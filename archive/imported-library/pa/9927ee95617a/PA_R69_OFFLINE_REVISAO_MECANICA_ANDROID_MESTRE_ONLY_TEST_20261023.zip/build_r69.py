from pathlib import Path
import zipfile,io,json,base64,hashlib,html,re
ROOT=Path('/mnt/data/pa_sucessao'); DEST=ROOT/'r69_offline'
R66=ROOT/'PA_R66_CARTOES_MECANICOS_NEUTROS_MESTRE_ONLY_TEST_20261022.zip'
R67=ROOT/'PA_R67_PEER_NEUTRAL_VERSION_SEAL_MESTRE_ONLY_TEST_20261022.zip'
SHA66='ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9'
SHA67INNER='626ffaf777ea12caa8c3dab492042154f3324142c5b430dad8aded48797f38bb'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(R66.read_bytes())==SHA66
with zipfile.ZipFile(R66) as z:
    peerbytes=z.read('PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip')
assert sha(peerbytes)==SHA67INNER
with zipfile.ZipFile(io.BytesIO(peerbytes)) as z:
    assert z.testzip() is None
    info=json.loads(z.read('REVISOR14.json'))
    cases=[]
    for x in info['records']:
        b=z.read(x['image_path']);assert sha(b)==x['image_sha256']
        cases.append({'id':x['case_id'],'data':'data:image/png;base64,'+base64.b64encode(b).decode(),'sha256':sha(b)})
assert len(cases)==14
casejs=json.dumps(cases,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
page=r'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; form-action 'none'; object-src 'none'; base-uri 'none'"/>
<title>Assimilação — leitura mecânica offline TEST R69</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Roboto,sans-serif;background:#101821;color:#edf4f7}
*{box-sizing:border-box} [hidden]{display:none!important} body{margin:0} main{max-width:1120px;margin:auto;padding:14px} header{padding:18px 0} h1{font-size:1.38rem;margin:.3em 0} h2{font-size:1.05rem}
p{line-height:1.5} .note{border-left:4px solid #e9b750;padding:12px;background:#25271d;color:#ffe6ab}.tiny{font-size:.83rem;color:#c4d4df}
.workspace{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(280px,.9fr);gap:16px;margin-top:14px}
.card{border:1px solid #395263;border-radius:12px;padding:14px;background:#1a2731;min-width:0}
.card img{display:block;width:100%;height:auto;max-width:700px;margin:auto;border-radius:5px;background:white} dialog{background:#172530;color:#eaf4fa;border:2px solid #6387a0;border-radius:9px;max-width:98vw;max-height:92vh;padding:10px}dialog::backdrop{background:#030912dc} .zoomscroll{overflow:auto;max-height:80vh;max-width:94vw} #zoomImage{width:760px;max-width:none;height:910px}
label{display:block;margin:12px 0;font-weight:600;font-size:.95rem} textarea,input,select{display:block;width:100%;padding:11px;margin-top:5px;background:#101821;color:white;border:1px solid #698298;border-radius:8px;font:inherit}
textarea{min-height:74px;resize:vertical} button{background:#254d69;border:1px solid #7493aa;border-radius:9px;color:white;padding:12px 14px;font-weight:600;cursor:pointer;margin:4px 4px 4px 0}
button:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{outline:3px solid #f5c65c}
button:hover{background:#376789} .actions{display:flex;flex-wrap:wrap;gap:5px}.counter{font-weight:700;color:#b7e0ff}
footer{padding:20px 0;color:#b5cbd7;font-size:.87rem} .split{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap} .split>div{min-width:0;flex:1 1 250px} footer,.tiny{overflow-wrap:anywhere}
@media(max-width:740px){.workspace{grid-template-columns:1fr}main{padding:11px}.card{padding:10px}}
</style></head><body><main>
<header><div class="tiny">MESTRE-SIDE · TEST R69 · ARQUIVO LOCAL / OFFLINE · NÃO ENVIADO</div><h1>Leitura mecânica independente — 14 cartões neutros</h1>
<p class="note"><strong>Sem decisão automática.</strong> Este arquivo NÃO atribui classificação oficial, PA, parecer aceito ou autenticação. As imagens podem conservar pistas semânticas. Não enviar à Party ou a O Primeiro. Uso por avaliador externo depende de autorização prévia do Mestre.</p></header>
<div class="card split"><div><strong>Identificação do avaliador (autodeclarada, não verificada)</strong><input id="reviewer" autocomplete="off" maxlength="120" placeholder="Apelido/código do revisor, opcional"></div><div><strong>Avanço de campos preenchidos</strong><p class="counter" id="progress" aria-live="polite">0/14</p></div></div>
<div class="workspace"><section class="card"><div class="split"><h2 id="cardTitle">Técnica 01 / 14</h2><span id="caseId" class="tiny"></span></div><img id="caseImage" alt="Cartão de mecânica apresentado sem título original"/><div class="actions"><button id="prev">← Anterior</button><button id="next">Próxima →</button><button id="zoomOpen">Ampliar cartão</button></div></section>
<section class="card"><h2>Registro de evidências — não é homologação</h2><label>1. Ação, duração, alcance e componentes<textarea id="action" maxlength="4000" placeholder="Transcreva o que a imagem demonstra"></textarea></label>
<label>2. Mecânica e subefeitos<textarea id="mechanic" maxlength="8000" placeholder="Separe efeitos e condições; não invente valores"></textarea></label>
<label>3. Limites, contraindicações e dúvidas<textarea id="limits" maxlength="6000" placeholder="O que não está demonstrado?"></textarea></label>
<label>4. Comparadores independentes ou ausência justificada<textarea id="comparators" maxlength="6000" placeholder="Cite fontes quando houver"></textarea></label>
<label>5. Parecer técnico ou abstenção<textarea id="opinion" maxlength="5000" placeholder="Hipótese fundamentada (não vinculante)"></textarea></label>
<label>Estado declarado<select id="state"><option value="NAO_INICIADO">Não iniciado</option><option value="EM_ANALISE">Em análise</option><option value="ABSTENCAO">Abstenção por evidência insuficiente</option><option value="PROPOSTA_NAO_HOMOLOGADA">Proposta não homologada</option></select></label>
<div class="actions"><button id="saveDraft">Salvar rascunho JSON</button><button id="export">Exportar parecer JSON (não homologado)</button><button id="importButton">Importar rascunho JSON</button><input type="file" id="file" accept=".json,application/json" hidden /></div><p id="feedback" role="status" aria-live="polite" class="tiny">Sem envio de dados.</p>
</section></div><dialog id="zoom"><div class="actions"><button id="zoomClose">Fechar ampliação</button></div><div class="zoomscroll"><img id="zoomImage" alt="Versão ampliada do cartão neutro"/></div></dialog><footer>R66 interno SHA-256: __R66SHA__ · 14 imagens fixadas por SHA-256. Nenhuma requisição de rede, servidor, API ou salvamento automático. Exportação é arquivo local no navegador; conservar uma cópia por conta própria.</footer>
</main><script>
'use strict'; const CASES=__CASE_DATA__; const fields=['action','mechanic','limits','comparators','opinion','state'];
const by=id=>document.getElementById(id);let index=0;let data=Object.create(null);
for(const c of CASES)data[c.id]={action:'',mechanic:'',limits:'',comparators:'',opinion:'',state:'NAO_INICIADO'};
function stash(){let obj=data[CASES[index].id];for(const f of fields)obj[f]=by(f).value;}
function completed(o){return o.state!=='NAO_INICIADO' && (!!o.opinion.trim() || o.state==='ABSTENCAO');}
function progress(){by('progress').textContent=CASES.filter(c=>completed(data[c.id])).length+'/14 com parecer ou abstenção (autodeclarados)';}
function display(i,saveCurrent=true){if(saveCurrent)stash();index=Math.max(0,Math.min(CASES.length-1,i));const c=CASES[index],o=data[c.id];by('caseImage').src=c.data;by('cardTitle').textContent='Técnica '+String(index+1).padStart(2,'0')+' / 14';by('caseId').textContent=c.id;
 for(const f of fields)by(f).value=o[f];by('prev').disabled=index===0;by('next').disabled=index===CASES.length-1;progress();}
function output(kind){stash();const items=CASES.map(c=>({case_id:c.id,image_sha256:c.sha256,...data[c.id]}));return {schema:'ASSIMILACAO_R69_REVIEW_LOCAL_V1',status:kind==='draft'?'RASCUNHO_LOCAL_NAO_VERIFICADO':'PARECER_AUTODECLARADO_NAO_HOMOLOGADO',reviewer_self_declared:by('reviewer').value.trim(),source_package_sha256:'__R66SHA__',source_review_zip_sha256:'__R67INNER__',reviewed_by_independent_party_verified:false,authority_approval:false,pa_official:null,items};}
function fileSave(name,content){let blob=new Blob([content],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)}
by('zoomOpen').addEventListener('click',()=>{by('zoomImage').src=CASES[index].data;by('zoom').showModal()});by('zoomClose').addEventListener('click',()=>by('zoom').close());
by('prev').addEventListener('click',()=>display(index-1));by('next').addEventListener('click',()=>display(index+1));
for(const f of fields)by(f).addEventListener('change',()=>{stash();progress()});
by('saveDraft').addEventListener('click',()=>{fileSave('ASSIMILACAO_R69_RASCUNHO_TEST.json',JSON.stringify(output('draft'),null,2));by('feedback').textContent='Rascunho local exportado. Não homologado.'});
by('export').addEventListener('click',()=>{fileSave('ASSIMILACAO_R69_PARECER_NAO_HOMOLOGADO.json',JSON.stringify(output('review'),null,2));by('feedback').textContent='Arquivo local exportado; qualquer parecer precisa de validação independente.'});
by('importButton').addEventListener('click',()=>by('file').click());
by('file').addEventListener('change',async()=>{const f=by('file').files[0];if(!f)return;try{if(f.size>1500000)throw Error('ARQUIVO_GRANDE');const obj=JSON.parse(await f.text());
 if(obj.schema!=='ASSIMILACAO_R69_REVIEW_LOCAL_V1'||obj.source_review_zip_sha256!=='__R67INNER__'||!Array.isArray(obj.items)||obj.items.length!==CASES.length)throw Error('FORMATO_OU_FONTE_INVALIDA');
 const copy=Object.create(null),seen=new Set();for(const it of obj.items){if(!it||!CASES.some(c=>c.id===it.case_id&&c.sha256===it.image_sha256)||seen.has(it.case_id))throw Error('ID_OU_HASH_INVALIDO');seen.add(it.case_id);
 const entry=Object.create(null);for(const key of fields){if(typeof it[key]!=='string'||it[key].length>(key==='mechanic'?8000:key==='limits'||key==='comparators'?6000:key==='opinion'?5000:key==='action'?4000:35))throw Error('CAMPO_INVALIDO');entry[key]=it[key]}
 if(!['NAO_INICIADO','EM_ANALISE','ABSTENCAO','PROPOSTA_NAO_HOMOLOGADA'].includes(entry.state))throw Error('ESTADO_INVALIDO');copy[it.case_id]=entry;}
 if(typeof obj.reviewer_self_declared!=='string'||obj.reviewer_self_declared.length>120)throw Error('REVISOR_INVALIDO');data=copy;by('reviewer').value=obj.reviewer_self_declared;display(index,false);by('feedback').textContent='Rascunho local importado (não verificado).';
 }catch(e){by('feedback').textContent='Importação recusada: '+e.message}finally{by('file').value=''}});
for(const f of fields)by(f).value=data[CASES[0].id][f];display(0);
</script></body></html>'''
page=page.replace('__CASE_DATA__',casejs).replace('__R66SHA__',SHA66).replace('__R67INNER__',SHA67INNER)
assert 'https://' not in page and 'http://' not in page
(DEST/'ASSIMILACAO_R69_REVISAO_OFFLINE_TEST.html').write_text(page,encoding='utf-8')
(DEST/'R69_CASES_MASTER_ONLY.json').write_text(json.dumps({'source_r66_sha256':SHA66,'source_neutral_zip_sha256':SHA67INNER,'case_count':14,'cases':[{'id':c['id'],'sha256':c['sha256']} for c in cases],'form_status':'NOT_SENT','independent_reviewers':0,'e0_homologations':0},ensure_ascii=False,indent=2))
print('HTML bytes',len(page.encode()),'cases',len(cases),'hash',sha(page.encode()))
