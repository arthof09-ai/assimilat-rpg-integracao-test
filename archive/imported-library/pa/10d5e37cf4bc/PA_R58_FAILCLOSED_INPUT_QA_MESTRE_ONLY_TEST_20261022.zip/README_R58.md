# PA R58 — Hotfix de entrada / QA CRAFT TEST (somente Mestre)

**Defeito real reproduzido:** QA R54/R56 aceita objetos JSON malformados e exceções escapavam em vez de retorno HOLD: aliases=null, rank/lista, registry=null, passos consumes=null, categoria/lista. Este defeito é da **camada TEST de QA**, não do motor oficial R26.

O wrapper `src/hardened_route_r58.py` tipa as fronteiras e responde `HOLD_INPUT_SCHEMA_R58` com motivo e sem write. Retorna a função R54/R56 original **inalterada** para entrada estruturada válida, preservando políticas e NO-WRITE. Não normaliza mecanicamente dados ausentes e não transforma falha em êxito.

Executar `python -m unittest discover -s tests -p test_r58.py -v` na extração. Pode reproduzir sem qualquer conexão, dados Party ou produção.

**Limites:** não homologou E0, não criou item/recurso, não corrigiu o engine oficial, não substituiu validação de autoridade nem provou instalação mágica. PA official=null, F5 RED/RC5 HOLD.
