import copy,unittest
from src.hardened_route_r58 import run_resource,run_item,run_module,run_substitution
from src.item_resource_qc_r54 import audit_item,audit_resource
from src.module_contract_r56 import audit_module,audit_substitution
reg={'cristal':{'id':'crystal-1','name':'Cristal'}}
class ContractBoundary(unittest.TestCase):
 def test_resource_bad_aliases(self):
  for bad in (None,123,{},'x',['x',34],[{}]):
   with self.subTest(bad=bad):self.assertEqual(run_resource({'name':'Novo','aliases':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_resource_bad_registry(self):
  for bad in (None,[],4,{'x':{}},{'x':'y'},{'x':{'id':[],'name':'A'}},{1:{'id':'x','name':'a'}}):
   with self.subTest(bad=bad):self.assertEqual(run_resource({'name':'Novo'},bad)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_resource_bad_rank(self):
  for bad in ([],{},1,[1]):
   with self.subTest(bad=bad):self.assertEqual(run_resource({'name':'Novo','RIn':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_resource_search_checked(self):
  for bad in (None,12,'itens',[1]):
   with self.subTest(bad=bad):self.assertEqual(run_resource({'name':'Novo','search_checked':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_rank(self):
  for bad in ([],{},1,[2]):
   with self.subTest(bad=bad):self.assertEqual(run_item({'name':'Item','RI':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_category(self):
  for bad in ([],{},1):self.assertEqual(run_item({'name':'Item','category':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_approval_claim(self):
  for bad in ([],{},1):self.assertEqual(run_item({'name':'Item','approval_claim':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_sections(self):
  for bad in (None,4,'identidade',[4]):self.assertEqual(run_item({'name':'Item','sections_reviewed':bad},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_effect_rank(self):
  for bad in ([],{},12):self.assertEqual(run_item({'name':'Item','effects':[{'RE':bad}]},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_bom(self):
  for bad in ([],{},12):self.assertEqual(run_item({'name':'Item','bom':[{'id':bad}]},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_process_list(self):
  for bad in (None,12,'x',[{}]):self.assertEqual(run_item({'name':'Item','process':[{'action':'x','consumes':bad}]},reg)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_item_bad_registry(self):
  for bad in (None,4,{'x':{}}):self.assertEqual(run_item({'name':'Item'},bad)['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_module_bad_category(self):
  for bad in (None,{},[]):self.assertEqual(run_module(bad,{})['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_module_steps(self):
  for bad in (None,4,'etapas',[{}]):self.assertEqual(run_module('arma',{'steps':bad})['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_substitution_grade(self):
  for bad in ([],{},5):
   x=run_substitution({'source_id':'x'},{'source_id':'y'},{'substitution_grade':bad})
   self.assertEqual(x['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_substitution_bad_sources(self):
  for bad in (None,[],4):
   x=run_substitution({'source_id':bad},{'source_id':'y'},{'substitution_grade':'S0'})
   self.assertEqual(x['status'],'HOLD_INPUT_SCHEMA_R58')
 def test_valid_original_resource_parity(self):
  spec={'name':'Cristal'}
  self.assertEqual(run_resource(spec,reg),audit_resource(spec,reg))
 def test_valid_original_item_parity(self):
  spec={'name':'Talismã','RI':'Bronze','category':'acessorio'}
  self.assertEqual(run_item(spec,reg),audit_item(spec,reg))
 def test_valid_module_parity(self):
  self.assertEqual(run_module('arma',{'steps':[]}),audit_module('arma',{'steps':[]}))
 def test_valid_substitution_parity(self):
  a={'source_id':'x','role':'ligante','maturity':'P4'};b={'source_id':'y','role':'ligante','maturity':'P4'};c={'substitution_grade':'S1','compatibility_test':True}
  self.assertEqual(run_substitution(a,b,c),audit_substitution(a,b,c))
 def test_unknown_nonpromoting(self):
  for x in (run_resource({'name':'X','RIn':[]},reg),run_item({'name':'X','category':[]},reg),run_module([],{})):
   self.assertFalse(x['party_write']);self.assertFalse(x['notion_write']);self.assertIsNone(x['official_pa']);self.assertEqual(x['production_gate'],'HOLD')
if __name__=='__main__': unittest.main()
