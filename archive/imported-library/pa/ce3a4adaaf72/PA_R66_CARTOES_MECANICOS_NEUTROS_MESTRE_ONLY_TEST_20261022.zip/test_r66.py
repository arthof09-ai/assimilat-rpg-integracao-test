from __future__ import annotations
import csv,hashlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from PIL import Image
from validate_r66 import check
from build_r66 import OUT,R60,sha

class R66SecurityTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.tempdir=Path(cls.tmp.name)
  with zipfile.ZipFile(OUT) as z:
   cls.baseline={x.filename:z.read(x.filename) for x in z.infolist()}
  cls.json_name='REVISOR14.json';cls.image=sorted(x for x in cls.baseline if x.endswith('.png'))[0]
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def pack(self,changes=None,comment=b'',extra_name=None,metadata=False,duplicate=False):
  changed=dict(self.baseline);changed.update(changes or {})
  if extra_name:changed[extra_name]=b'RANK HISTORICO'
  p=self.tempdir/(self.id().split('.')[-1]+'.zip')
  with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED) as z:
   z.comment=comment
   for name,data in changed.items():
    info=zipfile.ZipInfo(name,date_time=(2026,10,22,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
    if metadata and name==self.image:info.comment=b'oracle'
    z.writestr(info,data)
   if duplicate:z.writestr(self.image,changed[self.image])
  return p
 def assertHold(self,**kwargs):self.assertEqual(check(**kwargs)['status'],'HOLD_R66_INTEGRITY_OR_BLINDNESS')
 def mutate(self,func):
  j=json.loads(self.baseline[self.json_name]);func(j);return self.pack({self.json_name:json.dumps(j).encode()})
 def test_01_good(self):
  r=check();self.assertEqual(r['status'],'PASS_R66_NEUTRAL_VIEWS_PREPARED_NOT_SENT')
  self.assertFalse(r['send_authorized']);self.assertEqual(r['independent_peer_answers'],0);self.assertEqual(r['e0_homologated'],0)
 def test_02_zip_comment(self):self.assertHold(peer_path=self.pack(comment=b'CLASSIFICACAO HISTORICA'))
 def test_03_extra_member(self):self.assertHold(peer_path=self.pack(extra_name='MASTER_ORACLE.csv'))
 def test_04_member_comment(self):self.assertHold(peer_path=self.pack(metadata=True))
 def test_05_duplicate_member(self):self.assertHold(peer_path=self.pack(duplicate=True))
 def test_06_missing_card(self):self.assertHold(peer_path=self.pack({self.image:b''}))
 def test_07_replace_original_pretend_sha(self):
  with zipfile.ZipFile(R60) as z:orig=z.read('IMAGENS_SEM_GABARITO/'+self.image.split('/')[-1].replace('.png','.jpg'))
  j=json.loads(self.baseline[self.json_name]);j['records'][0]['image_sha256']=sha(orig)
  self.assertHold(peer_path=self.pack({self.image:orig,self.json_name:json.dumps(j).encode()}))
 def test_08_change_pixel_pretend_sha(self):
  img=Image.open(io.BytesIO(self.baseline[self.image])).copy();img.putpixel((75,425),(1,2,3))
  b=io.BytesIO();img.save(b,format='PNG');new=b.getvalue()
  j=json.loads(self.baseline[self.json_name]);j['records'][0]['image_sha256']=sha(new)
  self.assertHold(peer_path=self.pack({self.image:new,self.json_name:json.dumps(j).encode()}))
 def test_09_wrong_claimed_image_hash(self):self.assertHold(peer_path=self.mutate(lambda j:j['records'][0].update(image_sha256='0'*64)))
 def test_10_grade_leak_in_readme(self):self.assertHold(peer_path=self.pack({'LEIA_ANTES.md':self.baseline['LEIA_ANTES.md']+b'\nPrata\n'}))
 def test_11_grade_leak_in_json(self):self.assertHold(peer_path=self.mutate(lambda j:j['records'][0].update(extra='Bronze')))
 def test_12_rank_guess_in_record(self):self.assertHold(peer_path=self.mutate(lambda j:j['records'][0].update(verdict='Ouro')))
 def test_13_fake_reviewer(self):self.assertHold(peer_path=self.mutate(lambda j:j['records'][0].update(reviewer_submission={'signature':'forged'})))
 def test_14_fake_adjudication(self):self.assertHold(peer_path=self.mutate(lambda j:j.update(e0_adjudicated=14)))
 def test_15_fake_sent(self):self.assertHold(peer_path=self.mutate(lambda j:j.update(status='SENT_AND_ACCEPTED')))
 def test_16_case_id_changed(self):self.assertHold(peer_path=self.mutate(lambda j:j['records'][0].update(case_id='TEC-FAKE')))
 def test_17_bad_source_mapping(self):self.assertHold(peer_path=self.mutate(lambda j:j['records'][0].update(image_path='IMAGENS_SEM_GABARITO/EXPOSE.jpg')))
 def test_18_csv_response_prepopulated(self):
  s=self.baseline['RESPOSTAS_14.csv'].decode().splitlines();s[1]=s[1]+'PRATA'
  self.assertHold(peer_path=self.pack({'RESPOSTAS_14.csv':'\n'.join(s).encode()}))
 def test_19_csv_duplicate(self):
  s=self.baseline['RESPOSTAS_14.csv'].decode().splitlines();s[2]=s[1]
  self.assertHold(peer_path=self.pack({'RESPOSTAS_14.csv':'\n'.join(s).encode()}))
 def test_20_no_r60_anchor(self):
  wrong=self.tempdir/'wrong-source.zip';wrong.write_bytes(b'fake source')
  self.assertHold(original_path=wrong)
 def test_21_source_sha_stays(self):self.assertEqual(sha(R60.read_bytes()),'6118f4d2ba1843f2796ea92fa371029d247d4c795cf059786afbe862d86964ca')
 def test_22_bytes_repeatable(self):
  r=check();self.assertEqual(r['masked_and_neutral_cards'],14)
 def test_23_no_name_image_titles_as_patches(self):
  from build_r66 import PATCHES
  self.assertEqual(len(PATCHES),4)
  self.assertTrue(all(not (b>180 and t<400) for l,t,r,b,x,y in PATCHES))
 def test_24_no_party_write(self):self.assertIs(check()['party_write'],False)
 def test_25_no_official_pa(self):self.assertIsNone(check()['PA_official'])

if __name__=='__main__':unittest.main(verbosity=2)
