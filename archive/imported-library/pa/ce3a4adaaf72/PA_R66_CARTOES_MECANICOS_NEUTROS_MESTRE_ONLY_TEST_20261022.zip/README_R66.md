# PA R66 — Revisão de 14 efeitos em cartões neutros (MESTRE-SIDE TEST)

**Estado:** pacote físico TEST para leitura no Android. **Não enviado a avaliador**, **0/14 respostas**, **0 homologações E0**, **PA oficial PENDENTE**, CRAFT/F5 HOLD. Arquivos externos desta pasta contêm os JPG R60 anteriores, que revelam os nomes; **o ZIP externo nunca deve ser enviado à Party, O Primeiro ou ao revisor independente**.

## O que mudou

R60/R65 tinham nomes dos efeitos impressos nas imagens, apesar de seu formulário não incluir os ranks. Em R66, cada um dos 14 cartões PNG recebeu apresentação visual neutra: ações, duração, alcance/componentes e corpo mecânico foram copiados dos pixels do JPG original para campo neutro; a faixa visual que continha o título e escola ficou de fora. O texto do corpo pode mencionar o tema ou nome indiretamente. Portanto, **sem rótulo visual ≠ cegamento integral**. Nenhum texto ou efeito foi traduzido, inventado, reclassificado ou recalculado.

## Reproduzir/auditar

Da pasta extraída: `python build_r66.py` e `python -m unittest test_r66 -q`; exige Python 3 + Pillow e uma fonte DejaVu Sans instalada no host para a composição gráfica. O pacote de leitura produzido é `PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip`; abrir JPG/PNG e CSV em celular Android não exige executar Python. Nunca compartilhar os códigos/fontes do ZIP Mestre com Party/O Primeiro.

Proveniência: SHA256 R60 ZIP cego fonte `6118f4d2ba1843f2796ea92fa371029d247d4c795cf059786afbe862d86964ca` fixado no código; não é a autoridade canônica de rank, apenas identidade da fonte experimental recuperada. Um verificador R66 reconstitui hashes esperados dos cartões a partir da fonte fixada e rejeita imagens trocadas mesmo que a pessoa altere simultaneamente o hash escrito no formulário. Também rejeita vazamentos textuais, respostas falsificadas, ZIPs com comentários, arquivos extras, contagens erradas e fontes diferentes.

## Limites

O material nasceu de imagens de técnicas históricas importadas; sua mecânica textual ainda depende de validação do Atlas e do sistema de Assimilação. O revisor independente ainda precisa estar autorizado e não deve conhecer o gabarito. Sem sua assinatura/parecer e sem ato de autoridade do Mestre, nenhuma classificação de RE de subefeito, custo PA real, receita/RC5, insumo P4 ou item são promovidos. Conteúdo não é certificação de privacidade/anonimato total, pois características semânticas podem identificar a técnica.

**Ponto de retomada:** avaliação humana competente dos 14 cartões ainda 0/14, quatro casos R57 sem E0, E353 R61 com `1 AÇÃO`; gate de produção CRAFT HOLD; registro R64–R66 em Notion pendente devido a bloqueio de segurança anterior. Não forçar uma escrita no Notion por nova via se o bloqueio persistir.
