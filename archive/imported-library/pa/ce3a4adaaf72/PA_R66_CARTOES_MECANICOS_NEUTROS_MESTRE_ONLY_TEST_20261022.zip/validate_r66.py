"""Strict negative gate for R66 reviewer-safe preparation. Never validates rank or grants send authorization."""
from __future__ import annotations
import csv,hashlib,io,json,unicodedata,zipfile
from functools import lru_cache
from pathlib import Path
from PIL import Image
from build_r66 import R60,R60_SHA,OUT,sha,render,ORIG_IMAGE_DIR,NEUTRAL_DIR

BASE = Path(__file__).resolve().parent
TEXT_FILES = {'REVISOR14.json','RESPOSTAS_14.csv','LEIA_ANTES.md'}

def deny(reason):
    return {'status':'HOLD_R66_INTEGRITY_OR_BLINDNESS','reason':reason,
      'send_authorized':False,'independent_peer_answers':0,'e0_homologated':0,
      'PA_official':None,'production':'HOLD','party_write':False,'notion_write':False}

def normalize(s):
    return ''.join(x for x in unicodedata.normalize('NFKD',s) if not unicodedata.combining(x)).casefold()

@lru_cache(maxsize=1)
def pinned_expected_neutral_hashes():
    """Compute verified deterministic image hashes once from the immutable R60 SHA-pinned bytes."""
    if sha(R60.read_bytes())!=R60_SHA:raise ValueError("SOURCE_SHA_CHANGED")
    with zipfile.ZipFile(R60) as z:
        records=json.loads(z.read("PEER14_BLIND_ASSIGNMENT.json"))["records"]
        return {r["case_id"]:sha(render(z.read(ORIG_IMAGE_DIR+r["case_id"]+".jpg"),r["case_id"])) for r in records}

def check(peer_path=OUT,original_path=R60):
    try:
        if sha(Path(original_path).read_bytes())!=R60_SHA: return deny('PINNED_R60_SOURCE_CHANGED')
        with zipfile.ZipFile(original_path) as source,zipfile.ZipFile(peer_path) as peer:
            if peer.comment:return deny('ZIP_COMMENT')
            infos=peer.infolist();paths=[x.filename for x in infos]
            if len(paths)!=len(set(paths)):return deny('DUPLICATE_NAME')
            if any(x.comment or x.extra or x.flag_bits&1 for x in infos):return deny('UNSAFE_ZIP_MEMBER_METADATA')
            if any(x.filename.startswith('/') or '..' in x.filename or '\\' in x.filename for x in infos):return deny('UNSAFE_ZIP_PATH')
            if len(paths)!=17:return deny('EXPECTED_14_IMAGES_3_TEXT')
            if any(x.file_size>10_000_000 for x in infos) or sum(x.file_size for x in infos)>25_000_000:return deny('ZIP_SIZE_LIMIT')
            if peer.testzip() is not None:return deny('ZIP_CRC_FAILED')
            old = json.loads(source.read('PEER14_BLIND_ASSIGNMENT.json'))['records']
            old_ids=[x['case_id'] for x in old]
            if len(old_ids)!=14 or len(set(old_ids))!=14:return deny('INVALID_R60_ROSTER')
            allowed=TEXT_FILES|{NEUTRAL_DIR+x+'.png' for x in old_ids}
            if set(paths)!=allowed:return deny('UNEXPECTED_MEMBERS')
            data=json.loads(peer.read('REVISOR14.json'))
            if set(data.keys()) != {'status','reviewed','e0_adjudicated','records'}:return deny('REVIEW_JSON_SCHEMA')
            if data['status']!='NEUTRAL_MECHANICS_REVIEW_PREPARED_NOT_SENT' or data['reviewed']!=0 or data['e0_adjudicated']!=0 or isinstance(data['reviewed'],bool):return deny('REVIEW_STATUS_FORGED')
            rows=data['records'];rids=[x['case_id'] for x in rows]
            if len(rows)!=14 or rids != old_ids:return deny('REVIEW_ROSTER_MISMATCH')
            for r,oldr in zip(rows,old):
                cid=oldr['case_id']; path=NEUTRAL_DIR+cid+'.png'
                if set(r.keys())!={'case_id','image_path','image_sha256','mechanism_questions','reviewer_submission','verdict'}:return deny('RECORD_SCHEMA')
                if r['reviewer_submission'] is not None or r['verdict'] is not None:return deny('FORGED_REVIEW')
                if r['image_path']!=path or r['mechanism_questions']!=oldr['mechanism_questions']:return deny('FIELDS_MISMATCH')
                data_image=peer.read(path)
                with Image.open(io.BytesIO(data_image)) as test_image:
                    if test_image.size!=(760,910) or test_image.mode!='RGB' or test_image.format!='PNG':return deny('NEUTRAL_IMAGE_FORMAT')
                    if test_image.getexif() or any(k in test_image.info for k in ('comment','description','Author')):return deny('HIDDEN_IMAGE_METADATA')
                if r['image_sha256']!=sha(data_image):return deny('CLAIMED_IMAGE_SHA_WRONG')
                masked=source.read(ORIG_IMAGE_DIR+cid+'.jpg')
                if sha(masked)!=oldr['image_sha256']:return deny('MASKED_SOURCE_CHANGED')
                if sha(data_image)!=pinned_expected_neutral_hashes()[cid]:return deny('IMAGE_NOT_DETERMINISTIC_NEUTRAL_CROP')
            text_chunks=[peer.read(n).decode('utf-8') for n in TEXT_FILES]
            text='\n'.join(text_chunks)
            bad=('bronze','prata','ouro','lendario','gabarito','historical_nominal_technique_rank','notion_page_id','notion_page_url','rank_proposal')
            if any(k in normalize(text) for k in bad):return deny('GRADE_OR_SOURCE_ORACLE_TEXT')
            form=list(csv.reader(io.StringIO(peer.read('RESPOSTAS_14.csv').decode('utf-8'))))
            if len(form)!=15 or [r[0] for r in form[1:]] != old_ids:return deny('RESPONSE_COUNT_OR_ID')
            if any(len(row)!=7 or any(v.strip() for v in row[1:]) for row in form[1:]):return deny('ANSWERS_PREPOPULATED')
            return {'status':'PASS_R66_NEUTRAL_VIEWS_PREPARED_NOT_SENT','masked_and_neutral_cards':14,
              'visual_titles_excluded_by_cropping':True,'semantic_identity_remains_possible':True,
              'send_authorized':False,'independent_peer_answers':0,'e0_homologated':0,
              'PA_official':None,'production':'HOLD','party_write':False,'notion_write':False}
    except (KeyError,IndexError,TypeError,ValueError,UnicodeError,zipfile.BadZipFile,OSError,RuntimeError,ImportError) as e:
        return deny('INVALID_INPUT:'+type(e).__name__)
if __name__=='__main__':print(json.dumps(check(),ensure_ascii=False))
