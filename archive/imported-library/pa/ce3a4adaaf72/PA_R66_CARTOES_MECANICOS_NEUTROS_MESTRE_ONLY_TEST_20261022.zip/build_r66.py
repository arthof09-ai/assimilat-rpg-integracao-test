"""R66 neutral read-only views derived from pinned R60. No ranking, review, or authority writes."""
from __future__ import annotations
import csv, hashlib, io, json, os, shutil, zipfile, unicodedata
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw, ImageFont

R60_SHA = '6118f4d2ba1843f2796ea92fa371029d247d4c795cf059786afbe862d86964ca'
PATH = Path(__file__).resolve().parent
R60 = PATH / 'PA_R60_SOURCE_PINNED_MASTER_ONLY.zip'
OUT = PATH / 'PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip'
REPORT = PATH / 'R66_QA_REPORT_MESTRE_ONLY.json'
ORIG_IMAGE_DIR = 'IMAGENS_SEM_GABARITO/'
NEUTRAL_DIR='MECANICA_NEUTRA/'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
PATCHES=((45,25,300,102,45,92),(412,25,668,102,455,92),
         (125,407,643,505,113,207),(77,480,652,935,70,367))
GRADES=('bronze','prata','ouro','lendario','gabarito','historical_nominal_technique_rank')

def sha(data): return hashlib.sha256(data).hexdigest()
def norm(s): return ''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.combining(c)).casefold()

def render(imgbytes,case_id):
    img=Image.open(io.BytesIO(imgbytes)); img.load()
    if img.size != (700,1013):raise ValueError('IMAGE_DIMENSIONS_CHANGED')
    img=img.convert('RGB')
    out=Image.new('RGB',(760,910),'white')
    d=ImageDraw.Draw(out)
    font=ImageFont.truetype(FONT,22)
    small=ImageFont.truetype(FONT,14)
    d.text((45,18),'Revisao de efeito — '+case_id,font=font,fill='#111111')
    for label,x,y in [('Acao',45,65),('Duracao',455,65),('Alcance e componentes',45,181),('Descricao e limitacoes',45,338)]:d.text((x,y),label,font=small,fill='#333333')
    for l,t,r,b,x,y in PATCHES:
        cut=ImageOps.autocontrast(ImageOps.grayscale(img.crop((l,t,r,b))))
        out.paste(cut.convert('RGB'),(x,y))
    f=io.BytesIO();out.save(f,format='PNG',optimize=True)
    return f.getvalue()

def make():
    if sha(R60.read_bytes())!=R60_SHA:raise ValueError('R60_SOURCE_SHA_NOT_PINNED')
    with zipfile.ZipFile(R60) as z:
        manifest=json.loads(z.read('PEER14_BLIND_ASSIGNMENT.json'))
        rows=manifest['records'];ids=[r['case_id'] for r in rows]
        if len(ids)!=14 or len(set(ids))!=14:raise ValueError('R60_ROSTER_INVALID')
        outfiles={}; neutral=[]
        for record in rows:
            cid=record['case_id']
            if record['source_image']!=ORIG_IMAGE_DIR+cid+'.jpg':raise ValueError('R60_LINK_INVALID')
            original=z.read(record['source_image'])
            if sha(original)!=record['image_sha256']:raise ValueError('R60_MASKED_IMAGE_SHA_INVALID')
            result=render(original,cid)
            fn=NEUTRAL_DIR+cid+'.png'
            outfiles[fn]=result
            neutral.append({'case_id':cid,'image_path':fn,'image_sha256':sha(result),
              'mechanism_questions':record['mechanism_questions'],'reviewer_submission':None,'verdict':None})
        outfiles['REVISOR14.json']=json.dumps({'status':'NEUTRAL_MECHANICS_REVIEW_PREPARED_NOT_SENT',
          'reviewed':0,'e0_adjudicated':0,'records':neutral},ensure_ascii=False,indent=2).encode()
        b=io.StringIO();writer=csv.writer(b);writer.writerow(['case_id','acao','alcance','descricao','comparadores','parecer','incertezas']);
        for cid in ids:writer.writerow([cid]+['']*6)
        outfiles['RESPOSTAS_14.csv']=b.getvalue().encode()
        outfiles['LEIA_ANTES.md']=(
            '# Leitura mecanica, sem nomes de tecnicas\n\n'
            'Pacote MESTRE-SIDE de revisao independente, NAO ENVIADO. Imagens derivadas da fonte congelada, '
            'com titulo, estilo cromatico e identificacao historica removidos da apresentacao. '
            'Registrar fatos de acao, duracao, alcance, efeito e limites. '
            'Nao atribuir valor oficial sem autoridade; abster em caso de insuficiencia. '
            'O corpo textual pode conter pistas semanticas de identidade, nao sendo possivel garantir anonimato psicologico. '
            'Nao compartilhar com Party ou O Primeiro. Nenhuma resposta de revisor recebida.\n'
        ).encode()
        with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zo:
            for name,data in sorted(outfiles.items()):
                info=zipfile.ZipInfo(name,date_time=(2026,10,22,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                info.comment=b''; info.extra=b''
                zo.writestr(info,data)
        report={'status':'R66_NEUTRAL_MECHANICAL_VIEWS_PREPARED_NOT_SENT','r60_pinned_sha256':R60_SHA,
                'peer_package_sha256':sha(OUT.read_bytes()),'neutral_14':14,'peer_submissions':0,'individual_E0_decisions':0,
                'source_page_fullness':'UNKNOWN','mechanical_data_preserved_as_image_patches':True,
                'caveat':'Visual titles redacted, semantic names can persist in effect text; psychometric blindness unproven',
                'authorized_pa':None,'production':'HOLD','notion_write':False,'party_write':False,
                'patches_per_card':PATCHES,
                'neutral_sha_by_id':{r['case_id']:r['image_sha256'] for r in neutral}}
        REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2))
        return report

if __name__=='__main__':
    print(json.dumps(make(),ensure_ascii=False)[:800])
