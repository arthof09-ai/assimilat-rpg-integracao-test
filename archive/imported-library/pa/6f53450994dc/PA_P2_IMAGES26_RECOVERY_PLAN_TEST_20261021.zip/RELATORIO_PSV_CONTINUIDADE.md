# PSV — Recuperação de mídias e reconciliação P2

**AS-OF:** 21/10/2026 · ASSIMILAÇÃO · MESTRE-SIDE · TEST · sem nova operação formal

## ANTES — factual
- PA último checkpoint documental pleno R42; R43/R44 são candidatos TEST no acervo. R26/R27 preservados.
- 26 técnicas históricas originais e 26 referências em Notion; 0 imagens baixadas no runner anterior. Os ranks originais foram atribuídos empiricamente pelo Mestre e NÃO constituem gabarito científico obrigatório.
- CRAFT H1 fontes naturais com luz intrínseca, H2 P2 não instalada, efeito próprio não demonstrado, RC5/P4/F5 sem evidência material.
- P2-SALT-01, P2-ENERGY-02 e óleo 03/04/05 ainda requerem decisão técnica/autoridade.

## EXECUÇÃO — verificada neste turno
1. Relação completa 26 páginas Mestre → 26 IDs **únicos de bloco de imagem** relida pelo Notion em duas batches, 26/26 imagens, sem duplicações. Metadados consultados pelo conector; links assinados temporários funcionam como referências, mas NÃO foram transportados para bytes.
2. Tentativas de download assinado por runtime e visualizador falharam; o runtime Python não resolve DNS público. Não reportar acerto científico ou OCR. **Bytes 0/26.**
3. Criado `IMAGE_BLOCK_ROSTER_NO_RANKS.json` com 26 IDs opacos, UUID de bloco de imagem e de página para exportação controlada; sem título, custo, rank histórico ou gabarito.
4. Criado recuperador Python read-only compatível com Notion API `/v1/blocks/<uuid>`; usa token **somente no endpoint Notion** e baixa URL S3 sem Authorization; valida host, MIME real, tamanho, SHA, formato e colisão e entrega manifesto mestre-only. **FALTA EXECUÇÃO REAL** porque o token privado autenticado pela conexão MCP não é exposto ao runner e não há rede; não solicitar token em conversa.
5. Executadas 13 provas do módulo de exportação com servidor SIMULADO e 16 provas de decisão P2 TEST: **29/29 PASS, sem qualquer chamada live de download**.
6. Reaberta a receita original P2, inscrição e óleo; redigidas três hipóteses separadas, com menor delta, sem alterar objeto original. **P2/óleo não canonizados.**

## DEPOIS — prova/limites
- **PASS local:** integridade do roster, 29/29 testes, separação oráculo, plano editorial fundamentado.
- **PENDENTE real:** arquivo de imagem original 26/26, validação de mecânicas, classificações fundamentadas, decisão P2 e óleo, lote/operador/ocorrência magia.
- **NAC-PASS proporcional:** registro ANTES/DEPOIS, execução local, SHA + ZIP + leitura da Biblioteca se concluída; PASS apenas no âmbito provado. Party e O Primeiro NO-WRITE, nenhuma ficha/receita/motor canônico mexido.

## Rota operacional de transferência (sem credenciais em chat)
- Um ambiente de execução autorizado a acessar a API Notion pode executar `NOTION_TOKEN=... python download_notions_original_images.py --out ./mestre_only` (substituir diretório sem espaço). Não rodar dentro da Party nem publicar o token.
- A credencial fica local ao operador, nunca em código, artefatos, links externos ou mensagens.
- Após 26/26 JPEG/PNG/WebP originais íntegros e manifesto, submeter SOMENTE as imagens sem título/rank/preço a analista independente para transcrição validada; congela previsão antes de abrir o oráculo Mestre-only.
