# P2 / Óleo — parecer técnico para decisão da autoridade da receita

**MESTRE-SIDE • PROPOSTO • não é uma errata efetivada • 21/10/2026**

Fontes relidas: `https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8` (P2), `https://app.notion.com/p/75fc2b324ede83d492f881e556dc03f8` (Óleo de Vedação Alternativo), `https://app.notion.com/p/3edc2b324ede81adab3dd3a7f9fe921d` (Inscrição). Comunicação original CRAFT: IBX-116 existente `https://app.notion.com/p/3ffc2b324ede817aa3abea3cb7ba8c08`.

## P2-SALT-01 — inconsistência material de identidade

- **VERIFICADO**: ingrediente e origem geográfica dizem `2x Sal de Geodo Santo`; somente o passo 3 diz `Sal de Geodo Encantado`.
- **PROPOSTO prioritário**: corrigir SOMENTE o passo 3, de “Sal de Geodo Encantado” para “Sal de Geodo Santo”. Preserva BOM, localizações e quantidades existentes, sem inventar ingrediente adicional. É o menor delta editorial.
- **Alternativa rejeitada como padrão automático**: mudar BOM/origem para Encantado exigiria redefinir identidade e fonte, dois lugares canônicos, sem prova de substituição autorizada. Pode ser preferida pelo Mestre, mas **não presumir**.
- **Gate**: a autoridade competente confirma a identidade; não editar automaticamente receita original.

## P2-ENERGY-02 — energizador presente apenas no BOM

- **VERIFICADO**: o BOM exige **2x Pedra da Luz OU 2x Pote de Essência Mágica** para energizar a matriz por algum tempo; os seis passos da receita não contêm qualquer instrução para utilizar a fonte nem a duração quantificada. A formulação “OU” é ramo exclusivo; nunca somar 2+2 no mesmo lote por interpretação implícita.
- **PROPOSTO**: autoridade da receita definir se a fonte (i) energiza a massa ANTES de aplicar ao pergaminho/objeto ou (ii) energiza a inscrição JÁ aplicada. Em qualquer escolha, documentar se a fonte é consumida, como é acoplada, por quanto tempo sustenta a vedação e se a operação exige controle/rola­gem. Não inferir números.
- **Gate**: até essa decisão, `energy_stage=null` e execução material HOLD. A fonte não vira automaticamente PA do usuário.

## OIL-03/04/05 — incompatibilidade e truncamento

- **VERIFICADO**: o Óleo Alternativo lista 1 raiz de Mandrágora, 8 gotas Orvalho do Amanhecer, 2 Pó de Ferro Celestial, 1 Essência de Lua Minguante; entretanto, o passo 2 diz “Orvalho de Dragão com a C” (texto truncado) e o passo 4 exige “Essência de Vórtice”, ambos ausentes do BOM. O Pó Ferro não possui instrução explícita de incorporação.
- **PROPOSTO de menor risco**: preservar a identidade dos quatro ingredientes listados e sua proveniência; reconstruir uma sequência de aplicação coerente SOMENTE após aprovação e evidência da autoridade da receita. Guardar a linha truncada no histórico. **Não substituir automaticamente Dragão→Amanhecer ou Vórtice→Lua Minguante** como se equivalência química/mágica estivesse comprovada.
- **Alternativa**: considerar processo Dragão/Vórtice como variante histórica separada, mas isso NÃO autoriza criar receita duplicada ou item novo sem aprovação explícita.

## Testes H2 de instalação — diferencial causal sem falsa prova

| Controle | Montagem declarada | Informação que isolaria |
|---|---|---|
| C0 | suporte neutro, sem fonte/inscrição | luz/fenômeno ambiental |
| C1 | suporte com fontes íntegras, sem P2 | emissão intrínseca dos ingredientes |
| C2 | mesmo suporte/fontes + P2 realmente aplicada | eventual estabilização incremental |
| C3 | suporte sem fontes, com padrão de habilidade própria autorizado | existência de magia própria do item |

C3 só é admissível se houver fórmula efetiva distinta da P2 e inscrição realmente instalada. Resultado não pode ser deduzido de um teste digital. O projeto também carece de lote com custódia, operador efetivamente designado/conhecedor P2, testemunhas e dados de medição.

**Decisão técnica recomendada ao Mestre/autoridade:** priorizar P2-SALT-01 = Santo por economia de alterações; deliberar energizador e óleo separadamente; executar na sala TEST após documentação de insumo/operador. Sem promoção para RC5/P4/F5, sem lançamento R48, PA ou ficha.
