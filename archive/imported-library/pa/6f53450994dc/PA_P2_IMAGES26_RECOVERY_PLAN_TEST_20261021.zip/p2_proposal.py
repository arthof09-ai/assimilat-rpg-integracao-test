"""P2 and Alternative Sealing Oil decision analyzer; proposes TEXT only; NEVER mutates Notion or consumes stock."""
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class Proposal:
    authority: str
    level: str
    proposed_action: str
    status: str='PROPOSED_NOT_CANON'

P2_BOM={
    'Argila de Elemental da Terra':3,
    'Água Benta de Santuário':1,
    'Sal de Geodo Santo':2,
    'Pó de Ferro de Meteoro':3,
    'Essência de Barreira Mística':1,
    'Óleo de Vedação':1,
}
ENERGIZERS={'Pedra da Luz':2,'Pote de Essência Mágica':2}
P2_SALT_PROCESS='Sal de Geodo Encantado'
P2_SALT_BOM='Sal de Geodo Santo'
OIL_BOM={'Raiz de Mandrágora':1,'Gota do Orvalho do Amanhecer':8,
         'Pó de Ferro Celestial':2,'Essência de Lua Minguante':1}
OIL_PROCESS={'Raiz de Mandrágora','Orvalho de Dragão','Essência de Vórtice'}


def build_report(*,salt_authorized:Optional[str]=None, energizer_branch:Optional[str]=None,
                 energy_stage:Optional[str]=None, oil_procedure_authorized:Optional[str]=None,
                 physical_material_evidence:bool=False, witnessed:bool=False):
    salt_options=('SANTO_BOM','ENCANTADO_PROCESS')
    energy_options=('MIX_BEFORE_APPLICATION','ON_OBJECT_AFTER_APPLICATION')
    oil_options=('ALIGN_TO_BOM','RETAIN_AS_SEPARATE_VARIANT')
    errors=[]
    if salt_authorized not in salt_options:errors.append('P2_SALT_UNDECIDED')
    if energizer_branch not in ENERGIZERS:errors.append('P2_ENERGIZER_UNSELECTED')
    if energy_stage not in energy_options:errors.append('P2_ENERGY_APPLICATION_STAGE_UNDECIDED')
    if oil_procedure_authorized not in oil_options:errors.append('OIL_RECIPE_CONFLICT_UNDECIDED')
    if not physical_material_evidence:errors.append('LOT_AUTHENTICITY_NOT_VERIFIED')
    if not witnessed:errors.append('NO_WITNESSED_TEST')
    normalized=dict(P2_BOM)
    if salt_authorized=='ENCANTADO_PROCESS':
        del normalized[P2_SALT_BOM];normalized[P2_SALT_PROCESS]=2
    if energizer_branch in ENERGIZERS:normalized[energizer_branch]=2
    return {
       'scope':'MESTRE_SIDE_TEST_ONLY',
       'bom':normalized,
       'canonical_mutation_performed':False,
       'p2_installation_verified':False,
       'material_magic_verified':False,
       'ready_for_craft_material_gate': not errors,
       'missing_gates':errors,
       'facts':{
         'salt_bom':P2_SALT_BOM,
         'salt_location':P2_SALT_BOM,
         'salt_process':P2_SALT_PROCESS,
         'energy_source_quantity':2,
         'energy_source_is_exclusive':True,
         'energy_step_in_original_process':False,
         'oil_bom':OIL_BOM,
         'oil_process_unlisted_materials':sorted({'Orvalho de Dragão','Essência de Vórtice'}),
         'oil_process_fragment_truncated':True,
       },
       'recommended_actions':[
         'SALT: Prefer SANTO_BOM as one-line minimal editorial repair; Master/recipe authority must adjudicate.',
         'ENERGY: Specify exclusive source 2x, application phase, depletion and duration by authoritative recipe; never infer player PA.',
         'OIL: Prefer align alternative oil process to its own BOM, or formally separate another variant with full recipe and new authority; do not merge silently.',
         'MATERIAL: Authenticate actual lots, operator, witnessed P2 execution and controls C0/C1/C2/C3 before RC5 or power attribution.'
       ]
    }


def proposed_patch(*,source_step3='3. Adicione o Sal de Geodo Encantado à mistura para criar uma barreira protetora.',option='SANTO_BOM'):
    if option!='SANTO_BOM':raise ValueError('Only minimally supported editorial variant generated')
    if source_step3.count('Sal de Geodo Encantado')!=1:raise ValueError('source not exact / ambiguous')
    new=source_step3.replace('Sal de Geodo Encantado','Sal de Geodo Santo')
    return {'notion_edit_performed':False,'old_step':source_step3,'proposed_step':new,
       'status':'WAIT_AUTHORITY','why':'P2 BOM and location both identify Santo; process alone says Encantado'}
