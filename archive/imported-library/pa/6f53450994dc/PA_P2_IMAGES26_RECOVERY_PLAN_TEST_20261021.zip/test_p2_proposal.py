import unittest
from p2_proposal import *
class P2(unittest.TestCase):
 def test_source_salt_disagreement(self):self.assertNotEqual(P2_SALT_PROCESS,P2_SALT_BOM)
 def test_bom_six_primary_materials(self):self.assertEqual(len(P2_BOM),6)
 def test_energy_exclusive_two_sources(self):self.assertEqual(set(ENERGIZERS),{'Pedra da Luz','Pote de Essência Mágica'})
 def test_energy_quantities(self):self.assertEqual(set(ENERGIZERS.values()),{2})
 def test_oil_other_materials_present(self):self.assertIn('Orvalho de Dragão',OIL_PROCESS)
 def test_oil_bom_has_sunrise(self):self.assertIn('Gota do Orvalho do Amanhecer',OIL_BOM)
 def test_default_holds(self):self.assertFalse(build_report()['ready_for_craft_material_gate'])
 def test_default_no_changes(self):self.assertFalse(build_report()['canonical_mutation_performed'])
 def test_sample_with_all_still_no_magic(self):
  x=build_report(salt_authorized='SANTO_BOM',energizer_branch='Pedra da Luz',energy_stage='MIX_BEFORE_APPLICATION',oil_procedure_authorized='ALIGN_TO_BOM',physical_material_evidence=True,witnessed=True)
  self.assertTrue(x['ready_for_craft_material_gate']);self.assertFalse(x['material_magic_verified'])
 def test_salt_branch_santo(self):self.assertIn('Sal de Geodo Santo',build_report(salt_authorized='SANTO_BOM')['bom'])
 def test_salt_branch_encantado(self):self.assertIn('Sal de Geodo Encantado',build_report(salt_authorized='ENCANTADO_PROCESS')['bom'])
 def test_only_one_energizer(self):self.assertIn('Pedra da Luz',build_report(energizer_branch='Pedra da Luz')['bom']);self.assertNotIn('Pote de Essência Mágica',build_report(energizer_branch='Pedra da Luz')['bom'])
 def test_salt_patch_minimal(self):
  p=proposed_patch();self.assertIn('Sal de Geodo Santo',p['proposed_step']);self.assertFalse(p['notion_edit_performed'])
 def test_patch_unsafe_text_rejected(self):
  with self.assertRaises(ValueError):proposed_patch(source_step3='No match')
 def test_no_autocanon_for_any(self):self.assertFalse(build_report(salt_authorized='SANTO_BOM')['p2_installation_verified'])
 def test_oil_ambiguity_stays(self):self.assertIn('OIL_RECIPE_CONFLICT_UNDECIDED',build_report()['missing_gates'])
if __name__=='__main__':unittest.main()
