#!/usr/bin/env python3
"""MESTRE-SIDE only: read original image blocks via an independently authorized Notion API token.
No writes to Notion. No canonical rank provided to this tool. Does not run in ChatGPT's network-restricted container.
Usage (on authorized host): NOTION_TOKEN=... python download_notions_original_images.py --out ./master-only-images
"""
import argparse, hashlib, io, json, os, urllib.request, urllib.parse, urllib.error
from pathlib import Path
from PIL import Image

VERSION='2022-06-28'
MAX_BYTES=24*1024*1024
IMAGE_FORMATS={'JPEG','.JPG','.JPEG','PNG','.PNG','WEBP','.WEBP','GIF','.GIF'}
ALLOWED_DOMAINS=('s3.us-west-2.amazonaws.com','prod-files-secure.s3.us-west-2.amazonaws.com')

class ExportError(Exception): pass

def hash_bytes(b):return hashlib.sha256(b).hexdigest()

def allowed_image_url(u):
    p=urllib.parse.urlsplit(u)
    h=(p.hostname or '').lower()
    # AWS Notion S3 presigned files; block SSRF and local addresses
    return p.scheme=='https' and h in ALLOWED_DOMAINS and not p.username and not p.password

def parse_notion_block(item,expected_block_id):
    if item.get('object')!='block' or item.get('type')!='image':raise ExportError('not an image block')
    actual=(item.get('id') or '').replace('-','')
    if actual != expected_block_id.replace('-',''): raise ExportError('unexpected block id')
    x=item.get('image') or {}
    if x.get('type')=='file':url=(x.get('file') or {}).get('url')
    elif x.get('type')=='external':url=(x.get('external') or {}).get('url')
    else:raise ExportError('unsupported Notion image format')
    if not url or not allowed_image_url(url):raise ExportError('untrusted or unavailable image url')
    return url

def verify_image_bytes(b):
    if not b or len(b)>MAX_BYTES:raise ExportError('image bytes missing/over cap')
    try:
        with Image.open(io.BytesIO(b)) as im:
            fmt=im.format;w,h=im.size
            im.verify()
        if fmt not in ('PNG','JPEG','WEBP','GIF'):raise ExportError('unsupported actual image format')
    except ExportError:raise
    except Exception as e:raise ExportError('invalid image bytes') from e
    return fmt,w,h

def fetch_notion_block(block_id,token,open_fn=urllib.request.urlopen):
    # Authentication is sent ONLY to api.notion.com, never to S3
    req=urllib.request.Request('https://api.notion.com/v1/blocks/'+block_id,
        headers={'Authorization':'Bearer '+token,'Notion-Version':VERSION,'Accept':'application/json'},method='GET')
    with open_fn(req,timeout=30) as resp:
        return json.loads(resp.read(1000000))

def fetch_image_bytes(image_url,open_fn=urllib.request.urlopen):
    if not allowed_image_url(image_url):raise ExportError('forbidden image domain')
    req=urllib.request.Request(image_url,headers={'Accept':'image/*'},method='GET')
    with open_fn(req,timeout=60) as resp:
        # Reject redirects to unknown domains
        if not allowed_image_url(resp.geturl()):raise ExportError('redirected to forbidden domain')
        data=resp.read(MAX_BYTES+1)
    verify_image_bytes(data)
    return data

def recover(roster_path,out_dir,token,open_fn=urllib.request.urlopen):
    if not token:raise ExportError('no Notion API token: cannot export')
    src=json.loads(Path(roster_path).read_text(encoding='utf-8'))
    if src.get('reference_coverage')!=26 or len(src.get('items',[]))!=26:raise ExportError('wrong denominator')
    items=src['items']; out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    manifest={'scope':'MESTRE_ONLY','kind':'ORIGINAL_NOTION_IMAGE_BYTES','expected':26,'downloaded':0,'results':[]}
    for row in items:
        opaque=row['opaque_id'];block=row['image_block_id']
        dest=out/(opaque+'.original')
        try:
            binfo=fetch_notion_block(block,token,open_fn)
            url=parse_notion_block(binfo,block)
            b=fetch_image_bytes(url,open_fn)
            fmt,w,h=verify_image_bytes(b)
            extension={'JPEG':'.jpg','PNG':'.png','WEBP':'.webp','GIF':'.gif'}[fmt]
            dest=dest.with_suffix(extension)
            if dest.exists() and hash_bytes(dest.read_bytes())!=hash_bytes(b):
                raise ExportError('existing file collision with different bytes')
            dest.write_bytes(b)
            manifest['downloaded']+=1
            manifest['results'].append({'opaque_id':opaque,'status':'BYTES_VERIFIED','file':dest.name,'sha256':hash_bytes(b),'bytes':len(b),'format':fmt,'width':w,'height':h})
        except Exception as exc:
            manifest['results'].append({'opaque_id':opaque,'status':'BLOCKED','error':type(exc).__name__+': '+str(exc)[:160]})
    (out/'MEDIA_DIGEST_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    # No original title, rank, or price is stored in output or downloaded filename.
    return manifest

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--roster',default=str(Path(__file__).with_name('IMAGE_BLOCK_ROSTER_NO_RANKS.json')))
    ap.add_argument('--out',required=True)
    ap.add_argument('--token-env',default='NOTION_TOKEN')
    args=ap.parse_args()
    tok=os.getenv(args.token_env)
    if not tok:ap.error('No authorized Notion token in '+args.token_env)
    d=recover(args.roster,args.out,tok)
    print(json.dumps({'expected':d['expected'],'downloaded':d['downloaded'],'missing':26-d['downloaded']},ensure_ascii=False))
