import io,unittest,tempfile,json
from pathlib import Path
from PIL import Image
from download_notions_original_images import (parse_notion_block,allowed_image_url,verify_image_bytes,fetch_notion_block,fetch_image_bytes,recover,ExportError)

BLOCK='19594284-e99e-4d3d-a638-b3973cf505e3'
S3='https://prod-files-secure.s3.us-west-2.amazonaws.com/s/filename.jpg?X-Amz-Signature=fake'

class FakeResponse:
    def __init__(self,data,url):self.data=data;self.url=url
    def __enter__(self):return self
    def __exit__(self,*a):pass
    def read(self,n=None):return self.data if n is None else self.data[:n]
    def geturl(self):return self.url
class T(unittest.TestCase):
    def setUp(self):
        io_b=io.BytesIO();Image.new('RGB',(18,17),'white').save(io_b,'JPEG');self.image=io_b.getvalue()
        self.block={'object':'block','type':'image','id':BLOCK,'image':{'type':'file','file':{'url':S3}}}
        def opened(req,timeout=None):
            u=req.full_url
            if u.startswith('https://api.notion.com/'):
                self.assertEqual(req.get_header('Authorization'),'Bearer fake-token')
                return FakeResponse(json.dumps(self.block).encode(),u)
            self.assertFalse(req.has_header('Authorization'))
            return FakeResponse(self.image,u)
        self.opener=opened
    def test_safe_s3(self):self.assertTrue(allowed_image_url(S3))
    def test_block_mapping(self):self.assertEqual(parse_notion_block(self.block,BLOCK),S3)
    def test_wrong_id(self):
        with self.assertRaises(ExportError):parse_notion_block(self.block,'00000000-0000-0000-0000-000000000000')
    def test_wrong_block_type(self):
        x=dict(self.block,type='paragraph')
        with self.assertRaises(ExportError):parse_notion_block(x,BLOCK)
    def test_ssrf_local(self):
        for x in ('http://127.0.0.1/x','https://evil.com/x','https://prod-files-secure.s3.us-west-2.amazonaws.com.evil.com/x','file:///etc/passwd'):
            self.assertFalse(allowed_image_url(x))
    def test_token_only_to_notion(self):self.assertEqual(fetch_notion_block(BLOCK,'fake-token',self.opener)['type'],'image')
    def test_byte_download_no_token(self):self.assertEqual(fetch_image_bytes(S3,self.opener),self.image)
    def test_invalid_image(self):
        with self.assertRaises(ExportError):verify_image_bytes(b'Text only')
    def test_valid_image(self):self.assertEqual(verify_image_bytes(self.image)[:1],('JPEG',))
    def test_no_token(self):
        with self.assertRaises(ExportError):recover('/not_a_file','/tmp','')
    def test_wrong_n(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'i.json';p.write_text(json.dumps({'reference_coverage':25,'items':[]}))
            with self.assertRaises(ExportError):recover(p,Path(d)/'out','token',self.opener)
    def test_recover_all_26_synthetic(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.json';out=Path(d)/'output'
            rows=[{'opaque_id':'opaque'+str(i),'image_block_id':BLOCK} for i in range(26)]
            p.write_text(json.dumps({'reference_coverage':26,'items':rows}))
            r=recover(p,out,'fake-token',self.opener)
            self.assertEqual(r['downloaded'],26);self.assertEqual(len(list(out.glob('*.jpg'))),26)
            self.assertFalse(any('historical_rank' in str(x) for x in r['results']))
    def test_collision_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.json';out=Path(d)/'output';out.mkdir()
            (out/'opaque0.jpg').write_bytes(b'bad')
            rows=[{'opaque_id':'opaque'+str(i),'image_block_id':BLOCK} for i in range(26)]
            p.write_text(json.dumps({'reference_coverage':26,'items':rows}))
            r=recover(p,out,'fake-token',self.opener)
            self.assertEqual(r['downloaded'],25);self.assertEqual(r['results'][0]['status'],'BLOCKED')
if __name__=='__main__':unittest.main()
