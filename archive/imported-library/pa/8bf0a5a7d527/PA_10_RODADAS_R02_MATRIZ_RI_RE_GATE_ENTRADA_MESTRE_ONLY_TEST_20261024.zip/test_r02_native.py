"""R02 native cross-rank, composites, negatives, and bounded duplicate-name guard.
No external writes, engine reimplementation, or production claims.
"""
import hashlib, json, sys, math, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parent
B = ROOT/'baseline_r26'
sys.path.insert(0, str(B))
sys.path.insert(0, str(B/'baseline_r25'/'baseline_r22'))
from parecer_semicanonico_r26 import avaliar, BASE as BASE26, FLOORS as FLOOR26
from rank_guard_r22 import Effect, estimate_new_item, GateError
from R02_GATE_ENTRADA_TEST import avaliar_com_gate, normalized_label

RANKS=['Bronze','Prata','Ouro','Ouro Negro','Lendário']
BASE=[6,12,24,35,50]
FLOORS=[8,11,21,35,90]
SHA_R26='7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8'
SHA_R22='b43305818e8424b1c4eee65f11858732c961a9ef024b941b09e94c8269003257'
EVIDENCE=[]

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def data(t,usos=None,origem='NOVO_TEST'):
    return avaliar_com_gate(t,avaliar_nativo=avaliar,usos=usos,origem=origem)

def desc(item_rank,effect_rank,kind='ATIVA',name='Pulso'):
    label='ativa' if kind=='ATIVA' else 'passiva'
    mechanic='Com uma ação padrão, causa dano em um único inimigo.' if kind=='ATIVA' else 'Enquanto equipado, enxerga no escuro.'
    return f'Item: Teste R02\nRank do item: {item_rank}\nHabilidade {label} {effect_rank}: {name}: {mechanic}'

def native_oracle(item_rank, abilities, bonuses=0):
    daily=bonuses
    per_use=0
    for x in abilities:
        r=RANKS.index(x['rank'])
        daily+= BASE[r] if x['kind']=='PASSIVA' else BASE[r]//2
        if x['kind']=='ATIVA': per_use+=x.get('uses',0)*(BASE[r]*3//5)
    return {'daily_raw':daily,'daily':max(FLOORS[RANKS.index(item_rank)],daily),'activations':per_use,'total':max(FLOORS[RANKS.index(item_rank)],daily)+per_use}

class PA_R02(unittest.TestCase):
 def test_00_exact_source_bytes(self):
    self.assertEqual(sha(B/'parecer_semicanonico_r26.py'),SHA_R26)
    self.assertEqual(sha(B/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py'),SHA_R22)

 def test_01_cross_ri_re_active_25(self):
    for i,item in enumerate(RANKS):
     for j,effect in enumerate(RANKS):
      with self.subTest(item=item,effect=effect):
       x=data(desc(item,effect),{'Pulso':2})
       p=x['r26']['pareceres'][0]
       self.assertEqual(p['rank_efeito_recomendado'],effect)
       self.assertEqual(p['pa_dia_pelo_rank_proposto'],BASE[j]//2)
       self.assertEqual(p['pa_uso_pelo_rank_proposto'],BASE[j]*3//5)
       if j>i:
        self.assertNotIn('cenario_pa',x['r26']); self.assertEqual(x['status'],'HOLD')
       else:
        oracle=native_oracle(item,[{'rank':effect,'kind':'ATIVA','uses':2}])
        bill=x['r26']['cenario_pa']
        self.assertEqual((bill['pa_dia'],bill['pa_ativacoes'],bill['total_dia']), (oracle['daily'],oracle['activations'],oracle['total']))
        old=estimate_new_item(item,[Effect('Pulso',effect,'ATIVA','E3',2)])
        self.assertEqual((old['day'],old['activations'],old['total']),(oracle['daily'],oracle['activations'],oracle['total']))
       EVIDENCE.append({'test':'cross_active','RI':item,'RE':effect,'closed':j<=i,'result':x['r26'].get('cenario_pa',{}).get('total_dia',None),'status':x['status']})

 def test_02_cross_ri_re_passive_25(self):
    for i,item in enumerate(RANKS):
     for j,effect in enumerate(RANKS):
      with self.subTest(item=item,effect=effect):
       x=data(desc(item,effect,'PASSIVA',name='Luz'))
       p=x['r26']['pareceres'][0]
       self.assertEqual(p['pa_dia_pelo_rank_proposto'],BASE[j]);self.assertEqual(p['pa_uso_pelo_rank_proposto'],0)
       if j>i:
        self.assertNotIn('cenario_pa',x['r26'])
       else:
        oracle=native_oracle(item,[{'rank':effect,'kind':'PASSIVA','uses':0}])
        bill=x['r26']['cenario_pa'];self.assertEqual(bill['total_dia'],oracle['total'])
        old=estimate_new_item(item,[Effect('Luz',effect,'PASSIVA','E3')]);self.assertEqual(old['total'],oracle['total'])
       EVIDENCE.append({'test':'cross_passive','RI':item,'RE':effect,'closed':j<=i,'result':x['r26'].get('cenario_pa',{}).get('total_dia',None),'status':x['status']})

 def test_03_multi_three_ranks_distinct(self):
    desc3=('Item: Relicário\nRank do item: Ouro Negro\n'
         'Habilidade passiva Bronze: Visão: Enquanto equipado, enxerga no escuro.\n'
         'Habilidade ativa Prata: Pulso: Com uma ação padrão, causa 6d6 de dano em um único alvo.\n'
         'Habilidade ativa Ouro: Lança: Com uma ação padrão, causa 8d10 de dano em um único alvo.')
    x=data(desc3,{'Pulso':2,'Lança':1})
    oracle=native_oracle('Ouro Negro',[{'rank':'Bronze','kind':'PASSIVA'},{'rank':'Prata','kind':'ATIVA','uses':2},{'rank':'Ouro','kind':'ATIVA','uses':1}])
    p=x['r26']['cenario_pa'];self.assertEqual((p['pa_dia'],p['pa_ativacoes'],p['total_dia']),(35,28,63))
    self.assertEqual(p['total_dia'],oracle['total']); self.assertEqual(len(x['r26']['pareceres']),3)
    EVIDENCE.append({'test':'three_skills','total':p['total_dia'],'oracle':oracle})

 def test_04_multi_four_ranks_floor_legendary(self):
    s=('Item: Anel\nRank do item: Lendário\n'
       'Habilidade passiva Bronze: Visão: Enquanto equipado, enxerga no escuro.\n'
       'Habilidade ativa Prata: Pulso: Com uma ação padrão, causa 6d6 de dano em um único alvo.\n'
       'Habilidade ativa Ouro: Lança: Com uma ação padrão, causa 8d10 de dano em um único alvo.\n'
       'Habilidade passiva Ouro Negro: Rastro: Enquanto equipado, não deixa pegadas.')
    x=data(s,{'Pulso':2,'Lança':1});bill=x['r26']['cenario_pa']
    self.assertEqual((bill['taxas_habilidades_pa_dia'],bill['pa_dia'],bill['pa_ativacoes'],bill['total_dia']),(59,90,28,118))
    EVIDENCE.append({'test':'four_skills','total':bill['total_dia']})

 def test_05_mixed_numeric_and_skill(self):
    s=('Item: Relicário\nRank do item: Ouro\nBônus: +2 FOR; +1 ataque; +3 m deslocamento; +4 dano\n'
       'Habilidade passiva Bronze: Visão: Enquanto equipado, enxerga no escuro.\n'
       'Habilidade ativa Prata: Pulso: Com uma ação padrão, causa 6d6 de dano em um único alvo.')
    x=data(s,{'Pulso':2});bill=x['r26']['cenario_pa']; self.assertEqual((bill['componentes_numericos_pa_dia'],bill['taxas_habilidades_pa_dia'],bill['pa_dia'],bill['pa_ativacoes'],bill['total_dia']),(18,12,30,14,44))
    old=estimate_new_item('Ouro',[Effect('Visão','Bronze','PASSIVA','E3'),Effect('Pulso','Prata','ATIVA','E3',2)],numeric_pa=18)
    self.assertEqual(old['total'],44)
    EVIDENCE.append({'test':'mixed_numeric','total':44})

 def test_06_numeric_all_six_axes(self):
    s='Item: Braçadeira\nRank do item: Bronze\nBônus: +1 FOR; +2 DES; +3 dano; +1 teste de ataque; +2 m de deslocamento; +1 CA mágica'
    x=data(s);bill=x['r26']['cenario_pa']; self.assertEqual((bill['pa_dia'],bill['total_dia']),(22,22))
    self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],22)
    EVIDENCE.append({'test':'numeric_axes','total':22})

 def test_07_zero_activations_preserve_daily(self):
    x=data(desc('Ouro','Prata'),{'Pulso':0});b=x['r26']['cenario_pa']
    self.assertEqual((b['pa_dia'],b['pa_ativacoes'],b['total_dia']),(21,0,21))

 def test_08_numeric_floor(self):
    x=data('Item: Manoplas\nRank do item: Prata\nBônus: +2 FOR');self.assertEqual(x['r26']['cenario_pa']['pa_dia'],11)

 def test_09_duplicate_label_is_real_gap_and_is_blocked_by_r02(self):
    s=('Item: Teste\nRank do item: Prata\n'
       'Habilidade passiva Prata: Reflexo: Enquanto equipado, enxerga no escuro.\n'
       'Habilidade passiva Prata: Reflexo: Enquanto equipado, emite luz.')
    unsafe=avaliar(s)
    self.assertEqual(len(unsafe['abilities']),2)
    self.assertEqual(unsafe['r26']['cenario_pa']['pa_dia'],24) # confirmed actual R26 gap
    self.assertFalse(unsafe['issues'])
    safe=data(s)
    self.assertEqual(safe['r02_guard'],'HOLD_INPUT_AMBIGUOUS_ABILITY_ID')
    self.assertEqual(safe['duplicate_labels_normalized'],['reflexo'])
    self.assertIsNone(safe['cenario_pa']);self.assertNotIn('r26',safe)
    EVIDENCE.append({'test':'duplicate_gap','native_unsafe_day':24,'r02_gate':'HOLD_INPUT_AMBIGUOUS_ABILITY_ID'})

 def test_10_duplicate_case_folded_is_blocked(self):
    s=('Item: Teste\nRank do item: Prata\n'
       'Habilidade passiva Prata: Rásto: Enquanto equipado, enxerga no escuro.\n'
       'Habilidade passiva Prata: RASTO: Enquanto equipado, emite luz.')
    x=data(s);self.assertEqual(x['r02_guard'],'HOLD_INPUT_AMBIGUOUS_ABILITY_ID');self.assertEqual(x['duplicate_labels_normalized'],['rasto'])

 def test_11_distinct_ids_are_not_blocked(self):
    s=('Item: Teste\nRank do item: Prata\n'
       'Habilidade passiva Prata: Visão: Enquanto equipado, enxerga no escuro.\n'
       'Habilidade passiva Prata: Luz: Enquanto equipado, emite luz.')
    x=data(s);self.assertEqual(x['r02_guard'],'PASS_UNIQUE_ABILITY_IDENTIFIERS')
    self.assertEqual(x['r26']['cenario_pa']['pa_dia'],24)

 def test_12_legacy_never_repriced(self):
    s='Item: Bota Caminho Veloz\nRank do item: Ouro\nHabilidade ativa: Velocidade: +8m\n18 PA por dia'
    x=data(s,origem='HISTORICO');self.assertEqual(x['r26']['veredito'],'ANALISE_HISTORICA_SEM_REPRECIFICACAO');self.assertNotIn('cenario_pa',x['r26'])

 def test_13_numeric_conditional_refused(self):
    x=data('Item: Talismã\nRank do item: Ouro\nBônus: +5 FOR somente durante combate')
    self.assertNotIn('cenario_pa',x['r26']);self.assertIn('BONUS_CONDICIONAL_NAO_EQUIVALE_A_MODIFICADOR_PERMANENTE',x['issues'])

 def test_14_ca_ambiguous_refused(self):
    x=data('Item: Armadura\nRank do item: Ouro\nBônus: +11 CA; +15 DES')
    self.assertNotIn('cenario_pa',x['r26']);self.assertTrue(x['numeric_audit']['componentes_nao_precificados'])

 def test_15_ca_physical_not_magical(self):
    x=data('Item: Armadura\nRank do item: Prata\nBônus: +11 CA de armadura física; +2 DES')
    self.assertEqual(x['r26']['cenario_pa']['pa_dia'],11)
    self.assertEqual(x['numeric_audit']['subtotal_reconhecido_pa'],10)
    self.assertTrue(x['numeric_audit']['nao_cobrados_conhecidos'])

 def test_16_benefit_recurring_damage_refused(self):
    x=data('Item: Teste\nRank do item: Ouro\nBônus: +3 dano por rodada')
    self.assertNotIn('cenario_pa',x['r26'])

 def test_17_numeric_identical_repeated_refused(self):
    x=data('Item: Teste\nRank do item: Prata\nBônus: +1 FOR; +1 FOR')
    self.assertNotIn('cenario_pa',x['r26'])

 def test_18_fractional_bonus_refused(self):
    x=data('Item: Teste\nRank do item: Prata\nBônus: +1,5 FOR')
    self.assertNotIn('cenario_pa',x['r26'])

 def test_19_modal_contradiction_refused(self):
    x=data('Item: Anel\nRank do item: Ouro\nHabilidade passiva: Escudo: Como uma ação padrão, causa 8d10 de dano em um único alvo.')
    self.assertNotIn('cenario_pa',x['r26'])

 def test_20_complex_free_text_refused(self):
    x=data('Quero um anel capaz de teletransportar qualquer pessoa e dar invisibilidade permanente e reviver mortos.')
    self.assertNotIn('cenario_pa',x['r26'])

 def test_21_high_re_lower_ri_refused(self):
    x=data(desc('Bronze','Lendário'),{'Pulso':2});self.assertNotIn('cenario_pa',x['r26'])

 def test_22_missing_explicit_item_rank_is_only_e3_inferred(self):
    x=data('Item: Relicário\nHabilidade ativa Ouro: Lança: Com uma ação padrão, causa 8d10 de dano em um único alvo.',{'Lança':1})
    p=x['r26']['cenario_pa'];self.assertTrue(p['rank_item_e3_inferido']);self.assertFalse(x['official_classification']);self.assertEqual(p['natureza'].split(',')[0],'PARECER_E3_SEMICANONICO_REVOGAVEL')

 def test_23_invalid_usages_rejected(self):
    for u in (-1,'2',2.5,True):
     with self.subTest(usos=repr(u)):
      with self.assertRaises((ValueError,TypeError)):
       data(desc('Prata','Bronze'),{'Pulso':u})

 def test_24_origin_invalid_research_rejected(self):
    with self.assertRaises(ValueError):
     avaliar('Item: Teste\nRank do item: Bronze',pesquisa=[])

 def test_25_unknown_usage_key_native_gap_and_gate(self):
    s=desc('Prata','Bronze')
    unsafe=avaliar(s,usos={'Pulzo':2})
    self.assertEqual(unsafe['r26']['cenario_pa']['total_dia'],11) # silently ignored by native R26
    self.assertEqual(avaliar(s,usos={'Pulso':2})['r26']['cenario_pa']['total_dia'],17)
    safe=data(s,{'Pulzo':2})
    self.assertEqual(safe['r02_guard'],'HOLD_INPUT_USAGE_KEY_MISMATCH')
    self.assertEqual(safe['unknown_usage_keys'],['Pulzo'])
    self.assertEqual(safe['possible_exact_names'],['Pulso'])
    self.assertIsNone(safe['cenario_pa'])
    EVIDENCE.append({'test':'unknown_usage_key_gap','native_unsafe_total':11,'correct_input_total':17,'r02_gate':'HOLD_INPUT_USAGE_KEY_MISMATCH'})

 def test_26_unmatched_and_case_changed_usage_keys_fail_closed(self):
    for usages in ({'PULSO':2},{'Pulso':2,'Fantasma':1},{'Púlso':2}):
     with self.subTest(usages=usages):
      x=data(desc('Prata','Bronze'),usages)
      self.assertEqual(x['r02_guard'],'HOLD_INPUT_USAGE_KEY_MISMATCH')
      self.assertIsNone(x['cenario_pa'])

 def test_27_correct_exact_usage_key_survives(self):
    x=data(desc('Prata','Bronze'),{'Pulso':2})
    self.assertEqual(x['r02_guard'],'PASS_UNIQUE_ABILITY_IDENTIFIERS')
    self.assertEqual(x['r26']['cenario_pa']['total_dia'],17)

 def test_28_no_canonical_authority_on_any_closed_sample(self):
    x=data(desc('Lendário','Prata'),{'Pulso':2})
    self.assertEqual(x['r26_guard'] if 'r26_guard' in x else x['r02_guard'],'PASS_UNIQUE_ABILITY_IDENTIFIERS')
    self.assertFalse(x['official_classification']);self.assertFalse(x['canonical_write'])
    self.assertEqual(x['r26']['producao'],'HOLD')
    self.assertIn('E3',x['r26']['cenario_pa']['natureza'])

 def test_29_duplicate_active_usage_is_not_billed_twice_via_gate(self):
    s=('Item: Relicário\nRank do item: Ouro\n'
       'Habilidade ativa Prata: Eco: Com uma ação padrão, causa dano em um único inimigo.\n'
       'Habilidade ativa Prata: Eco: Com uma ação padrão, projeta energia contra um único inimigo.')
    unsafe=avaliar(s,usos={'Eco':2})
    self.assertEqual(len(unsafe['abilities']),2)
    self.assertEqual(unsafe['r26']['cenario_pa']['pa_ativacoes'],28) # 2 abilities * 2 uses * 7
    safe=data(s,{'Eco':2})
    self.assertEqual(safe['r02_guard'],'HOLD_INPUT_AMBIGUOUS_ABILITY_ID')
    self.assertIsNone(safe['cenario_pa'])
    EVIDENCE.append({'test':'duplicate_active_unsafe','native_unsafe_activations':28,'r02_guard':'HOLD_INPUT_AMBIGUOUS_ABILITY_ID'})

 def test_30_bare_r22_does_not_validate_ri_re_hierarchy(self):
    unsafe_low_level=estimate_new_item('Bronze',[Effect('Pulso','Lendário','ATIVA','E3',1)])
    self.assertEqual(unsafe_low_level['total'],55)
    checked=data(desc('Bronze','Lendário'),{'Pulso':1})
    self.assertNotIn('cenario_pa',checked['r26'])
    self.assertEqual(checked['status'],'HOLD')
    EVIDENCE.append({'test':'low_level_estimator_not_rank_gate','r22_numeric_total_not_authorized':55,'r26':'HOLD'})

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(PA_R02)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    payload={'round':'PA-10-R02','scope':'MESTRE_ONLY_TEST','source_sha256':{'r26':sha(B/'parecer_semicanonico_r26.py'),'r22':sha(B/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py')},'test_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'cross_rank_active_cases':25,'cross_rank_passive_cases':25,'cross_rank_e3_admissible':30,'cross_rank_blocked':20,'direct_evidence':EVIDENCE,'official_decisions':0,'production':'HOLD','remote_writes':0,'guard_note':'Pre-canonical TEST wrapper; no authoritatively installed patch.'}
    (ROOT/'R02_NATIVE_RESULTS.json').write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print('RESULTS_WRITTEN',ROOT/'R02_NATIVE_RESULTS.json')
    if not result.wasSuccessful():sys.exit(1)
