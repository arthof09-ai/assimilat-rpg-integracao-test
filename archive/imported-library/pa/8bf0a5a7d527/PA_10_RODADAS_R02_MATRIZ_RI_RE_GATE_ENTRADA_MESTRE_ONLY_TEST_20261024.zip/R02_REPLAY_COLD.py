"""PA round 2 exact cold replay, **read-only / MESTRE ONLY / TEST**.
Requires stdlib Python, includes untouched source archive R51; no PA engine replacement.
"""
from __future__ import annotations
from pathlib import Path
import hashlib, tempfile, zipfile, subprocess, shutil, os, sys, json
HERE=Path(__file__).resolve().parent
SRC=HERE/'SOURCE_PA_R51_FROZEN.zip'
SNAP='635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f'
R26='7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8'
R22='b43305818e8424b1c4eee65f11858732c961a9ef024b941b09e94c8269003257'

def sha(b):return hashlib.sha256(b).hexdigest()

def main():
    assert SRC.exists(),'SOURCE_ARCHIVE_MISSING'
    assert sha(SRC.read_bytes())==SNAP, 'SOURCE_R51_SHA_DRIFT'
    expected=HERE/'R02_NATIVE_RESULTS.json'
    frozen=expected.read_bytes()
    assert frozen.endswith(b'\n'), 'INCOMPLETE_FROZEN_JSON'
    with tempfile.TemporaryDirectory(prefix='pa_r02_clean_') as d:
        directory=Path(d)
        base=directory/'baseline'
        base.mkdir()
        with zipfile.ZipFile(SRC,'r') as z:
            assert z.testzip() is None,'BAD_ZIP_CRC'
            for member in z.namelist():
                assert (base/member).resolve().is_relative_to(base.resolve()),'ZIP_TRAVERSAL'
            z.extractall(base)
        assert sha((base/'baseline_r26'/'parecer_semicanonico_r26.py').read_bytes())==R26,'R26_SOURCE_CHANGED'
        assert sha((base/'baseline_r26'/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py').read_bytes())==R22,'R22_SOURCE_CHANGED'
        for source in ('R02_GATE_ENTRADA_TEST.py','test_r02_native.py'):
            shutil.copy2(HERE/source,directory/source)
        # Our 29-unit test imports /baseline_r26 from a relative location only.
        (directory/'baseline_r26').symlink_to(base/'baseline_r26',target_is_directory=True)
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
        out=subprocess.run([sys.executable,'-B','test_r02_native.py'],cwd=directory,text=True,capture_output=True,env=env,timeout=80)
        if out.returncode:
            raise RuntimeError('COLD_REPLAY_TEST_FAIL:'+out.stdout[-1500:]+out.stderr[-2000:])
        assert 'Ran 31 tests' in out.stderr and '\nOK' in out.stderr,'TEST_COUNT_OR_RESULT_CHANGED'
        regenerated=(directory/expected.name).read_bytes()
        assert regenerated==frozen,'R02_FROZEN_RESULTS_MISMATCH'
        evidence=json.loads(regenerated)
        matrix=[x for x in evidence['direct_evidence'] if x['test'] in ('cross_active','cross_passive')]
        assert len(matrix)==50 and sum(x['closed'] for x in matrix)==30,'CROSS_RANK_MATRIX_DRIFT'
        report={'result':'PASS','round':'R02','native_source_sha256':sha(SRC.read_bytes()),'R26_sha256':R26,'R22_sha256':R22,'methods':31,'matrix_cases':50,'matrix_admitted_e3':30,'matrix_held':20,'source_rewritten':False,'notion_writes':0,'craft_writes':0,'r02_output_sha256':sha(regenerated),'guard':'TEST_ONLY_NOT_INSTALLED_IN_CRAFT','r27_native':'NOT_IN_THIS_PACKAGE'}
        return report

if __name__=='__main__': print(json.dumps(main(),ensure_ascii=False,sort_keys=True))
