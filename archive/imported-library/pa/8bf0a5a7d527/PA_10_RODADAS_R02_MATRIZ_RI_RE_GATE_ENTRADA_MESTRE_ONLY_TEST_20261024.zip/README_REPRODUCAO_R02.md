# PA — Rodada 2/10 — Reprodução (MESTRE-ONLY / TEST)

Este pacote não constitui motor novo: contém um snapshot ZIP **byte-idêntico** do R51 com o módulo original **R26→R25→R22**, e somente scripts de teste/validação. Não instalar automaticamente em QMC05, CRAFT PROD, Notion ou Party.

## Execução sem dependências de terceiros

1. Extrair o ZIP completo para uma pasta.
2. Executar `python R02_REPLAY_COLD.py` (Python 3.11+).
3. Esperar JSON com `result: PASS`, `methods: 31`, `matrix_cases: 50`, `matrix_admitted_e3: 30`, `matrix_held: 20`.

A rotina verifica SHA-256 do snapshot R51 e dos fontes nativos R26/R22, CRC do ZIP, extração segura em pasta temporária, roda testes originais invocados pelos scripts novos e compara bytes do relatório JSON refeito com o resultado congelado. Apaga a pasta temporária. Não precisa de rede, API, Notion ou credenciais.

## Evidência

- 31/31 métodos novos R02 PASS. Os 50 cenários cruzados são subcasos de 2 métodos, **não adicionar 50 a 31**.
- 25 variações ATIVAS e 25 PASSIVAS de RI × RE: 30 receberam cenário E3 coerente com tarifa/piso e 20 permaneceram sem total por RI menor que RE. O cálculo de R22 isolado não valida a compatibilidade RI/RE: o R26 oferece esse gate.
- 3 habilidades com RI Ouro Negro: 35 PA/dia + 28 PA em ativações = 63 total. Quatro habilidades com RI Lendário: 90 + 28 = 118. Numéricos + habilidades RI Ouro: 30 +14 = 44. Bônus numéricos completos RI Bronze: 22 PA/dia.
- **Achado A:** duas habilidades distintas declaradas com o mesmo nome podem ser duplamente faturadas no R26. Teste reproduzido com passivas Prata `Reflexo`: 24 PA/dia, sem issue; com ativas `Eco`, 28 PA de ativações contadas com chave duplicada, sem alerta.
- **Achado B:** `usos={'Pulzo':2}` para a habilidade `Pulso` é ignorado silenciosamente pelo R26: 11 PA contra 17 PA com o nome exato (Prata RI, Bronze RE).
- `R02_GATE_ENTRADA_TEST.py`: barreira **somente TEST** que devolve HOLD sem valores fechados se detectar nome de habilidade duplicado (normalizado) ou chave de uso não correspondente **exatamente** a um ID existente. Não realiza cálculo PA; delega tarifas exclusivamente ao R26 original; não é patch instalado no CRAFT. Aceitar divergência ortográfica automaticamente seria arriscado; exige correção explícita do usuário.
- Todos os cenários originais R26 mantêm E3, `production=HOLD`, sem canonização e sem escrita.

## Interpretação correta

Módulo R27 original **não foi recuperado neste pacote/sessão**; o handoff Notion documenta a integração R27→R26 e a correção histórica CRAFT v1.2, mas isso não é reexecução de R27 nem TEE PROD. A prevenção dos dois defeitos é candidata TEST; depende de incorporação autorizada e de validação no consumidor real antes de ser declarada proteção oficial.

A R02 não altera fórmulas, custos históricos, receitas, fichas, inventário, Party ou O Primeiro; 0 escritas no Notion.
