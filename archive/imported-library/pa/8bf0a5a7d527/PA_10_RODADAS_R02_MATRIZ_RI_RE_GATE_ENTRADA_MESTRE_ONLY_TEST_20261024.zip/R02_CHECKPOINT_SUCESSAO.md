# PSV — Sistema Universal de PA — Rodada 2/10 — MESTRE-ONLY / TEST

**Data:** 24/10/2026. **Operação:** continuidade da operação de PA existente, não criar motor/OP paralelos. **Contador pós-execução:** 2/10 concluídas; **8 rodadas restantes**. **Mestre:** declarou dez rodadas máximas e retorno ao CRAFT após a 10ª. Preparações/perguntas não contam; cada rodada formal de execução conta uma. **Identity/role:** MESTRE-SIDE. Não adquirir writer, lease ou epoch por continuidade presumida.

## Fontes, precedente e BEFORE

- R01 `PA_10_RODADAS_R01_VALIDACAO_NATIVA_MESTRE_ONLY_TEST_20261024.zip` armazenado na Biblioteca Mestre, `libfile_075d0a5076e881918a070eb075a57f46` e readback confirmado no chat anterior. Checkpoint R01 `libfile_930c620fc0a4819184d762b6ec2ac97e`: 232/232 métodos R01 PASS, 10/10 tarifa R26↔R22; snapshot R51 íntegro; R27 não reexecutado. Não somar o teste histórico R01 com o R02 como se tivesse sido reexecutado nesta rodada.
- Fonte congelada R51 reutilizada **sem mutação** `SOURCE_PA_R51_FROZEN.zip`, SHA256 `635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f`. R26 original `7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8`; R22 original `b43305818e8424b1c4eee65f11858732c961a9ef024b941b09e94c8269003257`.
- Notion Mestre PR-ITEM-02 `3eec2b324ede81ecb058f59f5b67e4f4` confirma que R26/R27 não precisavam ter sua tarifa corrigida; erro histórico era no CRAFT v1.1, corrigido em CRAFT v1.2. Handoff existente `3ffc2b324ede81669f23c74ef48ceef8`; OP CRAFT `3f1c2b324ede81d7aa79c83106240516`. Os três foram reabertos em **modo leitura** nesta rodada. As regras vigentes permanecem passiva 100% base/dia; ativa floor(base×50%)/dia, floor(base×60%)/ativação; rank do ITEM tem piso diário próprio; não reprecificar histórico.

## AFTER — medições executadas

1. **Matriz 5 RI × 5 RE × 2 gatilhos:** 50/50 comparações esperadas PASS via invocação real R26; 30 cenários receberam custo E3 e concordaram com R22 quando RI>=RE; 20 cenários com RI<RE corretamente não receberam PA total; modalidades ativa e passiva conferidas separadamente e pisos dos cinco ranks cobertos. Os 50 cenários são **subtestes dos métodos 01 e 02**.
2. **Compostos:** 3 habilidades de ranks Bronze/Prata/Ouro em item Ouro Negro: 35 PA/dia +28 ativações =63; 4 habilidades Bronze/Prata/Ouro/Ouro Negro em item Lendário:90+28=118; bônus numérico FOR/ataque/deslocamento/dano + habilidades em item Ouro: 30+14=44; seis eixos numéricos em item Bronze:22 PA/dia; pisos e ativações zero preservados.
3. **Negativos existentes:** histórico não reprecificado; bônus condicional, CA ambígua, dano recorrente, bônus repetido, fracionário, modalidade contraditória, texto livre composto e RI<RE não geram total fechado; usos negativos, não inteiros e pesquisa de tipo inválido são recusados; classificação E3 não se torna E0 nem PROD.
4. **DEFEITO A REPRODUZIDO no R26 ORIGINAL:** duas habilidades semanticamente distintas mas declaradas com ID/nome `Reflexo`, passivas Prata, geraram **24 PA/dia**, sem issues, quando deveriam ser desambiguadas antes de faturar; duas ativas distintas sob `Eco`, Prata, duas ativações indicadas, geraram **28 PA em ativações**, 2×2×7, silenciosamente. R22 de baixo nível já recusa `Effect.identifier` duplicado, porém essa verificação não era imposta ao ramo texto do R26.
5. **DEFEITO B REPRODUZIDO no R26 ORIGINAL:** chave de ativação `Pulzo=2` para habilidade `Pulso` foi ignorada, total **11 PA** em lugar dos **17 PA** com chave exata `Pulso=2`, sem alerta; maiúscula alterada e chave extra desconhecida também são risco.
6. **Proteção candidato TEST:** `R02_GATE_ENTRADA_TEST.py` delega cálculos ao R26 imutável e só libera resultado quando os IDs de habilidade não duplicam após normalização e as chaves fornecidas em `usos` correspondem exatamente aos nomes de habilidades extraídas. Caso contrário emite HOLD sem `cenario_pa`, nenhuma soma alternativa. Não é motor nem correção oficial instalada; 0 alteração no R26 original. A revalidação consumidor CRAFT ainda é necessária para usar o gate.
7. **R22 sozinho não é gate de RI/RE:** para RI Bronze + RE Lendário ativa uso=1 produz **55 PA** como número técnico E3, enquanto R26 segura o caso em HOLD. Portanto, integração CRAFT precisa consumir o veredito protegido, não apenas números intermediários sem hierarquia.

**Suíte R02:** após uma fixture de teste inicialmente idêntica que o parser corretamente consolidava, modificou-se apenas a entrada sintética para distinguir dois textos; o FAIL inicial foi preservado no log, sem modificar R26. Suíte final **31/31 métodos PASS**. `R02_REPLAY_COLD.py` extrai a fonte congelada para `tempfile`, verifica hashes/CRC, executa os 31 métodos e compara o JSON refeito byte a byte com `R02_NATIVE_RESULTS.json`: **PASS**. Não contar o replay dos mesmos métodos duas vezes. SHA/CRC totais do pacote e readback da Biblioteca devem constar de verificação posterior ao upload, nunca ser presumidos.

## GATES E ESCOPO

- **VERIFICADO TEST:** fonte original SHA estável, duas falhas do ramo texto reproduzidas, 31/31 métodos PASS, 50/50 cenários cruzados, proteção TEST contra as duas classes, replay frio conforme relatório, consultas Notion read-only.
- **DOCUMENTADO SEM REEXECUÇÃO:** R27→R26 em Notion, 510/510 da R39 histórica, corrigenda CRAFT v1.2 já documentada.
- **PENDENTE:** recuperação do código R27 nativo e/ou validação em ponto de integração real; instalar/adotar proteção em consumidor legítimo somente após permissão/gates, se for necessária, não presumir integração; critérios formais de entrada e aceite CRAFT.
- **HOLD externo:** F5 RED, C19-021 UNKNOWN, receitas físicas RC5/P4, STOP/ACK, writer/lease/epoch CRAFT, 14 revisões independentes 0/14, quatro E0 individuais 0/4 (não bloquear PA geral por default).
- **NÃO ALTERADO:** catálogo canônico, itens/receitas/estoque, fórmulas, fontes R26/R22, custo histórico, Notion, Party, O Primeiro, runtime PROD.

## LAST / FIRST / NEXT / NO-REPEAT

**LAST-VERIFIED:** R02, 31/31 métodos PASS + 50/50 cruzamentos + 2 defeitos reais reproduzidos com proteção TEST + reexecução fria; artefatos R02 conferidos localmente e a preservar na Biblioteca.

**FIRST-PENDING:** R03 — comportamento do **consumidor PA→CRAFT** quando recebe descrições compostas, habilidades homônimas, erros de chave de usos e classificação RI/RE incompatível. A proteção R02 ainda é TEST local, não foi instalada.

**NEXT:** (1) recuperar R02 pela Biblioteca e comparar bytes/hash; (2) localizar *somente se disponível* o adaptador original R27 ou o pacote CRAFT v1.2, nunca reescrever motor; (3) criar/testar contratos de consumo da entrada corrigida e reconciliação com os recibos históricos Pingente 12/dia+7/uso e Botas 18/dia+5/uso; (4) qualificar como READ-ONLY/TEST se não houver writer CRAFT e separar cálculos prospectivos de prova de fabricação; (5) registrar evidência e preparar R04. Se bloqueado em integração real, prosseguir em trabalho independente seguro, não abrir novo motor.

**NO-REPEAT:** não duplicar R01 de 232 métodos; não renomear/homologar R26; não reabrir tarifa Mestre 50/60; não transformar review RE 0/14 ou E0 0/4 em bloqueador universal; não repetir R66–R71 visual; não anunciar REC/CRAFT PROD GREEN sem gate.

## PSV E NAC-PASS PROPORCIONAL

Esta rodada demonstrou apenas TEST/cálculo e fail-closed local. **NAC-PASS TEST** de 31/31 e cold replay; **PROMOÇÃO DE GATE, CRAFT PROD, writer, alterações no Notion e classificação E0** NÃO AUTORIZADAS. Se arquivo Biblioteca não for conferido por readback, persistência externa = PENDENTE, não PASS.
