import unittest,json,copy,hashlib,pathlib
from src.case_guard_r61 import verify_e353
p=pathlib.Path(__file__).resolve().parents[1]
a=json.loads((p/'evidence/R61_CASE_FILE.json').read_text())
class R61Case(unittest.TestCase):
 def test_01_clean_case_pass(self):self.assertEqual(verify_e353(a)['status'],'PASS_E353_CHAIN_TEST_HOLD_PROD')
 def test_02_no_E0(self):self.assertEqual(verify_e353(a)['adjudicated_RE_E0'],0)
 def test_03_no_PA(self):self.assertIsNone(verify_e353(a)['official_pa'])
 def test_04_no_party(self):self.assertFalse(verify_e353(a)['party_write'])
 def test_05_no_notion(self):self.assertFalse(verify_e353(a)['notion_write'])
 def test_06_no_production(self):self.assertEqual(verify_e353(a)['production'],'HOLD')
 def test_07_img_sha(self):self.assertEqual(hashlib.sha256((p/'evidence/TEC-E3532F6A98AC-original.jpg').read_bytes()).hexdigest(),a['original_image_sha256'])
 def test_08_legacy_rank_is_not_e0(self):self.assertEqual(a['nominal_rank_not_effect_RE'],'Ouro Negro');self.assertIsNone(a['canonical_RE'])
 def test_09_not_action_reaction(self):self.assertFalse(a['original_mecanics_verified_visually_2026_10_22']['source_activation_reaction'])
 def test_10_R45_historical_misread(self):self.assertEqual(a['r45_unamended_activation'],'reação')
 def test_11_R46_correction_actual(self):self.assertEqual(a['r46_actual_correction']['visually_verified_value'],'ação')
 def test_12_R47_result_only_candidate(self):self.assertEqual(a['r47_portability']['native_action_candidate_test_only'],'Ação Padrão')
 def test_13_R47_native_action_unapproved(self):self.assertIsNone(a['r47_portability']['native_action_authorized'])
 def test_14_only_weapon_attacks(self):self.assertEqual(a['original_mecanics_verified_visually_2026_10_22']['restricted_to'],'ataques com armas')
 def test_15_damage_type_census(self):self.assertEqual(len(a['original_mecanics_verified_visually_2026_10_22']['damage_types']),3)
 def test_16_visual_foreign_level_not_RE(self):self.assertEqual(a['original_mecanics_verified_visually_2026_10_22']['foreign_source_level'],'TRUQUE')
 def test_17_epoch_provenance(self):self.assertEqual(a['source_page_last_edited_at'],'2026-10-03T12:42:06.902Z')
 def test_18_mutation(self):
  d=copy.deepcopy(a);d['case']='TEC-OTHER';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_19_mutation(self):
  d=copy.deepcopy(a);d['canonical_RE']='Prata';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_20_mutation(self):
  d=copy.deepcopy(a);d['authorized_pa']=10;self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_21_mutation(self):
  d=copy.deepcopy(a);d['authority']='Mestre assinou';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_22_mutation(self):
  d=copy.deepcopy(a);d['source_img_match_R45']=False;self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_23_mutation(self):
  d=copy.deepcopy(a);d['r45_unamended_activation']='ação';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_24_mutation_nested(self):
  d=copy.deepcopy(a);d['original_mecanics_verified_visually_2026_10_22']['activation']='1 REAÇÃO';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_25_mutation_nested(self):
  d=copy.deepcopy(a);d['original_mecanics_verified_visually_2026_10_22']['duration']='2 RODADAS';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_26_mutation_nested(self):
  d=copy.deepcopy(a);d['original_mecanics_verified_visually_2026_10_22']['source_activation_reaction']=True;self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_27_mutation_nested(self):
  d=copy.deepcopy(a);d['r47_portability']['native_playable']=True;self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_28_mutation_nested(self):
  d=copy.deepcopy(a);d['r47_portability']['native_pa_cost']=18;self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_29_mutation_nested(self):
  d=copy.deepcopy(a);d['r47_portability']['native_action_candidate_test_only']='Reação';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_30_mutation_nested(self):
  d=copy.deepcopy(a);d['original_mecanics_verified_visually_2026_10_22']['restricted_to']='todos ataques';self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')
 def test_31_mutation_nested(self):
  d=copy.deepcopy(a);d['original_mecanics_verified_visually_2026_10_22']['damage_types']=['concussao'];self.assertEqual(verify_e353(d)['status'],'HOLD_E353_CORRECTION_OR_AUTHORITY')

if __name__=="__main__":unittest.main()
