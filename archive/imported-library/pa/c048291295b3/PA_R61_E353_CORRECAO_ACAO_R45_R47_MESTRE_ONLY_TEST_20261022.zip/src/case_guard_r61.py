"""Source-correction gate only; no effect-rank, PA or production authority."""
def verify_e353(row):
 reasons=[]
 if row.get('case')!='TEC-E3532F6A98AC':reasons.append('WRONG_CASE')
 f=row.get('original_mecanics_verified_visually_2026_10_22') or {}
 if f.get('activation')!='1 AÇÃO':reasons.append('ACTION_SOURCE_INCORRECT')
 if f.get('duration')!='1 RODADA':reasons.append('DURATION_SOURCE_INCORRECT')
 if f.get('source_activation_reaction') is not False:reasons.append('FAKE_REACTION_PREMIUM')
 if row.get('r45_unamended_activation')!='reação':reasons.append('R45_HISTORY_LOST')
 c=row.get('r46_actual_correction') or {}
 if c.get('previous_R45_value')!='reação' or c.get('visually_verified_value')!='ação':reasons.append('R46_CORRECTION_MISSING')
 p=row.get('r47_portability') or {}
 if p.get('source_activation')!='ação' or p.get('native_action_candidate_test_only')!='Ação Padrão':reasons.append('R47_NOT_CONSISTENT')
 if p.get('native_action_authorized') is not None or p.get('native_RE') is not None or p.get('native_pa_cost') is not None or p.get('native_playable') is not False:reasons.append('UNAUTHORIZED_R47_PROMOTION')
 if row.get('canonical_RE') is not None or row.get('authorized_pa') is not None or row.get('authority') is not None:reasons.append('UNAUTHORIZED_E0_OR_PA_PROMOTION')
 if row.get('source_img_match_R45') is not True:reasons.append('SOURCE_INTEGRITY_MISSING')
 if f.get('restricted_to')!='ataques com armas':reasons.append('SCOPE_NOT_PRESERVED')
 if len(set(f.get('damage_types') or []))!=3:reasons.append('DEFENSE_TYPE_SCOPE_CHANGED')
 return {'status':'PASS_E353_CHAIN_TEST_HOLD_PROD' if not reasons else 'HOLD_E353_CORRECTION_OR_AUTHORITY','issues':sorted(set(reasons)),
 'adjudicated_RE_E0':0,'official_pa':None,'production':'HOLD','notion_write':False,'party_write':False}
