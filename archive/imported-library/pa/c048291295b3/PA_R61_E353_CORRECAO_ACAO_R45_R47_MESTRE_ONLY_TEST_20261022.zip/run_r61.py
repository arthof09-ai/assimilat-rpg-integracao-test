import subprocess,sys,json
from pathlib import Path
p=Path(__file__).resolve().parent
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r61.py','-q'],cwd=p,capture_output=True,text=True,timeout=60)
if r.returncode or 'Ran 31 tests' not in r.stderr:raise RuntimeError(r.stderr[-3200:])
print(json.dumps({'status':'PASS_R61_E353_CORRECTION_HOLD_RE','tests_new':31,'R45_wrong_reaction_replayed':True,'R46_visual_acao_verified':True,'R47_native_candidate_acao_padrao':True,'native_action_adjudicated':False,'E0_effect_re_adjudicated':False,'production':'HOLD','party_write':0,'notion_write':0},sort_keys=True))
