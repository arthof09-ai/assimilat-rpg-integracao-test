import unittest,zipfile,io,json,csv,hashlib,copy,pathlib,tempfile
from src.peer14_gate_r60 import check
ROOT=pathlib.Path(__file__).resolve().parents[1]
P=ROOT/'PA_R60_PEER14_CEGO_SEM_GABARITO_MESTRE_ONLY_TEST_20261022.zip'
MASTER=json.loads((ROOT/'evidence/R60_NOTION_LIVE_READBACK_14_MASTER_ONLY.json').read_text())
REG=MASTER['records'];PEER12=MASTER['peer12_ids_excluded']
def mutated(update):
 with zipfile.ZipFile(P) as z:payload={n:z.read(n) for n in z.namelist()}
 update(payload)
 from tempfile import NamedTemporaryFile
 tmp=NamedTemporaryFile(suffix='.zip')
 with zipfile.ZipFile(tmp.name,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in payload.items():z.writestr(n,b)
 return tmp
class R60Gate(unittest.TestCase):
 def test_001_valid_peer14_is_not_E0(self):
  x=check(P,REG,PEER12);self.assertEqual(x['status'],'FORM_BLIND_READY_NOT_SENT');self.assertEqual(x['adjudicated_RE_E0'],0)
 def test_002_no_external_review(self):self.assertFalse(check(P,REG,PEER12)['independent_peer_review_received'])
 def test_003_zero_authoritative_pa(self):self.assertIsNone(check(P,REG,PEER12)['authoritative_PA'])
 def test_004_no_party_write(self):self.assertFalse(check(P,REG,PEER12)['party_write'])
 def test_005_no_notion_write(self):self.assertFalse(check(P,REG,PEER12)['notion_write'])
 def test_006_14_master_sources(self):self.assertEqual(len(REG),14)
 def test_007_unique_master_ids(self):self.assertEqual(len({x['notion_page_id'] for x in REG}),14)
 def test_008_source_origin_r47_r46(self):self.assertTrue(all('R47' in x['source_original_from'] for x in REG))
 def test_009_different_original_masked_sha(self):self.assertTrue(all(x['source_original_sha256']!=x['source_masked_sha256'] for x in REG))
 def test_010_no_claim_E0(self):self.assertTrue(all(x['effect_RE_E0'] is None for x in REG))
 def test_011_no_peer_receipts(self):self.assertTrue(all(x['independent_review_received'] is False for x in REG))
 def test_012_peer12_disjoint(self):self.assertFalse({x['case_id'] for x in REG}&set(PEER12))
 def test_013_complete_26_source(self):self.assertEqual(len(REG)+len(PEER12),26)
 def test_014_sealed_labels_only_master(self):
  with zipfile.ZipFile(P) as z:
   s=z.read('PEER14_BLIND_ASSIGNMENT.json').decode()
  self.assertNotIn('historical_nominal_technique_rank',s)
 def test_015_source_title_rank_sealed(self):self.assertTrue(all(x['historical_nominal_technique_rank_not_RE'] in ('Bronze','Prata','Ouro') for x in REG))
 def test_016_masked_cases_sha_match(self):
  with zipfile.ZipFile(P) as z:
   x=json.loads(z.read('PEER14_BLIND_ASSIGNMENT.json'))
   self.assertTrue(all(hashlib.sha256(z.read(r['source_image'])).hexdigest()==r['image_sha256'] for r in x['records']))
 def test_017_no_oracle_in_csv(self):
  with zipfile.ZipFile(P) as z:rows=list(csv.reader(io.StringIO(z.read('FORMULARIO_CEGO_14.csv').decode())))
  self.assertTrue(all(not any(v.strip() for v in r[1:]) for r in rows[1:]))
 def test_018_exact_14_jpg(self):
  with zipfile.ZipFile(P) as z:self.assertEqual(sum(n.endswith('.jpg') for n in z.namelist()),14)
 def test_019_manifests_not_answer_keys(self):
  with zipfile.ZipFile(P) as z:self.assertNotIn('MASTER',str(z.namelist()).upper())
 def test_020_json_no_legacy_ranks(self):
  with zipfile.ZipFile(P) as z:s=z.read('PEER14_BLIND_ASSIGNMENT.json').decode()
  self.assertNotIn('Prata',s);self.assertNotIn('Bronze',s)
 def test_021_no_answer_csv_on_source(self):
  with zipfile.ZipFile(P) as z:s=z.read('FORMULARIO_CEGO_14.csv').decode()
  self.assertNotIn('Repreensão Infernal',s)
 def test_022_file_crc(self):
  with zipfile.ZipFile(P) as z:self.assertIsNone(z.testzip())
 def test_023_priority_queue_complete(self):self.assertEqual(len(json.loads((ROOT/'evidence/R60_R47_QUEUE_READBACK.json').read_text())['queue']),14)
 def test_024_peer12_original_not_modified(self):self.assertEqual(len(PEER12),12)
 def test_025_original_source_files_present(self):self.assertEqual(len(list((ROOT/'sources_original_mestre').glob('*.jpg'))),14)
 def test_026_original_source_hashes(self):
  for r in REG:
   b=(ROOT/'sources_original_mestre'/f"{r['case_id']}.jpg").read_bytes()
   self.assertEqual(hashlib.sha256(b).hexdigest(),r['source_original_sha256'])
 def test_027_master_url_matches_id(self):self.assertTrue(all(x['notion_page_url'].endswith(x['notion_page_id']) for x in REG))
 def test_028_not_exhaustive_integrality(self):self.assertEqual(MASTER['notion_document_full_integrity'],'UNKNOWN')
 def test_029_no_declaration_of_peer(self):self.assertEqual(json.loads((ROOT/'evidence/R60_R47_QUEUE_READBACK.json').read_text())['peer14_status'],'NOT_SENT_NOT_RECEIVED_NOT_E0')
 def test_030_no_actual_production(self):self.assertEqual(check(P,REG,PEER12)['production'],'HOLD')
 def test_031_answers_do_not_grant_E0(self):self.assertEqual(check(P,REG,PEER12,answers=[{'rank':'Ouro'}])['adjudicated_RE_E0'],0)
 def test_032_unknown_authority_external(self):self.assertIsNone(check(P,REG,PEER12,answers=[{}])['authoritative_PA'])
 def test_033_source_count_mismatch_holds(self):self.assertEqual(check(P,REG[:-1],PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_034_overlap_with_first12_holds(self):self.assertEqual(check(P,REG,PEER12+[REG[0]['case_id']])['status'],'HOLD_R60_BLIND_PACK')
 def test_035_ids_no_dup_with_original_queue(self):self.assertEqual(len({x['case_id'] for x in REG}),14)
 def test_036_mutation_ranks(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['legacy_rank']='Ouro'
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_037_mutation_id_repeat(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][1]['case_id']=data['records'][0]['case_id']
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_038_mutation_image_missing(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   del payload[data['records'][0]['source_image']]
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_039_mutation_sha_wrong(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['image_sha256']='1'*64
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_040_mutation_blank_rank(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['rank_proposal_test_only']='Prata'
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_041_mutation_answer_prefill(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   rows=list(csv.reader(io.StringIO(payload['FORMULARIO_CEGO_14.csv'].decode())));rows[1][3]='Ataque';out=io.StringIO();csv.writer(out).writerows(rows);payload['FORMULARIO_CEGO_14.csv']=out.getvalue().encode()
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_042_mutation_wrong_count(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'].pop()
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_043_mutation_source_ref(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['source_image']='IMAGENS_SEM_GABARITO/missing.jpg'
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_044_mutation_csv_delete(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   rows=list(csv.reader(io.StringIO(payload['FORMULARIO_CEGO_14.csv'].decode())));out=io.StringIO();csv.writer(out).writerows(rows[:-1]);payload['FORMULARIO_CEGO_14.csv']=out.getvalue().encode()
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_045_mutation_modulo_illegal(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['notion_page_url']='https://app.notion.com/p/example'
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_046_mutation_title_leak(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['description']='Bronze e Prata'
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')
 def test_047_mutation_verdict(self):
  def modify(payload):
   data=json.loads(payload['PEER14_BLIND_ASSIGNMENT.json'])
   data['records'][0]['verdict']='Bronze'
   payload['PEER14_BLIND_ASSIGNMENT.json']=json.dumps(data,ensure_ascii=False).encode()
  with mutated(modify) as tmp:self.assertEqual(check(tmp.name,REG,PEER12)['status'],'HOLD_R60_BLIND_PACK')

if __name__=="__main__":unittest.main()
