import unittest,json,subprocess,sys,zipfile,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r60.py','-q'],cwd=root,capture_output=True,text=True,timeout=60)
if r.returncode or 'Ran 47 tests' not in r.stderr:raise RuntimeError(r.stderr[-3000:])
print(json.dumps({'status':'PASS_R60_PEER14_PREPARATION','new_tests':47,'source_notion_pages_read_this_turn':14,'original_jpegs_sha_checked':14,'masked_jpegs_sha_checked':14,'prior_peer12_preserved':12,'external_reviewer_received':False,'E0_adjudicated':0,'production':'HOLD','party_write':0,'notion_write':0},sort_keys=True))
