# R72 — ERRATA ADITIVA de R69: caminho de proveniência agora demonstrado

**Correção expressa:** o R69 encontrou 4/4 divergências reais entre propostas R45 e R57, mas errou ao tratar a ausência dos nomes nos **20 arquivos do núcleo PA R26** como sinal de atribuição de R57 não comprovada. O R26 **recebe descrições dinamicamente**. Nas cópias históricas do R53 existem `fixtures/four_cases.json`, `outputs/r50_results.json` e `outputs/r52_gateway_four_cases.json`, onde as quatro consultas, seus pareceres R26 e fontes relativas estão registradas. O runner R53 original foi reexecutado e passou em 118/118 execuções de testes. A análise R69 é preservada como histórico; a conclusão sobre ausência de origem é **SUBSTITUÍDA** por este readback, sem inventar nova autoridade.

| Efeito | R45 visual (TEST) | Parecer R26 via R50/R52 (TEST) | R57 cita | E0/PA oficial |
|---|---|---|---|---|
| Repreensão Infernal | Bronze | Prata | Prata | HOLD |
| Orbe Cromática | Prata | Bronze | Bronze | HOLD |
| Vínculo Com a Besta | Prata | Bronze | Bronze | HOLD |
| Toque Chocante | Prata | Bronze | Bronze | HOLD |

**O que continua PENDENTE:** os dois caminhos produzem pareceres TEST diferentes, sem comparadores isolados E0 homologados, sem decisão do Mestre e sem novos custos autorizados. O rótulo Ouro/Ouro Negro das fichas antigas não é autorização para transferir rank ao subefeito.

**Ação na sucessão:** ao consultar R69 ou checkpoint R68–R71, carregar esta errata R72 como evidência complementar obrigatória. Não apagar os artefatos nem repetir investigação da origem R26. A pendência científica é determinar qual RE da versão exata é válido com autoridade Atlas, NÃO localizar a execução R26, que foi recuperada. Biblioteca Mestre apenas, escrita no LAB Notion segue bloqueada; Party/O Primeiro NO-WRITE.
