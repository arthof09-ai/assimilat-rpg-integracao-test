import unittest,tempfile,copy,json,os
from pathlib import Path
from validate_r72 import check
DOC=Path(__file__).resolve().parent/'R72_CORRECTED_PROVENANCE_MESTRE_ONLY.json'
ROOT=Path(os.environ.get('PA_SOURCE_ROOT','/mnt/data/pa_sucessao'))
class T(unittest.TestCase):
 def setUp(self):self.doc=json.loads(DOC.read_text())
 def mutate(self,cb):
  j=copy.deepcopy(self.doc);cb(j)
  with tempfile.TemporaryDirectory() as tmp:
   f=Path(tmp)/'doc.json';f.write_text(json.dumps(j,ensure_ascii=False));return check(f,ROOT)
 def test_positive(self):self.assertTrue(check(DOC,ROOT)['status'].startswith('PASS'))
 def test_four_source_records(self):self.assertEqual(len(self.doc['records']),4)
 def test_four_own_R45(self):self.assertEqual(sum(r['r45_vs_r26_path_conflict'] for r in self.doc['records']),4)
 def test_zero_E0(self):self.assertEqual(sum(r['effect_RE_E0'] is not None for r in self.doc['records']),0)
 def test_negative_wrong_R50_candidate(self):self.assertIn('PROVENANCE',self.mutate(lambda j:j['records'][0].update(r50_native_r26_advisory_TEST='Ouro'))['reason'])
 def test_negative_wrong_R52_candidate(self):self.assertIn('PROVENANCE',self.mutate(lambda j:j['records'][0].update(r52_native_r26_advisory_TEST='Lendário'))['reason'])
 def test_negative_wrong_R57(self):self.assertIn('PROVENANCE',self.mutate(lambda j:j['records'][0].update(r57_attribution_TEST='Prata' if j['records'][0]['r57_attribution_TEST']!='Prata' else 'Bronze'))['reason'])
 def test_negative_fake_PA(self):self.assertIn('FAKE',self.mutate(lambda j:j['records'][0].update(authorized_PA=100))['reason'])
 def test_negative_fake_peer(self):self.assertIn('FAKE',self.mutate(lambda j:j['records'][0].update(independent_peer_14_result='APPROVED'))['reason'])
 def test_negative_false_closure(self):self.assertIn('GATE',self.mutate(lambda j:j['gates'].update(R69_conclusion_on_unproven_attribution_superseded=False))['reason'])
 def test_negative_missing_record(self):self.assertIn('FOUR',self.mutate(lambda j:j['records'].pop())['reason'])
 def test_no_production(self):self.assertEqual(self.doc['gates']['production'],'HOLD')
if __name__=='__main__':unittest.main(verbosity=2)
