"""Fixed archival source reconciliation only. R72 addendum supersedes R69 provenance inference."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json
ROOT=Path('/mnt/data/pa_sucessao')
SOURCE={
 'R53':('PA_R53_SUCESSAO_FRESCOR_13_FONTES_MESTRE_ONLY_TEST_20261022.zip','e0c5cb5fe0c7dad0a8d39bd0fe23bd199a9687ea48f097bf5a7ed6eab6705738'),
 'R57':('PA_R57_DOSSIER_E0_AUTHORITY_MESTRE_ONLY_TEST_20261022.zip','bfba9afe9b0c6e02411c11abcaf6aec5c90b23a2d382e7656ce4edb6efa5b22e'),
 'R47':('sources/PA_R47_ROBUSTEZ_PA_CRAFT_MESTRE_ONLY_TEST_20261021.zip','ec59d0f7f5916b74cc9b673398a2c890f762824bd1936eaf495598e5ab79b510'),
 'R69':('PA_R69_R45_R57_PROVENIENCIA_DISCORDANTE_MESTRE_ONLY_TEST_20261022.zip','a599fd7928284173c0e817b65e482f7850ee8de57881663e12fba8b6f20346bc')}
def deny(r):return {'status':'HOLD_R72_ARCHIVE_PROVENANCE','reason':r,'E0':0,'PA':None,'notion_write':False}
def check(dossier,root=ROOT):
 try:
  d=json.loads(Path(dossier).read_text())
  sources={}
  for n,(path,sha) in SOURCE.items():
   p=root/path
   if hashlib.sha256(p.read_bytes()).hexdigest()!=sha:return deny('SOURCE_HASH_'+n)
   sources[n]=p
  with ZipFile(sources['R53']) as z:
   fixtures={r['case_id']:r for r in json.loads(z.read('fixtures/four_cases.json'))['cases']}
   r50={r['case_id']:r for r in json.loads(z.read('outputs/r50_results.json'))['cases']}
   r52={r['case_id']:r for r in json.loads(z.read('outputs/r52_gateway_four_cases.json'))['records']}
  with ZipFile(sources['R57']) as z:r57={r['case_id']:r for r in json.loads(z.read('R57_ADJUDICATION_DOCKET.json'))['cases']}
  with ZipFile(sources['R47']) as z:r45={r['case_id']:r for r in json.loads(z.read('input/REFERENCE_R45_INPUT/CORPUS_MECANICO_MANUAL_CEGO.json'))['cases']}
  records=d.get('records',[])
  if len(records)!=4 or {r['case_id'] for r in records} != set(fixtures):return deny('FOUR_CASES')
  if d.get('gates')!={'r26_path_evidenced_records':4,'r45_vs_r26_test_differences':4,'R69_conclusion_on_unproven_attribution_superseded':True,'E0_adjudicated':0,'authorized_PA':None,'peer14_answers':0,'notion_write':False,'party_write':False,'production':'HOLD'}:return deny('GATE_CLAIM')
  for r in records:
   cid=r['case_id'];f=fixtures[cid];p=r50[cid];q=r52[cid];rv=r57[cid];s=r45[cid]
   candidates=[f['peer'],p['native_advisory_summary'][0]['candidate'],q['native_r26_outputs'][0]['proposed_rank_native'],rv['native_R26_proposal_TEST_ONLY']]
   if len(set(candidates))!=1:return deny('UPSTREAM_CANDIDATE_CONFLICT')
   if len(set([f['R45'],s['rank_proposal_test_only']]))!=1 or f['R45']==f['peer']:return deny('R45_LINEAGE_BAD')
   fields={'name':f['ability'],'r45_visual_rank_TEST':f['R45'],'r50_frozen_peer_candidate_TEST':f['peer'],
    'r50_native_r26_advisory_TEST':candidates[1],'r52_native_r26_advisory_TEST':candidates[2],
    'r57_attribution_TEST':candidates[3]}
   for key,v in fields.items():
    if r.get(key)!=v:return deny('PROVENANCE_TAMPER_'+key)
   if r.get('native_r26_engine_confidence')!=q['native_r26_outputs'][0]['native_confidence']:return deny('CONFIDENCE_TAMPER')
   if not r.get('r45_vs_r26_path_conflict') or r.get('isolated_e0_comparators')!=0:return deny('RANK_CONFLICT_OR_AUTHORITY')
   if any(r.get(k) is not None for k in ['effect_RE_E0','authorized_PA','independent_peer_14_result']):return deny('FAKE_E0_OR_PA_OR_PEER')
   if q['isolated_E0_comparators']!=0 or p['canonical_RE'] is not None or q['canonical_RE'] is not None:return deny('UPSTREAM_E0_CHANGED')
  return {'status':'PASS_R72_R26_PROVENANCE_RECOVERED','four_R26_advisory_outputs_evidenced':4,
   'R45_R26_distinct_tests':4,'R69_prior_source_inference_superseded':True,
   'r53_r52_r26_no_E0':True,'effect_E0':0,'PA_authorized':None,'production':'HOLD','notion_write':False,'party_write':False}
 except (ValueError,KeyError,IndexError,TypeError,OSError) as e:return deny('INVALID_'+type(e).__name__)
