"""Preflight mecânico cego sem gabarito. TEST.
Só admite imagem de fonte Mestre com bytes locais e redaction attestation manual.
Um URL temporário NÃO equivale a bytes. Nenhum rank é inferido do nome do arquivo.
"""
import json,hashlib,io
from pathlib import Path
from PIL import Image,ImageDraw

class BlindGateError(ValueError):pass
def sha(b):return hashlib.sha256(b).hexdigest()

def intake_image(image_path, out_dir, opaque_id, source_reference, redact_rects, attested=False):
    if not attested:raise BlindGateError('revisão humana de legenda/nome/preço/rank ausente')
    if not opaque_id or not source_reference.startswith('notion-file-block://'):
        raise BlindGateError('identidade de fonte inadequada')
    b=Path(image_path).read_bytes()
    try:
        im=Image.open(io.BytesIO(b));im.verify()
        im=Image.open(io.BytesIO(b)).convert('RGB')
    except Exception as e: raise BlindGateError('imagem ilegível') from e
    if not redact_rects:raise BlindGateError('redactions ausentes: não provar ausência de gabarito')
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    clean=im.copy();draw=ImageDraw.Draw(clean)
    for rect in redact_rects:
        if len(rect)!=4 or not (0<=rect[0]<rect[2]<=im.width and 0<=rect[1]<rect[3]<=im.height):
            raise BlindGateError('redaction fora do quadro')
        draw.rectangle(tuple(rect), fill=(0,0,0))
    p=out/(opaque_id+'.png')
    clean.save(p,format='PNG')
    metadata={'opaque_id':opaque_id,'raw_sha256':sha(b),'redacted_sha256':sha(p.read_bytes()),'width':im.width,'height':im.height,
              'redaction_count':len(redact_rects),'attested':True,'source_reference_sha256':sha(source_reference.encode()),
              'rank':None,'mechanics_verified':False,'ready_for_prediction':False}
    (out/(opaque_id+'.json')).write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    return metadata

def freeze_predictions(predictions, p):
    if not predictions:raise BlindGateError('sem previsões')
    if any('gold' in str(k).lower() or 'official' in str(k).lower() for row in predictions for k in row.keys()):
        raise BlindGateError('gabarito na previsão')
    for row in predictions:
        if row.get('rank_pred') not in ('Bronze','Prata','Ouro','Ouro Negro','Lendário'):
            raise BlindGateError('rank estimado inválido')
        if not row.get('mechanics_sha256') or not row.get('transcription_verified'):
            raise BlindGateError('mecânica não autenticada')
    data={'kind':'TEST_FROZEN_BLIND_PREDICTIONS','n':len(predictions),'predictions':predictions}
    b=json.dumps(data,sort_keys=True,ensure_ascii=False).encode('utf-8')
    data['freeze_sha256']=sha(b)
    Path(p).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    return data['freeze_sha256']

def score_only_after_freeze(p,gold):
    d=json.loads(Path(p).read_text(encoding='utf-8'))
    s={k:v for k,v in d.items() if k!='freeze_sha256'}
    if sha(json.dumps(s,sort_keys=True,ensure_ascii=False).encode('utf-8'))!=d['freeze_sha256']:
        raise BlindGateError('previsão foi alterada')
    unique={x['opaque_id']:x for x in d['predictions']}
    eligible=[(unique[k],v) for k,v in gold.items() if k in unique and v in ('Bronze','Prata','Ouro','Ouro Negro','Lendário')]
    if not eligible:return {'eligible':0,'accuracy':None,'correct':0}
    correct=sum(x['rank_pred']==rank for x,rank in eligible)
    return {'eligible':len(eligible),'correct':correct,'accuracy':correct/len(eligible)}
