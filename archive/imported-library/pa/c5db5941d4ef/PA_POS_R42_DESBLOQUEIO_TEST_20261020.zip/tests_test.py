import unittest,tempfile
from pathlib import Path
from fencing_test import FencedTestGateway,FenceDenied
from blind_intake_test import intake_image,freeze_predictions,score_only_after_freeze,BlindGateError
from PIL import Image

class FenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.g=FencedTestGateway(Path(self.tmp.name)/'gate.db')
    def tearDown(self):self.tmp.cleanup()
    def test_epoch_increments(self):
        a,_=self.g.acquire('executor-antigo');b,_=self.g.acquire('executor-novo');self.assertEqual(b,a+1)
    def test_stale_rejected(self):
        a,t=self.g.acquire('executor-antigo');b,u=self.g.acquire('executor-novo')
        with self.assertRaises(FenceDenied):self.g.write('executor-antigo',a,t,'PATCH','NO')
        self.assertEqual(self.g.state()[2],0)
        self.assertEqual(self.g.write('executor-novo',b,u,'TEST','YES'),1)
    def test_wrong_token_denied(self):
        a,t=self.g.acquire('owner')
        with self.assertRaises(FenceDenied):self.g.write('owner',a,'FALSO','X','Y')
    def test_wrong_owner_denied(self):
        a,t=self.g.acquire('owner')
        with self.assertRaises(FenceDenied):self.g.write('other',a,t,'X','Y')
    def test_legacy_epoch_denied(self):
        a,t=self.g.acquire('owner')
        with self.assertRaises(FenceDenied):self.g.write('owner',0,t,'X','Y')
    def test_no_writer_by_default(self):
        with self.assertRaises(FenceDenied):self.g.write('',0,'','X','Y')
    def test_version_increments(self):
        a,t=self.g.acquire('owner')
        self.assertEqual(self.g.write('owner',a,t,'X','1'),1)
        self.assertEqual(self.g.write('owner',a,t,'X','2'),2)

class BlindTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)
        Image.new('RGB',(32,32),'white').save(self.path/'sample.png')
        self.ref='notion-file-block://original/file?space_id=orig&name=photo.png'
    def tearDown(self):self.tmp.cleanup()
    def ingest(self,**kwargs):
        base=dict(image_path=self.path/'sample.png',out_dir=self.path/'out',opaque_id='opaque1',source_reference=self.ref,redact_rects=[[0,0,32,5]],attested=True)
        base.update(kwargs);return intake_image(**base)
    def test_intake_success(self):self.assertTrue(self.ingest()['redacted_sha256'])
    def test_intake_no_attestation(self):
        with self.assertRaises(BlindGateError):self.ingest(attested=False)
    def test_intake_without_rect(self):
        with self.assertRaises(BlindGateError):self.ingest(redact_rects=[])
    def test_intake_invalid_rect(self):
        with self.assertRaises(BlindGateError):self.ingest(redact_rects=[[0,0,40,5]])
    def test_intake_invalid_reference(self):
        with self.assertRaises(BlindGateError):self.ingest(source_reference='https://notion.so/test')
    def test_intake_bytes_required(self):
        with self.assertRaises(FileNotFoundError):self.ingest(image_path=self.path/'missing.jpg')
    def test_freeze_no_prediction(self):
        with self.assertRaises(BlindGateError):freeze_predictions([],self.path/'freeze.json')
    def test_freeze_no_verified_mechanics(self):
        with self.assertRaises(BlindGateError):freeze_predictions([{'opaque_id':'x','rank_pred':'Prata'}],self.path/'freeze.json')
    def test_freeze_gold_leak(self):
        with self.assertRaises(BlindGateError):freeze_predictions([{'opaque_id':'x','rank_pred':'Prata','gold_rank':'Bronze','mechanics_sha256':'sha','transcription_verified':True}],self.path/'freeze.json')
    def test_freeze_score(self):
        p=self.path/'freeze.json';freeze_predictions([{'opaque_id':'x','rank_pred':'Prata','mechanics_sha256':'sha','transcription_verified':True}],p)
        self.assertEqual(score_only_after_freeze(p,{'x':'Prata'})['accuracy'],1)
    def test_freeze_score_empty_gold(self):
        p=self.path/'freeze.json';freeze_predictions([{'opaque_id':'x','rank_pred':'Prata','mechanics_sha256':'sha','transcription_verified':True}],p)
        self.assertIsNone(score_only_after_freeze(p,{})['accuracy'])
    def test_freeze_tamper_rejected(self):
        p=self.path/'freeze.json';freeze_predictions([{'opaque_id':'x','rank_pred':'Prata','mechanics_sha256':'sha','transcription_verified':True}],p)
        p.write_text(p.read_text().replace('Prata','Ouro'))
        with self.assertRaises(BlindGateError):score_only_after_freeze(p,{'x':'Prata'})

if __name__=='__main__': unittest.main()
