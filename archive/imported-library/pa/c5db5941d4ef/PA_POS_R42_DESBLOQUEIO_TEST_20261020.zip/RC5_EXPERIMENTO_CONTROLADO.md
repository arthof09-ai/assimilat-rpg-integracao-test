# CRAFT H2 / RC5 — plano de prova material, MESTRE-SIDE

Caso EXISTENTE: LAB-CRAFT-VIGILIA-BOREAL-20261020-001. Pingente da Vigília Boreal v1.3, candidata H2-VB01.

## Resultados herdados (não físicos)
H1: Mestre aceitou retenção de luz intrínseca de Erva Luz Norte/Cristal Aurora, expostas sem obstrução. O suporte não recebe automaticamente poder próprio. H2: fonte ≠ estabilizada ≠ integração de item.
CRAFT pós-E50 25/25 software; H2 engenharia 43/43 software, 0 testemunhas físicas.
P2, BOM: Sal de Geodo Santo; processo: Sal de Geodo Encantado. Energizador Pedra da Luz ou Essência Mágica na BOM, não aplicado em passo processual. Óleo de Vedação tem variantes incompatíveis.
Pa A/B/C ainda `NULL` com incidência não decidida, `0` incorreto.

## Teste MÍNIMO que separa fonte de integração
1. Reconciliar P2 com autoridade: sal e etapa energizador, insumos reais e óleo/lote. Ficha de lote, origem, auditoria.
2. Evidência independente de peça física com duas fontes intactas, documentação da posição, grau de exposição e controle de obstrução. O teste H1 não prova instalação.
3. Controle C0: suporte idêntico SEM fontes/SEM inscrição (baseline de ambiente).
4. Controle C1: fontes colocadas em suporte SEM inscrição P2 (luz intrínseca).
5. Controle C2: fontes colocadas em suporte com inscrição P2 legitimamente executada e testemunhada (testa estabilização, não poder próprio).
6. Controle C3: se existir receita autorizada para habilidade própria, testar padrão instalado com condição de ativação, separado das fontes; sem receita C3 fica HOLD.
7. Medidas emparelhadas por CRAFT/Mestre: luz com fonte presente, luz após retirada de fontes, duração/área/repetibilidade, diferença com C0, C1, C2, e C3. Não definir lux, tempo ou eficiência sem instrumento/autoridade; registrar método e unidades reais.
8. Lógica discriminatória: se C1 e C2 funcionam apenas com fontes, H1 confirmado, H2 própria NÃO; se P2 mantém fonte estável demonstravelmente mais tempo, H2 estabilização sob provas; se C3 manifesta luz/Contrassombra com fontes retiradas e padrão ativo, investigar H2 item próprio e precedência de causa, repetir/medir.
9. Guardar mídia/ata e testemunha datadas, fingerprint/hash, instrumento, controles, fonte canônica, falhas, adversos; avaliar R46/R47 autenticidade e ocorrência certificada.
10. Somente depois compor RC5 com BOM→processo→produto 1:1, PA e gates completos; não marcar materialidade baseada em simulação.

## Evidências necessárias ainda ausentes
- Parecer competente sobre P2 e energia; óleo/lote rastreado.
- Operador e testemunho de ocorrência in-game/TEST; materialização e ato de inscrição.
- Dados comparados C0–C3 e QA discriminatório da habilidade.
- Decisão de custo PA e executor CRAFT competente.
- Fencing técnico, safe-point e canário produtivo.

Responsável pela observação: Mestre/CRAFT. Executor PA não poderá criar retroativamente resultado mágico observado ou assumir writer.
