# Media 26/26 — último obstáculo material

Há 26/26 referências `notion-file-block://` na coleção Mestre. O conector `notion_get_file_download_urls` confirmou 26/26 URLs temporárias resolvidas. Nenhum pixel foi baixado / visualizado no ambiente de código: a saída pública do runtime não possui acesso de rede HTTPS externo (teste HTTPS falhou). **Referência ou URL assinada não é evidência da mecânica**.

## Fluxo seguro exato
1. Abrir as 26 páginas Mestre autorizadas em Notion, usar Baixar no bloco de imagem (ou usar Work/Browser autorizado para exportar as 26 mídias).
2. Guardar arquivos Mestre-only fora do alcance da Party, com mapa page UUID → arquivo no cofre/oráculo.
3. Enviar os arquivos ou ZIP à entrada de TEST; não enviar URL temporária isolada que expira.
4. Executar `blind_intake_test.intake_image` com `source_reference` canônica e `opaque_id`, credencial da mídia autenticada, coordenadas de tarja sobre título/rank/preço/nome, atestado humano. Byte original e tarja ganham hashes separados. **O código sozinho não identifica onde estão todos os rótulos**.
5. Uma pessoa que não acessou rótulos vê só imagem tarjada, transcreve mecânica, assina SHA da transcrição, marca `transcription_verified=True` somente após verificação.
6. Congelar previsões com `freeze_predictions()` em arquivo separado, depois pontuar com `score_only_after_freeze()` e oráculo conservado à parte. Informar elegíveis, coberturas e erros.
7. Acurácia continua NULL com zero exemplos reais.

Opção adicional: recuperar mídia pela GUI de Notion/Cloud Browser em Work mode, mas esta instância não dispõe desse controle de navegador. Não simular OCR nem adivinhar danos/alcances.
