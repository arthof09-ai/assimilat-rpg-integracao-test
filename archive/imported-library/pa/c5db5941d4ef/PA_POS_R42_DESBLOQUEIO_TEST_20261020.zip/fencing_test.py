"""Gate TEST em SQLite: ilustra impedimento de escritor obsoleto APENAS pelo gateway.
Não intercepta MCP Notion e não comprova fencing PROD.
"""
import sqlite3, hashlib, secrets, time
from pathlib import Path

class FenceDenied(Exception): pass

class FencedTestGateway:
    def __init__(self, db):
        self.db=str(db)
        with sqlite3.connect(self.db) as c:
            c.execute("CREATE TABLE IF NOT EXISTS owner (id INTEGER PRIMARY KEY CHECK(id=1), epoch INTEGER NOT NULL, owner TEXT NOT NULL, token_hash TEXT NOT NULL, version INTEGER NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS journal (seq INTEGER PRIMARY KEY, epoch INTEGER, owner TEXT, kind TEXT, content TEXT)")
            c.execute("INSERT OR IGNORE INTO owner (id,epoch,owner,token_hash,version) VALUES (1,0,'','',0)")
    @staticmethod
    def digest(t): return hashlib.sha256(t.encode()).hexdigest()
    def acquire(self, owner):
        if not owner or not owner.strip(): raise ValueError('owner')
        token=secrets.token_urlsafe(32)
        with sqlite3.connect(self.db, isolation_level=None) as c:
            c.execute("BEGIN IMMEDIATE")
            old=c.execute("SELECT epoch FROM owner WHERE id=1").fetchone()[0]
            c.execute("UPDATE owner SET epoch=?,owner=?,token_hash=? WHERE id=1", (old+1,owner,self.digest(token)))
            c.execute("COMMIT")
        return (old+1,token)
    def write(self,owner,epoch,token,kind,content):
        with sqlite3.connect(self.db,isolation_level=None) as c:
            c.execute("BEGIN IMMEDIATE")
            oe,ow,oh,v=c.execute("SELECT epoch,owner,token_hash,version FROM owner WHERE id=1").fetchone()
            if (epoch,owner,self.digest(token)) != (oe,ow,oh):
                c.execute("ROLLBACK");raise FenceDenied('stale-owner-token')
            c.execute("INSERT INTO journal (epoch,owner,kind,content) VALUES(?,?,?,?)",(epoch,owner,kind,content))
            c.execute("UPDATE owner SET version=? WHERE id=1",(v+1,))
            c.execute("COMMIT")
        return v+1
    def state(self):
        with sqlite3.connect(self.db) as c:
            return c.execute("SELECT epoch,owner,version FROM owner WHERE id=1").fetchone()
