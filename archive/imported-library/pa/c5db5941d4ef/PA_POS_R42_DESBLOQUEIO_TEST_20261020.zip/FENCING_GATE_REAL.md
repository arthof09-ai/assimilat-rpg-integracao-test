# FENCING C19 — execução técnica restante

Estado: C19 administrativo REVOGADO; API de escrita Notion compartilhada não exerce CAS/owner/epoch/lease obrigatório.

## O que já se conseguiu
- Autenticação Notion MESTRE funciona para leitura e alterações de página.
- Não existe nas ações expostas um endpoint de revogar a credencial compartilhada nem de terminar uma instância ChatGPT.
- Notion `search_sessions` devolveu `entitlement_required` (plano Business+) e pertence a sessões Custom Agents; não autentica STOP da instância antiga.
- Protótipo `fencing_test.py`: rejeita escritor antigo dentro do seu próprio gateway transacional. Não governa escritas Notion feitas fora desse gateway.

## Caminho de desbloqueio real (operador da conexão)
1. Identificar a instalação Notion e todas as sessões/instâncias com o mesmo token ou OAuth.
2. Obter STOP-ACK com assinatura ou encerramento da instância antiga CM-000002-I0014; anotar safe-point e write-set.
3. Se não houver STOP-ACK, revogar/desconectar a **conexão comprometida**, não apenas registrar a revogação no Notion.
4. Se necessário, emitir credencial exclusiva para novo executor/serviço; não reutilizar o token antigo. Reavaliar compartilhamentos antes de conceder as páginas necessárias.
5. No controlador que será o ÚNICO caminho de mutação, exigir owner + epoch + token não reutilizável + fencing/compare-and-set real. A API Notion genérica, sem esse controlador, não cumpre o requisito.
6. Conferir que a instância antiga recebe 401/403 (ou rejeição demonstrável) em tentativa segura de acesso a recurso TEST de sua alçada; não testar em produção.
7. Com prova técnica, executar delta-check de C19-021 sem replay de efeito incerto, novo claim, canário TEST, TEE, NAC-PASS. Só então novo critério para F5.

Até lá: F5 RED/PROD HOLD; sem escrituras canônicas/estoque.

Fontes oficiais:
https://www.notion.com/help/add-and-manage-connections-with-the-api
https://www.notion.com/help/enterprise-connection-settings
