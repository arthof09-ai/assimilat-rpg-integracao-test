# PA-R48A — Adendo de comparadores próximos e conflito de incidência PA

## Proveniência

Pesquisa direcionada no Notion Mestre efetuada APÓS congelamentos R45 e peer v1.0.0. Esta auditoria não altera propostas anteriores nem obtém novo rank. Nenhuma origem Party/O Primeiro é usada.

### Repreensão Infernal — novo comparador melhor, porém conflitado

Fonte externa real da magia: `TEC-7F4A4B423743` — 1 Reação após sofrer dano, 2d10 fogo em falha de resistência Destreza, metade no êxito, alcance 60 pés. R45 Bronze; peer Prata.

**[Retaliação](https://app.notion.com/p/836c2b324ede83e2aae6016379ef2135)**: item/efeito de arma concede bônus +3 no ataque, +8 dano, e reação para atacar corpo a corpo quem causou dano; vantagem no ataque e ignora resistência a dano; **16 PA por dia** declarado.

**[Tento — 4º Discípulo](https://app.notion.com/p/d3fc2b324ede83c3a1bb01356904ce06)**: ficha registra Bastão (O) com a habilidade chamada Retaliação, descrição semelhante; **16 PA por turno** declarado, além de referência a ignorar imunidade/resistência. **Conflito documental** de taxa e alcance exato de bypass. Não inferir que custo diário e por turno sejam duas formas equivalentes da mesma habilidade; preservar linhagem/versão e pedir decisão técnica pelo NAC-NORM.

**[GÊMEAS ESTRELADAS](https://app.notion.com/p/6f7c2b324ede823b80068113b789aa06)** também registra passiva Retaliação semelhante, sem autoridade para conferir um RE isolado da magia Repreensão. Não confundir título/rank da arma ou ficha de personagem com RE de uma habilidade de reação.

**Conclusão científica:** comparação funcional melhor no gatilho **dano recebido → resposta via Reação**, mas não no mecanismo ofensivo: Retaliação usa ataque físico corpo a corpo e bônus de arma (possível bypass), enquanto Repreensão usa salvaguarda de Destreza, fogo à distância, meio dano garantido e risco de Conjuração. Classificação permanece **Bronze–Prata PENDENTE**, sem alteração do rank congelado de nenhum avaliador.

### Proteção Contra Lâminas — ambiguidade da palavra resistência

**[Anel de Resistência](https://app.notion.com/p/81bc2b324ede8282b47781c7d616708b)**: concede resistência a tipo de dano determinado pelo Mestre e cobra 22 PA/dia, **sem valor numérico de redução apresentado**.

**[Resistência](https://app.notion.com/p/eb6c2b324ede83eaab08812d52473dc1)**: efeito de armadura similar, sem escala quantitativa explícita, caso de outra fonte.

**[Sombra Sussurrante](https://app.notion.com/p/3edc2b324ede812c9b54c261934696e6)**: armadura não classificada com bônus numéricos explícitos (+5 resistência física, +3 mágica no bloco defensivo e outros efeitos); **não transfere** tais números para a palavra genérica resistência de técnica importada.

Isso demonstra uma lacuna documental mais ampla, **não confirma** que a resistência de Proteção Contra Lâminas equivalha a RD fixa, metade de dano ou porcentagem. Há também tensão entre a classificação E0 nominal no Atlas A §18 e a ordem posterior do Mestre de não usar rótulo histórico como gabarito mecânico. Governança: registrar conflito, não editar o Atlas ou declarar acerto retrospectivo.

### Outros comparadores de reação/elemental

**[Selo do Último Refúgio](https://app.notion.com/p/3f5c2b324ede81d0874ed4d96752812c)**: inscrição Lendário, usa Reação e 55 PA por uma única ocorrência, redução de até 60 de dano em até três criaturas. Confirma mecanicamente que Reação, por si só, não define Bronze/Prata/Lendário; QUALIDADE do efeito, número de alvos, custo e uso único são os determinantes. Não usar como analogia direta de Toque Chocante, que **nega Reações** e não reduz dano diretamente.

**[Arco Exterminador Elemental](https://app.notion.com/p/3edc2b324ede8156849bf1aae0ce9fb5)**: item classificado Lendário com dano de arma alto e bônus contra elementais. Não é comparador direto de Orbe Cromática (3d8, escolha exclusiva de um de seis tipos), e não autoriza derivação de Rank de Efeito pela afinidade elemental.

### Resultado e próximos gates

- **VERIFICADO:** novas fontes existentes, custos divergentes de Retaliação, falta de fator de resistência em pelo menos dois efeitos, alternativas funcionais.
- **INFERIDO:** referência de retaliação é mais próxima funcionalmente que mera regra geral de combate, mas não resolve RE isolado.
- **PROPOSTO:** reconciliar dia × turno e bypass antes de usar como benchmark tarifário; buscar homologação de efeitos reativos específicos (não rank do portador).
- **PENDENTE:** quatro RE divergentes, mecanismo nativo de resistência física, PA da magia, controle de versões, adjudicação E353.

*NAC-PASS proporcional*: PASS leitura documental e rastreabilidade; HOLD decisões normativas/eficácia/Rank. Sem alteração de estoque, folha de habilidade, engine PA, CRAFT, Party ou O Primeiro.
