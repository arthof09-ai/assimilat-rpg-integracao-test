# R68 — Reconciliar economia de ações e concentração antes da revisão científica

**Fonte:** 14 cartas mecânicas visuais R60→R66 verificadas, <https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0> (Sistema de Combate), <https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373> (Magia), <https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab> (Atlas).

## Achados materiais

Quatro técnicas trazem explicitamente **1 AÇÃO BÔNUS**, categoria não listada entre as cinco categorias do sistema nativo; oito técnicas têm o marcador **(C)** na duração. Ação-bônus não pode ser automaticamente tratada como Padrão, Movimento, Reação ou Livre; o custo relativo, vantagens por economia de ações e admissibilidade exigem decisão. O marcador (C) não estabelece por si só regra nativa de manutenção/concentração. Uma técnica usa **1 REAÇÃO**, cuja natureza é nativamente reconhecida, mas o gatilho do efeito permanece sujeito a auditoria.

| Caso/ID | Página Mestre | Ação na imagem | Duração na imagem | Gate semântico |
|---|---|---|---|---|
| `TEC-44ACABD04901` | [Saraivada de Espinhos](https://app.notion.com/p/3edc2b324ede81328e2ddeaf4ac3f848) | 1 AÇÃO BÔNUS | ATÉ 1 MIN (C) | HOLD—ação bônus |
| `TEC-4756338D9E0C` | [Golpe Constritor](https://app.notion.com/p/3edc2b324ede816ea8dae4a171d1d467) | 1 AÇÃO BÔNUS | ATÉ 1 MIN (C) | HOLD—ação bônus |
| `TEC-49FDDBE69D38` | [Perdição](https://app.notion.com/p/3edc2b324ede81fab67cd15d31615852) | 1 AÇÃO | ATÉ 1 MIN (C) | HOLD—(C) |
| `TEC-9252C3B2669F` | [Marca do Caçador](https://app.notion.com/p/3edc2b324ede81cda339e07d2ccb64ce) | 1 AÇÃO BÔNUS | ATÉ 1 HORA (C) | HOLD—ação bônus |
| `TEC-9684BAE3174B` | [Golpe de Zephyr](https://app.notion.com/p/3edc2b324ede81c8a686c4740ad5dc57) | 1 AÇÃO BÔNUS | ATÉ 1 MIN (C) | HOLD—ação bônus |
| `TEC-A2802280AAE8` | [Criar Fogueira](https://app.notion.com/p/3edc2b324ede8165a948c6b6c6c9ab62) | 1 AÇÃO | ATÉ 1 MINUTO | Confrontar demais eixos |
| `TEC-F1BD993CFF60` | [Faca de Gelo](https://app.notion.com/p/3edc2b324ede8118a6dce655e4a9b884) | 1 AÇÃO | INSTANTÂNEA | Confrontar demais eixos |
| `TEC-320DB7B56AD0` | [Benção](https://app.notion.com/p/3edc2b324ede81a0a72af24c15df234a) | 1 AÇÃO | ATÉ 1 MIN (C) | HOLD—(C) |
| `TEC-B0D00FDE2408` | [Raio de Fogo](https://app.notion.com/p/3edc2b324ede8136a10ce73a25d04b3a) | 1 AÇÃO | INSTANTÂNEA | Confrontar demais eixos |
| `TEC-1808CAC63847` | [Rajada Mística](https://app.notion.com/p/3edc2b324ede8132b862ce2d6efc860a) | 1 AÇÃO | INSTANTÂNEA | Confrontar demais eixos |
| `TEC-575586E88BE3` | [Lufada](https://app.notion.com/p/3edc2b324ede81559680d84589ccfb0f) | 1 AÇÃO | INSTANTÂNEA | Confrontar demais eixos |
| `TEC-680699BF9999` | [Ataque Certeiro](https://app.notion.com/p/3edc2b324ede81eead95fb791a31b0e0) | 1 AÇÃO | 1 RODADA (C) | HOLD—(C) |
| `TEC-B22F58FD1A83` | [Sentido Bestial](https://app.notion.com/p/3edc2b324ede81319cbaf75263c48326) | 1 AÇÃO | ATÉ 1 HORA (C) | HOLD—(C) |
| `TEC-6B84A461C262` | [Escudo Arcano](https://app.notion.com/p/3edc2b324ede816c8caae26f25e60379) | 1 REAÇÃO | INSTANTÂNEA | Confrontar demais eixos |

**Não é um novo sistema de ações.** O parecer independente ainda não ocorreu (0/14). Rank RE individual E0 e custo PA permanecem HOLD; nenhuma das páginas citadas foi alterada. Este documento revela identidade/títulos: **MESTRE-ONLY, não enviar ao revisor**.

## Resolução mínima para cada carta

1. Identificar a versão mecânica exata do efeito e sua ação/concentração estrangeiras; 2. Registrar, pela autoridade competente e sistema nativo, o tempo de ativação e a necessidade (ou não) de manutenção; 3. Confrontar duração, alcance, alvo, risco, bônus de ação e contraexemplos do Atlas; 4. Separar proposta científica de E0 oficial; 5. Só calcular PA pelo consultor nativo depois de aprovada a versão/RE, preservando PA legado.
