# PA R68 — Economia de ações estrangeira e concentração, sem converter regras

MESTRE-SIDE / TEST / READONLY. Não é produção, não instala efeitos nem homologa rank.

## Resultado comprovado
Leitura visual humana dos 14 PNGs R66 derivada de imagens antigas R60: 4/14 cartas têm a marca `1 AÇÃO BÔNUS` (sem mapeamento nativo conhecido), 8/14 duração `(C)` (sem decisão sobre manutenção/concentração nativa), 1/14 `1 REAÇÃO`, 9/14 `1 AÇÃO` (sem assumir automaticamente que equivalem à regra geral de conjuração na versão de Assimilação).

O Sistema de Combate canônico lista Padrão, Movimento, Reação, Livre e Completa; o Sistema de Magia define Padrão como padrão se nenhum outro tempo for informado. Entretanto, a carta estrangeira **informa** ação bônus em 4 casos; não é possível descartá-la silenciosamente. O Atlas requer análise da economia de ações, duração, limites e risco antes de classificar.

## Reproduzir testes a frio
Este pacote não duplica os ~9,8MB do artefato anterior. Obtenha o R66 técnico original e execute, em diretório isolado:

```
R66_TECHNICAL_ARCHIVE=/caminho/PA_R66_CARTOES_MECANICOS_NEUTROS_MESTRE_ONLY_TEST_20261022.zip python tests_r68.py
```

O próprio validador confere SHA completo do R66, a tabela R60 congelada, 14/14 identidades e os campos científicos `NULL`. A inspeção visual humana é evidência da transcrição, **não** derivada de OCR ou comprovada numericamente apenas pela suíte. O pacote contém o nome real dos 14 itens do corpus, portanto é **MESTRE-ONLY**, inadequado para o revisor cego.

## Gates
0/14 pareceres externos, 0/14 RE individuais E0, 0 custos PA oficiais novos, 0 escritos Notion/Party/O Primeiro. Registro R64–R67 continua pendente no Notion por bloqueio de segurança; não repetir escrita por outra rota. A entrega de código de teste é PASS proporcional apenas após 20/20 e hashes, nunca gate de produção.
