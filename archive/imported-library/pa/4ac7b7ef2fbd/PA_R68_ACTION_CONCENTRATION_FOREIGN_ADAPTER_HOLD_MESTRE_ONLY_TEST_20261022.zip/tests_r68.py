import copy,json,tempfile,unittest,os
from pathlib import Path
from validate_r68 import check,DOC,SOURCE
R66=Path(os.environ.get('R66_TECHNICAL_ARCHIVE',Path(__file__).resolve().parent.parent/'PA_R66_CARTOES_MECANICOS_NEUTROS_MESTRE_ONLY_TEST_20261022.zip'))
class TestR68(unittest.TestCase):
 def setUp(self):self.base=json.loads(DOC.read_text())
 def mutation(self,fun):
  d=copy.deepcopy(self.base);fun(d)
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'test.json';p.write_text(json.dumps(d,ensure_ascii=False))
   return check(p,SOURCE,R66)
 def test_valid_readback(self):
  r=check(DOC,SOURCE,R66);self.assertTrue(r['status'].startswith('PASS'),r)
 def test_no_source(self):self.assertEqual(check(DOC,SOURCE,None)['status'].split('_')[0],'HOLD')
 def test_mutation_fake_cost(self):self.assertIn('FABRICATED',self.mutation(lambda d:d['records'][0].update(official_PA=3))['reason'])
 def test_mutation_fake_E0(self):self.assertIn('FABRICATED',self.mutation(lambda d:d['records'][0].update(effect_RE_E0='Prata'))['reason'])
 def test_mutation_peer_response(self):self.assertIn('FABRICATED',self.mutation(lambda d:d['records'][0].update(independent_reviewer_result='homologado'))['reason'])
 def test_mutation_native_action(self):self.assertEqual(self.mutation(lambda d:d['records'][0].update(native_action_mapping_decision='Livre'))['status'].split('_')[0],'HOLD')
 def test_mutation_concentration(self):self.assertIn('CONCENTRATION',self.mutation(lambda d:d['records'][0].update(native_concentration_mechanic_decision='Sempre ativo'))['reason'])
 def test_mutation_source_id(self):self.assertIn('PROVENANCE',self.mutation(lambda d:d['records'][0].update(notion_page_id='1234'))['reason'])
 def test_mutation_sha(self):self.assertIn('PROVENANCE',self.mutation(lambda d:d['records'][0].update(r60_masked_sha256='0'*64))['reason'])
 def test_mutation_duplicate(self):self.assertIn('CASE_ORDER',self.mutation(lambda d:d['records'][1].update(case_id=d['records'][0]['case_id']))['reason'])
 def test_mutation_missing(self):self.assertIn('14',self.mutation(lambda d:d['records'].pop())['reason'])
 def test_mutation_action_unknown(self):self.assertIn('ACTION',self.mutation(lambda d:d['records'][0].update(observed_action_foreign_card='1 AÇÃO LIVRE'))['reason'])
 def test_mutation_action_flag(self):self.assertIn('FLAG',self.mutation(lambda d:d['records'][0].update(foreign_bonus_action=False))['reason'])
 def test_mutation_duration(self):self.assertIn('DURATION',self.mutation(lambda d:d['records'][0].update(observed_duration_foreign_card=''))['reason'])
 def test_mutation_count(self):self.assertIn('COUNTS',self.mutation(lambda d:d['counts'].update(foreign_bonus_action=0))['reason'])
 def test_mutation_status(self):self.assertIn('STATUS',self.mutation(lambda d:d.update(status='E0_14_OF_14'))['reason'])
 def test_wrong_R66_file(self):self.assertIn('SHA',check(DOC,SOURCE,SOURCE)['reason'])
 def test_r68_contains_4_bonus(self):self.assertEqual(sum(x['foreign_bonus_action'] for x in self.base['records']),4)
 def test_r68_contains_8_concentration(self):self.assertEqual(sum(x['foreign_concentration_marker'] for x in self.base['records']),8)
 def test_r68_original_still_empty(self):self.assertEqual(sum(x['effect_RE_E0'] is not None for x in self.base['records']),0)
if __name__=='__main__':unittest.main(verbosity=2)
