"""Semantic preflight for fixed 14-case roster only; excludes rank, cost, adjudication, production."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json

HERE=Path(__file__).resolve().parent
DOC=HERE/'R68_FOREIGN_ACTION_DOSSIER_MESTRE_ONLY.json'
SOURCE=HERE/'R60_NOTION_LIVE_READBACK_14_MASTER_ONLY.json'
SHA_R66='ce3a4adaaf72a38b3ac18c11c0b16748813138a3bca8894711e4201053da81d9'
SRC_SHA='ed69f1ee500958ed57838538b5c19fa752f24383408bbff0cdd80e745d3c802a'
ALLOWED_ACTIONS={'1 AÇÃO','1 AÇÃO BÔNUS','1 REAÇÃO'}
EXPECTED_TOTAL=14

def sha(b):return hashlib.sha256(b).hexdigest()
def denied(reason):return {'status':'HOLD_R68_PROVENANCE_OR_SEMANTIC_MAPPING','reason':reason,
 'release_for_peer':False,'re_homologated':0,'pa_official':None,'notion_write':False,'party_write':False}

def check(dossier=DOC,baseline=SOURCE,technical_r66=None):
 try:
  a=json.loads(Path(dossier).read_text(encoding='utf-8'))
  if sha(Path(baseline).read_bytes())!=SRC_SHA:return denied('BASELINE_SHA_NOT_PINNED')
  b=json.loads(Path(baseline).read_text(encoding='utf-8'))
  if technical_r66 is None:return denied('REQUIRES_PHYSICAL_R66_PACKAGE')
  if sha(Path(technical_r66).read_bytes())!=SHA_R66:return denied('R66_ARCHIVE_SHA_NOT_PINNED')
  with ZipFile(technical_r66) as z:
   if z.testzip() is not None:return denied('R66_ZIP_CRC_BAD')
   peer=z.read('PA_R66_REVISAO_MECANICA_NEUTRA_NAO_ENVIADA.zip')
  with ZipFile(__import__('io').BytesIO(peer)) as z:
   rows=json.loads(z.read('REVISOR14.json'))['records']
   images={r['case_id']:r['image_sha256'] for r in rows}
   if z.testzip() is not None:return denied('PEER_ZIP_CRC_BAD')
  records=a.get('records')
  if not isinstance(records,list) or len(records)!=EXPECTED_TOTAL:return denied('EXPECTED_14')
  if len(b['records'])!=EXPECTED_TOTAL:return denied('BASELINE_EXPECTED_14')
  ids=[r['case_id'] for r in records]
  native_ids=[r['case_id'] for r in b['records']]
  if ids!=native_ids or len(set(ids))!=14 or len(images)!=14:return denied('CASE_ORDER_AND_ID_MISMATCH')
  bonus=concen=reaction=normal=0
  for rec,src in zip(records,b['records']):
   if rec.get('title_MASTER_ONLY')!=src['canonical_source_page_title'] or rec.get('notion_page_id')!=src['notion_page_id'] or rec.get('notion_url')!=src['notion_page_url'] or rec.get('r60_masked_sha256')!=src['source_masked_sha256']:
    return denied('PROVENANCE_SUBSTITUTION')
   if not rec.get('r60_masked_sha256') or len(rec['r60_masked_sha256'])!=64:return denied('MASKED_SHA_ABSENT')
   action=rec.get('observed_action_foreign_card')
   if action not in ALLOWED_ACTIONS:return denied('ACTION_UNKNOWN')
   duration=rec.get('observed_duration_foreign_card')
   if not isinstance(duration,str) or not duration:return denied('DURATION_MISSING')
   if rec.get('foreign_bonus_action')!=(action=='1 AÇÃO BÔNUS') or rec.get('foreign_concentration_marker')!=('(C)' in duration):return denied('UNJUSTIFIED_FLAG')
   if rec.get('native_action_mapping_decision') is not None:return denied('ACTION_FABRICATED_NATIVE_MAPPING')
   if rec.get('native_concentration_mechanic_decision') not in (None,'N/A card lacks (C)'):return denied('CONCENTRATION_FABRICATED')
   if '(C)' in duration and rec.get('native_concentration_mechanic_decision') is not None:return denied('CONCENTRATION_IMPROPER_DECISION')
   if rec.get('effect_RE_E0') is not None or rec.get('official_PA') is not None or rec.get('independent_reviewer_result') is not None:return denied('FABRICATED_AUTHORITY_OR_COST')
   if action=='1 AÇÃO BÔNUS':bonus+=1
   elif action=='1 REAÇÃO':reaction+=1
   else:normal+=1
   concen+=int('(C)' in duration)
  if (bonus,concen,reaction,normal)!=(4,8,1,9):return denied('VISUAL_AUDIT_DENOMINATOR_MISMATCH')
  if a.get('counts') != {'total':14,'foreign_bonus_action':4,'foreign_concentration_marker':8,'reaction_card':1,'untranslated_action_card':9}:return denied('COUNTS_MANIPULATED')
  if a.get('status')!='HOLD_SEMANTIC_ADAPTATION; REVIEW_0_OF_14; E0_0_OF_14':return denied('STATUS_PROMOTED')
  return {'status':'PASS_R68_DOCUMENTARY_SEMANTIC_PREFLIGHT_ONLY',
      'cards':14,'bonus_unmapped':4,'foreign_concentration_unmapped':8,'action_default_not_automatically_equated':9,
      'submitted':False,'peer_answers':0,'e0_decisions':0,'official_PA':None,'production':'HOLD',
      'released_for_peer':False,'notion_write':False,'party_write':False}
 except (KeyError,ValueError,TypeError,OSError,IndexError,PermissionError) as e:return denied('BAD_DATA_'+type(e).__name__)
