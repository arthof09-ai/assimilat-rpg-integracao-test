import unittest,json,copy,pathlib
from src.check_r62 import audit
p=pathlib.Path(__file__).resolve().parents[1]
a=json.loads((p/'evidence/R62_DELTA_COMPARATORS_MASTER_ONLY.json').read_text())
class R62(unittest.TestCase):
 def test_01_four_source_cases(self):self.assertEqual(len(a['cases']),4)
 def test_02_clean_pass_no_adjudication(self):self.assertEqual(audit(a)['status'],'R62_PASS_PARTIAL_COMPARATORS_PENDING_AUTHORITY')
 def test_03_no_E0(self):self.assertEqual(audit(a)['e0_adjudicated'],0)
 def test_04_no_PA(self):self.assertIsNone(audit(a)['pa_authorized'])
 def test_05_hold_prod(self):self.assertEqual(audit(a)['production'],'HOLD')
 def test_06_no_party(self):self.assertFalse(audit(a)['party_write'])
 def test_07_no_notion(self):self.assertFalse(audit(a)['notion_write'])
 def test_08_6_distinct_source_pages(self):self.assertEqual(len({f['page_id'] for c in a['cases'] for f in c['new_comparators']}),6)
 def test_09_retaliation_has_reactive_trigger(self):self.assertIn('gatilho_apos_receber_dano',a['cases'][0]['new_comparators'][0]['overlap'])
 def test_10_retaliation_is_not_identical(self):self.assertTrue(len(a['cases'][0]['new_comparators'][0]['differences'])>=3)
 def test_11_magnitudes_not_ranked_from_cost(self):self.assertIn('16 PA por dia',a['cases'][0]['new_comparators'][0]['cost_legacy_only'])
 def test_12_elemental_environment_not_choice(self):self.assertIn('adapta_ao_ambiente_vs_escolha_no_lancamento',a['cases'][1]['new_comparators'][0]['differences'])
 def test_13_dialog_not_control(self):self.assertTrue(any('submissao_' in x for x in a['cases'][2]['new_comparators'][1]['differences']))
 def test_14_lightning_not_reaction_suppression(self):self.assertIn('descarga_eletrica',a['cases'][3]['new_comparators'][0]['overlap'])
 def test_15_ring_self_benefit_not_target_suppression(self):self.assertIn('melhora_reacao_do_portador_vs_suprime_do_alvo',a['cases'][3]['new_comparators'][1]['differences'])
 def test_16_proposals_still_TEST(self):self.assertTrue(all(x['R57_previous_provisional_TEST_not_auth'] in ('Bronze','Prata') for x in a['cases']))
 def test_17_none_automatically_reclassified(self):self.assertTrue(all(x['canonical_RE'] is None for x in a['cases']))
 def test_18_link_counts(self):self.assertEqual(a['new_comparator_refs_count'],6)
 def test_19_no_live_integrality_claim(self):self.assertEqual(a['direct_page_integrality'],'UNKNOWN')
 def test_20_all_sources_dated(self):self.assertTrue(all(x['page_last_edited_at'] for c in a['cases'] for x in c['new_comparators']))
 def test_21_footprint(self):self.assertTrue(a['no_new_items_or_resources'])
 def test_22_no_equal_mechanics_claim(self):self.assertFalse(any(c['E0_equivalent_same_effect_found'] for c in a['cases']))
 def test_23_tamper_case(self):
  d=copy.deepcopy(a);d['cases'][0]['canonical_RE']='Ouro';self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_24_tamper_case(self):
  d=copy.deepcopy(a);d['cases'][0]['official_pa']=50;self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_25_tamper_case(self):
  d=copy.deepcopy(a);d['cases'][0]['E0_equivalent_same_effect_found']=True;self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_26_tamper_comparator(self):
  d=copy.deepcopy(a);d['cases'][0]['new_comparators'][0]['independent_RE_E0_source']=True;self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_27_tamper_comparator(self):
  d=copy.deepcopy(a);d['cases'][0]['new_comparators'][0]['url']='https://app.notion.com/p/wrong';self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_28_tamper_comparator(self):
  d=copy.deepcopy(a);d['cases'][0]['new_comparators'][0]['overlap']=[];self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_29_tamper_comparator(self):
  d=copy.deepcopy(a);d['cases'][0]['new_comparators'][0]['differences']=[];self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_30_tamper_global(self):
  d=copy.deepcopy(a);d['matched_exact_effects_E0']=1;self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')
 def test_31_tamper_global(self):
  d=copy.deepcopy(a);d['cases']=[];self.assertEqual(audit(d)['status'],'R62_HOLD_PROVENANCE')

if __name__=="__main__":unittest.main()
