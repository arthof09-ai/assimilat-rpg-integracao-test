import subprocess,sys,json
from pathlib import Path
root=Path(__file__).resolve().parent
p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r62.py','-q'],cwd=root,capture_output=True,text=True,timeout=30)
if p.returncode or 'Ran 31 tests' not in p.stderr:raise RuntimeError(p.stderr[-2200:])
print(json.dumps({'status':'PASS_R62_SAME_FAMILY_PARTIAL_E0_HOLD','new_tests':31,'direct_Notion_sources':6,'cases_reopened':4,'fully_homologous_effects_found':0,'official_pa':None,'prod':'HOLD','notion_write':0,'party_write':0},sort_keys=True))
