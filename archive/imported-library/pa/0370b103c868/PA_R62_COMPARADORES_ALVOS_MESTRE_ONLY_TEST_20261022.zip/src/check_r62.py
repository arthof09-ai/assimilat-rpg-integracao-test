"""R62 homologous comparator admissibility (read-only, no rank inference)."""
def audit(doc):
 issues=[];cases=doc.get('cases',[])
 if len(cases)!=4 or len({x.get('case_id') for x in cases})!=4:issues.append('FOUR_DISTINCT_R57_CASES_REQUIRED')
 for row in cases:
  if row.get('canonical_RE') is not None or row.get('official_pa') is not None:issues.append('OFFICIAL_RE_OR_PA_SELF_PROMOTION')
  if row.get('E0_equivalent_same_effect_found') is not False:issues.append('E0_ASSERTION_WITHOUT_AUTHORITY')
  f=row.get('new_comparators',[])
  if not f:issues.append('NO_ADDITIONAL_EVIDENCE')
  for x in f:
   if x.get('independent_RE_E0_source') is not False:issues.append('UNVERIFIED_E0_COMPARATOR')
   if len(x.get('overlap') or [])<1 or len(x.get('differences') or [])<2:issues.append('MISSING_MECHANICAL_DIFFERENCES')
   if not str(x.get('url','')).endswith(str(x.get('page_id','___'))):issues.append('URL_ID_MISMATCH')
   if x.get('cost_legacy_only') and x.get('independent_RE_E0_source'):issues.append('PA_USED_TO_INFER_E0')
 if doc.get('matched_exact_effects_E0')!=0:issues.append('E0_COUNT_CANNOT_BE_PROMOTED_BY_RESEARCH')
 return {'status':'R62_PASS_PARTIAL_COMPARATORS_PENDING_AUTHORITY' if not issues else 'R62_HOLD_PROVENANCE','issues':sorted(set(issues)),
  'e0_adjudicated':0,'pa_authorized':None,'production':'HOLD','notion_write':False,'party_write':False}
