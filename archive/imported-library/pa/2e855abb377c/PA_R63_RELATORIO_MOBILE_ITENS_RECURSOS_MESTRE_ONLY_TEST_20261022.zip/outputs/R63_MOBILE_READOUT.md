# PA/CRAFT — VISTA COMPACTA MESTRE · TEST
**SEM ESCRITA NO CATÁLOGO • SEM PA NOVO • PRODUÇÃO HOLD**

## Recursos já disponíveis no acervo
- Cristal de Aurora Boreal — reutilizar ficha existente; RIn E2/PS não é RE homologado. Fonte: 3edc2b324ede818b9d7ad75d42f2afa2
- Erva da Luz do Norte — reutilizar ficha existente; RIn E2/PS não é RE homologado. Fonte: 3edc2b324ede81deb8cec70bf5ca7150
- Fibra de Casca Boreal — ficha PS no acervo; NÃO é P4 nem recurso canônico liberado para receita. RIn não é RE. Fonte: 3f3c2b324ede815ab04ace5bd1074e79

## Item já existente
Bota Caminho Veloz: preservar ficha; histórico 18 PA/dia e 5 PA por ativação de Velocidade Sobrenatural. **Não recalcular nem duplicar.**

## Bloqueios e próxima ação
- RE individual E0 só após homologação Atlas/Mestre com fonte e readback legítimos.
- Rendimento/BOM, comprovação mágica, P4/RC5 e runtime CRAFT continuam em HOLD.
- Consultar o item/recurso original; se precisar nova função, pesquisar equivalentes primeiro, antes de abrir PR-CRN.

*O relatório é Mestre-only; não copiar para a Party.*