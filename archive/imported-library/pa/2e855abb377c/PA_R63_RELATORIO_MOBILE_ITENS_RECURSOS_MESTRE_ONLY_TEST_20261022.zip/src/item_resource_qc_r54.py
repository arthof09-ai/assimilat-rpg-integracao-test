"""PA R54. Read-only inspection before existing PR-ITEM / PR-CRN / REC-EXEC.
This is a validation adapter, not a crafting engine, source of RE, or PA calculator.
All return objects are advisory TEST; no Notion calls or mutations.
"""
from __future__ import annotations
from pathlib import Path
import json,re,unicodedata
ROOT=Path(__file__).resolve().parents[1]
RANKS={'Bronze','Prata','Ouro','Ouro Negro','Lendário','Sem Classificação'}
CATEGORIES={'arma':'REC-MOD-ARM-01','armadura':'REC-MOD-ARD-01','acessorio':'REC-MOD-EQA-01','artefato':'REC-MOD-ART-01','inscricao':'REC-MOD-ENC-01'}
SEARCH_CRN={'itens','regioes','bestas_drops','receitas','sinonimos_historico','lore_economia'}
REQUIRED_SECTIONS={'identidade','descricao_fisica','mecanica','poder','origem','geografia','obtencao','receita_bom','economia','sociedade','historia_conhecimento','jogabilidade','auditoria'}
NO_WRITE={'notion_write':False,'party_write':False,'o_primeiro_write':False,'official_pa_consumed':None,'physical_item_produced':None,'magical_effect_installed':None,'official_item_created':False,'canonical_RE':None,'production_gate':'HOLD'}
def canon(s):
 if not isinstance(s,str):return ''
 s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().casefold()
 return re.sub(r'[^a-z0-9]+','',s)
def _result(kind,state,reasons,next_action,**extra):
 return {'kind':kind,'state':state,'blocking_reasons':sorted(set(reasons)),'next_action':next_action,**NO_WRITE,**extra}
def _positive_number(x):
 return isinstance(x,(int,float)) and not isinstance(x,bool) and x>0

def audit_resource(spec,registry):
 """PR-CRN BUSCA-CRN + RC-MIN, fail closed; NEVER promotes a new resource."""
 if not isinstance(spec,dict):return _result('resource','HOLD_INVALID_INPUT',['INVALID_RESOURCE_SPEC'],'provide_dict')
 title=spec.get('name',''); names={canon(k):v for k,v in registry.items()}
 for alias in (title,*spec.get('aliases',[])):
  if canon(alias) and canon(alias) in names:
   target=names[canon(alias)]
   return _result('resource','REUSE_EXISTING',['EXISTING_RESOURCE_FOUND'], 'inspect_existing_source_and_function',existing_name=target.get('name',title),existing_id=target['id'],proposed_state=None)
 checked=set(spec.get('search_checked',[]))
 missing=SEARCH_CRN-checked
 reasons=[]
 if not title or not isinstance(title,str):reasons.append('MISSING_RESOURCE_NAME')
 if missing:reasons.append('BUSCA_CRN_INCOMPLETE:'+','.join(sorted(missing)))
 if not isinstance(spec.get('function_independent_of_recipe'),str) or not spec['function_independent_of_recipe'].strip():reasons.append('RESOURCE_INNATE_FUNCTION_UNPROVEN')
 if not spec.get('geography_source'):reasons.append('GEO_SOURCE_REQUIRED')
 if not spec.get('ecology_source'):reasons.append('ECOLOGY_SOURCE_REQUIRED')
 if not spec.get('obtention_method'):reasons.append('OBTENTION_REQUIRED')
 if not spec.get('recipe_need'):reasons.append('RECIPE_NEED_NOT_DEMONSTRATED')
 if spec.get('RIn') not in RANKS:reasons.append('RIN_NOT_QUALIFIED')
 if spec.get('re_rank_from_rin') or spec.get('ri_rank_from_rin'):reasons.append('CANNOT_INHERIT_RE_OR_RI_FROM_RIN')
 if spec.get('approved_p4') or spec.get('auto_ps'):reasons.append('AUTHORITY_PROMOTION_NOT_ALLOWED_BY_QA')
 if any(k in spec and spec[k] is not None for k in ('precise_med','official_pa','new_crn_id')):reasons.append('AUTHORITATIVE_VALUE_OR_ID_NOT_ALLOWED')
 if reasons:return _result('resource','HOLD_PROPOSAL_QA',reasons,'complete_existing_pr_crn_and_human_authority',proposed_state='P0-P2_ONLY')
 return _result('resource','P3_DOSSIER_CANDIDATE_TEST_ONLY',[], 'present_existing_PR_CRN_proposal_to_Mestre',proposed_state='P3_NOT_CANON',authority_required=True)

def audit_item(spec,resource_registry):
 """Inspect existing item proposal; QMC/CRAFT/PA production gates stay HOLD."""
 if not isinstance(spec,dict):return _result('item','HOLD_INVALID_INPUT',['INVALID_ITEM_SPEC'],'provide_dict')
 reasons=[]
 if not spec.get('name'):reasons.append('MISSING_ITEM_NAME')
 cat=spec.get('category')
 if cat not in CATEGORIES:reasons.append('UNKNOWN_ITEM_CATEGORY')
 elif spec.get('rec_mod')!=CATEGORIES[cat]:reasons.append('WRONG_CANONICAL_MODULE')
 rank=spec.get('RI')
 if rank not in RANKS:reasons.append('RI_UNKNOWN')
 if isinstance(rank,str) and (re.search(r'\d\s*[★*]',rank) or re.search(r'[1-5]\s*(?:estrela|star)',rank,re.I)):reasons.append('ITEM_PUBLIC_STARS_PROHIBITED')
 if spec.get('ri_from_resource') or spec.get('re_from_item'):reasons.append('RIN_RI_RE_CROSS_INHERITANCE')
 if spec.get('approval_claim') in {'PS','P4','RC5','PROD'}:reasons.append('AUTOMATIC_AUTHORITY_CLAIM_PROHIBITED')
 if spec.get('official_pa_daily') is not None or spec.get('official_pa_use') is not None:reasons.append('OFFICIAL_PA_DIRECT_INPUT_NOT_ALLOWED')
 if not spec.get('existing_search_done'):reasons.append('EXISTING_FIRST_NOT_PROVED')
 if spec.get('existing_equivalent'):reasons.append('REUSE_EXISTING_ITEM_BEFORE_NEW_ONE')
 sections=set(spec.get('sections_reviewed',[]))
 if (missing:=REQUIRED_SECTIONS-sections):reasons.append('PR_ITEM_I_XIII_MISSING:'+','.join(sorted(missing)))
 if not spec.get('mestre_only_complete'):reasons.append('MESTRE_LAYER_INCOMPLETE')
 if not spec.get('player_projection_safe'):reasons.append('PLAYER_PROJECTION_NOT_SAFE')
 effects=spec.get('effects',[])
 if not isinstance(effects,list):effects=[];reasons.append('EFFECTS_INVALID')
 if not effects:reasons.append('EFFECT_MECHANICS_MISSING')
 for i,eff in enumerate(effects):
  if not isinstance(eff,dict):reasons.append(f'EFFECT_{i}_INVALID');continue
  if not eff.get('mechanic') or not eff.get('duration') or not eff.get('activation') or not eff.get('limits'):reasons.append(f'EFFECT_{i}_MECHANICS_INCOMPLETE')
  if eff.get('RE') not in RANKS:reasons.append(f'EFFECT_{i}_RE_UNASSESSED')
  if eff.get('individual_E0_adjudication') is not True:reasons.append(f'EFFECT_{i}_E0_AUTHORITY_MISSING')
  elif not eff.get('authority_source_direct_readback'):reasons.append(f'EFFECT_{i}_E0_AUTHORITY_READBACK_MISSING')
  if eff.get('magic_installed') is True:reasons.append(f'EFFECT_{i}_INSTALLATION_CLAIM_NOT_PROVEN')
  if eff.get('PA_suggested') is not None:reasons.append(f'EFFECT_{i}_ENERGY_CLAIM_NOT_AUTHORIZED')
 resources=spec.get('bom',[]);steps=spec.get('process',[])
 consumed=set();step_use=set();intermediate_created=set();intermediate_used=set()
 if not resources:reasons.append('BOM_EMPTY')
 if not isinstance(resources,list):resources=[];reasons.append('BOM_NOT_LIST')
 if not isinstance(steps,list):steps=[];reasons.append('PROCESS_NOT_LIST')
 for j,r in enumerate(resources):
  if not isinstance(r,dict):reasons.append(f'BOM_{j}_INVALID');continue
  rid=r.get('id');consumed.add(rid)
  if rid not in {x['id'] for x in resource_registry.values()}:reasons.append(f'BOM_{j}_RESOURCE_UNRESOLVED')
  if not _positive_number(r.get('quantity')) or not r.get('unit'):reasons.append(f'BOM_{j}_QUANTITY_UNIT_MISSING')
  if not r.get('role'):reasons.append(f'BOM_{j}_ROLE_MISSING')
  if r.get('RIn') not in RANKS:reasons.append(f'BOM_{j}_RIN_UNASSESSED')
  if r.get('auto_power_transfer'):reasons.append(f'BOM_{j}_TRANSFER_NOT_DEMONSTRATED')
 for j,step in enumerate(steps):
  if not isinstance(step,dict):reasons.append(f'PROCESS_{j}_INVALID');continue
  step_use.update(step.get('consumes',[]));intermediate_used.update(step.get('uses_intermediates',[]));intermediate_created.update(step.get('makes_intermediates',[]))
  if not step.get('action'):reasons.append(f'PROCESS_{j}_ACTION_MISSING')
 if not steps:reasons.append('PROCESS_EMPTY')
 if consumed-step_use:reasons.append('BOM_UNCONSUMED:'+','.join(sorted(str(x) for x in consumed-step_use)))
 if step_use-consumed:reasons.append('PROCESS_USE_NOT_IN_BOM:'+','.join(sorted(str(x) for x in step_use-consumed)))
 if intermediate_used-intermediate_created:reasons.append('INTERMEDIATE_ORPHAN')
 if spec.get('approved_units') is None:reasons.append('YIELD_UNKNOWN_BLOCKS_RC5')
 elif not (isinstance(spec['approved_units'],int) and spec['approved_units']>=0):reasons.append('YIELD_INVALID')
 if not spec.get('qa_material'):reasons.append('MATERIAL_QA_NOT_PROVED')
 if not spec.get('qa_magic'):reasons.append('MAGIC_QA_NOT_PROVED')
 if not spec.get('energy_receipt_source_r26_r27'):reasons.append('ORIGINAL_PA_ENVELOPE_NOT_PRESENT')
 if not spec.get('economy_source'):reasons.append('MED_ECONOMY_SOURCE_NOT_PRESENT')
 # This audit does not, and cannot, grant production even with complete fixture input.
 return _result('item','HOLD_PRODUCTION_AND_RE_ADJUDICATION' if reasons else 'DESIGN_QA_TEST_ONLY',reasons,
  'repair_input_in_existing_PR_ITEM_REC_EXEC_without_writing_canon',
  route_module=CATEGORIES.get(cat),reconciled_bom_process=not bool((consumed-step_use)|(step_use-consumed)),
  design_evidence_only=True,rc5_authorized=False)

def review_techniques_as_candidates(registry, case_ids):
 """Structural census: names/ranks from Notion technique pages are not E0 of isolated effect."""
 records=registry.get('records',[]);ids=[r.get('page_id') for r in records]
 issues=[]
 if len(records)!=8 or len(set(ids))!=8:issues.append('8_UNIQUE_SOURCES_REQUIRED')
 if sorted(r.get('nominal_technique_rank') for r in records)!=sorted(['Bronze']*2+['Prata']*6):issues.append('GRADE_CENSUS_MISMATCH')
 if any(r.get('isolated_effect_RE_adjudicated') is not False for r in records):issues.append('E0_CLAIM_INADMISSIBLE_WITHOUT_AUTHORITY')
 if any(r.get('mechanics_source')!='original_image_not_textual_in_page' for r in records):issues.append('UNVERIFIED_IMAGE_MECHANICS_CLAIM')
 return {'status':'HOLD_E0_EFFECT_RANK_ADJUDICATION','source_count':len(records),
   'source_nominal_rank_census':{'Bronze':2,'Prata':6},
   'direct_page_readback_asof':registry.get('asof_date'),
   'candidate_potential_only':True,'cases_to_review':case_ids,'issues':issues,
   'e0_effects_authorized':0,'r26_write':False,**NO_WRITE}
