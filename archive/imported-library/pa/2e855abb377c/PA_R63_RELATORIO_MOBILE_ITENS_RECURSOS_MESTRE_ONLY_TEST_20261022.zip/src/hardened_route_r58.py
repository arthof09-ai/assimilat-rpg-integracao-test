"""Strict type-boundary for original QA R54/R56. No extra crafting/PA decisions."""
from __future__ import annotations
from src.item_resource_qc_r54 import audit_item as original_item, audit_resource as original_resource
from src.module_contract_r56 import audit_module as original_module, audit_substitution as original_substitution

DENY={'notion_write':False,'party_write':False,'o_primeiro_write':False,
 'new_item':False,'new_resource':False,'new_recipe':False,
 'canonical_RE':None,'authorized_pa':None,'official_pa':None,'official_pa_consumed':None,
 'physical_item_produced':None,'magical_effect_installed':None,'production_gate':'HOLD'}

def hold(code,location):
 return {'status':'HOLD_INPUT_SCHEMA_R58','blocking_reasons':[code],
  'location':location,'needs_source_repair':True,**DENY}

def str_or_absent(v):return v is None or isinstance(v,str)
def clean_registry(v):
 return isinstance(v,dict) and all(isinstance(k,str) and isinstance(x,dict) and isinstance(x.get('id'),str) and isinstance(x.get('name'),str) for k,x in v.items())
def plain_strings(v):return isinstance(v,list) and all(isinstance(x,str) for x in v)

def run_resource(spec,registry):
 if not isinstance(spec,dict):return hold('RESOURCE_SPEC_NOT_OBJECT','resource')
 if not clean_registry(registry):return hold('REGISTRY_SCHEMA_INVALID','resource.registry')
 for k in ('name','RIn','function_independent_of_recipe','geography_source','ecology_source','obtention_method','recipe_need'):
  if not str_or_absent(spec.get(k)):return hold('FIELD_MUST_BE_STRING:'+k,'resource.'+k)
 if not plain_strings(spec.get('aliases',[])):return hold('ALIASES_LIST_OF_STRINGS_REQUIRED','resource.aliases')
 if not plain_strings(spec.get('search_checked',[])):return hold('SEARCH_CHECKED_LIST_REQUIRED','resource.search_checked')
 return original_resource(spec,registry)

def run_item(spec,registry):
 if not isinstance(spec,dict):return hold('ITEM_SPEC_NOT_OBJECT','item')
 if not clean_registry(registry):return hold('REGISTRY_SCHEMA_INVALID','item.registry')
 for k in ('name','RI','category','rec_mod','approval_claim'):
  if not str_or_absent(spec.get(k)):return hold('FIELD_MUST_BE_STRING:'+k,'item.'+k)
 if not plain_strings(spec.get('sections_reviewed',[])):return hold('SECTIONS_LIST_REQUIRED','item.sections_reviewed')
 for i,e in enumerate(spec.get('effects',[]) if isinstance(spec.get('effects',[]),list) else []):
  if not isinstance(e,dict):continue
  for k in ('RE','mechanic','duration','activation','limits'):
   if not str_or_absent(e.get(k)):return hold('EFFECT_FIELD_MUST_BE_STRING:'+k,'item.effects[%d]'%i)
 for i,b in enumerate(spec.get('bom',[]) if isinstance(spec.get('bom',[]),list) else []):
  if not isinstance(b,dict):continue
  for k in ('id','unit','role','RIn'):
   if not str_or_absent(b.get(k)):return hold('BOM_FIELD_MUST_BE_STRING:'+k,'item.bom[%d]'%i)
 for i,step in enumerate(spec.get('process',[]) if isinstance(spec.get('process',[]),list) else []):
  if not isinstance(step,dict):continue
  if not str_or_absent(step.get('action')):return hold('PROCESS_ACTION_INVALID','item.process[%d]'%i)
  for k in ('consumes','uses_intermediates','makes_intermediates'):
   if not plain_strings(step.get(k,[])):return hold('PROCESS_RESOURCE_LIST_REQUIRED:'+k,'item.process[%d]'%i)
 return original_item(spec,registry)

def run_module(category,spec):
 if not isinstance(category,str):return hold('MODULE_CATEGORY_NOT_STRING','module.category')
 if not isinstance(spec,dict):return hold('MODULE_SPEC_NOT_OBJECT','module.spec')
 if not plain_strings(spec.get('steps',[])):return hold('MODULE_STEPS_LIST_REQUIRED','module.steps')
 return original_module(category,spec)

def run_substitution(original,replacement,proposal):
 if any(not isinstance(x,dict) for x in (original,replacement,proposal)):return hold('SUBSTITUTION_INPUT_INVALID','substitution')
 for name,row in (('original',original),('replacement',replacement)):
  for k in ('source_id','role','maturity'):
   if not isinstance(row.get(k),str):return hold('SUBSTITUTION_FIELD_NOT_STRING:'+k,name)
 if not str_or_absent(proposal.get('substitution_grade')):return hold('GRADE_MUST_BE_STRING','proposal.substitution_grade')
 return original_substitution(original,replacement,proposal)
