"""R59 boundary hardening of existing R54/R56 TEST QA; not a CRAFT/PA engine.

Denied state is irreversible here. This function does NOT adjudicate evidence or ranks.
"""
from __future__ import annotations
import math
from src.hardened_route_r58 import run_resource as r58_resource, run_item as r58_item, run_module as r58_module, run_substitution as r58_substitution, hold as base_hold
from src.item_resource_qc_r54 import canon
DENY={"notion_write":False,"party_write":False,"o_primeiro_write":False,
"new_item":False,"new_resource":False,"new_recipe":False,
"canonical_RE":None,"authorized_pa":None,"official_pa":None,
"official_pa_consumed":None,"physical_item_produced":None,
"magical_effect_installed":None,"production_gate":"HOLD"}

def _hold(code,location):
 return {"status":"HOLD_EVIDENCE_OR_SCHEMA_R59", "blocking_reasons":[code], "location":location,
  "externally_verified_authority":False, "r59_gate":"HOLD",**DENY}

def _reg_issue(reg):
 if not isinstance(reg,dict):return 'REGISTRY_NOT_OBJECT'
 ids=set(); aliases=set()
 for key,value in reg.items():
  if not isinstance(key,str) or not key.strip() or not isinstance(value,dict):return 'BAD_REGISTRY_ENTRY'
  id_=value.get('id'); name=value.get('name')
  if not isinstance(id_,str) or not id_.strip() or not isinstance(name,str) or not name.strip():return 'INVALID_RESOURCE_ID_OR_NAME'
  if id_ in ids:return 'DUPLICATE_RESOURCE_ID'
  ids.add(id_)
  alias=canon(key)
  if not alias or alias in aliases:return 'COLLIDING_CANONICAL_RESOURCE_ALIAS'
  aliases.add(alias)
 return None

def _invalid_positive(v):
 return isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0

def run_resource(spec, registry):
 issue=_reg_issue(registry)
 if issue:return _hold(issue,'resource.registry')
 if isinstance(spec,dict):
  names=[spec.get('name','')]+(spec.get('aliases') if isinstance(spec.get('aliases'),list) else [])
  if all(isinstance(s,str) for s in names):
   norm=[canon(s) for s in names if canon(s)]
   if len(norm)!=len(set(norm)):return _hold('DUPLICATE_PROPOSAL_ALIAS','resource.aliases')
 return r58_resource(spec,registry)

def run_item(spec, registry):
 issue=_reg_issue(registry)
 if issue:return _hold(issue,'item.registry')
 if isinstance(spec,dict):
  bom=spec.get('bom',[])
  if isinstance(bom,list):
   ids=[]
   for i,row in enumerate(bom):
    if isinstance(row,dict):
     bid=row.get('id')
     if isinstance(bid,str) and bid.strip():ids.append(bid)
     if 'quantity' in row and _invalid_positive(row.get('quantity')):return _hold('BOM_QUANTITY_NONFINITE_ZERO_BOOL_OR_INVALID',f'item.bom[{i}].quantity')
   if len(ids)!=len(set(ids)):return _hold('DUPLICATE_BOM_RESOURCE_ID','item.bom')
  units=spec.get('approved_units')
  if units is not None and (isinstance(units,bool) or not isinstance(units,int) or units<0):return _hold('UNITS_NONINTEGER_BOOL_OR_NEGATIVE','item.approved_units')
  for i, eff in enumerate(spec.get('effects') if isinstance(spec.get('effects'),list) else []):
   if not isinstance(eff,dict):continue
   if eff.get('individual_E0_adjudication') is True or eff.get('authority_source_direct_readback'):
    return _hold('SELF_ATTESTED_EFFECT_E0_CANNOT_SATISFY_LIVE_AUTHORITY',f'item.effects[{i}]')
 return r58_item(spec,registry)

def run_module(category,spec):
 if isinstance(spec,dict):
  sid=spec.get('source_id')
  if sid is not None and (not isinstance(sid,str) or not sid.strip()):return _hold('SOURCE_ID_INVALID','module.source_id')
 return r58_module(category,spec)

def run_substitution(original,replacement,proposal):
 for name, row in [('original',original),('replacement',replacement)]:
  if isinstance(row,dict):
   sid=row.get('source_id')
   if isinstance(sid,str) and not sid.strip():return _hold('EMPTY_SOURCE_ID',f'substitution.{name}')
 return r58_substitution(original,replacement,proposal)
