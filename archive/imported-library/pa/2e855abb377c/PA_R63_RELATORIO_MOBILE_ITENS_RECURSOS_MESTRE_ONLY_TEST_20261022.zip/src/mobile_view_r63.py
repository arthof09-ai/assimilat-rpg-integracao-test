"""Mestre-side compact view over the existing TEST R59 read-only QA.
No new engine, recipe, item, resource, item rank or PA tariff.
"""
from src.qa_intake_r59 import run_resource,run_item

def summarize_snapshot(snapshot):
 sources=snapshot.get('resources',[]);registry=snapshot.get('registry',{});b=[]
 for row in sources:
  x=run_resource({'name':row['name'],'aliases':[]},registry)
  b.append({'name':row['name'],'source_id':row['source_id'], 'status':x.get('state') or x.get('status'),
   'reuse_original_id':x.get('existing_id')==row.get('source_id'),
   'RIn_not_RE':row.get('canonical_RE') is None,
   'source_freshness':'ASOF_ONLY_NO_CRYPT_FULL_PAGE_READBACK',
   'catalog_write':False,'new_resource':False})
 row=snapshot['item'];spec={'name':row['name'],'category':row['category'],'RI':row['RI'],
  'rec_mod':row['rec_mod'],'existing_equivalent':row['existing_equivalent'],'existing_search_done':row['existing_search_done']}
 q=run_item(spec,registry)
 item={'name':row['name'],'source_id':row['source_id'], 'status':'REUSE_EXISTING_ITEM_NO_DUPLICATION',
  'R54_QA_state':q.get('state') or q.get('status'), 'historical_PA_daily':row['old_PA_daily_historical'],
  'historical_PA_use':row['old_PA_use_historical'],'recalculated_PA':None,'canonical_RE':None,
  'catalog_write':False,'physical_item_produced':None, 'new_item':False}
 lines=['# PA/CRAFT — VISTA COMPACTA MESTRE · TEST','**SEM ESCRITA NO CATÁLOGO • SEM PA NOVO • PRODUÇÃO HOLD**','',
  '## Recursos já disponíveis no acervo']
 for x in b:
  maturity=next(z['status'] for z in sources if z['name']==x['name'])
  if maturity=='EXISTENT_PROPOSED_PS_NOT_P4':
   lines.append('- '+x['name']+' — ficha PS no acervo; NÃO é P4 nem recurso canônico liberado para receita. RIn não é RE. Fonte: '+x['source_id'])
  else:
   lines.append('- '+x['name']+' — reutilizar ficha existente; RIn E2/PS não é RE homologado. Fonte: '+x['source_id'])
 lines+=['','## Item já existente', item['name']+': preservar ficha; histórico '+row['old_PA_daily_historical']+' e '+row['old_PA_use_historical']+'. **Não recalcular nem duplicar.**','',
  '## Bloqueios e próxima ação','- RE individual E0 só após homologação Atlas/Mestre com fonte e readback legítimos.','- Rendimento/BOM, comprovação mágica, P4/RC5 e runtime CRAFT continuam em HOLD.','- Consultar o item/recurso original; se precisar nova função, pesquisar equivalentes primeiro, antes de abrir PR-CRN.','',
  '*O relatório é Mestre-only; não copiar para a Party.*']
 return {'status':'R63_MOBILE_EXISTING_FIRST_TEST_ONLY','resources':b,'item':item,'text_markdown':'\n'.join(lines),
  'readback_scope':'Notion source pages fetched previously in Mestre; textual snapshot used for QA, not live signature',
  'new_items':0,'new_resources':0,'official_PA':None,'party_write':False,'notion_write':False,'production':'HOLD'}
