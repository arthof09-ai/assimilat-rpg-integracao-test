"""QA-only routes to already canonical REC-MOD rules (not a new crafting engine).
No item, ingredient, recipe, magic, economy or PA is produced.
"""
from __future__ import annotations
from copy import deepcopy
MODULES={
 'arma':('REC-MOD-ARM-01',('corpo_arma','classe_ataque','superficie_ofensiva','empunhadura_ou_mecanismo','balanceamento','teste_integridade','teste_precisao')),
 'armadura':('REC-MOD-ARD-01',('cobertura','estrutura_camadas','articulacao_feches','mobilidade_peso','defesa_qa','integridade_qa')),
 'acessorio':('REC-MOD-EQA-01',('slot_interface','ajuste_ergonomia','fecho_suporte','efeit_pass_ativo_separados','interferencia_qa','integracao_fisico_magica_separada')),
 'artefato':('REC-MOD-ART-01',('replicabilidade','corpo_core','vetor_estabilizacao','interface_ativacao','cargas_regras','isolamento_seguranca','calibracao_qa')),
 'inscricao':('REC-MOD-ENC-01',('padrao_efeito_ref','receita_meio_ref','conhecimento_forma_ref','substrato','geometria_tracado','cura_selagem','teste_instalacao'))
}
SEQUENCE={
 'arma':('selecao','conformacao','tratamento','montagem','alinhamento','integracao_magica','prova'),
 'armadura':('preparacao','conformacao','tratamento','montagem_articulacao','ajuste','integracao_magica','prova'),
 'acessorio':('confeccao_fisica','integracao_magica','teste_ergonomia','teste_interferencia'),
 'artefato':('fabricar_corpo','preparar_core','integracao','isolamento','calibracao','ativacao_qa','seguranca'),
 'inscricao':('preparar_meio','tracado','energizacao','cura_selagem','teste_instalacao')
}
FREEZE={'notion_write':False,'party_write':False,'o_primeiro_write':False,'new_recipe':False,'new_resource':False,'new_item':False,'canonical_RE':None,'authorized_pa':None,'material_qa_certified':False,'magical_effect_installed':None,'RC5':False,'production':'HOLD'}

def audit_module(category,spec):
 """Produces QA obligations from existing family-specific module; no live-world judgement."""
 if category not in MODULES:return {'status':'HOLD_UNKNOWN_CANON_MODULE','issues':['INVALID_CATEGORY'],**FREEZE}
 module,required=MODULES[category];issues=[]
 if not isinstance(spec,dict):spec={};issues.append('SPEC_NOT_DICT')
 if spec.get('module')!=module:issues.append('MODULE_MISMATCH')
 if not spec.get('source_id'):issues.append('SOURCE_REQUIRED')
 for x in required:
  if spec.get(x) in (None,'',False,[]):issues.append('MISSING_MODULE_FIELD:'+x)
 sequence=spec.get('steps',[])
 if sequence!=list(SEQUENCE[category]):issues.append('MODULE_SEQUENCE_INCOMPLETE_OR_UNORDERED')
 if spec.get('magic_transferred') is True:issues.append('MAGIC_TRANSFER_NOT_VERIFIED')
 if spec.get('self_approved') or spec.get('declares_rc5'):issues.append('APPROVAL_ESCALATION_FORBIDDEN')
 if spec.get('charges_invented') or spec.get('repair_invented'):issues.append('CHARGES_OR_REPAIR_NOT_PROVED')
 if category=='artefato':
  if spec.get('replicabilidade')=='unico' and spec.get('new_recipe'):
   issues.append('UNIQUE_ARTIFACT_RECIPE_FORBIDDEN')
  if spec.get('replicabilidade') not in ('fabricavel','restauravel','unico','perdido','prototipo','PENDENTE'):
   issues.append('REPLICABILITY_UNASSESSED')
 if category=='inscricao':
  if spec.get('knowledge_visible_to_players') and not spec.get('disclosure_authorized'):
   issues.append('SECRET_FORMULA_DISCLOSURE_FORBIDDEN')
  if spec.get('magic_installed_claim'):
   issues.append('INSTALLATION_CANNOT_BE_ASSUMED')
 if category=='acessorio' and spec.get('passive_active_merged'):issues.append('PASSIVE_ACTIVE_MUST_BE_DISTINCT')
 if category=='arma' and spec.get('rank_from_damage_only'):issues.append('DMG_IS_NOT_AUTOMATIC_RE_RANK')
 if category=='armadura' and spec.get('ca_from_rin'):issues.append('DEFENSE_NOT_SUM_OF_RIN')
 return {'status':'LAB_SPEC_CHECK_COMPLETE_ONLY' if not issues else 'HOLD_MISSING_MODULE_EVIDENCE',
  'category':category,'existing_module':module,'issues':sorted(set(issues)),
  'all_required_fields_documented':not issues, 'not_proof_of_fabrication':True,**FREEZE}

def audit_substitution(original,replacement,proposal):
 """REC-LIN-SUB / RC-MIN gate for a source-backed candidate substitution, never automatic release."""
 issues=[]
 if not isinstance(original,dict) or not isinstance(replacement,dict) or not isinstance(proposal,dict):return {'status':'HOLD_BAD_INPUT','issues':['INVALID'],**FREEZE}
 if not original.get('source_id') or not replacement.get('source_id'):issues.append('PHYSICAL_SOURCE_REFERENCE_REQUIRED')
 if original.get('source_id')==replacement.get('source_id'):
  return {'status':'REUSE_SAME_RESOURCE_NO_CHANGE','issues':[],'no_new_recipe':True,**FREEZE}
 if proposal.get('substitution_grade') not in ('S0','S1','S2','SX'):issues.append('SUBSTITUTION_CLASS_UNKNOWN')
 if not original.get('role') or original.get('role')!=replacement.get('role'):issues.append('FUNCTIONAL_ROLE_NOT_EQUIVALENT')
 if not proposal.get('compatibility_test'):issues.append('COMPATIBILITY_UNTESTED')
 if replacement.get('maturity')!='P4' or original.get('maturity')!='P4':issues.append('UNAPPROVED_SOURCE_MATURITY')
 if proposal.get('inherit_rin_as_re') or proposal.get('transfer_effect_automatically'):issues.append('MAGICAL_POWER_TRANSFER_NOT_DEMONSTRATED')
 if proposal.get('rank_unchanged_by_assumption'):issues.append('RANK_UNCHANGED_NOT_PROVED')
 if proposal.get('new_recipe_id'):issues.append('RECIPE_CREATION_UNAUTHORIZED')
 if proposal.get('automatic_install'):issues.append('MAGIC_INSTALLATION_NOT_PROVED')
 return {'status':'LAB_SUBSTITUTION_CANDIDATE_ONLY' if not issues else 'HOLD_SUBSTITUTION_EVIDENCE',
  'issues':sorted(set(issues)),'human_authority_required':True,**FREEZE}
