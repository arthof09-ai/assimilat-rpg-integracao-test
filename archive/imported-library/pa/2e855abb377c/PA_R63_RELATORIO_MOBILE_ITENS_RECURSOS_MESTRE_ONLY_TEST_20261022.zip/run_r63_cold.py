import subprocess,sys,json
from pathlib import Path
r=Path(__file__).resolve().parent
p=subprocess.run([sys.executable,'run_mobile_r63.py'],cwd=r,capture_output=True,text=True,timeout=30)
if p.returncode:raise RuntimeError(p.stderr)
t=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_r63.py','-q'],cwd=r,capture_output=True,text=True,timeout=30)
if t.returncode or 'Ran 28 tests' not in t.stderr:raise RuntimeError(t.stderr)
print(json.dumps({'status':'PASS_R63_MOBILE_ADAPTER_ONLY','tests_new':28,'resources_existing':3,'items_existing':1,'new_records':0,'official_pa':None,'prod':'HOLD','notion_write':0,'party_write':0},sort_keys=True))
