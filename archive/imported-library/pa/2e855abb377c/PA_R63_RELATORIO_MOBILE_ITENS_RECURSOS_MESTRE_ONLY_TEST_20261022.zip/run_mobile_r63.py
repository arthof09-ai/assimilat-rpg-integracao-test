import json
from pathlib import Path
from src.mobile_view_r63 import summarize_snapshot
root=Path(__file__).resolve().parent
inp=json.loads((root/'fixtures/R63_CANONICAL_READBACK_EXISTING_ONLY.json').read_text())
r=summarize_snapshot(inp)
(root/'outputs/R63_MOBILE_READOUT.md').write_text(r['text_markdown'])
(root/'outputs/R63_MOBILE_READOUT.json').write_text(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2))
print(json.dumps({'status':r['status'],'resources_reused':len(r['resources']),'existing_item_reused':1,'new_resources':r['new_resources'],'new_items':r['new_items'],'production':r['production']},sort_keys=True))
