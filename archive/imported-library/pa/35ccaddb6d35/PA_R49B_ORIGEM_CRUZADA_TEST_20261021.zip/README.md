# PA-R49B — Origem cruzada sem gabaritos / Mestre-only / TEST

Reconciliador read-only do corpus visual R45 (26 registros) com os **12 campos mecânicos** do parecer independente real, sem importar suas classificações. Preserva o arquivo histórico e fornece overlay corrigido. Não escreve no Notion nem atualiza fichas ou motores.

Execute `python run_cold.py` num ambiente com Python padrão para conferir fonte/manifesto, reexecutar os 18 testes e reconstruir byte-idêntica a única saída `outputs/OVERLAY_ORIGEM_R49B.json`.

Análise e limitações: `docs/RELATORIO_R49B_MESTRE_ONLY.md`. Fontes e hashes originais em `source/`. O outro Comestre não precisa receber este pacote; ele contém evidência derivada de análises após seu congelamento.
