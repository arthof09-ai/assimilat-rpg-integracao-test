# PA-R49B — Auditoria de proveniência cruzada das mecânicas das 26 técnicas

**MESTRE-SIDE / TEST / sem reclassificar, sem custo PA, sem alterar fichas**.

## Fontes verificadas

- Cópia byte-idêntica do corpus da R45 (`CORPUS_MECANICO_MANUAL_CEGO.json`), extraída do pacote R45 original, com o SHA individual no arquivo `source/SHA_ORIGEM.json`. Baseline R45 original permanece imutável.
- Recorte exclusivamente mecânico do CSV realmente entregue pelo Comestre independente, com 12 códigos, tempo de ativação, duração, alcance e nome da técnica. O campo `proposed_RE` do avaliador **não entra no processo de reconciliação**. O CSV-fonte original, completo, está preservado na entrega independente autenticada pelo Mestre.
- Imagens verificadas anteriormente; hash da imagem original preservado em cada registro.

## Antes / depois

**ANTES:** R45 possuía `source_activation=reação` para TEC-E3532F6A98AC, corrigido nos relatórios posteriores mas ainda presente no corpus histórico. Servo Invisível já descrevia comandos por ação bônus em campo de narrativa, mas não havia separação por etapa de uso. Toque Chocante descrevia instantânea no campo de duração e supressão futura nas observações. Amizade Animal apresentava ambiguidade de alcance e Orbe seis opções de dano sem regime de material no Assimilação.

**DEPOIS:** overlay TEST de 26/26 registros, sem sobrescrever origem. A correção `TEC-E3532F6A98AC: REAÇÃO (R45) → 1 AÇÃO (imagem)` só é aplicada após verificar o valor anterior. Em Servo Invisível, a conjuração permanece uma Ação e o comando secundário é campo próprio; o relatório peer contém ambos no MESMO campo de texto. Em Toque, lançamento instantâneo não apaga a duração do efeito residual. Os dois casos de ambiguidade são sinalizados explicitamente.

**Defeito descoberto em TEST:** o primeiro comparador textual leu "ação bônus" da SEGUNDA cláusula do parecer Servo Invisível como se ela definisse a conjuração. Foi corrigido para distinguir a cláusula principal e o texto de comando; registramos o defeito porque é um risco de interpretação que também existe em outros efeitos compostos. Nenhuma mudança canônica ocorreu.

## Teste/resultado

- 26/26 linhas com identificadores e SHA de imagem originais;
- 12/12 conferências com o parecer independente sem consultar seu `proposed_RE`;
- 5/5 questões individualizadas e nenhuma escolha implícita de PA, resistência ou rank;
- 18/18 testes locais; pacote de reprodutor isolado com manifesto.

**Não confundir:** concordância dos campos de ação entre as duas anotações não comprova que a conversão para economia de ação do Assimilação foi autorizada. `ação bônus` permanece ESTRANGEIRA.

## Próximas decisões

Converter ação bônus, concentração, condição Enfeitiçado e Salvaguarda, fixar alcance ambíguo de Amizade Animal, período secundário de Reações, materiais/elementos e custos PA somente com norma pertinente, comparação e aprovação competente. R45/R46/parecer peer continuam congelados; nenhum rank é promovido. O executor CRAFT conserva responsabilidade sobre P2, óleo, lotes, H2 e RC5.
