import sys,unittest,pathlib,hashlib,json
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'src'))
from overlay import norm_action,output
class OverlayTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.data=output();cls.d={r['case_id']:r for r in cls.data['reconciled']}
 def test_count(self):self.assertEqual(len(self.d),26)
 def test_peers(self):self.assertEqual(sum(a['reconciled_against_peer_source_action'] for a in self.d.values()),12)
 def test_r45_not_overwritten(self):self.assertTrue(self.data['historical_R45_original_remains_untouched'])
 def test_rank_no_change(self):self.assertEqual(self.data['rank_PA_canon_changes'],0)
 def test_e353_prestate(self):self.assertEqual(self.d['TEC-E3532F6A98AC']['legacy_r45_activation_unchanged'],'reação')
 def test_e353_repaired(self):self.assertEqual(self.d['TEC-E3532F6A98AC']['experimental_source_activation_checked'],'ACAO')
 def test_servo_command(self):self.assertIn('ACAO BONUS',self.d['TEC-988589FB9716']['command_action_foreign'])
 def test_servo_primary(self):self.assertEqual(self.d['TEC-988589FB9716']['experimental_source_activation_checked'],'ACAO')
 def test_touch_rider(self):self.assertIn('inicio do proximo turno',self.d['TEC-D9EF9388353A']['rider_duration'])
 def test_touch_primary(self):self.assertEqual(self.d['TEC-D9EF9388353A']['cast_duration_original'],'instantânea')
 def test_animal_range_conflict(self):self.assertIn('alvo besta',self.d['TEC-C71526491A42']['source_ambiguity'][0])
 def test_orb_one_type(self):self.assertIn('UM tipo',self.d['TEC-968D29765EB1']['source_ambiguity'][0])
 def test_e353_only_action_override(self):self.assertEqual([r['case_id'] for r in self.data['reconciled'] if norm_action(r['legacy_r45_activation_unchanged'])!=r['experimental_source_activation_checked']],['TEC-E3532F6A98AC'])
 def test_all_original_image_sha(self):self.assertTrue(all(len(r['original_visual_sha256'])==64 for r in self.d.values()))
 def test_source_sha(self):
  m=json.loads((R/'source'/'SHA_ORIGEM.json').read_text());self.assertEqual(hashlib.sha256((R/'source'/'R45_CORPUS_CONGELADO.json').read_bytes()).hexdigest(),m['R45_CORPUS_CONGELADO.json'])
 def test_total_issues(self):self.assertEqual(len(self.data['issues']),5)
 def test_normalize(self):self.assertEqual(norm_action('1 ação bônus (origem; sem mapeamento)'), 'BONUS_ESTRANGEIRA')
 def test_not_leak(self):self.assertNotIn('rank_proposal_test_only',str(self.data))
if __name__=='__main__':unittest.main()
