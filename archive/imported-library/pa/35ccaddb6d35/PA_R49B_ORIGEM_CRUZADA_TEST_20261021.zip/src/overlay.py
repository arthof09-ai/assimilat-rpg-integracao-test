"""R49B: overlay de preservação e reconciliação de fatos de imagem, NÃO ranks."""
from __future__ import annotations
import json,hashlib,pathlib,re,unicodedata
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source';OUT=ROOT/'outputs'

def norm_action(text):
 s=unicodedata.normalize('NFKD',text.split(';',1)[0]).encode('ascii','ignore').decode().lower()
 if 'bonus' in s:return 'BONUS_ESTRANGEIRA'
 if 'reac' in s:return 'REACAO'
 if re.search(r'\bacao\b',s):return 'ACAO'
 return 'UNSPECIFIED'

def output():
 expected=json.loads((SOURCE/'SHA_ORIGEM.json').read_text())
 for name in ('R45_CORPUS_CONGELADO.json','PEER_FATOS_ORIGEM_SEM_RANKS.json'):
  if hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()!=expected[name]:raise RuntimeError('input alterado '+name)
 r45=json.loads((SOURCE/'R45_CORPUS_CONGELADO.json').read_text())['cases']
 peer=json.loads((SOURCE/'PEER_FATOS_ORIGEM_SEM_RANKS.json').read_text())
 lookup={r['case_id']:r for r in peer}
 if len(lookup)!=12 or len(r45)!=26 or len({r['case_id'] for r in r45})!=26: raise RuntimeError('censo incorreto')
 overlay=[];issues=[]
 for r in r45:
  id_=r['case_id'];p=lookup.get(id_)
  a=norm_action(r['source_activation'])
  revised=a
  if id_=='TEC-E3532F6A98AC':
   if a!='REACAO':raise RuntimeError('prestate nao confere: E353')
   revised='ACAO'
   issues.append({'case_id':id_,'type':'CRITICAL_ACTION_PRESTATE','old':'reação','new':'1 AÇÃO na imagem; peer confirmou','source_image_sha256':r['explicit_source_image_sha256']})
  if p:
   peer_action=norm_action(p['action_source'])
   if peer_action!=revised:raise RuntimeError('divergencia independente nao resolvida em '+id_+': '+str((peer_action,revised)))
  extra={'command_action_foreign':None,'rider_duration':None,'source_ambiguity':[]}
  if id_=='TEC-988589FB9716':
   extra['command_action_foreign']='ACAO BONUS a cada comando, separada de 1 ACAO de conjuracao'
   issues.append({'case_id':id_,'type':'SECONDARY_ACTION_SEPARATION','source':'observed_mechanic_facts na propria R45 e peer'})
  if id_=='TEC-D9EF9388353A':
   extra['rider_duration']='nega Reacoes ate o inicio do proximo turno do alvo; efeito residual mesmo com lancamento instantaneo'
   issues.append({'case_id':id_,'type':'POST_CAST_RIDER_DURATION','source':'observed_mechanic_facts na propria R45 e peer'})
  if id_=='TEC-C71526491A42':
   extra['source_ambiguity'].append('cabeçalho pessoal versus alvo besta visivel; NAO inventar alcance')
   issues.append({'case_id':id_,'type':'TARGET_RANGE_HEADER_CONFLICT','source':'parecer peer e imagem fonte'})
  if id_=='TEC-968D29765EB1':
   extra['source_ambiguity'].append('seis tags mas UM tipo escolhido por conjuracao; diamante material sem regime de consumo no Assimilacao')
   issues.append({'case_id':id_,'type':'ELEMENT_OPTION_SINGLETON','source':'imagem e parecer peer'})
  overlay.append({'case_id':id_,'original_visual_sha256':r['explicit_source_image_sha256'],
   'legacy_r45_activation_unchanged':r['source_activation'],'experimental_source_activation_checked':revised,
   'cast_duration_original':r['source_duration'],
   'reconciled_against_peer_source_action':p is not None,
   'does_not_change_rank':True,'does_not_change_PA':True,**extra})
 assert len(overlay)==26 and len(issues)==5 and sum(x['reconciled_against_peer_source_action'] for x in overlay)==12
 return {'status':'PA_R49B_SOURCE_QA_TEST_ONLY','n_techniques':26,'n_crosschecked_peer':12,
         'reconciled':overlay,'issues':issues,'historical_R45_original_remains_untouched':True,
         'rank_PA_canon_changes':0}

if __name__=='__main__':
 OUT.mkdir(exist_ok=True);data=output();(OUT/'OVERLAY_ORIGEM_R49B.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 print('R49B PASS',data['n_techniques'],'peer',data['n_crosschecked_peer'],'issues',len(data['issues']))
