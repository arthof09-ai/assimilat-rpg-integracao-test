import pathlib,hashlib,json,tempfile,shutil,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
for rel,h in meta['files'].items():
 if not (ROOT/rel).is_file() or sha(ROOT/rel)!=h:raise RuntimeError('tamper '+rel)
output=sha(ROOT/'outputs'/'OVERLAY_ORIGEM_R49B.json')
with tempfile.TemporaryDirectory(prefix='r49b-cold-') as tmp:
 p=pathlib.Path(tmp)/'r49b';shutil.copytree(ROOT,p)
 r=subprocess.run([sys.executable,str(p/'src'/'overlay.py')],capture_output=True,text=True,check=True)
 t=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(p/'tests'),'-q'],capture_output=True,text=True,check=True)
 if sha(p/'outputs'/'OVERLAY_ORIGEM_R49B.json')!=output:raise RuntimeError('overlay not deterministic')
 print('PASS R49B: 18/18 tests; output byte-identical; entries',len(meta['files']),r.stdout.strip())
