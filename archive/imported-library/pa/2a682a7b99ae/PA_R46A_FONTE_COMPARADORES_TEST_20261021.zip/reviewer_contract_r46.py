"""Peer review admission, R46 TEST. No external identity attestation by this code."""
import csv,hashlib,re,io
from engine_r46 import normalized_source_id
ALLOWED_RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário','INSUFICIENTE')
REQUIRED=('case_id','image_sha256','proposed_RE','system_comparator_url','live_comparator_url',
          'family_comparator_url','mechanical_rationale','limitations','reviewer_attestation',
          'independent_oracle_not_opened')

def check_peer_rows(rows,expected_hashes:dict):
    report=[]
    for x in rows:
        case=x.get('case_id','')
        faults=[]
        if case not in expected_hashes: faults.append('UNKNOWN_CASE')
        elif x.get('image_sha256')!=expected_hashes[case]: faults.append('SOURCE_IMAGE_SHA_MISMATCH')
        if x.get('proposed_RE') not in ALLOWED_RANKS: faults.append('INVALID_RANK')
        urls=[x.get(k,'').strip() for k in ('system_comparator_url','live_comparator_url','family_comparator_url')]
        if any(not u.startswith('https://app.notion.com/p/') for u in urls): faults.append('MISSING_CANONICAL_COMPARATOR_URL')
        if len(set(normalized_source_id(u) for u in urls if u))<3: faults.append('DUPLICATED_COMPARATORS')
        if len(x.get('mechanical_rationale','').strip())<60: faults.append('INSUFFICIENT_JUSTIFICATION')
        if not x.get('limitations','').strip(): faults.append('LIMITATIONS_NOT_DOCUMENTED')
        if x.get('reviewer_attestation','')!='YES': faults.append('NO_REVIEWER_ATTESTATION')
        if x.get('independent_oracle_not_opened','')!='YES': faults.append('ORACLE_EXPOSURE_NOT_ATTESTED')
        report.append({'case_id':case,'digital_check':'PASS_FORM_ONLY' if not faults else 'REJECT',
                       'faults':faults,'independent_human_identity_verified':False,
                       'canonical_rank_adjudicated':False})
    return report
