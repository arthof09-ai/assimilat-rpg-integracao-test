"""PA R46 TEST: evidence gate and non-destructive foreign-action bridge.
Not a canonical classifier, PA budgeter or magic manufacturing engine.
"""
from __future__ import annotations
import re, math
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

# DMG-RANK-01 v1.1, Notion Mestre, applies only to isolated, normal
# single-target offensive effects without strong control/area/bypass.
DMG_BANDS = {'Bronze': (4.,18.), 'Prata': (14.,36.),
             'Ouro': (22.,62.), 'Ouro Negro': (38.,96.),
             'Lendário': (58.,160.)}
RANKS=list(DMG_BANDS)

class DataQualityError(ValueError): pass


def normalized_source_id(x:str)->str:
    """Normalize stable Notion page IDs so cosmetic query params cannot fake independence."""
    if not isinstance(x,str) or not x.strip(): raise DataQualityError('missing_comparator_id')
    x=x.strip()
    try:
        u=urlparse(x)
        if u.scheme in ('http','https') and (u.hostname or '').lower() in ('app.notion.com','www.notion.so','notion.so'):
            # Notion URLs commonly end in the page's stable 32-hex UUID.
            stem=u.path.rstrip('/').split('/')[-1]
            uuid=re.search(r'([a-fA-F0-9]{32})$',stem.replace('-',''))
            if uuid: return 'notion_page_id:'+uuid.group(1).lower()
            return 'notion_url:'+u.path.rstrip('/').lower()
    except (ValueError, TypeError):
        pass
    return x.strip().lower()


def avg_dice(expr: str) -> float:
    """Average one nDm with optional signed fixed bonus; reject complex combos."""
    if not isinstance(expr,str): raise DataQualityError('expression_not_text')
    m=re.fullmatch(r'\s*(\d{1,3})\s*[dD]\s*(\d{1,3})\s*([+-]\s*\d{1,4})?\s*',expr)
    if not m: raise DataQualityError('ambiguous_or_unsupported_expression')
    n,d=int(m.group(1)),int(m.group(2))
    if n<1 or d<2 or n>100 or d>100: raise DataQualityError('invalid_dice')
    bonus=int(m.group(3).replace(' ','')) if m.group(3) else 0
    return n*(d+1)/2+bonus


def hypothetical_damage_bands(dme: float, *, direct_one_target:bool,
                              no_hard_control:bool, no_bypass:bool,
                              no_area:bool, not_conditional:bool) -> dict:
    """A descriptive DMG comparison, NEVER a canonical RE assertion."""
    if any(type(x) is not bool for x in [direct_one_target,no_hard_control,no_bypass,no_area,not_conditional]):
        raise DataQualityError('explicit_boolean_context_required')
    if not isinstance(dme,(int,float)) or not math.isfinite(dme) or dme<0 or dme>100000:
        raise DataQualityError('invalid_dme')
    eligibility=all([direct_one_target,no_hard_control,no_bypass,no_area,not_conditional])
    if not eligibility:
        return {'eligible':False,'ranks_matching_dmg_band':None,'adjudicated_re':None,
                'reason':'outside_normal_single_target_reference'}
    return {'eligible':True,
            'ranks_matching_dmg_band':[r for r,(lo,hi) in DMG_BANDS.items() if lo<=dme<=hi],
            'adjudicated_re':None,'reason':'overlapping_reference_not_rank_proof'}


def evidence_gate(rank:Optional[str],
                  source_ids:list[str],
                  categories:list[str],
                  *, authorized_adjudication:bool=False,
                  effect_text_verified:bool=False,
                  conflicting_evidence:bool=False)->dict:
    """Require three genuinely distinct comparator roles before even considering RE."""
    if rank not in (*RANKS,None): raise DataQualityError('invalid_rank')
    if len(source_ids)!=len(categories): raise DataQualityError('length_mismatch')
    if len(set(normalized_source_id(x) for x in source_ids))!=len(source_ids):
        raise DataQualityError('duplicate_source_not_independent')
    expected={'system','live','family'}
    observed=set(categories)
    if not observed.issubset(expected): raise DataQualityError('invalid_comparator_type')
    missing=sorted(expected-observed)
    review_ready=bool(rank is not None and authorized_adjudication and effect_text_verified and not missing and not conflicting_evidence)
    # Even an attested input does NOT prove a Notion canonical decision: this is
    # a local validation stage, not a persistent authoritative write.
    return {'adjudicated_re':None,
            'provisional_only_rank':rank,
            'comparators_missing':missing,
            'status':'READY_FOR_HUMAN_ADJUDICATION_NOT_CANON' if review_ready else 'HOLD_NEED_ADJUDICATION',
            'reason':[] if review_ready else (['missing_3_comparator_roles'] if missing else [])+
              (['no_authority'] if not authorized_adjudication else [])+
              (['source_unverified'] if not effect_text_verified else [])+
              (['conflict'] if conflicting_evidence else []),
            'canonical_write_executed':False}


def portability_gate(case:dict, *, native_pa_cost: Optional[int]=None,
                    concentration_contract_id:Optional[str]=None,
                    bonus_action_contract_id:Optional[str]=None,
                    source_save_contract_id:Optional[str]=None,
                    range_contract_id:Optional[str]=None,
                    source_progression_contract_id:Optional[str]=None) -> dict:
    """No automatic conversion of foreign rules to Assimilação."""
    action=(case.get('source_activation') or '').casefold()
    duration=(case.get('source_duration') or '').casefold()
    facts=(case.get('observed_mechanic_facts') or '').casefold()
    issues=[]
    if 'bônus' in action and not bonus_action_contract_id: issues.append('BONUS_ACTION_NO_NATIVE_MAPPING')
    if '(c)' in duration and not concentration_contract_id: issues.append('FOREIGN_CONCENTRATION_NO_NATIVE_MAINTENANCE')
    if case.get('source_save') and not source_save_contract_id: issues.append('SAVE_NATIVE_CONTRACT_PENDING')
    rang=(case.get('source_range') or '').casefold()
    if ('pés' in rang or 'feet' in rang or 'pés' in facts) and not range_contract_id:
        issues.append('FOREIGN_RANGE_UNIT_MAPPING_PENDING')
    if ('progressão' in facts or 'nível de origem' in facts or 'nível estrangeiro' in facts) and not source_progression_contract_id:
        issues.append('FOREIGN_LEVEL_SCALING_UNMAPPED')
    if native_pa_cost is None: issues.append('PA_COST_UNKNOWN_NOT_ZERO')
    elif not isinstance(native_pa_cost,int) or native_pa_cost<0: raise DataQualityError('invalid_pa_cost')
    # All adaptations are TEST pending explicit authorization and source-level verification.
    return {'case_id':case['case_id'],'native_action_candidate':'Ação Padrão' if action=='ação' else None,
            'native_action_approved':None,'native_pa_cost':native_pa_cost,'issues':sorted(set(issues)),
            'source_durations_preserved':case.get('source_duration'),
            'native_playable':False,'cost_debit_executed':False,
            'status':'TEST_DRAFT_NOT_FOR_PLAY'}


def p2_reconciliation(*,salt_bom='Santo',salt_step='Encantado',
                      energizer_bom=True,energizer_process=False,
                      oil_ingredients_complete=True,oil_process_complete=False,
                      lot_available=False,operator_verified=False)->dict:
    blockers=[]
    if salt_bom!=salt_step: blockers.append('P2_SALT_CONTRADICTION')
    if energizer_bom and not energizer_process: blockers.append('P2_ENERGY_STEP_MISSING')
    if oil_ingredients_complete and not oil_process_complete: blockers.append('OIL_PROCESS_NOT_RECONCILED')
    if not lot_available: blockers.append('NO_TRACEABLE_LOT')
    if not operator_verified: blockers.append('NO_AUTHORIZED_OPERATOR')
    return {'status':'HOLD_NO_APPLICATION' if blockers else 'PREFLIGHT_TEST_READY_FOR_AUTHORITY_REVIEW',
            'blockers':blockers,'installed_magic_verified':False,
            'consumed_inventory':False,'pa_debited':False,'manufactured_rc5':False}
