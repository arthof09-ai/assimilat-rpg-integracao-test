import unittest,random,hashlib,math
from engine_r46 import normalized_source_id,evidence_gate,hypothetical_damage_bands,DataQualityError
from reviewer_contract_r46 import check_peer_rows

A='https://app.notion.com/p/3edc2b324ede81b696b0d75191b7a5ec'
B='https://app.notion.com/p/3edc2b324ede8115a287e69daf383b38'
C='https://app.notion.com/p/3f5c2b324ede81e9aa8ec51f568600e8'

class TestGuardHardening(unittest.TestCase):
 def test0_notion_url_query_cannot_duplicate(self):
  self.assertEqual(normalized_source_id(A),normalized_source_id(A+'?pvs=204&foo=bar'))
  with self.assertRaises(DataQualityError):evidence_gate('Prata',[A,A+'?pvs=204',B],['system','live','family'])
 def test1_www_notion_so_same_page(self):
  alt='https://www.notion.so/3edc2b324ede81b696b0d75191b7a5ec'
  self.assertEqual(normalized_source_id(A),normalized_source_id(alt))
 def test2_hyphen_UUID_same_page(self):
  alt='https://www.notion.so/3edc2b32-4ede-81b6-96b0-d75191b7a5ec'
  self.assertEqual(normalized_source_id(A),normalized_source_id(alt))
 def test3_two_different_actual_ids(self):
  self.assertNotEqual(normalized_source_id(A),normalized_source_id(B))
 def test4_nan_rejected(self):
  with self.assertRaises(DataQualityError):hypothetical_damage_bands(float('nan'),direct_one_target=True,no_hard_control=True,no_bypass=True,no_area=True,not_conditional=True)
 def test5_inf_rejected(self):
  with self.assertRaises(DataQualityError):hypothetical_damage_bands(float('inf'),direct_one_target=True,no_hard_control=True,no_bypass=True,no_area=True,not_conditional=True)
 def test6_peer_attest_not_canon(self):
  sha='0'*64
  row={'case_id':'C','image_sha256':sha,'proposed_RE':'Prata','system_comparator_url':A,'live_comparator_url':B,
       'family_comparator_url':C,'mechanical_rationale':'Mecânica investigada com várias fontes e condições reais incluindo restrição; apenas parecer TEST, não decisão final.',
       'limitations':'Falta verificação independente','reviewer_attestation':'YES','independent_oracle_not_opened':'YES'}
  result=check_peer_rows([row],{'C':sha})[0]
  self.assertEqual(result['digital_check'],'PASS_FORM_ONLY')
  self.assertFalse(result['canonical_rank_adjudicated'])
 def test7_duplicate_peer_query_rejected(self):
  sha='a'*64
  row={'case_id':'C','image_sha256':sha,'proposed_RE':'Prata','system_comparator_url':A,'live_comparator_url':B,
       'family_comparator_url':A+'?pvs=204','mechanical_rationale':'Mecânica investigada com várias fontes e condições reais incluindo restrição; apenas parecer TEST, não decisão final.',
       'limitations':'Falta verificação independente','reviewer_attestation':'YES','independent_oracle_not_opened':'YES'}
  result=check_peer_rows([row],{'C':sha})[0]
  self.assertIn('DUPLICATED_COMPARATORS',result['faults'])
 def test8_arbitrary_authority_assertion_still_not_canon(self):
  r=evidence_gate('Ouro',[A,B,C],['system','live','family'],authorized_adjudication=True,effect_text_verified=True)
  self.assertTrue(r['status'].startswith('READY_FOR'))
  self.assertIsNone(r['adjudicated_re'])
 def test9_metastress_1000_duplicates(self):
  rng=random.Random(20261021)
  for _ in range(1000):
   q='?pvs='+str(rng.randint(0,100000))+'&utm_source=legacy'
   with self.assertRaises(DataQualityError):evidence_gate('Prata',[A,A+q,B],['system','live','family'])
 def test10_metastress_1000_nonanomalous(self):
  for _ in range(1000):
   r=evidence_gate('Prata',[A,B,C],['system','live','family'],effect_text_verified=True,authorized_adjudication=True)
   self.assertIsNone(r['adjudicated_re'])

if __name__=='__main__': unittest.main()
