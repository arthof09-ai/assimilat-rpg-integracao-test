# R46A — adendo de robustez para PA/CRAFT (MESTRE-ONLY / TEST)

Não substitui sozinho o pacote R46 nem cria norma de jogo. O pacote original [R46 TEST](../PA_R46_PA_CRAFT_EVIDENCE_TEST_20261021.zip) foi preservado na Biblioteca /Comestre e já passou por readback e replay de 43 testes. Este adendo corrige um risco técnico não previsto na primeira implementação do gate de evidência.

## Adendo de proteção real

1. **Comparadores distintos por ID, não por grafia:** `?pvs=` ou variante da URL do mesmo Notion não contam como duas fontes. A antiga validação tratava strings distintas como fontes distintas; agora a normalização usa o UUID do documento quando conhecido.
2. **RE canônico permanece impossível via programa:** mesmo com 3 comparadores preenchidos e sinalizador de autoridade, o retorno é só `READY_FOR_HUMAN_ADJUDICATION_NOT_CANON`, sem escrever fichas.
3. **DME não finito bloqueado:** NaN e infinito não geram bandas de classificação.
4. **Revisor independente não equivale a formulário preenchido:** algoritmo exige declarações mas não prova identidade humana ou ausência de contaminação de oráculo.

## Testes adicionais

`python -m unittest test_hardening_r46a -q`: 11 testes, incluindo duas campanhas determinísticas de 1.000 entradas (uma com URLs duplicadas disfarçadas e outra testando vedação de canonização). `python science_overlap_r46a.py` mede sobreposição de bandas do DMG-RANK-01 v1.1.

Para DME inteiro 4…160, 79/157 valores cabem em *mais de um* rank numérico, e 5/157 cabem em *três*. Esta é uma estatística aritmética descritiva da tabela normativa, não inferência de rank de habilidades nem medida empírica de precisão.

## Gate de conclusão

PASS software e anti-duplicata de comparador. HOLD adjudicação independente, regras de transporte, P2/óleo/lote, magia e fabricação. Não atualizar fichas originais, R26/R27, Party/O Primeiro.
