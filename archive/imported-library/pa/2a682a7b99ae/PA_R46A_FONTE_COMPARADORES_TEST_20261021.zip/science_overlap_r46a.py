"""Purely descriptive rank-band ambiguity. Ranks never chosen by DME alone."""
import json
from engine_r46 import DMG_BANDS
rows=[]
for dme in range(4,161):
 ranks=[k for k,(a,b) in DMG_BANDS.items() if a<=dme<=b]
 rows.append({'dme_integer':dme,'rank_band_matches':ranks,'n_matching_bands':len(ranks)})
summary={'range_integers_4_to_160':len(rows),'single_band':sum(x['n_matching_bands']==1 for x in rows),
         'multiple_bands':sum(x['n_matching_bands']>=2 for x in rows),
         'triple_band':sum(x['n_matching_bands']>=3 for x in rows),
         'DME_not_sufficient_to_infer_RE':True,
         'notes':'Reference-only calculation, not observed ability accuracy; incomplete information about reach/control/action/context.'}
open('R46A_DMG_BAND_OVERLAPS.json','w').write(json.dumps({'summary':summary,'rows':rows},indent=2,ensure_ascii=False))
print(summary)
