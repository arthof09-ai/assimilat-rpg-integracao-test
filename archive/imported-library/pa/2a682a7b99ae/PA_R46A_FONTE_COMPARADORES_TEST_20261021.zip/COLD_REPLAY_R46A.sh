#!/bin/sh
set -eu
cd "$(dirname "$0")"
python science_overlap_r46a.py
python -m unittest test_hardening_r46a -q
python - <<'PY'
import json,hashlib
from pathlib import Path
p=Path('MANIFEST_SHA256.json')
if p.exists():
 for n,h in json.loads(p.read_text()).items():
  assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
 print('R46A_MANIFEST_OK')
PY
