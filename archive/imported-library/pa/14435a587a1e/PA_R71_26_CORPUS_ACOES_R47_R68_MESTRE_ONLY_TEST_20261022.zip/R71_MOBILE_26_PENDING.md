# R71 — Fechamento de cobertura 26/26 das adaptações ainda PENDENTES

O diagnóstico não cria outro sistema nem restaura custos automaticamente. Reconciliou **R47 existente** (26 casos), **R68** (14 cartões relidos visualmente) e **R61** (correção pontual de E353), mantendo os arquivos originais intactos.

| Problema verificável no corpus | 14 cartões relidos | Outros 12 casos | Total 26 |
|---|---:|---:|---:|
| Conjuração original por ação bônus estrangeira | 4 | 2 | **6** |
| Duração com marcador de concentração (C) estrangeiro | 8 | 4 | **12** |
| Conjuração original por reação | 1 | 1 | **2** |
| Conjuração por ação original simples | 9 | 9 | **18** |
| Ação bônus **secundária** descrita no efeito (não conjuração) | 0 | 1 | **1** |

Outras lacunas já diagnosticadas no R47: **16** conversões de alcance estrangeiro não adjudicadas, **12** salvaguardas nativas pendentes, **8** escalas por nível estrangeiro. **0/26 efeitos liberados para jogo**; 0 custos novos de PA conhecidos; 0 homologações de RE isolado. As contagens são sobrepostos por caso, não somáveis como se fossem 26 problemas distintos.

**Correção conhecida não pode regredir:** `TEC-E3532F6A98AC` (Proteção Contra Lâminas) está como `reação` no texto original R45 por erro de transcrição. R46/R47 e inspeção de imagem R61 apontam `1 AÇÃO`; usar adaptação candidata Ação Padrão somente como TEST, não como decisão de autoridade E0.

**Outra distinção material:** `TEC-988589FB9716` contém **ação bônus secundária** dentro da descrição do efeito apesar de sua ativação principal ser `ação`; não a perder ao converter só cabeçalho. R47 já mantinha a distinção, este readback confirma.

Este relatório preserva o denominador **26=14+12**, evita redescobrir pendências antigas e instrui a próxima etapa: para cada versão, mapear explicitamente ação/duração/concentração/alcance/salvaguarda/escala antes de classificar RE e calcular PA. As fichas históricas, o R45/R46/R47, a Party e O Primeiro NÃO foram modificados. Notion R64+ continua sem sync documental pelo bloqueio de segurança da ferramenta.
