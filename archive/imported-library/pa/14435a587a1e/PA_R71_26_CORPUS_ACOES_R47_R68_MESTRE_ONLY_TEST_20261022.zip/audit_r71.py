"""Readback QA only. Does not implement native conversion and cannot approve RE/PA."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json
ROOT=Path('/mnt/data/pa_sucessao')
SOURCE={
 'R47':('sources/PA_R47_ROBUSTEZ_PA_CRAFT_MESTRE_ONLY_TEST_20261021.zip','ec59d0f7f5916b74cc9b673398a2c890f762824bd1936eaf495598e5ab79b510'),
 'R61':('PA_R61_E353_CORRECAO_ACAO_R45_R47_MESTRE_ONLY_TEST_20261022.zip','c048291295b34603f175c9bd99cda930267b50d047c18074e8b3b5eda4714206'),
 'R68':('PA_R68_ACTION_CONCENTRATION_FOREIGN_ADAPTER_HOLD_MESTRE_ONLY_TEST_20261022.zip','4ac7b7ef2fbdea2e2f232b4d5100d28e74a6051c78a441a2469c8a404c2055b9')}

def hold(why):return {'status':'HOLD_R71_RECONCILIATION', 'reason':why,'official_PA':None,'E0':0,'party_write':False}
def check(doc,root=ROOT):
 try:
  d=json.loads(Path(doc).read_text(encoding='utf8'))
  pp={k:root/path for k,(path,_) in SOURCE.items()}
  for k,(path,digest) in SOURCE.items():
   if hashlib.sha256(pp[k].read_bytes()).hexdigest()!=digest:return hold('SOURCE_HASH_'+k)
  with ZipFile(pp['R47']) as z:
   c=json.loads(z.read('out/R47_PORTABILITY_CORRECTED_26.json'))
  with ZipFile(pp['R61']) as z:e=json.loads(z.read('evidence/R61_CASE_FILE.json'))
  with ZipFile(pp['R68']) as z:v=json.loads(z.read('R68_FOREIGN_ACTION_DOSSIER_MESTRE_ONLY.json'))
  rows={r['case_id']:r for r in c['rows']};peer={r['case_id'] for r in v['records']};other=set(rows)-peer
  if len(rows)!=26 or len(peer)!=14 or len(other)!=12:return hold('DENOMINATOR_26_14_12')
  def counts(ids):return {'count':len(ids),'bonus':sum(rows[i]['source_activation']=='ação bônus' for i in ids),
   'concentration':sum('(C)' in rows[i]['source_duration'] for i in ids),'reaction':sum(rows[i]['source_activation']=='reação' for i in ids),
   'action':sum(rows[i]['source_activation']=='ação' for i in ids),
   'secondary_bonus':sum(rows[i]['source_secondary_bonus_action'] for i in ids)}
  if d['peer14']!=counts(peer) or d['original12']!=counts(other):return hold('COHORT_COUNTS_DO_NOT_AGREE_WITH_R47')
  if d['foreign_issues_total']!={'cast_bonus':6,'concentration':12,'secondary_bonus':1,'foreign_level':8,'foreign_range':16,'foreign_save':12}:return hold('FOREIGN_ISSUE_COUNTS')
  if rows[e['case']]['source_activation']!='ação' or e['original_mecanics_verified_visually_2026_10_22']['activation']!='1 AÇÃO':return hold('E353_VISUAL_CORRECTION')
  if d['E353_case']['r47_corrected_source']!='ação' or d['E353_case']['r45_stale_source']!='reação' or d['E353_case']['RE_E0'] is not None or d['E353_case']['official_PA'] is not None:return hold('E353_CASE_PROMOTED')
  if not rows['TEC-988589FB9716']['source_secondary_bonus_action'] or rows['TEC-988589FB9716']['source_activation']!='ação':return hold('SECONDARY_BONUS_DROPPED')
  if d['special_secondary']['case_id']!='TEC-988589FB9716' or d['special_secondary']['action_header']!='ação':return hold('SECONDARY_MERGED')
  if c['native_playable_count']!=0 or c['PA_cost_known_count']!=0 or d['playability']!={'native_playable':0,'pa_known':0,'effect_E0':0,'peer_reviews_received':0}:return hold('FAKE_READINESS')
  for k in ['notion_write','party_write','O_Primeiro_write']:
   if d['assertions'][k] is not False:return hold('FORBIDDEN_WRITE')
  if d['total_26']!=26:return hold('FAKE_DENOMINATOR')
  return {'status':'PASS_R71_CROSS_COHORT_26_AUDIT_ONLY','total':26,'peer14':14,'other12':12,'cast_bonus':6,'concentration_marker':12,
   'secondary_bonus':1,'source_corrected_E353':True,'native_playable':0,'official_pa':None,'E0':0,'notion_write':False,'party_write':False}
 except (KeyError,TypeError,ValueError,IndexError,OSError) as exc:return hold('SOURCE_OR_SCHEMA_'+type(exc).__name__)
