# R71 — Censo reconciliado 26/26 do corpus TEST de técnicas

Confere as coortes **14 cartões relidos em R68 + 12 casos anteriores** contra o relatório **já existente em R47**, preservando a correção R61 de E353 (1 AÇÃO, não reação) e a única ação-bônus SECUNDÁRIA, distinta da ativação. Não é um motor de combate, PA ou adaptação; não acrescenta norma nem modifica as fontes.

Para verificar a evidência num ambiente que possui R47/R61/R68 em seus paths originais: `PA_SOURCE_ROOT=/mnt/data/pa_sucessao python test_r71.py`. Os arquivos-fonte são validados por SHA fixo; alteração exige nova reconciliação. 13 novos testes documentais, separados do R70 (135 replayados e 8 testes próprios).

26/26 ainda não jogáveis nem homologados individualmente; 0 custos de PA novos, 0 pareceres independentes da coorte 14, 0 escrita Party/Notion/O Primeiro. Notion continua sync até R63; R64+ persistem na Biblioteca aguardando canal de escrita legítimo.
