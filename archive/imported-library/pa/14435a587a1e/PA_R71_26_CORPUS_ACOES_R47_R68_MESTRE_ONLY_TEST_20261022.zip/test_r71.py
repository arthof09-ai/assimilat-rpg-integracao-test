import unittest,copy,json,tempfile,os
from pathlib import Path
from audit_r71 import check
ROOT=Path(os.environ.get('PA_SOURCE_ROOT','/mnt/data/pa_sucessao'))
DOC=Path(__file__).resolve().parent/'R71_26_COVERAGE_MESTRE_ONLY.json'
class T(unittest.TestCase):
 def setUp(self):self.d=json.loads(DOC.read_text())
 def mutate(self,cb):
  d=copy.deepcopy(self.d);cb(d)
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'m.json';p.write_text(json.dumps(d));return check(p,ROOT)
 def test_positive(self):self.assertTrue(check(DOC,ROOT)['status'].startswith('PASS'))
 def test_corrected_action_counts(self):self.assertEqual(self.d['peer14']['action']+self.d['original12']['action'],18)
 def test_corrected_reaction_counts(self):self.assertEqual(self.d['peer14']['reaction']+self.d['original12']['reaction'],2)
 def test_6_bonus(self):self.assertEqual(self.d['foreign_issues_total']['cast_bonus'],6)
 def test_12_concentration(self):self.assertEqual(self.d['foreign_issues_total']['concentration'],12)
 def test_1_secondary(self):self.assertEqual(self.d['foreign_issues_total']['secondary_bonus'],1)
 def test_change_14(self):self.assertIn('COHORT',self.mutate(lambda x:x['peer14'].update(bonus=3))['reason'])
 def test_change_12(self):self.assertIn('COHORT',self.mutate(lambda x:x['original12'].update(concentration=3))['reason'])
 def test_wrong_e353(self):self.assertIn('E353',self.mutate(lambda x:x['E353_case'].update(r47_corrected_source='reação'))['reason'])
 def test_fake_pa(self):self.assertIn('E353',self.mutate(lambda x:x['E353_case'].update(official_PA=7))['reason'])
 def test_fake_playable(self):self.assertIn('FAKE_READINESS',self.mutate(lambda x:x['playability'].update(native_playable=26))['reason'])
 def test_party_write(self):self.assertIn('FORBIDDEN_WRITE',self.mutate(lambda x:x['assertions'].update(party_write=True))['reason'])
 def test_wrong_total(self):self.assertIn('FAKE_DENOMINATOR',self.mutate(lambda x:x.update(total_26=25))['reason'])
if __name__=='__main__':unittest.main(verbosity=2)
