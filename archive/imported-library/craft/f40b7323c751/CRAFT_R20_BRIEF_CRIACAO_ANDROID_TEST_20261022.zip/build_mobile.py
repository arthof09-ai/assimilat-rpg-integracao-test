import json, pathlib, html
base=pathlib.Path(__file__).resolve().parent
validator=(base/'src/validate.js').read_text()
products=(base/'data/proposals.json').read_text()
resources=(base/'data/resources.json').read_text()
mastercards=(base/'data/master_cards_13.json').read_text()
economics=(base/'data/economic_case.json').read_text()
econ_validator=(base/'src/economic_gate.js').read_text()
# JSON inside JS as assignments; replaces '</' to avoid injection if later modified.
products_safe=products.replace('</','<\\/')
resources_safe=resources.replace('</','<\\/')
mastercards_safe=mastercards.replace('</','<\\/')
economics_safe=economics.replace('</','<\\/')
page='''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>R53 — Auditor de Itens & Recursos TEST</title>
<style>
:root { color-scheme:dark; font-family:system-ui,-apple-system,Segoe UI,sans-serif; background:#0c1420; color:#edf4ff; }
* {box-sizing:border-box;} body{margin:0; padding:16px; max-width:930px; margin-inline:auto;}
h1{font-size:1.45rem;letter-spacing:-.02em;margin:.5rem 0} h2{font-size:1.08rem;margin:0 0 .55rem}
p{line-height:1.5;color:#cbd9ee}
header{padding:8px 0 16px;} .small{font-size:.85rem;color:#abc0d9}
.box{border:1px solid #33455e;border-radius:14px;padding:16px;background:#121e2e;margin-bottom:13px;overflow-wrap:anywhere}
.tag{display:inline-block;padding:4px 10px;border-radius:99px;background:#4c3a21;color:#ffdfad;font-weight:650;font-size:.76rem;letter-spacing:.02em}
.stat{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px}.stat div{border-radius:10px;background:#1d2b3d;padding:10px}
.stat strong{display:block;font-size:1.5rem}.stat small{color:#b3c6df}
button,.btn{border:0;display:inline-block;border-radius:10px;background:#d2e2ff;color:#082443;padding:11px 13px;font-size:.89rem;font-weight:650;cursor:pointer;margin-right:7px;margin-top:5px}button.secondary{background:#293b54;color:#eaf1ff}
input[type=file]{display:block;width:100%;max-width:100%;font-size:.84rem;color:#fff;border:1px dashed #577390;border-radius:8px;padding:10px;margin:10px 0}
select{background:#1b2d44;color:#fff;border:1px solid #587392;font-size:1rem;border-radius:10px;padding:10px;width:100%}
input[type=text],textarea{background:#1b2d44;color:#fff;border:1px solid #587392;font-size:1rem;border-radius:10px;padding:10px;width:100%;margin:6px 0 12px}label{display:block;font-size:.83rem;color:#c1d8ef;margin-top:11px}
ul{padding-left:21px;line-height:1.55} li{margin-bottom:5px} .mono{font-family:ui-monospace,Consolas,monospace;font-size:.79rem;color:#b6c9e2;white-space:pre-wrap;overflow-wrap:anywhere}
a{color:#a7cfff} details{border-top:1px solid #34445a;padding:10px 0} pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.78rem;color:#c9d7e9} summary{cursor:pointer;font-weight:600}
hr{border:0;border-top:1px solid #32465e;margin:15px 0}.warn{color:#ffcc90}.ok{color:#9bdfc3} footer{padding:12px 0 25px}
@media (max-width:450px){body{padding:10px} .box{padding:13px} button{width:100%;margin:5px 0} h1{font-size:1.25rem}}
</style></head><body>
<header><span class="tag">MESTRE-SIDE · TEST · SEM PUBLICAÇÃO</span><h1>R53 · Auditor de criação de itens e recursos</h1><p>Ferramenta local para revisar propostas conforme PR-ITEM-02 e REC-EXEC. Não exige login, não envia dados para servidores e não cria itens no Notion.</p></header>
<section class="box"><h2>Carregar proposta</h2><p class="small">Abra o arquivo <code>proposals.json</code> fornecido no pacote, ou revise os dois exemplos já carregados. Este aplicativo usa um índice congelado de cinco fontes consultadas em 21/10/2026; mudanças posteriores exigem releitura no Notion.</p>
<input type="file" id="upload" accept="application/json,.json"/><button id="check">Validar propostas</button><button id="save" class="secondary">Salvar diagnóstico JSON</button><button id="evidence" class="secondary">Baixar roteiro de TODOS os projetos (Mestre TEST)</button><button id="rejected-plan" class="secondary" disabled>Baixar correções do arquivo rejeitado (Mestre TEST)</button><div id="loadStatus" class="small" role="status">Exemplos locais prontos.</div></section>
<section class="box" id="creation-brief"><h2>Iniciar criação pelo celular — somente briefing TEST</h2><p class="small">Não gera item, recurso ou receita. Prepare uma solicitação ao Comestre para pesquisar o cânone e analisar viabilidade; os campos continuam PENDENTES até revisão.</p><label for="brief-kind">Tipo do pedido</label><select id="brief-kind"><option value="RESOURCE">Recurso / ingrediente</option><option value="ITEM" selected>Item / equipamento</option><option value="RECIPE">Receita de item</option></select><label for="brief-name">Nome provisório</label><input id="brief-name" type="text" maxlength="180" placeholder="Ex.: peça de medição de estática"/><label for="brief-intent">Função desejada (sem prometer efeito)</label><textarea id="brief-intent" rows="4" maxlength="2000" placeholder="O que deve fazer, para quem e em qual contexto?"></textarea><button id="brief-export" class="secondary">Baixar briefing de criação (Mestre TEST)</button><div id="brief-status" class="small" role="status">Nenhum briefing iniciado. Nenhuma ficha é criada aqui.</div></section>
<section class="box"><h2>Resumo da auditoria</h2><div id="top" class="stat"></div></section><section class="box"><h2>Projetos por página</h2><div id="pager" class="small" aria-live="polite">Aguardando auditoria.</div><button id="prev" class="secondary">Página anterior</button><button id="next" class="secondary">Próxima página</button></section>
<section class="box"><h2>Economia — quatro valores diferentes</h2><div id="economy" class="small"></div></section><section id="cards" aria-live="polite"></section>
<footer class="small">Atenção: PASS de formulário não significa receita RC5, efeito mágico instalado, existência material, aprovação do Mestre, preço ou RE homologado. Não compartilhar com Party/O Primeiro.</footer>
<script>
'''+validator+econ_validator+'''
const INDEX = '''+resources_safe+''';
let PROJECT = '''+products_safe+''';
const MASTER_CARDS = '''+mastercards_safe+''';
const ECON_CASE = '''+economics_safe+''';
function safe(t){return String(t??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');}
let current;
let rejectedPlan=null; // somente roteiro sanitizado, NÃO armazena projeto rejeitado como ativo
let pageIndex=0;const PAGE_SIZE=8;
// R14: visão local dos códigos já emitidos pelo motor R53. NÃO valida laudos R46.
const R14_ACTIONS = [
 {code:'LIVE_SOURCE_RECHECK',priority:'P0',title:'Reler as fontes Mestre vigentes',
   fields:['UUID da fonte','URL canônica','data da leitura','diferença versus snapshot R53','responsável pela leitura'],authority:'Notion Mestre read-only'},
 {code:'SOURCE_PENDING',priority:'P1',title:'Identificar material e forma física',
   fields:['nome do recurso ou comum','função BOM','fonte existente comprovada ou lacuna','quantidade e unidade','lote ou fornecedor'],authority:'REC-EXEC / EXISTING-FIRST'},
 {code:'BOM_QUANTITY_PENDING',priority:'P1',title:'Completar quantidades de BOM',
   fields:['node_id','quantidade mensurável','unidade','tipo de consumo','justificativa da dose'],authority:'PR-ITEM-02 / REC-EXEC'},
 {code:'RECIPE_NOT_EXECUTABLE',priority:'P1',title:'Fechar parâmetros reproduzíveis da receita',
   fields:['rendimento','perda','tempo','especialista qualificado','armazenamento','procedimento e controles'],authority:'REC-EXEC'},
 {code:'MECHANICS_PENDING',priority:'P1',title:'Especificar efeitos sem inventar dados',
   fields:['ativação','duração','alcance','recarga','fonte da regra e versão','teste independente'],authority:'PR-ITEM-02 / fornecedor PA'},
 {code:'MAGIC_NOT_DEMONSTRATED',priority:'P2',title:'Preparar comprovação física e mágica R46',
   fields:['ID de amostra','fonte e lote','instrumento e calibração válida','operador','testemunha/custódia','medida, unidade e incerteza','tolerância e controle comum','laudo assinado','observação de transferência/retensão'],authority:'R46 nativo; exigir laudo independente'},
 {code:'ECONOMY_PENDING',priority:'P2',title:'Reconciliar economia sem misturar preços',
   fields:['custo dos insumos','UTE','CTE','preço referência','preço local','preço realizado, se houver','fonte, data e confiança'],authority:'PR-ECO / Anexo C'}
];
// R18: orientações para ERROS CRÍTICOS já emitidos pelo MESMO validador R53.
// Agrupamento de apresentação e coleta de dados, NÃO nova regra nem novo motor.
// Prioridade P0 abaixo é prioridade visual de correção do arquivo TEST,
// NÃO suplanta P0 material F5/IBX38, nem cria ordem operacional nova.
const R18_ISSUE_ACTIONS = [
 {codes:['PARTY_EXPOSURE','PLAYER_SECRET_CROSSOVER','PLAYER_VIEW_SCHEMA','PLAYER_FIELD_TYPE_INVALID'],title:'Isolar camada Player e eliminar vazamento de segredo',authority:'PR-ITEM-02 / PR-SC-01',fields:['campo Player afetado','comparação Mestre-only','redação publicável somente após autorização','evidência de revisão humana']},
 {codes:['UNVERIFIED_RESOURCE','SOURCE_UUID_INVALID','SOURCE_IDENTITY_MISMATCH','SOURCE_URL_MISMATCH','SOURCE_SNAPSHOT_MISMATCH','SOURCE_INDEX_SCHEMA','SOURCE_EVIDENCE_MISSING','SOURCE_DUPLICATE_ID'],title:'Rastrear fonte física/UUID e verificar identidade em Notion Mestre',authority:'PR-CRN-01 / REC-EXEC',fields:['UUID canônico do recurso','URL e parent Mestre','nome/função','estado da busca EXISTING-FIRST','data e responsável do readback','rejeição de aliases não provados']},
 {codes:['BOM_PROCESS_MISMATCH','PHANTOM_INPUT','BOM_COLLISION','PROCESS_STEP_INVALID','PROCESS_INPUTS_INVALID','PROCESS_UNSPECIFIED','PROCESS_ORDER','MISSING_BOM','BOM_EMPTY','PROCESS_EMPTY','BOM_NODE_INVALID','INVALID_QUANTITY','BOM_UNIT_INVALID','BOM_ROLE_MISSING','BOM_CONSUMED_INVALID'],title:'Reconectar BOM a etapas e unidades do processo',authority:'REC-EXEC / REC-MOD específico',fields:['REC-ID e versão histórica se existente','node_id e papel','quantidade/unidade','consumo/reutilização','etapa que usa o nó','conflito de nomenclatura','aprovação de substituto se necessário']},
 {codes:['RANK_SHORTCUT','PA_UNAUTHORIZED','SOURCE_EFFECT_RANK_LEAK'],title:'Separar RI, RE, RIn/FIP e PA fornecedor',authority:'PR-ITEM-02 / Atlas / Sistema PA',fields:['efeito proposto','comparador rank/Atlas','RI/RE evidenciados separadamente','recibo PA/versão','status de avaliação do Mestre']},
 {codes:['FABRICATION_UNVERIFIED','PHYSICAL_CLAIM','MUTATION_NOT_ALLOWED'],title:'Retirar reivindicação de fabricação, magia, estoque ou Party sem prova',authority:'R46 / NAC-CONT-03 / PR-SC-01',fields:['qual reivindicação ocorreu','amostra, lote e laudo real se houver','instrumento/calibração/operador','fencing e writer efetivos','retificação para estado TEST']},
 {codes:['UNSUPPORTED_ECONOMY'],title:'Suspender preço/custo e coletar árvore econômica auditável',authority:'PR-ECO-01 Anexo C',fields:['UTE','cesta e quantidades','rendimento e perdas','mercado/época','CTE ou preço de referência comprovado','fonte de preço']},
 {codes:['MODULE_MISMATCH','TEXT_FIELD_INVALID','MECHANIC_TYPE_INVALID','MISSING_FIELD','PROJECT_OBJECT_INVALID','PROJECTS_REQUIRED','DUPLICATE_PROPOSAL','NOT_SANDBOX','ANTI_DUP_UNPROVEN'],title:'Reparar identidade, esquema e pesquisa prévia do item TEST',authority:'PR-ITEM-02 / PR-CRN-01 / PR-SC-01',fields:['família e módulo correto','nome e UUID do objeto','status TEST','identidade sem duplicata','pesquisa produto/receita/insumo','campos mínimos com fonte']}
];
function evidencePlan(reports){
 return {schema:'CRAFT_R14_EVIDENCE_REQUEST_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
   purpose:'SOLICITACAO_DE_EVIDENCIAS_NAO_E_LAUDO_NEM_AUTORIZACAO',
   authority:'PR-ITEM-02 / REC-EXEC / R46; sem substituir instrumentos existentes',
   requires_human_source_review:true,release_gate:'NO_PRODUCTION_NO_PARTY_PUBLICATION',
   projects:reports.map(r=>{
    const codes=new Set((r.holds||[]).map(h=>h.code));
    const tasks=R14_ACTIONS.filter(a=>codes.has(a.code)).map(a=>({
      priority:a.priority,source_hold:a.code,title:a.title,authority:a.authority,
      state:'PENDENTE_NAO_OBSERVADO',required_fields:a.fields,observed_data:null,
      approved_for_production:false}));
    const issueCodes=new Set((r.issues||[]).map(e=>e&&e.code).filter(c=>typeof c==='string'));
    const repairs=R18_ISSUE_ACTIONS.filter(a=>a.codes.some(code=>issueCodes.has(code))).map(a=>({
      priority:'P0',source_issue_codes:a.codes.filter(code=>issueCodes.has(code)),title:a.title,
      authority:a.authority,state:'PENDENTE_NAO_OBSERVADO',required_fields:a.fields,
      observed_data:null,approved_for_production:false}));
    const mapped=new Set(repairs.flatMap(t=>t.source_issue_codes));
    const unmapped=[...issueCodes].filter(c=>!mapped.has(c));
    if(unmapped.length)repairs.push({priority:'P0',source_issue_codes:unmapped,
      title:'Triagem manual de código crítico sem extrapolar a norma',authority:'PR-ITEM-02 / REC-EXEC / NAC',
      state:'PENDENTE_NAO_OBSERVADO',required_fields:['código e versão','entrada original em área Mestre','fonte normativa vigente','decisão técnica humana'],
      observed_data:null,approved_for_production:false});
    return {proposal_id:r.id,proposal_name:r.name,validator_verdict:r.verdict,
      blocking_errors:(r.issues||[]).map(e=>e.code),
      source_urls:(r.evidence||[]).map(e=>e.source_url).filter((v,i,arr)=>arr.indexOf(v)===i),
      methodology_snapshot:{
        existing_source_matches:r.methodology?.resource?.existing_index_matches ?? 0,
        unresolved_bom_nodes:r.methodology?.resource?.unresolved_material_nodes ?? [],
        no_new_crn_without_gap:true,
        bom_quantified_nodes:r.methodology?.recipe?.bom_quantified_nodes ?? 0,
        bom_total_nodes:r.methodology?.recipe?.bom_nodes ?? 0,
        production_parameters_missing:r.methodology?.recipe?.production_parameters_missing ?? [],
        power_pa_recipe_verification_pending:true,
        publication_and_stock_denied:true},
      missing_evidence:[...repairs,...tasks],physical_success:false,magic_transfer_proved:false,
      canonical_item_created:false,party_release_authorized:false};
   })};
}
function render(revalidate=true){
 if(revalidate||!current)current=valid(PROJECT,INDEX);
 const pageCount=Math.max(1,Math.ceil((current.items||[]).length/PAGE_SIZE));
 pageIndex=Math.max(0,Math.min(pageIndex,pageCount-1));
 const start=pageIndex*PAGE_SIZE;
 const pageItems=(current.items||[]).slice(start,start+PAGE_SIZE);
 document.getElementById('pager').textContent=`Página ${pageIndex+1} de ${pageCount} — ${current.total} projetos auditados (mostrando ${pageItems.length})`;
 document.getElementById('prev').disabled=pageIndex===0;
 document.getElementById('next').disabled=pageIndex>=pageCount-1;
 const e=reviewCost(ECON_CASE); document.getElementById('economy').innerHTML=`<p class="warn">${safe(e.gate)} · Sem preço de produto calculável</p><p>Para o tônico, valores históricos dos recursos NÃO equivalem a preço de poção ou a CTE. Pendências: ${e.pending.map(safe).join(', ')}.</p>`;
 document.getElementById('top').innerHTML = `<div><small>Projetos examinados</small><strong>${current.total}</strong></div><div><small>Recursos distintos usados</small><strong>${current.distinct_sources}</strong></div><div><small>Projetos liberados para fabricação</small><strong>0</strong></div>`;
 document.getElementById('cards').innerHTML=pageItems.map((v,i)=>`<article class="box"><h2>${safe(v.name)}</h2><span class="tag">${safe(v.verdict)}</span><p class="small">${safe(v.family)} · ${v.source_census} fontes catalogadas · ${v.issues.length} erros · ${v.holds.length} pendências</p><p>${safe(PROJECT.products[start+i]?.mechanic)}</p><details open><summary>Pendências (${v.holds.length})</summary><ul>${v.holds.map(e=>`<li><b>${safe(e.code)}</b>: ${safe(e.msg)}</li>`).join('')}</ul></details><details ${v.issues.length?'open':''}><summary>Erros críticos (${v.issues.length})</summary><ul>${v.issues.map(e=>`<li><b>${safe(e.code)}</b>: ${safe(e.msg)}</li>`).join('')}</ul></details><details><summary>Fontes canônicas citadas</summary><ul>${v.evidence.map(e=>`<li><a href="${safe(e.source_url)}" target="_blank" rel="noopener">${safe(e.source_name)}</a> — ${safe(e.node_id)}</li>`).join('')}</ul></details><details><summary>Metodologia R17 — recurso → item → receita (TEST)</summary><ul><li><b>Recursos existentes indexados:</b> ${v.methodology?.resource?.existing_index_matches ?? 0}; insumos ainda sem fonte: ${safe((v.methodology?.resource?.unresolved_material_nodes||[]).join(', ')||'nenhum no recorte')}</li><li><b>Criação de recurso novo:</b> NÃO AUTORIZADA; buscar equivalentes globalmente (PR-CRN-01)</li><li><b>Item:</b> efeito, rank, FIP e PA exigem validação própria; ficha permanece Mestre TEST</li><li><b>Receita:</b> ${v.methodology?.recipe?.bom_quantified_nodes ?? 0}/${v.methodology?.recipe?.bom_nodes ?? 0} quantidades+unidades; ${v.methodology?.recipe?.process_steps ?? 0} etapas; ${safe((v.methodology?.recipe?.production_parameters_missing||[]).join(', ')||'parâmetros formais preenchidos')}</li><li><b>Resultado:</b> identidade REC e RC5 não demonstradas; fabricação, estoque e Party bloqueados</li></ul></details><details><summary>Roteiro de evidências — pendente e sem laudo</summary><ol>${evidencePlan([v]).projects[0].missing_evidence.map(a=>`<li><b>${safe(a.priority)} · ${safe(a.title)}</b> — ${safe(a.required_fields.join(', '))}</li>`).join('')}</ol></details><details><summary>Prévia hipotética TEST — NÃO PUBLICAR</summary><p>${safe(PROJECT.products[start+i]?.player_view?.visible_properties)}</p></details>${MASTER_CARDS.cards.find(c=>c.id===v.id)?`<details><summary>Ficha Mestre I–XIII — íntegra TEST</summary>${Object.entries(MASTER_CARDS.cards.find(c=>c.id===v.id).chapters).map(([k,val])=>`<details><summary>${safe(k.replaceAll('_',' '))}</summary><pre>${safe(JSON.stringify(val,null,2))}</pre></details>`).join('')}</details>`:''}</article>`).join('');
}
// R20: brief de INTENÇÃO; não projeta produto nem receita automática.
// A fonte normativa continua no Notion. Nenhuma ação em PROJECT, IndexedDB ou rede.
const R20_REFERENCE = Object.freeze({
 RESOURCE:{'base':'PR-CRN-01','url':'https://app.notion.com/p/3eec2b324ede819fbe0ed4af1a4cb3aa',
   'first_steps':['EXISTING-FIRST global por função, material e sinônimo','provar GAP-ID antes de pedir CRN-ID','ecologia, região, origem, RIn/FIP e compatibilidade com receita motivadora']},
 ITEM:{'base':'PR-ITEM-02','url':'https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4',
   'first_steps':['pesquisar produto e fórmula existente','especificar desenho físico, efeito, limites e casos de falha','separar RI/RE/RIn/FIP e PA com recibo','BOM e processo/REC-EXEC sem inventar insumos']},
 RECIPE:{'base':'REC-LIB-01 / REC-EXEC','url':'https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702',
   'first_steps':['localizar produto-alvo e REC-ID/versões sem duplicata','mapear BOM quantidades/unidades/papéis e processo 1:1','condições, ferramentas, especialista, energia, rendimento e perdas','aplicar módulo específico e gates RC/PS sem presumir RC5']}
});
function makeCreationBrief(kind,name,intent){
 const k=R20_REFERENCE[kind];
 if(!k||typeof name!=='string'||typeof intent!=='string'||name.trim().length<2||name.trim().length>180||intent.trim().length<10||intent.trim().length>2000)
   return null;
 const n=name.trim(),goal=intent.trim();
 return {schema:'CRAFT_R20_CREATION_BRIEF_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
   kind,provisional_name:n,desired_function_not_verified:goal,
   authoritative_reference:{name:k.base,url:k.url},
   method_steps_to_research:k.first_steps,
   required_other_norms:['PR-ITEM-02','PR-CRN-01','PR-SC-01','REC-EXEC e módulo competente','PR-ECO Anexo C','NAC-CONT-03','NAC-NORM-01','NAC-PASS'],
   evidence_status:{existing_item_search_complete:false,existing_recipe_search_complete:false,existing_resource_search_complete:false,
      source_readback_current:false,gap_confirmed:false,resource_proposed:false,item_material_created:false,
      recipe_rc5_approved:false,rank_approved:false,pa_supplier_receipt_verified:false,physical_evidence_available:false,
      writer_fencing_authorized:false,canonical_write_permitted:false,party_release_permitted:false},
   follow_up_request:`COMESTRE MESTRE-SIDE/TEST: analisar pedido ${kind} '${n}' com finalidade informada no campo desejada. Consultar Notion e normas vigentes; primeiro reusar recursos/itens/receitas existentes e provar lacuna antes de criar. Separar VERIFICADO/INFERIDO/PROPOSTO/PENDENTE, fonte Mestre/Party, materialidade, magia, rank, PA, custo e RC. Não escrever no cânone, estoque, Party ou O Primeiro sem gate/ordem válida.`,
   status:'BRIEF_TEST_NOT_CANONICAL_NOT_READY_FOR_PRODUCTION'};
}
document.getElementById('brief-export').addEventListener('click',()=>{
 const kind=document.getElementById('brief-kind').value,
  name=document.getElementById('brief-name').value,
  purpose=document.getElementById('brief-intent').value;
 const obj=makeCreationBrief(kind,name,purpose);
 if(!obj){document.getElementById('brief-status').textContent='Pendente: nome de 2 a 180 caracteres e finalidade de 10 a 2000 caracteres; escolher tipo válido.';return;}
 const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob);const a=document.createElement('a');
 a.href=url;a.download='CRAFT_R20_BRIEF_CRIACAO_MESTRE_TEST.json';a.click();
 setTimeout(()=>URL.revokeObjectURL(url),1500);
 document.getElementById('brief-status').textContent='Brief TEST gerado. Ainda é necessário pesquisar e auditar antes de qualquer criação.';
});
document.getElementById('check').addEventListener('click',()=>render(true));
document.getElementById('prev').addEventListener('click',()=>{if(pageIndex>0){pageIndex--;render(false);}});
document.getElementById('next').addEventListener('click',()=>{if(pageIndex<Math.ceil(current.items.length/PAGE_SIZE)-1){pageIndex++;render(false);}});
document.getElementById('upload').addEventListener('change',async (e)=>{
 const f=e.target.files?.[0]; if(!f)return;
 let localRejected=null;
 try{
  if(f.size>2*1024*1024)throw Error('JSON excede limite local de 2 MiB');
  const d=JSON.parse(await f.text());
  if(!Array.isArray(d?.products)||d.products.length===0)throw Error('JSON deve conter products[] não vazio');
  const result=valid(d,INDEX);
  if(result.status==='REJECT'){
    // Cria somente orientação derivada dos CÓDIGOS: nem projeto inválido ativo,
    // nem preview Player, nem material de produção.
    localRejected=evidencePlan(result.items);
    throw Error('Entrada rejeitada: '+result.items.flatMap(x=>x.issues.map(i=>i.code)).join(', '));
  }
  const previous=PROJECT,prevPage=pageIndex;PROJECT=d;pageIndex=0;
  try{render()}catch(ex){PROJECT=previous;pageIndex=prevPage;render();throw ex;}
  rejectedPlan=null;document.getElementById('rejected-plan').disabled=true;
  document.getElementById('loadStatus').textContent=`Proposta TEST carregada: ${f.name} — ${d.products.length} itens.`;
 }catch(ex){
   rejectedPlan=localRejected;
   document.getElementById('rejected-plan').disabled=!rejectedPlan;
   document.getElementById('loadStatus').textContent='Falha no arquivo: '+ex.message;
 }
});
document.getElementById('rejected-plan').addEventListener('click',()=>{
 if(!rejectedPlan)return;
 const blob=new Blob([JSON.stringify(rejectedPlan,null,2)+'\\n'],{type:'application/json'});
 const url=URL.createObjectURL(blob);const a=document.createElement('a');
 a.href=url;a.download='CRAFT_R18_CORRECOES_ARQUIVO_REJEITADO_MESTRE_TEST.json';a.click();
 setTimeout(()=>URL.revokeObjectURL(url),1500);
});
document.getElementById('evidence').addEventListener('click',()=>{
 if(!current)render();
 const plan=evidencePlan(current.items||[]);
 const blob=new Blob([JSON.stringify(plan,null,2)+'\\n'],{type:'application/json'});
 const url=URL.createObjectURL(blob); const a=document.createElement('a');
 a.href=url;a.download='CRAFT_R14_PEDIDO_EVIDENCIAS_MESTRE_TEST.json';a.click();
 setTimeout(()=>URL.revokeObjectURL(url),1500);
});
document.getElementById('save').addEventListener('click',()=>{
 if(!current)render();const txt=JSON.stringify(current,null,2)+'\\n';const blob=new Blob([txt],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='R53_QA_TEST_RESULT.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
});
render();
</script></body></html>'''
(base/'REVISOR_LOCAL_ANDROID_R53_TEST.html').write_text(page,encoding='utf-8')
print('HTML',len(page),'bytes')
