@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo CRAFT experimental - sem acesso ao Notion
py -3 -c "import cryptography" >nul 2>&1
if errorlevel 1 (
  echo Instalando dependencia necessaria no Python local...
  py -3 -m pip install -r requirements.txt
  if errorlevel 1 ( echo Falha ao instalar dependencia. & pause & exit /b 1 )
)
py -3 app.py
pause
