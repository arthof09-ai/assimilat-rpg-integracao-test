# CRAFT — Oficina Experimental do Mestre (interface humana v1)

**Entrega operacional de interface sobre os motores R44 + R47 + R48.** Não é um sistema oficial do RPG, não acessa Notion e não altera Party/O Primeiro. R01–R52 preservados dentro do pacote histórico original R52; o código de fábrica R48 foi copiado sem modificações.

## Abrir e fabricar em três passos

1. **Extraia o ZIP completo** para uma pasta de caminho curto, como `C:\CRAFT` (Windows) ou `~/CRAFT` (Linux/Mac). **Não mova** `app.py` para fora da pasta extraída.
2. **Windows:** dê dois cliques em **`INICIAR_CRAFT.bat`**. **Mac/Linux:** execute `./INICIAR_CRAFT.sh` na pasta. Alternativamente, com Python 3.10+ instalado: `python -m pip install -r requirements.txt` e `python app.py` (Linux: `python3`). O pacote usa a biblioteca `cryptography`, já exigida pelo R47; a primeira inicialização pode requerer a instalação dessa dependência.
3. Abra o navegador em **<http://127.0.0.1:8765>** se ele não abrir sozinho. Clique **Criar estoque e começar**, depois **B30-01 — Tábua Lamelar de Inscrição**. Selecione a lâmina e os parâmetros, clique **Conferir recursos e QA** e depois **Confirmar e fabricar**. O recibo exibe a transição de etapas, consumo, rendimento experimental e saldo antes/depois.

**Você não precisa alterar código, editar JSON ou preparar relatórios/laudos.** A interface monta automaticamente um laudo inteiramente **fictício e assinado com chaves públicas de TESTE**, consumido pelos mesmos motores de autenticidade R47 e fabricação R44/R48. O laudo não constitui medida física legítima.

### Outras ações úteis

- **Falha por falta de recurso:** no Início, crie uma *nova sessão* com `Ardósia apta = 0`; selecione B30-01 e tente fabricar. O resultado esperado é `REJECTED_PRECHECK`, sem perda de estoque e sem produto.
- **Falha por QA:** numa sessão com Ardósia fictícia apta, altere `length_mm` para `999`. R47/R46 colocará a evidência em `QUARANTINE_EVIDENCE`, sem consumo.
- **Repetir o pedido:** no recibo, clique **Repetir o mesmo pedido**. O R48 devolve `idempotent_replay: true` e o saldo/HEAD não mudam.
- **Reverter:** no Início, clique **Reverter último lote fictício**. O app cria **nova sessão** derivada do checkpoint anterior e torna-a ativa, **preservando a sessão original e toda sua história**. É um fork/rollback local, não uma remoção do passado.
- **Consultas:** use **Histórico** e **Baixar recibo JSON** para revisar resultados, consumo e produtos; **Sessões** para reabrir registros anteriores.
- **Outra receita já implementada:** **B30-03 — Espaçador de Mica**, com 2 folhas e saída experimental de 2 peças.
- **Outro diretório de testes:** `python app.py --data "CAMINHO_DOS_MEUS_TESTES" --port 8766`. O aplicativo atende **somente `127.0.0.1`**, não publica serviço na internet.

### Definição dos 12 critérios funcionais

| # | Função em interface humana | Verificação |
|---|---|---|
| 1 | Escolher entre B30-01 e B30-03 | Links e menu HTML |
| 2 | Ver ingredientes, quantidades e requisitos | Tela da receita |
| 3 | Definir estoque fictício | Formulário novo estoque |
| 4 | Conferir recursos disponíveis | Saldo e botão pré-validação |
| 5 | Executar tentativa | Botão `Executar tentativa sintética` |
| 6 | Processar etapas suportadas | R44 por meio do R48; traço no recibo |
| 7 | Exibir consumo, rendimento e perdas experimentais | Débitos R44 e produtos; projeção geométrica **não medida** e refugo registrado separado |
| 8 | Avaliar QA suportado | Leituras editáveis, QA R44 e R46/R47 |
| 9 | Mostrar produto ou falha | Recibo por pedido |
| 10 | Comparar estoque antes/depois | Tabela do recibo e histórico |
| 11 | Consultar relatório | Histórico, recibo HTML e JSON |
| 12 | Reverter operação quando aplicável | Fork do checkpoint anterior sem apagar registros originais |

**Cobertura de implementação:** 12/12 funções presentes na interface e exercitáveis. **Teste automatizado HTTP:** fluxo principal, sucesso Tábua/Mica, falha por falta de estoque, falha de QA, repetição e reversão PASS. **UAT humana real:** 0/1, aguardando o Mestre usar a interface no próprio computador. Não confundir teste unitário com item fabricado.

## Como a simulação respeita o organismo

- O R48 **permanece original** em `CRAFT-R48-SANDBOX-I0016/`. É o motor com R44 (estoque, etapas, QA, consumo, produtos, perdas), R47 (assinaturas de TESTE, cadeia de custódia) e durabilidade R48 (journal, commits, locks e replay). `app.py` é **somente o controlador de telas, formulários, orquestração de fixtures e sessões isoladas**.
- Todas as medições, laudos, certificados, chaves e IDs são de teste; a data `2026-10-09` nos laudos corresponde ao **relógio congelado do fixture**, não à data presente nem à emissão de um laboratório real.
- A geometria exibida é uma **hipótese de projeto**, derivada das dimensões propostas; área/volume nominal não representa refugo pesado, estoque físico, tempo realizado ou rendimento empírico.
- O custo pode aparecer como **fórmula simbólica**, nunca MED canônico calculado sem dados oficiais.
- Estoques e sessões são gravados **apenas** sob `SESSOES-FICTICIAS/` (criada no primeiro uso), sem comunicação com o Notion. Esse diretório não está no pacote inicial; contém dados locais de teste do usuário.
- As cinco essências incertas de `C19-021` **não** são criadas nem consultadas pela interface.

## Provas entregues

`demonstracoes/resultados/demonstracao_http.json` guarda a prova automatizada feita através dos **endpoints reais da interface HTTP**. Arquivos por cenário contêm estado anterior/posterior, produto/rejeição, idempotência e reversão. Rode `python demonstracoes/executar_demo_http.py` apenas se quiser repetir a validação; **não é necessário** para jogar com a interface.

`testes/test_interface.py` contém somente os testes focados na nova camada humana. Os resultados anteriores R44–R52 foram preservados, **não repetidos sem alteração do motor**. `verificar_pacote.py` confere hashes, CRC e preservação histórica.

## Dependências e limitações concretas

- **Necessita Python 3.10+ e `cryptography`.** O ZIP entrega código-fonte executável e launchers, **não executável Windows nativo `.exe`**. No Android não há uma instalação direta: o servidor precisa rodar numa máquina com Python; por segurança o modo padrão não expõe a interface na rede.
- A aplicação não contém interface de autenticação multiusuário, não se conecta ao RPG oficial e não autoriza exclusividade de writer. O bloqueio C19/F5 não prejudica a simulação, mas impede integração oficial.
- A reversão é **fork da última transação**. Ela não desfaz um lote do meio da história nem altera o passado original; a interface não possui operação de “desfazer físico”.
- A assinatura válida de um laudo `SBX` prova apenas a consistência das chaves **públicas de TESTE**, nunca autenticidade independente ou fabricação real.
- Não há UAT humana comprovada: o Mestre ainda precisa executar a instalação e realizar uma fabricação na tela para aceitar a ferramenta operacionalmente.
- Recursos, preços e qualidade oficiais continuam pendentes. Estado material: `0/26 gaps`, `0/30 RC5`, `F5 RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, `NAC-PASS material HOLD`.

## Próximo passo depois da UAT humana

Testar instalação real em Windows/Mac/Linux escolhido pelo Mestre, corrigir eventual problema de usabilidade sem alterar o motor. A integração Notion oficial continua **uma frente diferente e bloqueada** até fencing C19, recuperação do checkpoint desconhecido, destino REC-LIB e evidências reais com GREEN/NAC-PASS apropriados.
