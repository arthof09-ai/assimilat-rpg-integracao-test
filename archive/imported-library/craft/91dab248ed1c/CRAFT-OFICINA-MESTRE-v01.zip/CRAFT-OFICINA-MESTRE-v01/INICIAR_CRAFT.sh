#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -c 'import cryptography' 2>/dev/null || python3 -m pip install -r requirements.txt
exec python3 app.py
