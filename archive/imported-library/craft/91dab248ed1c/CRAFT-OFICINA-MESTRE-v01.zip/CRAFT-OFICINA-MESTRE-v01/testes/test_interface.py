"""Focused human-adapter tests; does not re-run historical engine test suites."""
import sys
import tempfile
import unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import app

class StudioTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.studio=app.Studio(Path(self.tmp.name))
        self.studio.init()
    def request(self,code='B30-01',lot_ids=None,measure=None):
        r=self.studio.recipe(code)
        if lot_ids is None:lot_ids=['SBX-SLATE-GOOD-01'] if code=='B30-01' else ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
        q=dict(app.values_from_default(r))
        if measure:q.update(measure)
        return {'recipe':code,'lot_ids':lot_ids,'tools':r['tools'],'skills':r['skills'],'qa':q}
    def batch(self,i):return f'SBX-R48-BATCH-UI-{i:016x}'
    def test_recipe_catalog_is_existing_only(self):
        self.assertEqual(set(app.RECIPES),{'B30-01','B30-03'})
        self.assertEqual(self.studio.recipe('B30-01')['source_page_id'],'3f3c2b32-4ede-81ac-af28-c66a6b46e0b2')
        with self.assertRaises(ValueError):self.studio.recipe('B30-99')
    def test_success_idempotence_and_ledger(self):
        raw=self.request();bid=self.batch(1)
        self.assertEqual([],self.studio.preflight(raw)['stock_and_tool_reasons'])
        r=self.studio.commit(raw,bid)['receipt']
        self.assertEqual(r['orders'][0]['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual((r['stock_before']['SBX-SLATE-GOOD-01'],r['stock_after']['SBX-SLATE-GOOD-01']),(2,1))
        old=self.studio.active_store()[2]['r48_head']
        self.assertTrue(self.studio.repeat(bid)['idempotent_replay'])
        self.assertEqual(old,self.studio.active_store()[2]['r48_head'])
    def test_rejected_stock_retained(self):
        raw=self.request(lot_ids=['SBX-SLATE-TOO-SMALL'])
        r=self.studio.commit(raw,self.batch(2))['receipt']
        self.assertEqual('REJECTED_PRECHECK',r['orders'][0]['status'])
        self.assertEqual(r['stock_before'],r['stock_after'])
    def test_qa_invalid_goes_quarantine(self):
        raw=self.request(measure={'length_mm':888})
        r=self.studio.commit(raw,self.batch(3))['receipt']
        self.assertEqual('QUARANTINE_EVIDENCE',r['orders'][0]['status'])
        self.assertEqual(r['stock_before'],r['stock_after'])
    def test_rollback_fork_preserves_old(self):
        bid=self.batch(4)
        self.studio.commit(self.request(),bid)
        old=self.studio.session_id()
        info=self.studio.undo_last()
        self.assertEqual(info['old_session'],old)
        self.assertNotEqual(info['new_session'],old)
        self.assertEqual(self.studio.active_store()[1].quantities['SBX-SLATE-GOOD-01'],2)
        self.assertEqual(app.DurableFactory(self.studio.path(old)/'store').recover()[0].quantities['SBX-SLATE-GOOD-01'],1)
    def test_bad_quality_and_stock_stay_fictitious(self):
        self.studio.init({k:0 for k in app.DEFAULT_QTY})
        r=self.studio.commit(self.request(),self.batch(5))['receipt']
        self.assertEqual(0,r['official_stock_effect'])
        self.assertFalse(r['orders'][0]['physical_measurement_verified'])
    def test_geometry_is_explicitly_proposed(self):
        for code in app.RECIPES:
            g=app.theoretical_yield(self.studio.recipe(code))
            self.assertFalse(g['material_scrap_recorded'])
            self.assertTrue(g['kind'].startswith('PROPOSED_'))
            self.assertTrue(0<g['theoretical_recovery_pct']<100)
    def test_no_network_write_in_engine(self):
        text=(BASE/'CRAFT-R48-SANDBOX-I0016'/'fabricar.py').read_text('utf8')
        self.assertNotIn('notion_create_page',text)

if __name__=='__main__':unittest.main()
