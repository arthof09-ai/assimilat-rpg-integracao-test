#!/usr/bin/env python3
"""CRAFT Mestre — local web UI for the EXISTING R48 experiment.

Zero Notion access. All lots, QA, certificates, prices and products are synthetic.
This file is only a human-facing adapter: R44/R47/R48 execute all actual rules.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import html
import json
import math
import re
import secrets
import shutil
import sys
import threading
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit, quote

HERE=Path(__file__).resolve().parent
ENGINE=HERE/'CRAFT-R48-SANDBOX-I0016'
if not (ENGINE/'r48_factory.py').is_file():
    raise RuntimeError('Motor R48 ausente: extraia o pacote inteiro, sem separar app.py da pasta CRAFT-R48-SANDBOX-I0016')
sys.path.insert(0,str(ENGINE))
from r48_factory import IntegratedFactory, SandboxEngine, FactoryError, FactoryCrash, digest
from r48_store import DurableFactory
from r48_fixtures import lots as fixture_lots
from r46_fixtures import make_report, artifact
from r47_fixtures import make_attestation, REVIEW
from r47_durable_store import persist_atomic

RECIPES={'B30-01':'SBX-TLI-R44-v1','B30-03':'SBX-MICA-R44-v1'}
NAMES={'B30-01':'Tábua Lamelar de Inscrição','B30-03':'Par de Espaçadores de Mica'}
LOT_NAMES={'SBX-SLATE-GOOD-01':'Ardósia apta (fictícia)',
           'SBX-SLATE-TOO-SMALL':'Ardósia pequena (fictícia)',
           'SBX-SLATE-CRACKED':'Ardósia trincada (fictícia)',
           'SBX-MICA-GOOD-A':'Mica A (fictícia)',
           'SBX-MICA-GOOD-B':'Mica B (fictícia)'}
DEFAULT_QTY={r['lot_id']:r['quantity'] for r in fixture_lots()}
SESSION_RE=re.compile(r'^sim-[0-9a-f]{12}$')
BATCH_RE=re.compile(r'^SBX-R48-BATCH-UI-[0-9a-f]{16}$')


def esc(v):return html.escape(str(v),quote=True)
def canon(x):return json.dumps(x,indent=2,ensure_ascii=False,sort_keys=True,allow_nan=False)+'\n'
def write_json(path,obj):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    persist_atomic(path,canon(obj).encode('utf8'))

def short(x):return str(x)[:16]

def assert_finite(value,field):
    if not math.isfinite(float(value)):
        raise ValueError('VALOR_NAO_FINITO: '+field)
    return value

class Studio:
    def __init__(self,root:Path):
        self.root=Path(root).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.sessions=self.root/'sessions'
        self.sessions.mkdir(exist_ok=True)
        self.active_file=self.root/'ATIVA.json'
        self.lock=threading.RLock()
        self.token=secrets.token_urlsafe(32)
        self.recipe_cache=IntegratedFactory.fixture_factory(fixture_lots()).recipes

    def session_id(self):
        if not self.active_file.is_file():return None
        d=json.loads(self.active_file.read_text('utf8'))
        sid=d.get('active')
        if not isinstance(sid,str) or not SESSION_RE.fullmatch(sid):raise ValueError('INDICE_SESSAO_INVALIDO')
        if d.get('marker')!='FICTITIOUS_CRAFT_ONLY':raise ValueError('ATIVA_FORA_DO_SANDBOX')
        return sid

    def path(self,sid):
        if not SESSION_RE.fullmatch(sid):raise ValueError('ID_SESSAO_INVALIDO')
        return self.sessions/sid

    def active_store(self):
        sid=self.session_id()
        if sid is None:return None,None,None
        store=DurableFactory(self.path(sid)/'store')
        factory,state=store.recover()
        return store,factory,state

    def activate(self,sid):
        write_json(self.active_file,{'active':sid,'marker':'FICTITIOUS_CRAFT_ONLY'})

    def init(self,quantities=None):
        with self.lock:
            template=fixture_lots()
            if quantities is not None:
                if set(quantities)!=set(DEFAULT_QTY):raise ValueError('ESTOQUE_FORA_DO_CONTRATO')
                for row in template:
                    q=quantities[row['lot_id']]
                    if type(q) is not int or not 0<=q<=100000:raise ValueError('QUANTIDADE_INVALIDA')
                    row['quantity']=q
            sid='sim-'+uuid.uuid4().hex[:12]
            root=self.path(sid)
            root.mkdir(parents=True,exist_ok=False)
            store=DurableFactory(root/'store')
            try:
                store.initialize(IntegratedFactory.fixture_factory(template))
                write_json(root/'session.json',{'id':sid,'type':'SYNTHETIC_ONLY','started_utc':datetime.now(timezone.utc).isoformat(),'initial_inventory':{r['lot_id']:r['quantity'] for r in template},'origin':None})
                self.activate(sid)
            except Exception:
                # No attempt to alter existing session; failed new one stays forensic.
                raise
            return sid

    def list_sessions(self):
        return sorted([p.name for p in self.sessions.iterdir() if p.is_dir() and SESSION_RE.fullmatch(p.name)])

    def switch(self,sid):
        with self.lock:
            DurableFactory(self.path(sid)/'store').recover()  # integrity gate
            self.activate(sid)

    def recipe(self,code):
        if code not in RECIPES:raise ValueError('RECEITA_NAO_SUPORTADA')
        return self.recipe_cache[RECIPES[code]]

    def parse_order(self,data):
        code=data.get('recipe','B30-01')
        recipe=self.recipe(code)
        slots=[]
        for ix in range(len(recipe['inputs'])):
            v=data.get('lot_'+str(ix),'')
            if not v or v not in LOT_NAMES:raise ValueError('LOTE_NAO_SELECIONADO: '+str(ix))
            slots.append(v)
        tools=[s for s in recipe['tools'] if data.get('tool_'+s)=='on']
        skills=[s for s in recipe['skills'] if data.get('skill_'+s)=='on']
        qa={}
        for r in recipe['qa_rules']:
            field=r['field']
            value=data.get('qa_'+field)
            if value is None:raise ValueError('QA_OBRIGATORIO: '+field)
            if r['kind']=='bool_eq':
                if value not in ('true','false'):raise ValueError('QA_BOOLEANO_INVALIDO: '+field)
                qa[field]=value=='true'
            else:
                try:n=float(value)
                except Exception:raise ValueError('QA_NUMERICO_INVALIDO: '+field)
                assert_finite(n,field)
                if field.endswith('_count') or field=='piece_count':
                    if n!=int(n) or n<0:raise ValueError('QA_INTEIRO_INVALIDO: '+field)
                    n=int(n)
                if abs(n)>1000000000:raise ValueError('QA_FORA_LIMITE_UI: '+field)
                qa[field]=n
        return {'recipe':code,'lot_ids':slots,'tools':tools,'skills':skills,'qa':qa}

    def preflight(self,raw):
        with self.lock:
            _,f,_=self.active_store()
            recipe=self.recipe(raw['recipe'])
            reasons=[]
            if len(set(raw['lot_ids']))!=len(raw['lot_ids']):reasons.append('DUPLICATE_LOT_SELECTION')
            selected=[]
            for i,lot_id in enumerate(raw['lot_ids']):
                lot=f.core.state['lots'].get(lot_id)
                if lot is None:reasons.append('LOT_NOT_IN_SANDBOX:'+lot_id)
                else:selected.append(lot)
            if len(selected)==len(recipe['inputs']):
                reasons+=SandboxEngine._input_ok(recipe,selected)
            else:reasons.append('INPUT_COUNT_MISMATCH')
            if any(x not in raw['tools'] for x in recipe['tools']):reasons.append('MISSING_REQUIRED_TOOL')
            if any(x not in raw['skills'] for x in recipe['skills']):reasons.append('MISSING_REQUIRED_SKILL')
            qa=SandboxEngine._quality(recipe,raw['qa'])
            return {'can_attempt':True, 'stock_and_tool_reasons':reasons, 'qa_reasons':qa,
                    'projected_qa':'PASS_PROPOSTO' if not qa else 'FAIL_PROPOSTO',
                    'expected_behavior':'Pode falhar/rejeitar/quarentenar sem débito' if reasons or qa else 'Candidato a simulação de fabricação',
                    'current_stock':f.quantities,'synthetic_only':True}

    @staticmethod
    def request_from(raw,batch_id):
        if not BATCH_RE.fullmatch(batch_id):raise ValueError('ID_PEDIDO_INVALIDO')
        idx=50000+(int(batch_id.rsplit('-',1)[-1],16)%900000000)
        key=RECIPES[raw['recipe']]
        report=make_report(key=key,id=f'SBX-R47-LAUDO-{idx:09d}',kind='SYNTHETIC')
        report['lot_ids']=list(raw['lot_ids'])
        for field,val in raw['qa'].items():
            report['observations'][field]['value']=val
        measurement_payload={'sample_id':report['sample_id'], 'source_page_id':report['source_page_id'],
                             'instrument_id':report['instrument']['instrument_id'],
                             'observed_at':report['observed_at'],'observations':report['observations']}
        report['artifacts']['measurement']=artifact(json.dumps(measurement_payload,sort_keys=True,ensure_ascii=False))
        attestation=make_attestation(report) # OLD R47 signing fixtures, not a real lab
        order={'order_id':f'SBX-R48-ORDER-UI-{idx:09d}','recipe_key':key,
               'lot_ids':list(raw['lot_ids']),'measurements':copy.deepcopy(raw['qa']),
               'tools':list(raw['tools']),'skills':list(raw['skills']),
               'report':report,'attestation':attestation}
        return {'batch_id':batch_id,'orders':[order],'reviewed_at':REVIEW}

    def commit(self,raw,batch_id):
        with self.lock:
            store,f,before_pointer=self.active_store()
            if store is None:raise ValueError('CRIAR_SESSAO_PRIMEIRO')
            req=self.request_from(raw,batch_id)
            sid=self.session_id()
            path=self.path(sid)/'requests'/f'{batch_id}.json'
            if path.exists():
                existing=json.loads(path.read_text('utf8'))
                if digest(existing)!=digest(req):raise ValueError('IDEMPOTENCIA_UI_CONFLITO')
            else:
                write_json(path,req) # write-ahead: survive crash before response
            result=store.commit_batch(**req)
            return result

    def repeat(self,batch_id):
        with self.lock:
            if not BATCH_RE.fullmatch(batch_id):raise ValueError('REPLAY_INVALIDO')
            sid=self.session_id();path=self.path(sid)/'requests'/f'{batch_id}.json'
            if not path.is_file():raise ValueError('PEDIDO_ORIGINAL_NAO_ENCONTRADO')
            request=json.loads(path.read_text('utf8'))
            return DurableFactory(self.path(sid)/'store').commit_batch(**request)

    def undo_last(self):
        """Fork immutable durable history at previous commit. Never erase old commits.

        Old store remains readable; active moves to a brand-new independent local store.
        This is undo of the LAST local batch, including rejected attempts.
        """
        with self.lock:
            sid=self.session_id()
            if sid is None:raise ValueError('NENHUMA_SESSAO')
            old_root=self.path(sid)
            old=DurableFactory(old_root/'store')
            f,pointer=old.recover()
            if pointer['sequence']<1:raise ValueError('SEM_OPERACAO_A_REVERTER')
            old_head=pointer['r48_head']
            new_sid='sim-'+uuid.uuid4().hex[:12]
            new_root=self.path(new_sid)
            commits=new_root/'store'/'commits'
            commits.mkdir(parents=True,exist_ok=False)
            keep=pointer['known_commits'][:-1]
            if not keep:raise ValueError('SEM_GENESIS')
            for name in keep:
                shutil.copy2(old_root/'store'/'commits'/name,commits/name)
            snap=json.loads((commits/keep[-1]).read_text('utf8'))
            # Preserve original hashes. Authenticated HEAD is created using old durable writer.
            shortened={'schema':pointer['schema'],'sequence':len(keep)-1,
                       'known_commits':keep,
                       'commit_digests':{name:pointer['commit_digests'][name] for name in keep},
                       'current':keep[-1], 'r48_head':snap['r48_head'],
                       'snapshot_sha256':snap['snapshot_sha256'],
                       'sandbox_only':True,'official_stock_effect':0}
            target=DurableFactory(new_root/'store')
            target._publish(shortened)
            recovered,new_pointer=target.recover()
            if len(recovered.journal)!=len(f.journal)-1:raise ValueError('ROLLBACK_COUNT_NOT_ONE')
            # Concurrent updates by external scripts invalidate fork switch.
            if old.recover()[1]['r48_head']!=old_head:raise ValueError('OLD_LEDGER_CHANGED_DURING_FORK')
            write_json(new_root/'session.json',{'id':new_sid,'type':'SYNTHETIC_ONLY','origin':sid,
                      'reason':'FORK_ROLLBACK_LAST_BATCH','retained_original':True,
                      'started_utc':datetime.now(timezone.utc).isoformat(),
                      'restored_sequence':shortened['sequence'],
                      'old_sequence':pointer['sequence']})
            # Copy only surviving historical requests so replay history remains available.
            for entry in recovered.journal:
                bid=entry['event']['batch_id']
                src=old_root/'requests'/f'{bid}.json'
                if src.is_file():
                    dst=new_root/'requests'/f'{bid}.json'
                    dst.parent.mkdir(exist_ok=True)
                    shutil.copy2(src,dst)
            self.activate(new_sid)
            return {'old_session':sid,'new_session':new_sid,'reverted_batch_id':f.journal[-1]['event']['batch_id'],
                    'stock_before':f.quantities,'stock_after':recovered.quantities,
                    'old_store_preserved':True,'official_stock_effect':0,'old_head':old_head,
                    'recovered_head':new_pointer['r48_head']}


CSS='''
:root {font-family:system-ui,Arial,sans-serif;color:#212936;background:#f6f7f9}
body {max-width:1130px;margin:0 auto;padding:18px}
header {border-bottom:2px solid #cbd2dd;padding-bottom:12px;margin-bottom:14px}
h1{margin:3px 0;font-size:1.65rem} h2{font-size:1.25rem;margin:0 0 12px} h3{font-size:1.05rem}
p{line-height:1.5} .warn{background:#fff1dc;border-left:5px solid #ae6512;padding:10px 14px;margin:10px 0}
.info{background:#eef3fb;padding:12px;border:1px solid #d8e1f2;border-radius:8px}.error{background:#ffebea;border-left:4px solid #aa3030;padding:14px}.good{color:#13724b;font-weight:bold}.bad{color:#a12626;font-weight:bold}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}.panel{padding:16px;background:white;border:1px solid #d9dee8;border-radius:10px;margin:10px 0}
button,.button{cursor:pointer;display:inline-block;background:#263b62;color:white;border:0;border-radius:6px;padding:10px 15px;text-decoration:none;font-size:0.96rem}
button:hover,.button:hover{background:#39517c} button.subtle,.button.subtle{background:#e7ebf4;color:#1d3657}button.danger{background:#863c40}
nav a{margin-right:16px;color:#264a83;text-decoration:none}nav{margin:12px 0} label{display:block;margin:9px 0}input,select{padding:8px;max-width:100%;border:1px solid #bcc5d3;border-radius:5px}input[type=number]{width:110px}input[type=checkbox]{width:auto}
fieldset{border:1px solid #d4dce8;border-radius:8px;margin:12px 0;padding:12px}legend{font-weight:bold}table{width:100%;border-collapse:collapse;font-size:.91rem}th,td{padding:8px;border-bottom:1px solid #e1e6ee;text-align:left;vertical-align:top}th{background:#f3f5f8}code{font-size:.85em;word-break:break-word}
small,.muted{color:#596678}.buttons{display:flex;flex-wrap:wrap;gap:10px;align-items:center}.tiny{font-size:.85rem}.status{font-weight:bold;color:#115f4a}
@media(max-width:650px){body{padding:9px} .panel{padding:12px}td,th{padding:5px}}
'''


def nav():return '<nav><a href="/">Início</a><a href="/receita?code=B30-01">Tábua B30-01</a><a href="/receita?code=B30-03">Mica B30-03</a><a href="/historico">Histórico</a><a href="/ajuda">Instruções</a></nav>'

def layout(body,title='CRAFT — Oficina Experimental',sid=None):
    subtitle=f'Sessão fictícia ativa: {esc(sid)}' if sid else 'Nenhuma sessão de teste ativa'
    return f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>{CSS}</style></head><body><header><h1>CRAFT · Oficina experimental do Mestre</h1><div class="muted">{subtitle}</div>{nav()}</header><div class="warn"><strong>APENAS SIMULAÇÃO.</strong> Nenhum item, estoque, custo, medição, assinatura ou fabricação desta interface é real/canônico. F5 RED · RC5 0/30 · C19-021 UNKNOWN · NAC-PASS material HOLD.</div>{body}<footer><p class="muted tiny">Sem conexão com Notion, Party ou O Primeiro. Motores originais R44 + R47 + R48. Interface local em 127.0.0.1.</p></footer></body></html>'


def rows_stock(factory):
    if factory is None:return ''
    body=''.join(f'<tr><td>{esc(LOT_NAMES.get(lid,lid))}</td><td><code>{esc(lid)}</code></td><td>{esc(q)}</td><td>{esc(factory.core.state["lots"][lid]["unit"])}</td></tr>' for lid,q in factory.quantities.items())
    return '<table><thead><tr><th>Lote fictício</th><th>ID</th><th>Saldo</th><th>Unid.</th></tr></thead><tbody>'+body+'</tbody></table>'


def ready_form(token):
    fields=''.join(f'<label>{esc(LOT_NAMES[k])}<div><input name="quantity_{esc(k)}" type="number" min="0" max="100000" step="1" required value="{v}"> unidades fictícias</div></label>' for k,v in DEFAULT_QTY.items())
    return f'<section class="panel"><h2>1. Criar estoque de teste</h2><p>Altere as quantidades livremente. Isto cria uma <strong>nova sessão fictícia</strong>, sem sobrescrever sessões anteriores.</p><form method="post" action="/novo"><input type="hidden" name="csrf" value="{esc(token)}">{fields}<button type="submit">Criar estoque e começar</button></form></section>'


def qdesc(rule):
    if rule['kind']=='range':return f'entre {rule["min"]} e {rule["max"]}'
    if rule['kind']=='min':return f'mínimo {rule["min"]}'
    if rule['kind']=='max':return f'máximo {rule["max"]}'
    return 'deve ser '+('Sim' if rule['value'] else 'Não')


def theoretical_yield(recipe):
    """Presentation-only geometry from proposed design; NEVER engine scrap or physical yield."""
    if recipe['design_id']=='B30-01':
        g=recipe['geometry_proposed']
        return {'kind':'PROPOSED_GEOMETRY_NOT_MEASURED',
                'input_geometry':f"{g['raw_cm3']:.2f} cm³ (lâmina nominal)",
                'output_geometry':f"{g['finished_cm3']:.2f} cm³ (tábua nominal)",
                'ideal_nominal_scrap':f"{g['ideal_geometric_scrap_cm3']:.2f} cm³",
                'theoretical_recovery_pct':round(g['ideal_geometric_recovery_percent'],2),
                'material_scrap_recorded':False}
    if recipe['design_id']=='B30-03':
        # A purely *planar* comparison. Thickness/mass are unknown and NOT invented.
        input_area=sum(r['minimum_dimensions_mm']['length']*r['minimum_dimensions_mm']['width'] for r in recipe['inputs'])
        each_length,each_width=recipe['output']['target_mm_each']
        output_area=each_length*each_width*recipe['output']['quantity']
        return {'kind':'PROPOSED_PLANAR_GEOMETRY_NOT_MEASURED',
                'input_geometry':f'{input_area} mm² (área mínima nominal das folhas)',
                'output_geometry':f'{output_area} mm² (área nominal dos espaçadores)',
                'ideal_nominal_scrap':f'{input_area-output_area} mm² (área nominal não ocupada)',
                'theoretical_recovery_pct':round(100*output_area/input_area,2),
                'material_scrap_recorded':False}
    raise ValueError('ONLY_TWO_DESIGNS')

def values_from_default(recipe):
    from r48_fixtures import DEMO
    return DEMO['tli_good_measurements'] if recipe['design_id']=='B30-01' else DEMO['mica_good_measurements']


def recipe_form(recipe,stock,token,batch_id):
    qfields=[]
    vals=values_from_default(recipe)
    for r in recipe['qa_rules']:
        key=r['field'];v=vals[key]
        if r['kind']=='bool_eq':
            widget=f'<select name="qa_{esc(key)}"><option value="false" {"selected" if v is False else ""}>Não</option><option value="true" {"selected" if v is True else ""}>Sim</option></select>'
        else:
            widget=f'<input type="number" step="any" required name="qa_{esc(key)}" value="{esc(v)}">'
        qfields.append(f'<tr><td><code>{esc(key)}</code></td><td>{esc(qdesc(r))}</td><td>{widget}</td></tr>')
    selection=[]
    stocklots=list(stock.core.state['lots'].values())
    for ix,input_ in enumerate(recipe['inputs']):
        pool=[lot for lot in stocklots if lot['unit']==input_['unit'] and lot['source_page_id']==input_['source_page_id']]
        if not pool:pool=stocklots
        opt=''.join(f'<option value="{esc(lot["lot_id"])}" {"selected" if lot["lot_id"]==( "SBX-SLATE-GOOD-01" if recipe["design_id"]=="B30-01" else "SBX-MICA-GOOD-A") else ""}>{esc(LOT_NAMES.get(lot["lot_id"],lot["lot_id"]))} · saldo {lot["quantity"]} · {lot.get("dimensions_mm",{})}</option>' for j,lot in enumerate(pool))
        # avoid auto-selection of same mica lot in two different slots
        if recipe['design_id']=='B30-03' and ix==1:
            opt=''.join(f'<option value="{esc(lot["lot_id"])}" {"selected" if lot["lot_id"]=="SBX-MICA-GOOD-B" else ""}>{esc(LOT_NAMES.get(lot["lot_id"],lot["lot_id"]))} · saldo {lot["quantity"]}</option>' for lot in pool)
        selection.append(f'<label>Ingrediente {ix+1}: <strong>{input_["quantity"]} {esc(input_["unit"])}</strong> · origem PS <code>{esc(input_["source_page_id"])}</code><br><select name="lot_{ix}" required>{opt}</select></label>')
    ts=''.join(f'<label><input type="checkbox" name="tool_{esc(x)}" checked> {esc(x)}</label>' for x in recipe['tools'])
    sk=''.join(f'<label><input type="checkbox" name="skill_{esc(x)}" checked> {esc(x)}</label>' for x in recipe['skills'])
    steps=''.join(f'<tr><td>{s["seq"]}</td><td>{esc(s["name"])}</td><td>{s["minutes_proposed"]} min propostos</td><td>{esc(s.get("rule", "Critério específico descrito no QA experimental"))}</td></tr>' for s in recipe['steps'])
    return f'''<h2>{esc(recipe['name'])}</h2>
    <p><strong>Fonte:</strong> <a href="{esc(recipe['source_url'])}" target="_blank" rel="noreferrer">Ficha PS existente da matéria-prima</a>. <strong>Natureza:</strong> somente parâmetros PRE-Q2/experimentais, jamais estoque real.</p>
    <div class="grid"><div class="panel"><h3>Insumos e requisitos</h3><p>{esc(recipe['auxiliary_materials'])}</p><p><strong>Rendimento pretendido:</strong> {esc(recipe['output']['quantity'])} {esc(recipe['output']['unit'])}; efetivo somente se QA simulado aprovado.</p><p><strong>Tempo proposto:</strong> {esc(recipe['proposed_active_minutes'])} minutos · sem duração real medida</p><p><strong>MED:</strong> pendente; fórmula de custo proposta, sem preço oficial.</p><details><summary>Fórmula de custo simbólico</summary><code>{esc(recipe['cost_expression'])}</code></details></div><div class="panel"><h3>Estoque fictício atual</h3>{rows_stock(stock)}</div></div>
    <section class="panel"><h3>Etapas do motor R44 (execução simulada)</h3><table><thead><tr><th>#</th><th>Processamento</th><th>Duração</th><th>Regra proposta</th></tr></thead><tbody>{steps}</tbody></table></section>
    <form method="post" action="/fabricar"><input type="hidden" name="csrf" value="{esc(token)}"><input type="hidden" name="batch_id" value="{esc(batch_id)}"><input type="hidden" name="recipe" value="{esc(recipe['design_id'])}">
      <fieldset><legend>2. Selecionar insumos fictícios</legend>{''.join(selection)}</fieldset>
      <fieldset><legend>3. Disponibilidade de ferramentas e conhecimento SIMULADOS</legend><div class="grid"><div>{ts}</div><div>{sk}</div></div><small>Desmarcar um requisito poderá bloquear a fabricação.</small></fieldset>
      <fieldset><legend>4. Leituras de QA FICTÍCIAS (editáveis)</legend><p>Os valores iniciais são exemplos, não medições. A assinatura digital gerada será de TESTE, com chaves públicas inseguras. Todos os campos abaixo são verificados pelos motores existentes.</p>
      <table><thead><tr><th>Campo</th><th>Critério experimental</th><th>Leitura fictícia</th></tr></thead><tbody>{''.join(qfields)}</tbody></table></fieldset>
      <div class="buttons"><button type="submit" name="mode" value="preflight" class="subtle">Conferir recursos e QA</button><button type="submit" name="mode" value="execute">Executar tentativa sintética</button></div>
    </form>'''


class Handler(BaseHTTPRequestHandler):
    server_version='CRAFT-SBX-UI/1.0'
    def log_message(self,fmt,*args):
        # Never print report bodies/tokens/stock outside local process stdout.
        sys.stderr.write('CRAFT local '+fmt%args+'\n')

    @property
    def studio(self):return self.server.studio

    def _send(self,body,status=200,ctype='text/html; charset=utf-8',filename=None):
        data=body.encode('utf-8') if isinstance(body,str) else body
        self.send_response(status)
        self.send_header('Content-Type',ctype)
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'")
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.send_header('Content-Length',str(len(data)))
        self.end_headers();self.wfile.write(data)

    def _redirect(self,path):
        self.send_response(303);self.send_header('Location',path);self.send_header('Cache-Control','no-store');self.end_headers()

    def _query(self):return {k:v[-1] for k,v in parse_qs(urlsplit(self.path).query,keep_blank_values=True).items()}

    def do_GET(self):
        try:
            path=urlsplit(self.path).path
            if path=='/favicon.ico':self._send('',404);return
            if path=='/':return self.home()
            if path=='/receita':return self.view_recipe()
            if path=='/historico':return self.history()
            if path=='/recibo':return self.receipt()
            if path=='/ajuda':return self.help()
            if path=='/baixar':return self.download_receipt()
            if path=='/sessoes':return self.sessions()
            self._send(layout('<div class="error">Endereço não encontrado.</div>',sid=self.studio.session_id()),404)
        except Exception as e:self.fail(e)

    def _post(self):
        n=int(self.headers.get('Content-Length','0'))
        if not 0<n<=30000:raise ValueError('TAMANHO_FORMULARIO_INVALIDO')
        ctype=self.headers.get('Content-Type','')
        if not ctype.startswith('application/x-www-form-urlencoded'):raise ValueError('FORMULARIO_INVALIDO')
        data=self.rfile.read(n).decode('utf8')
        fields={k:v[-1] for k,v in parse_qs(data,keep_blank_values=True).items()}
        if not secrets.compare_digest(fields.get('csrf',''),self.studio.token):raise ValueError('FORMULARIO_TOKEN_INVALIDO')
        return fields

    def do_POST(self):
        try:
            v=self._post()
            path=urlsplit(self.path).path
            if path=='/novo':
                q={k:int(v.get('quantity_'+k,'-1')) for k in DEFAULT_QTY}
                sid=self.studio.init(q)
                return self._redirect('/?mensagem=Nova+sessao+ficticia+criada')
            if path=='/fabricar':
                batch=v.get('batch_id','')
                raw=self.studio.parse_order(v)
                if v.get('mode')=='preflight':
                    p=self.studio.preflight(raw)
                    # Show preflight and still permit the operator to execute or return to edit.
                    warn=('<p class="good">Pré-validação sem alertas. A execução ainda depende do motor e da evidência TESTE.</p>' if not p['stock_and_tool_reasons'] and not p['qa_reasons']
                          else '<p class="bad">Possível bloqueio/reprovação. O estoque continuará sujeito ao contrato original.</p>')
                    details='<p><strong>Estoque/ferramentas:</strong> '+esc(p['stock_and_tool_reasons'] or 'PASS')+'</p><p><strong>QA:</strong> '+esc(p['qa_reasons'] or 'PASS proposto')+'</p>'
                    button=f'<form method="post" action="/fabricar"><input type="hidden" name="csrf" value="{esc(self.studio.token)}"><input type="hidden" name="mode" value="execute">'+''.join(f'<input type="hidden" name="{esc(k)}" value="{esc(x)}">' for k,x in v.items() if k not in ('csrf','mode'))+'<button type="submit">Confirmar e fabricar (simulação)</button></form>'
                    return self._send(layout('<section class="panel"><h2>Pré-validação do pedido</h2>'+warn+details+button+'<p><a href="/receita?code='+esc(raw['recipe'])+'">Voltar e editar</a></p></section>',sid=self.studio.session_id()))
                result=self.studio.commit(raw,batch)
                return self._redirect('/recibo?batch='+quote(result['receipt']['batch_id']))
            if path=='/repetir':
                bid=v.get('batch_id','')
                a=self.studio.repeat(bid)
                return self._send(layout('<section class="panel"><h2>Repetição idempotente executada</h2><p class="good">Pedido reconhecido, sem consumo adicional.</p><p><strong>idempotent_replay:</strong> '+esc(a['idempotent_replay'])+'</p><p><strong>HEAD:</strong> <code>'+esc(a['r48_head'])+'</code></p><p><a href="/recibo?batch='+quote(bid)+'">Ver comprovante original</a></p></section>',sid=self.studio.session_id()))
            if path=='/desfazer':
                out=self.studio.undo_last()
                msg=f'<section class="panel"><h2>Reversão por fork concluída</h2><p class="good">Saldo experimental restaurado ao checkpoint anterior.</p><p>A sessão original <code>{esc(out["old_session"])}</code> foi PRESERVADA com todos os registros.</p><p>Nova sessão ativa: <code>{esc(out["new_session"])}</code>.</p><h3>Antes da reversão</h3><pre>{esc(canon(out["stock_before"]))}</pre><h3>Após reversão</h3><pre>{esc(canon(out["stock_after"]))}</pre><p><a href="/">Voltar à nova sessão</a></p></section>'
                return self._send(layout(msg,sid=self.studio.session_id()))
            if path=='/trocar':
                self.studio.switch(v.get('sid',''))
                return self._redirect('/')
            raise ValueError('ACAO_NAO_SUPORTADA')
        except Exception as e:self.fail(e)

    def fail(self,e):
        # Distinguish a rejected attempt from a webserver failure.
        message=f'<div class="error"><h2>Operação recusada, sem liberação de produção</h2><p><strong>{esc(type(e).__name__)}</strong>: {esc(str(e))}</p><p>Consulte o histórico; uma falha de gravação ambígua exige recuperação do estado antes de retry.</p><a href="/">Retornar</a></div>'
        self._send(layout(message,sid=self.studio.session_id() if self.studio.active_file.exists() else None),status=400)

    def home(self):
        with self.studio.lock:
            store,f,pointer=self.studio.active_store()
        q=self._query()
        info=('<div class="info">'+esc(q['mensagem'])+'</div>') if 'mensagem' in q else ''
        if store is None:
            return self._send(layout(info+ready_form(self.studio.token)))
        row=f'<section class="panel"><h2>Oficina ativa</h2><p><strong>Lotes confirmados no ledger local:</strong> {pointer["sequence"]}. Produtos experimentais armazenados: {len(f.core.state["products"])}. Auditoria: {"PASS" if f.audit()["ok"] else "FAIL"}.</p>{rows_stock(f)}</section>'
        recipes=''.join(f'<div class="panel"><h3>{esc(code)} — {esc(NAMES[code])}</h3><p>{esc(self.studio.recipe(code)["output"]["quantity"])} {esc(self.studio.recipe(code)["output"]["unit"])} previstos, sujeitos a QA.</p><a class="button" href="/receita?code={code}">Selecionar esta receita</a></div>' for code in RECIPES)
        backup=f'<section class="panel"><h2>Gestão de testes</h2><div class="buttons"><a class="button subtle" href="/historico">Recibos e relatório</a><a class="button subtle" href="/sessoes">Sessões salvas</a><form method="post" action="/desfazer"><input type="hidden" name="csrf" value="{esc(self.studio.token)}"><button class="danger" type="submit" {"disabled" if pointer["sequence"]<1 else ""}>Reverter último lote fictício</button></form></div><p><small>A reversão cria uma cópia do checkpoint anterior; preserva o histórico original.</small></p></section>'
        return self._send(layout(info+row+'<div class="grid">'+recipes+'</div>'+backup+ready_form(self.studio.token),sid=self.studio.session_id()))

    def view_recipe(self):
        code=self._query().get('code','B30-01')
        with self.studio.lock:
            store,f,_=self.studio.active_store()
        if f is None:return self._send(layout('<div class="error">Crie primeiro um estoque fictício. <a href="/">Início</a></div>'))
        batch='SBX-R48-BATCH-UI-'+secrets.token_hex(8)
        return self._send(layout('<section class="panel">'+recipe_form(self.studio.recipe(code),f,self.studio.token,batch)+'</section>',sid=self.studio.session_id()))

    def _receipt_for(self,batch):
        if not BATCH_RE.fullmatch(batch):raise ValueError('RECIBO_INVALIDO')
        with self.studio.lock:
            store,f,_=self.studio.active_store()
            if f is None:raise ValueError('SEM_SESSAO')
            entry=f.seen_batches.get(batch)
        if entry is None:raise ValueError('RECIBO_NAO_LOCALIZADO_NA_SESSAO_ATIVA')
        return entry['receipt']

    def receipt(self):
        batch=self._query().get('batch','')
        receipt=self._receipt_for(batch)
        blocks=[]
        for i,o in enumerate(receipt['orders'],1):
            stages=''.join('<tr><td>'+esc(s['seq'])+'</td><td>'+esc(s['name'])+'</td><td>'+esc(s['minutes_proposed'])+' min propostos</td></tr>' for s in o['process_trace']) or '<tr><td colspan="3">Etapas não executadas: rejeição/ quarentena antes da fabricação.</td></tr>'
            products=''.join(f'<li>{esc(x["name"])} — {esc(x["units"])} {esc(x["unit"])} — ID <code>{esc(x["product_id"])}</code></li>' for x in o['products']) or '<li>Nenhum produto gerado.</li>'
            recipe=self.studio.recipe('B30-01' if o['recipe_key']==RECIPES['B30-01'] else 'B30-03')
            geom=theoretical_yield(recipe)
            product_units=sum(p['units'] for p in o['products'])
            material_math=(f'<p><strong>Rendimento de saída do motor R44:</strong> {product_units} unidade(s) fictícia(s) fabricada(s) / '
                           f'{recipe["output"]["quantity"]} unidade(s) projetada(s) para uma tentativa aprovada. '
                           'Não é taxa de sucesso observada em lote real.</p>'
                           f'<p><strong>Projeção geométrica proposta (NÃO medida):</strong> entrada {esc(geom["input_geometry"])}, '
                           f'saída {esc(geom["output_geometry"])}, aparas ideais {esc(geom["ideal_nominal_scrap"])}, '
                           f'aproveitamento nominal de {esc(geom["theoretical_recovery_pct"])}%. '
                           'Não equivale a perdas registradas de material, massa, custo ou produtividade real.</p>')
            blocks.append(f'<section class="panel"><h2>Tentativa {i} · {esc(o["status"])}</h2><p><strong>Motivos:</strong> {esc(o["reasons"] or "nenhum")}</p><h3>Processamento (R44)</h3><table><tr><th>#</th><th>Etapa</th><th>Tempo simulado</th></tr>{stages}</table><h3>Saída experimental</h3><ul>{products}</ul><p><strong>Consumo:</strong> {esc(o["consumed"] or "zero")}<br><strong>Perdas/refugo:</strong> {esc(o["waste"] or "nenhuma registrada")}</p><p><strong>Evidência R47:</strong> {esc(o["authenticity"]["status"])} · certificado público de TESTE, <strong>não</strong> laudo físico.</p>{material_math}<p><strong>Custo:</strong> fórmula apenas PROPOSTA; MED oficial não calculado.</p></section>')
        stock=''.join(f'<tr><td>{esc(LOT_NAMES.get(lid,lid))}</td><td>{esc(receipt["stock_before"][lid])}</td><td>{esc(receipt["stock_after"][lid])}</td><td>{receipt["stock_after"][lid]-receipt["stock_before"][lid]:+d}</td></tr>' for lid in receipt['stock_before'])
        follow=f'<section class="panel"><h2>Recuperação e idempotência</h2><div class="buttons"><form method="post" action="/repetir"><input type="hidden" name="csrf" value="{esc(self.studio.token)}"><input type="hidden" name="batch_id" value="{esc(batch)}"><button type="submit">Repetir o mesmo pedido sem consumir novamente</button></form><a class="button subtle" href="/baixar?batch={quote(batch)}">Baixar recibo JSON</a><a class="button subtle" href="/historico">Consultar histórico</a></div></section>'
        top=f'<h2>Comprovante de fabricação fictícia</h2><p><strong>Lote:</strong> <code>{esc(batch)}</code></p><p><strong>Resultado:</strong> {esc(receipt["status"])}</p><p>Produtos físicos: <strong>0</strong> · REC-ID oficiais: <strong>0</strong>.</p><section class="panel"><h3>Saldo antes → depois</h3><table><tr><th>Lote</th><th>Antes</th><th>Depois</th><th>Variação</th></tr>{stock}</table></section>'
        return self._send(layout(top+''.join(blocks)+follow,sid=self.studio.session_id()))

    def history(self):
        with self.studio.lock:
            _,f,pointer=self.studio.active_store()
        if f is None:return self._redirect('/')
        records=[]
        for i,entry in enumerate(f.journal,1):
            b=entry['event']['batch_id'];v=f.seen_batches[b]['receipt']
            records.append(f'<tr><td>{i}</td><td><a href="/recibo?batch={quote(b)}">{esc(b)}</a></td><td>{esc(v["status"])}</td><td>{esc(v["experimental_product_count"])}</td><td>{esc(v["request_sha256"][:12])}</td></tr>')
        p='<p>Nenhuma fabricação nesta sessão.</p>' if not records else '<table><thead><tr><th>#</th><th>Lote</th><th>Status</th><th>Produtos</th><th>SHA pedido</th></tr></thead><tbody>'+''.join(records)+'</tbody></table>'
        out=f'<section class="panel"><h2>Relatório de fabricação e histórico imutável</h2><p>Ledger R48 auditado: <strong>{"PASS" if f.audit()["ok"] else "FAIL"}</strong>, {pointer["sequence"]} transações, {len(f.core.state["products"])} produtos sintéticos. HEAD <code>{esc(pointer["r48_head"][:24])}…</code></p>{p}</section><section class="panel"><h3>Estoque atual</h3>{rows_stock(f)}</section>'
        return self._send(layout(out,sid=self.studio.session_id()))

    def sessions(self):
        cards=[];active=self.studio.session_id()
        for sid in self.studio.list_sessions():
            try:
                factory,state=DurableFactory(self.studio.path(sid)/'store').recover()
                cards.append(f'<tr><td><code>{esc(sid)}</code> {"(ATIVA)" if sid==active else ""}</td><td>{state["sequence"]}</td><td>{len(factory.core.state["products"])}</td><td><form method="post" action="/trocar"><input type="hidden" name="csrf" value="{esc(self.studio.token)}"><input type="hidden" name="sid" value="{esc(sid)}"><button class="subtle" type="submit">Abrir esta sessão</button></form></td></tr>')
            except Exception as e:cards.append(f'<tr><td><code>{esc(sid)}</code></td><td colspan="3" class="bad">Não recuperável: {esc(e)}</td></tr>')
        return self._send(layout('<section class="panel"><h2>Sessões locais preservadas</h2><table><tr><th>Sessão</th><th>Commits</th><th>Produtos sintéticos</th><th>Ação</th></tr>'+''.join(cards)+'</table></section>',sid=active))

    def download_receipt(self):
        batch=self._query().get('batch','')
        return self._send(canon(self._receipt_for(batch)),ctype='application/json; charset=utf-8',filename=f'{batch}.json')

    def help(self):
        out='''<section class="panel"><h2>Como utilizar — sem editar arquivos</h2><ol><li>Na página Início, crie estoque fictício (quantidades editáveis).</li><li>Clique Tábua B30-01 ou Mica B30-03.</li><li>Selecione as lâminas/folhas e veja as ferramentas, etapas e tolerâncias de QA.</li><li>Edite os valores de QA fictícios ou desmarque um requisito para testar reprovação.</li><li>Clique Conferir para prévia e depois Confirmar ou Execute diretamente.</li><li>Leia o comprovante: estágio a estágio, qualidade, consumo, perdas e saldo antes/depois.</li><li>Use Repetir: o mesmo lote não consome de novo. Histórico exporta recibos JSON.</li><li>Use Reverter último lote: cópia do checkpoint anterior torna-se ativa; o original permanece arquivado e acessível em Sessões.</li></ol><p><strong>Limites:</strong> Não liga ao Notion ou estoque oficial; assinaturas e datas dos laudos são fixtures fictícios de outubro/2026, não laudos reais; não existe simulação de efeitos mágicos nem MED confiável. Se o browser informar erro de efeito incerto, verifique Histórico, não gere pedido duplicado.</p><p>Dados são armazenados somente na pasta <code>SESSOES-FICTICIAS</code> (ou diretório escolhido na inicialização); o motor R48 não foi modificado. Reversão é um fork íntegro da sessão anterior, não apagamento dos dados.</p></section>'''
        return self._send(layout(out,sid=self.studio.session_id()))


def serve(root,host,port,open_browser=True):
    studio=Studio(root)
    server=ThreadingHTTPServer((host,port),Handler)
    server.studio=studio
    u=f'http://{host}:{server.server_address[1]}/'
    print('\nCRAFT EXPERIMENTAL — SOMENTE DADOS FICTÍCIOS\n',u,'\nCTRL+C para encerrar. Nenhuma conexão Notion.\n',flush=True)
    if open_browser:
        try:webbrowser.open(u)
        except Exception:pass
    try:server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Interface web local do motor CRAFT R48, somente simulação')
    ap.add_argument('--port',type=int,default=8765)
    ap.add_argument('--host',default='127.0.0.1',choices=['127.0.0.1','localhost'])
    ap.add_argument('--data',type=Path,default=HERE/'SESSOES-FICTICIAS')
    ap.add_argument('--no-browser',action='store_true')
    args=ap.parse_args()
    serve(args.data,args.host,args.port,not args.no_browser)
