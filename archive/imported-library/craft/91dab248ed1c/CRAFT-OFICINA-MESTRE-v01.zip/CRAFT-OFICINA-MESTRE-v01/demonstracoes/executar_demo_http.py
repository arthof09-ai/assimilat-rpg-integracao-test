#!/usr/bin/env python3
"""Demonstrate the real local HTTP interface, not a fabricated UI screenshot.

Runs under the same user interface handlers, using synthetic fixtures only.
It is an AUTOMATED browser-protocol check, not a human UAT.
"""
from __future__ import annotations
import json
import re
import sys
import tempfile
import threading
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import Handler,Studio,LOT_NAMES,RECIPES,canon

class BrowserForm(HTMLParser):
    def __init__(self):
        super().__init__();self.forms=[];self.cur=None;self.select=None
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if tag=='form':
            self.cur={'method':d.get('method'),'action':d.get('action'),'values':{}}
            self.forms.append(self.cur)
        elif tag=='input' and self.cur is not None:
            n=d.get('name')
            if not n: return
            if d.get('type')=='checkbox' and 'checked' not in d:return
            self.cur['values'][n]=d.get('value','on')
        elif tag=='select' and self.cur is not None:
            self.select={'name':d.get('name'),'seen':False}
        elif tag=='option' and self.select is not None and self.cur is not None:
            if 'selected' in d or not self.select['seen']:
                self.cur['values'][self.select['name']]=d['value']
                self.select['seen']=True
    def handle_endtag(self,tag):
        if tag=='form':self.cur=None
        if tag=='select':self.select=None

def run(write_dir=None):
    root=Path(tempfile.mkdtemp(prefix='craft_http_demo_'))
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    server.studio=Studio(root)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    base=f'http://127.0.0.1:{server.server_address[1]}'
    def get(path):
        try:
            with urllib.request.urlopen(base+path,timeout=30) as r:return r.read().decode('utf8')
        except urllib.error.HTTPError as e:
            print('HTTPERR',e.code,e.read().decode('utf8')[-1600:]);raise
    def post(path,values):
        encoded=urllib.parse.urlencode(values).encode('ascii')
        with urllib.request.urlopen(base+path,data=encoded,timeout=30) as r:return r.read().decode('utf8')
    def form(page,path,number=0):
        p=BrowserForm();p.feed(get(page))
        choices=[f for f in p.forms if f['action']==path]
        if len(choices)<=number:raise AssertionError(f'FORM NOT FOUND {page} {path}')
        return dict(choices[number]['values'])
    def latest(store,bid):return store.active_store()[1].seen_batches[bid]['receipt']
    output={'scope':'HTTP_UI_AUTOMATED_DEMO_SYNTHETIC_ONLY','motor':'R44+R47+R48-ORIGINAL','human_uat':'PENDENTE',
            'scenarios':{},'official_stock_effect':0,'official_rc5':0,'physical_fabrication':0}
    try:
        assert 'CRAFT' in get('/')
        # A: use actual HTML init form and real POST handler to create fictional inventory.
        s=form('/','/novo');post('/novo',s)
        success_sid=server.studio.session_id()
        assert success_sid is not None
        a=form('/receita?code=B30-01','/fabricar')
        assert a['recipe']=='B30-01'
        # Separate HTTP preflight POST: no stock write.
        p=dict(a,mode='preflight');pre=post('/fabricar',p)
        assert 'Pré-validação' in pre and 'Pré-validação sem alertas' in pre
        page=post('/fabricar',dict(a,mode='execute'))
        bid=a['batch_id']
        assert 'Comprovante de fabricação' in page
        first=latest(server.studio,bid)
        one=first['orders'][0]
        assert one['status']=='EXPERIMENTAL_QA_PASS'
        assert first['stock_before']['SBX-SLATE-GOOD-01']==2
        assert first['stock_after']['SBX-SLATE-GOOD-01']==1
        assert len(one['process_trace'])==6 and len(one['products'])==1
        assert one['authenticity']['status']=='SIMULATED_CRYPTO_VALID_NOT_REAL'
        output['scenarios']['A_success']={'status':one['status'],'product':one['products'],'process_trace':one['process_trace'],
            'stock_before':first['stock_before'],'stock_after':first['stock_after'],
            'batch_id':bid,'receipt_sha256':__import__('hashlib').sha256(canon(first).encode('utf8')).hexdigest(),
            'r47':one['authenticity']['status'],'source':'Actual POST /fabricar via HTTP form'}
        # C: real replay through UI POST and compare stable stock and durable head.
        before_state=server.studio.active_store()[2]
        page=post('/repetir',{'csrf':server.studio.token,'batch_id':bid})
        after_state=server.studio.active_store()[2]
        assert 'Repetição idempotente executada' in page
        assert before_state['r48_head']==after_state['r48_head'] and before_state['sequence']==after_state['sequence']
        output['scenarios']['C_replay']={'idempotent':True,'same_head':True,'same_sequence':True,
            'stock_after':server.studio.active_store()[1].quantities,'source':'Actual POST /repetir'}
        # A second product from separate original engine via browser.
        mica=form('/receita?code=B30-03','/fabricar')
        bpage=post('/fabricar',dict(mica,mode='execute'))
        mreceipt=latest(server.studio,mica['batch_id']);m=mreceipt['orders'][0]
        assert m['status']=='EXPERIMENTAL_QA_PASS' and m['products'][0]['units']==2
        assert mreceipt['stock_after']['SBX-MICA-GOOD-A']==0 and mreceipt['stock_after']['SBX-MICA-GOOD-B']==0
        output['scenarios']['A2_mica_optional']={'status':m['status'],'product_units':m['products'][0]['units'],
            'stock_before':mreceipt['stock_before'],'stock_after':mreceipt['stock_after']}
        # D: real route for undo/fork rollback; old history retained.
        un_page=post('/desfazer',{'csrf':server.studio.token})
        new_sid=server.studio.session_id()
        assert new_sid!=success_sid and 'Reversão por fork concluída' in un_page
        new_f=server.studio.active_store()[1]
        old_f=__import__('app').DurableFactory(server.studio.path(success_sid)/'store').recover()[0]
        assert new_f.quantities['SBX-MICA-GOOD-A']==1 and old_f.quantities['SBX-MICA-GOOD-A']==0
        assert len(old_f.journal)==2 and len(new_f.journal)==1
        output['scenarios']['D_reversal']={'result':'fork previous durable checkpoint','old_session':success_sid,
            'new_session':new_sid,'stock_original_preserved':old_f.quantities,'stock_active_restored':new_f.quantities,
            'old_history_events':len(old_f.journal),'new_history_events':len(new_f.journal),
            'source':'Actual POST /desfazer'}
        # Browser accessible export of original receipt (switch session through HTML POST).
        post('/trocar',{'csrf':server.studio.token,'sid':success_sid})
        dl=get('/baixar?batch='+urllib.parse.quote(bid))
        assert json.loads(dl)['batch_id']==bid
        assert 'Relatório de fabricação' in get('/historico')
        # B: a separate NEW fictional session with 0 slate. No official stock impact.
        init=form('/','/novo');init['quantity_SBX-SLATE-GOOD-01']='0';post('/novo',init)
        fail=form('/receita?code=B30-01','/fabricar')
        fail_page=post('/fabricar',dict(fail,mode='execute'))
        bad=latest(server.studio,fail['batch_id']);o=bad['orders'][0]
        assert o['status']=='REJECTED_PRECHECK' and len(o['products'])==0
        assert bad['stock_before']==bad['stock_after']
        assert 'REJECTED_PRECHECK' in fail_page
        output['scenarios']['B_insufficient']={'status':o['status'],'reasons':o['reasons'],
            'stock_before':bad['stock_before'],'stock_after':bad['stock_after'],
            'products':o['products'],'source':'Actual POST /fabricar with zero slate test stock'}
        # Additional: bad QA reading, R47 does not manufacture or consume.
        post('/novo',form('/','/novo'))
        badqa=form('/receita?code=B30-01','/fabricar')
        badqa['qa_length_mm']='999'
        qa_page=post('/fabricar',dict(badqa,mode='execute'))
        qa_rec=latest(server.studio,badqa['batch_id']);q=qa_rec['orders'][0]
        assert q['status']=='QUARANTINE_EVIDENCE' and not q['products']
        assert qa_rec['stock_before']==qa_rec['stock_after']
        output['scenarios']['B2_invalid_quality']={'status':q['status'],'reasons':q['reasons'],
            'stock_before':qa_rec['stock_before'],'stock_after':qa_rec['stock_after'],
            'source':'Actual POST /fabricar with QA length 999 mm; unsigned real evidence NOT accepted'}
        output['browser_flow_steps']=['GET /','POST /novo','GET /receita','POST /fabricar preflight',
            'POST /fabricar success','GET /recibo','POST /repetir','POST /fabricar mica',
            'POST /desfazer','POST /trocar','GET /baixar','GET /historico',
            'POST /novo empty slate','POST /fabricar rejected','POST /novo','POST /fabricar invalid QA']
        output['result']='PASS_AUTOMATED_HTTP_NOT_HUMAN_UAT'
    finally:
        server.shutdown();thread.join(timeout=6);server.server_close()
    if write_dir:
        path=Path(write_dir);path.mkdir(parents=True,exist_ok=True)
        (path/'demonstracao_http.json').write_text(canon(output),encoding='utf8')
        for name,entry in output['scenarios'].items():
            (path/(name+'.json')).write_text(canon(entry),encoding='utf8')
    return output

if __name__=='__main__':
    o=run(ROOT/'demonstracoes'/'resultados')
    print('RESULTADO:',o['result'])
    for name,entry in o['scenarios'].items():print(name,entry['status'] if 'status' in entry else entry.get('result','PASS'))
