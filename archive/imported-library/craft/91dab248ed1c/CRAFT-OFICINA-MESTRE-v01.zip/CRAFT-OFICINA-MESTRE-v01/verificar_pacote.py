#!/usr/bin/env python3
"""Verifies distributed CRAFT UI archive and historical ZIPs; no production action."""
from __future__ import annotations
import hashlib,json,sys,zipfile
from pathlib import Path

SHA_R52='abb373d4b25ca017c91adf7dec17e25f3f73bed7a8973d419921be3addf276ee'
SHA_R48='073530965279de725c35460ea3236867a62d1c0b45cd41f26cf3dbaf30c0b5bc'
SHA_R51='7d18136e1220f1ba2c0b784d27fa9a3d62b2de079b1534b3da89f49725c1803f'

def filehash(data):return hashlib.sha256(data).hexdigest()

def verify(zip_path):
    p=Path(zip_path)
    with zipfile.ZipFile(p) as z:
        crc=z.testzip()
        if crc:raise AssertionError('ZIP_CRC_FAILED:'+crc)
        names=z.namelist()
        assert names and len(names)==len(set(names))
        assert all(not x.startswith('/') and '..' not in Path(x).parts for x in names)
        meta=json.loads(z.read('CRAFT-OFICINA-MESTRE-v01/MANIFEST-SHA256.json'))
        actual=[n for n in names if n!='CRAFT-OFICINA-MESTRE-v01/MANIFEST-SHA256.json']
        assert set(actual)==set(meta['files']),('MANIFEST_SET_DIFF',len(actual),len(meta['files']))
        for name in actual:
            digest=filehash(z.read(name))
            assert digest==meta['files'][name],('SHA_DIFF',name,digest,meta['files'][name])
        base='CRAFT-OFICINA-MESTRE-v01/historico/'
        assert filehash(z.read(base+'CRAFT-R52-I0016-DESBLOQUEIO-COORDENADO-v01.zip'))==SHA_R52
        assert filehash(z.read(base+'CRAFT-R48-I0016-FABRICA-INTEGRADA-v01.zip'))==SHA_R48
        with zipfile.ZipFile(__import__('io').BytesIO(z.read(base+'CRAFT-R52-I0016-DESBLOQUEIO-COORDENADO-v01.zip'))) as r52:
            assert r52.testzip() is None
            r51=next(n for n in r52.namelist() if n.endswith('CRAFT-R51-I0016-RECUPERACAO-E-DESBLOQUEIO-v01.zip'))
            assert filehash(r52.read(r51))==SHA_R51
        with zipfile.ZipFile(__import__('io').BytesIO(z.read(base+'CRAFT-R48-I0016-FABRICA-INTEGRADA-v01.zip'))) as r48:
            assert r48.testzip() is None
            original={n:r48.read(n) for n in r48.namelist()}
            mapped={n.split('CRAFT-R48-SANDBOX-I0016/',1)[1]:blob for n,blob in original.items() if n.startswith('CRAFT-R48-SANDBOX-I0016/')}
            for short,content in mapped.items():
                archived='CRAFT-OFICINA-MESTRE-v01/CRAFT-R48-SANDBOX-I0016/'+short
                assert archived in z.namelist() and z.read(archived)==content,('R48_CHANGED',short)
    return {'status':'PASS','file_count':len(actual),'zip_crc':'PASS','manifest_sha256':'PASS',
            'r48_unmodified_members':len(mapped),'r48_original_sha256':SHA_R48,
            'r52_original_sha256':SHA_R52,'r51_original_sha256':SHA_R51,'scope':'SYNTHETIC_ONLY'}

if __name__=='__main__':
    if len(sys.argv)<2:sys.exit('Uso: python verificar_pacote.py caminho/CRAFT-OFICINA-MESTRE-v01.zip')
    print(json.dumps(verify(sys.argv[1]),indent=2))
