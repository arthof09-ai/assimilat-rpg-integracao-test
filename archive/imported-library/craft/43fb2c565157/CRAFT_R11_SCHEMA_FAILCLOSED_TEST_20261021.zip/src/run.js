'use strict';
/* CRAFT-R10: mantém o motor de leitura R53/R8/R9; normaliza REJECT sem prévia Player aparente. */
const fs=require('fs'),path=require('path');
const {valid,playerSafe}=require('./validate');
const root=path.join(__dirname,'..');
const outputs=path.join(root,'outputs');
fs.mkdirSync(outputs,{recursive:true});
let d,resources,res;
try {
  d=JSON.parse(fs.readFileSync(path.join(root,'data','proposals.json'),'utf8'));
  resources=JSON.parse(fs.readFileSync(path.join(root,'data','resources.json'),'utf8'));
  res=valid(d,resources);
  if(!res||typeof res!=='object'||typeof res.status!=='string')throw Error('Invalid validator response');
} catch(err) {
  // Não expõe dados sensíveis do arquivo de entrada no recibo.
  res={status:'REJECT',items:[{id:null,verdict:'REJECT',issues:[{code:'INPUT_OR_VALIDATOR_INVALID',msg:'Formato inválido; revisão manual exigida'}],holds:[],evidence:[]}],total:0,distinct_sources:0,
    disclaimer:'Entrada inválida ou exceção de validação, nenhuma autorização de fabricação/publicação.'};
}
const blocked=res.status==='REJECT';
fs.writeFileSync(path.join(outputs,'QA_RESULT.json'),JSON.stringify(res,null,2)+'\n');
const preview=blocked
  ? {status:'REJECT_NO_PLAYER_PREVIEW',disclosure_status:'NÃO PUBLICAR',items:[]}
  : (Array.isArray(d?.products)?d.products.map(playerSafe):[]);
fs.writeFileSync(path.join(outputs,'PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'),JSON.stringify(preview,null,2)+'\n');
const items=Array.isArray(res.items)?res.items:[];
console.log(JSON.stringify({status:res.status,total:res.total||0,resources:res.distinct_sources||0,
  preview_blocked:blocked,projects:items.map(x=>({name:x.name||null,verdict:x.verdict||'REJECT',holds:(x.holds||[]).length,issues:(x.issues||[]).length}))},null,2));
if(blocked)process.exitCode=2;
