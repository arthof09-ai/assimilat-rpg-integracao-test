# Revisor de arquivos exportados pela Bancada CRAFT Android — TEST

**Trace:** CRAFT-MOBILE-REVIEW-20261021-001 · CM-000002/WS0001 · OP-ARQ-RIN-REC-01 · MESTRE-SIDE.

## O que faz

Valida o FORMATO de um JSON exportado pela Bancada CRAFT Android v1.0/v1.1, recalculando cada avaliação pelo **mesmo código `logic.js` da v1.1**, com SHA-256 fixado. Identifica diferenças entre o cálculo e o campo `evaluation` enviado, amostras duplicadas, resumo alterado, versão incompatível, JSON malformado ou tentativa de incluir `official_writes` diferentes de zero. Emite um relatório com SHA-256 dos bytes recebidos, resultados recalculados e problemas encontrados. **Não lê Notion, não cria receitas e não escreve nada no RPG.**

## Como usar

Com Node.js instalado, extraia os arquivos e execute:

```bash
node review_capture.js MEU_ARQUIVO_EXPORTADO.json RELATORIO_REVISADO.json
```

Ou envie o JSON exportado a um Comestre Mestre-side que disponha de execução local e peça para processá-lo **sem expor dados Mestre-only à Party**. O arquivo `exemplo_SOMENTE_SINTETICO.json` é uma demonstração fictícia, não uma medição real.

Para reproduzir a verificação de software:

```bash
node test_review.js
node review_capture.js exemplo_SOMENTE_SINTETICO.json relatorio_exemplo_SINTETICO.review.json
```

A execução normal retorna `REVIEW_REQUIRED_NO_AUTOCANON`; se detectar conflitos, `REVIEW_QUARANTINE`. O primeiro estado **não significa que a medição física é verdadeira ou validada**: apenas que o JSON está internamente consistente com o software de captura. A integridade de um arquivo SHA-256 não comprova quem o criou, se sofreu edições antes da leitura, se a calibração/operador são legítimos ou se os dados correspondem ao item.

## Compatibilidade / sem novo motor

Foi reaberto e verificado o ZIP CRAFT_BANCADA_ANDROID_B30_01_02_03_V11_20261021.zip, SHA-256 `42f7337bf5b89f429a38a075209fdf0dd0d582b18b0069ccd5078281fec6a520`. O código `logic.js` deste pacote é byte-idêntico ao da versão 1.1 (SHA-256 `1067deec34d5b48667b62ac48a1aad1b6fb172e44178854a259cebbf64d15421`), usado como dependência, não recodificado. O script apenas verifica exportação de dados de campo; o fluxo R45/R46 de metrologia, o motor R48 e a aprovação NAC-PASS permanecem separados.

**Autoridade:** F5 P0 RED; C19-021 UNKNOWN-SIDE-EFFECT; IBX38 fencing pendente; R51 destino REC-LIB pendente. Todos os relatórios preservam `physical_verified=false`, `rc5_created=0`, `official_writes=0`, `notion_write=false`, `party_write=false`. O script não tem mecanismo para liberar nenhum desses gates.

## Atualização do mesmo pacote — 21/10/2026 (v1.1 do revisor)

Em revisão independente, o revisor passou a sinalizar **o mesmo identificador de amostra em lotes diferentes** com `SAMPLE_ID_REUSED_CROSS_LOTS_INDEPENDENCE_UNKNOWN`. Essa situação é suspeita de reutilização de unidade experimental, não prova de fraude ou duplicata física. O relatório informa `independence_verified=false` mesmo quando todos os registros são válidos. Também rejeita alegação diferente da origem `SELF_DECLARED_OFFLINE_NO_NOTION_SYNC`. Foi mantido o mesmo arquivo/linha de ferramenta, com verificação regressiva, sem novo motor.
