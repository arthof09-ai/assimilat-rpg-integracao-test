/* READ-ONLY reviewer for field data exported from CRAFT Android offline.
   REUSES exact existing logic.js v1.1; NOT a fabrication engine / Notion client. */
'use strict';
const {readFileSync,writeFileSync}=require('node:fs');
const {createHash}=require('node:crypto');
const {resolve}=require('node:path');
const QA=require('./logic.js');
const SOURCE_PIN='1067deec34d5b48667b62ac48a1aad1b6fb172e44178854a259cebbf64d15421';
function digest(data){return createHash('sha256').update(data).digest('hex')}
function stable(x){if(Array.isArray(x))return x.map(stable);if(x&&typeof x==='object'){return Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]));}return x;}
function audit(raw){if(typeof raw!=='string'||Buffer.byteLength(raw)>10*1024*1024)throw Error('INVALID_SIZE');
 if(digest(readFileSync(__dirname+'/logic.js'))!==SOURCE_PIN)throw Error('BASELINE_LOGIC_SHA_MISMATCH');
 const textDigest=digest(raw);let payload;
 try{payload=JSON.parse(raw);}catch{throw Error('INVALID_JSON')}
 if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_PAYLOAD');
 if(!['CRAFT-MOBILE-CAPTURE/1.0-TEST','CRAFT-MOBILE-CAPTURE/1.1-TEST'].includes(payload.schema))throw Error('SCHEMA_NOT_SUPPORTED');
 if(payload.official_writes!==0)throw Error('OFFICIAL_WRITES_CLAIM_CONFLICT');
 if(!Array.isArray(payload.records)||payload.records.length>10000)throw Error('INVALID_RECORDS');
 const declaredOrigin=payload.data_origin==='SELF_DECLARED_OFFLINE_NO_NOTION_SYNC';
 const problems=[],seen=new Set(),crossLot=new Map(),evaluated=[];
 if(!declaredOrigin)problems.push({index:null,reason:'DATA_ORIGIN_CHANGED_OR_MISSING'});
 for(let i=0;i<payload.records.length;i++){
  const entry=payload.records[i];if(!entry||typeof entry!=='object'||Array.isArray(entry)||!entry.record){problems.push({index:i,reason:'MALFORMED_ENTRY'});continue;}
  let ev;
  try{ev=QA.evaluate(entry.record)}catch(e){problems.push({index:i,reason:'RECORD_INVALID_'+e.message});continue;}
  const key=entry.record.type+'|'+entry.record.lot_id+'|'+entry.record.sample_id;
  if(seen.has(key))problems.push({index:i,reason:'DUPLICATE_SAMPLE'});
  seen.add(key);
  const physicalKey=entry.record.type+'|'+entry.record.sample_id;
  if(crossLot.has(physicalKey)&&crossLot.get(physicalKey)!==entry.record.lot_id)problems.push({index:i,reason:'SAMPLE_ID_REUSED_CROSS_LOTS_INDEPENDENCE_UNKNOWN'});
  else crossLot.set(physicalKey,entry.record.lot_id);
  if(JSON.stringify(stable(entry.evaluation))!==JSON.stringify(stable(ev)))problems.push({index:i,reason:'EVALUATION_MISMATCH'});
  if(ev.physical_verified!==false||ev.rc5!==false||ev.production_authorized!==false)problems.push({index:i,reason:'UNEXPECTED_AUTHORITY'});
  evaluated.push({record:entry.record,evaluation_recomputed:ev});
 }
 let summary;
 try{summary=QA.groupSummary(evaluated.map(x=>x.record))}catch(e){problems.push({index:null,reason:'SUMMARY_INVALID_'+e.message});summary={groups:{}};}
 if(!payload.summary)problems.push({index:null,reason:'SUMMARY_MISSING'});
 else if(JSON.stringify(stable(payload.summary))!==JSON.stringify(stable(summary)))problems.push({index:null,reason:'SUMMARY_MISMATCH'});
 const report={schema:'CRAFT-MOBILE-REVIEW/1.0-TEST',input_sha256:textDigest,input_schema:payload.schema,logic_sha256:SOURCE_PIN,record_count:payload.records.length,recomputed_count:evaluated.length,issues:problems,summary,review_status:problems.length?'REVIEW_QUARANTINE':'REVIEW_REQUIRED_NO_AUTOCANON',authority:'SELF_DECLARED_NEEDS_INDEPENDENT_WITNESS',physical_verified:false,independence_verified:false,official_writes:0,rc5_created:0,production_authorized:false,notion_write:false,party_write:false,records:evaluated};
 return report;
}
function cli(){if(process.argv.length<3||process.argv.length>4){console.error('Uso: node review_capture.js entrada.json [saida.json]');process.exitCode=2;return}
 let report;try{report=audit(readFileSync(resolve(process.argv[2]),'utf8'));}catch(e){console.error('REVIEW_REJECTED',e.message);process.exitCode=2;return}
 const file=process.argv[3]||resolve(process.argv[2])+'.review.json';writeFileSync(file,JSON.stringify(report,null,2)+'\n');console.log(report.review_status,'records',report.record_count,'issues',report.issues.length,'sha',report.input_sha256,'output',file);if(report.issues.length)process.exitCode=1;
}
module.exports={audit,digest,SOURCE_PIN};if(require.main===module)cli();
