# PSV CRAFT R8 — Histórico, resultado, ponto de retomada

**Operação única:** OP-ARQ-RIN-REC-01; **alvo:** LAB CRAFT existente; **ambiente:** MESTRE-SIDE / TEST; **autoridade de produção:** nenhuma herdada. **Baseline:** `CRAFT_R53_ITEM_RESOURCE_TEST_20261021.zip`, SHA de fonte `190b53888c4f5c0276ad4ba6dcf27572c6d9e53273c318ed543b8faaed07defc`. **R7:** `CRAFT_R7_CUSTODIA_INTEGRADA_VERIFIED_20261021.zip`, SHA `9655154c60a9376ddaf4f39d912c2b4ef5069cb59e86e076e55db51212296dc7`.

## ANTES
R53: dois projetos TEST e 99 testes JS; validador conferia presença do UUID no próprio `resources.json`, mas a construção `Map` permitia apagar silenciosamente duplicatas e não testava identidade vinculada (nome, família, URL e efeito apenas cadastral). Um índice copiado/editado podia induzir uma fonte incorreta sem ser detectado. A verificação de materialidade e a autoridade de receita permaneciam HOLD.

## DEPOIS — PATCH R8
No MESMO `src/validate.js`: adicionado gate do índice local, detecção de duplicatas, URLs e identidades, pin de snapshot revalidado nas cinco fichas Notion. Uma nova pendência `LIVE_SOURCE_RECHECK` evita que o pacote offline seja citado como fonte atual sem confirmação no sistema canônico. `build_mobile.py` foi reutilizado para regenerar a mesma interface HTML. Testes novos isolados em `tests/test_source_identity_r8.js`. Fontes e procedimentos R53 originais mantidos; os dois projetos ainda não são fabricáveis.

## RESULTADOS, DENOMINADORES, LIMITES
- Baseline R53: 34 validação + 11 substituição + 15 smoke mobile JS + 23 ficha/grafo + 16 economia = **99/99**, reexecutados na cópia R8.
- R8: **21/21** casos de fonte válida, forjada, alias, origem, duplicata, URL, rank e metadados.
- Total local: **120/120 asserções digitais**. O ensaio de navegador real Chromium foi **tentado**, mas não iniciado por binário ausente; NÃO conta como PASS. Android físico do Mestre NÃO testado.
- Cinco fichas Mestre reabertas no Notion; nomes/UUID e datas comparados; 0 itens PROD, 0 receita RC5, 0 estoques, 0 Party/O Primeiro.
- Triagem de material EXISTING-FIRST (REC-MOD-POC e Poção Pasta Nuvem): apenas precedente de método, nenhum veículo compatível provado. Suporte comum isolante da Sonda continua PENDENTE.

## GOVERNANÇA
PASS proporcional: checagem digital/QA em TEST com manifesto SHA e replay frio quando confirmado. HOLD: P2 magia/óleo/sal, R51 parent, IBX-38 e C19-021 UNKNOWN-EFFECT, F5 RED, 30/30 RC5, R46 prova física, autorização/operador/lease/fencing, H2, P4, estoque e Party.

**FIRST-PENDING:** verificar persistência do R8 em Library e LAB/OP com readback; se documental for resolvido, próximo trabalho funcional é **evidência existente de suporte/veículo e protocolo de ensaio com controles**, nunca criação de fonte por quota, sem reimplementar R48/PA/R46. 
