from playwright.sync_api import sync_playwright
import tempfile,json,pathlib
p=pathlib.Path(__file__).resolve().parent.parent
html=p/'REVISOR_LOCAL_ANDROID_R53_TEST.html'
assert html.exists()
checks=0
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path=pw.chromium.executable_path,args=['--disable-gpu','--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True)
 errs=[]; outbound=[]
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('request',lambda r:outbound.append(r.url) if r.url.startswith('http') else None)
 page.goto(html.as_uri());page.wait_for_load_state('load')
 body=page.locator('body').inner_text()
 assert 'MESTRE-SIDE' in body;checks+=1
 assert body.count('HOLD_TEST_DESIGN')==2;checks+=1
 assert 'LIVE_SOURCE_RECHECK' in body;checks+=1
 assert 'Projetos liberados para fabricação\n0' in body;checks+=1
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1');checks+=1
 assert not errs and not outbound,(errs,outbound);checks+=1
 page.get_by_role('button',name='Validar propostas').click()
 assert page.locator('article.box').count()==2;checks+=1
 with tempfile.TemporaryDirectory() as d:
  d=pathlib.Path(d)
  data=json.loads((p/'data/proposals.json').read_text())
  data['products'][0]['item_rank']='Ouro'  # rank never auto-admit
  evil=d/'alterada.json';evil.write_text(json.dumps(data,ensure_ascii=False))
  page.locator('#upload').set_input_files(str(evil));page.wait_for_timeout(80)
  assert page.get_by_text('RANK_SHORTCUT').count()>=1;checks+=1
  assert page.locator('article.box').first.get_by_text('REJECT').count()>=1;checks+=1
  assert page.locator('article.box').last.get_by_text('HOLD_TEST_DESIGN').count()>=1;checks+=1
  assert not errs and not outbound,(errs,outbound);checks+=1
  data['products'][0]['item_rank']=None
  clean=d/'restaurada.json';clean.write_text(json.dumps(data,ensure_ascii=False))
  page.locator('#upload').set_input_files(str(clean));page.wait_for_timeout(80)
  assert page.locator('article.box').first.get_by_text('HOLD_TEST_DESIGN').count()>=1;checks+=1
  with page.expect_download() as dl:page.get_by_role('button',name='Salvar diagnóstico JSON').click()
  download=dl.value; assert download.suggested_filename=='R53_QA_TEST_RESULT.json';checks+=1
  out=d/'result.json';download.save_as(out)
  payload=json.loads(out.read_text())
  assert payload['status']=='HOLD_TEST_DESIGN' and all(v['verified_production'] is False for v in payload['items']);checks+=1
  assert not errs and not outbound,(errs,outbound);checks+=1
 browser.close()
print(f'PASS {checks}/{checks} R8 Chromium mobile 390x844 TEST; local browser ≠ aparelho Android real')
