# CRAFT R8 — Source Integrity Patch on R53 (MESTRE-SIDE / TEST)

Patch **no validador existente** (`src/validate.js`) e no mesmo revisor Android do R53. Não é motor ou regra nova. O R53 original permanece intocado, recuperável pela Biblioteca Mestre.

## Mudança funcional
- `validateSourceIndex` rejeita UUID malformado, duplicado, alias/título/família trocados, URL de origem divergente, origem sem evidência e suposta atribuição de rank do EFEITO ao recurso.
- Snapshots de nome, família, última edição e resumo funcional das cinco fontes R53 foram confrontados com **leituras diretas Notion MESTRE**, nesta rodada. Esse pin detecta alteração local do índice, **não prova autenticação por credencial, integridade do servidor, autoridade de writer, qualidade dos itens nem permanência futura das fontes**.
- Toda proposta inclui `LIVE_SOURCE_RECHECK` como HOLD de nova utilização. Ambos os projetos permanecem `HOLD_TEST_DESIGN`, sem valor oficial PA/rank/produção ou Party.
- O HTML offline é reconstruído pela própria rotina `build_mobile.py`. Não consome internet e a versão original continua histórica.

## Auditoria de testes
Rodar `node src/run.js` e depois `for f in tests/test_*.js; do node "$f"; done`. Total: **120 asserções declaradas por suíte** (99 R53 originais + 21 testes adicionais R8), em seis suítes Node. O smoke HTML é teste JS/VM, **não um navegador real**. O teste optativo `tests/test_mobile_browser_r8.py` depende de binário Chromium que não está instalado no runtime desta rodada: **NOT RUN / ENVIRONMENT-BLOCKED**, não foi contado como PASS.

## Anti-duplicata e limites
A busca dirigida por `veículo`, `frasco`, `isolante` e precedentes de Poções permitiu localizar REC-MOD-POC-01 e a Poção Pasta Nuvem com Orvalho de Miragem/frascos. Isso não demonstra compatibilidade química/mágica com Capim+Raiz nem fornece um veículo validado. A página Água retornada é grupo de Bestas, não insumo de alquimia. A resina da Acácia Radiante tem papel próprio, e madeira/casca não herdam esse efeito. `data/proposals.json` permanece idêntico ao R53 — **dois projetos continuam propostos, nenhuma BOM fechada**.

Nenhuma mutação no Notion Mestre, Party, O Primeiro, itens, estoque, receitas, R48, PA, F5 ou RL5 é executada pelo código. Papel da saída: diagnóstico offline; não certificar RC5.
