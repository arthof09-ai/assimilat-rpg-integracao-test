# Bancada CRAFT — coleta Android, offline e Mestre-only

**Identificação:** CRAFT-MOBILE-CAPTURE-20261021-001 · OP-ARQ-RIN-REC-01 · CM-000002/WS0001 · TEST.

## Para usar no Android

1. Baixe `CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html` e abra **uma cópia local** pelo navegador que permita arquivos HTML (Chrome ou visualizador local compatível). Não é necessário executar Python, instalar n8n, GitHub, API ou pagar por hospedagem.
2. Escolha **B30-01 Tábua Lamelar**, **B30-03 Par de Espaçadores de Mica** ou **B30-02 Cordão de Casca Boreal**.
3. Preencha amostra e lote, operador, instrumento, calibração, incerteza e medições realmente observadas, caso existam. Não substitua números ausentes por valores simulados.
4. **Pré-validar** mostra um parecer TEST. **Adicionar** registra a amostra **apenas na memória da aba**. Consulte a seção de amostras e exporte JSON/CSV antes de fechar; **nenhuma recuperação automática é possível**.
5. O JSON exportado preserva os dados brutos e recalcula o parecer; requer verificação por técnico/Comestre independente e autoridade correspondente. Nunca encaminhar este pacote Mestre-only à Party nem a O Primeiro.

> Se seu Android não abrir HTML local com JavaScript, guarde o arquivo para abertura em um navegador/gerenciador compatível. Não envie medições ou informações Mestre-only a sites de terceiros para contornar esse limite.

## Novidade e não duplicação

O CRAFT já possui QMC-01/02 e metrologia Python R45/R46. Esta entrega **não é** motor de fabricação ou novo RC5: é apenas uma interface local de campo, inclusive exportação, feita para o celular do Mestre e derivada dos limiares **PROPOSTOS** em R50/B30-01 e B30-03. O HTML contém integralmente sua lógica, não requer rede, banco de dados, Notion nem outras bibliotecas. O código de teste é incluído somente para auditores.

## Tolerâncias propostas do pré-RC5 (NÃO canonizadas)

B30-01: comprimento 119–121 mm; largura 79–81 mm; espessura 7,5–8,5 mm; planicidade 0–1 mm; malha 9–11 mm; sulco 0–0,5 mm; 3 ou mais repetições; sem trincas, delaminação, quinas cortantes ou detecção de magia.

B30-03: exatamente duas peças, comprimento de cada 49–51 mm, largura de cada 19–21 mm, diferença de espessura até 0,1 mm, sem trincas, lamelas soltas ou detecção de magia; encaixe seco aprovado.

B30-02: proposta de 2 m de fibra vegetal para alvo 1 m de cordão (95–105 cm). O requisito de suportar carga de serviço **não possui limiar homologado**. Carga de ruptura e alongamento são observações, não critérios de aprovação mecânica. Não aplicar poder mágico da origem.

A interface aplica incerteza inserida pelo operador: se o intervalo medido cruzar um limiar, retorna indeterminação. Para diferença de espessuras, usa o limite conservador de ±2u nas duas leituras; no comprimento B30-02 converte corretamente incerteza em mm para cm.

## Validação e uso dos estados

- `WITHIN_PROPOSED_TOLERANCE`: somente conformidade às tolerâncias de desenho **se** as medidas declaradas forem corretas. **Não** significa confirmação independente.
- `OUTSIDE_PROPOSED_TOLERANCE`: valor fora dos limites de desenho ou inspeção declarada reprovada.
- `INDETERMINATE_UNCERTAINTY`: intervalo de incerteza cruza tolerância ou incerteza ausente.
- `NO_HOMOLOGATED_LOAD_THRESHOLD`: B30-02 possui geometria preliminar avaliável, mas resistência de serviço ainda sem especificação oficial; não aprovar produto.
- `INCOMPLETE_OR_INVALID`: faltantes, tipos/números inválidos ou evidências de registro incompletas.

Todos os JSONs levam `physical_verified=false`, `rc5=false`, `production_authorized=false`, `official_writes=0` e origem `SELF_DECLARED_OFFLINE_NO_NOTION_SYNC` independentemente das caixas marcadas.

## Fontes e autoridade

- Ardósia de Geada Lamelar Mestre: https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2
- Mica de Bruma Boreal Mestre: https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84
- Fibra de Casca Boreal Mestre: https://app.notion.com/p/3f3c2b324ede815ab04ace5bd1074e79
- `R50_PLAN_B30-01.json`, `B30-03_PRONTIDAO_RC5.json` e dossiê PRE-Q2 B30-02 em AUD-CRAFT-F5-REMAP-01 recuperados da Biblioteca Mestre e lidos; não incorporados em novo banco de verdade.
- REC-MOD-EQA-01, PR-ITEM-02, AUD-CRAFT-F5-REMAP-01, R45/R46 preservados.

**GATES atuais:** F5 P0 RED; C19-021 UNKNOWN; REC-LIB R51 sem destino físico verificado; zero escrita em Party, O Primeiro, estoque, PA, R48, páginas de fontes ou fichas. Este arquivo HTML NÃO concede writer, lease, epoch, ACK, assinatura metrológica ou GREEN.

## Verificações offline de engenharia

Em um computador com Node.js 22 e Python Playwright+Chromium, execute `node tests.js` e `python test_browser.py` na pasta extraída. O primeiro valida o cálculo, as fontes e as negativas de autoridade; o segundo percorre a tela Android 390px, duas amostras, rejeição de duplicata, export JSON/CSV e import conflitante. As imagens de demonstração e exportação nos testes são **dados sintéticos**.

## Versão 1.1 e compatibilidade

A versão 1.1 acrescenta B30-02, sem alterar as tolerâncias recuperadas de B30-01/03. A versão 1.0 foi preservada no pacote anterior; JSONs 1.0 podem ser importados no aplicativo 1.1, **sempre reavaliados localmente**, sem confiar no campo `evaluation` do arquivo. Não é migração de página Notion nem de REC-ID.

### Correção de segurança da interface (mesma v1.1, revisão final)

As inspeções de trincas, delaminação, lamelas, quinas, encaixe e sinais mágicos **não têm resultado favorável pré-selecionado**. Cada uma apresenta `Não observado` até o operador marcar expressamente `Sim` ou `Não`. Se permanecer não observada, a triagem é `INCOMPLETE_OR_INVALID`, nunca aprovação automática. O formato JSON 1.1 e o código de avaliação reutilizado pelo revisor não mudaram; apenas o preenchimento visual foi reforçado e testado em Chromium.
