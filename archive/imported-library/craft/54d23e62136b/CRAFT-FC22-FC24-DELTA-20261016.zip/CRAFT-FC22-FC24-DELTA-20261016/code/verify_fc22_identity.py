#!/usr/bin/env python3
"""FC22 focused, read-only verifier. Not an engine or an RPG material assay.

Usage: python code/verify_fc22_identity.py --baseline /path/to/CRAFT-FC19-FC21-DELTA-20261016.zip
Prints independent checks; exits nonzero when evidence disagrees with pinned identities.
"""
import argparse
import hashlib
import json
import zipfile
from fractions import Fraction

PREFIX = 'CRAFT-FC19-FC21-DELTA-20261016/'
FELD = '3f3c2b32-4ede-81a2-a590-c53273f9e6e5'
CLAY = '3f3c2b32-4ede-81b8-b187-f217b20c6bdb'
URL_CLAY = 'https://app.notion.com/p/3f3c2b324ede81b8b187f217b20c6bdb'


def verify(path):
    checks = []
    def chk(name, statement):
        checks.append({'check':name, 'passed':bool(statement)})

    with zipfile.ZipFile(path) as z:
        ztest=z.testzip()
        chk('historical_zip_crc', ztest is None)
        manifest=json.loads(z.read(PREFIX+'MANIFEST_SHA256.json'))['entries']
        for relative, spec in manifest.items():
            raw=z.read(PREFIX+relative)
            chk('manifest:'+relative, len(raw)==spec['bytes'] and hashlib.sha256(raw).hexdigest()==spec['sha256'])
        original=json.loads(z.read(PREFIX+'contracts/FC20_B30_16_PREMISTURA_ADMISSAO_CONDICIONAL.json'))
        receipt=json.loads(z.read(PREFIX+'outputs/FC20_B30_16_new_sandbox_receipt.json'))
        legacy=json.loads(z.read(PREFIX+'outputs/FC20_reconciliacao_R44_somente_leitura.json'))

    bom=original['BOM']
    chk('2_distinct_dry_sources',len(bom)==2 and bom[0]['page_url'].endswith(FELD.replace('-','')) and bom[1]['page_url']==URL_CLAY and bom[0]['quantity']==200 and bom[1]['quantity']==800 and bom[0]['unit']=='g seco' and bom[1]['unit']=='g seco')
    chk('original_name_conflict_detected',bom[1]['source']=='Argila de Geleira')
    cases=receipt['cases']
    chk('old_attempt_statuses_preserved',len(cases)==2 and cases[0]['status']=='EXPERIMENTAL_QA_PASS' and cases[1]['status']=='REJECTED_QUALITY')
    for case in cases:
        got={c['source_page_id']: c['quantity'] for c in case['consumed']}
        chk('source_uuid:'+case['attempt_id'],got=={FELD:200,CLAY:800})
        chk('no_official_item:'+case['attempt_id'],case.get('official_materialization') is False and case.get('official_rec_id') is None)
    chk('success_test_970g',cases[0]['products'][0]['qa_fixture']['output_mass_g']==970)
    side=receipt['external_mass_sidecar']
    chk('sidecar_1000_eq_970_plus_30',side['synthetic_in_g']==1000 and side['synthetic_out_g']==970 and side['synthetic_residue_g']==30 and side['balance_g']==0)
    chk('sidecar_not_native_mass_ledger',side['status'].startswith('AUXILIARY_') and 'does not ledger final grams' in ' '.join(receipt['limits']))
    chk('idempotent_replay_claim_in_historical_receipt',receipt['idempotent_replay']['idempotent'] is True)
    chk('R44_other_recipe_caveat_preserved',legacy['native_gap']['pass'].startswith('500g debitados'))

    # New causal finding: lack of component-specific scrap disallows claiming 20/80 FINAL composition.
    # Under closed, dry, binary mixture and nonnegative 30 g residue, retained feldspar: [170,200].
    low = Fraction(200-30,970)
    high = Fraction(200,970)
    chk('final_fraction_not_uniquely_20pct',low < Fraction(1,5) < high)
    chk('final_fraction_bounds_exact',low == Fraction(17,97) and high == Fraction(20,97))
    # Mutation probes: altered source and unsupported constant final ratio must not validate.
    bad_component={FELD:200,'11111111-1111-1111-1111-111111111111':800}
    chk('reject_forged_source_uuid',bad_component!={FELD:200,CLAY:800})
    composition_measured = any('feldspar_retained' in x for x in receipt['cases'][0].get('products',[])) or 'feldspar_residue_g' in side
    chk('reject_unmeasured_final_composition',not composition_measured)
    return {'passed':sum(x['passed'] for x in checks),'total':len(checks),'all_pass':all(x['passed'] for x in checks),'checks':checks,'new_mathematical_inference':{'conditional_hypothesis':'dry binary mixture; no other mass flow and exactly 30g dry scrap','feldspar_mass_in_final_kg':[0.170,0.200],'feldspar_mass_fraction_min':str(low),'feldspar_mass_fraction_max':str(high),'percent_min':round(float(low)*100,4),'percent_max':round(float(high)*100,4),'cannot_claim_final_20_80':True,'not_material_observation':True}}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--baseline',required=True)
    args=ap.parse_args()
    result=verify(args.baseline)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['all_pass'] else 1)
