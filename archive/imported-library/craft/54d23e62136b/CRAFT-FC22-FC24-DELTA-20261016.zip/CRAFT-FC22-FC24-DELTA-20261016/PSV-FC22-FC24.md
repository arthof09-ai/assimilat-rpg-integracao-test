# PSV — CM-000002 / WS0001 / OP-ARQ-RIN-REC-01 / FC22–FC24

**AS-OF:** 16/10/2026 | **Ambiente:** MESTRE-SIDE | **BASELINE:** R01–R51, BACKFILL-30, FC01–FC21 preservados.

**LAST-VERIFIED-UNIT:** ZIP FC19–FC21 `6c15901fb52222a18dc1209c70ca9c2c3b4cc0e216587140a09381322cba8cc1`; manifesto e recibos reabertos em leitura; verificador focal 31/31. FC20 R44 contém dois eventos TEST (PASS e QUALITY REJECT), HEAD preservado `022fdea0c61b1ab8400f2bfdb420d9ff51a37a706aa063484eb19074f00ed170`, sem qualquer nova execução.

**FIRST-PENDING:** B30-16 — identificar consumidor/procedimento cerâmico competente para a pré-mistura não queimada e o método de QA de homogeneidade. Nome de argila e identidade física B30-04 não são mais frentes repetíveis.

## FC22 — Decisões de identidade

**B30-04 → MERGE de engenharia com a especificação do recurso PS, sem novo REC-ID.** A Coordenação informou, após reabertura, que `CRAFT-F5-R01-OUT-04` já contém lavagem, peneiramento, secagem e classificação da Areia de Brecha Granulada. O FC10 entregou uma fração granulada TEST de 250g; não fabricou um leito estruturado. O intervalo 0,2–1,0mm ainda é PROPOSTO. Beneficiamento contemplado na origem não justifica por si só receita duplicada; qualquer leito funcional novo exigiria BOM de suporte e transformação adicional. Não houve merge físico no Notion.

**B30-16 → ERRATA DE NOME, sem alterar os recibos.** O contrato FC20 escreveu `Argila de Geleira`, mas sua URL e ambos os recibos apontam ao UUID `3f3c2b32-4ede-81b8-b187-f217b20c6bdb`, identificado pela Coordenação como **Argila de Raiz Fria**, CRN `CRAFT-F5-R01-OUT-03`. O outro insumo permanece **Feldspato de Fenda Alpina**, CRN `CRAFT-F5-R02-MIN-01`. `Argila de Geleira` NÃO é alias canônico provado nem recurso novo. A retificação está no delta aditivo; artefatos FC20 intocados.

## FC23 — Engenharia terminal B30-16

- **RC2 — PASS documental/proposto:** 200g secos de feldspato + 800g secos de Argila de Raiz Fria, UUIDs corretos, materiais PS existentes. As massas não representam estoque nem ocorrência do RPG.
- **RC3 — PASS em projeto somente para insumos já secos:** identificar fonte→verificar secura→pesar→misturar→segregar resíduos→QA→conservar. Se os materiais chegarem úmidos, secagem com água/energia/tempo e perdas exige subárvore adicional. Não lançar massa úmida como seca.
- **RC4 — HOLD:** método competente de homogeneidade/QA, duração, ferramentas efetivas, operador/conhecimento, massa final e resíduos por constituinte, rendimento/qualidade reais e condições de conservação não certificados. O TEST R44 registrou consumo 200+800g, uma unidade aprovada com **970g sintéticos** e **30g de resíduos apenas em sidecar**, outro lote reprovado. R44 não mantém frações de massa em seu ledger nativo.
- **RC5 — HOLD técnico:** o produto é uma **pré-mistura seca intermediária, não uma cerâmica queimada**. A Coordenação identificou uso geral da argila em cerâmica e papel proposto de fundente do feldspato; um consumidor/necessidade específica dessa pré-mistura, anti-duplicata, conhecimento, qualidade e economia seguem sem prova suficiente. Não exigir ensaio físico terrestre universal e não inventar poderes, temperaturas, salários ou disponibilidade.

**Resultado técnico novo verificável:** `20/80` descreve somente a **alimentação**. Se (e apenas se) o lote TEST for uma mistura binária seca fechada e os 30g de resíduos vierem desses dois insumos, os 970g finais conteriam entre **170 e 200g de feldspato**, isto é, entre **17,5258% e 20,6186%**, pois a composição dos resíduos não foi identificada. É incorreto publicar `20/80 final` como medição ou consequência garantida. No QA reprovado o scrap também está em unidades, não em gramas identificadas. Esta descoberta não altera os recibos históricos.

**Economia:** `CTE = CI+CP+CF+CT+CE+CK+CL+CA+CC`, com kit, conhecimento, custo de fabricação e preço separados. Sem preços da mesma época/mercado, tempo, perdas e unidades aprovadas qualificadas, não há MED nem CTE unitário canônico. Quando zero unidades são aprovadas, custo por unidade é INDEFINIDO, não zero.

## FC24 — Carteira e admissibilidade

| Candidata | Decisão FC24 | Primeiro requisito decisivo |
|---|---|---|
| B30-04 | MERGE conceitual à especificação do recurso; sem REC-ID independente | Novo leito funcional exigiria transformação e BOM distintas |
| **B30-16** | **HOLD RC4/RC5; principal candidata intermediária** | Consumidor comprovado + método competente de mistura/QA; depois tempo, operador e CTE |
| B30-13 | HOLD | Volume final, benefício/segurança de substrato, pH/umidade e horticultura competentes |
| B30-17 | HOLD | Aplicação de abrasivo fino, moagem/qualificação, conhecimento e economia |

**RC5 técnico aprovado:** 0. **REC-IDs físicos RC5:** 0/30. **Recursos PS cobertos oficialmente:** 0/30. **Produtos oficiais:** 0. **BASELINE histórica:** 30/30 PS, 23 PRE-Q2 e 7 PRE-Q1. **Novos testes de integridade/identidade nesta rodada:** 31/31 PASS; **novos lotes R44:** 0. A quantidade de testes não aumenta os contadores de receita.

**CONFLICTS:** nome argila divergente do UUID (corrigido aditivamente); indicação 20/80 final injustificada; sidecar de resíduos fora do ledger R44; origem Areia de Brecha já prevê beneficiamento.

**UNKNOWN-EFFECT:** C19-021 e checkpoint órfão FC04 preservados. **AUTHORITY/WRITER:** F5 RED, IBX-38/IBX-78 NOVA conforme leitura comunicada pela Coordenação, exclusividade técnica não provada, writer não concedido. Notion nesta instância: `link_id must identify an eligible linked account`; nenhuma escrita canônica, Party ou O Primeiro. O write-set em `FC24_portfolio_and_disabled_writeset.json` está DESABILITADO.

**NAC-PASS proporcional:** PASS apenas para autenticação local, reconciliação de identidade e limitações matemáticas; HOLD para RC4/RC5 técnico, writer, publicação e fabricação no RPG. **NO-REPEAT:** nenhum replay R44 de rotina, nenhum motor ou checkpoint original alterado.

**TARGET-REMAINDER / NEXT-5:** (1) localizar consumo competente da pré-mistura seca em processo cerâmico; (2) obter procedimento de secagem/homogeneidade e aceitação QA; (3) reconciliar tempo, equipamento e especialista; (4) fechar UTE/CTE no contexto autorizado; (5) Coordenação resolver IBX-38/78/C19 para eventual publicação após RC5 técnico. Sem consumidor específico, classificar B30-16 como preparo interno de outra fórmula e prosseguir pela B30-17 — sem REC-ID artificial.

**CHECKPOINT DE SUCESSÃO:** `outputs/FC23_B30_16_terminal_gate.json`, campo `minimal_decisive_frontier`, seguido de `outputs/FC24_portfolio_and_disabled_writeset.json`. Persistência Notion PENDENTE; pacote local somente.
