# FC22–FC24 — Recuperação, não substituição

Operação original `OP-ARQ-RIN-REC-01`, CM-000002/WS0001, ambiente MESTRE-SIDE.

## Material necessário

- ZIP preservado `CRAFT-FC19-FC21-DELTA-20261016.zip`, SHA-256 `6c15901fb52222a18dc1209c70ca9c2c3b4cc0e216587140a09381322cba8cc1`.
- Histórico anterior FC01–FC18 permanece em seus respectivos pacotes; não está duplicado aqui.

## Verificar

```bash
python code/verify_fc22_identity.py --baseline /caminho/CRAFT-FC19-FC21-DELTA-20261016.zip
```

O script lê o ZIP original, recalcula tamanho e SHA-256 de cada arquivo do manifesto e verifica os UUIDs reais nos recibos, sem salvar nem alterar fontes. A saída é JSON. O resultado desta sessão está em `outputs/FC22_read_only_verification.json` (**31/31 PASS**). Além da verificação de identidade, inclui casos adversariais de UUID inválido e do erro de alegar 20/80 finais sem discriminar perdas. São testes da análise, não novos eventos R44 nem provas físicas.

## Arquivos

- `outputs/FC22_material_identity.json` — B30-04 MERGE de engenharia e B30-16 errata aditiva com proveniência.
- `outputs/FC23_B30_16_terminal_gate.json` — BOM, RC2–RC5, ramo seco/úmido, saldo e economia, produto intermediário.
- `outputs/FC24_portfolio_and_disabled_writeset.json` — estado das quatro candidatas, bloqueios e write-set totalmente desabilitado.
- `PSV-FC22-FC24.md` — PSV e sucessão.
- `MANIFEST_SHA256.json` — hashes deste delta, não dos pacotes anteriores.

## Limites de proveniência

- **VERIFICADO LOCALMENTE:** ZIP, manifesto, contrato FC20, recibos FC20 e consistências matemáticas.
- **TRANSMITIDO PELA COORDENAÇÃO após leitura canônica:** nomes CRN, usos e descrição do beneficiamento da Areia de Brecha, Argila de Raiz Fria e Feldspato. O Executor não reabriu Notion por erro de `link_id`; NÃO confundir com leitura física própria.
- **TEST:** 970g de produto e 30g de resíduos; sem medição de material RPG. RC4/RC5 não homologados.
- **PENDENTE:** consumidor específico, QA de mistura, ofício, tempo, economia, linhagem oficial, C19 e escrituração.

**Imutabilidade:** nenhum recibo, engine R44–R48, rascunho histórico, checkpoint órfão ou arquivo FC01–FC21 foi reescrito. Não criar novo REC-ID, Party ou O Primeiro.
