import unittest
from pathlib import Path
from qmc05_delta02 import augment_power,extend_qualification

class TestAttributeShorthand(unittest.TestCase):
    def f(self,text,negated=False):
        return augment_power({'literal':text,'magnitudes':[],'negated_benefit':negated,'documented_pa_mentions':[]})
    def test_des(self):
        r=self.f('Agilidade Estelar: +8 Des')
        self.assertEqual(r['magnitudes'][0]['property'],'DESTREZA')
        self.assertEqual(r['magnitudes'][0]['value'],8)
    def test_other_attributes(self):
        r=self.f('Bônus: +1 For, -2 Con, +3 Int, +4 Sab, +5 Car')
        self.assertEqual([(x['property'],x['value']) for x in r['magnitudes']], [('FORCA',1),('CONSTITUICAO',-2),('INTELIGENCIA',3),('SABEDORIA',4),('CARISMA',5)])
    def test_deslocamento_not_des(self):
        self.assertEqual(self.f('+8 Deslocamento')['magnitudes'],[])
    def test_unsigned_not_bonus(self):
        self.assertEqual(self.f('8 Des sem sinal')['magnitudes'],[])
    def test_negated_not_bonus(self):
        self.assertEqual(self.f('Não confere +8 Des',True)['magnitudes'],[])
    def test_negative_garante_hidden(self):
        self.assertEqual(self.f('A peça não garante +8 DES')['magnitudes'],[])
    def test_sem_bonus(self):
        self.assertEqual(self.f('Sem bônus +4 CAR')['magnitudes'],[])
    def test_zero_pa_not_invented(self):
        x=self.f('Defesa Astral: 10 RDM')
        self.assertEqual(x['documented_pa_mentions'],[])
        self.assertNotIn('PA',x['literal'])
    def test_exact_evidence_spans(self):
        s='Poder: + 8 DES e +2 INT';a=self.f(s)
        self.assertEqual(len(a['magnitudes']),2)
        self.assertTrue(all(x['evidence'] in s for x in a['magnitudes']))
    def test_preexisting_magnitude_untouched(self):
        x=augment_power({'literal':'Teste: +2 CA +8 Des','magnitudes':[{'property':'CA','value':2,'evidence':'+2 CA'}],'negated_benefit':False})
        self.assertEqual(len(x['magnitudes']),2)
    def test_real_holdout_rdm_and_des(self):
        root=Path(__file__).resolve().parent.parent / 'replay' / 'CRAFT-QMC04' / 'QMC-05-DELTA' / 'readbacks' / 'vestes_guardiao_cosmo_holdout.txt'
        result=extend_qualification(root.read_text().rstrip('\n'),'https://app.notion.com/p/3edc2b324ede816d9f36dc6bf73d485b')
        self.assertEqual(result['state'],'QMC05_EXTENSION_TEST')
        self.assertEqual(result['named_powers_in_source'],2)
        self.assertEqual(result['abbreviation_normalizations_count'],1)
        effects=result['all_named_power_effects']
        self.assertIn(('DESTREZA',8),[(m['property'],m['value']) for m in effects[0]['magnitudes']])
        self.assertIn(('RESISTENCIA_RDM',10),[(m['property'],m['value']) for m in effects[1]['magnitudes']])
        self.assertEqual(result['pa']['return_official_cost'],None)
        self.assertEqual(result['production'],'HOLD')

if __name__=='__main__':unittest.main()
