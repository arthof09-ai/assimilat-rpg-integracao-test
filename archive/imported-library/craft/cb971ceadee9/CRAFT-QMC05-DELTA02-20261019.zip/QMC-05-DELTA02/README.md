# CRAFT / QMC-05 / DELTA-02 — Reconhecimento genérico de atributos abreviados

**MESTRE-SIDE.** Extensão de **OP-ARQ-RIN-REC-01**. Não cria operação, motor de PA, receitas, BOM ou itens. Produção HOLD / F5 RED / C19-021 UNKNOWN-EFFECT.

## Base original, imutável

`BASELINE-QMC05-DELTA01.zip` é cópia de `CRAFT-QMC05-DELTA01-20261018.zip` original verificado com SHA-256 `e41fb3ca05dc15be244a6c9d301e20ac5aa961f78e39cf7a43bfe8862eee8de1`. Dentro dele está `BASELINE-QMC05-ORIGINAL-INTEGRAL.zip`, SHA `f2471657eed68b7349518d0a7d902004bd6969e1add7fc0b29741957675a52ff`. Não edite esses ZIPs.

**NOVO:** `QMC-05-DELTA02/qmc05_delta02.py` acrescenta normalizações semânticas locais `+8 Des` → `DESTREZA +8`, com a frase literal preservada. Abreviações de FOR/DES/CON/INT/SAB/CAR só são interpretadas quando há sinal e palavra completa como token. Negações explícitas fecham o gate de benefício positivo. Não deduz classe, preço, PA, reação, duração nem aplicação oficial.

## Recuperação em ambiente limpo

```bash
python replay_delta02.py
```

Requer Python 3.11+ padrão, sem bibliotecas externas para teste. Reexecuta 37 + 40 + 50 + 47 + 28 + 11 = **213/213** testes CRAFT internos (não inclui os cinco R05 externos). Para 218/218 incluindo cinco testes reais R05, usar o pacote original `PA_UNIVERSAL_R05_TEST_20261017.zip` com SHA `6f69fd1ef197851e128c2fc7becbad1f2a14a1438e7bf9ac71742b835f99078e` e a instrução `QMC-05/README.md`, sem modificar código do fornecedor. Nunca contar R05 em nova sessão sem executar o arquivo REAL.

## Holdout documental novo

Consulta ao Notion Mestre em 19/10/2026: `Vestes Guardião Cosmo`, URL `https://app.notion.com/p/3edc2b324ede816d9f36dc6bf73d485b`, fonte apresentada pelo conector como **as-of 2026-10-03T13:20:59.381Z**. Nesta transferência o texto foi recomposto manualmente do retorno e NÃO recebeu assinatura de origem independente. **Não somar ao corpus qualificado histórico de 24 UUIDs como fonte autenticada.**

O analisador antigo identificava dois poderes, mas não tipava `+8 Des`. O delta passa a extrair **Destreza +8 documentada** em Agilidade Estelar, e preserva **10 RDM** em Defesa Astral como resistência específica. Modalidade, duração, custo PA e uso oficial permanecem desconhecidos. A imagem continua sem bytes; uma URL assinada não vale como inspeção. Efeito de velocidade é qualitativo e não recebe multiplicador inventado.

## Conflito/dependência PA

Fonte existente do LAB CRAFT em Notion, `PA-R27-CRAFT-INTEROP-20261019-001`, relata ponte de fornecedor R27 baseada no R26 real, contrato `PA-CRAFT-QMC05-COMPAT-R27/1.0.0-TEST`, porém o ZIP executável R27 não pôde ser materializado nesta instância (arquivo de Projeto sem rota autorizada de bytes). Não criar substituto de motor nem afirmar que o entrypoint QMC-05 importa `consultar_ficha_craft()` com êxito. A QMC-05 antiga pode chamar R05 de modo TEST, mas não estava integrada nativamente ao fornecedor R27. Interface nativa R27 permanece HOLD até recuperar código original, verificar hash e executar canário.

## Gates

- Nova função demonstrada e 11 testes: PASS local TEST.
- Regressões e manifesto base sem adulteração: executar `replay_delta02.py`.
- Readback textual qualificado com âncora Notion independente: HOLD, apesar do parecer experimental.
- Bytes de imagem: 0; inspeção visual: 0.
- PA R27 nativo: HOLD; homologação PA, NAC-NORM, produção, F5, RC5: HOLD.
- Notion Party, O Primeiro, fichas Mestre oficiais e REC-LIB: ZERO ESCRITA.
