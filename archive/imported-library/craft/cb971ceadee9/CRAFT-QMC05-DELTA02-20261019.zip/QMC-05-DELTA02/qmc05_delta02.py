#!/usr/bin/env python3
"""CRAFT QMC-05 / DELTA02. Reconhecimento genérico de abreviações de atributo.

Apenas normalização de frase literal; NÃO é regra de dano, PA ou equipagem.
Reutiliza o código autenticado QMC-05 + DELTA01, sem reescrever suas fontes.
"""
from __future__ import annotations
import importlib.util, re, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent / 'replay' / 'CRAFT-QMC04' / 'QMC-05-DELTA' / 'qmc05_delta.py'


def _original_module():
    if not BASE.is_file():
        raise FileNotFoundError('BASELINE_QMC05_DELTA01_AUSENTE')
    spec = importlib.util.spec_from_file_location('craft_qmc05_original_delta01', BASE)
    if not spec or not spec.loader:
        raise RuntimeError('IMPORT_ORIGINAL_INDISPONIVEL')
    parent = str(BASE.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def augment_power(power: dict) -> dict:
    """Normaliza +N DES/CON/INT etc somente quando explicitamente escritos.

    Uma abreviação normalizada permanece rastreável ao texto e não valida efeitos
    contrários, magnitude isolada sem sinal, ou palavras como 'deslocamento'.
    """
    result = {**power, 'magnitudes': [dict(m) for m in power.get('magnitudes', [])]}
    result['abbreviation_normalizations'] = []
    # Falha fechada: negações que a versão anterior ainda não reconhecia.
    # Essa salvaguarda pode gerar falso negativo; é preferível a atribuir bônus
    # positivo a uma frase explicitamente negativa.
    hidden_negation = bool(re.search(r'\b(?:não|nunca)\s+(?:(?:\w+)\s+){0,2}(?:concede|confere|fornece|causa|aumenta|adiciona|dá|da|garante|atribui)\b|\bsem\s+(?:b[oô]nus|aumento|ganho)\b', result['literal'], re.I))
    if result.get('negated_benefit') or hidden_negation:
        result['abbreviation_normalization_blocked'] = 'NEGACAO_LITERAL'
        return result
    literal = result['literal']
    names = {'FOR': 'FORCA', 'DES': 'DESTREZA', 'CON': 'CONSTITUICAO',
             'INT': 'INTELIGENCIA', 'SAB': 'SABEDORIA', 'CAR': 'CARISMA'}
    # Anchor strict to standalone abbreviation with explicit signed magnitude.
    regex = r'(?<!\w)([+\-]\s*\d+)\s*(?:de\s+)?(FOR|DES|CON|INT|SAB|CAR)\b(?!\w)'
    prior = {(m.get('property'),m.get('evidence')) for m in result['magnitudes']}
    for m in re.finditer(regex, literal, flags=re.I):
        prop = names[m.group(2).upper()]
        span = m.group(0)
        if (prop, span) in prior:
            continue
        number = int(m.group(1).replace(' ', ''))
        magnitude = {'property': prop, 'value': number, 'unit': 'pontos',
                     'evidence': span, 'normalization': 'ABREVIACAO_LITERAL',
                     'authority': 'SOMENTE_INTERPRETACAO_DOCUMENTAL'}
        result['magnitudes'].append(magnitude)
        result['abbreviation_normalizations'].append({'abbreviation':m.group(2).upper(),
                                                        'expanded_to':prop,'literal':span})
        prior.add((prop,span))
    return result


def extend_qualification(raw:str,url:str,anchor:dict|None=None)->dict:
    upstream = _original_module().extend_qualification(raw,url,anchor)
    if upstream.get('state') != 'QMC05_EXTENSION_TEST':
        return upstream
    out = dict(upstream)
    out['contract'] = 'QMC-05-DELTA02-TEST'
    out['all_named_power_effects'] = [augment_power(p) for p in upstream['all_named_power_effects']]
    out['abbreviation_normalizations_count'] = sum(len(p['abbreviation_normalizations']) for p in out['all_named_power_effects'])
    out['source_test_only'] = True
    out['no_cost_calculation'] = True
    out['production'] = 'HOLD'
    return out


if __name__ == '__main__':
    import argparse, json
    p=argparse.ArgumentParser()
    p.add_argument('--readback',required=True);p.add_argument('--url',required=True)
    p.add_argument('--anchor');p.add_argument('--out')
    ns=p.parse_args()
    result=extend_qualification(Path(ns.readback).read_text(encoding='utf8').rstrip('\n'),
                                ns.url,json.loads(Path(ns.anchor).read_text()) if ns.anchor else None)
    payload=json.dumps(result,indent=2,ensure_ascii=False)
    if ns.out:Path(ns.out).write_text(payload+'\n',encoding='utf8')
    print(payload)
    if result.get('state')!='QMC05_EXTENSION_TEST':raise SystemExit(2)
