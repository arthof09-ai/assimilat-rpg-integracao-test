#!/usr/bin/env python3
"""Reconstituição segura do pacote QMC-05+DELTA01 e teste do DELTA02."""
from __future__ import annotations
import hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE/'BASELINE-QMC05-DELTA01.zip'
SHA01='e41fb3ca05dc15be244a6c9d301e20ac5aa961f78e39cf7a43bfe8862eee8de1'
SHA05='f2471657eed68b7349518d0a7d902004bd6969e1add7fc0b29741957675a52ff'
sha=lambda d:hashlib.sha256(d).hexdigest()
assert sha(BASE.read_bytes())==SHA01,'BASELINE_DELTA01_DIVERGENTE'
with tempfile.TemporaryDirectory(prefix='craft_qmc05_delta02_') as t:
    root=Path(t)
    with zipfile.ZipFile(BASE) as z:
        assert z.testzip() is None
        nested=z.read('BASELINE-QMC05-ORIGINAL-INTEGRAL.zip')
        assert sha(nested)==SHA05,'QMC05_ORIGINAL_DIVERGENTE'
        z.extractall(root)
    with zipfile.ZipFile(root/'BASELINE-QMC05-ORIGINAL-INTEGRAL.zip') as z:
        assert z.testzip() is None
        z.extractall(root/'replay')
    base=root/'replay'/'CRAFT-QMC04'
    target=base/'QMC-05-DELTA';target.mkdir(exist_ok=True)
    for file in (root/'QMC-05-DELTA').rglob('*'):
        if file.is_file():
            dest=target/file.relative_to(root/'QMC-05-DELTA');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(file.read_bytes())
    # Holdout new in this delta but NOT independently attested at transport.
    witness=HERE/'QMC-05-DELTA02'/'vestes_guardiao_cosmo_holdout.txt'
    (target/'readbacks').mkdir(exist_ok=True)
    (target/'readbacks'/'vestes_guardiao_cosmo_holdout.txt').write_bytes(witness.read_bytes())
    # Check manifests of the authentic QMC05 package.
    m=json.loads((base/'QMC05-MANIFEST-SHA256.json').read_text(encoding='utf-8-sig'))
    mismatches=[]
    for name,entry in m['files'].items():
        p=root/'replay'/name
        if not p.is_file() or len(p.read_bytes())!=entry['size'] or sha(p.read_bytes())!=entry['sha256']:
            mismatches.append(name)
    assert not mismatches, 'BASELINE_128_DIVERGENT:' + str(mismatches)
    expected={'QMC-02/qmc02':('test_*.py',37),'QMC-03':('test_qmc03.py',40),
              'QMC-04':('test_qmc04.py',50),'QMC-05':('test_qmc05.py',47),
              'QMC-05-DELTA':('test_qmc05_delta.py',28)}
    for folder,(pattern,n) in expected.items():
        out=subprocess.run([sys.executable,'-m','unittest','discover','-s',folder,'-p',pattern,'-q'],cwd=base,capture_output=True,text=True)
        assert out.returncode==0 and f'Ran {n} tests' in out.stderr,(folder,out.stderr)
        print(folder,n,'OK')
    # the new module assumes the delta folder is sibling of "replay" under the package root.
    d=root/'QMC-05-DELTA02';d.mkdir()
    for n in ['qmc05_delta02.py','test_qmc05_delta02.py']:
        (d/n).write_bytes((HERE/'QMC-05-DELTA02'/n).read_bytes())
    env=None
    import os
    env=os.environ.copy();env['PYTHONPATH']=str(d)
    out=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(d),'-p','test_qmc05_delta02.py','-q'],cwd=root,env=env,capture_output=True,text=True)
    assert out.returncode==0 and 'Ran 11 tests' in out.stderr, out.stderr
    print('DELTA02',11,'OK')
    print(json.dumps({'qmc05_manifest':len(m['files']),'base_sha256':SHA01,'nested_qmc05_sha256':SHA05,
          'craft_internal':213,'r05_external_not_executed_by_script':5,'prod':'HOLD','new_recipes':0},ensure_ascii=False))
