"""Preflight TEST do caso único CRAFT; não resolve a magia do RPG.

Nenhuma combinação de flags do JSON produz OBSERVED_MAGIC nem RC5. A competência
para adjudicar as consequências pertence ao Mestre e ao fluxo canônico do RPG.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
CASE = "LAB-CRAFT-VIGILIA-BOREAL-20261020-001"
OLD_ORDER = "SBX-R48-ORDER-48322"


def gate(payload: dict) -> dict:
    errors=[]; dependencies=[]
    if payload.get("case_id") != CASE:
        errors.append("WRONG_CASE_OR_DUPLICATE")
    if payload.get("recipe_version") != "1.3 TEST":
        errors.append("RECIPE_VERSION_DRIFT")
    if payload.get("r48_order") == OLD_ORDER or payload.get("replay_old_order"):
        errors.append("OLD_TRANSACTION_REUSE_FORBIDDEN")
    if payload.get("promote_rc5") or payload.get("production_write") or payload.get("party_write"):
        errors.append("PRODUCTION_PARTY_OR_RC5_FORBIDDEN")
    if payload.get("claims_observed_magic") or payload.get("claims_transfer_success"):
        errors.append("UNVERIFIED_MAGIC_CLAIM")
    if payload.get("automatic_observation") or payload.get("magic_success"):
        errors.append("BOOLEAN_IS_NOT_RPG_OBSERVATION")

    h1=payload.get("h1",{})
    decision=h1.get("master_decision")
    if decision not in (None, "YES", "NO"):
        errors.append("INVALID_MASTER_DECISION")
    if decision is None:
        h1_state="H1_DECISION_PENDING"
        dependencies.append("MASTER_H1_FIXATION_RETENTION_DECISION")
    elif not h1.get("master_decision_source"):
        h1_state="H1_DECISION_REFERENCE_MISSING"
        dependencies.append("VERIFY_MASTER_DECISION_FROM_AUTHORIZED_SOURCE")
    elif decision=="NO":
        h1_state="H1_RETAINED_BY_FIXATION_NOT_ASSUMED"
    else:
        h1_state="H1_SCENE_ELIGIBLE_NOT_OBSERVED"
        dependencies.append("AUTHORIZED_RPG_SCENE_OBSERVATION")
    if h1.get("witness_event_id"):
        # Evento apenas informado; exige leitura humana independente antes de promover.
        dependencies.append("INDEPENDENT_RPG_WITNESS_READBACK")
    # Critério anti-invenção: nem uma entrada com YES + event ID é comprovação.

    h2=payload.get("h2",{})
    fields=("substrate_source","compatible_medium_source","target_effect_pattern_source",
            "energization_rule_source","stabilization_rule_source", "witness_authority_source")
    missing=[f for f in fields if not h2.get(f)]
    if missing:
        h2_state="H2_INSCRIPTION_CONTRACT_INCOMPLETE"
        dependencies.extend("H2_MISSING_"+f.upper() for f in missing)
    else:
        h2_state="H2_REVIEW_OF_CONTRACT_REQUIRED_NOT_EXECUTED"
        dependencies.append("H2_TEST_AUTHORIZATION_AND_WITNESS_REVIEW")
    if h2.get("seal_only_claims_light"):
        errors.append("SEALING_DOES_NOT_IMPLY_LUMINESCENCE")
    if h2.get("use_existing_recipe_as_new_light_formula"):
        errors.append("UNSUPPORTED_CROSS_EFFECT_RECIPE_COPY")
    if h2.get("seal_fabrication_proven"):
        errors.append("SEAL_FABRICATION_NOT_PROVEN")

    return {
        "case_id": CASE,
        "h1_gate":h1_state,
        "h2_gate":h2_state,
        "errors":errors,
        "dependencies":sorted(set(dependencies)),
        "software_admissible":not errors,
        "has_in_game_observation":False,
        "has_demonstrated_magic_transfer":False,
        "rc5":False,
        "native_r48_new_orders":0,
        "proven_effects_of_mounted_pingente":[],
        "note":"Somente um humano com fonte competente pode converter uma observacao de RPG em evidencia; este preflight nunca declara magia provada."
    }


def main():
    if len(sys.argv)<2:
        print("Usage: python controle_h1_h2.py STATUS_AUDITADO.json")
        return 2
    data=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    p={"case_id":data["case_id"],"recipe_version":data["recipe_version"],"h1":{"master_decision":data["h1_master_decision"]},"h2":{}}
    print(json.dumps(gate(p),ensure_ascii=False,indent=2))
    return 0
if __name__=="__main__":
    sys.exit(main())
