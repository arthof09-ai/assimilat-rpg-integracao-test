import hashlib,json,sys
from pathlib import Path
p=Path(__file__).resolve().parent
manifest=json.loads((p/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
missing=[]; mismatch=[]
for name,expect in manifest.items():
 f=p/name
 if not f.is_file(): missing.append(name)
 elif hashlib.sha256(f.read_bytes()).hexdigest()!=expect: mismatch.append(name)
if missing or mismatch:
 print('MANIFEST_FAIL',{'missing':missing,'mismatch':mismatch});sys.exit(1)
print('MANIFEST_PASS',str(len(manifest))+'/'+str(len(manifest)))
