import copy, unittest
from controle_h1_h2 import gate, CASE, OLD_ORDER

GOOD={"case_id": CASE, "recipe_version": "1.3 TEST", "h1":{},"h2":{}}
class Cases(unittest.TestCase):
    def run_g(self,**updates):
        p=copy.deepcopy(GOOD);p.update(updates);return gate(p)
    def test_pending_master_cannot_be_accepted(self):
        r=self.run_g();self.assertEqual(r["h1_gate"],"H1_DECISION_PENDING");self.assertFalse(r["has_in_game_observation"])
    def test_claimed_yes_without_source(self):
        r=self.run_g(h1={"master_decision":"YES"});self.assertEqual(r["h1_gate"],"H1_DECISION_REFERENCE_MISSING")
    def test_yes_with_reference_is_not_observation(self):
        r=self.run_g(h1={"master_decision":"YES","master_decision_source":"only-fixture://unit-test","witness_event_id":"fabricated-id"});self.assertEqual(r["h1_gate"],"H1_SCENE_ELIGIBLE_NOT_OBSERVED");self.assertFalse(r["has_in_game_observation"]);self.assertFalse(r["has_demonstrated_magic_transfer"])
    def test_no_is_not_fail_of_h2(self):
        r=self.run_g(h1={"master_decision":"NO","master_decision_source":"only-fixture://unit-test"});self.assertEqual(r["h2_gate"],"H2_INSCRIPTION_CONTRACT_INCOMPLETE")
    def test_only_seal_cannot_imply_light(self):
        r=self.run_g(h2={"seal_only_claims_light":True});self.assertIn("SEALING_DOES_NOT_IMPLY_LUMINESCENCE",r["errors"])
    def test_recipe_copy_not_luminescence(self):
        r=self.run_g(h2={"use_existing_recipe_as_new_light_formula":True});self.assertIn("UNSUPPORTED_CROSS_EFFECT_RECIPE_COPY",r["errors"])
    def test_h2_contract_fully_filled_is_still_not_executed(self):
        f={k:"fixture://source" for k in ("substrate_source","compatible_medium_source","target_effect_pattern_source","energization_rule_source","stabilization_rule_source","witness_authority_source")}
        r=self.run_g(h2=f);self.assertEqual(r["h2_gate"],"H2_REVIEW_OF_CONTRACT_REQUIRED_NOT_EXECUTED");self.assertFalse(r["has_demonstrated_magic_transfer"])
    def test_magic_true_rejected(self):
        r=self.run_g(magic_success=True);self.assertIn("BOOLEAN_IS_NOT_RPG_OBSERVATION",r["errors"])
    def test_old_transaction_reuse_forbidden(self):
        r=self.run_g(r48_order=OLD_ORDER);self.assertIn("OLD_TRANSACTION_REUSE_FORBIDDEN",r["errors"])
    def test_production_and_party_forbidden(self):
        r=self.run_g(promote_rc5=True,party_write=True);self.assertIn("PRODUCTION_PARTY_OR_RC5_FORBIDDEN",r["errors"])
    def test_wrong_case_forbidden(self):
        r=self.run_g(case_id="PENDANT-CLONE");self.assertIn("WRONG_CASE_OR_DUPLICATE",r["errors"])
    def test_unsourced_claim_invalid(self):
        r=self.run_g(claims_observed_magic=True);self.assertIn("UNVERIFIED_MAGIC_CLAIM",r["errors"])

if __name__=='__main__':unittest.main()
