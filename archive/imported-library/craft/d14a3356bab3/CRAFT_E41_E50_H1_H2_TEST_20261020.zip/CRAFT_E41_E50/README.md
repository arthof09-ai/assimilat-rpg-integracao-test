# CRAFT E41–E50 | LAB H1/H2 (delta, sem duplicar baseline)

Mesma OP/caso/receita Pingente 1.3. Conteúdo: cena TEST H1 A–E não adjudicada; candidato H2 controlado de estabilização por inscrição de Vedação existente; preflight fail-closed; auditoria da Inbox CM-000002; PSV com rastreio.

`python -m unittest -q test_controle_h1_h2.py`

`python controle_h1_h2.py STATUS_AUDITADO.json`

`python VERIFY_MANIFEST.py` (após instalar o pacote, compara arquivos do próprio delta)

O software NÃO executa magia em RPG nem fábrica nativa R48 e não gera evidência canônica. A ordem anterior R48 não é reexecutada. Consulte H1 Master's decision pendente; não execute cena montada com premissa presumida.
