# Cena H1 — Ensaio de alojamento funcional do mesmo Pingente (TEST)

**Identidade preexistente:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001` · Pingente v1.3 · OP-ARQ-RIN-REC-01 · MESTRE-SIDE.

**Gate primário:** o Mestre **ainda não adjudicou** se fixação não destrutiva preserva as manifestações mágicas próprias dos materiais. Estado `H1_DECISION_PENDING`. Este documento define uma cena pronta para execução **depois** da autorização. NÃO é relato de cena ocorrida.

## Equipamento e precondições

- Uma Erva da Luz do Norte **intacta** (a fonte documenta luz e possível revelação); um Cristal de Aurora Boreal **intacto** (fonte registra luz e possibilidade de dissipar escuridão), fibra da Casca Boreal **somente estrutural** 45 cm PROPOSTOS. Nenhuma fonte física é afirmada disponível. Unidades discretas 1/1 e 45 cm continuam apenas especificação TEST.
- Não pressupor corpo metálico, runa, lente, esmalte, pasta, óleo, habilidade do operador, ferramenta ou montagem já medida. A fixação é montagem **não destrutiva proposta**; suporte, resistência, fecho e ergonomia não comprovados.
- Mesma cena/iluminação/portador e observador autorizado nas comparações; fontes não são automaticamente portadoras de efeito após montagem. Não inventar intensidade, alcance, duração, CD, rolagem, carga ou efeitos sem regra.
- **Condições separadas**: penumbra/escuridão comum (teste da erva); escuridão mágica criada por efeito canônico IDENTIFICADO (cristal — exige forma, origem, alcance e ação competente). Se não houver efeito identificável, o ramo de contrassombra fica `SCENE_CONDITION_NOT_GROUNDED`.

## Controles A–E (estado inicial, intervenção, testemunho)

| Cena | Condição variável | Pergunta experimental | Saída legítima sem adjudicação |
|---|---|---|---|
| A | Fontes soltas, isoladas, sem fibra | Luz da erva/ação do cristal conforme suas próprias fichas? | `SOURCE_PROPERTY_DOCUMENTED_NOT_SCENE_OBSERVED` |
| B | Fontes intactas alojadas/expostas, sem inscrição | Mantêm o mesmo comportamento de A? | `H1_DECISION_PENDING` |
| C | Mesmo suporte, **sem erva** | Desaparece a contribuição da erva? | `NEGATIVE_CONTROL_PLANNED` |
| D | Mesmo suporte, **sem cristal** | Desaparece a contribuição do cristal? | `NEGATIVE_CONTROL_PLANNED` |
| E | Mesmo conjunto, manifestação obstruída SEM DANIFICAR | Há bloqueio por cobertura/obstáculo? | `OBSTRUCTION_RULE_UNDEFINED` |

**Registro por evento em RPG:** `event_id`, `observer_authority`, `source_page_version`, `decision_h1_id`, `scene_location_test`, `ambient_effect_ref`, `source_prestate`, `setup`, `action`, `observables`, `rule_or_adjudication_ref`, `comparison_control`, `result`, `evidence_ref`, `notes`, `next_action`. O programa NÃO preenche observações por conta própria. Todos estes campos ficam `PENDENTE` até cena real resolvida.

## Resultados H1 possíveis

- `H1_SOURCE_FUNCTION_RETAINED`: somente após decisão + ensaio observado com controle A/B positivo; o efeito continua atribuído ao **material alojado**.
- `H1_SOURCE_FUNCTION_BLOCKED`: adjudicação e controle confirmam bloqueio.
- `H1_SOURCE_FUNCTION_CHANGED`: funcionamento alterado em relação a A, novo exame de mecanismo e tarifa.
- `H1_NOT_RESOLVABLE_WITH_CURRENT_AUTHORITY`: sem decisão, sem condições ou sem observador.

Nenhuma dessas saídas certifica automaticamente **raio 1 metro, ação padrão, 1 turno, duas ativações, PA debitado ou encanto próprio do corpo**. Testar cada parâmetro separadamente quando houver contrato.

## Decisão pontual ao Mestre (única, ainda pendente)

*Em uma cena Mestre-side TEST, a fixação não destrutiva e não obstrutiva da Erva da Luz do Norte e do Cristal Aurora, sem mudar sua estrutura, conserva as manifestações originais de cada componente enquanto **propriedade do próprio material**, sem conceder magia ao suporte?*

**SIM:** admite A/B/C/D com observador do RPG; não determina de antemão o resultado da cena nem efeito adicional. **NÃO:** proíbe presumir conservação e encaminha H1 para processamento específico; H2 continua em engenharia, sem usar um não em H1 como evidência de falha H2.
