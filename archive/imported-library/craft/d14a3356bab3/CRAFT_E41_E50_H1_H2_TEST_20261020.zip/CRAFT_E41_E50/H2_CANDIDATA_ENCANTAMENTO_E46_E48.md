# Variante técnica H2 — conservação por inscrição/vedação (somente hipótese TEST)

**A MESMA receita/caso:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001` v1.3, sem criar REC-ID, fórmula oficial, inscrição nova no catálogo ou item de Party.

## Nova pesquisa e descoberta operacional

A [Inscrição de Vedação (Prata)](https://app.notion.com/p/3edc2b324ede81adab3dd3a7f9fe921d) **efetivamente** descreve matriz capaz de conter/estabilizar energia mágica, com [receita própria](https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8): argila, água benta, sal, ferro de meteoro, essência de barreira, óleo de vedação e fonte de energia especificada. A [Inscrição de Selamento](https://app.notion.com/p/3edc2b324ede81769f26d68a8a42aab6) sela espíritos/energias, mas não instala por si uma habilidade luminosa. A [ficha do Óleo de Vedação](https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd) suporta uso em selamento de magias e objetos, mas a receita interna apresenta nomes inconsistentes entre lista e procedimento. Essas são **autoridades de metodologia e comparadores de retenção**, NÃO autorização para aplicar o mesmo selo ao Pingente como se produzisse luz.

### Hipótese H2 mínima delimitada

**H2a — Ancoragem, não geração:** se uma ocorrência legítima de vedação poderia estabilizar uma **fonte já luminosa**, avaliar a diferença entre (i) fonte apenas alojada H1, (ii) fonte instalada em suporte com selo admissível, (iii) selo isolado sem a fonte. O selo poderia **reter/obstruir/alterar** a manifestação: nenhuma direção é presumida.

**H2b — Instalação efetiva:** seria necessário demonstrar que o efeito, não apenas a fonte, está associado à superfície do Pingente e persiste sob condição discriminatória definida, possivelmente após remoção da fonte quando a regra permitir. Sem o padrão de LUZ+CONTRASSOMBRA, o resultado **não está demonstrado**.

## Caminho operacional proposto (não executado)

1. **Inspecionar substrato:** a receita original v1.3 tem fibra, cristal e erva, mas **não** descreve placa rígida com superfície livre de inscrição. Decisão técnica: substrato disponível em fonte autorizada e superfície/slot verificáveis, preservando o caso; nunca inserir placa de material inventado na BOM.
2. **Habilitar meio de inscrição:** **não existe pasta luminosa completa** comprovada para o Pingente. A matriz da Vedação possui seus próprios ingredientes e efeito; usá-la para iluminar violaria causalidade. Óleo de Vedação é um **candidato de componente adicional TEST para controle de selagem**, não elemento consumido da v1.3 nem produto pronto garantido; unidade e lote ficam PENDENTES.
3. **Padrão/geometria:** nenhum traçado para Luminescência+Contrassombra foi encontrado entre as inscrições canônicas pesquisadas. A forma deve ser decidida/aprovada como candidato LAB, não apresentada como descoberta canônica.
4. **Acoplar fonte:** em teste discriminatório, fonte da erva/correspondência luz em superfície; cristal/correspondência reação à escuridão. Se a fonte tiver de ser moída ou aquecida, **não presumir sobrevivência do efeito**. Preferir interfaces não destrutivas para primeiro controle.
5. **Energização e ativação:** mecanismo e quantidade precisam de regra de inscrição aplicável; orçamento PA R39 (12/dia +7/uso) se refere a **hipótese de habilidades próprias da versão v1.3**, não ao custo de uma matriz de Vedação Prata, nem é custo do procedimento de fabrico.
6. **Cura/selagem:** comparar H1 sem inscrição vs H2 com inscrição válida e vs selo sem fonte. O selamento pode prejudicar luminosidade; um PASS estrutural não é eficácia.
7. **Teste de retenção:** observação no RPG por fonte independente e árbitro, com estado montado, removido e reintroduzido **somente se operação for reversível**; R46 laudo e R47 autenticidade não poderão ser criados com chaves de fixture como se fossem testemunhas reais.

## Gate verificável

| Requisito REC-MOD-ENC | Estado agora | Motivo |
|---|---|---|
| Substrato, superfície/área | PENDENTE | corpo físico do acessório não discriminado além da fibra |
| Efeito-alvo / fontes | DOCUMENTADO E2/PROPOSTO E3 | duas fichas de recursos, habilidades próprias do item não demonstradas |
| Meio/pasta compatível | PENDENTE | nenhuma fórmula luminescente do Pingente |
| Padrão específico | PENDENTE | outras inscrições causam efeitos diferentes |
| Procedimento de energização | PENDENTE | PA de uso não substitui energização da receita |
| Selagem/estabilização | COMPARADOR ENCONTRADO / APLICAÇÃO PENDENTE | Vedação Prata existente, não transferência automática |
| Ativação, retenção, eficácia | NÃO OBSERVADOS | cena TEST/adjudicação/ensaios ainda necessários |

**Resultado funcional novo de E46–E48:** contrato de estabilização candidato ancorado em uma inscrição existente e **caminho de falsificação** (`fonte solta` x `alojada sem selo` x `selo sem fonte` x `fonte selada`). **Não é execução da inscrição**, não produz magia, não altera rank, item, rendimento ou store R48. Não duplicar a rota H1; H2 prossegue independentemente.

### Condição mínima adicional para ensaio H2 legítimo

Apresentar ao Mestre/subsistema de encantamentos **uma** proposta de substrato + padrão + meio concretamente fundamentada e pedir autorização delimitada para a variante TEST. Enquanto faltar qualquer dessas três partes, não declarar execução nem preparar commit MAGIC_TEST R48. A existência da Vedação canonizada não sana a lacuna.
