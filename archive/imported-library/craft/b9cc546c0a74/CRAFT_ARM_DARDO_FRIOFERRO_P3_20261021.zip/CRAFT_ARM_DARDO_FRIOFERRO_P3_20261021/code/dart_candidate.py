"""CRAFT MESTRE-SIDE TEST only: single authorial P3 dart design, zero canon actions."""
from itertools import product
import math

REFS = {
  'frioferro':'https://app.notion.com/p/fbcc2b324ede820582ca010199f7af51',
  'canonical_lance':'https://app.notion.com/p/3edc2b324ede81ecbae3cf4b0cf274e5',
  'arm_module':'https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649',
  'pr_item':'https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4',
}
PROPOSAL={
  'trace':'CRAFT-ARM-FRIOFERRO-DART-P3-20261021-001',
  'stage':'P3_PROPOSTO_ONLY',
  'name':'Dardo de Frioferro de Vigília',
  'family':'ARMA_ARREMESSO',
  'quantity_actual_produced':0,
  'function':'candidato de arma de arremesso com ponta de Frioferro para ensaio de contato frio',
  'sources':REFS,
  'bom':{'ponta_frióferro':'material canônico referenciado; massa/quantidade/lote PENDENTES',
          'corpo_dardo':'suporte estrutural EXISTING-FIRST a escolher; sem lote',
          'uniao':'junção mecânica e isolamento térmico PENDENTES',
          'acabamento':'tratamento superficial compatível PENDENTE'},
  'process_proposto':['Identificar lote Frioferro e corpo estrutural','Refino e forja somente por operador e procedimento competentes',
      'Conformação e tratamento sob medidas controladas','Montagem da junção sem alterar fontes do jogo',
      'Balanceamento e integridade','Teste inerte seguro e metrológico','Somente depois, ensaio de contato térmico/adjudicação mágica'],
  'effect_source':'Frioferro absorve frio do ambiente; fonte diz que armas podem congelar ao contato, sem garantir este produto',
  'effect_owned_by_item':None,'magic_observed':False,'freeze_confirmed':False,
  'attack_damage':None,'classificacao_publica':None,'PA_day':None,'PA_use':None,
  'ammo_count':None,'range_m':None,'cooldown':None,'cost_med':None,
  'comparison':'Lança Sopro Congelante é arma existente com magia própria, DANO/PA/skills não importáveis.',
  'standalone_spell_or_inscription':False,'r48_order_created':False,'r48_orders':0,
  'physical_tests':0,'material_consumption':0,'party_prime_writes':0,
}
REQUIRED={
 'frioferro_lot_id','shaft_lot_id','fastener_lot_id','projected_geometry_ref',
 'measured_geometry_ref','forge_process_authority_ref','operator_credential_ref',
 'balance_instrument_ref','sample_id','chain_of_custody_ref','qa_signed_report_ref',
 'thermal_control_report_ref','witness_adjudication_ref','DMG_RANK_classifier_report_ref'
}
FORBIDDEN={
 'reuse_canonical_lance_skills','import_lance_4d8','import_lance_8PA',
 'magic_pre_observed','party_item_modified','claim_rc5','official_stock_consumed',
 'bypass_DMG_rank','new_spell_created'
}

def readiness(claims=None):
    if claims is None: claims={}
    if not isinstance(claims,dict):
        return {'stage':'REJECT_BAD_DOCUMENT','physical_pass':False,'magic_pass':False,'rc5':False}
    maltyped=sorted(k for k in FORBIDDEN if k in claims and type(claims[k]) is not bool)
    forbidden=sorted(k for k in FORBIDDEN if claims.get(k) is True)
    missing=sorted(k for k in REQUIRED if not isinstance(claims.get(k),str) or not claims[k].strip())
    if maltyped: stage='REJECT_BAD_FLAGS'
    elif forbidden: stage='REJECT_ILLEGITIMATE_TRANSFER_OR_WRITE'
    elif missing: stage='HOLD_REQUIRED_MATERIAL_EVIDENCE'
    else: stage='CONDITIONAL_PHYSICAL_AND_ADJUDICATION_REVIEW'
    return {'stage':stage,'missing':missing,'maltyped_flags':maltyped,'forbidden_flags':forbidden,
         'rc5':False,'physical_pass':False,'magic_pass':False,'PA_due':None,'r48_orders':0,
         'party_prime_writes':0}

def geometry(synthetic=None):
    if not isinstance(synthetic,dict):
       return {'stage':'NO_SYNTHETIC_MEASURES','physical_pass':False,'measured':False}
    keys=['shaft_length_mm','head_length_mm','overall_length_mm','head_mass_g','total_mass_g']
    if any(type(synthetic.get(k)) not in (float,int) or not math.isfinite(synthetic[k]) or synthetic[k]<=0 for k in keys):
       return {'stage':'INVALID_SYNTHETIC_GEOMETRY','physical_pass':False,'measured':False}
    plausible=(synthetic['overall_length_mm']>=synthetic['shaft_length_mm']
       and synthetic['overall_length_mm']>=synthetic['head_length_mm']
       and synthetic['total_mass_g']>=synthetic['head_mass_g'])
    return {'stage':'SYNTHETIC_LOGIC_PASS' if plausible else 'SYNTHETIC_LOGIC_FAIL',
       'physical_pass':False,'measured':False,'tolerance_approved':False}

def causal_plan():
   return [{'cold_source':c,'contact':t,'control':True,'executed':False,'magic_observed':None}
      for c,t in product([False,True],repeat=2)]

def snapshot():
   return {'proposal':PROPOSAL,'default_readiness':readiness(),'default_geometry':geometry(),
      'causal_plan':causal_plan(),'candidate_P3_count':1,'physical_products':0,
      'magic_tests':0,'rc5':0,'new_r48_orders':0,'party_prime_writes':0}
if __name__=='__main__':
 import json
 print(json.dumps(snapshot(),ensure_ascii=False,indent=2))
