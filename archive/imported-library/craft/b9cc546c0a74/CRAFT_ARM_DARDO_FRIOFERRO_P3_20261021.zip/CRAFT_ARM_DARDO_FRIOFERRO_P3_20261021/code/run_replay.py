import subprocess,sys,json,importlib.util
from pathlib import Path
r=Path(__file__).resolve().parents[1]
def run(args):
 x=subprocess.run([sys.executable,*args],cwd=r,capture_output=True,text=True,timeout=25)
 assert x.returncode==0,x.stderr[-1500:]
 return x.stdout+x.stderr
assert 'PASS_MANIFEST' in run(['code/verify_manifest.py'])
q=run(['-m','unittest','discover','-s','tests','-p','test_*.py'])
assert 'Ran 23 tests' in q,q
sp=importlib.util.spec_from_file_location('dart',r/'code/dart_candidate.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
assert m.snapshot()==json.loads((r/'outputs/snapshot.json').read_text())
assert m.snapshot()['physical_products']==0 and m.snapshot()['magic_tests']==0
print('PASS_REPLAY CRAFT_ARM_DART 23/23 DIGITAL 1 P3 PROPOSAL 0 MAGIC 0 PROD')
