# CRAFT — Dardo de Frioferro de Vigília (P3 PROPOSTO/TEST)

Existing OP-ARQ-RIN-REC-01 / CM-000002-WS0001, Master-only. Distinct from pre-existing Lança Sopro Congelante. This is a design, not a manufactured weapon and not a new canonical recipe.

Run `python code/run_replay.py` after clean extraction. No actual dimensions, forge/weapon, damage, chance to freeze, PA, cost, range, cooldown, item ranking, stock, operator, magic or test scenes are asserted. R48 and Party/O Primeiro remain untouched. The weapon derives a TEST *research question* from the Frioferro source, not an item skill.
