# Dardo de Frioferro de Vigília — P3 / TEST / Mestre-side

**ID funcional** CRAFT-ARM-FRIOFERRO-DART-P3-20261021-001. **Família** arma de arremesso. **Estado** projeto autoral P3 proposto, PS/P4/RC5 = NÃO. Um projeto distinto do suporte de escudo P3, sem produzir fichas canônicas. Sem rank público atribuído.

**Problema útil**: criar um objeto de arremesso cuja ponta possa testar, sob adjudicação, a propriedade do material Frioferro de absorver frio; o texto-fonte relata que armas podem congelar ao contato, mas NÃO estabelece que qualquer design obtém esse efeito, sua duração, CD, dano, alcance ou PA. O ensaio deve aferir integridade física e diferença causal entre contato real com Frioferro versus controle não-Frioferro antes de qualquer alegação mágica.

**Fontes**: [Frioferro regional](https://app.notion.com/p/fbcc2b324ede820582ca010199f7af51); [Lança Sopro Congelante canônica](https://app.notion.com/p/3edc2b324ede81ecbae3cf4b0cf274e5); [REC-MOD-ARM-01](https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649); [PR-ITEM-02](https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4). A Lança tem passivo congelante, Estilhaço de Gelo, Passagem Glacial, 4d8 de dano, 3m alcance, 8 PA em habilidade e 24/dia na ficha; NENHUM destes números é importado para o Dardo.

**BOM/projeto:** Frioferro como candidato à ponta, quantidade/pureza/forma/rendimento PENDENTES; haste estrutural existente a selecionar EXISTING-FIRST; junção e isolamento a testar; acabamento autorizado a determinar. Não pressupor minério em estoque. **Projeto de processo**: escolha de lotes → extração/refino/forja competente → conformação da ponta → acoplamento → balanceamento → ensaio de integridade/safe arremesso controlado → ensaio térmico/efeito sob árbitro competente. Cada etapa carece evidência e operador; não executada.

**Riscos**: ponta projetiva, massa/distribuição/desbalanceamento, desprendimento de ponta, frio térmico, ferimento, interação elemental. Não praticar lançamento real sem ambiente e profissionais aptos, contenção de projéteis, equipamento e segurança; proibido usar personagem/player como alvo de teste técnico. O braço controle inerte e simulação documental antecedem qualquer cena mágica.

**Gates**: 14 identificadores de evidência obrigatórios no code/readiness; medidas reais com instrumento e tolerância; operador/autoridade da forja; amostra/custódia; QA assinado; controle termodinâmico, árbitro e DMG-RANK para dano/rank. Uma string em um campo NÃO prova verdade; mesmo preenchido, output fica conditional, jamais physical pass. Quatro braços causais de frio × contato todos PROPOSTOS, 0 executados.

**Mecânica e PA**: dano, congelamento, duração, CD, alcance, custo diário e por ativação, rank, mercado, manutenção e recuperação ficam NULL/PENDENTE. A Lança Sopro Congelante é comparador de outra magia, não receita para cópia. Nenhum resultado do CRAFT atribui skill nova a personagem/item, nem encosta nas contas ou inventários Party/O Primeiro.

**Critério de saída:** projeto físico seguro ainda necessita lote verdadeiro, controles, autorização e QA; efeito só depois de adjudicação competente; receita PS/RC5 somente por hierarquia PR-SC/REC-EXEC/F5 quando permitido, jamais por este pacote.
