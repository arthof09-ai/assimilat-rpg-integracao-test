import unittest,sys,pathlib,math
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'code'))
import dart_candidate as d
class DartP3QA(unittest.TestCase):
 def test_stage(self):self.assertEqual(d.PROPOSAL['stage'],'P3_PROPOSTO_ONLY')
 def test_lance_non_import(self):self.assertIn('não importáveis',d.PROPOSAL['comparison'])
 def test_no_real_effect(self):self.assertFalse(d.PROPOSAL['magic_observed'])
 def test_no_dmg(self):self.assertIsNone(d.PROPOSAL['attack_damage'])
 def test_pa_null(self):self.assertIsNone(d.PROPOSAL['PA_day']);self.assertIsNone(d.PROPOSAL['PA_use'])
 def test_default_hold(self):self.assertEqual(d.readiness()['stage'],'HOLD_REQUIRED_MATERIAL_EVIDENCE')
 def test_no_dict(self):self.assertEqual(d.readiness(2)['stage'],'REJECT_BAD_DOCUMENT')
 def test_four_causal_arms(self):self.assertEqual(len(d.causal_plan()),4)
 def test_no_executed_arms(self):self.assertFalse(any(x['executed'] for x in d.causal_plan()))
 def test_all_claims_not_sufficient(self):
  x={k:'trace' for k in d.REQUIRED};self.assertEqual(d.readiness(x)['stage'],'CONDITIONAL_PHYSICAL_AND_ADJUDICATION_REVIEW');self.assertFalse(d.readiness(x)['physical_pass'])
 def test_forbidden(self):
  for k in d.FORBIDDEN:
   with self.subTest(flag=k):self.assertEqual(d.readiness({k:True})['stage'],'REJECT_ILLEGITIMATE_TRANSFER_OR_WRITE')
 def test_bad_types(self):
  for k in d.FORBIDDEN:
   with self.subTest(flag=k):self.assertEqual(d.readiness({k:'false'})['stage'],'REJECT_BAD_FLAGS')
 def test_empty_needed(self):
  for k in d.REQUIRED:
   with self.subTest(key=k):self.assertIn(k,d.readiness({k:''})['missing'])
 def test_geometry(self):
  x={'shaft_length_mm':50,'head_length_mm':20,'overall_length_mm':60,'head_mass_g':3,'total_mass_g':11}
  self.assertEqual(d.geometry(x)['stage'],'SYNTHETIC_LOGIC_PASS');self.assertFalse(d.geometry(x)['measured']);self.assertFalse(d.geometry(x)['physical_pass'])
 def test_geometry_invalid(self):
  x={'shaft_length_mm':50,'head_length_mm':20,'overall_length_mm':60,'head_mass_g':3,'total_mass_g':11}
  for key in x:
   for val in [float('nan'),float('inf'),float('-inf'),-1,0,True,None,'100']:
    y=x.copy();y[key]=val
    with self.subTest(key=key,val=val):self.assertEqual(d.geometry(y)['stage'],'INVALID_SYNTHETIC_GEOMETRY')
 def test_geometry_bad_ratio(self):
  x={'shaft_length_mm':200,'head_length_mm':20,'overall_length_mm':60,'head_mass_g':20,'total_mass_g':11}
  self.assertEqual(d.geometry(x)['stage'],'SYNTHETIC_LOGIC_FAIL')
 def test_empty_geometry(self):self.assertEqual(d.geometry(None)['stage'],'NO_SYNTHETIC_MEASURES')
 def test_no_new_source(self):self.assertEqual(d.PROPOSAL['material_consumption'],0)
 def test_none_rank(self):self.assertIsNone(d.PROPOSAL['classificacao_publica'])
 def test_no_party(self):self.assertEqual(d.snapshot()['party_prime_writes'],0)
 def test_one_p3_not_rc5(self):self.assertEqual(d.snapshot()['candidate_P3_count'],1);self.assertEqual(d.snapshot()['rc5'],0)
 def test_no_r48(self):self.assertEqual(d.readiness()['r48_orders'],0)
 def test_hold_safeguards(self):
  dct=d.readiness();self.assertFalse(dct['rc5']);self.assertFalse(dct['physical_pass']);self.assertFalse(dct['magic_pass'])
