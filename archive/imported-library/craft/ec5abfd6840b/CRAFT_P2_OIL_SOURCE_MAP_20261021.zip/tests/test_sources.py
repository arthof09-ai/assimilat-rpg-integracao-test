import unittest,sys,json,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(ROOT/"code"))
from validate import check
class TestMap(unittest.TestCase):
 @classmethod
 def setUpClass(c): c.m=json.loads((ROOT/"SOURCE_MAP.json").read_text(encoding="utf-8"))
 def test_base(self):self.assertEqual(check(self.m)["bom_lines"],12)
 def test_sources_not_lots(self):self.assertFalse(any(r["lot_verified"] for r in self.m["rows"]))
 def test_mirror_not_master(self): self.assertGreaterEqual(sum(r["source_status"].startswith("MIRROR_ONLY") for r in self.m["rows"]),3)
 def test_alternative_not_cumulative(self): self.assertEqual(sum(r["stage"]=="P2/ENERGIA-OU" for r in self.m["rows"]),2)
 def test_iron_processing_held(self): self.assertIn("NOT_POWDER",next(r for r in self.m["rows"] if r["ingredient"]=="Pó de Ferro Celestial")["source_status"])
 def test_illegal_promote_detected(self):
  m=copy.deepcopy(self.m);m["rows"][0]["lot_verified"]=True
  with self.assertRaises(AssertionError):check(m)
 def test_duplicate_item_detected(self):
  m=copy.deepcopy(self.m);m["rows"][1]["ingredient"]=m["rows"][0]["ingredient"]
  with self.assertRaises(AssertionError):check(m)
 def test_scope(self):self.assertEqual(self.m["counts"]["p2_mandatory"],6)
 def test_no_party_write(self):self.assertEqual(self.m["party_writes"],0)
 def test_no_o_primeiro(self):self.assertEqual(self.m["o_primeiro_writes"],0)
 def test_source_ids(self):
  for x in self.m["rows"]:
   v=x["candidate_page_id"]
   if v:self.assertEqual(len(v),32)
 def test_no_substitution(self):self.assertFalse(self.m["substitution"])
 def test_oil_two_versions(self):self.assertNotEqual(self.m["oil_version_quantity"]["Mestre"],self.m["oil_version_quantity"]["Historical"])
 def test_production_held(self):self.assertEqual(self.m["production_state"],"HOLD")
 def test_conflicts(self):self.assertEqual(len(self.m["process_conflicts"]),3)
 def test_lots_zero(self):self.assertEqual(self.m["counts"]["lots_physically_verified"],0)
if __name__=="__main__":unittest.main(verbosity=1)
