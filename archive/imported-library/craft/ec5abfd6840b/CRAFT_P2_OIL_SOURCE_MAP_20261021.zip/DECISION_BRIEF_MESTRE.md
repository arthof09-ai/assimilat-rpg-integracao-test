# CRAFT — P2 e Óleo de Vedação: mapa de fontes (MESTRE-ONLY)

**Resultado:** 12 linhas de BOM (seis obrigatórias da P2, duas alternativas mutuamente exclusivas de energização e quatro do óleo). **Nenhum lote físico verificado**. Busca nominal dirigida, não censo global; o retorno de um título no Espelho da Party não vale como fonte Mestre.

**BOM de P2:** 3 Argila de Elemental da Terra; 1 Água Benta de Santuário; 2 Sal de Geodo Santo; 3 Pó de Ferro de Meteoro; 1 Essência de Barreira Mística; 1 Óleo de Vedação; MAIS ramo OU de 2 Pedras da Luz **ou** 2 Potes de Essência Mágica.

**BOM do Óleo Mestre:** 1 Raiz de Mandrágora, 8 Gotas do Orvalho do Amanhecer, 3 Pó de Ferro Celestial, 1 Essência de Lua Minguante. A cópia histórica tinha 2x Pó Ferro Celestial; não vale como decisão atual. Rendimento e porção não documentados.

**Novos bloqueios materiais diferenciados:** Ferro Celestial Mestre tem unidade operacional de *peça*, receita exige *pó*; Pó de Meteoro não prova ser Pó de Ferro de Meteoro; Essência Mágica genérica não prova 'Pote' com unidade/volume; itens com título exato encontrados somente no Espelho Mestre Party na busca direcionada não são provas de posse nem fontes competentes. As menções não equivalem a lotes em estoque.

**Correções proibidas:** converter peça em pó sem rendimento, substituir pedra por pote sem cena, trocar Sal Santo por Encantado, Orvalho Amanhecer por Dragão, Lua Minguante por Vórtice ou usar a versão óleo 2x no lugar da versão Mestre 3x. Nenhum write em itens/receitas/Party/O Primeiro.

**Decisões já existentes, sem duplicação:** P2-SALT-01, P2-ENERGY-02 e IBX-116; revisão de identidade e processo de óleo no mesmo envelope. F5 P0 RED, C19-021 UNKNOWN-SIDE-EFFECT, RC5/P4/PROD HOLD. PASS apenas pesquisa documental nominal TEST, nenhum efeito mágico.

Fonte de base: https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8; https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd; programa e resultados anteriores em LAB https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00.
