import json
from pathlib import Path

def check(m):
    r=m["rows"]
    assert len(r)==12 and len({(x["stage"],x["ingredient"]) for x in r})==12
    assert sum(x["stage"]=="P2" for x in r)==6
    assert sum(x["stage"]=="P2/ENERGIA-OU" for x in r)==2
    assert sum(x["stage"]=="OIL" for x in r)==4
    assert all(not x["lot_verified"] and not x["canonical_substitution_authorized"] for x in r)
    assert not m["stage_transition_authorized"] and m["production_state"]=="HOLD"
    assert m["energy_rule"].startswith("Exactly one")
    assert m["oil_version_quantity"]["Mestre"].startswith("3x")
    assert m["oil_version_quantity"]["Historical"].startswith("2x")
    return {"status":"DOCUMENTARY_SOURCE_MAP_ONLY_NO_PRODUCTION", "bom_lines":len(r), "material_lots_verified":0, "substitution_authorized":False}
if __name__=="__main__":
 p=Path(__file__).resolve().parent.parent/"SOURCE_MAP.json"
 print(json.dumps(check(json.loads(p.read_text(encoding="utf-8"))),sort_keys=True))
