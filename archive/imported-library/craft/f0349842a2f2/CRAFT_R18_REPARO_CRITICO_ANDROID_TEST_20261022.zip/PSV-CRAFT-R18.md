# PSV CRAFT R18 — Correção assistida de REJECT (TEST)

**ANTES:** R17 517/517 JS, 154/154 Chromium inline e SHA receipt QA/preview intacto. A importação falhava de forma segura, porém arquivo rejeitado não possuía roteiro baixável. Notion Mestre disponível somente para leitura; F5 C19/IBX38/R51 HOLD.

**DEPOIS:** mesma interface R53/R17 exibe botão para baixar reparo do arquivo rejeitado; classes críticas derivadas dos códigos JÁ EMITIDOS pelo validador. Um REJECT não vira objeto ativo. Roteiro apresenta status PENDENTE_NAO_OBSERVADO, sem dados de laudo, sem aprovação de produção/estoque/Party; fallback para códigos desconhecidos. JSON inválido sintaticamente, tamanho acima de 2 MiB ou importação válida descartam plano rejeitado antigo. Não houve alteração em validade, rank, PA, preços, BOM, receitas, bibliotecas canônicas ou cópias Party.

**QA:** 517/517 verificações JS herdadas; fuzz robustez informacional 2.000; Chromium inline 154/154 regressões R9–R17 + 171/171 novas R18 = **325/325**. Testes reais de importação/download em browser de sistema (390×844), não Android físico/file://. Saídas QA e Player preview R17 byte-idênticas; recibo OUTPUT_COMMIT verificado. Manifests, CRC e replay cold comprovam somente software, não fabricação.

**Gates NAC-PASS:** TEST digital PASS; C19-021 UNKNOWN, IBX38 NOVA/Exige ACK, R51 parent não verificado, F5 P0 RED, RC5/P4/produção, H2/R46 físico, fonte de PA e Party/O Primeiro NO-WRITE. Não reivindicar writer/lease/epoch/ACK. **PONTO EXATO:** R18 funcional no revisor existente, sem sincronização Notion pós-R13 enquanto ferramenta de atualização estiver indisponível.
