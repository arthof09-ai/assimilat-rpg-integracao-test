import json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'MANIFEST_SHA256.json').read_text())['sha256_by_relative_path']
a={str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in root.rglob('*') if x.is_file() and x.name!='MANIFEST_SHA256.json' and '__pycache__' not in x.parts}
assert a==m
print('PASS_MANIFEST',len(m))
