import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'],cwd=root,capture_output=True,text=True)
assert p.returncode==0,p.stderr
p=subprocess.run([sys.executable,'-B','code/art_ard_gate.py'],cwd=root,capture_output=True,text=True)
assert p.returncode==0,p.stderr
assert json.loads(p.stdout)==json.loads((root/'outputs'/'READONLY_REPORT.json').read_text())
p=subprocess.run([sys.executable,'-B','code/verify_manifest.py'],cwd=root,capture_output=True,text=True)
assert p.returncode==0,p.stderr
print('PASS_ARTARD_COLD_REPLAY',p.stdout.strip(),'NO_ITEM_WRITE_NO_MAGIC')
