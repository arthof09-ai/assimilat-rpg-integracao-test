import json
from pathlib import Path

def art_gaps(art):
    bom=set(art['bom_text_names'])
    if len(bom)!=len(art['bom_text_names']):raise ValueError('DUPLICATE_BOM')
    steps={x for stage in art['steps'] for x in stage}
    return {
     'named_bom_lines':len(bom),
     'quantities_undefined':sorted(k for k,q in zip(art['bom_text_names'],art['bom_quantities']) if q is None),
     'process_only_structural_parts':sorted(steps-bom),
     'bom_unreferenced_process':sorted(bom-steps),
     'named_canonical_resource_pages_verified':sorted(k for k,v in art['source_lookup'].items() if v.get('status')=='NAMED_CANON_PAGE_VERIFIED'),
     'named_source_only_in_recipe_not_page_proven':sorted(k for k,v in art['source_lookup'].items() if v.get('status')!='NAMED_CANON_PAGE_VERIFIED'),
     'magic_transfer_unverified':True,
     'all_lots_unverified':True,
    }

def material_admission(art,observations=None):
    obs=observations or {}
    if obs.get('autonomous_rank') is not None or obs.get('automatic_rc5') is True:
        return {'admit':False,'reason':'UNAUTHORIZED_CANONIZATION'}
    gaps=art_gaps(art)
    if not art.get('replicability_adjudicated',False):return {'admit':False,'reason':'REPLICABILITY_UNDECIDED','gaps':gaps}
    if gaps['quantities_undefined'] or gaps['process_only_structural_parts']:
        return {'admit':False,'reason':'BOM_UNRESOLVED','gaps':gaps}
    if any(k not in obs.get('lot_receipts',{}) for k in art['bom_text_names']):
        return {'admit':False,'reason':'LOT_RECEIPTS_MISSING','gaps':gaps}
    if obs.get('operator_verified') is not True or obs.get('master_test_authorization') is not True:
        return {'admit':False,'reason':'TEST_AUTHORITY_MISSING','gaps':gaps}
    if obs.get('energy_transfer_observed') is not True:
        return {'admit':False,'reason':'MAGICAL_ENERGY_TRANSFER_UNVERIFIED','gaps':gaps}
    return {'admit':False,'reason':'PHYSICAL_INDEPENDENT_GATE_NOT_IMPLEMENTED_IN_TEST','gaps':gaps}

def aurora_event(armour,observation):
    # Classification of observed evidence ONLY, never mutate the canonical armour.
    if not isinstance(observation,dict): return {'status':'INVALID_OBSERVATION'}
    if any(observation.get(k) is not True for k in ('dawn_witnessed','damage_from_previous_day','damage_small_adjudicated','same_armour_verified','pre_state_documented','post_state_documented')):
        return {'status':'NOT_ADMISSIBLE','reason':'DAWN_DAMAGE_SIZE_CUSTODY_PREPOST'}
    if observation.get('actual_item_restoration_seen') is not True:
        return {'status':'CONTROL_ONLY_NO_EFFECT_OBSERVED'}
    if observation.get('effect_adjudicated_by_master') is not True:
        return {'status':'PENDING_COMPETENT_ADJUDICATION'}
    return {'status':'ELIGIBLE_FOR_HUMAN_REVIEW','no_numeric_repair_claim':True,'no_hp_heal_claim':True,'no_auto_canonization':True}

def report(source):
    a,b=source['art'],source['ard']
    return {'scope':source['scope'],'ART':{'item_url':a['url'],'gaps':art_gaps(a),'preflight':material_admission(a)},'ARD':{'item_url':b['url'],'ca_bonus_preserved':b['defense_ca_bonus'],'movement_penalty_preserved':b['movement_penalty_m'],'repair_rate':None,'repair_event_preflight':aurora_event(b,{})},'gates':'TEST_ONLY_NO_PROTOTYPE_NO_MAGIC_NO_PA_NO_STOCK_NO_PARTY','status':'HOLD_MATERIAL_WITH_FUNCTIONAL_PRECHECK'}

def main():
    s=json.loads((Path(__file__).resolve().parents[1]/'data'/'source_summary.json').read_text())
    print(json.dumps(report(s),indent=2,ensure_ascii=False))
if __name__=='__main__':main()
