# CRAFT ART / ARD Existing-First — TEST (21/10/2026)

Two canonical item pages were read in the Mestre Notion: Artefatos: Amuleto da Noite Estrelada, Armaduras: Acolchoada Aurora. The objective is a **real read-only functional preflight** (not another invented item): identify missing quantities and structural parts in an existing artifact recipe, and refuse false claims of observed armor self-repair. Run `python -B code/run_replay.py`. This package can never grant production, magic, PA, stock, item edits or Party writes.
