import unittest,sys,copy,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'code'))
from art_ard_gate import *
src=json.loads((root/'data'/'source_summary.json').read_text())
class G(unittest.TestCase):
 def test_5_bom(self):self.assertEqual(len(src['art']['bom_text_names']),5)
 def test_5_missing_qty(self):self.assertEqual(len(art_gaps(src['art'])['quantities_undefined']),5)
 def test_2_missing_structure(self):self.assertEqual(set(art_gaps(src['art'])['process_only_structural_parts']),{'medalhao_de_prata','corrente_do_amuleto'})
 def test_no_missing_bom_process(self):self.assertFalse(art_gaps(src['art'])['bom_unreferenced_process'])
 def test_3_sources_found(self):self.assertEqual(len(art_gaps(src['art'])['named_canonical_resource_pages_verified']),3)
 def test_2_sources_undetermined(self):self.assertEqual(len(art_gaps(src['art'])['named_source_only_in_recipe_not_page_proven']),2)
 def test_no_global_absence(self):self.assertTrue(all(src['art']['source_lookup'][k]['status']=='NO_EXACT_NAMED_PAGE_IN_SEARCH' for k in ('coral_de_sussurro','estrela_do_mar_guia')))
 def test_replicability_hold(self):self.assertEqual(material_admission(src['art'])['reason'],'REPLICABILITY_UNDECIDED')
 def test_bom_hold_after_replicability(self):
  a=copy.deepcopy(src['art']);a['replicability_adjudicated']=True;self.assertEqual(material_admission(a)['reason'],'BOM_UNRESOLVED')
 def test_no_autorank(self):self.assertEqual(material_admission(src['art'],{'autonomous_rank':'ON'})['reason'],'UNAUTHORIZED_CANONIZATION')
 def test_no_autorc5(self):self.assertEqual(material_admission(src['art'],{'automatic_rc5':True})['reason'],'UNAUTHORIZED_CANONIZATION')
 def test_can_not_fake_lots_to_bypass(self):
  o={'lot_receipts':{k:'FAKE' for k in src['art']['bom_text_names']},'operator_verified':True,'master_test_authorization':True,'energy_transfer_observed':True}
  self.assertFalse(material_admission(src['art'],o)['admit'])
 def test_canon_title(self):self.assertEqual(src['art']['name'],'Amuleto da Noite Estrelada')
 def test_no_rank_inferred(self):self.assertIsNone(src['art']['rank'])
 def test_no_art_magic_claim(self):self.assertTrue(art_gaps(src['art'])['magic_transfer_unverified'])
 def test_ard_bonus_preserved(self):self.assertEqual(src['ard']['defense_ca_bonus'],8)
 def test_ard_move_preserved(self):self.assertEqual(src['ard']['movement_penalty_m'],5)
 def test_ard_no_repair_rate(self):self.assertIsNone(src['ard']['repair_rate'])
 def test_ard_no_duration(self):self.assertIsNone(src['ard']['repair_duration'])
 def test_ard_no_hp_heal(self):self.assertFalse(src['ard']['target_is_wearer_hp'])
 def test_ard_not_recipe(self):self.assertFalse(src['ard']['effect_is_manufacturing_recipe'])
 def test_no_observation(self):self.assertEqual(aurora_event(src['ard'],{})['status'],'NOT_ADMISSIBLE')
 def test_empty_string_not_true(self):self.assertEqual(aurora_event(src['ard'],{'dawn_witnessed':'true'})['status'],'NOT_ADMISSIBLE')
 def test_one_missing_gate(self):
  o={k:True for k in ('dawn_witnessed','damage_from_previous_day','damage_small_adjudicated','same_armour_verified','pre_state_documented')}
  self.assertEqual(aurora_event(src['ard'],o)['status'],'NOT_ADMISSIBLE')
 def test_control_only(self):
  o={k:True for k in ('dawn_witnessed','damage_from_previous_day','damage_small_adjudicated','same_armour_verified','pre_state_documented','post_state_documented')}
  self.assertEqual(aurora_event(src['ard'],o)['status'],'CONTROL_ONLY_NO_EFFECT_OBSERVED')
 def test_master_adjudication_required(self):
  o={k:True for k in ('dawn_witnessed','damage_from_previous_day','damage_small_adjudicated','same_armour_verified','pre_state_documented','post_state_documented','actual_item_restoration_seen')}
  self.assertEqual(aurora_event(src['ard'],o)['status'],'PENDING_COMPETENT_ADJUDICATION')
 def test_hypothetical_review_only(self):
  o={k:True for k in ('dawn_witnessed','damage_from_previous_day','damage_small_adjudicated','same_armour_verified','pre_state_documented','post_state_documented','actual_item_restoration_seen','effect_adjudicated_by_master')}
  v=aurora_event(src['ard'],o);self.assertEqual(v['status'],'ELIGIBLE_FOR_HUMAN_REVIEW');self.assertTrue(v['no_hp_heal_claim'])
 def test_invalid_data(self):self.assertEqual(aurora_event(src['ard'],'text')['status'],'INVALID_OBSERVATION')
 def test_no_party_write_code(self):self.assertNotIn('notion_update_page',(root/'code'/'art_ard_gate.py').read_text())
 def test_report_hold(self):self.assertEqual(report(src)['status'],'HOLD_MATERIAL_WITH_FUNCTIONAL_PRECHECK')
 def test_all_stocks_false(self):self.assertIs(src['art']['all_stocks_verified'],False)
 def test_output_names(self):self.assertEqual(set(report(src))-{'gates','status','scope'}, {'ART','ARD'})
if __name__=='__main__':unittest.main(verbosity=2)
