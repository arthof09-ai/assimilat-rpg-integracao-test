# Resultado independente: duas famílias (ART + ARD)

## ART — Amuleto da Noite Estrelada existente

**VERIFICADO:** Cinco ingredientes textualizados na própria ficha Artefatos; TODOS SEM quantidade numérica. Passos pedem medalhão de prata e corrente, que **não** são linhas da BOM de ingredientes. 3/5 recursos nomeados possuem ficha Mestre separada reaberta: Safira de Profundez (minério), Opala de Abissal (minério), Musgo de Mana (erva). Buscas dirigidas por Coral de Sussurro e Estrela-do-Mar Guia não identificaram página individual inequívoca; **NÃO** concluir que não existem no mundo. Nenhum recurso nominal é inventário com lote. Musgo de Mana tem função energética, mas sua própria ficha diz que recarga exige método de transferência compatível. O passo sob lua cheia é instrução textual: não prova carregamento.

**CONTRATO NOVO/TEST:** auditor read-only valida BOM⊂processo, identifica 2 estruturas de processo sem BOM e 5 quantidades ausentes; enumera fonte/qualidade/operador/lote/replicabilidade necessários. Recusa fabricar mesmo recebendo lotes fakes. Não cria uma segunda receita ou artigo distinto. Estado HOLD/RC5 PENDENTE, não inferir efeito, PA, rank ou preço.

## ARD — Acolchoada Aurora existente

**VERIFICADO:** +8 CA e perda -5m deslocamento; efeito Renovação Diária repara *pequenos danos sofridos no dia anterior* ao *novo amanhecer*. A ficha não diz a taxa numérica de recuperação, limite de dano pequeno, duração completa de reparo, método de manutenção ou qualificação de operador. O efeito não implica restaurar Vida do usuário, eliminar dano amplo, resetar por turno nem converter automaticamente tempo RS↔Cidade da Glória.

**CONTRATO NOVO/TEST:** recibo de observação exige mesma armadura/custódia, estado anterior e posterior, amanhecer testemunhado, dano de dia anterior e classificado como pequeno por autoridade, observação real e adjudicação humana. Ausência de um componente gera controle/negativa. Mesmo com todos sinalizados num formulário sintético, ferramenta só declara 'elegível para revisão humana'; **não** credita magia nem reparo real.

## Fronteira

REC-MOD-ART-01 e REC-MOD-ARD-01 são padrões de engenharia, não permissão de copiar efeito de uma categoria à outra. As 22 fichas canônicas de índice (7+15) foram lidas para orientar a seleção; apenas estes dois casos tiveram gate detalhado. Sem Party, O Primeiro, fontes canônicas alteradas. Nenhuma instrução de fabricação real autorizada; zero RC5/PA/stock.
