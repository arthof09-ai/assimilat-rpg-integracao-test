# CRAFT — R36/R37 · Priorização do processo e dependência do Óleo (Mestre TEST)

## Escopo e evidência

Depois de R35, a continuação **somente leitura** abriu as três receitas P1_PROCESSO mais urgentes ainda sem perguntas detalhadas no R30: Matriz Espacial (MAT-05), Pasta Invasão Explosiva (BAT-08) e Matriz de Invocação Nível 4 (MAT-01 Ouro Negro, UUID próprio). As três páginas foram consultadas diretamente no Notion em 22/10/2026, com carimbos históricos de 02/10/2026 inalterados. As perguntas do JSON anexo são PROPOSTAS de reconciliação para o Mestre, **nenhuma resposta foi dada**.

## Nove decisões autorais adicionais

### MAT-05 — Matriz Espacial

Fonte física Mestre: https://app.notion.com/p/3edc2b324ede810f8b29cb9f85cc9776

1. BOM `3x Essência de Portal` versus etapa com `Essência de Buraco Negro`.
2. BOM `4x Lírio do Vazio` versus etapa com `Fragmentos de Cometa`.
3. BOM `2x Cinza de Besta Cósmica` versus etapa com `Cinza de Dragão Cósmico`.
4. BOM `1x Óleo de Vedação` e `10x Pedra da Luz OU 10x Pote de Essência Mágica`, sem etapas inequívocas de consumo/energização.

### BAT-08 — Invasão Explosiva

Fonte: https://app.notion.com/p/3edc2b324ede81678729e720e953e776

5. BOM `3x Pó de Basalto Esplosivo` não aparece em etapa própria de consumo.
6. `2x Óleo de Criaturas Infernais` na BOM versus `Óleo de Criatura Infernal` no processo; identidade não comprovada.

### MAT-01 Ouro Negro — Matriz de Invocação Nível 4

Fonte: https://app.notion.com/p/3edc2b324ede81f8a604de666d828b2d

7. BOM `1x chuva de Eclipse Lunar` versus `Pó de Eclipse Lunar` no processo; quantidade e transformação desconhecidas.
8. BOM `4x Teia de Sombra Etérea` versus `Véu de Sombra Etérea` no processo.
9. BOM `1x Óleo de Vedação` e energizador 10x alternativo sem etapas inequívocas. **Não confundir** esta receita com a outra MAT-01 (Prata) UUID `3edc2b324ede81b2b826ef6f6d30dc6c`.

A revisão segue as regras existentes PR-ITEM-02, REC-EXEC, PR-SC, PR-ECO e NAC. Não cria uma autoridade alternativa.

## R37 — Impacto a jusante do Óleo de Vedação

A auditoria **histórica e congelada R15** das 29 receitas registra **29/29 menções** a Óleo de Vedação, mas **somente 28/29 identificam o óleo literalmente na BOM**. A exceção é MAT-03, com menção na localização e o `1x` associado à referência antiga não validada. Esta contagem NÃO demonstra que as 29 receitas consumiram óleo fisicamente, nem que o óleo mestre seja automaticamente o destino de todos os links.

Assim, **qualquer correção autoral futura no Óleo de Vedação** exige reabertura documental dos 29 potenciais dependentes (não fabricação em lote), revisão da quantidade, identidade, BOM↔processo, custos e permissões. A amostragem direta desta execução abrange 6 receitas focalizadas; **os outros 23 não foram todos relidos novamente**. O CSV R15 original foi preservado com hash para auditoria.

## Denominadores corretos após R36

- 29 receitas-filhas no corpus.
- 21 com divergências documentadas; 8 sem divergência lexical identificada, não homologadas.
- 3 receitas tinham perguntas detalhadas R30; **3 adicionais R36**; **15 permanecem sem detalhamento autoral aprofundado**.
- R30: 11 perguntas; R36: 9 perguntas adicionais; **20 perguntas preparadas, 0 decisões autenticadas**.
- R46: 3 nós físicos e 72 campos de relato, 0 laudos independentes comprovados.

## Bloqueios preservados

C19-021 UNKNOWN, fencing técnico IBX-38, REC-LIB/R51, IBX-116 ACK, F5 RED, RC5/P4/PRODUÇÃO HOLD; apenas `fetch/search` no Notion. Nenhuma alteração em receita, item, óleo, estoque, PA, Party ou O Primeiro. **NAC-PASS material não concedido**.
