"""R37 downstream view from the preserved R15 original 29-recipe readback CSV."""
import csv,hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
csv_path=r/'R15_ORIGINAL_READBACK_29_TEST.csv'
rows=list(csv.DictReader(csv_path.open()))
assert len(rows)==29 and len({row['physical_recipe_uuid'] for row in rows})==29
assert sum(x['oil_mentioned']=='YES' for x in rows)==29
assert sum(x['oil_named_in_BOM']=='YES' for x in rows)==28
assert sum(x['oil_named_in_BOM']=='NO' for x in rows)==1
assert next(x for x in rows if x['oil_named_in_BOM']=='NO')['case_key']=='MAT-03'
priority={'P0_RECEITA_P2':0,'P1_REFERENCIA_CONSUMO':1,'P1_PROCESSO':2,'P2_IDENTIDADE':3,'P3_DOCUMENTO':4}
rows.sort(key=lambda x:(priority.get(x['original_docket_priority'],99),x['physical_recipe_uuid']))
scoped={'ENC-08','MAT-03','MAT-06','MAT-05','BAT-08'}
# MAT-01 must use physical UUID for ON variant and not conflate with P
MAT01_ON='3edc2b324ede81f8a604de666d828b2d'
for row in rows: 
 if row['physical_recipe_uuid']==MAT01_ON:scoped.add('MAT-01')
result={'schema':'CRAFT_R37_OIL_DEPENDENCY_VIEW_TEST_V1',
 'classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
 'evidence_kind':'HISTORICAL_R15_READBACK_29_NOT_LIVE_NOT_A_RECIPE_EXECUTION',
 'source_sha256':hashlib.sha256(csv_path.read_bytes()).hexdigest(),
 'source_recipe_denominator':29,
 'oil_mencion_count':29,
 'bom_explicit_name_count':28,
 'broken_reference_candidate_count':1,
 'source_upstream_oil_uuid':'3edc2b324ede81f1a88ec69980ab6cfd',
 'scope':'One historical upstream impact scan, not a claim of actual use, compatible lots, magic transfer or validated source links',
 'scoped_recipes_currently_re_read':6,
 'source_re_read_scope':'R34 focused 3 and R36 new P1 3, unchanged page last edit stamp; not full live 29',
 'potential_dependents':[
  {'case_key':r0['case_key'],'physical_recipe_id':r0['physical_recipe_uuid'],
   'original_priority':r0['original_docket_priority'],
   'dependency_type':'LITERAL_OIL_IN_BOM' if r0['oil_named_in_BOM']=='YES' else 'BROKEN_BOM_LINK_LOCATION_MENTIONS_OIL_UNCONFIRMED',
   'conditional':r0['oil_named_in_BOM']=='NO',
   'source_url':r0['url'],'last_edit_observed_in_R15':r0['live_last_edited'],
   'canonical_edit_performed':False,'oil_material_usage_demonstrated':False,
   'requires_author_and_material_review':True} for r0 in rows],
 'gates':{'author_oil_formula_reconciled':False,'physical_oil_lots_verified':False,'writer_fencing_verified':False,
   'r51_destination_verified':False,'rc5_p4_production_allowed':False,'party_release_allowed':False},
 'creates_duplicate_recipe':False,'writes_canonical':False,'new_ticket_created':False}
p=(r/'CRAFT_R37_OIL_29_POTENTIAL_DEPENDENCIES_TEST.json');p.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('R37 potential oil dependencies 29 = 28 literal BOM + 1 conditional; source SHA',result['source_sha256'])
