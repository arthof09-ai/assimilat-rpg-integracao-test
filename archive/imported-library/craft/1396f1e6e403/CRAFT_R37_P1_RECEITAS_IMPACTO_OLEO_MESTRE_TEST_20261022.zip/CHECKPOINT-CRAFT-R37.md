# CHECKPOINT CRAFT R37 (R35 CODE + R36/R37 DOC READ-ONLY)

**Versão funcional do revisor:** R35, preservado no pacote `CRAFT_R35_CRIACAO_ITENS_RECEITAS_COLETA_MESTRE_TEST_20261022.zip` e Biblioteca Mestre; 1314 JS + 640 Chromium + 2000 fuzz, sem produção.

**Incremento atual:** R36 abriu diretamente Notion Mestre MAT-05, BAT-08, MAT-01 Ouro Negro com metadados 2026-10-02 e criou 9 perguntas P1_PROCESSO (`CRAFT_R36_P1_PROCESSO_3_RECEITAS_MESTRE_TEST.json`), além das 11 R30. R37 reaproveita o CSV original R15 (29 UUIDs únicos, 29 menções de óleo, 28 BOM literais, MAT-03 exceção com link quebrado). Dados estão em `CRAFT_R37_OIL_29_POTENTIAL_DEPENDENCIES_TEST.json`; **somente evidência documental histórica**. Escopo direto revisitado de seis receitas, restantes não conferidas live nesta etapa. O Óleo não foi fabricado, corrigido nem aprovado.

**Denominador:** 29 totais; 21 com divergências; 6 detalhados R30+R36; 15 pendentes de aprofundamento; 8 sem alerta lexical ≠ RC5. 20 perguntas preparadas, 0 respondidas/autenticadas. Três nós R46 continuam sem prova de laboratório.

**Gate antes de qualquer escrita:** IBX38/116/R51 NOVA + ACK, C19-021 UNKNOWN, fencing externo não comprovado, REC-LIB destino físico não demonstrado, F5 RED, Notion sem update, RC5/P4/PRODUÇÃO HOLD. Party/O Primeiro NO WRITE.

**Retomar:** ler este checkpoint, R35 checkpoint anterior, JSON R36 e R37; revalidar ACK e autorizações. Depois ler os próximos P2_IDENTIDADE do dossiê R27 — sem inventar material, rank, custo ou efeito — enquanto aguarda decisão autenticada do Mestre ou medições genuínas R46. Preservar as duas variantes físicas MAT-01, os 29 UUIDs, o óleo original e o histórico. NÃO inventar novos tickets ou páginas. Publicar no Notion somente quando writer/gates estiverem efetivamente disponíveis; hoje a atualização documental R14–R37 não está sincronizada.
