'use strict';const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'R27_ORIGINAL_DOCKET_SNAPSHOT_TEST.json')));
const x=JSON.parse(fs.readFileSync(path.join(__dirname,'CRAFT_R36_P1_PROCESSO_3_RECEITAS_MESTRE_TEST.json')));
let n=0;const ok=(v,l)=>{assert.ok(v,l);n++};const cases=new Map(d.issues.map(y=>[y.physical_recipe_id,y]));
ok(x.cases.length===3,'3 recipes');ok(x.denominators.child_recipes===29,'29');ok(x.denominators.lexical_issue_cases===21,'21');ok(x.denominators.remaining_not_detailed_recipes===15,'15');ok(x.denominators.R36_process_questions===9,'9 slots');
for(const c of x.cases){const r=cases.get(c.physical_recipe_id);ok(!!r,c.key);ok(c.key===r.pattern_key,'original identity');ok(c.priority===r.priority,'original priority');ok(c.source_url===r.source_url,'source');ok(c.last_edited_utc.startsWith('2026-10-02'),'source timestamp');ok(c.decisions.length>=2,'issues');for(const q of c.decisions){ok(q.decision===null,'no authorship');ok(q.bom_literal.length>5&&q.process_literal.length>5,'literals');ok(q.question.length>30,'meaningful question')}}
ok(x.cases.find(y=>y.key==='MAT-01').disambiguation.includes('3edc2b324ede81b2b826ef6f6d30dc6c'),'distinct P');ok(x.cross_deps.oil_formula_still_conflicted,'oil hold');for(const [k,v] of Object.entries(x.gates))ok(v===false,'gate false '+k);ok(x.canonical_mutations===0&&!x.creates_ticket&&!x.creates_recipe,'no edits');
console.log('R36 additional P1_PROCESSO questions '+n+'/'+n+' PASS');
