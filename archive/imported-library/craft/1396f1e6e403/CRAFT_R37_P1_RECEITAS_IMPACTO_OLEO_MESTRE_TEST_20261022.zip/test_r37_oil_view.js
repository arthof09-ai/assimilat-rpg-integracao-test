'use strict';const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const root=__dirname;
const x=JSON.parse(fs.readFileSync(path.join(root,'CRAFT_R37_OIL_29_POTENTIAL_DEPENDENCIES_TEST.json')));
const y=JSON.parse(fs.readFileSync(path.join(root,'CRAFT_R36_P1_PROCESSO_3_RECEITAS_MESTRE_TEST.json')));
let n=0;const ok=(v,l)=>{assert.ok(v,l);n++};
ok(x.potential_dependents.length===29,'29');ok(new Set(x.potential_dependents.map(e=>e.physical_recipe_id)).size===29,'UUID unique');ok(x.bom_explicit_name_count===28,'28');ok(x.broken_reference_candidate_count===1,'one');
ok(x.potential_dependents.filter(x=>x.conditional).length===1,'conditional');ok(x.potential_dependents.find(r=>r.case_key==='MAT-03').conditional,'MAT03');
ok(y.cross_deps.oil_downstream_cases.length===3,'3 new P1 includes BAT08');for(const c of y.cases){ok(x.potential_dependents.some(r=>r.physical_recipe_id===c.physical_recipe_id),'source exists '+c.key);}
ok(x.potential_dependents.filter(r=>r.case_key.startsWith('MAT-01-')).length===2,'two MAT01 distinct');ok(x.potential_dependents.some(r=>r.physical_recipe_id==='3edc2b324ede81f8a604de666d828b2d'),'ON variant');ok(x.potential_dependents.some(r=>r.physical_recipe_id==='3edc2b324ede81b2b826ef6f6d30dc6c'),'P variant');
for(const r of x.potential_dependents){ok(r.source_url==='https://app.notion.com/p/'+r.physical_recipe_id,'source');ok(!r.oil_material_usage_demonstrated,'no usage approval');ok(!r.canonical_edit_performed,'no edit');}
for(const [key,val] of Object.entries(x.gates))ok(val===false,'gate false '+key);ok(!x.writes_canonical&&!x.new_ticket_created,'none');
console.log('R37 upstream oil 29-link audit '+n+'/'+n+' PASS');
