"""CRAFT existing-LAB H2-VB01 protocol compiler.
Pure *admission* logic, NOT an inscription engine, creator, magical adjudicator,
PA calculator, R48 executor, or attestation issuer.
"""
from __future__ import annotations
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASELINE_SHA='dec8d8c6a5a7624428f540b7a4ac96cec00c605303f3303e1ffb0b63426a4a8a'
CASE='LAB-CRAFT-VIGILIA-BOREAL-20261020-001'
P2_KEY='H2-3-P2-PERGAMINHO-ISOLADO'
CANONICAL_P2='https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8'

def readjson(path):
    return json.loads((ROOT/path).read_text(encoding='utf8'))

def recipe_reconcile(p2=None,oil=None):
    p2=p2 if p2 is not None else readjson('inputs/P2_CANONICAL_BOM_PROCESS.json')
    oil=oil if oil is not None else readjson('inputs/OIL_REFERENCE.json')
    bom={i['id']:i for i in p2['recipe_items']}
    steps={i for s in p2['process_steps'] for i in s['uses']}
    unconsumed=sorted(set(bom)-steps)
    undeclared=sorted(steps-set(bom))
    required=set(bom)
    # Existing recognized difference by exact IDs; no alias guess.
    issues=[]
    if 'sal_geodo_santo' in unconsumed and 'sal_geodo_encantado' in undeclared:
        issues.append({'id':'P2-SALT-01','type':'IDENTITY','severity':'STOP','bom':'sal_geodo_santo','process':'sal_geodo_encantado','source':CANONICAL_P2,'possible_min_fix':'AUTHORITY_CHOOSES_SALT_IDENTITY_AND_VERSION','auto_corrected':False})
    if 'energy_choice' in unconsumed:
        issues.append({'id':'P2-ENERGY-02','type':'PROCESS_MISSING','severity':'STOP','bom':'energy_choice_2_EXCLUSIVE','process':None,'source':CANONICAL_P2,'possible_min_fix':'AUTHORITY_ADDS_EXPLICIT_ENERGIZATION_STEP_WITH_CHOICE_CONDITIONS','auto_corrected':False})
    if oil['declared_drops']!=oil['process_drops']:
        issues.append({'id':'OIL-DROPS-03','type':'SUPPLIER_IDENTITY','severity':'STOP_IF_OIL_MUST_BE_CRAFTED','bom':oil['declared_drops'],'process':oil['process_drops'],'source':oil['source'],'possible_min_fix':'SOURCE_AUTHORITY_RECONCILES_OR_SUPPLIES_VERIFIED_FINISHED_OIL','auto_corrected':False})
    if oil['declared_essence']!=oil['process_essence'] or oil['truncated_step_2']:
        issues.append({'id':'OIL-ESSENCE-04','type':'SUPPLIER_INCOMPLETE','severity':'STOP_IF_OIL_MUST_BE_CRAFTED','bom':oil['declared_essence'],'process':oil['process_essence'],'step2_truncated':oil['truncated_step_2'],'source':oil['source'],'possible_min_fix':'SOURCE_AUTHORITY_RECONCILES_OR_SUPPLIES_VERIFIED_FINISHED_OIL','auto_corrected':False})
    if oil.get('declared_iron_qty_current')!=oil.get('declared_iron_qty_legacy') and oil.get('process_iron_step_explicit') is False:
        issues.append({'id':'OIL-IRON-05','type':'SUPPLIER_VERSION_AND_STEP','severity':'STOP_IF_OIL_MUST_BE_CRAFTED',
                       'bom':oil['declared_iron_qty_current'],'historical_bom':oil['declared_iron_qty_legacy'],
                       'process':None,'source':oil['source'],'possible_min_fix':'OIL_AUTHORITY_DECIDES_VERSION_AND_IRON_STEP','auto_corrected':False})
    # Historical O variant is independent source, not an alias authority.
    return {'issues':issues,'new_flags_count':len(issues),'P2_declared_lines':len(bom),'P2_process_steps':len(p2['process_steps']),
            'unconsumed_bom_ids':unconsumed,'undeclared_process_ids':undeclared,
            'historical_gold_variant_is_errata':False,'verified_alias_equivalence':False,
            'updated_canonical_recipe':False,'P2_recipe_ready':False}

def dependency_dag():
    # Exactly one existing case, node stages are gates rather than new factories.
    nodes={
       'DOC_SUBSTRATE_PERGAMINHO':{'needs':[],'evidence':'P2_STEP_6','stage':'DOCUMENTED'},
       'P2_SALT_RECONCILED':{'needs':[],'evidence':None,'stage':'PENDING_AUTHORITY'},
       'P2_ENERGIZATION_RECONCILED':{'needs':[],'evidence':None,'stage':'PENDING_AUTHORITY'},
       'FINISHED_OIL_VERIFIED':{'needs':[],'evidence':None,'stage':'PENDING_STOCK_OR_SUPPLIER'},
       'P2_LOTS_AUTHORIZED':{'needs':[],'evidence':None,'stage':'PENDING_IN_GAME_TEST'},
       'OPERATOR_COMPETENCE':{'needs':[],'evidence':None,'stage':'PENDING_IN_GAME_TEST'},
       'P2_ENERGY_SOURCE_AUTH':{'needs':['P2_ENERGIZATION_RECONCILED','P2_LOTS_AUTHORIZED'],'evidence':None,'stage':'PENDING_IN_GAME_TEST'},
       'H2_3_INSTALLATION':{'needs':['DOC_SUBSTRATE_PERGAMINHO','P2_SALT_RECONCILED','P2_ENERGIZATION_RECONCILED','FINISHED_OIL_VERIFIED','P2_LOTS_AUTHORIZED','OPERATOR_COMPETENCE','P2_ENERGY_SOURCE_AUTH'],'evidence':None,'stage':'HOLD'},
       'H2_3_STABILIZATION':{'needs':['H2_3_INSTALLATION','OBSERVABLE_TARGET','AUTHORIZED_ADJUDICATION'],'evidence':None,'stage':'HOLD'},
       'OBSERVABLE_TARGET':{'needs':[],'evidence':None,'stage':'PENDING_IN_GAME_TEST'},
       'AUTHORIZED_ADJUDICATION':{'needs':[],'evidence':None,'stage':'PENDING_IN_GAME_TEST'},
       'PINGENTE_SUBSTRATE_COMPAT':{'needs':[],'evidence':None,'stage':'PENDING_MATERIAL'},
       'PINGENTE_EFFECT_PATTERN':{'needs':[],'evidence':None,'stage':'PENDING_FORMULA'},
       'H2_4_INSTALLATION':{'needs':['H2_3_STABILIZATION','PINGENTE_SUBSTRATE_COMPAT','PINGENTE_EFFECT_PATTERN'],'evidence':None,'stage':'HOLD'},
       'H2_5_REMOVAL_CONTRAST':{'needs':['H2_4_INSTALLATION','H2_3_STABILIZATION','REVERSIBLE_REMOVAL_PROOF'],'evidence':None,'stage':'HOLD'},
       'REVERSIBLE_REMOVAL_PROOF':{'needs':[],'evidence':None,'stage':'PENDING_MATERIAL'},
    }
    assert len(nodes)==len(set(nodes))
    for k,v in nodes.items():
        for dep in v['needs']:
            if dep not in nodes: raise ValueError((k,dep))
    return nodes

def process_preflight(candidate=None):
    """Never accepts a caller's magic_success/verified flag as proof.

    The only authority assertions available in this offline LAB snapshot are fixed
    to NOT_OBSERVED; a later real LAB/Mestre event must be evaluated by the proper
    authority outside this function, not by setting booleans here.
    """
    c=candidate or {}
    if c.get('case') not in (None,CASE) or c.get('h2_control') not in (None,'H2-3'):
        return {'allowed':False,'gate':'WRONG_CASE_OR_CONTROL','installed':False,'item_integrated':False}
    if c.get('substrate') not in (None,'PERGAMINHO'):
        return {'allowed':False,'gate':'P2_SUBSTRATE_NOT_CANONICALLY_ADMITTED','installed':False,'item_integrated':False}
    defects=recipe_reconcile()['issues']
    return {'allowed':False,'gate':'HOLD_RECIPE_SOURCE_CONFLICTS' if defects else 'HOLD_MISSING_LOTS_OPERATOR_AUTHORITY',
            'defects':[i['id'] for i in defects], 'surface':'PERGAMINHO','source_type_documented':True,
            'finished_oil_is_confirmed':False,'operator_is_confirmed':False,'energy_step_resolved':False,
            'new_event_created':False,'installed':False,'source_stabilized':None,'item_integrated':False,
            'r46_evidence':None,'r47_attestation':None,'r48_order':None}

def reason_about_residual(inputs):
    """Causal guard for H2-5; even observed residue cannot single-handedly prove transfer."""
    if not inputs.get('h2_4_actually_adjudicated'):
        return 'HOLD_H2_4_NOT_EXECUTED'
    if not inputs.get('source_removed_under_valid_rule'):
        return 'HOLD_REMOVAL_NOT_DEMONSTRATED'
    if not inputs.get('h2_3_inscription_only_control'):
        return 'INDETERMINATE_INSCRIPTION_OWN_ENERGY_CONFOUNDER'
    if not inputs.get('effect_specific_pattern_authorized'):
        return 'INDETERMINATE_PATTERN_NO_AUTHORITY'
    if not inputs.get('authorized_causal_comparison'):
        return 'INDETERMINATE_ADJUDICATION_NOT_DOCUMENTED'
    return 'ELIGIBLE_FOR_INDEPENDENT_REVIEW_NOT_AUTOMATIC_ITEM_INTEGRATED'

def classify_inscriptions():
    return {
      'Vedacao_P2':{'category':'COMPARADOR_ESTABILIZACAO','item_effect':'CONTENCAO_ELEMENTO_MAGICO','own_luminosity':False,'support_ready':False},
      'Sombras_Enganosas_O':{'category':'COMPARADOR_INSTALACAO_ITEM','item_effect':'CAMUFLAGEM_QUASE_INVISIBILIDADE','own_luminosity':False,'supports_contrassombra':False},
      'Reflexo_Profundezas_P':{'category':'COMPARADOR_INSTALACAO_ITEM','item_effect':'REFLEXAO_RESPIRAR_SUBMERSO','own_luminosity':False},
      'Aurora_Rompe_Correntes_L':{'category':'COMPARADOR_INSTALACAO_EM_ACESSORIO','item_effect':'REAÇÃO_CONTRA_CONTROLE_MENTAL','own_luminosity':False,'installed_per_source':True},
      'Eclipse_Astral_L':{'category':'INCOMPATIVEL_PADRAO_ALVO','item_effect':'ECLIPSE_TATICO_AREA','own_luminosity':False,'is_battle_inscription':True},
      'Luz_de_Aurora_recurso':{'category':'FONTE_POTENCIAL_SEM_FORMULA','item_effect':None,'own_luminosity':None,'usable_as_p2':False},
    }

def energy_states():
    # R39/R34/R27/R26 original: returned null for H1; no new calculation.
    return {'H1_INTRINSIC':{'pa_daily':None,'pa_use':None,'pa_install':None,'pa_maint':None,'status':'PA_R39_PARTIAL_NO_RULE'},
            'H2_STABILIZATION':{'pa_daily':None,'pa_use':None,'pa_install':None,'pa_maint':None,'status':'INSCRIPTION_NOT_INSTALLED'},
            'H2_INTEGRATION':{'pa_daily':None,'pa_use':None,'pa_install':None,'pa_maint':None,'status':'NEW_EFFECT_NOT_PROVEN',
                'historical_e3_budget_conditional':{'daily':12,'per_use':7,'two_use_scenario_total':26}},
            'request':'CRAFT-PA-QUERY-POS-E50-20261020-001','owner_reply_seen':False,
            'null_is_zero':False}

def generate():
    out={'case':CASE,'trace':'CRAFT-H2P2-ENG-20261020','scope':'EXISTING_LAB_TEST',
         'canonical_sources_not_modified':True,'source_reconciliation':recipe_reconcile(),
         'stage_dependencies':dependency_dag(),'h2_3':process_preflight(),
         'h2_4':'HOLD_SUBSTRATE_AND_EFFECT_PATTERN','h2_5':'HOLD_H2_4_FIRST',
         'inscription_mechanisms':classify_inscriptions(),'pa':energy_states(),
         'r48_readonly_sequence_expected':1,'r48_reexecution':False,
         'magic_installations':0,'magic_witnesses':0,'new_official_recipes':0,
         'item_integrated':False,'source_stabilized':False,'H1_PREVIOUS_TEST_QUALITATIVE':'PASS_E50_NO_REPEAT'}
    return out

if __name__=='__main__':
    (ROOT/'outputs'/'GATES_H2P2_NEW.json').write_text(json.dumps(generate(),indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
    print('PRECHECK_COMPLETE_NOT_MAGIC',len(recipe_reconcile()['issues']), 'BLOCKING_ISSUES')
