"""Parametric nonbinding *structural layout* acceptance constraints.
No fictional measurements can turn this into a physical QA certificate.
Units must be supplied from actual measurement, otherwise UNKNOWN.
"""
from __future__ import annotations

REQUIRED=('crystal_envelope_mm','herb_envelope_mm','crystal_aperture_mm','herb_aperture_mm','strap_length_mm','strap_required_mm','substrate_trace_area_mm2','pattern_required_area_mm2')

def validate_geometry(measurements, provenance=None):
    if not measurements or any(k not in measurements or measurements[k] is None for k in REQUIRED):
        return {'state':'NEEDS_MEASUREMENTS','physical_verified':False,'material_fabricated':False,
                'missing':[k for k in REQUIRED if k not in (measurements or {}) or measurements[k] is None]}
    if any(type(measurements[k]) not in (int,float) or measurements[k]<=0 for k in REQUIRED):
        return {'state':'INVALID_MEASUREMENT_INPUT','physical_verified':False,'material_fabricated':False}
    geom={
      'crystal_unobstructed':measurements['crystal_aperture_mm']>=measurements['crystal_envelope_mm'],
      'herb_unobstructed':measurements['herb_aperture_mm']>=measurements['herb_envelope_mm'],
      'strap_sufficient':measurements['strap_length_mm']>=measurements['strap_required_mm'],
      'pattern_area_sufficient':measurements['substrate_trace_area_mm2']>=measurements['pattern_required_area_mm2'],
    }
    return {'state':'SCHEMATIC_CONSTRAINTS_PASS' if all(geom.values()) else 'SCHEMATIC_CONSTRAINTS_FAIL',
            'checks':geom,'physical_verified':False,'material_fabricated':False,
            'evidence':'ILLUSTRATIVE_ONLY' if provenance!='VERIFIED_FIELD_MEASUREMENT' else 'MEASUREMENT_REQUIRES_EXTERNAL_INDEPENDENT_QA',
            'eligible_for_physical_review':all(geom.values()) and provenance=='VERIFIED_FIELD_MEASUREMENT'}
