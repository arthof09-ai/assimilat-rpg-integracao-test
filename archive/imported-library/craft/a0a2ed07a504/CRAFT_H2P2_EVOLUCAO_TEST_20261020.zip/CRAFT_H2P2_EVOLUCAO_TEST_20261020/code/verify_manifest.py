from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[1]
m=json.loads((r/'MANIFEST.json').read_text(encoding='utf8'))
assert m['baseline_zip_sha256']=='dec8d8c6a5a7624428f540b7a4ac96cec00c605303f3303e1ffb0b63426a4a8a'
for rel,h in m['files_sha256'].items():
    p=(r/rel).resolve()
    assert p.is_relative_to(r.resolve()) and p.is_file(),rel
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h,rel
print('PASS_MANIFEST',len(m['files_sha256']))
