"""Self-contained cold replay; execution from extracted ZIP with system Python."""
from pathlib import Path
import hashlib,zipfile,sys,subprocess,json,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'baselines'/'CRAFT_POS_E50_H2_MATERIAL_PA_20261020.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='dec8d8c6a5a7624428f540b7a4ac96cec00c605303f3303e1ffb0b63426a4a8a'
with zipfile.ZipFile(old) as z:
    assert z.testzip() is None
    with tempfile.TemporaryDirectory(prefix='craft_h2p2_baseline_') as scratch:
        z.extractall(scratch)
        base=Path(scratch)/'CRAFT_POS_E50_H2_MATERIAL_PA_20261020'
        b=subprocess.run([sys.executable,str(base/'RUN_REPLAY.py')],text=True,capture_output=True)
        assert b.returncode==0,(b.stdout,b.stderr)
        print('BASELINE_E50_REPLAY_25_25_PRESERVED',b.stdout[-400:].replace('\n',' '))
new=subprocess.run([sys.executable,str(ROOT/'code'/'h2_protocol.py')],text=True,capture_output=True)
assert new.returncode==0,(new.stdout,new.stderr)
newtest=subprocess.run([sys.executable,str(ROOT/'tests'/'test_new_delta.py')],text=True,capture_output=True)
assert newtest.returncode==0,(newtest.stdout,newtest.stderr)
print('NEW_DELTA_TESTS', [l for l in newtest.stderr.splitlines() if l.startswith('Ran ')][-1], newtest.stderr.strip().splitlines()[-1]);print('RECIPE',new.stdout.strip())
# R48 frozen transaction lives INSIDE immutable old baseline ZIP, and old baseline
# RUN_REPLAY verifies the commit chain. No call to R48 factory or writer here.
result=json.loads((ROOT/'outputs'/'GATES_H2P2_NEW.json').read_text())
assert result['r48_reexecution'] is False
assert result['magic_installations']==0 and result['new_official_recipes']==0
print('PASS_H2P2_CRAFT_REPLAY_NO_R48_WRITE_NO_MAGIC_PROOF')
