from pathlib import Path
import sys,unittest,copy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
import h2_protocol as p
import mount_geometry as m

class TestH2NewDelta(unittest.TestCase):
 def test_01_same_case(self): self.assertIn('20261020-001',p.CASE)
 def test_02_p2_seven_declarations(self): self.assertEqual(p.recipe_reconcile()['P2_declared_lines'],7)
 def test_03_p2_six_steps(self): self.assertEqual(p.recipe_reconcile()['P2_process_steps'],6)
 def test_04_p2_salt_stop(self): self.assertIn('P2-SALT-01',[x['id'] for x in p.recipe_reconcile()['issues']])
 def test_05_p2_energy_stop(self): self.assertIn('P2-ENERGY-02',[x['id'] for x in p.recipe_reconcile()['issues']])
 def test_06_oil_drops_stop(self): self.assertIn('OIL-DROPS-03',[x['id'] for x in p.recipe_reconcile()['issues']])
 def test_07_oil_essence_stop(self): self.assertIn('OIL-ESSENCE-04',[x['id'] for x in p.recipe_reconcile()['issues']])
 def test_08_no_auto_alias(self): self.assertFalse(p.recipe_reconcile()['verified_alias_equivalence'])
 def test_09_o_variant_not_errata(self): self.assertFalse(p.recipe_reconcile()['historical_gold_variant_is_errata'])
 def test_10_no_auto_patch(self): self.assertFalse(p.recipe_reconcile()['updated_canonical_recipe'])
 def test_11_step_energy_unmatched(self): self.assertIn('energy_choice',p.recipe_reconcile()['unconsumed_bom_ids'])
 def test_12_wrong_case_holds(self): self.assertEqual(p.process_preflight({'case':'OTHER'})['gate'],'WRONG_CASE_OR_CONTROL')
 def test_13_wrong_target_holds(self): self.assertEqual(p.process_preflight({'substrate':'FIBRA'})['gate'],'P2_SUBSTRATE_NOT_CANONICALLY_ADMITTED')
 def test_14_p2_surface_only(self): self.assertTrue(p.process_preflight()['source_type_documented'])
 def test_15_p2_not_installed(self): self.assertFalse(p.process_preflight()['installed'])
 def test_16_fake_magic_bool_no_effect(self): self.assertFalse(p.process_preflight({'magic_success':True,'observed':True,'signed':True})['installed'])
 def test_17_fake_witness_no_effect(self): self.assertIsNone(p.process_preflight({'witness':'MASTER_SIGNED_SYNTHETIC'})['r47_attestation'])
 def test_18_no_r48_order(self): self.assertIsNone(p.process_preflight()['r48_order'])
 def test_19_dag_complete(self): self.assertEqual(len(p.dependency_dag()),16)
 def test_20_dependency_h2_4(self): self.assertIn('PINGENTE_EFFECT_PATTERN',p.dependency_dag()['H2_4_INSTALLATION']['needs'])
 def test_21_h2_5_needs_h2_4(self): self.assertIn('H2_4_INSTALLATION',p.dependency_dag()['H2_5_REMOVAL_CONTRAST']['needs'])
 def test_22_removal_without_h2_4(self): self.assertEqual(p.reason_about_residual({'effect_remains':True}),'HOLD_H2_4_NOT_EXECUTED')
 def test_23_residual_with_no_baseline(self): self.assertEqual(p.reason_about_residual({'h2_4_actually_adjudicated':True,'source_removed_under_valid_rule':True,'effect_remains':True}),'INDETERMINATE_INSCRIPTION_OWN_ENERGY_CONFOUNDER')
 def test_24_residual_with_no_pattern(self): self.assertEqual(p.reason_about_residual({'h2_4_actually_adjudicated':True,'source_removed_under_valid_rule':True,'h2_3_inscription_only_control':True,'effect_remains':True}),'INDETERMINATE_PATTERN_NO_AUTHORITY')
 def test_25_all_inputs_still_review_only(self): self.assertEqual(p.reason_about_residual(dict.fromkeys(['h2_4_actually_adjudicated','source_removed_under_valid_rule','h2_3_inscription_only_control','effect_specific_pattern_authorized','authorized_causal_comparison'],True)),'ELIGIBLE_FOR_INDEPENDENT_REVIEW_NOT_AUTOMATIC_ITEM_INTEGRATED')
 def test_26_sombras_not_contrassombra(self): self.assertFalse(p.classify_inscriptions()['Sombras_Enganosas_O']['supports_contrassombra'])
 def test_27_aurora_not_lum(self): self.assertFalse(p.classify_inscriptions()['Aurora_Rompe_Correntes_L']['own_luminosity'])
 def test_28_oil_supplier_not_magic(self): self.assertFalse(p.generate()['source_stabilized'])
 def test_29_null_not_zero(self): self.assertIsNone(p.energy_states()['H1_INTRINSIC']['pa_daily'])
 def test_30_hold_pa_historical_separate(self): self.assertEqual(p.energy_states()['H2_INTEGRATION']['historical_e3_budget_conditional']['daily'],12)
 def test_31_geom_requires_all_real_inputs(self): self.assertEqual(m.validate_geometry(None)['state'],'NEEDS_MEASUREMENTS')
 def test_32_invalid_geometry(self): self.assertEqual(m.validate_geometry({i:-1 for i in m.REQUIRED})['state'],'INVALID_MEASUREMENT_INPUT')
 def test_33_synthetic_fit_pass_not_physical(self):
  d={i:10 for i in m.REQUIRED};r=m.validate_geometry(d);self.assertEqual(r['state'],'SCHEMATIC_CONSTRAINTS_PASS');self.assertFalse(r['physical_verified'])
 def test_34_synthetic_fit_fail(self):
  d={i:10 for i in m.REQUIRED};d['strap_length_mm']=1;self.assertEqual(m.validate_geometry(d)['state'],'SCHEMATIC_CONSTRAINTS_FAIL')
 def test_35_source_stabilized_not_item(self): self.assertFalse(p.generate()['item_integrated'])
 def test_36_no_new_magic_event(self): self.assertEqual(p.generate()['magic_installations'],0)
 def test_37_no_new_rec(self): self.assertEqual(p.generate()['new_official_recipes'],0)
 def test_38_no_h1_repeat(self): self.assertEqual(p.generate()['H1_PREVIOUS_TEST_QUALITATIVE'],'PASS_E50_NO_REPEAT')
 def test_39_no_extra_baseline_change(self): self.assertEqual(p.BASELINE_SHA,'dec8d8c6a5a7624428f540b7a4ac96cec00c605303f3303e1ffb0b63426a4a8a')
 def test_41_new_oil_iron_gap(self): self.assertIn('OIL-IRON-05',[x['id'] for x in p.recipe_reconcile()['issues']])
 def test_42_current_oil_qty(self): self.assertEqual(p.readjson('inputs/OIL_REFERENCE.json')['declared_iron_qty_current'],3)
 def test_43_legacy_qty_not_errata(self): self.assertEqual(p.readjson('inputs/OIL_REFERENCE.json')['declared_iron_qty_legacy'],2)
 def test_40_snapshot_citation(self): self.assertTrue(p.CANONICAL_P2.startswith('https://app.notion.com/p/'))

if __name__=='__main__':
 unittest.main(verbosity=1)
