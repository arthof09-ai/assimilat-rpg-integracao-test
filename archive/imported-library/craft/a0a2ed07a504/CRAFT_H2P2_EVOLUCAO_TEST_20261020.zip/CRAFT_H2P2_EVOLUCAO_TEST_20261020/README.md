# CRAFT · H2-VB01 · continuidade pós-E50+ · 20/10/2026

## Resultado novo

**De um preflight estático P2 para um protocolo de bancada COMPILADO:** 15 campos de ensaio H2-3 em pergaminho, 16 dependências rastreáveis, 5 issues de origem e opções de redução de dependência do Óleo de Vedação, geometria paramétrica reversível e controle causal de efeito residual. Tudo dentro do mesmo Pingente v1.3 / caso LAB único, sem motor mágico/PA/R48 novo.

**Não foi executada inscrição P2; nenhum efeito mágico novo, PA debitado, material físico ou R48 novo**. Um efeito próprio de item permanece não demonstrado. A simulação de fonte com valores hipotéticos não substitui prova mecânica válida do mundo do RPG.

## Replay (executável após extrair este ZIP em pasta limpa)

```sh
python code/run_replay.py
python code/verify_manifest.py
```

**Baseline:** `/Comestre/CRAFT_POS_E50_H2_MATERIAL_PA_20261020.zip`, SHA256 `dec8d8c6a5a7624428f540b7a4ac96cec00c605303f3303e1ffb0b63426a4a8a` autenticado, embutido sob `baselines/`. O replay anterior foi reexecutado com seus 25 testes próprios, separadamente dos 43 novos.

**Artefato técnico principal:** `docs/PROTOCOLO_H2_3_EXECUTAVEL_CONDICIONAL.md` (não confundir 'executável' com 'executado'). A matriz de reconciliação deixa visíveis nomes divergentes, a etapa de energização ausente e a quantidade discrepante do ferro no óleo histórico.

**Estados:** H1 PASS histórico E50, H2-3 instalação HOLD, H2-4/5 HOLD, SOURCE_STABILIZED=0, ITEM_INTEGRATED=0, PA_H1=NULL/PENDENTE, R48 frozen seq1, F5 RED/C19-021 UNKNOWN-EFFECT, RC5/P4/PROD HOLD, Party/O Primeiro NO-WRITE.

Sem novo REC-ID, OP, Inbox, nova receita oficial, reserva de E51, writer/lease/epoch/fencing ou falsa autenticação R46/R47.
