# H2-3 — Procedimento de execução condicional da Vedação P2 em pergaminho

**Importante:** este protocolo está pronto para ser usado como **roteiro de cena** quando as autoridades e recursos estiverem disponíveis. **NÃO FOI EXECUTADO COMO ENCANTAMENTO**. O preflight original do ciclo anterior (25/25) foi PRESERVADO, não substituído. O compilador novo discrimina as dependências, sem emular magia.

**Identidade de evento futuro, reservável apenas no momento da aplicação legítima:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001` + tipo `H2-3-P2-PERGAMINHO-ISOLADO`. Não reusar `SBX-R48-ORDER-48322`, nem criar recibo R48 antecipadamente. H2-1 e H2-2 são controles **históricos E50**, não reexecutar.

| Campo obrigatório | Estado preflight e condição de execução |
|---|---|
| 1. Substrato | **Pergaminho** — P2, etapa 6, admite explicitamente a categoria; exemplar/lote permanece PENDENTE. |
| 2. Inscrição | **Inscrição de Vedação Prata**, não Selamento nem padrão novo; página de efeito P2. |
| 3. Ingredientes | P2 tem 7 linhas (argila 3, água 1, sal 2, ferro meteorítico 3, essência barreira 1, óleo 1, energizador 2 de UMA alternativa). Detalhes na planilha JSON sem adicionar unidades de massa/volume. |
| 4. Quantidades | Quantidades textuais 3/1/2/3/1/1/2 e opção XOR de energia; **unidade física específica não prescrita**. |
| 5. Proveniência | Notion Mestre páginas P2/efeito/Óleo com versões. Lotes TEST, origem de cada insumo e cadeia de custódia PENDENTES. |
| 6. Processo ordenado | Seis etapas originais preservadas na P2. Sal e energia bloqueiam compilação para ato; proposta de inserção depende de errata P2. |
| 7. Energização | Duas Pedras da Luz OU dois Potes de Essência Mágica como **item da BOM**, método/etapa de energização NÃO DOCUMENTADOS. PA da energia/inscrição ≠ custo de item v1.3. |
| 8. Aplicação | Aplicar pasta ao pergaminho ou objeto segundo P2; ambiente de instalação e geometria do símbolo ainda sem registro operacional suficiente. |
| 9. Operador | Pessoa/NPC de competência em inscrição, conhecimento da fórmula, ferramentas e autorização em TEST **não identificados**; não inventar mestre inscricionista. |
| 10. Observação | Comparar pergaminho antes/depois, um **alvo mágico legitimamente disponível** ou entidade quando permitido, e controle de ausência de inscrição. Alvo não é o Pingente. |
| 11. Sucesso | Manifestação efetiva de **contenção/estabilização da P2**, com regra/decisão e observador competente; não é Luminescência/Contrassombra. |
| 12. Controles negativos | Pergaminho sem pasta, mistura sem energização quando seguro/permitido, eventual P2 sem fonte-alvo; resultados não devem ser pré-programados. |
| 13. Falha | Inscrição incompleta, alvo não compatível, falta PA/energia, inscrição incapaz de estabilizar, ruptura da pasta; apenas categorias — **sem probabilidades inventadas**. |
| 14. Limites | Sem raio/duração/PA extrapolados, sem material real, sem dano/desgaste/tempo adjudicados, sem transferência do efeito da erva/cristal. |
| 15. Reversão/segurança/registro | Lote e identidade, recibo ANTES, evento de tentativa, decisão e resultado, consumo de energia APENAS se ocorreu, readback, tipo H2-3, rollback de estado de TEST se suportado. Nenhum R46/R47 falso. |

## Máquina de estados do protocolo (prévia, não motor mágico)

`DOCUMENT_SOURCE` → `RECONCILE_P2_SALT` → `RECONCILE_P2_ENERGY` → `VERIFY_FINISHED_OIL_OR_SUPPLIER` → `VERIFY_LOTS` → `VERIFY_OPERATOR` → `VERIFY_TEST_AUTHORITY` → `APPLY_P2` → `OBSERVE_P2_EFFECT` → `CAUSAL_CONTRAST`.

O executor só alcança `APPLY_P2` após todas as condições anteriores com fontes, e **só registra `SOURCE_STABILIZED` depois do efeito previsto realmente resolvido**. Atualmente `RECONCILE_P2_SALT` e `RECONCILE_P2_ENERGY` estão ambos HOLD, e não existem lotes/operador/energia adjudicados. Nenhuma transição de aplicação foi praticada.

### Separação entre estabilização e integração

- `SOURCE_RETAINED`: o material conserva poder original em H1 (já adjudicado, não reexecutado).
- `SOURCE_STABILIZED`: P2 ou técnica equivalente **realmente estabiliza uma fonte** sob regra, alvo e evidência.
- `ITEM_INTEGRATED`: apenas com **padrão de transferência apropriado**, inscrição instalada, energia, manifestação própria, contraste H2-3/4/5 e aprovação competente.

Um pergaminho com P2 instalado e própria pedra de energia **pode** manter um efeito sem erva/cristal; isso é confusão causal, não transferência. Portanto o H2-3 deve preceder H2-4/5 e figurar como comparador energético explícito.

## Roteiro mínimo para adjudicação futura pelo Mestre

1. Confirmar em NOTION a versão aprovada de P2 e a decisão da energia/óleo.
2. Identificar testemunha TEST competente e lote real/TEST autorizado, fixando o pré-estado e permissões.
3. Aplicar passo a passo com quantidades reconhecidas e energia legitimada, sem conjuração universal/d20 inventado.
4. Resolver somente a capacidade própria da inscrição de Vedação, registrando condição inicial, decisão, resultado e retenção.
5. Se houver PASS, produzir um novo recibo H2-3 com evento e SHA, ler novamente o store devido, validar NAC-PASS proporcional. Nunca retroeditar E27 nem chamar isso Pingente encantado.
