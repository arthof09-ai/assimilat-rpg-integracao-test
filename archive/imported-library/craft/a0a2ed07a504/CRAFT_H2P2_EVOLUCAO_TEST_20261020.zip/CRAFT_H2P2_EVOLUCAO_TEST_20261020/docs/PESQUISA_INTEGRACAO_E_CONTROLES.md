# Engenharia independente de integração — H2-VB01, sem fórmula canônica fictícia

**Problema:** a fonte mágica ainda pertence à erva/cristal em H1. Vedação P2 pode estabilizar/encapsular elementos, mas não está demonstrado que instale Luminescência ou Contrassombra no corpo do Pingente.

## Comparadores reais recuperados no Notion

| Fonte | Classificação do confronto | Mecanismo documentado | Não autoriza |
|---|---|---|---|
| [REC-MOD-ENC-01](https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6) | **Diretamente aplicável ao PROCESSO** | substrato, receita de pasta, padrão, conhecimento, instalação, energia, cura/selagem e teste são objetos distintos | efeito específico sem fórmula |
| [REC-MOD-EQA-01](https://app.notion.com/p/3f1c2b324ede818ab3c0d913574eed28) | **Diretamente aplicável à FAMÍLIA** | separa montagem física de integração mágica em acessório | poder herdado por mera montagem |
| [Vedação Prata](https://app.notion.com/p/3edc2b324ede81adab3dd3a7f9fe921d) | **Comparador parcial de estabilização** | matriz pode vedar/estabilizar elementos mágicos | transferência específica de luz/Contrassombra |
| [Selamento Prata](https://app.notion.com/p/3edc2b324ede81769f26d68a8a42aab6) | **Incompatível como selo de luz** | receptáculo para espíritos | contenção de aurora por analogia |
| [Sombras Enganosas Ouro](https://app.notion.com/p/3edc2b324ede81328244cb03c1baf85d) e [sua pasta](https://app.notion.com/p/3edc2b324ede813ca572c8b98443d53f) | **Comparador concreto de ITEM encantado** | mistura de insumos Dark, aplicação no item e habilidade própria de camuflagem | faixas de Contrassombra 1 m/1 turno |
| [Reflexo das Profundezas Prata](https://app.notion.com/p/3edc2b324ede816bac13cb656a31677a) | **Comparador concreto de ITEM encantado** | pasta/padrão em item com reflexo/respiração aquática | reutilizar fórmula para luz |
| [Aurora que Rompe Correntes Lendária](https://app.notion.com/p/3f5c2b324ede818296fbd64921861d83) | **Comparador concreto de INSCRIÇÃO em acessório** | inscrição instalada em armadura/manto/acessório, duração limitada e reação 60 PA contra controle mental | luminescência ou padrão de prata |
| [Eclipse Astral Lendária](https://app.notion.com/p/3edc2b324ede818dbbb5de269a8c138f) | **Incompatível como fórmula-alvo** | inscrição de batalha em pergaminho produz eclipse tático | converter em Contrassombra de acessório |
| [Luz de Aurora](https://app.notion.com/p/3edc2b324ede8123b3a0f680ad20202f) | **Fonte temática com evidência insuficiente** | recurso especial captura luz auroral com uso próprio | derivar nova inscrição/efeito só pelo nome |

## Uma candidata técnica TEST, ainda NÃO AUTORIZADA COMO FÓRMULA

**H2-VB01 permanece ÚNICA candidata** e não cria outra receita. Arquitetura por funções:

- **S1 — alojamento:** versão H1 já adjudicada conserva as fontes; tratada como baseline.
- **S2 — estabilização:** testar P2 em pergaminho sem as fontes do Pingente, com lote/energia/operador legitimados. Se P2 funcionar, comparar posterior interface com e sem selo. Não converter `SOURCE_STABILIZED` em `ITEM_INTEGRATED`.
- **S3 — acoplamento:** identificar *novo padrão de vínculo* específico entre propriedade luminosa das fontes e substrato do Pingente, com meio e fonte de energia competentes; NÃO se encontra esse padrão nas nove inscrições da família oficial REC-MOD-ENC. Desenho de zona de inscrição somente layout, não padrão mágico genuíno.
- **S4 — habilidade própria:** efeito ativável cuja origem no suporte seja demonstrada, com controle de retirada das fontes e comparação contra a energia que a própria P2 emprega. Aplicabilidade energética reconsulta PA R39 quando houver contrato efetivo.

### Critério mecânico que realmente decide transferência

1. H2-3, inscrição P2 isolada, com sua própria energia, estabelece `inscription_only_effect` conforme regra e observação.
2. H2-4, quando forma/insumo do Pingente já forem aceitos, aplica uma inscrição com **padrão específico legitimamente autorizado**; observa diferença frente a H1 sem inscrição, mantendo fontes iguais.
3. H2-5, remove as fontes **reversivelmente e de forma autorizada**, compara efeito remanescente com H2-3 e H1, descarta residuais da própria P2.
4. **Ainda assim**, precisa verificar que o padrão instalado concede especificamente a habilidade reclamada; só o Mestre/autoridade pode determinar uma nova fórmula se o corpus não a fornecer. `effect_remains=True` sem essa cadeia não prova integração.

### Decisão normativa mínima para o futuro S3 (independente da errata P2)

O Mestre/autoridade REC deve decidir se autoriza **conceber e ensaiar** um padrão TEST *não-canônico* para vincular a propriedade luminosa da fonte a um substrato de acessório, e determinar sua forma, energia, uso, limites e verificador de instalação. As nove inscrições canônicas mostram TECNOLOGIA DE ITEM com efeito próprio, mas **não** dão fórmula equivalente à **Luminescência de Vigília** ou **Abertura de Contrassombra**.

A escolha de autorizar pesquisa adicional não é aprovação de fórmula, não supre H2-3 e não define PA. O resultado legítimo de S3 enquanto não autorizado é `H2_EFFECT_PATTERN_PENDING`, e o da instalação é `NOT_EXECUTED`.
