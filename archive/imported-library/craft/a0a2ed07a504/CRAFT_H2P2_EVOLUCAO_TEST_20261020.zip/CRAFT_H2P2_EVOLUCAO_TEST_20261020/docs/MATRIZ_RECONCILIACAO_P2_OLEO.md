# P2 e Óleo de Vedação — reconciliação de fonte e patch MÍNIMO proposto (NÃO APLICADO)

**Identidade:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001` · mesmo Pingente v1.3/H2-VB01 · MESTRE-SIDE/TEST · estado `PREPARADO/AGUARDANDO AUTORIDADE`. **Nenhuma linha canônica foi editada.**

## Autoridades e versões abertas neste ciclo

| Referência | Notion | Última edição recuperada | Função |
|---|---|---|---|
| P2 Prata receita | [P2 vigente](https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8) | 02/10/2026 12:35:14Z | BOM/sete linhas e processo/seis etapas |
| P2 efeito | [Inscrição de Vedação Prata](https://app.notion.com/p/3edc2b324ede81adab3dd3a7f9fe921d) | 03/10/2026 05:37:57Z | Vedar e estabilizar elemento mágico ou entidade por prazo não quantificado |
| Óleo vigente | [Óleo de Vedação](https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd) | 03/10/2026 04:46:58Z | Insumo próprio da P2, preparo problemático |
| Óleo histórico | [Óleo de Vedação — outra cópia](https://app.notion.com/p/75fc2b324ede83d492f881e556dc03f8) | 30/09/2026 04:46:54Z | Repete os defeitos; NÃO é errata |
| Vedação histórica | [Inscrição de Vedação Ouro](https://app.notion.com/p/7cac2b324ede8294bb7a8169d7a51ad7) | 30/09/2026 04:46:50Z | Variante com materiais/quantidades DISTINTOS; não corrige P2 Prata |
| Regras | [REC-MOD-ENC-01](https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6) | 06/10/2026 04:35:56Z | Padrão, receita do meio, substrato, energia, aplicação, selagem, evento instalador separados |

Essas versões são datas de página recuperadas, **não hashes de bytes brutos do Notion**. Transcrições do código e dos excertos no pacote são snapshots dirigidos, não replicação integral de blocos originais.

## Matriz BOM↔processo

| Código | Literal da receita | A parte do processo | Implicação | Evidência para equivalência | Correção mínima PROPOSTA |
|---|---|---|---|---|---|
| **P2-SALT-01** | “**2x Sal de Geodo Santo**” | Passo 3: “**Sal de Geodo Encantado**” | Não é seguro consumir ou debitar estoque de um sob o ID do outro | **Não encontrada** como alias aprovado; antiga versão Ouro usa **Sal dos Espíritos** e outras quantidades | Mestre/autor da P2 define o insumo vencedor; opção A preservar BOM e retificar passo 3; opção B retificar BOM mediante identidade distinta e rastreável. **Nenhuma escolhida automaticamente.** |
| **P2-ENERGY-02** | “**2x Pedra da Luz ou 2x Pote de Essência Mágica**” | Nas seis etapas não há ação de inclusão/energização | Energia listada ≠ ação executável; não inferir PA nem energia extra | Receitas de outros elementos mostram energização contextual, mas não podem impor passo específico à P2 | Mestre/autor adiciona instrução explícita no processo para **escolher UMA das duas fontes declaradas**, definir ponto de aplicação, condições, eventual consumo, selagem, observação e falha. **Nenhuma condição inventada.** |
| **OIL-DROPS-03** | Óleo: “**8x Gota do Orvalho do Amanhecer**” | Passo 2: “**Orvalho de Dragão**” e trecho termina em “com a C” | Não se sabe insumo empregado nem sequência completa | Cópia histórica de 30/09 repete; não confirma equivalência | Recuperar versão integral validada ou corrigir sob autoridade do óleo. **Alternativa operacional**: usar lote de Óleo de Vedação ACABADO já existente, se origem/lote/qualidade de verdade forem comprovados, sem fabricar óleo neste ensaio. |
| **OIL-ESSENCE-04** | Óleo: “**1x Essência de da lua minguante**” | Passo 4: “**Essência de Vórtice**” | Outra divergência de identidade; não intercambiar por nome/elemento | Não encontrada correspondência suficiente; etapa 2 do óleo também truncada | Autor do óleo ou fonte íntegra aprovada deve resolver; óleo pronto legitimamente rastreado é dependência ALTERNATIVA, não prova de que a fórmula de óleo foi corrigida. |
| **OIL-IRON-05** | Óleo vigente: **3x Pó de Ferro Celestial** | Histórico do óleo registra **2x**, mas o processo vigente não explicita incorporação desse pó em etapa íntegra | Divergência de quantidade entre versões e mapeamento BOM incompleto | NÃO existe despacho de supersessão que transforme 2 em 3 como correção; versão atual tem 3 | Manter 3 como literal vigente, investigar etapa e divergência histórica com autor do Óleo; ou obter **óleo acabado rastreável**, sem fabricar o fornecedor. |

### O precedente Ouro esclareceu o quê?

A versão anterior [Vedação Ouro](https://app.notion.com/p/7cac2b324ede8294bb7a8169d7a51ad7) usa **2 Sal dos Espíritos**, **1 Pó de Ferro do Espaço**, **2 Óleos de Vedação** e **4 energizadores alternativos**, enquanto P2 usa **2 Sal de Geodo Santo**, **3 Pó Ferro Meteoro**, **1 óleo** e **2 energizadores**. O passo 3 da Ouro usa o MESMO nome que sua lista, mas continua sem procedimento explícito do energizador. Assim, **há pluralidade real de variantes, não demonstração de sinonímia ou de errata da Prata**.

### Rota de redução de dependência legítima

- **Rota 1 — Produzir o Óleo:** requer reconciliação das duas discrepâncias do óleo + etapa truncada + ingredientes/operador/condições. HOLD.
- **Rota 2 — Obter Óleo acabado comprovado:** dispensa **apenas** produzir o óleo do zero; ainda exige **lote/autoridade/qualidade** do produto acabado e ambas as correções P2-SALT-01 e P2-ENERGY-02. Nenhum lote foi verificado nesta rodada.

**Nenhum patch proposto foi aplicado à P2, Óleo, item, BOM oficial, runtime ou Party.** Um operador jamais pode marcar `P2_INSTALLED` com base apenas em validação de texto, no uso do sal hipotético ou em `magic_success=True`.

## Encaminhamento à autoridade competente — pedido singular versionado

**Solicitação de errata EXECUTIVA da P2, não de regra universal:** em LAB TEST, o Mestre/autor competente deve (1) determinar qual identidade de sal governará a Prata P2 e (2) inserir o uso/posição do energizador já previsto, inclusive condições e falha; (3) decidir se um lote de óleo acabado válido é suficiente para evitar reprocessamento do Óleo neste ensaio. A correção do Óleo como receita própria só será exigida para fabricá-lo, e será feita em sua autoridade separada.

**Proposta preferida de menor alteração, sujeita a decisão expressa:** manter os insumos P2 literalmente listados e corrigir **somente o passo 3** para o nome aprovado após a identidade ser confirmada; inserir **uma etapa de energização** usando UMA fonte já listada, sem inventar tempo/PA/forma de aplicação; usar **óleo acabado verificado** sem recompor a receita defeituosa do fornecedor. Nenhuma linha pode ser publicada como errata aprovada sem despacho e NAC-PASS.
