# PSV — CRAFT / H2-VB01 · evolução pós-E50+ (TEST)

**AS-OF:** 20/10/2026, MESTRE-SIDE · **Operação existente:** OP-ARQ-RIN-REC-01 · **Workstream:** CM-000002-WS0001 · **Caso único:** LAB-CRAFT-VIGILIA-BOREAL-20261020-001 · **Receita e candidata:** Pingente v1.3 / H2-VB01 · **Inbox existente:** IBX-116 · **PA:** IBX-118. Não reivindicada reserva global de E51, portanto checkpoint novo por marcador `CRAFT-H2P2-ENG-20261020-*`.

## Resultado de capacidade antes dos hashes

**A. P2:** fontes atuais relidas, sem errata P2 Prata encontrada; versão histórica Ouro é distinta e não autoriza trocar materiais. Matriz BOM↔processo preserva identidade do sal e omissão da energização como 2 impedimentos no núcleo P2. Óleo atual tem divergências entre lista e processo, etapa truncada e **quantidade do Pó Ferro Celestial diferente da cópia histórica (3× atual / 2× histórica)**. São **5 issues rastreáveis** nesta passagem (2 diretas P2, 3 grupos do fornecedor Óleo), sem patch canônico aplicado. Menor fix legítimo no arquivo `MATRIZ_RECONCILIACAO_P2_OLEO.md`.

**B. H2-3:** a receita P2 cita pergaminho/objeto como substrato; o protocolo de **15 campos** está especificado para TEST em pergaminho separado, não Pingente. Modelo de dependências tem **16 nós** e condições de avanço; o ensaio prévio documental foi reusado. **Nenhuma inscrição realizada; H2-3 INSTALL=HOLD** por divergências P2, falta de lotes, operador, alvo e energia com regra de aplicação. Novo benefício: **óleo acabado de proveniência verificada pode legalmente substituir a necessidade de *fabricar o fornecedor Óleo* durante o ensaio P2**, mas nenhum estoque foi comprovado; isso não elimina correção da P2.

**C. H2-4/H2-5:** comparadores causalmente separados, `H2-4` depende de substrato do Pingente, padrão específico dos efeitos e estabilização H2-3; `H2-5` depende de H2-4/retirada segura e controle da energia **da própria P2**. O protocolo recusa `ITEM_INTEGRATED` com mero efeito residual, falso `magic_success` ou simulação. Nenhuma nova transferência provada.

**D. Materialidade:** layout paramétrico/testável com janelas para duas fontes, amarração PS reversível e área H2 distinta (desenho SVG não à escala). O verificador de geometria possui entradas tipadas, acusa medidas ausentes, valida somente desigualdades condicionais; teste sintético não vira medição. Fibra PS = ligante; Ardósia Lamelar PS = possibilidade de placa; Pergaminho = substrato P2 em cupom isolado, não peça da v1.3. **Peças produzidas 0, medições 0, BOM oficial 0 adições**.

**E. Integração mágica:** além da Vedação, fontes **Sombras Enganosas Ouro**, **Reflexo das Profundezas Prata** e **Aurora que Rompe Correntes Lendária** demonstram que o corpus prevê inscrições com **efeito próprio no item/acessório**. Nenhuma instala especificamente Luminescência de Vigília ou Abertura de Contrassombra; Eclipse Astral é inscrição de batalha, incompatível como fórmula-alvo. A proposta H2-VB01 (uma candidata, sem REC-ID) requer decisão específica sobre padrão e energia de vínculo das fontes ao suporte para S3, separada da estabilização P2 S2. **Inscrição própria 0**.

**F. PA:** reaberto o objeto **IBX-118** ao qual foi encaminhada `CRAFT-PA-QUERY-POS-E50-20261020-001`. Não havia despacho do responsável presente na verificação; PA H1 original R39/R34/R27/R26 continua **NULL**, NÃO custo zero. Três modalidades A fontes próprias, B P2 estabilização, C habilidade item próprio mantidas distintas. 12 PA/dia+7/uso/26 cenário para v1.3 E3 é **orçamento prospectivo, não débito H1**, e não foi refeito pelo CRAFT.

**G. Evolução sistêmica:** código `code/h2_protocol.py` é um **compilador de gates auxiliar** para o fluxo CRAFT já existente, usando como entrada a representação documental P2 aprovada em E50 — NÃO motor de encantamento, PA ou R48. Entrega diagnóstico de divergências P2/Óleo; DAG de autorização, opção de insumo acabado do fornecedor; controle antirreclassificação H2-5; e `code/mount_geometry.py` produz QA geométrico condicionado a medidas reais. 43 testes novos verificam o comportamento dos validadores, não produzem magia.

**H. Homologação / denominadores:**

| Gate | Evidência | Estado |
|---|---|---|
| H1 luz qualitativa | Mestre TEST e cena E50, não reexecutada | PASS histórico delimitado |
| P2 mecanismo de Vedação | P2 Prata fonte e receita | VERIFICADO como mecanismo, não aplicado |
| Preflight e protocolo H2-3 | 7 insumos / 6 passos; 15 campos; 16 nós de dependência | PASS **somente de engenharia** |
| Reconciliar P2 sal/energização | 2 divergências | **0/2 resolvidas**, HOLD |
| Preparar Óleo na própria receita | 3 grupos divergentes | **0/3 resolvidos**, HOLD; óleo acabado depende de lote |
| H2-3 instalação com operador/energia | Não executada | **0/1**, HOLD |
| H2-4/H2-5 instalação/remoção | Não executadas | **0/2**, HOLD |
| SOURCE_STABILIZED / ITEM_INTEGRATED | Não demonstrados | **0/2**, HOLD |
| Geometria física/QA físico | 0 medidas, 0 peças | HOLD |
| R48 antigo E27 | seq 1; dois commits íntegros | PASS histórico read-only, sem TX nova |
| Software TEST | baseline replay **25/25** histórico + **43/43** novos | PASS software, não magia |
| PA A/B/C | sem resposta formal | PENDENTE; A retorna NULL |
| F5 / C19-021 | F5 RED / UNKNOWN-EFFECT | RC5/P4/produção HOLD |
| Party/O Primeiro | nenhuma escrita | NO-WRITE |

**I. Continuidade:** última unidade verificável deste ciclo = P2/óleo reconciliação e cold replay + matriz de interface; **primeiro identificador sequencial global disponível: NÃO DEMONSTRADO**; marcador usado `CRAFT-H2P2-ENG-20261020-*`. Primeira dependência externa = autoridade da P2 decidir a identidade do sal e a operação do energizador; em paralelo, procurar lote real/TEST autorizado de Óleo acabado e operador de inscrição, sem fabricar estado. Segundo bloqueio independente = padrão de vinculação luz/Contrassombra ao Pingente. PA espera resposta ao objeto único IBX-118, não nova solicitação. R48 TEST E27 seq1/ordem histórica **não repetir**.

## Entrega e segurança

- `inputs/` snapshots textuais rastreáveis, **não** extração integral da fonte Notion.
- `docs/` reconciliação, protocolo, materialidade, precedentes e este PSV.
- `design/` desenho SVG sem escala, não peça real.
- `code/h2_protocol.py`, `code/mount_geometry.py` e `tests/test_new_delta.py`: **engenharia auxiliar**; não motor mágico.
- `baselines/` ZIP pós-E50 autêntico, byte idêntico, hash fixo.
- `outputs/` diagnóstico de gates e logs de execução.
- `code/run_replay.py`: replay em extração limpa, baseline e 43 novos tests.

**NAC-PASS proporcional:** PASS engenharia/qualificação documental, software, reprodutibilidade e congelamento R48; HOLD procedimento de inscrição, energia, PA novo, observação mágica, física, RC5/P4 e produção. Não há testemunha mágica externa, writership produtivo, STOP-ACK/release ou fencing comprovado. Nenhuma ficha Mestre-only foi publicada à Party/O Primeiro.
