# Interface H2-VB01 — geometria paramétrica, QA e reversibilidade

**Caso único:** Pingente da Vigília Boreal v1.3 TEST. Sem adição à BOM oficial. Desenho em [`../design/INTERFACE_VB01_SEM_ESCALA.svg`](../design/INTERFACE_VB01_SEM_ESCALA.svg) é **esquema**, não foto, CAD executivo homologado, fabricação ou medição.

## Arquitetura modular de FUNÇÕES (não componentes comprados)

1. **Pontos de retenção H1:** contato mecânico reversível sem dano a cristal/erva; as duas fontes ficam íntegras e expostas, conforme SIM Mestre já adjudicado. Não inferir método adesivo ou clipe específico.
2. **Amarração PS:** Fibra da Casca Boreal, função mecânica somente, 45 cm PROPOSTOS no dossiê v1.3 (não quantidade medida/rendimento). Não transmutar sua superfície em substrato inscricionável.
3. **Janelas de exposição independentes:** uma mineral e outra vegetal. Ausência da erva não apaga a luz do cristal; ausência do cristal não apaga a luz da erva, como cena E50. Não classificar alcance quantitativo.
4. **Zona H2 de inscrição separada:** no desenho apenas área ilustrativa, sem matéria/produto adicionado. A superfície mais diretamente sustentada por P2 é **pergaminho de ensaio H2-3**, separado fisicamente do Pingente. Ardósia Lamelar PS é alternativa rígida a ser testada depois, não homologada para P2.
5. **Retirada reversível H2-5:** mecanismo de remoção só é validado após ensaios físicos de esforço/dano e após a inscrição H2-4 legitimamente instalada; fora disso é restrição de projeto.

## Contrato geométrico, sem valores inventados

Variables requeridas antes de aceitar montagem física:

| Variável (mm ou mm², unidade explícita) | Origem da futura medição | Critério puramente geométrico |
|---|---|---|
| `crystal_envelope_mm` | cristal TEST e orientação | contorno máximo documentado |
| `crystal_aperture_mm` | suporte TEST | abertura livre ≥ envelope projetado |
| `herb_envelope_mm` | erva TEST / folhas expostas | contorno máximo documentado |
| `herb_aperture_mm` | suporte TEST | abertura livre ≥ envelope projetado |
| `strap_length_mm` | corte real de fibra teste | comprimento fornecido ≥ percurso de amarração medido |
| `strap_required_mm` | medição de percurso/folga | cálculo de forma física auditável |
| `substrate_trace_area_mm2` | plano do substrato concreto | área útil ≥ área do padrão autorizado |
| `pattern_required_area_mm2` | área do padrão autêntico inscricionável | **não existe ainda fórmula/padrão específico** para novo efeito Pingente |

`code/mount_geometry.py` calcula exclusivamente essas desigualdades **quando alimentado com medições**. Atualmente não há dados físicos: retorna `NEEDS_MEASUREMENTS`. Um fixture com valores hipotéticos só demonstra algoritmo, jamais segurança real, ausência de bloqueio óptico ou resistência do produto.

### Ensaios de bancada física quando houver materialidade autorizada

- **T1 Fixação:** registrar resistência/folga/deslizamento, com instrumentos/operador/unidade/incerteza; sem critérios numéricos inventados.
- **T2 Exposição:** confirmar que suporte não cobre superfície funcional de cristal e erva durante uso e orientação normal, confrontar com condição H1 da decisão Mestre.
- **T3 Remoção:** desmontar sem dano às fontes, repetir encaixe e verificar desgaste (não aplicado ainda).
- **T4 Compatibilidade de material:** verificar se superfície candidata aceita a pasta P2 e se a energização degrada as fontes. NÃO presumir equivalência de fibra/ardósia/pergaminho.
- **T5 Segurança e ergonomia:** avaliar massa, bordas, conforto, contato corporal, movimento, resistência à umidade e risco de ruptura, com unidade/limite fundamentado.

**QA atual:** `LAYOUT_TEST_PROPOSTO`, `CONDIÇÕES_GEOMÉTRICAS_DEFINIDAS`; `QA_FÍSICO_MEDIDO=0`, `PEÇAS_PRODUZIDAS=0`, `BOM_OFICIAL_ADIÇÕES=0`.
