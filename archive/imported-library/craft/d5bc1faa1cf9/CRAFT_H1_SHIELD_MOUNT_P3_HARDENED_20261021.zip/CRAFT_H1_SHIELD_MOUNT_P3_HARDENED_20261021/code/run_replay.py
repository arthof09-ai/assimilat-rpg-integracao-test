import subprocess,sys,importlib.util,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def run(args):
 p=subprocess.run([sys.executable,*args],cwd=root,capture_output=True,text=True,timeout=30)
 assert p.returncode==0,p.stderr[-1000:]
 return p.stdout+p.stderr
assert 'PASS_MANIFEST' in run(['code/verify_manifest.py'])
assert 'Ran 59 tests' in run(['-m','unittest','discover','-s','tests','-p','test_*.py'])
s=importlib.util.spec_from_file_location('h1mount',root/'code/mount_candidate.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert m.snapshot()==json.loads((root/'outputs/snapshot.json').read_text())
assert m.snapshot()['physical_prototypes']==0
assert m.snapshot()['magic_tests']==0
assert m.snapshot()['candidate_recipes_created']==1
assert m.documentary_preflight()['stage']=='HOLD_MISSING_REAL_MEASUREMENT_AND_AUTHORITY'
assert m.snapshot()['proposal']['PA_day'] is None
print('PASS_REPLAY H1_SHIELD_P3 59/59 SAFETY_GATES 1 P3 DESIGN 0 PROD 0 MAGIC 0 PA')
