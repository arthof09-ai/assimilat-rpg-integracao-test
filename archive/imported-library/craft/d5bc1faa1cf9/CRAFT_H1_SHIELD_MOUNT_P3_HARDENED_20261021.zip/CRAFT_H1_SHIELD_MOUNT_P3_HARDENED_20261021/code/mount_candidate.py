"""P3 TEST shield accessory with H1 retained-source concept, not fabrication.

This is a project within the existing CRAFT operation; NEVER modifies a shield,
crystal, inventory, game rule, Party or magic engine. No claim of item enchantment.
"""
from __future__ import annotations
from itertools import product
from math import isfinite

CRYSTAL='https://app.notion.com/p/3edc2b324ede818b9d7ad75d42f2afa2'
HERB='https://app.notion.com/p/3edc2b324ede81deb8cec70bf5ca7150'
EQA='https://app.notion.com/p/3f1c2b324ede818ab3c0d913574eed28'
ARD='https://app.notion.com/p/3f1c2b324ede8116bd3cc6606a1c6687'
LANTERN='https://app.notion.com/p/a2bc2b324ede830a98a701b78079781c'

PROPOSAL={
 'trace':'CRAFT-H1-CROSSCATEGORY-SHIELD-20261021-001',
 'name':'Suporte de Vigília Luminar para Escudo',
 'stage':'P3_PROPOSTO_ONLY','item_family':'ACESSORIO_EQUIPAMENTO',
 'host_type':'escudo existente a identificar, não um escudo novo',
 'host_source_category':'ARMA/ARMADURA/EQA a confirmar pela ficha do escudo escolhido',
 'core':{'item':'Cristal de Aurora Boreal','amount':1,'source_ref':CRYSTAL,
         'source_property':'emite luz calmante que pode dissipar escuridão',
         'blindness_cure_not_tested':True,
         'magic_remains_at_source':True},
 'physical_scope':'Grampo físico REVERSÍVEL sobre borda de escudo, com janela frontal aberta, retenção secundária e espaço para extração segura',
 'secondary_materials':'grampo, acolchoamento, retentor e suporte a selecionar no acervo; nenhum lote atestado',
 'no_oil':True,'no_p2':True,'no_new_inscription':True,
 'design_goal':'iluminação de orientação por fonte exposta, sem transferir luz ao escudo',
 'source_retained_candidate':True,'source_stabilized_claim':False,'item_integrated_claim':False,
 'defensive_stats_added':False,'PA_day':None,'PA_activation':None,'PA_debited':0,
 'new_item_or_recipe_created_in_notions_canon':False,
 'manufacturer_and_operator':'UNASSIGNED',
 'production':'HOLD',
 'comparators':[{'name':'Lanterna de Bioluminescência','url':LANTERN,
                 'distinction':'lanterna existente atrai/repulsa criaturas abissais; NÃO importar sua função/26 PA ao grampo'}],
 'sources':[CRYSTAL,HERB,EQA,ARD],
}

REQUIRED={
 'host_shield_id','host_owner_or_lab_permission_ref','host_edge_measurement_ref',
 'clamp_material_lot_ref','padding_lot_ref','source_crystal_lot_ref',
 'crystal_dimensions_ref','window_dimensions_ref','retention_test_ref',
 'illumination_test_setup_ref','negative_control_record_ref',
 'operator_assignment_ref','test_adjudicator_ref','qa_readback_ref',
}

def four_arm_h1_test_plan():
    arms=[]
    for has_source,exposed in product((False,True),repeat=2):
        arms.append({'arm':('SOURCE' if has_source else 'BLANK')+'_'+('OPEN' if exposed else 'COVERED'),
            'source_installed':has_source,'window_exposed':exposed,
            'planned':True,'executed':False,
            'witnessed_effect':None,
            'expected_inference':'COMPARE_ILLUMINATION_ONLY_NOT_ITEM_POWER',
        })
    return {'arms':arms,'control_arms':4,'observed':0,'real_scenes':0,'source_only_reference_required':True}


def documentary_preflight(input_claims:dict|None=None):
    """Even fully populated text is not measured or verified evidence."""
    if input_claims is None:
        x={}
    elif not isinstance(input_claims,dict):
        return {'stage':'REJECT_MALFORMED_DOCUMENTARY_RECORD','physical_receipt':False,'manufactured':False,'can_move_to_rc5':False,'new_R48_orders':0}
    else:
        x=input_claims
    bad_boolean_fields=[k for k in ('host_damage_risk','change_shield_ca','transfer_magic_claim','party_asset_target','new_spell_claim') if k in x and type(x[k]) is not bool]
    missing=sorted(k for k in REQUIRED if not isinstance(x.get(k),str) or not x[k].strip())
    checks={
        'host_may_be_damaged':x.get('host_damage_risk') is True,
        'shield_CA_bonus_proposed':x.get('change_shield_ca') is True,
        'crystal_magical_ability_moved_to_shield':x.get('transfer_magic_claim') is True,
        'party_asset_target':x.get('party_asset_target') is True,
        'new_luminous_spell_claimed':x.get('new_spell_claim') is True,
    }
    if bad_boolean_fields:stage='REJECT_MALFORMED_SAFETY_FLAGS'
    elif any(checks.values()):stage='REJECT_UNSAFE_OR_UNSUPPORTED_CLAIM'
    elif missing:stage='HOLD_MISSING_REAL_MEASUREMENT_AND_AUTHORITY'
    else:stage='CONDITIONAL_INDEPENDENT_PHYSICAL_READBACK_REQUIRED'
    return {'stage':stage,'missing':missing,'malformed_safety_fields':bad_boolean_fields,'unsafe_claims':checks,
            'source_property_preserved':True,'source_only_no_new_magic':True,
            'test_performed':False,'physical_receipt':False,
            'manufactured':False,'shield_CA_changed':False,
            'integration_magic_observed':False,'pa_day':None,
            'can_move_to_rc5':False,'new_R48_orders':0,
            'no_write_outside_lab':True}


def geometry_sanity(dim:dict|None=None):
    """Only checks algebraic coherence for synthetic/supplied numbers.

    Millimeters are example units for mechanical consistency, but NO fabricated
    size/tolerance is taken as real calibration or source approval.
    """
    if dim is None: dim={}
    if not isinstance(dim,dict):
        return {'stage':'MALFORMED_GEOMETRY_RECORD','measured':False,'physical_pass':False}
    keys=('shield_edge_thickness_mm','clamp_internal_clearance_mm',
          'crystal_max_diameter_mm','window_clear_opening_mm')
    if not all(type(dim.get(k)) in (float,int) and isfinite(dim[k]) and 0<dim[k] for k in keys):
        return {'stage':'MEASUREMENTS_MISSING_OR_INVALID','measured':False,'physical_pass':False}
    logical=(dim['clamp_internal_clearance_mm']>=dim['shield_edge_thickness_mm'] and
             dim['window_clear_opening_mm']>=dim['crystal_max_diameter_mm'])
    return {'stage':'SYNTHETIC_GEOMETRY_LOGIC_PASS' if logical else 'SYNTHETIC_GEOMETRY_LOGIC_FAIL',
            'comparisons_pass':logical,
            'host_compatible_physically':None,
            'tolerance_approved':False,
            'measured':False,'physical_pass':False}


def snapshot():
    return {'proposal':PROPOSAL,'h1_controls':four_arm_h1_test_plan(),
            'default_preflight':documentary_preflight(),
            'default_geometry':geometry_sanity(),
            'oil_supplier_required':False,
            'physical_prototypes':0,'magic_tests':0,'candidate_recipes_created':1,
            'candidate_recipes_ps':0,'rc5_official':0,
            'original_shield_edit':0,'crystal_consumed':0,'r48_events':0,
            'party_and_prime_writes':0}

if __name__=='__main__':
 import json
 print(json.dumps(snapshot(),ensure_ascii=False,indent=2))
