CRAFT — Suporte de Vigília Luminar para Escudo, proposal P3/TEST. This package is NOT a physical or magic object and does not edit existing Notion source. Run `python code/run_replay.py` after extraction. The diagram is a schematic at undefined scale. The tests only prove local code logic / safety negatives. The source crystal is an existing canonical resource; no item ability or PA rate is transferred.

Existing operation OP-ARQ-RIN-REC-01; workstream CM-000002-WS0001, LAB CRAFT. For canonical sources, see docs/PROJETO_P3_SUPORTE_VIGILIA_LUMINAR.md. No new OP/REC-ID/lease/epoch/ACK. Pa/day = NULL/PENDENTE.

**QA2 successor (2026-10-21):** This archive hardens the previous P3 shield-mount project; it is not a new item or new recipe. See docs/HARDENING_QA_V2.md. 59 digital unit tests including malformed input and nonfinite geometry. No measurements, physical tests or magic acts. Prior v1 ZIP and SHA are preserved by reference and were not modified.
