# Proposta P3 / TEST — Suporte de Vigília Luminar para Escudo

**TRACE** CRAFT-H1-CROSSCATEGORY-SHIELD-20261021-001. **Operação existente** OP-ARQ-RIN-REC-01 / CM-000002-WS0001 / MESTRE-SIDE TEST. Não é página de item criada, receita RC5, produto fabricado, magia instalada, lançamento em loja nem informação Party.

## I. Identidade e finalidade

- **Nome:** Suporte de Vigília Luminar para Escudo (P3/TEST).
- **Categoria proposta:** acessório de equipamento **removível**, montado em escudo existente; não cria nem altera escudo-base. Módulo aplicável REC-MOD-EQA-01; compatibilidade com eventual chassi defensivo segue REC-MOD-ARD-01 e a ficha real do escudo escolhido.
- **Rank público e FIP do produto:** **PENDENTES**. Nenhum rank de item por herança do RIn Ouro da fonte. Efeito próprio de item = NÃO DEMONSTRADO.
- **Objetivo funcional proposto:** ter fonte de luz da aurora exposta na face anterior do escudo para orientação quando usado à noite, sem exigir uma lanterna separada. Intensidade/alcance/duração não documentados: pendentes.
- **Elemento:** Luz na fonte cristalina, não afinidade conferida ao escudo.
- **Compatibilidade/funcionalidade:** apenas se não bloquear campo de visão, ergonomia, manuseio, proteção do escudo e janela física da fonte. Não declarar vantagem de Percepção, CA, dano, medo, repelir criaturas, cura, imunidade ou outra habilidade de item.

## II. Propriedades e materiais efetivamente documentados

**Fonte única de H1:** 1 Cristal de Aurora Boreal, recurso canônico [Mestre](https://app.notion.com/p/3edc2b324ede818b9d7ad75d42f2afa2) que naturalmente emite luz calmante, pode dissipar escuridão e curar cegueira mágica segundo texto. Aqui se busca **somente iluminação intrínseca exposta**; cura/dissipação em montagem não são verificadas nem herdadas pelo escudo. Na regra de Anel, 1 unidade física é 1 cristal, com escala Pequeno; não é quantidade de estoque. H1 do Pingente anterior autoriza inferência somente em seu escopo qualitativo histórico, não prova universal da nova montagem.

**Chassi:** escudo preexistente TEST, ID e autorização pendentes. **Suporte, grampo, acolchoamento e retenção:** componentes mecânicos PROPOSTOS, sem material, dimensão, quantidade de fabricante, resistência ou lote presumidos. Fixação **reversível**, sem perfurar o escudo, sem adesão destrutiva, com janela frontal e mecanismo de retirada. Uma variante com Erva da Luz do Norte é **hipótese posterior independente**, não BOM da versão P3 atual.

**Fornecedor:** origem do cristal descrita como cavernas geladas do Reino de Borealis; isso **não cria rota logística real nem exemplar disponível**. O responsável pelo design não cria fornecedor ou estoque.

## III. BOM / processo de projeto (não receita material executável)

| Papel | Componente | Quantidade | Estado |
|---|---|---:|---|
| Fonte de luz | Cristal de Aurora Boreal | 1 | Identidade canônica sim, lote/QA não |
| Hospedeiro | Escudo existente | 1 referência | Identificação, autorização e medição pendentes; não consumir escudo |
| Estrutura | Suporte/grampo de montagem | A definir | Geometria, material, ferramenta e resistência pendentes |
| Contato | Acolchoamento e retenção secundária | A definir | Material/quantidade e falha segura pendentes |

**Processo TEST a autorizar, não executado:** (1) identificar hospedeiro e comprovar permissão; (2) medir borda/chassi e cristal com instrumentos calibrados; (3) selecionar grampo e retentor reversíveis com fonte existente; (4) ensaio mecânico em réplica TEST inerte; (5) somente com lotes/operador/proteção efetivos, inserir cristal real intacto sem mudança de superfície/estrutura do escudo; (6) testar fonte sozinha, suporte vazio, suporte aberto, suporte fechado, remoção e readback. Sem ritual, óleo, P2 ou inscrição nova.

## IV. Esquema e verificador

`sketch/CONCEITO_NAO_MEDIDO.svg` é desenho paramétrico **NÃO ESCALADO** sem valor dimensional canônico. O verificador `code/mount_candidate.py` recusa falta de referências e riscos, e pode comparar clareza interna com espessura e abertura frontal com diâmetro apenas em *dados sintéticos*. Mesmo se sintéticos coerentes, NÃO aprova material nem equipamento.

**14 evidências de ingresso físico:** ID e permissão do escudo, medição de espessura, lote do grampo e do acolchoamento, lote do cristal, dimensão do cristal e janela, laudo de retenção, plano de ensaio luminoso, controle negativo, nomeação operador, testemunha/adjudicador, readback QA. Gate de dano ao hospedeiro REJECT; mudar CA REJECT; mover magia da fonte ao escudo REJECT; Party item como alvo REJECT.

## V. Controle causal da luz H1

| Braço experimental proposto | Cristal instalado | Janela exposta | Resultado real |
|---|---|---|---|
| BLANK_COVERED | Não | Não | NÃO OBSERVADO |
| BLANK_OPEN | Não | Sim | NÃO OBSERVADO |
| SOURCE_COVERED | Sim | Não | NÃO OBSERVADO |
| SOURCE_OPEN | Sim | Sim | NÃO OBSERVADO |

Além desses braços, comparação da **fonte sozinha** em mesmas condições e teste de retirada reversível, a adjudicar. Não basta emitir brilho residual após remoção para concluir poder próprio do hospedeiro. O plano não simula rolagem, magia ou testemunho.

## VI. Comparadores, não duplicata

[Lanterna de Bioluminescência](https://app.notion.com/p/a2bc2b324ede830a98a701b78079781c) é um item existente com atração/repulsão de criaturas abissais e anotação histórica de 26 PA; não é esta candidata e seu custo/poder não são transportáveis. [Escudo Sentinela](https://app.notion.com/p/29ac2b324ede82d8a46e814c05fcfb77) possui vantagens próprias; a candidata **não ganha** vantagem de iniciativa ou Percepção. Busca dirigida por nome/função do suporte não encontrou uma página canônica equivalente evidente, mas não é prova de inexistência universal. Projeto é extensão física removível, não cópia da Lanterna ou aprimoramento do Escudo Sentinela.

## VII. Economia, efeitos, classificação e riscos

- **Preço:** PENDENTE, proibido derivar de preço de cristal, lanterna ou escudo.
- **Custo PA/dia e por ativação:** `NULL/PENDENTE`, não zero. Fonte H1 preserva resposta parcial PA; nenhuma tarifa v1.3 do Pingente transferida.
- **Duração:** depende da fonte e proteção, SEM número canônico.
- **Manutenção:** substituição/revisão do grampo e fonte somente após especificação e aprovação; não reponha cristal fictício.
- **Riscos técnicos propostos:** obstrução, queda do cristal, exposição aos golpes, quebra da retenção, incompatibilidade com escudo, brilho denunciando localização, reação mágica desconhecida.
- **História/obtenção:** nenhum evento passado novo, nenhuma facção fabricou protótipo, nenhuma loja tem exemplar, nenhuma ficha original recebeu menção.
- **Selo editorial:** P3 proposta. NÃO PS/P4/RC5. Não aplicar autocanonização por caso simples.

## VIII. Entrega e NAC-PASS proporcional

Software QA testado e reproduzível; peça TEST física **0**, aplicação mágica **0**, efeito novo do escudo **0**, teste com cristal físico **0**, lotes **0**. `PR-ITEM-02` e `REC-MOD-EQA/ARD` governam eventual evolução. Gate para cena é (a) host legítimo, (b) materiais/lotes, (c) física QA, (d) operador TEST, (e) adjudicador e controles, (f) autoridade e efeito, (g) readback. Com F5 RED/C19 UNKNOWN, nenhuma publicação/canonicidade. Party/O Primeiro não recebe este material.

**Próxima ação autorizável sem magia:** realizar teste dimensional inerte com *peças do próprio laboratório* comprovadas ou completar projeto de geometria após medição autêntica; não fabricar automaticamente. Em paralelo concluir P2 e Óleo por suas autoridades.
