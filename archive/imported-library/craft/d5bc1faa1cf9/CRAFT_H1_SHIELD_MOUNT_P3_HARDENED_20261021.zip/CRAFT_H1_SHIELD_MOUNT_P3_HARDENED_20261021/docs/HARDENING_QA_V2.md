# P3 Suporte de Vigília Luminar — QA2 adversarial (MESTRE-SIDE TEST)

**Operação:** OP-ARQ-RIN-REC-01 / CM-000002-WS0001. **Novo trace:** CRAFT-H1-SHIELD-QA2-20261021-001. **Antecessor imutável:** CRAFT_H1_SHIELD_MOUNT_P3_TEST_20261021.zip (SHA-256 927966b1527698325eda08159ab10be30b4595a7b86b8fb7863a233783f0514f, 47 testes digitais PASS).

## Delta funcional em cópia local

1. Geometria agora recusa `NaN`, infinito positivo/negativo, booleanos e registros não-dicionário antes de comparar folgas e aberturas. Ainda não existe medição física nem calibração: `physical_pass` sempre falso e o caminho positivo é só álgebra sintética.
2. `documentary_preflight` recusa registros não-dicionário e flags de segurança se os valores fornecidos não forem do tipo booleano estrito. Strings como `"false"` não são consideradas autorização e não podem contornar a recusa.
3. Criados 12 testes adversariais e de borda: 47→59 unitários digitais. O estágio permanece P3 PROPOSTO e o retorno positivo documental segue exigindo readback independente de evidências materiais efetivas; nunca confere RC5.

## Limites

Nenhuma peça/escudo/cristal real foi montada, nenhuma habilidade própria foi transmitida, nenhuma magia foi observada, nenhum PA é devido ou debitado com base neste estudo. F5 RED/C19 UNKNOWN-EFFECT; nenhuma atualização em ficha canônica/Party/O Primeiro, R48, PA, REC-ID ou E51. Conservar a v1 para comparação; este é hardening de **uma mesma proposta**, não segundo projeto e nem segunda receita.

## Reprodução

Executar `python code/run_replay.py` em diretório extraído limpo. Verificador do manifesto roda antes dos 59 unitários, compara snapshot e checa ausência de eventos físicos/mágicos/produtivos.
