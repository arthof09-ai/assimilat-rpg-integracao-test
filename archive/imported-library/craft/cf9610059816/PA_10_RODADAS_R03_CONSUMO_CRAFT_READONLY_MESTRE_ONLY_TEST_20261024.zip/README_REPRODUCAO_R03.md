# PA R03 — Contrato de consumo seguro do fornecedor R26 para CRAFT (MESTRE-ONLY TEST)

**RODADA 3/10, 24/10/2026. Operação PA existente.**

## Resultado material

- **46/46 métodos unittest PASS**, usando diretamente a função `avaliar()` de `parecer_semicanonico_r26.py` congelada no ZIP R51 e o gate de validação R02 já existente, nunca novo motor de tarifas.
- Dois casos equivalentes aos **recibos R39 congelados** (não descrições originais byte-idênticas): Pingente da Vigília Boreal = **12 PA/dia + 14 de duas ativações = 26 PA**; Botas do Explorador de Brumas = **25 PA/dia + 6 = 31 PA**. Coincidem com o projeto de recibo R51.
- **Risco preservado:** declaração de rank em texto livre pode gerar `rank_evidence='E0_MESTRE_EXPLICITO_EFEITO'` na saída interna, mesmo sendo somente input de teste. A projeção R03 não promove tal rótulo a E0: `authoritative_RE_E0=None` e `pa_approved=None`.
- **HOLD de cobrança se entrada ambígua:** nomes duplicados, chaves de usos não reconhecidas, rank de item inferior ao efeito, texto mecanicamente incompleto, item sem efeito (não faturar o piso sozinho), histórico (não reprecificar) e simulação de fonte natural sem feitiço próprio H1.
- **Integridade dos recibos históricos:** R03 fixa SHA-256 de duas fixtures originais e chama o módulo R51 sem alterá-lo; manipular preço, E0 ou escritor, mesmo com soma aritmeticamente válida, retorna HOLD.
- **HOLD em tudo que não é consulta:** prova real de magia instalada, PA realmente gasto, aprovação E0, item fabricado, RC5/P4, writer/lease/epoch e escritura Notion/Party.

## Reproduzir offline

1. Extrair este ZIP para um diretório local de teste.
2. Executar `python R03_REPLAY_COLD.py` com Python 3.10+ (biblioteca padrão).
3. O runner confere o SHA-256 do ZIP congelado R51, extrai os fontes originais para diretório temporário, executa `test_r03_consumer.py`, confere exatamente 46 testes e confronta `R03_CONSUMER_RESULTS.json` campo a campo.
4. Esperado: `COLD_REPLAY_PASS`, `test_methods_unique: 46`, `results_equal_pinned: true`, `production: HOLD`.

Arquivos-chave: `SOURCE_PA_R51_FROZEN.zip` (R26/R22 intactos), `R02_GATE_ENTRADA_TEST.py` (guard anterior), `R51_CONTRACT_ORIGINAL.py` (contrato anterior byte-idêntico), os dois recibos originais, `R03_CONSUMIDOR_READONLY_TEST.py` (projeção de consumo conservadora), `test_r03_consumer.py`, `R03_CONSUMER_RESULTS.json`, `R03_COLD_REPLAY_REPORT.json`, `R03_REPLAY_COLD.py`, `MANIFEST_SHA256.json` e `R03_CHECKPOINT_SUCESSAO.md`.

**Primeiro replay tentado:** falhou por ausência de `SOURCE_PA_R51_FROZEN.zip` no diretório extraído de teste; o runner foi corrigido para copiá-lo também. O replay seguinte PASSOU. Falha de empacotamento, não regressão de PA. Fontes R26/R22/R02/R51 não editadas.

## Limitações inegociáveis

- O CRAFT v1.2 **não foi executado** porque seus binários/pacote de integração nativa não foram materialmente recuperados neste turno; documentos Notion/handoff foram reabertos, mas **não substituem a execução nativa**.
- O adaptador original PA R27 **não foi reexecutado**. Não atribuir a este pacote o crédito histórico R39 510/510, nem a passagem da suíte antiga R01 ou R02.
- Concordância com recibos R39 significa somente consistência do **cenário E3** entre entradas estruturadas e evidências anteriores; não autentica rank RE E0, custo aplicado ou efeito observado.
- O campo `rank_item_declared_in_input` é uma observação da entrada, **não** verificação de RI E0; `rank_item_official=None` por design.
- O código R03 não substitui o fornecedor, não tem tabela de PA, não executa automação, não escreve no Notion nem integra de fato o runtime CRAFT.

## Fonte canônica de precedência

- PR-ITEM-02: https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4
- Handoff existente PA/CRAFT: https://app.notion.com/p/3ffc2b324ede81669f23c74ef48ceef8
- CRAFT existente OP-ARQ-RIN-REC-01: https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516
- LONG-RUN-01 §§15–16: https://app.notion.com/p/3f2c2b324ede8185b987dfe8470fce4e

Nunca criar OP de PA/CRAFT paralela ou reenviar este pacote Mestre-only à Party.
