"""R03: teste de CONTRATO DE CONSUMO do fornecedor existente, sem motor/PA novo.

MESTRE-ONLY / TEST. Encapsula resultados R26 + R02 (somente validação de entrada)
e faz projeção conservadora do recibo histórico já existente R51. Nunca escreve.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any

from R02_GATE_ENTRADA_TEST import avaliar_com_gate

ROOT = Path(__file__).resolve().parent
RECEIPT_HASHES = {
    'RECIBO_PINGENTE_R39.json': '909fcd2cb5b76060fa40411299a1a5dc4376e4e96f12749dca94e0b54cc86e13',
    'RECIBO_BOTAS_R39.json': '7d3553318bc4c749b0509730d09fbb10719de8b5acfd588aa7d8f0169827bfb8',
}


def _sha_bytes(buf: bytes) -> str:
    return hashlib.sha256(buf).hexdigest()


def _hold(why: str, *, source_sha256: str|None, details: dict|None=None) -> dict:
    return {'contract':'R03_PA_CRAFT_CONSUMER_READONLY_TEST',
            'state':'HOLD_'+why,
            'source_sha256':source_sha256,
            'scenario_pa':None,'authoritative_RE_E0':None,
            'rank_item_official':None,'pa_approved':None,'pa_debited':None,
            'magic_installed':None,'production':'HOLD',
            'item_created':False,'notion_write':False,'party_write':False,
            'extra':details or {}}


def consumir_consulta(texto: str, *, avaliar_nativo, usos: dict|None=None, origem='NOVO_TEST', pesquisa: dict|None=None) -> dict:
    """Never turns a semicanonical rank declaration into an authenticated E0.

    Call the EXISTING native R26, with prior R02 input gate, and read its result.
    No tariff formula lives here. Test source is external and pinned by runner.
    """
    raw_sha=_sha_bytes(texto.encode('utf8')) if isinstance(texto,str) else None
    if origem=='HISTORICO':
        # Historical items must never be silently repriced in a new consultation.
        return _hold('HISTORICO_NAO_REPRECIFICAR',source_sha256=raw_sha)
    result=avaliar_com_gate(texto,avaliar_nativo=avaliar_nativo,origem=origem,usos=usos,pesquisa=pesquisa)
    guard=result.get('r02_guard','')
    if guard.startswith('HOLD_'):
        return _hold('ENTRADA_AMBIGUA',source_sha256=raw_sha,
                     details={'input_guard':guard,'duplicate_labels':result.get('duplicate_labels_normalized',[]),
                              'unknown_usage_keys':result.get('unknown_usage_keys',[]),
                              'possible_exact_names':result.get('possible_exact_names',[])})
    native=result.get('r26',{})
    estimate=native.get('cenario_pa')
    if estimate is None:
        return _hold('MECANICA_OU_RANK_INSUFICIENTE',source_sha256=raw_sha,
                     details={'native_verdict':native.get('veredito'), 'issues':result.get('issues',[])})
    abilities=result.get('abilities',[])
    bonus=result.get('numeric_audit',{}).get('subtotal_reconhecido_pa',0)
    if not abilities and not bonus:
        return _hold('ITEM_SEM_EFEITO_DESCRITO',source_sha256=raw_sha,
                     details={'native_floor_only':True,'native_floor_not_authorized':True})
    keys=('pa_dia','pa_ativacoes','total_dia')
    if not all(type(estimate.get(k)) is int and estimate[k]>=0 for k in keys):
        return _hold('RECIBO_PA_INVALIDO',source_sha256=raw_sha)
    if estimate['pa_dia']+estimate['pa_ativacoes']!=estimate['total_dia']:
        return _hold('RECIBO_PA_INVALIDO',source_sha256=raw_sha)
    if native.get('producao')!='HOLD' or bool(result.get('official_classification')) or bool(result.get('canonical_write')):
        return _hold('AUTORIDADE_INCOMPATIVEL',source_sha256=raw_sha)
    # No claims that rank text or internal E0_MESTRE_EXPLICITO_EFEITO flag
    # is an authenticated decision of the real Mestre. It is just USER INPUT.
    return {'contract':'R03_PA_CRAFT_CONSUMER_READONLY_TEST',
            'state':'CONSULTA_E3_SEMICANONICA_NAO_HOMOLOGADA',
            'source_sha256':raw_sha,
            'scenario_pa':{'daily':estimate['pa_dia'],
                           'activations':estimate['pa_ativacoes'],
                           'scenario_total':estimate['total_dia']},
            'abilities_count':len(abilities),
            'rank_item_declared_in_input':str(result.get('item_rank_evidence','')).startswith('DECLARADO'),
            'effect_ranks_declared_in_input':any(a.get('rank_evidence')=='E0_MESTRE_EXPLICITO_EFEITO' for a in abilities),
            'rank_declaration_is_not_authenticated_e0':True,
            'authoritative_RE_E0':None,'rank_item_official':None,
            'pa_approved':None,'pa_debited':None,
            'magic_installed':None,'production':'HOLD',
            'item_created':False,'notion_write':False,'party_write':False,
            'extra':{'original_native_verdict':native.get('veredito'),
                     'source_engine':'R26_UNMODIFIED', 'input_guard':guard,
                     'semicanonical_notice':'E3; nao prova eficacia, classificacao E0 ou custo debitado'}}


def confrontar_recibos_congelados(*, receipts_dir:Path=ROOT, contrato_r51):
    """Confronts ONLY two PINNED receipts as read-only historical evidence.

    Hashes do not authenticate original E0 decisions or actual physical effects.
    Actual projection is delegated to the EXISTING R51 module.
    """
    receipts_dir=Path(receipts_dir)
    for name,expected in RECEIPT_HASHES.items():
        p=receipts_dir/name
        if not p.is_file() or _sha_bytes(p.read_bytes())!=expected:
            return _hold('RECIBO_HISTORICO_DESVIADO',source_sha256=None,
                         details={'source':name,'expected_sha256':expected})
    p=contrato_r51.derive(receipts_dir=receipts_dir)
    if p.get('type')!='READONLY_CONSULTATION_CONTRACT_R51_TEST' or len(p.get('records',[]))!=2:
        return _hold('CONTRATO_HISTORICO_INCOMPATIVEL',source_sha256=None)
    if any(r['production']!='HOLD' or r['re_individual_authoritative'] is not None or r['official_pa_authorization'] is not None or r['real_pa_consumed'] is not None for r in p['records']):
        return _hold('AUTORIDADE_HISTORICA_INVALIDA',source_sha256=None)
    return {'state':'RECIBOS_R39_CONGELADOS_R51_CONFRONTADOS_READONLY',
            'contract':'R03_PA_CRAFT_CONSUMER_READONLY_TEST',
            'receipt_count':len(p['records']),
            'pinned_receipts_sha256':RECEIPT_HASHES.copy(),
            'projection':p,
            'authoritative_RE_E0':None,'pa_debited':None,'production':'HOLD',
            'notion_write':False,'party_write':False}
