"""R51 contract: segregate R39 TEST cost estimates, adjudication, observed effects.

No actual PA debit, item creation, or Notion mutation is possible here.
"""
from __future__ import annotations
from pathlib import Path
import json,hashlib

ROOT=Path(__file__).resolve().parents[1]
CASEFILES={'botas':'RECIBO_BOTAS_R39.json','pingente':'RECIBO_PINGENTE_R39.json'}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def derive(receipts_dir=ROOT/'fixtures'):
    results=[]
    for name,fn in CASEFILES.items():
        fp=Path(receipts_dir)/fn
        d=json.loads(fp.read_text('utf8'))
        if d.get('uso_material_permitido') is not False:
            raise ValueError('EXPECTED_MATERIAL_USAGE_HOLD')
        if d.get('writer_lease_epoch') is not None or d.get('notion_write') is not False or d.get('party_write') is not False:
            raise ValueError('UNTRUSTED_WRITE_OR_LEASE')
        if not str(d.get('gate_nac_prod','')).startswith('HOLD;'):
            raise ValueError('PRODUCTION_GATE_NOT_HOLD')
        if 'RE_INDEPENDENTE_E0_NAO_PROVADO' not in d.get('estado_evidencia',''):
            raise ValueError('EFFECT_RANK_EVIDENCE_UNKNOWN')
        cost_day=d['pa_por_dia'];cost_usages=d['pa_ativacao_no_cenario'];total=d['pa_total_cenario']
        if not all(type(k) is int and k>=0 for k in (cost_day,cost_usages,total)) or total!=cost_day+cost_usages:
            raise ValueError('INVALID_SCENARIO_ARITHMETIC')
        results.append({
            'case_id':name,'source_sha256':sha(fp),'legacy_item_rank_from_input':d['rank_item'],
            're_individual_authoritative':None,'re_evidence':'E0_NOT_DEMONSTRATED',
            'scenario_pa':{'daily':cost_day,'activation_sum':cost_usages,'sum':total},
            'official_pa_authorization':None,'real_pa_consumed':None,
            'production':'HOLD','effect_installed':'UNVERIFIED','effect_measured':'UNVERIFIED',
            'scenario_not_physical_fact':True, 'party_write':False, 'notion_write':False})
    return {'type':'READONLY_CONSULTATION_CONTRACT_R51_TEST','records':results,
            'no_automatic_classification':True,'no_automatic_spend':True,
            'no_automatic_production':True,'authority_required':True}

if __name__=='__main__':
    print(json.dumps(derive(),ensure_ascii=False,sort_keys=True,indent=2))
