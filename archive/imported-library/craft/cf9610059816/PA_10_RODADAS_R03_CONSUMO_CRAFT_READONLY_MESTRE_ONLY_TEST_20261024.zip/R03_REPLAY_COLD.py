"""Independent, self-contained R03 cold replay for the existing PA R26 source.
MESTRE-ONLY TEST; requires Python standard library, never touches Notion/Party.
"""
from __future__ import annotations
import hashlib,json,subprocess,sys,tempfile,shutil,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE_SHA='635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f'
SHARED=['R02_GATE_ENTRADA_TEST.py','R51_CONTRACT_ORIGINAL.py','R03_CONSUMIDOR_READONLY_TEST.py','test_r03_consumer.py',
        'RECIBO_PINGENTE_R39.json','RECIBO_BOTAS_R39.json']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def go():
 assert sha(HERE/'SOURCE_PA_R51_FROZEN.zip')==SOURCE_SHA,'FROZEN_SOURCE_ZIP_SHA_FAILED'
 with tempfile.TemporaryDirectory(prefix='pa_r03_cold_') as temp:
  run=Path(temp)
  with zipfile.ZipFile(HERE/'SOURCE_PA_R51_FROZEN.zip') as z:
   for info in z.infolist():
    p=Path(info.filename)
    if p.is_absolute() or '..' in p.parts:raise ValueError('SOURCE_ZIP_PATH_TRAVERSAL')
   if z.testzip() is not None:raise ValueError('SOURCE_ZIP_CRC_FAILED')
   z.extractall(run)
  for n in SHARED:shutil.copyfile(HERE/n,run/n)
  # Test-source attestation also checks the outer ZIP, so include it in the portable replay.
  shutil.copyfile(HERE/'SOURCE_PA_R51_FROZEN.zip',run/'SOURCE_PA_R51_FROZEN.zip')
  cmd=subprocess.run([sys.executable,'test_r03_consumer.py'],cwd=run,env=None,
                     capture_output=True,text=True,timeout=120)
  if cmd.returncode:raise RuntimeError('TESTS_FAILED\n'+cmd.stdout+'\n'+cmd.stderr)
  if 'Ran 46 tests' not in cmd.stderr or 'OK' not in cmd.stderr:raise RuntimeError('UNEXPECTED_TEST_COUNT')
  expected=json.loads((HERE/'R03_CONSUMER_RESULTS.json').read_text('utf8'))
  observed=json.loads((run/'R03_CONSUMER_RESULTS.json').read_text('utf8'))
  if observed!=expected:raise RuntimeError('RESULTS_DIVERGED')
  report={'round':'R03','state':'COLD_REPLAY_PASS','test_methods_unique':46,
          'source_zip_sha256':SOURCE_SHA,
          'r26_source_sha256':sha(run/'baseline_r26'/'parecer_semicanonico_r26.py'),
          'results_sha256':sha(run/'R03_CONSUMER_RESULTS.json'),
          'results_equal_pinned':True,'test_log_first':cmd.stderr.splitlines()[0],
          'test_log_last':cmd.stderr.splitlines()[-1],
          'original_sources_changed':False,'remote_writes':0,'production':'HOLD'}
 (HERE/'R03_COLD_REPLAY_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
 return report

if __name__=='__main__':print(json.dumps(go(),ensure_ascii=False,indent=2))
