# Incidente de replay frio R03 — falha inicial e correção

O primeiro replay frio, antes de corrigir o runner, extraiu a árvore interna de `SOURCE_PA_R51_FROZEN.zip`, porém não copiou o próprio ZIP externo para o diretório temporário. O teste de proveniência `test_00_source_zip_unmodified` tentou abrir `./SOURCE_PA_R51_FROZEN.zip` e retornou `FileNotFoundError`; **45 métodos passaram, 1 teve ERROR** por problema de montagem da fixture (não houve teste funcional reprovado). A tentativa **não** conta como PASS.

A correção restrita foi adicionar `shutil.copyfile(HERE/'SOURCE_PA_R51_FROZEN.zip', run/'SOURCE_PA_R51_FROZEN.zip')` em `R03_REPLAY_COLD.py`. A segunda execução passou 46/46, com `results_equal_pinned=true`. O código original R26, R22, gate R02, contrato R51 e recibos congelados não foram modificados. Estado FINAL = PASS para replay TEST, não para produção.
