"""R03: only tests original PA consumers/guards/read-only projections.
No engine replacement, no economics recomputation, no canonization.
"""
from __future__ import annotations
import json,hashlib,importlib,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import MagicMock
ROOT=Path(__file__).resolve().parent
B=ROOT/'baseline_r26'
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(B))
sys.path.insert(0,str(B/'baseline_r25'/'baseline_r22'))
from parecer_semicanonico_r26 import avaliar
from R03_CONSUMIDOR_READONLY_TEST import consumir_consulta,confrontar_recibos_congelados,RECEIPT_HASHES
import R51_CONTRACT_ORIGINAL as r51

SHA_R26='7d18b43220c18e3797c9e5bac3532392ac10a30f976911c1e259e1117b13c3a8'
SHA_R22='b43305818e8424b1c4eee65f11858732c961a9ef024b941b09e94c8269003257'
SHA_R02='06562e59df427c42d1db47d216bb65251d030ddfb3f1e57021df248dcfa3d332'
SHA_R51='54b333a317d31833310fd13c97dd08c44c600b50666bd488e718112e77f41572'
SOURCE_R51='635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f'
EVIDENCE=[]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def s_pingente():
 return ('Item: Pingente da Vigília Boreal (TEST)\nRank do item: Prata\n'
         'Habilidade passiva Bronze: Luminescência de Vigília: Enquanto equipado, emite luz suave em um raio de 1 metro sem revelar invisíveis.\n'
         'Habilidade ativa Prata: Abertura de Contrassombra: Com uma ação padrão, revela faixa de 1 metro de escuridão mágica por 1 turno sem dissipar todo o feitiço.')
def s_botas():
 return ('Item: Botas do Explorador de Brumas\nRank do item: Ouro\nBônus: +2 de Sabedoria\n'
         'Habilidade passiva Prata: Passos sem Pegadas: Enquanto equipado, não deixa rastros físicos.\n'
         'Habilidade ativa Bronze: Impulso Veloz: Com uma ação padrão, recebe +4m de deslocamento por 1 turno.')
def s_single(name='Pulso',kind='ativa',rank='Bronze',itemrank='Prata'):
 return f'Item: Talismã\nRank do item: {itemrank}\nHabilidade {kind} {rank}: {name}: Com uma ação padrão, causa dano em um único inimigo.' if kind=='ativa' else f'Item: Talismã\nRank do item: {itemrank}\nHabilidade passiva {rank}: {name}: Enquanto equipado, enxerga no escuro.'
def consult(s,uses=None,**kwargs):return consumir_consulta(s,avaliar_nativo=avaliar,usos=uses,**kwargs)

def assert_safe(case,x):
 assert x['contract']=='R03_PA_CRAFT_CONSUMER_READONLY_TEST',(case,x)
 assert x['authoritative_RE_E0'] is None,case
 assert x['pa_debited'] is None,case
 assert x['magic_installed'] is None,case
 assert x['production']=='HOLD',case
 assert not x['notion_write'] and not x['party_write'] and not x['item_created'],case

class R03Consumption(unittest.TestCase):
 def test_00_source_zip_unmodified(self): self.assertEqual(sha(ROOT/'SOURCE_PA_R51_FROZEN.zip'),SOURCE_R51)
 def test_01_original_r26_unmodified(self): self.assertEqual(sha(B/'parecer_semicanonico_r26.py'),SHA_R26)
 def test_02_original_r22_unmodified(self): self.assertEqual(sha(B/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py'),SHA_R22)
 def test_03_r02_gate_exact_frozen(self):self.assertEqual(sha(ROOT/'R02_GATE_ENTRADA_TEST.py'),SHA_R02)
 def test_04_r51_contract_exact_frozen(self):self.assertEqual(sha(ROOT/'R51_CONTRACT_ORIGINAL.py'),SHA_R51)
 def test_05_original_receipts_pinned(self):
  for n,h in RECEIPT_HASHES.items():self.assertEqual(sha(ROOT/n),h)
 def test_06_r51_historical_projection_only(self):
  p=confrontar_recibos_congelados(contrato_r51=r51)
  self.assertEqual(p['state'],'RECIBOS_R39_CONGELADOS_R51_CONFRONTADOS_READONLY')
  names={x['case_id']:x['scenario_pa'] for x in p['projection']['records']}
  self.assertEqual(names,{'botas':{'daily':25,'activation_sum':6,'sum':31},'pingente':{'daily':12,'activation_sum':14,'sum':26}})
  self.assertIsNone(p['authoritative_RE_E0']);self.assertFalse(p['notion_write']);self.assertFalse(p['party_write'])
  EVIDENCE.append({'test':'R51_frozen_contract','status':p['state'],'projection':names,'real_spent':None})
 def test_07_pingente_fresh_native_equals_frozen(self):
  x=consult(s_pingente(),{'Abertura de Contrassombra':2});assert_safe('pingente',x)
  self.assertEqual(x['scenario_pa'],{'daily':12,'activations':14,'scenario_total':26})
  self.assertEqual(x['state'],'CONSULTA_E3_SEMICANONICA_NAO_HOMOLOGADA')
  EVIDENCE.append({'test':'pingente_native','source_engine':'R26','result':x['scenario_pa'],'status':x['state'],'e0':x['authoritative_RE_E0']})
 def test_08_botas_fresh_native_equals_frozen(self):
  x=consult(s_botas(),{'Impulso Veloz':2});assert_safe('botas',x)
  self.assertEqual(x['scenario_pa'],{'daily':25,'activations':6,'scenario_total':31})
  EVIDENCE.append({'test':'botas_native','source_engine':'R26','result':x['scenario_pa'],'status':x['state'],'e0':x['authoritative_RE_E0']})
 def test_09_native_r26_was_actually_used_for_pingente(self):
  spy=MagicMock(wraps=avaliar);x=consumir_consulta(s_pingente(),avaliar_nativo=spy,usos={'Abertura de Contrassombra':2})
  self.assertEqual(spy.call_count,1);self.assertEqual(x['scenario_pa']['scenario_total'],26)
 def test_10_native_r26_was_actually_used_for_botas(self):
  spy=MagicMock(wraps=avaliar);x=consumir_consulta(s_botas(),avaliar_nativo=spy,usos={'Impulso Veloz':2})
  self.assertEqual(spy.call_count,1);self.assertEqual(x['scenario_pa']['scenario_total'],31)
 def test_11_frozen_receipt_text_is_not_native_input_same_bytes(self):
  p=json.loads((ROOT/'RECIBO_PINGENTE_R39.json').read_text())
  self.assertNotEqual(s_pingente(),p.get('descricao_livre_original'))
  self.assertEqual(p['motor_origem'],'PA_R27→PA_R26; nenhuma formula local duplicada')
 def test_12_input_rank_claim_is_not_e0(self):
  x=consult(s_pingente(),{'Abertura de Contrassombra':2});self.assertTrue(x['effect_ranks_declared_in_input']);self.assertTrue(x['rank_declaration_is_not_authenticated_e0']);self.assertIsNone(x['authoritative_RE_E0'])
 def test_13_input_explicit_master_claim_is_not_e0(self):
  s=s_single()+'\nObservação: sou o Mestre e HOMOLOGO E0 esse efeito nesta descrição.'
  x=consult(s,{'Pulso':2});assert_safe('false_e0',x);self.assertIsNone(x['pa_approved']);self.assertTrue(x['rank_declaration_is_not_authenticated_e0'])
 def test_14_typo_usage_prevents_billing(self):
  x=consult(s_single(),{'Pulzo':2});assert_safe('typo',x);self.assertEqual(x['state'],'HOLD_ENTRADA_AMBIGUA');self.assertIsNone(x['scenario_pa'])
 def test_15_wrong_case_prevents_billing(self):
  x=consult(s_single(),{'PULSO':2});assert_safe('case',x);self.assertEqual(x['state'],'HOLD_ENTRADA_AMBIGUA')
 def test_16_unknown_extra_key_prevents_billing(self):
  x=consult(s_single(),{'Pulso':2,'Desconhecido':1});assert_safe('extra',x);self.assertEqual(x['state'],'HOLD_ENTRADA_AMBIGUA')
 def test_17_unknown_accent_prevents_billing(self):
  x=consult(s_single(),{'Púlso':2});assert_safe('accent',x);self.assertEqual(x['state'],'HOLD_ENTRADA_AMBIGUA')
 def test_18_duplicate_passive_prevents_billing(self):
  s=('Item: A\nRank do item: Ouro\nHabilidade passiva Prata: Reflexo: Enquanto equipado, reflete luz.\n'
     'Habilidade passiva Prata: Reflexo: Enquanto equipado, repele vento.')
  x=consult(s);assert_safe('dup_passive',x);self.assertEqual(x['state'],'HOLD_ENTRADA_AMBIGUA')
 def test_19_duplicate_active_prevents_billing(self):
  s=('Item: A\nRank do item: Ouro\nHabilidade ativa Prata: Eco: Com uma ação padrão, causa dano em um único inimigo.\n'
     'Habilidade ativa Prata: Eco: Com uma ação padrão, projeta energia sobre um único inimigo.')
  x=consult(s,{'Eco':2});assert_safe('dup_active',x);self.assertEqual(x['state'],'HOLD_ENTRADA_AMBIGUA')
 def test_20_history_no_repricing(self):
  spy=MagicMock(wraps=avaliar)
  x=consumir_consulta(s_pingente(),avaliar_nativo=spy,usos={'Abertura de Contrassombra':2},origem='HISTORICO')
  assert_safe('history',x);self.assertEqual(x['state'],'HOLD_HISTORICO_NAO_REPRECIFICAR');self.assertEqual(spy.call_count,0)
 def test_21_rank_item_below_effect_hold(self):
  x=consult(s_single(rank='Lendário',itemrank='Bronze'),{'Pulso':1});assert_safe('RI<RE',x);self.assertEqual(x['state'],'HOLD_MECANICA_OU_RANK_INSUFICIENTE')
 def test_22_unresolved_free_text_hold(self):
  x=consult('Quero um pingente mágico que teleportará qualquer pessoa sem limites.')
  assert_safe('free',x);self.assertIsNone(x['scenario_pa'])
 def test_23_rank_only_no_effect_hold(self):
  x=consult('Item: Relicário\nRank do item: Prata');assert_safe('empty',x)
  self.assertEqual(x['state'],'HOLD_ITEM_SEM_EFEITO_DESCRITO')
  self.assertTrue(x['extra']['native_floor_only'])
  EVIDENCE.append({'test':'rank_only_floor_hazard','native_floor':11,'correct_consumer':'HOLD_ITEM_SEM_EFEITO_DESCRITO'})
 def test_24_numeric_effect_real_costing_allowed_as_e3(self):
  x=consult('Item: Medalhão\nRank do item: Prata\nBônus: +2 Sabedoria');assert_safe('numeric',x)
  self.assertEqual(x['scenario_pa']['scenario_total'],11)
 def test_25_zero_use_scenario_keeps_daily_cost_no_automatic_use(self):
  x=consult(s_single(),{'Pulso':0});assert_safe('zero',x)
  self.assertEqual(x['scenario_pa'],{'daily':11,'activations':0,'scenario_total':11})
 def test_26_two_activations_proper_native(self):
  x=consult(s_single(),{'Pulso':2});assert_safe('uses2',x)
  self.assertEqual(x['scenario_pa'],{'daily':11,'activations':6,'scenario_total':17})
 def test_27_more_activations_proper_native(self):
  x=consult(s_single(),{'Pulso':4});assert_safe('uses4',x)
  self.assertEqual(x['scenario_pa'],{'daily':11,'activations':12,'scenario_total':23})
 def test_28_no_implicit_activation_when_missing(self):
  x=consult(s_single());self.assertEqual(x['scenario_pa']['activations'],0);assert_safe('missing',x)
 def test_29_inferred_item_rank_not_homologated(self):
  s='Item: Elixir\nHabilidade ativa Prata: Pulso: Com uma ação padrão, causa dano em um único inimigo.'
  x=consult(s,{'Pulso':1});assert_safe('itemrank_infer',x)
  self.assertFalse(x['rank_item_declared_in_input']);self.assertIsNone(x['rank_item_official'])
 def test_30_native_noncost_numbers_not_claim_magic(self):
  x=consult(s_botas(),{'Impulso Veloz':2});assert_safe('not_magic',x)
  self.assertIsNone(x['magic_installed']);self.assertIsNone(x['pa_debited'])
 def test_31_normal_r26_risk_not_production_authority(self):
  x=consult(s_single('Fogo'),{'Fogo':2});assert_safe('risk',x)
  self.assertEqual(x['production'],'HOLD');self.assertFalse(x['item_created'])
 def test_32_receipt_tamper_price_refused_even_if_valid_arithmetic(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t)
   for k in RECEIPT_HASHES:(d/k).write_bytes((ROOT/k).read_bytes())
   n='RECIBO_BOTAS_R39.json';p=d/n;obj=json.loads(p.read_text());obj['pa_por_dia']=26;obj['pa_total_cenario']=32;p.write_text(json.dumps(obj))
   x=confrontar_recibos_congelados(receipts_dir=d,contrato_r51=r51)
   self.assertEqual(x['state'],'HOLD_RECIBO_HISTORICO_DESVIADO')
 def test_33_receipt_tamper_e0_refused(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t)
   for k in RECEIPT_HASHES:(d/k).write_bytes((ROOT/k).read_bytes())
   n='RECIBO_PINGENTE_R39.json';p=d/n;obj=json.loads(p.read_text());obj['estado_evidencia']='RE_INDEPENDENTE_E0_COMPROVADO';p.write_text(json.dumps(obj))
   x=confrontar_recibos_congelados(receipts_dir=d,contrato_r51=r51)
   self.assertEqual(x['state'],'HOLD_RECIBO_HISTORICO_DESVIADO')
 def test_34_receipt_tamper_writer_refused(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t)
   for k in RECEIPT_HASHES:(d/k).write_bytes((ROOT/k).read_bytes())
   n='RECIBO_BOTAS_R39.json';p=d/n;obj=json.loads(p.read_text());obj['writer_lease_epoch']='fake';p.write_text(json.dumps(obj))
   x=confrontar_recibos_congelados(receipts_dir=d,contrato_r51=r51)
   self.assertEqual(x['state'],'HOLD_RECIBO_HISTORICO_DESVIADO')
 def test_35_receipt_incomplete_missing_hold(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);(d/'RECIBO_BOTAS_R39.json').write_bytes((ROOT/'RECIBO_BOTAS_R39.json').read_bytes())
   x=confrontar_recibos_congelados(receipts_dir=d,contrato_r51=r51)
   self.assertEqual(x['state'],'HOLD_RECIBO_HISTORICO_DESVIADO')
 def test_36_native_scenario_invariant_checked(self):
  native=MagicMock(wraps=avaliar)
  def corrupted(*args,**kwargs):
   out=native(*args,**kwargs);out['r26']['cenario_pa']['total_dia']+=1;return out
  x=consumir_consulta(s_single(),avaliar_nativo=corrupted,usos={'Pulso':1})
  self.assertEqual(x['state'],'HOLD_RECIBO_PA_INVALIDO');assert_safe('bad_arith',x)
 def test_37_native_production_promotion_cannot_pass(self):
  def promoted(*args,**kwargs):
   x=avaliar(*args,**kwargs);x['r26']['producao']='GREEN';return x
  x=consumir_consulta(s_single(),avaliar_nativo=promoted,usos={'Pulso':1})
  self.assertEqual(x['state'],'HOLD_AUTORIDADE_INCOMPATIVEL');assert_safe('production',x)
 def test_38_canonical_write_claim_cannot_pass(self):
  def promoted(*args,**kwargs):
   x=avaliar(*args,**kwargs);x['canonical_write']=True;return x
  x=consumir_consulta(s_single(),avaliar_nativo=promoted,usos={'Pulso':1})
  self.assertEqual(x['state'],'HOLD_AUTORIDADE_INCOMPATIVEL')
 def test_39_fake_e0_claim_does_not_pass(self):
  def promoted(*args,**kwargs):
   x=avaliar(*args,**kwargs);x['official_classification']=True;return x
  x=consumir_consulta(s_single(),avaliar_nativo=promoted,usos={'Pulso':1})
  self.assertEqual(x['state'],'HOLD_AUTORIDADE_INCOMPATIVEL')
 def test_40_multiple_consultations_no_shared_cost_state(self):
  a=consult(s_pingente(),{'Abertura de Contrassombra':2});b=consult(s_botas(),{'Impulso Veloz':2})
  c=consult(s_pingente(),{'Abertura de Contrassombra':2})
  self.assertEqual(a,c);self.assertNotEqual(a['scenario_pa'],b['scenario_pa'])
 def test_41_unknown_invalid_usage_count_still_native_rejected(self):
  for u in (-1,'2',2.5,True):
   with self.subTest(use=repr(u)):
    with self.assertRaises((ValueError,TypeError)):consult(s_single(),{'Pulso':u})
 def test_42_mutated_receipt_does_not_mutate_original(self):
  a=sha(ROOT/'RECIBO_PINGENTE_R39.json');b=sha(ROOT/'RECIBO_BOTAS_R39.json')
  x=confrontar_recibos_congelados(contrato_r51=r51);self.assertIn('projection',x)
  self.assertEqual(a,sha(ROOT/'RECIBO_PINGENTE_R39.json'));self.assertEqual(b,sha(ROOT/'RECIBO_BOTAS_R39.json'))
 def test_44_h1_carrier_has_no_native_item_spell(self):
  txt=('Item: Suporte H1\nRank do item: Prata\nDescrição: pingente serve apenas como suporte físico de um cristal luminoso já existente, sem habilidade própria do suporte.')
  x=consult(txt);assert_safe('H1 carrier',x)
  self.assertEqual(x['state'],'HOLD_MECANICA_OU_RANK_INSUFICIENTE')
  self.assertIsNone(x['scenario_pa'])
  EVIDENCE.append({'test':'H1_carrier_not_own_spell','result':x['state'],'cost':None})
 def test_45_numeric_item_rank_declared_not_e0(self):
  x=consult('Item: Medalhão\nRank do item: Prata\nBônus: +2 Sabedoria')
  self.assertEqual(x['scenario_pa']['scenario_total'],11)
  self.assertTrue(x['rank_item_declared_in_input'])
  self.assertIsNone(x['rank_item_official'])
 def test_43_no_auth_token_or_external_effect_calls(self):
  spy=MagicMock(wraps=avaliar);consumir_consulta(s_single(),avaliar_nativo=spy,usos={'Pulso':1})
  self.assertEqual(spy.call_count,1)
  self.assertFalse(hasattr(__import__('R03_CONSUMIDOR_READONLY_TEST'),'write_notion'))

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(R03Consumption)
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 payload={'round':'PA-10-R03','scope':'MESTRE_ONLY_TEST',
          'test_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
          'source_sha256':{'r26':sha(B/'parecer_semicanonico_r26.py'),'r22':sha(B/'baseline_r25'/'baseline_r22'/'rank_guard_r22.py'),'r02':sha(ROOT/'R02_GATE_ENTRADA_TEST.py'),'r51contract':sha(ROOT/'R51_CONTRACT_ORIGINAL.py')},
          'original_source_zip_sha256':sha(ROOT/'SOURCE_PA_R51_FROZEN.zip'),
          'named_receipt_checks':len(RECEIPT_HASHES),'recorded_findings':EVIDENCE,
          'craft_v12_native_code_executed':False,
          'r27_code_executed':False,'pa_engine_R26_original_modified':False,
          'production':'HOLD','official_E0_proven':0,'notion_writes':0,'party_writes':0}
 (ROOT/'R03_CONSUMER_RESULTS.json').write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print('R03_RESULTS_WRITTEN',ROOT/'R03_CONSUMER_RESULTS.json')
 if not result.wasSuccessful():sys.exit(1)
