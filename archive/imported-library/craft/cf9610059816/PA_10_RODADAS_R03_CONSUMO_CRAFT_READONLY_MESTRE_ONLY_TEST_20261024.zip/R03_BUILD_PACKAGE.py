"""Build deterministic Master-only R03 archival bundle + readback checks.
No network/Notion operations here.
"""
from __future__ import annotations
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
NAME='PA_10_RODADAS_R03_CONSUMO_CRAFT_READONLY_MESTRE_ONLY_TEST_20261024.zip'
CONTENTS=[
 'SOURCE_PA_R51_FROZEN.zip',
 'R02_GATE_ENTRADA_TEST.py',
 'R51_CONTRACT_ORIGINAL.py',
 'RECIBO_PINGENTE_R39.json','RECIBO_BOTAS_R39.json',
 'R03_CONSUMIDOR_READONLY_TEST.py','test_r03_consumer.py',
 'R03_CONSUMER_RESULTS.json','R03_TEST_STDOUT.log',
 'R03_REPLAY_COLD.py','R03_COLD_REPLAY_REPORT.json','R03_REPLAY_LOG.txt','R03_COLD_FIRST_FAIL_AUDIT.md',
 'README_REPRODUCAO_R03.md','R03_CHECKPOINT_SUCESSAO.md',
 'R03_BUILD_PACKAGE.py'
]

def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 assert len(CONTENTS)==len(set(CONTENTS))
 files={n:(ROOT/n).read_bytes() for n in CONTENTS}
 assert sha(files['SOURCE_PA_R51_FROZEN.zip'])=='635148abd24bc32799cdc56b2efa759bdcfe649376a47e4e339714985e269a9f'
 assert json.loads(files['R03_CONSUMER_RESULTS.json'])['test_methods']==46
 assert json.loads(files['R03_COLD_REPLAY_REPORT.json'])['state']=='COLD_REPLAY_PASS'
 manifest={'round':'R03','scope':'MESTRE_ONLY_TEST','operator':'PA existent',
    'status':'TEST_PASSED_CRAFT_PROD_HOLD','source_origin':'R51 original frozen',
    'output_evidence':{'unittest_methods_unique':46,'historical_r39_receipts':2,'native_r26_scenario_replayed':2,'r27_reexecuted':False,'craft_v12_executed':False,'notion_write':False,'party_write':False},
    'entries':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}}
 mf=(json.dumps(manifest,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode()
 (ROOT/'MANIFEST_SHA256.json').write_bytes(mf)
 dest=ROOT/NAME
 with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in [*files.items(),('MANIFEST_SHA256.json',mf)]:
   info=zipfile.ZipInfo(n,(2026,10,24,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   info.external_attr=0o644<<16
   z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(CONTENTS)+1
  for n in CONTENTS:
   b=z.read(n)
   assert sha(b)==manifest['entries'][n]['sha256']
 report={'name':NAME,'sha256':sha(dest.read_bytes()),'size':dest.stat().st_size,
         'entries':len(CONTENTS)+1,'entries_verified':len(CONTENTS)+1,
         'crc':'PASS','manifest_sha256':sha(mf),
         'test_methods_unique':46,'no_source_mutation':True}
 (ROOT/'R03_BUILD_VERIFICATION.json').write_text(json.dumps(report,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
