"""R02: validation-only wrapper for *unchanged* original R26.
Master-only TEST. Not a replacement PA calculator; NEVER claims canonical E0/PROD.
A close-looking pair of abilities with the same normalized label is ambiguous.
Do not bill or infer that they are two independent powers.
"""
from __future__ import annotations
from collections import Counter
import re
import unicodedata

def normalized_label(s: str) -> str:
    s = unicodedata.normalize('NFKD', s.casefold())
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return ' '.join(s.split())

def avaliar_com_gate(descricao: str, *, avaliar_nativo, origem='NOVO_TEST', usos=None, pesquisa=None):
    """Only protects a known gap; delegates *every tariff* to the original R26.
    Rejects duplicates before publishing any incomplete billing result.
    Caller is responsible for normal R26 evidence/authority gates downstream.
    """
    native = avaliar_nativo(descricao, origem=origem, usos=usos, pesquisa=pesquisa)
    abilities = native.get('abilities', [])
    labels = [normalized_label(a.get('name', '')) for a in abilities]
    duplicates = sorted(k for k, n in Counter(labels).items() if n > 1)
    blanks = [i for i, x in enumerate(labels) if not x]
    supplied_names = list(usos.keys()) if isinstance(usos, dict) else []
    native_names = [a.get('name','') for a in abilities]
    unknown_use_keys = [k for k in supplied_names if k not in native_names]
    # R26 matches use-count keys EXACTLY; case/accent near matches must never
    # silently become zero activations or be automatically corrected.
    if duplicates or blanks or unknown_use_keys:
        return {
            'r02_guard': 'HOLD_INPUT_AMBIGUOUS_ABILITY_ID' if (duplicates or blanks) else 'HOLD_INPUT_USAGE_KEY_MISMATCH',
            'duplicate_labels_normalized': duplicates,
            'blank_ability_indices': blanks,
            'unknown_usage_keys': [str(k) for k in unknown_use_keys],
            'possible_exact_names': native_names if unknown_use_keys else [],
            'ability_count': len(abilities),
            'cenario_pa': None,
            'official_classification': False,
            'canonical_write': False,
            'reason': 'Ambiguous skill identifier or activation key not matched exactly: reconcile inputs; no billing emitted.',
            'source': 'UNMODIFIED_R26_VALIDATED_BUT_NOT_DISCLOSED',
            'scope': 'MESTRE_ONLY_TEST',
        }
    native['r02_guard'] = 'PASS_UNIQUE_ABILITY_IDENTIFIERS' if abilities else 'PASS_NO_ABILITY_IDENTIFIERS'
    return native
