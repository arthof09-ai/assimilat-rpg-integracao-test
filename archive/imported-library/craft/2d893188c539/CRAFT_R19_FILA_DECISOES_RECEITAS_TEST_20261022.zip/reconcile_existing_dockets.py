'''CRAFT R19: ONE-OFF read-only join; NOT a new recipe engine/norm/Notion writer.'''
import csv,io,json,zipfile,collections,pathlib,hashlib
root=pathlib.Path(__file__).resolve().parent
source_docket=root/'inputs/CRAFT_DECISION_DOCKET_34_20261021.zip'
source_readback=root/'inputs/R15_READBACK_29_RECIPES.csv'
assert source_docket.exists() and source_readback.exists()
with zipfile.ZipFile(source_docket) as z:
 assert z.testzip() is None
 decisions=list(csv.DictReader(io.StringIO(z.read('DECISIONS_21.csv').decode('utf-8-sig'))))
 register=json.loads(z.read('DECISION_REGISTER.json'))
readback=list(csv.DictReader(source_readback.open(encoding='utf-8-sig')))
assert len(decisions)==21 and len(readback)==29
assert len({x['physical_recipe_id'] for x in decisions})==21
assert len({x['physical_recipe_uuid'] for x in readback})==29
by_uuid={row['physical_recipe_uuid']:row for row in readback}
assert all(d['physical_recipe_id'] in by_uuid for d in decisions)
priority_order=['P0_RECEITA_P2','P1_REFERENCIA_CONSUMO','P1_PROCESSO','P2_IDENTIDADE','P3_DOCUMENTO']
priority_next={
 'P0_RECEITA_P2':'Mestre/autor: reconciliar Sal de Geodo Santo versus Encantado e escolha/etapa da fonte de energia; não tratar alternativa como insumo simultâneo.',
 'P1_REFERENCIA_CONSUMO':'Mestre/autor: identificar ingrediente por fonte/UUID, resolver quantidade não numérica e uso BOM↔processo; não reparar por proximidade lexical.',
 'P1_PROCESSO':'Mestre/autor: comparar sequência, insumo e função de cada nó; registrar etapa ausente e compatibilidade com receita-base.',
 'P2_IDENTIDADE':'Mestre/autor: decidir igualdade, variante ou ingredientes distintos; buscar ficha canônica e preservar nomes históricos até decisão.',
 'P3_DOCUMENTO':'Mestre/autor: corrigir sequência editorial/sinalização de etapas SEM inventar física, quantidade, efeito ou ingredientes.'}
rows=[]
for d in decisions:
 rb=by_uuid[d['physical_recipe_id']]
 assert rb['docket_class']=='DIVERGENCE_DOCUMENTED'
 assert rb['original_docket_priority']==d['priority']
 assert rb['source_url' if 'source_url' in rb else 'url']==d['source_url']
 oil='NAMED_BOM' if rb['oil_named_in_BOM']=='YES' else 'BROKEN_REF_REQUIRES_IDENTITY_DECISION'
 assert rb['oil_mentioned']=='YES'
 rows.append({
   'pattern_key':d['pattern_key'],'physical_recipe_uuid':d['physical_recipe_id'],
   'source_url':d['source_url'],'family':d['family'],'priority_existing':d['priority'],
   'issue_existing':d['issues_from_live_snapshot'],
   'oil_role_state':oil,'last_edited_at_r15':rb['live_last_edited'],
   'last_edited_after_docket_r15':rb['after_2026_10_21_docket'],
   'question_to_authority':priority_next[d['priority']],
   'owner':'Mestre ou autor legitimamente competente da receita',
   'source_ticket':'IBX-116 existente',
   'relink_or_recipe_write_allowed':False,'rc5_claim_allowed':False,
   'source_reopened_this_turn':d['physical_recipe_id'] in {
     '3edc2b324ede81faafa2ce406944d9b6',
     '3edc2b324ede8129a6c3cfb603027383',
     '3edc2b324ede811783dfce62058ca6b8'},
   'decision_status':'PENDENTE_AUTORAL_NO_WRITE'})
rows.sort(key=lambda x:(priority_order.index(x['priority_existing']),x['pattern_key'],x['physical_recipe_uuid']))
assert len(rows)==21
counts=collections.Counter(x['priority_existing'] for x in rows)
assert counts=={'P0_RECEITA_P2':1,'P1_REFERENCIA_CONSUMO':2,'P1_PROCESSO':3,'P2_IDENTIDADE':13,'P3_DOCUMENTO':2}
assert sum(x['oil_role_state']=='NAMED_BOM' for x in rows)==20
assert sum(x['oil_role_state']!='NAMED_BOM' for x in rows)==1
assert {x['physical_recipe_uuid'] for x in readback if x['docket_class']!='DIVERGENCE_DOCUMENTED'}.isdisjoint({x['physical_recipe_uuid'] for x in rows})
assert sum(x['oil_named_in_BOM']=='YES' for x in readback)==28
assert sum(x['oil_mentioned']=='YES' for x in readback)==29
assert sum(x['after_2026_10_21_docket']=='YES' for x in readback)==0
payload={
 'schema':'CRAFT_R19_CROSSWALK_EXISTING_TEST_V1','classification':'MESTRE-SIDE_READ_ONLY_NO_WRITE',
 'inputs':{
  'legacy_docket_sha256':hashlib.sha256(source_docket.read_bytes()).hexdigest(),
  'r15_readback_sha256':hashlib.sha256(source_readback.read_bytes()).hexdigest(),
  'legacy_docket_name':source_docket.name,
  'r15_readback_name':source_readback.name,
  'fresh_reopen_this_turn_2026_10_22':['ENC-08','MAT-03','MAT-06','OLEO_MESTRE'],
  'fresh_reopen_is_not_29_29_revalidation':True},
 'scope':{'pattern_pages_historical':34,'physical_recipe_pages_historical':29,'divergences_in_existing_docket':21,'no_divergence_identified_not_rc5':8,'distinct_recipe_uuids_joined':21,'oil_named_bom_in_29':28,'oil_named_bom_in_21':20,'oil_mentioned_anywhere_in_29':29,'production_rc5_proved_by_this_package':0},
 'priority_distribution':dict(counts),
 'dependency_order_suggested_read_only':[
  '0: STOP material/F5 e C19-021 UNKNOWN / fencing IBX38; bloqueiam qualquer mutação',
  '1: R51 parent físico REC-LIB e anti-duplicidade; não criar biblioteca por hipótese',
  '2: Upstream Óleo Mestre — divergência interna BOM/processo, 28 usos nomeados; não substituir dado Mestre pelo Espelho Party',
  '3: ENC-08 — decidir Sal Santo/Encantado e Pedra da Luz OU Pote de Essência Mágica (apenas 1 receita)',
  '4: MAT-03 — determinar identidade da referência apagada 1x; reparar somente após autorização; não confundir com página-pai',
  '5: MAT-06 — resolver Ex (quantidade inválida) com decisão autoral; não inferir 1x',
  '6: 3 casos P1_PROCESSO, 13 casos P2_IDENTIDADE, 2 casos P3_DOCUMENTO, preservando UUID e variante por receita'],
 'items':rows,'gates':{'can_write_notion':False,'can_claim_rec_id':False,'can_produce':False,'can_publish_party':False,'can_claim_fencing':False,'requires_authority':True},
 'disclaimer':'Reorganização dos registros R15 e dossiê já existentes; não corrige física, não descobre ingrediente e não é norma.'}
(root/'R19_CROSSWALK_21_RECIPES_TEST.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
with (root/'R19_QUEUE_21_RECIPES_TEST.csv').open('w',encoding='utf-8',newline='') as f:
 fieldnames=list(rows[0].keys());w=csv.DictWriter(f,fieldnames);w.writeheader();w.writerows(rows)
print(json.dumps({'status':'PASS_READ_ONLY','rows':len(rows),'priority_counts':dict(counts),'oil_named_in21':20,'oil_broken_identity_in21':1,'oil_named_in29':28,'r15_reopened_full_this_turn':False,'gates':payload['gates']},ensure_ascii=False))
