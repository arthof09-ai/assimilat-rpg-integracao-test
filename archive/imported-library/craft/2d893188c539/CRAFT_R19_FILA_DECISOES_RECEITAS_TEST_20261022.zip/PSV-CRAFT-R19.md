# PSV CRAFT R19 — Fila de 21 decisões existentes

**ANTES:** R15 possuía 29/29 páginas auditadas, 21 divergências, 28 nomes explícitos de Óleo em BOM, uma menção quebrada. Docket anterior de 34 Padrões (29 receitas-filhas, 5 casos de receita embutida) já tinha grupos de P0 a P3, sem autorização de gravação.

**DEPOIS:** cruzamento read-only auditável entre R15 CSV e docket imutável de 21. 21/21 UUIDs únicos, 20 chaves de padrão, `MAT-01` reconhecido em duas variantes físicas. Grupos 1 P0 +2 P1_REFERENCIA +3 P1_PROCESSO +13 P2_IDENTIDADE +2 P3_DOCUMENTO; 20/21 óleos nominados na BOM e uma menção de ingrediente quebrada em MAT-03. 29/29 escopo R15 mantido como histórico; R19 reabriu no Notion apenas ENC-08, MAT-03, MAT-06 e ficha de Óleo fora do universo 29. Nenhuma aprovação RC5 inferida das oito linhas sem conflito apontado.

**GATE:** apenas relatório, CSV e JSON TEST; priorizações não substituem autoria, NAC-NORM, NAC-PASS, NAC-CONT-03, IBX38, C19 ou R51. F5 P0 RED, writer/lease/epoch/ACK ausentes, Party/O Primeiro NO-WRITE. 0 Notion write/0 receita materializada/0 estoque.

**QA:** `reconcile_existing_dockets.py` reproduz o cruzamento a partir das duas fontes preservadas; `test_reconciliation_r19.py` 37/37 invariantes; hashes e CRC verificáveis. Atestado apenas de integridade e método read-only, não de correção de receita física.
