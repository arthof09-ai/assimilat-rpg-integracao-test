'''Tests only the traceability of an existing (not canonical) docket join.'''
import json,csv,collections,pathlib,hashlib,zipfile,subprocess
root=pathlib.Path(__file__).parent
p=json.loads((root/'R19_CROSSWALK_21_RECIPES_TEST.json').read_text())
rows=list(csv.DictReader((root/'R19_QUEUE_21_RECIPES_TEST.csv').open()))
count=0
def ck(x):
 global count
 assert x,count
 count+=1
ck(p['schema']=='CRAFT_R19_CROSSWALK_EXISTING_TEST_V1')
ck(p['classification']=='MESTRE-SIDE_READ_ONLY_NO_WRITE')
ck(len(rows)==len(p['items'])==21)
ck(p['scope']['physical_recipe_pages_historical']==29)
ck(p['scope']['pattern_pages_historical']==34)
ck(p['scope']['no_divergence_identified_not_rc5']==8)
ck(p['scope']['oil_named_bom_in_29']==28)
ck(p['scope']['oil_named_bom_in_21']==20)
ck(p['scope']['oil_mentioned_anywhere_in_29']==29)
ck(p['scope']['production_rc5_proved_by_this_package']==0)
ck(len({r['physical_recipe_uuid'] for r in rows})==21)
ck(len({r['pattern_key'] for r in rows})==20)
ck(len([r for r in rows if r['pattern_key']=='MAT-01'])==2)
ck(len({r['physical_recipe_uuid'] for r in rows if r['pattern_key']=='MAT-01'})==2)
ck(all(r['source_url'].endswith(r['physical_recipe_uuid']) for r in rows))
ck(all(r['decision_status']=='PENDENTE_AUTORAL_NO_WRITE' for r in rows))
ck(all(r['relink_or_recipe_write_allowed']=='False' for r in rows))
ck(all(r['rc5_claim_allowed']=='False' for r in rows))
ck(all(r['source_ticket']=='IBX-116 existente' for r in rows))
ck(sum(r['oil_role_state']=='NAMED_BOM' for r in rows)==20)
ck(sum(r['oil_role_state']=='BROKEN_REF_REQUIRES_IDENTITY_DECISION' for r in rows)==1)
ck(len([r for r in rows if r['oil_role_state']=='BROKEN_REF_REQUIRES_IDENTITY_DECISION' and r['pattern_key']=='MAT-03'])==1)
ck(collections.Counter(r['priority_existing'] for r in rows)==p['priority_distribution'])
ck(sum(p['priority_distribution'].values())==21)
ck(set(p['priority_distribution'])=={'P0_RECEITA_P2','P1_REFERENCIA_CONSUMO','P1_PROCESSO','P2_IDENTIDADE','P3_DOCUMENTO'})
ck(all(x['source_reopened_this_turn']==(x['pattern_key'] in {'MAT-03','MAT-06','ENC-08'}) for x in p['items']))
ck(p['inputs']['fresh_reopen_is_not_29_29_revalidation'] is True)
ck(len(p['inputs']['fresh_reopen_this_turn_2026_10_22'])==4)
ck(all(v is False for v in p['gates'].values() if isinstance(v,bool) and v is False))
ck(p['gates']['requires_authority'] is True)
ck(p['gates']['can_produce'] is False)
ck(p['gates']['can_publish_party'] is False)
ck(p['gates']['can_claim_fencing'] is False)
for key,name in [('legacy_docket_sha256','CRAFT_DECISION_DOCKET_34_20261021.zip'),('r15_readback_sha256','R15_READBACK_29_RECIPES.csv')]:
 ck(hashlib.sha256((root/'inputs'/name).read_bytes()).hexdigest()==p['inputs'][key])
ck((root/'inputs/CRAFT_DECISION_DOCKET_34_20261021.zip').is_file())
ck(zipfile.ZipFile(root/'inputs/CRAFT_DECISION_DOCKET_34_20261021.zip').testzip() is None)
print(f'R19 CROSSWALK TEST PASS {count}/{count} assertions — frozen R15/R11 inputs, read-only')
