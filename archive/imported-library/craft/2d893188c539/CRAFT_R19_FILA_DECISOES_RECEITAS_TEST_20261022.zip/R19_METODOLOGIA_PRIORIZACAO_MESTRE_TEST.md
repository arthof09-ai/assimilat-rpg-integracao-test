# CRAFT R19 — Fila de decisões da metodologia de receitas (somente leitura)

**Objeto existente:** dossiê `CRAFT_DECISION_DOCKET_34_20261021.zip` (21 divergências nas receitas dos Padrões de Inscrições) cruzado com `R15_READBACK_29_RECIPES.csv` (29 receitas físicas Mestre). **Não é nova biblioteca, motor de receitas, ordem normativa ou lista de correções automáticas.** O R19 apenas organiza o que já estava identificado para evitar revisitar a mesma dúvida 21 vezes. Preserva os dois insumos congelados dentro do pacote, sem tocar nas páginas Notion.

## Resultado quantitativo auditável

| Situação no dossiê anterior | Casos | Ação permitida neste checkpoint |
| --- | ---: | --- |
| P0_RECEITA_P2 — sal/energia de Vedação | 1 | Encaminhar decisão à autoridade competente; nenhuma substituição |
| P1_REFERENCIA_CONSUMO — link e quantidade incompleta | 2 | Recuperar UUID, nomenclatura, quantidade e função; manter HOLD |
| P1_PROCESSO — divergência BOM/etapas | 3 | Revisar correspondência BOM→processo sem inventar operação |
| P2_IDENTIDADE — nomes/ingredientes distintos ou aliases incertos | 13 | Perguntar se são sinônimos, variantes ou insumos diferentes |
| P3_DOCUMENTO — apresentação/etapas incompletas | 2 | Revisar texto e sequência preservando materialidade |
| **Total com divergência anotada** | **21** | **0 write / 0 RC5** |

Os 21 registros correspondem a **21 UUIDs físicos de receita distintos**, mas apenas **20 chaves de padrão**: `MAT-01` inclui as fórmulas Nível 2 e Nível 4 da mesma Matriz de Invocação, não uma duplicata a ser fundida. O recorte maior de 29 receitas tem oito páginas sem divergência apontada no dossiê, o que **não equivale a RC5 aprovado**. A auditoria R15 observou 29/29 menções ao Óleo de Vedação e 28/29 nomes explícitos na BOM, com exceção do link inacessível da Matriz de Cultivo. Entre as **21** receitas com divergências: 20 com óleo nomeado na BOM e uma com a referência do ingrediente a recuperar. Esses são denominadores distintos.

## Ordem de decisão proposta — dependências, não cronograma nem autoridade

1. **Bloqueio de governança (P0 real):** IBX38 fencing de I0014 ainda não comprovado e C19-021 UNKNOWN-EFFECT. Não transformar decisão lexical em writer de produção. R51 continua sem parent físico único comprovado, de modo que nem REC-ID oficial deve ser materializado por aproximação.
2. **Decisão upstream sobre Óleo de Vedação:** ficha oficial Mestre [Óleo de Vedação](https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd) apresenta BOM com 3x Pó de Ferro Celestial, mas processo cita componentes sem correspondência comprovada na BOM. O dossiê registra 28 usos nomeados do óleo; isso justifica revisar a referência comum antes de remediar diversas receitas dependentes. A cópia do Espelho da Party com 2x não é fonte para sobrepor o Mestre.
3. **Vedação P2:** [ENC-08](https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8) requer escolha autoral entre Sal de Geodo Santo e Sal de Geodo Encantado e esclarecimento da energização por **Pedra da Luz OU Pote de Essência Mágica**. É uma divergência de uma receita, não permissão de criar ingrediente novo.
4. **Matriz de Cultivo:** [MAT-03](https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6) tem ingrediente `1x` apontando a UUID inacessível, embora a descrição e a seção de obtenção sugiram Óleo de Vedação. A troca de link permanece **PROPOSTA/INFERIDA** e exige prova/decisão de origem e writer legítimo; além disso a receita diverge entre Terra Encantada/Terra de Gigante e Essência de Água da Nascente/Água de Nascente Élfica.
5. **Matriz de Proteção:** [MAT-06](https://app.notion.com/p/3edc2b324ede8129a6c3cfb603027383) registra `Ex Pó de Quartzo Fantasma`, sem quantidade numericamente válida. Não inventar `1x`, nem interpretar rank como quantidade.
6. **Demais casos P1, P2, P3:** preservar UUID/parent e consultar autoridade de cada receita. Diferença lexical não comprova sinônimo. Não gerar recurso novo, receita derivada, preço ou efeito para corrigir um texto.

**Verificação de atualidade nesta execução:** as três receitas ENC-08, MAT-03, MAT-06 e a ficha do Óleo Mestre foram reabertas diretamente no Notion em 22/10/2026; continuam mostrando, respectivamente, sal divergente, link antigo, `Ex` e BOM de 3x. Os outros 26 UUIDs **não foram reabertos nesta execução**; seus carimbos e análises são do checkpoint R15, explicitamente classificados como congelados. Não alegar nova auditoria integral de 29/29 no R19.

## Entrega aplicável ao Mestre

- `R19_QUEUE_21_RECIPES_TEST.csv`: uma linha por UUID, grupo de prioridade já existente, fonte, problema, evidência de óleo e pergunta ao autor; somente `PENDENTE_AUTORAL_NO_WRITE`.
- `R19_CROSSWALK_21_RECIPES_TEST.json`: mesmo mapa, denominadores, hashes das duas fontes, gates e ordem de dependência, sem conteúdo Player.
- `reconcile_existing_dockets.py`: **junção pontual READ-ONLY de dois artefatos de teste congelados**, não motor, sem chamadas a Notion; 37/37 invariantes automatizadas; cópias das fontes empacotadas para replay limpo.

**NAC-PASS proporcional:** documentação/identidade e reprodução local PASS; decisões autorais, equivalência física, receitas RC5, promoção P4/PS, fabricação, estoque, PA, C19/fencing, R51 e divulgação à Party HOLD. Nenhuma página ou arquivo canônico foi escrito, nenhuma duplicata oficial criada, nenhum REC-ID foi atribuído.
