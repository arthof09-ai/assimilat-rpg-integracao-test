import copy,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from migration_dryrun import load_source,migration_plan,preflight
C=load_source(); P=migration_plan(C)
class TestR51Plan(unittest.TestCase):
 def test_status(self):self.assertEqual(P['status'],'PLAN_TEST_READONLY_NO_ACTION_ALLOWED')
 def test_denominators(self):self.assertEqual(P['scope']['action_units'],35)
 def test_physical(self):self.assertEqual(P['scope']['physical_child_recipe_pages_preserved'],29)
 def test_inline(self):self.assertEqual(P['scope']['embedded_recipe_bodies_review_only'],5)
 def test_missing(self):self.assertEqual(P['scope']['one_pattern_without_recipe_in_page'],1)
 def test_no_duplicate_physical_page(self):
  ids=[x['existing_recipe_page_id'] for x in P['actions'] if x['existing_recipe_page_id']]
  self.assertEqual(len(ids),len(set(ids)))
 def test_all_actions_no_write(self):self.assertTrue(all(x['action']=='NO_MUTATION' for x in P['actions']))
 def test_every_rec_id_unassigned(self):self.assertTrue(all(x['recorded_rec_id'] is None and x['proposed_rec_id'] is None for x in P['actions']))
 def test_target_not_verified(self):self.assertFalse(P['target']['physical_parent_verified'])
 def test_global_absence_not_claimed(self):self.assertFalse(P['target']['global_parent_absence_proven'])
 def test_declared_claims_not_credentials(self):
  fields={'writer_green':True,'external_fence':True,'parent_verified':True,'nac_pass':True,'ack':True,'safe_point':True,'lease':True,'epoch':99}
  self.assertEqual(preflight(P['actions'],fields)['status'],'HOLD_NO_AUTHENTICATED_EXTERNAL_FENCING_OR_VERIFIED_TARGET_PARENT')
 def test_no_party(self):self.assertEqual(P['effects']['party_writes'],0)
 def test_invocation_reuses_two_pages(self):
  a=[x for x in P['actions'] if x['pattern_key']=='MAT-01']
  self.assertEqual(len(a),2);self.assertNotEqual(a[0]['existing_recipe_page_id'],a[1]['existing_recipe_page_id'])
 def test_millennium_no_recipe(self):
  a=[x for x in P['actions'] if x['pattern_key']=='MAT-07'];self.assertEqual(a[0]['classification'],'NO_EXPLICIT_RECIPE_IN_THIS_PATTERN')
 def test_rerun_is_idempotent(self):self.assertEqual(P,migration_plan(C))
 def test_missing_source(self):self.assertEqual(migration_plan({'patterns':[]})['status'],'REJECTED_INVALID_CORPUS')
 def test_duplicate_physical(self):
  c=copy.deepcopy(C)
  c['patterns'][1]['recipe_ids']=c['patterns'][0]['recipe_ids'][:]
  self.assertEqual(migration_plan(c)['reason'],'DUPLICATE_RECIPE_PAGE_ID')
 def test_unsupported_role(self):
  c=copy.deepcopy(C);c['patterns'][0]['source_role']='OFFICIAL_RC5'
  self.assertEqual(migration_plan(c)['reason'],'INVALID_ROLE')
 def test_no_ing_coverage_assumption(self):self.assertEqual(P['effects']['new_rec_ids_assigned'],0)
class TestEachPlanAction(unittest.TestCase):pass
for i,a in enumerate(P['actions']):
 def t(self,a=a):
  self.assertEqual(a['action'],'NO_MUTATION')
  self.assertFalse(a['canonicalization_authorized'])
  self.assertFalse(a['party_write'])
 setattr(TestEachPlanAction,'test_safe_%02d'%i,t)
