"""R51 existing-first migration planner — no Notion API and NO writes.

Consumes checksum-pinned CRAFT-CORPUS34-OIL-GRAPH-20261021.zip.
Does not create physical recipe pages, REC-IDs or canonical data.
"""
from pathlib import Path
from collections import Counter
import zipfile,hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
SOURCE_NAME='CRAFT_CORPUS34_OIL_GRAPH_20261021.zip'
SOURCE_SHA='cf4268a3178dd99a55fcb60add082e8537d8dd33c5e6eeaa59afdabe0f9db0f4'

def load_source():
 p=ROOT/'baseline'/SOURCE_NAME
 if not p.is_file():raise ValueError('MISSING_PINNED_BASELINE')
 if hashlib.sha256(p.read_bytes()).hexdigest()!=SOURCE_SHA:raise ValueError('BASELINE_HASH_MISMATCH')
 with zipfile.ZipFile(p) as z:
  if z.testzip() is not None:raise ValueError('BASELINE_CRC_FAILURE')
  return json.loads(z.read('data/pattern_recipe_crosswalk.json').decode('utf8'))

def preflight(rows,external_assertions=None):
 """Pure code can verify documentary consistency, not external writer/epoch/fencing."""
 if not isinstance(rows,list):return {'status':'INVALID_PLAN','writes':0}
 expected={'PRESERVE_EXISTING_RECIPE_PHYSICAL_PAGE':29,
           'EMBEDDED_CONTENT_REQUIRE_CANONICAL_EXTRACTION_REVIEW':5,
           'NO_EXPLICIT_RECIPE_IN_THIS_PATTERN':1}
 got=Counter(x.get('classification') for x in rows)
 if got!=expected:return {'status':'INVALID_PLAN_DENOMINATORS','writes':0,'found':dict(got)}
 assert all(x['action']=='NO_MUTATION' for x in rows)
 # A claim written in a JSON object is not external technical fencing.
 return {'status':'HOLD_NO_AUTHENTICATED_EXTERNAL_FENCING_OR_VERIFIED_TARGET_PARENT',
  'writes':0,'moved_pages':0,'new_rec_ids':0,'modified_pages':0,
  'parent_destination_verified':False,'authenticated_owner_verified':False,
  'all_user_supplied_flags_ignored':True,'claims_supplied':bool(external_assertions)}

def migration_plan(corpus):
 patterns=corpus.get('patterns',[])
 if len(patterns)!=34:return {'status':'REJECTED_INVALID_CORPUS','reason':'PATTERN_DENOMINATOR'}
 seen=set(); actions=[]
 for p in patterns:
  if not re.fullmatch('[0-9a-f]{32}',p.get('pattern_id','')):return {'status':'REJECTED_INVALID_CORPUS','reason':'BAD_PATTERN_ID'}
  role=p['source_role']
  base={'pattern_key':p['key'],'pattern_page_id':p['pattern_id'],'family':p['family'],
        'pattern_name':p['name'],'action':'NO_MUTATION',
        'recorded_rec_id':None,'proposed_rec_id':None,'proposed_physical_page_id':None,
        'destination_parent_page_id':None,
        'canonicalization_authorized':False,
        'party_write':False,'o_primeiro_write':False}
  if role=='CHILD_RECIPE_PAGE':
   for rid in p['recipe_ids']:
    if rid in seen:return {'status':'REJECTED_INVALID_CORPUS','reason':'DUPLICATE_RECIPE_PAGE_ID'}
    seen.add(rid)
    actions.append({**base,'classification':'PRESERVE_EXISTING_RECIPE_PHYSICAL_PAGE',
       'existing_recipe_page_id':rid,'source_link':'https://app.notion.com/p/'+rid,
       'future_operator_notes':'First locate actual central parent and verify current PAGE-ID and UID, then secure fencing; preserve old URL and properties if later moved; add mentions instead of copying recipe.'})
  elif role=='EMBEDDED_RECIPE':
   if p['recipe_ids']:return {'status':'REJECTED_INVALID_CORPUS','reason':'INLINE_CHILD_CONFLICT'}
   actions.append({**base,'classification':'EMBEDDED_CONTENT_REQUIRE_CANONICAL_EXTRACTION_REVIEW',
      'existing_recipe_page_id':None,'source_link':'https://app.notion.com/p/'+p['pattern_id'],
      'future_operator_notes':'Do not create recipe yet: confirm absence of canonical source under product+version+REC-ID; extract once only after competent authority, physical target and fencing.'})
  elif role=='NO_EXPLICIT_RECIPE':
   if p['recipe_ids']:return {'status':'REJECTED_INVALID_CORPUS','reason':'MISSING_WITH_CHILD'}
   actions.append({**base,'classification':'NO_EXPLICIT_RECIPE_IN_THIS_PATTERN',
      'existing_recipe_page_id':None,'source_link':'https://app.notion.com/p/'+p['pattern_id'],
      'future_operator_notes':'Do not infer recipe from effect or create formula. Search beyond this pattern before deciding whether a gap exists.'})
  else:return {'status':'REJECTED_INVALID_CORPUS','reason':'INVALID_ROLE'}
 if len(actions)!=35 or len(seen)!=29:return {'status':'REJECTED_INVALID_CORPUS','reason':'ACTION_DENOMINATOR'}
 proof=preflight(actions)
 return {'schema':'CRAFT-R51-MIGRATION-DRYRUN-v1','status':'PLAN_TEST_READONLY_NO_ACTION_ALLOWED',
      'as_of_utc':'2026-10-21',
      'trace':'CRAFT-REC-LIB-R51-DRYRUN34-20261021-001',
      'source_snapshot':SOURCE_NAME,'source_snapshot_sha256':SOURCE_SHA,
      'scope':{'unique_patterns':34,'mestre_pattern_families':{'ENC':9,'BAT':17,'MAT':8},
               'physical_child_recipe_pages_preserved':29,'embedded_recipe_bodies_review_only':5,
               'one_pattern_without_recipe_in_page':1,'action_units':35,
               'two_versions_one_invocation_pattern':True,'duplicate_pages_added':0},
      'target':{'normative_rec_lib_page_id':'3f1c2b324ede81e2901adb9ae10b2702',
         'r51_request_page_id':'3f4c2b324ede812a9153d39281b488f8',
         'items_root_page_id':'3edc2b324ede8184b487c0735f1eabb4',
         'direct_items_children_read':17,
         'direct_child_named_recipes_and_formulas_found':False,
         'global_parent_absence_proven':False,
         'physical_parent_verified':False},
      'auth':proof,'stages':[
        '0 REOPEN evidence and verify current version/parent/permissions; read-only',
        '1 SEARCH global REC-ID, product+version aliases, prior physical recipe; anti-duplicate',
        '2 RECONCILE R51 parent and C19-021 in-flight effects with competent operator',
        '3 OBTAIN external fence, exclusive writer, monotonic epoch/lease and proper NAC-PASS',
        '4 VERIFY source BOM, variant identity, custody/QA, Player-safe and historical provenance',
        '5 AFTER explicit GREEN, preserve each source ID; move/relink only by atomic authorized transaction',
        '6 REOPEN actual destination and links; compare before/after and log; do not fill gaps by inference'],
      'actions':actions,
      'effects':{'notion_writes':0,'existing_pages_moved':0,'new_recipe_pages_created':0,
       'new_rec_ids_assigned':0,'writer_or_epoch_claims_created':0,'f5_red_unmodified':True,
       'party_writes':0,'o_primeiro_writes':0}}

if __name__=='__main__':print(json.dumps(migration_plan(load_source()),ensure_ascii=False,indent=2))
