from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())['files']
a={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json' and '__pycache__' not in p.parts}
assert a==m,'MANIFEST_MISMATCH'
t=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
assert t.returncode==0,t.stderr
p=subprocess.run([sys.executable,'-B','code/migration_dryrun.py'],cwd=ROOT,capture_output=True,text=True)
assert p.returncode==0,p.stderr
assert json.loads(p.stdout)==json.loads((ROOT/'outputs'/'MIGRATION_DRYRUN.json').read_text()),'NON_DETERMINISTIC_REPORT'
print('R51_DRY_RUN_COLD_PASS',len(a),'MANIFEST_HASHES',t.stderr.split('Ran ')[-1].split(' ')[0],'TESTS','0_NOTION_WRITES')
