# Fila executável — BACKFILL-30 / futuro GREEN legítimo

**Este arquivo não concede GREEN.** Fila de trabalho para o operador autorizado, reutilizando OP-ARQ-RIN-REC-01, AUD-CRAFT-F5-REMAP-01, a IBX-38 para fencing, IBX-78 para destino REC-LIB e a biblioteca normativa REC-LIB-01. Proibido criar outra Inbox/OP/biblioteca, página de recurso, espécie, loja ou registro nas fichas.

## Gate transversal G0 — pré-condição para qualquer escrita produtiva

1. Registrar evidência **externa efetiva** de término/bloqueio técnico de escrita de I0014 e estado das chamadas in-flight; ACK documental do Coordenador sozinho não é fence. Usar a [IBX-38 existente](https://app.notion.com/p/3f3c2b324ede817fb888ca32aacaf2de) sem reabrir demanda duplicada.
2. Reconciliar `C19-021` por snapshot de R02 + fontes ESS + logs/API suficientes, com `NONE/PARTIAL/FULL/AMBIGUOUS` por chave; `UNKNOWN` impede writer material e retry do lote de cinco Essências. Nenhuma essência R02 nova nesta fase.
3. U-SUCCESSION com identidade e collision domain legitimos, `CLAIM-PENDING → VERIFY-CLAIM → TAKEOVER-COMMIT`, epoch/lease/fencing demonstrados, canário em destino autorizado e `GREEN` específico microbloco. Não herdar instância I0016 ou C19 por silêncio.
4. Identificar/verificar **parent físico único** de Receitas & Fórmulas no Notion Mestre ou implantação mínima expressamente permitida; [IBX-78](https://app.notion.com/p/3f4c2b324ede812a9153d39281b488f8) mantém a pendência; nenhuma criação alternativa em Incubação por conveniência.
5. Em cada item: insumo PS com fonte/quantidade/posse legitimada, BOM↔processo e evidência real suficiente; `PR-ITEM-02`, `PR-SC-01`, `REC-EXEC`, `REC-LIB-01`, custo Anexo C, distinção existente-first e NAC-NORM/CONT/PASS aplicados sem fake PASS. SC-3/4 requer Mestre; Player-safe só após conhecimento descoberto/autorizado.

## Ordem de qualificação TÉCNICA (pode avançar documentalmente sob RED)

| Grupo | B30 | Meta de prova antes da publicação | Dependência de catálogo/antiduplicata |
|---|---|---|---|
| P0 piloto técnico | 01 | lâmina real dimensionada, 6 etapas, QA independente, benchmark placa comum, custo/lote | pesquisar tabelas/gabaritos já existentes; não usar produto sandbox |
| P1 materiais secos e dimensões | 02, 03, 04, 05, 06, 07 | tração; espessura/folga; granulometria; anisotropia; adsorção; pigmento | diferenciar suportes/abrasivos e garantir invólucro B30-06 existente |
| P1 instrumentos e cerâmica R01 | 08, 09, 10, 11, 12 | retenção punho, capilaridade, corte, queima/vedação, carbonato/argamassa | ferramentas comuns, tinta real e forno/licenças já autorizados |
| P1 horticultura/energia/argilas | 13, 14, 15, 16, 17 | germinação, calor/fumaça, magnetização, sinterização, acabamento fino | B30-13 usa areia RECURSO B30-04 sem presumir leito pronto; B30-15 fibra B30-02; B30-16 argila B30-11 sob compatibilidade |
| P2 alta temperatura e drops R02 | 18, 19, 20, 21, 22, 23 | refratariedade, estabilidade biológica, abrasividade, calibração, fecho e segurança espectral | B30-18 liga argila, B30-19/22 fibra; comparar alternativas mais baratas e fontes biológicas reais |
| Q1 decisão de mérito | 24–30 | mecanismo e produto material distintivo; doses/segurança e diferenciação | 24/25 possível merge, 28 reformular, 29 comparar essência Planta, 30 protocolo transversal |

Dentro de cada grupo, executar pela numeração B30 vigente em vez de reorganizar o inventário. Se um bloqueio de insumo/ensaio ocorrer em uma ficha, avançar outra qualificação documental sem gastar autoridade de publicação. Não inventar dados de teste e não contar “resultado de design” como observação.

## Microtransação de publicação por candidato (após G0 + prova técnica)

**ANTES:** novo readback da fonte PS, última versão/parent da receita e índices de produto; busca global por nome, produto, função, BOM, REC-ID e linhagem, inclusive receitas embutidas. Conferir não concorrência e gate da instância. Registrar ANTES na operação competente, com fingerprint, escopo do write-set e reversão.

**AÇÃO restrita:** criar/reutilizar **UMA** página REC-ID na fonte física única; classificar RC conforme resultado técnico independente; vincular BOM, produto e fonte sem duplicar o corpo integral em fichas/índices; não criar recurso novo. Quando já há receita equivalente, versionar/adaptar com rastreio, **não contabilizar novo REC-ID**. Produto deve ter identidade própria/PR-ITEM, não um rótulo de TESTE.

**READBACK:** reabrir página REC-ID, fonte PS, produto, parent/índices; confirmar menções bilaterais, status RC e dependências, autor e versão. Registrar DEPOIS, REPA, NAC-PASS terminal específico e evidências. Se resultado incerto, verificar efeito antes de retry. Atualizar contadores `RECEITAS_RC5/30`, `REC_IDS_UNICOS/30`, `FONTES_COM_LINK/30` separadamente, com set-ID e sem duplicata.

**DECISÃO DO MESTRE:** necessária se uma candidata exigir SC-3/4, se valor funcional não sustentado mas a meta de 30 pressionar filler, se materialidade/uso histórico depender de lore não resolvido, ou se faltarem regras/disponibilidade após pesquisa exaustiva. A decisão deve ser **questão específica com opções e efeitos**, nunca solicitação genérica de autorização.

## Pontos de controle (PSV)

`OP=OP-ARQ-RIN-REC-01; WORKSTREAM=CM-000002-WS0001; DOCUMENT-SCOPE=BACKFILL-30; MATERIAL=HOLD; NO-WRITER-CLAIM; IBX38=NOVA/SEM ACK no último readback; IBX78=NOVA/SEM ACK no último readback; C19-021=UNKNOWN-SIDE-EFFECT; F5=RED; RC5=0/30; REC-ID=0/30; PS-FICHAS-LINKADAS=0/30; NOVOS-RECURSOS=DENY; PARTY/O PRIMEIRO-WRITE=0; V03-PLAN=DRAFT.`

**Último efeito desta rodada:** geração local de dossiês técnicos, links e matriz; nenhum Notion write. **Ponto exato de retomada:** B30-01 medição/validação técnica por evidência, em paralelo decisão de destino IBX-78/fence IBX-38 pelas autoridades competentes; ao existir primeiro GREEN específico com TECH-PASS, executar um REC-ID de cada vez.
