# Sete candidaturas PRE-Q1 — julgamento técnico e caminhos não artificiais

**Estado:** proposta de decisão Mestre-side, não homologação, não REC-ID. As páginas de recurso continuam preservadas independentemente de destino da hipótese original. Referência: AUD-CRAFT R43-Q1 e matriz comparativa R43-Q2.

## B30-24 / B30-25 — espinhos de Tigre Flora e Felpudo

**Diagnóstico:** ambas as hipóteses produzem, até aqui, um **protocolo de amostragem e comparação**, e não dois produtos materialmente transformados distintos. Uma identidade biológica diferente não torna automaticamente uma mesma rotina de embalagem em duas receitas RC5 legítimas. Atividade residual e risco são desconhecidos.

**Opção A — recomendada sob evidência atual:** preservar as DUAS fichas PS e conceber uma **única plataforma de referência morfológica comparativa**, com duas amostras-fontes, recipiente e custódia certificados. Contar no máximo UM projeto de protocolo, e **zero receita RC5** enquanto não houver transformação concreta/consumidor/lote. Não manipular toxinas. Critério de separação futura: só individualizar receitas se surgirem processos/saídas distintos com uso demonstrado e não mero rótulo de espécie.

**Opção B — condicionada:** desenvolver duas peças de proteção/encaixe fisicamente distintas somente após provar morfologia, estabilidade e demanda; exigir ferramenta, embalagem e BOM existentes. Sem estudo estrutural real, não escolher B por meta de 30.

**Decisão reservada:** aceitar equivalência funcional de produção de amostras, com preservação de ambas as fichas; validar necessidade da coleção apenas se houver instituição ou função concreta no mundo.

## B30-26 — Essência de Ovelha de Chifres

**Diagnóstico:** o desenho "catalisador de tenacidade" presume transmissão de propriedade mágica/biológica para matéria córnea sem mecanismo comprovado; não há dose, extração ou estabilidade. Associar esta essência a um punho B30-08 só é permitido como experimento controlado, não BOM obrigatória.

**Rota técnica recomendada:** manter estudo de compatibilidade essência–chifre com placebo, ensaio de flexão e curva dose/efeito; antes validar a extração/identidade da essência. Se houver melhora física comprovada com segurança e diferença contra tratamento comum, derivar receita de compósito sob REC-LIB. Sem isso, **preservar Essência PS sem inventar produto**. Nenhuma Investida/força/dano transferida.

## B30-27 — Essência de Carniceiro

**Diagnóstico:** “tinta de assinatura” depende de veículo, capacidade de fixação de essência e mecanismo de inscrição, todos desconhecidos. A pena B30-09 não prova compatibilidade arcana; pigmento B30-07 tampouco é veículo pronto.

**Rota técnica recomendada:** primeiro verificar identidade/concentração e transportador existente; ensaio em suporte de inscrição com controles sem essência e medição temporal da assinatura. Só transformar em receita se houver efeito de inscrição sustentado; caso contrário registrar estudo de estabilidade/identidade como pesquisa, sem REC-ID distinto. Silêncio/furtividade de Carniceiro NÃO é efeito transferido.

## B30-28 — Essência de Lobo das Cavernas

**Diagnóstico crítico:** a premissa de resposta vegetal é fraca; capacidade de rastreio do animal não sustenta afinidade Planta da essência. Nem tipo de planta nem modo de reação foram encontrados como fatos aptos a justificar receita.

**Reformulação preferível:** **retirar o alvo “reagente botânico” da fila de RC5** enquanto a fonte canônica não trouxer mecanismo vegetal. A ficha da Essência continua PS e pode ser analisada para **estabilização, acondicionamento ou identificação em processo existente**, mas não conta como nova receita se produzir apenas um laudo genérico. Uma decisão positiva exige função diferente comprovada, não simples alteração do nome do reagente.

## B30-29 — Essência de Tigre Flora

**Diagnóstico:** pode coincidir com Essência de Vida de Planta ou extrato Planta genérico. Nome “Tigre Flora” não prova aumento de potência, letalidade ou afinidade especial.

**Rota técnica recomendada:** realizar comparativo de concentração, assinatura/afinidade Planta e estabilidade contra o controle genérico EXISTENTE. Se diferença material e uso seguro forem comprovados, estudar **concentrado de assinatura específica** com processo e dose medidos. Se equivalentes, **variante/linhagem compartilhada em receita única**, sem novo REC-ID só por espécie. Qualquer toxicidade permanece sem uso/transferência autorizados.

## B30-30 — Essência de Felpudo

**Diagnóstico:** verificar estabilidade ao longo do tempo constitui técnica de QA, não fabricação de produto por si só. Atribuir uma receita de “padrão de estabilidade” a cada espécie de Essência seria receita-filler.

**Rota técnica recomendada:** reutilizar **um protocolo transversal** de identidade/estabilidade de Essências, com amostra de Felpudo identificada como linha de ensaio. Somente formular uma receita própria se dela resultar material/veículo/estabilizante distinto com efeito causal e consumidor comprovados. Charme/regeneração não são propriedades transferíveis inferidas.

## Impasse de denominador — posição técnica

O objetivo de **30 fichas integradas e ≥30 REC-IDs distintos legítimos** é vinculante como META, mas não como licença de invenção. A carteira documental tem **23 B30 PRE-Q2** e **7 hipóteses PRE-Q1**. Se B30-24/25 convergirem para um só procedimento e B30-28/30 se revelarem meros laudos, mesmo uma passagem de todos os 23 para RC5 não demonstra 30 receitas adicionais. A quantidade futura depende de distinções de função, materiais disponíveis, processo comprovado e anti-duplicata. A decisão do Mestre torna-se indispensável APENAS para eventual redefinição de mérito/escopo quando a evidência individual mostrar inviabilidade, não para cada etapa segura de pesquisa.

**Contagem atual:** fontes PS examinadas 30/30; receita RC5 de B30-24..30 = 0/7; equivalências MERGE = PROPOSTAS, não decisões canônicas. A preservação de fichas **não** implica declarar receita válida.
