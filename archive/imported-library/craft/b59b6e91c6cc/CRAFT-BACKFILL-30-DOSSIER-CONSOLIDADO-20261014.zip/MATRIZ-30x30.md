# BACKFILL-30 — Matriz de rastreio 30/30

**Corte:** 14/10/2026; **escopo:** design read-only Mestre-side, não implementação no Notion.

| B30 | Região | Ficha PS original → proposta | Maturidade documental | Diferenciação / decisão | Receita RC5 | REC-ID | Link físico |
|---|---|---|---|---|---:|---:|---:|
| B30-01 | R01 | [Ardósia de Geada Lamelar](https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2) → Tábua Lamelar de Inscrição | PRE-Q2 | CONSERVAR alvo | 0 | 0 | 0 |
| B30-02 | R01 | [Fibra de Casca Boreal](https://app.notion.com/p/3f3c2b324ede815ab04ace5bd1074e79) → Cordão de Casca Boreal | PRE-Q2 | CONSERVAR só se uso não for dominado por fibra/corda comum | 0 | 0 | 0 |
| B30-03 | R01 | [Mica de Bruma Boreal](https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84) → Espaçador de Mica Calibrado | PRE-Q2 | CONSERVAR como par espaçador, não como isolante mágico | 0 | 0 | 0 |
| B30-04 | R01 | [Areia de Brecha Granulada](https://app.notion.com/p/3f3c2b324ede816f9af4fdd6758bbe6c) → Leito Abrasivo de Brecha | PRE-Q2 | CONSERVAR se serviço de desbaste se distinguir de B30-17 | 0 | 0 | 0 |
| B30-05 | R02 | [Gnaisse de Fibra Transversal](https://app.notion.com/p/3f3c2b324ede81319786eba0f666cef1) → Placa de Apoio de Gnaisse Orientado | PRE-Q2 | CONSERVAR função de base | 0 | 0 | 0 |
| B30-06 | R02 | [Zeólita de Caverna Fria](https://app.notion.com/p/3f3c2b324ede819695d6e7797fd94370) → Bolsa Secante de Zeólita | PRE-Q2 | CONSERVAR condicionada à identidade do invólucro e ganho mensurado | 0 | 0 | 0 |
| B30-07 | R01 | [Hematita de Raiz Fria](https://app.notion.com/p/3f3c2b324ede810b9969e0a01d26457d) → Pigmento de Hematita para Marcação | PRE-Q2 | MANTER pó seco como produto-alvo | 0 | 0 | 0 |
| B30-08 | R01 | [Lâmina de Chifre da Ovelha de Chifres](https://app.notion.com/p/3f3c2b324ede812f9857c6fc696202e1) → Empunhadura Córnea de Ferramenta | PRE-Q2 | MANTER como peça de reposição, não item com bônus de dano | 0 | 0 | 0 |
| B30-09 | R01 | [Pena de Carniceiro](https://app.notion.com/p/3f3c2b324ede81779a63d897f33fed77) → Pena-Cálamo de Marcação | PRE-Q2 | CONSERVAR como instrumento, não afirmar tinta incorporada | 0 | 0 | 0 |
| B30-10 | R01 | [Presa do Lobo das Cavernas](https://app.notion.com/p/3f3c2b324ede8138851ad3867572384c) → Buril de Presa Cavernícola | PRE-Q2 | MANTER para substrato macio | 0 | 0 | 0 |
| B30-11 | R01 | [Argila de Raiz Fria](https://app.notion.com/p/3f3c2b324ede81b8b187f217b20c6bdb) → Selo Cerâmico de Argila | PRE-Q2 | MANTER como disco cerâmico | 0 | 0 | 0 |
| B30-12 | R01 | [Calcita de Brecha Lechosa](https://app.notion.com/p/3f3c2b324ede81f5b23df718df83b634) → Carga Carbonática para Argamassa de Oficina | PRE-Q2 | CONSERVAR como ingrediente de argamassa se comparação sustentar | 0 | 0 | 0 |
| B30-13 | R01 | [Húmus de Agulhas Frias](https://app.notion.com/p/3f3c2b324ede812b84b2fe10adb88d8e) → Substrato de Germinação de Agulhas | PRE-Q2 | CONSERVAR se existir benefício objetivo contra solo comum | 0 | 0 | 0 |
| B30-14 | R01 | [Turfa de Pinhal Frio](https://app.notion.com/p/3f3c2b324ede8130a63ed053b8bd132f) → Briquete de Turfa Boreal | PRE-Q2 | CONDICIONAR fonte ecológica e ganho real | 0 | 0 | 0 |
| B30-15 | R01 | [Magnetita de Pinhal](https://app.notion.com/p/3f3c2b324ede81ee9a8cd69d25d1d94e) → Agulha de Orientação Ferruginosa | PRE-Q2 | CONDICIONAR magnetização real e instrumento referência | 0 | 0 | 0 |
| B30-16 | R02 | [Feldspato de Fenda Alpina](https://app.notion.com/p/3f3c2b324ede81a2a590c53273f9e6e5) → Mistura Fundente de Fenda Alpina | PRE-Q2 | CONSERVAR como mistura para corpos de prova, não vidrado mágico | 0 | 0 | 0 |
| B30-17 | R02 | [Granada Abrasiva de Escarpa](https://app.notion.com/p/3f3c2b324ede8150939dc8e911a3c5e1) → Granada Calibrada para Lapidação | PRE-Q2 | CONSERVAR se classe fina funcionalmente distinta for demonstrada | 0 | 0 | 0 |
| B30-18 | R02 | [Magnesita de Garganta Serrana](https://app.notion.com/p/3f3c2b324ede8113a005f7b254490583) → Revestimento Magnesiano de Cadinho | PRE-Q2 | CONDICIONAR forno/ligante verdadeiros e prova de compatibilidade | 0 | 0 | 0 |
| B30-19 | R02 | [Placa Cutânea do Behemoth Glacial](https://app.notion.com/p/3f3c2b324ede814e84e6e254bae3b242) → Invólucro Cutâneo de Ferramenta | PRE-Q2 | CONSERVAR se cura e aplicação justificam drop raro | 0 | 0 | 0 |
| B30-20 | R02 | [Limalha de Esmalte do Rinolupo](https://app.notion.com/p/3f3c2b324ede81b682edf096ae99470a) → Pasta Abrasiva de Esmalte Rinolupo | PRE-Q2 | CONDICIONAR veículo e ganho econômico | 0 | 0 | 0 |
| B30-21 | R02 | [Lasca de Presa do Mamute Antigo](https://app.notion.com/p/3f3c2b324ede814ab353cf6008946d2c) → Régua Entalhada de Presa de Mamute | PRE-Q2 | CONDICIONAR diferenciação | 0 | 0 | 0 |
| B30-22 | R02 | [Quitina de Exoesqueleto do Escorpião Ártico](https://app.notion.com/p/3f3c2b324ede8141acddf0bb23ffe56c) → Estojo Articulado de Quitina | PRE-Q2 | CONSERVAR só se fecho com placa demonstrar vantagem real | 0 | 0 | 0 |
| B30-23 | R02 | [Apara Óssea do Frígido Ossário](https://app.notion.com/p/3f3c2b324ede81efb836ded2692cfd89) → Pino Ósseo de Alinhamento | PRE-Q2 | CONDICIONAR antes de qualquer teste comum ao laudo de estabilidade | 0 | 0 | 0 |
| B30-24 | R01 | [Espinho de Garra do Tigre Flora](https://app.notion.com/p/3f3c2b324ede810fb218c5033bfca614) → Padrão Morfológico Controlado de Espinho Flora | PRE-Q1 | MERGE PROPOSTO com B30-25 em protocolo de comparação se só houver custódia | 0 | 0 | 0 |
| B30-25 | R01 | [Espinho de Pelagem do Felpudo](https://app.notion.com/p/3f3c2b324ede816cac14f775dad4c8a7) → Amostra Comparativa de Espinho Tegumentar Felpudo | PRE-Q1 | MERGE PROPOSTO protocolo compartilhado com B30-24 | 0 | 0 | 0 |
| B30-26 | R01 | [Essência de Ovelha de Chifres](https://app.notion.com/p/3f3c2b324ede81a19cc9d6a89841e3b7) → Catalisador Experimental de Tenacidade Córnea | PRE-Q1 | CONDICIONAR | 0 | 0 | 0 |
| B30-27 | R01 | [Essência de Carniceiro](https://app.notion.com/p/3f3c2b324ede816dac4fe2d085290425) → Tinta Experimental de Assinatura Aviária | PRE-Q1 | CONDICIONAR | 0 | 0 | 0 |
| B30-28 | R01 | [Essência de Lobo das Cavernas](https://app.notion.com/p/3f3c2b324ede813780bfc86dd62cd3ac) → Reagente Experimental de Resposta Silvestre | PRE-Q1 | REFORMULAR: sem suporte botânico, estudar preservação/identificação da essência | 0 | 0 | 0 |
| B30-29 | R01 | [Essência de Tigre Flora](https://app.notion.com/p/3f3c2b324ede81709ea8df4b319397f3) → Concentrado Experimental de Afinidade Planta Predatória | PRE-Q1 | CONDICIONAR comparação | 0 | 0 | 0 |
| B30-30 | R01 | [Essência de Felpudo](https://app.notion.com/p/3f3c2b324ede8124bb19e5529e1b3b8a) → Padrão Experimental de Estabilidade de Essência Felpudo | PRE-Q1 | MERGE PROPOSTO com protocolo transversal de análise | 0 | 0 | 0 |

**Totais de cobertura:** 30/30 candidaturas com especificação consolidada (100%); 23/30 PRE-Q2 (76,67%) e 7/30 PRE-Q1 (23,33%). **RC5 tecnicamente validada: 0/30; REC-ID criado: 0/30; vínculo físico: 0/30.**

**Definições:** especificado ≠ validado empiricamente ≠ RC5 ≠ REC-ID criado ≠ backlink comprovado. Uma receita compartilhada conta uma única REC-ID mesmo que cubra duas fontes. Os dados não autorizam 30 receitas distintas finais.