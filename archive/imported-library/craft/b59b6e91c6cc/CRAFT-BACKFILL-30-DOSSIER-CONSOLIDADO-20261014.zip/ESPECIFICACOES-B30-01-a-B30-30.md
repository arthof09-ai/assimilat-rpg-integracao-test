# BACKFILL-30 — 30 especificações técnicas consolidadas

**CM-000002 / WS0001 / OP-ARQ-RIN-REC-01 · 14/10/2026 · Dossiê técnico Mestre-only — sandbox documental.**

## Convenção de evidência e autoridade

- **VERIFICADO:** 30 páginas PS no Notion da conta Mestre e correspondência 1:1 com o dossiê AUD R42; NÃO verifica insumos em estoque, poderes, fabricação, aptidão nem acessibilidade comercial.
- **HERDADO DO R42/R43/R52:** BOMs, produto-alvo, processos, parâmetros de QA e comparadores de projeto; indicados como PROPOSTOS até prova física/canônica adicional.
- **APROFUNDAMENTO DESTE PACOTE:** trilha de teste e decisão funcional individual, dependências cruzadas, alternativas de merge/refuso, tratamento explícito de riscos, custo e publish-gate em cada ficha; raciocínio de projeto, NÃO medições ou RC5.
- **23 PRE-Q2** significam engenharia documental com hipóteses mensuráveis; **7 PRE-Q1** são hipóteses com mérito ainda não demonstrado; a escala RC0–RC5 oficial não pode ser inferida de PRE-Q2.
- **Uso em jogo:** DENY até autorização PS/JIT distinta. Novos recursos F5 = DENY; publicação e escrita oficiais = HOLD.

## Fontes de autoridade

- [OP-ARQ-RIN-REC-01](https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516)
- [AUD-CRAFT-F5-REMAP-01](https://app.notion.com/p/3f3c2b324ede81c99367e2de46077cbb) — seções `BACKFILL30-CRAFT-R42-A-001`, `BACKFILL30-CRAFT-R42-B-001`, `PRE-REC-CRAFT-R42-TLI-METROLOGY-001`, `CRAFT-I0016-R43-Q1-TRIAGE-20261009-001`, `CRAFT-I0016-R43-Q2-FUNCTIONAL-20261009-001`
- [REC-LIB-01](https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702)
- [PR-ITEM-02](https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4)
- [PR-SC-01](https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1)
- [Anexo C PR-ECO](https://app.notion.com/p/3eec2b324ede8102b3f3e6c8851ad1e7)
- [R52 B30-01 mínimo empírico](#) — arquivo histórico contido no ZIP R52 da v03; ver dossiê independente incluso neste pacote.

## Especificações individuais

### B30-01 — Tábua Lamelar de Inscrição

**1. Ficha original / proveniência (VERIFICADO):** [Ardósia de Geada Lamelar](https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-01` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Tábua Lamelar de Inscrição — ferramenta de inscrição não mágica. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 lâmina íntegra ≥130×90×9 mm; abrasivo desgaste a g; instrumentação reutilizável. Corpo rígido e superfície de traçado. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** catalogar lote e fissuras → marcar → cortar/clivar → aplainar espessura → gravar malha ortogonal 10 mm → desbastar cantos → medir e classificar. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** lapidador mineral, corte, apoio rígido, esquadro, paquímetro, régua, abrasivo, controle de poeira. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** poeira, lascamento, delaminação; conter e descartar lâminas inseguras. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Ardósia de Geada Lamelar e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** poeira, lascamento, delaminação; conter e descartar lâminas inseguras; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **ardósia comum, pedra plana, placa e gabaritos já existentes**. Critério de contribuição própria: precisão geométrica, legibilidade, reuso e custo por uso contra gabarito comum. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81acaf28c66a6b46e0b2` → `B30-01` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** dimensões entrada/saída, planicidade, espessura, passo/sulco, desgaste abrasivo, massa e repetibilidade. **Tratamento recomendado:** CONSERVAR alvo; base de protocolo R41/R42 e R52; sem bônus de perícia, magia ou frio. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-02 — Cordão de Casca Boreal

**1. Ficha original / proveniência (VERIFICADO):** [Fibra de Casca Boreal](https://app.notion.com/p/3f3c2b324ede815ab04ace5bd1074e79) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-02` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Cordão de Casca Boreal — cordoaria/fixação. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 2 m de fibra selecionada + água q_a se necessária → 1 m de cordão pretendido; fibra suporta tração, água facilita torção. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** atestar planta e coleta → classificar fibras → umedecer se cabível → torcer dois conjuntos → retorcer → secar → testar nós e tração. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** fiandeiro/cordoeiro, fuso, régua, dinamômetro aferido, varal. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** dano à casca viva, rompimento sob carga, apodrecimento por umidade. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Fibra de Casca Boreal e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** dano à casca viva, rompimento sob carga, apodrecimento por umidade; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **cordas vegetais comuns; adicional como ligadura de B30-15/19/22**. Critério de contribuição própria: carga de ruptura e ciclos úmido/seco superiores ou mesma função a menor custo. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede815ab04ace5bd1074e79` → `B30-02` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** curva de tração (força, alongamento, nós, ciclos úmido-seco), extensão útil de fibra por feixe. **Tratamento recomendado:** CONSERVAR só se uso não for dominado por fibra/corda comum; não pressupor cordão fabricado como insumo de terceiros. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-03 — Espaçador de Mica Calibrado

**1. Ficha original / proveniência (VERIFICADO):** [Mica de Bruma Boreal](https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-03` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Espaçador de Mica Calibrado — peça dimensional de bancada. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 2 folhas de mica ≥60×30 mm cada → 2 espaçadores 50×20 mm; espessura t_lote medida; sem colas. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** medir amostras → clivar → aparar → alinhar por espessura → testar montagem seca → QA. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** lapidador mineral, micrômetro/paquímetro, lâmina, suporte plano e EPI. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** lascas, lamelas livres, isolamento arcano falsamente presumido. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Mica de Bruma Boreal e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** lascas, lamelas livres, isolamento arcano falsamente presumido; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **calços de madeira/metal, mica comum, B30-05 placa de apoio**. Critério de contribuição própria: repetibilidade de folga e desgaste na interface sob carga e umidade. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81e1b179e194e2838c84` → `B30-03` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** distribuição de espessuras, deformação sob pressão da montagem, fragmentação por corte. **Tratamento recomendado:** CONSERVAR como par espaçador, não como isolante mágico; t_tol e espessura reais impedem qualificação. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-04 — Leito Abrasivo de Brecha

**1. Ficha original / proveniência (VERIFICADO):** [Areia de Brecha Granulada](https://app.notion.com/p/3f3c2b324ede816f9af4fdd6758bbe6c) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-04` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Leito Abrasivo de Brecha — consumível de desbaste. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 500 g areia bruta → alvo de 250 g fração aprovada 0,2–1 mm; grão faz remoção mecânica. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** pesar entrada → secar → peneirar → remover impurezas → embalar carga rastreável → testar desbaste. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** preparador mineral, peneiras graduadas, balança, bandeja, exaustão. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** poeira mineral, sílica desconhecida, riscos excessivos em peças finas. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Areia de Brecha Granulada e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** poeira mineral, sílica desconhecida, riscos excessivos em peças finas; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **areia de desbaste comum e B30-17 de acabamento fino**. Critério de contribuição própria: comprovar faixa grossa/durabilidade/removal e não duplicar abrasivo fino. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede816f9af4fdd6758bbe6c` → `B30-04` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** granulometria, dureza relativa, massa separada e taxa de remoção/risco sobre padrão. **Tratamento recomendado:** CONSERVAR se serviço de desbaste se distinguir de B30-17. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-05 — Placa de Apoio de Gnaisse Orientado

**1. Ficha original / proveniência (VERIFICADO):** [Gnaisse de Fibra Transversal](https://app.notion.com/p/3f3c2b324ede81319786eba0f666cef1) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-05` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Placa de Apoio de Gnaisse Orientado — base rígida de oficina. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 bloco ≥200×120×20 mm → 1 placa 180×100×18 mm; auxiliares de fixação já existentes. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** identificar direção das bandas → triagem de fraturas → corte orientado → nivelamento → carga de prova → QA. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** canteiro/lapidador, serra mineral, esquadro, apoio estável, extensômetro/medidor. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** peso, fragmentos e anisotropia; fixação inadequada pode falhar. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Gnaisse de Fibra Transversal e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** peso, fragmentos e anisotropia; fixação inadequada pode falhar; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **pedra de bancada convencional e B30-03 mica como CALÇO, não base**. Critério de contribuição própria: estabilidade sob carga e anisotropia útil com custo superior justificado. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81319786eba0f666cef1` → `B30-05` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** deformação sob carga e direções dos veios, planeza e taxa de trincas. **Tratamento recomendado:** CONSERVAR função de base; não atribuir função de matriz mágica. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-06 — Bolsa Secante de Zeólita

**1. Ficha original / proveniência (VERIFICADO):** [Zeólita de Caverna Fria](https://app.notion.com/p/3f3c2b324ede819695d6e7797fd94370) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-06` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Bolsa Secante de Zeólita — conservação mecânica. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 200 g zeólita seca/classificada + 1 invólucro poroso já existente a identificar; adsorvente + retenção física. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** medir umidade inicial → secar sob curva suportada → classificar → encher invólucro → vedar sem vazamento → comparar umidade em estojo. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** preparador de conservação, balança, peneira, estufa adequada, bolsa permeável, medidor de umidade. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** inalação de pó, saturação, higroscopicidade não aferida. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Zeólita de Caverna Fria e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** inalação de pó, saturação, higroscopicidade não aferida; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **sílica/absorvente comum; não neutraliza venenos ou mana**. Critério de contribuição própria: capacidade adsorvida g água/g, regenerabilidade e custo por ciclo. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede819695d6e7797fd94370` → `B30-06` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** massa de água adsorvida em função do tempo, saturação, recuperação após secagem. **Tratamento recomendado:** CONSERVAR condicionada à identidade do invólucro e ganho mensurado. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-07 — Pigmento de Hematita para Marcação

**1. Ficha original / proveniência (VERIFICADO):** [Hematita de Raiz Fria](https://app.notion.com/p/3f3c2b324ede810b9969e0a01d26457d) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-07` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Pigmento de Hematita para Marcação — insumo pigmentário. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 100 g nódulo → alvo 50 g pó colorante calibrado; água/veículo só se sua procedência for provada. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** lavar → secar → triturar → separar granulometria → pesar → testar deposição em suporte. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** preparador mineral, almofariz/moinho, peneira, balança, coleta de poeira. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** poeira, contaminantes e resíduo nos instrumentos. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Hematita de Raiz Fria e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** poeira, contaminantes e resíduo nos instrumentos; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **ocre/pigmento comum; B30-09 é pena, não substituto do pigmento**. Critério de contribuição própria: cromia/reprodutibilidade e custo de pó útil frente a pigmento já existente. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede810b9969e0a01d26457d` → `B30-07` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** pureza óxido, tamanho de partícula, intensidade de cor e aderência no suporte compatível. **Tratamento recomendado:** MANTER pó seco como produto-alvo; tinta líquida exige receita distinta/veículo. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-08 — Empunhadura Córnea de Ferramenta

**1. Ficha original / proveniência (VERIFICADO):** [Lâmina de Chifre da Ovelha de Chifres](https://app.notion.com/p/3f3c2b324ede812f9857c6fc696202e1) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-08` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Empunhadura Córnea de Ferramenta — componente ergonômico. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 lâmina de chifre ≥90×20×8 mm + interface mecânica de ferramenta existente; suporte não criado. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** comprovar origem → higienizar/estabilizar → recortar → ajustar encaixe sem adesivo novo → polir → ensaiar uso. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** artífice de chifre, serra fina, limas, medidor, bancada de montagem. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** bio-contaminação, fratura e alegação de Investida herdada. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Lâmina de Chifre da Ovelha de Chifres e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** bio-contaminação, fratura e alegação de Investida herdada; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **punho de madeira/chifre comum; B30-10 é ponta de gravação**. Critério de contribuição própria: ergonomia/desgaste mensuráveis em ferramenta compatível. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede812f9857c6fc696202e1` → `B30-08` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** força de extração/torção da empunhadura, umidade e ruptura após ciclos. **Tratamento recomendado:** MANTER como peça de reposição, não item com bônus de dano. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-09 — Pena-Cálamo de Marcação

**1. Ficha original / proveniência (VERIFICADO):** [Pena de Carniceiro](https://app.notion.com/p/3f3c2b324ede81779a63d897f33fed77) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-09` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Pena-Cálamo de Marcação — escrita mecânica. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 pena estrutural íntegra ≥150 mm; tinta de teste EXISTENTE sem fabricar nova tinta. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** comprovar muda/coleta → limpar e secar → abrir ponta do cálamo → regular → realizar 10 passadas → reabrir QA. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** artífice de escrita, lâmina, gabarito, superfície e tinta já existentes. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** bio-contaminação; não transferir furtividade/voo silencioso. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Pena de Carniceiro e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** bio-contaminação; não transferir furtividade/voo silencioso; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **pena comum, pena metálica, B30-07 é pigmento não aplicador**. Critério de contribuição própria: capilaridade, ergonomia e durabilidade superiores com economia justificável. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81779a63d897f33fed77` → `B30-09` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** largura e continuidade do traço 10x, retenção de tinta e perda de rigidez. **Tratamento recomendado:** CONSERVAR como instrumento, não afirmar tinta incorporada. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-10 — Buril de Presa Cavernícola

**1. Ficha original / proveniência (VERIFICADO):** [Presa do Lobo das Cavernas](https://app.notion.com/p/3f3c2b324ede8138851ad3867572384c) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-10` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Buril de Presa Cavernícola — instrumento de entalhe. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 presa íntegra útil ≥60 mm + pega reutilizável se necessária. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** provar origem → estabilizar/limpar → desbastar ponta → ajustar manuseio → entalhar argila crua padrão 10 vezes. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** artífice de osso, lima, gabarito, proteção biológica, apoio. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** fratura e corte; dureza mineral ou poder da Besta não presumidos. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Presa do Lobo das Cavernas e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** fratura e corte; dureza mineral ou poder da Besta não presumidos; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **buril de metal/rocha comum, função distinta da pena B30-09**. Critério de contribuição própria: resistência a desgaste e controle de gravação em argila crua. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede8138851ad3867572384c` → `B30-10` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** legibilidade/risco em argila crua 10x e variação da geometria da ponta. **Tratamento recomendado:** MANTER para substrato macio; não testar em aço sem evidência. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-11 — Selo Cerâmico de Argila

**1. Ficha original / proveniência (VERIFICADO):** [Argila de Raiz Fria](https://app.notion.com/p/3f3c2b324ede81b8b187f217b20c6bdb) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-11` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Selo Cerâmico de Argila — vedação material não mágica. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 200 g argila preparada + q mL água medida; disco-alvo Ø60×10 mm. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** provar plasticidade → retirar inclusões → amassar → moldar → secar massa estável → queimar em forno apto → testar estanqueidade. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** ceramista, molde, balança, paquímetro, secador e forno de curva verificada. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** explosão por umidade, queimadura, falso efeito arcano. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Argila de Raiz Fria e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** explosão por umidade, queimadura, falso efeito arcano; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **vedação de argila comum e inscrições de vedação (efeitos diferentes)**. Critério de contribuição própria: vedação mecânica repetível com compatibilidade da tampa. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81b8b187f217b20c6bdb` → `B30-11` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** retração, curva de queima, trincas e vazamento sob P_teste definido. **Tratamento recomendado:** MANTER como disco cerâmico; se não vedar, reformular como corpo de prova, sem crédito de vedação. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-12 — Carga Carbonática para Argamassa de Oficina

**1. Ficha original / proveniência (VERIFICADO):** [Calcita de Brecha Lechosa](https://app.notion.com/p/3f3c2b324ede81f5b23df718df83b634) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-12` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Carga Carbonática para Argamassa de Oficina — carga mineral intermediária. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 150 g fragmentos de calcita → alvo 100 g carga seca; ligante de argamassa não criado. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** validar composição → lavar/secar → moer → peneirar → pesar → misturar em argamassa controle existente. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** preparador mineral, moinho, balança, peneira, corpos de prova de aderência. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** pó, reação incompatível com ácido/ligante. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Calcita de Brecha Lechosa e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** pó, reação incompatível com ácido/ligante; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **calcário comum; não é argamassa pronta**. Critério de contribuição própria: relação resistência/porosidade/custo do enchimento. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81f5b23df718df83b634` → `B30-12` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** fração carbonática, distribuição de partículas e resistência do ligante-controle. **Tratamento recomendado:** CONSERVAR como ingrediente de argamassa se comparação sustentar; ligante não é presumido. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-13 — Substrato de Germinação de Agulhas

**1. Ficha original / proveniência (VERIFICADO):** [Húmus de Agulhas Frias](https://app.notion.com/p/3f3c2b324ede812b84b2fe10adb88d8e) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-13` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Substrato de Germinação de Agulhas — meio de cultivo. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 750 mL húmus selecionado + até 250 mL areia B30-04 como RECURSO, se aerar; alvo 1 L misturado. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** coleta sustentável → caracterizar pH/umidade/organismos → peneirar → ajustar mistura → envasar → germinar sementes-controle. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** horticultor, medidores de volume, peneira, balança, caixas comparativas. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** patógenos, acidez e dano ecológico de coleta. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Húmus de Agulhas Frias e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** patógenos, acidez e dano ecológico de coleta; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **terra comum; areia B30-04 não pressupõe leito processado**. Critério de contribuição própria: melhoria estatisticamente observável em germinação ou irrigação. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede812b84b2fe10adb88d8e` → `B30-13` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-04 (fonte areia, se necessária); usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** pH, água retida e porcentagem de germinação por grupo aleatorizado. **Tratamento recomendado:** CONSERVAR se existir benefício objetivo contra solo comum; sem magia de crescimento. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-14 — Briquete de Turfa Boreal

**1. Ficha original / proveniência (VERIFICADO):** [Turfa de Pinhal Frio](https://app.notion.com/p/3f3c2b324ede8130a63ed053b8bd132f) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-14` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Briquete de Turfa Boreal — combustível de oficina. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 500 g turfa úmida de composição conhecida → 1 briquete seco de massa m_s medida. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** analisar umidade → separar impurezas → compactar → secar → pesar massa estável → ensaiar calor/fumaça em local seguro. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** operador de combustível, balança, prensa manual, secagem ventilada, bancada adequada. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** fogo, fumaça tóxica, turfeira vulnerável; sem efeito Fogo. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Turfa de Pinhal Frio e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** fogo, fumaça tóxica, turfeira vulnerável; sem efeito Fogo; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **lenha/carvão comum com custo por calor**. Critério de contribuição própria: energia térmica útil, emissão e impacto ambiental em mesmo cenário. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede8130a63ed053b8bd132f` → `B30-14` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** umidade final, massa seca, energia útil por massa e fumaça com proteção. **Tratamento recomendado:** CONDICIONAR fonte ecológica e ganho real; não prometer 50% redução de massa. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-15 — Agulha de Orientação Ferruginosa

**1. Ficha original / proveniência (VERIFICADO):** [Magnetita de Pinhal](https://app.notion.com/p/3f3c2b324ede81ee9a8cd69d25d1d94e) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-15` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Agulha de Orientação Ferruginosa — instrumento de orientação. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 nódulo ≥20 g magnetizado e comprovado + até 30 cm cordão de fonte B30-02 original se exigido. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** testar magnetização → escolher fragmento → suspender fora do metal → alinhar → comparar norte conhecido em N orientações. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** montador, balança, fio, referência magnética não interferida. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** navegação errada e objetos magnéticos próximos; não detecta magia. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Magnetita de Pinhal e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** navegação errada e objetos magnéticos próximos; não detecta magia; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **bússola tradicional e minerais magnéticos comuns**. Critério de contribuição própria: estabilidade de leitura e custo com material PS local. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81ee9a8cd69d25d1d94e` → `B30-15` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-02 (fonte fibra, se necessária); usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** magnetização efetiva, desvio angular e repetibilidade sob interferência controlada. **Tratamento recomendado:** CONDICIONAR magnetização real e instrumento referência; sem bônus automático. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-16 — Mistura Fundente de Fenda Alpina

**1. Ficha original / proveniência (VERIFICADO):** [Feldspato de Fenda Alpina](https://app.notion.com/p/3f3c2b324ede81a2a590c53273f9e6e5) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-16` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Mistura Fundente de Fenda Alpina — insumo de cerâmica. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 200 g feldspato seco moído + 800 g argila do acervo comprovada (B30-11, se compatível); lote massa seca 1 kg. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** analisar mineral → moer → secar argila → homogeneizar → ajustar água → moldar corpos de prova → queimar sob curva. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** ceramista, moinho, balança, misturador, forno aferido e EPI térmico. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** pó respirável e choque térmico; sem afinidade Gelo. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Feldspato de Fenda Alpina e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** pó respirável e choque térmico; sem afinidade Gelo; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **massa cerâmica comum/vidrado convencional**. Critério de contribuição própria: janela de sinterização diferenciada, energia por peça e integridade. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81a2a590c53273f9e6e5` → `B30-16` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-11 (fonte argila, após compatibilidade); usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** temperaturas de sinterização, absorção/porosidade, deformação e energia de forno. **Tratamento recomendado:** CONSERVAR como mistura para corpos de prova, não vidrado mágico; argila física não inferida do nome. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-17 — Granada Calibrada para Lapidação

**1. Ficha original / proveniência (VERIFICADO):** [Granada Abrasiva de Escarpa](https://app.notion.com/p/3f3c2b324ede8150939dc8e911a3c5e1) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-17` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Granada Calibrada para Lapidação — abrasivo de acabamento fino. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 150 g rocha granular bruta → alvo 100 g pó calibrado, granulometria menor que B30-04. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** caracterizar dureza → triturar em contenção → peneirar → pesar frações → ensaiar lapidação padronizada. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** preparador mineral, moinho, peneiras graduadas, balança, lupa, exaustão. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** pó e dano à superfície; não transferir poder do bioma. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Granada Abrasiva de Escarpa e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** pó e dano à superfície; não transferir poder do bioma; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **B30-04 (desbaste grosso) e granada/abrasivo ordinários**. Critério de contribuição própria: faixa de acabamento e custo por acabamento obtido. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede8150939dc8e911a3c5e1` → `B30-17` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** faixa fina de grão e rugosidade final por massa de abrasivo. **Tratamento recomendado:** CONSERVAR se classe fina funcionalmente distinta for demonstrada. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-18 — Revestimento Magnesiano de Cadinho

**1. Ficha original / proveniência (VERIFICADO):** [Magnesita de Garganta Serrana](https://app.notion.com/p/3f3c2b324ede8113a005f7b254490583) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-18` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Revestimento Magnesiano de Cadinho — refratário de oficina. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 500 g magnesita seca + 250 g argila/ligante existente qualificado + q mL água; rendimento m_revest medida. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** analisar → calcinar sob curva técnica → moer → compor ligante → aplicar no cadinho teste → curar → fazer ciclos térmicos. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** ceramista/refratarista, forno compatível, molde de cadinho, medidor de espessura, EPI. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** falha térmica, queimadura, expansão diferencial. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Magnesita de Garganta Serrana e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** falha térmica, queimadura, expansão diferencial; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **cadinho sem revestimento e revestimentos usuais**. Critério de contribuição própria: ganho refratário/vida útil que compense custo e risco. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede8113a005f7b254490583` → `B30-18` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-11 (ligante argiloso condicionado); usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** espessura aderida, temperatura máxima do substrato, N ciclos e falhas térmicas. **Tratamento recomendado:** CONDICIONAR forno/ligante verdadeiros e prova de compatibilidade. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-19 — Invólucro Cutâneo de Ferramenta

**1. Ficha original / proveniência (VERIFICADO):** [Placa Cutânea do Behemoth Glacial](https://app.notion.com/p/3f3c2b324ede814e84e6e254bae3b242) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-19` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Invólucro Cutâneo de Ferramenta — proteção de ferramenta. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 placa íntegra ≥150×100 mm + até 50 cm Fibra de Casca Boreal B30-02 como recurso PS, não produto presumido. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** provar drop autorizado → descontaminar/estabilizar → medir espessura → recortar → costurar/amarrar → submeter a atrito. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** curtidor/artífice, lâmina, medidor, bancada de abrasão, EPI biológico. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** contaminação e deterioração cutânea; não concede resistência a frio. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Placa Cutânea do Behemoth Glacial e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** contaminação e deterioração cutânea; não concede resistência a frio; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **couro comum e B30-22 estojo rígido**. Critério de contribuição própria: proteção flexível específica por atrito e uso, distinta de contenção rígida. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede814e84e6e254bae3b242` → `B30-19` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-02 (fonte fibra, não cordão pronto); usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** resistência a abrasão/flexão, compatibilidade microbiológica e tamanho de ferramenta. **Tratamento recomendado:** CONSERVAR se cura e aplicação justificam drop raro. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-20 — Pasta Abrasiva de Esmalte Rinolupo

**1. Ficha original / proveniência (VERIFICADO):** [Limalha de Esmalte do Rinolupo](https://app.notion.com/p/3f3c2b324ede81b682edf096ae99470a) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-20` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Pasta Abrasiva de Esmalte Rinolupo — pasta de acabamento. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 50 g limalha esterilizada/classificada + até 100 mL veículo EXISTENTE compatível (água se cabível). Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** atestar coleta → higienizar → caracterizar dureza e tamanho → misturar com veículo → polir padrão → pesar/medir riscos. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** lapidador, balança, peneira, recipiente de preparo, medidor de rugosidade. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** bio-contaminação, abrasão e contaminação de peças. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Limalha de Esmalte do Rinolupo e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** bio-contaminação, abrasão e contaminação de peças; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **B30-17 granada fina, B30-04 areia; pasta comum**. Critério de contribuição própria: performance úmida/de precisão acima de pó já disponível com custo justificado. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81b682edf096ae99470a` → `B30-20` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** dureza/granulometria, rugosidade e arranhamento, estabilidade de suspensão. **Tratamento recomendado:** CONDICIONAR veículo e ganho econômico; não conceder Investida da Besta. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-21 — Régua Entalhada de Presa de Mamute

**1. Ficha original / proveniência (VERIFICADO):** [Lasca de Presa do Mamute Antigo](https://app.notion.com/p/3f3c2b324ede814ab353cf6008946d2c) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-21` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Régua Entalhada de Presa de Mamute — instrumento dimensional linear. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 lasca íntegra ≥200×25×10 mm → régua ≤180 mm com divisões de 10 mm. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** provar origem → higienizar → retificar lado → riscar usando padrão preexistente → polir → verificar estabilidade à umidade. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** artífice de osso, serra fina, gravador, medidor referência. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** rachadura, deformação e desperdício de drop raro. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Lasca de Presa do Mamute Antigo e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** rachadura, deformação e desperdício de drop raro; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **régua comum madeira/metal; B30-01 é malha plana**. Critério de contribuição própria: valor funcional/cultural demonstrado contra régua ordinária. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede814ab353cf6008946d2c` → `B30-21` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** erro das marcações e empeno em mudanças de umidade. **Tratamento recomendado:** CONDICIONAR diferenciação; se régua simples inferior, não publicar só para quota. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-22 — Estojo Articulado de Quitina

**1. Ficha original / proveniência (VERIFICADO):** [Quitina de Exoesqueleto do Escorpião Ártico](https://app.notion.com/p/3f3c2b324ede8141acddf0bb23ffe56c) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-22` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Estojo Articulado de Quitina — estojo para amostras inertes. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 2 placas ≥60×30 mm + 30 cm fibra de casca R01 como ligação flexível. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** provar muda/obtenção → higienizar → cortar placa → perfurar → unir com fio → testar abertura/fecho. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** artífice de quitina, serra, broca manual, gabarito e EPI biológico. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** fratura, contaminação; não preserva veneno nem mana. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Quitina de Exoesqueleto do Escorpião Ártico e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** fratura, contaminação; não preserva veneno nem mana; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **estojo de madeira/fibra e B30-19 invólucro flexível**. Critério de contribuição própria: rigidez leve e acesso repetido versus estojo ordinário. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede8141acddf0bb23ffe56c` → `B30-22` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-02 (fonte fibra, não cordão pronto); usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** N ciclos de abrir/fechar, resistência da junta, retenção de conteúdo inerte. **Tratamento recomendado:** CONSERVAR só se fecho com placa demonstrar vantagem real. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-23 — Pino Ósseo de Alinhamento

**1. Ficha original / proveniência (VERIFICADO):** [Apara Óssea do Frígido Ossário](https://app.notion.com/p/3f3c2b324ede81efb836ded2692cfd89) · R02 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-23` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Pino Ósseo de Alinhamento — componente de alinhamento. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 apara óssea ≥60 mm e seção ≥8 mm proposta; sem resina mágica. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** provar drop e ausência de instabilidade → higienizar → reduzir seção → arredondar ponta → ensaiar encaixe e flexão. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** artífice de osso, serra, lima, paquímetro e contenção. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** instabilidade biológica/espectral não quantificada; contenção obrigatória. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Apara Óssea do Frígido Ossário e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** instabilidade biológica/espectral não quantificada; contenção obrigatória; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **pino de madeira/osso comum e calço B30-03**. Critério de contribuição própria: melhora útil de alinhamento e segurança do material raro. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q2 — engenharia parametrizada, SEM prova empírica e SEM RC5**. Impeditivo técnico: Validação do insumo PS, metrologia de lote, teste funcional comparativo e custo/economia; integridade de cadeia e anti-duplicata. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81efb836ded2692cfd89` → `B30-23` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** estabilidade espectral e bioquímica sob protocolo seguro, força de flexão e alinhamento. **Tratamento recomendado:** CONDICIONAR antes de qualquer teste comum ao laudo de estabilidade; sem efeito Gelo. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-24 — Padrão Morfológico Controlado de Espinho Flora

**1. Ficha original / proveniência (VERIFICADO):** [Espinho de Garra do Tigre Flora](https://app.notion.com/p/3f3c2b324ede810fb218c5033bfca614) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-24` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Padrão Morfológico Controlado de Espinho Flora — amostra analítica — não receita qualificada. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 espinho PS + recipiente seguro existente não identificado, vedação/dimensão a apurar. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** identificar origem → acondicionar sem dispersão → observar morfologia sem abertura → fotografar/medir → arquivar sob custódia. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** analista de materiais biológicos, lupa, recipiente resistente validado, EPI; protocolo de contenção não confirmado. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** toxicidade e atividade residual desconhecidas; não formular veneno. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Espinho de Garra do Tigre Flora e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** toxicidade e atividade residual desconhecidas; não formular veneno; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **B30-25 espinho Felpudo e amostra biológica genérica**. Critério de contribuição própria: existência de propriedade estrutural que justifique PADRÃO específico e consumidor real. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede810fb218c5033bfca614` → `B30-24` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-25 mesmo protocolo de referência, produto único se aplicável; usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** morfometria e eventual atividade residual observadas sem extração; consumidor analítico. **Tratamento recomendado:** MERGE PROPOSTO com B30-25 em protocolo de comparação se só houver custódia; manter fonte separada. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-25 — Amostra Comparativa de Espinho Tegumentar Felpudo

**1. Ficha original / proveniência (VERIFICADO):** [Espinho de Pelagem do Felpudo](https://app.notion.com/p/3f3c2b324ede816cac14f775dad4c8a7) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-25` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Amostra Comparativa de Espinho Tegumentar Felpudo — amostra analítica — não receita qualificada. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** 1 espinho PS + recipiente seguro existente a comprovar. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** comprovar origem → isolar → comparar medidas de tegumento contra B30-24 → arquivar amostra com rastreio. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** analista biológico, lupa, recipiente/EPIs, registrador de amostra. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** atividade residual não conhecida, riscos biológicos. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Espinho de Pelagem do Felpudo e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** atividade residual não conhecida, riscos biológicos; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **B30-24 mesmo processo de custódia; pele/planta não são equivalência presumida**. Critério de contribuição própria: separação de morfologia com uso analítico efetivo. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede816cac14f775dad4c8a7` → `B30-25` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-24 mesma família, anti-duplicata; usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** variação de morfologia e efeito residual versus B30-24; existência de uso distinto. **Tratamento recomendado:** MERGE PROPOSTO protocolo compartilhado com B30-24; NÃO contar segundo REC-ID sem transformação distinta. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-26 — Catalisador Experimental de Tenacidade Córnea

**1. Ficha original / proveniência (VERIFICADO):** [Essência de Ovelha de Chifres](https://app.notion.com/p/3f3c2b324ede81a19cc9d6a89841e3b7) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-26` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Catalisador Experimental de Tenacidade Córnea — hipótese de incorporação em compósito. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** dose d26 e concentração da essência não definidas; amostra de chifre já existente somente para controle; veículo não identificado. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** validar perfil de extração → definir unidade e pureza → preparar amostra e placebo com contenção → testar tenacidade sob carga → comparar cegamente. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** especialista em AA e material córneo; equipamento de ensaio e contenção dependentes de autorização. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** essência sem estabilidade conhecida; não herdar Investida. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Essência de Ovelha de Chifres e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** essência sem estabilidade conhecida; não herdar Investida; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **compósito de chifre sem essência B30-08 e aditivos já existentes**. Critério de contribuição própria: incremento reprodutível de propriedade física sem conferir poder animal. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81a19cc9d6a89841e3b7` → `B30-26` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-08 (chifre como comparador), essência sem causalidade; usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** concentração/dose, resistência do compósito, efeito com controles placebo. **Tratamento recomendado:** CONDICIONAR; se não houver transferência causal, abandonar catalisador e preservar recurso PS. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-27 — Tinta Experimental de Assinatura Aviária

**1. Ficha original / proveniência (VERIFICADO):** [Essência de Carniceiro](https://app.notion.com/p/3f3c2b324ede816dac4fe2d085290425) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-27` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Tinta Experimental de Assinatura Aviária — hipótese de veículo de inscrição. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** dose d27 desconhecida + suporte físico já existente; tinta/veículo não identificados. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** validar extração e identidade → identificar veículo autorizado → preparar controle e composto → depositar → verificar assinatura retida. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** inscripcionista/alquimista, recipientes/medidores/controle de estabilidade não certificados. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** contaminação/instabilidade; furtividade não transferida. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Essência de Carniceiro e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** contaminação/instabilidade; furtividade não transferida; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **tinta comum e B30-07 pigmento, B30-09 cálamo**. Critério de contribuição própria: assinatura de inscrição distinta, legível e causal, não nome de Besta. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede816dac4fe2d085290425` → `B30-27` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** B30-07/B30-09 para comparação de pigmento/aplicador sem transferência mágica; usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** veículo e concentração, retenção de assinatura versus controle, estabilidade temporal. **Tratamento recomendado:** CONDICIONAR; se não houver veículo ou assinatura, manter pesquisa, não receita. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-28 — Reagente Experimental de Resposta Silvestre

**1. Ficha original / proveniência (VERIFICADO):** [Essência de Lobo das Cavernas](https://app.notion.com/p/3f3c2b324ede813780bfc86dd62cd3ac) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-28` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Reagente Experimental de Resposta Silvestre — hipótese botânica não sustentada. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** dose d28, unidade e concentração pendentes; planta de referência aprovada ausente. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** verificar premissa botânica nas regras → testar só se compatível → comparar planta controle com placebo sem efeitos de rastreio. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** botânico e especialista AA, contenção para essência; nenhum procedimento canônico aprovado. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** premissa de rastreio animal não prova resposta vegetal. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Essência de Lobo das Cavernas e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** premissa de rastreio animal não prova resposta vegetal; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **essência animal e reagentes botânicos existentes; tentativa de transferência indevida**. Critério de contribuição própria: evidência de afinidade Planta efetiva específica (atualmente não encontrada). A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede813780bfc86dd62cd3ac` → `B30-28` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** presença de mecanismo botânico na fonte canônica ANTES de ensaiar qualquer planta. **Tratamento recomendado:** REFORMULAR: sem suporte botânico, estudar preservação/identificação da essência; não criar reagente vegetal artificioso. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-29 — Concentrado Experimental de Afinidade Planta Predatória

**1. Ficha original / proveniência (VERIFICADO):** [Essência de Tigre Flora](https://app.notion.com/p/3f3c2b324ede81709ea8df4b319397f3) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-29` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Concentrado Experimental de Afinidade Planta Predatória — hipótese de concentrado de essência Planta. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** dose d29 e unidade desconhecidas + controle de Essência Vida de Planta a identificar. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** validar origem e pureza → preparar duas diluições mensuradas e controles → observar afinidade em sistema autorizado → comparar. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** especialista AA, medidor de potência e contenção não comprovados. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** toxidade, extração e exposição da Party desconhecidas. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Essência de Tigre Flora e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** toxidade, extração e exposição da Party desconhecidas; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **Essência de Vida de Planta / concentrados vegetais do acervo**. Critério de contribuição própria: potência/uso diferente do genérico com segurança demonstrada. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede81709ea8df4b319397f3` → `B30-29` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. **Dependência cruzada:** essência Planta genérica existente a localizar; usar a fonte existente, não presumir produto intermediário já fabricado.

**Novidade decisória / evidência mínima que realmente decide:** concentração/afinidade em escala validada, diferencial para essência Planta comum. **Tratamento recomendado:** CONDICIONAR comparação; MERGE com família de extratos Planta se sem diferencial. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---

### B30-30 — Padrão Experimental de Estabilidade de Essência Felpudo

**1. Ficha original / proveniência (VERIFICADO):** [Essência de Felpudo](https://app.notion.com/p/3f3c2b324ede8124bb19e5529e1b3b8a) · R01 · ficha PS/semicanônica preexistente. Fonte de engenharia: AUD-CRAFT R42; triagem funcional R43. Identificador `B30-30` é DESIGN-ID e não REC-ID.

**2. Produto-alvo / utilidade (PROPOSTO):** Padrão Experimental de Estabilidade de Essência Felpudo — ensaio de estabilidade — não receita qualificada. Deve atender uso material mensurável; necessidade comercial/posse no cenário ainda não comprovada.

**3. Classificação, mecânica e limites:** ferramenta/insumo material de oficina sem bônus de dano, defesa, inscrição, magia, alteração de rank, atributo ou efeito da Besta. Origem e faixa PS não classificam automaticamente a potência do produto. RIn/FIP do item final PENDENTES ou N/A se puramente comum.

**4–5. BOM normalizada, quantidades/unidades e função de ingrediente (PROJETO):** dose d30 sem unidade, recipiente e janela temporal não identificados. Toda quantidade sem ensaio é alvo de design; stock e disponibilidade in-game NÃO comprovados. Meios reutilizáveis são ferramental, não ingredientes gratuitamente existentes.

**6. Transformação operacional BOM↔etapas:** validar origem → caracterizar concentração inicial → lacrar amostras controle → medir variação temporal → comparar essência genérica. Em cada etapa manter entrada, saída, resíduo, rejeição/retrabalho e identificação de lote; nenhuma criação de insumo fora da lista.

**7–8. Ferramental, especialista, ambiente e pré-condições:** especialista AA, recipientes homologados, metrologia de concentração indisponível. Demonstrar disponibilidade autorizada, treinamento, origem lícita, segurança e adequação do ambiente antes de produção. Todas as presenças físicas continuam PENDENTES.

**9. Lote e rendimento:** lote-alvo conforme BOM. Rendimento real `N_PASS / N_in`, com unidades compatíveis, é DESCONHECIDO. Medir subprodutos, consumo efetivo e perdas por subetapa. Se o produto for amostra/laudo (PRE-Q1), não contar como manufatura RC5 sem produto transformado materialmente distinto.

**10. Falhas, perdas e recuperação:** instabilidade e efeito de charme/regeneração jamais herdado. Reprocessar somente quando reversível e comprovadamente seguro; descartar/quarentenar unidades contaminadas, rachadas, instáveis ou incompatíveis. Reprocessamento entra no tempo/custo, nunca transforma REJECT em PASS por decisão editorial.

**11. Tempo, custo e proveniência:** tempo numérico não aferido salvo o tempo de PROJETO de 55 min de B30-01; demais etapas com `t_setup`, `t_i`, `t_wait`, `t_rework`, `t_log` sem valor. CI (entrada Essência de Felpudo e auxiliares realmente necessários) + CP (perdas, separadas do CI) + CF (rejeição/retrabalho) + CT (tempos registrados × tarifa do ofício) + CE (ferramentas/energia) + CK (conhecimento verificável) + CL (logística) + CA (conservação) + CC (capital/oportunidade); CTE por peça aprovada somente se N_PASS > 0. Preço MED exige mercado, época, unidade e comparador reais. Todos valores numéricos econômicos: PENDENTES.

**12. Segurança/restrições:** instabilidade e efeito de charme/regeneração jamais herdado; permissão de obtenção PS, conservação, rastreabilidade, proteção do operador, P4/Party e eventual SC não presumidas. Acionamento de efeito de combate expressamente PROIBIDO.

**13–14. EXISTING-FIRST, anti-duplicata e mérito:** comparar com **protocolo comum de estabilidade de essências, essencialmente método e não produto**. Critério de contribuição própria: diferenciação de CONSERVANTE OU MATERIAL transformado, não mero laudo de estabilidade. A busca histórica por nome foi limitada: antes de criar REC-ID, procurar função, nome, ID, variantes e linhagem no índice global; se equivalente melhor, reusar/derivar/merge, NÃO duplicar por meta.

**15. Maturidade e travas distintas:** **PRE-Q1 — hipótese funcional, NÃO qualificada para receita executável**. Impeditivo técnico: Identidade, mecanismo/necessidade material, insumo quantificado e seguro, comparador e decisão merge/reformulação; não admitir receituário artificioso. Impeditivo administrativo, INDEPENDENTE: `F5 P0/RED`, `C19-021 UNKNOWN-SIDE-EFFECT`, fencing/writer/GREEN ausentes, REC-LIB parent físico pendente, NAC-PASS material HOLD. Não é RC5 nem validação técnico-empírica.

**16. Grafo futuro (NÃO MATERIALIZADO):** ficha PS `3f3c2b324ede8124bb19e5529e1b3b8a` → `B30-30` (especificação/dossiê local, SEM REC-ID) → `REC-ID=NULL` (apenas após aceite e LIB-GATE) → `PRODUTO-ID=NULL` (apenas após aceite) → links bidirecionais verificados. Nenhuma dependência B30 cruzada obrigatória indicada no desenho base.

**Novidade decisória / evidência mínima que realmente decide:** identidade, concentração e curva temporal; provar que produto material seria criado. **Tratamento recomendado:** MERGE PROPOSTO com protocolo transversal de análise; preservar ficha, sem receita-filler. Prova negativa do diferencial gera reformulação, equivalência ou descarte da RECEITA, preservando sempre a FICHA do recurso.

---
