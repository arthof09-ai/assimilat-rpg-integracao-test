# QA local — evidências e limites BACKFILL-30 (14/10/2026)

## Evidências positivas

1. Reabertos no Notion Mestre: OP-ARQ-RIN-REC-01, AUD-CRAFT-F5-REMAP-01, ordem BACKFILL-30, PROMPT sucessão, REC-LIB-01, PR-ITEM-02, PR-SC-01, Runtime e tickets existentes IBX-38/IBX-78. As referências foram usadas como fonte, não como autorização material.
2. Confrontadas por `notion.fetch` **as 30 páginas individuais** de recursos PS (IDs nos `MATRIZ-30x30.json`), incluindo título, marca PS e origem regional. Conjunto documental da R01: 20/20; R02: 10/10. O R52 da ZIP histórico foi lido diretamente para controle B30-01. Esta leitura não foi um inventário exaustivo de todo o Notion/receituário histórico.
3. Matriz 30/30 sem repetição de DESIGN-ID nem de página-fonte, com 23 `PRE-Q2` e 7 `PRE-Q1`; 30 seções técnicas e 30 conjuntos dos tópicos 1–16 verificáveis no dossiê consolidado.
4. Detalhes numéricos da B30-01 mantêm estritamente a proveniência de PROJETO de R41/R42/R52: `105,3 cm³`, `76,8 cm³`, 55 minutos, 10 mm malha e QA com incerteza — nenhum desses números foi tratado como medição real.
5. Falhas de mérito nas PRE-Q1 têm alternativa por candidato, com recomendação de merge/variante/reformulação sem descartar as fichas.
6. Integridade dos artefatos digitais calculada por SHA-256 com `MANIFESTO-SHA256.txt`, e pacote ZIP testado por CRC. PDF de leitura separado renderizado e inspecionado em páginas amostrais.

## Limites explícitos

- `PRE-Q2`/`PRE-Q1` são classificações de documento já existentes no AUD; **não** há nesta rodada reclassificação oficial para RC2–RC4. RC0/RC1 são exemplos/propostas históricas, não receitas executáveis certificadas.
- Não houve ensaio, montagem de produto, compra, leitura de estoque canônico, UAT humana de receitas, negociação econômica ou medição real; QA do motor R48 é exclusivamente sintético e não substitui nenhum destes eventos.
- Não houve pesquisa exaustiva em todo o catálogo de produtos/receitas existentes para provar inexistência funcional; as alternativas explícitas requerem pesquisa final no destino REC-LIB antes de publicação. A distinção dos 23 produtos é projeto e sujeita a prova de não duplicação.
- Não houve `REC-ID`, `PRODUCT-ID` ou backlink criado, nem atribuição de writer/lease/epoch/GREEN. `IBX-38`, `IBX-78` e `C19-021` permanecem dependências reais. Nenhuma escrita em Notion, Party ou O Primeiro.
- O plano `SBX-R48-BATCH-UI-2afb696406a6e839` foi mantido em DRAFT; os ZIPs v03 e backup de sessão não foram editados.

## Métricas com denominador

- **30/30 fontes PS localizadas e confrontadas nesta rodada** (100% do conjunto alvo, NÃO do Notion global).
- **30/30 especificações de projeto consolidadas** (100% do conjunto alvo), com QA de presença dos 16 tópicos; não são receitas RC5.
- **23/30 PRE-Q2 e 7/30 PRE-Q1**, classificação de entrada preservada.
- **0/30 avanço formal de classe RC demonstrado nesta rodada**, porque nenhum gate de validação externa/experimental foi satisfeito.
- **0/30 tecnicamente validadas em condições reais**, **0/30 RC5**, **0/30 REC-ID físico**, **0/30 recurso↔receita↔produto com vínculo físico**.
- **Nº futuro de receitas distintas legitimamente aptas:** **NÃO DETERMINÁVEL AINDA** (anti-filler). O número de nomes 30 não é prova de cardinalidade legítima 30.

## NAC-PASS / classificação correta

**Local artifact QA = PASS limitado** à cobertura dos 30 registros, identidade dos documentos-fonte e integridade criptográfica de arquivos. **NAC-PASS-02 material/terminal = HOLD**, `F5=P0/RED`, `C19-021=UNKNOWN-SIDE-EFFECT`, `WRITER=NONE CLAIMED`, `NEW F5 RESOURCES=DENY`. Não declarar NAC-PASS documental canônico sem respectivo registro/gate no Notion; este é relatório local de qualidade e entrega.
