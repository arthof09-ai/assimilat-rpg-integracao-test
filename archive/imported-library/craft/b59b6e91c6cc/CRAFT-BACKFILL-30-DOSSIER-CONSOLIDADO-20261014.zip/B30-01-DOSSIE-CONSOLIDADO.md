# B30-01 — DOSSIÊ TÉCNICO CONSOLIDADO DA TÁBUA LAMELAR DE INSCRIÇÃO

**CM-000002 / WS0001 · 14/10/2026 · PRE-REC DOCUMENTAL, não REC-ID e não RC5.**

## 1. Identidade, autoridade e critério de utilidade

- **Fonte de recurso VERIFICADA documentalmente:** [Ardósia de Geada Lamelar](https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2), `CRAFT-F5-R01-MIN-01`, proposta PS/semicanônica da R01. É rocha lamelar e substrato de gravação, não elemento frio mágico. A ficha PS não prova mina, coleta, disponibilidade, posse ou lote.
- **Dossiês precedentes (NÃO DUPLICAR):** `PRE-REC-CRAFT-R41-TLI-001` e `-002`, `CP-CRAFT-I0015-FENCE-COST-R41-002`, `PRE-REC-CRAFT-R42-TLI-METROLOGY-001`, `BACKFILL30-CRAFT-R42-A-001`, R44/R48 e `R52_B30-01_MINIMO_EMPIRICO.md`. Todos preservados historicamente, sem reexecutar fábrica fictícia.
- **Produto-alvo ÚNICO:** Tábua Lamelar de Inscrição (também chamada Tábua Lamelar de Ardósia em versão histórica); **não** são dois produtos. Utilidade física: apoio rígido de prática/inspeção de traços ortogonais e inscrições NÃO mágicas. Não concede modificador de perícia, cargas, magia ou afinidade.
- **Categoria:** ferramenta/gabarito durável de oficina, não consumível de inscrição nem artefato espiritual. Potência/ranqueamento mecânico: nenhuma comprovada; produto proposto sem classificação mágica. FIP/custo PA/Alma: N/A enquanto sem poder.
- **GAP:** demonstrar que essa função é demandada em oficina e não igualmente suprida, mais barato, por placa de pedra comum, ardósia comum, madeira, pergaminho ou gabarito de gravação histórico. O fato de existir uma ficha PS de ardósia não prova o benefício da tábua.

## 2. BOM unitária: separação matéria, consumíveis e bens de capital

| Ref | Quantidade de PROJETO | Origem e função | Natureza da prova |
|---|---|---|---|
| M01 | 1 lâmina inteira, **entrada mínima 130 × 90 × 9 mm** | Ardósia PS `CRAFT-F5-R01-MIN-01`: corpo físico, apta somente sem trincas/delaminação | Página PS VERIFICADA; amostra e dimensão NÃO verificadas |
| E01 | 1 conjunto reutilizável corte/clivagem/apoio | Geometria e segurança do corte; depreciação por ciclo | Existência no mundo/posse PENDENTE |
| E02 | 1 conjunto régua ≥120 mm, esquadro, paquímetro e referência plana | Medição antes/depois, marcação e QA independente | Calibração e existência PENDENTES |
| E03 | Abrasivo compatível, consumo `a` g/peça | Aplainar/chanfrar e regularizar sulcos; nenhum recurso F5 novo | Identidade, fornecedor e `a` PENDENTES |
| E04 | Escova/coleta de poeira, EPI, descarte `u` unidades | Controlar resíduo, cortes e particulados | Custos/consumo PENDENTES |

**Não faz parte da BOM:** tinta, cola, inscrição ativa, essência, runa, catalisador ou outra pedra. Caso uma etapa requeira componente não listado, retornar a EXISTING-FIRST e versionar o projeto; não declarar compra, criação ou disponibilidade por inferência.

## 3. Geometria e rastreabilidade do material

- Volume retangular bruto de design `V0 = 130 × 90 × 9 mm³ = 105.300 mm³ = 105,3 cm³`.
- Volume acabado retangular de design `Vf = 120 × 80 × 8 mm³ = 76.800 mm³ = 76,8 cm³`.
- Relação geométrica ideal `Vf/V0 = 76,8 / 105,3 = 72,934%` (**não** taxa de fabricação aprovada); remoção geométrica ideal `27,066%`. Bordas, sulcos, trincas e densidade podem alterar as massas reais; não converter volume em custo de refugo sem massa aferida.
- Densidade `ρ` não medida, massa `m0 = ρ×105,3 cm³`, massa acabada `mf` somente após pesagem. `m_entrada ≈ m_acabada + m_aparas + m_poeira + m_outras_perdas` é equação de reconciliação, sujeita a incerteza/calibração.
- Unidade de compra/coleta deve ser **lâmina que satisfaz a dimensão**, não quantidade genérica de rocha ou estoque do motor sandbox. Cada lâmina recebe `lot_id`, `plate_id`, origem, proprietário, estado inicial e decisão de triagem.

## 4. Rota técnica completa (55 minutos ATIVOS de PROJETO, NÃO cronometrados)

| Ordem | Mapeamento da BOM | Operação definida | Min de PROJETO | Registro mínimo da etapa |
|---|---|---|---:|---|
| 1 | M01 + E02/E04 | Identificar origem, medir três eixos, planeza, massa, umidade e fissuras; separar apta/rejeitada | 5 | lote e resultado de triagem |
| 2 | M01 + E01/E02 | Riscar margens de corte 120 × 80 mm; clivar em apoio estável, recolher aparas | 10 | dimensões intermediárias, perdas e trincas |
| 3 | M01 + E02/E03 | Aplainar faces e reduzir espessura até 8 mm previstos; avaliar delaminação | 15 | espessura, planicidade, abrasivo `a`, massa removida |
| 4 | M01 + E01/E02 | Riscar linhas-guia ortogonais com passo 10 mm e sulco superficial ≤0,5 mm | 10 | desvios de passo, profundidade e ortogonalidade |
| 5 | M01 + E03/E04 | Chanfro/arredondamento de quinas; coleta de pó e limpeza | 10 | integridade das bordas, limpeza, resíduos |
| 6 | E02, gabarito independente | QA dimensões, malha, trincas, planeza e registro PASS/REWORK/REJECT | 5 | laudo por peça e rastreio de operador |

**Condições indispensáveis:** bancada estável, superfície de referência, controle de poeira, uso real autorizado da lâmina PS, artesão/lapidador com aptidão a confirmar, medição independente, descarte rastreável. Estabilidade de umidade/tempos de espera não mensurados; cronômetro deve separar `setup, t_ativo, t_espera, t_QA, t_logística, t_retrabalho`.

## 5. QA de aceitação — critérios PROPOSTOS até aprovação técnica

| Propriedade | Limite da versão de design | Prova exigida |
|---|---|---|
| Comprimento | 120 mm ±1 mm | Medidor aferido, erro e intervalo de incerteza |
| Largura | 80 mm ±1 mm | Medidor aferido, erro e intervalo de incerteza |
| Espessura | 8 mm ±0,5 mm | Vários pontos, variação e incerteza |
| Planeza | desvio ≤1 mm em vão de 120 mm | Regra ou superfície de referência controlada |
| Malha | 10 mm ±1 mm, linhas ortogonais | Gabarito independente com leitura repetível |
| Sulco | profundidade ≤0,5 mm | Medida ou perfilometria compatível |
| Integridade | zero trinca passante, delaminação solta ou aresta cortante | inspeção/lupa, fotografia, QA independente |
| Uso funcional | ao menos 3 marcações repetidas sem ruptura (PROPOSTO) | comparação com placa comum sob mesmo protocolo |

**Tratamento da incerteza (R52):** um valor medido nominalmente dentro do alvo não é `PASS` se seu intervalo de incerteza invade o limite. Nesse caso `INDETERMINATE`, reteste ou melhoria de medição. `REWORK` exige operação explícita, com novo tempo/abrasivo e nova medição; trinca crítica = `REJECT` sem fingir reparabilidade.

## 6. Piloto empírico proposto, não executado

Desenho R42: até 3 sublotes de 5 lâminas (`n_design=15`). **Não existe amostra de 15 no RPG comprovada.** Se `n_real<15`, documentar quantas existem e a incerteza maior, sem completar artificialmente. A prova envolve cadastro de lotes, dimensões antes/depois, tempos de cada operação, consumíveis, `N_in`, `N_PASS`, `N_REWORK`, `N_REJECT`, pesos, fotografias e benchmark com placa comum igualmente adequada.

- **Medição que decide aceitação dimensional:** comprimento/largura/espessura/planicidade/passo de malha e incerteza após usinagem.
- **Medição que decide fabricabilidade:** quantas lâminas reais podem ser clivadas sem trinca e quanto abrasivo/tempo consomem; produção fictícia R48/R49 não responde.
- **Medição que decide utilidade:** repetibilidade e durabilidade de traço comparadas com o substrato padrão, avaliadas por quem realmente usaria a ferramenta.
- **Medição que decide substituição:** custo por ciclo de uso com insumo regional PS versus ardósia comum/placa convencional, com controle de mesma função.
- **Medição que decide segurança:** poeira/fragmentação e viabilidade de proteção na instalação escolhida.

## 7. Rendimento, recuperação, refugo e impacto no estoque

`N_in` = lâminas cadastradas que entram na tentativa. `N_PASS` = peças aprovadas em todos os QAs; `N_REWORK` = peças elegíveis a correção; `N_REJECT` = descartadas por falha crítica. Taxa de peças aptas por tentativa `q_emp=N_PASS/N_in`, apenas após observação e reconciliação. A disponibilidade de lâminas qualificadas é separada de `q_emp`.

Nunca usar `72,934%` como porcentagem de sucessos: é somente o aproveitamento de volume de dois prismas do projeto. Aparas e pó podem ser tratados como resíduo rastreável; não são drop/recurso monetizável sem receita, qualidade, destinação e autoridade independentes. Estoques testados R48 em `sim-75192d55b85e` não representam estoque de nenhuma ficha do mundo. Plano `SBX-R48-BATCH-UI-2afb696406a6e839` permanece DRAFT, sem confirmação/cancelamento.

## 8. Economia: árvore completa, sem preço fictício

**COST-ID de análise, não item:** `COST-PRE-CRAFT-TLI-20261008-001`.

`CI = N_lâminas×P_lâmina_qualificada + a×P_abrasivo/g + u×P_EPI_uso` (contabilizar E01/E02 reutilizáveis em depreciação CE, não de novo em CI).

`CT = w_art×(Σ t_setup+t_corte+t_aplainamento+t_gravação+t_acabamento+t_QA+t_rework)/60` (minutos reais; os 55 min só hipótese para cenário base).

`CTE_lote = CI + CP + CF + CT + CE + CK + CL + CA + CC` com CP descarte/perdas sem duplicar CI, CF falhas/retrabalho, CE ferramentas/energia, CK treinamento/licença, CL logística, CA conservação e CC oportunidade/capital. `CTE_unit=CTE_lote/N_PASS` quando `N_PASS>0`; com zero PASS, custo unitário final não é definido.

**FAVORÁVEL/NORMAL/ADVERSO:** três cenários com `N_PASS`, horas, insumos e falhas medidos/estimados com pressupostos explícitos e fontes; não inventar probabilidades. Diferenciar preço de lâmina, custo de fabricação, valor de fórmula e preço de transação do produto. **MED real: INDETERMINADO** enquanto faltarem mercado, data, qualidade, rota, unidade e comparadores.

## 9. Matriz de completude — o que está e não está resolvido

| Dimensão | Estado | Evidência / próximo ato |
|---|---|---|
| Identidade de recurso | **VERIFICADO PS** | ficha R01 `CRAFT-F5-R01-MIN-01` existente |
| Identidade de produto | **PROPOSTO consolidado** | único nome/alias Tábua Lamelar |
| Categoria/mecânica | **PROJETO COMPLETO sem magia** | não transfere gelo/Inscrição, sem bônus automático |
| BOM/quantidades | **PROJETO COMPLETO** | 1 lâmina e insumos/ferramentas separados; `a,u` pendentes |
| Geometria/QA | **PROJETO COMPLETO** | dimensões e tolerâncias propostas, sem medição |
| Processo/segurança | **ROTA DESENHADA** | 6 passos/55 min de design; infraestrutura não comprovada |
| Tempo/consumo | **A MEDIR** | t_i, secagem, abrasivo, mão de obra real |
| Rendimento/qualidade | **A MEDIR** | N_in/N_PASS, registros com incerteza, laudos |
| Economia/mercado | **MODELO FORMAL PRONTO, PREÇO INDETERMINADO** | taxas, rotas, custos e comparadores reais |
| Substitutos e distinção | **COMPARAÇÃO ESPECIFICADA, NÃO DEMONSTRADA** | placa comum e custo por serviço |
| Disponibilidade in-game | **NÃO VERIFICADA** | amostras, posse, origem e autorização PS |
| RC5 técnico | **NÃO ATINGIDO** | QA empírico, fontes materiais e revisão de mérito |
| REC-ID físico | **NÃO CRIADO** | autorização writer, REC-LIB parent e anti-duplicata |
| Backlinks recurso/receita/produto | **NÃO CRIADOS** | transação canônica futura, readback bilateral |

## 10. Dois gates que nunca podem ser confundidos

**Gate TÉCNICO (independente do bloqueio de escrita):** lote elegível e obtido legitimamente; QA instrumentado com incerteza, repetibilidade, segurança, operador/oficina, consumo/rendimento/tempos, economia justificável, função distinta e revisão da classificação; decisão explícita de prontidão RC5. Nenhum desses fatos é produzido por autorização administrativa.

**Gate ADMINISTRATIVO (independente da engenharia):** fencing demonstrado contra I0014 no ponto de escrita, eventuais requisições em voo tratadas, C19-021 reconciliado sem retry cego, U-SUCCESSION claim/reopen/commit, epoch/lease/GREEN específicos, parent REC-LIB único validado, verificação anti-duplicata na hora do commit, criação de UM REC-ID e eventual produto, backlink triplo efetivamente conferido, NAC-CONT-03/REPA/NAC-PASS terminal. Autorização administrativa não supre o ensaio físico.

## 11. Critério de mérito e decisão futura

**Recomendação de engenharia PROPOSTA:** manter esta especificação como projeto formal prioritário. Confirmar a necessidade de gabarito de traçado em oficina; se a ardósia regional não melhorar vida útil, planicidade ou custo em relação à pedra comum, avaliar o mesmo design como variante de receita-base ou substituição de material, não criar REC-ID somente para fechar 1/30. Se funcionar, publicar uma única receita e um único produto associados à mesma ficha PS, preservando os históricos R41/R42/R52 como evidência.

**Resultado desta consolidação:** documentação técnica e plano de prova completos como projeto; `TECH-VALIDATED=NO`, `RC5=NO`, `REC-ID=NULL`, `PRODUCT-ID=NULL`, `PHYSICAL-LINK=NO`, `MATERIAL=NÃO AUTORIZADO`.
