from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,copy,json
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
checks=0
def ok(c,msg):
 global checks
 assert c,msg;checks+=1
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];network=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.on('request',lambda r:network.append(r.url) if r.url.startswith(('http:','https:')) else None)
 p.set_content(html,wait_until='load')
 ok(p.locator('#r31-author').is_visible(),'section')
 ok(p.locator('#r31-decision-fields textarea').count()==11,'eleven mobile fields')
 ok('0/11' in p.locator('#r31-status').inner_text(),'initial status')
 ok(p.locator('#r31-triage').is_enabled(),'empty draft triage allowed')
 with tempfile.TemporaryDirectory() as td:
  td=Path(td)
  def upload(obj,file):
   path=td/file;path.write_text(json.dumps(obj,ensure_ascii=False));p.locator('#r31-upload').set_input_files(path);p.wait_for_timeout(50)
  with p.expect_download() as info:p.locator('#r31-save').click()
  blank=td/'blank.json';info.value.save_as(blank);draft=json.loads(blank.read_text())
  ok(len(draft['cases'])==4,'four cases')
  ok(sum(len(c['decision_slots']) for c in draft['cases'])==11,'11 slots')
  ok(all(s['decision'] is None for c in draft['cases'] for s in c['decision_slots']),'blank')
  inp=p.locator('#r31-decision-fields textarea').nth(0)
  inp.fill('Resolução TEST; P4 ainda não autorizado')
  ok('1/11' in p.locator('#r31-status').inner_text(),'one note')
  with p.expect_download() as info:p.locator('#r31-save').click()
  part=td/'partial.json';info.value.save_as(part);one=json.loads(part.read_text())
  ok(one['cases'][0]['decision_slots'][0]['decision']=='Resolução TEST; P4 ainda não autorizado','actual text in private draft')
  ok(one['constraints']['notion_write_permitted'] is False,'still blocked')
  ok(one['all_choices_blank'] is False,'R31 correctly recognizes note entered')
  with p.expect_download() as info:p.locator('#r31-triage').click()
  triage=td/'triage.json';info.value.save_as(triage);t=json.loads(triage.read_text())
  ok(t['decisions_reported']==1,'triage summary count')
  ok(not t['authorship_verified'] and not t['canonical_write_allowed'],'triage no authorization')
  ok('Resolução TEST' not in json.dumps(t,ensure_ascii=False),'no text in summary')
  filled=copy.deepcopy(blank and draft)
  for c in filled['cases']:
   for s in c['decision_slots']:
    s['decision']='Rascunho TEST não é ordem CANÔNICA'
  filled['all_choices_blank']=False
  upload(filled,'filled.json')
  ok('11/11' in p.locator('#r31-status').inner_text(),'11 answers imported')
  ok(p.locator('#r31-decision-fields textarea').count()==11,'still 11')
  ok(p.locator('#r31-decision-fields textarea').nth(10).input_value()=='Rascunho TEST não é ordem CANÔNICA','last value')
  tampered=copy.deepcopy(filled);tampered['constraints']['notion_write_permitted']=True
  upload(tampered,'tampered.json')
  ok('REJEITADO' in p.locator('#r31-status').inner_text(),'tampered reject')
  ok(p.locator('#r31-decision-fields textarea').nth(10).input_value()=='Rascunho TEST não é ordem CANÔNICA','rejection no mutations')
  with p.expect_download() as info:p.locator('#r31-save').click()
  after=td/'unchanged.json';info.value.save_as(after)
  ok(json.loads(after.read_text())['constraints']['notion_write_permitted'] is False,'not promoted')
  inj=copy.deepcopy(filled);inj['cases'][0]['decision_slots'][0]['decision']='<img src=x onerror=alert(1)>'
  upload(inj,'injection.json')
  ok('<img src=x' in p.locator('#r31-decision-fields textarea').first.input_value(),'raw text only')
  ok(p.locator('img[src=x]').count()==0,'not interpreted DOM')
  ok(p.locator('#top').inner_text().count('0')>0,'existing core still renders')
  ok(not errors,errors)
  ok(not network,network)
  ok(p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),'no horizontal scroll')
 b.close()
print(f'R31 Chromium mobile author notes {checks}/{checks} PASS')
