"""Auditor de admissibilidade para E31-E40. NÃO é motor de magia nem GM automático.
Regras de procedência: Notion mestre, REC-MOD-EQA/ENC. Nenhum efeito pós-montagem
recebe estado OBSERVED de entrada local. Nunca emite laudo R46/R47.
"""
from __future__ import annotations
import hashlib, json
from pathlib import Path

HERE=Path(__file__).resolve().parent
CASE='LAB-CRAFT-VIGILIA-BOREAL-20261020-001'

def canonical(obj): return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def hash_obj(obj): return hashlib.sha256(canonical(obj)).hexdigest()

def sources():
    doc=json.loads((HERE/'FONTES_READBACK_E31.json').read_text())
    assert doc['case_id']==CASE
    for s in doc['sources'].values():
        assert hashlib.sha256(s['excerpt'].encode()).hexdigest()==s['excerpt_sha256'],'source excerpt changed'
        assert s['url'].startswith('https://app.notion.com/p/')
        assert s['date_observed']
    return doc

def evaluate(control: dict, ss: dict|None=None) -> dict:
    """Admissibilidade mecânica (NÃO observação em jogo). Exact, closed vocabulary."""
    ss = ss or sources()
    mode=control.get('mode')
    materials=set(control.get('materials',[]))
    valid={'cristal','erva','fibra'}
    if materials-valid: return {'status':'REJECTED_UNKNOWN_MATERIAL','observed_magic':False}
    if control.get('observed_magic') or control.get('magic_success') or control.get('witness_role'):
        return {'status':'UNTRUSTED_WITNESS_REJECTED','observed_magic':False}
    if mode=='source_isolated':
        material=control.get('material')
        if material=='erva' and 'erva' in materials:
            return {'status':'SOURCE_PROPERTY_DOCUMENTED','property':'iluminação qualitativa da própria erva','observed_magic':False,'radius_m':None}
        if material=='cristal' and 'cristal' in materials:
            return {'status':'SOURCE_POTENTIAL_DOCUMENTED','property':'pode dissipar escuridão, circunstâncias não especificadas','observed_magic':False,'activation':None}
        if material=='fibra' and 'fibra' in materials:
            return {'status':'SOURCE_NO_MAGIC','property':'apenas função estrutural','observed_magic':False}
        return {'status':'REJECTED_SOURCE_NOT_PRESENT','observed_magic':False}
    if mode=='H1':
        skill=control.get('skill')
        expected={'luminescencia':'erva','contrassombra':'cristal'}.get(skill)
        if expected is None:return {'status':'REJECTED_UNKNOWN_SKILL','observed_magic':False}
        if expected not in materials:return {'status':'SOURCE_MISSING','observed_magic':False,'skill':skill}
        if control.get('requested_radius_m') is not None:
            return {'status':'RADIUS_UNMEASURED','observed_magic':False,'source_effect_qualitative':True}
        return {'status':'MOUNTED_RETENTION_NOT_OBSERVED','observed_magic':False,'source_effect_qualitative':True,'skill':skill}
    if mode=='H2':
        if control.get('copied_inscription') in ('vento_artico','reflexo_profundezas'):
            return {'status':'REJECTED_WRONG_SPELL_PATTERN','observed_magic':False}
        missing=[field for field in ('substrate','compatible_medium','pattern','source_to_pattern_binding','energization_authority','sealing_evidence') if not control.get(field)]
        if missing:
            return {'status':'INSCRIPTION_PROCEDURE_INCOMPLETE','missing':missing,'observed_magic':False}
        # Campos preenchidos não são evidência real de integração.
        return {'status':'AUTHORITY_AND_RESULT_NOT_OBSERVED','observed_magic':False}
    if mode=='pa':
        a=control.get('qualified_envelope')
        if a is None:return {'status':'NO_PA_ENVELOPE','observed_magic':False}
        if a.get('case_id')!=CASE or a.get('daily')!=12 or a.get('per_use')!=7 or a.get('two_uses_total')!=26:
            return {'status':'INVALID_PA_CONTRACT','observed_magic':False}
        if a.get('charge_executed'):
            return {'status':'REJECTED_UNVERIFIED_CHARGE','observed_magic':False}
        return {'status':'PA_TEST_CONSULTATION_ONLY','observed_magic':False}
    return {'status':'REJECTED_UNKNOWN_CONTROL','observed_magic':False}

def scene():
    # O que o RPG permite inferir das regras da fonte, sem inventar um evento.
    cases=[
        ('C01_fonte_erva',{'mode':'source_isolated','materials':['erva'],'material':'erva'}),
        ('C02_fonte_cristal',{'mode':'source_isolated','materials':['cristal'],'material':'cristal'}),
        ('C03_fonte_fibra',{'mode':'source_isolated','materials':['fibra'],'material':'fibra'}),
        ('C04_H1_sem_erva',{'mode':'H1','skill':'luminescencia','materials':['cristal','fibra']}),
        ('C05_H1_sem_cristal',{'mode':'H1','skill':'contrassombra','materials':['erva','fibra']}),
        ('C06_H1_montado',{'mode':'H1','skill':'luminescencia','materials':['erva','cristal','fibra']}),
        ('C07_H1_raio',{'mode':'H1','skill':'luminescencia','materials':['erva','cristal','fibra'],'requested_radius_m':1}),
        ('C08_H2_sem_medio_padrao',{'mode':'H2','materials':['erva','cristal','fibra'],'substrate':'cordão PS TEST'}),
        ('C09_H2_Vento',{'mode':'H2','materials':['erva','cristal','fibra'],'copied_inscription':'vento_artico'}),
        ('C10_H2_Reflexo',{'mode':'H2','materials':['erva','cristal','fibra'],'copied_inscription':'reflexo_profundezas'}),
        ('C11_H2_preenchimento_sem_teste',{'mode':'H2','materials':['erva','cristal','fibra'],'substrate':'P','compatible_medium':'M','pattern':'P','source_to_pattern_binding':'B','energization_authority':'A','sealing_evidence':'S'}),
        ('C12_PA_consulta',{'mode':'pa','qualified_envelope':{'case_id':CASE,'daily':12,'per_use':7,'two_uses_total':26,'charge_executed':False}}),
        ('C13_falsa_observacao',{'mode':'H1','skill':'luminescencia','materials':['erva'],'observed_magic':True}),
    ]
    return {'case_id':CASE,'execution_class':'RPG_RULE_ADMISSIBILITY_TEST_NOT_IN_GAME_OBSERVATION','cases':[{'control_id':id,'input':ctl,'result':evaluate(ctl)} for id,ctl in cases], 'events_in_game':0,'magic_events_observed':0,'new_r48_orders':0}

def previous_store_check(zip_path: str|Path):
    from zipfile import ZipFile
    zip_path=Path(zip_path)
    sha=hashlib.sha256(zip_path.read_bytes()).hexdigest()
    expected='d0b113244cf590a9c30be34c5893c332a08a8e15daa3c17aa9be4cf5356104f0'
    if sha!=expected:raise ValueError('E21_E30_SHA_MISMATCH')
    with ZipFile(zip_path) as z:
        if z.testzip() is not None: raise ValueError('E21_E30_BAD_ZIP_CRC')
        root='CRAFT_E21_E30/results/R48_TEST_DURABLE_NEW/'
        current=json.loads(z.read(root+'CURRENT.json'))
        for fname,h in current['commit_digests'].items():
            actual=hashlib.sha256(z.read(root+'commits/'+fname)).hexdigest()
            if actual!=h:raise ValueError('HISTORICAL_COMMIT_CHANGED')
        results=json.loads(z.read('CRAFT_E21_E30/results/DURABLE_R48_PINGENTE_RESULTS.json'))
        if current['sequence']!=1 or results['structural']['order_id']!='SBX-R48-ORDER-48322' or results['structural']['physical_products']!=0 or results['any_real_magic']:
            raise ValueError('HISTORICAL_SCOPE_CHANGED')
        if current['r48_head']!=results['structural']['r48_head']:raise ValueError('HISTORICAL_HEAD_MISMATCH')
        return {'zip_sha256':sha,'archive_members':len(z.namelist()),'historical_store_sequence':1,'historical_receipt_sha256':results['structural']['r48_batch_receipt_sha256'],'commit_digest_count':len(current['commit_digests']),'unchanged_store_verified':True,'new_transaction_executed':False}

if __name__=='__main__':
    import sys
    res=scene()
    res['baseline']=previous_store_check(sys.argv[1])
    (HERE/'ENSAIO_RESULTADOS_E31.json').write_text(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True))
    print(json.dumps({'cases':len(res['cases']),'statuses':{c['control_id']:c['result']['status'] for c in res['cases']},'observed_magic':res['magic_events_observed'],'r48_new_orders':0,'old_store_sequence':res['baseline']['historical_store_sequence']},ensure_ascii=False,indent=2))
