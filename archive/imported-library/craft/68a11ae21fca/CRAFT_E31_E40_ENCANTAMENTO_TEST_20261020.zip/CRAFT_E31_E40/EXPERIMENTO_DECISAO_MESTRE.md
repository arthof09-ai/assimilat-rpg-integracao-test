# Decisão mestre única — desbloqueio da rota H1 no Laboratório CRAFT

Caso existente `LAB-CRAFT-VIGILIA-BOREAL-20261020-001`, Pingente v1.3. As propriedades intrínsecas da Erva Luz Norte (luz) e do Cristal Aurora (possível interação com escuridão) são documentadas; o REC-MOD-EQA prevê suporte, mas não há regra identificada que garanta suas propriedades depois de uma montagem física não destrutiva. REC-MOD-ENC fornece um processo de inscrição, mas não a fórmula/padrão específicos do Pingente.

**Pergunta de adjudicação TEST:** *Ao prender uma Erva da Luz do Norte e um Cristal de Aurora Boreal íntegros no Pingente apenas com fibra estrutural, mantendo-os expostos e sem alterar seus componentes, o Mestre permite que cada material continue manifestando sua propriedade **intrínseca documentada**, sem transferi-la ao suporte?*

- **SIM — H1, conservador:** cena TEST pode comparar fonte solta e alojada; luz qualitativa da erva tem base textual. Raio de 1m, duração 1turno, 2 usos/dia, PA do item e ação de Contrassombra seguem **propostas não demonstradas**, sem promoção E0/P4/RC5. Teste de escuridão mágica do cristal requer adjudicar condições específicas na cena.
- **NÃO — bloqueio H1 montado:** propriedade após montagem precisa de procedimento adicional. H2 por encantamento permanece dependente de meio e padrão próprios, especialista/energização/selagem, nunca copiados de Vento Ártico/Reflexo.

Um SIM é autorização de *ensaio*, não certificação de dois resultados; um NÃO não invalida as propriedades do material isolado. A decisão solicitada é somente Mestre-side/LAB, não publica nada na Party nem inicia produção oficial.
