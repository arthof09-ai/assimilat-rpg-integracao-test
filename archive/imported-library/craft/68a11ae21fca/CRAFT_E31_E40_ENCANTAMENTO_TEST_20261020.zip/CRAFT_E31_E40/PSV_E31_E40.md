# PSV — CRAFT E31–E40 · Encantamento e alojamento

**Pergunta operacional 1. O que as regras permitem?** Aplicar encantamento a item conforme REC-MOD-ENC-01: substrato, pasta/meio, padrão/geometria, aplicação/energização, selagem e ensaio. REC-MOD-EQA-01 exige que esse processo seja distinto da fabricação do acessório. Duas receitas de referência confirmam a sequência, **nenhuma** é receita do Pingente.

**2. H1 alojamento: funcionou?** A fonte canônica da erva descreve iluminação, e o cristal apresenta potencial de dissipação de escuridão, cada um como material isolado. Teste de suporte H1 pós-montagem: **NOT_OBSERVED**; não há adjudicação de conservação da propriedade depois da fixação. Fibra: estrutural sem magia. Este é resultado de leitura normativa/controle lógico, **não evento de campanha**.

**3. H2 integração por encantamento: funcionou?** **NÃO EXECUTADO**; não se identifica fórmula/padrão ou meio compatíveis especificamente com Luminescência de Vigília e Abertura de Contrassombra. REC-MOD-ENC-01 fornece contrato geral, mas não preenche a receita particular. Copiar os padrões Vento Ártico/Reflexo foi legitimamente recusado por efeito incompatível. Não inventar rolagem de sucesso, especialista nem selagem.

**4. Habilidades:** Luminescência de fonte isolada é propriedade documental qualitativa, sem raio de 1m medido; Luminescência do Pingente = pendente; Contrassombra da fonte = potencial documental com condições ausentes; Contrassombra do Pingente = pendente. 0 ativações em cena/0 resultados mágicos observados.

**5. Energia/Rank:** envelope E21–E30 R39 preservado (RI Prata E3, RE Bronze E3 passiva, RE Prata E3 ativa), consumo **12 PA/dia + 7 PA/uso, 26 PA no cenário de 2 usos**, todos prospectivos. Nada foi debitado; nesta rodada não houve alteração de efeito que justificasse novo preço energético. **Se a rota H1 não criar habilidade no item, reavaliar a interpretação do envelope com o dono PA; não transferir automaticamente o preço de uma habilidade do item para a planta/cristal soltos.** RIn não prova RE.

**6. Material e mágico:** último pedido R48 E27 `SBX-R48-ORDER-48322` permanece intacto, sequência 1 e 2 commits em store TEST, receipt SHA `394132efe12a1f83e7f2fd62dd0dca09a7a3374a4ef080fac25426f8355b8c37`; foi **uma amostra estrutural sintética**. Nesta execução 0 pedidos R48 novos, 0 estoque real, 0 montagem física e 0 ocorrência mágica; H2 não instalada, retenção não demonstrada. RC3(TEST) indicativo; RC4/RC5/P4/produção HOLD.

**7. Primeiro bloqueio/decisão:** Fonte de luz e cristal têm propriedades mas **não foi estabelecida a adjudicação de conservação H1 depois da montagem**. Uma única decisão Mestre TEST, formulada em `MAPA_CANONICO_H1_H2.md`, permite executar o cenário controlado sem confundir H1 com transferência. Se o Mestre exigir H2 antes de qualquer efeito, a lacuna é fórmula de inscrição luz/antiescuridão específica, a ser investigada sem inventar autoridade.

**Trabalhos realmente executados:** oito excertos de Notion Mestre comparados com as páginas vigentes, 13 confrontos de regras/controles efetivamente processados em Python, 20/20 testes da bancada de admissibilidade PASS, readback **somente leitura** do store anterior com sequence=1 e hashes 2/2; não repetidos E21–E30 nem contadas as 100 regressões anteriores. Estes resultados certificam o **instrumento de triagem documental**, não mecanismo de magia física ou in-game.

**Classificação do desfecho E40:** **D — decisão de adjudicação TEST pontual indispensável**, precedida de ensaio documental útil e gate de fonte. NAC-PASS proporcional software e readback, magia HOLD. F5 RED, C19-021 UNKNOWN-EFFECT, nenhum writer/lease/fence, Party/O Primeiro NO-WRITE, sem novos REC-ID nem páginas de item.
