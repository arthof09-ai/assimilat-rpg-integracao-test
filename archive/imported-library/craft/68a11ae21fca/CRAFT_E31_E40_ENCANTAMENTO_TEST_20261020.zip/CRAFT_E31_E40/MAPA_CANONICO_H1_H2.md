# CRAFT E31–E40 — Mapa causal H1/H2 e resultado da prova TEST

**Operação:** OP-ARQ-RIN-REC-01 · **caso ÚNICO:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001` · Pingente v1.3 TEST. **Ambiente:** Mestre-side, F5 RED, C19-021 UNKNOWN-EFFECT, Party/O Primeiro NO-WRITE.

## Resultado com base em autoridade existente

O REC-MOD-EQA-01 é mãe de família (acessório). O REC-MOD-ENC-01 é o contrato de *inscrição* para transferir/instalar um efeito no substrato. Ambos são oficiais. Padrões são magias pré-preparadas: o padrão, a pasta, o conhecimento da fórmula e a ocorrência instalada são objetos diferentes. A existência do procedimento **não autentica** a fórmula específica do Pingente.

| Requisito | H1 — Alojar fontes, sem transferir | H2 — Inscrição no objeto | Fonte/estado atual |
|---|---|---|---|
| Corpo e ergonomia | Fio estrutural de 45 cm, configuração TEST ainda sem medição | O mesmo, mas substrato deve suportar traçado | REC-MOD-EQA; fibra PS, dimensões físicas desconhecidas |
| Fonte de luminosidade | Erva com luz descrita em sua própria ficha | Erva proposta como fonte do padrão | Erva E2/PS, **descrição da fonte** verificada; retenção ao montar NÃO observada |
| Fonte antiescuridão | Cristal com *potencial* de dissipar escuridão | Cristal proposto como fonte ativa | Cristal E2/PS, gatilho/quantidade/intensidade NÃO descritos |
| Ligação física | Fibra liga ou segura componentes | Fibra poderia suportar item, não é pasta/estabilizador mágico por convenção | Fibra é PS estrutural apenas |
| Superfície/área | Fixação e exposição ótica ainda não verificadas | Geometria do padrão requer substrato/área definida | PENDENTE |
| Meio ou pasta | Não exigido se o efeito permanece na **fonte**, mas a conservação precisa de decisão/ensaio | Nenhum meio de inscrição luz/contrassombra identificado na receita v1.3 | PENDENTE H2 |
| Padrão/geometria | Não há inscrição | Padrão específico luz/contrassombra NÃO identificado | PENDENTE H2 |
| Energização | A ativação intrínseca da fonte pode não ser custo de nova habilidade do item | Requer acoplamento energia→padrão→efeito | PA 12/dia+7/uso é **parecer prospectivo do item proposto**, não prova de funcionamento nem de débito |
| Cura/selagem | Ligação física pode deixar as fontes expostas, sem retenção própria demonstrada | Exige procedimento e sua evidência | PENDENTE H2 |
| Ativação, duração e alcance | Descrição de fontes não determina raio 1m, duração 1 turno nem 2 usos/dia | Proposta do Pingente E3; não demonstrada | PENDENTE H1/H2 |
| Retenção | A fonte mantém ou perde propriedade depois da manipulação? | A propriedade persiste no próprio suporte sem a fonte? | **0 observações em cena** |
| Identidade de propriedade | **Pertence à erva e ao cristal** | **Pertence ao Pingente**, se provado | rotas epistemicamente distintas |

## Duas receitas canônicas comparadas

- [Reflexo das Profundezas](https://app.notion.com/p/3edc2b324ede816bac13cb656a31677a): pó/pasta, combinação de reagentes, entoação e símbolo, aplicação em item, efeito oceânico — demonstra *procedimento*, não efeito luz.
- [Vento Ártico](https://app.notion.com/p/3edc2b324ede814591bbe9b1a9eac5f0) e [receita ligada](https://app.notion.com/p/3edc2b324ede819e850de7e272c1032e): cristal/especificação de vento + folhas + óleo de vedação, pasta aplicada, entoação. Versão legada `defc2b32-4ede-8201-a9a0-816b6c413118` diverge: óleo **2x vs 1x**, folhas **8x vs 4x**, e nomes de essência/folhagem diferentes. Não escolher nem misturar versões silenciosamente. Nenhuma das duas fornece o padrão ou os efeitos do Pingente.

## Ensaio mecânico TEST executado (sem inventar cena)

O programa `mecanica_encantamento_test.py` confronta **trechos curtos de oito fontes lidos no Notion**, preservando suas datas e hash dos próprios excertos. Em 13 casos já executados:

- **Fonte isolada / propriedade descrita:** Erva capaz de iluminar (qualitativamente), Cristal capaz de interagir com escuridão sob condições não definidas; não são eventos observados, nem indicam raio/frequência.
- **Controle negativo:** Fibra não tem magia; sem erva nenhuma Luminescência pode ser atribuída à erva; sem cristal nenhuma Contrassombra pode ser atribuída ao cristal.
- **H1 após montagem:** `MOUNTED_RETENTION_NOT_OBSERVED` para ambos os efeitos. Raio 1m = `RADIUS_UNMEASURED`.
- **H2:** `INSCRIPTION_PROCEDURE_INCOMPLETE` por falta de meio/padrão/vínculo/energia/selagem; copiar Vento/Reflexo = rejeitado; todos os campos preenchidos sem resolução competente não instalam magia.
- **PA:** R39/R27/R26 anterior permanece 12 PA/dia e 7 por ativação, 26 em duas; **consultivo e condicionado à identidade das habilidades E3**; não existe débito, nem novo cálculo nesta execução.
- **Antifraude:** `magic_success=true`, `observed_magic=true` ou testemunho local não são aceitos como prova; no código são recusados. 0 eventos em jogo, 0 efeito mágico observado, 0 ordens R48 novas.

Há um resultado mecânico **positivo documental**: a erva possui luminosidade própria segundo sua fonte. **Não é resultado de montagem nem de ativação do Pingente**. A fonte do cristal diz que *pode* dissipar escuridão, sem mecanismo observável definido. Não há rolagem universal para forçar sucesso de encantamento; [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373) proíbe inventar teste universal de conjuração.

## Ensaio RPG pronto após decisão pontual

**Cena TEST proposta, ainda NÃO executada**: local escuro comum com controle da erva intacta; local de escuridão mágica identificada por fonte competente; objetos soltos vs fontes montadas mas expostas; controles sem erva, sem cristal e fibra isolada; depois ação padrão se houver interface válida, PA disponível em ficha TEST (não Party), repetição até duas vezes somente se a regra da habilidade for adjudicada. Fonte da observação e resolução do Mestre exigidas. Não inventar CD, dado, intensidade, dano, tempo ou retenção ausentes.

Resultados a registrar separadamente: luz **da erva isolada**, luz **da erva alojada**, interação **do cristal isolado**, interação **do cristal alojado**, habilidade **própria do suporte**, inscrição **instalada**, e retenção após retirar a fonte. Cada mudança precisa de adjudicação/medição em jogo e evidência. Um software não deve assinar laudo mágico R46/R47 por um resultado injetado.

## Decisão de engenharia D — uma escolha Mestre específica

**Pergunta:** *No laboratório TEST, a fixação não destrutiva de uma Erva da Luz do Norte e um Cristal de Aurora Boreal íntegros, preservados e expostos no Pingente permite que cada componente continue exercendo suas propriedades originais documentadas como **propriedades do próprio componente**, sem conceder ao suporte uma nova magia nem os limites novos de 1m/1 turno?*

- **A — Sim, somente H1 TEST:** ensaio qualificado pode comparar fontes soltas/montadas e procurar perda por cobertura, processamento e estabilidade. Ativação do item, área, duração, custo diário e efeitos adicionais continuam sem homologação; não chamar H1 de H2.
- **B — Não / exigir demonstração específica antes:** nem H1 montado pode ser resolvido positivamente sem um procedimento/observador definido. H2 segue exigindo *padrão e pasta específicos*, sem copiar encantamento alheio.

Nenhuma resposta foi presumida. A decisão é local ao LAB, não publica o Pingente nem torna RC5/P4 vigentes.
