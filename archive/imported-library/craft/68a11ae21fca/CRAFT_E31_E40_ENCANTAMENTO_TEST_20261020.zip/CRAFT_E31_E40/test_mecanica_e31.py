import copy
import json
import unittest
from pathlib import Path
from mecanica_encantamento_test import (CASE,evaluate,scene,sources,previous_store_check)

BASE=Path(__file__).resolve().parent.parent/'CRAFT_E21_E30_R39_R48_NATIVE_TEST_20261020.zip'
class EnchantmentGates(unittest.TestCase):
 def test_01_source_snapshot_integrity(self):
  self.assertEqual(sources()['case_id'],CASE)
 def test_02_source_light_fact_not_event(self):
  x=evaluate({'mode':'source_isolated','materials':['erva'],'material':'erva'})
  self.assertEqual(x['status'],'SOURCE_PROPERTY_DOCUMENTED');self.assertFalse(x['observed_magic']);self.assertIsNone(x['radius_m'])
 def test_03_source_crystal_potential_not_guarantee(self):
  x=evaluate({'mode':'source_isolated','materials':['cristal'],'material':'cristal'})
  self.assertEqual(x['status'],'SOURCE_POTENTIAL_DOCUMENTED');self.assertIsNone(x['activation'])
 def test_04_fiber_never_magical(self):
  self.assertEqual(evaluate({'mode':'source_isolated','materials':['fibra'],'material':'fibra'})['status'],'SOURCE_NO_MAGIC')
 def test_05_without_herb_no_luminescence_inference(self):
  self.assertEqual(evaluate({'mode':'H1','skill':'luminescencia','materials':['fibra','cristal']})['status'],'SOURCE_MISSING')
 def test_06_without_crystal_no_contrassombra_inference(self):
  self.assertEqual(evaluate({'mode':'H1','skill':'contrassombra','materials':['fibra','erva']})['status'],'SOURCE_MISSING')
 def test_07_mounted_herb_is_unobserved(self):
  x=evaluate({'mode':'H1','skill':'luminescencia','materials':['fibra','erva','cristal']});self.assertEqual(x['status'],'MOUNTED_RETENTION_NOT_OBSERVED')
 def test_08_mounted_crystal_is_unobserved(self):
  x=evaluate({'mode':'H1','skill':'contrassombra','materials':['fibra','erva','cristal']});self.assertEqual(x['status'],'MOUNTED_RETENTION_NOT_OBSERVED')
 def test_09_radius_1m_not_canonical(self):
  x=evaluate({'mode':'H1','skill':'luminescencia','materials':['fibra','erva'],'requested_radius_m':1})
  self.assertEqual(x['status'],'RADIUS_UNMEASURED')
 def test_10_inscription_requires_specific_mechanism(self):
  x=evaluate({'mode':'H2','materials':['fibra','erva','cristal'],'substrate':'fibra TEST'})
  self.assertIn('pattern',x['missing']);self.assertIn('compatible_medium',x['missing']);self.assertEqual(x['status'],'INSCRIPTION_PROCEDURE_INCOMPLETE')
 def test_11_vento_arctico_wrong_spell(self):
  x=evaluate({'mode':'H2','materials':['erva','cristal'],'copied_inscription':'vento_artico'})
  self.assertEqual(x['status'],'REJECTED_WRONG_SPELL_PATTERN')
 def test_12_reflexo_wrong_spell(self):
  self.assertEqual(evaluate({'mode':'H2','materials':['erva','cristal'],'copied_inscription':'reflexo_profundezas'})['status'],'REJECTED_WRONG_SPELL_PATTERN')
 def test_13_filled_fields_do_not_install_magic(self):
  x=evaluate({'mode':'H2','substrate':'s','compatible_medium':'x','pattern':'s','source_to_pattern_binding':'v','energization_authority':'e','sealing_evidence':'c','materials':['erva','cristal']})
  self.assertEqual(x['status'],'AUTHORITY_AND_RESULT_NOT_OBSERVED');self.assertFalse(x['observed_magic'])
 def test_14_false_magic_claim_is_rejected(self):
  self.assertEqual(evaluate({'mode':'H1','skill':'luminescencia','materials':['erva'],'observed_magic':True})['status'],'UNTRUSTED_WITNESS_REJECTED')
 def test_15_fake_witness_is_rejected(self):
  self.assertEqual(evaluate({'mode':'H2','materials':['erva'],'witness_role':'GM_SIMULATED'})['status'],'UNTRUSTED_WITNESS_REJECTED')
 def test_16_pa_qualified_but_not_debited(self):
  a={'case_id':CASE,'daily':12,'per_use':7,'two_uses_total':26}
  self.assertEqual(evaluate({'mode':'pa','qualified_envelope':a})['status'],'PA_TEST_CONSULTATION_ONLY')
  a['charge_executed']=True
  self.assertEqual(evaluate({'mode':'pa','qualified_envelope':a})['status'],'REJECTED_UNVERIFIED_CHARGE')
 def test_17_source_excerpt_tamper_detection(self):
  s=sources();s['sources']['erva']['excerpt']='forjado'
  # A próxima leitura do snapshot íntegro continua correta; adulterado não igual hash.
  import hashlib
  self.assertNotEqual(hashlib.sha256(s['sources']['erva']['excerpt'].encode()).hexdigest(),s['sources']['erva']['excerpt_sha256'])
 def test_18_R48_store_historical_readback_no_mutation(self):
  x=previous_store_check(BASE);self.assertEqual(x['historical_store_sequence'],1);self.assertEqual(x['commit_digest_count'],2);self.assertFalse(x['new_transaction_executed'])
 def test_19_scene_denominators_and_sources(self):
  x=scene();self.assertEqual(len(x['cases']),13);self.assertEqual(x['magic_events_observed'],0);self.assertEqual(x['events_in_game'],0)
  self.assertTrue(all(not a['result']['observed_magic'] for a in x['cases']))
 def test_20_no_unknown_material_or_control(self):
  self.assertEqual(evaluate({'mode':'H1','materials':['erva','magic_ink'],'skill':'luminescencia'})['status'],'REJECTED_UNKNOWN_MATERIAL')
  self.assertEqual(evaluate({'mode':'inject_magic'})['status'],'REJECTED_UNKNOWN_CONTROL')

if __name__=='__main__': unittest.main(verbosity=2)
