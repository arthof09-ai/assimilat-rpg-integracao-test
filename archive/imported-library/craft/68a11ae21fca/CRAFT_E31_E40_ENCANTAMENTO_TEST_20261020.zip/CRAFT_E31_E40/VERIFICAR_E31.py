"""Verify local immutable evidence bundle. Pure stdlib; no Notion or production writes."""
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
    assert manifest['schema']=='CRAFT-E31E40-EVIDENCE-MANIFEST-v1'
    for name, expected in manifest['files'].items():
        p=ROOT/name
        assert p.exists() and p.is_file(),name
        assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
    print('PASS E31_E40 MANIFEST',len(manifest['files']),'/',len(manifest['files']))
if __name__=='__main__':main()
