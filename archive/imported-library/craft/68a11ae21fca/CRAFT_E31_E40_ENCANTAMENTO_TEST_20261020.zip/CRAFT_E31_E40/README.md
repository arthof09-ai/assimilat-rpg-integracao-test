# Replay CRAFT E31–E40 / apenas gate mecânico de admissibilidade

**Não contém motor de combate, transferidor de magia nem clone R48.** Exige Python 3.10+ da stdlib, pacote anterior E21–E30 sem alteração:
`CRAFT_E21_E30_R39_R48_NATIVE_TEST_20261020.zip`
SHA256 esperado `d0b113244cf590a9c30be34c5893c332a08a8e15daa3c17aa9be4cf5356104f0`.

Coloque o ZIP baseline E21–E30 **no diretório pai** da pasta extraída (ou use seu caminho explícito para o avaliador). Execute a partir do diretório deste pacote:
```sh
python mecanica_encantamento_test.py /caminho/CRAFT_E21_E30_R39_R48_NATIVE_TEST_20261020.zip
python -m unittest -v test_mecanica_e31.py
```

Os testes não realizam cenas no RPG nem reexecutam pedido consumado R48; verificam regras de admissibilidade e recusas com trechos curtos recuperados de Notion. `ENSAIO_RESULTADOS_E31.json` guarda as 13 saídas. Fonte de evidência: oito excertos exatamente confrontados contra Notion do Mestre nesta execução; hashes pertencem aos trechos curtos, não aos documentos completos. Sem fetch Notion pelo Python.

PROD F5 RED, C19 UNKNOWN, Party/O Primeiro NO WRITE. Pedir apenas a decisão Mestre de H1 que consta do mapa; sem adjudicação não gerar `MAGIC_SUCCESS`.
