# PA R27 — Interface de consulta PA para a bancada CRAFT QMC-05

**MESTRE-SIDE · TEST · não produtivo · não canoniza.**

## Propósito

Este é um **adaptador executável** entre os efeitos estruturados de itens mágicos (formato de consulta CRAFT compatível com os campos documentados do QMC-05) e o motor PA R26 real incluído em `engine_r26/`. A fonte R26 é mantida separada e não foi reimplementada. O código histórico binário QMC-05 **não foi recuperado** nesta sessão; portanto esta ponte **não foi instalada no entrypoint nativo QMC-05**. É um contrato funcional e um passo mensurável de integração, com recibo e regressões.

## Executar a prova ponta a ponta

```bash
python -m unittest -q test_ponte_pa_craft_r27
python ponte_pa_craft_r27.py fixture_craft_acessorio.json > recibo_reproduzido.json
python -m unittest -q engine_r26.test_r26_decisao
```

Para executar a regressão completa R22–R25:

```bash
cd engine_r26/baseline_r25
PYTHONPATH=.:baseline_r22 python -m unittest -q test_r25_qualidade test_integracao_r24 test_motor_conversacional_r24 test_alcance_mestre_r23 test_ponte_pa_r23 baseline_r22.test_rank_guard_r22
```

Python 3.11+; apenas biblioteca padrão. Resultado do exemplo: +2 SAB = 10 PA/dia; passiva Prata = 12 PA/dia; ativa Bronze = 3 PA/dia e 3 PA/uso. Item Ouro piso 21 PA/dia. **Total = 25 PA/dia + 6 PA por duas ativações = 31 PA no dia.**

## Contrato de entrada CRAFT

Arquivo JSON (exemplo: `fixture_craft_acessorio.json`):

- `acao`: **somente `CONSULTAR_PA_TEST`**. Não aceita publicação, fabricação ou escrita.
- `item`, `familia`, `rank_item`, `historico`.
- `bonus`: lista de bônus numéricos literais, distinguindo CA física da mágica, dano por turno do dano por ataque, permanente de condicional.
- `habilidades`: lista de objetos `nome`, `modalidade` (`ATIVA`/`PASSIVA`), `descricao`, `usos_no_dia`, `duracao`, `frequencia`, `condicoes`, `custo_variavel`.
- `pesquisa`: rank proposto pelo Comestre, justificativa, comparadores por URL + descrição mecânica, lacunas, risco SC e confiança avaliada pelo R26.
- `pa_historico`: custos originais de itens existentes, que permanecem intocados.

Resposta: `contrato`, `id_entrada_sha256`, `item`, `habilidades[]` com ranks, confiança, custos individuais, origens, riscos; `custo_pa` com PA/dia, ativações no cenário, total e históricos; `gate`, `pendencias`, `governanca` e rastro textual. `null` significa custo não fechável, nunca zero.

## Instalação nativa pendente

Depois de recuperar os **bytes originais do pacote QMC-05 com SHA autenticado** e checar a identidade competente, o executor CRAFT poderá fazer a chamada, dentro da bancada QMC-05 original, ao adaptador `consultar_ficha_craft()` após a extração estruturada de efeitos. Antes, deve mapear os campos reais do fornecedor para o contrato, e testar ida e volta sem gravar os itens reais. **Não suponha que o entrypoint original tenha método, assinatura ou nome de função que não foi lido do código real.**

Requer gate TEE de que a interface do CRAFT realmente chama o adaptador e de que cada campo, inclusive as lacunas, é preservado; teste nativo, falhas e regressões específicas; leitura Notion readback; NAC-NORM/GNN/GP-NAC e NAC-PASS conforme aplicação. Para produção, esclarecer o estado CRAFT/F5 RED, C19-021 UNKNOWN e writer/lease/fencing. A autonomia do LAB não substitui esses gates.

## FONTES e antiduplicação

- `PR-ECO-01` Atlas: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- `DMG-RANK-01` vigente: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- `CRAFT QMC-05`: https://app.notion.com/p/3fdc2b324ede816b824df4f2feee3b2a
- `OP-ARQ-RIN-REC-01`: https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516
- `LAB CRAFT`: https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00
- `PR-SC-01`: https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1

Não cria nova operação, LAB, ficha ou receita; não assume CM-000002, epoch ou writer; nenhum dado é propagado à Party.
