# RELATÓRIO PA R27 — Integração CRAFT/Notion

## Resultado verificável

- **Ponte TEST executável:** `ponte_pa_craft_r27.py` consome um item estruturado CRAFT, chama o **código R26 real** em `engine_r26`, devolve PA/dia, PA por ativação, ranking fundamentado, confiança, evidências, condições, limites, lacunas e custo histórico segregado.
- **Caso real de integração contratual:** acessório Ouro com +2 SAB, passiva Prata e ativa Bronze; PA/dia **25**, 2 ativações **6**, total diário **31**. Identidade estável SHA256 da entrada.
- **QA:** 22/22 testes novos, 26/26 R26 e 163/163 R22–R25. Testes da ponte incluem faixa de uso, escrita negada, sem retroatividade, input inválido, rank distinto, risco SC-3, ausência de magnitude e confiança sem comparadores.
- **Notion LAB CRAFT:** registro ANTES fisicamente gravado e lido de volta no LAB já existente; a segunda seção DEPOIS registrará o artefato/hash/gates após a reextração.

## Limite material encontrado

O QMC-05 documenta contrato externo ainda não implementado na interface nativa. O ZIP QMC05 histórico foi localizado no inventário de arquivos da Library, porém sua materialização binária autorizada **falhou**. Portanto esta execução não alterou o entrypoint QMC05 original e não consegue provar um roundtrip verdadeiro nesse código. Não inventar essa equivalência. O registro Notion do LAB é documentação durável da ponte TEST; Notion não executa automaticamente o Python anexado.

## GATES (NAC)

- Interoperabilidade por contrato (QMC-05 **compatível**): PASS-TEST.
- Execução limpa / integridade do pacote: verificar em relatório de release.
- Implantação dentro do entrypoint QMC05: HOLD.
- CRAFT/F5 e REC-LIB produtivos: HOLD/RED, C19-021 UNKNOWN, fencing/lease/writer não demonstrados.
- Alteração normativa oficial: não executada; NAC-NORM-01/GNN/GP-NAC/TEE produtivos pendentes.
- PASS local de testes ≠ NAC-PASS-02 terminal para produção.
- Party/O Primeiro: zero escrita. Nenhum PS/P4 físico foi promovido.

## Primeiro próximo passo exato

Recuperar os bytes nativos QMC-05 de sua Library e comprovar o SHA esperado da versão competente; executor CRAFT legítimo mapear campos e inserir uma chamada a `consultar_ficha_craft()` no entrypoint EXISTENTE, depois executar fixtures de ida e volta e casos de falha. Teste dentro do LAB autorizado com readback. Resolver writer/fencing apenas se desejar materializar em REC-LIB/fichas.
