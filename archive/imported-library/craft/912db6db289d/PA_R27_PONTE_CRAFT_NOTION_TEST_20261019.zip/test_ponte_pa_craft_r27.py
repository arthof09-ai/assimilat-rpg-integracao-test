import copy,json,unittest
from pathlib import Path
from ponte_pa_craft_r27 import consultar_ficha_craft,ContractError,SCHEMA_VERSION
HERE=Path(__file__).parent
DATA=json.loads((HERE/'fixture_craft_acessorio.json').read_text())
class TestaPonteR27(unittest.TestCase):
    def make(self,**kw):
        d=copy.deepcopy(DATA);d.update(kw);return d
    def test_ponta_a_ponta_diario(self):
        o=consultar_ficha_craft(self.make());self.assertEqual((o['custo_pa']['pa_por_dia'],o['custo_pa']['pa_ativacoes_no_cenario'],o['custo_pa']['pa_total_no_cenario']),(25,6,31))
    def test_rank_efeito_independente(self):
        o=consultar_ficha_craft(self.make());self.assertEqual([x['rank_efeito_proposto'] for x in o['habilidades']],['Prata','Bronze']);self.assertEqual(o['item']['classificacao_declarada'],'Ouro')
    def test_dupla_tarifa(self):
        o=consultar_ficha_craft(self.make());self.assertEqual([x['pa_por_dia'] for x in o['habilidades']],[12,3]);self.assertEqual(o['habilidades'][1]['pa_por_ativacao'],3);self.assertIsNone(o['habilidades'][0]['pa_por_ativacao'])
    def test_periodo_com_0_ativacoes(self):
        x=self.make();x['habilidades'][1]['usos_no_dia']=0;o=consultar_ficha_craft(x);self.assertEqual(o['custo_pa']['pa_total_no_cenario'],25)
    def test_periodo_com_3_ativacoes(self):
        x=self.make();x['habilidades'][1]['usos_no_dia']=3;o=consultar_ficha_craft(x);self.assertEqual(o['custo_pa']['pa_total_no_cenario'],34)
    def test_no_item_rank(self):
        o=consultar_ficha_craft(self.make(rank_item=None));self.assertIsNone(o['custo_pa']['pa_por_dia']);self.assertIn('PARCIAL',o['gate'])
    def test_historico_intacto(self):
        x=self.make(historico=True,pa_historico={'pa_por_dia':18,'pa_por_ativacao':5});o=consultar_ficha_craft(x)
        self.assertIsNone(o['custo_pa']['pa_por_dia']);self.assertEqual(o['custo_pa']['pa_historico_preservado'],{'pa_por_dia':18,'pa_por_ativacao':5});self.assertFalse(o['governanca']['historico_reprecificado'])
    def test_production_action_denied(self):
        with self.assertRaises(ContractError):consultar_ficha_craft(self.make(acao='PUBLICAR'))
    def test_bad_rank_denied(self):
        with self.assertRaises(ContractError):consultar_ficha_craft(self.make(rank_item='Diamante'))
    def test_bad_use_denied(self):
        x=self.make();x['habilidades'][1]['usos_no_dia']=-1
        with self.assertRaises(ContractError):consultar_ficha_craft(x)
    def test_passive_with_activations_denied(self):
        x=self.make();x['habilidades'][0]['usos_no_dia']=1
        with self.assertRaises(ContractError):consultar_ficha_craft(x)
    def test_duplicate_names_denied(self):
        x=self.make();x['habilidades'][1]['nome']='Passos sem Pegadas'
        with self.assertRaises(ContractError):consultar_ficha_craft(x)
    def test_research_unknown_ability_denied(self):
        x=self.make();x['pesquisa']['Habilidade Fantasma']=x['pesquisa']['Passos sem Pegadas']
        with self.assertRaises(ContractError):consultar_ficha_craft(x)
    def test_missing_mobility_magnitude_no_final_price(self):
        x=self.make();x['habilidades'][1]['descricao']='Ao ativar, recebe impulso de deslocamento por 1 turno.'
        o=consultar_ficha_craft(x);self.assertIsNone(o['custo_pa']['pa_por_dia']);self.assertTrue(any('MOBILIDADE_SEM_MAGNITUDE' in x for x in o['pendencias']))
    def test_control_incomplete_no_price(self):
        x=self.make();x['habilidades'][1]['descricao']='Ao ativar, prende adversários em campo gravitacional.'
        o=consultar_ficha_craft(x);self.assertIsNone(o['custo_pa']['pa_por_dia'])
    def test_high_risk_hold_material(self):
        x=self.make();x['pesquisa']['Impulso Veloz']['risco']='SC-3'
        o=consultar_ficha_craft(x);self.assertIn('ALTO_RISCO',o['gate']);self.assertTrue(o['risco_material']);self.assertEqual(o['governanca']['nac_pass_material'],'HOLD')
    def test_research_low_confidence_display_only(self):
        x=self.make();x['pesquisa']={};o=consultar_ficha_craft(x)
        self.assertIsNone(o['custo_pa']['pa_por_dia']);self.assertIn('PARCIAL',o['gate'])
    def test_deterministic_receipt(self):
        a=consultar_ficha_craft(self.make());b=consultar_ficha_craft(self.make());self.assertEqual(a,b);self.assertEqual(len(a['id_entrada_sha256']),64)
    def test_cross_layer_no_party(self):
        o=consultar_ficha_craft(self.make());self.assertFalse(o['governanca']['party_write']);self.assertIsNone(o['governanca']['epoch']);self.assertEqual(o['contrato'],SCHEMA_VERSION)
    def test_does_not_mutate_input(self):
        x=self.make();y=copy.deepcopy(x);consultar_ficha_craft(x);self.assertEqual(x,y)
    def test_missing_ability_rejected(self):
        x=self.make();x['habilidades'][1]['descricao']=''
        with self.assertRaises(ContractError):consultar_ficha_craft(x)
    def test_noninteger_legacy(self):
        x=self.make(historico=True,pa_historico={'pa_por_dia':'18'})
        with self.assertRaises(ContractError):consultar_ficha_craft(x)

if __name__=='__main__':unittest.main()
