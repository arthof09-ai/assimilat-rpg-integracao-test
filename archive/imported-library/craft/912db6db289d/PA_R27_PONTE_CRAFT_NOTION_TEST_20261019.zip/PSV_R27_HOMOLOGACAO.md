PSV — PA R27 / CRAFT QMC-05 / INTEGRAÇÃO TEST

AS-OF: 19/10/2026, MESTRE-SIDE. ORIGEM: decisão do Mestre, continuação da operação PA associada ao CRAFT `OP-ARQ-RIN-REC-01`. BASELINE: R26 real, imutável, testes 26; R22–R25 regressões 163. OBJETO MATERIAL NOVO: `ponte_pa_craft_r27.py` (contrato CRAFT compatível QMC-05, sem instalar em QMC05 original).

LAST-VERIFIED-UNIT: consulta programática de item Ouro com +2 SAB, passiva Prata, ativa Bronze, duas ativações. Recibo 25 PA/dia + 6 PA ativações = 31 PA no dia. Fonte R26 mantida. CASOS: 22/22 ponte + 26/26 R26 + 163/163 regressão R22–R25, total 211/211 em módulos distintos.

NOTION: LAB CRAFT existente (https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00), intent `PA-R27-CRAFT-INTEROP-20261019-001`; registro ANTES reaberto fisicamente. Registrar DEPOIS/readback após validação final. Documentação física NÃO prova execução automática de Python pelo Notion.

GATES: TEST CONTRATO=PASS; TEST R26=PASS; REGRESSÃO=PASS; **NATIVE ENTRYPOINT QMC05=HOLD** — binário original não recuperável pela ferramenta nesta sessão (Library expõe arquivo, mas materialização negada); **MIE/TEE real=HOLD**; **NAC-NORM/GNN/GP-NAC produtivo=HOLD**, **NAC-PASS terminal produtivo=HOLD**; **CRAFT/F5=RED**, C19-021=UNKNOWN; Party/O Primeiro WRITE=ZERO; REC-LIB WRITE=ZERO; OUTROS ORIGINAIS WRITE=ZERO.

FIRST-PENDING: recuperar o ZIP nativo QMC-05 autenticamente, incorporar o adaptador no entrypoint original via responsável legítimo CRAFT; testar chamada e persistência no Notion dentro de LAB, depois resolução de gates de writer para produção. NÃO REPETIR: R22–R26 matemática/classificação básica, nem criar novo motor/OP/LAB.

DECISÃO MESTRE: 100% de precisão não é requisito para julgamento semicanônico, mas decisão deve ser argumentada, rastreada e revisável. Risco SC-3/4 exige decisão aplicável antes de uso material. Esta entrega NÃO reprecifica itens canônicos anteriores nem publica novos produtos.
