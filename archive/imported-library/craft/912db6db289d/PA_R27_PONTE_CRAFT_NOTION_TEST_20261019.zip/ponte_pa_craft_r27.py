"""PA R27 -> CRAFT QMC-05 compatible, read-only/TEST boundary.

Not an installation inside historic QMC-05. Calls the authentic R26 engine
available via PA_R26_ENGINE_DIR, preserving its sources and evidence gates.
Never writes Notion or live RPG entities, never claims CRAFT writer/epoch.
"""
from __future__ import annotations
import hashlib, json, os, sys, re
from pathlib import Path
from typing import Any

R26_DIR=Path(os.environ.get('PA_R26_ENGINE_DIR',str(Path(__file__).resolve().parent/'engine_r26')))
if not (R26_DIR/'parecer_semicanonico_r26.py').exists():
    raise RuntimeError('PA_R26_ORIGINAL_NOT_PRESENT: do not substitute a fake implementation')
sys.path.insert(0,str(R26_DIR))
from parecer_semicanonico_r26 import avaliar as _r26_avaliar

SCHEMA_VERSION='PA-CRAFT-QMC05-COMPAT-R27/1.0.0-TEST'
RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário')
MODE_MAP={'PASSIVA':'passiva','PASS':'passiva','PASSIVO':'passiva',
          'ATIVA':'ativa','ATV':'ativa','ATIVO':'ativa'}
ALLOWED_FAMILIES=('arma','armadura','acessório','equipamento','artefato','inscrição','consumível','outro')

class ContractError(ValueError):pass


def _str(x,field,maxlen=6000,allow_empty=False):
    if not isinstance(x,str) or (not x.strip() and not allow_empty) or len(x)>maxlen:
        raise ContractError(f'{field}: must be nonempty short text')
    return x.strip()


def _as_item_rank(x):
    if x is None or x=='':return None
    x=_str(x,'classificacao_item')
    if x not in RANKS:raise ContractError('classificacao_item: rank invalid')
    return x


def _normalize_ability(a:dict,idx:int):
    if not isinstance(a,dict):raise ContractError(f'habilidades[{idx}]: not object')
    name=_str(a.get('nome') or a.get('name'),f'habilidades[{idx}].nome',140)
    mode=a.get('modalidade') or a.get('mode') or a.get('tipo')
    if not isinstance(mode,str) or mode.upper() not in MODE_MAP:raise ContractError(f'habilidades[{idx}].modalidade: required ATIVA/PASSIVA')
    body=_str(a.get('descricao') or a.get('efeito') or a.get('effect'),f'habilidades[{idx}].descricao')
    uses=a.get('usos_no_dia',a.get('usos',0))
    if type(uses)!=int or uses<0 or uses>10000:raise ContractError(f'habilidades[{idx}].usos: invalid')
    if mode.upper() in ('PASSIVA','PASS','PASSIVO') and uses:
        raise ContractError(f'habilidades[{idx}]: passive ability has paid activations')
    return {'nome':name,'modalidade':MODE_MAP[mode.upper()], 'descricao':body,
            'usos_no_dia':uses,'duracao':a.get('duracao'),
            'frequencia':a.get('frequencia'),'condicoes':a.get('condicoes'),
            'custo_variavel':a.get('custo_variavel')}


def _input_text(name:str,rank:str|None,bonuses:list,abilities:list):
    lines=[f'Item: {name}']
    if rank:lines.append(f'Rank do item: {rank}')
    if bonuses:lines.append('Bônus: '+'; '.join(bonuses))
    for a in abilities:lines.append(f"Habilidade {a['modalidade']}: {a['nome']}: {a['descricao']}")
    return '\n'.join(lines)


def consultar_ficha_craft(registro:dict)->dict:
    """Return a STRICT decision envelope, preserving unknown prices and historic PA.

    This is an adapter prototype for the existent CRAFT QMC05 interface.
    It does not run QMC05's original entrypoint and cannot commit Notion data.
    """
    if not isinstance(registro,dict):raise ContractError('registro: object required')
    if registro.get('acao','CONSULTAR_PA_TEST')!='CONSULTAR_PA_TEST':
        raise ContractError('PRODUCTION_ACTION_DENIED: query only')
    name=_str(registro.get('item') or registro.get('nome_item'), 'item',160)
    family=_str(registro.get('familia') or registro.get('categoria') or 'outro','familia',100).lower()
    if family not in ALLOWED_FAMILIES:family='outro'
    item_rank=_as_item_rank(registro.get('rank_item',registro.get('classificacao_item')))
    is_legacy=bool(registro.get('historico',False))
    effects=registro.get('habilidades',registro.get('effects',[]))
    if not isinstance(effects,list) or len(effects)>80:raise ContractError('habilidades: list <=80 required')
    abilities=[_normalize_ability(a,i) for i,a in enumerate(effects)]
    names=[a['nome'] for a in abilities]
    if len(set(n.casefold() for n in names))!=len(names):raise ContractError('duplicate ability names: explicit disambiguation required')
    bonuses=registro.get('bonus',registro.get('bonuses',[]))
    if not isinstance(bonuses,list) or not all(isinstance(x,str) and x.strip() and len(x)<500 for x in bonuses):raise ContractError('bonus: list of short strings required')
    research=registro.get('pesquisa',{})
    if not isinstance(research,dict):raise ContractError('pesquisa: object expected')
    extra_research=set(research)-set(names)
    if extra_research:raise ContractError('pesquisa: unknown ability names '+', '.join(sorted(extra_research)))
    original=registro.get('pa_historico',{})
    if original and not isinstance(original,dict):raise ContractError('pa_historico: object expected')
    for v in (original or {}).values():
        if v is not None and (type(v)!=int or v<0):raise ContractError('pa_historico: nonnegative integer or null expected')
    text=_input_text(name,item_rank,bonuses,abilities)
    uses={a['nome']:a['usos_no_dia'] for a in abilities}
    out=_r26_avaliar(text,origem='HISTORICO' if is_legacy else 'NOVO_TEST',usos=uses,pesquisa=research)
    pa=out.get('r26',{}).get('cenario_pa') if not is_legacy else None
    pmap={p['habilidade']:p for p in out.get('r26',{}).get('pareceres',[])}
    projections=[]
    for a in abilities:
        p=pmap.get(a['nome'],{})
        projections.append({'nome':a['nome'],'modalidade':a['modalidade'].upper(),
                'efeito_literal':a['descricao'],
                'rank_efeito_proposto':p.get('rank_efeito_recomendado'),
                'confianca':p.get('confianca','INDETERMINADA'),
                'evidencia':p.get('comparadores',{}),
                'pa_por_dia':p.get('pa_dia_pelo_rank_proposto'),
                'pa_por_ativacao':p.get('pa_uso_pelo_rank_proposto') if a['modalidade']=='ativa' else None,
                'usos_no_dia':a['usos_no_dia'], 'duracao':a['duracao'],'frequencia':a['frequencia'],
                'condicoes':a['condicoes'],'custo_variavel':a['custo_variavel'],
                'risco':p.get('risco','SC-A-AVALIAR'),'estado':p.get('estado','PENDENTE'),
                'lacunas':p.get('lacunas',[])})
    # The R26 estimator is not a proof of full specification. A quantified
    # mobility effect cannot be assigned a closed tariff if its magnitude is
    # omitted, even when its rank proposal and energy arithmetic are available.
    essential=[]
    for a in abilities:
        body=a['descricao'].lower()
        if re.search(r'\b(?:impulso|aumento|bônus|bonus)\b.{0,55}\b(?:deslocamento|movimento|velocidade)\b|\b(?:deslocamento|movimento|velocidade)\b',body):
            if not re.search(r'\+\s*\d+(?:[.,]\d+)?\s*(?:m|metros?)\b|\b\d+(?:[.,]\d+)?\s*(?:m|metros?)\b',body):
                essential.append('MOBILIDADE_SEM_MAGNITUDE:'+a['nome'])
        if re.search(r'\b(?:campo gravitacional|campo de gravidade|prende adversarios|imobiliza criaturas)\b',body):
            if not re.search(r'\b(?:\d+\s*(?:turnos?|rodadas?|segundos?|minutos?)|cd\s*\d+)\b',body):
                essential.append('CONTROLE_SEM_DURACAO_OU_CD:'+a['nome'])
    # Always preserve explicit original separate from prospective prices.
    complete=bool(pa and pa.get('pa_dia') is not None and pa.get('pa_ativacoes') is not None)
    risk_high=any(p['risco'] in ('SC-3','SC-4','SC-3_4_AVALIAR') for p in projections)
    # The consumer cannot accept a fully resolved RI from a mere free-text inference,
    # nor an unsupported rank as if the CRAFT interface had calibrated it.
    # This gates the *consumable contract*, not the Comestre's freedom to propose.
    if item_rank is None:essential.append('RI_NAO_DECLARADO_NA_ENTRADA_CRAFT')
    if abilities and not all(research.get(a['nome'],{}).get('comparadores') for a in abilities):
        essential.append('CLASSIFICACAO_SEM_COMPARADORES_DOCUMENTADOS_NA_ENTRADA_CRAFT')
    complete=complete and not essential
    issues=list(out.get('issues',[]))+essential
    origin='PARECER_R26_TEST_SEMICANONICO' if complete else 'PARECER_PARCIAL_TEST'
    gate='CONSULTA_TEST_COMPLETA_COM_REVISAO_JIT' if complete else 'CONSULTA_TEST_PARCIAL_COM_PENDENCIAS'
    if risk_high:gate='CONSULTA_TEST_ALTO_RISCO_REQUER_AUTORIZACAO_ANTES_DE_USO_MATERIAL'
    if is_legacy:gate='DIAGNOSTICO_HISTORICO_SEM_REPRECIFICACAO'
    # never mix historic values with new computed scenario
    request=json.dumps(registro,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    return {'contrato':SCHEMA_VERSION,'id_entrada_sha256':hashlib.sha256(request.encode()).hexdigest(),
        'ambiente':'MESTRE-SIDE TEST','sistema_origem':'CRAFT_QMC05_CONTRATO_COMPATIVEL_NAO_INSTALADO',
        'item':{'nome':name,'familia':family,'classificacao_declarada':item_rank,'historico':is_legacy},
        'habilidades':projections,'bonus_literais':bonuses,
        'custo_pa':{'pa_por_dia':pa['pa_dia'] if complete else None,
                    'pa_ativacoes_no_cenario':pa['pa_ativacoes'] if complete else None,
                    'pa_total_no_cenario':pa['total_dia'] if complete else None,
                    'piso_item':pa.get('piso_item') if complete else None,
                    'parcela_numerica_pa_dia':pa.get('componentes_numericos_pa_dia') if complete else None,
                    'pa_historico_preservado':original or None,
                    'origem_calculo':origin,'campo_ausente':None},
        'risco_material':risk_high,'gate':gate,'pendencias':issues,
        'parecer_r26':out.get('r26',{}).get('veredito'),
        'governanca':{'semicanonico':'PARECER_TEST_REVOGAVEL; PS FISICO NAO COMPROVADO',
                      'recibo_notional':'NAO_ESCREVE_NOTION_NEM_FICHAS',
                      'craft_f5':'RED_PRODUCAO_HOLD',
                      'writer':None,'lease':None,'epoch':None,'nac_pass_material':'HOLD',
                      'party_write':False,'historico_reprecificado':False},
        'descricao_entrada_engine':text}


def main():
    if len(sys.argv)!=2:raise SystemExit('Use: python ponte_pa_craft_r27.py input.json')
    inp=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    print(json.dumps(consultar_ficha_craft(inp),ensure_ascii=False,indent=2,sort_keys=True))

if __name__=='__main__':main()
