# ERRATA ADITIVA — Braçadeira do Sopro Guardião · v1.0→v1.0-E1

**Data:** 17/10/2026. **Motivo:** observações do Mestre sobre estrelas e omissão de PA/dia após primeira apresentação. **Original preservado integralmente**, SHA-256 `feb618b5d57a7aa0c8da966ccabf799cfaec5240b97cc4770c4b13bd6ce39a00`. ZIP histórico SHA-256 `1e93b64ff4808b166effb3f2bdc92623ee1418216669b9df43a050b55cd9d127`.

1. **Classificação pública:** ler `Bronze`, sem `Bronze 1` no título ou cabeçalho de item. `Bronze 1` no original era parâmetro de avaliação provisória e não uma estrela pública homologada. Avaliação interna FIP/estrela continua sem certificação.
2. **Custos:** `5 PA por ativação` permanece uma proposta autoral para Passo de Sopro; **custo diário de PA = PENDENTE**, a definir após pesquisa empírica e eventual decisão normativa. Não lançar 0 PA/dia. Custos de ativação e de manutenção não se anulam.
3. **Produto:** não afirmar item fabricado por inserir descrição de fabricação e QA; taxa de sucesso e integração mágica não demonstrados. É uma receita PROPOSTA, não RC5 nem REC-ID.
4. **Preço/CTE:** os valores históricos citados de ingredientes não são valor da braçadeira. CTE por unidade, renda e mercado de mesma época não reconciliados.
5. **Adequação da receita:** o aceite narrativo do Mestre não serve de prova material nem autoriza retroativamente uso da Party.
6. **Próxima edição legítima:** substituir o cabeçalho e incorporar `PA/dia: PENDENTE` na ficha de trabalho; só declarar nova versão canônica após gate/autoridade. Originais permanecem preservados.

**Proveniência:** fontes: [Armas](https://app.notion.com/p/3edc2b324ede8140b8a0e645630b8387), [Armaduras](https://app.notion.com/p/3edc2b324ede81a2be45ddf0f8d94814), [Atlas](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab), [IBX-105](https://app.notion.com/p/3fcc2b324ede819cb313dcd80a702574).
