# Requisição científica posterior — custo diário de PA para itens mágicos

**Origem:** decisão do Mestre em 17/10/2026, após observar na Braçadeira do Sopro Guardião a ausência de custo diário. **Sequenciamento:** só iniciar APÓS registro e circular da correção metodológica (IBX-105 readback já feito); esta requisição NÃO contém modelo final nem autoriza troca em itens existentes.

## Perguntas obrigatórias e hipóteses refutáveis
- É obrigatório para todos os itens, inclusive os de carga própria, permanentes, consumíveis e sem portador? Esta é a DIREÇÃO EXPRESSA DO MESTRE; mapear conflito com fontes antigas e operacionalizar exceções justificadas, não presumir que todos já cobram PA/dia.
- O que é “dia” no calendário de jogo? Equipado vs posse vs ativo vs dormindo, muito itens simultâneos, recursos do portador vs núcleo? PENDENTES de regra sistêmica.
- Itens de mesmo rank mas efeitos e passivos diferentes: qual diferença empírica no PA/dia? Atributos puros vs defesas/reduções vs mobilidade vs efeitos múltiplos vs bypass; o rank pode funcionar como covariável, não como calculadora única.
- Como combinar PA/DIA base+passivo+habilidade ativa, custo por uso, número de usos, duração e energia intrínseca, evitando dupla cobrança? Demonstrar em fichas reais.
- Quais itens têm só PA/uso e quais têm só PA/dia, dois custos, ou nenhum registrado? Falta ≠ gratuito.
- O que acontece quando portador não possui PA livre para manter o item? Não inventar exaustão até confrontar Sistema de Magia e regra dos artefatos.

## Extrato unitário do dataset (a ser construído)
`PAGE_UUID;version;as_of;categoria;item_nome;RI_publico;FIP_interna;efeito_primario;atributos;defesas;mobilidade;controle;passivo;ativo;bonus_ativos;cargas;autonomia;PA_dia;PA_ativacao;PA_outro;condicao_uso;ambiguidade;proveniencia;qualidade;grupo_comp;
` 

## Acceptance científico
1. Denominador de itens elegíveis por família com IDs únicos, e subdenominadores explícitos com e sem PA/dia.
2. Extração de fontes com divergências e dados ausentes, sem atribuir zero.
3. Estatística robusta por tipo e rank, sem misturar custos (dia vs ativação), épocas e alterações de ficha.
4. Proposta reproduzível com margens de incerteza e validação fora da amostra/desenho.
5. Ficheiro de exceções/conflitos, homologação normativa com NAC-NORM, teste em itens reais e sem alteração retroativa silenciosa.

**DON'T MIX:** gasto de PA/dia de portador ≠ PA de ativação ≠ energia do núcleo ≠ preço MED.
