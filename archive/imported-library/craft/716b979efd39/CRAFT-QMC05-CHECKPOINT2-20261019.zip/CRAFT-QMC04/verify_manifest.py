#!/usr/bin/env python3
"""Verifica integridade do pacote QMC-04 sem rede/credenciais."""
from __future__ import annotations
import json,hashlib,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
manifest=json.loads((ROOT/'QMC04-MANIFEST-SHA256.json').read_text())
bad=[]
for r in manifest['files']:
 p=ROOT/r['path']
 if not p.is_file():bad.append((r['path'],'missing'));continue
 b=p.read_bytes()
 if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:
  bad.append((r['path'],'sha_or_bytes_mismatch'))
print(json.dumps({'artifact':'QMC-04','files_expected':len(manifest['files']),
                  'files_verified':len(manifest['files'])-len(bad),'errors':bad,
                  'production':'HOLD','new_recipes':0},ensure_ascii=False))
if bad:sys.exit(2)
