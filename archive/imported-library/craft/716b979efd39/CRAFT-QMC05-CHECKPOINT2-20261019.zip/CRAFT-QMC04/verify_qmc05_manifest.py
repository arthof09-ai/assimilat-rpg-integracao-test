from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
m=json.loads((root/'QMC05-CHECKPOINT2-MANIFEST.json').read_text())
errors=[]
for rel,expected in m['files'].items():
 p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:errors.append(rel)
print(f'QMC05 manifest {len(m["files"])-len(errors)}/{len(m["files"])}',errors)
sys.exit(bool(errors))
