"""QMC-05 incremental read-only checks, imported by existing qmc05 (not a new engine).
No PA formula, no official writes. All claims grounded to source literals.
"""
from __future__ import annotations
import re,hashlib,json
from pathlib import Path
import qmc04,qmc05

SCHEMA='CRAFT-EFFECT-STRUCTURED/1.1-TEST'

def effect_records(content:str)->dict:
    old=qmc05.structured_effects(content)
    out=[]
    for e in old['effects']:
        x=dict(e)
        s=x['literal']
        x['source_literal_sha256']=hashlib.sha256(s.encode('utf8')).hexdigest()
        x['target']={'BONUS_DESTREZA':'DESTREZA','BONUS_CA':'CA','PENALIDADE_DESLOCAMENTO':'DESLOCAMENTO','MULTIPLICADOR_VELOCIDADE':'VELOCIDADE','REDUCAO_CARISMA':'CARISMA'}.get(x['type'],'EFEITO_NAO_TIPADO')
        x['polarity']='REDUCAO' if x['type'] in ('PENALIDADE_DESLOCAMENTO','REDUCAO_CARISMA') else ('AUMENTO' if x['magnitude'] is not None else 'NAO_QUANTIFICADA')
        x['activation_documented']=bool(re.search(r'\b(?:ativad[oa]|ativar|acionad[oa]|como rea[cç][ãa]o)\b',s,re.I))
        x['is_automatic_activation']=False
        x['unresolved']=['CUSTO_PA_NAO_DOCUMENTADO','MODALIDADE_NAO_CONFIRMADA']
        if x['duration']=='NAO_DOCUMENTADA':x['unresolved'].append('DURACAO_NAO_DOCUMENTADA')
        out.append(x)
    return {'contract':SCHEMA,'effects':out,'count':len(out),'original_sha256':hashlib.sha256(content.encode('utf8')).hexdigest(),'no_pa_calculation':True}

def energy_gate(provider:dict|None,expected_id:str|None,expected_contract:str|None)->dict:
    """Provider identity/version must be anchored by independent, verified authority, never self-attested."""
    if not provider:return {'state':'PENDENTE_FORNECEDOR','official_result':None}
    if provider.get('kind') in ('MOCK','FIXTURE_SIMULADA','TEST'):
        return {'state':'SIMULACAO_NAO_OFICIAL','official_result':None}
    if not expected_id or not expected_contract:
        return {'state':'IDENTIDADE_E_CONTRATO_NAO_ATESTADOS','official_result':None}
    if provider.get('provider_id')!=expected_id or provider.get('contract_version')!=expected_contract:
        return {'state':'FORNECEDOR_OU_VERSAO_DIVERGENTE','official_result':None}
    return {'state':'ESTRUTURA_COMPATIVEL_SEM_HOMOLOGACAO','official_result':None}

def semantic_revision(delta:dict)->dict:
    x=qmc05.revision_semantics(delta)
    x['mechanical_changes']=sum(bool(d['mechanical_change']) for d in x['deltas'])
    x['editorial_only']=bool(x['deltas']) and all(d['kind'] in ('SOMENTE_EDITORIAL','IDENTIDADE_EDITORIAL') for d in x['deltas'])
    x['requires_requalification']=x['mechanical_changes']>0
    x['notion_physical_attestation']=delta.get('physical_delta') is True and delta.get('evidence_scope','').startswith('Notion LAB')
    return x

def composite_compatibility(a:dict,b:dict,request:str)->dict:
    r=qmc05.multifactor(a,b,request)
    r['physical_documentation']='INDETERMINADO_SEM_PROVA_DE_ENCAIXE'
    r['energy_documentation']='INDETERMINADO_SEM_PA_COMPETENTE'
    r['mechanical_documentation']='INDETERMINADO_SEM_REGRA_DE_INTERACAO'
    r['positive_requires_documented_rule']=True
    r['safe_for_real_equipping']=False
    return r

def degradation_check(original:dict,altered:dict)->dict:
    """Report isolated missing fields; do not reject unrelated documented effects."""
    lost=sorted(k for k in original if k not in altered)
    changed=sorted(k for k in original if k in altered and original[k]!=altered[k])
    return {'missing_fields':lost,'changed_fields':changed,'preserved_fields':sorted(k for k in original if k in altered and original[k]==altered[k]),'partial_analysis_allowed':True,'missing_is_zero':False}

def consult(raw:str,url:str,anchor:dict|None=None)->dict:
    r=qmc05.consult(raw,url,anchor)
    if r.get('status')!='ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO':return r
    parsed=qmc04.qmc03.extract_tool_readback(raw,url)
    r['effect_structured_v11']=effect_records(parsed['source']['content'])
    r['pa_provider_gate']=energy_gate(None,None,None)
    r['requires_authorized_live_media_bytes']=bool(r.get('media'))
    r['no_new_recipes']=True
    return r
