# CRAFT QMC-05 — PSV parcial verificável
AS-OF: 2026-10-18; OP-ARQ-RIN-REC-01; MESTRE-SIDE; PRODUÇÃO HOLD.

## LAST-VERIFIED-UNIT
Recuperação dos ZIP QMC-03 e QMC-04; restauração byte-idêntica de `QMC-03/baseline_tests.log` (3715 bytes; SHA-256 e6f8e3a542381408ccdef176f466eb37fed2f6da8c234b9621c91a26cc601bc3). QMC-04 SHA-256 121708d005e154775c5cb63ac7064449cc22a4b6ca79bba95238943aa330d7a4; QMC-03 SHA-256 e76058eac20d545bfcd1b4749efadf743f11c55e264b22a60b6108f2aa327248.

Nova camada `QMC-04/qmc05.py` sem modificar qmc03.py, qmc04.py ou motores anteriores. Contrato EFFECT-STRUCTURED/1.0-TEST. Execução efetiva com readbacks preservados de Topázio, Aurora e Espelho: 2, 5 e 1 efeitos estruturados respectivamente; sem atribuir custos PA desconhecidos. Novos testes dirigidos 9/9; reexecução nesta sessão de 10+27+28+34=99 regressões unittest aprovadas. Os 127/127 de QMC-04 continuam reconhecidos pela auditoria coordenadora, mas a presente reexecução executou 99 testes dos quatro módulos diretamente, não 127; não confundir denominadores.

## FIRST-PENDING
Q05-02 recuperação de bytes de imagens: ferramenta Notion resolve referências em URLs assinadas, mas não retorna bytes. Nenhuma imagem inspecionada. Sistema competente de PA não encontrado por busca dirigida; contrato candidato e bloqueio de fornecedor falso preservados. Holdout de novas fontes QMC-05 e integração do consultor de versões em leitura atual ainda pendentes. Este é pacote incremental de checkpoint, NÃO homologação final QMC-05.

## DENOMINATORS
Arquivos QMC-03 históricos preservados com log; QMC-04 integral preservada; 3/3 readbacks antigos processados pela camada nova; 9/9 testes novos; 99/99 regressões reexecutadas nesta sessão; 0 imagens inspecionadas; 0 fornecedor PA oficial; 0 novas receitas/BOMs/REC-IDs; 0 modificações oficiais.

## NO-REPEAT / CONFLICTS / UNKNOWN-EFFECT
Nenhuma reimplementação de QMC-01–04; QMC-05 é extensão aditiva. F5 RED, C19-021 UNKNOWN-EFFECT; sem alterar R48, FC36 ou BACKFILL-30.

## AUTHORITY/WRITER / NAC-PASS
Autorização de laboratório apenas; nenhum writer produtivo, lease, epoch ou fencing assumido. NAC-PASS local parcial: PASS para integridade histórica restaurada, testes executados e efeitos textuais; HOLD para imagens, PA, cobertura holdout e homologação QMC-05.

## NEXT-5
1. Recuperar bytes de imagens via canal autorizado que disponibilize binários.
2. Confrontar imagens com texto sem inferir propriedades pela arte.
3. Localizar contrato/versionamento do executor PA e validar troca real.
4. Executar holdout de páginas Mestre inéditas e pares de itens com regras competentes.
5. Reexecutar suíte completa QMC-04 com seu runner de distribuição e registrar handoff final.
