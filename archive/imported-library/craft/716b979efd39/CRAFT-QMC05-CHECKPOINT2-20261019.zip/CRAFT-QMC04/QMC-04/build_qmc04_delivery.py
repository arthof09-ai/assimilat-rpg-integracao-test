#!/usr/bin/env python3
"""QMC04 geração de pareceres e prova de transmissão (NO NEW RECIPES)."""
from __future__ import annotations
import json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import qmc04
INPUTS=[('Topázio de Velocidade','topazio','https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250'),
        ('Acolchoada Aurora','acolchoada','https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a'),
        ('Espelho Verdade Oculta','espelho_holdout','https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f')]
FILES={'topazio':('topazio_readback.txt','topazio_anchor.json'),
       'acolchoada':('acolchoada_readback.txt','acolchoada_anchor.json'),
       'espelho_holdout':('espelho_holdout.txt','espelho_holdout_anchor.json')}
outputs=[]
for name,key,url in INPUTS:
 textfile,anchorfile=FILES[key]
 raw=(ROOT/'input'/textfile).read_text(encoding='utf8').rstrip('\n');anchor=json.loads((ROOT/'input'/anchorfile).read_text())
 r=qmc04.qualified_chat(raw,url,anchor)
 assert r['status']=='ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO',r['status']
 assert r['transfer']['transfer_ok'] is True
 outputs.append(r)
 (ROOT/f'{key}_parecer.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 (ROOT/f'{key}_chat.md').write_text(qmc04.conversational(r)+'\n')
uid='3fdc2b324ede815fa3e3efa3182d4a5e'
lab=ROOT/'replica_laboratorio'
a=json.loads((lab/'anchors.json').read_text())['states']
v=[(lab/f'v{i}_readback.txt').read_text().rstrip('\n') for i in range(3)]
d0=qmc04.compare_lab_revisions(v[0],v[1],uid,a[0],a[1]);d1=qmc04.compare_lab_revisions(v[1],v[2],uid,a[1],a[2])
assert d0['status']=='DELTA_LAB_DOCUMENTAL_CONFERIDO'
assert [x['field'] for x in d1['diff']]==['editorial']
(lab/'delta_v0_v1.json').write_text(json.dumps(d0,ensure_ascii=False,indent=2)+'\n');(lab/'delta_v1_v2.json').write_text(json.dumps(d1,ensure_ascii=False,indent=2)+'\n')
# Compose real queries across inspected items. Read-only compatibility; no invented rule.
a1,a2,a3=outputs
c1=qmc04.compatible_pair(a1,a1,'Podem empilhar dois exemplares idênticos no Anel Dimensional?')
c2=qmc04.compatible_pair(a1,a2,'Podem empilhar juntos no Anel Dimensional?')
c3=qmc04.compatible_pair(a1,a2,'Posso instalar uma matriz mágica da Acolchoada Aurora no Topázio?')
assert [x['status'] for x in (c1,c2,c3)]==['CONDICIONAL','INCOMPATIVEL_VERIFICADO','INDETERMINADO']
(ROOT/'COMPATIBILIDADE-COMPOSTA-EXECUTADA.json').write_text(json.dumps([c1,c2,c3],ensure_ascii=False,indent=2)+'\n')
# Summary for chat, generated from executable outputs, no hand-written outputs disguised as runs.
s='## Consultas QMC-04 realmente executadas\n\n'
for (name,key,url),r in zip(INPUTS,outputs):
 s+=f'### Consulta: “Analise {name}”\n\n'+qmc04.conversational(r)+'\n\n'
s+='## Consultas compostas\n\n'
for i,case in enumerate([c1,c2,c3],1):s+=f'Caso {i}: **{case["status"]}** — {case["reason"]}\n\n'
s+='## Revisão de página TEST no Notion\n\n'
s+='v0→v1: '+', '.join(x['field'] for x in d0['diff'])+'; v1→v2: '+', '.join(x['field'] for x in d1['diff'])+'. Três leituras físicas reais na mesma réplica isolada, nenhuma alteração em ficha oficial.\n'
(ROOT/'DEMO-CONVERSACIONAL-GERADA.md').write_text(s)
results={'operation':'OP-ARQ-RIN-REC-01','build':'QMC-04.0-TEST','source_uuids':[r['identity']['uuid'] for r in outputs],
    'new_items':3,'family_counts':{'ARTEFATO':2,'ARMADURA':1},'original_qmc_03_cases_preserved':18,
    'cumulative_known_uuids':21,'not_total_rpg_corpus':True,
    'lab_revision_state_count':3,'lab_physical_deltas':2,
    'images_referenced':sum(len(r['media']) for r in outputs),'images_inspected':0,
    'PA_provider_real_contract':None,'compatibility_compound':[c1['status'],c2['status'],c3['status']],
    'no_new_recipes':True,'no_bom':True,'production':'HOLD'}
(ROOT/'RESULTADOS-DENOMINADORES.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
