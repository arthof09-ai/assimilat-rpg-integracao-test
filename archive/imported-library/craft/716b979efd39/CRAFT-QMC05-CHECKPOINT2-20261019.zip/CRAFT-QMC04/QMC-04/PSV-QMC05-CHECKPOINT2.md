# PSV QMC-05 — Checkpoint funcional 2 · 19/10/2026

**OPERATION:** OP-ARQ-RIN-REC-01 · **WORKSTREAM:** CM-000002-WS0001 · **MESTRE-SIDE**. INSTANCE-ID, writer produtivo, lease, epoch e fencing não confirmados. Produção HOLD; F5 RED; C19-021 UNKNOWN-EFFECT.

## VERIFIED — baseline e nova capacidade
- SHA QMC-03 original `e76058eac20d545bfcd1b4749efadf743f11c55e264b22a60b6108f2aa327248`; SHA QMC-04 original `121708d005e154775c5cb63ac7064449cc22a4b6ca79bba95238943aa330d7a4`; checkpoint anterior QMC-05 `d978b2b4fa1528974a423c0856248832b6517688248bf1499369d4aad715747b`.
- **48/48 arquivos QMC-03** conferidos byte a byte na cadeia incorporada, incluindo `baseline_tests.log`, 3.715 bytes, SHA `e6f8e3a542381408ccdef176f466eb37fed2f6da8c234b9621c91a26cc601bc3`.
- Regressões reexecutadas em cópia local: **37 QMC-02 + 40 QMC-03 + 50 QMC-04 = 127/127**. Testes QMC-05: 9 originais + **17 novos** = **26/26**. Total **153/153**, sem contabilizar casos adversariais duas vezes.
- Incremento `qmc05_adv.py` estende o consultor existente sem nova fábrica: `EFFECT-STRUCTURED/1.1-TEST` identifica alvos/polaridade, proveniência literal e incertezas; recusa resultados energéticos falsos; classifica revisão mecânica vs editorial; compatibilidade multifatorial permanece parcial quando falta norma; degradação por campo preserva conclusões independentes.
- Consultas de regressão geradas pelo executável para Topázio, Acolchoada e Espelho; **3 fontes anteriores, 0 fontes holdout novas neste checkpoint**. Não alegar demonstração Q05-09 final.
- Comparação real LAB v0→v1 (custo/efeito/título/editorial) e v1→v2 (apenas editorial) via deltas físicos preservados da QMC-04; não houve nova escrita Notion neste checkpoint.

## MEDIA / R-IMG
- Notion retornou referências estáveis para Topázio, Acolchoada e Espelho e o conector forneceu URLs assinadas com expiração. O resultado do conector continha `reference`, `url`, `expiry_time`, **não bytes**. Não houve inspeção visual binária; R-IMG continua **0/5** histórico, não confundir URL com arquivo. É pendência técnica; não bloquear análise textual.

## PA
- Fonte PR-OBJ-01 / R-PA-DIA reaberta: padrão isolado “N PA” ao final de ficha de item sem gatilho explícito é diário; contexto de ativação/golpe/turno prevalece. Sem aplicar inferência ao campo `24 por dia` sem unidade.
- Contexto recuperado do Executor PA: continuidade R10+ READONLY, candidato `QMC-PA-INTERCHANGE`; sem contrato real homologado ou recibo de fornecedor recuperado no runtime QMC-05. Guard `energy_gate` rejeita MOCK, identidade ausente, versão divergente e mantém `official_result=None` mesmo com campos formalmente compatíveis. **0 integrações reais**, 0 cálculo PA.

## DENOMINATORS / BEFORE-AFTER
- Corpus histórico de fichas QMC-04: 21 UUIDs; nenhum novo UUID qualificado neste checkpoint. Módulos: 7/8 demonstrados historicamente; APR canônico aplicado positivo: 0.
- QMC-04: interpretações parcialmente tipadas, comparação de revisões em relatório separado, guard PA candidato.
- QMC-05 checkpoint 2: efeitos com alvo, polaridade, SHA literal, condições e pendências; comparação de deltas ligada a necessidade de requalificação; gate de fornecedor versionado sem alegar oficialidade; degradação por campo.

## CONFLICTS / FIRST-PENDING / NEXT-5
- Sem mídia recuperada; sem atestação criptográfica independente Notion; sem contrato PA homologado; sem novo holdout; sem APR canônico positivo; sem handoff final.
- **NEXT-5:** (1) acesso binário de imagem com SHA real; (2) holdout Notion novo executado sem transcrição; (3) obter contrato/identidade PA com recibo competente; (4) comparar dois itens novos e condições mecânicas por norma; (5) handoff Inbox e NAC-PASS terminal proporcional.

## NAC-PASS
**PASS experimental local** somente para recuperação 48/48, regressões 127/127 e novos testes 26/26. **HOLD** para R-IMG, PA real, holdout independente, APR, fabricação, receitas e produção. **NO-NEW-RECIPES:** 0 novas receitas, BOMs ou REC-IDs; 0 alterações de fichas oficiais, Party ou O Primeiro.
