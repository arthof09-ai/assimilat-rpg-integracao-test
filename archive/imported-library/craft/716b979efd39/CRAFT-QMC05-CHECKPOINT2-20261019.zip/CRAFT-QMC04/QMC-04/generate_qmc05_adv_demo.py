import json
from pathlib import Path
import qmc05_adv
p=Path(__file__).parent
cases={'Topázio de Velocidade':('topazio_readback.txt','topazio_anchor.json','3edc2b324ede81f9b294edf33c354250'),'Acolchoada Aurora':('acolchoada_readback.txt','acolchoada_anchor.json','3edc2b324ede81a9a1cfc83817895e8a'),'Espelho Verdade Oculta':('espelho_holdout.txt','espelho_holdout_anchor.json','3edc2b324ede817188f3deff656edc1f')}
for name,(file,anchor,uuid) in cases.items():
 r=qmc05_adv.consult((p/'input'/file).read_text().rstrip('\n'),uuid,json.loads((p/'input'/anchor).read_text()));(p/('qmc05adv-'+uuid+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))
 print(name,r['status'],r['effect_structured_v11']['count'])
