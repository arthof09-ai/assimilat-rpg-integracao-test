## Consultas QMC-04 realmente executadas

### Consulta: “Analise Topázio de Velocidade”

**Topázio de Velocidade** — ARTEFATO / Sem classificação

**Fonte:** https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250; versão observável 2026-10-03T19:35:15.711Z (não garante atualização de hoje).

**Efeitos documentados:** NAO_CLASSIFICAVEL_SEM_REGRA: Aumenta a agilidade e a velocidade do portador temporariamente.; NAO_CLASSIFICAVEL_SEM_REGRA: Duplica sua velocidade e da +5 de destreza

**PA/dia:** PENDENTE | **PA/ativação:** PENDENTE

**Imagem:** IMAGEM_REFERENCIADA_NAO_INSPECIONADA. **Energia oficial:** sistema PA não integrado.

**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.

### Consulta: “Analise Acolchoada Aurora”

**Acolchoada Aurora** — ARMADURA / Sem classificação

**Fonte:** https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a; versão observável 2026-10-03T13:19:10.151Z (não garante atualização de hoje).

**Efeitos documentados:** NAO_CLASSIFICAVEL_SEM_REGRA: Escudo do Amanhecer: A armadura é capaz de absorver o primeiro golpe de um inimigo ao amanhecer, protegendo a usuária de danos.; NAO_CLASSIFICAVEL_SEM_REGRA: Calor do Sol Nascente: Ela mantém a usuária aquecida em climas frios, emulando o calor suave do sol nascente.; NAO_CLASSIFICAVEL_SEM_REGRA: Renovação Diária: A cada novo amanhecer, a armadura repara pequenos danos sofridos no dia anterior.; NAO_CLASSIFICAVEL_SEM_REGRA: Defesa: +8 CA e -5m de deslocamento

**PA/dia:** PENDENTE | **PA/ativação:** PENDENTE

**Imagem:** IMAGEM_REFERENCIADA_NAO_INSPECIONADA. **Energia oficial:** sistema PA não integrado.

**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.

### Consulta: “Analise Espelho Verdade Oculta”

**Espelho Verdade Oculta** — ARTEFATO / Sem classificação

**Fonte:** https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f; versão observável 2026-10-03T19:35:28.359Z (não garante atualização de hoje).

**Efeitos documentados:** NAO_CLASSIFICAVEL_SEM_REGRA: Quem ficar na frente desse espelho, perde 15 pontos de carisma temporário

**PA/dia:** PENDENTE | **PA/ativação:** PENDENTE

**Imagem:** IMAGEM_REFERENCIADA_NAO_INSPECIONADA. **Energia oficial:** sistema PA não integrado.

**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.

## Consultas compostas

Caso 1: **CONDICIONAL** — A ficha autoriza empilhamento apenas quando exemplares são de fato idênticos e intercambiáveis; estado real de cada ocorrência não está no corpus.

Caso 2: **INCOMPATIVEL_VERIFICADO** — Fonte exige espaço exclusivo por unidade ou conjunto; não compartilhar/empilhar com objeto distinto.

Caso 3: **INDETERMINADO** — Não há contrato mecânico documentado suficiente para o par específico.

## Revisão de página TEST no Notion

v0→v1: title, cost, effect, editorial; v1→v2: editorial. Três leituras físicas reais na mesma réplica isolada, nenhuma alteração em ficha oficial.
