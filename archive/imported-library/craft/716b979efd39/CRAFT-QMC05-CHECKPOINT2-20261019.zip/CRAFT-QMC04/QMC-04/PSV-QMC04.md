# PSV — CRAFT QMC-04 · CONSULTOR CONVERSACIONAL + REVISÕES REAIS EM LAB

**AS-OF:** 17/10/2026 em America/Recife; readbacks LAB entre 01:55 e 01:56 de **18/10/2026 UTC**, ainda 17/10 local. Readbacks das fichas retornaram `as of` de **03/10/2026**. **IDENTIDADE:** CM-000002 por ordem do Mestre; `INSTANCE-ID` não comprovado. **OPERATION:** `OP-ARQ-RIN-REC-01`; **WS:** `CM-000002-WS0001`; **PRODUÇÃO:** HOLD.

## ANTES / BASELINE recuperada

**Baseline autêntica:** arquivo `CRAFT-QMC03-INGESTAO-AUDITAVEL-20261017.zip`, SHA-256 esperado/observado `e76058eac20d545bfcd1b4749efadf743f11c55e264b22a60b6108f2aa327248`. **47/47** entradas do manifesto original conferidas por tamanho e SHA. O código QMC-02/QMC-03 no pacote QMC-04 permanece idêntico ao ZIP original. **QMC-01/QMC-02** preservadas dentro da baseline.

**Regressões executadas:** 37/37 QMC-01/QMC-02 + 40/40 QMC-03. A QMC-03 recebia wrappers integrais de ferramenta, mas ainda não demonstrava pontas de conversa com fontes desconhecidas, revisões físicas divergentes no Notion ou comparador composto de armazenamento com duas fichas.

## DEPOIS / CAPACIDADES EFETIVAMENTE EXECUTADAS

1. **Entrada URL → conector Notion → resposta integral → código → resposta de chat:** aplicada pelo Comestre no próprio ChatGPT a três páginas inéditas de `Itens` Mestre. O código gerou `topazio_chat.md`, `acolchoada_chat.md`, `espelho_holdout_chat.md` após executar o parser; o Mestre não precisou transferir arquivo. **Limite:** o Comestre ainda realiza a ponte cross-tool entre o conector e Python; o Python NÃO possui client/credencial Notion e a ponte não opera sozinha numa sessão externa. Âncoras de sessão de bytes/CRC32 independentes dos arquivos transferidos detectaram corrupção (ex.: `1909/9a8e1560`, `2142/54f79390`, `1846/411649eb`). A âncora não é assinatura criptográfica de origem/frescor.
2. **Interpretador de efeitos genérico:** aceita propriedades verbais sem nome de habilidade, condições, bônus explícitos e restrições de escopo. A Acolchoada tem quatro trechos de efeito. No **Espelho**, a primeira consulta revelou defeito: frase `perde 15 pontos de carisma temporário` ignorada pelo parser. Ajuste geral de linguagem aplicado, mesma fonte reexecutada e novo teste passou. Não foi criada regra de efeito ou custo.
3. **Controle de versões físico na réplica CRAFT:** página `https://app.notion.com/p/3fdc2b324ede815fa3e3efa3182d4a5e` criada APENAS como TEST documental dentro do LAB, sem vínculos com outras fichas. Três readbacks físicos com `as of` distintos, todos com transferências conferidas por CRC. `v0→v1` detectou **4** diferenças (título, custo textual simulado, efeito textual simulado, editorial); `v1→v2` detectou **1** diferença editorial, zero mudanças mecânicas. `v2→v0` foi reconhecida como resposta obsoleta. NÃO atribuir esses custos simulado a um item oficial nem a motor PA. Nenhuma outra página foi escrita.
4. **Compatibilidade composta entre itens Mestre reais:** 3 novas consultas baseadas em literais do Anel Dimensional (Topázio × exemplar do mesmo tipo = CONDICIONAL à fungibilidade; Topázio × Acolchoada = INCOMPATÍVEL para o mesmo espaço, dada exclusividade da armadura; instalação específica sem fonte = INDETERMINADO). As 6 consultas anteriores QMC-03 permanecem. **Não** homologar combinações mecânicas sem documentação.
5. **R-IMG com recusa de falsa inspeção:** 3 referências novas identificadas, somadas às 2 QMC-03; **0/5** arquivos de imagem visualmente examinados. Endereços assinados de mídia foram resolvidos via Notion, mas tentativas de acesso aos bytes não produziram inspeção real nesta sessão. Estado **PENDENTE**, sem inferir material, efeito, cor ou mecanismo pela arte.
6. **Interface PA:** `CRAFT-PA-READONLY-CANDIDATE-04` preserva ITEM-ID, versão observável, família, rank, efeitos, custos explícitos, desconhecidos e evidências; mock e versão contratual indevida são rejeitados. Não foi identificada/recuperada versão validada do contrato externo PA nesta execução. Nenhuma fórmula energética concorrente implementada. `15 PA` ou `24 por dia` históricos não são normalizados sem autoridade.

## CORPUS e DENOMINADORES

- **QMC-04 itens novos:** 3 UUIDs Mestre/3 páginas lidas integralmente; 2 artefatos, 1 armadura. **Acumulado documental conhecido:** 6 QMC-01 + 10 QMC-02 + 2 QMC-03 + 3 QMC-04 = **21 UUIDs**. Não constitui censo do acervo RPG.
- **Módulos especializados com caso demonstrado:** **7/8** preservados; **APR aplicado real 0**. Matrizes QMC-02 continuam em 2 casos históricos, não foram relidas como novas nesta rodada.
- **Testes novos QMC-04:** **50/50**; regressões 37/37 e 40/40; **total distinto 127/127**. Não somar subconjuntos adversariais de QMC-03 como testes extras.
- **Versionamento físico:** 3/3 estados LAB reabertos, 2/2 transições com alteração observável; 1 transição apenas editorial; 0 revisões reais de uma ficha canônica alterada (não é permitido tocar nela).
- **Imagens:** 3/3 referências detectadas nas novas fichas, 0/3 visualmente inspecionadas. Pendências anteriores 0/2; acumulado de cinco imagens 0/5 efetivamente inspecionadas.
- **Compatibilidade composta:** 3/3 consultas estruturadas demonstradas (1 condicional, 1 incompatível, 1 indeterminado); 6 QMC-03 históricas preservadas.
- **Aprimoramento aplicado:** 0 casos positivos: REC-MOD-APR-01, REC-LIN-SUB-01 e duas pílulas relacionadas por título foram confrontados. Mangual do Trovão no espelho Party foi encontrado mas EXCLUÍDO como fonte Mestre válida. Par de produtos ≠ evento de modificação de um exemplar. Corpus investigado é amostra dirigida, não busca exaustiva de todas as fichas.
- **Receitas criadas:** 0; **BOMs autorais:** 0; **REC-IDs:** 0; **itens fabricados:** 0.

## Proveniência / conflitos / confiança

**VERIFICADO:** readbacks Notion efetivamente recebidos em conversa; 3 fontes inéditas transferidas com integridade, 3 revisões físicas LAB e seus deltas; 127/127 testes do arquivo; arquivos hash no pacote; código de respostas geradas pelo executor. 
**RELATADO/NÃO REATESTADO:** quem detém credenciais/motor homologado PA; escopo global das oito famílias fora dos casos lidos; estado atualizado dos itens em 17/10 (readbacks do conector trazem 03/10).
**INFERIDO/CONDICIONAL:** empilhamento físico de exemplares idênticos se satisfizerem condições; conexão energética de Esmeralda com modelo de receptor não demonstrada.
**PENDENTE:** assinatura Notion, atestação externa imune a origem adulterada com hash forjado, edição física real de item canônico (proibida), inspeção visual R-IMG, APR real aplicado, contrato/API PA oficial.
**CONFLITOS:** registros históricos com modalidade de PA ambígua (Adaga `35 de PA`, Lança `24 por dia`), termos divergentes da receita HISTÓRICA Matriz de Cultivo, Sem Classificação dos três itens QMC-04 preservada; nenhum foi reparado mediante inferência.
**UNKNOWN-EFFECT:** C19-021 de histórico R48/F5 preservado; não houve operação sobre esse incidente. A atualização única da réplica TEST foi reaberta e reconciliada em estados sequenciais.

## Governança e passagem

**NO-REPEAT:** R48, FC36, BACKFILL-30 não modificados nem reexecutados sem delta. QMC-01–03 recuperadas e auditadas por manifesto original. Ferramenta aditiva, não outra fábrica.
**AUTHORITY/WRITER:** leitura Notion da fonte Mestre demonstrada; escrita isolada em uma réplica LAB autorizada expressamente por QMC-04, recuperada em readback. Nenhum `writer/lease/epoch/fencing` PROD confirmado; nenhuma escrita Party/O Primeiro/REC-LIB/ficha Mestre ou item inventado.
**NAC-PASS proporcional:** `PASS TEST` para transferência conferível na sessão, código, 3 fontes novas, 3 revisões TEST e regressão. `HOLD` para publicação, produção, receitas, homologação energética, imagens não vistas, integração Notion autônoma assinada e APR canônico.

**LAST-VERIFIED-UNIT:** run de 3 consultas de fichas Mestre até parecer via QMC-04 e 2 diferenças de revisão física no LAB, 127/127 testes limpos.
**FIRST-PENDING:** obter e inspecionar bytes de imagens via serviço autorizado, com recibo R-IMG (0/5); encontrar contrato PA homologado. Canal com assinatura externa da fonte é limitação separada.
**NEXT-5:** 1) canal de mídia Notion com inspeção e SHA; 2) ponte conector→executor sem transcrição assistida e com âncora de sessão estruturada; 3) corpus de arma/matriz/inscrição não utilizada no desenvolvimento em novos testes; 4) evidência de APR item-base→aplicação→estado posterior; 5) contrato PA versionado e validado por executor competente, sem nova fórmula.
**TARGET-REMAINDER:** escopo acervo completo (denominador desconhecido), 8º módulo APR, R-IMG, API PA real, atestado externo, normalização profunda de capacidades especiais e compatibilidades sob regras autorizadas.
**ESTADO DE PRODUÇÃO:** **HOLD**. 
