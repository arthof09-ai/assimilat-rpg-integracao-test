import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import qmc05,qmc04
class TestQMC05(unittest.TestCase):
 def test_topazio(self):
  r=qmc05.structured_effects('Duplica sua velocidade e da +5 de destreza')['effects'];self.assertEqual({x['type'] for x in r},{'MULTIPLICADOR_VELOCIDADE','BONUS_DESTREZA'});self.assertTrue(all(x['pa_daily'] is None for x in r))
 def test_aurora(self):
  r=qmc05.structured_effects('Defesa: +8 CA e -5m de deslocamento\nEscudo: absorve o primeiro golpe ao amanhecer\nCalor: mantém a usuária aquecida\nReparo: repara pequenos danos')['effects'];self.assertEqual(len(r),5)
 def test_espelho(self):
  r=qmc05.structured_effects('Quem ficar na frente desse espelho, perde 15 pontos de carisma temporário')['effects'];self.assertEqual(r[0]['magnitude'],15);self.assertEqual(r[0]['duration'],'TEMPORARIA_SEM_DURACAO')
 def test_editorial(self):
  d=qmc05.revision_semantics({'diff':[{'field':'editorial','before':'a','after':'b'}]});self.assertFalse(d['deltas'][0]['mechanical_change'])
 def test_cost(self):
  d=qmc05.revision_semantics({'diff':[{'field':'cost','before':'7 PA','after':'12 PA'}]});self.assertTrue(d['deltas'][0]['mechanical_change'])
 def test_provider(self):
  self.assertIsNone(qmc05.pa_exchange({}, {'kind':'MOCK'},'1')['official_result'])
 def test_media(self):
  self.assertFalse(qmc05.inspect_media_receipt('ref')['inspected'])
 def test_multifactor(self):
  x={'identity':{'uuid':'a','url':'u','family':'ARTEFATO'}};y={'identity':{'uuid':'b','url':'v','family':'ARTEFATO'}}
  self.assertEqual(qmc05.multifactor(x,y,'compatibilidade')['decision'],'INDETERMINADO')
 def test_negation(self):
  self.assertEqual(qmc05.structured_effects('Não concede +5 de destreza')['effects'],[])
if __name__=='__main__':unittest.main()
