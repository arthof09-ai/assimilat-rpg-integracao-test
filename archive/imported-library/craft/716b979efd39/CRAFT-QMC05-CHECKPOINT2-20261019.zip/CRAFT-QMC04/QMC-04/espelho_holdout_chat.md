**Espelho Verdade Oculta** — ARTEFATO / Sem classificação

**Fonte:** https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f; versão observável 2026-10-03T19:35:28.359Z (não garante atualização de hoje).

**Efeitos documentados:** NAO_CLASSIFICAVEL_SEM_REGRA: Quem ficar na frente desse espelho, perde 15 pontos de carisma temporário

**PA/dia:** PENDENTE | **PA/ativação:** PENDENTE

**Imagem:** IMAGEM_REFERENCIADA_NAO_INSPECIONADA. **Energia oficial:** sistema PA não integrado.

**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.
