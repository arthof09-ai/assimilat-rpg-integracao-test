#!/usr/bin/env python3
"""QMC-05: extensão exclusivamente read-only do consultor QMC-04."""
from __future__ import annotations
import json,re,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import qmc04
VERSION='QMC-05.0-TEST'

def structured_effects(content:str)->dict:
    """Interpretação de fragmentos literais, não arbitragem de regras."""
    results=[]
    for line in qmc04.lines_with_offsets(content):
        s=line['literal']
        if re.search(r'fonte protegida|arquivo hist[oó]rico|referência legada|^\*\*Tipo:',s,re.I):continue
        if re.search(r'\b(?:não|nunca|sem)\s+(?:concede|confere|fornece|aumenta|duplica|dobra|perde)\b',s,re.I):continue
        specs=[
            ('MULTIPLICADOR_VELOCIDADE',r'\b(?:duplica|dobra)\s+(?:sua\s+)?velocidade\b',2,'multiplicador'),
            ('BONUS_DESTREZA',r'\+\s*(\d+)\s*(?:de\s+)?destreza\b',None,'pontos'),
            ('BONUS_CA',r'\+\s*(\d+)\s*CA\b',None,'CA'),
            ('PENALIDADE_DESLOCAMENTO',r'-\s*(\d+)\s*m\s+de\s+deslocamento\b',None,'metros'),
            ('REDUCAO_CARISMA',r'\bperde\s+(\d+)\s+pontos?\s+de\s+carisma\b',None,'pontos'),
        ]
        for typ,pat,constant,unit in specs:
            m=re.search(pat,s,re.I)
            if not m:continue
            cond=[]
            if re.search(r'\bao amanhecer\b|\ba cada novo amanhecer\b',s,re.I):cond.append('AMANHECER_LITERAL')
            if re.search(r'\bquem ficar na frente\b',s,re.I):cond.append('DIANTE_DO_OBJETO_LITERAL')
            results.append({'type':typ,'magnitude':constant if constant is not None else int(m.group(1)),'unit':unit,'literal':s,'condition':cond,'duration':'TEMPORARIA_SEM_DURACAO' if re.search(r'tempor[aá]ri',s,re.I) else 'NAO_DOCUMENTADA','frequency':'NAO_DOCUMENTADA','mode':'NAO_CLASSIFICADA_SEM_FONTE','pa_activation':None,'pa_daily':None,'provenance':'CORPO_TEXTUAL'})
        if re.search(r'\b(?:primeiro golpe|mant[eé]m.+aquecid\w*|repara pequenos danos)',s,re.I):
            typ='ESCUDO_CONDICIONAL' if 'primeiro golpe' in s else ('CONFORTO_TERMICO' if 'aquecid' in s else 'REPARO_CONDICIONAL')
            results.append({'type':typ,'magnitude':None,'unit':None,'literal':s,'condition':['AMANHECER_LITERAL'] if re.search(r'amanhecer',s,re.I) else [],'duration':'NAO_DOCUMENTADA','frequency':'NAO_INFERIR_POR_RODADA_NEM_RECARGA','mode':'NAO_CLASSIFICADA_SEM_FONTE','pa_activation':None,'pa_daily':None,'provenance':'CORPO_TEXTUAL'})
    return {'contract':'EFFECT-STRUCTURED/1.0-TEST','effects':results,'no_external_rules':True,'unknowns_not_zero':True}

def revision_semantics(delta:dict)->dict:
    out=[]
    for d in delta.get('diff',[]):
        field=d['field']
        kind={'cost':'CUSTO_PA_TEST','effect':'EFEITO_TEXTUAL_TEST','editorial':'SOMENTE_EDITORIAL','title':'IDENTIDADE_EDITORIAL'}.get(field,'INDETERMINADO')
        out.append({'kind':kind,'before':d.get('before'),'after':d.get('after'),'mechanical_change':kind in ('CUSTO_PA_TEST','EFEITO_TEXTUAL_TEST'),'scope':'LAB_TEST'})
    return {'source_status':delta.get('status'),'deltas':out,'official_item_change':False}

def multifactor(a:dict,b:dict,request:str)->dict:
    base=qmc04.compatible_pair(a,b,request)
    return {'decision':base['status'],'basis':base,'dimensions':{'documental':base['status'],'fisica':'INDETERMINADA_SEM_OCORRENCIA','energetica':'INDETERMINADA_SEM_CONTRATO_PA','mecanica':'INDETERMINADA_SEM_REGRA_DE_INTERACAO'},'does_not_authorize_equipping':True}

def pa_exchange(payload:dict,provider:dict|None=None,expected_version:str|None=None)->dict:
    if provider is None:return {'status':'FORNECEDOR_COMPETENTE_NAO_RECUPERADO','official_result':None,'payload':payload,'no_calculation':True}
    checked=qmc04.check_provider_reply(provider,expected_version)
    return {'status':checked['status'],'official_result':None,'payload':payload,'no_calculation':True}

def inspect_media_receipt(reference:str,byte_sha256:str|None=None,byte_count:int|None=None,visual_observation:str|None=None)->dict:
    if not byte_sha256 or not byte_count:return {'reference':reference,'status':'REFERENCIADA_SEM_BYTES','inspected':False}
    if not re.fullmatch('[a-f0-9]{64}',byte_sha256):return {'reference':reference,'status':'HASH_INVALIDO','inspected':False}
    return {'reference':reference,'status':'INSPECIONADA' if visual_observation else 'BYTES_RECUPERADOS_NAO_INSPECIONADOS','inspected':bool(visual_observation),'sha256':byte_sha256,'bytes':byte_count,'observation':visual_observation,'mechanics_from_appearance':False}

def consult(raw:str,url:str,anchor:dict|None=None)->dict:
    result=qmc04.qualified_chat(raw,url,anchor)
    if result.get('status')!='ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO':return result
    parsed=qmc04.qmc03.extract_tool_readback(raw,url)
    result['qmc05_version']=VERSION
    result['effect_structured']=structured_effects(parsed['source']['content'])
    result['energy_exchange']=pa_exchange(result['energy'])
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--url',required=True);p.add_argument('--readback',required=True);p.add_argument('--anchor');p.add_argument('--output')
    a=p.parse_args();raw=Path(a.readback).read_text(encoding='utf8').rstrip('\n');anchor=json.loads(Path(a.anchor).read_text()) if a.anchor else None
    data=consult(raw,a.url,anchor);txt=json.dumps(data,ensure_ascii=False,indent=2)
    if a.output:Path(a.output).write_text(txt,encoding='utf8')
    else:print(txt)
