import unittest,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import qmc05_adv as a
D=Path(__file__).parent
class TestQMC05Adv(unittest.TestCase):
 def test_negation(self):self.assertEqual(a.effect_records('Não concede +5 de destreza')['count'],0)
 def test_target(self):
  x=a.effect_records('Duplica sua velocidade e concede +5 de destreza')['effects'];self.assertEqual([e['target'] for e in x],['VELOCIDADE','DESTREZA'])
 def test_penalty(self):self.assertEqual(a.effect_records('Reduz -5m de deslocamento')['effects'][0]['polarity'],'REDUCAO')
 def test_no_automatic_activation(self):self.assertFalse(any(e['is_automatic_activation'] for e in a.effect_records('Ao amanhecer, escudo absorve o primeiro golpe')['effects']))
 def test_provider_missing(self):self.assertEqual(a.energy_gate(None,None,None)['state'],'PENDENTE_FORNECEDOR')
 def test_provider_mock(self):self.assertEqual(a.energy_gate({'kind':'MOCK'},'x','1')['state'],'SIMULACAO_NAO_OFICIAL')
 def test_provider_unverified(self):self.assertEqual(a.energy_gate({'kind':'REAL'},None,None)['state'],'IDENTIDADE_E_CONTRATO_NAO_ATESTADOS')
 def test_provider_wrong(self):self.assertEqual(a.energy_gate({'kind':'REAL','provider_id':'impostor','contract_version':'1'},'official','1')['state'],'FORNECEDOR_OU_VERSAO_DIVERGENTE')
 def test_provider_matching_not_official(self):self.assertIsNone(a.energy_gate({'kind':'REAL','provider_id':'a','contract_version':'1'},'a','1')['official_result'])
 def test_revision_lab_mechanical(self):
  d=json.loads((D/'replica_laboratorio/delta_v0_v1.json').read_text());self.assertTrue(a.semantic_revision(d)['requires_requalification'])
 def test_revision_lab_editorial(self):
  d=json.loads((D/'replica_laboratorio/delta_v1_v2.json').read_text());self.assertTrue(a.semantic_revision(d)['editorial_only'])
 def test_degradation_localized(self):
  r=a.degradation_check({'cost':15,'effect':'protection','rank':'Ouro'},{'effect':'protection','rank':'Ouro'});self.assertEqual(r['missing_fields'],['cost']);self.assertEqual(len(r['preserved_fields']),2)
 def test_degradation_not_zero(self):self.assertFalse(a.degradation_check({'PA':10},{})['missing_is_zero'])
 def test_composite_not_authorize(self):
  x={'identity':{'uuid':'a','url':'u','family':'ARTEFATO'}};y={'identity':{'uuid':'b','url':'v','family':'ARTEFATO'}};self.assertFalse(a.composite_compatibility(x,y,'compatibilidade')['safe_for_real_equipping'])
 def test_end_to_end_topazio(self):
  raw=(D/'input/topazio_readback.txt').read_text().rstrip('\n');anc=json.loads((D/'input/topazio_anchor.json').read_text());r=a.consult(raw,'3edc2b324ede81f9b294edf33c354250',anc);self.assertEqual(r['status'],'ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO');self.assertIn('effect_structured_v11',r)
 def test_end_to_end_aurora(self):
  raw=(D/'input/acolchoada_readback.txt').read_text().rstrip('\n');anc=json.loads((D/'input/acolchoada_anchor.json').read_text());r=a.consult(raw,'3edc2b324ede81a9a1cfc83817895e8a',anc);self.assertEqual(r['status'],'ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO')
 def test_end_to_end_espelho(self):
  raw=(D/'input/espelho_holdout.txt').read_text().rstrip('\n');anc=json.loads((D/'input/espelho_holdout_anchor.json').read_text());r=a.consult(raw,'3edc2b324ede817188f3deff656edc1f',anc);self.assertEqual(r['status'],'ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO')
if __name__=='__main__':unittest.main()
