#!/usr/bin/env python3
"""QMC-04: camada aditiva sobre QMC-03/QMC-02; SEM receitas e SEM mutação Notion.

O Mestre informa URL/UUID no ChatGPT. O Comestre busca via mcp__Notion__fetch,
transporta toda a resposta textual conferível por âncora observada em sessão e
executa este CLI para responder. Não tem token nem cliente Notion embutido.
A âncora de CRC protege contra erro acidental, não é assinatura ou autenticidade.
"""
from __future__ import annotations
import argparse, hashlib, html, json, re, sys, zlib
from datetime import datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'QMC-03'))
import qmc03
VERSION='QMC-04.0-TEST'
CONTRACT='CRAFT-PA-READONLY-CANDIDATE-04'


def crc32(s:str)->str:
    return f'{zlib.crc32(s.encode("utf8")):08x}'


def anchor_verdict(raw:str,anchor:dict|None)->dict:
    if anchor is None:
        return {'state':'SEM_ANCORA_SESSAO','transfer_ok':None,'notion_signature':False}
    if anchor.get('kind')!='CONNECTOR_OBSERVATION' or anchor.get('uuid') is None:
        return {'state':'ANCORA_INVALIDA','transfer_ok':False,'notion_signature':False}
    expected=anchor['uuid']
    if qmc03.qmc02.norm_id(expected) is None:
        return {'state':'ANCORA_UUID_INVALIDO','transfer_ok':False,'notion_signature':False}
    values=[('utf8_bytes',len(raw.encode('utf8'))),('crc32',crc32(raw))]
    bad=[k for k,actual in values if anchor.get(k)!=actual]
    if bad:
        return {'state':'DIVERGENCIA_TRANSFERENCIA','transfer_ok':False,'failed':bad,'notion_signature':False}
    found=qmc03.extract_tool_readback(raw,expected)
    if not found['status'].startswith('READBACK_'):
        return {'state':'DIVERGENCIA_IDENTIDADE','transfer_ok':False,'reason':found['status'],'notion_signature':False}
    if anchor.get('as_of')!=found['source']['observed_at']:
        return {'state':'DIVERGENCIA_ESTADO_OBSERVADO','transfer_ok':False,'notion_signature':False}
    return {'state':'TRANSFERENCIA_LOCAL_CONFERIDA_SE_ANCORA_REALMENTE_FIXADA_NO_CHAT',
            'transfer_ok':True,'notion_signature':False,
            'limitations':'Observação de ferramenta no chat; o CRC/metadata NÃO autenticam criptograficamente o Notion e não provam estado atual.',
            'source_uuid':found['source']['uuid'],'observed_at':found['source']['observed_at']}


def lines_with_offsets(content:str)->list[dict]:
    """Lista só expressões textuais; não transforma aparência em atributo."""
    text=re.sub(r'<br\s*/?>','\n',content,flags=re.I)
    text=qmc03.qmc02.plain(text)
    lines=[];p=0
    for s in text.splitlines():
        v=s.strip()
        if v:lines.append({'literal':v,'offset':p})
        p+=len(s)+1
    return lines


def inspect_generic_effects(content:str)->dict:
    """Extração agnóstica de nomes, fundamentada em trechos literais, com incertezas."""
    skip=re.compile(r'^(?:Tipo|Classifica[çc][ãa]o|Arquivo hist[óo]rico|Refer[êe]ncia legada|Anel Dimensional|Fun[çc][ãa]o, propriedades|Fonte protegida)\b',re.I)
    numeric=re.compile(r'\b(?:\+?\d+\s*(?:CA|RD|RDM|RM|RF|PV|PA)|\d+d\d+|\d+\s*m\b|\d+\s+vez(?:es)?\s+por\s+(?:dia|turno))\b',re.I)
    trigger=re.compile(r'\b(?:[Aa]tiva[çc][ãa]o|[Aa]tivar|[Rr]ea[çc][ãa]o|[Uu]ma vez|[Qq]uando|[Aa]manhecer|[Ee]nquanto|[Pp]rimeiro golpe|[Cc]ada novo)\b',re.I)
    relevant=re.compile(r'\b(?:efeito|habilidade|poder|escudo|defesa|calor|renov|teleport|moviment|deslocament|velocidade|agilidade|destreza|passos|absorv|dissip|congel|regener|resist|matriz|enchant|inscri|vis[ãa]o|estilha|aumenta|duplica|perde|reduz|pontos|carisma|tempor[áa]ri|ganha|concede|causa|cura)\b',re.I)
    items=[]
    for item in lines_with_offsets(content):
        s=item['literal']
        if len(s)<9 or skip.search(s) or re.search(r'preservad[oa]s? da fonte|sem rec[áa]lculo|arquivo hist[óo]rico naveg[áa]vel',s,re.I) or ('[REF:' in s and len(s)<110): continue
        if not (numeric.search(s) or trigger.search(s) or relevant.search(s)): continue
        mode='PASSIVO_EXPLICITO' if re.search(r'\(Pass\)',s,re.I) else ('ATIVO_EXPLICITO' if re.search(r'\(Atv\)',s,re.I) else 'NAO_CLASSIFICAVEL_SEM_REGRA')
        if mode=='NAO_CLASSIFICAVEL_SEM_REGRA' and re.search(r'\b(?:pode(?:m)?\s+(?:usar|liberar)|uma vez por dia|uma vez por turno|a[çc][ãa]o padr[ãa]o|como rea[çc][ãa]o)\b',s,re.I):mode='USO_DESCRITO_SEM_CLASSIFICACAO_ATIVA'
        items.append({'literal':s,'mode':mode,'evidence_source':'CORPO_ORIGINAL','certainty':'TEXTO_VERIFICADO_MODO_PODE_SER_PENDENTE'})
    return {'effects':items,'count':len(items),'policy':'Não inferir efeito mecânico de imagem ou título; modo é explicitado somente quando há marcador competente.'}


def media_index(content:str)->list[dict]:
    media=[]
    for m in re.finditer(r'!\[([^\]]*)\]\(([^)]+)\)',content):
        media.append({'reference':m.group(2),'alt':m.group(1),'kind':'NOTION_STABLE_REFERENCE' if m.group(2).startswith('notion-file-block://') else 'EXTERNAL_IMAGE_URL',
                      'visual_status':'REFERENCIADA_NAO_INSPECIONADA','visual_conclusions':[],
                      'content_sha256':None})
    return media


def visual_receipt(reference:str,sha256_hex:str,visual_notes:list[str],method:str,confirmed:bool=False)->dict:
    """Só marca inspecionada quando bytes e inspeção humana/modelo forem comprovados fora do parser."""
    if not confirmed or not re.fullmatch(r'[a-f0-9]{64}',sha256_hex or '') or not visual_notes or method not in ('container.open_image','VISUAL_INSPECTION_SESSION'):
        return {'status':'R_IMG_PENDENTE','reason':'Faltam bytes SHA256, método e observação visual reais. Link por si não é inspeção.'}
    return {'status':'R_IMG_INSPECIONADA_COM_RECIBO','reference':reference,'sha256':sha256_hex,'notes':visual_notes,'method':method,
            'notion_cryptographic_attestation':False,'automatic_mechanical_inference':False}


def qualified_chat(raw:str, url:str,anchor:dict|None=None,visual:list|None=None)->dict:
    pv=anchor_verdict(raw,anchor)
    if pv['transfer_ok'] is False:
        return {'status':'BLOQUEADO_TRANSPORTE','transfer':pv,'production':'HOLD','new_recipes':0}
    old=qmc03.analyze_fetch(raw,url)
    if old.get('status')!='PARECER_EXPERIMENTAL_DO_READBACK_TRANSPORTADO':
        return {'status':'BLOQUEADO_QUALIFICADOR_EXISTENTE','old_status':old.get('status'),'production':'HOLD','new_recipes':0}
    cap=qmc03.extract_tool_readback(raw,url)
    content=cap['source']['content']
    media=media_index(content)
    validated_visual=[]
    for v in (visual or []):
        if v.get('reference') not in [m['reference'] for m in media]:continue
        validated_visual.append(visual_receipt(v['reference'],v.get('sha256'),v.get('notes',[]),v.get('method',''),v.get('confirmed',False)))
    status='ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO'
    s=old['item']['identity']
    temporal={'source_as_of':cap['source']['observed_at'],'conversation_read_date':'2026-10-17',
        'temporal_state':'ESTADO_OBSERVAVEL_DO_CONECTOR_NAO_FRESCOR_GARANTIDO',
        'revision_id':'NAO_FORNECIDO'}
    return {'status':status,'version':VERSION,'identity':s,'baseline_qmc03':old,
      'transfer':pv,'readback':{'original_sha256':qmc03.sha(raw),'bytes':len(raw.encode('utf8')),'crc32':crc32(raw),
            'source_as_of':cap['source']['observed_at'],'complete_content_sha256':qmc03.sha(content)},
      'temporal':temporal,'additional_effects':inspect_generic_effects(content),
      'media':media,'documented_storage':next((x['literal'] for x in lines_with_offsets(content) if 'Anel Dimensional:' in x['literal']),None),'visual_receipts':validated_visual,'visual_state':'INSPECIONADA_COM_RECIBO' if validated_visual and all(z['status']=='R_IMG_INSPECIONADA_COM_RECIBO' for z in validated_visual) else ('IMAGEM_REFERENCIADA_NAO_INSPECIONADA' if media else 'SEM_IMAGEM_IDENTIFICADA'),
      'energy':pa_interoperability(old),
      'production':'HOLD','new_recipes':0,'new_boms':0,'new_rec_ids':0}


def pa_interoperability(old:dict)->dict:
    inp=old['pa_interface'];item=old['item']
    return {'contract':CONTRACT,'contract_status':'PROPOSTO_READONLY_NAO_NEGOCIADO','provider':None,
       'item_id':item['identity']['uuid'],'version_observed':old['evidence']['observed_at'],
       'family':item['identity']['family'],'rank':item['identity']['rank'],
       'documented_costs':inp['PA_HISTORICO'],'effects':item['effects'],'uncertainties':inp['INCOGNITAS'],
       'provenance':old['evidence']['full_content_sha256'],
       'official_pa_result':None,'no_pa_algorithm':True,'no_activation_authorization':True}


def check_provider_reply(reply:dict,expected_contract_version:str|None=None)->dict:
    if not isinstance(reply,dict) or reply.get('kind') in ('MOCK','FIXTURE_SIMULADA','TEST'):
        return {'status':'NAO_OFICIAL_REJEITADO','authorizes_pa':False}
    if expected_contract_version is None:
        return {'status':'CONTRATO_REAL_AINDA_NAO_CONFERIDO','authorizes_pa':False}
    if reply.get('contract_version')!=expected_contract_version:
        return {'status':'VERSAO_INCOMPATIVEL','authorizes_pa':False}
    return {'status':'DADOS_RECEBIDOS_SEM_HOMOLOGACAO_PA','authorizes_pa':False}


def compare_two_readbacks(raw1:str,raw2:str,uuid:str,physical_revision_verified:bool=False)->dict:
    a=qmc03.extract_tool_readback(raw1,uuid);b=qmc03.extract_tool_readback(raw2,uuid)
    if not a['status'].startswith('READBACK_') or not b['status'].startswith('READBACK_'):
        return {'status':'COMPARACAO_INADMISSIVEL','reason':(a['status'],b['status'])}
    c1,c2=a['source']['content'],b['source']['content']
    if raw1==raw2:return {'status':'MESMA_RESPOSTA_OBSERVADA','physical_revision_verified':False,'delta':[]}
    try:d1=datetime.fromisoformat(a['source']['observed_at'].replace('Z','+00:00'));d2=datetime.fromisoformat(b['source']['observed_at'].replace('Z','+00:00'))
    except ValueError:return {'status':'REVISAO_NAO_COMPARAVEL','physical_revision_verified':False}
    if d2<d1:return {'status':'LEITURA_OBSOLETA','first':a['source']['observed_at'],'second':b['source']['observed_at'],'physical_revision_verified':False}
    changes=[]
    if a['source']['title']!=b['source']['title']:changes.append({'field':'title','before':a['source']['title'],'after':b['source']['title']})
    if c1!=c2:
        for label,pattern in [('costs',r'\b\d+\s*PA\b[^\n]*'),('effect',r'(?im)^(?:\(Pass\)|\(Atv\)|Defesa:|Poderes:)\s*[^\n]+')]:
            old=set(re.findall(pattern,qmc03.qmc02.plain(c1),re.I));new=set(re.findall(pattern,qmc03.qmc02.plain(c2),re.I))
            if old!=new:changes.append({'field':label,'removed':sorted(old-new),'added':sorted(new-old)})
        if not any(x['field'] in ('costs','effect') for x in changes):changes.append({'field':'other_content','before_sha256':qmc03.sha(c1),'after_sha256':qmc03.sha(c2)})
    if not changes:changes.append({'field':'response_wrapper_only','before_sha256':qmc03.sha(raw1),'after_sha256':qmc03.sha(raw2)})
    return {'status':'ALTERACAO_FISICA_CONFIRMADA_SE_VERIFICACAO_EXTERNA' if physical_revision_verified else 'DELTA_ENTRE_DOCUMENTOS_SEM_PROVA_FISICA',
       'physical_revision_verified':physical_revision_verified,'observed_at_first':d1.isoformat(),'observed_at_second':d2.isoformat(),'delta':changes,
       'source_sha256_before':qmc03.sha(c1),'source_sha256_after':qmc03.sha(c2)}


def compatible_pair(source:dict,target:dict,request:str)->dict:
    """Parecer é limitado ao literal compartilhado e módulos; não é um novo contrato normativo."""
    a=source.get('identity',{});b=target.get('identity',{});q=request.casefold()
    urls=[a.get('url'),b.get('url')]
    if not a or not b:return {'status':'INDETERMINADO','reason':'Identidade incompleta','sources':urls}
    if 'anel dimensional' in q or 'empilhar' in q:
        stor_a=source.get('documented_storage') or ''
        stor_b=target.get('documented_storage') or ''
        if a['uuid']!=b['uuid'] and ('espaço exclusivo por unidade' in stor_a or 'espaço exclusivo por unidade' in stor_b):
            return {'status':'INCOMPATIVEL_VERIFICADO','reason':'Fonte exige espaço exclusivo por unidade ou conjunto; não compartilhar/empilhar com objeto distinto.',
                    'sources':urls,'literal_storages':[stor_a,stor_b]}
        if a['uuid']==b['uuid'] and 'idênticas/intercambiáveis' in stor_a:
            return {'status':'CONDICIONAL','reason':'A ficha autoriza empilhamento apenas quando exemplares são de fato idênticos e intercambiáveis; estado real de cada ocorrência não está no corpus.',
                    'sources':urls,'literal_storage':stor_a}
        return {'status':'INDETERMINADO','reason':'Regras de armazenamento dos dois itens não demonstram compartilhamento específico.',
                'sources':urls,'literal_storages':[stor_a,stor_b]}
    if 'item do anel' in q and a['family']=='MATRIZ':
        return {'status':'INCOMPATIVEL_VERIFICADO','reason':'Matriz é instalação por padrão; sem prova de ocorrência objeto físico transportável.',
                'sources':urls+['https://app.notion.com/p/3f1c2b324ede819ca142cbf1eb992fac']}
    if 'alimentar' in q and a['title']=='Esmeralda de Energia' and b['family']=='ARTEFATO':
        return {'status':'CONDICIONAL','reason':'A fonte documenta alimentação genérica de artefatos, não interface com este receptor, capacidade nem consumo.',
                'sources':urls,'missing':['interface de energia do receptor','requisitos de acoplamento','quantidade de carga']}
    if 'inscri' in q and ('INSCRICAO' in a['family'] or 'INSCRICAO' in b['family']):
        return {'status':'INDETERMINADO','reason':'Não foi comprovado suporte/material/instalação específica; não usar categoria para presumir compatibilidade.', 'sources':urls}
    return {'status':'INDETERMINADO','reason':'Não há contrato mecânico documentado suficiente para o par específico.','sources':urls}


def lineage(base:dict,new:dict,applied_source:dict|None=None)->dict:
    a=base.get('identity',{});b=new.get('identity',{})
    if not a or not b:return {'status':'DADOS_INSUFICIENTES','positive':False}
    if a['uuid']==b['uuid']:return {'status':'MESMA_IDENTIDADE_SEM_DELTA_APLICADO','positive':False}
    required=('base_uuid','result_uuid','before','actual_application_event','after','source_url')
    if not applied_source or any(not applied_source.get(k) for k in required):
        return {'status':'APRIMORAMENTO_APLICADO_NAO_COMPROVADO','positive':False,'reason':'Produtos, títulos, upgrades de receita e versões de ficha não demonstram transformação física do objeto.'}
    if applied_source['base_uuid']!=a['uuid'] or applied_source['result_uuid']!=b['uuid']:
        return {'status':'IDENTIDADE_DE_LINHAGEM_INCOMPATIVEL','positive':False}
    return {'status':'RELACAO_DOCUMENTADA_REQUER_READBACK_INDEPENDENTE','positive':False,'reason':'Dados declarados não certificam evento sem fonte original autenticada.'}


def conversational(result:dict)->str:
    if result.get('status')!='ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO':return 'QUALIFICAÇÃO BLOQUEADA: '+result.get('status','desconhecido')
    i=result['identity'];costs=result['baseline_qmc03']['item']['costs'];fx=result['additional_effects']['effects'];lines=[
        f"**{i['title']}** — {i['family']} / {i['rank']}",
        f"**Fonte:** {i['url']}; versão observável {result['readback']['source_as_of']} (não garante atualização de hoje).",
        '**Efeitos documentados:** '+('; '.join((f"{x['mode']}: {x['literal']}") for x in fx[:6]) if fx else 'Nenhum efeito específico demonstrável neste extrato.'),
        '**PA/dia:** '+(', '.join(str(x['value'])+' PA/dia' for x in costs['daily']) if costs['daily'] else 'PENDENTE')+
        ' | **PA/ativação:** '+(', '.join(str(x['value'])+' PA/uso' for x in costs['activation']) if costs['activation'] else 'PENDENTE'),
        '**Imagem:** '+result['visual_state']+'. **Energia oficial:** sistema PA não integrado.',
        '**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.'
    ]
    if costs['ambiguous']:lines.insert(4,'**PA sem modalidade:** '+str([x['evidence'] for x in costs['ambiguous']]))
    if result['transfer']['transfer_ok'] is not True:lines.append('**Transferência:** âncora externa da sessão não disponível; arquivo NÃO atestado.')
    return '\n\n'.join(lines)


LAB_ID='3fbc2b324ede811db848d35d4739eb00'

def extract_lab_replica(raw:str,expected_uuid:str,anchor:dict|None=None)->dict:
    """Consulta de PÁGINA RÉPLICA no LAB, nunca via parser de item canônico.
    O flag de verificação externa é deliberadamente separado da estrutura deste documento.
    """
    u=qmc03.qmc02.norm_id(expected_uuid)
    if not u:return {'status':'REPLICA_UUID_INVALIDO'}
    m=re.search(r'Here is the result of "fetch" for the Page with URL (https://app\.notion\.com/p/([a-f0-9]{32})) as of ([0-9T:.Z+\-]+):',raw)
    t=re.search(r'<properties>\s*(\{[^\n]+\})\s*</properties>',raw)
    content=re.search(r'<content>\n([\s\S]*?)\n</content>\s*</page>',raw)
    if not (m and t and content):return {'status':'REPLICA_WRAPPER_INCOMPLETO'}
    if m.group(2)!=u or f'<page url="{m.group(1)}"' not in raw:
        return {'status':'REPLICA_IDENTIDADE_DIVERGENTE'}
    if not re.search(r'<parent-page url="https://app\.notion\.com/p/'+LAB_ID+r'" title="LABORATÓRIO CRAFT',raw):
        return {'status':'REPLICA_FORA_DO_LABORATORIO_CRAFT'}
    try:title=json.loads(t.group(1))['title']
    except (ValueError,KeyError):return {'status':'REPLICA_TITULO_INVALIDO'}
    evidence=content.group(1)
    fields={}
    for label,regex in [('cost',r'(?m)^Custo textual simulado: (.+)$'),
                        ('effect',r'(?m)^Efeito textual simulado: (.+)$'),
                        ('editorial',r'(?m)^Campo editorial: (.+)$')]:
        f=re.search(regex,evidence)
        fields[label]=f.group(1).strip() if f else None
    verdict={'state':'SEM_ANCORA_LAB','transfer_ok':None}
    if anchor is not None:
        ok=anchor.get('kind')=='CONNECTOR_OBSERVATION' and anchor.get('uuid')==u and anchor.get('utf8_bytes')==len(raw.encode('utf8')) and anchor.get('crc32')==crc32(raw) and anchor.get('as_of')==m.group(3)
        verdict={'state':'CONFERENCIA_LOCAL_LAB' if ok else 'DIVERGENCIA_LAB','transfer_ok':ok,'signature':False}
        if not ok:return {'status':'REPLICA_TRANSPORTE_CORROMPIDO','transport':verdict}
    return {'status':'REPLICA_LAB_READBACK_OBSERVAVEL','uuid':u,'title':title,
      'as_of':m.group(3),'content_sha256':qmc03.sha(evidence),
      'full_response_sha256':qmc03.sha(raw),'fields':fields,
      'transport':verdict,'same_as_item_master':False}


def compare_lab_revisions(raw_before:str,raw_after:str,uid:str,anchor_before:dict|None=None,anchor_after:dict|None=None)->dict:
    a=extract_lab_replica(raw_before,uid,anchor_before);b=extract_lab_replica(raw_after,uid,anchor_after)
    if a['status']!='REPLICA_LAB_READBACK_OBSERVAVEL' or b['status']!='REPLICA_LAB_READBACK_OBSERVAVEL':
        return {'status':'COMPARACAO_LAB_BLOQUEADA','before':a['status'],'after':b['status']}
    if raw_before==raw_after:return {'status':'MESMO_READBACK','physical_delta':False,'diff':[]}
    da=datetime.fromisoformat(a['as_of'].replace('Z','+00:00'))
    db=datetime.fromisoformat(b['as_of'].replace('Z','+00:00'))
    if db<da:return {'status':'LEITURA_LAB_OBSOLETA','physical_delta':False,'readback_before':a['as_of'],'readback_after':b['as_of']}
    diff=[]
    for key in ('title','cost','effect','editorial'):
        first=a['title'] if key=='title' else a['fields'].get(key)
        second=b['title'] if key=='title' else b['fields'].get(key)
        if first!=second:diff.append({'field':key,'before':first,'after':second})
    if not diff and a['content_sha256']!=b['content_sha256']:
        diff.append({'field':'other_content','before_sha256':a['content_sha256'],'after_sha256':b['content_sha256']})
    return {'status':'DELTA_LAB_DOCUMENTAL_CONFERIDO' if diff else 'WRAPPER_ALTERADO_SEM_DELTA_DOCUMENTAL',
       'physical_delta':bool(diff),'same_uuid':True,'readback_before':a['as_of'],'readback_after':b['as_of'],
       'before_sha':a['full_response_sha256'],'after_sha':b['full_response_sha256'],
       'diff':diff,'external_signatures':False,
       'evidence_scope':'Notion LAB experimental. Documento e revisões reais consultados pela ferramenta; itens oficiais intactos.'}

def cli():
    ap=argparse.ArgumentParser(description='CRAFT QMC-04: fonte Notion lida pelo Comestre → texto conversacional')
    ap.add_argument('--url',required=True);ap.add_argument('--tool-response-file',required=True)
    ap.add_argument('--anchor-json');ap.add_argument('--out-json');ap.add_argument('--out-chat')
    args=ap.parse_args();raw=Path(args.tool_response_file).read_text(encoding='utf8').rstrip('\n');anchor=json.loads(Path(args.anchor_json).read_text()) if args.anchor_json else None
    result=qualified_chat(raw,args.url,anchor)
    body=json.dumps(result,ensure_ascii=False,indent=2)
    chat=conversational(result)
    if args.out_json:Path(args.out_json).write_text(body+'\n',encoding='utf8')
    if args.out_chat:Path(args.out_chat).write_text(chat+'\n',encoding='utf8')
    print(chat)
    if result.get('status')!='ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO':raise SystemExit(2)

if __name__=='__main__':cli()
