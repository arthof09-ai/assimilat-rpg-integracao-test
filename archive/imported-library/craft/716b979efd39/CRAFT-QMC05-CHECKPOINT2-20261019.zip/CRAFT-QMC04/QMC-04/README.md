# CRAFT QMC-04 — continuidade aditiva da QMC-03

**Operação:** `OP-ARQ-RIN-REC-01` · **workstream:** `CM-000002-WS0001` · **MESTRE-SIDE** · **produção HOLD** · **novas receitas proibidas**.

## O que realmente funciona

O Mestre pode enviar ao Comestre, **na conversa do ChatGPT no celular**, uma URL/UUID da área Mestre. O Comestre usa a ferramenta autorizada do Notion, transporta **o retorno textual integral** (sem preencher campos à mão), fixa em sessão uma referência verificável da transferência, chama o núcleo existente QMC-03/QMC-02 e devolve a análise textual produzida pelo executável. O usuário não precisa abrir terminal, servidor, script, Base64 ou CSV.

O executável **não chama o Notion diretamente**, não recebe credenciais, não verifica assinatura do Notion e não garante que o `as of` corresponda à data corrente. A transferência entre a ferramenta de conversa e o processo Python é assistida pelo Comestre; a conferência de bytes/CRC32 protege contra erros de transferência, **não** contra um atacante que falsifique corpo e âncora juntos. Se faltar âncora independente, a resposta informa **NÃO ATESTADO**.

## Arquitetura existente preservada

- `QMC-02/qmc02/bancada.py` + `qmc02.py`: núcleo e parser anterior.
- `QMC-03/qmc03.py`: valida wrappers integrais do conector, ancestral Mestre e grounding da interpretação.
- `QMC-04/qmc04.py`: camada aditiva para conversa, interpretação de frases sem nome de habilidade, comparação de revisões em laboratório, mídia, compatibilidade composta e contrato PA somente leitura.
- `QMC-04/build_qmc04_delivery.py`: produz as três respostas a partir dos três retornos Notion reais e as duas diferenças de revisão física. **Não** gera receita/BOM/item.

## Recuperação em ambiente limpo

Na raiz descompactada `CRAFT-QMC04/`:

```bash
python -m unittest discover -s QMC-02/qmc02 -p 'test_*.py' -v
python -m unittest discover -s QMC-03 -p 'test_qmc03.py' -v
python -m unittest discover -s QMC-04 -p 'test_qmc04.py' -v
python QMC-04/build_qmc04_delivery.py
python QMC-04/qmc04.py --url https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f --tool-response-file QMC-04/input/espelho_holdout.txt --anchor-json QMC-04/input/espelho_holdout_anchor.json
python verify_manifest.py
```

**Esperado:** 37 + 40 + 50 = **127** testes distintos. O subconjunto adversarial dos testes antigos não deve ser somado outra vez.

## Evidência de versões físicas reais

Página **TEST** única no LAB CRAFT: https://app.notion.com/p/3fdc2b324ede815fa3e3efa3182d4a5e.

- v0 `2026-10-18T01:55:09.280Z`: custo textual simulado de 7 PA, efeito `brilho curto`, título e editorial iniciais.
- v1 `2026-10-18T01:56:02.780Z`: custo 12 PA, efeito `pulso curto`, título alterado, editorial alterado.
- v2 `2026-10-18T01:56:48.835Z`: **só** alteração editorial.

Três chamadas autorizadas `mcp__Notion__fetch`, três retornos integrais guardados com âncoras de bytes/CRC32 anotadas à parte. Alterações foram restritas à réplica isolada, sem links para fontes externas e sem qualquer escrita em fichas Mestre ou Party.

## Fontes de demonstração inéditas em QMC-04

- [Topázio de Velocidade](https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250): artefato sem classificação, PA não documentado.
- [Acolchoada Aurora](https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a): armadura sem classificação, 4 efeitos/limites literais, PA pendente.
- [Espelho Verdade Oculta](https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f): perda temporária de 15 de Carisma, modalidade não demonstrada, PA pendente. **Holdout revelou bug** de frase sem nome de habilidade; corrigido genericamente, com regressão adicionada.

Os `as of` das fichas são **03/10/2026**. São estados disponibilizados pelo conector em consultas realizadas nesta sessão; **não** prova de edição recente.

## R-IMG e PA

As cinco referências de imagens pertinentes (duas pendentes da QMC-03 e três novas) foram encontradas; foi possível solicitar URLs assinadas da mídia ao conector, porém não obter bytes observáveis nesta execução. **0/5 imagens realmente inspecionadas**; o parecer visual segue PENDENTE. A interface PA (`CRAFT-PA-READONLY-CANDIDATE-04`) é **proposta e testada somente por schema local**, sem endpoint/API real do Comestre competente e sem geração de custos novos. `R-PA-DIA` é respeitada pelo núcleo anterior, exclusivamente em seu escopo competente.

## Não permitido

Nenhuma receita, preliminar, experimental ou derivada; nenhuma BOM autoral, REC-ID, criação/fabricação de item; nenhuma alteração em Party/O Primeiro, no histórico R48/FC36, nas fichas Mestre, na DMG-RANK ou em tabelas oficiais. O LAB de revisão não é uma ficha de item. **F5 RED; C19-021 UNKNOWN-EFFECT; produção HOLD.**
