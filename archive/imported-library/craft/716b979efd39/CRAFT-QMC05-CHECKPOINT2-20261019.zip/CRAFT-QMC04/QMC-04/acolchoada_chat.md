**Acolchoada Aurora** — ARMADURA / Sem classificação

**Fonte:** https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a; versão observável 2026-10-03T13:19:10.151Z (não garante atualização de hoje).

**Efeitos documentados:** NAO_CLASSIFICAVEL_SEM_REGRA: Escudo do Amanhecer: A armadura é capaz de absorver o primeiro golpe de um inimigo ao amanhecer, protegendo a usuária de danos.; NAO_CLASSIFICAVEL_SEM_REGRA: Calor do Sol Nascente: Ela mantém a usuária aquecida em climas frios, emulando o calor suave do sol nascente.; NAO_CLASSIFICAVEL_SEM_REGRA: Renovação Diária: A cada novo amanhecer, a armadura repara pequenos danos sofridos no dia anterior.; NAO_CLASSIFICAVEL_SEM_REGRA: Defesa: +8 CA e -5m de deslocamento

**PA/dia:** PENDENTE | **PA/ativação:** PENDENTE

**Imagem:** IMAGEM_REFERENCIADA_NAO_INSPECIONADA. **Energia oficial:** sistema PA não integrado.

**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.
