"""QMC04: testes do delta, mantendo as 77 regressões de QMC01-QMC03 separadas."""
from __future__ import annotations
import copy, json, pathlib, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import qmc04
T_URL='https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250'
A_URL='https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a'
T=(ROOT/'input/topazio_readback.txt').read_text().rstrip('\n')
A=(ROOT/'input/acolchoada_readback.txt').read_text().rstrip('\n')
TA=json.loads((ROOT/'input/topazio_anchor.json').read_text())
AA=json.loads((ROOT/'input/acolchoada_anchor.json').read_text())

def altered(src,new_title=None,new_cost=None,new_effect=False,asof='2026-10-04T13:19:10.151Z'):
    src=src.replace(' as of 2026-10-03T13:19:10.151Z:', ' as of '+asof+':')
    if new_title:src=src.replace('Acolchoada Aurora',new_title)
    if new_cost:src=src.replace('Defesa: +8 CA e -5m de deslocamento','Defesa: +8 CA e -5m de deslocamento\n'+new_cost)
    if new_effect:src=src.replace('Calor do Sol Nascente:','Voo do Amanhecer:')
    return src

class TestQMC04(unittest.TestCase):
    def test_01_new_item_topazio(self):
        x=qmc04.qualified_chat(T,T_URL,TA);self.assertEqual(x['identity']['family'],'ARTEFATO');self.assertEqual(x['identity']['rank'],'Sem classificação')
    def test_02_second_new_item_armor(self):
        x=qmc04.qualified_chat(A,A_URL,AA);self.assertEqual(x['identity']['family'],'ARMADURA');self.assertEqual(x['identity']['uuid'],'3edc2b324ede81a9a1cfc83817895e8a')
    def test_03_byte_anchor_matches_topazio(self):self.assertTrue(qmc04.anchor_verdict(T,TA)['transfer_ok'])
    def test_04_byte_anchor_matches_armor(self):self.assertTrue(qmc04.anchor_verdict(A,AA)['transfer_ok'])
    def test_05_corrupted_text_rejected(self):self.assertEqual(qmc04.anchor_verdict(T+'S',TA)['state'],'DIVERGENCIA_TRANSFERENCIA')
    def test_06_selfdeclared_hash_is_not_signature(self):self.assertFalse(qmc04.anchor_verdict(T,TA)['notion_signature'])
    def test_07_wrong_uuid_rejected(self):
        b=dict(TA,uuid='3edc2b324ede81a9a1cfc83817895e8a');self.assertEqual(qmc04.anchor_verdict(T,b)['state'],'DIVERGENCIA_IDENTIDADE')
    def test_08_wrong_timestamp_rejected(self):
        b=dict(TA,as_of='2026-10-17T19:00:00Z');self.assertEqual(qmc04.anchor_verdict(T,b)['state'],'DIVERGENCIA_ESTADO_OBSERVADO')
    def test_09_bogus_anchor_rejected(self):self.assertEqual(qmc04.anchor_verdict(T,{'kind':'MOCK'})['state'],'ANCORA_INVALIDA')
    def test_10_missing_anchor_not_cryptographically_verified(self):
        self.assertIsNone(qmc04.anchor_verdict(T,None)['transfer_ok'])
    def test_11_body_content_faithful(self):
        x=qmc04.qualified_chat(A,A_URL,AA)
        self.assertEqual(x['readback']['crc32'],AA['crc32']);self.assertEqual(x['readback']['bytes'],AA['utf8_bytes'])
    def test_12_metadata_not_effect(self):
        x=qmc04.qualified_chat(A,A_URL,AA)
        self.assertFalse(any('preservados da fonte' in e['literal'] for e in x['additional_effects']['effects']))
    def test_13_four_armor_effect_lines(self):
        x=qmc04.qualified_chat(A,A_URL,AA);e=x['additional_effects']['effects']
        for k in ('Escudo do Amanhecer','Calor do Sol Nascente','Renovação Diária','Defesa: +8 CA'):
            self.assertTrue(any(k in v['literal'] for v in e))
    def test_14_topazio_pa_unknown_is_not_zero(self):
        x=qmc04.qualified_chat(T,T_URL,TA);self.assertEqual(x['baseline_qmc03']['item']['costs']['daily'],[])
        self.assertIsNone(x['energy']['official_pa_result'])
    def test_15_visual_index_preserves_reference(self):
        x=qmc04.qualified_chat(T,T_URL,TA);self.assertEqual(len(x['media']),1);self.assertTrue(x['media'][0]['reference'].startswith('notion-file-block://'))
    def test_16_url_alone_does_not_count_visual_inspection(self):
        self.assertEqual(qmc04.visual_receipt('notion-file-block://dummy',None,['looks blue'],'VISUAL_INSPECTION_SESSION')['status'],'R_IMG_PENDENTE')
    def test_17_synthetic_receipt_not_injected(self):
        x=qmc04.qualified_chat(T,T_URL,TA,visual=[{'reference':x if False else 'notion-file-block://fake','sha256':'a'*64,'notes':['blue'],'method':'container.open_image','confirmed':True}]);self.assertEqual(x['visual_receipts'],[])
    def test_18_two_identical_readbacks_not_two_revisions(self):self.assertEqual(qmc04.compare_two_readbacks(A,A,A_URL)['status'],'MESMA_RESPOSTA_OBSERVADA')
    def test_19_different_real_item_not_comparable(self):self.assertEqual(qmc04.compare_two_readbacks(A,T,A_URL)['status'],'COMPARACAO_INADMISSIVEL')
    def test_20_new_document_cost_detected_fixture_only(self):
        y=altered(A,new_cost='50 PA por dia');x=qmc04.compare_two_readbacks(A,y,A_URL)
        self.assertEqual(x['status'],'DELTA_ENTRE_DOCUMENTOS_SEM_PROVA_FISICA');self.assertTrue(any(v['field']=='costs' for v in x['delta']))
    def test_21_title_change_detected_fixture_only(self):
        y=altered(A,new_title='Armadura Aurora Teste');x=qmc04.compare_two_readbacks(A,y,A_URL)
        self.assertTrue(any(v['field']=='title' for v in x['delta']));self.assertFalse(x['physical_revision_verified'])
    def test_22_effect_change_detected_fixture_only(self):
        y=altered(A,new_effect=True);x=qmc04.compare_two_readbacks(A,y,A_URL)
        self.assertTrue(any(v['field'] in ('effect','other_content') for v in x['delta']))
    def test_23_stale_second_readback(self):
        y=altered(A,asof='2026-09-29T13:19:10.151Z');self.assertEqual(qmc04.compare_two_readbacks(A,y,A_URL)['status'],'LEITURA_OBSOLETA')
    def test_24_same_uuid_but_changed_wrapper_no_claim(self):
        y=altered(A);self.assertFalse(qmc04.compare_two_readbacks(A,y,A_URL)['physical_revision_verified'])
    def test_25_mock_energy_rejected(self):self.assertEqual(qmc04.check_provider_reply({'kind':'FIXTURE_SIMULADA'})['status'],'NAO_OFICIAL_REJEITADO')
    def test_26_provider_version_mismatch(self):
        self.assertEqual(qmc04.check_provider_reply({'kind':'PROD','contract_version':'v9'},'v10')['status'],'VERSAO_INCOMPATIVEL')
    def test_27_no_official_energy_contract(self):self.assertEqual(qmc04.check_provider_reply({'kind':'PROD'})['status'],'CONTRATO_REAL_AINDA_NAO_CONFERIDO')
    def test_28_recipe_hard_block(self):
        x=qmc04.qualified_chat(T,T_URL,TA);self.assertEqual(x['new_recipes'],0);self.assertEqual(x['production'],'HOLD')
    def test_29_compound_pair_unknown(self):
        a=qmc04.qualified_chat(T,T_URL,TA);b=qmc04.qualified_chat(A,A_URL,AA)
        self.assertEqual(qmc04.compatible_pair(a,b,'instalar em armadura')['status'],'INDETERMINADO')
    def test_30_lineage_negative(self):
        a=qmc04.qualified_chat(T,T_URL,TA);b=qmc04.qualified_chat(A,A_URL,AA)
        self.assertEqual(qmc04.lineage(a,b)['status'],'APRIMORAMENTO_APLICADO_NAO_COMPROVADO')
    def test_31_lineage_lying_source_rejected(self):
        a=qmc04.qualified_chat(T,T_URL,TA);b=qmc04.qualified_chat(A,A_URL,AA)
        p={'base_uuid':a['identity']['uuid'],'result_uuid':b['identity']['uuid'],'before':'A','actual_application_event':'X','after':'B','source_url':A_URL}
        self.assertFalse(qmc04.lineage(a,b,p)['positive'])
    def test_32_generates_conversation_not_pretyped(self):
        a=qmc04.qualified_chat(T,T_URL,TA);s=qmc04.conversational(a)
        self.assertIn('Topázio de Velocidade',s);self.assertIn(T_URL,s);self.assertIn('PENDENTE',s)
    def test_33_unknown_source_blocked(self):
        x=qmc04.qualified_chat(T,'https://app.notion.com/p/3edc2b324ede81a9a1cfc83817895e8a',None)
        self.assertEqual(x['status'],'BLOQUEADO_QUALIFICADOR_EXISTENTE')
    def test_34_opaque_pa_contract_does_not_calculate(self):
        a=qmc04.qualified_chat(T,T_URL,TA);self.assertTrue(a['energy']['no_pa_algorithm']);self.assertFalse(a['energy']['no_activation_authorization'] is False)

if __name__=='__main__':unittest.main()

class TestRealLabReplica(unittest.TestCase):
    root=ROOT/'replica_laboratorio'
    readings=[(ROOT/'replica_laboratorio'/f'v{i}_readback.txt').read_text().rstrip('\n') for i in range(3)]
    anchors=json.loads((ROOT/'replica_laboratorio'/'anchors.json').read_text())['states']
    uid='3fdc2b324ede815fa3e3efa3182d4a5e'
    def test_35_initial_lab_readback_physical(self):
        x=qmc04.extract_lab_replica(self.readings[0],self.uid,self.anchors[0]);self.assertEqual(x['status'],'REPLICA_LAB_READBACK_OBSERVAVEL');self.assertEqual(x['fields']['cost'],'7 PA por ativação.')
    def test_36_modified_lab_readback_physical(self):
        x=qmc04.extract_lab_replica(self.readings[1],self.uid,self.anchors[1]);self.assertEqual(x['status'],'REPLICA_LAB_READBACK_OBSERVAVEL');self.assertEqual(x['fields']['cost'],'12 PA por ativação.')
    def test_37_final_lab_readback_physical(self):
        x=qmc04.extract_lab_replica(self.readings[2],self.uid,self.anchors[2]);self.assertEqual(x['status'],'REPLICA_LAB_READBACK_OBSERVAVEL');self.assertIn('revisão C',x['fields']['editorial'])
    def test_38_cost_change_detected_physically(self):
        x=qmc04.compare_lab_revisions(*self.readings[:2],self.uid,self.anchors[0],self.anchors[1]);self.assertEqual(x['status'],'DELTA_LAB_DOCUMENTAL_CONFERIDO');self.assertIn('cost',[c['field'] for c in x['diff']])
    def test_39_effect_change_detected_physically(self):
        x=qmc04.compare_lab_revisions(*self.readings[:2],self.uid,self.anchors[0],self.anchors[1]);self.assertIn('effect',[c['field'] for c in x['diff']])
    def test_40_title_change_detected_physically(self):
        x=qmc04.compare_lab_revisions(*self.readings[:2],self.uid,self.anchors[0],self.anchors[1]);self.assertIn('title',[c['field'] for c in x['diff']])
    def test_41_editorial_only_detected_physically(self):
        x=qmc04.compare_lab_revisions(self.readings[1],self.readings[2],self.uid,self.anchors[1],self.anchors[2]);self.assertEqual([c['field'] for c in x['diff']],['editorial'])
    def test_42_stale_readback_rejected(self):
        x=qmc04.compare_lab_revisions(self.readings[2],self.readings[0],self.uid,self.anchors[2],self.anchors[0]);self.assertEqual(x['status'],'LEITURA_LAB_OBSOLETA')
    def test_43_same_readback_zero_delta(self):
        x=qmc04.compare_lab_revisions(self.readings[0],self.readings[0],self.uid,self.anchors[0],self.anchors[0]);self.assertEqual(x['status'],'MESMO_READBACK')
    def test_44_tampered_replica_blocked(self):
        raw=self.readings[1].replace('12 PA','1200 PA');x=qmc04.extract_lab_replica(raw,self.uid,self.anchors[1]);self.assertEqual(x['status'],'REPLICA_TRANSPORTE_CORROMPIDO')
    def test_45_replica_cannot_claim_item_master(self):
        x=qmc04.qmc03.extract_tool_readback(self.readings[1],self.uid);self.assertNotEqual(x['status'],'READBACK_TRANSFERIDO_SEM_ATESTADO_CRIPTOGRAFICO')
    def test_46_different_uuid_blocked(self):
        self.assertEqual(qmc04.extract_lab_replica(self.readings[0],'3edc2b324ede81f9b294edf33c354250')['status'],'REPLICA_IDENTIDADE_DIVERGENTE')
    def test_47_compound_compatibility_conditional(self):
        x=qmc04.qualified_chat(T,T_URL,TA);v=qmc04.compatible_pair(x,x,'Podem empilhar no Anel Dimensional?');self.assertEqual(v['status'],'CONDICIONAL')
    def test_48_compound_compatibility_negative(self):
        x=qmc04.qualified_chat(T,T_URL,TA);y=qmc04.qualified_chat(A,A_URL,AA);v=qmc04.compatible_pair(x,y,'Podem empilhar juntos no Anel Dimensional?');self.assertEqual(v['status'],'INCOMPATIVEL_VERIFICADO')

class TestUnknownHoldout(unittest.TestCase):
    def test_49_unnamed_effect_extracted_after_general_fix(self):
        p=ROOT/'input';raw=(p/'espelho_holdout.txt').read_text().rstrip('\n');a=json.loads((p/'espelho_holdout_anchor.json').read_text())
        r=qmc04.qualified_chat(raw,'https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f',a)
        self.assertEqual(r['status'],'ATENDIDO_PARECER_COM_LIMITE_DE_ATESTACAO')
        self.assertTrue(any('perde 15 pontos de carisma' in e['literal'] for e in r['additional_effects']['effects']))
        self.assertTrue(all(e['mode']=='NAO_CLASSIFICAVEL_SEM_REGRA' for e in r['additional_effects']['effects']))
    def test_50_unnamed_effect_does_not_invent_pa(self):
        p=ROOT/'input';raw=(p/'espelho_holdout.txt').read_text().rstrip('\n');a=json.loads((p/'espelho_holdout_anchor.json').read_text())
        r=qmc04.qualified_chat(raw,'https://app.notion.com/p/3edc2b324ede817188f3deff656edc1f',a)
        self.assertFalse(r['baseline_qmc03']['item']['costs']['daily']);self.assertIsNone(r['energy']['official_pa_result'])
