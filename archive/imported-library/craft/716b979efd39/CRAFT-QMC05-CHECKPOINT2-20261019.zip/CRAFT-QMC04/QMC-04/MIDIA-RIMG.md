# QMC04 — R-IMG / status de mídias da fonte

O conector Notion retornou referência estável de mídia nas 3 fichas novas e nas 2 fichas QMC03 preservadas. `notion_get_file_download_urls` resolveu URLs assinadas do armazenamento para Esmeralda, Lança e Acolchoada. Foi tentado buscar a imagem no runtime, mas a transferência dos bytes não foi concluída: o download requeria URL previamente aberta e a abertura por web não acessou a URL assinada. **Zero bytes de mídia efetivamente inspecionados**; não se produz recibo de inspeção nem qualquer conclusão visual/mecânica.

| Item | ID da fonte | Referência detectada | Visão | Status |
|---|---|---|---|---|
| Esmeralda de Energia | `3edc2b324ede81e28548ef18833a7078` | `notion-file-block://affc2b32-4ede-8246-96fb-015129b02402/...` | 0 | PENDENTE |
| Lança Sopro Congelante | `3edc2b324ede81ecbae3cf4b0cf274e5` | `notion-file-block://119c2b32-4ede-834e-af07-81440138b59e/...` | 0 | PENDENTE |
| Topázio de Velocidade | `3edc2b324ede81f9b294edf33c354250` | `notion-file-block://758c2b32-4ede-8212-ac83-81125460ad88/...` | 0 | PENDENTE |
| Acolchoada Aurora | `3edc2b324ede81a9a1cfc83817895e8a` | `notion-file-block://a07c2b32-4ede-832f-beff-01e3efb3d1ba/...` | 0 | PENDENTE |
| Espelho Verdade Oculta | `3edc2b324ede817188f3deff656edc1f` | `notion-file-block://6a3c2b32-4ede-8287-9ecb-81624fce0097/...` | 0 | PENDENTE |

**R-IMG conforme PR-OBJ-01:** Não é admissível concluir inspeção visual sem visualizar os pixels do próprio arquivo canônico. SHA textual da referência Notion também não prova conteúdo da imagem. Recuperar bytes via canal autorizado, inspecionar as 5 imagens, salvar hash e veredito especificamente visual, sem inferir efeitos pela ilustração.
