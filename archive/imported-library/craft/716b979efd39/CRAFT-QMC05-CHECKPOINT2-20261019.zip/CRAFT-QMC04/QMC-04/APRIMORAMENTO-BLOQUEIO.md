# QMC-04 — APR / bloqueio documental honesto

**0 casos positivos de aprimoramento aplicado identificados na amostra dirigida.**

Fontes usadas no julgamento:
- `REC-MOD-APR-01`: https://app.notion.com/p/3f1c2b324ede81958b48da97806423f3
- `REC-LIN-SUB-01`: https://app.notion.com/p/3f1c2b324ede818a9e84cfeae2aa0b9b
- `Pílula de Melhoria`: https://app.notion.com/p/3edc2b324ede81dabab7d062c302f51b
- `Pílula de Melhoria Aprimorada`: https://app.notion.com/p/3edc2b324ede81e59a61d9b0fae8546d
- `Mangual do Trovão`: página localizada em Party (Mestre — Espelho), e portanto **rejeitada como evidência canônica independente Mestre para este exercício**, sem exportar dados Party a jogadores.

Duas pílulas distintas, mesmo com título parecido, não estabelecem um evento físico de modificação de um exemplar. Uma edição de página não é atualização do item, e um upgrade de receita não é aprimoramento aplicado. A função `lineage()` exige identidades base/resultante, before, evento físico, after e fonte autenticável; na ausência retorna `APRIMORAMENTO_APLICADO_NAO_COMPROVADO`. Dados declarados isoladamente não aprovam resultado. Nenhum item-base foi alterado ou fabricado.

**Denominador da busca dirigida nesta execução:** 2 módulos normativos + 2 páginas de produtos Mestre + 1 página de espelho Party excluída. **0/2 pares positivos demonstráveis**; a estatística não corresponde à totalidade dos casos possíveis no RPG.
