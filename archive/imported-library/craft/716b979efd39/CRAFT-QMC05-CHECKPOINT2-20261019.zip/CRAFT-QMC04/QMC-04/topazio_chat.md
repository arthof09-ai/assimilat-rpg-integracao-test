**Topázio de Velocidade** — ARTEFATO / Sem classificação

**Fonte:** https://app.notion.com/p/3edc2b324ede81f9b294edf33c354250; versão observável 2026-10-03T19:35:15.711Z (não garante atualização de hoje).

**Efeitos documentados:** NAO_CLASSIFICAVEL_SEM_REGRA: Aumenta a agilidade e a velocidade do portador temporariamente.; NAO_CLASSIFICAVEL_SEM_REGRA: Duplica sua velocidade e da +5 de destreza

**PA/dia:** PENDENTE | **PA/ativação:** PENDENTE

**Imagem:** IMAGEM_REFERENCIADA_NAO_INSPECIONADA. **Energia oficial:** sistema PA não integrado.

**Veredito:** qualificação documental experimental; criação de receitas e produção HOLD.
