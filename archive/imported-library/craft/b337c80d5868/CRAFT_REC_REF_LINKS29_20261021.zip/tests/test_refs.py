import unittest,sys,copy
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from refcheck import source,classify,classify_request,SOMBRAS,CULTIVO,RESOLVED,UNRESOLVED
ROWS=source();P=classify(ROWS)
class TestRef(unittest.TestCase):
 def test_summary(self):self.assertEqual(P['denominator'],{'child_recipe_pages':29,'pages_with_mention_tags':2,'pages_without_mention_tags':27,'total_mention_targets':2,'targets_fetch_ok':1,'targets_not_found':1})
 def test_real_target(self):self.assertEqual(P['resolved']['target_page_id'],RESOLVED)
 def test_unresolved_not_assumed(self):self.assertEqual(P['unresolved']['target_actual_identity'],'UNKNOWN')
 def test_no_promote_by_text(self):self.assertFalse(P['unresolved']['auto_relabel_oil_allowed'])
 def test_no_global_nonexistence(self):self.assertIn('NOT_FOUND',P['unresolved']['fetch_result'])
 def test_quantity_still_ex(self):self.assertEqual(P['other_pending']['malformed_quantity'],'Ex Pó de Quartzo Fantasma')
 def test_mirror_does_not_authorize(self):self.assertFalse(P['other_pending']['quantity_corrected'])
 def test_claim_does_not_replace_fetch(self):self.assertEqual(classify_request(P,{'url':'https://fake/','claimed':'oil'}),'HOLD_MESTRE_SOURCE_OWNER_RECONCILIATION')
 def test_no_party(self):self.assertEqual(P['gate']['party_writes'],0)
 def test_no_recipe_mutation(self):self.assertFalse(P['gate']['recipe_edited'])
 def test_no_new_rc5(self):self.assertFalse(P['gate']['official_rec_id_created'])
 def test_bad_source(self):self.assertEqual(classify([])['status'],'INVALID_SOURCE_29_DENOMINATOR')
 def test_duplicate_source(self):
  r=copy.deepcopy(ROWS);r[1]['recipe_page_id']=r[0]['recipe_page_id'];self.assertEqual(classify(r)['status'],'INVALID_SOURCE_IDS')
 def test_two_ids_distinct(self):self.assertNotEqual(SOMBRAS,CULTIVO)
class TestPerRecipe(unittest.TestCase):pass
for i,r in enumerate(P['records']):
 def test(self,r=r):
  self.assertFalse(r['physical_stock_inferred'])
  self.assertEqual(len(r['mention_target_statuses']),r['notion_mention_count'])
  self.assertEqual(len(r['mention_target_ids']),r['notion_mention_count'])
 setattr(TestPerRecipe,'test_read_%02d'%i,test)
