"""Read-only Notion mention link audit of 29 Mestre recipe child pages.
This is a snapshot of direct fetch results, not a live authenticated Notion client.
"""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
PIN='671a13cc1904ff0f8b03e1e8d7b93894c7879888aa49b9dfee251f2719ea9d97'
NAME='CRAFT_BOM29_PREEXEC_QA_20261021.zip'
RESOLVED='3edc2b324ede816aaa04d698822055c2'
UNRESOLVED='707d83314e7c40cd89bc70fb240e6076'
SOMBRAS='3edc2b324ede813ca572c8b98443d53f'
CULTIVO='3edc2b324ede81faafa2ce406944d9b6'

def source():
 p=R/'baseline'/NAME
 if hashlib.sha256(p.read_bytes()).hexdigest()!=PIN:raise ValueError('BASELINE_HASH_MISMATCH')
 with zipfile.ZipFile(p) as z:
  if z.testzip() is not None:raise ValueError('SOURCE_ZIP_CORRUPT')
  return json.loads(z.read('data/bom29_qa_matrix.json'))['rows']

def classify(rows):
 if not isinstance(rows,list) or len(rows)!=29:return {'status':'INVALID_SOURCE_29_DENOMINATOR'}
 ids=[r['recipe_page_id'] for r in rows]
 if len(set(ids))!=29 or SOMBRAS not in ids or CULTIVO not in ids:return {'status':'INVALID_SOURCE_IDS'}
 # All 29 raw Notion enhanced-Markdown recipe bodies re-fetched on 2026-10-21.
 records=[{'recipe_page_id':rid,'notion_mention_count':0,'mention_target_ids':[],
           'mention_target_statuses':[],'physical_stock_inferred':False} for rid in ids]
 ix={r['recipe_page_id']:r for r in records}
 ix[SOMBRAS]['notion_mention_count']=1
 ix[SOMBRAS]['mention_target_ids']=[RESOLVED]
 ix[SOMBRAS]['mention_target_statuses']=['FETCH_OK_MESTRE_ITENS_MINERIOS_PO_DIAMANTE_NOTURNO']
 ix[CULTIVO]['notion_mention_count']=1
 ix[CULTIVO]['mention_target_ids']=[UNRESOLVED]
 ix[CULTIVO]['mention_target_statuses']=['NOT_FOUND_NOT_PROOF_OF_GLOBAL_NONEXISTENCE']
 return {'schema':'CRAFT-REC-REFLINK-AUDIT-TEST-v1',
 'status':'NOTION_REFERENCE_SNAPSHOT_PASS_WITH_UNRESOLVED_LINK',
 'as_of':'2026-10-21','scope':'29 MESTRE recipe child pages only, raw notion mention tag audit',
 'denominator':{'child_recipe_pages':29,'pages_with_mention_tags':2,'pages_without_mention_tags':27,
                'total_mention_targets':2,'targets_fetch_ok':1,'targets_not_found':1},
 'resolved':{'source_recipe_page_id':SOMBRAS,'target_page_id':RESOLVED,'target_title':'Pó de Diamante Noturno',
             'target_mestre_path':'RPG / Itens / Minérios'},
 'unresolved':{'source_recipe_page_id':CULTIVO,'target_page_id':UNRESOLVED,
               'visible_label':'MISSING','ingredient_display':'1x :',
               'adjacent_bom_description':'Óleo ritualístico de selamento (textual)',
               'other_description':'Localização dos Ingredientes lista Óleo de Vedação',
               'fetch_result':'NOT_FOUND','target_actual_identity':'UNKNOWN',
               'historical_mestre_mirror_same_defect':True,
               'auto_relabel_oil_allowed':False},
 'other_pending':{'matriz_protecao_recipe_page_id':'3edc2b324ede8129a6c3cfb603027383',
                  'malformed_quantity':'Ex Pó de Quartzo Fantasma',
                  'historical_mestre_mirror_same_defect':True,
                  'quantity_corrected':False},
 'records':records,
 'gate':{'physical_recipe_moved':False,'recipe_edited':False,'stock_verified':False,
         'notion_target_autocreated':False,'official_rec_id_created':False,
         'party_writes':0,'o_primeiro_writes':0,'production_enabled':False}}

def classify_request(result,claimed_target=None):
 if result.get('status')!='NOTION_REFERENCE_SNAPSHOT_PASS_WITH_UNRESOLVED_LINK':return 'DENY_BAD_SOURCE'
 # A requester-supplied URL or name is not a fetched, authoritative ID.
 return 'HOLD_MESTRE_SOURCE_OWNER_RECONCILIATION'

if __name__=='__main__':print(json.dumps(classify(source()),ensure_ascii=False,indent=2))
