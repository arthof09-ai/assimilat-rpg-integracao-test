from pathlib import Path
import hashlib,subprocess,json,sys
R=Path(__file__).resolve().parents[1]
m=json.loads((R/'MANIFEST_SHA256.json').read_text())['files']
a={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in R.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json' and '__pycache__' not in p.parts}
assert a==m
p=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'],cwd=R,capture_output=True,text=True)
assert p.returncode==0,p.stderr
s=subprocess.run([sys.executable,'-B','code/refcheck.py'],cwd=R,capture_output=True,text=True)
assert s.returncode==0,s.stderr
assert json.loads(s.stdout)==json.loads((R/'outputs'/'REFERENCE_AUDIT.json').read_text())
print('REFLINK_COLD_PASS',len(a),'SHA_FILES',p.stderr.split('Ran ')[-1].split(' ')[0],'TESTS','NO_CANONICAL_REPAIR')
