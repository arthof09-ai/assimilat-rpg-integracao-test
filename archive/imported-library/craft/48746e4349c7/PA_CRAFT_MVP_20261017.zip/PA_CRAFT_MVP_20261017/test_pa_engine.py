import unittest
from pa_engine import load,lookup,inspect,activation_check,hypothesis_attr

class PATests(unittest.TestCase):
    def test_distinct_ten_examples(self): self.assertEqual(len(load()),10)
    def test_verified_daily_arco(self): self.assertEqual(lookup("arco_exterminador_elemental")["pa_daily"]["value"],64)
    def test_verified_daily_armadura(self): self.assertEqual(lookup("armadura_guardia_elemental")["pa_daily"]["value"],55)
    def test_daily_subtotal(self): self.assertEqual(inspect(["arco_exterminador_elemental","armadura_guardia_elemental"])["daily_literal_subtotal"],119)
    def test_unknown_blocks_total(self): self.assertEqual(inspect(["arco_exterminador_elemental","botas_vento_cortante"])["daily_total_status"],"PENDENTE")
    def test_ambiguous_not_classified(self): self.assertIsNone(lookup("amuleto_inteligencia")["pa_daily"]["value"])
    def test_activation_separate(self): self.assertEqual(lookup("bracadeira_pulmao_ferro")["pa_activation"]["value"],15)
    def test_no_auto_collapse(self): self.assertEqual(activation_check(10,"bracadeira_pulmao_ferro")["aplicacao"],"NAO_EXECUTADA")
    def test_no_made_up_zero(self): self.assertIsNone(lookup("botas_vento_cortante")["pa_daily"]["value"])
    def test_hypothesis_not_rule(self): self.assertEqual(hypothesis_attr(10)["status"],"HIPOTESE_MESTRE_NAO_CALIBRADA")
    def test_duplicate_blocked(self):
        with self.assertRaises(ValueError): inspect(["arco_exterminador_elemental"]*2)
    def test_proposed_not_activated(self): self.assertEqual(activation_check(30,"bracadeira_sopro_guardiao")["status"],"CENARIO_SOMENTE_PROPOSTO")

if __name__=="__main__": unittest.main()
