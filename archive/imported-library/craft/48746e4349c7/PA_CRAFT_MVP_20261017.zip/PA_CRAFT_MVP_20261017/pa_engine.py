"""PA / CRAFT: prototipo local somente leitura. Nao canoniza custos nem escreve no RPG."""
import argparse
import json
from pathlib import Path

DATA = Path(__file__).with_name("corpus_inicial.json")


def load():
    return json.loads(DATA.read_text(encoding="utf-8"))["items"]


def lookup(item_id):
    matches = [x for x in load() if x["id"] == item_id]
    if len(matches) != 1:
        raise ValueError("Item ausente ou identidade duplicada: " + item_id)
    x = matches[0]
    return {
        "item_id": x["id"], "source_url": x["url"], "source_status": x["status"],
        "pa_daily": {"value": x["pa_day"], "status": "LITERAL" if x["pa_day"] is not None else "PENDENTE"},
        "pa_activation": {"value": x["pa_activation"], "status": "PROPOSTO" if x["cost_kind"] == "activation_proposed" else ("LITERAL" if x["pa_activation"] is not None else "PENDENTE")},
        "pa_without_period": {"value": x["pa_unqualified"], "status": "PERIODO_DESCONHECIDO" if x["pa_unqualified"] is not None else "NAO_INFORMADO"},
        "pa_daily_semantics": "INDETERMINADO_SE_COMPROMETIDO_OU_DEBITADO",
        "canonicalization": "NAO_MODIFICADA"
    }


def inspect(item_ids):
    if len(item_ids) != len(set(item_ids)):
        raise ValueError("Item duplicado na mesma configuracao")
    items = [lookup(i) for i in item_ids]
    daily_known = sum(x["pa_daily"]["value"] for x in items if x["pa_daily"]["value"] is not None)
    daily_unknown = [x["item_id"] for x in items if x["pa_daily"]["value"] is None]
    activation_known = {x["item_id"]: x["pa_activation"]["value"] for x in items if x["pa_activation"]["value"] is not None}
    return {
        "daily_literal_subtotal": daily_known,
        "daily_total_status": "PENDENTE" if daily_unknown else "SOMA_DOS_LITERAIS",
        "daily_unknown_items": daily_unknown,
        "activation_literal_costs_separate": activation_known,
        "pa_livre": "NAO_CALCULADO: diario nao classificado como PA comprometido/debito",
        "items": items,
        "type": "PARECER_EXPERIMENTAL_SEM_ESCRITA"
    }


def activation_check(pa_livre, item_id):
    if pa_livre < 0:
        raise ValueError("PA Livre nao pode ser negativo")
    item = lookup(item_id)
    cost = item["pa_activation"]["value"]
    if cost is None:
        return {"status":"PENDENTE_CUSTO_ATIVACAO", "pa_livre":pa_livre, "item":item_id}
    if item["pa_activation"]["status"] == "PROPOSTO":
        return {"status":"CENARIO_SOMENTE_PROPOSTO", "pa_livre":pa_livre, "cost":cost, "item":item_id}
    if cost > pa_livre:
        return {"status":"INSUFICIENTE_COLAPSO_SE_FORCAR_CONFORME_SISTEMA_MAGIA", "pa_livre":pa_livre, "cost":cost, "item":item_id, "aplicacao":"NAO_EXECUTADA"}
    return {"status":"COBERTURA_NUMERICA_SUFFICIENTE", "pa_livre":pa_livre, "cost":cost, "saldo_aritmetico_pos_pagamento":pa_livre-cost, "item":item_id,"aplicacao":"NAO_EXECUTADA"}


def hypothesis_attr(points, factor=5):
    if points < 0 or factor < 0:
        raise ValueError("Parametros nao negativos")
    return {"status":"HIPOTESE_MESTRE_NAO_CALIBRADA", "points":points, "pa_per_point":factor,"attr_component_only":points*factor,"not_total_item_cost":True}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("mode", choices=["lookup","inspect","activation","hypothesis","demo"])
    p.add_argument("values",nargs="*")
    args=p.parse_args()
    if args.mode=="lookup": out=lookup(args.values[0])
    elif args.mode=="inspect": out=inspect(args.values)
    elif args.mode=="activation": out=activation_check(int(args.values[0]),args.values[1])
    elif args.mode=="hypothesis": out=hypothesis_attr(float(args.values[0]))
    else: out={"sample":inspect(["arco_exterminador_elemental","armadura_guardia_elemental"]),"activation":activation_check(10,"bracadeira_pulmao_ferro"),"hypothesis":hypothesis_attr(10)}
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=="__main__": main()
