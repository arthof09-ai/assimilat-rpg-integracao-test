# PA ↔ CRAFT | MVP científico 17/10/2026

**Natureza:** ferramenta local de leitura/calculo, não regra canônica nem receita RC5. Não escreve em Notion, Party ou fichas. Não substitui nenhum componente do CRAFT.

## Resultado funcional agora

- Recupera os custos *literais* de 10 itens/casos identificados no Notion Mestre (5 explicitamente por dia, 1 explicitamente por ativação, 1 PA sem período, 2 sem PA e 1 custo por ativação em projeto autoral).
- Suma custos diários conhecidos de uma configuração, mas **não apresenta soma parcial como custo total** quando há itens pendentes.
- Mantém por ativação, por dia, custo sem período e item consumível como grandezas distintas.
- Testa cobertura numérica de PA Livre para ativação com custo conhecido, sem aplicar perda e sem confundir eventual insuficiência de PA com autorização para executá-la.
- Registra a hipótese histórica do Mestre (+5 PA por ponto de atributo) como **simulação isolada**, sem aplicá-la aos itens nem converter em regra.

## Executar

`python pa_engine.py demo`

`python pa_engine.py lookup arco_exterminador_elemental`

`python pa_engine.py inspect arco_exterminador_elemental armadura_guardia_elemental`

`python pa_engine.py activation 10 bracadeira_pulmao_ferro`

`python pa_engine.py hypothesis 10`

`python -m unittest -v test_pa_engine.py`

## Saída contratual para CRAFT

`lookup` fornece: `pa_daily`, `pa_activation`, `pa_without_period`, `source_url`, `source_status`, `pa_daily_semantics`, `canonicalization`. CRAFT usa cada campo sem inventar valores pendentes. `inspect` retorna subtotal e bloqueios por item.

## Fatos canônicos distinguidos

- Em *Criação de Ficha* e *Sistema de Magia*: **PA Total − PA comprometido = PA Livre**. Falta comprovar caso a caso se o literal `PA por dia` de cada item funciona como reserva comprometida, como débito por ciclo ou de outra forma. **Não converter automaticamente uma unidade na outra**.
- Em *Sistema de Magia*: forçar magia sem PA Livre suficiente causa exaustão espiritual extrema e inconsciência por 2d10 dias; o motor somente sinaliza insuficiência e nunca a executa.
- Em *CRAFT*: PA de ativação e PA diário são campos diferentes; ausência é PENDENTE e não zero.

## Investigação necessária antes da tabela universal

1. Censo físico por ID de itens e habilidades. Denominadores independentes (itens, efeitos, parcelas de atributo, custos declarados, custos incompletos, famílias e duplicatas).
2. Interpretar semântica temporal e modo de compromisso de PA, campo por campo.
3. Pares comparáveis e controle de efeitos coligados: atributo, dano bruto/dano condicional, CA/RD, habilidade passiva, ativa, CD, duração, cargas, recarga, alcance, rank e sinergias.
4. Medir variantes candidatas, erros, outliers e generalização em holdout, sem usar preço MED como conversão direta e sem alterar fatos históricos.
5. Submeter regra candidata à governança NAC-NORM-01 e só publicar com gate próprio; integrar com CRAFT por contrato acima.

## Estado de validação

`LOCAL-MVP` e não `VALIDADO_NAC-PASS_CANONICO`. Fontes rastreadas por URL no JSON; censo global PENDENTE; 0 coeficientes universais aceitos; 0 receitas/homologações, 0 writes canônicos. Resultados são replicáveis neste pacote, não verificação externa de execução mágica.
