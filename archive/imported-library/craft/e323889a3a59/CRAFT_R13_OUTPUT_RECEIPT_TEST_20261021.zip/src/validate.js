'use strict';
/* Auditor READ-ONLY para candidatos TEST. Não é fonte normativa, não aprova itens. */
const FAMILIES = {
  'Equipamentos/Roupas/Acessórios':'REC-MOD-EQA-01',
  'Poções':'REC-MOD-POC-01',
  'Armas':'REC-MOD-ARM-01',
  'Armaduras':'REC-MOD-ARD-01',
  'Artefatos':'REC-MOD-ART-01'
};
const NO_PROOF = ['physical_prototype','magical_transfer','effect_observed','recipe_authority'];
const REQUIRED = ['name','family','design','physical_description','mechanic','activation','duration','range','geography','acquisition','history','politics','gameplay','master_secrets','player_view','bom','process','economy','proof'];
const UUID = /^[0-9a-f]{32}$/;
const nonempty = v => typeof v === 'string' && v.trim().length > 0;
const TEXT_FIELDS = ['name','design','physical_description','mechanic','activation','duration','range','geography','acquisition','history','politics','gameplay','master_secrets'];
// Camada de não-divulgação do artefato interno TEST: NÃO é autorização Player.
// Tipos errados e cópia literal de campo Mestre devem bloquear exportação.
const MAX_PREVIEW_NAME=180, MAX_PREVIEW_VISIBLE=1400;
function previewViolations(item){
  const problems=[];
  const view=item&&item.player_view;
  if(!view||typeof view!=='object'||Array.isArray(view))return ['PLAYER_VIEW_SCHEMA'];
  for(const [key,limit] of [['name_if_discovered',MAX_PREVIEW_NAME],['visible_properties',MAX_PREVIEW_VISIBLE]]){
    if(!nonempty(view[key])||view[key].length>limit)problems.push('PLAYER_FIELD_TYPE_INVALID');
  }
  // Proteção de regressão: este check detecta COPIA LITERAL; revisão humana
  // continua necessária para paráfrases e informação secreta não estruturada.
  if(typeof item.master_secrets==='string'&&item.master_secrets.trim().length>=12){
    for(const key of ['name_if_discovered','visible_properties']){
      if(typeof view[key]==='string'&&view[key].includes(item.master_secrets.trim()))
        problems.push('PLAYER_SECRET_CROSSOVER');
    }
  }
  return [...new Set(problems)];
}

// Snapshot Mestre-side: identidades/nomes, NAO regras universais nem garantia
// de que uma fonte continua atual no Notion. O pin detecta alias/troca de IDs.
const SOURCE_IDENTITY_R53 = Object.freeze({
  '3edc2b324ede8153b25cd4d8f323bc67':['Cobre do Trovão','Minérios'],
  '3edc2b324ede8176817ec09a5651648f':['Quartzo Elétrico','Minérios'],
  '3edc2b324ede8171a99af5f43f2a3109':['Fulgurite Mística','Minérios'],
  '3edc2b324ede8125abcddb7a1f37a98e':['Capim Relâmpago de Flashgrass','Ervas/Botânica'],
  '3edc2b324ede818290aad649c65aa304':['Raiz de Condutor de Conduroot','Ervas/Botânica']
});
// Metadados congelados do recorte R53, confrontados com leitura direta
// do Notion nesta rodada. Detectam deriva local, NAO atestam login/custódia.
const SOURCE_SNAPSHOT_R53 = Object.freeze({
  '3edc2b324ede8153b25cd4d8f323bc67':['2026-10-06T11:27:25.629Z','Melhora a comunicação e transmissão de sinais mágicos.'],
  '3edc2b324ede8176817ec09a5651648f':['2026-10-06T11:32:38.926Z','Acumula energia estática e é usado em campos de força/barreiras.'],
  '3edc2b324ede8171a99af5f43f2a3109':['2026-10-06T11:28:57.620Z','Concentra/amplifica magias de eletricidade, uso registrado em bastões/cajados.'],
  '3edc2b324ede8125abcddb7a1f37a98e':['2026-10-21T10:12:39.356Z','Concede reflexos rápidos e velocidade; ocorrência atual atribuída a R10 Vale dos Raios.'],
  '3edc2b324ede818290aad649c65aa304':['2026-10-06T18:20:31.699Z','Conduz eletricidade e melhora condução de magia pelo corpo; não confere resistência automática.']
});
function validateSourceIndex(resources) {
  const failures=[];
  const rows=resources&&Array.isArray(resources.resources)?resources.resources:[];
  if(!resources || resources.kind!=='source_index_read_only' || !Array.isArray(resources.resources))
    failures.push('SOURCE_INDEX_SCHEMA');
  const seen=new Set();
  for(const r of rows){
    if(!r || typeof r.id!=='string' || !UUID.test(r.id)){
      failures.push('SOURCE_UUID_INVALID');continue;
    }
    if(seen.has(r.id))failures.push('SOURCE_DUPLICATE_ID');
    seen.add(r.id);
    const pinned=SOURCE_IDENTITY_R53[r.id];
    if(!pinned || r.name!==pinned[0] || r.family!==pinned[1])
      failures.push('SOURCE_IDENTITY_MISMATCH');
    if(r.source_url!==`https://app.notion.com/p/${r.id}`)
      failures.push('SOURCE_URL_MISMATCH');
    const frozen=SOURCE_SNAPSHOT_R53[r.id];
    if(!frozen || r.last_edited!==frozen[0] || r.verified_property!==frozen[1])
      failures.push('SOURCE_SNAPSHOT_MISMATCH');
    if(typeof r.verified_property!=='string' || !r.verified_property.trim() ||
       typeof r.bom_role!=='string' || !r.bom_role.trim())
      failures.push('SOURCE_EVIDENCE_MISSING');
    if(r.effect_rank!==null)failures.push('SOURCE_EFFECT_RANK_LEAK');
  }
  // A ausencia de uma fonte historica nao autoriza inventar outra,
  // mas uma copia parcial e permitida se a BOM apontar apenas para fontes presentes.
  return [...new Set(failures)];
}
function valid(d, resources) {
  const sourceFailures=validateSourceIndex(resources);
  const rows=resources&&Array.isArray(resources.resources)?resources.resources:[];
  const src=new Map(rows.filter(x=>x&&typeof x.id==='string').map(v=>[v.id,v]));
  const reports=[];
  const idSeen=new Set();
  const products=Array.isArray(d?.products)?d.products:null;
  if(!products || products.length===0){
    const code='PROJECTS_REQUIRED';
    return {status:'REJECT',items:[{id:null,name:'Entrada vazia/inválida',verdict:'REJECT',
      issues:[{code,msg:'products deve conter ao menos uma proposta'}],holds:[],evidence:[],
      verified_production:false,canonical_rank_approved:false,magic_transfer_proved:false}],
      total:0,distinct_sources:0,disclaimer:'Falha fechada: nenhum candidato submetido ou estrutura inválida.'};
  }
  for(const item of products) {
    const issues=[],holds=[],evidence=[];
    if(item===null || typeof item!=='object' || Array.isArray(item)){
      reports.push({id:null,name:'Proposta inválida',verdict:'REJECT',
        issues:[{code:'PROJECT_OBJECT_INVALID',msg:'Entrada deve ser objeto'}],holds:[],evidence:[],
        verified_production:false,canonical_rank_approved:false,magic_transfer_proved:false});
      continue;
    }
    const reject=(code,msg)=>issues.push({code,msg});
    const hold=(code,msg)=>holds.push({code,msg});
    for(const code of sourceFailures)reject(code,'Índice local não equivale a fonte Mestre autenticada; exigir releitura de origem');
    hold('LIVE_SOURCE_RECHECK','Readback Notion ao reutilizar esta ficha; índice offline apenas snapshot histórico');
    if(!nonempty(item.proposal_id)||idSeen.has(item.proposal_id)) reject('DUPLICATE_PROPOSAL','Identificador vazio, inválido ou duplicado');
    if(typeof item.proposal_id==='string') idSeen.add(item.proposal_id);
    if(typeof item.proposal_id!=='string'||!item.proposal_id.includes('TEST')) reject('NOT_SANDBOX','Proposta não sinalizada como TEST');
    if(item.module!==FAMILIES[item.family]) reject('MODULE_MISMATCH','Módulo não corresponde à família');
    if(item.item_rank!==null||item.effect_rank!==null||item.rin_inherited_as_rank!==false) reject('RANK_SHORTCUT','Rank de insumo ou objeto antecipado como efeito');
    if(item.pa_daily!==null||item.pa_activation!==null) reject('PA_UNAUTHORIZED','Custo PA sem recibo autorizado');
    if(item.item_found_in_notion!==false) reject('ANTI_DUP_UNPROVEN','Estado de deduplicação não suportado; verificar busca');
    for(const field of REQUIRED)if(!(field in item)||item[field]===undefined)reject('MISSING_FIELD',`Campo ausente: ${field}`);
    for(const field of TEXT_FIELDS)if(!nonempty(item[field]))reject('TEXT_FIELD_INVALID',`Texto obrigatório inválido: ${field}`);
    for(const field of ['duration','activation','cooldown'])if(item[field]!==undefined&&!nonempty(item[field]))reject('MECHANIC_TYPE_INVALID',`Campo mecânico inválido: ${field}`);
    if(item.player_view?.status!=='NÃO PUBLICAR'||item.player_view?.secret_fields_excluded!==true) reject('PARTY_EXPOSURE','Versão Player não possui bloqueio e sigilo');
    for(const code of previewViolations(item))reject(code,'Prévia TEST recusada: campo Player inválido ou contém conteúdo Mestre literal');
    if(!item.bom||!Array.isArray(item.bom)||!item.process||!Array.isArray(item.process)){reject('MISSING_BOM','BOM ou processo inexistentes');reports.push({id:item.proposal_id,name:item.name||null,family:item.family||null,issues,holds,evidence,verdict:'REJECT',verified_production:false,canonical_rank_approved:false,magic_transfer_proved:false});continue;}
    if(item.bom.length===0)reject('BOM_EMPTY','BOM sem nós não é projeto executável');
    if(item.process.length===0)reject('PROCESS_EMPTY','Processo sem etapas não é projeto executável');
    const nodes=new Map();
    for(const node of item.bom){
      if(!node || typeof node!=='object' || Array.isArray(node)){
        reject('BOM_NODE_INVALID','Nó BOM deve ser objeto');continue;
      }
      if(!nonempty(node.node_id)||nodes.has(node.node_id))reject('BOM_COLLISION','Nó BOM ausente, inválido ou repetido');
      if(nonempty(node.node_id))nodes.set(node.node_id,node);
      if(node.source_id!==null && node.source_id!==undefined){
        if(typeof node.source_id!=='string'||!UUID.test(node.source_id)||!src.has(node.source_id))reject('UNVERIFIED_RESOURCE',`Material fora do índice verificado: ${String(node.node_id)}`);
        else evidence.push({node_id:node.node_id,source_name:src.get(node.source_id).name,source_url:src.get(node.source_id).source_url,source_rank_is_not_effect_rank:true});
      }else hold('SOURCE_PENDING',`Material comum ou fonte não especificada no nó ${node.node_id}; não promover CRN`);
      if(node.qty==null||node.unit==null)hold('BOM_QUANTITY_PENDING',`Quantidade/unidade do nó ${String(node.node_id)} pendente`);
      else if(typeof node.qty!=='number'||!Number.isFinite(node.qty)||node.qty<=0)reject('INVALID_QUANTITY','Quantidade BOM não positiva ou inválida');
      if(node.unit!==null&&node.unit!==undefined&&!nonempty(node.unit))reject('BOM_UNIT_INVALID','Unidade BOM deve ser texto não vazio');
      if(typeof node.consumed!=='boolean')reject('BOM_CONSUMED_INVALID','Consumo do nó deve ser booleano');
      if(!nonempty(node.role)||!nonempty(node.evidence))reject('BOM_ROLE_MISSING',`Nó ${String(node.node_id)} sem função/evidência`);
    }
    const used=new Set();
    const stepSeen=new Set();
    for(const step of item.process){
      if(!step || typeof step!=='object' || Array.isArray(step)){
        reject('PROCESS_STEP_INVALID','Etapa deve ser objeto');continue;
      }
      if(!Number.isInteger(step.step)||step.step<1||stepSeen.has(step.step))reject('PROCESS_ORDER','Etapa duplicada ou inválida');
      stepSeen.add(step.step);
      if(!nonempty(step.action)||!nonempty(step.status))reject('PROCESS_UNSPECIFIED','Etapa sem ação/status string');
      if(!Array.isArray(step.input_node_ids))reject('PROCESS_INPUTS_INVALID','Entradas da etapa devem ser uma lista');
      else for(const id of step.input_node_ids){if(typeof id!=='string'||!nodes.has(id))reject('PHANTOM_INPUT',`Nó ${String(id)} não existe na BOM`);else used.add(id);}
      if(typeof step.status==='string' && /executado|observado|validado/i.test(step.status)&&!/(não executado|não validado|não observado|não demonstrado)/i.test(step.status))reject('PHYSICAL_CLAIM','Etapa declarada como executada sem evidência');
    }
    for(const id of nodes.keys())if(!used.has(id))reject('BOM_PROCESS_MISMATCH',`Nó BOM não consta do processo: ${id}`);
    for(const k of ['yield','loss_rate','craft_time','qualified_operator','storage'])if(item[k]==null)hold('RECIPE_NOT_EXECUTABLE',`Falta ${k}`);
    if(!item.proof||typeof item.proof!=='object'||Array.isArray(item.proof))reject('PROOF_SCHEMA_INVALID','Envelope de provas deve ser objeto');
    const proof=item.proof&&typeof item.proof==='object'&&!Array.isArray(item.proof)?item.proof:{};
    for(const k of NO_PROOF){if(proof[k]!==null&&proof[k]!==undefined)reject('FABRICATION_UNVERIFIED',`Prova de ${k} não verificada em TEST`);}
    if(proof.inventory_commit!==false||proof.party_published!==false)reject('MUTATION_NOT_ALLOWED','Inventário/Party são NO-WRITE');
    if(!item.economy||typeof item.economy!=='object'||Array.isArray(item.economy)||item.economy.cte_med!==null||item.economy.market_value_med!==null)reject('UNSUPPORTED_ECONOMY','Custo/preço sem base auditada');
    else hold('ECONOMY_PENDING','CTE e preço exigem dados das quatro camadas de valor');
    if(['activation','duration','cooldown'].some(k=>typeof item[k]==='string'&&item[k].includes('PENDENTE')))hold('MECHANICS_PENDING','Ativação/duração/recarga ainda não fechadas');
    if(!nonempty(item.search_scope))hold('SEARCH_SCOPE_UNKNOWN','Escopo de busca anti-duplicata não textual/ausente');
    hold('MAGIC_NOT_DEMONSTRATED','Componente com propriedade própria não prova transferência/instalação mágica');
    const verdict=issues.length?'REJECT':holds.length?'HOLD_TEST_DESIGN':'FORM_READY_NOT_PRODUCTION';
    reports.push({id:item.proposal_id,name:item.name,family:item.family,verdict,source_census:evidence.length,issues,holds,evidence,
      verified_production:false,canonical_rank_approved:false,magic_transfer_proved:false});
  }
  return {status:reports.some(x=>x.verdict==='REJECT')?'REJECT':reports.every(x=>x.verdict==='FORM_READY_NOT_PRODUCTION')?'FORM_READY_NOT_PRODUCTION':'HOLD_TEST_DESIGN',
    items:reports,total:reports.length,distinct_sources:[...new Set(reports.flatMap(r=>(Array.isArray(r.evidence)?r.evidence:[]).map(e=>e.source_url)))].length,
    disclaimer:'Aparência de completude documental não equivale a receita RC5, criação física, magia instalada, precificação ou aprovação.'};
}
function playerSafe(item){
  return {name:item.player_view.name_if_discovered,visible:item.player_view.visible_properties,disclosure_status:item.player_view.status,
     internal_approval:false};
}
if(typeof module!=='undefined')module.exports={valid,playerSafe,FAMILIES,validateSourceIndex};
