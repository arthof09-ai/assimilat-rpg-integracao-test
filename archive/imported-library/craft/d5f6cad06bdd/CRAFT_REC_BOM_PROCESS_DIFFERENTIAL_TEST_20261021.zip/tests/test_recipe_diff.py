import unittest,copy,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from recipe_diff import *
class TestAudit(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  c.a=json.loads((ROOT/'data'/'recipe_transcription_mestre_only.json').read_text())['records'];c.r=corpus_report(c.a)
 def case(self,i):return self.r['cases'][i]
 def test_count(self):self.assertEqual(self.r['scope_pages'],9)
 def test_master_count(self):self.assertEqual(self.r['mestre_recipe_pages'],8)
 def test_historical_count(self):self.assertEqual(self.r['historical_comparators'],1)
 def test_corpus_status(self):self.assertIsNone(verify_corpus(self.a))
 def test_id_unique(self):self.assertEqual(len({x['id'] for x in self.a}),9)
 def test_page_unique(self):self.assertEqual(len({x['page_id'] for x in self.a}),9)
 def test_master_p2_hold(self):self.assertEqual(self.case(0)['status'],'BOM_PROCESS_IDENTITY_HOLD')
 def test_p2_salt_bom_not_used(self):self.assertIn('SAL_SANTO',self.case(0)['unmatched_bom_ids'])
 def test_p2_salt_process_only(self):self.assertIn('SAL_ENCANTADO',self.case(0)['process_only_ids'])
 def test_p2_energy_missing(self):self.assertIn('ALT_ENERGY',self.case(0)['unresolved_or_branches'])
 def test_p2_oil_used(self):self.assertNotIn('OLEO_VEDACAO',self.case(0)['unmatched_bom_ids'])
 def test_vento_mintaur(self):self.assertIn('FOLHAS_MINTAUR',self.case(1)['process_only_ids'])
 def test_vento_sussurro_unused(self):self.assertIn('FOLHAS_SUSSURRO_CONGELADOS',self.case(1)['unmatched_bom_ids'])
 def test_terra_literal_pass(self):self.assertEqual(self.case(2)['status'],'BOM_PROCESS_LITERAL_LINKAGE_PASS_NONPHYSICAL')
 def test_chama_literal_pass(self):self.assertEqual(self.case(3)['status'],'BOM_PROCESS_LITERAL_LINKAGE_PASS_NONPHYSICAL')
 def test_terra_not_magic(self):self.assertFalse(self.case(2)['physical_execution_verified'])
 def test_chama_not_recipe_certified(self):self.assertFalse(self.case(3)['quantities_verified_by_process'])
 def test_nevasca_no_auto_alias(self):self.assertIn('PO_DO_GELO_ETERNO',self.case(4)['process_only_ids'])
 def test_nevasca_sopro(self):self.assertIn('SOPRO_DO_CONGELANTE',self.case(4)['process_only_ids'])
 def test_spatial_portal(self):self.assertIn('ESS_PORTAL',self.case(5)['unmatched_bom_ids'])
 def test_spatial_blackhole(self):self.assertIn('ESS_BURACO_NEGRO',self.case(5)['process_only_ids'])
 def test_spatial_lirio(self):self.assertIn('LIRIO_VAZIO',self.case(5)['unmatched_bom_ids'])
 def test_spatial_cometa(self):self.assertIn('FRAGMENTOS_COMETA',self.case(5)['process_only_ids'])
 def test_spatial_cosmic(self):self.assertIn('CINZA_BESTA_COSMICA',self.case(5)['unmatched_bom_ids'])
 def test_spatial_dragon(self):self.assertIn('CINZA_DRAGAO_COSMICO',self.case(5)['process_only_ids'])
 def test_spatial_energy(self):self.assertIn('ALT_ENERGY',self.case(5)['unresolved_or_branches'])
 def test_spatial_oil(self):self.assertIn('OLEO_VEDACAO',self.case(5)['unmatched_bom_ids'])
 def test_illusion_oil(self):self.assertIn('OLEO_VEDACAO',self.case(6)['unmatched_bom_ids'])
 def test_illusion_energy(self):self.assertIn('ALT_ENERGY',self.case(6)['unresolved_or_branches'])
 def test_oil_amanhecer(self):self.assertIn('ORVALHO_AMANHECER',self.case(7)['unmatched_bom_ids'])
 def test_oil_dragon(self):self.assertIn('ORVALHO_DRAGAO',self.case(7)['process_only_ids'])
 def test_oil_moon(self):self.assertIn('ESS_LUA_MINGUANTE',self.case(7)['unmatched_bom_ids'])
 def test_oil_vortex(self):self.assertIn('ESS_VORTICE',self.case(7)['process_only_ids'])
 def test_alt_not_authority(self):self.assertEqual(self.case(8)['status'],'HISTORICAL_COMPARATOR_ONLY_NOT_AUTHORITY')
 def test_oil_3v2(self):
  self.assertEqual(next(x['qty'] for x in self.a[7]['bom'] if x['key']=='PO_FERRO_CELESTIAL'),'3')
  self.assertEqual(next(x['qty'] for x in self.a[8]['bom'] if x['key']=='PO_FERRO_CELESTIAL'),'2')
 def test_no_auto_replacement(self):self.assertEqual(self.r['ingredient_replacements'],0)
 def test_no_new_pages(self):self.assertEqual(self.r['notional_recipe_pages_created'],0)
 def test_no_party(self):self.assertTrue(all(x['party_writes']==0 for x in self.r['cases']))
 def test_no_o_primeiro(self):self.assertTrue(all(x['o_primeiro_writes']==0 for x in self.r['cases']))
 def test_no_rec_id(self):self.assertTrue(all(x['official_rec_id_created'] is None for x in self.r['cases']))
 def test_no_migration(self):self.assertFalse(self.r['rec_lib_migration_authorized'])
 def test_master_2_literal(self):self.assertEqual(self.r['master_literal_pass'],2)
 def test_master_6_hold(self):self.assertEqual(self.r['master_identity_hold'],6)
 def test_or_kept_alternative(self):self.assertEqual(len(self.a[0]['bom'][-1]['options']),2)
 def test_blank_process_kept(self):self.assertEqual(self.a[5]['steps'][-1]['uses'],['ORVALHO_FLOR_SONHO'])
 def test_duplicate_recipe_id_reject(self):
  a=copy.deepcopy(self.a);a[1]['id']=a[0]['id'];self.assertEqual(verify_corpus(a),'DUPLICATE_RECIPE_OR_PAGE')
 def test_duplicate_page_id_reject(self):
  a=copy.deepcopy(self.a);a[1]['page_id']=a[0]['page_id'];self.assertEqual(verify_corpus(a),'DUPLICATE_RECIPE_OR_PAGE')
 def test_invalid_role(self):
  a=copy.deepcopy(self.a);a[0]['role']='PARTY';self.assertEqual(verify_corpus(a),'INVALID_AUTHORITY_ROLE')
 def test_zero_qty(self):
  a=copy.deepcopy(self.a);a[0]['bom'][0]['qty']='0';self.assertEqual(verify_corpus(a),'INVALID_BOM_QUANTITY')
 def test_bad_or(self):
  a=copy.deepcopy(self.a);a[0]['bom'][-1]['options']=['PEDRA_LUZ'];self.assertEqual(verify_corpus(a),'OR_BRANCH_INVALID')
 def test_bad_step_sequence(self):
  a=copy.deepcopy(self.a);a[0]['steps'][0]['seq']=2;self.assertEqual(verify_corpus(a),'PROCESS_SEQUENCE_INVALID')
 def test_bad_step_type(self):
  a=copy.deepcopy(self.a);a[0]['steps'][0]['uses']='Sal';self.assertEqual(verify_corpus(a),'PROCESS_USES_INVALID')
 def test_extra_single_options_reject(self):
  a=copy.deepcopy(self.a);a[0]['bom'][0]['options']=['C'];self.assertEqual(verify_corpus(a),'SINGLE_WITH_OPTIONS_INVALID')
 def test_bad_id(self):
  a=copy.deepcopy(self.a);a[0]['page_id']='fake';self.assertEqual(verify_corpus(a),'INVALID_PAGE_ID')
 def test_input_immutable(self):
  a=copy.deepcopy(self.a);b=copy.deepcopy(a);corpus_report(a);self.assertEqual(a,b)
 def test_two_runs_identical(self):self.assertEqual(corpus_report(self.a),corpus_report(self.a))
 def test_authority_preserved(self):self.assertEqual(self.case(0)['role'],'MESTRE_RECIPE')
 def test_no_qty_cert(self):self.assertTrue(all(not x['quantities_verified_by_process'] for x in self.r['cases']))
 def test_no_write_allowed(self):self.assertTrue(all(not x['recipe_edit_allowed'] for x in self.r['cases']))
if __name__=='__main__':unittest.main()
