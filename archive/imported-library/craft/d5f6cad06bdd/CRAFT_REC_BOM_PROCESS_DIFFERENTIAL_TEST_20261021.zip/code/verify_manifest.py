from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def check():
 m=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json' and '__pycache__' not in p.parts}
 assert set(m['files'])==actual
 assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in m['files'].items())
 return len(actual)
if __name__=='__main__':print('PASS',check())
