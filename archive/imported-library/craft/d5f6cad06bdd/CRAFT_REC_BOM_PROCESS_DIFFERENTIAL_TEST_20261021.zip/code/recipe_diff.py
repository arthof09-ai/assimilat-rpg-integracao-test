"""BOM/process linkage auditor with strict identity and explicit OR branches.

Only distinguishes role-preserving strings: no fuzzy synonym substitution,
no file/Notion writes, no recipe repair or stock effects.
"""
from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parents[1]

def verify_corpus(records):
    if not isinstance(records,list) or not records:return 'INVALID_RECORDS'
    ids=[r.get('id') for r in records]
    pages=[r.get('page_id') for r in records]
    if len(ids)!=len(set(ids)) or len(pages)!=len(set(pages)):return 'DUPLICATE_RECIPE_OR_PAGE'
    if not all(isinstance(p,str) and re.fullmatch('[0-9a-f]{32}',p) for p in pages):return 'INVALID_PAGE_ID'
    for r in records:
        if r.get('role') not in ('MESTRE_RECIPE','ALTERNATE_HISTORICAL_NOT_MASTER_AUTHORITY'):
            return 'INVALID_AUTHORITY_ROLE'
        bom=r.get('bom');steps=r.get('steps')
        if not isinstance(bom,list) or not isinstance(steps,list) or not steps:return 'MISSING_BOM_OR_STEPS'
        keys=[x.get('key') for x in bom]
        if len(keys)!=len(set(keys)):return 'DUPLICATE_BOM_KEY'
        for x in bom:
            if not isinstance(x.get('qty'),str) or not re.fullmatch(r'[1-9][0-9]*',x['qty']):return 'INVALID_BOM_QUANTITY'
            if x.get('kind') not in ('single','one_of'):return 'BOM_KIND_INVALID'
            if x['kind']=='one_of':
                if not isinstance(x.get('options'),list) or len(set(x['options']))<2 or not all(isinstance(t,str) and t for t in x['options']):
                    return 'OR_BRANCH_INVALID'
            elif 'options' in x:return 'SINGLE_WITH_OPTIONS_INVALID'
        n=[s.get('seq') for s in steps]
        if n!=list(range(1,len(n)+1)):return 'PROCESS_SEQUENCE_INVALID'
        if any(not isinstance(s.get('uses'),list) or not all(isinstance(x,str) and x for x in s['uses']) for s in steps):
            return 'PROCESS_USES_INVALID'
    return None

def audit(rec):
    err=verify_corpus([rec])
    if err:return {'status':'REJECTED_NO_AUTOFIX','reason':err}
    used={x for step in rec['steps'] for x in step['uses']}
    single={x['key'] for x in rec['bom'] if x['kind']=='single'}
    alternatives=[x for x in rec['bom'] if x['kind']=='one_of']
    unused_single=sorted(single-used)
    unmet_alts=[x['key'] for x in alternatives if not used.intersection(x['options'])]
    supplied=single.union(*[set(a['options']) for a in alternatives])
    process_only=sorted(used-supplied)
    role=rec['role']
    status='BOM_PROCESS_LITERAL_LINKAGE_PASS_NONPHYSICAL' if not (unused_single or unmet_alts or process_only) else 'BOM_PROCESS_IDENTITY_HOLD'
    # Alternative source is NEVER authorization to override a Mestre source.
    if role!='MESTRE_RECIPE':status='HISTORICAL_COMPARATOR_ONLY_NOT_AUTHORITY'
    return {'id':rec['id'],'page_id':rec['page_id'],'role':role,'family':rec['family'],
            'status':status,'bom_lines_n':len(rec['bom']),'process_steps_n':len(rec['steps']),
            'unmatched_bom_ids':unused_single,'unresolved_or_branches':unmet_alts,
            'process_only_ids':process_only,'quantities_verified_by_process':False,
            'physical_execution_verified':False,'recipe_edit_allowed':False,
            'official_rec_id_created':None,'party_writes':0,'o_primeiro_writes':0,
            'identity_warnings':rec.get('known_notes',[]),
            'source_evidence':'MESTRE_NOTION_READBACK_MANUAL_TOKENIZATION_NOT_PHYSICAL'}

def corpus_report(records):
    e=verify_corpus(records)
    if e:return {'status':'INVALID_CORPUS','reason':e}
    data=[audit(x) for x in records]
    master=[x for x in data if x['role']=='MESTRE_RECIPE']
    comparator=[x for x in data if x['role']!='MESTRE_RECIPE']
    return {'schema':'CRAFT-REC-BOM-PROCESS-LITERAL-AUDIT-TEST-v1',
            'scope_pages':len(records),'mestre_recipe_pages':len(master),'historical_comparators':len(comparator),
            'master_literal_pass':sum(x['status']=='BOM_PROCESS_LITERAL_LINKAGE_PASS_NONPHYSICAL' for x in master),
            'master_identity_hold':sum(x['status']=='BOM_PROCESS_IDENTITY_HOLD' for x in master),
            'notional_recipe_pages_created':0,'ingredient_replacements':0,'changes_to_existing_recipe_pages':0,
            'physical_rc5_claim':False,'rec_lib_migration_authorized':False,
            'notes':['PASS literal is not certification of quantities or physical magic',
                     'No auto-merge or synonyms; only author can adjudicate aliases',
                     'Historical 2 vs current Mestre 3 Pó Ferro Celestial is a version contrast, not a corrected quantity'],
            'cases':data}

if __name__=='__main__':
 src=json.loads((ROOT/'data'/'recipe_transcription_mestre_only.json').read_text(encoding='utf8'))
 print(json.dumps(corpus_report(src['records']),indent=2,ensure_ascii=False))
