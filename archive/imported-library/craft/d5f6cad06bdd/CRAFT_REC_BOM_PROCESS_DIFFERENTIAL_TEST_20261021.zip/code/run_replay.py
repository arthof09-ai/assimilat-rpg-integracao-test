from pathlib import Path
import sys,json,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from verify_manifest import check
from recipe_diff import corpus_report
if __name__=='__main__':
 n=check();t=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
 if t.returncode:raise RuntimeError(t.stderr)
 src=json.loads((ROOT/'data'/'recipe_transcription_mestre_only.json').read_text())
 assert corpus_report(src['records'])==json.loads((ROOT/'outputs'/'RESULT.json').read_text())
 print('PASS_CRAFT_BOM_PROCESS_COLD_REPLAY',n,'MANIFEST',t.stderr.strip().split('Ran ')[-1].split(' ')[0],'TESTS_9_PAGES_NO_RECIPE_WRITES')
