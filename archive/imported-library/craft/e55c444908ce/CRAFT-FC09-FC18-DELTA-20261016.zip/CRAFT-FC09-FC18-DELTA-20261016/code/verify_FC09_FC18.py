#!/usr/bin/env python3
"""Independent stdlib verifier: hashes, counts, R44 ledger, synthetic QA, source separation.

Does NOT import R44 motor and does NOT trust its 'audit.ok' flag.
No network calls, Notion writes, or live inventory actions.
"""
import argparse,hashlib,copy,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]

def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def sha(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def bsha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(p):return json.loads((ROOT/p).read_text(encoding='utf8'))
def insist(cond,msg):
    if not cond:raise AssertionError(msg)
def verify_manifest():
    path=ROOT/'MANIFEST_SHA256.json';m=json.loads(path.read_text())
    for name,row in m['files'].items():
        p=ROOT/name;insist(p.is_file(),'MISSING_MANIFEST_FILE:'+name)
        insist(p.stat().st_size==row['bytes'],'SIZE_MISMATCH:'+name)
        insist(bsha(p)==row['sha256'],'HASH_MISMATCH:'+name)
    observed={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p!=path and '__pycache__' not in p.parts}
    insist(observed==set(m['files']),'UNLISTED_OR_MISSING_IN_MANIFEST:'+str(observed.symmetric_difference(m['files'])))
    return len(m['files'])
def verify_ledger():
    recipe=data('contracts/B30-04-R44-TEST.json'); receipts=data('outputs/r44_B30_04/r44_executed_receipts.json');snapshot=data('outputs/r44_B30_04/r44_snapshot.json')
    insist(recipe['official_rec_id'] is None and recipe['official_product_id'] is None and recipe['mechanical_bonus']==0,'OFFICIAL_LEAK')
    insist(receipts['recipe_sha256']==sha(recipe),'RECIPE_RECEIPT_HASH_MISMATCH')
    original_integrity=snapshot.pop('integrity_sha256')
    insist(sha(snapshot)==original_integrity,'INVALID_SNAPSHOT_HASH');snapshot['integrity_sha256']=original_integrity
    insist(snapshot['recipe_hashes'][recipe['key']]==sha(recipe),'RECIPE_HASH_NOT_SNAPSHOT')
    initial=snapshot['initial_lots'];state=snapshot['state']
    insist(snapshot['initial_hash']==sha(initial),'INITIAL_LOTS_MUTATED')
    genesis=hashlib.sha256('SBX-CRAFT-R44-I0016|GENESIS-v1'.encode()).hexdigest()
    prev=genesis;held=copy.deepcopy(initial);seen=set();products={}
    for num,item in enumerate(state['events'],1):
        e=item['event'];insist(item['previous_hash']==prev,'CHAIN_LINK_BAD')
        insist(item['hash']==sha({'previous_hash':prev,'event':e}),'CHAIN_HASH_BAD');prev=item['hash']
        insist(e['seq']==num,'SEQ_BAD');aid=e['attempt_id'];insist(aid not in seen,'DUPLICATE_EVENT');seen.add(aid)
        before={lot:q['quantity'] for lot,q in held.items()}
        r=state['attempts'][aid];insist(r['inventory_before']==before,'BEFORE_STOCK_DIFF')
        insist(r['request_hash']==e['request_hash'] and r['status']==e['status'],'RECEIPT_STATUS_DIFF')
        for field in ('consumed','products','scrap','transformation_stage_trace'):
            insist(r[field]==e[field],'EVENT_'+field+'_MISMATCH')
        for item2 in e['consumed']:
            lotid=item2['lot_id'];insist(lotid in held,'UNKNOWN_LOT')
            insist(item2['quantity']>0 and item2['unit']==held[lotid]['unit'],'INVALID_CONSUMPTION')
            insist(item2['source_page_id']==held[lotid]['source_page_id'],'ORIGIN_CROSSED')
            held[lotid]['quantity']-=item2['quantity'];insist(held[lotid]['quantity']>=0,'OVERSELL')
        after={lot:q['quantity'] for lot,q in held.items()}
        insist(r['inventory_after']==after,'AFTER_STOCK_DIFF')
        if e['status']=='REJECTED_PRECHECK': insist(not e['consumed'] and not e['products'],'BAD_PREFLIGHT')
        if e['status']=='EXPERIMENTAL_QA_PASS': insist(len(e['products'])==1,'BAD_QA_PASS')
        if e['status']=='REJECTED_QUALITY': insist(not e['products'] and bool(e['scrap']),'BAD_QA_FAIL')
        for prod in e['products']:
            insist(prod['official_product_id'] is None and prod['mechanical_bonus']==0,'CANONICAL_PRODUCT_LEAK')
            products[prod['product_id']]=prod
    insist(held==state['lots'],'REPLAYED_INVENTORY_BAD')
    insist(products==state['products'],'REPLAYED_PRODUCT_BAD')
    insist(state['head_hash']==prev and receipts['engine_audit']['head_hash']==prev,'HEAD_MISMATCH')
    insist(len(state['events'])==3 and len(products)==1,'EVENT_COUNT_OR_PRODUCTS_BAD')
    assert receipts['idempotent_replay']['idempotent_replay'] is True
    insist(receipts['idempotent_replay']['request_hash']==receipts['cases'][0]['request_hash'],'BAD_IDEMPOTENCY')
    insist(receipts['cases'][0]['status']=='EXPERIMENTAL_QA_PASS' and receipts['cases'][1]['status']=='REJECTED_PRECHECK' and receipts['cases'][2]['status']=='REJECTED_QUALITY','SCENARIO_MATRIX_WRONG')
    for f in receipts['material_fraction_sheets']:
        feed=f['feed_g'];remainder=sum(x for k,x in f.items() if k.endswith('_g') and k not in ('feed_g','mass_balance_error_g'))
        insist(feed==remainder and f['mass_balance_error_g']==0,'SYNTHETIC_MASS_MISMATCH')
    return {'verified_events':len(state['events']),'products_TEST':len(products),'head':prev,'receipt_independent':True,'restart_reported_and_integrity_recomputed':True}

def verify_portfolio():
    d=data('outputs/FC17_portfolio_30.json');items=d['items'];insist(len(items)==30,'NO_30_ROWS')
    insist({row['b30'] for row in items}=={f'B30-{x:02}' for x in range(1,31)},'ID_COVERAGE')
    insist(len({row['resource_url'] for row in items})==30,'SOURCE_IDENTITY_DUP')
    insist(sum(row['preparation_historical']=='PRE-Q2' for row in items)==23,'PRE_Q2_COUNT')
    insist(sum(row['preparation_historical']=='PRE-Q1' for row in items)==7,'PRE_Q1_COUNT')
    insist(not any(row['rc5_technical_verified'] or row['rc5_official'] or row['new_official_rec_id'] for row in items),'FALSE_RC5')
    for row in items:insist(row['first_real_blocker'] and row['specific_next_action'],'NO_DECISION')
    for n in [4,17,13,16]:
        insist(next(r for r in items if r['b30']==f'B30-{n:02}')['status_after'],'MISSING_RECIPE_DECISION')
    stage=data('outputs/FC18_succession.json');insist(len(stage['stages'])==10,'NOT_10_PHASES');insist(stage['official_denominators']['rc5_physical_REC_IDs']==0,'UNAUTHORIZED_RC5')
    return {'rows':30,'PRE_Q2':23,'PRE_Q1':7,'stages_documented':10,'official_rc5':0}

def main():
    result={'scope':'INDEPENDENT_OFFLINE_NO_GAME_MODIFICATIONS','manifest_files':verify_manifest(),'ledger':verify_ledger(),'portfolio':verify_portfolio(),'passed':True}
    print(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True))
if __name__=='__main__':main()
