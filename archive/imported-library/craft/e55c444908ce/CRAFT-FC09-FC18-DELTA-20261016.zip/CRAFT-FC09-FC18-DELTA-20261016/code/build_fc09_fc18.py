#!/usr/bin/env python3
"""Assembles additive Mestre-only FC09-FC18 technical artifacts from preserved source documents.
Does not call Notion, modify engine, or create real RPG objects. All judgments marked scoped.
"""
from pathlib import Path
import json,re,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1]
SRC=Path('/mnt/data/BACKFILL30-CRAFT-20261014/ESPECIFICACOES-B30-01-a-B30-30.md')
text=SRC.read_text()

def out(path,obj):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')

# Type: verdict, obstacle, one genuine next change, dependency IDs (SOURCE ONLY), family.
D={
1:('INCONCLUSIVA_MERITO_IND','Malha 2D faz sentido; nenhuma vantagem do substrato PS sobre gabarito comum demonstrada','Aceitar função como variante de gabarito ou documentar tolerância que material PS permite e comum não','', 'Oficina/medição'),
2:('VARIANTE_BASE_PENDENTE','Cordame genérico cumpre função; receita-base física não encontrada','Identificar fonte física de cordoaria comum; não registrar derivada fictícia','', 'Fibras/união'),
3:('INCONCLUSIVA_MONTAGEM','Nenhuma montagem fonte-vinculada exige mica nem especifica a distância','Localizar necessidade de espaçamento em objeto existente; caso contrário não avançar','', 'Oficina/medição'),
4:('CANDIDATA_NOVA_CONDICIONAL','Um PS; peneiramento basta para grade, mas dureza/sortimento/linhagem/custo ainda sem prova','Identificar operador/ferramental e classificação reconhecida; homologar lote controlado no contexto PS','', 'Abrasivos'),
5:('VARIANTE_POTENCIAL','Placa rígida comum pode dar apoio; anisotropia do gnaisse não qualificada','Confrontar carga/planicidade com placa de apoio existente','', 'Oficina/medição'),
6:('INCONCLUSIVA_INVOLUCRO','Zeólita não é recipiente; fonte de bolsa porosa competente ausente','Identificar invólucro já existente ou mudar alvo para carga solta','', 'Conservação'),
7:('CANDIDATA_NOVA_CONDICIONAL','Pó pigmentário fisicamente plausível; cor, pureza e fixação não medidas; veículo não identificado','Tratar pó seco sem prometer tinta; qualificar marcador comum/aderência','', 'Pigmentos'),
8:('VARIANTE_POTENCIAL','Punho de chifre sem corpo de ferramenta correspondente confirmado','Identificar ferramenta hospedeira e encaixe; buscar punho comum anterior','', 'Oficina/componentes'),
9:('VARIANTE_POTENCIAL','Pena aparada é cálamo convencional; fluido de escrita separado não demonstrado','Vincular a suporte/fluido existente antes de designar fórmula própria','', 'Oficina/inscrição'),
10:('INCONCLUSIVA_PROPRIEDADE','Buril de presa demanda dureza e aresta suficientes, não evidenciadas','Comparar carga de incisão com metal/ponta comum documentados','', 'Oficina/inscrição'),
11:('INCONCLUSIVA_FORNO','Selagem cerâmica precisa de forno/temperatura/curva, além de argila','Confirmar oficina cerâmica, curva e taxa de rachaduras sem inferência','', 'Cerâmica'),
12:('VARIANTE_POTENCIAL','Carga carbonática é aditivo, exige argamassa ligante existente','Identificar fórmula-base de argamassa e classificação compatível','', 'Materiais de construção'),
13:('CANDIDATA_MISTURA_CONDICIONAL','Mistura de húmus e areia é operável como blend; alegação de melhora germinativa não provada','Qualificar areia crua como insumo, higiene e final medido; verificar linhagem de substrato comum','B30-04:RECURSO_CRU','Agricultura'),
14:('INCONCLUSIVA_SEGURANCA','Turfa pode arder, mas composição/umidade/carbonização/impacto ecológico não verificados','Validar sustentabilidade e combustão antes de classificar briquete combustível','', 'Combustível'),
15:('INCONCLUSIVA_MAGNETISMO','Magnetita não garante instrumento de orientação estável em oficina ou jogo','Validar magnetização, pivô e campo local; comparar bússola existente','', 'Oficina/medição'),
16:('CANDIDATA_MISTURA_CONDICIONAL','Blend seco feldspato/argila processável; vidro/cerâmica final e sinterização não demonstrados','Fixar alvo como pré-mistura não queimada; qualificar argila e forno só para próxima receita','B30-11:RECURSO_CRU','Cerâmica'),
17:('CANDIDATA_NOVA_CONDICIONAL','Moagem e classificação fina distintas da peneira grossa; qualidade abrasiva não provada','Validar instrumento, operador, qualidade e linhagem proporcional; sem pressupor 100g aprovados','', 'Abrasivos'),
18:('VARIANTE_BASE_PENDENTE','Refratário de magnesita exige ligante/cadinho/temperatura, não comprovados','Localizar fórmula e cadinho existente; não pressupor refratariedade medida','', 'Cerâmica'),
19:('VARIANTE_POTENCIAL','Cobertura flexível de pele equivale potencialmente a capa comum','Identificar ferramenta a envolver e proteção diferencial','', 'Oficina/componentes'),
20:('INCONCLUSIVA_VEICULO','Pasta de esmalte requer veículo/ligante não identificado; nenhum poder animal transferível','Confirmar veículo existente e uso distinto de pó seco','', 'Abrasivos'),
21:('VARIANTE_POTENCIAL','Régua linear é função válida; presa de mamute sem precisão especial demonstrada','Encontrar padrão de calibração independente; comparar régua comum','', 'Oficina/medição'),
22:('INCONCLUSIVA_DIFERENCIAL','Porta-amostras plana TEST existe; retenção/ciclos de dobradiça não demonstrados fisicamente','Verificar junta/fecho e comparação material real com recipiente comum','B30-02:RECURSO_FIBRA_NAO_RECEITA','Oficina/recipiente'),
23:('VARIANTE_POTENCIAL','Pino ósseo exige tolerância e resistência sem consumidor específico','Identificar encaixe real e medir força/folga','', 'Oficina/componentes'),
24:('REJEITAR_RECEITA_INDEPENDENTE_ATUAL','Amostragem morfológica de espinho é procedimento; não demonstrou produto transformado','Reusar protocolo de amostragem junto com B30-25; buscar uso material distinto','', 'PRE-Q1'),
25:('REJEITAR_RECEITA_INDEPENDENTE_ATUAL','Troca da origem do espinho não justifica segunda receita de amostragem','Compartilhar protocolo de referência com B30-24 sem fundir fichas','', 'PRE-Q1'),
26:('BLOQUEIO_MECANISMO','Essência de ovelha não demonstra aumento de tenacidade do chifre','Fonte de mecanismo/dose/segurança ou estudo controle; não herdar Investida','B30-08:COMPARADOR','PRE-Q1'),
27:('BLOQUEIO_VEICULO_EFEITO','Essência de carniceiro sem veículo ou prova de tinta de assinatura','Verificar suporte, veículo, estabilidade e atributo distinto com controle','B30-09:COMPARADOR','PRE-Q1'),
28:('REJEITAR_ALVO_BOTANICO_ATUAL','Rastreio de lobo não implica resposta vegetal','Abandonar alvo botânico até fonte canônica demonstrar afinidade planta; preservar PS','', 'PRE-Q1'),
29:('BLOQUEIO_EQUIVALENCIA','Essência de Tigre Flora não prova diferenciação perante Essência de Vida de Planta','Comparar assinatura/estabilidade com essência vegetal existente; não prometer poder','', 'PRE-Q1'),
30:('REJEITAR_RECEITA_INDEPENDENTE_ATUAL','Curva de estabilidade de essência é ensaio QA, não produto fabricado','Reusar protocolo transversal de estabilidade sem novo REC-ID','', 'PRE-Q1')}

portfolio=[]
for idx in range(1,31):
    pattern=rf'^### B30-{idx:02d} — (.+?)$'
    matches=list(re.finditer(pattern,text,re.M));assert len(matches)==1,(idx,len(matches))
    start=matches[0].start(); end=text.find('\n---',start)
    sect=text[start:end if end>=0 else None]
    ma=re.search(r'\[([^\]]+)\]\((https://app\.notion\.com/p/[a-z0-9]+)\)',sect);assert ma,idx
    verdict,block,next_step,dependency,family=D[idx]
    portfolio.append({'b30':f'B30-{idx:02d}','resource_name':ma.group(1),'resource_url':ma.group(2),
      'product_proposed':matches[0].group(1),'family':family,'preparation_historical':'PRE-Q1' if idx>=24 else 'PRE-Q2',
      'source_status':'historically_verified_PS__NOT_LIVE_REOPENED_FC09_FC18',
      'status_after':'DOCUMENTARY_DECISION_ONLY__'+verdict,
      'first_real_blocker':block,'specific_next_action':next_step,
      'source_dependencies_not_product_recipes':dependency.split('|') if dependency else [],
      'new_official_rec_id':None,'rc5_official':False,'rc5_technical_verified':False,
      'evidence_provenance':'B30 dossier R42/R43/FC01-08 history; decision scoped to existing accessible evidence',
      'last_test':'FC09 B30-04 R44 test' if idx==4 else 'historical FC01-08 or none'})
assert len({x['resource_url'] for x in portfolio})==30
assert sum(x['preparation_historical']=='PRE-Q2' for x in portfolio)==23
out('outputs/FC17_portfolio_30.json',{'schema':'FC17-INDIVIDUAL-30-v1','scope':'DOCUMENTARY_DECISIONS_NO_NOTION_WRITES','denominators':{'resources':30,'PRE_Q2':23,'PRE_Q1':7,'official_rc5':0,'covered':0,'official_products':0},'items':portfolio})

base_equations={'CTE':'CI + CP + CF + CT + CE + CK + CL + CA + CC',
 'CTE_unit':'CTE_batch / N_accepted iff N_accepted >0 else INDEFINITE',
 'CI':'physical source feed and unavoidable auxiliaries, actual unit costs PENDING',
 'CP':'incremental normal processing losses after no double count with CI',
 'CF':'incremental rejected-batch and rework costs, not counted again as input',
 'CT':'actual active and waiting labor × competent wage, PENDING',
 'CE':'sieves, weighing, wear, dust control, energy, amortization per batch, PENDING',
 'CK':'qualified operator and license/recipe knowledge cost, if applicable PENDING',
 'CL':'transport, source and route, PENDING',
 'CA':'storage, moisture management and protection, PENDING',
 'CC':'opportunity and capital costs, PENDING',
 'MED':'NOT CALCULATED; no real market/epoch/feed quality/source price',
 'economic_scenarios':{'favorable':'QA_PASS after first pass with measured approved yield','normal':'classification with extra dry time/reprocessing, costs measured separately','adverse':'no 250g approved output: CTE batch incurred, unit cost INDEFINITE'}}

recipe04={
 'schema':'FC09-RECIPE-COMPLETE-TEST-DESIGN-v1', 'candidate':'B30-04','state':'COMPLETE_EXECUTABLE_TEST_CONTRACT__NOT_RC5_CERTIFIED',
 'identity':'Fração grossa classificada de Areia de Brecha — unidade nominal de 250g; historical product alias Leito Abrasivo de Brecha',
 'physical_source':portfolio[3]['resource_url'],
 'product_function':'Entregar grãos minerais entre 0.20 e 1.00 mm por classificação e pesagem; nenhum rendimento nem desempenho abrasivo presumido.',
 'scope_limitation':'Se faltar dureza ou taxa de remoção, usar nome técnico de granulado classificado; não declarar desbaste superior.',
 'formula':'Lote tentado: 500g de areia bruta da fonte PS -> (QA aprovado e fração em faixa >=250g) uma carga 250g + frações restantes reconciliadas; em caso contrário zero carga qualificada e material em quarentena/rejeição com rastreio.',
 'bom':[{'node':'M01','quantity':500,'unit':'g','source':portfolio[3]['resource_url'],'role':'material alimentado','confidence':'PROPOSED_FC09_FC10_ORIGINAL_R42'},
        {'node':'TOOL01','unit':'kit reutilizável','role':'balança, duas peneiras delimitadoras 0.20 e 1.00 mm, recipiente não consumível, controle de pó','stock':'PENDING_IN_GAME'},
        {'node':'CONSUMABLE01','quantity':'consumo_real_por_lote','role':'material de proteção e desgaste, se houver','status':'PENDING_NOT_FREE'}],
 'process':[{'index':i,'action':action,'input_or_output':role,'time':tm} for i,(action,role,tm) in enumerate([
   ('identificar origem, lote e massa','M01; separar lotes desconhecidos','t_identificacao'),
   ('secar e pesar umidade removida','água evaporada registrada, não convertida em areia','t_secagem'),
   ('peneirar a 1.00 e 0.20 mm','fração dentro da faixa, finos e grossos identificados','t_peneira'),
   ('separar impurezas, isolar poeira/resíduos','não duplicar rejeitos nem contabilizá-los como insumo grátis','t_triagem'),
   ('pesar fração em faixa e medir QA','se aprovado reservar 250g, excedente continua fração própria','t_QA'),
   ('liberar TEST ou quarentenar','1 carga nominal ou zero; sob direitos PS/JIT não liberar jogo','t_liberacao')],1)],
 'QA_contract':{'mass':'m_accepted_250g exactly for pack, from a measured grade fraction >=250g','sieve_low_mm':0.20,'sieve_high_mm':1.00,
       'grain_grade':'fixture can assert range; real material requires calibrated sieves and inspection',
       'dry':'condição de secagem aceita e documentada por lote','impurity':'impurezas medidas e excluídas',
       'identity':'somente source_page_id original; offgrade não vira outro CRN','negative':'<250g QA grade -> 0 produtos; precheck <500g -> sem consumo',
       'measurement_uncertainty':'PENDING: accuracy, calibration, sieve selectivity and controls in world'},
 'mass_balance':{'equation':'m_feed=m_grade_delivered+m_grade_excess+m_coarse+m_fines+m_impurities+m_evaporated_water+m_capture_loss',
        'constraint':'all masses nonnegative, same units, no double counting. No claim about in-world distribution',
        'fixture_success_g':{'feed':500,'grade_delivered':250,'grade_excess':0,'coarse':100,'fines':80,'impurities':30,'evaporated_water':35,'capture_loss':5},
        'fixture_failed_QA_g':{'feed':500,'grade_available':190,'coarse':145,'fines':90,'impurities':35,'evaporated_water':35,'capture_loss':5}},
 'tools':['balança de precisão compatível','peneiras 0.2 e 1.0 mm, calibradas','bandeja reutilizável, contenção','proteção respiratória e ocular quando cabível'],
 'knowledge':{'generic':'preparo e classificação mineral; não há prova de artesão no cenário','actual_character_knows':False,'status':'PENDING'},
 'safety':['poeira mineral de composição desconhecida','não inalar nem aplicar sobre superfícies sem teste de compatibilidade','resíduos úmidos/impurezas segregados','sem efeitos sobrenaturais'],
 'time':{'formula':'t_identificacao+t_secagem+t_peneira+t_triagem+t_QA+t_liberacao+t_retrabalho','actual':'UNKNOWN','fixed_proposed':'NONE_NEW','reason':'R42 não fornece duração B30-04'},
 'yield':{'mass_approved_fraction':'m_grade_accepted/m_feed (quando m_feed>0)','pack_count':'floor(m_grade_accepted/250g) se todas unidades QA; nesta receita/TEST no máximo uma carga por 500g','field_yield':'UNKNOWN','success_probability':'UNKNOWN','target_250g':'PROPOSED design, not guaranteed'},
 'lineage':{'no_verified_physical_base':True,'new_first_generation_candidate':True,'anti_duplicate':'must reconcile exact product/grade/process in REC-LIB and embedded formula before creating unique ID','status':'LIVE_ACERVO_NOT_SEARCHABLE_THIS_TURN'},
 'economy':base_equations,
 'in_game':{'available_inventory':False,'procedure_known_to_player':False,'f5_writer':False,'actual_item_fabricated':False},
 'technical_remaining':['one canonical QA grade/proc competence or scoped authorial acceptance','source-compatible tools, knowledge/time and energy','actual yield and economic cost basis or authorized conditional treatment','anti-duplicate physical recipe search in competent REC-LIB'],
 'official_remaining':['fencing and C19 unknown effect','valid writer claim','REC-LIB unique parent','NAC-PASS and readback'],
 'gates':{'RC2':'PASS_DOCUMENTAL_PROPOSED_QUANTITIES','RC3':'PASS_DOCUMENTAL_PROCESS','RC4':'PARTIAL__TEST_ONLY_TIMING_MATERIAL_PENDING','RC5':'HOLD_SOURCE_ECONOMY_AUTHORITY','REC_ID':'NULL'}
}
out('contracts/B30-04-RECEITA-COMPLETA-TEST.json',recipe04)

recipe17={
 'schema':'FC11-SECOND-RECIPE-DESIGN-v1','candidate':'B30-17','source':portfolio[16]['resource_url'],
 'identity':'Fração fina classificada da Granada Abrasiva de Escarpa','state':'COMPLETE_DESIGN_CONTRACT_NOT_RC5',
 'purpose':'Fração seca 0.10<=d<0.20 mm; sem desempenho lapidador garantido.',
 'BOM':[{'id':'M01','source':portfolio[16]['resource_url'],'quantity':150,'unit':'g','status':'PROPOSTO'},
        {'id':'TOOLS','role':'britador/moinho, peneiras graduadas, balança, contenção, proteção','availability':'NOT_VERIFIED'},
        {'id':'COOLANT/VEHICLE','applicable':False,'reason':'produto é fração SECA sem pasta; nenhum ingrediente novo'}],
 'process':['identificar fonte+pesar','remover contaminantes identificáveis','britar/moer e rastrear massa','peneirar grau fino 0.10<=d<0.20mm',
     'reprocessar grosso opcionalmente, debitando tempo/energia/perdas e nunca material criado','inspecionar grau e quarentena',
     'liberar massa fina aceita m>=0; não prometer 100g'],
 'QA':['lote e fonte','massa de fração fina e balanço completo','limites de grão propostos','impurezas e compatibilidade com material-alvo','desempenho abrasivo ainda sem evidência'],
 'output':'m_fine_approved g; alvo histórico 100g somente PROPOSTO, não obrigação garantida',
 'yield':'q=m_fine_approved/150g no lote conhecido; p_qa separado; ambos desconhecidos in-world',
 'time':'t_ident+t_tritura+t_peneira+t_reprocesso+t_QA, todos tempos reais PENDENTES',
 'faults':['pó/mineral incompatível','fração não atingida','contaminação','dupla contagem de recirculação','lote sem aprovação'],
 'economy':base_equations,'skill':'preparador mineral e metrologia de peneiramento, presença in-world PENDENTE',
 'lineage':'sem base física comprovada, mas ausência não obriga derivar; candidatura independente se processo efetivamente diferente e ausência equivalente reconciliada',
 'mechanical_effect':'NONE','in_game':'DENY','rc5':'HOLD process tools source, efficacy scope, knowledge, CTE, anti-duplicate, PS/JIT',
 'historical_TEST':'FC08 causal trace audit 13/13; no rerun needed'}
out('contracts/B30-17-SEGUNDA-RECEITA.json',recipe17)

recipe13={
 'schema':'FC11-THIRD-RECIPE-DESIGN-v1','candidate':'B30-13', 'source':portfolio[12]['resource_url'],
 'identity':'Mistura não mágica de húmus de agulhas frias e areia bruta classificada por fonte — substrato experimental',
 'state':'COMPLETE_DESIGN_CONTRACT_NOT_RC5',
 'BOM':[{'id':'M01','source':portfolio[12]['resource_url'],'volume':750,'unit':'mL_nominal_measured','role':'matéria orgânica potencialmente germinativa','availability':'UNKNOWN'},
        {'id':'M02','source':portfolio[3]['resource_url'],'volume':250,'unit':'mL_nominal_measured','role':'fração mineral, NÃO depende de B30-04 receita','availability':'UNKNOWN'}],
 'output':'Mistura com volume final V_final medido, NÃO presumir V_final=1000mL por soma pré-mistura',
 'process':['identificar duas fontes PS brutas e lotes','inspecionar material orgânico e contaminação','medir 750mL e 250mL na mesma convenção volumétrica',
            'misturar em recipiente reutilizável, registrar perda e compactação','inspecionar lotes segregados/contaminação e volume final','liberar como MISTURA somente, sem germinação garantida'],
 'qa':['fontes originais','volume dos componentes na mesma escala','homogeneidade observacional (método ainda precisa autoridade)','pH/umidade/segurança das sementes PENDENTES','germinação em controle NÃO DEMONSTRADA'],
 'yield':'V_final = V_humus+V_areia - Delta_volume_de_compactacao - perdas; Delta desconhecido; q_emp depende QA real',
 'knowledge':'horticultor/preparador de substrato, disponibilidade no RPG não verificada',
 'tools':'medidas de volume, misturador, bandeja, proteção orgânica; presença no RPG PENDENTE',
 'time':'t_triagem + t_mistura + t_QA + eventual t_espera; sem números observados',
 'faults':['contaminação microbiológica','pH/umidade prejudicial','mistura heterogênea','compactação alterar volume','coleta ambiental inadequada'],
 'mechanical_effect':'NONE; não concede crescimento mágico ou sucesso de germinação',
 'economy':base_equations,'lineage':'variável/primeira geração pendente pesquisa de substrato comum, não uma duplicação presumida',
 'in_game':'DENY','RC5':'HOLD identificação qualificada/necessidade funcional, operador, qualidade, rendimento/custo e anti-duplicata'}
out('contracts/B30-13-TERCEIRA-RECEITA.json',recipe13)

abrasive={
 'schema':'FC12-LINEAGE-ABRASIVE-v1','basis':'local archival evidence only; no live Notion authoritative lineage readback',
 'family_nodes':[
 {'id':'B30-04','product':'coarse mineral grade','process':'dry/sieve, without mandatory grinding','material':portfolio[3]['resource_url'],
   'scope':'0.20-1.00mm design, no proven abrasivity','lineage':'candidate first generation or grade variant; existing recipe unknown'},
 {'id':'B30-17','product':'fine mineral grade','process':'grind/mill/sieve/regrind','material':portfolio[16]['resource_url'],
   'scope':'0.10<=d<0.20mm design, no proven superiority','lineage':'materially distinct PROCESS, possible S2 if qualified base discovered; no base assumed'},
 {'id':'B30-20','product':'paste candidate','process':'requires formulated carrier/viscosity, unknown','material':portfolio[19]['resource_url'],
   'scope':'not a dry powder substitute without new BOM','lineage':'HOLD missing compatible carrier'}],
 'not_inferred':['granular grade -> relative hardness','regional source -> unique recipe','paste -> stable abrasive without vehicle','side fraction -> resource CRN transformation'],
 'anti_double_count':'every fraction preserves original CRN identity and lot; regrind is same source, not new feed',
 'family_verdict':'B30-04 and B30-17 separate design/process candidates; REC-LIB first-generation vs S2 pending physical base search. B30-20 blocked.'}
out('outputs/FC12_family_abrasive.json',abrasive)

# Source-ID cross-links are not recipe/stock dependencies.
graph={'B30-13':{'input_resource_of_B30-04':True,'requires_processed_B30_04_product':False},
       'B30-16':{'input_resource_of_B30-11':True,'requires_fired_seal_B30_11':False},
       'B30-22':{'input_resource_of_B30-02':True,'requires_manufactured_cord_B30_02':False},
       'B30-01':{'needs_generic_abrasive_tool':True,'requires_B30-04_or_B30-17':False},
       'B30-17':{'requires_B30-04_base_recipe':False,'remilling_preserves_same_CRN':True},
       'B30-24+25':{'candidate_shared_protocol':True,'two_separate_material_PS_sources':True,'two_recipe_ids_earned':False},
       'B30-30':{'is_QA_method_not_material_product':True},
       'B30-07+B30-09':{'pigment_powder_plus_feather_is_ready_ink':False}}
out('outputs/FC16_dependency_graph.json',{'schema':'FC16-DEPENDENCIES-v1','cross_refs':graph,'new_resources_created':0,'canonical_links_modified':0,
      'anti_cycle':'resource intake does not require manufacture of different B30 recipe unless explicitly source-verified'})

admission={'candidate':'B30-04','verdict':'EXECUTABLE_TEST_CONTRACT__RC5_TECH_HOLD__RC5_OFFICIAL_HOLD',
 'gates':[
   {'requirement':'product identity and origin PS','status':'PASS_ARCHIVAL','basis':'B30 dossiê R42 PS source, no live re-open'},
   {'requirement':'BOM units/quantities','status':'PASS_PROPOSED','basis':'500g raw resource, 250g target, tools not consumed'},
   {'requirement':'BOM↔stages and batch','status':'PASS_TEST_ONLY','basis':'R44 receipt + explicit sidecar balances'},
   {'requirement':'QA scope','status':'PASS_DESIGN','basis':'grade and mass measured only in synthetic fixture; effectiveness excluded'},
   {'requirement':'physical material qualification','status':'HOLD_SOURCE_OR_AUTHORITY','basis':'no actual PS feed distribution, suitability, instrument calibration or batch provenance observed in world'},
   {'requirement':'time, conditions and operator','status':'HOLD_SOURCE_OR_AUTHORITY','basis':'recordable variables exist but no authorized durations, personnel or workshop verified'},
   {'requirement':'yield/failures','status':'PASS_MODEL_HOLD_ACTUAL','basis':'conditional 0 or 1 pack; field q/p unknown; TEST failures verified'},
   {'requirement':'material benefit and nonredundancy','status':'HOLD_SOURCE','basis':'grade product distinct from raw ungraded feed, but existing recipe and abrasivity alternatives unchecked live'},
   {'requirement':'economic UTE/CTE','status':'HOLD_APPLICABLE','basis':'CTE components modeled, prices, actual yield and market/epoch missing'},
   {'requirement':'knowledge and recipe discovery','status':'HOLD_SOURCE','basis':'generic skill specified; no in-world artisan or character knowledge proven'},
   {'requirement':'semicanon PS and JIT','status':'HOLD_PRODUCTION','basis':'PS valid for source identification not stock or campaign use'},
   {'requirement':'writer/fencing REC-LIB & NAC-PASS','status':'HOLD_PRODUCTION','basis':'F5 RED, C19 UNKNOWN, IBX gates unchanged, no actor transferred'}],
 'technical_rc5':False,'official_rc5':False,'physical_product':False,
 'minimal_nonadmin_path':['Scoped authoritative acceptance of coarse grade as intended nonmagical material product, not abrasion buff.',
  'Locate single competent base in REC-LIB+embedded formulas or attest proportional discovery with link/provenance.',
  'Verify compatible equipment/trained producer and timing/yield/cost basis or authorize conditional economic treatment under competent norm.',
  'Material context JIT then RC5 technical gate with NAC-PASS.'],
 'administrative_path':['Coordinator reconciles C19-021 effects, writer exclusivity/fencing via existing IBX-38.',
  'Verify unique physical parent via IBX-78/REC-LIB and anti-duplicate key.',
  'Documented ANTES, reserved writer, minimal commit, reopen and readback, DEPOIS, NAC-PASS; no Party data.']}
out('outputs/FC10_RC5_B30_04.json',admission)

# Preliminary documentary write-set only, no generated official identifiers.
dryrun={'schema':'FC17-DRYRUN-ONLY-v1','operation':'OP-ARQ-RIN-REC-01','NO_NOTION_WRITE':True,'writer':'NONE',
 'destination_parent':'PENDING_IBX78','official_rec_id':None,'new_product_id':None,'intended_source':portfolio[3]['resource_url'],
 'candidate_alias':'B30-04 coarse classified Brecha','logical_uniqueness_key':'(product grade+source CRN+version/lineage) pending REC-LIB search',
 'steps':['ANTES read source and target','fencing and writer gate','confirm no base-equivalent','reserve unique key','create ONE recipe in legitimate parent','create/link item only with competent authority','reopen source+recipe+product and verify reciprocal links','DEPOIS/diary/NAC-PASS'],
 'disabled_when':['F5_RED','C19_UNKNOWN_EFFECT','IBX38_FENCING_NOT_VERIFIED','IBX78_PARENT_NOT_VERIFIED','RC5_TECH_HOLD']}
out('outputs/FC17_publication_dryrun.json',dryrun)

# one explicit checkpoint for each requested stage, values are tangible; not pretending all green
stages=[
 ('FC09','B30-04 first concrete contract, candidate selection and BOM/process','contracts/B30-04-RECEITA-COMPLETA-TEST.json','DONE_EXPERIMENTAL_NOT_RC5'),
 ('FC10','R44 historical engine driven with new B30-04 recipe; success, preflight negative, QA negative, replay, restart','outputs/r44_B30_04/r44_executed_receipts.json','DONE_TEST_ONLY'),
 ('FC11','Second and third design contracts with own BOM/QA/economics: B30-17 and B30-13','contracts/B30-17-SEGUNDA-RECEITA.json','DONE_DESIGN_HOLD_RC5'),
 ('FC12','Family abrasive: coarse fine paste, independent / derivative status pending source','outputs/FC12_family_abrasive.json','DONE_SCOPED_DECISION'),
 ('FC13','Equipment, mounts and containers individualized in 30-source portfolio','outputs/FC17_portfolio_30.json','DONE_DOCUMENTARY'),
 ('FC14','Other mineral, ceramic, agricultural, conservation items classified individually','outputs/FC17_portfolio_30.json','DONE_DOCUMENTARY'),
 ('FC15','Seven PRE-Q1 each decided, no artificial filler formulas','outputs/FC17_portfolio_30.json','DONE_DOCUMENTARY'),
 ('FC16','Interdependencies and circular-source errors reconciled','outputs/FC16_dependency_graph.json','DONE_DOCUMENTARY'),
 ('FC17','30/30 portfolio status, official denominator 0 and disabled publication dry-run','outputs/FC17_publication_dryrun.json','DONE_DRYRUN_ONLY'),
 ('FC18','Hash manifest and checkpoint package; no canonical write','outputs/FC18_succession.json','DONE_LOCAL_ONLY')]
out('outputs/FC18_succession.json',{
 'as_of':'2026-10-16','operation':'CM-000002 / WS0001 / OP-ARQ-RIN-REC-01',
 'baseline':'R01–R51, FC01–FC08 untouched, v03 and FC08 SHA preserved',
 'last_verified_unit':'R44 B30-04 restarted snapshot and 3-event hash ledger + FC09-18 clean manifest, after verifier',
 'first_pending':'B30-04 qualified source grade/known equipment/operator and proportional REC-LIB anti-duplicate readback',
 'official_denominators':{'ps_originals':30,'pre_q2':23,'pre_q1':7,'rc5_physical_REC_IDs':0,'rc5_resources_covered':0,'official_product_occurrences':0},
 'local_denominators':{'candidate_executable_in_R44_TEST':1,'candidate_design_contracts':3,'candidate_rc5_eligible':0,'portfolio_individual_decisions':30,'PRE_Q1_decisions':7},
 'notion':'connection link_id must identify eligible linked account; ZERO live pages reopened, ZERO writes',
 'authority':{'F5':'RED historical','C19_021':'UNKNOWN_EFFECT','writer':'NONE','IBX38':'pending fencing','IBX78':'pending physical destination'},
 'unknown_effect':['C19-021 unverified','FC04 synthetic orphan untouched'],
 'conflicts':['B30-04 grade classification does not prove real abrasive effectiveness','B30-17 fine grade process difference does not prove higher hardness','B30-13 volume inputs do not guarantee 1 litre final','B30-24/25 and B30-30 are procedures rather than novel product recipes'],
 'no_repeat':['do not rerun R44–R48 historic tests','do not modify FC01–FC08 stores or archived R48 draft','do not repeat 30-source inventory','do not create official REC-IDs while blocked'],
 'next_5':['Confirm live Notion source and valid linked account via authorized connection','Search actual REC-LIB abrasive generic recipe and embedded historical function; reconcile candidate B30-04 first',
   'Verify material QA, producer/tools and process parameter authority for B30-04; then economic UTE/CTE',
   'If B30-04 cannot be qualified, B30-17 fine and B30-13 nominal blend remain separate conditional contracts',
   'Coordinator resolves C19/fencing and unique destination; if all RC5+writer gates pass, one idempotent canonical write/readback'],
 'nac_pass_02':{'synthetic_integrity':'PENDING_SELF_VERIFY_THEN_PASS','material_rc5':'HOLD','canonical_write':'HOLD'},
 'resume':'outputs/FC10_RC5_B30_04.json --> first HOLD_SOURCE_OR_AUTHORITY; then outputs/FC17_portfolio_30.json',
 'stages':[{'id':k,'work':description,'evidence':e,'state':s} for k,description,e,s in stages]})

print(json.dumps({'portfolio_count':len(portfolio),'q1':sum(x['preparation_historical']=='PRE-Q1' for x in portfolio),'written_contracts':3,'stages':len(stages)}))
