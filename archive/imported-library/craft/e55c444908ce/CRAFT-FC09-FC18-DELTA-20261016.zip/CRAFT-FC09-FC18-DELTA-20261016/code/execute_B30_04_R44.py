#!/usr/bin/env python3
"""FC09/10: run one actual R44 engine with one new TEST recipe; never alters v03.

Usage: python code/execute_B30_04_R44.py --baseline /path/CRAFT-COMESTRE-CHAT-v03.zip --output outputs/r44_B30_04
No Notion access and no real world item/stock writes.
"""
import argparse, importlib.util, json, hashlib, pathlib, tempfile, zipfile
from decimal import Decimal

PREFIX='CRAFT-COMESTRE-CHAT-v03/Oficina-v02/CRAFT-R48-SANDBOX-I0016/legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016/'
EXPECTED_V03_SHA='5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434'
SOURCE='3f3c2b32-4ede-816f-9af4-fdd6758bbe6c'

def canon(o): return json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def sha(o): return hashlib.sha256(canon(o).encode()).hexdigest()
def write(path,obj):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

def fractions(accepted,coarse,fine,impurities,water,lost,feed=500):
    f={'feed_g':feed,'accepted_grade_g':accepted,'coarse_g':coarse,'fines_g':fine,'impurities_g':impurities,'water_evaporated_g':water,'dust_and_loss_g':lost}
    vals=list(f.values()); assert all(type(x)==int and x>=0 for x in vals)
    assert sum(vals[1:])==feed, 'MASS_NOT_RECONCILED'
    return {**f,'mass_balance_error_g':feed-sum(vals[1:]),'all_fractions_are_TEST':True}

def measures(f,accepted=True):
    return {'accepted_mass_g':f['accepted_grade_g'],'min_grain_mm':0.2,'max_grain_mm':1.0,
            'grade_sampling_plan_accepted':True,'mass_balance_error_g':f['mass_balance_error_g'],
            'dry_state_accepted':True,'impurities_reconciled':True,'origin_preserved':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    base=pathlib.Path(a.baseline);out=pathlib.Path(a.output)
    assert hashlib.sha256(base.read_bytes()).hexdigest()==EXPECTED_V03_SHA,'HISTORIC_BASELINE_SHA_MISMATCH'
    root=pathlib.Path(__file__).resolve().parents[1]; rec=json.loads((root/'contracts/B30-04-R44-TEST.json').read_text())
    assert rec['official_rec_id'] is None and rec['source_page_id']==SOURCE
    with zipfile.ZipFile(base) as z:
        modsource=z.read(PREFIX+'experimental_engine.py')
        assert z.testzip() is None
        with tempfile.TemporaryDirectory(prefix='craft_fc09_r44_') as d:
            path=pathlib.Path(d)/'experimental_engine.py';path.write_bytes(modsource)
            spec=importlib.util.spec_from_file_location('craft_r44_fc09_isolated',path)
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            recmap={rec['key']:rec}; tools=rec['tools'];skills=rec['skills']
            fsuccess=fractions(250,100,80,30,35,5)
            fnegative=fractions(190,145,90,35,35,5)
            def lot(id,qty):return {'lot_id':id,'fixture_kind':'SYNTHETIC','source_page_id':SOURCE,'unit':'g','quantity':qty,'cracked':False,'delaminated':False,'contaminated':False}
            fx=module.SandboxEngine(recmap,[lot('SBX-FC09-SAND-GOOD',1000),lot('SBX-FC09-SAND-LOW',400)])
            success=fx.run(rec['key'],'SBX-FC09-B30-04-OK',['SBX-FC09-SAND-GOOD'],measures(fsuccess),tools,skills)
            assert success['status']=='EXPERIMENTAL_QA_PASS' and len(success['products'])==1
            assert success['consumed'][0]['quantity']==500 and success['inventory_after']['SBX-FC09-SAND-GOOD']==500
            # Preflight negative: insufficient synthetic inventory MUST NOT be decremented.
            nofeed=fx.run(rec['key'],'SBX-FC09-B30-04-NOFEED',['SBX-FC09-SAND-LOW'],measures(fsuccess),tools,skills)
            assert nofeed['status']=='REJECTED_PRECHECK' and nofeed['consumed']==[] and nofeed['products']==[]
            # Physical lot QA failure is represented by quarantining the whole 500g TEST, never a usable product.
            badqa=fx.run(rec['key'],'SBX-FC09-B30-04-FAILQA',['SBX-FC09-SAND-GOOD'],measures(fnegative),tools,skills)
            assert badqa['status']=='REJECTED_QUALITY' and badqa['products']==[] and len(badqa['scrap'])==1
            assert badqa['inventory_after']['SBX-FC09-SAND-GOOD']==0
            replay=fx.run(rec['key'],'SBX-FC09-B30-04-OK',['SBX-FC09-SAND-GOOD'],measures(fsuccess),tools,skills)
            assert replay['idempotent_replay'] and replay['inventory_after']==success['inventory_after']
            assert len(fx.state['events'])==3
            audit=fx.audit();assert audit['ok'] and audit['verified_events']==3
            out.mkdir(parents=True,exist_ok=True)
            ss=out/'r44_snapshot.json';digest=fx.export_snapshot(ss)
            restored=module.SandboxEngine.restore(recmap,ss)
            assert restored.audit()['ok'] and restored.audit()['head_hash']==audit['head_hash']
            audit2=restored.audit()
            receipts={'kind':'R44_ORIGINAL_UNMODIFIED_WITH_NEW_RECIPE_FIXTURE',
                  'r44_module_sha256':hashlib.sha256(modsource).hexdigest(),
                  'historic_v03_sha256':EXPECTED_V03_SHA,
                  'recipe_sha256':sha(rec),'official_materialization':False,
                  'cases':[success,nofeed,badqa],'idempotent_replay':replay,
                  'material_fraction_sheets':[fsuccess,fnegative],
                  'engine_audit':audit,'restart_audit':audit2,
                  'snapshot_sha256':digest,
                  'LIMITS':['R44 TEST output stores a 250g target as one unit, not physical sand.','The R44 core tracks stock but not reusable residue fractions on PASS; sidecar tracks them.','No real sieving was performed.','R47 verification and official economics not claimed.']}
            write(out/'r44_executed_receipts.json',receipts)
            print(json.dumps({'success':success['status'],'no_feed':nofeed['status'],'bad_QA':badqa['status'],'events':3,'restored':audit2['ok'],'hash':audit2['head_hash']}))
if __name__=='__main__':main()
