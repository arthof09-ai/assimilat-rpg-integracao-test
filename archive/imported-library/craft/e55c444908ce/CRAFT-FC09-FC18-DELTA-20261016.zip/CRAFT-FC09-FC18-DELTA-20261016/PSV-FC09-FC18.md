# PSV — CM-000002 / WS0001 / OP-ARQ-RIN-REC-01 / FC09–FC18

**AS-OF:** 16/10/2026 · **AMBIENTE:** MESTRE-SIDE · **BASELINE:** R01–R51 e FC01–FC08 intactos.

**LAST-VERIFIED-UNIT:** R44 original rodou a B30-04 em loja 100% sintética: 1 PASS, 1 rejeição antes de consumo, 1 QA reprovado, replay idempotente, snapshot recuperado. Os recibos preservam hash HEAD; `verify_FC09_FC18.py` reavalia cadeia e saldos independentemente. FC08 ZIP/hash autenticado, sem testes históricos repetidos.

**PRIMEIRA RECEITA:** B30-04, **fração grossa classificada de Areia de Brecha**. Uma entrada **PROPOSTA** de 500g de material PS, com secagem, classificação em 0,20–1,00mm e alvo **PROPOSTO** de 250g. Equações, quantidade, papel, processo, QA, resíduos, ferramentas e operador previstos no contrato `contracts/B30-04-RECEITA-COMPLETA-TEST.json`. Sem poderes mágicos nem abrasividade superior presumida.

**FC10 TEST:** PASS de uma carga 250g, REJECTED_PRECHECK por estoque, REJECTED_QUALITY por 190g conforme fixture; registro R44 de três eventos, restart/replay auditado. Em caso de QA reprovado R44 coloca a entrada sintética sob descarte; isso **não é receita de reciclagem material** e não prediz desperdício real. Em êxito, rastreio de finos/grossos/umidade/impurezas em folha separada: não confundir sidecar com subproduto nativo R44.

**RC5 B30-04:** HOLD. A execução sintética mostra uma fórmula experimental operável, mas não verifica grãos, dureza, rendimento e custos do mundo. O tempo é variável condicionada, não número inventado. Falta anti-duplicata física REC-LIB, ferramentas/operador qualificados, economia UTE/CTE e condições PS/JIT. Falta writer/fencing C19 para publicação, independente da ciência.

**FC11:** B30-17 (fração fina com britagem/moagem e recirculação) e B30-13 (mistura de húmus+areia bruta sem afirmar 1L final ou germinação superior) desenvolvidas como contratos distintos e condicionais. **FC12:** família abrasiva distingue peneiramento grosso, moagem fina e B30-20 pasta sem veículo. **FC13–14:** oficina/montagem e demais famílias revisadas individualmente; contrato adicional de pré-mistura seca B30-16, sem afirmar corpo cerâmico queimado. **FC15:** sete PRE-Q1 individualizadas, com rejeição provisória de receitas que seriam apenas protocolo/QA. **FC16:** relações de RECURSOS brutos não se transformam em receitas intermediárias obrigatórias. **FC17:** 30 fichas/30 decisões documentais registradas, dry-run de publicação incapaz de executar. **FC18:** pacote delta e validação local.

**DENOMINATORS:** 30/30 fichas PS documentadas historicamente; 23 PRE-Q2 + 7 PRE-Q1; 4 contratos de desenvolvimento detalhado, 1 executado novo em R44 TEST; 30 decisões documentais de triagem (não 30 receitas); **0 RC5 técnica verificada, 0/30 RC5 oficiais, 0/30 fichas cobertas oficialmente, 0 produtos oficiais**.

**CONFLICTS:** classe de grão ≠ eficácia abrasiva; 250g TEST ≠ rendimento físico; mistura volumétrica ≠ volume final; rastreio da fonte B30-13 não depende de fabricar B30-04; amostras B30-24/25 e ensaio B30-30 não autorizam receitas múltiplas.

**UNKNOWN-EFFECT:** C19-021 e checkpoint órfão FC04 não reconciliados; sem alteração.

**AUTHORITY / WRITER STATE:** F5 RED, IBX-38/78 pendentes, Notion `link_id` inacessível, writer produtivo NÃO concedido, nenhum write-set oficial executado.

**NO-REPEAT:** R44–R48 originais, draft, checkpoint órfão e FC01–FC08 não alterados; regressões antigas não reexecutadas nesta rodada. Apenas nova execução B30-04 foi realizada.

**NAC-PASS-02 proporcional:** PASS TEST e integridade local após auditoria independente; HOLD RC5 técnico, autenticação canônica, promoção, publicação e Party.

**NEXT-5:** (1) reconectar leitura Notion autorizada; (2) identificar equivalentes físicos de classificação de areia no REC-LIB; (3) qualificar operador/ferramental, critérios do produto, tempo e rendimento B30-04; (4) fechar CTE aplicável sem preços inventados; (5) reavaliar RC5 técnico, e só depois writer/exclusividade/gate físico sob Coordenação.

**PONTO EXATO DE RETOMADA:** `outputs/FC10_RC5_B30_04.json` (`HOLD_SOURCE_OR_AUTHORITY`) → `outputs/FC17_portfolio_30.json`; não retornar à metrologia antiga nem refazer a fábrica.
