# CRAFT — Delta FC09–FC18 (MESTRE-SIDE)

**Operação existente:** CM-000002 / WS0001 / OP-ARQ-RIN-REC-01. **AS-OF:** 2026-10-16. Este pacote é uma continuação experimental/documental: **NÃO** é um novo motor, nova operação, publicação REC-LIB, fabricação in-game ou autorização de leitura Party.

## Artefatos que não foram alterados

- Baseline v03: `/mnt/data/craft_recovery/CRAFT-COMESTRE-CHAT-v03.zip`, SHA-256 `5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434`.
- FC08: `/mnt/data/CRAFT-FC08-DELTA-20261016.zip`, SHA-256 `992332c51411844517b4dbcaccd6ff1a754419872493d888effa6cd55cfeb23f`.
- Draft R48 `SBX-R48-BATCH-UI-2afb696406a6e839`, stores FC04/FC05 e checkpoint órfão permaneceram intactos.

## Recuperar a execução nova (Python 3, biblioteca padrão)

Na raiz deste delta:

```bash
python code/verify_FC09_FC18.py
python code/execute_B30_04_R44.py \
  --baseline /CAMINHO/CRAFT-COMESTRE-CHAT-v03.zip \
  --output /PASTA_VAZIA/PROVA_REEXECUTADA
```

A primeira chamada é **auditoria independente** de hashes, conservação de estoque, evento, recibo, idempotência e cobertura 30/30. A segunda **carrega o arquivo `experimental_engine.py` histórico R44 dos bytes autenticados do v03**, sem modificá-lo, e executa uma receita adicional B30-04 em store isolado. O v03 não está duplicado neste pacote; deve ser recuperado da Biblioteca anterior. O estado de saída TEST original foi preservado em `outputs/r44_B30_04/`.

**Recibos:** `outputs/r44_B30_04/r44_executed_receipts.json` contém um PASS, uma falha de estoque e uma falha de QA, idempotência e dois hashes de auditoria; `r44_snapshot.json` contém três eventos reabríveis. A R44 registra estoque e produto, mas **não contabiliza nativamente as frações residuais do lote aprovado**; elas ficam na folha de balanço acompanhante. Não interpretar essa folha como medição real.

## Receita prioritária

`contracts/B30-04-RECEITA-COMPLETA-TEST.json` é o contrato técnico detalhado. `contracts/B30-04-R44-TEST.json` é sua parametrização executável em sandbox R44. Quantidades 500 g / 250 g e faixa 0,2–1,0 mm são **PROPOSTAS históricas**, não observações em Assimilação. Não promete desempenho de desbaste.

Segundo e terceiro contratos: B30-17 e B30-13; quarto contrato exploratório: B30-16. Não foram promovidos RC5. `outputs/FC17_portfolio_30.json` individualiza os 30 recursos PS e suas pendências; não modifica as páginas originais.

## Limites e autoridade

- Notion conector falhou: `link_id must identify an eligible linked account`. Ausência de leitura nesta instância não demonstra ausência das páginas.
- F5 RED / C19-021 UNKNOWN-EFFECT / IBX-38 fencing / IBX-78 destino / writer não concedido.
- Nenhum recurso, item, receita, estoque, página Party ou O Primeiro foi escrito.
- `REC-ID` permanece `null`; **RC5 oficiais = 0/30**, cobertura = 0/30, produtos oficiais = 0.

**Primeira pendência:** reabrir e reconciliar receita histórica equivalente da família de areia/abrasivos, qualificar aplicação e ofício/equipamento/custo da B30-04; somente então reavaliar RC5. **NAC-PASS-02:** PASS local TEST/hashes condicionado à verificação; HOLD material, oficial e escrita.
