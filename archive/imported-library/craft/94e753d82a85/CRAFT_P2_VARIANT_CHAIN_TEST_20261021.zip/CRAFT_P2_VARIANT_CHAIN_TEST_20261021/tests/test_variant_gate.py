import copy,json,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from variant_gate import *
SRC=json.loads((ROOT/'data'/'source_transcription.json').read_text())['sources']
class VariantTests(unittest.TestCase):
    def test_master_authority(self):self.assertTrue(admissible_authority(SRC['P2_MASTER'],'master_recipe_decision'))
    def test_mirror_no_authority_o(self):self.assertFalse(admissible_authority(SRC['VEDACAO_O_MIRROR'],'master_recipe_decision'))
    def test_mirror_no_authority_p(self):self.assertFalse(admissible_authority(SRC['SELAMENTO_P_MIRROR'],'apply_recipe'))
    def test_mirror_comparison_ok(self):self.assertTrue(admissible_authority(SRC['VEDACAO_O_MIRROR'],'master_comparator'))
    def test_bad_action(self):
        with self.assertRaises(ValueError):admissible_authority(SRC['P2_MASTER'],'modify_party')
    def test_bom_counts(self):self.assertEqual(sum(quantities(SRC['P2_MASTER']['bom']).values()),11)
    def test_6_fixed_ingredients(self):self.assertEqual(len(quantities(SRC['P2_MASTER']['bom'])),6)
    def test_p2_salt_missing_from_process(self):self.assertIn('sal_de_geodo_santo',unresolved_steps(SRC['P2_MASTER'])['bom_missing_from_process'])
    def test_p2_salt_unexpected(self):self.assertIn('sal_de_geodo_encantado',unresolved_steps(SRC['P2_MASTER'])['process_not_in_bom'])
    def test_master_energies_missing(self):self.assertEqual(set(unresolved_steps(SRC['P2_MASTER'])['energy_candidates_missing_from_process']),{'pedra_da_luz','pote_essencia_magica'})
    def test_o_energies_missing(self):self.assertEqual(len(unresolved_steps(SRC['VEDACAO_O_MIRROR'])['energy_candidates_missing_from_process']),2)
    def test_p_no_energy(self):self.assertEqual(unresolved_steps(SRC['SELAMENTO_P_MIRROR'])['energy_candidates_missing_from_process'],[])
    def test_master_one_oil(self):self.assertEqual(quantities(SRC['P2_MASTER']['bom'])['oleo_de_vedacao'],1)
    def test_o_two_oil(self):self.assertEqual(quantities(SRC['VEDACAO_O_MIRROR']['bom'])['oleo_de_vedacao'],2)
    def test_selamento_one_oil(self):self.assertEqual(quantities(SRC['SELAMENTO_P_MIRROR']['bom'])['oleo_de_vedacao'],1)
    def test_iron_distinct(self):self.assertNotEqual(quantities(SRC['P2_MASTER']['bom']).get('po_de_ferro_de_meteoro'),quantities(SRC['VEDACAO_O_MIRROR']['bom']).get('po_de_ferro_do_espaco'))
    def test_same_image(self):self.assertTrue(report(SRC)['same_drawing_asset_across_master_and_mirror'])
    def test_same_image_not_authority(self):self.assertTrue(report(SRC)['gate']['mirrors_not_authorities'])
    def test_report_hold(self):self.assertEqual(report(SRC)['decision'],'HOLD_NO_APPLICATION')
    def test_source_scope(self):self.assertEqual(report(SRC)['source_scope'],'three_named_pages_only')
    def test_qty_diff_oil(self):self.assertIn({'ingredient':'oleo_de_vedacao','master':1,'comparator':2,'difference_master_minus_comparator':-1},normalized_bom_diff(SRC['P2_MASTER'],SRC['VEDACAO_O_MIRROR']))
    def test_qty_diff_metal(self):self.assertTrue(any(d['ingredient']=='po_de_ferro_do_espaco' and d['comparator']==1 for d in normalized_bom_diff(SRC['P2_MASTER'],SRC['VEDACAO_O_MIRROR'])))
    def test_salt_is_not_synonym(self):self.assertTrue(any(d['ingredient']=='sal_dos_espiritos' for d in normalized_bom_diff(SRC['P2_MASTER'],SRC['VEDACAO_O_MIRROR'])))
    def test_invalid_qty_bool(self):
        with self.assertRaises(ValueError):quantities([['a',True]])
    def test_invalid_qty_zero(self):
        with self.assertRaises(ValueError):quantities([['a',0]])
    def test_invalid_qty_float(self):
        with self.assertRaises(ValueError):quantities([['a',2.0]])
    def test_bad_bom_list(self):
        with self.assertRaises(ValueError):quantities('2xfoo')
    def test_empty_name(self):
        with self.assertRaises(ValueError):quantities([[' ',2]])
    def test_duplicate_qty_accumulates(self):self.assertEqual(quantities([['a',2],['a',3]]),{'a':5})
    def test_lot_false_none(self):self.assertFalse(qualify_lot(None))
    def test_lot_false_catalog(self):self.assertFalse(qualify_lot({'document_type':'catalog_page'}))
    def test_lot_false_recipe(self):self.assertFalse(qualify_lot({'document_type':'recipe_page','lot_id':'L1'}))
    def _valid_lot(self):return dict(lot_id='L1',source_document_url='https://app.notion.com/p/123',custodian='TEST',operator='TEST',quantity=2,qa_record_id='QA1',test_permit_id='T1',chain_of_custody='C1',kind='PHYSICAL_FINISHED_OIL',document_type='physical_lot_record',qa_pass=True,test_authorized=True)
    def test_valid_fixture_structural_only(self):self.assertTrue(qualify_lot(self._valid_lot()))
    def test_lot_requires_qa_true(self):
        a=self._valid_lot();a['qa_pass']='true';self.assertFalse(qualify_lot(a))
    def test_lot_requires_permit_true(self):
        a=self._valid_lot();a['test_authorized']=1;self.assertFalse(qualify_lot(a))
    def test_lot_requires_quantity_int(self):
        a=self._valid_lot();a['quantity']=True;self.assertFalse(qualify_lot(a))
    def test_lot_requires_custody(self):
        a=self._valid_lot();a.pop('chain_of_custody');self.assertFalse(qualify_lot(a))
    def test_lot_rejects_fake_kind(self):
        a=self._valid_lot();a['kind']='CATALOG';self.assertFalse(qualify_lot(a))
    def test_lot_rejects_fixture(self):
        a=self._valid_lot();a['document_type']='synthetic_fixture';self.assertFalse(qualify_lot(a))
    def test_energy_stage_missing(self):self.assertEqual(energy_selection(SRC['P2_MASTER'],'pedra_da_luz',{'pedra_da_luz':2})['reason'],'ENERGY_STAGE_MISSING')
    def test_energy_branch_bad(self):self.assertEqual(energy_selection(SRC['P2_MASTER'],'both',{})['reason'],'INVALID_BRANCH')
    def test_energy_bad_qty(self):
        a=copy.deepcopy(SRC['P2_MASTER']);a['energy_step_documented']=True;self.assertEqual(energy_selection(a,'pedra_da_luz',{'pedra_da_luz':True})['reason'],'ENERGIZER_LOT_INSUFFICIENT')
    def test_energy_double_branch(self):
        a=copy.deepcopy(SRC['P2_MASTER']);a['energy_step_documented']=True;self.assertEqual(energy_selection(a,'pedra_da_luz',{'pedra_da_luz':2,'pote_essencia_magica':2})['reason'],'DOUBLE_BRANCH_FORBIDDEN')
    def test_energy_select_2_conditional(self):
        a=copy.deepcopy(SRC['P2_MASTER']);a['energy_step_documented']=True;self.assertTrue(energy_selection(a,'pedra_da_luz',{'pedra_da_luz':2})['admitted'])
    def test_master_lost_rejected(self):
        a=copy.deepcopy(SRC);a['P2_MASTER']['authority']='MESTRE_ESPELHO_CONTEXT';
        with self.assertRaises(ValueError):report(a)
    def test_no_magic_in_report(self):self.assertFalse(report(SRC)['gate']['magic_observed'])
    def test_no_oil_lot_in_report(self):self.assertFalse(report(SRC)['gate']['oil_lot_record_schema_complete_UNVERIFIED'])
    def test_no_permit_in_report(self):self.assertFalse(report(SRC)['gate']['master_test_permit_documented_UNVERIFIED'])
    def test_no_operator_in_report(self):self.assertFalse(report(SRC)['gate']['operator_assignment_documented_UNVERIFIED'])
    def test_salt_still_blocks_even_if_other_gates(self):
        obs={'verified_finished_oil_lots':[self._valid_lot()],'qualified_operator_assigned':True,'master_test_permit':True}
        self.assertEqual(report(SRC,obs)['decision'],'HOLD_NO_APPLICATION')
    def test_energy_blocks_if_salt_solved(self):
        a=copy.deepcopy(SRC);a['P2_MASTER']['process'][2]=['sal_de_geodo_santo']
        obs={'verified_finished_oil_lots':[self._valid_lot()],'qualified_operator_assigned':True,'master_test_permit':True}
        self.assertEqual(report(a,obs)['decision'],'HOLD_NO_APPLICATION')
    def test_clean_hypothetical_does_not_claim_magic(self):
        a=copy.deepcopy(SRC);a['P2_MASTER']['process'][2]=['sal_de_geodo_santo'];a['P2_MASTER']['energy_step_documented']=True
        obs={'verified_finished_oil_lots':[self._valid_lot()],'qualified_operator_assigned':True,'master_test_permit':True}
        self.assertEqual(report(a,obs)['decision'],'AWAIT_INDEPENDENT_PHYSICAL_AND_MAGICAL_QA')
    def test_false_text_does_not_mark_operator_assigned(self):self.assertFalse(report(SRC,{'qualified_operator_assigned':'false'})['gate']['operator_assignment_documented_UNVERIFIED'])
    def test_false_text_does_not_mark_test_permit(self):self.assertFalse(report(SRC,{'master_test_permit':'false'})['gate']['master_test_permit_documented_UNVERIFIED'])
    def test_fake_magic_string_does_not_establish_observation(self):self.assertFalse(report(SRC,{'magic_observed':'true'})['gate']['magic_observed'])
    def test_no_party_write_apis(self):
        code=(ROOT/'code'/'variant_gate.py').read_text();self.assertNotIn('notion_update_page',code);self.assertNotIn('requests.post',code)
if __name__=='__main__':unittest.main(verbosity=2)
