from __future__ import annotations
import json
from collections import Counter
from pathlib import Path

MASTER = "MASTER_CANON_SOURCE"
MIRROR = "MESTRE_ESPELHO_CONTEXT"


def quantities(ingredients):
    out = Counter()
    if not isinstance(ingredients, list):
        raise ValueError("BOM_NOT_LIST")
    for line in ingredients:
        if not isinstance(line,(list,tuple)) or len(line)!=2:
            raise ValueError("MALFORMED_BOM_LINE")
        name,count=line
        if not isinstance(name,str) or not name.strip() or not isinstance(count,int) or isinstance(count,bool) or count<=0:
            raise ValueError("INVALID_BOM_VALUE")
        out[name]+=count
    return dict(out)


def admissible_authority(source, requested_action):
    if requested_action not in ("master_recipe_decision", "master_comparator", "apply_recipe"):
        raise ValueError("INVALID_ACTION")
    if not isinstance(source,dict):
        return False
    if source.get('surface') not in ('MESTRE_ONLY','MESTRE_ONLY_READ'):
        return False
    if requested_action=='master_comparator':
        return source.get('authority') in (MASTER,MIRROR)
    return source.get('authority')==MASTER and source.get('surface')=='MESTRE_ONLY'


def normalized_bom_diff(left,right):
    a,b=quantities(left['bom']),quantities(right['bom'])
    return [{'ingredient':k,'master':a.get(k,0),'comparator':b.get(k,0),'difference_master_minus_comparator':a.get(k,0)-b.get(k,0)} for k in sorted(set(a)|set(b)) if a.get(k,0)!=b.get(k,0)]


def unresolved_steps(record):
    bom=quantities(record['bom'])
    process=[name for stage in record['process'] for name in stage]
    missing=sorted(k for k in bom if k not in process)
    unexpected=sorted(k for k in process if k not in bom and k!='application')
    energy=[]
    opts=record.get('energy_alternative',[])
    for alt in opts:
        if len(alt)!=2 or not isinstance(alt[1],int) or isinstance(alt[1],bool) or alt[1]<=0:
            raise ValueError('INVALID_ENERGY_ALTERNATIVE')
        if alt[0] not in process: energy.append(alt[0])
    return {'bom_missing_from_process':missing,'process_not_in_bom':unexpected,'energy_candidates_missing_from_process':sorted(energy),'energy_step_documented':record.get('energy_step_documented')}


def energy_selection(record,selected,lot_quantities):
    opts=record.get('energy_alternative',[])
    if len(opts)!=2: return {'admitted':False,'reason':'NOT_DUAL_OPTION_RECIPE'}
    choices=dict(opts)
    if selected not in choices:return {'admitted':False,'reason':'INVALID_BRANCH'}
    if not isinstance(lot_quantities,dict):return {'admitted':False,'reason':'LOTS_INVALID'}
    if not record.get('energy_step_documented'):
        return {'admitted':False,'reason':'ENERGY_STAGE_MISSING'}
    if any(k in lot_quantities for k in choices if k!=selected):
        return {'admitted':False,'reason':'DOUBLE_BRANCH_FORBIDDEN'}
    n=lot_quantities.get(selected)
    if not isinstance(n,int) or isinstance(n,bool) or n<choices[selected]:
        return {'admitted':False,'reason':'ENERGIZER_LOT_INSUFFICIENT'}
    return {'admitted':True,'selected':selected,'quantity':choices[selected]}


def qualify_lot(lot):
    if not isinstance(lot,dict):return False
    required=['lot_id','source_document_url','custodian','operator','quantity','qa_record_id','test_permit_id','chain_of_custody']
    if not all(isinstance(lot.get(k),str) and lot[k].strip() for k in required if k!='quantity'):
        return False
    if not isinstance(lot.get('quantity'),int) or isinstance(lot.get('quantity'),bool) or lot['quantity']<=0:return False
    if lot.get('kind')!='PHYSICAL_FINISHED_OIL':return False
    if lot.get('document_type') in ('recipe_page','catalog_page','mirrored_recipe','synthetic_fixture'):return False
    if lot.get('qa_pass') is not True:return False
    if lot.get('test_authorized') is not True:return False
    return True


def _gate(sources, observation):
    master=sources['P2_MASTER']
    return {
      'master_source_selected':admissible_authority(master,'master_recipe_decision'),
      'mirrors_not_authorities':all(not admissible_authority(sources[n],'apply_recipe') for n in ('VEDACAO_O_MIRROR','SELAMENTO_P_MIRROR')),
      'salt_equivalence_unapproved':('sal_de_geodo_santo' in quantities(master['bom']) and 'sal_de_geodo_encantado' in unresolved_steps(master)['process_not_in_bom']),
      'missing_energy_stage':not bool(master.get('energy_step_documented')),
      'oil_lot_record_schema_complete_UNVERIFIED':any(qualify_lot(l) for l in observation.get('verified_finished_oil_lots',[])),
      'operator_assignment_documented_UNVERIFIED':observation.get('qualified_operator_assigned') is True,
      'master_test_permit_documented_UNVERIFIED':observation.get('master_test_permit') is True,
      'magic_observed':False,
    }


def report(sources,observation=None):
    if observation is None: observation={}
    p2=sources['P2_MASTER']
    if not admissible_authority(p2,'master_recipe_decision'):raise ValueError('MASTER_SOURCE_REJECTED')
    if sources['VEDACAO_O_MIRROR'].get('drawing_identity')!=p2.get('drawing_identity'):
        drawing_match=False
    else:drawing_match=True
    gates=_gate(sources,observation)
    return {
      'source_scope':'three_named_pages_only',
      'master_url':p2['source_url'],
      'authority':'MASTER_CANON_SOURCE_ONLY_P2',
      'mirror_comparators':[sources['VEDACAO_O_MIRROR']['source_url'],sources['SELAMENTO_P_MIRROR']['source_url']],
      'same_drawing_asset_across_master_and_mirror':drawing_match,
      'same_drawing_does_not_prove_same_formula':True,
      'p2_bom_to_process':unresolved_steps(p2),
      'vedacao_o_mirror_bom_to_process':unresolved_steps(sources['VEDACAO_O_MIRROR']),
      'diff_p2_vs_vedacao_o_mirror':normalized_bom_diff(p2,sources['VEDACAO_O_MIRROR']),
      'diff_p2_vs_selamento_p_mirror':normalized_bom_diff(p2,sources['SELAMENTO_P_MIRROR']),
      'gate':gates,
      'decision':'HOLD_NO_APPLICATION' if gates['salt_equivalence_unapproved'] or gates['missing_energy_stage'] or not(gates['oil_lot_record_schema_complete_UNVERIFIED'] and gates['operator_assignment_documented_UNVERIFIED'] and gates['master_test_permit_documented_UNVERIFIED']) else 'AWAIT_INDEPENDENT_PHYSICAL_AND_MAGICAL_QA',
      'notes':['Comparators originate in the Mestre Espelho, never authority for correction of the Mestre canonical recipe.','A matching drawing/image ID is not recipe equivalence, rank upgrade, lot, energy step, or observed magic.','No actor/stock/rank/item stats are synthesized.'],
    }


def main():
    src=Path(__file__).resolve().parents[1]
    recipes=json.loads((src/'data'/'source_transcription.json').read_text())['sources']
    obj=report(recipes)
    print(json.dumps(obj,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
