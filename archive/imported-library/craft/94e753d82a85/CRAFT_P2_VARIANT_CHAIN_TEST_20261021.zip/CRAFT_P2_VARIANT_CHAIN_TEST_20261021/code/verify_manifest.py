import json,hashlib,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'MANIFEST_SHA256.json').read_text())['sha256_by_relative_path']
actual={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.name not in ('MANIFEST_SHA256.json',) and '__pycache__' not in p.parts}
assert actual==m, {'unexpected':set(actual)-set(m),'missing':set(m)-set(actual),'mismatched':[k for k in set(m)&set(actual) if m[k]!=actual[k]]}
print('PASS_MANIFEST',len(m))
