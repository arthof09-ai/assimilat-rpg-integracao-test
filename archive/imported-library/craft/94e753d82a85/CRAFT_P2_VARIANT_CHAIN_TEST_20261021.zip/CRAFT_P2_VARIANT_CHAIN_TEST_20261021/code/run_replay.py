import subprocess,sys,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'],cwd=root,capture_output=True,text=True)
assert p.returncode==0,(p.stdout,p.stderr)
p=subprocess.run([sys.executable,'-B','code/variant_gate.py'],cwd=root,capture_output=True,text=True)
assert p.returncode==0,p.stderr
actual=json.loads(p.stdout)
expected=json.loads((root/'outputs'/'READONLY_GATE.json').read_text())
assert actual==expected,'OUTPUT_DRIFT'
p=subprocess.run([sys.executable,'-B','code/verify_manifest.py'],cwd=root,capture_output=True,text=True)
assert p.returncode==0,p.stderr
print('PASS_VARIANT_CHAIN_COLD_REPLAY',p.stdout.strip(),actual['decision'],'NO_MAGIC_NO_STOCK_NO_PARTY')
