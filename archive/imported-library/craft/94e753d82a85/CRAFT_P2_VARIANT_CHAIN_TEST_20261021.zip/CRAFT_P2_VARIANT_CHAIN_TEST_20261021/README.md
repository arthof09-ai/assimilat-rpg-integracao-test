# CRAFT P2 Variant Chain TEST — 2026-10-21

MESTRE-SIDE ONLY. Three named Notion documents are transcribed in data/source_transcription.json; this is not a global item or stock census. Execute `python -m unittest discover -s tests -v`; `python code/variant_gate.py`. Compare Mestre canonical P2 with two *Mestre Espelho* source variants read-only, without deriving authority from the Party mirror or an identical attached drawing. No writing or magical application.
