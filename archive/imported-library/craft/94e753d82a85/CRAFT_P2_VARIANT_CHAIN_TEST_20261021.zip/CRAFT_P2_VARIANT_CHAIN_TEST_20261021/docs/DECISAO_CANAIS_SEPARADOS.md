# Decisão de proteção de variante — Mestre-only

## Fatos VERIFICADOS por fetch dos documentos nomeados

1. Fonte Mestre: Inscrição de Vedação (P) (CG) → filha **Receita** P2: 3 Argila Elemental da Terra; 1 Água Benta; 2 **Sal de Geodo Santo**; 3 Pó de Ferro de Meteoro; 1 Essência Barreira; 1 Óleo de Vedação; 2 Pedra Luz **OU** 2 Potes Essência. Processo etapa 3 escreve **Sal de Geodo Encantado**; processo nenhuma etapa de energização. Uma unidade de óleo na BOM.
2. Espelho Mestre da Party: **Inscrição de Vedação (O) (CG)**, receita incorporada usa **2 Sal dos Espíritos**, **1 Pó Ferro Espaço**, **2 Óleo Vedação**, e **4** de uma das fontes energizantes. As origens, quantidades e ingrediente energético diferem. Esta fonte não está na árvore Mestre Itens e NÃO retifica P2 nem atualiza Party.
3. Espelho Mestre da Party: **Inscrição de Selamento (P) (CG)**, outra finalidade, **1 óleo**, 2 Argila Barreira/3 Sal Espíritos/2 Pó Quartzo Guardião, nenhum energizador explícito.
4. Mesmo ID do arquivo de desenho em Vedação P2 Mestre e Vedação O Espelho (fa582656-e0ca-4aee-bfb5-4c830fc864c8) não prova mesmo rank, receita, equivalência material ou versão. O identificador completo do bloco do arquivo pode variar entre pais; igualdade de identidade de mídia é apenas um sinal de reaproveitamento gráfico.

## Inferência delimitada

O risco de cruzamento é concreto: um preparador automático pode erroneamente corrigir P2 usando o Sal dos Espíritos, o ferro e 2x Óleo da outra variante, tomando a imagem igual como prova de compatibilidade. Isto é INFERIDO como falha possível, não observado na produção.

## Consequência executável em sandbox

Negar ingresso de receitas do Espelho Party como fonte de autoridade Mestre; comparar somente read-only. A correção de P2 SALT/ENERGY exige decisão Mestre/autoridade da receita original, preservando procedimento e lineage. Quantidades são especificação documental, não lotes adquiridos. Não chamar qualquer óleo da ficha/catálogo de lote físico. Uma condição positiva sintética no validador não libera execução, PA, estoque nem magia.

## Pedido competente existente

P2-SALT-01 e P2-ENERGY-02 estão solicitados na **IBX-116 existente**. NÃO abrir nova Inbox. Autoridade deve definir se Santo versus Encantado é errata ou versão distinta e autorizar/definir etapa de energização, consumo, observação. Pergaminho, operador, materiais e óleo continuam independentes. Ref: OP-ARQ-RIN-REC-01; LAB CRAFT; NAC-NORM-01; NAC-PASS proporcional.
