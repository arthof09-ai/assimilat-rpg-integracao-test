# Segurança, critérios e retomada

**TEST-only**: gate de proveniência da receita e consistência BOM-processo; controles sem utilização de estoque. `qualify_lot` avalia *formato de documentos hipotéticos*, jamais autentica existência real. Não atribuir eficácia a magia, rank ou preço. C19-021 UNKNOWN-EFFECT, F5 RED, RC5/P4/PROD HOLD. SOURCE_STABILIZED/ITEM_INTEGRATED NOT DEMONSTRATED.

**NAC-PASS**: somente testes digitais e confronto das três fontes nomeadas; HOLD aplicação H2-3A/B, retificação P2, lotes, operador, energia e magic witness.

**FIRST PENDING**: autoridade Mestre responde no objeto IBX-116 os dois itens P2 SALT/ENERGY. Em paralelo obter evidência objetiva de lote Óleo/insumos e operador; classificar variantes conforme parent-chain; testar aplicação quando autorizada. Não substitua isto por PA/R48 replays repetidos.
