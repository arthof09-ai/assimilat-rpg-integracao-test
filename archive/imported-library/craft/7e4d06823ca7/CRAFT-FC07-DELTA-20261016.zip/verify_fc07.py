#!/usr/bin/env python3
"""Independent FC07 readback, using only the standard library, from a clean extraction."""
import hashlib,json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
M=json.loads((BASE/'MANIFEST_SHA256.json').read_text())
errs=[]
for name,v in M['files'].items():
    f=BASE/name
    if not f.is_file():errs.append('MISSING '+name);continue
    h=hashlib.sha256(f.read_bytes()).hexdigest()
    if h!=v['sha256'] or f.stat().st_size!=v['bytes']:errs.append('MISMATCH '+name)
r=subprocess.run([sys.executable,str(BASE/'code/run_targeted_checks.py')],capture_output=True,text=True,cwd=str(BASE),check=False)
if r.returncode: errs.append('TARGET_TEST_ERROR:'+r.stderr[-500:])
else:
    expected=json.loads((BASE/'outputs/targeted_checks.json').read_text())
    actual=json.loads(r.stdout)
    if expected!=actual or actual['passed']!=actual['total']: errs.append('TEST_DIFFERENCE')
state=json.loads((BASE/'outputs/succession_checkpoint.json').read_text())
if state['denominators']['official_rc5_recids']['num']!=0 or state['authority']['writer']!='NOT_GRANTED':errs.append('UNSAFE_STATE')
print(json.dumps({'schema':'FC07-INDEPENDENT-READBACK-v1','ok':not errs,'manifest_files':len(M['files']), 'tests_passed':0 if r.returncode else actual['passed'], 'tests_total':0 if r.returncode else actual['total'], 'original_motors_modified':False,'errors':errs},ensure_ascii=False))
sys.exit(bool(errs))
