# CRAFT / FC07 — Recuperação e escopo

Operação preexistente `CM-000002 / WS0001 / OP-ARQ-RIN-REC-01` · MESTRE-SIDE · 16/10/2026.

## Natureza

Pacote delta técnico, somente aditivo e local; não cria motor, receita oficial, laboratório, inventário, Notion ou regra. Parte de `CRAFT-FC06-DELTA-20261016.zip` (SHA-256 `99b6be127ef56bbdae8f85b12b37b3ef09179b571ae359f5c8a0dbeee22e205e`). A fábrica R44–R48, o HEAD `cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708`, o draft `SBX-R48-BATCH-UI-2afb696406a6e839`, o órfão FC04 e os recibos históricos não foram modificados ou reexecutados.

## Evidência e força probatória

- `outputs/recovery_and_sources.json` — referências históricas, baseline FC06 verificada localmente, falha de conexão live Notion.
- `outputs/functional_decision_matrix.json` — juízo específico B30-03,17,04,01,21; A e D não são promoções RC5; nenhuma base física de receita comprovada nesta passagem.
- `outputs/rc5_candidate_B30_17.json` — pré-admissão B30-17 com BOM/etapas, classificação de custo, autoridade e menor gargalo.
- `code/abrasive_grade_gate.py` — verificador de fronteiras de *propostas* granulométricas e conservação de massa, preservando identidade de recurso PS. Não demonstra abrasividade real.
- `outputs/targeted_checks.json` — 17/17 testes novos TEST, sem chamadas ao motor de fábrica.
- `outputs/succession_checkpoint.json` — ponto exato de retomada, denominadores e NEXT-5.

## Executar e auditar

Em extração limpa, somente biblioteca padrão Python:

```
python code/run_targeted_checks.py
python verify_fc07.py
```

O primeiro executa 17 testes determinísticos. O segundo reexecuta testes e valida os hashes listados no manifesto contra os bytes na extração. Nenhum chama APIs nem escreve no Notion.

## Limites / governança

Notion `link_id must identify an eligible linked account` durante FC07. URLs canônicas foram recuperadas de dossiês anteriores, mas **0 páginas** reabertas live nesta passagem. Documentos locais ≠ autoridade canônica atualizada. Aplicar `NAC-CONT-03`, `NAC-NORM-01`, `REC-EXEC`, `PR-SC/JIT-SC`, `PR-ECO-01`, `REC-LIB-01` e `NAC-PASS-02` antes de qualquer admissão. F5 RED; C19-021 UNKNOWN_EFFECT; IBX-38 fencing e IBX-78 destino continuam sem prova de liberação. Nenhuma receita física, REC-ID, item de campanha ou conhecimento Player criado.
