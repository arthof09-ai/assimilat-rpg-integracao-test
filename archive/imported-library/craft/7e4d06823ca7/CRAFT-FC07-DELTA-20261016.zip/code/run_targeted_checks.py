#!/usr/bin/env python3
"""New focused FC07 checks. No historical engine/replay is invoked."""
import json,sys
from decimal import Decimal as D
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from abrasive_grade_gate import grade,classify_feed,cost_per_approved_unit
cases=[]
def check(name, expr):
    cases.append({'case':name,'pass':bool(expr)})
    if not expr: raise AssertionError(name)

check('fine low inclusive',grade('0.10')=='FINE_0p10_to_lt_0p20mm')
check('fine high exclusive, coarse inclusive',grade('0.20')=='COARSE_0p20_to_1p00mm')
check('coarse max inclusive',grade('1.00')=='COARSE_0p20_to_1p00mm')
check('reject below lower limit',grade('0.099')=='REJECT_OUT_OF_DESIGN_RANGE')
check('reject above upper limit',grade('1.001')=='REJECT_OUT_OF_DESIGN_RANGE')
feed17=classify_feed(150,[{'diameter_mm':'0.15','grams':60},{'diameter_mm':'0.50','grams':50}],40,True,material_source='B30-17_PS')
check('mass conservation illustrative mixed TEST',feed17['state']=='PASS_SYNTHETIC_CLASSIFICATION' and feed17['fine_25g_units']==2 and feed17['mass_g']['FINE_0p10_to_lt_0p20mm']=='60')
feed04=classify_feed(500,[{'diameter_mm':'0.50','grams':250},{'diameter_mm':'0.15','grams':100}],150,True,material_source='B30-04_PS')
check('B30-04 synthetic feed grade separation',feed04['state']=='PASS_SYNTHETIC_CLASSIFICATION' and feed04['mass_g']['COARSE_0p20_to_1p00mm']=='250')
check('reject impossible output exceeds input',classify_feed(150,[{'diameter_mm':'.15','grams':151}],0,True,material_source='B30-17_PS')['state']=='REJECT_MASS_NOT_CONSERVED')
check('reject unexplained missing waste',classify_feed(150,[{'diameter_mm':'.15','grams':60}],40,True,material_source='B30-17_PS')['state']=='REJECT_MASS_NOT_CONSERVED')
check('not approve unmeasured distribution',classify_feed(150,material_source='B30-17_PS')['state'].startswith('INDETERMINATE'))
check('not approve unchecked contamination',classify_feed(150,[{'diameter_mm':'.15','grams':100}],50,False,material_source='B30-17_PS')['state']=='INDETERMINATE_CONTAMINATION_QA')
check('no cost-per-approved when zero units',cost_per_approved_unit(42,0) is None)
check('conditional cost-per-approved arithmetic only',cost_per_approved_unit(42,2)==D('21'))
check('reject negative mass',classify_feed(150,[{'diameter_mm':'.15','grams':-1}],151,True,material_source='B30-17_PS')['state']=='REJECT_NEGATIVE_MASS')
check('zero of approved target is permitted',classify_feed(150,[{'diameter_mm':'0.50','grams':150}],0,True,material_source='B30-17_PS')['fine_25g_units']==0)
check('no automatic source identity change',feed17['source_id_preserved']=='B30-17_PS' and feed17['new_resource_product_id'] is None)
check('unidentified input cannot be treated as source',classify_feed(150,[{'diameter_mm':'.15','grams':150}],0,True)['state']=='REJECT_UNIDENTIFIED_INPUT_SOURCE')
output={'schema':'FC07-PROCESS-GRADE-CHECKS-v1','scope':'deterministic classification of proposed size ranges and accounting; NOT abrasion efficacy or regional material measurement', 'cases':cases, 'passed':sum(x['pass'] for x in cases),'total':len(cases),'fc04_r48_touched':False}
print(json.dumps(output,indent=2,ensure_ascii=False))
if len(sys.argv)>1: Path(sys.argv[1]).write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
