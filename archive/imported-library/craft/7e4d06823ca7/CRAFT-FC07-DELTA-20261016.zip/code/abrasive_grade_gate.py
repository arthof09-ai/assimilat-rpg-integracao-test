#!/usr/bin/env python3
"""FC07: independent dimensional/mass conservation gate (NOT the R44-R48 factory).
All sample lots are declared TEST. Does NOT model hardness, polishing, or economic prices.
"""
from decimal import Decimal as D

def to_d(x): return D(str(x))

def grade(diameter_mm):
    d=to_d(diameter_mm)
    if d<0: raise ValueError('negative grain size')
    if D('0.10')<=d<D('0.20'): return 'FINE_0p10_to_lt_0p20mm'
    if D('0.20')<=d<=D('1.00'): return 'COARSE_0p20_to_1p00mm'
    return 'REJECT_OUT_OF_DESIGN_RANGE'

def classify_feed(feed_g, measured_bins=None, reject_g=None, contamination_checked=False, material_source=None):
    """measured_bins: [{diameter_mm, grams}]; complete synthetic distribution for QA.
    Pass output requires QA of contamination; absent checks -> indeterminate.
    """
    feed=to_d(feed_g)
    if material_source not in ('B30-17_PS', 'B30-04_PS'):
        return {'state':'REJECT_UNIDENTIFIED_INPUT_SOURCE'}
    if feed<=0: return {'state':'REJECT_INVALID_FEED'}
    if measured_bins is None or reject_g is None:
        return {'state':'INDETERMINATE_MISSING_GRAIN_DISTRIBUTION_OR_LOSSES'}
    rejected=to_d(reject_g)
    if rejected<0: return {'state':'REJECT_NEGATIVE_MASS'}
    masses={'FINE_0p10_to_lt_0p20mm':D('0'), 'COARSE_0p20_to_1p00mm':D('0'), 'REJECT_OUT_OF_DESIGN_RANGE':D('0')}
    for item in measured_bins:
        q=to_d(item['grams'])
        if q<0: return {'state':'REJECT_NEGATIVE_MASS'}
        try: k=grade(item['diameter_mm'])
        except ValueError: return {'state':'REJECT_INVALID_DIAMETER'}
        masses[k]+=q
    total=sum(masses.values(),D('0'))+rejected
    if total!=feed: return {'state':'REJECT_MASS_NOT_CONSERVED','feed_g':str(feed),'accounted_g':str(total)}
    if not contamination_checked:
        return {'state':'INDETERMINATE_CONTAMINATION_QA','mass_g':{k:str(v) for k,v in masses.items()}}
    return {'state':'PASS_SYNTHETIC_CLASSIFICATION','feed_g':str(feed), 'source_id_preserved':material_source, 'new_resource_product_id':None,
            'mass_g':{k:str(v) for k,v in masses.items()},
            'reject_g':str(rejected),
            'fine_25g_units':int(masses['FINE_0p10_to_lt_0p20mm']//D('25')),
            'observed_real_material':False}

def cost_per_approved_unit(total_cost, units):
    if units<=0: return None
    return to_d(total_cost)/D(units)

if __name__=='__main__':
    import json
    print(json.dumps(classify_feed('150',[{'diameter_mm':'0.15','grams':'60'}, {'diameter_mm':'0.50','grams':'50'}],reject_g='40',contamination_checked=True,material_source='B30-17_PS'),ensure_ascii=False,sort_keys=True))
