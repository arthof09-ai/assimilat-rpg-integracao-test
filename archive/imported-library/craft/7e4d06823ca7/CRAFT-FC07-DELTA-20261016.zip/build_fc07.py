from pathlib import Path
import json,hashlib,zipfile,subprocess,sys
P=Path(__file__).parent
O=P/'outputs'
root='/mnt/data/'
def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def write(name,data):
    (O/name).write_text(json.dumps(data,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
known={
'B30-01':{'name':'Tábua Lamelar de Inscrição','source_name':'Ardósia de Geada Lamelar','url':'https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2'},
'B30-03':{'name':'Espaçador de Mica Calibrado','source_name':'Mica de Bruma Boreal','url':'https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84'},
'B30-04':{'name':'Leito Abrasivo de Brecha','source_name':'Areia de Brecha Granulada','url':'https://app.notion.com/p/3f3c2b324ede816f9af4fdd6758bbe6c'},
'B30-05':{'name':'Placa de Apoio de Gnaisse Orientado','source_name':'Gnaisse de Fibra Transversal','url':'https://app.notion.com/p/3f3c2b324ede81319786eba0f666cef1'},
'B30-17':{'name':'Granada Calibrada para Lapidação','source_name':'Granada Abrasiva de Escarpa','url':'https://app.notion.com/p/3f3c2b324ede8150939dc8e911a3c5e1'},
'B30-21':{'name':'Régua Entalhada de Presa de Mamute','source_name':'Lasca de Presa do Mamute Antigo','url':'https://app.notion.com/p/3f3c2b324ede814ab353cf6008946d2c'},
}
source_context={'as_of':'2026-10-16','source_authority':'LOCAL_ARCHIVE_OF_PREVIOUSLY_READ_NOTION_PAGES; live Notion denied link_id eligible account',
'live_notion_reopened':0,
'baseline_fc06_sha256':digest(Path(root+'CRAFT-FC06-DELTA-20261016.zip')),
'baseline_fc06_checkpoint':json.loads(Path(root+'CRAFT-FC06-DELTA-20261016/outputs/fc06_rc5_gate_and_next.json').read_text()),
'local_historical_backfill_sha256':digest(Path(root+'BACKFILL30-CRAFT-20261014/ESPECIFICACOES-B30-01-a-B30-30.md')),
'source_urls':known,
'notion_access_status':'DENIED_THIS_EXECUTOR_link_id must identify an eligible linked account',
'known_canonicity':'PS existing resource pages, content captured earlier, NOT re-opened FC07; local dossier not authority for fresh changes',
'historical_R48_head':'cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708',
'recovered_file_integrity':{'fc06_zip_test':'PASS','fc06_sha256_match_prior':'PASS'},
'do_not_touch':['R44-R48','FC01-FC06','SBX-R48-BATCH-UI-2afb696406a6e839','FC04 orphan checkpoint','Party','O Primeiro']}
write('recovery_and_sources.json',source_context)
rows=[
{'id':'B30-03','product':known['B30-03'],'function':'calibrated gap/spacer between components',
'application_evidence':'only generic workshop/possible inscription and matrix assembly in archived PS dossier; no identifiable physical canonical assembly with required gap/tolerance in accessible evidence',
'control':'wood/metal/mica common shims; B30-05 is a support plate, not proof of a shim requirement',
'technical_evidence':'historical proposed two 50x20 mm pieces; thickness must be lot-measured; FC04 synthetic fabrication proves only model flow',
'decision':'D_INCONCLUSIVE_BY_SOURCE','independence':'NOT_DEMONSTRATED','material_property_claims':'NONE',
'next_condition':'Identify an existing competent assembly by page/ID specifying sandwich gap, tolerance, load, and reason common shim fails; without this do not resume tests',
'formal_recipe_base_id':None,'official_rec_id':None},
{'id':'B30-17','product':known['B30-17'],'function':'measurable fine grading of abrasive bulk material, not promised polish or hardness superiority',
'application_evidence':'archived PS material is a granular abrasive intended for lapidação; BACKFILL product process has milling and fine sieving',
'control':'B30-04 coarse fraction and ordinary graded abrasive. Coarse grade specification is [0.20,1.00]mm; B30-17 fine grade is [0.10,0.20)mm PROPOSED',
'process_difference':'B30-17 additionally requires britagem/moagem before classifying; B30-04 dry/wash/sieve, no mandatory crushing in historical design',
'functional_evidence':'grade intervals disjoint under a precisely defined 0.20-mm boundary; independently tested synthetic classification; does not establish real surface finish or region-specific superiority',
'decision':'A_DISTINCT_DESIGN_GRADE','independence':'PHYSICAL_REC_ID_NOT_JUSTIFIED_UNTIL_EXISTING_FINE_ABRASIVE_RECIPE_RECONCILED',
'next_condition':'Read-only source of existing fine abrasive recipe/base; actual process feasibility, particle distributions, and qualified in-world manufacturing/quality methods; technical economy scope',
'formal_recipe_base_id':None,'official_rec_id':None},
{'id':'B30-04','product':known['B30-04'],'function':'graded coarse abrasive as bulk input to desbaste',
'application_evidence':'archived PS and BACKFILL proposes simple sieving and classification',
'control':'B30-17 fine fraction and ordinary coarse sand',
'functional_evidence':'different grade interval, not a demonstrated different material performance',
'decision':'A_DISTINCT_DESIGN_GRADE','independence':'NOT_OFFICIAL; same family can share base recipe or distinct processing if proven',
'next_condition':'evaluate lineage once one abrasive family source can be reopened; no new duplicate class IDs',
'formal_recipe_base_id':None,'official_rec_id':None},
{'id':'B30-01','product':known['B30-01'],'function':'two-dimensional gridded inscription-training substrate only',
'application_evidence':'R42/FC06 design, 24 historical synthetic QA checks, no production measured',
'control':'generic gridded board; B30-21 portable 1D rule; no confirmed special slate merit',
'decision':'D_INCONCLUSIVE_FOR_PS_SPECIFIC_FORMULA','technical_nonredundancy_vs_B30_21':'different functions: 2D layout vs 1D measuring, but neither justifies regional material premium without evidence',
'lineage':'If a base gridded board recipe exists, treat use of PS slate as substitution S0/S1 if quality equivalent; do not label DERIVAÇÃO without physical base and change',
'next_condition':'identify same-purpose base gabarito recipe or material-specific permissible function, and cost/knowledge under PR-ECO and PR-SC',
'formal_recipe_base_id':None,'official_rec_id':None},
{'id':'B30-21','product':known['B30-21'],'function':'one-dimensional portable measurement with marked 10mm divisions',
'application_evidence':'historical PS/BACKFILL design, not a measured artifact',
'control':'ordinary ruler and B30-01 2D board',
'decision':'D_INCONCLUSIVE_FOR_PS_SPECIFIC_FORMULA','functional_nonredundancy_vs_B30_01':'linear portable rule can transfer a reference to the board; it must itself be calibrated against an independent established standard, avoiding a circular calibration proof',
'lineage':'no verified ordinary ruler recipe-base; cannot declare formal derivation',
'next_condition':'locate competent calibrated ruler/base and evidence for mammoth tusk durability/cost/suitability',
'formal_recipe_base_id':None,'official_rec_id':None}
]
write('functional_decision_matrix.json',{'schema':'FC07-FUNCTION-AND-LINEAGE-v1','decision_classes':{'A':'distinct candidate design, not automatically RC5','B':'verified physical recipe-base needed for formal derivation; none found','C':'reject only with sufficient duplicate/unsuitability proof','D':'evidence-specific inconclusive; branch closed without repetition'},'rows':rows,'assessed_count':len(rows),'current_notion_pages_reopened':0,'existing_physical_recipe_bases_authenticated':0,'rc5_eligible':0})
proposal={
'schema':'FC07-RC5-PRE_ADMISSION-B30-17-v1','source':known['B30-17'],'official_rec_id':None,
'design_id':'B30-17','design_name':'Granada Calibrada para Lapidação','product_specification_refined':'dry bulk grains graded 0.10 mm <= diameter <0.20 mm; no automatic improved polish, rank or elemental effect',
'documentation_level':'RC2_DESIGN_AND_RC3_PROCESS_LOGIC; RC4_STILL_CONDITIONAL; RC5_NOT_ELIGIBLE',
'identity_and_merit':{'status':'PROPOSED_WITH_TESTED_BOUNDARY','difference_from_B30_04':'strictly disjoint grade window (0.2 belongs to coarse grade), with physical size QA and grinding stage not in simple coarse sorting; not proof of different regional abrasive efficacy','possible_lineage':'single family of mineral grits; unique physical REC-ID only after existing fine abrasive formula/version searched and no functional equivalent found'},
'bom':{'M01':{'material':'Granada Abrasiva de Escarpa PS','quantity':'150 g nominal feed per TEST/design batch','role':'abrasive mineral feed, not already certified as fine fraction','source':known['B30-17']['url'],'evidence':'PS resource description historically recovered; availability/purity unknown'},
'T01_T05':{'material':'mill, graduated sieves, scale, hand lens, local dust capture','role':'reusable apparatus/energy/safety, NOT new ingredients','quantity':'one workstation, facility not certified in RPG'},
'consumable_envelope':{'material':None,'status':'N/A for output specified as BULK; if packaging/carrying required, add from legitimate inventory and reopen BOM'}},
'process_1_to_1':['select and weigh 150 g feed','crush/mill feed (mechanical, no new mass)','sieve into fine [0.10,0.20)mm, coarse [0.20,1.00]mm and out-of-grade','separate and weigh each fraction + documented dust/spill','inspect out-of-grade and contamination; QUARANTINE if indeterminate','release bulk grade only on recorded passing tests; returned into reusable workshop pan'],
'conservation':'m_fine + m_coarse + m_outgrade + m_dust_loss = m_feed (all actual measured g); no target 100g guaranteed',
'yield':'fine_g_approved from actual measured grade/certified contamination; output may be 0 g; prior 100g target not recorded as result',
'conditions':'dry handling, dust containment, appropriate screening tools and suitable/known test reference, no astrological condition stipulated',
'worker':'mineral preparation, screening and QA operator PROPOSED; actual in-world known practitioner and ability unverified',
'qa':{'synthetic_conservation_and_boundary':'15/15 PASS in targeted FC07 checker; NO real particles measured','required_real_or_authoritatively_accepted':'fine particle grade distribution, contamination tolerances, actual retention/performance if lapidação claimed, compatible substrate, safety of dust','failure':'oversized/no fraction -> zero or retriable; contamination unknown -> INDETERMINATE not PASS; impossible mass balance -> REJECT'},
'effect_and_power':'only physically classified grain fraction in proposed design; no offensive/defensive/magical modification; rank mechanical N/A, FIP N/A if no power',
'economy':{'canonical_formula':'CTE = CI + CP + CF + CT + CE + CK + CL + CA + CC','unit':'g fine-class approved bulk','cost_per_unit':'CTE_batch / m_fine_approved_g if m_fine_approved_g >0, otherwise INDEFINITE','known_values':{},'missing_inputs':['valued PS raw material unit (origin/time/market)','actual sorting loss and fine fraction yield','mineral processing operator time/cost','equipment energy/depreciation','skills/knowledge cost','transport, storage, capital opportunity']},
'authority_and_knowledge':{'raw_material':'PS existing, not P4; in-game stock not demonstrated','recipe_knowledge':'not demonstrated for anyone in campaign','jit':'NOT RUN; requires contextual PR-SC','publication':'HOLD no writer/fencing, unknown C19 effect, parent not verified'},
'gate_evidence':{'RC0_1':'existing product concept with PS raw source','RC2':'quantity+unit+role proposal','RC3':'1:1 transformation and mass balance proposal checked synthetically','RC4':'conditional: actual lot fraction/throughput, time, specialist, quality and quantified losses unknown','RC5':'DENY: material/process authority, knowledgeable operator, economic sufficiency, lineage, PS/JIT not proven'},
'no_empirical_claims':['no actual granulometric data','no measured abrasive rate or surface roughness','no tested product in Assimilação','no market value or real inventory']}
write('rc5_candidate_B30_17.json',proposal)
state={'schema':'FC07-SUCCESSION-STATE-v1','as_of':'2026-10-16','op':'CM-000002 / WS0001 / OP-ARQ-RIN-REC-01','baseline':'R01-R51 BACKFILL30 FC01-FC06 preserved','last_verified_unit':'FC07 newly executed focused tests in outputs/targeted_checks.json (15/15) + local FC06 sha/zip confirmation','first_pending':'for B30-17 verify existing fine abrasive recipe/base via reopened competent Notion index, and actual in-world PS source/process/QA/knowledge and economic evidence','nac_pass_02':{'local_package_integrity':'PASS after clean extraction','technical_size/mass_spec':'PASS_TEST_ONLY','real_material':'HOLD','technical_rc5':'HOLD','official_writes':'HOLD'},'denominators':{'ps_resources_documented_hist':{'num':30,'den':30},'pre_q2_hist':23,'pre_q1_hist':7,'fc07_candidate_designs_assessed':{'num':5,'den':5},'fc07_unique_matched_canonical_assembly_for_mica':{'num':0,'den':1},'fc07_local_focused_tests':{'num':15,'den':15},'physical_properties_measured':0,'fc07_Notion_read_verified':0,'official_rc5_recids':{'num':0,'den':30},'official_ps_resources_covered':{'num':0,'den':30},'official_products':0},'conflicts':['B30-03 has proposed spacer but no identifiable required assembly','B30-17 fine size grade is distinct, but this does not prove lapidation performance or independent official lineage','B30-01 2D board and B30-21 1D rule differ as tool class, but PS-material advantage not verified'], 'unknown_effect':['C19-021 UNKNOWN_EFFECT','FC04 orphan checkpoint untouched'], 'authority':{'F5':'RED historical','writer':'NOT_GRANTED','lease_fencing':'IBX-38 pending','REC_LIB_destination':'IBX-78 pending','Notion':'link_id ineligible, no live read/write','party_and_original_write_count':0},'no_repeat':['R44-R48 motor/replays and 62 FC04 checks','FC06 24 geometry tests','FC05 B30-22 tests','global 30-source rescan','existing operation/diary recreation'], 'next_5':['Recover authorized Notion link, re-open only B30-17 PS and potential existing fine abrasive recipe index','Compare B30-17 physical formula/base/variant ID; no speculative derivation or REC-ID','If independent, obtain appropriate in-world mineral grading and abrasive-use evidence or scoped authorial acceptance of spec','Complete RC4 lot and knowledge/economics for B30-17, assess RC5 technical without phantom MED','If writer eventually legitimate via IBX38/C19/IBX78 and NAC-PASS, apply only one idempotent write-set and read back'], 'next_exact':'outputs/rc5_candidate_B30_17.json gate_evidence.RC4 then anti-duplicate recipe-base lookup; no repeated geometric QA'}
write('succession_checkpoint.json',state)
