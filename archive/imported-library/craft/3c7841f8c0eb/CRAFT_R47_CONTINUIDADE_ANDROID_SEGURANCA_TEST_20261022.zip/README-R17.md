# CRAFT R17 — Auditoria metodológica aplicada ao R53 (MESTRE-SIDE TEST)

**Não é novo motor/norma:** delta somente `src/validate.js` (campo aditivo `methodology` por projeto), `build_mobile.py` (a mesma página HTML R16 apresenta recursos, item e receita e os exporta como resumo no roteiro existente), `tests/test_schema_r11.js` (regressão antiga compara apenas os campos legados) e testes `tests/test_methodology_r17.js`, `tests/test_browser_r17.py`. Todos os dados, regras e módulos canônicos continuam read-only. R13 receipt SHA cobre a auditoria expandida. O relatório anterior só muda pelo campo metodológico adicional; IDs, status, pendências e evidências preservados.

## Finalidade

Executar o EXISTING-FIRST de PR-CRN-01, ficha PR-ITEM-02 e BOM↔processo REC-EXEC como uma leitura objetiva das lacunas de proposta: fonte comum/documentada, recurso ainda não justificado, quantidade e unidade, prova física, rank/PA/custo ainda não aprovados, e segregação Mestre/Party. O novo campo não afirma aprovação de nenhum desses componentes e não substitui os protocolos.

## Procedimento

`node src/run.js && node src/verify_outputs.js`, `python build_mobile.py`, `node tests/test_methodology_r17.js`, `python tests/test_browser_r17.py`. Para regressão completa executar os demais `tests/test_*.js` e testes browser anteriores. `fuzz_schema_r11.js` é sondagem informacional separada. O HTML é TEST local e só foi aberto em Chromium inline, não em Android físico.

Fontes metodológicas e aplicações em `METODOLOGIA_APLICADA_R17_MESTRE_TEST.md`. F5/C19/IBX38 e R51 continuam sem autorização de produção. Não enviar à Party ou ao Primeiro. Sem writer/lease/epoch/ACK do executor predecessor.
