# PSV CRAFT R13 — Integridade de emissão local TEST

**ANTES:** R12 382/382 JS, 51/51 UI; arquivo QA e prévia TEST eram gravados sequencialmente sem recibo comum. Falha entre escritas podia deixar estado misturado até a execução seguinte.

**MUDANÇA EXECUTADA:** runner histórico `src/run.js` usa arquivos temporários, invalida recibo anterior antes de alterar saídas, escreve `OUTPUT_COMMIT.json` por último; verificador `src/verify_outputs.js` confere SHA256 dos dois arquivos, tamanho, estado e política de bloqueio Player. Este controle é interno/TEST e não configura autenticidade criptográfica de emissor.

**DEPOIS:** 9 cenários isolados, 58/58 asserções novas; 382/382 regressões JS; total 440/440 JS. Fuzz 2.000 determinístico separado. HTML anterior sem delta, 51/51 verificações Chromium inline, não prova Android físico. QA e prévia normais byte-idênticos R12, `OUTPUT_COMMIT.json` gerado e verificado. Cold replay/manifesto do pacote final são gate do artefato.

**GATES:** TEST software PASS; RC5/F5/P4/produção, IBX38, C19, R51, H2/R46, PA e materiais físicos HOLD. Itens/receitas/estoques canônicos, Party/O Primeiro sem escrita. **NEXT:** validar proteção diante de colisões e imports JSON muito grandes, ou avançar no dossiê REC-LIB e provas externas sem criar duplicata.
