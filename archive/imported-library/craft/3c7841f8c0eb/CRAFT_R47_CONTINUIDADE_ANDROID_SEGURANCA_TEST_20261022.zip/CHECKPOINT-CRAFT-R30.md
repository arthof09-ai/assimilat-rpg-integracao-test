# CHECKPOINT CRAFT R30 — Ponto exato de retomada

**Fonte:** Notion Mestre OP CRAFT `3f1c2b32-4ede-81d7-aa79-c83106240516` e LAB CRAFT `3fbc2b32-4ede-811d-b848-d35d4739eb00`, último registro CRAFT sincronizado R13. Os códigos TEST R14–R30 são preservados na Biblioteca Mestre, não no Notion.

**Artefato atual:** `CRAFT_R30_MATERIAL_REVIEW_AUTHOR_DECISIONS_TEST_20261022.zip` (raiz do mesmo motor R53/R20). Abrir `README-R30.md`, `PSV-CRAFT-R30.md`, `PARECER_CRAFT_R30_DECISOES_MESTRE_TEST.md`, `src/r46_intake.js`, `data/r27_decision_register_readonly.json`, `outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json`.

**Estado verificado nesta rodada:** R29 triagem R46 sem aprovar amostras/alterar requests; R30 documento autoral de 11 campos vazios em 3 receitas + 1 óleo; 21 decisões originais preservadas; 0 decisões formalizadas. Regressão alvo 1059 JS + 563 browser + fuzz 2000, detalhes no PSV. Revalidar ao extrair.

**Passo 1:** reabrir Notion e checar IBX-38, IBX-116, R51; se NOVA/sem fencing comprovado, continuar TEST sem writer. Não tomar lease/epoch/sessão por herança.

**Passo 2:** usar R29 para triagem de relatórios **genuinamente fornecidos** pelo operador R46 nos nós `R53-TEST-SONDA-001:B3`, `R53-TEST-TONICO-002:B3`, `R53-TEST-TONICO-002:B4`. Campos preenchidos não comprovam ensaio; perguntar por amostra, medição, controle, calibração, custódia e revisão independente. Não fabricar dados.

**Passo 3:** obter decisão do Mestre em `R30` sobre sal e energia P2, referências e aliases MAT03, `Ex` e sopro MAT06, processo do óleo Mestre. Só depois testar uma proposta de correção sem escrita canônica enquanto gates fechados.

**Bloqueios:** C19-021 UNKNOWN/F5 RED, R51 físico HOLD, IBX38 e IBX116 NOVA/ACK YES, RC5/P4/PROD HOLD. Party e O Primeiro NO-WRITE, 0 alterações em item/recurso/receita/inventário/PA. Não alegar NAC-PASS material.
