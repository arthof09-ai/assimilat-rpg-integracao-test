# CRAFT R11 — hardening de esquema no auditor R53 (MESTRE-SIDE/TEST)

Continuidade da **mesma bancada R53→R10**. Não existe novo motor, writer, receita RC5, item, estoque, preço, rank, efeito mágico, publicação Player ou autorização F5.

## Delta localizado
- `src/validate.js`: rejeita tipos impróprios em proposta, campos textuais, BOM, unidades, função/evidência, etapas, envelope de provas e economia, em vez de lançar exceção ou tolerar estrutura vazia.
- Completa recibos de proposta rejeitada sem BOM/processo para que a consolidação não quebre em `evidence.map`.
- `build_mobile.py` regenera o MESMO `REVISOR_LOCAL_ANDROID_R53_TEST.html`, preservando o fluxo de importação R9 (2 MiB, sem trocar estado ao falhar).
- `src/run.js` permanece byte-idêntico ao R10. Saídas normais `outputs/QA_RESULT.json` e `outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json` são **byte-idênticas** ao R10; ambos os projetos continuam `HOLD_TEST_DESIGN`.

## Reprodução (somente ambiente de laboratório)
- `node tests/test_schema_r11.js` — 141/141 verificações (35 mutações ×4 + baseline).
- `node tests/fuzz_schema_r11.js` — 2.000 sondagens determinísticas para evitar exceções; **não** contam como 2.000 testes unitários independentes.
- Demais 8 arquivos `tests/*.js` preexistentes = 197/197 verificações; com R11 = 338/338 verificações JS enumeradas.
- `python tests/test_mobile_browser_r9.py` e `python tests/test_browser_r11.py` sob Chromium de sistema/Playwright, separadamente 15/15 e 20/20 verificações de interface. São ensaios de navegador emulado, **não** prova de abertura no Android real.
- `node src/run.js` e comparar as saídas com R10. `REJECT_NO_PLAYER_PREVIEW` continua válido no caso de entrada inválida.

## Escopo e pendências
Fontes congeladas são índices históricos; `LIVE_SOURCE_RECHECK` permanece. P2/óleo, R46 físico, C19-021 e IBX-38 fencing, R51 parent, F5/RC5/P4/produção continuam HOLD. Party/O Primeiro NO-WRITE. Conteúdo interno da ficha Mestre não foi publicado.

Manifesto SHA256 `MANIFEST.json` do R11 é o único manifesto ativo deste pacote; as versões R9/R10 continuam preservadas em seus arquivos independentes anteriores na Biblioteca Mestre.
