# CRAFT R10 — CLI robusto e prévia Player bloqueada em erros de entrada

**MESTRE-SIDE / TEST**. Continuidade R53→R8→R9→R10 no mesmo executor, sem motor paralelo.

## Problema corrigido
O R9 retornava REJECT para array `products` vazio, mas `src/run.js` ainda tentava mapear `d.products` diretamente; outro erro de tipo em proposta (ou arquivo JSON corrompido) podia deixar uma prévia Player anterior intacta, apesar da rejeição. A saída do processo era confundível com êxito.

## Delta
`src/run.js` trata entrada ou validador inválidos com resposta `REJECT`, `INPUT_OR_VALIDATOR_INVALID` quando aplicável, saída de processo 2, diagnóstico JSON próprio e sentinela `{status:'REJECT_NO_PLAYER_PREVIEW',disclosure_status:'NÃO PUBLICAR',items:[]}` substituindo prévia residual. Não contém segredo da entrada rejeitada. Para propostas válidas mas ainda não certificadas, conserva a estrutura antiga da prévia TEST, apenas Mestre-only, e `HOLD_TEST_DESIGN` com saída de processo 0.

## Reprodução
`node src/run.js` → status `HOLD_TEST_DESIGN`, 2 propostas, 0 fabricação. Para regressões: `for f in tests/test_*.js; do node "$f"; done`. Rodar `python tests/test_mobile_browser_r9.py` **apenas se Chromium do sistema e Playwright estiverem disponíveis**; trata-se de DOM com HTML injetado, não abertura `file://` em Android físico.

`tests/test_cli_r10.js` executa 11 fixtures em diretórios descartáveis e 55 verificações de saída/código/diagnóstico/prevenção de prévia residual. As suites anteriores mantidas representam 142 verificações JS anteriores (99 R53+21 R8+22 R9). Total JS: **197 verificações PASS** em coortes disjuntas, sem chamar cada verificação de receita ou teste físico. UI Chromium R9: **15 verificações independentes** quando executadas.

Sem alteração a R48, QMC, PA, receitas, inventário, fichas ou Party/O Primeiro. F5 P0 RED/C19-021 UNKNOWN, writer/fencing/REC-LIB/RC5/P4/produção HOLD.
