# CHECKPOINT CRAFT R28 — Sucessão segura

**Fonte canônica:** Notion Mestre; fonte operacional: LAB CRAFT `3fbc2b32-4ede-811d-b848-d35d4739eb00` e OP CRAFT `3f1c2b32-4ede-81d7-aa79-c83106240516`. Execução R26–R28 MESTRE-SIDE / TEST do **mesmo motor R53/R20**.

- Recuperar `README-R28.md`, `PSV-CRAFT-R28.md`, `data/research_gaps_r25.json`, `data/r27_decision_register_readonly.json`, `data/r28_readback_21.json` e `outputs/CRAFT_R27_*`. Preservar histórico anterior; não criar motor de evidência paralelo ao R46.
- Software: 922/922 JS, 536/536 browser inline, 2k fuzz informacionais; baseline R25 saídas normais bit-identical e recibo verificado. UI Android físico não testado.
- R26: 3 pedidos concretos de fonte/prova; 0 amostra, 0 medição, 0 validação física, 0 substituto comprovado. R27: 21 UUIDs/20 keys; P0 ENC-08 sal/energia; P1 MAT-03 óleo/aliases e MAT-06 `Ex`; 7 crosscutting; no-write. R28: 21/21 páginas reabertas; 0 carimbo de edição novo desde o dossiê; **não** body diff histórico nem RC5.
- Notion: IBX38, IBX116, R51 NOVA e ACK YES, C19-021 UNKNOWN, fencing técnico não demonstrado, R51 destino físico não demonstrado. R14–R28 **não registrados em OP/LAB/Inbox**; último CRAFT até R13 (outras operações podem ter editado LAB). Ferramenta atual só leitura.
- **Ponto exato:** primeira ação externa útil = obter provas de operador/instrumento/custódia R46 para os 3 nós materiais. Separar resultados laboratoriais reais de templates. Segundo eixo = decisão Mestre para 21 divergências, iniciando P2, sem inventar dados; recheck após decisões, jamais alteração silenciosa.
- F5 RED, RC5/P4/PROD HOLD. Zero writer/lease/epoch/claim/ACK herdado; Party e O Primeiro NO-WRITE. Nenhum recurso, item, receita, estoque ou PA alterado.
