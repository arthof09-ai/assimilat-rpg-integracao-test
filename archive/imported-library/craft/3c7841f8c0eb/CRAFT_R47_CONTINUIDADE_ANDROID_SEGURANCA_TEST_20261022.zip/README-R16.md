# CRAFT R16 — paginação de propostas na interface móvel (MESTRE TEST)

## Problema e solução funcional

O mesmo revisor R53→R14 exibia todo o lote em uma única lista de cartões no Android. Isso pode causar grandes DOMs em lotes extensos. R16 modifica **somente** `build_mobile.py`/HTML offline para renderizar no máximo **oito cartões por página**, com botões Anterior/Próxima, resumo `Página X de Y` e estados de botões apropriados. **Não limita a quantidade de projetos que o motor valida**: a validação, o JSON de diagnóstico, o recibo e o roteiro R14 continuam cobrindo o lote inteiro. Trocar de página não reexecuta a validação. Uma importação inválida conserva lote e página anteriores.

## Prova de ganho

- Caso novo: **45 propostas TEST** em lote, importação abaixo de 2 MiB, 6 páginas (8/8/8/8/8/5); todas as 45 constam do QA e do roteiro, não apenas as oito visíveis.
- `tests/test_browser_r16.py`: 33/33 verificações Chromium inline móvel 390×844; paginação, quantidade total, navegação, export completo, falha de importação preservando estado e ausência de rede/overflow.
- Testes de interface anteriores R9 15/15, R11 20/20, R12 16/16, R14 40/40, somados aos 33 novos: **124/124**. Todos são Chromium de sistema com HTML em memória, NÃO ensaio no celular Android físico ou acesso file://.
- As 11 suítes JS R53–R13 seguem 440/440 verificações; fuzz determinístico 2.000 probes separados. `src/run.js`, `src/validate.js`, `src/verify_outputs.js`, `data`, QA, prévia e recibo saem byte-idênticos a R14.

## Governaça e uso

Somente MESTRE-SIDE TEST, sem enviar à Party. Baixar roteiro abrange TODOS os projetos; esse JSON é um pedido de evidências, não um laudo R46. Paginação é de visualização, não quota do jogo nem regra de criação. P0 F5 RED, IBX38/C19, R51, RC5/P4/PRODUÇÃO, lotes físicos, efeitos e magia continuam HOLD. Se um aparelho Android impedir abrir arquivo HTML local, esta bancada ainda não fornece certificação de plataforma/arquivo.
