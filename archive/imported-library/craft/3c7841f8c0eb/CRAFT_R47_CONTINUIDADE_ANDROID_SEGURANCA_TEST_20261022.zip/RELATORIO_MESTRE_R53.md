# R53 TEST — Aprimoramento prático da criação de itens e recursos

**Ambiente:** MESTRE-SIDE, exclusivamente experimental e documental. **Data:** 21/10/2026. **Objeto:** não inventar outro sistema de crafting; aplicar PR-ITEM-02, PR-CRN-01, REC-LIB-01, REC-LIN-SUB-01 e módulos REC-MOD existentes a dois projetos com fontes reais do acervo.

## 1. Estado real das fontes

- **VERIFICADO:** PR-ITEM-02 exige 13 blocos de uma ficha Mestre, avaliação independente de preço, descrição física, origem, funcionamento, receita e versão segura para Players. Não requer inventar conteúdo irrelevante.
- **VERIFICADO:** PR-CRN-01 exige GATE ZERO, BUSCA-CRN e recurso novo apenas mediante lacuna funcional verdadeira; as diretrizes CRAFT/F5 em HOLD não liberam expansão regional.
- **VERIFICADO:** MAN-CRAFT-F1-001 registra 212 recursos UCO físicos no seu checkpoint histórico, que não foram todos reabertos nesta execução. A pesquisa pontual presente não constitui auditoria global exaustiva.
- **VERIFICADO:** REC-LIB mantém receita, item, conhecimento da receita e ocorrência fabricada como objetos/estados distintos. Uma descrição de item ou processo proposto não é REC-ID RC5 legítimo.
- **VERIFICADO:** REC-LIN-SUB distingue S0, S1, S2, NO e PENDENTE; materiais de mesmo elemento não são automaticamente equivalentes.
- **VERIFICADO:** a diretriz do Mestre de 17/10/2026 pede competência geral em armas, armaduras, acessórios, equipamentos, artefatos e inscrições, sem alegar domínio a partir de uma só família.

Fontes principais: [PR-ITEM-02](https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4) · [PR-CRN-01](https://app.notion.com/p/3eec2b324ede819fbe0ed4af1a4cb3aa) · [REC-LIB-01](https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702) · [REC-LIN-SUB-01](https://app.notion.com/p/3f1c2b324ede818a9e84cfeae2aa0b9b) · [DIR-CRAFT-GERAL](https://app.notion.com/p/3fcc2b324ede810d9cf2c344e9c8e84e).

## 2. Exemplar A — Sonda de Eco Estático do Vale dos Raios (TEST / NOVO-P)

**Identidade e função.** Candidato a equipamento portátil para leitura qualitativa de carga estática de superfícies próximas. **NÃO é detector universal de magia, arma elétrica, pára-raios, cura ou fonte de resistência**. Não existia registro idêntico nas buscas nominais e funcionais realizadas; isso não prova inexistência no mundo. O nome, a geometria e o funcionamento do aparelho são PROPOSTOS; o equipamento não foi materializado.

**Descrição para o Mestre.** PROPOSTO: corpo de aproximadamente 18 cm com encaixe protegendo quartzo translúcido e aro condutor dourado, acondicionado em estojo simples. Aparelho a ser segurado pela parte isolante; a composição estrutural e seus detalhes ainda não têm material/proveniência identificados. Estado candidato sem preço, rank, FIP ou efeito comprovado.

**Recursos verificados.** [Cobre do Trovão](https://app.notion.com/p/3edc2b324ede8153b25cd4d8f323bc67) transmite sinais mágicos, enquanto [Quartzo Elétrico](https://app.notion.com/p/3edc2b324ede8176817ec09a5651648f) acumula carga estática. Tais capacidades isoladas **não provam que uma sonda construída a partir deles meça algo**. A função do Cobre como vetor e do quartzo como interface passiva ainda exige teste com controles.

**Mecânica de jogo, PROPOSTA A TESTAR.** Ao encostar a ponta em uma superfície, o instrumento poderia apresentar um sinal visual proporcional apenas a uma alteração local de eletricidade estática. Nenhum limiar de classificação, distância, CD, PA, duração, ação ou sucesso é fixado porque não foi demonstrado. Se a hipótese falhar, o objeto pode permanecer um conjunto mecânico inerte, sem efeito mágico.

**Origem/obtenção/geografia.** Cobre do Trovão tem fontes em vales ecoantes; Quartzo Elétrico em altitudes elevadas. A rota necessária entre fornecedores, a qualidade, o armazenamento, os riscos de extração e a economia regional não foram verificados. **Não localizamos nem inventamos um novo ponto geográfico**.

**Receita proposta, não executável.** A BOM contém B1 Cobre do Trovão (transmissor), B2 Quartzo Elétrico (captor hipotético) e B3 suporte/fecho comum ainda não escolhido. O processo cobre explicitamente a seleção do suporte, fixação do quartzo, instalação do cobre, prova estrutural e ensaio de comportamento com controles. As quantidades exatas, tratamentos, profissional, ferramentas, rendimento, perdas e integração mágica permanecem PENDENTES. É proibido denominar o candidato RC5.

**Testes discriminatórios propostos, não realizados:** C0 suporte isolante sem fonte; C1 suporte com quartzo; C2 suporte com cobre; C3 ambos, com distância/condição ambiental igual e instrumento de referência. Registrar observações reais antes de aceitar a hipótese. Uma mera imagem de faísca não prova sensibilidade calibrada, potência constante ou magia instalada.

**Economia, sociedade, conhecimento e jogabilidade.** CTE e MED não calculáveis com confiabilidade: não há preços correspondentes para os dois recursos, volume por unidade, yield ou rota; não presumir mercado. Possível interesse de exploradores é inferência, não facção declarada. A obtenção e o uso criariam escolhas e riscos, sem previsão infalível. O valor estratégico é condicionado ao efeito medido.

**Camadas:** Mestre mantém riscos e hipóteses; a versão de Players é **prévia segura NÃO PUBLICADA**, apenas aparência perceptível e status desconhecido.

**Resultado:** bom projeto conceitual para teste de bancada, **NÃO FABRICÁVEL**, rank/PAs/efeito/magia/preço desconhecidos.

## 3. Exemplar B — Tônico Experimental de Passo Elétrico (TEST / NOVO-P)

**Família:** Poções, portanto obedece a REC-MOD-POC-01; não usar o procedimento de equipamento como se fosse fórmula de poção.

**Recursos existentes:** [Capim Relâmpago](https://app.notion.com/p/3edc2b324ede8125abcddb7a1f37a98e) é associado a reflexos/velocidade, ocorrência canônica R10 Vale dos Raios; [Raiz de Condutor](https://app.notion.com/p/3edc2b324ede818290aad649c65aa304) conduz energia/magia pelo corpo, **sem resistência automática**. Não há evidência de que os dois sejam seguros, miscíveis ou tenham efeito combinado amplificado.

**Ficha Mestre conceitual:** um frasco com preparado líquido esverdeado, ainda sem forma/processo comprovado; uso por ingestão é NOVO-P. Efeito pretendido: benefício temporário de reflexos, quantitativo e prazo PENDENTES. Não afirmar que a poção já concede DES, esquiva, PA ou metros de deslocamento. Possíveis contaminação/instabilidade/dose inadequada são riscos prospectivos, não efeitos canônicos.

**BOM / receita:** capim como ativo, raiz como vetor candidato, veículo líquido PENDENTE, recipiente PENDENTE. Cada nó aparece no processo; contudo dose por frasco, unidade, temperatura, extração, rendimento, falhas, prazo de validade, especialista e custo não estão fundamentados. O pacote valida essa correspondência, mas impede a fabricação enquanto os dados forem desconhecidos.

**Economia:** as fichas do capim e da raiz apresentam valores aproximados de baixa confiança (capim 120–750 mil MED, referência central ~300 mil; raiz 95–650 mil, referência central ~260 mil). **Esses números NÃO são preço do tônico ou CTE**: falta quantidade consumida, mercado comparável, yield, trabalho e demais nós da árvore PR-ECO/C. Não se pode adicionar duas cotações imprecisas e declarar preço final.

**Resultado:** duas fontes existentes, nenhuma proposta CRN nova, **NÃO FABRICÁVEL** até fundamentar o processo, a dose, a estabilidade e os efeitos.

## 4. Recurso — GATE ZERO real aplicado

As quatro necessidades de *transmissão de sinal*, *carga estática*, *reflexos* e *condução* encontraram, nas pesquisas dirigidas, recursos físicos existentes. Nenhum recurso novo foi criado. Restam duas lacunas documentais de projeto: **veículo líquido adequado** e **suporte/fecho comum**. Ausência desses materiais no recorte pesquisado não é prova de lacuna global nem autoriza PR-CRN/P3, estoque ou nova região.

**Substituições:** quatro cenários documentados; nenhum S0 autorizado. A substituição de Capim Relâmpago por Raiz Condutora para a função de reflexos é NO: função incompatível. Cobre/raiz, quartzo/fulgurite e núcleo da Manopla/fulgurite são PENDENTES, porque os efeitos materiais e os processos não se equivalem automaticamente.

## 5. Melhoria geral de competência por família

| Família | Norma existente | Falha típica evitada | Ensaio/posição atual |
|---|---|---|---|
| Armas | REC-MOD-ARM-01 | RI do minério virar dano da arma | Manopla Ouro usada apenas como comparador; sem reescrever receita |
| Armaduras | REC-MOD-ARD-01 | CA e mobilidade ignorarem cobertura e articulação | Checklist técnico pronto; nenhuma armadura produzida |
| Equipamentos/Acessórios | REC-MOD-EQA-01 | Material condutor virar efeito mágico automaticamente | Sonda NOVO-P com BOM e ensaio discriminatório |
| Poções | REC-MOD-POC-01 | Falta de via, dose, veículo e rendimento | Tônico NOVO-P bloqueado por dados ausentes |
| Artefatos | REC-MOD-ART-01 | Carga/recarga/replicabilidade inventadas | Módulo recuperado; nenhum artefato novo reivindicado |
| Aprimoramentos | REC-MOD-APR-01 | Troca material S2 apresentada como S0 | Manopla + Fulgurite: PENDENTE, não aplicar |
| Recursos | PR-CRN-01/RC-MIN | Propor recurso para suprir um nome ausente | 4 necessidades reutilizam recursos existentes |

O objetivo de uma linha universal está nas **interfaces e nas provas**, e não num motor concorrente ao REC-EXEC. Cada família conserva seus próprios testes.

## 6. Ferramenta e testes

`REVISOR_LOCAL_ANDROID_R53_TEST.html` é uma interface autônoma sem envio de dados. Oferece revisão dos dois projetos e importação opcional de JSON no dispositivo, gerando diagnóstico JSON local. **Não consulta o Notion em tempo real; o índice é um snapshot** e exige rechecagem antes de qualquer decisão relevante. O JS usa whitelist restrita a cinco fontes efetivamente relidas e nunca autoriza produção, PA ou rank.

Suíte executada: 34 testes do validador + 11 de substituição/reutilização + 15 smoke tests JS da interface = **60 verificações**. A interface foi examinada por execução do script em VM Node. A tentativa de captura Chromium headless atingiu timeout no ambiente; portanto NÃO alegar teste E2E Android ou renderização visual em navegador real. O código e a saída continuam úteis para inspeção manual no Android.

## 7. Estado e próxima fronteira

**PASS digital/documental:** fontes alvo lidas, dois projetos modelados, BOM↔etapas com correspondência, cinco recursos catalogados, quatro cenários S0/S1/S2/NO analisados, 60 testes, interface offline, restrições Mestre/Party.

**HOLD real:** criação física, integração mágica, receita RC5, RIn/FIP definitivos, RE/RI, PA por ativação e por dia, quantidades físicas, rendimento, logística e valores de mercado, publicações de fichas, autorização de novos recursos. A própria OP CRAFT/F5 continua em F5 P0 RED/C19 UNKNOWN; nenhum writer ou lease da outra instância foi reivindicado.

**NEXT de maior valor:** localizar um componente estrutural existente apropriado e um veículo compatível (ou provar GAP real após GATE ZERO), resolver uma BOM experimental com medidas verificáveis, designar bancada/operador dentro do rito CRAFT, produzir controles sem mágico primeiro, comparar sinal real e só então discutir RE/PA/rank/CTE. A expansão para arma/armadura/artefato exige protótipo próprio e módulo específico; não se deduz domínio geral de dois estudos documentais.

## 8. Reforço de ficha física e proveniência (adendo ao primeiro replay)

Após o primeiro ensaio de 60 testes, acrescentei `data/master_cards_13.json` com os **13 blocos I–XIII** para cada um dos dois projetos, sob status `DOCUMENTAL_TEST_HOLD`, sem substituir as fichas originais. O texto da página HTML offline inclui as 13 seções expansíveis, para permitir revisão pelo celular.

Também acrescentei `data/provenance_graph.json`: **8 nós (4 fichas de recursos existentes + 2 receitas candidatas + 2 itens propostos) e 6 relações funcionais**, sem ocorrência física, página Player, pedido de estoque ou REC-ID canônico. Cada relação contém marcador de não comprovação de quantidade/estoque/produção, não apenas um link estético.

O adendo trouxe **23 testes novos**, totalizando **83 testes digitais**: 34 validador, 11 substituições/reutilização, 15 interface JS e 23 fichas/grafo. O primeiro pacote foi reempacotado e a persistência deve corresponder somente ao **hash final** declarado no registro. A versão anterior do ZIP foi um checkpoint transitório de engenharia, não uma receita publicada.

## 9. Aperfeiçoamento econômico — recibo R53 ECON (adendo final)

O Anexo C de PR-ECO-01 distingue **quatro valores**: kit de ingredientes, CTE de fabricação/instalação, valor do conhecimento da receita e preço/valor do produto. Para o tônico, os números históricos de baixa confiança do capim (120–750 mil MED; centro ~300 mil) e da raiz (95–650 mil; centro ~260 mil) foram transcritos COM AS RESSALVAS de origem. A simples soma ilustrativa de uma unidade de cada produziria centro ~560 mil MED, faixa 215 mil–1,4 milhão MED. **Essa conta não constitui orçamento, CTE, valor de receita ou preço final**, pois as quantidades, o mercado/época comum, o rendimento e os demais nós econômicos são desconhecidos.

Foi adicionado `src/economic_gate.js`, `data/economic_case.json` e 16 testes específicos. O gate devolve `HOLD_DATA` e quatro valores nulos enquanto essas informações não forem auditadas. Rejeita preço de venda apresentado como se decorresse diretamente do kit, estoque com preço zero e rank calculado a partir de preço. A ferramenta offline para Android exibe as pendências econômicas sem criar cotação nova.

**Total final de testes digitais:** 34 + 11 + 15 + 23 + 16 = **99/99**. Nenhuma dessas execuções é ensaio material, nem QA E2E em Android físico, nem NAC-PASS produtivo.
