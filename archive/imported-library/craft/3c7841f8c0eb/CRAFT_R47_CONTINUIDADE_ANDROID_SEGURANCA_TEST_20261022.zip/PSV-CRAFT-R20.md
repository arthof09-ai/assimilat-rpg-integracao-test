# PSV CRAFT R20 — Intake leve para criação de recurso, item ou receita (MESTRE-SIDE/TEST)

**ANTES:** R18 validava 517/517 JS, 325/325 Chromium inline, 2 projetos R53 HOLD_TEST_DESIGN e não gerava um briefing simples para uma criação nova. As fontes de metodologia PR-CRN-01, PR-ITEM-02, REC-EXEC/REC-LIB/PR-SC/PR-ECO estavam separadas em páginas extensas, embora a própria documentação já tenha o fluxo.

**DEPOIS:** só no HTML/revisor offline EXISTENTE, formulário curto de tipo, nome e intenção; gera arquivo JSON MESTRE-SIDE/TEST de pesquisa e completude documental. Cada tipo aponta seu procedimento canônico atual e mantém todos os indicadores de evidência `false`. Campo `follow_up_request` é somente sugestão de trabalho, com NO-WRITE canônico, sem informação Party. Nenhum formulário gera, aprova ou publica recurso, item ou receita. Nenhum motor ou normativo novo.

**Ensaios:** JS 517/517 herdados; 2000 fuzz informacionais. Chromium 325/325 herdados + 56/56 R20 = 381/381, viewport móvel 390×844 via conteúdo inline, downloads de 3 tipos, robustez input inválido, injeção texto, preservação dos dois projetos ativos, recibo R13, ausência de rede. Android físico/file:// NÃO provado. QA, preview e OUTPUT_COMMIT byte-idênticos R18/R20.

**Cadeia de custódia:** ZIP com manifesto SHA256/CRC e replay frio em pasta limpa; upload/readback Biblioteca Mestre comparado byte a byte (ver relatório de checkpoint). Notion/IBX/LAB/OP não sincronizados após R13 porque a conexão de atualização não está disponível. C19-021 UNKNOWN, IBX38 NOVA/Exige ACK YES/fencing NOT DEMONSTRATED, R51 NOVA/parent físico não verificado, F5 P0 RED. 0 item, receita, ficha, PA, estoque, Party/O Primeiro modificado.

**Ponto seguinte:** auditar qualidade das intenções e ordens de pesquisa com exemplos canônicos, continuar melhoria incremental da metodologia sem duplicar protocolos; quando houver autorização independente válida, executar menor microbloco material com gates, nunca antes.
