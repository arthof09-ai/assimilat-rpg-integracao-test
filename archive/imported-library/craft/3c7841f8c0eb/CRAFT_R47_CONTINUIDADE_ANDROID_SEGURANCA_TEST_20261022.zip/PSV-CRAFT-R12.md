# PSV CRAFT R12 — Proteção de prévia no laboratório

**ANTES:** R11 338/338 JS e 35/35 browser inline; validador aceitava tipo inesperado ou cópia literal de segredo Mestre em `player_view.name_if_discovered` / `visible_properties`, desde que `status=NÃO PUBLICAR`. Todos os projetos permaneciam HOLD TEST.

**MUDANÇA:** bloqueios `PLAYER_VIEW_SCHEMA`, `PLAYER_FIELD_TYPE_INVALID`, `PLAYER_SECRET_CROSSOVER` no validador existente; lote misto recusa TODA a prévia. UI rebatizada para “Prévia hipotética TEST — NÃO PUBLICAR”. Sem novo motor ou dados canônicos.

**DEPOIS:** R12 44/44 JS, acumulado R53–R12 382/382 JS, fuzz 2.000 determinístico, interface Chromium inline R9 15/15 + R11 20/20 + R12 16/16 = 51/51. Replay frio e manifesto sujeitos à verificação final do ZIP. QA e prévia normal idênticos à baseline R11. Dois produtos HOLD_TEST_DESIGN.

**GATE:** digital/TEST PASS; redação literal não prova ausência de paráfrases, Android físico, mágico, produção, RC5 ou autorização Party. C19-021 UNKNOWN-EFFECT, IBX-38 fencing PENDENTE, R51 parent não demonstrado, F5 P0 RED. O Primeiro/Party NO-WRITE, sem ACK ou writer herdado. **NEXT:** endurecer integridade do par diagnóstico/prévia para falhas de escrita, sem refazer o motor.
