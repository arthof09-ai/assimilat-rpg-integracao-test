# PSV CRAFT R9 — Entrada Android e dados malformados

**Operação original:** OP-ARQ-RIN-REC-01. **Superfície:** LAB CRAFT / MESTRE-SIDE TEST. **Baseline confirmado:** R53 e R8, não reescrever nenhum dos dois. **Fronteira:** QA e UX de importação; não há permissão de writer, lease, epoch, ACK ou GREEN.

## ANTES
R8 confirmou ID/URL/função da fonte, mas `valid` tolerava arrays de produtos vazios com sucesso documental (`every` em zero itens), podia lançar TypeError com item `null`, nó BOM nulo e etapa com entradas inválidas. A interface importava diretamente qualquer `products[]` antes do diagnóstico; um arquivo malformado poderia corromper o estado em memória do revisor até recarregar a página.

## DEPOIS
`src/validate.js` (o mesmo validador) tem fail-closed para entradas top-level, itens, nós e etapas inválidos. `build_mobile.py` (a mesma interface) impõe 2 MiB, pré-valida JSON, recusa o resultado `REJECT` e mantém o último conteúdo válido em caso de erro. **Não foi criada receita/motor/catálogo nem feito upload de input do Mestre.**

## PROVAS
- 22/22 adversariais novos (`tests/test_import_r9.js`), com execução do handler de upload local e rejeição sem alteração da proposta anterior.
- 99/99 R53 +21/21 R8 regressões PASS; total **142/142** asserções JS TEST nesta cópia.
- Controle R53: Sonda e Tônico continuam `HOLD_TEST_DESIGN`; `LIVE_SOURCE_RECHECK` permanece HOLD, 0 itens/receitas/PA/rank/estoque publicados.
- Navegador **Chromium de sistema 144**, viewport móvel 390×844: **15/15 asserções E2E de UI PASS** com `page.set_content` e interação real (importação inválida, retenção do estado anterior, importação válida, download JSON, 0 chamadas HTTP). `file://` foi bloqueado por política do ambiente; abertura local no telefone Android do Mestre **NÃO VALIDADA**. Os 15 pontos UI são uma coorte separada das 142 asserções JS/VM.

## BLOQUEIOS E NEXT
F5 P0 RED/C19-021 UNKNOWN-EFFECT, IBX-38 fencing, R51 parent REC-LIB, P2 sal/energia/Óleo, R46 medições reais e H2 testemunha, RC5/P4/PRODUÇÃO HOLD. Primeiro pendente: readback da Library e LAB/OP/IBX; depois fontes de suporte/veículo e prova de compatibilidade com controles. Zero Party/O Primeiro. NAC-PASS apenas engenharia digital/replay proporcional.
