"""R41 consolidates original 29 recipe physical IDs and separate evidence status."""
import json,csv,pathlib,collections
p=pathlib.Path(__file__).parent
q=json.loads((p/'outputs/CRAFT_R27_FILA_21_RECEITAS_MESTRE_TEST.json').read_text())
r39=json.loads((p/'data/r39_remaining_13_recipe_readback.json').read_text())
r41=json.loads((p/'data/r41_clean_eight_hold.json').read_text())
r40=json.loads((p/'data/r40_50_author_notes_baseline.json').read_text())
all_records=[]
for c in q['cases']:
 n=sum(1 for r in r40['cases'] if r['physical_recipe_id']==c['physical_recipe_id'])
 assert n==1
 r=next(r for r in r40['cases'] if r['physical_recipe_id']==c['physical_recipe_id'])
 all_records.append({'physical_recipe_id':c['physical_recipe_id'],'case_key':r['key'],'source_url':c['source_url'],'class':'ORIGINAL_LEXICAL_ISSUE',
 'questions_total':len(r['slots']),'author_notes_authenticated':False,'physical_rc5_approved':False,'readback_basis':'R30/R36/R38/R39 document readback 2026-10-22'})
for c in r41['cases']:
 all_records.append({'physical_recipe_id':c['physical_recipe_id'],'case_key':c['case_key'],'source_url':c['source_url'],'class':'NO_LEXICAL_ISSUE_IN_OLD_DOCKET',
 'questions_total':0,'author_notes_authenticated':False,'physical_rc5_approved':False,'readback_basis':'R41 direct Notion readback 2026-10-22'})
assert len(all_records)==29 and len({c['physical_recipe_id'] for c in all_records})==29
assert sum(c['class']=='ORIGINAL_LEXICAL_ISSUE' for c in all_records)==21
assert sum(c['class']=='NO_LEXICAL_ISSUE_IN_OLD_DOCKET' for c in all_records)==8
assert sum(c['questions_total'] for c in all_records)==47 # additional upstream oil 3 not recipe
assert r40['denominators']['total_questions']==50
f=p/'R41_MAPA_29_RECEITAS_READBACK_MESTRE_TEST.csv'
with f.open('w',newline='') as h:
 writer=csv.DictWriter(h,fieldnames=list(all_records[0]));writer.writeheader();writer.writerows(all_records)
(p/'data/r41_29_recipe_coverage.json').write_text(json.dumps({'schema':'CRAFT_R41_29_RECIPES_COVERAGE_TEST_V1','classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
'denominator':{'recipes':29,'lexical_issues':21,'no_lexical_issues':8,'question_slots_for_recipes':47,'upstream_oil_questions':3,'all_question_slots':50,
'physical_rc5_lots_approved':0,'canonical_mutations':0},'cases':all_records,'no_party_write':True,'production_hold':True},ensure_ascii=False,indent=2)+'\n')
print('R41 29/29 unique; 47 recipe slots +3 upstream oil=50; physical RC5 0')
