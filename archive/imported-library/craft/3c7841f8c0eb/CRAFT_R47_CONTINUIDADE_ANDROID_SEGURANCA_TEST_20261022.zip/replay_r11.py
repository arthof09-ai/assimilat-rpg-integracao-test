"""QA proporcional CRAFT R11 — não altera Notion nem estoque."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for n,meta in manifest['files'].items():
 p=root/n
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256'],n
js_files=sorted((root/'tests').glob('test_*.js'))
for p in js_files:
 c=subprocess.run(['node',str(p)],cwd=root,text=True,capture_output=True)
 assert c.returncode==0,f'{p.name}: {c.stderr} {c.stdout}'
c=subprocess.run(['node',str(root/'tests/fuzz_schema_r11.js')],cwd=root,text=True,capture_output=True)
assert c.returncode==0,(c.stderr,c.stdout)
print('PASS manifest',len(manifest['files']),'source files; JS suites',len(js_files),'; deterministic robustness 2000 vectors')
print('Browser suites require installed Python Playwright+Chromium; run separately and do not infer Android-device validation')
