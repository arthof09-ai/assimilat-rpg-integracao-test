# CRAFT R13 — Recibo íntegro do par QA + prévia TEST

MESTRE-SIDE/TEST. É um patch do mesmo executor R53→R12, sem motor, norma, autoridade, escritor, nova receita ou integração Party.

## Problema resolvido

O CLI escrevia `QA_RESULT.json` e `PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json` como arquivos independentes: uma falha entre gravações podia deixar duas gerações diferentes aparentando formar um mesmo resultado. No R13:

1. Remove `OUTPUT_COMMIT.json` **antes** de começar a escrita.
2. Prepara as duas saídas com arquivos temporários e renomeia para os caminhos históricos.
3. Emite `OUTPUT_COMMIT.json` **por último**, com hashes SHA256, comprimento em bytes, estado, total de itens e hash de geração.
4. O verificador read-only `src/verify_outputs.js` invalida recibo ausente, hashes/bytes alterados, status incoerente, `REJECT` com prévia não bloqueada ou objeto não-REJECT sem `disclosure_status=NÃO PUBLICAR` e `internal_approval=false`.

**Limitação importante:** não é uma transação multiarquivo atomicamente garantida nem assinatura criptográfica externa. Consumidores devem exigir `verify_outputs` PASS antes de aceitar uma dupla de resultados. Durante falha, os arquivos avulsos continuam sem validade sem recibo.

## QA

- Teste novo `tests/test_receipt_r13.js`: 9 cenários isolados e 58/58 asserções, incluindo falha injetada após staging, após escrita QA, após escrita prévia, mudanças de bytes no QA/prévia, alteração de status, remoção de recibo e QA ilegível.
- R53–R12: 382/382 regressões JS anteriores. Total R53–R13: 440/440 asserções JS.
- Fuzz determinístico 2.000 vetores informacionais; UI Chromium inline R9 15/15, R11 20/20, R12 16/16 (mesma interface sem delta), 51/51, sem Android físico.
- Normal original mantém saída QA/prévia byte-idêntica ao R12. O único arquivo operacional extra é o recibo.

## Gate

Ambos os produtos `HOLD_TEST_DESIGN`. RC5/F5/P4/PRODUÇÃO, C19-021, IBX-38, R51 destino, P2, H2/R46 físico/magia HOLD. O Primeiro/Party NO-WRITE. Atesta consistência dos bytes TEST, não autenticidade de fonte externa ou publicação Player.
