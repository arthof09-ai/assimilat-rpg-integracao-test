"""Exports an existing-docket continuity view: no new REC-ID, items or Notion writes."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
js="""'use strict';const fs=require('node:fs');const {buildR33ContinuityView}=require('./src/r33_continuity_view.js');
const d=JSON.parse(fs.readFileSync('data/r27_decision_register_readonly.json'));
const a=JSON.parse(fs.readFileSync('outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json'));
const e=JSON.parse(fs.readFileSync('outputs/CRAFT_R27_PEDIDOS_R46_3_NOS_MESTRE_TEST.json'));
const o=buildR33ContinuityView(d,a,e);if(o.verdict!=='DOCUMENTAL_NEXT_STEPS_ONLY')throw Error(o.reason);
fs.writeFileSync('outputs/CRAFT_R33_PLANO_UNICO_CONTINUIDADE_MESTRE_TEST.json',JSON.stringify(o,null,2)+'\\n');
console.log('R33',o.other_recipe_cases.length, o.pending_material_nodes.length,o.priority_recipe_sources.length);
"""
# JS one-off uses static bundled data, not API/network
subprocess.run(['node','-e',js],cwd=root,check=True)
