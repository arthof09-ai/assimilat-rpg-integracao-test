# Guia Android — R47 TEST — somente Mestre

**R45:** a área de proteção avisa alterações não exportadas nas seções R31, R40, R46. Não guarda rascunhos sozinho. Fechar aba ou atualizar pode apagar notas. Clique em Salvar e confira o arquivo baixado.

**R46:** a conferência do índice de 29 receitas rejeita UUIDs duplicados inclusive na referência congelada. Não significa que haja receita aprovada; é um controle documental.

**R47:** uma importação R31 ou R40 diferente das anotações locais preenchidas pede confirmação ANTES de substituir. Cancelar conserva as anotações. Arquivo adulterado é rejeitado. A confirmação autoriza somente trocar texto local, **não canoniza** receita.

**R35:** recriar coleta R46 com campos preenchidos também pede confirmação. Não há 72 medições reais; são 72 campos disponíveis para 3 nós materiais. Não supor que dados inseridos sejam laudos.

**Importante:** alerta de saída pode não funcionar em todos os navegadores Android. O revisor não solicita internet e jamais deve ser enviado à Party. O formulário completo é Mestre-only.
