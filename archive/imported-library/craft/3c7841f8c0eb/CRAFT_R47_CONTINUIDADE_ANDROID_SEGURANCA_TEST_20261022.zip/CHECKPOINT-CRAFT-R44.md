# CHECKPOINT CRAFT R44 — 22/10/2026 — MESTRE-SIDE / TEST

## Antes

R41 era versão funcional do mesmo revisor R53 com 50 perguntas em 22 grupos; a leitura documental cobria 29 receitas únicas (21 com divergência, 8 sem conflito lexical localizado), 0 decisões autenticadas, 0 receitas homologadas RC5. Sonda e Tônico TEST `HOLD_TEST_DESIGN`. NAC-AUTO-01 proposta, não promovida. Notion OP/LAB/Inbox último registro CRAFT comprovado R13.

## Depois, fisicamente observado no ambiente TEST

- R42: filtro e navegação móvel que não afetam conteúdo das 50 notas e não ocultam perguntas na exportação. Validação 56/56 JS novos e 34/34 Chromium novos.
- R43: roteiro de revalidação exportável sem texto de nota, 50 passos baseados na mesma ficha de perguntas; 142/142 JS novos e 22/22 Chromium novos. Qualquer nota continua não autenticada.
- R44: 29/29 páginas de receitas reabertas diretamente via Notion nas 3 consultas desta execução; edit stamps e pais coincidiram com R15. Sem captura do hash integral de todos os corpos. Comparador fail-closed: 89/89 testes. A leitura não alterou a ficha e não certifica RC5.
- Regressões JS herdadas, QA e fuzz executadas. Arquivos QA e Player-preview inalterados: `b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541` e `509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8`.

## Bloqueios externos persistentes

IBX38 `NOVA/ACK __YES__` fencing C19-021 sem prova; IBX116 `NOVA/ACK __YES__`; R51 `NOVA/ACK __YES__`, pai físico REC-LIB sem homologação; Notion conexão apenas busca/fetch. RC5/P4, transferências mágicas, estoque e divulgação Party/O Primeiro **HOLD**. Sem writer/lease/epoch ou fonte de medida R46. Nenhum write canônico efetuado; arquivos TEST salvos apenas no contêiner/Biblioteca.

## Próxima retomada exata

1. Ler este checkpoint e `README-R44.md`; verificar no Notion IBX38/116, R51, OP e LAB antes de qualquer escrita.
2. Executar `replay_r44.py` na cópia do pacote e conferir `MANIFEST-R44.json`; se necessário `--full` para emulação Chromium. No Chrome Android Mestre, filtrar 50 perguntas e salvar minuta sem autorização.
3. Receber **decisões autenticadas** referentes às 50 perguntas e executar comparador de identidade/fonte por UUID antes de aplicar possíveis edições; sem decisão manter HOLD. Óleo de Vedação possui impacto potencial em 29 receitas; MAT03 contém referência antiga e não deve sofrer relink automático.
4. Receber **dados físicos genuínos R46** para Sonda B3, Tônico B3/B4, incluindo custódia, amostras, medições, controles e calibração. Teste sintético não é laudo.
5. Só após fencing e roteamento competente, tratar REC-LIB físico e NAC-PASS; sem duplicate tickets/receitas/engines; Party/O Primeiro NO-WRITE.

**Estado de checkpoint: R44 TEST digital.** O projeto CRAFT canônico permanece sem writes e sem homologação produtiva.

## Observação da reprodução fria

Execução completa dos 21 testes Chromium excedeu o limite temporal da ferramenta depois de 16 suítes PASS. As cinco remanescentes passaram em nova chamada sobre a mesma extração. R35 recebeu `wait_for_function` após upload assíncrono para eliminar race do próprio teste, preservando os critérios e a lógica do revisor. Reportar 725/725 **por blocos**, sem insinuar uma única chamada concluída.
