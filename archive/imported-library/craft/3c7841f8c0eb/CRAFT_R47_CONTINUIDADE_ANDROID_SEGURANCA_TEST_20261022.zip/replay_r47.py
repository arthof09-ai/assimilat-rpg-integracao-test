"""CRAFT R47 TEST-only reproducibility gate. No canonical or network writes."""
from pathlib import Path
import json,hashlib,subprocess,re,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST-R47.json').read_text())
assert manifest['schema']=='CRAFT_R47_TEST_MANIFEST_V1'
for filename,digest in manifest['files'].items():
 p=root/filename
 assert p.is_file(),('MISSING',filename)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,('SHA_MISMATCH',filename)
print('MANIFEST',len(manifest['files']),'/',len(manifest['files']),'PASS',flush=True)
suites=sorted((root/'tests').glob('test_*.js'));tests=0
for script in suites:
 p=subprocess.run(['node',str(script)],cwd=root,capture_output=True,text=True,timeout=45)
 assert p.returncode==0,(script.name,p.stdout[-900:],p.stderr[-900:]);m=re.search(r'(\d+)\s*/\s*(\d+)',p.stdout)
 assert m and m[1]==m[2],(script.name,p.stdout)
 tests+=int(m[1])
assert len(suites)==30 and tests==1765,(len(suites),tests)
print('JS 30/30 SUITES',tests,'/1765 CHECKS PASS',flush=True)
p=subprocess.run(['node','src/run.js'],cwd=root,capture_output=True,text=True,timeout=45)
assert p.returncode==0,(p.stdout,p.stderr)
p=subprocess.run(['node','src/verify_outputs.js'],cwd=root,capture_output=True,text=True,timeout=45)
assert p.returncode==0,(p.stdout,p.stderr)
for f,digest in [('outputs/QA_RESULT.json','b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'),('outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json','509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8')]:
 assert hashlib.sha256((root/f).read_bytes()).hexdigest()==digest,('HISTORIC_QA_DRIFT',f)
print('QA/RECEIPT/PLAYER_PREVIEW TEST HASHES PRESERVED; 2 PROJECTS HOLD',flush=True)
p=subprocess.run(['node','tests/fuzz_schema_r11.js'],cwd=root,capture_output=True,text=True,timeout=60)
assert p.returncode==0 and 'PASS 2000' in p.stdout,(p.stdout,p.stderr)
print('SYNTHETIC FUZZ 2000/2000 PASS',flush=True)
if '--full' in sys.argv:
 chrome=sorted((root/'tests').glob('test_browser_*.py'))+[root/'tests/test_mobile_browser_r9.py']
 count=0
 for script in chrome:
  p=subprocess.run([sys.executable,str(script)],cwd=root,capture_output=True,text=True,timeout=75)
  assert p.returncode==0,(script.name,p.stdout[-1100:],p.stderr[-1100:]);m=re.search(r'(\d+)\s*/\s*(\d+)',p.stdout)
  assert m and m[1]==m[2],(script.name,p.stdout)
  count+=int(m[1]);print('CHROME',script.name,m[1],flush=True)
 assert len(chrome)==23 and count==778,(len(chrome),count)
 print('CHROMIUM 23/23 SUITES, 778/778 PASS; EMULATED, NOT PHYSICAL ANDROID',flush=True)
print('R47 TEST VERIFIED; REC-LIB/C19/RC5/PRODUCTION/PARTY HOLD',flush=True)
