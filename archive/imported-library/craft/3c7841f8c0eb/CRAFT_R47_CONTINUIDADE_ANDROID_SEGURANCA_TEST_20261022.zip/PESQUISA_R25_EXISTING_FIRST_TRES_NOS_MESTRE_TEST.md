# CRAFT R25 — Pesquisa dirigida EXISTING-FIRST: três nós materiais pendentes

**Projeto:** Assimilação · **frente:** OP-ARQ-RIN-REC-01 · **ambiente:** MESTRE-SIDE / TEST / somente leitura · **data de verificação:** 22/10/2026. 

**Escopo fechado:** B3 Sonda (suporte/fecho), B3 Tônico (veículo/carreador) e B4 Tônico (frasco/fecho). Retoma checkpoint R21, validador R22 e recomendações R17–R21. Nenhum novo recurso, item ou REC-ID foi criado. Não presume que busca textual parcial prova inexistência no catálogo. 

## Metodologia aplicada, sem criar regra

1. Produto, fórmula e insumo existente antes de PR-CRN-01. A pesquisa percorreu títulos e descrições acessíveis do Notion Mestre, com identidade de páginas e proveniência; não usou páginas do Espelho Party como matéria-prima.
2. Distinguir **função física do suporte**, **função energética** e **transferência de magia**. Resistência elétrica, estabilidade do material, segurança de dose e compatibilidade com veículo exigem evidências próprias.
3. Confrontar PRECEDENTE de recipiente no texto de uma receita com PROVA de material isolado/componente do catálogo. Uma receita que menciona frasco **não certifica** que esse frasco possa ser reutilizado universalmente.
4. Qualquer comparação de rendimento, concentração, dose, custo, PA, Rank e durabilidade permanece **PENDENTE** sem dados e laudo R46.

## A — Sonda de Eco Estático: B3 suporte/fecho

**VERIFICADO:** [Cobre do Trovão](https://app.notion.com/p/3edc2b324ede8153b25cd4d8f323bc67) é relevante à transmissão de sinais mágicos; [Quartzo Elétrico](https://app.notion.com/p/3edc2b324ede8176817ec09a5651648f) acumula energia estática. Propriedade própria ≠ conjunto detector qualificado. Ambos já estão nos nós B1/B2, não preenchem B3 automaticamente.

**Candidato a examinar, NÃO APROVADO:** [Acácia Radiante](https://app.notion.com/p/3edc2b324ede81518426d45967b10e8f). A ficha Mestre distingue árvore, madeira, casca e resina; *somente a resina* possui função mágica documentada de selar encantamentos luminosos. Madeira/casca **não** herdam função de resina, não provam isolamento elétrico, resistência à vibração nem geometria de encaixe. Não transferir automaticamente a função luminosa para uma Sonda elétrica.

**Decisão atual:** B3 permanece `PENDING_STANDARD_MATERIAL_AND_SPEC`. Não criar novo minério/CRN. **Próximo dado necessário:** especificação de suporte físico comum (tipo/forma/medida), encaixe e método de fixação, ensaio de isolamento mecânico/elétrico em amostras reais, fornecedor/quantidade/unidade e acesso seguro. Nenhum ingrediente substituto foi homologado.

## B — Tônico Experimental: B3 veículo líquido

**VERIFICADO:** [Capim Relâmpago](https://app.notion.com/p/3edc2b324ede8125abcddb7a1f37a98e) e [Raiz de Condutor](https://app.notion.com/p/3edc2b324ede818290aad649c65aa304) possuem propriedades próprias, mas não demonstram eficácia, extração ou segurança de ingestão combinada.

**Precedentes parciais, NÃO SUBSTITUTOS VALIDOS:** [Poção de Liquidação](https://app.notion.com/p/3edc2b324ede814f89f3e19247d52c5c) e [Porção Rastreadora](https://app.notion.com/p/3edc2b324ede8133af08e788d51c3686) referem transferência/engarrafamento ao fim do processo; o texto consultado não demonstra que seu veículo, caso existente, extraia e estabilize estes dois recursos específicos. REC-MOD-POC-01 exige distinguir ativo, veículo/carreador, estabilização, forma de uso e compatibilidade; nenhum solvente foi declarado como testado.

**Decisão atual:** B3 permanece `PENDING_WIDER_SEARCH`, `new_CRN=false`. **Próximo dado:** catálogo de veículos com composição/formato, método de extração, compatibilidade material, concentração, risco de ingestão, estabilidade, descarte e documentação de ensaio. Não inventar água como solvente só porque líquido é plausível.

## C — Tônico Experimental: B4 recipiente/fecho

**VERIFICADO:** [Óleo de Vedação](https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd) menciona armazenamento em frasco de cristal encantado; [Poção de Liquidação](https://app.notion.com/p/3edc2b324ede814f89f3e19247d52c5c) fala em frascos de poção. Esses são **precedentes de práticas específicas**, não ficha universal de frasco equivalente nem especificação para o Tônico. [Poção Troca Atributos](https://app.notion.com/p/3edc2b324ede81759411f34a98e6887b) deixa recipiente/volume pendentes, ilustrando a diferença entre item físico e volume efetivamente medido.

**Decisão atual:** B4 permanece `PENDING_STANDARD_MATERIAL_AND_SPEC` em função do material do recipiente, compatibilidade, resistência, fechamento e volume. **Próximo dado:** referência física única de recipiente/fecho ou especificação documentada, volume real, vedação compatível com o veículo, higienização, armazenamento, custo e descarte. Frasco encantado não é escolha automática (pode exigir poderes/PA/receita distintos).

## D — Instrumentação e transferência mágica

**R46 é a rota vigente:** amostra/ID/lote/operador/instrumento/calibração/controle positivo-negativo/incerteza/rendimento/perda/laudo/origem. O presente estudo apenas prepara necessidades; **0 medições físicas, 0 lotes de poção, 0 testes de eficácia**, zero demonstrativo de transferência de magia, zero atestado de segurança. Instrumentos, preços, cargas, raridade, PA e RI/RE requerem autoridades próprias; nenhum foi inventado.

**NAC-PASS proporcional:** pesquisa/readback Notion PASS no recorte indicado, compatibilidade material e promoção/produção HOLD. C19-021 UNKNOWN, IBX38 NOVA/ACK YES sem prova de fencing, R51 NOVA/ACK YES sem destino físico único e conexão Notion no momento apenas leitura. Party/O Primeiro NO-WRITE. Não considerar este documento nova norma, recibo de produção ou autorização.

**Retomada:** 1) R46 prova física verdadeira para B3/B4 e efeito; 2) fechar nó, quantidade, unidade, ferramenta, tempo e custo somente por fonte; 3) passar por módulos PR-ITEM/REC-EXEC/PR-CRN e NAC quando autorização técnica voltar; 4) sem isso, manter os três nós PENDENTES.
