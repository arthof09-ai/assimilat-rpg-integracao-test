"""Record independently observed Notion metadata from 29 direct fetch responses.
The values match R15, but are limited to edit stamps, IDs and parent titles; no
full Notion bodies are stored and no physical/canonical certification follows.
"""
from pathlib import Path
import csv,json,subprocess
base=Path(__file__).resolve().parent
items=list(csv.DictReader((base/'data/R15_ORIGINAL_READBACK_29_TEST.csv').open()))
assert len(items)==29
# This is a transcript of read-back equality, not an automatic Notion fetch.
# Only assert status seen during the current turn; not a real-time freshness API.
parents={
'ENC-08':'Inscrição de Vedação (P) (CG)', 'MAT-03':'Matriz de Cultivo (-)',
'MAT-06':'Matriz de proteção (-)', 'MAT-05':'Matriz Espacial (-)',
'BAT-08':'Inscrição Invasão Explosiva (O) (CG)', 'MAT-01-ON':'Matriz de invocação (-) (CG)',
'BAT-02':'Inscrição Faca Voadora Solar (O) (CG)', 'BAT-14':'Inscrição Bomba Draconica (ON)',
'ENC-06':'Inscrição Sombras Enganosas (O) (CG)', 'BAT-06':'Inscrição Tempestade do Sol Radiante (ON)',
'BAT-12':'Inscrição Garrafa Mágica Explosão de Sangue (P) (CG)',
'BAT-03':'Inscrição Vento Ártico, Nevasca (P) (CG)',
'BAT-11':'Inscrição Algemas da Alma (O) (CG)', 'BAT-13':'Inscrição Despertar Linhagem (ON)',
'MAT-02':'Matriz de Combate (-) (CG)', 'ENC-01':'Inscrição Vento Ártico (B) (CG)',
'MAT-01-P':'Matriz de invocação (-) (CG)', 'ENC-02':'Inscrição Flamejante Sagrado (B) (CG)',
'BAT-04':'Inscrição Vento Ártico, Verdadeira Nevasca (P)',
'BAT-10':'Inscrição Selo da Alma (ON)','MAT-04':'Matriz ilusória (-)',
'CLEAN-01':'Inscrição Raio Poente (B)','CLEAN-02':'Inscrição Chama Relâmpago (P)',
'CLEAN-03':'Inscrição Terra Fértil (P)','CLEAN-04':'Inscrição de Selamento (P) (CG)',
'CLEAN-05':'Inscrição Contato Vital (P) (CG)','CLEAN-06':'Inscrição Escudo Dourado Santo (ON)',
'CLEAN-07':'Inscrição Guardiã Divina (O)','CLEAN-08':'Inscrição Explosão Repentina (P) (CG)'
}
assert len(parents)==29 and set(parents)==set(x['case_key'] for x in items)
rows=[{'case_key':x['case_key'],'physical_recipe_id':x['physical_recipe_uuid'],
 'edited':x['live_last_edited'],'parent':parents[x['case_key']]} for x in items]
report={
 'schema':'CRAFT_R44_29_NOTION_METADATA_READBACK_TEST_V1',
 'classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
 'live_notions_read_on':'2026-10-22','readback_batches':3,
 'evidence_basis':'29 DIRECT NOTION FETCH RESPONSES IN CURRENT CONVERSATION; edit stamp/parent only',
 'explicit_limitation':'Values transcribed from live fetches that matched the R15 dates; not proof of full page body byte identity.',
 'baseline':rows,'current_readback':rows,
 'timestamps_changed_in_readback':0,'contents_sha256_captured':False,
 'canonical_writes':0,'physical_rc5_approved':0,'party_release':False}
(base/'data/r44_29_notion_metadata_readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
js="const m=require('./src/r44_recipe_freshness');let a=require('./data/r44_29_notion_metadata_readback.json');let p=m.compareR44SourceStamps(a.baseline,a.current_readback);process.stdout.write(JSON.stringify(p,null,2)+'\\n');if(p.verdict!=='NO_TIMESTAMP_DRIFT_OBSERVED')process.exit(1)"
p=subprocess.run(['node','-e',js],cwd=base,capture_output=True,text=True,check=True)
(base/'outputs/CRAFT_R44_STAMP_COMPARE_MESTRE_TEST.json').write_text(p.stdout)
print('R44 29/29 metadata compared: NO_TIMESTAMP_DRIFT_OBSERVED, never physical or content-hash certification')
