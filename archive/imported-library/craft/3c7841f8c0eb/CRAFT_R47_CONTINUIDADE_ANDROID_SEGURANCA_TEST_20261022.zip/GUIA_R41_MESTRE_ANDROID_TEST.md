# Guia rápido — Mestre no celular · CRAFT R41 TEST

1. Abra `REVISOR_LOCAL_ANDROID_R53_TEST.html` **somente em ambiente privado Mestre-side**. Se o Android impedir acesso local, não contorne bloqueios de segurança; os documentos CSV/JSON podem ser lidos separadamente.
2. Abra **R40 — 50 perguntas históricas**. Escolha a receita e anote informações sem pressa; os campos de origem são apenas leitura. Há 21 receitas e o upstream Óleo de Vedação.
3. Toque **Salvar 50 anotações não autenticadas** para guardar um JSON no telefone. Ele não prova que o Mestre autorizou nada; só preserva texto.
4. Use **Importar minuta anterior** para continuar. Se ID, texto de pergunta, URL, permissão ou estrutura tiverem mudado, o arquivo será rejeitado sem substituir as notas presentes.
5. **Baixar triagem sem texto** gera um resumo de contagem, sem transcrever as respostas, para o Comestre conferir sem distribuir segredos inadvertidamente.
6. Para medições materiais, vá a **R35 — Preencher coleta R46 pelo celular**. Preencha apenas observações genuínas e links verificáveis. Deixe desconhecidos vazios. O JSON segue sendo relato sem laudo.

**Não compartilhar com Party/O Primeiro.** O HTML não escreve no Notion; respostas não autorizam mudanças de ingrediente, receita, rank, PA, estoque, RC5 ou fabricação. Os testes móveis são simulados; o aparelho real ainda não foi certificado.
