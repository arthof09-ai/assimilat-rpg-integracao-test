# CRAFT R28 — continuidade técnica TEST da bancada R53/R20/R25

**Não é nova norma, engine, receita, laudo, programa de produção ou permissão de escrita.** Extende os arquivos originais R53/R20 e preserva os artefatos R25, onde R22–R25 já haviam sido validados. Mestre-side only.

### R26 — dúvidas materiais viraram pedidos por nó

`build_mobile.py` agora incorpora o readback de pesquisa R25 e o reapresenta na interface original R53 sem atribuir fonte/compatibilidade. Ao baixar o roteiro existente R14, a seção `targeted_material_requests` contém Sonda:B3, Tônico:B3 e Tônico:B4, cada um com cinco perguntas específicas e ficha de coleta R46 inteiramente vazia. Um JSON importado alterado, mesmo com o mesmo proposal_id, NÃO herda os pedidos dos exemplos originais.

### R27 — dossiê de 21 receitas original, não duplicado

O mesmo HTML oferece a fila `CRAFT_R27_DECISION_QUEUE_MESTRE_TEST.json` ordenada por prioridade, usando o **mesmo arquivo** DECISION_REGISTER.json do dossiê pré-existente CRAFT_DECISION_DOCKET_34_20261021.zip. SHA256 da fonte `6ea83f2b702f5624694db6e83378208827fc1e2a3a99f40e255e6f307137269e` comprovado antes da inclusão. 21 UUIDs distintos/20 chaves de padrão; 7 dependências transversais; nenhuma emissão de decisão autoral, REC-ID, ticket ou mutação. Fonte congelada em 21/10/2026, não retrato ao vivo.

### R28 — reabertura física no Notion por UUID

21/21 páginas do dossiê R27 reabertas na conta **Mestre**, todos os UUIDs sob a árvore `Itens`, last-edited exibido em 02/10/2026. `data/r28_readback_21.json` registra cada ID, parent e data. Nenhum last-edited posterior ao dossiê 21/10; **somente prova de frescor do metadado**, não comparação integral de body com hash de versões históricas. Oito outras receitas (sem issues no dossiê) não foram reabertas nesta R28, sem atribuir RC5 nem completude global.

### Testes e reprodução

R25 base: **683/683** verificações JS e **461/461** Chromium inline. R26 +55 JS/+51 UI; R27 +23 JS/+24 UI; R28 +161 JS; cumulativo **922/922 JS** (17 suites) e **536/536 UI Chromium inline** (13 scripts). 2.000 vetores de fuzz sintético informacional à parte. Saídas QA/prévia testadas contra R25, byte-idênticas (SHA256 `b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541` e `509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8`). `OUTPUT_COMMIT.json` do runner verifica OK. Nenhum Android físico foi testado.

```bash
node src/run.js
node src/verify_outputs.js
for f in tests/*.js; do node "$f"; done
for f in tests/test_browser_*.py tests/test_mobile_browser_r9.py; do python "$f"; done
python tests/export_current_r27.py
```

Para testar UI é necessário Chromium + Playwright Python, com HTML injetado sem rede. `tests/export_current_r27.py` exporta o pedido de evidência e a fila diretamente da interface; não fabrica dados.

### Ponto de continuidade

F5 P0 RED, C19-021 UNKNOWN, IBX-38 fencing **não demonstrado**, IBX-116 sem ACK, R51 parent REC-LIB não comprovado, RC5/P4/produção HOLD. OP/LAB/IBX no Notion registravam CRAFT até R13; R14–R28 não sincronizados devido a ausência de capacidade de escrita. Ferramenta de leitura continua permitida; não contornar. Nenhum item, receita, estoque, PA, Party ou O Primeiro alterado.

**NEXT:** obter dados físicos verdadeiros R46 para B3 Sonda e B3/B4 Tônico; decisão humana para P2 e aliases de receitas; liberação somente após fencing externo e governança legítima; reabrir Notion e registrar uma única consolidação sem duplicar o diário.
