# CRAFT R14 — roteiro de coleta de evidências no mesmo revisor offline

**MESTRE-SIDE / TEST somente.** Não é novo motor CRAFT, nem substitui o laudo original R46, REC-EXEC, PR-ITEM-02, PA, DMG ou procedimentos científicos.

## Capacidade prática nova

A interface Android offline existente (`REVISOR_LOCAL_ANDROID_R53_TEST.html`) agora exibe, por projeto, as próximas evidências necessárias diretamente dos `holds` do validador, por P0/P1/P2: releitura das fontes Mestre, identificação e dosagem da BOM, parâmetros reprodutíveis da receita, mecânicas, ensaios R46 e quatro dimensões de economia. Não inventa material, medida, custo nem transferências mágicas. O botão **Baixar roteiro de evidências (Mestre TEST)** exporta um JSON de solicitação para ambos os projetos sem campos de segredos, com ações marcadas `PENDENTE_NAO_OBSERVADO`, dados observados `null` e produção/Party false. A funcionalidade trabalha sobre a saída original `valid`, não gera nova autoridade científica nem assina laudos.

## Testes

- `node` 11 suítes anteriores: 440/440 asserções JS (R53–R13), inalteradas.
- Fuzz tipado: 2.000 sondagens determinísticas separadas.
- Chromium inline sob viewport 390×844, testes R9 15/15 + R11 20/20 + R12 16/16 + R14 40/40 = 91/91 verificações de interface (mesmo aplicativo).
- Exports: esquema TEST, sem segredos Mestre, sem preço inventado ou sucesso físico, importação inválida preserva roteiro anterior, sem requisições HTTP, sem overflow horizontal.
- `src/run.js`, `src/validate.js`, `src/verify_outputs.js`, QA, prévia e `OUTPUT_COMMIT.json` idênticos ao R13. Apenas `build_mobile.py` e HTML TEST e tests de interface mudaram.

## Gates

R46 continua dono dos laudos/observações reais. R14 é somente solicitação e checklist; envio pelo operador, custódia, instrumento e validação independentes são externos. Não habilita F5/RC5/P4/PRODUÇÃO, writer, ACK, receita ou Player. C19-021 UNKNOWN, IBX38 fencing e R51 destino físico HOLD. Uso no Android real ainda não demonstrado: Chromium em tela móvel não certifica instalação nem abertura file:// no aparelho.
