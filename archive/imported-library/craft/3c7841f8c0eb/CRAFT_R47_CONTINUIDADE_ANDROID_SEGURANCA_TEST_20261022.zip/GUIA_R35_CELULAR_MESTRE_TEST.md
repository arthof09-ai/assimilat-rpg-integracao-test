# Guia rápido — CRAFT R35 no Android (MESTRE-SIDE / TEST)

1. Abra o arquivo **REVISOR_LOCAL_ANDROID_R53_TEST.html**. Se o Android impedir arquivos locais, não contorne controles de segurança nem considere o teste Chromium do laboratório como validação física do aparelho. O site oficial do RPG não foi alterado nesta execução.
2. Para decidir **qual sal**, **qual componente 1x**, a quantidade `Ex` e outras questões, abra **R31 — Decisões do Mestre**, digite o que souber em uma ou mais perguntas e salve o JSON. As respostas são apenas uma **minuta**; o executor deverá autenticá-las com o Mestre e conferir novamente as fontes.
3. Clique em **R32 — Baixar plano de impacto** para visualizar as verificações necessárias após cada resposta; não significa alteração de fórmula.
4. Para um ensaio de verdade, abra **R35 — Preencher coleta R46** e expanda o nó certo. Registre somente os fatos e links reais: amostra, lote, operador, instrumento, calibração, medições, controles, cadeia de custódia, revisão independente. **Não preencha o que não foi observado**. Salve o relato.
5. Importe esse relato na seção **R29**. A triagem informa quais campos foram preenchidos ou faltam, mas não atribui PASS físico. O arquivo bruto deve ir a revisor humano independente, de acordo com R46.
6. Na seção **R27**, baixe o **plano R33** para continuar a fila existente: Vedação, Matriz de Cultivo, Matriz de Proteção, 18 outras receitas, três nós materiais, bloqueios F5/R51.

**Informações estritamente Mestre-only.** Não enviar o HTML, arquivos JSON ou laudos contendo segredos para a Party/O Primeiro. Antes de produzir, vender ou disponibilizar item, exigir as normas e gates canônicos aplicáveis.
