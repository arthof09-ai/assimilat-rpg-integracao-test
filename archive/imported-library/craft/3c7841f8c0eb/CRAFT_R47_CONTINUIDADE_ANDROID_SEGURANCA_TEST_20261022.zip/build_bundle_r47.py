"""Assemble deterministic R47 TEST archive and hashed manifest. No Notion writes."""
from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parent
archive=root.parent/'CRAFT_R47_CONTINUIDADE_ANDROID_SEGURANCA_TEST_20261022.zip'
manifest=root/'MANIFEST-R47.json'
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST-R47.json' and '__pycache__' not in p.parts and p.suffix!='.pyc')
m={'schema':'CRAFT_R47_TEST_MANIFEST_V1','classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY','source_checkpoint':'R44','output_checkpoint':'R47','claims':{'canonical_writes':0,'party_writes':0,'physical_rc5_approved':0,'android_hardware_certified':False},'files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
paths=files+[manifest]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9,strict_timestamps=True) as z:
 for p in paths:
  n=p.relative_to(root).as_posix();info=zipfile.ZipInfo(n,date_time=(2026,10,22,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('R47',archive,'files',len(files),'manifest',manifest.name,'ZIP bytes',archive.stat().st_size,'SHA256',hashlib.sha256(archive.read_bytes()).hexdigest())
