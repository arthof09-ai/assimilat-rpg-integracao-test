# CRAFT — R17 | Metodologia operacional aplicada a recursos, itens e receitas

**Classificação:** MESTRE-SIDE / TEST / PROPOSTO como melhoria de utilização; **não** é norma, aprovação, receita RC5 nem alteração do Notion. **Origem:** checkpoint R16 recuperado da Biblioteca e normas vivas do RPG consultadas em 22/10/2026. **Objetivo:** tornar a metodologia vigente *executável como uma revisão consistente*, e não inventar outra cadeia de criação.

## 1. Fontes canônicas e hierarquia de consulta

1. **PR-CRN-01 — Criação de Recurso Novo**: https://app.notion.com/p/3eec2b324ede819fbe0ed4af1a4cb3aa. Gate Zero EXISTING-FIRST, BUSCA-CRN, dossiê A–N, teste dos sete encaixes; RC-MIN para usar um recurso em crafting; F5 obedece DIR-003 e STOP material.
2. **PR-ITEM-02 — Padrão Universal de Criação de Item**: https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4. Ficha universal I–XIII, física, mecânica, poder, geografia, cadeia material, economia, sociedade, história e conhecimento.
3. **REC-EXEC e REC-LIB-01 — Biblioteca de Receitas**: https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702. Um REC-ID físico único, BOM/processo, versão/linhagem, RC0–RC5, produto, material, energia, condições, rendimento/perdas, falhas, operador, ferramenta, controle epistemológico. A localização física comum segue sem comprovação R51.
4. **PR-SC-01 — Semicanonicidade**: https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1. Estados P0→P4/PS; não promover por silêncio. Produto ≠ receita ≠ conhecimento ≠ ocorrência ≠ autorização de fabricação; RC e PS são eixos independentes.
5. **PR-ECO Anexo C — Árvore de Custo**: https://app.notion.com/p/3eec2b324ede8102b3f3e6c8851ad1e7. Unidades econômicas UTE, custo dos insumos e de oportunidade, processamento, risco/perdas, trabalho, equipamento, logística, conhecimento, conservação, mercados/época. Rank não decorre de preço.
6. **REC-MOD-POC-01, REC-MOD-ENC-01, REC-MOD-MAT-01**: https://app.notion.com/p/3f1c2b324ede810f91edd002c4bfb855, https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6, https://app.notion.com/p/3f1c2b324ede819ca142cbf1eb992fac. Especificidades: veículo de poção, meio/substrato de inscrição, ancoragem/energização de matriz. Não transformar módulo em autoridade paralela.
7. **OP CRAFT, LAB, NAC e ordens do Mestre**: https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516; https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00. STOP/fencing/segredo prevalecem sobre prontidão documental.

## 2. Fluxo prático em uma trilha — sem criar nova regra

**PASSO A — Pedido e produto**: declarar função, usuário, contexto, vantagem/limite e distinção do que já existe. Pesquisar separadamente **produto existente, receita histórica/equivalente e insumos por função**. Buscar por sinônimo e ancestralidade de UUID; busca pontual incompleta não comprova inexistência.

**PASSO B — Recurso necessário**: para cada nó BOM, identificar papel funcional, proveniência, forma física, unidade, compatibilidade e estado da evidência (VERIFICADO/INFERIDO/PROPOSTO/PENDENTE). Reutilizar fontes. Se faltar veículo, fecho ou recipiente **não** inventar recurso sobrenatural; buscar componente comum e compatibilidade. Só acionar PR-CRN-01 com lacuna global comprovada e necessidade ligada a produto/receita. F5 não é quota automática.

**PASSO C — Item**: desenhar o objeto físico verificável (suporte, interface, dimensões, equipamento, conservação), efeito proposto e contraprova. Separar rank do ITEM (RI), rank do EFEITO (RE) e RIn/FIP do recurso: não inferir nenhum dos demais. Especificar ativação, alcance, duração, alvos, recarga, restrições e comparação; PA somente com fornecedor aplicável e recibo de versão.

**PASSO D — Receita**: reaproveitar fórmula canônica quando existir; variante deve preservar linhagem/REC-ID próprio autorizado. BOM com nós, quantidades e unidades operacionais, consumo versus catalisador reutilizável; processo referenciando os MESMOS nós (BOM↔processo, verificando faltas e aliases). Condições ambientais, instrumento, especialista, duração, rendimento, perdas, falhas, descarte, subprodutos e energização documentados; dado não medido fica PENDENTE. Testar compatibilidade, não presumir transferência de propriedades mágicas.

**PASSO E — Física e custo**: planejamento de experimento não é ensaio real; R46 exige amostra, lote, instrumento calibrado, operador, controle, medida/incerteza, observação de efeito, custódia e laudo. Economia: custo total de execução ≠ faixa de preço da matéria-prima ≠ preço de mercado do produto ≠ preço efetivo de venda. Se faltar dose/lote/rendimento/rota, nenhum número derivado ganha precisão fictícia.

**PASSO F — Estados e publicação**: manter separados `proposta do recurso`, `item`, `fórmula`, `conhecimento da fórmula`, `ocorrência instalada` e `disponibilidade/estoque`. Resultado RC5/P4/PS exige gates próprios; Party jamais recebe segredo Mestre. Para F5, C19-021 UNKNOWN e IBX38 fencing não demonstrado impedem gravação material independentemente da qualidade do texto.

## 3. Aplicação concreta do R17 ao R53 (fatos de software, não produção)

| Objeto TEST | Recurso documentado por ID | Ausência de fonte/compatibilidade | Receita e item |
| --- | --- | --- | --- |
| Sonda de Eco Estático | Cobre do Trovão e Quartzo Elétrico, 2 fontes distintas read-only | Nó B3: suporte/fecho físico, quantidade/unidade; transferência para detecção não demonstrada | 3 nós BOM, 0 quantificados; 5 etapas apenas propostas; efeito, rank, PA, tempo, rendimento, perda, especialista, armazenamento pendentes |
| Tônico Experimental de Passo Elétrico | Capim Relâmpago de Flashgrass e Raiz de Condutor, 2 fontes distintas read-only | Nós B3 (veículo líquido) e B4 (recipiente); extração, dose e compatibilidade não demonstradas | 4 nós BOM, 0 quantificados; 5 etapas apenas propostas; 0 lote real, efeito/rank/PA/custo de produto não demonstrados |

**Conferência de identidade das 5 fontes R53:** Cobre do Trovão, Quartzo Elétrico, Fulgurite Mística, Capim Relâmpago e Raiz de Condutor reabertos em Notion; IDs/nomes e last_edited permaneciam iguais ao snapshot R53 na leitura de 22/10/2026. Mesmo com isso, o reuso futuro requer readback atualizado. Os 2 produtos acima continuam HOLD_TEST_DESIGN e **não** representam novas fichas.

O R17 **não** adiciona uma nova condição de aprovação: o campo `methodology` no mesmo relatório `QA_RESULT.json` apresenta triagem separada de recurso/item/receita baseada exclusivamente em dados que o validador já examina. O recibo R13 passa a cobrir esse campo por SHA. O HTML R16 exibe a trilha por projeto e o pedido de evidências R14 inclui o resumo **sem master_secrets**. Os valores explícitos `false` são bloqueios do ambiente TEST e **não** prova da inexistência mundial de recursos ou de autorização em outros cenários.

## 4. Auditoria de um legado canônico — Matriz de Cultivo e Óleo de Vedação

**VERIFICADO por R15, preservado sem escrita:** corpus T-09 de 29 UUIDs de receitas, 21 com divergências registradas e oito sem divergências identificadas nesse recorte; óleo aparece em 29/29 textos e é nomeado em 28/29 BOM. A receita da [Matriz de Cultivo](https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6) tem `1x` seguido de UUID de ingrediente inacessível; abaixo, lista de obtenção chama o componente de Óleo de Vedação. A ficha [Óleo de Vedação Mestre](https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd) é candidata **INFERIDA** à remissão, não equivalência histórica comprovada. Não usar páginas homônimas da Party como destino.

**Vícios de método detectados sem corrigir cânone:** na mesma matriz, BOM diz Terra Encantada e Essência de Água da Nascente, mas o processo cita Terra de Gigante e Água de Nascente Élfica. Não presumir aliases nem excluir nós; exigir reconciliação autoral e evidência por função. A receita física do Óleo Mestre apresenta 3x Pó de Ferro Celestial, enquanto o processo usa termos como Orvalho de Dragão/Essência de Vórtice não reconciliados com a BOM de Amanhecer/Lua Minguante. Isso bloqueia fabricação inferida. A etapa `Ex Pó de Quartzo Fantasma` da Matriz de Proteção segue sem quantidade numérica. O R17 não reescreve essas fichas nem as promove.

## 5. Aperfeiçoamentos editoriais PROPOSTOS, sem substituir normas

- Acrescentar aos formulários e recibos operacionais **uma única visão de três camadas**: RECURSO (existente/lacuna evidenciada) → ITEM (efeito/RI/RE/PA/objeto) → RECEITA (REC-ID, BOM→processo, condições e laudo). Campos são **visões de dados existentes**, sem mudar PR-CRN, PR-ITEM, REC-EXEC ou PR-SC.
- Tornar visível o motivo concreto de HOLD por nó e por gate: um material desconhecido **não** vira automaticamente novo CRN; um ingrediente de 1x sem URL confiável **não** vira substituição silenciosa.
- Preservar UUID/parent de receitas e suas variantes, evitando tratar `MAT-01` Nível 2 e Nível 4 como duplicatas; jamais usar apenas o título genérico “Receita” como chave.
- Melhorar a ergonomia Android por paginação **já existente**, seção de triagem e exportação do pedido; não criar app concorrente nem exigir custo pago.
- Quando houver ferramentas de escrita e autoridade, submeter qualquer eventual delta às normas vigentes NAC-NORM/NAC-PASS, com ANTES/DEPOIS/readback e sem tocar Party por reflexo.

## 6. Situação dos bloqueios externos em 22/10/2026

- IBX38 — `NOVA`, `Exige ACK=YES`; fencing técnico do predecessor não atestado. C19-021 `UNKNOWN-EFFECT`; sem retry cego.
- IBX116 — `NOVA`, `Exige ACK=YES`; não autodeclarar leitura do destinatário.
- R51 — `NOVA` e destino físico REC-LIB não provado. Nenhuma pasta nova por inferência.
- Notion connector Mestre: leitura disponível; `notion_update_page` **não** consta como habilitado. R14–R16 e este R17 permanecem fora das páginas LAB/OP/Inbox enquanto não houver autorização técnica. Não inferir sincronização da existência de um arquivo.
- Party/O Primeiro **NO-WRITE**; 0 receita/objeto/estoque/PA canônico alterado. R46 metrologia física e H2 magia não foram executados nesta rodada.

**NEXT:** preservar R17 no acervo Mestre, ler recibo/manifesto em cópia limpa e, quando a integração permitir, adicionar 1 checkpoint aos mesmos LAB/OP/Inbox com readback, sem novo ticket. Avançar na coleta de dados reais para a Sonda/Tônico via R46, ou na decisão autoral de reconciliação da Matriz/Óleo quando os gates materiais forem efetivamente satisfeitos.
