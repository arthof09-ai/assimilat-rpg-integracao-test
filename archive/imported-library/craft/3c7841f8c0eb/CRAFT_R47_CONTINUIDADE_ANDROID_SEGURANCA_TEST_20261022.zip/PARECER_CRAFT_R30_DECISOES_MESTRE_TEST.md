# CRAFT R30 — Perguntas autorais prontas para despacho (Mestre / TEST)

Reutiliza o dossiê original das 21 receitas; não cria nova autoridade, regra, receita, registro físico, identidade ou decisão em nome do Mestre.

**Escopo:** 3 receitas físicas prioritárias e 1 insumo compartilhado (Óleo). Os demais 18 casos do dossiê permanecem na fila R27. As 8 sem divergência lexical não estão homologadas.

**Estado:** proposta de perguntas, não resposta nem autorização. Links abaixo são Mestre-only.


## ENC-08 — P0_RECEITA_P2

Fonte: https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8

**SALT_IDENTITY** — BOM: 2x Sal de Geodo Santo; processo: Sal de Geodo Encantado.

Pergunta ao Mestre: Qual substância é efetivamente consumida e qual a fonte oficial?

Decisão: **PENDENTE (campo não preenchido)**.

**ENERGY_ALTERNATIVE** — BOM: 2x Pedra da Luz OU 2x Pote de Essência Mágica; processo: sem etapa inequívoca de instalação/uso desta fonte.

Pergunta ao Mestre: As rotas são alternativas exclusivas? Qual unidade real, procedimento, operador e consumo comprovado?

Decisão: **PENDENTE (campo não preenchido)**.


## MAT-03 — P1_REFERENCIA_CONSUMO

Fonte: https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6

**BROKEN_1X_REFERENCE** — BOM: 1x [referência antiga 707d83314e7c40cd89bc70fb240e6076]; processo: menção Óleo de Vedação na localização, sem uso em etapa de processo.

Pergunta ao Mestre: O componente 1x deve apontar à ficha Óleo de Vedação Mestre 3edc2b324ede81f1a88ec69980ab6cfd? Somente após decisão e fencing.

Decisão: **PENDENTE (campo não preenchido)**.

**EARTH_ALIAS** — BOM: 5x Terra Encantada; processo: Terra de Gigante.

Pergunta ao Mestre: São o mesmo material? Se não, qual é o BOM e qual é a etapa correta?

Decisão: **PENDENTE (campo não preenchido)**.

**WATER_ALIAS** — BOM: 3x Essência de Água da Nascente; processo: Água de Nascente Élfica.

Pergunta ao Mestre: Identidades e unidades são equivalentes? Qual fonte autoral?

Decisão: **PENDENTE (campo não preenchido)**.


## MAT-06 — P1_REFERENCIA_CONSUMO

Fonte: https://app.notion.com/p/3edc2b324ede8129a6c3cfb603027383

**EX_QUANTITY** — BOM: Ex Pó de Quartzo Fantasma; processo: uso sem número definido.

Pergunta ao Mestre: Qual quantidade numérica e unidade explicitamente autorizadas? Proibido interpretar Ex como um número.

Decisão: **PENDENTE (campo não preenchido)**.

**WIND_ALIAS** — BOM: 1x Sopro de Vento Mundial; processo: Sopro de Vento Ancestral.

Pergunta ao Mestre: Qual identidade material correta e como reconciliar a etapa?

Decisão: **PENDENTE (campo não preenchido)**.

**ENERGY_OIL_STEPS** — BOM: 1x Óleo de Vedação; 5x Pedra da Luz OU 5x Pote de Essência Mágica; processo: sem passos inequívocos dos dois consumos.

Pergunta ao Mestre: Qual a etapa, rota energética exclusiva e evidência física?

Decisão: **PENDENTE (campo não preenchido)**.


## UPSTREAM_OIL — UPSTREAM_SHARED

Fonte: https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd

**OIL_POWDER** — BOM: 3x Pó de Ferro Celestial (ficha Mestre); processo: espelho Party histórico 2x não autoriza troca.

Pergunta ao Mestre: Manter ficha Mestre como fonte; decidir somente inconsistências materiais com autoridade.

Decisão: **PENDENTE (campo não preenchido)**.

**OIL_DEW** — BOM: Gota do Orvalho do Amanhecer; processo: Orvalho de Dragão.

Pergunta ao Mestre: Qual insumo e processamento estão corretos?

Decisão: **PENDENTE (campo não preenchido)**.

**OIL_ESSENCE** — BOM: Essência de da lua minguante; processo: Essência de Vórtice.

Pergunta ao Mestre: Qual identidade funcional e evidência de transformação?

Decisão: **PENDENTE (campo não preenchido)**.


## Gates conservados

- C19-021 UNKNOWN + fencing técnico IBX38 sem atestado; R51/REC-LIB sem destino físico; sem writer/lease/epoch e sem ACK.

- RC5/P4/produção, inventário, PA e publicação Party continuam bloqueados.

- Nenhuma decisão desse papel substitui R46, provas de ingredientes, operador ou classificação do efeito.

- R30 TEST apenas. Próximo passo: Mestre resolver identidade; depois revalidar BOM↔processo nos módulos PR-ITEM/REC-EXEC, seguindo NAC-NORM/NAC-PASS.
