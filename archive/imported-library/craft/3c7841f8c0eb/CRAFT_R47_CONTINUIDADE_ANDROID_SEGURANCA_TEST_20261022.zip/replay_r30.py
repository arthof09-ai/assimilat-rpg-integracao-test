from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST-R30.json').read_text())
for name,digest in m['files'].items():
 p=root/name
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest, ('MANIFEST_FAIL',name)
print('R30 manifest PASS',len(m['files']))
for path in sorted((root/'tests').glob('*.js')):
 subprocess.run(['node',str(path)],cwd=root,check=True,stdout=subprocess.DEVNULL)
print('R30 JS SUITES PASS',len(list((root/'tests').glob('*.js'))))
subprocess.run(['node','src/run.js'],cwd=root,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['node','src/verify_outputs.js'],cwd=root,check=True,stdout=subprocess.DEVNULL)
assert hashlib.sha256((root/'outputs/QA_RESULT.json').read_bytes()).hexdigest()=='b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'
assert hashlib.sha256((root/'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json').read_bytes()).hexdigest()=='509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8'
print('R30 source QA/preview identical PASS, receipt PASS')
