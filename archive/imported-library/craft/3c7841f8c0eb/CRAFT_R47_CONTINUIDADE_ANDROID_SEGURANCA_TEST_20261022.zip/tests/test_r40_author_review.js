'use strict';const assert=require('assert');const fs=require('fs');const path=require('path');
const root=path.resolve(__dirname,'..');const baseline=JSON.parse(fs.readFileSync(path.join(root,'data/r40_50_author_notes_baseline.json'),'utf8'));
const {reviewR40Draft}=require('../src/r40_author_review.js');
let n=0;const ok=(x,label)=>{assert.ok(x,label);n++};const fresh=()=>JSON.parse(JSON.stringify(baseline));
const pass=(o)=>reviewR40Draft(o,baseline).verdict==='NOTES_TRIAGED_NOT_AUTHENTICATED';
const reject=(o)=>reviewR40Draft(o,baseline).verdict==='REJECT_UNTRUSTED_NOTES';
ok(baseline.cases.length===22,'case count');ok(baseline.denominators.total_questions===50,'slots contract');
ok(baseline.cases.reduce((n,c)=>n+c.slots.length,0)===50,'slot total');ok(pass(fresh()),'clean baseline pass');
ok(reviewR40Draft(fresh(),baseline).notes_pending===50,'initial pending');
ok(baseline.cases.filter(c=>c.original_source==='R39').length===13,'R39 13 only');
ok(new Set(baseline.cases.map(x=>x.physical_recipe_id)).size===22,'no duplicate parent recipes');
ok(baseline.no_canonical_write&&baseline.no_player_release&&baseline.no_rc5_approval,'no authorization');
for(const [f,v] of [['schema','FAKE'],['no_rc5_approval',false],['classification','PUBLIC'],['no_canonical_write',false],['no_player_release',false],['fencing_verified',true],['r51_single_parent_verified',true],['all_notes_blank',false]]){
 let x=fresh();x[f]=v;ok(reject(x),'root tamper '+f)
}
for(const p of ['source_url','physical_recipe_id','key','original_source','priority']){let x=fresh();x.cases[0][p]='changed';ok(reject(x),'case tamper '+p)}
for(const p of ['bom_literal','process_literal','slot_id','question','issue_class']){let x=fresh();x.cases[0].slots[0][p]='changed';ok(reject(x),'slot tamper '+p)}
for(const value of ['',123,true,{},[],'x'.repeat(1501),'\u0000','\u000b','\u000d','\u007f']){let x=fresh();x.cases[0].slots[0].author_note=value;x.all_notes_blank=false;ok(reject(x),'reject invalid note')}
for(const value of ['resposta textual sem autoria','linha 1\nlinha 2','<script>alert(1)</script>','MESTRE CONFIRMOU MAS NÃO AUTENTICADO','x'.repeat(1500)]){
 let x=fresh();x.cases[0].slots[0].author_note=value;x.all_notes_blank=false;
 const y=reviewR40Draft(x,baseline);ok(y.verdict==='NOTES_TRIAGED_NOT_AUTHENTICATED','note as untrusted only');
 ok(y.notes_reported===1&&!y.notes_authenticated&&!y.notion_write_allowed&&!y.rc5_allowed&&!y.party_release_allowed,'never authorizes');
 ok(JSON.stringify(y).indexOf(value)===-1,'triage does not echo user text');
}
let x=fresh();x.cases[0].slots[0].author_note='Teste';x.all_notes_blank=true;ok(reject(x),'flag drift');
x=fresh();x.cases.pop();ok(reject(x),'case removed');
x=fresh();x.cases.push(x.cases[0]);ok(reject(x),'case added');
x=fresh();x.cases[0].slots.shift();ok(reject(x),'slot removed');
x=fresh();x.cases[0].slots.push(x.cases[0].slots[0]);ok(reject(x),'slot duplicated');
x=fresh();x.cases.reverse();ok(reject(x),'case order changed');
x=fresh();x.cases[0].slots.reverse();ok(reject(x),'slot order changed');
x=fresh();delete x.cases[0].slots[0].author_note;ok(reject(x),'note field dropped');
x=fresh();x.mestre_authority='APPROVED';ok(reject(x),'extra approval field');
x=fresh();x.cases[0].slots[0].authorization=true;ok(reject(x),'extra slot field');
x=fresh();x.cases[0].slots[0].author_note='valid';x.all_notes_blank=false;x.cases[10].slots[0].author_note='anotação';
let v=reviewR40Draft(x,baseline);ok(v.notes_reported===2&&v.notes_pending===48,'two notes accepted only as text');
ok(v.cases[0].notes_reported===1,'case tracked');ok(v.cases[10].notes_reported===1,'independent case tracked');
ok(!v.recipe_modified&&!v.physical_material_verified&&!v.author_mestre_identity_verified,'gates remain');
let last=fresh();for(const c of last.cases)for(const s of c.slots)s.author_note='texto provisório';last.all_notes_blank=false;
v=reviewR40Draft(last,baseline);ok(v.notes_reported===50&&v.notes_pending===0,'all 50 still draft');
ok(!v.rc5_allowed&&!v.party_release_allowed&&!v.notion_write_allowed,'all notes never release');
const r39=JSON.parse(fs.readFileSync(path.join(root,'data/r39_remaining_13_recipe_readback.json'),'utf8'));
ok(r39.coverage.original_issue_recipes===21,'original 21');ok(r39.coverage.remaining_issue_recipes===0,'13 covered');
ok(r39.cases.length===13,'13 sources');ok(r39.coverage.R39_questions===27,'27 new');ok(r39.gates.mestre_decisions_authenticated===false,'not decisions');
const docket=JSON.parse(fs.readFileSync(path.join(root,'outputs/CRAFT_R27_FILA_21_RECEITAS_MESTRE_TEST.json'),'utf8'));
for(const c of r39.cases)ok(docket.cases.some(x=>x.physical_recipe_id===c.physical_recipe_id),'same physical id '+c.key);
for(const c of r39.cases)ok(c.decision_slots.every(s=>s.decision===null&&s.physical_equivalence_verified===false),'all undecided '+c.key);
console.log('R40 Author note coverage: '+n+'/'+n+' PASS');
