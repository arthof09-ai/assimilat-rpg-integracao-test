from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,json
root=Path(__file__).resolve().parents[1];html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
checks=0
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errs=[];net=[];page.on('pageerror',lambda e:errs.append(str(e)));page.on('request',lambda r:net.append(r.url) if r.url.startswith(('http:','https:')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('#r33-continuity').is_visible();checks+=1
 with tempfile.TemporaryDirectory() as d:
  with page.expect_download() as info:page.locator('#r33-continuity').click()
  p=Path(d)/'view.json';info.value.save_as(p);x=json.loads(p.read_text())
  assert x['verdict']=='DOCUMENTAL_NEXT_STEPS_ONLY';checks+=1
  assert x['denominators']['lexical_issue_cases']==21;checks+=1
  assert x['denominators']['remaining_issues_only_in_docket']==18;checks+=1
  assert x['denominators']['pending_r46_material_nodes']==3;checks+=1
  assert len(x['priority_recipe_sources'])==3;checks+=1
  assert x['total_canonical_changes']==0;checks+=1
  assert not x['gates']['party_or_o_primeiro_write_allowed'];checks+=1
  # If a revised proposal no longer matches the R25 three nodes, refuse draft plan.
  page.evaluate("PROJECT.products[0].design+=' outra versão';render(true)")
  page.locator('#r33-continuity').click()
  assert 'bloqueado' in page.locator('#docket-summary').inner_text().lower();checks+=1
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');checks+=1
  assert not errs,errs;checks+=1
  assert not net,net;checks+=1
 browser.close()
print('R33 browser mobile continuation '+str(checks)+'/'+str(checks)+' PASS')
