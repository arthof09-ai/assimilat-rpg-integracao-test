'''R11 integração do mesmo HTML offline; não é Android físico.'''
import json,pathlib,tempfile
from playwright.sync_api import sync_playwright
p=pathlib.Path(__file__).resolve().parents[1]
html=(p/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
data=json.loads((p/'data/proposals.json').read_text())
checks=0
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--disable-gpu','--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
 errors=[];requests=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http://','https://')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('article.box').count()==2;checks+=1
 assert page.locator('article.box').filter(has_text='HOLD_TEST_DESIGN').count()==2;checks+=1
 with tempfile.TemporaryDirectory() as td:
  td=pathlib.Path(td)
  for j,(kind,fn) in enumerate([
    ('invalid_activation',lambda x:x['products'][0].update(activation={'includes':1})),
    ('invalid_source_type',lambda x:x['products'][0]['bom'][0].update(source_id=42)),
    ('invalid_step_status',lambda x:x['products'][0]['process'][0].update(status=['executado'])),
    ('missing_bom',lambda x:x['products'][0].pop('bom')),
    ('empty_bom',lambda x:x['products'][0].update(bom=[])),
  ]):
   d=json.loads(json.dumps(data));fn(d)
   f=td/f'{j}_{kind}.json';f.write_text(json.dumps(d,ensure_ascii=False))
   page.locator('#upload').set_input_files(str(f));page.wait_for_timeout(30)
   assert page.locator('#loadStatus').inner_text().startswith('Falha no arquivo: Entrada rejeitada'),kind;checks+=1
   assert page.locator('article.box').filter(has_text='HOLD_TEST_DESIGN').count()==2,kind;checks+=1
   assert not errors and not requests,(kind,errors,requests);checks+=1
  with page.expect_download() as ev:page.locator('#save').click()
  dl=ev.value;f=td/'qa.json';dl.save_as(f);r=json.loads(f.read_text())
  assert r['status']=='HOLD_TEST_DESIGN' and r['total']==2;checks+=1
  assert all(z.get('verified_production') is False for z in r['items']);checks+=1
  assert not errors and not requests;checks+=1
 b.close()
print(f'PASS {checks}/{checks} R11 Chromium inline e UI fail-closed; aparelho Android real não testado')
