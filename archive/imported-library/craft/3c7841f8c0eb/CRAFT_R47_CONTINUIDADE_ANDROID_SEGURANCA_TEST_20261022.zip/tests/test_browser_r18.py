'''R18: critical issue codes -> actionable evidence requests in existing R14/R17 UI.
No new approval rule or engine, no Party. Chromium inline only.
'''
import json,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
checks=0
cases=[
 ('party', ['PARTY_EXPOSURE'], 'Isolar camada Player'),
 ('literal_secret',['PLAYER_SECRET_CROSSOVER'],'Isolar camada Player'),
 ('fake_resource',['UNVERIFIED_RESOURCE'],'Rastrear fonte física'),
 ('alias_resource',['SOURCE_IDENTITY_MISMATCH'],'Rastrear fonte física'),
 ('phantom',['PHANTOM_INPUT'],'Reconectar BOM'),
 ('missing_bom',['MISSING_BOM'],'Reconectar BOM'),
 ('neg_qty',['INVALID_QUANTITY'],'Reconectar BOM'),
 ('rank',['RANK_SHORTCUT'],'Separar RI'),
 ('pa',['PA_UNAUTHORIZED'],'Separar RI'),
 ('fake_claim',['FABRICATION_UNVERIFIED'],'Retirar reivindicação'),
 ('false_stock',['MUTATION_NOT_ALLOWED'],'Retirar reivindicação'),
 ('fake_cost',['UNSUPPORTED_ECONOMY'],'Suspender preço'),
 ('module',['MODULE_MISMATCH'],'Reparar identidade'),
 ('not_test',['NOT_SANDBOX'],'Reparar identidade'),
 ('empty',['PROJECTS_REQUIRED'],'Reparar identidade'),
 ('unknown',['UNKNOWN_FUTURE_CODE'],'Triagem manual')
]
script='''(caseName)=>{
 let d=structuredClone(PROJECT), idx=structuredClone(INDEX);
 const p=d.products[0];
 switch(caseName){
 case 'party':p.player_view.status='PUBLICAR';break;
 case 'literal_secret':p.player_view.visible_properties=p.master_secrets;break;
 case 'fake_resource':p.bom[0].source_id='ffffffffffffffffffffffffffffffff';break;
 case 'alias_resource':idx.resources[0].name='Falsificação';break;
 case 'phantom':p.process[0].input_node_ids=['ZZ'];break;
 case 'missing_bom':p.bom=null;break;
 case 'neg_qty':p.bom[0].qty=-5;break;
 case 'rank':p.item_rank='Lendário';break;
 case 'pa':p.pa_daily=200;break;
 case 'fake_claim':p.proof.physical_prototype=true;break;
 case 'false_stock':p.proof.inventory_commit=true;break;
 case 'fake_cost':p.economy.cte_med=100;break;
 case 'module':p.module='REC-MOD-ARM-01';break;
 case 'not_test':p.proposal_id='R18-PRODUCTION';break;
 case 'empty':d={products:[]};break;
 case 'unknown':return {qa_status:'REJECT',plan:evidencePlan([{
    id:'R18-TEST-UNKNOWN',name:'TEST desconhecido',verdict:'REJECT',
    issues:[{code:'UNKNOWN_FUTURE_CODE'}],holds:[],evidence:[]}])};
 }
 const qa=valid(d,idx);
 return {qa_status:qa.status,plan:evidencePlan(qa.items)};
}'''
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors,requests=[],[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http://','https://')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('article.box').count()==2;checks+=1
 for name,expected,title in cases:
  r=page.evaluate(script,name)
  assert r['qa_status']=='REJECT',(name,r['qa_status']);checks+=1
  project=r['plan']['projects'][0]
  assert project['validator_verdict']=='REJECT';checks+=1
  assert all(e in project['blocking_errors'] for e in expected),(name,project['blocking_errors']);checks+=1
  issue_tasks=[x for x in project['missing_evidence'] if x.get('source_issue_codes')]
  assert issue_tasks,name;checks+=1
  assert any(title in a['title'] for a in issue_tasks),name;checks+=1
  assert all(x['priority']=='P0' and x['approved_for_production'] is False and x['observed_data'] is None for x in issue_tasks);checks+=1
  assert any(any(c in x['source_issue_codes'] for x in issue_tasks) for c in expected),name;checks+=1
  assert project['physical_success'] is False and project['party_release_authorized'] is False;checks+=1
  assert 'Nenhum segredo factual criado' not in json.dumps(project,ensure_ascii=False);checks+=1
 with tempfile.TemporaryDirectory() as d:
  with page.expect_download() as event:page.locator('#evidence').click()
  out=Path(d)/'request.json';event.value.save_as(out);plan=json.loads(out.read_text())
  assert len(plan['projects'])==2;checks+=1
  assert all(x['validator_verdict']=='HOLD_TEST_DESIGN' for x in plan['projects']);checks+=1
  assert all(x['methodology_snapshot']['publication_and_stock_denied'] is True for x in plan['projects']);checks+=1
  assert all(not any('source_issue_codes' in task for task in x['missing_evidence']) for x in plan['projects']);checks+=1
  assert all(x['missing_evidence'] for x in plan['projects']);checks+=1
 # Execução real no botão do Android/Chromium: inválido NÃO substitui projeto,
 # mas permite BAIXAR roteiro de correção limitado a códigos, sem segredos.
 with tempfile.TemporaryDirectory() as d:
  d=Path(d)
  source=json.loads((root/'data/proposals.json').read_text())
  source['products'][0]['pa_daily']=999
  source['products'][0]['player_view']['visible_properties']=source['products'][0]['master_secrets']
  bad=d/'invalid_proposals.json';bad.write_text(json.dumps(source,ensure_ascii=False))
  assert page.locator('#rejected-plan').is_disabled();checks+=1
  page.locator('#upload').set_input_files(str(bad));page.wait_for_timeout(120)
  assert page.locator('#loadStatus').inner_text().startswith('Falha no arquivo: Entrada rejeitada');checks+=1
  assert page.locator('article.box').count()==2;checks+=1
  assert page.locator('#pager').inner_text().startswith('Página 1 de 1');checks+=1
  assert page.locator('#rejected-plan').is_enabled();checks+=1
  with page.expect_download() as ev:page.locator('#rejected-plan').click()
  saved=d/'repair.json';ev.value.save_as(saved);j=json.loads(saved.read_text())
  assert len(j['projects'])==2;checks+=1
  assert {'PA_UNAUTHORIZED','PLAYER_SECRET_CROSSOVER'}.issubset(set(j['projects'][0]['blocking_errors']));checks+=1
  assert j['projects'][0]['party_release_authorized'] is False;checks+=1
  assert j['projects'][0]['physical_success'] is False;checks+=1
  assert j['projects'][0]['missing_evidence'][0]['source_issue_codes'];checks+=1
  assert source['products'][0]['master_secrets'] not in saved.read_text();checks+=1
  # JSON sintaticamente inválido limpa roteiro anterior (sem stale)
  broken=d/'broken.json';broken.write_text('{invalid json',encoding='utf8')
  page.locator('#upload').set_input_files(str(broken));page.wait_for_timeout(90)
  assert page.locator('#rejected-plan').is_disabled();checks+=1
  assert page.locator('article.box').count()==2;checks+=1
  # Rejeição e correção: aceitar válido cancela recibo antigo do rejeitado
  page.locator('#upload').set_input_files(str(bad));page.wait_for_timeout(100)
  assert page.locator('#rejected-plan').is_enabled();checks+=1
  fixed=d/'valid.json';fixed.write_text((root/'data/proposals.json').read_text())
  page.locator('#upload').set_input_files(str(fixed));page.wait_for_timeout(120)
  assert page.locator('#loadStatus').inner_text().startswith('Proposta TEST carregada');checks+=1
  assert page.locator('#rejected-plan').is_disabled();checks+=1
  assert page.locator('article.box').count()==2;checks+=1
 assert page.locator('#pager').inner_text().startswith('Página 1 de 1');checks+=1
 assert not errors,errors;checks+=1
 assert not requests,requests;checks+=1
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+1');checks+=1
 b.close()
print('R18 critical repair requests browser PASS',checks,'/',checks,'(Chromium inline only)')
