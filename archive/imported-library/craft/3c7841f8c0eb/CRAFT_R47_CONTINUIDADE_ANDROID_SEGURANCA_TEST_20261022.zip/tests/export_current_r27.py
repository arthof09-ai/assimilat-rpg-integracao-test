"""Exports only already validated data from R53 existing HTML; no physical claims."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, tempfile
root=Path(__file__).resolve().parents[1];dest=root/'outputs';dest.mkdir(exist_ok=True)
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.set_content(html,wait_until='load')
 for button,filename in [('evidence','CRAFT_R27_PEDIDOS_R46_3_NOS_MESTRE_TEST.json'),('docket-export','CRAFT_R27_FILA_21_RECEITAS_MESTRE_TEST.json')]:
  with p.expect_download() as ev:p.locator('#'+button).click()
  ev.value.save_as(dest/filename)
  data=json.loads((dest/filename).read_text())
  if button=='evidence':
   req=[x for proj in data['projects'] for x in proj['targeted_material_requests']]
   assert len(req)==3 and all(not any(v is not None for v in x['r46_record'].values()) for x in req)
   assert all(not x['production_or_party_release_allowed'] for x in req)
  else:
   assert len(data['cases'])==21 and len(set(c['physical_recipe_id'] for c in data['cases']))==21
   assert not data['creates_new_ticket'] and not data['physical_recipe_changed']
  print(filename,'OK',len((dest/filename).read_bytes()))
 assert not errors,errors
 b.close()
