'''CRAFT R14: comprovação de roteiro MESTRE TEST no mesmo HTML offline.''' 
import json,pathlib,tempfile
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
data=json.loads((root/'data/proposals.json').read_text())
checks=0
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    errors=[];external=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:external.append(r.url) if r.url.startswith(('http://','https://')) else None)
    page.set_content(html,wait_until='load')
    assert page.locator('article.box').count()==2;checks+=1
    assert page.locator('#evidence').count()==1;checks+=1
    assert page.locator('summary').filter(has_text='Roteiro de evidências').count()==2;checks+=1
    for article in page.locator('article.box').all():
        article.locator('summary').filter(has_text='Roteiro de evidências').click()
        s=article.inner_text()
        for phrase in ['Reler as fontes Mestre vigentes','Completar quantidades de BOM','Preparar comprovação física e mágica R46','Reconciliar economia']:
            assert phrase in s;checks+=1
    with tempfile.TemporaryDirectory() as tmp:
        out=pathlib.Path(tmp)
        with page.expect_download() as d:page.locator('#evidence').click()
        item=d.value
        assert item.suggested_filename=='CRAFT_R14_PEDIDO_EVIDENCIAS_MESTRE_TEST.json';checks+=1
        p=out/'request.json';item.save_as(p)
        plan=json.loads(p.read_text())
        assert plan['schema']=='CRAFT_R14_EVIDENCE_REQUEST_TEST_V1';checks+=1
        assert plan['classification']=='MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY';checks+=1
        assert plan['release_gate']=='NO_PRODUCTION_NO_PARTY_PUBLICATION';checks+=1
        assert len(plan['projects'])==2;checks+=1
        for req in plan['projects']:
            assert req['validator_verdict']=='HOLD_TEST_DESIGN';checks+=1
            assert req['physical_success'] is False and req['magic_transfer_proved'] is False;checks+=1
            assert req['party_release_authorized'] is False;checks+=1
            assert len(req['missing_evidence'])>=6;checks+=1
            assert all(x['state']=='PENDENTE_NAO_OBSERVADO' and x['observed_data'] is None for x in req['missing_evidence']);checks+=1
            assert all(x['approved_for_production'] is False for x in req['missing_evidence']);checks+=1
            assert all(x['priority'] in ('P0','P1','P2') for x in req['missing_evidence']);checks+=1
            assert all(u.startswith('https://app.notion.com/p/') for u in req['source_urls']);checks+=1
        payload=p.read_text()
        for product in data['products']:
            assert product['master_secrets'] not in payload;checks+=1
        assert 'item_rank' not in payload;checks+=1
        # Falha importacao não troca estado do app nem plano anterior
        attack=json.loads(json.dumps(data));attack['products'][0]['player_view']['visible_properties']=attack['products'][0]['master_secrets']
        bad=out/'bad.json';bad.write_text(json.dumps(attack,ensure_ascii=False))
        page.locator('#upload').set_input_files(str(bad))
        page.wait_for_timeout(40)
        assert page.locator('#loadStatus').inner_text().startswith('Falha no arquivo: Entrada rejeitada');checks+=1
        assert page.locator('article.box').count()==2;checks+=1
        with page.expect_download() as d2:page.locator('#evidence').click()
        p2=out/'request2.json';d2.value.save_as(p2)
        assert p.read_bytes()==p2.read_bytes();checks+=1
        assert not errors and not external,(errors,external);checks+=1
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1');checks+=1
    browser.close()
print(f'R14 Chromium mobile TEST PASS {checks}/{checks}; sem prova Android físico')
