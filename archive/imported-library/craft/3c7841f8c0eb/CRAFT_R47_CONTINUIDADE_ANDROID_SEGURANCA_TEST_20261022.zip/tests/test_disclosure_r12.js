
'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),cp=require('child_process');
const root=path.join(__dirname,'..'); const {valid,playerSafe}=require('../src/validate');
const data=JSON.parse(fs.readFileSync(path.join(root,'data/proposals.json')));
const sources=JSON.parse(fs.readFileSync(path.join(root,'data/resources.json')));
const clone=v=>JSON.parse(JSON.stringify(v));let count=0;
const good=valid(data,sources);assert.equal(good.status,'HOLD_TEST_DESIGN');count++;
function broken(label,edit,code){
 const d=clone(data);edit(d.products[0]);const result=valid(d,sources);
 assert.equal(result.status,'REJECT',label);count++;
 assert.ok(result.items[0].issues.some(i=>i.code===code),label+': '+code);count++;
 assert.ok(result.items.every(i=>i.verified_production!==true),label);count++;
 return d;
}
broken('name object',x=>x.player_view.name_if_discovered={text:'safe'},'PLAYER_FIELD_TYPE_INVALID');
broken('visible list',x=>x.player_view.visible_properties=['lista'],'PLAYER_FIELD_TYPE_INVALID');
broken('name numeric',x=>x.player_view.name_if_discovered=15,'PLAYER_FIELD_TYPE_INVALID');
broken('name whitespace',x=>x.player_view.name_if_discovered='  ','PLAYER_FIELD_TYPE_INVALID');
broken('visible empty',x=>x.player_view.visible_properties='','PLAYER_FIELD_TYPE_INVALID');
broken('visible longer than limit',x=>x.player_view.visible_properties='a'.repeat(1401),'PLAYER_FIELD_TYPE_INVALID');
broken('name longer than limit',x=>x.player_view.name_if_discovered='x'.repeat(181),'PLAYER_FIELD_TYPE_INVALID');
broken('player view array',x=>x.player_view=[],'PLAYER_VIEW_SCHEMA');
broken('player view primitive',x=>x.player_view='not an object','PLAYER_VIEW_SCHEMA');
broken('secret in player name',x=>x.player_view.name_if_discovered=x.master_secrets,'PLAYER_SECRET_CROSSOVER');
broken('secret in visible',x=>x.player_view.visible_properties='AVISO: '+x.master_secrets,'PLAYER_SECRET_CROSSOVER');
// Explicit export path: mixed batch MUST suppress ALL player previews.
const d=broken('multiple items one disclosure failure',x=>x.player_view.visible_properties={secret:1},'PLAYER_FIELD_TYPE_INVALID');
const inpath=path.join(root,'data/proposals.json');const backup=fs.readFileSync(inpath);
const oldOut=fs.readFileSync(path.join(root,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'));
try {
 fs.writeFileSync(inpath,JSON.stringify(d));
 const ret=cp.spawnSync('node',['src/run.js'],{cwd:root,encoding:'utf8'});
 assert.equal(ret.status,2);count++;
 const preview=JSON.parse(fs.readFileSync(path.join(root,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json')));
 assert.equal(preview.status,'REJECT_NO_PLAYER_PREVIEW');count++;
 assert.deepEqual(preview.items,[]);count++;
}finally{ fs.writeFileSync(inpath,backup);cp.spawnSync('node',['src/run.js'],{cwd:root,encoding:'utf8'});}
const normalized=JSON.parse(fs.readFileSync(path.join(root,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json')));
assert.ok(Array.isArray(normalized)&&normalized.length===2);count++;
assert.deepEqual(fs.readFileSync(path.join(root,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json')),oldOut);count++;
const exportItem=playerSafe(data.products[0]);
assert.ok(!JSON.stringify(exportItem).includes(data.products[0].master_secrets));count++;
assert.equal(exportItem.internal_approval,false);count++;
console.log(`R12 disclosure PASS ${count}/${count} assertions (12 mutations + fail-closed mixed-batch export)`);
