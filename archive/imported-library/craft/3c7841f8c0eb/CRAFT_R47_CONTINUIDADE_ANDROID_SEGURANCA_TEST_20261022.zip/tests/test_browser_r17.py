'''R17 methodology lens uses the SAME R53 mobile HTML. Chromium inline only; Android not certified.'''
import json,copy,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text(encoding='utf8')
base=json.loads((root/'data/proposals.json').read_text())
n=0
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors,requests=[],[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http://','https://')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('article.box').count()==2;n+=1
 assert page.get_by_text('Metodologia R17').count()==2;n+=1
 page.get_by_text('Metodologia R17').first.click();page.get_by_text('Metodologia R17').last.click()
 assert 'Recursos existentes indexados:' in page.locator('article.box').first.inner_text();n+=1
 assert 'Criação de recurso novo:' in page.locator('article.box').first.inner_text();n+=1
 assert 'NÃO AUTORIZADA' in page.locator('article.box').first.inner_text();n+=1
 assert 'Receita:' in page.locator('article.box').first.inner_text();n+=1
 assert '0/3 quantidades+unidades' in page.locator('article.box').first.inner_text();n+=1
 assert '0/4 quantidades+unidades' in page.locator('article.box').last.inner_text();n+=1
 assert 'RC5 não demonstradas' in page.locator('article.box').first.inner_text();n+=1
 with tempfile.TemporaryDirectory() as d:
  d=Path(d)
  with page.expect_download() as ev:page.locator('#save').click()
  path=d/'qa.json';ev.value.save_as(path);qa=json.loads(path.read_text())
  assert qa['total']==2;n+=1
  assert all(x['methodology']['resource']['new_crn_justified'] is False for x in qa['items']);n+=1
  assert all(x['methodology']['recipe']['rc5_demonstrated'] is False for x in qa['items']);n+=1
  assert [x['methodology']['resource']['unresolved_material_nodes'] for x in qa['items']]==[['B3'],['B3','B4']];n+=1
  assert 'master_secrets' not in json.dumps([x['methodology'] for x in qa['items']]);n+=1
  lot={'products':[]}
  for i in range(17):
   x=copy.deepcopy(base['products'][i%2]);x['proposal_id']=f'R17-TEST-BATCH-{i:03d}';x['name']+=f' — projeto {i}'
   lot['products'].append(x)
  f=d/'lot.json';f.write_text(json.dumps(lot,ensure_ascii=False));page.locator('#upload').set_input_files(str(f));page.wait_for_timeout(150)
  assert page.locator('#pager').inner_text().startswith('Página 1 de 3');n+=1
  assert page.locator('article.box').count()==8;n+=1
  page.locator('#next').click();page.locator('#next').click()
  assert page.locator('#pager').inner_text().startswith('Página 3 de 3');n+=1
  assert page.locator('article.box').count()==1;n+=1
  with page.expect_download() as ev:page.locator('#save').click()
  full=d/'full.json';ev.value.save_as(full);full_qa=json.loads(full.read_text())
  assert len(full_qa['items'])==17;n+=1
  assert all(x['methodology']['decision']['physical_fabrication_allowed'] is False for x in full_qa['items']);n+=1
  with page.expect_download() as ev:page.locator('#evidence').click()
  request=d/'request.json';ev.value.save_as(request);plan=json.loads(request.read_text())
  assert len(plan['projects'])==17;n+=1
  assert plan['projects'][0]['methodology_snapshot']['bom_total_nodes']==3;n+=1
  assert plan['projects'][1]['methodology_snapshot']['unresolved_bom_nodes']==['B3','B4'];n+=1
  assert all(x['methodology_snapshot']['publication_and_stock_denied'] for x in plan['projects']);n+=1
  assert all(x['party_release_authorized'] is False for x in plan['projects']);n+=1
  bad=copy.deepcopy(lot);bad['products'][0]['player_view']['visible_properties']=bad['products'][0]['master_secrets'];p=d/'bad.json';p.write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#upload').set_input_files(str(p));page.wait_for_timeout(150)
  assert 'Falha no arquivo' in page.locator('#loadStatus').inner_text();n+=1
  assert page.locator('#pager').inner_text().startswith('Página 3 de 3');n+=1
  assert not errors,(errors);n+=1
  assert not requests,requests;n+=1
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+1');n+=1
 browser.close()
print('R17 browser methodology mobile PASS',n,'/',n,'(Chromium inline only)')
