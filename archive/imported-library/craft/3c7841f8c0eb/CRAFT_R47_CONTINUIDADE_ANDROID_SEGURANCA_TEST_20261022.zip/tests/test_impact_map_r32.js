'use strict';const assert=require('node:assert/strict'),fs=require('node:fs');
const source=JSON.parse(fs.readFileSync(__dirname+'/../outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json'));
const {reviewAuthorDraft}=require('../src/r31_author_intake.js');global.reviewAuthorDraft=reviewAuthorDraft;
const {buildR32ImpactMap,R32_EFFECTS}=require('../src/r32_impact_map.js');let n=0;function ok(x,label){assert.ok(x,label);n++}const cp=v=>JSON.parse(JSON.stringify(v));
let x=buildR32ImpactMap(source);ok(x.verdict==='IMPACT_PLANNED_NOT_AUTHORIZED','original map');ok(x.actions.length===11,'eleven actions');ok(x.counts.child_recipe_total===29,'denominator');ok(x.counts.lexical_issue_cases===21,'issues');ok(x.counts.prioritized_recipe_cases===3,'physical recipes');ok(x.shared_dependencies.links.length===3,'three downstream');ok(x.shared_dependencies.links.filter(e=>e.conditional).length===1,'MAT03 conditional');ok(!x.recipe_rc5_approved&&!x.canonical_writer_or_fencing_verified,'holds');ok(!x.party_or_o_primeiro_release_allowed,'no Party');
for(const a of x.actions){ok(a.required_follow_up.length===3,'3 followups '+a.decision_slot);ok(a.gates.length>=6,'gate list');ok(!a.physical_recipe_updated,'no physical');ok(!a.author_note_received_not_authenticated,'empty');ok(a.source_readback_required,'readback');ok(a.source_url.startsWith('https://app.notion.com/p/'),'source');}
const d=cp(source);d.cases[0].decision_slots[0].decision='Minuta, ainda não autorizada';d.all_choices_blank=false;const r=buildR32ImpactMap(source,d);
ok(r.verdict==='IMPACT_PLANNED_NOT_AUTHORIZED','draft accepted');ok(r.actions.filter(a=>a.author_note_received_not_authenticated).length===1,'notes count');ok(!r.all_author_decisions_authenticated,'no authority');ok(!JSON.stringify(r).includes('Minuta, ainda não autorizada'),'never exposes notes');
const bad=cp(d);bad.cases[0].physical_recipe_id='fake';ok(buildR32ImpactMap(source,bad).verdict==='REJECT_SOURCE_DRIFT','tamper');
const wrong=cp(source);wrong.cases[0].decision_slots[0].id='UNKNOWN';ok(buildR32ImpactMap(wrong).verdict==='REJECT_SOURCE_DRIFT','unknown slot');
const lost=cp(source);lost.cases.pop();ok(buildR32ImpactMap(lost).verdict==='REJECT_SOURCE_DRIFT','lost case');
const perm=cp(source);perm.cases[1].decision_slots[0].decision='not source blank';ok(buildR32ImpactMap(perm).verdict==='IMPACT_PLANNED_NOT_AUTHORIZED','baseline id retained but source data only'); // not a source authenticity check
ok(Object.keys(R32_EFFECTS).length===11,'map exhaustive');
console.log('R32 impact trace tests '+n+'/'+n+' PASS');
