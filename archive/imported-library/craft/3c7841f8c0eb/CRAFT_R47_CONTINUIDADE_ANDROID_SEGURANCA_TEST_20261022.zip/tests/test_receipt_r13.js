'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),cp=require('child_process');
const root=path.join(__dirname,'..');
const run=fs.readFileSync(path.join(root,'src/run.js'));
const validation=fs.readFileSync(path.join(root,'src/validate.js'));
const verify=fs.readFileSync(path.join(root,'src/verify_outputs.js'));
const inputs=['data/proposals.json','data/resources.json'].map(f=>fs.readFileSync(path.join(root,f)));
let checks=0;
function test(fault,corrupt,expected){
 const base=fs.mkdtempSync(path.join(os.tmpdir(),'craft-r13-'));
 try{
  for(const sub of ['data','src','outputs'])fs.mkdirSync(path.join(base,sub));
  for(const [name,data] of [['src/run.js',run],['src/validate.js',validation],['src/verify_outputs.js',verify],['data/proposals.json',inputs[0]],['data/resources.json',inputs[1]]])fs.writeFileSync(path.join(base,name),data);
  fs.writeFileSync(path.join(base,'outputs/QA_RESULT.json'),'old');
  fs.writeFileSync(path.join(base,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'),'stale secret');
  fs.writeFileSync(path.join(base,'outputs/OUTPUT_COMMIT.json'),JSON.stringify({schema:'CRAFT_TEST_OUTPUT_COMMIT_V1',status:'FORM_READY_NOT_PRODUCTION'}));
  const v=()=>cp.spawnSync('node',['src/verify_outputs.js'],{cwd:base,encoding:'utf8'});
  const env={...process.env};if(fault)env.CRAFT_TEST_FAULT=fault;
  const x=cp.spawnSync('node',['src/run.js'],{cwd:base,env,encoding:'utf8'});
  assert.equal(x.status,fault?3:0,`run ${fault||'normal'}: ${x.stderr}`);checks++;
  const commit=path.join(base,'outputs/OUTPUT_COMMIT.json');
  assert.equal(fs.existsSync(commit),!fault,`commit ${fault}`);checks++;
  if(corrupt){
   corrupt(base);checks++;
  }
  const check=v();const body=JSON.parse(check.stdout);
  assert.equal(body.verified,expected,`verified ${fault} ${body.code}`);checks++;
  assert.equal(check.status,expected?0:4,'validator exit');checks++;
  const leftovers=fs.readdirSync(path.join(base,'outputs')).filter(x=>x.endsWith('.tmp'));
  assert.equal(leftovers.length,0,'sem arquivos temporários após falha');checks++;
  if(!expected){assert.notEqual(body.status,'FORM_READY_NOT_PRODUCTION');checks++;}
 }finally{fs.rmSync(base,{force:true,recursive:true});}
}
test(null,null,true);
for(const fault of ['after_stage','after_qa','after_preview'])test(fault,null,false);
test(null,b=>fs.appendFileSync(path.join(b,'outputs/QA_RESULT.json'),'\n'),false);
test(null,b=>fs.appendFileSync(path.join(b,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'),'\n'),false);
test(null,b=>{const f=path.join(b,'outputs/OUTPUT_COMMIT.json');let x=JSON.parse(fs.readFileSync(f));x.status='FORM_READY_NOT_PRODUCTION';fs.writeFileSync(f,JSON.stringify(x));},false);
test(null,b=>fs.rmSync(path.join(b,'outputs/OUTPUT_COMMIT.json')),false);
test(null,b=>fs.writeFileSync(path.join(b,'outputs/QA_RESULT.json'),'not json'),false);
console.log(`R13 receipt/integrity PASS ${checks}/${checks} assertions (9 isolated scenarios)`);
