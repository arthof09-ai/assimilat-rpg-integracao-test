'''R20 mobile briefing of resource/item/recipe requests; does NOT create in RPG.'''
from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,json
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
count=0
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors,requests=[],[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http://','https://')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('#creation-brief').count()==1;count+=1
 assert page.locator('article.box').count()==2;count+=1
 assert page.locator('#pager').inner_text().startswith('Página 1 de 1');count+=1
 assert page.locator('#rejected-plan').is_disabled();count+=1
 assert page.get_by_text('Metodologia R17').count()==2;count+=1
 page.locator('#brief-export').click()
 assert 'Pendente:' in page.locator('#brief-status').inner_text();count+=1
 assert page.evaluate('makeCreationBrief("UNKNOWN","nome","finalidade detalhada") === null');count+=1
 assert page.evaluate('makeCreationBrief("ITEM","a","finalidade detalhada") === null');count+=1
 assert page.evaluate('makeCreationBrief("ITEM","nome","curto") === null');count+=1
 assert page.evaluate('makeCreationBrief("ITEM","nome","x".repeat(2001)) === null');count+=1
 examples=[('RESOURCE','Veículo de teste','Pesquisar veículo compatível para infusão experimental, sem presumir magia','PR-CRN-01'),
  ('ITEM','Sonda de investigação','Criar conceito de medição qualitativa, sujeito à prova e comparadores','PR-ITEM-02'),
  ('RECIPE','Matriz de cultivo','Revisar BOM, processo e condições da matriz, sem substituir ingredientes','REC-LIB-01')]
 with tempfile.TemporaryDirectory() as temp:
  temp=Path(temp)
  for kind,name,goal,source in examples:
   page.locator('#brief-kind').select_option(kind)
   page.locator('#brief-name').fill(name)
   page.locator('#brief-intent').fill(goal)
   with page.expect_download() as ev:page.locator('#brief-export').click()
   out=temp/(kind+'.json');ev.value.save_as(out)
   doc=json.loads(out.read_text())
   assert doc['kind']==kind;count+=1
   assert doc['provisional_name']==name;count+=1
   assert doc['desired_function_not_verified']==goal;count+=1
   assert source in doc['authoritative_reference']['name'];count+=1
   assert doc['method_steps_to_research'];count+=1
   assert all(x is False for x in doc['evidence_status'].values());count+=1
   assert doc['status']=='BRIEF_TEST_NOT_CANONICAL_NOT_READY_FOR_PRODUCTION';count+=1
   assert doc['classification']=='MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY';count+=1
   assert 'Não escrever no cânone' in doc['follow_up_request'];count+=1
   assert 'Party' in doc['follow_up_request'];count+=1
   assert 'Brief TEST gerado' in page.locator('#brief-status').inner_text();count+=1
   assert not ('master_secrets' in json.dumps(doc));count+=1
  # Dado hostil é preservado apenas em JSON, sem executar como HTML.
  page.locator('#brief-kind').select_option('ITEM')
  page.locator('#brief-name').fill('<svg onload=alert(1)>')
  page.locator('#brief-intent').fill('Tentativa TEST de XSS em texto, não executável como script.')
  with page.expect_download() as ev:page.locator('#brief-export').click()
  a=temp/'injection.json';ev.value.save_as(a);data=json.loads(a.read_text());assert data['provisional_name'].startswith('<svg');count+=1
  assert page.locator('svg').count()==0;count+=1
  assert page.locator('article.box').count()==2;count+=1
  assert page.locator('#pager').inner_text().startswith('Página 1 de 1');count+=1
  with page.expect_download() as ev:page.locator('#save').click()
  qa=temp/'qa.json';ev.value.save_as(qa);d=json.loads(qa.read_text())
  assert d['total']==2;count+=1
  assert all(item['methodology']['recipe']['rc5_demonstrated'] is False for item in d['items']);count+=1
  assert all(item['issues']==[] for item in d['items']);count+=1
 assert not errors,errors;count+=1
 assert not requests,requests;count+=1
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+1');count+=1
 b.close()
print('R20 mobile creation briefing PASS',count,'/',count,'(Chromium inline only)')
