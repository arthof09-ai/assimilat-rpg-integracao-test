'use strict';const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),{reviewCost}=require('../src/economic_gate');const root=path.join(__dirname,'..'),base=JSON.parse(fs.readFileSync(path.join(root,'data/economic_case.json')));
let count=0;function check(name,update,gate,reason){const x=structuredClone(base);update(x);const res=reviewCost(x);assert.equal(res.gate,gate,name);if(reason)assert(res.failures.includes(reason)||res.pending.includes(reason));count++;}
check('real case hold',x=>{},'HOLD_DATA','yield');
check('no dose',x=>{},'HOLD_DATA','bom_quantities');
check('no market',x=>{},'HOLD_DATA','same_market_epoch');
check('no skilled labor',x=>{},'HOLD_DATA','labor');
check('no route',x=>{},'HOLD_DATA','logistics');
check('no recipe knowledge',x=>{},'HOLD_DATA','knowledge');
check('no opportunity',x=>{},'HOLD_DATA','opportunity_cost');
check('reject product price based only on material sum',x=>x.market_product_med=560000,'REJECT','PRICE_UNAUTHORIZED_WITHOUT_CTE');
check('reject inherited rank from price',x=>x.item_rank_from_price=true,'REJECT','RANK_FROM_PRICE_FORBIDDEN');
check('reject free owned input',x=>{x.material_prices[0].unit_price_med=0;x.material_prices[0].owned=true;},'REJECT','OWN_STOCK_IS_NOT_FREE');
check('reject bad yield',x=>x.yield=0,'REJECT','INVALID_YIELD');
check('reject p>1',x=>x.success_probability=1.2,'REJECT','INVALID_SUCCESS_PROBABILITY');
check('reject negative qty',x=>x.bom_quantities=[1,-2],'REJECT','INVALID_BOM_QUANTITY');
check('reject incompatible market epochs',x=>x.same_market_epoch=false,'REJECT','MARKET_MISMATCH');
const r=reviewCost(base);assert([r.kit_cost_med,r.cte_med,r.recipe_knowledge_value_med,r.product_market_price_med].every(v=>v===null));count++;
assert(base.illustrative_one_unit_each.sum_reference_centers_med===560000&&base.illustrative_one_unit_each.CAN_NOT_BE_USED_AS_PRODUCT_PRICE);count++;
console.log('PASS '+count+'/'+count+' testes econômicos quatro valores separados');
