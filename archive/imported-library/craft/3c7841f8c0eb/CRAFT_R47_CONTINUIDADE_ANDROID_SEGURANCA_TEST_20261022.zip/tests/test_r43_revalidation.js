'use strict';const assert=require('assert'),fs=require('fs');
const baseline=JSON.parse(fs.readFileSync(require('path').join(__dirname,'../data/r40_50_author_notes_baseline.json')));
const {reviewR40Draft}=require('../src/r40_author_review.js');global.reviewR40Draft=reviewR40Draft;
const {makeR43Plan,R43_ACTIONS}=require('../src/r43_revalidation_plan.js');
let n=0;const ok=(x,m)=>{assert.ok(x,m);n++};const fresh=()=>JSON.parse(JSON.stringify(baseline));
const original=JSON.stringify(baseline);let x=fresh(),p=makeR43Plan(x,baseline);
ok(p.verdict==='PLAN_NOT_AUTHENTICATED','default plan');ok(p.actions.length===22,'22');ok(p.questions_total===50,'50');ok(p.notes_present===0&&p.notes_missing===50,'zero');
ok(p.actions.reduce((a,c)=>a+c.slots.length,0)===50,'each once');ok(new Set(p.actions.map(c=>c.case_key)).size===22,'unique keys');
ok(p.actions.every(c=>c.slots.every(s=>s.state==='AGUARDA_NOTA'&&!s.notion_write_allowed&&!s.physical_equivalence_verified)),'no authorize');
ok(p.actions.every(c=>!c.can_apply_to_notions&&!c.rc5_allowed),'cases HOLD');
ok(!p.canonical_write&&!p.rc5_allowed&&!p.party_release&&!p.notes_authenticated,'global HOLD');
ok(p.upstream_oil_cascade.review_scope.includes('29'),'29 mention scope');ok(p.upstream_oil_cascade.literal_bom_mentions===28,'28 BOM');ok(p.upstream_oil_cascade.broken_reference_cases.includes('MAT-03'),'broken mat');
const count=p.actions.flatMap(c=>c.slots).reduce((o,s)=>(o[s.issue_class]=(o[s.issue_class]||0)+1,o),{});
for(const [cl,quantity] of Object.entries({AUTHORITY_RECONCILIATION:23,MATERIAL_IDENTITY:11,UNCONSUMED_BOM:6,LEXICAL_CANDIDATE:4,PROCESS_SEQUENCE:3,TRANSFORMATION_UNPROVED:2,QUANTITY_VOLUME:1})){
 ok(count[cl]===quantity,'issue count '+cl);ok(typeof R43_ACTIONS[cl]==='string'&&R43_ACTIONS[cl].length>15,'action meaningful '+cl);
}
for(const c of p.actions)for(const s of c.slots){ok(s.next_action.length>30,'action '+s.slot_id);ok(!Object.hasOwn(s,'author_note'),'no note text');}
x=fresh();x.cases[0].slots[0].author_note='Segredo MESTRE <p>ZZZ</p>';x.all_notes_blank=false;
p=makeR43Plan(x,baseline);ok(p.notes_present===1&&p.notes_missing===49,'one report');ok(p.actions[0].slots[0].state==='AGUARDA_AUTENTICACAO','auth required');ok(p.requires_author_review.length===1,'case for review');ok(!JSON.stringify(p).includes('ZZZ'),'no text leaked');ok(!p.party_release&&!p.canonical_write,'still hold');
x=fresh();for(const c of x.cases)for(const s of c.slots)s.author_note='Texto pendente';x.all_notes_blank=false;p=makeR43Plan(x,baseline);
ok(p.notes_present===50,'50 input');ok(p.requires_author_review.length===22,'22 affected');ok(p.external_gates.NAC_PASS_material==='NOT_GRANTED','NAC-PASS HOLD');ok(!p.party_release&&!p.rc5_allowed,'all still HOLD');
for(const [field,value] of [['no_player_release',false],['no_canonical_write',false],['rc5_allowed',true],['classification','PUBLIC']]){let d=fresh();d[field]=value;ok(makeR43Plan(d,baseline).verdict==='REJECT','reject tamper '+field)}
x=fresh();x.cases[0].slots[0].issue_class='HACKED';ok(makeR43Plan(x,baseline).verdict==='REJECT','unknown after R40');
x=fresh();x.cases[0].slots[0].question='alteração';ok(makeR43Plan(x,baseline).verdict==='REJECT','metadata mutation');
ok(JSON.stringify(baseline)===original,'source stays frozen');
console.log('R43 gated revalidation plan '+n+'/'+n+' PASS');
