'use strict';const assert=require('node:assert/strict'),fs=require('node:fs');let n=0;const ok=(v,x)=>{assert.ok(v,x);n++};
const r=JSON.parse(fs.readFileSync(__dirname+'/../data/r34_notionsource_readback_test.json')),
a=JSON.parse(fs.readFileSync(__dirname+'/../outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json'));
ok(r.sources.length===4,'4 pages only');ok(r.scope.startsWith('SOMENTE'),'limited scope');ok(new Set(r.sources.map(x=>x.page_id)).size===4,'unique physical UUIDs');
for(const c of a.cases){const s=r.sources.find(x=>x.key===c.key);ok(!!s,c.key);ok(s.source_url===c.source_url,'URL');if(c.physical_recipe_id){ok(s.page_id===c.physical_recipe_id,'identity');ok(s.last_edited_utc===c.canonical_page_last_edited_utc,'no metadata edit after R30');}ok(s.source_signals.oil_named,'mentions oil');ok(s.body_text_length>1800&&s.body_text_length<4000,'bounds');}
ok(r.sources.find(x=>x.key==='MAT-03').source_signals.broken_oil_reference,'broken link still there');ok(r.sources.find(x=>x.key==='MAT-06').source_signals.unknown_ex_quantity,'Ex not resolved');ok(r.sources.find(x=>x.key==='ENC-08').source_signals.salt_holy_vs_enchanted,'salt conflict');ok(r.sources.find(x=>x.key==='UPSTREAM_OIL').source_signals.oil_dew_conflict,'oil upstream conflict');
for(const [name,val] of Object.entries(r.limits))ok(val===false,'no actual confirmation '+name);
console.log('R34 timestamp/text-signals readback consistency '+n+'/'+n+' PASS');
