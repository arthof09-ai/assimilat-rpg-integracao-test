"""R22: validação real de formulário/reparo no Chromium mobile, sem Android físico."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,json,copy
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
base=json.loads((root/'data/proposals.json').read_text())
n=0
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 requests=[];errors=[]
 p.on('request',lambda x:requests.append(x.url) if x.url.startswith(('https://','http://')) else None)
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.set_content(html,wait_until='load')
 assert p.locator('article.box').count()==2;n+=1
 assert p.locator('#rejected-plan').is_disabled();n+=1
 assert p.locator('#pager').inner_text().startswith('Página 1 de 1');n+=1
 with tempfile.TemporaryDirectory() as tmp:
  tmp=Path(tmp)
  bad=copy.deepcopy(base)
  bad['products'][0]['process'][0]['input_node_ids']=['B3','B3']
  bad['products'][0]['process'][1]['step']=9
  bad['products'][0]['yield']={'quantity':-3,'unit':'frascos'}
  file=tmp/'bad.json';file.write_text(json.dumps(bad,ensure_ascii=False))
  p.locator('#upload').set_input_files(str(file));p.wait_for_timeout(120)
  assert 'Falha no arquivo' in p.locator('#loadStatus').inner_text();n+=1
  assert p.locator('article.box').count()==2;n+=1
  assert p.locator('#rejected-plan').is_enabled();n+=1
  with p.expect_download() as ev:p.locator('#rejected-plan').click()
  out=tmp/'corrections.json';ev.value.save_as(out)
  data=json.loads(out.read_text())
  assert data['classification']=='MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY';n+=1
  repair=data['projects'][0]
  assert 'PROCESS_INPUT_DUPLICATE' in repair['blocking_errors'];n+=1
  assert 'PROCESS_SEQUENCE_GAP' in repair['blocking_errors'];n+=1
  assert 'PRODUCTION_PARAMETER_INVALID' in repair['blocking_errors'];n+=1
  assert any('quantidade' in ' '.join(x['required_fields']) for x in repair['missing_evidence']);n+=1
  assert repair['party_release_authorized'] is False;n+=1
  assert 'master_secrets' not in json.dumps(data);n+=1
  qa=p.evaluate('current')
  assert qa['total']==2;n+=1
  assert qa['status']=='HOLD_TEST_DESIGN';n+=1
  assert all(x['issues']==[] for x in qa['items']);n+=1
  ok=copy.deepcopy(base);ok['products'][0]['loss_rate']=.10
  file2=tmp/'hold.json';file2.write_text(json.dumps(ok,ensure_ascii=False))
  p.locator('#upload').set_input_files(str(file2));p.wait_for_timeout(120)
  assert 'Proposta TEST carregada' in p.locator('#loadStatus').inner_text();n+=1
  assert not p.locator('#rejected-plan').is_enabled();n+=1
  assert 'PRODUCTION_PROVENANCE_PENDING' in p.locator('article.box').first.inner_text();n+=1
  with p.expect_download() as ev:p.locator('#evidence').click()
  evidence=tmp/'evidence.json';ev.value.save_as(evidence)
  plan=json.loads(evidence.read_text())
  assert any(x['source_hold']=='PRODUCTION_PROVENANCE_PENDING' for x in plan['projects'][0]['missing_evidence']);n+=1
  assert all(x['approved_for_production'] is False for x in plan['projects'][0]['missing_evidence']);n+=1
  with p.expect_download() as ev:p.locator('#save').click()
  d=tmp/'qa.json';ev.value.save_as(d);report=json.loads(d.read_text())
  assert report['total']==2;n+=1
  assert report['items'][0]['verdict']=='HOLD_TEST_DESIGN';n+=1
  assert report['items'][0]['verified_production'] is False;n+=1
  assert p.evaluate('document.documentElement.scrollWidth <= innerWidth+1');n+=1
  assert not requests,requests;n+=1
  assert not errors,errors;n+=1
 b.close()
print(f'R22 browser/process methodology TEST PASS {n}/{n} checks, Chromium inline')
