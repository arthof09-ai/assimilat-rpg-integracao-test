"""R26: material evidence requests TEST tied to existing frozen examples; never a physical certificate."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,json,copy
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text(encoding='utf-8')
checks=0
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];net=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:net.append(r.url) if r.url.startswith(('https://','http://')) else None)
 page.set_content(html,wait_until='load')
 raw=page.evaluate('evidencePlan(current.items)')
 assert len(raw['projects'])==2;checks+=1
 assert raw['classification']=='MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY';checks+=1
 node_requests=[r for p in raw['projects'] for r in p['targeted_material_requests']]
 assert len(node_requests)==3;checks+=1
 assert {r['proposal_id']+':'+r['node_id'] for r in node_requests}=={'R53-TEST-SONDA-001:B3','R53-TEST-TONICO-002:B3','R53-TEST-TONICO-002:B4'};checks+=1
 for r in node_requests:
  assert r['precedent_is_not_proof'] is True;checks+=1
  assert r['source_search_scope']=='PARTIAL_TARGETED_SEARCH_NOT_GLOBAL_CENSUS';checks+=1
  assert r['status']=='PENDENTE_NAO_OBSERVADO';checks+=1
  assert len(r['evidence_requirements'])==5;checks+=1
  assert all(q['observed_data'] is None and q['proof_url'] is None for q in r['evidence_requirements']);checks+=1
  assert all(v is None for v in r['r46_record'].values());checks+=1
  assert r['certification_status']=='NOT_REVIEWED_NOT_PHYSICALLY_VERIFIED';checks+=1
  assert r['compatibility_demonstrated'] is False;checks+=1
  assert r['physical_test_executed'] is False;checks+=1
  assert r['magical_transfer_demonstrated'] is False;checks+=1
  assert r['production_or_party_release_allowed'] is False;checks+=1
 assert page.get_by_text('R26 — materiais pendentes por nó').count()==2;checks+=1
 assert 'suporte/fecho' not in page.locator('#pager').inner_text();checks+=1
 with tempfile.TemporaryDirectory() as tmp:
  with page.expect_download() as ev:page.locator('#evidence').click()
  f=Path(tmp)/'plan.json';ev.value.save_as(f)
  saved=json.loads(f.read_text())
  assert saved==raw;checks+=1
  assert 'master_secrets' not in json.dumps(saved);checks+=1
  mutated=copy.deepcopy(page.evaluate('PROJECT'))
  mutated['products'][0]['design']+=' — mudança legítima de usuário, não herdar prova R25'
  assert page.evaluate('(d)=>valid(d,INDEX).status',mutated)=='HOLD_TEST_DESIGN';checks+=1
  # Same ID, different content means the R25 sampling snapshot no longer binds.
  page.evaluate('(d)=>{PROJECT=d;render(true)}',mutated)
  second=page.evaluate('evidencePlan(current.items)')
  assert len(second['projects'][0]['targeted_material_requests'])==0;checks+=1
  assert len(second['projects'][1]['targeted_material_requests'])==2;checks+=1
  assert page.get_by_text('Nenhum nó R25 aplicável à versão atual').count()==1;checks+=1
  # Invalid upload must preserve existing user proposal and its page.
  invalid=copy.deepcopy(mutated);invalid['products'][0]['proof']['inventory_commit']=True
  field=page.locator('#upload');bad=Path(tmp)/'invalid.json';bad.write_text(json.dumps(invalid))
  field.set_input_files(bad)
  assert page.evaluate('PROJECT.products[0].design.endsWith("— mudança legítima de usuário, não herdar prova R25")');checks+=1
  assert page.evaluate('evidencePlan(current.items).projects[0].targeted_material_requests.length')==0;checks+=1
  assert page.locator('#rejected-plan').is_enabled();checks+=1
  assert len(net)==0;checks+=1
  assert len(errors)==0,errors;checks+=1
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');checks+=1
 browser.close()
print('R26 targeted R46 request Chromium inline PASS %d/%d'%(checks,checks))
