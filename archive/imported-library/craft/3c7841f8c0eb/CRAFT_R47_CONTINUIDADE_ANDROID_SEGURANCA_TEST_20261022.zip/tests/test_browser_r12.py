'''CRAFT R12: teste visual/interação na mesma interface TEST, sem rede.''' 
import json, pathlib, tempfile
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
data=json.loads((root/'data/proposals.json').read_text())
checks=0
with sync_playwright() as pw:
    b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
    page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    requests=[];errs=[]
    page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('https://','http://')) else None)
    page.on('pageerror',lambda e:errs.append(str(e)))
    page.set_content(html,wait_until='load')
    assert page.locator('article.box').count()==2;checks+=1
    assert page.locator('article.box').filter(has_text='HOLD_TEST_DESIGN').count()==2;checks+=1
    with tempfile.TemporaryDirectory() as tmp:
        for ix,(name,edit) in enumerate([
            ('secret_name',lambda x:x['player_view'].update(name_if_discovered=x['master_secrets'])),
            ('secret_visible',lambda x:x['player_view'].update(visible_properties=x['master_secrets'])),
            ('name_object',lambda x:x['player_view'].update(name_if_discovered={'secret':'MESTRE'})),
            ('visible_list',lambda x:x['player_view'].update(visible_properties=['sigilo'])),
        ]):
            d=json.loads(json.dumps(data));edit(d['products'][0])
            f=pathlib.Path(tmp)/f'{ix}_{name}.json'
            f.write_text(json.dumps(d,ensure_ascii=False))
            page.locator('#upload').set_input_files(str(f))
            page.wait_for_timeout(50)
            assert page.locator('#loadStatus').inner_text().startswith('Falha no arquivo: Entrada rejeitada');checks+=1
            assert page.locator('article.box').filter(has_text='HOLD_TEST_DESIGN').count()==2;checks+=1
            assert not errs and not requests;checks+=1
        with page.expect_download() as ev:page.locator('#save').click()
        dfile=pathlib.Path(tmp)/'qa.json';ev.value.save_as(dfile)
        out=json.loads(dfile.read_text())
        assert out['status']=='HOLD_TEST_DESIGN' and len(out['items'])==2;checks+=1
        assert not errs and not requests;checks+=1
    b.close()
print(f'R12 Chromium inline UI PASS {checks}/{checks}; Android real NAO testado')
