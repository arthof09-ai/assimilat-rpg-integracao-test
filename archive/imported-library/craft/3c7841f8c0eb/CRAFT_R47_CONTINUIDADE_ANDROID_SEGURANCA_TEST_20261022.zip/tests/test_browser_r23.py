"""R23: cartões Mestre congelados não podem colar em proposta importada com ID igual."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,copy,tempfile
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
base=json.loads((root/'data/proposals.json').read_text())
n=0
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 req=[];err=[]
 p.on('request',lambda r:req.append(r.url) if r.url.startswith(('http://','https://')) else None)
 p.on('pageerror',lambda e:err.append(str(e)))
 p.set_content(html,wait_until='load')
 assert p.get_by_text('Ficha Mestre I–XIII').count()==2;n+=1
 assert p.evaluate('bundledMasterCard(0,current.items[0]) !== null');n+=1
 assert p.evaluate('bundledMasterCard(1,current.items[1]) !== null');n+=1
 with tempfile.TemporaryDirectory() as tmp:
  tmp=Path(tmp)
  # Same ID, changed meaning; card MUST NOT be presented as matching that item.
  drift=copy.deepcopy(base)
  drift['products'][0]['design']='PROPOSTO: geometria TEST corrigida por outro operador, ainda sem laudo'
  f=tmp/'drift.json';f.write_text(json.dumps(drift,ensure_ascii=False))
  p.locator('#upload').set_input_files(str(f));p.wait_for_timeout(120)
  assert 'carregada' in p.locator('#loadStatus').inner_text();n+=1
  assert p.get_by_text('Ficha Mestre I–XIII').count()==1;n+=1
  assert p.evaluate('bundledMasterCard(0,current.items[0]) === null');n+=1
  assert p.evaluate('bundledMasterCard(1,current.items[1]) !== null');n+=1
  # More severe: imported item adopting the embedded ID but different name.
  name=copy.deepcopy(base);name['products'][0]['name']='Instrumento inteiramente diferente TEST'
  g=tmp/'id-collision.json';g.write_text(json.dumps(name,ensure_ascii=False))
  p.locator('#upload').set_input_files(str(g));p.wait_for_timeout(120)
  assert 'carregada' in p.locator('#loadStatus').inner_text();n+=1
  assert p.get_by_text('Ficha Mestre I–XIII').count()==1;n+=1
  assert p.evaluate('bundledMasterCard(0,current.items[0]) === null');n+=1
  # Failed import never replaces the active project or its card gate.
  bad=copy.deepcopy(name);bad['products'][0]['player_view']['visible_properties']=bad['products'][0]['master_secrets']
  h=tmp/'bad.json';h.write_text(json.dumps(bad,ensure_ascii=False))
  p.locator('#upload').set_input_files(str(h));p.wait_for_timeout(120)
  assert 'Falha no arquivo' in p.locator('#loadStatus').inner_text();n+=1
  assert p.get_by_text('Ficha Mestre I–XIII').count()==1;n+=1
  assert 'inteiramente diferente' in p.locator('article.box').first.inner_text();n+=1
  # Exact original can restore bundled cards, but never a Party publication.
  j=tmp/'original.json';j.write_text(json.dumps(base,ensure_ascii=False))
  p.locator('#upload').set_input_files(str(j));p.wait_for_timeout(120)
  assert p.get_by_text('Ficha Mestre I–XIII').count()==2;n+=1
  assert p.evaluate('current.items.every(v=>v.verified_production===false)');n+=1
  assert p.evaluate('document.documentElement.scrollWidth <= innerWidth+1');n+=1
  assert not req,req;n+=1
  assert not err,err;n+=1
 b.close()
print('R23 bundle/card identity mobile PASS',n,'/',n,'Chromium inline')
