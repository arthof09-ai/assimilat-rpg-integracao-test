'use strict';const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {reviewAuthorDraft}=require('../src/r31_author_intake.js'),root=path.join(__dirname,'..');
const orig=JSON.parse(fs.readFileSync(root+'/outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json'));
const dup=x=>JSON.parse(JSON.stringify(x));let n=0;const ok=(x,msg)=>{assert.ok(x,msg);n++};
let res=reviewAuthorDraft(orig,orig);ok(res.verdict==='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED','baseline');ok(res.slots_total===11,'eleven');ok(res.decisions_reported===0,'no answers');ok(res.pending_slots===11,'missing');ok(!res.recipe_rc5_approved&&!res.canonical_write_allowed,'holds');ok(!res.notes_forwarded,'does not export notes');
let filled=dup(orig);for(const c of filled.cases)for(const s of c.decision_slots)s.decision='Decisão textual PROPOSTA — ainda sem fonte técnica/medição';
filled.all_choices_blank=false;res=reviewAuthorDraft(filled,orig);ok(res.verdict==='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED','full report');ok(res.decisions_reported===11,'eleven reported');ok(res.pending_slots===0,'zero missing');ok(!JSON.stringify(res).includes('Decisão textual PROPOSTA'),'not leaking notes');ok(!res.authorship_verified,'not real authorization');ok(!res.recipe_rc5_approved&&!res.physical_recipe_modified,'no production/recipe');ok(!res.party_or_o_primeiro_release_allowed,'no Party');
const contradiction=dup(filled);contradiction.all_choices_blank=true;ok(reviewAuthorDraft(contradiction,orig).reason==='DRAFT_STATUS_INCONSISTENT','reject contradiction');
let part=dup(orig);part.cases[0].decision_slots[0].decision='Sal autoral ainda PENDENTE';part.all_choices_blank=false;res=reviewAuthorDraft(part,orig);ok(res.decisions_reported===1&&res.pending_slots===10,'partial');ok(res.cases[0].slots_reported===1,'case count');
const cases=[
 ['schema',x=>x.schema='AUTHORITY_GRANTED'],['type',x=>x.type='CANONICAL'],['source hash',x=>x.source_docket_sha256='fake'],
 ['source timestamp',x=>x.cases[0].canonical_page_last_edited_utc='2099-01-01'],
 ['UUID',x=>x.cases[0].physical_recipe_id='bad'],['URL',x=>x.cases[0].source_url='https://bad.example'],
 ['question',x=>x.cases[0].decision_slots[0].question='auto-approved'],['BOM',x=>x.cases[0].decision_slots[0].bom_literal='1x'],
 ['priority',x=>x.cases[0].priority='P4'],['fencing',x=>x.constraints.c19_fencing_confirmed=true],
 ['write',x=>x.cases[0].canonical_mutation_performed=true],['append case',x=>x.cases.push(x.cases[0])],
 ['delete case',x=>x.cases.pop()],['extra key',x=>x.authorized=true],
 ['slot key',x=>x.cases[0].decision_slots[0].id='BYPASS'],['extra slot',x=>x.cases[0].decision_slots.push(x.cases[0].decision_slots[0])],
 ['remove slot',x=>x.cases[0].decision_slots.pop()],['duplicate case',x=>x.cases[1]=x.cases[0]],
 ['number as decision',x=>x.cases[0].decision_slots[0].decision=4],['boolean decision',x=>x.cases[0].decision_slots[0].decision=true],
 ['object decision',x=>x.cases[0].decision_slots[0].decision={action:'write'}],['blank',x=>x.cases[0].decision_slots[0].decision=' '],
 ['oversize',x=>x.cases[0].decision_slots[0].decision='X'.repeat(1501)],['control',x=>x.cases[0].decision_slots[0].decision='x\u0000'],
 ['drop decision',x=>delete x.cases[0].decision_slots[0].decision],['rename source key',x=>x.cases[0].key='CANON'],
 ['unexpected compliance',x=>x.can_publish=true]
];
for(const [label,edit] of cases){let x=dup(orig);edit(x);ok(reviewAuthorDraft(x,orig).verdict==='REJECT_UNTRUSTED_DRAFT',label)}
for(let i=0;i<11;i++){let x=dup(orig);let k=0;for(const c of x.cases)for(const s of c.decision_slots)if(k++===i)s.decision='Nota '+i;x.all_choices_blank=false;let y=reviewAuthorDraft(x,orig);ok(y.decisions_reported===1&&y.pending_slots===10,'each slot '+i)}
const max=dup(orig);max.cases[0].decision_slots[0].decision='A'.repeat(1500);max.all_choices_blank=false;ok(reviewAuthorDraft(max,orig).decisions_reported===1,'boundary max');
const nl=dup(orig);nl.cases[0].decision_slots[0].decision='Linha 1\nLinha 2';nl.all_choices_blank=false;ok(reviewAuthorDraft(nl,orig).decisions_reported===1,'newline allowed');
const attack=dup(orig);attack.cases[0].decision_slots[0].decision='</script><img src=x onerror=alert(1)>';attack.all_choices_blank=false;ok(reviewAuthorDraft(attack,orig).decisions_reported===1,'text data only');ok(!JSON.stringify(reviewAuthorDraft(attack,orig)).includes('onerror'),'text never propagated');
let huge=dup(orig);huge.untrusted_payload='X'.repeat(135000);ok(reviewAuthorDraft(huge,orig).reason==='SIZE_LIMIT_128K','total cap');
for(const x of [null,[],{},undefined,12,'string'])ok(reviewAuthorDraft(x,orig).verdict==='REJECT_UNTRUSTED_DRAFT','bad root');
console.log(`R31 author-note triage ${n}/${n} PASS`);
