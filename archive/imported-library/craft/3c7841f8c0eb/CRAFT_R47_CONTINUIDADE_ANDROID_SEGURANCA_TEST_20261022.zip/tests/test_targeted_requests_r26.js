'use strict';
const a=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const root=path.join(__dirname,'..');
const research=JSON.parse(fs.readFileSync(path.join(root,'data/research_gaps_r25.json')));
const proposals=JSON.parse(fs.readFileSync(path.join(root,'data/proposals.json')));
const html=fs.readFileSync(path.join(root,'REVISOR_LOCAL_ANDROID_R53_TEST.html'),'utf8');
const map=new Map(proposals.products.map(p=>[p.proposal_id,p]));let n=0;
const check=(expr,msg)=>{a.ok(expr,msg);++n;};
check(research.pending_nodes.length===3,'three requirements');
check(research.source_completeness==='PARTIAL_TARGETED_SEARCH_NOT_GLOBAL_CENSUS','no global proof');
check(html.includes('function targetedEvidenceForReport(report)'), 'function in old revisor');
check(html.includes('targeted_material_requests:targetedEvidenceForReport(r)'), 'uses existing evidence exporter');
check(html.includes('R26 — materiais pendentes por nó'), 'UI added');
check(html.includes('NOT_REVIEWED_NOT_PHYSICALLY_VERIFIED'), 'no physical acceptance');
check(html.includes('JSON.stringify(currentProduct)!==JSON.stringify(frozenProduct)'), 'anti-spoof comparison');
check(html.includes('const R25_RESEARCH_GAPS = '), 'embedded static research');
check(html.includes('production_or_party_release_allowed:false'), 'no party/production');
check(html.includes('r46_record:{sample_id:null'), 'blank R46 custody');
check(html.includes('source_search_scope:R25_RESEARCH_GAPS.source_completeness'), 'disclose partial');
const keys=new Set();
for(const gap of research.pending_nodes){
 const key=gap.proposal_id+':'+gap.node_id;
 check(!keys.has(key),'no duplicate gap');keys.add(key);
 const p=map.get(gap.proposal_id);check(!!p,'proposal exists');
 const node=p.bom.find(x=>x.node_id===gap.node_id);check(!!node,'node exists');
 check(node.source_id===null,'still no source');
 check(node.qty===null,'still no quantity');
 check(gap.candidate_used_as_fact===false,'no invented candidate fact');
 check(gap.needs.length===5,'five requirements per node');
 check(gap.source_precedent_url.startsWith('https://app.notion.com/p/'),'canonical candidate url');
 check(gap.decision.startsWith('HOLD_'),'only hold');
 for(const need of gap.needs){check(html.includes(need+':'),'key explicitly mapped');}
}
check(keys.size===3,'three distinct nodes');
check(!html.includes('VALIDATED_PHYSICAL_LAB'), 'no forged PASS');
console.log('R26 targeted material worksheet JS PASS '+n+'/'+n);
