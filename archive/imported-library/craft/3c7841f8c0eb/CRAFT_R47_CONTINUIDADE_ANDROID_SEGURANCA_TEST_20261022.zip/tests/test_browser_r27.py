"""R27 original 21-decision docket in same offline HTML, read-only and frozen."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,tempfile
root=Path(__file__).resolve().parents[1];source=json.loads((root/'data/r27_decision_register_readonly.json').read_text());html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
n=0
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];network=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.on('request',lambda r:network.append(r.url) if r.url.startswith(('https://','http://')) else None)
 p.set_content(html,wait_until='load')
 assert p.locator('#recipe-docket').count()==1;n+=1
 assert '21/29' in p.locator('#docket-summary').inner_text();n+=1
 assert 'NÃO aprovadas' in p.locator('#docket-summary').inner_text();n+=1
 assert p.locator('#docket-list li').count()>=21;n+=1
 d=p.evaluate('recipeDecisionQueue()');assert len(d['cases'])==21;n+=1
 assert len(d['upstream_crosscutting_decisions'])==7;n+=1
 assert d['source_freshness']=='FROZEN_20261021_NOT_LIVE';n+=1
 assert d['creates_new_recipe'] is False;n+=1
 assert d['creates_new_ticket'] is False;n+=1
 assert d['physical_recipe_changed'] is False;n+=1
 assert d['status']=='HOLD_AUTHOR_AND_FENCING';n+=1
 assert d['source_denominator']==source['denominator'];n+=1
 assert all(x['author_decision_required'] and not x['eligible_for_write'] for x in d['cases']);n+=1
 assert d['cases'][0]['priority']=='P0_RECEITA_P2';n+=1
 assert {x['physical_recipe_id'] for x in d['cases']}=={x['physical_recipe_id'] for x in source['issues']};n+=1
 assert sum(x['pattern_key']=='MAT-01' for x in d['cases'])==2;n+=1
 with tempfile.TemporaryDirectory() as tmp:
  with p.expect_download() as ev:p.locator('#docket-export').click()
  path=Path(tmp)/'decision.json';ev.value.save_as(path);data=json.loads(path.read_text())
  assert data==d;n+=1
  assert all(x['physical_recipe_edit_now'] is False for x in data['cases']);n+=1
  assert 'master_secrets' not in path.read_text();n+=1
  with p.expect_download() as ev:p.locator('#evidence').click()
  path=Path(tmp)/'evidence.json';ev.value.save_as(path)
  assert sum(len(x['targeted_material_requests']) for x in json.loads(path.read_text())['projects'])==3;n+=1
 assert p.locator('article.box').count()==2;n+=1
 assert not errors,errors;n+=1
 assert not network,network;n+=1
 assert p.evaluate('document.documentElement.scrollWidth<=innerWidth+1');n+=1
 b.close()
print('R27 integrated existing recipe decisions mobile PASS',n,'/',n)
