'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process');
const root=path.join(__dirname,'..');
const proposal=JSON.parse(fs.readFileSync(path.join(root,'data/proposals.json'),'utf8'));
const resources=fs.readFileSync(path.join(root,'data/resources.json'));
const js=fs.readFileSync(path.join(root,'src/run.js'));
const validator=fs.readFileSync(path.join(root,'src/validate.js'));
let count=0;
function test(label,input,expected,shouldReject=true) {
 const t=fs.mkdtempSync(path.join(os.tmpdir(),'craft-r10-'));
 try{
  fs.mkdirSync(path.join(t,'data'));fs.mkdirSync(path.join(t,'src'));
  fs.writeFileSync(path.join(t,'src/run.js'),js);fs.writeFileSync(path.join(t,'src/validate.js'),validator);
  fs.writeFileSync(path.join(t,'data/resources.json'),resources);
  fs.writeFileSync(path.join(t,'data/proposals.json'),typeof input==='string'?input:JSON.stringify(input));
  // Simula saída anterior que NÃO poderá parecer aprovação após um input rejeitado.
  fs.mkdirSync(path.join(t,'outputs'));
  fs.writeFileSync(path.join(t,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'),'[{"name":"STALE_PREVIEW"}]');
  const x=cp.spawnSync(process.execPath,[path.join(t,'src/run.js')],{encoding:'utf8',timeout:12000});
  assert.equal(x.status,shouldReject?2:0,label+' exit '+x.stderr);
  const qa=JSON.parse(fs.readFileSync(path.join(t,'outputs/QA_RESULT.json'),'utf8'));
  const preview=JSON.parse(fs.readFileSync(path.join(t,'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'),'utf8'));
  assert.equal(qa.status,expected,label+' QA');
  if(shouldReject){assert.equal(preview.status,'REJECT_NO_PLAYER_PREVIEW',label+' preview block');assert.deepEqual(preview.items,[],label+' items');}
  else {assert(Array.isArray(preview),label+' legacy format');assert.equal(preview.length,2,label+' count');}
  assert(!JSON.stringify(preview).includes('STALE_PREVIEW'),label+' no stale');
  const stdout=JSON.parse(x.stdout);
  assert.equal(stdout.preview_blocked,shouldReject,label+' status');
  count+=5;
 }finally{fs.rmSync(t,{recursive:true,force:true});}
}
test('baseline stays HOLD',proposal,'HOLD_TEST_DESIGN',false);
test('malformed JSON','{bad json','REJECT');
test('null document',null,'REJECT');
test('no products',{},'REJECT');
test('products null',{products:null},'REJECT');
test('products empty',{products:[]},'REJECT');
test('products primitive',{products:[false]},'REJECT');
test('products nested arrays',{products:[[]]},'REJECT');
const missingView=structuredClone(proposal);delete missingView.products[0].player_view;
test('missing party view',missingView,'REJECT');
const brokenMechanic=structuredClone(proposal);brokenMechanic.products[0].activation={bad:'type'};
test('unusual activation type',brokenMechanic,'REJECT');
const wrongSource=structuredClone(proposal);wrongSource.products[0].bom[0].source_id='ffffffffffffffffffffffffffffffff';
test('invalid source no preview',wrongSource,'REJECT');
console.log('PASS '+count+'/'+count+' R10 CLI fail-closed/sem preview residual');
