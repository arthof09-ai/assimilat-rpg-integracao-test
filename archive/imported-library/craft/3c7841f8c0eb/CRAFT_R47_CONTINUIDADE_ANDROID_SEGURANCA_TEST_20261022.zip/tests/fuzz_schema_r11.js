'use strict';
/* Deterministic robustness probe; not independent unit-test certification. */
const fs=require('fs'),path=require('path'),{valid}=require('../src/validate');
const root=path.join(__dirname,'..'), data=JSON.parse(fs.readFileSync(path.join(root,'data/proposals.json'),'utf8')),
  resources=JSON.parse(fs.readFileSync(path.join(root,'data/resources.json'),'utf8'));
let seed=20261021;const rnd=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/2**32};
const select=a=>a[Math.floor(rnd()*a.length)];
const things=[null,0,-3,1.5,'','x','PENDENTE',true,false,{},[],{includes:0},{step:1},{id:'B1'},[null]];
const fields=['proposal_id','name','module','family','design','physical_description','mechanic','activation','duration','cooldown','range','geography','acquisition','history','politics','gameplay','master_secrets','player_view','bom','process','economy','proof','search_scope','item_found_in_notion','rin_inherited_as_rank','pa_daily'];
const subfields=['node_id','source_id','role','qty','unit','consumed','evidence'];
const stepfields=['step','action','status','input_node_ids'];
let n=0;
for(let i=0;i<2000;i++){
  const d=JSON.parse(JSON.stringify(data));let x=d.products[Math.floor(rnd()*2)];let pathcode=Math.floor(rnd()*5);
  if(pathcode===0)x[select(fields)]=select(things);
  if(pathcode===1)x.bom[0][select(subfields)]=select(things);
  if(pathcode===2)x.process[0][select(stepfields)]=select(things);
  if(pathcode===3)x.player_view=select(things);
  if(pathcode===4)x.proof=select(things);
  try {const z=valid(d,resources); if(!z||!Array.isArray(z.items))throw Error('missing result');}
  catch(err){console.error('FAIL at vector '+i+' code '+pathcode+': '+err.stack);process.exitCode=1;process.exit();}
  n++;
}
console.log('PASS '+n+' deterministic malformed-input robustness probes; informational only');
