'''CRAFT R16 — teste de lote de 45 propostas no mesmo HTML mobile TEST.'''
from pathlib import Path
import json,tempfile,copy
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
base=json.loads((root/'data/proposals.json').read_text())
d={'products':[]}
for i in range(45):
 p=copy.deepcopy(base['products'][i%2]);p['proposal_id']=f'R16-TEST-ITEM-{i+1:03d}';p['name']=f'{p["name"]} — amostra {i+1}'
 d['products'].append(p)
checks=0
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];requests=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http://','https://')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('article.box').count()==2;checks+=1
 assert page.locator('#pager').inner_text().startswith('Página 1 de 1');checks+=1
 assert page.locator('#prev').is_disabled() and page.locator('#next').is_disabled();checks+=1
 with tempfile.TemporaryDirectory() as tmp:
  tmp=Path(tmp);f=tmp/'lote45.json';f.write_text(json.dumps(d,ensure_ascii=False))
  assert f.stat().st_size<2*1024*1024;checks+=1
  page.locator('#upload').set_input_files(str(f));page.wait_for_timeout(100)
  assert page.locator('#loadStatus').inner_text().startswith('Proposta TEST carregada');checks+=1
  assert page.locator('#pager').inner_text().startswith('Página 1 de 6');checks+=1
  assert page.locator('article.box').count()==8;checks+=1
  assert page.locator('#prev').is_disabled() and page.locator('#next').is_enabled();checks+=1
  assert 'amostra 1' in page.locator('article.box').first.inner_text();checks+=1
  for idx in range(2,7):
   page.locator('#next').click()
   assert page.locator('#pager').inner_text().startswith(f'Página {idx} de 6');checks+=1
   assert page.locator('article.box').count()==(5 if idx==6 else 8);checks+=1
  assert page.locator('#next').is_disabled() and page.locator('#prev').is_enabled();checks+=1
  assert 'amostra 45' in page.locator('article.box').last.inner_text();checks+=1
  page.locator('#prev').click()
  assert page.locator('#pager').inner_text().startswith('Página 5 de 6');checks+=1
  assert page.locator('article.box').count()==8;checks+=1
  with page.expect_download() as ev:page.locator('#save').click()
  out=tmp/'full_qa.json';ev.value.save_as(out);qa=json.loads(out.read_text())
  assert qa['status']=='HOLD_TEST_DESIGN';checks+=1
  assert qa['total']==45 and len(qa['items'])==45;checks+=1
  with page.expect_download() as ev2:page.locator('#evidence').click()
  p=tmp/'all_requests.json';ev2.value.save_as(p);plan=json.loads(p.read_text())
  assert len(plan['projects'])==45;checks+=1
  assert all(x['party_release_authorized'] is False and x['physical_success'] is False for x in plan['projects']);checks+=1
  assert all(x['missing_evidence'] for x in plan['projects']);checks+=1
  bad=copy.deepcopy(d);bad['products'][0]['player_view']['visible_properties']=bad['products'][0]['master_secrets']
  bf=tmp/'invalid.json';bf.write_text(json.dumps(bad,ensure_ascii=False));page.locator('#upload').set_input_files(str(bf));page.wait_for_timeout(50)
  assert page.locator('#loadStatus').inner_text().startswith('Falha no arquivo: Entrada rejeitada');checks+=1
  assert page.locator('#pager').inner_text().startswith('Página 5 de 6');checks+=1
  assert page.locator('article.box').count()==8;checks+=1
  assert not errors and not requests,(errors,requests);checks+=1
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1');checks+=1
 b.close()
print(f'R16 large-batch Chromium mobile PASS {checks}/{checks}; 45 TEST proposals, paginated 8/8/8/8/8/5; Android real not tested')
