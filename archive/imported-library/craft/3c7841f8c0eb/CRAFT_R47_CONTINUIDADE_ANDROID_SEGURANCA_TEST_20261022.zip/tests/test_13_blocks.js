'use strict';const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');const root=path.join(__dirname,'..');const m=JSON.parse(fs.readFileSync(path.join(root,'data/master_cards_13.json'))),g=JSON.parse(fs.readFileSync(path.join(root,'data/provenance_graph.json')));
let c=0;
assert.equal(m.cards.length,2);c++;
for(const card of m.cards){
 assert.equal(Object.keys(card.chapters).length,13);c++;
 assert(Object.keys(card.chapters).every(k=>/^(I_|II_|III_|IV_|V_|VI_|VII_|VIII_|IX_|X_|XI_|XII_|XIII_)/.test(k)));c++;
 assert.equal(card.chapters.XIII_AUDITORIA['MESTRE_ONLY'],true);c++;
 assert.equal(card.chapters.VIII_RECEITA_CADEIA.RC5,false);c++;
 assert.equal(card.chapters.VIII_RECEITA_CADEIA.REC_ID_canônico,null);c++;
 assert.equal(card.chapters.XII_JOGABILIDADE.efeito_jogavel,false);c++;
 assert.equal(card.chapters.V_ORIGEM_FORMACAO.formacao_real,null);c++;
}
assert(g.nodes.every(x=>x.type!=='OCORRENCIA_FABRICADA'&&x.type!=='PLAYER_FICHA_PUBLICA'));c++;
assert(g.edges.every(x=>x.not_physical_creation===true||x.no_stock_claim===true));c++;
assert(g.nodes.filter(x=>x.type==='ITEM_PROPOSTO').length===2);c++;
assert(g.nodes.filter(x=>x.type==='RECEITA_CANDIDATA').length===2);c++;
assert(g.nodes.filter(x=>x.type==='RECURSO_FICHA_EXISTENTE').length===4);c++;
assert(g.edges.length===6);c++;
assert(g.nodes.length===8);c++;
assert(new Set(g.nodes.map(x=>x.id)).size===g.nodes.length);c++;
console.log('PASS '+c+'/'+c+' testes ficha I–XIII e grafo anti-falsa-produção');
