'use strict';const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const dir=path.join(__dirname,'..'),report=JSON.parse(fs.readFileSync(path.join(dir,'outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json'))),d=JSON.parse(fs.readFileSync(path.join(dir,'data/r27_decision_register_readonly.json'))),r=JSON.parse(fs.readFileSync(path.join(dir,'data/r28_readback_21.json')));let n=0;const ok=(v,msg)=>{assert.ok(v,msg);n++};
ok(report.classification==='MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY','classification');ok(report.type==='ADVISORY_READONLY_NOT_CANONICAL','advisory');ok(report.all_choices_blank,'no author decisions');ok(report.cases.length===4,'3 plus upstream oil');ok(report.denominators.all_child_recipes===29,'29');ok(report.denominators.recipes_with_lexical_issues===21,'21');ok(report.denominators.remaining_without_reported_lexical_issue===8,'8');ok(report.crosscutting_count===7,'seven');
const issue_ids=new Set(d.issues.map(x=>x.physical_recipe_id));const rids=new Set(r.rows.map(x=>x.physical_recipe_id));let count=0;
for(const c of report.cases){ok(c.authority_state==='PENDENTE_DECISAO_MESTRE','pending '+c.key);ok(!c.canonical_mutation_performed&&!c.can_produce_or_release,'no write/release');ok(c.source_url.startsWith('https://app.notion.com/p/'),'source');ok(c.decision_slots.length>=2,'multiple decisions');
 if(c.physical_recipe_id){ok(issue_ids.has(c.physical_recipe_id)&&rids.has(c.physical_recipe_id),'mapped physical');ok(c.source_url.endsWith(c.physical_recipe_id),'url physical');}for(const s of c.decision_slots){ok(s.decision===null,'blank field');ok(s.question.length>25,'meaningful question');count++;}}
ok(count===11,'11 independent pending answers');
for(const [k,v] of Object.entries(report.constraints))ok(v===false,'gate still false '+k);
ok(!report.cases.some(c=>c.key==='MAT-01'),'no collapse of MAT-01 variants');
console.log(`R30 original 21-case decision register consistency ${n}/${n} PASS`);
