from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,json
html=(Path(__file__).resolve().parents[1]/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text();checks=0
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];requests=[];page.on('pageerror',lambda x:errors.append(str(x)));page.on('request',lambda x:requests.append(x.url) if x.url.startswith(('http:','https:')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('#r32-impact').is_visible();checks+=1
 with tempfile.TemporaryDirectory() as t:
  with page.expect_download() as info:page.locator('#r32-impact').click()
  file=Path(t)/'impact.json';info.value.save_as(file);plan=json.loads(file.read_text())
  assert plan['verdict']=='IMPACT_PLANNED_NOT_AUTHORIZED';checks+=1
  assert len(plan['actions'])==11;checks+=1
  assert plan['shared_dependencies']['links'][1]['conditional'] is True;checks+=1
  assert plan['counts']['child_recipe_total']==29;checks+=1
  assert plan['counts']['lexical_issue_cases']==21;checks+=1
  assert all(not x['physical_recipe_updated'] for x in plan['actions']);checks+=1
  assert not plan['recipe_rc5_approved'] and not plan['canonical_writer_or_fencing_verified'];checks+=1
  page.locator('#r31-decision-fields textarea').first.fill('Resolução ainda não autorizada');checks+=1
  with page.expect_download() as info:page.locator('#r32-impact').click()
  file=Path(t)/'second.json';info.value.save_as(file);plan=json.loads(file.read_text());checks+=1
  assert plan['actions'][0]['author_note_received_not_authenticated'];checks+=1
  assert 'Resolução ainda não autorizada' not in file.read_text();checks+=1
  assert not plan['all_author_decisions_authenticated'];checks+=1
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');checks+=1
  assert not errors,errors;checks+=1
  assert not requests,requests;checks+=1
 browser.close()
print(f'R32 browser impact workflow {checks}/{checks} PASS')
