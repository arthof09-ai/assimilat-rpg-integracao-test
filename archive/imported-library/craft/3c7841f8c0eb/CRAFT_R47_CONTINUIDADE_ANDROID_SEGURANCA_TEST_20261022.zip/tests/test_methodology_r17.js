'use strict';
// R17 — teste da lente de metodologia no validador EXISTENTE, sem motor paralelo.
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const {valid}=require('../src/validate');
const root=path.resolve(__dirname,'..');
const proposal=JSON.parse(fs.readFileSync(path.join(root,'data/proposals.json')));
const index=JSON.parse(fs.readFileSync(path.join(root,'data/resources.json')));
let count=0;
function chk(condition,message){assert.ok(condition,message);count++;}
function eq(actual,expected,message){assert.deepEqual(actual,expected,message);count++;}
function inspect(v){return valid(v,index)}
function cand(i){return inspect(proposal).items[i].methodology}
const qa=inspect(proposal);
eq(qa.status,'HOLD_TEST_DESIGN','dois projetos continuam HOLD');
eq(qa.total,2,'denominador dois');
for(let i=0;i<2;i++){
 const v=qa.items[i],m=v.methodology;
 eq(v.verdict,'HOLD_TEST_DESIGN','sem aprovação');
 eq(m.schema,'CRAFT_R17_METHODOLOGY_LENS_TEST_V1','schema');
 eq(m.decision.qa_verdict,v.verdict,'coerência da etapa');
 eq(m.resource.existing_first_search_complete,false,'pesquisa total não comprovada');
 eq(m.resource.new_crn_justified,false,'CRN sem prova proibida');
 eq(m.item.party_publication_allowed,false,'Party bloqueada');
 eq(m.item.master_proposal_only,true,'Mestre TEST');
 eq(m.item.pa_supplier_receipt_verified,false,'PA sem recibo');
 eq(m.recipe.canonical_recipe_identity_verified,false,'REC-ID não liberado');
 eq(m.recipe.rc5_demonstrated,false,'RC5 não demonstrado');
 eq(m.recipe.magic_transfer_verified,false,'transferência não demonstrada');
 eq(m.decision.physical_fabrication_allowed,false,'sem fabricação');
 eq(m.decision.stock_commit_allowed,false,'sem estoque');
 eq(m.decision.production_fencing_verified,false,'fencing não prova');
 eq(m.recipe.bom_nodes,proposal.products[i].bom.length,'conta BOM');
 eq(m.recipe.process_steps,proposal.products[i].process.length,'conta processo');
 eq(m.recipe.bom_quantified_nodes,0,'quantidades não inventadas');
 eq(m.recipe.production_parameters_missing.length,5,'campos faltantes não inventados');
 eq(m.recipe.bom_nodes_not_in_process.length,0,'cobre todos nós');
 eq(m.item.applicable_module,proposal.products[i].module,'família do caso');
 chk(!JSON.stringify(m).includes(proposal.products[i].master_secrets),'sem texto secreto no roteiro');
}
eq(cand(0).resource.existing_index_matches,2,'sonda duas fontes indexadas');
eq(cand(0).resource.unresolved_material_nodes,['B3'],'sonda suporte pendente');
eq(cand(1).resource.existing_index_matches,2,'tônico duas fontes indexadas');
eq(cand(1).resource.unresolved_material_nodes,['B3','B4'],'tônico veículo recipiente pendentes');
eq(cand(0).resource.unique_matching_sources,2,'contagem única sonda');
eq(cand(1).resource.unique_matching_sources,2,'contagem única tônico');
{
 const d=structuredClone(proposal);d.products[0].bom[0].qty=2;d.products[0].bom[0].unit='g';
 const x=inspect(d).items[0].methodology;eq(x.recipe.bom_quantified_nodes,1,'contabiliza quantidade sem liberar produção');eq(x.recipe.rc5_demonstrated,false,'quantidade não promove RC5');
}
{
 const d=structuredClone(proposal);d.products[0].bom[2].source_id='ffffffffffffffffffffffffffffffff';
 const v=inspect(d).items[0];eq(v.verdict,'REJECT','fonte forjada recusada');chk(v.methodology.decision.critical_issue_codes.includes('UNVERIFIED_RESOURCE'),'código presente na triagem');eq(v.methodology.decision.physical_fabrication_allowed,false,'sem fabricação apesar fonte forjada');
}
{
 const d=structuredClone(proposal);d.products[1].process[1].input_node_ids=[];
 const v=inspect(d).items[1];eq(v.verdict,'REJECT','passo com BOM desacoplada');eq(v.methodology.recipe.bom_nodes_not_in_process,['B2'],'identifica nó exato órfão');
}
{
 const d=structuredClone(proposal);d.products[1].bom[0].qty=-7;
 const v=inspect(d).items[1];chk(v.methodology.decision.critical_issue_codes.includes('INVALID_QUANTITY'),'quantidade inválida refletida');eq(v.methodology.recipe.bom_quantified_nodes,0,'não contabiliza negativo');
}
{
 const d=structuredClone(proposal);d.products[0].item_rank='Lendário';
 const v=inspect(d).items[0];eq(v.verdict,'REJECT','rank preatribuído não aceito');eq(v.methodology.item.effect_and_item_rank,'PENDENTE_AVALIACAO_INDEPENDENTE','lente não normaliza rank falso');
}
{
 const d=structuredClone(proposal);d.products[0].pa_daily=100;
 const v=inspect(d).items[0];eq(v.verdict,'REJECT','PA sem fornecedor');eq(v.methodology.item.pa_supplier_receipt_verified,false,'recibo não inventado');
}
{
 const d=structuredClone(proposal);d.products[0].proof.party_published=true;
 const v=inspect(d).items[0];eq(v.verdict,'REJECT','declaração Party rejeitada');eq(v.methodology.item.party_publication_allowed,false,'sem divulgação');
}
{
 const d=structuredClone(proposal);d.products[0].bom=null;
 const v=inspect(d).items[0];eq(v.verdict,'REJECT','sem BOM');eq(v.methodology.recipe.bom_nodes,0,'conta nulo com segurança');eq(v.methodology.recipe.rc5_demonstrated,false,'nega RC5');
}
{
 const d=structuredClone(proposal);d.products[0]=42;
 const v=inspect(d).items[0];eq(v.verdict,'REJECT','objeto inválido');eq(v.methodology.recipe.bom_nodes,0,'sem crash no resumo');eq(v.methodology.item.master_proposal_only,true,'não promove objeto inválido');
}
{
 const d=structuredClone(proposal);d.products.push({...structuredClone(d.products[0]),proposal_id:'R17-TEST-NEW-003'});
 const r=inspect(d);eq(r.total,3,'lote mais amplo');eq(r.items.length,3,'todas propostas examinadas');chk(r.items.every(x=>x.methodology.recipe.rc5_demonstrated===false),'sem promoção por escalar lote');
}
{
 const d=structuredClone(proposal);d.products[0].master_secrets='SINAL_SECRETO_MESTRE_R17_C1';
 const m=inspect(d).items[0].methodology;chk(!JSON.stringify(m).includes('SINAL_SECRETO_MESTRE_R17_C1'),'não copia segredo canário');
}

{
 const v=inspect({products:[]});eq(v.status,'REJECT','vazio continua rejeitado');eq(v.items[0].methodology.decision.physical_fabrication_allowed,false,'vazio recebe triagem fail-closed');
}
console.log(`R17 METHODOLOGY TEST PASS ${count}/${count} assertions`);
