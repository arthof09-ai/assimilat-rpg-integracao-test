'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {valid}=require('../src/validate');
const src=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/resources.json'))),base=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/proposals.json')));
let count=0;
function negative(mut,code){const d=structuredClone(base);mut(d);let res;assert.doesNotThrow(()=>res=valid(d,src));assert.equal(res.status,'REJECT');assert(res.items.some(x=>x.issues.some(e=>e.code===code)));count++;}
for(const v of [null,{}, {products:null},{products:[]},{products:'wrong'}]){let x;assert.doesNotThrow(()=>x=valid(v,src));assert.equal(x.status,'REJECT');assert.equal(x.total,0);count++}
negative(x=>x.products[0]=null,'PROJECT_OBJECT_INVALID');
negative(x=>x.products[0]=123,'PROJECT_OBJECT_INVALID');
negative(x=>x.products[0]=[],'PROJECT_OBJECT_INVALID');
negative(x=>x.products[0].bom[0]=null,'BOM_NODE_INVALID');
negative(x=>x.products[0].bom[0]=23,'BOM_NODE_INVALID');
negative(x=>x.products[0].process[0]=null,'PROCESS_STEP_INVALID');
negative(x=>x.products[0].process[0]=23,'PROCESS_STEP_INVALID');
negative(x=>x.products[0].process[0].input_node_ids=23,'PROCESS_INPUTS_INVALID');
negative(x=>x.products[0].process[0].input_node_ids='B1','PROCESS_INPUTS_INVALID');
assert.equal(valid(base,src).status,'HOLD_TEST_DESIGN');count++;
// Testa evento real de upload da UI, sem rede nem navegador externo.
const html=fs.readFileSync(path.join(__dirname,'../REVISOR_LOCAL_ANDROID_R53_TEST.html'),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1],els=new Map();
function el(){return {innerHTML:'',textContent:'',files:null,addEventListener(type,fn){this['on_'+type]=fn},click(){}}}
const doc={getElementById(k){if(!els.has(k))els.set(k,el());return els.get(k)},createElement(){return el()}};
const ctx={document:doc,console,setTimeout(){},Blob:class Blob{},URL:{createObjectURL(){return'blob:fake'},revokeObjectURL(){}},module:undefined};
vm.createContext(ctx);vm.runInContext(script,ctx,{timeout:3000});
const handler=els.get('upload').on_change;
assert.equal(typeof handler,'function');count++;
(async()=>{
 async function change(v){await handler({target:{files:[{size:Buffer.byteLength(v),name:'fixture.json',text:async()=>v}]}})}
 const orig=els.get('cards').innerHTML;
 await change('{this-is-malformed');assert(els.get('loadStatus').textContent.startsWith('Falha no arquivo'));assert.equal(els.get('cards').innerHTML,orig);count++;
 await change(JSON.stringify({products:[null]}));assert(els.get('loadStatus').textContent.includes('Entrada rejeitada'));assert.equal(els.get('cards').innerHTML,orig);count++;
 await change(JSON.stringify({products:[]}));assert(els.get('loadStatus').textContent.includes('não vazio'));count++;
 let attack=structuredClone(base);attack.products[0].item_rank='Ouro';await change(JSON.stringify(attack));assert(els.get('loadStatus').textContent.includes('RANK_SHORTCUT'));assert.equal(els.get('cards').innerHTML,orig);count++;
 const validJSON=JSON.stringify(base);await change(validJSON);assert(els.get('loadStatus').textContent.includes('Proposta TEST carregada'));assert(els.get('cards').innerHTML.includes('HOLD_TEST_DESIGN'));count++;
 const huge={size:2*1024*1024+1,name:'gigante.json',text:async()=>{throw Error('não deve ler bytes')}};
 await handler({target:{files:[huge]}});assert(els.get('loadStatus').textContent.includes('2 MiB'));count++;
 console.log('PASS '+count+'/'+count+' R9 input fail-closed + UI invalid-import recovery TEST');
})().catch(e=>{console.error(e);process.exitCode=1});
