from pathlib import Path
from playwright.sync_api import sync_playwright
import json,tempfile
root=Path(__file__).resolve().parents[1]; html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text(); n=0
def ok(v,m):
 global n
 assert v,m;n+=1
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 err=[];req=[];page.on('pageerror',lambda e:err.append(str(e)));page.on('request',lambda r:req.append(r.url) if r.url.startswith(('http:','https:')) else None)
 page.set_content(html)
 page.locator('.r40-case').first.evaluate('(e)=>e.open=true')
 p40=page.locator('#r40-decision-fields textarea').first
 p31=page.locator('#r31-decision-fields textarea').first
 page.locator('#r31-decision-fields details').first.evaluate('(e)=>e.open=true')
 with tempfile.TemporaryDirectory() as directory:
  root_tmp=Path(directory)
  for nfile,name,button in [('r40.json','r40','#r40-save'),('r31.json','r31','#r31-save')]:
   with page.expect_download() as d:page.locator(button).click()
   d.value.save_as(root_tmp/nfile)
  r40=json.loads((root_tmp/'r40.json').read_text());r31=json.loads((root_tmp/'r31.json').read_text())
  r40['cases'][0]['slots'][0]['author_note']='VERSAO EXTERNA'
  r40['all_notes_blank']=False
  (root_tmp/'r40.json').write_text(json.dumps(r40,ensure_ascii=False))
  r31['cases'][0]['decision_slots'][0]['decision']='OUTRA DECISAO EXTERNA'
  r31['all_choices_blank']=False
  (root_tmp/'r31.json').write_text(json.dumps(r31,ensure_ascii=False))
  p40.fill('LOCAL NÃO EXPORTADO');p31.fill('ANOTAÇÃO LOCAL NÃO EXPORTADA')
  ok('EXPORTAÇÃO RECOMENDADA' in page.locator('#r45-safety-status').inner_text(),'unsaved local state')
  dialogs=[]
  page.once('dialog',lambda d:(dialogs.append(d.message),d.dismiss()))
  page.locator('#r40-upload').set_input_files(root_tmp/'r40.json')
  page.wait_for_function("document.querySelector('#r40-status').textContent.includes('CANCELADA')")
  ok(len(dialogs)==1 and 'R40' in dialogs[0],'R40 asks explicit consent')
  ok(p40.input_value()=='LOCAL NÃO EXPORTADO','R40 cancel preserves local')
  ok(page.locator('#r40-upload').input_value()=='','R40 can reselect same file after cancel')
  page.once('dialog',lambda d:(dialogs.append(d.message),d.accept()))
  page.locator('#r40-upload').set_input_files(root_tmp/'r40.json')
  page.wait_for_function("document.querySelector('#r40-decision-fields textarea').value==='VERSAO EXTERNA'")
  ok(p40.input_value()=='VERSAO EXTERNA','R40 explicit confirm imports')
  ok('0 decisões canônicas' in page.locator('#r40-status').inner_text(),'R40 import never authenticates')
  dialogs31=[]
  page.once('dialog',lambda d:(dialogs31.append(d.message),d.dismiss()))
  page.locator('#r31-upload').set_input_files(root_tmp/'r31.json')
  page.wait_for_function("document.querySelector('#r31-status').textContent.includes('CANCELADA')")
  ok(len(dialogs31)==1 and 'R31' in dialogs31[0],'R31 asks explicit consent')
  ok(p31.input_value()=='ANOTAÇÃO LOCAL NÃO EXPORTADA','R31 cancel preserves local')
  ok(page.locator('#r31-upload').input_value()=='','R31 can reselect same file after cancel')
  page.once('dialog',lambda d:(dialogs31.append(d.message),d.accept()))
  page.locator('#r31-upload').set_input_files(root_tmp/'r31.json')
  page.wait_for_function("document.querySelector('#r31-decision-fields textarea').value==='OUTRA DECISAO EXTERNA'")
  ok(p31.input_value()=='OUTRA DECISAO EXTERNA','R31 explicit confirm imports')
  ok('0 escritas canônicas' in page.locator('#r31-status').inner_text(),'R31 still no write')
  # A tampered file is rejected BEFORE asking for consent.
  bad=json.loads((root_tmp/'r40.json').read_text());bad['no_rc5_approval']=False
  (root_tmp/'bad.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r40-upload').set_input_files(root_tmp/'bad.json')
  page.wait_for_function("document.querySelector('#r40-status').textContent.startsWith('REJEITADO')")
  ok(p40.input_value()=='VERSAO EXTERNA','tampered file cannot overwrite existing notes')
  ok(len(dialogs)==2,'no confirm for tampered file')
 ok(not req,'no network calls');ok(not err,err)
 for w in [320,390,430]:
  page.set_viewport_size({'width':w,'height':800})
  ok(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),f'no overflow at {w}')
 browser.close()
print(f'R47 guarded draft import Chromium {n}/{n} PASS')
