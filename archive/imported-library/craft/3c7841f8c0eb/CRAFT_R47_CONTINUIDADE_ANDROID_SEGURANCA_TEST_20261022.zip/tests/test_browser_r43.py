from pathlib import Path
from playwright.sync_api import sync_playwright
import json,tempfile
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text();n=0
def ok(b,m):
 global n
 assert b,m;n+=1
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errs=[];net=[];p.on('pageerror',lambda e:errs.append(str(e)));p.on('request',lambda req:net.append(req.url) if req.url.startswith(('http://','https://')) else None)
 p.set_content(html,wait_until='load')
 ok(p.locator('#r43-plan-export').count()==1,'one new export');ok(p.locator('#r40-decision-fields textarea').count()==50,'50')
 ok(p.locator('#r42-navigator').count()==1,'R42 preserved');ok(p.locator('#r31-decision-fields textarea').count()==11,'11')
 with tempfile.TemporaryDirectory() as temp:
  with p.expect_download() as dl:p.locator('#r43-plan-export').click()
  f=Path(temp)/'base.json';dl.value.save_as(f);d=json.loads(f.read_text())
  ok(d['schema']=='CRAFT_R43_REVALIDATION_PLAN_TEST_V1','schema');ok(len(d['actions'])==22,'22');ok(sum(len(c['slots']) for c in d['actions'])==50,'50 slots');ok(d['notes_present']==0,'no notes');ok(not d['canonical_write'] and not d['rc5_allowed'] and not d['party_release'],'hold');
  first=p.locator('.r40-case').first;first.evaluate('(e)=>e.open=true');first.locator('textarea').first.fill('TEST_PRIVADO_NAO_AUTENTICADO')
  with p.expect_download() as dl:p.locator('#r43-plan-export').click()
  f=Path(temp)/'one.json';dl.value.save_as(f);d=json.loads(f.read_text())
  ok(d['notes_present']==1,'one note');ok('ENC-08' in d['requires_author_review'],'trace case');ok('TEST_PRIVADO_NAO_AUTENTICADO' not in f.read_text(),'no leak');
  ok(d['actions'][0]['slots'][0]['state']=='AGUARDA_AUTENTICACAO','not authenticated');ok(d['upstream_oil_cascade']['literal_bom_mentions']==28,'oil scope');
  p.locator('#r42-priority').select_option('UPSTREAM')
  with p.expect_download() as dl:p.locator('#r43-plan-export').click()
  f=Path(temp)/'filtered.json';dl.value.save_as(f);d=json.loads(f.read_text())
  ok(d['questions_total']==50 and d['notes_present']==1,'filter only visual, exports all')
  with p.expect_download() as dl:p.locator('#r40-save').click()
  f=Path(temp)/'draft.json';dl.value.save_as(f);d=json.loads(f.read_text());ok(d['cases'][0]['slots'][0]['author_note']=='TEST_PRIVADO_NAO_AUTENTICADO','original draft retains text')
 ok(not errs,'zero pageerror '+str(errs));ok(not net,'no network '+str(net))
 for width in (320,360,390,430):p.set_viewport_size({'width':width,'height':840});ok(p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),f'no overflow {width}')
 b.close()
print('R43 Chromium mobile '+str(n)+'/'+str(n)+' PASS')
