'use strict';
const assert=require('node:assert/strict');const {compareR44SourceStamps}=require('../src/r44_recipe_freshness');
const fs=require('fs');const path=require('path');
let n=0;function ok(x,label){assert(x,label);n++}
const original=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/r44_29_notion_metadata_readback.json'),'utf8'));
const source=Array.isArray(original)?original:original.baseline||original.recipes||original.entries||original.records;
assert(Array.isArray(source));
const records=source.map((x,i)=>({...x,case_key:x.case_key||'CASE'+i}));
ok(records.length===29,'29 recipe records');
ok(new Set(records.map(x=>x.physical_recipe_id)).size===29,'unique baseline');
const good=compareR44SourceStamps(records,structuredClone(records));
ok(good.verdict==='NO_TIMESTAMP_DRIFT_OBSERVED','no drift when unchanged');
ok(good.physical_recipe_ids_unique===true,'returned uniqueness truth');
ok(good.approved_for_write===false,'unchanged is not write authorization');
ok(good.rc5===false,'unchanged not RC5');
function chk(b,l,v,label){const z=compareR44SourceStamps(b,l);ok(z.verdict==='HOLD_INCOMPLETE_READBACK',label+':blocked');ok(z.reason===v,label+':reason');ok(z.approved_for_write===false,label+':write false');ok(z.rc5===false,label+':no RC5')}
let b=structuredClone(records);b[2].physical_recipe_id=b[1].physical_recipe_id;chk(b,structuredClone(b),'DUPLICATE_BASE_PHYSICAL_ID','identical pair of poisoned corpora');
let l=structuredClone(records);l[3].physical_recipe_id=l[2].physical_recipe_id;chk(records,l,'DUPLICATE_LIVE_PHYSICAL_ID','duplicate live');
b=structuredClone(records);b[1].case_key=b[0].case_key;chk(b,structuredClone(b),'DUPLICATE_BASE_KEY','duplicate baseline key');
l=structuredClone(records);l[1].case_key=l[0].case_key;chk(records,l,'DUPLICATE_LIVE_KEY','duplicate current key');
l=structuredClone(records);l[2].edited='2026-10-30T00:00:00.000Z';const changed=compareR44SourceStamps(records,l);
ok(changed.verdict==='HOLD_SOURCE_DRIFT','real changed stamp stays HOLD');ok(changed.changed.length===1,'one drift');ok(changed.approved_for_write===false,'no write from drift');
l=structuredClone(records);l[2].parent='Outra página';ok(compareR44SourceStamps(records,l).verdict==='HOLD_SOURCE_DRIFT','changed parent HOLD');
l=structuredClone(records);l[2].physical_recipe_id='f'.repeat(32);chk(records,l,'PHYSICAL_ID_CHANGED','unexpected distinct ID');
ok(compareR44SourceStamps(records,records.slice(1)).verdict==='HOLD_INCOMPLETE_READBACK','incomplete corpus denied');
console.log('PASS '+n+'/'+n+' R46 physical recipe UUID uniqueness fail-closed');
