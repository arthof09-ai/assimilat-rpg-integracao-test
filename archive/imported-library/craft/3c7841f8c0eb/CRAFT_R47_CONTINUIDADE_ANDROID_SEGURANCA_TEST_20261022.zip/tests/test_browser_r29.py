from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,copy,json
r=Path(__file__).resolve().parents[1];html=(r/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text()
checks=0
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errs=[];requests=[]
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('request',lambda rq:requests.append(rq.url) if rq.url.startswith(('http:','https:')) else None)
 page.set_content(html,wait_until='load')
 assert page.locator('#r46-review').is_visible();checks+=1
 assert page.locator('#r46-export').is_disabled();checks+=1
 base=page.evaluate('evidencePlan(current.items)')
 assert len(base['projects'])==2;checks+=1
 assert sum(len(p['targeted_material_requests']) for p in base['projects'])==3;checks+=1
 with tempfile.TemporaryDirectory() as td:
  td=Path(td)
  def upload(data,name='r46.json'):
   f=td/name;f.write_text(json.dumps(data,ensure_ascii=False));page.locator('#r46-upload').set_input_files(f)
   page.wait_for_timeout(75)
  upload(base)
  assert page.locator('#r46-export').is_enabled();checks+=1
  assert '0/72' in page.locator('#r46-status').inner_text();checks+=1
  with page.expect_download() as info:page.locator('#r46-export').click()
  loc=td/'review.json';info.value.save_as(loc);s=json.loads(loc.read_text())
  assert s['verdict']=='REPORTED_DATA_TRIAGED_NOT_VERIFIED';checks+=1
  assert s['fields_reported']==0;checks+=1
  assert s['node_count']==3;checks+=1
  assert all(n['review_state']=='RELATO_NAO_VERIFICADO' for n in s['nodes']);checks+=1
  assert s['production_or_party_release_allowed'] is False;checks+=1
  reported=copy.deepcopy(base)
  for p in reported['projects']:
   for n in p['targeted_material_requests']:
    for f in n['evidence_requirements']:f['observed_data']='Relato TEST não auditado';f['proof_url']='https://example.org/proof'
    for k in n['r46_record']:n['r46_record'][k]='Relato TEST não auditado'
  upload(reported,'filled.json')
  assert '72/72' in page.locator('#r46-status').inner_text();checks+=1
  assert page.locator('#r46-export').is_enabled();checks+=1
  data=page.evaluate('r46Review')
  assert data['fields_reported']==72;checks+=1
  assert 'Relato TEST não auditado' not in json.dumps(data);checks+=1
  assert not data['magic_transfer_demonstrated'];checks+=1
  assert not data['production_or_party_release_allowed'];checks+=1
  broken=copy.deepcopy(reported);broken['projects'][0]['targeted_material_requests'][0]['certification_status']='PHYSICALLY_CERTIFIED'
  upload(broken,'broken.json')
  assert page.locator('#r46-export').is_disabled();checks+=1
  assert 'REJEITADO' in page.locator('#r46-status').inner_text();checks+=1
  assert page.evaluate('r46Review.verdict')=='REJECT_UNTRUSTED_REPORT';checks+=1
  assert page.evaluate('current.total')==2;checks+=1
  # Restore evidence, then update proposal; page clears inherited report even if ID remains.
  upload(base,'again.json');assert page.locator('#r46-export').is_enabled();checks+=1
  d=page.evaluate('PROJECT');d['products'][0]['design']+=' — outra versão'
  page.evaluate('d=>{PROJECT=d;render(true)}',d)
  upload(base,'stale.json')
  assert page.locator('#r46-export').is_disabled();checks+=1
  assert page.evaluate('r46Review.reason') in ('IMMUTABLE_FIELDS_CHANGED','IDENTITY_DRIFT');checks+=1
  assert not errs,errs;checks+=1
  assert not requests,requests;checks+=1
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');checks+=1
 browser.close()
print(f'R29 Chromium mobile inline {checks}/{checks} PASS')
