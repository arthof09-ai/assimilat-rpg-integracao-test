# CRAFT R20 — briefing de criação a partir de intenção / TEST Mestre

## Função real

Amplia o revisor offline R53/R18 EXISTENTE, sem criar novo sistema: três campos de entrada pequenos (tipo RESOURCE/ITEM/RECIPE, nome provisório e objetivo desejado) geram arquivo JSON `CRAFT_R20_BRIEF_CRIACAO_MESTRE_TEST.json` com roteiro de pesquisa de fontes canônicas, requisitos pendentes e negativas explícitas de autorização. Não gera recurso/item/receita, não executa a criação, não pesquisa automaticamente o Notion e não possui efeitos sobre o cânone, estoque ou Party.

## Autoridade / precedência

Recurso → PR-CRN-01 / EXISTING-FIRST e GAP; Item → PR-ITEM-02 / Atlas + PA aplicável; Receita → REC-EXEC, REC-LIB-01, PR-SC-01 / BOM-processo, unidades e economia; estado e gates NAC-CONT-03/NAC-NORM-01/NAC-PASS; F5 C19-021 RED, IBX-38 fencing NÃO DEMONSTRADO, R51 destino da biblioteca PENDENTE.

## Como usar (Android, TEST)

1. Abrir `REVISOR_LOCAL_ANDROID_R53_TEST.html` como arquivo TEST, se o navegador permitir; ambiente de teste validado via Chromium inline, **não** no aparelho Android real.
2. No painel **Novo pedido de pesquisa de criação (Mestre TEST)** escolher recurso/item/receita, informar nome provisório e finalidade.
3. Baixar o JSON. Ele é uma **solicitação de pesquisa**, não um item criado nem uma receita publicável. Entregar apenas a executor MESTRE-SIDE autorizado quando fizer sentido; jamais encaminhar à Party.
4. Continuar auditando/importando/exportando as propostas existentes independentemente do formulário. O projeto ativo NÃO muda com o briefing.

## Resultados verificáveis

Regressões JS R53–R17 517/517 (12 suites). 2000 vetores determinísticos informacionais separados. UI Chromium mobile R9 15 + R11 20 + R12 16 + R14 40 + R16 33 + R17 30 + R18 171 + R20 56 = 381/381; 56 checks novos para três tipos, JSON/download, critérios fail-closed, injeção de texto sem execução, 0 rede, importação preservada. Saídas normais QA e prévia Player idênticas R18; recibo `OUTPUT_COMMIT.json` íntegro. Fronteira: nenhum teste físico/Android file:// ou homologação RC5, rank, custo, efeito ou produção.

## Regra de leitura

Campos de evidência iniciais são `false` e nomes/objetivos são **intenções fornecidas**, não VERIFICADOS. As instruções do próprio JSON são dados informativos para o operador, nunca uma permissão para modificar Notion. Não criar norma, página oficial, nem motor paralelo. R20 é delta de interface no R53, continuando R18.
