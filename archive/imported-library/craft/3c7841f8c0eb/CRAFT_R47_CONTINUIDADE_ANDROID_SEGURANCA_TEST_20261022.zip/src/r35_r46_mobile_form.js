// R35: ergonomic input for the three PREEXISTING R46 requests. No physical certification.
const r35Root=document.getElementById('r35-r46-fields'),r35Status=document.getElementById('r35-status');
if(r35Root&&typeof r35Root.appendChild==='function'){
 let r35Baseline=null,r35ProjectSnapshot=null;
 function r35Build(){
  r35Root.replaceChildren();
  r35Baseline=evidencePlan(valid(PROJECT,INDEX).items);
  r35ProjectSnapshot=JSON.stringify(PROJECT);
  let nodeN=0,fieldN=0;
  for(const proj of r35Baseline.projects)for(const node of proj.targeted_material_requests){
   const container=document.createElement('details');container.className='r35-node';
   const title=document.createElement('summary');title.textContent=node.proposal_id+' / '+node.node_id+' — '+node.material_role;
   container.appendChild(title);
   const explain=document.createElement('p');explain.textContent='Precedente pesquisado, NÃO prova. Cada campo pode permanecer vazio. Não registrar segredo Player.';explain.className='small';container.appendChild(explain);
   function field(label,key,kind,idx){
    const lab=document.createElement('label'),input=document.createElement('input');
    lab.textContent=label;input.type='text';input.maxLength=(kind==='proof'?2048:4096);
    input.dataset.projectId=node.proposal_id;input.dataset.nodeId=node.node_id;
    input.dataset.kind=kind;input.dataset.key=key;if(idx!==undefined)input.dataset.requirementIndex=String(idx);
    input.placeholder=kind==='proof'?'Link https://... ou vazio':'Observação real/relato ou vazio';
    container.appendChild(lab);container.appendChild(input);fieldN++;
   }
   node.evidence_requirements.forEach((req,i)=>{field(req.key+' — '+req.request,req.key,'observed',i);field('Prova/URL para '+req.key,req.key,'proof',i)});
   for(const key of Object.keys(node.r46_record))field('R46: '+key,key,'r46');
   r35Root.appendChild(container);nodeN++;
  }
  r35Status.textContent='Coleta local para '+nodeN+' nós e '+fieldN+' campos. Nenhum dado preenchido ou verificado.';
 }
 function r35CreateReport(){
  if(JSON.stringify(PROJECT)!==r35ProjectSnapshot)return {verdict:'REJECT_PROPOSAL_VERSION_CHANGED'};
  const report=JSON.parse(JSON.stringify(r35Baseline));
  for(const input of r35Root.querySelectorAll('input[data-kind]')){
   const p=report.projects.find(p=>p.proposal_id===input.dataset.projectId);
   const n=p?.targeted_material_requests.find(n=>n.node_id===input.dataset.nodeId);
   if(!n)return {verdict:'REJECT_TARGET_DRIFT'};
   const val=input.value.trim()||null;
   if(input.dataset.kind==='r46')n.r46_record[input.dataset.key]=val;
   else if(input.dataset.kind==='observed')n.evidence_requirements[Number(input.dataset.requirementIndex)].observed_data=val;
   else if(input.dataset.kind==='proof')n.evidence_requirements[Number(input.dataset.requirementIndex)].proof_url=val;
  }
  const review=reviewR46Report(report,r35Baseline);
  if(review.verdict!=='REPORTED_DATA_TRIAGED_NOT_VERIFIED')return {verdict:'REJECT_REPORT_INVALID',reason:review.reason};
  return {verdict:'R46_DRAFT_REPORTED_NOT_VERIFIED',report,review};
 }
 document.getElementById('r35-reset').addEventListener('click',()=>{
   const populated=Array.from(r35Root.querySelectorAll('input[data-kind]')).filter(e=>e.value.trim()).length;
   // Real Android may not show beforeunload: explicit destructive-action gate.
   if(populated>0 && (typeof window==='undefined'||typeof window.confirm!=='function'||
      !window.confirm('Há '+populated+' campos de coleta preenchidos. Recriar apagará estes relatos locais. Já exportou uma cópia?'))){
      r35Status.textContent='Recriação CANCELADA. '+populated+' campos preservados; exporte o relato antes de recriar.';
      return;
   }
   r35Build();document.dispatchEvent(new Event('craft-r35-reset'));
 });
 document.getElementById('r35-export').addEventListener('click',()=>{
  const x=r35CreateReport();if(x.verdict!=='R46_DRAFT_REPORTED_NOT_VERIFIED'){
    r35Status.textContent='REJEITADO — '+(x.reason||x.verdict)+'; reconstruir ficha se a versão das propostas mudou.';return;
  }
  const blob=new Blob([JSON.stringify(x.report,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='CRAFT_R35_COLETA_R46_NAO_VERIFICADA_MESTRE_TEST.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
  r35Status.textContent=x.review.fields_reported+'/'+x.review.fields_required+' campos declarados; 0 laudos comprovados. Verifique se o download foi guardado; use a triagem R29.';document.dispatchEvent(new Event('craft-r35-export-requested'));
 });
 r35Build();
}
