// R42 mobile navigation added to the SAME R40 author review panel, not a new engine.
(function(){
const section=document.getElementById('r40-author');
const grid=document.getElementById('r40-decision-fields');
if(!section||!grid||typeof section.insertBefore!=='function'||typeof grid.querySelectorAll!=='function'||typeof projectR42Nav!=='function')return;
const pane=document.createElement('div');pane.id='r42-navigator';pane.className='box';
pane.style.margin='12px 0';
const h=document.createElement('h2');h.textContent='R42 — Localizar pendências (somente visual)';pane.appendChild(h);
const note=document.createElement('p');note.className='small';note.textContent='Busque materiais/receitas e filtre por prioridade ou progresso. Anotações permanecem no formulário local, sem autenticação ou publicação.';pane.appendChild(note);
function field(tag,id,title,options){const l=document.createElement('label');l.htmlFor=id;l.textContent=title;const e=document.createElement(tag);e.id=id;if(options)for(const [value,text] of options){const o=document.createElement('option');o.value=value;o.textContent=text;e.appendChild(o);}pane.append(l,e);return e;}
const q=field('input','r42-search','Buscar por receita, material ou pergunta');q.type='search';q.maxLength=120;q.placeholder='Ex.: óleo, matriz, cristal...';
const priority=field('select','r42-priority','Prioridade', [['ALL','Todas'],['P0','P0'],['P1','P1'],['P2','P2'],['P3','P3'],['UPSTREAM','Insumo compartilhado']]);
const status=field('select','r42-progress','Estado das anotações', [['ALL','Todos'],['UNTOUCHED','Sem anotações'],['PARTIAL','Parciais'],['COMPLETE','Completas (não autenticadas)'],['INCOMPLETE','Ainda incompletas']]);
const s=document.createElement('p');s.id='r42-nav-status';s.className='small';s.setAttribute('role','status');pane.appendChild(s);
const next=document.createElement('button');next.type='button';next.id='r42-first-pending';next.className='secondary';next.textContent='Abrir primeira pendência visível';pane.appendChild(next);
const clear=document.createElement('button');clear.type='button';clear.id='r42-clear';clear.className='secondary';clear.textContent='Limpar filtros';pane.appendChild(clear);
section.insertBefore(pane,grid);
const blocks=Array.from(grid.querySelectorAll(':scope > details.r40-case'));
if(blocks.length!==R40_AUTHOR_BASELINE.cases.length)return;
function snapshot(){
 const notes={};for(let i=0;i<blocks.length;i++){
  const c=R40_AUTHOR_BASELINE.cases[i],inputs=blocks[i].querySelectorAll('textarea');
  for(let j=0;j<c.slots.length;j++)notes[c.key+':'+c.slots[j].slot_id]=inputs[j]?.value??'';
 }
 return projectR42Nav(R40_AUTHOR_BASELINE.cases,notes,{search:q.value,priority:priority.value,status:status.value});
}
function render(){
 const view=snapshot();if(!view.valid){s.textContent='Filtro indisponível: '+view.reason;return;}
 for(let i=0;i<blocks.length;i++)blocks[i].hidden=!view.cases[i].visible;
 s.textContent=view.visible_cases+'/22 grupos visíveis · '+view.visible_questions+'/50 perguntas no filtro · '+view.notes_present+'/50 anotações locais, NÃO autenticadas.';
 next.disabled=view.visible_cases===0||!view.cases.some(c=>c.visible&&c.notes_missing>0);
}
for(const el of [q,priority,status])el.addEventListener('input',render);
grid.addEventListener('input',render); // update progress without discarding any draft data
document.addEventListener('craft-r40-notes-imported',render);
clear.addEventListener('click',()=>{q.value='';priority.value='ALL';status.value='ALL';render();});
next.addEventListener('click',()=>{
 const v=snapshot(),i=v.cases.findIndex(x=>x.visible&&x.notes_missing>0);if(i<0)return;
 const b=blocks[i];b.open=true;b.scrollIntoView?.({block:'nearest'});
 const c=R40_AUTHOR_BASELINE.cases[i];const ins=b.querySelectorAll('textarea');
 let j=c.slots.findIndex((slot,k)=>!ins[k]?.value.trim());if(j<0)j=0;
 ins[j]?.focus?.({preventScroll:true});
});
render();
})();
