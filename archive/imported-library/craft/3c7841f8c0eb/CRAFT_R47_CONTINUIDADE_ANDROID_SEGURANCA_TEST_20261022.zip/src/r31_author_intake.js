// CRAFT R31 -- intake of AUTHOR NOTES ONLY. Existing R30 questions/UUIDs are immutable.
// A populated note is NOT authenticated as a Mestre order or canonized.
'use strict';
function reviewAuthorDraft(incoming,baseline){
 const deny=(reason)=>({schema:'CRAFT_R31_AUTHOR_DRAFT_TRIAGE_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
   verdict:'REJECT_UNTRUSTED_DRAFT',reason,decisions_reported:0,slots_total:11,notes_forwarded:false,
   authorship_verified:false,canonical_write_allowed:false,physical_recipe_modified:false,
   recipe_rc5_approved:false,party_or_o_primeiro_release_allowed:false});
 const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
 if(!plain(incoming)||!plain(baseline)||incoming.schema!=='CRAFT_R30_AUTHOR_DECISIONS_TEST_V1'||baseline.schema!=='CRAFT_R30_AUTHOR_DECISIONS_TEST_V1')return deny('WRONG_BASELINE_SCHEMA');
 let size;try{size=JSON.stringify(incoming).length;}catch{return deny('NOT_SERIALIZABLE')}
 if(size>131072)return deny('SIZE_LIMIT_128K');
 if(!Array.isArray(incoming.cases)||!Array.isArray(baseline.cases)||incoming.cases.length!==baseline.cases.length)return deny('CASE_SET_CHANGED');
 let masked;try{masked=JSON.parse(JSON.stringify(incoming))}catch{return deny('MALFORMED_DRAFT')}
 const cases=[];const observedKeys=new Set();let total=0,reported=0;
 for(let i=0;i<incoming.cases.length;i++){
  const c=incoming.cases[i],m=masked.cases[i],b=baseline.cases[i];
  if(!plain(c)||!plain(b)||!plain(m)||!Array.isArray(c.decision_slots)||!Array.isArray(b.decision_slots)||c.decision_slots.length!==b.decision_slots.length)return deny('SLOT_SET_CHANGED');
  const missing=[];
  for(let j=0;j<c.decision_slots.length;j++){
   const s=c.decision_slots[j],ms=m.decision_slots[j];
   if(!plain(s)||!plain(ms)||!Object.prototype.hasOwnProperty.call(s,'decision'))return deny('DECISION_FIELD_MISSING');
   const label=c.key+':'+s.id;
   if(observedKeys.has(label))return deny('DUPLICATE_SLOT');
   observedKeys.add(label);
   const value=s.decision;
   if(value!==null&&(typeof value!=='string'||value.trim().length===0||value.length>1500||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)))return deny('INVALID_DECISION_TEXT');
   if(value===null)missing.push(s.id);else reported++;
   total++;ms.decision=null;
  }
  cases.push({key:c.key,physical_recipe_id:c.physical_recipe_id,source_url:c.source_url,
   slots_reported:c.decision_slots.length-missing.length,slots_total:c.decision_slots.length,
   pending_slot_ids:missing,notes_state:'TEXT_RECEIVED_UNVERIFIED_NOT_CANONICAL'});
 }
 if(total!==11)return deny('ELEVEN_SLOT_CONTRACT_BROKEN');
 if(incoming.all_choices_blank!==(reported===0))return deny('DRAFT_STATUS_INCONSISTENT');
 masked.all_choices_blank=baseline.all_choices_blank;
 if(JSON.stringify(masked)!==JSON.stringify(baseline))return deny('IMMUTABLE_R30_FIELDS_CHANGED');
 return {schema:'CRAFT_R31_AUTHOR_DRAFT_TRIAGE_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
  verdict:'AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED',source_schema:baseline.schema,
  source_docket_sha256:baseline.source_docket_sha256,source_readback_as_of:baseline.readback_as_of,
  source_freshness:'FROZEN_R30_NOT_LIVE',decisions_reported:reported,slots_total:total,
  pending_slots:total-reported,cases,notes_forwarded:false,authorship_verified:false,
  decisions_authenticated_by_mestre:false,canonical_write_allowed:false,physical_recipe_modified:false,
  recipe_rc5_approved:false,magic_transfer_demonstrated:false,party_or_o_primeiro_release_allowed:false,
  requires_real_mestre_confirmation:true,requires_canonical_readback_and_fencing:true,
  warning:'Somente minuta textual não autenticada, não determina ingrediente, unidade, quantidade, rank, PA, custo, estoque ou produção.'};
}
if(typeof module!=='undefined'&&module.exports)module.exports={reviewAuthorDraft};
