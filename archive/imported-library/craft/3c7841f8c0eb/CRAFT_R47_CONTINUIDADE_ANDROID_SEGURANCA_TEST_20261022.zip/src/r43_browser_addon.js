// Adds one export action to existing 50-question surface, never a write engine.
(function(){const section=document.getElementById('r40-author'),save=document.getElementById('r40-save'),root=document.getElementById('r40-decision-fields');
 if(!section||!save||!root||typeof root.querySelectorAll!=='function'||typeof section.insertBefore!=='function')return;
 const btn=document.createElement('button');btn.id='r43-plan-export';btn.type='button';btn.className='secondary';btn.textContent='Baixar roteiro de revalidação (50 perguntas, sem notas)';
 section.insertBefore(btn,document.getElementById('r40-upload').previousElementSibling||root.nextSibling);
 btn.addEventListener('click',()=>{
  const draft=JSON.parse(JSON.stringify(R40_AUTHOR_BASELINE));
  const sections=Array.from(root.querySelectorAll(':scope > details.r40-case'));
  if(sections.length!==draft.cases.length)return;
  for(let i=0;i<draft.cases.length;i++){
   const inputs=sections[i].querySelectorAll('textarea');
   if(inputs.length!==draft.cases[i].slots.length)return;
   for(let j=0;j<draft.cases[i].slots.length;j++){
    const value=inputs[j].value.trim();draft.cases[i].slots[j].author_note=value||null;
   }
  }
  draft.all_notes_blank=draft.cases.every(c=>c.slots.every(s=>s.author_note===null));
  const plan=makeR43Plan(draft,R40_AUTHOR_BASELINE);
  if(plan.verdict!=='PLAN_NOT_AUTHENTICATED')return;
  const blob=new Blob([JSON.stringify(plan,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='CRAFT_R43_ROTEIRO_REVALIDACAO_50_MESTRE_TEST.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
 });
})();
