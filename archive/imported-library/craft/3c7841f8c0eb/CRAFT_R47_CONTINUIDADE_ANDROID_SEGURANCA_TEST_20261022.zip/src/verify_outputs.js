
'use strict';
// Verificador local do recibo final. Nunca atesta publicação ou medição física.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const outputs=path.join(__dirname,'..','outputs');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
function check(folder=outputs){
  const fail=(code)=>({verified:false,code});
  let stamp,qaBytes,viewBytes,qa,view;
  try{
    stamp=JSON.parse(fs.readFileSync(path.join(folder,'OUTPUT_COMMIT.json')));
    qaBytes=fs.readFileSync(path.join(folder,'QA_RESULT.json'));
    viewBytes=fs.readFileSync(path.join(folder,'PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'));
    qa=JSON.parse(qaBytes);view=JSON.parse(viewBytes);
  }catch(_){return fail('COMMIT_OR_OUTPUT_MISSING');}
  if(stamp.schema!=='CRAFT_TEST_OUTPUT_COMMIT_V1')return fail('COMMIT_SCHEMA_INVALID');
  if(stamp.qa_sha256!==sha(qaBytes)||stamp.preview_sha256!==sha(viewBytes)||
     stamp.qa_bytes!==qaBytes.length||stamp.preview_bytes!==viewBytes.length||
     stamp.generation_sha256!==sha(stamp.qa_sha256+':'+stamp.preview_sha256))return fail('COMMIT_HASH_MISMATCH');
  if(stamp.status!==qa.status||stamp.preview_blocked!==(qa.status==='REJECT')||
     stamp.total_items!==qa.items?.length)return fail('COMMIT_SEMANTICS_MISMATCH');
  if(qa.status==='REJECT'){
    if(!view||view.status!=='REJECT_NO_PLAYER_PREVIEW'||
       !Array.isArray(view.items)||view.items.length!==0)return fail('REJECT_PREVIEW_LEAK');
  }else if(!Array.isArray(view)||view.length!==(qa.items||[]).length||
           view.some(x=>x.internal_approval!==false||x.disclosure_status!=='NÃO PUBLICAR'))return fail('PREVIEW_NOT_SAFELY_BLOCKED');
  return {verified:true,status:qa.status,total:qa.items.length,generation_sha256:stamp.generation_sha256};
}
if(require.main===module){let r=check();console.log(JSON.stringify(r,null,2));if(!r.verified)process.exitCode=4;}
module.exports={check};
