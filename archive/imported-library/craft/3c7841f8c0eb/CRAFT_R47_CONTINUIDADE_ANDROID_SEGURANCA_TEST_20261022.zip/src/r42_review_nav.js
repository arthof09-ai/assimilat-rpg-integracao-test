// CRAFT R42: read-only navigation projection of the existing 50-note form.
// Never edits frozen metadata, author notes, or governance state.
'use strict';
function normalizeR42Text(v){return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');}
function projectR42Nav(cases,notes,filters={}){
 const denied=(reason)=>({schema:'CRAFT_R42_VIEW_TEST_V1',valid:false,reason,visible_keys:[],visible_cases:0,total_cases:0,visible_questions:0,notes_present:0,notes_missing:0,canonical_write:false,rc5_approved:false,party_release:false});
 if(!Array.isArray(cases)||cases.length!==22||!notes||typeof notes!=='object')return denied('CONTRACT');
 const cleanText=typeof filters.search==='string'?filters.search.slice(0,120):'';
 const search=normalizeR42Text(cleanText.trim());
 const priority=Object.prototype.hasOwnProperty.call(filters,'priority')?filters.priority:'ALL',status=Object.prototype.hasOwnProperty.call(filters,'status')?filters.status:'ALL';
 if(!['ALL','P0','P1','P2','P3','UPSTREAM'].includes(priority)||!['ALL','UNTOUCHED','PARTIAL','COMPLETE','INCOMPLETE'].includes(status))return denied('INVALID_FILTER');
 let allSlots=0,noteCount=0;const rows=[];const keys=new Set();
 for(const c of cases){
  if(!c||typeof c.key!=='string'||keys.has(c.key)||!Array.isArray(c.slots))return denied('CASE_LAYOUT');keys.add(c.key);
  let filled=0;
  for(const s of c.slots){
   if(!s||typeof s.slot_id!=='string')return denied('SLOT_LAYOUT');
   const v=notes[c.key+':'+s.slot_id];
   if(v!==undefined&&typeof v!=='string')return denied('NOTE_TYPE');
   if(typeof v==='string'&&v.trim())filled++;
  }
  const total=c.slots.length;allSlots+=total;noteCount+=filled;
  const pr=String(c.priority||'');
  const type=pr==='UPSTREAM_SHARED'?'UPSTREAM':pr.split('_')[0];
  const state=filled===0?'UNTOUCHED':filled===total?'COMPLETE':'PARTIAL';
  const knownTitles={'UPSTREAM_OIL':'Óleo de Vedação','MAT-03':'Matriz de Cultivo'};
  const searchText=normalizeR42Text([c.key,knownTitles[c.key]||'',c.priority,c.source_url,...c.slots.flatMap(s=>[s.slot_id,s.question,s.bom_literal,s.process_literal])].join(' '));
  const visible=(!search||searchText.includes(search))&&(priority==='ALL'||type===priority)&&(
   status==='ALL'||status===state||(status==='INCOMPLETE'&&filled<total));
  rows.push({key:c.key,priority:type,status:state,visible,notes_present:filled,notes_missing:total-filled,questions:total});
 }
 if(allSlots!==50)return denied('QUESTION_COUNT');
 const visible=rows.filter(c=>c.visible);
 return {schema:'CRAFT_R42_VIEW_TEST_V1',valid:true,total_cases:22,total_questions:50,
  visible_cases:visible.length,visible_questions:visible.reduce((s,c)=>s+c.questions,0),
  notes_present:noteCount,notes_missing:50-noteCount,visible_keys:visible.map(c=>c.key),cases:rows,
  canonical_write:false,rc5_approved:false,party_release:false,notes_authenticated:false,
  reminder:'Filtro visual local: observação não autentica decisão nem libera RC5.'};
}
if(typeof module!=='undefined'&&module.exports)module.exports={normalizeR42Text,projectR42Nav};
