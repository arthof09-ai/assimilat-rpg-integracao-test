// CRAFT R29 -- triagem de relatos R46. TEST, não prova física nem writer.
'use strict';
function reviewR46Report(incoming,baseline){
 const rejected=(code,detail)=>({schema:'CRAFT_R29_R46_REVIEW_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
   verdict:'REJECT_UNTRUSTED_REPORT',reason:code,detail,usable_for_physical_pass:false,
   magic_transfer_demonstrated:false,recipe_rc5_approved:false,production_or_party_release_allowed:false,
   canonical_write_permitted:false,report_details_preserved:false});
 const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
 if(!object(incoming)||!object(baseline)||incoming.schema!=='CRAFT_R14_EVIDENCE_REQUEST_TEST_V1')return rejected('WRONG_SCHEMA','Somente pedido R46 gerado por esta sessão.');
 if(JSON.stringify(incoming).length>262144)return rejected('SIZE_LIMIT','Arquivo excede 256 KiB.');
 if(!Array.isArray(incoming.projects)||!Array.isArray(baseline.projects)||incoming.projects.length!==baseline.projects.length)return rejected('PROJECT_SET_MISMATCH','Conjunto de propostas mudou.');
 let masked;
 try{masked=JSON.parse(JSON.stringify(incoming));}catch{return rejected('MALFORMED_JSON','Estrutura não serializável.');}
 const results=[];
 const okValue=(v,max=4096)=>v===null||(typeof v==='string'&&v.trim().length>0&&v.length<=max&& !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v))||(typeof v==='number'&&Number.isFinite(v));
 for(let i=0;i<incoming.projects.length;i++){
  const p=incoming.projects[i],base=baseline.projects[i],mp=masked.projects[i];
  if(!object(p)||!object(base)||!object(mp)||!Array.isArray(p.targeted_material_requests)||!Array.isArray(base.targeted_material_requests)||p.targeted_material_requests.length!==base.targeted_material_requests.length)
   return rejected('IDENTITY_DRIFT','Projetos ou nós materiais alterados.');
  for(let j=0;j<p.targeted_material_requests.length;j++){
   const req=p.targeted_material_requests[j],mr=mp.targeted_material_requests[j],baseReq=base.targeted_material_requests[j];
   if(!object(req)||!object(mr)||!object(baseReq)||!object(req.r46_record)||!object(mr.r46_record)||!Array.isArray(req.evidence_requirements)||req.evidence_requirements.length!==baseReq.evidence_requirements.length)
    return rejected('REQUIREMENTS_TAMPERED','Nó ou requisitos diferentes do pedido original.');
   let provided=0,total=0;const missing=[];
   for(let k=0;k<req.evidence_requirements.length;k++){
    const field=req.evidence_requirements[k], mf=mr.evidence_requirements[k];
    if(!object(field)||!object(mf)||!okValue(field.observed_data))return rejected('FIELD_TYPE_INVALID','Observação deve ser texto/número limitado ou null.');
    if(field.proof_url!==null&&(typeof field.proof_url!=='string'||!/^https:\/\/[^\s]+$/i.test(field.proof_url)||field.proof_url.length>2048))return rejected('PROOF_LINK_INVALID','Referência deve ser URL HTTPS ou null.');
    if(field.observed_data!==null)provided++;else missing.push(field.key);total++;
    if(field.proof_url===null)missing.push(field.key+':proof_url');
    else provided++;total++;
    mf.observed_data=null;mf.proof_url=null;
   }
   for(const key of Object.keys(baseReq.r46_record)){
    if(!Object.prototype.hasOwnProperty.call(req.r46_record,key)||!okValue(req.r46_record[key]))return rejected('R46_FIELD_INVALID','Registro R46 fora do formato permitido.');
    if(req.r46_record[key]===null)missing.push('r46:'+key);else provided++;
    total++;mr.r46_record[key]=null;
   }
   results.push({proposal_id:req.proposal_id,node_id:req.node_id,fields_reported:provided,fields_required:total,
    missing,review_state:'RELATO_NAO_VERIFICADO',physical_verification:false,source_authenticity_confirmed:false,
    operational_release:false});
  }
 }
 if(JSON.stringify(masked)!==JSON.stringify(baseline))return rejected('IMMUTABLE_FIELDS_CHANGED','Identidade, parâmetros, fontes ou gates foram alterados.');
 if(results.length===0)return rejected('NO_FROZEN_R25_NODES','Nenhum nó elegível no snapshot desta sessão.');
 return {schema:'CRAFT_R29_R46_REVIEW_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
   verdict:'REPORTED_DATA_TRIAGED_NOT_VERIFIED',node_count:results.length,nodes:results,
   fields_reported:results.reduce((a,x)=>a+x.fields_reported,0),fields_required:results.reduce((a,x)=>a+x.fields_required,0),
   requires_independent_operator_and_source_review:true,source_status:'UNVERIFIED_SELF_REPORT',
   physical_test_executed:false,magic_transfer_demonstrated:false,recipe_rc5_approved:false,
   production_or_party_release_allowed:false,canonical_write_permitted:false,report_details_preserved:false,
   warning:'Contagem documental, NÃO confirmação de laudo, amostra, metrologia, autenticidade, autoria ou efeito.'};
}
if(typeof module!=='undefined'&&module.exports)module.exports={reviewR46Report};
