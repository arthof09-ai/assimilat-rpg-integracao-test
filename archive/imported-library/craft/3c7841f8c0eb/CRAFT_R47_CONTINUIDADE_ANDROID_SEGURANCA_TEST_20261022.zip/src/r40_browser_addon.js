// R40 extends existing R53 form with all existing issues, no new recipe engine.
const r40Root=document.getElementById('r40-decision-fields');
if(r40Root&&typeof r40Root.appendChild==='function'){
 const control=new Map();let lastReview=null;
 for(const c of R40_AUTHOR_BASELINE.cases){
  const details=document.createElement('details');details.className='r40-case';
  const title=document.createElement('summary');title.textContent=c.key+' · '+c.slots.length+' perguntas · '+c.priority;details.appendChild(title);
  const ref=document.createElement('p');ref.className='small';ref.textContent='Fonte oficial Mestre: '+c.source_url+' · '+c.original_source+' (cópia congelada)';details.appendChild(ref);
  for(const slot of c.slots){
   const label=document.createElement('label'),input=document.createElement('textarea');input.rows=2;input.maxLength=1500;
   const k=c.key+':'+slot.slot_id;input.id='r40-'+c.key+'-'+slot.slot_id;label.htmlFor=input.id;
   label.textContent=slot.slot_id+' — '+slot.question;input.placeholder='Observação textual privada, NÃO AUTENTICADA';
   const provenance=document.createElement('div');provenance.className='small';
   provenance.textContent='BOM: '+slot.bom_literal+' | processo/fonte: '+slot.process_literal;
   details.append(label,provenance,input);control.set(k,input);
  }
  r40Root.appendChild(details);
 }
 function makeR40Draft(){
  const draft=JSON.parse(JSON.stringify(R40_AUTHOR_BASELINE));
  for(const c of draft.cases)for(const s of c.slots){const value=control.get(c.key+':'+s.slot_id).value.trim();s.author_note=value||null;}
  draft.all_notes_blank=draft.cases.every(c=>c.slots.every(s=>s.author_note===null));return draft;
 }
 function refreshR40(){
  lastReview=reviewR40Draft(makeR40Draft(),R40_AUTHOR_BASELINE);
  const e=document.getElementById('r40-status');e.textContent=lastReview.verdict!=='NOTES_TRIAGED_NOT_AUTHENTICATED'?'REJEITADO: '+lastReview.reason:
   lastReview.notes_reported+'/50 anotações não autenticadas; 0 decisões canônicas, 0 fichas alteradas.';
  document.getElementById('r40-triage').disabled=lastReview.verdict!=='NOTES_TRIAGED_NOT_AUTHENTICATED';
 }
 function downloadR40(data,name){
  const blob=new Blob([JSON.stringify(data,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
 }
 r40Root.addEventListener('input',refreshR40);refreshR40();
 document.getElementById('r40-save').addEventListener('click',()=>{
  const draft=makeR40Draft(),review=reviewR40Draft(draft,R40_AUTHOR_BASELINE);
  if(review.verdict!=='NOTES_TRIAGED_NOT_AUTHENTICATED'){refreshR40();return;}
  downloadR40(draft,'CRAFT_R40_50_RESPOSTAS_NAO_AUTENTICADAS_MESTRE_TEST.json');refreshR40();document.dispatchEvent(new Event('craft-r40-export-requested'));
 });
 document.getElementById('r40-upload').addEventListener('change',async(e)=>{
  const f=e.target.files?.[0];if(!f)return;const st=document.getElementById('r40-status');
  try{
   if(f.size>262144)throw Error('Arquivo maior que 256 KiB');const draft=JSON.parse(await f.text());
   const rv=reviewR40Draft(draft,R40_AUTHOR_BASELINE);
   if(rv.verdict!=='NOTES_TRIAGED_NOT_AUTHENTICATED')throw Error(rv.reason);
   const conflicts=draft.cases.flatMap(c=>c.slots.map(s=>({key:c.key+':'+s.slot_id,incoming:s.author_note??''})))
      .filter(s=>control.get(s.key).value.trim()&&control.get(s.key).value.trim()!==s.incoming.trim());
   if(conflicts.length&&(typeof window==='undefined'||typeof window.confirm!=='function'||
      !window.confirm('IMPORTAÇÃO R40 substitui '+conflicts.length+' anotações locais já preenchidas. Exportou uma cópia? Continuar?'))){
      st.textContent='IMPORTAÇÃO CANCELADA: '+conflicts.length+' conflitos locais; notas originais preservadas.';
      e.target.value='';return;
   }
   for(const c of draft.cases)for(const s of c.slots){control.get(c.key+':'+s.slot_id).value=s.author_note??'';}
   refreshR40();document.dispatchEvent(new Event('craft-r40-notes-imported'));
  }catch(ex){st.textContent='REJEITADO: '+String(ex.message||ex).slice(0,160)+'; notas anteriores preservadas';}
 });
 document.getElementById('r40-triage').addEventListener('click',()=>{
  refreshR40();if(lastReview.verdict==='NOTES_TRIAGED_NOT_AUTHENTICATED')downloadR40(lastReview,'CRAFT_R40_TRIAGEM_50_NOTAS_SEM_TEXTO_MESTRE_TEST.json');
 });
}
