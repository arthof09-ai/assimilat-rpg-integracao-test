// CRAFT R32: compile the follow-up tasks of the existing 11 author-decision slots.
// Only documents dependencies; NEVER applies a rule, decision, physical recipe edit or production.
'use strict';
const R32_EFFECTS=Object.freeze({
 'ENC-08:SALT_IDENTITY':['identidade e unidade do sal na BOM','substituição ou correção da etapa de processo','fonte e proveniência do sal'],
 'ENC-08:ENERGY_ALTERNATIVE':['rota Pedra da Luz OU Pote de Essência Mágica','consumo por rota e instalação/ativação','economia sem somar alternativas'],
 'MAT-03:BROKEN_1X_REFERENCE':['identidade do ingrediente quebrado 1x','parent Mestre único do Óleo de Vedação, se confirmado','inclusão ou descarte da etapa de consumo de 1x'],
 'MAT-03:EARTH_ALIAS':['identidade Terra Encantada versus Terra de Gigante','compatibilidade e unidades da BOM','correção correspondente do procedimento'],
 'MAT-03:WATER_ALIAS':['identidade Essência de Água da Nascente versus Água de Nascente Élfica','volume/unidade e fonte da água','etapa de irrigação e perdas'],
 'MAT-06:EX_QUANTITY':['quantidade e unidade de Pó de Quartzo Fantasma, sem inferir Ex','rendimento e dimensionamento da matriz','consumo efetivo na BOM e etapa'],
 'MAT-06:WIND_ALIAS':['identidade Sopro Mundial versus Sopro Ancestral','procedimento de ativação sem substituição lexical automática','compatibilidade com ambiente e duração'],
 'MAT-06:ENERGY_OIL_STEPS':['etapa de 1x Óleo de Vedação','rota Pedra da Luz OU Pote Essência Mágica','consumo inicial versus recorrente e manutenção'],
 'UPSTREAM_OIL:OIL_POWDER':['ficha Mestre com 3x Pó de Ferro Celestial','BOM original não substituível pelo espelho Party','processo e eventual variante com origem própria'],
 'UPSTREAM_OIL:OIL_DEW':['Gota do Orvalho do Amanhecer versus Orvalho de Dragão','identidade/reagente e momento da mistura','controle de equivalência sem assumir sinonímia'],
 'UPSTREAM_OIL:OIL_ESSENCE':['Essência da Lua Minguante versus Essência de Vórtice','origem/fonte e processamento','efeito final e limites demonstráveis']
});
function buildR32ImpactMap(source,draft=null){
 const deny=(code)=>({schema:'CRAFT_R32_RECIPE_IMPACT_TEST_V1',verdict:'REJECT_SOURCE_DRIFT',reason:code,no_canonical_write:true});
 if(!source||source.schema!=='CRAFT_R30_AUTHOR_DECISIONS_TEST_V1'||!Array.isArray(source.cases))return deny('R30_REQUIRED');
 if(draft!==null){
  if(typeof reviewAuthorDraft!=='function')return deny('R31_REVIEW_REQUIRED');
  const check=reviewAuthorDraft(draft,source);
  if(check.verdict!=='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED')return deny('R31_DRAFT_REJECTED');
 }
 let actions=[];
 for(const c of source.cases){
  if(!c||!Array.isArray(c.decision_slots))return deny('INVALID_CASE');
  for(const s of c.decision_slots){
   const key=c.key+':'+s.id;if(!Object.prototype.hasOwnProperty.call(R32_EFFECTS,key))return deny('UNKNOWN_DECISION_SLOT');
   const n=draft?.cases.find(x=>x.key===c.key)?.decision_slots.find(x=>x.id===s.id)?.decision??null;
   actions.push({case_key:c.key,decision_slot:s.id,physical_recipe_id:c.physical_recipe_id,
    source_url:c.source_url,priority:c.priority,
    author_note_received_not_authenticated:n!==null,
    authority_state:'PENDING_MESTRE_CONFIRMATION',
    required_follow_up:R32_EFFECTS[key],
    gates:['NAC-CONT-03 / writer fencing','NAC-NORM-01 / precedence','PR-ITEM-02 / REC-EXEC BOM-process','PR-SC-01 / RC-state','PR-ECO Anexo C / units and costs','NAC-PASS appropriate'],
    source_readback_required:true,operator_or_instrument_proof_required_where_material:true,
    proposal_only:true,physical_recipe_updated:false,production_allowed:false});
  }
 }
 const keys=new Set(actions.map(a=>a.case_key+':'+a.decision_slot));
 if(actions.length!==11||keys.size!==11||Object.keys(R32_EFFECTS).length!==11)return deny('ELEVEN_SLOT_CONTRACT_BROKEN');
 const oilSource='https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd';
 const links=[
  {source_case:'UPSTREAM_OIL',destination_case:'ENC-08',kind:'VERIFIED_BOM_MENTION_OIL',conditional:false},
  {source_case:'UPSTREAM_OIL',destination_case:'MAT-03',kind:'SOURCE_SECTION_OIL_BUT_BROKEN_1X_LINK',conditional:true},
  {source_case:'UPSTREAM_OIL',destination_case:'MAT-06',kind:'VERIFIED_BOM_MENTION_OIL',conditional:false}
 ];
 return {schema:'CRAFT_R32_RECIPE_IMPACT_TEST_V1',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
  verdict:'IMPACT_PLANNED_NOT_AUTHORIZED',source_readback_as_of:source.readback_as_of,
  source_docket_sha256:source.source_docket_sha256,source_freshness:'R30_FROZEN_NOT_LIVE',
  counts:{child_recipe_total:29,lexical_issue_cases:21,prioritized_recipe_cases:3,upstream_shared_sources:1,decision_slots:11},
  actions,shared_dependencies:{oil_source_url:oilSource,links,
    note:'O vínculo da MAT-03 depende de decisão autoral; menção e link quebrado não são identidade validada.'},
  all_author_decisions_authenticated:false,canonical_writer_or_fencing_verified:false,
  physical_lots_verified:false,magic_transfer_proved:false,recipe_rc5_approved:false,
  canonical_item_or_recipe_created:false,party_or_o_primeiro_release_allowed:false,
  requires_next:'Autoria Mestre e frescor de cada fonte; reconciliar cada BOM/etapa, custos, estados e gate NAC antes de qualquer escrita física.'};
}
if(typeof module!=='undefined'&&module.exports)module.exports={R32_EFFECTS,buildR32ImpactMap};
