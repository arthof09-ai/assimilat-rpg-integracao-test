'use strict';
/* CRAFT-R10: mantém o motor de leitura R53/R8/R9; normaliza REJECT sem prévia Player aparente. */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {valid,playerSafe}=require('./validate');
const root=path.join(__dirname,'..');
const outputs=path.join(root,'outputs');
fs.mkdirSync(outputs,{recursive:true});
let d,resources,res;
try {
  d=JSON.parse(fs.readFileSync(path.join(root,'data','proposals.json'),'utf8'));
  resources=JSON.parse(fs.readFileSync(path.join(root,'data','resources.json'),'utf8'));
  res=valid(d,resources);
  if(!res||typeof res!=='object'||typeof res.status!=='string')throw Error('Invalid validator response');
} catch(err) {
  // Não expõe dados sensíveis do arquivo de entrada no recibo.
  res={status:'REJECT',items:[{id:null,verdict:'REJECT',issues:[{code:'INPUT_OR_VALIDATOR_INVALID',msg:'Formato inválido; revisão manual exigida'}],holds:[],evidence:[]}],total:0,distinct_sources:0,
    disclaimer:'Entrada inválida ou exceção de validação, nenhuma autorização de fabricação/publicação.'};
}
const blocked=res.status==='REJECT';
const preview=blocked
  ? {status:'REJECT_NO_PLAYER_PREVIEW',disclosure_status:'NÃO PUBLICAR',items:[]}
  : (Array.isArray(d?.products)?d.products.map(playerSafe):[]);
// R13: um par de saída só pode ser usado se o COMMIT final validar os DOIS hashes.
// Apaga recibo ANTES de tocar arquivos: crash entre renames jamais deixa recibo antigo válido.
const qaData=JSON.stringify(res,null,2)+'\n';
const previewData=JSON.stringify(preview,null,2)+'\n';
const sha=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
const stamp=path.join(outputs,'OUTPUT_COMMIT.json');
const qTmp=path.join(outputs,`.QA_RESULT.${process.pid}.tmp`);
const pTmp=path.join(outputs,`.PLAYER_PREVIEW.${process.pid}.tmp`);
const cTmp=path.join(outputs,`.OUTPUT_COMMIT.${process.pid}.tmp`);
try{
  fs.rmSync(stamp,{force:true});
  fs.writeFileSync(qTmp,qaData,{flag:'wx'});
  fs.writeFileSync(pTmp,previewData,{flag:'wx'});
  if(process.env.CRAFT_TEST_FAULT==='after_stage')throw Error('Injected R13 TEST fault');
  fs.renameSync(qTmp,path.join(outputs,'QA_RESULT.json'));
  if(process.env.CRAFT_TEST_FAULT==='after_qa')throw Error('Injected R13 TEST fault');
  fs.renameSync(pTmp,path.join(outputs,'PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'));
  if(process.env.CRAFT_TEST_FAULT==='after_preview')throw Error('Injected R13 TEST fault');
  const receipt={schema:'CRAFT_TEST_OUTPUT_COMMIT_V1',status:res.status,preview_blocked:blocked,
    qa_sha256:sha(qaData),preview_sha256:sha(previewData),
    qa_bytes:Buffer.byteLength(qaData),preview_bytes:Buffer.byteLength(previewData),
    total_items:Array.isArray(res.items)?res.items.length:0,
    generation_sha256:sha(sha(qaData)+':'+sha(previewData))};
  fs.writeFileSync(cTmp,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
  fs.renameSync(cTmp,stamp);
}catch(err){
  console.error('OUTPUT_NOT_COMMITTED: acesso à dupla QA/prévia bloqueado; conferir OUTPUT_COMMIT.json');
  process.exitCode=3;
}finally{
  for(const f of [qTmp,pTmp,cTmp])try{fs.rmSync(f,{force:true})}catch(_){}
}
const items=Array.isArray(res.items)?res.items:[];
console.log(JSON.stringify({status:res.status,total:res.total||0,resources:res.distinct_sources||0,
  preview_blocked:blocked,projects:items.map(x=>({name:x.name||null,verdict:x.verdict||'REJECT',holds:(x.holds||[]).length,issues:(x.issues||[]).length}))},null,2));
if(blocked && !process.exitCode)process.exitCode=2;
