// CRAFT R40: same R53 private review surface, combining existing 50 questions.
// The only mutable content of an incoming draft is slots[].author_note and all_notes_blank.
// NEVER authenticates authorship or authorizes material/canonical writes.
'use strict';
function reviewR40Draft(incoming,baseline){
 const deny=reason=>({schema:'CRAFT_R40_50_NOTE_TRIAGE_TEST_V1',verdict:'REJECT_UNTRUSTED_NOTES',reason,
   note_count:0,notes_authenticated:false,notion_write_allowed:false,rc5_allowed:false,party_release_allowed:false});
 const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
 if(!plain(incoming)||!plain(baseline)||incoming.schema!=='CRAFT_R40_COMBINED_50_DECISIONS_MESTRE_TEST_V1'||baseline.schema!==incoming.schema)return deny('SOURCE_SCHEMA');
 let raw;try{raw=JSON.stringify(incoming)}catch{return deny('NON_SERIALIZABLE')}
 if(typeof raw!=='string'||raw.length>262144)return deny('MAX_SIZE_256K');
 if(!Array.isArray(incoming.cases)||incoming.cases.length!==22||!Array.isArray(baseline.cases)||baseline.cases.length!==22)return deny('CASE_COUNT');
 let mask;try{mask=JSON.parse(raw)}catch{return deny('INVALID_JSON')}
 let n=0,notes=0;const found=new Set(),summaries=[];
 for(let i=0;i<22;i++){
  const c=incoming.cases[i],b=baseline.cases[i],m=mask.cases[i];
  if(!plain(c)||!plain(b)||!Array.isArray(c.slots)||!Array.isArray(b.slots)||c.slots.length!==b.slots.length)return deny('SLOT_LAYOUT');
  if(c.key!==b.key||c.physical_recipe_id!==b.physical_recipe_id||c.source_url!==b.source_url)return deny('SOURCE_IDENTITY');
  let local=0;
  for(let j=0;j<c.slots.length;j++){
   const s=c.slots[j];if(!plain(s)||!Object.prototype.hasOwnProperty.call(s,'author_note'))return deny('NOTE_FIELD_MISSING');
   const id=c.key+':'+s.slot_id;if(found.has(id))return deny('DUPLICATE_SLOT');found.add(id);
   const value=s.author_note;
   if(value!==null&&(typeof value!=='string'||!value.trim()||value.length>1500||/[\u0000-\u0008\u000b\u000c\u000d\u000e-\u001f\u007f]/.test(value)))return deny('UNSAFE_NOTE');
   if(value!==null){notes++;local++;}
   m.slots[j].author_note=null;n++;
  }
  summaries.push({key:c.key,physical_recipe_id:c.physical_recipe_id,notes_reported:local,slots_total:c.slots.length,
   pending_slots:c.slots.length-local,official_write:false});
 }
 if(n!==50||found.size!==50)return deny('FIFTY_SLOT_CONTRACT');
 if(incoming.all_notes_blank!==(notes===0))return deny('NOTES_FLAG_DRIFT');
 mask.all_notes_blank=baseline.all_notes_blank;
 if(JSON.stringify(mask)!==JSON.stringify(baseline))return deny('IMMUTABLE_METADATA_CHANGED');
 return {schema:'CRAFT_R40_50_NOTE_TRIAGE_TEST_V1',verdict:'NOTES_TRIAGED_NOT_AUTHENTICATED',
  classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',slots_total:50,cases_total:22,
  notes_reported:notes,notes_pending:50-notes,cases:summaries,notes_authenticated:false,
  author_mestre_identity_verified:false,notion_write_allowed:false,recipe_modified:false,
  rc5_allowed:false,party_release_allowed:false,physical_material_verified:false,
  warning:'Observações locais; não substituem decisão autenticada do Mestre, laudo R46, fencing, nem produção.'};
}
if(typeof module!=='undefined'&&module.exports)module.exports={reviewR40Draft};
