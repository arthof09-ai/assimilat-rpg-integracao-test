// R31 private Android input. Does not request network or write canonical records.
let r31Review=null;
const r31Root=document.getElementById('r31-decision-fields');
// Original R9/R20 regression harness uses a deliberately minimal DOM stub.
if(r31Root&&typeof r31Root.appendChild==='function'){
for(const c of R30_AUTHOR_BASELINE.cases){
 const details=document.createElement('details');details.open=c.key==='ENC-08';
 const summary=document.createElement('summary');summary.textContent=c.key+' — '+c.decision_slots.length+' decisões pendentes';details.appendChild(summary);
 const cite=document.createElement('p');cite.className='small';cite.textContent='Fonte Mestre: '+c.source_url+' · snapshot local R30';details.appendChild(cite);
 for(const slot of c.decision_slots){
  const label=document.createElement('label'),ta=document.createElement('textarea');
  const id='r31-'+c.key+'-'+slot.id;
  label.htmlFor=id;label.textContent=slot.id+': '+slot.question;
  ta.id=id;ta.rows=3;ta.maxLength=1500;ta.dataset.caseKey=c.key;ta.dataset.slotId=slot.id;
  ta.placeholder='Anotação do Mestre (rascunho, sem efeito canônico)';
  details.appendChild(label);details.appendChild(ta);
 }
 r31Root.appendChild(details);
}
function authorDraftFromInputs(){
 const draft=JSON.parse(JSON.stringify(R30_AUTHOR_BASELINE));
 for(const c of draft.cases)for(const s of c.decision_slots){
  const t=document.getElementById('r31-'+c.key+'-'+s.id).value;
  s.decision=t.trim()?t:null;
 }
 draft.all_choices_blank=draft.cases.every(c=>c.decision_slots.every(s=>s.decision===null));
 return draft;
}
function r31UpdateStatus(){
 r31Review=reviewAuthorDraft(authorDraftFromInputs(),R30_AUTHOR_BASELINE);
 const st=document.getElementById('r31-status'),btn=document.getElementById('r31-triage');
 btn.disabled=r31Review.verdict!=='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED';
 st.textContent=r31Review.verdict==='REJECT_UNTRUSTED_DRAFT'?'Minuta inválida: '+r31Review.reason:
  'Minuta local: '+r31Review.decisions_reported+'/11 respostas textuais; '+r31Review.pending_slots+' pendentes; 0 decisões autenticadas e 0 escritas canônicas.';
}
r31Root.addEventListener('input',r31UpdateStatus);r31UpdateStatus();
document.getElementById('r31-save').addEventListener('click',()=>{
 const draft=authorDraftFromInputs();const test=reviewAuthorDraft(draft,R30_AUTHOR_BASELINE);
 if(test.verdict!=='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED'){r31UpdateStatus();return;}
 const blob=new Blob([JSON.stringify(draft,null,2)+'\n'],{type:'application/json'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;
 a.download='CRAFT_R31_MINUTA_RESPOSTAS_MESTRE_TEST_NAO_CANONICA.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
 r31UpdateStatus();document.dispatchEvent(new Event('craft-r31-export-requested'));
});
document.getElementById('r31-upload').addEventListener('change',async e=>{
 const f=e.target.files?.[0];if(!f)return;
 const status=document.getElementById('r31-status');
 try{
  if(f.size>131072)throw Error('Excede 128 KiB');
  const incoming=JSON.parse(await f.text());const rv=reviewAuthorDraft(incoming,R30_AUTHOR_BASELINE);
  if(rv.verdict!=='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED')throw Error(rv.reason);
  const conflicts=incoming.cases.flatMap(c=>c.decision_slots.map(s=>({key:'r31-'+c.key+'-'+s.id,newText:s.decision??''})))
     .filter(s=>document.getElementById(s.key).value.trim()&&document.getElementById(s.key).value.trim()!==s.newText.trim());
  if(conflicts.length&&(typeof window==='undefined'||typeof window.confirm!=='function'||
      !window.confirm('IMPORTAÇÃO R31 substitui '+conflicts.length+' anotações já preenchidas. Exportou uma cópia privada? Continuar?'))){
      status.textContent='IMPORTAÇÃO CANCELADA: '+conflicts.length+' conflitos, notas preservadas.';
      e.target.value='';return;
  }
  for(const c of incoming.cases)for(const sl of c.decision_slots){
   document.getElementById('r31-'+c.key+'-'+sl.id).value=sl.decision??'';
  }
  r31UpdateStatus();document.dispatchEvent(new Event('craft-r31-notes-imported'));
 }catch(ex){status.textContent='REJEITADO — '+String(ex.message||ex).slice(0,170)+'; respostas locais anteriores preservadas, não aplicadas.';}
});
document.getElementById('r31-triage').addEventListener('click',()=>{
 r31UpdateStatus();if(!r31Review||r31Review.verdict!=='AUTHOR_NOTE_DRAFT_TRIAGED_NOT_APPLIED')return;
 const blob=new Blob([JSON.stringify(r31Review,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download='CRAFT_R31_TRIAGEM_NOTAS_SEM_TEXTO_MESTRE_TEST.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
});

// R32 planning only: maps original R30 issue IDs to downstream review, never writes.
document.getElementById('r32-impact').addEventListener('click',()=>{
 const plan=buildR32ImpactMap(R30_AUTHOR_BASELINE,authorDraftFromInputs());
 if(plan.verdict!=='IMPACT_PLANNED_NOT_AUTHORIZED')return;
 const blob=new Blob([JSON.stringify(plan,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download='CRAFT_R32_PLANO_IMPACTO_11_DECISOES_MESTRE_TEST.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
});

} // browser DOM availability guard; legacy CLI harness still runs all original handlers
// R33: frozen-source work order derived from existing CRAFT docket and R46 requests.
document.getElementById('r33-continuity').addEventListener('click',()=>{
 const plan=buildR33ContinuityView(R27_RECIPE_DOCKET,R30_AUTHOR_BASELINE,evidencePlan((current||valid(PROJECT,INDEX)).items));
 if(plan.verdict!=='DOCUMENTAL_NEXT_STEPS_ONLY'){document.getElementById('docket-summary').textContent='Plano R33 bloqueado: fontes ou propostas diferem do snapshot. Revalidar manualmente.';return;}
 const blob=new Blob([JSON.stringify(plan,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download='CRAFT_R33_PLANO_UNICO_CONTINUIDADE_MESTRE_TEST.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
});
