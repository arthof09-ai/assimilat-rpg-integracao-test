// CRAFT R33 -- read-only unified continuation view. Sources remain R27/R30/R46.
// Not a task tracker, a separate engine, or a Notion/Party writer.
'use strict';
function buildR33ContinuityView(docket,author,evidence){
 const reject=reason=>({schema:'CRAFT_R33_CONTINUITY_SNAPSHOT_TEST_V1',verdict:'REJECT_SOURCE_DRIFT',reason});
 if(!docket||!author||!evidence||!Array.isArray(docket.issues)||!Array.isArray(author.cases)||!Array.isArray(evidence.projects))return reject('MISSING_SOURCE');
 const den=docket.denominator;
 if(!den||den.child_recipe_pages!==29||den.recipes_with_lexical_issues!==21||den.lexical_only_not_physical_pass!==8||docket.issues.length!==21)return reject('DOCKET_DENOMINATOR');
 const cases=new Map();for(const c of docket.issues){if(!c||!c.physical_recipe_id||cases.has(c.physical_recipe_id))return reject('DUPLICATED_PHYSICAL_CASE');cases.set(c.physical_recipe_id,c);}
 const focused=author.cases.filter(x=>x.physical_recipe_id),upstream=author.cases.filter(x=>!x.physical_recipe_id);
 if(focused.length!==3||upstream.length!==1||author.cases.reduce((n,x)=>n+x.decision_slots.length,0)!==11)return reject('AUTHOR_SCOPE_DRIFT');
 for(const c of focused)if(!cases.has(c.physical_recipe_id)||cases.get(c.physical_recipe_id).pattern_key!==c.key)return reject('AUTHOR_CASE_NOT_FROM_DOCKET');
 const focusedIds=new Set(focused.map(c=>c.physical_recipe_id));if(focusedIds.size!==3)return reject('DUPLICATED_PRIORITY_CASE');
 const allNodes=evidence.projects.flatMap(p=>(p.targeted_material_requests||[]).map(n=>({project_id:p.proposal_id,node_id:n.node_id,materials:n.material_role,source_precedent_url:n.source_precedent_url,
  source_status:'PENDENTE_NAO_OBSERVADO',physical_proof_received:false,requires_r46_independent_review:true})));
 if(allNodes.length!==3||new Set(allNodes.map(n=>n.project_id+':'+n.node_id)).size!==3)return reject('R46_THREE_NODES_DRIFT');
 const remaining=docket.issues.filter(c=>!focusedIds.has(c.physical_recipe_id));if(remaining.length!==18)return reject('REMAINING_CASE_DRIFT');
 return {schema:'CRAFT_R33_CONTINUITY_SNAPSHOT_TEST_V1',verdict:'DOCUMENTAL_NEXT_STEPS_ONLY',classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
  sources:{docket_schema:docket.schema,author_schema:author.schema,evidence_schema:evidence.schema,
   dossier_source:'FROZEN_R27_21_ISSUES',notion_source:'R30_READBACK_NOT_CONTINUOUS'},
  denominators:{physical_recipes_in_corpus:29,lexical_issue_cases:21,issues_with_detailed_author_questions:3,
   remaining_issues_only_in_docket:18,upstream_shared_oil_sources:1,decision_questions:11,
   pending_r46_material_nodes:3,recipes_without_reported_lexical_issues_NOT_APPROVED:8},
  next_chain:[
   {order:1,work:'FENCING_AND_R51_STATUS_READ_ONLY',scope:'IBX38 / IBX116 / R51',gate:'NO_WRITER_NO_PRODUCTION'},
   {order:2,work:'R30_AUTHOR_NOTES_FOR_FOCUSED_ISSUES',scope:'ENC-08 / MAT-03 / MAT-06 + upstream oil',gate:'MESTRE_CONFIRMATION_NOT_YET_PRESENT'},
   {order:3,work:'R46_MATERIAL_MEASUREMENT_AND_INDEPENDENT_REVIEW',scope:'SONDA B3 / TONICO B3,B4',gate:'NO_PHYSICAL_DATA_PROVIDED'},
   {order:4,work:'BOM_PROCESS_RECONCILIATION_AND_COSTS',scope:'3 focused recipe cases',gate:'NOT_TO_APPLY_WITHOUT_AUTHORITY'},
   {order:5,work:'REMAINING_18_RECIPE_ISSUES',scope:'Existing R27 dossier, no duplicate tickets',gate:'MESTRE_AUTHOR_AND_CURRENT_READBACK'},
   {order:6,work:'CANONICAL_WRITE_NAC_PASS_AFTER_GATES',scope:'only authorized original writer and locations',gate:'F5_RED_R51_HOLD'}],
  priority_recipe_sources:focused.map(c=>({key:c.key,physical_recipe_id:c.physical_recipe_id,
   source_url:c.source_url,author_decision_slots:c.decision_slots.map(x=>x.id),author_notes_verified:false,
   recipe_edit_performed:false})),
  other_recipe_cases:remaining.map(c=>({key:c.pattern_key,uuid:c.physical_recipe_id,priority:c.priority,source_url:c.source_url,requires_author_review:true})),
  pending_material_nodes:allNodes,
  gates:{c19_fencing_verified:false,r51_physical_parent_confirmed:false,r46_lots_proved:false,
   author_decisions_authenticated:false,rc5_material_verified:false,canonical_write_allowed:false,
   recipe_product_magic_verified:false,party_or_o_primeiro_write_allowed:false},
  total_canonical_changes:0,creates_new_ticket:false,creates_new_recipe:false,contains_player_secret_release:false};
}
if(typeof module!=='undefined'&&module.exports)module.exports={buildR33ContinuityView};
