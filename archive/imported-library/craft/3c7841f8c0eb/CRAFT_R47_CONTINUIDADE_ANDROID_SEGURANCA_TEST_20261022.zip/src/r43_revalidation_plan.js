// R43: output a review-only action queue from the existing R40 frozen questions.
// Never exports note text or interprets notes as decisions. RECIPE/PA/RC5 remain HOLD.
'use strict';
const R43_ACTIONS=Object.freeze({
 AUTHORITY_RECONCILIATION:'Reconciliar identidade, BOM, etapa e fonte; obter decisão competente e readback atual.',
 MATERIAL_IDENTITY:'Conferir identidade física das duas substâncias; equivalência só com evidência e decisão autoral.',
 UNCONSUMED_BOM:'Identificar etapa de consumo/instalação ou declarar item PENDENTE; não completar receita por inferência.',
 LEXICAL_CANDIDATE:'Comparar ficha e função dos nomes; pode ser variação editorial, mas não presumir equivalência.',
 PROCESS_SEQUENCE:'Normalizar sequência com validação autoral; manter eventos originais no histórico.',
 TRANSFORMATION_UNPROVED:'Demonstrar processamento da forma de entrada para forma usada e seu rendimento/perdas.',
 QUANTITY_VOLUME:'Determinar volume/unidade/lote e tolerância; não converter fração narrativa em quantidade física.'
});
function makeR43Plan(draft,baseline){
 const deny=(reason)=>({schema:'CRAFT_R43_REVALIDATION_PLAN_TEST_V1',verdict:'REJECT',reason,actions:[],canonical_write:false,rc5_allowed:false,party_release:false});
 if(typeof reviewR40Draft!=='function')return deny('R40_VALIDATOR_REQUIRED');
 const check=reviewR40Draft(draft,baseline);if(check.verdict!=='NOTES_TRIAGED_NOT_AUTHENTICATED')return deny('R40_'+check.reason);
 const actions=[];const recheckCases=[];
 for(const c of draft.cases){
  const slots=[];
  for(const s of c.slots){
   if(!Object.prototype.hasOwnProperty.call(R43_ACTIONS,s.issue_class))return deny('UNKNOWN_CLASS');
   slots.push({slot_id:s.slot_id,issue_class:s.issue_class,has_local_note:s.author_note!==null,
    next_action:R43_ACTIONS[s.issue_class],state:s.author_note===null?'AGUARDA_NOTA':'AGUARDA_AUTENTICACAO',
    physical_equivalence_verified:false,notion_write_allowed:false});
  }
  actions.push({case_key:c.key,physical_recipe_id:c.physical_recipe_id,source_url:c.source_url,
   priority:c.priority,slots,notes_present:slots.filter(s=>s.has_local_note).length,
   note_text_included:false,source_readback_required:true,author_authentication_required:true,
   can_apply_to_notions:false,rc5_allowed:false});
  if(slots.some(s=>s.has_local_note))recheckCases.push(c.key);
 }
 return {schema:'CRAFT_R43_REVALIDATION_PLAN_TEST_V1',verdict:'PLAN_NOT_AUTHENTICATED',
  classification:'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',source_schema:draft.schema,
  cases_total:22,questions_total:50,notes_present:check.notes_reported,notes_missing:check.notes_pending,
  actions,requires_author_review:recheckCases,
  upstream_oil_cascade:{source:'Óleo de Vedação Mestre',review_scope:'29 menções no corpus R15/R37',
   literal_bom_mentions:28,broken_reference_cases:['MAT-03'],
   trigger:'Somente se a identidade, BOM ou processo do óleo for decidido e validado',
   requires_individual_recipe_readback:true,affected_rc5_automatically_approved:0},
  external_gates:{ibx38_fencing:'NOT_DEMONSTRATED',r51_single_parent:'HOLD',r46_physical_evidence:'NOT_DEMONSTRATED',
   release_writer_lease_epoch:'NOT_DEMONSTRATED',NAC_PASS_material:'NOT_GRANTED'},
  note_text_included:false,notes_authenticated:false,canonical_write:false,physical_recipe_modified:false,
  rc5_allowed:false,party_release:false,
  usage:'Roteiro de conferência; não é patch, decisão autenticada, perícia mágica, nem autorização de publicação.'};
}
if(typeof module!=='undefined'&&module.exports)module.exports={makeR43Plan,R43_ACTIONS};
