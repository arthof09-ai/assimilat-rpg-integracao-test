'use strict';
/* Aplicação em TEST do Anexo C. Nenhuma taxa/estimativa inventada. */
function reviewCost(input){
 const failures=[],pending=[];
 for(const key of ['material_prices','bom_quantities','same_market_epoch','yield','success_probability','labor','equipment','knowledge','logistics','storage','opportunity_cost']){
   if(input[key]===null||input[key]===undefined)pending.push(key);
 }
 if(input.material_prices?.some(p=>p.unit_price_med===0&&p.owned===true))failures.push('OWN_STOCK_IS_NOT_FREE');
 if(input.market_product_med!==null&&input.market_product_med!==undefined)failures.push('PRICE_UNAUTHORIZED_WITHOUT_CTE');
 if(input.item_rank_from_price)failures.push('RANK_FROM_PRICE_FORBIDDEN');
 if(typeof input.yield==='number'&&(!Number.isFinite(input.yield)||input.yield<=0))failures.push('INVALID_YIELD');
 if(typeof input.success_probability==='number'&&(!Number.isFinite(input.success_probability)||input.success_probability<=0||input.success_probability>1))failures.push('INVALID_SUCCESS_PROBABILITY');
 if(Array.isArray(input.bom_quantities)&&input.bom_quantities.some(v=>!Number.isFinite(v)||v<=0))failures.push('INVALID_BOM_QUANTITY');
 if(input.same_market_epoch===false)failures.push('MARKET_MISMATCH');
 return {gate:failures.length?'REJECT':pending.length?'HOLD_DATA':'MODEL_READY_BUT_NOT_APPROVED',failures,pending, 
   kit_cost_med:null,cte_med:null,recipe_knowledge_value_med:null,product_market_price_med:null,
   note:'Quatro valores distintos; sem dados comparáveis não retornar números; RIn, preço e RI/RE não são equivalentes.'};
}
if(typeof module!=='undefined')module.exports={reviewCost};
