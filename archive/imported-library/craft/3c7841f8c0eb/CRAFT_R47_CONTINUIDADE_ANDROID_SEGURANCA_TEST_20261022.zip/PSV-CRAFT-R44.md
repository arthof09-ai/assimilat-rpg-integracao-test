# PSV — CRAFT R44 — gate proporcional / MESTRE-SIDE TEST

- `ANTES`: R41, 29 receitas, 50 perguntas, 22 casos, zero decisões autenticadas, zero RC5; dois produtos TEST HOLD. Notion apenas busca/fetch.
- `DEPOIS`: R42 navegador móvel visual; R43 roteiro de revalidação sem notas; R44 reconfirmação dos edit stamps/pais de 29 receitas e comparador de fontes.
- Regressões JavaScript: 1.734/1.734 (29 suites). Novos R42 56, R43 142, R44 89; herdados 1.447.
- Chromium móvel simulado: 725/725 (21 suites). Novos R42 34, R43 22; herdados 669.
- Fuzz: 2.000 sondagens determinísticas, não equivalentes a ensaio físico.
- QA: 2 casos `HOLD_TEST_DESIGN`, resultado e prévia idênticos aos hashes históricos; recibo válido.
- Meta R44: 29 consultas diretas Notion, sem mudanças de carimbo de edição/pai frente à base R15; **não há hashes dos corpos completos**.
- Restrições: sem prova de fencing, writer/lease/epoch, físico R46, 29 receitas RC5, aprovação de 50 decisões, pai REC-LIB ou publicação à Party. Notion não recebeu R14–R44 nesta conexão.
- Gate: **PASS apenas de software/documentação TEST**. NAC-PASS material, integração canônica e Android físico: **HOLD**.

## Gate de distribuição extraída (cold replay)

O ZIP novo foi extraído em `/mnt/data/craft_r44_cold`. Manifesto, QA/recibo, 1.734 JS e fuzz 2.000 foram verificados nessa cópia. A execução Chromium de `replay_r44.py --full` atingiu o limite temporal do ambiente após **16 suítes PASS**; as **cinco restantes** foram executadas separadamente e passaram (R35 23, R40 29, R42 34, R43 22, R9 15). Assim, a cobertura gráfica **21/21 suítes, 725/725 verificações** foi reproduzida na distribuição, porém em **dois blocos**, e não em uma chamada integral ininterrupta. O teste R35 legado recebeu espera assíncrona explícita, sem alterar a asserção nem o código de produção correspondente.
