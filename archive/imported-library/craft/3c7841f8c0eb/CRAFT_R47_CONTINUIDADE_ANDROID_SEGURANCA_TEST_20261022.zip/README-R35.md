# CRAFT — R31–R35: tomada de decisões, consequências e coleta Android TEST

**Natureza:** evolução do MESMO motor local R53/R20/R30. MESTRE-SIDE, offline, sem rede, nenhum escritor canônico, sem Party/O Primeiro. O HTML funciona em Chromium simulado em 390×844; **Android físico não certificado**. Nada é publicado no Notion nem no site oficial.

## Onde usar

Abra `REVISOR_LOCAL_ANDROID_R53_TEST.html` em um navegador compatível (se o sistema permitir arquivo local). As outras funções R30 permanecem preservadas.

1. **R31 — Decisões no celular.** Em `R31 — Decisões do Mestre`, abra a receita, digite nas 11 perguntas e clique em **Salvar minuta privada**. Um campo vazio é PENDENTE. O arquivo é uma cópia do parecer R30 com `decision` preenchido e `all_choices_blank` refletindo se existem notas. Importar a minuta valida os 11 slots, UUIDs, URLs, regras e gates; rejeita alteração fora do campo de notas. Mesmo preenchida, ela **NÃO atesta autoria** e exige confirmação real do Mestre.
2. **R32 — Plano de impacto.** Clique em `Baixar plano de impacto`. O plano enumera 11 verificações necessárias, inclusive as consequências a jusante do Óleo de Vedação. `MAT-03→Óleo` continua **condicional**, sem substituição do link quebrado. O plano não contém o texto autoral das notas e não modifica receita.
3. **R33 — Plano único de continuidade.** Na fila R27, baixe a visão de 21 casos: três detalhados, dezoito ainda no dossiê, um óleo a montante e três nós R46. Ela não cria nenhum ticket.
4. **R35 — Relato de coleta material pelo celular.** Abra `R35 — Preencher coleta R46` dentro da revisão R29. Existem **72 campos** distribuídos em três nós (`SONDA B3`, `TÔNICO B3` e `TÔNICO B4`). Preencha somente observações reais e URLs HTTPS válidas; ausências ficam vazias. Baixe o relato para arquivo privado. Em seguida, use a função R29 para triagem; todos continuam `RELATO_NAO_VERIFICADO`. Se mudar o conteúdo de uma proposta, **recrie a ficha**: ela não herda evidências por coincidência de ID.
5. **R34 — Fonte externa.** O arquivo `data/r34_notionsource_readback_test.json` documenta somente a leitura de metadados/sinais das quatro páginas prioritárias na data indicada; não é busca permanente, ensaio nem certificado de versão.

## Entradas e artefatos

- Formulário R30 original: `outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json`.
- Fila original: `data/r27_decision_register_readonly.json` (21 receitas, original SHA256 preservado).
- Plano R33: `outputs/CRAFT_R33_PLANO_UNICO_CONTINUIDADE_MESTRE_TEST.json`.
- Pedidos materiais originais: `outputs/CRAFT_R27_PEDIDOS_R46_3_NOS_MESTRE_TEST.json`.
- HTML: `REVISOR_LOCAL_ANDROID_R53_TEST.html`; regenerar por `python build_mobile.py`.
- Executar testes: `python replay_r35.py` (manifesto, 23 JS e CLI) ou `python replay_r35.py --full` (inclui 18 suítes Chromium, requer Playwright e Chromium).

## Proveniência e limitações

R30 → R31 acrescenta campos de NOTA somente; R32/R33 derivam visões documentais dos dossiês existentes; R34 revalida quatro metadados Notion; R35 reaproveita os pedidos e a triagem R46 já existentes. Um texto supostamente do Mestre no arquivo **não é prova de que o Mestre o autorizou**. Para efetuar alteração canônica: comprovar decisão/autoria, reler fontes, aplicar NAC-NORM, obter writer/fencing, checar BOM↔processo, RC e NAC-PASS. Não inventar medição, material, rank, PA, preço, feitiço, quantidade `Ex` ou compatibilidade.

**Gates reais:** IBX38/116 e R51 NOVA + ACK, C19-021 UNKNOWN, F5 RED, R51 parent físico não atestado, R46 sem prova material. Todos são HOLD. Até que mudem, `0` itens/receitas/estoque/PA alterados; `0` Party/O Primeiro write. O último registro CRAFT sincronizado no OP/LAB/Inbox continua R13; R14–R35 aqui são biblioteca de código TEST, não sincronização Notion.
