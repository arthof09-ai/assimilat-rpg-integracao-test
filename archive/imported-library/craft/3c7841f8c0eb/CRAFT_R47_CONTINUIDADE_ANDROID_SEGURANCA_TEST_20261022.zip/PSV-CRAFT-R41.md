# PSV CRAFT R41 — PASS proporcional somente em software/documentação TEST

**ANTES** R38: 21 receitas com divergências históricas, oito aprofundadas, 23 perguntas preparadas; código R35 validado em 1.314 JS / 640 Chromium. **DEPOIS** R39–R41: 13 adicionais lidas, 21/21 receitas com divergência documentadas, 50 perguntas totais (47 por receita, 3 Óleo Mestre); 8/8 sem divergência lexical revisadas separadamente; 29 UUIDs físicos únicos; nenhum efeito canônico.

**R39:** 27 novas perguntas (`MATERIAL_IDENTITY` 11, `UNCONSUMED_BOM` 6, `LEXICAL_CANDIDATE` 4, `PROCESS_SEQUENCE` 3, `TRANSFORMATION_UNPROVED` 2, `QUANTITY_VOLUME` 1), vinculadas a fontes e UUIDs já existentes.

**R40:** código já validado no mesmo R53. Novo validador rejeita alterações em schema/UUID/fonte/nome de slot/permissões/flags e protege importação atômica de rascunhos, com preservação das 11 perguntas antigas. Observações são texto Mestre-only sem assinatura; HTML trata markup como texto. `R40 50` sem efeito no Notion.

**R41:** as oito fichas sem problema lexical detectado no dossiê anterior contêm BOM e processo de 5–6 etapas, mas não fornecem homologação física de rendimento/lote, taxa de sucesso, transferência mágica ou RC5. Uma descrição aparentemente coerente não equivale a receita executável.

**Regressões:** JS 26 suítes / 1.447 verificações; Chromium emulado 19 suítes / 669 verificações; robustez determinística adicional 2.000 vetores; QA e prévia byte-idênticos ao R35 e recibo de saída verificado. CRC+manifesto SHA-256 conferidos na extração limpa. Não é ensaio em Android físico.

**NAC-PASS:** proporcional `PASS TEST SOFTWARE / PASS READBACK DOCUMENTAL COM RESSALVAS`; `HOLD` para autoria, governança material, R46, RC5, estado de fábrica, F5, C19-021, fencing, single-parent REC-LIB, PA, estoque e Party.

**Limite da evidência:** notas textuais não são autenticação de decisões do Mestre. Metadados de edição Notion iguais aos históricos não demonstram comparação byte a byte das versões. Nenhuma decisão/ingrediente/equivalência/processo foi alterado na página física. As oito fichas limpas eram limpas somente no critério lexical histórico.
