# PSV CRAFT R14 — solicitação de evidência por projeto

**ANTES:** CRAFT R13 440/440 JS, 51/51 Chromium, diagnóstico técnico correto mas sem roteiro operacional exportável para coletar provas externas, Mestre Android precisava traduzir cada hold manualmente.

**DEPOIS FUNCIONAL:** a mesma interface offline R53 exibe as ações priorizadas P0/P1/P2 e baixa um pedido JSON MESTRE-SIDE/TEST. Cada projeto conserva link das fontes citadas, responsável normativo, campos mínimos R46 e estado `PENDENTE_NAO_OBSERVADO`, com `null` nos dados físicos e `false` na aprovação, produção e divulgação à Party. Nenhum novo laudo ou sistema é criado.

**QA:** 40/40 verificações Chromium inline R14, 51/51 anteriores, total 91/91. JS 440/440 regressões; fuzz 2.000 informacionais. HTML e export sem chamadas HTTP; sem overflow viewport 390×844, download e importação inválida PASS. Inputs e saídas CLI/R13 mantidos byte-idênticos. Browser inline não é prova Android físico.

**GATE:** R14 é pedido de dados e não comprovação: sem operador real, instrumento calibrado, testemunha, observação de magia, disponibilidade de estoques, receita RC5 ou F5 autorizado. C19-021 UNKNOWN, IBX38 fencing externo, R51 parent HOLD. Party/O Primeiro NO-WRITE. **NEXT:** dossiê read-only com decisões pendentes nas 21 receitas divergentes e os conflitos P2/óleo/energia, sem duplicação.
