"""R35 strict archive replay. Quick: manifesto+JS+QA receipt. --full: all Chromium suites too."""
from pathlib import Path
import hashlib,json,subprocess,re,sys
r=Path(__file__).resolve().parent
manifest=json.loads((r/'MANIFEST-R35.json').read_text())
for path,digest in manifest['files'].items():
 p=r/path
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise SystemExit('MANIFEST FAIL '+path)
print('R35 MANIFEST',len(manifest['files']),'PASS')
files=sorted((r/'tests').glob('test_*.js'));n=0
for f in files:
 p=subprocess.run(['node',str(f)],cwd=r,check=True,capture_output=True,text=True)
 m=re.search(r'(\d+)\s*/\s*(\d+)',p.stdout)
 if not m or m.group(1)!=m.group(2):raise SystemExit('ASSERTION COUNT FAIL '+f.name)
 n+=int(m.group(1))
assert len(files)==23 and n==1314,(len(files),n)
print('R35 JS',len(files),n,'PASS')
subprocess.run(['node','src/run.js'],cwd=r,check=True,capture_output=True)
subprocess.run(['node','src/verify_outputs.js'],cwd=r,check=True,capture_output=True)
assert hashlib.sha256((r/'outputs/QA_RESULT.json').read_bytes()).hexdigest()=='b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'
assert hashlib.sha256((r/'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json').read_bytes()).hexdigest()=='509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8'
print('R35 CLI RECEIPT / HOLD / SOURCE OUTPUTS PASS')
if '--full' in sys.argv:
 br=sorted((r/'tests').glob('test_browser_*.py'))+[r/'tests/test_mobile_browser_r9.py'];n=0
 for f in br:
  p=subprocess.run(['python',str(f)],cwd=r,check=True,capture_output=True,text=True,timeout=55)
  m=re.search(r'(\d+)\s*/\s*(\d+)',p.stdout)
  if not m or m.group(1)!=m.group(2):raise SystemExit('BROWSER COUNT FAIL '+f.name)
  n+=int(m.group(1))
 assert len(br)==18 and n==640,(len(br),n)
 print('R35 CHROMIUM',len(br),n,'PASS')
