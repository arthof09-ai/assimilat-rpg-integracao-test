import json,hashlib,zipfile,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
files=sorted(x for x in root.rglob('*') if x.is_file() and x.suffix in {'.json','.js','.md','.html','.py'} and x.name!='MANIFEST.json' and '.zip' not in x.name and not any(part.startswith('cold_') for part in x.parts))
records={str(x.relative_to(root)):dict(sha256=hashlib.sha256(x.read_bytes()).hexdigest(),size=len(x.read_bytes())) for x in files}
manifest={'checkpoint':'CRAFT-R53-ITEM-RESOURCE-QA-20261021-001','authority':'MESTRE-SIDE TEST','files':records,'count':len(records),'purpose':'Sem writer, sem Party, sem magia instalada, sem RC5'}
(root/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=pathlib.Path('/mnt/data/CRAFT_R53_ITEM_RESOURCE_TEST_20261021.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for x in [*files,root/'MANIFEST.json']:
  p=str(x.relative_to(root)); info=zipfile.ZipInfo(p,(2026,10,21,12,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,x.read_bytes())
assert zipfile.ZipFile(archive).testzip() is None
print(json.dumps({'zip':str(archive),'size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'count':len(files)+1},ensure_ascii=False))
