# CRAFT R28 — Guia de coleta dirigido (MESTRE-SIDE / TEST)

**Natureza:** formulário de preparação de coleta, não laudo, receita, permissão de fabricação ou publicação. Instrumento nativo de evidência: **CRAFT R46**. Estas fichas apenas encaminham perguntas ao operador; nenhum resultado foi observado. Leia [LAB CRAFT](https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00) e as normas PR-CRN-01/PR-ITEM-02/REC-EXEC antes de interpretação física.

## Caso 1 — Sonda de Eco Estático / B3 — suporte e fecho

- **Estado:** `HOLD_PHYSICAL_SPEC`; 0 quantidade, 0 unidade, 0 material de fonte identificado como compatível.
- **Perguntas:** qual matéria e estado físico? Quem fornece, com qual lote e identidade? Qual encaixe e tolerância do quartzo e do cobre? Há isolamento elétrico efetivo ou pode haver contato? Qual quantidade/unidade operacional? Qual controle físico comparativo foi usado?
- **Precedente para comparação, não substituto aprovado:** [Acácia Radiante](https://app.notion.com/p/3edc2b324ede81518426d45967b10e8f). O efeito de selagem luminosa pertence à **resina** documentada, não automaticamente à madeira ou casca. Não afirmar isolamento elétrico da madeira.
- **Condição de interrupção:** sem segurança demonstrada, evitar ensaio energizado e qualquer exposição de pessoas; não atribuir capacidade de detectar magia.

## Caso 2 — Tônico de Passo Elétrico / B3 — veículo líquido

- **Estado:** `HOLD_COMPATIBILITY_AND_SAFETY`; 0 composição, dose, extração ou eficácia real demonstrada.
- **Perguntas:** veículo canônico ou material comum identificável? Composição e lote? Método de extração e estabilidade? Compatibilidade com capim/raiz? Rendimento, controle e conservação? Qual prova de segurança independente existe?
- **Precedente, não equivalência:** [Poção de Liquidação](https://app.notion.com/p/3edc2b324ede814f89f3e19247d52c5c). Ter frascos e receita histórica não valida o veículo desta formulação.
- **Condição de interrupção:** **não ingerir, aplicar em pessoas ou fabricar dose para uso** sem segurança e autoridade apropriadas; não estimar dose nem resistência.

## Caso 3 — Tônico / B4 — recipiente e vedação

- **Estado:** `HOLD_CONTAINER_PROVENANCE`; volume, material, fecho e compatibilidade não demonstrados.
- **Perguntas:** recipiente existente comprovado? Material, origem e lote? Capacidade em unidade real? Tipo de fecho, integridade, vazamento e resistência? Compatibilidade com o veículo definido em B3? Armazenagem e higiene?
- **Precedente, não equivalência:** [Óleo de Vedação](https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd), cujo frasco encantado de receita própria não define um frasco universal gratuito.

## Para todo laudo R46 futuro — não preencher por inferência

`sample_id`, `lot_id`, `operator_id`, `observation_datetime`, `instrument_id`, `calibration_validity`, `measurement`, `unit`, `uncertainty`, `tolerance`, `control_sample`, `custody_chain`, `source_document` e `independent_review` devem vir de **evidência real**, com proveniência. Uma medição fora de tolerância ou com intervalo de incerteza cruzando o limite permanece INDETERMINATE/QUARANTINE segundo avaliação R46; a simples presença dos campos **não** autentica o operador, a calibração ou a transferência mágica.

## Decisões autorais de receita ainda pendentes

Usar o **dossiê histórico existente** de 21 receitas (20 pattern-keys). P0: Vedação P2 — Sal Santo/Encantado, fonte energética e modo de aplicação. P1: Matriz de Cultivo — menção 1x quebrada, aliases de terra e água; Matriz de Proteção — quantidade literal `Ex`. Não decidir aliases por semelhança e não modificar nenhuma página sem writer/fencing/atesto. Matriz `MAT-01` tem duas receitas físicas distintas e UUIDs diferentes.

**Gates finais:** IBX-38 `NOVA`, C19-021 UNKNOWN, R51 `NOVA`, F5 P0 RED, REC-LIB parent não confirmado, RC5 0/30. Party e O Primeiro NO-WRITE. Todos os três pedidos são experimentais e MESTRE-ONLY.
