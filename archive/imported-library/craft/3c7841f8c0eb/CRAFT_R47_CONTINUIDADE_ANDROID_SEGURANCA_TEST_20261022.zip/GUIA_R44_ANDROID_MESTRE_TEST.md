# Guia curto — CRAFT R44 no Chrome Android (MESTRE-SIDE TEST)

Abra somente o arquivo **REVISOR_LOCAL_ANDROID_R53_TEST.html**, guardado na pasta privada do Mestre. O pacote não requer rede. Nunca compartilhe HTML, fichas Mestre, perguntas, notas ou arquivos JSON com a Party ou O Primeiro.

No painel **R40 — 50 perguntas históricas**, use a caixa **R42 — Localizar pendências** para procurar “óleo”, “Matriz de Cultivo” ou material, filtrar P0–P3 e escolher “Sem anotações”, “Parciais”, “Completas” ou “Incompletas”. Toque em **Abrir primeira pendência visível**. Pode voltar a “Todas”: o filtro não apaga nenhuma nota.

O botão **Salvar 50 anotações não autenticadas** exporta todas as 50 perguntas com as notas privadas. O botão **Baixar roteiro de revalidação** produz um JSON com as tarefas e uma indicação de quais campos têm notas, **sem copiar o texto das notas**. A **Importação** exige que os IDs, fontes, perguntas e gates permaneçam idênticos à base congelada.

Para provas materiais, abra **R35 — Preencher coleta R46**. Anote apenas observações ou links que existam de verdade; deixe campos desconhecidos vazios. Mesmo quando tudo estiver preenchido, o sistema **não certifica laudo, transferência mágica, fabricação ou RC5**.

A ferramenta foi testada em Chromium com emulação móvel, não em um Android físico via arquivo local. Se o navegador não abrir HTML local corretamente, utilize um leitor/gerenciador de arquivos que permita abrir HTML com Chrome; o estado de certificação permanece TEST.
