"""R41: the 8 no-lexical-issue pages are a separate evidence HOLD, NOT RC5 PASS."""
import json,csv,hashlib,pathlib
root=pathlib.Path(__file__).parent
rows=list(csv.DictReader(open(str(root/'data/R15_ORIGINAL_READBACK_29_TEST.csv'))))
names=['Inscrição Raio Poente (B)','Inscrição Chama Relâmpago (P)','Inscrição Terra Fértil (P)','Inscrição de Selamento (P) (CG)',
'Inscrição Contato Vital (P) (CG)','Inscrição Escudo Dourado Santo (ON)','Inscrição Guardiã Divina (O)','Inscrição Explosão Repentina (P) (CG)']
steps=[5,6,5,5,5,6,6,5]
clean=[r for r in rows if r['case_key'].startswith('CLEAN-')]
assert len(clean)==8
items=[]
for i,c in enumerate(clean):
 assert c['case_key']==f'CLEAN-{i+1:02d}'
 items.append({'case_key':c['case_key'],'physical_recipe_id':c['physical_recipe_uuid'],'source_url':c['url'],
    'parent_pattern_name':names[i],'last_edited_utc':c['live_last_edited'],
    'direct_notion_fetch_2026_10_22':True,'historical_lexical_issues_identified':False,
    'bom_present':True,'process_present':True,'numbered_process_steps_observed':steps[i],
    'oil_mentioned':True,'production_yield_quantity_authorized':False,'quantitative_success_rate_authorized':False,
    'r46_material_lot_verified':False,'magic_transfer_proved':False,'rc5_p4_authorized':False,
    'next_check':'Reconciliar condições, tempo, ferramentas, unidade, rendimento e perdas com evidência real REC-EXEC/R46; reaplicar dependência Óleo de Vedação. Não inventar taxas.'})
result={'schema':'CRAFT_R41_EIGHT_NO_LEXICAL_ISSUES_READBACK_TEST_V1','classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
'denominator':{'original_physical_recipes':29,'cases_with_lexical_issues':21,'without_lexical_issue_in_old_docket':8,
'rc5_real_physical_approved':0,'r41_docs_not_approved':8},'sources':{'original_csv_sha256':hashlib.sha256(pathlib.Path(str(root/'data/R15_ORIGINAL_READBACK_29_TEST.csv')).read_bytes()).hexdigest(),
 'last_direct_notion_fetch':'2026-10-22','page_edit_metadata_unchanged_from_R15':True,'bytewise_comparison_of_prior_content':False},
'cases':items,'state':'EVIDENCE_MISSING_HOLD_NOT_RC5','canonical_mutations':0,'party_release_allowed':False,
'create_recipe':False,'create_ticket':False,'fencing_verified':False,'r51_destination_verified':False}
(root/'data/r41_clean_eight_hold.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('R41',len(items),'clean lexical only; material RC5',result['denominator']['rc5_real_physical_approved'])
