# CRAFT R25 — continuação R21 / engenharia e pesquisa TEST MESTRE-SIDE

Este pacote **ESTENDE o mesmo R53/R20**, sem nova aplicação, novo protocolo, novo writer ou alteração material do Notion. O ZIP contém todos os arquivos necessários para reexecução local e o revisor offline de celular.

### Melhorias efetivas
- R22: `src/validate.js` detecta saltos de sequência, entrada BOM repetida dentro da mesma etapa, insumo consumido em várias etapas sem frações medidas, rendimento/perda/tempo/operador/armazenamento em formato inválido e parâmetros preenchidos que ainda exigem prova R46. O feedback de erro/pendência é integrado à lista de reparos/pedido de evidências já existente no HTML.
- R23: cartões Mestre I–XIII embutidos são mostrados somente para a proposta TEST original de conteúdo idêntico. Mesmo UUID com dados alterados não reaproveita ficha antiga visualmente. **Não é proteção criptográfica de segredo:** os cartões continuam embutidos no arquivo local MESTRE-SIDE.
- R24: `follow_up_request` do briefing de criação não incorpora texto livre do operador. Nome/finalidade permanecem **campos de dados não confiáveis**, jamais instruções de autoridade. O arquivo continua somente briefing TEST.
- R25: pesquisa de três nós BOM ainda pendentes em Notion Mestre; precedentes encontrados não demonstram compatibilidade material. Artefatos `PESQUISA_R25_EXISTING_FIRST_TRES_NOS_MESTRE_TEST.md` e `data/research_gaps_r25.json` não canonizam nem promovem.

### Execução
A partir da raiz descompactada:

```sh
node src/run.js
node src/verify_outputs.js
for f in tests/*js; do node "$f"; done
for f in tests/test_browser_*.py tests/test_mobile_browser_r9.py; do python "$f"; done
```

O último loop percorre cada script Python de browser **uma vez**. Os testes de browser requerem Python Playwright e Chromium (`/usr/bin/chromium` no ambiente de verificação). Não exigem acesso à rede e usam HTML injetado; não demonstram que `file://` abre no Android real.

Os arquivos em `outputs/` são QA TEST, prévia **NÃO PUBLICAR** e recibo R13. A validação de hash comprova integridade do pacote local, **não** assinatura de autoridade, medição física ou permissão de fabricar. 

### Portas fechadas
F5 P0/RED, C19-021 UNKNOWN-effect, IBX-38 fencing sem prova externa, IBX-116 sem ACK, R51 sem destino físico único, R46/H2 magia e metrologia, preço, energia, PA, RC5, P4, estoque e Party/O Primeiro. Notion Mestre read-only na execução; R14–R25 **não sincronizados no LAB/OP/Inbox**. R53 Sonda/Tônico **2/2 HOLD_TEST_DESIGN**.
