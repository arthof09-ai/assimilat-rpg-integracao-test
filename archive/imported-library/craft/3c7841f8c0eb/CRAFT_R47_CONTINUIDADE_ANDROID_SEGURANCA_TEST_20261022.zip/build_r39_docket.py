"""CRAFT R39: documental detail of the 13 remaining cases of existing R27.
All text transcribed/abstracted from official Mestre-side Notion fetch, 2026-10-22.
No decisions, measurements or canon writes. This is NOT an independent engine.
"""
import json,hashlib,pathlib,csv
p=pathlib.Path(__file__).parent
src=json.loads((p/'outputs/CRAFT_R27_FILA_21_RECEITAS_MESTRE_TEST.json').read_text())
# (case key, decision id, BOM / location, step, question, kind)
entries={
'ENC-06':[
('SHADOW_ESSENCE','3x Essência Sangue das Sombras','Essência de Sombra na etapa 1','O processo consome Essência de Sombra ou Essência de Sangue das Sombras? A purificação é subreceita necessária?','MATERIAL_IDENTITY')],
'BAT-06':[
('COMET_POWDER','3x Pó de Cometa Solar','Pó de Cometa nas etapas e localização','O qualificativo Solar identifica o mesmo componente? Qual origem e especificação obrigatórias?','MATERIAL_IDENTITY'),
('ETERNAL_FLAME_STATE','1x Essência de Chama Eterna','Óleo de Chama Eterna aquecido na etapa 4','É essência ou óleo? Se houver transformação, indicar fórmula, consumo, rendimento e condição.','MATERIAL_IDENTITY'),
('SUNFLOWER_PART','1x Girassol Místico','Pétalas de Girassol Místico trituradas na etapa 6','Uma unidade de girassol fornece as pétalas requeridas? Qual parte, quantidade útil e perdas?','TRANSFORMATION_UNPROVED')],
'BAT-12':[
('BLOOD_SOURCE','2x Sangue de Besta Demoníaca','Sangue de Hidra Carmesim até metade da garrafa','Hidra Carmesim é condição obrigatória ou subtipo opcional aprovado de Besta? Qual material, quantidade e unidade realmente exigidos?','MATERIAL_IDENTITY'),
('BOTTLE_VOLUME','2x Sangue de Besta Demoníaca','garrafa preenchida até metade, volume não indicado','Qual capacidade do recipiente e como conciliar metade do volume com 2x sangue? Não inventar dose.','QUANTITY_VOLUME')],
'BAT-03':[
('ICE_POWDER_FORM','3x Pó de Gelo Eterno','Pó do Gelo Eterno na etapa 1','Ambas as expressões são o mesmo recurso e forma? Confirmar antes de normalizar o título.','LEXICAL_CANDIDATE'),
('FROST_BREATH_FORM','1x Sopro Congelante','Sopro do Congelante na etapa 1','O uso de artigo indica só variante linguística ou insumo diferente? Fonte de contenção?','LEXICAL_CANDIDATE')],
'BAT-11':[
('PORTAL_OR_MIRROR','2x Fragmentos de portais','Fragmentos de Espelho do Destino na etapa 2','Qual componente é efetivamente utilizado? Sem equivalência automática entre portal e espelho.','MATERIAL_IDENTITY'),
('STEP_NUMBERING','etapas 1,2,3 + Óleo de Vedação','marcadores bullet e reinício 1,2','Confirmar sequência real das etapas e preservar o conteúdo enquanto normaliza a apresentação.','PROCESS_SEQUENCE')],
'BAT-13':[
('LEVIATHAN_ESSENCE','1x Essência de Sopro do Leviatã','Essência do Sopro do Leviatã na etapa 1','É a mesma substância com artigo diferente? Consultar a identidade Mestre antes de harmonizar.','LEXICAL_CANDIDATE'),
('STEP_NUMBERING','etapas 1,2,3 + óleo intermediário','marcadores bullet e reinício 1,2','Confirmar posição inequívoca do óleo e a sequência antes de renumerar.','PROCESS_SEQUENCE')],
'MAT-02':[
('ICE_CRYSTALS','2x Cristais de Gelo de Eterno','Cristais de Gelo de Gigante na fonte e etapa 3','Qual cristal e procedência é necessário? Ausência de equivalência provada.','MATERIAL_IDENTITY'),
('HARPY_PART','4x Pena de Asa de Harpia','Poeira de Asa de Harpia na fonte e etapa 5','É pena integral ou poeira derivada? Indicar processamento, rendimento e proporção.','TRANSFORMATION_UNPROVED'),
('DEMONIC_SPIRIT','1x Espírito Demoníaco de vento, fogo e gelo','nenhuma etapa clara para incorporação','Qual identidade do(s) espírito(s), tipo e etapa segura de incorporação? Não inferir vínculo ou mecanismo.','UNCONSUMED_BOM'),
('OIL_MISSING_STEP','1x Óleo de Vedação','não consta nas cinco etapas','Em qual etapa o óleo é consumido, e qual sua função? Resolver o upstream Óleo Mestre.','UNCONSUMED_BOM')],
'ENC-01':[
('FROZEN_LEAVES','4x Folhas do Sussurro Congelados','Folhas de Mintaur trituradas na etapa 3','A receita requer folhas de qual espécie? Não substituir automaticamente com base em similaridade.','MATERIAL_IDENTITY')],
'MAT-01-P':[
('SOUL_VS_MANA_CRYSTAL','1x Cristais de Alma 2P','Cristais de Mana Puro na etapa 2','Determinar a identidade do cristal (e classificação 2P) sem confundir Mana e Alma.','MATERIAL_IDENTITY'),
('OIL_NOT_INSTALLED','1x Óleo de Vedação','não incluído nas quatro etapas','Qual etapa consome o óleo e como este interage com o circuito de invocação?','UNCONSUMED_BOM'),
('ENERGY_ALTERNATIVE','2x Pedra da Luz OU 2x Pote de Essência Mágica','etapas não usam claramente a opção energética','Definir qual das rotas alternativas é válida, operador, unidade, instalação e consumo.','UNCONSUMED_BOM')],
'ENC-02':[
('HEART_ASH_ALIAS','2x Cinzas Coração Flamejante','Cinzas do Coração Flamejante na etapa 1','É variação gramatical da mesma cinza? Exigir confirmação antes de alterar nome canônico.','LEXICAL_CANDIDATE')],
'BAT-04':[
('ICE_KIND','4x Cristais de Gelo Eterno','Cristais de Gelo Profundo nas fontes e etapa 1','Definir origem e material; não presumir que gelo profundo tem as propriedades de gelo eterno.','MATERIAL_IDENTITY'),
('WIND_KIND','3x Essência de Vento Ártico','Essência de Vento Polar nas fontes e etapa 2','Definir qual essência real e sua fonte, sem inferir igualdade climática/elemental.','MATERIAL_IDENTITY')],
'BAT-10':[
('SHADOW_DEW_OR_ESSENCE','5x Orvalho da Sombra Profunda','Essência de Sombra Profunda apenas na localização','Confirmar qual matéria-prima abastece a BOM; procedência diferente não autoriza equivalência.','MATERIAL_IDENTITY'),
('STEP_NUMBERING','etapas numeradas 1,2,3 e inclusão de óleo','seguem bullet e etapas 1,2','Confirmar ordem operacional e corrigir numeração sem mudar consumo.','PROCESS_SEQUENCE')],
'MAT-04':[
('OIL_MISSING_STEP','1x Óleo de Vedação','óleo ausente no processo explícito','Determinar etapa e interface de aplicação do óleo (upstream óleo ainda inconsistente).','UNCONSUMED_BOM'),
('ENERGY_MISSING_STEP','5x Pedra da Luz OU 5x Pote Essência Mágica','nenhuma etapa inequívoca de instalação/consumo','Escolher ou documentar alternativa autorizada, unidade, processo e manutenção/energia.','UNCONSUMED_BOM')]
}
# MAT-01 on R27 has a second row for ON; priority P2 selects P.
allcase=src['cases']; rows=[]; known=set()
for case in allcase:
 k=case['pattern_key'];k=('MAT-01-P' if k=='MAT-01' and case['priority']=='P2_IDENTIDADE' else k)
 if k not in entries:continue
 assert k not in known,(k,'duplicate');known.add(k)
 slots=[]
 for id,bom,process,q,kind in entries[k]:
  slots.append({'id':id,'bom_literal':bom,'process_literal':process,'question':q,'issue_class':kind,'decision':None,'physical_equivalence_verified':False})
 rows.append({'key':k,'physical_recipe_id':case['physical_recipe_id'], 'source_url':case['source_url'],
              'priority':case['priority'],'original_issue':case['issues_from_live_snapshot'],
              'last_edited_utc':case['physical_recipe_edit_now'], 'readback_status':'NOTION_DIRECT_READ_2026_10_22',
              'decision_slots':slots,'authorship_state':'AWAITING_MESTRE_AUTHENTICATION'})
assert len(rows)==13 and len(known)==len(entries),len(rows)
assert len({c['physical_recipe_id'] for c in rows})==13
n=sum(len(c['decision_slots']) for c in rows)
assert n==27,n
assert {c['key'] for c in rows} == set(entries)
provenance=hashlib.sha256((p/'outputs/CRAFT_R27_FILA_21_RECEITAS_MESTRE_TEST.json').read_bytes()).hexdigest()
result={'schema':'CRAFT_R39_REMAINING_13_RECIPE_READBACK_TEST_V1',
'classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY','type':'DOCUMENTAL_AUTHOR_QUESTIONS_NOT_CANON',
'origin_r27_sha256':provenance,
'authority_basis':'Original R27 dossier + direct official Mestre Notion page reads 2026-10-22. No transcript copied into Party.',
'coverage':{'original_recipes':29,'original_issue_recipes':21,'previously_detailed':8,'newly_detailed':13,'detailed_issue_recipes_total':21,
            'remaining_issue_recipes':0,'R30_questions':11,'R36_questions':9,'R38_questions':3,'R39_questions':n,'questions_total':23+n,
            'all_choices_authored':0,'rc5_material_approved':0},
'cases':rows,'gates':{'physical_magnetic_transfer_proved':False,'external_fencing_proved':False,'r51_single_parent_approved':False,
                    'mestre_decisions_authenticated':False,'rc5_p4_production_allowed':False,'party_release_allowed':False},
'notion_mutations':0,'creates_recipe':False,'creates_ticket':False}
(p/'data/r39_remaining_13_recipe_readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (p/'R39_13_RECEITAS_PENDENCIAS_MESTRE_TEST.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['case_key','physical_recipe_id','priority','slot','kind','BOM_original','processo_original','pergunta','source_url','decision'])
 for c in rows:
  for s in c['decision_slots']:
   w.writerow([c['key'],c['physical_recipe_id'],c['priority'],s['id'],s['issue_class'],s['bom_literal'],s['process_literal'],s['question'],c['source_url'],'PENDENTE'])
print('R39',len(rows),'recipes',n,'questions',result['coverage'])
