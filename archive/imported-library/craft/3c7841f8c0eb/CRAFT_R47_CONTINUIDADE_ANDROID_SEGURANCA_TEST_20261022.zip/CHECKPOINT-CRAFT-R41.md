# CHECKPOINT — CRAFT R41 (MESTRE-SIDE, TEST) — 22/10/2026

## Recuperação e governança

- Origem R38/R35 verificada a partir dos checkpoints/pacotes locais. NAC-AUTO-01 tratado como **PROPOSTA**, usado como orientação de autonomia sem promoção normativa.
- Leitura atual do Notion confirmou **IBX-38 / IBX-116 / R51 = NOVA, exige ACK**. A conexão de Notion desta execução expõe apenas `search`/`fetch`, não atualização. Fencing externo C19-021, writer/lease/epoch, único pai REC-LIB, magic-transfer/RC5 e publicação Party **não comprovados**.
- Laboratório/OP/Inbox ainda possuem último registro CRAFT conhecido R13; a Biblioteca pode guardar pacotes, mas não constitui sincronização da OP canônica. Fichas oficiais, Party e O Primeiro não receberam writes.

## Estado após R39–R41

- R39: 13/13 receitas faltantes relidas diretamente no Notion Mestre; **27 perguntas documentais** (11 identidade material; 6 BOM sem consumo explícito; 4 possibilidade de alias lexical; 3 sequência; 2 transformação; 1 unidade-volume). Nenhuma equivalência canonizada.
- R40: mesmo HTML R53 atualizado com painel privado e funcional de 50 campos, proveniências imutáveis e importação bloqueada quando fonte/UUID/autorizações divergem. As 11 decisões R31, 72 campos R46 e QA R53 anteriores foram preservados.
- R41: 8/8 páginas anteriormente sem divergência lexical relidas no Notion; todas têm BOM e passos, nenhuma promovida. `29=21+8` IDs físicos únicos. **47 perguntas de receitas + 3 do óleo = 50**. 0 decisões autenticadas, 0 homologações RC5.
- QA dos dois projetos TEST ainda `HOLD_TEST_DESIGN`; `QA_RESULT.json` SHA256 `b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541`, prévia SHA `509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8`, ambos inalterados.

## Próxima retomada exata

1. Ler este checkpoint e verificar Notion IBX38, IBX116 e R51, OP e LAB; **não** reivindicar writer/lease/epoch por herança.
2. Usar o HTML R41 para registrar **notas** sobre as 50 perguntas e trazer autorização/autenticidade independente do Mestre. Para correção futura, conferir ficha Mestre original por UUID e comparador antes/depois, aplicar NAC-PASS e controle de efeitos em 29 receitas. Não promover automaticamente notas digitadas.
3. R46 exige dados genuínos de ensaio (operador, amostra, instrumento, calibração, lote, controles, incerteza, custódia), sem inventar resultados. Três nós iniciais continuam pendentes: Sonda B3, Tônico B3, Tônico B4.
4. Após futura liberação formal e fencing comprovado, conciliar referência MAT03, identidade/receita upstream Óleo de Vedação, BOM ↔ processo, R51 biblioteca física e custo/PA; sempre preservar IDs e histórico.
5. Não criar motor, receita, operação, ticket, logs em fichas ou duplicatas. Party/O Primeiro NO-WRITE, sem auto-ACK.

**Ponto de checkpoint:** R41 TEST documentado; código R40 último software funcional; R39/R41 são relatórios e fontes do mesmo motor. Estado canônico sem alteração; publicação em Library não equivale a Notion sincronizado.
