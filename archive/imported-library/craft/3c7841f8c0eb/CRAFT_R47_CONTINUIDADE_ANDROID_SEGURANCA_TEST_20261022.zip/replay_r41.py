"""R41 TEST replay: verify immutable hashes, original QA receipt, regression suites.
--full extends to Chrome emulation, not a physical Android device certification.
"""
from pathlib import Path
import json,hashlib,subprocess,re,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST-R41.json').read_text())
assert manifest['schema']=='CRAFT_R41_TEST_MANIFEST_V1'
for k,expected in manifest['files'].items():
 path=root/k
 assert path.is_file(),('MISSING',k)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,('HASH_CHANGED',k)
print('MANIFEST',len(manifest['files']),'/',len(manifest['files']),'PASS')
expected_js=1447;expected_browser=669
files=sorted((root/'tests').glob('test_*.js'))
count=0
for f in files:
 p=subprocess.run(['node',str(f)],cwd=root,capture_output=True,text=True,timeout=40)
 if p.returncode:raise RuntimeError(('JS',f.name,p.stderr[-1000:],p.stdout[-1000:]))
 ms=re.findall(r'(\d+)\s*/\s*(\d+)',p.stdout)
 if not ms or ms[0][0]!=ms[0][1]:raise RuntimeError(('JS COUNT',f.name,p.stdout))
 count+=int(ms[0][0])
assert len(files)==26 and count==expected_js,(len(files),count)
print('JS',count,'/',expected_js,'PASS')
subprocess.run(['node','src/run.js'],cwd=root,check=True,capture_output=True,timeout=40)
subprocess.run(['node','src/verify_outputs.js'],cwd=root,check=True,capture_output=True,timeout=40)
assert hashlib.sha256((root/'outputs/QA_RESULT.json').read_bytes()).hexdigest()=='b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'
assert hashlib.sha256((root/'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json').read_bytes()).hexdigest()=='509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8'
print('QA RECEIPT + SOURCE HOLD PASS')
p=subprocess.run(['node','tests/fuzz_schema_r11.js'],cwd=root,capture_output=True,text=True,timeout=60)
assert p.returncode==0 and 'PASS 2000' in p.stdout,p.stdout[-1000:]+p.stderr[-1000:]
print('FUZZ 2000/2000 informational PASS')
if '--full' in sys.argv:
 files=sorted((root/'tests').glob('test_browser_*.py'))+[root/'tests/test_mobile_browser_r9.py']
 count=0
 for f in files:
  p=subprocess.run([sys.executable,str(f)],cwd=root,capture_output=True,text=True,timeout=90)
  if p.returncode:raise RuntimeError(('BROWSER',f.name,p.stdout[-1000:],p.stderr[-1000:]))
  ms=re.findall(r'(\d+)\s*/\s*(\d+)',p.stdout)
  if not ms or ms[0][0]!=ms[0][1]:raise RuntimeError(('BROWSER COUNT',f.name,p.stdout))
  count+=int(ms[0][0]);print('BROWSER',f.name,ms[0][0],flush=True)
 assert len(files)==19 and count==expected_browser,(len(files),count)
 print('CHROMIUM',count,'/',expected_browser,'PASS')
print('R41 TEST REPLAY COMPLETE; NEVER CANONICAL OR MATERIAL RC5 CERTIFICATION')
