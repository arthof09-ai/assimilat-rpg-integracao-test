# CRAFT R18 — correções críticas orientadas no MESMO revisor Android TEST

**Problema concreto resolvido:** no R17, `valid()` devolvia códigos de REJECT, mas um JSON rejeitado não se tornava a proposta ativa e, por isso, o Mestre não conseguia baixar as correções necessárias; só via os códigos em texto. R18 mantém o bloqueio e acrescenta **roteiro sanitizado de reparo** para aquele arquivo recusado, sem torná-lo válido ou armazená-lo como lote ativo.

**Delta mínimo:** somente `build_mobile.py` e HTML gerado; a validação R53/R17, fontes, entradas originais, QA, prévia, recibo R13, módulos, normas e contas permanecem byte-idênticos. `R18_ISSUE_ACTIONS` é uma tabela local de APRESENTAÇÃO/COLETA para classes de código já existentes, não regra de criação, motor novo, execução de reparo, checklist físico certificado ou autoridade de escrita.

**Uso:** abrir HTML Mestre TEST; tentar importar JSON com erros; conferir mensagem de rejeição e pressionar **Baixar correções do arquivo rejeitado (Mestre TEST)**. O conteúdo contém apenas códigos, questões a esclarecer, campos de evidência ainda nulos e negativas de autorização; sem texto bruto de segredo `master_secrets`. A proposta válida continua intocada; importar JSON sintaticamente inválido ou arquivo válido limpa o roteiro rejeitado, prevenindo o download de um roteiro obsoleto. O botão de roteiro geral R14 continua funcional para projetos válidos.

**Classes cobertas:** segredo/Party, fonte/UUID/EXISTING-FIRST, BOM/processo/unidades, RI/RE/RIn/FIP/PA, reivindicação sem prova física, economia e identidade/esquema. Códigos novos/desconhecidos seguem para triagem manual explícita, jamais “auto corrigidos”. As prioridades P0 deste arquivo referem-se **à ordem visual de correção do JSON TEST** e não alteram o STOP material F5 P0, C19 ou NAC.

**Regressão:** 517/517 JS R53–R17 (12 suítes), mais fuzz 2.000 informacional; UI Chromium inline 154/154 prévia R9–R17 + 171/171 R18 = 325/325. Inclui testes de arquivo efetivamente rejeitado, download permitido, ausência de segredo literal, integridade da proposta anterior, limpeza de roteiro obsoleto, arquivo válido posterior e zero rede. Android físico/file:// NÃO testado. 2 propostas R53 continuam HOLD_TEST_DESIGN e 0 produto/RC5 oficial.

**Fontes:** [Metodologia aplicada R17](METODOLOGIA_APLICADA_R17_MESTRE_TEST.md), PR-CRN-01, PR-ITEM-02, REC-EXEC, PR-SC-01, PR-ECO Anexo C e R46. Não tocar Party/O Primeiro, Notion produção nem alegar permissão de writer/ACK.
