# PSV — CRAFT R47 — Gate TEST DIGITAL

Escopo: proteção contra perda/overwriting de notas do Mestre, integridade documental de 29 UUIDs de receita, e regressão do motor R53. **Nenhum teste é ensaio de fabricação, comprovação de magia, assinatura de Mestre ou permissão de produção.**

## Riscos examinados

- Reiniciar R35 com observações digitadas: agora exige confirmação; cancelar preserva 72 controles e valores.
- Importar R40/R31 sobre valores locais: pedido explícito de substituição após verificação de esquema e metadados; cancelamento não altera campos e reset do input permite reimportar.
- Recarregar aba: aviso de dados locais modificados, mas apenas best-effort mobile e NÃO armazenamento automático.
- Duplicidade de UUID entre receitas no baseline: `HOLD_INCOMPLETE_READBACK` também quando os outros carimbos coincidem; não contar como `NO_TIMESTAMP_DRIFT_OBSERVED`.
- Dados maliciosos/secretos: continuam Mestre-only, renderizados como texto, sem HTTP nem publicação de Party; status de notas é não autenticado.

## Provas

Bancada R47: 30 suítes JS, 1.765/1.765 verificações; 23 suítes Chromium, 778/778 verificações somando R45 (35), R47 (18) e regressões pré-existentes (725); 2.000 sondagens sintéticas; hash de QA e prévia preservados. Reprodução fria concluída de ZIP extraído: 185/185 arquivos com SHA-256 no manifesto; 30/30 suítes JS, 1.765/1.765; 2.000 sondagens, SHA de QA e prévia idênticos ao R44; 23/23 suítes Chromium em três blocos, 778/778. O gate concedido é SOMENTE TEST digital. A reprodução deve manter SHA do QA e prévia exatamente como R44. A validação de navegador deve ser descrita como **Chromium móvel emulado**, e não Android físico.

## Gates

TEST digital sujeito à reprodução limpa. Notion canônico continua NO-WRITE, C19/R51 HOLD. O produto ainda possui 0 RC5 homologadas e 0 publicações Party.

## Deliberação proporcional de validação

**PASS TEST DIGITAL R47** para revisor e comparador de identidade. **HOLD** para Chrome Android físico, autoria de notas, laudos R46, C19-021/fencing, REC-LIB, RC5, produção e divulgação Player. Este documento NÃO concede NAC-PASS material ou produção.
