import json,pathlib
p=pathlib.Path(__file__).resolve().parent
obj=json.loads((p/'data/proposals.json').read_text()); resources=json.loads((p/'data/resources.json').read_text()); rmap={v['id']:v for v in resources['resources']}
cards=[]; graph={'nodes':[],'edges':[],'relationships_must_not_imply_reality':True}
for item in obj['products']:
    resource_names=[rmap[b['source_id']]['name'] for b in item['bom'] if b['source_id'] in rmap]
    current={
      'I_IDENTIDADE': {'nome':item['name'],'familia':item['family'],'classificacao':'PENDENTE','FIP':'PENDENTE','natureza':'PROPOSTO artesanal/híbrido','estado':'NOVO-P TEST sem existência material'},
      'II_DESCRICAO_FISICA': {'descricao':item['physical_description'],'materialidade_observada':None,'dimensoes':'PROPOSTAS ou PENDENTES','sinais_autenticidade':'PENDENTE'},
      'III_PROPRIEDADES_MECANICA': {'efeito':item['mechanic'],'ativacao':item['activation'],'duracao':item['duration'],'alcance':item['range'],'recarga':item['cooldown'],'pa_dia':item['pa_daily'],'pa_uso':item['pa_activation'],'contramedidas':'PENDENTE onde não especificado'},
      'IV_PODER': {'rank_item':item['item_rank'],'rank_efeito':item['effect_rank'],'comparadores':'Efeitos de fontes são comparadores de função, NÃO E0 de RE','stress':'Proibir imunidade/dano/resistência sem prova'},
      'V_ORIGEM_FORMACAO': {'desenho':item['design'],'formacao_real':None,'receita_vigente':False,'tempo':item['craft_time']},
      'VI_GEOGRAFIA_AMBIENTE':{'origem':item['geography'],'ocorrencia_do_produto':None,'novo_POI':False},
      'VII_OBTENCAO':{'metodo':item['acquisition'],'estoque_real':None,'rendimento':item['yield'],'perdas':item['loss_rate']},
      'VIII_RECEITA_CADEIA':{'fontes_existentes':resource_names,'bom_nodes':[b['node_id'] for b in item['bom']],'etapas':[x['step'] for x in item['process']],'REC_ID_canônico':None,'RC5':False},
      'IX_ECONOMIA': item['economy'],
      'X_POLITICA_SOCIEDADE': {'status':'PENDENTE, hipótese nunca fato','conteudo':item['politics']},
      'XI_HISTORIA_CONHECIMENTO': {'historico':item['history'],'conhecimento_player':'não descoberto ou não publicado'},
      'XII_JOGABILIDADE': {'ganchos':item['gameplay'],'efeito_jogavel':False},
      'XIII_AUDITORIA': {'evidencia':'fontes canônicas REAIS para material; montagem e efeitos NOVO-P','pontos_pendentes':['RE','PA','REC-ID','lote','operador','rendimento','efeito instalado','MED','prova física'],'MESTRE_ONLY':True,'Party:NO_WRITE':True}
    }
    cards.append({'id':item['proposal_id'],'chapters':current,'status':'DOCUMENTAL_TEST_HOLD'})
    product_id='product:'+item['proposal_id']; recipe_id='recipe_test:'+item['proposal_id']
    graph['nodes'].extend([{'id':product_id,'type':'ITEM_PROPOSTO','exists_physically':False},{'id':recipe_id,'type':'RECEITA_CANDIDATA','RC5':False}]);
    graph['edges'].append({'from':recipe_id,'to':product_id,'relation':'ALVO_PROPOSTO','not_physical_creation':True})
    for b in item['bom']:
        if b['source_id'] and b['source_id'] in rmap:
            rid='resource:'+b['source_id']
            if not any(x['id']==rid for x in graph['nodes']):graph['nodes'].append({'id':rid,'type':'RECURSO_FICHA_EXISTENTE','physical_unit_stock_unknown':True,'url':rmap[b['source_id']]['source_url']})
            graph['edges'].append({'from':rid,'to':recipe_id,'relation':'BOM_FUNCTIONAL_ROLE_CANDIDATE','role':b['role'],'quantity':b['qty'],'no_stock_claim':True})
(p/'data/master_cards_13.json').write_text(json.dumps({'status':'MESTRE_ONLY_TEST','cards':cards},ensure_ascii=False,indent=2)+'\n')
(p/'data/provenance_graph.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n')
print('written cards',len(cards),'graph',len(graph['nodes']),'nodes',len(graph['edges']),'edges')
