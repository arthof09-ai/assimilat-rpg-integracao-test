# CRAFT R29–R30 — Continuidade metodológica e custódia TEST

Implementado **no mesmo motor R53/R20/R28**. Não cria segundo motor, norma, receita, laboratório físico, autorização, página Notion nem registro de produção. A aplicação HTML é offline e destinada exclusivamente ao Mestre.

## R29 — Triagem do formulário original R46

- Entrada: o JSON de **pedido de evidências** exportado pela aplicação R28/R29 para **a versão exata das propostas embutidas**. Edita-se apenas `observed_data`, `proof_url` e os campos de `r46_record` no pedido; não editar identidade, metas, status, lista de materiais ou gates.
- O R29 confere estrutura, correspondência ao snapshot e valores declarados. Qualquer alteração de identificador, exigência, classificação, fonte, permissão de produção, status de laboratório ou projeto torna o documento `REJECT_UNTRUSTED_REPORT`. A cada importação, invalida-se o relatório anterior; a mudança das propostas impede herança de dados.
- O resumo exportado **não contém os relatos/observações nem prova material bruta**, apenas contagens e pendências. Mesmo 72/72 campos preenchidos são apenas **relatos não verificados**. O arquivo de entrada original deve continuar sob custódia adequada, fora do HTML, para revisão independente de operador, instrumentos, calibração, lotes, cadeia de custódia, segurança e magia.
- O HTML não acessa servidores. Chromium 390×844 demonstra comportamento web inline, **não Android físico nem hospedagem**.

## R30 — Fila autoral aplicável, sem adjudicação

- `PARECER_CRAFT_R30_DECISOES_MESTRE_TEST.md` e `outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json` provêm de `data/r27_decision_register_readonly.json` e `data/r28_readback_21.json`, preservando 21/29 e 8/29 e os UUIDs originais. Não gera decisão nem REC-ID novo.
- 11 campos de decisão em quatro blocos: Vedação P2 (sal, rota energética), Matriz de Cultivo (referência 1x/óleo, terra, água), Matriz de Proteção (quantidade `Ex`, sopro, consumo óleo/energia) e Óleo Mestre (pó 3x; orvalho; essência). Nunca resolver `Ex`, equivalência de material ou energia por semelhança lexical.
- Leitura Notion Mestre diretamente em 22/10/2026 revalidou as quatro fontes sem edição posterior às datas históricas; **somente metadados e trechos relevantes**, não prova de lote ou aprovação.

## Testes de regressão

- JS R28: 922/922; R29: +76; R30: +61 => **1059/1059** em 19 suítes.
- Chromium R28: 536/536; R29: +27 => **563/563** em 14 suítes. Fuzz 2.000 sondagens determinísticas informacionais separado.
- Saídas CLI QA/prévia e recibo de origem permanecem bit a bit idênticos ao R28. O pacote pode ser reproduzido em extração limpa por `python replay_r30.py` e `python tests/test_browser_r29.py` (Chromium/Playwright necessários para browser).

## Governança

- Notion fornece somente `fetch`/`search` nesta conexão, não `notion_update_page`; registro CRAFT em OP/LAB/IBX verificado apenas até R13. R14–R30 preservados local/Biblioteca, **NÃO SINCRONIZADOS** nas páginas Notion.
- IBX38, IBX116 e R51 seguem NOVA, ACK YES. C19-021 UNKNOWN, fencing externo não atestado, R51 parent REC-LIB sem prova; F5 RED, RC5/P4/produção HOLD. Nenhuma Party ou O Primeiro write, nenhuma apropriação de writer/lease/epoch, 0 recurso/receita/estoque/PA modificado.
