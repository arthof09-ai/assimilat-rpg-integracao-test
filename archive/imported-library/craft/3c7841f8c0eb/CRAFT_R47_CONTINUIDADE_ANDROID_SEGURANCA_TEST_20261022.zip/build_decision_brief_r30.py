"""R30: projection from the EXISTING 21-case CRAFT docket. Advisory; never edits Notion."""
import hashlib,json,pathlib
base=pathlib.Path(__file__).resolve().parent
source=base/'data/r27_decision_register_readonly.json';d=json.loads(source.read_text())
r= json.loads((base/'data/r28_readback_21.json').read_text())
assert len(d['issues'])==len(r['rows'])==21
assert hashlib.sha256(source.read_bytes()).hexdigest()=='6ea83f2b702f5624694db6e83378208827fc1e2a3a99f40e255e6f307137269e'
by_id={x['physical_recipe_id']:x for x in r['rows']}
for x in d['issues']:
 row=by_id[x['physical_recipe_id']]
 assert row['pattern_key']==x['pattern_key'] and row['within_itens_ancestry'] is True
 assert row['edited_after_20261021_docket'] is False
 assert row['recipe_rc5_verified'] is False
cases=[
 {'key':'ENC-08','physical_recipe_id':'3edc2b324ede811783dfce62058ca6b8',
  'decision_slots':[{'id':'SALT_IDENTITY','bom_literal':'2x Sal de Geodo Santo','process_literal':'Sal de Geodo Encantado','question':'Qual substância é efetivamente consumida e qual a fonte oficial?','decision':None,'requires_bom_process_reconciliation':True},
   {'id':'ENERGY_ALTERNATIVE','bom_literal':'2x Pedra da Luz OU 2x Pote de Essência Mágica','process_literal':'sem etapa inequívoca de instalação/uso desta fonte','question':'As rotas são alternativas exclusivas? Qual unidade real, procedimento, operador e consumo comprovado?','decision':None,'requires_bom_process_reconciliation':True}]},
 {'key':'MAT-03','physical_recipe_id':'3edc2b324ede81faafa2ce406944d9b6',
  'decision_slots':[{'id':'BROKEN_1X_REFERENCE','bom_literal':'1x [referência antiga 707d83314e7c40cd89bc70fb240e6076]','process_literal':'menção Óleo de Vedação na localização, sem uso em etapa de processo','question':'O componente 1x deve apontar à ficha Óleo de Vedação Mestre 3edc2b324ede81f1a88ec69980ab6cfd? Somente após decisão e fencing.','decision':None,'candidate_not_verified':True},
    {'id':'EARTH_ALIAS','bom_literal':'5x Terra Encantada','process_literal':'Terra de Gigante','question':'São o mesmo material? Se não, qual é o BOM e qual é a etapa correta?','decision':None},
    {'id':'WATER_ALIAS','bom_literal':'3x Essência de Água da Nascente','process_literal':'Água de Nascente Élfica','question':'Identidades e unidades são equivalentes? Qual fonte autoral?','decision':None}]},
 {'key':'MAT-06','physical_recipe_id':'3edc2b324ede8129a6c3cfb603027383',
  'decision_slots':[{'id':'EX_QUANTITY','bom_literal':'Ex Pó de Quartzo Fantasma','process_literal':'uso sem número definido','question':'Qual quantidade numérica e unidade explicitamente autorizadas? Proibido interpretar Ex como um número.','decision':None},
   {'id':'WIND_ALIAS','bom_literal':'1x Sopro de Vento Mundial','process_literal':'Sopro de Vento Ancestral','question':'Qual identidade material correta e como reconciliar a etapa?','decision':None},
   {'id':'ENERGY_OIL_STEPS','bom_literal':'1x Óleo de Vedação; 5x Pedra da Luz OU 5x Pote de Essência Mágica','process_literal':'sem passos inequívocos dos dois consumos','question':'Qual a etapa, rota energética exclusiva e evidência física?','decision':None}]},
 {'key':'UPSTREAM_OIL','physical_recipe_id':None,
  'source_url':'https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd',
  'decision_slots':[{'id':'OIL_POWDER','bom_literal':'3x Pó de Ferro Celestial (ficha Mestre)','process_literal':'espelho Party histórico 2x não autoriza troca','question':'Manter ficha Mestre como fonte; decidir somente inconsistências materiais com autoridade.','decision':None},
   {'id':'OIL_DEW','bom_literal':'Gota do Orvalho do Amanhecer','process_literal':'Orvalho de Dragão','question':'Qual insumo e processamento estão corretos?','decision':None},
   {'id':'OIL_ESSENCE','bom_literal':'Essência de da lua minguante','process_literal':'Essência de Vórtice','question':'Qual identidade funcional e evidência de transformação?','decision':None}]}
]
keymap={(i['pattern_key'],i['physical_recipe_id']):i for i in d['issues']}
for c in cases:
 if c['physical_recipe_id']:
  issue=keymap[(c['key'],c['physical_recipe_id'])]
  c['source_url']=issue['source_url']
  c['priority']=issue['priority']
  c['canonical_page_last_edited_utc']=by_id[c['physical_recipe_id']]['page_last_edited_utc']
 else:c['priority']='UPSTREAM_SHARED'
 c['authority_state']='PENDENTE_DECISAO_MESTRE'
 c['canonical_mutation_performed']=False
 c['can_produce_or_release']=False
result={'schema':'CRAFT_R30_AUTHOR_DECISIONS_TEST_V1','classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
 'type':'ADVISORY_READONLY_NOT_CANONICAL','source_docket_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'readback_schema':r['schema'],'readback_as_of':r['readback_date_utc'],
 'denominators':{'all_child_recipes':29,'recipes_with_lexical_issues':21,'remaining_without_reported_lexical_issue':8,'priority_physical_recipes_in_this_brief':3,'shared_upstream_oil':1},
 'cases':cases,'crosscutting_count':len(d['crosscutting_decisions']),
 'constraints':{'c19_fencing_confirmed':False,'ibx38_ack_obtained':False,'r51_physical_parent_confirmed':False,'r46_physical_measurement_available':False,'physical_rc5_approved':False,'notion_write_permitted':False,'party_or_o_primeiro_write_permitted':False},
 'all_choices_blank':True,'conclusion':'Requer decisão Mestre para cada identidade; dados físicos e writer externo seguem HOLD.'}
out=base/'outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json';out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
md=['# CRAFT R30 — Perguntas autorais prontas para despacho (Mestre / TEST)',
  'Reutiliza o dossiê original das 21 receitas; não cria nova autoridade, regra, receita, registro físico, identidade ou decisão em nome do Mestre.',
  '**Escopo:** 3 receitas físicas prioritárias e 1 insumo compartilhado (Óleo). Os demais 18 casos do dossiê permanecem na fila R27. As 8 sem divergência lexical não estão homologadas.',
  '**Estado:** proposta de perguntas, não resposta nem autorização. Links abaixo são Mestre-only.']
for c in cases:
 md+=[f"\n## {c['key']} — {c['priority']}",f"Fonte: {c['source_url']}"]
 for slot in c['decision_slots']:
  md+=[f"**{slot['id']}** — BOM: {slot['bom_literal']}; processo: {slot['process_literal']}.",f"Pergunta ao Mestre: {slot['question']}","Decisão: **PENDENTE (campo não preenchido)**."]
md+=['\n## Gates conservados','- C19-021 UNKNOWN + fencing técnico IBX38 sem atestado; R51/REC-LIB sem destino físico; sem writer/lease/epoch e sem ACK.','- RC5/P4/produção, inventário, PA e publicação Party continuam bloqueados.','- Nenhuma decisão desse papel substitui R46, provas de ingredientes, operador ou classificação do efeito.','- R30 TEST apenas. Próximo passo: Mestre resolver identidade; depois revalidar BOM↔processo nos módulos PR-ITEM/REC-EXEC, seguindo NAC-NORM/NAC-PASS.']
(base/'PARECER_CRAFT_R30_DECISOES_MESTRE_TEST.md').write_text('\n\n'.join(md)+'\n',encoding='utf8')
print('R30 decision cards:',len(cases),'slots:',sum(len(x['decision_slots']) for x in cases),'physical ids:',3)
