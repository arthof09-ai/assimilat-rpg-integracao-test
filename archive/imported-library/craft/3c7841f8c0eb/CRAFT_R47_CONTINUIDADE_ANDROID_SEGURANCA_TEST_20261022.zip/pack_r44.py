"""Deterministic ZIP CRAFT R44 continuation. Local TEST only."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZipInfo
import json,hashlib
base=Path(__file__).resolve().parent
out=base.parent/'CRAFT_R44_REVISOR_50_DECISOES_FRESCOR_RECEITAS_MESTRE_TEST_20261022.zip'
ignore={'MANIFEST-R44.json'}
paths=sorted((x for x in base.rglob('*') if x.is_file() and x.name not in ignore and '__pycache__' not in x.parts and x.suffix!='.pyc'),key=lambda v:v.relative_to(base).as_posix())
digests={p.relative_to(base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
man={'schema':'CRAFT_R44_TEST_MANIFEST_V1','classification':'MESTRE_SIDE_TEST_NO_PRODUCTION',
 'hash_algorithm':'SHA256','files':digests,'physical_recipes':29,'questions':50,'canonical_mutations':0,
 'physical_rc5_lots_approved':0,'notion_write':False,'party_release':False}
(base/'MANIFEST-R44.json').write_text(json.dumps(man,ensure_ascii=False,indent=2)+'\n')
with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths+[base/'MANIFEST-R44.json']:
  key=p.relative_to(base).as_posix();info=ZipInfo(key,date_time=(2026,10,22,0,0,0))
  info.compress_type=ZIP_DEFLATED;info.external_attr=0o644<<16
  z.writestr(info,p.read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
with ZipFile(out) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(digests)|{'MANIFEST-R44.json'}
 for k,v in digests.items():assert hashlib.sha256(z.read(k)).hexdigest()==v,k
print('PACK_R44',len(digests),'files + manifest',out,out.stat().st_size,'bytes',hashlib.sha256(out.read_bytes()).hexdigest())
