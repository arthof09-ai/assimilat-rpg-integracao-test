"""Reproducible CRAFT R44 TEST-only audit; never authorizes production."""
from pathlib import Path
import json,hashlib,subprocess,re,sys
root=Path(__file__).resolve().parent
M=json.loads((root/'MANIFEST-R44.json').read_text())
assert M['schema']=='CRAFT_R44_TEST_MANIFEST_V1'
for key,expected in M['files'].items():
 p=root/key
 assert p.is_file(),('MISSING',key)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,('BAD_SHA',key)
print('MANIFEST',len(M['files']),'/',len(M['files']),'PASS',flush=True)
js=sorted((root/'tests').glob('test_*.js'));count=0
for f in js:
 p=subprocess.run(['node',str(f)],cwd=root,capture_output=True,text=True,timeout=40)
 assert p.returncode==0,('JS_FAIL',str(f),p.stdout[-1000:],p.stderr[-1000:])
 m=re.search(r'(\d+)\s*/\s*(\d+)',p.stdout)
 assert m is not None and m[1]==m[2],('BAD_COUNTS',f.name,p.stdout)
 count+=int(m[1]);
assert len(js)==29 and count==1734,(len(js),count)
print('JS',count,'/1734 PASS',flush=True)
p=subprocess.run(['node','src/run.js'],cwd=root,capture_output=True,text=True,timeout=45)
assert p.returncode==0,(p.stdout,p.stderr)
p=subprocess.run(['node','src/verify_outputs.js'],cwd=root,capture_output=True,text=True,timeout=45)
assert p.returncode==0,(p.stdout,p.stderr)
assert hashlib.sha256((root/'outputs/QA_RESULT.json').read_bytes()).hexdigest()=='b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'
assert hashlib.sha256((root/'outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json').read_bytes()).hexdigest()=='509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8'
print('QA and preview receipt PASS; 2 projects HOLD_TEST_DESIGN',flush=True)
p=subprocess.run(['node','tests/fuzz_schema_r11.js'],cwd=root,capture_output=True,text=True,timeout=60)
assert p.returncode==0 and 'PASS 2000' in p.stdout,p.stdout[-1500:]+p.stderr[-500:]
print('FUZZ 2000/2000 PASS (digital only)',flush=True)
if '--full' in sys.argv:
 scripts=sorted((root/'tests').glob('test_browser_*.py'))+[root/'tests/test_mobile_browser_r9.py'];ct=0
 for f in scripts:
  p=subprocess.run([sys.executable,str(f)],cwd=root,capture_output=True,text=True,timeout=100)
  assert p.returncode==0,('CHROME_FAIL',str(f),p.stdout[-1000:],p.stderr[-1000:])
  m=re.search(r'(\d+)\s*/\s*(\d+)',p.stdout);assert m and m[1]==m[2],(f.name,p.stdout)
  ct+=int(m[1]);print('CHROME',f.name,m[1],flush=True)
 assert len(scripts)==21 and ct==725,(len(scripts),ct)
 print('CHROMIUM',ct,'/725 PASS; emulação, NOT physical Android',flush=True)
print('R44 TEST VERIFIED; CANONICAL/PHYSICAL PRODUCTION HOLD',flush=True)
