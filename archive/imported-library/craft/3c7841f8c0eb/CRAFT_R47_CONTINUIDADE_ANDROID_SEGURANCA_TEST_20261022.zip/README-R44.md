# CRAFT — R42–R44 / Continuidade da revisão Mestre-only (TEST)

Ambiente: MESTRE-SIDE, somente TEST, R53 revisor existente. **NAC-AUTO-01 permanece PROPOSTA** nesta execução, sem modificação do estatuto de normas canônicas. Nenhuma ficha/receita/item/estoque/Party/O Primeiro foi escrito.

## Melhorias efetivas

- **R42:** busca textual tolerante a acentos, prioridade P0/P1/P2/P3/insumo compartilhado, filtros de notas (sem notas/parciais/completas/incompletas), contador de 50 perguntas e foco na primeira pendência visível. Visualização **não** altera, oculta definitivamente ou perde notas; o arquivo exportado sempre inclui os 50 slots, independentemente de filtros.
- **R43:** roteiro JSON de revalidação para as 50 perguntas. Identifica classe de problema, próxima verificação, status de anotação, 29 menções históricas a Óleo de Vedação e os gates externos. **Nunca copia conteúdo das notas**; nota preenchida continua NÃO AUTENTICADA. Não é plano de execução automática nem patch de fichas.
- **R44:** leitura direta das 29 páginas de receita no Notion Mestre em três lotes nesta execução e comparação dos metadados com o levantamento R15. 29/29 carimbos de edição e pais registrados sem mudanças detectadas. A equivalência de timestamps **não demonstra igualdade dos corpos das páginas**. `src/r44_recipe_freshness.js` compara snapshots futuros e bloqueia mudanças de identidade/data/pai; **não acessa o Notion sozinho**.

## Estado do software

- Revisor único `REVISOR_LOCAL_ANDROID_R53_TEST.html`: 50 perguntas/22 grupos, 11 decisões antigas R31 e 72 campos de coleta R46 preservados. Sem chamada HTTP.
- `src/run.js`, `src/verify_outputs.js`, projetos `Sonda` e `Tônico`, recibos de QA e prévia: byte-idênticos aos hashes R41. Ambos em `HOLD_TEST_DESIGN`.
- 29 páginas físicas Mestre únicas; 21 divergências históricas, 8 sem divergência lexical no dossiê. Nenhuma é homologada RC5. 50 perguntas não autenticadas.
- IBX-38, IBX-116, R51 `NOVA` / exige ACK, sem fencing externo C19-021, writer/lease/epoch ou pai único REC-LIB. Atualização no Notion indisponível nesta conexão, somente read-only. Última sincronização documental de CRAFT no Notion demonstrada R13.

## Reprodução e segurança

`python replay_r44.py` confere manifesto, executa regressões JS, recibo original, 2.000 probes e comparador R44; `python replay_r44.py --full` também executa Chromium **simulado**. Requer Python, Node e Chromium. Nenhuma execução automatizada em smartphone físico foi certificada. Os `MANIFEST-R*.json` anteriores são registros históricos **não vigentes nesta versão**. A validação da distribuição R44 usa exclusivamente `MANIFEST-R44.json`.

**Proibido apresentar notas de Mestre à Party/O Primeiro.** Importações só alimentam interface local; minuta não autentica decisão. Campos de laudo R46 continuam vazios quando desconhecidos. Não criar segunda receita ou objeto canônico para substituir divergências.
