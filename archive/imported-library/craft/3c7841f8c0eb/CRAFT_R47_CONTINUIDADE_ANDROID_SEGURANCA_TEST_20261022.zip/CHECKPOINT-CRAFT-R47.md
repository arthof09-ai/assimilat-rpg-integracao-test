# CHECKPOINT — CRAFT R47 — 22/10/2026 — Mestre-only TEST

**Origem:** checkpoint R44 e pacote R44 com manifesto hash/CRC; R44 homologado apenas digitalmente. NAC-AUTO-01 permanece proposta.

## Delta R45–R47

- R45: painel de alterações locais não exportadas para R31 (11), R40 (50), R35/R46 (72); aviso `beforeunload` best-effort, sem armazenamento persistente; recriação R35 com confirmação de perda de dados; cancelar conserva conteúdo. Exportar representa solicitação de download sem verificação de custódia do Android.
- R46: comparador R44 torna UUID físico duplicado no baseline ou no atual condição HOLD; proveniência física/RC5 não inferida.
- R47: importação dos formulários R31/R40 com conflito local requer confirmação, CANCEL mantém notas, importação adulterada rejeitada antes de qualquer sobreposição. Nenhuma nota autoral ganhou autenticação.

## Corpus e status

29 páginas de receitas Mestre (21 divergências e 8 sem divergência lexical detectada), 50 perguntas sem respostas autenticadas, 3 nós materiais R46 (Sonda B3, Tônico B3, Tônico B4) sem medição/laudo verificado. Sonda/Tônico continuam `HOLD_TEST_DESIGN`. Nenhuma ficha física, estoque, sistema de PA, Party ou O Primeiro alterado.

## Gates canônicos

Na leitura de 22/10: IBX38 `NOVA/ACK __YES__`, IBX116 `NOVA/ACK __YES__`, R51 `NOVA/ACK __YES__`. C19-021 fencing/lease/epoch não comprovados, REC-LIB destino físico não homologado. Notion oferece apenas fetch/search. Última sincronização documental CRAFT comprovada é R13. R14–R47 em TEST/Biblioteca, não publicados como atos canônicos.

## Ponto de retomada exato

1. `python replay_r47.py` no ZIP de R47 e conferir `MANIFEST-R47.json`; opção `--full` para Chromium simulado.
2. Usar R47 no Android **Mestre-only**: preencher e exportar minutas; confirmar downloads e não confiar exclusivamente em aviso de fechamento.
3. Rechecar fontes Notion antes de qualquer decisão; se qualquer UUID/timestamp/pai mudar, HOLD e reauditoria; igualdade de carimbos não prova byte equality.
4. Receber 50 decisões autorais autenticadas e 3 laudos físicos R46; enquanto ausentes não corrigir material, processo nem receita por inferência.
5. Se e somente se os gates técnicos externos liberarem, tratar R51/REC-LIB com writer competente, fencing, NAC-PASS e readback; não abrir receita duplicada, não alterar Party/O Primeiro.
