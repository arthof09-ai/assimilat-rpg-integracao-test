"""Present 50 historical questions in same R53 private UI; never instantiate recipes/tickets."""
import json,pathlib,hashlib
p=pathlib.Path(__file__).parent
inputs=[('R30',p/'outputs/CRAFT_R30_PARECER_DECISOES_MESTRE_TEST.json'),('R36',p/'data/CRAFT_R37_9_PERGUNTAS_P1_RECEITAS_MESTRE_TEST.json'),('R38',p/'data/CRAFT_R38_3_PERGUNTAS_IDENTIDADE_MESTRE_TEST.json'),('R39',p/'data/r39_remaining_13_recipe_readback.json')]
normalized=[];evidence=[]
for origin,f in inputs:
 a=json.loads(f.read_text());evidence.append({'origin':origin,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'source_filename':f.name})
 for c in a['cases']:
  key=c['key'];key='MAT-01-ON' if key=='MAT-01' and origin=='R36' else key
  slots=[]
  for s in c.get('decision_slots',c.get('decisions',c.get('questions',[]))):
   slots.append({'slot_id':s.get('id',s.get('slot')),'bom_literal':s.get('bom_literal'),
     'process_literal':s.get('process_literal'), 'question':s.get('question'),
     'issue_class':s.get('issue_class','AUTHORITY_RECONCILIATION'),
     'author_note':None})
  normalized.append({'key':key,'original_source':origin,'physical_recipe_id':c.get('physical_recipe_id'),
      'source_url':c.get('source_url',c.get('source_url') or 'https://app.notion.com/p/'+c['physical_recipe_id']),
      'priority':c.get('priority',c.get('original_priority','UPSTREAM_MASTER_OIL')),
      'slots':slots})
assert len(normalized)==22,len(normalized)
assert len({x['key'] for x in normalized})==22
assert sum(len(x['slots']) for x in normalized)==50
assert len({(x['key'],s['slot_id']) for x in normalized for s in x['slots']})==50
assert len({x['physical_recipe_id'] for x in normalized})==22
assert sum(x['original_source']=='R39' for x in normalized)==13
assert sum(x['original_source']=='R36' for x in normalized)==3
assert sum(x['original_source']=='R38' for x in normalized)==2
assert sum(x['original_source']=='R30' for x in normalized)==4
assert all(x['source_url'].startswith('https://app.notion.com/p/') for x in normalized)
dossier={'schema':'CRAFT_R40_COMBINED_50_DECISIONS_MESTRE_TEST_V1','classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
'input_hashes':evidence,'denominators':{'recipe_issue_cases':21,'upstream_oil_item':1,'recipe_pages_without_lexical_issue':8,
 'total_cases_including_oil':22,'R30':11,'R36':9,'R38':3,'R39':27,'total_questions':50},
'cases':normalized,'all_notes_blank':True,
'no_authorship_authentication':True,'no_canonical_write':True,'no_rc5_approval':True,'no_magic_transfer_proof':True,
'no_player_release':True,'fencing_verified':False,'r51_single_parent_verified':False}
(p/'data/r40_50_author_notes_baseline.json').write_text(json.dumps(dossier,ensure_ascii=False,indent=2)+'\n')
print('R40 normalized',len(normalized),sum(len(x['slots']) for x in normalized))
