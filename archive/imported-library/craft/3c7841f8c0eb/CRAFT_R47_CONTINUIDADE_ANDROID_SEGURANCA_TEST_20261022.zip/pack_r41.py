"""Deterministic self-contained CRAFT R41 TEST distribution archive with SHA256 manifest."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZipInfo
import hashlib,json
base=Path(__file__).resolve().parent
out=base.parent/'CRAFT_R41_CONSOLIDACAO_29_RECEITAS_50_QUESTOES_TEST_20261022.zip'
file_paths=[]
for x in base.rglob('*'):
 if not x.is_file() or x.name=='MANIFEST-R41.json' or '__pycache__' in x.parts or x.suffix=='.pyc':continue
 file_paths.append(x)
file_paths=sorted(file_paths,key=lambda z:z.relative_to(base).as_posix())
digests={p.relative_to(base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in file_paths}
manifest={'schema':'CRAFT_R41_TEST_MANIFEST_V1','classification':'MESTRE_SIDE_TEST_NO_PRODUCTION',
 'hash_algorithm':'SHA256','files':digests,'physical_recipe_pages_approved':0,'canonical_mutations':0}
(base/'MANIFEST-R41.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=9) as zip:
 for p in file_paths+[base/'MANIFEST-R41.json']:
  key=p.relative_to(base).as_posix();zi=ZipInfo(key,date_time=(2026,10,22,0,0,0));zi.compress_type=ZIP_DEFLATED;zi.external_attr=0o644<<16
  zip.writestr(zi,p.read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
with ZipFile(out) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(digests)|{'MANIFEST-R41.json'}
 for k,v in digests.items():assert hashlib.sha256(z.read(k)).hexdigest()==v,k
print(out,out.stat().st_size,'bytes;',len(digests),'hashed files + manifest; sha256=',hashlib.sha256(out.read_bytes()).hexdigest())
