# PSV — CRAFT R11 / validação tipada e rejeição recuperável

**Operação original:** OP-ARQ-RIN-REC-01. **Trilha:** MESTRE-SIDE / LAB-TEST. **Antecessor:** CRAFT R10. **Trace:** CRAFT-SUCCESSION-R11-SCHEMA-20261021-001.

## ANTES (verificado)
R10 possui 197/197 verificações JS e mantém duas propostas em `HOLD_TEST_DESIGN`. Auditor R53/R10 possuía campos aninhados fracamente tipados; alguns valores JSON (por exemplo `activation` como objeto) geravam TypeError. No caminho BOM/processo ausentes, o recibo parcial podia provocar exceção ao agregar evidências. R10 já dispunha de proteção contra prévia residual, preservada.

## DEPOIS / execução
**Correção no validador existente, sem motor paralelo.** Tipagem de identidade e campos humanos; nós BOM, quantidade, unidade e consumo; etapas, status e entradas; objetos `proof`/`economy`; recusa explícita de BOM/processo vazios. Consolidação de rejeição passa a conservar `evidence=[]` e metadados mínimos. Nenhum dado de lore, rank, PA ou mecânica do RPG foi alterado.

**Testes:** coorte R53/R8/R9/R10 = 197/197; R11 = 141/141 (35 cenários adversariais + baseline): total 338/338 verificações JS. Robustez extra 2.000 entradas mutadas determinísticas PASS, sem contabilizar como testes unitários independentes. Regressão de UI antiga 15/15 PASS e R11 20/20 PASS em Chromium sistema 390×844 com HTML inline. Abertura `file://` e Android físico NÃO certificados. Saídas normais QA e prévia interna idênticas aos bytes de R10; ambos os projetos seguem `HOLD_TEST_DESIGN`.

## NAC-PASS proporcional
PASS apenas integridade local, regressão, compatibilidade funcional e testes de interface; **HOLD** autenticação externa das fontes, implantação material, transferência/retensão mágica, RC5/F5/P4, R46/hardware, C19-021, IBX-38 fencing, R51 destino. Party/O Primeiro, produtos, fichas, estoque, receitas, PA e normas: zero escrita. Não há writer/epoch/lease/ACK/GREEN adquirido.

**Próximo ponto:** retomar prova externa de fencing/efeito C19 e parent REC-LIB; se não houver evidência, manter F5 RED e avançar somente QA TEST ou avaliação material com dados reais do operador autorizado. Não refazer R48 ou os pacotes anteriores.
