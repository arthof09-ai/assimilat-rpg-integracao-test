# PSV CRAFT R28 — escopo TEST, 22/10/2026

**ANTES:** R25 pacote preservado e cold replay PASS; 683/683 JS, 461/461 Chromium inline, 2.000 fuzz separados, 2/2 propostas HOLD_TEST_DESIGN; Notion Mestre OP/LAB/Inbox CRAFT sincronizados somente até R13. IBX-38, IBX-116, R51 `NOVA` e ACK YES, R46 sem amostras.

**R26:** pedidos R46 por B3 Sonda, B3 e B4 Tônico com exatamente cinco requisitos por nó, IDs canônicos das propostas, precedentes rotulados como pista, ficha R46 completamente vazia, status não certificável; proteção de identidade contra importação alterada; UI/download aprovado 55/55 JS +51/51 Chromium inline.

**R27:** reutilização read-only do original DECISION_REGISTER.json SHA `6ea83f2b702f5624694db6e83378208827fc1e2a3a99f40e255e6f307137269e`, 21 decisões/20 pattern keys, 7 transversais, 0 aprovação; ordem P0/P1/P2/P3 no revisor offline, com exportação JSON, 23/23 JS +24/24 Chromium inline.

**R28:** verificação atual de 21/21 páginas Notion por UUID/parent/last_edited, sem mudanças de last-edited após 21/10/2026 no recorte; 161/161 assertions JS documentais, 8 receitas restantes fora desta leitura. Não se comprovou atualização de corpo inexistente nem RC5.

**DEPOIS:** suites totais 922/922 JS (17 suítes) e 536/536 UI Chromium inline (13 scripts) + 2000 fuzz informacionais. Teste R53 e recibo R13 normais byte-idênticos ao R25. 2/2 propostas HOLD_TEST_DESIGN, 0 medição física, 0 laudo validado, 0 magic transfer, 0 RC5, 0 material produzido, 0 Party/O Primeiro write, 0 alteração Notion original. R26/27/28 são evidências digitais, sem NAC-PASS material.

**GATES:** Notion só leitura na conexão; C19-021 UNKNOWN, IBX-38 fencing externo não atestado, R51 sem parent físico, H2/R46 físico pendente, P2/Óleo/energização pendentes, F5 RED, P4/PROD HOLD; nenhuma herança de writer/epoch/lease/ACK.

**NEXT:** gerar coleta de laboratório real nos 3 nós via R46; decidir P2 e MAT03/MAT06 com autoridade; sincronizar consolidação R14–R28 no Laboratório/OP/Inbox quando escrita permitida e fencing da produção comprovado — registros TEST/relato não liberam produção.
