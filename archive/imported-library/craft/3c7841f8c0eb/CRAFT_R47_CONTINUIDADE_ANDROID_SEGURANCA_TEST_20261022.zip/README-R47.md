# CRAFT R45–R47 — Continuidade Android e integridade das receitas (TEST, Mestre-only)

Implementação incremental **no revisor R53 existente**, sobre R44. Não há novo motor de receitas nem alteração canônica. NAC-AUTO-01 permanece PROPOSTA.

## Funcionalidades implementadas

- **R45** — status local de alterações nos 50 campos R40, 11 notas R31 e 72 campos de coleta R46. Antes de sair/recarregar, o navegador pode avisar que há alterações não exportadas (comportamento `beforeunload` depende do navegador). Destruição por `Recriar ficha vazia` no R35 exige confirmação explícita quando há relato preenchido; cancelar preserva os dados. Nenhum armazenamento automático, telemetria ou envio online; botão Baixar representa **pedido de download**, não recebimento comprovado no Android.
- **R46** — comparador `src/r44_recipe_freshness.js` atualizado: rejeita UUIDs de receita duplicados **também no baseline**, sem declarar ausência de drift. O comparador não escreve nem consulta Notion automaticamente; datas/pais idênticos não provam hash do corpo, RC5 ou identidade física.
- **R47** — os carregadores de minutas R31 e R40 solicitam aprovação antes de **substituir** conteúdo local preenchido. O cancelamento é não destrutivo e permite selecionar o mesmo arquivo novamente. A validação integral e antifalsificação do JSON acontece antes do aviso de substituição; importar não autentica decisão.

## Uso no Android

1. Abra o HTML offline no Chrome e mantenha-o **somente em área privada do Mestre**.
2. Preencha notas R40, R31 ou evidências R46, deixando desconhecidos sem resposta. Os textos são relatos, não decisão autenticada nem laudo.
3. Toque em **Salvar** na seção correspondente e **confirme a presença efetiva do arquivo na pasta Downloads**. Não dependa de aviso de aba fechando — muitos navegadores móveis não garantem que ele apareça.
4. Antes de importar outro arquivo ou recriar ficha, faça cópia privada. Cancele a confirmação se não tiver backup.
5. Para retomar, importe cada minuta na seção correta; qualquer conflito de dados preenchidos exige confirmação. `R46` tem triagem própria.

## Reproduzir

`python replay_r47.py` valida manifesto, 30 suítes JS, QA e recibo de saída, além de 2.000 sondagens. `python replay_r47.py --full` executa 23 suítes Chromium emulado por blocos; requer Node, Python e Chromium. Os testes simularam viewport móvel e **não certificam Chrome Android físico**.

## Cânone/gates

IBX38, IBX116 e R51 permaneciam NOVA/ACK YES no último readback (22/10/2026). Sem evidência de fencing C19-021, writer/lease/epoch ou pai REC-LIB físico homologado. Notion read-only para esta instância. Última escrita documental CRAFT comprovada no Notion: R13. Nenhuma receita, estoque, PA, Party, O Primeiro, RC5 ou produção alterados. 29 receitas físicas, 50 perguntas privadas não autenticadas, 3 nós R46 ainda sem laudos.
