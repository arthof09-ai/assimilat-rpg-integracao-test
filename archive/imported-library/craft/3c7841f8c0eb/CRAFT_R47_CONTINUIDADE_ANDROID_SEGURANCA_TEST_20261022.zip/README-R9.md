# CRAFT R9 — Importação segura do mesmo Auditor R53 (TEST / MESTRE)

Este pacote evolui R8 no MESMO validador (`src/validate.js`) e no MESMO aplicativo HTML offline (`build_mobile.py`), sem outro motor, receita, item ou regra.

- Rejeita `products` inexistente, vazio, não-array ou contendo valores que não são objetos; não retorna sucesso por lista vazia nem derruba renderização com exceção não tratada.
- Rejeita BOM com nó inválido, etapa nula e campo `input_node_ids` que não seja lista; mantém os bloqueios de origem, rank, economia, Party e fabrico do R53/R8.
- Importador Android/HTML recusa mais de 2 MiB, não troca o estado anterior ao ler um JSON inválido e mantém os projetos TEST prévios se a importação falhar.
- 
**Execução digital independente:** `node src/run.js` e `for f in tests/test_*.js; do node "$f"; done`. 99 regressões R53 +21 R8 +22 R9 = **142/142 asserções digitais PASS**, sete suítes Node. Além das 142 asserções JS, o ensaio de interface com **Chromium de sistema 144 (390×844)** via `tests/test_mobile_browser_r9.py` executou **15/15 verificações** de interação em uma página HTML injetada no navegador, incluindo importação maliciosa, recuperação, export e ausência de requisições HTTP. Não foi possível abrir `file://` pelo sandbox (bloqueio administrativo); isso NÃO demonstra abertura do arquivo no aparelho Android físico. Não confundir os dois E2E Chromium anteriores da bancada R6.

**Status:** Sonda e Tônico `HOLD_TEST_DESIGN`. Fontes do R53, receitas e BOM não mudaram. Sem escritura em Notion pelos binários, Party/O Primeiro, inventário ou estoque oficial. F5 P0 RED/C19-021 UNKNOWN, writer/fencing/RC5/P4 HOLD.
