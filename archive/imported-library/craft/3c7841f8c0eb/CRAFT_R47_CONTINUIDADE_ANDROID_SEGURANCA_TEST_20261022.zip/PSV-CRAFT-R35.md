# PSV CRAFT — R35 (22/10/2026)

**ANTES:** checkpoint R30 preservado, 1.059/1.059 JS, 563/563 Chromium; 21 divergências de receitas no dossiê R27; 11 questões R30 com resposta `null`; 3 nós R46 sem ensaio; Notion writer indisponível e C19/F5 RED.

**R31 TEST:** introduziu 11 campos privados no revisor local, exportação/reimportação de minuta e triagem fail-closed. O único conteúdo variável são respostas textuais com limites e estado `all_choices_blank` coerente; UUID, pergunta, rank/estado, fonte, Notion gate e autorizações são imutáveis. Nenhuma nota é autenticada nem aplicada. Testes novos 65 JS e 26 Chromium.

**R32 TEST:** mapa 11/11 de impacto, 3 ligações óleo→receitas, uma condicional MAT-03. Não resolve link, quantidade `Ex`, alias nem transferência mágica. Testes novos 84 JS e 16 Chromium.

**R33 TEST:** plano unificado derivado de R27/R30/R46, 21 questões em receitas (3 aprofundadas, 18 na fila), 11 perguntas autorais, 3 nós R46 e 8 receitas sem divergência lexical identificada — **não homologadas**. Testes 70 JS e 12 Chromium.

**R34 TEST:** reabriu Notion ENC-08, MAT-03, MAT-06, Óleo Mestre; os quatro carimbos são iguais aos do checkpoint R30. Registra sinais específicos (sal, link 1x, `Ex`, orvalho/essência). Não reabriu 29/29 páginas nem gerou prova de lote. Testes novos 36 JS.

**R35 TEST:** entrada de 72 campos para os mesmos 3 nós R46 no próprio HTML. Campos vazios continuam `null`; o relato exportado é processável no R29; URLs inseguras rejeitadas; mudança de proposta obriga recriação de ficha sem herança de evidências. Nenhum relatório atesta física ou magia. Testes novos 23 Chromium.

**TOTAL REGRESSÃO:** 23 suítes / **1.314/1.314 JS**; 18 suítes / **640/640 Chromium inline**; 2.000 entradas sintéticas informacionais. QA/preview CLI preservam hashes `b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541` e `509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8`; recibo de commit verificado. Chromium simulado ≠ Android físico. Verificar também manifesto R35 e replay em extração limpa antes de release documental.

**Bloqueios:** IBX-38, IBX-116, R51 sem ACK, C19-021 UNKNOWN, F5 RED, R51 parent físico não comprovado, 0 laudos materiais, Notion conexão somente fetch/search. Nenhum item, receita, estoque, PA, Party ou O Primeiro alterado. NAC-PASS apenas DIGITAL TEST proporcional; CANÔNICO/MATERIAL/PROD HOLD.
