# CRAFT R12 — proteção adicional da prévia Mestre/Player (TEST)

Continuidade **do mesmo motor** R53→R11, MESTRE-SIDE sem publicação. Sem writer/lease/epoch/ACK herdado e sem alteração a canônicos, Party/O Primeiro, PA, estoque ou receitas.

## Delta efetivo

- Em `src/validate.js`, conferir campos `player_view` como *strings limitadas e não vazias*; rejeitar arrays/objetos/números e cópia **literal** de `master_secrets` no nome/observação que seriam serializados no JSON de prévia. Identificadores de erro: `PLAYER_VIEW_SCHEMA`, `PLAYER_FIELD_TYPE_INVALID`, `PLAYER_SECRET_CROSSOVER`. A prova é **limitada a coincidência literal**; não se declara sanitização semântica de segredos ou revisão de revelação.
- A lógica R10 de bloqueio global (`REJECT_NO_PLAYER_PREVIEW`) é preservada: uma proposta contaminada bloqueia o arquivo de prévia do lote inteiro. A amostra limpa gera os dois arquivos de saída byte-idênticos ao R11.
- Em `build_mobile.py`, o título da observação mudou de “pública segura” para “Prévia hipotética TEST — NÃO PUBLICAR” no mesmo HTML offline. Sem servidores e sem publicação.

## Execução

- `node tests/test_disclosure_r12.js` — 44/44 asserções; 12 mutações adversariais e verificações de exportação fail-closed.
- Demais 9 suítes JS R53–R11: 338/338 verificações. Total: 382/382 JS; `node tests/fuzz_schema_r11.js` executa 2.000 vetores determinísticos informacionais separados.
- Chromium sistema com conteúdo inline na largura móvel (390×844): R9 15/15, R11 20/20, R12 16/16, total 51/51 verificações de interface. Não certifica abertura `file://` nem Android físico.
- `node src/run.js` em arquivo TEST original; comparar QA e prévia com R11 (SHA dos dois artefatos preservados).

## Limites

Fonte congelada exige `LIVE_SOURCE_RECHECK`. Os dois projetos continuam `HOLD_TEST_DESIGN`, 0 produção. Emissões com segredos parafraseados ou originados fora do campo `master_secrets` exigem auditoria humana. RC5/F5/P4/PRODUÇÃO, C19-021, IBX-38 e R51 permanecem HOLD; não usar o título de prévia como autorização de compartilhamento.
