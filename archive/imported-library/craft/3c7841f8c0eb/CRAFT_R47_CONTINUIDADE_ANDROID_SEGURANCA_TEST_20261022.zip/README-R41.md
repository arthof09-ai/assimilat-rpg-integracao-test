# CRAFT R41 — 29 receitas reconciliadas / 50 perguntas móveis (MESTRE-SIDE · TEST)

**Não é nova operação, motor, receita, regra nem publicação.** É continuação do revisor R53/R35 existente, respeitando PR-ITEM-02, PR-SC-01, PR-CRN-01, REC-LIB-01, REC-EXEC, R46 e NAC-CONT/NORM/PASS.

## O que mudou

- **R39:** releitura direta de 13 receitas no Notion Mestre e 27 perguntas detalhadas que antes constavam apenas da classificação resumida do dossiê R27. As 13 continuam HOLD; quatro perguntas são candidatas a variação textual, não a prova de equivalência.
- **R40:** integração **na mesma interface HTML offline** das 50 perguntas existentes: 11 R30, 9 R36, 3 R38 e 27 R39. São 22 grupos: **21 receitas** com pendências + a **ficha upstream do Óleo de Vedação**. Há 47 perguntas de receitas e 3 do óleo; nenhuma resposta/identidade/fonte é inventada. Entrada, exportação e reimportação de minutas ficam locais e TEST. O revisor R31 de 11 perguntas e os formulários R46 permanecem disponíveis e inalterados. `src/r40_author_review.js` verifica fonte/UUID/metadados e rejeita arquivos manipulados; não valida autoria, magia nem produção.
- **R41:** releitura direta das oito receitas que o levantamento antigo tratou como sem divergência lexical. Elas têm BOM e processo narrativo, mas carecem de homologação física RC5; ausência de erro lexical **NÃO é aprovação**. Criado um único mapa de 29 IDs físicos com status separados.

## Arquivos específicos novos

- `data/r39_remaining_13_recipe_readback.json`; `R39_13_RECEITAS_PENDENCIAS_MESTRE_TEST.csv`
- `data/r40_50_author_notes_baseline.json` (50 questões congeladas com hashes de origem)
- `src/r40_author_review.js`; `src/r40_browser_addon.js`; `REVISOR_LOCAL_ANDROID_R53_TEST.html`
- `data/r41_clean_eight_hold.json`, `data/r41_29_recipe_coverage.json`, `R41_MAPA_29_RECEITAS_READBACK_MESTRE_TEST.csv`
- `CHECKPOINT-CRAFT-R41.md`; `PSV-CRAFT-R41.md`; `GUIA_R41_MESTRE_ANDROID_TEST.md`

## Execução segura

No Chrome Android, abra `REVISOR_LOCAL_ANDROID_R53_TEST.html`, expanda **R40 — 50 perguntas históricas** e anote as suas respostas; baixe a **minuta não autenticada**. Ela não é publicada. Após importação, a triagem ignora o conteúdo das respostas e retorna só status de completude. Textos podem conter quebras de linha, mas não caracteres de controle perigosos. O HTML emula interface móvel em Chromium; não há certificação em Android físico.

Para reproduzir, em computador/ambiente com Node.js, Python e Chromium instalado: `python replay_r41.py` para manifesto, JS, recibos. `python replay_r41.py --full` inclui 19 testes de navegador, sujeitos a disponibilidade de Chromium. O arquivo `MANIFEST-R41.json` certifica todos os arquivos da distribuição, exceto a si próprio.

**NUNCA enviar o pacote Mestre-side, as respostas ou a matriz de dependências à Party/O Primeiro.** Não há autorização de gravação canônica, decisão oficial ou lote físico neste pacote.
