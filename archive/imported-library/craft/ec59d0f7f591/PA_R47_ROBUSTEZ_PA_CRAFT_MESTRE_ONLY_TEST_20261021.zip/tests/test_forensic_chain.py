import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from forensic_chain import audit
class TestForensicChain(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=audit()
 def test_01_all_original(self):self.assertEqual(self.r['n_original'],26)
 def test_02_all_masked(self):self.assertEqual(self.r['n_masked'],26)
 def test_03_peer_exact(self):self.assertEqual(self.r['n_peer'],12)
 def test_04_12_template(self):self.assertEqual(self.r['n_template_csv'],12)
 def test_05_nothing_mismatched(self):self.assertEqual(self.r['wrong_sha_or_dimensions'],[])
 def test_06_redaction_inside_is_significant(self):self.assertGreater(self.r['jpeg_inside_redaction_mean_abs_error_avg'],15)
 def test_07_nonredacted_area_nearly_same(self):self.assertLess(self.r['jpeg_outside_redaction_mean_abs_error_avg'],1.0)
 def test_08_sha_zip_matches_R46(self):self.assertEqual(self.r['source_zip_sha256'],'e6b1d8e209561df3c5d784bf12fe6ee4201c34ce20aa69a49e223a0ea55045c3')
 def test_09_didnt_use_rank_oracle(self):self.assertFalse(self.r['peer_ranks_seen_in_this_audit'])
if __name__=='__main__':unittest.main()
