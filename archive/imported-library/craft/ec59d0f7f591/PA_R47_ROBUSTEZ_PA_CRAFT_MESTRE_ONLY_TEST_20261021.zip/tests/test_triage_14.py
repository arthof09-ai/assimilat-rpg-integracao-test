import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from triage_14 import build_triage,audit_subeffects
from portability_v2 import BASE
import json

class TestTriage(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.t=build_triage();cls.a=audit_subeffects()
 def test_01_exact_fourteen(self):self.assertEqual(self.t['n'],14)
 def test_02_not_peer_twelfth(self):
  ids={r['case_id'] for r in json.loads((BASE/'R46_12_HIGH_PRIORITY_DISAGREEMENTS_MESTRE_ONLY.json').read_text())}
  self.assertTrue(all(r['case_id'] not in ids for r in self.t['queue']))
 def test_03_all_unranked(self):self.assertTrue(all(r['provisional_rank'] is None for r in self.t['queue']))
 def test_04_26_components(self):self.assertEqual(self.a['n_abilities'],26)
 def test_05_67_components(self):self.assertEqual(self.a['n_subeffects'],67)
 def test_06_component_ids_unique(self):self.assertTrue(self.a['component_unique_ids'])
 def test_07_component_parentage(self):self.assertFalse(self.a['bad_component_parentage'])
 def test_08_no_component_re_canon(self):self.assertTrue(self.a['all_RE_not_adjudicated'])
 def test_09_no_blind_oracle(self):self.assertTrue(all('legacy' not in str(r).lower() for r in self.t['queue']))
 def test_10_all_have_scientific_gap(self):self.assertTrue(all(len(r['gaps'])>=3 for r in self.t['queue']))
 def test_11_source_urls_not_guesses(self):self.assertTrue(all(x.startswith('https://app.notion.com/p/') for x in self.t['ground_sources']))
 def test_12_priority_stable(self):self.assertEqual([x['triage_priority'] for x in self.t['queue']],sorted((x['triage_priority'] for x in self.t['queue']),reverse=True))
 def test_13_no_official_writes(self):self.assertEqual(self.t['n_official_rank_changes'],0)
 def test_14_no_missing_cases(self):self.assertTrue(self.a['case_denominator_ok'])
if __name__=='__main__':unittest.main()
