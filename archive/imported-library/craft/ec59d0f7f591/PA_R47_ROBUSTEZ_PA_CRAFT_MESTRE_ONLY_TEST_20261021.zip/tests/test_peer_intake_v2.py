import unittest,zipfile,hashlib,io,csv,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from peer_intake_v2 import *
from compare_sealed import postfreeze_agreement
TMP=Path(__file__).resolve().parents[1]/'source/PEER_TEMPLATE_12_SEM_GABARITO.zip'
A='https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'
B='https://app.notion.com/p/b06c2b324ede8279a0f4014c14125a98'
C='https://app.notion.com/p/3edc2b324ede81b696b0d75191b7a5ec'

class TestPeerIntake(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.expected=load_peer_template(TMP)
  with zipfile.ZipFile(TMP) as z:
   cls.blank=read_csv_checked(z.read('peer_review_blank.csv'))
 @classmethod
 def fixture(cls,rank='Ouro'):
  rows=[]
  for r in cls.blank:
   rr={**r,'proposed_RE':rank,'mechanical_rationale':'Analisei visualmente o alcance e a duração do efeito; os valores estrangeiros foram preservados e existem incertezas sobre a aplicação em combate.',
       'limitations':'Este efeito exige comparadores de fontes com mecanismos correspondentes. Não há aprovação formal.',
       'system_comparator_url':A,'live_comparator_url':B,'family_comparator_url':C,
       'reviewer_attestation':'YES','independent_oracle_not_opened':'YES'}
   rows.append(rr)
  return rows
 def test_01_template_exact(self):self.assertEqual(len(self.expected),12)
 def test_02_all_valid_form(self):self.assertEqual(assess_rows(self.fixture(),self.expected)['batch_intake'],'FORM_COMPLETE_NOT_SCIENTIFICALLY_VALIDATED')
 def test_03_missing_row(self):
  r=assess_rows(self.fixture()[:-1],self.expected);self.assertEqual(r['batch_intake'],'REJECT_OR_HOLD');self.assertEqual(len(r['missing']),1)
 def test_04_duplicate_row(self):
  rr=self.fixture();rr[0]=rr[1].copy();r=assess_rows(rr,self.expected);self.assertEqual(r['batch_intake'],'REJECT_OR_HOLD');self.assertEqual(len(r['duplicate']),1)
 def test_05_extra_row(self):
  rr=self.fixture();rr.append({**rr[0],'case_id':'FAKE'});r=assess_rows(rr,self.expected);self.assertEqual(r['batch_intake'],'REJECT_OR_HOLD')
 def test_06_bad_image(self):
  rr=self.fixture();rr[0]['image_sha256']='0'*64;self.assertIn('MASKED_IMAGE_SHA_MISMATCH',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_07_insufficient_with_empty_comparators(self):
  rr=self.fixture('INSUFICIENTE'); rr[0].update({k:'' for k in ROLES});r=assess_rows(rr,self.expected);self.assertNotIn('NO_SOURCES_FOR_PROPOSED_RANK',r['rows'][0]['reasons']);self.assertEqual(r['rows'][0]['status'],'INSUFFICIENT_DOCUMENTED_PENDING')
 def test_08_empty_comparators_with_rank_cannot_pass(self):
  rr=self.fixture();rr[0].update({k:'' for k in ROLES});self.assertIn('NO_SOURCES_FOR_PROPOSED_RANK',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_09_duplicate_sources_not_two_independent(self):
  rr=self.fixture();rr[0]['family_comparator_url']=A+'?pvs=204';self.assertIn('COMPARATOR_SOURCE_DUPLICATE',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_10_hyphen_duplicate(self):
  self.assertEqual(notion_uuid(A),notion_uuid('https://www.notion.so/3eec2b32-4ede-81ea-8920-c52473ecc3ab'))
 def test_11_bad_host_rejected(self):
  rr=self.fixture();rr[0]['system_comparator_url']='https://app.notion.com.evil.org/p/3eec2b324ede81ea8920c52473ecc3ab';self.assertIn('BAD_NOTION_COMPARATOR_URL',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_12_url_nonid_rejected(self):self.assertIsNone(notion_uuid('https://app.notion.com/workspace'))
 def test_13_unicode_rank_wrong(self):
  rr=self.fixture();rr[0]['proposed_RE']='Ouro superior';self.assertIn('INVALID_RE',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_14_no_attestation(self):
  rr=self.fixture();rr[0]['reviewer_attestation']='NO';self.assertIn('NO_SELF_ATTESTATION',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_15_false_independence(self):
  rr=self.fixture();rr[0]['independent_oracle_not_opened']='NO';self.assertIn('ORACLE_EXPOSURE_UNCLEAR',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_16_no_canon(self):
  rr=self.fixture();r=assess_rows(rr,self.expected);self.assertEqual(r['automatically_canonized'],0);self.assertIsNone(r['scientific_accuracy']);self.assertFalse(r['rows'][0]['three_equivalent_comparators_verified'])
 def test_17_insufficient_empty_limitation_reject(self):
  rr=self.fixture('INSUFICIENTE');rr[0]['limitations']='incerto';self.assertIn('INSUFFICIENT_REQUIRES_EXPLICIT_GAP',assess_rows(rr,self.expected)['rows'][0]['reasons'])
 def test_18_csv_roundtrip(self):
  r=self.fixture();b=io.StringIO();w=csv.DictWriter(b,fieldnames=COLS);w.writeheader();w.writerows(r);p=read_csv_checked(b.getvalue().encode());self.assertEqual(p,r)
 def test_19_missing_column(self):
  with self.assertRaises(IntegrityError):read_csv_checked('case_id\nA')
 def test_20_duplicate_columns(self):
  with self.assertRaises(IntegrityError):read_csv_checked('case_id,case_id\nA,A')
 def test_21_bad_legacy_column(self):
  with self.assertRaises(IntegrityError):read_csv_checked(','.join(COLS)+',legacy_rank\n'+','.join('' for _ in range(len(COLS)+1)))
 def test_22_bad_legacy_prediction(self):
  with self.assertRaises(IntegrityError):read_csv_checked(','.join(COLS)+',r45_prediction\n'+','.join('' for _ in range(len(COLS)+1)))
 def test_23_oversize(self):
  with self.assertRaises(IntegrityError):read_csv_checked('a'*(4_000_001))
 def test_24_empty(self):
  with self.assertRaises(IntegrityError):read_csv_checked('')
 def test_25_invalid_utf(self):
  with self.assertRaises(UnicodeDecodeError):read_csv_checked(b'\xff\xfe')
 def test_26_zip_safe(self):
  with zipfile.ZipFile(TMP) as z:data=Path(TMP).read_bytes()
  self.assertEqual(len(verified_zip_entries(data)),15)
 def test_27_zip_traversal(self):
  with io.BytesIO() as b:
   with zipfile.ZipFile(b,'w') as z:z.writestr('../evil','x')
   with self.assertRaises(IntegrityError):verified_zip_entries(b.getvalue())
 def test_28_zip_duplicate_name(self):
  with io.BytesIO() as b:
   with zipfile.ZipFile(b,'w') as z:
    z.writestr('same.txt','a');z.writestr('same.txt','b')
   with self.assertRaises(IntegrityError):verified_zip_entries(b.getvalue())
 def test_29_zip_bomb_guard(self):
  with io.BytesIO() as b:
   with zipfile.ZipFile(b,'w') as z:z.writestr('large','x'*10_000)
   with self.assertRaises(IntegrityError):verified_zip_entries(b.getvalue(),max_expanded=10)
 def test_30_compare_no_accuracy(self):
  r=postfreeze_agreement({'C':'Prata','B':'INSUFICIENTE'},{'C':'Prata','B':'Ouro'});self.assertEqual(r['counts']['matches'],1);self.assertEqual(r['counts']['abstentions'],1);self.assertEqual(r['metric'],'AGREEMENT_BETWEEN_TWO_PROVISIONAL_ASSESSORS_NOT_ACCURACY')
 def test_31_compare_no_fake_n(self):
  r=postfreeze_agreement({'C':'Prata'},{'C':'Prata','A':'Ouro'});self.assertEqual(r['shared_cases'],1)
 def test_32_compare_distance(self):
  r=postfreeze_agreement({'C':'Lendário'},{'C':'Bronze'});self.assertEqual(r['rows'][0]['rank_distance'],4)
 def test_33_compare_invalid(self):
  with self.assertRaises(ValueError):postfreeze_agreement({'C':'Superlenda'},{'C':'Prata'})
 def test_34_compare_all_abstain(self):
  r=postfreeze_agreement({'C':'INSUFICIENTE'},{'C':'Prata'});self.assertIsNone(r['agreement_rate'])
 def test_35_url_u_source_attestation_only(self):
  r=assess_rows(self.fixture(),self.expected);self.assertFalse(r['fully_verified_peer_independence'])

if __name__=='__main__':unittest.main(verbosity=2)
