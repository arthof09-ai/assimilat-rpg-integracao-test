import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from craft_evidence_v2 import *

def make_data():
 out=[]
 for k,(a,b,c) in ARMS.items():
  for rep in range(2):
   out.append(dict(arm=k,source_present=a,p2_installed=b,own_spell_installed=c,
                   evidence_origin='PHYSICAL_WITNESSED_EVENT', observation_value=(10*a+3*b+5*c),
                   witness_id='witness'+str(rep),operator_id='operator1',time_recorded='2026-10-21T11:00:00Z',
                   traceable_lot_id='lot_p2',source_object_id='source1',test_item_id='item1',evidence_sha256='a'*64))
 return out

class TestCraft(unittest.TestCase):
 def test_01_empty_hold(self):self.assertEqual(test_preflight([])['admissibility'],'HOLD_NO_APPLICATION')
 def test_02_synthetic_hold(self):
  data=make_data();data[0]['evidence_origin']='SYNTHETIC';self.assertIn('NO_PHYSICAL_WITNESS_EVIDENCE',test_preflight(data)['blockers'])
 def test_03_synthetic_no_effect(self):
  data=make_data();data[0]['evidence_origin']='SYNTHETIC';self.assertIsNone(pre_registered_contrasts(data)['contrasts'])
 def test_04_nonexistent_lot_hold(self):
  data=make_data();data[0]['traceable_lot_id']='';self.assertIn('MISSING_TRACEABLE_LOT_ID',test_preflight(data)['blockers'])
 def test_05_observation_quantity_hold(self):
  data=make_data()[:-1];self.assertIn('ARM_I3_NEEDS_AT_LEAST_TWO_OBSERVATIONS',test_preflight(data)['blockers'])
 def test_06_one_witness_hold(self):
  data=make_data()
  for x in data:x['witness_id']='one'
  self.assertIn('TWO_DISTINCT_WITNESSES_REQUIRED',test_preflight(data)['blockers'])
 def test_07_arm_factor_tamper_hold(self):
  data=make_data();data[0]['source_present']=True;self.assertIn('ARM_FACTOR_MISMATCH',test_preflight(data)['blockers'])
 def test_08_bad_hash_hold(self):
  data=make_data();data[0]['evidence_sha256']='xx';self.assertIn('BAD_EVIDENCE_HASH',test_preflight(data)['blockers'])
 def test_09_nonnumeric_hold(self):
  data=make_data();data[0]['observation_value']='LIGHT';self.assertIn('NONNUMERIC_OBSERVATION',test_preflight(data)['blockers'])
 def test_10_all_compliant_form_not_proven(self):
  res=test_preflight(make_data());self.assertEqual(res['admissibility'],'FORM_COMPLETE_EXTERNAL_EVIDENCE_VERIFICATION_REQUIRED');self.assertFalse(res['item_own_magic_proven'])
 def test_11_contrasts_no_canon(self):
  res=pre_registered_contrasts(make_data());self.assertAlmostEqual(res['contrasts']['incremental_P2_on_source'],3);self.assertFalse(res['claimed_magic_installed'])
 def test_12_source_only_does_not_create_item_spell(self):
  res=pre_registered_contrasts(make_data());self.assertAlmostEqual(res['contrasts']['natural_source_effect'],10);self.assertFalse(res['claimed_magic_installed'])
 def test_13_costs_unknown(self):
  res=pa_incidence_policy();self.assertIsNone(res['A_natural_source_carried']['pa_user_per_day']);self.assertFalse(res['inventory_consumed'])
 def test_14_scenario_separate(self):self.assertEqual(pa_incidence_policy()['prospective_v13_cost_only']['two_uses'],26)
 def test_15_no_written_p2(self):self.assertFalse(test_preflight(make_data())['notion_write_executed'])
 def test_16_outside_arm(self):
  data=make_data();data[0]['arm']='X1';self.assertIn('UNKNOWN_ARM',test_preflight(data)['blockers'])
 def test_17_missing_field(self):
  data=make_data();del data[0]['operator_id'];self.assertIn('REQUIRED_FIELDS_MISSING',test_preflight(data)['blockers'])
 def test_18_no_origin(self):
  data=make_data();data[0]['evidence_origin']='DOCUMENT_ONLY';self.assertEqual(test_preflight(data)['admissibility'],'HOLD_NO_APPLICATION')
if __name__=='__main__':unittest.main()
