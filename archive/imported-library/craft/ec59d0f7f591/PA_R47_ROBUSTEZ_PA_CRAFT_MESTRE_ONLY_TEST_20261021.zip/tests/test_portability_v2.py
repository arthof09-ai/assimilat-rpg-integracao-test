import unittest,copy,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from portability_v2 import *

class TestPortability(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.cards,cls.amended=build_corrected_corpus();cls.out=build_portability_gates(cls.cards)
 def test_01_amended_one(self):self.assertEqual(self.amended,['TEC-E3532F6A98AC'])
 def test_02_R46_corrected_action_propagated(self):
  r=next(r for r in self.out if r['case_id']=='TEC-E3532F6A98AC');self.assertEqual(r['source_activation'],'ação')
 def test_03_R46_corrected_native_not_reaction(self):
  r=next(r for r in self.out if r['case_id']=='TEC-E3532F6A98AC');self.assertEqual(r['native_action_candidate_test_only'],'Ação Padrão')
 def test_04_old_R46_was_stale(self):
  old=json.loads((BASE/'R46_26_NATIVE_ADAPTATION_GATE.json').read_text()); delta=audit_old_pipeline(self.out,old);self.assertEqual(len(delta),1);self.assertEqual(delta[0]['old_native_candidate'],'Ação Padrão')
 def test_05_no_modified_source(self):self.assertTrue(all(not r['notion_source_modified'] for r in self.out))
 def test_06_all_unknown_cost(self):self.assertEqual(sum(r['native_pa_cost'] is None for r in self.out),26)
 def test_07_all_not_playable(self):self.assertTrue(all(not r['native_playable'] for r in self.out))
 def test_08_cast_bonus_count(self):self.assertEqual(report()['source_cast_bonus_count'],6)
 def test_09_secondary_action_command_detected(self):
  r=next(r for r in self.out if r['case_id']=='TEC-988589FB9716');self.assertTrue(r['source_secondary_bonus_action'])
 def test_10_secondary_action_issues(self):
  r=next(r for r in self.out if r['case_id']=='TEC-988589FB9716');self.assertIn('FOREIGN_SECONDARY_BONUS_ACTION_PENDING',r['issues'])
 def test_11_concentration_count(self):self.assertEqual(report()['concentration_count'],12)
 def test_12_12_saves(self):self.assertEqual(report()['issue_counts']['FOREIGN_SAVING_THROW_NEEDS_NATIVE_CONTRACT'],12)
 def test_13_all_original_hashes(self):self.assertTrue(all(len(r['original_image_sha256'])==64 for r in self.out))
 def test_14_26_unique_cases(self):self.assertEqual(len(set(r['case_id'] for r in self.out)),26)
 def test_15_impact_only_corrected(self):self.assertEqual(sum(bool(r['corrections']) for r in self.out),1)
 def test_16_no_ranks(self):self.assertTrue(all(r['native_re'] is None for r in self.out))
 def test_17_bad_prestate_rejected(self):
  import tempfile
  with tempfile.TemporaryDirectory() as tmp:
   a=json.loads((BASE/'R46_CORRECOES_VISUAIS_SOBRE_R45.json').read_text());a[0]['previous_R45_value']='ação';p=Path(tmp)/'fix.json';p.write_text(json.dumps(a))
   with self.assertRaises(SourceConflict):build_corrected_corpus(amend_file=p)
 def test_18_bad_case_rejected(self):
  import tempfile
  with tempfile.TemporaryDirectory() as tmp:
   a=json.loads((BASE/'R46_CORRECOES_VISUAIS_SOBRE_R45.json').read_text());a[0]['case_id']='FAKE';p=Path(tmp)/'fix.json';p.write_text(json.dumps(a))
   with self.assertRaises(SourceConflict):build_corrected_corpus(amend_file=p)
 def test_19_original_input_not_mutated(self):
  data=json.loads((BASE/'REFERENCE_R45_INPUT/CORPUS_MECANICO_MANUAL_CEGO.json').read_text())
  x=next(x for x in data['cases'] if x['case_id']=='TEC-E3532F6A98AC');self.assertEqual(x['source_activation'],'reação')
 def test_20_facts_no_ability_invention(self):self.assertTrue(all(r['native_action_authorized'] is None for r in self.out))
if __name__=='__main__':unittest.main()
