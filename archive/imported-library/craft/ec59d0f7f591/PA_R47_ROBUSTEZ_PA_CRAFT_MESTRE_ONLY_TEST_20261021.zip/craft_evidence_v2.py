"""P2/H2 controlled-test admissions; planning and audit only (NO real simulation == magic)."""
from __future__ import annotations
from collections import Counter

ARMS={
 'N0':(False,False,False), # no natural source, no seal, no own spell
 'S1':(True, False,False), # source only
 'S2':(True, True, False), # source + P2
 'P0':(False,True, False), # P2 alone
 'I0':(False,False,True), # item-owned magic alone
 'I1':(True,False,True),  # natural source + item spell
 'I2':(False,True, True), # P2 + item spell
 'I3':(True,True, True)   # source + P2 + item spell
}
REQUIRED=('arm','source_present','p2_installed','own_spell_installed','evidence_origin',
          'observation_value','witness_id','operator_id','time_recorded',
          'traceable_lot_id','source_object_id','test_item_id','evidence_sha256')

class ExperimentQualityError(ValueError): pass


def test_preflight(observations):
    """No fabricated scientific proof or item production status.

    Every reported test arm must correspond to its declared factors. Statistical
    inference remains a separate task even with an admissible real experiment.
    """
    faults=[]; seen=Counter()
    for x in observations:
        arm=x.get('arm');seen[arm]+=1
        if arm not in ARMS:faults.append('UNKNOWN_ARM');continue
        if any(k not in x for k in REQUIRED):faults.append('REQUIRED_FIELDS_MISSING')
        if tuple(x.get(k) for k in ('source_present','p2_installed','own_spell_installed'))!=ARMS[arm]:
            faults.append('ARM_FACTOR_MISMATCH')
        if x.get('evidence_origin')!='PHYSICAL_WITNESSED_EVENT':faults.append('NO_PHYSICAL_WITNESS_EVIDENCE')
        if type(x.get('observation_value')) not in (int,float):faults.append('NONNUMERIC_OBSERVATION')
        for s in ['witness_id','operator_id','time_recorded','traceable_lot_id','source_object_id','test_item_id','evidence_sha256']:
            if not isinstance(x.get(s),str) or not x.get(s).strip():faults.append('MISSING_'+s.upper())
        h=x.get('evidence_sha256','')
        if not isinstance(h,str) or len(h)!=64 or any(c not in '0123456789abcdef' for c in h.lower()):faults.append('BAD_EVIDENCE_HASH')
    for arm in ARMS:
        if seen[arm]<2:faults.append('ARM_'+arm+'_NEEDS_AT_LEAST_TWO_OBSERVATIONS')
    if len({x.get('witness_id') for x in observations if x.get('witness_id')})<2:
        faults.append('TWO_DISTINCT_WITNESSES_REQUIRED')
    if len({x.get('operator_id') for x in observations if x.get('operator_id')})<1:
        faults.append('OPERATOR_NOT_RECORDED')
    faults=sorted(set(faults))
    return {'admissibility':'FORM_COMPLETE_EXTERNAL_EVIDENCE_VERIFICATION_REQUIRED' if not faults else 'HOLD_NO_APPLICATION',
            'blockers':faults,'n_observations':len(observations),
            'natural_source_proven':False,'P2_causal_effect_proven':False,
            'item_own_magic_proven':False,'installed_magic_status':'NOT_CLAIMED',
            'PA_debited':False,'RC5_produced':False,'notion_write_executed':False}


def pre_registered_contrasts(observations):
    check=test_preflight(observations)
    if check['admissibility']!='FORM_COMPLETE_EXTERNAL_EVIDENCE_VERIFICATION_REQUIRED':
        return {'admissibility':check['admissibility'],'contrasts':None,'reason':'unverified_or_incomplete_evidence'}
    def mean_arm(k):
        a=[float(x['observation_value']) for x in observations if x['arm']==k]
        return sum(a)/len(a)
    v={a:mean_arm(a) for a in ARMS}
    return {'admissibility':'DESCRIPTIVE_VALUES_ONLY_WITHOUT_PHYSICAL_ATTESTATION',
            'contrasts':{'natural_source_effect':v['S1']-v['N0'],
                         'incremental_P2_on_source':v['S2']-v['S1'],
                         'own_spell_without_source':v['I0']-v['N0'],
                         'P2_only_without_source':v['P0']-v['N0'],
                         'interaction_source_P2':(v['S2']-v['S1'])-(v['P0']-v['N0']),
                         'own_spell_with_P2_no_source':v['I2']-v['P0']},
            'claimed_magic_installed':False,'authorized_human_adjudication':False,'physical_evidence_authenticated':False}


def pa_incidence_policy():
    return {'A_natural_source_carried':{'pa_user_per_day':None,'pa_user_per_use':None,'reason':'no native own spell demonstrated'},
            'B_P2_real_vedacao':{'pa_user_per_day':None,'pa_user_per_use':None,'reason':'no material P2 installation observed'},
            'C_own_magic':{'pa_user_per_day':None,'pa_user_per_use':None,'reason':'own spell not installed'},
            'prospective_v13_cost_only':{'daily':12,'active_use':7,'two_uses':26,
                                         'status':'HYPOTHETICAL_E3_TEST_NOT_CHARGED'},
            'authoritative_cost_engine_R26_R27_modified':False,
            'inventory_consumed':False}
