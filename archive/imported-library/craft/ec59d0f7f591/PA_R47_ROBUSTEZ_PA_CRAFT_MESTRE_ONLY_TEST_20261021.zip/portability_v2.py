"""Read-only foreign->Assimilação bridge with explicit correction provenance.

No native spell, PA cost, rank or inventory is created by this module.
"""
from __future__ import annotations
import json,re,hashlib
from collections import Counter
from pathlib import Path
BASE=Path(__file__).resolve().parent/'input'

class SourceConflict(ValueError): pass


def norm_text(x):return (x or '').strip().casefold()


def build_corrected_corpus(base_file=None,amend_file=None):
    base_file=Path(base_file or BASE/'REFERENCE_R45_INPUT/CORPUS_MECANICO_MANUAL_CEGO.json')
    amend_file=Path(amend_file or BASE/'R46_CORRECOES_VISUAIS_SOBRE_R45.json')
    source=json.loads(base_file.read_text(encoding='utf8'))
    cards=source['cases']
    byid={x['case_id']:x for x in cards}
    if len(byid)!=26:raise SourceConflict('denominator or duplicate source ids')
    amended=[]
    for a in json.loads(amend_file.read_text(encoding='utf8')):
        case=a['case_id'];field=a['field'];rec=byid.get(case)
        if rec is None:raise SourceConflict('amendment refers to missing case')
        if rec.get(field)!=a['previous_R45_value']:raise SourceConflict('R45 prestate mismatch')
        if not a['visually_verified_value'] or not a['evidence']:raise SourceConflict('missing evidence for amendment')
        rec[field]=a['visually_verified_value']
        rec.setdefault('source_correction_provenance',[]).append({k:a[k] for k in ('field','previous_R45_value','visually_verified_value','evidence')})
        amended.append(case)
    return cards,amended


def build_portability_gates(cards):
    out=[]
    for card in cards:
        c=card['case_id'];act=norm_text(card.get('source_activation'))
        facts=norm_text(card.get('observed_mechanic_facts'))
        duration=norm_text(card.get('source_duration'))
        rang=norm_text(card.get('source_range'))
        sec=('ação bônus' in facts or 'ação bonus' in facts)
        issues=['PA_COST_UNKNOWN_NOT_ZERO','NATIVE_RE_NOT_ADJUDICATED']
        if 'bônus' in act or 'bonus' in act:issues.append('FOREIGN_CAST_BONUS_ACTION_PENDING')
        if sec:issues.append('FOREIGN_SECONDARY_BONUS_ACTION_PENDING')
        if '(c)' in duration or 'concentração' in duration:issues.append('FOREIGN_CONCENTRATION_PENDING')
        if card.get('source_save'):issues.append('FOREIGN_SAVING_THROW_NEEDS_NATIVE_CONTRACT')
        if 'pés' in rang or 'feet' in rang or 'pés' in facts or 'feet' in facts:issues.append('FOREIGN_RANGE_UNIT_NOT_MECHANICAL_ADJUDICATION')
        if ('nível' in facts or 'progressão' in facts) and any(k in facts for k in ('origem','estrangeiro','progressão')):
            issues.append('FOREIGN_LEVEL_SCALING_PENDING')
        if card.get('source_correction_provenance'):issues.append('SOURCE_VISUAL_AMENDMENT_AUDIT')
        out.append({'case_id':c,'original_image_sha256':card['explicit_source_image_sha256'],
                    'source_activation':card.get('source_activation'),
                    'source_secondary_bonus_action':sec,
                    'corrections':card.get('source_correction_provenance',[]),
                    'native_action_candidate_test_only':('Ação Padrão' if act=='ação' else None),
                    'native_action_authorized':None,
                    'native_re':None,'native_pa_cost':None,'native_pa_debit':False,
                    'source_duration':card.get('source_duration'),
                    'issues':sorted(set(issues)), 'native_playable':False,
                    'notion_source_modified':False})
    if len(out)!=26 or len({x['case_id'] for x in out})!=26:raise SourceConflict('invalid output denominator')
    return out


def audit_old_pipeline(corrected, old_rows):
    old={r['case_id']:r for r in old_rows};new={r['case_id']:r for r in corrected}
    if set(new)!=set(old):raise SourceConflict('R46 denominator drift')
    impacted=[]
    for id in new:
        n=new[id];o=old[id]
        if n['corrections']:
            impacted.append({'case_id':id,
               'old_native_candidate':o['native_action_candidate'],
               'new_native_candidate':n['native_action_candidate_test_only'],
               'cause':'R45 embedded source remained stale; R46 output already reflected correction; R47 rebuilds source with explicit provenance'})
    return impacted


def report():
    cards,amended=build_corrected_corpus()
    new=build_portability_gates(cards)
    old=json.loads((BASE/'R46_26_NATIVE_ADAPTATION_GATE.json').read_text())
    affected=audit_old_pipeline(new,old)
    counts=Counter(issue for row in new for issue in row['issues'])
    return {'scope':'TEST_ONLY_NO_CANON_WRITES','n':26,'visually_amended_count':len(amended),
            'change_propagation':affected,'issue_counts':dict(sorted(counts.items())),
            'source_cast_bonus_count':sum('FOREIGN_CAST_BONUS_ACTION_PENDING' in x['issues'] for x in new),
            'secondary_bonus_count':sum(x['source_secondary_bonus_action'] for x in new),
            'concentration_count':sum('FOREIGN_CONCENTRATION_PENDING' in x['issues'] for x in new),
            'PA_cost_known_count':sum(x['native_pa_cost'] is not None for x in new),
            'native_playable_count':sum(x['native_playable'] for x in new),
            'rows':new}
if __name__=='__main__':
    print(json.dumps(report(),indent=2,ensure_ascii=False))
