"""Resume next 14 techniques WITHOUT touching 12-case peer review or oracle."""
from pathlib import Path
import json, collections
from portability_v2 import report,BASE
SOURCE_ATLAS='https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab'
SOURCE_MAGIA='https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373'
SOURCE_COMBATE='https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0'
SOURCE_DMG='https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e'

def build_triage():
 outliers={r['case_id'] for r in json.loads((BASE/'R46_12_HIGH_PRIORITY_DISAGREEMENTS_MESTRE_ONLY.json').read_text())}
 rr=report();gates={r['case_id']:r for r in rr['rows']}
 corpus=json.loads((BASE/'REFERENCE_R45_INPUT/CORPUS_MECANICO_MANUAL_CEGO.json').read_text())['cases']
 components=json.loads((BASE/'REFERENCE_R45_INPUT/ATLAS_26_DECOMPOSICAO_SUBEFEITOS_TEST.json').read_text())['cards']
 bycomp={r['case_id']:r for r in components}
 if len(outliers)!=12 or len(bycomp)!=26:raise RuntimeError('denominator issue')
 queue=[]
 for c in corpus:
  id=c['case_id'];
  if id in outliers:continue # strictly independent, 12 peer review cases untouched
  g=gates[id]
  issues=g['issues']
  family=c.get('effect_family')
  category=(['system:Atlas A','system:Magia','system:Combate']+
   (['system:DMG-RANK'] if family=='dano' else []))
  missing=[]
  if 'FOREIGN_CAST_BONUS_ACTION_PENDING' in issues or 'FOREIGN_SECONDARY_BONUS_ACTION_PENDING' in issues:missing.append('conversão de economia de ação com autoridade')
  if 'FOREIGN_CONCENTRATION_PENDING' in issues:missing.append('regra nativa de manutenção/concentração')
  if 'FOREIGN_SAVING_THROW_NEEDS_NATIVE_CONTRACT' in issues:missing.append('atributo de salvaguarda e comparação CD')
  if 'FOREIGN_LEVEL_SCALING_PENDING' in issues:missing.append('escala evolutiva permitida pelo rank do conjurador')
  missing+=['comparador vivo do estado atual', 'comparador de família com efeito realmente equiparável','critério PA pela autoridade']
  count=len(bycomp[id]['subeffects'])
  # priority is triage of adaptation constraints, not rank/quality.
  priority=3*len(issues)+count
  queue.append({'case_id':id,'source_image_sha256':c['explicit_source_image_sha256'],
    'source_summary_not_historic_rank':c['visual_mechanic_summary'],
    'subeffect_count':count,'foreign_incompatibility_count':len(issues),
    'triage_priority':priority,'system_sources_to_open':category,
    'gaps':missing, 'provisional_rank':None, 'official_change':False,
    'reviewed_by_independent_peer':False})
 queue.sort(key=lambda x:(-x['triage_priority'],x['case_id']))
 return {'peer_12_untouched':True,'scope':'remaining_14_only','n':len(queue),
   'ground_sources':[SOURCE_ATLAS,SOURCE_MAGIA,SOURCE_COMBATE,SOURCE_DMG],
   'n_official_rank_changes':0,'queue':queue}

def audit_subeffects():
 d=json.loads((BASE/'REFERENCE_R45_INPUT/ATLAS_26_DECOMPOSICAO_SUBEFEITOS_TEST.json').read_text())
 cards=d['cards']; valid=set(report()['rows'][i]['case_id'] for i in range(26))
 ids=[s['subeffect_id'] for c in cards for s in c['subeffects']]
 wrong=[(c['case_id'],s['subeffect_id']) for c in cards for s in c['subeffects'] if not s['subeffect_id'].startswith(c['case_id']+'-E')]
 unadjudicated=all(s.get('rank_effect_adjudicated') is None for c in cards for s in c['subeffects'])
 return {'n_abilities':len(cards),'n_subeffects':len(ids),
   'case_denominator_ok':len(cards)==26 and {c['case_id'] for c in cards}==valid,
   'component_unique_ids':len(ids)==len(set(ids)),
   'bad_component_parentage':wrong,'all_RE_not_adjudicated':unadjudicated}

if __name__=='__main__':
 print(json.dumps({'triage':build_triage(),'components':audit_subeffects()},ensure_ascii=False,indent=2))
