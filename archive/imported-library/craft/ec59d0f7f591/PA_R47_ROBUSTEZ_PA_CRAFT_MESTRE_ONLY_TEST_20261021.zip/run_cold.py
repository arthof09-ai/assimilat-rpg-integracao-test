"""Run reproducible self-contained 96-test R47 local proof from an extracted ZIP."""
import subprocess,sys,json,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 m=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
 for n,d in m.items():
  f=ROOT/n
  if not f.exists():raise RuntimeError('MISSING:'+n)
  if sha(f)!=d:raise RuntimeError('SHA_MISMATCH:'+n)
 cmd=[sys.executable,'-m','unittest','discover','-s','tests','-q']
 p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
 output=p.stdout+'\n'+p.stderr
 if p.returncode or 'Ran 96 tests' not in output or 'OK' not in output:
  raise RuntimeError(output[-4000:])
 print(json.dumps({'status':'PASS_LOCAL_TEST_ONLY','source_files_verified':len(m),
         'new_R47_tests':96,'source_R46_sha256':sha(ROOT/'source/R46_BASELINE_MESTRE_ONLY.zip'),
         'peer_template_sha256':sha(ROOT/'source/PEER_TEMPLATE_12_SEM_GABARITO.zip'),
         'no_notion_writes':True,'no_canonical_promotions':True},indent=2))
if __name__=='__main__':main()
