"""Post-freeze agreement-only comparison. Does not declare accuracy or alter R45.

To use *only after receiving a genuinely independent completed review*, hand
in that review CSV as the first input, and an authorized sealed set of proposals
as the second input. Never publish sealed oracle mappings in peer materials.
"""
from __future__ import annotations
import statistics
from math import sqrt
from peer_intake_v2 import RANKS
FIVE=RANKS[:5]

def postfreeze_agreement(peer_by_id, before_oracle_by_id):
    shared=sorted(set(peer_by_id)&set(before_oracle_by_id))
    rows=[]; counts={'matches':0,'mismatches':0,'abstentions':0}
    for key in shared:
        p=peer_by_id[key]; b=before_oracle_by_id[key]
        if p not in RANKS or b not in FIVE:raise ValueError('unexpected rank input')
        if p=='INSUFICIENTE':
            rows.append({'case_id':key,'agreement':None,'rank_distance':None,'peer_abstained':True})
            counts['abstentions']+=1
        else:
            d=abs(FIVE.index(p)-FIVE.index(b)); counts['matches' if d==0 else 'mismatches']+=1
            rows.append({'case_id':key,'agreement':d==0,'rank_distance':d,'peer_abstained':False})
    n=counts['matches']+counts['mismatches']
    # Wilson score for agreement among non-abstentions, NOT accuracy.
    if n:
        rate=counts['matches']/n; z=1.96; den=1+z*z/n
        center=(rate+z*z/(2*n))/den
        half=z*sqrt(rate*(1-rate)/n+z*z/(4*n*n))/den
        interval=[max(0,center-half),min(1,center+half)]
    else: rate=None;interval=None
    return {'metric':'AGREEMENT_BETWEEN_TWO_PROVISIONAL_ASSESSORS_NOT_ACCURACY',
            'shared_cases':len(shared), 'denominator_non_abstaining':n,
            'agreement_rate':rate,'wilson_95_exploratory':interval,'counts':counts,
            'adjudicated_truth':None,'canonical_changes':0,'rows':rows}
