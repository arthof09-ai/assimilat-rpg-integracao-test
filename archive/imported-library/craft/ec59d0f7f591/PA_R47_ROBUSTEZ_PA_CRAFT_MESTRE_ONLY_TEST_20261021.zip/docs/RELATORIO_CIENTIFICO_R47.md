# PA R47 CANDIDATO TEST — Relatório de aperfeiçoamento autônomo

## Resultado funcional, não retórico

O trabalho evita interferir na avaliação do segundo Comestre. Refaz-se somente o **protocolo de recebimento, consistência, integração mecânica e ensaio CRAFT**. A base de comparação histórica foi mantida intacta, e nenhuma autoridade científica foi simulada.

### 1. Validação completa de submissão

O contrato R46 conferia linhas independentes e podia retornar PASS_FORM_ONLY a respostas isoladas sem exigir o denominador. R47 obriga identificar os doze registros, nenhum repetido, nenhum desconhecido, a correspondência SHA com o JPEG derivado correto e testes anti-leakage. O resultado `INSUFICIENTE` é admitido sem três comparadores quando há explicação detalhada da lacuna. Três links sintaticamente válidos não provam que são comparadores idôneos nem identidade do avaliador. Resultado: `FORM_COMPLETE_NOT_SCIENTIFICALLY_VALIDATED`, nunca canonização.

### 2. Separação entre independência e ciência

`compare_sealed.py` só poderá rodar depois do recebimento congelado, usando avaliação independente e previsões R45 previamente congeladas. Retorna acordo ordinal por caso, abstinência e intervalo exploratório de Wilson no conjunto não abstinente. Resultado não é acurácia contra verdade. Neste ciclo, ninguém apresentou a avaliação independente, então acordo novo = NULL, adjudicação = 0.

### 3. Adaptação com proveniência

A correção visual R46 de Proteção Contra Lâminas (1 AÇÃO, não REAÇÃO) estava correta na saída `R46_26_NATIVE_ADAPTATION_GATE.json`, mas o pacote mantinha como referência o corpus R45 sem retificação. R47 aplica a alteração com pré-condição explícita, conserva o corpus antigo e o motivo da emenda. Adicional: detectada separadamente ação bônus de **comando** em Servo Invisível; seis ações bônus de *conjuração* continuam como categorias distintas. Custos PA de 26/26 técnicas = NULL, e nenhuma é declarada pronta para jogo. Avisos por fatos de alcance em pés incluem alcance do efeito além do alcance de conjuração.

### 4. Qualidade da descrição das técnicas

Foram confirmados 26 cartões, 67 subefeitos, vínculo pai-filho íntegro e nenhum RE adjudicado nos subefeitos. A fila dos 14 casos não entregues ao revisor externo preserva suas lacunas e não cria novas classificações por heurísticas não verificadas.

### 5. Ensaio CRAFT H2/P2

O ensaio fatorial proposto distingue oito cenários possíveis com fonte natural, P2 instalada e magia própria instalada, exigindo contrafactuais e repetição. É **arquitetura**, não execução material. Mesmo com uma planilha formalmente completa, somente verificação externa das imagens, lotes, operador, fontes, amostras e testemunhos poderá sustentar qualquer conclusão sobre estabilidade ou item com habilidade própria. Nenhum efeito mág­ico efetivamente observado, 0 PA gasto, 0 item criado, H2/RC5 HOLD.

### 6. Integridade da preparação para peer

A auditoria de bytes reconcilia os 26 JPGs de origem, 26 cópias com rodapé mascarado, 12 JPGs no pacote externo e 12 hashes do CSV. Todos os pares possuem hashes correspondentes. A recompressão JPEG preserva a leitura, mas altera ligeiramente pixels fora da máscara; assim não se afirma igualdade pixel a pixel fora da região. A alteração média fora da máscara (canal absoluto) é <1, enquanto a região mascarada apresenta contraste muito superior; não há nova geração do conteúdo original.

### 7. Estabilidade do motor legado

O arquivo-fonte original R42 foi reaberto e executado de forma isolada nesta rodada. **284/284 arquivos de fonte conferidos**, 510 testes da PA R39, 40 testes da fábrica R48 e 13 do R42: **563/563 PASS**. Não há alteração dos motores R26/R27, nem evidência de fabricação material. A suíte nova do R47 deve ser verificada separadamente.

### Estado de maturidade

**PASS local:** qualidade do CSV/ZIP futuro, detecção de alterações/contaminação, controle do denominador, proveniência de correção visual, identificação de subações, identificação de 14 casos remanescentes, QA fatorial digital, cadeia de hashes e regressão R42.

**HOLD:** ranking E0/E1, verdadeiro benchmark de acurácia, adaptação normativa externa, incidência PA definitiva de A/B/C, aplicação P2 material e produção RC5. Cada HOLD tem motivo específico e não paralisa trabalho independente.
