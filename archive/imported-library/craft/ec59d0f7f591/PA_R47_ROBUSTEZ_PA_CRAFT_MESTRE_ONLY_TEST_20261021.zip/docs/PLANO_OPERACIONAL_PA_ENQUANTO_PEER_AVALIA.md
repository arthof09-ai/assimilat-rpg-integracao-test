# Plano operacional R47 — execução autônoma, sem contaminação do revisor

**Escopo existente:** Mestre-side / estudo PA R45→R46→R46A / Foco R47-CANDIDATO TEST / controle CRAFT H2/P2.
**Precedência:** BOOTSTRAP-COMESTRE; NAC-CONT-03; NAC-NORM-01; NAC-PASS; Atlas A; DMG-RANK-01; Sistema de Magia e Combate.
**Não é uma nova versão do motor R26/R27, uma aprovação de rank, uma ordem do CRAFT ou um substituto para a avaliação independente.**

## Dez etapas encadeadas cumpridas neste ciclo
1. Reabrir status das fontes e confirmar que outro CRAFT trabalha no mesmo LAB; não interferir nas folhas das técnicas, Party ou O Primeiro.
2. Inspecionar pacotes R45/R46 e a R46A, incluindo a separação do kit do avaliador, o score histórico e o congelamento pré-oráculo.
3. Detectar falha do validador R46: valida linhas mas não integridade 12/12 do conjunto; ausência de tolerância correta para INSUFICIENTE.
4. Construir recebimento `peer_intake_v2.py` com 12/12 únicos, hashes da imagem MASCARADA, proteção contra CSV/ZIP inválidos, autorrelato de independência marcado somente como autorrelato; 35 testes.
5. Construir módulo `compare_sealed.py` de concordância ordinal e intervalo de Wilson **somente após** o recebimento congelado do novo Comestre. Sem 'acurácia', sem acesso ao gabarito e sem promover classificação.
6. Auditar reparo visual de Proteção Contra Lâminas: a saída final R46 já havia corrigido para Ação Padrão, mas o corpus histórico R45 embutido não refletia a emenda; manter correção na camada derivada R47 sem editar o original. Identificar ação bônus *secundária* de comando Servo Invisível, além das 6 de conjuração e dos 12 casos de concentração. 20 testes.
7. Criar protocolo experimental CRAFT com oito braços fatoriais (fonte, vedação, magia própria), duas observações mínimas por braço e testemunhas/lotes. **Mesmo um formulário integral não autentica a aplicação física nem demonstra magia**. Preservar status HOLD; 18 testes.
8. Derivar fila de trabalho dos 14 casos fora do pacote peer, com carências por tipo e referências sistêmicas; verificar os 67 subefeitos já identificados e suas associações às 26 técnicas; 14 testes.
9. Auditar cadeia de integridade: 26 originais e 26 derivados no pacote R46, 12 derivados entregues ao peer; conferir SHA/PIL e quantificar o efeito de recompressão na área fora do rodapé redigido; 9 testes.
10. Reexecutar suíte PA R42 intacta em extração limpa (284 membros SHA, 510 testes PA + 40 fábrica R48 + 13 da R42=563 PASS), gerar novo ZIP R47 com prova local, inserir checkpoint LAB autorizado e verificar readback, mantendo próximos gates.

## Estado de evidência
**VERIFICADO:** 26 imagens reais originais, 26 derivações, 12 imagens do peer no pacote específico, 67 subefeitos indexados, 14 casos não submetidos ao peer, fonte PA R42 563/563 PASS, testes unitários R47 e hashes por arquivo.
**INFERIDO:** criticidade potencial de ações de conjuração e comando; ordenação de trabalho por número de dependências não equivale a RE.
**PROPOSTO:** verificação de comparadores externos por fonte viva, adjudicação por responsável competente, oito braços CRAFT antes de fabricação real.
**PENDENTE:** parecer independente realmente entregue e congelado (não fingir acesso ao outro chat); classificação E0/E1; fórmula nativa para PA de todas as 26; homologação do mapa ação bônus/Concentração; correção oficial P2 do sal/energia e óleo; lotes, operador e testemunhas; H2/F5/RC5.

## Regras adicionais de continuidade
- Não buscar nem ler a avaliação do novo Comestre antes de ele entregá-la ao Mestre. Qualquer validação futura deve comparar os **12 casos recebidos** contra os 12 correspondentes, preservando os 14 outros fora do denominador.
- `INSUFICIENTE` é um resultado legítimo se justificado e com lacuna explícita. Falta de três comparadores não é falha formal automática desse resultado.
- URLs só validam estrutura; depois exige abrir cada referência, confirmar correspondência de fenômeno e distinguir personagem, sistema e família.
- Em qualquer análise de acordo, reportar **concordância**, nunca acurácia contra gabarito não homologado.
- R26/R27 são a fonte energética, não modificar seus arquivos nem cobrar PA de material não instalado; custo não informado = NULL, não zero.
- Para CRAFT, relato, simulação e formulário não são magia instalada nem registro de consumo; o laboratório precisa de evidência material supervisionada.
- Atualizar apenas LAB Mestre já existente e somente com checkpoints únicos, em Notion Mestre; nenhum write Party/O Primeiro ou fichas originais.
