"""Byte provenance of current R46 inputs and peer kit (no reclassification)."""
import json,zipfile,hashlib,io
from pathlib import Path
from PIL import Image
import numpy as np
BASE=Path(__file__).resolve().parent/'input'
PEER=Path(__file__).resolve().parent/'source/PEER_TEMPLATE_12_SEM_GABARITO.zip'
ORIGINAL=Path(__file__).resolve().parent/'source/R46_BASELINE_MESTRE_ONLY.zip'

def sha(x):return hashlib.sha256(x).hexdigest()

def audit():
    manifest=json.loads((BASE/'R46_26_SOURCE_IMAGE_SHA256.json').read_text())
    with zipfile.ZipFile(ORIGINAL) as source,zipfile.ZipFile(PEER) as peer:
        images=[n for n in source.namelist() if n.startswith('REFERENCE_R45_INPUT/images/') and n.endswith('.jpg')]
        masks=[n for n in source.namelist() if n.startswith('REFERENCE_R45_INPUT/BLIND_NATIVE_LEVEL_MASKED/') and n.endswith('.jpg')]
        pimgs=[n for n in peer.namelist() if n.startswith('IMAGENS_SEM_GABARITO/') and n.endswith('.jpg')]
        wrong=[];outside_error=[];inside_error=[];masked_shas={}
        for n in images:
            case=Path(n).stem;file=source.read(n)
            if sha(file)!=manifest.get(case):wrong.append(case)
            mfile=source.read('REFERENCE_R45_INPUT/BLIND_NATIVE_LEVEL_MASKED/'+case+'.jpg')
            with Image.open(io.BytesIO(file)) as im,Image.open(io.BytesIO(mfile)) as masked:
                if im.size!=(700,1013) or masked.size!=(700,1013):wrong.append('DIM:'+case)
                a=np.asarray(im.convert('RGB')).astype('int16');b=np.asarray(masked.convert('RGB')).astype('int16')
                mask=np.ones((1013,700),dtype=bool)
                mask[932:999,55:647]=False
                diff=np.abs(a-b)
                outside_error.append(float(diff[mask].mean()))
                inside_error.append(float(diff[~mask].mean()))
            masked_shas[case]=sha(mfile)
        for n in pimgs:
            case=Path(n).stem
            if sha(peer.read(n))!=masked_shas.get(case):wrong.append('PEER_SHA:'+case)
        csv=peer.read('peer_review_blank.csv')
        import csv as cv
        rows=list(cv.DictReader(io.StringIO(csv.decode('utf-8'))))
        for r in rows:
            if masked_shas.get(r['case_id'])!=r['image_sha256']:wrong.append('PEER_CSV:'+r['case_id'])
        return {'source_zip_sha256':sha(ORIGINAL.read_bytes()),
                'n_original':len(images),'n_masked':len(masks),'n_peer':len(pimgs),'n_template_csv':len(rows),
                'wrong_sha_or_dimensions':wrong,
                'jpeg_outside_redaction_mean_abs_error_avg':round(sum(outside_error)/len(outside_error),3),
                'jpeg_inside_redaction_mean_abs_error_avg':round(sum(inside_error)/len(inside_error),3),
                'footer_mask_only_original_untouched':True,
                'redaction_quality_inference':'JPEG re-encoding changes pixels outside box slightly; assess ratio, not exact equality',
                'peer_ranks_seen_in_this_audit':False}
if __name__=='__main__':print(json.dumps(audit(),ensure_ascii=False,indent=2))
