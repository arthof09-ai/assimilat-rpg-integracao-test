"""PA TEST-only peer-review intake, deliberately independent of historical ranks.

This module never opens a prior assessor's oracle or legacy labels, never alters
Notion, never promotes RE and does not attest independent human identity.
"""
from __future__ import annotations
import csv, hashlib, io, math, re, json, zipfile
from pathlib import Path
from urllib.parse import urlparse
from collections import Counter
from typing import Iterable

RANKS = ('Bronze', 'Prata', 'Ouro', 'Ouro Negro', 'Lendário', 'INSUFICIENTE')
ROLES = ('system_comparator_url', 'live_comparator_url', 'family_comparator_url')
COLS = ('case_id','image_sha256','proposed_RE',*ROLES,'mechanical_rationale',
        'limitations','reviewer_attestation','independent_oracle_not_opened')
BAD_COLUMNS = {'legacy_rank','legacy_rank_master_only','rank_historico',
               'rank_provisional_before_oracle','r45_prediction','oracle_result'}
NUMCASE=12

class IntegrityError(ValueError): pass


def notion_uuid(url):
    if not isinstance(url, str) or not url.strip():return None
    try:
        p=urlparse(url.strip())
        if p.scheme!='https' or (p.hostname or '').lower() not in ('app.notion.com','www.notion.so','notion.so'):
            return None
        # Authored pages only, not arbitrary Notion marketing or share-home links
        part=p.path.strip('/').split('/')[-1]
        match=re.search(r'([a-f0-9]{32}|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})$',part.lower())
        if not match: return None
        return match.group(1).replace('-','')
    except Exception:
        return None


def sha(data):return hashlib.sha256(data).hexdigest()


def load_peer_template(template_zip):
    """Exact expected identifiers and hashes of the original masked peer files."""
    with zipfile.ZipFile(template_zip) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or z.testzip() is not None:raise IntegrityError('template ZIP invalid')
        expected={Path(n).stem:sha(z.read(n)) for n in names if n.startswith('IMAGENS_SEM_GABARITO/') and n.endswith('.jpg')}
        if len(expected)!=NUMCASE:raise IntegrityError('template case count mismatch')
        f=next((n for n in names if n=='peer_review_blank.csv'),None)
        if not f:raise IntegrityError('no template CSV')
        rows=list(csv.DictReader(io.StringIO(z.read(f).decode('utf-8-sig'))))
        if len(rows)!=NUMCASE or set(expected)!={x['case_id'] for x in rows}:raise IntegrityError('template roster mismatch')
        for r in rows:
            if r['image_sha256']!=expected[r['case_id']]:raise IntegrityError('template image sha mismatch')
        return expected


def read_csv_checked(data, *, size_limit=4_000_000):
    if isinstance(data,str):data=data.encode('utf8')
    if len(data)>size_limit:raise IntegrityError('oversize CSV')
    s=data.decode('utf-8-sig')
    reader=csv.DictReader(io.StringIO(s, newline=''))
    fields=reader.fieldnames
    if not fields or len(fields)!=len(set(fields)):raise IntegrityError('missing or duplicate CSV columns')
    if not set(COLS).issubset(fields):raise IntegrityError('required columns missing')
    if set(fields)&BAD_COLUMNS:raise IntegrityError('peer data contaminated with oracle fields')
    rows=list(reader)
    if any(None in r or any(v is None for v in r.values()) for r in rows):
        raise IntegrityError('malformed CSV row')
    return rows


def assess_rows(rows, expected):
    """Returns form quality and scientific eligibility, NEVER a canonical rank."""
    if set(expected)==set() or len(expected)!=NUMCASE:raise IntegrityError('invalid expected source roster')
    seen=Counter(r.get('case_id','') for r in rows)
    extra=sorted(set(seen)-set(expected))
    missing=sorted(set(expected)-set(seen))
    duplicate=sorted(x for x,n in seen.items() if n>1)
    # IMPORTANT: not enough to check each row; compare whole batch denominator.
    per=[]
    for r in rows:
        case=r.get('case_id','')
        reasons=[];rank=(r.get('proposed_RE','') or '').strip()
        if case not in expected:reasons.append('UNKNOWN_CASE')
        elif r.get('image_sha256')!=expected[case]:reasons.append('MASKED_IMAGE_SHA_MISMATCH')
        if seen[case]>1:reasons.append('DUPLICATE_CASE_IN_BATCH')
        if rank not in RANKS:reasons.append('INVALID_RE')
        rationale=(r.get('mechanical_rationale','') or '').strip()
        limits=(r.get('limitations','') or '').strip()
        if len(rationale)<80:reasons.append('RATIONALE_TOO_SHORT')
        if len(limits)<20:reasons.append('LIMITATIONS_TOO_SHORT')
        if r.get('reviewer_attestation','')!='YES':reasons.append('NO_SELF_ATTESTATION')
        if r.get('independent_oracle_not_opened','')!='YES':reasons.append('ORACLE_EXPOSURE_UNCLEAR')
        uids=[notion_uuid(r.get(k,'')) for k in ROLES]
        present=[u for u in uids if u]
        if len(present)!=len(set(present)):reasons.append('COMPARATOR_SOURCE_DUPLICATE')
        if rank=='INSUFICIENTE':
            # Do not force three comparators for precisely the cases where one cannot be found.
            # Still require meaningful description of why it is impossible.
            if len(limits)<45:reasons.append('INSUFFICIENT_REQUIRES_EXPLICIT_GAP')
        else:
            if not any(uids):reasons.append('NO_SOURCES_FOR_PROPOSED_RANK')
        if any(r.get(k,'').strip() and notion_uuid(r.get(k,'')) is None for k in ROLES):
            reasons.append('BAD_NOTION_COMPARATOR_URL')
        # Three comparator slots are evidence of form only. They aren't verified roles.
        three_distinct=len(present)==3 and len(set(present))==3
        state=('FORM_REJECTED' if reasons else
               'INSUFFICIENT_DOCUMENTED_PENDING' if rank=='INSUFICIENTE' else
               'PROVISIONAL_RE_WITH_THREE_FORMAL_SOURCES' if three_distinct else
               'PROVISIONAL_RE_SOURCES_INCOMPLETE')
        per.append({'case_id':case,'status':state,'reasons':sorted(set(reasons)),
                    'three_distinct_page_ids_in_form':three_distinct,
                    'three_equivalent_comparators_verified':False,
                    'independent_reviewer_identity_verified':False,
                    'provisional_rank':rank if rank in RANKS else None,
                    'canonical_re':None})
    valid_structure=(len(rows)==NUMCASE and not missing and not extra and not duplicate)
    no_row_errors=all(x['status']!='FORM_REJECTED' for x in per)
    return {'batch_intake':('FORM_COMPLETE_NOT_SCIENTIFICALLY_VALIDATED' if valid_structure and no_row_errors
                            else 'REJECT_OR_HOLD'),
            'expected_n':NUMCASE,'received_rows':len(rows),'unique_expected_rows':sum(1 for x in expected if seen[x]==1),
            'missing':missing,'unknown':extra,'duplicate':duplicate,
            'form_row_passed':sum(not x['reasons'] for x in per),
            'fully_verified_peer_independence':False,'scientific_accuracy':None,
            'automatically_canonized':0,'rows':per}


def static_intake_from_template(template_zip, review_csv_bytes):
    return assess_rows(read_csv_checked(review_csv_bytes),load_peer_template(template_zip))


def verified_zip_entries(blob, max_files=200, max_expanded=60_000_000):
    """Intake safety for untrusted future ZIP: no traversal, dupes, symlinks, decompression bombs."""
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        infos=z.infolist(); names=[x.filename for x in infos]
        if len(names)>max_files or len(names)!=len(set(names)):raise IntegrityError('duplicate/too many ZIP entries')
        if sum(x.file_size for x in infos)>max_expanded:raise IntegrityError('ZIP expansion limit')
        for x in infos:
            p=Path(x.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in x.filename or '\x00' in x.filename:
                raise IntegrityError('unsafe ZIP path')
            if (x.external_attr>>16)&0o170000==0o120000:
                raise IntegrityError('symbolic link not permitted')
        if z.testzip() is not None:raise IntegrityError('CRC failure')
        return {n:sha(z.read(n)) for n in names if not n.endswith('/')}


def no_oracle_rows(rows):
    assert all(set(r).isdisjoint(BAD_COLUMNS) for r in rows)
    return True
