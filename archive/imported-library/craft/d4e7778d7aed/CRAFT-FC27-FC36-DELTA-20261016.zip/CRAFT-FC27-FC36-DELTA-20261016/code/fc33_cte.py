"""PR-ECO-01 Anexo C: dimensional/accounting input validator, NOT price generator.
Unknown inputs never silently become zero. No RPG MED prices are included.
"""
from __future__ import annotations
from decimal import Decimal, InvalidOperation
import json,sys
KEYS=('CI','CP','CF','CT','CE','CK','CL','CA','CC')

def evaluate(nodes,accepted_units,unit):
    if type(nodes)!=dict:raise TypeError('NODE_MAP_REQUIRED')
    if set(nodes)!=set(KEYS):raise ValueError('EXACT_NINE_CTE_CATEGORIES_REQUIRED')
    if type(accepted_units)!=int or accepted_units<0:raise ValueError('INVALID_APPROVED_UNITS')
    missing=[];vals={}
    for k in KEYS:
        v=nodes[k]
        if v is None:
            missing.append(k);continue
        if type(v)!=dict or v.get('unit')!=unit or v.get('value') is None:
            raise ValueError('SOURCE_UNIT_MISMATCH_OR_MISSING:'+k)
        if not v.get('source') or not v.get('epoch'):
            raise ValueError('PROVENANCE_REQUIRED:'+k)
        try:amount=Decimal(str(v['value']))
        except (InvalidOperation, ValueError):raise ValueError('NOT_A_DECIMAL:'+k)
        if not amount.is_finite() or amount<0:raise ValueError('NEGATIVE_OR_NONFINITE:'+k)
        vals[k]=amount
    if missing:
        return {'status':'HOLD_MISSING_PARAMETERS','missing':missing,'unit':unit,
                'CTE_total':None,'CTE_per_approved_unit':None}
    total=sum(vals.values(),Decimal('0'))
    if accepted_units==0:
        return {'status':'ZERO_PASS_NO_UNIT_COST','missing':[],'unit':unit,
                'CTE_total':str(total),'CTE_per_approved_unit':None}
    return {'status':'CALCULABLE_WITH_SUPPLIED_PARAMETERS','missing':[],'unit':unit,
            'CTE_total':str(total),'CTE_per_approved_unit':str(total/Decimal(accepted_units)),
            'source_scope':'ONLY_INPUTS_SUPPLIED_NOT_PRICES_DISCOVERED'}

if __name__=='__main__':
    empty={k:None for k in KEYS}
    symbolic=evaluate(empty,1,'MED')
    # Test-only dimensional sentinel units, not canonical MED prices or economics.
    synthetic={k:{'value':'1','unit':'u_TEST','source':'SYNTHETIC_UNIT_TEST','epoch':'NOT_MARKET'} for k in KEYS}
    assert evaluate(synthetic,1,'u_TEST')['CTE_total']=='9'
    assert evaluate(synthetic,0,'u_TEST')['CTE_per_approved_unit'] is None
    try:evaluate({**synthetic,'CI':{'value':'1','unit':'MED','source':'SYNTH','epoch':'NONE'}},1,'u_TEST')
    except ValueError:pass
    else:raise RuntimeError('UNIT_MISMATCH_NOT_REJECTED')
    print(json.dumps({'symbolic_with_missing':symbolic,'test_only_total':evaluate(synthetic,1,'u_TEST'),
                      'zero_pass':evaluate(synthetic,0,'u_TEST'),'checks_passed':4},ensure_ascii=False,indent=2))
