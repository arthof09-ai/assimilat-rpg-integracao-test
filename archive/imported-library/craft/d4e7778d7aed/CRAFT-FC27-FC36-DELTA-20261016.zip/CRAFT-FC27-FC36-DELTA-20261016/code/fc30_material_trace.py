"""FC27–FC36 additive experiment on ORIGINAL R48 + FC04 adapter.
No edits to the old engine, no official stock and no new REC-ID.
New component: verified material-role allocation and independently recoverable
append-only output annex bound to actual R48 commit; NOT the R48 native waste ledger.
"""
from __future__ import annotations
import copy, hashlib, json, os, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
FC04=Path(os.environ['CRAFT_FC04_ROOT'])
sys.path.insert(0,str(FC04/'code'))
from r48_b30_adapter import CASE,SM,FM,REVIEW,factory,synthetic_lots,order,qa_values,CHITIN,FIBER

def dig(x):
    return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def put_once(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():raise RuntimeError('IMMUTABLE_ARTIFACT_EXISTS:'+str(p))
    data=(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    with open(p,'xb') as f:
        f.write(data);f.flush();os.fsync(f.fileno())
    return dig(obj)

def plan(order_id,plate_mm=(60,30),panel_mm=(50,20),hinge_cm=18,closure_cm=12):
    return {'schema':'FC30-MATERIAL-ROLE-PLAN-v1','order_id':order_id,
       'kind':'ALL_NUMERIC_DIMENSIONS_SYNTHETIC_DESIGN_NOT_PS_MEASURED',
       'recipe_design_id':'B30-22','source_page_ids':{'chitin':CHITIN,'fiber':FIBER},
       'panels':[{'lot_id':'SBX-FC04-CHITIN-A','source_min_mm':list(plate_mm),'target_mm':list(panel_mm)},
                 {'lot_id':'SBX-FC04-CHITIN-B','source_min_mm':list(plate_mm),'target_mm':list(panel_mm)}],
       'fiber_lot_id':'SBX-FC04-FIBER','fiber_input_cm':30,
       'fiber_roles_proposed_cm':{'flexible_joint':hinge_cm,'closure_lacing':closure_cm},
       'real_offcut_mass':None,'real_wear':None,'physical_strength':None,
       'official_rec_id':None,'authoritative_process_evidence':False}

def preflight(p):
    if p['source_page_ids']!={'chitin':CHITIN,'fiber':FIBER}:raise ValueError('SOURCE_IDENTITY_INVALID')
    if p['fiber_input_cm']!=30 or any(type(x)!=int or x<0 for x in p['fiber_roles_proposed_cm'].values()):raise ValueError('FIBER_INPUT_INVALID')
    if sum(p['fiber_roles_proposed_cm'].values())!=p['fiber_input_cm']:
        raise ValueError('UNRECONCILED_FIBER_LENGTH')
    if len(p['panels'])!=2 or {x['lot_id'] for x in p['panels']}!={'SBX-FC04-CHITIN-A','SBX-FC04-CHITIN-B'}:
        raise ValueError('PANEL_SOURCE_LOTS_INVALID')
    for r in p['panels']:
        if len(r['source_min_mm'])!=2 or len(r['target_mm'])!=2 or any(type(v)!=int or v<=0 for v in r['source_min_mm']+r['target_mm']):
            raise ValueError('INVALID_DIMENSION')
        if any(b>a for b,a in zip(r['target_mm'],r['source_min_mm'])):
            raise ValueError('OUTPUT_EXCEEDS_INPUT_AXIS')
    return True

def newest_order(store,order_id):
    f,s=SM.DurableFactory(store).recover()
    matches=[o for j in f.journal for o in j['event']['orders'] if o['order_id']==order_id]
    if len(matches)!=1:raise RuntimeError('NOT_EXACTLY_ONE_COMMITTED_ORDER')
    return matches[0],s,f

def material_annex(store,p):
    preflight(p)
    o,s,f=newest_order(store,p['order_id'])
    passed=o['status']=='EXPERIMENTAL_QA_PASS'
    input_map={x['lot_id']:(x['quantity'],x['unit'],x['source_page_id']) for x in o['consumed']}
    required={'SBX-FC04-CHITIN-A':(1,'placa',CHITIN),'SBX-FC04-CHITIN-B':(1,'placa',CHITIN),'SBX-FC04-FIBER':(30,'cm',FIBER)}
    if passed and input_map!=required:raise RuntimeError('CONSUMPTION_DOES_NOT_MATCH_PLAN')
    if not passed and (o['consumed'] or o['products']):raise RuntimeError('REJECTED_EFFECT_LEAK')
    if passed and (len(o['products'])!=1 or o['products'][0]['recipe_key']!=CASE):raise RuntimeError('PRODUCT_MISMATCH')
    if not f.audit()['ok']:raise RuntimeError('R48_NATIVE_AUDIT_FAILED')
    # THE ATTACHED AREA IS ONLY IDEAL-RECTANGLE ENGINEERING, NOT MEASURED CHITIN MASS.
    areas=[{'lot_id':r['lot_id'],'input_min_rect_area_mm2':r['source_min_mm'][0]*r['source_min_mm'][1],
        'panel_target_area_mm2':r['target_mm'][0]*r['target_mm'][1],
        'unused_ideal_area_mm2':r['source_min_mm'][0]*r['source_min_mm'][1]-r['target_mm'][0]*r['target_mm'][1],
        'actual_scrap_mass':'UNKNOWN'} for r in p['panels']]
    a={'schema':'FC30-MATERIAL-SIDECAR-v1','fixture_only':True,'order_id':o['order_id'],
       'plan_sha256':dig(p),'native_r48_head':s['r48_head'],'native_disk_sequence':s['sequence'],
       'native_order_digest':dig(o),'native_consumed':o['consumed'],'native_waste':o['waste'],
       'native_qa_status':o['status'],'native_product_ids':[z['product_id'] for z in o['products']],
       'fiber_role_allocation_cm':p['fiber_roles_proposed_cm'] if passed else {},
       'fiber_allocated_total_cm':sum(p['fiber_roles_proposed_cm'].values()) if passed else 0,
       'panel_ideal_area_analysis':areas if passed else [],
       'physical_scrap_mass_measured':False,'actual_material_qa_measured':False,
       'annotation':'Additive MATERIAL-FLOW sidecar, NOT R48 native mass/waste ledger. No inferred physical loss.',
       'official_write_count':0}
    a['sidecar_digest']=dig(a)
    return a

def run_demo():
    out=ROOT/'outputs/FC30_R48_NEW_EXECUTION';out.mkdir(parents=True,exist_ok=True)
    def init(name,chitin=1,fiber=30):
        dst=out/name
        if dst.exists():raise RuntimeError('REFUSE_OVERWRITE:'+name)
        s=SM.DurableFactory(dst);s.initialize(factory(synthetic_lots(chitin=chitin,fiber=fiber)))
        return s
    # Case A: fully new product under R48, with new validation+sidecar.
    normal=init('CASE_MAIN_STORE')
    row=order(CASE,92701);p=plan(row['order_id']);preflight(p)
    put_once(out/'plans'/f"{row['order_id']}.json",p)
    stock_before=normal.recover()[0].quantities
    r=normal.commit_batch('SBX-R48-BATCH-FC30-MATERIAL-01',[row],REVIEW)
    assert r['receipt']['orders'][0]['status']=='EXPERIMENTAL_QA_PASS'
    sidecar=material_annex(normal.root,p)
    put_once(out/'sidecars'/f"{row['order_id']}.json",sidecar)
    idem=normal.commit_batch('SBX-R48-BATCH-FC30-MATERIAL-01',[row],REVIEW)
    assert idem['idempotent_replay'] and idem['r48_head']==r['r48_head']
    other=normal.commit_batch('SBX-R48-BATCH-FC30-MATERIAL-OVERSELL',[order(CASE,92702)],REVIEW)
    assert other['receipt']['orders'][0]['status']=='REJECTED_PRECHECK'
    assert normal.recover()[0].quantities['SBX-FC04-FIBER']==0
    # QA reject is already established by R47. Here exercise preservation of sidecar boundaries.
    qstore=init('CASE_QA_REJECT_STORE');q=qa_values(CASE);q['closure_secure']=False
    qr=qstore.commit_batch('SBX-R48-BATCH-FC30-QA-NEG',[order(CASE,92703,q)],REVIEW)
    assert qr['receipt']['orders'][0]['status']=='QUARANTINE_EVIDENCE'
    assert qstore.recover()[0].quantities['SBX-FC04-FIBER']==30
    # Fault A: R48 commits but acknowledgement is lost; recover in same idempotent route.
    fault=init('CASE_LOST_ACK_STORE');frow=order(CASE,92704);fp=plan(frow['order_id']);preflight(fp)
    put_once(out/'plans'/f"{frow['order_id']}.json",fp)
    try:
        fault.commit_batch('SBX-R48-BATCH-FC30-LOST-ACK',[frow],REVIEW,inject='AFTER_HEAD_BEFORE_ACK')
    except FM.FactoryCrash as ex:failure=str(ex)
    else:raise RuntimeError('FAULT_NOT_TRIGGERED')
    st=fault.recover()[1]
    frr=fault.commit_batch('SBX-R48-BATCH-FC30-LOST-ACK',[frow],REVIEW)
    assert frr['idempotent_replay'] and frr['disk_sequence']==1
    # Fault B: crash between R48 commit and sidecar durable publication.
    # FAIL CLOSED during acceptance; reconstruct sidecar from R48 committed event and the precommitted plan.
    assert not (out/'sidecars'/f"{frow['order_id']}.json").exists()
    sidecar_recovered=material_annex(fault.root,fp)
    put_once(out/'sidecars'/f"{frow['order_id']}.json",sidecar_recovered)
    # Deliberate bad input: allocation and impossible panel MUST fail before R48 commit.
    invalid=[]
    for name,p_bad in [('FIBER_OVERALLOCATED',plan('PRECHECK-BAD',hinge_cm=19,closure_cm=12)),
                       ('PANEL_EXCEEDS_PLATE',plan('PRECHECK-BAD',panel_mm=(65,20)))]:
        try:preflight(p_bad)
        except ValueError as e:invalid.append({'case':name,'rejected':str(e)})
        else:raise RuntimeError('INVALID_PREFLIGHT_ACCEPTED:'+name)
    result={'schema':'FC30-R48-MATERIAL-EXECUTION-v1',
      'baseline_fc04_head':'cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708',
      'run_ids':['SBX-R48-BATCH-FC30-MATERIAL-01','SBX-R48-BATCH-FC30-LOST-ACK'],
      'factory_original_unmodified':True,'adapter_reused_from_fc04':True,
      'product_TEST_new_run':sidecar['native_product_ids'],
      'main_head_after_oversell':normal.recover()[1]['r48_head'],
      'main_stock_before':stock_before,'main_stock_after':normal.recover()[0].quantities,
      'positive':{'status':r['receipt']['orders'][0]['status'],'receipt_sha256':dig(r['receipt']),
         'head_at_positive':r['r48_head'],'material_sidecar':sidecar['sidecar_digest']},
      'insufficient_stock':other['receipt']['orders'][0]['status'],
      'quality_rejection':qr['receipt']['orders'][0]['status'],
      'idempotent_replay':idem['idempotent_replay'],
      'lost_ack':failure,'lost_ack_replay':frr['idempotent_replay'],
      'recovered_material_sidecar':sidecar_recovered['sidecar_digest'],
      'rejected_preflights':invalid,
      'source_character':'SIMULATED_PS_IDENTITIES_NOT_CANONICAL_STOCK',
      'new_measured_material_properties':0,'new_official_rec_ids':0,
      'scope':'MASTER_SIDE_SANDBOX_ONLY'}
    put_once(out/'fc30_execution_results.json',result)
    return result

if __name__=='__main__':
    print(json.dumps(run_demo(),ensure_ascii=False,indent=2))
