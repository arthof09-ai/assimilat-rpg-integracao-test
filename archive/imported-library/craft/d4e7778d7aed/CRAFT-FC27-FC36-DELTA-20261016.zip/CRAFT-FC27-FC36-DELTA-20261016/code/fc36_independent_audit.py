"""Read-only verification of FC30 commits and NEW material allocation sidecar.
Stdlib only. Does not import, invoke, or trust the R48 factory.
Loads original FC04's already-proven read-only hash-chain auditor by explicit path.
"""
from __future__ import annotations
import argparse, copy, hashlib, importlib.util, json, sys
from pathlib import Path

def dig(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def read(p):return json.loads(Path(p).read_text('utf8'))
def independent_fc04_auditor(fc04):
    src=Path(fc04)/'code/independent_audit.py'
    if not src.is_file():raise FileNotFoundError('MISSING_ORIGINAL_FC04_AUDITOR')
    spec=importlib.util.spec_from_file_location('fc04_read_only_independent_for_fc36',src)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod.audit_store

def check_sidecar(root,s,known):
    problems=[]
    digest_saved=s.get('sidecar_digest')
    pure={k:v for k,v in s.items() if k!='sidecar_digest'}
    if dig(pure)!=digest_saved:problems.append('SIDECAR_INTEGRITY')
    pth=root/'plans'/f"{s.get('order_id')}.json"
    if not pth.is_file():return ['MISSING_PRECOMMITTED_PLAN']+problems
    p=read(pth)
    if p['order_id']!=s['order_id'] or dig(p)!=s['plan_sha256']:
        problems.append('PLAN_ANCHOR_DRIFT')
    allocated=p['fiber_roles_proposed_cm']
    if allocated!={'flexible_joint':18,'closure_lacing':12} or sum(allocated.values())!=30:
        problems.append('FIBER_PARTITION_CONSERVATION')
    if p.get('source_page_ids')!={'chitin':'3f3c2b32-4ede-8141-acdd-f0bb23ffe56c',
                                  'fiber':'3f3c2b32-4ede-815a-b04a-ce5bd1074e79'}:
        problems.append('PS_SOURCE_IDENTITY')
    if p['real_offcut_mass'] is not None or s['physical_scrap_mass_measured'] is not False:
        problems.append('UNSUPPORTED_PHYSICAL_WASTE_CLAIM')
    if s['order_id'] not in known:return ['ORDER_NOT_PRESENT_IN_R48_JOURNAL']+problems
    obj=known[s['order_id']]
    event_order=obj['order'];event=obj['event'];seq=obj['sequence'];eventhash=obj['hash']
    if s['native_order_digest']!=dig(event_order):problems.append('ORDER_RECEIPT_BINDING')
    if s['native_r48_head']!=eventhash or s['native_disk_sequence']!=seq:problems.append('TRANSACTION_HEAD_BINDING')
    if s['native_consumed']!=event_order['consumed'] or s['native_waste']!=event_order['waste']:
        problems.append('MATERIAL_LEDGER_BINDING')
    if s['native_qa_status']!=event_order['status']:problems.append('QA_BINDING')
    product_ids=[x['product_id'] for x in event_order['products']]
    if s['native_product_ids']!=product_ids or len(product_ids)!=1:problems.append('PRODUCT_BINDING')
    want={'SBX-FC04-CHITIN-A':(1,'placa','3f3c2b32-4ede-8141-acdd-f0bb23ffe56c'),
          'SBX-FC04-CHITIN-B':(1,'placa','3f3c2b32-4ede-8141-acdd-f0bb23ffe56c'),
          'SBX-FC04-FIBER':(30,'cm','3f3c2b32-4ede-815a-b04a-ce5bd1074e79')}
    got={x['lot_id']:(x['quantity'],x['unit'],x['source_page_id']) for x in event_order['consumed']}
    if got!=want:problems.append('REAL_R48_CONSUMPTION_NOT_EXPECTED_SYNTHETIC_BOM')
    if s['fiber_allocated_total_cm']!=30 or s['fiber_role_allocation_cm']!=allocated:
        problems.append('ALLOCATION_DOES_NOT_FIT_CONSUMPTION')
    for panel in p['panels']:
        a,b=panel['source_min_mm'];x,y=panel['target_mm']
        if x>a or y>b:problems.append('PANEL_EXCEEDS_SOURCE')
    if not s['fixture_only'] or s['official_write_count']!=0:problems.append('OFFICIAL_BOUNDARY')
    return problems

def verify(root,fc04, write=False):
    root=Path(root);auditor=independent_fc04_auditor(fc04)
    paths=['CASE_MAIN_STORE','CASE_QA_REJECT_STORE','CASE_LOST_ACK_STORE']
    stores={n:auditor(root/n) for n in paths}
    faults={n:x['failures'] for n,x in stores.items() if not x['ok']}
    known={}
    for n in paths:
        current=read(root/n/'CURRENT.json')
        snap=read(root/n/'commits'/current['current'])
        for j,item in enumerate(snap['journal'],1):
            for o in item['event']['orders']:
                known[o['order_id']]={'order':o,'event':item['event'],'sequence':j,'hash':item['hash'],'store':n}
    sidecars=list(sorted((root/'sidecars').glob('*.json')))
    sidecar_results={}
    for path in sidecars:
        s=read(path);sidecar_results[s['order_id']]=check_sidecar(root,s,known)
    expected_ids={'SBX-R48-ORDER-FC04-92701','SBX-R48-ORDER-FC04-92704'}
    if set(sidecar_results)!=expected_ids:faults['sidecar_registry']='EXPECTED_EXACTLY_TWO_SIDECARS'
    if any(sidecar_results.values()):faults['sidecar_mismatch']=sidecar_results
    if stores['CASE_MAIN_STORE']['synthetic_products']!=1 or stores['CASE_MAIN_STORE']['sequence']!=2:
        faults['main']='EXPECTED_ONE_PRODUCT_ONE_REJECT'
    if stores['CASE_QA_REJECT_STORE']['synthetic_products']!=0 or stores['CASE_QA_REJECT_STORE']['stock_before']!=stores['CASE_QA_REJECT_STORE']['stock_after']:
        faults['qa']='EXPECTED_NO_STOCK_EFFECT'
    if stores['CASE_LOST_ACK_STORE']['synthetic_products']!=1 or stores['CASE_LOST_ACK_STORE']['sequence']!=1:
        faults['lost_ack']='EXPECTED_EXACTLY_ONE_COMMITTED_PRODUCT'
    demo=read(root/'fc30_execution_results.json')
    if not demo['idempotent_replay'] or not demo['lost_ack_replay']:
        faults['replay']='REPLAY_REQUIRED'
    # Tampering test performed ONLY in memory, never on accepted file.
    accepted=read(sidecars[0]);tampered=copy.deepcopy(accepted);tampered['fiber_allocated_total_cm']=90
    tamper_result=check_sidecar(root,tampered,known)
    if not ('SIDECAR_INTEGRITY' in tamper_result and 'ALLOCATION_DOES_NOT_FIT_CONSUMPTION' in tamper_result):
        faults['tamper']='TAMPERING_NOT_CAUGHT'
    metrics={'native_store_integrity':len([k for k,v in stores.items() if v['ok']]),
             'sidecar_integrity':len([k for k,v in sidecar_results.items() if not v]),
             'tamper_rejected':bool(tamper_result),
             'main_positive_units':stores['CASE_MAIN_STORE']['synthetic_products'],
             'recover_positive_units':stores['CASE_LOST_ACK_STORE']['synthetic_products'],
             'r48_commit_sequence_main':stores['CASE_MAIN_STORE']['sequence'],
             'r48_commit_sequence_lost_ack':stores['CASE_LOST_ACK_STORE']['sequence']}
    result={'schema':'FC36-INDEPENDENT-READBACK-v1','read_only':True,'factory_engine_imported':False,
            'stores':stores,'sidecar_results':sidecar_results,
            'tamper_detection_in_memory':tamper_result,'metrics':metrics,
            'errors':faults,'ok':not faults,'official_products':0,
            'disclaimer':'Simulated material allocation, not native mass ledger or physical material measurement'}
    if write:
        dest=root.parent/'fc36_independent_readback.json'
        if dest.exists():raise RuntimeError('IMMUTABLE_AUDIT_EXISTS')
        dest.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('store_root',type=Path);ap.add_argument('--fc04-root',required=True,type=Path);ap.add_argument('--write',action='store_true');a=ap.parse_args()
    r=verify(a.store_root,a.fc04_root,a.write)
    print(json.dumps({'ok':r['ok'],'metrics':r['metrics'],'errors':r['errors']},ensure_ascii=False,indent=2))
    sys.exit(0 if r['ok'] else 1)
