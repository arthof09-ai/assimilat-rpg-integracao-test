# PSV — CM-000002 / WS0001 / OP-ARQ-RIN-REC-01 / FC27–FC36

**AS-OF:** 16/10/2026. **Ambiente:** MESTRE-SIDE. **BASELINE:** R01–R52, BACKFILL-30 e FC01–FC26 preservados.

## Resultado executivo

- **Fato recuperado:** a integração B30-22 na R48 não é inédita nesta ordem — já existia no FC04, com HEAD `cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708`.
- **Capacidade nova FC30:** guardião de alocação de materiais por função (2 placas + 30 cm fibra); recuperação de anexo após ACK perdido usando recibo transacional R48 e plano previamente guardado. Sidecar *não* é ledger nativo de massa/refugo.
- **Novo produto TEST desta rodada:** `SBX-CRAFT-R44-I0016-PRODUCT-SBX-R48-ORDER-FC04-92701` (execução nova, não família nova); um segundo TEST surgiu no cenário de recuperação `...92704`. Ambos têm fonte PS como identidade, mas estoque exclusivamente sintético e QA simulado. **Zero produtos oficiais.**
- **Fabricação oficial e RC5:** HOLD; requisitos técnicos de mérito/qualidade/conhecimento/economia e gates administrativos separados.

## Etapas individualizadas

| Etapa | Execução real e classificação | Evidência |
|---|---|---|
| FC27 | **VERIFICADO**: errata aditiva de 2 linhas B30-03 mal mapeadas; input 2 folhas >=60×30 mm, saída par 50×20 mm e `t_lote` desconhecida; 26 gaps históricos intactos | `outputs/FC27_aditiva_errata_B30_03.json` |
| FC28 | **VERIFICADO histórico:** R50 recuperado do pacote v03: uma B30-01 com dois nomes; B30-21 é régua linear, não substituto automático de gabarito 2D. **HOLD** quanto a ausência global de equivalente | `outputs/FC28_lineage_B30_01_R50_physical_evidence.json` |
| FC29 | **PROPOSTO/RECUPERADO**: contrato B30-22 e fontes de quitina/fibra reconciliados sem cordame intermediário; geometria/fecho propostos, nenhum bônus | `outputs/FC29_B30_22_contract_provenance.json` |
| FC30 | **EXECUTADO TEST**: R48/FC04 originais reutilizados; novo pedido B30-22 PASS, produto TEST, estoque 2 placas+30 cm debitado; tentativas negativas sem duplicação | `outputs/FC30_R48_NEW_EXECUTION/` |
| FC31 | **EXECUTADO TEST**: falta de estoque, QA negativa, replay, crash pós-commit/ACK perdido e recuperação do mesmo commit, rejeição de partições inválidas; concorrência comprovada no FC04 histórico, não repetida | `outputs/FC31_FC32_recovery_qa_scientific_limits.json` |
| FC32 | **HOLD material**: QA operacional de fixture, mas ciclos, força, massa residual, umidade e benefício físico sem medição/autoridade | `outputs/FC31_FC32_recovery_qa_scientific_limits.json` |
| FC33 | **NOVO COMPONENTE REUTILIZÁVEL:** PR-ECO CTE validado com nove parcelas, unidades/proveniência requeridas, UNKNOWN não vira zero, PASS=0 gera custo unitário indefinido | `code/fc33_cte.py`, `outputs/FC33_pr_eco_cost_tree.json` |
| FC34 | **RC5-TECH HOLD**: B30-22 e B30-01 pontuadas por RC2/3/4/5; write-set desabilitado sem REC-ID inventado | `outputs/FC34_RC5_gates_disabled_write_set.json` |
| FC35 | **5 aplicações existentes** de engenharia de corte, união, QA e custo; 30 fichas PS históricas preservadas, sem novas recipes | `outputs/FC35_portfolio_reuse_delta.json` |
| FC36 | **VERIFICADO LOCALMENTE**: extração, integridade R48 e material annex, adulteração em memória rejeitada. Não houve readback Notion | `outputs/fc36_independent_readback.json` |

## Dados verificáveis da FC30

**Execução principal:** lotes `SBX-FC04-CHITIN-A`, `SBX-FC04-CHITIN-B` e `SBX-FC04-FIBER` passaram de `1 placa + 1 placa + 30 cm` para `0 + 0 + 0`; um produto foi comitado com `EXPERIMENTAL_QA_PASS`. A tentativa seguinte recebeu `REJECTED_PRECHECK`. Chave repetida = replay sem novo consumo. Segundo store: QA não conforme = `QUARANTINE_EVIDENCE`, estoque intacto. Terceiro store: ACK perdido após commit, produto recuperado sem novo débito e sidecar reconstruído da evidência pré-registrada.

A alocação de 18+12 cm é **PROJETO/TEST**, não um dado PS. Os dois painéis, cada um com fonte retangular mínima proposta 60×30 mm e destino 50×20 mm, deixam diferença geométrica ideal de 800 mm² por placa; espessura, perda de massa e força de articulação são **PENDENTES**. A R48 não serializa massa de aparas de quitina e o sidecar não a inventa.

**Auditoria independente do motor, dentro desta instância:** 3/3 stores íntegros, 2/2 anexos vinculados, adulteração rejeitada, com 2 unidades TEST no total em stores separadas. Essa auditoria não equivale a homologação pela Coordenação.

## RC5 e denominações separadas

- **B30-22 RC2:** BOM e origem em projeto; **RC3:** processo TEST executado; **RC4 HOLD:** qualidade física/união, operador e condições; **RC5 HOLD:** mérito independente versus capa comum, conhecimento e economia aplicável. Não é estojo universal nem estanque.
- **B30-01 RC2:** auxiliar abrasivo `a_s` ainda indefinido; **RC3:** procedimento histórico completo em projeto; **RC4 HOLD:** QA/ofício/condições; **RC5 HOLD:** gabarito comum de mesmo uso, linhagem e economia.
- **B30-03 RC5 HOLD:** consumidor/encaixe real indeterminado; duas dimensões corrigidas em FC27. **B30-06 RC5 HOLD:** invólucro poroso não vinculado a fonte.
- Sem ensaio físico terrestre universal; ausência de medição não foi convertida em permissão para criar propriedades PS nem em exigência arbitrária.

## DENOMINATORS · CONFLICTS · UNKNOWN-EFFECT

**30/30** fichas PS históricas, **23 PRE-Q2**, **7 PRE-Q1**, **26** lacunas R49 preservadas. Nesta execução: **1** tipo B30-22 processado novamente para nova função de rastreabilidade, **2 produtos TEST** em dois stores separados, **2 pedidos TEST negativos** (escassez e QA), **0 RC5 técnico PASS**, **0/30 REC-ID oficial**, **0/30 cobertura oficial**, **0 produtos de campanha**. Não somar TEST à quota.

**CONFLICTS:** FC25 atribuía dimensões e rendimento de tábua à mica; errata aditiva corrige. B30-01 sem receita equivalente validada globalmente; B30-22 sem mérito material particular. Sidecar não substitui registro nativo de resíduo por massa.

**UNKNOWN-EFFECT:** C19-021; checkpoint órfão FC04 intacto. **AUTHORITY/WRITER STATE:** F5 RED, IBX-38/78 abertos conforme última leitura transmitida, writer não comprovado, Notion do Executor retornou `link_id must identify an eligible linked account`. Nenhuma gravação Notion/REC-LIB/Party/O Primeiro.

**NAC-PASS-02:** PASS proporcional à integridade e reprodução TEST local; HOLD para qualificação RC5, operação produtiva e publicação. **NO-REPEAT:** R44–R48 originais, draft e execução FC04, 26 gaps R49 e checkpoints históricos não modificados.

## NEXT-5, FIRST-PENDING e TARGET-REMAINDER

1. Reabrir leitura legítima do acervo para confrontar B30-01 com gabarito 2D equivalente real; nenhuma ausência global foi certificada.
2. Completar auxiliar abrasivo, ofício e economia de B30-01 por fonte/autoridade sem lançar números arbitrários.
3. Para B30-22, encontrar uso/fecho legitimamente verificável e qualificação de fibra/quitina; sem superioridade pressuposta.
4. Reavaliar RC2–RC5 com a evidência real nova; não repetir R48 sem defeito.
5. Coordenação: tratar IBX-38/fencing C19, C19-021 e IBX-78; somente após RC5 PASS, writer exclusivo e NAC-PASS abrir mínimo write-set oficial.

**LAST-VERIFIED-UNIT:** `outputs/fc36_independent_readback.json` com R48 principal sequência 2 e ACK recuperado sequência 1.
**FIRST-PENDING:** leitura competente da linhagem B30-01 e da função/articulação B30-22.
**TARGET-REMAINDER:** primeiro RC5 técnico legítimo, depois 30 REC-IDs distintos e cobertura PS 30/30 sem duplicação.
**Ponto exato de sucessão:** `outputs/FC36_succession_checkpoint.json` → `outputs/FC34_RC5_gates_disabled_write_set.json`.
