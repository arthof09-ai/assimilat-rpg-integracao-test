from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from decimal import Decimal
import json,hashlib
R=Path(__file__).resolve().parent
O=R/'outputs'; O.mkdir(exist_ok=True)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name,d):
 p=O/name;p.write_text(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n','utf8')
source_refs={
'B30-01':'https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2',
'B30-03':'https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84',
'B30-06':'https://app.notion.com/p/3f3c2b324ede819695d6e7797fd94370',
'B30-22-quitina':'https://app.notion.com/p/3f3c2b324ede8141acddf0bb23ffe56c',
'B30-22-fibra':'https://app.notion.com/p/3f3c2b324ede815ab04ace5bd1074e79'}
fc25=json.load(open('/mnt/data/CRAFT-FC25-FC26-DELTA-20261016/outputs/FC25_R49_R52_AUTHENTICATED_GAPS.json'))
original_mica=[g for g in fc25['gaps'] if g['design_id']=='B30-03']
errata={'schema':'CRAFT-FC27-ADDITIVE-ERRATA-v1','original_preserved':True,
 'source_fc25_file_sha256':h('/mnt/data/CRAFT-FC25-FC26-DELTA-20261016/outputs/FC25_R49_R52_AUTHENTICATED_GAPS.json'),
 'scope':'ONLY DERIVED MAPPING ERRORS; R49 26 GAP ROWS NOT RETROACTIVELY CLOSED',
 'B30-01':{'input':'1 lamina >=130x90x9 mm','output':'1 tabua alvo 120x80x8 mm','per_attempt':'1_PASS or 0_REJECT'},
 'B30-03':{'input':'2 folhas de mica, cada >=60x30 mm','output':'1 PAR DE 2 pecas 50x20 mm','thickness':'t_lote UNKNOWN; measure fitting context','paired_difference_max_mm':'0.1 PROPOSED NOT SOURCE MEASUREMENT','per_attempt':'1 approved pair or 0; NOT 1 slate board'},
 'corrective_rows':[{'source_r49_gap':g['r49_gap'],'original_fc25_text':g['fc25_interpretation'],
  'corrected_mapping':'Mica: 2 leaves >=60x30; 2 spacers 50x20; thickness and mounting gap unknown; count pairs not boards'}
  for g in original_mica if ('130x90x9' in g['fc25_interpretation'] or '0/1' in g['fc25_interpretation'])],
 'material_closures_new':0,'gaps_R49_total':26,'notion_live_readback':'NOT_AVAILABLE_EXECUTOR_LINK_ID'}
dump('FC27_aditiva_errata_B30_03.json',errata)
# Retrieve nested *actual R50* anti-duplicate evidence, no invented Notion IDs.
z=ZipFile('/mnt/data/craft_recovery/CRAFT-COMESTRE-CHAT-v03.zip')
r52=ZipFile(BytesIO(z.read([p for p in z.namelist() if 'CRAFT-R52-' in p][0])))
r51=ZipFile(BytesIO(r52.read([p for p in r52.namelist() if p.endswith('.zip')][0])))
r50=ZipFile(BytesIO(r51.read([p for p in r51.namelist() if p.endswith('.zip')][0])))
p='CRAFT-R50-SANDBOX-I0016/results/R50_DUPLICATAS_EQUIVALENCIAS.json'
actual=json.loads(r50.read(p))
entries=[e for e in actual['entries'] if e['design']=='B30-01' or e['decision'].startswith('EXISTING_NOT_REUSABLE')]
lineage={'schema':'FC28-SCOPED-LINEAGE-READBACK-v1',
 'source':'CRAFT v03 > R52 > R51 > R50 / results/R50_DUPLICATAS_EQUIVALENCIAS.json',
 'source_sha256':hashlib.sha256(r50.read(p)).hexdigest(),'source_scope':actual['search_scope'],
 'authoritative_source':'HISTORICAL_R50_RECOVERED_BINARILY; NOT_LIVE_NOTION_REFRESH',
 'B30_01':{'function':'2D mechanical marking template',
 'same_design_aliases':['Tabua Lamelar de Inscricao','Tabua Lamelar de Ardosia'],
 'source_pages':[source_refs['B30-01']],'recovered_R50_objects':entries,
 'compared_B30_21':'1D linear ruler proposal; not mechanically equivalent to 2D template, though can assist grid calibration',
 'material_indispensability':'NOT_DEMONSTRATED; PS slate is an optional candidate substrate',
 'existing_base_recipe_id':None,
 'verdict':'HOLD_SINGLE_FUNCTIONAL_RECIPE_VS_GENERIC_VARIANT; conditional NEW not authorized without final competent search',
 'REC_LIN_SUB':'S0/S1/S2 not assignable to a nonexistent physical base; common board functional interchangeability is only INFERRED',
 'minimum_external_evidence':'read competent physical recipe/item directory for 2D marking board and confirm exact product/source or absence within authorized scope'},
 'global_absence_certified':False,'new_rec_id':None}
dump('FC28_lineage_B30_01_R50_physical_evidence.json',lineage)
contract={'schema':'FC29-B30-22-EXPERIMENTAL-REUSE-v1','design_id':'B30-22',
 'baseline_recipe':'CRAFT-FAST-CLOSE-03/recipes/B30-22-TEST.json',
 'baseline_adapter':'CRAFT-R48-B30-22-FC04/code/r48_b30_adapter.py',
 'already_materialized_in_FC04':True,'scope':'TEST_ONLY','official_rec_id':None,
 'materials':[{'url':source_refs['B30-22-quitina'],'qty':2,'unit':'placa','min_dimensions_mm_proposed':[60,30],
  'role':'rigid covers','physical_strength':'UNKNOWN'},
  {'url':source_refs['B30-22-fibra'],'qty':30,'unit':'cm','role':'flexible joint and proposed lacing','physical_strength':'UNKNOWN'}],
 'component_allocation_proposed':{'fiber_joint_cm':18,'fiber_closure_cm':12,'unallocated_cm':0},
 'output':'one 2-panel mechanical cover for FLAT INERT samples, not a sealed general container',
 'geometry_proposed':{'panel_mm':[50,20],'clearance_depth_mm':None,'hole_spacing_mm':None},
 'steps':['inspect panels','cut','drill','join with source fiber directly','lace closure','finish edges','QA'],
 'tools_proposed':['fine cutter','perforator','straightedge','clamp','dust/shard protection'],
 'knowledge_proposed':['rigid panel craft','fiber joining','dimension/inspection'],
 'qa_proposed':['source/correct lots','2 panels intact','closure fastens in TEST','retains flat test sample under fixture conditions','no dangerous exposed edges'],
 'qa_not_measured':['real hinge wear','seal','retention force','humidity response','material strength','real offcut mass'],
 'negative_codes':['INSUFFICIENT_STOCK','CRITICAL_CRACK','INVALID_FIBER_LENGTH_PARTITION','EVIDENCE_QUARANTINE'],
 'anti_duplicate':'Generic planar hinged cover comparator; physical advantage for PS material NOT established',
 'source_type':'prior PS identities and engineering TEST; Notion reread executor unavailable'}
dump('FC29_B30_22_contract_provenance.json',contract)
execresult=json.load(open(O/'FC30_R48_NEW_EXECUTION/fc30_execution_results.json'))
readback=json.load(open(O/'fc36_independent_readback.json'))
trace={'schema':'FC31-FC32-CAUSAL-QUALITY-v1','source_run':'FC30_R48_NEW_EXECUTION',
 'run_ids':execresult['run_ids'],'reused_original_R48':True,'fc04_adapter_original_untouched':True,
 'cases':{
 'positive':{'result':'EXPERIMENTAL_QA_PASS','product_count':1,'new_execution':True},
 'scarcity':{'result':execresult['insufficient_stock'],'effect':'no further product'},
 'quality':{'result':execresult['quality_rejection'],'effect':'zero stock/product effects for rejected order'},
 'concurrency':{'evidence':'historic FC04 tests test_concurrent_requests_no_oversell; not rerun in FC31', 'new_execution':False},
 'interruption':{'result':execresult['lost_ack'],'recovery':'R48 commit survived, replay did not consume again'},
 'idempotence':{'result':execresult['idempotent_replay']},
 'material_partition_guard':{'cases':execresult['rejected_preflights'],'new_execution':True},
 'sidecar_tamper':{'detected_in_memory':readback['metrics']['tamper_rejected'],'new_execution':True}},
 'scientific_boundaries':{'fiber_18_plus_12':'proposal ONLY','unknown_actual_scrap_mass':True,
 'panel_geometry':'ideal proposed rectangular analysis only','closure_retention':'signed synthetic QA BOOL not physical',
 'official_materiality':False},
 'native_R48_waste_ledger_for_panel_area':'NOT_IMPLEMENTED; separate sidecar is not native scrap ledger',
 'sidecar_recovery':'Recover from PRE-COMMITTED plan and committed R48 journal; no fabrication retry',
 'new_capability':'R48 receipt-bound material-role allocation, deterministic sidecar recovery and independent tamper check'}
dump('FC31_FC32_recovery_qa_scientific_limits.json',trace)
cost={'schema':'FC33-PR-ECO-COST-TREE-v1',
 'source':'PR-ECO-01 Anexo C (historic authorized formula supplied in task)',
 'CTE':'CI+CP+CF+CT+CE+CK+CL+CA+CC',
 'unit':'MED_UNDETERMINED','synthetic_computable_unit':'u_TEST',
 'CI':{'chitin_panels':'2*P_chitin_panel_qualified','fiber':'0.30m*P_fiber_per_meter',
       'consumables':'P_drill_bit_wear_consumed+P_protection_used; only if actually consumed',
       'source_prices':None,'epoch':None},
 'CP':{'residues':'C_disposal+unrecovered offcut values','offcut_mass':None,'no_double_count_with_CI':True},
 'CF':{'rework_and_failed_units':'C_failed_attempts+rework','rate':None},
 'CT':{'labor':'(t_cut+t_drill+t_joint+t_finish+t_QA+t_setup+t_rework)*w_labor_time',
       'duration_proposed_minutes':45,'duration_real':None},
 'CE':{'tools':'amortized_cutting+perforator+measuring+clamps+energy; reusable not CI again'},
 'CK':{'competence':'qualified_craft_knowledge_required','RPG_professional_verified':False},
 'CL':{'logistics':'transport per origin and epoch','price':None},
 'CA':{'conservation':'storage+contamination_prevention','price':None},
 'CC':{'capital':'working_capital+opportunity_cost','price':None},
 'CTE_per_PASS':'CTE_lot/N_QA_PASS if N_QA_PASS>0 else UNDEFINED',
 'scenarios':{
 'favorable':'one approved, no repeat, unknown input prices','normal':'retrabalho conditional, variables not probabilities',
 'adverse':'QA rejects and variable wasted material; unit cost undefined if zero approved'},
 'noncanonical_price_warning':'No MED, wages, trade location or epoch asserted',
 'executable_model':'code/fc33_cte.py'}
dump('FC33_pr_eco_cost_tree.json',cost)
rc5={'schema':'FC34-RC5-TECH-ASSESSMENT-v1','as_of':'2026-10-16','operation':'OP-ARQ-RIN-REC-01',
 'B30_22':{'RC2':'DESIGN_PASS: 2 chitin panels PS + 30cm source fiber; proposed quantities/units',
 'RC3':'TEST_EXECUTED: process steps, roles and receipt-replay; physical junction mechanism not source-certified',
 'RC4':'HOLD: productive process requires accepted hole/closure geometry, material quality, operator/knowledge, conditions, time, residue handling and rework',
 'RC5':'HOLD: differential merit vs common cover, effective retention, cost applicability, competent knowledge and source/lineage/JIT',
 'rc5_tech':'HOLD','rc5_official':False,
 'smallest_decisive_fact':'competent source/admission for specific protected sample and functional 2-panel closure, with accepted QA/knowledge and permissible economic parameters',
 'campaign_knowledge':'NONE_GRANTABLE_AUTOMATICALLY','PS_P4':'NO_PROMOTION'},
 'B30_01':{'RC2':'HOLD consumable a_s and disposition vs reusable abrasive tool',
 'RC3':'DESIGN_PASS historical R42/FC06','RC4':'HOLD accepted measurement/QA and competent procedure/economics',
 'RC5':'HOLD anti-dup/function of 2D board vs existing generic recipe; master/competent source gate',
 'rc5_tech':'HOLD','rc5_official':False,
 'smallest_decisive_fact':'physical comparable 2D reference gabarito recipe or validated one-material-conditional functional recipe; then auxiliary consumables and economic knowledge'},
 'B30_03':{'rc5_tech':'HOLD','smallest_decisive_fact':'verified consuming assembly that requires mica spacer tolerance; R50 similar design conflict'},
 'B30_06':{'rc5_tech':'HOLD','smallest_decisive_fact':'existing legitimate breathable enclosure or redefine loose refill; adsorption benefit still unknown'},
 'preferred_technical_frontier':'B30-01 scoped anti-dup and accessory BOM; B30-22 already functionally TEST but material merit unresolved',
 'none_RC5_tech_pass':True,
 'disabled_write_set':{'enabled':False,'draft_parent':'REC-LIB-01 actual physical parent UNKNOWN; IBX-78 NOVA as of Coordinator',
 'recipe_id':None,'official_product_id':None,'source_PS_links':['B30-01','B30-22'],
 'requirements_before_enable':['competent RC5 PASS','IBX38 actual fencing C19','C19-021 UNKNOWN effect reconciliation','IBX78 unique valid destination','specific writer grant and NAC PASS','readback']},
 'no_campaign_claims':True}
dump('FC34_RC5_gates_disabled_write_set.json',rc5)
portfolio=json.load(open('/mnt/data/CRAFT-FC09-FC18-DELTA-20261016/outputs/FC17_portfolio_30.json'))
transfer={'schema':'FC35-EXISTING-BACKFILL30-DEPENDENCY-DELTA-v1',
 'historic_portfolio_checksum':h('/mnt/data/CRAFT-FC09-FC18-DELTA-20261016/outputs/FC17_portfolio_30.json'),
 'resource_count':len(portfolio['items']),'original_candidates_mutated':0,
 'engineering_reuse_opportunities':[
 {'candidate':'B30-19','resource_url':next(x['resource_url'] for x in portfolio['items'] if x['b30']=='B30-19'),
  'reusable':'closure QA/assembly/edge inspection and ledger reservation FC30','gate':'flexible-skin cover is a different material; actual envelope/closure merits and source knowledge unverified'},
 {'candidate':'B30-08','resource_url':next(x['resource_url'] for x in portfolio['items'] if x['b30']=='B30-08'),
  'reusable':'fit/contact geometry and reusable tools accounting FC30','gate':'a real host tool and mating dimensions must be source-bound'},
 {'candidate':'B30-22','resource_url':next(x['resource_url'] for x in portfolio['items'] if x['b30']=='B30-22'),
  'reusable':'R48 stock/replay plus material-allocation sidecar with source roles','gate':'physical hinge/retention/knowledge still not demonstrated'},
 {'candidate':'B30-01','resource_url':next(x['resource_url'] for x in portfolio['items'] if x['b30']=='B30-01'),
  'reusable':'QA consistency, abrasive consumable vs reusable equipment, PR-ECO parameter validator','gate':'abrasive used amount and source-bound competent 2D gabarito alternative'},
 {'candidate':'B30-13','resource_url':next(x['resource_url'] for x in portfolio['items'] if x['b30']=='B30-13'),
  'reusable':'source/consumable reconciliation and no-phantom-yield QA','gate':'volume mixing/compaction and legitimate agronomic use remain unknown'}],
 'official_distinct_REC_IDs':0,'official_resources_covered':0,'resource_target':30,
 'historical_preparation':{'PRE-Q2':23,'PRE-Q1':7},'notes':'Existing R42 portfolio items are proposals, not RC5 coverage. No new IDs.'}
dump('FC35_portfolio_reuse_delta.json',transfer)
checkpoint={'schema':'FC36-PSV-CHECKPOINT-v1','as_of':'2026-10-16',
 'operation':'OP-ARQ-RIN-REC-01','ws':'CM-000002-WS0001',
 'baseline':'R01-R52 BACKFILL30 FC01-FC26 preserved',
 'last_verified_unit':'outputs/fc36_independent_readback.json + outputs/FC30_R48_NEW_EXECUTION (CASE_MAIN_STORE seq 2; LOST_ACK seq 1)',
 'first_pending':'competent material and knowledge basis for B30-22 hinge/retention and B30-01 material/functional lineage under read-only Notion authority',
 'FC27_FC36':{
 'FC27':'DONE errata of two false mica mappings; history intact','FC28':'DONE R50 scoped lineage readback; global absence not certified',
 'FC29':'DONE source-bounded B30-22 TEST contract reused','FC30':'DONE new R48 run and R44 product id with material annex',
 'FC31':'DONE new shortage, QA, idempotency and ack recovery; concurrency evidence retained FC04 not repeated',
 'FC32':'DONE QA classification; no real material measurements','FC33':'DONE reusable cost evaluator and parametric formula',
 'FC34':'DONE terminal technical HOLD no faux RC5','FC35':'DONE 5 reuse targets incl >=3 actionable opportunities',
 'FC36':'DONE independent local readback plus delta manifest; Notion readback PENDING'},
 'counts':{'historical_PS':30,'PRE_Q2':23,'PRE_Q1':7,'R49_historical_gaps':26,
  'FC30_distinct_recipe_types_executed':1,'FC30_new_successful_TEST_instances':2,
  'FC30_new_rejection_orders':2,'FC30_main_successful_units':1,
  'RC5_tech_pass':0,'official_REC_ID':0,'official_coverage':0,'official_products':0},
 'authority':{'F5':'RED','C19_021':'UNKNOWN_EFFECT','IBX_38':'NOVA per Coordinator last readback',
              'IBX_78':'NOVA per Coordinator last readback','writer':'NOT_GRANTED',
              'notion_connection':'link_id must identify an eligible linked account',
              'notion_writes':0,'party_writes':0,'o_primeiro_writes':0},
 'conflicts':['FC25 mica dimensions/count mapped from B30-01: corrected by addendum',
              'R50 generic gabarito search limited: cannot assert absence globally',
              'material sidecar not native R48 waste ledger; unknown real scrap mass',
              'FC04 already had B30-22 in R48: FC30 is a fresh run with new allocation/recovery gate, NOT first third-recipe integration'],
 'unknown_effects':['C19-021','FC04_ORPHAN_FAIL_CLOSED_STORE preserved'],
 'no_repeat':['R44-R48 unchanged','FC04 prior triple batch untouched','R49 26 gaps unchanged',
 'FC06/07 tests not rerun','no draft commit','no official NC/P4 or Party write'],
 'next_5':['Resolve physical 2D gabarito equivalent in REC-LIB through authorized Notion readback',
 'Settle B30-01 abrasive use status/quantity and operator with competent authority',
 'Find accepted hinge/closure function for B30-22 (flat inert samples only), not synthetic premium claims',
 'Qualify PR-ECO cost/knowledge/QA as actual competent RPG parameters; rerun RC5 tech gate',
 'Coordination IBX38/78/C19 technical fencing + explicit writer only after candidate RC5 eligible'],
 'target_remainder':{'RC5_official':30,'RC5_coverage_resources':30,'current_official':0,
                     'next_technical_goal':'one genuinely RC5 eligible recipe; blockers outside simulation'},
 'resume_at':'outputs/FC34_RC5_gates_disabled_write_set.json and outputs/fc36_independent_readback.json'}
dump('FC36_succession_checkpoint.json',checkpoint)
print('artifacts generated')
