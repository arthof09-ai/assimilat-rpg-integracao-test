# CRAFT — FC27–FC36, delta experimental aditivo (MESTRE-SIDE)

**Identidade:** CM-000002 / WS0001 / OP-ARQ-RIN-REC-01, 16/10/2026.
**Âmbito:** somente laboratório TEST, sem materialização RC5, sem modificação a Party/O Primeiro/estoque de campanha.

## Descoberta que altera o plano de execução

A B30-22 já estava integrada à R48 no delta FC04; a prova histórica inclui B30-01/03/22, recibos R47, produto TEST, QA negativo, oversell, idempotência, checkpoint órfão bloqueado e recuperação após ACK perdido. **Não contar a repetição da terceira receita como capacidade inédita em FC30.**

O avanço novo FC30–FC33 é uma **alocação de papéis materiais vinculada ao recibo nativo do R48**, com rejeição prévia de partição inválida, reconstrução determinística do registro adicional após perda de confirmação e auditoria externa ao código de fabricação. É camada experimental complementar; **não é um ledger de massas nativo do R48**. A massa de aparas de quitina permanece desconhecida, mesmo que a geometria ideal proposta determine áreas.

## Prerrequisitos autenticados pela execução FC27

| Pacote anterior | SHA-256 |
|---|---|
| `CRAFT-COMESTRE-CHAT-v03.zip` | `5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434` |
| `CRAFT-FAST-CLOSE-03-DELTA-20261016.zip` | `72fba831198de4701ee0e0b6d50abda594cf6ec4223c0955fe36e92c92f5e2c4` |
| `CRAFT-R48-B30-22-FC04-DELTA-20261016.zip` | `5756bdf2e6e0550336d483c0c749a411ab345bf39b1168d585d1a883f077bf9b` |
| `CRAFT-FC25-FC26-DELTA-20261016.zip` | `4856bc9f96486bf0a710f58e1d94d1d174e5fa87df92d3495d5e797349253477` |

O ZIP v03 contém 205 arquivos e a árvore original R48 tem 174 arquivos. Não modificar esses pacotes ou o FC04 `ACCEPTED_V2`. O draft `SBX-R48-BATCH-UI-2afb696406a6e839` e o órfão FC04 continuam preservados.

## Execução feita nesta sessão

1. R48 original carregado da cópia autenticada; FC04 apenas como adaptador da terceira receita/R47 TEST.
2. `outputs/FC30_R48_NEW_EXECUTION/CASE_MAIN_STORE`: pedido B30-22 `...92701` aprovado, 2 placas e 30 cm de fibra debitados; um produto TEST gerado. A nova tentativa `...92702` é `REJECTED_PRECHECK` por insumo insuficiente; repetição do primeiro lote foi idempotente.
3. `CASE_QA_REJECT_STORE`: `...92703`, `QUARANTINE_EVIDENCE`, nenhuma perda de estoque.
4. `CASE_LOST_ACK_STORE`: `...92704` foi efetivamente comitado; a confirmação foi perdida. R48 recuperou o mesmo commit e recusou dupla fabricação; o anexo ausente foi reconstruído do plano pré-registrado + journal comitado.
5. Partição de projeto 18 cm para articulação e 12 cm para o fechamento. Uma alocação 19+12 e um painel 65×20 diante de fonte 60×30 foram rejeitados antes do processo. **Os valores 18 e 12 são PROPOSTOS; força, desgaste e massa de aparas não foram medidos.**
6. `outputs/fc36_independent_readback.json`: leitura com biblioteca padrão, auditoria de hash-chain R48/44/47/46, estoque, produto e vinculação de anexo/planos, além de adulteração simulada **somente em memória**. **3/3 stores, 2/2 anexos e adulteração detectada.** A auditoria é independente do *motor*, mas é produzida nesta mesma instância executora, não pela Coordenação.

**Resultados materiais:** 2 unidades TEST B30-22 geradas nesta execução em duas stores isoladas (uma normal, uma após perda de ACK), 2 rejeições TEST, zero item em campanha. Isso não é nova *família* de receita: B30-22 já existia em FC04.

## Leitura independente após extração limpa

Use uma cópia integral dos dois pacotes base, sem alterar originais. Extraia o v03 em `scratch/CRAFT-FAST-CLOSE-03/inputs/CRAFT-COMESTRE-CHAT-v03`, FC03 em `scratch/CRAFT-FAST-CLOSE-03/` e FC04 em `scratch/CRAFT-R48-B30-22-FC04/`. Mantenha **este** delta em sua própria pasta. Os scripts usam biblioteca Python padrão exceto a execução R48, que requer `cryptography` como FC04.

```bash
# Apenas leitura. Não invoca o motor nem altera as stores.
python CRAFT-FC27-FC36-DELTA-20261016/code/fc36_independent_audit.py \
  CRAFT-FC27-FC36-DELTA-20261016/outputs/FC30_R48_NEW_EXECUTION \
  --fc04-root scratch/CRAFT-R48-B30-22-FC04

# Modelo econômico; os números de teste são em u_TEST, jamais em MED.
python CRAFT-FC27-FC36-DELTA-20261016/code/fc33_cte.py
```

Para nova fabricação **somente em uma extração nova do delta, sem stores existentes**, defina `CRAFT_FC03_ROOT` apontando para `scratch/CRAFT-FAST-CLOSE-03` e `CRAFT_FC04_ROOT` para `scratch/CRAFT-R48-B30-22-FC04` e rode `code/fc30_material_trace.py`. O script recusa sobrescrever qualquer store já existente. Não é necessário repetir esse experimento para aceitar os resultados armazenados.

## Estado normativo e entrada na próxima sucessão

- RC5-TECH PASS: **0**. Publicação: **0/30 REC-IDs; 0/30 cobertura PS**, zero produtos oficiais.
- IBX-38/IBX-78: pendências existentes da Coordenação; F5 RED e C19-021 UNKNOWN-EFFECT. Fencing e writer produtivo não comprovados.
- Notion: `link_id must identify an eligible linked account` na instância executora. O registro na operação/Diário canônicos está **PENDENTE**. Nenhuma edição foi realizada em Notion.
- `outputs/FC27_aditiva_errata_B30_03.json`: errata **somente derivada**, não modifica R49/FC25.
- `outputs/FC28_lineage_B30_01_R50_physical_evidence.json`: anti-duplicatas R50 com fonte binária recuperada; comparação global segue limitada.
- `outputs/FC34_RC5_gates_disabled_write_set.json`: primeira fronteira técnica para a sucessão.
- `outputs/FC36_succession_checkpoint.json`: snapshot global do escopo e `NEXT-5`.

**Gate NAC-PASS proporcional:** PASS de integridade local, transação sintética e anexo independente; HOLD de propriedades materiais, RC5 técnico, admissão canônica e publicação. R44–R48 e FC01–FC26 são NO-REPEAT, exceto defeito novo diretamente demonstrado.
