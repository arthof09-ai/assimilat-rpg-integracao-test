"""Uncertainty analysis descriptive ONLY; obsolete historic Notion ranks are NOT ground truth."""
import json,os,collections
B=os.path.dirname(__file__)
rows=json.load(open(B+'/ANALISE_CONCORDANCIA_MESTRE_ONLY.json'))['pairs']
R={'Bronze':0,'Prata':1,'Ouro':2,'Ouro Negro':3,'Lendário':4}
assert len(rows)==26
out=[]
for r in rows:
 lower,upper=r['proposed_interval'].split('–');hist=r['historic_rank'];proposed=r['provisional_rank_test'];low_i=R[lower];high_i=R[upper];hist_i=R[hist]
 assert low_i<=R[proposed]<=high_i
 out.append({'case_id':r['case_id'],'historic_rank_for_mestre_only':hist,'range_test':r['proposed_interval'],'historic_in_uncertainty_range':low_i<=hist_i<=high_i,'signed_gap':R[proposed]-hist_i,'adjudication_priority':'HIGH' if (low_i<=hist_i<=high_i)==False else 'NORMAL','disagreement_is_error':None})
summary={'n':len(rows),'ranges_cover_legacy':sum(x['historic_in_uncertainty_range'] for x in out),'outside_legacy':sum(not x['historic_in_uncertainty_range'] for x in out),'under_legacy':sum(x['signed_gap']<0 for x in out),'above_legacy':sum(x['signed_gap']>0 for x in out),'exact_legacy':sum(x['signed_gap']==0 for x in out),'mean_signed_rank_gap_test_minus_legacy':round(sum(x['signed_gap'] for x in out)/26,4),'meaning':'Only compares E3 candidate severity/uncertainty to informally labeled historical list. A downward systematic shift can reflect either source/system differences, conservative evaluator, or historical overestimation; adjudicator must not prefer labels by default.','valid_precision_against_canon_gold':None}
json.dump({'summary':summary,'rows':out},open(B+'/SENSIBILIDADE_CONCORDANCIA_MESTRE_ONLY.json','w'),indent=2,ensure_ascii=False)
print(summary)
