"""R45 TEST: diagnostics of observed source dice. DO NOT infer RE from damage before Atlas."""
import json,re,os,statistics
B=os.path.dirname(__file__)
corpus=json.load(open(B+'/CORPUS_MECANICO_MANUAL_CEGO.json'))['cases']
RANGES={'Bronze':(4,18),'Prata':(14,36),'Ouro':(22,62),'Ouro Negro':(38,96),'Lendário':(58,160)}
pattern=re.compile(r'(?<!\d)([+-]?)(\d+)\s*d\s*(\d+)',flags=re.I)
def dice(text):
 if not text:return []
 out=[]
 for m in pattern.finditer(text):
  sign=-1 if m.group(1)=='-' else 1; n=int(m.group(2));s=int(m.group(3));
  if n<1 or s<2 or n>100 or s>1000:raise ValueError('dice out of bounds')
  out.append({'dice':f'{sign*n}d{s}', 'n':n,'sides':s,'average':sign*n*(s+1)/2,'minimum':sign*n,'maximum':sign*n*s})
 return out
out=[]
for row in corpus:
 comp=dice(row['source_damage_expression'])
 scope='SINGLE_INSTANT_DAMAGE' if row['effect_family']=='dano' and len(comp)==1 and 'por' not in (row['source_damage_expression'] or '').lower() and 'adicional' not in (row['source_damage_expression'] or '').lower() else 'COMPLEX_OR_MIXED'
 if not comp:scope='NO_INTRINSIC_DAMAGE_QUANTIFIED'
 # Damage of a single event only; no conversion to probability expectation (missing defenses/saving chance).
 out.append({'case_id':row['case_id'],'component_count':len(comp),'components':comp,'raw_sum_mean_for_illustration_only':sum(x['average'] for x in comp) if comp else None,'dme_applicability':scope,'overlapping_rank_dmg_bands':([k for k,(lo,hi) in RANGES.items() if lo<=comp[0]['average']<=hi] if len(comp)==1 and scope=='SINGLE_INSTANT_DAMAGE' else None), 'notes':'Mean of event dice conditional on trigger; does not model save, area, repetition, upcast, attack hit probability, item potency. Not a rank classifier.'})
summary={'n_cases':len(corpus),'quantified_source_damage':sum(bool(x['components']) for x in out),'zero_numeric_damage':sum(not bool(x['components']) for x in out),'single_event_unconditional_candidate':sum(x['dme_applicability']=='SINGLE_INSTANT_DAMAGE' for x in out),'ambiguous_complex_or_conditional':sum(x['dme_applicability']=='COMPLEX_OR_MIXED' for x in out),'not_scientific_accuracy':True,'band_authority':'DMG-RANK-01 v1.1, Notion Mestre, sourced 2026-10-21'}
open(B+'/DME_PARTIAL_DIAGNOSTIC.json','w').write(json.dumps({'summary':summary,'rows':out},ensure_ascii=False,indent=2))
print(summary)
