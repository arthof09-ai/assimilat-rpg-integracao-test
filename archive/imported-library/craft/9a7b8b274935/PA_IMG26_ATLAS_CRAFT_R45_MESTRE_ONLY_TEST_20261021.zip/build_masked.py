"""Redact only foreign-RPG level footer for independent assessor; never touch originals."""
import os,hashlib,json
from PIL import Image, ImageDraw
B=os.path.dirname(__file__);out=B+'/BLIND_NATIVE_LEVEL_MASKED';os.makedirs(out,exist_ok=True)
R=[]
for a in json.load(open(B+'/SOURCE_AUDIT.json'))['images']:
 src=f"{B}/images/{a['anon_id']}.jpg";im=Image.open(src).convert('RGB')
 assert im.size==(700,1013)
 # Bottom band contains origin's 'TRUQUE' / 'MAGIA DE NÍVEL X'. In the cropped
 # records observed source mechanics end above y=924. Mask left/right inner footer
 # leaving margins and upper mechanics untouched. No OCR is used.
 bounds=(55,932,646,998)
 ImageDraw.Draw(im).rectangle(bounds,fill=(235,228,209))
 fp=f"{out}/{a['anon_id']}.jpg";im.save(fp,format='JPEG',quality=96,subsampling=0,optimize=True)
 original=hashlib.sha256(open(src,'rb').read()).hexdigest();masked=hashlib.sha256(open(fp,'rb').read()).hexdigest()
 assert original==a['sha256'] and masked!=original
 R.append({'case_id':a['anon_id'],'source_sha256':original,'redacted_sha256':masked,'redaction_rectangle_px':list(bounds),'redacted_image':'BLIND_NATIVE_LEVEL_MASKED/'+a['anon_id']+'.jpg','width':700,'height':1013,'original_unchanged':True,'native_spell_level_hidden_in_footer':True,'still_not_guaranteed_independent_blind':'The visible title/foreign level scaling and prior evaluator knowledge may bias; independent adjudicator required'})
json.dump({'n':26,'use':'provisional independent test with footer containing foreign spell level hidden','method':'PIL rectangle; source unchanged; this is an edited derivative only','masked':R},open(B+'/MASKING_AUDIT.json','w'),indent=2)
print('MASKED',len(R),'totalBytes',sum(os.path.getsize(B+'/'+e['redacted_image']) for e in R))
