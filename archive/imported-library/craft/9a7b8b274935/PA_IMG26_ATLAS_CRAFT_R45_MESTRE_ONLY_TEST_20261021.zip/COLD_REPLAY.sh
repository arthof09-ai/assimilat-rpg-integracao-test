#!/bin/sh
set -eu
cd "$(dirname "$0")"
python analyze_components.py
python adapter_assimilacao.py
python craft_p2_stage.py
python sensitivity_analysis.py
python build_components.py
python build_masked.py
python -m unittest discover -s . -p 'test_*r45.py' -q
python - <<'PY'
import hashlib,json,os
raw=open('FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json','rb').read();expected=open('FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.sha256').read().split()[0]
assert hashlib.sha256(raw).hexdigest()==expected
print('FROZEN_PROPOSALS_SHA256_OK',expected)
PY
