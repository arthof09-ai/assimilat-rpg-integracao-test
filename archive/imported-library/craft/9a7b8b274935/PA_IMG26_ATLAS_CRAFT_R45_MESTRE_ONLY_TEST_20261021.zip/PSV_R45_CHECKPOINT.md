# PSV / NAC-PASS proporcional — PA IMG26 TEST / MESTRE-SIDE

**Ambiente:** Projeto Comestre, LAB TEST, não produção. **Nome de checkpoint:** PA-IMG26-SCI-20261021-001 (não reivindica reserva formal R45 na governança). **Classificação:** E3 PROPOSTA, sem alterar origem.

## PRESTATE verificável
- Notion canônico de Técnicas & Pergaminhos, Atlas A, DMG-RANK-01 v1.1, Sistema de Magia e Sistema de Combate foi consultado.
- 26 JPG da exportação fornecida pelo Mestre estavam recuperados e em pacote anonimizado, mas não havia avaliação mecânica das 26 nem comparação individual fundamentada.
- PA R26/R27 preservados; CRAFT H2-3/RC5 material continuavam HOLD; sal, energia e óleo P2 sem decisão homologada.
- Legado R42 continha 12 inscrições textuais; não confundir este lote com elas.

## AÇÕES REALIZADAS NESTE CICLO
1. Censo hash SHA-256 de 26/26 imagens, 7 folhas de contato e revisão visual manual uma vez para as 26.
2. 26 fichas mecânicas resumidas; campos por ação/duração/alcance/alvos/salvaguarda/dano, sempre fonte vs inferência separados.
3. Congelamento de 26 ranks candidatos TEST antes de abrir oráculo; SHA-256 `2f1e88e3c7980cf376ed2ec76816dec48d3f4779bec55a9f6e3bf5687e799a5e`.
4. Após freeze, comparação 8/26 rótulos legados coincidentes, 18 divergentes, 14/26 rótulos dentro das faixas de incerteza. Isso NÃO representa acurácia científica ou duplo-cego independente.
5. Extração 13/26 com dano numérico, 12 com teste de resistência indicado, 18 com dano OU resistência; 5 candidatos de dano simples e 8 compostos.
6. Portabilidade de 26 fontes externas: 7 truques, 17 nível 1, 2 nível 2; 6 usam Ação Bônus e 12 concentração, sem regra nativa automaticamente equivalente.
7. 67 subefeitos identificados e codificados, sem atribuir seu RE ou custo automaticamente.
8. 26 cópias visuais mascadas no rodapé de nível estrangeiro, com verificação de integridade dos originais.
9. CRAFT P2/Óleo: regras fonte confrontadas, preflight READ-ONLY documentado, 0 aplicação, 0 medições, 0 alteração das receitas. C0–C3 preparados para aplicação legítima.
10. Suíte automatizada com 168 casos PASS, cobrindo dados, fontes, hashes, freeze, compatibilidade, QA visual, CRAFT e provas negativas.

## GATES
- PASS: imagens reais, integridade, resumo fonte, comparação descritiva, QA TEST, preservação dos originais, separação Mestre/Party.
- HOLD: adjudicação RE sob 3 comparadores independentes do Atlas, adaptação de Ação Bônus e concentração, custo energético de habilidades importadas, classificação de 67 subefeitos, eficácia/magia H2 CRAFT, receita P2/Óleo, materiais/operador, fabricação RC5/P4/F5.
- Sem trabalho de O Primeiro ou Party, sem atualização de fichas ou R26/R27, sem débito de PA, sem novo REC-ID, sem falsa testemunha.

## NEXT HIGHEST VALUE
- Revisar os 12 casos cujas etiquetas históricas caem FORA até da faixa provisória, com comparadores vivos + sistema + família e um revisor independente.
- Alinhar 26 técnicas a sistema de ações, concentração, progresso e área do Assimilação em ambiente TEST, com autoridade especializada; não presumir ações de D&D.
- Receber resposta de autoridade para SALT/ENERGY e óleo na Inbox CRAFT existente, com lote e operador reais; depois testar instalação C0–C3.
- Retomar pela exata fonte original hash/case_id, nunca recriar páginas do acervo.
