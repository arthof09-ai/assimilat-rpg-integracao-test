import unittest,json,os,hashlib,zipfile,sys,collections,importlib.util,re
from pathlib import Path
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('analyze_components',B/'analyze_components.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
CORPUS=json.loads((B/'CORPUS_MECANICO_MANUAL_CEGO.json').read_text())
FROZEN=json.loads((B/'FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json').read_text())
AUDIT=json.loads((B/'SOURCE_AUDIT.json').read_text())
class AuditedCorpus(unittest.TestCase):
 def test_01_dataset_count(self):self.assertEqual(CORPUS['read_count'],26)
 def test_02_record_count(self):self.assertEqual(len(CORPUS['cases']),26)
 def test_03_ids_unique(self):self.assertEqual(len({r['case_id'] for r in CORPUS['cases']}),26)
 def test_04_source_hashes_unique(self):self.assertEqual(len({r['explicit_source_image_sha256'] for r in CORPUS['cases']}),26)
 def test_05_image_files_match_SHA(self):
  for r in CORPUS['cases']:
   with self.subTest(id=r['case_id']):
    img=(B/'images'/(r['case_id']+'.jpg')).read_bytes();self.assertEqual(hashlib.sha256(img).hexdigest(),r['explicit_source_image_sha256']);self.assertEqual(img[:3],b'\xff\xd8\xff')
 def test_06_manual_description_nonempty(self):self.assertTrue(all(r['observed_mechanic_facts'] and len(r['observed_mechanic_facts'])>30 for r in CORPUS['cases']))
 def test_07_all_have_timing(self):self.assertTrue(all(r['source_duration'] and r['source_activation'] for r in CORPUS['cases']))
 def test_08_all_have_range(self):self.assertTrue(all(r['source_range'] for r in CORPUS['cases']))
 def test_09_no_retroactive_change(self):self.assertTrue(all(r['power_rank_adjudication']!='OFFICIAL_CANON' for r in CORPUS['cases']))
 def test_10_legacy_rank_not_present_in_mechanic_rows(self):
  self.assertTrue(all('historic_rank' not in r and 'historic_name' not in r for r in CORPUS['cases']))
 def test_11_no_price_fields(self):self.assertTrue(all(not any('price' in k or 'preço' in k for k in r) for r in CORPUS['cases']))
 def test_12_no_owner_characters(self):self.assertTrue(all('Party' not in r['observed_mechanic_facts'] for r in CORPUS['cases']))
 def test_13_minimum_multiple_categories(self):self.assertGreaterEqual(len(set(r['effect_family'] for r in CORPUS['cases'])),6)
 def test_14_proposed_only_known_rank(self):self.assertTrue(all(r['rank_proposal_test_only'] in {'Bronze','Prata','Ouro','Ouro Negro','Lendário'} for r in CORPUS['cases']))
 def test_15_confidence_has_status(self):self.assertTrue(all(r['interpretation_evidence'] in ('E2','E3') for r in CORPUS['cases']))
 def test_16_corresponding_ids_match_freeze(self):self.assertEqual({r['case_id'] for r in CORPUS['cases']},{r['case_id'] for r in FROZEN['cases']})
 def test_17_freeze_is_verified(self):self.assertEqual(hashlib.sha256((B/'FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json').read_bytes()).hexdigest(),(B/'FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.sha256').read_text().split()[0])
 def test_18_freeze_values_match_source(self):
  source={r['case_id']:r for r in CORPUS['cases']}
  for c in FROZEN['cases']:
   self.assertEqual(c['proposed_rank'],source[c['case_id']]['rank_proposal_test_only'])
 def test_19_no_strict_blind_claim(self):self.assertTrue(FROZEN['not_strictly_blind'])
 def test_20_damage_method_requires_qualifier(self):self.assertIn('Not a rank classifier.',mod.out[0]['notes'])
 def test_21_no_cost_deduced(self):self.assertTrue(all('PA_spent' not in x and 'pa_dia' not in x for x in CORPUS['cases']))
 def test_22_source_zip_exists(self):self.assertEqual(len(AUDIT['images']),26)
 def test_23_AUDIT_hashes(self):
  a={r['anon_id']:r['sha256'] for r in AUDIT['images']}
  self.assertEqual({r['case_id']:r['explicit_source_image_sha256'] for r in CORPUS['cases']},a)
 def test_24_damage_n(self):self.assertEqual(mod.summary['quantified_source_damage'],13)
 def test_25_all_dice_parse_in_bound(self):
  for r in CORPUS['cases']:
   self.assertLessEqual(len(mod.dice(r['source_damage_expression'])),5)
 def test_26_simple_dice(self):self.assertEqual(mod.dice('1d10')[0]['average'],5.5)
 def test_27_complex_dice(self):self.assertEqual([x['average'] for x in mod.dice('1d10+2d6')],[5.5,7])
 def test_28_negative_dice(self):self.assertEqual(mod.dice('-1d4')[0]['average'],-2.5)
 def test_29_zero_dice_is_rejected(self):
  with self.assertRaises(ValueError):mod.dice('0d10')
 def test_30_zero_sides_rejected(self):
  with self.assertRaises(ValueError):mod.dice('1d1')
 def test_31_huge_dice_rejected(self):
  with self.assertRaises(ValueError):mod.dice('10000d20')
 def test_32_label_not_in_image_names(self):self.assertTrue(all(re.fullmatch('TEC-[0-9A-F]{12}',r['case_id']) for r in CORPUS['cases']))
 def test_33_case_study_ice_knife(self):
  r=next(x for x in CORPUS['cases'] if x['case_id']=='TEC-F1BD993CFF60');self.assertEqual(len(mod.dice(r['source_damage_expression'])),2)
 def test_34_case_study_bless_3(self):
  r=next(x for x in CORPUS['cases'] if x['case_id']=='TEC-320DB7B56AD0');self.assertEqual(r['target_count_or_area'],3)
 def test_35_instant_area_is_not_aggregate_damage(self):
  r=next(x for x in mod.out if x['case_id']=='TEC-F1BD993CFF60');self.assertEqual(r['dme_applicability'],'COMPLEX_OR_MIXED')
 def test_36_hard_control_no_raw_damage(self):
  r=next(x for x in CORPUS['cases'] if x['case_id']=='TEC-39F038CF281E');self.assertIsNone(r['source_damage_expression']);self.assertIn('paralisa',r['observed_mechanic_facts'])
 def test_37_legacy_assessment_marked_not_accuracy(self):
  x=json.loads((B/'ANALISE_CONCORDANCIA_MESTRE_ONLY.json').read_text());self.assertIsNone(x['summary']['new_label_accuracy_against_adjudicated_atlas'])
 def test_38_legacy_matches_sum(self):
  x=json.loads((B/'ANALISE_CONCORDANCIA_MESTRE_ONLY.json').read_text());self.assertEqual(sum(r['agree_historical'] for r in x['pairs']),x['summary']['matches'])
 def test_39_assessed_all_oracle_id(self):
  x=json.loads((B/'ANALISE_CONCORDANCIA_MESTRE_ONLY.json').read_text());self.assertEqual(len(x['pairs']),26)
 def test_40_have_linked_image_hash_to_oracle(self):
  with zipfile.ZipFile(B/'MESTRE_ONLY'/'PA_26_TECNICAS_CORRESPONDENCIA_MESTRE_ONLY_20261021.zip' if (B/'MESTRE_ONLY'/'PA_26_TECNICAS_CORRESPONDENCIA_MESTRE_ONLY_20261021.zip').exists() else '/mnt/data/PA_26_TECNICAS_CORRESPONDENCIA_MESTRE_ONLY_20261021.zip') as z:oracle=json.loads(z.read('MESTRE_ONLY_CORRESPONDENCIA.json'))
  self.assertEqual({o['anon_id'] for o in oracle['mapping']},{r['case_id'] for r in CORPUS['cases']})
 def test_41_damage_bands_finite_positive(self):self.assertTrue(all(0<=a<b for a,b in mod.RANGES.values()))
 def test_42_no_secrets_in_source(self):
  for p in [B/'CORPUS_MECANICO_MANUAL_CEGO.json',B/'FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json']:
   t=p.read_text();self.assertNotIn('X-Amz-Signature=',t);self.assertNotIn('ntn_',t);self.assertNotIn('Bearer ',t)
 def test_43_against_hash_mutation(self):
  s=(B/'FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json').read_bytes();self.assertNotEqual(hashlib.sha256(s+b' ').hexdigest(),(B/'FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.sha256').read_text().split()[0])
 def test_44_not_pretend_gold_canonicity(self):
  sm=json.loads((B/'ANALISE_CONCORDANCIA_MESTRE_ONLY.json').read_text())['summary'];self.assertTrue(sm['not_scientific_accuracy'] if 'not_scientific_accuracy' in sm else sm['status'].endswith('NOT_ACCURACY'))
 def test_45_18_of_26_have_an_explicit_Dice_or_save(self):self.assertEqual(sum(bool(r['source_damage_expression'] or r['source_save']) for r in CORPUS['cases']),18)
 def test_46_provisional_no_long_rank(self):self.assertTrue(all(r['rank_proposal_test_only']!='Lendário' for r in CORPUS['cases']))
 def test_47_claim_provenance_for_all(self):self.assertTrue(all(r['provenance'].startswith('Mestre export JPG') for r in CORPUS['cases']))
 def test_48_data_sources_separated(self):self.assertNotIn('original_title',json.dumps(CORPUS,ensure_ascii=False));self.assertNotIn('historic_rank',json.dumps(CORPUS,ensure_ascii=False))
 def test_49_no_integrity_loss(self):
  imgs=list((B/'images').glob('TEC-*.jpg'))
  self.assertEqual(len(imgs),26)
  for source in AUDIT['images']:
   p=B/'images'/(source['anon_id']+'.jpg')
   self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),source['sha256'])
 def test_50_controlled_rank_order(self):self.assertEqual(list(mod.RANGES),['Bronze','Prata','Ouro','Ouro Negro','Lendário'])
if __name__=='__main__':unittest.main(verbosity=1)
