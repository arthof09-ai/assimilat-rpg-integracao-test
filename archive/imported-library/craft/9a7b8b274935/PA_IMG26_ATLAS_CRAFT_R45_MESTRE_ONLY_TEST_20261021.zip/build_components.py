import json,os,collections
B=os.path.dirname(__file__)
D={
'TEC-0E7493058FC8':[('compreensão/comunicação verbal com bestas','informacao','sem controle mental'),('persuasão de favor','controle','depende da discricionariedade Mestre')],
'TEC-1808CAC63847':[('feixe 1d10 força em acerto','dano','ataque mágico à distância'),('feixes adicionais conforme progressão estrangeira','alcance_area','não mapear nível para rank')],
'TEC-320DB7B56AD0':[('+1d4 em ataques','suporte','até três alvos'),('+1d4 em salvaguardas','suporte','até três alvos'),('ampliação por níveis superiores estrangeiros','alcance_area','contrato de progressão em Assimilação inexistente')],
'TEC-39F038CF281E':[('paralisar humanoide até 1 minuto','controle','resistência Sabedoria inicial e por turno; mortos-vivos imunes'),('ampliar humanoides por progressão estrangeira','alcance_area','não equiparar a rank')],
'TEC-3A1BC9C77ED8':[('1d6 fogo extra no golpe','dano','requer acertar ataque'),('1d6 fogo periódico','dano','se alvo falha teste Constituição; concentração'),('escalonamento de dano com nível de origem','progressao','sem fórmula Assimilação')],
'TEC-44ACABD04901':[('explosão de espinhos 1d10','dano','por criatura na área ao acertar golpe com arma à distância'),('salvaguarda Destreza para metade','confiabilidade','área 5 pés'),('incremento até 6d10 por nível estrangeiro','progressao','sem fórmula Assimilação')],
'TEC-4756338D9E0C':[('impedimento por vinhas','controle','teste Força; criatura grande com vantagem'),('1d6 perfurante por turno','dano','somente enquanto impedido'),('escalonamento 1d6 por nível estrangeiro','progressao','sem fórmula Assimilação')],
'TEC-49FDDBE69D38':[('-1d4 ataques em até 3 alvos','suporte','falha salvaguarda Carisma'),('-1d4 salvaguardas em até 3 alvos','suporte','falha salvaguarda Carisma'),('ampliar alvos em níveis superiores','progressao','sem fórmula Assimilação')],
'TEC-575586E88BE3':[('empurrar criatura pequena ou média 5 pés','controle','falha Força'),('deslocar objeto não segurado 10 pés','mobilidade','massa <=2,5kg e alcance 30 pés; sem dano')],
'TEC-680699BF9999':[('vantagem no próximo ataque','suporte','apenas próxima jogada, em outro turno, sob concentração')],
'TEC-6B84A461C262':[('+5 CA reativo','defesa','até próximo turno inclusive ataque gatilho; CA estrangeiro'),('anular dano de mísseis mágicos','defesa','efeito específico de origem')],
'TEC-7F4A4B423743':[('2d10 fogo de retaliação','dano','reação após dano sofrido; resistência Destreza metade'),('incremento 1d10 por nível de magia estrangeiro','progressao','não mapear')],
'TEC-9252C3B2669F':[('+1d6 em cada acerto','dano','concentração até uma hora'),('rastrear alvo com vantagem','informacao','somente alvo marcado'),('transferir marca após morte','mobilidade','usa ação bônus de origem')],
'TEC-9668762A6DAC':[('encantar humanoide','controle','teste Sabedoria, vantagem se em luta; não controle absoluto'),('reconhecimento posterior do encanto','informacao','alvo sabe ao final')],
'TEC-9684BAE3174B':[('não provoca ataque de oportunidade','mobilidade','até 1min concentração'),('uma vantagem no ataque com arma e +1d8 força','dano','única vez antes do fim'),('+30 pés deslocamento no turno','mobilidade','condição do ataque')],
'TEC-968D29765EB1':[('3d8 de energia ao atingir alvo','dano','ataque 90 pés'),('escolher um dentre seis tipos de dano','versatilidade','ácido, frio, fogo, elétrico, veneno, trovejante'),('incremento 1d8 por nível estrangeiro','progressao','não mapear')],
'TEC-988589FB9716':[('conjurar servo invisível CA10 PV1 FOR2','criacao','1 hora, não ataca; atributos estrangeiros'),('comandar 15 pés e manipular objetos','criacao','ação bônus origem, sob comandos')],
'TEC-A2802280AAE8':[('criar fogo em área 5 pés','criacao','até um minuto'),('1d8 dano fogo ao surgir/entrar/terminar turno','dano','salvaguarda Destreza'),('progressão dano para até 4d8 em níveis externos','progressao','sem versão Assimilação')],
'TEC-AC33D1C9DD16':[('vínculo telepático bidirecional com besta','informacao','10 minutos, amiga/enfeitiçada, int <4'),('transmitir emoção e conceitos simples','informacao','linha de visão')],
'TEC-B0D00FDE2408':[('1d10 fogo à distância','dano','ataque 120 pés'),('incendiar objeto inflamável não carregado','criacao','ao acertar'),('progressão até 4d10 em níveis externos','progressao','sem fórmula nativa')],
'TEC-B22F58FD1A83':[('percepção remota por sentidos da besta','informacao','1h concentração com alvo voluntário'),('perda temporária dos sentidos próprios','limitacao','enquanto utiliza sentidos da besta')],
'TEC-C71526491A42':[('encantar besta por 24h','controle','falha sabedoria; int <4, termina se sofrer dano da equipe'),('ampliação de alvos em níveis estrangeiros','progressao','não converter')],
'TEC-D9EF9388353A':[('1d8 dano elétrico por toque','dano','ataque corpo-a-corpo'),('alvo sem reação até próximo turno','controle','requer acerto'),('vantagem ao atacar metal','confiabilidade','condicional à armadura'),('progressão até 4d8 em níveis externos','progressao','não mapear')],
'TEC-E229A1361599':[('2d6 dano trovejante no golpe','dano','gatilho em arma corpo-a-corpo'),('empurrar 10 pés após falha FOR','controle','teste força'),('derrubar alvo após falha FOR','controle','condição caído'),('estrondo audível a 90m','informacao','efeito secundário')],
'TEC-E3532F6A98AC':[('resistência a dano concussão de arma','defesa','até próximo turno'),('resistência a dano cortante de arma','defesa','até próximo turno'),('resistência a dano perfurante de arma','defesa','até próximo turno')],
'TEC-F1BD993CFF60':[('1d10 perfurante do projétil','dano','requer acerto mágico'),('2d6 frio em área de 5 pés','dano','explosão em acerto ou erro; teste Destreza evita'),('progressão +1d6 por nível estrangeiro','progressao','não mapear')]
}
corpus=json.load(open(B+'/CORPUS_MECANICO_MANUAL_CEGO.json'))['cases']
assert set(D)=={x['case_id'] for x in corpus}
rows=[]
for r in corpus:
 subs=[]
 for ix,(effect,axis,condition) in enumerate(D[r['case_id']],1):
  subs.append({'subeffect_id':f"{r['case_id']}-E{ix:02}",'observed_or_interpreted_effect':effect,'atlas_axis':axis,'source_condition':condition,'rank_effect_adjudicated':None,'evidence_level':'SOURCE_VISUAL_INTERPRETATION','translation_into_assimilacao':'PENDING'})
 rows.append({'case_id':r['case_id'],'subeffects':subs})
counts=collections.Counter(x['atlas_axis'] for r in rows for x in r['subeffects'])
ans={'method':'Manual subeffect split of 26 visual cards. Not necessarily disjoint causal effects, no automatic rank, no PA.','n_abilities':26,'n_subeffects':sum(len(x['subeffects']) for x in rows),'family_counts':counts,'all_no_adjudicated_subrank':True,'cards':rows}
json.dump(ans,open(B+'/ATLAS_26_DECOMPOSICAO_SUBEFEITOS_TEST.json','w'),ensure_ascii=False,indent=2)
print('Subeffects:',ans['n_subeffects'],'Families:',dict(counts))
