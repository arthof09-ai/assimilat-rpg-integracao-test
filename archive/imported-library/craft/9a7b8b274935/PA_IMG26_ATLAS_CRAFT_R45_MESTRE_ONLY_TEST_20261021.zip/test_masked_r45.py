import unittest,json,hashlib,os
from pathlib import Path
from PIL import Image,ImageStat,ImageChops
B=Path(__file__).parent
M=json.loads((B/'MASKING_AUDIT.json').read_text())
class MaskedImageTests(unittest.TestCase):
 def test01_n(self):self.assertEqual(M['n'],26)
 def test02_entries(self):self.assertEqual(len(M['masked']),26)
 def test03_ids_unique(self):self.assertEqual(len({r['case_id'] for r in M['masked']}),26)
 def test04_files_all_exist(self):self.assertTrue(all((B/r['redacted_image']).exists() for r in M['masked']))
 def test05_source_hashes(self):
  for r in M['masked']:self.assertEqual(hashlib.sha256((B/'images'/(r['case_id']+'.jpg')).read_bytes()).hexdigest(),r['source_sha256'])
 def test06_redacted_hashes(self):
  for r in M['masked']:self.assertEqual(hashlib.sha256((B/r['redacted_image']).read_bytes()).hexdigest(),r['redacted_sha256'])
 def test07_source_differs_masked(self):self.assertTrue(all(r['source_sha256']!=r['redacted_sha256'] for r in M['masked']))
 def test08_redact_bounds_constant(self):self.assertEqual({tuple(r['redaction_rectangle_px']) for r in M['masked']},{(55,932,646,998)})
 def test09_dimensions(self):
  for r in M['masked']:
   self.assertEqual(Image.open(B/r['redacted_image']).size,(700,1013))
 def test10_orig_source_dims(self):
  for r in M['masked']:
   self.assertEqual(Image.open(B/'images'/(r['case_id']+'.jpg')).size,(700,1013))
 def test11_source_body_preserved_approx(self):
  for r in M['masked']:
   a=Image.open(B/'images'/(r['case_id']+'.jpg')).convert('RGB').crop((0,0,700,925))
   b=Image.open(B/r['redacted_image']).convert('RGB').crop((0,0,700,925))
   ma=max(ImageStat.Stat(ImageChops.difference(a,b)).mean);self.assertLess(ma,8)
 def test12_mask_actually_differs_in_footer(self):
  for r in M['masked']:
   a=Image.open(B/'images'/(r['case_id']+'.jpg')).convert('RGB').crop((55,950,646,998))
   b=Image.open(B/r['redacted_image']).convert('RGB').crop((55,950,646,998))
   self.assertGreater(max(ImageStat.Stat(ImageChops.difference(a,b)).mean),2)
 def test13_originals_unchanged(self):self.assertTrue(all(r['original_unchanged'] for r in M['masked']))
 def test14_not_independent_blind_claim(self):self.assertTrue(all(r['still_not_guaranteed_independent_blind'] for r in M['masked']))
 def test15_no_legacy_gold(self):self.assertNotIn('historic_rank',(B/'MASKING_AUDIT.json').read_text())
 def test16_anonymized_name(self):self.assertTrue(all('TEC-' in r['redacted_image'] for r in M['masked']))
 def test17_no_image_modification_in_source(self):self.assertTrue(all(r['source_sha256']==next(z['sha256'] for z in json.load(open(B/'SOURCE_AUDIT.json'))['images'] if z['anon_id']==r['case_id']) for r in M['masked']))
 def test18_all_jpeg(self):self.assertTrue(all((B/r['redacted_image']).read_bytes()[:3]==b'\xff\xd8\xff' for r in M['masked']))
 def test19_no_more_mask_than_footer(self):self.assertTrue(all(r['redaction_rectangle_px'][1]>=920 for r in M['masked']))
 def test20_each_original_not_duplicate(self):self.assertEqual(len({r['source_sha256'] for r in M['masked']}),26)
if __name__=='__main__':unittest.main()
