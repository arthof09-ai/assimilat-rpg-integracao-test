# Corpo científico sem rótulos históricos — entrega para verificador independente

**TEST / não canônico.** As leituras derivam de 26 imagens originais de fontes externas, já inspecionadas, cada uma verificada com SHA-256. O antigo rank do Notion foi separado, mas o mesmo assistente pode ter conhecimento prévio; usar outro revisor para teste cego verdadeiro.

| ID | Tipo de efeito | Duração fonte | Dano informado | Rank candidato E2/E3 | Faixa para adjudicação |
|---|---|---|---|---|---|
| TEC-0E7493058FC8 | informacao | 10 minutos | Não quantificado | Prata | Bronze–Prata |
| TEC-1808CAC63847 | dano | instantânea | 1d10 força | Bronze | Bronze–Prata |
| TEC-320DB7B56AD0 | suporte | até 1 minuto (C) | Não quantificado | Ouro | Prata–Ouro |
| TEC-39F038CF281E | controle | 1 minuto (C) | Não quantificado | Ouro | Prata–Ouro Negro |
| TEC-3A1BC9C77ED8 | dano | até 1 minuto (C) | 1d6 fogo inicial + 1d6 fogo recorrente em falha | Prata | Bronze–Prata |
| TEC-44ACABD04901 | dano | até 1 minuto (C) | 1d10 perfurante por criatura atingida ou metade no sucesso | Prata | Bronze–Ouro |
| TEC-4756338D9E0C | controle | até 1 minuto (C) | 1d6 perfurante por turno | Ouro | Prata–Ouro |
| TEC-49FDDBE69D38 | suporte | até 1 minuto (C) | Não quantificado | Ouro | Prata–Ouro |
| TEC-575586E88BE3 | controle | instantânea | Não quantificado | Bronze | Bronze–Prata |
| TEC-680699BF9999 | suporte | 1 rodada (C) | Não quantificado | Bronze | Bronze–Prata |
| TEC-6B84A461C262 | defesa | até início do próximo turno | Não quantificado | Prata | Prata–Ouro |
| TEC-7F4A4B423743 | dano | instantânea | 2d10 fogo (metade no sucesso) | Bronze | Bronze–Prata |
| TEC-9252C3B2669F | suporte | até 1 hora (C) | +1d6 por acerto | Prata | Bronze–Ouro |
| TEC-9668762A6DAC | controle | 1 hora | Não quantificado | Prata | Prata–Ouro |
| TEC-9684BAE3174B | mobilidade | até 1 minuto (C) | +1d8 força em um acerto | Prata | Prata–Ouro |
| TEC-968D29765EB1 | dano | instantânea | 3d8 elemento escolhido | Prata | Bronze–Prata |
| TEC-988589FB9716 | criacao | 1 hora | Não quantificado | Prata | Bronze–Prata |
| TEC-A2802280AAE8 | dano | até 1 minuto | 1d8 fogo por permanência/exposição | Bronze | Bronze–Prata |
| TEC-AC33D1C9DD16 | informacao | 10 minutos (C) | Não quantificado | Prata | Bronze–Prata |
| TEC-B0D00FDE2408 | dano | instantânea | 1d10 fogo | Bronze | Bronze–Prata |
| TEC-B22F58FD1A83 | informacao | até 1 hora (C) | Não quantificado | Prata | Bronze–Prata |
| TEC-C71526491A42 | controle | 24 horas | Não quantificado | Prata | Bronze–Ouro |
| TEC-D9EF9388353A | dano | instantânea | 1d8 elétrico | Prata | Bronze–Prata |
| TEC-E229A1361599 | dano | até 1 minuto (C) | 2d6 trovejante adicional | Prata | Bronze–Prata |
| TEC-E3532F6A98AC | defesa | 1 rodada | Não quantificado | Prata | Bronze–Ouro |
| TEC-F1BD993CFF60 | dano | instantânea | 1d10 perfurante no ataque + 2d6 frio em explosão de raio 5 pés | Prata | Bronze–Prata |

**Números de PA não calculados:** as magias fonte não têm contrato de custos do Assimilação aceito por autoridade. R26/R27 e DMG-RANK-01 permanecem intactos.

A avaliação independente deve considerar efeito dominante, área, controle, confiabilidade, economia de ações, permanência, bypass e três comparadores do Atlas A. Dano por rolagem não transforma o rank em dado diretamente.
