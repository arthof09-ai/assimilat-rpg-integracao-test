# Missão executiva MESTRE-SIDE — Continuidade profunda PA/CRAFT

## Objetivo
Executar, em sequência, a recuperação do contexto canônico, a conversão das 26 imagens entregues pelo Mestre em corpus mecânico verificável, a classificação multicritério segundo Atlas A e DMG-RANK-01, testes reais e negativos, comparação posterior com ranks históricos como concordância (não verdade), análise de lacunas, solução independente de P2/Óleo em engenharia TEST, checkpoint escrito e verificado na página existente e PSV antes/depois. Repetir próxima pendência enquanto houver rotas independentes que agreguem resultados concretos; preferir funcionalidade demonstrada e não geração repetitiva de relatórios.

## Regras explícitas
1. Nunca escrever Party/O Primeiro. Nunca mudar classificações históricas, fichas, receitas canônicas, custos R26/R27, estoque, produção.
2. O título/nível D&D nas próprias imagens é dado de origem, não gabarito Assimilação. Rank do Notion entra SOMENTE após congelar as avaliações deste ciclo, para estudo de concordância.
3. Registrar leitura visual por ID anônimo, mecânica observada, números, área, testes, condição, E0–E3 e incerteza. Distinguir dano base, dano de área/sustentado e controle.
4. Usar Atlas de Poder A como norma de classificar RE antes do dano, e DMG-RANK-01 v1.1 apenas para comparar dano existente sem substituir expressão original. Não usar preço para rank.
5. Classificação proposta E3 TEST não é promoção canônica. Nunca apresentar concordância com rótulos legados como precisão contra verdade.
6. Executar regressões, cenários extremos e provas de integridade, rejeição de leakage e discriminação CRAFT.
7. Checkpoint ANTES/DEPOIS na página Laboratório CRAFT existente, conferir leitura de volta, não duplicar operação, não inventar sucesso de Inbox.
8. Preservar tudo como ZIP com manifestos SHA256 e oferecer ao Mestre arquivos. Não criar falsas evidências materiais de magia.
9. Continuar com pendências adjacentes (CRAFT P2, QA causal, formalização de decisões) sem exigir reconfirmações que já foram dadas.
10. Nenhuma duração horária é prometida além da execução interativa real que ocorrer neste turno; fazer o máximo viável e apresentar estado de retomada explícito.
