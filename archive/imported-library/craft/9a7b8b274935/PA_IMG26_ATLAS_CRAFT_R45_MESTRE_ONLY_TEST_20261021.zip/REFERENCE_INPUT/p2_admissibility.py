"""Strict real recipe preflight, not an alchemy runner. No canonical errata.
Follows the original P2 BOM and process in Notion. Both conflicts are unresolved.
"""
from dataclasses import dataclass
BOM={'Argila de Elemental da Terra':3,'Água Benta de Santuário':1,'Sal de Geodo Santo':2,'Pó de Ferro de Meteoro':3,'Essência de Barreira Mística':1,'Óleo de Vedação':1}
ENERGY_CHOICES={'Pedra da Luz':2,'Pote de Essência Mágica':2}
PROCESS_STEP_SALT='Sal de Geodo Encantado'
OIL_BOM={'Raiz de Mandrágora':1,'Gota do Orvalho do Amanhecer':8,'Pó de Ferro Celestial':2,'Essência da Lua Minguante':1}
OIL_PROCESS_EXTRA={'Orvalho de Dragão','Essência de Vórtice'}
def preflight(*,sal_decision=None,energizer=None,energy_stage=None,oil_recipe_decision=None,lot_inventory=None,operator_certified=False,material_witnesses=None):
    blockers=[]
    if sal_decision not in ('USAR_SANTO','USAR_ENCANTADO'):
        blockers.append('P2-SALT-01_CANONICAL_DECISION_MISSING')
    if energizer not in ENERGY_CHOICES: blockers.append('P2-ENERGY-CHOICE_MISSING')
    if energy_stage not in ('IN_MIX','POST_APPLY'):
        blockers.append('P2-ENERGY-02_STAGE_DECISION_MISSING')
    if oil_recipe_decision not in ('OIL_BOM','OIL_PROCESS_RECONCILED'):
        blockers.append('OIL_RECIPE_AUTHORITY_DECISION_MISSING')
    if not operator_certified: blockers.append('P2_TRAINED_OPERATOR_NOT_VERIFIED')
    if not material_witnesses or len(set(material_witnesses))<2:
        blockers.append('INDEPENDENT_MATERIAL_WITNESSES_MISSING')
    needed=dict(BOM)
    if sal_decision=='USAR_ENCANTADO':
        del needed['Sal de Geodo Santo'];needed['Sal de Geodo Encantado']=2
    if energizer in ENERGY_CHOICES:needed[energizer]=ENERGY_CHOICES[energizer]
    if lot_inventory is None:
        blockers.append('REAL_LOT_INVENTORY_MISSING')
    else:
        for name,qty in needed.items():
            stock=lot_inventory.get(name)
            if not stock or stock.get('quantity',0)<qty or not all(stock.get(k) for k in ('lot_id','custody','authenticity_sha')):
                blockers.append(f'NO_CERTIFIED_LOT:{name}')
    # This is still not permission to install: source itself has unresolved contradictions.
    return {'kind':'P2_TEST_READONLY_GATE','can_install_in_official_world':False,
        'eligible_for_material_setup':len(blockers)==0,
        'blockers':blockers,
        'needed_quantities':needed,'energy_step_proposal':energy_stage,
        'salt_branch_proposal':sal_decision,
        'oil_branch_proposal':oil_recipe_decision,
        'baseline_authority':'3edc2b324ede811783dfce62058ca6b8',
        'note':'Even fully ready fixtures only open supervised CRAFT TEST; no R48 order, PA cost, or item certification.'}
