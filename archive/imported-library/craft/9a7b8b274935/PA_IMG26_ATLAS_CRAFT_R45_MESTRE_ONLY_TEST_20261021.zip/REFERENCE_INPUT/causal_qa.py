"""MESTRE-SIDE test causal decision gate. Never fabricates witnesses.

Observations are logical records. Accepts only witnessed/measured real events for
positive classifications; synthetic values exercise the validator but cannot certify RC5.
"""
from dataclasses import dataclass
from statistics import mean
from typing import List, Optional

@dataclass(frozen=True)
class Observation:
    arm: str # C0:empty, C1:source-only, C2:source+p2, C3:own pattern
    source_present: bool
    p2_installed: bool
    own_pattern_installed: bool
    observed_signal: float
    quality_duration: float
    independent_witness: Optional[str]
    external_record_sha256: Optional[str]
    kind: str='REAL'  # TEST and SYNTHETIC may never certify magic

class AdmissibilityError(ValueError): pass
ARM_RULES={'C0':(False,False,False),'C1':(True,False,False),'C2':(True,True,False),
           'C3':(False,True,True)}
def validate(o):
    if o.arm not in ARM_RULES:raise AdmissibilityError('unknown arm')
    if (o.source_present,o.p2_installed,o.own_pattern_installed)!=ARM_RULES[o.arm]:
        raise AdmissibilityError('arm flags mismatch')
    if o.observed_signal<0 or o.quality_duration<0:raise AdmissibilityError('negative measurements')
    if o.kind not in ('REAL','SYNTHETIC','TEST'):raise AdmissibilityError('invalid origin')
    if o.kind=='REAL' and (not o.independent_witness or not o.external_record_sha256 or len(o.external_record_sha256)!=64):
        raise AdmissibilityError('real observation missing independent witness or hash')
    if o.kind!='REAL' and (o.independent_witness or o.external_record_sha256):
        raise AdmissibilityError('synthetic may not impersonate witness')

def adjudicate(observations: List[Observation]):
    for o in observations:validate(o)
    arms={k:[o for o in observations if o.arm==k] for k in ARM_RULES}
    base={'input_count':len(observations),'real_count':sum(o.kind=='REAL' for o in observations),
          'source_effect':'NOT_DEMONSTRATED','p2_stabilization':'NOT_DEMONSTRATED',
          'own_pattern_effect':'NOT_DEMONSTRATED','rc5':'HOLD',
          'source_inference':'Requires C0/C1 independent documented comparator',
          'p2_inference':'Requires C1/C2 independent documented duration comparison',
          'own_inference':'Requires C0/C3 independent documented source-absent signal'}
    # Require at least two independently witnessed REAL trials in each arm;
    # mere high synthetic numbers never qualify, nor does software gate alone approve production.
    arms={k:[o for o in xs if o.kind=='REAL'] for k,xs in arms.items()}
    qualified=all(len(xs)>=2 and len(set(y.independent_witness for y in xs))>=2 for xs in arms.values())
    if not qualified:
        base['reason']='REAL_REPLICATES_AND_DISTINCT_WITNESSES_REQUIRED'
        return base
    b={k:mean(o.observed_signal for o in xs) for k,xs in arms.items()}
    dur={k:mean(o.quality_duration for o in xs) for k,xs in arms.items()}
    # No absolute physical threshold is invented. Positive merely says a direction;
    # authority must define instrument noise, unit, significance and causal controls.
    if b['C1']>b['C0']:base['source_effect']='CANDIDATE_DIRECTIONAL_ONLY'
    if dur['C2']>dur['C1']:base['p2_stabilization']='CANDIDATE_DIRECTIONAL_ONLY'
    if b['C3']>b['C0']:base['own_pattern_effect']='CANDIDATE_DIRECTIONAL_ONLY'
    base.update(reason='THRESHOLDS_R46_R47_P2_OPERATOR_NOT_CERTIFIED',
      measurements={'means_signal':b,'means_duration':dur},
      notice='Directional change is not magical certification, no factory product can be inferred.')
    return base
