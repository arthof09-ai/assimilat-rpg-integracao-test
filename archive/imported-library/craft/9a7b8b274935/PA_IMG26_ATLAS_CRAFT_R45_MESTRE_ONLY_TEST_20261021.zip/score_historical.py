import json,hashlib,zipfile,collections,csv,os,statistics
B=os.path.dirname(__file__)
raw=open(B+'/FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.json','rb').read();actual_hash=hashlib.sha256(raw).hexdigest()
expected=open(B+'/FREEZE_RANK_PROPOSALS_BEFORE_ORACLE.sha256').read().split()[0]
assert actual_hash==expected
freeze=json.loads(raw)
with zipfile.ZipFile(os.path.join(B,'MESTRE_ONLY','PA_26_TECNICAS_CORRESPONDENCIA_MESTRE_ONLY_20261021.zip') if os.path.isfile(os.path.join(B,'MESTRE_ONLY','PA_26_TECNICAS_CORRESPONDENCIA_MESTRE_ONLY_20261021.zip')) else '/mnt/data/PA_26_TECNICAS_CORRESPONDENCIA_MESTRE_ONLY_20261021.zip') as z:
    gold=json.loads(z.read('MESTRE_ONLY_CORRESPONDENCIA.json'))
assert len(gold['mapping'])==26 and gold['item_count']==26
legacy={g['anon_id']:g for g in gold['mapping']}
RANK={'B':'Bronze','P':'Prata','O':'Ouro','ON':'Ouro Negro','L':'Lendário'}
order={'Bronze':0,'Prata':1,'Ouro':2,'Ouro Negro':3,'Lendário':4}
family={g['case_id']:g['effect_family'] for g in json.load(open(B+'/CORPUS_MECANICO_MANUAL_CEGO.json'))['cases']}
rows=[]
for e in freeze['cases']:
    g=legacy[e['case_id']];assert g['image_sha256']==next(x['sha256'] for x in json.load(open(B+'/SOURCE_AUDIT.json'))['images'] if x['anon_id']==e['case_id'])
    nominal=RANK[g['historic_rank']];proposal=e['proposed_rank']
    row={'case_id':e['case_id'],'historic_name_for_master_only':g['original_title'],'historic_rank':nominal,'provisional_rank_test':proposal,'proposed_interval':e['candidate_range'],'signed_rank_delta_proposed_minus_historic':order[proposal]-order[nominal], 'agree_historical':int(proposal==nominal),'family':family[e['case_id']]}
    rows.append(row)
count_match=sum(x['agree_historical'] for x in rows)
legacy_counts=collections.Counter(x['historic_rank'] for x in rows);proposed_counts=collections.Counter(x['provisional_rank_test'] for x in rows)
confusion={old:{new:sum(x['historic_rank']==old and x['provisional_rank_test']==new for x in rows) for new in order} for old in order}
from sklearn.metrics import balanced_accuracy_score,cohen_kappa_score,classification_report
ys=[x['historic_rank'] for x in rows];yp=[x['provisional_rank_test'] for x in rows]
# Note: labels are FALLIBLE. These are descriptive metrics of concordance, not scientific precision.
summary={'status':'EXPLORATORY_LEGACY_AGREEMENT_NOT_ACCURACY','n':26,'freeze_sha256':actual_hash,'image_sha256_unique':26,'method':'procedural freeze of E3 candidates before opening legacy oracle, not independent human double blind','assistant_may_have_seen_some_legacy_labels_prior':True,'matches':count_match,'agreement_fraction':round(count_match/26,4),'mean_abs_rank_difference':round(statistics.mean(abs(x['signed_rank_delta_proposed_minus_historic']) for x in rows),4),'legacy_distribution':legacy_counts,'provisional_distribution':proposed_counts,'confusion_legacy_rows_proposed_cols':confusion,'balanced_recall_with_legacy_as_labels_not_truth':round(balanced_accuracy_score(ys,yp),4),'cohen_kappa_vs_legacy_not_accuracy':round(cohen_kappa_score(ys,yp),4),'disagreements':26-count_match,'new_label_accuracy_against_adjudicated_atlas':None,'adjudicated_atlas_cases':0,'note':'Historic Notion labels were assigned informally according to Mestre. Neither a match nor mismatch is scientific evidence of correctness; assessor had prior exposure and native card spell level was visible.'}
with open(B+'/ANALISE_CONCORDANCIA_MESTRE_ONLY.json','w') as f:json.dump({'summary':summary,'pairs':rows},f,ensure_ascii=False,indent=2)
with open(B+'/DESACORDOS_MESTRE_ONLY.csv','w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,ensure_ascii=False,indent=2))
