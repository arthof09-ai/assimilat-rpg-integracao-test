# CRAFT H2/P2 — plano de continuidade R45 (TEST, sem execução de fabricação)

Autoridade de referência: receita https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8 ; óleo https://app.notion.com/p/75fc2b324ede83d492f881e556dc03f8 ; IBX-116 já existente https://app.notion.com/p/3ffc2b324ede817aa3abea3cb7ba8c08 . 

## Verificado (fonte viva)
- A receita P2 tem BOM com 7 classes de insumo: 3 Argila de Elemental da Terra, 1 Água Benta de Santuário, 2 Sal de Geodo Santo, 3 Pó Ferro Meteoro, 1 Essência Barreira Mística, 1 Óleo Vedação, mais ramo 2 Pedra Luz OU 2 Potes Essência Mágica. O processo tem 6 passos e erra identidade de sal e não usa energia explicitamente.
- Receita alternativa do óleo contém quatro classes na BOM, mas a instrução 2 é truncada e menciona Orvalho Dragão e Vórtice em vez das fontes listadas; falta incorporação do Pó Ferro.
- Não existem, no conjunto disponível, registros positivos de lote/quantidade/custódia/operador designado/testemunhas instrumentadas desta fabricação. Isso NÃO quer dizer estoque zero em todo o mundo.

## Decisões propostas, NÃO executadas
1. **SALT:** usar Sal de Geodo Santo no passo 3 é a emenda textual mínima coerente com BOM e localização. Alternativa Encantado exige modificar BOM/origem; requer autoridade.
2. **ENERGY:** determinar se 2x Pedra Luz OU 2x Pote Essência é ativador durante mistura ou pós-aplicação. Estabelecer consumo, duração, teste e modo de fixação. Até lá NULL.
3. **OIL:** escolher reconciliação da BOM existente ou variante distinta com linhagem própria; não inventar receita automaticamente.
4. **SISTEMA PA:** fonte mágica intrínseca não define custo de PA no usuário. P2 estabilizadora não é automaticamente habilidade própria, custo NULL (não zero). Orçamento C de habilidade própria 12 PA/dia + 7 por uso no ensaio E3 continua hipotético, não pago.

## Protocolo experimental físico exigível, mas não realizado
C0 suporte neutro; C1 suporte com fontes de luz sem inscrição; C2 mesmo suporte + P2 de verdade; C3 suporte sem fontes + padrão próprio explicitamente autorizado (se existir). Métricas requerem ruído instrumental, duração, sinal e duas testemunhas independentes por braço; evidência com hashes, operador e identificação do lote. Software testa admissibilidade mas não materializa magia.

## Gate medido neste turno
- Preflight P2 real documental **HOLD**, sem lote, operador, autoridade de emenda ou testemunha verificados.
- QA C0–C3: braços definidos, **0 observações reais**, nenhum ganho físico demonstrado.
- 40 testes negativos/positivos de engenharia TEST PASS; 0 ordens R48, 0 PA debitos, 0 instalação e 0 produtos RC5.
- F5/RC5/P4 produção HOLD; Party/O Primeiro NO-WRITE. Próxima retomada: respostas competentes da IBX-116 e registro de lotes/operador; não duplicar consulta.
