"""Reports inter-system adaptation decisions without making canonical conversions."""
import json,os,collections
B=os.path.dirname(__file__)
cases=json.load(open(B+'/CORPUS_MECANICO_MANUAL_CEGO.json'))['cases']
source_type={} # visual read of source label, NOT use as rank label
cantrips={'TEC-1808CAC63847','TEC-575586E88BE3','TEC-680699BF9999','TEC-A2802280AAE8','TEC-B0D00FDE2408','TEC-D9EF9388353A','TEC-E3532F6A98AC'}
level2={'TEC-39F038CF281E','TEC-B22F58FD1A83'}
for c in cases:source_type[c['case_id']]='TRUQUE' if c['case_id'] in cantrips else ('FONTE_NIVEL_2' if c['case_id'] in level2 else 'FONTE_NIVEL_1')
rows=[]
for c in cases:
 pending=[]
 if 'pés' in c['source_range'] or 'pés' in c['observed_mechanic_facts']:pending.append('UNIT_FEET_GAME_CONVERSION_NOT_AUTHORIZED')
 if '(C)' in c['source_duration']:pending.append('FOREIGN_CONCENTRATION_MAINTENANCE_RULE_UNMAPPED')
 if 'ação bônus' in c['source_activation']:pending.append('FOREIGN_BONUS_ACTION_UNMAPPED')
 if c['source_save'] is not None:pending.append('SOURCE_SAVE_STAT_REQUIRES_ASSIMILACAO_SALVAGUARDA_CHECK')
 if c['source_damage_expression'] is not None:pending.append('SOURCE_DAMAGE_DICE_NEED_RANK_PROFILE_DMG_COMPARISON_NOT_AUTOMATIC_REWRITE')
 if c['source_duration'] in ('instantânea','1 rodada','1 rodada (C)'):pending.append('CHECK_TEMPORAL_UNIT_ROUND_SPELL_CONTEXT')
 if c['case_id']=='TEC-0E7493058FC8':pending.append('SOURCE_IMAGE_ANIMALS_VS_NOTION_TITLE_CREATURES_SCOPE_MISMATCH')
 if c['case_id']=='TEC-988589FB9716':pending.append('FOREIGN_COMPANION_CA_HP_SPEED_NOT_TRANSLATED')
 if c['case_id']=='TEC-6B84A461C262':pending.append('FOREIGN_CA_PLUS5_NOT_YET_COMPARABLE_WITH_ASSIMILACAO_DEFENSE')
 if c['case_id'] in {'TEC-39F038CF281E','TEC-9668762A6DAC','TEC-C71526491A42','TEC-4756338D9E0C'}:pending.append('CROWD_CONTROL_AND_MIND_RULES_REQUIRE_SYSTEM_COMPARATORS')
 rows.append({'case_id':c['case_id'],'foreign_card_category_observed':source_type[c['case_id']],'pending_adaptation_flags':pending,'native_PA_cost':None,'native_Atlas_adjudication':'NOT_APPROVED','action_proposal':'Reação' if c['source_activation']=='reação' else ('Ação Padrão tentative under native default' if c['source_activation']=='ação' else 'NEEDS_TIME_DECISION'),'translation_status':'TEST_ONLY_NOT_PLAYABLE'})
summary={'n':len(rows),'cantrip_count':sum(x=='TRUQUE' for x in source_type.values()),'foreign_spell_level1_count':sum(x=='FONTE_NIVEL_1' for x in source_type.values()),'foreign_spell_level2_count':sum(x=='FONTE_NIVEL_2' for x in source_type.values()),'needs_actions':sum('FOREIGN_BONUS_ACTION_UNMAPPED' in x['pending_adaptation_flags'] for x in rows),'concentration_flags':sum('FOREIGN_CONCENTRATION_MAINTENANCE_RULE_UNMAPPED' in x['pending_adaptation_flags'] for x in rows),'need_save_mapping':sum('SOURCE_SAVE_STAT_REQUIRES_ASSIMILACAO_SALVAGUARDA_CHECK' in x['pending_adaptation_flags'] for x in rows),'foreign_level_not_assimilacao_rank':True,'valid_for_play':0,'canon_not_changed':True}
json.dump({'summary':summary,'rows':rows},open(B+'/PORTABILIDADE_ASSIMILACAO_TEST.json','w'),ensure_ascii=False,indent=2)
print(summary)
