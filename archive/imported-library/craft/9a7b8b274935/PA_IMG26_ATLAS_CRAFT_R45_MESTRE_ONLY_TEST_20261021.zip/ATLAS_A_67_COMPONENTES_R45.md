# 67 componentes mecânicos das 26 cartas — Atlas A em TEST

**Cada componente abaixo tem nível de evidência VISUAL-INTERPRETADA e rank RE pendente.** O Mestre não aprovou nem alterou nenhum efeito.

| ID da carta | ID componente | Eixo do Atlas | Mecânica resumida | Dependência da fonte |
|---|---|---|---|---|
| TEC-0E7493058FC8 | TEC-0E7493058FC8-E01 | informacao | compreensão/comunicação verbal com bestas | sem controle mental |
| TEC-0E7493058FC8 | TEC-0E7493058FC8-E02 | controle | persuasão de favor | depende da discricionariedade Mestre |
| TEC-1808CAC63847 | TEC-1808CAC63847-E01 | dano | feixe 1d10 força em acerto | ataque mágico à distância |
| TEC-1808CAC63847 | TEC-1808CAC63847-E02 | alcance_area | feixes adicionais conforme progressão estrangeira | não mapear nível para rank |
| TEC-320DB7B56AD0 | TEC-320DB7B56AD0-E01 | suporte | +1d4 em ataques | até três alvos |
| TEC-320DB7B56AD0 | TEC-320DB7B56AD0-E02 | suporte | +1d4 em salvaguardas | até três alvos |
| TEC-320DB7B56AD0 | TEC-320DB7B56AD0-E03 | alcance_area | ampliação por níveis superiores estrangeiros | contrato de progressão em Assimilação inexistente |
| TEC-39F038CF281E | TEC-39F038CF281E-E01 | controle | paralisar humanoide até 1 minuto | resistência Sabedoria inicial e por turno; mortos-vivos imunes |
| TEC-39F038CF281E | TEC-39F038CF281E-E02 | alcance_area | ampliar humanoides por progressão estrangeira | não equiparar a rank |
| TEC-3A1BC9C77ED8 | TEC-3A1BC9C77ED8-E01 | dano | 1d6 fogo extra no golpe | requer acertar ataque |
| TEC-3A1BC9C77ED8 | TEC-3A1BC9C77ED8-E02 | dano | 1d6 fogo periódico | se alvo falha teste Constituição; concentração |
| TEC-3A1BC9C77ED8 | TEC-3A1BC9C77ED8-E03 | progressao | escalonamento de dano com nível de origem | sem fórmula Assimilação |
| TEC-44ACABD04901 | TEC-44ACABD04901-E01 | dano | explosão de espinhos 1d10 | por criatura na área ao acertar golpe com arma à distância |
| TEC-44ACABD04901 | TEC-44ACABD04901-E02 | confiabilidade | salvaguarda Destreza para metade | área 5 pés |
| TEC-44ACABD04901 | TEC-44ACABD04901-E03 | progressao | incremento até 6d10 por nível estrangeiro | sem fórmula Assimilação |
| TEC-4756338D9E0C | TEC-4756338D9E0C-E01 | controle | impedimento por vinhas | teste Força; criatura grande com vantagem |
| TEC-4756338D9E0C | TEC-4756338D9E0C-E02 | dano | 1d6 perfurante por turno | somente enquanto impedido |
| TEC-4756338D9E0C | TEC-4756338D9E0C-E03 | progressao | escalonamento 1d6 por nível estrangeiro | sem fórmula Assimilação |
| TEC-49FDDBE69D38 | TEC-49FDDBE69D38-E01 | suporte | -1d4 ataques em até 3 alvos | falha salvaguarda Carisma |
| TEC-49FDDBE69D38 | TEC-49FDDBE69D38-E02 | suporte | -1d4 salvaguardas em até 3 alvos | falha salvaguarda Carisma |
| TEC-49FDDBE69D38 | TEC-49FDDBE69D38-E03 | progressao | ampliar alvos em níveis superiores | sem fórmula Assimilação |
| TEC-575586E88BE3 | TEC-575586E88BE3-E01 | controle | empurrar criatura pequena ou média 5 pés | falha Força |
| TEC-575586E88BE3 | TEC-575586E88BE3-E02 | mobilidade | deslocar objeto não segurado 10 pés | massa <=2,5kg e alcance 30 pés; sem dano |
| TEC-680699BF9999 | TEC-680699BF9999-E01 | suporte | vantagem no próximo ataque | apenas próxima jogada, em outro turno, sob concentração |
| TEC-6B84A461C262 | TEC-6B84A461C262-E01 | defesa | +5 CA reativo | até próximo turno inclusive ataque gatilho; CA estrangeiro |
| TEC-6B84A461C262 | TEC-6B84A461C262-E02 | defesa | anular dano de mísseis mágicos | efeito específico de origem |
| TEC-7F4A4B423743 | TEC-7F4A4B423743-E01 | dano | 2d10 fogo de retaliação | reação após dano sofrido; resistência Destreza metade |
| TEC-7F4A4B423743 | TEC-7F4A4B423743-E02 | progressao | incremento 1d10 por nível de magia estrangeiro | não mapear |
| TEC-9252C3B2669F | TEC-9252C3B2669F-E01 | dano | +1d6 em cada acerto | concentração até uma hora |
| TEC-9252C3B2669F | TEC-9252C3B2669F-E02 | informacao | rastrear alvo com vantagem | somente alvo marcado |
| TEC-9252C3B2669F | TEC-9252C3B2669F-E03 | mobilidade | transferir marca após morte | usa ação bônus de origem |
| TEC-9668762A6DAC | TEC-9668762A6DAC-E01 | controle | encantar humanoide | teste Sabedoria, vantagem se em luta; não controle absoluto |
| TEC-9668762A6DAC | TEC-9668762A6DAC-E02 | informacao | reconhecimento posterior do encanto | alvo sabe ao final |
| TEC-9684BAE3174B | TEC-9684BAE3174B-E01 | mobilidade | não provoca ataque de oportunidade | até 1min concentração |
| TEC-9684BAE3174B | TEC-9684BAE3174B-E02 | dano | uma vantagem no ataque com arma e +1d8 força | única vez antes do fim |
| TEC-9684BAE3174B | TEC-9684BAE3174B-E03 | mobilidade | +30 pés deslocamento no turno | condição do ataque |
| TEC-968D29765EB1 | TEC-968D29765EB1-E01 | dano | 3d8 de energia ao atingir alvo | ataque 90 pés |
| TEC-968D29765EB1 | TEC-968D29765EB1-E02 | versatilidade | escolher um dentre seis tipos de dano | ácido, frio, fogo, elétrico, veneno, trovejante |
| TEC-968D29765EB1 | TEC-968D29765EB1-E03 | progressao | incremento 1d8 por nível estrangeiro | não mapear |
| TEC-988589FB9716 | TEC-988589FB9716-E01 | criacao | conjurar servo invisível CA10 PV1 FOR2 | 1 hora, não ataca; atributos estrangeiros |
| TEC-988589FB9716 | TEC-988589FB9716-E02 | criacao | comandar 15 pés e manipular objetos | ação bônus origem, sob comandos |
| TEC-A2802280AAE8 | TEC-A2802280AAE8-E01 | criacao | criar fogo em área 5 pés | até um minuto |
| TEC-A2802280AAE8 | TEC-A2802280AAE8-E02 | dano | 1d8 dano fogo ao surgir/entrar/terminar turno | salvaguarda Destreza |
| TEC-A2802280AAE8 | TEC-A2802280AAE8-E03 | progressao | progressão dano para até 4d8 em níveis externos | sem versão Assimilação |
| TEC-AC33D1C9DD16 | TEC-AC33D1C9DD16-E01 | informacao | vínculo telepático bidirecional com besta | 10 minutos, amiga/enfeitiçada, int <4 |
| TEC-AC33D1C9DD16 | TEC-AC33D1C9DD16-E02 | informacao | transmitir emoção e conceitos simples | linha de visão |
| TEC-B0D00FDE2408 | TEC-B0D00FDE2408-E01 | dano | 1d10 fogo à distância | ataque 120 pés |
| TEC-B0D00FDE2408 | TEC-B0D00FDE2408-E02 | criacao | incendiar objeto inflamável não carregado | ao acertar |
| TEC-B0D00FDE2408 | TEC-B0D00FDE2408-E03 | progressao | progressão até 4d10 em níveis externos | sem fórmula nativa |
| TEC-B22F58FD1A83 | TEC-B22F58FD1A83-E01 | informacao | percepção remota por sentidos da besta | 1h concentração com alvo voluntário |
| TEC-B22F58FD1A83 | TEC-B22F58FD1A83-E02 | limitacao | perda temporária dos sentidos próprios | enquanto utiliza sentidos da besta |
| TEC-C71526491A42 | TEC-C71526491A42-E01 | controle | encantar besta por 24h | falha sabedoria; int <4, termina se sofrer dano da equipe |
| TEC-C71526491A42 | TEC-C71526491A42-E02 | progressao | ampliação de alvos em níveis estrangeiros | não converter |
| TEC-D9EF9388353A | TEC-D9EF9388353A-E01 | dano | 1d8 dano elétrico por toque | ataque corpo-a-corpo |
| TEC-D9EF9388353A | TEC-D9EF9388353A-E02 | controle | alvo sem reação até próximo turno | requer acerto |
| TEC-D9EF9388353A | TEC-D9EF9388353A-E03 | confiabilidade | vantagem ao atacar metal | condicional à armadura |
| TEC-D9EF9388353A | TEC-D9EF9388353A-E04 | progressao | progressão até 4d8 em níveis externos | não mapear |
| TEC-E229A1361599 | TEC-E229A1361599-E01 | dano | 2d6 dano trovejante no golpe | gatilho em arma corpo-a-corpo |
| TEC-E229A1361599 | TEC-E229A1361599-E02 | controle | empurrar 10 pés após falha FOR | teste força |
| TEC-E229A1361599 | TEC-E229A1361599-E03 | controle | derrubar alvo após falha FOR | condição caído |
| TEC-E229A1361599 | TEC-E229A1361599-E04 | informacao | estrondo audível a 90m | efeito secundário |
| TEC-E3532F6A98AC | TEC-E3532F6A98AC-E01 | defesa | resistência a dano concussão de arma | até próximo turno |
| TEC-E3532F6A98AC | TEC-E3532F6A98AC-E02 | defesa | resistência a dano cortante de arma | até próximo turno |
| TEC-E3532F6A98AC | TEC-E3532F6A98AC-E03 | defesa | resistência a dano perfurante de arma | até próximo turno |
| TEC-F1BD993CFF60 | TEC-F1BD993CFF60-E01 | dano | 1d10 perfurante do projétil | requer acerto mágico |
| TEC-F1BD993CFF60 | TEC-F1BD993CFF60-E02 | dano | 2d6 frio em área de 5 pés | explosão em acerto ou erro; teste Destreza evita |
| TEC-F1BD993CFF60 | TEC-F1BD993CFF60-E03 | progressao | progressão +1d6 por nível estrangeiro | não mapear |

### Gate

Não usar número 67 como denominador de acerto por rank: contém progressões, limitações e efeitos componentes sem classificação RE individual. Uma avaliação independente pode rever a decomposição e agregar ou separar subefeitos, registrando delta; os 26 JPG originais com SHA continuam a prova primária.
