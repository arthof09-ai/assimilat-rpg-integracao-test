# PA R45 — Investigação completa das 26 técnicas (MESTRE-ONLY)

**Natureza:** estudo TEST, competência Mestre-side; não cria regra nova, não canoniza ranks, não publica Party.

## Entrega e origem

1. 26/26 JPEGs originais do ZIP de exportação enviado pelo Mestre foram visualizados neste turno; hashes individuais e correspondência de 26 arquivos foram checados contra pacote anterior; imagens de 700×1.013 pixels; nível de outro RPG ignorado como rank.
2. 26 resumos mecânicos de leitura visual manual, reduzidos e não apresentados como transcrição literal completa. Cada caso relaciona JPEG, hash, ação, duração, alcance, dano, teste e efeitos condicionais.
3. Atlas A e DMG-RANK-01 v1.1 consultados no Notion Mestre antes de formular comparadores e diagnóstico de dano.
4. O SHA de propostas foi congelado antes de abrir o oráculo antigo: `2f1e88e3c7980cf376ed2ec76816dec48d3f4779bec55a9f6e3bf5687e799a5e`. Porém o mesmo assistente havia conhecido alguns títulos/ranks; portanto o procedimento é **separação sequencial documentada, NÃO duplo-cego independente**.
5. Classificações estimadas são E2 apenas quanto ao dano básico de dois casos; demais E3 provisórias. Nenhuma classificação foi adjudicada por três comparadores completos nem transformada em valor de PA.

## Medidas apuradas

- Fonte visual: **26/26** inspecionadas. Famílias: controle 5, criacao 1, dano 10, defesa 2, informacao 3, mobilidade 1, suporte 4.
- Dado numérico de dano: **13/26**. Com dano ou teste de resistência explícito: **18/26**. Comparação simples de 1 evento de dano, sem área/DoT/dependência: **5/26**.
- Cartas importadas: **7 truques, 17 magias de nível 1, 2 de nível 2**; 6 ações bônus, 12 concentradas, 12 Salvaguardas de origem. **Não equiparar nível estrangeiro e rank Assimilação**.
- Concordância entre as 26 **estimativas E3** e rótulos históricos do Notion: **8/26**, divergência 18/26; **não é acurácia científica**. O Mestre confirmou que os ranks históricos foram atribuídos informalmente a magias importadas.
- Resultado contra adjudicação independente conforme Atlas: **NULL / 0 avaliadas**, não preencher com zero ou com 8/26.

## Auditoria individual de compatibilidade (tabela Mestre-only)

| Referência original | ID opaco | Mecânica extraída | Rank histórico | Proposta TEST | Incerteza |
|---|---|---|---|---|---|
| Falar Com Criaturas (ON) | TEC-0E7493058FC8 | Comunicação com bestas | Ouro Negro | Prata | Bronze–Prata |
| Rajada Mística (B) | TEC-1808CAC63847 | Feixe mágico à distância | Bronze | Bronze | Bronze–Prata |
| Benção (O) | TEC-320DB7B56AD0 | Bênção em três alvos | Ouro | Ouro | Prata–Ouro |
| Imobilizar Pessoa (L) | TEC-39F038CF281E | Paralisia de humanoide | Lendário | Ouro | Prata–Ouro Negro |
| Destruição Lancinante (O) | TEC-3A1BC9C77ED8 | Imbuimento ígneo recorrente | Ouro | Prata | Bronze–Prata |
| Saraivada de Espinhos (O) | TEC-44ACABD04901 | Explosão de espinhos de armamento | Ouro | Prata | Bronze–Ouro |
| Golpe Constritor (O) | TEC-4756338D9E0C | Restrição por vinhas no golpe | Ouro | Ouro | Prata–Ouro |
| Perdição (O) | TEC-49FDDBE69D38 | Maldição d4 a três criaturas | Ouro | Ouro | Prata–Ouro |
| Lufada (P) | TEC-575586E88BE3 | Rajada de vento utilitária | Prata | Bronze | Bronze–Prata |
| Ataque Certeiro (P) | TEC-680699BF9999 | Antecipação de ataque | Prata | Bronze | Bronze–Prata |
| Escudo Arcano (O) | TEC-6B84A461C262 | Barreira reativa de escudo | Ouro | Prata | Prata–Ouro |
| Repreensão Infernal (O) | TEC-7F4A4B423743 | Retaliação infernal por reação | Ouro | Bronze | Bronze–Prata |
| Marca do Caçador (P) | TEC-9252C3B2669F | Marca do caçador sustentada | Prata | Prata | Bronze–Ouro |
| Enfeitiçar Pessoa (ON) | TEC-9668762A6DAC | Encantamento social individual | Ouro Negro | Prata | Prata–Ouro |
| Golpe de Zephyr (O) | TEC-9684BAE3174B | Mobilidade vento e golpe único | Ouro | Prata | Prata–Ouro |
| Orbe Cromática (ON) | TEC-968D29765EB1 | Orbe de elemento variável | Ouro Negro | Prata | Bronze–Prata |
| Servo Invisível (O) | TEC-988589FB9716 | Auxiliar invisível com comandos | Ouro | Prata | Bronze–Prata |
| Criar Fogueira (B) | TEC-A2802280AAE8 | Fogueira mágica de pequeno espaço | Bronze | Bronze | Bronze–Prata |
| Vínculo Com a Besta (O) | TEC-AC33D1C9DD16 | Elo telepático com besta | Ouro | Prata | Bronze–Prata |
| Raio de Fogo (P) | TEC-B0D00FDE2408 | Projétil ígneo inicial | Prata | Bronze | Bronze–Prata |
| Sentido Bestial (P) | TEC-B22F58FD1A83 | Percepção por sentidos alheios | Prata | Prata | Bronze–Prata |
| Amizade Animal (ON) | TEC-C71526491A42 | Amizade animal duradoura | Ouro Negro | Prata | Bronze–Ouro |
| Toque Chocante (O) | TEC-D9EF9388353A | Choque de toque e negação de reação | Ouro | Prata | Bronze–Prata |
| Destruição Trovejante (O) | TEC-E229A1361599 | Reforço trovejante e deslocamento | Ouro | Prata | Bronze–Prata |
| Proteção Contra Lâminas (ON) | TEC-E3532F6A98AC | Resistência física por reação | Ouro Negro | Prata | Bronze–Ouro |
| Faca de Gelo (P) | TEC-F1BD993CFF60 | Fragmento de gelo e explosão secundária | Prata | Prata | Bronze–Prata |

**Esta tabela é confidencial Mestre-only:** a coluna histórica NÃO acompanha o pacote de material cego para um avaliador independente.

## Divergências exemplares que exigem avaliação da regra, não renomeação automática

- **Imobilizar Pessoa:** a imagem mostra humanoide, teste de Sabedoria recorrente e concentração até um minuto. O rank Lendário histórico não se prova somente pelo título de imobilização; mas também não é seguro rebaixar definitivamente sem considerar o impacto de hard-control nos benchmarks do Atlas.
- **Orbe Cromática:** 3d8 de tipo elemental escolhido, DME do evento básico 13,5, alvo único e ataque; o valor de Ouro Negro histórico necessita justificativa adicional e não define a potência numérica automaticamente.
- **Falar Com Criaturas:** título do Notion abrange genericamente criaturas, porém imagem fonte diz “Falar com animais” e o efeito só comunica com bestas. É uma diferença semântica capaz de alterar o escopo da habilidade: registrar, não corrigir sem ordem.
- **Proteção Contra Lâminas:** reação que concede resistência física durante uma rodada, sem efeito amplo de campo; o histórico Ouro Negro não pode ser considerado a verdade sem benchmark da defesa no Assimilação.
- **Escudo Arcano:** +5 CA da fonte de origem e imunidade a projéteis mágicos; os números CA de um sistema não devem ser copiados diretamente para o outro.
- **Rajada Mística e Raio de Fogo:** ambos dão 1d10 por ataque básico; média 5,5 está dentro da banda Bronze 4–18 de DMG-RANK-01, porém progressão, múltiplos ataques, elemento e condições são tratados separadamente.

## Adaptações pendentes para jogar de fato

1. **Ação bônus:** não existe classe equivalente explicitamente identificada nos atuais Sistema de Combate e Sistema de Magia consultados; exige decisão para 6 casos, não aplicar Ação Livre por identidade falsa.
2. **Concentração:** o mecanismo estrangeiro aparece em 12 cartas e não está definido nas páginas principais consultadas; determinar manutenção, interrupção, simultaneidade e custo conforme norma competente.
3. **Pés e movimentação:** manter medidas de origem e eventual conversão física como informativa, sem configurar geometria de combate automaticamente.
4. **D&D níveis e upcast:** progressão por espaços de magia e níveis de conjurador NÃO equivalem a Bronze→Lendário ou PA. Criar versão por rank só depois de classificá-la separadamente.
5. **Controle e Salvaguarda:** CD no Assimilação é Proficiência + INT + bônus; salvaguarda é atributo puro, conforme os sistemas vigentes. Não transportar CD nem economia de ações implícitas da origem.
6. **Dano explícito e DMG:** preservar origem como dado do experimento; DMG-RANK-01 manda classificar efeito primeiro e só então gerar dano se faltar, não substituir automaticamente a expressão original.
7. **Condições estratégicas:** charm, paralisia, barreira, telepatia, servo autônomo e não-reação exigem comparadores reais e risco/contramedidas do mundo de Assimilação.

## CRAFT/P2 — contribuição paralela real

- Receita P2 Fonte: https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8 ; óleo fonte: https://app.notion.com/p/75fc2b324ede83d492f881e556dc03f8 . Não foi alterada receita.
- Confirmado Sal de Geodo **Santo** na BOM e localização, **Encantado** apenas no passo 3. Menor correção PROPOSTA troca Encantado→Santo no processo, sujeita a decisão da autoridade de receita.
- Energizador 2x Pedra da Luz **OU** 2x Pote de Essência Mágica consta BOM mas não processo; estágio, consumo, duração e equivalência permanecem NULL.
- Óleo Alternativo BOM orvalho Amanhecer / essência Lua Minguante / Pó Ferro Celestial; processo fala Dragão / Vórtice, linha 2 truncada. Não estabelecer equivalência sem respaldo.
- Teste real de admissibilidade documental retorna HOLD; controles C0–C3 estão especificados, mas observações materiais reais n=0. Nenhuma instalação, item RC5, gasto PA ou ordem R48 foi gerado.


## Nova camada de análise — 67 subefeitos da fonte

Após a primeira extração, cada magia foi novamente decomposta em unidades que o Atlas A pode julgar individualmente. O novo arquivo `ATLAS_26_DECOMPOSICAO_SUBEFEITOS_TEST.json` contém **67 subefeitos** em **26 cartas**, cada um com ID, família mecânica, condição, referência à imagem e rank do subefeito ainda NULL. Distribuição: informacao: 7, controle: 9, dano: 15, alcance_area: 3, suporte: 5, progressao: 11, confiabilidade: 2, mobilidade: 4, defesa: 5, versatilidade: 1, criacao: 4, limitacao: 1. Alguns subefeitos são progressão estrangeira, limitações ou entrega condicionada, não “poderes mágicos” independentes, por isso 67 NÃO equivale a 67 classificações ou 67 magias.

A classificação preliminar do conjunto inteiro foi congelada antes do confronto com os rótulos históricos. Esta decomposição foi criada DEPOIS de consultar o oráculo, portanto deve ser submetida a revisão independente sem alegação de cegamento para seus detalhes.

Os testes locais totais são **168/168**: 50 de corpus/dano, 40 de CRAFT P2, 25 de portabilidade e 21 de decomposição; a contagem é sobre validações de software, não amostras independentes de desempenho científico.


## Sensibilidade, transferência entre sistemas e segunda revisão visual

A comparação do candidato congelado com rótulos legados mostra **8/26 coincidências exatas; em 14/26 casos o rank histórico está dentro da faixa ampla de incerteza testada; 12/26 fora**. Nas 18 divergências exatas, todas as propostas preliminares são inferiores ao rótulo antigo e nenhuma superior, diferença média -0,96 patamar. Esta assimetria **NÃO** autoriza concluir que o Notion está inflado: pode indicar conservadorismo do avaliador, incompatibilidade entre os jogos ou rótulos antigos informais.

Foram criadas **26 cópias visuais derivadas** que ocultam apenas a faixa inferior onde aparece “TRUQUE” ou “MAGIA DE NÍVEL X” do sistema estrangeiro. Os **26 originais permanecem byte-identical**. Verificação visual de amostras e comparação numérica garantem que a zona de conteúdo acima de y=925 permaneceu legível após recompressão JPEG, média máxima do erro de pixel <8/255. O segundo revisor ainda deve evitar mapear os níveis citados dentro das próprias descrições ao rank de Assimilação. As cópias mascaradas são suporte para avaliação independente, **não prova de cegamento pleno**.

A coleção de 26 talentos foi decomposta em 67 subefeitos após o congelamento inicial; essa camada requer segunda auditoria independente antes de medir desempenho por efeito.

## Execução, reprodução e segregação

- Foi produzida suíte de **168/168 testes unitários** de integridade, análise numérica, dados cegos, portabilidade e negativos CRAFT. Os testes provam funcionamento do código, não precisão rank nem execução mágica.
- Pacote mestre inclui imagens byte-identical, referência cega, freeze assinado por SHA-256, avaliação histórica pós-freeze e dados de testes. Preservar MASTER-ONLY. Para novo avaliador verdadeiramente independente, entregar apenas o ZIP de imagens anonimizadas original e/ou o corpus sem oráculo.
- As mídias foram obtidas do arquivo do Mestre nesta conversa, não de API pública. Nenhuma gravação Party ou O Primeiro foi efetuada.

## Ponto de retomada de maior valor

1. Auditar independentemente as 26 fichas de extração e reproduzir as mecânicas de fonte com segundo revisor; E2/E3 conforme Atlas.
2. Adjudicar ranks de efeitos com comparadores sistêmicos, NPC/Besta atuais e família de magia, mantendo versões iniciais e escaláveis separadas.
3. Reexecutar classificação com os rótulos adjudicados e reportar cobertura, confiança, matriz de confusão e limites de erro; não usar rank histórico como gold.
4. Criar adaptador nativo de concentração / ações bônus / progressão por espaços de magia só após decisão competente; ensaiar em TEST, não Party.
5. CRAFT: receber decisão P2-SALT/ENERGY, óleo, lote e operador; depois executar ensaios C0–C3 físicos com testemunhas, sem falsa certificação.
