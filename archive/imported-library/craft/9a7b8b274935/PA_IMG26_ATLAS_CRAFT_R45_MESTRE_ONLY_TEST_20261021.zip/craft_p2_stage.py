"""Read-only planning extension to existing CRAFT H2 P2 gates. No recipe mutation."""
import os,importlib.util,json,re,hashlib
B=os.path.dirname(__file__)
L=(os.path.join(B,'REFERENCE_INPUT') if os.path.isfile(os.path.join(B,'REFERENCE_INPUT','p2_admissibility.py')) else '/mnt/data/PA_CRAFT_R44_CANDIDATO_TEST_20261020/')
def load_module(name):
 spec=importlib.util.spec_from_file_location(name,os.path.join(L,name+'.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
p2=load_module('p2_admissibility'); causal=load_module('causal_qa')
SALT_SOURCE='Sal de Geodo Santo';SALT_PROCESS='Sal de Geodo Encantado'
OIL_BOM={'Raiz de Mandrágora':1,'Gota do Orvalho do Amanhecer':8,'Pó de Ferro Celestial':2,'Essência da Lua Minguante':1}
OIL_PROCESS=['Raiz de Mandrágora','Orvalho de Dragão','Essência de Vórtice','Frasco de cristal encantado']
BOM_P2={**p2.BOM,'Pedra da Luz OU Pote de Essência Mágica':2}
STEPS=[['Argila de Elemental da Terra'],['Água Benta de Santuário'],['Sal de Geodo Encantado'],['Pó de Ferro de Meteoro'],['Óleo de Vedação'],['Essência de Barreira Mística']]
# A possible revised formula is a blueprint until a real authority authorizes it.
def propose_protocol(*,salt_decision=None,energy_stage=None,oil_variant=None):
  missing=[]
  if salt_decision not in ('USAR_SANTO','USAR_ENCANTADO'):missing.append('AUTHORITY_SALT_DECISION')
  if energy_stage not in ('IN_MIX','POST_APPLY'):missing.append('AUTHORITY_ENERGY_STAGE')
  if oil_variant not in ('FOLLOW_BOM','PROCESS_OTHER_FORMULA'):missing.append('AUTHORITY_OIL_IDENTITY')
  return {'operation':'PLAN_IN_TEST_ONLY','official_recipe_unchanged':True,'source_recipe_contained':'P2 canon / oil alternative canon','branch_salt':salt_decision,'branch_energy':energy_stage,'branch_oil':oil_variant,'outstanding_authorities':missing,'eligible_for_official_production':False,'consumed_resources':0,'applied_inscriptions':0,'manually_approved':False}

# Strict device for known evidence only. Syntax of a purported SHA is not independent proof.
def guard_real_material_evidence(records,registry):
 if not records:return False,'NO_OBSERVATION_RECORDS'
 if not registry:return False,'NO_AUTHORITATIVE_EXTERNAL_REGISTRY'
 for o in records:
  if o.get('kind')!='REAL':return False,'NOT_REAL_RECORD'
  sha=o.get('sha256',''); witness=o.get('independent_witness','')
  if not re.fullmatch(r'[a-f0-9]{64}',sha):return False,'INVALID_SHA256_SYNTAX'
  if not witness:return False,'WITNESS_ABSENT'
  # External registry must be separately populated from actual trusted file and signoff; none currently available.
  if registry.get(sha)!=witness:return False,'EVIDENCE_NOT_IN_VERIFIED_REGISTRY'
 return True,'DOCUMENTALLY_VERIFIED_RECORDS_ONLY_NOT_MAGICAL_PROOF'

def simulated_lab_matrix():
 arms=['C0','C1','C2','C3'];result=[]
 for name in arms:
  state=causal.ARM_RULES[name];result.append({'arm':name,'source_present':state[0],'p2_installed':state[1],'own_pattern_installed':state[2],'measurements':None,'kind':'PLANNED_ONLY','magical_success':None})
 return result

def run():
 return {'preflight_actual':p2.preflight(),'decisions_needed':propose_protocol(),'qa_zero_trials':causal.adjudicate([]),'lab_arms':simulated_lab_matrix(),'crosswalk':{'p2_bom':BOM_P2,'process_steps':STEPS,'sal_mismatch':SALT_SOURCE!=SALT_PROCESS,'missing_energy_step':True,'oil_bom':OIL_BOM,'oil_process':OIL_PROCESS,'oil_process_includes_unlisted_materials':['Orvalho de Dragão','Essência de Vórtice'],'oil_explicit_pó_incorporation':False,'oil_line2_truncated':True},'external_verified_material_records':0,'material_outcome':'HOLD' }
if __name__=='__main__':
 a=run();json.dump(a,open(B+'/CRAFT_P2_R45_PREFLIGHT_RESULT.json','w'),ensure_ascii=False,indent=2);print(json.dumps({k:v for k,v in a.items() if k not in ('crosswalk','lab_arms')},ensure_ascii=False,indent=2))
