# CRAFT R6 — correção de custódia do revisor Node (MESTRE-ONLY, TEST)

**Fonte congelada:** R5 ZIP SHA256 `29b4bfb61a726bd4e12bffa8e245552831003ca5f3e1b7e4f5edcbd7f65eb6e8`. `logic.js` é o mesmo arquivo do R5 (SHA pinado no `review_capture.js`). **Não** altera a bancada HTML nem as tolerâncias PRE-Q2.

## Defeito e correção

No R5, `writeFileSync` sobrescrevia a saída, inclusive se fosse o próprio arquivo de entrada. Isso podia destruir a evidência original ou um parecer prévio. No R6, a saída é criada com `flag:'wx'` e modo `0600`: somente arquivo novo, nunca substituição silenciosa. Caminhos de entrada e saída iguais, destinos existentes, aliases de symlink/hardlink e diretórios são recusados sem alterar bytes de entrada.

## Uso

`node review_capture.js entrada.json novo-parecer.json`

O segundo argumento é opcional; o padrão é `entrada.json.review.json`. Se já existir, escolha outro nome. Nenhum arquivo de origem é editado. A revisão recalcula os resultados pelo código R5 e continua retornando `REVIEW_REQUIRED_NO_AUTOCANON` quando consistente. A correção protege contra sobrescrita acidental, **não** autentica operador, instrumento, cadeia de custódia ou dados físicos. Não é assinatura digital nem proteção contra operador malicioso com acesso de escrita ao sistema de arquivos.

## Validação

`python test_custody.py` testa 12 cenários de integridade de arquivo. `node test_review.js` executa os 26 testes do revisor R5. O R5 completo também foi reexecutado em extração limpa (63 testes da bancada, 26 do revisor, 2.000 vetores sintéticos e E2E Chromium). Não duplicar as contagens.

**Gates:** PASS exclusivamente correção CLI e testes digitais; HOLD produção, RC5/F5, dados físicos, C19/IBX38 e REC-LIB/R51. Party/O Primeiro NO-WRITE. Nenhuma escrita no Notion de fichas/receitas/estoque/PA.
