"""R7 custody tests for the previously vulnerable r46_predossier_cli.js. All in temporary directories."""
from pathlib import Path
import tempfile, subprocess, json, os, hashlib
ROOT=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='r46-custody-') as td:
 d=Path(td);source=d/'source.json';source.write_bytes((ROOT/'evidencia-sintetica/export_test.json').read_bytes());original=source.read_bytes()
 def run(out):return subprocess.run(['node',str(ROOT/'r46_predossier_cli.js'),str(source),str(out)],capture_output=True,text=True)
 def preserved():return source.read_bytes()==original
 count=0
 def check(k,ok):
  global count
  assert ok,k
  count+=1;print('PASS',k)
 p=run(source);check('self-output',p.returncode!=0 and preserved())
 p=run(d/'./source.json');check('normalized-self-output',p.returncode!=0 and preserved())
 old=d/'existing.json';old.write_text('KEEP');p=run(old);check('existing-output',p.returncode!=0 and old.read_text()=='KEEP' and preserved())
 link=d/'symlink.json';link.symlink_to(source);p=run(link);check('symlink-output',p.returncode!=0 and preserved())
 hard=d/'hardlink.json';os.link(source,hard);p=run(hard);check('hardlink-output',p.returncode!=0 and preserved())
 p=run(d);check('directory-output',p.returncode!=0 and preserved())
 target=d/'result.json';p=run(target);check('fresh-output',p.returncode==0 and target.exists() and preserved())
 r=json.loads(target.read_text());check('no-autocanon',r['notion_write'] is False and r['official_rec_ids_created']==0 and r['physical_measurement_verified'] is False)
 old=target.read_bytes();p=run(target);check('no-repeat-truncation',p.returncode!=0 and target.read_bytes()==old)
 check('input-sha-intact',hashlib.sha256(source.read_bytes()).digest()==hashlib.sha256(original).digest())
 print('R7_R46_CUSTODY_PASS',count)
