# CRAFT R7 — correção de custódia integrada em TEST

Escopo: derivação isolada do pacote CRAFT_R6_ANDROID_R46_PREDOSSIER_20261021.zip. O pacote anterior NÃO foi sobrescrito, modificado ou publicado em fonte canônica.

Mudanças mínimas:
1. `review_capture.js`: mesmo patch de custódia R6 validado (SHA original registrado no manifesto); impede truncar entrada e saída existente com flag `wx`.
2. `r46_predossier_cli.js`: correção correspondente; o CLI R46 também podia sobrescrever arquivo de entrada ou recibo. Agora rejeita saída igual/normalizada e exige saída inexistente (`wx`, modo `0600`).
3. `run_replay_r6.py`: replay R46 em diretório temporário, não escreve sobre fixture anterior.
4. `test_custody.py` (12 casos) e `test_r46_custody.py` (10 casos) avaliam preservação, alias e idempotência negativa.
5. `logic.js`, HTML Android, `r46_predossier.js` e o ZIP R5 pinado são byte-idênticos ao pacote R6/R46 original. Manifestos, QA e checks originais preservados exceto alterações explícitas.

Execução no ambiente de engenharia: `python run_replay_r6.py`, `python test_custody.py`, `python test_r46_custody.py`. Após empacotar, `python verify_release_r6.py <zip>`.

Limite: esta integração protege saída dos dois CLIs Node, não autentica origem, evita falsa canonização e não prova o aplicativo em Android real. Não altera fichas, Party/O Primeiro, receitas/REC-LIB, PA, R48, estoque, ou writer/fencing. PRODUÇÃO e RC5 HOLD. Nenhum auto-merge para branches oficiais sem autorização e gate.
