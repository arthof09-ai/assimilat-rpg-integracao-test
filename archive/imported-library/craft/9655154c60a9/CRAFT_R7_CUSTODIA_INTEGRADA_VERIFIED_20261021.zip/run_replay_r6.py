#!/usr/bin/env python3
"""CRAFT R6 isolated replay. All data synthetic, no network or Notion writes."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent

def cmd(*args):
 p=subprocess.run(args,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=100)
 lines=p.stdout.strip().splitlines()
 print('RUN',*args,'RESULT',p.returncode,'\n'+'\n'.join(lines[-3:]),flush=True)
 if p.returncode:raise SystemExit('REPLAY_FAIL '+str(args))
 return p.stdout

# Historical code pinned byte-identically to R5 source.
q=hashlib.sha256((HERE/'logic.js').read_bytes()).hexdigest()
assert q=='a346889dd1cc59826d7d0ce24a16a9444d7587d316f63eccd1034dfc8be6e484',q
cmd('node','tests.js')
cmd('node','test_review.js')
cmd('node','stress_guardband.js')
cmd('node','test_r46_predossier.js')
cmd(sys.executable,'test_browser_r5_regression.py')
cmd(sys.executable,'test_r46_browser.py')
with tempfile.TemporaryDirectory(prefix='craft-r7-cli-') as tmp:
 cli_out=Path(tmp)/'r46_pre_dossier_cli.json'
 cmd('node','r46_predossier_cli.js',str(HERE/'evidencia-sintetica'/'export_test.json'),str(cli_out))
 browser=json.loads((HERE/'evidencia-sintetica'/'r46_pre_dossier_browser.json').read_text())
 cli=json.loads(cli_out.read_text())
 assert browser==cli,'BROWSER_NODE_DRAFT_DIFFERENCE'
assert all(r['report_id'] is None for r in browser['reports'])
assert not browser['notion_write'] and browser['official_rec_ids_created']==0
print('CRAFT_R6_REPLAY_PASS','R5:63+26 TESTS','R6:35 TESTS','2000 SYNTHETIC','2 BROWSER E2E','R46 BROWSER_CLI_MATCH','NO_WRITER')
