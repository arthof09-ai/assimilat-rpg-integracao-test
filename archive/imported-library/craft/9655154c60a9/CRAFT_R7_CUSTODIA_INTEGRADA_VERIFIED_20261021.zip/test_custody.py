import tempfile,subprocess,hashlib,json,os,pathlib
ROOT=pathlib.Path(__file__).parent
REVIEW=ROOT/'review_capture.js'
SAMPLE=ROOT/'evidencia-sintetica/export_test.json'
assert SAMPLE.exists()
with tempfile.TemporaryDirectory() as t:
 d=pathlib.Path(t);inp=d/'entrada.json'; inp.write_bytes(SAMPLE.read_bytes()); initial=inp.read_bytes();
 def call(out):return subprocess.run(['node',str(REVIEW),str(inp),str(out)],capture_output=True,text=True)
 cases=0
 def check(label,condition):
  global cases
  assert condition,label
  cases+=1
  print('PASS',label)
 a=call(inp);check('self-path blocked',a.returncode==2 and inp.read_bytes()==initial)
 a=call(d/'./entrada.json');check('normalized self-path blocked',a.returncode==2 and inp.read_bytes()==initial)
 target=d/'existing.json';target.write_text('DO_NOT_REPLACE');a=call(target);check('existing output intact',a.returncode==2 and target.read_text()=='DO_NOT_REPLACE')
 sym=d/'alias.json';sym.symlink_to(inp);a=call(sym);check('symlink alias intact',a.returncode==2 and inp.read_bytes()==initial)
 hard=d/'hardlink.json';os.link(inp,hard);a=call(hard);check('hardlink alias intact',a.returncode==2 and inp.read_bytes()==initial)
 a=call(d);check('directory refused',a.returncode==2 and inp.read_bytes()==initial)
 out=d/'new.review.json';a=call(out);check('fresh output created',a.returncode==0 and out.is_file() and inp.read_bytes()==initial)
 report=json.loads(out.read_text());check('review remains no-autocanon',report['review_status']=='REVIEW_REQUIRED_NO_AUTOCANON' and report['physical_verified']==False and report['official_writes']==0)
 a=call(out);check('second execution no overwrite',a.returncode==2 and json.loads(out.read_text())==report)
 a=subprocess.run(['node',str(REVIEW),str(inp)],capture_output=True,text=True);default=pathlib.Path(str(inp)+'.review.json');check('default output creates new file',a.returncode==0 and default.is_file())
 a=subprocess.run(['node',str(REVIEW),str(inp)],capture_output=True,text=True);check('default output second run refused',a.returncode==2)
 check('input SHA remains identical',hashlib.sha256(inp.read_bytes()).digest()==hashlib.sha256(initial).digest())
 print('R6_CUSTODY_TESTS',cases,'PASS')
