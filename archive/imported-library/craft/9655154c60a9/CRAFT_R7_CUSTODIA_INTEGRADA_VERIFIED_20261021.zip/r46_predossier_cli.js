/* Read-only Node convenience: same R46 pre-dossier transformer as Android. */
'use strict';
const {readFileSync,writeFileSync}=require('node:fs');
const {resolve}=require('node:path');
const {createHash}=require('node:crypto');
const QA=require('./logic.js');
const PRE=require('./r46_predossier.js');
const QA_PIN='a346889dd1cc59826d7d0ce24a16a9444d7587d316f63eccd1034dfc8be6e484';
if(createHash('sha256').update(readFileSync(__dirname+'/logic.js')).digest('hex')!==QA_PIN)throw Error('UNEXPECTED_QA_BASELINE');
function convert(str){if(Buffer.byteLength(str)>2*1024*1024)throw Error('SOURCE_OVER_2MB');return PRE.stagePortable(JSON.parse(str),QA);}
if(require.main===module){
 if(process.argv.length!==4)throw Error('USO node r46_predossier_cli.js entrada.json saida.json');
 const input=resolve(process.argv[2]), output=resolve(process.argv[3]);
 if(input===output)throw Error('OUTPUT_IS_INPUT');
 const out=convert(readFileSync(input,'utf8'));
 // Fails closed when target already exists, including preexisting file/symlink/hardlink/directory.
 // This script never opens input for writing and does not truncate existing evidence.
 writeFileSync(output,JSON.stringify(out,null,2)+'\n',{flag:'wx',mode:0o600});
 console.log('R46_PREDOSSIER_QUARANTINED','reports',out.report_count,'excluded',out.excluded_count,'notion_write',out.notion_write);
}
module.exports={convert};
