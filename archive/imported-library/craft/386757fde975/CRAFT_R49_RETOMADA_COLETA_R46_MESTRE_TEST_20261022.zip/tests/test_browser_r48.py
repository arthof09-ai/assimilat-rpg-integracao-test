"""R48 offline rehydration from an R35 R46 draft. Read-only, Mestre-only TEST."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,tempfile
root=Path(__file__).resolve().parents[1]
html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text(encoding='utf-8')
n=0
def ok(cond,explain):
 global n
 assert cond,explain
 n+=1
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[];network=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:network.append(r.url) if r.url.startswith(('https:','http:')) else None)
 page.set_content(html)
 page.locator('#r35-mobile-collection').evaluate('(e)=>e.open=true')
 fields=page.locator('#r35-r46-fields input[data-kind]')
 ok(fields.count()==72,'R48 baseline fields 72')
 ok(page.locator('#r35-resume-upload').count()==1,'resume upload exists')
 with tempfile.TemporaryDirectory() as td:
  td=Path(td)
  vals=['']*72
  vals[0]='OBS TESTE R48';vals[1]='https://example.org/prova-test';vals[2]='OUTRO DADO DE AMOSTRA';vals[23]='MULTICAMPO';vals[47]='OUTRO NÓ';vals[71]='ÚLTIMO CAMPO';
  fields.evaluate_all('''(els,v)=>els.forEach((el,i)=>{el.value=v[i]})''',vals)
  with page.expect_download() as d:page.locator('#r35-export').click()
  data_file=td/'report.json';d.value.save_as(data_file)
  draft=json.loads(data_file.read_text())
  ok(draft['release_gate']=='NO_PRODUCTION_NO_PARTY_PUBLICATION','safe draft gates')
  ok(len(draft['projects'])==2,'two source projects')
  fields.evaluate_all('(els)=>els.forEach(e=>e.value="")')
  page.locator('#r35-resume-upload').set_input_files(data_file)
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('RESTAURADOS')")
  ok(fields.evaluate_all('(els)=>els.map(e=>e.value)')==vals,'full 72-field restored exactly')
  ok('NÃO verificados' in page.locator('#r35-status').inner_text(),'no fake verification')
  with page.expect_download() as reround:page.locator('#r35-export').click()
  second_file=td/'roundtrip.json';reround.value.save_as(second_file)
  ok(json.loads(second_file.read_text())==draft,'R48 export-import-export byte-equivalent JSON data (parsed)')
  ok('0 laudos comprovados' in page.locator('#r35-status').inner_text(),'reexport no physical certification')
  ok('sem novas alterações detectadas' in page.locator('#r45-safety-status').inner_text(),'restored baseline tracked; not lost')
  ok(page.locator('#r35-resume-upload').input_value()=='','upload reset after success')
  # Cancel confirms previous values exactly intact.
  second=json.loads(data_file.read_text());second['projects'][0]['targeted_material_requests'][0]['evidence_requirements'][0]['observed_data']='IMPORT COM CONFLITO'
  (td/'conflict.json').write_text(json.dumps(second,ensure_ascii=False))
  dialogs=[]
  page.once('dialog',lambda d:(dialogs.append(d.message),d.dismiss()))
  page.locator('#r35-resume-upload').set_input_files(td/'conflict.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('CANCELADA')")
  ok(len(dialogs)==1 and 'substituídos' in dialogs[0],'asks to overwrite prior notes')
  ok(fields.nth(0).input_value()=='OBS TESTE R48','cancel retains values')
  ok(page.locator('#r35-resume-upload').input_value()=='','input resets on cancel')
  # Tampered flags must reject *before* asking for consent.
  bad=json.loads(data_file.read_text());bad['release_gate']='PRODUCTION'
  (td/'tampered.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r35-resume-upload').set_input_files(td/'tampered.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('REJEITADA')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','tampered flag no overwrite')
  ok(len(dialogs)==1,'no dialog if invalid')
  ok(page.locator('#r35-resume-upload').input_value()=='','input resets on reject')
  # Mutated component identity must reject without inheriting same proposal ID.
  bad=json.loads(data_file.read_text());bad['projects'][0]['targeted_material_requests'][0]['material_role']='DRIFTED'
  (td/'bad_role.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r35-resume-upload').set_input_files(td/'bad_role.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('REJEITADA')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','material role drift rejected')
  # Invalid proof URL rejected.
  bad=json.loads(data_file.read_text());bad['projects'][0]['targeted_material_requests'][0]['evidence_requirements'][0]['proof_url']='javascript:alert(1)'
  (td/'url.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r35-resume-upload').set_input_files(td/'url.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('REJEITADA')")
  ok(fields.nth(1).input_value()=='https://example.org/prova-test','malicious URL rejected')
  # R49: numeric or whitespace-rich payload must not be silently coerced by the text UI.
  bad=json.loads(data_file.read_text());bad['projects'][0]['targeted_material_requests'][0]['evidence_requirements'][0]['observed_data']=123.456
  (td/'numeric.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r35-resume-upload').set_input_files(td/'numeric.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('TIPO_OU_TEXTO_NAO_RESTAURAVEL')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','number not silently coerced to string')
  bad=json.loads(data_file.read_text());bad['projects'][0]['targeted_material_requests'][0]['evidence_requirements'][0]['observed_data']='  VALOR COM ESPACOS  '
  (td/'spaces.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r35-resume-upload').set_input_files(td/'spaces.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('TIPO_OU_TEXTO_NAO_RESTAURAVEL')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','trim drift rejected not silently normalized')
  bad=json.loads(data_file.read_text());bad['projects'][0]['targeted_material_requests'][0]['evidence_requirements'][0]['observed_data']='X'*4097
  (td/'max_len.json').write_text(json.dumps(bad,ensure_ascii=False))
  page.locator('#r35-resume-upload').set_input_files(td/'max_len.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('REJEITADA')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','length mismatch cannot truncate imported content')
  # >256KB hard limit before parse or replacement.
  (td/'huge.json').write_bytes(b'x'*263000)
  page.locator('#r35-resume-upload').set_input_files(td/'huge.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('ARQUIVO_ACIMA_256K')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','oversize preserves input')
  # Malformed JSON: no fallback to untrusted source.
  (td/'broken.json').write_text('{')
  page.locator('#r35-resume-upload').set_input_files(td/'broken.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('JSON_INVALIDO')")
  ok(fields.nth(0).input_value()=='OBS TESTE R48','bad JSON preserves input')
  # Accept valid import with explicit consent; only then state mutates.
  page.once('dialog',lambda d:(dialogs.append(d.message),d.accept()))
  page.locator('#r35-resume-upload').set_input_files(td/'conflict.json')
  page.wait_for_function("document.querySelector('#r35-r46-fields input').value==='IMPORT COM CONFLITO'")
  ok(len(dialogs)==2,'confirmation asked again')
  ok(fields.nth(0).input_value()=='IMPORT COM CONFLITO','confirmed replacement')
  ok('0 laudos' not in page.locator('#r35-status').inner_text(),'shows explicit unverified state')
  # file content bound to proposal: a product design mutation blocks import.
  page.evaluate("PROJECT.products[0].design+=' variante test';render(true)")
  page.locator('#r35-resume-upload').set_input_files(td/'conflict.json')
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('REJEITADA')")
  ok(fields.nth(0).input_value()=='IMPORT COM CONFLITO','stale project draft rejected')
  # Fresh rebuilt matching current project has 48 fields; restore empty variant.
  page.once('dialog',lambda d:d.accept())
  page.locator('#r35-reset').click()
  ok(fields.count()==48,'changed proposal reduces nodes to two')
  with page.expect_download() as d:page.locator('#r35-export').click()
  fresh=td/'fresh.json';d.value.save_as(fresh)
  page.locator('#r35-resume-upload').set_input_files(fresh)
  page.wait_for_function("document.querySelector('#r35-status').textContent.includes('RESTAURADOS')")
  ok(fields.count()==48,'fresh partial request restored safely')
  ok('NÃO verificados' in page.locator('#r35-status').inner_text(),'no physical pass with 48 controls')
  ok(not network,'network requests prohibited')
  ok(not errors,errors)
  for w in (320,360,390,430):
   page.set_viewport_size({'width':w,'height':844})
   ok(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),f'no overflow {w}')
 browser.close()
print(f'R48 Android-style safe R46 collection resume {n}/{n} PASS')
