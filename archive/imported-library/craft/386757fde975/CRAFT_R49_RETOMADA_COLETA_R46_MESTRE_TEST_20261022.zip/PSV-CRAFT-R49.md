# PSV — CRAFT R49 — Validação proporcional TEST DIGITAL

**Escopo:** continuidade do revisor CRAFT R53 na mesma superfície móvel, restauração fiel de relatório R46 anteriormente exportado. Nenhum write Notion, inventário, ficha, receita ou Party.

## Casos de ataque executados

- Documento válido R35 72 campos → restaurar → exportar novamente: dados JSON equivalentes, sem laudo emitido.
- Dados locais preenchidos + nova versão importada: diálogo de confirmação; CANCELAR preserva valores; ACEITAR substitui após validação.
- Arquivo com gate ou papel do material adulterado, link `javascript:`, JSON quebrado, arquivo acima de 256 KiB e mudança da proposta: rejeição sem sobrepor trabalho do Mestre.
- Relatório com número onde formulário é texto, espaços que seriam normalizados, texto acima do limite do controle: rejeição fail-closed (R49).
- Proposta modificada reduzindo 3 nós a 2: somente novo snapshot 48 campos compatível pode ser reimportado; não herdar dados de nós antigos.
- Regressão dos controles R31, R35, R40, R45, R47, importações protegidas, 50 questões e bases de fonte.

## Resultados observados

- Bancada: **30/30 JS**, 1765/1765 verificações; **24/24 Chromium**, 814/814 verificações; 2.000 sondagens; 2 projetos `HOLD_TEST_DESIGN`; `src/verify_outputs.js` PASS. Chromium executado em 3 blocos: 393 + 209 + 212 = 814.
- Conferência de distribuição, manifesto, replay a frio e custódia: ver relatório de encerramento; qualquer exceção futura deve manter o gate em HOLD, não ser tratada como PASS.

## Gate

**PASS restrito a TEST digital para retomada de relatórios R46 e fidelidade do formulário.** **HOLD** para Android físico, autenticidade/autoria, validação física R46, RC5, fencing, REC-LIB, publicação Player e produção. Não há assinatura do Mestre neste PSV, nem autenticação de relatórios externos.
