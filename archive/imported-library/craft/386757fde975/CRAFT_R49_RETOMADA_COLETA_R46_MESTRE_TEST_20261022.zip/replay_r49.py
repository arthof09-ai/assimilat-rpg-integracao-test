"""CRAFT R49: deterministic TEST validation without Notion writes."""
from pathlib import Path
import json,hashlib,subprocess,re,sys
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST-R49.json').read_text())
assert m['schema']=='CRAFT_R49_TEST_MANIFEST_V1'
for f,d in m['files'].items():
 p=root/f
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==d,('MANIFEST_DRIFT',f)
print(f'MANIFEST {len(m["files"])}/{len(m["files"])} PASS',flush=True)
total=0;suites=sorted((root/'tests').glob('test_*.js'))
for f in suites:
 z=subprocess.run(['node',str(f)],cwd=root,capture_output=True,text=True,timeout=45)
 k=re.search(r'(\d+)\s*/\s*(\d+)',z.stdout)
 assert z.returncode==0 and k and k[1]==k[2],(f,z.stdout[-300:],z.stderr[-300:])
 total+=int(k[1])
assert len(suites)==30 and total==1765,(len(suites),total)
print('JS 30/30',total,'/1765 PASS',flush=True)
for command in [('node','src/run.js'),('node','src/verify_outputs.js'),('node','tests/fuzz_schema_r11.js')]:
 z=subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=65)
 assert z.returncode==0,(command,z.stdout[-500:],z.stderr[-500:])
 if 'fuzz_schema' in command[1]:assert 'PASS 2000' in z.stdout
for f,d in [('outputs/QA_RESULT.json','b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'),('outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json','509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8')]:
 assert hashlib.sha256((root/f).read_bytes()).hexdigest()==d,('OUTPUT_DRIFT',f)
print('QA, RECEIPT, PREVIEW HASHES AND FUZZ PASS; 2 PROJECTS HOLD',flush=True)
if '--full' in sys.argv:
 chrome=sorted((root/'tests').glob('test_browser_*.py'))+[root/'tests/test_mobile_browser_r9.py'];count=0
 for f in chrome:
  z=subprocess.run([sys.executable,str(f)],cwd=root,capture_output=True,text=True,timeout=85)
  k=re.search(r'(\d+)\s*/\s*(\d+)',z.stdout)
  assert z.returncode==0 and k and k[1]==k[2],(f,z.stdout[-500:],z.stderr[-500:])
  count+=int(k[1]);print(f'CHROME {f.name}: {k[1]} PASS',flush=True)
 assert len(chrome)==24 and count==814,(len(chrome),count)
 print('CHROMIUM 24/24 SUITES, 814/814 PASS — EMULATED ONLY',flush=True)
print('CRAFT R49 TEST verified. C19/REC-LIB/RC5/PRODUCTION/PARTY HOLD',flush=True)
