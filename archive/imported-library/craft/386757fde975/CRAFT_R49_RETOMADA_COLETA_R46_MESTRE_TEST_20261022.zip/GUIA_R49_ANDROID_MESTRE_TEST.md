# Guia R49 — Reabrir coleta privada R46 no Android (TEST)

1. Abra **REVISOR_LOCAL_ANDROID_R53_TEST.html** no navegador do Mestre. O arquivo contém dados Mestre-only: não envie à Party.
2. Entre em **R35 — Preencher coleta R46 pelo celular**. Para continuar um formulário antigo, selecione o JSON previamente exportado em **R48 — Retomar coleta R46 de um JSON privado exportado**.
3. Se houver campos preenchidos, confirme a troca apenas após manter uma cópia própria. **Cancelar** não apaga campos. Arquivo alterado, desatualizado, inseguro ou incompatível é rejeitado sem substituição.
4. Confira os campos restaurados. Só então use **Salvar relato R46 preenchido (não verificado)** e confirme manualmente que o download existe no telefone. Um clique no botão não é prova de armazenamento.
5. Se a proposta foi alterada, use **Recriar ficha vazia para proposta atual**, após exportar o que quiser preservar; não reaproveite medições de um nó antigo pelo mesmo ID.
6. **A coleta nunca concede RC5, magia, laudo, produção, decisão do Mestre ou Party-release.** Dados de ensaio físico precisam de proveniência e validação R46 externa.

Este programa é testado em **Chromium móvel simulado**, não em aparelho Android real; opera offline, não guarda notas automaticamente e não sincroniza com o Notion.
