// R45 user-data-loss guard for the EXISTING R31/R35/R40 Mestre-only forms.
// Only in-memory form snapshots; no browser storage, network, telemetry or Party writing.
// Download *requested* does not establish that a file was saved by Android.
(function(){
 const root=document.getElementById('r40-author');
 if(!root||!root.parentNode||typeof root.parentNode.insertBefore!=='function'||
  typeof document.querySelectorAll!=='function'||typeof document.addEventListener!=='function'||
  typeof window==='undefined'||typeof window.addEventListener!=='function'||typeof document.createElement!=='function')return;
 const status=document.createElement('section');status.id='r45-draft-safety';status.className='box';
 const h=document.createElement('h2');h.textContent='R45 — Proteção do trabalho local (Mestre-only)';
 const p=document.createElement('p');p.className='small';
 p.textContent='As notas NÃO são salvas automaticamente e não possuem prova de autoria. Baixe e confira uma cópia privada ANTES de fechar/recarregar, redefinir ficha ou importar outra minuta. Um clique em Baixar não comprova que o Android armazenou o arquivo.';
 const table=document.createElement('p');table.id='r45-safety-status';table.className='small';table.setAttribute('role','status');
 status.append(h,p,table);root.parentNode?.insertBefore(status,root);
 const cfg=[
  {id:'R40 (50 notas)',selector:'#r40-decision-fields textarea',events:['craft-r40-export-requested','craft-r40-notes-imported']},
  {id:'R31 (11 respostas)',selector:'#r31-decision-fields textarea',events:['craft-r31-export-requested','craft-r31-notes-imported']},
  {id:'R46 (72 campos)',selector:'#r35-r46-fields input[data-kind]',events:['craft-r35-export-requested','craft-r35-reset','craft-r35-notes-imported']}
 ];
 // A saved marker means only "most recent export was requested or older draft imported".
 const saved=new Map(),snapshot=c=>Array.from(document.querySelectorAll(c.selector)).map(x=>x.value);
 const isPopulated=x=>x.some(v=>typeof v==='string'&&v.trim().length>0);
 for(const c of cfg){saved.set(c.id,[]);for(const e of c.events)document.addEventListener(e,()=>{saved.set(c.id,snapshot(c));render();});}
 function pending(){return cfg.map(c=>{const values=snapshot(c),baseline=saved.get(c.id)||[];
  const changed=values.length!==baseline.length||values.some((v,i)=>v!==baseline[i]);
  return{id:c.id,count:values.filter(v=>v.trim()).length,unsaved:changed&&(isPopulated(values)||isPopulated(baseline)),
   export_is_not_receipt:true};});}
 function render(){const list=pending();table.textContent=list.map(x=>x.id+': '+x.count+' preenchidos'+(x.unsaved?' · EXPORTAÇÃO RECOMENDADA':' · sem novas alterações detectadas')).join(' | ')+'. TEST, sem autenticação, sem RC5.';}
 for(const c of cfg){const el=document.querySelector(c.selector)?.closest('section')||document.querySelector(c.selector)?.parentNode;el?.addEventListener?.('input',render);}
 window.addEventListener('beforeunload',function(e){if(pending().some(x=>x.unsaved)){e.preventDefault();e.returnValue='';}});
 document.addEventListener('craft-r40-notes-imported',render);
 render();
})();
