// R35: ergonomic input for the three PREEXISTING R46 requests. No physical certification.
const r35Root=document.getElementById('r35-r46-fields'),r35Status=document.getElementById('r35-status');
if(r35Root&&typeof r35Root.appendChild==='function'){
 let r35Baseline=null,r35ProjectSnapshot=null;
 function r35Build(){
  r35Root.replaceChildren();
  r35Baseline=evidencePlan(valid(PROJECT,INDEX).items);
  r35ProjectSnapshot=JSON.stringify(PROJECT);
  let nodeN=0,fieldN=0;
  for(const proj of r35Baseline.projects)for(const node of proj.targeted_material_requests){
   const container=document.createElement('details');container.className='r35-node';
   const title=document.createElement('summary');title.textContent=node.proposal_id+' / '+node.node_id+' — '+node.material_role;
   container.appendChild(title);
   const explain=document.createElement('p');explain.textContent='Precedente pesquisado, NÃO prova. Cada campo pode permanecer vazio. Não registrar segredo Player.';explain.className='small';container.appendChild(explain);
   function field(label,key,kind,idx){
    const lab=document.createElement('label'),input=document.createElement('input');
    lab.textContent=label;input.type='text';input.maxLength=(kind==='proof'?2048:4096);
    input.dataset.projectId=node.proposal_id;input.dataset.nodeId=node.node_id;
    input.dataset.kind=kind;input.dataset.key=key;if(idx!==undefined)input.dataset.requirementIndex=String(idx);
    input.placeholder=kind==='proof'?'Link https://... ou vazio':'Observação real/relato ou vazio';
    container.appendChild(lab);container.appendChild(input);fieldN++;
   }
   node.evidence_requirements.forEach((req,i)=>{field(req.key+' — '+req.request,req.key,'observed',i);field('Prova/URL para '+req.key,req.key,'proof',i)});
   for(const key of Object.keys(node.r46_record))field('R46: '+key,key,'r46');
   r35Root.appendChild(container);nodeN++;
  }
  r35Status.textContent='Coleta local para '+nodeN+' nós e '+fieldN+' campos. Nenhum dado preenchido ou verificado.';
 }
 function r35CreateReport(){
  if(JSON.stringify(PROJECT)!==r35ProjectSnapshot)return {verdict:'REJECT_PROPOSAL_VERSION_CHANGED'};
  const report=JSON.parse(JSON.stringify(r35Baseline));
  for(const input of r35Root.querySelectorAll('input[data-kind]')){
   const p=report.projects.find(p=>p.proposal_id===input.dataset.projectId);
   const n=p?.targeted_material_requests.find(n=>n.node_id===input.dataset.nodeId);
   if(!n)return {verdict:'REJECT_TARGET_DRIFT'};
   const val=input.value.trim()||null;
   if(input.dataset.kind==='r46')n.r46_record[input.dataset.key]=val;
   else if(input.dataset.kind==='observed')n.evidence_requirements[Number(input.dataset.requirementIndex)].observed_data=val;
   else if(input.dataset.kind==='proof')n.evidence_requirements[Number(input.dataset.requirementIndex)].proof_url=val;
  }
  const review=reviewR46Report(report,r35Baseline);
  if(review.verdict!=='REPORTED_DATA_TRIAGED_NOT_VERIFIED')return {verdict:'REJECT_REPORT_INVALID',reason:review.reason};
  return {verdict:'R46_DRAFT_REPORTED_NOT_VERIFIED',report,review};
 }
 // R48: restore the existing 72-field private R46 draft after reopening the offline HTML.
 // Never persist private notes automatically; validating a JSON and requesting overwrite consent is not a receipt,
 // an authenticated Master decision, or proof of any physical measurement.
 let r48ImportEpoch=0;
 const r48Upload=document.getElementById('r35-resume-upload');
 if(r48Upload)r48Upload.addEventListener('change',async e=>{
  const file=e.target.files?.[0];if(!file)return;
  const sequence=++r48ImportEpoch;
  const beforeProject=JSON.stringify(PROJECT),beforeValues=Array.from(r35Root.querySelectorAll('input[data-kind]')).map(x=>x.value);
  const deny=reason=>{r35Status.textContent='R48 — RETOMADA REJEITADA: '+reason+'. Nenhum campo foi substituído; use coleta da proposta atual.';};
  try{
   if(file.size>262144){deny('ARQUIVO_ACIMA_256K');return;}
   const incoming=JSON.parse(await file.text());
   if(sequence!==r48ImportEpoch){deny('IMPORTACAO_SUPERADA');return;}
   if(JSON.stringify(PROJECT)!==beforeProject||beforeProject!==r35ProjectSnapshot){deny('VERSAO_PROPOSTA_MUDOU');return;}
   const inputs=Array.from(r35Root.querySelectorAll('input[data-kind]'));
   if(inputs.length!==beforeValues.length||inputs.some((input,i)=>input.value!==beforeValues[i])){deny('CAMPOS_MUDARAM_DURANTE_LEITURA');return;}
   const verdict=reviewR46Report(incoming,r35Baseline);
   if(verdict.verdict!=='REPORTED_DATA_TRIAGED_NOT_VERIFIED'){deny(verdict.reason||verdict.verdict);return;}
   const staged=new Map();
   for(const project of incoming.projects)for(const node of project.targeted_material_requests){
    const rootId=node.proposal_id+'\u001f'+node.node_id;
    node.evidence_requirements.forEach((req,i)=>{
     staged.set(rootId+'\u001fobserved\u001f'+i,req.observed_data);
     staged.set(rootId+'\u001fproof\u001f'+i,req.proof_url);
    });
    for(const [key,val] of Object.entries(node.r46_record))staged.set(rootId+'\u001fr46\u001f'+key,val);
   }
   if(inputs.length!==72&&inputs.length!==48&&inputs.length!==24){deny('CONTAGEM_DE_CAMPOS_INESPERADA');return;}
   if(staged.size!==inputs.length){deny('MAPEAMENTO_INCOMPLETO');return;}
   const proposed=[];const seen=new Set();
   for(const input of inputs){
    const id=input.dataset.projectId+'\u001f'+input.dataset.nodeId+'\u001f'+input.dataset.kind+'\u001f'+
      (input.dataset.kind==='r46'?input.dataset.key:input.dataset.requirementIndex);
    if(seen.has(id)||!staged.has(id)){deny('IDENTIDADE_CAMPO_INCOMPATIVEL');return;}
    seen.add(id);const val=staged.get(id);
    // R49: the HTML form is text-only. Reject numeric/whitespace-coerced values
    // rather than silently changing their type or contents during a round trip.
    if(val!==null&&(typeof val!=='string'||val!==val.trim()||val.length>input.maxLength)){
      deny('TIPO_OU_TEXTO_NAO_RESTAURAVEL_SEM_PERDA');return;
    }
    proposed.push(val===null?'':val);
   }
   const populated=beforeValues.filter(v=>v.trim()).length;
   const wouldReplace=beforeValues.some((v,i)=>v!==proposed[i]);
   if(populated&&wouldReplace){
    if(typeof window.confirm!=='function'||!window.confirm('R48: '+populated+' campos locais preenchidos serão substituídos pela coleta importada. Confira se exportou uma cópia. Continuar?')){
      r35Status.textContent='R48 — IMPORTAÇÃO CANCELADA. '+populated+' campos locais preservados.';return;
    }
   }
   if(sequence!==r48ImportEpoch||JSON.stringify(PROJECT)!==beforeProject||inputs.some((input,i)=>input.value!==beforeValues[i])){
    deny('ESTADO_MUDOU_ANTES_DA_APLICACAO');return;
   }
   inputs.forEach((input,i)=>{input.value=proposed[i]});
   r35Status.textContent='R48 — '+verdict.fields_reported+'/'+verdict.fields_required+' campos RESTAURADOS da minuta TEST; autoria, laudo, magia, RC5 e produção NÃO verificados.';
   document.dispatchEvent(new Event('craft-r35-notes-imported'));
  }catch(err){deny('JSON_INVALIDO_OU_NAO_SUPORTADO');}
  finally{r48Upload.value='';}
 });
 document.getElementById('r35-reset').addEventListener('click',()=>{
   const populated=Array.from(r35Root.querySelectorAll('input[data-kind]')).filter(e=>e.value.trim()).length;
   // Real Android may not show beforeunload: explicit destructive-action gate.
   if(populated>0 && (typeof window==='undefined'||typeof window.confirm!=='function'||
      !window.confirm('Há '+populated+' campos de coleta preenchidos. Recriar apagará estes relatos locais. Já exportou uma cópia?'))){
      r35Status.textContent='Recriação CANCELADA. '+populated+' campos preservados; exporte o relato antes de recriar.';
      return;
   }
   r35Build();document.dispatchEvent(new Event('craft-r35-reset'));
 });
 document.getElementById('r35-export').addEventListener('click',()=>{
  const x=r35CreateReport();if(x.verdict!=='R46_DRAFT_REPORTED_NOT_VERIFIED'){
    r35Status.textContent='REJEITADO — '+(x.reason||x.verdict)+'; reconstruir ficha se a versão das propostas mudou.';return;
  }
  const blob=new Blob([JSON.stringify(x.report,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='CRAFT_R35_COLETA_R46_NAO_VERIFICADA_MESTRE_TEST.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
  r35Status.textContent=x.review.fields_reported+'/'+x.review.fields_required+' campos declarados; 0 laudos comprovados. Verifique se o download foi guardado; use a triagem R29.';document.dispatchEvent(new Event('craft-r35-export-requested'));
 });
 r35Build();
}
