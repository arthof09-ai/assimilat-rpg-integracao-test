"""Deterministic R49 Mestre-only TEST distribution. No external writes."""
from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parent
manifest=root/'MANIFEST-R49.json'
archive=root.parent/'CRAFT_R49_RETOMADA_COLETA_R46_MESTRE_TEST_20261022.zip'
files=sorted(p for p in root.rglob('*') if p.is_file() and p!=manifest and '__pycache__' not in p.parts and p.suffix!='.pyc')
m={'schema':'CRAFT_R49_TEST_MANIFEST_V1','classification':'MESTRE-SIDE_ONLY_DO_NOT_SEND_PARTY',
 'source_checkpoint':'R47','output_checkpoint':'R49',
 'non_authority':{'canonical_writes':0,'party_writes':0,'production_gate':False,'android_hardware_certified':False},
 'files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[manifest]:
  name=p.relative_to(root).as_posix();i=zipfile.ZipInfo(name,date_time=(2026,10,22,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16
  z.writestr(i,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('R49',len(files),'files + manifest, SHA256',hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes',archive.stat().st_size)
