# CRAFT R49 — Retomada segura de coleta R46, Mestre-only TEST

Origem: pacote canário R47 integralmente preservado; diffs localizados no **mesmo revisor** (`build_mobile.py`, `src/r35_r46_mobile_form.js`, `src/r45_draft_safety_browser.js`) e uma nova suíte de regressão `tests/test_browser_r48.py`. Não é novo motor, não autoriza Notion write ou produção.

`python build_mobile.py` recompila a página. `python replay_r49.py` verifica manifest e executa JS/QA; `python replay_r49.py --full` inclui Chromium instalado localmente. Não execute writer canônico. Dados exclusivos do Mestre: não distribua página HTML, CSVs ou ZIP à Party.

Antigos MANIFEST-R* e replay_r* foram mantidos como histórico de suas respectivas versões, **não são validadores da versão R49**. Somente MANIFEST-R49/replay_r49 governam o ZIP atual.
