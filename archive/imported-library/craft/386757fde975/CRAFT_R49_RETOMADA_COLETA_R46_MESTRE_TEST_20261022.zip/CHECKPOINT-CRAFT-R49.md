# CHECKPOINT — CRAFT R49 — 22/10/2026 — Mestre-only TEST

**Operação existente:** OP-ARQ-RIN-REC-01 / CRAFT, continuidade R47 → R48/R49. **NAC-AUTO-01 continua PROPOSTA**, não declarado canonizado.

## Delta funcional verificado

- **R48** — O mesmo revisor HTML offline R53 recupera um relato R46 exportado em JSON por meio de `r35-resume-upload`, dentro do formulário R35 existente. Valida o documento antes da aplicação com `reviewR46Report` (R29), compara versão congelada de `PROJECT`, identifica individualmente os 3 nós e seus 72 campos e mapeia 48/24 nos subconjuntos válidos quando uma proposta alterada sai da fila. Limite do upload 256 KiB. Substituição de campo já preenchido exige consentimento explícito; cancelar/arquivo adulterado preserva o estado local. Upload reseta após êxito/erro para permitir reler o mesmo arquivo.
- **R49** — A restauração rejeita silenciosas conversões de tipo, truncamento por tamanho e normalização de espaços (`TIPO_OU_TEXTO_NAO_RESTAURAVEL_SEM_PERDA`). Valores numéricos permitidos pela triagem textual R29 não são reinterpretados como texto pelo formulário. Minutas geradas originalmente pelo R35 fazem ida-e-volta JSON → HTML → JSON com dados estruturados idênticos.
- **R45 integrado** — Marcador de alterações não exportadas passa a reconhecer a retomada `craft-r35-notes-imported`. Continua sem armazenamento local automático e sem garantia de download no Android.

## Denominadores e provas

- 30 suítes JS herdadas: **1.765/1.765 PASS**.
- 24 suítes Chromium em 3 blocos: **814/814 PASS**, incluindo nova suíte R48 **36/36** e 778 verificações herdadas.
- 2.000/2.000 sondagens sintéticas separadas, não contadas como verificações JS.
- Gerador de QA e verificador de recibo PASS; QA e prévia hipotética não mudaram em relação a R47. Sonda e Tônico permanecem `HOLD_TEST_DESIGN`.
- R49 distribuído com `MANIFEST-R49.json`, verificador `replay_r49.py` e arquivo ZIP determinístico. Conferir execução limpa e readback da Biblioteca no PSV.

## Garantias negativas / gates

- **29 receitas Mestre**, 21 divergências históricas, 8 sem divergência lexical identificada; **50 perguntas sem resposta autenticada** e **3 nós materiais sem laudo R46 verdadeiro**.
- Fencing C19-021, IBX-38 e IBX-116 sem ACK, R51/REC-LIB sem homologação, RC5 e produção HOLD. Fichas físicas/estoque/PA/Party/O Primeiro NO-WRITE. O arquivo exportado é relato não verificado, mesmo completamente preenchido.
- Em 22/10/2026, Notion permitiu fetch/search, não writer. Última sincronização documental CRAFT efetivamente encontrada no Notion: R13. R14–R49 são pacotes TEST/Biblioteca, NÃO atos canônicos.
- Chrome Android **real não testado**; Chromium móvel emulado validado. Não presumir custódia de download por `a.click()`.

## Próxima retomada exata

1. Recuperar R49 da Biblioteca Mestre /Comestre e reproduzir em extração limpa com `python replay_r49.py` e `--full` se houver Chromium local.
2. Testar importação, exportação e reabertura R35 num **Chrome Android físico** no ambiente Mestre, se acessível; identificar eventuais diferenças do seletor de arquivos e confirmação de download.
3. Rechecar Notion e gates antes de qualquer decisão material. Receber decisões realmente autenticadas para as 50 questões e laudos R46 independentes dos 3 nós; a coleta offline não é laudo.
4. Só então, com fencing C19-021, ACK e writer competente, iniciar reconciliação REC-LIB/RC5 e NAC-PASS proporcional, sem duplicar receitas ou alterar Party/O Primeiro.
