from pathlib import Path
from playwright.sync_api import sync_playwright
from tempfile import TemporaryDirectory
import json
root=Path(__file__).resolve().parents[1]; html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text();n=0
def ok(cond,msg):
 global n
 assert cond,msg;n+=1
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 errors=[]; requests=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http://','https://')) else None)
 page.set_content(html,wait_until='load')
 ok(page.locator('#r42-navigator').count()==1,'new nav');ok(page.locator('.r40-case').count()==22,'22 old cases');ok(page.locator('#r40-decision-fields textarea').count()==50,'50 preserved')
 ok('22/22' in page.locator('#r42-nav-status').inner_text(),'all');ok('50/50' in page.locator('#r42-nav-status').inner_text(),'50')
 ok(page.locator('#r31-decision-fields textarea').count()==11,'r31 preserved');ok(page.locator('#r35-r46-fields input').count()==72,'r35 preserved')
 page.locator('#r42-priority').select_option('P1');ok(page.locator('.r40-case:visible').count()==5,'P1 count')
 page.locator('#r42-priority').select_option('P2');ok(page.locator('.r40-case:visible').count()==13,'P2 count')
 page.locator('#r42-priority').select_option('UPSTREAM');ok(page.locator('.r40-case:visible').count()==1,'upstream')
 page.locator('#r42-priority').select_option('ALL');page.locator('#r42-search').fill('Matriz de Cultivo');ok(page.locator('.r40-case:visible').count()>=1,'search')
 ok(page.locator('.r40-case:visible').first.locator('summary').inner_text().startswith('MAT-03'),'mat03')
 page.locator('#r42-search').fill('não existe material absurdo');ok(page.locator('.r40-case:visible').count()==0,'no results');ok(page.locator('#r42-first-pending').is_disabled(),'disable when none')
 page.locator('#r42-clear').click();ok(page.locator('.r40-case:visible').count()==22,'reset all')
 page.locator('#r42-progress').select_option('UNTOUCHED');ok(page.locator('.r40-case:visible').count()==22,'untouched')
 page.locator('#r42-first-pending').click();ok(page.locator('.r40-case').first.evaluate('(e)=>e.open'),'opens first');ok(page.locator('.r40-case').first.locator('textarea').first.evaluate('(e)=>document.activeElement===e'),'focuses pending')
 t=page.locator('.r40-case').first.locator('textarea');t.first.fill('anotação privada não autenticada');ok('1/50' in page.locator('#r42-nav-status').inner_text(),'1 note')
 page.locator('#r42-progress').select_option('PARTIAL');ok(page.locator('.r40-case:visible').count()==1,'one partial')
 page.locator('#r42-first-pending').click();ok(t.nth(1).evaluate('(e)=>document.activeElement===e'),'focus missing slot')
 t.nth(1).fill('segunda nota');page.locator('#r42-progress').select_option('COMPLETE');ok(page.locator('.r40-case:visible').count()==1,'completed group')
 page.locator('#r42-progress').select_option('INCOMPLETE');ok(page.locator('.r40-case:visible').count()==21,'incomplete group count')
 with TemporaryDirectory() as d:
  with page.expect_download() as out:page.locator('#r40-save').click()
  f=Path(d)/'draft.json';out.value.save_as(f);x=json.loads(f.read_text())
  ok(x['cases'][0]['slots'][0]['author_note']=='anotação privada não autenticada','draft preserved through filters')
  ok(x['cases'][0]['slots'][1]['author_note']=='segunda nota','second preserved')
  ok(x['no_canonical_write'] and x['no_rc5_approval'] and x['no_player_release'],'flags')
  page.locator('#r42-clear').click();page.locator('.r40-case').first.evaluate('(e)=>e.open=true');t.first.fill('temporário')
  page.locator('#r40-upload').set_input_files(f)
  page.wait_for_function("document.querySelector('.r40-case textarea').value==='anotação privada não autenticada'")
  ok(t.first.input_value()=='anotação privada não autenticada','import preserved')
  ok('2/50' in page.locator('#r42-nav-status').inner_text(),'nav recomputes after import')
 ok(not requests,'zero network requests');ok(not errors,'zero page errors')
 for w in [320,360,390,430]:
  page.set_viewport_size({'width':w,'height':800});ok(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),f'no overflow {w}')
 b.close()
print('R42 Chromium mobile '+str(n)+'/'+str(n)+' PASS')
