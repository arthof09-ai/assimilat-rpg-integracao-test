from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,json
root=Path(__file__).resolve().parents[1];html=(root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_text();n=0
def ok(x,label):
 global n
 assert x,label;n+=1
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 p=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 err=[];net=[];p.on('pageerror',lambda e:err.append(str(e)));p.on('request',lambda r:net.append(r.url) if r.url.startswith(('http:','https:')) else None)
 p.set_content(html,wait_until='load');p.locator('#r35-mobile-collection').evaluate('(e)=>e.open=true')
 ok(p.locator('#r35-r46-fields input').count()==72,'72 inputs')
 ok(p.locator('.r35-node').count()==3,'three nodes')
 ok('72 campos' in p.locator('#r35-status').inner_text(),'initial state')
 with tempfile.TemporaryDirectory() as td:
  td=Path(td)
  with p.expect_download() as info:p.locator('#r35-export').click()
  f=td/'empty.json';info.value.save_as(f);report=json.loads(f.read_text())
  ok(sum(len(q['targeted_material_requests']) for q in report['projects'])==3,'three original nodes')
  ok(report['release_gate']=='NO_PRODUCTION_NO_PARTY_PUBLICATION','no release')
  ok(all(req['r46_record']['operator_id'] is None for pr in report['projects'] for req in pr['targeted_material_requests']),'no fabricated operator')
  p.locator('.r35-node').first.evaluate('(e)=>e.open=true')
  fields=p.locator('#r35-r46-fields input[data-kind="observed"]');fields.first.fill('Observação TEST sem assinatura')
  p.locator('#r35-r46-fields input[data-kind="proof"]').first.fill('https://example.org/reference')
  p.locator('#r35-r46-fields input[data-kind="r46"]').first.fill('AMOSTRA-TESTE-NÃO-VALIDADA')
  with p.expect_download() as info:p.locator('#r35-export').click()
  f=td/'partial.json';info.value.save_as(f);partial=json.loads(f.read_text());ok('3/72' in p.locator('#r35-status').inner_text(),'three reported')
  node=partial['projects'][0]['targeted_material_requests'][0];ok(node['r46_record']['sample_id']=='AMOSTRA-TESTE-NÃO-VALIDADA','sample reported')
  ok(node['evidence_requirements'][0]['observed_data']=='Observação TEST sem assinatura','observation saved')
  ok(node['evidence_requirements'][0]['proof_url']=='https://example.org/reference','reference saved')
  ok(not node['physical_test_executed'] and not node['magical_transfer_demonstrated'],'no physical+magic')
  ok(not partial['projects'][0]['party_release_authorized'],'no Party')
  # the saved file is triaged by the existing R29 checker with the same source snapshot
  f2=td/'r46_upload.json';f2.write_text(json.dumps(partial,ensure_ascii=False));p.locator('#r46-upload').set_input_files(f2)
  p.wait_for_function("document.querySelector('#r46-status').textContent.includes('3/72')",timeout=5000)
  ok('3/72' in p.locator('#r46-status').inner_text(),'R29 triage accepts R35 file')
  ok(p.locator('#r46-export').is_enabled(),'R29 triage enabled')
  # invalid URL, no document exported; input is not construed as proof
  p.locator('#r35-r46-fields input[data-kind="proof"]').first.fill('javascript:alert(1)')
  p.locator('#r35-export').click()
  ok('REJEITADO' in p.locator('#r35-status').inner_text(),'unsafe URL rejected')
  p.locator('#r35-r46-fields input[data-kind="proof"]').first.fill('')
  # modified proposal invalidates old material form until explicitly rebuilt
  p.evaluate("PROJECT.products[0].design+=' nova variante';render(true)")
  p.locator('#r35-export').click()
  ok('REJEITADO' in p.locator('#r35-status').inner_text(),'proposal version drift')
  p.locator('#r35-reset').click()
  ok(p.locator('#r35-r46-fields input').count()==48,'reset dropped changed Sonda node but preserved Tonico nodes')
  ok(all(not x for x in p.locator('#r35-r46-fields input').evaluate_all('(els)=>els.map(e=>e.value)')),'no old report inherited')
  with p.expect_download() as info:p.locator('#r35-export').click()
  f=td/'new_version.json';info.value.save_as(f);new_data=json.loads(f.read_text())
  ok(sum(len(pr['targeted_material_requests']) for pr in new_data['projects'])==2,'new snapshot only unchanged nodes')
  ok('0/48' in p.locator('#r35-status').inner_text(),'new partial proposal snapshot safe')
  ok(not err,err);ok(not net,net);ok(p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),'mobile width')
 b.close()
print('R35 Android-style collection UI '+str(n)+'/'+str(n)+' PASS')
