// R44 read-only Notion source metadata comparator. Equality of edit stamps is
// NOT a content hash, an authorization, physical RC5, or source identity proof.
'use strict';
function compareR44SourceStamps(baseline,live){
 const deny=(reason)=>({schema:'CRAFT_R44_NOTION_STAMP_COMPARE_TEST_V1',verdict:'HOLD_INCOMPLETE_READBACK',reason,approved_for_write:false,content_bytes_verified:false,rc5:false,party_release:false});
 const validRec=x=>x&&typeof x==='object'&&!Array.isArray(x)&&typeof x.case_key==='string'&&x.case_key.length>0&&/^[0-9a-f]{32}$/.test(x.physical_recipe_id)&&typeof x.edited==='string'&&!Number.isNaN(Date.parse(x.edited))&&typeof x.parent==='string'&&x.parent.trim();
 if(!Array.isArray(baseline)||!Array.isArray(live)||baseline.length!==29||live.length!==29||!baseline.every(validRec)||!live.every(validRec))return deny('COUNT_OR_SCHEMA');
 const a=new Map();for(const c of baseline){if(a.has(c.case_key))return deny('DUPLICATE_BASE_KEY');a.set(c.case_key,c)}
 const seen=new Set(),changed=[];
 for(const c of live){if(seen.has(c.case_key))return deny('DUPLICATE_LIVE_KEY');seen.add(c.case_key);
  const b=a.get(c.case_key);if(!b)return deny('UNKNOWN_KEY');
  if(c.physical_recipe_id!==b.physical_recipe_id)return deny('PHYSICAL_ID_CHANGED');
  if(c.edited!==b.edited||c.parent!==b.parent)changed.push({case_key:c.case_key,id:c.physical_recipe_id,
   change:c.parent!==b.parent?'PARENT_OR_NAME_DRIFT':'EDIT_STAMP_DRIFT',baseline_edit:b.edited,current_edit:c.edited,
   baseline_parent:b.parent,current_parent:c.parent});
 }
 if(seen.size!==29)return deny('MISSING_KEY');
 return {schema:'CRAFT_R44_NOTION_STAMP_COMPARE_TEST_V1',verdict:changed.length?'HOLD_SOURCE_DRIFT':'NO_TIMESTAMP_DRIFT_OBSERVED',
  source_pages_compared:29,physical_recipe_ids_unique:new Set(live.map(c=>c.physical_recipe_id)).size===29,
  edit_stamp_changes:changed.length,changed,
  strict_limitation:'Coincidência de edit stamp e parent NÃO atesta identidade de bytes, correção de receita ou homologação RC5.',
  source_body_hash_verified:false,approved_for_write:false,rc5:false,party_release:false,
  relink_suggested_automatically:false,recipe_modified:false};
}
if(typeof module!=='undefined'&&module.exports)module.exports={compareR44SourceStamps};
