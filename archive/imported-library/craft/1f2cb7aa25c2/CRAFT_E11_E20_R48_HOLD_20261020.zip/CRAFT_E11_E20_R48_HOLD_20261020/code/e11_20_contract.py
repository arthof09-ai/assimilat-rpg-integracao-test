"""CRAFT E11-E20: ADDITIVE E14/E15/E16 contract compiler on original v1.3 inputs.

This is neither original R48 nor a replacement physics / PA / R46 / R47 motor.
It may emit *candidate input*, audits and a design for discriminating observation;
it intentionally cannot issue a native R48 order, journal, verified lab report,
signature, recognized physical product, magic observation or RC5 authorization.
"""
from __future__ import annotations
import copy, hashlib, json
from decimal import Decimal
from pathlib import Path

CASE='LAB-CRAFT-VIGILIA-BOREAL-20261020-001'
KEY='SBX-VIGILIA-BOREAL-R48-TEST-v1'
SOURCES={
 'CORE-CRISTAL-AURORA':'3edc2b324ede818b9d7ad75d42f2afa2',
 'FOLHAGEM-ERVA-NORTE':'3edc2b324ede81deb8cec70bf5ca7150',
 'FIBRA-CASCA-BOREAL':'3f3c2b324ede815ab04ace5bd1074e79',
}
R48_REQUIRED_SHA256={
 'r48_factory.py':'872dc5bf1e588a9ba6f4c45421a4dddbbe7d261842a4e951fd684bfc374c6801',
 'r48_store.py':'e6f684e80e0d5c95dff8ea94cbae985b0a8e046b48886d593d6e49534f046bd1',
 'legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/r46_evidence.py':'c869d80f243b349d817c63bd0c40fc08d7b43c98ce54ec9c91d62cd42c73c85e',
}
EXPECTED_ORIGINAL_R48_KEYS=['SBX-TLI-R44-v1','SBX-MICA-R44-v1']


def hbytes(p: Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()

def hobj(obj)->str: return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def binary_access(root:Path)->dict:
    """Read-only, no imports; require EXACT original file hashes."""
    root=Path(root)
    entries=[]
    for name,expected in R48_REQUIRED_SHA256.items():
        p=root/name
        got=hbytes(p) if p.is_file() else None
        entries.append({'relative_path':name,'expected_sha256':expected,'obtained_sha256':got,
                        'verified':got==expected})
    return {'schema':'CRAFT-R48-BINARY-PREFLIGHT/TEST','original_engine_verified':all(x['verified'] for x in entries),
            'files':entries,'source':'LIBRARY_RAW_FILES_NOT_MATERIALIZED_WHEN_MISSING',
            'r48_native_orders_new':0}


def _source_id(ref):
    return ref.split('/p/')[-1].replace('-','')


def bom_wire(recipe:dict)->list[dict]:
    """Convert only the known historical FC04 fiber unit m -> cm, exactly.
    This is dimensional normalization, NOT evidence of material or stock.
    """
    bom=recipe['bom']
    if len(bom)!=3 or {x['id'] for x in bom}!=set(SOURCES):
        raise ValueError('BOM_SOURCE_SET_CHANGED')
    wires=[]
    for row in bom:
        if _source_id(row['source_ref']) != SOURCES[row['id']]:raise ValueError('BOM_SOURCE_ID_MISMATCH')
        qty=Decimal(str(row['qty']))
        if qty<=0:raise ValueError('BOM_NONPOSITIVE_QUANTITY')
        if row['id']=='FIBRA-CASCA-BOREAL':
            if row['unit']!='m_de_fibra_PROPOSTO_TEST':raise ValueError('UNSUPPORTED_FIBER_UNIT')
            normalized=qty*Decimal(100)
            unit='cm'
        else:
            if row['unit'] not in ('cristal/un','erva/un'):raise ValueError('UNSUPPORTED_MATERIAL_UNIT')
            normalized=qty
            if normalized != normalized.to_integral_value():raise ValueError('FRACTIONAL_DISCRETE_MATERIAL')
            unit='cristal' if row['id']=='CORE-CRISTAL-AURORA' else 'erva'
        if normalized != normalized.to_integral_value():raise ValueError('UNVERIFIED_FRACTIONAL_R48_DIMENSION')
        wires.append({'node_id':row['id'],'source_page_id':SOURCES[row['id']],
                      'original_quantity':str(qty),'original_unit':row['unit'],
                      'r48_proposed_quantity':str(normalized),'r48_unit':unit,
                      'quantity_status':'PROPOSED_NOT_MEASURED',
                      'unit_accepted_by_original_r48':None,
                      'source_classification':row['classification'],'function':row['role'],
                      'physical_lot_id':None,'received_quantity_observed':None,
                      'consume_order_allowed':False})
    return wires


def graph_check(recipe:dict)->dict:
    ops=recipe['operations']
    if len(ops)!=4:raise ValueError('OPERATION_COUNT_CHANGED')
    available=set(SOURCES)
    audit=[];produced=set();consumed=set()
    for index,op in enumerate(ops,1):
        missing=sorted(set(op['inputs'])-available)
        overlap=set(op['outputs']) & available
        used_twice=set(op['inputs']) & consumed
        if missing:raise ValueError('PROCESS_INPUT_MISSING:'+','.join(missing))
        if used_twice:raise ValueError('COMPONENT_CONSUMED_TWICE:'+','.join(sorted(used_twice)))
        if overlap:raise ValueError('INTERMEDIATE_DUPLICATED:'+','.join(sorted(overlap)))
        consumed.update(op['inputs'])
        available.difference_update(op['inputs'])
        available.update(op['outputs']);produced.update(op['outputs'])
        audit.append({'seq':index,'step_id':op['id'],'inputs':op['inputs'],'outputs':op['outputs'],
                      'graph_connected':True,'executed_on_material':False,'runtime_observation':None})
    if recipe['final_node'] not in available:raise ValueError('FINAL_NODE_UNREACHABLE')
    if not set(SOURCES)<=consumed:raise ValueError('BOM_NOT_ALL_USED')
    return {'graph_routed':True,'operations':audit,'physical_step_runs':0,
            'planned_output_units':1,'approved_units_observed':None,
            'losses_observed':None}


def compile_candidate(recipe:dict,pa_gate:dict,archived_contract:dict,original_root:Path)->dict:
    """Only build an input candidate with a native import/allowlist BLOCK.
    Never mark factory recognition merely because mapping succeeded.
    """
    if recipe.get('case_id')!=CASE or not recipe.get('fixture_only') or recipe.get('mode')!='FIXTURE_TEST':
        raise ValueError('CASE_OR_AUTHORITY_OUT_OF_SCOPE')
    if any(recipe.get(x) for x in ('request_publish','request_write','request_fabricate')):
        raise ValueError('OFFICIAL_OR_NATIVE_FABRICATION_NOT_AUTHORIZED')
    if set(EXPECTED_ORIGINAL_R48_KEYS)-set(archived_contract):raise ValueError('HISTORICAL_R48_CONTRACT_MISSING')
    if not pa_gate.get('pa_version_compatible'):raise ValueError('PA_VERSION_NOT_AUTHORIZED')
    totals=pa_gate.get('pa_provider_reported_total_not_approved') or {}
    if (totals.get('pa_por_dia'),totals.get('pa_ativacoes_no_cenario'))!=(12,14):
        raise ValueError('PA_RECEIPT_NOT_MATCHING_CORRECT_POLICY')
    if recipe['manufacture'].get('approved_units') is not None:
        raise ValueError('FALSE_PHYSICAL_YIELD')
    wires=bom_wire(recipe);graph=graph_check(recipe);preflight=binary_access(original_root)
    const=[ 'R48_ORIGINAL_ALLOWLIST_DOES_NOT_INCLUDE_PINGENTE',
            'R46_HAS_NO_AUTHENTIC_MAGIC_TRANSFER_SENSOR',
            'R47_AUTHENTICITY_OF_MAGIC_OBSERVATION_NOT_VERIFIED',
            'MATERIAL_LOTS_NOT_RECEIVED_OR_MEASURED',
            'SPECIALIST_AND_TOOL_CAPABILITY_UNVERIFIED',
            'MAGIC_TRANSFER_AND_RETENTION_NOT_OBSERVED',
            'R48_UNITS_CRYSTAL_AND_HERB_ACCEPTANCE_NOT_VERIFIED',
            'R48_SOURCE_REGISTRY_FOR_THREE_MATERIALS_NOT_LOADED',
            'ORIGINAL_R48_NATIVE_FACTORY_NOT_INVOKED']
    if not preflight['original_engine_verified']: const.insert(0,'R48_ORIGINAL_EXECUTABLE_NOT_MATERIALIZED')
    recipe_descriptor={'key':KEY,'case_id':CASE,'namespace':'SBX-CRAFT-R44-I0016',
                       'name':'Pingente da Vigília Boreal TEST','family':'ACESSORIO',
                       'status':'CANDIDATE_ONLY_NO_NATIVE_ORDER',
                       'inputs':[{'source_page_id':x['source_page_id'],'quantity':int(Decimal(x['r48_proposed_quantity'])),
                                  'unit':x['r48_unit']} for x in wires],
                       'planned_output':{'quantity':1,'unit':'pingente_TEST'},
                       'observed_output':None,'approved_units':None,
                       'steps':copy.deepcopy(recipe['operations']),
                       'tools_status':'UNVERIFIED_PROPOSED',
                       'specialist_status':'UNVERIFIED_PROPOSED',
                       'qa_structural':'NO_SIGNED_R46_MEASURED_LAUDO',
                       'qa_magic':'NO_R46_MAGIC_SENSOR_OR_COMPETENT_OBSERVATION',
                       'pa_test':{'daily':12,'per_activation':7,'uses':2,'total_scenario':26,
                                  'provider':'R27/R26_CORRECT_VERIFIED_IN_E1_E10'},
                       'official_rec_id':None,'official_product_id':None,
                       'has_stock':False,'physical_magic_observed':False}
    return {'schema':'CRAFT-PINGENTE-R48-ADMISSION-WIRE-v2-TEST',
            'case_id':CASE,'read_only_adapter':True,'native_factory_call':False,
            'status':'HOLD_BINARY_AND_EVIDENCE','candidate':recipe_descriptor,
            'bom_transforms':wires,'ops_audit':graph,
            'binary_preflight':preflight,'blocking_causes':const,
            'original_r48_recognized':False,'r48_native_receipt':None,
            'r48_input_schema_acceptance':'UNVERIFIED_UNTIL_ORIGINAL_BINARY_AVAILABLE',
            'evidence_status':'CANDIDATE_INPUT_ONLY_NOT_ADMITTED',
            'all_historical_stores_modified':False}


CONTROL_MATRIX=(
 ('F0_NO_MAGIC_INPUTS','SEM_CRISTAL_SEM_ERVA','absence_of_both_power_sources'),
 ('F1_NO_CRYSTAL','SEM_CRISTAL','light_possible_active_darkness_effect_unproven'),
 ('F2_NO_HERB','SEM_ERVA','crystal_possible_light_passive_herb_effect_unproven'),
 ('F3_NO_SUPPORT','MONTAGEM_INCOMPLETA','no_mechanical_retention'),
 ('F4_LOW_PA','PA_INSUFICIENTE','reject_active_use_without_available_PA'),
 ('F5_RAW_SOURCES','FONTES_SOLTAS','does_co_location_alone_show_source_property'),
 ('F6_ASSEMBLED_INACTIVE','MONTADO_INATIVO','measure_light_without_activation'),
 ('F7_ASSEMBLED_ACTIVE','MONTADO_ATIVADO','measure_distinct_darkness_disruption'),
 ('F8_AFTER_TWO_ACTIVATIONS','POS_2_USOS','retention_with_source_and_lot_identity'),
 ('F9_ORDINARY_VS_MAGICAL_DARK','ESCURIDAO_COMUM_VS_MAGICA','separate optical visibility from supernatural cancellation')
)

def magic_transfer_protocol(recipe:dict)->dict:
    """Protocol, not test results. H1 native-source co-location, H2 transfer.
    Neither is assumed real merely because R48 or simulated controls pass.
    """
    if recipe['case_id']!=CASE:raise ValueError('WRONG_CASE')
    plans=[]
    for cid,condition,hyp in CONTROL_MATRIX:
        plans.append({'control_id':cid,'input_state':condition,'falsifiable_question':hyp,
                      'source_sample_ids':None,'observation_event_ids':None,
                      'independent_comparator_id':None,'metric_and_unit':None,
                      'actual_observation':None,'outcome':'NOT_OBSERVED',
                      'source_kind':'PROTOCOL_ONLY_NOT_PHYSICAL_EVIDENCE',
                      'magic_observed':False})
    return {'schema':'CRAFT-MAGIC-TRANSFER-PROTOCOL/1.0-TEST','case_id':CASE,
            'observed_sample_count':0,'observed_magic_count':0,
            'models_to_discriminate':{
                'H1_COLOCATION':'Magical raw sources retain THEIR OWN behavior after passive mounting; no transfer to carrier is established',
                'H2_TRANSFER':'Finished carrier expresses an effect absent in unattached sources after controlled separation from raw-core effect; needs competent rule/measurement',
                'H3_PA_COUPLING':'An independent interface causes change on paying PA, versus 0/insufficient PA; interface mechanism must be sourced, not assumed',
                'H4_RETENTION':'Repeated use does not lose effect under documented time/conditions; no decay value assumed'},
            'critical_gap':'NO_CANONICAL_TRANSFER_INTERFACE_FOR_THIS_RECIPE_AND_NO_MAGIC_R46_SENSOR',
            'observation_authority':'PENDENTE_MAGIA_MESTRE_OR_VLAB_COMPETENT_RULE_AND_LAB_EVIDENCE',
            'darkness_definition':'PENDENTE_ACTUAL_SPELL_CASE_NORMAL_VS_SUPERNATURAL',
            'tests':plans,'physical_magic_effect_proven':False,
            'result':'PROTOCOL_FALSIFIABLE_TEST_DESIGNED_BUT_NOT_EXECUTED_PHYSICALLY'}


def r46_r47_receipt_gate(packet:dict,original_binary_verified:bool)->dict:
    """Consumer boundary only: never validate Ed25519 locally instead of original R47.
    Require ORIGINAL R46/R47 verdict objects and actual observed sources to clear.
    Current runtime must always reject because original binary absent.
    """
    reasons=[]
    if not original_binary_verified:reasons.append('ORIGINAL_R48_R46_R47_RUNTIME_NOT_AVAILABLE')
    if packet.get('recipe_key')!=KEY:reasons.append('WRONG_RECIPE_KEY')
    if packet.get('case_id')!=CASE:reasons.append('WRONG_CASE_ID')
    request_lots=packet.get('lot_ids')
    report=packet.get('r46_report')
    auth=packet.get('r47_attestation')
    if not isinstance(request_lots,list) or not request_lots or len(request_lots)!=len(set(request_lots)):
        reasons.append('LOT_IDS_INVALID_OR_NOT_PRESENT')
    if not isinstance(report,dict):reasons.append('R46_REPORT_ABSENT')
    else:
        if report.get('schema')!='R46-LAUDO-v1':reasons.append('R46_SCHEMA_INVALID')
        if report.get('recipe_key')!=KEY:reasons.append('R46_RECIPE_MISMATCH')
        if report.get('lot_ids')!=request_lots:reasons.append('R46_LOT_IDS_MISMATCH')
        if report.get('evidence_kind') not in ('PHYSICALLY_OBSERVED','INDEPENDENT_OBSERVATION'):
            reasons.append('SYNTHETIC_OR_UNVERIFIED_EVIDENCE_NOT_PHYSICAL')
        if not report.get('observations'):
            reasons.append('R46_MEASUREMENTS_EMPTY')
    if not isinstance(auth,dict):reasons.append('R47_ATTESTATION_ABSENT')
    else:
        if auth.get('schema')!='R47-AUTHENTICITY-v1':reasons.append('R47_SCHEMA_INVALID')
        if not auth.get('certificates'):reasons.append('R47_MISSING_CERTIFICATE')
        if not auth.get('custody_events'):reasons.append('R47_MISSING_CUSTODY')
    if packet.get('external_r46_verification') != 'VERIFIED_BY_ORIGINAL_R46':
        reasons.append('ORIGINAL_R46_VALIDATION_MISSING')
    if packet.get('external_r47_verification') != 'VERIFIED_BY_ORIGINAL_R47_WITH_REAL_TRUST_ROOT':
        reasons.append('ORIGINAL_R47_TRUST_VALIDATION_MISSING')
    # Crucially, a text string claiming verdict is NOT proof unless original
    # runtime was actually authenticated. Final gate includes original_binary_verified.
    if packet.get('magic_observation_competent') is not True:
        reasons.append('MAGIC_EFFECT_NOT_COMPETENTLY_OBSERVED')
    if packet.get('physical_sample_observed') is not True:
        reasons.append('PHYSICAL_SAMPLE_NOT_OBSERVED')
    reasons.append('ORIGINAL_RUNTIME_READBACK_AND_COMPETENT_MAGIC_EVIDENCE_GATE_NOT_IMPLEMENTED')
    return {'schema':'CRAFT-R48-EVIDENCE-BOUNDARY/1.0-TEST',
            'allowed_to_claim_verified_magic':False,
            'rejection_reasons':reasons,'original_r48_invoked':False,
            'kind':'READ_ONLY_CONSUMER_PREFLIGHT_NOT_R46_R47_ORIGINAL'}
