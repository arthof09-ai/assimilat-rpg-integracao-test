"""Isolated additive test contract package; not an R48 engine."""
