import copy, json, tempfile, unittest
from pathlib import Path
from .e11_20_contract import (CASE,KEY,SOURCES,binary_access,bom_wire,graph_check,compile_candidate,magic_transfer_protocol,r46_r47_receipt_gate)
BASE=Path(__file__).resolve().parents[1]

def loads(name):return json.loads((BASE/'fixtures'/name).read_text(encoding='utf8'))

class E11E20ContractTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.recipe=loads('recipe_v1_3_original.json');cls.pa=loads('pa_gate_original.json');cls.hist=loads('archived_R48_contract_original.json')
 def compiler(self,r=None,p=None,h=None):
  return compile_candidate(self.recipe if r is None else r,self.pa if p is None else p,self.hist if h is None else h,BASE/'no_binary')
 def test_01_case_unique(self):self.assertEqual(self.recipe['case_id'],CASE)
 def test_02_source_set(self):self.assertEqual(set(SOURCES),{r['id'] for r in self.recipe['bom']})
 def test_03_fiber_unit_normalized(self):
  w=bom_wire(self.recipe); f=next(x for x in w if x['node_id']=='FIBRA-CASCA-BOREAL');self.assertEqual((f['original_quantity'],f['r48_proposed_quantity'],f['r48_unit']),('0.45','45.00','cm'))
 def test_04_malformed_fiber_unit_rejected(self):
  r=copy.deepcopy(self.recipe);r['bom'][2]['unit']='unknown';self.assertRaises(ValueError,bom_wire,r)
 def test_05_source_swap_rejected(self):
  r=copy.deepcopy(self.recipe);r['bom'][0]['source_ref']=r['bom'][1]['source_ref'];self.assertRaises(ValueError,bom_wire,r)
 def test_06_false_inventory_blocked(self):self.assertTrue(all(not x['consume_order_allowed'] for x in bom_wire(self.recipe)))
 def test_07_zero_material_rejected(self):
  r=copy.deepcopy(self.recipe);r['bom'][0]['qty']=0;self.assertRaises(ValueError,bom_wire,r)
 def test_08_graph_connected(self):self.assertEqual(len(graph_check(self.recipe)['operations']),4)
 def test_09_graph_cyclic_reference_rejected(self):
  r=copy.deepcopy(self.recipe);r['operations'][0]['inputs'].append('PINGENTE-VIGILIA-TEST');self.assertRaises(ValueError,graph_check,r)
 def test_10_graph_duplicate_intermediate_rejected(self):
  r=copy.deepcopy(self.recipe);r['operations'][1]['outputs']=['INTERMEDIARIO-CORDAO'];self.assertRaises(ValueError,graph_check,r)
 def test_11_false_production_denied(self):
  r=copy.deepcopy(self.recipe);r['request_fabricate']=True;self.assertRaises(ValueError,self.compiler,r)
 def test_12_false_yield_denied(self):
  r=copy.deepcopy(self.recipe);r['manufacture']['approved_units']=1;self.assertRaises(ValueError,self.compiler,r)
 def test_13_correct_pa_checked(self):
  x=self.compiler();self.assertEqual(x['candidate']['pa_test']['total_scenario'],26)
 def test_14_bad_pa_denied(self):
  p=copy.deepcopy(self.pa);p['pa_provider_reported_total_not_approved']['pa_por_dia']=11;self.assertRaises(ValueError,self.compiler,None,p)
 def test_15_wrong_historical_contract_rejected(self):self.assertRaises(ValueError,self.compiler,None,None,{})
 def test_16_no_r48_claim(self):
  x=self.compiler();self.assertFalse(x['native_factory_call']);self.assertIsNone(x['r48_native_receipt'])
 def test_17_missing_binary_preflight(self):self.assertFalse(binary_access(BASE/'no_binary')['original_engine_verified'])
 def test_18_magic_protocol_not_observed(self):
  x=magic_transfer_protocol(self.recipe);self.assertEqual(x['observed_magic_count'],0);self.assertEqual(len(x['tests']),10)
 def test_19_hypothesis_distinct(self):
  x=magic_transfer_protocol(self.recipe);self.assertIn('H1_COLOCATION',x['models_to_discriminate']);self.assertIn('H2_TRANSFER',x['models_to_discriminate'])
 def test_20_negative_report_denied(self):
  x=r46_r47_receipt_gate({'case_id':CASE,'recipe_key':KEY},False);self.assertFalse(x['allowed_to_claim_verified_magic'])
 def test_21_synthetic_fraud_denied(self):
  pkt={'case_id':CASE,'recipe_key':KEY,'lot_ids':['LOT1'],
       'r46_report':{'schema':'R46-LAUDO-v1','recipe_key':KEY,'lot_ids':['LOT1'],'evidence_kind':'SYNTHETIC','observations':{'magic':True}},
       'r47_attestation':{'schema':'R47-AUTHENTICITY-v1','certificates':[1],'custody_events':[1]},
       'external_r46_verification':'VERIFIED_BY_ORIGINAL_R46','external_r47_verification':'VERIFIED_BY_ORIGINAL_R47_WITH_REAL_TRUST_ROOT',
       'physical_sample_observed':True,'magic_observation_competent':True}
  self.assertFalse(r46_r47_receipt_gate(pkt,False)['allowed_to_claim_verified_magic'])
 def test_22_lot_swap_denied(self):
  pkt={'case_id':CASE,'recipe_key':KEY,'lot_ids':['LOT-A'],'r46_report':{'schema':'R46-LAUDO-v1','recipe_key':KEY,'lot_ids':['LOT-B'],'evidence_kind':'SYNTHETIC'}}
  self.assertIn('R46_LOT_IDS_MISMATCH',r46_r47_receipt_gate(pkt,False)['rejection_reasons'])
 def test_23_missing_magic_observation_denied(self):
  x=r46_r47_receipt_gate({'case_id':CASE,'recipe_key':KEY,'lot_ids':['A']},False);self.assertIn('MAGIC_EFFECT_NOT_COMPETENTLY_OBSERVED',x['rejection_reasons'])
 def test_24_duplicate_lot_denied(self):
  x=r46_r47_receipt_gate({'case_id':CASE,'recipe_key':KEY,'lot_ids':['A','A']},False);self.assertIn('LOT_IDS_INVALID_OR_NOT_PRESENT',x['rejection_reasons'])
 def test_25_fake_report_not_product(self):
  c=self.compiler();self.assertIsNone(c['ops_audit']['approved_units_observed'])
 def test_26_hypothetical_specs_remain_pending(self):
  x=magic_transfer_protocol(self.recipe);self.assertTrue(all(t['actual_observation'] is None for t in x['tests']))


 def test_27_component_reuse_rejected(self):
  r=copy.deepcopy(self.recipe);r['operations'][1]['inputs'].append('FIBRA-CASCA-BOREAL');self.assertRaises(ValueError,graph_check,r)
 def test_28_source_not_used_rejected(self):
  r=copy.deepcopy(self.recipe);r['operations'][2]['inputs'].remove('CORE-CRISTAL-AURORA');self.assertRaises(ValueError,graph_check,r)
 def test_29_forged_all_claims_still_denied(self):
  pkt={'case_id':CASE,'recipe_key':KEY,'lot_ids':['L'],
       'r46_report':{'schema':'R46-LAUDO-v1','recipe_key':KEY,'lot_ids':['L'], 'evidence_kind':'PHYSICALLY_OBSERVED','observations':{'magic':True}},
       'r47_attestation':{'schema':'R47-AUTHENTICITY-v1','certificates':['fake'],'custody_events':['fake']},
       'external_r46_verification':'VERIFIED_BY_ORIGINAL_R46',
       'external_r47_verification':'VERIFIED_BY_ORIGINAL_R47_WITH_REAL_TRUST_ROOT',
       'magic_observation_competent':True,'physical_sample_observed':True}
  self.assertFalse(r46_r47_receipt_gate(pkt,True)['allowed_to_claim_verified_magic'])
 def test_30_proposed_units_unconfirmed_by_engine(self):
  self.assertTrue(all(x['unit_accepted_by_original_r48'] is None for x in bom_wire(self.recipe)))


 def test_31_outgoing_quantities_numeric(self):
  x=self.compiler()['candidate']['inputs']; self.assertEqual([a['quantity'] for a in x],[1,1,45]);self.assertTrue(all(type(a['quantity']) is int for a in x))
 def test_32_fractional_discrete_source_denied(self):
  r=copy.deepcopy(self.recipe);r['bom'][0]['qty']=0.5;self.assertRaises(ValueError,bom_wire,r)

if __name__=='__main__':unittest.main()
