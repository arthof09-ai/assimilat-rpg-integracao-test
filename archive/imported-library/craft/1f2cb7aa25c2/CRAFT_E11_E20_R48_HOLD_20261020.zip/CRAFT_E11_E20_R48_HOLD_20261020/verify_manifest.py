"""Verify additive E11-E20 delta payload: excludes pycache, no network."""
import hashlib, json, sys
from pathlib import Path
R=Path(__file__).resolve().parent
M=R/'MANIFEST_SHA256.json'
manifest=json.loads(M.read_text(encoding='utf8'))
expected=manifest['files'];got={}
for path,sha in sorted(expected.items()):
 p=R/path
 if not p.is_file():raise SystemExit('MISSING:'+path)
 got[path]=hashlib.sha256(p.read_bytes()).hexdigest()
 if sha!=got[path]:raise SystemExit('MISMATCH:'+path)
all_files={str(x.relative_to(R)) for x in R.rglob('*') if x.is_file() and '__pycache__' not in x.parts and x.name not in ('MANIFEST_SHA256.json','verify_manifest.py')}
if all_files!=set(expected):raise SystemExit('EXTRA_OR_MISSING:'+str(sorted(all_files^set(expected))))
print('MANIFEST_SHA256 PASS',len(expected),'/',len(expected),'files')
