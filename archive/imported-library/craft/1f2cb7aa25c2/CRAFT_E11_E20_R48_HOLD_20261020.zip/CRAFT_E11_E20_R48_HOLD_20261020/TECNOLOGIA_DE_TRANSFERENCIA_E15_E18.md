# CRAFT / E15 e E18 — Contrato experimental refutável (MESTRE-SIDE / TEST)

**Receita única:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001`, Pingente da Vigília Boreal v1.3. **Estado:** plano de teste, não teste físico nem magia efetivamente realizada.

## Mecanismos concorrentes que precisam ser distinguidos

**H1 — Alojamento das fontes, sem transferência.** O cristal e a erva podem continuar exercendo as propriedades que possuem **por si mesmos**, mesmo quando fisicamente presos à fibra. Se o conjunto emite luz exatamente como a erva isolada, a evidência favorece simples co-localização; não demonstra encantamento da fibra, da peça nem interface nova de PA. H1 oferece rota de engenharia mais econômica *a investigar*, mas não sustenta automaticamente efeitos ativos.

**H2 — Transferência / inscrição.** O Pingente adquire uma função que excede a mera justaposição das fontes, por método de integração/inscrição competente. REC-MOD-ENC exige meio, geometria, sequência, energização, cura/selagem e teste; REC-MOD-EQA exige interface corporal, core e estabilização. **Nenhuma ficha recuperada das três matérias fornece método determinado para fabricar esse canal ou prender permanentemente o poder do cristal.** Um procedimento de integração teria de provir de autoridade competente ou de proposta explícita ao Mestre; a R48/R46 atual não fornece sensor/lei que o torne verificado.

**H3 — Acoplamento energético ativo.** Pagar `7 PA` em uma ativação Prata TEST (além de `12 PA/dia` prospectivos) precisa correlacionar-se com um resultado **distinto** em escuridão mágica controlada; o cálculo de PA, isoladamente, não cria o efeito. Testes contra pouca luz ordinária NÃO demonstram superação de escuridão mágica, nem percepção universal, cura da cegueira ou alcance acima da hipótese E3.

**H4 — Retenção.** Se houver ativação válida, observar efeito na segunda utilização com mesmos instrumentos, controle sem ativação e identidade de lote; comparar com as fontes fora da montagem e com tempo de repouso. Sem observações replicadas não atribuir taxa de retenção/duração nem perda zero.

## Dez controles pré-registrados (não executados fisicamente)

| Controle | Estado controlado | Diferença que pode refutar hipótese | Evidência essencial ainda ausente |
|---|---|---|---|
| F0 | Fibra sem cristal e sem erva | Comprovar ausência de efeito que deveria depender de fonte | Amostra e laudo real |
| F1 | Sem cristal | Luz natural da erva ≠ dissipação ativa de escuridão | Comparador de escuridão e observação |
| F2 | Sem erva | Luz do cristal ≠ luz da erva, evitar duplicar fonte | Linha de base isolada |
| F3 | Montagem mecânica incompleta | Fixação deve resistir à inspeção, sem efeito creditado | Resistência e critérios mecânicos definidos |
| F4 | PA insuficiente | Ativação não deve ser declarada válida | Leitura de PA Livre no contexto autorizado |
| F5 | Fontes soltas próximas do portador | Comparar co-localização e montagem | Amostras e cegamento de avaliador |
| F6 | Montado, inativo | Distinguir luz intrínseca de ativação | Medição de luminosidade sob condição definida |
| F7 | Montado, PA adequado | Efeito adicional **específico** em escuridão mágica | Efeito adversário canônico escolhido, árbitro habilitado |
| F8 | Após duas ativações | Retenção e estabilidade versus fontes originais | Medições sequenciais de mesma amostra |
| F9 | Escuridão comum × mágica | Não confundir iluminação física e quebra de efeito sobrenatural | Mecânica da fonte de escuridão e alvo |

**Métricas:** só selecionar grandeza/unidade e limiar após recuperar fonte/método competente. Sem potência luminosa, duração, intensidade, 1 m de alcance, 1 turno ou limite 2/dia medidos; esses números permanecem **parâmetros TEST da proposta**, não experimentos.

**Contrato mínimo do laudo:** `case_id` imutável, chave SBX, pedido/lote/amostra (não reutilizados), antes/depois, fontes de cada material, cenário/control_id, condição ambiental e escuridão normal/mágica, PA livre e consumido conforme regra competente, leitura/unidade/incerteza/instrumento se houver, operador/cadeia de custódia, resultado positivo/negativo/ambíguo, verificação R46/R47 ORIGINAL quando disponível, e `magic_observed` validado por autoridade de adjudicação. Sem isso resultado permanece `NOT_OBSERVED` e não permite RC5.

**Resultado científico desta rodada:** nenhuma observação de magia, nenhuma amostra material, nenhum ensaio nativo novo; apenas mecanismo decomponível em hipóteses independentes, interfaces faltantes localizadas e testes que permitem falsificar transferência. Status atual H1/H2/H3/H4 = **PROPOSTO, NÃO COMPROVADO**.
