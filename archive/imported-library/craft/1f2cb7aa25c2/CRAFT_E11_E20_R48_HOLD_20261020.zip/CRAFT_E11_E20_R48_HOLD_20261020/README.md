# CRAFT E11–E20 | Delta aditivo MESTRE-SIDE TEST

**Não é motor R48.** A implementação original R48 foi localizada, mas seus bytes continuam negados para este ambiente. Este pacote contém um **payload candidato** de admissão, um **contrato de experimentos refutáveis** e testes de negativos de evidência que não emitem pedido nem recibo verdadeiro.

**Baseline legado mantido FORA do ZIP sem sobrescrita:** `/Comestre/CRAFT_PINGENTE_PA_R48_LAB_CONTINUIDADE_20261020.zip`, SHA256 `bdf37c22594aa697a7eb182e844b34de6c094ea0039599dcf6c84932f11b14ea`. Foram preservadas três cópias JSON de entrada originais suficientes para replay lógico do delta. Corrigenda PA v1.2 e motores R26/R27 não são duplicados aqui.

## Executar em diretório extraído limpo

```sh
python verify_manifest.py
python run_replay.py
```

O segundo comando gera os JSONs em `outputs/`, confirma os campos de proposta, testa 32 casos de software e preserva **R48=0 recibos novos; magia=0 observações**. Scripts não usam rede, Notion, estoque, motor R48 ou assinaturas criptográficas; somente auditam contratos e recusam reivindicação sem prova.

Arquivos: `code/e11_20_contract.py`, `code/test_e11_20_contract.py`, `ENGENHARIA_E14_E16.md`, `TECNOLOGIA_DE_TRANSFERENCIA_E15_E18.md`, `evidence/R48_RAW_ACCESS_DENIED.json`, `evidence/SOURCE_REOPEN_MATRIX.json`, `PSV_E11_E20_20261020.md`.

**Importante:** a existência de entradas e termos `r46_report`, `r47_attestation` neste pacote NÃO significa que os sistemas originais R46/R47 tenham sido invocados. O gate é consumidor auxiliar fail-closed enquanto o R48 original estiver inacessível.
