# CRAFT E14–E16: estado antes/depois de engenharia e contrato R48

**Identidade preservada:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001`, revisão aditiva de adaptador, **não nova receita**. A v1.3 original não foi alterada.

## Achados verificáveis na interface histórica R48/FC04

1. **Unidade de fibra:** receita v1.3 usa `0,45 m` apenas como parâmetro de LAB. As receitas FC04 legadas codificam a fibra em `cm`. A versão aditiva converte dimensionalmente para **45 cm** exatos no fio de entrada; conserva a unidade original e marca `PROPOSED_NOT_MEASURED`. Não implica que 45 cm de material físico existam.
2. **Identidades materiais:** os três `source_page_id` foram reabertos no Notion Mestre. Cristal e erva têm propriedades mágicas descritas em suas próprias fichas; fibra é material PS de suporte e **não ganha propriedades mágicas**. Cadastro desses dois novos tipos de unidade na R48 original (`cristal`, `erva`) permanece **NÃO VERIFICADO**, pois o engine executável não está acessível.
3. **Processo rastreável:** quatro operações do projeto preservadas como grafo sem duplo consumo documental: fibra→cordão; erva→preparo de folhagem; cordão+folhagem+cristal→conjunto bruto; tentativa de calibração→saída planejada. A última etapa é hipótese de interface, não execução de efeito. Quantidade planejada 1, saída produzida/QA aprovado/perdas reais = **DESCONHECIDOS**.
4. **Ferramentas, especialista e estoque:** o texto possui ferramenta candidata, competência proposta e **nenhum lote recebido**. Falta disponibilidade/suficiência de ferramenta, prova de habilidade, equivalência de amostra, limiares mecânicos e laudos metrológicos R46; não atribuir `inventory=1` por existir página de material.
5. **R46/R47:** o registro FC04 contém laudos com observações **SINTÉTICAS** e certificados públicos **FAKE**. Eles comprovam integridade interna sob regras de fixture, não física/magia. Os campos `magic_detected=false` do estojo mecânico não viram um sensor validado por definir `true` no Pingente. Um gate consumidor de E16 rejeita schema incorreto, lote trocado, fonte sintética, ausência de medidas, verificação original não realizada e ausência de observação mágica. Ele NÃO substitui R46/R47 originais.
6. **Allowlist R48:** são reconhecidas historicamente `SBX-TLI-R44-v1` e `SBX-MICA-R44-v1`. FC04 adicionou estojo em cópia de laboratório; Pingente `SBX-VIGILIA-BOREAL-R48-TEST-v1` é apenas chave candidata. **Nenhuma allowlist real foi alterada nesta execução**.

## Procedimento condicional de primeira execução quando houver bytes autorizados

1. Materializar o ZIP matriz R48 legitimamente; comparar bytes, CRC e os três hashes individuais oficiais antes de importar. Parar se qualquer comparação falhar.
2. Criar extração TEST **nova**, nunca escrever nos quatro stores históricos FC04 nem reutilizar identificadores de pedidos/lotes.
3. Rodar **um canário de receita histórica**, usando `run_fc04.py` em cópia nova e baseline real, sem repetir store/historical batch. Medir HEAD, PRE/DEPOIS, journal, `idempotent_replay` e tipos de QA reais do motor.
4. Verificar aceitação de schema para cristal, erva e fibra (cm) sem fabricar dados de estoque. Admitir chave experimental em extensão de memória por allowlist sob adaptação legítima. **Reconhecimento** é checkpoint isolado, não output.
5. Rodar negativo de Pingente sem lotes/sem evidência: esperar `REJECTED_PRECHECK`/quarentena conforme retorno **real** da fábrica, com zero consumo; salvar recibo nativo, ids novos, PRE/DEPOIS e readback.
6. Só propor montagem estrutural em TEST quando houver lotes explicitamente **SYNTHETIC** e limiares QA mecânicos competentes; a saída será componente inerte/fixturada e **não prova de efeito mágico**.
7. Para alegar transferência, requer-se árbitro/observação competente externa + fonte do procedimento + R46/R47 real e comparação H1–H4; assinatura TEST sozinha não serve.
8. Reavaliar RC e custos PR-ECO; aprovação produtiva separada F5/C19/gates.

**Estado de admissão desta rodada:** `HOLD_BINARY_AND_EVIDENCE`; conversor E14–E16 executado (read-only), **nenhum R48.commit_batch foi invocado**. **E11/E12/E17** aguardam acesso executável; **E15/E18** aguardam efeito observable competente; **E19** mantém `approved_units=null`, perdas/CTE/MED indeterminados.
