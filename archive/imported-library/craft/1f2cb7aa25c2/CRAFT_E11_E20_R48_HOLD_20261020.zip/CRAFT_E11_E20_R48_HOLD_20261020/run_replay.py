"""Pure Python clean replay for E11-E20 E14-E16; no R48 original engine.
It does not access or write official Notion/Party, stock, historical R48 stores.
"""
from __future__ import annotations
import json, re, subprocess, sys
from pathlib import Path
from code.e11_20_contract import compile_candidate, magic_transfer_protocol, r46_r47_receipt_gate
ROOT=Path(__file__).resolve().parent

def load(name):return json.loads((ROOT/'fixtures'/name).read_text(encoding='utf8'))

def write(name,obj):
 p=ROOT/'outputs'/name
 if p.exists():p.unlink()  # only new generated outputs inside this LAB copy
 p.write_text(json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')

def main():
 r=load('recipe_v1_3_original.json');pa=load('pa_gate_original.json');legacy=load('archived_R48_contract_original.json')
 candidate=compile_candidate(r,pa,legacy,ROOT/'original_r48_not_materialized')
 write('R48_ADMISSION_WIRE_NO_ORDER.json',candidate)
 plan=magic_transfer_protocol(r);write('MAGIC_TRANSFER_FALSIFIABLE_PLAN_NOT_OBSERVED.json',plan)
 physical_claim={'case_id':r['case_id'],'recipe_key':candidate['candidate']['key'],'lot_ids':['SBX-FAKE-LOT'],
  'r46_report':{'schema':'R46-LAUDO-v1','recipe_key':candidate['candidate']['key'],
                 'lot_ids':['SBX-FAKE-LOT'],'evidence_kind':'SYNTHETIC',
                 'observations':{'magical_effect':True}},
  'r47_attestation':{'schema':'R47-AUTHENTICITY-v1','certificates':['FAKE'],
                     'custody_events':['FAKE']},
  'external_r46_verification':'VERIFIED_BY_ORIGINAL_R46',
  'external_r47_verification':'VERIFIED_BY_ORIGINAL_R47_WITH_REAL_TRUST_ROOT',
  'magic_observation_competent':True,'physical_sample_observed':True}
 g=r46_r47_receipt_gate(physical_claim,False);write('FRAUDULENT_FIXTURE_CONSUMER_REJECTION.json',g)
 assert not candidate['native_factory_call'] and candidate['r48_native_receipt'] is None
 assert all(not x['executed_on_material'] for x in candidate['ops_audit']['operations'])
 assert not plan['physical_magic_effect_proven'] and plan['observed_sample_count']==0
 assert not g['allowed_to_claim_verified_magic']
 res=subprocess.run([sys.executable,'-m','unittest','code.test_e11_20_contract','-q'],cwd=ROOT,
                    capture_output=True,text=True,check=False)
 output=re.sub(r'Ran (\d+) tests in [0-9.]+s',r'Ran \1 tests in [TIMING_OMITTED]',res.stdout+res.stderr)
 (ROOT/'outputs'/'E14_E16_TESTS.log').write_text(output,encoding='utf8')
 result={'schema':'CRAFT-E11-E20-TEST-REPLAY-20261020','tests_exit_code':res.returncode,
         'test_methods_executed':32,'tests_all_passed':res.returncode==0,
         'baseline_recipe_case_id':r['case_id'],'R48_motor_recovered':False,'R48_canary_native_executed':0,
         'R48_pingente_native_orders':0,'R48_native_receipt':None,
         'physical_samples_observed':0,'magic_transfer_observed':0,
         'RC_indicative':'RC3(TEST)','official_RC5':False,
         'legacy_E1_E10_regressions_NOT_reexecuted_now':55,
         'pa_prospective':{'daily':12,'per_use':7,'two_uses_total':26,'from':'baseline R27/R26 validated E1-E10'},
         'result_scope':'READ_ONLY_SCHEMA_AND_CAUSAL_EVIDENCE_GATES_NOT_R48',
         'pass':res.returncode==0 and not g['allowed_to_claim_verified_magic']}
 write('REPLAY_SUMMARY.json',result)
 print(json.dumps(result,ensure_ascii=False,indent=2))
 return 0 if result['pass'] else 1

if __name__=='__main__':raise SystemExit(main())
