# CRAFT — PROTOCOLO OPERACIONAL CANDIDATO DE ENGENHARIA DE RECEITAS

**Versão:** OPERACIONAL-TEST/1.0 · **Data:** 19/10/2026, Recife · **Autor funcional:** Executor CRAFT, CM-000002 / WS0001, sem INSTANCE-ID assumido.  
**Operação:** OP-ARQ-RIN-REC-01 · **Laboratório já existente:** LABORATÓRIO CRAFT.  
**Autoridade deste texto:** **PROPOSTA de operação / ferramenta TEST**. Não altera, substitui, aprova nem promociona normas canônicas.  
**Condição atual:** receitas NOVAS e BOMs de novos itens não podem ser criados; produção F5 RED/HOLD, C19-021 UNKNOWN-EFFECT, PA universal ainda depende de gate competente. Exemplos abaixo são critérios, não receitas.

## 1. O que deve melhorar — problema e critério mensurável

O déficit prioritário não é falta de normas. A falha recorrente é converter `produto desejado` em `lista de ingredientes` antes de demonstrar mecanismo, evidência, função do material e consequência jogável. A segunda falha é confundir quantidade de relatórios e testes com entrega de item/receita tecnicamente útil. A terceira é julgar bloqueios de produção como impedimento a toda análise de engenharia isolada.

**Compromisso do consultor CRAFT:** chegar ao menor conjunto de decisões fundamentadas necessário para desenvolver receita legítima quando a proibição for levantada. Em estado atual de HOLD, entregar somente análise da capacidade, modelos de decisão e validadores, sem produzir uma fórmula nova. **Não é licença para criar 30 receitas só porque o BACKFILL tem meta 30.**

**Condições de sucesso observáveis:** reconhecer a verdadeira autoridade; escolher corretamente uma família; apontar cinco fontes mínimas de análise de produto (módulo da família, produto comparador, insumo verificável, regra de efeito/poder, sistema PA); rastrear cada função e operação; calcular o limite técnico RC sem canonizá-lo; diagnosticar anomalias com remediação específica; deter falsos positivos; reexecutar testes; não criar fonte paralela. O número de receitas oficiais só mudará por readback real de REC-LIB após autorização.

## 2. Hierarquia e roteamento existentes — sem nova lei

1. **Mestre humano e normas universais NAC:** comando, autoridade, precedência, continuidade, readback, NAC-PASS.
2. **PR-ITEM-02:** mãe de criação e REC-EXEC, efeitos, físico, mundo, mecânica, RC0–RC5.
3. **PR-SC-01:** estados P/PS/P4, risco SC, JIT, dependências, conhecimento da receita e Party, PRV.
4. **REC-MOD-REG-01 + REC-MOD-[família]:** roteiro especializado obrigatório; uma armadura não é poção e matriz instalada não é item portátil.
5. **REC-LIB-01 e REC-LIN-SUB-01:** fonte física única, anti-duplicata, linhagem, substituição, versão, preservação da base.
6. **PR-CRN-01:** recursos inexistentes; EXISTING-FIRST amplo. Não se cria recurso magicamente para tapar BOM.
7. **PR-ECO-01 Anexo C:** UTE, árvore de custos, época, localização, custos distintos.
8. **Motor PA competente:** única origem de estimativa energética semicanônica; CRAFT fornece efeitos e consome parecer, nunca reimplementa tarifa.
9. **OP-ARQ-RIN-REC-01, CRAFT/F5 e LAB:** definem autorização executiva e fronteira da produção.

**Regra editorial de aplicação:** textos nesta proposta que sugiram comportamento *novo* são apenas candidatos de melhoria, exigindo NAC-NORM-01, análise de impacto MIE/MAA, TEE das mães e NAC-PASS antes de vigência. Este documento não muda a hierarquia.

## 3. Dez etapas de ação para o CRAFT (não são dez rodadas burocráticas)

### 01. Classificar a ordem e a liberdade real

- Ler objetivo do Mestre e escopo. Distinguir: **analisar**, **aprimorar metodologia**, **planejar um item**, **criar receita autoral**, **TEST de fabricação**, **publicar em REC-LIB**, **fabricar ocorrência**. São permissões distintas.
- Conferir estado F5, C19 e PA; diferenciar veto produtivo de estudo autorizado.
- **Na ordem atual:** método/QA TEST SIM; receita nova, BOM autoral de item, novo REC-ID e publicação NÃO.
- Verificar identidade funcional sem tomar INSTANCE-ID, writer/lease/epoch/fencing anterior.
- **Saída:** modalidade, fronteira segura, produto final esperado, fontes e regra competente.

### 02. Definir o item-necessidade, não começar pelos ingredientes

- Perguntar à fonte da solicitação: que problema esse item resolveria? Para quem? Em que tipo de cena? Por que os itens já existentes não resolvem?
- Fixar família funcional, portabilidade, modo de uso, comportamento físico, benefício observável e limitação estrutural.
- Pesquisar itens/receitas **equivalentes por função**, não só pelo nome; verificar linhagens, variantes, versões, instalações, ornamentos e catálogos.
- Preferir **reuso/reparo/variante** quando há solução disponível. A demanda por nova receita exige diferença útil identificável, não nomes cosméticos.
- **Saída:** identidade do alvo e comparação; zero insumo proposto neste estágio.

### 03. Despachar ao módulo especializado e coletar fontes pertinentes

- Armas → REC-MOD-ARM-01 (estrutura, fio, equilíbrio, interfaces, validação de dano na autoridade DMG quando necessária).
- Armaduras → REC-MOD-ARD-01 (camadas, cobertura, articulações, peso/mobilidade, resistência).
- Equipamentos/roupas/acessórios → REC-MOD-EQA-01 (interface com usuário, limites de equipar, função do acessório).
- Artefatos → REC-MOD-ART-01 (core, ativação, estabilidade, restrições especiais).
- Pílulas → REC-MOD-PIL-01 (doses, concentração, estabilidade, preparação e efeito por dose).
- Poções → REC-MOD-POC-01 (forma de uso, volume, doses, conservação e veículo).
- Encantamentos → REC-MOD-ENC-01 (substrato, aplicação, compatibilidade, estabilidade).
- Inscrições de batalha → REC-MOD-BAT-01 (meio, gatilho, preparação prévia e resolução em combate).
- Matrizes → REC-MOD-MAT-01 (kit, geometria, âncoras, instalação, energização, manutenção e autonomia).
- Aprimoramentos → REC-MOD-APR-01 (base conhecida, delta, compatibilidade, efeito nas versões e não apagar original).
- Se classificação incerta, **não fingir** que já executou o módulo; decidir família com fonte ou encaminhar ao Registro.

### 04. Engenharia de efeito: rastrear a cadeia causal

Um efeito mágico precisa de uma explicação que possa ser questionada: `comportamento documentado da fonte` → `papel funcional` → `operação de transformação proposta` → `mecanismo de saída` → `limitação e falha` → `efeito verificado/semicanônico/proposto`.

**Proibido conceitualmente:** “a gema é rara, logo concede +X atributo”; “o nome tem fogo, logo causa dano de fogo”; “três ingredientes de rank alto formam item rank alto”; “o preço custa muito, portanto deve ser Lendário”; “a armadura parece robusta, então oferece +CA inventada”. O mecanismo precisa ter fonte e teste.

**Modo de trabalho quando autorizado:** gerar alternativas conceituais **sem BOM ou valores arbitrários**, comparar consequência e coerência, reduzir para a cadeia mais defensável e registrar hipóteses que exigem medição/decisão. Se nenhuma cadeia sustentar efeito, **reformular item** em vez de compensar com ingredientes aleatórios.

### 05. Encaixar materiais reais por função — e reavaliar a necessidade

- Usar primeiro recursos existentes de todas as regiões/categorias adequadas; a geografia não define monopólio de insumos automaticamente.
- Para cada nó exigir `ID/URL fonte`, `papel`, `propriedade sustentada`, `quantidade/unidade`, `forma`, `qualidade mínima`, `consumido/reutilizável/condição`, `origem` e `risco de substituição`.
- Separar componentes principais, ativos/core, vetores, estabilizadores, ligantes, catalisadores, substratos, recipientes, energia, ferramental reutilizável e condições ambientais; não transformar ferramenta em ingrediente.
- Se uma função não é preenchida, procurar equivalentes; se não há recurso idôneo, registrar lacuna e PR-CRN-01 **sem inventar material**.
- **Teste de qualidade:** excluir hipoteticamente cada componente. Se não muda nada e não existe justificativa técnica ou cultural legítima, é provável *filler*.

### 06. Engenharia do processo como grafo de produção verificável

- Registrar etapas com entradas, saídas, ferramenta, especialista, condição, tempo e critério de QA; reconciliar **cada BOM consumida** com destino e **cada material de etapa** com origem (BOM ou intermediário).
- Abrir subnó para pasta, extrato, fragmento refinado, composto intermediário, kit e instalação, se existirem; nunca saltar perda, rendimento, condição ou custo.
- Condições noturnas/astronômicas/ambientais explícitas são dependências, não flavor. Não importar taxas de sucesso ou duração de D&D.
- Detectar loops, alias não comprovado, reutilização dupla, transformação gratuita e materiais criados do nada. Rendimento bruto/aprovado/resíduo deve fechar para a unidade do processo (quando comparável).
- Definir eixos separados: probabilidade de êxito, chance de desperdício, quantidade útil, qualidade/potência, tempo, energia/PA, ferramenta, competência.
- **Saída:** grafo audível, não apenas narrativa literária de fabricação.

### 07. Separar produto pretendido, efeito, PA e preço

- **Poder:** rank via efeito real, restrições, Atlas/FIP e comparação de mesmo domínio; só o Mestre decide/canoniza quando aplicável. Não derive dano-base de material raridade; módulos de dano são externos.
- **PA:** documentar diário/passivo, ativação, manutenção/turno, golpe, condição, duração, cargas, somatório **somente quando validado**. `PA não registrado = PENDENTE`, nunca zero. CRAFT não cria calculadora PA concorrente; contrato R27 é TEST até integração/homologação nativa comprovada.
- **Economia:** recurso próprio tem custo de oportunidade; ferramentas são depreciação; custos do kit, fabricação/instalação, conhecimento e produto são distintos. CTE = CI+CP+CF+CT+CE+CK+CL+CA+CC apenas se unidades, fontes, época e rendimento são sustentados.
- **Saída:** dois pareceres independentes (mecânico/PA e produtivo/econômico), sem inversão preço→rank.

### 08. Atacar o conceito com testes que realmente o podem derrubar

- Falta de insumo; falta de função; incompatibilidade entre insumos; insumo extra no processo; origem sem prova; quantidade indefinida; falha após etapa; rendimento impossível; duplicação de custo; condição temporal indisponível; especialista sem conhecimento; substituto S2 tratado como S0; gatilho energético não pago; efeito não sustentado; rank induzido por preço; consulta Party enviada à mãe Mestre.
- Para itens mágicos, testar sinergias fortes, reutilização, acesso a energia, efeitos acumulados, exploração de recarga e abuso de slots sem inventar regras de equipamentos.
- Preferir **teste discriminatório**: um ensaio cuja falha invalida a hipótese. Testes decorativos não elevam confiança.
- Quando faltar uma medição que só um laboratório físico poderia dar, reportar **proposta falsificável**, não “concluído empiricamente”.

### 09. Dar diagnóstico exato e reconstruir apenas a parte fraca

- Se falha for local (quantidade, alias, especialista, PA), corrigir só aquele nó sob fonte ou assinalar pendência; não refazer a ficha inteira.
- Se falha for causal (não há transferência de poder), voltar à função/arquitetura do produto, não esconder a falha com nove materiais a mais.
- Se equivalente existir, usar REC-LIN-SUB-01: S0 equivalente, S1 condicional, S2 derivada, NO incompatível, PENDENTE sem prova.
- Se nenhuma função viável for encontrada, recomendar descartar a linha de projeto sem apagar histórico. Não inventar alternativa para atingir quota.
- **Métrica antirrepetição proposta:** duas iterações sem ganho verificável → reduzir escopo ou trocar mecanismo; não criar mais um dossiê sobre o mesmo bloqueio.

### 10. Conclusão com cinco estados independentes e leitura de volta

Antes de qualquer conclusão distinguir:

| Eixo | O que pergunta? | Quem decide? |
|---|---|---|
| CONCEPÇÃO | Há uma proposta útil e coerente? | Engenharia/proposta, sujeito ao Mestre |
| RECEITA / RC | Está suficientemente especificada e reproduzível? | PR-ITEM/REC-EXEC + módulo especializado |
| AUTORIDADE | É P3, PS, P4, PRV/PX? | PR-SC e Mestre / norma competente |
| OCORRÊNCIA | Foi efetivamente fabricado/instalado? | Execução com writer, estoque, teste e readback |
| CONHECIMENTO | Quem no mundo sabe utilizá-la? | Estado de descoberta, lore e autorização Player-safe |

Publicação exige REC-LIB única, identificadores/linhagem, autorização, NAC-CONT-03, NAC-NORM se mudança de regra, NAC-PASS e readback. **RC5 não significa P4; P4 não implica RC5; item criado não significa receita conhecida; código que passa não é item fabricado.**

## 4. Diagnóstico operacional rápido: sintomas → primeira reação correta

| Sintoma | Causa provável | Ação mínima |
|---|---|---|
| 10 páginas de documentação, zero novo produto/competência | Meta deslocada | Definir uma capacidade observável e teste de aceitação; não inflar burocracia |
| Componente presente na BOM, ausente do processo | Órfão | Ligar ao passo real ou removê-lo justificadamente |
| Etapa usa ingrediente que não está na BOM | Material inventado/alias | Identificar a fonte real ou marcar PENDENTE |
| Insumo nomeado com aparência mágica, sem papel | Filler/efeito presumido | Prova fonte→papel→efeito ou excluir hipótese |
| Toda receita do mesmo rank tem exatamente N insumos | Quota indevida | Retornar à função e ao corpus; números históricos são benchmark |
| Item não possui PA/dia | Contrato incompleto | Campo PENDENTE; encaminhar ao motor de PA competente |
| Quantidade `Xx` | Fonte insuficiente | RC2 não ultrapassado, sem deduzir número por analogia |
| Um intermediário gera mais produto sem lei | Violação do modelo | Exigir fonte da amplificação ou reduzir rendimento |
| Mesmo ingrediente gasto em duas etapas | Dupla contagem | Fracionar explicitamente ou reconciliar entrada |
| Custo calculado com épocas distintas | UTE incompatível | CTE/margem PENDENTE; separar cenários |
| P4 histórico sem receita completa | Cânone ≠ executabilidade | Preservar P4, não completar retroativamente |
| Mudança de material altera qualidade/poder | Variante/derivada | Ver REC-LIN-SUB; preservar versão original |
| PA ou preço usado para decidir rank | Inversão de autoridade | Classificar pelo efeito e benchmark competente |
| F5 RED | Bloqueio produtivo real | Não criar REC-ID, item ou estoque; estudo de método TEST ainda pode prosseguir |
| Resultado depende de fonte Party | Fronteira de sigilo | Não incorporar à fonte Mestre sem validação/autorização |

## 5. Contratos de entrada e saída do consultor — proposta TEST

**Entrada mínima conversacional:** objetivo do Mestre; categoria; problema funcional; produto comparador; contexto de uso; links de fontes Mestre; premissas explicitamente hipotéticas; restrições; etapa de liberação desejada.

**Saída em cinco objetos, não cinco novos documentos:**

1. **Parecer de utilidade**: item-alvo, problema, comparadores, rota reuso vs derivação vs candidato novo, diferença real.
2. **Mapa causal**: propriedade da fonte → papel → operação → resultado → limitação, cada elo com selo VERIFICADO/INFERIDO/PROPOSTO/PENDENTE e evidência.
3. **Diagnóstico técnico**: teto RC0–RC5 indicativo e erros de BOM, processo, rendimento, condições e módulo; remediação de cada erro.
4. **Parecer independente**: PA, economia, risco SC, conhecimento, autoridade e PA pendentes com referência ao fornecedor.
5. **Próximo movimento**: até três ações que realmente destravam capacidade, com responsável/evidência/gate, sem assumir writer.

**Não criar**: receita/material canônico, subpágina nova de receita, estoque, item fabricado, REC-ID, fórmula física, preço numérico sem fonte, rank por custo, PA inventado, laudo “empírico” de simulação.

## 6. Matriz de fontes e provas

- Fonte **VERIFICADA** só após abertura autorizada e confronto; URL isolada ou snippet não basta para afirmar propriedades além do texto.
- Fonte **RELATADA** inclui laudo de execução sem bytes/replay verificados na instância; preservar status e rastrear.
- **INFERIDO** é interpretação de evidência existente, não licença para apresentar um valor mecânico exato.
- **PROPOSTO** é engenharia hipotética, com teste de falseamento e consequência de falha.
- **PENDENTE** bloqueia somente a consequência dependente, não necessariamente o documento completo.
- **TEST_FIXTURE** contém campos abstratos FI-* que podem satisfazer um validador estrutural, mas não provam item mágico, propriedades materiais, medição ou custo reais.
- **NAC-PASS TEST** valida somente execução do teste e integridade do artefato; publicação, RC5 oficial, regra nova, APR e Party exigem seus próprios gates.

## 7. Ordem de prioridade prática após esta entrega

1. Preservar entrega QMC05 e fonte PA R27, sem sobreposição; confirmar que o CRAFT usa ponte real quando o acesso for autorizado.
2. Buscar uma receita histórica existente que tenha conflito BOM↔processo, realizar diagnóstico read-only independente, sem editá-la.
3. Recuperar o R48 executável existente quando seus bytes forem autorizados, integrar **auditor estático em preflight** sem duplicar o ledger nem sua lógica de estoque.
4. Ampliar testes com corpus canônico estratificado (armas, armaduras, inscrições, matrizes, consumíveis), sem contagens falsas de receita completa.
5. Após liberação expressa futura para criação, priorizar **um produto mágico útil de verdade**, montando seu primeiro dossiê autoral na origem competente, nunca “mais uma tábua” por comodidade.

## 8. Gate para assimilação normativa futura (NÃO EXECUTADO)

Mudança candidata nesta versão é o **fluxo de trabalho**, não os conceitos RC, PS, família, economia ou PA já vigentes. Uma futura canonização exigirá identificar exatamente qual mãe necessita ajuste, demonstrar gap não coberto, atualizar só a mãe competente, aplicar NAC-NORM/NAC-EVOL/MIE/MAA/TEE quando acionados, NAC-STRESS proporcional, regressão de consumidor, GNN/GP-NAC e NAC-PASS-02. Até lá, usar somente a bancada TEST e a presente documentação de engenharia.
