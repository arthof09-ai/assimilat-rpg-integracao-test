# CRAFT — Melhoria de criação de receitas / QA TEST

**Situação:** entrega experimental de capacidade do Executor CRAFT em engenharia de receitas. **Sem nova receita, sem novo BOM de item, sem REC-ID, sem produto fabricado, sem escrita de produção.** F5 RED, C19-021 UNKNOWN-EFFECT. Este pacote não substitui QMC-05 nem o motor R48 nem o motor PA R26/R27.

## Para o Mestre no celular

Nenhuma ação técnica é exigida. O Comestre pode consultar o protocolo e os fluxogramas, ler as fichas no Notion Mestre, aplicar o auditor de prontidão e produzir um parecer conversacional. O Mestre decide criá-las quando for permitido; este pacote **não inicia criação de receitas agora**.

## Arquivos principais

- `FLUXOGRAMAS-OPERACIONAIS.md`: seis rotas Mermaid, de pedido até gates finais.
- `PROTOCOLO-OPERACIONAL-CANDIDATO.md`: procedimento de dez etapas, decisões, critérios e erros comuns. Proposta operacional, não nova lei.
- `FONTES-E-MODULOS.md`: mães vigentes e dez módulos especializados em seus endereços do Notion.
- `recipe_qa.py`: linter/auditor JSON estático **somente READ-ONLY ou FI-* TEST**, sem internet/Notion/produção.
- `test_recipe_qa.py`: testes de casos positivos, negativos e robustez (inclusive mutações determinísticas).
- `fixture_abstrata.json`: forma de entrada FI-*, **NÃO** fórmula real de item ou consumível.
- `holdout_readonly_abridged.json`: duas representações parciais de fontes Mestre, declaradas **transferência manual abreviada**, não autenticação binária.
- `holdout_receipts.json`: diagnóstico dos dois read-only parciais; RC1/RC0 são tetos de informação informada, não RC oficial dos itens.
- `HOLDOUT-CANONICO-READONLY.md`: três páginas reais reabertas e auditadas **manualmente**; terceira não entrou no linter.
- `QA-RESULTADOS.json`, `PSV-CHECKPOINT.md`: contadores e limites.
- `replay.py`: verificações repetíveis em ambiente limpo.

## Execução técnica opcional pelo Comestre, nunca exigida do Mestre

```bash
python replay.py
python recipe_qa.py fixture_abstrata.json
python replay.py  # também valida os dois holdouts resumidos
```

A segunda linha NÃO publica nada; `production` é sempre `DENY` e `official_recipe_created` é `false`. O campo `rc_ceiling_test` é apenas diagnóstico estrutural de teto: não prova fonte, magia, rendimento observado, PA correto, receita canônica, RC5 oficial ou autorização de fabricar.

## Limites de confiança

- `FIXTURE_TEST`: objetos abstratos FI-*, com dados sintéticos e referências abstratas, servem só para teste de lógica.
- `SOURCE_READONLY`: dados reais **declarados/transcritos** exigem URL e AS-OF; a integridade da transcrição depende de inspeção externa ao validador.
- `SC-3/4`: um campo de referência no input não substitui decisão física do Mestre nem validade da autoridade; apenas permite detectar ausência sintática.
- Testes unitários não substituem laboratório de fabricação, medições de materiais, ou análise empírica de uso em jogo.
- O modelo de subtarefas QA não é uma nova versão normativa de REC-EXEC; só indica bloqueios de completude.

## Critério de retomada

**FIRST-PENDING:** revalidar integração contratada do fornecedor PA no entrypoint CRAFT e usar auditor como *preflight* do motor R48 autêntico quando os bytes necessários estiverem acessíveis. Depois, confrontar auditor read-only com corpus maior de itens mágicos/receitas, medir falsos positivos e corrigir parser antes de recomendar promoção normativa. Enquanto o Mestre não retirar a proibição, não criar receita mesmo experimental.
