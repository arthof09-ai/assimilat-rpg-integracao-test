# ROTEAMENTO DE FONTES — SEM NORMA DUPLICADA

**Estas páginas do Notion são as autoridades vivas.** Este arquivo não as substitui e não atesta atualização além dos readbacks feitos nesta execução.

| Papel | Fonte competente existente | Aplicação |
|---|---|---|
| Operação e HOLD | [OP-ARQ-RIN-REC-01](https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516) | Estado da missão, PRE/POST, limitação de produção |
| Criação geral | [PR-ITEM-02](https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4) | Ficha, ordem de criação, REC-EXEC RC0–RC5 |
| Autoridade semicanônica | [PR-SC-01](https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1) | PS, P3/P4, SC, JIT, PRV, dependências |
| Matriz dos módulos | [REC-MOD-REG-01](https://app.notion.com/p/3f1c2b324ede81868e28ce11a06b1253) | Roteamento por tipo de produto |
| Fonte única | [REC-LIB-01](https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702) | Identidade, anti-duplicação e local físico da receita |
| Linhagem e variante | [REC-LIN-SUB-01](https://app.notion.com/p/3f1c2b324ede818a9e84cfeae2aa0b9b) | S0/S1/S2/NO, preservação de base |
| Recurso novo | [PR-CRN-01](https://app.notion.com/p/3eec2b324ede819fbe0ed4af1a4cb3aa) | GAP, fonte alternativa, proibição de inventar matéria |
| Economia | [PR-ECO-01 Anexo C](https://app.notion.com/p/3eec2b324ede8102b3f3e6c8851ad1e7) | UTE/CTE, mercado, época, rendimento |
| Stress de receitas | [AUD-REC-HARD-100-01](https://app.notion.com/p/3f1c2b324ede81e8ad7bdc600aac34a5) | Referência empírica S4 100/100 existente (não recontada) |
| Laboratório existente | [LABORATÓRIO CRAFT](https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00) | Engenharia READ-ONLY, TEST isolado e checkpoints |
| Ciência de receitas | [OP-NORM-REC-EMP-01](https://app.notion.com/p/3f1c2b324ede814ea62dc72438a6f3a5) | Corpus e integração normativa já homologada |
| Ponte PA R27 | [LAB CRAFT — PA-R27-CRAFT-INTEROP](https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00) | Contrato de fornecedor TEST; NÃO motor paralelo |
| Estado histórico R48 | [CRAFT R48](https://app.notion.com/p/3f4c2b324ede81f8add3f0bb1e77f4f1) | Motor multiordem e ledger TEST já desenvolvido; **não reconstruído aqui** |

## Dez módulos especializados, sempre chamados quando aplicáveis

| Família | Fonte | O que o CRAFT precisa testar |
|---|---|---|
| Arma | [REC-MOD-ARM-01](https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649) | Forma, integridade, equilíbrio, interfaces, desempenho e fonte de dano |
| Armadura | [REC-MOD-ARD-01](https://app.notion.com/p/3f1c2b324ede8116bd3cc6606a1c6687) | Cobertura, camadas, mobilidade, ajuste, ensaio defensivo |
| Equipamento/roupa/acessório | [REC-MOD-EQA-01](https://app.notion.com/p/3f1c2b324ede818ab3c0d913574eed28) | Interface, usos, limites e funções reais |
| Artefato | [REC-MOD-ART-01](https://app.notion.com/p/3f1c2b324ede81b48b33d0877ee107d3) | Core, energia, estabilidade, custo/limite de ativação |
| Pílulas e Alquimia | [REC-MOD-PIL-01](https://app.notion.com/p/3f1c2b324ede81699599c15a08585fc4) | Dose, concentração, qualidade e estabilidade |
| Poções | [REC-MOD-POC-01](https://app.notion.com/p/3f1c2b324ede810f91edd002c4bfb855) | Via de uso, dose/volume, conservação, veículo |
| Inscrição Encantamento | [REC-MOD-ENC-01](https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6) | Preparação, substrato, aplicação e compatibilidade |
| Inscrição Batalha | [REC-MOD-BAT-01](https://app.notion.com/p/3f1c2b324ede81c1bda7d07e0b5456e9) | Suporte, gatilho, manutenção, preparação/uso distintos |
| Matriz | [REC-MOD-MAT-01](https://app.notion.com/p/3f1c2b324ede819ca142cbf1eb992fac) | Kit/instalação, âncoras, geometria, energia, calibração |
| Aprimoramento | [REC-MOD-APR-01](https://app.notion.com/p/3f1c2b324ede81958b48da97806423f3) | Item-base, delta, compatibilidade, revalidação |

**Nota:** o validador desta entrega verifica presença de evidências dos requisitos mapeados; ele NÃO executa empiricamente o processo especializado nem certifica que a evidência informada seja verdadeira. Para cada operação real, a norma completa deve ser lida novamente.

## Exigências do NAC

- Identidade ≠ instância ≠ writer.
- Operação existente (não nova OP): LER → REGISTRAR ANTES → autoridade → TEST → reabrir → DEPOIS → NAC-PASS proporcional.
- Proposta operacional no LAB não é promoção normativa. Mudança de regra/mãe demanda NAC-NORM-01 e testes específicos de enraizamento/entrada.
- Versão Party-safe não é extraída automaticamente da Mestre.
