#!/usr/bin/env python3
"""Autoverificação de integridade local, sem conexão com Notion ou autorizações."""
import hashlib,json,sys
from pathlib import Path
p=Path(__file__).resolve().parent
manifest=json.loads((p/'manifest.json').read_text(encoding='utf8'))
checks=[]
for rel,sha in sorted(manifest['files'].items()):
    target=p/rel
    exists=target.is_file()
    got=hashlib.sha256(target.read_bytes()).hexdigest() if exists else 'MISSING'
    checks.append((rel,sha==got))
print(json.dumps({'files_checked':len(checks),'passed':sum(ok for _,ok in checks),
                  'mismatches':[k for k,ok in checks if not ok],
                  'package_type':'CRAFT-RECIPE-QA-TEST; no authority promotion'},
                 ensure_ascii=False,indent=2))
sys.exit(0 if all(ok for _,ok in checks) else 1)
