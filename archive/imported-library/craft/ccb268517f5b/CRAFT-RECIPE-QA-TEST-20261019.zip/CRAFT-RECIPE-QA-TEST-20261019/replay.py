#!/usr/bin/env python3
"""Replay TEST sem rede, Notion, escrita canônica ou motor de produção.
Apenas consulta dados FI-/read-only locais e reexecuta 26 métodos unittest.
"""
import json
import sys
import unittest
from pathlib import Path
from recipe_qa import audit
import test_recipe_qa

class CountingResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.subtest_cases=0
        self.subtest_failures=0
    def addSubTest(self,test,subtest,err):
        self.subtest_cases+=1
        if err:self.subtest_failures+=1
        super().addSubTest(test,subtest,err)

class CountingRunner(unittest.TextTestRunner):
    resultclass=CountingResult


def execute(write_receipt=True):
    root=Path(__file__).resolve().parent
    tests=unittest.defaultTestLoader.loadTestsFromModule(test_recipe_qa)
    result=CountingRunner(stream=sys.stderr,verbosity=1).run(tests)
    f=json.loads((root/'fixture_abstrata.json').read_text(encoding='utf-8'))
    frec=audit(f)
    sources=json.loads((root/'holdout_readonly_abridged.json').read_text(encoding='utf-8'))
    holdout_receipts=[audit(x) for x in sources]
    expected=json.loads((root/'holdout_receipts.json').read_text(encoding='utf-8'))
    holdout_identical=(holdout_receipts==expected)
    guards=(frec['rc_ceiling_test']=='RC5' and frec['production']=='DENY'
            and len(holdout_receipts)==2 and [r['rc_ceiling_test'] for r in holdout_receipts]==['RC1','RC0']
            and all(r['production']=='DENY' for r in holdout_receipts))
    receipt={
      'engine':'CRAFT-RECIPE-QA-TEST/1.0.0',
      'kind':'LOCAL_TEST_NOT_CANONICAL',
      'unittest_methods_run':result.testsRun,
      'unittest_failures':len(result.failures),
      'unittest_errors':len(result.errors),
      'unittest_subtest_cases':result.subtest_cases,
      'unittest_subtest_failures':result.subtest_failures,
      'adversarial_inputs_inside_test':300,
      'family_dispatch_inside_test':10,
      'manual_notion_sources_reopened':3,
      'readonly_auto_transcriptions_checked':len(holdout_receipts),
      'readonly_receipts_reproduced':holdout_identical,
      'fixture_expected_readiness':frec['rc_ceiling_test'],
      'holdout_rc_caps':[r['rc_ceiling_test'] for r in holdout_receipts],
      'local_quality_pass':result.wasSuccessful() and guards and holdout_identical,
      'production':'HOLD',
      'official_recipe_created':0,
      'new_bom_of_item':0,
      'new_rec_id':0,
      'notion_modified_by_replay':False,
      'causal_recipe_quality_validated':False,
      'reason':'Fixtures provam a lógica sintática. Qualidade real requer fontes/ensaio/julgamento competentes.'
    }
    if write_receipt:
        (root/'QA-RESULTADOS.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
    print(json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True))
    return receipt

if __name__=='__main__':
    r=execute()
    sys.exit(0 if r['local_quality_pass'] else 1)
