# FLUXOGRAMAS OPERACIONAIS — CRAFT / MELHORIA DE CRIAÇÃO DE RECEITAS

> **Classe:** proposta de fluxo operacional + ferramenta experimental (não nova regra, não produção). **Mães vigentes:** PR-ITEM-02/REC-EXEC, PR-SC-01, REC-MOD-REG-01, PR-ECO-01 Anexo C, PR-CRN-01, REC-LIB-01, REC-LIN-SUB-01, NAC-CONT-03. **Produção:** HOLD. **Receitas novas:** proibidas até liberação competente.

## FLUXO F1 — Produto primeiro, pesquisa depois (roteiro mestre)

```mermaid
flowchart TD
    A[Pedido ou lacuna real] --> B{Escopo permite criar receita?}
    B -- Não --> C[Somente aperfeiçoar método e QA TEST]
    B -- Sim, após futura autorização --> D[Definir produto e problema que resolve]
    D --> E[Comparar produtos e receitas existentes]
    E --> F{Equivalente já existe?}
    F -- Sim --> G[Reusar, reparar ou estudar linhagem]
    F -- Não --> H[Escolher família e módulo REC-MOD]
    H --> I[Fixar efeito, usuário, limites e benchmark]
    I --> J[Buscar recursos existentes por função]
    J --> K{Mecanismo fonte→processo→efeito plausível?}
    K -- Não --> L[Reformulação ou rejeição do conceito]
    L --> I
    K -- Sim --> M[BOM causal e papéis de cada insumo]
    M --> N[Processo e grafo de intermediários]
    N --> O[QA, rendimento, falhas, especialista e condições]
    O --> P[PA competente e economia UTE/CTE]
    P --> Q[Red team, substituições e compatibilidade]
    Q --> R{REC-EXEC e módulo aprovados?}
    R -- Não --> S[Diagnóstico do bloqueio mínimo]
    S --> M
    R -- Sim --> T[RC5 técnico candidato, não produção]
    T --> U{PS/JIT, NAC, writer e liberação válidos?}
    U -- Não --> V[HOLD de publicação e fabricação]
    U -- Sim --> W[Registro único REC-LIB e readback]
    W --> X[NAC-PASS e disponibilidade conforme conhecimento]
```

**Como agir:** se o item-alvo ou sua utilidade não estiverem claros, resolver isso antes de fazer uma lista de ingredientes. Se houver equivalente, preferir reuso/derivação. `B` neste período leva obrigatoriamente ao ramo `C`.

## FLUXO F2 — Engenharia causal de uma habilidade mágica

```mermaid
flowchart TD
    A[Benefício desejado para o usuário] --> B[Examinar efeito já canônico e família]
    B --> C[Pesquisar fonte que realmente possua propriedade pertinente]
    C --> D{Há evidência do atributo ou afinidade?}
    D -- Não --> E[Rejeitar atribuição gratuita]
    E --> C
    D -- Sim --> F[Declarar papel: core, vetor, substrato, estabilizador etc.]
    F --> G[Desenhar transformação: extração, transferência, fixação ou redireção]
    G --> H{Operação suporta saída proposta sem salto causal?}
    H -- Não --> I[Reduzir poder ou revisar mecanismo]
    I --> G
    H -- Sim --> J[Descrever efeito mecânico, alcance, duração e restrições]
    J --> K[Comparar com Atlas/RIn/FIP e módulo de família]
    K --> L[Consultar PA: diário, uso, manutenção e contexto]
    L --> M{Custo e limitações sustentados?}
    M -- Não --> N[PA PENDENTE, não zero; gate energético HOLD]
    M -- Sim --> O[Testes de abuso, sobreposição e contramedida]
    O --> P[Habilitar somente avaliação TEST]
```

**Como agir:** o desejo de um efeito não prova que um recurso o concede. A origem do poder, a transformação e os limites precisam formar uma cadeia. Não inferir potência apenas do rank do insumo. Quando o produto for mágico, considerar as modalidades de PA mesmo que o resultado permaneça PENDENTE.

## FLUXO F3 — BOM ↔ operações ↔ rendimento (diagnóstico de RC)

```mermaid
flowchart TD
    A[BOM: identidade, quantidade, unidade, papel, fonte] --> B{Todos os nós admitem RC2?}
    B -- Não --> C[Retornar erro por campo: insumo, unidade, função ou fonte]
    B -- Sim --> D[Processo: entradas e saídas por etapa]
    D --> E{Cada consumível tem destino e cada material vem da BOM ou intermediário?}
    E -- Não --> F[Identificar órfão, material extra ou consumo duplo]
    E -- Sim --> G{Grafo acíclico e intermediários rastreáveis?}
    G -- Não --> H[Consertar dependência circular, alias ou nó perdido]
    G -- Sim --> I[RC3 indicativo]
    I --> J[Documentar tempo, local, ferramentas, especialista]
    J --> K[Separar sucesso, perdas, rendimento, qualidade e PA]
    K --> L{Lote bruto e aprovados são coerentes?}
    L -- Não --> M[Revisar medição/proposição e cenário]
    L -- Sim --> N[RC4 indicativo]
    N --> O[RC5 requer módulos, poder, economia, PS/JIT e segurança]
    O --> P[Resultado read-only, não fabricação]
```

**Como agir:** ferramenta ou condição ambiental NÃO são ingredientes por padrão. Intermediário tem entrada, saída, rendimento e custo próprios. Uma unidade de material consumida duas vezes sem divisão explícita é alerta de dupla contagem. O `RCn` do auditor é teto indicativo, não selo de maturidade oficial.

## FLUXO F4 — Autoridade, maturidade, publicação e conhecimento

```mermaid
flowchart TD
    A[Objeto de trabalho] --> B{É receita, item, conhecimento ou ocorrência?}
    B --> C[Classificar entidade separada]
    C --> D[Determinar autoridade: P3, PS ou P4]
    D --> E[Determinar completude técnica RC0 a RC5]
    E --> F{Dependências e JIT aptos?}
    F -- Não --> G[PRV ou PENDENTE na dimensão afetada]
    F -- Sim --> H{É somente estudo TEST?}
    H -- Sim --> I[LAB / sem publicação e sem REC-ID]
    H -- Não --> J{F5 GREEN, writer, NAC-CONT, NAC-NORM e NAC-PASS válidos?}
    J -- Não --> K[HOLD: nada em fontes produtivas]
    J -- Sim --> L[REC-LIB única, readback e histórico]
    L --> M{Conhecimento já descoberto pela Party?}
    M -- Não --> N[Somente Mestre-side]
    M -- Sim --> O[Derivação Player-safe estrita, autorizada]
```

**Como agir:** RC5 não é P4; P4 não garante RC5; PS não concede automaticamente fabricação; obter ou fabricar produto não significa que a receita seja conhecimento difundido.

## FLUXO F5 — Reprovação útil, substituição e recuperação

```mermaid
flowchart TD
    A[Anomalia detectada] --> B{Bloqueio local ou estrutural?}
    B -- Local --> C[Isolar unidade mínima e fonte]
    C --> D[Classificar erro: dado, fonte, custo, papel, processo, PA]
    D --> E[Aplicar correção apenas com evidência ou hipótese TEST]
    E --> F[Reexecutar teste do erro + regressões afetadas]
    B -- Estrutural --> G[Reexaminar produto e mecanismo causal]
    G --> H{Existe equivalente ou substituição?}
    H -- S0/S1 --> I[Validar cobertura total e ajustar variáveis]
    H -- S2 --> J[Propor linhagem derivada sem apagar base]
    H -- NO/PENDENTE --> K[Rejeitar ou suspender substituição]
    I --> F
    J --> F
    K --> L[Reformulação ou HOLD]
    F --> M{Mudança material afeta outras receitas?}
    M -- Sim --> N[PRV somente dependentes reais]
    M -- Não --> O[Preservar versões e histórico]
    N --> O
    O --> P[REGISTRAR DEPOIS + readback + NAC-PASS proporcional]
```

**Como agir:** após duas rodadas sem avanço funcional, mudar de caminho. A mesma candidata não deve alimentar infinitos laudos sem corrigir uma falha falsificável. Substituição não é válida apenas porque os nomes dos materiais são parecidos.

## FLUXO F6 — Interop PA e economia sem invenção

```mermaid
flowchart TD
    A[Efeito e processo estruturados] --> B[Classificar custos energéticos por modalidade]
    B --> C{Existe parecer competente de PA?}
    C -- Não --> D[Marcar PA PENDENTE, sem converter para zero]
    C -- Sim --> E[Consumir contrato vigente, guardar versão e recibo]
    E --> F[PA diário/ativação/manutenção separados]
    D --> G[Não fechar gate energético]
    F --> H[Arvore UTE: unidade, tempo, mercado e época]
    H --> I{Preços e rendimentos comparáveis?}
    I -- Não --> J[CTE parcial/simbólico e faixa, sem preço oficial]
    I -- Sim --> K[CTE CI+CP+CF+CT+CE+CK+CL+CA+CC]
    J --> L[Economia e PA continuam independentes do rank]
    K --> L
```

**Como agir:** jamais recriar o motor de PA. O CRAFT fornece efeito/proveniência e consome resposta do sistema competente; quando a API estiver inacessível, registra dependência testável. Nunca equalizar “preço de item” com “custo de insumos” ou “PA de ativação”.
