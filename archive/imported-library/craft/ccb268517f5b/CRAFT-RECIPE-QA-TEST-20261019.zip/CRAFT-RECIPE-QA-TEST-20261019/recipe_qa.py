#!/usr/bin/env python3
"""CRAFT — auditor estático de prontidão de receita (TEST, READ-ONLY).

NÃO desenha receitas, NÃO classifica itens oficialmente, NÃO fabrica,
NÃO lê ou escreve Notion, NÃO chama fornecedor PA, NÃO reserva writer.

As verificações implementam sinais de inconsistência rastreáveis às normas
já vigentes: PR-ITEM-02/REC-EXEC, PR-SC-01, PR-ECO-01, REC-LIB-01,
REC-LIN-SUB-01 e REC-MOD-REG-01. Nenhuma inferência vira fato canônico.
"""
from __future__ import annotations
import argparse
import copy
import json
import sys
from collections import defaultdict
from pathlib import Path

VERSION = 'CRAFT-RECIPE-QA-TEST/1.0.0'
FAMILIES = {
    'ARMA': ('arquitetura', 'integridade', 'equilibrio', 'interfaces', 'ensaio_de_uso'),
    'ARMADURA': ('cobertura', 'camadas', 'mobilidade', 'ajuste', 'ensaio_defensivo'),
    'EQUIPAMENTO': ('arquitetura', 'interface_usuario', 'funcao_principal', 'ensaio_uso'),
    'ARTEFATO': ('fonte_poder', 'interface_ativacao', 'estabilidade', 'restricoes'),
    'PILULA': ('dose', 'estabilidade', 'via_uso', 'ensaio_concentracao'),
    'POCAO': ('via_uso', 'volume', 'dose', 'estabilidade'),
    'INSCRICAO_ENC': ('substrato', 'aplicacao', 'compatibilidade', 'estabilidade'),
    'INSCRICAO_BAT': ('suporte', 'preparacao', 'gatilho', 'resolucao'),
    'MATRIZ': ('geometria', 'ancoras', 'energia', 'instalacao', 'calibracao'),
    'APRIMORAMENTO': ('base_referenciada', 'delta', 'compatibilidade', 'revalidacao'),
}
FAMILY_REF = {
    'ARMA': 'REC-MOD-ARM-01', 'ARMADURA': 'REC-MOD-ARD-01',
    'EQUIPAMENTO': 'REC-MOD-EQA-01', 'ARTEFATO': 'REC-MOD-ART-01',
    'PILULA': 'REC-MOD-PIL-01', 'POCAO': 'REC-MOD-POC-01',
    'INSCRICAO_ENC': 'REC-MOD-ENC-01', 'INSCRICAO_BAT': 'REC-MOD-BAT-01',
    'MATRIZ': 'REC-MOD-MAT-01', 'APRIMORAMENTO': 'REC-MOD-APR-01',
}
ALLOWED_PROVENANCE = {'CANONICO_VERIFICADO', 'FONTE_MESTRE', 'PS_VERIFICADO', 'TEST_FIXTURE'}
EXPECTED_ROLES = {'core', 'ativo', 'vetor', 'estabilizador', 'ligante', 'catalisador',
                  'amplificador', 'buffer', 'energia', 'substrato', 'recipiente',
                  'conservante', 'estrutura', 'interface', 'acabamento', 'outro_justificado'}
NO_COST = {'not_applicable_confirmed', 'documented_no_cost'}
VALID_COST = {'documented', 'provider_semicanonico', *NO_COST}


def has(x):
    return x is not None and x != '' and x != [] and x != {}


def number_gt0(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and 0 < x < float('inf')


def number_nonnegative(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and 0 <= x < float('inf')


def audit(doc: dict) -> dict:
    """Devuelve teto indicativo RC + findings. Nunca certifica RC oficial."""
    fs = []
    codes = set()

    def flag(code, severity, text, field, norm, remedy):
        if code not in codes:
            codes.add(code)
            fs.append(dict(code=code, severity=severity, diagnosis=text, field=field,
                           canonical_anchor=norm, next_action=remedy))

    if not isinstance(doc, dict):
        return {'engine': VERSION, 'classification': 'INVALID_INPUT', 'rc_ceiling_test': 'RC0',
                'production': 'DENY', 'findings': [{'code': 'INVALID_INPUT', 'severity': 'HOLD'}]}
    mode = doc.get('mode', 'FIXTURE_TEST' if doc.get('fixture_only') else None)
    if mode not in ('FIXTURE_TEST','SOURCE_READONLY') or (mode == 'FIXTURE_TEST' and not doc.get('fixture_only')):
        flag('SCOPE_NOT_FIXTURE', 'HOLD', 'Entrada fora dos dois modos autorizados (fixture TEST ou fonte Mestre read-only).',
             'mode', 'NAC-CONT-03 / OP-ARQ-RIN-REC-01', 'Indicar modo e confirmar limites')
    if mode == 'SOURCE_READONLY' and (not has(doc.get('source_ref')) or not has(doc.get('source_asof'))):
        flag('SOURCE_READBACK_MISSING', 'HOLD', 'Auditoria de fonte real exige referência e momento de leitura.',
             'source_ref', 'Princípio de verificação do estado real', 'Reabrir fonte e registrar data/versão')
    if doc.get('source_workspace') != 'MESTRE':
        flag('PARTY_BOUNDARY', 'HOLD', 'Fonte Party não pode ser reclassificada como Mestre.',
             'source_workspace', 'Separação Mestre↔Party', 'Usar fonte Mestre autorizada, mantendo Party read-only')
    if doc.get('request_write') or doc.get('request_publish') or doc.get('request_fabricate'):
        flag('NO_WRITE_GATE', 'HOLD', 'Validação não pode executar publicação ou fabricação.',
             'request_write', 'CRAFT/F5 HOLD + NAC-CONT-03', 'Retirar intenção de escrita e seguir gates externos')

    target = doc.get('target', {}) if isinstance(doc.get('target'), dict) else {}
    if not has(target.get('identity')) or not has(target.get('intended_function')):
        flag('PRODUCT_FIRST', 'HOLD', 'Falta item-alvo e função; não iniciar pesquisa indiscriminada de materiais.',
             'target', 'PR-ITEM-02 / DIR-MESTRE-CRAFT-PRODUTO-PRIMEIRO', 'Definir necessidade, usuário, função e produto-alvo')
    family = target.get('family')
    family_key = family if isinstance(family,str) else None
    if not isinstance(family,str) or family not in FAMILIES:
        flag('FAMILY_UNKNOWN', 'HOLD', 'Módulo especializado não selecionado.',
             'target.family', 'REC-MOD-REG-01', 'Roteie para o módulo real; não invente uma família')

    existing = doc.get('existing_first', {})
    if not isinstance(existing, dict) or existing.get('checked') is not True or not has(existing.get('scope')) or not has(existing.get('references')):
        flag('EXISTING_FIRST', 'HOLD', 'Anti-duplicata não demonstrado por escopo+referências.',
             'existing_first', 'PR-SC-01 §15 / REC-LIB-01', 'Pesquisar produto, função, fórmula, versão e linhagem')
    if existing and isinstance(existing, dict) and existing.get('duplicate_confirmed'):
        flag('DUPLICATE_FOUND', 'HOLD', 'Existe receita equivalente: não criar segunda verdade.',
             'existing_first.duplicate_confirmed', 'REC-LIB-01', 'Reutilizar ou derivar a fonte existente')
    lineage = doc.get('lineage', {})
    if isinstance(lineage, dict):
        if lineage.get('change') in ('material', 'mechanical') and lineage.get('strategy') != 'DERIVATIVE':
            flag('LINEAGE_MATERIAL_CHANGE', 'HOLD', 'Mudança material de produto/processo exige derivação e preservação da base.',
                 'lineage', 'REC-LIN-SUB-01', 'Criar apenas proposta de linhagem derivada, sem apagar base')
        if lineage.get('substitution') == 'SX' or lineage.get('substitution') == 'NO':
            flag('SUBSTITUTION_INVALID', 'HOLD', 'Substituição não cobre função obrigatória.',
                 'lineage.substitution', 'REC-LIN-SUB-01', 'Reprovar substituição ou obter substituto competente')
        if lineage.get('substitution') == 'PENDENTE':
            flag('SUBSTITUTION_PENDING', 'HOLD', 'Substituição não comprovada.',
                 'lineage.substitution', 'REC-LIN-SUB-01', 'Comparar todas as funções e qualidade mínima')

    stages = {'RC0': True, 'RC1': False, 'RC2': False, 'RC3': False,
              'RC4': False, 'RC5': False}
    bom = doc.get('bom') if isinstance(doc.get('bom'), list) else []
    if bom:
        stages['RC1'] = True
    else:
        flag('NO_BOM', 'HOLD', 'Composição não estruturada.', 'bom', 'REC-EXEC RC1', 'Identificar recursos já existentes e papéis')
    nodes = {}
    completed_bom = bool(bom)
    for i, part in enumerate(bom):
        place = f'bom[{i}]'
        if not isinstance(part, dict) or not isinstance(part.get('id'),str) or not has(part.get('id')):
            completed_bom = False
            flag('BOM_ID', 'HOLD', 'Componente sem identidade estável.', place, 'REC-LIB-01 / REC-EXEC', 'Resolver identidade sem fundir homônimos')
            continue
        n = part['id']
        if n in nodes:
            completed_bom = False
            flag('BOM_DUPLICATE_ID', 'HOLD', 'Componente duplicado no mesmo BOM.', place, 'REC-EXEC / REC-LIB-01', 'Reconciliar nós e quantidades')
        nodes[n] = part
        if not number_gt0(part.get('qty')) or not has(part.get('unit')):
            completed_bom = False
            flag('BOM_QTY_UNIT', 'HOLD', 'Quantidade/unidade material ausente, zero ou inválida.', place, 'REC-EXEC RC2', 'Registrar quantidade física positiva e unidade verificável')
        role = part.get('role')
        if not isinstance(role,str) or role not in EXPECTED_ROLES or not has(part.get('role_why')):
            completed_bom = False
            flag('BOM_ROLE', 'HOLD', 'Componente sem função causal comprovada/proposta explicitada.', place, 'REC-EXEC §C', 'Justificar papel e ensaio discriminatório')
        if not has(part.get('source_ref')) or not isinstance(part.get('provenance'),str) or part.get('provenance') not in ALLOWED_PROVENANCE:
            completed_bom = False
            flag('BOM_SOURCE', 'HOLD', 'Origem ou proveniência de componente indefinida.', place, 'PR-CRN-01 / REC-EXEC', 'Citar fonte; NOVO-P não é fonte admitida')
        if part.get('provenance') == 'TEST_FIXTURE' and mode != 'FIXTURE_TEST':
            completed_bom = False
            flag('FIXTURE_NOT_SOURCE', 'HOLD', 'Fixture não comprova insumo real.', place, 'NAC-CONT-03', 'Usar referência real')
        if part.get('dependency') in ('NOVO-P', 'UNVERIFIED', 'REJECTED'):
            completed_bom = False
            flag('UNADMITTED_DEPENDENCY', 'HOLD', 'Dependência não admissível para fabricação.', place, 'PR-SC-01 §9/10', 'Substituir por existente ou aguardar autorização competente')
    if completed_bom:
        stages['RC2'] = True

    operations = doc.get('operations') if isinstance(doc.get('operations'), list) else []
    completed_process = bool(operations) and completed_bom
    consumers = defaultdict(list)
    produces = defaultdict(list)
    opids = set()
    edges = defaultdict(set)
    for i, op in enumerate(operations):
        place = f'operations[{i}]'
        if not isinstance(op, dict) or not isinstance(op.get('id'),str) or not has(op.get('id')):
            completed_process = False
            flag('PROCESS_ID', 'HOLD', 'Etapa sem identidade.', place, 'REC-EXEC RC3', 'Nomear etapa e resultado')
            continue
        oid = op['id']
        if oid in opids:
            completed_process = False
            flag('PROCESS_DUPLICATE_ID', 'HOLD', 'Etapa repetida.', place, 'REC-EXEC RC3', 'Corrigir topologia de etapas')
        opids.add(oid)
        if not isinstance(op.get('inputs'), list) or not op.get('inputs'):
            completed_process = False
            flag('PROCESS_NO_INPUT', 'HOLD', 'Operação material sem entradas declaradas.', place, 'REC-EXEC RC3', 'Listar entradas ou documentar transformação de energia/condição')
        for inp in (op.get('inputs') if isinstance(op.get('inputs'),list) else []):
            if not isinstance(inp, str):
                completed_process = False
                flag('PROCESS_BAD_INPUT', 'HOLD', 'Entrada sem ID estável.', place, 'REC-EXEC RC3', 'Normalizar IDs')
                continue
            consumers[inp].append(oid)
        if not isinstance(op.get('outputs'), list) or not op.get('outputs'):
            completed_process = False
            flag('PROCESS_NO_OUTPUT', 'HOLD', 'Etapa não declara resultado.', place, 'REC-EXEC RC3', 'Indicar produto intermediário, final ou descarte')
        for out in (op.get('outputs') if isinstance(op.get('outputs'),list) else []):
            if isinstance(out, str):
                produces[out].append(oid)
            else:
                completed_process = False
                flag('PROCESS_BAD_OUTPUT', 'HOLD', 'Saída sem identidade.', place, 'REC-EXEC RC3', 'Normalizar IDs')
    for n, node in nodes.items():
        if node.get('consumed', True) and not consumers[n]:
            completed_process = False
            flag('BOM_ORPHAN', 'HOLD', f'Componente {n} não consumido em nenhuma etapa.', 'bom', 'REC-EXEC BOM↔processo', 'Ligar componente à etapa e destino')
        if node.get('consumed', True) and len(consumers[n]) > 1 and not node.get('split_explicit'):
            completed_process = False
            flag('DOUBLE_CONSUMPTION', 'HOLD', f'Componente {n} aparece como entrada múltipla sem alocação.', 'operations', 'REC-EXEC / PR-ECO anti-dupla-contagem', 'Declarar fracionamento por quantidade ou não reutilizar o insumo consumido')
    for n in consumers:
        if n not in nodes and n not in produces:
            completed_process = False
            flag('PROCESS_UNDECLARED_MATERIAL', 'HOLD', f'Etapa usa material {n} ausente do BOM e dos intermediários.', 'operations', 'REC-EXEC RC3', 'Reconciliar com fonte ou ferramenta/condição explícita')
        if n in produces:
            if len(produces[n]) > 1:
                completed_process = False
                flag('INTERMEDIATE_DUPLICATE', 'HOLD', f'Nó {n} produzido duas vezes sem merge explícito.', 'operations', 'REC-EXEC intermediários', 'Separar lotes ou justificar fusão')
            for prod in produces[n]:
                for con in consumers[n]:
                    edges[prod].add(con)
    # Todo intermediário que alimenta processo precisa ser produzido por etapa anterior:
    for n, ops in produces.items():
        if n != doc.get('final_node') and n not in consumers and n not in nodes and not n.startswith('WASTE_'):
            completed_process = False
            flag('INTERMEDIATE_DANGLING', 'HOLD', f'Intermediário {n} sem destino.', 'operations', 'REC-EXEC intermediários', 'Declarar saída final, subproduto ou uso posterior')
    if not isinstance(doc.get('final_node'),str) or doc.get('final_node') not in produces:
        completed_process = False
        flag('FINAL_NOT_PRODUCED', 'HOLD', 'Processo não produz o alvo final declarado.', 'final_node', 'REC-EXEC produto-alvo', 'Ligar etapa final ao item-alvo')
    visited, visiting = set(), set()
    def dfs(v):
        if v in visiting:
            return True
        if v in visited:
            return False
        visiting.add(v)
        if any(dfs(x) for x in edges.get(v, ())):
            return True
        visiting.remove(v)
        visited.add(v)
        return False
    if any(dfs(o) for o in opids):
        completed_process = False
        flag('PROCESS_CYCLE', 'HOLD', 'Grafo de fabricação contém ciclo de dependência.', 'operations', 'REC-EXEC intermediários', 'Separar retrabalho justificado de loop circular de material')
    if completed_process:
        stages['RC3'] = True

    mfg = doc.get('manufacture', {}) if isinstance(doc.get('manufacture'), dict) else {}
    completed_mfg = completed_process
    for key in ('lot', 'approved_units', 'time', 'equipment', 'specialist', 'conditions', 'failure_mode', 'qa', 'losses'):
        if not has(mfg.get(key)):
            completed_mfg = False
            flag('RC4_'+key.upper(), 'HOLD', 'Condição de fabricação não especificada: '+key+'.', 'manufacture.'+key,
                 'REC-EXEC RC4', 'Preencher com evidência ou PENDENTE; nunca inventar número')
    if not number_gt0(mfg.get('lot')):
        completed_mfg = False
        flag('INVALID_LOT', 'HOLD', 'Lote deve ter quantidade positiva.', 'manufacture.lot',
             'REC-EXEC RC4', 'Corrigir numerador e unidade')
    if not number_gt0(mfg.get('approved_units')):
        completed_mfg = False
        flag('INVALID_YIELD', 'HOLD', 'Unidades aprovadas devem ser positivas.', 'manufacture.approved_units',
             'REC-EXEC RC4', 'Verificar rendimento em unidade de produto')
    unit_start, unit_end = mfg.get('lot_unit'), mfg.get('approved_unit')
    if not has(unit_start) or not has(unit_end):
        completed_mfg = False
        flag('YIELD_UNITS_MISSING','HOLD','Unidade de lote ou aprovado não documentada.',
             'manufacture', 'REC-EXEC rendimento / PR-ECO UTE', 'Registrar unidades de entrada e saída')
    if unit_start != unit_end and not has(mfg.get('conversion_ref')):
        completed_mfg = False
        flag('YIELD_UNIT_AMBIGUOUS','HOLD','Unidades diferentes sem contrato de conversão.',
             'manufacture', 'PR-ECO UTE', 'Conservar quantidade como indeterminada até prova de conversão')
    if (number_gt0(mfg.get('approved_units')) and number_gt0(mfg.get('lot'))
        and unit_start == unit_end and mfg['approved_units']>mfg['lot']
        and not has(mfg.get('yield_multiplier_ref'))):
        completed_mfg = False
        flag('INVALID_YIELD', 'HOLD', 'Produto excede o lote sem lei de amplificação documentada.',
             'manufacture.approved_units', 'REC-EXEC rendimento', 'Provar multiplicação ou corrigir dado')
    tm=mfg.get('time')
    if not (isinstance(tm,dict) and number_gt0(tm.get('value')) and has(tm.get('unit')) and has(tm.get('ref'))):
        completed_mfg=False
        flag('RC4_TIME_EVIDENCE','HOLD','Tempo não é medida rastreável com unidade e fonte.',
             'manufacture.time','REC-EXEC RC4','Registrar tempo, unidade e fonte/hipótese claramente')
    eq=mfg.get('equipment')
    if not (isinstance(eq,list) and eq and all(isinstance(v,dict) and has(v.get('id')) and has(v.get('ref')) for v in eq)):
        completed_mfg=False
        flag('RC4_EQUIPMENT_EVIDENCE','HOLD','Ferramental carece de identidade e evidência.',
             'manufacture.equipment','REC-EXEC / PR-ECO','Separar reutilizável, consumível e infraestrutura')
    sp=mfg.get('specialist')
    if not (isinstance(sp,dict) and has(sp.get('competence')) and has(sp.get('ref'))):
        completed_mfg=False
        flag('RC4_SPECIALIST_EVIDENCE','HOLD','Especialista/habilidade sem origem documentada.',
             'manufacture.specialist','REC-EXEC RC4','Definir competência e referência')
    co=mfg.get('conditions')
    if not (isinstance(co,dict) and co.get('status') in ('documented','not_applicable')
            and has(co.get('ref')) and (co.get('status')!='not_applicable' or has(co.get('reason')))):
        completed_mfg=False
        flag('RC4_CONDITIONS_EVIDENCE','HOLD','Condições do processo não são demonstradas nem N/A justificado.',
             'manufacture.conditions','REC-EXEC RC4','Descrever janelas reais sem inventar probabilidade')
    fl=mfg.get('failure_mode')
    if not (isinstance(fl,list) and fl and all(isinstance(v,dict) and has(v.get('failure')) and has(v.get('response')) for v in fl)):
        completed_mfg=False
        flag('RC4_FAILURE_EVIDENCE','HOLD','Falhas e respostas não modeladas.',
             'manufacture.failure_mode','REC-EXEC RC4','Separar perda de insumo, falha de efeito e de equipamento')
    qa=mfg.get('qa')
    if not (isinstance(qa,list) and qa and all(isinstance(v,dict) and has(v.get('test')) and has(v.get('acceptance')) for v in qa)):
        completed_mfg=False
        flag('RC4_QA_EVIDENCE','HOLD','Critérios de qualidade não falsificáveis.',
             'manufacture.qa','REC-EXEC RC4','Definir teste e limite de aceite, sem medir ficticiamente')
    ls=mfg.get('losses')
    if not (isinstance(ls,dict) and ls.get('status') in ('documented','not_applicable')
            and has(ls.get('ref')) and (ls.get('status')!='not_applicable' or has(ls.get('reason')))
            and (ls.get('status')!='documented' or (number_nonnegative(ls.get('qty')) and has(ls.get('unit'))))):
        completed_mfg=False
        flag('RC4_LOSSES_EVIDENCE','HOLD','Perdas não especificadas, zero presumido ou unidades ausentes.',
             'manufacture.losses','REC-EXEC / PR-ECO-01','Conservar perdas indeterminadas, não 0, até existir fonte')
    if completed_mfg:
        stages['RC4'] = True

    completed_rc5 = completed_mfg
    mechanic = doc.get('mechanic', {}) if isinstance(doc.get('mechanic'), dict) else {}
    if not has(mechanic.get('source_mechanism')) or not has(mechanic.get('effect_and_limits')) or not has(mechanic.get('rank_comparator')):
        completed_rc5 = False
        flag('EFFECT_UNSUSTAINED', 'HOLD', 'Efeito/rank sem cadeia fonte→mecanismo→restrições→comparador.',
             'mechanic', 'PR-ITEM-02 / PR-SC-01 §8', 'Rastrear poder a fonte competente e testar limites')
    if mechanic.get('rank_from') in ('price', 'ingredient_count', 'rarity_alone'):
        completed_rc5 = False
        flag('RANK_PROXY_FORBIDDEN', 'HOLD', 'Preço, número de insumos ou raridade não determinam rank.',
             'mechanic.rank_from', 'PR-ITEM-02 REC-EXEC', 'Comparar efeitos/Atlas e módulo de poder')
    pa = doc.get('pa', {}) if isinstance(doc.get('pa'), dict) else {}
    for key in ('daily', 'per_activation'):
        part = pa.get(key)
        if not isinstance(part, dict) or not isinstance(part.get('status'),str) or part.get('status') not in VALID_COST:
            completed_rc5 = False
            flag('PA_'+key.upper(), 'HOLD', 'Modalidade de custo energético sem parecer competente.', 'pa.'+key,
                 'PA Universal / DIR-MESTRE-CRAFT-PRODUTO-PRIMEIRO', 'Preservar PENDENTE ou consultar motor autorizado')
        elif part['status'] in ('documented','provider_semicanonico') and not number_nonnegative(part.get('amount')):
            completed_rc5 = False
            flag('PA_AMOUNT_'+key.upper(), 'HOLD', 'Tarifa numérica documentada inválida.', 'pa.'+key,
                 'PA Universal', 'Exigir recibo e unidade efetivos')
        elif part['status'] in NO_COST and not has(part.get('reason')):
            completed_rc5 = False
            flag('PA_NA_REASON_'+key.upper(), 'HOLD', 'N/A ou custo nulo exige fonte/justificativa; ausência não é zero.',
                 'pa.'+key, 'PA Universal', 'Documentar razão e autoridade competente')
    if pa.get('provider') not in ('SOURCE_ONLY', 'PA_R27_TEST', 'CANONICAL_FUTURE', 'TEST_FIXTURE'):
        completed_rc5 = False
        flag('PA_PROVIDER', 'HOLD', 'Origem da classificação energética não identificada.', 'pa.provider',
             'PA Universal / CRAFT-QMC05', 'Obter contrato real sem motor paralelo')
    def credible_gate(v):
        return (isinstance(v, dict) and v.get('status') in
                ('TEST_EVIDENCE', 'SOURCE_EVIDENCE', 'NOT_APPLICABLE_DOCUMENTED')
                and has(v.get('ref')) and
                (v.get('status') != 'NOT_APPLICABLE_DOCUMENTED' or has(v.get('reason'))))

    refs = doc.get('module_evidence', {}) if isinstance(doc.get('module_evidence'), dict) else {}
    for key in FAMILIES.get(family_key, ()):
        if not credible_gate(refs.get(key)):
            completed_rc5 = False
            flag('MODULE_'+key.upper(), 'HOLD', f'Gatilho especializado {key} pendente.', 'module_evidence.'+key,
                 FAMILY_REF.get(family_key, 'REC-MOD-REG-01'), 'Consultar módulo e comprovar teste/condição')
    control = doc.get('control', {}) if isinstance(doc.get('control'), dict) else {}
    for key in ('knowledge', 'jit_review', 'qa_safety', 'dependencies', 'economy'):
        if not credible_gate(control.get(key)):
            completed_rc5 = False
            flag('CONTROL_'+key.upper(), 'HOLD', 'Gate RC5 sem evidência: '+key+'.', 'control.'+key,
                 'PR-SC-01 / PR-ECO-01', 'Registrar fonte, não preencher só com OK')
    if isinstance(control.get('dependencies'), dict):
        depth=control['dependencies'].get('max_ps_chain')
        if not isinstance(depth,int) or isinstance(depth,bool) or depth>2 or control['dependencies'].get('novop'):
            completed_rc5 = False
            flag('DEPENDENCY_GAP', 'HOLD', 'Cadeia semicanônica indefinida/>2 ou NOVO-P sem admissão.', 'control.dependencies',
                 'PR-SC-01 §10', 'PRV/JIT ou reformulação EXISTING-FIRST')
    risk = doc.get('risk', {}) if isinstance(doc.get('risk'), dict) else {}
    if risk.get('sc') in ('SC-3','SC-4') and not risk.get('master_decision_ref'):
        completed_rc5 = False
        flag('SC_DECISION_PENDING', 'HOLD', 'SC-3/SC-4 exige decisão apropriada antes de uso material.',
             'risk', 'PR-SC-01 §6', 'Submeter risco e consequência à autoridade Mestre')
    if not risk.get('classified'):
        completed_rc5 = False
        flag('SC_UNCLASSIFIED', 'HOLD', 'Risco semicanônico não classificado.', 'risk', 'PR-SC-01 §6', 'Analisar impacto sem presumir risco baixo')
    hard_vetos={'SCOPE_NOT_FIXTURE','SOURCE_READBACK_MISSING','PARTY_BOUNDARY',
                'NO_WRITE_GATE','PRODUCT_FIRST','FAMILY_UNKNOWN','EXISTING_FIRST',
                'DUPLICATE_FOUND','LINEAGE_MATERIAL_CHANGE','SUBSTITUTION_INVALID',
                'SUBSTITUTION_PENDING','FIXTURE_NOT_SOURCE'}
    if stages['RC4'] and completed_rc5 and not codes.intersection(hard_vetos):
        stages['RC5'] = True

    ceiling=max(k for k,v in stages.items() if v)
    blockers=[x for x in fs if x['severity']=='HOLD']
    return {
        'engine': VERSION,
        'case_id': doc.get('case_id','UNSPECIFIED'),
        'assessment': ('SOURCE_READONLY_STATIC_NOT_CANONICAL' if mode == 'SOURCE_READONLY' else 'STATIC_TEST_NOT_CANONICAL'),
        'rc_ceiling_test': ceiling,
        'rc_not_official': True,
        'source_truth': 'DECLARED_INPUT_NOT_INDEPENDENTLY_AUTHENTICATED',
        'production': 'DENY',
        'official_recipe_created': False,
        'can_publish': False,
        'family_module': FAMILY_REF.get(family_key, 'PENDING'),
        'stage_checks': {k: v for k, v in stages.items()},
        'blocks': len(blockers),
        'findings': fs,
        'next_action': (blockers[0]['next_action'] if blockers else
                       'Solicitar NAC-PASS e autoridade humana competente; não publicar por este parecer'),
    }


def main():
    parser=argparse.ArgumentParser(description='CRAFT auditor read-only: JSON de preflight → JSON diagnóstico')
    parser.add_argument('input',help='JSON com dados TEST/read-only; NÃO cria receita')
    parser.add_argument('-o','--output',help='Salvar recibo JSON, sem escrever Notion')
    args=parser.parse_args()
    obj=json.loads(Path(args.input).read_text(encoding='utf-8'))
    receipt=audit(obj)
    rendered=json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True)
    if args.output:
        Path(args.output).write_text(rendered+'\n',encoding='utf-8')
    else:
        print(rendered)
    return 0

if __name__=='__main__':
    sys.exit(main())
