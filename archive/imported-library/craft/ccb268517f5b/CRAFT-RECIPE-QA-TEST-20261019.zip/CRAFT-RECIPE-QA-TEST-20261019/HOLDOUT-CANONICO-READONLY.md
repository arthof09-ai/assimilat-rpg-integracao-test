# HOLDOUT DIRIGIDO EM FONTES MESTRE REAIS — SOMENTE LEITURA

**AS-OF:** leitura Notion durante esta instância em 19/10/2026 (últimas edições de origem indicadas abaixo). **NÃO** é auditoria global, recontagem de acervo, verificação de preço, medição física nem correção retrospectiva. A ferramenta `recipe_qa.py` complementa a inspeção humana; o extrator automático de corpo Notion não foi homologado neste ensaio. Nenhuma receita foi criada ou alterada.

## H1 — Pílula Agregação da Alma (canônica)

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede8198abdce4eee5ffcaeb · última edição exposta por Notion: `2026-10-03T05:36:55.606Z`.

**VERIFICADO NO TEXTO:** entre os ingredientes, há quantidade escrita `Xx Núcleos Elementais`; o processo menciona especificamente um Núcleo Elemental de Água. A etapa final manda solidificar em pílulas, sem contagem de unidades aprovadas expressa no trecho lido. Há condição noturna/astral de repouso/cristalização. Efeito mágico descrito é qualitativo, sem quantificação de bônus ou custo de PA nessa leitura.

**DIAGNÓSTICO DE ENGENHARIA:** RC2 não pode ser certificado pela quantidade `Xx`; reconciliação de tipo genérico vs Núcleo de Água exige a fonte competente — não assumir equivalência ou quantidade. RC4 para custo unitário depende de rendimento/doses. Janela noturna é condição real da receita, não floreio; falta rateio/custo/QA concreto para equipará-la a uma produção homologada.

**RESULTADO:** item/cânone preservado; **executabilidade indeterminada/abaixo do RC5 demonstrável**. Não inventar o número de Núcleos nem de pílulas; não lançar errata de origem sem ordem do Mestre.

## H2 — Receita (P) da Matriz de Invocação

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81b2b826ef6f6d30dc6c · última edição: `2026-10-02T12:45:10.742Z`.

**VERIFICADO NO TEXTO:** ingredientes especificam `Cristais de Alma 2P`, enquanto passo de posicionamento diz `Cristais de Mana Puro`; há alternativa entre Pedra da Luz e Pote de Essência Mágica; Óleo de Vedação e fonte energética aparecem na lista, porém sua utilização não está rastreada explicitamente nas quatro etapas da descrição recuperada. Receita mira uma instalação/matriz, não mero produto portátil.

**DIAGNÓSTICO DE ENGENHARIA:** alias `Alma 2P` ↔ `Mana Puro` **não comprovado**, não renomear por semelhança; alternativas exigem contrato S0/S1/S2/NO e economia por variante; BOM↔processo tem possíveis componentes órfãos. A maturidade depende da arquitetura de instalação, condições energéticas, QA e manutenção do módulo REC-MOD-MAT-01.

**RESULTADO:** possibilidade de revisão técnica dirigida; nenhuma origem alterada, nenhuma equivalência arbitrária, nenhuma energia inventada, nenhum cálculo de custo ou PA novo.

## H3 — Poção Troca Atributos

**Fonte Mestre:** https://app.notion.com/p/3edc2b324ede81759411f34a98e6887b · última edição: `2026-10-03T21:43:11.630Z`.

**VERIFICADO NO TEXTO:** efeito do item descrito (troca temporária de atributo mais forte até meia-noite do dia tomado). O corpo consultado não apresenta ingredientes, processo, dose, volume ou recipiente de fabricação.

**DIAGNÓSTICO DE ENGENHARIA:** **existência do item e descrição do efeito não equivalem à disponibilidade de fórmula executável**. Não fabricar retrospectivamente uma receita nem declarar que a poção não existe.

**RESULTADO:** registro de item preservado; receita não demonstrada. Não extrapolar que todos os recipientes de poção têm frascos/pesos/volumes idênticos.

## Síntese transversal dos três casos

- **3/3 páginas Mestre individuais reabertas e lidas** nesta instância. Denominador é **somente três fontes selecionadas**; não é censo nem amostra aleatória representativa.
- **3/3 exibem lacunas relevantes para engenharia reprodutível** de tipos distintos: unidade/quantidade; identidade/BOM↔processo; ausência de fórmula.
- **0/3 fichas alteradas, 0 receitas criadas, 0 valores canônicos preenchidos por inferência**.
- **Gate real**: a nova rotina QA não converte essas lacunas em correções oficiais; elas compõem **holdout de diagnóstico manual**, distinto da suíte automatizada de fixtures abstratas. Não contar 3 como 3 testes de código.

## Como melhorar o consultor após esta rodada

1. Adaptador read-only Notion→contrato (sem inventar identidades, mantendo corpo original e âncoras); separar extração automática de veredito.
2. Detector de quantidade `Xx`/unidade impossível, de aparente alias e de BOM órfã; cada alerta exige confronto literal, não correção automática.
3. Extrair condição temporal como dependência de fabricação; não estimar probabilidade de sucesso ou desgaste sem fonte.
4. Comparar o conjunto de fontes com a matriz de gates dos dez módulos da família.
5. Repetir com novos casos independentes, contabilizando falsos positivos e falsos negativos com anotação humana/competente.
