#!/usr/bin/env python3
"""Testes falsificáveis do auditor estático; apenas casos abstratos FI-*.
Nenhum fixture é uma receita, produto, insumo ou mecânica do RPG.
"""
import copy
import json
import unittest
from recipe_qa import audit, FAMILIES

GATE={'status':'TEST_EVIDENCE','ref':'FIXTURE-QA-LOCAL'}

def fixture():
    return {
        'case_id':'FI-ABSTRACT-01','fixture_only':True,'source_workspace':'MESTRE',
        'request_write':False,'request_publish':False,'request_fabricate':False,
        'target':{'identity':'FI-ALVO','intended_function':'VALIDAR_ESTRUTURA_ABSTRATA','family':'ARMADURA'},
        'existing_first':{'checked':True,'scope':'FI-ONLY','references':['FI-CATALOG'],
                          'duplicate_confirmed':False},
        'lineage':{'change':'editorial','strategy':'SAME_VERSION'},
        'bom':[{'id':'FI-A','qty':1,'unit':'unidade_sintetica','role':'estrutura',
                'role_why':'somente teste de rastreio','source_ref':'FI-SOURCE-A',
                'provenance':'TEST_FIXTURE','consumed':True}],
        'operations':[{'id':'FI-ETAPA-1','inputs':['FI-A'],'outputs':['FI-RESULTADO']}],
        'final_node':'FI-RESULTADO',
        'manufacture':{'lot':1,'approved_units':1,
                       'lot_unit':'unidade_sintetica','approved_unit':'unidade_sintetica',
                       'time':{'value':1,'unit':'tempo_sintetico','ref':'FI-DURACAO'},
                       'equipment':[{'id':'FI-FERRAMENTA','ref':'FI-TOOL-REF'}],
                       'specialist':{'competence':'FI-PERFIL','ref':'FI-SOURCE-REF'},
                       'conditions':{'status':'not_applicable','ref':'FI-SOURCE-REF','reason':'fixture'},
                       'failure_mode':[{'failure':'FI-FALHA','response':'FI-PARAR'}],
                       'qa':[{'test':'FI-QA','acceptance':'FI-ACEITE'}],
                       'losses':{'status':'not_applicable','ref':'FI-TEST-REF','reason':'fixture'}},
        'mechanic':{'source_mechanism':'FI-MODELO SEM EFEITO REAL',
                    'effect_and_limits':'FI-LIMITES DE TESTE','rank_comparator':'FI-COMPARAÇÃO-ABSTRATA',
                    'rank_from':'effect'},
        'pa':{'provider':'TEST_FIXTURE',
              'daily':{'status':'not_applicable_confirmed','reason':'não é item, fixture somente'},
              'per_activation':{'status':'not_applicable_confirmed','reason':'não é item, fixture somente'}},
        'module_evidence':{key:copy.deepcopy(GATE) for key in FAMILIES['ARMADURA']},
        'control':{'knowledge':copy.deepcopy(GATE),'jit_review':copy.deepcopy(GATE),
                   'qa_safety':copy.deepcopy(GATE),
                   'dependencies':dict(GATE,max_ps_chain=0,novop=False),
                   'economy':copy.deepcopy(GATE)},
        'risk':{'classified':True,'sc':'SC-1'}
    }

def codes(x):
    return {v['code'] for v in audit(x)['findings']}

class Contract(unittest.TestCase):
    def test_full_fixture_only_rc5_but_denies_production(self):
        r=audit(fixture())
        self.assertEqual(r['rc_ceiling_test'],'RC5')
        self.assertEqual(r['blocks'],0)
        self.assertEqual(r['production'],'DENY')
        self.assertFalse(r['can_publish'])
        self.assertFalse(r['official_recipe_created'])
        self.assertTrue(r['rc_not_official'])
    def test_immutability(self):
        f=fixture();b=copy.deepcopy(f);audit(f);self.assertEqual(f,b)
    def test_reproducibility(self):
        f=fixture();self.assertEqual(json.dumps(audit(f),sort_keys=True),json.dumps(audit(f),sort_keys=True))
    def test_non_mapping(self):
        self.assertEqual(audit(None)['classification'],'INVALID_INPUT')
    def test_all_families_dispatch(self):
        for name,fields in FAMILIES.items():
            with self.subTest(name=name):
                f=fixture();f['target']['family']=name
                f['module_evidence']={key:copy.deepcopy(GATE) for key in fields}
                self.assertEqual(audit(f)['rc_ceiling_test'],'RC5')

class Security(unittest.TestCase):
    def test_security_mutations(self):
        mutants=[
            ('SCOPE_NOT_FIXTURE',lambda f:f.update(fixture_only=False)),
            ('PARTY_BOUNDARY',lambda f:f.update(source_workspace='PARTY')),
            ('PARTY_BOUNDARY',lambda f:f.update(source_workspace=None)),
            ('NO_WRITE_GATE',lambda f:f.update(request_write=True)),
            ('NO_WRITE_GATE',lambda f:f.update(request_publish=True)),
            ('NO_WRITE_GATE',lambda f:f.update(request_fabricate=True)),
            ('PRODUCT_FIRST',lambda f:f['target'].update(identity=None)),
            ('PRODUCT_FIRST',lambda f:f['target'].update(intended_function='')),
            ('FAMILY_UNKNOWN',lambda f:f['target'].update(family='NENHUMA')),
            ('EXISTING_FIRST',lambda f:f['existing_first'].update(checked=False)),
            ('EXISTING_FIRST',lambda f:f['existing_first'].update(references=[])),
            ('EXISTING_FIRST',lambda f:f['existing_first'].update(scope='')),
            ('DUPLICATE_FOUND',lambda f:f['existing_first'].update(duplicate_confirmed=True)),
            ('LINEAGE_MATERIAL_CHANGE',lambda f:f['lineage'].update(change='material')),
            ('LINEAGE_MATERIAL_CHANGE',lambda f:f['lineage'].update(change='mechanical')),
            ('SUBSTITUTION_INVALID',lambda f:f['lineage'].update(substitution='NO')),
            ('SUBSTITUTION_INVALID',lambda f:f['lineage'].update(substitution='SX')),
            ('SUBSTITUTION_PENDING',lambda f:f['lineage'].update(substitution='PENDENTE')),
        ]
        for ix,(expected,fn) in enumerate(mutants):
            with self.subTest(i=ix,expected=expected):
                f=fixture();fn(f);self.assertIn(expected,codes(f))
                self.assertEqual(audit(f)['production'],'DENY')

class BOM(unittest.TestCase):
    def test_material_mutations(self):
        mutants=[
            ('NO_BOM', lambda f: f.update(bom=[])),
            ('BOM_ID', lambda f: f['bom'][0].update(id=None)),
            ('BOM_DUPLICATE_ID', lambda f: f['bom'].append(copy.deepcopy(f['bom'][0]))),
            ('BOM_QTY_UNIT', lambda f: f['bom'][0].update(qty=0)),
            ('BOM_QTY_UNIT', lambda f: f['bom'][0].update(qty=-1)),
            ('BOM_QTY_UNIT', lambda f: f['bom'][0].update(qty='1')),
            ('BOM_QTY_UNIT', lambda f: f['bom'][0].update(unit='')),
            ('BOM_ROLE', lambda f: f['bom'][0].update(role='decoracao')), 
            ('BOM_ROLE', lambda f: f['bom'][0].update(role_why='')),
            ('BOM_SOURCE', lambda f: f['bom'][0].update(source_ref='')),
            ('BOM_SOURCE', lambda f: f['bom'][0].update(provenance='INVENTADO')),
            ('UNADMITTED_DEPENDENCY', lambda f: f['bom'][0].update(dependency='NOVO-P')),
            ('UNADMITTED_DEPENDENCY', lambda f: f['bom'][0].update(dependency='REJECTED')),
        ]
        for i,(exp,fn) in enumerate(mutants):
            with self.subTest(i=i,exp=exp):
                f=fixture();fn(f)
                self.assertIn(exp,codes(f));self.assertLess(int(audit(f)['rc_ceiling_test'][-1]),5)

class Process(unittest.TestCase):
    def test_process_mutations(self):
        mutants=[
            ('PROCESS_ID',lambda f:f['operations'][0].update(id=None)),
            ('PROCESS_DUPLICATE_ID',lambda f:f['operations'].append(copy.deepcopy(f['operations'][0]))),
            ('PROCESS_NO_INPUT',lambda f:f['operations'][0].update(inputs=[])),
            ('PROCESS_NO_OUTPUT',lambda f:f['operations'][0].update(outputs=[])),
            ('BOM_ORPHAN',lambda f:f['operations'][0].update(inputs=['FI-X'])),
            ('DOUBLE_CONSUMPTION',lambda f:f['operations'].append({'id':'FI-2','inputs':['FI-A'],'outputs':['WASTE_FI']})),
            ('PROCESS_UNDECLARED_MATERIAL',lambda f:f['operations'][0].update(inputs=['FI-A','FI-X'])),
            ('FINAL_NOT_PRODUCED',lambda f:f.update(final_node='FI-OTHER')),
            ('INTERMEDIATE_DANGLING',lambda f:f['operations'][0].update(outputs=['FI-RESULTADO','FI-ORPHAN'])),
            ('INTERMEDIATE_DUPLICATE',lambda f:f['operations'].append({'id':'FI-2','inputs':['FI-RESULTADO'],'outputs':['FI-RESULTADO']})),
        ]
        for i,(exp,fn) in enumerate(mutants):
            if fn is None:continue
            with self.subTest(i=i,exp=exp):
                f=fixture();fn(f);self.assertIn(exp,codes(f))
                self.assertLess(int(audit(f)['rc_ceiling_test'][-1]),4)
    def test_acyclic_intermediate_success(self):
        f=fixture();f['operations']=[
            {'id':'P1','inputs':['FI-A'],'outputs':['I1']},
            {'id':'P2','inputs':['I1'],'outputs':['FI-RESULTADO']}]
        self.assertNotIn('PROCESS_CYCLE',codes(f))
        self.assertEqual(audit(f)['rc_ceiling_test'],'RC5')
    def test_process_cycle(self):
        f=fixture();f['operations']=[
            {'id':'P1','inputs':['FI-A','I2'],'outputs':['I1']},
            {'id':'P2','inputs':['I1'],'outputs':['I2','FI-RESULTADO']}]
        self.assertIn('PROCESS_CYCLE',codes(f))
        self.assertLess(int(audit(f)['rc_ceiling_test'][-1]),4)
    def test_undeclared_tool_not_material(self):
        f=fixture();f['operations'][0]['tools']=['FI-TOOLS']
        self.assertEqual(audit(f)['rc_ceiling_test'],'RC5')
    def test_double_consumption_explicit_split(self):
        f=fixture();f['bom'][0]['split_explicit']=True
        f['operations'].append({'id':'P2','inputs':['FI-A'],'outputs':['WASTE_RESIDUE']})
        self.assertNotIn('DOUBLE_CONSUMPTION',codes(f))

class RC4(unittest.TestCase):
    def test_empty_mfg_fields(self):
        for key in ['lot','approved_units','time','equipment','specialist','conditions','failure_mode','qa','losses']:
            with self.subTest(key=key):
                f=fixture();f['manufacture'][key]=None
                self.assertIn('RC4_'+key.upper(),codes(f))
                self.assertLess(int(audit(f)['rc_ceiling_test'][-1]),4)
    def test_bad_lot_and_yield(self):
        f=fixture();f['manufacture']['lot']=-2;self.assertIn('INVALID_LOT',codes(f))
        f=fixture();f['manufacture']['approved_units']=2;self.assertIn('INVALID_YIELD',codes(f))
        f=fixture();f['manufacture']['approved_units']='2';self.assertIn('INVALID_YIELD',codes(f))
        f=fixture();f['manufacture']['approved_units']=2;f['manufacture']['yield_multiplier_ref']='FI-FONTE-AMPLIFICACAO'
        self.assertNotIn('INVALID_YIELD',codes(f))

class RC5(unittest.TestCase):
    def test_power_pa_mutations(self):
        mutants=[
            ('EFFECT_UNSUSTAINED',lambda f:f['mechanic'].update(source_mechanism='')),
            ('EFFECT_UNSUSTAINED',lambda f:f['mechanic'].update(effect_and_limits=None)),
            ('EFFECT_UNSUSTAINED',lambda f:f['mechanic'].update(rank_comparator='')),
            ('RANK_PROXY_FORBIDDEN',lambda f:f['mechanic'].update(rank_from='price')),
            ('RANK_PROXY_FORBIDDEN',lambda f:f['mechanic'].update(rank_from='ingredient_count')),
            ('PA_DAILY',lambda f:f['pa'].update(daily={'status':'PENDENTE'})),
            ('PA_PER_ACTIVATION',lambda f:f['pa'].update(per_activation={})),
            ('PA_PROVIDER',lambda f:f['pa'].update(provider=None)),
            ('PA_AMOUNT_DAILY',lambda f:f['pa'].update(daily={'status':'documented','amount':-1})),
            ('PA_AMOUNT_PER_ACTIVATION',lambda f:f['pa'].update(per_activation={'status':'documented','amount':'5'})),
            ('PA_NA_REASON_DAILY',lambda f:f['pa'].update(daily={'status':'not_applicable_confirmed'})),
            ('PA_NA_REASON_PER_ACTIVATION',lambda f:f['pa'].update(per_activation={'status':'documented_no_cost'})),
        ]
        for i,(exp,fn) in enumerate(mutants):
            with self.subTest(i=i,exp=exp):
                f=fixture();fn(f);self.assertIn(exp,codes(f))
                self.assertLess(int(audit(f)['rc_ceiling_test'][-1]),5)
    def test_module_gates(self):
        for key in FAMILIES['ARMADURA']:
            for variant in ({},{'status':'PENDENTE','ref':'X'},{'status':'TEST_EVIDENCE'},'PENDENTE'):
                with self.subTest(key=key,variant=variant):
                    f=fixture();f['module_evidence'][key]=variant
                    self.assertIn('MODULE_'+key.upper(),codes(f))
    def test_control_gates(self):
        for key in ['knowledge','jit_review','qa_safety','dependencies','economy']:
            for variant in ({},'PENDENTE',{'status':'NOT_APPLICABLE_DOCUMENTED','ref':'TEST'}):
                with self.subTest(key=key,variant=variant):
                    f=fixture();f['control'][key]=variant
                    self.assertIn('CONTROL_'+key.upper(),codes(f))
    def test_dependency_chain(self):
        f=fixture();f['control']['dependencies']['max_ps_chain']=3
        self.assertIn('DEPENDENCY_GAP',codes(f))
        f=fixture();f['control']['dependencies']['novop']=True
        self.assertIn('DEPENDENCY_GAP',codes(f))
    def test_sc_risk(self):
        f=fixture();f['risk']['classified']=False;self.assertIn('SC_UNCLASSIFIED',codes(f))
        for sc in ['SC-3','SC-4']:
            f=fixture();f['risk']['sc']=sc
            self.assertIn('SC_DECISION_PENDING',codes(f))
            f['risk']['master_decision_ref']='TEST-DECISION-NOT-REAL'
            self.assertNotIn('SC_DECISION_PENDING',codes(f))
    def test_documented_zero_can_be_explicit(self):
        f=fixture();f['pa']['daily']={'status':'documented','amount':0}
        f['pa']['per_activation']={'status':'documented','amount':0}
        self.assertNotIn('PA_AMOUNT_DAILY',codes(f))
        self.assertNotIn('PA_AMOUNT_PER_ACTIVATION',codes(f))

class StageProgression(unittest.TestCase):
    def test_progression(self):
        f=fixture()
        self.assertEqual(audit(f)['rc_ceiling_test'],'RC5')
        f['control']['economy']='PENDENTE';self.assertEqual(audit(f)['rc_ceiling_test'],'RC4')
        f['manufacture']['qa']=[];self.assertEqual(audit(f)['rc_ceiling_test'],'RC3')
        f['operations'][0]['inputs']=[];self.assertEqual(audit(f)['rc_ceiling_test'],'RC2')
        f['bom'][0]['qty']=None;self.assertEqual(audit(f)['rc_ceiling_test'],'RC1')
        f['bom']=[];self.assertEqual(audit(f)['rc_ceiling_test'],'RC0')

# Executável por discovery `python -m unittest`, sem modificar código em produção.
class FurtherRobustness(unittest.TestCase):
    def test_readonly_requires_readback(self):
        f=fixture();f['fixture_only']=False;f['mode']='SOURCE_READONLY'
        f['source_ref']='https://app.notion.com/p/3edc2b324ede8198abdce4eee5ffcaeb'
        f['source_asof']='2026-10-03T05:36:55Z'
        f['bom'][0]['provenance']='FONTE_MESTRE'
        self.assertNotIn('SOURCE_READBACK_MISSING',codes(f))
        self.assertNotIn('SCOPE_NOT_FIXTURE',codes(f))
        self.assertEqual(audit(f)['production'],'DENY')
        f['source_asof']=None
        self.assertIn('SOURCE_READBACK_MISSING',codes(f))
    def test_scope_veto_never_rc5(self):
        for key, val in [('request_write',True),('source_workspace','PARTY'),('fixture_only',False)]:
            with self.subTest(field=key):
                f=fixture();f[key]=val
                self.assertNotEqual(audit(f)['rc_ceiling_test'],'RC5')
    def test_mfg_evidence_falsification(self):
        cases=[
            ('RC4_TIME_EVIDENCE','time','PENDENTE'),
            ('RC4_TIME_EVIDENCE','time',{'value':1,'unit':'min'}),
            ('RC4_EQUIPMENT_EVIDENCE','equipment',['PENDENTE']),
            ('RC4_SPECIALIST_EVIDENCE','specialist','PENDENTE'),
            ('RC4_CONDITIONS_EVIDENCE','conditions','PENDENTE'),
            ('RC4_FAILURE_EVIDENCE','failure_mode',['PENDENTE']),
            ('RC4_QA_EVIDENCE','qa',['PENDENTE']),
            ('RC4_LOSSES_EVIDENCE','losses',{'status':'documented','qty':0}),
            ('YIELD_UNITS_MISSING','lot_unit',None),
            ('YIELD_UNITS_MISSING','approved_unit',None),
            ('YIELD_UNIT_AMBIGUOUS','approved_unit','dose'),
        ]
        for expected,field,v in cases:
            with self.subTest(expected=expected,field=field):
                f=fixture();f['manufacture'][field]=v
                self.assertIn(expected,codes(f))
                self.assertLess(int(audit(f)['rc_ceiling_test'][-1]),4)
    def test_no_unjustified_zero_or_source_independent_claim(self):
        f=fixture();r=audit(f)
        self.assertEqual(r['source_truth'],'DECLARED_INPUT_NOT_INDEPENDENTLY_AUTHENTICATED')
        f['manufacture']['losses']={'status':'documented','qty':0,'unit':'u','ref':'FI-DOC'}
        self.assertNotIn('RC4_LOSSES_EVIDENCE',codes(f))  # zero explicitamente documentado, não pressuposto
    def test_deterministic_adversarial_300_cases(self):
        import random
        rnd=random.Random(20261019)
        candidates=[None,[],{},'PENDENTE','99',True,-1,0,123,{'surprise':['obj']}, ['weird']]
        paths=[('target','family'),('bom',0,'id'),('bom',0,'qty'),('bom',0,'role'),
               ('bom',0,'provenance'),('operations',0,'inputs'),('operations',0,'outputs'),
               ('manufacture','lot'),('manufacture','approved_units'),('manufacture','time'),
               ('manufacture','qa'),('manufacture','conditions'),('pa','daily'),('pa','provider'),
               ('risk','sc'),('control','dependencies'),('final_node',)]
        for i in range(300):
            f=fixture();p=rnd.choice(paths);value=copy.deepcopy(rnd.choice(candidates))
            x=f
            for k in p[:-1]:x=x[k]
            x[p[-1]]=value
            try:r=audit(f)
            except Exception as e:
                self.fail(f'Mutação FI-{i:03d} {p}={value!r} causou crash: {type(e).__name__}: {e}')
            self.assertEqual(r['production'],'DENY')
            self.assertFalse(r['can_publish'])

if __name__ == "__main__":
    unittest.main(verbosity=2)
