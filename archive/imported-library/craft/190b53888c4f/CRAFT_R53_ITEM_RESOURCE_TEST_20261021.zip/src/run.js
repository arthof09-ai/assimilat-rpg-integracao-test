'use strict';
const fs=require('fs'),path=require('path');const {valid,playerSafe}=require('./validate');
const root=path.join(__dirname,'..');const d=JSON.parse(fs.readFileSync(path.join(root,'data','proposals.json'))), resources=JSON.parse(fs.readFileSync(path.join(root,'data','resources.json')));
const res=valid(d,resources);fs.mkdirSync(path.join(root,'outputs'),{recursive:true});fs.writeFileSync(path.join(root,'outputs','QA_RESULT.json'),JSON.stringify(res,null,2)+'\n');
fs.writeFileSync(path.join(root,'outputs','PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json'),JSON.stringify(d.products.map(playerSafe),null,2)+'\n');
console.log(JSON.stringify({status:res.status,total:res.total,resources:res.distinct_sources,projects:res.items.map(x=>({name:x.name,verdict:x.verdict,holds:x.holds.length,issues:x.issues.length}))},null,2));
