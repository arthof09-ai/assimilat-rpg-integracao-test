import json, pathlib, html
base=pathlib.Path(__file__).resolve().parent
validator=(base/'src/validate.js').read_text()
products=(base/'data/proposals.json').read_text()
resources=(base/'data/resources.json').read_text()
mastercards=(base/'data/master_cards_13.json').read_text()
economics=(base/'data/economic_case.json').read_text()
econ_validator=(base/'src/economic_gate.js').read_text()
# JSON inside JS as assignments; replaces '</' to avoid injection if later modified.
products_safe=products.replace('</','<\\/')
resources_safe=resources.replace('</','<\\/')
mastercards_safe=mastercards.replace('</','<\\/')
economics_safe=economics.replace('</','<\\/')
page='''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>R53 — Auditor de Itens & Recursos TEST</title>
<style>
:root { color-scheme:dark; font-family:system-ui,-apple-system,Segoe UI,sans-serif; background:#0c1420; color:#edf4ff; }
* {box-sizing:border-box;} body{margin:0; padding:16px; max-width:930px; margin-inline:auto;}
h1{font-size:1.45rem;letter-spacing:-.02em;margin:.5rem 0} h2{font-size:1.08rem;margin:0 0 .55rem}
p{line-height:1.5;color:#cbd9ee}
header{padding:8px 0 16px;} .small{font-size:.85rem;color:#abc0d9}
.box{border:1px solid #33455e;border-radius:14px;padding:16px;background:#121e2e;margin-bottom:13px;overflow-wrap:anywhere}
.tag{display:inline-block;padding:4px 10px;border-radius:99px;background:#4c3a21;color:#ffdfad;font-weight:650;font-size:.76rem;letter-spacing:.02em}
.stat{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px}.stat div{border-radius:10px;background:#1d2b3d;padding:10px}
.stat strong{display:block;font-size:1.5rem}.stat small{color:#b3c6df}
button,.btn{border:0;display:inline-block;border-radius:10px;background:#d2e2ff;color:#082443;padding:11px 13px;font-size:.89rem;font-weight:650;cursor:pointer;margin-right:7px;margin-top:5px}button.secondary{background:#293b54;color:#eaf1ff}
input[type=file]{display:block;width:100%;max-width:100%;font-size:.84rem;color:#fff;border:1px dashed #577390;border-radius:8px;padding:10px;margin:10px 0}
select{background:#1b2d44;color:#fff;border:1px solid #587392;font-size:1rem;border-radius:10px;padding:10px;width:100%}
ul{padding-left:21px;line-height:1.55} li{margin-bottom:5px} .mono{font-family:ui-monospace,Consolas,monospace;font-size:.79rem;color:#b6c9e2;white-space:pre-wrap;overflow-wrap:anywhere}
a{color:#a7cfff} details{border-top:1px solid #34445a;padding:10px 0} pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.78rem;color:#c9d7e9} summary{cursor:pointer;font-weight:600}
hr{border:0;border-top:1px solid #32465e;margin:15px 0}.warn{color:#ffcc90}.ok{color:#9bdfc3} footer{padding:12px 0 25px}
@media (max-width:450px){body{padding:10px} .box{padding:13px} button{width:100%;margin:5px 0} h1{font-size:1.25rem}}
</style></head><body>
<header><span class="tag">MESTRE-SIDE · TEST · SEM PUBLICAÇÃO</span><h1>R53 · Auditor de criação de itens e recursos</h1><p>Ferramenta local para revisar propostas conforme PR-ITEM-02 e REC-EXEC. Não exige login, não envia dados para servidores e não cria itens no Notion.</p></header>
<section class="box"><h2>Carregar proposta</h2><p class="small">Abra o arquivo <code>proposals.json</code> fornecido no pacote, ou revise os dois exemplos já carregados. Este aplicativo usa um índice congelado de cinco fontes consultadas em 21/10/2026; mudanças posteriores exigem releitura no Notion.</p>
<input type="file" id="upload" accept="application/json,.json"/><button id="check">Validar propostas</button><button id="save" class="secondary">Salvar diagnóstico JSON</button><div id="loadStatus" class="small" role="status">Exemplos locais prontos.</div></section>
<section class="box"><h2>Resumo da auditoria</h2><div id="top" class="stat"></div></section>
<section class="box"><h2>Economia — quatro valores diferentes</h2><div id="economy" class="small"></div></section><section id="cards" aria-live="polite"></section>
<footer class="small">Atenção: PASS de formulário não significa receita RC5, efeito mágico instalado, existência material, aprovação do Mestre, preço ou RE homologado. Não compartilhar com Party/O Primeiro.</footer>
<script>
'''+validator+econ_validator+'''
const INDEX = '''+resources_safe+''';
let PROJECT = '''+products_safe+''';
const MASTER_CARDS = '''+mastercards_safe+''';
const ECON_CASE = '''+economics_safe+''';
function safe(t){return String(t??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');}
let current;
function render(){
 current=valid(PROJECT,INDEX);
 const e=reviewCost(ECON_CASE); document.getElementById('economy').innerHTML=`<p class="warn">${safe(e.gate)} · Sem preço de produto calculável</p><p>Para o tônico, valores históricos dos recursos NÃO equivalem a preço de poção ou a CTE. Pendências: ${e.pending.map(safe).join(', ')}.</p>`;
 document.getElementById('top').innerHTML = `<div><small>Projetos examinados</small><strong>${current.total}</strong></div><div><small>Recursos distintos usados</small><strong>${current.distinct_sources}</strong></div><div><small>Projetos liberados para fabricação</small><strong>0</strong></div>`;
 document.getElementById('cards').innerHTML=current.items.map((v,i)=>`<article class="box"><h2>${safe(v.name)}</h2><span class="tag">${safe(v.verdict)}</span><p class="small">${safe(v.family)} · ${v.source_census} fontes catalogadas · ${v.issues.length} erros · ${v.holds.length} pendências</p><p>${safe(PROJECT.products[i]?.mechanic)}</p><details open><summary>Pendências (${v.holds.length})</summary><ul>${v.holds.map(e=>`<li><b>${safe(e.code)}</b>: ${safe(e.msg)}</li>`).join('')}</ul></details><details ${v.issues.length?'open':''}><summary>Erros críticos (${v.issues.length})</summary><ul>${v.issues.map(e=>`<li><b>${safe(e.code)}</b>: ${safe(e.msg)}</li>`).join('')}</ul></details><details><summary>Fontes canônicas citadas</summary><ul>${v.evidence.map(e=>`<li><a href="${safe(e.source_url)}" target="_blank" rel="noopener">${safe(e.source_name)}</a> — ${safe(e.node_id)}</li>`).join('')}</ul></details><details><summary>Observação pública segura (NÃO publicar)</summary><p>${safe(PROJECT.products[i]?.player_view?.visible_properties)}</p></details>${MASTER_CARDS.cards.find(c=>c.id===v.id)?`<details><summary>Ficha Mestre I–XIII — íntegra TEST</summary>${Object.entries(MASTER_CARDS.cards.find(c=>c.id===v.id).chapters).map(([k,val])=>`<details><summary>${safe(k.replaceAll('_',' '))}</summary><pre>${safe(JSON.stringify(val,null,2))}</pre></details>`).join('')}</details>`:''}</article>`).join('');
}
document.getElementById('check').addEventListener('click',render);
document.getElementById('upload').addEventListener('change',async (e)=>{
 const f=e.target.files?.[0]; if(!f)return;
 try{ const d=JSON.parse(await f.text());if(!Array.isArray(d.products))throw Error('JSON deve conter products[]');PROJECT=d;render();document.getElementById('loadStatus').textContent=`Proposta local carregada: ${f.name} — ${d.products.length} itens.`;}catch(ex){document.getElementById('loadStatus').textContent='Falha no arquivo: '+ex.message;}
});
document.getElementById('save').addEventListener('click',()=>{
 if(!current)render();const txt=JSON.stringify(current,null,2)+'\\n';const blob=new Blob([txt],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='R53_QA_TEST_RESULT.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
});
render();
</script></body></html>'''
(base/'REVISOR_LOCAL_ANDROID_R53_TEST.html').write_text(page,encoding='utf-8')
print('HTML',len(page),'bytes')
