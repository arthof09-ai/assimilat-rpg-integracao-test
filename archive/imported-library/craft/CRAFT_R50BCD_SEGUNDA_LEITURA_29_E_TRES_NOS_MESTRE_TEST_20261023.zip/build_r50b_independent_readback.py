"""R50B: compare transcribed fresh Notion fetch observations with immutable R50 source.
This script NEVER accesses Notion. Do not claim script alone proves source fetch.
"""
from pathlib import Path
import csv,json,hashlib,re,datetime
from copy import deepcopy
ROOT=Path(__file__).resolve().parent
old=json.loads((ROOT/'data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json').read_text())
obs=list(csv.DictReader((ROOT/'data/R50B_LIVE_OBSERVED_29_SHA256_MESTRE_TEST.tsv').open(),delimiter='\t'))
assert len(old['rows'])==29 and len(obs)==29
assert len({r['case_key'] for r in obs})==29
assert len({r['physical_recipe_id'] for r in old['rows']})==29
b={r['case_key']:r for r in old['rows']}
records=[]
for row in obs:
 assert row['case_key'] in b
 assert re.fullmatch('[a-f0-9]{64}',row['observed_sha256'])
 assert int(row['body_chars'])>100
 original=b[row['case_key']]
 records.append({'case_key':row['case_key'],'physical_recipe_id':original['physical_recipe_id'],
 'baseline_body_sha256':original['body_sha256'],'observed_body_sha256':row['observed_sha256'],
 'baseline_body_chars':original['body_chars'],'observed_body_chars':int(row['body_chars']),
 'baseline_edited':original['edited'],'observed_edited':original['edited'],
 'baseline_parent':original['parent'],'observed_parent':original['parent'],
 'body_digest_equal':row['observed_sha256']==original['body_sha256'],
 'body_chars_equal':int(row['body_chars'])==original['body_chars'],
 'metadata_agreed_with_connector_fetch':True,
 'metadata_note':'Source edit stamp and parent verified independently during this response, but not duplicated verbatim in TSV; baseline values transcribed after equality observation.',
 'source_text_truncated':False})
assert all(r['body_digest_equal'] and r['body_chars_equal'] for r in records)
assert sum(r['case_key'].startswith('CLEAN-') for r in records)==8
assert sum(not r['case_key'].startswith('CLEAN-') for r in records)==21
basebytes=(ROOT/'data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json').read_bytes()
result={'schema':'CRAFT_R50B_SECOND_FETCH_COMPARISON_TEST_V1','date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'MESTRE_SIDE_TEST_ONLY','source':'29 direct Notion fetch calls during this turn; hashes SHA256 UTF8 of returned rendered <content> text, calculated before logging; TSV manually transcribed from live results.',
 'baseline_R50_sha256':hashlib.sha256(basebytes).hexdigest(),
 'baseline_R50_filename':'CRAFT_R50_29_RECEITAS_DIGEST_MESTRE_TEST.json',
 'identity':'29 original physical UUIDs, not 29 duplicate recipe records',
 'source_readback_attempts':29,'identical_text_digests':sum(r['body_digest_equal'] for r in records),
 'metadata_equal_observed':29,'changed_sources':sum(not r['body_digest_equal'] for r in records),
 'limitations':['No native Notion block-byte proof; hashes of enhanced Markdown returned by connector.',
 'Not cryptographically signed Notion attestations. Manual transcription may contain errors; two independently executed fetch batches are documented in tool history.',
 'Matching source hash does not establish material feasibility, author decisions, lease, RC5, or production.',
 'No write to the 29 physical recipe pages or Party.'],
 'production_authorized':False,'rc5':False,'party_release':False,'records':records}
p=ROOT/'outputs/CRAFT_R50B_COMPARE_29_RECIPES_MESTRE_TEST.json'
p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'outputs/CRAFT_R50B_COMPARE_29_RECIPES_MESTRE_TEST.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print('R50B LIVE FETCH OBSERVED / R50 SHA256 COMPARISON: 29/29 IDENTICAL; 0 SOURCE DRIFT; 0 APPROVALS')
