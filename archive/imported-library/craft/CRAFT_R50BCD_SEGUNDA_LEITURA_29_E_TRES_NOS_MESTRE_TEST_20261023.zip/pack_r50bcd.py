"""Deterministic distribution of CRAFT R50B/R50C/R50D on top of original R50 corpus."""
from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parent
mfile=root/'MANIFEST-R50BCD.json'
out=root.parent/'CRAFT_R50BCD_SEGUNDA_LEITURA_29_E_TRES_NOS_MESTRE_TEST_20261023.zip'
files=sorted(p for p in root.rglob('*') if p.is_file() and p!=mfile and '__pycache__' not in p.parts and p.suffix!='.pyc')
manifest={'schema':'CRAFT_R50BCD_TEST_MANIFEST_V1','classification':'MESTRE_SIDE_ONLY_DO_NOT_SEND_PARTY','upstream':'R50 canonical corpus; R49 HTML stable','observation':'2026-10-23 direct Notion fetch 29/29 content SHA recheck; 3 precedent roles reviewed','limits':'Rendered enhanced Markdown sha; not native Notion bytes, not physical/RC5/author decision','writes':'no recipe/stock/party/production writes','files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
mfile.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[mfile]:
  rel=p.relative_to(root).as_posix();info=zipfile.ZipInfo(rel,date_time=(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('PACK',len(files),'file digests',out.name,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
