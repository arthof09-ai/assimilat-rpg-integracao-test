"""R50C: annotate 3 existing R46 requests with evidence-role suitability.
Read-only analytical finding, not reidentification or physical validation.
"""
from pathlib import Path
import json
root=Path(__file__).resolve().parent
request=json.loads((root/'outputs/CRAFT_R27_PEDIDOS_R46_3_NOS_MESTRE_TEST.json').read_text())
raw=[(pr['proposal_id'],n) for pr in request['projects'] for n in pr['targeted_material_requests']]
assert len(raw)==3
obs={
 ('R53-TEST-SONDA-001','B3'):{'observed_source':'Acácia Radiante / ficha de Ervas/Botânica','notion_edit_stamp':'2026-10-21T03:38:26.147Z','semantic_relevance':'PRECEDENTE_BOTANICO_PARCIAL','observation':'Fonte descreve resina com uso narrativo de selamento luminoso; NÃO demonstra forma, encaixe, isolação, lote ou compatibilidade da Sonda.','next_evidence':'Documento do material e teste dimensional/encaixe/isolação independente'},
 ('R53-TEST-TONICO-002','B3'):{'observed_source':'Receita histórica localizada em Poções','notion_edit_stamp':'2026-10-03T05:39:05.809Z','semantic_relevance':'PRECEDENTE_DE_RECEITA_NAO_ESPECIFICA_VEICULO','observation':'Fonte fornece ingredientes e passos de poção; não é ficha de veículo líquido real, estabilidade, extração, compatibilidade ou segurança de dose para este Tônico.','next_evidence':'Identidade do veículo e prova de compatibilidade/estabilidade/segurança independente'},
 ('R53-TEST-TONICO-002','B4'):{'observed_source':'Receita Óleo de Vedação Alternativo, categoria Poções','notion_edit_stamp':'2026-10-03T04:46:58.180Z','semantic_relevance':'PRECEDENTE_SEM_PROVA_DE_RECIPIENTE_OU_FECHO','observation':'A fonte trata de óleo de selamento, não comprova material de frasco, volume aferido, fecho físico, higiene ou retenção. Link histórico preservado, sem interpretá-lo como recipiente.','next_evidence':'Fonte Mestre de recipiente/fecho efetivo e ensaio real de capacidade, fechamento e compatibilidade'}
}
rows=[]
for proposal,n in raw:
 key=(proposal,n['node_id']);o=obs[key]
 rows.append(dict(proposal_id=proposal,node_id=n['node_id'],material_role=n['material_role'],source_precedent_url=n['source_precedent_url'],source_precedent_is_not_proof=True,source_page_last_edited=o['notion_edit_stamp'],source_description=o['observed_source'],source_suitability=o['semantic_relevance'],finding=o['observation'],next_needed=o['next_evidence'],evidence_requirements=[q['key'] for q in n['evidence_requirements']],source_readback_this_turn=True,physical_test_executed=False,physical_evidence_verified=False,author_decision_authenticated=False,rc5=False,allow_production=False,allow_party_release=False))
assert len(rows)==3 and len({(r['proposal_id'],r['node_id']) for r in rows})==3
assert all(r['source_precedent_url'].startswith('https://app.notion.com/p/') for r in rows)
assert sum(r['source_suitability']=='PRECEDENTE_SEM_PROVA_DE_RECIPIENTE_OU_FECHO' for r in rows)==1
obj={'schema':'CRAFT_R50C_SOURCE_ROLE_FIT_READONLY_TEST_V1','date_local':'2026-10-23','environment':'MESTRE_ONLY_TEST','precedent_not_proof':True,
 'basis':'Direct readback of 3 exact Notion precedent pages and 4 parent source pages as referenced by prior R27 request; interpretation is PROPOSTO and requires original decision',
 'sources_checked':7,'nodes':3,'role_fit_review_needed':3,'unsafe_automatic_source_relinks':0,
 'safety':'Not a recommendation for real ingested tonic or a magic transfer experiment',
 'writes':0,'canonical_recipe_changes':0,'physical_evidence_verified':0,'rc5':0,'party_publication':False,'findings':rows}
p=root/'outputs/CRAFT_R50C_TRES_NOS_PRECEDENTES_MESTRE_TEST.json';p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print('R50C 3/3 provenance-role suitability audited; B4 vessel/oil gap isolated; all HOLD')
