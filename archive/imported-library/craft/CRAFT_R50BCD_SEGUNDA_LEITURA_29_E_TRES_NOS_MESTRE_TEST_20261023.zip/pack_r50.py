"""Archive continuation of original R49 CRAFT; R50 only read-only source audit."""
from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parent
mfile=root/'MANIFEST-R50.json';out=root.parent/'CRAFT_R50_AUDITORIA_CORPUS_NOTION_MESTRE_TEST_20261023.zip'
files=sorted(p for p in root.rglob('*') if p.is_file() and p!=mfile and '__pycache__' not in p.parts and '.pyc'!=p.suffix)
m={'schema':'CRAFT_R50_TEST_MANIFEST_V1','classification':'MESTRE_ONLY_TEST_DO_NOT_SEND_PARTY',
'upstream_source':'CRAFT_R49_RETOMADA_COLETA_R46_MESTRE_TEST_20261022.zip',
'write_scope':'OP/LAB DOC ONLY; 0 recipe/stock/party/production edits',
'live_notions_read_on':'2026-10-23',
'digest_scope':'29 original physical recipe page <content> enhanced Markdown UTF-8 SHA256; not Notion native blocks',
'files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
mfile.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[mfile]:
  rel=p.relative_to(root).as_posix();zi=zipfile.ZipInfo(rel,date_time=(2026,10,23,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
  z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print(f'R50: {len(files)}/{len(files)} manifest entries and ZIP CRC ready; bytes={out.stat().st_size}; SHA256={hashlib.sha256(out.read_bytes()).hexdigest()}')
