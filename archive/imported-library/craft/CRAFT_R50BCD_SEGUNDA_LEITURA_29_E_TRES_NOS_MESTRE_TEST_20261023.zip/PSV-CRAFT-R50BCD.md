# PSV — CRAFT R50B/R50C/R50D — GATE MESTRE TEST / 23/10/2026

PASS DOCUMENTAL restrito: segundo fetch independente de 29/29 fontes físicas canônicas → hashes de corpo retornado, edit stamps e parents iguais ao snapshot R50; 3/3 nós R46 auditados por adequação da fonte, sem laudos e sem substituição de links.

REPRODUÇÃO: execução do gerador não busca o Notion. Apenas valida arquivo de observações transcrito de tool result do presente turno (verificar limite de procedência). Usar `python replay_r50bcd.py` depois de extrair ZIP e checar manifesto. O motor e HTML R49/R50 são preservados bit a bit. Browser Chromium emulado não equivale a Android físico.

NEGATIVOS: 0 receitas alteradas, 0 materiais novos, 0 RC5, 0 produtos físicos, 0 economia/estoque alterado, 0 resposta autoral autenticada, 0 laudo R46, 0 divulgação Party, 0 O Primeiro, 0 alteração de lease/epoch/ACK. C19-021/F5/REC-LIB e writer produtivo continuam HOLD. NAC-AUTO-01 permanece proposta, não usado para contornar gates.

Gate digital aferido após extração do ZIP em diretório limpo: 223/223 hashes de arquivos do manifesto, 224 entradas ZIP com CRC PASS, 34/34 suítes JavaScript e 2.084/2.084 verificações PASS, recibos QA históricos SHA idênticos, 2.000/2.000 sondagens sintéticas PASS, 24/24 suítes Chromium emulado distribuídas em três lotes 393+209+212 = 814/814 PASS. A verificabilidade do texto nativo do Notion e do hardware Android é PENDENTE.

R50D adicional: busca dirigida no Notion e leitura da raiz Itens, 17/17 referências de primeiro nível, norma e incubadora; 384 menções de páginas internas varridas sem nome exato de categoria REC-LIB; ausência de categoria física direta observada, mas **ausência global NÃO DEMONSTRADA**. R51 REC-LIB segue HOLD sem writer/fencing, 0 criação de páginas.
