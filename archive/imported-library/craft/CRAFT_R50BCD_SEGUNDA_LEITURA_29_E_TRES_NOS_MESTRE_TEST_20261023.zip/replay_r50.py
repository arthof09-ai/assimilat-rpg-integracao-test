"""Cold replay: R49 CRAFT engine unchanged plus R50 read-only source digest audit."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,csv
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST-R50.json').read_text())
assert m['schema']=='CRAFT_R50_TEST_MANIFEST_V1'
for name,h in m['files'].items():
 p=root/name;assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==h,('MANIFEST_FILE_CHANGED',name)
print('MANIFEST R50',len(m['files']),'/'+str(len(m['files'])),'PASS',flush=True)
corpus=json.loads((root/'data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json').read_text())
rows=corpus['rows']
assert len(rows)==29 and len(set(x['physical_recipe_id'] for x in rows))==29
assert len([r for r in rows if r['case_key'].startswith('CLEAN-')])==8
assert all(re.fullmatch('[a-f0-9]{64}',r['body_sha256']) for r in rows)
with (root/'outputs/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.csv').open() as f:
 assert list(csv.DictReader(f)) and len(list(csv.DictReader(open(root/'outputs/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.csv'))))==29
print('29/29 Notion-source TEXT snapshot entries, 21 lexical + 8 unflagged; baseline-first, not native content verified',flush=True)
suites=sorted((root/'tests').glob('test_*.js')); count=0
for f in suites:
 z=subprocess.run(['node',str(f)],cwd=root,text=True,capture_output=True,timeout=45)
 mm=re.search(r'(\d+)\s*/\s*(\d+)',z.stdout)
 assert z.returncode==0 and mm and mm[1]==mm[2],(f,z.stdout[-250:],z.stderr[-250:]);count+=int(mm[1])
assert len(suites)==31 and count==1898,(len(suites),count)
print(f'JS {len(suites)}/{len(suites)} {count}/{count} PASS',flush=True)
for a in [('node','src/run.js'),('node','src/verify_outputs.js'),('node','tests/fuzz_schema_r11.js')]:
 z=subprocess.run(a,cwd=root,capture_output=True,text=True,timeout=70)
 assert z.returncode==0,(a,z.stdout[-300:],z.stderr[-200:])
 if a[1].endswith('fuzz_schema_r11.js'):assert 'PASS 2000' in z.stdout
for f,d in [('outputs/QA_RESULT.json','b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'),('outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json','509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8')]:
 assert hashlib.sha256((root/f).read_bytes()).hexdigest()==d
print('QA + receipt + 2000 fuzz, historic QA/preview SHA256 unchanged, 2 project proposals HOLD',flush=True)
if '--full' in sys.argv:
 browser=sorted((root/'tests').glob('test_browser_*.py'))+[root/'tests/test_mobile_browser_r9.py'];assert len(browser)==24
 total=0
 for f in browser:
  z=subprocess.run([sys.executable,str(f)],cwd=root,text=True,capture_output=True,timeout=90)
  mm=re.search(r'(\d+)\s*/\s*(\d+)',z.stdout)
  assert z.returncode==0 and mm and mm[1]==mm[2],(f,z.stdout[-300:],z.stderr[-300:]);total+=int(mm[1]);print('CHROME',f.name,mm[1],flush=True)
 assert total==814,(total,'814')
 print('CHROMIUM 24/24 814/814 PASS EMULATED (NOT ANDROID HARDWARE)',flush=True)
print('R50 only-documentation-and-text-digest TEST PASS. RC5/REC-LIB/PROD/PARTY HOLD',flush=True)
