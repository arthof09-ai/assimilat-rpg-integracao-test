# CRAFT R50B/R50C/R50D — Atualização de evidências, NÃO run R51/REC-LIB

O pacote contém o motor offline CRAFT original, revisor Mestre-only e toda sua história preservada, acrescidos de comparação independente de corpus Notion (R50B) e auditoria de precedentes R46 (R50C). R50 e R49 NÃO foram sobrescritos em suas fontes na Biblioteca; o HTML distribuído continua bit-idêntico.

## Como conferir

Após extração: `python replay_r50bcd.py`. Se houver Chromium instalado no computador de teste, executar também os scripts `tests/test_browser_*.py` em lotes; os resultados de emulação não certificam o aplicativo no celular Android real.

As 29 linhas TSV derivam de novas leituras Notion efetuadas nesta interação e comparadas com o baseline R50, **não de uma chamada futura que o script realizará sozinho**. O replay revalida integridade, conteúdo transcrito, comportamento do comparador e motor antigo; não consulta Notion nem aprova criação de itens, materiais, craft ou publicação.

Documentos são MESTRE-ONLY. Não distribuir à Party ou O Primeiro.

R50D: descoberta dirigida da área REC-LIB; sem pasta/receita criada e sem prova de ausência em todo Notion.

Atualização R50D: 17/17 páginas de primeiro nível de Itens lidas, 384 links de páginas examinados por rótulo e 0 ocorrências exatas do destino REC-LIB. Não prova ausência global.
