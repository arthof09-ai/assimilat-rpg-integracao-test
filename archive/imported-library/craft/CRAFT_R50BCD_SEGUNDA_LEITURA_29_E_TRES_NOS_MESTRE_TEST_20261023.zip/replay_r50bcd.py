"""Reproducible offline verification of CRAFT R50B/R50C/R50D distribution.
Independent live Notion fetch must be performed outside this script.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile,csv
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST-R50BCD.json').read_text())
assert manifest['schema']=='CRAFT_R50BCD_TEST_MANIFEST_V1'
for name,digest in manifest['files'].items():
 path=root/name
 assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==digest,('PACKAGE_TAMPER',name)
print('R50B/R50C/R50D MANIFEST',len(manifest['files']),'/',len(manifest['files']),'PASS',flush=True)
base=json.loads((root/'data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json').read_text())
comp=json.loads((root/'outputs/CRAFT_R50B_COMPARE_29_RECIPES_MESTRE_TEST.json').read_text())
source=json.loads((root/'outputs/CRAFT_R50C_TRES_NOS_PRECEDENTES_MESTRE_TEST.json').read_text())
rows=comp['records']
assert len(base['rows'])==len(rows)==29
assert len(set(x['physical_recipe_id'] for x in rows))==29
assert comp['identical_text_digests']==29 and comp['changed_sources']==0
assert all(r['baseline_body_sha256']==r['observed_body_sha256'] and r['baseline_body_chars']==r['observed_body_chars'] for r in rows)
assert len(source['findings'])==3 and source['writes']==0 and source['rc5']==0
rec_lib=json.loads((root/'outputs/CRAFT_R50D_REC_LIB_DESTINO_LEITURA_MESTRE_TEST.json').read_text())
assert rec_lib['decision']=='HOLD_DESTINATION_NOT_VERIFIED' and rec_lib['physical_destination_id_verified'] is None and not rec_lib['create_parent']
print('R50B TWO DISTINCT OBSERVATION RECORDS 29/29; R50C EVIDENCE-ROLE AUDIT 3/3; ALL GATES HOLD',flush=True)
suites=sorted((root/'tests').glob('test_*.js'));total=0
for f in suites:
 z=subprocess.run(['node',str(f)],cwd=root,text=True,capture_output=True,timeout=45)
 m=re.search(r'(\d+)\s*/\s*(\d+)',z.stdout)
 assert z.returncode==0 and m and m[1]==m[2],(f,z.stdout[-300:],z.stderr[-300:])
 total+=int(m[1])
assert len(suites)==34 and total==2084,(len(suites),total)
print('R50BCD JS',len(suites),'/',len(suites),'SUITES',total,'/',total,'PASS',flush=True)
for command in [('node','src/run.js'),('node','src/verify_outputs.js'),('node','tests/fuzz_schema_r11.js')]:
 z=subprocess.run(command,cwd=root,text=True,capture_output=True,timeout=80)
 assert z.returncode==0,(command,z.stdout[-400:],z.stderr[-300:])
 if command[1].endswith('fuzz_schema_r11.js'):assert 'PASS 2000' in z.stdout
for name,digest in [
 ('outputs/QA_RESULT.json','b307dd7d24f18bbdc46e16c3ff75dd011898de0713f0d1784a51eb5ea932a541'),
 ('outputs/PLAYER_PREVIEW_NOT_FOR_PUBLICATION.json','509505549c0d174e55cfe3d0f400c23529817040b82109508db4e7e773103db8')]:
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,('HISTORIC_OUTPUT_CHANGED',name)
# Preview hash separately: original R50 QA must be identical, no run of new motor.
assert hashlib.sha256((root/'REVISOR_LOCAL_ANDROID_R53_TEST.html').read_bytes()).hexdigest()=='a4a4574411462e1dac6da44ba95ebb895fa646684033ad45198f1c56c405ee2b'
print('QA+receipt+2000 fuzz, HTML SHA immutable; Notion native content/Android hardware NOT certified',flush=True)
print('R50B/C/D PASS in TEST only — no canonical writes, source text found unchanged, production HOLD',flush=True)
