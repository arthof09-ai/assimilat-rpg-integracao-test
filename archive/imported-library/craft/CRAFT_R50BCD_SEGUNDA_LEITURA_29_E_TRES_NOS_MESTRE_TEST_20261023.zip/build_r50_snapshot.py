"""R50: write transcript-based SHA-256 digests of exact Notion fetch <content> text.
No Notion calls, page edits, or plaintext copies of canonic source; MESTRE-only TEST.
"""
from pathlib import Path
import csv,json,re
from hashlib import sha256
base=Path(__file__).resolve().parent
D={
'ENC-08':('5b8c28604beabe07e9e811714eed22e75d2dbbd80a6b9647faafc74a44a7a2b9',2223),
'MAT-06':('aadffac210a402d923051a499c6efef1eae9791d48a8c2888f5b0a3fa65c0caf',2279),
'MAT-03':('7f38a6b96b2981398c362c9bc3bca3a94d23c61eb0ec1d855a773c159e8d2e35',2252),
'MAT-05':('d8c7524e031c409238c7d7e882461e20a29db042cf37d4037abe8c2105bb128a',2514),
'BAT-08':('b0ad64be56a2d07f75bf97c3287cd1e140126106dfd677536d1c638eba5aae43',2201),
'MAT-01-ON':('8acf361ce1d8ef5bf8579bb8d921525e09d1a561358664a5cc2e554791232d78',2526),
'BAT-02':('080d4ff5d8d2914cfbd0baeed92022caa0e9c47c567c8b16cd08203edf85f2db',2385),
'BAT-14':('52661ee96a498fa102fa9094cd0da89119df4e31be5d2ca7ce72e950f5b03b21',2286),
'ENC-06':('c7afd57b91627ee5012d8c882021be8a11e806bd0951c5f69b834acba7db6568',2877),
'BAT-06':('6c560e002badf5a40d6cbc231296ce4b140dce23b3c346e52c1a0009837458b0',2647),
'BAT-12':('f68308fac876cc6567810c25827a4088a89b8534ad8e81056bfdb39b9f390dbb',2114),
'BAT-03':('271ce3fcbe31c6e023f89259463adb73e586cd5e0b2119007d99d3cbabcca23c',1655),
'BAT-11':('ce8e920e1323f2efd5d71ea209b822e3efc152b9a6b088912f7b3889d8578e9b',2219),
'BAT-13':('e074d0324497f126037cfc3e18950857c15f6e8ba2c197f1f4e234a1c19b11ac',2295),
'MAT-02':('d04febbcf045493aa2a23f2eef187fa017d275c72a669500ab8bae3c8ac072d7',2180),
'ENC-01':('087325a6534c7d8d65df21181ed58a5a3b3e8e2b5171c9b6332a9804cf39c86c',1845),
'MAT-01-P':('77aceb86cef61bc590d0a32c575cc9e1456b885f587187fdc5a7fca97d0e7008',1860),
'ENC-02':('1df69e8f74af2c9fcbdb27ce9de06716dde4dc54bb02318c4b7d3c3820f3570a',1997),
'BAT-04':('362e2510a30e32d4a5977d02b95c514991dc52eef3dcddc474bd00ca2e1a8f54',2118),
'BAT-10':('07e5b9eea3745fff4237b2eeb208da3a4cb1f67f1e588e788db0d18d9956721e',2369),
'MAT-04':('4d5f9cb51802446141b268653373784e0390593c5680d94a3f1562ef88d82c41',2024),
'CLEAN-01':('7081f576d5a0705bd97e7de7fdc36a732e9be4f1625e6387536445ef0a3f2619',1939),
'CLEAN-02':('1a8f951049d7ec0a85fb48688c8dd45feea48e7d7f16f583eddf406f31bf24f7',2164),
'CLEAN-03':('93e86ded87aa0015938d8fb1adfd76c296a070756d42c46d110b8ff4a8565393',2296),
'CLEAN-04':('6dfa93d39b8a3b10e5c4b97681d40b0993b427b4a5fa20eac8fa68c3b080a1ef',1879),
'CLEAN-05':('70c5bab8349c4173bf8ae772c270fbebf68f1ace1ff825d43c74f95214565441',1998),
'CLEAN-06':('f33d4fbcd8c38fd545c6465afb3ff1b62d2a0dcf01e357c0a4c647ba44e5d158',2501),
'CLEAN-07':('f39a9d97db936f9b7a592725543550b0933f6a6e9f21937239e7e773fb20d9f6',2285),
'CLEAN-08':('26c7d5932a8cfe483b8ff4a47e44ce58d439ce3405ded2405c6a55d87771c27d',1851),
}
previous=json.loads((base/'data/r44_29_notion_metadata_readback.json').read_text())
records=[]
for c in previous['baseline']:
    d=D[c['case_key']]
    records.append(dict(c, body_chars=d[1],body_sha256=d[0],source_text_truncated=False))
assert len(records)==29 and len(set(x['physical_recipe_id'] for x in records))==29
assert len(D)==29 and len(set(x['body_sha256'] for x in records))==29
assert all(re.fullmatch(r'[a-f0-9]{64}',x['body_sha256']) for x in records)
assert sum(x['case_key'].startswith('CLEAN-') for x in records)==8
out={'schema':'CRAFT_R50_NOTION_FETCH_CONTENT_SHA256_V1',
 'date_local':'2026-10-23', 'scope':'MESTRE-SIDE_TEST_ONLY',
 'basis':'Direct fetch of 29 original Notion physical recipe pages in this execution, 3 groups of 9+10+10; SHA-256 of UTF-8 text inside <content> as returned by Notion connector, computed by independently vector-checked JavaScript SHA-256 implementation',
 'limit':'These are hashes of rendered enhanced Markdown content, NOT Notion native block bytes or linked images/files. This is first full-text digest baseline, NOT comparison with historical full-text digests, and does not certify correctness, authorization, RC5 or physical outcome.',
 'prior_metadata':'R44 29-source stamp/parent snapshot, matched by physical UUID/case key',
 'source_pages_count':29,'original_divergences':21,'lexically_unflagged':8,
 'material_evidence_R46_verified':0,'author_decisions_authenticated':0,
 'writes_to_recipe_pages':0,'rc5_approved':0,'party_release':False,
 'rows':records}
p=base/'data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json'
p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
q=base/'outputs/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.csv'
q.parent.mkdir(exist_ok=True)
with q.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print('R50 29/29 exact fetch <content> SHA-256 digests captured and linked to historical R44 metadata; no old body hash exists to compare')
