'use strict';
const assert=require('assert/strict');
const original=require('../data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json');
const {compareR50ContentSnapshots}=require('../src/r44_recipe_freshness');
let count=0;const ok=(expr,description)=>{assert.ok(expr,description);count++};
const eq=(a,b,description)=>{assert.deepEqual(a,b,description);count++};
const clone=x=>JSON.parse(JSON.stringify(x));
const b=original.rows;
ok(b.length===29,'29 physical rows');
ok(new Set(b.map(x=>x.physical_recipe_id)).size===29,'29 physical IDs unique');
ok(new Set(b.map(x=>x.case_key)).size===29,'29 case keys unique');
ok(b.every(x=>/^[a-f0-9]{64}$/.test(x.body_sha256)),'SHA256 shape');
ok(b.every(x=>x.source_text_truncated===false),'source text not truncated');
ok(b.every(x=>x.body_chars>100),'source body nonempty');
ok(b.filter(x=>x.case_key.startsWith('CLEAN-')).length===8,'8 without lexical issue');
ok(b.filter(x=>!x.case_key.startsWith('CLEAN-')).length===21,'21 with lexical issue');
let good=compareR50ContentSnapshots(b,clone(b));
eq(good.verdict,'NO_TEXT_OR_METADATA_DRIFT_IN_SUPPLIED_SNAPSHOTS','self match');
eq(good.sources_compared,29,'denominator');
eq(good.changed_fields,0,'no diff');
ok(!good.approved_for_write&&!good.rc5&&!good.party_release,'self-check not auth');
for(const row of b){ok(row.edited.startsWith('2026-10-02T'),'historical edit stamp');}
const adverse=[
 ['NO_COUNT',a=>a.pop(),'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['DUP_UUID',a=>a[0].physical_recipe_id=a[1].physical_recipe_id,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['DUP_KEY',a=>a[0].case_key=a[1].case_key,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['SWAP_UUID',a=>{let x=a[0].physical_recipe_id;a[0].physical_recipe_id=a[1].physical_recipe_id;a[1].physical_recipe_id=x},'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['KEY_UNKNOWN',a=>a[0].case_key='OTHER-RX','HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['DIGEST_CHANGED_SAME_DATE',a=>a[0].body_sha256='a'+a[0].body_sha256.slice(1),'HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['STAMP_CHANGED_SAME_BODY',a=>a[0].edited='2026-10-03T10:00:00.000Z','HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['PARENT_CHANGED',a=>a[0].parent='Different physical parent','HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['CHARCOUNT_CHANGED',a=>a[0].body_chars++,'HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['TRUNCATED',a=>a[0].source_text_truncated=true,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['MISSING_DIGEST',a=>delete a[0].body_sha256,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['MISSING_PARENT',a=>a[0].parent='','HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['FAKE_DATE',a=>a[0].edited='bad','HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['DIGEST_SHORT',a=>a[0].body_sha256='bb','HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['DIGEST_UPPER',a=>a[0].body_sha256=a[0].body_sha256.toUpperCase(),'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['ZERO_LEN',a=>a[0].body_chars=0,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK']
];
for(const[name,mut,verdict]of adverse){let x=clone(b);mut(x);const y=compareR50ContentSnapshots(b,x);eq(y.verdict,verdict,name);ok(!y.approved_for_write&&!y.rc5&&!y.party_release,name+' read-only');}
for(let i=0;i<29;i++){const x=clone(b);x[i].body_sha256=x[i].body_sha256.replace(/^./,x[i].body_sha256[0]==='f'?'a':'f');const v=compareR50ContentSnapshots(b,x);eq(v.verdict,'HOLD_SOURCE_CHANGE_REQUIRES_REVIEW','body changed '+i);ok(v.changed_fields>=1,'change logged '+i)}
const shuffled=clone(b).reverse();eq(compareR50ContentSnapshots(b,shuffled).verdict,'NO_TEXT_OR_METADATA_DRIFT_IN_SUPPLIED_SNAPSHOTS','ordering independent');
const badbase=clone(b);badbase[0].body_sha256='';eq(compareR50ContentSnapshots(badbase,b).verdict,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK','no old baseline digest');
console.log('R50 body SHA256 comparator TEST '+count+'/'+count+' PASS; self comparison is not live Notion re-fetch; RC5/PROD/PARTY HOLD');
