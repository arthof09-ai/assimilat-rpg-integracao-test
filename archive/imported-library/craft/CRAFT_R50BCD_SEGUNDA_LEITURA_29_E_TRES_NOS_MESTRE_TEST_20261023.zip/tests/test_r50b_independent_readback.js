'use strict';
const fs=require('fs'),assert=require('assert/strict');
const base=require('../data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json');
const compared=require('../outputs/CRAFT_R50B_COMPARE_29_RECIPES_MESTRE_TEST.json');
const {compareR50ContentSnapshots}=require('../src/r44_recipe_freshness');
let count=0;const check=(x,msg)=>{assert.ok(x,msg);count++};const eq=(x,y,msg)=>{assert.deepEqual(x,y,msg);count++};
const clones=x=>JSON.parse(JSON.stringify(x));
const live=compared.records.map(x=>({case_key:x.case_key,physical_recipe_id:x.physical_recipe_id,edited:x.observed_edited,parent:x.observed_parent,body_chars:x.observed_body_chars,body_sha256:x.observed_body_sha256,source_text_truncated:x.source_text_truncated}));
const original=base.rows;
check(compared.schema==='CRAFT_R50B_SECOND_FETCH_COMPARISON_TEST_V1','version');
check(compared.rc5===false&&compared.party_release===false&&compared.production_authorized===false,'no approvals');
check(live.length===29&&original.length===29,'full denominator');
check(new Set(live.map(x=>x.physical_recipe_id)).size===29,'unique live uuid');
check(new Set(live.map(x=>x.case_key)).size===29,'unique live case');
check(live.filter(x=>x.case_key.startsWith('CLEAN-')).length===8,'eight lexical-unflagged');
check(compared.changed_sources===0,'zero changes');
check(compared.identical_text_digests===29,'29 full digest matches');
const verdict=compareR50ContentSnapshots(original,live);
eq(verdict.verdict,'NO_TEXT_OR_METADATA_DRIFT_IN_SUPPLIED_SNAPSHOTS','fresh source content compared');
eq(verdict.sources_compared,29,'coverage');
eq(verdict.changed_fields,0,'zero drift');
check(!verdict.approved_for_write&&!verdict.rc5&&!verdict.party_release,'read-only');
for(let i=0;i<live.length;i++){
 eq(live[i].body_sha256,original.find(x=>x.case_key===live[i].case_key).body_sha256,'same sha '+i);
 eq(live[i].body_chars,original.find(x=>x.case_key===live[i].case_key).body_chars,'same body length '+i);
 const data=clones(live);data[i].body_sha256=data[i].body_sha256.replace(/./,data[i].body_sha256[0]==='a'?'b':'a');
 eq(compareR50ContentSnapshots(original,data).verdict,'HOLD_SOURCE_CHANGE_REQUIRES_REVIEW','tamper hash '+i);
}
const bad=[
 ['missing',a=>a.pop(),'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['duplicated uuid',a=>a[0].physical_recipe_id=a[1].physical_recipe_id,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['duplicated key',a=>a[0].case_key=a[1].case_key,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['edited',a=>a[0].edited='2026-10-23T18:00:00.000Z','HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['parent',a=>a[0].parent+=' modified','HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['length',a=>a[0].body_chars+=1,'HOLD_SOURCE_CHANGE_REQUIRES_REVIEW'],
 ['truncation',a=>a[0].source_text_truncated=true,'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['bad digest',a=>a[0].body_sha256='FAKE','HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK'],
 ['unknown identity',a=>a[0].case_key='R50B-UNKNOWN','HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK']
];
for(const [name,mut,want]of bad){let a=clones(live);mut(a);const v=compareR50ContentSnapshots(original,a);eq(v.verdict,want,name);check(!v.approved_for_write&&!v.rc5&&!v.party_release,'fail closed '+name)}
console.log('R50B independent live readback '+count+'/'+count+' PASS; 29 direct sources compared; no canonical writes or RC5');
