"""R50D: add 17 read-only first-layer category observations from Notion fetches in this turn."""
from pathlib import Path
import json,csv,hashlib,re
root=Path(__file__).resolve().parent
p=root/'outputs/CRAFT_R50D_REC_LIB_DESTINO_LEITURA_MESTRE_TEST.json'
x=json.loads(p.read_text())
rows=list(csv.DictReader((root/'data/R50D_ITENS_17_CATEGORIAS_READBACK_MESTRE_TEST.tsv').open(),delimiter='\t'))
assert len(rows)==17 and len({r['page_id'] for r in rows})==17
assert all(re.fullmatch('[a-f0-9]{32}',r['page_id']) for r in rows)
assert sum(int(r['embedded_page_links']) for r in rows)==384
assert all(int(r['exact_rec_lib_destination_page_links'])==0 for r in rows)
x.update({'first_layer_category_pages_live_fetched':17,
'first_layer_embedded_page_links_total':384,
'exact_rec_lib_destination_links_in_first_layer':0,
'first_layer_is_exhaustive_global_search':False,
'first_layer_note':'Each of 17 Itens-linked category/history/PS pages directly fetched; count of <page> embeds, not unique UUID census or exhaustive traversal of nested/archive roots.',
'search_nested_and_archive_still_pending':True,
'first_layer_source_tsv_sha256':hashlib.sha256((root/'data/R50D_ITENS_17_CATEGORIAS_READBACK_MESTRE_TEST.tsv').read_bytes()).hexdigest()})
p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print('R50D: 17/17 child pages checked; 384 links, no exact REC-LIB destination; GLOBAL ABSENCE UNKNOWN')
