# PSV — CRAFT R50 — Gate documental proporcional / MESTRE-SIDE TEST

**Escopo:** estabilização administrativa dos resultados R14–R49 no LAB/OP existentes; primeira captura criptográfica do texto retornado pelo Notion para 29 receitas; fortalecimento do comparador somente leitura.

## Evidência e condições de PASS

- Notion conta Mestre: duas atualizações documentais, duas leituras independentes; o mesmo ID de marcador 1/1 em cada página. R13 histórico mantido; IDs e SHA256 do ZIP R49 encontrados.
- 29 capturas diretas de páginas físicas por `fetch`, associadas aos 29 UUIDs de R41/R44, 29 SHA-256 do UTF-8 de `<content>`; algoritmo vetorizado com `abc` e `Olá 🌿`. Não há hash textual de antes do R50 — nenhuma conclusão retroativa de identidade de bytes.
- Extensão do comparador R44 rejeita digest modificado sem timestamp, corpora incompletos, UUID/key duplicado/remapeado, fonte truncada sinalizada e mudança de parent. Não autoriza automaticamente qualquer edição.
- Pacote, fonte e testes: conferir `MANIFEST-R50.json` e `replay_r50.py` no ZIP de distribuição. Qualquer discrepância = HOLD.

## Negativos obrigatórios

**PASS apenas de documento, captura digital textual e comparação em TEST.** R49 HTML foi preservado; nenhum Android físico foi testado por este PSV. Dados de amostra/hashes de corpo são serialização visível do conector, não prova interna de blocos Notion, não assinatura do Mestre, nem laudo empírico. C19-021/fencing, F5 RED, IBX38/116 ACK, R51/REC-LIB, RC5/P4/PROD/H2 e Party/O Primeiro permanecem HOLD. NAC-AUTO-01 segue PROPOSTA subordinada ao LONG-RUN-01 vigente.

## Resultado final medido em TEST

- `replay_r50.py` em extração limpa: 204/204 hashes, 31 suítes JS 1.898/1.898, QA/recibo/fuzz e outputs imutáveis PASS.
- Testes Chromium na mesma extração, três blocos: 24/24 suítes, 814/814 assertivas, nenhuma falha. Android físico NÃO validado.
- Verificador de snapshots R50 novo: 133/133 afirmações, incluídas na soma JS 1.898, nunca contado duplamente.
- A comparação de baseline com ele próprio foi apenas teste lógico; 29 leituras reais criaram o baseline inaugural em 23/10/2026. Não houve segundo dataset ao vivo depois disso.
- Gate proporcional: PASS de software TEST, hash do texto do conector e persistência documental; HOLD de autenticidade autoral, corpo Notion nativo, QA físico/mágico, RC5, writer/lease/fencing/recursos/Party.
