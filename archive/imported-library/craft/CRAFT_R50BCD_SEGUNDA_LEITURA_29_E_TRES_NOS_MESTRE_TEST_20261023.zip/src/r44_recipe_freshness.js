// R44 read-only Notion source metadata comparator. Equality of edit stamps is
// NOT a content hash, an authorization, physical RC5, or source identity proof.
'use strict';
function compareR44SourceStamps(baseline,live){
 const deny=(reason)=>({schema:'CRAFT_R44_NOTION_STAMP_COMPARE_TEST_V1',verdict:'HOLD_INCOMPLETE_READBACK',reason,approved_for_write:false,content_bytes_verified:false,rc5:false,party_release:false});
 const validRec=x=>x&&typeof x==='object'&&!Array.isArray(x)&&typeof x.case_key==='string'&&x.case_key.length>0&&/^[0-9a-f]{32}$/.test(x.physical_recipe_id)&&typeof x.edited==='string'&&!Number.isNaN(Date.parse(x.edited))&&typeof x.parent==='string'&&x.parent.trim();
 if(!Array.isArray(baseline)||!Array.isArray(live)||baseline.length!==29||live.length!==29||!baseline.every(validRec)||!live.every(validRec))return deny('COUNT_OR_SCHEMA');
 // R46: one physical recipe page per UUID. A duplicate in EITHER corpus is a
 // preflight failure, not a harmless flag under NO_TIMESTAMP_DRIFT_OBSERVED.
 if(new Set(baseline.map(c=>c.physical_recipe_id)).size!==29)return deny('DUPLICATE_BASE_PHYSICAL_ID');
 if(new Set(live.map(c=>c.physical_recipe_id)).size!==29)return deny('DUPLICATE_LIVE_PHYSICAL_ID');
 const a=new Map();for(const c of baseline){if(a.has(c.case_key))return deny('DUPLICATE_BASE_KEY');a.set(c.case_key,c)}
 const seen=new Set(),changed=[];
 for(const c of live){if(seen.has(c.case_key))return deny('DUPLICATE_LIVE_KEY');seen.add(c.case_key);
  const b=a.get(c.case_key);if(!b)return deny('UNKNOWN_KEY');
  if(c.physical_recipe_id!==b.physical_recipe_id)return deny('PHYSICAL_ID_CHANGED');
  if(c.edited!==b.edited||c.parent!==b.parent)changed.push({case_key:c.case_key,id:c.physical_recipe_id,
   change:c.parent!==b.parent?'PARENT_OR_NAME_DRIFT':'EDIT_STAMP_DRIFT',baseline_edit:b.edited,current_edit:c.edited,
   baseline_parent:b.parent,current_parent:c.parent});
 }
 if(seen.size!==29)return deny('MISSING_KEY');
 return {schema:'CRAFT_R44_NOTION_STAMP_COMPARE_TEST_V1',verdict:changed.length?'HOLD_SOURCE_DRIFT':'NO_TIMESTAMP_DRIFT_OBSERVED',
  source_pages_compared:29,physical_recipe_ids_unique:new Set(live.map(c=>c.physical_recipe_id)).size===29,
  edit_stamp_changes:changed.length,changed,
  strict_limitation:'Coincidência de edit stamp e parent NÃO atesta identidade de bytes, correção de receita ou homologação RC5.',
  source_body_hash_verified:false,approved_for_write:false,rc5:false,party_release:false,
  relink_suggested_automatically:false,recipe_modified:false};
}
if(typeof module!=='undefined'&&module.exports)module.exports={compareR44SourceStamps};

// R50 extension to the SAME read-only R44 source-audit module. Requires the
// 2026-10-23 Notion connector <content> text hash baseline. No writer gate.
function compareR50ContentSnapshots(baseline, readback){
 const deny=reason=>({schema:'CRAFT_R50_BODY_SNAPSHOT_COMPARE_TEST_V1',verdict:'HOLD_INCOMPLETE_OR_UNTRUSTED_READBACK',reason,approved_for_write:false,rc5:false,party_release:false});
 const valid=x=>x&&typeof x==='object'&&!Array.isArray(x)&&
  typeof x.case_key==='string'&&x.case_key.length>0&&
  typeof x.physical_recipe_id==='string'&&/^[a-f0-9]{32}$/.test(x.physical_recipe_id)&&
  typeof x.body_sha256==='string'&&/^[a-f0-9]{64}$/.test(x.body_sha256)&&
  Number.isInteger(x.body_chars)&&x.body_chars>0&&
  x.source_text_truncated===false&&
  typeof x.edited==='string'&&!Number.isNaN(Date.parse(x.edited))&&
  typeof x.parent==='string'&&x.parent.trim().length>0;
 if(!Array.isArray(baseline)||!Array.isArray(readback)||baseline.length!==29||readback.length!==29) return deny('INCOMPLETE_DENOMINATOR');
 if(!baseline.every(valid)||!readback.every(valid))return deny('INVALID_OR_TRUNCATED_CONTENT');
 const keys=a=>new Set(a.map(x=>x.case_key)),ids=a=>new Set(a.map(x=>x.physical_recipe_id));
 if(keys(baseline).size!==29||ids(baseline).size!==29)return deny('BASELINE_DUPLICATE_KEY_OR_UUID');
 if(keys(readback).size!==29||ids(readback).size!==29)return deny('LIVE_DUPLICATE_KEY_OR_UUID');
 const bmap=new Map(baseline.map(x=>[x.case_key,x]));const changes=[];
 for(const x of readback){const p=bmap.get(x.case_key);if(!p)return deny('UNKNOWN_SOURCE_KEY');
  if(p.physical_recipe_id!==x.physical_recipe_id)return deny('PHYSICAL_UUID_REMAPPED');
  for(const field of ['parent','edited','body_chars','body_sha256'])if(p[field]!==x[field])
   changes.push({case_key:x.case_key,physical_recipe_id:x.physical_recipe_id,field,previous:p[field],current:x[field]});
 }
 return{schema:'CRAFT_R50_BODY_SNAPSHOT_COMPARE_TEST_V1',
  verdict:changes.length?'HOLD_SOURCE_CHANGE_REQUIRES_REVIEW':'NO_TEXT_OR_METADATA_DRIFT_IN_SUPPLIED_SNAPSHOTS',
  sources_compared:29,changed_fields:changes.length,changes,
  comparison_scope:'SHA-256 UTF-8 Notion-enhanced-markdown <content>; metadata parent/edit stamp and JS char count; NOT Notion native blocks or images',
  evidence_limitation:'If readback is the baseline reused as both arguments, this is a SELF-CHECK, NOT a second live Notion fetch.',
  approved_for_write:false,rc5:false,party_release:false,author_decisions_authenticated:false};
}
if(typeof module!=='undefined'&&module.exports)module.exports.compareR50ContentSnapshots=compareR50ContentSnapshots;
