# CRAFT R50 — Fonte textual e sincronização documental segura

**Operação existente** OP-ARQ-RIN-REC-01 / LAB CRAFT, MESTRE-SIDE, TEST. R49 é o revisor funcional móvel vigente. R50 é uma extensão do **comparador de origem R44 existente**, não é motor/ficha/receita nova. O revisor HTML não foi alterado nesta etapa.

## Resultado

- O LAB e a OP existentes no Notion Mestre receberam **o mesmo marcador documental** `CRAFT-RETROSYNC-R14R49-20261023-001` e foram relidos (1 ocorrência por página). Isso registra custódia e estado retrospectivo, não promove R14–R49 a produção nem muda receitas.
- Acesso canônico `notion_update_page` ficou tecnicamente disponível nesta execução; isso é permissão de ferramenta para registro documental e **não demonstra** writer/lease/epoch/fencing de produção.
- 29/29 páginas físicas de receitas relidas em três lotes diretamente na conta Notion Mestre, com 29 impressões SHA-256 do UTF-8 do texto representado entre `<content>` e `</content>` do `fetch`. São 21 divergências históricas e 8 sem conflito lexical identificado. O conteúdo e IDs não foram modificados.
- `src/r44_recipe_freshness.js` passou a exportar `compareR50ContentSnapshots`, além do comparador de metadata R44. Ambos continuam **somente leitura**. O R50 exige 29 UUIDs únicos, key/parent/edit stamp/body length/SHA-256 válidos, rejeita truncamento sinalizado, e faz HOLD ante alteração ou corpus incompleto.
- A primeira amostra contra si mesma prova a integridade do verificador, não constitui segunda leitura de Notion, nem PASS de receita.

## Como reproduzir

`python replay_r50.py` testa arquivos do manifesto, valida corpus, roda testes JavaScript completos, valida QA/recibo e fuzz. `python replay_r50.py --full` acrescenta Chromium simulado, se Playwright/Chromium estiverem disponíveis. Para novos retornos Notion, compare o dataset **realmente obtido** contra `data/CRAFT_R50_NOTION_BODY_DIGEST_29_MESTRE_TEST.json`; não reutilize o baseline como se fosse uma captura nova.

O gerador `build_r50_snapshot.py` recompõe **somente a transcrição capturada em 23/10/2026**. Ele não faz novas chamadas Notion. Comparações futuras exigem novo fetch dos 29 UUIDs, seguindo o escopo de hash descrito em `snapshot_digest_spec.md`.

**Gates:** C19-021 UNKNOWN, F5 RED, IBX38/116 NOVA sem ACK, REC-LIB/R51 destino sem homologação, 50 perguntas sem decisões autenticadas, 3 nós sem laudo R46, 2 projetos HOLD_TEST_DESIGN, RC5/P4/PROD e Party/O Primeiro NO-WRITE. Browser Android físico não certificado.
