# R50 source-text snapshot rule (TEST)

The SHA-256 is calculated on UTF-8 bytes of the exact enhanced Markdown payload inside `<content>` returned by `mcp__Notion__fetch`. It is NOT a digest of Notion's internal block representation. A content hash mismatch indicates a need to inspect a potential change; it is not enough to determine authorization or semantic equivalence. Fetch metadata (`page_last_edited_at`) is retained separately. The hash does not cover images or any external linked content. Missing or truncated source MUST be HOLD.
