/* CRAFT-MOBILE-CAPTURE-20261021-001 — pure JS QA for existing PRE-Q2 contracts.
   Never authenticate evidence or authorize canonical writes. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.CraftMobileQA=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const VERSION='CRAFT-MOBILE-CAPTURE/1.2-TEST';
const SOURCES=Object.freeze({tli:'3f3c2b32-4ede-81ac-af28-c66a6b46e0b2',mica:'3f3c2b32-4ede-81e1-b179-e194e2838c84',cordao:'3f3c2b32-4ede-815a-b04a-ce5bd1074e79'});
const CONFIG={
 tli:{title:'B30-01 — Tábua Lamelar',numeric:{length_mm:[119,121],width_mm:[79,81],thickness_mm:[7.5,8.5],flatness_mm:[0,1],grid_mm:[9,11],groove_mm:[0,.5],marking_repeats:[3,null]},boolean:{cracks:false,delamination:false,sharp_edges:false,magic_detected:false}},
 mica:{title:'B30-03 — Par de Espaçadores',numeric:{piece_count:[2,2],length1_mm:[49,51],width1_mm:[19,21],length2_mm:[49,51],width2_mm:[19,21],thickness_difference_mm:[0,.1]},boolean:{loose_lamellae:false,cracks:false,mount_fit:true,magic_detected:false}},
 cordao:{title:'B30-02 — Cordão de Casca Boreal',numeric:{length_cm:[95,105]},boolean:{frayed_knots:false,magic_detected:false},observations:['fiber_input_m','break_load_N','test_load_N','elongation_pct']}
};
const safeText=v=>typeof v==='string'?v.trim():'';
const numeric=v=>typeof v==='number'&&Number.isFinite(v)&&!Object.is(v,-0);
function evaluate(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('REGISTRO_INVALIDO');
 const type=input.type, c=CONFIG[type];if(!c)throw Error('TIPO_INVALIDO');
 const m=input.measurements||{},u=input.uncertainty_mm;
 const notes=[],fail=[],ambiguous=[],missing=[];
 for(const [key,[lo,hi]] of Object.entries(c.numeric)){
   const v=m[key];if(v===null||v===undefined||v===''){missing.push(key);continue;}
   if(!numeric(v)){fail.push(key+':not_finite_number');continue;}
   if(v<0||(!['thickness_difference_mm','flatness_mm','groove_mm'].includes(key)&&v===0)){fail.push(key+':non_positive');continue;}
   if(key==='piece_count'||key==='marking_repeats'){
      if(!Number.isInteger(v)){fail.push(key+':non_integer');continue;}
      if(v<lo||(hi!==null&&v>hi))fail.push(key+':out_of_proposed_range');
      continue;
   }
   // Conservative guard band: point outside but uncertainty overlaps tolerance => INDETERMINATE.
   // Do not treat synthetic ±u as authenticated instrument accuracy.
   const validU=numeric(u)&&u>=0;
   const effectiveU=validU?(key==='thickness_difference_mm'?2*u:(key==='length_cm'?u/10:u)):null;
   const below=v<lo, above=hi!==null&&v>hi;
   const whollyOutside=validU&&((below&&v+effectiveU<lo)||(above&&v-effectiveU>hi));
   const outsideWithoutU=(below||above)&&!validU;
   if(whollyOutside){fail.push(key+':out_of_proposed_range');continue;}
   if(outsideWithoutU){ambiguous.push(key+':uncertainty_missing_outside');continue;}
   if(!validU)continue;
   // Crossings of strictly physical zero lower bound are not false measurement failures.
   const lowerBoundCrosses=lo>0&&v-effectiveU<lo;
   const upperBoundCrosses=hi!==null&&v+effectiveU>hi;
   if(lowerBoundCrosses||upperBoundCrosses||below||above)ambiguous.push(key+':uncertainty_crosses_boundary');
 }
 for(const [key,expected] of Object.entries(c.boolean)){
   if(typeof m[key]!=='boolean')missing.push(key);
   else if(m[key]!==expected)fail.push(key+':failed_flag');
 }
 if(type==='cordao'){
  for(const name of c.observations){const v=m[name];if(v!==null&&v!==undefined&&( !numeric(v)||v<0))fail.push(name+':not_finite_number');}
  if(numeric(m.test_load_N)&&numeric(m.break_load_N)&&m.break_load_N<m.test_load_N)notes.push('RUPTURA_ANTES_DA_CARGA_DE_TESTE_DECLARADA');
  notes.push('CARGA_DE_SERVICO_NAO_HOMOLOGADA');
 }
 if(type==='mica'&&numeric(m.thickness1_mm)&&numeric(m.thickness2_mm)){
   if(Math.abs(Math.abs(m.thickness1_mm-m.thickness2_mm)-m.thickness_difference_mm)>0.0000001)fail.push('thickness_difference_mm:not_equal_to_measured_pieces');
 } else if(type==='mica'){missing.push('thickness1_mm/thickness2_mm');}
 if(!numeric(u)||u<0)notes.push('INCERTEZA_INSTRUMENTAL_NAO_REGISTRADA');
 if(!safeText(input.sample_id))missing.push('sample_id');
 if(!safeText(input.lot_id))missing.push('lot_id');
 if(!safeText(input.instrument_id))missing.push('instrument_id');
 if(!safeText(input.operator))missing.push('operator');
 if(!safeText(input.calibration_reference))missing.push('calibration_reference');
 if(!safeText(input.date_time))missing.push('date_time');
 if(input.process_minutes!==null&&input.process_minutes!==undefined&&!numeric(input.process_minutes))fail.push('process_minutes:not_finite_number');
 else if(numeric(input.process_minutes)&&input.process_minutes<0)fail.push('process_minutes:negative');
 if(input.claimed_is_actual!==true)notes.push('REGISTRO_DEMONSTRATIVO_OU_NAO_ATESTADO');
 if(input.claimed_is_actual===true)notes.push('MEDICAO_DECLARADA_PELO_OPERADOR_NAO_AUTENTICADA');
 let status='WITHIN_PROPOSED_TOLERANCE';
 if(missing.length||fail.some(x=>x.endsWith('not_finite_number')||x.endsWith(':negative')||x.endsWith(':non_positive')||x.endsWith(':non_integer')))status='INCOMPLETE_OR_INVALID';
 else if(fail.length)status='OUTSIDE_PROPOSED_TOLERANCE';
 else if(ambiguous.length||!numeric(u)||u<0)status='INDETERMINATE_UNCERTAINTY';
 else if(type==='cordao')status='NO_HOMOLOGATED_LOAD_THRESHOLD';
 return {schema:VERSION,type,source_id:SOURCES[type],status,flags:{missing:[...new Set(missing)],fail,ambiguous,notes},authority:'SELF_DECLARED_REQUIRES_INDEPENDENT_REVIEW',physical_verified:false,rc5:false,production_authorized:false,limits:'TOLERANCIAS_PRE_Q2_PROPOSTAS_SEM_GREEN'};
}
function validateBatch(records){if(!Array.isArray(records))throw Error('BATCH_NOT_ARRAY');const keys=new Set(),out=[];
 for(const r of records){if(!r||typeof r!=='object'||Array.isArray(r))throw Error('INVALID_RECORD');const key=JSON.stringify([r.type,safeText(r.lot_id),safeText(r.sample_id)]);if(keys.has(key))throw Error('DUPLICATE_SAMPLE');keys.add(key);out.push({record:r,evaluation:evaluate(r)});}
 return out;
}
function groupSummary(records){const out={};for(const x of validateBatch(records)){const key=x.record.type+'|'+(x.record.comparator?'CONTROL':'CANDIDATE');const v=out[key]||(out[key]={n:0,within:0,outside:0,indeterminate:0,incomplete:0});v.n++;const s=x.evaluation.status;if(s==='WITHIN_PROPOSED_TOLERANCE')v.within++;else if(s==='OUTSIDE_PROPOSED_TOLERANCE')v.outside++;else if(s==='INDETERMINATE_UNCERTAINTY'||s==='NO_HOMOLOGATED_LOAD_THRESHOLD')v.indeterminate++;else v.incomplete++;}return {groups:out,comparison:'DESCRITIVO_APENAS_NAO_SUPERIORIDADE_NEM_EFICACIA'};}
// Read-only common audit used by both Android review and Node wrapper.
function stable(x){if(Array.isArray(x))return x.map(stable);if(x&&typeof x==='object')return Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]));return x;}
const same=(a,b)=>JSON.stringify(stable(a))===JSON.stringify(stable(b));
function auditPortable(payload){
 if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_PAYLOAD');
 if(!['CRAFT-MOBILE-CAPTURE/1.0-TEST','CRAFT-MOBILE-CAPTURE/1.1-TEST',VERSION].includes(payload.schema))throw Error('SCHEMA_NOT_SUPPORTED');
 if(payload.official_writes!==0)throw Error('OFFICIAL_WRITES_CLAIM_CONFLICT');
 if(!Array.isArray(payload.records)||payload.records.length>3000)throw Error('INVALID_RECORDS');
 const issues=[],seen=new Set(),samePhysical=new Map(),recomputed=[];
 if(payload.data_origin!=='SELF_DECLARED_OFFLINE_NO_NOTION_SYNC')issues.push({index:null,reason:'DATA_ORIGIN_CHANGED_OR_MISSING'});
 for(const key of ['rc5','physical_verified','production_authorized','writer_green','notion_write','party_write','independence_verified']){
  if(payload[key]===true)issues.push({index:null,reason:'UNVERIFIED_AUTHORITY_CLAIM_'+key.toUpperCase()});
 }
 for(let i=0;i<payload.records.length;i++){
  const entry=payload.records[i];
  if(!entry||typeof entry!=='object'||Array.isArray(entry)||!entry.record){issues.push({index:i,reason:'MALFORMED_ENTRY'});continue;}
  const r=entry.record;
  let evaluation;
  try{evaluation=evaluate(r);}catch(err){issues.push({index:i,reason:'RECORD_INVALID_'+err.message});continue;}
  const key=JSON.stringify([r.type,r.lot_id,r.sample_id]);
  if(seen.has(key))issues.push({index:i,reason:'DUPLICATE_SAMPLE'});
  seen.add(key);
  const physical=JSON.stringify([r.type,r.sample_id]);
  if(samePhysical.has(physical)&&samePhysical.get(physical)!==r.lot_id)issues.push({index:i,reason:'SAMPLE_ID_REUSED_CROSS_LOTS_INDEPENDENCE_UNKNOWN'});
  else samePhysical.set(physical,r.lot_id);
  for(const field of ['rc5','physical_verified','production_authorized','writer_green','notion_write','party_write','independence_verified']){
   if(r[field]===true)issues.push({index:i,reason:'UNVERIFIED_RECORD_AUTHORITY_'+field.toUpperCase()});
  }
  if(r.source_id!==undefined&&r.source_id!==evaluation.source_id)issues.push({index:i,reason:'SOURCE_ID_CONFLICT'});
  const prior=entry.evaluation&&typeof entry.evaluation==='object'?{...entry.evaluation}:entry.evaluation;
  // Only source-version marker is comparable as historical metadata, never as a policy override.
  if(prior&&payload.schema!==VERSION&&prior.schema===payload.schema)prior.schema=VERSION;
  if(!same(prior,evaluation))issues.push({index:i,reason:'EVALUATION_MISMATCH'});
  recomputed.push({record:r,evaluation_recomputed:evaluation});
 }
 let summary;
 try{summary=groupSummary(recomputed.map(z=>z.record));}catch(e){issues.push({index:null,reason:'SUMMARY_INVALID_'+e.message});summary={groups:{}};}
 if(!payload.summary)issues.push({index:null,reason:'SUMMARY_MISSING'});
 else if(!same(payload.summary,summary))issues.push({index:null,reason:'SUMMARY_MISMATCH'});
 return {schema:'CRAFT-MOBILE-REVIEW/1.2-TEST',input_schema:payload.schema,record_count:payload.records.length,recomputed_count:recomputed.length,issues,summary,review_status:issues.length?'REVIEW_QUARANTINE':'REVIEW_REQUIRED_NO_AUTOCANON',authority:'SELF_DECLARED_NEEDS_INDEPENDENT_WITNESS',physical_verified:false,independence_verified:false,official_writes:0,rc5_created:0,production_authorized:false,notion_write:false,party_write:false,records:recomputed};
}
function csvEscape(value){
 let s=String(value??'');
 // Spreadsheet importers sometimes execute untrusted cells beginning with formulas.
 if(/^[\s]*[=+@-]/.test(s) && !/^-?\d+(?:[.,]\d+)?$/.test(s)) s="'"+s;
 return '"'+s.replaceAll('\"','\"\"')+'"';
}
function toCSV(records){
 const data=validateBatch(records);const keys=[...new Set(records.flatMap(x=>Object.keys(x.measurements||{})))].sort();
 const cols=['evidence_status','source_id','type','sample_id','lot_id','operator','instrument_id','calibration_reference','date_time','witness','notes','process_minutes','uncertainty_mm','claimed_is_actual','comparator','qa_status','authority','physical_verified','rc5','production_authorized','independence_verified','official_writes',...keys];
 const rows=[cols.map(csvEscape).join(',')];
 for(const {record:r,evaluation:e} of data)rows.push(cols.map(k=>csvEscape(k==='evidence_status'?'TEST_ONLY_SELF_DECLARED':k==='qa_status'?e.status:k==='source_id'?e.source_id:k==='authority'?e.authority:k==='physical_verified'||k==='rc5'||k==='production_authorized'?false:k==='independence_verified'?false:k==='official_writes'?0:Object.prototype.hasOwnProperty.call(r,k)?r[k]:r.measurements[k])).join(','));
 return rows.join('\r\n')+'\r\n';
}
function portableExport(records){return {schema:VERSION,created_at:new Date().toISOString(),data_origin:'SELF_DECLARED_OFFLINE_NO_NOTION_SYNC',official_writes:0,records:validateBatch(records).map(x=>x),summary:groupSummary(records),flags:['PARTY_NO_WRITE','F5_RED','C19_021_UNKNOWN','RC5_HOLD','EXTERNAL_VALIDATION_PENDING']};}
return {VERSION,SOURCES,CONFIG,evaluate,validateBatch,groupSummary,auditPortable,portableExport,toCSV};
});
