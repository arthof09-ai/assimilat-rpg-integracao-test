#!/usr/bin/env python3
"""Verify R6 ZIP structure, SHA manifest and preserved R5 baseline, no writes to RPG."""
import hashlib,json,sys,zipfile
from pathlib import PurePosixPath
from pathlib import Path
REQUIRED=['logic.js','r46_predossier.js','r46_predossier_cli.js','CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html','run_replay_r6.py','baseline/CRAFT_R5_BANCADA_ANDROID_V12_REVIEW_20261021.zip']
R5_SHA='29b4bfb61a726bd4e12bffa8e245552831003ca5f3e1b7e4f5edcbd7f65eb6e8'
QA_SHA='a346889dd1cc59826d7d0ce24a16a9444d7587d316f63eccd1034dfc8be6e484'
def sha(x):return hashlib.sha256(x).hexdigest()
def verify(path):
 with zipfile.ZipFile(path) as z:
  files=[n for n in z.namelist() if not n.endswith('/')]
  if len(set(files))!=len(files) or any(n.startswith('/') or '\\' in n or '..' in PurePosixPath(n).parts for n in files):raise ValueError('UNSAFE_ZIP_PATH')
  bad=z.testzip()
  if bad:raise ValueError('ZIP_CRC_FAIL '+bad)
  declared=json.loads(z.read('MANIFEST-SHA256.json'))['files']
  if set(files)!=(set(declared)|{'MANIFEST-SHA256.json'}):raise ValueError('MANIFEST_SET_MISMATCH')
  for name,h in declared.items():
   if sha(z.read(name))!=h:raise ValueError('MANIFEST_HASH_MISMATCH '+name)
  if any(x not in files for x in REQUIRED):raise ValueError('MISSING_REQUIRED_FILE')
  if sha(z.read('logic.js'))!=QA_SHA:raise ValueError('R5_QA_WAS_MODIFIED')
  if sha(z.read('baseline/CRAFT_R5_BANCADA_ANDROID_V12_REVIEW_20261021.zip'))!=R5_SHA:raise ValueError('R5_BASELINE_WAS_MODIFIED')
  html=z.read('CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html')
  if z.read('logic.js') not in html or z.read('r46_predossier.js') not in html:raise ValueError('UI_DIFFERENT_FROM_AUDITED_SOURCE')
  for forbidden in (b'XMLHttpRequest(',b'fetch(',b'sendBeacon(',b'import(',b'<script src='):
   if forbidden in html:raise ValueError('NETWORK_OR_DYNAMIC_DEPENDENCY')
 print('R6_RELEASE_INTEGRITY_PASS',len(files),'files',len(declared),'manifest',sha(Path(path).read_bytes()),'QA_BASELINE_PINNED','R5_ZIP_PINNED')
if __name__=='__main__':verify(sys.argv[1])
