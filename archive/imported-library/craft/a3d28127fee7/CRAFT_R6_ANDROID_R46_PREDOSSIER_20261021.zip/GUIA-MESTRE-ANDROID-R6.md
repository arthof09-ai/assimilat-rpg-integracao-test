# CRAFT — evolução v1.3: pré-dossiê para laboratório R46

**MESTRE-SIDE · TEST · LOCAL · SEM CANONIZAÇÃO.** A página continua a bancada offline anterior. O mesmo avaliador `logic.js` v1.2 foi preservado **byte por byte**. A nova função é uma *ponte documental*, não novo motor R45/R46 ou schema nativo de laudo.

## No celular Android

1. Abra `CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html` no navegador compatível e registre as medidas pelos campos existentes. O teste automatizado usa Chromium móvel, mas não comprova abertura `file://` em todos os aparelhos Android.
2. Exporte normalmente o JSON das medidas na seção 3. Guarde-o na área Mestre.
3. Na seção 5, toque em **Exportar pré-dossiê R46**. A página extrai os dados já existentes de **B30-01 Tábua** e **B30-03 Mica**; registros do **B30-02 Cordão** aparecem como excluídos, pois o contrato experimental R46 citado não inclui Cordão.
4. Salve o arquivo `CRAFT_R46_PRE_DOSSIE_NAO_NATIVO_*.json`. O arquivo contém campos de identidade, observações em mm/count/bool, referências **declaradas**, ausência explícita de certificado, prova de horário com fuso, custódia, anexos primários, assinaturas e revisão independente. **Não é um relatório R46 válido para ingestão nativa**: `report_id=null`, `recipe_key=null`, `r46_import_ready=false`, `physical_measurement_verified=false`, `stock_effect=0`.
5. Para revisão por especialista, envie separadamente o JSON original, as fotos/bytes primários, certificados e cadeia de custódia reais. O especialista deve reconstruir o relatório no schema verdadeiro R46 e submetê-lo ao processo canônico; jamais renomear o pré-dossiê como laudo aprovado.

**Nota:** as datas inseridas pelo `<input type="datetime-local">` não carregam fuso. A ponte preserva `observed_at_local_claim`, porém mantém `observed_at=null` e `observation_timezone_verified=null`. Não fabrica horário UTC. Instrumentos/calibrações são autorrelato e não comprovação.

## Para testes de engenharia fora do celular

Execute `python run_replay_r6.py` no ZIP extraído com Node, Chromium e Playwright instalados. O CLI facultativo `node r46_predossier_cli.js origem.json saida.json` emprega o mesmo transformador da página. O usuário Android **não precisa** de Node nem Python.

## Segurança e limites

O arquivo não sincroniza com Notion, Party ou O Primeiro. Não contém código de produção, movimentação de estoque ou magia. Ainda requer F5/C19, R51, autorização e todas as provas externas para qualquer etapa material. Não fornece credencial de laboratório, assinaturas ou autenticação física. Os testes e arquivos de exemplo são 100% sintéticos.

**Controle comum:** se a amostra for um comparador comum, o pré-dossiê não copia para ela a origem PS da Tábua/Mica. Os campos `source_page_id`/`source_crn_id` ficam nulos e a procedência do controle continua pendente.
