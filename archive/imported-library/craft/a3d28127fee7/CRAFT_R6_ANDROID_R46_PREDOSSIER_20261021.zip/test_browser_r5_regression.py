from playwright.sync_api import sync_playwright
from pathlib import Path
import json
HTML=Path(__file__).with_name('CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html').read_text()

def fill_common(page, sample):
    page.locator('#sample').fill(sample)
    page.locator('#lot').fill('L-TST')
    page.locator('#operator').fill('OPERADOR TESTE')
    page.locator('#instrument').fill('MICRO TESTE')
    page.locator('#calibration').fill('CAL-TEST')
    page.locator('#uncertainty').fill('0')

def mark_inspections(page, expected):
    for key,value in expected.items():
        page.locator('#q_'+key).select_option('yes' if value else 'no')

def main():
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':390,'height':844},accept_downloads=True)
        page=context.new_page()
        errors=[]
        page.on('pageerror',lambda exc:errors.append(str(exc)))
        page.set_content(HTML,wait_until='load')
        assert page.locator('h1').inner_text()=='CRAFT · Bancada de medições v1.3'
        assert page.locator('#measurements input').count()==7
        for w in [320,360,390,412,768]:
            page.set_viewport_size({'width':w,'height':844})
            assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'),w
        page.set_viewport_size({'width':390,'height':844})
        fill_common(page,'T1')
        values={'length_mm':120,'width_mm':80,'thickness_mm':8,'flatness_mm':0.5,'grid_mm':10,'groove_mm':0.2,'marking_repeats':3}
        for key,value in values.items():page.locator('#m_'+key).fill(str(value))
        page.locator('#preview').click()
        assert 'INCOMPLETE OR INVALID' in page.locator('#assessment').inner_text()
        mark_inspections(page, {'cracks':False,'delamination':False,'sharp_edges':False,'magic_detected':False})
        page.locator('#preview').click()
        assert 'WITHIN PROPOSED TOLERANCE' in page.locator('#assessment').inner_text()
        page.locator('#add').click()
        assert 'T1' in page.locator('#records').inner_text()
        page.locator('#add').click()
        assert 'DUPLICATE_SAMPLE' in page.locator('#assessment').inner_text()
        page.locator('#kind').select_option('mica')
        assert page.locator('#measurements input').count()==8
        fill_common(page,'M1')
        for key,value in {'piece_count':2,'length1_mm':50,'width1_mm':20,'length2_mm':50,'width2_mm':20,'thickness1_mm':1.0,'thickness2_mm':1.05,'thickness_difference_mm':0.05}.items():page.locator('#m_'+key).fill(str(value))
        mark_inspections(page,{'loose_lamellae':False,'cracks':False,'mount_fit':True,'magic_detected':False})
        page.locator('#add').click()
        assert 'M1' in page.locator('#records').inner_text()
        page.locator('#kind').select_option('cordao')
        fill_common(page,'C1')
        for key,value in {'length_cm':100,'fiber_input_m':2,'break_load_N':80,'test_load_N':50,'elongation_pct':10}.items():page.locator('#m_'+key).fill(str(value))
        mark_inspections(page,{'frayed_knots':False,'magic_detected':False})
        page.locator('#preview').click()
        assert 'NO HOMOLOGATED LOAD THRESHOLD' in page.locator('#assessment').inner_text()
        page.locator('#add').click()
        assert 'C1' in page.locator('#records').inner_text()
        with page.expect_download() as download:
            page.locator('#exportJson').click()
        path=Path(__file__).parent/'export_test.json'
        download.value.save_as(str(path))
        obj=json.loads(path.read_text())
        assert obj['schema']=='CRAFT-MOBILE-CAPTURE/1.2-TEST'
        assert len(obj['records'])==3
        assert obj['official_writes']==0
        assert all(not z['evaluation']['physical_verified'] for z in obj['records'])
        with page.expect_download() as download:
            page.locator('#exportCsv').click()
        csvpath=Path(__file__).parent/'export_test.csv'
        download.value.save_as(str(csvpath))
        assert csvpath.read_text().count('\n')==4
        # Read-only audit on the SAME Android page: valid file does not add records.
        count_before=page.locator('#records .record').count()
        page.locator('#reviewFile').set_input_files(str(path))
        page.wait_for_function("document.querySelector('#reviewStatus').textContent.includes('REVISÃO LOCAL')")
        assert 'REVIEW_REQUIRED_NO_AUTOCANON' in page.locator('#reviewStatus').inner_text()
        assert page.locator('#records .record').count()==count_before
        assert page.locator('#reviewExport').is_enabled()
        with page.expect_download() as download:
            page.locator('#reviewExport').click()
        reviewpath=Path(__file__).parent/'review_result.json'
        download.value.save_as(str(reviewpath))
        rev=json.loads(reviewpath.read_text())
        assert rev['record_count']==3 and rev['physical_verified']==False and rev['notion_write']==False
        # Tampered export: a changed dimension and stale evaluation must be quarantined.
        tampered=json.loads(path.read_text())
        tampered['records'][0]['record']['measurements']['length_mm']=145
        dirty=Path(__file__).parent/'tampered_test.json';dirty.write_text(json.dumps(tampered))
        page.locator('#reviewFile').set_input_files(str(dirty))
        page.wait_for_function("document.querySelector('#reviewStatus').textContent.includes('REVIEW_QUARANTINE')")
        assert 'EVALUATION_MISMATCH' in page.locator('#reviewStatus').inner_text()
        assert page.locator('#records .record').count()==count_before
        # Import of tampered file is rejected and keeps the current three records unchanged.
        page.locator('#importFile').set_input_files(str(dirty))
        page.wait_for_function("document.querySelector('#assessment').textContent.includes('IMPORTAÇÃO REJEITADA')")
        assert 'Arquivo em quarentena' in page.locator('#assessment').inner_text()
        assert page.locator('#records .record').count()==count_before
        page.locator('#importFile').set_input_files(str(path))
        page.wait_for_function("document.querySelector('#assessment').textContent.includes('DUPLICATE_SAMPLE')")
        assert 'DUPLICATE_SAMPLE' in page.locator('#assessment').inner_text()
        page.screenshot(path=str(Path(__file__).parent/'screenshot_two_samples.png'),full_page=True)
        assert not errors,errors
        browser.close()
        print('BROWSER_E2E_PASS','mobile390','TLI+MICA+CORDAO','review_same_screen','tamper_quarantine','add','duplicate_rejected','JSON_CSV_export','import_duplicate_rejected','no_JS_errors','no_overflow')
if __name__=='__main__':main()
