# Protocolo de execução interna contínua — CRAFT R6 (MESTRE-SIDE)

Este protocolo foi preparado para a sequência atual de trabalho e não substitui BOOTSTRAP-COMESTRE, NAC-CONT-03, NAC-NORM-01, NAC-PASS, REC-LIB-01 ou ordens do Mestre.

1. Reabrir o último checkpoint nativo, as fontes Mestre e a Inbox CRAFT antes de afirmar continuidade.
2. Verificar artefatos anteriores pelo SHA/readback e preservar versões históricas; executar regressões apenas em cópias.
3. Distinguir VERIFICADO, INFERIDO, PROPOSTO e PENDENTE, explicitando a autoridade de cada dado.
4. Desambiguar pendência material versus digital. Resolver apenas a que possua requisitos demonstráveis e não tenha sido já concluída.
5. Priorizar função utilizável no celular e integração com motor canônico, não novo motor ou duplicação de receita.
6. Criar checkpoint ANTES, rodar implementação e testes; rejeitar correções que reduzam invariantes.
7. Garantir, para R6, que logic.js permaneça byte-idêntico a R5; ponte ao R46 NÃO faz laudo nativo nem atestado.
8. Extrair em diretório limpo, testar SHA/manifesto, Node, Chromium e CLI/browser; validar negativos e sinais de autoridade falsos.
9. Persistir no mesmo LAB/OP/IBX e Biblioteca Mestre usando ID existente quando for versão do mesmo objeto; nunca tocar Party/O Primeiro.
10. Publicar checkpoint DEPOIS após readback com alcance proporcional; manter F5 P0 RED/C19 UNKNOWN, REC-LIB e P2 em HOLD; continuar por outra frente independente se existir sem inventar trabalho.

Nenhum requisito de duração autoriza prometer trabalho assíncrono, relatar tempo fictício ou manter escrita após o fim da sessão. Proteger os pontos de retomada.
