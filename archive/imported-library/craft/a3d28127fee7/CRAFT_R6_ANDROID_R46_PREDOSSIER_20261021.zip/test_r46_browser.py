from playwright.sync_api import sync_playwright
from pathlib import Path
import json
BASE=Path(__file__).parent
HTML=(BASE/'CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html').read_text()

def main():
 with sync_playwright() as pw:
  br=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  context=br.new_context(viewport={'width':390,'height':844},accept_downloads=True)
  page=context.new_page();errors=[]
  page.on('pageerror',lambda err:errors.append(str(err)))
  page.set_content(HTML,wait_until='load')
  assert 'v1.3' in page.locator('h1').inner_text()
  assert page.locator('#exportR46').is_visible()
  assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
  page.locator('#exportR46').click()
  assert 'EMPTY_SESSION' in page.locator('#r46Status').inner_text()
  # Existing trusted TEST JSON: its three rows carry two applicable source families.
  payload=BASE/'evidencia-sintetica/export_test.json'
  page.locator('#importFile').set_input_files(str(payload))
  page.wait_for_function("document.querySelector('#assessment').textContent.includes('IMPORTAÇÃO LOCAL')")
  assert page.locator('#records .record').count()==3
  with page.expect_download() as dl:page.locator('#exportR46').click()
  out=BASE/'evidencia-sintetica/r46_pre_dossier_browser.json'
  dl.value.save_as(str(out))
  data=json.loads(out.read_text())
  assert data['report_count']==2 and data['excluded_count']==1
  assert data['review_status']=='QUARANTINE_INCOMPLETE_NO_AUTOCANON'
  assert not data['notion_write'] and not data['physical_measurement_verified']
  assert all(x['report_id'] is None and x['observed_at'] is None and x['artifacts']==[] for x in data['reports'])
  assert 'QUARENTENA R46' in page.locator('#r46Status').inner_text()
  assert page.locator('#records .record').count()==3
  assert not errors,errors
  br.close()
  print('R46_MOBILE_BROWSER_E2E_PASS','390x844','R46 2 DRAFT 1 EXCLUDED','NO_NATIVE_OR_OFFICIAL_WRITE')
if __name__=='__main__':main()
