/* CRAFT-R6: Mobile R46 pre-dossier staging ONLY. No native R46 ingestion or certification.
   Reuse the existing QA module, never implement a second metrology engine. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.CraftR46PreDossier=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const SCHEMA='CRAFT-R46-PREDOSSIER/1.0-TEST-NONNATIVE';
const R46_TYPES=Object.freeze({tli:{family:'R44_TLI',crn:'CRAFT-F5-R01-MIN-01'},mica:{family:'R44_MICA',crn:'CRAFT-F5-R01-MIN-02'}});
const REQUIRED_EXTERNAL=Object.freeze([
 'R46_NATIVE_REPORT_ID_BY_AUTHORIZED_REVIEWER',
 'R46_NATIVE_RECIPE_KEY_AND_SCHEMA_CHECK',
 'SOURCE_LOT_PROVENANCE_AND_QUANTITY_EXTERNAL_PROOF',
 'OPERATOR_IDENTITY_COMPETENCE_AND_ATTESTATION',
 'INSTRUMENT_SERIAL_AND_TRACEABLE_CALIBRATION_CERTIFICATE_BYTES',
 'CALIBRATION_START_END_SCOPE_AND_UNCERTAINTY_FLOOR',
 'TIMEZONE_VERIFIED_OBSERVATION_TIMESTAMP',
 'TEST_CONDITIONS_AND_PRE_REGISTERED_METHOD',
 'SAMPLE_CUSTODY_EVENTS_WITH_VERIFIABLE_ACTORS_AND_BYTES',
 'FOUR_PRIMARY_ATTACHMENT_BYTESETS_AND_SHA256',
 'INDEPENDENT_REVIEW_AND_AUTHORITY_DECISION'
]);
const MM_KEYS=new Set(['length_mm','width_mm','thickness_mm','flatness_mm','grid_mm','groove_mm','length1_mm','width1_mm','length2_mm','width2_mm','thickness1_mm','thickness2_mm','thickness_difference_mm']);
const COUNT_KEYS=new Set(['marking_repeats','piece_count']);
function kindOf(key,value){if(typeof value==='boolean')return 'bool';if(MM_KEYS.has(key))return 'mm';if(COUNT_KEYS.has(key))return 'count';return null;}
function readingId(r,k){return 'DRAFT-READ:'+['type','lot_id','sample_id'].map(z=>encodeURIComponent(String(r[z]))).join(':')+':'+encodeURIComponent(k);}
function mapOne(r,ev){const info=R46_TYPES[r.type];if(!info)throw Error('UNSUPPORTED_R46_FAMILY');
 const readings=[];
 for(const [name,value] of Object.entries(r.measurements||{})){
  if(value===null||value===undefined||value==='')continue;
  const unit=kindOf(name,value);if(!unit)continue;
  readings.push({draft_reading_id:readingId(r,name),measurement_name:name,value,unit,uncertainty_abs_declared:unit==='mm'&&Number.isFinite(r.uncertainty_mm)?(name==='thickness_difference_mm'?2*r.uncertainty_mm:r.uncertainty_mm):null,uncertainty_verified:false,instrument_id_declared:r.instrument_id||null,observed_at_verified:null,derived:name==='thickness_difference_mm'});
 }
 return {
  schema:SCHEMA, r46_native_schema:false,r46_import_ready:false,
  report_id:null,recipe_key:null,recipe_family_candidate:info.family,
  source_page_id:r.comparator?null:(r.source_id||ev.source_id),source_crn_id:r.comparator?null:info.crn,
  source_id_claim_from_mobile:ev.source_id,control_material_provenance_required:!!r.comparator,source_id_verified_by_operator:false,
  sample_id:r.sample_id,lot_ids:[r.lot_id],lot_quantity_verified:null,
  evidence_kind:r.claimed_is_actual===true?'OPERATOR_SELF_DECLARED_NOT_AUTHENTICATED':'DEMONSTRATION_OR_UNATTESTED',
  operator:{declared_name:r.operator||null,identity_verified:false,competence_verified:false,signature:null},
  instrument:{declared_id:r.instrument_id||null,declared_calibration_reference:r.calibration_reference||null,serial:null,certificate_bytes_sha256:null,calibration_start:null,calibration_end:null,calibration_scope:null,traceable_uncertainty_floor:null},
  observed_at:null,observed_at_local_claim:r.date_time||null,observation_timezone_verified:null,
  submitted_at:null,conditions:null,
  custody:[],artifacts:[],observations:readings,
  witness_claim:r.witness||null,comparator_declared:!!r.comparator,
  source_proposed_qa_status:ev.status,source_qa_fails:ev.flags.fail,source_qa_missing:ev.flags.missing,
  missing_external_evidence:[...REQUIRED_EXTERNAL],
  status:'QUARANTINE_INCOMPLETE_R46_PREDRAFT',
  authority:'SELF_DECLARED_NOT_R46_NATIVE',execution_authorized:false,
  physical_measurement_verified:false,independence_verified:false,rc5:false,
  official_rec_id:null,stock_effect:0,notion_write:false,party_write:false
 };
}
function stagePortable(payload,QA){if(!QA||typeof QA.auditPortable!=='function'||!QA.VERSION)throw Error('QA_SOURCE_REQUIRED');
 if(!payload||payload.schema!==QA.VERSION)throw Error('REEXPORT_WITH_CURRENT_QA_REQUIRED');
 const audit=QA.auditPortable(payload);
 if(audit.issues.length)throw Error('QUARANTINED_SOURCE_JSON_'+audit.issues[0].reason);
 if(!payload.records.length)throw Error('EMPTY_SESSION');
 const reports=[],excluded=[];
 for(let i=0;i<payload.records.length;i++){
  const r=payload.records[i].record,ev=QA.evaluate(r);
  if(!R46_TYPES[r.type]){excluded.push({index:i,sample_id:r.sample_id,type:r.type,reason:'B30_02_CORD_NOT_IN_R46_TLI_MICA_CONTRACT'});continue;}
  reports.push(mapOne({...r,source_id:ev.source_id},ev));
 }
 if(!reports.length)throw Error('NO_R46_TLI_OR_MICA_SAMPLES');
 return {schema:SCHEMA,source_schema:QA.VERSION,source_data_origin:payload.data_origin,
  output_kind:'PREPARATORY_DRAFT_NOT_R46_NATIVE',review_status:'QUARANTINE_INCOMPLETE_NO_AUTOCANON',
  report_count:reports.length,excluded_count:excluded.length,reports,excluded,
  evidence_completeness:'ZERO_EXTERNALLY_VERIFIED_EVIDENCE',
  required_external_proofs:[...REQUIRED_EXTERNAL],
  physical_measurement_verified:false,independence_verified:false,execution_authorized:false,
  official_rec_ids_created:0,stock_effect:0,notion_write:false,party_write:false,
  next_action:'OBTER_ANEXOS_E_COMPROVANTES_REAIS_E_MONTAR_LAUDO_R46_NATIVO_SOB_REVISOR_COMPETENTE'};
}
function stageSession(records,QA){return stagePortable(QA.portableExport(records),QA);}
return {SCHEMA,REQUIRED_EXTERNAL,R46_TYPES,stagePortable,stageSession};
});
