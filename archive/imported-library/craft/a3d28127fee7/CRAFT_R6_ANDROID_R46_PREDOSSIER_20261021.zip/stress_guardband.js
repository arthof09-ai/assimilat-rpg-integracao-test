'use strict';
// Deterministic stress test of proposed geometric tolerance, no real metrology.
const assert=require('node:assert/strict');const crypto=require('node:crypto');const QA=require('./logic');
let seed=0xC0A517;function random(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296;}
const base=()=>({type:'tli',sample_id:'STRESS',lot_id:'SBX-TEST',operator:'TEST',instrument_id:'SBX-INSTRUMENT',calibration_reference:'SBX-CAL',date_time:'2026-10-21T12:00',uncertainty_mm:0.05,claimed_is_actual:false,comparator:false,measurements:{length_mm:120,width_mm:80,thickness_mm:8,flatness_mm:.5,grid_mm:10,groove_mm:.2,marking_repeats:3,cracks:false,delamination:false,sharp_edges:false,magic_detected:false}});
const results=[];for(let i=0;i<2000;i++){
 const rec=base();const v=118+random()*5,u=.001+random()*.35;rec.measurements.length_mm=v;rec.uncertainty_mm=u;
 const outcome=QA.evaluate(rec).status;
 const inside=(v>=119&&v<=121),intervalCross=(v-u<=121&&v+u>=119);
 if(outcome==='WITHIN_PROPOSED_TOLERANCE')assert(inside&&v-u>=119&&v+u<=121);
 if(outcome==='OUTSIDE_PROPOSED_TOLERANCE')assert(!intervalCross);
 if(!inside&&intervalCross)assert.equal(outcome,'INDETERMINATE_UNCERTAINTY');
 results.push(`${i}|${outcome}`);
}
const sha=crypto.createHash('sha256').update(results.join('\n')).digest('hex');
console.log('GUARDBAND_STRESS_2000_PASS',sha,'proposed_limits_only','no_physical_samples');
