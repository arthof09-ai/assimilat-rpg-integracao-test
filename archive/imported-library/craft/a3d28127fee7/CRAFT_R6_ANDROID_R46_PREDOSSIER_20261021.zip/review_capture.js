/* REVIEWER CRAFT R5: Node CLI reads the exact shared Android v1.2 QA module.
   No duplicate rule engine, no external network, no Notion writes. */
'use strict';
const {readFileSync,writeFileSync}=require('node:fs');
const {createHash}=require('node:crypto');
const {resolve}=require('node:path');
const QA=require('./logic.js');
const SOURCE_PIN='a346889dd1cc59826d7d0ce24a16a9444d7587d316f63eccd1034dfc8be6e484';
function digest(data){return createHash('sha256').update(data).digest('hex')}
function audit(raw){
 if(typeof raw!=='string'||Buffer.byteLength(raw)>10*1024*1024)throw Error('INVALID_SIZE');
 if(digest(readFileSync(__dirname+'/logic.js'))!==SOURCE_PIN)throw Error('BASELINE_LOGIC_SHA_MISMATCH');
 let payload;
 try{payload=JSON.parse(raw)}catch{throw Error('INVALID_JSON')}
 const report=QA.auditPortable(payload);
 return {...report,input_sha256:digest(raw),logic_sha256:SOURCE_PIN};
}
function cli(){
 if(process.argv.length<3||process.argv.length>4){console.error('Uso: node review_capture.js entrada.json [saida.json]');process.exitCode=2;return}
 let report;
 try{report=audit(readFileSync(resolve(process.argv[2]),'utf8'));}catch(e){console.error('REVIEW_REJECTED',e.message);process.exitCode=2;return}
 const file=process.argv[3]||resolve(process.argv[2])+'.review.json';
 writeFileSync(file,JSON.stringify(report,null,2)+'\n');
 console.log(report.review_status,'records',report.record_count,'issues',report.issues.length,'sha',report.input_sha256,'output',file);
 if(report.issues.length)process.exitCode=1;
}
module.exports={audit,digest,SOURCE_PIN};if(require.main===module)cli();
