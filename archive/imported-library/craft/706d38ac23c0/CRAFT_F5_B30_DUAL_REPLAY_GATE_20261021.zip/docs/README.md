# Contrato F5 B30-06 + B30-13 — integração de testes sem admissão automática

**Propósito:** demonstrar que os últimos três pacotes TEST (Bolsa Secante, auditor de replicatas e Substrato) podem ser abertos pelo mesmo integrador read-only com hashes originais fixos, provas de identidade de 30 fichas-fonte PS e rejeição de uma promoção física indevida. Não reimplementa nem altera o motor R48, receita REC-LIB, regras, ficha e estoque de jogo.

**Execução:** `python -B code/run_replay.py` em pasta extraída. Todos os ZIPs originais são anexados e SHA256 validados antes de importar código de fonte própria, e os resultados são confrontados com `outputs/COMPOSED.json`. Também verifica por testes que um envelope com TODOS os oito campos declarados true continua `EXTERNAL_REVIEW_REQUIRED_NO_AUTOCANON`, jamais writer GREEN.

**Fatos preservados:** 30/30 fichas-fonte PS Mestre previamente reabertas no inventário, não é censo atual de REC-IDs; candidato 06 com origem de invólucro NÃO qualificada, pseudorreplicação da fixture e sorção não observada; candidato 13 com areia CRUA da fonte B30-04 e anomalia de 250mL na variante sem areia, 0 germinação real. Produção RC5, F5 e P4 HOLD; C19-021 UNKNOWN-EFFECT. Não há medições físicas, PA debitado, Party/O Primeiro, mutações de R48 ou registros da campanha.

**Seguimento:** obter autorização/fencing material, fonte/custódia/operador e ensaios independentes por categoria, antes de qualquer adendo produtivo. Este integrador é apenas verificador da capacidade digital já executada.
