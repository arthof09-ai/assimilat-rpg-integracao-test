import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def check():
 m=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
 for path,h in m['files'].items():
  if hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=h:raise ValueError('SHA_FAIL:'+path)
 existing={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256.json'}
 assert set(m['files'])==existing
 return len(existing)
if __name__=='__main__':print('PASS_MANIFEST',check())
