"""Read-only composed F5 B30-06/B30-13 test gate using immutable verified baselines.

Does NOT reproduce original factory modules; imports them from SHA-pinned ZIPs.
"""
from pathlib import Path
from dataclasses import dataclass
import zipfile,hashlib,importlib.util,tempfile,json,io,csv,copy,re,sys
ROOT=Path(__file__).resolve().parents[1]
BASE={
 'bag':('CRAFT_B30_06_BOLSA_FUNC_TEST_20261021.zip','f9e5d494956039566417df0edf9e6b22bfef7e9a38190875e37c06329d0b2166'),
 'trial':('CRAFT_B30_06_TRIAL_INTEGRITY_TEST_20261021.zip','5159f0c207a68216af07202186388db580532607d33e2c4a67688b6d015e6654'),
 'substrate':('CRAFT_B30_13_VOLUME_CAUSAL_TEST_20261021.zip','9acaa3284b7cf9fedf05e12586b942ee72062fe1d1a5a2f24621787ed30dec77')}
MODULE={ 'bag':'code/bag_case.py','trial':'code/trial_integrity.py','substrate':'code/mix_engine.py'}
SUPPORTED={'B30-06','B30-13'}
_ACTIVE_TEMP_DIRS=[]

def source_files():
    zs={}
    for k,(name,sha) in BASE.items():
        p=ROOT/'baselines'/name
        if hashlib.sha256(p.read_bytes()).hexdigest()!=sha:raise RuntimeError('BASELINE_HASH_MISMATCH:'+k)
        z=zipfile.ZipFile(p)
        if z.testzip() is not None:raise RuntimeError('BASELINE_ZIP_CRC_FAIL:'+k)
        zs[k]=z
    return zs

def load(z, member, module_name):
    # Trust boundary: member loaded only from independently SHA-pinned ZIP.
    d=tempfile.TemporaryDirectory();_ACTIVE_TEMP_DIRS.append(d)
    root=Path(d.name);(root/'code').mkdir();(root/'baselines').mkdir()
    p=root/'code'/(module_name+'.py');p.write_bytes(z.read(member))
    if module_name=='pinned_trial':
        (root/'baselines'/'CRAFT_B30_06_PAIRED_CONTROL_TEST_20261021.zip').write_bytes(z.read('baselines/CRAFT_B30_06_PAIRED_CONTROL_TEST_20261021.zip'))
    spec=importlib.util.spec_from_file_location(module_name,p)
    m=importlib.util.module_from_spec(spec);sys.modules[module_name]=m;spec.loader.exec_module(m)
    return m

def evidence_row(candidate,evidence):
    if candidate not in SUPPORTED:return {'status':'UNSUPPORTED_CANDIDATE_NO_ACTION'}
    if not isinstance(evidence,dict):return {'status':'REJECTED_NO_ACTION','reason':'EVIDENCE_NOT_OBJECT'}
    # Form completeness is not authorization; even green strings cannot prove external fencing.
    allowed={'source_chain','lot_custody','operator_witness','physical_measurement','comparison','receipts','writer_green','signed_identity','self_claimed_status'}
    if set(evidence)-allowed:return {'status':'REJECTED_NO_ACTION','reason':'UNKNOWN_EVIDENCE_FIELDS'}
    for k in allowed-{'self_claimed_status'}:
        if k in evidence and type(evidence[k]) is not bool:
            return {'status':'REJECTED_NO_ACTION','reason':'EVIDENCE_BOOL_TYPE_INVALID'}
    present=[k for k in sorted(allowed-{'self_claimed_status'}) if evidence.get(k) is True]
    missing=[k for k in sorted(allowed-{'self_claimed_status'}) if evidence.get(k) is not True]
    return {'status':'EXTERNAL_REVIEW_REQUIRED_NO_AUTOCANON' if not missing else 'DOCUMENTARY_GATES_OPEN_HOLD',
            'candidate':candidate,'fields_claimed_true':present,'missing_or_false':missing,
            'self_report_is_not_authority':True,'actual_writer_verified':False,
            'material_effects':0,'physical_efficacy_verified':False,
            'rec_id_created':None,'party_writes':0,'o_primeiro_writes':0,
            'next':'Requires independent authoritative Notion/scene readback, NAC-PASS, C19 fencing, physical source custody.'}

def composed():
    z=source_files()
    bag=load(z['bag'],MODULE['bag'],'pinned_bag')
    trial=load(z['trial'],MODULE['trial'],'pinned_trial')
    substrate=load(z['substrate'],MODULE['substrate'],'pinned_substrate')
    with z['bag'].open('data/b30_live_sources.csv') as f:
        rows=list(csv.DictReader(io.TextIOWrapper(f,encoding='utf8')))
    ids=[r['b30_id'] for r in rows]
    uuids=[r['notion_page_id'] for r in rows]
    if len(rows)!=30 or set(ids)!={f'B30-{i:02}' for i in range(1,31)} or len(set(uuids))!=30 or not all(re.fullmatch(r'[0-9a-f]{32}',x) for x in uuids):
        raise ValueError('PORTFOLIO_PRIMARY_SOURCE_IDENTITY_INVALID')
    lookup={r['b30_id']:r for r in rows}
    if lookup['B30-06']['notion_page_id']!=bag.ZEO_SOURCE:raise ValueError('ZEOLITE_SOURCE_MISMATCH')
    if lookup['B30-13']['notion_page_id']!=substrate.HUMUS or lookup['B30-04']['notion_page_id']!=substrate.SAND:
        raise ValueError('HUMUS_OR_SAND_SOURCE_MISMATCH')
    e=json.loads(z['trial'].read('data/paired_synthetic.json'))
    pseud=json.loads(z['trial'].read('data/design_pseudoreplication.json'))
    m=json.loads(z['trial'].read('data/mass_synthetic.json'))
    x=trial.assess(e,pseud,m)
    d=substrate.demo()
    seed=json.loads(z['substrate'].read('data/seed_germination_fixture.json'))
    g=substrate.germination(seed)
    bag_output=bag.demonstrator()
    # Scope-specific receipts only, no double counting of source pages.
    assert x['status']=='PSEUDOREPLICATION_OR_SINGLE_BATCH_HOLD'
    assert d['no_sand_750ml_gap']['status']=='NOMINAL_SHORTFALL_250_MINUS_SAND'
    assert g['status']=='DESCRIPTIVE_SEED_COUNTS_UNVERIFIED'
    # Do not reinterpret the two PS source links as two official REC-IDs.
    return {'schema':'CRAFT-F5-B30-TWO-CANDIDATE-CROSS-GATE-TEST-v1',
            'readback_resources':30,'unique_sources':30,'current_global_rc5':'NOT_AUDITED',
            'count_candidate_tested':2,'official_rc5_created_this_run':0,
            'candidate_06':{
                'source_zeolite_page':lookup['B30-06']['notion_page_id'],
                'sleeve_source':'UNQUALIFIED_EXISTING_CANDIDATES_OR_SYNTHETIC_FIXTURE',
                'assembly_status':'SYNTHETIC_ONLY',
                'trial_status':x['status'], 'rh_contrast_fixture_pp':x['mean_paired_RH_diff_pp'],
                'mass_fixture_assembly_apparent_g_per_g':x['mass']['apparent_gain_g_per_g'],
                'physical_sorption_verified':False,
                'blockers':['porous_sleeve_material_lot','sorption_independent_units','pore_powder_containment','C19_fencing','REC_LIB','physical_QA']},
            'candidate_13':{
                'source_humus_page':lookup['B30-13']['notion_page_id'],
                'source_raw_sand_page':lookup['B30-04']['notion_page_id'],
                'sand_is_raw_PS_not_B30_04_product':True,
                'mixture_status':d['single']['status'],
                'nominal_no_sand_shortfall_ml':d['no_sand_750ml_gap']['nominal_gap_ml'],
                'germination_status':g['status'],
                'physical_germination_verified':False,
                'blockers':['1L_volume_and_BOM_authority','actual_mixed_yield_and_qa','germination_controls','C19_fencing','REC_LIB','physical_QA']},
            'common_authority':{'F5':'P0_RED','C19_021':'UNKNOWN_EFFECT',
                'all_counters_test_only':True,'source_readback_not_recipe_census':True,
                'no_party':True,'no_o_primeiro':True,'no_R48_write':True,
                'no_stock_change':True,'no_PA_change':True,
                'no_production_green_assumed':True},
            'admission_examples':{'all_false':evidence_row('B30-06',{}),
                'all_true_autoreport':evidence_row('B30-13',{k:True for k in ['source_chain','lot_custody','operator_witness','physical_measurement','comparison','receipts','writer_green','signed_identity']})},
            'source_identity_note':'30/30 PS identity/CRN from prior live Notion reopen; values read from pinned CSV, no fresh Notion readback claimed by this runner'}
