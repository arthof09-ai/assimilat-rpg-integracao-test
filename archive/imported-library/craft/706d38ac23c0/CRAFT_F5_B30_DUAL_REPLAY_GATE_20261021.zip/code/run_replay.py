from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from verify_manifest import check
from dual_replay import composed
if __name__=='__main__':
 n=check();p=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stderr)
 stored=json.loads((ROOT/'outputs'/'COMPOSED.json').read_text())
 assert composed()==stored
 print('PASS_B30_TWO_CANDIDATE_INTEGRATION_COLD',n,'MANIFEST',p.stderr.strip().split('Ran ')[-1].split(' ')[0],'TESTS_NO_RC5_NO_WRITER')
