import sys,unittest,copy,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from dual_replay import composed,evidence_row,source_files,load,BASE,ROOT
class Integrated(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=composed()
 def test_resource_30(self):self.assertEqual(self.r['readback_resources'],30)
 def test_unique_30(self):self.assertEqual(self.r['unique_sources'],30)
 def test_not_global_rc5(self):self.assertEqual(self.r['current_global_rc5'],'NOT_AUDITED')
 def test_two_candidates(self):self.assertEqual(self.r['count_candidate_tested'],2)
 def test_zero_rc5(self):self.assertEqual(self.r['official_rc5_created_this_run'],0)
 def test_06_pseudoreplication(self):self.assertEqual(self.r['candidate_06']['trial_status'],'PSEUDOREPLICATION_OR_SINGLE_BATCH_HOLD')
 def test_06_RH(self):self.assertEqual(self.r['candidate_06']['rh_contrast_fixture_pp'],'9')
 def test_06_mass(self):self.assertEqual(self.r['candidate_06']['mass_fixture_assembly_apparent_g_per_g'],'0.0095')
 def test_06_not_sorption(self):self.assertFalse(self.r['candidate_06']['physical_sorption_verified'])
 def test_06_sleeve(self):self.assertIn('UNQUALIFIED',self.r['candidate_06']['sleeve_source'])
 def test_13_humus(self):self.assertEqual(self.r['candidate_13']['source_humus_page'],'3f3c2b324ede812b84b2fe10adb88d8e')
 def test_13_sand(self):self.assertEqual(self.r['candidate_13']['source_raw_sand_page'],'3f3c2b324ede816f9af4fdd6758bbe6c')
 def test_13_raw_not_processed(self):self.assertTrue(self.r['candidate_13']['sand_is_raw_PS_not_B30_04_product'])
 def test_13_gap_250(self):self.assertEqual(self.r['candidate_13']['nominal_no_sand_shortfall_ml'],'250')
 def test_13_mixture_test_only(self):self.assertEqual(self.r['candidate_13']['mixture_status'],'SYNTHETIC_SUBSTRATE_COMMIT_ONLY')
 def test_13_germination_unverified(self):self.assertFalse(self.r['candidate_13']['physical_germination_verified'])
 def test_13_germination_status(self):self.assertEqual(self.r['candidate_13']['germination_status'],'DESCRIPTIVE_SEED_COUNTS_UNVERIFIED')
 def test_F5_red(self):self.assertEqual(self.r['common_authority']['F5'],'P0_RED')
 def test_unknown(self):self.assertEqual(self.r['common_authority']['C19_021'],'UNKNOWN_EFFECT')
 def test_no_party(self):self.assertTrue(self.r['common_authority']['no_party'])
 def test_no_o_primeiro(self):self.assertTrue(self.r['common_authority']['no_o_primeiro'])
 def test_no_R48(self):self.assertTrue(self.r['common_authority']['no_R48_write'])
 def test_no_stock(self):self.assertTrue(self.r['common_authority']['no_stock_change'])
 def test_no_PA(self):self.assertTrue(self.r['common_authority']['no_PA_change'])
 def test_not_recipe_census(self):self.assertTrue(self.r['common_authority']['source_readback_not_recipe_census'])
 def test_2_distinct_source_ids(self):self.assertNotEqual(self.r['candidate_06']['source_zeolite_page'],self.r['candidate_13']['source_humus_page'])
 def test_exposed_all_true_not_real(self):self.assertFalse(self.r['admission_examples']['all_true_autoreport']['actual_writer_verified'])
 def test_form_all_true(self):self.assertEqual(self.r['admission_examples']['all_true_autoreport']['status'],'EXTERNAL_REVIEW_REQUIRED_NO_AUTOCANON')
 def test_not_admit_none(self):self.assertEqual(self.r['admission_examples']['all_false']['status'],'DOCUMENTARY_GATES_OPEN_HOLD')
 def test_no_auto_rec_id(self):self.assertIsNone(self.r['admission_examples']['all_true_autoreport']['rec_id_created'])
 def test_06_block_count(self):self.assertGreaterEqual(len(self.r['candidate_06']['blockers']),5)
 def test_13_block_count(self):self.assertGreaterEqual(len(self.r['candidate_13']['blockers']),5)
 def test_receipt_claims_cannot_authorize(self):self.assertFalse(evidence_row('B30-13',{'writer_green':True})['actual_writer_verified'])
 def test_receipt_overwrite(self):self.assertEqual(evidence_row('B30-13',{'writer_green':'true'})['reason'],'EVIDENCE_BOOL_TYPE_INVALID')
 def test_receipt_unknown(self):self.assertEqual(evidence_row('B30-13',{'notion_write':True})['reason'],'UNKNOWN_EVIDENCE_FIELDS')
 def test_receipt_unsupported(self):self.assertEqual(evidence_row('B30-07',{})['status'],'UNSUPPORTED_CANDIDATE_NO_ACTION')
 def test_not_adhoc_official(self):self.assertEqual(evidence_row('B30-06',{'self_claimed_status':'RC5_PASS'})['status'],'DOCUMENTARY_GATES_OPEN_HOLD')
 def test_sourced_file_count(self):self.assertEqual(len(BASE),3)
 def test_determinism(self):self.assertEqual(self.r,composed())
 def test_actual_source_reopen_is_prior(self):self.assertIn('prior live Notion reopen',self.r['source_identity_note'])
 def test_not_claim_new_reopen(self):self.assertIn('no fresh Notion readback',self.r['source_identity_note'])
 def test_not_prod_green(self):self.assertTrue(self.r['common_authority']['no_production_green_assumed'])
 def test_no_writes_claim(self):self.assertEqual(self.r['admission_examples']['all_true_autoreport']['material_effects'],0)
 def test_invalid_evidence(self):self.assertEqual(evidence_row('B30-06',None)['reason'],'EVIDENCE_NOT_OBJECT')
 def test_pin_zip_tamper(self):
  # Verify trust boundary without editing zipped originals.
  from unittest.mock import patch
  import dual_replay
  orig=dual_replay.BASE
  try:
   dual_replay.BASE={**orig,'bag':(orig['bag'][0],'0'*64)}
   with self.assertRaises(RuntimeError):source_files()
  finally:dual_replay.BASE=orig
 def test_load_baseline(self):
  z=source_files();self.assertTrue(load(z['bag'],'code/bag_case.py','t_bag').ZEO_SOURCE)
if __name__=='__main__':unittest.main()
