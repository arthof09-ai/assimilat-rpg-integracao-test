import copy, json, unittest
from pathlib import Path
from pa_nac_preflight import gate, _policy_comparison, MASTER_POLICY, _load_qa
P=Path(__file__).resolve().parent
R=json.loads((P/'receita_test_input.json').read_text())
PA=json.loads((P/'pa_r27_receipt.json').read_text())

class LabRecipeTests(unittest.TestCase):
    def setUp(self):self.r=copy.deepcopy(R);self.pa=copy.deepcopy(PA)
    def run_gate(self):return gate(self.r,self.pa,r48_executable=True,r48_recipe_executed=False)
    def codes(self):return {x['code'] for x in _load_qa().audit(self.r)['findings']}
    def test_original_qa_static_rc5_overclaim_correctly_capped(self):self.assertEqual(_load_qa().audit(self.r)['rc_ceiling_test'],'RC5');self.assertEqual(self.run_gate()['qa_ceiling_test_only'],'RC4')
    def test_qa_pa_gaps_resolved(self):self.assertEqual(self.codes(),set())
    def test_three_bom_materials(self):self.assertEqual(len(self.r['bom']),3)
    def test_all_bom_have_source_ref(self):self.assertTrue(all(x.get('source_ref','').startswith('https://app.notion.com/p/') for x in self.r['bom']))
    def test_distinct_roles(self):self.assertEqual({x['role'] for x in self.r['bom']},{'core','ativo','ligante'})
    def test_four_operations(self):self.assertEqual(len(self.r['operations']),4)
    def test_act_two(self):self.assertEqual(self.pa['habilidades'][1]['usos_no_dia'],2)
    def test_pa_day_literal_original_receipt(self):self.assertEqual(self.pa['custo_pa']['pa_por_dia'],12)
    def test_pa_two_activations_legacy(self):self.assertEqual(self.pa['custo_pa']['pa_ativacoes_no_cenario'],14)
    def test_pa_provider_real(self):self.assertEqual(self.pa['contrato'],'PA-CRAFT-QMC05-COMPAT-R27/1.0.0-TEST')
    def test_pa_falsely_flagged_mismatch_fixed(self):self.assertNotIn('PA_PROVIDER_TARIFF_DIVERGES_MESTRE:Abertura de Contrassombra',self.run_gate()['non_pa_gates'])
    def test_pa_quarantine_lifted_only_energy(self):self.assertTrue(self.run_gate()['pa_version_compatible'])
    def test_no_canonical_artifact(self):self.assertEqual(self.run_gate()['official_rec_ids'],0)
    def test_no_party_write(self):self.assertFalse(self.run_gate()['party_write'])
    def test_r48_original_found_but_no_pingente_adapter(self):self.assertIn('R48_RECIPE_ADAPTER_AND_EXECUTION_NOT_PROVEN',self.run_gate()['non_pa_gates'])
    def test_magic_not_proved(self):self.assertIn('MAGICAL_TRANSFER_NOT_PHYSICALLY_DEMONSTRATED',self.run_gate()['non_pa_gates'])
    def test_missing_unit_detection(self):self.r['bom'][0]['unit']='';self.assertIn('BOM_QTY_UNIT',self.codes())
    def test_extra_material_without_bom(self):self.r['operations'][2]['inputs'].append('MATERIAL_NAO_LISTADO');self.assertGreaterEqual(len(self.codes()),1)
    def test_duplicate_input_or_bom_detection(self):self.r['bom'][1]['id']=self.r['bom'][0]['id'];self.assertIn('BOM_DUPLICATE_ID',self.codes())
    def test_missing_source_detection(self):self.r['bom'][2]['source_ref']='';self.assertIn('BOM_SOURCE',self.codes())
    def test_novop_blocks(self):self.r['bom'][2]['dependency']='NOVO-P';self.assertIn('UNADMITTED_DEPENDENCY',self.codes())
    def test_party_source_blocks(self):self.r['source_workspace']='PARTY';self.assertIn('PARTY_BOUNDARY',self.codes())
    def test_publish_attempt_denied(self):self.r['request_publish']=True;self.assertIn('NO_WRITE_GATE',self.codes())
    def test_scope_without_fixture_denied(self):self.r['fixture_only']=False;self.assertIn('SCOPE_NOT_FIXTURE',self.codes())
    def test_bom_role_without_why(self):self.r['bom'][1]['role_why']='';self.assertIn('BOM_ROLE',self.codes())
    def test_rank_from_price_denied(self):self.r['mechanic']['rank_from']='price';self.assertIn('RANK_PROXY_FORBIDDEN',self.codes())
    def test_missing_time_blocks(self):self.r['manufacture']['time']['value']=None;self.assertIn('RC4_TIME_EVIDENCE',self.codes())
    def test_missing_specialist_blocks(self):self.r['manufacture']['specialist']['ref']='';self.assertIn('RC4_SPECIALIST_EVIDENCE',self.codes())
    def test_high_risk_master_decision(self):self.r['risk']['sc']='SC-4';self.assertIn('SC_DECISION_PENDING',self.codes())
    def test_legacy_pa_never_repriced(self):self.pa['item']['historico']=True;self.assertIn('HISTORIC_PA_MUST_NOT_BE_REPRICED',self.run_gate()['non_pa_gates'])
    def test_fake_green_detected(self):self.pa['governanca']['craft_f5']='GREEN';self.assertIn('PRODUCTION_STATE_UNEXPECTED',self.run_gate()['non_pa_gates'])
    def test_invalid_provider_contract(self):self.pa['contrato']='MOCK';self.assertIn('PA_PROVIDER_CONTRACT_INVALID',self.run_gate()['non_pa_gates'])
    def test_unknown_rank_for_pa(self):self.pa['habilidades'][1]['rank_efeito_proposto']=None;self.assertIn('EFFECT_RANK_UNKNOWN:Abertura de Contrassombra',self.run_gate()['non_pa_gates'])
    def test_master_policy_correct_rates(self):self.assertEqual(MASTER_POLICY['active_daily_numerator'],50);self.assertEqual(MASTER_POLICY['active_activation_numerator'],60)
    def test_pa_passive_same(self):self.assertTrue(self.run_gate()['pa_tariff_observation'][0]['compatible'])
    def test_pa_active_compatible(self):self.assertTrue(self.run_gate()['pa_tariff_observation'][1]['compatible'])
    def test_mutation_noninterfering(self):self.assertNotEqual(self.run_gate()['status'],'READY_FOR_FURTHER_TEST_ONLY')
    def test_missing_qa_evidence(self):self.r['module_evidence']['ensaio_uso']={};self.assertIn('MODULE_ENSAIO_USO',self.codes())
    def test_unauthorized_material_change_lineage(self):self.r['lineage']={'change':'material','strategy':'SAME_VERSION'};self.assertIn('LINEAGE_MATERIAL_CHANGE',self.codes())
    def test_chemical_name_not_power(self):self.assertIn('não transmite frio',self.r['bom'][2]['role_why'])
    def test_qa_source_original_preserved(self):self.assertEqual(_load_qa().VERSION,'CRAFT-RECIPE-QA-TEST/1.0.0')

    def test_wrong_daily_tariff_rejected(self):
        self.pa['habilidades'][1]['pa_por_dia']=7
        self.assertIn('PA_PROVIDER_TARIFF_DIVERGES_MESTRE:Abertura de Contrassombra',self.run_gate()['non_pa_gates'])
    def test_wrong_activation_tariff_rejected(self):
        self.pa['habilidades'][1]['pa_por_ativacao']=12
        self.assertIn('PA_PROVIDER_TARIFF_DIVERGES_MESTRE:Abertura de Contrassombra',self.run_gate()['non_pa_gates'])
    def test_wrong_daily_60_percent_rejected(self):
        self.pa['habilidades'][1]['pa_por_dia']=7
        self.assertFalse(self.run_gate()['pa_version_compatible'])
    def test_passive_100_percent_preserved(self):
        self.assertEqual(self.pa['habilidades'][0]['pa_por_dia'],6)
    def test_prata_base_and_usage(self):
        self.assertEqual(self.pa['habilidades'][1]['pa_por_dia'],6)
        self.assertEqual(self.pa['habilidades'][1]['pa_por_ativacao'],7)
    def test_day_total_tampering(self):
        self.pa['custo_pa']['pa_por_dia']=13
        self.assertIn('PA_PROVIDER_DAILY_TOTAL_INCONSISTENT',self.run_gate()['non_pa_gates'])
    def test_activation_total_tampering(self):
        self.pa['custo_pa']['pa_ativacoes_no_cenario']=15
        self.assertIn('PA_PROVIDER_ACTIVATIONS_TOTAL_INCONSISTENT',self.run_gate()['non_pa_gates'])
    def test_scenario_total_tampering(self):
        self.pa['custo_pa']['pa_total_no_cenario']=100
        self.assertIn('PA_PROVIDER_SCENARIO_TOTAL_INCONSISTENT',self.run_gate()['non_pa_gates'])
    def test_rc5_still_denied_after_correct_tariff(self):
        outcome=self.run_gate()
        self.assertEqual(outcome['production'],'DENY')
        self.assertIn('MAGICAL_TRANSFER_NOT_PHYSICALLY_DEMONSTRATED',outcome['non_pa_gates'])
        self.assertEqual(outcome['official_rec_ids'],0)
    def test_daily_floor_not_activation(self):
        self.assertEqual(self.pa['custo_pa']['piso_item'],11)
        self.assertEqual(self.pa['custo_pa']['pa_por_dia'],12)
        self.assertEqual(self.pa['custo_pa']['pa_ativacoes_no_cenario'],14)
        self.assertEqual(self.pa['custo_pa']['pa_total_no_cenario'],26)
    def test_corrected_recipe_has_provider_pa(self):
        self.assertEqual(self.r['pa']['daily']['amount'],12)
        self.assertEqual(self.r['pa']['per_activation']['amount'],7)
        self.assertEqual(self.codes(),set())

    def test_rc5_static_false_positive_blocked_by_magic_transfer(self):
        self.assertEqual(self.run_gate()['qa_static_raw_ceiling'],'RC5')
        self.assertEqual(self.run_gate()['qa_ceiling_test_only'],'RC4')
        self.assertEqual(self.run_gate()['production'],'DENY')
    def test_rc5_is_not_equivalent_to_complete_energy_contract(self):
        self.assertTrue(self.run_gate()['pa_version_compatible'])
        self.assertEqual(self.run_gate()['official_rec_ids'],0)

    def test_r48_original_test_success_not_recipe_execution(self):
        s=self.run_gate()
        self.assertEqual(s['r48_execution'],'R48_FABRICA_ORIGINAL_RECUPERADA_SEM_ENSAIO_DA_RECEITA')
    def test_r48_executable_is_not_approval(self):
        s=gate(self.r,self.pa,r48_executable=True,r48_recipe_executed=True)
        self.assertIn('MAGICAL_TRANSFER_NOT_PHYSICALLY_DEMONSTRATED',s['non_pa_gates'])
        self.assertEqual(s['production'],'DENY')

if __name__=='__main__':unittest.main(verbosity=2)
