# LAB CRAFT — Receita TEST: Pingente da Vigília Boreal

**Natureza:** projeto autoral experimental criado APENAS sob autorização expressa do Mestre de 20/10/2026. Não é receita oficial, página REC-LIB, produto fabricado, item canônico, conhecimento da Party ou ordem para fabricar. Não atribuir REC-ID produtivo. **Case-id LAB:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001`.

## I — Necessidade e identidade

- **Finalidade:** acessório pessoal de exploração noturna: iluminação útil sem concessão de visão absoluta e alívio momentâneo contra uma área muito pequena de escuridão mágica.
- **Família:** Equipamentos/Roupas/Acessórios (`REC-MOD-EQA-01`).
- **Classificação nominal de projeto:** **Prata, PROPOSTA E3**, sem estrelas públicas. Posicionamento FIP interno INDETERMINADO.
- **Comparadores de efeito:** [Cristal de Aurora Boreal](https://app.notion.com/p/3edc2b324ede818b9d7ad75d42f2afa2), [Erva da Luz do Norte](https://app.notion.com/p/3edc2b324ede81deb8cec70bf5ca7150), [Véu de Eärendil](https://app.notion.com/p/3edc2b324ede813e8efaf8de2050fd9b) e [Atlas de Poder](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab). É utilitário distinto do Véu: o Véu se protege de escuridão, o pingente pretende abrir um trecho visual próximo; não concede imunidade mágica.
- **Valor de ineditismo:** buscas dirigidas por função, broche, aurora e anti-escuridão não encontraram fórmula física homônima. Isso NÃO comprova inexistência global; é anti-duplicata proporcional ao TEST.

## II — Descrição física / interface

Pequeno cristal auroral preso em laço/trança de fibra vegetal, com folhagem luminosa conservada atrás da gema. Porta-se ao pescoço, na altura do peito. Forma, dimensões, peso, espessura e aparência finais **PROPOSTOS**, não fotografados, fabricados nem medidos. Exige teste de atrito cutâneo, desprendimento, conforto com armadura e interferência luminosa. Não concede bônus de CA, atributo ou RD.

## III — Fonte → função → mecanismo → ensaio

| Componente | Evidência da fonte / autoridade | Papel indispensável | Transformação proposta | Ensaio discriminatório |
|---|---|---|---|---|
| 1 Cristal de Aurora Boreal | Ficha Mestre documenta luz e dissipação de escuridão; RIn Ouro/E2/PS revisável | Core de luz contra escuridão | Acoplamento limitado ao usuário pelo suporte | Verificar se o cristal conserva sua ação quando montado; comparar efeito isolado x montado |
| 1 Erva da Luz do Norte | Ficha Mestre documenta luz auroral e revelação de magias ocultas; RIn Prata/E2/PS revisável | Reserva para luminescência passiva | Folhas iluminam de modo sustentado após preparo | Monitorar duração sem suposição de fonte infinita; controle com folhas comuns |
| 0,45 m de Fibra de Casca Boreal | Material F5 PS de função física (amarrar/estruturar), não mágico | Ligante/estrutura, fio e suspensão | Trançar suporte de folha e cristal | Ensaio de ruptura e manuseio; substituir por fibra comum sem reivindicar poder |

**OBS:** `0,45 m` é número de engenharia de TEST, não medida canônica do recurso; a ficha PS não possui unidade normalizada/rendimento validado. Quantidades de folhas efetivamente aproveitáveis, fração de perda e estabilidade da peça são PENDENTES.

## IV — Efeito pretendido, sem inventar poderes

**Passiva — Luminescência de Vigília (Bronze E3 sugerido):** enquanto equipado, a folhagem fornece luz suave pessoal em **raio proposto de 1 m**. Não revela invisibilidade, não cura cegueira, não dissipa sombras mágicas por si, não atravessa barreiras e não permite visão através de fumaça. Só funciona enquanto sua carga luminosa estiver preservada; frequência de recarga NÃO demonstrada.

**Ativa — Abertura de Contrassombra (Prata E3 sugerido):** mediante **1 Ação Padrão**, por **1 turno**, o portador abre uma **faixa visual de até 1 m** adjacente a ele através de escuridão mágica. Até **2 ativações/dia** como limite de design. Não encerra nem enfraquece globalmente a magia hostil, não é contra-ataque, não causa dano, não interfere fora da área próxima, não cura cegueira e não ativa se o portador estiver incapaz de enxergar. O alcance, a duração, os limites e a frequência são **PARÂMETROS PROPOSTOS TEST**, não derivados literalmente da fonte.

A transição de “um cristal que dissipa escuridão” para “um pingente capaz de canalizar isso ao portador por um turno” é a hipótese central ainda **NÃO DEMONSTRADA**. Nada foi magicamente fabricado ou observado. A falha nesse ensaio reprova a habilidade ou exige reformular o dispositivo — não autoriza criar poder por conveniência.

## V — BOM, sequência e rastreabilidade

**BOM:** três materiais de fontes reais acima; cada unidade é gasto conceitual apenas na fixture TEST. Ferramenta reutilizável de trançar, bancada e conhecimento de artesão são recursos de produção, **não** ingredientes consumidos; identidade/especialista concretos ainda dependem de fonte.

**Grafo:** fibra → cordão; erva → folhas luminescentes preparadas; {cordão + folhas + cristal} → pingente bruto; pingente bruto → *hipótese de calibração mágica* → pingente funcional. Quatro operações, cada entrada/saída com ID. Nenhum nó ganha massa ou efeito não explicado. Rendimento de intermediários, estabilidade e transformação energética necessitam teste.

**Procedimento de bancada — SIMULADO / PROPOSTO:** selecionar material íntegro → separar folhagem → torcer cordão → fixar cristal sem cola/metais adicionais → calibrar ligação mágico-visual → inspecionar retenção e segurança → ensaiar em ambiente controlado. Tempo `55 minutos` é convenção de scenario TEST, não duração física constatada. A etapa de calibração não possui método comprovado no corpus.

## VI — Controles e falhas

- **Falha física:** nó rompe, gema se solta, folhas perdem brilho; reprovar lote antes de uso.
- **Falha funcional:** gema brilha mas não abre visão local em sombra mágica; reprovar efeito ativo. Luminescência mundana NÃO prova poder mágico.
- **Falha de sistema:** fonte E2/PS mudada, exigência ambiental não satisfeita, item incapaz de cumprir mecanismo; marcar PRV e JIT-SC.
- **Confusão de orçamento:** PA diário de vestir o pingente NÃO é PA de fabricação; duas ativações não pagam a taxa diária automaticamente.
- **Contra-exemplos:** cegueira, parede opaca, escuridão fora de alcance, ausência de luz retida, uso de fibra comum, tentativa de remover magia inteira, ativação em outro alvo.
- **QA:** comparar suporte com material comum, observar brilho não mágico em controle e, somente com engine apropriada, testar visão local em magia de escuridão. **Nenhum teste de magia física foi executado.**

## VII — PA diário: chamada do fornecedor competente e divergência

**Motor efetivamente chamado em TEST:** adaptador autêntico R27 importando motor R26 da distribuição R28 recuperada. `CONSULTAR_PA_TEST`, entrada com duas habilidades, comparadores Notion e parecer E3.

| Modalidade | Resposta R27/R26 registrada — QUARENTENA | Situação |
|---|---|---|
| Passiva Bronze | 6 PA/dia | Hipótese de tarifa passiva, sem homologação |
| Ativa Prata | 6 PA/dia + 7 PA/uso | **DIVERGE da determinação posterior do Mestre** |
| Item Prata com 2 ativações | 12 PA/dia + 14 PA em 2 ativações = 26 PA no cenário | Resultado literal legado do software, **NÃO APROVADO** |

**Conflito documental objetivo:** o R26 do pacote R28 calcula ativas usando 50% da base/dia e 60% da base/ativação, ao passo que a ordem posterior do Mestre determina 60% da base/dia e tarifa-base integral por ativação. O CRAFT **não recalcula o custo final no lugar do Executor PA**. Campos prospectivos publicáveis ficam **PENDENTES** até fornecedor corrigido/revalidado. O piso por rank também precisa ser exercido dentro do motor competente. Não reprecificar itens históricos.

## VIII — Economia / UTE / logística

O preço de mercado e CTE por unidade **não são determináveis**. A erva possui estimativa antiga de cerca de 320.000 MED/unidade com confiança baixa e faixa 120.000–800.000 MED no texto da fonte, mas não é preço realizado do mesmo contexto da receita. Cristal e fibra carecem de cotações adequadas comparáveis, rendimentos reais, mão de obra, ferramenta, transporte entre origem e local e taxa de falhas. Manter separado kit, fabricação, conhecimento e produto. Não utilizar preço como evidência de rank.

**Gargalos:** coleta da erva na R06/taiga; cristal sob condições de aurora/caverna gelada conforme fonte; fibra PS na R01 exige fonte biológica real ainda não validada. Nenhuma rota, entrega, estoque ou safra ocorreu.

## IX — Social, conhecimento e Party

Somente projeto Mestre-side; artesão hipotético, nenhuma guilda, facção, comprador, cidade ou versão Player criada. Personagens não conhecem nem possuem a receita. O valor estratégico e eventual descoberta são cenários possíveis, não fatos históricos.

## X — Resultado dos gates e aceite

- **Receita documental:** BOM rastreável, papéis reais e quatro passos auditáveis; **RC4 indicativo TEST** pelo pré-validador reaproveitado, sem valor de fabricação física.
- **RC5:** HOLD: conflito tarifário, efeito mágico não demonstrado, fonte fibra PS com propriedades não medidas, função de especialista/ferramenta e perdas não comprovadas, R48 executável indisponível.
- **PA:** R27/R26 chamado realmente e resposta preservada como recibo semicanônico E3, tarifa normativa incompatível.
- **R48:** pacote histórico identificado na Library, binário não materializável nesta sessão; não há prova de execução de fábrica ou resultado de combate.
- **F5:** RED; C19-021 UNKNOWN; Writer/lease/fencing não assumidos; NAC-PASS produtivo HOLD.
- **Próximo experimento decisivo:** aferir retenção de luz e possibilidade de transferência da ação cristalina à peça em ambiente TEST autorizado e recuperar provider PA corrigido + runner R48 original; se falhar, reformular sem inflar ingredientes.

**Regra de interpretação:** documentar com qualidade profissional não é o mesmo que satisfazer evidência empírica RC5. O Mestre autorizou precisamente a tentativa em laboratório — não a canonização de seus resultados.
