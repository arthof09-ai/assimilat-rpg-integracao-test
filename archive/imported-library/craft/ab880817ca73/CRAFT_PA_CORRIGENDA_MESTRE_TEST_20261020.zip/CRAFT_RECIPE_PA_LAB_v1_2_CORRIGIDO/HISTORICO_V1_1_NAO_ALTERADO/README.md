# CRAFT / Engenharia de Receitas com PA — LAB TEST 20/10/2026

**Operação existente:** `OP-ARQ-RIN-REC-01` · **MESTRE-SIDE** · **CM-000002-WS0001**.

**Natureza deste pacote:** documentação de fluxo, um único projeto de receita mágica LAB-TEST, auditor estático reutilizado, consulta real ao fornecedor PA R27→R26, ensaios automatizados locais e PSV. Não é receita oficial, item fabricado, REC-ID, novo motor PA ou publicação da Party.

## Acesso rápido

- `FLUXOGRAMAS_CRAFT_PA_v1_1.md` — sete fluxogramas, incluindo consumo PA por dia e compatibilidade de fornecedor.
- `PROTOCOLO_OPERACIONAL_v1_1.md` — procedimento de atuação conforme mães PR-ITEM/REC-EXEC, PR-SC, módulos de família e PR-ECO.
- `RECEITA_TEST_PINGENTE_VIGILIA_BOREAL.md` — demonstração de **um** pingente mágico autoral TEST, três materiais referenciados e ensaios discriminatórios.
- `pa_r27_request.json` e `pa_r27_receipt.json` — chamada já executada ao fornecedor PA autêntico recuperado no pacote R28; o recibo fica em QUARENTENA por tarifa desatualizada.
- `receita_test_input.json` / `receita_test_audit.json` / `recibo_integrado_qa_pa.json` — entradas e decisão de RC4 apenas indicativo, com RC5 bloqueado.
- `pa_nac_preflight.py` — *somente* verificador de coerência do contrato: não calcula tarifa.
- `vendor/recipe_qa.py` — auditor anterior preservado como baseline TEST; não edita fontes.
- `test_recipe_pa_integration.py` — 41 testes novos, `vendor/test_recipe_qa.py` — 26 regressões.
- `run_lab.py` — replay autocontido de todos os testes internos e integridade do recibo PA.
- `PSV_FINAL.md` — estado antes/depois, denominadores, limites e retomada.

## Reproduzir sem fontes externas

Extraia o ZIP e execute no diretório extraído:

```bash
python run_lab.py
python verify_manifest.py
```

A reprodução valida 41+26 testes e o recibo já capturado da chamada autêntica. Ela **não executa** novamente o fornecedor R27, pois o seu código permanece íntegro no pacote R28 separado, nem executa R48 (bytes indisponíveis neste runtime). O estado da fonte externa é documentado, não mascarado como replay.

## Diferença normativa energética importante

O código R26 embutido no pacote R28 calculou **50% da base para PA diário de ativa e 60% da base por ativação**, divergindo da ordem posterior do Mestre (**60% por dia, 100% por ativação**). O recibo é preservado somente como evidência técnica da integração real, não tarifa aprovada. O validador retorna `PA_TARIFF_VERSION_MISMATCH` em vez de recalcular valores. O Executor PA competente deve corrigir a fonte e emitir recibo fresco, após o qual a receita pode ser reavaliada.

**Proteções:** sem escrita em Party/O Primeiro; `CRAFT/F5=RED`, `C19-021=UNKNOWN-EFFECT`, produção HOLD, sem writer/lease/epoch herdado.
