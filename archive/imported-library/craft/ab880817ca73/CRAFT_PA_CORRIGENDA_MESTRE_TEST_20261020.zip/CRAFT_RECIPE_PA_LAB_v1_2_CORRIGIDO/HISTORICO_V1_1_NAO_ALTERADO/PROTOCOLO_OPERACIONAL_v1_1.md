# ADENDO OPERACIONAL — ENGENHARIA DE RECEITAS × PA DIÁRIO · v1.1

**Âmbito:** MESTRE-SIDE / CRAFT CM-000002 WS0001 / OP-ARQ-RIN-REC-01. Ordem expressa Mestre 20/10/2026. **Status:** diretriz operacional do Mestre aplicável ao CRAFT-LAB TEST; corte normativo produtivo e tarifação PA dependem dos gates competentes. Sem nova norma autônoma. Sem poderes de writer.

**Precedência:** Mestre → NAC-NORM/NAC-CONT/NAC-PASS → PR-ITEM-02/REC-EXEC → PR-SC → Atlas/FIP/DMG competente → REC-MOD da família → PR-ECO/Anexo C → REC-LIN-SUB/REC-LIB/PR-CRN → este roteiro subordinado.

## Decisões que passam a governar o procedimento CRAFT em LAB

1. Produto antes de ingredientes: ficha-alvo, diferencial, usuário, comparadores e aplicação real.
2. Um projeto tem escopo declarado: **PESQUISA**, **LAB-TEST**, **USO PS/JIT**, **PRODUÇÃO**. Ordem LAB não autoriza publicação.
3. Buscar produto/receita e equivalentes globalmente antes de criar. Reutilizar/derivar, não duplicar.
4. Papel técnico de todo componente + propriedade extraída de fonte literal + estado E0/E1/E2/E3/PS + mecanismo e teste que pode refutá-lo.
5. BOM quantificada + processo como grafo; identidade de nós e aliases, conservação de material, intermediários, etapas, rendimentos, perdas e equipamento separado de consumível.
6. Cada módulo especializado da família é despacho obrigatório; acessórios devem contemplar ergonomia/slot, estrutura, fixação, core, interface, conforto, estabilidade e efeitos ativos/passivos, sem supor compatibilidade.
7. Poder/rank só pela mecânica com benchmarks Atlas, nunca por RIn, preço, ingredientes ou estética; não representar estrelas na classificação pública de item.
8. **GATE PA-OBRIGATÓRIO:** toda proposta mágica enumera PA/dia do item (piso por rank quando competente), parcelas passivas/ativas diárias, PA/ativação, usos no cenário, condições, duração, recarga, manutenção/cargas, proveniência de fonte, versão e confiança. Consultar o código externo PA; não copiar ou substituir sua matemática. Sem item mágico totalmente especificado e parecer compatível, RC5 e publicação ficam bloqueados.
9. **Compatibilidade semântica e normativa:** confrontar resposta do fornecedor com determinações posteriores do Mestre. A ordem vigente para habilidades ativas é 60% da base ao dia e uma base integral por ativação. **Conflito identificado:** R26 integrado em R28 usa 50% ao dia e 60% por ativação. Proibir converter saída R26 conflitante em tarifa oficial; emitir `PA_TARIFF_VERSION_MISMATCH` e acionar Executor PA. O guard apenas compara contrato, não recalcula o item.
10. **GATE ECONÔMICO:** quatro valores distintos: kit de insumos, CTE da fabricação/instalação, conhecimento e preço do produto. CTE = CI + CP + CF + CT + CE + CK + CL + CA + CC apenas com UTE, época, mercado, rendimento e custos demonstrados. PA não determina preço, e preço não determina rank.
11. **GATE AUTORIDADE:** RC0–RC5 = completude; P3/PS/P4 = autoridade; ocorrência = evento físico; conhecimento = quem sabe; publicação = decisão autorizada. São cinco estados diferentes.
12. **LAB-TEST EXCEÇÃO 20/10:** permitido UM projeto/receita inédita de item mágico, rigor de especificação equivalente ao de uma receita oficial, com premissas sinalizadas e fontes reais Mestre; 0 REC-IDs oficiais, 0 novos recursos/estoque/Party/O Primeiro, 0 mutação de mães de itens. RC4/RC5 indicativos de auditor NÃO são certificados técnicos de produção.
13. **F5 RED / C19-021 UNKNOWN:** não há fabricação oficial, venda, distribuição, catálogo, sincronização de player ou reivindicação de writer. R48 verdadeiro deve ser recuperado e testado para creditar fabricação; não substituir por uma simulação ad hoc.
14. Correções posteriores do Mestre prevalecem; fatos PS e E3 não se convertem em E0 por repetição. Mudar dependência material gera PRV apenas para descendentes pertinentes; preservar histórico.
15. Registro: ANTES → autorização/escopo LAB → artefato/testes → DEPOIS/readback → NAC-PASS TEST. Alterar norma produtiva requer NAC-NORM/PQN/NRM conforme impacto, MIE/TEE, regressão de afetados, GNN/GP-NAC, verificação independente e gate produtivo; nenhum texto de diretiva por si garante homologação total.

## Contrato mínimo de resposta conversacional no celular

**Ao Mestre sobre criação de item novo:** (a) produto útil, materiais e fontes; (b) efeito e rank sugerido com confiança; (c) BOM↔processo e QA; (d) energia PA diário e por uso com versão do fornecedor; (e) custo/mercado apenas com dados; (f) status RC e PS separados; (g) pendências realmente bloqueantes e próxima prova.

**Erro por falta do PA:** nunca omitir o campo e não preencher com 0. Progredir na concepção/fabricação TEST se independente da decisão PA; não liberar conclusão que dependa do consumo.

**Mais de duas iterações sem capacidade observável:** reavaliar abordagem, reduzir escopo, comparar produto de referência e testar hipótese mais discriminatória.

## Pistas de controle

- **Fonte-mãe:** PR-ITEM-02 / REC-EXEC.
- **Maturidade/risco:** PR-SC-01.
- **Energia:** PA R28→R27→R26 como fonte de código em TEST, sujeito à errata de tarifas pela autoridade PA.
- **Mecânica de família:** REC-MOD-REG-01 → REC-MOD-EQA-01 para pingente.
- **Fabricar:** somente R48 autêntico, quando recuperado e com estoque TEST.
- **Rastrear:** LABORATÓRIO CRAFT existente.
