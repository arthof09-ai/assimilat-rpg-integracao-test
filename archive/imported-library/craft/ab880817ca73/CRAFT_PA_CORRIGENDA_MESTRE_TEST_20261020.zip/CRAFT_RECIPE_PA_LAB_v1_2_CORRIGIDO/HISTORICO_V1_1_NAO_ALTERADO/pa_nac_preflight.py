#!/usr/bin/env python3
"""CRAFT recipe QA + external PA version-compatibility gate (TEST ONLY).
No new PA model, no reprice, no fabrication, no Notion write.
Consumes original receipt produced by R27/R26; compares tariff compatibility
against explicit Mestre directive, rejects stale provider versions.
"""
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec

BASE = Path(__file__).resolve().parent
QA = BASE / 'vendor' / 'recipe_qa.py'

def _load_qa():
    if not QA.is_file(): raise RuntimeError('AUTENTIC_QA_20261019_NOT_MATERIALIZED')
    s=spec_from_file_location('qa_original_20261019',QA); mod=module_from_spec(s);s.loader.exec_module(mod)
    return mod

# This is a version-interoperability guard, NOT a pricing engine. Rates are
# declared by the Master and are used to detect divergence in external receipts.
MASTER_POLICY = {
 'id':'MESTRE-PA-DIA-ATIVA-60PC-ATIVACAO-BASE-20261019',
 'source':'decisão expressa do Mestre: ativa 60% da base por dia, ativação igual base (prospectivo)',
 'ability_base':{'Bronze':6,'Prata':12,'Ouro':24,'Ouro Negro':35,'Lendário':50},
 'active_daily_numerator':60,'active_daily_denominator':100,
 'rounding':'floor','active_activation_multiplier':1,
 'item_daily_floors':{'Bronze':8,'Prata':11,'Ouro':21,'Ouro Negro':35,'Lendário':90},
 'status':'MASTER_DECISION_TO_BE_PROPAGATED_TO_PA_OWNER; NOT_PROVIDER_RELEASE'
}

def _policy_comparison(r):
    problems=[];details=[]
    for p in r.get('habilidades',[]):
        rank=p.get('rank_efeito_proposto');mode=p.get('modalidade');base=MASTER_POLICY['ability_base'].get(rank)
        if base is None:
            problems.append('EFFECT_RANK_UNKNOWN:'+str(p.get('nome')));continue
        if mode=='ATIVA':
            required_day=(base*60)//100
            required_use=base
            observed_day,observed_use=p.get('pa_por_dia'),p.get('pa_por_ativacao')
            if observed_day!=required_day or observed_use!=required_use:
                problems.append('PA_R26_STALE_ACTIVE_TARIFF:'+p['nome'])
            details.append({'nome':p.get('nome'),'effect_rank':rank,'provider_daily':observed_day,'provider_activation':observed_use,'compatible':observed_day==required_day and observed_use==required_use})
        elif mode=='PASSIVA':
            observed_day=p.get('pa_por_dia')
            if observed_day!=base: problems.append('PA_PROVIDER_PASSIVE_MISMATCH:'+p['nome'])
            details.append({'nome':p.get('nome'),'effect_rank':rank,'provider_daily':observed_day,'compatible':observed_day==base})
        else:problems.append('PA_MODE_UNKNOWN:'+p.get('nome','?'))
    return problems,details

def gate(recipe,pa_receipt,*,r48_executable=False):
    qa=_load_qa().audit(recipe)
    problems,detail=_policy_comparison(pa_receipt)
    if pa_receipt.get('contrato')!='PA-CRAFT-QMC05-COMPAT-R27/1.0.0-TEST':
        problems.append('PA_PROVIDER_CONTRACT_INVALID')
    if pa_receipt.get('item',{}).get('historico'):
        problems.append('HISTORIC_PA_MUST_NOT_BE_REPRICED')
    if pa_receipt.get('custo_pa',{}).get('pa_por_dia') is None:
        problems.append('PA_PROVIDER_TOTAL_NOT_CLOSED')
    if pa_receipt.get('gate')!='CONSULTA_TEST_COMPLETA_COM_REVISAO_JIT':
        problems.append('PA_PROVIDER_UNQUALIFIED_GATE')
    if pa_receipt.get('governanca',{}).get('craft_f5')!='RED_PRODUCAO_HOLD':
        problems.append('PRODUCTION_STATE_UNEXPECTED')
    if not r48_executable:problems.append('R48_EXECUTABLE_BINARY_NOT_MATERIALIZED')
    if recipe.get('risk',{}).get('sc') in ('SC-3','SC-4'):
        problems.append('HIGH_RISK_SC_REQUIRES_MESTRE')
    # A full TEST brief is not proof of magical transmutation or successful
    # fabrication; keep original 'RC5 indicative' separate from official RC5.
    problems.append('MAGICAL_TRANSFER_NOT_PHYSICALLY_DEMONSTRATED')
    blocks=len(qa.get('findings',[]))
    return {
        'contract':'CRAFT-RECIPE-PA-GATE/1.1.0-TEST',
        'status':'HOLD_RECEITA_MAGICA_RC5_NAO_COMPROVADA' if problems or blocks else 'READY_FOR_FURTHER_TEST_ONLY',
        'recipe_hash':hashlib.sha256(json.dumps(recipe,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
        'pa_receipt_id':pa_receipt.get('id_entrada_sha256'),
        'pa_policy_id':MASTER_POLICY['id'],
        'pa_version_compatible':not any(x.startswith('PA_R26_STALE') or x.startswith('PA_PROVIDER_') for x in problems),
        'pa_tariff_observation':detail,
        'pa_provider_reported_total_not_approved':pa_receipt.get('custo_pa',{}),
        'qa_ceiling_test_only':qa['rc_ceiling_test'],'qa_block_count':qa['blocks'],
        'qa_codes':[x['code'] for x in qa['findings']],
        'non_pa_gates':problems,
        'r48_execution':'BLOQUEADO_BINARIOS' if not r48_executable else 'EXECUTOR_DEPENDE_DE_TESTE_PROPRIO',
        'production':'DENY','record_notional':'NO','party_write':False,'official_rec_ids':0,
        'source_labels':'Fontes Notion Mestre E0 + PS/E2; números físicos e efeitos reproduzidos são PROPOSTOS em TEST',
    }

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('python pa_nac_preflight.py receita.json recibo_pa_r27.json')
    a=json.loads(Path(sys.argv[1]).read_text());b=json.loads(Path(sys.argv[2]).read_text());
    print(json.dumps(gate(a,b),ensure_ascii=False,indent=2,sort_keys=True))
