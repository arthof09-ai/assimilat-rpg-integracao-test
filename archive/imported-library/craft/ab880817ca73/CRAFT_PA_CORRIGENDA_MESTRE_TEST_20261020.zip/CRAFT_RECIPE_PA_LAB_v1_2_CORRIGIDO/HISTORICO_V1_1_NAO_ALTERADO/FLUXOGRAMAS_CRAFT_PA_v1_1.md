# FLUXOS CRAFT — PR-ITEM-02/REC-EXEC × PA UNIVERSAL · V1.1 LAB TEST

**Autoridade:** ordem expressa do Mestre em 20/10/2026 para aperfeiçoar e regulamentar metodologia, inserindo custos diários no fluxo; aplicação imediata no laboratório isolado. Não substitui PR-ITEM-02, PR-SC, PR-ECO, REC-MOD, NAC-NORM ou motor PA. Não autoriza produção. 

**Genealogia:** seis fluxos CRAFT-RECIPE-QA-TEST-20261019, preservados no ZIP original. Este documento integra esses seis fluxos com gates energéticos, resultado de R28 e a exceção autorizada para **uma receita exclusivamente TEST**.

## F1 — Produto primeiro, poder e recursos com evidência

```mermaid
flowchart TD
 A[Pedido Mestre ou lacuna real] --> B{Tipo de autorização?}
 B -->|Somente método| C[Auditar e refinar fluxo]
 B -->|LAB TEST expressamente autorizado| D[Escolher produto e propósito]
 B -->|Produção| P{Writer + GREEN + PA competente + NAC?}
 P -->|Não| H[HOLD produção]
 P -->|Sim| D
 D --> E[BUSCA global: item, receita, linhagem, substituto]
 E --> F{Existe equivalente?}
 F -->|Sim| G[Reusar / derivar; não duplicar]
 F -->|Não| I[Selecionar REC-MOD real]
 I --> J[Definir efeito, usuário, alvos e limitações]
 J --> K[Fontes Mestre com proveniência e função]
 K --> L{Cadeia fonte→processo→efeito sustentável?}
 L -->|Não| M[Reformular ou descartar]
 M --> J
 L -->|Sim| N[Construir BOM/processo/QA]
 N --> O[Consultar PA externo com tarifas tipadas]
 O --> Q[Economia, risco SC, compatibilidade, red team]
 Q --> R{RC5 técnico + PA compatível + NAC produtivo?}
 R -->|Não| S[PENDENTE/HOLD com próxima prova]
 R -->|Sim| T[REC-LIB única, somente com permissão]
```

## F2 — Engenharia causal de magia com fonte física

```mermaid
flowchart TD
 A[Efeito-alvo e limites] --> B[Comparadores Atlas + efeito + caso vivo]
 B --> C[Recuperar fonte Mestre exata]
 C --> D{Propriedade literal ou E2 revisável suporta função?}
 D -->|Não| E[Retirar ingrediente / não inventar poder]
 D -->|Sim| F[Papel: core, vetor, buffer, substrato, ligante]
 F --> G[Transformação físico-mágica hipotética]
 G --> H{Falsificável, sem dupla contagem?}
 H -->|Não| I[Reprojetar mecanismo]
 H -->|Sim| J[Processo ↔ QA de transferência e falha]
 J --> K[Rank do EFEITO pelo Atlas; preço isolado]
 K --> L[Separar passiva, ativa e condição]
 L --> M[Enviar efeitos e comparadores ao fornecedor PA]
```

## F3 — A cadeia de fabricação

```mermaid
flowchart TD
 A[BOM unidades e procedência] --> B{RC2 coerente?}
 B -->|Não| C[Corrigir quantidade ou identidade com fonte]
 B -->|Sim| D[Etapas e intermediários]
 D --> E{BOM↔processo 1:1?}
 E -->|Não| F[Órfão, insumo extra, consumo duplo → HOLD]
 E -->|Sim| G{Sem loop, rendimento coerente?}
 G -->|Não| H[Rever transformação]
 G -->|Sim| I[RC3 indicativo]
 I --> J[Tempo + ferramenta + especialista + condições + QA]
 J --> K{Medição real ou premissas rotuladas?}
 K -->|Não| L[Não declarar fabricação RC4]
 K -->|Sim| M[RC4 indicativo TEST]
 M --> N[PA, economia, JIT, módulo e autorização são gates independentes]
```

## F4 — Estados editoriais e fabricação

```mermaid
flowchart TD
 A[Produto proposto] --> B[Separar item, receita, conhecimento, ocorrência]
 B --> C[RC0–RC5: completude técnica]
 C --> D[P3/PS/P4: autoridade separada]
 D --> E{Origem LAB?}
 E -->|Sim| F[LAB: projeto apenas; nenhuma ocorrência oficial]
 E -->|Não| G{Autoridade, writer, GREEN, NAC-PASS produtivo?}
 G -->|Não| H[HOLD sem REC-ID ou estoque]
 G -->|Sim| I[Registro físico único REC-LIB + readback]
 I --> J{Conhecimento da Party autorizado?}
 J -->|Não| K[MESTRE-ONLY]
 J -->|Sim| L[Player-safe somente após sync apropriada]
```

## F5 — Diagnóstico e correção pontual

```mermaid
flowchart TD
 A[Erro observável] --> B{Falha técnica local ou causal?}
 B -->|Local| C[Corrigir só nó afetado mediante fonte]
 B -->|Causal| D[Retornar ao efeito e ao papel do componente]
 C --> E[Reexecução adversarial]
 D --> F{Alternativa S0/S1/S2/NO/PENDENTE?}
 F -->|S0 ou S1| E
 F -->|S2| G[Derivada, sem apagar mãe]
 F -->|NO ou PENDENTE| H[HOLD / rejeitar]
 G --> E
 E --> I{Mudou dependência material?}
 I -->|Sim| J[PRV apenas descendentes pertinentes]
 I -->|Não| K[Preservar histórico]
 J --> K
```

## F6 — PA por dia/ativação e economia

```mermaid
flowchart TD
 A[Item mágico: efeitos estruturados] --> B[Separar passiva/ativa, modo, duração, frequência]
 B --> C[Obter recibo do motor UNIVERSAL, versão e provenance]
 C --> D{Provider real e contrato íntegro?}
 D -->|Não| H[PA PENDENTE; não criar calculadora paralela]
 D -->|Sim| E{Tarifa diária e de ativação correspondem à última ordem do Mestre?}
 E -->|Não| F[QUARENTENA tarifa desatualizada; abrir errata ao dono PA]
 E -->|Sim| G[PA diário + PA/ativação + manutenção/cargas separados]
 G --> I{Todos os campos, RI e mecânica suficiente?}
 I -->|Não| H
 I -->|Sim| J[Estimativa semicanônica revisável, nunca publicação automática]
 J --> K[PR-ECO UTE/CTE: custo físico separado de gasto PA]
 K --> L[RC5 só após QA, SC, JIT e gates produtivos]
```

## F7 — Laboratório TEST para qualidade oficial sem item canônico

```mermaid
flowchart TD
 A[Ordem expressa Mestre LAB] --> B[Reservar escopo; REGISTRAR ANTES]
 B --> C[Escolher um item útil e os comparadores reais]
 C --> D[Propor BOM, processo e números TEST com selo]
 D --> E[Auditor QA existente + módulo especializado]
 E --> F[Consultar QMC05/PA R27-R28 real]
 F --> G{Provedor PA compatível?}
 G -->|Não| H[CONFLITO PA → HOLD só do eixo energético]
 G -->|Sim| I[Parecer energético semicanônico TEST]
 H --> J[Continuar ensaios físicos não dependentes]
 I --> J
 J --> K{Runner R48 autêntico materializado?}
 K -->|Não| L[R48 HOLD; não fingir fabricação]
 K -->|Sim| M[Runner isolado, sem estoque real]
 M --> N[Rejeição/QA, recibo + replay]
 L --> N
 N --> O[DEPOIS + readback + NAC-PASS proporcional]
 O --> P[LAB TEST jamais cria REC-ID/Party/item oficial]
```

**Critérios transversais:** uma URL não é byte; testemunho não é medição; 60% diário ativo e custo por ativação integral são ordem Mestre a exigir no provedor, não conta do CRAFT; ausência de dados significa PENDENTE; progresso em uma família não certifica todas as famílias; falha de E0/SC3/4 ou conflito NAC bloqueia apenas a transição dependente.
