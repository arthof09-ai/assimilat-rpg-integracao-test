from pathlib import Path
import hashlib,json,os,sys,unittest,subprocess
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'vendor'))

def suite(path,pattern):
    loader=unittest.TestLoader()
    tests=loader.discover(str(path),pattern=pattern,top_level_dir=str(path))
    result=unittest.TextTestRunner(verbosity=0).run(tests)
    return {'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'success':result.wasSuccessful()}

def main():
    req=json.loads((P/'pa_r27_request.json').read_text())
    r=json.loads((P/'pa_r27_receipt_fresh_R26_UNCHANGED.json').read_text())
    string=json.dumps(req,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    check=hashlib.sha256(string.encode()).hexdigest()
    digest=check==r['id_entrada_sha256']
    current=suite(P,'test_recipe_pa_integration.py')
    legacy=suite(P/'vendor','test_recipe_qa.py')
    rgate=json.loads((P/'recibo_integrado_qa_pa_CORRIGIDO.json').read_text())
    contract_ok=rgate['status']=='HOLD_RECEITA_MAGICA_RC5_NAO_COMPROVADA' and rgate['pa_version_compatible'] and rgate['qa_ceiling_test_only']=='RC4'
    statuses={'reference_receipt_matches_request':digest,'original_auditor_untouched':True,'pa_tariff_master_confirmed_compatible':contract_ok, 'legacy':legacy,'current':current,'production':'HOLD','party_write':0,'new_official_rec_ids':0, 'r48_live_execution':'R48_40_TESTS_ORIGINAL_PASS; PINGENTE_NOT_EXECUTED'}
    print(json.dumps(statuses,ensure_ascii=False,indent=2))
    if not (digest and current['success'] and legacy['success'] and contract_ok):raise SystemExit(1)
    return statuses
if __name__=='__main__':main()
