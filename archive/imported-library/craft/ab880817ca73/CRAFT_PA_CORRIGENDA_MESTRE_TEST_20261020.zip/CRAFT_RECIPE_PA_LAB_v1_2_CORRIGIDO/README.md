# CRAFT / Correção de interface PA — 20/10/2026

**Mestre corrigiu expressamente a interpretação do Executor CRAFT.** O motor PA R26/R27 original estava correto. O pré-validador CRAFT v1.1 exigia erroneamente 60% ativo/dia e 100% ativação.

A correção v1.2 é aditiva; o ZIP v1.1 inteiro e arquivos históricos pré-imagem estão preservados. Arquivos corrigidos: `pa_nac_preflight.py`, `test_recipe_pa_integration.py`, `receita_test_input.json`, `run_lab.py`, `recibo_integrado_qa_pa_CORRIGIDO.json`, `pa_r27_receipt_fresh_R26_UNCHANGED.json`, documentos v1.2.

**Tarifa correta:** passiva 100% base/dia; ativa 50% base/dia e 60% base por ativação; piso rank ITEM independente. Bronze base6/ativa3/uso3/piso8; Prata12/6/7/11; Ouro24/12/14/21; Ouro Negro35/17/21/35; Lendário50/25/30/90.

**Caso TEST Pingente da Vigília Boreal:** dois efeitos, E3; 12 PA/dia + 14 PA pelas duas ativações = 26 PA no dia. Nenhuma tarifa nova foi inventada, reconsulta fresca ao fornecedor R27/R26 original; não é item canônico. RC5 continua HOLD por transferência mágica não provada e F5 RED/C19-021 UNKNOWN.

Execute `python run_lab.py` e `python verify_manifest.py` nesta pasta. A prova de reconsulta fresca está em `pa_r27_receipt_fresh_R26_UNCHANGED.json`, cujo input hash coincide com o original imutável. Código do PA R26/R27 não foi alterado.

A correção documental Notion nos sete pontos competentes é separada do software e exige readback próprio.

**Atualização R48:** os bytes originais foram recuperados e autenticados após o primeiro diagnóstico. Fonte `CRAFT-COMESTRE-CHAT-v03.zip` (SHA-256 `5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434`); motor R48 40/40 testes PASS; adaptador FC04 histórico recuperado SHA-256 `5756bdf2e6e0550336d483c0c749a411ab345bf39b1168d585d1a883f077bf9b` e readback independente PASS em cópia.
A fábrica R48 original aceita apenas `SBX-TLI-R44-v1` e `SBX-MICA-R44-v1`; FC04 inclui estojo B30-22, **não o Pingente de Vigília Boreal**. A pendência não é mais a disponibilidade do motor, e sim um adaptador/ensaio compatível com nova receita, além de validação do mecanismo mágico. Não converter QA estático `RC5` em RC5 material; capa de gate limita a `RC4 TEST`.
