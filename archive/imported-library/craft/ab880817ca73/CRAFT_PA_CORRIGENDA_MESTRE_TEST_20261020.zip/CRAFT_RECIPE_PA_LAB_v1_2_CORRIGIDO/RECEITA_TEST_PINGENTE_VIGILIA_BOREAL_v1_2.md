# LAB CRAFT — Receita TEST: Pingente da Vigília Boreal

**Natureza:** projeto autoral experimental criado APENAS sob autorização expressa do Mestre de 20/10/2026. Não é receita oficial, página REC-LIB, produto fabricado, item canônico, conhecimento da Party ou ordem para fabricar. Não atribuir REC-ID produtivo. **Case-id LAB:** `LAB-CRAFT-VIGILIA-BOREAL-20261020-001`.

## I — Necessidade e identidade

- **Finalidade:** acessório pessoal de exploração noturna: iluminação útil sem concessão de visão absoluta e alívio momentâneo contra uma área muito pequena de escuridão mágica.
- **Família:** Equipamentos/Roupas/Acessórios (`REC-MOD-EQA-01`).
- **Classificação nominal de projeto:** **Prata, PROPOSTA E3**, sem estrelas públicas. Posicionamento FIP interno INDETERMINADO.
- **Comparadores de efeito:** [Cristal de Aurora Boreal](https://app.notion.com/p/3edc2b324ede818b9d7ad75d42f2afa2), [Erva da Luz do Norte](https://app.notion.com/p/3edc2b324ede81deb8cec70bf5ca7150), [Véu de Eärendil](https://app.notion.com/p/3edc2b324ede813e8efaf8de2050fd9b) e [Atlas de Poder](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab). É utilitário distinto do Véu: o Véu se protege de escuridão, o pingente pretende abrir um trecho visual próximo; não concede imunidade mágica.
- **Valor de ineditismo:** buscas dirigidas por função, broche, aurora e anti-escuridão não encontraram fórmula física homônima. Isso NÃO comprova inexistência global; é anti-duplicata proporcional ao TEST.

## II — Descrição física / interface

Pequeno cristal auroral preso em laço/trança de fibra vegetal, com folhagem luminosa conservada atrás da gema. Porta-se ao pescoço, na altura do peito. Forma, dimensões, peso, espessura e aparência finais **PROPOSTOS**, não fotografados, fabricados nem medidos. Exige teste de atrito cutâneo, desprendimento, conforto com armadura e interferência luminosa. Não concede bônus de CA, atributo ou RD.

## III — Fonte → função → mecanismo → ensaio

| Componente | Evidência da fonte / autoridade | Papel indispensável | Transformação proposta | Ensaio discriminatório |
|---|---|---|---|---|
| 1 Cristal de Aurora Boreal | Ficha Mestre documenta luz e dissipação de escuridão; RIn Ouro/E2/PS revisável | Core de luz contra escuridão | Acoplamento limitado ao usuário pelo suporte | Verificar se o cristal conserva sua ação quando montado; comparar efeito isolado x montado |
| 1 Erva da Luz do Norte | Ficha Mestre documenta luz auroral e revelação de magias ocultas; RIn Prata/E2/PS revisável | Reserva para luminescência passiva | Folhas iluminam de modo sustentado após preparo | Monitorar duração sem suposição de fonte infinita; controle com folhas comuns |
| 0,45 m de Fibra de Casca Boreal | Material F5 PS de função física (amarrar/estruturar), não mágico | Ligante/estrutura, fio e suspensão | Trançar suporte de folha e cristal | Ensaio de ruptura e manuseio; substituir por fibra comum sem reivindicar poder |

**OBS:** `0,45 m` é número de engenharia de TEST, não medida canônica do recurso; a ficha PS não possui unidade normalizada/rendimento validado. Quantidades de folhas efetivamente aproveitáveis, fração de perda e estabilidade da peça são PENDENTES.

## IV — Efeito pretendido, sem inventar poderes

**Passiva — Luminescência de Vigília (Bronze E3 sugerido):** enquanto equipado, a folhagem fornece luz suave pessoal em **raio proposto de 1 m**. Não revela invisibilidade, não cura cegueira, não dissipa sombras mágicas por si, não atravessa barreiras e não permite visão através de fumaça. Só funciona enquanto sua carga luminosa estiver preservada; frequência de recarga NÃO demonstrada.

**Ativa — Abertura de Contrassombra (Prata E3 sugerido):** mediante **1 Ação Padrão**, por **1 turno**, o portador abre uma **faixa visual de até 1 m** adjacente a ele através de escuridão mágica. Até **2 ativações/dia** como limite de design. Não encerra nem enfraquece globalmente a magia hostil, não é contra-ataque, não causa dano, não interfere fora da área próxima, não cura cegueira e não ativa se o portador estiver incapaz de enxergar. O alcance, a duração, os limites e a frequência são **PARÂMETROS PROPOSTOS TEST**, não derivados literalmente da fonte.

A transição de “um cristal que dissipa escuridão” para “um pingente capaz de canalizar isso ao portador por um turno” é a hipótese central ainda **NÃO DEMONSTRADA**. Nada foi magicamente fabricado ou observado. A falha nesse ensaio reprova a habilidade ou exige reformular o dispositivo — não autoriza criar poder por conveniência.

## V — BOM, sequência e rastreabilidade

**BOM:** três materiais de fontes reais acima; cada unidade é gasto conceitual apenas na fixture TEST. Ferramenta reutilizável de trançar, bancada e conhecimento de artesão são recursos de produção, **não** ingredientes consumidos; identidade/especialista concretos ainda dependem de fonte.

**Grafo:** fibra → cordão; erva → folhas luminescentes preparadas; {cordão + folhas + cristal} → pingente bruto; pingente bruto → *hipótese de calibração mágica* → pingente funcional. Quatro operações, cada entrada/saída com ID. Nenhum nó ganha massa ou efeito não explicado. Rendimento de intermediários, estabilidade e transformação energética necessitam teste.

**Procedimento de bancada — SIMULADO / PROPOSTO:** selecionar material íntegro → separar folhagem → torcer cordão → fixar cristal sem cola/metais adicionais → calibrar ligação mágico-visual → inspecionar retenção e segurança → ensaiar em ambiente controlado. Tempo `55 minutos` é convenção de scenario TEST, não duração física constatada. A etapa de calibração não possui método comprovado no corpus.

## VI — Controles e falhas

- **Falha física:** nó rompe, gema se solta, folhas perdem brilho; reprovar lote antes de uso.
- **Falha funcional:** gema brilha mas não abre visão local em sombra mágica; reprovar efeito ativo. Luminescência mundana NÃO prova poder mágico.
- **Falha de sistema:** fonte E2/PS mudada, exigência ambiental não satisfeita, item incapaz de cumprir mecanismo; marcar PRV e JIT-SC.
- **Confusão de orçamento:** PA diário de vestir o pingente NÃO é PA de fabricação; duas ativações não pagam a taxa diária automaticamente.
- **Contra-exemplos:** cegueira, parede opaca, escuridão fora de alcance, ausência de luz retida, uso de fibra comum, tentativa de remover magia inteira, ativação em outro alvo.
- **QA:** comparar suporte com material comum, observar brilho não mágico em controle e, somente com engine apropriada, testar visão local em magia de escuridão. **Nenhum teste de magia física foi executado.**

## VII — PA diário: chamada do fornecedor competente e correção Mestre

**Motor efetivamente chamado em TEST:** adaptador autêntico R27 importando motor R26 da distribuição R28 recuperada. `CONSULTAR_PA_TEST`, entrada com duas habilidades, comparadores Notion e parecer E3.

| Modalidade | Resposta R27/R26 reconsultada | Situação vigente |
|---|---|---|
| Passiva Bronze | 6 PA/dia | Tarifa correta; rank da habilidade E3 TEST |
| Ativa Prata | 6 PA/dia + 7 PA/uso | **Correto pela última confirmação expressa do Mestre**; rank E3 TEST |
| Item Prata com 2 ativações | 12 PA/dia + 14 PA em 2 ativações = 26 PA no cenário | **TARIFA PROSPECTIVA TEST VALIDADA**, efeito mágico não fabricado |

**Conflito documental resolvido pelo Mestre:** o R26 do pacote R28 está CORRETO (ativa 50% base/dia e 60% base/ativação). O pré-validador v1.1 do CRAFT estava ERRADO ao exigir 60% base/dia e base integral/ativação. A reconsulta ao fornecedor original com a mesma entrada reproduziu 12 PA/dia e 7 PA por ativação; piso Prata 11 verificado. **Apenas o bloqueio energético indevido foi removido.** Não reprecificar itens históricos, não inferir demonstração da magia, não criar RC5, P4 nem item real.

## VIII — Economia / UTE / logística

O preço de mercado e CTE por unidade **não são determináveis**. A erva possui estimativa antiga de cerca de 320.000 MED/unidade com confiança baixa e faixa 120.000–800.000 MED no texto da fonte, mas não é preço realizado do mesmo contexto da receita. Cristal e fibra carecem de cotações adequadas comparáveis, rendimentos reais, mão de obra, ferramenta, transporte entre origem e local e taxa de falhas. Manter separado kit, fabricação, conhecimento e produto. Não utilizar preço como evidência de rank.

**Gargalos:** coleta da erva na R06/taiga; cristal sob condições de aurora/caverna gelada conforme fonte; fibra PS na R01 exige fonte biológica real ainda não validada. Nenhuma rota, entrega, estoque ou safra ocorreu.

## IX — Social, conhecimento e Party

Somente projeto Mestre-side; artesão hipotético, nenhuma guilda, facção, comprador, cidade ou versão Player criada. Personagens não conhecem nem possuem a receita. O valor estratégico e eventual descoberta são cenários possíveis, não fatos históricos.

## X — Resultado dos gates e aceite

- **Receita documental:** BOM rastreável, papéis reais e quatro passos auditáveis; **RC4 indicativo TEST** pelo pré-validador reaproveitado, sem valor de fabricação física.
- **RC5:** HOLD por transferência mágica não demonstrada, fonte fibra PS sem medidas/rendimento, especialista/ferramentas/perdas não comprovados e ausência de adaptador/ensaio do Pingente no R48 verdadeiro. O auditor estático isolado pode indicar RC5(TEST) pelo preenchimento; gate independente limita prontidão RC4(TEST).
- **PA:** R27/R26 original reconsultado na auditoria independente; tarifa COMPATÍVEL com Mestre, 12 PA/dia +7 por ativação, total 26 PA no cenário TEST; rank dos efeitos E3 e sujeição a revisão.
- **R48:** engine original recuperado e 40/40 testes PASS; mecanismo disponível, **receita do Pingente não adaptada nem executada**. Histórico FC04 com auditoria independente PASS, mas apenas para fixtures B30-01/03/22, sem poder mágico do Pingente.
- **F5:** RED; C19-021 UNKNOWN; Writer/lease/fencing não assumidos; NAC-PASS produtivo HOLD.
- **Próximo experimento decisivo:** investigar a transferência real de luz/ação cristalina à peça, desenhar ensaio discriminatório e adaptar caso do Pingente à entrada R48 em sandbox sob controle competente. O motor PA e o R48 original já foram recuperados e NÃO exigem reinvenção.

**Regra de interpretação:** documentar com qualidade profissional não é o mesmo que satisfazer evidência empírica RC5. O Mestre autorizou precisamente a tentativa em laboratório — não a canonização de seus resultados.


## ERRATA CONFIRMADA PELO MESTRE — 20/10/2026 (CRAFT v1.2, prospectivo)

O texto histórico v1.1 que exige **60% base/dia e 100% base/ativação** foi INCORRETO. **Não** tratar o motor PA R26/R27 como desatualizado. A regra correta, confirmada pelo Mestre: **passiva = base inteira por dia; ativa = floor(base/2) por dia; ativação = floor(0,6×base) por uso**, com piso do ITEM independente (Bronze 8, Prata 11, Ouro 21, Ouro Negro 35, Lendário 90).
Bases de habilidades (B/P/O/ON/L): 6/12/24/35/50. A tabela por ativa diária é 3/6/12/17/25; por ativação 3/7/14/21/30.
No Pingente TEST Prata (passiva Bronze, ativa Prata, duas ativações), a resposta **12 PA/dia + 7 por uso = 26 PA no cenário** é CORRETA pela política vigente, E3 semicanônica. Quarentena energética por suposta divergência: **RETIRADA**. RC5 continua HOLD por hipótese mágica, medições, QA físico/R48, F5 RED e C19-021 UNKNOWN.
Esta seção corrige interpretação do CRAFT, não apaga documentos originais nem altera PA de itens históricos, receitas oficiais ou Party.
