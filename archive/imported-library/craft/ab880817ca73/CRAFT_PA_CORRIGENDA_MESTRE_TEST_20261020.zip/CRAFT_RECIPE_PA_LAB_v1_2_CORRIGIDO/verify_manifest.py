from pathlib import Path
import hashlib,json,sys
base=Path(__file__).resolve().parent
manifest=json.loads((base/'MANIFEST.json').read_text())
errors=[]
for f,expected in manifest['sha256'].items():
    p=base/f
    if not p.is_file(): errors.append('ausente: '+f); continue
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    if h!=expected:errors.append('hash divergente: '+f)
print(json.dumps({'checked':len(manifest['sha256']),'errors':errors,'pass':not errors},ensure_ascii=False))
if errors:sys.exit(1)
