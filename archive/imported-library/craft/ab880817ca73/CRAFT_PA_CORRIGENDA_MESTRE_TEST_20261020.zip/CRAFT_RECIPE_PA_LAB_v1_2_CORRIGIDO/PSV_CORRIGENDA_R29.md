# PSV — ERRATA EXECUTOR CRAFT/PA — 20/10/2026

**DECISÃO MESTRE:** motor R26/R27 correto; CRAFT `MASTER_POLICY` v1.1 incorreta.

**EVIDÊNCIA:** SHA256 original CRAFT ZIP `9c2e299de21a36a8c3d93c781c32ad1cb946ba264b9429e3d46478c2fd3990e9`; PA R28 ZIP `68acc4405250cbf03a89924fa4df1f3d36586f26a5a903610c6600e8f26a391e`; reconsulta mesma entrada original `815b6600c3fca27b030da4326159ea740fda98709e6581caf92eed37b85bd379`.

**DEPOIS:** ativa diária floor(0,5base), ativação floor(0,6base); 12 PA/dia e 7 PA/uso no Pingente TEST; gate energética PASS; RC5 HOLD por hipóteses materiais. Preservadas fontes Mestre/Party, CRAFT/F5 RED, C19-021 UNKNOWN, writer não herdado.

**LIMITES:** classificação E3 não é 100% precisa por definição, comparadores precisam revisão humana ou semicanônica, testes estáticos não provam fabricação nem magia.

**AUDITORIA R48 RECUPERADO:** 40/40 testes originais aprovados; histórico FC04 4 stores íntegros e órfão intencional fail-closed. A fábrica original não possui receita/QA de Pingente; `R48_RECIPE_ADAPTER_AND_EXECUTION_NOT_PROVEN` e `MAGICAL_TRANSFER_NOT_PHYSICALLY_DEMONSTRATED` mantêm RC5 HOLD.
**ACHADO SECUNDÁRIO:** quando PA é correto, o QA estático passa a indicar RC5(TEST) por campos preenchidos; o gate do consumidor deliberadamente limita RC4(TEST) porque eficácia mágica não é verificada.
