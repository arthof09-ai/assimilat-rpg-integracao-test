"""Integrity/format checker for FC05 additive delta; uses only standard library."""
from pathlib import Path
import json,hashlib,sys
base=Path(__file__).resolve().parent
m=json.loads((base/'MANIFEST_SHA256.json').read_text())
errors=[]
for relative, meta in m['files'].items():
 p=base/relative
 if not p.is_file():errors.append('MISSING:'+relative);continue
 raw=p.read_bytes()
 if len(raw)!=meta['bytes']:errors.append('SIZE:'+relative)
 if hashlib.sha256(raw).hexdigest()!=meta['sha256']:errors.append('HASH:'+relative)
all_files={x.relative_to(base).as_posix() for x in base.rglob('*') if x.is_file() and '__pycache__' not in x.parts and x.name!='MANIFEST_SHA256.json'}
if set(m['files'])!=all_files:errors.append('DENOMINATOR_DRIFT:'+repr(sorted(all_files^set(m['files']))))
print(json.dumps({'ok':not errors,'checked':len(m['files']),'errors':errors,'scope':'FC05_DELTA_ONLY','historical_writes':0},indent=2))
sys.exit(1 if errors else 0)
