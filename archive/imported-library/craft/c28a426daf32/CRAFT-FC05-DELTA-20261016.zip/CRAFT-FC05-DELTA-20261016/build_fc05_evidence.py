from pathlib import Path
import json,zipfile,hashlib
root=Path('/mnt/data/CRAFT-FC05-DELTA-20261016')
def write_json(name,data):
 p=root/'outputs'/name
 if p.exists():raise FileExistsError(p)
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n')

def name(n):return n.replace('CRAFT-FAST-CLOSE-03/','').replace('CRAFT-R48-B30-22-FC04/','')
with zipfile.ZipFile('/mnt/data/CRAFT-FAST-CLOSE-03-DELTA-20261016.zip') as z03,zipfile.ZipFile('/mnt/data/CRAFT-R48-B30-22-FC04-DELTA-20261016.zip') as z04:
 a={name(n) for n in z03.namelist() if not n.endswith('/')};b={name(n) for n in z04.namelist() if not n.endswith('/')}
 delta={'fc03_member_count':len(a),'fc04_member_count':len(b),'overlapping_relative_paths':sorted(a&b),
        'fc04_distinct_code':sorted(x for x in b if x.startswith('code/') and x not in a),
        'fc04_primary_outputs':sorted(x for x in b if x.startswith('outputs/ACCEPTED_V2/') and x.count('/')==2),
        'historical_engines_modified':False,'baseline_archive_preserved':True,
        'note':'Different additive file packages; not a proof of every code semantic change.'}
 write_json('baseline_fc03_fc04_delta_map.json',delta)

write_json('b30_22_sources_process.json',{
 'status':'MESTRE_SIDE_DOC_ANALYSIS_NOT_NOTION_CURRENT_READBACK',
 'product':'Estojo Articulado de Quitina / propondo apenas porta-amostra plano',
 'authorities':{'source':'BACKFILL-30 local historical snapshot of Notion PS pages; Notion fresh fetch unavailable',
 'norms':['PR-ITEM-02 REC-EXEC','REC-LIB-01','PR-ECO-01 Anexo C','PR-SC-01','REC-LIN-SUB-01']},
 'materials':[
  {'slot':'PANEL-A/B','quantity':2,'unit':'placa min 60x30 mm (PROPOSTO)',
   'source':'https://app.notion.com/p/3f3c2b324ede8141acddf0bb23ffe56c',
   'crn':'CRAFT-F5-R02-DROP-04','description':'PS quitina de Exoesqueleto do Escorpião Ártico',
   'known':'material source and intended rigid panel application from PS, not measured mechanics or stock',
   'unknown':['minimum verified plate size','cutting fracture limit','effective density','surface porosity','mechanical properties','decontamination method']},
  {'slot':'JOINT+TIE','quantity':30,'unit':'cm (PROPOSTO)',
   'source':'https://app.notion.com/p/3f3c2b324ede815ab04ace5bd1074e79',
   'crn':'CRAFT-F5-R01-OUT-01','description':'PS Fibra de Casca Boreal',
   'known':'structural fibre with manual twist potential on PS page; direct material consumption, NOT finished B30-02 cordage',
   'unknown':['fiber minimum length per thread','knot reliability','tensile/abrasion limits','wet performance','sustainable harvest yield']}
 ],
 'process':[
  {'step':1,'operation':'PS material acceptance / quality and legitimate origin','input':'2 intact chitin plates; 30cm prepared fiber', 'evidence':'NOT YET MATERIAL VERIFIED'},
  {'step':2,'operation':'hygiene and safe handling','input':'plates; reusable hand tools; protective equipment', 'evidence':'METHOD PROPOSED / no verified creature-specific decontamination'},
  {'step':3,'operation':'mark and cut two 50x20mm panels','input':'2 plates; cutting tools', 'evidence':'dimensional geometry calculable / breakage unresolved'},
  {'step':4,'operation':'drill proposed four hinge holes and finish edges','input':'panels; reusable drill/gauge', 'evidence':'hole positions, edge distances, tearout strength PENDING'},
  {'step':5,'operation':'thread fiber directly to join panels and make closure tie','input':'panels; 30cm fiber', 'evidence':'feasible assembly CONCEPT, length split and knot strength NOT QUALIFIED'},
  {'step':6,'operation':'inspect geometry, fit and retention for specifically specified sample','input':'assembled holder + non-consumed gauge/test sample', 'evidence':'FC04 boolean fixture PASS; physical force and volume QA PENDING'},
 ],
 'intermediate':'Two cut, bored panels = in-process nodes. No extra intermediate cord B30-02.',
 'tools':[{'name':x,'role':'reusable tool/operational condition','verified_available_in_game':False} for x in ['saw/cutter','hand drill','marking template','dimensional gauge','PPE and dust collection']],
 'specialist':'PROPOSTO: artisan with safe cutting/boring technique of source material; no existing named qualified artisan proven',
 'time':'45 min FC04 fixture only; not measured actual manufacturing time',
 'environment':'clean/dry controlled workstation proposed; actual humidity/temperature requirement unverified',
 'qa':['two flat panels and dimensional fit','no visible cracks/cutting hazards','no loose fiber','functional joint/closure under qualified load, not fixture boolean','repeat opening acceptance with physical instrumented test'],
 'failure_and_waste':['panel fracture: reject/quarantine; no automatic recycling','fiber knot/joint failure: reject/rework only if safe','cut-off fragments: quantity and fate unknown, no invented output resource','contamination: reject pending approved safe handling'],
 'product_limit':'Flat inert samples only as present candidate; no liquid, poison, loose powder, magical essence, capacity or protective ability licensed',
 'physical_success_rate':'UNKNOWN', 'rc5_technical_status':'HOLD'
})

write_json('b30_22_differential_protocol.json',{
 'method':'FC05 independent evidence audit of FC04 comparator, PLUS geometrical guards; not new physical experiment',
 'comparator':{'name':'ordinary wood-fiber hinged case','documented_as':'historical BACKFILL-30 comparator family; concrete REC-ID/page not independently fetched',
               'status':'DESIGN-LEVEL_ALTERNATIVE_NOT_PHYSICALLY_VERIFIED_ITEM'},
 'hypotheses':[
 {'hypothesis':'B30-22 improves sample retention at same panel footprint and sample type','unit':'per physical prototype paired trial',
  'metric':'retention failure rate or minimum release force','control':'same geometry, fill, environment, opening cycles',
  'acceptance':'pre-registered practical nonzero improvement versus real comparator with measurement uncertainty',
  'fc04_input':'both flat_sample_retained=true SYNTHETIC','verdict':'INCONCLUSIVE_PHYSICAL'},
 {'hypothesis':'B30-22 hinge survives repeated openings better','unit':'per prototype and independent life-cycle',
  'metric':'cracks, loosened holes, retained closure force after N cycles','control':'identical N/load/humidity',
  'acceptance':'material difference measured against matched alternative; N and tolerance must be registered before real trial',
  'fc04_input':'both hinge_cycle_count=20 SYNTHETIC','verdict':'INCONCLUSIVE_PHYSICAL'},
 {'hypothesis':'B30-22 is lighter at equal useful carrying capacity','unit':'grams per usable sample volume/area',
  'metric':'mass, usable interior clearance/area, drop failure','control':'matched sample burden',
  'acceptance':'real normalized mass/payload measured, no presumed chitin density',
  'fc04_input':'no mass/payload data','verdict':'NOT_EVALUABLE'},
 {'hypothesis':'B30-22 costs no more for equal qualified use','unit':'MED per accepted item and per qualified service cycle',
  'metric':'CTE and cycle life with error bands','control':'same location/date/cost units and rejected lots',
  'acceptance':'same reference market and validated output yield',
  'fc04_input':'symbolic cost only','verdict':'NOT_EVALUABLE'}
 ],
 'limits':['FC04 QA boolean cannot establish retaining force or life','B30-19 candidate flexible cover is a different product, not proof of equivalent rigid case',
           'geometry qualifies only envelope; no clearance or sidewall measurements','wet/temperature stability untested'],
 'conclusion':'DIFFERENTIAL_NOT_DEMONSTRATED; not proof of material equivalence or inferiority',
 'merit_decision':'DO_NOT_ADMIT_INDEPENDENT_RC5_WITH_CURRENT_EVIDENCE; retain historical PRE-Q2 or propose narrow flat-sample holder for future material demonstration',
 'recipe_relations':'NO existing parent REC-ID verified; do not claim formal derivation'
})

write_json('b30_22_economy.json',{
 'official_norm':'PR-ECO-01 Anexo C','currency':'MED_UNDETERMINED',
 'source_quality':'PARAMETRIC_ONLY','object':'one QA-approved B30-22 holder',
 'bom_model':{'chitin_panels':{'n':2,'unit':'intact usable plate','price':'P_plate in MED/unit UNKNOWN'},
              'boreal_fiber':{'quantity':0.30,'unit':'m of prepared usable fiber','price':'P_fiber_m in MED/m UNKNOWN'},
              'equipment':'reusable tools amortized per attempted lot; no assumption that tools owned'} ,
 'formula':'CTE=CI+CP+CF+CT+CE+CK+CL+CA+CC',
 'cost_nodes':{
  'CI':'2*P_plate+0.30*P_fiber_m+other approved consumables (if truly required)',
  'CP':'material lost in cutting/piercing beyond planned first-attempt input, avoid double-counting 2 plates',
  'CF':'extra inputs/labor from rejected attempts; probability unknown',
  'CT':'t_act_h*w_hour; 45min is FC04 fixture proposal, not measured',
  'CE':'tool depreciation, energy and PPE per lot based on actual usage',
  'CK':'knowledge training/licence/qualified specialist cost, only when demonstrably applicable',
  'CL':'physical transportation and hazardous handling where legitimately required',
  'CA':'storage, contamination prevention and custody as evidenced',
  'CC':'opportunity/capital, not zero for self-owned resources'},
 'unit_cost':'CTE_lot/N_approved if N_approved > 0; UNDEFINED if zero',
 'four_distinct_values':['input kit cost','effective technical production cost','recipe/knowledge value','product MED price/value'],
 'scenarios':[
 {'case':'favorable','assumptions':'both panels and fiber pass acceptance; first-attempt QA pass, t_rework=0','result':'SYMBOLIC_ONLY'},
 {'case':'normal','assumptions':'rework variable r>=0; reject probability unknown','result':'NOT_COMPUTABLE'},
 {'case':'adverse','assumptions':'fractured plate or failed closure, N_approved=0','result':'NO_PER_UNIT_CTE; rejected costs retained'}],
 'missing_minimum':['date/location/market channel and costs of equivalent usable plates and prepared fiber','available fiber/plate yield by lot','measured attempt time and artisan rate','actual QA-passing count and material losses','tool cost/use and licensed know-how where applicable','physical comparator cost for merit'],
 'rank_by_price':False,'no_invented_MED':True,'official_market_price':None
})

candidates={
 'B30-01':{'status':'RC4_DOCUMENTAL_PLUS_FC04_TEST','functional_merit':'distinct 2D grid workbench guide PROPOSED, no automatic inscription bonus',
 'positive':['R48 TEST executed','single known PS slate resource','geometric tolerances and conditional QA defined'],
 'tech_missing':['PS sheet lot quality/obtainability','realistic tool abrasion consumption and yield','qualified craft know-how and market CTE/merit equivalence'],
 'priority':1,'reason':'one primary source and simple physical effect, fewer interface-dependent claims'},
 'B30-03':{'status':'RC4_DOCUMENTAL_PLUS_FC04_TEST','functional_merit':'pair calibrated dimension spacers distinct from gneiss support plate by FORM, not measured superior material performance',
 'positive':['R48 TEST executed','two inputs from same known PS resource','dimensional fit QA in fixture'],
 'tech_missing':['material thickness/calibration and fatigue in qualified assembly','legitimate comparison with common spacers','know-how/economy/PS'],
 'priority':2,'reason':'no extra ingredient but no validated application-specific superiority'},
 'B30-22':{'status':'RC4_DOCUMENTAL_PLUS_FC04_TEST','functional_merit':'no independent merit demonstrated against ordinary case; flat-sample clamshell is narrower PROPOSAL',
 'positive':['R48 TEST executed with R47 synthetic receipts','30cm PS fiber directly used, no cordage base needed','new footprint/containment gate identifies unsupported bulky-sample claims'],
 'tech_missing':['real material suitability and qualified hole/hinge/closure','surface/height/payload and differential vs comparator','qualified knowledge/CTE/PS'],
 'priority':3,'reason':'additional assembly interfaces and comparator performance not established'},
 'B30-06':{'status':'PRE_Q2_BLOCKED_SOURCE_NO_R48_TEST','functional_merit':'desiccant bag requires validated permeable envelope and measured adsorption; alternative open refill tray changes product scope',
 'positive':['200g zeolite source PS documented in prior dossier','bag/body/charge and recharge separated analytically'],
 'tech_missing':['one proven porous envelope identity/function','adsorption vs ordinary desiccant with measurable performance','safe drying/regeneration, cost and origin/knowledge'],
 'priority':4,'reason':'insufficient BOM and unverified core effect; no physical envelope source'},
}
write_json('rc5_admission_matrix.json',{
 'schema':'CRAFT-FC05-RC5-ADMISSION-v1','sources':['REC-EXEC PR-ITEM-02','REC-LIB-01','PR-ECO-01 Anexo C','PR-SC-01','DIR-003','local BACKFILL30 specs','FC04 verified archive'],
 'seven_state_separation':{
  '1_documental_specs':'4 candidates historical (B30-01/03/06/22), statuses differ',
  '2_synthetic_execution':'3 candidates R48 TEST prior; not rerun',
  '3_material_proof':'0 of 4 has full physical performance qualified in FC05',
  '4_rc5_technical_eligibility':'0 of 4 demonstrated',
  '5_official_physical_rec_ids':'0 of 30',
  '6_really_manufactured_products':'0 in this operation',
  '7_party_knowledge':'0 authorizations or disclosures'},
 'candidates':candidates,
 'authority':{'F5':'RED/HISTORICAL_NOT_REVALIDATED','C19_021':'UNKNOWN_SIDE_EFFECT','IBX_38':'FENCING_PENDENTE',
   'IBX_78':'REC_LIB_DESTINATION_PENDING','writer':'NOT_PROVEN','NAC_PASS_PRODUCTIVE':'HOLD','notion_readback':'UNAVAILABLE_THIS_SESSION'},
 'goals':{'sources_documentally_identified':30,'pre_q2':23,'pre_q1':7,
 'previous_fc04_test_families':3,'new_rc5_official':0,'rec_id_goal':30,'rc5_coverage':0,'coverage_goal':30,'new_official_products':0},
 'candidate_eligibility':0,'candidate_denominator':4,'new_material_comparisons_physically_verified':0,
 'existing_physical_comparator_proven':0,
 'next_priority':'B30-01; first material-qualified geometric workbench source, then B30-03; B30-22 hold differential; B30-06 envelope conditional',
 'official_write_set_prepared':False,'no_prod_write':True})

(root/'README-FC05.md').write_text('''# FC05 — CRAFT material gate and successor package (MESTRE-SIDE)

Existing operation **CM-000002 / WS0001 / OP-ARQ-RIN-REC-01**, 2026-10-16. New material-evidence gate is a **checker only**, NOT a new factory, laboratory, motor or REC-ID. Historical v03, FC03 and FC04 ZIPs were not edited. No Notion / official writes.

## New, actually executed in FC05

- Clean archive reader `code/verify_fc05_clean.py`: checks original SHA-256 (v03/FC03/FC04), v03 205/205 declared files, FC04 74/74 declared files, R48 hash chains, stock ledger, case receipts, angular base unit and deliberate orphan fail-closed; **no imports from factory or FC04 audit**. An in-memory corrupted pointer is rejected.
- `code/fc05_material_gate.py`: differentiates footprint geometry from actual physical retention; four deterministic sample-envelope cases; compares unchanged FC04 fixtures and refuses to infer true material advantage. `code/test_fc05_material.py`: 12/12 checks.
- `outputs/b30_22_scientific_gate.json`: rejects unsupported claims that two panels and thread prove a 3D storage box for bulk samples; narrows viable *proposal* to inert planar sample holder, not material-homologated.
- `outputs/b30_22_sources_process.json`: traceable BOM/process and exact pending physical fields, no B30-02 cordage dependency.
- `outputs/b30_22_differential_protocol.json`: physical controls, hypotheses, uncertainties and comparator limitations; comparison is synthetic-only.
- `outputs/b30_22_economy.json`: official Anexo C cost tree with missing values explicitly identified.
- `outputs/rc5_admission_matrix.json`: stage separation and evidence-ranked next candidate.

## Reproduce from clean extraction

```bash
python code/verify_fc05_clean.py /path/CRAFT-COMESTRE-CHAT-v03.zip /path/CRAFT-FAST-CLOSE-03-DELTA-20261016.zip /path/CRAFT-R48-B30-22-FC04-DELTA-20261016.zip /tmp/verify_result.json
python -m unittest discover -s code -p 'test_*.py' -v
python code/fc05_material_gate.py inputs/fc04_controlled_comparison.json /tmp/material_result.json
python verify_fc05_package.py
```

All script outputs go to NEW files; existing files are never overwritten. Physical material tests, real stock, real markets, licensing, Party knowledge and RC5 official canon **NOT DEMONSTRATED**.

**AS-OF:** 16 October 2026. **LAST-VERIFIED:** original FC04 `ACCEPTED_V2/R48_SHARED_TRIPLE_STORE`, sequence 2, HEAD `cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708`, plus four-stores auditor result and one expected orphan fail-closed. **FIRST-PENDING:** in real evidence, B30-01 qualified source sheet and tool/skill costs; B30-22 3D enclosure/hinge and differential properties. **UNKNOWN-EFFECT:** C19-021 not reconciled; separate FC04 orphan remains fenced. **NO-REPEAT:** do not rebuild R44–R48, re-run 62 known tests, reuse obsolete R47 certificates, consume draft UI, count fixtures as RC5, or touch Party/O Primeiro.

**Notion connector:** `link_id must identify an eligible linked account`; current Notion readback and writing PENDENTE. Do not assert writer/lease. No official publication, no new REC-ID, no physical product, no Player disclosure. **NAC-PASS-02:** technical archive validation PASS in isolated scope; RC5 and production HOLD.
''',encoding='utf8')
print('evidence written',[(p.name,p.stat().st_size) for p in (root/'outputs').glob('*')])
