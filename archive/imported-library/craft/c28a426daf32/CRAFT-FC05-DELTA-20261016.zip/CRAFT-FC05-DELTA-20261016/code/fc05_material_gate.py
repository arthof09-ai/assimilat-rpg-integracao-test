"""FC05 evidence gate, NOT a second manufacturing engine. No production writes.
Reads immutable FC04 fixtures and emits only technical/synthetic classifications.
"""
import json
from pathlib import Path

def analyze(fc04_comparison:dict):
    a=fc04_comparison['chitin_tested_values']
    b=fc04_comparison['ordinary_case_tested_values']
    compared=('closure_secure','cracks','flat_sample_retained','hinge_cycle_count','hinge_open_angle_deg','length_mm','panel_count','sharp_edges','width_mm')
    # Equality of fixtures is not scientific evidence of actual equivalence.
    equal={k:a[k]==b[k] for k in compared}
    if not all(equal.values()):
        raise AssertionError('FC04 fixture assumption changed: recompute test design')
    units={'panel_length_mm':a['length_mm'],'panel_width_mm':a['width_mm'],
           'source_plate_min_length_mm':60,'source_plate_min_width_mm':30,
           'source_plate_count':2,'fiber_input_cm':30}
    # Proposed geometry, not a physical fit/retention measurement.
    cases=[
        {'case':'flat_40x10_mm','sample_length_mm':40,'sample_width_mm':10,
         'thickness_mm':None,'envelope': 'WITHIN_PLANAR_FOOTPRINT','physical_retention':'UNMEASURED'},
        {'case':'oversize_55x10_mm','sample_length_mm':55,'sample_width_mm':10,
         'thickness_mm':None,'envelope':'OUTSIDE_PLANAR_FOOTPRINT','physical_retention':'NOT_ACCEPTABLE_BY_GEOMETRY'},
        {'case':'oversize_40x25_mm','sample_length_mm':40,'sample_width_mm':25,
         'thickness_mm':None,'envelope':'OUTSIDE_PLANAR_FOOTPRINT','physical_retention':'NOT_ACCEPTABLE_BY_GEOMETRY'},
        {'case':'bulk_10x10x4_mm','sample_length_mm':10,'sample_width_mm':10,
         'thickness_mm':4,'envelope':'WITHIN_PLANAR_FOOTPRINT','physical_retention':'INDETERMINATE_NO_CLEARANCE_OR_WALL_DATA'},
    ]
    for x in cases:
        computed=('WITHIN_PLANAR_FOOTPRINT' if x['sample_length_mm']<=a['length_mm'] and
                  x['sample_width_mm']<=a['width_mm'] else 'OUTSIDE_PLANAR_FOOTPRINT')
        assert computed==x['envelope']
    raw_area=60*30*2; product_area=50*20*2
    assert raw_area>product_area
    return {
        'schema':'CRAFT-FC05-MATERIAL-DIFFERENTIAL-v1','classification':'TEST_GEOMETRIC_ONLY',
        'pre_registered_claim':'Chitin case is materially different/superior in physically meaningful properties to ordinary wood-fiber case; null is no demonstrated differential.',
        'null_result':'DIFFERENTIAL_NOT_DEMONSTRATED',
        'counterpart':'Ordinary wood/fiber rigid case from BACKFILL-30 dossier: comparative design alternative, NOT physically verified as catalogued existing Notion item',
        'matched_synthetic_metrics':equal,
        'synthetic_equal_inputs_cannot_prove_physical_equivalence':True,
        'units':units,'case_tests':cases,
        'geometric_area_mm2':{'raw_plate_surfaces':raw_area,'finished_plate_surfaces':product_area,
                               'ideal_fraction_only':round(product_area/raw_area,6),
                               'not_empirical_yield_or_cost':True},
        'direct_fiber_consumption':{'cm':30,'m':0.3,'B30_02_cordage_prerequisite':False},
        'fatal_to_current_RC5':[
           'No verified internal clearance or loose-sample containment: flat-plate sandwich alone is not certified bulk container',
           'No measured closure retention, hinge wear, bending/tear-out, humidity/temperature response',
           'No genuine comparator test on physical specimens or authoritative material qualification',
           'Chitin/fiber resource pages are PS, not evidence of legitimate stock, craft knowledge or tool availability',
           'No available MED/CTE physical parameters (source cost, loss yield, opportunity cost, labor rate)'],
        'conditional_tech_reformulation':{
           'candidate':'Reusable flat-sample clamshell / porta-amostra plano',
           'product_class':'PROPOSED_NOT_OFFICIAL',
           'requirement':'Specify planar max sample, clearance and closure mechanism; compare with ordinary folder/wood case; reject use for loose granules or liquids absent walls/seal',
           'hole_count_proposal':4,
           'hinge_and_closure':'Direct fiber threading, 30 cm total; fiber lengths, knot strength and hole integrity PENDING, not assumed pass',
           'does_not_create_recipe_or_rec_id':True
        },
        'source_quality':'FC04 receipts checked locally; BACKFILL dossier historical Notion provenance; no fresh live Notion read',
        'official_RC5':False,
        'scientific_conclusion':'NO_MATERIAL_ADVANTAGE_SHOWN; RETAIN_AS_PRE_Q2_OR_RESCOPE, DO_NOT_INDEPENDENTLY_ADMIT'
    }

def dump(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():raise FileExistsError('No overwrite: '+str(p))
    p.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')

if __name__=='__main__':
    import sys
    src=Path(sys.argv[1]);dst=Path(sys.argv[2]);dump(dst,analyze(json.loads(src.read_text())))
    print('FC05 material gate: TEST-only, no merit proven, four dimensional cases')
