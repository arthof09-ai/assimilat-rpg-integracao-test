"""FC05 standalone independent verifier: reads original ZIP bytes in a clean tempfile.
No import of CRAFT R44-R48 or FC04 verifier. No historical writes.
"""
from __future__ import annotations
import hashlib,json,zipfile,tempfile,sys,copy
from pathlib import Path
EXPECTED={
 'v03':'5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434',
 'fc03':'72fba831198de4701ee0e0b6d50abda594cf6ec4223c0955fe36e92c92f5e2c4',
 'fc04':'5756bdf2e6e0550336d483c0c749a411ab345bf39b1168d585d1a883f077bf9b'}
HEAD='cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708'
HEALTHY=['R48_SHARED_TRIPLE_STORE','R48_QA_NEGATIVE_STORE','R48_EXPIRED_CERT_STORE','R48_LOST_ACK_RECOVERED_STORE']
ORPHAN='R48_ORPHAN_FAIL_CLOSED_STORE'
def sha(raw:bytes):return hashlib.sha256(raw).hexdigest()
def jhash(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def verify(path_v03,path_fc03,path_fc04):
    paths={'v03':Path(path_v03),'fc03':Path(path_fc03),'fc04':Path(path_fc04)}
    hashes={x:sha(p.read_bytes()) for x,p in paths.items()}
    assert hashes==EXPECTED,('BASELINE_HASH',hashes)
    with zipfile.ZipFile(paths['v03']) as z:
        assert z.testzip() is None
        original_file_count=sum(not n.endswith('/') for n in z.namelist())
        base_manifest=json.loads(z.read('CRAFT-COMESTRE-CHAT-v03/MANIFEST-V03.json'))
        assert len(base_manifest['files'])==205
        for rel,meta in base_manifest['files'].items():
            member=rel if rel.startswith('CRAFT-COMESTRE-CHAT-v03/') else 'CRAFT-COMESTRE-CHAT-v03/'+rel
            raw=z.read(member)
            expected_sha=meta.get('sha256') if isinstance(meta,dict) else meta
            assert sha(raw)==expected_sha,('V03_HASH',rel)
        original_manifest_count=len(base_manifest['files'])
    with zipfile.ZipFile(paths['fc03']) as z:
        assert z.testzip() is None
        fc03_file_count=sum(not n.endswith('/') for n in z.namelist())
    with zipfile.ZipFile(paths['fc04']) as z,tempfile.TemporaryDirectory(prefix='CRAFT-FC05-CLEAN-') as tmp:
        assert z.testzip() is None
        paths_zip=[n for n in z.namelist() if not n.endswith('/')]
        assert len(paths_zip)==75, len(paths_zip)
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in paths_zip)
        # Read manifest bytes from ZIP instead of trusting the existing extraction.
        prefix='CRAFT-R48-B30-22-FC04/'
        manifest=json.loads(z.read(prefix+'MANIFEST_SHA256.json'))
        files=manifest['files']
        assert len(files)==74
        for rel, meta in files.items():
            raw=z.read(prefix+rel)
            assert len(raw)==meta['bytes'],('LENGTH',rel)
            assert sha(raw)==meta['sha256'],('HASH',rel)
        z.extractall(tmp)
        extracted=Path(tmp)/'CRAFT-R48-B30-22-FC04'/'outputs'/'ACCEPTED_V2'
        results=[]
        for name in HEALTHY+[ORPHAN]:
            folder=extracted/name
            p=json.loads((folder/'CURRENT.json').read_text())
            digest=p.pop('pointer_sha256')
            assert jhash(p)==digest,('POINTER',name)
            assert p['sandbox_only'] is True and p['official_stock_effect']==0
            on_disk={x.name for x in (folder/'commits').glob('*.json')}
            declared=set(p['known_commits'])
            if name==ORPHAN:
                assert on_disk!=declared,('ORPHAN_UNDETECTED',name)
                results.append({'store':name,'status':'EXPECTED_FAIL_CLOSED','unknown_effect':True})
                continue
            assert on_disk==declared,('ORPHAN',name)
            assert len(declared)==p['sequence']+1
            for f in declared:
                assert sha((folder/'commits'/f).read_bytes())==p['commit_digests'][f]
            snap=json.loads((folder/'commits'/p['current']).read_text())
            snap_hash=snap.pop('snapshot_sha256')
            assert jhash(snap)==snap_hash==p['snapshot_sha256']
            assert snap['r48_head']==p['r48_head']
            assert snap['fixture_marker']=='SYNTHETIC_NO_OFFICIAL_INVENTORY'
            lots={i['lot_id']:i['quantity'] for i in snap['original_lots']}
            expected=dict(lots)
            prev=snap['factory_genesis']
            product_count=0
            for i,record in enumerate(snap['journal'],1):
                assert record['previous_hash']==prev
                assert record['hash']==jhash({'previous_hash':prev,'event':record['event']})
                prev=record['hash']; e=record['event']
                assert e['stock_before']==expected,('STOCK_BEFORE',i,name)
                for order in e['orders']:
                    assert order['physical_measurement_verified'] is False
                    assert order['official_materialization'] is False
                    assert order['official_rec_id'] is None
                    for item in order['consumed']:
                        expected[item['lot_id']]-=item['quantity']
                        assert expected[item['lot_id']]>=0
                    product_count+=len(order['products'])
                    assert all(prod['official_product_id'] is None and prod['status']=='SYNTHETIC_OUTPUT_ONLY' for prod in order['products'])
                assert e['stock_after']==expected,('STOCK_AFTER',i,name)
            assert prev==p['r48_head']
            assert {k:v['quantity'] for k,v in snap['core_state']['lots'].items()}==expected
            assert len(snap['core_state']['products'])==product_count
            if name==HEALTHY[0]:
                assert p['r48_head']==HEAD
                assert p['sequence']==2
                assert product_count==3
                assert len(snap['r46_parent_events'])==len(snap['r47_events'])==4
                # Regression guard for FC04 superseded angular label.
                angular=snap['r46_parent_events'][-1]['payload']['decision']['inspection']['hinge_open_angle_deg']
                assert angular['base_unit']=='deg',('ANGLE_MISLABELED',angular)
            results.append({'store':name,'status':'VERIFIED_SYNTHETIC_READBACK',
                            'sequence':p['sequence'],'products':product_count,'head':p['r48_head']})
        # Red-team: a tampered in-memory pointer must fail canonical serialization check.
        sample_folder=extracted/HEALTHY[0]
        altered=json.loads((sample_folder/'CURRENT.json').read_text())
        signed=altered.pop('pointer_sha256'); altered['sequence']+=1
        assert jhash(altered)!=signed
        return {'schema':'CRAFT-FC05-CLEAN-ARCHIVE-CHECK-v1','verified':True,
                'original_package_sha256':hashes,'original_v03_zip_members':original_file_count,'original_v03_manifest_verified':original_manifest_count,
                'fc03_files':fc03_file_count,'fc04_manifest_files':len(files),
                'fc04_zip_members':len(paths_zip),'recovered_head':HEAD,
                'stores':results,'tampered_pointer_rejected':True,
                'independent_of_factory_and_fc04_auditor':True,
                'material_properties_measured':0,'production_writes':0}
if __name__=='__main__':
    if len(sys.argv)!=5:raise SystemExit('Usage: verify_fc05_clean.py V03.zip FC03.zip FC04.zip OUTPUT.json')
    result=verify(*sys.argv[1:4]);dest=Path(sys.argv[4]);
    if dest.exists():raise SystemExit('refuse overwrite '+str(dest))
    dest.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'verified':result['verified'],'v03_files':result['original_v03_manifest_verified'],
                      'fc04_files':result['fc04_manifest_files'],'healthy_stores':sum(z['status']=='VERIFIED_SYNTHETIC_READBACK' for z in result['stores']),
                      'orphans_blocked':sum(z['status']=='EXPECTED_FAIL_CLOSED' for z in result['stores']),
                      'pointer_tamper_rejected':result['tampered_pointer_rejected']},indent=2))
