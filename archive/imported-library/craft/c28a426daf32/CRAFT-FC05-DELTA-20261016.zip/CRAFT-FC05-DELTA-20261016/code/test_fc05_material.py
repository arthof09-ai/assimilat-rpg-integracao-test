import unittest, sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fc05_material_gate import analyze

F=Path(__file__).resolve().parents[1]/'inputs'/'fc04_controlled_comparison.json'
class TechnicalGates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=json.loads(F.read_text());cls.r=analyze(cls.source)
    def test_equal_synthetic_fixtures_not_physical_equivalence(self):
        self.assertTrue(all(self.r['matched_synthetic_metrics'].values()))
        self.assertEqual(self.r['null_result'],'DIFFERENTIAL_NOT_DEMONSTRATED')
    def test_source_fiber_direct_without_cordage(self):
        self.assertEqual(self.r['direct_fiber_consumption']['cm'],30)
        self.assertFalse(self.r['direct_fiber_consumption']['B30_02_cordage_prerequisite'])
    def test_planar_interior_only(self):
        self.assertEqual(self.r['case_tests'][0]['envelope'],'WITHIN_PLANAR_FOOTPRINT')
        self.assertEqual(self.r['case_tests'][0]['physical_retention'],'UNMEASURED')
    def test_oversize_length_reject(self):
        self.assertEqual(self.r['case_tests'][1]['envelope'],'OUTSIDE_PLANAR_FOOTPRINT')
    def test_oversize_width_reject(self):
        self.assertEqual(self.r['case_tests'][2]['envelope'],'OUTSIDE_PLANAR_FOOTPRINT')
    def test_bulk_height_unproven(self):
        self.assertEqual(self.r['case_tests'][3]['physical_retention'],'INDETERMINATE_NO_CLEARANCE_OR_WALL_DATA')
    def test_area_is_not_yield(self):
        self.assertTrue(self.r['geometric_area_mm2']['not_empirical_yield_or_cost'])
        self.assertEqual(self.r['geometric_area_mm2']['ideal_fraction_only'],round(2000/3600,6))
    def test_no_rc5_credit(self):
        self.assertIs(self.r['official_RC5'],False)
    def test_historical_comparator_not_verified(self):
        self.assertIn('NOT physically verified',self.r['counterpart'])
    def test_detect_changed_historical_fixture(self):
        inp=json.loads(json.dumps(self.source));inp['ordinary_case_tested_values']['width_mm']=15
        with self.assertRaises(AssertionError):analyze(inp)
    def test_ps_is_not_stock(self):
        self.assertTrue(any('legitimate stock' in s for s in self.r['fatal_to_current_RC5']))
    def test_guard_against_premature_bulk_container(self):
        self.assertIn('flat-plate sandwich',self.r['fatal_to_current_RC5'][0])
if __name__=='__main__':unittest.main()
