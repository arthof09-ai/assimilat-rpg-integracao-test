# PSV — CM-000002 / WS0001 / OP-ARQ-RIN-REC-01 / FC05

**AS-OF:** 2026-10-16 · **AMBIENTE:** MESTRE-SIDE · **BASELINE:** R01–R51, FC01–FC04 (originais intactos).  
**LAST-VERIFIED-UNIT:** FC04 `ACCEPTED_V2/R48_SHARED_TRIPLE_STORE`, sequência 2, HEAD `cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708`; 4 stores íntegros, 1 órfão deliberado FAIL-CLOSED.  
**FIRST-PENDING:** evidência física autorizada do diferencial do produto B30-22, e cadeia de lote/CTE/operador B30-01, sem aumentar produtos TEST.

## Evidência executada nesta FC05

Recuperados bytes dos arquivos v03 (SHA 5a9af3ae…4434), FC03 (72fba831…e2c4), FC04 (5756bdf2…bf9b). Verificador independente novo em extração temporária, sem importar motor nem auditor FC04: 205/205 entradas do MANIFEST v03; 74/74 do FC04; 4/4 stores saudáveis; 1/1 órfão FAIL-CLOSED; hash corrente R48 confirmado; adulteração de ponteiro de memória recusada. Observação: v03 possui 206 entradas físicas ZIP incluindo seu manifesto; 205 são os arquivos inventariados.

Novo gate geométrico B30-22, sobre fixtures FC04 imutáveis: **12/12 testes novos PASS**; amostra plana 40×10mm cabe no contorno proposto 50×20mm, 55×10 ou 40×25mm excedem o contorno; retenção física plana e volume de amostra espessa **NÃO MEDIDOS**. Acesso a recipiente comum do acervo físico Notion não recuperado. O comparador de madeira/fibra é somente uma alternativa de design já identificada no BACKFILL-30, não ficha oficial verificada. Ficou provado *o limite da alegação*: duas placas planas + fibra não certificam contenção volumosa, vedação, retenção física, resistência a desgaste ou superioridade sobre estojo ordinário. Não se conclui inferioridade nem equivalência material.

**DEPENDÊNCIA RESOLVIDA:** B30-22 consome PS Fibra de Casca Boreal diretamente, sem fabricar B30-02; nenhum ingrediente novo. **PENDENTES B30-22:** fonte/autorização de lotes e dimensões de quitina e fibra; perfuração/união/fecho e frestas sob carga, higiene, operador/ferramentas reais, durabilidade, preço e custos de obtenção, rendimento e diferencial de função. Reformulação PROPOSTA apenas: porta-amostra inerte/plana, não estojo volumétrico genérico.

## Economia e admissão

Árvore oficial `CTE=CI+CP+CF+CT+CE+CK+CL+CA+CC` explicitada por unidade, perdas extras, mão de obra, depreciação, saber, logística, armazenagem e oportunidade, sem MED falso. Cenários favorável/normal/adverso apenas qualitativos: com zero peças QA, custo/peça aprovada indefinido, não zero.

**Priorização:** 1) B30-01 (gabarito plano, um insumo PS e QA mais simples); 2) B30-03 (calço, falta prova de mérito versus calço comum); 3) B30-22 (produto restringido a amostras planas, mérito não demonstrado); 4) B30-06 (invólucro poroso não autenticado, adsorção não medida). A zeólita pode ser carga em recipiente existente *se identificado*, mas isso muda o produto; não promova Bolsa sem invólucro.

**Contadores independentes:** PS originais identificados documentalmente 30/30; PRE-Q2 23/30 e PRE-Q1 7/30 (histórico); famílias TEST da FC04 3/3 (não repetidas); fontes de comparadores oficiais reabertas nesta sessão 0; candidatas tecnicamente RC5 elegíveis 0/4; REC-IDs RC5 oficiais 0/30; cobertura oficial 0/30; produtos oficiais 0. Testes novos 12/12, auditorias históricas selecionadas 4 stores e 1 órfão; nada disso credita RC5.

**CONFLICTS:** esta instância não recuperou a conexão Notion; evidências atuais de fonte PS são recortes locais historicamente identificados, não novo readback canônico. FC04 QA `flat_sample_retained=true` é prova sintética, e não pode sustentar retenção material; produto estojo universal extrapola dois painéis planos. **UNKNOWN-EFFECT:** C19-021 permanece não reconciliado; órfão experimental FC04 preservado sem retomada. **WRITER:** não provado; F5 RED; IBX-38 fencing, IBX-78 destino REC-LIB, NAC-PASS produtivo HOLD. Sem OP/Diário/REC-LIB/Party/O Primeiro/estoques oficiais alterados.

**NAC-PASS-02 proporcional:** PASS apenas na auditoria binária local dos pacotes e consistência dos recibos TEST; HOLD na evidência material, elegibilidade RC5, canonicidade, write e fabricação real.

**NO-REPEAT:** não reconstruir R44–R48, não tocar draft `SBX-R48-BATCH-UI-2afb696406a6e839`, tentativa angular superada e órfão FC04; não repetir 62 regressões sem código alterado, não transformar fixture em medição; não aumentar artificialmente REC-IDs.

**NEXT-5:** (1) recuperar Notion somente quando conector habilitado, verificar PS quitina/fibra e item comum físico; (2) pedir/identificar evidência competente de lote e metrologia B30-01; (3) qualificar corte/ferramentas e custo real de gabarito; (4) concluir comparador dimensional B30-03 sem inventar superioridade; (5) voltar à B30-22 só com amostras reais ou fonte técnica sobre fecho/placa, caso contrário reclassificar produto proposto como porta-amostra plano.

**PONTO EXATO DE RETOMADA:** FC05 `outputs/independent_clean_readback_v2.json` e `outputs/b30_22_scientific_gate.json`; baseline FC04 HEAD inalterado. Sem escrita Notion, o registro canônico continua PENDENTE.
