# FC05 — CRAFT material gate and successor package (MESTRE-SIDE)

Existing operation **CM-000002 / WS0001 / OP-ARQ-RIN-REC-01**, 2026-10-16. New material-evidence gate is a **checker only**, NOT a new factory, laboratory, motor or REC-ID. Historical v03, FC03 and FC04 ZIPs were not edited. No Notion / official writes.

## New, actually executed in FC05

- Clean archive reader `code/verify_fc05_clean.py`: checks original SHA-256 (v03/FC03/FC04), v03 205/205 declared files, FC04 74/74 declared files, R48 hash chains, stock ledger, case receipts, angular base unit and deliberate orphan fail-closed; **no imports from factory or FC04 audit**. An in-memory corrupted pointer is rejected.
- `code/fc05_material_gate.py`: differentiates footprint geometry from actual physical retention; four deterministic sample-envelope cases; compares unchanged FC04 fixtures and refuses to infer true material advantage. `code/test_fc05_material.py`: 12/12 checks.
- `outputs/b30_22_scientific_gate.json`: rejects unsupported claims that two panels and thread prove a 3D storage box for bulk samples; narrows viable *proposal* to inert planar sample holder, not material-homologated.
- `outputs/b30_22_sources_process.json`: traceable BOM/process and exact pending physical fields, no B30-02 cordage dependency.
- `outputs/b30_22_differential_protocol.json`: physical controls, hypotheses, uncertainties and comparator limitations; comparison is synthetic-only.
- `outputs/b30_22_economy.json`: official Anexo C cost tree with missing values explicitly identified.
- `outputs/rc5_admission_matrix.json`: stage separation and evidence-ranked next candidate.

## Reproduce from clean extraction

```bash
python code/verify_fc05_clean.py /path/CRAFT-COMESTRE-CHAT-v03.zip /path/CRAFT-FAST-CLOSE-03-DELTA-20261016.zip /path/CRAFT-R48-B30-22-FC04-DELTA-20261016.zip /tmp/verify_result.json
python -m unittest discover -s code -p 'test_*.py' -v
python code/fc05_material_gate.py inputs/fc04_controlled_comparison.json /tmp/material_result.json
python verify_fc05_package.py
```

All script outputs go to NEW files; existing files are never overwritten. Physical material tests, real stock, real markets, licensing, Party knowledge and RC5 official canon **NOT DEMONSTRATED**.

**AS-OF:** 16 October 2026. **LAST-VERIFIED:** original FC04 `ACCEPTED_V2/R48_SHARED_TRIPLE_STORE`, sequence 2, HEAD `cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708`, plus four-stores auditor result and one expected orphan fail-closed. **FIRST-PENDING:** in real evidence, B30-01 qualified source sheet and tool/skill costs; B30-22 3D enclosure/hinge and differential properties. **UNKNOWN-EFFECT:** C19-021 not reconciled; separate FC04 orphan remains fenced. **NO-REPEAT:** do not rebuild R44–R48, re-run 62 known tests, reuse obsolete R47 certificates, consume draft UI, count fixtures as RC5, or touch Party/O Primeiro.

**Notion connector:** `link_id must identify an eligible linked account`; current Notion readback and writing PENDENTE. Do not assert writer/lease. No official publication, no new REC-ID, no physical product, no Player disclosure. **NAC-PASS-02:** technical archive validation PASS in isolated scope; RC5 and production HOLD.
