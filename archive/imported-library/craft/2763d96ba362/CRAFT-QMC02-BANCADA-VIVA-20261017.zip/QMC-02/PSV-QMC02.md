# PSV — CRAFT QMC-02 / Engenharia de Qualificação Multicategoria

**AS-OF:** 17/10/2026 (execução neste turno; datas `as of` individuais das páginas Notion preservadas nos envelopes de leitura).  
**IDENTIDADE:** responsável funcional CM-000002 / WS0001; **INSTANCE-ID de sessão e writer produtivo: não comprovados**.  
**OPERATION:** `OP-ARQ-RIN-REC-01` (continuação); **PRODUÇÃO:** HOLD.  
**BASELINE:** R01–R52, BACKFILL-30, FC01–FC36, R48 e QMC-01, preservados no escopo disponível; **QMC-01 ZIP AUTENTICADO** SHA-256 `0900aa3d064a51a91dd26d3a4383fc1e9acca35349b624e5fe0e02452b675885`, com testes originais 10/10 reexecutados. **Não há alegação de reautenticação exaustiva dos binários R48/FC36 neste ciclo** (resultado prévio QMC-01 reutilizado).

## ANTES → DEPOIS

- **ANTES (QMC-01):** consultava apenas seis fichas de cinco famílias principais via snapshots locais; 10 testes; nenhuma matriz real; nenhum novo UUID não cadastrado; PA diário vs ativação básico; adulteração detectada só contra baseline local.
- **DEPOIS (QMC-02):** aceita envelope desacoplado de extrato obtido por fetch Notion autorizado, com URL/UUID/ancestral/momento de leitura; qualifica **10 novas fichas** e emite parecer estruturado ou conversacional; identifica **PA diário e por ativação em mesmo item**, múltiplas ativações distintas, valor de PA cuja unidade não é conhecida, módulos de MATRIZ e INSCRIÇÃO_ENCANTAMENTO, links de receitas históricas sem confundir com item instalado, conflitos entre ingredientes e processo de receita histórica, comparação de conteúdo entre duas capturas, revisão/ranqueamento conflitante, superfície imprópria e mock energético não oficial.
- **TESTES:** 37/37 passaram (10 legados + 27 novos) em desenvolvimento. Extração limpa também será validada antes da distribuição. Nenhuma execução da fábrica histórica necessária.

## Cobertura com denominadores corretos

**Nesta missão:** 10 fichas novas de 6 famílias: armas (1), armaduras (2), acessórios (1), artefatos (2), matrizes (2), inscrições de encantamento (2). **Cumulativo:** 16 UUIDs distintos QMC-01+QMC-02, **7/8 módulos** com pelo menos um caso de inspeção documental; isto não significa 7/8 categorias homologadas nem análise exaustiva do corpus. **Aprimoramento:** módulo lido, 0 caso canônico Mestre-side autônomo admitido; candidatos localizados sob catálogo legado INVENTÁRIO foram **EXCLUÍDOS**, não canonizados. A própria norma REC-MOD-APR-01 registra ausência de categoria autônoma Mestre-side no mapa atual; requer vínculo real item-base→delta. **INSCRIÇÃO_BATALHA** permaneceu coberta pela QMC-01, INSCRIÇÃO_ENCANTAMENTO agora possui dois casos. Outras famílias auxiliares fora desses oito módulos não foram contadas no denominador.

## Novas demonstrações reais e respostas

1. [Bota Caminho Veloz](https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c): **18 PA/dia**, habilidade ativa **5 PA**, dois efeitos passivos explícitos; não afirmar acumulação automática de bônus +6m/+8m.
2. [Amuleto Tempo Eterno](https://app.notion.com/p/3edc2b324ede8132bbc8f857f4b276c4): **15 PA/dia + 15 PA/ativação**, uso uma vez a cada dois dias; unidades separadas.
3. [Orbe da Palavra Guardada](https://app.notion.com/p/3f5c2b324ede81a89213c1a391293b59): **10 PA captação / 5 PA reprodução**, duas operações distintas, PA/dia não documentado; não atribuir zero.
4. [Matriz de Cultivo](https://app.notion.com/p/3edc2b324ede81fe98faf689b2750291): link à **receita histórica**, mas não ocorrência montada. [Receita vinculada](https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6) tem **dois conflitos documentais literais**: Terra Encantada ↔ Terra de Gigante; Essência de Água da Nascente ↔ Água de Nascente Élfica. **Não assumir sinonímia nem gerar receita corrigida.**
5. [Matriz Espacial dos 10 Milênios](https://app.notion.com/p/3edc2b324ede8166b3aed4b90f7a0a86): Lendária, instalação não portátil por padrão; sem custo PA documentado.
6. [Manto de Abismo](https://app.notion.com/p/3edc2b324ede81a5b09dc45deac36b43): efeitos de teleporte/barreiras condicionados; siglas RM/RF não reinterpretadas em RD/CA.
7. [Vestes de Lydandra](https://app.notion.com/p/3edc2b324ede813f80c1dc8f23f05ec8): +5 CA, limite da barreira uma vez/dia e 10 minutos; custos PA não documentados.
8. [Adaga da Serpente Enfeitiçada](https://app.notion.com/p/3edc2b324ede811787a0de913622b14d): `5d4+5d8+10`, condição CD25 para `3d12` veneno por turno; **35 de PA** tem unidade indeterminada — não transformar em PA/dia nem PA/uso.
9. [Inscrição Reflexo das Profundezas](https://app.notion.com/p/3edc2b324ede816bac13cb656a31677a): padrão de ENC Prata com receita embutida; **sem ocorrência instalada comprovada**.
10. [Inscrição Terra Fértil](https://app.notion.com/p/3edc2b324ede81b9a769d4ede0c4605e): padrão ENC Prata ligado a receita filha; não demonstra instalação.

## NOTION / Proveniência e riscos

**Conexão real no nível do Comestre:** sim, páginas/índices/módulos recuperados por ferramenta autorizada `mcp__Notion__fetch` nesta execução. **Conexão direta do Python:** NÃO; `qmc02.py` aceita envelopes exportados de extratos selecionados da coleta competente. Cada envelope informa UUID, URL, ancestral, fonte e `as of` devolvido pelo conector, e calcula SHA apenas do **extrato**. O envelope local não é assinatura criptográfica do Notion; a tag `source_tool` é declarativa, requer conferência da pessoa/ferramenta que exportou. Os `as of` são da fonte retornada, muitos anteriores a 17/10, portanto **frescor minuto a minuto NÃO foi verificado**.

**Alterações entre versões:** motor compara SHA do mesmo UUID para duas capturas e bloqueia promoção quando há diferença; teste sintético positivo. Dois pares de fetch real de Bota e Matriz retornaram mesmo texto e mesmo `as of`; **não há mutação histórica Notion detectada/testada**. **Não houve alteração na origem**.

## Compatibilidade e energização

**COMPATÍVEL_VERIFICADO** só com citação competente concreta; negativa dirigida implementada para fabricar nova receita (ordem Mestre), matriz portátil presumida (REC-MOD-MAT-01), RD condicional assumida universal (REC-MOD-ARD-01), PA desconhecido assumido zero; caso `POTENCIALMENTE_COMPATÍVEL` rotulado HIPÓTESE e `INDETERMINADO` por insuficiência de fonte. Não há motor universal de sinergias ou instalação.

**Contrato PA interno:** `QMC-PA-INTERCHANGE-CANDIDATE-1` emite ITEM-ID, família, rank, efeitos/modos extraídos, histórico PA diário/ativação, unidade e proveniência. **Nenhuma API externa de PA alegada, nem estimativa autoral.** Resposta `FIXTURE_SIMULADA` é explicitamente rejeitada como PA oficial. Autoridade energética externa ainda não integrada.

## Governação e segurança

**NO-NEW-RECIPES:** 0 receitas novas, 0 derivadas, 0 BOM autorais, 0 REC-ID, 0 itens novos, 0 ativações, 0 produtos, 0 gravações em fontes Mestre/Party/O Primeiro/REC-LIB. Código e fixtures residem só em arquivos TEST locais; relatório ao Coordenador via Inbox preexistente quando enviado.  
**F5:** RED; **C19-021:** UNKNOWN-EFFECT histórico preservado; **writer/lease/epoch/fencing:** não demonstrados; **RC5:** 0/30 no escopo histórico; **PA validado:** PENDENTE; **produção:** HOLD.  
**NAC-PASS proporcional:** PASS de execução local/regressão/captura documental qualificada nos dez casos. **NAC-PASS CANÔNICO/PRODUTIVO: HOLD**. 

## LAST-VERIFIED / FIRST-PENDING / NEXT-5

**LAST-VERIFIED-UNIT:** parecer executável da QMC-02 sobre dez fichas adicionais, com conflitos e múltiplos custos, 37/37 regressões, sem receita gerada.  
**FIRST-PENDING:** adaptador de ingestão automática de saída autenticada da ferramenta Notion para o próprio executável, sem transcrição intermediária, e prova com *duas versões realmente distintas* de uma mesma página (não adulterar original).  
**TARGET-REMAINDER:** interpretar fonte sem dependência de seleção manual de trechos; caso Mestre-side de aprimoramento item-base+delta; regras de compatibilidade cruzada de itens/inscrições com fonte suficiente; protocolo real PA do outro Comestre após validação; corpus ampliado com avaliação de cobertura baseada em denominador físico total (ainda não inventariado).  
**NEXT-5:** (1) ponte autenticada Notion→envelope; (2) ensaiar revisão Notion em réplica autorizada ou fonte versionada; (3) localizar aprimoramento legítimo em item-base Mestre-side; (4) aprofundar análise de múltiplos efeitos condicionais/combinações sem criar novas regras; (5) integrar somente contrato real do Comestre PA quando disponibilizado e autorizado.

**NO-REPEAT:** QMC-01, 10 testes e R48/FC36 preservados; sem segunda fábrica, sem rerun de fabricação.  
**CONFLICTS:** dois conflitos terminológicos de receita histórica, 35 PA de modalidade desconhecida em arma, RM/RF de armadura sem normalização, exclusão da falsa equivalência de aprimoramento legado.  
**ACK:** IBX-108 aparece como `ACK` por `CM-000001-I0007` na reabertura; isso não transmite writer nem homologa QMC-02.

**Resposta central:** O CRAFT passou de *seis snapshots fixos* para **dez casos novos coletados do Notion por ferramenta autorizada e qualificados via envelope desacoplado**, reconhecendo módulos novos, separando várias habilidades energéticas por item, detectando conflitos reais e produzindo interfaces de consumo de PA sem inventar PA ou receitas. A leitura automática Notion pelo código continua pendente.
