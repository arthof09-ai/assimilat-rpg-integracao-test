import copy,unittest
from bancada import SNAPSHOTS,inspect,pa_interface

IDS=list(SNAPSHOTS)
class QualificationTests(unittest.TestCase):
    def test_five_families_accepted(self):
        for k in IDS:
            with self.subTest(item=k):
                r=inspect(k)
                self.assertEqual(r['status'],'QUALIFICACAO_READONLY_CONCLUIDA')
                self.assertEqual(r['no_new_recipe'],True)
                self.assertEqual(r['production_admissibility'],'HOLD_SEM_WRITER_E_SISTEMA_PA_COMPLETO')
    def test_no_generalized_pa(self):
        self.assertEqual(inspect(IDS[0])['energy_contract']['pa_por_dia']['value'],64)
        self.assertEqual(inspect(IDS[2])['energy_contract']['pa_por_dia']['value'],55)
        self.assertEqual(inspect(IDS[3])['energy_contract']['pa_por_ativacao']['value'],15)
        self.assertEqual(inspect(IDS[3])['energy_contract']['pa_por_dia']['status'],'PENDENTE')
        self.assertEqual(inspect(IDS[4])['energy_contract']['pa_por_ativacao']['status'],'PENDENTE')
    def test_onyx_one_use_not_recharge(self):
        r=inspect(IDS[4]);self.assertTrue(r['energy_contract']['consumo_do_item']['value'])
        self.assertEqual(r['energy_contract']['recarga']['status'],'PENDENTE')
        self.assertIn('ART_RECARGA',r['unresolved_checks'])
    def test_inscription_not_installed(self):
        r=inspect(IDS[5]);self.assertIn('INS_OCORRENCIA',r['unresolved_checks'])
        self.assertEqual(r['historical_recipe']['status'],'DOCUMENTADA_NA_FICHA')
    def test_armor_rd_only_elemental(self):
        r=inspect(IDS[2]);d=[e for e in r['effects'] if e['kind']=='RD_conditional'][0]
        self.assertEqual(d['condition'],'ataques de elemental')
    def test_five_family_negative_tampering(self):
        for k in [IDS[0],IDS[2],IDS[3],IDS[4],IDS[5]]:
            with self.subTest(item=k):
                clone=copy.deepcopy(SNAPSHOTS[k]);clone['pa_daily']=7777
                o=inspect(k,clone)
                self.assertEqual(o['status'],'REJEITADO_FONTE_DIVERGENTE')
                self.assertIn('pa_daily',o['different_fields'])
    def test_negative_changes_effect_not_accepted(self):
        t=copy.deepcopy(SNAPSHOTS[IDS[2]]);t['effects'][1]['value']=99
        self.assertEqual(inspect(IDS[2],t)['status'],'REJEITADO_FONTE_DIVERGENTE')
    def test_negative_five_distinct_family_claims(self):
        # Uma falsa regra própria de cada família jamais passa como fonte.
        cases=[
            (IDS[0], lambda x: x['mechanics'].__setitem__('range','ilimitado')),
            (IDS[2], lambda x: x['effects'][1].__setitem__('condition','qualquer dano')),
            (IDS[3], lambda x: x['mechanics']['not_protect_against'].remove('gases tóxicos')),
            (IDS[4], lambda x: x['mechanics'].__setitem__('recharge','recarga automática')),
            (IDS[5], lambda x: x['mechanics'].__setitem__('installed_instance_verified',True)),
        ]
        for k,mutation in cases:
            with self.subTest(k=k):
                copy_=copy.deepcopy(SNAPSHOTS[k]);mutation(copy_)
                self.assertEqual(inspect(k,copy_)['status'],'REJEITADO_FONTE_DIVERGENTE')

    def test_no_activation(self):
        self.assertEqual(inspect(IDS[3],ask_activate=True)['activation_admissibility'],'BLOQUEADA_NESTA_BANCADA')
    def test_unknown_ref_no_assumption(self):
        self.assertEqual(inspect('nao-existe')['status'],'NECESSITA_LEITURA_CANONICA')
if __name__=='__main__':unittest.main(verbosity=2)
