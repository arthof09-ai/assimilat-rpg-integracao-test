#!/usr/bin/env python3
"""QMC-02: extensão read-only da QMC-01. Sem rede, sem receita, sem cálculo de PA.
Recebe envelopes de readback de fonte Notion obtidos por ferramenta AUTORIZADA.
A autenticação do envelope é responsabilidade do Comestre que realizou o readback;
SHA local não constitui prova de assinatura Notion nem autenticidade de permissão.
"""
from __future__ import annotations
import argparse, hashlib, html, json, re, unicodedata
from pathlib import Path
from typing import Any
import bancada as original

QMC_VERSION='CRAFT-QUAL-MULTI-02'
PA_VERSION='QMC-PA-INTERCHANGE-CANDIDATE-1'
UUID_RE=re.compile(r'[a-f0-9]{32}',re.I)
RANKS={'Bronze','Prata','Ouro','Ouro Negro','Lendário','Sem classificação'}
RANK_NORM={'on':'Ouro Negro','o':'Ouro','l':'Lendário','p':'Prata','b':'Bronze'}
FORBIDDEN_SURFACES={'PARTY','PARTY_ESPELHO','INVENTARIO_LEGADO','UNKNOWN'}
MODULE=original.FAMILY_MODULE
LABEL_PATTERNS=(
 ('INSCRICAO_BATALHA',r'Inscri[çc][ãa]o de Batalha'),
 ('INSCRICAO_ENCANTAMENTO',r'Inscri[çc][ãa]o de Encantamento'),
 ('MATRIZ',r'\bMatriz\b'),('ARTEFATO',r'\bArtefato\b'),
 ('ARMADURA',r'\bArmadura\b'),('ARMA',r'\bArma\b'),
 ('ACESSORIO',r'(?:Roupa\s*/\s*Acess[óo]rio|Acess[óo]rio|Equipamento)'),
)

def norm_id(identifier:str)->str|None:
    s=str(identifier).strip().lower()
    if '/p/' in s: s=s.split('/p/')[-1].split('?')[0]
    s=s.replace('-','')
    return s if UUID_RE.fullmatch(s) else None

def plain(s:str)->str:
    # Notion enhanced-markdown: strip tags but keep visible TEXT; do not follow links.
    s=re.sub(r'<(?:page|mention-page)\s+url="([^"]+)"[^>]*>',r' [REF:\1] ',s)
    s=re.sub(r'<[^>]+>',' ',s)
    s=re.sub(r'!\[[^\]]*\]\([^\n]*\)','',s)
    s=re.sub(r'\*\*|\*|\`','',s)
    s=html.unescape(s)
    return unicodedata.normalize('NFC',s)

def digest(s:str)->str:
    return hashlib.sha256(unicodedata.normalize('NFC',s).replace('\r\n','\n').encode()).hexdigest()

def occurrence(pattern:str,src:str,flags=re.I)->list[dict]:
    return [{'literal':m.group(0).strip(),'span':[m.start(),m.end()]} for m in re.finditer(pattern,src,flags)]

def find_family(content:str,category_hint:str|None,ancestry:list[str])->tuple[str|None,str]:
    # Only explicit Notion type/category, or CONFIRMED ancestry, never title inference alone.
    t=plain(content)
    a=re.search(r'(?im)^\s*(?:Tipo|Categoria)\s*:\s*([^\n]+)',t)
    declared=a.group(1).strip() if a else ''
    for family,p in LABEL_PATTERNS:
        if re.search(p,declared,re.I):return family,'tipo/categoria na própria ficha'
    canon_anc=' | '.join(ancestry)
    for family,p in LABEL_PATTERNS:
        if re.search(p,canon_anc,re.I) and (not category_hint or category_hint==family):
            return family,'ancestral Mestre informado e verificado no readback'
    if category_hint in MODULE:
        return category_hint,'dica EXTERNA não suficiente para certificar a família'
    return None,'classificação não comprovada'

def extract_costs(src:str)->dict:
    txt=plain(src)
    daily=[]; activation=[]; ambiguous=[]
    for line in txt.splitlines():
        line=line.strip()
        if not line:continue
        for m in re.finditer(r'(?<!\d)(\d+)\s*PA\s*por\s*dia\b',line,re.I):
            daily.append({'value':int(m.group(1)),'unit':'PA/dia','evidence':line,'state':'DOCUMENTADO'})
        for m in re.finditer(r'(?<!\d)(\d+)\s*PA\s*(?:para\s+ativar|por\s+ativa[çc][ãa]o)\b',line,re.I):
            activation.append({'value':int(m.group(1)),'unit':'PA/uso','evidence':line,'activity':'ativação','state':'DOCUMENTADO'})
        for m in re.finditer(r'(?:a[çc][ãa]o\s+padr[ãa]o\s*(?:\+|e)\s*)(\d+)\s*PA\b',line,re.I):
            activation.append({'value':int(m.group(1)),'unit':'PA/uso','evidence':line,'activity':line.split(':')[0][:65],'state':'DOCUMENTADO'})
        if re.search(r'\(Atv\)|\bAtiva\b|\bReprodu[çc][ãa]o\s*:',line,re.I):
            for m in re.finditer(r'(?<!\d)(\d+)\s*PA\b(?!\s*por\s*dia)',line,re.I):
                activation.append({'value':int(m.group(1)),'unit':'PA/uso','evidence':line,'activity':line.split(':')[0][:65],'state':'DOCUMENTADO'})
        if not re.search(r'\bpor\s+dia|ativar|ativa[çc][ãa]o|\(Atv\)|reprodu[çc][ãa]o',line,re.I):
            for m in re.finditer(r'(?<!\d)(\d+)\s*(?:de\s+)?PA\b',line,re.I):
                ambiguous.append({'value':int(m.group(1)),'unit':'PA (tipo não demonstrado)','evidence':line,'state':'MODALIDADE_PENDENTE'})
    # Deduplicate same cost/activity/evidence, avoid double-count regex.
    def uniq(items):
        seen=set();out=[]
        for q in items:
            key=(q['value'],q['unit'],q['evidence'])
            if key not in seen: seen.add(key);out.append(q)
        return out
    return {'daily':uniq(daily),'activation':uniq(activation),'ambiguous':uniq(ambiguous),
            'daily_state':'DOCUMENTADO' if daily else 'PENDENTE',
            'activation_state':'DOCUMENTADO' if activation else 'PENDENTE'}

def get_effects(src:str)->list[dict]:
    lines=[x.strip() for x in plain(src).splitlines() if x.strip()]
    result=[]
    for s in lines:
        # Lines are evidence, not confirmed independent effects; label only explicit modality.
        if re.search(r'\(Atv\)|\(Pass\)|\bEfeito M[áa]gico\s*:|\bDefesa\s*:|\bB[oô]nus\s*:|\bPoderes\s*:.{8,}|\d+d\d+|^Se\s+o\s+inimigo\s+|^É uma matriz',s,re.I) or (re.search(r'^[\wÀ-ÿ ]{4,40}:\s',s) and not re.search(r'^(Tipo|Categoria|Classificação|Custo|Anel Dimensional|Poderes|Composição|Conhecimento Geral)\s*:',s,re.I)):
            mode='ATIVO_EXPLICITO' if re.search(r'\(Atv\)',s,re.I) else ('PASSIVO_EXPLICITO' if re.search(r'\(Pass\)',s,re.I) else 'INDETERMINADO')
            if re.search(r'uma\s+vez\s+por\s+dia|uma\s+vez\s+por\s+turno|a[çc][ãa]o\s+padr[ãa]o',s,re.I) and mode=='INDETERMINADO':mode='USO_CONDICIONAL_EVIDENCIADO'
            role='DANO_DADOS' if re.search(r'\d+d\d+',s,re.I) else ('DEFESA' if re.search(r'^Defesa:',s,re.I) else ('EFEITO_CONDICIONAL' if re.search(r'^Se\s+o\s+inimigo|\bcontra\s+elementais',s,re.I) else 'EFEITO_DOCUMENTADO'))
            result.append({'mode':mode,'role':role,'evidence':s,'scope':'literal; sem aplicação universal'})
    return result

def detect_family_specific(fam:str|None,content:str,txt:str,costs:dict,refs:list[dict])->tuple[list[dict],list[str]]:
    checks=[];pending=[]
    def add(code,state,detail,evidence=''):
        checks.append({'code':code,'state':state,'detail':detail,'evidence':evidence})
        if state=='PENDENTE':pending.append(code)
    if fam=='MATRIZ':
        add('MATRIZ_NAO_PORTATIL','VERIFICADO','Módulo MATRIZ: sistema/instalação, não portátil automaticamente.','REC-MOD-MAT-01')
        has_recipe=any(r['kind']=='child_page' and re.search('Receita',r['label'],re.I) for r in refs)
        add('MATRIZ_RECEITA_VINCULADA','VERIFICADO' if has_recipe else 'PENDENTE','Página filha Receita referenciada; não comprova instalação.',str([r for r in refs if 'Receita' in r['label']]))
        add('MATRIZ_INSTALADA','PENDENTE','Padrão/receita não são evidência de uma ocorrência de matriz montada.')
    if fam=='ARTEFATO':
        if re.search(r'\b(?:gastar|consumir)\s+o\s+(?:[ôo]nix|artefato)',txt,re.I):
            add('ART_CONSUMO_UNICO','VERIFICADO','Consumo de artefato sustentado. Recarga não se presume.')
        elif re.search(r'\b(?:duas\s+vezes|uma\s+vez|registro\s+pode\s+ser\s+reproduzido)',txt,re.I):
            add('ART_USOS_CONDICIONADOS','VERIFICADO','Limites do efeito extraídos sem inferir número de cargas do objeto.')
        add('ART_RECARREGAMENTO','PENDENTE','Nenhuma política de recarga derivável por categoria.')
    if fam=='ARMADURA':
        if re.search(r'RD\s*\d+\s+a\s+ataques?\s+de\s+elemental',txt,re.I):
            add('ARD_RD_CONDICIONAL','VERIFICADO','RD somente contra ataques de elemental, não RD universal.')
        if re.search(r'\b(?:\d+\s*RM|\d+\s*RF|\d+\s*RDM|\bRDF\b)',txt,re.I):
            add('ARD_SIGLA_NAO_NORMALIZADA','PENDENTE','RM/RF/RDM/RDF exigem fonte de equivalência; não converter automaticamente em RD ou CA.')
    if fam=='ARMA':
        if re.search(r'contra\s+elementais',txt,re.I):add('ARMA_DANO_CONDICIONAL','VERIFICADO','Bônus restrito a elementais; não generalizar.')
        if re.search(r'\b\d+d\d+\b',txt,re.I):add('ARMA_DADOS_LITERAL','VERIFICADO','Expressão de dados preservada, sem calcular bônus inventados.')
    if fam=='ACESSORIO':
        if re.search(r'\b\(Pass\)\b|\(Pass\)',txt,re.I):add('EQA_PASSIVO_EXPLICITO','VERIFICADO','Modalidade passiva marcada na fonte.')
        if re.search(r'\(Atv\)',txt,re.I):add('EQA_ATIVO_EXPLICITO','VERIFICADO','Modalidade ativa marcada na fonte.')
    if fam in ('INSCRICAO_BATALHA','INSCRICAO_ENCANTAMENTO'):
        add('INS_PADRAO_INSTALADO','PENDENTE','Padrão mágico e receita histórica não comprovam ocorrência instalada.')
    if not costs['daily'] or not costs['activation']:
        add('PA_CAMPO_PENDENTE','PENDENTE','Custo diário ou por ativação sem fonte; não afirmar inexistência nem zero.')
    if not costs['daily'] and not costs['activation']:
        add('PA_NAO_DOCUMENTADO','PENDENTE','Não significa custo zero nem gratuidade de energia.')
    return checks,pending

def links_from_page(content:str)->list[dict]:
    out=[]
    for m in re.finditer(r'<page\s+url="([^"]+)"[^>]*>(.*?)</page>',content,re.S):
        out.append({'url':m.group(1),'label':plain(m.group(2)).strip(),'kind':'child_page'})
    for m in re.finditer(r'<mention-page\s+url="([^"]+)"',content):
        out.append({'url':m.group(1),'label':'referência','kind':'mention'})
    return out

def historical_recipe_audit(related:dict)->list[dict]:
    """Audita uma receita HISTÓRICA existente sem reescrever seus ingredientes.
    Prova apenas divergência literal em conceitos pesquisados, não equivalência química.
    """
    content=plain(related.get('content',''))
    checks=[]
    source=related.get('url')
    # Detector dirigido: identificar alteração de identidade material entre lista e processo.
    for original_in_ingredients,process_substitution in [
        ('Terra Encantada','Terra de Gigante'),
        ('Essência de Água da Nascente','Água de Nascente Élfica'),
    ]:
        a,b=content.split('Processo de Criação:',1) if 'Processo de Criação:' in content else (content,'')
        if original_in_ingredients.casefold() in a.casefold() and process_substitution.casefold() in b.casefold():
            checks.append({'code':'RECEITA_HISTORICA_TERMINOLOGIA_CONFLITANTE',
                           'state':'CONFLITO','source':source,
                           'detail':f'Ingredientes citam {original_in_ingredients}; processo usa {process_substitution}. Equivalência NÃO documentada; não corrigir receita.'})
    return checks

def inspect_source(src:dict)->dict:
    required={'uuid','url','title','content','source_tool','observed_at','source_surface','ancestry'}
    absent=sorted(required-set(src))
    if absent:return {'status':'ENVELOPE_INCOMPLETO','missing':absent,'no_new_recipe':True}
    sid=norm_id(src['uuid']);uid=norm_id(src['url'])
    if not sid or sid!=uid:return {'status':'IDENTIDADE_DIVERGENTE','no_new_recipe':True}
    if src['source_surface'] in FORBIDDEN_SURFACES or src['source_surface']!='MASTER_ITEMS':
        return {'status':'FONTE_FORA_ESCOPO_MESTRE','uuid':sid,'source_surface':src['source_surface'],'no_new_recipe':True}
    if src['source_tool']!='mcp__Notion__fetch':
        return {'status':'PROVENIENCIA_NAO_AUTORIZADA','uuid':sid,'no_new_recipe':True}
    if not isinstance(src['ancestry'],list) or not src['ancestry']:
        return {'status':'ANCESTRAL_NAO_VERIFICADO','uuid':sid,'no_new_recipe':True}
    raw=src['content']
    if not isinstance(raw,str) or not raw.strip():return {'status':'FONTE_SEM_CONTEUDO','uuid':sid,'no_new_recipe':True}
    if src.get('declared_content_sha256') and src['declared_content_sha256']!=digest(raw):
        return {'status':'EXCERTO_ALTERADO_APOS_EXPORTACAO','uuid':sid,'no_new_recipe':True}
    txt=plain(raw)
    fam,how=find_family(raw,src.get('family_hint'),src['ancestry'])
    # refuse confident family if supplied hint is the only evidence
    if how.startswith('dica EXTERNA'):fam=None
    if fam is None:
        return {'status':'FAMILIA_NAO_VERIFICADA','uuid':sid,'source':src['url'],'source_tool':src['source_tool'],'provenance':src['observed_at'],'no_new_recipe':True}
    rank_match=re.search(r'(?:\*\*)?Classifica[çc][ãa]o(?:\*\*)?\s*:\s*(Lend[áa]rio|Ouro Negro|Ouro|Prata|Bronze|Sem classifica[çc][ãa]o)',txt,re.I)
    rank=rank_match.group(1).strip() if rank_match else 'PENDENTE'
    if rank.lower()=='sem classificação':rank='Sem classificação'
    refs=links_from_page(raw)
    costs=extract_costs(raw)
    effects=get_effects(raw)
    checks,pending=detect_family_specific(fam,raw,txt,costs,refs)
    if rank=='PENDENTE':
        checks.append({'code':'RANK_NAO_DOCUMENTADO','state':'PENDENTE','detail':'Não deduzir rank do título nem do efeito.'});pending.append('RANK_NAO_DOCUMENTADO')
    if src.get('index_rank') and src['index_rank'].casefold()!=rank.casefold():
        checks.append({'code':'RANK_CONFLITO_INDICE_FICHA','state':'CONFLITO','detail':f"Index: {src['index_rank']} / ficha: {rank}; decisão por fonte competente pendente."});pending.append('RANK_CONFLITO_INDICE_FICHA')
    if src.get('related_historical_recipe'):
        recipe_checks=historical_recipe_audit(src['related_historical_recipe'])
        checks.extend(recipe_checks)
        pending.extend(x['code'] for x in recipe_checks if x['state'] in ('PENDENTE','CONFLITO'))
    if src.get('conflicts'):
        checks.append({'code':'CONFLITO_DECLARADO','state':'CONFLITO','detail':src['conflicts']})
    recipe=[x for x in refs if x['kind']=='child_page' and re.search(r'Receita',x['label'],re.I)]
    embedded=bool(re.search(r'(?im)^\s*Receita\s*:',txt))
    evidence=[]
    for x in costs['daily']+costs['activation']+costs['ambiguous']:
        evidence.append({'field':'custo_pa','literal':x['evidence'][:250]})
    for x in effects:evidence.append({'field':'efeito','literal':x['evidence'][:250]})
    output={'status':'QUALIFICACAO_FONTE_AUTORIZADA_EM_EXTRATO',
      'identity':{'uuid':sid,'url':src['url'],'title':src['title'],'family':fam,'module':MODULE[fam],'rank':rank,'family_basis':how},
      'provenance':{'source_tool':src['source_tool'],'source_surface':src['source_surface'],'observed_at':src['observed_at'],
         'content_sha256_excerpt':digest(raw),'excerpt_scope':src.get('capture_scope','texto extraído no readback autorizado'),
         'ancestry':src['ancestry'],'authenticity':'readback declarado pelo coletor, assinatura externa não comprovada'},
      'effects':effects,'costs':costs,'historical_recipe':{'linked_recipe_pages':recipe,'embedded_in_page':embedded,
         'real_fabrication_demonstrated':False},'references':refs,'family_checks':checks,'pending':pending,
      'evidence':evidence,'energy_interface':energy_envelope(src, fam, rank, effects, costs),
      'recipe_creation':'PROIBIDA','production_admissibility':'HOLD',
      'no_new_recipe':True}
    return output

def energy_envelope(src:dict,family:str,rank:str,effects:list,costs:dict)->dict:
    return {'contract':PA_VERSION,'state':'READY_FOR_COMPETENT_CONTRACT_NOT_CONNECTED',
      'ITEM-ID':norm_id(src['uuid']),'FAMILIA':family,'RANK':rank,
      'EFEITOS':effects,'MODALIDADE':'somente literal/explícita; demais INDETERMINADA',
      'MAGNITUDE':'conforme literal nos efeitos','DURACAO':'extrair de condições documentadas; sem extrapolar',
      'FREQUENCIA':'não inferida','CONDICOES':'conforme fonte original',
      'CUSTO_PA_HISTORICO':{'por_dia':costs['daily'],'por_ativacao':costs['activation'],'modalidade_indeterminada':costs['ambiguous']},
      'UNIDADE_PA':['PA/dia','PA/uso'],'PROVENIENCIA':{'url':src['url'],'source_observed_at':src['observed_at'],
                                                     'excerpt_sha256':digest(src['content'])},
      'CONFIANCA':'documental limitada ao extrato','PENDENCIAS':['integração PA competente não contratada'],
      'no_cost_estimation_by_craft':True}

def validate_external_pa(reply:dict)->dict:
    # No PA ENGINE endpoint assumed. Fixtures are testing only; never become official.
    if not isinstance(reply,dict):return {'status':'REJEITADO_FORMATO'}
    if reply.get('kind')=='FIXTURE_SIMULADA':
        return {'status':'SIMULACAO_NAO_OFICIAL','message':'Valor mock não é PA verdadeiro nem libera receita, ativação ou produção.'}
    return {'status':'INTERFACE_EXTERNA_NAO_CONTRATADA','message':'Modelo PA competente não validado nesta bancada; não aceitar valores sem autoridade/versão/proveniência.'}

def compare_readbacks(first:dict,second:dict)->dict:
    a,b=norm_id(first.get('uuid','')),norm_id(second.get('uuid',''))
    if not a or a!=b:return {'status':'ITENS_DIFERENTES','same_item':False}
    d1,d2=digest(first['content']),digest(second['content'])
    return {'status':'SEM_ALTERACAO' if d1==d2 else 'MUDANCA_DE_CONTEUDO_NAO_RECONCILIADA',
            'same_item':True,'first_sha256':d1,'second_sha256':d2,'first_at':first.get('observed_at'),
            'second_at':second.get('observed_at'),'can_auto_promote':False}

def compatibility(item:dict,proposal:str,other:dict|None=None)->dict:
    """Responde só ao comprovado; não estabelece novas regras universais."""
    fam=item.get('identity',{}).get('family')
    s=proposal.casefold()
    if not fam:return {'status':'INDETERMINADO','reason':'Fonte sem família verificada.'}
    if 'fabricar' in s or 'receita nova' in s:
        return {'status':'INCOMPATIVEL_VERIFICADO','reason':'Decisão posterior expressa do Mestre proíbe receitas novas e fabricação produtiva nesta missão.'}
    if fam=='MATRIZ' and ('anel dimensional' in s or 'automaticamente portátil' in s):
        return {'status':'INCOMPATIVEL_VERIFICADO','reason':'REC-MOD-MAT-01: matriz é instalação, não item portátil por padrão.'}
    if fam=='INSCRICAO_BATALHA' and 'já instalada' in s:
        return {'status':'INDETERMINADO','reason':'Padrão/receita histórica não provam ocorrência instalada; procurar relação de ocorrência.'}
    if fam=='ARMADURA' and 'rd universal' in s:
        if any(c.get('code')=='ARD_RD_CONDICIONAL' for c in item.get('family_checks',[])):
            return {'status':'INCOMPATIVEL_VERIFICADO','reason':'RD explicitamente condicionada à classe de ataque.'}
        return {'status':'INDETERMINADO','reason':'Não há regra universal de RD demonstrada.'}
    if fam=='ACESSORIO' and 'pa por dia é zero' in s and not item['costs']['daily']:
        return {'status':'INCOMPATIVEL_VERIFICADO','reason':'PA diário não documentado permanece PENDENTE, não 0.'}
    if other and 'instalar' in s:
        return {'status':'POTENCIALMENTE_COMPATIVEL','reason':'Famílias conhecidas; suporte, regras de instalação, rank, ocorrência e energia exigem validação independente.'}
    return {'status':'INDETERMINADO','reason':'Ausência de prova competente de compatibilidade ou proibição específica no corpus lido.'}

def consult(result:dict)->str:
    if result.get('status')!='QUALIFICACAO_FONTE_AUTORIZADA_EM_EXTRATO':
        return f"{result.get('status')}: fonte não qualificada; não completar campos sem evidência."
    i=result['identity'];c=result['costs'];h=result['historical_recipe']
    def p(v,unit):return '; '.join(f"{x['value']} {unit}" for x in v) if v else 'PENDENTE'
    ev=[f"{e['mode']}: {e['evidence'][:165]}" for e in result['effects'][:5]]
    return (f"{i['title']} — {i['family']} / {i['rank']} ({i['module']})\n"
      f"Fonte: {i['url']} | leitura: {result['provenance']['observed_at']}\n"
      f"Efeitos/modos explicitados: {'; '.join(ev) or 'modo não certificado; consultar literal da ficha'}\n"
      f"PA diário: {p(c['daily'],'PA/dia')} | PA ativação: {p(c['activation'],'PA/uso')}\n"
      f"Receita histórica ligada: {len(h['linked_recipe_pages'])} página(s); embutida: {h['embedded_in_page']}."
      " Isso não significa item fabricado/instalado.\n"
      f"Pendências: {', '.join(result['pending']) or 'nenhuma nos verificadores aplicados'}.\n"
      "PARECER: leitura documental experimental; custos sem fonte pendentes; fabricar/ativar/receitas novas BLOQUEADOS.")

def main():
    p=argparse.ArgumentParser(description='CRAFT QMC-02 — analisa envelope readback autorizado, nunca conecta automaticamente')
    p.add_argument('--envelope',required=True,help='JSON exportado de Notion por Comestre autorizado')
    p.add_argument('--item',help='UUID/URL do item dentro do envelope; se omitido inspeciona todos')
    p.add_argument('--text',action='store_true')
    p.add_argument('--out',help='Escreve só parecer local read-only')
    p.add_argument('--compare',help='Segundo envelope para comparar a mesma fonte')
    a=p.parse_args()
    data=json.loads(Path(a.envelope).read_text(encoding='utf8'))
    items=data['sources'] if isinstance(data,dict) and 'sources' in data else [data]
    if a.item:items=[x for x in items if norm_id(x.get('uuid',''))==norm_id(a.item)]
    res=[inspect_source(x) for x in items]
    if a.compare:
        x=json.loads(Path(a.compare).read_text(encoding='utf8'))
        newitems=x['sources'] if isinstance(x,dict) and 'sources' in x else [x]
        res.append({'comparison':[compare_readbacks(a,b) for a in items for b in newitems if norm_id(a['uuid'])==norm_id(b['uuid'])]})
    out='\n\n'.join(consult(x) if x.get('identity') else json.dumps(x,ensure_ascii=False) for x in res) if a.text else json.dumps(res,ensure_ascii=False,indent=2)
    if a.out:Path(a.out).write_text(out+'\n',encoding='utf8')
    print(out)
if __name__=='__main__':main()
