# CRAFT QMC-02 — Demonstrações conversacionais Mestre-side

**Fonte real:** extratos documentais recuperados por `mcp__Notion__fetch` durante a missão e reconfrontados por UUID/URL. **Não são consultas automáticas do script à rede.** Todas as respostas abaixo são leitura do cânone existente, não testes de ativação no jogo.

## A — "Essa Bota Caminho Veloz gasta PA diariamente e para ativar?"

**Sim.** [Bota Caminho Veloz](https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c) documenta **18 PA por dia** e a habilidade **Velocidade Sobrenatural (Atv), +8 m, 5 PA**. Também há *Passos sem Pegadas* e *Adaptação de Terreno*, rotulados como passivos. O bloco de bônus registra +6 m de deslocamento, sem ser confundido automaticamente com os +8 m da habilidade ativa. Não foi verificado se os dois bônus se acumulam; tal regra não será inventada. A classificação pública é **Sem classificação** na ficha, não Bronze por analogia.

## B — "O Amuleto Tempo Eterno gasta 15 PA por dia ou para ativar?"

**Ambos os valores aparecem, com unidades diferentes** na [ficha canônica](https://app.notion.com/p/3edc2b324ede8132bbc8f857f4b276c4): **15 PA por dia** e **15 PA para ativar**. A ficha também diz **uma utilização a cada dois dias**. Isso NÃO autoriza reduzir custo ou definir rotina de pagamento, esgotamento e interação energética: tais decisões pertencem ao sistema competente de PA.

## C — "O Orbe da Palavra Guardada custa quanto para gravar e reproduzir?"

O [Orbe da Palavra Guardada](https://app.notion.com/p/3f5c2b324ede81a89213c1a391293b59) documenta **10 PA** para iniciar uma captação de até **60 segundos**, com Ação Padrão, e **5 PA** para reproduzir o registro, também com Ação Padrão. São **dois custos por ativação de funções distintas**, não soma automática nem PA por dia. A captura pode ser iniciada uma vez por descanso de oito horas e a reprodução possui restrições de dois usos e sete dias. O custo PA diário é **PENDENTE** por ausência na ficha; não equivale a zero.

## D — "A Matriz de Cultivo possui receita e já foi instalada?"

A [Matriz de Cultivo](https://app.notion.com/p/3edc2b324ede81fe98faf689b2750291) contém uma **página filha de receita histórica**. Isso prova existência documental da receita referenciada, mas **não prova que uma ocorrência da matriz foi montada ou ativada**. A [receita histórica](https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6) contém pelo menos **duas divergências materiais literais**: ingredientes citam **Terra Encantada** mas o processo cita **Terra de Gigante**; ingredientes citam **Essência de Água da Nascente** mas o processo cita **Água de Nascente Élfica**. Não foi comprovado que sejam sinônimos. A bancada bloqueia reconciliação inventada e não cria uma versão corrigida.

## E — "Posso levar a Matriz Espacial dos 10 Milênios no anel dimensional?"

A [Matriz Espacial dos 10 Milênios](https://app.notion.com/p/3edc2b324ede8166b3aed4b90f7a0a86) pertence à família **MATRIZ**, classificação Lendário. A ficha a caracteriza como matriz de proteção contra bestas, com vulnerabilidade a conhecedores de matrizes. O módulo `REC-MOD-MAT-01` define matrizes como **instalações**, não itens portáteis por padrão. A própria ficha afirma que a capacidade de anel dimensional **não se aplica a conteúdo não físico**. Não extrapolar para um kit desmontado/transportável sem evidência.

## F — "Essa Adaga da Serpente Enfeitiçada custa 35 PA por dia?"

**Não é possível concluir isso.** A [Adaga da Serpente Enfeitiçada](https://app.notion.com/p/3edc2b324ede811787a0de913622b14d) registra `5d4+5d8+10` de dano, uma salvaguarda de Constituição **CD 25**, e `3d12` de veneno por turno caso o inimigo falhe. A mesma página traz **"35 de PA"**, mas **não especifica a unidade diária nem a ativação** nesse trecho. A QMC-02 preserva a ambiguidade, sem converter arbitrariamente em PA/dia ou PA/uso. O cálculo de dano final exige também o módulo DMG competente.

## G — "Essas armaduras têm proteção universal?"

Não. [Manto de Abismo](https://app.notion.com/p/3edc2b324ede81a5b09dc45deac36b43) cita *15 RM e 10 RF*, siglas não normalizadas neste extrato; não podem ser convertidas automaticamente em CA ou RD geral. [Vestes de Lydandra](https://app.notion.com/p/3edc2b324ede813f80c1dc8f23f05ec8) traz `+5 CA`, um escudo **uma vez por dia com duração de 10 minutos**, e outros benefícios. Não há custo PA explícito nas fichas lidas; a QMC não inventa custo e não concede ativação.

## H — "E os aprimoramentos?"

O módulo canônico [REC-MOD-APR-01](https://app.notion.com/p/3f1c2b324ede81958b48da97806423f3) rege aprimoramentos e exige item-base e delta verificáveis. Ele declara que não há categoria Mestre-side autônoma no mapa atual de Itens. Os candidatos localizados sob **Inventário/Catálogo/Aprimoramento** não foram automaticamente tratados como itens Mestre-side homologados. **0 exemplos Mestre-side autônomos de aprimoramento validados nesta execução**; verificar a autoridade de cada relação item-base→delta antes de uso.

## I — "Quanto PA esse item deveria gastar?"

O CRAFT fornece somente os **custos históricos documentados**, indicando PA/dia, PA/uso e modalidade pendente. Não estima o "deveria". O contrato interno `QMC-PA-INTERCHANGE-CANDIDATE-1` produz dados rastreáveis para o futuro sistema competente; qualquer resposta de teste marcada `FIXTURE_SIMULADA` é rejeitada como custo oficial. **PA científico e novas receitas seguem HOLD**.
