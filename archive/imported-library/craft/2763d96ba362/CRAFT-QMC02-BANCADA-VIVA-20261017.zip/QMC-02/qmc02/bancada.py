#!/usr/bin/env python3
"""CRAFT — Bancada de Qualificação Multicategoria, TEST / READ-ONLY.

Não gera receitas, BOMs, novos itens, PA ou estados de campanha.
Snapshots tipados são EXTRATOS MANUAIS verificados nas páginas Mestre em 2026-10-17.
São consultas offline sobre um corpus de seis páginas, não integração Notion live.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, sys
from pathlib import Path

VERSION='CRAFT-QUAL-MULTI-01'
STATE_UNSET='PENDENTE'
FAMILY_MODULE={
 'ARMA':'REC-MOD-ARM-01', 'ARMADURA':'REC-MOD-ARD-01',
 'ACESSORIO':'REC-MOD-EQA-01', 'ARTEFATO':'REC-MOD-ART-01',
 'INSCRICAO_BATALHA':'REC-MOD-BAT-01', 'INSCRICAO_ENCANTAMENTO':'REC-MOD-ENC-01',
 'MATRIZ':'REC-MOD-MAT-01','APRIMORAMENTO':'REC-MOD-APR-01',
}
MODULE_URLS={
 'ARMA':'https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649',
 'ARMADURA':'https://app.notion.com/p/3f1c2b324ede8116bd3cc6606a1c6687',
 'ACESSORIO':'https://app.notion.com/p/3f1c2b324ede818ab3c0d913574eed28',
 'ARTEFATO':'https://app.notion.com/p/3f1c2b324ede81b48b33d0877ee107d3',
 'INSCRICAO_BATALHA':'https://app.notion.com/p/3f1c2b324ede81c1bda7d07e0b5456e9',
 'INSCRICAO_ENCANTAMENTO':'https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6',
 'MATRIZ':'https://app.notion.com/p/3f1c2b324ede819ca142cbf1eb992fac',
 'APRIMORAMENTO':'https://app.notion.com/p/3f1c2b324ede81958b48da97806423f3'
}
# Data is a typed extraction from verified Notion pages. Excerpts exactly present in source.
# Absence in this extraction is not global absence across all source history.
SNAPSHOTS={
 '3edc2b324ede8156849bf1aae0ce9fb5':{
  'title':'Arco Exterminador Elemental','family':'ARMA','rank':'Lendário',
  'materials':[], 'effects':[{'kind':'damage_base','value':'8d8+25','evidence':'8d8+25 de dano'},
   {'kind':'damage_conditional','value':'+8d12+10 contra elementais','evidence':'Você tem +8d12+10 de dano contra elementais.'},
   {'kind':'bonus_conditional','value':'+15 Percepção para rastrear elemental','evidence':'+15 de Percepção para rastrear um elemental.'}],
  'mechanics':{'weapon_type':'arco','target_condition':'elemental','range':None,'ammo':None},
  'pa_daily':64,'pa_activation':None,'activation_action':None,'duration':None,
  'charges':None,'reaction':None,'consumable':None, 'historical_recipe':None,
  'evidence':{'rank':'**Classificação:** Lendário','daily':'64 PA por dia.'}},
 '3edc2b324ede81018124d63cd8508ea2':{
  'title':'Espada Chamas Vivas','family':'ARMA','rank':'Ouro Negro',
  'materials':['Ouro do Abismo ardente','Cristal de Calor Abrasador'],
  'effects':[{'kind':'damage','value':'5d10+5d8+15','evidence':'5d10+5d8+15'},
   {'kind':'descriptive','value':'aura ardente e poder flamejante','evidence':'Ela tem um Cristal de Calor Abrasador, contando com um forte poder flamejante.'}],
  'mechanics':{'weapon_type':'espada','target_condition':None,'range':None,'ammo':None},
  'pa_daily':None,'pa_activation':None,'activation_action':None,'duration':None,
  'charges':None,'reaction':None,'consumable':None,'historical_recipe':None,
  'evidence':{'rank':'**Classificação:** Ouro Negro','materials':'uma espada feita com Ouro do Abismo ardente','damage':'5d10+5d8+15'}},
 '3edc2b324ede8127a576ee01c44bd1d4':{
  'title':'Armadura Guardiã Elemental','family':'ARMADURA','rank':'Ouro Negro',
  'materials':[],
  'effects':[{'kind':'armor_CA','value':12,'evidence':'Armadura Pesada 12 CA'},
   {'kind':'RD_conditional','value':35,'condition':'ataques de elemental','evidence':'Tem RD 35 a ataques de elemental'},
   {'kind':'save_bonus_conditional','value':8,'condition':'elementais','evidence':'+8 para salvaguardas contra elementais'},
   {'kind':'CA_bonus_conditional','value':6,'condition':'Elementais','evidence':'+6 CA contra Elementais'}],
  'mechanics':{'armor_class':'pesada','mobility':None,'fit':None},
  'pa_daily':55,'pa_activation':None,'activation_action':None,'duration':None,
  'charges':None,'reaction':None,'consumable':None,'historical_recipe':None,
  'evidence':{'daily':'55 PA por dia','rd':'Tem RD 35 a ataques de elemental','rank':'**Classificação:** Ouro Negro'}},
 '3f5c2b324ede81eaa080cad94c16dd3b':{
  'title':'Braçadeira do Pulmão de Ferro','family':'ACESSORIO','rank':'Ouro',
  'materials':['placas de ferro cinza','couro escuro','elemento filtrante','inscrições'],
  'effects':[{'kind':'active','value':'filtro respiratório e ocular contra partículas sólidas em suspensão','evidence':'1 Ação Padrão e 15 PA'},
   {'kind':'mitigation_conditional','value':20,'condition':'dano ambiental por areia, pó mineral ou cinzas sólidas em suspensão','evidence':'reduz em até **20 pontos** cada ocorrência de dano ambiental'},
   {'kind':'save_bonus_conditional','value':6,'condition':'Salvaguarda de CON contra efeito sobrenatural de partículas sólidas','evidence':'recebe **+6** nessa salvaguarda'}],
  'mechanics':{'wearable':'antebraço','duration_minutes':10,'uses_per_rest':1,'rest_hours':8,'activation_action':'1 Ação Padrão',
   'not_protect_against':['gases tóxicos','falta de oxigênio','fumaça predominantemente gasosa','veneno ingerido','feitiço não particulado'],
   'maintenance':'limpeza após uso intenso; filtro obstruído impede nova ativação'},
  'pa_daily':None,'pa_activation':15,'activation_action':'1 Ação Padrão','duration':'10 minutos',
  'charges':None,'reaction':None,'consumable':None,'historical_recipe':None,
  'evidence':{'active':'mediante **1 Ação Padrão e 15 PA**','duration':'por **10 minutos**','rank':'**Classificação:** Ouro'}},
 '3edc2b324ede8115a287e69daf383b38':{
  'title':'Ônix de Proteção','family':'ARTEFATO','rank':'Sem classificação',
  'materials':['minério (ônix)'],
  'effects':[{'kind':'defensive','value':'campo de força protetor de ataques físicos e mágicos','evidence':'Este minério cria um campo de força ao redor do usuário'}],
  'mechanics':{'reaction':True,'spend_item':True,'defense_magnitude':None,'recharge':None},
  'pa_daily':None,'pa_activation':None,'activation_action':None,'duration':None,
  'charges':None,'reaction':'gasta uma Reação','consumable':True,'historical_recipe':None,
  'evidence':{'reaction':'Você pode usar sua reação para gastar o Onix de proteção e o proteger de um ataque.',
    'rank':'**Classificação:** Sem classificação'}},
 '3edc2b324ede81a28d05d128b5a4efdd':{
  'title':'Inscrição Fúria do Leviatã','family':'INSCRICAO_BATALHA','rank':'Prata',
  'materials':['Núcleo de vida de um Leviatã das Profundezas (P)','Sangue de Kraken (CG)',
   'Pó de Pérola do Abismo','Essência de Alga do Maremoto','pergaminho (suporte histórico)'],
  'effects':[{'kind':'active','value':'onda colossal de água, arrasta inimigos e causa estragos sem dano numérico documentado','evidence':'Quando ativada, a inscrição libera uma onda colossal'}],
  'mechanics':{'kind':'padrão de inscrição de batalha','historical_paste_name':'Pasta Mágica da Fúria do Leviatã',
   'historical_recipe_embedded':True,'installed_instance_verified':False,'knowledge_general':False,
   'activation_trigger':None,'damage_formula':None,'range':None},
  'pa_daily':None,'pa_activation':None,'activation_action':None,'duration':None,
  'charges':None,'reaction':None,'consumable':None,'historical_recipe':True,
  'evidence':{'recipe':'Receita: Pasta Mágica da Fúria do Leviatã','process':'Processo de Criação:',
    'rank':'**Classificação:** Prata','knowledge':'**Conhecimento Geral (CG):** Não'}},
}
UUID_TO_KEY={x:x for x in SNAPSHOTS}
NAME_TO_KEY={v['title'].casefold():k for k,v in SNAPSHOTS.items()}
FIELDS=('pa_daily','pa_activation','duration','charges','reaction','consumable','historical_recipe')

def resolve_item(query):
    key=query.strip().lower().replace('-','')
    if key.startswith('https://'):
        key=key.split('/p/')[-1].split('?')[0].replace('-','')
    if key in SNAPSHOTS:return key
    if query.strip().casefold() in NAME_TO_KEY:return NAME_TO_KEY[query.strip().casefold()]
    return None

def pa_interface(raw):
    # Typed contract for future competent external PA engine; never computes daily cost.
    def p(v,unit):
        return {'status':'DOCUMENTADO' if v is not None else STATE_UNSET,
                'value':v,'unit':unit,'source':'ficha canônica' if v is not None else None}
    return {
        'pa_por_dia':p(raw['pa_daily'],'PA/dia'),
        'pa_por_ativacao':p(raw['pa_activation'],'PA/uso'),
        'duracao':p(raw['duration'],'tempo'),
        'frequencia':p(raw['mechanics'].get('uses_per_rest'),'por descanso'),
        'cargas':p(raw['charges'],'cargas'),
        'recarga':p(raw['mechanics'].get('recharge'),'método'),
        'reacao':p(raw['reaction'],'reação'),
        'consumo_do_item':p(raw['consumable'],'booleano'),
        'efeitos_passivos':[e for e in raw['effects'] if e.get('activation_mode')=='passive_explicit'],
        'efeitos_ativos':[e for e in raw['effects'] if e['kind']=='active'],
        'efeitos_reativos':[e for e in raw['effects'] if raw.get('reaction') is not None],
        'efeitos_com_modo_nao_documentado':[e for e in raw['effects'] if e['kind']!='active' and e.get('activation_mode') is None and raw.get('reaction') is None],
        'custo_manutencao':p(None,'a determinar'),
        'fonte_de_energia':p(None,'a determinar'),
        'requisitos_portador':p(None,'a determinar'),
        'suficiencia_energetica':{'status':'NAO_AVALIADA_POR_CRAFT','value':None},
        'regra_energia':{'status':'DEPENDENCIA_EXTERNA_PENDENTE','value':None},
    }

def classify(raw):
    fam=raw['family']; checks=[]; blocked=[]
    def check(test,code,message):
        checks.append({'id':code,'status':'OK' if test else 'PENDENTE','reason':message})
    if fam=='ARMA':
        check(bool(raw['mechanics'].get('weapon_type')),'ARMA_TIPO','Tipo do armamento registrado')
        check(any(e['kind'].startswith('damage') for e in raw['effects']),'ARMA_DANO','Dano literal documentado')
        check(bool(raw['materials']),'ARMA_MATERIALIDADE','Corpo/materialidade não completável por inferência')
        check(raw['mechanics'].get('range') is not None or raw['mechanics']['weapon_type']!='arco','ARMA_ALCANCE','Alcance ausente para arma de projétil')
        check(raw['activation_action'] is not None,'ARMA_ATIVACAO_MAGICA','Ação/gatilho de habilidade mágica não documentados; não inferir passividade')
    elif fam=='ARMADURA':
        check(any(e['kind']=='armor_CA' for e in raw['effects']),'ARD_CA','CA ou defesa explícita')
        check(raw['mechanics'].get('mobility') is not None,'ARD_MOBILIDADE','Mobilidade não fornecida')
        check(raw['mechanics'].get('fit') is not None,'ARD_AJUSTE','Compatibilidade corporal não fornecida')
    elif fam=='ACESSORIO':
        check(raw['mechanics'].get('wearable') is not None,'EQA_SLOT','Interface física demonstrada')
        check(raw['pa_activation'] is not None,'EQA_PA_ATIVO','PA da habilidade documentado')
        check(raw['mechanics'].get('uses_per_rest') is not None,'EQA_LIMITE','Limite de uso documentado')
    elif fam=='ARTEFATO':
        check(raw['consumable'] is not None,'ART_CONSUMO','Consumo do artefato explicitado')
        check(raw['reaction'] is not None,'ART_REACAO','Uso de Reação documentado')
        check(raw['mechanics'].get('recharge') is not None,'ART_RECARGA','Recarga não declarada')
    elif fam.startswith('INSCRICAO'):
        check(raw['historical_recipe'] is True,'INS_REC_HIST','Receita histórica está embutida na ficha')
        check(raw['mechanics'].get('installed_instance_verified') is True,'INS_OCORRENCIA','Padrão ou receita não equivale a inscrição instalada')
        check(raw['mechanics'].get('activation_trigger') is not None,'INS_GATILHO','Gatilho de ativação não determinado')
    else:
        check(False,'MOD_CASE_UNAVAILABLE','Família tem módulo, mas nenhum caso recuperado no snapshot')
    return checks

def inspect(query,observed=None,ask_activate=False):
    k=resolve_item(query)
    if k is None:
        return {'status':'NECESSITA_LEITURA_CANONICA','query':query,'reason':'Não presente nos seis extratos verificados; fornecer fonte para inspeção e readback, sem preencher campos.'}
    baseline=copy.deepcopy(SNAPSHOTS[k]);actual=copy.deepcopy(baseline if observed is None else observed)
    # Per-record immutable trusted baseline in this tool. An external copy is UNTRUSTED.
    if actual!=baseline:
        differences=[f for f in set(actual)|set(baseline) if actual.get(f)!=baseline.get(f)]
        return {'status':'REJEITADO_FONTE_DIVERGENTE','item':baseline['title'],'source_id':k,
                'different_fields':sorted(differences),'reason':'Cópia adulterada/variável não condiz com extrato canônico verificado; não promove valores.'}
    checks=classify(baseline)
    p=pa_interface(baseline)
    critical=['pa_por_dia','pa_por_ativacao']
    # Lack of daily cost does NOT prove a daily cost is needed; external motor decides.
    missing=[f for f in critical if p[f]['status']==STATE_UNSET]
    unknown=[c['id'] for c in checks if c['status']=='PENDENTE']
    return {
       'status':'QUALIFICACAO_READONLY_CONCLUIDA','source':f'https://app.notion.com/p/{k}',
       'source_scope':'extrato verificado em 17/10/2026; inspeção offline, não readback ao vivo',
       'identity':{'uuid':k,'name':baseline['title'],'family':baseline['family'],
                   'module':FAMILY_MODULE[baseline['family']],'module_url':MODULE_URLS[baseline['family']],'rank_public':baseline['rank']},
       'effects':baseline['effects'],'materials_documented':baseline['materials'],
       'mechanics_documented':baseline['mechanics'],'historical_recipe':{
          'status':'DOCUMENTADA_NA_FICHA' if baseline['historical_recipe'] is True else 'NAO_VERIFICADA_NESTE_EXTRATO',
          'not_an_authorization_to_complete':True},
       'energy_contract':p,'checks':checks,'unresolved_checks':unknown,'missing_pa_fields':missing,
       'engineering_admissibility':'INSPECAO_DOCUMENTAL_COM_PENDENCIAS' if unknown or missing else 'INSPECAO_DOCUMENTAL_SEM_PENDENCIA_LISTADA',
       'production_admissibility':'HOLD_SEM_WRITER_E_SISTEMA_PA_COMPLETO',
       'activation_admissibility':'BLOQUEADA_NESTA_BANCADA' if ask_activate else 'NAO_SOLICITADA',
       'no_new_recipe':True,
       'evidence_excerpts':baseline['evidence']
    }

def render_text(result):
    """Compacta o parecer, conservando estados e origem para uso no celular."""
    if isinstance(result,list):
        return '\n\n'.join(render_text(r) for r in result)
    if result.get('status')!='QUALIFICACAO_READONLY_CONCLUIDA':
        return f"{result.get('status')}: {result.get('reason','Fonte incompatível ou ausente')}" 
    ident=result['identity'];e=result['energy_contract']
    def f(k):
        v=e[k]
        return str(v['value'])+' '+v['unit'] if v['status']=='DOCUMENTADO' else 'PENDENTE'
    checks=result['checks']
    pending=[x['id'] for x in checks if x['status']=='PENDENTE']
    eff='; '.join(str(x['value']) for x in result['effects'])
    ing='; '.join(result['materials_documented']) if result['materials_documented'] else 'não explicitada no extrato'
    recipe=result['historical_recipe']['status']
    return (f"{ident['name']} — {ident['rank_public']} / {ident['family']} / {ident['module']}\n"
            f"Fonte: {result['source']}\n"
            f"Efeitos documentados na ficha: {eff}\n"
            f"Materiais citados (NÃO é receita/BOM): {ing}\n"
            f"PA por dia: {f('pa_por_dia')} | PA por ativação: {f('pa_por_ativacao')}\n"
            f"Receita histórica: {recipe}. Limitações técnicas: {', '.join(pending) if pending else 'nenhuma destas verificações pendente'}.\n"
            f"PARECER: documentação inspecionada; produção HOLD; ativação real NÃO AUTORIZADA por esta Bancada."
    )

def main(argv=None):
    a=argparse.ArgumentParser(description='Bancada CRAFT read-only; consulte fichas historicamente existentes')
    a.add_argument('item',nargs='?',help='UUID, URL ou nome exato. Ausente lista o corpus.')
    a.add_argument('--all',action='store_true')
    a.add_argument('--text',action='store_true',help='Parecer conciso para leitura no celular')
    a.add_argument('--activate',action='store_true',help='Tenta ativar: bloqueada em qualquer caso')
    a.add_argument('--json-out',help='Grava APENAS resultado da consulta no caminho local')
    ar=a.parse_args(argv)
    if ar.all or ar.item is None:
        result=[inspect(k) for k in SNAPSHOTS]
    else:result=inspect(ar.item,ask_activate=ar.activate)
    raw=json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)
    if ar.json_out:Path(ar.json_out).write_text(raw+'\n',encoding='utf8')
    print(render_text(result) if ar.text else raw)
    return 0
if __name__=='__main__':sys.exit(main())
