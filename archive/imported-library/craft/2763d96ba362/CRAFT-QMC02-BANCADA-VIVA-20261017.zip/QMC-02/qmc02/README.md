# QMC-02 — Continuação funcional de QMC-01 (MESTRE-SIDE, TEST)

## Escopo

Extensão incremental da Bancada original, sem segunda fábrica nem segundo sistema PA. A base `bancada.py` e os dez testes `test_bancada.py` permanecem byte-a-byte iguais aos do ZIP autenticado QMC-01. `qmc02.py` adiciona aceitação de envelopes de conteúdo Notion obtidos por ferramenta autorizada, análise de **10 novos itens não presentes no pacote original**, cobrindo 7/8 módulos especializados no acumulado com QMC-01, custos PA por modalidade, condições, receitas ligadas, ocorrências, detecção de conflitos, comparação de versões e interface energética **SEM cálculo**.

### Proveniência e verdadeiro limite de leitura ao vivo

**Este Comestre realizou fetch de páginas reais por ferramenta Notion autorizada nesta conversa.** O script Python **não possui cliente Notion embutido** e não faz fetch via rede. `source_readbacks.json` é **transcrição de trechos selecionados** dessas páginas, com UUID, URL, categoria, ancestral, data `as of` retornada pelo Notion e indicação de fonte. O hash SHA-256 aplicado pelo motor **cobre apenas o trecho transcrito**, não a página completa do Notion. O campo `source_tool` no JSON é **declaração de proveniência**, não assinatura eletrônica ou prova de ACL. A verificação humana de que o envelope corresponde ao retorno autorizado continua obrigatória.

Para novo item: o Comestre recebe URL/UUID na conversa, realiza `notion.fetch` usando acesso Master autorizado, verifica ancestral e superfície, transmite conteúdo retornado ao envelope local tipado, e roda consulta. Não confundir etapa de coleta do Comestre com acesso live nativo do script. Links privados nunca são buscados com web público.

### Uso em cópia limpa

Python 3.10+ sem dependências externas:

```
python -m unittest -v test_bancada test_qmc02
python qmc02.py --envelope source_readbacks.json --text
python qmc02.py --envelope source_readbacks.json --item https://app.notion.com/p/3edc2b324ede8135b199fd0cdbb5463c --text
python qmc02.py --envelope source_readbacks.json --out consulta.json
```

`source_readbacks.json` pode conter qualquer número de envelopes `sources[]`. Os dados de origem são **somente leitura**. A saída de `--out` é um relatório local, não um item/receita Notion.

### Conteúdo aceito / recusado

Aceita UUID/URL consistentes, fonte autorizada declarada, superfície Mestre, ancestral verificável, `content` da página, as-of. Compara hash do trecho entre envelopes; mudança implica revalidação, não atualização silenciosa. Rejeita formulário sem fonte, links com UUID incompatível, arquivo sem conteúdo, superfície Party/legado, modo de PA não comprovado e `FIXTURE_SIMULADA` como custo oficial. Rótulo de rank conflitante com índice vira PENDENTE.

### Categoria aprimoramento

O módulo REC-MOD-APR-01 foi relido e reconhecido; nele consta **ausência de categoria autônoma Mestre-side** no mapa de itens. Páginas de aprimoramento achadas em Inventário legado/Party Espelho não foram importadas nem classificadas como fonte canônica Mestre. É **bloqueio documentado de caso-real Mestre-side**, não falha de cobertura escondida. O executor pode qualificar um aprimoramento quando houver **item-base+delta** e autorização/linhagem competente; este pacote não cria isso.

### Segurança

- ZERO receitas novas, BOMs autorais, itens, REC-ID e produção.
- ZERO alteração de fichas Mestre, Party, O Primeiro, REC-LIB, writer/lease, SQLite ou motor histórico.
- `F5=RED`; `C19-021=UNKNOWN`; `0/30 RC5`; autoridade/lease material **não demonstrados**.
- NAC-PASS proporcional APENAS para reprocessamento local e pacote. HOLD para integração direta com PA, ativação, fabricação e publicação.
- Não atribui arbitrariamente PA ao item; nenhuma API do Comestre de PA foi inventada.

### Falsificabilidade

Os 37 testes (10 regressões originais + 27 novos) verificam interpretação de custos duplos, múltiplas habilidades, campos ambíguos, matrizes, divergência entre ingredientes e processo de receita histórica, dados trocados, rank conflitante, identidade, duas versões, superfície/autoridade errada, mock energético, não regressão QMC-01. Dois fetches repetidos da Bota e da Matriz de Cultivo retornaram conteúdo igual e mesmo as-of — não comprovam detecção de mudanças históricas reais.
