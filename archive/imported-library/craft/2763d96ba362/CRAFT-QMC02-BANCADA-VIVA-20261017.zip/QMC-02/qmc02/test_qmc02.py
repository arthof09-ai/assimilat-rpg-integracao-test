import copy, json, tempfile, unittest
from pathlib import Path
import bancada as old
from qmc02 import inspect_source,extract_costs,compare_readbacks,compatibility,validate_external_pa,inspect_source,energy_envelope,consult,digest,historical_recipe_audit

SOURCE=json.loads(Path(__file__).with_name('source_readbacks.json').read_text(encoding='utf8'))['sources']
LOOK={s['title']:s for s in SOURCE}

def q(n):return inspect_source(copy.deepcopy(LOOK[n]))

class QMC02Functional(unittest.TestCase):
    def test_qmc01_baseline_preserved(self):
        self.assertEqual(len(old.SNAPSHOTS),6)
        self.assertEqual(old.inspect('Arco Exterminador Elemental')['energy_contract']['pa_por_dia']['value'],64)
        self.assertEqual(old.inspect('Ônix de Proteção')['production_admissibility'],'HOLD_SEM_WRITER_E_SISTEMA_PA_COMPLETO')
    def test_ten_new_sources(self):
        self.assertEqual(len(SOURCE),10)
        self.assertTrue(all(q(s['title'])['status']=='QUALIFICACAO_FONTE_AUTORIZADA_EM_EXTRATO' for s in SOURCE))
    def test_enchantment_inscription_two_real_cases(self):
        a=q('Inscrição Reflexo das Profundezas');b=q('Inscrição Terra Fértil')
        self.assertEqual(a['identity']['family'],'INSCRICAO_ENCANTAMENTO')
        self.assertEqual(a['identity']['rank'],'Prata')
        self.assertTrue(a['historical_recipe']['embedded_in_page'])
        self.assertEqual(len(b['historical_recipe']['linked_recipe_pages']),1)
        self.assertIn('INS_PADRAO_INSTALADO',a['pending'])
        self.assertIn('INS_PADRAO_INSTALADO',b['pending'])
    def test_boots_two_costs(self):
        o=q('Bota Caminho Veloz');self.assertEqual(o['identity']['family'],'ACESSORIO')
        self.assertEqual([x['value'] for x in o['costs']['daily']],[18]);self.assertEqual([x['value'] for x in o['costs']['activation']],[5])
        self.assertGreaterEqual(sum(e['mode']=='PASSIVO_EXPLICITO' for e in o['effects']),2)
        self.assertEqual(sum(e['mode']=='ATIVO_EXPLICITO' for e in o['effects']),1)
    def test_amulet_both_identical_amounts_distinct_units(self):
        o=q('Amuleto Tempo Eterno');self.assertEqual([x['value'] for x in o['costs']['daily']],[15]);self.assertEqual([x['value'] for x in o['costs']['activation']],[15])
    def test_orb_two_activations_not_daily(self):
        o=q('Orbe da Palavra Guardada');self.assertEqual([x['value'] for x in o['costs']['activation']],[10,5]);self.assertEqual(o['costs']['daily'],[])
    def test_matrix_real_and_no_install(self):
        o=q('Matriz de Cultivo');self.assertEqual(o['identity']['family'],'MATRIZ');self.assertEqual(len(o['historical_recipe']['linked_recipe_pages']),1)
        self.assertIn('MATRIZ_INSTALADA',o['pending']);self.assertTrue(o['production_admissibility']=='HOLD')
    def test_matrix_recipe_conflicts(self):
        o=q('Matriz de Cultivo');self.assertEqual(sum(c['state']=='CONFLITO' for c in o['family_checks']),2)
    def test_spatial_matrix_rank(self):
        o=q('Matriz Espacial dos 10 Milênios');self.assertEqual(o['identity']['rank'],'Lendário')
        self.assertEqual(compatibility(o,'armazenar automaticamente portátil no anel dimensional')['status'],'INCOMPATIVEL_VERIFICADO')
    def test_armor_ambiguous_abbreviations(self):
        o=q('Manto de Abismo');self.assertIn('ARD_SIGLA_NAO_NORMALIZADA',o['pending']);self.assertEqual(o['costs']['daily'],[])
    def test_armor_protection_not_universal(self):
        o=q('Manto de Abismo');self.assertEqual(compatibility(o,'rd universal')['status'],'INDETERMINADO')
    def test_weapon_untyped_35pa_not_invent_activation(self):
        o=q('Adaga da Serpente Enfeitiçada');self.assertFalse(o['costs']['daily']);self.assertFalse(o['costs']['activation']);self.assertEqual([x['value'] for x in o['costs']['ambiguous']],[35]);self.assertTrue(any(x['role']=='DANO_DADOS' for x in o['effects']))
    def test_known_passive_unknown_pa_not_zero(self):
        o=q('Vestes de Lydandra');self.assertEqual(o['costs']['daily_state'],'PENDENTE');self.assertEqual(o['costs']['activation_state'],'PENDENTE')
    def test_change_detection(self):
        a=LOOK['Bota Caminho Veloz'];b=copy.deepcopy(a);b['content']+='\nNota adicional'
        self.assertEqual(compare_readbacks(a,b)['status'],'MUDANCA_DE_CONTEUDO_NAO_RECONCILIADA')
        self.assertNotEqual(digest(a['content']),digest(b['content']))
        self.assertEqual(compare_readbacks(a,a)['status'],'SEM_ALTERACAO')
    def test_duplicate_titles_different_uuid(self):
        a=LOOK['Bota Caminho Veloz'];b=copy.deepcopy(a);b['uuid']='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
        self.assertEqual(compare_readbacks(a,b)['status'],'ITENS_DIFERENTES')
    def test_uuid_url_conflict(self):
        b=copy.deepcopy(LOOK['Bota Caminho Veloz']);b['uuid']='bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
        self.assertEqual(inspect_source(b)['status'],'IDENTIDADE_DIVERGENTE')
    def test_reject_legacy_party_scope(self):
        b=copy.deepcopy(LOOK['Bota Caminho Veloz']);b['source_surface']='PARTY_ESPELHO'
        self.assertEqual(inspect_source(b)['status'],'FONTE_FORA_ESCOPO_MESTRE')
    def test_reject_unverified_tool(self):
        b=copy.deepcopy(LOOK['Bota Caminho Veloz']);b['source_tool']='MANUAL'
        self.assertEqual(inspect_source(b)['status'],'PROVENIENCIA_NAO_AUTORIZADA')
    def test_reject_blank(self):
        b=copy.deepcopy(LOOK['Bota Caminho Veloz']);b['content']=''
        self.assertEqual(inspect_source(b)['status'],'FONTE_SEM_CONTEUDO')
    def test_reject_missing(self):
        b=copy.deepcopy(LOOK['Bota Caminho Veloz']);b.pop('observed_at')
        self.assertEqual(inspect_source(b)['status'],'ENVELOPE_INCOMPLETO')
    def test_reject_mutated_declared_digest(self):
        b=copy.deepcopy(LOOK['Bota Caminho Veloz']);b['declared_content_sha256']=digest(b['content']);b['content']+='hack'
        self.assertEqual(inspect_source(b)['status'],'EXCERTO_ALTERADO_APOS_EXPORTACAO')
    def test_rank_conflict(self):
        b=copy.deepcopy(LOOK['Amuleto Tempo Eterno']);b['index_rank']='Ouro'
        o=inspect_source(b);self.assertIn('RANK_CONFLITO_INDICE_FICHA',o['pending'])
    def test_energy_mock_not_official(self):
        self.assertEqual(validate_external_pa({'kind':'FIXTURE_SIMULADA','PA_por_dia':9})['status'],'SIMULACAO_NAO_OFICIAL')
        self.assertEqual(validate_external_pa({'kind':'OFICIAL','PA_por_dia':9})['status'],'INTERFACE_EXTERNA_NAO_CONTRATADA')
    def test_no_new_recipes(self):
        self.assertTrue(all(q(s['title'])['no_new_recipe'] for s in SOURCE))
        self.assertTrue(all(q(s['title'])['recipe_creation']=='PROIBIDA' for s in SOURCE))
    def test_compatibility_prohibition(self):
        self.assertEqual(compatibility(q('Bota Caminho Veloz'),'fabricar nova receita')['status'],'INCOMPATIVEL_VERIFICADO')
    def test_compatibility_uncertain(self):
        self.assertEqual(compatibility(q('Orbe da Palavra Guardada'),'instalar inscrição no suporte',q('Matriz de Cultivo'))['status'],'POTENCIALMENTE_COMPATIVEL')
    def test_text_mobile(self):
        t=consult(q('Bota Caminho Veloz'));self.assertIn('18 PA/dia',t);self.assertIn('5 PA/uso',t);self.assertIn('BLOQUEADOS',t)

if __name__=='__main__':unittest.main()
