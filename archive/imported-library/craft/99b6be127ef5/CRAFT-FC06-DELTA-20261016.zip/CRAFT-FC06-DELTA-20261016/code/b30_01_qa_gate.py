"""FC06: independent R42/R52 dimensional acceptance oracle, not a CRAFT engine.
All numeric cases are expressly synthetic engineering fixtures, not in-game material observations.
No Notion/stock mutations. Standard library only.
"""
from decimal import Decimal, InvalidOperation
from typing import Any

D = lambda x: Decimal(str(x))
SPEC = {
    "raw_min_mm": {"length": D(130), "width": D(90), "thickness": D(9)},
    "finished_intervals_mm": {
        "length": (D(119), D(121)), "width": (D(79), D(81)),
        "thickness": (D('7.5'), D('8.5')),
        "grid_pitch": (D(9), D(11)), "flatness": (D(0), D(1)),
        "groove_depth": (D(0), D('0.5')),
    },
}

class InvalidFixture(ValueError):
    pass


def val(v, label):
    if isinstance(v, bool):
        raise InvalidFixture(f"{label}: boolean no lugar de medida")
    try:
        x = D(v)
    except (InvalidOperation, ValueError, TypeError):
        raise InvalidFixture(f"{label}: medida invalida")
    if not x.is_finite() or x < 0:
        raise InvalidFixture(f"{label}: deve ser finita e nao negativa")
    return x


def interval(m, name):
    if not isinstance(m, dict) or set(m) != {"value", "uncertainty_mm"}:
        raise InvalidFixture(f"{name}: medida precisa de value e uncertainty_mm")
    v = val(m["value"], name + ".value")
    u = val(m["uncertainty_mm"], name + ".u")
    return v - u, v + u


def inside(interval_v, bounds):
    lo, hi = interval_v
    low, high = bounds
    if lo >= low and hi <= high:
        return "PASS"
    if hi < low or lo > high:
        return "FAIL"
    return "INDETERMINATE"


def gate(case: dict[str, Any]):
    if case.get("evidence_type") != "TEST_SYNTHETIC":
        raise InvalidFixture("somente fixture sintética, sem classificar como medição canônica")
    if case.get("unit") != "mm":
        raise InvalidFixture("unidade precisa ser mm; nenhuma conversao implicita")
    raw, out = case["raw"], case["finished"]
    checks = {}
    raw_intervals = {}
    for k, minimum in SPEC["raw_min_mm"].items():
        raw_intervals[k] = interval(raw.get(k), "raw."+k)
        lo,hi = raw_intervals[k]
        checks["raw_min_"+k] = "PASS" if lo >= minimum else ("FAIL" if hi < minimum else "INDETERMINATE")
    for defect in ["crack", "delamination"]:
        state = raw.get(defect)
        checks["raw_"+defect] = "PASS" if state is False else "FAIL" if state is True else "INDETERMINATE"
    out_intervals = {}
    for k,bounds in SPEC["finished_intervals_mm"].items():
        out_intervals[k] = interval(out.get(k), "finished."+k)
        checks["finished_"+k] = inside(out_intervals[k], bounds)
    # PROPOSED FC06 grid-placement acceptance overlay (not an existing canonical tolerance):
    # start 10mm from an edge, end 10mm before the opposite edge. Check both
    # adjacent pitch AND absolute line position to detect cumulative pitch drift.
    grid_positions=out.get("grid_positions_mm")
    if grid_positions is None:
        checks["absolute_grid_positions"] = "INDETERMINATE"
    elif not isinstance(grid_positions,dict) or set(grid_positions)!={"x","y"}:
        raise InvalidFixture("grid_positions_mm deve ter x e y")
    else:
        for axis,n,finish_axis in [("x",11,"length"),("y",7,"width")]:
            positions=grid_positions[axis]
            if not isinstance(positions,list) or len(positions)!=n:
                raise InvalidFixture(f"{axis}: quantidade de linhas deveria ser {n}")
            converted=[interval(m,f"grid_{axis}_position_{i}") for i,m in enumerate(positions)]
            for i,reading in enumerate(converted):
                target=D(10)*(i+1)
                checks[f"absolute_grid_{axis}_{i}"]=inside(reading,(target-D(1),target+D(1)))
                # the entire uncertainty interval must remain on the cut finished face
                finish_min,finish_max=out_intervals[finish_axis]
                checks[f"grid_inside_face_{axis}_{i}"]=(
                    "PASS" if reading[0]>=0 and reading[1]<=finish_min else
                    "FAIL" if reading[1]<0 or reading[0]>finish_max else "INDETERMINATE")
            for i,(r1,r2) in enumerate(zip(converted,converted[1:])):
                # interval arithmetic: every possible separation must be in [9,11]mm
                separation=(r2[0]-r1[1], r2[1]-r1[0])
                checks[f"adjacent_grid_{axis}_{i}"]=inside(separation,(D(9),D(11)))
    for defect in ["crack", "delamination", "sharp_edges"]:
        state=out.get(defect)
        checks["finished_"+defect] = "PASS" if state is False else "FAIL" if state is True else "INDETERMINATE"
    checks["grid_orthogonality_observed"] = ("PASS" if out.get("grid_orthogonal") is True else
                                               "FAIL" if out.get("grid_orthogonal") is False else "INDETERMINATE")
    checks["functional_marking_observed"] = ("PASS" if out.get("three_marks_without_breakage") is True else
                                              "FAIL" if out.get("three_marks_without_breakage") is False else "INDETERMINATE")
    for k in SPEC["raw_min_mm"]:
        raw_lo,raw_hi = raw_intervals[k]
        finish_lo,finish_hi=out_intervals[k]
        # With overlapping uncertainty intervals, there is no proof that output fitted inside input.
        checks["no_growth_"+k] = ("PASS" if finish_hi<=raw_lo else
                                   "FAIL" if finish_lo>raw_hi else "INDETERMINATE")

    # Optional chain; bounding-prism volumes, not actual density/mass measurements.
    stage_volumes=[]
    stage_dimensions=[]
    if "stages" in case:
        stages=case["stages"]
        if not isinstance(stages,list) or len(stages)<2 or stages[0].get("stage")!="raw" or stages[-1].get("stage")!="finished":
            raise InvalidFixture("cadeia de etapas deve comecar em raw e terminar em finished")
        for stage in stages:
            dims=stage.get("dims_mm",{})
            if set(dims)!={"length","width","thickness"}:
                raise InvalidFixture("etapa com dimensoes malformadas")
            dimension={k:val(v,f"{stage.get('stage')}.{k}") for k,v in dims.items()}
            if any(x==0 for x in dimension.values()):
                raise InvalidFixture("etapa com dimensao nula")
            stage_dimensions.append({"stage":stage["stage"],"dims":dimension})
            stage_volumes.append({"stage":stage["stage"],"volume_mm3":dimension["length"]*dimension["width"]*dimension["thickness"]})
        for a,b in zip(stage_volumes,stage_volumes[1:]):
            checks[f"step_nonincrease_{a['stage']}_to_{b['stage']}"] = "PASS" if a["volume_mm3"]>=b["volume_mm3"] else "FAIL"
        for a,b in zip(stage_dimensions,stage_dimensions[1:]):
            for dimension_name in ("length", "width", "thickness"):
                checks[f"shape_nonincrease_{a['stage']}_to_{b['stage']}_{dimension_name}"] = (
                    "PASS" if a["dims"][dimension_name]>=b["dims"][dimension_name] else "FAIL"
                )
        # A bounding box is not an exact physical material balance; explicitly report model only.
    if "FAIL" in checks.values():result="FAIL"
    elif "INDETERMINATE" in checks.values():result="INDETERMINATE"
    else:result="PASS_TEST_ONLY"
    raw_design=D(130)*D(90)*D(9)
    final_design=D(120)*D(80)*D(8)
    return {
       "id":case["id"],"status":result,"checks":checks,"failed":[k for k,v in checks.items() if v=="FAIL"],
       "indeterminate":[k for k,v in checks.items() if v=="INDETERMINATE"],
       "ideal_design_only": {"raw_bounding_prism_mm3":str(raw_design),"final_bounding_prism_mm3":str(final_design),
          "bounding_prism_difference_mm3":str(raw_design-final_design),
          "geometric_ratio_percent":str((final_design/raw_design*100).quantize(D('0.0001'))),
          "not_success_probability":True,"not_physical_measured_mass_loss":True},
       "volume_chain_bounding_prisms_mm3":[{"stage":s["stage"],"volume":str(s["volume_mm3"])} for s in stage_volumes],
       "material_performance_measured":False,
       "official_qa":False,
    }


def draft_fixture(fixture_id, material_name="PS ardósia",grid=True):
    mk = lambda v,u="0.1":{"value":str(v),"uncertainty_mm":str(u)}
    grid_coords={"x":[mk(i*10,"0.1") for i in range(1,12)],"y":[mk(i*10,"0.1") for i in range(1,8)]} if grid else None
    return {"id":fixture_id,"unit":"mm","evidence_type":"TEST_SYNTHETIC","material_label":material_name,
         "raw":{"length":mk(130.2),"width":mk(90.2),"thickness":mk(9.2),"crack":False,"delamination":False},
         "finished":{"length":mk(120),"width":mk(80),"thickness":mk(8),"grid_pitch":mk(10),
              "flatness":mk('0.5'),"groove_depth":mk('0.2'),"crack":False,"delamination":False,"sharp_edges":False,
              "grid_orthogonal":True if grid else None,"three_marks_without_breakage":True if grid else None,
              "grid_positions_mm":grid_coords}}
