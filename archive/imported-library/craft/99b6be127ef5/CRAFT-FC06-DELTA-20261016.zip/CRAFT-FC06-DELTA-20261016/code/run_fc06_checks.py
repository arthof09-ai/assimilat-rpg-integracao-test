"""Small, isolated FC06 acceptance tests of B30-01 only; does not import historical motors."""
import copy,json,pathlib,sys
from b30_01_qa_gate import gate, draft_fixture, InvalidFixture

BASE=pathlib.Path(__file__).resolve().parent.parent
cases=[]
def run_case(label, changer, expected):
    f=draft_fixture(label)
    changer(f)
    try:
        obj=gate(f)
        got=obj["status"]
    except InvalidFixture as e:
        got="INVALID_FIXTURE"
        obj={"id":label,"status":got,"error":str(e)}
    cases.append({"id":label,"expected":expected,"actual":got,"ok":got==expected,"detail":obj})

run_case("01_nominal_synthetic",lambda x:None,"PASS_TEST_ONLY")
run_case("02_missing_raw_dimension",lambda x: x['raw'].pop('width'),"INVALID_FIXTURE")
run_case("03_insufficient_raw_thickness",lambda x: x['raw'].update(thickness={'value':'8.7','uncertainty_mm':'0.1'}),"FAIL")
run_case("04_inconclusive_raw_thickness",lambda x:x['raw'].update(thickness={'value':'9.05','uncertainty_mm':'0.1'}),"INDETERMINATE")
run_case("05_output_longer_than_input",lambda x:x['finished'].update(length={'value':'131','uncertainty_mm':'0.1'}),"FAIL")
run_case("06_finished_width_outside_limit",lambda x:x['finished'].update(width={'value':'82','uncertainty_mm':'0.1'}),"FAIL")
run_case("07_finish_borderline_uncertainty",lambda x:x['finished'].update(length={'value':'120.9','uncertainty_mm':'0.3'}),"INDETERMINATE")
run_case("08_flatness_unknown",lambda x:x['finished'].update(flatness={'value':'0.95','uncertainty_mm':'0.1'}),"INDETERMINATE")
run_case("09_cracked_finished",lambda x:x['finished'].update(crack=True),"FAIL")
run_case("10_raw_cracked",lambda x:x['raw'].update(crack=True),"FAIL")
run_case("11_grid_unmarked_common_slab",lambda x:x['finished'].update(grid_orthogonal=None,three_marks_without_breakage=None),"INDETERMINATE")
run_case("12_unknown_unit",lambda x:x.update(unit='cm'),"INVALID_FIXTURE")
run_case("13_negative_uncertainty",lambda x:x['raw'].update(length={'value':'130.2','uncertainty_mm':'-1'}),"INVALID_FIXTURE")
run_case("14_missing_QA_for_crack",lambda x:x['finished'].pop('crack'),"INDETERMINATE")
run_case("15_groove_overdeep",lambda x:x['finished'].update(groove_depth={'value':'0.7','uncertainty_mm':'0.1'}),"FAIL")
run_case("16_nonorthogonal_grid",lambda x:x['finished'].update(grid_orthogonal=False),"FAIL")
run_case("17_no_3mark_function",lambda x:x['finished'].update(three_marks_without_breakage=False),"FAIL")
run_case("18_common_slab_same_geometry",lambda x:x.update(material_label='ordinary slab synthetic control'),"PASS_TEST_ONLY")
run_case("19_unauthorized_evidence_claim",lambda x:x.update(evidence_type='REAL_CRAFT'),"INVALID_FIXTURE")
run_case("20_nonfinite_input",lambda x:x['raw'].update(length={'value':'NaN','uncertainty_mm':'0.1'}),"INVALID_FIXTURE")
chain=[
    {'stage':'raw','dims_mm':{'length':130,'width':90,'thickness':9}},
    {'stage':'clivage','dims_mm':{'length':122,'width':82,'thickness':9}},
    {'stage':'flatten','dims_mm':{'length':122,'width':82,'thickness':8.2}},
    {'stage':'finished','dims_mm':{'length':120,'width':80,'thickness':8}},
]
run_case('21_monotonic_prism_chain',lambda x:x.update(stages=chain), 'PASS_TEST_ONLY')
changed=copy.deepcopy(chain);changed[2]['dims_mm']['length']=130
run_case('22_nonmonotonic_prism_chain',lambda x:x.update(stages=changed), 'FAIL')
run_case('23_accumulated_pitch_drift',lambda x:x['finished'].update(grid_positions_mm={
   'x':[{'value':str(i*10+(i-1)*0.5),'uncertainty_mm':'0.1'} for i in range(1,12)],
   'y':x['finished']['grid_positions_mm']['y']}), 'FAIL')
run_case('24_grid_position_missing',lambda x:x['finished'].pop('grid_positions_mm'),'INDETERMINATE')

if not all(x['ok'] for x in cases):
 print(json.dumps([x for x in cases if not x['ok']],indent=2,ensure_ascii=False));sys.exit(1)
comp={
  'comparator_class':'TEST_SYNTHETIC',
  'official_common_board_id':None,
  'materials':['PS lamellar slate fixture','ordinary stone slab fixture'],
  'matched_conditions':{'raw_dimensions':'same','finished_dimensions':'same','pitch':'same','uncertainty':'same',
                         'durability_real':'UNMEASURED','abrasive_compatibility':'UNMEASURED'},
  'same_geometry_pass':cases[0]['actual']==cases[17]['actual']=='PASS_TEST_ONLY',
  'evidence_conclusion':'INVARIANT under substrate label in geometric oracle: NO PS slate advantage demonstrated',
  'grid_versus_unmarked':'unmarked control has insufficient evidence, not proof that it can never be marked',
  'material_comparison_conclusion':'INCONCLUSIVE; material-specific independent REC-ID not justified merely by name',
}
p=BASE/'outputs'/'dimensional_qa_tests.json'
p.parent.mkdir(exist_ok=True)
p.write_text(json.dumps({'schema':'FC06-LOCAL-QA-v1','cases':cases,'passed':sum(x['ok'] for x in cases),'denominator':len(cases),'comparison':comp,'only_synthetic':True},indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print('FC06 PASS',len(cases),'/',len(cases),'comparison_equal',comp['same_geometry_pass'])
