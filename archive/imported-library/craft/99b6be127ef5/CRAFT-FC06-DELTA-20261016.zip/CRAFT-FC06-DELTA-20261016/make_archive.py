"""Additive FC06 packaging; archives historical baselines are NOT copied or modified."""
import hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
ZIP=ROOT.parent/'CRAFT-FC06-DELTA-20261016.zip'
manifest={'schema':'FC06-SHA256-v1','as_of':'2026-10-16','experimental_only':True,'baseline_unchanged':True,'files':{}}
for path in sorted(ROOT.rglob('*')):
 if not path.is_file() or path.name in {'MANIFEST_SHA256.json','make_archive.py'}:continue
 rel=path.relative_to(ROOT).as_posix()
 dat=path.read_bytes()
 manifest['files'][rel]={'bytes':len(dat),'sha256':hashlib.sha256(dat).hexdigest()}
manifest['files']['make_archive.py']={'bytes':(ROOT/'make_archive.py').stat().st_size,'sha256':hashlib.sha256((ROOT/'make_archive.py').read_bytes()).hexdigest()}
(ROOT/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in sorted(ROOT.rglob('*')):
  if path.is_file():z.write(path,arcname='CRAFT-FC06-DELTA-20261016/'+path.relative_to(ROOT).as_posix())
print('CREATED',ZIP,'files',len(manifest['files']))
