"""FC06 independent ZIP manifest auditor and clean-room local QA replay. No external deps."""
import hashlib, json, pathlib, shutil, subprocess, sys, tempfile, zipfile

def verify(path):
 path=pathlib.Path(path)
 with zipfile.ZipFile(path) as z:
  bad=z.testzip()
  assert bad is None, f'CRC problem {bad}'
  roots={n.split('/')[0] for n in z.namelist() if '/' in n}
  assert roots=={'CRAFT-FC06-DELTA-20261016'}, roots
  prefix='CRAFT-FC06-DELTA-20261016/'
  manifest=json.loads(z.read(prefix+'MANIFEST_SHA256.json'))
  listed=manifest['files']
  actual={n[len(prefix):] for n in z.namelist() if n.startswith(prefix) and not n.endswith('/') and n!=prefix+'MANIFEST_SHA256.json'}
  assert set(listed)==actual, ('missing_or_extra',set(listed)^actual)
  for n,m in listed.items():
   b=z.read(prefix+n)
   assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256'],n
  gate=json.loads(z.read(prefix+'outputs/dimensional_qa_tests.json'))
  assert gate['denominator']==24 and gate['passed']==24 and all(x['ok'] for x in gate['cases'])
  assert gate['comparison']['same_geometry_pass'] and gate['only_synthetic'] is True
  # independent basic cross-check from the fields, not the CRAFT engine's status flag:
  nominal=next(x for x in gate['cases'] if x['id']=='01_nominal_synthetic')
  assert nominal['detail']['ideal_design_only']['raw_bounding_prism_mm3']=='105300'
  assert nominal['detail']['ideal_design_only']['final_bounding_prism_mm3']=='76800'
  assert float(nominal['detail']['ideal_design_only']['geometric_ratio_percent']) >72.93
  # CLEAN replay without importing engine or modifying historical source stores.
  with tempfile.TemporaryDirectory(prefix='fc06_clean_readback_') as d:
   z.extractall(d)
   runner=pathlib.Path(d)/prefix/'code/run_fc06_checks.py'
   c=subprocess.run([sys.executable,str(runner)],capture_output=True,text=True,timeout=20)
   assert c.returncode==0,(c.stdout,c.stderr)
   output=json.loads((runner.parent.parent/'outputs/dimensional_qa_tests.json').read_text())
   assert [(x['id'],x['actual']) for x in output['cases']]==[(x['id'],x['actual']) for x in gate['cases']]
  return {'ok':True,'manifest_files':len(listed),'replayed_tests':24,'baseline_not_mutated':True,
   'sha256_zip':hashlib.sha256(path.read_bytes()).hexdigest()}

if __name__=='__main__':
 print(json.dumps(verify(sys.argv[1]),indent=2))
