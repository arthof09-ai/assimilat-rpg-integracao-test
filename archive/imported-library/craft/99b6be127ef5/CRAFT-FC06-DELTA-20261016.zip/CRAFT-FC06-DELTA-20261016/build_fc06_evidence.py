"""Build supplemental FC06 evidence only. Historical zip stores and campaign are read-only."""
import json,hashlib,pathlib,zipfile,datetime
P=pathlib.Path(__file__).resolve().parent
OUT=P/'outputs';OUT.mkdir(exist_ok=True)
def write(name, data):
 (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')

zip_paths={
 'CRAFT_v03':'/mnt/data/craft_recovery/CRAFT-COMESTRE-CHAT-v03.zip',
 'FC03':'/mnt/data/CRAFT-FAST-CLOSE-03-DELTA-20261016.zip',
 'FC04':'/mnt/data/CRAFT-R48-B30-22-FC04-DELTA-20261016.zip',
 'FC05':'/mnt/data/CRAFT-FC05-DELTA-20261016.zip',
}
provenance={'as_of':'2026-10-16','schema':'FC06-RECOVERY-v1','restored_packages':{},
 'fc05_last_verified_unit_from_previous_audit':{'store':'ACCEPTED_V2/R48_SHARED_TRIPLE_STORE','seq':2,'head':'cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708',
    'status':'RECUPERADO/RELATADO_FROM_PRIOR_FC04_FC05; not new transaction'},
 'NO_REPEAT':['historical R44–R48','FC03–FC05 fixtures and stores','R48 draft SBX-R48-BATCH-UI-2afb696406a6e839','FC04 orphan checkpoint','FC04 angular first attempt']}
for tag,filename in zip_paths.items():
 file=pathlib.Path(filename)
 with zipfile.ZipFile(file) as z:
  assert z.testzip() is None
  entry={'path':str(file),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'zip_entries':len(z.namelist()),'zip_crc_ok':True}
  if tag in ('CRAFT_v03','FC04','FC05'):
   mn = next(x for x in z.namelist() if x.count('/')==1 and x.endswith(('MANIFEST-V03.json','MANIFEST_SHA256.json')))
   m=json.loads(z.read(mn))['files']
   root=mn.split('/')[0]
   fails=[]
   for path,detail in m.items():
    member=root+'/'+path
    if not member in z.namelist():fails.append(path+':missing');continue
    data=z.read(member)
    if hashlib.sha256(data).hexdigest()!=detail['sha256'] or len(data)!=detail['bytes']:fails.append(path+':mismatch')
   assert not fails, (tag,fails[:3])
   entry['manifest_file_count']=len(m)
   entry['manifest_hashes_reverified']=len(m)
  provenance['restored_packages'][tag]=entry
write('recovery_integrity.json',provenance)

refsrc={
 'PS_Ardosia':{'url':'https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2','crn_id':'CRAFT-F5-R01-MIN-01','name':'Ardósia de Geada Lamelar','type':'PS preexisting; only identity, region R01 and lamellar engraving-substrate context previously read','new_notion_readback':'DENIED_this_session'},
 'AUD_R42':{'url':'https://app.notion.com/p/3f3c2b324ede81c99367e2de46077cbb','name':'AUD-CRAFT-F5-REMAP-01','type':'historical design, R42 metrology and PRE-Q2; recovered from authorized local dossiers','new_notion_readback':'DENIED_this_session'},
 'PR_ITEM_REC_EXEC':{'url':'https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4','type':'Previously consulted official norm; this turn uses preserved extracts'},
 'PR_ECO':{'url':'https://app.notion.com/p/3eec2b324ede8102b3f3e6c8851ad1e7','type':'Previously consulted official economics Anexo C'},
 'REC_LIB':{'url':'https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702','type':'Previously consulted single physical page requirement'},
 'B30_21_comparator':{'url':'https://app.notion.com/p/3f3c2b324ede814ab353cf6008946d2c','type':'PS mammoth fang resource; separately proposed ruler B30-21; no manufactured real ruler confirmed'},
 'B30_05_comparator':{'url':'https://app.notion.com/p/3f3c2b324ede81319786eba0f666cef1','type':'PS gneiss resource, not proven substitute ready-made 2D grid tool'},
}
write('sources_and_evidence.json',{
 'schema':'FC06-SOURCES-v1','as_of':'2026-10-16','notion_tool_error':'link_id must identify an eligible linked account',
 'new_notion_fetched_pages':0,'sources_from_previously_verified_local_material':refsrc,
 'local_document_paths':['BACKFILL30-CRAFT-20261014/B30-01-DOSSIE-CONSOLIDADO.md',
 'BACKFILL30-CRAFT-20261014/ESPECIFICACOES-B30-01-a-B30-30.md',
 'CRAFT-R52-SANDBOX-I0016/docs/R52_B30-01_MINIMO_EMPIRICO.md (nested historic ZIP)'],
 'source_identity_verified_in_prior_sessions_only':True,
 'source_properties_not_proven':['physical occurrence/current stock','density','fracture strength','friction/durability','raw plate sizes in the world','craft knowledge in population','actual supply or trade']})

write('b30_01_contract_and_lineage.json',{
 'schema':'FC06-B30-01-CONTRACT-v1','design_id':'B30-01','official_rec_id':None,
 'single_product':{'canonical_design_label':'Tábua Lamelar de Inscrição — Gabarito Mecânico de Oficina',
  'historic_alias':'Tábua Lamelar de Ardósia','alias_is_same_product':True,
  'purpose':'Reusable physical support for orthogonal 2D 10mm marking and inspection, NOT an active inscription',
  'gameplay_effect':'No verified modifiers, elemental cold, PA, damage, magic, insulation, or rank bonus',
  'actual_product_created':False,'desired_mechanism':'Surface flatness and visible grid','rank':'No magical power justified; classification not auto-imported from PS resource',
  'conditions':'bench stable, dry/safe work handling, no assumption of stocked tools or material'},
 'bom':[
  {'ref':'M01','role':'substrate','qty_proposed':1,'unit':'qualified slate lamella','min_dims_mm':[130,90,9],'source':'PS_Ardosia','quantity_verified_as_stock':False},
  {'ref':'T01','role':'reusable cutting/splitting tool and rigid support','consumed':'NO, unless wear/depreciation','source':'generic technical fixture, NOT real inventory','availability':'PENDING'},
  {'ref':'T02','role':'ruler, square, caliper, independent straightedge','consumed':'NO, depreciation','calibration':'PENDING'},
  {'ref':'T03','role':'reusable compatible abrasive bench stone','consumed':'WEAR unknown; CE cost, alternative consumable a_g would require BOM revision','identity':'not verified in this workspace'},
  {'ref':'T04','role':'dust control, brush, operator protection','consumed':'disposable usage u unknown; if any, open BOM node','identity':'generic fixture, availability not proven'},
 ],
 'operation_map':[
  {'step':1,'in':['M01','T02','T04'],'result':'screen crack/dimensions','project_minutes':5,'reject':'unqualified raw plate'},
  {'step':2,'in':['M01','T01','T02'],'result':'clive and trim; shavings','project_minutes':10,'reject':'critical fissure'},
  {'step':3,'in':['M01','T02','T03'],'result':'plane and thickness adjust','project_minutes':15,'reject':'delamination or insufficient material'},
  {'step':4,'in':['M01','T01','T02'],'result':'trace 10mm grid, groove <=0.5mm','project_minutes':10,'reject':'nonorthogonality'},
  {'step':5,'in':['M01','T03','T04'],'result':'bevel, dust capture','project_minutes':10,'reject':'sharp edge'},
  {'step':6,'in':['T02'],'result':'independent dimensional QA','project_minutes':5,'reject':'tolerance / insufficient evidence'},
 ],
 'claimed_time':'55min ACTIVE DESIGN, not observed/confirmed',
 'lab_safety':'protect from cut fragments/mineral dust; no claim real equipment available',
 'knowledge':'generic mineral lapidary and 2D measurement PROPOSED; existence of authorized knowledgeable NPC PENDING',
 'intermediates':'single piece during cutting, no magic/intermediate ingredients; dust and trimmed slate residues nonmarketable unless separately qualified',
 'qa':'R42/R52 interval uncertainty rule; unit tests in dimensional_qa_tests.json; not physical lot',
 'reuse_and_variants':'2D ruled tool is a genuine *function* relative to an unmarked slab; no material-specific benefit established versus identically ruled ordinary stone; no proven physical existing recipe base; do not label S2 derivative or create independent physical REC-ID',
 'ps_dependency':'source exists as PS documentation; individual lot/authorization/JIT not presumed',
 'economic_model':'see economic_tree.json',
 'mechanical_not_applicable':['PA','Alma','magical charges','combat activation','energy-element effect'],
 'main_technical_conclusion':'Documented process coherent under synthetic assumptions, but no special merit of PS slate demonstrated; physical suitability and economic/knowledge sources pending'
})

write('material_function_comparison.json',{
 'schema':'FC06-B30-01-COMPARISON-v1',
 'question':'Does PS lamellar slate grant independent function beyond adequately gridded common substrate?',
 'controls':[
  {'name':'PS slate B30-01', 'evidence':'RECOVERED_PS_IDENTITY + TEST_GEOMETRY_ONLY', 'independent_product_recipe':False},
  {'name':'Ordinary stone or common slate slab', 'evidence':'DOCUMENTARY alternative in R42/R52; no recovered page ID or actual available board'},
  {'name':'Equal geometric board in neutral ordinary slab', 'evidence':'TEST_SYNTHETIC, geometry and QA identical to PS slate'},
  {'name':'Mammoth fang ruler B30-21', 'evidence':'DOCUMENTARY comparator; source PS identity exists, ruler is a proposed product, not a verified real replacement'},
 ],
 'preregistered_hypotheses':{
   'H0':'For fixed finished geometry and QA values, source label alone changes no decision in dimensional oracle.',
   'H1':'PS slate has independently supported material advantage in durability, inscription marking, risk, or cost.',
   'reject_H0_threshold':'Different QA decision solely on source under identical geometry (should not happen); this would signal unwanted source bias',
   'accept_H1':'Competent independent material evidence of materially favorable property vs common comparator, same task and measured uncertainty'},
 'synthetic_observations':{'PS_slate_fixture':'PASS_TEST_ONLY','common_slab_fixture':'PASS_TEST_ONLY','unmarked_plate_fixture':'INDETERMINATE due unobserved grid','source_invariance':True},
 'not_measured':['flatness of any slate source','relative durability','real scratchability','wear','mass','water sensitivity','skilled labor efficiency','CTE unit'],
 'conclusion':'No unique advantage of lamellar PS material demonstrated. Adding a grid distinguishes a gridded board from an unmarked one, but a common slab may also receive a grid. MATERIAL DIFFERENTIAL INCONCLUSIVE.',
 'anti_duplicate_decision':'NO NEW REC-ID; preserve B30-01 design as material variant candidate, search/reconcile actual existing base only under valid library read access.',
 'scientific_limit':'Neither infer equivalence of real materials nor declare B30-01 inferior. A fixture equality is not a material test.'
})

write('economic_tree.json',{
 'schema':'FC06-PR-ECO-01-v1','cost_id':'COST-PRE-CRAFT-TLI-20261008-001 (historic, unchanged)',
 'price_observed':None,'MED_observed':None,'market_and_epoch':None,'currency':'MED not assigned',
 'formula':'CTE = CI + CP + CF + CT + CE + CK + CL + CA + CC',
 'components':{
  'CI':'1 qualified PS lamella times unit opportunity cost + actual consumables (only if shown used; no CE double-count)',
  'CP':'incremental process losses/disposal not already within purchase or CI',
  'CF':'failures and rework distinctly tracked, no fictive failure rate',
  'CT':'qualified labor wage_rate * observed active+waiting/rework time (55min is only design input)',
  'CE':'reusable cutting/measurement/abrasion tooling amortization and energy, no fake owned=free',
  'CK':'competent know-how, teaching/license/skill expense if applicable and legitimately documented',
  'CL':'actual procurement route transport, distance and tariffs PENDING',
  'CA':'storage and protecting lamella, if justified',
  'CC':'capital or real alternative use opportunity cost; avoid counting raw material opportunity twice'},
 'units':{'input':'qualified lamella count','output':'QA approved board count','work':'minutes then hours','abrasive':'g only if consumable proven','waste':'mass/volume independently measured, not prism-volume inferred','price':'MED per matching epoch/market only'},
 'q_emp':'N_PASS/N_in only when real observations exist and N_in>0',
 'CTE_unit':'CTE_lot/N_PASS if N_PASS>0; undefined otherwise',
 'scenarios':[
  {'kind':'FAVORABLE','hypothesis':'at least one eligible lamella, QA first attempt, no extra rework','cost':'symbolic, no numerical price'},
  {'kind':'NORMAL','hypothesis':'unknown rework, consumables, operating time and rejection; preserve variables','cost':'symbolic, no guessed rates'},
  {'kind':'ADVERSE','hypothesis':'all tested pieces fail; costs incurred despite zero approved goods','cost_per_approved_piece':None}],
 'provenance_missing':['actual unit value of qualified PS lamella in named market/date','period and rate of labor','tool usage depreciation and consumables','actual sample selection and measured time','real N_in/N_PASS','transport/warehousing and realistic opportunity'],
 'computed_CTE':False,'does_not_imply_RC5':True
})

write('rc5_dryrun_write_set.json',{
 'schema':'FC06-NO-WRITE-PREVIEW-v1','dry_run_only':True,
 'preconditions_false_or_unknown':['B30-01 material-specific differential/recipe identity not demonstrated',
  'full quantified consumables/lot suitability/qualified operator not demonstrated',
  'verified knowledge and economic sufficiency not demonstrated','official existing REC-ID/product lineage not fully queried',
  'F5 RED','C19-021 UNKNOWN_EFFECT','writer fencing/lease/claim not proven','REC-LIB physical parent not validated','NAC-PASS production HOLD'],
 'operations_preview_in_order':[{'op':'REOPEN_AUTHORITATIVE_OP_RUNTIME_INBOX_IBX38_IBX78','effect':'read-only governance preflight'},
  {'op':'RECONCILE_C19_UNKNOWN_EFFECT_AND_EXCLUSIVE_WRITER','effect':'no unsafe retry'},
  {'op':'LOCATE_EXISTING_REC_ID_BY_PRODUCT_VERSION_LINEAGE','effect':'reuse existing if found; no duplicate'},
  {'op':'VALIDATE_B30_01_TECHNICAL_AND_ECONOMIC_RC5','effect':'hold if any source pending'},
  {'op':'RESERVE_SINGLE_APPROVED_PARENT_AND_WRITE_SET','effect':'only with epoch lease GREEN and NAC precheck'},
  {'op':'CREATE_OR_REUSE_SINGLE_RECIPE_PRODUCT_AND_CROSS_LINKS','effect':'conditional only, no current execution'},
  {'op':'REOPEN_AND_VALIDATE_TRIPLE_LINKS_AND_NAC_PASS','effect':'count only after physical readback'}],
 'product_target_id':None,'new_official_rec_id':None,'notion_pages_written':0,'campaign_stock_consumed':0,'party_disclosures':0
})

write('fc06_rc5_gate_and_next.json',{
 'schema':'FC06-RC5-SUCCESSION-v1','as_of':'2026-10-16',
 'baseline':{'resources_ps':30,'pre_q2':23,'pre_q1':7,'official_rc5_ids':0,'resource_coverage_rc5':0,'official_products':0,'fc04_synthetic_test_families':3},
 'new_fc06':{'material_PS_Notion_pages_reopened':0,'synthetic_gate_tests':24,'synthetic_gate_tests_pass':24,'material_comparators_current_confirmed':0,'documentary_comparators_used':2,'synthetic_comparisons':1,'material_properties_measured':0,'rc5_gates_closed':0},
 'candidate_status':{
  'B30-01':{'status':'RC4_DESIGN_PLUS_SYNTHETIC_QA, RC5_HOLD','new_delta':'24 deterministic QA cases; proof material identity does not alter geometry oracle','merit':'no independently established PS slate advantage','highest_priority_missing':'same-purpose existing recipe/comparator ID and accepted QA with competent plate knowledge, source/lot and nonfictive costing'},
  'B30-03':{'status':'RC4_DESIGN_PLUS_PRIOR_R48_TEST, RC5_HOLD','delta':'unchanged; PS mica spacers need specific actual fit use and nonredundancy versus gneiss/common shims'},
  'B30-22':{'status':'RC4_DESIGN_PLUS_PRIOR_R48_TEST, RC5_HOLD','delta':'FC05 limit unchanged; flat-sample case, not universal container'},
  'B30-06':{'status':'PRE_Q2_SOURCE_BLOCK, RC5_HOLD','delta':'no competent identified permeable envelope, no measured adsorption'},
  'B30-17':{'status':'PRE_Q2_DIFFERENTIAL_CANDIDATE','delta':'potential next functional candidate from existing portfolio; process-controlled grit fraction vs coarse aggregate must be reconciled with prior abrasive recipe and QA'}
 },
 'comparative_next_priority':'B30-17 conditional technical priority if B30-03 cannot name a specific necessary assembly. No new REC-ID before source and lineage proof.',
 'writer':'NOT_GRANTED','f5':'RED','C19_021':'UNKNOWN_EFFECT','IBX_38':'FENCING_PENDING','IBX_78':'LIBRARY_PARENT_PENDING','notion_connection':'connector error link_id must identify an eligible linked account',
 'unknown_effect':['C19-021 never retried','FC04 deliberate orphan persisted and blocked, untouched'],
 'conflicts':['R42 project QA looks complete but dimension fixture is not material validation',
  'B30-01 material-specific recipe has no differentiator compared with generic marked slab, given present proof'],
 'last_verified_unit':'FC06 code/run_fc06_checks.py; outputs/dimensional_qa_tests.json with 24/24 synthetic outcomes; historical head cfaa39bad734106c254a140ebeec67ceee6713ed1475312ebde07cf0f0930708 preserved',
 'first_pending':'documented same-purpose common gabarito/recipe identity + proof of suitable PS slate layer/available craft technique for independent merits',
 'no_repeat':['R44-R48 full regression','FC04 synthetic batch replay','B30-22 geometric gate','BACKFILL30 30-source scan'],
 'next_5':['Reestablish legitimate Notion read access to locate existing generic marked-board recipe and confirm PS slate source/destination',
  'If no documented independent board advantage, change B30-01 to material variant without new REC-ID and continue to B30-03 fit-case',
  'Test B30-03 necessary shim specification in one concrete existing mechanism before considering distinct recipe',
  'If B30-03 has no documented use, prioritize B30-17 screened abrasive differential vs B30-04 coarse with same standards',
  'Do not attempt productive commit until fencing C19 reconciled, writer assigned, REC-LIB parent verified and NAC-PASS fulfilled'],
 'nac_pass_scope':{'local_integrity_and_synthetic_QA':'PASS','material_eligibility':'HOLD','canonization_and_productive_write':'HOLD'},
})
print('created evidence',len(list(OUT.glob('*.json'))))
