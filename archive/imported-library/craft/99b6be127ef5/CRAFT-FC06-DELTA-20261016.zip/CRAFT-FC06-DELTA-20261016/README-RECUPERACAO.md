# FC06 — CRAFT / OP-ARQ-RIN-REC-01 / CM-000002-WS0001

**PERÍMETRO**: MESTRE-SIDE, **somente** QA/dossiê sandbox e DRY-RUN. Nenhuma escrita produtiva ou estoque real. Não há novo motor. Preservados v03, FC03, FC04, FC05, R48 e todo histórico.

## Reproduzir

Com Python 3.10+ (somente biblioteca padrão):

1. Extrair `CRAFT-FC06-DELTA-20261016.zip` em pasta vazia.
2. `python CRAFT-FC06-DELTA-20261016/code/run_fc06_checks.py` — 24 testes sintéticos com aceites, recusas e indeterminados. Regrava APENAS um JSON local na pasta extraída. Não importa motor CRAFT, não usa rede nem escreve no Notion.
3. `python CRAFT-FC06-DELTA-20261016/verify_fc06.py CRAFT-FC06-DELTA-20261016.zip` — valida 100% de hashes SHA-256 do manifesto, integridade ZIP, resultados gravados; reexecuta 24 testes em uma extração nova e isolada. Pode ser chamado de qualquer diretório.

## Onde estão as provas

- `outputs/recovery_integrity.json`: SHA-256 dos arquivos originais v03, FC03, FC04, FC05 conferidos no runtime da FC06, sem executá-los.
- `outputs/dimensional_qa_tests.json`: 24 fixtures e vereditos; nenhum valor é medição de ardósia do RPG.
- `outputs/material_function_comparison.json`: comparação controlada com placa comum SINTÉTICA, conclusão de diferencial ainda não demonstrado.
- `outputs/b30_01_contract_and_lineage.json`: uma identidade de produto, BOM/processo e delimitação das fontes e ferramentas.
- `outputs/economic_tree.json`: nove nós da fórmula PR-ECO e três cenários sem preços fictícios.
- `outputs/rc5_dryrun_write_set.json`: atos condicionais descritos, **nenhuma transação autorizada ou executada**.
- `outputs/fc06_rc5_gate_and_next.json`: gates, denominadores, 1ª pendência, NEXT-5 e NAC-PASS.
- `outputs/sources_and_evidence.json`: URLs preexistentes e falha de acesso Notion da instância. Fatos retirados de recortes locais são **RECUPERADOS**; não são prova de uma reabertura no Notion nesta rodada.

## Ponto de retomada

`outputs/fc06_rc5_gate_and_next.json` → investigar **a identidade funcional/linhagem de um gabarito comum**, sem reabrir as 30 fontes. Caso falte mérito específico à ardósia PS, tratar B30-01 como variante de material sob a fonte-base se verificada; próximo ensaio de mérito B30-03, ou B30-17 se B30-03 continuar sem uma montagem legitimamente necessária.

**Não tentar**: confirmar o draft `SBX-R48-BATCH-UI-2afb696406a6e839`; editar o órfão FC04; criar REC-ID/estoque; repetir R48; emitir GREEN; escrever em Party / O Primeiro.
