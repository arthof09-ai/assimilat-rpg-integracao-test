"""Verificador R49: reproduz relatórios e testes a partir de ZIP imutável (sem rede)."""
import sys,pathlib,hashlib,json,tempfile,shutil,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
MANIFEST=ROOT/'MANIFEST_SHA256.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 a=json.loads(MANIFEST.read_text(encoding='utf-8'))
 for rel,h in a['files'].items():
  p=ROOT/rel
  if not p.is_file() or sha(p)!=h:raise RuntimeError('SHA mismatch '+rel)
 orig={rel:sha(ROOT/rel) for rel in a['outputs']}
 with tempfile.TemporaryDirectory(prefix='r49-replay-') as t:
  dst=pathlib.Path(t)/'R49'; shutil.copytree(ROOT,dst)
  code=subprocess.run([sys.executable,str(dst/'src'/'generate.py')],capture_output=True,text=True,check=True)
  (dst/'outputs'/'GENERATION_STDOUT.json').write_text(code.stdout,encoding='utf-8')
  tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(dst/'tests'),'-q'],capture_output=True,text=True,check=True)
  for rel,h in orig.items():
   if sha(dst/rel)!=h:raise RuntimeError('replay nao deterministico: '+rel)
  print('PASS: manifest',len(a['files']),'outputs deterministic',len(orig),'tests',tests.stderr.strip().splitlines()[-2:])
if __name__=='__main__':run()
