"""PA-R49: funções puras de sensibilidade e qualidade da evidência.

Não classifica RE, não calcula custo canônico de PA, não modifica motores.
Valores de probabilidade ou reducao sao CONTRAFACTUAIS, nunca observacoes.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import isfinite
import re
from urllib.parse import urlsplit

RANKS = ('Bronze','Prata','Ouro','Ouro Negro','Lendário')
NOTION = re.compile(r'(?:^|/)([0-9a-f]{32})(?:$|\?)',re.I)

def unit(x: float) -> float:
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not isfinite(x) or not 0<=x<=1:
        raise ValueError('probabilidade deve ser numero finito em [0,1]')
    return float(x)

def positive(x: float) -> float:
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not isfinite(x) or x<0:
        raise ValueError('medida hipotetica nao negativa e finita')
    return float(x)

def retaliation(p_save_fails, p_attack_received=1, p_reaction_available=1):
    """Dano teórico E[dano]=P(gatilho)*P(reacao disponivel|gatilho)*(5.5+5.5*P(falha|reacao))."""
    p=unit(p_save_fails); t=unit(p_attack_received); r=unit(p_reaction_available)
    return round(t*r*(5.5+5.5*p),8)

def chromatic_orb(p_hit, elemental_multiplier=1):
    """DME bruta do unico tipo escolhido, multiplicador EXPLORATORIO, sem fraqueza oficial inferida."""
    p=unit(p_hit); m=positive(elemental_multiplier)
    return round(13.5*p*m,8)

def shocking_touch(p_hit, p_reaction_opportunity):
    """Duas unidades NÃO aditivas: dano esperado e oportunidade esperada de suprimir Reacao futura."""
    p=unit(p_hit); r=unit(p_reaction_opportunity)
    return {'expected_raw_damage':round(4.5*p,8),'expected_reactions_prevented':round(p*r,8)}

def beast_link(*, touched, friendly_or_charmed, intelligence_below_4, mutual_line_of_sight, maintained):
    """Aplica SOMENTE os gates descritos na imagem, sem atribuir grau de poder."""
    opts=(touched,friendly_or_charmed,intelligence_below_4,mutual_line_of_sight,maintained)
    if not all(isinstance(x,bool) for x in opts):
        raise TypeError('gates booleanos explicitos obrigatorios')
    return all(opts)

def physical_ward_fixed(damage, reduction):
    """HIPOTESE NÃO CANÔNICA de RD fixa, para teste de sensibilidade apenas."""
    d=positive(damage);r=positive(reduction)
    return round(max(0,d-r),8)

def physical_ward_fraction(damage, fraction_removed):
    """HIPOTESE NÃO CANÔNICA de reducao percentual, para teste de sensibilidade apenas."""
    d=positive(damage);f=unit(fraction_removed)
    return round(d*(1-f),8)

def notion_identity(url: str) -> str:
    """Rejeita host falso; só conta UUID valido como mesma fonte."""
    if not isinstance(url,str): raise ValueError('URL invalida')
    p=urlsplit(url)
    if p.scheme!='https' or p.hostname not in ('app.notion.com','www.notion.so','notion.so') or p.username or p.password or p.port not in (None,443):
        raise ValueError('dominio ou credencial nao autorizado')
    path=p.path.rstrip('/')
    m=NOTION.search(path)
    if not m: raise ValueError('UUID Notion ausente')
    return m.group(1).lower()

def comparator_quality(*, source_class, same_mechanism, isolated_rank, known_cost, verified):
    """Taxonomia conservadora, nao cria E0/E1 nem aumenta nivel de prova por contagem."""
    if source_class not in ('rule','character','item','ability'): raise ValueError('tipo desconhecido')
    if not all(isinstance(x,bool) for x in (same_mechanism,isolated_rank,known_cost,verified)): raise TypeError('evidencias devem ser booleanas')
    if not verified: return 'UNVERIFIED'
    if not same_mechanism: return 'INDIRECT_CONTEXT_ONLY'
    if not isolated_rank: return 'MECHANICAL_ANALOG_NO_EFFECT_RE'
    if not known_cost: return 'RANK_ANALOG_COST_UNRESOLVED'
    return 'POTENTIAL_EFFECT_ANCHOR_REQUIRES_HUMAN_REVIEW'

def compare_predictions(rows):
    """Compara com segunda IA como PARECER, não verdade. Garante IDs, classes e transparencia do denominador."""
    ids=set();live=[]
    for row in rows:
        id_=row['id'];a=row['r45'];b=row['peer']
        if id_ in ids: raise ValueError('id duplicado')
        ids.add(id_)
        if a not in RANKS: raise ValueError('rank R45 invalido')
        if b=='INSUFICIENTE':continue
        if b not in RANKS:raise ValueError('rank peer invalido')
        live.append((a,b))
    if not live: raise ValueError('nenhum caso elegivel')
    n=len(live)
    exact=sum(a==b for a,b in live)
    silver=sum(b=='Prata' for _,b in live)
    a_wins=sum(a==b and b!='Prata' for a,b in live)
    s_wins=sum(b=='Prata' and a!=b for a,b in live)
    classes=sorted(set(b for _,b in live),key=RANKS.index)
    recall_by_rank={r:sum(a==r and b==r for a,b in live)/sum(b==r for _,b in live) for r in classes}
    macro_recall=sum(recall_by_rank.values())/len(classes)
    return {'n_eligible':n,'n_abstention':len(rows)-n,'r45_hits':exact,
            'constant_prata_hits':silver,'r45_only_wins':a_wins,'prata_only_wins':s_wins,
            'macro_recall_if_peer_assumed_reference':round(macro_recall,6),
            'macro_recall_constant_prata':round(1/len(classes) if 'Prata' in classes else 0,6),
            'peer_rank_counts':{r:sum(b==r for _,b in live) for r in classes},
            'r45_recall_by_peer_rank':recall_by_rank,
            'accuracy_status':'NOT_ADJUDICATED_PEER_IS_NOT_GOLD'}
