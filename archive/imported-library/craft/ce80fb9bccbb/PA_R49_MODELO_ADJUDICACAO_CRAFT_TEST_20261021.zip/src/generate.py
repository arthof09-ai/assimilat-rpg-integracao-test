"""Reprodutor R49: separa estimativas contrafactuais de observações reais."""
from __future__ import annotations
import json,sys,zipfile,hashlib,csv,itertools,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from modelo import *
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source'
OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)

def save(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

origin=json.loads((SOURCE/'ORIGIN_SHA256.json').read_text(encoding='utf-8'))
for name in ('PEER_R48_CROSSCHECK.json','MATRIZ_QUATRO_DIVERGENCIAS.json'):
 assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==origin[name], 'SOURCE TAMPERING'
metrics=json.loads((SOURCE/'PEER_R48_CROSSCHECK.json').read_text(encoding='utf-8'))['metrics']
matrix=json.loads((SOURCE/'MATRIZ_QUATRO_DIVERGENCIAS.json').read_text(encoding='utf-8'))
assert metrics['n_eligible']==11 and len(metrics['per_case'])==11  # R48 omite o caso abstido na tabela comparavel
rows=[{'id':i['id'],'r45':i['r45_frozen'],'peer':i['peer_frozen']} for i in metrics['per_case']]
rows.append({'id':'TEC-E3532F6A98AC','r45':'Prata','peer':'INSUFICIENTE'})  # manter denominador bruto de 12
result=compare_predictions(rows)
assert result['n_eligible']==11 and result['n_abstention']==1
assert result['r45_hits']==7 and result['constant_prata_hits']==7
assert result['r45_only_wins']==1 and result['prata_only_wins']==1
result['matched_paired_summary']={
 'both_correct':6,
 'both_wrong':3,
 'only_r45_correct':1,
 'only_constant_prata_correct':1,
 'no_superiority_claim':True,
 'mcnemar_exact_p_two_sided':1.0,
 'comparison_definition':'parecer IA congelado versus outro parecer IA congelado, nao acuracia canônica'}
result['cohen_nominal_kappa']=metrics['cohen_nominal_kappa']
result['r45_interval_hits']=metrics['within_R45_band']
result['always_prata_interval_hits']=metrics['naive_Prata_within_R45_band']
result['methodology']={
 'selected_outliers_not_random':True,'comparator_peer_not_gold':True,
 'r45_observer_preexposure_possible':True,'case_e353_exposed':True,
 'avoid_tuning_to_11_cases':True,'test_pre_registered_14_new_cases_with_new_reviewer':True}
save('METRICAS_SEM_GABARITO_COMO_VERDADE.json',result)

levels=[0,.25,.5,.75,1]; scenarios={
'WARNING':'Todos os valores de probabilidade/multiplicador sao EXPLORATORIOS. Nao foram medidos em sessao, nao determinam rank ou custo PA.',
'retaliation':[], 'orbe':[], 'toque':[], 'vinculo':[], 'protecao':[]}
for p,t,r in itertools.product(levels,repeat=3):
 scenarios['retaliation'].append({'p_falha_save':p,'p_sofreu_dano_gatilho':t,'p_reacao_ainda_disponivel':r,'DME_condicional_de_uso':retaliation(p,t,r)})
for p,m in itertools.product(levels,[.5,1,1.5,2]):
 scenarios['orbe'].append({'p_acerto':p,'multiplicador_exploratorio_tipo_escolhido':m,'DME_condicional_de_uso':chromatic_orb(p,m)})
for p,r in itertools.product(levels,repeat=2):
 scenarios['toque'].append({'p_acerto':p,'p_haveria_reacao_futura_apos_acerto':r,**shocking_touch(p,r)})
for bits in itertools.product([False,True],repeat=5):
 scenarios['vinculo'].append({'tocou':bits[0],'amizade_ou_encanto':bits[1],'int_origem_menor_4':bits[2],'linha_visao_mutua':bits[3],'concentracao_mantida':bits[4],'canal_origem_operacional':beast_link(touched=bits[0],friendly_or_charmed=bits[1],intelligence_below_4=bits[2],mutual_line_of_sight=bits[3],maintained=bits[4])})
for d,r in itertools.product([5,20,50,100],[0,5,15,30]):
 scenarios['protecao'].append({'dano_recebido':d,'modelo_ficticio':'RD_Fixa','parametro_ficticio':r,'dano_apos_hipotese':physical_ward_fixed(d,r)})
for d,f in itertools.product([5,20,50,100],[0,.25,.5,.75]):
 scenarios['protecao'].append({'dano_recebido':d,'modelo_ficticio':'Reducao_Fracional','parametro_ficticio':f,'dano_apos_hipotese':physical_ward_fraction(d,f)})
assert {k:len(v) for k,v in scenarios.items() if isinstance(v,list)}=={'retaliation':125,'orbe':20,'toque':25,'vinculo':32,'protecao':32}
save('CENARIOS_CONDICIONAIS_NAO_CANONICOS.json',scenarios)

case_refs=[
 {'id':'TEC-7F4A4B423743','nome':'Repreensão Infernal','fonte_real':'https://app.notion.com/p/836c2b324ede83e2aae6016379ef2135', 'classe_fonte':'habilidade de arma Retaliacao','comparabilidade':'gatilho mesmo, mecanismos de ataque diferentes','ambiguidade':'16 PA/dia na habilidade; 16 PA/turno no equipamento de Tento; Gêmeas custo agregado; bypass de imunidade varia', 'requisito_decisivo':'custo e janela da Reação; benchmark de efeito reativo com RE isolado, nao RN do portador', 'resultado':'HOLD_BRONZE_PRATA'},
 {'id':'TEC-968D29765EB1','nome':'Orbe cromática','fonte_real':'https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474', 'classe_fonte':'Explosão de Terra de Gorrok','comparabilidade':'dano elementar nominal proximo; explosao em area vs orbe alvo unico','ambiguidade':'Ouro1 e RN de Gorrok; seus 4d6 em area nao criam RE; tags estrangeiras nao mapeadas','requisito_decisivo':'mapeamento das seis tags, dano e efeito da fraqueza em alvo unico, acerto e diamante', 'resultado':'HOLD_BRONZE_PRATA'},
 {'id':'TEC-AC33D1C9DD16','nome':'Vínculo com a besta','fonte_real':'https://app.notion.com/p/b45c2b324ede829eb04d011f826e427e', 'classe_fonte':'Coleira de Subjugacao','comparabilidade':'ambas interagem com bestas, MAS coleira domina e vinculo so comunica','ambiguidade':'requer besta amiga, toque, INT origem <4, linha de visao mutua e concentracao','requisito_decisivo':'mecanica de comunicacao mental ja homologada ou teste controlado de utilidade de silencio versus conversa convencional', 'resultado':'HOLD_BRONZE_PRATA'},
 {'id':'TEC-D9EF9388353A','nome':'Toque chocante','fonte_real':'https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0', 'classe_fonte':'Sistema de Combate: Reacoes','comparabilidade':'o efeito nega Defesa, Esquiva, Contra-ataque e Refletir futuras, mas regra nao e tecnica rankeada','ambiguidade':'ataque precisa acertar e reacao anterior ao acerto nao e desfeita retroativamente','requisito_decisivo':'efeito de impedir uma Reacao apos acerto em cenarios de combate, janela ate inicio do turno do alvo', 'resultado':'HOLD_BRONZE_PRATA'}]
assert {c['id'] for c in case_refs}=={c['id'] for c in matrix['cases']}
for c in case_refs:
 c['fonte_uuid']=notion_identity(c['fonte_real']);c['r45']=next(v['r45'] for v in matrix['cases'] if v['id']==c['id'])
 c['peer']=next(v['peer'] for v in matrix['cases'] if v['id']==c['id'])
 c['peer_evidence']='E2'
save('FICHAS_DECISAO_4_E2_MESTRE_ONLY.json',case_refs)

# Fonte comparativa nao E0 isolada. Texto apenas com o que foi fisicamente consultado no Notion.
conflict={'id':'PA-R49-CONFLITO-RETALIACAO-01', 'title':'Retaliacao: taxa e bypass divergentes entre fontes que nao sao independentes',
 'source_pages':[
 {'notion_page_uuid':'836c2b324ede83e2aae6016379ef2135','title':'Retaliação','PA_incidence':'16 PA por dia','bypass':'ignora resistencia ao dano'},
 {'notion_page_uuid':'d3fc2b324ede83c3a1bb01356904ce06','title':'Tento (Mestre)','PA_incidence':'16 PA por turno','bypass':'ignora imunidade ou resistencia'},
 {'notion_page_uuid':'33fc2b324ede830284c1819bfe775d2c','title':'Tento (espelho de origem, conteudo repetido)','PA_incidence':'16 PA por turno','bypass':'ignora imunidade ou resistencia'},
 {'notion_page_uuid':'6f7c2b324ede823b80068113b789aa06','title':'Gêmeas Estreladas','PA_incidence':'57 PA por dia NO CONJUNTO','bypass':'ignora imunidade ou resistencia'}],
 'not_decided':['qual versao normativamente vigente','se diaria ou por turno','bypass imunidade ou resistencia','tarifa da magia externa','rank isolado de Retaliação'],
 'route':'Autoridade pertinente via NAC-NORM-01/IBX existente; neste estudo apenas preregistro Mestre-side',
 'status':'PENDENTE_NORMATIVO_SEM_ESCRITA_EM_FICHA'}
save('REGISTRO_CONFLITO_RETALIACAO_MESTRE_ONLY.json',conflict)

text=f'''# PA R49 — Estudo de sensibilidade, falsificação e decisão (MESTRE-ONLY / TEST)

## Regra de separação
Esta entrega **não produz rank nem custo de PA**. Examina se há condições sob as quais cada escolha R45 versus peer seria plausível. Nenhuma probabilidade, frequência, redutor ou multiplicador foi observado em jogo; os valores enumerados são exemplos contrafactuais para **refutar generalizações**. O motor canônico R26/R27 e R42 são preservados.

## Base empírica e achado metodológico
Peer real entregue e congelado com SHA `d5fa1054b6e296d893e182a735efb24f2053ffdf28bbcecae7da552318b93435`; R45 foi congelado antes do oráculo legado. 11 comparáveis, 1 abstinência E353 por exposição ao Atlas. Acordo R45/peer **7/11**, baseline *sempre Prata* também **7/11**. R45 supera a baseline em um caso (Ouro em Imobilizar Pessoa) e perde em outro (Prata em Repreensão Infernal); os outros 9 não diferenciam os dois métodos. McNemar exato dois lados = 1,0. Macro recall condicionada a tratar peer apenas como REFERÊNCIA PROVISÓRIA: {result['macro_recall_if_peer_assumed_reference']:.3f} R45 vs {result['macro_recall_constant_prata']:.3f} sempre Prata, mas o Ouro tem apenas UM representante, amostra enviesada e não mede acurácia verdadeira.

## Repreensão Infernal: avaliação causal limitada
A imagem tem 2d10 fogo na falha (11 DME), metade no sucesso (5,5), ação REAÇÃO após sofrer dano. `E[dano]=P(gatilho) × P(reação disponível | gatilho) × [5,5+5,5×P(falha do alvo)]`. Com P(gatilho)=P(reação)=1, limites condicionais **5,5–11**. Com qualquer gatilho/reação indisponível, valor zero. Esses fatores jamais foram medidos. A fonte real mais próxima Retaliação conflita em **16 PA/dia** vs **16 PA/turno** e bypass, logo não resolve tarifa nem RE. HOLD.

## Orbe Cromática: versatilidade ≠ seis ataques
DME por acerto = 3d8 = 13,5 com UM dos seis tipos selecionados e teste de ataque. Tabela hipotética calcula `13,5 × P(acerto) × multiplicador experimental`, mas não inventa mapeamento de elementos nem aplica Fraqueza Elemental automaticamente. Se multiplicador real não trouxer vantagem recorrente, Bronze é plausível; efeito de escolha frequentemente vantajoso poderia sustentar Prata, ainda não demonstrado.

## Vínculo com besta: gates observáveis, RE ainda desconhecido
A imagem exige besta tocada, amiga/enfeitiçada, INT original menor que 4, linha de visão mútua e concentração (10 minutos na fonte). A grade 2⁵ mostra **1/32 combinações de gates** com vínculo operacional por descrição; esta proporção NÃO é probabilidade real, pois o ambiente não amostra combinações equiprovavelmente. Não há controle da besta nem comunicação remota sem visão; benefício de silêncio mental deve ser ensaiado contra comunicação normal. RE continua Bronze/Prata condicionado.

## Toque Chocante: não somar coisas de unidades diferentes
Ao acertar: 1d8=4,5 DME e o alvo fica sem Reações até o início do próximo turno dele; alcance toque, vantagem estrangeira contra metal. Representar **separadamente** dano esperado `4,5×P(acerto)` e número esperado de oportunidades de Reação futura evitadas `P(acerto)×P(haveria reação futura)`. Não somar tais eixos sem uma função de utilidade fundamentada. A defesa anunciada antes de o golpe acertar não é retroativamente anulada. RE sem adjudicação.

## Proteção contra Lâminas: demonstração da lacuna, NÃO adaptação aprovada
Texto da imagem diz 1 AÇÃO, 1 rodada e resistência a três formas de dano de arma; NÃO define quanto resiste no Assimilação. Grade prospectiva de RD fixa ou fração de redução gera diferenças enormes no dano residual. Nada disso autoriza escolher redução de metade, RD15, rank Ouro Negro ou Prata. O Atlas contém rótulo Ouro Negro documental, mas mestre informou origem legada subjetiva. E353 do peer foi contaminado e abstido. HOLD revisão cega e decisão normativa.

## Adjudicação e ciência
Os comparadores (Regra, portador RN, habilidade de item RI) são operacionalmente diversos; contar URLs não aumenta semelhança nem valida rank. Para cada caso, exigir **ponto falsificador** registrado, comparador com RE isolado ou testes reais, definição de ação, custo e contramedida quando necessários. Usar holdout das 14 restantes sem abrir o oráculo, com critérios de sucesso definidos antes do parecer. Registrar resultados favoráveis e desfavoráveis. Não usar scores E2/E3 como notas de confiança probabilística nem usar rank histórico como gabarito.

## Fronteira CRAFT
P2 (sal Santo/Encantado; energia no BOM sem passo de aplicação) e Óleo (Amanhecer/Lua Minguante versus Dragão/Vórtice) continuam sob responsabilidade da operação CRAFT especializada, HOLD material, sem lotes/operador/aplicação. Teste digital de PA não demonstra instalação mágica ou efeito do item. O conflito Retaliação não pertence à receita CRAFT e não constitui tarifa normativa do PA.

## Artefatos
`METRICAS_SEM_GABARITO_COMO_VERDADE.json`, `CENARIOS_CONDICIONAIS_NAO_CANONICOS.json`, `FICHAS_DECISAO_4_E2_MESTRE_ONLY.json`, `REGISTRO_CONFLITO_RETALIACAO_MESTRE_ONLY.json`, fonte Python e testes unitários. Tudo TEST, sigilo Mestre-only, sem escrita Party/O Primeiro.
'''
(ROOT/'docs'/'RELATORIO_R49_MESTRE_ONLY.md').write_text(text,encoding='utf-8')
print(json.dumps({'scenarios':{k:len(v) for k,v in scenarios.items() if isinstance(v,list)},'metrics':result,'source_zip_sha256':origin['origin_R48_ZIP']},ensure_ascii=False,indent=2))
