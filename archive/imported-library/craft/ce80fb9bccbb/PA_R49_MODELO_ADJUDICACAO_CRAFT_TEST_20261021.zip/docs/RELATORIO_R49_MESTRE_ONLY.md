# PA R49 — Estudo de sensibilidade, falsificação e decisão (MESTRE-ONLY / TEST)

## Regra de separação
Esta entrega **não produz rank nem custo de PA**. Examina se há condições sob as quais cada escolha R45 versus peer seria plausível. Nenhuma probabilidade, frequência, redutor ou multiplicador foi observado em jogo; os valores enumerados são exemplos contrafactuais para **refutar generalizações**. O motor canônico R26/R27 e R42 são preservados.

## Base empírica e achado metodológico
Peer real entregue e congelado com SHA `d5fa1054b6e296d893e182a735efb24f2053ffdf28bbcecae7da552318b93435`; R45 foi congelado antes do oráculo legado. 11 comparáveis, 1 abstinência E353 por exposição ao Atlas. Acordo R45/peer **7/11**, baseline *sempre Prata* também **7/11**. R45 supera a baseline em um caso (Ouro em Imobilizar Pessoa) e perde em outro (Prata em Repreensão Infernal); os outros 9 não diferenciam os dois métodos. McNemar exato dois lados = 1,0. Macro recall condicionada a tratar peer apenas como REFERÊNCIA PROVISÓRIA: 0.619 R45 vs 0.333 sempre Prata, mas o Ouro tem apenas UM representante, amostra enviesada e não mede acurácia verdadeira.

## Repreensão Infernal: avaliação causal limitada
A imagem tem 2d10 fogo na falha (11 DME), metade no sucesso (5,5), ação REAÇÃO após sofrer dano. `E[dano]=P(gatilho) × P(reação disponível | gatilho) × [5,5+5,5×P(falha do alvo)]`. Com P(gatilho)=P(reação)=1, limites condicionais **5,5–11**. Com qualquer gatilho/reação indisponível, valor zero. Esses fatores jamais foram medidos. A fonte real mais próxima Retaliação conflita em **16 PA/dia** vs **16 PA/turno** e bypass, logo não resolve tarifa nem RE. HOLD.

## Orbe Cromática: versatilidade ≠ seis ataques
DME por acerto = 3d8 = 13,5 com UM dos seis tipos selecionados e teste de ataque. Tabela hipotética calcula `13,5 × P(acerto) × multiplicador experimental`, mas não inventa mapeamento de elementos nem aplica Fraqueza Elemental automaticamente. Se multiplicador real não trouxer vantagem recorrente, Bronze é plausível; efeito de escolha frequentemente vantajoso poderia sustentar Prata, ainda não demonstrado.

## Vínculo com besta: gates observáveis, RE ainda desconhecido
A imagem exige besta tocada, amiga/enfeitiçada, INT original menor que 4, linha de visão mútua e concentração (10 minutos na fonte). A grade 2⁵ mostra **1/32 combinações de gates** com vínculo operacional por descrição; esta proporção NÃO é probabilidade real, pois o ambiente não amostra combinações equiprovavelmente. Não há controle da besta nem comunicação remota sem visão; benefício de silêncio mental deve ser ensaiado contra comunicação normal. RE continua Bronze/Prata condicionado.

## Toque Chocante: não somar coisas de unidades diferentes
Ao acertar: 1d8=4,5 DME e o alvo fica sem Reações até o início do próximo turno dele; alcance toque, vantagem estrangeira contra metal. Representar **separadamente** dano esperado `4,5×P(acerto)` e número esperado de oportunidades de Reação futura evitadas `P(acerto)×P(haveria reação futura)`. Não somar tais eixos sem uma função de utilidade fundamentada. A defesa anunciada antes de o golpe acertar não é retroativamente anulada. RE sem adjudicação.

## Proteção contra Lâminas: demonstração da lacuna, NÃO adaptação aprovada
Texto da imagem diz 1 AÇÃO, 1 rodada e resistência a três formas de dano de arma; NÃO define quanto resiste no Assimilação. Grade prospectiva de RD fixa ou fração de redução gera diferenças enormes no dano residual. Nada disso autoriza escolher redução de metade, RD15, rank Ouro Negro ou Prata. O Atlas contém rótulo Ouro Negro documental, mas mestre informou origem legada subjetiva. E353 do peer foi contaminado e abstido. HOLD revisão cega e decisão normativa.

## Adjudicação e ciência
Os comparadores (Regra, portador RN, habilidade de item RI) são operacionalmente diversos; contar URLs não aumenta semelhança nem valida rank. Para cada caso, exigir **ponto falsificador** registrado, comparador com RE isolado ou testes reais, definição de ação, custo e contramedida quando necessários. Usar holdout das 14 restantes sem abrir o oráculo, com critérios de sucesso definidos antes do parecer. Registrar resultados favoráveis e desfavoráveis. Não usar scores E2/E3 como notas de confiança probabilística nem usar rank histórico como gabarito.

## Fronteira CRAFT
P2 (sal Santo/Encantado; energia no BOM sem passo de aplicação) e Óleo (Amanhecer/Lua Minguante versus Dragão/Vórtice) continuam sob responsabilidade da operação CRAFT especializada, HOLD material, sem lotes/operador/aplicação. Teste digital de PA não demonstra instalação mágica ou efeito do item. O conflito Retaliação não pertence à receita CRAFT e não constitui tarifa normativa do PA.

## Artefatos
`METRICAS_SEM_GABARITO_COMO_VERDADE.json`, `CENARIOS_CONDICIONAIS_NAO_CANONICOS.json`, `FICHAS_DECISAO_4_E2_MESTRE_ONLY.json`, `REGISTRO_CONFLITO_RETALIACAO_MESTRE_ONLY.json`, fonte Python e testes unitários. Tudo TEST, sigilo Mestre-only, sem escrita Party/O Primeiro.
