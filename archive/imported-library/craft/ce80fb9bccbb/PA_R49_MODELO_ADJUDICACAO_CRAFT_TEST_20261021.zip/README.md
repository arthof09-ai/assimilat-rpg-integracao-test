# PA-R49 — Perícia comparativa e falsificação / Mestre-only / TEST

Nova camada **experimental** de análise pós-congelamento R45 + auditoria peer (ZIP autenticado). NÃO substitui a R48 original, não canoniza qualquer RE, não precifica PA, não escreve no Notion/Party. Trata somente de evidências já verificadas e cenários explicitamente condicionais.

## Execução em diretório limpo

```bash
python run_cold.py
```

O script verifica SHA-256 do próprio inventário, SHA das duas extrações de fonte R48, reexecuta os testes e os geradores numa cópia temporária, verifica identidade byte a byte das saídas e falha se houver divergência. Usa apenas Python padrão.

## Conteúdo

- `docs/RELATORIO_R49_MESTRE_ONLY.md`: raciocínio científico, limites, fontes e fronteira CRAFT;
- `outputs/METRICAS_SEM_GABARITO_COMO_VERDADE.json`: R45/peer versus baseline Prata, denominador e qualidade;
- `outputs/CENARIOS_CONDICIONAIS_NAO_CANONICOS.json`: 234 condições **hipotéticas**, não resultados de sessão;
- `outputs/FICHAS_DECISAO_4_E2_MESTRE_ONLY.json`: perguntas capazes de refutar cada hipótese;
- `outputs/REGISTRO_CONFLITO_RETALIACAO_MESTRE_ONLY.json`: PA por dia × por turno sem reescrever fontes;
- `source/`: recortes de resultados R48 já congelados, com hashes e SHA do pacote ancestral;
- `src/`: cálculos simbólicos/condicionais, sem API externa;
- `tests/`: unidade e integridade.

**NAC-PASS PROPORCIONAL:** PASS código/testes/identidade e pesquisa documental; HOLD decisão normativa, 4 RE, E353 contaminada, custo de PA, P2/CRAFT material. A separação Mestre ↔ Party é obrigatória.
