import sys,unittest
sys.path.insert(0,__file__.split('/tests/')[0]+'/src')
from modelo import *
class TestModel(unittest.TestCase):
 def test_ret_0(self):self.assertEqual(retaliation(0),5.5)
 def test_ret_1(self):self.assertEqual(retaliation(1),11)
 def test_ret_half(self):self.assertEqual(retaliation(.5),8.25)
 def test_ret_trigger0(self):self.assertEqual(retaliation(.5,0),0)
 def test_ret_ready0(self):self.assertEqual(retaliation(.5,1,0),0)
 def test_ret_joint(self):self.assertEqual(retaliation(.5,.5,.5),2.0625)
 def test_orb_hit0(self):self.assertEqual(chromatic_orb(0),0)
 def test_orb_hit1(self):self.assertEqual(chromatic_orb(1),13.5)
 def test_orb_half(self):self.assertEqual(chromatic_orb(.5),6.75)
 def test_orb_mult(self):self.assertEqual(chromatic_orb(1,2),27)
 def test_touch_hit0(self):self.assertEqual(shocking_touch(0,1)['expected_reactions_prevented'],0)
 def test_touch_hit1(self):self.assertEqual(shocking_touch(1,1),{'expected_raw_damage':4.5,'expected_reactions_prevented':1})
 def test_touch_half(self):self.assertEqual(shocking_touch(.5,.5),{'expected_raw_damage':2.25,'expected_reactions_prevented':.25})
 def test_link_yes(self):self.assertTrue(beast_link(touched=True,friendly_or_charmed=True,intelligence_below_4=True,mutual_line_of_sight=True,maintained=True))
 def test_link_no_los(self):self.assertFalse(beast_link(touched=True,friendly_or_charmed=True,intelligence_below_4=True,mutual_line_of_sight=False,maintained=True))
 def test_link_no_friend(self):self.assertFalse(beast_link(touched=True,friendly_or_charmed=False,intelligence_below_4=True,mutual_line_of_sight=True,maintained=True))
 def test_link_bad_type(self):
  with self.assertRaises(TypeError):beast_link(touched='sim',friendly_or_charmed=True,intelligence_below_4=True,mutual_line_of_sight=True,maintained=True)
 def test_fixed(self):self.assertEqual(physical_ward_fixed(30,15),15)
 def test_fixed_floor(self):self.assertEqual(physical_ward_fixed(5,15),0)
 def test_pct(self):self.assertEqual(physical_ward_fraction(30,.5),15)
 def test_pct_none(self):self.assertEqual(physical_ward_fraction(30,0),30)
 def test_pct_max(self):self.assertEqual(physical_ward_fraction(30,1),0)
 def test_host(self):self.assertEqual(notion_identity('https://app.notion.com/p/836c2b324ede83e2aae6016379ef2135?pvs=204'),'836c2b324ede83e2aae6016379ef2135')
 def test_host_same(self):self.assertEqual(notion_identity('https://app.notion.com/p/836c2b324ede83e2aae6016379ef2135'),notion_identity('https://app.notion.com/p/836c2b324ede83e2aae6016379ef2135?pvs=204'))
 def test_host_fake(self):
  with self.assertRaises(ValueError):notion_identity('https://app.notion.com.evil/p/836c2b324ede83e2aae6016379ef2135')
 def test_host_bad_credentials(self):
  with self.assertRaises(ValueError):notion_identity('https://user@app.notion.com/p/836c2b324ede83e2aae6016379ef2135')
 def test_comparator_unranked(self):self.assertEqual(comparator_quality(source_class='item',same_mechanism=True,isolated_rank=False,known_cost=True,verified=True),'MECHANICAL_ANALOG_NO_EFFECT_RE')
 def test_comparator_not_mech(self):self.assertEqual(comparator_quality(source_class='character',same_mechanism=False,isolated_rank=True,known_cost=True,verified=True),'INDIRECT_CONTEXT_ONLY')
 def test_comparator_cost(self):self.assertEqual(comparator_quality(source_class='ability',same_mechanism=True,isolated_rank=True,known_cost=False,verified=True),'RANK_ANALOG_COST_UNRESOLVED')
 def test_comparator_unverified(self):self.assertEqual(comparator_quality(source_class='ability',same_mechanism=True,isolated_rank=True,known_cost=True,verified=False),'UNVERIFIED')
 def test_reject_invalid_probs(self):
  for x in (-.1,1.1,float('nan'),float('inf'),True,'0.5'):
   with self.subTest(x=x),self.assertRaises(ValueError):unit(x)
 def test_reject_invalid_values(self):
  for x in (-1,float('nan'),float('inf'),False,'25'):
   with self.subTest(x=x),self.assertRaises(ValueError):positive(x)
 def test_macro(self):
  rows=[{'id':'1','r45':'Ouro','peer':'Ouro'},{'id':'2','r45':'Bronze','peer':'Prata'},{'id':'3','r45':'Prata','peer':'Bronze'}]
  r=compare_predictions(rows);self.assertEqual(r['r45_hits'],1);self.assertEqual(r['constant_prata_hits'],1)
 def test_duplicate(self):
  with self.assertRaises(ValueError):compare_predictions([{'id':'1','r45':'Ouro','peer':'Ouro'},{'id':'1','r45':'Prata','peer':'Bronze'}])
 def test_full_abstain(self):
  with self.assertRaises(ValueError):compare_predictions([{'id':'1','r45':'Ouro','peer':'INSUFICIENTE'}])
 def test_reject_boolean_zero(self):
  with self.assertRaises(ValueError):positive(True)
 def test_response_no_double_count(self):
  a=shocking_touch(1,1);self.assertEqual(set(a),{'expected_raw_damage','expected_reactions_prevented'})
 def test_ward_not_identical(self):
  self.assertNotEqual(physical_ward_fixed(50,15),physical_ward_fraction(50,.5))
 def test_probability_monotonic_grid(self):
  arr=[retaliation(i/20) for i in range(21)];self.assertEqual(sorted(arr),arr)
 def test_orb_monotonic_grid(self):
  arr=[chromatic_orb(i/20) for i in range(21)];self.assertEqual(sorted(arr),arr)
 def test_touch_bounds(self):
  for i in range(11):
   for j in range(11):
    x=shocking_touch(i/10,j/10);self.assertTrue(0<=x['expected_reactions_prevented']<=1)
if __name__=='__main__': unittest.main()
