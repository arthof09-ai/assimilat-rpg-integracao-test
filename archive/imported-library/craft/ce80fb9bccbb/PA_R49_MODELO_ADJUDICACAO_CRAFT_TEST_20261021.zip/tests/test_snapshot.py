import unittest, pathlib, json, hashlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from modelo import compare_predictions

class TestFrozenComparators(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.origin=json.loads((ROOT/'source'/'ORIGIN_SHA256.json').read_text())
  cls.m=json.loads((ROOT/'source'/'PEER_R48_CROSSCHECK.json').read_text())['metrics']
  cls.matrix=json.loads((ROOT/'source'/'MATRIZ_QUATRO_DIVERGENCIAS.json').read_text())
  cls.four=json.loads((ROOT/'outputs'/'FICHAS_DECISAO_4_E2_MESTRE_ONLY.json').read_text())
  cls.metrics=json.loads((ROOT/'outputs'/'METRICAS_SEM_GABARITO_COMO_VERDADE.json').read_text())
 def test_frozen_source_bytes_crosscheck(self):
  for n in ('PEER_R48_CROSSCHECK.json','MATRIZ_QUATRO_DIVERGENCIAS.json'):
   self.assertEqual(hashlib.sha256((ROOT/'source'/n).read_bytes()).hexdigest(),self.origin[n])
 def test_original_source_record(self): self.assertEqual(self.origin['origin_R48_ZIP'],'8237d594a2fb0e3694fcfa98037633accdb16396a06c22166ea86d1536943eff')
 def test_peers_count(self): self.assertEqual((self.m['n_eligible'],self.m['n_total'],self.m['n_contaminated']),(11,12,1))
 def test_no_oracle_truth(self): self.assertEqual(self.metrics['accuracy_status'],'NOT_ADJUDICATED_PEER_IS_NOT_GOLD')
 def test_exact_four(self):self.assertEqual({c['id'] for c in self.four},{c['id'] for c in self.matrix['cases']})
 def test_disagreements(self): self.assertEqual(len(self.m['discordances']),4)
 def test_disagree_e2(self): self.assertTrue(all(c['peer_evidence']=='E2' for c in self.four))
 def test_unique_source_uuid(self): self.assertEqual(len({c['fonte_uuid'] for c in self.four}),4)
 def test_no_new_rank(self): self.assertTrue(all(c['resultado']=='HOLD_BRONZE_PRATA' for c in self.four))
 def test_baseline_same(self):self.assertEqual((self.metrics['r45_hits'],self.metrics['constant_prata_hits']),(7,7))
 def test_matched_win_equal(self):self.assertEqual((self.metrics['r45_only_wins'],self.metrics['prata_only_wins']),(1,1))
 def test_no_conflation(self):
  d=json.loads((ROOT/'outputs'/'REGISTRO_CONFLITO_RETALIACAO_MESTRE_ONLY.json').read_text());src=d['source_pages']
  self.assertEqual(len(src),4);self.assertNotEqual(src[0]['PA_incidence'],src[1]['PA_incidence']);self.assertIn('57 PA por dia NO CONJUNTO',src[3]['PA_incidence'])
 def test_hypothesis_rows(self):
  s=json.loads((ROOT/'outputs'/'CENARIOS_CONDICIONAIS_NAO_CANONICOS.json').read_text())
  self.assertEqual(tuple(map(len,[s['retaliation'],s['orbe'],s['toque'],s['vinculo'],s['protecao']])),(125,20,25,32,32))
 def test_link_combos_not_probability(self):
  s=json.loads((ROOT/'outputs'/'CENARIOS_CONDICIONAIS_NAO_CANONICOS.json').read_text());self.assertEqual(sum(c['canal_origem_operacional'] for c in s['vinculo']),1)
 def test_single_exposed_excluded(self):self.assertEqual(self.metrics['n_abstention'],1)
if __name__=='__main__':unittest.main()
