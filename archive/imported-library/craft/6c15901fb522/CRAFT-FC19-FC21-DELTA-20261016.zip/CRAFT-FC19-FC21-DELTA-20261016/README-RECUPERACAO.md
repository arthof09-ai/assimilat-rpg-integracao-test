# CRAFT FC19–FC21 — recuperação segura

Continuação estritamente **MESTRE-SIDE** de `CM-000002 / WS0001 / OP-ARQ-RIN-REC-01`. Pacote delta aditivo; não contém motor novo, dados canônicos ou permissões de escrita.

Pré-requisitos já preservados:
- `/mnt/data/craft_recovery/CRAFT-COMESTRE-CHAT-v03.zip` SHA-256 `5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434`.
- `/mnt/data/CRAFT-FC09-FC18-DELTA-20261016.zip` SHA-256 `e55c444908ce2d8d0a14d397d269ebbf1dddaaadb23b1ab400b5a6f76ec601db`.

A integração R44 original é importada **somente de ZIP em diretório temporário**. O código não lê credenciais nem efetua requisição à rede. Não confirma o draft R48, não toca no órfão FC04 nem registra itens reais.

Para recuperar a prova existente SEM execução de manufatura nova: extrair este delta e executar `python code/verify_clean_fc19_fc21.py` dentro da pasta `CRAFT-FC19-FC21-DELTA-20261016`. Isso lê o snapshot FC20 e calcula novamente hashes de eventos, inventário, recibos, saldo de massa auxiliar, rejeição e adulteração adversarial; retorna `PASS_PROPORTIONAL_TEST_AND_READONLY` quando íntegro. Não confia em flags `ok` do motor.

Para repetir a execução experimental somente se necessário, extrair FC18 em uma pasta de leitura separada e executar:

```
python code/fc19_fc21_audit_and_test.py \
  --fc18-root <caminho>/CRAFT-FC09-FC18-DELTA-20261016 \
  --fc18-zip <caminho>/CRAFT-FC09-FC18-DELTA-20261016.zip \
  --v03 <caminho>/CRAFT-COMESTRE-CHAT-v03.zip
```

Esse comando **substitui apenas os JSONs deste delta experimental**, nunca snapshots históricos. Não executar sem preservar a versão anterior do delta. Os hashes históricos são hard-gated.

Arquivos decisivos: `outputs/FC19_B30_04_identity_verdict.json`, `outputs/FC20_reconciliacao_R44_somente_leitura.json`, `contracts/FC20_B30_16_PREMISTURA_ADMISSAO_CONDICIONAL.json`, `outputs/FC20_B30_16_new_sandbox_receipt.json`, `outputs/FC20_RC5_gate_matrix.json`, `outputs/FC21_publication_write_set_DISABLED.json`, `outputs/FC21_checkpoint_succession.json`.

**Retomada:** reabrir a PS `Areia de Brecha Granulada` no Notion; resolver o que significa `Granulada` e se há receita embutida, sem criar REC-ID. Em paralelo localizar técnica/consumidor da pré-mistura B30-16. Sem fonte material, classificação HOLD; sem F5 GREEN + writer + C19 reconciliado, publicação proibida.
