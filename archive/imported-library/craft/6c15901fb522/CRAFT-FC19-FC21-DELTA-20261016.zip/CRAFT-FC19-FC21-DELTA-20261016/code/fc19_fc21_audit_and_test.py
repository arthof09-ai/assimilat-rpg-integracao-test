#!/usr/bin/env python3
"""CRAFT FC19-21 local-only: audit archived FC10 receipts; execute new B30-16 with original R44.
No external network, Notion, canon inventory, or changes to archived stores.
"""
import argparse, hashlib, importlib.util, json, pathlib, tempfile, zipfile
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE_FELD='3f3c2b32-4ede-81a2-a590-c53273f9e6e5'
SOURCE_CLAY='3f3c2b32-4ede-81b8-b187-f217b20c6bdb'
HIST_SHA='5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434'
FC18_SHA='e55c444908ce2d8d0a14d397d269ebbf1dddaaadb23b1ab400b5a6f76ec601db'
R44_PATH='CRAFT-COMESTRE-CHAT-v03/Oficina-v02/CRAFT-R48-SANDBOX-I0016/legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016/experimental_engine.py'
def digest_bytes(data):return hashlib.sha256(data).hexdigest()
def canon(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(obj):return digest_bytes(canon(obj))
def read_json(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def put(path,obj):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def calc_native_event(r):
 consumes=sum(z['quantity'] for z in r['consumed'] if z['unit']=='g')
 return {'attempt_id':r['attempt_id'],'status':r['status'],'native_g_consumed':consumes,
         'native_product_count':len(r['products']),'native_scrap_records':len(r['scrap']),
         'native_gram_fraction_items':[], 'native_mass_reconciliation': 'NOT_RECORDED_BY_R44',
         'receipt_hash_sha256':digest(r), 'request_hash':r['request_hash']}
def audit_fc10(fc18_path):
 receipts=read_json(fc18_path/'outputs/r44_B30_04/r44_executed_receipts.json')
 cases=receipts['cases']; assert len(cases)==3
 sources=[calc_native_event(r) for r in cases]
 assert [(r['status'],s['native_g_consumed']) for r,s in zip(cases,sources)]==[
 ('EXPERIMENTAL_QA_PASS',500),('REJECTED_PRECHECK',0),('REJECTED_QUALITY',500)]
 original_sheet=receipts['material_fraction_sheets']
 sheets=[]
 for r,f in [(cases[0],original_sheet[0]),(cases[2],original_sheet[1])]:
  assert f['feed_g']==500 and sum(f[k] for k in ('accepted_grade_g','coarse_g','fines_g','impurities_g','water_evaporated_g','dust_and_loss_g'))==500
  # A new *linked* read-only observation; not part of native R44 records or provenance proven by native events.
  sheets.append({'attempt_id':r['attempt_id'],'receipt_sha256':digest(r),
    'external_sheet_sha256':digest(f),'external_synthetic_sheet':f,
    'status':'AUXILIARY_NOT_NATIVE_NOT_SIGNED_BY_ENGINE',
    'limits':['associacao estabelecida nesta auditoria por ordem/fonte do script FC10','sem rastreio de residuos por gramas nos eventos R44','sem prova de frações fisicas reais']})
 # Independently verify native event chain using underlying snapshot and sealed initial state, without relying on audit flag.
 wrapper=read_json(fc18_path/'outputs/r44_B30_04/r44_snapshot.json')
 ss_sha=wrapper.pop('integrity_sha256');assert ss_sha==digest(wrapper)
 orig=wrapper['initial_lots'];balance={k:v['quantity'] for k,v in orig.items()}
 state=wrapper['state']; assert state['head_hash']==receipts['engine_audit']['head_hash']
 prev=hashlib.sha256(('SBX-CRAFT-R44-I0016'+'|GENESIS-v1').encode()).hexdigest()
 for i,e in enumerate(state['events'],1):
  assert e['previous_hash']==prev and e['hash']==digest({'previous_hash':prev,'event':e['event']}) and e['event']['seq']==i
  aid=e['event']['attempt_id'];r=state['attempts'][aid];assert r['status']==e['event']['status'] and r['request_hash']==e['event']['request_hash']
  assert r['inventory_before']==balance
  for c in e['event']['consumed']:
   assert c['source_page_id']==orig[c['lot_id']]['source_page_id'] and c['unit']==orig[c['lot_id']]['unit']
   balance[c['lot_id']]-=c['quantity'];assert balance[c['lot_id']]>=0
  assert r['inventory_after']==balance
  prev=e['hash']
 assert state['head_hash']==prev and len(state['events'])==3
 assert {k:v['quantity'] for k,v in state['lots'].items()}==balance
 ret={'snapshot_sha256':ss_sha,'head_sha256':prev,'independent_event_replay': 'PASS','verified_events':3,'cases_native':sources,'linked_auxiliary_sheets':sheets,
 'native_gap':{'pass':'500g debitados; 250g produto por fixture; 250g demais frações somente em sidecar externo',
               'fail_qa':'500g debitados; rejeito nativo conta 1 unidade, sem decomposicao em gramas',
               'precheck':'0g consumidos'},
 'gate_effect':'R44 transacao e hashes PASS; rastreabilidade material integral do lote nao e provada pelo ledger nativo; sidecar conserva balanco aritmetico TEST sem identidade de residuos persistidos como estoque'}
 put('outputs/FC20_reconciliacao_R44_somente_leitura.json',ret);return ret

def recipe_b30_16():
 # A candidate experimental *dry blend*, not fired ceramic, not a new canon resource.
 return {'namespace':'SBX-CRAFT-R44-I0016','status':'EXPERIMENTAL_DESIGN_ONLY',
  'key':'SBX-B30-16-PREMISTURA-SECA-FC20-v1','source_page_id':SOURCE_FELD,'official_rec_id':None,'official_product_id':None,'mechanical_bonus':0,
  'name':'Pré-mistura seca de feldspato e argila, TEST, sem sinterização',
  'inputs':[{'quantity':200,'unit':'g','source_page_id':SOURCE_FELD},{'quantity':800,'unit':'g','source_page_id':SOURCE_CLAY}],
  'output':{'name':'Lote TEST de pré-mistura seca de feldspato e argila (massa final parametrizada)','quantity':1,'unit':'lote_sintetico'},
  'tools':['balanca','peneira','misturador','bandeja','controle_poeira'],
  'skills':['preparo_mineral','mistura_ceramica_nao_queimada'],
  'steps':[{'seq':i+1,'name':step,'minutes_proposed':None} for i,step in enumerate([
   'confirmar_lotes_e_fontes','inspecionar_secura_impureza_e_tara','pesar_200g_e_800g','misturar_em_equipamento_reutilizavel',
   'quantificar_residuo_e_massa_saida','verificar_QA_e_quarentena_ou_liberacao_TEST'])],
  'qa_rules':[{'field':'balance_error_g','kind':'range','min':0,'max':0},
    {'field':'output_mass_g','kind':'range','min':1,'max':1000},
    {'field':'feed_feldspar_g','kind':'range','min':200,'max':200},
    {'field':'feed_clay_g','kind':'range','min':800,'max':800},
    {'field':'dry_inputs_verified_fixture','kind':'bool_eq','value':True},
    {'field':'homogeneity_observed_fixture','kind':'bool_eq','value':True},
    {'field':'provenance_complete_fixture','kind':'bool_eq','value':True}],
  'source_urls':['https://app.notion.com/p/'+SOURCE_FELD.replace('-',''), 'https://app.notion.com/p/'+SOURCE_CLAY.replace('-','')],
  'origin':'B30-16 R42 and FC14 design; quantities are PROPOSED; fixtures synthetic; no source occurrence nor yield verified',
  'effect_scope':'somente pré-mistura seca, sem propriedades de ceramica queimada, fusao, resistencia ou rendimento prometido',
  'technical_holds':['fontes PS sem confirmaçao de forma seca e compativel','qualidade e secagem do feed desconhecidas',
   'homogeneidade final sem metodo de amostragem competente','duracao, ofício, ferramentas e economia canonica nao aferidos',
   'consumidor final e anti-duplicata de mistura comum pendentes','RC5/HOLD independentemente da execução TEST']}

def execute_b30_16(v03_path):
 assert digest_bytes(v03_path.read_bytes())==HIST_SHA
 recipe=recipe_b30_16();put('contracts/B30-16-PREMISTURA-SECA-TEST.json',recipe)
 with zipfile.ZipFile(v03_path) as z:
  raw=z.read(R44_PATH)
 with tempfile.TemporaryDirectory(prefix='fc20_r44_original_') as d:
  file=pathlib.Path(d)/'r44_original.py';file.write_bytes(raw)
  spec=importlib.util.spec_from_file_location('r44_original_fc20_read_only',file)
  mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  def lot(id,source,mass):return {'lot_id':id,'fixture_kind':'SYNTHETIC','source_page_id':source,'unit':'g','quantity':mass,'cracked':False,'delaminated':False,'contaminated':False}
  recs={recipe['key']:recipe}
  eng=mod.SandboxEngine(recs,[lot('SBX-FC20-FELD-A',SOURCE_FELD,200),lot('SBX-FC20-CLAY-A',SOURCE_CLAY,800),lot('SBX-FC20-FELD-B',SOURCE_FELD,200),lot('SBX-FC20-CLAY-B',SOURCE_CLAY,800)])
  ok={'balance_error_g':0,'output_mass_g':970,'feed_feldspar_g':200,'feed_clay_g':800,
      'dry_inputs_verified_fixture':True,'homogeneity_observed_fixture':True,'provenance_complete_fixture':True}
  before={k:v['quantity'] for k,v in eng.state['lots'].items()}
  passed=eng.run(recipe['key'],'SBX-FC20-B30-16-SUCCESS',['SBX-FC20-FELD-A','SBX-FC20-CLAY-A'],ok,recipe['tools'],recipe['skills'])
  replay=eng.run(recipe['key'],'SBX-FC20-B30-16-SUCCESS',['SBX-FC20-FELD-A','SBX-FC20-CLAY-A'],ok,recipe['tools'],recipe['skills'])
  assert passed['status']=='EXPERIMENTAL_QA_PASS' and replay['idempotent_replay']
  bad={**ok,'homogeneity_observed_fixture':False}
  rejected=eng.run(recipe['key'],'SBX-FC20-B30-16-HETEROGENEOUS',['SBX-FC20-FELD-B','SBX-FC20-CLAY-B'],bad,recipe['tools'],recipe['skills'])
  assert rejected['status']=='REJECTED_QUALITY' and not rejected['products']
  assert all(v['quantity']==0 for v in eng.state['lots'].values())
  report={'original_r44_module_sha256':digest_bytes(raw),'recipe_sha256':digest(recipe),'historic_v03_zip_sha256':HIST_SHA,
   'snapshot_scope':'SEPARATE_FC20_SANDBOX_NOT_R44_HISTORIC','original_lots':before,'cases':[passed,rejected],
   'idempotent_replay':{'idempotent':replay['idempotent_replay'],'products':len(replay['products'])},
   'external_mass_sidecar':{'attempt_id':passed['attempt_id'],'receipt_sha256':digest(passed),
     'synthetic_in_g':1000,'synthetic_out_g':970,'synthetic_residue_g':30,
     'balance_g':0,'status':'AUXILIARY_TEST_NOT_NATIVE_LEDGER_OR_PHYSICAL'},
   'negative_case_warning':'A QA negativa consome 1000g TEST e R44 gera 2 unidades de scrap; não existe rastreio de massa dos rejeitos no ledger nativo',
   'limits':['no valid RPG occurrence or qualified feed proved','R44 does not ledger final grams or 30g residues natively',
    'no sampling method for homogeneity certified','does not prove final constituent fraction after loss',
    'TEST success does not imply RC5']}
  audit=eng.audit();assert audit['ok'] and audit['verified_events']==2
  report['engine_audit']=audit
  snap=ROOT/'outputs/FC20_B30_16_new_sandbox_snapshot.json';report['snapshot_integrity_sha256']=eng.export_snapshot(snap)
  restored=mod.SandboxEngine.restore(recs,snap)
  assert restored.audit()==audit
  report['restart_pass']=True
  put('outputs/FC20_B30_16_new_sandbox_receipt.json',report)
  return report

def main():
 a=argparse.ArgumentParser();a.add_argument('--fc18-root',required=True);a.add_argument('--fc18-zip',required=True);a.add_argument('--v03',required=True);args=a.parse_args()
 fc18=pathlib.Path(args.fc18_root);pack=pathlib.Path(args.fc18_zip);v03=pathlib.Path(args.v03)
 assert digest_bytes(pack.read_bytes())==FC18_SHA,'FC18_BASELINE_HASH'
 # minimum check of manifest without rewriting it; report sha and R44 status
 d=audit_fc10(fc18);t=execute_b30_16(v03)
 print(json.dumps({'archived_fc18_sha256':FC18_SHA,'fc10_events_audited':d['verified_events'],
                   'fc10_head':d['head_sha256'],'b30_16_new_test':t['cases'][0]['status'],
                   'b30_16_new_head':t['engine_audit']['head_hash'],'b30_16_restart':t['restart_pass']}))
if __name__=='__main__':main()
