#!/usr/bin/env python3
"""Independent readback for CRAFT FC19-21. Check raw bytes/events, do not trust engine ok flags."""
import hashlib,json,pathlib,sys
R=pathlib.Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text(encoding='utf-8'))
def sha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def verify_snapshot(wrapper):
 s=dict(wrapper);tag=s.pop('integrity_sha256')
 assert sha(s)==tag,'wrapper checksum mismatch'
 init=s['initial_lots'];assert sha(init)==s['initial_hash']
 observed={k:v['quantity'] for k,v in init.items()}
 prev=hashlib.sha256(b'SBX-CRAFT-R44-I0016|GENESIS-v1').hexdigest()
 for i,ev in enumerate(s['state']['events'],1):
  body=ev['event'];assert body['seq']==i
  assert ev['previous_hash']==prev and sha({'previous_hash':prev,'event':body})==ev['hash']
  r=s['state']['attempts'][body['attempt_id']]
  assert r['request_hash']==body['request_hash'] and r['status']==body['status']
  assert r['inventory_before']==observed
  assert r['consumed']==body['consumed'] and r['products']==body['products'] and r['scrap']==body['scrap']
  for c in body['consumed']:
   assert c['source_page_id']==init[c['lot_id']]['source_page_id']
   assert c['unit']==init[c['lot_id']]['unit']
   observed[c['lot_id']]-=c['quantity'];assert observed[c['lot_id']]>=0
  assert r['inventory_after']==observed
  prev=ev['hash']
 assert prev==s['state']['head_hash']
 assert observed=={k:v['quantity'] for k,v in s['state']['lots'].items()}
 return len(s['state']['events']),prev

def verify():
 old=load('outputs/FC20_reconciliacao_R44_somente_leitura.json')
 assert old['independent_event_replay']=='PASS' and len(old['cases_native'])==3
 assert [e['native_g_consumed'] for e in old['cases_native']]==[500,0,500]
 for item in old['linked_auxiliary_sheets']:
  f=item['external_synthetic_sheet'];assert f['feed_g']==sum(f[k] for k in ('accepted_grade_g','coarse_g','fines_g','impurities_g','water_evaporated_g','dust_and_loss_g'))
  assert sha(f)==item['external_sheet_sha256']
 new=load('outputs/FC20_B30_16_new_sandbox_receipt.json')
 assert 'official_materialization' not in new or new['official_materialization'] is False
 assert all(c['simulation_only'] is True and c['official_rec_id'] is None for c in new['cases'])
 assert new['original_r44_module_sha256']=='64520be11e8148c54fe6eaabb2bd2338c143273ae7d03ae064c3a0d8e9603f27'
 n,head=verify_snapshot(load('outputs/FC20_B30_16_new_sandbox_snapshot.json'))
 assert n==2 and head==new['engine_audit']['head_hash']
 cases=new['cases'];assert len(cases)==2
 assert [c['status'] for c in cases]==['EXPERIMENTAL_QA_PASS','REJECTED_QUALITY']
 for c in cases:
  assert sum(z['quantity'] for z in c['consumed'])==1000
  assert {z['source_page_id'] for z in c['consumed']}=={'3f3c2b32-4ede-81a2-a590-c53273f9e6e5','3f3c2b32-4ede-81b8-b187-f217b20c6bdb'}
 assert len(cases[0]['products'])==1 and cases[1]['products']==[]
 assert new['external_mass_sidecar']['receipt_sha256']==sha(cases[0])
 assert new['external_mass_sidecar']['synthetic_in_g']==new['external_mass_sidecar']['synthetic_out_g']+new['external_mass_sidecar']['synthetic_residue_g']
 # Challenge the verifier's event binding, not the precomputed 'ok' field.
 tampered=load('outputs/FC20_B30_16_new_sandbox_snapshot.json')
 tampered['state']['events'][0]['event']['consumed'][0]['quantity']+=1
 caught=False
 try:verify_snapshot(tampered)
 except AssertionError:caught=True
 assert caught,'tampered event accepted'
 gate=load('outputs/FC20_RC5_gate_matrix.json')
 assert len(gate['statuses'])==4 and all(not x['technical_eligible_RC5'] for x in gate['statuses'])
 publication=load('outputs/FC21_publication_write_set_DISABLED.json')
 assert not publication['allowed_to_write'] and publication['official_rec_id'] is None
 checkpoint=load('outputs/FC21_checkpoint_succession.json')
 assert checkpoint['denominators']['rc5_official_id']==0 and checkpoint['denominators']['historical_PS_sources']==30
 return {'fc10_old_event_count_audited':3,'new_R44_event_count_readback':n,'new_R44_final_head':head,
         'source_integrity':'PASS','adversarial_tamper_rejected':caught,'material_fraction_sidecar':'AUXILIARY_NOT_NATIVE',
         'new_rc5_claims':0,'writes':0,'result':'PASS_PROPORTIONAL_TEST_AND_READONLY'}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,sort_keys=True))
