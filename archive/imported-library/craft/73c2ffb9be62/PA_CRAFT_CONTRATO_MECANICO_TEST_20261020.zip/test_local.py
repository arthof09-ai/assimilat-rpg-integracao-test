import unittest,hashlib,json,tempfile,zipfile
from pathlib import Path
from parse_mechanics import extract_one,load_r42,R42_SHA
from causal_qa import Observation,adjudicate,AdmissibilityError
R42='/mnt/data/PA_Sucessao/PA_R42_CLASSIFICADOR_FENCE_R48_TEST_20261020.zip'
def mk(s):return dict(opaque_id='opaque',mechanics_text=s,mechanics_sha256=hashlib.sha256(s.encode()).hexdigest())
def obs(arm='C1',v=1,d=1,kind='SYNTHETIC',wit=None,sha=None):
    f={'C0':(False,False,False),'C1':(True,False,False),'C2':(True,True,False),'C3':(False,True,True)}[arm]
    return Observation(arm,*f,v,d,wit,sha,kind)
class Parser(unittest.TestCase):
    def test_original_sha(self):self.assertEqual(hashlib.sha256(Path(R42).read_bytes()).hexdigest(),R42_SHA)
    def test_12_corpus(self):self.assertEqual(len(load_r42(R42)),12)
    def test_no_rank(self):self.assertTrue(all(x['computed_rank'] is None for x in load_r42(R42)))
    def test_one_cost(self):self.assertEqual(extract_one(mk('Ativa por 60 PA.'))['explicit_PA_activation'],60)
    def test_no_invented_cost(self):self.assertIsNone(extract_one(mk('causa dano colossal'))['explicit_PA_activation'])
    def test_positive_mod(self):self.assertEqual(extract_one(mk('recebe +18 na salvaguarda'))['explicit_unsigned_modifier'],[18])
    def test_dice(self):self.assertEqual(extract_one(mk('causa 2d8 de dano'))['explicit_damage_dice'],['2d8'])
    def test_no_dice_from_adjective(self):self.assertIsNone(extract_one(mk('causa dano massivo'))['explicit_damage_dice'])
    def test_numeric_duration(self):self.assertEqual(extract_one(mk('até sete dias ou 7 turnos'))['explicit_duration_count'],[7,7])
    def test_source_hash(self):
        bad=mk('aura elétrica');bad['mechanics_sha256']='a'*64
        with self.assertRaises(ValueError):extract_one(bad)
    def test_no_gold_in_results(self):self.assertFalse(any('rank_pattern_e0' in d or 'historical_rank' in d for d in load_r42(R42)))
class Gate(unittest.TestCase):
    def test_empty(self):self.assertEqual(adjudicate([])['rc5'],'HOLD')
    def test_synthetic_not_magic(self):self.assertEqual(adjudicate([obs('C0',0),obs('C1',50),obs('C2',90),obs('C3',90)])['own_pattern_effect'],'NOT_DEMONSTRATED')
    def test_missing_arm(self):self.assertEqual(adjudicate([obs('C1')])['reason'],'REAL_REPLICATES_AND_DISTINCT_WITNESSES_REQUIRED')
    def test_malformed_arm(self):
        a=obs('C1');a=Observation(a.arm,False,False,False,1,2,None,None,'TEST')
        with self.assertRaises(AdmissibilityError):adjudicate([a])
    def test_negative_signal(self):
        with self.assertRaises(AdmissibilityError):adjudicate([obs(v=-2)])
    def test_unwitnessed_real(self):
        with self.assertRaises(AdmissibilityError):adjudicate([obs(kind='REAL')])
    def test_synthetic_fake_witness(self):
        with self.assertRaises(AdmissibilityError):adjudicate([obs(wit='Mestre')])
    def test_single_witness_repetition(self):
        a=[obs(arm,v,d,'REAL','one','0'*64) for arm in ('C0','C1','C2','C3') for v,d in [(0,0),(1,1)]]
        self.assertEqual(adjudicate(a)['rc5'],'HOLD')
    def test_witnessed_still_no_rc5(self):
        a=[obs(arm,v,d,'REAL',w,'a'*64) for arm,v,d in [('C0',0,1),('C1',4,2),('C2',4,6),('C3',9,7)] for w in ['testemunha-a','testemunha-b']]
        x=adjudicate(a)
        self.assertEqual(x['source_effect'],'CANDIDATE_DIRECTIONAL_ONLY')
        self.assertEqual(x['p2_stabilization'],'CANDIDATE_DIRECTIONAL_ONLY')
        self.assertEqual(x['own_pattern_effect'],'CANDIDATE_DIRECTIONAL_ONLY')
        self.assertEqual(x['rc5'],'HOLD')
    def test_real_negative_observations(self):
        a=[obs(arm,0,0,'REAL',w,'f'*64) for arm in ('C0','C1','C2','C3') for w in ['a','b']]
        x=adjudicate(a)
        self.assertEqual(x['own_pattern_effect'],'NOT_DEMONSTRATED')
        self.assertEqual(x['rc5'],'HOLD')
if __name__=='__main__':unittest.main()
from p2_admissibility import preflight,BOM,ENERGY_CHOICES
class P2(unittest.TestCase):
    def test_default_hold(self):self.assertFalse(preflight()['eligible_for_material_setup'])
    def test_default_no_install(self):self.assertFalse(preflight()['can_install_in_official_world'])
    def test_missing_salt_decision(self):self.assertIn('P2-SALT-01_CANONICAL_DECISION_MISSING',preflight()['blockers'])
    def test_missing_energy_step(self):self.assertIn('P2-ENERGY-02_STAGE_DECISION_MISSING',preflight()['blockers'])
    def test_missing_oil(self):self.assertIn('OIL_RECIPE_AUTHORITY_DECISION_MISSING',preflight()['blockers'])
    def test_real_ingredient_lots_must_be_traced(self):
        x=preflight(sal_decision='USAR_SANTO',energizer='Pedra da Luz',energy_stage='IN_MIX',oil_recipe_decision='OIL_BOM',operator_certified=True,material_witnesses=['a','b'],lot_inventory={})
        self.assertTrue(any(k.startswith('NO_CERTIFIED_LOT') for k in x['blockers']))
    def test_branch_changes_salt_only(self):
        a=preflight(sal_decision='USAR_SANTO')['needed_quantities'];b=preflight(sal_decision='USAR_ENCANTADO')['needed_quantities']
        self.assertIn('Sal de Geodo Santo',a);self.assertIn('Sal de Geodo Encantado',b)
        self.assertEqual(a['Óleo de Vedação'],b['Óleo de Vedação'])
    def test_either_energy_not_both(self):
        a=preflight(energizer='Pedra da Luz')['needed_quantities'];b=preflight(energizer='Pote de Essência Mágica')['needed_quantities']
        self.assertIn('Pedra da Luz',a);self.assertNotIn('Pote de Essência Mágica',a)
        self.assertIn('Pote de Essência Mágica',b);self.assertNotIn('Pedra da Luz',b)
    def test_synthetic_complete_still_no_prod(self):
        needed=preflight(sal_decision='USAR_SANTO',energizer='Pedra da Luz')['needed_quantities']
        pretend={n:{'lot_id':'FAKE-'+n,'quantity':count,'custody':'EXPERIMENTAL','authenticity_sha':'SYNTHETIC'} for n,count in needed.items()}
        x=preflight(sal_decision='USAR_SANTO',energizer='Pedra da Luz',energy_stage='IN_MIX',oil_recipe_decision='OIL_BOM',lot_inventory=pretend,operator_certified=True,material_witnesses=['a','b'])
        self.assertTrue(x['eligible_for_material_setup']);self.assertFalse(x['can_install_in_official_world'])
