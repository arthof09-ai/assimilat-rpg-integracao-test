# PA / CRAFT — Contrato de Evidência Mecânica TEST, 20/10/2026

Escopo MESTRE-SIDE / TEST. Preservados: motor PA R26/R27, CRAFT R48, receitas e fichas, Party/O Primeiro NO-WRITE. **Sem reivindicação de R44 canônico** (R43 anterior era só candidato TEST).

## ANTES e fontes
- Técnicas e Pergaminhos: https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff — 26 páginas e 26 imagens relidas, URLs assinadas 26/26; bytes importados **0/26**. Visual inaccessível ao extractor porque o link S3 Notion não é transferido em bytes pelo conector; web.open também não forneceu imagem, e runtime de código não tem DNS exterior.
- R42 original ZIP SHA256 `6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800`: 12 inscrições com texto legível, distintas das 26 habilidades em imagem.
- P2 receita: https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8. Óleo: https://app.notion.com/p/75fc2b324ede83d492f881e556dc03f8. Operação CRAFT: https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516 e IBX-116: https://app.notion.com/p/3ffc2b324ede817aa3abea3cb7ba8c08.
- Decisão oral do Mestre: os ranks históricos das 26 técnicas foram atribuídos subjetivamente a materiais genéricos externos, logo NÃO são gabarito mecânico canônico.

## DEPOIS — melhorias executadas
1. `parse_mechanics.py` lê apenas `MECHANICS_ONLY_R42.json` com integridade SHA da fonte e de cada texto, sem acessar `GOLD_R42_SEPARATE.json`. Sinais temáticos **heurísticos**; RE/rank não inferidos automaticamente. Em 12 inscrições: **1** custo PA explícito, **1** bônus numérico, **1** duração cuantificada, **0** danos em dados; **12/12** abstenções fundamentadas para classificação não demonstrada.
2. `eval_contract.py` congela previsões antes de pontuar e separa concordância com *rank histórico* da exatidão perante *rank adjudicado conforme regra vigente*. Sem gabarito adjudicado, métrica científica `null`; sem previsão, cobertura zero e precisão `null`.
3. `BLIND_ROSTER_ONLY.json`: 26 IDs opacos sem nomes, preços, URLs de ficha ou ranks. Sem arquivos de imagem autenticados, todas as 26 entradas ficam pendentes. `ORACLE_MESTRE_ONLY.json` e construtor ficam em **outro arquivo ZIP**, Mestre-only, e jamais devem entrar no classificador. Como o mesmo assistente viu o índice histórico, só um avaliador processualmente isolado dos ranks poderá se declarar efetivamente cego.
4. `p2_admissibility.py`: admissão explícita de ramo sal, energia, etapa, receita óleo, custódia/quantidade de insumos, operador e testemunhas. Com fontes vivas atuais, o resultado real é **HOLD e nenhuma inscrição aplicada**. Casos sintéticos não habilitam produção.
5. `causal_qa.py`: controles C0 (suporte), C1 (fontes), C2 (fontes+P2), C3 (efeito próprio sem fontes). Exige ocorrências reais com testemunhas; dados sintéticos jamais contam como prova, nem diferenças direcionais garantem magia.
6. Nova bateria unitária **40/40 PASS**, código independente e auditável; não recontar os 563 testes históricos como novidades.

## P2 — duas decisões aguardadas; não canonizar por maioria textual
- **P2-SALT-01:** BOM e localização prescrevem **Sal de Geodo Santo**; processo prescreve **Encantado**. Candidata de menor alteração: tornar etapa 3 Santo, **PROPOSTA TEST**, não errata canônica; alternativa Encantado exige reconciliar BOM/localidade.
- **P2-ENERGY-02:** 2 Pedras da Luz **OU** 2 Potes de Essência Mágica na BOM, nenhum passo operacional correspondente. Etapa de energização durante mistura ou após aplicação são variantes TEST, ambas aguardam decisão competente.
- **Óleo:** receita BOM pede Orvalho do Amanhecer/Essência Lua Minguante, processo cita Orvalho Dragão/Essência Vórtice, passo truncado. Ficha e preço NÃO certificam lote real.
- **CRAFT RC5:** H1 fontes luminosas não demonstra H2 estabilização nem poder próprio; não há materialização/observação com controles e testemunhas suficientes. R48/Party/O Primeiro intactos.

## GATES
PASS somente fonte relida, QA de código, prevenção de vazamento de rótulo e conservação de estados. HOLD imagens 26/26 para leitura, precisão cega, rank por efeito, P2 física, óleo/lote, H2/RC5/F5 produção. Nenhum PA debitado. FIRST PENDING: exportar bytes das 26 mídias no perímetro Mestre por Notion UI ou Work Browser autorizado; executar mecânica em ambiente oculto dos labels; decisão de sal/energia/óleo por autoridade; ensaio testemunhado de C0–C3. ANTES e DEPOIS estão neste README; readback de Biblioteca e Notion serão relatados após persistência.
