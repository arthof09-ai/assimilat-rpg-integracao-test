"""Extract *explicit* mechanics from R42 inscriptions, without reading rank gold.

No inferred RE, no learned labels; unavailable quantitative fields remain null.
"""
import hashlib,json,re,zipfile
from pathlib import Path
R42_SHA='6fbaaf8b54e79d5b7e506f580b32495ee3448e5f8c13c75be224e9c9fdbe7800'
VOCAB={
 'DANO':('dano','golpe','ataque','chama','choque'),
 'DEFESA':('protege','proteção','resiste','campo de força','resistência','salvaguarda'),
 'CONTROLE':('paralisa','prende','desacelera','selad','grilhão','imobiliza','arrasta'),
 'MOBILIDADE':('agilidade','movimento','velocidade','acelera golpes'),
 'UTILIDADE':('luz','purifica','colheitas','crescimento','respirar','invisível','invisibilidade'),
 'TEMPORAL':('temporais','temporal','tempo'),
}
def extract_one(d):
    assert set(d)=={'opaque_id','mechanics_text','mechanics_sha256'}
    s=d['mechanics_text']
    if hashlib.sha256(s.encode()).hexdigest()!=d['mechanics_sha256']:raise ValueError('source content hash mismatch')
    low=s.lower()
    cost=re.search(r'\b(\d+)\s*pa\b',low)
    modifier=re.findall(r'(?<!\w)\+\s*(\d+)\b',s)
    duration=list(map(int,re.findall(r'\b(?:até\s+)?(\d+)\s+(?:dia|dias|turno|turnos|rodada|rodadas|minuto|minutos|segundo|segundos)\b',low)))
    nums={'um':1,'uma':1,'dois':2,'duas':2,'três':3,'quatro':4,'cinco':5,'seis':6,'sete':7,'oito':8,'nove':9,'dez':10,'onze':11,'doze':12}
    duration += [nums[n] for n in re.findall(r'\b(um|uma|dois|duas|três|quatro|cinco|seis|sete|oito|nove|dez|onze|doze)\s+(?:dia|dias|turno|turnos|rodada|rodadas|minuto|minutos|segundo|segundos)\b',low)]
    dice=re.findall(r'\b\d+[dD]\d+\b',s)
    metric_range=re.findall(r'\b\d+(?:[.,]\d+)?\s*(?:m|metros)\b',low)
    signals=sorted(k for k,terms in VOCAB.items() if any(t in low for t in terms))
    # Objective coverage indicators, not presumption of sufficiency or of a rank.
    return {'opaque_id':d['opaque_id'],'mechanics_sha256':d['mechanics_sha256'],
      'explicit_PA_activation':int(cost.group(1)) if cost else None,
      'explicit_unsigned_modifier':list(map(int,modifier)) or None,
      'explicit_duration_count':sorted(duration) or None,
      'explicit_damage_dice':dice or None,
      'explicit_range_m':metric_range or None,
      'textual_effect_signals':signals,
      'qualitative_effects_need_review':True,'component_RE':None,'computed_PA':None,
      'computed_rank':None,'classification_decision':'ABSTAIN_INSUFFICIENT_MECHANICAL_PARAMETERS',
      'missing':'Damage/defense magnitudes, target caps, range, trigger, duration or action economy must be corroborated effect-by-effect.'}
def load_r42(path):
    b=Path(path).read_bytes()
    if hashlib.sha256(b).hexdigest()!=R42_SHA:raise ValueError('wrong source R42 SHA')
    with zipfile.ZipFile(path) as z:
      if z.testzip() is not None:raise ValueError('source CRC')
      rows=json.loads(z.read('MECHANICS_ONLY_R42.json'))
    if len(rows)!=12 or len(set(d['opaque_id'] for d in rows))!=12:raise ValueError('denominator/identity')
    return [extract_one(x) for x in rows]
if __name__=='__main__':
 import sys
 d=load_r42(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps({'n':len(d),'source':'R42 MECHANICS_ONLY original, no gold','items':d},indent=2,ensure_ascii=False))
 print(json.dumps({'n':len(d),'no_rank_claims':sum(x['computed_rank'] is None for x in d),'explicit_costs':sum(x['explicit_PA_activation'] is not None for x in d),'explicit_dice':sum(x['explicit_damage_dice'] is not None for x in d),'total_missing_evidence':sum(x['classification_decision'].startswith('ABSTAIN') for x in d)}))
