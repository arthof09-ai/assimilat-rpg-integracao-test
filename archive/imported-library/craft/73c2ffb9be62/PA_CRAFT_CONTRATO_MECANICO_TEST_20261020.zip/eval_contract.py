"""Prospective rank evaluation with noisy legacy labels, authority labels kept separate.

Only authoritative scientific adjudication (not old Notion label) is a ground truth.
Missing adjudication -> NULL, not wrong.
"""
import hashlib,json
from pathlib import Path
RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário')
class BenchmarkError(ValueError):pass

def canonical(obj):return json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def digest(obj):return hashlib.sha256(canonical(obj)).hexdigest()
def freeze_prediction(path, predictions):
    if not predictions: raise BenchmarkError('missing predictions')
    if len(set(x.get('opaque_id') for x in predictions))!=len(predictions):raise BenchmarkError('duplicate identities')
    for row in predictions:
        if set(row)-{'opaque_id','computed_rank','evidence_sha256','explanation','classification_state'}:
            raise BenchmarkError('leaked legacy/gold/private data in prediction')
        if row.get('computed_rank') not in (*RANKS,None):raise BenchmarkError('invalid rank')
        if not row.get('opaque_id') or not row.get('evidence_sha256'):raise BenchmarkError('mechanical source absent')
        if row.get('computed_rank') is None and row.get('classification_state')!='ABSTAIN':raise BenchmarkError('abstention must be explicit')
        if row.get('computed_rank') is not None and row.get('classification_state')!='PROPOSED':raise BenchmarkError('proposal state required')
        if not row.get('explanation'):raise BenchmarkError('rationale required')
    data={'kind':'BLIND_PREDICTION_TEST','n':len(predictions),'predictions':predictions}
    data['freeze_sha256']=digest(data)
    Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
    return data['freeze_sha256']

def evaluate_after_freeze(path, labels):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    prefix={k:v for k,v in data.items() if k!='freeze_sha256'}
    if digest(prefix)!=data.get('freeze_sha256'):raise BenchmarkError('frozen data modified')
    p=data['predictions']
    if any(x['opaque_id'] not in labels for x in p):raise BenchmarkError('unknown sample')
    predicted=[x for x in p if x['computed_rank'] in RANKS]
    eligible_legacy=[x for x in predicted if labels[x['opaque_id']].get('historical') in RANKS]
    eligible_adjudicated=[x for x in predicted if labels[x['opaque_id']].get('adjudicated') in RANKS]
    return {'records':len(p),'prediction_coverage':len(predicted),
      'historical_agreement_count':sum(x['computed_rank']==labels[x['opaque_id']]['historical'] for x in eligible_legacy),
      'historical_agreement_denominator':len(eligible_legacy),
      'historical_agreement':sum(x['computed_rank']==labels[x['opaque_id']]['historical'] for x in eligible_legacy)/len(eligible_legacy) if eligible_legacy else None,
      'authority_correct':sum(x['computed_rank']==labels[x['opaque_id']]['adjudicated'] for x in eligible_adjudicated),
      'authority_denominator':len(eligible_adjudicated),
      'authority_accuracy':sum(x['computed_rank']==labels[x['opaque_id']]['adjudicated'] for x in eligible_adjudicated)/len(eligible_adjudicated) if eligible_adjudicated else None,
      'interpretation':'Historical agreement is not scientific accuracy; adjudication required. NULL for 0 eligible.'}
