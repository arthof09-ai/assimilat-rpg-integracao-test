import unittest,tempfile,json
from pathlib import Path
from eval_contract import freeze_prediction,evaluate_after_freeze,BenchmarkError
class Evaluator(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.p=Path(self.tmp.name)/'frozen.json'
    def tearDown(self):self.tmp.cleanup()
    def row(self,rank='Prata'):return {'opaque_id':'case1','computed_rank':rank,'evidence_sha256':'abc','explanation':'Parâmetros verificados','classification_state':'ABSTAIN' if rank is None else 'PROPOSED'}
    def test_freeze_and_score_agrees_history_not_authority(self):
        freeze_prediction(self.p,[self.row()]);q=evaluate_after_freeze(self.p,{'case1':{'historical':'Prata','adjudicated':'Ouro'}})
        self.assertEqual(q['historical_agreement'],1.0);self.assertEqual(q['authority_accuracy'],0.)
    def test_historical_only_not_ground_truth(self):
        freeze_prediction(self.p,[self.row()]);q=evaluate_after_freeze(self.p,{'case1':{'historical':'Prata'}})
        self.assertIsNone(q['authority_accuracy']);self.assertEqual(q['authority_denominator'],0)
    def test_abstention_denominator(self):
        freeze_prediction(self.p,[self.row(None)]);q=evaluate_after_freeze(self.p,{'case1':{'historical':'Prata','adjudicated':'Prata'}})
        self.assertEqual(q['prediction_coverage'],0);self.assertIsNone(q['historical_agreement'])
    def test_legacy_leak_rejected(self):
        bad=self.row();bad['historical_rank']='Ouro'
        with self.assertRaises(BenchmarkError):freeze_prediction(self.p,[bad])
    def test_gold_leak_rejected(self):
        bad=self.row();bad['adjudicated']='Ouro'
        with self.assertRaises(BenchmarkError):freeze_prediction(self.p,[bad])
    def test_duplicate_rejected(self):
        with self.assertRaises(BenchmarkError):freeze_prediction(self.p,[self.row(),self.row()])
    def test_no_evidence_rejected(self):
        bad=self.row();bad['evidence_sha256']=None
        with self.assertRaises(BenchmarkError):freeze_prediction(self.p,[bad])
    def test_tamper(self):
        freeze_prediction(self.p,[self.row()]);self.p.write_text(self.p.read_text().replace('Prata','Ouro'))
        with self.assertRaises(BenchmarkError):evaluate_after_freeze(self.p,{'case1':{'historical':'Prata'}})
    def test_unknown_label_rejected(self):
        freeze_prediction(self.p,[self.row()]);
        with self.assertRaises(BenchmarkError):evaluate_after_freeze(self.p,{'not-case1':{}})
    def test_none_rank_requires_abstention(self):
        bad=self.row(None);bad['classification_state']='PROPOSED'
        with self.assertRaises(BenchmarkError):freeze_prediction(self.p,[bad])
