# QMC-03 — Busca específica de aprimoramentos reais

**Estado:** DOCUMENTALMENTE BLOQUEADO para item-base→aprimoramento aplicado→item posterior; **nenhum dado fictício usado para concluir o caso.**

## Evidências consultadas no Notion autorizado

1. [REC-MOD-APR-01 — Aprimoramentos](https://app.notion.com/p/3f1c2b324ede81958b48da97806423f3): módulo exige **alvo-base físico identificado, delta antes/depois, instalação, compatibilidade e linhagem**. Registra que não existe categoria Mestre-side canônica autônoma de Aprimoramentos no mapa atual; não importar conteúdo Party/legado automaticamente.
2. [REC-LIN-SUB-01](https://app.notion.com/p/3f1c2b324ede818a9e84cfeae2aa0b9b): upgrade de receita ≠ upgrade do item; item-base preservado.
3. [Aprimoramento — Índice legado](https://app.notion.com/p/27ec2b324ede82c99ecd01c8221f44ca): ancestrais observados `INVENTÁRIO` e `Catálogo`, não o índice Mestre-side atual de Itens. A existência de uma melhoria como entrada de catálogo não demonstra que foi aplicada em item-base competente.
4. [Pílula de Melhoria (Prata)](https://app.notion.com/p/3edc2b324ede81dabab7d062c302f51b) e [Pílula de Melhoria Aprimorada (Ouro)](https://app.notion.com/p/3edc2b324ede81e59a61d9b0fae8546d): duas páginas de **produtos canônicos preexistentes**, com propriedades e receitas históricas distintas. O nome “Aprimorada” sugere linhagem, mas as páginas disponíveis **não demonstram aprimoramento de uma pílula específica já existente em outra**. Não produzir uma receita derivada.
5. Busca dirigida por “APRIMORAMENTO:”, “Mira Apurada”, item-base, linhagem e páginas de armas: casos aplicados encontrados em espelhos/legados não foram importados para o escopo Mestre de autoria de itens. Nenhum desses registros permite certificação do 8º módulo sob o critério pedido.

## Verificação operacional

`item_lineage()` retorna `APRIMORAMENTO_NAO_VERIFICADO` quando há dois UUIDs distintos sem relação Mestre competente. É uma capacidade **negativa demonstrada**, não a demonstração positiva de aprimoramento aplicado.

**Para ultrapassar a barreira:** localizar (ou obter decisão canônica sobre) item-base Mestre UUID, estado antes, fonte com operação de aprimoramento efetivamente aplicada, resultado após e vínculo explícito; reabrir fonte e comparar de modo read-only. Não criar esse histórico artificialmente.
