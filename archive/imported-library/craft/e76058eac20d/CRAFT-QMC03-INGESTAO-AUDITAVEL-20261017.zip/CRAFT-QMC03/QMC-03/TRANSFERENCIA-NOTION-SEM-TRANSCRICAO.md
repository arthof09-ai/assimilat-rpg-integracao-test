# Protocolo do transporte integral de uma leitura Notion autorizada

O adaptador realiza **normalização sobre a resposta completa** de `mcp__Notion__fetch`, não um resumo humano. Na sessão ChatGPT, a chamada da ferramenta deve ser executada pelo Comestre autorizado. O corpo `structuredContent.text` é convertido para UTF8/Base64 de modo lossless antes de transferência ao laboratório. Nenhuma senha, cookie, token ou API secreta é guardada.

Este trecho é um **exemplo de comando para ambiente de orquestração que disponibilize tools.mcp__Notion__fetch**; não executável pelo Python offline:

```javascript
const result = await tools.mcp__Notion__fetch({id: UUID_OR_URL, link_id: AUTHORIZED_LINK_ID});
const raw = result.structuredContent?.text || '';
if (!raw.includes('<content>') || !raw.includes('<ancestor-path>')) throw new Error('readback incompleto');
// Codificação UTF8/Base64 lossless (sem reescrever campos), armazenar em pacote TEST.
// Confrontar com segunda chamada INDEPENDENTE antes de afirmar readback em sessão.
// O hash calculado no pacote não constitui assinatura Notion.
```

Para novas URLs, o componente **externo de leitura** ainda depende das ferramentas do chat. O interpretador local recebe `--readback-b64` + `--url` e rejeita divergências URL/UUID, superfícies fora de `Itens`, propriedades ausentes, conteúdo incompleto ou blocos desconhecidos. `as of` é versão observável devolvida, **não revision-ID**.

**Limite não resolvido:** ainda falta ponte 100% automática entre chamada da ferramenta e arquivo do sandbox, com autenticação externa ao conteúdo transferido. A QMC-03 comprova ingestão fiel de saída real e verificação de consistência, não assinatura digital/streaming nativo Notion→Python.
