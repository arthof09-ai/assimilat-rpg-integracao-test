# CRAFT QMC-03 — bancada existente ampliada, read-only

**Operação:** OP-ARQ-RIN-REC-01 / CM-000002-WS0001 / MESTRE-SIDE. **Produção:** HOLD; **novas receitas, BOMs, REC-IDs, fabricação e ativação real:** PROIBIDOS.

## O que é fisicamente reproduzível

- Subdiretório `QMC-02/` preservado byte a byte do ZIP QMC-02 original. `qmc03.py` **importa `qmc02.py`**, não é outro motor.
- `verified_transfers/*.b64`: retorno **integral** de `mcp__Notion__fetch`, convertido sem transcrever livremente os trechos por codificação UTF8/Base64. Inclui wrapper com URL, UUID, ancestral, timestamp `as of`, título, `<content>` original e imagens como referências textuais.
- `qmc03.py`: valida identidade URL/UUID, ancestral Itens Mestre, presença de propriedades/conteúdo, integridade do corpo, regras de efeitos, correspondência entre literal e extração, PA, compatibilidade, transferência e versões. Não lê a Internet diretamente nem guarda credenciais.
- `build_demonstrations.py`: produz respostas de consultas reais a partir da análise, não a partir de respostas fixas.

## Rodar em cópia limpa

A partir do diretório raiz extraído:

```bash
python -m unittest discover -s QMC-02/qmc02 -p 'test_*.py' -v
python -m unittest discover -s QMC-03 -p 'test_qmc03.py' -v
python QMC-03/build_demonstrations.py
python QMC-03/qmc03.py --readback-b64 QMC-03/verified_transfers/esmeralda_tool_response.b64 --url https://app.notion.com/p/3edc2b324ede81e28548ef18833a7078 --text
python QMC-03/qmc03.py --readback-b64 QMC-03/verified_transfers/lanca_tool_response.b64 --url https://app.notion.com/p/3edc2b324ede81ecbae3cf4b0cf274e5 --text
```

## Usar diretamente no ChatGPT do Mestre

Solicite: **“CRAFT, analise esta ficha do Notion: <URL>.”** O Comestre utiliza o conector autorizado para ler a página real, inspeciona a proveniência, entrega parecer e, se for necessário reproduzir em laboratório, transfere o retorno integral da ferramenta para a QMC-03. **O Mestre não precisa instalar nada.** Uma captura local desatualizada não substitui leitura atual autorizada.

## Fronteira de autenticidade

O formato transporta a resposta da ferramenta sem paráfrase, mas **não é assinatura digital emitida pelo Notion**. A palavra `mcp__Notion__fetch` dentro do arquivo é verificável sintaticamente, não criptograficamente. Hash local autodeclarado **NÃO** prova origem: o operador deve confrontar o arquivo com uma consulta real por ferramenta autorizada e guardar uma âncora independente. Este ambiente permite comprovar **execução real do conector neste chat**; **não** permite ao Python autenticar um token Notion ou verificar assinatura digital externa. Duas consultas iguais corroboram estabilidade da resposta obtida, mas não provam leitura do estado mais recente da página se o conector entregar um mesmo `as of` antigo.

## Outras condições

- Imagens referenciadas no Markdown não foram visualmente inspecionadas pelo executável; a regra R-IMG da PR-OBJ-01 marca a pendência.
- Aprimoramentos: não há relação Mestre com item-base→delta→item posterior autenticada dentre os casos consultados; o verificador rejeita promoção por semelhança de títulos.
- R-PA-DIA interpretada **somente** no escopo histórico estrito, quando a última linha útil for `N PA` sem gatilho textual específico. Não converter “35 de PA” ou “24 por dia” automaticamente.
- PA real: **não conectado**. O adaptador envia contrato candidato, sem algoritmo ou autorização de ativação.
- Nenhum CSV de execução do motor físico R48 foi modificado ou regenerado.
