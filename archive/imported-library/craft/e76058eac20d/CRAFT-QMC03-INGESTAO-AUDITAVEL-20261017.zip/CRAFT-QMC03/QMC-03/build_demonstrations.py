#!/usr/bin/env python3
"""Gera demonstrações diretamente da QMC-03 executada e dos extratos QMC-02 antigos."""
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import qmc03
srcs=[('Esmeralda de Energia','esmeralda_tool_response.b64','3edc2b324ede81e28548ef18833a7078'),('Lança Sopro Congelante','lanca_tool_response.b64','3edc2b324ede81ecbae3cf4b0cf274e5')]
reports={}
output=['# Consultas produzidas pelo código QMC-03','', 'Demonstração automatizada; respostas derivadas de retornos integrais do conector autorizado, preservados em UTF8/Base64. Nenhum custo inferido.','']
for name,base,uuid in srcs:
    raw=qmc03.read_b64(HERE/'verified_transfers'/base)
    p=qmc03.analyze_fetch(raw,f'https://app.notion.com/p/{uuid}')
    assert p['status']=='PARECER_EXPERIMENTAL_DO_READBACK_TRANSPORTADO',p
    reports[uuid]=p
    (HERE/f'PARECER-{uuid}.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    output+=['## Mestre: Analise '+name+'.','',qmc03.consult_qmc03(p),'']
for title,uuid,question in [
    ('Compatibilidade documentada','3edc2b324ede81e28548ef18833a7078','alimentar artefatos'),
    ('Compatibilidade condicional','3edc2b324ede81e28548ef18833a7078','alimentar este artefato específico'),
    ('Recarga indeterminada','3edc2b324ede81e28548ef18833a7078','recarregar ao amanhecer'),
    ('Bloqueio da fabricação','3edc2b324ede81ecbae3cf4b0cf274e5','fabricar nova receita'),
]:
    r=qmc03.check_compatibility(reports[uuid],question)
    output += ['## Mestre: '+question+'?','','**'+r['status']+'** — '+r['reason']+' Fonte: '+', '.join(r['sources']), '']
# Caso de matriz pré-existente na QMC-02, sem novo readback executado.
baseline=json.loads((HERE.parent/'QMC-02'/'qmc02'/'source_readbacks.json').read_text())
m=next(x for x in baseline['sources'] if x.get('family_hint')=='MATRIZ')
mi=qmc03.qmc02.inspect_source(m)
for question in ('classificar como instalação','guardar no anel dimensional como portátil'):
    r=qmc03.check_compatibility({'item':mi},question)
    output += ['## Mestre: '+question+'?','',f"**{r['status']}** — {r['reason']} Fonte: {', '.join(r['sources'])}",'']
# Histórico de dois itens reais com nome relacionado mas sem vínculo físico item-base/delta.
base={'identity':{'uuid':'3edc2b324ede81dabab7d062c302f51b','title':'Pílula de Melhoria'}}
improved={'identity':{'uuid':'3edc2b324ede81e59a61d9b0fae8546d','title':'Pílula de Melhoria Aprimorada'}}
lineage=qmc03.item_lineage(base,improved)
output += ['## Mestre: a Pílula Aprimorada é um aprimoramento instalado na Pílula base?','','**'+lineage['status']+'** — '+lineage['reason'], '', 'As duas páginas são produtos Mestre distintos; seus nomes não atestam modificação de um objeto-base. Nenhuma receita nova gerada.','']
(HERE/'DEMO-CONVERSACIONAL-GERADA.md').write_text('\n'.join(output),encoding='utf8')
(HERE/'PA-INTERFACE-2-FONTES.json').write_text(json.dumps({k:v['pa_interface'] for k,v in reports.items()},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(HERE/'COMPATIBILIDADE-RESULTADOS.json').write_text(json.dumps({'Esmeralda':{q:qmc03.check_compatibility(reports['3edc2b324ede81e28548ef18833a7078'],q) for q in ['alimentar artefatos','alimentar este artefato específico','recarregar ao amanhecer']},'Matriz':{q:qmc03.check_compatibility({'item':mi},q) for q in ('classificar como instalação','guardar no anel dimensional como portátil')},'UPGRADE':lineage},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'consultas_reais':len(srcs),'familias_novas':len({v['item']['identity']['family'] for v in reports.values()}),'compatibility_cases':6,'lineage_real_pages_compared':2,'upgrade_certified':0},ensure_ascii=False))
