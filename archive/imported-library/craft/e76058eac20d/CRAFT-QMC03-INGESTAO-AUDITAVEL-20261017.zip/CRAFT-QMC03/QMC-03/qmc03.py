#!/usr/bin/env python3
"""CRAFT QMC-03 / extensão READ-ONLY da QMC-02.

Sem acesso direto a Notion nem credenciais. Consome saída INTEGRAL de fetch autorizado,
transportada como bytes (UTF8/Base64) com duas leituras e proveniência explícita.
Um arquivo local NUNCA é autenticação criptográfica da fonte: replay contra o
conector em sessão é condição para a afirmação 'fonte conferida na sessão'.
Não fabrica, não cria receitas, não calcula custos energéticos.
"""
from __future__ import annotations
import argparse, hashlib, json, re, html, base64, sys
from pathlib import Path
from datetime import datetime
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'QMC-02'/'qmc02'))
import qmc02

VERSION='QMC-03.0-TEST'
ROOT_ITEM_URL='https://app.notion.com/p/3edc2b324ede8184b487c0735f1eabb4'
ROOT_RPG_URL='https://app.notion.com/p/181c2b324ede82278778012fb533228f'
PA_CONTRACT='CRAFT-PA-READONLY-CANDIDATE-03'
CONN='mcp__Notion__fetch'

def sha(s:str)->str:
    return hashlib.sha256(s.encode('utf8')).hexdigest()

def extract_tool_readback(result_text:str, expected_url:str|None=None)->dict:
    """Extrai sem transcrição subjetiva; guarda o retorno do conector integral.
    O wrapper sozinho pode ser forjado fora do chat: NÃO declarar autenticidade.
    """
    if not isinstance(result_text,str) or not result_text.strip():
        return {'status':'REJEITADO_RETORNO_VAZIO'}
    m=re.search(r'Here is the result of "fetch" for the Page with URL (https://app\.notion\.com/p/([a-f0-9]{32})) as of ([0-9T:.Z+\-]+):',result_text)
    p=re.search(r'<page\s+url="([^"]+)"[^>]*>',result_text)
    prop=re.search(r'<properties>\s*(\{[^\n]*\})\s*</properties>',result_text)
    content=re.search(r'<content>\n([\s\S]*?)\n</content>\s*</page>',result_text)
    ancestry=re.findall(r'<(?:parent-page|ancestor-\d+-page)\s+url="([^"]+)"\s+title="([^"]*)"\s*/>',result_text)
    if not all((m,p,prop,content,ancestry)):
        return {'status':'REJEITADO_RETORNO_INCOMPLETO', 'has_header':bool(m),'has_properties':bool(prop),'has_content':bool(content),'has_ancestry':bool(ancestry)}
    try: metadata=json.loads(prop.group(1))
    except json.JSONDecodeError:return {'status':'REJEITADO_PROPRIEDADES'}
    if m.group(1)!=p.group(1):return {'status':'REJEITADO_WRAPPER_URL_DIVERGENTE'}
    uid=qmc02.norm_id(p.group(1));
    if uid!=m.group(2):return {'status':'REJEITADO_WRAPPER_UUID_DIVERGENTE'}
    if expected_url is not None and qmc02.norm_id(expected_url)!=uid:
        return {'status':'REJEITADO_UUID_PEDIDO_DIVERGENTE'}
    if not isinstance(metadata.get('title'),str) or not metadata['title'].strip():
        return {'status':'REJEITADO_TITULO_AUSENTE'}
    ancestor_urls=[qmc02.norm_id(u) for u,_ in ancestry]
    ancestor_names=[html.unescape(n) for _,n in ancestry]
    if any('party' in name.lower() or 'primeiro' in name.lower() or 'inventário' in name.lower() or 'inventario' in name.lower() for name in ancestor_names):
        return {'status':'REJEITADO_SUPERFICIE_PARTY_OU_LEGADO','ancestors':ancestor_names}
    if (qmc02.norm_id(ROOT_ITEM_URL) not in ancestor_urls or qmc02.norm_id(ROOT_RPG_URL) not in ancestor_urls or
        not any(qmc02.norm_id(u)==qmc02.norm_id(ROOT_ITEM_URL) and n=='Itens' for u,n in ancestry) or
        not any(qmc02.norm_id(u)==qmc02.norm_id(ROOT_RPG_URL) and n=='RPG' for u,n in ancestry)):
        return {'status':'REJEITADO_NAO_COMPROVADO_ITENS_MESTRE','ancestors':ancestor_names}
    source_content=content.group(1)
    if not source_content.strip():return {'status':'REJEITADO_PAGINA_SEM_CONTEUDO'}
    if '<unknown' in source_content: return {'status':'BLOQUEADO_BLOCO_DESCONHECIDO_NA_FONTE'}
    return {'status':'READBACK_TRANSFERIDO_SEM_ATESTADO_CRIPTOGRAFICO',
            'source':{'uuid':uid,'url':p.group(1),'title':metadata['title'],'source_tool':CONN,
                      'observed_at':m.group(3),'source_surface':'MASTER_ITEMS','ancestry':ancestor_names,
                      'content':source_content,'capture_scope':'corpo <content> completo conforme saída do conector',
                      'declared_content_sha256':sha(source_content)},
            'raw_connector_response_sha256':sha(result_text),
            'content_size_chars':len(source_content),'response_size_chars':len(result_text),
            'page_version':'as-of fornecido pelo conector; não é revision-ID',
            'transport':'UTF8_BASE64_LOSSLESS',
            'provenance_limit':'Arquivo local autodescritivo não prova origem Notion nem frescor em tempo real.'}

def verify_dual_readbacks(first:str,second:str,expected_url:str)->dict:
    a=extract_tool_readback(first,expected_url);b=extract_tool_readback(second,expected_url)
    if not a['status'].startswith('READBACK_') or not b['status'].startswith('READBACK_'):
        return {'status':'REJEITADO_PAREAMENTO','first':a['status'],'second':b['status']}
    same=a['raw_connector_response_sha256']==b['raw_connector_response_sha256']
    if not same:
        return {'status':'DIVERGENCIA_ENTRE_READBACKS','uuid':a['source']['uuid'],
                'first_sha':a['raw_connector_response_sha256'],'second_sha':b['raw_connector_response_sha256'],
                'can_claim_same_revision':False,'can_claim_authenticity':False}
    return {'status':'DOIS_READBACKS_IGUAIS','uuid':a['source']['uuid'],
            'response_sha256':a['raw_connector_response_sha256'],
            'observed_at':a['source']['observed_at'],
            'verified_by_local_comparison':True,
            'can_claim_authenticity':False,
            'note':'Par de arquivos iguais não é prova independente de origem; só a chamada autorizada no chat confirma execução do conector.'}

def audit_parser_grounding(src:dict,qualified:dict)->dict:
    """Garantia negativa: o parser não pode citar valores ausentes do texto usado.
    Não prova interpretação mecânica perfeita, mas expõe evidência sem literal.
    """
    text=qmc02.plain(src['content']);unsupported=[];checked=0
    for key in ('daily','activation','ambiguous'):
        for value in qualified.get('costs',{}).get(key,[]):
            checked+=1
            if value.get('evidence','').strip() not in text:
                unsupported.append({'field':'costs.'+key,'value':value.get('value'),'literal':value.get('evidence')})
    for effect in qualified.get('effects',[]):
        checked+=1
        if effect.get('evidence','').strip() not in text:
            unsupported.append({'field':'effects','literal':effect.get('evidence')})
    for quote in qualified.get('evidence',[]):
        checked+=1
        if quote.get('literal','').strip() not in text and not any(quote.get('literal','') in s for s in text.splitlines()):
            # Algumas citações da QMC-02 são deliberadamente truncadas (prefixos).
            unsupported.append({'field':'evidence','literal':quote.get('literal')})
    return {'status':'GROUNDING_CHECK_OK' if not unsupported else 'INTERPRETACAO_SEM_EVIDENCIA_LITERAL',
            'claims_checked':checked,'unsupported':unsupported,'source_sha256':sha(src['content'])}

def analyze_fetch(raw:str, expected_url:str, second_raw:str|None=None)->dict:
    captured=extract_tool_readback(raw,expected_url)
    if not captured['status'].startswith('READBACK_'):
        return {'status':captured['status'],'capture_error':captured,'no_new_recipes':True}
    src=captured['source']; core=qmc02.inspect_source(src)
    if core.get('status')!='QUALIFICACAO_FONTE_AUTORIZADA_EM_EXTRATO':
        return {'status':'QUALIFICACAO_BLOQUEADA','capture':captured,'core_status':core,'no_new_recipes':True}
    ground=audit_parser_grounding(src,core)
    if ground['status']!='GROUNDING_CHECK_OK':
        return {'status':'BLOQUEADO_INTERPRETACAO_DIVERGENTE_DA_FONTE','discriminant':ground,'no_new_recipes':True}
    double=verify_dual_readbacks(raw,second_raw,expected_url) if second_raw is not None else {'status':'SEM_SEGUNDO_READBACK'}
    # Não promover arquivo a fonte certificada apenas por source_tool declarado.
    ans={'status':'PARECER_EXPERIMENTAL_DO_READBACK_TRANSPORTADO','QMC_VERSION':VERSION,
         'item':core,'parser_grounding':ground,'evidence':{'full_response_sha256':captured['raw_connector_response_sha256'],
            'full_content_sha256':sha(src['content']),'byte_length_utf8':len(raw.encode('utf8')),
            'observed_at':src['observed_at'],'second_readback':double,
            'origin_auth':'FERRAMENTA_NOTION_CONSULTADA_NESTE_CHAT_SE_INDEPENDENTEMENTE_COMPROVADA; ARQUIVO_LOCAL_NAO_ASSINADO',
            'image_evidence':'PENDENTE_INSPECAO_VISUAL' if re.search(r'!\[.*?\]\(',src['content']) else 'SEM_IMAGEM_NO_CORPO_LIDO'},
         'mechanical_semantics':enrich(src,core),
         'recipe_creation':'PROIBIDA','production':'HOLD','no_new_recipes':True}
    ans['pa_interface']=pa_payload(core,ans['mechanical_semantics'])
    return ans

def apply_r_pa_dia_literal(content:str)->dict:
    """PR-OBJ-01 R-PA-DIA, escopo estrito: N PA isolado no final da ficha,
    sem gatilho textual explícito. Não recalcula modelos e não converte N de PA.
    """
    txt=qmc02.plain(content)
    lines=[x.strip() for x in txt.splitlines() if x.strip()]
    if not lines:return {'status':'SEM_DADO'}
    # Somente a última linha ÚTIL da ficha (não ignora linha de inventário posterior).
    last=lines[-1]
    m=re.fullmatch(r'(\d+)\s*PA\s*[.!]?\s*',last,re.I)
    if not m:return {'status':'REGRA_NAO_APLICAVEL','note':'Não há valor isolado N PA ao fim da ficha.'}
    # Conservador: se existe gatilho próximo, exige contexto competente, em vez de forçar diário.
    if re.search(r'\b(?:ativa[çc][ãa]o|ativar|ataque|turno|habilidade|golpe|rea[çc][ãa]o)\b',txt,re.I):
        return {'status':'CONTEXTO_EXPLICITO_EXIGE_REVISAO','value':int(m.group(1)),'unit':'PENDENTE'}
    return {'status':'PA_DIA_INTERPRETADO_R_PA_DIA','value':int(m.group(1)),
            'unit':'PA/dia','source_rule':'PR-OBJ-01 §R-PA-DIA (03/10/2026)',
            'note':'Interpretação do padrão documental histórico; não é custo calculado pelo CRAFT.'}

def enrich(src:dict,core:dict)->dict:
    content=qmc02.plain(src['content']);fam=core['identity']['family'];properties=[];unknown=[]
    if fam=='ARTEFATO' and re.search(r'Armazena energia m[áa]gica',content,re.I):
        properties.append({'property':'ARMAZENAMENTO_ENERGETICO','state':'DOCUMENTADO',
          'source_quote':'Armazena energia mágica que pode ser liberada para lançar feitiços ou alimentar artefatos.',
          'scope':'capacidade descrita sem quantidade de PA, compatibilidade ou recarga do objeto'} )
    if re.search(r'at[ée] o amanhecer.*dissipad',content,re.I):
        properties.append({'property':'EXPIRACAO_NO_AMANHECER','state':'DOCUMENTADO',
          'source_quote':'A energia fica na Esmeralda até o amanhecer, depois ela é dissipada.',
          'scope':'expiração da energia, não declaração de recarga'} )
    if 'arma'==str(fam).lower() and re.search(r'\(Pass\)',content,re.I):
        properties.append({'property':'PASSIVO_DOCUMENTADO','state':'DOCUMENTADO'})
    if re.search(r'\b(?:24|\d+)\s+por\s+dia\b',content,re.I) and not re.search(r'\b(?:24|\d+)\s*PA\s*por\s*dia',content,re.I):
        unknown.append('UNIDADE_DO_VALOR_DIARIO_NAO_IDENTIFICADA_NO_TRECHO')
    if not core['costs']['daily']:unknown.append('PA_DIA_NAO_DOCUMENTADO_NESTA_FONTE')
    if not core['costs']['activation']:unknown.append('PA_ATIVACAO_NAO_DOCUMENTADO_NESTA_FONTE')
    if re.search(r'!\[.*?\]\(',src['content']):unknown.append('IMAGEM_NAO_INSPECIONADA_PELO_EXECUTAVEL')
    return {'properties':properties,'unknown':unknown,
            'r_pa_dia_scoped':apply_r_pa_dia_literal(src['content']),
            'no_inferred_costs':True}

def pa_payload(core:dict,mechanics:dict)->dict:
    i=core['identity'];c=core['costs'];p=core['provenance']
    return {'contract':PA_CONTRACT,'contract_state':'CANDIDATE_NOT_CONNECTED',
     'ITEM-ID':i['uuid'],'VERSION':p['observed_at'],'FAMILIA':i['family'],'RANK':i['rank'],
     'EFEITOS':core['effects'],'MODALIDADE':'somente modo documental explícito',
     'PA_HISTORICO':{'PA_DIA':c['daily'],'PA_ATIVACAO':c['activation'],'PA_SEM_UNIDADE':c['ambiguous'],
      'R_PA_DIA_HISTORICA':mechanics['r_pa_dia_scoped']},
     'DURACAO':'consultar evidência literal; sem inferência','CARGAS':'INDETERMINADO',
     'CONDICOES':mechanics['properties'],'INCOGNITAS':mechanics['unknown']+core['pending'],
     'PROVENIENCIA':{'url':i['url'],'as_of':p['observed_at'],'conteudo_sha256':p['content_sha256_excerpt']},
     'AUTHORITY':'Comestre PA competente ainda não integrado','PA_MODELO_ESTIMADO':None,
     'PRODUCAO':'HOLD','CRIACAO_RECEITA':'PROIBIDA'}

def check_pa_reply(reply:dict)->dict:
    if not isinstance(reply,dict):return {'status':'REJEITADO_FORMATO'}
    if reply.get('kind') in ('FIXTURE_SIMULADA','MOCK','TEST'):
        return {'status':'MOCK_NAO_OFICIAL','authorizes_cost':False,'authorizes_activation':False}
    return {'status':'CONTRATO_ENERGETICO_REAL_NAO_VALIDADO','authorizes_cost':False,'authorizes_activation':False}

def check_compatibility(source:dict,question:str)->dict:
    """Casos dirigidos a regras verificadas; não é motor universal de compatibilidade."""
    item=source.get('item',source);i=item.get('identity',{});fam=i.get('family');src=i.get('url');s=question.casefold()
    def verdict(status,reason,evidence):return {'status':status,'reason':reason,'sources':evidence,'no_new_recipes':True}
    if 'fabricar' in s or 'receita nova' in s:
        return verdict('INCOMPATIVEL_VERIFICADO','Suspensão expressa do Mestre de criar receitas e fabricar oficialmente.',['Ordem CRAFT QMC-03 / seção IV'])
    if fam=='MATRIZ' and ('portátil' in s or 'anel dimensional' in s):
        return verdict('INCOMPATIVEL_VERIFICADO','Matriz é instalação por padrão, não objeto portátil.',['https://app.notion.com/p/3f1c2b324ede819ca142cbf1eb992fac'])
    if fam=='MATRIZ' and 'classificar como instalação' in s:
        return verdict('COMPATIVEL_VERIFICADO','A classificação como instalação corresponde ao contrato, não prova instalação efetiva.',['https://app.notion.com/p/3f1c2b324ede819ca142cbf1eb992fac'])
    if fam=='ARTEFATO' and 'alimentar artefatos' in s:
        if 'ARMAZENAMENTO_ENERGETICO' in [p['property'] for p in source.get('mechanical_semantics',{}).get('properties',[])]:
            return verdict('COMPATIVEL_VERIFICADO','Fonte literalmente declara finalidade alimentar artefatos; ainda não comprova compatibilidade com um modelo particular.',[src])
    if fam=='ARTEFATO' and ('instalar' in s or 'alimentar este artefato' in s):
        return verdict('CONDICIONAL','Capacidade energética é documentada, interface/fonte do item específico não foram comprovadas.',[src,'https://app.notion.com/p/3f1c2b324ede81b48b33d0877ee107d3'])
    if fam in ('INSCRICAO_ENCANTAMENTO','INSCRICAO_BATALHA') and 'instalar em' in s:
        return verdict('CONDICIONAL','O módulo admite suportes quando compatíveis; material, geometria e processo deste alvo requerem prova.',[src,'https://app.notion.com/p/3f1c2b324ede818ab03bc749883906c6'])
    if fam=='ARTEFATO' and ('recarga' in s or 'recarregar' in s):
        return verdict('INDETERMINADO','Fonte não define recarga após dissipação; não inventar mecanismo.',[src])
    if fam=='ARMADURA' and 'rd universal' in s:
        if any(x['code']=='ARD_RD_CONDICIONAL' for x in item.get('family_checks',[])):
            return verdict('INCOMPATIVEL_VERIFICADO','RD restrita a ataques de elementais.',[src,'https://app.notion.com/p/3f1c2b324ede8116bd3cc6606a1c6687'])
    return verdict('INDETERMINADO','Não há prova competente suficiente para aprovar ou proibir o uso específico. Incerteza mantida.',[src] if src else [])

def item_lineage(base:dict,derived:dict,proof:dict|None=None)->dict:
    """Inspeção de versões SEM derivar nova receita. Título 'Aprimorada' é indício, não vínculo."""
    a=base.get('item',base).get('identity',{});b=derived.get('item',derived).get('identity',{})
    same=a.get('uuid')==b.get('uuid')
    if same:return {'status':'MESMO_ITEM_NAO_LINHAGEM','linked':False}
    if not proof or proof.get('source_scope')!='MASTER_ITEMS' or proof.get('base_uuid')!=a.get('uuid') or proof.get('derived_uuid')!=b.get('uuid') or not proof.get('literal_relation'):
        return {'status':'APRIMORAMENTO_NAO_VERIFICADO','linked':False,'base_uuid':a.get('uuid'),
                'target_uuid':b.get('uuid'),'reason':'Nomes, níveis ou semelhança funcional não bastam; faltam item-base e delta ligados por fonte Mestre.',
                'could_compare_as_two_items':True,'no_new_recipes':True}
    return {'status':'VINCULO_DECLARADO_PENDENTE_CONFIRMAR_AUTENTICIDADE_DO_DOCUMENTO','linked':False,'no_new_recipes':True}

def read_b64(path:Path)->str:
    return base64.b64decode(path.read_text(encoding='ascii').strip(),validate=True).decode('utf8')

def consult_qmc03(result:dict)->str:
    """Texto diretamente gerado do parecer real, sem geração de novos itens."""
    if result.get('status')!='PARECER_EXPERIMENTAL_DO_READBACK_TRANSPORTADO':
        return 'INSPEÇÃO BLOQUEADA: '+str(result.get('status'))
    i=result['item']['identity'];p=result['pa_interface'];parts=result['mechanical_semantics']['properties']
    cd=p['PA_HISTORICO']['PA_DIA'];ca=p['PA_HISTORICO']['PA_ATIVACAO']
    def fmt(x):return ', '.join(f"{a['value']} {a['unit']}" for a in x) if x else 'PENDENTE'
    return (f"**{i['title']}** — {i['family']} / {i['rank']} ({i['module']})\n"
        f"Fonte Mestre: {i['url']} (retorno do conector as-of {result['evidence']['observed_at']}). "
        "Transferência do corpo integral analisada; arquivo local sem assinatura externa.\n"
        f"PA/dia documentado: {fmt(cd)}; PA por ativação: {fmt(ca)}. "
        f"R-PA-DIA: {result['mechanical_semantics']['r_pa_dia_scoped']['status']}.\n"
        f"Propriedades confirmadas neste recorte: " + ('; '.join(x.get('property','') for x in parts) if parts else 'consultar efeitos literais').strip() + '\n'
        f"Pendências: {', '.join(result['mechanical_semantics']['unknown']) or 'nenhuma listada'}.\n"
        "Parecer: qualificação documental experimental; sem certificação energética ou de fabricação; receitas novas PROIBIDAS, produção HOLD.")

def main():
    ap=argparse.ArgumentParser(description='QMC-03 — camada de ingestão sobre QMC-02')
    ap.add_argument('--readback-b64',required=True)
    ap.add_argument('--url',required=True)
    ap.add_argument('--second-readback-b64')
    ap.add_argument('--out')
    ap.add_argument('--text',action='store_true',help='Emitir resposta conversacional gerada do parecer')
    a=ap.parse_args()
    raw=read_b64(Path(a.readback_b64));b=read_b64(Path(a.second_readback_b64)) if a.second_readback_b64 else None
    ans=analyze_fetch(raw,a.url,b)
    serialized=consult_qmc03(ans) if a.text else json.dumps(ans,ensure_ascii=False,indent=2)
    if a.out:Path(a.out).write_text(serialized+'\n',encoding='utf8')
    print(serialized)

if __name__=='__main__':main()

def verify_against_session_anchor(raw:str, trusted_response_sha256:str)->dict:
    """Detecção de tamper pós-exportação contra hash fixado ANTES da alteração.
    A âncora precisa vir de comparação independente com o conector; se o atacante
    controla a âncora, a verificação local não prova autenticidade de origem.
    """
    actual=sha(raw)
    return {'status':'MATCH_ANCHOR_LOCAL' if actual==trusted_response_sha256 else 'REJEITADO_RESPONSABILIDADE_TRANSFERENCIA',
            'actual_sha256':actual,'pinned_sha256':trusted_response_sha256,
            'note':'Âncora local não assinada; autenticidade externa requer readback Notion independente em sessão.'}
