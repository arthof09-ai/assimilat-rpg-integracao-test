"""Independent integrity and causal replay gate for FC08 (stdlib only)."""
from pathlib import Path
import hashlib, json, subprocess, sys
ROOT=Path(__file__).resolve().parent
MAN=json.loads((ROOT/'MANIFEST_SHA256.json').read_text(encoding='utf8'))
errors=[]
for relative,entry in MAN['files'].items():
    p=(ROOT/relative).resolve()
    if not p.is_relative_to(ROOT.resolve()) or not p.is_file():
        errors.append(f'missing/unsafe: {relative}');continue
    data=p.read_bytes()
    if hashlib.sha256(data).hexdigest()!=entry['sha256'] or len(data)!=entry['bytes']:
        errors.append(f'bad content: {relative}')
# Re-audit from raw lot witness, independently from serialized output flags.
sys.path.insert(0,str(ROOT/'code'))
from audit_process_trace import audit
w=json.loads((ROOT/'inputs/test_trace_B30_17.json').read_text())
computed=audit(w)
observed=json.loads((ROOT/'outputs/causal_trace_audit.json').read_text())
if computed!=observed:errors.append('causal process replay diverged')
if sum(map(float,computed['final_bins_g'].values()))!=150: errors.append('mass not conserved')
if computed['final_bins_g']['fine']!='75.000' or computed['rc5_granted']:
    errors.append('incorrect synthetic acceptance/mass')
r=subprocess.run([sys.executable,str(ROOT/'code/test_causal_trace.py')],capture_output=True,text=True,cwd=ROOT)
if r.returncode:errors.append('new regression execution failed: '+r.stderr[:500])
else:
    tests=json.loads(r.stdout)
    ref=json.loads((ROOT/'outputs/new_focused_tests.json').read_text())
    if tests!=ref or tests['passed']!=13 or tests['tested']!=13: errors.append('tests differ from stored report')
rc5=json.loads((ROOT/'outputs/rc5_admission_B30_17.json').read_text())
dry=json.loads((ROOT/'outputs/dryrun_write_set.json').read_text())
if rc5['rc5_technical'] or rc5['rc5_official'] or dry['execute'] or dry['write_count']:
    errors.append('technical or productive promotion in TEST package')
status={'schema':'FC08-INDEPENDENT-CLEAN-READBACK-v1','status':'PASS' if not errors else 'FAIL',
        'manifest_files':len(MAN['files']),'new_tests_passed':13 if not errors else None,
        'causal_ledger_replayed':True if not errors else False,
        'baseline_modified':False,'official_recipe_promoted':False,
        'errors':errors}
print(json.dumps(status,sort_keys=True,ensure_ascii=False))
if errors:sys.exit(1)
