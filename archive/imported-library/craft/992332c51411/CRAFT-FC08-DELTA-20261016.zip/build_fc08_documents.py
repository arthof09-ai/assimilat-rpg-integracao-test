from pathlib import Path
import json
P=Path(__file__).resolve().parent
OUT=P/'outputs'
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
URLS={
'B30-04':'https://app.notion.com/p/3f3c2b324ede816f9af4fdd6758bbe6c',
'B30-17':'https://app.notion.com/p/3f3c2b324ede8150939dc8e911a3c5e1',
'B30-20':'https://app.notion.com/p/3f3c2b324ede81b682edf096ae99470a',
'B30-01':'https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2',
'PR-ITEM-02':'https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4',
'PR-ECO-01':'https://app.notion.com/p/3eec2b324ede8102b3f3e6c8851ad1e7',
'REC-LIB-01':'https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702',
'PR-SC-01':'https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1'
}
lineage={
'schema':'FC08-ABRASIVE-LINEAGE-v1',
'as_of':'2026-10-16','operation':'OP-ARQ-RIN-REC-01','workspace':'MESTRE-SIDE',
'live_notion_attempt':{'outcome':'ERROR','error':'link_id must identify an eligible linked account','reopened_pages':0,'negative_search_claims':0},
'local_search_scope':[
 {'path':'BACKFILL30-CRAFT-20261014/ESPECIFICACOES-B30-01-a-B30-30.md','kind':'preserved_design_dossier','scope':'B30-01,B30-04,B30-17,B30-20; material and product designs, no physical REC-ID'},
 {'path':'CRAFT-FC07-DELTA-20261016.zip/outputs/functional_decision_matrix.json','kind':'executor_evidence','scope':'candidate lineage and earlier limited search, no authenticated base'},
 {'path':'CRAFT-COMESTRE-CHAT-v03.zip','kind':'historical_engine_corpus','scope':'textual match scan abrasiv/lapidacao/granulometria/polimento; includes experimental B30-01 abrasive as auxiliary, no authenticated fine-abrasive recipe base'}
],
'candidate_matches':[
 {'key':'PS-GRANADA','url':URLS['B30-17'],'kind':'PS_RESOURCE_NOT_RECIPE','result':'original resource lists fine grit as RC0/RC1 product concept; not existing REC-ID'},
 {'key':'PS-AREIA','url':URLS['B30-04'],'kind':'PS_RESOURCE_NOT_RECIPE','result':'coarse abrasive material and Leito design; not recipe-base'},
 {'key':'PS-ESMALTE','url':URLS['B30-20'],'kind':'PS_RESOURCE_NOT_RECIPE','result':'bio enamel and paste design; vehicle unresolved; no independent recipe-base'},
 {'key':'B30-01-E03','url':URLS['B30-01'],'kind':'DESIGN_APPLICATION_NOT_CANONICAL_MANUFACTURE','result':'historical design has physically abrasive-assisted planar finishing; no fine-grit requirement, no actual usage proven'},
 {'key':'ARCHIVAL-POWDER-NAMES','url':None,'kind':'SEARCH_HISTORY_UNVERIFIED_FUNCTION','result':'historical Notion keyword matches Pó de Meteoro/Pó de Diamante Noturno etc; names alone cannot prove abrasive role or process; not promoted as equivalences'}
],
'physical_recipe_base_ids_verified':[],
'lineage_verdict':'C_NEW_RECIPE_CANDIDATE_WITHIN_SEARCH_SCOPE_NOT_GLOBAL_ABSENCE_PROOF',
'formal_derivation':False,
'new_recipe_permitted_by_norm_in_principle':True,
'new_physical_REC_ID_now_permitted':False,
'blocking_evidence_to_finalize':['competent read-only REC-LIB and legacy embedded recipe function+version+product search when connection is eligible','source-qualified product merit and executable manufacturing/QA']
}
save('lineage_scope_and_verdict.json',lineage)
family={
'schema':'FC08-FAMILY-ABRASIVE-v1','family':'physical mineral abrasives: concepts, not physical recipe parent',
'material_identity_rule':'sieved or remilled fraction always retains the source resource CRN; B30-17 coarse fraction never becomes B30-04 sand',
'rows':[
 {'id':'B30-04','source':URLS['B30-04'],'crn':'CRAFT-F5-R01-OUT-04','raw_g_nominal_design':500,'approved_g_target_only':250,'grade_mm_proposed':'[0.20,1.00]','form':'dry loose coarse grains','process':'dry/clean/sieve/classify; milling not stipulated','function':'bulk desbaste coarse','tool':'sieve,scale,dust control proposed','hardness':'unmeasured for actual PS lot','performance':'unmeasured','lineage':'POTENTIAL_INDEPENDENT_OR_GRADED_VARIANT','quality':'sieve class grade only; no declared removal rate','independent_REC_ID':'HOLD'},
 {'id':'B30-17','source':URLS['B30-17'],'crn':'CRAFT-F5-R02-MIN-02','raw_g_nominal_design':150,'approved_g_target_only':100,'grade_mm_proposed':'[0.10,0.20)','form':'dry loose fine grains','process':'selection+controlled crushing/milling+sieve/QA; optional remill with mass ledger','function':'size-qualified fine bulk for prospective lapidação / finishing','tool':'mill,sieves,scale,lens,dust control proposed','hardness':'unmeasured for actual PS lot','performance':'no measured abrasive removal or finish','lineage':'C_NEW_RECIPE_CANDIDATE_NOT_FORMAL_DERIVATION','quality':'physical size grade if measured; no promised better polish','independent_REC_ID':'HOLD'},
 {'id':'B30-20','source':URLS['B30-20'],'crn':None, 'crn_verification':'PENDING, resource page URL known but specific CRN-ID not confirmed from currently accessible bytes','raw_g_nominal_design':50,'approved_g_target_only':None,'grade_mm_proposed':None,'form':'slurry/paste only if actual vehicle and rheology defined','process':'clean bio enamel+classify+mix with vehicle+QC; process unclosed','vehicle_design':'<=100 mL compatible existing carrier, identity/range still undefined','function':'prospective application of abrasive suspension','hardness':'unmeasured','performance':'unmeasured','lineage':'FORMULATION_BLOCKED_SOURCE_NOT_AUTOMATIC_DERIVATIVE','independent_REC_ID':'HOLD'}
],
'family_decision':'B30-04 coarse dry grade and B30-17 fine dry grade are distinct DESIGN OUTPUTS; recipe IDs separate only after existence/equivalence review and demonstrated process merit. B30-20 paste is not the same product form but currently has incomplete BOM and vehicle.',
'can_B30_17_output_be_credited_to_B30_04':'NO, source identities differ',
'physically_demonstrated_polishing_superiority':False,
'stable_knowledge_of_process_in_campaign':False
}
save('abrasive_family_matrix.json',family)
app={'schema':'FC08-APPLICATION-EVIDENCE-v1',
  'candidate':'B30-17',
  'applications':[
   {'application':'B30-01 workshop planar finishing / edge adjustment','evidence':'BACKFILL30 design dossier explicitly calls for abrasive E03 in lapidation/finishing and has 55 min proposed process; no fine grade, mineral source or official execution specified','status':'DOCUMENTED_DESIGN_USE_NOT_CANONICAL_ITEM_USE','conclusion':'B30-17 could be tried as E03 subject to substrate compatibility; cannot claim current canonical demand'},
   {'application':'PS granite source portfolio intended lapidação/finish','evidence':'PS source text recovered historically as abrasive resource/application, no actual specimen or work order','status':'PS_FUNCTION_PROPOSED','conclusion':'a targeted grade is plausible; no abrasive effect measured'},
   {'application':'canonical item with verified use of 0.10-0.20mm garnet powder','evidence':None,'status':'NOT_VERIFIED_CURRENT_SESSION','conclusion':'do not manufacture claimed source-bound canonical consumer'}
  ],'verified_current_canonical_operational_consumers':0,'conditional_design_consumers':1,
  'minimal_new_evidence':'source of actual compatible mineral finishing process or authoritatively accepted engineering finish/QA specification (not generic abrasive inference)' }
save('application_evidence.json',app)
gates=[
 ('identity/product/version','PASS_DESIGN','One PS source, dry bulk fraction, alias B30-17, no new item/REC-ID'),
 ('lineage anti-duplicate','HOLD_SOURCE','No physical base found in local corpus; live REC-LIB/embedded-function search unavailable; C candidate-new not absolute novelty'),
 ('BOM units roles','PASS_PROPOSED','150 g PS feed; reusable tools (mill/sieves/scale/dust capture) not consumables; no carrier'),
 ('BOM_process_reconciliation','PASS_TEST_ONLY','Each processing event accounts material, source and batch; new 13 directed causal checks'),
 ('intermediates and mass conservation','PASS_TEST_ONLY','fine/coarse/outgrade/quarantine/loss separated incl remill, no double-count'),
 ('batch yield','PASS_MODEL_HOLD_DATA','q_m=m_fine_approved/m_feed; actual q_m unknown; synthetic 75/150 is not observed'),
 ('time conditions','HOLD_SOURCE_OR_DECISION','dry handling and dust control proposed; time t_setup + sum(t_process) + t_QA must be sourced or competent scope-design adopted before RC4'),
 ('tools specialist energy','HOLD_SOURCE','generic equipment/qualified mineral preparator described but no verified in-world capability, availability, or energy use'),
 ('success failure and risks','PASS_DESIGN_HOLD_MATERIAL','zero output if no fine fraction or contamination unresolved; dust and contact risk; actual failure distribution unknown'),
 ('effect QA law power','HOLD_MATERIAL','only particle-size grade testable in specification; no physical PSD, efficacy or substrate compatibility; no magical effect, rank by effect N/A'),
 ('PR-ECO/Anexo C','HOLD_APPLICABLE','CTE tree itemized; actual feed cost, time, equipment, usable yield, market/epoch missing; no price MED'),
 ('knowledge and Party','PASS_SEPARATION_HOLD_AUTHORITY','method described Mestre-side; no historical artisan known or Party discovery; in-game use DENY'),
 ('PS dependency/JIT','HOLD_CONTEXT','PS resource identity existing; availability, procurement and JIT before material consequence not proven'),
 ('REC-LIB parent/write','HOLD_PRODUCTIVE','physical destination not proven, writer/fencing/UNKNOWN_EFFECT prevents official writes')
]
rc5={'schema':'FC08-RC5-TECHNICAL-ADMISSION-v1','candidate':'B30-17','source':URLS['B30-17'],
'origin_authority':'PS/HISTORICAL_READ; not live re-fetched in FC08',
'recipe_design_identity':'Granada Calibrada para Lapidação (alias histórico) — nome técnico proposto: fração fina de Granada Abrasiva de Escarpa classificada a seco',
'family_lineage':'POTENTIAL_FIRST_GENERATION_RECIPE; physical base not established, formal derivation not asserted',
'product_form':'loose dry abrasive grade measured by sieve, no bag/container as hidden BOM and no magical/performance claims',
'bom':{'M01':{'crn':'CRAFT-F5-R02-MIN-02','quantity_g':'150 PROPOSED','role':'mineral source','actual_availability':'UNKNOWN'},'EQUIPMENT':['mill','graduated sieves','scale','suitable dust control','hand lens'], 'process_materials_not_on_BOM':[]},
'process':['source check and weigh','contaminant sort/quarantine','dry mill with loss recorded','sieve; record fine/coarse/outgrade/discard','optional controlled remill of coarse without changing CRN and with new time/energy/loss','QA grade+contamination+batch-source; no released fine if nonPASS','release approved bulk fraction or zero; report residue fractions and store dry'],
'product_QA':{'size_mm':'[0.10,0.20) PROPOSED','acceptance':'measured lot-size and contamination QA when eventually possible; TEST report alone not proof','stop':'no approved fine mass -> no unit; feed under seal unknown -> QUARANTINE'},
'yield_model':{'mass_yield_q':'m_approved_fine / m_feed, both same mass unit, if input>0','batch_success_p':'number of independent batches meeting declared QA / independent batches attempted, distinct statistic, actual unknown','unit':'gram approved fine fraction','historical_100g':'design target only, not guaranteed','test_example':'75/150=0.5 TEST_SYNTHETIC, not actual q'},
'engineering_not_demonstrated':['fraction distribution in an RPG lot','sieve/calibration in the RPG','granada PS natural hardness and contaminant profile','suitable in-world mineral preparer and equipment','time or lawful productive conditions','finite economic CTE','actual abrasive effectiveness for stone finish','authoritative uniqueness of recipe'],
'CTE':{'formula':'CI+CP+CF+CT+CE+CK+CL+CA+CC','unit':'gram approved fine grade','numerical_cost':'NOT_COMPUTABLE','per_gram':'CTE_batch / m_fine_approved if m_fine_approved>0; otherwise INDEFINITE','no_double_count':'CI includes feed value; CP/CF cover incremental processing, disposal, replacement needs without counting identical feed twice','scenario_favorable':'one batch yields QA-passing fine fraction, proposed','scenario_normal':'controlled regrind, additional labour/energy and per-step mass losses, proposed','scenario_adverse':'no accepted output; sunk costs registered, unit cost undefined, proposed'},
'gates':[{'requirement':x,'status':s,'reason':v} for x,s,v in gates],
'prior_fc07_correction':'absence of verified recipe-base is not itself a blocking norm for a truly new formula; require proportional anti-duplicate comparison before physical REC-ID',
'verdict':'RC5-CONDICIONAL__NOT_READY__NOT_OFFICIALLY_ADMISSIBLE',
'minimal_scientific_blockers':['accepted nonmagical fine grade and process/QA as technical effect, with competent evidence or explicit scoped authorial design acceptance','recover authoritative function+version search of existing recipes; choose independent/variant with real key','source-qualified process capability: operator/tool/time/safety and actual or authorized-conditional batch acceptance','economy cost basis/UTE appropriate to evaluable item, keeping unknown MED distinct'],
'publication':'HOLD RED/writer/fencing/C19/REC-LIB/NAC-PASS, independently of technical verdict',
'in_game_creation':'DENY pending JIT/proven materials, knowledge and authority',
'rc5_technical':False,'rc5_official':False}
save('rc5_admission_B30_17.json',rc5)
dry={'schema':'FC08-DRYRUN-MINIMAL-WRITESET-v1','execute':False,'effect':'ZERO','dedupe_key':'resource_CRN + output_grade + process_version + product_target',
'authoritative_keys_to_recheck':{'recipe_source':'REC-LIB-01','product':'product ID, query exact function+version','resource':URLS['B30-17']},
'conditional_actions_if_and_only_if_all_gates_GREEN':[
 'READ competent REC-LIB and embedded recipe index by function/version; if matched, update existing physical recipe with version lineage, never duplicate',
 'READ destination parent and writer lease/epoch fenced from C19; verify unknown effect and safe point, NAC-CONT before',
 'RESERVE one unique physical REC-ID only after RC5 technical acceptance; do not derive ID from DESIGN-ID',
 'CREATE OR LINK exactly one qualified Mestre-side recipe with product target + approved source references; no synthetic stock credit',
 'ATTACH mentions from PS resource to recipe, recipe to item-model and backwards, respecting canonical location and knowledge secrecy',
 'REOPEN all affected IDs, verify hashes/links/rights, AFTER record and NAC-PASS'
],
'write_count':0,'dependencies_for_execution':['RC5_READY','REC_LIB_VALID_PARENT','F5_MATERIAL_GREEN','C19_UNKNOWN_EFFECT_RESOLVED','IBX38_FENCING_CONFIRMED','VALID_WRITER_LEASE','NAC_PASS_PROPORTIONAL']}
save('dryrun_write_set.json',dry)
checkpoint={'schema':'FC08-SUCCESSION-v1','operation':'CM-000002 / WS0001 / OP-ARQ-RIN-REC-01','as_of':'2026-10-16',
'baseline':'R01-R51, FC01-FC07 preserved, no writers','last_verified_unit':'FC08/outputs/causal_trace_audit.json verified from events in inputs/test_trace_B30_17.json; 13/13 directed new tests, and FC07 11/11 files / 17/17 historic tests read back',
'first_pending':'competent live REC-LIB-01 and embedded formula search by function to determine actual lineage; no historical base required by rule to be a new candidate',
'next_exact':'FC08/outputs/rc5_admission_B30_17.json gates lineage anti-duplicate and process capability; stop if connector unavailable and shift to another candidate',
'official_counters':{'ps_resources_documented':'30/30','PRE_Q2':23,'PRE_Q1':7,'official_rc5_REC_IDs':'0/30','official_resources_covered':'0/30','official_products':0},
'FC08_denominators':{'focused_sources_or_designs_reviewed':4,'physical_recipe_bases_verified':0,'live_notion_pages_reopened':0,'new_tests':'13/13','candidate_gate_rows':len(gates),'candidate_technical_rc5':0,'family_comparison':'3/3 documented','lineage_verdict':'1/1 scoped but live incomplete','dry_run':'1/1 non-executed'},
'no_repeat':['do not rerun FC06 24 or FC07 17 or R44-R48 engines as routine','do not duplicate R01-R51, FC01-FC07','do not invent physical recipe base or make P4 PS','do not convert synthetic grit or mass to measured physical claim','do not resolve C19/IBX by false successor claim'],
'conflicts':['B30-17 historical name implies lapidação but demonstrated specification only size-grade classification','B30-04 and B30-17 disjoint grades but no evidence of comparative abrasive performance','B30-20 paste has no identified authorized compatible carrier or fixed amount','no live Notion access; search scope does not establish global nonexistence'],
'unknown_effect':['C19-021 persists UNKNOWN_EFFECT','FC04 orphan checkpoint untouched'],
'authority':{'F5':'RED historical','IBX38':'PENDING fencing','IBX78':'PENDING library destination','writer':'NOT_GRANTED','Notion':'ERROR link_id must identify an eligible linked account','official_write_count':0,'Party_or_OPrimeiro_writes':0},
'nac_pass_02':{'local_integrity':'PASS conditional on clean readback','technical_rc5':'HOLD','official_persistence':'HOLD','player_visibility':'NONE'},
'NEXT_5':['Recover legitimate Notion account linkage and search exact abrasive function+product+version on existing REC-LIB and embedded historic formulas','If equivalent found: preserve base ID and decide S0/S1/S2 under REC-LIN-SUB; if none, classify B30-17 as new eligible candidate without assuming global uniqueness','Qualify actual in-world grading instruments, operator skill, dry conditions, and time—or obtain scoped authoritative design acceptance, no inferred inventory','Constrain grade QA to intended mineral finishing substrate and record defensible economy with actual yield/period/market; reassess RC5','Only after all technical and F5/C19/IBX/writer/NAC gates, one idempotent official write and physical readback; otherwise move to next best PS candidate']}
save('succession_checkpoint.json',checkpoint)
print(json.dumps({'generated':['lineage_scope_and_verdict','abrasive_family_matrix','application_evidence','rc5_admission_B30_17','dryrun_write_set','succession_checkpoint'],'rc5_gate_rows':len(gates)}))
