# CRAFT FC08 — Delta aditivo / Recuperação

- Pertence exclusivamente a `CM-000002 / WS0001 / OP-ARQ-RIN-REC-01`, MESTRE-SIDE. Base FC07 ZIP SHA-256 `7e4d06823ca731c857758349d7bb8500b7484160c4a5a6195ede599b1fc96f7a`.
- **Não é** outro motor, laboratório, receita oficial, REC-ID físico nem evento de fabricação. Nenhum byte R44–R48/FC01–FC07 é substituído.
- Os documentos autorais canônicos foram recuperados em leituras anteriores; **Notion atual inacessível à instância** (`link_id must identify an eligible linked account`); todas as alegações de verdade canônica atual ficam PENDENTES quando exigem nova leitura.
- Artefatos: `outputs/lineage_scope_and_verdict.json` (busca), `outputs/abrasive_family_matrix.json` (família), `outputs/application_evidence.json` (uso), `outputs/rc5_admission_B30_17.json` (parecer), `outputs/dryrun_write_set.json` (não executado), `outputs/causal_trace_audit.json` (TEST), `outputs/new_focused_tests.json` (13/13), `outputs/succession_checkpoint.json` e `PSV-FC08.md`.
- Reproduzir somente teste NOVO de rastreabilidade, com Python 3, sem dependências externas:
  ```
  python code/test_causal_trace.py
  python code/audit_process_trace.py inputs/test_trace_B30_17.json
  python verify_fc08.py
  ```
- Os resultados do lote TEST são inventados especificamente para testar regras de conservação: não têm validade material, econômica ou canônica. O status final é RC5-CONDICIONAL, sem crédito oficial.
- Antes de qualquer escrita: REC-LIB existing-first + PR-ITEM + REC-EXEC + PR-ECO + PR-SC/JIT + NAC-NORM/C19/fencing/writer/NAC-PASS; processo de criação previsto mas não executado.
