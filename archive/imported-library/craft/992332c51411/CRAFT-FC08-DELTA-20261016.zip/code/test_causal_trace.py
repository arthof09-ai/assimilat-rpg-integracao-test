"""Testes dirigidos inéditos: auditoria por etapa não coberta pelo gate granulométrico FC07."""
import copy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from audit_process_trace import audit,WitnessError
w=json.loads((Path(__file__).resolve().parent.parent/'inputs/test_trace_B30_17.json').read_text())
tests=[]
def check(name, mutate=None, should_pass=False):
    obj=copy.deepcopy(w)
    if mutate: mutate(obj)
    try:
        res=audit(obj);good=should_pass and res['result']=='PASS_CAUSAL_MASS_PROVENANCE_ONLY'
    except WitnessError:
        good=not should_pass
    tests.append({'test':name,'pass':bool(good)})
check('baseline_150g_balanced_multiple_mills',should_pass=True)
check('duplicate_event_rejected',lambda x:x['events'].append(copy.deepcopy(x['events'][-1])))
check('regrind_twice_oversell_rejected',lambda x:x['events'][3].update(feed_g='63.000'))
check('mass_creation_in_sieving_rejected',lambda x:x['events'][2]['outputs'].update(fine='46.000'))
check('wrong_ps_resource_rejected',lambda x:x.update(resource_crn='CRAFT-F5-R01-OUT-04'))
check('missing_source_id_rejected',lambda x:x['events'][2].update(source='raw'))
check('failed_qc_with_approved_fine_rejected',lambda x:x['events'][2]['gradation_qc'].update(status='REJECT'))
check('unqualified_qc_rejected',lambda x:x['events'][2]['gradation_qc'].update(basis='INFERRED'))
check('negative_loss_rejected',lambda x:x['events'][3]['outputs'].update(loss='-1.000'))
check('unregistered_external_material_rejected',lambda x:x['events'][2]['outputs'].update(vehicle='0.000'))
check('excess_precision_rejected',lambda x:x['events'][3].update(feed_g='62.0001'))
check('nonfinite_mass_rejected',lambda x:x['events'][3].update(feed_g='NaN'))
check('missing_lot_replay_event_rejected',lambda x:x.update(events=[]))
if len(tests)!=13 or not all(t['pass'] for t in tests):
 print(json.dumps({'tests':tests,'status':'FAIL'},indent=2));sys.exit(1)
result={'schema':'FC08-NEW-TESTS-v1','tested':len(tests),'passed':sum(z['pass'] for z in tests),'scope':'CAUSAL_TRACE_TEST_ONLY','tests':tests,'fixture_final':audit(w)['final_bins_g']}
print(json.dumps(result,indent=2,ensure_ascii=False))
