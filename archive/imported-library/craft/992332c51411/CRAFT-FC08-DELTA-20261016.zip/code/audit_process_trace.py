"""FC08: auditor de traços de lote mineral, TEST apenas; não fabrica item RPG.

Novo escopo perante FC07: proveniência de frações quando reprocessadas em múltiplas etapas,
prevenção de dupla contagem, compatibilidade de massa/unidade e despacho QA explícito.
Não mede mineral, dureza, abrasão, procedência PS, nem comprova RC5.
"""
from __future__ import annotations
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path

EXPECTED_CRN = 'CRAFT-F5-R02-MIN-02'
VALID_BINS = {'raw', 'loose', 'coarse', 'fine', 'outgrade', 'loss', 'quarantine'}
OPS = {'select': ('raw', {'raw', 'quarantine', 'loss'}),
       'mill': ('raw', {'loose', 'loss'}),
       'remill': ('coarse', {'loose', 'loss'}),
       'sieve': ('loose', {'fine', 'coarse', 'outgrade', 'quarantine', 'loss'})}

class WitnessError(ValueError):
    pass

def gram(v):
    if isinstance(v, bool) or v is None:
        raise WitnessError('invalid gram value')
    try: d = Decimal(str(v))
    except (InvalidOperation, ValueError): raise WitnessError('invalid numeric mass')
    if not d.is_finite() or d < 0 or d.as_tuple().exponent < -3:
        raise WitnessError('nonfinite/negative/overprecise mass')
    return d

def audit(witness: dict) -> dict:
    if witness.get('scope') != 'TEST_SYNTHETIC' or witness.get('resource_crn') != EXPECTED_CRN:
        raise WitnessError('missing TEST scope or wrong source CRN')
    stock = {k: Decimal(0) for k in VALID_BINS}
    initial = gram(witness.get('input_g'))
    if initial <= 0: raise WitnessError('empty batch')
    stock['raw'] = initial
    used = set()
    replay = []
    for event in witness.get('events', []):
        eid = event.get('event_id')
        op = event.get('op')
        if not isinstance(eid, str) or not eid or eid in used: raise WitnessError('missing or duplicate event ID')
        used.add(eid)
        if op not in OPS: raise WitnessError('unsupported operation')
        default_source, allowed = OPS[op]
        src = event.get('source')
        if src != default_source: raise WitnessError('wrong source for this transformation')
        feed = gram(event.get('feed_g'))
        if feed <= 0 or feed > stock[src]: raise WitnessError('oversell or zero processing feed')
        allocations = event.get('outputs')
        if not isinstance(allocations, dict) or not allocations: raise WitnessError('missing outputs')
        if set(allocations).difference(allowed): raise WitnessError('invalid result bin')
        if src in allocations and op != 'select': raise WitnessError('implicit unchanged source not authorized')
        outs = {k: gram(v) for k,v in allocations.items()}
        if sum(outs.values()) != feed: raise WitnessError('step mass not conserved')
        if op == 'sieve':
            if not isinstance(event.get('gradation_qc'), dict): raise WitnessError('missing gradation evidence classification')
            qc = event['gradation_qc']
            if qc.get('basis') not in ('TEST_SYNTHETIC','EXTERNAL_VERIFIED'):
                raise WitnessError('gradation witness has no qualified evidence basis')
            if qc.get('status') not in ('PASS','REJECT','INDETERMINATE'):
                raise WitnessError('gradation witness has no determination')
            if qc.get('status') != 'PASS' and outs.get('fine',Decimal(0)) > 0:
                raise WitnessError('cannot approve fine fraction under nonpassing QC')
        stock[src] -= feed
        for k,v in outs.items(): stock[k] += v
        if sum(stock.values()) != initial: raise WitnessError('global balance lost')
        replay.append({'id':eid,'operation':op,'source_crn':EXPECTED_CRN,
                       'balance_g':{k:str(stock[k]) for k in sorted(stock)}})
    if not replay: raise WitnessError('no processing events')
    final = {k:str(stock[k]) for k in sorted(stock)}
    if sum(stock.values()) != initial: raise WitnessError('final mass mismatch')
    return {'schema':'FC08-CAUSAL-TRACE-AUDIT-v1','classification':'TEST_SYNTHETIC',
            'lot_id':witness.get('lot_id'),'resource_crn':EXPECTED_CRN,
            'input_g':str(initial),'final_bins_g':final,'events_accepted':len(replay),
            'causal_states':replay,'actual_rpg_material_measured':False,
            'rc5_granted':False,'result':'PASS_CAUSAL_MASS_PROVENANCE_ONLY'}

def main():
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('witness');p.add_argument('--output');a=p.parse_args()
    w=json.loads(Path(a.witness).read_text(encoding='utf8'))
    result=audit(w)
    text=json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n'
    if a.output: Path(a.output).write_text(text,encoding='utf8')
    else: print(text)

if __name__=='__main__':main()
