"""Deterministic FAKE stock and reports. Never real physical inventory."""
from __future__ import annotations
import copy,json
from pathlib import Path
from r48_factory import R44,R47
from r47_fixtures import make_pair
from r46_fixtures import REVIEW

DEMO=json.loads((R44/'fixtures/demo.json').read_text(encoding='utf8'))


def lots(slate=2,mica_a=1,mica_b=1):
    out=copy.deepcopy(DEMO['lots'])
    qty={'SBX-SLATE-GOOD-01':slate,'SBX-MICA-GOOD-A':mica_a,'SBX-MICA-GOOD-B':mica_b}
    for row in out:
        if row['lot_id'] in qty:row['quantity']=qty[row['lot_id']]
    return out


def order(recipe:str,index:int,lot_ids=None):
    if recipe=='tli':
        key='SBX-TLI-R44-v1'
        vals=copy.deepcopy(DEMO['tli_good_measurements']);tools=DEMO['tli_tools'];skills=DEMO['tli_skills']
        lot_ids=lot_ids if lot_ids is not None else ['SBX-SLATE-GOOD-01']
    elif recipe=='mica':
        key='SBX-MICA-R44-v1'
        vals=copy.deepcopy(DEMO['mica_good_measurements']);tools=DEMO['mica_tools'];skills=DEMO['mica_skills']
        lot_ids=lot_ids if lot_ids is not None else ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
    else:raise ValueError('ONLY_TWO_RECIPES')
    report,attestation=make_pair(key=key,index=index,kind='SYNTHETIC')
    # Old R47 fixture already carries lot_ids. Intentionally allow a mismatch
    # for negative tests, but NEVER secretly rewrite a signed document.
    return {'order_id':f'SBX-R48-ORDER-{index:05d}','recipe_key':key,'lot_ids':lot_ids,
            'measurements':vals,'tools':copy.deepcopy(tools),'skills':copy.deepcopy(skills),
            'report':report,'attestation':attestation}


def pair(index=48001):
    return [order('tli',index),order('mica',index+1)]
