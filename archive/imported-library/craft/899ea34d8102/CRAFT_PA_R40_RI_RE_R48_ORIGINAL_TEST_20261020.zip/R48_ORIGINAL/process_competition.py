"""Two OS subprocesses race for ONE synthetic slate in ONE local durable store."""
from __future__ import annotations
import json,subprocess,sys,tempfile
from pathlib import Path
from r48_factory import IntegratedFactory
from r48_fixtures import lots,order,REVIEW
from r48_store import DurableFactory

HERE=Path(__file__).resolve().parent

def run():
    with tempfile.TemporaryDirectory(prefix='SBX-R48-PROCESS-RACE-') as td:
        root=Path(td)
        store=DurableFactory(root/'stock')
        store.initialize(IntegratedFactory.fixture_factory(lots(slate=1,mica_a=1,mica_b=1)))
        configs=[]
        for idx in (48070,48071):
            req={'batch_id':f'SBX-R48-BATCH-RACE-{idx}',
                 'orders':[order('tli',idx)],'reviewed_at':REVIEW}
            file=root/f'request-{idx}.json'
            file.write_text(json.dumps(req,sort_keys=True),encoding='utf8')
            configs.append((idx,file))
        ps=[]
        for ix,path in configs:
            cmd=[sys.executable,str(HERE/'fabricar.py'),'--store',str(root/'stock'),'batch',str(path)]
            ps.append((ix,subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,cwd=str(HERE))))
        output=[]
        for ix,p in ps:
            out,err=p.communicate(timeout=40)
            if p.returncode:
                raise RuntimeError('PROCESS_FAILED:'+repr({'id':ix,'returncode':p.returncode,'stderr':err}))
            data=json.loads(out)
            output.append({'index':ix,'status':data['receipt']['orders'][0]['status'],
                           'synthetic_product_count':data['receipt']['experimental_product_count']})
        f,ptr=store.recover()
        statuses=sorted(x['status'] for x in output)
        assert statuses==['EXPERIMENTAL_QA_PASS','REJECTED_PRECHECK'],statuses
        assert f.quantities['SBX-SLATE-GOOD-01']==0
        assert len(f.core.state['products'])==1
        assert ptr['sequence']==2
        assert f.audit()['ok']
        # Verify same two payloads retried after both processes exit:
        again=[]
        for ix,path in configs:
            obj=json.loads(path.read_text(encoding='utf8'))
            res=store.commit_batch(obj['batch_id'],obj['orders'],obj['reviewed_at'])
            assert res['idempotent_replay'] and res['disk_sequence']==2
            again.append(ix)
        return {'scenario':'TWO_SEPARATE_PROCESSES_ONE_SHARED_SYNTHETIC_STOCK',
                'processes':2,'statuses_sorted':statuses,'products_total':len(f.core.state['products']),
                'remaining_slate':f.quantities['SBX-SLATE-GOOD-01'],
                'disk_sequence':ptr['sequence'],'no_oversell':True,'audited':True,
                'idempotent_retries':len(again),
                'claims_external_Notion_fencing':False,'official_stock_effect':0,
                'non_deterministic_winner':'WHO_WINS_LOCK_NOT_FIXED'}

if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False,sort_keys=True,indent=2))
