"""Verify ZIP CRC + R48 manifest + byte-preserved R47 nested source."""
from __future__ import annotations
import hashlib,json,sys,zipfile
from pathlib import Path
R47_SHA='be76bc7ea2218dce388b1197797d6015891b3bbb1801351f99a2b49bab56252e'
ROOT='CRAFT-R48-SANDBOX-I0016/'
LEGACY=ROOT+'legacy/CRAFT-R47-SANDBOX-I0016/'
R47_ZIP=ROOT+'baseline_original/CRAFT-R47-I0016-AUTENTICIDADE-CUSTODIA-v02.zip'

def sha(raw):return hashlib.sha256(raw).hexdigest()

def verify(path):
    p=Path(path);zh=sha(p.read_bytes())
    with zipfile.ZipFile(p) as z:
        bad=z.testzip()
        if bad:raise AssertionError('ZIP_CRC_FAIL:'+bad)
        names=[n for n in z.namelist() if not n.endswith('/')]
        manifest_path=ROOT+'MANIFEST_SHA256.txt'
        if manifest_path not in names:raise AssertionError('MISSING_MANIFEST')
        rows=[]
        for line in z.read(manifest_path).decode('utf8').splitlines():
            if not line or line.startswith('#'):continue
            h,rel=line.split('  ',1);rows.append((rel,h))
        expected={ROOT+rel for rel,h in rows}
        if expected!=set(names)-{manifest_path}:raise AssertionError('MANIFEST_SET_MISMATCH')
        for rel,h in rows:
            if sha(z.read(ROOT+rel))!=h:raise AssertionError('MANIFEST_FILE_CORRUPT:'+rel)
        if sha(z.read(R47_ZIP))!=R47_SHA:raise AssertionError('R47_ORIGINAL_ZIP_CHANGED')
        # R47 extracted sources inside R48 must also match the R47 original ZIP manifest.
        with zipfile.ZipFile(z.open(R47_ZIP)) as old:
            source_manifest=old.read('CRAFT-R47-SANDBOX-I0016/MANIFEST_SHA256.txt').decode('utf8')
            checked=0
            for line in source_manifest.splitlines():
                if not line or line.startswith('#'):continue
                h,rel=line.split('  ',1)
                member=LEGACY+rel
                if member not in names or sha(z.read(member))!=h:raise AssertionError('R47_EXTRACTED_FILE_CHANGED:'+rel)
                checked+=1
            if checked!=138:raise AssertionError('R47_EXPECTED_138_MEMBERS_GOT_'+str(checked))
        return {'status':'PASS','sha256':zh,'zip_crc':'PASS','manifest_files_verified':len(rows),
                'r47_legacy_members_verified':checked,'r47_original_zip_sha256':R47_SHA,
                'physical_validation':'NONE_SOFTWARE_ONLY'}

if __name__=='__main__':
    print(json.dumps(verify(sys.argv[1]),ensure_ascii=False,indent=2,sort_keys=True))
