# Protocolo R46 · recuperação, integridade e reprodução limpa

**Alvo:** reconstruir exclusivamente o estado do laboratório fictício; nenhuma conexão ao Notion, estoque real ou motor produtivo.

1. Compare SHA-256 do ZIP R46 fornecido no recibo com o ZIP recebido. Inspecione entradas ZIP para duplicidade, `..`, paths absolutos, barras inversas, CRC e `MANIFEST_SHA256.txt`; recuse divergência em qualquer membro. Use `verify_r46.py` no diretório extraído apontando para o ZIP externo.
2. Confira as cópias exatas R45 e R44 em `baseline/` usando SHA-256 esperado respectivamente `5b36b0...718946` e `900452...ff3`; valide os manifests originais independentemente. `baseline/extracted_R45/` é leitura e execução em cópia.
3. Em diretório limpo e offline, execute as três suítes `unittest` na ordem R44 (52), R45 (64), R46 (70). Se os testes alterarem resultados extraídos da linha histórica, faça uma **nova cópia** antes de rodar scripts que gravem no mesmo diretório.
4. Execute `run_r46_demo.py`, `stress_r46.py` e `mutation_r46.py`. Compare os SHA-256 dos resultados determinísticos originais e reexecutados. Todos os IDs/tempos/valores de fixture são fixos. O stress usa seed 460016 (300) e mutação seed 460017 (330).
5. Para restaurar vault de laudos: `EvidenceVault.restore('results/r46_demo_snapshot.json', expected_head='<head externo registrado>')`. O `expected_head` deve vir de recibo *independente do arquivo a restaurar*; o hash contido na própria snapshot não é âncora independente. O restore executa as decisões anteriores e rejeita divergência semântica/hash.
6. Se houver `.tmp` remanescente de crash antes do rename, **não** a promova automaticamente: verifique snapshot anterior, âncora externa e dados de journal; reprocessar somente sob idempotência de mesmo `report_id` e payload. Evento de efeito desconhecido requer readback antes de retry.
7. Na recuperação de laudo não verificado, mantenha sempre status de quarentena ou elegível à revisão; não reclassifique para `PHYSICALLY_VERIFIED` nem gere material.
8. Se hash/cadeia quebrar, registre o último estado confiável e **PARE publicação daquele arquivo**; não reescreva ou recompute hashes para ocultar quebra. Reexecute contra a fonte preservada e compare à âncora externa.

**Aceite de recuperação:** manifesto íntegro, baselines imutáveis, 186 testes (52+64+70), stress 300, mutação 330, hashes determinísticos correspondentes e zero escrita oficial.

**Limitações:** não há prova de tempo físico/assinatura criptográfica externa, observação humana, certificação de laboratório, servidor imutável ou garantia de exclusão de writer concorrente. Isto não é NAC-PASS de produção.
