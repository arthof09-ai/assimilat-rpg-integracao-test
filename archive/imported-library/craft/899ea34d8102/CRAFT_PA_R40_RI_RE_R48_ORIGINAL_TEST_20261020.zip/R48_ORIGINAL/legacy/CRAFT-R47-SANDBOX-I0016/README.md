# CRAFT R47 — AUTENTICIDADE DOCUMENTAL & CUSTÓDIA | SANDBOX

**Autor operacional:** `CM-000002-I0016` / `CM-000002-WS0001` (Executor 1 / MESTRE-SIDE).  
**Escopo:** laboratório de software, isolado da campanha. **NENHUMA medição física realizada.**

Este pacote acrescenta arquivos R47 e NÃO substitui o R46, que está preservado byte a byte em `baseline/CRAFT-R46-I0016-EVIDENCE-VAULT-v01.zip` e em `baseline/CRAFT-R46-SANDBOX-I0016/` (103 arquivos de origem verificados). O R46 já contém R44/R45 e todos os ensaios anteriores, preservados.

## Arquitetura

`R44 motor de transformação sintética` → `R45 contrato de medidas` → `R46 validação de bytes/laudo` → `R47 checagem criptográfica de confiança declarada + cadeia assinada + journal local + checkpoint durável opcional`.

- `r47_authenticity.py`: valida assinatura **Ed25519**, certificado assinado por raiz PINNED localmente (somente fixtures nesta versão), permissão do emissor por papel/instrumento/recurso PS, revogação e prazo, assinatura do laudo e certificado de calibração e custódia (coleta, transferência, recebimento e leitura). Exige hashes e identidades consistentes com laudo R46. Cada decisão contém causas, recibo, confiança limitada e condições pendentes. Nenhum caminho certifica medição física ou chama biblioteca produtiva.
- `r47_fixtures.py`: chaves e identidades **publicamente deriváveis, fabricadas só para teste**. A validade dessas assinaturas nunca fornece identidade real, laboratório ou medição. Não reutilize essas chaves fora de testes.
- `r47_durable_store.py`: checkpoints locais imutáveis, `flock` entre processos no **mesmo filesystem**, ponteiro de commit publicado atomicamente, retenção de versões, detecção de ponteiro/arquivo corrompido e `UNKNOWN_EFFECT` se houver candidato sem publicação. **Não é o gateway F5/C19.**
- `run_r47_demo.py`: duas receitas originais e casos de autenticação/quarentena; repete e compara os resultados das duas alternativas comuns.
- `stress_r47.py`, `mutation_r47.py`, `process_recovery_r47.py`, `tests/`: testes funcionais, adversariais e de recuperação.
- `verify_r47.py`: integridade de ZIP/manifest/arquivos 103/103 do R46 e SHA de ZIPs originais R44/R45.

## Como reproduzir a partir de ZIP extraído

Requer **Python 3.10+** e a dependência externa **cryptography** (avaliada aqui na versão 46.0.4). Com o pacote extraído na pasta `CRAFT-R47-SANDBOX-I0016`, sem conexões ao Notion:

```bash
python -m unittest discover -s baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016/tests -p 'test*.py' -q
python -m unittest discover -s baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016/tests -p 'test*.py' -q
python -m unittest discover -s baseline/CRAFT-R46-SANDBOX-I0016/tests -p 'test*.py' -q
python -m unittest discover -s tests -p 'test*.py' -q
python run_r47_demo.py
python stress_r47.py
python mutation_r47.py
python process_recovery_r47.py
```

O último processo cria apenas o diretório `results/r47_local_durable_demo/` e o substitui no *sandbox* para garantir repetibilidade da simulação; ele não acessa o RPG. Para verificar o ZIP intacto, executar `python verify_r47.py CAMINHO/ZIP`.

## Gates e denominadores

- Modelos experimentais herdados: **2/2** (Tábua Lamelar e Espaçador de Mica); **0 novos modelos** nesta rodada.
- R44 regressivos: **52/52**; R45: **64/64**; R46: **70/70**; R47: **87/87**.
- Stress R47: **120/120 operações**, dados sintéticos. Mutação R47: **260/260** entradas em quarentena, nenhuma certificação material.
- C19: `F5=RED`, IBX-38 `NOVA` sem ACK no preflight, C19-021 `UNKNOWN_EFFECT`, fencing externo não demonstrado; **RC5=0/30**, `MATERIAL NAC-PASS=HOLD`, `Party/O Primeiro=0 writes`.
- `REVIEW_REQUIRED` não significa medição verdadeira. Nenhuma raiz externa real foi certificada pela ferramenta; `externally_vetted=True` não é aceito como declaração autossuficiente. Até que uma autoridade realmente independente valide o processo, os certificados de teste permanecem simulados ou em quarentena.

A análise de ameaças, cadeia de custódia, riscos, protocolo de recuperação e ponto de retomada estão em `docs/`. O ZIP é um **artefato de software**, não uma receita oficial, medida física ou prova de exclusividade no Notion.
