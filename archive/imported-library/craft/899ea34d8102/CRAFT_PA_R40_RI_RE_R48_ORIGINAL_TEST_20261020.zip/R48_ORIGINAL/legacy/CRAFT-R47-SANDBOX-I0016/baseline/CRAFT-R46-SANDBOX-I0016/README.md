# CRAFT / CM-000002-I0016 — R46 · motor de laudos em quarentena

**MESTRE-SIDE · SANDBOX EXPERIMENTAL · 2026-10-09 · F5=RED**

Este pacote deriva **aditivamente** do R45. `baseline/CRAFT-R45-I0016-PLATAFORMA-EXPERIMENTAL-v01.zip` é um backup integral de bytes do antecessor; `baseline/CRAFT-R44-I0016-PILOTO-EXPERIMENTAL-v01.zip` guarda o R44 original, ambos por SHA-256. `baseline/extracted_R45/` contém uma cópia de referência para execução e `baseline/extracted_R44/` a cópia do R44; não são editados pelos módulos R46.

**Não há escrita Notion/API/campaign**, geração de receitas oficiais, magia nova, produção, coleta, estoque real, preços MED ou certificação de instrumento. `ELIGIBLE_FOR_INDEPENDENT_REVIEW` significa apenas contrato documental completo e autoconsistente, **não** medição real conferida. Hash comprova que aqueles bytes coincidem com o digest informado; **não** comprova autoria, coleta física, autenticidade do emissor ou veracidade da observação.

## Requisitos e execução

Python 3.11+ padrão, nenhuma dependência instalada nem rede. A partir deste diretório:

```bash
python -m unittest discover -s baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016/r44_legacy/tests -p 'test_*.py' -q
python -m unittest discover -s baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016/tests -p 'test_*.py' -q
python -m unittest discover -s tests -p 'test_*.py' -q
python run_r46_demo.py
python stress_r46.py
python mutation_r46.py
```

Os três primeiros resultados esperados são **52/52, 64/64 e 70/70**. `stress_r46.py` executa 300 casos com seed fixa e restaura snapshot; `mutation_r46.py` injeta 330 mutações malformadas com seed fixa. Os comandos sobrescrevem **somente resultados locais R46**, nunca os ZIPs/baselines R44/R45. Não rodar o stress R45 dentro do diretório de baseline sem fazer cópia separada, pois seu script escreve resultados no diretório de trabalho R45; o arquivo ZIP original permanece intocado.

## Arquivos

- `r46_evidence.py`: contratos documentais, prova local de igualdade de bytes, unidade/guard-band, carimbo UTC, cadeia de custódia e journal hash-linked, idempotência, transação em lote, rollback e snapshot atômico.
- `r46_fixtures.py`: gerador declaradamente **FICTÍCIO**; qualquer alegação de medição física nela é apenas o objeto de teste do classificador, nunca laudo real.
- `r46_comparison.py`: reaproveita o comparador R45 com restrições de pareamento/condições/n, sem estatística inferencial nem proclamação de vencedor empírico.
- `tests/`: testes de contrato, falsificação, medição ambígua, unidade, calibração, idempotência, lote, tamper de snapshot e integração comparativa.
- `results/`: fichas e recibos gerados deterministicamente; relatório de stress, matriz de evidência e matriz comparativa.
- `docs/`: protocolo operacional, matriz de riscos, relatório e retomada R47.
- `MANIFEST_SHA256.txt`: caminhos/hash do pacote (não inclui o manifesto). O ZIP externo é identificado por seu SHA-256 próprio entregue no relatório.

## Fronteiras de confiança

`VERIFICADO` significa apenas que SHA-256, CRC, execução de software e readback foram observados; `SINTÉTICO` significa valores totalmente fictícios; `PROPOSTO` é contrato de engenharia sem aferição; `MEDIDO` foi alegado em fixture, mas nenhuma medição foi autenticada; `MATERIALIZADO`=0. Fonte R01 PS, não estoque. **A conversão para oficial é um processo separado, hoje BLOQUEADO por C19.**
