"""Filesystem-process experiment: local flock != canonical C19 gateway."""
import json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from r47_durable_store import R47DurableStore,LocalCrash
from r47_authenticity import AuthenticityVault,AuthError
from r47_fixtures import policy,recipes_and_sources,make_pair,REVIEW

folder=ROOT/'results/r47_local_durable_demo'
if folder.exists():
    # For deterministic replays, ensure cleanup is confined to this distinct sandbox folder.
    import shutil
    shutil.rmtree(folder)
recipes,sources=recipes_and_sources();v=AuthenticityVault(recipes,sources,policy())
store=R47DurableStore(folder)
initial=store.initialize(v)
ids=[400001,400002,400003,400004]
script='''import sys,json
from r47_durable_store import R47DurableStore
from r47_fixtures import policy,make_pair,REVIEW
from r47_authenticity import digest
v=R47DurableStore(sys.argv[1]);r,a=make_pair(index=int(sys.argv[2]))
p=v.commit_batch([{'report':r,'attestation':a}],REVIEW,digest(policy()))
print(json.dumps({'id':int(sys.argv[2]),'head':p['disk_head'],'sequence':p['sequence']}))
'''
children=[subprocess.Popen([sys.executable,'-c',script,str(folder),str(i)],cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
          for i in ids]
logs=[]
for process in children:
    out,err=process.communicate(timeout=90)
    assert process.returncode==0,(process.returncode,err)
    logs.append(json.loads(out.strip()))
loaded,ptr=store.recover(v.trust.policy_sha256)
assert ptr['sequence']==4 and len(loaded.events)==4 and loaded.audit()['ok']
# A caller whose ACK disappeared after disk commit can replay without a second effect.
item=make_pair(index=400005)
try:
    store.commit_batch([{'report':item[0],'attestation':item[1]}],REVIEW,v.trust.policy_sha256,inject='AFTER_HEAD_BEFORE_ACK')
    raise AssertionError('INJECTION_FAILED')
except LocalCrash:pass
fresh=R47DurableStore(folder)
after_ack_loss,st=fresh.recover(v.trust.policy_sha256)
assert st['sequence']==5 and len(after_ack_loss.events)==5
replay=fresh.commit_batch([{'report':item[0],'attestation':item[1]}],REVIEW,v.trust.policy_sha256)
assert replay['idempotent_only'] and fresh.recover(v.trust.policy_sha256)[1]['sequence']==5
# Reproduce unknown effect in an entirely independent ephemeral repository.
with tempfile.TemporaryDirectory() as d:
    t=R47DurableStore(d)
    dummy=AuthenticityVault(recipes,sources,policy());t.initialize(dummy)
    x,y=make_pair(index=400006)
    try:
        t.commit_batch([{'report':x,'attestation':y}],REVIEW,dummy.trust.policy_sha256,inject='AFTER_CHECKPOINT_BEFORE_HEAD')
        raise AssertionError('ORPHAN_NOT_INJECTED')
    except LocalCrash:pass
    try:t.recover(dummy.trust.policy_sha256);raise AssertionError('UNKNOWN_EFFECT_NOT_DETECTED')
    except AuthError as err:
        assert 'UNKNOWN_EFFECT_ORPHAN_CHECKPOINTS' in str(err)
summary={'schema':'R47-LOCAL-FILESYSTEM-RECOVERY-v1','scope':'SYNTHETIC_FILESYSTEM_ONLY',
         'cross_process_workers':4,'cross_process_commits':4,'sequences':[l['sequence'] for l in logs],
         'after_ack_loss_no_duplicate':True,'after_commit_without_head_halts':True,
         'final_process_commits':5,'replay_audit':after_ack_loss.audit(),
         'external_notions_writer_fenced':False,'physical_measurements_verified':0,
         'official_stock_effect':0,'rc5':0,'f5':'RED'}
(ROOT/'results/r47_process_recovery_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
