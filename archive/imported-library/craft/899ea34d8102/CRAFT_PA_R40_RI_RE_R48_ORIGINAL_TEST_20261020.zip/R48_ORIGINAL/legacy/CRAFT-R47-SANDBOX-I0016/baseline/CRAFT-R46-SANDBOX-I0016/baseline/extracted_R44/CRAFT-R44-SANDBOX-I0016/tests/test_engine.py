import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from experimental_engine import (SandboxEngine, SandboxError, SimulatedCrash,
                                 load_recipes, simulation_cost, digest, NAMESPACE)

R=load_recipes(ROOT/'recipes')
F=json.loads((ROOT/'fixtures'/'demo.json').read_text(encoding='utf8'))

class R44Tests(unittest.TestCase):
    def setUp(self):
        self.e=SandboxEngine(R,F['lots'])
        self.slate=F['lots'][0]['lot_id']
        self.mica=['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']

    def tli(self,aid='SBX-T1',lots=None,qa=None,tools=None,skills=None,fault_stage=None):
        return self.e.run('SBX-TLI-R44-v1',aid,[self.slate] if lots is None else lots,
                          copy.deepcopy(F['tli_good_measurements']) if qa is None else qa,
                          F['tli_tools'] if tools is None else tools,
                          F['tli_skills'] if skills is None else skills, fault_stage)

    def mica_run(self,aid='SBX-M1',lots=None,qa=None,tools=None,skills=None,fault_stage=None):
        return self.e.run('SBX-MICA-R44-v1',aid,self.mica if lots is None else lots,
                          copy.deepcopy(F['mica_good_measurements']) if qa is None else qa,
                          F['mica_tools'] if tools is None else tools,
                          F['mica_skills'] if skills is None else skills, fault_stage)

    def test_01_genesis_integrity(self):
        self.assertTrue(self.e.audit()['ok'])
        self.assertEqual(self.e.audit()['verified_events'],0)

    def test_02_tli_happy_path_consumes_one(self):
        r=self.tli()
        self.assertEqual(r['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(r['inventory_before'][self.slate],2)
        self.assertEqual(r['inventory_after'][self.slate],1)
        self.assertEqual(len(r['products']),1)
        self.assertEqual(len(r['transformation_stage_trace']),6)
        self.assertEqual(sum(z['minutes_proposed'] for z in r['transformation_stage_trace']),55)
        self.assertTrue(all(z['mode']=='SIMULATED_RULE_TRANSITION_NOT_PHYSICAL' for z in r['transformation_stage_trace']))
        self.assertEqual(r['products'][0]['units'],1)
        self.assertIsNone(r['official_rec_id'])

    def test_03_tli_output_no_magic(self):
        p=self.tli()['products'][0]
        self.assertEqual(p['mechanical_bonus'],0)
        self.assertIsNone(p['official_product_id'])
        self.assertEqual(p['status'],'SYNTHETIC_OUTPUT_ONLY')

    def test_04_mica_happy_path_consumes_two(self):
        r=self.mica_run()
        self.assertEqual(r['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(len(r['consumed']),2)
        self.assertEqual(r['products'][0]['units'],2)
        self.assertEqual(len(r['transformation_stage_trace']),5)
        self.assertEqual(sum(z['minutes_proposed'] for z in r['transformation_stage_trace']),30)
        self.assertEqual(self.e.state['lots'][self.mica[0]]['quantity'],0)
        self.assertEqual(self.e.state['lots'][self.mica[1]]['quantity'],0)

    def test_05_idempotent_success_no_second_consumption(self):
        a=self.tli(); n=self.e.state['lots'][self.slate]['quantity']
        b=self.tli();self.assertEqual(n,self.e.state['lots'][self.slate]['quantity'])
        self.assertTrue(b['idempotent_replay']);self.assertEqual(a['request_hash'],b['request_hash'])
        self.assertEqual(len(self.e.state['events']),1)

    def test_06_conflicting_same_key_rejected(self):
        self.tli()
        q=copy.deepcopy(F['tli_good_measurements']);q['length_mm']=121
        with self.assertRaisesRegex(SandboxError,'IDEMPOTENCY_KEY_REUSE'):
            self.tli(qa=q)
        self.assertEqual(len(self.e.state['events']),1)

    def test_07_insufficient_slate_does_not_overdraw(self):
        self.tli('SBX-A'); self.tli('SBX-B')
        r=self.tli('SBX-C')
        self.assertEqual(r['status'],'REJECTED_PRECHECK')
        self.assertIn('INSUFFICIENT_QUANTITY',r['rejection_reasons'])
        self.assertFalse(r['consumed']);self.assertFalse(r['products'])
        self.assertEqual(r['transformation_stage_trace'],[])
        self.assertEqual(self.e.state['lots'][self.slate]['quantity'],0)

    def test_08_undersized_slate_no_consumption(self):
        r=self.tli(lots=['SBX-SLATE-TOO-SMALL'])
        self.assertIn('UNDER_DIMENSION_length',r['rejection_reasons'])
        self.assertEqual(self.e.state['lots']['SBX-SLATE-TOO-SMALL']['quantity'],1)

    def test_09_cracked_slate_no_consumption(self):
        r=self.tli(lots=['SBX-SLATE-CRACKED'])
        self.assertIn('INPUT_CRACKED_UNVERIFIED_OR_TRUE',r['rejection_reasons'])
        self.assertEqual(self.e.state['lots']['SBX-SLATE-CRACKED']['quantity'],1)

    def test_10_unknown_lot_no_consumption(self):
        r=self.tli(lots=['SBX-ABSENT'])
        self.assertIn('UNKNOWN_SYNTHETIC_LOT',r['rejection_reasons']);self.assertFalse(r['consumed'])

    def test_11_wrong_resource_for_tli(self):
        r=self.tli(lots=[self.mica[0]])
        self.assertIn('SOURCE_OR_UNIT_MISMATCH',r['rejection_reasons'])
        self.assertEqual(self.e.state['lots'][self.mica[0]]['quantity'],1)

    def test_12_missing_required_tool_blocks(self):
        tools=F['tli_tools'][:-1]
        r=self.tli(tools=tools)
        self.assertIn('MISSING_REQUIRED_TOOL',r['rejection_reasons']);self.assertFalse(r['consumed'])

    def test_13_missing_skill_blocks(self):
        r=self.tli(skills=[])
        self.assertIn('MISSING_REQUIRED_SKILL',r['rejection_reasons'])

    def test_14_bad_final_length_consumes_and_scraps(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['length_mm']=125
        r=self.tli(qa=q)
        self.assertEqual(r['status'],'REJECTED_QUALITY')
        self.assertIn('length_mm:OUT_OF_RANGE',r['rejection_reasons'])
        self.assertEqual(self.e.state['lots'][self.slate]['quantity'],1)
        self.assertFalse(r['products']);self.assertEqual(len(r['scrap']),1)

    def test_15_flatness_failure(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['flatness_deviation_mm']=2
        self.assertIn('flatness_deviation_mm:OUT_OF_RANGE',self.tli(qa=q)['rejection_reasons'])

    def test_16_grid_failure(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['grid_spacing_mm']=12
        self.assertEqual(self.tli(qa=q)['status'],'REJECTED_QUALITY')

    def test_17_groove_failure(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['groove_depth_mm']=0.7
        self.assertIn('groove_depth_mm:OUT_OF_RANGE',self.tli(qa=q)['rejection_reasons'])

    def test_18_sharp_edges_failure(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['sharp_edges']=True
        self.assertEqual(self.tli(qa=q)['status'],'REJECTED_QUALITY')

    def test_19_magic_detected_rejected(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['magic_detected']=True
        self.assertEqual(self.tli(qa=q)['status'],'REJECTED_QUALITY')

    def test_20_missing_measurement_is_not_auto_pass(self):
        q=copy.deepcopy(F['tli_good_measurements']);del q['cracks']
        self.assertEqual(self.tli(qa=q)['status'],'REJECTED_QUALITY')

    def test_21_wrong_boolean_type_is_rejected(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['cracks']=0
        self.assertIn('cracks:REQUIRED_False',self.tli(qa=q)['rejection_reasons'])

    def test_22_reject_precheck_is_idempotent(self):
        a=self.tli(lots=['SBX-ABSENT']);b=self.tli(lots=['SBX-ABSENT'])
        self.assertTrue(b['idempotent_replay']);self.assertEqual(len(self.e.state['events']),1)

    def test_23_duplicate_lot_in_mica_rejected(self):
        with self.assertRaisesRegex(SandboxError,'DUPLICATE_LOT_SELECTION'):
            self.mica_run(lots=[self.mica[0],self.mica[0]])
        self.assertEqual(self.e.audit()['verified_events'],0)

    def test_24_mica_missing_second_sheet(self):
        r=self.mica_run(lots=[self.mica[0],'SBX-ABSENT'])
        self.assertIn('UNKNOWN_SYNTHETIC_LOT',r['rejection_reasons'])
        self.assertEqual(self.e.state['lots'][self.mica[0]]['quantity'],1)

    def test_25_mica_thickness_mismatch_reject(self):
        q=copy.deepcopy(F['mica_good_measurements']);q['thickness_difference_mm']=0.2
        r=self.mica_run(qa=q)
        self.assertEqual(r['status'],'REJECTED_QUALITY');self.assertEqual(len(r['consumed']),2)
        self.assertEqual(len(r['products']),0)

    def test_26_mica_mount_does_not_fit(self):
        q=copy.deepcopy(F['mica_good_measurements']);q['mount_fit']=False
        self.assertEqual(self.mica_run(qa=q)['status'],'REJECTED_QUALITY')

    def test_27_mica_no_mystic_properties(self):
        self.assertEqual(self.mica_run()['products'][0]['mechanical_bonus'],0)

    def test_28_fault_after_consume_rolls_back(self):
        before=digest(self.e.state)
        with self.assertRaises(SimulatedCrash): self.tli(fault_stage='AFTER_CONSUME')
        self.assertEqual(digest(self.e.state),before)
        self.assertEqual(self.tli()['status'],'EXPERIMENTAL_QA_PASS')

    def test_29_fault_after_qa_rolls_back(self):
        before=digest(self.e.state)
        with self.assertRaises(SimulatedCrash): self.tli(fault_stage='AFTER_QA')
        self.assertEqual(digest(self.e.state),before)

    def test_30_fault_before_commit_rolls_back(self):
        before=digest(self.e.state)
        with self.assertRaises(SimulatedCrash): self.tli(fault_stage='BEFORE_COMMIT')
        self.assertEqual(digest(self.e.state),before)

    def test_31_atomic_transaction_no_negative_stock_mica(self):
        self.mica_run('SBX-M1')
        r=self.mica_run('SBX-M2')
        self.assertEqual(r['status'],'REJECTED_PRECHECK')
        self.assertEqual(self.e.state['lots'][self.mica[0]]['quantity'],0)
        self.assertTrue(self.e.audit()['ok'])

    def test_32_ledger_replay_happy_and_failure(self):
        self.tli('SBX-T1');self.tli('SBX-T2')
        self.tli('SBX-T3')
        self.mica_run('SBX-M1')
        a=self.e.audit()
        self.assertTrue(a['ok'],a['reasons']);self.assertEqual(a['verified_events'],4)

    def test_33_detect_tampered_inventory(self):
        self.tli()
        self.e.state['lots'][self.slate]['quantity']=999
        self.assertFalse(self.e.audit()['ok'])

    def test_34_detect_tampered_event(self):
        self.tli()
        self.e.state['events'][0]['event']['status']='COUNTERFEIT'
        self.assertFalse(self.e.audit()['ok'])

    def test_35_fail_closed_if_tampered(self):
        self.tli()
        self.e.state['lots'][self.slate]['quantity']=0
        with self.assertRaisesRegex(SandboxError,'LEDGER_INTEGRITY_FAILURE'):
            self.tli('SBX-T2')

    def test_36_snapshot_recovery_then_idempotency(self):
        self.tli('SBX-T1');self.mica_run('SBX-M1')
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'snapshot.json';self.e.export_snapshot(path)
            recovered=SandboxEngine.restore(R,path)
            self.assertEqual(digest(self.e.state),digest(recovered.state))
            r=recovered.run('SBX-TLI-R44-v1','SBX-T1',[self.slate],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'])
            self.assertTrue(r['idempotent_replay'])

    def test_37_corrupted_snapshot_must_refuse(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'snapshot.json';self.e.export_snapshot(path)
            obj=json.loads(path.read_text());obj['state']['head_hash']='BAD'
            path.write_text(json.dumps(obj))
            with self.assertRaisesRegex(SandboxError,'SNAPSHOT_CHECKSUM_INVALID'):
                SandboxEngine.restore(R,path)

    def test_38_recipe_change_refuses_old_snapshot(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'snapshot.json';self.e.export_snapshot(path)
            changed=copy.deepcopy(R);changed['SBX-TLI-R44-v1']['output']['name']='CHANGED'
            with self.assertRaisesRegex(SandboxError,'RECIPE_CHANGED'):
                SandboxEngine.restore(changed,path)

    def test_39_reject_non_synthetic_lot(self):
        lot=copy.deepcopy(F['lots'][0]);lot['lot_id']='REAL-L1'
        with self.assertRaisesRegex(SandboxError,'NON_SANDBOX_STOCK'):
            SandboxEngine(R,[lot])

    def test_40_reject_bad_initial_stock(self):
        lot=copy.deepcopy(F['lots'][0]);lot['quantity']=-1
        with self.assertRaisesRegex(SandboxError,'INVALID_QUANTITY'):
            SandboxEngine(R,[lot])

    def test_41_duplicate_id_in_initial_stock(self):
        with self.assertRaisesRegex(SandboxError,'DUPLICATE_LOT_ID'):
            SandboxEngine(R,[F['lots'][0],F['lots'][0]])

    def test_42_synthetic_cost_has_no_med(self):
        r=simulation_cost(R['SBX-TLI-R44-v1'],F['mock_prices_ucs'],1)
        self.assertEqual(r['currency'],'UCS_SIMULADA')
        self.assertEqual(r['total_batch'],'43.00')
        self.assertEqual(r['unit_cost'],'43.00')
        self.assertFalse(r['prices_are_real'])

    def test_43_zero_yield_cost_undefined(self):
        r=simulation_cost(R['SBX-TLI-R44-v1'],F['mock_prices_ucs'],0)
        self.assertIsNone(r['unit_cost'])

    def test_44_real_med_prices_forbidden(self):
        with self.assertRaisesRegex(SandboxError,'REAL_MED_PRICE_NOT_ESTIMABLE'):
            simulation_cost(R['SBX-TLI-R44-v1'],F['mock_prices_ucs'],1,'MED')

    def test_45_mica_uses_same_engine_and_cost(self):
        r=simulation_cost(R['SBX-MICA-R44-v1'],F['mock_prices_mica_ucs'],2)
        self.assertEqual(r['total_batch'],'31.50')
        self.assertEqual(r['unit_cost'],'15.75')

    def test_46_geometry_waste_not_product_yield(self):
        r=R['SBX-TLI-R44-v1']['geometry_proposed']
        self.assertAlmostEqual(r['raw_cm3']-r['finished_cm3'],28.5)
        self.assertAlmostEqual(r['finished_cm3']/r['raw_cm3']*100,r['ideal_geometric_recovery_percent'])
        self.assertEqual(self.e.audit()['verified_events'],0)

    def test_47_products_never_enter_official_inventory(self):
        self.tli();self.mica_run()
        for p in self.e.state['products'].values():
            self.assertIsNone(p['official_product_id'])
            self.assertIn(NAMESPACE,p['product_id'])

    def test_48_precheck_wrong_lot_quantity_zero(self):
        lot=copy.deepcopy(F['lots'][0]);lot['quantity']=0
        e=SandboxEngine(R,[lot]);r=e.run('SBX-TLI-R44-v1','SBX-TRY',[lot['lot_id']],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'])
        self.assertEqual(r['status'],'REJECTED_PRECHECK')

    def test_49_replay_detects_scrap_tampering(self):
        q=copy.deepcopy(F['tli_good_measurements']);q['length_mm']=155
        self.tli(qa=q)
        self.e.state['waste'].clear()
        self.assertFalse(self.e.audit()['ok'])

    def test_51_detect_tampered_attempt_receipt(self):
        self.tli()
        self.e.state['attempts']['SBX-T1']['consumed']=[]
        self.assertFalse(self.e.audit()['ok'])

    def test_52_detect_tampered_receipt_balance_snapshot(self):
        self.tli()
        self.e.state['attempts']['SBX-T1']['inventory_after'][self.slate]=999
        self.assertFalse(self.e.audit()['ok'])

    def test_50_reject_missing_qa_does_not_publish(self):
        q={'length_mm':120}
        r=self.tli(qa=q)
        self.assertEqual(r['status'],'REJECTED_QUALITY')
        self.assertFalse(r['products'])

if __name__=='__main__':unittest.main()
