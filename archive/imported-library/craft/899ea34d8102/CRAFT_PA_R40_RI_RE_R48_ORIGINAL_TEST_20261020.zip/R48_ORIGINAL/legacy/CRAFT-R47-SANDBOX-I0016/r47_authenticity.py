"""R47 OFFLINE experimental authenticity layer over byte-preserved R46.

Guarantee boundary: Ed25519 signature verification is cryptographic; REAL-WORLD
identity, permission, calibration, measurement and trust are NOT inferred from a
fixture root, valid digest, or successful local software check. No production API.
"""
from __future__ import annotations
import base64
import copy
import datetime as dt
import hashlib
import json
import threading
import sys
from pathlib import Path
from typing import Any
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature
sys.path.insert(0,str(Path(__file__).resolve().parent/"baseline/CRAFT-R46-SANDBOX-I0016"))
from r46_evidence import EvidenceVault, EvidenceError, InjectedFailure, digest, canonical, timestamp

NAMESPACE='SBX-CRAFT-R47-I0016'
SCHEMA='R47-AUTHENTICITY-v1'
GENESIS=hashlib.sha256((NAMESPACE+'|GENESIS').encode()).hexdigest()
SNAPSHOT_SCHEMA='R47-SNAPSHOT-v1'
MAX_ENVELOPE=400000
VALID_ROLES={'OPERATOR','CALIBRATOR','CUSTODIAN'}
STATUS={'QUARANTINE_AUTHENTICITY','QUARANTINE_R46_PRECHECK','QUARANTINE_UNVETTED_ANCHOR',
        'SIMULATED_CRYPTO_VALID_NOT_REAL','DOCUMENT_SIGNED_REVIEW_REQUIRED'}

class AuthError(ValueError): pass

def _bytes(value:str)->bytes:
    if type(value) is not str:raise AuthError('MISSING_BASE64')
    try:return base64.b64decode(value,validate=True)
    except Exception as e:raise AuthError('INVALID_BASE64') from e

def verify(key_b64:str,payload:dict,signature_b64:str)->bool:
    try:
        key=_bytes(key_b64);sig=_bytes(signature_b64)
        if len(key)!=32 or len(sig)!=64:return False
        Ed25519PublicKey.from_public_bytes(key).verify(sig,canonical(payload).encode('utf8'))
        return True
    except (ValueError,TypeError,InvalidSignature,AuthError):return False

def valid_time(s):
    try:return timestamp(s)
    except (ValueError,TypeError,OverflowError):raise AuthError('TIME_OR_TIMEZONE_INVALID')

def require_fields(d,fields,code):
    if type(d) is not dict or set(d)!=set(fields):raise AuthError(code)

def sha_text(obj):return digest(obj)

class TrustGate:
    """Frozen externally supplied anchor registry; envelope CANNOT introduce roots."""
    def __init__(self,policy:dict):
        self.policy=copy.deepcopy(policy)
        if type(policy) is not dict or set(policy)!={'schema','roots','revocations','policy_mode','externally_vetted'}:
            raise AuthError('TRUST_POLICY_SCHEMA')
        if policy['schema']!='R47-TRUST-POLICY-v1' or policy['policy_mode'] not in ('FIXTURE_SIMULATED','EXTERNAL_REVIEW_PENDING'):
            raise AuthError('TRUST_POLICY_MODE')
        if type(policy['externally_vetted']) is not bool or not isinstance(policy['roots'],dict) or not policy['roots']:
            raise AuthError('TRUST_POLICY_EMPTY')
        if type(policy['revocations']) is not dict:raise AuthError('TRUST_REVOCATION_SCHEMA')
        if policy['policy_mode']=='FIXTURE_SIMULATED' and policy['externally_vetted']:
            raise AuthError('SIMULATED_ROOT_CANNOT_BE_VETTED')
        for name,root in policy['roots'].items():
            require_fields(root,{'public_key_b64','fixture_only','allowed_roles','not_before','not_after'},'ROOT_FIELDS')
            if type(name) is not str or len(_bytes(root['public_key_b64']))!=32 or type(root['fixture_only']) is not bool:
                raise AuthError('ROOT_KEY_INVALID')
            if not isinstance(root['allowed_roles'],list) or not set(root['allowed_roles'])<=VALID_ROLES:
                raise AuthError('ROOT_ROLE_INVALID')
            if valid_time(root['not_before'])>=valid_time(root['not_after']):raise AuthError('ROOT_TIME_INVALID')
            if root['fixture_only'] and policy['externally_vetted']:raise AuthError('FIXTURE_ROOT_CANNOT_VET_REAL')
        for serial,at in policy['revocations'].items():
            if type(serial) is not str:raise AuthError('REVOCATION_SERIAL')
            valid_time(at)
        # The current implementation has no independent external authority
        # capable of vetting a root: a JSON flag can never grant that status.
        if policy['externally_vetted']:
            raise AuthError('R47_NO_EXTERNAL_ATTESTATION_CHANNEL')
        self.policy_sha256=digest(self.policy)

    def certificate(self,certificate,role,at,reviewed,source,inst):
        require_fields(certificate,{'body','signature_b64'},'CERTIFICATE_FIELDS')
        b=certificate['body']
        require_fields(b,{'schema','serial','subject_id','public_key_b64','issuer_root_id','roles',
                          'source_page_ids','instrument_ids','not_before','not_after'},'CERT_BODY_FIELDS')
        if b['schema']!='R47-CERT-v1' or type(b['serial']) is not str or not b['serial'] or type(b['subject_id']) is not str:
            raise AuthError('CERT_IDENTITY')
        root=self.policy['roots'].get(b['issuer_root_id'])
        if root is None:raise AuthError('ANCHOR_NOT_PINNED')
        if not verify(root['public_key_b64'],b,certificate['signature_b64']):raise AuthError('CERT_SIGNATURE_INVALID')
        key=_bytes(b['public_key_b64'])
        if len(key)!=32:raise AuthError('CERT_KEY_INVALID')
        if type(b['roles']) is not list or role not in b['roles'] or not set(b['roles'])<=set(root['allowed_roles']):
            raise AuthError('ROLE_NOT_AUTHORIZED')
        if type(b['source_page_ids']) is not list or source not in b['source_page_ids']:
            raise AuthError('SOURCE_NOT_AUTHORIZED')
        if type(b['instrument_ids']) is not list or inst not in b['instrument_ids']:
            raise AuthError('INSTRUMENT_NOT_AUTHORIZED')
        st,en=valid_time(b['not_before']),valid_time(b['not_after'])
        root_start,root_end=valid_time(root['not_before']),valid_time(root['not_after'])
        if not (root_start<=st<=at<=en<=root_end and st<=reviewed<=en):
            raise AuthError('CERT_OR_ROOT_EXPIRED_OR_NOT_YET_VALID')
        revoked=self.policy['revocations'].get(b['serial'])
        if revoked and valid_time(revoked)<=reviewed:raise AuthError('CERT_REVOKED')
        return b

    def assess(self,report,attestation,reviewed_at,r46_decision,prior_event_ids:set):
        errors=[];signature_count=0;custody_count=0
        def check():
            nonlocal signature_count,custody_count
            require_fields(attestation,{'schema','report_id','certificates','calibration_proof','report_proof','custody_events'},'ENVELOPE_FIELDS')
            if attestation['schema']!=SCHEMA or attestation['report_id']!=report['report_id']:
                raise AuthError('ENVELOPE_REPORT_ID_MISMATCH')
            cs=attestation['certificates'];require_fields(cs,{'operator','calibrator','custodian_origin','custodian_receiver'},'CERT_SET_FIELDS')
            obs=valid_time(report['observed_at']);review=valid_time(reviewed_at)
            submitted=valid_time(report['submitted_at'])
            source=report['source_page_id'];inst=report['instrument']['instrument_id']
            op=report['operator']['operator_id']
            certs={}
            rolemap={'operator':'OPERATOR','calibrator':'CALIBRATOR',
                     'custodian_origin':'CUSTODIAN','custodian_receiver':'CUSTODIAN'}
            for key,role in rolemap.items():
                certs[key]=self.certificate(cs[key],role,obs,review,source,inst)
                signature_count+=1  # signature of certificate by pinned root
            if certs['operator']['subject_id']!=op:raise AuthError('OPERATOR_SUBJECT_MISMATCH')
            if certs['custodian_receiver']['subject_id']!=op:raise AuthError('FINAL_CUSTODIAN_OPERATOR_MISMATCH')
            if certs['custodian_origin']['subject_id']==certs['custodian_receiver']['subject_id']:
                raise AuthError('CUSTODIAN_DISTINCTNESS_REQUIRED_FOR_TRANSFER_FIXTURE')
            # Calibration attestation is signed by the authorized calibrator.
            p=attestation['calibration_proof'];require_fields(p,{'body','signature_b64'},'CALIBRATION_PROOF_FIELDS')
            b=p['body']
            require_fields(b,{'schema','instrument_id','instrument_serial','calibration_id',
                               'calibration_artifact_sha256','calibration_start','calibration_expires',
                               'signed_at','calibrator_id'},'CALIBRATION_PROOF_BODY')
            i=report['instrument']
            if b['schema']!='R47-CALIBRATION-v1' or b['instrument_id']!=inst or b['instrument_serial']!=i['serial'] or b['calibration_id']!=i['calibration_id'] or b['calibration_artifact_sha256']!=i['certificate_sha256'] or b['calibration_start']!=i['calibration_start'] or b['calibration_expires']!=i['calibration_expires'] or b['calibrator_id']!=certs['calibrator']['subject_id']:
                raise AuthError('CALIBRATION_CONTENT_OR_INSTRUMENT_MISMATCH')
            if not (valid_time(b['calibration_start'])<=obs<=valid_time(b['calibration_expires'])):
                raise AuthError('CALIBRATION_EXPIRED_AT_MEASUREMENT')
            if valid_time(b['signed_at'])>obs:raise AuthError('CALIBRATION_ATTESTED_AFTER_READING')
            if not valid_time(certs['calibrator']['not_before'])<=valid_time(b['signed_at'])<=valid_time(certs['calibrator']['not_after']):
                raise AuthError('CALIBRATION_SIGNED_OUTSIDE_CERTIFICATE')
            if not verify(certs['calibrator']['public_key_b64'],b,p['signature_b64']):
                raise AuthError('CALIBRATION_SIGNATURE_INVALID')
            signature_count+=1
            # A hash matching a supplied document is not enough. The signer
            # commits to the report AND exact document hash and claimed source.
            p=attestation['report_proof'];require_fields(p,{'body','signature_b64'},'REPORT_PROOF_FIELDS')
            b=p['body']
            require_fields(b,{'schema','report_id','report_sha256','measurement_sha256','sample_id',
                               'instrument_id','operator_id','source_page_id','signed_at'},'REPORT_PROOF_BODY')
            if b['schema']!='R47-REPORT-SIGNATURE-v1' or b['report_id']!=report['report_id'] or b['report_sha256']!=digest(report) or b['measurement_sha256']!=report['artifacts']['measurement']['claimed_sha256'] or b['sample_id']!=report['sample_id'] or b['instrument_id']!=inst or b['operator_id']!=op or b['source_page_id']!=source:
                raise AuthError('REPORT_SIGNATURE_CONTENT_BINDING')
            if not (obs<=valid_time(b['signed_at'])<=submitted):raise AuthError('REPORT_SIGN_TIME_INVALID')
            if not verify(certs['operator']['public_key_b64'],b,p['signature_b64']):
                raise AuthError('OPERATOR_REPORT_SIGNATURE_INVALID')
            signature_count+=1
            # Signed custody chain. Handoff must be acknowledged by receiver.
            events=attestation['custody_events']
            if type(events) is not list or not (4<=len(events)<=64):raise AuthError('CUSTODY_LENGTH')
            prev='R47-CUSTODY-GENESIS:'+report['sample_id'];holder=None;pending=None
            last_time=None;measured=False;seen=set()
            for index,event in enumerate(events,1):
                require_fields(event,{'body','signature_b64'},'CUSTODY_EVENT_FIELDS')
                row=event['body']
                require_fields(row,{'schema','seq','event_id','sample_id','at','kind','from_actor','to_actor',
                                    'instrument_id','measurement_sha256','previous_hash','signer_id'},'CUSTODY_BODY_FIELDS')
                if row['schema']!='R47-CUSTODY-v1' or type(row['seq']) is not int or row['seq']!=index:
                    raise AuthError('CUSTODY_SEQUENCE_INVALID')
                if row['event_id'] in seen or row['event_id'] in prior_event_ids:
                    raise AuthError('CUSTODY_EVENT_DUPLICATE')
                if type(row['event_id']) is not str or not row['event_id'].startswith('SBX-R47-'):
                    raise AuthError('CUSTODY_EVENT_ID_INVALID')
                seen.add(row['event_id'])
                if row['sample_id']!=report['sample_id'] or row['previous_hash']!=prev:
                    raise AuthError('CUSTODY_SAMPLE_OR_PREVIOUS_HASH')
                now=valid_time(row['at'])
                if last_time is not None and now<=last_time:raise AuthError('CUSTODY_NONMONOTONIC')
                if now>submitted:raise AuthError('CUSTODY_EVENT_AFTER_SUBMISSION')
                last_time=now
                kind=row['kind']
                if index==1:
                    if kind!='COLLECTED' or row['from_actor']!='NONE' or row['to_actor']!=certs['custodian_origin']['subject_id']:
                        raise AuthError('CUSTODY_INITIAL_COLLECTION_INVALID')
                    subject=certs['custodian_origin'];holder=row['to_actor']
                elif pending is not None:
                    if kind!='RECEIVED' or row['from_actor']!=pending or row['to_actor']!=pending:
                        raise AuthError('CUSTODY_HANDOFF_NOT_ACKNOWLEDGED')
                    subject=certs['custodian_receiver'];holder=pending;pending=None
                elif kind=='TRANSFERRED':
                    if measured or row['from_actor']!=holder or row['to_actor']!=certs['custodian_receiver']['subject_id']:
                        raise AuthError('CUSTODY_TRANSFER_SENDER_OR_RECEIVER')
                    subject=certs['custodian_origin'];pending=row['to_actor']
                elif kind=='MEASURED':
                    if measured or holder!=op or row['from_actor']!=op or row['to_actor']!=op or now!=obs:
                        raise AuthError('CUSTODY_MEASURE_OPERATOR_OR_TIME')
                    subject=certs['custodian_receiver'];measured=True
                    if row['instrument_id']!=inst or row['measurement_sha256']!=b_report_doc:
                        raise AuthError('CUSTODY_MEASUREMENT_INSTRUMENT_OR_DOC')
                else:raise AuthError('CUSTODY_UNAUTHORIZED_TRANSITION')
                if row['signer_id']!=subject['subject_id']:
                    raise AuthError('CUSTODY_SIGNER_ID')
                if not valid_time(subject['not_before'])<=now<=valid_time(subject['not_after']):
                    raise AuthError('CUSTODY_EVENT_OUTSIDE_SIGNER_CERTIFICATE')
                if kind!='MEASURED' and (row['instrument_id'] is not None or row['measurement_sha256'] is not None):
                    raise AuthError('CUSTODY_EARLY_MEASUREMENT_ASSERTION')
                if not verify(subject['public_key_b64'],row,event['signature_b64']):
                    raise AuthError('CUSTODY_SIGNATURE_INVALID')
                signature_count+=1;custody_count+=1
                prev=digest(event)
            if pending is not None or not measured or events[-1]['body']['kind']!='MEASURED':
                raise AuthError('CUSTODY_NOT_FINALIZED_BY_MEASUREMENT')
            if valid_time(events[0]['body']['at'])>obs:raise AuthError('CUSTODY_COLLECTION_AFTER_MEASUREMENT')
            return seen
        b_report_doc=(report.get('artifacts',{}).get('measurement',{}) or {}).get('claimed_sha256')
        event_ids=[]
        try:
            if type(attestation) is not dict or len(canonical(attestation))>MAX_ENVELOPE:
                raise AuthError('MALFORMED_OR_OVERSIZE_ENVELOPE')
            if type(r46_decision) is not dict or r46_decision.get('report_id')!=report.get('report_id'):
                raise AuthError('R46_DECISION_NOT_BOUND')
            event_ids=sorted(check())
        except (AuthError,TypeError,KeyError,ValueError,OverflowError,RecursionError) as exc:
            errors=[str(exc) if str(exc) else type(exc).__name__]
        parent_ok=r46_decision['status'] in ('SYNTHETIC_QA_PASS','ELIGIBLE_FOR_INDEPENDENT_REVIEW')
        if errors:status='QUARANTINE_AUTHENTICITY'
        elif not parent_ok:status='QUARANTINE_R46_PRECHECK'
        elif self.policy['policy_mode']=='FIXTURE_SIMULATED':status='SIMULATED_CRYPTO_VALID_NOT_REAL'
        elif not self.policy['externally_vetted']:status='QUARANTINE_UNVETTED_ANCHOR'
        else:status='DOCUMENT_SIGNED_REVIEW_REQUIRED'
        # None of the statuses authorizes empirical certification or writing.
        return {'report_id':report.get('report_id'),'status':status,'r46_status':r46_decision['status'],
                'document_hash_validated_by_r46':(type(r46_decision.get('document_sha256')) is str and not any('DIGEST_MISMATCH' in x for x in r46_decision.get('problems',[]))),
                'valid_signatures_under_local_policy':(not errors),'valid_signature_count':signature_count,
                'r46_document_content_binding_ok':(not any('ARTIFACT_CONTENT_BINDING_MISMATCH' in x or 'ARTIFACT_JSON_UNREADABLE' in x for x in r46_decision.get('problems',[]))),
                'custody_event_count':custody_count,'custody_event_ids':event_ids,
                'reasons':errors if errors else ([] if status=='DOCUMENT_SIGNED_REVIEW_REQUIRED' else
                      ['ONLY_SIMULATED_TRUST_ANCHORS' if status=='SIMULATED_CRYPTO_VALID_NOT_REAL' else
                       'R46_PRECHECK_BLOCK' if status=='QUARANTINE_R46_PRECHECK' else 'EXTERNAL_ANCHOR_VETTING_ABSENT']),
                'missing_to_accept_physical_measurement':[
                    'INDEPENDENT_REAL_WORLD_ISSUER_IDENTITY_AND_AUTHORIZATION',
                    'INDEPENDENT_CERTIFICATION_AND_REVOCATION_CHECK',
                    'INSTRUMENT_AND_CUSTODY_REAL_WORLD_ATTESTATION',
                    'PROVEN_MEASUREMENT_UNCERTAINTY_AND_METHOD',
                    'INDEPENDENT_PHYSICAL_REVIEW','CRAFT_C19_WRITER_FENCING_AND_PRODUCTION_GATE'],
                'physically_verified':False,'official_rec_id':None,'stock_effect':0,
                'material_promotion_allowed':False,'trust_policy_sha256':self.policy_sha256}

class AuthenticityVault:
    """R46 parent + append-only R47 decisions committed as ONE local transaction.

    Lock serializes threads within this process ONLY; no cross-process writer claim.
    """
    def __init__(self,recipes,sources,policy):
        self.parent=EvidenceVault(recipes,sources)
        self.trust=TrustGate(policy)
        self.events=[];self.head=GENESIS;self._fingerprint=digest(self.events)
        self._lock=threading.RLock()

    def _verify_base(self):
        if digest(self.events)!=self._fingerprint or (self.events[-1]['hash'] if self.events else GENESIS)!=self.head:
            raise AuthError('LOCAL_R47_JOURNAL_MUTATED')
        if digest(self.trust.policy)!=self.trust.policy_sha256:
            raise AuthError('TRUST_POLICY_CHANGED')
        if not self.parent.audit()['ok']:raise AuthError('R46_PARENT_AUDIT_FAILED')
        if len(self.parent.events)!=len(self.events):raise AuthError('PARENT_CHILD_EVENT_COUNT_MISMATCH')

    @staticmethod
    def _prior_ids(rows):
        ids=set()
        for e in rows:ids.update(e['payload']['decision']['custody_event_ids'])
        return ids

    def _stage_one(self,parent,entries,report,attestation,reviewed_at):
        if type(report) is not dict or type(attestation) is not dict:
            raise AuthError('REPORT_AND_ATTESTATION_OBJECTS_REQUIRED')
        fingerprint=digest({'report':report,'attestation':attestation,'reviewed_at':reviewed_at})
        rid=report.get('report_id')
        if type(rid) is not str:raise AuthError('REPORT_ID_REQUIRED')
        for entry in entries:
            p=entry['payload']
            if p['report_id']==rid:
                if p['request_sha256']!=fingerprint:raise AuthError('IDEMPOTENCY_CONFLICT')
                return {**copy.deepcopy(p['decision']),'idempotent_replay':True,'receipt_hash':entry['hash']},False
        parent_receipt=parent.submit(report,reviewed_at)
        decision=self.trust.assess(report,attestation,reviewed_at,parent_receipt,self._prior_ids(entries))
        if decision['status'] not in STATUS:raise AuthError('UNKNOWN_AUTH_STATUS')
        payload={'report_id':rid,'request_sha256':fingerprint,'report':copy.deepcopy(report),
                 'attestation':copy.deepcopy(attestation),'reviewed_at':reviewed_at,
                 'r46_receipt_hash':parent_receipt['receipt_hash'],'decision':decision}
        entry={'seq':len(entries)+1,'previous_hash':entries[-1]['hash'] if entries else GENESIS,'payload':payload}
        entry['hash']=digest({'previous_hash':entry['previous_hash'],'payload':payload})
        entries.append(entry)
        return {**copy.deepcopy(decision),'idempotent_replay':False,'receipt_hash':entry['hash']},True

    def submit_batch(self,items,reviewed_at,inject=None):
        if type(items) is not list or not items or len(items)>50:raise AuthError('BATCH_SIZE')
        batch_ids=[i.get('report',{}).get('report_id') if type(i) is dict and type(i.get('report')) is dict else None for i in items]
        if len(set(map(repr,batch_ids)))!=len(items):raise AuthError('BATCH_DUPLICATE_REPORT_IDS')
        with self._lock:
            self._verify_base()
            before_head=self.head;before_parent=self.parent.head
            staged_parent=copy.deepcopy(self.parent)
            staged_entries=copy.deepcopy(self.events)
            receipts=[]
            for item in items:
                require_fields(item,{'report','attestation'},'BATCH_ITEM_SCHEMA')
                receipt,_=self._stage_one(staged_parent,staged_entries,item['report'],item['attestation'],reviewed_at)
                receipts.append(receipt)
            if inject in ('AFTER_STAGE_BEFORE_COMMIT','MID_BATCH_ABORT'):
                raise InjectedFailure('R47_'+inject)
            result=self._audit_parts(staged_parent,staged_entries)
            if not result['ok']:raise AuthError('STAGED_R47_AUDIT_FAILED:'+repr(result['issues']))
            self.parent=staged_parent;self.events=staged_entries
            self.head=staged_entries[-1]['hash'] if staged_entries else GENESIS
            self._fingerprint=digest(self.events)
            return {'receipts':receipts,'batch_count':len(items),'events':len(self.events),
                    'r47_head':self.head,'r46_head':self.parent.head,
                    'previous_r47_head':before_head,'previous_r46_head':before_parent,
                    'official_stock_effect':0,'physical_measurements_verified':0}

    def submit(self,report,attestation,reviewed_at,inject=None):
        result=self.submit_batch([{'report':report,'attestation':attestation}],reviewed_at,inject)
        return result['receipts'][0]

    def _audit_parts(self,parent,entries):
        problems=[];p=parent.audit();prev=GENESIS;seen=set();ids=set()
        if not p['ok']:problems.append('R46_AUDIT_FAILED')
        if len(entries)!=len(parent.events):problems.append('PARENT_CHILD_LENGTH_MISMATCH')
        for ix,e in enumerate(entries):
            try:
                if set(e)!={'seq','previous_hash','payload','hash'} or e['seq']!=ix+1 or e['previous_hash']!=prev or e['hash']!=digest({'previous_hash':prev,'payload':e['payload']}):
                    problems.append('R47_CHAIN_INVALID_'+str(ix));break
                pp=e['payload'];rid=pp['report_id']
                if rid in seen:problems.append('R47_REPORT_ID_REUSED')
                seen.add(rid)
                if pp['request_sha256']!=digest({'report':pp['report'],'attestation':pp['attestation'],'reviewed_at':pp['reviewed_at']}):
                    problems.append('R47_REQUEST_TAMPER_'+str(ix))
                if ix>=len(parent.events):problems.append('MISSING_R46_PARENT');break
                parent_row=parent.events[ix]
                if pp['r46_receipt_hash']!=parent_row['hash'] or digest(pp['report'])!=parent_row['payload']['request_hash']:
                    problems.append('R46_R47_RECEIPT_NOT_BOUND_'+str(ix))
                calc=self.trust.assess(pp['report'],pp['attestation'],pp['reviewed_at'],parent_row['payload']['decision'],ids)
                if calc!=pp['decision']:problems.append('AUTH_DECISION_REPLAY_MISMATCH_'+str(ix))
                ids.update(calc['custody_event_ids']);prev=e['hash']
            except (KeyError,TypeError,ValueError):problems.append('R47_REPLAY_EXCEPTION_'+str(ix));break
        return {'ok':not problems,'issues':sorted(set(problems)),'events':len(entries),
                'r47_head':prev,'r46_head':parent.head,'trust_policy_sha256':self.trust.policy_sha256}

    def audit(self):
        with self._lock:
            result=self._audit_parts(self.parent,self.events)
            if self.head!=result['r47_head']:
                result['ok']=False;result['issues'].append('HEAD_MISMATCH')
            if digest(self.events)!=self._fingerprint:
                result['ok']=False;result['issues'].append('JOURNAL_BYTES_CHANGED')
            if digest(self.trust.policy)!=self.trust.policy_sha256:
                result['ok']=False;result['issues'].append('TRUST_POLICY_CHANGED')
            return result

    def snapshot(self,path,inject=None):
        with self._lock:
            if not self.audit()['ok']:raise AuthError('INVALID_STATE_CANNOT_SNAPSHOT')
            state={'schema':SNAPSHOT_SCHEMA,'namespace':NAMESPACE,'r47_genesis':GENESIS,
                   'trust_policy':self.trust.policy,'trust_policy_sha256':self.trust.policy_sha256,
                   'parent':{'recipes':self.parent.recipes,'sources':self.parent.sources,
                             'r46_genesis':self.parent.events[0]['previous_hash'] if self.parent.events else self.parent.head,
                             'recipes_sha256':self.parent.recipe_hash,'sources_sha256':self.parent.source_hash,
                             'head':self.parent.head,'events':self.parent.events},
                   'r47_head':self.head,'events':self.events}
            state['snapshot_sha256']=digest(state)
            p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
            tmp=p.with_suffix(p.suffix+'.tmp')
            tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
            if inject=='BEFORE_RENAME':raise InjectedFailure('R47_SNAPSHOT_ABORT_BEFORE_RENAME')
            tmp.replace(p)
            return state['snapshot_sha256']

    @classmethod
    def restore(cls,path,expected_policy_sha256,expected_r47_head=None):
        if not expected_policy_sha256:raise AuthError('EXTERNAL_TRUST_POLICY_ANCHOR_REQUIRED')
        state=json.loads(Path(path).read_text(encoding='utf8'))
        sig=state.pop('snapshot_sha256',None)
        if sig!=digest(state):raise AuthError('SNAPSHOT_SHA256_INVALID')
        if state.get('schema')!=SNAPSHOT_SCHEMA or state.get('namespace')!=NAMESPACE or state.get('r47_genesis')!=GENESIS:
            raise AuthError('SNAPSHOT_SCHEMA_INVALID')
        if state.get('trust_policy_sha256')!=expected_policy_sha256 or digest(state.get('trust_policy'))!=expected_policy_sha256:
            raise AuthError('EXTERNAL_TRUST_POLICY_MISMATCH')
        parent=state['parent'];obj=cls(parent['recipes'],parent['sources'],state['trust_policy'])
        if (obj.parent.recipe_hash!=parent['recipes_sha256'] or obj.parent.source_hash!=parent['sources_sha256'] or
            parent['r46_genesis']!=obj.parent.head and parent['events'] and parent['r46_genesis']!=parent['events'][0]['previous_hash']):
            raise AuthError('PARENT_ANCHOR_INCONSISTENT')
        obj.parent.events=parent['events'];obj.parent.head=parent['head']
        obj.parent._events_fingerprint=digest(obj.parent.events)
        obj.events=state['events'];obj.head=state['r47_head'];obj._fingerprint=digest(obj.events)
        if expected_r47_head is None and obj.events:
            raise AuthError('EXTERNAL_JOURNAL_HEAD_ANCHOR_REQUIRED')
        if expected_r47_head is not None and obj.head!=expected_r47_head:
            raise AuthError('EXTERNAL_JOURNAL_HEAD_MISMATCH')
        result=obj.audit()
        if not result['ok']:raise AuthError('RESTORE_AUDIT_FAILED:'+repr(result['issues']))
        return obj
