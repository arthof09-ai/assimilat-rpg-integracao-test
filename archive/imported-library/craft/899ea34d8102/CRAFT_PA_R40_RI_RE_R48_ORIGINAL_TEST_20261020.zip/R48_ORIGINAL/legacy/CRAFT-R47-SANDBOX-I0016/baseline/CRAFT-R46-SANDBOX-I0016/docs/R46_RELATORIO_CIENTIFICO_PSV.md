# PSV — Relatório funcional CRAFT R46 · CM-000002-I0016

**Operação:** CM-000002-WS0001 / OP-ARQ-RIN-REC-01, domínio de execução `SBX-CRAFT-R46-I0016` estritamente desvinculado de `CRAFT/F5` material.
**Ordem:** Mestre R46 + IBX-55; ordem do Mestre prevalece. **Conexão:** Mestre-side. **Dia do experimento:** 09/10/2026.

## 1. Recuperação e ANTES

- R45 ZIP preservado SHA-256 `5b36b0aea5f7c6abf0275e93e192a8331201f38133c2275c270c59a788718946` (50/50 entradas de manifesto + CRC + 18/18 hash R44 integrado).
- R44 ZIP também preservado SHA-256 `900452bb24f398d1968e57ddbfabc0359fb93502cfd21eaf48e44ecfffd6aff3`.
- Execução em cópia extraída: 52/52 regressões R44; 64/64 testes R45; 250/250 stress R45, 52 rollbacks, 0 invariantes falhos; **nenhum reinício ou alteração de código histórico**.
- A IBX-55 foi fisicamente lida e recebeu ACK **por comentário**, com readback, sem alterar a propriedade Estado/Leitura. IBX-38 estava NOVA e sem ACK; proteção externa de C19 não demonstrada, sem STOP-ACK/RELEASE.
- R44 DEPOIS: comentário no thread da OP, **não** incluído no corpo; R45 recibo: comentário na mesma discussão. R46 ANTES: registro em comentário na OP. O R44 não foi duplicado.

## 2. Sistema funcional novo R46

### Contrato de laudo

`schema`, `report_id`, `recipe_key` (somente Tábua/Mica), `evidence_kind`, `source_page_id`, `source_crn_id`, `sample_id`, `lot_ids`, `operator`, `instrument`, `observed_at`, `submitted_at`, `conditions`, `custody`, `artifacts` e `observations`. Cada leitura contém identificador, valor, unidade, incerteza absoluta, instrumento, amostra e instante. Instrumento: ID, série, certificado, calibração início/fim, dimensões e piso sintético de incerteza. Cadeia de custódia: ID, amostra, data, ator, ação e SHA do anexo. Quatro anexos com bytes acessíveis e digest: medição, calibração, custódia, atestação do operador.

A validação testa SHA-256 **dos bytes** e também faz comparação entre conteúdo decodificado e campos estruturados — não aceita laudo com digest coerente para outro valor/amostra. Documentos inteiramente reescritos com novo hash continuam sem autenticação externa; por isso nunca entram automaticamente como dados físicos verificados.

Classificação explícita: `SYNTHETIC_QA_PASS`, `SYNTHETIC_QA_FAIL`, `SYNTHETIC_INDETERMINATE`, `QUARANTINE_INCOMPLETE`, `QUARANTINE_SUSPECT`, `QUARANTINE_CALIBRATION`, `QUARANTINE_INDETERMINATE`, `ELIGIBLE_FOR_INDEPENDENT_REVIEW`. **Não existe transição `PHYSICALLY_VERIFIED` neste motor.** Toda saída tem `execution_authorized=false`, `official_rec_id=null`, `physical_measurement_verified=false`, `stock_effect=0`.

### QA de engenharia

Faixas da Tábua, definição de 10 mm e Mica 0,1 mm continuam **PROPOSTAS** R42/R44, não tolerâncias homologadas. Para medida `x ± u`, o motor aprova somente se **todo** o intervalo pertence à faixa; separação total gera FAIL; cruzamento de fronteira gera `INDETERMINATE`. Converter unidade e incerteza juntas para a mesma base, comparar piso de instrumento na base, não na unidade lida. `bool` e `count` usam regras distintas.

### Execução e recuperação

Journal append-only com `seq`, `previous_hash`, SHA-256 do payload e decisão reexecutável; `report_id` repetido idêntico é replay sem evento novo, id repetido alterado é recusado. Detecta reaproveitamento de `reading_id` ou documento entre relatórios. Pré-commit fault injection deixa journal intacto. `submit_batch` recebe até 100 laudos com publicação atômica de todo lote, preservando decisões de quarentena. Snapshot tem hash, versão, registros de receitas/fontes, journal e head; restauração exige replay semântico e aceita âncora externa (`expected_head`) para impedir reconstrução autodeclarada de cadeia alterada. Snapshots são substituídos via arquivo temporário e rename local.

Verificação de integridade rápida por commit e reexecução semântica completa a cada 25 eventos, ao gerar snapshot, ao restaurar e nos readbacks finais. **Esta é verificação local com limites; não é um serviço transacional distribuído, storage imutável ou assinatura com chave externa**.

## 3. Resultados observados de software (nenhuma medição física)

- Regressão R44: **52/52**. R45: **64/64**.
- Suíte funcional R46: **70/70** aprovações, inclusive ingestão em lote e recuperação.
- Stress sintético R46 seed 460016: **300/300 tentativas**, 235 eventos, 65 falhas injetadas com rollback, 20 replays idempotentes, 120 quarentenas, 17 alegações apenas elegíveis a revisão, 26 adulterações de conteúdo detectadas, 0 violações de invariantes, snapshot restaurado. São contagens de teste, não frequências de laboratório.
- Mutações sintéticas seed 460017: **330/330 tentativas**, 315 quarentenas, 15 recusas limpas, 0 exceções sem tratamento, 0 liberações materiais.
- Demonstração: 9 laudos, incluindo 2 sintéticos aprovados, 1 alegação autocoerente mas ainda **NÃO VERIFICADA FISICAMENTE**, 2 suspeitos, 2 incompletos, 1 calibração vencida e 1 sintético indeterminado.
- Comparadores pareados R45 reutilizados: cinco pares fictícios para Tábua vs gabarito comum e cinco para Mica vs calço comum, n=5 por comparação. Condições, ID de amostra, unidade, custo UCS_SIM, precisão/durabilidade e intervalos verificados como **FIXTURES**. Dois casos `SYNTHETIC_TRADEOFF_NO_GLOBAL_WINNER`; nenhum vencedor comercial/empírico.

## 4. Certeza e pendências

- **VERIFICADO (software):** arquivos/hashes/regressões/stress/classificações/readbacks descritos; journal/snapshot restauráveis.
- **SINTÉTICO:** todos os números, amostras, instrumentos e laudos testados; alegações `MEASURED_CLAIM_UNVERIFIED` são objetos fictícios para testar a fronteira, nunca documentos recebidos de laboratório externo.
- **PROPOSTO:** tolerâncias, plano de ensaio, metodologia e comparadores.
- **MEDIDO/VERIFICADO FISICAMENTE:** 0 laudos, 0 peças físicas.
- **MATERIALIZADO CANÔNICO:** 0/30 RC5, 0 produtos; 2/2 modelos experimentais herdados de R44, sem terceira receita.
- **PENDENTE:** amostras legítimas, cadeia de custódia independente, assinaturas/calibrações reais, validação do especialista/operador, qualidade, custos MED/mercado, processo real, avaliação de substitutos, parâmetros de confiança estatística, C19 fencing e autoridade de promoção.

## 5. Interlocks

`CRAFT/F5=P0/RED`; `REC-ID official=0`, `writer/epoch/lease/GREEN=0`; `C19-021 UNKNOWN-SIDE-EFFECT`, `IBX-38= NOVA/SEM ACK`, `NAC-PASS MATERIAL=HOLD`. O ACK da IBX-55 é comprovado em comentário, mas estado da propriedade pode permanecer NOVA até atualização formal. Nenhuma ação de Party/O Primeiro/REC-LIB/Runtime realizada.

## 6. NEXT R47 — fronteira exata

1. Recuperar ZIP R46 e comprovar SHA/manifest/CRC, 52+64+70 testes e stress 300+330 em extração limpa; preservar baseline intocado.
2. Construir **verificador independente real** fora do classificador, com autoridade verificável de laboratório/operador, identidade dos certificados, prova de posse de bytes primários, calibração rastreável e assinatura/atestação; usar primeiro apenas prova documental Mestre-side, nunca declarar físico só por SHA.
3. Implementar análise estatística de amostragem e variância/predefinição de efeito mínimo antes de alegar vantagem de Tábua/Mica; rejeitar pareamentos contaminados por condições divergentes.
4. Não abrir nova receita, não usar dados de fixture como estoque, não executar C19-021. Se IBX38 tiver novo ato técnico, verificar o write point e U-SUCCESSION separadamente.
5. Após evidência real e autorização, prosseguir apenas com ensaio não oficial; para RC5 material, gates externos completos e NAC-PASS independente.

**Gate documental:** recibos Notion / pacote e readbacks; **NAC-PASS terminal/material = HOLD**. Arquivo pode ser integralmente descartado sem afetar fichas existentes.
