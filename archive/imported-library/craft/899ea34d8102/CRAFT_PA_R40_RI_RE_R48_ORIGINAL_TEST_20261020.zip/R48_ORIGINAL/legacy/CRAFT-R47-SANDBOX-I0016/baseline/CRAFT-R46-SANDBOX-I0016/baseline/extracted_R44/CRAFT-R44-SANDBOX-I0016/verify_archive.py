"""Verify shipped relative-path SHA-256 manifest and optionally a ZIP CRC/inclusion."""
import hashlib
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/'MANIFEST_SHA256.txt'

def check(root=ROOT, archive_path=None):
    text= (root/'MANIFEST_SHA256.txt').read_text(encoding='utf8')
    entries=[]
    for line in text.splitlines():
        if not line or line.startswith('#'):continue
        sha,rel=line.split('  ',1)
        f=root/rel
        if not f.is_file() or '..' in Path(rel).parts:raise ValueError('MISSING_OR_UNSAFE_MANIFEST_ENTRY: '+rel)
        actual=hashlib.sha256(f.read_bytes()).hexdigest()
        if actual!=sha:raise ValueError(f'SHA256_MISMATCH: {rel}')
        entries.append(rel)
    if archive_path:
        with zipfile.ZipFile(archive_path) as z:
            if z.testzip() is not None:raise ValueError('ZIP_CRC_FAILURE')
            want={'CRAFT-R44-SANDBOX-I0016/'+rel for rel in entries}
            want.add('CRAFT-R44-SANDBOX-I0016/MANIFEST_SHA256.txt')
            if set(z.namelist())!=want:raise ValueError('ZIP_SET_MISMATCH')
            for rel in entries:
                a=z.read('CRAFT-R44-SANDBOX-I0016/'+rel)
                if hashlib.sha256(a).hexdigest()!=hashlib.sha256((root/rel).read_bytes()).hexdigest():
                    raise ValueError('ZIP_ENTRY_BYTES_MISMATCH:'+rel)
    return {'manifest_files_pass':len(entries),'crc':'PASS' if archive_path else 'NOT_APPLICABLE',
            'archive_set_bytes':'PASS' if archive_path else 'NOT_APPLICABLE'}

if __name__=='__main__':
    archive=Path(sys.argv[1]) if len(sys.argv)>1 else None
    print(check(ROOT,archive))
