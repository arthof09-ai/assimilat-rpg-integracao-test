"""Deterministic QA guardband property and instrument invariants."""
import copy,random,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from r45_engine import LabBench,load_recipes,paired_comparison,SandboxError
from fixture_factory import get_fixture,get_registries,readings,DEFAULT_TIME
R=load_recipes(ROOT/'r44_legacy/recipes');F=get_fixture();G=get_registries()
class QAProperties(unittest.TestCase):
 def test_001_200_random_guardband_outside_never_pass(self):
  rng=random.Random(450017)
  for j in range(200):
   e=LabBench(R,F['lots'],G['instruments'],G['sources'])
   aid=f'SBX-PROP-{j:03d}'
   val=rng.uniform(117,123);u=rng.choice([0.05,0.1,0.2,0.5])
   obs=readings(R['SBX-TLI-R44-v1'],F['tli_good_measurements'],['SBX-SLATE-GOOD-01'],aid,
                {'length_mm':{'value':val,'uncertainty_abs':u}})
   o=e.run('SBX-TLI-R44-v1',aid,['SBX-SLATE-GOOD-01'],obs,F['tli_tools'],F['tli_skills'],DEFAULT_TIME)
   should_pass=val-u>=119 and val+u<=121
   self.assertEqual(o['status']=='EXPERIMENTAL_QA_PASS',should_pass,(j,val,u))
   self.assertTrue(e.audit()['ok'])
 def test_002_false_claim_rejects_bad_calibration_class(self):
  x=copy.deepcopy(G['instruments']);x['SBX-CALIPER-01']['calibration_class']='REAL_CERTIFIED_NO_PROOF'
  e=LabBench(R,F['lots'],x,G['sources']);aid='SBX-BAD-CERT'
  obs=readings(R['SBX-TLI-R44-v1'],F['tli_good_measurements'],['SBX-SLATE-GOOD-01'],aid)
  with self.assertRaisesRegex(SandboxError,'INSTRUMENT_NOT_VERIFIED'):e.run('SBX-TLI-R44-v1',aid,['SBX-SLATE-GOOD-01'],obs,F['tli_tools'],F['tli_skills'],DEFAULT_TIME)
 def test_003_non_zero_measurement_count_uncertainty_rejected(self):
  e=LabBench(R,F['lots'],G['instruments'],G['sources']);aid='SBX-COUNT-U'
  obs=readings(R['SBX-TLI-R44-v1'],F['tli_good_measurements'],['SBX-SLATE-GOOD-01'],aid,{'markings_repeat_count':{'uncertainty_abs':1}})
  with self.assertRaisesRegex(SandboxError,'INVALID_EXACT_COUNT'):e.run('SBX-TLI-R44-v1',aid,['SBX-SLATE-GOOD-01'],obs,F['tli_tools'],F['tli_skills'],DEFAULT_TIME)
 def test_004_evidence_anchor_safeguards_random_mutations(self):
  e=LabBench(R,F['lots'],G['instruments'],G['sources']);aid='SBX-PROP-TAMPER'
  obs=readings(R['SBX-TLI-R44-v1'],F['tli_good_measurements'],['SBX-SLATE-GOOD-01'],aid)
  e.run('SBX-TLI-R44-v1',aid,['SBX-SLATE-GOOD-01'],obs,F['tli_tools'],F['tli_skills'],DEFAULT_TIME)
  e.provenance_events[0]['event']['qa_verdicts']['length_mm']['verdict']='PASS_FAKE'
  self.assertFalse(e.audit()['ok'])
 def test_005_comparison_inconsistent_unit_across_pairs_rejected(self):
  import json
  c=json.loads((ROOT/'fixtures/comparisons_synthetic.json').read_text())['comparisons']['tli_vs_common_board']
  t=copy.deepcopy(c['pairs']);t[3]['alternative']['flatness_mm']['unit']='cm';t[3]['candidate']['flatness_mm']['unit']='cm'
  with self.assertRaisesRegex(SandboxError,'CROSS_TRIAL_UNIT_DRIFT'):paired_comparison(t,c['metrics'])
 def test_006_negative_comparison_metric_rejected(self):
  import json
  c=json.loads((ROOT/'fixtures/comparisons_synthetic.json').read_text())['comparisons']['mica_vs_common_shim']
  t=copy.deepcopy(c['pairs']);t[0]['candidate']['cost_ucs_sim']['value']=-1
  with self.assertRaisesRegex(SandboxError,'NEGATIVE_METRIC'):paired_comparison(t,c['metrics'])
