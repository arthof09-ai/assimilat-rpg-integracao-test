"""Single reproducible, synthetic R45 demonstration. Does not contact external systems."""
from __future__ import annotations
import copy,json
from pathlib import Path
from r45_engine import LabBench,paired_comparison,SimulatedCrash,digest,load_recipes,quarantine_claimed_measurements
from fixture_factory import get_fixture,get_registries,readings,DEFAULT_TIME
ROOT=Path(__file__).resolve().parent
R=load_recipes(ROOT/'r44_legacy/recipes');F=get_fixture();REG=get_registries()
bench=LabBench(R,F['lots'],REG['instruments'],REG['sources'])
T='SBX-TLI-R44-v1';M='SBX-MICA-R44-v1'
def run(k,aid,lots,values,tools,skills,overrides=None,stage=None):
    obs=readings(R[k],values,lots,aid,overrides)
    try: return bench.run(k,aid,lots,obs,tools,skills,DEFAULT_TIME,stage)
    except SimulatedCrash as e:return {'status':'INJECTED_ROLLBACK','attempt_id':aid,'error':str(e),'audit_after':bench.audit()}

results={}
results['tli_approved']=run(T,'SBX-R45-DEMO-TLI', ['SBX-SLATE-GOOD-01'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'])
results['mica_approved']=run(M,'SBX-R45-DEMO-MICA',['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B'],F['mica_good_measurements'],F['mica_tools'],F['mica_skills'])
results['tli_guardband_rejected']=run(T,'SBX-R45-DEMO-MARGINAL',['SBX-SLATE-GOOD-01'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'],{'length_mm':{'value':121,'uncertainty_abs':0.1}})
results['tli_after_stock_depletion']=run(T,'SBX-R45-DEMO-INSUFFICIENT',['SBX-SLATE-GOOD-01'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'])
state_before=digest(bench.core.state)
results['injected_fault']=run(T,'SBX-R45-DEMO-FAULT',['SBX-SLATE-TOO-SMALL'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'],stage='AFTER_CORE_BEFORE_EVIDENCE_COMMIT')
results['rollback_unchanged']=(digest(bench.core.state)==state_before)
results['idempotent_replay']=run(T,'SBX-R45-DEMO-TLI', ['SBX-SLATE-GOOD-01'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'])
comparisons=json.loads((ROOT/'fixtures/comparisons_synthetic.json').read_text(encoding='utf8'))['comparisons']
paired={k:paired_comparison(v['pairs'],v['metrics']) for k,v in comparisons.items()}
output=ROOT/'results'
output.mkdir(exist_ok=True)
(output/'r45_demo_receipts.json').write_text(json.dumps(results,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
(output/'r45_comparators_synthetic.json').write_text(json.dumps(paired,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
(output/'r45_core_and_evidence_audit.json').write_text(json.dumps(bench.audit(),indent=2,ensure_ascii=False)+'\n',encoding='utf8')
head=bench.snapshot(output/'r45_demo_snapshot.json')
rest=LabBench.restore(output/'r45_demo_snapshot.json',R)
assert rest.audit()==bench.audit() and results['rollback_unchanged']
summary={
 'scope':'SYNTHETIC_EXECUTION_ONLY','recipes':2,
 'status_per_event':{k:v.get('status') for k,v in results.items() if isinstance(v,dict) and 'status' in v},
 'idempotent_replay':results['idempotent_replay']['idempotent_replay'],
 'rollback_kept_state':results['rollback_unchanged'],
 'core_evidence_audit':bench.audit(),
 'snapshot_integrity_sha256':head,
 'recovered_snapshot_integrity_ok':True,
 'comparison_pair_counts':{k:v['n_matched_pairs'] for k,v in paired.items()},
 'warnings':['NOT MATERIAL LAB TEST','ALL MEASUREMENTS AND ALTERNATIVE COSTS SYNTHETIC','RC5_OFFICIAL=0','NOTION_WRITER=NONE']}
(output/'r45_demo_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(summary,indent=2,ensure_ascii=False))
