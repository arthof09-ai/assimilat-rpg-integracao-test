# CRAFT R45 — Relatório de execução, PSV e R46

**Operação:** CM-000002-I0016 / WS0001 CRAFT, escopo DOCUMENTAL+SANDBOX. **Ordem do Mestre R45:** fortalecer motor R44 sem alterar fichas/REC-LIB/Party/O Primeiro e mantendo F5=RED. **Ponto de partida:** R43 CP-CRAFT-I0016-R43-Q2PORT-DEPOIS-004 e R44 pacote experimental anterior. **Estado material antes/depois:** 2 modelos experimentais R44; RC5=0/30; nenhum writer/epoch/lease/GREEN; C19-021 UNKNOWN e IBX-38 NOVA sem ACK na última leitura.

## Evidência preservada e readback

- ZIP R44 `CRAFT-R44-I0016-PILOTO-EXPERIMENTAL-v01.zip`: SHA-256 `900452bb24f398d1968e57ddbfabc0359fb93502cfd21eaf48e44ecfffd6aff3`, CRC PASS, 18/18 hashes de arquivos no manifesto R44 verificados. Código R44 **não foi modificado**; importado como dependência em `r44_legacy/` com adaptador `__init__.py` novo.
- Fontes PS originais: [Ardósia](https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2), [Mica](https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84), dossiê [AUD-CRAFT-F5-REMAP-01](https://app.notion.com/p/3f3c2b324ede81c99367e2de46077cbb), [REC-LIB-01](https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702). Referências reabertas somente leitura. Uso dos recursos concretos, propriedades e preços permanecem PS/PENDENTES.
- [IBX-38](https://app.notion.com/p/3f3c2b324ede817fb888ca32aacaf2de) ainda NOVA, leitura/ACK vazios no preflight; não duplicada. C19 fencing técnico não demonstrado e nenhuma posse material tomada.
- R44 checkpoint ANTES no corpo da [OP](https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516). DEPOIS não materializado no corpo em duas tentativas históricas bloqueadas. Regularizado apenas como **comentário alternativo** no mesmo registro OP, criado e reaberto com `discussion_id=3f4c2b32-4ede-81f1-a51c-001c18ba1040`, em 09/10/2026 11:57 UTC. Isto **não** substitui uma seção OP requerida por governance nem dá NAC-PASS terminal.

## Mudanças funcionais da versão R45

1. Contratos tipados QA por leitura: unidade real de `mm/cm/m/count/bool`; instrumento identificado, janela de validade e incerteza com piso; hora da leitura e referência a fonte PS e lotes de fixture.
2. Guardband conservador: um intervalo de incerteza só aprova se totalmente dentro das tolerâncias; `INDETERMINATE/FAIL` não recebe produto aprovado. Nenhuma medida presumida ou resultado mágico.
3. Contratos de recebimento, estoque e saída preservados do R44, com etapa de evidência dupla e commit atômico; rollback também se falhar a auditoria depois do commit.
4. Hash da evidência científica ligado ao evento e recibo de R44, com antirrepetição de reading IDs, anti-duplication de lotes, replay e snapshots restauráveis; hashes são prova de integridade relativa ao manifesto externo, não certificados de laboratório.
5. Comparador pareado de Tábua vs gabarito comum e Mica vs calço comum, cinco pares sintéticos cada, medindo diferença e incerteza para cada indicador. Sem efeitos sobre catálogo/economia.
6. Alegações de medição real podem ser **protocoladas como reivindicação ainda não verificada** mediante estrutura com hashes de documentos e custódia: `quarantine_claimed_measurements`; não há promoção automática para MEDIDO, VERIFICADO ou MATERIALIZADO.

## Testes reproduzíveis do código final

| Conjunto | Denominador | Resultado | Evidência |
| --- | ---: | --- | --- |
| Regressão R44 herdada, separada | 52 | PASS | `results/r44_regression.log` |
| Novos testes R45 | 64 | PASS | `results/r45_new_tests.log` |
| Verificações property com seed 450017 | 200 | PASS | Uma unidade de teste R45 contém 200 casos, **não** somar como mais 200 testes unitários |
| Demonstração transacional | 4 eventos novos + um replay e uma falha induzida | PASS | `results/r45_demo_receipts.json`, snapshot/ledger |
| Stress deterministicamente injetado, seed 450016 | 250 tentativas | PASS | `results/r45_stress_summary.json`, snapshot |
| Comparações sintéticas | 10 pares (5+5) | PASS do algoritmo | `results/r45_comparators_synthetic.json` |

**Stress:** 62 aprovadas, 43 rejeições PRECHECK, 61 rejeições QA, 32 entradas malformadas recusadas antes de commit, 52 crashes com rollback, 18 replays idempotentes; total **250**. Foram comitados 166 eventos e nenhum efeito oficial. Nenhum desses 62 produtos aprovados sintéticos é um item no RPG.

## Resultados comparativos apenas da fixture inventada

| Proposta x alternativa hipotética | Indicador | Proposta favorecida / Alternativa favorecida / Inconclusivo (de 5) |
| --- | --- | --- |
| Tábua x gabarito comum | Planeza | 3 / 0 / 2 |
| Tábua x gabarito comum | Erro de repetição de traçado | 4 / 0 / 1 |
| Tábua x gabarito comum | Custo UCS sintético | 0 / 5 / 0 |
| Tábua x gabarito comum | Ciclos até falha | 1 / 1 / 3 |
| Mica x calço comum | Uniformidade de espessura | 4 / 0 / 1 |
| Mica x calço comum | Erro de encaixe | 2 / 0 / 3 |
| Mica x calço comum | Custo UCS sintético | 0 / 5 / 0 |
| Mica x calço comum | Ciclos até falha | 0 / 5 / 0 |

**Interpretação correta:** as alternativas hipotéticas são deliberadamente mais baratas nos dados simulados; o algoritmo não favorece automaticamente materiais regionais. Isso **não é evidência de inferioridade ou superioridade real** da Tábua/Mica, nem ranking econômico canônico. UCS_SIM ≠ MED.

## Gate, rastreabilidade e ponto R46

**R45 artefato local:** arquivos, snapshots, manifests e hashes verificáveis; teste limpo externo e readback do zip necessários para fechar a entrega. **No Notion:** checkpoint R44 comment-only, R45 sem writer material. **NAC-PASS material:** HOLD. **Materialização:** 0 RC5 / 30; 0 produtos no acervo; 2 receitas experimentais já existentes no R44 (sem inflar para 4).

**R46 FIRST-PENDING:** integrar pacote de evidências medido externamente sob QUARENTENA com hashes de bytes realmente acessados, cadeia de custódia, calibração, comparador pareado e revisão Mestre-side; aplicar gates de autorização e decisão antes de transformar uma alegação em medição VERIFICADA. Em paralelo, acompanhar IBX-38 sem duplicá-la e manter C19 material no estado RED até fencing ou STOP-ACK legítimos, reconciliação física C19-021, claim e NAC-PASS apropriado. Testes sintéticos podem continuar de modo seguro, mas não geram REC-ID.
