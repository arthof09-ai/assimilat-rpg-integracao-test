"""Guarded reuse of unmodified R45 paired comparator; R46 conditions and n-audit.

No inferential statistics, no physical measurement and no automatic superiority.
"""
from __future__ import annotations
import copy,sys
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parent
R45=ROOT/'baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016'
if str(R45) not in sys.path:sys.path.insert(0,str(R45))
from r45_engine import paired_comparison, SandboxError, digest

EXPECTED={'tli_vs_common_board':{'flatness_mm':'mm','line_repetition_error_mm':'mm','cost_ucs_sim':'UCS_SIM','cycles_to_failure':'cycle'},
          'mica_vs_common_shim':{'thickness_difference_mm':'mm','fit_error_mm':'mm','cost_ucs_sim':'UCS_SIM','cycles_to_failure':'cycle'}}

def add_condition_fixture(trials):
 """Attach matching fake environmental controls; not field records."""
 result=[]
 for i,t in enumerate(trials):
  row=copy.deepcopy(t)
  row['candidate_conditions']={'temperature_c':str(20+i%3),'humidity_pct':str(45+i%4),'method_id':'SBX-R46-METHOD-v1','operator_id':'SBX-OP-CTRL-01'}
  row['alternative_conditions']=copy.deepcopy(row['candidate_conditions'])
  row['candidate_sample_id']='SBX-PAIR-C-'+row['trial_id']
  row['alternative_sample_id']='SBX-PAIR-A-'+row['trial_id']
  result.append(row)
 return result

def guarded_compare(name,design,trials,min_pairs=5):
 if name not in EXPECTED:raise SandboxError('UNKNOWN_COMPARISON')
 expected=EXPECTED[name]
 metrics=design['metrics']
 if set(metrics)!=set(expected):raise SandboxError('METRIC_SCOPE_MISMATCH')
 if len(trials)<min_pairs:
  return {'comparison':name,'classification':'INSUFFICIENT_SYNTHETIC_PAIRS',
          'scope':'SYNTHETIC_ONLY','n_pairs':len(trials),'min_pairs_proposed':min_pairs,
          'empirical_superiority':False}
 if len(trials)!=len({t.get('trial_id') for t in trials}):raise SandboxError('DUPLICATED_TRIAL_ID')
 if len(trials)!=len({t.get('matched_setup_id') for t in trials}):raise SandboxError('DUPLICATED_MATCHED_SETUP')
 control_issues=[];baseline=[];summary_conditions=[]
 for t in trials:
  a=t.get('candidate_conditions');b=t.get('alternative_conditions')
  if type(a) is not dict or type(b) is not dict or set(a)!={'temperature_c','humidity_pct','method_id','operator_id'}:
   control_issues.append(t['trial_id']+':MISSING_TEST_CONDITIONS');continue
  if a!=b:control_issues.append(t['trial_id']+':CONDITIONS_NOT_PAIRED')
  if not t.get('candidate_sample_id') or not t.get('alternative_sample_id') or t['candidate_sample_id']==t['alternative_sample_id']:
   control_issues.append(t['trial_id']+':SAMPLE_PAIR_IDENTITIES')
  summary_conditions.append({'trial_id':t['trial_id'],'conditions_digest':digest(a)})
  baseline.append({k:copy.deepcopy(t[k]) for k in ('trial_id','evidence_kind','candidate','alternative','matched_setup_id')})
  for metric in expected:
   try:
    if t['candidate'][metric]['unit']!=expected[metric] or t['alternative'][metric]['unit']!=expected[metric]:
     control_issues.append(t['trial_id']+':WRONG_UNIT_'+metric)
   except (TypeError,KeyError):control_issues.append(t['trial_id']+':MISSING_METRIC_'+metric)
 if control_issues:
  return {'comparison':name,'classification':'QUARANTINE_COMPARISON_CONDITIONS_OR_UNITS',
          'scope':'SYNTHETIC_ONLY','n_pairs':len(trials),'issues':sorted(set(control_issues)),
          'empirical_superiority':False}
 paired=paired_comparison(baseline,metrics)
 per_metric={};pro=[];contra=[]
 for metric,datum in paired['metrics'].items():
  c=datum['counts'];n=datum['n_pairs']
  dist={'n_pairs':n,'candidate_better':c['candidate_better'],
        'alternative_better':c['alternative_better'],'inconclusive':c['inconclusive'],
        'unit':datum['unit'],'direction':datum['direction'],'intervals':datum['paired_details']}
  per_metric[metric]=dist
  if c['candidate_better']>c['alternative_better']:pro.append(metric)
  if c['alternative_better']>c['candidate_better']:contra.append(metric)
 if pro and contra:assessment='SYNTHETIC_TRADEOFF_NO_GLOBAL_WINNER'
 elif pro and not contra:assessment='SYNTHETIC_DIRECTION_FAVORABLE_NOT_EMPIRICAL'
 elif contra and not pro:assessment='SYNTHETIC_DIRECTION_UNFAVORABLE_NOT_EMPIRICAL'
 else:assessment='SYNTHETIC_INCONCLUSIVE'
 return {'comparison':name,'classification':assessment,'scope':'SYNTHETIC_PAIRED_DESCRIPTIVE',
         'n_pairs':len(trials),'proposed_min_pairs':min_pairs,
         'no_statistical_power_established':True,'empirical_superiority':False,
         'candidate_source':'EXPERIMENTAL_PS_NOT_CANONICAL_STOCK',
         'alternative_source':'COMMON_SUBSTITUTE_NOT_ASSERTED_CANONICAL_PRODUCT',
         'comparison_conditions':summary_conditions,'metrics':per_metric,
         'conditional_favorable_metrics':pro,'conditional_unfavorable_metrics':contra}
