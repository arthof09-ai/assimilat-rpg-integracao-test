"""Reproducible high-volume synthetic stress; no external systems touched."""
import copy,json,random
from pathlib import Path
from experimental_engine import SandboxEngine,load_recipes,SimulatedCrash,digest
ROOT=Path(__file__).resolve().parent
rng=random.Random(440016)
recipes=load_recipes(ROOT/'recipes')
f=json.loads((ROOT/'fixtures'/'demo.json').read_text(encoding='utf8'))
lots=copy.deepcopy(f['lots'])
for x in lots:
    if x['lot_id']=='SBX-SLATE-GOOD-01' or x['lot_id'].startswith('SBX-MICA-GOOD-'):
        x['quantity']=250
engine=SandboxEngine(recipes,lots)
results={'seed':440016,'runs':600,'attempted_stages':{},'outcomes':{},'crash_rollbacks':0,
         'replays':0,'independent_restore_pass':False,'failed_invariants':0,
         'synthetic_only':True,'official_rec_id_new':0}
for i in range(600):
    candidate=rng.choice(['TLI','MICA'])
    recipe_key='SBX-TLI-R44-v1' if candidate=='TLI' else 'SBX-MICA-R44-v1'
    lot_ids=['SBX-SLATE-GOOD-01'] if candidate=='TLI' else ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
    qa=copy.deepcopy(f['tli_good_measurements'] if candidate=='TLI' else f['mica_good_measurements'])
    tools=f['tli_tools'] if candidate=='TLI' else f['mica_tools']
    skills=f['tli_skills'] if candidate=='TLI' else f['mica_skills']
    mode=rng.choice(['good','good','good','badqa','no_tool','not_enough','fault_before','fault_after'])
    if mode=='badqa':
        if candidate=='TLI': qa['sharp_edges']=True
        else: qa['mount_fit']=False
    if mode=='no_tool':tools=tools[:-1]
    if mode=='not_enough':lot_ids=['SBX-SLATE-TOO-SMALL'] if candidate=='TLI' else ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
    fault={'fault_before':'AFTER_CONSUME','fault_after':'BEFORE_COMMIT'}.get(mode)
    aid=f'SBX-STRESS-{i:04d}'
    before=digest(engine.state)
    try:
        r=engine.run(recipe_key,aid,lot_ids,qa,tools,skills,fault)
        results['outcomes'][r['status']]=results['outcomes'].get(r['status'],0)+1
        if i%13==0:
            dup=engine.run(recipe_key,aid,lot_ids,qa,tools,skills)
            assert dup['idempotent_replay']
            results['replays']+=1
    except SimulatedCrash:
        assert digest(engine.state)==before
        results['crash_rollbacks']+=1
    assert engine.audit()['ok'],engine.audit()['reasons']
    results['attempted_stages'][mode]=results['attempted_stages'].get(mode,0)+1
    if not engine.audit()['ok']:results['failed_invariants']+=1

saved=ROOT/'results'/'stress_snapshot.json'
engine.export_snapshot(saved)
restored=SandboxEngine.restore(recipes,saved)
results['independent_restore_pass']=restored.audit()['ok'] and digest(engine.state)==digest(restored.state)
results['verified_ledger_events']=engine.audit()['verified_events']
results['head_hash']=engine.audit()['head_hash']
results['result']='PASS' if results['independent_restore_pass'] and results['failed_invariants']==0 else 'FAIL'
(ROOT/'results'/'stress_summary.json').write_text(json.dumps(results,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps(results,indent=2,ensure_ascii=False,sort_keys=True))
assert results['result']=='PASS'
