"""Reproducible local packaging; modifies only R46 manifest and parent ZIP."""
from __future__ import annotations
import hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent/'CRAFT-R46-I0016-EVIDENCE-VAULT-v01.zip'

def payload_files():
 return sorted((p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
                and not p.name.endswith(('.pyc','.tmp')) and p!=ROOT/'MANIFEST_SHA256.txt'),
               key=lambda x:x.relative_to(ROOT).as_posix())

def build():
 files=payload_files()
 content=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files)
 (ROOT/'MANIFEST_SHA256.txt').write_text(content,encoding='utf8')
 with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8,strict_timestamps=False) as z:
  for p in sorted(files+[ROOT/'MANIFEST_SHA256.txt'],key=lambda v:v.relative_to(ROOT).as_posix()):
   inner=ROOT.name+'/'+p.relative_to(ROOT).as_posix()
   info=zipfile.ZipInfo(inner,date_time=(1980,1,1,0,0,0))
   info.compress_type=zipfile.ZIP_DEFLATED
   info.external_attr=(0o100644<<16)
   z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
 sha=hashlib.sha256(DEST.read_bytes()).hexdigest()
 (ROOT.parent/'CRAFT-R46-I0016-SHA256.txt').write_text(sha+'  '+DEST.name+'\n',encoding='utf8')
 print('r46_zip',DEST,'size',DEST.stat().st_size,'manifest_count',len(files),'sha256',sha)
 return sha
if __name__=='__main__':build()
