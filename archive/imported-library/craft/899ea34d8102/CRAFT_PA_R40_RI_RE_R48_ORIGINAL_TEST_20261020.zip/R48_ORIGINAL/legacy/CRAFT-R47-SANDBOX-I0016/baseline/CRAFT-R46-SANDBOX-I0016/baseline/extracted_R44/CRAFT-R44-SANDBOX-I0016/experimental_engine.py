"""CRAFT R44: local in-memory fictional fabrication sandbox. NEVER a Notion writer.

Standard library only. Every lot, tool, staff skill and measurement passed to this
module is a synthetic test fixture, NOT a canon inventory, stock or production event.
"""
from __future__ import annotations
import copy
import hashlib
import json
import math
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any

NAMESPACE = 'SBX-CRAFT-R44-I0016'
GENESIS = hashlib.sha256((NAMESPACE + '|GENESIS-v1').encode()).hexdigest()


def canonical(x: Any) -> str:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(x: Any) -> str:
    return hashlib.sha256(canonical(x).encode('utf-8')).hexdigest()


def load_recipes(recipe_dir: str | Path) -> dict:
    root = Path(recipe_dir)
    r = {}
    for p in sorted(root.glob('*.json')):
        row = json.loads(p.read_text(encoding='utf8'))
        assert row['namespace'] == NAMESPACE and row['status'] == 'EXPERIMENTAL_DESIGN_ONLY'
        assert row['key'] not in r
        assert row['official_rec_id'] is None and row['mechanical_bonus'] == 0
        assert row['source_page_id'] and row['inputs'] and row['output']
        r[row['key']] = row
    return r


class SandboxError(ValueError):
    pass


class SimulatedCrash(RuntimeError):
    pass


class SandboxEngine:
    """Transactional, replay-checked event ledger. No API/network/Notion access."""

    def __init__(self, recipes: dict, lots: list[dict]):
        self.recipes = copy.deepcopy(recipes)
        self.recipe_hashes = {k:digest(v) for k,v in recipes.items()}
        d = {x['lot_id']:copy.deepcopy(x) for x in lots}
        if len(d) != len(lots):
            raise SandboxError('DUPLICATE_LOT_ID')
        for key, lot in d.items():
            if not key.startswith('SBX-') or lot.get('fixture_kind') != 'SYNTHETIC':
                raise SandboxError('NON_SANDBOX_STOCK')
            if not isinstance(lot.get('quantity'),int) or lot['quantity'] < 0:
                raise SandboxError('INVALID_QUANTITY')
        self.initial_lots = copy.deepcopy(d)
        self.initial_hash = digest(d)
        self.state = {'lots': d, 'products': {}, 'waste': {}, 'attempts': {}, 'events': [], 'head_hash': GENESIS}
        assert self.audit()['ok']

    def _payload(self, key, attempt_id, lot_ids, measurements, tools, skills):
        return {'recipe':key,'attempt_id':attempt_id,'lot_ids':lot_ids,
                'measurements':measurements,'tools':sorted(tools),'skills':sorted(skills)}

    @staticmethod
    def _quality(recipe, measurements):
        """A QA pass requires every specified measurement, never assumes missing=PASS."""
        failed = []
        for spec in recipe['qa_rules']:
            field=spec['field']
            value=measurements.get(field)
            if type(value) not in (int,float,bool) or (isinstance(value,float) and not math.isfinite(value)):
                failed.append(f'{field}:MISSING_OR_INVALID'); continue
            if spec['kind'] == 'bool_eq':
                if type(value) is not bool or value != spec['value']: failed.append(f'{field}:REQUIRED_{spec["value"]}')
            else:
                if type(value) is bool: failed.append(f'{field}:BOOLEAN_NOT_NUMERIC'); continue
                if spec['kind'] == 'range' and not (spec['min'] <= value <= spec['max']): failed.append(f'{field}:OUT_OF_RANGE')
                elif spec['kind'] == 'max' and not value <= spec['max']: failed.append(f'{field}:ABOVE_LIMIT')
                elif spec['kind'] == 'min' and not value >= spec['min']: failed.append(f'{field}:BELOW_LIMIT')
        return failed

    @staticmethod
    def _input_ok(recipe, selected):
        err=[]
        for req,lot in zip(recipe['inputs'],selected):
            if lot['source_page_id'] != req['source_page_id'] or lot['unit'] != req['unit']:
                err.append('SOURCE_OR_UNIT_MISMATCH')
            if lot['quantity'] < req['quantity']:
                err.append('INSUFFICIENT_QUANTITY')
            for dim,v in req.get('minimum_dimensions_mm',{}).items():
                measured=lot.get('dimensions_mm',{}).get(dim)
                if type(measured) not in (int,float) or measured < v:
                    err.append(f'UNDER_DIMENSION_{dim}')
            for flag in ('cracked','delaminated','contaminated'):
                if lot.get(flag) is not False:
                    err.append(f'INPUT_{flag.upper()}_UNVERIFIED_OR_TRUE')
        return err

    def run(self, recipe_key: str, attempt_id: str, lot_ids: list[str],
            measurements: dict, tools: list[str], skills: list[str],
            fault_stage: str | None = None):
        if not self.audit()['ok']:
            raise SandboxError('LEDGER_INTEGRITY_FAILURE')
        if recipe_key not in self.recipes:
            raise SandboxError('UNKNOWN_RECIPE')
        if not attempt_id.startswith('SBX-') or not attempt_id.replace('-','').replace('_','').isalnum():
            raise SandboxError('INVALID_EXPERIMENTAL_ATTEMPT_ID')
        if len(lot_ids) != len(set(lot_ids)):
            raise SandboxError('DUPLICATE_LOT_SELECTION')
        p=self._payload(recipe_key,attempt_id,lot_ids,measurements,tools,skills)
        fp=digest(p)
        prior=self.state['attempts'].get(attempt_id)
        if prior:
            if prior['request_hash'] != fp:
                raise SandboxError('IDEMPOTENCY_KEY_REUSE_WITH_DIFFERENT_PAYLOAD')
            return {**copy.deepcopy(prior),'idempotent_replay':True}
        recipe=self.recipes[recipe_key]
        staged=copy.deepcopy(self.state)
        rejects=[]
        if len(lot_ids) != len(recipe['inputs']): rejects.append('INPUT_ARITY')
        selected=[]
        for id_ in lot_ids:
            if id_ not in staged['lots']:
                rejects.append('UNKNOWN_SYNTHETIC_LOT')
            else: selected.append(staged['lots'][id_])
        if len(selected) == len(recipe['inputs']):
            rejects += self._input_ok(recipe,selected)
        if any(t not in tools for t in recipe['tools']): rejects.append('MISSING_REQUIRED_TOOL')
        if any(t not in skills for t in recipe['skills']): rejects.append('MISSING_REQUIRED_SKILL')
        # In a rejected preflight, no resource is deducted and no product created.
        consumed=[]; created=[]; waste=[]; qa_reasons=[]; stage_trace=[]
        status='REJECTED_PRECHECK' if rejects else None
        if not rejects:
            for req,lot in zip(recipe['inputs'],selected):
                q=req['quantity']; lot['quantity']-=q
                consumed.append({'lot_id':lot['lot_id'],'quantity':q,'unit':lot['unit'], 'source_page_id':lot['source_page_id']})
            if fault_stage == 'AFTER_CONSUME':
                raise SimulatedCrash('INJECTED_AFTER_CONSUME_BEFORE_COMMIT')
            # Explicit transformation trace: a designed game-model step, NEVER
            # proof that real material was processed or time truly elapsed.
            stage_trace=[{'seq':step['seq'], 'name':step['name'],
                          'minutes_proposed':step['minutes_proposed'],
                          'mode':'SIMULATED_RULE_TRANSITION_NOT_PHYSICAL'}
                         for step in recipe['steps']]
            qa_reasons=self._quality(recipe,measurements)
            if fault_stage == 'AFTER_QA':
                raise SimulatedCrash('INJECTED_AFTER_QA_BEFORE_COMMIT')
            if qa_reasons:
                status='REJECTED_QUALITY'
                waste=[{'id':NAMESPACE+'-WASTE-'+attempt_id,'reason':'REJECTED_QUALITY',
                        'units_scrapped':len(consumed),'not_inventory_resource':True}]
                staged['waste'][attempt_id]=copy.deepcopy(waste)
            else:
                status='EXPERIMENTAL_QA_PASS'
                product_id=f'{NAMESPACE}-PRODUCT-{attempt_id}'
                product={'product_id':product_id,'name':recipe['output']['name'],
                         'units':recipe['output']['quantity'],'unit':recipe['output']['unit'],
                         'recipe_key':recipe_key,'qa_fixture':copy.deepcopy(measurements),
                         'source_lots':list(lot_ids),'status':'SYNTHETIC_OUTPUT_ONLY',
                         'official_product_id':None,'mechanical_bonus':0}
                staged['products'][product_id]=product
                created=[copy.deepcopy(product)]
        before_quantities={k:v['quantity'] for k,v in self.state['lots'].items()}
        after_quantities={k:v['quantity'] for k,v in staged['lots'].items()}
        receipt={'attempt_id':attempt_id,'request_hash':fp, 'recipe_key':recipe_key,
                 'recipe_hash':self.recipe_hashes[recipe_key],'status':status,
                 'rejection_reasons':sorted(set(rejects+qa_reasons)),
                 'consumed':consumed,'transformation_stage_trace':stage_trace,
                 'products':created,'scrap':waste,
                 'inventory_before':before_quantities,'inventory_after':after_quantities,
                 'fixture_type':'SYNTHETIC','simulation_only':True,'official_rec_id':None,
                 'official_materialization':False, 'idempotent_replay':False}
        staged['attempts'][attempt_id]=copy.deepcopy(receipt)
        event={'seq':len(self.state['events'])+1,'attempt_id':attempt_id,'request_hash':fp,
               'recipe_hash':self.recipe_hashes[recipe_key],'status':status,
               'consumed':consumed,'transformation_stage_trace':stage_trace,
               'products':created,'scrap':waste,
               'rejects':sorted(set(rejects+qa_reasons))}
        prev=staged['head_hash']; rec={'previous_hash':prev,'event':event}
        rec['hash']=digest({'previous_hash':prev,'event':event})
        staged['events'].append(rec);staged['head_hash']=rec['hash']
        if fault_stage == 'BEFORE_COMMIT':
            raise SimulatedCrash('INJECTED_BEFORE_COMMIT')
        original=self.state
        self.state=staged
        if not self.audit()['ok']:
            self.state=original
            raise SandboxError('FAILED_POSTCOMMIT_INVARIANT')
        return copy.deepcopy(receipt)

    def audit(self) -> dict:
        reasons=[]
        if digest(self.initial_lots) != self.initial_hash: reasons.append('INITIAL_STOCK_CHANGED')
        observed=copy.deepcopy(self.initial_lots)
        products={};wastes={};attempt_ids=set(); prev=GENESIS
        for index,rec in enumerate(self.state['events'],1):
            e=rec['event']
            if rec['previous_hash'] != prev or rec['hash'] != digest({'previous_hash':prev,'event':e}):
                reasons.append(f'BROKEN_HASH_CHAIN_AT_{index}')
            prev=rec['hash']
            if e['seq']!=index: reasons.append('BROKEN_SEQUENCE')
            aid=e['attempt_id']
            if aid in attempt_ids: reasons.append('DUPLICATE_ATTEMPT_LEDGER')
            attempt_ids.add(aid)
            a=self.state['attempts'].get(aid)
            if not a or a['request_hash']!=e['request_hash'] or a['status']!=e['status']:
                reasons.append('ATTEMPT_RECEIPT_MISMATCH')
            before_event_qty={k:v['quantity'] for k,v in observed.items()}
            for c in e['consumed']:
                if c['lot_id'] not in observed: reasons.append('CONSUMED_UNKNOWN_LOT');continue
                observed[c['lot_id']]['quantity']-=c['quantity']
                if observed[c['lot_id']]['quantity']<0: reasons.append('NEGATIVE_INVENTORY')
            after_event_qty={k:v['quantity'] for k,v in observed.items()}
            if a and (a['inventory_before']!=before_event_qty or a['inventory_after']!=after_event_qty):
                reasons.append('RECEIPT_INVENTORY_SNAPSHOT_MISMATCH')
            if a and (a['consumed']!=e['consumed'] or a['products']!=e['products']
                      or a['scrap']!=e['scrap'] or a['transformation_stage_trace']!=e['transformation_stage_trace']
                      or a['rejection_reasons']!=e['rejects']):
                reasons.append('RECEIPT_EVENT_CONTENT_MISMATCH')
            if a and (a.get('official_rec_id') is not None or not a.get('simulation_only')):
                reasons.append('INVALID_RECEIPT_SANDBOX_SCOPE')
            for p in e['products']:
                if (p.get('official_product_id') is not None or p.get('mechanical_bonus') != 0
                    or not p.get('product_id','').startswith(NAMESPACE)):
                    reasons.append('PRODUCT_CROSSES_SANDBOX_BOUNDARY')
                if p['product_id'] in products: reasons.append('DUPLICATE_PRODUCT_ID')
                products[p['product_id']]=p
            if e['scrap']: wastes[aid]=e['scrap']
            if e['status']=='EXPERIMENTAL_QA_PASS' and not e['products']: reasons.append('PASS_WITHOUT_PRODUCT')
            if e['status']!='EXPERIMENTAL_QA_PASS' and e['products']: reasons.append('FAILED_WITH_PRODUCT')
            if e['status']=='REJECTED_PRECHECK' and e['consumed']: reasons.append('PRECHECK_CONSUMED_STOCK')
            if e['status']=='REJECTED_PRECHECK' and e['transformation_stage_trace']: reasons.append('PRECHECK_PERFORMED_TRANSFORMATION')
            if e['status']!='REJECTED_PRECHECK' and not e['transformation_stage_trace']: reasons.append('PROCESS_WITHOUT_STAGE_TRACE')
        if observed!=self.state['lots']: reasons.append('INVENTORY_REPLAY_MISMATCH')
        if products!=self.state['products']: reasons.append('PRODUCT_REPLAY_MISMATCH')
        if wastes!=self.state['waste']: reasons.append('WASTE_REPLAY_MISMATCH')
        if attempt_ids!=set(self.state['attempts']): reasons.append('ATTEMPT_SET_MISMATCH')
        if self.state['head_hash']!=prev: reasons.append('HEAD_HASH_MISMATCH')
        return {'ok':not reasons,'reasons':reasons,'verified_events':len(self.state['events']),
                'head_hash':self.state['head_hash']}

    def export_snapshot(self, path: str | Path):
        if not self.audit()['ok']: raise SandboxError('REFUSE_CORRUPT_SNAPSHOT')
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
        wrapper={'namespace':NAMESPACE,'schema':'R44-SANDBOX-SNAPSHOT-v1',
                 'initial_lots':self.initial_lots,'initial_hash':self.initial_hash,
                 'recipe_hashes':self.recipe_hashes,'state':self.state}
        wrapper['integrity_sha256']=digest(wrapper)
        tmp=p.with_suffix(p.suffix+'.tmp')
        tmp.write_text(json.dumps(wrapper,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
        tmp.replace(p)
        return wrapper['integrity_sha256']

    @classmethod
    def restore(cls, recipes, path: str | Path):
        w=json.loads(Path(path).read_text(encoding='utf8'))
        sha=w.pop('integrity_sha256',None)
        if not sha or digest(w)!=sha: raise SandboxError('SNAPSHOT_CHECKSUM_INVALID')
        if w['namespace']!=NAMESPACE or w['schema']!='R44-SANDBOX-SNAPSHOT-v1':
            raise SandboxError('INVALID_SNAPSHOT_NAMESPACE')
        if w['recipe_hashes']!={k:digest(v) for k,v in recipes.items()}:
            raise SandboxError('RECIPE_CHANGED_SINCE_SNAPSHOT')
        obj=cls(recipes,list(w['initial_lots'].values()))
        if obj.initial_hash!=w['initial_hash']: raise SandboxError('INITIAL_LOT_MISMATCH')
        obj.state=w['state']
        if not obj.audit()['ok']: raise SandboxError('RESTORE_REPLAY_FAILURE')
        return obj


def simulation_cost(recipe:dict, prices:dict, success_count:int, currency:str='UCS_SIMULADA') -> dict:
    """Optional synthetic accounting. NEVER emits a MED estimate."""
    if currency!='UCS_SIMULADA': raise SandboxError('REAL_MED_PRICE_NOT_ESTIMABLE')
    if not isinstance(success_count,int) or success_count<0: raise SandboxError('INVALID_SUCCESS_COUNT')
    required=('input_cost','labor_rate_hour','tool_wear','epi','route','discard')
    if any(x not in prices for x in required): raise SandboxError('MISSING_SYNTHETIC_PRICE')
    v={x:Decimal(str(prices[x])) for x in required}
    if any(x<0 or not x.is_finite() for x in v.values()): raise SandboxError('INVALID_PRICE')
    minutes=Decimal(str(recipe['proposed_active_minutes']))
    total=v['input_cost']+v['labor_rate_hour']*minutes/Decimal(60)+sum(v[x] for x in ('tool_wear','epi','route','discard'))
    q=lambda n:str(n.quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
    return {'currency':'UCS_SIMULADA','prices_are_real':False,'total_batch':q(total),
            'unit_cost':q(total/Decimal(success_count)) if success_count else None,
            'successful_outputs':success_count,'active_minutes_design_only':int(minutes),
            'pending_real_parameters':['MED/input','MED/labor','MED/wear','MED/EPI','MED/logistics','MED/failures','availability','lot-empirical-yield']}
