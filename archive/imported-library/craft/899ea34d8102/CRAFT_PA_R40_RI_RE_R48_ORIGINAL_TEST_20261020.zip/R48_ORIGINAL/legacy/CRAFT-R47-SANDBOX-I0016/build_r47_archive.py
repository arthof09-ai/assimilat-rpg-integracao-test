"""Deterministic ZIP and exhaustive file manifest for R47, no network access."""
from __future__ import annotations
import hashlib,os,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ZIP=ROOT.parent/'CRAFT-R47-I0016-AUTENTICIDADE-CUSTODIA-v02.zip'
MAN=ROOT/'MANIFEST_SHA256.txt'
EXCLUDE_DIRS={'__pycache__','.pytest_cache','r47_local_durable_demo'}

def sha(b):return hashlib.sha256(b).hexdigest()

def files():
    items=[]
    for file in sorted(ROOT.rglob('*')):
        if not file.is_file() or file==MAN:continue
        parts=file.relative_to(ROOT).parts
        if any(c in EXCLUDE_DIRS for c in parts):continue
        if file.suffix in ('.pyc','.inflight','.tmp'):continue
        if file.is_symlink():raise RuntimeError('REFUSE_SYMLINK')
        items.append((file,'/'.join(parts)))
    return items

if __name__=='__main__':
    arr=files()
    text='# R47 manifest: SHA-256 of exact member bytes; excludes this manifest only.\n'
    text+=''.join(sha(f.read_bytes())+'  '+name+'\n' for f,name in arr)
    MAN.write_text(text,encoding='utf8')
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for f,rel in [(MAN,'MANIFEST_SHA256.txt')]+arr:
            info=zipfile.ZipInfo(ROOT.name+'/'+rel,(1980,1,1,0,0,0))
            info.external_attr=0o100644<<16
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    print('ARCHIVE',ZIP)
    print('BYTES',ZIP.stat().st_size,'SHA256',sha(ZIP.read_bytes()),'FILES',len(arr))
