# R46 — protocolo preparatório de ensaio empírico (NÃO EXECUTADO)

## Status e isolamento

O R45 apenas prepara a interface; nenhuma amostra real foi recebida, medida ou transformada. Este protocolo tem status **PROPOSTO**. A entrada de alegações de medidas físicas gera `CLAIM_SCHEMA_ACCEPTED_QUARANTINE_ONLY_NOT_VERIFIED` e não chama `LabBench.run`, nem escreve estoque/receita oficial. A fonte PS continua sem disponibilidade, local, quantidade, vendedor ou preço MED comprovados.

## Um ensaio legítimo deverá documentar antes

1. Identidade do operador, competência, responsabilidade Mestre-side e autorização precisa; fonte do lote com identificador físico, registro temporal e ligação PS/canônica; quantidade e unidade medidas, não apenas afirmação de disponibilidade.
2. Cadeia de custódia de material, instrumentos identificados e certificados reais de calibração com escopo e validade, fotos/arquivos primários, hash calculado a partir de bytes acessíveis e readback independente.
3. Pré-registro de comparação e aceite, lote alvo e alternativas com função equivalente, plano de amostragem/aleatorização, ordem de ensaio pareada e controle de aprendizagem/temperatura/umidade.
4. A tolerância é uma **proposta de engenharia R42**, nunca homologação: Tábua `120×80×8mm`, comprimento/largura ±1mm, espessura ±0,5mm, planeza ≤1mm, grade 10±1mm, sulco ≤0,5mm; Mica 2 folhas ≥60×30mm, duas saídas alvo 50×20mm, diferença espessura ≤0,10mm proposta R44 (a confirmar com encaixe real).
5. Unidades completas, valores com incerteza, condições e fotos antes/depois, tempo por etapa observado (não 55/30 minutos propostos), sobras e rejeições, riscos à saúde e proteção contra poeira, ficha de segurança e regras reais de oficina.
6. Resultados comparáveis: Tábua contra gabarito comum (planicidade, erro de repetição de traçado, custo real relativo por ciclo e durabilidade); Mica contra calço comum (tolerância de espessura, erro de encaixe, custo e ciclos). Registrar séries e variabilidade de ambos, não apenas médias finais.
7. Proposta de amplitude: até três sublotes de cinco placas TLI, **somente se houver 15 lâminas legitimas**; não criar estoque fictício para alcançar N. Para comparações, definir tamanho pela variância medida no piloto; cinco pares sintéticos atuais **não** são evidência nem cálculo de poder estatístico.

## Gate de ingestão R46

**RECEBER → QUARENTENA → VERIFICAR BYTES/CALIBRAÇÃO/FONTE/CUSTÓDIA → REVISÃO INDEPENDENTE → DECISÃO DO MESTRE/GOVERNANÇA → EVENTO DE ENSAIO ISOLADO (se autorizado)**. Não aceitar `VERIFIED` só porque uma mensagem traz essa palavra. Atribuir timestamp de observação e separado timestamp de verificação. Ausência de prova essencial = PENDING, não simular valores reais.

## Gate material oficial (não incluído no protocolo experimental)

C19 deve ter resposta sobre capacidade efetiva de fencing, STOP-ACK/RELEASE ou impedimento técnico comprovado no write point, reconciliação C19-021 sem repetição cega, U-SUCCESSION+claim+canário+GREEN único, busca real de duplicatas e autoridade competente para REC-LIB; NAC-NORM/REPA/NAC-PASS próprios. Até lá F5=P0/RED e RC5=0/30.
