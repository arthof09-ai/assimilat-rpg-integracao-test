import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from r46_comparison import guarded_compare,add_condition_fixture,SandboxError
R45=ROOT/'baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016'
COMPS=json.loads((R45/'fixtures/comparisons_synthetic.json').read_text())['comparisons']

def get(name):
 d=copy.deepcopy(COMPS[name]);return d,add_condition_fixture(d['pairs'])

class ComparisonAudit(unittest.TestCase):
 def test_001_tli_tradeoff(self):
  name='tli_vs_common_board';d,t=get(name);out=guarded_compare(name,d,t)
  self.assertEqual(out['classification'],'SYNTHETIC_TRADEOFF_NO_GLOBAL_WINNER');self.assertEqual(out['n_pairs'],5)
  self.assertFalse(out['empirical_superiority'])
 def test_002_mica_tradeoff(self):
  name='mica_vs_common_shim';d,t=get(name);out=guarded_compare(name,d,t)
  self.assertEqual(out['classification'],'SYNTHETIC_TRADEOFF_NO_GLOBAL_WINNER')
 def test_003_five_pairs_does_not_prove_power(self):
  d,t=get('tli_vs_common_board');out=guarded_compare('tli_vs_common_board',d,t)
  self.assertTrue(out['no_statistical_power_established'])
 def test_004_two_pairs_inconclusive(self):
  d,t=get('tli_vs_common_board');out=guarded_compare('tli_vs_common_board',d,t[:2])
  self.assertEqual(out['classification'],'INSUFFICIENT_SYNTHETIC_PAIRS')
 def test_005_conditions_not_matched(self):
  d,t=get('mica_vs_common_shim');t[0]['alternative_conditions']['humidity_pct']='95'
  out=guarded_compare('mica_vs_common_shim',d,t)
  self.assertEqual(out['classification'],'QUARANTINE_COMPARISON_CONDITIONS_OR_UNITS')
 def test_006_bad_units_quarantined(self):
  d,t=get('tli_vs_common_board');t[0]['candidate']['cost_ucs_sim']['unit']='MED'
  out=guarded_compare('tli_vs_common_board',d,t)
  self.assertEqual(out['classification'],'QUARANTINE_COMPARISON_CONDITIONS_OR_UNITS')
 def test_007_duplicate_trial_refused(self):
  d,t=get('tli_vs_common_board');t[1]['trial_id']=t[0]['trial_id']
  with self.assertRaisesRegex(SandboxError,'DUPLICATED_TRIAL_ID'):guarded_compare('tli_vs_common_board',d,t)
 def test_008_duplicate_setup_refused(self):
  d,t=get('tli_vs_common_board');t[1]['matched_setup_id']=t[0]['matched_setup_id']
  with self.assertRaisesRegex(SandboxError,'DUPLICATED_MATCHED_SETUP'):guarded_compare('tli_vs_common_board',d,t)
 def test_009_identical_candidate_and_alternative_sample_id(self):
  d,t=get('tli_vs_common_board');t[0]['alternative_sample_id']=t[0]['candidate_sample_id']
  self.assertIn('SAMPLE_PAIR_IDENTITIES',str(guarded_compare('tli_vs_common_board',d,t)['issues']))
 def test_010_metric_scope_protected(self):
  d,t=get('tli_vs_common_board');d['metrics']['magical_strength']='higher'
  with self.assertRaisesRegex(SandboxError,'METRIC_SCOPE_MISMATCH'):guarded_compare('tli_vs_common_board',d,t)
 def test_011_negative_cost_cannot_win(self):
  d,t=get('tli_vs_common_board');t[0]['candidate']['cost_ucs_sim']['value']=-1
  with self.assertRaisesRegex(SandboxError,'NEGATIVE_METRIC'):guarded_compare('tli_vs_common_board',d,t)
 def test_012_uncertainty_crossing_delta_is_inconclusive(self):
  d,t=get('tli_vs_common_board');t[0]['candidate']['flatness_mm']['uncertainty_abs']=100
  out=guarded_compare('tli_vs_common_board',d,t)
  self.assertEqual(out['metrics']['flatness_mm']['intervals'][0]['outcome'],'inconclusive')
 def test_013_non_synthetic_input_refused(self):
  d,t=get('tli_vs_common_board');t[0]['evidence_kind']='MEASURED_VERIFIED'
  with self.assertRaisesRegex(SandboxError,'NOT_SYNTHETIC'):guarded_compare('tli_vs_common_board',d,t)
 def test_014_alternative_never_asserted_canonical(self):
  d,t=get('mica_vs_common_shim');out=guarded_compare('mica_vs_common_shim',d,t)
  self.assertEqual(out['alternative_source'],'COMMON_SUBSTITUTE_NOT_ASSERTED_CANONICAL_PRODUCT')
 def test_015_conditions_digest_consistency(self):
  d,t=get('tli_vs_common_board');a=guarded_compare('tli_vs_common_board',d,t)
  b=guarded_compare('tli_vs_common_board',d,copy.deepcopy(t))
  self.assertEqual(a,b)
 def test_016_cost_does_not_generate_MED(self):
  d,t=get('tli_vs_common_board');out=guarded_compare('tli_vs_common_board',d,t)
  self.assertEqual(out['metrics']['cost_ucs_sim']['unit'],'UCS_SIM')
if __name__=='__main__':unittest.main()
