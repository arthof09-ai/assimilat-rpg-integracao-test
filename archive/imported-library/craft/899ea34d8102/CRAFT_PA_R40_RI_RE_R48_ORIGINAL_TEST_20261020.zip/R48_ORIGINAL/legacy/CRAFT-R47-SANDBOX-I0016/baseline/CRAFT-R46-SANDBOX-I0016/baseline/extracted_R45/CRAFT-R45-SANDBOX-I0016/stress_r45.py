"""Deterministic adversarial mix. No real measurements or external side effects."""
import copy,json,random
from pathlib import Path
from r45_engine import LabBench,load_recipes,digest,SimulatedCrash,SandboxError
from fixture_factory import get_fixture,get_registries,readings,DEFAULT_TIME
ROOT=Path(__file__).resolve().parent
F=get_fixture();REG=get_registries();R=load_recipes(ROOT/'r44_legacy/recipes')
rng=random.Random(450016)
lots=copy.deepcopy(F['lots'])
for l in lots:
    if l['lot_id'] in ('SBX-SLATE-GOOD-01','SBX-MICA-GOOD-A','SBX-MICA-GOOD-B'):
        l['quantity']=150
bench=LabBench(R,lots,REG['instruments'],REG['sources'])
S={'seed':450016,'attempts':250,'statuses':{},'fault_rollbacks':0,'idempotent_replays':0,
   'rejected_noncanonical_input':0,'invariant_failures':0,'snapshot_restored':False,
   'scope':'SYNTHETIC_ONLY','official_rec_ids_created':0}
for i in range(250):
    kind=rng.choice(['TLI','MICA']);t=kind=='TLI'
    key='SBX-TLI-R44-v1' if t else 'SBX-MICA-R44-v1'
    lot_ids=['SBX-SLATE-GOOD-01'] if t else ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
    val=copy.deepcopy(F['tli_good_measurements'] if t else F['mica_good_measurements'])
    tools=list(F['tli_tools' if t else 'mica_tools'])
    skills=list(F['tli_skills' if t else 'mica_skills'])
    aid=f'SBX-R45-STRESS-{i:04d}'
    mode=rng.choice(['good','good','badqa','guardband','no_tool','insufficient','fault_after_core','fault_after_consume','bad_unit','future_reading'])
    if mode=='badqa':val['sharp_edges' if t else 'mount_fit']=True if t else False
    if mode=='guardband':val['length_mm' if t else 'thickness_difference_mm']=121 if t else 0.1
    if mode=='no_tool':tools=[]
    if mode=='insufficient':lot_ids=['SBX-SLATE-TOO-SMALL'] if t else ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
    ob=readings(R[key],val,lot_ids,aid)
    if mode=='bad_unit':ob['length_mm']['unit']='kg'
    if mode=='future_reading':ob['length_mm']['observed_at']='2031-01-01T00:00:00+00:00'
    stage={'fault_after_core':'AFTER_CORE_BEFORE_EVIDENCE_COMMIT','fault_after_consume':'AFTER_CONSUME'}.get(mode)
    prior=(digest(bench.core.state),digest(bench.provenance_events))
    try:
        r=bench.run(key,aid,lot_ids,ob,tools,skills,DEFAULT_TIME,stage)
        S['statuses'][r['status']]=S['statuses'].get(r['status'],0)+1
        if i%9==0:
            replay=bench.run(key,aid,lot_ids,ob,tools,skills,DEFAULT_TIME)
            assert replay['idempotent_replay']
            S['idempotent_replays']+=1
    except SimulatedCrash:
        assert prior==(digest(bench.core.state),digest(bench.provenance_events))
        S['fault_rollbacks']+=1
    except SandboxError as e:
        assert mode in ('bad_unit','future_reading'),(mode,str(e))
        assert prior==(digest(bench.core.state),digest(bench.provenance_events))
        S['rejected_noncanonical_input']+=1
    try:assert bench.audit()['ok']
    except AssertionError:S['invariant_failures']+=1;raise
p=ROOT/'results/r45_stress_snapshot.json'
bench.snapshot(p)
restored=LabBench.restore(p,R)
S['snapshot_restored']=restored.audit()==bench.audit()
S['evidence_events']=bench.audit()['evidence_events']
S['core_events']=bench.audit()['core_events']
S['evidence_head_hash']=bench.audit()['evidence_head_hash']
S['outcome']='PASS' if S['snapshot_restored'] and S['invariant_failures']==0 else 'FAIL'
(ROOT/'results/r45_stress_summary.json').write_text(json.dumps(S,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(S,indent=2,sort_keys=True))
assert S['outcome']=='PASS'
