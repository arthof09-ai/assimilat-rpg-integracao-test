"""R45 tests only: R44 regression is run separately from legacy tests."""
import copy,json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from r45_engine import LabBench,paired_comparison,SandboxError,SimulatedCrash,digest,load_recipes
from fixture_factory import get_fixture,get_registries,readings,DEFAULT_TIME

R=load_recipes(ROOT/'r44_legacy/recipes')
F=get_fixture(); REG=get_registries()
M=json.loads((ROOT/'fixtures/comparisons_synthetic.json').read_text(encoding='utf-8'))['comparisons']

class R45Tests(unittest.TestCase):
    def setUp(self):
        self.e=LabBench(R,F['lots'],REG['instruments'],REG['sources'])
        self.s=['SBX-SLATE-GOOD-01'];self.m=['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']

    def args(self,kind='tli',aid='SBX-R45-A',overrides=None):
        t=(kind=='tli');k='SBX-TLI-R44-v1' if t else 'SBX-MICA-R44-v1'
        lots=self.s if t else self.m
        qa=F['tli_good_measurements'] if t else F['mica_good_measurements']
        observations=readings(R[k],qa,lots,aid,overrides)
        return [k,aid,copy.deepcopy(lots),observations,
                F['tli_tools' if t else 'mica_tools'],
                F['tli_skills' if t else 'mica_skills'], DEFAULT_TIME]

    def test_001_initial_state_clean(self):
        self.assertTrue(self.e.audit()['ok']);self.assertEqual(self.e.audit()['evidence_events'],0)
    def test_002_two_legacy_recipes_only(self):
        self.assertEqual(len(self.e.recipes),2)
    def test_003_tli_pass_with_contracts_and_consumption(self):
        r=self.e.run(*self.args());self.assertEqual(r['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(self.e.core.state['lots'][self.s[0]]['quantity'],1)
        self.assertEqual(len(r['transformation_stage_trace']),6)
        self.assertEqual(r['qa_verdicts']['length_mm']['verdict'],'PASS')
    def test_004_mica_pass_same_motor(self):
        r=self.e.run(*self.args('mica'))
        self.assertEqual(r['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(r['products'][0]['units'],2)
    def test_005_combined_engine_ledger_atomic(self):
        self.e.run(*self.args());self.e.run(*self.args('mica',aid='SBX-R45-MICA'))
        self.assertTrue(self.e.audit()['ok']);self.assertEqual(self.e.audit()['core_events'],2)
    def test_006_cm_conversion_exact(self):
        args=self.args(overrides={'length_mm':{'value':12,'unit':'cm','uncertainty_abs':0.01}})
        r=self.e.run(*args);self.assertEqual(r['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(r['qa_verdicts']['length_mm']['nominal'],'120')
    def test_007_bad_unit_blocks_before_consumption(self):
        args=self.args(overrides={'length_mm':{'unit':'kg'}})
        with self.assertRaisesRegex(SandboxError,'UNIT'):self.e.run(*args)
        self.assertEqual(self.e.audit()['core_events'],0)
    def test_008_missing_field_blocks_no_defaults(self):
        args=self.args();del args[3]['thickness_mm']
        with self.assertRaisesRegex(SandboxError,'FIELDS'):self.e.run(*args)
    def test_009_extra_field_blocks(self):
        args=self.args();args[3]['made_up']=args[3]['length_mm']
        with self.assertRaisesRegex(SandboxError,'FIELDS'):self.e.run(*args)
    def test_010_missing_instrument_blocks(self):
        args=self.args(overrides={'length_mm':{'instrument_id':'NO-INSTRUMENT'}})
        with self.assertRaisesRegex(SandboxError,'INSTRUMENT'):self.e.run(*args)
    def test_011_wrong_instrument_dimension_blocks(self):
        args=self.args(overrides={'length_mm':{'instrument_id':'SBX-COUNTER-01'}})
        with self.assertRaisesRegex(SandboxError,'UNIT_DIMENSION'):self.e.run(*args)
    def test_012_expired_calibration_blocks(self):
        args=self.args(overrides={'length_mm':{'observed_at':'2026-10-12T12:00:00+00:00'}})
        with self.assertRaisesRegex(SandboxError,'READING_STALE_OR_FUTURE'):self.e.run(*args)
    def test_013_specific_calibration_out_of_window(self):
        args=self.args();args[6]='2026-10-13T12:00:00+00:00'
        for row in args[3].values():row['observed_at']='2026-10-12T12:00:00+00:00'
        with self.assertRaisesRegex(SandboxError,'CALIBRATION_WINDOW'):self.e.run(*args)
    def test_014_future_reading_rejected(self):
        args=self.args(overrides={'length_mm':{'observed_at':'2026-10-10T12:00:00+00:00'}})
        with self.assertRaisesRegex(SandboxError,'STALE_OR_FUTURE'):self.e.run(*args)
    def test_015_real_claim_cannot_ride_synthetic_fixture(self):
        args=self.args(overrides={'length_mm':{'evidence_kind':'MEASURED'}})
        with self.assertRaisesRegex(SandboxError,'REAL_MEASUREMENT_INGESTION_REQUIRES_GATE'):self.e.run(*args)
    def test_016_negative_uncertainty_rejected(self):
        args=self.args(overrides={'length_mm':{'uncertainty_abs':-1}})
        with self.assertRaisesRegex(SandboxError,'NEGATIVE_UNCERTAINTY'):self.e.run(*args)
    def test_017_understated_instrument_uncertainty_rejected(self):
        args=self.args(overrides={'length_mm':{'uncertainty_abs':0.001}})
        with self.assertRaisesRegex(SandboxError,'UNCERTAINTY_BELOW'):self.e.run(*args)
    def test_018_not_a_number_rejected(self):
        args=self.args(overrides={'length_mm':{'value':'NaN'}})
        with self.assertRaisesRegex(SandboxError,'NONFINITE'):self.e.run(*args)
    def test_019_boolean_as_number_rejected(self):
        args=self.args(overrides={'length_mm':{'value':True}})
        with self.assertRaisesRegex(SandboxError,'INVALID_NUMERIC'):self.e.run(*args)
    def test_020_bool_uncertainty_rejected(self):
        args=self.args(overrides={'cracks':{'uncertainty_abs':1}})
        with self.assertRaisesRegex(SandboxError,'INVALID_BOOLEAN'):self.e.run(*args)
    def test_021_count_must_be_integer(self):
        args=self.args(overrides={'markings_repeat_count':{'value':2.5}})
        with self.assertRaisesRegex(SandboxError,'INVALID_EXACT_COUNT'):self.e.run(*args)
    def test_022_guardband_boundary_not_pass(self):
        args=self.args(overrides={'length_mm':{'value':121,'uncertainty_abs':0.1}})
        r=self.e.run(*args)
        self.assertEqual(r['status'],'REJECTED_QUALITY')
        self.assertIn('length_mm:R45_GUARDBAND_INDETERMINATE',r['rejection_reasons'])
        self.assertFalse(r['products']);self.assertEqual(len(r['scrap']),1)
    def test_023_guardband_strictly_outside_fail(self):
        args=self.args(overrides={'length_mm':{'value':124}})
        r=self.e.run(*args)
        self.assertEqual(r['status'],'REJECTED_QUALITY')
        self.assertIn('length_mm:R45_GUARDBAND_FAIL',r['rejection_reasons'])
    def test_024_guardband_mica_tolerance(self):
        args=self.args('mica',overrides={'thickness_difference_mm':{'value':0.099,'uncertainty_abs':0.01}})
        r=self.e.run(*args)
        self.assertEqual(r['status'],'REJECTED_QUALITY')
    def test_025_source_id_substitution_rejected(self):
        args=self.args(overrides={'length_mm':{'source_page_id':'another-source'}})
        with self.assertRaisesRegex(SandboxError,'SOURCE_OR_LOTS'):self.e.run(*args)
    def test_026_lot_binding_substitution_rejected(self):
        args=self.args(overrides={'length_mm':{'lot_ids':['SBX-OTHER']}})
        with self.assertRaisesRegex(SandboxError,'SOURCE_OR_LOTS'):self.e.run(*args)
    def test_027_precheck_wrong_ingredient_stays_no_consumption(self):
        args=self.args();args[2]=['SBX-MICA-GOOD-A']
        # readings bound to selected lot; no source mismatch for observations, but wrong stock rejected by core
        for ob in args[3].values():ob['lot_ids']=args[2]
        r=self.e.run(*args)
        self.assertEqual(r['status'],'REJECTED_PRECHECK')
        self.assertFalse(r['consumed'])
    def test_028_precheck_lacking_tool(self):
        args=self.args();args[4]=[]
        r=self.e.run(*args)
        self.assertEqual(r['status'],'REJECTED_PRECHECK')
    def test_029_idempotent_same_payload_zero_extra_debit(self):
        args=self.args();a=self.e.run(*args);b=self.e.run(*args)
        self.assertEqual(a['r45_evidence_id'],b['r45_evidence_id'])
        self.assertTrue(b['idempotent_replay']);self.assertEqual(self.e.audit()['core_events'],1)
    def test_030_conflicting_attempt_key_rejected(self):
        args=self.args();self.e.run(*args)
        changed=self.args(overrides={'length_mm':{'value':119.6}})
        with self.assertRaisesRegex(SandboxError,'IDEMPOTENCY'):self.e.run(*changed)
    def test_031_duplicate_readings_within_one_attempt(self):
        args=self.args();args[3]['width_mm']['reading_id']=args[3]['length_mm']['reading_id']
        with self.assertRaisesRegex(SandboxError,'DUPLICATE_READING_IDS'):self.e.run(*args)
    def test_032_duplicate_readings_between_attempts(self):
        self.e.run(*self.args())
        args=self.args(aid='SBX-R45-B');args[3]['width_mm']['reading_id']='SBX-OBS-SBX-R45-A-width_mm'
        with self.assertRaisesRegex(SandboxError,'READING_ID_REUSED'):self.e.run(*args)
    def test_033_rollback_after_consume(self):
        args=self.args();state=digest(self.e.core.state)
        with self.assertRaises(SimulatedCrash):self.e.run(*args,fault_stage='AFTER_CONSUME')
        self.assertEqual(state,digest(self.e.core.state));self.assertEqual(self.e.audit()['evidence_events'],0)
    def test_034_rollback_after_qa(self):
        args=self.args();state=digest(self.e.core.state)
        with self.assertRaises(SimulatedCrash):self.e.run(*args,fault_stage='AFTER_QA')
        self.assertEqual(state,digest(self.e.core.state))
    def test_035_rollback_after_core_before_evidence(self):
        args=self.args();state=digest(self.e.core.state)
        with self.assertRaises(SimulatedCrash):self.e.run(*args,fault_stage='AFTER_CORE_BEFORE_EVIDENCE_COMMIT')
        self.assertEqual(state,digest(self.e.core.state))
        self.assertEqual(self.e.audit()['evidence_events'],0)
    def test_036_retry_after_fault_consumes_once(self):
        args=self.args()
        with self.assertRaises(SimulatedCrash):self.e.run(*args,fault_stage='AFTER_CORE_BEFORE_EVIDENCE_COMMIT')
        r=self.e.run(*args);self.assertEqual(r['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(self.e.core.state['lots'][self.s[0]]['quantity'],1)
    def test_037_tampered_source_registry_audit_fails(self):
        self.e.sources[next(iter(self.e.sources))]['source_status']='CANONICAL'
        self.assertFalse(self.e.audit()['ok'])
    def test_038_tampered_instrument_audit_fails(self):
        self.e.instruments['SBX-CALIPER-01']['uncertainty_floor']='0'
        self.assertFalse(self.e.audit()['ok'])
    def test_039_tampered_receipt_fails(self):
        self.e.run(*self.args())
        self.e.provenance_events[0]['event']['r44_receipt']['status']='OFFICIAL_PASS'
        self.assertFalse(self.e.audit()['ok'])
    def test_040_tampered_core_state_fails(self):
        self.e.run(*self.args())
        self.e.core.state['lots'][self.s[0]]['quantity']=2
        self.assertFalse(self.e.audit()['ok'])
    def test_041_snapshot_restore_exact_hash(self):
        self.e.run(*self.args());self.e.run(*self.args('mica',aid='SBX-R45-MICA'))
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';h=self.e.snapshot(p);o=LabBench.restore(p,R)
            self.assertEqual(self.e.audit(),o.audit());self.assertEqual(h,digest({k:v for k,v in json.loads(p.read_text()).items() if k!='sha256'}))
    def test_042_tampered_snapshot_refused(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';self.e.snapshot(p);w=json.loads(p.read_text())
            w['initial_lots'][self.s[0]]['quantity']=999;p.write_text(json.dumps(w))
            with self.assertRaisesRegex(SandboxError,'SNAPSHOT_HASH_INVALID'):LabBench.restore(p)
    def test_043_different_recipe_refuses_restore(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';self.e.snapshot(p)
            changed=copy.deepcopy(R);changed['SBX-TLI-R44-v1']['name']='MODIFIED'
            with self.assertRaisesRegex(SandboxError,'RESTORE_RECIPE_CHANGED'):LabBench.restore(p,changed)
    def test_044_comparison_tli_5_pairs(self):
        x=M['tli_vs_common_board'];r=paired_comparison(x['pairs'],x['metrics'])
        self.assertEqual(r['n_matched_pairs'],5)
        self.assertEqual(r['metrics']['cost_ucs_sim']['counts']['alternative_better'],5)
    def test_045_comparison_mica_5_pairs(self):
        x=M['mica_vs_common_shim'];r=paired_comparison(x['pairs'],x['metrics'])
        self.assertEqual(r['n_matched_pairs'],5)
    def test_046_comparison_wrong_unit_rejected(self):
        x=copy.deepcopy(M['tli_vs_common_board']);x['pairs'][0]['alternative']['flatness_mm']['unit']='cm'
        with self.assertRaisesRegex(SandboxError,'UNIT_MISMATCH'):paired_comparison(x['pairs'],x['metrics'])
    def test_047_comparison_fake_measured_rejected(self):
        x=copy.deepcopy(M['tli_vs_common_board']);x['pairs'][0]['evidence_kind']='MEASURED'
        with self.assertRaisesRegex(SandboxError,'NOT_SYNTHETIC'):paired_comparison(x['pairs'],x['metrics'])
    def test_048_comparison_duplicate_trial_rejected(self):
        x=copy.deepcopy(M['mica_vs_common_shim']);x['pairs'][1]['trial_id']=x['pairs'][0]['trial_id']
        with self.assertRaisesRegex(SandboxError,'DUPLICATE'):paired_comparison(x['pairs'],x['metrics'])
    def test_049_comparison_too_few_pairs_rejected(self):
        x=M['mica_vs_common_shim']
        with self.assertRaisesRegex(SandboxError,'TOO_FEW'):paired_comparison(x['pairs'][:2],x['metrics'])
    def test_050_wrong_source_registry_rejected(self):
        sources=copy.deepcopy(REG['sources']);sources.pop(R['SBX-TLI-R44-v1']['source_page_id'])
        with self.assertRaisesRegex(SandboxError,'SOURCE_REGISTRY'):LabBench(R,F['lots'],REG['instruments'],sources)
    def test_051_all_new_product_ids_are_local(self):
        r=self.e.run(*self.args());p=r['products'][0]
        self.assertIsNone(p['official_product_id']);self.assertEqual(p['mechanical_bonus'],0)
        self.assertTrue(p['product_id'].startswith('SBX-'))
    def test_052_signed_chain_detects_event_swap(self):
        self.e.run(*self.args());self.e.run(*self.args('mica',aid='SBX-R45-MICA'))
        self.e.provenance_events.reverse()
        self.assertFalse(self.e.audit()['ok'])

if __name__=='__main__':unittest.main()
