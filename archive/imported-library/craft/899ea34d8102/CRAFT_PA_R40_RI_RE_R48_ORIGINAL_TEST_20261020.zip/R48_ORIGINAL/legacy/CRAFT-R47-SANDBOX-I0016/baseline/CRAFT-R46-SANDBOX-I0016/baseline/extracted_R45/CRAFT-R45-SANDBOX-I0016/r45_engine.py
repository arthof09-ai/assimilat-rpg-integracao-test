"""R45 additive scientific intake and evidence ledger atop unmodified R44 engine.

No Notion access.  Every executed lot and reading must be tagged SYNTHETIC.
The MEASURED ingestion interface is deliberately gated pending verified real
calibration/source authority.  Data acceptance does NOT mean canonical approval.
"""
from __future__ import annotations
import copy, datetime as dt, json, math
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from r44_legacy.experimental_engine import (SandboxEngine, SandboxError,
    SimulatedCrash, load_recipes, digest, NAMESPACE as OLD_NAMESPACE)

NAMESPACE = 'SBX-CRAFT-R45-I0016'
SCHEMA = 'R45-EVIDENCE-SNAPSHOT-v1'
GENESIS = digest({'namespace':NAMESPACE, 'purpose':'RESEARCH_ONLY', 'genesis':1})
ALLOWED_UNITS={'mm':('length',Decimal('1')), 'cm':('length',Decimal('10')),
               'm':('length',Decimal('1000')), 'count':('count',Decimal('1')),
               'bool':('boolean',Decimal('1'))}


def parse_instant(value):
    if not isinstance(value,str) or not value:
        raise SandboxError('INVALID_TIMESTAMP')
    try:
        v=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError as e:
        raise SandboxError('INVALID_TIMESTAMP') from e
    if v.tzinfo is None or v.utcoffset() is None:
        raise SandboxError('TIMESTAMP_REQUIRES_TZ')
    return v.astimezone(dt.timezone.utc)


def dec(value):
    if type(value) not in (int,float,str):
        raise SandboxError('INVALID_NUMERIC_MEASUREMENT')
    try:
        d=Decimal(str(value))
    except InvalidOperation as e:
        raise SandboxError('INVALID_NUMERIC_MEASUREMENT') from e
    if not d.is_finite():
        raise SandboxError('NONFINITE_MEASUREMENT')
    return d


def dimension_for_field(field, rule):
    if rule['kind']=='bool_eq': return 'boolean'
    if field.endswith('_count') or field == 'piece_count': return 'count'
    if field.endswith('_mm'): return 'length'
    raise SandboxError('UNMAPPED_MEASUREMENT_DIMENSION')


class R45Core(SandboxEngine):
    @staticmethod
    def _quality(recipe, measurements):
        reasons=SandboxEngine._quality(recipe,measurements)
        reasons+=measurements.get('__r45_guard_failures__',[])
        return reasons


class LabBench:
    """Atomic quality-intake wrapper: R44 core + R45 evidence history."""
    def __init__(self, recipes:dict, lots:list[dict], instruments:dict, sources:dict):
        self.recipes=copy.deepcopy(recipes)
        if len(self.recipes)!=2 or set(self.recipes)!={'SBX-TLI-R44-v1','SBX-MICA-R44-v1'}:
            raise SandboxError('R45_TWO_EXISTING_RECIPES_ONLY')
        self.instruments=copy.deepcopy(instruments)
        self.sources=copy.deepcopy(sources)
        self.instrument_hash=digest(self.instruments)
        self.sources_hash=digest(self.sources)
        self.recipe_hash=digest(self.recipes)
        self.core=R45Core(self.recipes,lots)
        self.provenance_events=[]
        self.head_hash=GENESIS
        for recipe in recipes.values():
            src=recipe['source_page_id']
            meta=sources.get(src)
            if not meta or meta.get('source_status')!='PS_SEMICANONICAL_NOT_STOCK' or not meta.get('last_edited_at'):
                raise SandboxError('SOURCE_REGISTRY_MISSING_OR_NOT_PS')
        if not self.audit()['ok']:
            raise SandboxError('INVALID_GENESIS')

    def _normalize(self,recipe_key,attempt_id,lot_ids,observations,at):
        recipe=self.recipes[recipe_key]
        if type(observations) is not dict or set(observations)!={q['field'] for q in recipe['qa_rules']}:
            raise SandboxError('MISSING_OR_EXTRA_INSPECTION_FIELDS')
        if len(set(lot_ids))!=len(lot_ids):
            raise SandboxError('DUPLICATE_SELECTED_LOT')
        at_date=parse_instant(at)
        vals={}; verdicts={}; guard_failures=[]; reading_ids=[]
        for rule in recipe['qa_rules']:
            f=rule['field']; obs=observations[f]
            if type(obs) is not dict:
                raise SandboxError('OBSERVATION_MUST_HAVE_PROVENANCE')
            required={'reading_id','value','unit','uncertainty_abs','instrument_id','observed_at','evidence_kind','source_page_id','lot_ids'}
            if set(obs)!=required:
                raise SandboxError('OBSERVATION_CONTRACT_FIELDS')
            rid=obs['reading_id']
            if not isinstance(rid,str) or not rid.startswith('SBX-OBS-') or len(rid)>150:
                raise SandboxError('INVALID_READING_ID')
            reading_ids.append(rid)
            if obs['evidence_kind']!='SYNTHETIC':
                raise SandboxError('REAL_MEASUREMENT_INGESTION_REQUIRES_GATE')
            if obs['source_page_id']!=recipe['source_page_id'] or obs['lot_ids']!=lot_ids:
                raise SandboxError('OBSERVATION_SOURCE_OR_LOTS_MISMATCH')
            observed_at=parse_instant(obs['observed_at'])
            if observed_at>at_date or (at_date-observed_at)>dt.timedelta(hours=24):
                raise SandboxError('READING_STALE_OR_FUTURE')
            inst=self.instruments.get(obs['instrument_id'])
            if not inst or inst.get('calibration_class')!='SYNTHETIC_FIXTURE_NOT_REAL_CALIBRATION':
                raise SandboxError('INSTRUMENT_NOT_VERIFIED_IN_SYNTHETIC_FIXTURE')
            if not (parse_instant(inst['calibration_start'])<=observed_at<=parse_instant(inst['calibration_expires'])):
                raise SandboxError('INSTRUMENT_CALIBRATION_WINDOW_MISMATCH')
            spec_dim=dimension_for_field(f,rule)
            unitspec=ALLOWED_UNITS.get(obs['unit'])
            if not unitspec or unitspec[0]!=spec_dim or spec_dim not in inst['dimensions']:
                raise SandboxError('INSTRUMENT_OR_UNIT_DIMENSION_MISMATCH')
            if spec_dim=='boolean':
                if type(obs['value']) is not bool or type(obs['uncertainty_abs']) not in (int,float) or obs['uncertainty_abs']!=0:
                    raise SandboxError('INVALID_BOOLEAN_INSPECTION')
                vals[f]=obs['value']
                verdicts[f]={'verdict':'PASS' if obs['value']==rule['value'] else 'FAIL',
                             'nominal':obs['value'],'interval':None,'unit':'bool'}
                if vals[f]!=rule['value']:
                    guard_failures.append(f'{f}:INSPECTED_BOOLEAN_FAIL')
                continue
            d=dec(obs['value']); u=dec(obs['uncertainty_abs'])
            if u<0: raise SandboxError('NEGATIVE_UNCERTAINTY')
            factor=unitspec[1]
            d=d*factor; u=u*factor
            # Instrument floors are specified in canonical base units (mm/count).
            if u<dec(inst['uncertainty_floor']):
                raise SandboxError('UNCERTAINTY_BELOW_SYNTHETIC_INSTRUMENT_FLOOR')
            if spec_dim=='count':
                if d!=d.to_integral_value() or u!=0 or d<0:
                    raise SandboxError('INVALID_EXACT_COUNT')
                value=int(d)
            else:
                value=float(d)
                if not math.isfinite(value): raise SandboxError('NONFINITE_MEASUREMENT')
            vals[f]=value
            low=d-u; high=d+u
            lo=Decimal(str(rule['min'])) if 'min' in rule else None
            hi=Decimal(str(rule['max'])) if 'max' in rule else None
            wholly_inside=(lo is None or low>=lo) and (hi is None or high<=hi)
            wholly_outside=(lo is not None and high<lo) or (hi is not None and low>hi)
            verdict='PASS' if wholly_inside else 'FAIL' if wholly_outside else 'INDETERMINATE'
            verdicts[f]={'verdict':verdict,'nominal':str(d),'interval':[str(low),str(high)],
                         'unit':'mm' if spec_dim=='length' else 'count'}
            if verdict!='PASS': guard_failures.append(f'{f}:R45_GUARDBAND_{verdict}')
        if len(set(reading_ids))!=len(reading_ids):
            raise SandboxError('DUPLICATE_READING_IDS_WITHIN_EVENT')
        all_prev={r['reading_id'] for e in self.provenance_events for r in e['event']['observations'].values()}
        if all_prev.intersection(reading_ids):
            raise SandboxError('READING_ID_REUSED_ACROSS_ATTEMPTS')
        vals['__r45_guard_failures__']=sorted(guard_failures)
        vals['__r45_evidence_hash__']=digest(observations)
        return vals,verdicts

    def run(self,recipe_key,attempt_id,lot_ids,observations,tools,skills,at,
            fault_stage=None):
        if not self.audit()['ok']: raise SandboxError('EVIDENCE_LEDGER_INTEGRITY_FAILURE')
        if recipe_key not in self.recipes: raise SandboxError('UNKNOWN_R45_RECIPE')
        if not attempt_id.startswith('SBX-'): raise SandboxError('INVALID_SANDBOX_ATTEMPT')
        payload={'recipe_key':recipe_key,'attempt_id':attempt_id,'lot_ids':lot_ids,
                 'observations':observations,'tools':tools,'skills':skills,'at':at}
        request_hash=digest(payload)
        old=next((e for e in self.provenance_events if e['event']['attempt_id']==attempt_id),None)
        if old:
            if old['event']['request_hash']!=request_hash:
                raise SandboxError('IDEMPOTENCY_KEY_REUSE_WITH_DIFFERENT_MEASUREMENT_REQUEST')
            return {**copy.deepcopy(old['event']['r44_receipt']),
                    'r45_evidence_id':old['hash'],'idempotent_replay':True,
                    'qa_verdicts':copy.deepcopy(old['event']['qa_verdicts'])}
        qa,verdicts=self._normalize(recipe_key,attempt_id,lot_ids,observations,at)
        core_staged=copy.deepcopy(self.core)
        receipt=core_staged.run(recipe_key,attempt_id,lot_ids,qa,tools,skills,
                                fault_stage if fault_stage not in ('AFTER_CORE_BEFORE_EVIDENCE_COMMIT',) else None)
        if fault_stage=='AFTER_CORE_BEFORE_EVIDENCE_COMMIT':
            raise SimulatedCrash('INJECTED_AFTER_CORE_BEFORE_EVIDENCE_COMMIT')
        if any(x['verdict']!='PASS' for x in verdicts.values()) and receipt['status']=='EXPERIMENTAL_QA_PASS':
            raise SandboxError('GUARDBAND_BYPASS')
        row={'seq':len(self.provenance_events)+1,'attempt_id':attempt_id,
             'recipe_key':recipe_key,'request_hash':request_hash,
             'r44_receipt':copy.deepcopy(receipt),
             'r44_event_hash':core_staged.state['events'][-1]['hash'],
             'run_at':at,'observations':copy.deepcopy(observations),
             'qa_verdicts':verdicts,'source_registry_hash':self.sources_hash,
             'instrument_registry_hash':self.instrument_hash,
             'evidence_kind':'SYNTHETIC','official_rec_id':None}
        signed={'previous_hash':self.head_hash,'event':row}
        signed['hash']=digest(signed)
        old_core=self.core
        old_head=self.head_hash
        self.core=core_staged
        self.provenance_events.append(signed)
        self.head_hash=signed['hash']
        if not self.audit()['ok']:
            self.core=old_core
            self.provenance_events.pop()
            self.head_hash=old_head
            raise SandboxError('INVALID_ATOMIC_EVIDENCE_COMMIT_ROLLED_BACK')
        return {**copy.deepcopy(receipt),'r45_evidence_id':signed['hash'],
                'qa_verdicts':copy.deepcopy(verdicts)}

    def audit(self):
        problems=[]
        if digest(self.instruments)!=self.instrument_hash: problems.append('INSTRUMENT_REGISTRY_MUTATED')
        if digest(self.sources)!=self.sources_hash: problems.append('SOURCE_REGISTRY_MUTATED')
        if digest(self.recipes)!=self.recipe_hash: problems.append('RECIPE_REGISTRY_MUTATED')
        if self.core.recipe_hashes != {k:digest(r) for k,r in self.recipes.items()}:
            problems.append('R44_RECIPE_HASH_DRIFT')
        c=self.core.audit()
        if not c['ok']:problems.append('R44_CORE_AUDIT_FAILURE')
        if len(self.core.state['events'])!=len(self.provenance_events):
            problems.append('CORE_EVIDENCE_EVENT_COUNT_MISMATCH')
        prev=GENESIS; ids=set(); readings=set()
        for i,entry in enumerate(self.provenance_events,1):
            if entry['previous_hash']!=prev or entry['hash']!=digest({'previous_hash':prev,'event':entry['event']}):
                problems.append(f'EVIDENCE_CHAIN_BROKEN_{i}')
            prev=entry['hash'];e=entry['event']
            if e['seq']!=i or e['attempt_id'] in ids: problems.append('EVIDENCE_ORDER_OR_DUPLICATE')
            ids.add(e['attempt_id'])
            if e.get('official_rec_id') is not None or e.get('evidence_kind')!='SYNTHETIC':
                problems.append('EVIDENCE_SCOPE_CROSSED')
            if e['source_registry_hash']!=self.sources_hash or e['instrument_registry_hash']!=self.instrument_hash:
                problems.append('REGISTRY_ANCHOR_MISMATCH')
            if i<=len(self.core.state['events']):
                r44_event=self.core.state['events'][i-1]
                if (e['r44_event_hash']!=r44_event['hash'] or
                    e['attempt_id']!=r44_event['event']['attempt_id'] or
                    e['r44_receipt']!=self.core.state['attempts'].get(e['attempt_id'])):
                    problems.append('R44_EVIDENCE_RECEIPT_MISMATCH')
            for r in e['observations'].values():
                if r['reading_id'] in readings:problems.append('EVIDENCE_READING_REUSE')
                readings.add(r['reading_id'])
            if e['r44_receipt']['status']=='EXPERIMENTAL_QA_PASS' and any(x['verdict']!='PASS' for x in e['qa_verdicts'].values()):
                problems.append('UNCERTAIN_QA_WAS_ACCEPTED')
        if self.head_hash!=prev: problems.append('EVIDENCE_HEAD_MISMATCH')
        return {'ok':not problems,'issues':sorted(set(problems)),
                'evidence_events':len(self.provenance_events),
                'core_events':len(self.core.state['events']),
                'evidence_head_hash':self.head_hash,
                'core_head_hash':c['head_hash']}

    def snapshot(self,path):
        a=self.audit()
        if not a['ok']:raise SandboxError('REFUSE_INVALID_EVIDENCE_SNAPSHOT')
        w={'schema':SCHEMA,'namespace':NAMESPACE,'r44_namespace':OLD_NAMESPACE,
           'recipes':self.recipes,'recipe_hash':self.recipe_hash,
           'instruments':self.instruments,'instrument_hash':self.instrument_hash,
           'sources':self.sources,'sources_hash':self.sources_hash,
           'initial_lots':self.core.initial_lots,
           'initial_hash':self.core.initial_hash,
           'core_state':self.core.state,
           'provenance_events':self.provenance_events,
           'evidence_head_hash':self.head_hash}
        w['sha256']=digest(w)
        p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_suffix(p.suffix+'.tmp')
        tmp.write_text(json.dumps(w,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        tmp.replace(p)
        return w['sha256']

    @classmethod
    def restore(cls,path,recipe_overrides=None):
        w=json.loads(Path(path).read_text(encoding='utf8'))
        expected=w.pop('sha256',None)
        if expected is None or digest(w)!=expected:
            raise SandboxError('R45_SNAPSHOT_HASH_INVALID')
        if w['namespace']!=NAMESPACE or w['schema']!=SCHEMA or w['r44_namespace']!=OLD_NAMESPACE:
            raise SandboxError('R45_SNAPSHOT_SCHEMA_INVALID')
        if recipe_overrides is not None and digest(recipe_overrides)!=w['recipe_hash']:
            raise SandboxError('RESTORE_RECIPE_CHANGED')
        o=cls(w['recipes'],list(w['initial_lots'].values()),w['instruments'],w['sources'])
        if (o.recipe_hash!=w['recipe_hash'] or o.instrument_hash!=w['instrument_hash'] or
            o.sources_hash!=w['sources_hash'] or o.core.initial_hash!=w['initial_hash']):
            raise SandboxError('RESTORE_ANCHOR_HASH_MISMATCH')
        o.core.state=w['core_state']
        o.provenance_events=w['provenance_events'];o.head_hash=w['evidence_head_hash']
        if not o.audit()['ok']:
            raise SandboxError('RESTORE_STATE_REPLAY_FAILURE')
        return o


def paired_comparison(trials:list[dict],metrics:dict) -> dict:
    """Paired descriptive intervals; cannot establish empirical superiority."""
    if len(trials)<3:raise SandboxError('TOO_FEW_SYNTHETIC_PAIRS')
    seen=set();out={}
    for t in trials:
        if t.get('evidence_kind')!='SYNTHETIC' or t.get('trial_id') in seen:
            raise SandboxError('NOT_SYNTHETIC_OR_DUPLICATE_TRIAL')
        seen.add(t['trial_id'])
        if set(t)!= {'trial_id','evidence_kind','candidate','alternative','matched_setup_id'}:
            raise SandboxError('INVALID_COMPARATOR_CONTRACT')
        if not t['matched_setup_id'].startswith('SBX-MATCH-'):
            raise SandboxError('UNMATCHED_OR_UNVERIFIED_SETUP')
    for metric,direction in metrics.items():
        if direction not in ('lower','higher'):raise SandboxError('INVALID_METRIC_DIRECTION')
        counts={'candidate_better':0,'alternative_better':0,'inconclusive':0}
        deltas=[]
        reference_unit=None
        for t in trials:
            cand=t['candidate'][metric];alt=t['alternative'][metric]
            if not (isinstance(cand,dict) and isinstance(alt,dict) and
                    set(cand)=={'value','uncertainty_abs','unit'} and set(alt)=={'value','uncertainty_abs','unit'}):
                raise SandboxError('COMPARISON_MISSING_METROLOGY')
            if cand['unit']!=alt['unit']:raise SandboxError('COMPARISON_UNIT_MISMATCH')
            if reference_unit is None: reference_unit=cand['unit']
            if cand['unit']!=reference_unit:raise SandboxError('COMPARISON_CROSS_TRIAL_UNIT_DRIFT')
            v,u,v2,u2=(dec(cand['value']),dec(cand['uncertainty_abs']),
                       dec(alt['value']),dec(alt['uncertainty_abs']))
            if u<0 or u2<0:raise SandboxError('NEGATIVE_COMPARISON_UNCERTAINTY')
            if v<0 or v2<0:raise SandboxError('NEGATIVE_METRIC_INVALID')
            signed=(v2-v) if direction=='lower' else (v-v2)
            low=signed-(u+u2);high=signed+(u+u2)
            outcome='candidate_better' if low>0 else 'alternative_better' if high<0 else 'inconclusive'
            counts[outcome]+=1
            deltas.append({'trial_id':t['trial_id'],'signed_improvement':str(signed),
                           'interval':[str(low),str(high)],'outcome':outcome})
        out[metric]={'unit':trials[0]['candidate'][metric]['unit'],
                     'direction':direction,'n_pairs':len(trials),'counts':counts,'paired_details':deltas}
    return {'scope':'SYNTHETIC_PAIRED_DESCRIPTIVE_NOT_EMPIRICAL',
            'n_matched_pairs':len(trials),'metrics':out,
            'inference':'NO_CANONICAL_OR_EMPIRICAL_SUPERIORITY_CLAIM'}


def quarantine_claimed_measurements(claim:dict,recipes:dict) -> dict:
    """Read-only intake for *claims* of physical measurements.

    A schema-valid claim is never treated as physically verified or executable.
    Such records require independent review, source chain, and authorization.
    This function changes no inventory and creates no accepted QA event.
    """
    if type(claim) is not dict:
        raise SandboxError('INVALID_CLAIM_TYPE')
    required={'claim_id','recipe_key','evidence_kind','sample_id','source_page_id',
              'sample_chain_ref','measurement_document_sha256','instrument_cert_sha256',
              'operator_attestation_ref','observed_at','observations'}
    if set(claim)!=required:
        raise SandboxError('INCOMPLETE_MEASURED_CLAIM_CONTRACT')
    if claim['evidence_kind']!='MEASURED_CLAIM_UNVERIFIED':
        raise SandboxError('NO_PROMOTION_BY_EVIDENCE_LABEL')
    if claim['recipe_key'] not in recipes or claim['source_page_id']!=recipes[claim['recipe_key']]['source_page_id']:
        raise SandboxError('MEASURED_CLAIM_UNKNOWN_RECIPE_OR_SOURCE')
    if not (isinstance(claim['claim_id'],str) and claim['claim_id'].startswith('SBX-CLAIM-')
            and isinstance(claim['sample_id'],str) and claim['sample_id'].startswith('SBX-SAMPLE-')):
        raise SandboxError('INVALID_MEASUREMENT_CLAIM_IDENTIFIERS')
    for key in ('measurement_document_sha256','instrument_cert_sha256'):
        v=claim[key]
        if not (isinstance(v,str) and len(v)==64 and all(ch in '0123456789abcdef' for ch in v)):
            raise SandboxError('INVALID_EVIDENCE_DIGEST')
    for key in ('sample_chain_ref','operator_attestation_ref'):
        if not (isinstance(claim[key],str) and len(claim[key])>=12):
            raise SandboxError('MEASUREMENT_CLAIM_CHAIN_MISSING')
    parse_instant(claim['observed_at'])
    if not isinstance(claim['observations'],dict) or not claim['observations']:
        raise SandboxError('MEASURED_CLAIM_WITHOUT_OBSERVATIONS')
    required_fields={q['field'] for q in recipes[claim['recipe_key']]['qa_rules']}
    if set(claim['observations'])!=required_fields:
        raise SandboxError('MEASURED_CLAIM_INCOMPLETE_QA_FIELDS')
    return {'claim_id':claim['claim_id'],'intake_digest_sha256':digest(claim),
            'evidence_status':'CLAIM_SCHEMA_ACCEPTED_QUARANTINE_ONLY_NOT_VERIFIED',
            'verification_required':['actual_document_bytes_and_digest','instrument_calibration_real',
              'sample_chain_and_authority','independent_inspector','actual_stock_and_scene_state',
              'NAC_CONT_REPA_NAC_PASS_AND_WRITER_GATES'],
            'execution_authorized':False,'official_rec_id':None,
            'materialized':False,'stock_effect':0}
