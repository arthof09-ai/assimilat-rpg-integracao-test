"""Deterministic synthetic observation fixtures, NOT field measurements."""
from __future__ import annotations
import copy,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DEFAULT_TIME='2026-10-09T11:45:00+00:00'


def get_fixture():
    return json.loads((ROOT/'r44_legacy/fixtures/demo.json').read_text(encoding='utf-8'))


def get_registries():
    return json.loads((ROOT/'fixtures/registries_synthetic.json').read_text(encoding='utf-8'))


def readings(recipe,values,lot_ids,attempt_id,overrides=None,at=DEFAULT_TIME):
    """Make explicit, individual readings; exercise sample generation only."""
    out={}
    for qa in recipe['qa_rules']:
        field=qa['field'];v=values[field]
        dim='boolean' if qa['kind']=='bool_eq' else 'count' if field.endswith('_count') or field=='piece_count' else 'length'
        if dim=='boolean': instrument='SBX-VISUAL-01';unit='bool';uncertainty=0
        elif dim=='count': instrument='SBX-COUNTER-01';unit='count';uncertainty=0
        elif field=='thickness_difference_mm' or field=='groove_depth_mm':
            instrument='SBX-MICROMETER-01';unit='mm';uncertainty=0.01
        else:
            instrument='SBX-CALIPER-01';unit='mm';uncertainty=0.1
        out[field]={'reading_id':f'SBX-OBS-{attempt_id}-{field}',
                    'value':v,'unit':unit,'uncertainty_abs':uncertainty,
                    'instrument_id':instrument,'observed_at':at,
                    'evidence_kind':'SYNTHETIC','source_page_id':recipe['source_page_id'],
                    'lot_ids':list(lot_ids)}
    for k,update in (overrides or {}).items():
        out[k].update(copy.deepcopy(update))
    return out
