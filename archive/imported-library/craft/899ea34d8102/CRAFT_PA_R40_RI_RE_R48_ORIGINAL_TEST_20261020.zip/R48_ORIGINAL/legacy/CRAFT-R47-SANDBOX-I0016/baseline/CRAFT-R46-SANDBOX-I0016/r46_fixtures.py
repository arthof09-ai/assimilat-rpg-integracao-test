"""All outputs of this fixture factory are FABRICATED data for deterministic tests."""
from __future__ import annotations
import base64,copy,json,hashlib
from pathlib import Path
from r46_evidence import SCHEMA, bytes_hash
ROOT=Path(__file__).resolve().parent
R45=ROOT/'baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016'
TIME='2026-10-09T11:45:00+00:00'
SUBMIT='2026-10-09T11:46:00+00:00'
REVIEW='2026-10-09T11:47:00+00:00'

def recipes_and_sources():
 recipes={}
 for p in sorted((R45/'r44_legacy/recipes').glob('*.json')):
  r=json.loads(p.read_text());recipes[r['key']]=r
 sources=json.loads((R45/'fixtures/registries_synthetic.json').read_text())['sources']
 return recipes,sources

def artifact(s):
 b=s.encode('utf8')
 return {'payload_b64':base64.b64encode(b).decode('ascii'),'claimed_sha256':bytes_hash(b)}

def make_report(key='SBX-TLI-R44-v1',id='SBX-R46-LAUDO-0001',kind='SYNTHETIC'):
 r,_=recipes_and_sources();recipe=r[key]
 old=json.loads((R45/'r44_legacy/fixtures/demo.json').read_text())
 if key=='SBX-TLI-R44-v1':vals=old['tli_good_measurements'];lot_ids=['SBX-SLATE-GOOD-01']
 else:vals=old['mica_good_measurements'];lot_ids=['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B']
 sample=('SBX-SAMPLE-' if kind=='SYNTHETIC' else 'CLAIM-SAMPLE-')+id
 if kind!='SYNTHETIC':lot_ids=['CLAIM-LOT-'+str(i+1) for i in range(len(lot_ids))]
 inst='SBX-R46-BENCH-01' if kind=='SYNTHETIC' else 'CLAIM-INSTRUMENT-01'
 cert=artifact('CAL-CERT|PLACEHOLDER|'+id)
 custody=artifact('CUSTODY|PLACEHOLDER|'+id)
 operator=artifact('OPERATOR|PLACEHOLDER|'+id)
 docs={'measurement':artifact('MEASUREMENT|PLACEHOLDER|'+id),
       'calibration':cert,'custody':custody,'operator':operator}
 observations={}
 for rule in recipe['qa_rules']:
  f=rule['field'];v=vals[f]
  d='bool' if rule['kind']=='bool_eq' else 'count' if f.endswith('_count') or f=='piece_count' else 'mm'
  u=0 if d in ('bool','count') else 0.01 if f in ('groove_depth_mm','thickness_difference_mm') else 0.05
  observations[f]={'reading_id':'SBX-R46-OBS-'+id+'-'+f,'value':v,'unit':d,'uncertainty_abs':u,
                   'instrument_id':inst,'sample_id':sample,'observed_at':TIME}
 report={'schema':SCHEMA,'report_id':id,'recipe_key':key,'evidence_kind':kind,
         'source_page_id':recipe['source_page_id'],'source_crn_id':recipe['source_crn_id'],
         'sample_id':sample,'lot_ids':lot_ids,
         'operator':{'operator_id':'SBX-FIXTURE-OP-01' if kind=='SYNTHETIC' else 'CLAIM-OPERATOR-01',
                     'competency':'SYNTHETIC_FIXTURE' if kind=='SYNTHETIC' else 'ASSERTED_NOT_VERIFIED',
                     'attestation_ref':docs['operator']['claimed_sha256']},
         'instrument':{'instrument_id':inst,'serial':'SIMULATED-SERIAL-01' if kind=='SYNTHETIC' else 'CLAIMED-SERIAL-01',
                       'calibration_id':'SBX-CAL-01' if kind=='SYNTHETIC' else 'CLAIM-CAL-01',
                       'calibration_start':'2026-10-08T00:00:00+00:00',
                       'calibration_expires':'2026-10-11T00:00:00+00:00',
                       'certificate_sha256':cert['claimed_sha256'],
                       'dimensions':['length','boolean','count'],'uncertainty_floor_mm':'0.005'},
         'observed_at':TIME,'submitted_at':SUBMIT,
         'conditions':{'setup_id':'SBX-SETUP-'+id,'temperature_c':'20',
                       'humidity_pct':'45','method_id':'SBX-R42-QA-PROPOSED'},
         'custody':[{'event_id':id+'-C1','sample_id':sample,'at':'2026-10-09T11:40:00+00:00',
                     'actor_id':'SBX-FIXTURE-OP-01' if kind=='SYNTHETIC' else 'CLAIM-OPERATOR-01','action':'COLLECTED','support_sha256':custody['claimed_sha256']},
                    {'event_id':id+'-C2','sample_id':sample,'at':TIME,
                     'actor_id':'SBX-FIXTURE-OP-01' if kind=='SYNTHETIC' else 'CLAIM-OPERATOR-01','action':'MEASURED','support_sha256':custody['claimed_sha256']}],
         'artifacts':docs,'observations':observations}

 # Bind four accessible synthetic document blobs to the exact report fields.
 # This certifies local consistency of supplied bytes, never the real-world issuer.
 inst_obj=report['instrument']
 cert_payload={k:v for k,v in inst_obj.items() if k!='certificate_sha256'}
 report['artifacts']['calibration']=artifact(json.dumps(cert_payload,sort_keys=True,ensure_ascii=False))
 inst_obj['certificate_sha256']=report['artifacts']['calibration']['claimed_sha256']
 custody_payload={'sample_id':report['sample_id'],
                  'events':[{k:v for k,v in e.items() if k!='support_sha256'} for e in report['custody']]}
 report['artifacts']['custody']=artifact(json.dumps(custody_payload,sort_keys=True,ensure_ascii=False))
 for event in report['custody']:event['support_sha256']=report['artifacts']['custody']['claimed_sha256']
 operator_payload={'sample_id':report['sample_id'],
                   'operator':{k:v for k,v in report['operator'].items() if k!='attestation_ref'}}
 report['artifacts']['operator']=artifact(json.dumps(operator_payload,sort_keys=True,ensure_ascii=False))
 report['operator']['attestation_ref']=report['artifacts']['operator']['claimed_sha256']
 measurement_payload={'sample_id':report['sample_id'],'source_page_id':report['source_page_id'],
                      'instrument_id':inst,'observed_at':report['observed_at'],'observations':report['observations']}
 report['artifacts']['measurement']=artifact(json.dumps(measurement_payload,sort_keys=True,ensure_ascii=False))
 return report
