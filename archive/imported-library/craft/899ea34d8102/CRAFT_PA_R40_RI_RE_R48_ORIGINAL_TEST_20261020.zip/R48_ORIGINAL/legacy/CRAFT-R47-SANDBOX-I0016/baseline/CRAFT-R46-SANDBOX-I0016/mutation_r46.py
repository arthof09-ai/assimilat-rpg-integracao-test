"""Deterministic adversarial input mutation deck; synthetic only."""
import copy,json,random
from pathlib import Path
from r46_evidence import EvidenceVault,EvidenceError,digest
from r46_fixtures import recipes_and_sources,make_report,REVIEW
ROOT=Path(__file__).resolve().parent
R,S=recipes_and_sources()
rng=random.Random(460017)
paths=[('source_page_id',),('sample_id',),('report_id',),('lot_ids',),('operator',),('instrument',),('custody',),
       ('observations',),('conditions',),('artifacts',),('observed_at',),('submitted_at',),
       ('operator','operator_id'),('instrument','dimensions'),('instrument','uncertainty_floor_mm'),
       ('observations','length_mm','value'),('observations','length_mm','unit'),
       ('observations','length_mm','uncertainty_abs'),('observations','length_mm','observed_at'),
       ('artifacts','measurement','claimed_sha256'),('custody',0,'sample_id'),('custody',1,'at')]
mutations=[None,[],{},'',False,0,-1,'not-a-number','2037-01-01','wrong-source','PSEUDO_VERIFIED']
summary={'seed':460017,'attempts':330,'quarantined':0,'refused_cleanly':0,
         'unexpected_acceptances':0,'unhandled_exceptions':[],
         'scope':'SYNTHETIC_ADVERSARIAL_MUTATION_NOT_REAL'}
for i in range(summary['attempts']):
 report=make_report(id=f'SBX-MUT-{i:04d}')
 path=paths[i%len(paths)];mutation=copy.deepcopy(rng.choice(mutations))
 target=report
 for p in path[:-1]:target=target[p]
 target[path[-1]]=mutation
 v=EvidenceVault(R,S)
 try:
  z=v.submit(report,REVIEW)
  if z['status'].startswith('QUARANTINE'):summary['quarantined']+=1
  else:
   # A malformed mutation must not be accepted as a physical measurement;
   # benign changes to synthetic values may still yield synthetic QA FAIL.
   if z['physical_measurement_verified'] or z['execution_authorized'] or z['stock_effect']!=0:
    summary['unexpected_acceptances']+=1
 except EvidenceError:summary['refused_cleanly']+=1
 except Exception as e:summary['unhandled_exceptions'].append({'i':i,'path':path,'type':type(e).__name__,'detail':str(e)})
 if not v.audit()['ok']:
  summary['unhandled_exceptions'].append({'i':i,'path':path,'type':'INVARIANT_BREAK','detail':v.audit()['issues']})
summary['result']='PASS' if not summary['unhandled_exceptions'] and not summary['unexpected_acceptances'] else 'FAIL'
(ROOT/'results/r46_mutation_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
if summary['result']!='PASS':raise RuntimeError('MUTATION_FAIL')
