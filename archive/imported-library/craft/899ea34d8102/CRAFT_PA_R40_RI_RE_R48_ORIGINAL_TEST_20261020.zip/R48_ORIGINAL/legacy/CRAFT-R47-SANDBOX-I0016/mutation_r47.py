"""Adversarial mutation stress, deterministic synthetic input and OFFICIAL DENY."""
import copy,json,random,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from r47_fixtures import make_pair,recipes_and_sources,policy,REVIEW
from r47_authenticity import AuthenticityVault,AuthError,InjectedFailure
rng=random.Random(470047)
recipes,sources=recipes_and_sources();counts={'quarantined':0,'rejected_before_record':0,'mutations':0,'false_material_approvals':0}
N=260
for i in range(N):
    v=AuthenticityVault(recipes,sources,policy())
    report,att=make_pair(index=200000+i)
    x=i%13
    if x==0:att['report_proof']['signature_b64']='CORRUPTED'
    elif x==1:att['calibration_proof']['body']['calibration_id']='CHANGED'
    elif x==2:att['custody_events'][rng.randrange(4)]['signature_b64']='X'
    elif x==3:att['custody_events'][3]['body']['sample_id']='SUBSTITUTED'
    elif x==4:att['certificates']['operator']['body']['roles']=['CUSTODIAN']
    elif x==5:att['certificates']['operator']['body']['instrument_ids']=['FOREIGN']
    elif x==6:att['certificates']['operator']['signature_b64']='WRONG'
    elif x==7:att['custody_events'][rng.randrange(4)]['body']['previous_hash']='RANDOM'+str(i)
    elif x==8:att['schema']='V0'
    elif x==9:att.pop('report_proof')
    elif x==10:att['custody_events'].pop(2)
    elif x==11:report['artifacts']['measurement']['payload_b64']='AA=='
    else:att['custody_events'][2]['body']['at']='BAD_TIME'
    counts['mutations']+=1
    try:
        result=v.submit(report,att,REVIEW)
        assert result['status'] in ('QUARANTINE_AUTHENTICITY','QUARANTINE_R46_PRECHECK'),result['status']
        assert not result['material_promotion_allowed'] and not result['physically_verified'] and result['stock_effect']==0
        assert v.audit()['ok']
        counts['quarantined']+=1
    except (AuthError,ValueError,TypeError,KeyError,OverflowError):
        counts['rejected_before_record']+=1
        assert len(v.events)==0
assert counts['mutations']==counts['quarantined']+counts['rejected_before_record']
summary={'schema':'R47-MUTATION-SYNTHETIC-v1','seed':470047,'result':counts,
         'real_approved':0,'stock_effect':0,'status':'PASS'}
(HERE/'results/r47_mutation_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
