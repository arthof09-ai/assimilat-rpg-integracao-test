from __future__ import annotations
import copy, json,random,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from r46_evidence import EvidenceVault,EvidenceError,InjectedFailure,digest,bytes_hash,judge_reading
from r46_fixtures import recipes_and_sources,make_report,REVIEW,artifact
REC,SOURCES=recipes_and_sources()

def vault():return EvidenceVault(REC,SOURCES)
def new(id='SBX-TEST-0001',key='SBX-TLI-R44-v1',kind='SYNTHETIC'):
 return make_report(key=key,id=id,kind=kind)

def rebind_artifacts(r):
 """Regenerate self-consistent document bytes after deliberate test field changes.

 In real world this is NOT issuer-authenticity validation; adversarial cases
 must be quarantined if independent evidence of issuer/calibration is absent.
 """
 inst=r['instrument'];cal={k:v for k,v in inst.items() if k!='certificate_sha256'}
 r['artifacts']['calibration']=artifact(json.dumps(cal,sort_keys=True))
 inst['certificate_sha256']=r['artifacts']['calibration']['claimed_sha256']
 c={'sample_id':r['sample_id'],'events':[{k:v for k,v in e.items() if k!='support_sha256'} for e in r['custody']]}
 r['artifacts']['custody']=artifact(json.dumps(c,sort_keys=True))
 for e in r['custody']:e['support_sha256']=r['artifacts']['custody']['claimed_sha256']
 op={'sample_id':r['sample_id'],'operator':{k:v for k,v in r['operator'].items() if k!='attestation_ref'}}
 r['artifacts']['operator']=artifact(json.dumps(op,sort_keys=True))
 r['operator']['attestation_ref']=r['artifacts']['operator']['claimed_sha256']
 m={'sample_id':r['sample_id'],'source_page_id':r['source_page_id'],
    'instrument_id':inst['instrument_id'],'observed_at':r['observed_at'],
    'observations':r['observations']}
 r['artifacts']['measurement']=artifact(json.dumps(m,sort_keys=True))
 return r

class EvidenceContract(unittest.TestCase):
 def test_001_two_historical_recipes_only(self):
  self.assertEqual(len(REC),2)
  with self.assertRaises(EvidenceError):EvidenceVault({list(REC)[0]:list(REC.values())[0]},SOURCES)
 def test_002_valid_synthetic_tli(self):
  z=vault().submit(new(),REVIEW);self.assertEqual(z['status'],'SYNTHETIC_QA_PASS');self.assertEqual(z['readings_evaluated'],11)
 def test_003_valid_synthetic_mica(self):
  z=vault().submit(new(key='SBX-MICA-R44-v1'),REVIEW);self.assertEqual(z['status'],'SYNTHETIC_QA_PASS');self.assertEqual(z['readings_evaluated'],8)
 def test_004_complete_documentary_claim_is_never_physically_verified(self):
  z=vault().submit(new(kind='MEASURED_CLAIM_UNVERIFIED'),REVIEW)
  self.assertEqual(z['status'],'ELIGIBLE_FOR_INDEPENDENT_REVIEW')
  self.assertFalse(z['physical_measurement_verified']);self.assertFalse(z['execution_authorized']);self.assertEqual(z['stock_effect'],0)
 def test_005_forbidden_claim_of_verified_evidence(self):
  r=new();r['evidence_kind']='MEASURED_VERIFIED'
  z=vault().submit(r,REVIEW);self.assertEqual(z['status'],'QUARANTINE_SUSPECT')
 def test_006_incomplete_documentation(self):
  r=new();del r['operator'];self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INCOMPLETE')
 def test_007_source_ps_mismatch(self):
  r=new();r['source_page_id']=REC['SBX-MICA-R44-v1']['source_page_id']
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_008_mismatched_custody_sample(self):
  r=new();r['custody'][1]['sample_id']='SBX-SAMPLE-SWAPPED'
  self.assertIn('CUSTODY_SAMPLE_DIVERGENCE',vault().submit(r,REVIEW)['problems'])
 def test_009_calibration_expired(self):
  r=new();r['instrument']['calibration_expires']='2026-10-09T11:44:59+00:00';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_CALIBRATION')
 def test_010_calibration_starts_after_observed(self):
  r=new();r['instrument']['calibration_start']='2026-10-09T11:45:01+00:00';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_CALIBRATION')
 def test_011_calibration_certificate_content_binding(self):
  r=new();r['instrument']['serial']='DIFFERENT'
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_012_tampered_artifact_digest(self):
  r=new();r['artifacts']['measurement']['claimed_sha256']='0'*64
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_013_tampered_artifact_bytes_even_with_recomputed_hash(self):
  r=new();r['artifacts']['measurement']=artifact(json.dumps({'bogus':'x'}))
  self.assertIn('ARTIFACT_CONTENT_BINDING_MISMATCH_MEASUREMENT',vault().submit(r,REVIEW)['problems'])
 def test_014_tampered_reading_without_change_to_document_bytes(self):
  r=new();r['observations']['length_mm']['value']='500'
  self.assertIn('ARTIFACT_CONTENT_BINDING_MISMATCH_MEASUREMENT',vault().submit(r,REVIEW)['problems'])
 def test_015_unit_dimension_mismatch(self):
  r=new();r['observations']['length_mm']['unit']='kg';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INCOMPLETE')
 def test_016_cm_converted_to_mm_with_uncertainty(self):
  r=new();o=r['observations']['length_mm'];o.update(value='12',unit='cm',uncertainty_abs='0.01');rebind_artifacts(r)
  z=vault().submit(r,REVIEW);self.assertEqual(z['status'],'SYNTHETIC_QA_PASS');self.assertEqual(z['inspection']['length_mm']['value'],'120')
 def test_017_cm_floor_applied_in_base_units(self):
  r=new();o=r['observations']['length_mm'];o.update(value='12',unit='cm',uncertainty_abs='0.00001');rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INCOMPLETE')
 def test_018_incertitude_crosses_tolerance(self):
  r=new();o=r['observations']['length_mm'];o['value']='120.98';o['uncertainty_abs']='0.05';rebind_artifacts(r)
  z=vault().submit(r,REVIEW);self.assertEqual(z['status'],'SYNTHETIC_INDETERMINATE')
  self.assertEqual(z['inspection']['length_mm']['verdict'],'INDETERMINATE')
 def test_019_fully_outside_tolerance_fails(self):
  r=new();r['observations']['length_mm']['value']=124;rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'SYNTHETIC_QA_FAIL')
 def test_020_real_claim_guardband_uncertain_never_review_eligible(self):
  r=new(kind='MEASURED_CLAIM_UNVERIFIED');r['observations']['length_mm']['value']='120.98';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INDETERMINATE')
 def test_021_boolean_mismatch(self):
  r=new();r['observations']['cracks']['value']=True;rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'SYNTHETIC_QA_FAIL')
 def test_022_exact_count_rejects_fraction(self):
  r=new();r['observations']['markings_repeat_count']['value']='3.1';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INCOMPLETE')
 def test_023_no_duplicate_reading_id(self):
  r=new();r['observations']['width_mm']['reading_id']=r['observations']['length_mm']['reading_id'];rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_024_operator_attribution_mismatch(self):
  r=new();r['custody'][1]['actor_id']='SBX-OTHER-OP';rebind_artifacts(r)
  self.assertIn('MEASURED_CUSTODY_OPERATOR_OR_TIME_MISMATCH',vault().submit(r,REVIEW)['problems'])
 def test_025_future_observation_time(self):
  r=new();r['observed_at']='2027-01-01T00:00:00+00:00';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_026_naive_timestamp(self):
  r=new();r['observed_at']='2026-10-09T11:45:00';rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INCOMPLETE')
 def test_027_negative_uncertainty(self):
  r=new();r['observations']['length_mm']['uncertainty_abs']=-1;rebind_artifacts(r)
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_INCOMPLETE')
 def test_028_bad_artifact_b64(self):
  r=new();r['artifacts']['measurement']['payload_b64']='____-NOTBASE64'
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_029_idempotent_exact_replay_not_duplicate_debit(self):
  v=vault();r=new();a=v.submit(r,REVIEW);b=v.submit(r,REVIEW)
  self.assertFalse(a['idempotent_replay']);self.assertTrue(b['idempotent_replay']);self.assertEqual(v.audit()['events'],1)
 def test_030_same_report_id_changed_payload_denied(self):
  v=vault();v.submit(new(),REVIEW);r=new();r['sample_id']='SBX-SAMPLE-MAL'
  with self.assertRaisesRegex(EvidenceError,'REPORT_ID_REUSE'):v.submit(r,REVIEW)
 def test_031_duplicate_measurement_bytes_new_report_id_quarantined(self):
  v=vault();v.submit(new(),REVIEW)
  r=new('SBX-TEST-0002');r['artifacts']['measurement']=new()['artifacts']['measurement']
  self.assertIn('DUPLICATE_MEASUREMENT_DOCUMENT',v.submit(r,REVIEW)['problems'])
 def test_032_rollback_after_validation(self):
  v=vault();r=new();original=(v.head,digest(v.events))
  with self.assertRaises(InjectedFailure):v.submit(r,REVIEW,'AFTER_VALIDATION_BEFORE_JOURNAL')
  self.assertEqual((v.head,digest(v.events)),original)
  self.assertEqual(v.submit(r,REVIEW)['status'],'SYNTHETIC_QA_PASS')
 def test_033_rollback_after_stage(self):
  v=vault();r=new();original=(v.head,digest(v.events))
  with self.assertRaises(InjectedFailure):v.submit(r,REVIEW,'AFTER_STAGE_BEFORE_COMMIT')
  self.assertEqual((v.head,digest(v.events)),original)
 def test_034_snapshot_roundtrip_and_head(self):
  v=vault();v.submit(new(),REVIEW);h=v.head
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'vault.json';v.snapshot(p);v2=EvidenceVault.restore(p,expected_head=h)
   self.assertEqual(v2.head,h);self.assertEqual(v2.audit(),v.audit())
 def test_035_snapshot_tamper_detected(self):
  v=vault();v.submit(new(),REVIEW)
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'vault.json';v.snapshot(p)
   s=json.loads(p.read_text());s['events'][0]['payload']['decision']['status']='FAKE_PASS';p.write_text(json.dumps(s))
   with self.assertRaisesRegex(EvidenceError,'SNAPSHOT_HASH_INVALID'):EvidenceVault.restore(p)
 def test_036_rehashed_snapshot_with_false_decision_still_detected(self):
  v=vault();v.submit(new(),REVIEW)
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'vault.json';v.snapshot(p)
   s=json.loads(p.read_text());s['events'][0]['payload']['decision']['status']='FAKE_PASS';s['snapshot_sha256']=digest({k:v for k,v in s.items() if k!='snapshot_sha256'});p.write_text(json.dumps(s))
   with self.assertRaisesRegex(EvidenceError,'SNAPSHOT_REPLAY_FAILURE'):EvidenceVault.restore(p)
 def test_037_external_anchor_mismatch(self):
  v=vault();v.submit(new(),REVIEW)
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'vault.json';v.snapshot(p)
   with self.assertRaisesRegex(EvidenceError,'EXTERNAL_HEAD_ANCHOR_CONFLICT'):EvidenceVault.restore(p,expected_head='0'*64)
 def test_038_snapshot_crash_before_atomic_rename(self):
  v=vault();v.submit(new(),REVIEW)
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'vault.json';v.snapshot(p);baseline=p.read_bytes()
   with self.assertRaises(InjectedFailure):v.snapshot(p,'BEFORE_ATOMIC_RENAME')
   self.assertEqual(p.read_bytes(),baseline)
 def test_039_runtime_tamper_refused_before_new_commit(self):
  v=vault();v.submit(new(),REVIEW);v.events[0]['payload']['decision']['status']='FAKE_PASS'
  self.assertFalse(v.audit()['ok'])
  with self.assertRaisesRegex(EvidenceError,'REFUSE_MUTATED_JOURNAL'):v.submit(new('SBX-TEST-0002'),REVIEW)
 def test_040_source_registry_mutation_audited(self):
  v=vault();v.sources[list(v.sources)[0]]['inventory']='FAKE_CANONICAL_STOCK'
  self.assertFalse(v.audit()['ok'])
 def test_041_recipe_registry_mutation_audited(self):
  v=vault();v.recipes['SBX-TLI-R44-v1']['mechanical_bonus']=100
  self.assertFalse(v.audit()['ok'])
 def test_042_claimed_attestation_sha_mismatch(self):
  r=new();r['operator']['attestation_ref']='0'*64
  self.assertIn('OPERATOR_ATTESTATION_HASH_MISMATCH',vault().submit(r,REVIEW)['problems'])
 def test_043_untrusted_operator_cannot_certify_physical_success(self):
  r=new(kind='MEASURED_CLAIM_UNVERIFIED')
  r['operator']['competency']='SUPPOSED_LAB_DIRECTOR_REAL';rebind_artifacts(r)
  z=vault().submit(r,REVIEW)
  self.assertFalse(z['physical_measurement_verified']);self.assertEqual(z['status'],'ELIGIBLE_FOR_INDEPENDENT_REVIEW')
 def test_044_no_stock_or_official_id_after_any_decision(self):
  v=vault();r=new();z=v.submit(r,REVIEW)
  self.assertEqual(z['stock_effect'],0);self.assertIsNone(z['official_rec_id']);self.assertFalse(z['materialized'])
 def test_045_proposed_guards_randomized_300_points(self):
  rng=random.Random(460016)
  for i in range(300):
   lo=119;hi=121
   value=rng.uniform(117,123);uncertainty=rng.choice([0.005,0.05,0.1,0.5,1.2])
   ob={'reading_id':'SBX-QA-RND-'+str(i),'value':str(value),'unit':'mm','uncertainty_abs':str(uncertainty),
       'sample_id':'SBX-SAMPLE-X','instrument_id':'SBX-INSTR-X','observed_at':REVIEW}
   result=judge_reading(ob,{'field':'length_mm','kind':'range','min':lo,'max':hi},'SBX-SAMPLE-X','SBX-INSTR-X',
                        __import__('datetime').datetime.fromisoformat(REVIEW), '0.005')
   expected=value-uncertainty>=lo and value+uncertainty<=hi
   self.assertEqual(result['verdict']=='PASS',expected,(i,result,value,uncertainty))
 def test_046_asserted_physical_stock_forbidden_in_contract(self):
  r=new();r['canonical_stock_qty']=99
  self.assertEqual(vault().submit(r,REVIEW)['status'],'QUARANTINE_SUSPECT')
 def test_047_mica_observation_uncertainty_0_05_exceeds_limit(self):
  r=new(key='SBX-MICA-R44-v1');r['observations']['thickness_difference_mm']['uncertainty_abs']='0.07';rebind_artifacts(r)
  z=vault().submit(r,REVIEW);self.assertEqual(z['status'],'SYNTHETIC_INDETERMINATE')

if __name__=='__main__':unittest.main()

class BatchAndReapplication(unittest.TestCase):
 def test_048_two_distinct_reports_batch_atomic(self):
  v=vault();a=v.submit_batch([new('SBX-BATCH-TLI'),new('SBX-BATCH-MICA','SBX-MICA-R44-v1')],REVIEW)
  self.assertEqual(a['batch_reports'],2);self.assertEqual(v.audit()['events'],2)
  self.assertEqual(a['stock_effect'],0)
 def test_049_batch_missing_id_rolls_back_all(self):
  v=vault();a=new('SBX-BATCH-01');b=new('SBX-BATCH-02');b['report_id']=None
  with self.assertRaises(EvidenceError):v.submit_batch([a,b],REVIEW)
  self.assertEqual(v.audit()['events'],0)
 def test_050_batch_injected_fault_rolls_back_all(self):
  v=vault();old=(v.head,digest(v.events))
  with self.assertRaises(InjectedFailure):v.submit_batch([new('SBX-BATCH-01'),new('SBX-BATCH-02')],REVIEW,'AFTER_BATCH_STAGE_BEFORE_COMMIT')
  self.assertEqual((v.head,digest(v.events)),old)
 def test_051_reapplication_new_id_same_reading_id_refused(self):
  v=vault();first=new('SBX-BATCH-01');v.submit(first,REVIEW)
  second=new('SBX-BATCH-02');second['observations']['length_mm']['reading_id']=first['observations']['length_mm']['reading_id']
  rebind_artifacts(second)
  out=v.submit(second,REVIEW)
  self.assertEqual(out['status'],'QUARANTINE_SUSPECT')
  self.assertIn('READING_ID_REUSED_ACROSS_REPORTS',out['problems'])
 def test_052_exact_batch_replay_does_not_append(self):
  v=vault();row=[new('SBX-BATCH-01'),new('SBX-BATCH-02')]
  v.submit_batch(row,REVIEW);head=v.head
  out=v.submit_batch(row,REVIEW)
  self.assertEqual(v.head,head);self.assertEqual(out['journal_events'],2)
  self.assertTrue(all(x['idempotent_replay'] for x in out['receipts']))
 def test_053_duplicate_ids_within_batch_rejected(self):
  v=vault();r=new('SBX-BATCH-01')
  with self.assertRaisesRegex(EvidenceError,'BATCH_DUPLICATE_IDS'):v.submit_batch([r,copy.deepcopy(r)],REVIEW)
 def test_054_batch_snapshot_restore_invariant(self):
  v=vault();v.submit_batch([new('SBX-BATCH-01'),new('SBX-BATCH-02')],REVIEW)
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'snap.json';v.snapshot(p)
   self.assertEqual(EvidenceVault.restore(p,expected_head=v.head).audit(),v.audit())
