# CRAFT R45 — Plataforma Experimental de Medições e Comparadores

**MESTRE-SIDE**, `CM-000002-I0016`, workstream `CM-000002-WS0001` — evolução aditiva **PROPOSTA** ao sandbox R44. Somente duas receitas pré-existentes: Tábua Lamelar e Espaçador de Mica. **Nenhum REC-ID oficial, F5 RED e RC5 0/30**. O pacote não acessa Notion nem rede, não altera fichas ou estoque real.

## Arquivos

- `r44_legacy/` contém cópia **byte a byte** do motor, duas receitas, fixtures, testes e recibos R44 extraídos do ZIP histórico, sem reimplementação. `r44_legacy/__init__.py` foi acrescentado apenas como adaptador de importação, sem modificar os arquivos R44 originais.
- `r45_engine.py`: invólucro de contrato metrológico conservador, ledger duplo e importação em quarentena; `fixture_factory.py`: medições 100% sintéticas para teste.
- `run_r45_demo.py`, `stress_r45.py`, `tests/`, `fixtures/`, `results/`: execução e recibos reproduzíveis. Dados dos comparadores são **totalmente inventados para testar o algoritmo**; não há prova de vantagem física, comercial ou social de qualquer material.
- `docs/`: protocolo de medição R46 e matriz de riscos.
- `MANIFEST_SHA256.txt`: hashes SHA-256 de todos os arquivos exceto ele próprio; `verify_r45.py`: verificador CRC, manifesto e segurança básica do ZIP.

## Reprodução offline

```bash
cd CRAFT-R45-SANDBOX-I0016
python -m unittest discover -s r44_legacy/tests -q   # 52 regressões herdadas
python -m unittest discover -s tests -q              # novos testes R45
python run_r45_demo.py                                # saídas e snapshot sintéticos
python stress_r45.py                                  # seed 450016; 250 tentativas
```

Para verificar o ZIP de entrega: `python verify_r45.py ../CRAFT-R45-I0016-PLATAFORMA-EXPERIMENTAL-v01.zip`. Sempre extrair para uma pasta vazia antes de executar. Python 3.11+ sem dependências externas; execução CLI local single-process. Hashes de snapshot e recibos **não equivalem a assinatura digital, autenticação de pessoa ou NAC-PASS oficial**.

## Escopos distintos

| Classe | Situação |
| --- | --- |
| PROPOSTO | geometria, processo, tolerâncias e economia de projeto da Tábua/Mica |
| SINTÉTICO | lotes, instrumentos, leituras, comparações, consumo, refugo, tempo e custos de teste |
| MEDIDO | 0 medidas físicas legítimas coletadas nesta operação |
| VERIFICADO | hashes de arquivo, recibos, QA lógico, contrato e testes computacionais; referências Notion read-only |
| MATERIALIZADO | 0 produtos oficiais / 0 novas RC5 |

A primeira fase empírica legítima é **R46**, após fonte de amostra + autoridade + cadeia de custódia + calibração real. Até então o intake físico permanece QUARANTINE e nenhuma alteração canônica pode ocorrer.
