"""R47 independent unittest suite: all keys and readings SYNTHETIC, NEVER REAL."""
import base64,copy,json,os,sys,tempfile,unittest,concurrent.futures
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from r47_authenticity import AuthenticityVault,TrustGate,AuthError,InjectedFailure,digest
from r47_fixtures import policy,make_pair,make_attestation,recipes_and_sources,REVIEW,sign,public_b64,ROOT_ID

def fixture(index=1,kind='SYNTHETIC',key='SBX-TLI-R44-v1',pol=None):
    recipes,sources=recipes_and_sources();v=AuthenticityVault(recipes,sources,pol if pol is not None else policy())
    r,a=make_pair(key=key,index=index,kind=kind)
    return v,r,a

def status(case,expected):
    v,r,a=case
    out=v.submit(r,a,REVIEW)
    assert out['status']==expected, (out['status'],out['reasons'])
    assert not out['physically_verified'] and out['stock_effect']==0
    assert v.audit()['ok']
    return out

def resign_events(a):
    prev='R47-CUSTODY-GENESIS:'+a['custody_events'][0]['body']['sample_id']
    for idx,e in enumerate(a['custody_events']):
        b=e['body'];b['seq']=idx+1;b['previous_hash']=prev
        role='origin' if b['kind'] in ('COLLECTED','TRANSFERRED') else 'receiver'
        e['signature_b64']=sign(role,b)
        prev=digest(e)

class TestR47(unittest.TestCase):
    def test_synthetic_positive(self):
        o=status(fixture(),'SIMULATED_CRYPTO_VALID_NOT_REAL')
        self.assertEqual(o['valid_signature_count'],10)
        self.assertEqual(o['custody_event_count'],4)
    def test_mica_positive(self):
        o=status(fixture(2,key='SBX-MICA-R44-v1'),'SIMULATED_CRYPTO_VALID_NOT_REAL')
        self.assertEqual(o['r46_status'],'SYNTHETIC_QA_PASS')
    def test_measured_claim_still_not_verified(self):
        o=status(fixture(3,kind='MEASURED_CLAIM_UNVERIFIED'),'SIMULATED_CRYPTO_VALID_NOT_REAL')
        self.assertEqual(o['r46_status'],'ELIGIBLE_FOR_INDEPENDENT_REVIEW')
        self.assertEqual(o['official_rec_id'],None)
    def test_external_unvetted_policy(self):
        o=status(fixture(4,pol=policy('EXTERNAL_REVIEW_PENDING')),'QUARANTINE_UNVETTED_ANCHOR')
        self.assertIn('EXTERNAL_ANCHOR_VETTING_ABSENT',o['reasons'])
    def test_root_in_envelope_not_accepted(self):
        v,r,a=fixture(5)
        a['extra_root']=public_b64('root')
        self.assertEqual(v.submit(r,a,REVIEW)['status'],'QUARANTINE_AUTHENTICITY')
    def test_forged_document_same_digest_not_authentication(self):
        v,r,a=fixture(6)
        # Attacker controls bytes+hash in R46 but cannot forge operator signature.
        o=r['observations']['width_mm'];o['value']='123.99'
        import hashlib
        from r46_fixtures import artifact
        measurement={'sample_id':r['sample_id'],'source_page_id':r['source_page_id'],
                     'instrument_id':r['instrument']['instrument_id'],'observed_at':r['observed_at'],
                     'observations':r['observations']}
        r['artifacts']['measurement']=artifact(json.dumps(measurement,sort_keys=True,ensure_ascii=False))
        out=v.submit(r,a,REVIEW)
        self.assertEqual(out['status'],'QUARANTINE_AUTHENTICITY')
        self.assertIn('REPORT_SIGNATURE_CONTENT_BINDING',out['reasons'])
        self.assertFalse(out['physically_verified'])
    def test_file_bytes_tamper_no_digest_replacement(self):
        v,r,a=fixture(7)
        r['artifacts']['measurement']['payload_b64']=base64.b64encode(b'TAMPERED').decode()
        x=v.submit(r,a,REVIEW)
        self.assertEqual(x['status'],'QUARANTINE_AUTHENTICITY')
        self.assertTrue('MEASUREMENT_ARTIFACT_DIGEST_MISMATCH' in v.parent.events[0]['payload']['decision']['problems'])
    def test_report_signature_invalid(self):
        v,r,a=fixture(8)
        a['report_proof']['signature_b64']=sign('calibrator',a['report_proof']['body'])
        x=v.submit(r,a,REVIEW)
        self.assertIn('OPERATOR_REPORT_SIGNATURE_INVALID',x['reasons'])
    def test_calibration_signature_invalid(self):
        v,r,a=fixture(9)
        a['calibration_proof']['signature_b64']=sign('operator',a['calibration_proof']['body'])
        self.assertIn('CALIBRATION_SIGNATURE_INVALID',v.submit(r,a,REVIEW)['reasons'])
    def test_cert_signature_invalid(self):
        v,r,a=fixture(10)
        a['certificates']['operator']['signature_b64']=sign('operator',a['certificates']['operator']['body'])
        self.assertIn('CERT_SIGNATURE_INVALID',v.submit(r,a,REVIEW)['reasons'])
    def test_unknown_root(self):
        v,r,a=fixture(11)
        b=a['certificates']['operator']['body'];b['issuer_root_id']='SBX-UNPINNED-ROOT'
        a['certificates']['operator']['signature_b64']=sign('root',b)
        self.assertIn('ANCHOR_NOT_PINNED',v.submit(r,a,REVIEW)['reasons'])
    def test_wrong_role(self):
        v,r,a=fixture(12)
        b=a['certificates']['operator']['body'];b['roles']=['CUSTODIAN']
        a['certificates']['operator']['signature_b64']=sign('root',b)
        self.assertIn('ROLE_NOT_AUTHORIZED',v.submit(r,a,REVIEW)['reasons'])
    def test_unauthorized_instrument(self):
        v,r,a=fixture(13)
        b=a['certificates']['operator']['body'];b['instrument_ids']=['SBX-OTHER-INSTRUMENT']
        a['certificates']['operator']['signature_b64']=sign('root',b)
        self.assertIn('INSTRUMENT_NOT_AUTHORIZED',v.submit(r,a,REVIEW)['reasons'])
    def test_unauthorized_ps_source(self):
        v,r,a=fixture(14)
        b=a['certificates']['operator']['body'];b['source_page_ids']=['FAKE-PS-PAGE']
        a['certificates']['operator']['signature_b64']=sign('root',b)
        self.assertIn('SOURCE_NOT_AUTHORIZED',v.submit(r,a,REVIEW)['reasons'])
    def test_cert_expired_at_review(self):
        v,r,a=fixture(15)
        b=a['certificates']['operator']['body'];b['not_after']='2026-10-09T11:46:00+00:00'
        a['certificates']['operator']['signature_b64']=sign('root',b)
        self.assertIn('CERT_OR_ROOT_EXPIRED_OR_NOT_YET_VALID',v.submit(r,a,REVIEW)['reasons'])
    def test_revocation(self):
        p=policy();p['revocations']['SBX-R47-CERT-OPERATOR']='2026-10-09T11:46:30+00:00'
        v,r,a=fixture(16,pol=p)
        self.assertIn('CERT_REVOKED',v.submit(r,a,REVIEW)['reasons'])
    def test_calibration_proof_instrument_divergence(self):
        v,r,a=fixture(17)
        b=a['calibration_proof']['body'];b['instrument_id']='SBX-WRONG'
        a['calibration_proof']['signature_b64']=sign('calibrator',b)
        self.assertIn('CALIBRATION_CONTENT_OR_INSTRUMENT_MISMATCH',v.submit(r,a,REVIEW)['reasons'])
    def test_calibration_expired_in_claim(self):
        v,r,a=fixture(18)
        b=a['calibration_proof']['body'];b['calibration_expires']='2026-10-08T12:00:00+00:00'
        a['calibration_proof']['signature_b64']=sign('calibrator',b)
        self.assertIn('CALIBRATION_CONTENT_OR_INSTRUMENT_MISMATCH',v.submit(r,a,REVIEW)['reasons'])
    def test_calibration_attested_future(self):
        v,r,a=fixture(19)
        b=a['calibration_proof']['body'];b['signed_at']='2026-10-09T13:00:00+00:00'
        a['calibration_proof']['signature_b64']=sign('calibrator',b)
        self.assertIn('CALIBRATION_ATTESTED_AFTER_READING',v.submit(r,a,REVIEW)['reasons'])
    def test_operator_mismatch(self):
        v,r,a=fixture(20)
        b=a['certificates']['operator']['body'];b['subject_id']='SBX-IMP0STOR'
        a['certificates']['operator']['signature_b64']=sign('root',b)
        self.assertIn('OPERATOR_SUBJECT_MISMATCH',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_missing_event(self):
        v,r,a=fixture(21)
        a['custody_events'].pop(2)
        self.assertIn('CUSTODY_LENGTH',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_handoff_no_receive(self):
        v,r,a=fixture(22)
        a['custody_events'][2]['body']['kind']='MEASURED'
        resign_events(a)
        self.assertIn('CUSTODY_HANDOFF_NOT_ACKNOWLEDGED',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_broken_hash(self):
        v,r,a=fixture(23)
        b=a['custody_events'][2]['body'];b['previous_hash']='BAD';a['custody_events'][2]['signature_b64']=sign('receiver',b)
        self.assertIn('CUSTODY_SAMPLE_OR_PREVIOUS_HASH',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_signature_invalid(self):
        v,r,a=fixture(24)
        b=a['custody_events'][1]['body'];a['custody_events'][1]['signature_b64']=sign('operator',b)
        self.assertIn('CUSTODY_SIGNATURE_INVALID',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_wrong_instrument(self):
        v,r,a=fixture(25)
        b=a['custody_events'][3]['body'];b['instrument_id']='SBX-WRONG'
        a['custody_events'][3]['signature_b64']=sign('receiver',b)
        self.assertIn('CUSTODY_MEASUREMENT_INSTRUMENT_OR_DOC',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_wrong_sample(self):
        v,r,a=fixture(26)
        b=a['custody_events'][2]['body'];b['sample_id']='SBX-OTHER-SAMPLE'
        a['custody_events'][2]['signature_b64']=sign('receiver',b)
        self.assertIn('CUSTODY_SAMPLE_OR_PREVIOUS_HASH',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_time_reverse(self):
        v,r,a=fixture(27)
        b=a['custody_events'][2]['body'];b['at']='2026-10-09T11:39:00+00:00'
        a['custody_events'][2]['signature_b64']=sign('receiver',b)
        self.assertIn('CUSTODY_NONMONOTONIC',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_duplicate_id(self):
        v,r,a=fixture(28)
        b=a['custody_events'][2]['body'];b['event_id']=a['custody_events'][0]['body']['event_id']
        a['custody_events'][2]['signature_b64']=sign('receiver',b)
        self.assertIn('CUSTODY_EVENT_DUPLICATE',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_signature_substitution(self):
        v,r,a=fixture(29)
        a['custody_events'][3]['signature_b64']=a['custody_events'][0]['signature_b64']
        self.assertIn('CUSTODY_SIGNATURE_INVALID',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_handoff_receiver_divergence(self):
        v,r,a=fixture(30)
        b=a['custody_events'][1]['body'];b['to_actor']='SBX-UNAUTHORIZED-CUSTODIAN';a['custody_events'][1]['signature_b64']=sign('origin',b)
        self.assertIn('CUSTODY_TRANSFER_SENDER_OR_RECEIVER',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_duplicate_between_reports(self):
        v,r,a=fixture(31);r2,a2=make_pair(index=32)
        v.submit(r,a,REVIEW)
        b=a2['custody_events'][0]['body'];b['event_id']=a['custody_events'][0]['body']['event_id']
        a2['custody_events'][0]['signature_b64']=sign('origin',b)
        self.assertIn('CUSTODY_EVENT_DUPLICATE',v.submit(r2,a2,REVIEW)['reasons'])
    def test_duplicate_report_replay(self):
        v,r,a=fixture(33);x=v.submit(r,a,REVIEW);y=v.submit(r,a,REVIEW)
        self.assertTrue(y['idempotent_replay']);self.assertEqual(y['receipt_hash'],x['receipt_hash']);self.assertEqual(len(v.events),1)
    def test_idempotency_change_attestation(self):
        v,r,a=fixture(34);v.submit(r,a,REVIEW);b=copy.deepcopy(a);b['report_proof']['signature_b64']='BAD'
        with self.assertRaisesRegex(AuthError,'IDEMPOTENCY_CONFLICT'):v.submit(r,b,REVIEW)
        self.assertEqual(len(v.events),1)
    def test_idempotency_change_review_time(self):
        v,r,a=fixture(35);v.submit(r,a,REVIEW)
        with self.assertRaisesRegex(AuthError,'IDEMPOTENCY_CONFLICT'):v.submit(r,a,'2026-10-09T11:48:00+00:00')
    def test_batch_atomic_commit(self):
        v,r,a=fixture(36);r2,a2=make_pair(index=37,key='SBX-MICA-R44-v1')
        x=v.submit_batch([{'report':r,'attestation':a},{'report':r2,'attestation':a2}],REVIEW)
        self.assertEqual(x['events'],2);self.assertEqual(len(v.parent.events),2)
        self.assertTrue(v.audit()['ok'])
    def test_batch_rollback(self):
        v,r,a=fixture(38);r2,a2=make_pair(index=39)
        old=(v.head,v.parent.head)
        with self.assertRaises(InjectedFailure):v.submit_batch([{'report':r,'attestation':a},{'report':r2,'attestation':a2}],REVIEW,inject='MID_BATCH_ABORT')
        self.assertEqual((v.head,v.parent.head),old);self.assertEqual(len(v.events),0)
        self.assertTrue(v.audit()['ok'])
    def test_batch_conflict_atomic(self):
        v,r,a=fixture(40);b=copy.deepcopy(a);b['report_proof']['signature_b64']='bad'
        with self.assertRaisesRegex(AuthError,'BATCH_DUPLICATE_REPORT_IDS'):
            v.submit_batch([{'report':r,'attestation':a},{'report':r,'attestation':b}],REVIEW)
        self.assertEqual(len(v.events),0)
    def test_parent_journal_tampered(self):
        v,r,a=fixture(41);v.submit(r,a,REVIEW)
        v.parent.events[0]['payload']['decision']['physical_measurement_verified']=True
        self.assertFalse(v.audit()['ok'])
        with self.assertRaises(AuthError):v.submit(*make_pair(index=42),REVIEW)
    def test_r47_journal_tampered(self):
        v,r,a=fixture(43);v.submit(r,a,REVIEW);v.events[0]['payload']['decision']['physically_verified']=True
        self.assertFalse(v.audit()['ok'])
        with self.assertRaises(AuthError):v.submit(*make_pair(index=44),REVIEW)
    def test_root_registry_mutated(self):
        v,r,a=fixture(45);v.submit(r,a,REVIEW);v.trust.policy['roots'][ROOT_ID]['public_key_b64']=public_b64('operator')
        self.assertFalse(v.audit()['ok'])
        with self.assertRaises(AuthError):v.submit(*make_pair(index=46),REVIEW)
    def test_snapshot_restore(self):
        v,r,a=fixture(47);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'state.json';h=v.snapshot(p)
            obj=AuthenticityVault.restore(p,v.trust.policy_sha256,v.head)
            self.assertEqual(obj.head,v.head);self.assertTrue(obj.audit()['ok']);self.assertEqual(len(obj.events),1)
    def test_snapshot_atomic_abort(self):
        v,r,a=fixture(48);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json'
            with self.assertRaises(InjectedFailure):v.snapshot(p,inject='BEFORE_RENAME')
            self.assertFalse(p.exists());self.assertTrue(v.audit()['ok'])
    def test_snapshot_corrupt(self):
        v,r,a=fixture(49);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';v.snapshot(p)
            x=json.loads(p.read_text());x['events'][0]['payload']['decision']['physically_verified']=True
            p.write_text(json.dumps(x))
            with self.assertRaisesRegex(AuthError,'SNAPSHOT_SHA256_INVALID'):AuthenticityVault.restore(p,v.trust.policy_sha256)
    def test_restore_wrong_policy(self):
        v,r,a=fixture(50);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';v.snapshot(p)
            with self.assertRaisesRegex(AuthError,'EXTERNAL_TRUST_POLICY_MISMATCH'):AuthenticityVault.restore(p,'bad-policy-hash')
    def test_restore_requires_external_policy(self):
        v,r,a=fixture(51);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';v.snapshot(p)
            with self.assertRaisesRegex(AuthError,'EXTERNAL_TRUST_POLICY_ANCHOR_REQUIRED'):AuthenticityVault.restore(p,None)
    def test_restore_wrong_expected_head(self):
        v,r,a=fixture(52);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'snap.json';v.snapshot(p)
            with self.assertRaisesRegex(AuthError,'EXTERNAL_JOURNAL_HEAD_MISMATCH'):AuthenticityVault.restore(p,v.trust.policy_sha256,'WRONG-HEAD')
    def test_claim_measurement_uncertain(self):
        v,r,a=fixture(53,kind='MEASURED_CLAIM_UNVERIFIED')
        r['observations']['width_mm']['value']='121.0';r['observations']['width_mm']['uncertainty_abs']='1.0'
        # Resigning R47 still cannot change the R46 content-bound measurement document.
        o=v.submit(r,a,REVIEW)
        self.assertFalse(o['physically_verified']);self.assertIn(o['status'],['QUARANTINE_AUTHENTICITY','QUARANTINE_R46_PRECHECK'])
    def test_policy_simulated_vetting_forgery(self):
        p=policy();p['externally_vetted']=True
        r,s=recipes_and_sources()
        with self.assertRaisesRegex(AuthError,'SIMULATED_ROOT_CANNOT_BE_VETTED'):AuthenticityVault(r,s,p)
    def test_multi_thread_exactly_once(self):
        v,r,a=fixture(54)
        def task(_):return v.submit(copy.deepcopy(r),copy.deepcopy(a),REVIEW)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
            rows=list(ex.map(task,range(12)))
        self.assertEqual(len(v.events),1);self.assertEqual(sum(not x['idempotent_replay'] for x in rows),1)
        self.assertTrue(v.audit()['ok'])
    def test_multi_thread_unique_reports(self):
        v,r,a=fixture(55)
        jobs=[make_pair(index=i+55) for i in range(8)]
        def task(pair):return v.submit(pair[0],pair[1],REVIEW)
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
            rows=list(ex.map(task,jobs))
        self.assertEqual(len(v.events),8);self.assertEqual(len(v.parent.events),8)
        self.assertTrue(v.audit()['ok'])
    def test_no_production_interface(self):
        v,r,a=fixture(65);x=v.submit(r,a,REVIEW)
        self.assertFalse(hasattr(v,'production_client'))
        self.assertIsNone(x['official_rec_id']);self.assertFalse(x['material_promotion_allowed'])
        self.assertEqual(x['stock_effect'],0)
    def test_all_fields_answer_missing_evidence(self):
        v,r,a=fixture(66);x=v.submit(r,a,REVIEW)
        self.assertEqual(len(x['missing_to_accept_physical_measurement']),6)
        self.assertTrue(all(isinstance(y,str) for y in x['missing_to_accept_physical_measurement']))
    def test_external_review_pending_still_not_physical(self):
        v,r,a=fixture(67,kind='MEASURED_CLAIM_UNVERIFIED',pol=policy('EXTERNAL_REVIEW_PENDING'))
        x=v.submit(r,a,REVIEW)
        self.assertEqual(x['status'],'QUARANTINE_UNVETTED_ANCHOR')
        self.assertFalse(x['physically_verified'])

    def test_external_vetting_flag_cannot_be_user_asserted(self):
        p=policy('EXTERNAL_REVIEW_PENDING');p['roots'][ROOT_ID]['fixture_only']=False;p['externally_vetted']=True
        r,s=recipes_and_sources()
        with self.assertRaisesRegex(AuthError,'R47_NO_EXTERNAL_ATTESTATION_CHANNEL'):AuthenticityVault(r,s,p)
    def test_restore_requires_external_head_for_nonempty_snapshot(self):
        v,r,a=fixture(71);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'state.json';v.snapshot(p)
            with self.assertRaisesRegex(AuthError,'EXTERNAL_JOURNAL_HEAD_ANCHOR_REQUIRED'):
                AuthenticityVault.restore(p,v.trust.policy_sha256)
    def test_restore_attacker_rewrites_hash_but_expected_head_blocks(self):
        v,r,a=fixture(72);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'state.json';v.snapshot(p)
            j=json.loads(p.read_text());j['r47_head']='BOGUS';j['snapshot_sha256']=digest({k:v for k,v in j.items() if k!='snapshot_sha256'})
            p.write_text(json.dumps(j))
            with self.assertRaises(AuthError):AuthenticityVault.restore(p,v.trust.policy_sha256,v.head)
    def test_forbidden_evidence_label_quarantined_by_parent(self):
        v,r,a=fixture(73);r['evidence_kind']='VERIFIED_REAL_WORLD'
        a=make_attestation(r)
        x=v.submit(r,a,REVIEW)
        self.assertEqual(x['status'],'QUARANTINE_R46_PRECHECK')
        self.assertFalse(x['physically_verified'])
    def test_cert_signed_with_valid_key_but_wrong_subject(self):
        v,r,a=fixture(74)
        b=a['certificates']['calibrator']['body'];b['subject_id']='FAKE-LAB-WRONG-ID'
        a['certificates']['calibrator']['signature_b64']=sign('root',b)
        self.assertIn('CALIBRATION_CONTENT_OR_INSTRUMENT_MISMATCH',v.submit(r,a,REVIEW)['reasons'])
    def test_invalid_report_time_timezone(self):
        v,r,a=fixture(75);r['observed_at']='2026-10-09T11:45:00'
        a=make_attestation(r)
        x=v.submit(r,a,REVIEW)
        self.assertEqual(x['status'],'QUARANTINE_AUTHENTICITY')
        self.assertIn('TIME_OR_TIMEZONE_INVALID',x['reasons'])
    def test_uncertainty_crossing_limit_is_not_pass_even_signed(self):
        v,r,a=fixture(76)
        r['observations']['length_mm']['value']='120.99'
        from r46_fixtures import artifact
        sample=r['artifacts']['measurement']
        row={'sample_id':r['sample_id'],'source_page_id':r['source_page_id'],
             'instrument_id':r['instrument']['instrument_id'],'observed_at':r['observed_at'],
             'observations':r['observations']}
        r['artifacts']['measurement']=artifact(json.dumps(row,sort_keys=True,ensure_ascii=False))
        a=make_attestation(r)
        x=v.submit(r,a,REVIEW)
        self.assertNotEqual(x['status'],'SIMULATED_CRYPTO_VALID_NOT_REAL')
        self.assertEqual(x['status'],'QUARANTINE_R46_PRECHECK')
    def test_measurement_unit_mismatch_blocked_even_with_signatures(self):
        v,r,a=fixture(77)
        r['observations']['length_mm']['unit']='UCS_SIM'
        from r46_fixtures import artifact
        row={'sample_id':r['sample_id'],'source_page_id':r['source_page_id'],
             'instrument_id':r['instrument']['instrument_id'],'observed_at':r['observed_at'],
             'observations':r['observations']}
        r['artifacts']['measurement']=artifact(json.dumps(row,sort_keys=True,ensure_ascii=False))
        a=make_attestation(r)
        x=v.submit(r,a,REVIEW)
        self.assertEqual(x['status'],'QUARANTINE_R46_PRECHECK')
    def test_custody_signer_id_mismatch(self):
        v,r,a=fixture(78);b=a['custody_events'][0]['body']
        b['signer_id']='ANOTHER-HOLDER';a['custody_events'][0]['signature_b64']=sign('origin',b)
        self.assertIn('CUSTODY_SIGNER_ID',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_event_in_unauthorized_cert_time(self):
        v,r,a=fixture(79);b=a['custody_events'][0]['body']
        b['at']='2026-10-07T11:40:00+00:00';a['custody_events'][0]['signature_b64']=sign('origin',b)
        self.assertIn('CUSTODY_EVENT_OUTSIDE_SIGNER_CERTIFICATE',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_event_unauthorized_early_doc(self):
        v,r,a=fixture(80);b=a['custody_events'][0]['body']
        b['measurement_sha256']=r['artifacts']['measurement']['claimed_sha256']
        a['custody_events'][0]['signature_b64']=sign('origin',b)
        self.assertIn('CUSTODY_EARLY_MEASUREMENT_ASSERTION',v.submit(r,a,REVIEW)['reasons'])
    def test_custody_missing_previous_hash(self):
        v,r,a=fixture(81);del a['custody_events'][3]['body']['previous_hash']
        self.assertIn('CUSTODY_BODY_FIELDS',v.submit(r,a,REVIEW)['reasons'])
    def test_calibrator_untrusted_role_certificate(self):
        v,r,a=fixture(82);b=a['certificates']['calibrator']['body'];b['roles']=['OPERATOR']
        a['certificates']['calibrator']['signature_b64']=sign('root',b)
        self.assertIn('ROLE_NOT_AUTHORIZED',v.submit(r,a,REVIEW)['reasons'])
    def test_root_removed_from_policy_invalidates_issuer(self):
        v,r,a=fixture(83);a['certificates']['operator']['body']['issuer_root_id']='FOREIGN'
        a['certificates']['operator']['signature_b64']=sign('root',a['certificates']['operator']['body'])
        self.assertIn('ANCHOR_NOT_PINNED',v.submit(r,a,REVIEW)['reasons'])
    def test_stale_replay_head_cannot_replace_newer(self):
        v,r,a=fixture(84);v.submit(r,a,REVIEW)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'old.json';v.snapshot(p);old_head=v.head
            r2,a2=make_pair(index=85);v.submit(r2,a2,REVIEW)
            with self.assertRaisesRegex(AuthError,'EXTERNAL_JOURNAL_HEAD_MISMATCH'):
                AuthenticityVault.restore(p,v.trust.policy_sha256,v.head)
            self.assertNotEqual(old_head,v.head)
    def test_empty_snapshot_restores_with_policy_only(self):
        v,r,a=fixture(86)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'empty.json';v.snapshot(p)
            obj=AuthenticityVault.restore(p,v.trust.policy_sha256)
            self.assertTrue(obj.audit()['ok'])
            self.assertEqual(obj.events,[])
    def test_batch_failure_if_second_report_invalid_id(self):
        v,r,a=fixture(87);r2,a2=make_pair(index=88);r2['report_id']='BAD'
        with self.assertRaises(ValueError):
            v.submit_batch([{'report':r,'attestation':a},{'report':r2,'attestation':a2}],REVIEW)
        self.assertEqual(len(v.events),0);self.assertTrue(v.audit()['ok'])
    def test_batch_injected_precommit_keeps_previous_history(self):
        v,r,a=fixture(89);v.submit(r,a,REVIEW);old=(v.head,v.parent.head,len(v.events))
        q,b=make_pair(index=90)
        with self.assertRaises(InjectedFailure):v.submit(q,b,REVIEW,inject='AFTER_STAGE_BEFORE_COMMIT')
        self.assertEqual((v.head,v.parent.head,len(v.events)),old)
        self.assertTrue(v.audit()['ok'])
    def test_unsigned_report_credential_not_enough(self):
        v,r,a=fixture(91);a['report_proof'].pop('signature_b64')
        self.assertIn('REPORT_PROOF_FIELDS',v.submit(r,a,REVIEW)['reasons'])
    def test_public_test_seed_does_not_certify_real_laboratory(self):
        v,r,a=fixture(92,kind='MEASURED_CLAIM_UNVERIFIED')
        x=v.submit(r,a,REVIEW)
        self.assertEqual(x['status'],'SIMULATED_CRYPTO_VALID_NOT_REAL')
        self.assertFalse(x['physically_verified']);self.assertIn('ONLY_SIMULATED_TRUST_ANCHORS',x['reasons'])

if __name__=='__main__':unittest.main()
