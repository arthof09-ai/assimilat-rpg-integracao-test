"""Seeded fault deck: every stress case is SYNTHETIC or an unverified claim."""
from __future__ import annotations
import copy,json,random
from pathlib import Path
from r46_evidence import EvidenceVault,EvidenceError,InjectedFailure,digest
from r46_fixtures import recipes_and_sources,make_report,artifact,REVIEW
ROOT=Path(__file__).resolve().parent
r,s=recipes_and_sources();vault=EvidenceVault(r,s)
rng=random.Random(460016)
counts={'seed':460016,'attempts':300,'synthetic':0,'claimed_documentary':0,
        'quarantined':0,'eligible_for_independent_review':0,'synthetic_pass':0,
        'uncertain':0,'fault_rollbacks':0,'idempotent_replay_checks':0,
        'content_tamper_rejections':0,'invariant_failures':0,
        'physical_verified':0,'stock_effect':0,'official_rc5':0}

def rebind_measurement(row):
 inst=row['instrument']
 reading={'sample_id':row['sample_id'],'source_page_id':row['source_page_id'],
          'instrument_id':inst['instrument_id'],'observed_at':row['observed_at'],
          'observations':row['observations']}
 row['artifacts']['measurement']=artifact(json.dumps(reading,sort_keys=True,ensure_ascii=False))

for i in range(300):
 key='SBX-TLI-R44-v1' if rng.random()<0.5 else 'SBX-MICA-R44-v1'
 kind='SYNTHETIC' if rng.random()<0.8 else 'MEASURED_CLAIM_UNVERIFIED'
 row=make_report(key,id='SBX-R46-STRESS-'+f'{i:04d}',kind=kind)
 mode=rng.choice(['ok','ok','ok','expired','mutated_doc','uncertain','missing','wrong_unit','fault1','fault2'])
 if kind=='SYNTHETIC':counts['synthetic']+=1
 else:counts['claimed_documentary']+=1
 if mode=='expired':
  row['instrument']['calibration_expires']='2026-10-09T11:44:59+00:00'
 elif mode=='mutated_doc':
  row['observations']['length_mm']['value']=int(row['observations']['length_mm']['value'])+5
 elif mode=='uncertain':
  if key=='SBX-TLI-R44-v1':row['observations']['length_mm']['value']='120.99'
  else:row['observations']['thickness_difference_mm']['value']='0.099'
  rebind_measurement(row)
 elif mode=='missing':row.pop('custody')
 elif mode=='wrong_unit':
  row['observations']['length_mm']['unit']='kg';rebind_measurement(row)
 prev=(vault.head,digest(vault.events))
 try:
  fault='AFTER_VALIDATION_BEFORE_JOURNAL' if mode=='fault1' else 'AFTER_STAGE_BEFORE_COMMIT' if mode=='fault2' else None
  out=vault.submit(row,REVIEW,inject=fault)
  assert not out['physical_measurement_verified'] and out['stock_effect']==0 and out['official_rec_id'] is None
  if out['status']=='ELIGIBLE_FOR_INDEPENDENT_REVIEW':counts['eligible_for_independent_review']+=1
  if out['status']=='SYNTHETIC_QA_PASS':counts['synthetic_pass']+=1
  if 'INDETERMINATE' in out['status']:counts['uncertain']+=1
  if out['status'].startswith('QUARANTINE'):counts['quarantined']+=1
  if mode=='mutated_doc':
   assert out['status']=='QUARANTINE_SUSPECT';counts['content_tamper_rejections']+=1
  if i%13==0:
   a=vault.submit(row,REVIEW)
   assert a['idempotent_replay']
   counts['idempotent_replay_checks']+=1
 except InjectedFailure:
  counts['fault_rollbacks']+=1
  assert prev==(vault.head,digest(vault.events))
 else:
  assert out['journal_events']==len(vault.events)
 # Full semantic replay every 25 rounds and at the terminal snapshot gate.
 if i%25==0 and not vault.audit()['ok']:
  counts['invariant_failures']+=1;raise RuntimeError('VAULT_INVARIANT_FAILURE')

snap=ROOT/'results/r46_stress_snapshot.json'
sh=vault.snapshot(snap)
restored=EvidenceVault.restore(snap,expected_head=vault.head)
assert restored.audit()==vault.audit()
counts.update({'events':vault.audit()['events'],'journal_head':vault.head,
               'snapshot_sha256':sh,'restored':True,'result':'PASS',
               'scope':'SYNTHETIC_AND_UNVERIFIED_CLAIMS_ONLY_NO_REAL_STOCK'})
(ROOT/'results/r46_stress_summary.json').write_text(json.dumps(counts,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(counts,sort_keys=True,indent=2))
