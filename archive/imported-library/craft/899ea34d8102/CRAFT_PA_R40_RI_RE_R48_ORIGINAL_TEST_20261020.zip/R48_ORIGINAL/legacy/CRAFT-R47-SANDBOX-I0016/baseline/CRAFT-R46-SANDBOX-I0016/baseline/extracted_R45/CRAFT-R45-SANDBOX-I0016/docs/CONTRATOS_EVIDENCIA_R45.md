# CRAFT R45 — contratos do motor, versão 1

**Autor operacional:** CM-000002-I0016 / CM-000002-WS0001. **Ambiente:** `SBX-CRAFT-R45-I0016`, separado do domínio oficial `CRAFT/F5`. **Baseline:** R44 ZIP SHA-256 `900452bb24f398d1968e57ddbfabc0359fb93502cfd21eaf48e44ecfffd6aff3`. **Status:** contrato PROPOSTO implementado e VERIFICADO exclusivamente como software, nunca como medição física, recurso canônico ou RECEITA RC5.

## Entrada / lote / fontes

* Um lote `SBX-*` deve existir em estoque local `fixture_kind=SYNTHETIC`, com quantidade inteira não negativa, `unit`, `source_page_id`, dimensões e flags de integridade explícitas. O `source_page_id` precisa corresponder ao ingrediente da receita imutável de R44; referências a Ardósia PS e Mica PS são apenas links, **não** disponibilidade nem título de propriedade in-game.
* Uma invocação exige: chave da receita, `attempt_id` `SBX-*` único, IDs distintos de lotes, observações QA completas, ferramentas declaradas, competências declaradas e instante com fuso. Campos extras ou ausentes nas observações são recusados. Não aceita receitas adicionais: dois modelos R44, nem mais nem menos.
* Dois consumos da mesma folha em posições distintas são válidos apenas quando os lotes são distintos. Repetir lote na mesma invocação é proibido. Se o estoque for insuficiente ou o ingrediente incorreto, o contrato responde `REJECTED_PRECHECK` sem debitá-lo.

## Leitura metrológica

Uma observação por campo QA, com campos **exatos**:
`reading_id`, `value`, `unit`, `uncertainty_abs`, `instrument_id`, `observed_at`, `evidence_kind`, `source_page_id`, `lot_ids`.

* `evidence_kind=SYNTHETIC` é obrigatório no executor demonstrativo. `MEASURED` em fixture sintética é rejeitado, sem alegar que um valor foi observado realmente. Para documentação humana, o canal independente `quarantine_claimed_measurements()` aceita somente **alegação não verificada**, sem debitar estoque, calcular PASS ou registrar item oficial.
* Unidades dimensionais aceitas: `mm`, `cm`, `m` convertidas a milímetros antes de avaliar tolerância e piso de incerteza do instrumento. Contagens usam `count` inteiro com incerteza zero; flags visuais booleanas usam `bool`. Unidade incompatível com campo ou instrumento é rejeitada.
* Registros sintéticos de instrumentos têm escopo `SYNTHETIC_FIXTURE_NOT_REAL_CALIBRATION`, janela fictícia, dimensão compatível e incerteza mínima em unidade base. A validade é verificada pela hora da leitura, não pela data do arquivo. Certificado real externo não é substituído por essa fixture.
* O intervalo `valor ± incerteza absoluta` deve estar inteiramente dentro de todos os limites QA para `PASS`. Inteiramente fora → `FAIL`; interceptando a fronteira → `INDETERMINATE`; ambos últimos entram em `REJECTED_QUALITY` se houve transformação simulada. **Não se arredonda valor borderline para PASS**. Nenhum bônus mágico é inferido.

## Saídas, resíduos e recibos

* Saída aprovada: produto apenas `SBX-*`, `status=SYNTHETIC_OUTPUT_ONLY`, `official_product_id=null`, `mechanical_bonus=0` e unidade específica. O recibo contém `request_hash`, `recipe_hash`, lotes consumidos, etapa por etapa PROPOSTA, QA, quantidades antes/depois e estado da tentativa.
* Refugo significa descarte **no modelo sintético**, sem inventar recurso secundário. Uma rejeição de pré-condição preserva estoque e não cria estágio; rejeição QA consome os insumos de fixture e cria refugo, não produto. Nenhum número de massa é inferido do cálculo volumétrico sem densidade real.
* Chave idempotente idêntica retorna o mesmo recibo sem novo evento. Repetir chave com qualquer divergência nos campos de input é erro. IDs de leitura não podem reaparecer em tentativas diferentes.
* O recibo R44 e a evidência R45 são vinculados por hash do evento, digest da observação, hash da receita, cadeia SHA-256 e posição de evento. Hash sozinho identifica alterações observáveis relativas ao anchor externo, **não autentica por si um operador ou laboratório**.

## Recuperação transacional

* O R44 legado permanece intocado no diretório `r44_legacy/`. O R45 monta um estado encenado, executa o R44 nele e só comita core + evidência juntos após sucesso; falhas injetadas antes do commit deixam ambos inalterados. Falha na verificação pós-commit aciona restauração do estado e retirada da evidência.
* Snapshot R45 possui conteúdo e hash de integridade de `recipes`, fontes, instrumentos, estoques de gênese, core R44 e recibos R45. `LabBench.restore` compara receita e fonte, reexecuta auditoria determinística sem executar produção e bloqueia alteração ou drift. Snapshot + `sha256` exige anchor em manifesto externo para detectar falsificação conjunta, não é assinatura digital.

## Contrato de comparação

* Pareamento por `trial_id` único e `matched_setup_id`, com cinco pares **SINTÉTICOS** por proposta e alternativa comum. Cada métrica exige número finito não negativo, unidade igual entre braços e entre pares e intervalo de incerteza explícito.
* Melhor apenas quando o **intervalo conservador inteiro** da diferença pareada favorece um braço; sobreposição = `INCONCLUSIVE`. Contagens são descritivas da fixture inventada, **não estimativa estatística do mundo do RPG**. Não há seleção automática de materiais ou RC5.
