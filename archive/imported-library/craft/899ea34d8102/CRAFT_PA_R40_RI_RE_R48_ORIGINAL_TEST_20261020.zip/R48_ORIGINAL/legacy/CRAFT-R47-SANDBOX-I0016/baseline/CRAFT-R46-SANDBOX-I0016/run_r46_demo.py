"""R46 deterministic demonstration. All records entirely fabricated test fixtures."""
from __future__ import annotations
import copy,json
from pathlib import Path
from r46_evidence import EvidenceVault,digest
from r46_fixtures import recipes_and_sources,make_report,REVIEW,R45
from r46_comparison import guarded_compare,add_condition_fixture
ROOT=Path(__file__).resolve().parent
recipes,sources=recipes_and_sources();v=EvidenceVault(recipes,sources)
cases=[]
def submit(name,report):
 row=v.submit(report,REVIEW)
 cases.append({'case':name,'report_id':report['report_id'],'status':row['status'],
               'problems':row['problems'],'receipt_hash':row['receipt_hash'],
               'readings_evaluated':row['readings_evaluated'],
               'physical_measurement_verified':row['physical_measurement_verified'],
               'stock_effect':row['stock_effect']})

def docfix(row):
 import json
 from r46_fixtures import artifact
 instr=row['instrument'];instr_payload={k:v for k,v in instr.items() if k!='certificate_sha256'}
 row['artifacts']['calibration']=artifact(json.dumps(instr_payload,sort_keys=True,ensure_ascii=False))
 instr['certificate_sha256']=row['artifacts']['calibration']['claimed_sha256']
 chain={'sample_id':row['sample_id'],'events':[{k:v for k,v in e.items() if k!='support_sha256'} for e in row['custody']]}
 row['artifacts']['custody']=artifact(json.dumps(chain,sort_keys=True,ensure_ascii=False))
 for e in row['custody']:e['support_sha256']=row['artifacts']['custody']['claimed_sha256']
 op={'sample_id':row['sample_id'],'operator':{k:v for k,v in row['operator'].items() if k!='attestation_ref'}}
 row['artifacts']['operator']=artifact(json.dumps(op,sort_keys=True,ensure_ascii=False))
 row['operator']['attestation_ref']=row['artifacts']['operator']['claimed_sha256']
 reading={'sample_id':row['sample_id'],'source_page_id':row['source_page_id'],
          'instrument_id':instr['instrument_id'],'observed_at':row['observed_at'],
          'observations':row['observations']}
 row['artifacts']['measurement']=artifact(json.dumps(reading,sort_keys=True,ensure_ascii=False))

submit('synthetic_tli_pass',make_report(id='SBX-DEMO-TLI-PASS'))
submit('synthetic_mica_pass',make_report('SBX-MICA-R44-v1',id='SBX-DEMO-MICA-PASS'))
claim=make_report(id='SBX-DEMO-CLAIM-001',kind='MEASURED_CLAIM_UNVERIFIED')
submit('claimed_measured_fully_structured_still_unverified',claim)
missing=make_report(id='SBX-DEMO-MISSING');missing.pop('operator')
submit('missing_operator',missing)
tampered=make_report(id='SBX-DEMO-TAMPER');tampered['observations']['length_mm']['value']=122
submit('tampered_reading_not_bound_to_artifact',tampered)
expired=make_report(id='SBX-DEMO-EXPIRED');expired['instrument']['calibration_expires']='2026-10-09T11:44:59+00:00';docfix(expired)
submit('expired_calibration',expired)
uncertain=make_report(id='SBX-DEMO-UNCERTAIN');uncertain['observations']['length_mm']['value']='120.99';docfix(uncertain)
submit('crossing_tolerance_not_approved',uncertain)
wrong_unit=make_report(id='SBX-DEMO-UNIT');wrong_unit['observations']['length_mm']['unit']='UCS_SIM';docfix(wrong_unit)
submit('incompatible_units',wrong_unit)
spoof=make_report(id='SBX-DEMO-SPOOF');spoof['evidence_kind']='MEASURED_VERIFIED'
submit('false_approval_label',spoof)
# Identical ID and bytes replay cannot create a second journal entry.
replay=v.submit(claim,REVIEW)
assert replay['idempotent_replay'] and len(v.events)==len(cases)

comparisons={}
fixture=json.loads((R45/'fixtures/comparisons_synthetic.json').read_text())
for name,design in fixture['comparisons'].items():
 comparisons[name]=guarded_compare(name,design,add_condition_fixture(design['pairs']))

snap=ROOT/'results/r46_demo_snapshot.json'
snap_hash=v.snapshot(snap)
restored=EvidenceVault.restore(snap,expected_head=v.head)
assert restored.audit()==v.audit()
summary={'schema':'R46-DEMO-SYNTHETIC-v1','scope':'SYNTHETIC_FIXTURE_AND_UNVERIFIED_DOCUMENT_CLAIM_NOT_PHYSICAL',
         'models':list(recipes),'report_cases':len(cases),'journal_events':len(v.events),
         'idempotent_replays':1,'classification_counts':{},
         'historical_engine_modified':False,'real_measurements_verified':0,
         'official_rc5_created':0,'f5_material_status':'RED',
         'stock_effect':0,'snapshot_sha256':snap_hash,'journal_head':v.head,
         'recovery_audit':restored.audit(),'comparisons':{
            k:{'classification':vv['classification'],'n_pairs':vv['n_pairs'],
               'metrics':{m:vv['metrics'][m]['n_pairs'] for m in vv.get('metrics',{})},
               'empirical_superiority':vv['empirical_superiority']} for k,vv in comparisons.items()}}
for c in cases:summary['classification_counts'][c['status']]=summary['classification_counts'].get(c['status'],0)+1
for file,data in [('r46_demo_cases.json',cases),('r46_demo_summary.json',summary),('r46_comparison_results.json',comparisons),
                  ('r46_demo_journal.json',v.events)]:
 (ROOT/'results'/file).write_text(json.dumps(data,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(summary,indent=2,sort_keys=True,ensure_ascii=False))
