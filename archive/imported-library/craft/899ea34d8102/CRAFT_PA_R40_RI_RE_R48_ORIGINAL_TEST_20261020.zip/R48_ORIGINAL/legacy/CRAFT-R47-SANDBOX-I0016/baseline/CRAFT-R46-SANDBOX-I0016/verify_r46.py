"""Offline integrity gate for R46 ZIP; NOT physical science or NAC-PASS."""
from __future__ import annotations
import hashlib,io,json,sys,zipfile
from pathlib import PurePosixPath
PREFIX='CRAFT-R46-SANDBOX-I0016/'
R45_SHA='5b36b0aea5f7c6abf0275e93e192a8331201f38133c2275c270c59a788718946'
R44_SHA='900452bb24f398d1968e57ddbfabc0359fb93502cfd21eaf48e44ecfffd6aff3'

def sha(b):return hashlib.sha256(b).hexdigest()

def validate(zip_file):
 with zipfile.ZipFile(zip_file) as z:
  items=z.infolist();names=[i.filename for i in items]
  assert len(names)==len(set(names)), 'DUPLICATE_MEMBERS'
  assert z.testzip() is None, 'CRC_FAILED'
  for row in items:
   name=row.filename;path=PurePosixPath(name)
   assert name.startswith(PREFIX) and not name.startswith('/') and '..' not in path.parts and '\\' not in name, 'PATH_ESCAPE'
   assert (row.external_attr>>16)&0o170000!=0o120000, 'SYMLINK_MEMBER'
  m=PREFIX+'MANIFEST_SHA256.txt';assert m in names
  manifest=z.read(m).decode('utf8');lines={}
  for line in manifest.splitlines():
   if not line or line.startswith('#'):continue
   hash_,rel=line.split('  ',1)
   assert len(hash_)==64 and all(c in '0123456789abcdef' for c in hash_),'BAD_DIGEST'
   assert rel not in lines,'DUPLICATE_MANIFEST_MEMBER'
   lines[rel]=hash_
  allfiles={n[len(PREFIX):] for n in names if not n.endswith('/') and n!=m}
  assert set(lines)==allfiles,'ZIP_MANIFEST_SET_DIFF'
  for rel,h in lines.items():assert sha(z.read(PREFIX+rel))==h,'HASH_MISMATCH:'+rel
  for prefix,archive,expected,n in [
     ('baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016/',
      'baseline/CRAFT-R45-I0016-PLATAFORMA-EXPERIMENTAL-v01.zip',R45_SHA,50),
     ('baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016/',
      'baseline/CRAFT-R44-I0016-PILOTO-EXPERIMENTAL-v01.zip',R44_SHA,18)]:
   raw=z.read(PREFIX+archive)
   assert sha(raw)==expected,'PARENT_BASELINE_DRIFT'
   with zipfile.ZipFile(io.BytesIO(raw)) as parent:
    assert parent.testzip() is None,'PARENT_CRC'
    pm=parent.read(parent.namelist()[0]) if parent.namelist()[0].endswith('MANIFEST_SHA256.txt') else parent.read(prefix.split('/')[2]+'/MANIFEST_SHA256.txt')
    # Verify expanded files and byte-preserved originals independently.
    entries=[]
    for line in pm.decode('utf8').splitlines():
     if not line or line.startswith('#'):continue
     h,rel=line.split('  ',1);entries.append((h,rel))
    assert len(entries)==n,'PARENT_MANIFEST_COUNT'
    parentfolder='CRAFT-R45-SANDBOX-I0016/' if n==50 else 'CRAFT-R44-SANDBOX-I0016/'
    for h,rel in entries:
     assert sha(parent.read(parentfolder+rel))==h,'PARENT_ARCHIVE_ENTRY_FAILED:'+rel
     assert sha(z.read(PREFIX+prefix+rel))==h,'EXPANDED_BASELINE_MODIFIED:'+rel
  return {'status':'PASS','r46_sha256':sha(open(zip_file,'rb').read()),
          'manifest_files':len(lines),'crc':'PASS','r45_legacy_files':50,'r44_legacy_files':18,
          'scope':'SOFTWARE_ARCHIVE_INTEGRITY_ONLY'}

if __name__=='__main__':print(json.dumps(validate(sys.argv[1]),indent=2,sort_keys=True))
