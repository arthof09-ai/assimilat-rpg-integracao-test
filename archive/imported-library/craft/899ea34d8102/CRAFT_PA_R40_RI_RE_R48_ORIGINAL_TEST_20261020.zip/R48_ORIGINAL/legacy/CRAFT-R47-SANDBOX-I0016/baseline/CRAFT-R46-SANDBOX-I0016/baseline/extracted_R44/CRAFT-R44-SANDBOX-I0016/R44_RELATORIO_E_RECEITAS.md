# RELATÓRIO R44 — Primeiro piloto de receita experimental e reuso seguro

**PSV | CM-000002-I0016 | CM-000002-WS0001 — CRAFT | MESTRE-SIDE**  
**INTENT-ID:** `CRAFT-I0016-R44-EXP-ENGINE-20261009-001`  
**Rastreio ANTES (OP existente):** `CP-CRAFT-I0016-R44-SANDBOX-ANTES-001`  
**Escopo:** `CRAFT-R44-EXPERIMENTAL-LOCAL`; **F5/REC-LIB/Party/O Primeiro: NO-WRITE**.  
**Status:** modelos experimentais testáveis; **NÃO é fabricação real**, aprovação canônica, REC-ID oficial, RC5, disponibilidade de estoque ou simulação de leis físicas.

## 1. Contrato de experimento e estado anterior

O ponto de partida foi o dossiê `AUD-CRAFT-F5-REMAP-01` no Notion: a Tábua Lamelar era B30-01/PRE-Q2 e o Espaçador de Mica era B30-03/PRE-Q2. O registro especializado `PRE-REC-CRAFT-R42-TLI-METROLOGY-001` já documentava função, propostas de dimensões, QA, riscos, modelagem de custos, gatilhos anti-filler e bloqueios. O R43 havia mantido 23/30 PRE-Q2, 7/30 PRE-Q1; **0/30 fichas com RC5 real**. Esses objetos/contadores são históricos preservados, não recriados neste pacote.

A verificação inicial identificou `CM-000002-I0016` legitimada apenas para documentação em `CP-CRAFT-I0016-ALLOC-20261009-002`. `IBX-38=NOVA`, sem ACK; ausência de STOP-ACK/RELEASE técnico do predecessor I0014/C19, C19-021 UNKNOWN-EFFECT e `F5=P0/RED`. Não há base para atribuir writer, epoch, lease, canário ou GREEN. O R44 usa **inventários de teste criados inteiramente dentro de arquivos**, sem ler estoques canônicos como números reais.

### O que o motor prova e o que não prova

- **Prova de lógica:** insumos com ID de fonte referenciada e quantidade sintética; validação de identidade, unidade, geometria e condição; débito transacional; inspeção por medidas sintéticas explícitas; aprovação ou refugo; criação de produto apenas no inventário sintético; rejeição prévia sem débito; repetição idempotente; rollback e replay verificável.
- **Não prova:** extração ou clivagem reais, propriedades únicas da Ardósia de Geada, funcionalidade mágica de inscrição, labor de oficina na campanha, MED, rank, estoque existente, demanda de mercado, duração empírica, qualidade realmente medida ou integração REC-LIB.

## 2. Receita experimental 01 — Tábua Lamelar de Inscrição

**Chave somente sandbox:** `SBX-TLI-R44-v1` — **não é REC-ID**.  
**Origem PS da matéria-prima:** [Ardósia de Geada Lamelar](https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2), `CRAFT-F5-R01-MIN-01`, ficha já existente, sem estoque/lote comprovado.  
**Produto-alvo proposto:** tábua não mágica para marcação e inspeção geométrica em bancada, sem bônus de inscrição, sem slot mágico e sem vinculação automática a Player.

### 2.1 BOM proposta, unidade e meios

| Entrada | Quantidade de projeto | Estado/observação |
|---|---:|---|
| Lâmina de Ardósia de Geada Lamelar PS | 1 lâmina, **mínimo 130×90×9 mm** | Fonte existente, tamanho e disponibilidade por lote **não verificados** |
| Ferramentas reutilizáveis | 1 conjunto de corte/clivagem e apoio, régua/esquadro, paquímetro, abrasivo, escova/EPI | Meios de oficina propostos; **não** são novos recursos inventados |
| Abrasivo / EPI consumível | `a` gramas / `u` usos | Consumo real **a medir**, nunca reduzir automaticamente estoque do RPG |
| Cola, tinta, essência, runa | **0 obrigatório neste modelo** | Adesão ou magia não pressupostas; se necessárias, **versão deve ser revista** |

**Competências propostas:** lapidação/clivagem mineral, inspeção metrológica e segurança contra partículas/arestas; presença de artífice e instrumentos em cenário **PENDENTE**.

### 2.2 Transformação reproduzível como regra de jogo experimental

| Etapa | Operação | Tempo ativo **PROPOSTO** | Verificação |
|---|---|---:|---|
| 1 | Inspecionar proveniência, dimensões, fissuras e contaminação | 5 min | Entrada pode ser rejeitada sem débito |
| 2 | Marcar e cortar/clivar retângulo de 120×80 mm | 10 min | Quebra é falha terminal; sem produto |
| 3 | Aplainar faces até espessura de 8 mm | 15 min | Trincas, planicidade, espessura |
| 4 | Marcar grade ortogonal mecânica com passo 10 mm | 10 min | Sem runas; sulco ≤0,5 mm |
| 5 | Suavizar cantos, limpar pó, proteger operador | 10 min | Sem arestas cortantes |
| 6 | QA independente do desenho-alvo | 5 min | Aprova/refuga lote sintético |
| **Total ativo** | | **55 min** | Setup, transporte, espera e retrabalho **não medidos** |

A `experimental_engine.py` implementa esses passos como **contrato de transição** e validação explícita. Não interpreta que uma mudança de estado digital seja a execução física de uma lapidação. A prova de resultado vem dos parâmetros de inspeção **injetados na fixture**, não de uma medição autônoma pelo programa.

### 2.3 Produto, geometria, perdas e QA

**Produto de projeto:** 1 tábua 120×80×8 mm, quatro cantos sem arestas cortantes, linhas-guia ortogonais a cada 10 mm, uso físico simples. **Nenhum dano, defesa, FIP, PA, runa ativa ou propriedade elemental**.

Geometria ideal, sem perdas extras por fratura:

- `V_bruto = 130×90×9 = 105.300 mm³ = 105,3 cm³`.
- `V_produto = 120×80×8 = 76.800 mm³ = 76,8 cm³`.
- `V_ideal_removido = 28,5 cm³`; `aproveitamento geométrico ideal = 76,8/105,3 = 72,9344729%`.

**Não converter 72,93% em taxa de produção.** O rendimento industrial real depende de ruptura, espessura irregular, retrabalho, sobras aproveitáveis e QA. `N_pass / N_in` precisa ser medido em lotes verdadeiros e pode ser zero. Se o produto for reprovado após consumo, o motor marca **refugo sintético**, sem criar material vendável.

**Aceitação experimental proposta (não norma canônica):** lados 120 e 80 mm ±1; espessura 8 mm ±0,5; desvio de planeza 0–1 mm; espaçamento de malha 10 ±1 mm; profundidade 0–0,5 mm; ≥3 marcações repetidas; ausência explícita de trinca, delaminação, aresta aguda e efeito mágico. Falta de qualquer medição é **REJECTED_QUALITY**, nunca PASS por omissão.

**Rejeição prévia sem consumo:** matéria menor que 130×90×9 mm, fonte ou unidade incorretas, lâmina com fissura/delaminação/contaminação não resolvida, estoque sintético insuficiente, ferramenta ou habilidade necessária ausente. **Rejeição depois do processamento:** comprimento final fora da faixa, falta de planeza, profundidade excessiva, dano ou ausência de medição — insumo consumido e 0 unidades aprovadas. **Falha de infraestrutura do motor:** rollback sem qualquer mutação ou ledger publicado.

### 2.4 Economia de projeto sem inventar MED

Preço real, UTE, CTE por lote e rota **PENDENTES**. Fórmula simbólica por lote:

`CTE_lote = (1×P_lâmina) + (a_g×P_abrasivo/g) + (u×P_EPI/uso) + (55/60×w_artesão_h) + depreciação_ferramental + transporte + custo_refugo/retrabalho + custódia/capital`.

`CTE_unit = CTE_lote/N_QA_PASS` somente quando `N_QA_PASS > 0`; se não houver aprovações, custo unitário de peça válida fica **indefinido**, e não zero. A perda geométrica não é automaticamente perda financeira proporcional; valor de aparas também depende de prova de reaproveitamento.

**Exemplo estritamente didático em UCS — Unidades de Custo Simuladas (não MED):** lâmina 20 UCS, ofício 18 UCS/h, desgaste de ferramenta 2 UCS, EPI 1,5 UCS, rota 2 UCS, descarte 1 UCS. Para 55 min propostos, **43,00 UCS por lote com 1 peça aprovada**. A estimativa **não** representa preço, custo econômico real, salário ou mercado do RPG.

### 2.5 Diferenciação e anti-filler

Comparar com tábua comum de oficina, ardósia normal, régua já existente, pergaminho e matriz. A função distintiva precisa ser comprovada por estabilidade do plano, legibilidade/repetibilidade de traços, resistência, manuseio, regravabilidade e custo por uso. A palavra “Geada” não atesta isolamento de frio ou poder. Caso alternativas comuns entreguem desempenho igual com menor custo, **a hipótese de produto exclusivo deve ser combinada ou descartada**, sem apagar a Ardósia PS e sem fabricar receita para atingir quota.

### 2.6 Provas de execução sintética

O `run_demo.py` valida um lote sintético de 2 lâminas adequadas: um `SBX-DEMO-TLI-001` aprova e debita 1 lâmina, gerando 1 produto `SBX-CRAFT-R44-I0016-PRODUCT-*`; um segundo processamento na mesma origem falha QA pós-consumo, debita outra lâmina e gera refugo; uma tentativa seguinte com a mesma origem acusa estoque 0 e não debita. Outra lâmina de dimensões insuficientes é rejeitada **antes** do consumo. A repetição do ID+payload anterior devolve recibo prévio sem novo débito. Uma falha injetada após débito *não comitado* deixa estado idêntico ao anterior e permite novo processamento legítimo do mesmo ID no ambiente isolado.

## 3. Receita experimental 02 — Espaçador de Mica Calibrado

**Chave somente sandbox:** `SBX-MICA-R44-v1` — não é REC-ID. Fonte PS [Mica de Bruma Boreal](https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84), `CRAFT-F5-R01-MIN-02`; origem/estoque/dielétrica reais pendentes. Escolhida em vez do Cordão por exigir um segundo padrão **mineral e geométrico** com duas entradas e saída múltipla, que testa melhor a reutilização do mesmo motor.

**BOM proposta:** duas folhas de mica, cada uma com área contínua mínima 60×30 mm. Ferramentas reutilizáveis: lâmina fina de corte, apoio plano, micrômetro, régua e EPI. Competências: laminação mineral e metrologia. Sem novos insumos canônicos. **Saída de projeto:** duas peças de 50×20 mm para separação dimensional seca, sem poder/isolamento arcano.

**Etapas com tempos propostos no R44, não medidos no R42:** inspeção (4 min), recorte (7), remoção de arestas (5), comparação de espessuras (6), teste de montagem seca e QA (8) = **30 min ativos de desenho**. Espessura real `t_lote` permanece indeterminada. A tolerância de diferença entre folhas **≤0,10 mm** foi escolhida *apenas como parâmetro falsificável desta fixture experimental*; não constitui regra, requisito de encaixe no jogo ou propriedade PS constatada.

**QA:** exatamente duas peças, lados 50×20 mm ±1, diferença de espessura 0–0,10 mm, ambas sem trinca/lamela solta, encaixe seco positivo, nenhum efeito mágico. A mesma transação de estoque deve consumir 1 folha de **cada** lote, produzir 2 unidades sintéticas se aprovadas, refugar sem saída em falha pós-processo e negar nova execução com os lotes esgotados. Comparadores: mica comum, calço comum, espaçador já existente. Não afirmar superioridade sem prova de carga, geometria e custo.

**Custo:** `CTE_lote = 2×P_folha + 30/60×w_h + desgaste + EPI + rota + rejeições`. Somente como UCS fictícia, 2 folhas juntas=16 UCS, ofício=18 UCS/h, ferramenta=2, EPI=1,5, rota=2, descarte=1 → **31,50 UCS/lote / 2 saídas QA-PASS = 15,75 UCS/peça sintética**. MED real **não determinado**.

**Resultado de reuso:** o motor executou esta receita independente com mesma máquina de estados, mesmo formato de ledger, controle de duplicatas, QA específica e recuperação. Isso demonstra reutilização **do modelo computacional**, não equivalência física entre ardósia e mica.

## 4. Motor, método e resultados dos testes executados

O motor usa transações por cópia: `verificar → preparar nova versão → subtrair lotes sintéticos → validar QA → criar produto/refugo sintético → anexar evento com SHA-256 encadeado → verificar por replay → publicar`. Uma exceção intencional em qualquer ponto antes do commit descarta a cópia. Um `attempt_id` válido só pode ser usado uma vez; repetição idêntica devolve o recibo anterior, alteração de payload sob a mesma chave é barrada. Snapshot local tem SHA-256 de conteúdo e recusa mudanças de receita desde a captura.

### 4.1 Suíte de unidade e integração

O arquivo `results/test_suite.log` registra **52/52 testes PASS** cobrindo identificação de insumo, unidade, quantidade e dimensões; recursos contaminados/trincados, ferramentas e habilidades; limites positivos/negativos de QA; criação, refugo, falta de estoque, duplicidade, replay íntegro e adulterado; falha após débito/QA e antes de commit; roundtrip de snapshot, checksum inválido, alteração de receita, lote não sintético e economia em unidades simuladas.

### 4.2 Demonstração de ponta a ponta

| Cenário sintético | Entrada | Resultado esperado e observado |
|---|---|---|
| `SBX-DEMO-TLI-001` | 1 lâmina suficiente, inspeção conforme proposta | `EXPERIMENTAL_QA_PASS`, consome 1, gera 1 tábua `SBX-*` |
| `SBX-DEMO-TLI-002` | 1 lâmina 115×90×9 (abaixo da dimensão mínima) | `REJECTED_PRECHECK`, consome 0 |
| `SBX-DEMO-TLI-003` | 1 lâmina restante, peça medida sinteticamente 122,3 mm | `REJECTED_QUALITY`, consome 1, gera refugo, 0 produto |
| `SBX-DEMO-TLI-004` | Lote de lâminas anteriores sem saldo | `REJECTED_PRECHECK`, consome 0 |
| `SBX-DEMO-MICA-001` | 2 folhas suficientes, medições conforme proposta | `EXPERIMENTAL_QA_PASS`, consome 2 folhas, gera 2 espaçadores `SBX-*` |
| `SBX-DEMO-MICA-002` | Ambas as folhas já consumidas | `REJECTED_PRECHECK`, 0 produto |
| Replay TLI-001 | Mesmo attempt/payload do primeiro sucesso | `idempotent_replay=true`, eventos e estoque não se alteram |
| Crash injetado em branch | Falha deliberada após preparo de consumo e antes de commit | `rollback=true`, digest de estado invariável; retry passa |
| Restore | Reabrir `state_after.json` com checksum | `recovery_ok=true`, cadeia íntegra |

### 4.3 Stress determinístico suplementar

`stress_replay.py` rodou **600 tentativas fictícias** com seed `440016`. Resultado: **259 QA-PASS sintéticos, 105 rejeições prévias, 100 rejeições de QA, 136 crashes injetados/rollback, 30 replays idempotentes**; **0 invariantes falhos**; **464 eventos persistidos**; restauração de snapshot consistente. O total de 600 considera passes+rejeições+crashes, não os 30 replays (que não criam evento novo). Esses números são provas de robustez **do software isolado**, não probabilidade econômica ou chance de fabricação do mundo do RPG.

## 5. Prova de isolamento, integridade e recuperação

1. As fontes originais foram acessadas apenas por leitura para orientar o design. O mecanismo `experimental_engine.py` **não possui cliente Notion, HTTP ou método para atualização de páginas**. Nenhum dado de estoque canônico é importado: `fixtures/demo.json` declara `fixture_kind=SYNTHETIC`, IDs começam em `SBX-` e o motor rejeita lotes externos.
2. Todos os artefatos gerados por teste ficam na subpasta `results/` deste próprio sandbox. O único registro Mestre-side externo à pasta é um **checkpoint documental de controle na OP existente**, não uma fórmula ou produto canônico.
3. Os recibos e produtos carregam `simulation_only=true`, `official_rec_id=null`, `official_product_id=null` e bônus mecânico `0`; nenhum evento autoriza novo REC-ID, escrituração de estoque oficial, loja, preços MED ou Player.
4. A cadeia de SHA-256, o replay integral de quantidades/produtos/refugos e o checksum do checkpoint foram reabertos e comparados. Duplicação de pedido não duplica consumo. Falha no meio da operação não deixa débito persistido.
5. Para descartar o teste, apagar a pasta isolada e qualquer cópia do ZIP experimental. Isso não altera os objetos originais. **Não é rollback de uma produção real — porque não houve produção real.**

## 6. Pendências, gabaritos futuros e decisão

**PENDENTES de materialização real:** (i) exclusividade do writer e fencing C19; (ii) reconciliação de C19-021; (iii) definição de autoridade material e gate de LIB/REC-LIB; (iv) confirmação de fontes/estoque/lote PS de dimensão apropriada; (v) identificação da bancada, profissional, ferramentas e local legítimos; (vi) medidas reais de qualidade, tempo, massa, perdas e custos; (vii) teste funcional contra substitutos e decisão de relevância econômica; (viii) destino correto de receita/produto e backlinks sob GREEN e NAC-PASS correspondente.

**PRÓXIMA META FUNCIONAL recomendada:** reutilizar o motor para lote real de dados medidos **ainda isolado** com contrato de evidência independente, sem inseri-lo em jogo; comparar Tábua com gabarito comum e Mica com espaçador comum, registrar tempos/preços só quando houver fontes; no âmbito oficial aguardar a IBX-38/coordenador e fencing sem fazer pedido duplicado. Após liberação completa, primeiro microbloco RC5 poderá usar o modelo validado, com REC-ID oficial ÚNICO e readback das relações. Até lá, F5=RED, `RC5=0/30`, `experimental_designs=2/2`, `official_product=0`, sem CANON-PASS.

## 7. Rastros e pontos de retomada

- **Base documental preservada:** `PRE-REC-CRAFT-R42-TLI-METROLOGY-001`, `BACKFILL30-CRAFT-R42-A-001`, `CRAFT-I0016-R43-Q1-TRIAGE-20261009-001`, `CRAFT-I0016-R43-Q2-FUNCTIONAL-20261009-001`.
- **Registro ANTES:** `CP-CRAFT-I0016-R44-SANDBOX-ANTES-001` na OP-ARQ-RIN-REC-01; reabrir DEPOIS para readback.
- **Payload R44:** `recipes/tli.json`, `recipes/mica.json`, `experimental_engine.py`, fixtures, testes, recibos e snapshots, íntegros sob manifesto SHA-256.
- **FIRST-PENDING científico:** amostra e QA empíricas da Tábua; comparação funcional com ardósia/gabarito comum. **FIRST-PENDING material:** decisão técnica IBX-38 / fencing C19 e reconciliação C19-021 — nenhuma repetição cega.
- **NAC-CONT de sandbox:** prestate/antes; simulação isolada; testes; verificação; depois; sincronização documental de status na OP, sem materialização oficial. **NAC-PASS material CRAFT/F5 = HOLD**, não confundir com testes PASS do software.
