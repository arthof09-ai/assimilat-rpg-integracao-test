"""CRAFT R46: additive, OFFLINE, document *claim* validation and immutable decisions.

No inventory, manufacturing, Notion/network connectors, approval capability or official
writer. A valid cryptographic digest proves equality of supplied bytes, NOT authenticity,
calibration traceability, trustworthy origin or physical measurement.
R44 and R45 code remain in the untouched R45 baseline archive.
"""
from __future__ import annotations
import base64
import copy
import datetime as dt
import hashlib
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

R46_NAMESPACE='SBX-CRAFT-R46-I0016'
SCHEMA='R46-LAUDO-v1'
SNAPSHOT_SCHEMA='R46-VAULT-SNAPSHOT-v1'
GENESIS=hashlib.sha256((R46_NAMESPACE+'|GENESIS-01').encode()).hexdigest()
MAX_ARTIFACT_BYTES=250000
MAX_REPORT_JSON=1000000
UNITS={'mm':('length',Decimal('1')),'cm':('length',Decimal('10')),
       'm':('length',Decimal('1000')),'count':('count',Decimal('1')),
       'bool':('boolean',Decimal('1'))}
ARTIFACTS=('measurement','calibration','custody','operator')
STATUS_SET={'SYNTHETIC_QA_PASS','SYNTHETIC_QA_FAIL','SYNTHETIC_INDETERMINATE',
            'QUARANTINE_INCOMPLETE','QUARANTINE_SUSPECT','QUARANTINE_CALIBRATION',
            'QUARANTINE_INDETERMINATE','ELIGIBLE_FOR_INDEPENDENT_REVIEW'}

class EvidenceError(ValueError): pass
class InjectedFailure(RuntimeError): pass

def canonical(x:Any)->str:
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def digest(x:Any)->str:
    return hashlib.sha256(canonical(x).encode('utf8')).hexdigest()

def bytes_hash(value:bytes)->str:
    return hashlib.sha256(value).hexdigest()

def timestamp(value):
    if not isinstance(value,str):raise ValueError('time must include timezone')
    x=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
    if x.tzinfo is None or x.utcoffset() is None:raise ValueError('timezone required')
    return x.astimezone(dt.timezone.utc)

def number(v):
    if type(v) not in (str,int,float):raise ValueError('number required')
    try:z=Decimal(str(v))
    except InvalidOperation:raise ValueError('number invalid')
    if not z.is_finite():raise ValueError('number must be finite')
    return z

def dim_of(field,rule):
    if rule['kind']=='bool_eq':return 'boolean'
    if field.endswith('_count') or field=='piece_count':return 'count'
    if field.endswith('_mm'):return 'length'
    raise EvidenceError('UNMAPPED_QA_FIELD')

def _valid_id(s,prefix='SBX-',max_len=150):
    return type(s) is str and s.startswith(prefix) and len(s)<=max_len and len(s)>len(prefix) and all(c.isalnum() or c in '-_' for c in s)

def _artifact(artifact):
    if type(artifact) is not dict or set(artifact)!={'payload_b64','claimed_sha256'}:
        return 'MISSING_OR_BAD_ARTIFACT'
    v=artifact['claimed_sha256']
    if type(v) is not str or len(v)!=64 or any(x not in '0123456789abcdef' for x in v):
        return 'ARTIFACT_DIGEST_FORMAT'
    try:b=base64.b64decode(artifact['payload_b64'],validate=True)
    except (ValueError,base64.binascii.Error,TypeError):return 'INVALID_ARTIFACT_BYTES'
    if len(b)>MAX_ARTIFACT_BYTES:return 'ARTIFACT_TOO_LARGE'
    if bytes_hash(b)!=v:return 'ARTIFACT_DIGEST_MISMATCH'
    return None

def judge_reading(obs,rule,expected_sample,expected_inst,observed_at,inst_floor):
    """Return a guard-band verdict; ambiguous readings NEVER pass."""
    needed={'reading_id','value','unit','uncertainty_abs','instrument_id','sample_id','observed_at'}
    if type(obs) is not dict or set(obs)!=needed:return {'verdict':'UNVERIFIED','reason':'READING_FIELDS'}
    f=rule['field']
    if not _valid_id(obs['reading_id']) or obs['sample_id']!=expected_sample or obs['instrument_id']!=expected_inst:
        return {'verdict':'UNVERIFIED','reason':'READING_IDENTITY_MISMATCH'}
    try:
        if timestamp(obs['observed_at'])!=observed_at:raise ValueError('time mismatch')
    except (ValueError,TypeError):return {'verdict':'UNVERIFIED','reason':'READING_TIME_MISMATCH'}
    spec=UNITS.get(obs['unit']) if type(obs['unit']) is str else None
    if spec is None or spec[0]!=dim_of(f,rule):
        return {'verdict':'UNVERIFIED','reason':'READING_DIMENSION_MISMATCH'}
    dim,factor=spec
    if dim=='boolean':
        try:
            if type(obs['value']) is not bool or type(obs['uncertainty_abs']) not in (str,int,float) or number(obs['uncertainty_abs'])!=0:
                return {'verdict':'UNVERIFIED','reason':'INVALID_BOOLEAN'}
        except ValueError:
            return {'verdict':'UNVERIFIED','reason':'INVALID_BOOLEAN'}
        return {'verdict':'PASS' if obs['value']==rule['value'] else 'FAIL',
                'base_unit':'bool','value':obs['value'],'interval':None}
    try:
        v=number(obs['value'])*factor;u=number(obs['uncertainty_abs'])*factor
        if u<0:raise ValueError('negative uncertainty')
        if dim=='count' and (v<0 or v!=v.to_integral_value() or u!=0):raise ValueError('noninteger count')
        if dim=='length' and u<number(inst_floor):raise ValueError('below floor')
    except (ValueError,InvalidOperation):return {'verdict':'UNVERIFIED','reason':'MEASUREMENT_INVALID_OR_UNCERTAINTY_FLOOR'}
    lo=v-u;hi=v+u
    low_limit=number(rule['min']) if 'min' in rule else None
    high_limit=number(rule['max']) if 'max' in rule else None
    inside=(low_limit is None or lo>=low_limit) and (high_limit is None or hi<=high_limit)
    outside=(low_limit is not None and hi<low_limit) or (high_limit is not None and lo>high_limit)
    verdict='PASS' if inside else 'FAIL' if outside else 'INDETERMINATE'
    return {'verdict':verdict,'base_unit':'mm' if dim=='length' else 'count',
            'value':str(v),'interval':[str(lo),str(hi)]}

class EvidenceVault:
    """Content-addressed append-only local journal and deterministic replay.

    An unreviewed physical claim may become ELIGIBLE_FOR_INDEPENDENT_REVIEW,
    never PHYSICALLY_VERIFIED; the vault has no trusted physical authority.
    """
    def __init__(self,recipes:dict,sources:dict):
        self.recipes=copy.deepcopy(recipes)
        self.sources=copy.deepcopy(sources)
        if len(self.recipes)!=2 or set(self.recipes)!={'SBX-TLI-R44-v1','SBX-MICA-R44-v1'}:
            raise EvidenceError('ONLY_TWO_HISTORICAL_RECIPES')
        if set(self.sources)!={r['source_page_id'] for r in self.recipes.values()}:
            raise EvidenceError('SOURCE_REGISTRY_MISMATCH')
        for r in self.recipes.values():
            if r.get('official_rec_id') is not None or r.get('mechanical_bonus')!=0:
                raise EvidenceError('OFFICIAL_OR_BONUS_SCOPE')
        self.recipe_hash=digest(self.recipes);self.source_hash=digest(self.sources)
        self.events=[];self.head=GENESIS
        self._events_fingerprint=digest(self.events)
        self._checked_head=GENESIS

    def _classify(self,report,reviewed_at,prior_doc_hashes,prior_reading_ids=None):
        reasons_incomplete=[]; reasons_suspect=[]; reasons_cal=[]; verdicts={}; doc_hash=None
        prior_reading_ids=prior_reading_ids or set()
        expected={'schema','report_id','recipe_key','evidence_kind','source_page_id','source_crn_id',
                  'sample_id','lot_ids','operator','instrument','observed_at','submitted_at',
                  'conditions','custody','artifacts','observations'}
        for k in sorted(expected-set(report)):reasons_incomplete.append('MISSING_'+k)
        for k in sorted(set(report)-expected):reasons_suspect.append('UNEXPECTED_'+k)
        kind=report.get('evidence_kind')
        if kind not in ('SYNTHETIC','MEASURED_CLAIM_UNVERIFIED'):
            reasons_suspect.append('FORBIDDEN_EVIDENCE_LABEL')
        if report.get('schema')!=SCHEMA:reasons_suspect.append('SCHEMA_MISMATCH')
        rkey=report.get('recipe_key');recipe=self.recipes.get(rkey)
        if recipe is None:reasons_suspect.append('RECIPE_NOT_IN_TWO_MODELS')
        else:
            if report.get('source_page_id')!=recipe['source_page_id'] or report.get('source_crn_id')!=recipe['source_crn_id']:
                reasons_suspect.append('SOURCE_PS_MISMATCH')
            if recipe['source_page_id'] not in self.sources:
                reasons_suspect.append('PS_SOURCE_NOT_REGISTERED')
        sample=report.get('sample_id')
        if not _valid_id(sample,prefix='SBX-' if kind=='SYNTHETIC' else 'CLAIM-'):
            reasons_suspect.append('SAMPLE_ID_MISMATCH')
        lots=report.get('lot_ids')
        if type(lots) is not list or not lots or any(not _valid_id(x,prefix='SBX-' if kind=='SYNTHETIC' else 'CLAIM-') for x in lots) or len(set(lots))!=len(lots):
            reasons_incomplete.append('LOT_PROVENANCE_INVALID')
        operator=report.get('operator')
        if type(operator) is not dict or set(operator)!={'operator_id','competency','attestation_ref'}:
            reasons_incomplete.append('OPERATOR_FIELDS')
        else:
            if not all(type(operator[x]) is str and len(operator[x])>=5 for x in operator):
                reasons_incomplete.append('OPERATOR_ATTRIBUTION')
            if kind=='SYNTHETIC' and operator['competency']!='SYNTHETIC_FIXTURE':
                reasons_suspect.append('SYNTHETIC_OPERATOR_SCOPE')
        observed=submitted=reviewed=None
        try:
            observed=timestamp(report.get('observed_at'))
            submitted=timestamp(report.get('submitted_at'))
            reviewed=timestamp(reviewed_at)
            if not (observed<=submitted<=reviewed):reasons_suspect.append('IMPOSSIBLE_CHRONOLOGY')
        except (ValueError,TypeError):reasons_incomplete.append('INVALID_OR_NAIVE_TIME')
        conditions=report.get('conditions')
        if type(conditions) is not dict or set(conditions)!={'setup_id','temperature_c','humidity_pct','method_id'}:
            reasons_incomplete.append('CONDITIONS_MISSING')
        else:
            if not isinstance(conditions['setup_id'],str) or not isinstance(conditions['method_id'],str):
                reasons_incomplete.append('CONDITIONS_SETUP_METHOD')
            try:
                t=number(conditions['temperature_c']);h=number(conditions['humidity_pct'])
                if t < -100 or t > 200 or h<0 or h>100:reasons_suspect.append('CONDITIONS_OUT_OF_PLAUSIBLE_BOUNDS')
            except ValueError:reasons_incomplete.append('CONDITIONS_BAD_NUMERIC')
        artifacts=report.get('artifacts')
        if type(artifacts) is not dict or set(artifacts)!=set(ARTIFACTS):
            reasons_incomplete.append('ARTIFACT_SET_INCOMPLETE')
        else:
            for name,blob in artifacts.items():
                err=_artifact(blob)
                if err:reasons_suspect.append(name.upper()+'_'+err)
            doc_hash=artifacts['measurement'].get('claimed_sha256') if type(artifacts['measurement']) is dict else None
            if isinstance(doc_hash,str) and doc_hash in prior_doc_hashes:
                reasons_suspect.append('DUPLICATE_MEASUREMENT_DOCUMENT')
        # Bind the actual artifact bytes to the assertions in the report.
        # A matching hash without a content-level cross-check is insufficient.
        if type(artifacts) is dict and set(artifacts)==set(ARTIFACTS):
            try:
                parsed={key:json.loads(base64.b64decode(artifacts[key]['payload_b64'],validate=True).decode('utf8'))
                        for key in ARTIFACTS}
                instrument_row=report.get('instrument')
                expected_content={
                    'measurement':{'sample_id':report.get('sample_id'),
                                   'source_page_id':report.get('source_page_id'),
                                   'instrument_id':instrument_row.get('instrument_id') if type(instrument_row) is dict else None,
                                   'observed_at':report.get('observed_at'),
                                   'observations':report.get('observations')},
                    'calibration':{k:v for k,v in instrument_row.items() if k!='certificate_sha256'}
                                   if type(instrument_row) is dict else None,
                    'custody':{'sample_id':report.get('sample_id'),
                               'events':[{k:v for k,v in e.items() if k!='support_sha256'}
                                         for e in report.get('custody',[]) if type(e) is dict]},
                    'operator':{'sample_id':report.get('sample_id'),
                                'operator':{k:v for k,v in report.get('operator',{}).items() if k!='attestation_ref'}}
                                if type(report.get('operator')) is dict else None}
                for key in ARTIFACTS:
                    if expected_content[key] is not None and (key!='measurement' or all(k in report for k in ('sample_id','source_page_id','observed_at','observations'))) and parsed[key]!=expected_content[key]:
                        reasons_suspect.append('ARTIFACT_CONTENT_BINDING_MISMATCH_'+key.upper())
            except (UnicodeDecodeError,ValueError,TypeError,KeyError,base64.binascii.Error):
                reasons_suspect.append('ARTIFACT_JSON_UNREADABLE')
        if type(operator) is dict and type(artifacts) is dict and type(artifacts.get('operator')) is dict:
            if operator.get('attestation_ref')!=artifacts['operator'].get('claimed_sha256'):
                reasons_suspect.append('OPERATOR_ATTESTATION_HASH_MISMATCH')
        inst=report.get('instrument')
        if type(inst) is not dict or set(inst)!={'instrument_id','serial','calibration_id','calibration_start',
                                                'calibration_expires','certificate_sha256','dimensions','uncertainty_floor_mm'}:
            reasons_incomplete.append('INSTRUMENT_FIELDS')
        else:
            if type(inst['instrument_id']) is not str or type(inst['serial']) is not str or len(inst['serial'])<3:
                reasons_incomplete.append('INSTRUMENT_SERIAL')
            if type(inst['calibration_id']) is not str or not inst['calibration_id']:
                reasons_incomplete.append('CALIBRATION_ID')
            if not isinstance(inst['dimensions'],list) or not inst['dimensions'] or any(d not in ('length','boolean','count') for d in inst['dimensions']):
                reasons_incomplete.append('INSTRUMENT_DIMENSIONS')
            try:
                if number(inst['uncertainty_floor_mm'])<0:raise ValueError('floor negative')
            except ValueError:reasons_incomplete.append('INVALID_INSTRUMENT_FLOOR')
            try:
                start=timestamp(inst['calibration_start']);expires=timestamp(inst['calibration_expires'])
                if start>expires or (observed is not None and not start<=observed<=expires):
                    reasons_cal.append('CALIBRATION_OUT_OF_WINDOW')
            except (ValueError,TypeError):reasons_cal.append('CALIBRATION_TIME_MISSING')
            if artifacts and type(artifacts) is dict and type(artifacts.get('calibration')) is dict:
                if inst['certificate_sha256']!=artifacts['calibration'].get('claimed_sha256'):
                    reasons_suspect.append('CALIBRATION_CERTIFICATE_DIGEST_MISMATCH')
            if kind=='SYNTHETIC' and not inst['instrument_id'].startswith('SBX-'):
                reasons_suspect.append('SYNTHETIC_INSTRUMENT_SCOPE')
        custody=report.get('custody')
        if type(custody) is not list or len(custody)<2:
            reasons_incomplete.append('CUSTODY_CHAIN_MISSING')
        else:
            ids=set();last=None
            for row in custody:
                if type(row) is not dict or set(row)!={'event_id','sample_id','at','actor_id','action','support_sha256'}:
                    reasons_incomplete.append('CUSTODY_EVENT_FIELDS');continue
                if row['event_id'] in ids:reasons_suspect.append('CUSTODY_EVENT_DUPLICATE')
                ids.add(row['event_id'])
                if row['sample_id']!=sample:reasons_suspect.append('CUSTODY_SAMPLE_DIVERGENCE')
                if row['action'] not in ('COLLECTED','TRANSFERRED','MEASURED','RECEIVED'):
                    reasons_suspect.append('INVALID_CUSTODY_ACTION')
                try:
                    at=timestamp(row['at'])
                    if (last is not None and at<last) or (submitted is not None and at>submitted):
                        reasons_suspect.append('CUSTODY_NONMONOTONIC')
                    last=at
                except (ValueError,TypeError):reasons_incomplete.append('CUSTODY_TIME')
                if artifacts and type(artifacts) is dict and type(artifacts.get('custody')) is dict:
                    if row['support_sha256']!=artifacts['custody'].get('claimed_sha256'):
                        reasons_suspect.append('CUSTODY_SUPPORT_DIGEST_MISMATCH')
            measured_events=[e for e in custody if type(e) is dict and e.get('action')=='MEASURED']
            if not measured_events:reasons_incomplete.append('CUSTODY_MEASURED_EVENT_ABSENT')
            else:
                if observed is not None and type(operator) is dict and not any(e.get('at')==report.get('observed_at') and
                           e.get('actor_id')==operator.get('operator_id')
                           for e in measured_events):
                    reasons_suspect.append('MEASURED_CUSTODY_OPERATOR_OR_TIME_MISMATCH')
        readings=report.get('observations')
        if recipe is None or type(readings) is not dict:
            reasons_incomplete.append('OBSERVATIONS_UNAVAILABLE')
        else:
            required={x['field'] for x in recipe['qa_rules']}
            if set(readings)!=required:reasons_incomplete.append('QA_SET_INCOMPLETE_OR_EXTRA')
            observed_ids=[]
            for rule in recipe['qa_rules']:
                f=rule['field']
                if f not in readings:continue
                ob=readings[f]
                if type(ob) is dict:
                    observed_ids.append(ob.get('reading_id'))
                    if ob.get('reading_id') in prior_reading_ids:
                        reasons_suspect.append('READING_ID_REUSED_ACROSS_REPORTS')
                result=judge_reading(ob,rule,sample,inst['instrument_id'] if type(inst) is dict and 'instrument_id' in inst else None,
                                     observed,inst.get('uncertainty_floor_mm','0') if type(inst) is dict else '0') if observed is not None else {'verdict':'UNVERIFIED','reason':'TIME_MISSING'}
                verdicts[f]=result
                if result['verdict']=='UNVERIFIED':reasons_incomplete.append('QA_'+f+'_'+result.get('reason','INVALID'))
                if type(inst) is dict and type(inst.get('dimensions')) is list and dim_of(f,rule) not in inst['dimensions']:
                    reasons_incomplete.append('INSTRUMENT_DIMENSION_UNSUPPORTED_'+f)
            if len(observed_ids)!=len(set(observed_ids)):
                reasons_suspect.append('READING_IDS_DUPLICATED')
        if reasons_suspect:status='QUARANTINE_SUSPECT'
        elif reasons_incomplete:status='QUARANTINE_INCOMPLETE'
        elif reasons_cal:status='QUARANTINE_CALIBRATION'
        else:
            v={v['verdict'] for v in verdicts.values()}
            if 'INDETERMINATE' in v:
                status='SYNTHETIC_INDETERMINATE' if kind=='SYNTHETIC' else 'QUARANTINE_INDETERMINATE'
            elif 'FAIL' in v:
                status='SYNTHETIC_QA_FAIL' if kind=='SYNTHETIC' else 'QUARANTINE_INDETERMINATE'
            else:
                status='SYNTHETIC_QA_PASS' if kind=='SYNTHETIC' else 'ELIGIBLE_FOR_INDEPENDENT_REVIEW'
        return {'report_id':report['report_id'],'status':status,
                'evidence_kind':kind,'document_sha256':doc_hash,
                'problems':sorted(set(reasons_incomplete+reasons_suspect+reasons_cal)),
                'inspection':verdicts,'readings_evaluated':len(verdicts),
                'execution_authorized':False,'official_rec_id':None,'stock_effect':0,
                'physical_measurement_verified':False,'materialized':False,
                'trust_boundary':'DIGEST_MATCH_IS_NOT_REAL_WORLD_AUTHENTICATION',
                'review_next':'INDEPENDENT_EVIDENCE_AND_CALIBRATION_AUDIT' if status=='ELIGIBLE_FOR_INDEPENDENT_REVIEW' else 'RESOLVE_QUARANTINE_OR_SYNTHETIC_ONLY'}

    def _evaluate(self,events):
        reasons=[];prev=GENESIS;byid={};docs=set();readings_seen=set()
        if digest(self.recipes)!=self.recipe_hash or digest(self.sources)!=self.source_hash:
            reasons.append('GENESIS_ANCHOR_DRIFT')
        for i,entry in enumerate(events,1):
            if type(entry) is not dict or set(entry)!={'seq','previous_hash','hash','payload'}:
                reasons.append(f'ENTRY_FIELDS_{i}');break
            if entry['seq']!=i or entry['previous_hash']!=prev:
                reasons.append(f'CHAIN_INDEX_{i}')
            h=digest({'previous_hash':entry['previous_hash'],'payload':entry['payload']})
            if entry['hash']!=h:reasons.append(f'CHAIN_HASH_{i}')
            prev=entry['hash']
            e=entry['payload'];rid=e['report']['report_id']
            if rid in byid:reasons.append('JOURNAL_DUPLICATE_REPORT_ID')
            byid[rid]=e
            try:
                expected=self._classify(e['report'],e['reviewed_at'],docs,readings_seen)
                if expected!=e['decision']:reasons.append(f'DECISION_REPLAY_MISMATCH_{i}')
                if digest(e['report'])!=e['request_hash']:
                    reasons.append(f'REPORT_FINGERPRINT_MISMATCH_{i}')
                dh=expected['document_sha256']
                if type(dh) is str and len(dh)==64:docs.add(dh)
                obs=e['report'].get('observations')
                if type(obs) is dict:
                    for row in obs.values():
                        if type(row) is dict and type(row.get('reading_id')) is str:
                            readings_seen.add(row['reading_id'])
            except Exception:
                reasons.append(f'REPLAY_EXCEPTION_{i}')
        return {'ok':not reasons,'issues':sorted(set(reasons)),'head':prev,
                'events':len(events),'report_ids':len(byid)}

    def audit(self):
        r=self._evaluate(self.events)
        if self.head!=r['head']:r['ok']=False;r['issues'].append('HEAD_HASH_MISMATCH')
        return r

    def submit(self,report:dict,reviewed_at:str,inject:str|None=None):
        # Fast optimistic check of all previously committed bytes plus anchor.
        # Full semantic replay occurs periodically, at snapshot and at restore.
        if (digest(self.events)!=self._events_fingerprint or
            digest(self.recipes)!=self.recipe_hash or digest(self.sources)!=self.source_hash or
            (self.events[-1]['hash'] if self.events else GENESIS)!=self.head):
            raise EvidenceError('REFUSE_MUTATED_JOURNAL')
        if type(report) is not dict or not _valid_id(report.get('report_id')):
            raise EvidenceError('REPORT_ID_INVALID')
        try:
            fingerprint=digest(report)
            if len(canonical(report))>MAX_REPORT_JSON:raise EvidenceError('OVERSIZE_REPORT')
        except (TypeError,ValueError,OverflowError) as exc:
            raise EvidenceError('UNSERIALIZABLE_REPORT') from exc
        try:timestamp(reviewed_at)
        except (ValueError,TypeError) as exc:raise EvidenceError('INVALID_REVIEW_CLOCK') from exc
        old=next((e for e in self.events if e['payload']['report']['report_id']==report['report_id']),None)
        if old:
            if old['payload']['request_hash']!=fingerprint or old['payload']['reviewed_at']!=reviewed_at:
                raise EvidenceError('REPORT_ID_REUSE_WITH_CHANGED_PAYLOAD_OR_REVIEW_TIME')
            return {**copy.deepcopy(old['payload']['decision']),'idempotent_replay':True,
                    'receipt_hash':old['hash'],'journal_events':len(self.events)}
        previous_docs=set();previous_readings=set()
        for e in self.events:
            d=e['payload']['decision']['document_sha256']
            if type(d) is str:previous_docs.add(d)
            obs=e['payload']['report'].get('observations')
            if type(obs) is dict:
                for row in obs.values():
                    if type(row) is dict and type(row.get('reading_id')) is str:
                        previous_readings.add(row['reading_id'])
        decision=self._classify(report,reviewed_at,previous_docs,previous_readings)
        if decision['status'] not in STATUS_SET:raise EvidenceError('INVALID_DECISION_STATUS')
        if inject in ('AFTER_VALIDATION_BEFORE_JOURNAL','AFTER_STAGE_BEFORE_COMMIT'):
            raise InjectedFailure(inject)
        payload={'report':copy.deepcopy(report),'reviewed_at':reviewed_at,
                 'request_hash':fingerprint,'decision':decision}
        entry={'seq':len(self.events)+1,'previous_hash':self.head,'payload':payload}
        entry['hash']=digest({'previous_hash':self.head,'payload':payload})
        staged=self.events+[entry]
        # Never expose an unverified checkpoint: each 25th commit receives a
        # full replay before publication; all snapshots also full-replay.
        if len(staged)%25==0:
            test=self._evaluate(staged)
            if not test['ok']:raise EvidenceError('STAGED_REPLAY_FAILED:'+str(test['issues']))
        self.events=staged;self.head=entry['hash']
        self._events_fingerprint=digest(self.events)
        return {**copy.deepcopy(decision),'idempotent_replay':False,
                'receipt_hash':entry['hash'],'journal_events':len(self.events)}

    def submit_batch(self,reports:list[dict],reviewed_at:str,inject=None):
        """Atomic local intake for a manifest of reports; quarantine decisions persist.

        If interrupted before COMMIT, the original journal/head remain unchanged.
        There is no authority to mutate official production or claim measured status.
        """
        if type(reports) is not list or not reports or len(reports)>100:
            raise EvidenceError('BATCH_ARITY')
        ids=[x.get('report_id') if type(x) is dict else None for x in reports]
        if len(set(map(repr,ids)))!=len(ids):raise EvidenceError('BATCH_DUPLICATE_IDS')
        if digest(self.events)!=self._events_fingerprint or not self.audit()['ok']:
            raise EvidenceError('REFUSE_MUTATED_BATCH_BASELINE')
        staged=copy.deepcopy(self)
        receipts=[]
        for r in reports:
            receipts.append(staged.submit(r,reviewed_at))
        if inject in ('AFTER_BATCH_STAGE_BEFORE_COMMIT','BEFORE_BATCH_PUBLISH'):
            raise InjectedFailure('BATCH_ROLLBACK_'+inject)
        if not staged.audit()['ok']:raise EvidenceError('BATCH_REPLAY_INVALID')
        self.events=staged.events
        self.head=staged.head
        self._events_fingerprint=staged._events_fingerprint
        return {'batch_reports':len(reports),'receipts':receipts,
                'journal_events':len(self.events),'journal_head':self.head,
                'official_rc5_created':0,'physical_measurements_verified':0,
                'stock_effect':0}

    def snapshot(self,path,inject=None):
        if not self.audit()['ok']:raise EvidenceError('REFUSE_INVALID_SNAPSHOT')
        state={'schema':SNAPSHOT_SCHEMA,'namespace':R46_NAMESPACE,
               'recipes':self.recipes,'sources':self.sources,
               'recipe_hash':self.recipe_hash,'source_hash':self.source_hash,
               'genesis':GENESIS,'events':self.events,'journal_head':self.head}
        state['snapshot_sha256']=digest(state)
        p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_suffix(p.suffix+'.tmp')
        tmp.write_text(json.dumps(state,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
        if inject=='BEFORE_ATOMIC_RENAME':raise InjectedFailure('BEFORE_ATOMIC_RENAME')
        tmp.replace(p)
        return state['snapshot_sha256']

    @classmethod
    def restore(cls,path,expected_head=None):
        w=json.loads(Path(path).read_text(encoding='utf8'))
        signature=w.pop('snapshot_sha256',None)
        if signature is None or digest(w)!=signature:
            raise EvidenceError('SNAPSHOT_HASH_INVALID')
        if w.get('schema')!=SNAPSHOT_SCHEMA or w.get('namespace')!=R46_NAMESPACE or w.get('genesis')!=GENESIS:
            raise EvidenceError('SNAPSHOT_SCHEMA_INVALID')
        o=cls(w['recipes'],w['sources'])
        if o.recipe_hash!=w['recipe_hash'] or o.source_hash!=w['source_hash']:
            raise EvidenceError('SNAPSHOT_ANCHOR_INVALID')
        if type(w['events']) is not list:raise EvidenceError('SNAPSHOT_JOURNAL_INVALID')
        o.events=w['events'];o.head=w['journal_head']
        result=o.audit()
        if not result['ok']:raise EvidenceError('SNAPSHOT_REPLAY_FAILURE:'+str(result['issues']))
        if expected_head is not None and o.head!=expected_head:
            raise EvidenceError('EXTERNAL_HEAD_ANCHOR_CONFLICT')
        o._events_fingerprint=digest(o.events)
        return o
