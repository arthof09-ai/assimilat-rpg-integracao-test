import sys,unittest,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from r45_engine import quarantine_claimed_measurements,load_recipes,SandboxError
R=load_recipes(ROOT/'r44_legacy/recipes')

class QuarantineTests(unittest.TestCase):
    def claim(self):
        key='SBX-TLI-R44-v1'
        return {'claim_id':'SBX-CLAIM-UNVERIFIED-01','recipe_key':key,
                'evidence_kind':'MEASURED_CLAIM_UNVERIFIED','sample_id':'SBX-SAMPLE-UNVERIFIED-01',
                'source_page_id':R[key]['source_page_id'],
                'sample_chain_ref':'PENDING-REVIEW-NOT-ATTESTED',
                'measurement_document_sha256':'f'*64,
                'instrument_cert_sha256':'e'*64,
                'operator_attestation_ref':'PENDING-REVIEW-NOT-ATTESTED',
                'observed_at':'2026-10-09T11:30:00+00:00',
                'observations':{q['field']:{'placeholder':'NOT-A-PHYSICAL-READING'} for q in R[key]['qa_rules']}}
    def test_01_quarantine_never_execute(self):
        r=quarantine_claimed_measurements(self.claim(),R)
        self.assertFalse(r['execution_authorized']);self.assertFalse(r['materialized'])
        self.assertEqual(r['stock_effect'],0)
    def test_02_no_missing_provenance(self):
        c=self.claim();del c['sample_chain_ref']
        with self.assertRaisesRegex(SandboxError,'INCOMPLETE_MEASURED'):quarantine_claimed_measurements(c,R)
    def test_03_fake_verified_label_rejected(self):
        c=self.claim();c['evidence_kind']='VERIFIED'
        with self.assertRaisesRegex(SandboxError,'NO_PROMOTION'):quarantine_claimed_measurements(c,R)
    def test_04_wrong_source_rejected(self):
        c=self.claim();c['source_page_id']='wrong'
        with self.assertRaisesRegex(SandboxError,'UNKNOWN_RECIPE_OR_SOURCE'):quarantine_claimed_measurements(c,R)
    def test_05_bad_hash_rejected(self):
        c=self.claim();c['measurement_document_sha256']='not a hash'
        with self.assertRaisesRegex(SandboxError,'INVALID_EVIDENCE_DIGEST'):quarantine_claimed_measurements(c,R)
    def test_06_missing_field_rejected(self):
        c=self.claim();del c['observations']['cracks']
        with self.assertRaisesRegex(SandboxError,'INCOMPLETE_QA'):quarantine_claimed_measurements(c,R)
