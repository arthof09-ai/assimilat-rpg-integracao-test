"""Deterministic CRAFT R47 synthetic evidence demonstration, no production side effect."""
import copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from r47_fixtures import make_pair,policy,recipes_and_sources,REVIEW,sign
from r47_authenticity import AuthenticityVault,AuthError,InjectedFailure,digest
from r46_comparison import guarded_compare,add_condition_fixture
from r46_fixtures import R45

def save(name,value):
    (ROOT/'results'/name).write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
recipes,sources=recipes_and_sources();v=AuthenticityVault(recipes,sources,policy());cases=[]

def add(name,r,a):
    d=v.submit(r,a,REVIEW)
    cases.append({'name':name,'report_id':r['report_id'],'status':d['status'],'r46_status':d['r46_status'],
                  'reason':d['reasons'],'signature_count':d['valid_signature_count'],
                  'custody_events':d['custody_event_count'],'physically_verified':d['physically_verified'],
                  'receipt_hash':d['receipt_hash'],'missing':d['missing_to_accept_physical_measurement']})
    assert d['stock_effect']==0 and not d['physically_verified'] and d['official_rec_id'] is None

r,a=make_pair(index=90001);add('tli_integrity_and_fixture_signatures_pass_not_real',r,a)
r,a=make_pair(index=90002,key='SBX-MICA-R44-v1');add('mica_integrity_and_fixture_signatures_pass_not_real',r,a)
r,a=make_pair(index=90003,kind='MEASURED_CLAIM_UNVERIFIED');add('documentary_claim_signed_by_fake_CA_not_real',r,a)
r,a=make_pair(index=90004);a['report_proof']['signature_b64']=sign('calibrator',a['report_proof']['body']);add('invalid_operator_signature',r,a)
r,a=make_pair(index=90005);a['certificates']['operator']['body']['issuer_root_id']='FAKE-UNKNOWN-ROOT';add('untrusted_issuer_root',r,a)
r,a=make_pair(index=90006);b=a['certificates']['operator']['body'];b['not_after']='2026-10-09T11:46:00+00:00';a['certificates']['operator']['signature_b64']=sign('root',b);add('expired_operator_certificate',r,a)
r,a=make_pair(index=90007);a['custody_events'].pop(2);add('missing_custody_receipt',r,a)
r,a=make_pair(index=90008);a['custody_events'][3]['body']['instrument_id']='WRONG';add('instrument_divergence_with_broken_signature',r,a)
r,a=make_pair(index=90009);add('second_full_synthetic_custody',r,a)
# Retry exact report once; detect and do not create second receipt.
retry=v.submit(r,a,REVIEW);assert retry['idempotent_replay'] and len(v.events)==9
# Demonstrate simultaneous two-document atomic batch success, then injected abort.
batch=[]
for num,key in [(90010,'SBX-TLI-R44-v1'),(90011,'SBX-MICA-R44-v1')]:
    report,att=make_pair(index=num,key=key)
    batch.append({'report':report,'attestation':att})
commit=v.submit_batch(batch,REVIEW)
assert len(v.events)==11 and v.audit()['ok']
before={'r47':v.head,'r46':v.parent.head,'events':len(v.events)}
crashpair=[]
for num in (90012,90013):
    report,att=make_pair(index=num);crashpair.append({'report':report,'attestation':att})
try:v.submit_batch(crashpair,REVIEW,inject='MID_BATCH_ABORT');raise AssertionError('INJECTION_NOT_TRIGGERED')
except InjectedFailure:pass
assert before=={'r47':v.head,'r46':v.parent.head,'events':len(v.events)}
# Run both R46 comparisons again, in place of fabricating a new candidate.
fixture=json.loads((R45/'fixtures/comparisons_synthetic.json').read_text())
comps={name:guarded_compare(name,design,add_condition_fixture(design['pairs']))
       for name,design in fixture['comparisons'].items()}
old=json.loads((ROOT/'baseline/CRAFT-R46-SANDBOX-I0016/results/r46_comparison_results.json').read_text())
assert comps==old,'R46_COMPARISON_RESULT_DRIFT'
assert all(c['scope']=='SYNTHETIC_PAIRED_DESCRIPTIVE' and not c['empirical_superiority'] for c in comps.values())
snap_hash=v.snapshot(ROOT/'results/r47_demo_snapshot.json')
loaded=AuthenticityVault.restore(ROOT/'results/r47_demo_snapshot.json',v.trust.policy_sha256,v.head)
assert loaded.audit()==v.audit()
save('r47_demo_cases.json',cases)
save('r47_demo_journal.json',v.events)
save('r47_comparison_results.json',comps)
summary={'schema':'R47-SYNTHETIC-DEMO-v1','models':list(recipes),
         'scope':'ALL_KEYS_CERTS_SAMPLES_OPERATORS_INSTRUMENTS_AND_RESULTS_SIMULATED',
         'cases':len(cases),'journal_events':len(v.events),
         'batch_atomic_commits':2,'batch_rollback_cases':2,'idempotent_replays':1,
         'status_counts':{},'r47_head':v.head,'r46_head':v.parent.head,'snapshot_sha256':snap_hash,
         'trust_policy_sha256':v.trust.policy_sha256,'restore_audit':loaded.audit(),
         'comparison_unchanged_from_R46':True,'comparisons':{k:{'classification':val['classification'],'n_pairs':val['n_pairs'],'empirical_superiority':False} for k,val in comps.items()},
         'physical_measurements_verified':0,'official_stock_effects':0,'official_rc5':0,'f5':'RED'}
for c in cases:summary['status_counts'][c['status']]=summary['status_counts'].get(c['status'],0)+1
save('r47_demo_summary.json',summary)
print(json.dumps(summary,indent=2,sort_keys=True,ensure_ascii=False))
