"""Independent SHA/CRC/manifest/lineage validator for experimental R47.

This is file integrity only; hashes do not certify scientific physical results.
"""
from __future__ import annotations
import hashlib,io,json,sys,zipfile
from pathlib import Path,PurePosixPath

ROOT='CRAFT-R47-SANDBOX-I0016/'
R46_ROOT='CRAFT-R46-SANDBOX-I0016/'
R46_SHA='966e137b5092b419e8a94804c97711d36ba0f119a96ba212cf53d0a1953b25f4'
R45_SHA='5b36b0aea5f7c6abf0275e93e192a8331201f38133c2275c270c59a788718946'
R44_SHA='900452bb24f398d1968e57ddbfabc0359fb93502cfd21eaf48e44ecfffd6aff3'


def sha(b):return hashlib.sha256(b).hexdigest()

def manifest(data):
    entries={}
    for row in data.decode('utf8').splitlines():
        if not row or row.startswith('#'):continue
        hexhash,name=row.split('  ',1)
        assert len(hexhash)==64 and all(c in '0123456789abcdef' for c in hexhash),'BAD_MANIFEST_HASH'
        assert name not in entries,'DUPLICATE_MANIFEST_LINE'
        entries[name]=hexhash
    return entries

def validate(zpath):
    with zipfile.ZipFile(zpath) as z:
        inf=z.infolist();names=[x.filename for x in inf]
        assert len(names)==len(set(names)),'ZIP_DUPLICATE_NAMES'
        assert z.testzip() is None,'ZIP_CRC_FAILURE'
        for row in inf:
            name=row.filename
            assert name.startswith(ROOT) and '\\' not in name and '..' not in PurePosixPath(name).parts and not name.startswith('/'),'ZIP_PATH_ESCAPE'
            assert ((row.external_attr>>16)&0o170000)!=0o120000,'SYMLINK_NOT_ALLOWED'
        man=ROOT+'MANIFEST_SHA256.txt'
        assert man in names,'MISSING_MANIFEST'
        m=manifest(z.read(man))
        others={n[len(ROOT):] for n in names if not n.endswith('/') and n!=man}
        assert set(m)==others,'ZIP_SET_MISMATCH'
        for name,h in m.items():assert sha(z.read(ROOT+name))==h,'ZIP_FILE_SHA_MISMATCH:'+name
        parent_rel='baseline/CRAFT-R46-I0016-EVIDENCE-VAULT-v01.zip'
        parent=z.read(ROOT+parent_rel)
        assert sha(parent)==R46_SHA,'R46_ORIGINAL_SHA_DRIFT'
        with zipfile.ZipFile(io.BytesIO(parent)) as old:
            assert old.testzip() is None,'PARENT_R46_CRC'
            old_manifest=manifest(old.read(R46_ROOT+'MANIFEST_SHA256.txt'))
            assert len(old_manifest)==103,'R46_EXPECTED_103_NOT_FOUND'
            for rel, h in old_manifest.items():
                assert sha(old.read(R46_ROOT+rel))==h,'R46_MEMBER_BAD:'+rel
                assert sha(z.read(ROOT+'baseline/'+R46_ROOT+rel))==h,'EXPANDED_R46_FILE_DRIFT:'+rel
            assert sha(z.read(ROOT+'baseline/'+R46_ROOT+'MANIFEST_SHA256.txt'))==sha(old.read(R46_ROOT+'MANIFEST_SHA256.txt')),'EXPANDED_R46_MANIFEST_DRIFT'
            for oldname,expected in [('baseline/CRAFT-R45-I0016-PLATAFORMA-EXPERIMENTAL-v01.zip',R45_SHA),
                                     ('baseline/CRAFT-R44-I0016-PILOTO-EXPERIMENTAL-v01.zip',R44_SHA)]:
                assert sha(old.read(R46_ROOT+oldname))==expected,'R46_HISTORICAL_ARCHIVE_DRIFT'
    return {'status':'PASS','zip_sha256':sha(Path(zpath).read_bytes()),
            'new_manifest_files':len(m),'r46_expanded_files_verified':103,
            'historical_r45_sha256':R45_SHA,'historical_r44_sha256':R44_SHA,
            'r46_parent_sha256':R46_SHA,'zip_crc':'PASS',
            'scope':'SOFTWARE_ARCHIVE_INTEGRITY_NOT_PHYSICAL_EVIDENCE'}

if __name__=='__main__':
    print(json.dumps(validate(sys.argv[1]),indent=2,sort_keys=True))
