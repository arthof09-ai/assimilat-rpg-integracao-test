"""Independent local ZIP integrity checks. NOT a canonical NAC-PASS certifier."""
import hashlib,io,os,sys,zipfile
from pathlib import PurePosixPath

ROOT_NAME='CRAFT-R45-SANDBOX-I0016'

def verify(path):
  archive=zipfile.ZipFile(path)
  names=archive.namelist()
  assert len(names)==len(set(names)), 'DUPLICATE_ZIP_MEMBERS'
  assert archive.testzip() is None, 'BAD_ZIP_CRC'
  prefix=ROOT_NAME+'/'
  for n in names:
    p=PurePosixPath(n)
    assert n.startswith(prefix) and not n.startswith('/') and '..' not in p.parts and '\\' not in n, 'ZIP_PATH_ESCAPE'
  m_name=prefix+'MANIFEST_SHA256.txt'
  assert m_name in names, 'MISSING_MANIFEST'
  manifest=archive.read(m_name).decode('utf8')
  entries={}
  for line in manifest.splitlines():
    if not line or line.startswith('#'):continue
    h,rel=line.split('  ',1)
    assert len(h)==64 and all(c in '0123456789abcdef' for c in h),'BAD_MANIFEST_HASH'
    assert rel not in entries,'DUPLICATED_MANIFEST_PATH'
    entries[rel]=h
  file_members={n[len(prefix):] for n in names if not n.endswith('/') and n!=m_name}
  assert set(entries)==file_members, f'MANIFEST_MEMBER_SET_DIFF missing={sorted(file_members-set(entries))} extra={sorted(set(entries)-file_members)}'
  for rel,h in entries.items():
    assert hashlib.sha256(archive.read(prefix+rel)).hexdigest()==h,'MEMBER_HASH_FAILED '+rel
  legacy_prefix=prefix+'r44_legacy/'
  r44_manifest=archive.read(legacy_prefix+'MANIFEST_SHA256.txt').decode('utf8')
  old_entries=0
  for line in r44_manifest.splitlines():
    if not line or line.startswith('#'):continue
    h,rel=line.split('  ',1)
    assert hashlib.sha256(archive.read(legacy_prefix+rel)).hexdigest()==h,'R44_LEGACY_MUTATED '+rel
    old_entries+=1
  assert old_entries==18,'R44_BASELINE_MANIFEST_DENOMINATOR'
  result={'status':'PASS','zip_sha256':hashlib.sha256(open(path,'rb').read()).hexdigest(),
          'manifest_member_count':len(entries),'r44_baseline_file_hashes_verified':old_entries,
          'crc':'PASS','archive_members':len(names),'scope':'SOFTWARE_INTEGRITY_NOT_CANONICAL'}
  return result

if __name__=='__main__':
 import json
 print(json.dumps(verify(sys.argv[1]),indent=2,ensure_ascii=False))
