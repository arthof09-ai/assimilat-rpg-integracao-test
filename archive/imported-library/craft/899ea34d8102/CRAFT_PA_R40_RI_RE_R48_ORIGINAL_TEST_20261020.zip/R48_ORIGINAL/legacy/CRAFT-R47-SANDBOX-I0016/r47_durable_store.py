"""Optional local disk checkpoint store for synthetic R47 journal.

This is NOT the Notion writer, C19 gateway or external authority. It uses Linux
flock solely to serialize processes sharing THIS sandbox filesystem. A checkpoint
published before its pointer becomes an UNKNOWN-EFFECT orphan: no blind retry.
"""
from __future__ import annotations
import contextlib,copy,fcntl,hashlib,json,os
from pathlib import Path
from r47_authenticity import AuthenticityVault,AuthError,digest

class LocalCrash(RuntimeError):pass


def filehash(b):return hashlib.sha256(b).hexdigest()

def persist_atomic(path:Path,raw:bytes):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.inflight')
    if tmp.exists():raise AuthError('PENDING_INFLIGHT_UNKNOWN_EFFECT')
    with open(tmp,'xb') as f:
        f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
    fd=os.open(str(path.parent),os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)

class R47DurableStore:
    def __init__(self,folder):
        self.root=Path(folder)
        self.commits=self.root/'commits'
        self.head_path=self.root/'CURRENT.json'
        self.lockfile=self.root/'LOCK'

    @contextlib.contextmanager
    def lock(self):
        self.root.mkdir(parents=True,exist_ok=True)
        with open(self.lockfile,'a+b') as f:
            fcntl.flock(f.fileno(),fcntl.LOCK_EX)
            try:yield
            finally:fcntl.flock(f.fileno(),fcntl.LOCK_UN)

    @staticmethod
    def _pointer(payload):
        return {**payload,'pointer_sha256':digest(payload)}

    def _publish(self,state):
        persist_atomic(self.head_path,(json.dumps(self._pointer(state),sort_keys=True,indent=2)+'\n').encode())

    def initialize(self,vault:AuthenticityVault):
        with self.lock():
            if self.head_path.exists() or (self.commits.exists() and list(self.commits.glob('*.json'))):
                raise AuthError('ALREADY_INITIALIZED_OR_UNKNOWN_DISK_STATE')
            if vault.events:raise AuthError('INITIALIZE_ONLY_EMPTY_EXPERIMENTAL_STORE')
            self.commits.mkdir(parents=True,exist_ok=True)
            name='000000-'+vault.head+'.json'
            snap=self.commits/name
            vault.snapshot(snap)
            with open(snap,'rb') as f:os.fsync(f.fileno())
            state={'schema':'R47-LOCAL-DURABLE-v1','policy_sha256':vault.trust.policy_sha256,
                   'known_commits':[name],'commit_digests':{name:filehash(snap.read_bytes())},'current':name,'head':vault.head,
                   'snapshot_file_sha256':filehash(snap.read_bytes()),'sequence':0}
            self._publish(state)
            return state

    def _recover_unlocked(self,expected_policy_sha256,expected_external_head=None):
        if not self.head_path.is_file():raise AuthError('NO_DURABLE_HEAD')
        ptr=json.loads(self.head_path.read_text())
        psha=ptr.pop('pointer_sha256',None)
        if psha!=digest(ptr):raise AuthError('HEAD_POINTER_CORRUPT')
        if ptr.get('schema')!='R47-LOCAL-DURABLE-v1' or ptr.get('policy_sha256')!=expected_policy_sha256:
            raise AuthError('HEAD_POLICY_OR_SCHEMA_CONFLICT')
        names=ptr.get('known_commits')
        if type(names) is not list or not names or len(set(names))!=len(names):raise AuthError('COMMIT_INDEX_INVALID')
        if ptr['current']!=names[-1] or ptr['sequence']!=len(names)-1:raise AuthError('COMMIT_INDEX_MISMATCH')
        if type(ptr.get('commit_digests')) is not dict or set(ptr['commit_digests'])!=set(names):
            raise AuthError('HISTORICAL_CHECKPOINT_HASH_INDEX_INVALID')
        disk={p.name for p in self.commits.glob('*.json')}
        unknown=disk-set(names)
        if unknown:
            raise AuthError('UNKNOWN_EFFECT_ORPHAN_CHECKPOINTS:'+','.join(sorted(unknown)))
        if not set(names)<=disk:raise AuthError('MISSING_HISTORICAL_COMMIT')
        for n in names:
            if Path(n).name!=n:raise AuthError('COMMIT_PATH_INVALID')
        current=self.commits/ptr['current']
        if current.is_symlink():raise AuthError('SYMLINK_CHECKPOINT_REFUSED')
        if filehash(current.read_bytes())!=ptr['snapshot_file_sha256']:
            raise AuthError('CURRENT_CHECKPOINT_BYTE_CORRUPT')
        for previous_name in names:
            old=self.commits/previous_name
            if old.is_symlink() or filehash(old.read_bytes())!=ptr['commit_digests'][previous_name]:
                raise AuthError('HISTORICAL_CHECKPOINT_BYTE_CORRUPT:'+previous_name)
        if expected_external_head is not None and expected_external_head!=ptr['head']:
            raise AuthError('EXTERNAL_HEAD_MISMATCH')
        vault=AuthenticityVault.restore(current,expected_policy_sha256,ptr['head'])
        return vault,ptr

    def recover(self,expected_policy_sha256,expected_external_head=None):
        with self.lock():return self._recover_unlocked(expected_policy_sha256,expected_external_head)

    def commit_batch(self,items,reviewed_at,expected_policy_sha256,inject=None,expected_external_head=None):
        with self.lock():
            vault,head=self._recover_unlocked(expected_policy_sha256,expected_external_head)
            old_count=len(vault.events)
            operation=vault.submit_batch(items,reviewed_at)
            if len(vault.events)==old_count:
                return {'idempotent_only':True,'receipt':operation,'disk_head':head['head'],'recovered':True}
            seq=head['sequence']+1
            name=f'{seq:06d}-{vault.head}.json'
            fname=self.commits/name
            if fname.exists():raise AuthError('COMMIT_NAME_COLLISION_UNKNOWN_EFFECT')
            vault.snapshot(fname)
            with open(fname,'rb') as f:os.fsync(f.fileno())
            if inject=='AFTER_CHECKPOINT_BEFORE_HEAD':
                raise LocalCrash('UNACKNOWLEDGED_ORPHAN_MUST_RECONCILE')
            next_state={'schema':'R47-LOCAL-DURABLE-v1','policy_sha256':head['policy_sha256'],
                        'known_commits':head['known_commits']+[name],
                        'commit_digests':{**head['commit_digests'],name:filehash(fname.read_bytes())},
                        'current':name,'head':vault.head,
                        'snapshot_file_sha256':filehash(fname.read_bytes()),'sequence':seq}
            self._publish(next_state)
            if inject=='AFTER_HEAD_BEFORE_ACK':
                raise LocalCrash('COMMITTED_BUT_ACK_LOST_RETRY_IDEMPOTENT')
            return {'idempotent_only':False,'receipt':operation,'disk_head':vault.head,
                    'snapshot_filename':name,'sequence':seq,'recovered':True}
