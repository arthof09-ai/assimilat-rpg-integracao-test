"""Sandbox-local durable filesystem behavior; NOT Notion or C19 fencing."""
import json,sys,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from r47_durable_store import R47DurableStore,LocalCrash
from r47_authenticity import AuthenticityVault,AuthError,digest
from r47_fixtures import recipes_and_sources,policy,make_pair,REVIEW

def setup(d):
    r,s=recipes_and_sources();v=AuthenticityVault(r,s,policy());store=R47DurableStore(Path(d)/'vault')
    state=store.initialize(v);return store,v.trust.policy_sha256,state

def item(n):
    r,a=make_pair(index=300000+n)
    return [{'report':r,'attestation':a}]

class TestR47Durable(unittest.TestCase):
    def test_initialize_and_recover(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            v,r=store.recover(pol)
            self.assertTrue(v.audit()['ok']);self.assertEqual(r['sequence'],0)
    def test_commit_and_recover(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            x=store.commit_batch(item(1),REVIEW,pol)
            v,pt=store.recover(pol,x['disk_head'])
            self.assertEqual(pt['sequence'],1);self.assertEqual(len(v.events),1)
            self.assertTrue(v.audit()['ok'])
    def test_idempotency_after_process_reopen(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d);x=store.commit_batch(item(2),REVIEW,pol)
            nextprocess=R47DurableStore(store.root)
            y=nextprocess.commit_batch(item(2),REVIEW,pol)
            self.assertTrue(y['idempotent_only']);self.assertEqual(y['disk_head'],x['disk_head'])
            self.assertEqual(len(nextprocess.recover(pol)[1]['known_commits']),2)
    def test_atomic_batch_and_recover(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            both=item(3)+item(4)
            x=store.commit_batch(both,REVIEW,pol)
            v,_=store.recover(pol)
            self.assertEqual(len(v.events),2);self.assertTrue(v.audit()['ok'])
    def test_crash_after_head_returns_idempotency(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            with self.assertRaisesRegex(LocalCrash,'COMMITTED_BUT_ACK_LOST'):
                store.commit_batch(item(5),REVIEW,pol,inject='AFTER_HEAD_BEFORE_ACK')
            vault,pt=store.recover(pol)
            self.assertEqual(len(vault.events),1)
            retry=store.commit_batch(item(5),REVIEW,pol)
            self.assertTrue(retry['idempotent_only']);self.assertEqual(pt['sequence'],1)
    def test_crash_before_head_is_unknown_effect(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            with self.assertRaisesRegex(LocalCrash,'UNACKNOWLEDGED_ORPHAN'):
                store.commit_batch(item(6),REVIEW,pol,inject='AFTER_CHECKPOINT_BEFORE_HEAD')
            with self.assertRaisesRegex(AuthError,'UNKNOWN_EFFECT_ORPHAN_CHECKPOINTS'):
                store.recover(pol)
            with self.assertRaisesRegex(AuthError,'UNKNOWN_EFFECT_ORPHAN_CHECKPOINTS'):
                store.commit_batch(item(6),REVIEW,pol)
    def test_stale_external_head_blocks_new_commit(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d);old=ptr['head']
            store.commit_batch(item(7),REVIEW,pol)
            with self.assertRaisesRegex(AuthError,'EXTERNAL_HEAD_MISMATCH'):
                store.commit_batch(item(8),REVIEW,pol,expected_external_head=old)
    def test_missing_historical_commit_detected(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d);store.commit_batch(item(9),REVIEW,pol)
            (store.commits/ptr['current']).unlink()
            with self.assertRaisesRegex(AuthError,'MISSING_HISTORICAL_COMMIT'):store.recover(pol)
    def test_snapshot_file_corruption_detected(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d);s=store.commit_batch(item(10),REVIEW,pol)
            current=store.commits/s['snapshot_filename']
            current.write_bytes(current.read_bytes()+b'attack')
            with self.assertRaisesRegex(AuthError,'CURRENT_CHECKPOINT_BYTE_CORRUPT'):store.recover(pol)
    def test_head_pointer_integrity_detected(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            o=json.loads(store.head_path.read_text());o['sequence']=99
            store.head_path.write_text(json.dumps(o))
            with self.assertRaisesRegex(AuthError,'HEAD_POINTER_CORRUPT'):store.recover(pol)
    def test_policy_mismatch_detected(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            with self.assertRaisesRegex(AuthError,'HEAD_POLICY_OR_SCHEMA_CONFLICT'):store.recover('FORGED_POLICY')
    def test_unauthorized_reinit_refused(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            r,s=recipes_and_sources();v=AuthenticityVault(r,s,policy())
            with self.assertRaisesRegex(AuthError,'ALREADY_INITIALIZED'):store.initialize(v)
    def test_no_external_production_connection(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d);x=store.commit_batch(item(11),REVIEW,pol)
            self.assertFalse(hasattr(store,'notion_writer'))
            self.assertEqual(x['receipt']['official_stock_effect'],0)

    def test_historical_checkpoint_hash_mutation_detected(self):
        with tempfile.TemporaryDirectory() as d:
            store,pol,ptr=setup(d)
            store.commit_batch(item(17),REVIEW,pol)
            store.commit_batch(item(18),REVIEW,pol)
            old=store.commits/ptr['current']
            old.write_bytes(old.read_bytes()+b'corrupt-historical-commit')
            with self.assertRaisesRegex(AuthError,'HISTORICAL_CHECKPOINT_BYTE_CORRUPT'):
                store.recover(pol)

if __name__=='__main__':unittest.main()
