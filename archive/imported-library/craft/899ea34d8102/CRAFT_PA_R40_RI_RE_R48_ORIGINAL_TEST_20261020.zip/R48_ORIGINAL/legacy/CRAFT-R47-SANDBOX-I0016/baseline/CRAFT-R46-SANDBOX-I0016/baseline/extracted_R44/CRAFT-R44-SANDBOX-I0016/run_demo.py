"""Deterministic synthetic demonstration with JSON receipts + crash-recovery proof."""
import copy
import hashlib
import json
from pathlib import Path
from experimental_engine import SandboxEngine,SimulatedCrash,load_recipes,simulation_cost,digest

ROOT=Path(__file__).resolve().parent
R=load_recipes(ROOT/'recipes')
F=json.loads((ROOT/'fixtures'/'demo.json').read_text(encoding='utf8'))
e=SandboxEngine(R,F['lots'])


def tli(aid,lot_id,qa=None, fault=None):
    return e.run('SBX-TLI-R44-v1',aid,[lot_id],copy.deepcopy(F['tli_good_measurements']) if qa is None else qa,
                 F['tli_tools'],F['tli_skills'],fault_stage=fault)

def mica(aid,qa=None):
    return e.run('SBX-MICA-R44-v1',aid,['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B'],
                 copy.deepcopy(F['mica_good_measurements']) if qa is None else qa,F['mica_tools'],F['mica_skills'])

receipts=[]
receipts.append(tli('SBX-DEMO-TLI-001','SBX-SLATE-GOOD-01'))
receipts.append(tli('SBX-DEMO-TLI-002','SBX-SLATE-TOO-SMALL'))
q=copy.deepcopy(F['tli_good_measurements']);q['length_mm']=122.3
receipts.append(tli('SBX-DEMO-TLI-003','SBX-SLATE-GOOD-01',q))
receipts.append(tli('SBX-DEMO-TLI-004','SBX-SLATE-GOOD-01')) # quantity=0
# Crash fault is executed on a separate valid-lot branch to avoid contaminating demo receipts.
branch=SandboxEngine(R,F['lots']);branch_before=digest(branch.state)
try:
    branch.run('SBX-TLI-R44-v1','SBX-DEMO-CRASH-01',['SBX-SLATE-GOOD-01'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'],'AFTER_CONSUME')
except SimulatedCrash: pass
crash_rollback_ok=(digest(branch.state)==branch_before)
branch_receipt=branch.run('SBX-TLI-R44-v1','SBX-DEMO-CRASH-01',['SBX-SLATE-GOOD-01'],F['tli_good_measurements'],F['tli_tools'],F['tli_skills'])
receipts.append(mica('SBX-DEMO-MICA-001'))
receipts.append(mica('SBX-DEMO-MICA-002')) # insufficient after consume
replayed=tli('SBX-DEMO-TLI-001','SBX-SLATE-GOOD-01')
assert replayed['idempotent_replay'] and crash_rollback_ok
assert e.audit()['ok']

snapshot_hash=e.export_snapshot(ROOT/'results'/'state_after.json')
resumed=SandboxEngine.restore(R, ROOT/'results'/'state_after.json')
recovery_ok=digest(resumed.state)==digest(e.state) and resumed.audit()['ok']
summary={
 'scope':'LOCAL_SANDBOX_NO_NOTION_WRITES_NO_OFFICIAL_RECORDS',
 'recipe_designs_experimental':len(R),'official_RC5_created':0,'official_products_created':0,
 'scenarios':[{ 'attempt_id':r['attempt_id'],'result':r['status'],
   'consumption':r['consumed'],'transformation_stages':r['transformation_stage_trace'],
   'products':r['products'],'reasons':r['rejection_reasons']} for r in receipts],
 'idempotent_replay_detected':replayed['idempotent_replay'],
 'injected_crash_before_commit_rolled_back':crash_rollback_ok,
 'retry_after_crash_succeeded':branch_receipt['status']=='EXPERIMENTAL_QA_PASS',
 'persistent_snapshot_restore_ok':recovery_ok,
 'ledger_audit':e.audit(),
 'snapshot_integrity_sha256':snapshot_hash,
 'geometric_design_only':R['SBX-TLI-R44-v1']['geometry_proposed'],
 'cost_tli_synthetic':simulation_cost(R['SBX-TLI-R44-v1'],F['mock_prices_ucs'],1),
 'cost_mica_synthetic':simulation_cost(R['SBX-MICA-R44-v1'],F['mock_prices_mica_ucs'],2),
 'canonical_source_receipts_from_notion':False,
 'synthetic_materials_are_not_available_in_campaign':True,
 'official_f5':'RED','fencing_c19':'NOT_DEMONSTRATED','ibx38':'NOVA_NO_ACK_AT_READBACK'
}
out=ROOT/'results'/'demo_receipts.json';out.write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps({'scenario_statuses':[(r['attempt_id'],r['status']) for r in receipts],
 'idempotent_replay':replayed['idempotent_replay'],
 'crash_rollback':crash_rollback_ok,'retry_after_crash':branch_receipt['status'],
 'restored':recovery_ok,'ledger':e.audit(),'snapshot_sha256':snapshot_hash,
 'cost_tli_mock':summary['cost_tli_synthetic'],'cost_mica_mock':summary['cost_mica_synthetic']},ensure_ascii=False,indent=2))
