# CRAFT R44 — Sandbox experimental do Executor 1 (CM-000002-I0016)

**CLASSIFICAÇÃO: MESTRE-SIDE / EXPERIMENTAL / NÃO CANÔNICO / ISOLADO.**

Este pacote demonstra **duas receitas experimentais** usando **insumos sintéticos representando recursos PS já documentados no Notion**, sem fabricar no mundo do jogo, reservar recursos de campanha, emitir REC-ID oficial, alterar REC-LIB, criar produtos do catálogo ou sincronizar informações à Party/O Primeiro.

- `SBX-TLI-R44-v1`: Tábua Lamelar de Inscrição (B30-01), 1 lâmina sintética de Ardósia de Geada Lamelar → 1 tábua sintética condicionada ao QA.
- `SBX-MICA-R44-v1`: Espaçador de Mica Calibrado (B30-03), 2 folhas sintéticas de Mica de Bruma Boreal → 2 espaçadores sintéticos condicionados ao QA.

**Importante:** o software é um **motor de transições e validação de consistência**, não uma máquina de física: os dados de inspeção (`qa_fixture`) são **dados sintéticos introduzidos na fixture**, e não medições realizadas. A lógica confirma que uma receita consumiu estoque *simulado*, rejeitou condições impróprias, criou saídas *simuladas*, impediu dupla execução e recuperou estado após crash; ela não comprova qualidade mineral real ou disponibilidade econômica.

## Reprodução offline (Python ≥ 3.10, biblioteca padrão)

Execute no diretório que contém este README:

```bash
python -m unittest discover -s tests -v
python run_demo.py
python stress_replay.py
```

Os resultados de referência estão em `results/test_suite.log`, `results/demo_receipts.json`, `results/demo_stdout.log`, `results/state_after.json`, `results/stress_summary.json`, `results/stress_stdout.log` e `results/stress_snapshot.json`. Após executar novamente, snapshots/receipts são sobrescritos **apenas nesta cópia experimental**, nunca no Notion.

## Organização

| Arquivo | Finalidade |
|---|---|
| `experimental_engine.py` | Motor transacional in-memory; consumo, transformação, QA, refugo, recuperação, journal com hash e idempotência |
| `recipes/tli.json` | Especificação executável de Tábua Lamelar, tolerâncias e fonte PS |
| `recipes/mica.json` | Segunda receita no mesmo motor, para aferir reutilização |
| `fixtures/demo.json` | Lotes, medições e preços **sintéticos**; jamais prova de estoque real |
| `run_demo.py` | Seis exemplos e comprovações de replay/rollback/restauração |
| `stress_replay.py` | 600 tentativas determinísticas com seed `440016` e verificação de invariantes |
| `tests/test_engine.py` | 52 testes automatizados com casos normais, negativos e recuperação |
| `R44_RELATORIO_E_RECEITAS.md` | Relatório completo, BOM, tempos, perdas, custos, diferenciação, testes e pendências |
| `MANIFEST_SHA256.txt` | Hashes de arquivos antes do empacotamento (exclui o próprio manifesto) |

## Segurança e separações

O motor não importa bibliotecas de Notion/HTTP, não acessa a rede e não envia dados a aplicativos. Os identificadores de saídas começam com `SBX-CRAFT-R44-I0016`, `official_rec_id=null` e `official_product_id=null`; mecânica mágica `0`. Os lotes exigem `fixture_kind=SYNTHETIC` e IDs `SBX-*`. Apenas arquivos locais são gravados, em `results/` para checkpoints. Se a pasta deste experimento for descartada, nada na campanha se altera.

O domínio de writer CRAFT/F5 continua independente e **RED**; C19-021 permanece UNKNOWN-EFFECT; IBX-38 continua dependente de resposta técnica real do Coordenador. O R44 não equivale a REC-LIB/RC5 e não satisfaz NAC-PASS de materialização.

## Integridade

O motor grava histórico em cadeia de SHA-256, recompõe inventário/produtos/refugos a partir dos eventos e verifica estado a cada chamada. Checkpoints persistidos contêm um `integrity_sha256`; restauração recusa alteração de receita, manifesto inválido e divergência de replay. A gravação usa arquivo temporário e rename local. Esses controles fornecem consistência **dentro do sandbox**, não fencing de outro chat nem prova física do RPG.

## Fontes Mestre-side consultadas, somente leitura

- Dossiê de engenharia: [AUD-CRAFT-F5-REMAP-01](https://app.notion.com/p/3f3c2b324ede81c99367e2de46077cbb), B30-01 / B30-03 e `PRE-REC-CRAFT-R42-TLI-METROLOGY-001`.
- [Ardósia de Geada Lamelar](https://app.notion.com/p/3f3c2b324ede81acaf28c66a6b46e0b2) — PS / semicanônica / sem lote real certificado.
- [Mica de Bruma Boreal](https://app.notion.com/p/3f3c2b324ede81e1b179e194e2838c84) — PS / semicanônica / espessura funcional pendente.
- Controle [OP-ARQ-RIN-REC-01](https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516), [IBX-38](https://app.notion.com/p/3f3c2b324ede817fb888ca32aacaf2de) e [REC-LIB-01](https://app.notion.com/p/3f1c2b324ede81e2901adb9ae10b2702).

## Estado da entrega

**Modelos experimentais executáveis=2/2; RC5 oficiais=0; produtos oficiais=0; fichas RC5=0/30; material F5=RED.** Os testes sintéticos internos não elevam prontidão PRE-Q1/PRE-Q2 nem transformam estoque da fixture em loot ou mercadoria real.
