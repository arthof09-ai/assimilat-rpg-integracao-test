# R47 — Modelo de ameaças e confiança (MESTRE-SIDE)

**Ameaça A: SHA correto de documento falso.** Um adversário consegue criar bytes e seus hashes coerentes. R47 exige vínculo exato dos bytes R46 com amostra+instrumento+leitura e assinatura do relatório. Mesmo isso só prova chave possuída, não autoria legitimamente atribuída ao mundo.

**Ameaça B: emissor autodeclarado.** Certificado com `issuer_root_id` não implica autoridade. R47 verifica a assinatura contra **raiz PINNED pelo operador da política**, nunca raiz apresentada no laudo. Em R47, todas as raízes funcionais são FIXTURES; `externally_vetted=True` é recusado como flag autossuficiente. Uma raiz real exige onboarding por sistema independente ainda inexistente.

**Ameaça C: certificado assinado mas fora do escopo.** Requer papel, PS, instrumento, período tanto da leitura quanto da revisão, período do evento de custódia e lista de revogação local. Falta sincronização com listas de revogação reais / cadeia pública, NÃO suprir com ficção.

**Ameaça D: custódia disfarçada.** Handoff requer confirmação assinada por quem recebeu. `sample_id`, `from_actor`, `to_actor`, `instrument_id`, hash dos bytes e tempos precisam concordar; cadeia de eventos é hash-linked e assinada. Não impede conluio entre detentores das chaves sintéticas nem prova que a amostra física existiu.

**Ameaça E: documento antigo válido usado como medição nova.** Evita reuso de report_id (conflito), reading_ids por R46, custody_event_ids e estado temporal na cadeia. Relógios dos atores **não têm timestamp externo confiável**; relatar a lacuna.

**Ameaça F: journal e snapshots modificados.** R46+R47 auditam hashes e decisões replayadas, com hashes de política e HEAD fornecidos fora do snapshot; rejeitam versões antigas quando há HEAD externo conhecido. Um adversário que controla todas as âncoras e a máquina pode fabricar nova cadeia: exigiria âncora imutável externa, NÃO implementada.

**Ameaça G: falha intermediária/disputa de escritores.** No R47, o stage em memória é atômico e `fcntl` evita disputa entre processos cooperantes num mesmo diretório. Checkpoint gravado mas ponteiro não publicado = UNKNOWN_EFFECT e bloqueio de retry. Não existe write-fencing na API do Notion, nem lease/epoch C19 válido. O mecanismo local NÃO serve como prova de exclusividade CRAFT/F5.

**Ameaça H: conhecimento do próprio teste.** Chaves privadas das fixtures são geradas de sementes deliberadamente publicadas no código para reproduzibilidade. Elas são inerentemente inseguras para identidade real. Descartar quaisquer `signed=True` de teste como evidência física seria violação de governança.

**Resultado:** o sistema distingue integridade, autorização local de teste e aptidão à revisão; não atesta autenticidade do mundo sem confiança externa legítima. `F5 RED / RC5 0/30 / material NAC-PASS HOLD` são invariantes de escopo.
