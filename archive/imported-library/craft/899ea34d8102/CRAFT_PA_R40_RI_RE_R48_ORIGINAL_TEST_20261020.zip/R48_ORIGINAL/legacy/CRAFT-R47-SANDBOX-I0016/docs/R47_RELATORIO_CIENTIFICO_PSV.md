# PSV — CRAFT R47 | CM-000002-I0016 | OP-ARQ-RIN-REC-01

## 1. Contrato, contexto, recuperação

Ordem Mestre R47: **autenticidade independente de laudos e cadeia de custódia**, preservando R01–R46, sem materialização F5. Reaproveita o motor R46 a partir do ZIP de origem `CRAFT-R46-I0016-EVIDENCE-VAULT-v01.zip` SHA-256 `966e137b5092b419e8a94804c97711d36ba0f119a96ba212cf53d0a1953b25f4`.

No preflight recuperado em diretório limpo: ZIP R46 SHA/CRC PASS; **103/103** membros rastreados, R45 **50/50**, R44 **18/18**; regressões R44 **52/52**, R45 **64/64**, R46 **70/70**. Nenhum arquivo dos motores originais foi sobrescrito.

**ANTES registrado:** `CP-CRAFT-I0016-R47-ANTES-001` como comentário no mesmo thread da OP original. Fonte/IBX38: `NOVA`, `Lida por INSTANCE-ID` vazia. Não houve STOP-ACK do writer C19 nem prova de fencing externo. R44 DEPOIS permanece comentário, não seção do corpo OP.

## 2. Quatro camadas epistemológicas

| Camada | O que foi implementado | O que NÃO prova |
|---|---|---|
| Integridade de bytes | SHA-256 e correspondência entre conteúdo dos anexos, amostra, leitura e recurso PS por R46 | autoria, autenticidade no mundo, data legítima |
| Assinatura | Ed25519 de documento, calibração, coleta, handoff, aceite e medição, verificadas com certificado | identidade real do portador da chave; laboratório real |
| Autorização | papéis OPERATOR/CALIBRATOR/CUSTODIAN, origem PS, instrumento, validade, revogação, raiz PINNED por política local | autoridade real não verificada; raízes FIXTURE_SIMULATED |
| Validade científica | R46 reaproveitado: instrumento, dimensionalidade, janela de calibração, incerteza, guard-band e métodos propostos | medição física, rastreabilidade metrológica externa, potência estatística, integração material |

Os dados de demonstração utilizam chaves **publicamente derivadas apenas para teste**, emissores, amostras e certificados rotulados `SBX`. Assim, uma assinatura válida só é considerada `SIMULATED_CRYPTO_VALID_NOT_REAL`; não existe retorno `PHYSICALLY_VERIFIED` ou `MATERIALIZED` nesta plataforma.

## 3. Cadeia de custódia transacional

1. `COLLECTED` — amostra e custódia original assinada.
2. `TRANSFERRED` — entrega assinada pelo detentor anterior.
3. `RECEIVED` — confirmação assinada pelo destinatário (sem aceitar transferência silenciosa).
4. `MEASURED` — operador atual assina amostra, instrumento, bytes da medição e timestamp.

Exige: `sample_id` igual em todas as etapas; sequência e tempos crescentes; `previous_hash` assinando o elo anterior; ator do evento autorizado por certificado de custodiante; assinatura válida; medição feita pelo detentor atual; instrumento e documento iguais aos anexos R46. Rejeita substituição de documentos, eventos ausentes, dupla utilização de IDs, assinatura inválida e transferência sem recebimento.

## 4. Resultados FUNCIONAIS reproduzidos (somente software)

- R47 unitários: **87/87**. Cenários: assinaturas adulteradas, cert vencido/revogado, emissor fora do papel ou PS, calibração e amostra divergentes, custódia incompleta, replays idempotentes, colisões, processo concorrente, snapshots adulterados, rollback de stage e restauração com hash externo.
- Demonstração: **9 laudos sintéticos**, **4** verificações de cripto de fixture (SEM legitimidade física), **5** quarentenas; lote com **2** documentos admitidos atomicamente, lote de **2** revertido após falha simulada, **1** replay sem novo registro; journal **11** eventos. Snapshot restaurado com heads R46/R47 iguais.
- Stress sem aleatoriedade externa, seed 470016: **120** tentativas, **111** eventos novos (81 classificações sintéticas, 30 quarentenas), **10** abortos com rollback, **9** replays idempotentes, **10** lotes de 2; invariantes finais e auditoria R46+R47 PASS.
- Mutação seed 470047: **260/260** laudos alterados em quarentena, **0** aprovações materiais, **0** crashes não tratados.
- Concorrência entre processos: **4** processos cooperantes usando um mesmo filesystem; **4** commits serializados localmente, mais **1** commit sem ACK que foi readback/retry idempotente. Teste separado gerou um checkpoint órfão antes do HEAD: resultou em `UNKNOWN_EFFECT` com bloqueio de retry cego.
- Comparadores das duas receitas: 5 pares sintéticos TLI/gabarito comum e 5 pares sintéticos Mica/calço comum; resultado de ambas as análises **`SYNTHETIC_TRADEOFF_NO_GLOBAL_WINNER`**, com controles de condição, amostra, custo UCS_SIM, precisão, durabilidade e incerteza. Comprovação independente: resultado JSON recalculado é byte-semanticamente igual ao R46 preservado; **nenhuma superioridade empírica certificada**.

## 5. Gates, riscos e estado antes/depois

**ANTES:** 2/2 receitas sintéticas; motor R46 preservado, QA documentário local; validação criptográfica/autorização real ainda inexistente; F5 RED, RC5 0/30.

**DEPOIS de software:** camada R47 acrescentada; certificados e cadeia assinada com raiz *fixture*, rastreabilidade por hashes, journal, transações e checkpoints locais. Baselines preservados. **Medições reais verificadas = 0; certificados externos verificados = 0; produtos/receitas oficiais criados = 0; estoques oficiais consumidos = 0.**

**NAC-CONT-03 / REPA:** preflight/registro ANTES → execução isolada → regressões/testes/stress → snapshot/auditoria/replay → pacote SHA/CRC/manifest → readback de Notion protegido → registro DEPOIS e readback. **NAC-PASS do artefato software** depende apenas de evidência de testes; **NAC-PASS MATERIAL=HOLD** sem fencing C19 e medição física legítima.

**IBX-38:** propriedade NOVA sem ACK na última reabertura; competência do Coordenador Geral. **C19-021:** efeito material desconhecido. Não foram pedidos novamente YIELD/fencing, nem tomado writer ou criado REC-ID.

## 6. Fronteira objetiva R48 e aceitação futura

Próximo avanço seguro **R48**: adaptador para **prova externa de admissão de autoridades**, com checagem de certificado/cadeia reconhecida, evidência de revogação emitida por fonte distinta, timestamp independente e retenção imutável verificável fora do mesmo filesystem; testar honestamente a impossibilidade de autenticação externa quando essas evidências não existirem. Sem elas, continuar `QUARANTINE_UNVETTED_ANCHOR`. Nunca migrar chaves fixas de teste a produção. Integrar medição real somente após amostra, laudo, operador, calibração e custódia serem fisicamente rastreáveis e auditados por entidade independente; materializar RC5 apenas após prova autônoma de fencing C19, reconciliação C19-021 e gates F5.

**Ponto exato:** validar o hash do ZIP R47 e o manifesto, rodar as 186 regressões históricas e os 87 testes novos em pasta limpa; confirmar cabeças e hash externo do trust policy; executar somente o novo adaptador em sandbox, preservando R44–R47 sem reconstruí-los.
