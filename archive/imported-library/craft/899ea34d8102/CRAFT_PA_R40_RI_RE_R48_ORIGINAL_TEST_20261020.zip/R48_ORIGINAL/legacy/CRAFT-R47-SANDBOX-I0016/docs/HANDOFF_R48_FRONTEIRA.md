# Ponto exato R48 — sem reiniciar R44–R47

- Recuperar ZIP R47 (SHA conforme manifesto/recibo terminal) e comparar byte a byte o ZIP R46 **966e137b5092b419e8a94804c97711d36ba0f119a96ba212cf53d0a1953b25f4**, integridade 103/103; R45 50/50 e R44 18/18.
- Conservar 52 regressões R44, 64 R45, 70 R46 e 87 testes R47; corpus de mutações 260 e stress 120, sem renomear REC-ID nem terceira receita.
- Retomar do `r47_authenticity.TrustGate` e `r47_durable_store.R47DurableStore`; avançar SOMENTE para protótipo de **admissão real verificável de trust roots** e timestamp/revogação independentes. Hoje não há conector de autoridade e `externally_vetted=True` é intencionalmente rejeitado.
- Próximo teste: laudo com bytes coerentes e assinatura falsificada deve ser quarantined; laudo de emissor real sem atestado independente permanece quarantined; ausência de resposta externa não autoriza liberação.
- Condição de bloqueio permanente: IBX38+C19 sem fencing; C19-021 UNKNOWN; F5 RED; RC5 0/30; 0 medições reais; material NAC-PASS HOLD; Party/O Primeiro 0 write. Notion só por superfície existente e gates corretos.
