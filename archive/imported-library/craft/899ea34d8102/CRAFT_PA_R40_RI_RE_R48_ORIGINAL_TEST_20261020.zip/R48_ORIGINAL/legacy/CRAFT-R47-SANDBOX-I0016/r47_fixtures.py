"""ALL signing seeds and certificates in this module are PUBLIC, FICTIONAL fixtures.
Not a CA, lab, instrument, calibrated sample or verified real-world authority.
Do not reuse keys for any real signature. Deterministic for replay ONLY.
"""
from __future__ import annotations
import base64,copy,hashlib,sys
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from r47_authenticity import digest,canonical,NAMESPACE,GENESIS
HERE=Path(__file__).resolve().parent
R46=HERE/'baseline/CRAFT-R46-SANDBOX-I0016'
sys.path.insert(0,str(R46))
from r46_fixtures import make_report,recipes_and_sources,REVIEW
ROOT_ID='SBX-R47-PUBLIC-FAKE-ROOT'
SOURCE_PAGES=['3f3c2b32-4ede-81ac-af28-c66a6b46e0b2','3f3c2b32-4ede-81e1-b179-e194e2838c84']
TIME_ROOT_FROM='2026-01-01T00:00:00+00:00'
TIME_ROOT_TO='2027-01-01T00:00:00+00:00'
TIME_CERT_FROM='2026-10-08T00:00:00+00:00'
TIME_CERT_TO='2026-10-10T23:59:59+00:00'
SUBJECTS={'operator':'SBX-FIXTURE-OP-01','calibrator':'SBX-FAKE-CALIBRATOR-01',
          'custodian_origin':'SBX-FAKE-HOLDER-ORIGIN','custodian_receiver':'SBX-FIXTURE-OP-01'}

def private(role):
    seed=hashlib.sha256(('PUBLIC_INSECURE_EXAMPLE_ONLY_CRAFT_R47_'+role).encode()).digest()
    return Ed25519PrivateKey.from_private_bytes(seed)

def public_b64(role):
    return base64.b64encode(private(role).public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)).decode('ascii')

def sign(role,body):
    return base64.b64encode(private(role).sign(canonical(body).encode('utf8'))).decode('ascii')

def policy(mode='FIXTURE_SIMULATED'):
    return {'schema':'R47-TRUST-POLICY-v1','roots':{
        ROOT_ID:{'public_key_b64':public_b64('root'),'fixture_only':True,
                 'allowed_roles':['OPERATOR','CALIBRATOR','CUSTODIAN'],
                 'not_before':TIME_ROOT_FROM,'not_after':TIME_ROOT_TO}},
            'revocations':{},'policy_mode':mode,'externally_vetted':False}

def _certificate(role,subject,inst,source,until=None,serial=None):
    b={'schema':'R47-CERT-v1','serial':serial or 'SBX-R47-CERT-'+role.upper(),
       'subject_id':subject,'public_key_b64':public_b64(role),'issuer_root_id':ROOT_ID,
       'roles':['OPERATOR' if role=='operator' else 'CALIBRATOR' if role=='calibrator' else 'CUSTODIAN'],
       'source_page_ids':[source], 'instrument_ids':[inst],
       'not_before':TIME_CERT_FROM,'not_after':until or TIME_CERT_TO}
    return {'body':b,'signature_b64':sign('root',b)}

def make_pair(key='SBX-TLI-R44-v1',index=1,kind='SYNTHETIC'):
    rid=f'SBX-R47-LAUDO-{index:05d}'
    report=make_report(key=key,id=rid,kind=kind)
    return report,make_attestation(report)

def make_attestation(report):
    inst=report['instrument'];iid=inst['instrument_id'];source=report['source_page_id']
    operator=report['operator']['operator_id'];sample=report['sample_id'];rid=report['report_id']
    if operator=='CLAIM-OPERATOR-01':
        subject_operator='CLAIM-OPERATOR-01'
    else:subject_operator=operator
    certs={
      'operator':_certificate('operator',subject_operator,iid,source),
      'calibrator':_certificate('calibrator',SUBJECTS['calibrator'],iid,source),
      'custodian_origin':_certificate('origin',SUBJECTS['custodian_origin'],iid,source),
      'custodian_receiver':_certificate('receiver',subject_operator,iid,source)}
    cb={'schema':'R47-CALIBRATION-v1','instrument_id':iid,'instrument_serial':inst['serial'],
        'calibration_id':inst['calibration_id'],'calibration_artifact_sha256':inst['certificate_sha256'],
        'calibration_start':inst['calibration_start'],'calibration_expires':inst['calibration_expires'],
        'signed_at':'2026-10-08T01:00:00+00:00','calibrator_id':SUBJECTS['calibrator']}
    mb={'schema':'R47-REPORT-SIGNATURE-v1','report_id':rid,'report_sha256':digest(report),
        'measurement_sha256':report['artifacts']['measurement']['claimed_sha256'],
        'sample_id':sample,'instrument_id':iid,'operator_id':operator,
        'source_page_id':source,'signed_at':'2026-10-09T11:45:30+00:00'}
    ev=[];prev='R47-CUSTODY-GENESIS:'+sample
    base=[('COLLECTED','NONE',SUBJECTS['custodian_origin'],'2026-10-09T11:40:00+00:00','origin'),
          ('TRANSFERRED',SUBJECTS['custodian_origin'],subject_operator,'2026-10-09T11:41:00+00:00','origin'),
          ('RECEIVED',subject_operator,subject_operator,'2026-10-09T11:42:00+00:00','receiver'),
          ('MEASURED',subject_operator,subject_operator,report['observed_at'],'receiver')]
    for seq,(act,f,t,when,role) in enumerate(base,1):
        e={'schema':'R47-CUSTODY-v1','seq':seq,'event_id':f'SBX-R47-{rid}-EV-{seq}',
           'sample_id':sample,'at':when,'kind':act,'from_actor':f,'to_actor':t,
           'instrument_id':iid if act=='MEASURED' else None,
           'measurement_sha256':report['artifacts']['measurement']['claimed_sha256'] if act=='MEASURED' else None,
           'previous_hash':prev,'signer_id':SUBJECTS['custodian_origin'] if role=='origin' else subject_operator}
        item={'body':e,'signature_b64':sign(role,e)};ev.append(item);prev=digest(item)
    return {'schema':'R47-AUTHENTICITY-v1','report_id':rid,'certificates':certs,
            'calibration_proof':{'body':cb,'signature_b64':sign('calibrator',cb)},
            'report_proof':{'body':mb,'signature_b64':sign('operator',mb)},'custody_events':ev}

if __name__=='__main__':
    print('FIXTURE ONLY; keys deliberately deterministic/public and unusable as real-world trust evidence')
