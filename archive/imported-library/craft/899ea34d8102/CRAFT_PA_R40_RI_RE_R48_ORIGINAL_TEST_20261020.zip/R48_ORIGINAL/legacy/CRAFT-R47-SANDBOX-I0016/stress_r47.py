"""Deterministic local concurrency/rollback/invalid envelope stress, 0 real claims."""
from __future__ import annotations
import copy,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from r47_fixtures import make_pair,recipes_and_sources,policy,REVIEW,sign
from r47_authenticity import AuthenticityVault,InjectedFailure,AuthError

SEED=470016
rng=random.Random(SEED)
recipes,sources=recipes_and_sources();v=AuthenticityVault(recipes,sources,policy())
counts={'FIXTURE_CRYPTO_PASS_NOT_REAL':0,'AUTH_QUARANTINE':0,'ROLLBACK':0,'IDEMPOTENT_REPLAY':0,'BATCH_COMMITS':0}
saved=[];iterations=120
for i in range(iterations):
    case=i%12
    if case==0 and saved:
        r,a=saved[rng.randrange(len(saved))]
        prev=len(v.events)
        receipt=v.submit(copy.deepcopy(r),copy.deepcopy(a),REVIEW)
        assert receipt['idempotent_replay'] and len(v.events)==prev
        counts['IDEMPOTENT_REPLAY']+=1
        continue
    if case==1:
        rs=[]
        for m in range(2):
            report,att=make_pair(index=120000+i*2+m)
            rs.append({'report':report,'attestation':att})
        old=(v.head,v.parent.head,len(v.events))
        try:v.submit_batch(rs,REVIEW,inject='MID_BATCH_ABORT');raise AssertionError('NO_ABORT')
        except InjectedFailure:pass
        assert old==(v.head,v.parent.head,len(v.events))
        counts['ROLLBACK']+=1
        continue
    if case==2:
        rs=[]
        for m in range(2):
            report,att=make_pair(index=140000+i*2+m,key='SBX-MICA-R44-v1' if m else 'SBX-TLI-R44-v1')
            rs.append({'report':report,'attestation':att})
        result=v.submit_batch(rs,REVIEW)
        assert result['batch_count']==2
        counts['FIXTURE_CRYPTO_PASS_NOT_REAL']+=2;counts['BATCH_COMMITS']+=1
        saved.extend((row['report'],row['attestation']) for row in rs)
        continue
    r,a=make_pair(index=100000+i,key='SBX-MICA-R44-v1' if i%2 else 'SBX-TLI-R44-v1',
                  kind='MEASURED_CLAIM_UNVERIFIED' if i%13==0 else 'SYNTHETIC')
    if case in (3,4,5):
        if case==3:a['report_proof']['signature_b64']='%%%INVALID%'
        if case==4:a['calibration_proof']['signature_b64']=sign('origin',a['calibration_proof']['body'])
        if case==5:a['custody_events'][0]['signature_b64']='FAILED'
    rec=v.submit(r,a,REVIEW)
    assert rec['official_rec_id'] is None and rec['stock_effect']==0 and not rec['physically_verified']
    if case in (3,4,5):
        assert rec['status']=='QUARANTINE_AUTHENTICITY',rec['status']
        counts['AUTH_QUARANTINE']+=1
    else:
        assert rec['status']=='SIMULATED_CRYPTO_VALID_NOT_REAL',rec['status']
        counts['FIXTURE_CRYPTO_PASS_NOT_REAL']+=1;saved.append((r,a))
    if i%20==0:assert v.audit()['ok']
assert v.audit()['ok']
snap_hash=v.snapshot(ROOT/'results/r47_stress_snapshot.json')
restored=AuthenticityVault.restore(ROOT/'results/r47_stress_snapshot.json',v.trust.policy_sha256,v.head)
assert restored.audit()==v.audit()
summary={'schema':'R47-STRESS-SYNTHETIC-v1','seed':SEED,'iterations':iterations,'counts':counts,
         'journal_events':len(v.events),'r46_events':len(v.parent.events),'r47_head':v.head,
         'r46_head':v.parent.head,'snapshot_sha256':snap_hash,'full_replay_ok':True,
         'physical_verified':0,'official_rc5':0,'stock_effect':0,'material_promotion':False,
         'cross_process_exclusivity_proven':False}
(ROOT/'results/r47_stress_summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
