"""CRAFT R48 reproducible end-to-end factory showcase (NO Notion, all fixtures)."""
from __future__ import annotations
import copy,json
from pathlib import Path
from r48_factory import IntegratedFactory,FactoryCrash,digest
from r48_fixtures import lots,pair,order,REVIEW
from r48_dryrun import all_dossiers
from r47_fixtures import sign
ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'
RESULTS.mkdir(parents=True,exist_ok=True)

def dump(name,obj):
    f=RESULTS/name
    f.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')

# Full integrated production in a single shared synthetic ledger.
f=IntegratedFactory.fixture_factory(lots())
before=f.quantities
AandB=pair(index=48001)
request={'batch_id':'SBX-R48-BATCH-AB-0001','orders':AandB,'reviewed_at':REVIEW}
receipt=f.process_batch(**request)
assert receipt['status']=='ALL_SYNTHETIC_QA_PASS'
assert [x['status'] for x in receipt['orders']]==['EXPERIMENTAL_QA_PASS','EXPERIMENTAL_QA_PASS']
assert sum(p['units'] for x in receipt['orders'] for p in x['products'])==3
assert receipt['experimental_product_count']==2
assert receipt['stock_before']==before
stock_after_pair=f.quantities
assert stock_after_pair['SBX-SLATE-GOOD-01']==1
assert stock_after_pair['SBX-MICA-GOOD-A']==0 and stock_after_pair['SBX-MICA-GOOD-B']==0
head_before_replay=f.head
retry=f.process_batch(**request)
assert retry['idempotent_replay'] and f.head==head_before_replay and f.quantities==stock_after_pair

# Genuinely new request with no available mica must not invent more.
missing_mica=f.process_batch('SBX-R48-BATCH-MICA-INSUFFICIENT',[order('mica',48003)],REVIEW)
assert missing_mica['orders'][0]['status']=='REJECTED_PRECHECK'
assert not missing_mica['orders'][0]['consumed'] and not missing_mica['orders'][0]['products']
assert f.quantities==stock_after_pair

# Signed report tamper: R47 quarantine happens BEFORE R44 inventory reserve.
bad=order('tli',48004)
bad['attestation']['report_proof']['signature_b64']=sign('calibrator',bad['attestation']['report_proof']['body'])
head_prev=f.head
quarantine=f.process_batch('SBX-R48-BATCH-SIGNED-BUT-INVALID',[bad],REVIEW)
assert quarantine['orders'][0]['status']=='QUARANTINE_EVIDENCE'
assert f.quantities==stock_after_pair
assert f.head!=head_prev

# Whole-batch rollback without any invented side effect, then safe retry.
fault=IntegratedFactory.fixture_factory(lots())
fault_orders=pair(index=48010)
fault_initial=fault.quantities
try:
    fault.process_batch('SBX-R48-BATCH-ROLLBACK',fault_orders,REVIEW,'AFTER_FIRST_ORDER_STAGED')
    raise AssertionError('FAULT_WAS_NOT_INJECTED')
except FactoryCrash:pass
assert fault.quantities==fault_initial and not fault.journal
assert not fault.vault.events and not fault.core.state['events']
fault_retry=fault.process_batch('SBX-R48-BATCH-ROLLBACK',fault_orders,REVIEW)
assert fault_retry['experimental_product_count']==2 and fault.audit()['ok']

snap=f.snapshot()
restored=IntegratedFactory.restore(copy.deepcopy(snap),f.head)
assert restored.audit()['ok'] and restored.quantities==f.quantities

readiness=all_dossiers(f.recipes)
assert readiness['official_RC5']==0 and readiness['ready_for_official_write']==0
assert {x['design_id'] for x in readiness['dossiers']}=={'B30-01','B30-03'}

dump('r48_batch_request_AB.json',request)
dump('r48_batch_receipt_AB.json',receipt)
dump('r48_rejections.json',{'insufficient_mica':missing_mica,'invalid_signature':quarantine})
dump('r48_inventory_snapshot.json',snap)
dump('r48_rc5_dryrun.json',readiness)
summary={'schema':'CRAFT-R48-DEMO-v1','fixture_only':True,
    'baseline_recipe_models':2,'new_recipes':0,'rc5_official':0,
    'comparison_r47_r48':{
        'r47':'R44 single recipe simulation + R47 evidence batches, no unified manufacturing orderbook/stock across requests',
        'r48':'multiorder batch A+B, one shared inventory, preflight+reserve, R44 transform+QA, R47 gate, product, receipt, persisted rollback'},
    'batch_id':receipt['batch_id'],'batch_status':receipt['status'],
    'orders':[{'order_id':x['order_id'],'recipe_key':x['recipe_key'],'status':x['status'],
              'ps_source_page_id':x['source_ps_page_id'],
              'consumed':x['consumed'],'products':x['products'],
              'qa_mode':'SYNTHETIC','evidence_status':x['authenticity']['status'],
              'processing_steps':x['process_trace'],
              'official_rec_id':x['official_rec_id']} for x in receipt['orders']],
    'raw_output_records':receipt['experimental_product_count'],
    'output_synthetic_units':sum(p['units'] for x in receipt['orders'] for p in x['products']),
    'stock_before':before,'stock_after':stock_after_pair,
    'idempotent_retry_no_additional_event':True,
    'insufficient_mica_status':missing_mica['orders'][0]['status'],
    'invalid_signature_status':quarantine['orders'][0]['status'],
    'interruption_before_commit_rollback':True,
    'retry_after_rollback_successful':True,
    'journal_audit':f.audit(),'restored_head':restored.head,
    'RC5_readiness':[{'design_id':x['design_id'],'rc5_status':x['rc5_status'],
                      'open_dependencies':len(x['open_gates'])} for x in readiness['dossiers']],
    'any_physical_fabrication':False,'any_real_inventory':False,'any_party_item':False,
    'C19':'NOT_FENCED','F5':'RED','NAC_PASS_MATERIAL':'HOLD'}
dump('r48_demo_summary.json',summary)
print(json.dumps({'status':'PASS','orders':len(receipt['orders']),
                  'product_records':receipt['experimental_product_count'],
                  'synthetic_piece_units':summary['output_synthetic_units'],
                  'stock_before':before,'stock_after':stock_after_pair,
                  'insufficient_mica':summary['insufficient_mica_status'],
                  'invalid_signature':summary['invalid_signature_status'],
                  'rollback':True,'audit':f.audit()['ok'],'official_rc5':0},
                 indent=2,sort_keys=True,ensure_ascii=False))
