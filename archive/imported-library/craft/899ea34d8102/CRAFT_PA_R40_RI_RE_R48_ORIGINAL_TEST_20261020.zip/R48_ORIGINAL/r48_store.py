"""R48 local-only transaction store, reusing R47 flock and fsync/atomic writer.
Not a Notion lease, writer, C19 fencing mechanism or production state.
"""
from __future__ import annotations
import json
from pathlib import Path
from r48_factory import IntegratedFactory, FactoryError, FactoryCrash, digest
from r47_durable_store import R47DurableStore,persist_atomic,filehash

class DurableFactory:
    def __init__(self,folder):
        self.root=Path(folder)
        self.commits=self.root/'commits'
        self.headfile=self.root/'CURRENT.json'
        self.lockfile=self.root/'LOCK'
        # Use the exact prior version's cross-process filesystem mutex.
        self._old=R47DurableStore(folder)

    def _lock(self):
        return self._old.lock()

    def _publish(self,body):
        persist_atomic(self.headfile,(json.dumps({**body,'pointer_sha256':digest(body)},
                                               sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode('utf8'))

    def initialize(self,factory:IntegratedFactory):
        with self._lock():
            if self.headfile.exists() or (self.commits.exists() and list(self.commits.iterdir())):
                raise FactoryError('DURABLE_STORE_ALREADY_INITIALIZED_OR_ORPHAN')
            if factory.journal:raise FactoryError('INITIALIZE_ONLY_FRESH_FACTORY')
            self.commits.mkdir(parents=True,exist_ok=True)
            snap=factory.snapshot()
            name=f'000000-{factory.head}.json'
            target=self.commits/name
            persist_atomic(target,(json.dumps(snap,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
            state={'schema':'CRAFT-R48-LOCAL-FILE-STORE-v1','sequence':0,
                   'known_commits':[name],'commit_digests':{name:filehash(target.read_bytes())},
                   'current':name,'r48_head':factory.head,
                   'snapshot_sha256':snap['snapshot_sha256'],
                   'sandbox_only':True,'official_stock_effect':0}
            self._publish(state)
            return state

    def _read_unlocked(self,expected_head=None):
        if not self.headfile.exists():raise FactoryError('MISSING_HEAD_NO_AUTOMATIC_BOOTSTRAP')
        body=json.loads(self.headfile.read_text('utf8'))
        checksum=body.pop('pointer_sha256',None)
        if checksum!=digest(body):raise FactoryError('HEAD_POINTER_TAMPERED')
        if body.get('schema')!='CRAFT-R48-LOCAL-FILE-STORE-v1' or body.get('sandbox_only') is not True or body.get('official_stock_effect')!=0:
            raise FactoryError('HEAD_DOMAIN_INCOMPATIBLE')
        known=body.get('known_commits',[])
        if type(known) is not list or not known or len(set(known))!=len(known) or body.get('current')!=known[-1]:
            raise FactoryError('COMMIT_POINTER_ORDER_BROKEN')
        if len(known)!=body.get('sequence')+1:raise FactoryError('COMMIT_SEQUENCE_MISMATCH')
        discovered={p.name for p in self.commits.iterdir() if p.is_file()}
        if discovered!=set(known):
            raise FactoryError('UNKNOWN_EFFECT_ORPHAN_OR_MISSING_HISTORICAL_COMMIT')
        if set(body.get('commit_digests',{}))!=set(known):raise FactoryError('COMMIT_DIGEST_TABLE_MISMATCH')
        for name in known:
            if filehash((self.commits/name).read_bytes())!=body['commit_digests'][name]:
                raise FactoryError('HISTORICAL_COMMIT_FILE_CORRUPT:'+name)
        if expected_head is not None and expected_head!=body['r48_head']:
            raise FactoryError('EXTERNAL_R48_HEAD_MISMATCH')
        snap=json.loads((self.commits/body['current']).read_text('utf8'))
        factory=IntegratedFactory.restore(snap,body['r48_head'],body['snapshot_sha256'])
        if len(factory.journal)!=body['sequence']:
            raise FactoryError('COMMITTED_FACTORY_SEQUENCE_MISMATCH')
        return factory,body

    def recover(self,expected_head=None):
        with self._lock():return self._read_unlocked(expected_head)

    def commit_batch(self,batch_id,orders,reviewed_at,inject=None,expected_head=None):
        """Publish exactly one durable batch transaction to shared synthetic inventory.
        Inject BEFORE_HEAD => blocked unknown effect; AFTER_HEAD => safe idempotent retry.
        """
        with self._lock():
            factory,state=self._read_unlocked(expected_head)
            before=len(factory.journal)
            receipt=factory.process_batch(batch_id,orders,reviewed_at,
                'AFTER_FIRST_ORDER_STAGED' if inject=='BEFORE_BATCH_MEMORY_COMMIT' else None)
            if len(factory.journal)==before:
                return {'idempotent_replay':True,'receipt':receipt,'r48_head':factory.head,
                        'disk_sequence':state['sequence']}
            seq=state['sequence']+1
            name=f'{seq:06d}-{factory.head}.json'
            snap=factory.snapshot()
            target=self.commits/name
            if target.exists():raise FactoryError('CHECKPOINT_COLLISION')
            persist_atomic(target,(json.dumps(snap,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
            if inject=='AFTER_CHECKPOINT_BEFORE_HEAD':
                raise FactoryCrash('UNKNOWN_EFFECT_SNAPSHOT_WRITTEN_POINTER_NOT_COMMITTED')
            nxt={'schema':state['schema'],'sequence':seq,
                 'known_commits':state['known_commits']+[name],
                 'commit_digests':{**state['commit_digests'],name:filehash(target.read_bytes())},
                 'current':name,'r48_head':factory.head,
                 'snapshot_sha256':snap['snapshot_sha256'],
                 'sandbox_only':True,'official_stock_effect':0}
            self._publish(nxt)
            if inject=='AFTER_HEAD_BEFORE_ACK':
                raise FactoryCrash('COMMIT_COMPLETED_ACK_LOST_SAFE_TO_RETRY_IDENTICAL_BATCH')
            return {'idempotent_replay':False,'receipt':receipt,'r48_head':factory.head,
                    'disk_sequence':seq}
