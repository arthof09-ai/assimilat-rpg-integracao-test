"""RC5 readiness DRY-RUN: dependency graph and projected write-set, never Notion writes."""
from __future__ import annotations
import copy
from r48_factory import ALLOWED_RECIPES, FactoryError, digest

PAGE_LAST_EDITS={
 '3f3c2b32-4ede-81ac-af28-c66a6b46e0b2':'2026-10-08T02:26:26.500Z',
 '3f3c2b32-4ede-81e1-b179-e194e2838c84':'2026-10-08T02:26:28.307Z'}
MODULES={
 'REC-LIB-01':'3f1c2b32-4ede-81e2-901a-db9ae10b2702',
 'PR-ITEM-02':'3eec2b32-4ede-81ec-b058-f59f5b67e4f4',
 'REC-MOD-EQA-01':'3f1c2b32-4ede-818a-b3c0-d913574eed28',
 'AUD-CRAFT-F5-REMAP-01':'3f3c2b32-4ede-81c9-9367-e2de46077cbb'}
SUBSTITUTES={
 'SBX-TLI-R44-v1':['ardósia comum plana','tábua comum de oficina','régua existente'],
 'SBX-MICA-R44-v1':['mica comum','calço comum de oficina','espaçador dimensional existente']}

def dossier(recipe):
    if recipe['key'] not in ALLOWED_RECIPES:raise FactoryError('DRYRUN_NOT_ONE_OF_TWO_RECIPES')
    source=recipe['source_page_id']
    if source not in PAGE_LAST_EDITS or not recipe['source_url'].endswith(source.replace('-','')):
        raise FactoryError('SOURCE_PS_NOT_ANCHORED')
    if recipe['official_rec_id'] is not None or recipe['official_product_id'] is not None:
        raise FactoryError('DRYRUN_CANNOT_ACCEPT_OFFICIAL_ID')
    inputs=copy.deepcopy(recipe['inputs'])
    if any(x['quantity']<=0 for x in inputs):raise FactoryError('INVALID_BOM')
    if sum(x['minutes_proposed'] for x in recipe['steps'])!=recipe['proposed_active_minutes']:
        raise FactoryError('DESIGN_PROCESS_DURATION_INCONSISTENT')
    gaps={
      'P0_FENCING_C19': 'NOT_DEMONSTRATED',
      'P0_C19_021_UNKNOWN_EFFECT':'PENDING_RECONCILIATION',
      'PS_SOURCE_REAL_STOCK_AND_UNITS':'UNVERIFIED',
      'REAL_LOT_DIMENSIONS_AND_IDENTITY':'UNVERIFIED',
      'MEASURED_PROCESS_YIELD_AND_FAILURE_RATES':'NOT_MEASURED',
      'TOOLS_SKILLS_OPERATOR_REAL_WORLD':'NOT_VERIFIED',
      'CALIBRATION_CUSTODY_AUTHENTICITY':'SIMULATED_FIXTURES_ONLY',
      'QUALITY_PHYSICAL_INDEPENDENT_TEST':'NOT_MEASURED',
      'COST_UTE_CTE_MED_BY_MARKET_TIME':'UNKNOWN',
      'FUNCTIONAL_BENCHMARK_VS_COMMON_SUBSTITUTES':'NOT_MEASURED',
      'ANTI_DUPLICATE_GLOBAL_RECIPE_PRODUCT_LINEAGE':'SEARCH_LIMITED',
      'REC_LIB_SINGLE_PHYSICAL_PARENT':'PENDING_DESTINATION',
      'CANONICAL_LINKS_AND_PS_JIT_AUTHORIZATION':'PENDING'
    }
    children={'source_resource':{'verified_as_page':True,'ps_semicanonical':True,
                   'source_page_id':source,'last_edited_at_readback':PAGE_LAST_EDITS[source],
                   'actual_stock':None,'confirmed_output':None},
              'rec_model':{'synthetic_design':True,'programmatic_transformation':True,
                            'rc5_canonically_published':False}}
    # All targets are future conditional operations. These are NOT live Notion ids.
    writes=[
      {'action':'REUSE_OR_CREATE_ONE_RECIPE_PAGE_AFTER_GLOBAL_LOOKUP',
       'scope':'REC-LIB/approved physical parent pending',
       'conditional':True,'official_rec_id':None},
      {'action':'REUSE_OR_CREATE_PRODUCT_PAGE_ONLY_IF_ABSENT',
       'scope':'Itens/product destination to validate','conditional':True,'official_product_id':None},
      {'action':'ADD_BACKLINK_TO_EXISTING_SOURCE_IF_AUTHORIZED',
       'scope':source,'conditional':True,'preserve_ps_content':True},
      {'action':'LINK_RECIPE_TO_PRODUCT_AND_CORRECT_INDEX_IF_REQUIRED',
       'scope':'single source of truth under REC-LIB','conditional':True}
    ]
    return {'scope':'MESTRE_ONLY_DRY_RUN_NO_WRITES','design_id':recipe['design_id'],
            'recipe_key':recipe['key'],'name':recipe['name'],'experimental_status':'SOFTWARE_FUNCTIONAL',
            'rc5_status':'NOT_READY','verified_source':children,
            'existing_ps_source_page_id':source,'ingredients_proposed':inputs,
            'tools_proposed':recipe['tools'],'skills_proposed':recipe['skills'],
            'steps_proposed':recipe['steps'],'active_minutes_proposed':recipe['proposed_active_minutes'],
            'output_proposed':recipe['output'],'qa_thresholds_proposed':recipe['qa_rules'],
            'real_yield':'NOT_MEASURED','geometry_or_yield_design':recipe.get('geometry_proposed',{}),
            'cost_expression_proposed':recipe['cost_expression'],'MED_cost':None,
            'benchmarks_existing_first':SUBSTITUTES[recipe['key']],
            'candidate_authority_pages':MODULES,
            'open_gates':gaps,'projected_write_set_if_all_gates_pass':writes,
            'count_rc5_now':0,'count_experimental_recipes':1,
            'anti_duplication_note':'Directed name search only; lack of results is not global absence proof',
            'no_new_materials':True,'party_disclosure':False,
            'readiness_gate_passed':False}


def all_dossiers(recipes):
    if set(recipes)!=set(ALLOWED_RECIPES):raise FactoryError('DRYRUN_TWO_EXISTING_RECIPES')
    rows=[dossier(recipes[k]) for k in ALLOWED_RECIPES]
    return {'status':'NO_OFFICIAL_RC5_WRITES','experimental':2,'official_RC5':0,
            'ready_for_official_write':0,'r48_integrated_software_pilot':True,
            'dossiers':rows,'package_fingerprint_sha256':digest(rows),
            'no_network_or_notion_actions':True}
