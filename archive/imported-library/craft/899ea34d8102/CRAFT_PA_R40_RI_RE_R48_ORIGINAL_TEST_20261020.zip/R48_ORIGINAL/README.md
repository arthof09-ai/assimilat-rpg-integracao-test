# CRAFT R48 — Fábrica Experimental Integrada | CM-000002-I0016 / WS0001

**MESTRE-SIDE · SANDBOX OFFLINE · SEM ESCRITA NA CAMPANHA**

## O que funciona de novo

Um único lote aceita os dois pedidos **B30-01 Tábua Lamelar** e **B30-03 Espaçador de Mica**, e executa na mesma transação local:

`Pedido -> contrato BOM/estoque -> laudo R47 -> reserva de lote -> motor de transformação R44 -> QA -> produto experimental -> recibo -> saldo compartilhado -> checkpoint recuperável`.

**R44 é o motor de consumo, processo, QA e produto, reutilizado sem modificação.** **R47 é o verificador independente de evidências**, reaproveitado com suas regras de CA/assinaturas de TESTE e custódia. R48 acrescenta apenas a coordenação de pedidos, uma prova de reserva/estoque comum, recibos integrados, durabilidade local e dois dossiês RC5 DRY-RUN. Todos os 138 arquivos R47 estão preservados sem edição dentro de `legacy/`, e o ZIP R47 v02 original está em `baseline_original/`.

Não há acesso ao Notion, API produtiva, Party, O Primeiro, estoques reais ou emissão de REC-ID. As chaves R47 de TESTE são públicas e **não** tornam a simulação confiável como produção física.

## Como executar

Requer **Python 3.10+**, dependência `cryptography` (reutilizada de R47). Execute dentro da pasta extraída `CRAFT-R48-SANDBOX-I0016`:

```bash
# 1) Demonstração em memória, sem qualquer escrita produtiva:
python fabricar.py demo

# 2) Exemplo completo com lote A+B, rejeições e rollback local:
python run_r48_demo.py

# 3) Fábrica persistente NOVA em sua pasta de teste:
python fabricar.py --store ./SBX-R48-STATE-DEMO init
python fabricar.py --store ./SBX-R48-STATE-DEMO batch results/r48_batch_request_AB.json
python fabricar.py --store ./SBX-R48-STATE-DEMO status

# 4) Disputa por estoque entre dois processos do sistema operacional:
python process_competition.py

# 5) Novos testes R48:
python -m unittest discover -s tests -p 'test*.py' -q

# 6) Regressões imutáveis anteriores:
python -m unittest discover -s legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016/tests -p 'test*.py' -q
python -m unittest discover -s legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R45/CRAFT-R45-SANDBOX-I0016/tests -p 'test*.py' -q
python -m unittest discover -s legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/tests -p 'test*.py' -q
python -m unittest discover -s legacy/CRAFT-R47-SANDBOX-I0016/tests -p 'test*.py' -q

# 7) Verificação de pacote e manifesto
python verify_r48.py /caminho/CRAFT-R48-I0016-FABRICA-INTEGRADA-v01.zip
```

O arquivo de pedido JSON contém precisamente `batch_id`, `orders`, `reviewed_at`. Cada pedido deve ter `order_id`, `recipe_key`, `lot_ids`, `measurements`, `tools`, `skills`, `report`, `attestation`. O arquivo `results/r48_batch_request_AB.json` é um exemplo **totalmente sintético**, com dois laudos falsos explicitamente rotulados. Nunca use esse exemplo como comprovação física.

## Estados e limites

- Duas receitas experimentais pré-existentes, **2/2**, sem terceira receita.
- **Duas saídas de lote** (uma tábua simulada e um par de espaçadores simulados, 3 peças sintéticas no total).
- **40 testes R48 novos** + **273 regressões R44–R47**, executados separadamente.
- Concorrência `flock` somente entre processos que usam **o mesmo diretório sandbox**. Não equivale a gateway F5/Notion.
- `F5=RED`, `RC5=0/30`, `C19-021=UNKNOWN_EFFECT`, `IBX-38=NOVA`, `NAC-PASS material=HOLD` no último readback.
- **0 medições físicas**, 0 fabricantes reais, 0 novos produtos oficiais, 0 operações em inventário da Party.
- REC-LIB futura somente após prova de fencing, reconhecimento do parent competente, verificação contra duplicatas e gates NAC vigentes.

## O que há nos arquivos

- `r48_factory.py`: adaptador dos motores R44 e R47, lote coordenado, seleção/risco, estoque compartilhado, idempotência e auditoria integrada.
- `r48_store.py`: checkpoints imutáveis, mutex interprocessos reutilizando a API `R47DurableStore.lock` e o gravador `persist_atomic`, detecção de órfãos `UNKNOWN_EFFECT`, replay ancorado em HEAD.
- `fabricar.py`: CLI de fabricação e inspeção de estado.
- `r48_fixtures.py`, `run_r48_demo.py`, `process_competition.py`: dados artificiais e cenários.
- `r48_dryrun.py`, `dryrun/`: dois dossiês RC5 projetados, nenhuma escrita.
- `tests/`: negativos funcionais, concorrência e recuperação.
- `results/`: pedidos, produtos, recibos, snapshots, logs de regressão e resultados.
- `docs/`: relatório/PSV, análise de risco, preparo RC5, protocolo de recuperação, delta R47→R48 e fronteira R49.
- `baseline_original/`: ZIP v02 exatamente igual ao fornecido, SHA-256 publicado.
- `legacy/`: todos os arquivos originais R47 extraídos, preservados byte a byte.

**Descartar a pasta `SBX-R48-STATE-DEMO` remove apenas a simulação local.** Não apague os baselines nem faça rollback do Notion.
