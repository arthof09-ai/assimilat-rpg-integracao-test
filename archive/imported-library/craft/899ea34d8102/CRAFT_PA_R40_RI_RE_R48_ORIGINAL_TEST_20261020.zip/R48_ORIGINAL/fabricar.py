#!/usr/bin/env python3
"""Point of entry: CLI for the integrated SYNTHETIC CRAFT R48 factory."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from r48_factory import IntegratedFactory
from r48_fixtures import lots,pair,REVIEW
from r48_store import DurableFactory


def output(x):print(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2))

def main(argv=None):
    ap=argparse.ArgumentParser(description='CRAFT R48 OFFLINE FACTORY - SYNTHETIC ONLY, no Notion writer')
    ap.add_argument('--store',default='./SBX-R48-FACTORY-STATE',help='isolated local directory, not RPG inventory')
    sp=ap.add_subparsers(dest='command',required=True)
    sp.add_parser('init',help='initialize fictional inventory (default demonstration fixture)')
    p=sp.add_parser('batch',help='process a JSON file with batch_id,orders,reviewed_at')
    p.add_argument('input',type=Path)
    sp.add_parser('status',help='verify disk ledger, display synthetic products/stock')
    sp.add_parser('demo',help='execute two recipes on a new disposable factory')
    args=ap.parse_args(argv)
    if args.command=='demo':
        f=IntegratedFactory.fixture_factory(lots())
        receipt=f.process_batch('SBX-R48-BATCH-DEMO',pair(index=48001),REVIEW)
        output({'receipt':receipt,'audit':f.audit(),'synthetic_only':True})
        return 0
    store=DurableFactory(args.store)
    if args.command=='init':
        output(store.initialize(IntegratedFactory.fixture_factory(lots())))
    elif args.command=='status':
        f,h=store.recover()
        output({'pointer':h,'factory_audit':f.audit(),
                'experimental_products':f.core.state['products'],
                'stock_synthetic':f.quantities,'physical_stock':None,'RC5_official':0})
    elif args.command=='batch':
        data=json.loads(args.input.read_text('utf8'))
        if set(data)!={'batch_id','orders','reviewed_at'}:raise ValueError('BATCH_CONTRACT')
        output(store.commit_batch(data['batch_id'],data['orders'],data['reviewed_at']))
    return 0

if __name__=='__main__':sys.exit(main())
