"""Unit tests of R48 behavior; all fixtures synthetic."""
from __future__ import annotations
import copy
import unittest
from r48_factory import IntegratedFactory,FactoryError,FactoryCrash
from r48_fixtures import lots,pair,order,REVIEW
from r48_dryrun import all_dossiers,dossier
from r47_fixtures import sign

class FactoryTests(unittest.TestCase):
    def setUp(self):
        self.f=IntegratedFactory.fixture_factory(lots())
        self.orders=pair(index=51001)

    def runpair(self,bid='SBX-R48-BATCH-A'):
        return self.f.process_batch(bid,self.orders,REVIEW)

    def test_two_recipe_integrated_production(self):
        r=self.runpair()
        self.assertEqual(r['status'],'ALL_SYNTHETIC_QA_PASS')
        self.assertEqual([x['recipe_key'] for x in r['orders']],['SBX-TLI-R44-v1','SBX-MICA-R44-v1'])
        self.assertEqual(r['experimental_product_count'],2)
        self.assertEqual([len(x['products']) for x in r['orders']],[1,1])
        self.assertEqual([x['products'][0]['units'] for x in r['orders']],[1,2])
        self.assertEqual(self.f.quantities['SBX-SLATE-GOOD-01'],1)
        self.assertEqual(self.f.quantities['SBX-MICA-GOOD-A'],0)
        self.assertEqual(self.f.quantities['SBX-MICA-GOOD-B'],0)
        self.assertEqual(len(self.f.core.state['events']),2)
        self.assertEqual(len(self.f.vault.events),2)
        self.assertTrue(self.f.audit()['ok'])

    def test_shared_one_slate_two_orders_no_oversell(self):
        f=IntegratedFactory.fixture_factory(lots(slate=1))
        a=order('tli',51020);b=order('tli',51021)
        r=f.process_batch('SBX-R48-BATCH-TWO-OVERLAP',[a,b],REVIEW)
        self.assertEqual([x['status'] for x in r['orders']],['EXPERIMENTAL_QA_PASS','REJECTED_PRECHECK'])
        self.assertEqual(r['experimental_product_count'],1)
        self.assertEqual(f.quantities['SBX-SLATE-GOOD-01'],0)
        self.assertTrue(f.audit()['ok'])

    def test_zero_input_yields_no_product(self):
        f=IntegratedFactory.fixture_factory(lots(slate=0))
        r=f.process_batch('SBX-R48-BATCH-INSUFFICIENT',[order('tli',51025)],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'REJECTED_PRECHECK')
        self.assertEqual(r['orders'][0]['consumed'],[])
        self.assertEqual(r['experimental_product_count'],0)
        self.assertEqual(f.quantities['SBX-SLATE-GOOD-01'],0)

    def test_invalid_signature_quarantined_no_stock_effect(self):
        x=order('tli',51026)
        x['attestation']['report_proof']['signature_b64']=sign('calibrator',x['attestation']['report_proof']['body'])
        r=self.f.process_batch('SBX-R48-BATCH-SIGNATURE',[x],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'QUARANTINE_EVIDENCE')
        self.assertEqual(self.f.quantities['SBX-SLATE-GOOD-01'],2)
        self.assertEqual(len(self.f.core.state['events']),0)
        self.assertEqual(len(self.f.vault.events),1)

    def test_signed_report_and_order_quality_diverge(self):
        x=order('tli',51027)
        x['measurements']['width_mm']=75
        r=self.f.process_batch('SBX-R48-BATCH-MEASUREMENT-MISMATCH',[x],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'QUARANTINE_EVIDENCE')
        self.assertIn('MEASUREMENT_NOT_BOUND_TO_SIGNED_REPORT:width_mm',r['orders'][0]['reasons'])
        self.assertEqual(r['stock_before'],r['stock_after'])

    def test_report_source_mismatch_blocks_input(self):
        x=order('tli',51028)
        x['report']['source_page_id']='WRONG'
        r=self.f.process_batch('SBX-R48-BATCH-INVALID-SOURCE',[x],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'QUARANTINE_EVIDENCE')
        self.assertEqual(r['stock_before'],r['stock_after'])

    def test_signed_report_and_order_lot_diverge_preflight_no_mutation(self):
        x=order('tli',51029)
        x['lot_ids']=['SBX-SLATE-TOO-SMALL']
        with self.assertRaises(FactoryError):
            self.f.process_batch('SBX-R48-BATCH-LOT-FORGE',[x],REVIEW)
        self.assertEqual(len(self.f.journal),0)

    def test_bad_dimension_rejected_precheck(self):
        x=order('tli',51030,lot_ids=['SBX-SLATE-TOO-SMALL'])
        # Explicitly update both original and synthetic attestation to the selected
        # reference not possible without a full signed report; malformed request
        # safely rejects before any change.
        with self.assertRaises(FactoryError):
            self.f.process_batch('SBX-R48-BATCH-DIM',[x],REVIEW)
        self.assertEqual(self.f.quantities['SBX-SLATE-TOO-SMALL'],1)

    def test_good_and_bad_in_one_batch(self):
        a=order('tli',51031);b=order('mica',51032)
        b['attestation']['custody_events'].pop(2)
        r=self.f.process_batch('SBX-R48-BATCH-PARTIAL',[a,b],REVIEW)
        self.assertEqual([x['status'] for x in r['orders']],['EXPERIMENTAL_QA_PASS','QUARANTINE_EVIDENCE'])
        self.assertEqual(self.f.quantities['SBX-SLATE-GOOD-01'],1)
        self.assertEqual(self.f.quantities['SBX-MICA-GOOD-A'],1)
        self.assertEqual(r['experimental_product_count'],1)

    def test_missing_tool_reject_no_consume(self):
        a=order('tli',51033);a['tools']=[]
        r=self.f.process_batch('SBX-R48-BATCH-TOOL',[a],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'REJECTED_PRECHECK')
        self.assertEqual(self.f.quantities['SBX-SLATE-GOOD-01'],2)

    def test_duplicate_lot_selection_prevented(self):
        a=order('mica',51034)
        a['lot_ids']=['SBX-MICA-GOOD-A','SBX-MICA-GOOD-A']
        with self.assertRaises(FactoryError):self.f.process_batch('SBX-R48-BATCH-DUPLOT',[a],REVIEW)
        self.assertTrue(self.f.audit()['ok'])

    def test_duplicate_order_id_in_batch(self):
        a=order('tli',51035)
        with self.assertRaises(FactoryError):self.f.process_batch('SBX-R48-BATCH-DUPID',[a,a],REVIEW)

    def test_batch_idempotency_no_second_stock_effect(self):
        initial=self.runpair();before=copy.deepcopy(self.f.quantities);head=self.f.head
        r=self.runpair()
        self.assertTrue(r['idempotent_replay'])
        self.assertEqual(self.f.head,head)
        self.assertEqual(self.f.quantities,before)
        self.assertEqual(len(self.f.journal),1)
        self.assertEqual(initial['experimental_product_count'],r['experimental_product_count'])

    def test_conflicting_batch_idempotency(self):
        self.runpair()
        with self.assertRaises(FactoryError):
            self.f.process_batch('SBX-R48-BATCH-A',pair(index=51500),REVIEW)

    def test_order_id_reuse_between_batches(self):
        self.runpair()
        with self.assertRaises(FactoryError):
            self.f.process_batch('SBX-R48-BATCH-B',self.orders,REVIEW)

    def test_atomic_rollback_after_first_order_staged(self):
        head=self.f.head;stock=copy.deepcopy(self.f.quantities)
        with self.assertRaises(FactoryCrash):
            self.f.process_batch('SBX-R48-BATCH-CRASH',self.orders,REVIEW,'AFTER_FIRST_ORDER_STAGED')
        self.assertEqual(self.f.head,head)
        self.assertEqual(self.f.quantities,stock)
        self.assertEqual(len(self.f.vault.events),0)
        self.assertEqual(len(self.f.core.state['events']),0)
        self.assertEqual(self.runpair('SBX-R48-BATCH-CRASH')['experimental_product_count'],2)

    def test_atomic_rollback_after_second_order_staged(self):
        with self.assertRaises(FactoryCrash):
            self.f.process_batch('SBX-R48-BATCH-CRASH2',self.orders,REVIEW,'AFTER_ALL_ORDERS_BEFORE_COMMIT')
        self.assertEqual(len(self.f.journal),0)
        self.assertEqual(self.f.quantities['SBX-MICA-GOOD-A'],1)
        self.assertTrue(self.f.audit()['ok'])

    def test_snapshot_restore_same_state(self):
        self.runpair()
        snap=self.f.snapshot()
        restored=IntegratedFactory.restore(copy.deepcopy(snap),self.f.head)
        self.assertEqual(restored.quantities,self.f.quantities)
        self.assertEqual(restored.head,self.f.head)
        self.assertTrue(restored.audit()['ok'])

    def test_tamper_snapshot_without_rehash(self):
        self.runpair();snap=self.f.snapshot()
        snap['core_state']['lots']['SBX-SLATE-GOOD-01']['quantity']=999
        with self.assertRaises(FactoryError):IntegratedFactory.restore(snap,self.f.head)

    def test_tamper_snapshot_rehash_still_detected(self):
        from r48_factory import digest
        self.runpair();snap=self.f.snapshot()
        snap['core_state']['lots']['SBX-SLATE-GOOD-01']['quantity']=999
        d={k:v for k,v in snap.items() if k!='snapshot_sha256'}
        snap['snapshot_sha256']=digest(d)
        with self.assertRaises(FactoryError):IntegratedFactory.restore(snap,self.f.head)

    def test_external_head_fences_old_snapshot(self):
        self.runpair();snap=self.f.snapshot()
        with self.assertRaises(FactoryError):IntegratedFactory.restore(snap,'WRONG_HEAD')

    def test_journal_mutation_detected(self):
        self.runpair()
        self.f.journal[0]['event']['orders'][0]['consumed'][0]['quantity']=999
        self.assertFalse(self.f.audit()['ok'])

    def test_no_material_claim_in_receipts(self):
        r=self.runpair()
        self.assertTrue(r['synthetic_only'])
        self.assertEqual(r['official_rec_ids'],[])
        self.assertEqual(r['physical_products'],0)
        self.assertTrue(all(not x['physical_measurement_verified'] and not x['official_materialization'] for x in r['orders']))

    def test_dryrun_two_existing_source_pages_only(self):
        rows=all_dossiers(self.f.recipes)
        self.assertEqual(rows['experimental'],2)
        self.assertEqual(rows['ready_for_official_write'],0)
        self.assertEqual({r['design_id'] for r in rows['dossiers']},{'B30-01','B30-03'})
        self.assertTrue(all(x['official_product_id'] is None for x in [self.f.recipes[k] for k in self.f.recipes]))
        self.assertTrue(all(r['rc5_status']=='NOT_READY' and r['count_rc5_now']==0 for r in rows['dossiers']))

    def test_dryrun_rejects_forged_source(self):
        x=copy.deepcopy(self.f.recipes['SBX-TLI-R44-v1']);x['source_page_id']='WRONG'
        with self.assertRaises(FactoryError):dossier(x)

if __name__=='__main__':unittest.main()

class AdditionalSafetyTests(unittest.TestCase):
    def test_one_report_cannot_support_two_products(self):
        f=IntegratedFactory.fixture_factory(lots())
        a=order('tli',59001);b=copy.deepcopy(a);b['order_id']='SBX-R48-ORDER-59002'
        with self.assertRaisesRegex(FactoryError,'ONE_EVIDENCE_REPORT'):
            f.process_batch('SBX-R48-BATCH-EVIDENCE-DOUBLE',[a,b],REVIEW)
        self.assertEqual(f.quantities['SBX-SLATE-GOOD-01'],2)

    def test_replay_signed_report_for_new_order_rejected(self):
        f=IntegratedFactory.fixture_factory(lots())
        a=order('tli',59003)
        f.process_batch('SBX-R48-BATCH-EVIDENCE-A',[a],REVIEW)
        b=copy.deepcopy(a);b['order_id']='SBX-R48-ORDER-59004'
        with self.assertRaisesRegex(FactoryError,'EVIDENCE_REUSED'):
            f.process_batch('SBX-R48-BATCH-EVIDENCE-B',[b],REVIEW)
        self.assertEqual(f.quantities['SBX-SLATE-GOOD-01'],1)

    def test_fixture_certificate_never_physically_verified(self):
        f=IntegratedFactory.fixture_factory(lots())
        r=f.process_batch('SBX-R48-BATCH-TESTCERT',[order('tli',59005)],REVIEW)
        row=r['orders'][0]
        self.assertEqual(row['authenticity']['status'],'SIMULATED_CRYPTO_VALID_NOT_REAL')
        self.assertFalse(row['authenticity']['physically_verified'])
        self.assertIsNone(row['official_rec_id'])

    def test_small_dimensions_in_existing_lot_rejected(self):
        stock=lots()
        for lot in stock:
            if lot['lot_id']=='SBX-SLATE-GOOD-01':lot['dimensions_mm']['length']=110
        f=IntegratedFactory.fixture_factory(stock)
        r=f.process_batch('SBX-R48-BATCH-UNDER-DIM',[order('tli',59006)],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'REJECTED_PRECHECK')
        self.assertEqual(r['stock_before'],r['stock_after'])

    def test_cracked_input_rejected_even_with_signed_fixture(self):
        stock=lots()
        for lot in stock:
            if lot['lot_id']=='SBX-SLATE-GOOD-01':lot['cracked']=True
        f=IntegratedFactory.fixture_factory(stock)
        r=f.process_batch('SBX-R48-BATCH-CRACKED',[order('tli',59007)],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'REJECTED_PRECHECK')
        self.assertEqual(r['experimental_product_count'],0)

    def test_one_unverified_measured_claim_never_consumes(self):
        from r47_fixtures import make_pair
        f=IntegratedFactory.fixture_factory(lots())
        report,auth=make_pair(index=59008,kind='MEASURED_CLAIM_UNVERIFIED')
        x=order('tli',59009)
        x['report']=report;x['attestation']=auth;x['lot_ids']=report['lot_ids']
        r=f.process_batch('SBX-R48-BATCH-MEASURED-CLAIM',[x],REVIEW)
        self.assertEqual(r['orders'][0]['status'],'QUARANTINE_EVIDENCE')
        self.assertEqual(r['stock_before'],r['stock_after'])
