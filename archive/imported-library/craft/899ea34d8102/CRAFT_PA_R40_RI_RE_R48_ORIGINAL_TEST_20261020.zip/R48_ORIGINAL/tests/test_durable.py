from __future__ import annotations
import copy,json,tempfile,unittest
from pathlib import Path
from r48_factory import IntegratedFactory,FactoryError,FactoryCrash
from r48_fixtures import lots,pair,REVIEW
from r48_store import DurableFactory

class DurableTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='SBX-R48-TEST-')
        self.addCleanup(self.tmp.cleanup)
        self.store=DurableFactory(self.tmp.name)
        self.store.initialize(IntegratedFactory.fixture_factory(lots()))
        self.orders=pair(index=52001)

    def test_disk_success_restart(self):
        self.store.commit_batch('SBX-R48-BATCH-D1',self.orders,REVIEW)
        f,ptr=self.store.recover()
        self.assertEqual(len(f.journal),1)
        self.assertEqual(ptr['sequence'],1)
        self.assertEqual(f.quantities['SBX-SLATE-GOOD-01'],1)
        self.assertTrue(f.audit()['ok'])

    def test_disk_idempotent_retry(self):
        self.store.commit_batch('SBX-R48-BATCH-D2',self.orders,REVIEW)
        result=self.store.commit_batch('SBX-R48-BATCH-D2',self.orders,REVIEW)
        self.assertTrue(result['idempotent_replay'])
        self.assertEqual(result['disk_sequence'],1)

    def test_ack_lost_after_committed_pointer_safe_retry(self):
        with self.assertRaises(FactoryCrash):
            self.store.commit_batch('SBX-R48-BATCH-ACK',self.orders,REVIEW,inject='AFTER_HEAD_BEFORE_ACK')
        r=self.store.commit_batch('SBX-R48-BATCH-ACK',self.orders,REVIEW)
        self.assertTrue(r['idempotent_replay'])
        f,ptr=self.store.recover()
        self.assertEqual(ptr['sequence'],1)
        self.assertEqual(len(f.core.state['products']),2)

    def test_abort_before_memory_commit_no_files(self):
        with self.assertRaises(FactoryCrash):
            self.store.commit_batch('SBX-R48-BATCH-ABORT',self.orders,REVIEW,inject='BEFORE_BATCH_MEMORY_COMMIT')
        f,ptr=self.store.recover()
        self.assertEqual(ptr['sequence'],0)
        self.assertEqual(f.quantities['SBX-SLATE-GOOD-01'],2)

    def test_unpublished_checkpoint_blocks_retry(self):
        with self.assertRaises(FactoryCrash):
            self.store.commit_batch('SBX-R48-BATCH-ORPHAN',self.orders,REVIEW,inject='AFTER_CHECKPOINT_BEFORE_HEAD')
        with self.assertRaisesRegex(FactoryError,'UNKNOWN_EFFECT'):
            self.store.commit_batch('SBX-R48-BATCH-ORPHAN',self.orders,REVIEW)
        with self.assertRaisesRegex(FactoryError,'UNKNOWN_EFFECT'):
            self.store.recover()

    def test_inconsistent_head_detected(self):
        p=self.store.headfile
        v=json.loads(p.read_text());v['r48_head']='WRONG';p.write_text(json.dumps(v))
        with self.assertRaisesRegex(FactoryError,'HEAD_POINTER_TAMPERED'):self.store.recover()

    def test_historical_checkpoint_corruption_detected(self):
        self.store.commit_batch('SBX-R48-BATCH-HISTORY',self.orders,REVIEW)
        first=sorted(self.store.commits.glob('*.json'))[0]
        first.write_text(first.read_text()+'X')
        with self.assertRaisesRegex(FactoryError,'HISTORICAL_COMMIT_FILE_CORRUPT'):self.store.recover()

    def test_external_expected_head_must_match(self):
        with self.assertRaisesRegex(FactoryError,'EXTERNAL_R48_HEAD_MISMATCH'):
            self.store.recover(expected_head='STALE_EXTERNAL_HEAD')

    def test_batch_conflict_safe(self):
        self.store.commit_batch('SBX-R48-BATCH-KEY',self.orders,REVIEW)
        with self.assertRaises(FactoryError):
            self.store.commit_batch('SBX-R48-BATCH-KEY',pair(index=53000),REVIEW)
        f,_=self.store.recover();self.assertTrue(f.audit()['ok'])

if __name__=='__main__':unittest.main()
