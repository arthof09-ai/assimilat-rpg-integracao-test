"""CRAFT R48 integrated SYNTHETIC factory: reuses R44 transformation + R47 authenticity.

No Notion/network access, no physical measurements, no RC5 materialization.  All
stock, operators, prices, lots, and QA assertions are explicitly test fixtures.
"""
from __future__ import annotations
import copy
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parent
R47=ROOT/'legacy/CRAFT-R47-SANDBOX-I0016'
R44=R47/'baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016'
sys.path.insert(0,str(R47))
sys.path.insert(0,str(R44))
from experimental_engine import SandboxEngine, SandboxError, SimulatedCrash, load_recipes
from r47_authenticity import AuthenticityVault, AuthError, InjectedFailure, digest, GENESIS as AUTH_GENESIS
from r47_fixtures import policy, recipes_and_sources

SCHEMA='CRAFT-R48-FACTORY-v1'
GENESIS=hashlib.sha256(b'SBX-CRAFT-R48-I0016|GENESIS-v1').hexdigest()
ALLOWED_RECIPES=('SBX-TLI-R44-v1','SBX-MICA-R44-v1')
FIXTURE='SYNTHETIC'

class FactoryError(ValueError): pass
class FactoryCrash(RuntimeError): pass


def _canon(x):
    return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)


def _receipt_only(recp):
    """Do not echo source instrument private bytes in a factory receipt."""
    return {'status':recp['status'],'report_id':recp['report_id'],
            'valid_fixture_signatures':recp['valid_signature_count'],
            'reason':recp['reasons'],'physically_verified':recp['physically_verified'],
            'r47_receipt_hash':recp['receipt_hash']}


def _clone_auth(obj):
    """Reuse the old R47 validator with an independent staging state; never copy RLock."""
    x=AuthenticityVault(obj.parent.recipes,obj.parent.sources,obj.trust.policy)
    x.parent.events=copy.deepcopy(obj.parent.events)
    x.parent.head=obj.parent.head
    x.parent._events_fingerprint=digest(x.parent.events)
    x.events=copy.deepcopy(obj.events)
    x.head=obj.head
    x._fingerprint=digest(x.events)
    if not x.audit()['ok']:
        raise FactoryError('R47_CLONE_AUDIT_FAILURE')
    return x


def _validate_request(item:dict):
    if type(item) is not dict or set(item)!={'order_id','recipe_key','lot_ids','measurements','tools','skills','report','attestation'}:
        raise FactoryError('ORDER_CONTRACT_INVALID')
    if type(item['order_id']) is not str or not item['order_id'].startswith('SBX-R48-ORDER-') or len(item['order_id'])>110:
        raise FactoryError('EXPERIMENTAL_ORDER_ID_REQUIRED')
    if item['recipe_key'] not in ALLOWED_RECIPES:
        raise FactoryError('ONLY_TWO_EXISTING_RECIPES')
    if type(item['lot_ids']) is not list or any(type(s) is not str for s in item['lot_ids']):
        raise FactoryError('LOT_IDS_CONTRACT')
    if type(item['tools']) is not list or type(item['skills']) is not list or type(item['measurements']) is not dict:
        raise FactoryError('PROCESS_CONTRACT_INVALID')
    if type(item['report']) is not dict or type(item['attestation']) is not dict:
        raise FactoryError('EVIDENCE_CONTRACT_INVALID')
    if item['report'].get('recipe_key')!=item['recipe_key'] or item['report'].get('lot_ids')!=item['lot_ids']:
        raise FactoryError('REPORT_ORDER_RECIPE_LOT_MISMATCH')
    return item


def _evidence_agrees(item,recipe):
    """R47 signatures are necessary but not sufficient: QA must describe this order."""
    report=item['report']
    if report.get('evidence_kind')!='SYNTHETIC' or report.get('source_page_id')!=recipe['source_page_id']:
        return False,'EVIDENCE_NOT_SIMULATED_OR_SOURCE_MISMATCH'
    obs=report.get('observations')
    if type(obs) is not dict or set(obs)!={s['field'] for s in recipe['qa_rules']}:
        return False,'INSPECTION_FIELDS_MISMATCH'
    if set(item['measurements'])!={s['field'] for s in recipe['qa_rules']}:
        return False,'INSPECTION_MEASUREMENTS_INCOMPLETE'
    for field,reading in obs.items():
        if type(reading) is not dict or reading.get('value')!=item['measurements'][field]:
            return False,'MEASUREMENT_NOT_BOUND_TO_SIGNED_REPORT:'+field
        if reading.get('sample_id')!=report.get('sample_id') or reading.get('instrument_id')!=report.get('instrument',{}).get('instrument_id'):
            return False,'READING_SAMPLE_OR_INSTRUMENT_DIVERGENCE:'+field
    return True,None


class IntegratedFactory:
    """Atomic, multiorder simulation over ONE R44 ledger and ONE R47 vault."""
    def __init__(self,recipes:dict,lots:list[dict],sources:dict,trust:dict):
        if set(recipes)!=set(ALLOWED_RECIPES):raise FactoryError('EXACTLY_TWO_EXISTING_RECIPES')
        self.recipes=copy.deepcopy(recipes)
        self.core=SandboxEngine(self.recipes,lots)
        self.vault=AuthenticityVault(self.recipes,sources,trust)
        self.journal=[]
        self.head=GENESIS
        self.seen_batches={}
        self.fixture_marker='SYNTHETIC_NO_OFFICIAL_INVENTORY'

    @classmethod
    def fixture_factory(cls,lots):
        r,s=recipes_and_sources()
        return cls(r,lots,s,policy())

    @property
    def quantities(self):
        return {k:v['quantity'] for k,v in sorted(self.core.state['lots'].items())}

    def process_batch(self,batch_id:str,orders:list,reviewed_at:str,inject:str|None=None):
        if not self.audit()['ok']:raise FactoryError('FACTORY_AUDIT_FAILED_PRESTATE')
        if type(batch_id) is not str or not batch_id.startswith('SBX-R48-BATCH-') or len(batch_id)>110:
            raise FactoryError('EXPERIMENTAL_BATCH_ID_REQUIRED')
        if type(orders) is not list or not 1<=len(orders)<=16:
            raise FactoryError('INVALID_BATCH_ARITY')
        if any(type(row) is not dict for row in orders):raise FactoryError('ORDER_MUST_BE_OBJECT')
        ids=[row.get('order_id') for row in orders]
        if len(set(ids))!=len(ids):raise FactoryError('DUPLICATE_ORDER_ID_IN_BATCH')
        for row in orders:_validate_request(row)
        evidence_ids=[row['report'].get('report_id') for row in orders]
        if len(set(evidence_ids))!=len(evidence_ids):
            raise FactoryError('ONE_EVIDENCE_REPORT_CANNOT_PRODUCE_TWO_ORDERS')
        request_hash=digest({'batch_id':batch_id,'orders':orders,'reviewed_at':reviewed_at})
        if batch_id in self.seen_batches:
            old=self.seen_batches[batch_id]
            if old['request_hash']!=request_hash:raise FactoryError('BATCH_IDEMPOTENCY_CONFLICT')
            return {**copy.deepcopy(old['receipt']),'idempotent_replay':True}
        old_orderids={r['order_id'] for record in self.journal for r in record['event']['orders']}
        if old_orderids.intersection(ids):raise FactoryError('ORDER_ID_REUSED_IN_ANOTHER_BATCH')
        previous_reports={o['authenticity']['report_id'] for rec in self.journal
                          for o in rec['event']['orders']}
        if previous_reports.intersection(evidence_ids):
            raise FactoryError('EVIDENCE_REUSED_FOR_NEW_FABRICATION_ORDER')
        old_core=self.core
        core=copy.deepcopy(old_core)
        auth=_clone_auth(self.vault)
        before=self.quantities
        output=[]
        for index,row in enumerate(orders,1):
            recipe=self.recipes[row['recipe_key']]
            agreed,why=_evidence_agrees(row,recipe)
            # ALWAYS validate independent R47 fixture authenticity, even for a
            # rejected synthetic order, but do NOT let R47 touch stock.
            auth_receipt=auth.submit(row['report'],row['attestation'],reviewed_at)
            verdict=_receipt_only(auth_receipt)
            source_lots=copy.deepcopy(row['lot_ids'])
            reserved=[]
            if not agreed:
                status='QUARANTINE_EVIDENCE'
                reasons=[why]
                craft=None
            elif (auth_receipt['status']!='SIMULATED_CRYPTO_VALID_NOT_REAL' or
                  auth_receipt['r46_status']!='SYNTHETIC_QA_PASS' or
                  auth_receipt['physically_verified'] is not False):
                status='QUARANTINE_EVIDENCE'
                reasons=['R47_OR_R46_QUARANTINE']+auth_receipt['reasons']
                craft=None
            else:
                # Projection of shared stock before every production step.  The
                # R44 engine will independently validate and consume quantities.
                projected=copy.deepcopy(core.state['lots'])
                preflight=[]
                if len(source_lots)!=len(recipe['inputs']):preflight.append('INPUT_ARITY')
                if len(set(source_lots))!=len(source_lots):preflight.append('DUPLICATE_LOT_SELECTION')
                selected=[]
                for lot_id in source_lots:
                    if lot_id not in projected:preflight.append('UNKNOWN_SYNTHETIC_LOT')
                    else:selected.append(projected[lot_id])
                if len(selected)==len(recipe['inputs']):
                    preflight+=SandboxEngine._input_ok(recipe,selected)
                if any(t not in row['tools'] for t in recipe['tools']):preflight.append('MISSING_TOOL')
                if any(t not in row['skills'] for t in recipe['skills']):preflight.append('MISSING_SKILL')
                if not preflight:
                    for rq,lot in zip(recipe['inputs'],selected):
                        lot['quantity']-=rq['quantity']
                        reserved.append({'lot_id':lot['lot_id'],'quantity':rq['quantity'],'unit':rq['unit']})
                    if any(lot['quantity']<0 for lot in projected.values()):
                        raise FactoryError('SHARED_RESERVATION_OVERSELL')
                # Existing R44 implementation creates the product, process trace,
                # waste, QA verdict and consumption.  It is NEVER replaced.
                craft=core.run(row['recipe_key'],row['order_id'],source_lots,row['measurements'],
                               row['tools'],row['skills'])
                reasons=craft['rejection_reasons']
                status=craft['status']
                if preflight and status!='REJECTED_PRECHECK':
                    raise FactoryError('RESERVATION_AND_R44_DISAGREE')
                if not preflight and craft['status']=='EXPERIMENTAL_QA_PASS':
                    if [{k:c[k] for k in ('lot_id','quantity','unit')} for c in craft['consumed']]!=reserved:
                        raise FactoryError('R44_CONSUMPTION_MISMATCH')
                else:
                    reserved=[]
            out={'order_id':row['order_id'],'recipe_key':row['recipe_key'],
                 'source_ps_page_id':recipe['source_page_id'],
                 'status':status,'reasons':sorted(set(reasons)),
                 'inventory_reservation':reserved,
                 'lot_ids':source_lots,'authenticity':verdict,
                 'process_trace':craft['transformation_stage_trace'] if craft else [],
                 'quality_fixture':copy.deepcopy(row['measurements']),
                 'consumed':copy.deepcopy(craft['consumed']) if craft else [],
                 'waste':copy.deepcopy(craft['scrap']) if craft else [],
                 'products':copy.deepcopy(craft['products']) if craft else [],
                 'r44_receipt_hash':digest(craft) if craft else None,
                 'active_minutes_proposed':recipe['proposed_active_minutes'],
                 'cost':{'formula_proposed':recipe['cost_expression'],'currency':'MED_UNDETERMINED',
                         'note':'ONLY_SYNTHETIC_INPUT_PRICES_IF_EXPLICITLY_SUPPLIED'},
                 'physical_measurement_verified':False,'official_rec_id':None,
                 'official_materialization':False,'fixture_kind':FIXTURE}
            output.append(out)
            if inject=='AFTER_FIRST_ORDER_STAGED' and index==1:
                raise FactoryCrash('INJECTED_AFTER_FIRST_ORDER_STAGED_ROLLBACK_WHOLE_BATCH')
        if inject=='AFTER_ALL_ORDERS_BEFORE_COMMIT':
            raise FactoryCrash('INJECTED_BEFORE_BATCH_COMMIT_ROLLBACK')
        after={k:v['quantity'] for k,v in sorted(core.state['lots'].items())}
        batch_status=('ALL_SYNTHETIC_QA_PASS' if all(x['status']=='EXPERIMENTAL_QA_PASS' for x in output)
                      else 'COMPLETED_WITH_REJECTIONS')
        receipt={'schema':SCHEMA,'batch_id':batch_id,'request_sha256':request_hash,
                 'status':batch_status,'orders':copy.deepcopy(output),
                 'stock_before':before,'stock_after':after,
                 'r44_ledger_head':core.state['head_hash'],'r47_evidence_head':auth.head,
                 'experimental_product_count':sum(len(x['products']) for x in output),
                 'physical_products':0,'official_rec_ids':[], 'official_stock_effect':0,
                 'synthetic_only':True,'idempotent_replay':False}
        event={'sequence':len(self.journal)+1,'batch_id':batch_id,'request_sha256':request_hash,
               'orders':copy.deepcopy(output),'stock_before':before,'stock_after':after,
               'r44_ledger_head':core.state['head_hash'],'r47_head':auth.head,
               'receipt_hash':digest(receipt),'batch_status':batch_status}
        prev=self.head
        entry={'previous_hash':prev,'event':event}
        entry['hash']=digest(entry)
        # Last chance to inspect *all* staged sub-ledgers before publishing.
        if not core.audit()['ok'] or not auth.audit()['ok']:
            raise FactoryError('STAGED_SUBLEDGER_AUDIT_FAILED')
        # Prepare and audit the *whole integrated candidate* before publishing.
        # Failures, including unforeseen cross-ledger mismatches, must not leave
        # a partially committed factory in memory.
        candidate=IntegratedFactory(self.recipes,list(self.core.initial_lots.values()),
                                    self.vault.parent.sources,self.vault.trust.policy)
        candidate.core=core;candidate.vault=auth
        candidate.journal=copy.deepcopy(self.journal)+[entry]
        candidate.head=entry['hash']
        candidate.seen_batches=copy.deepcopy(self.seen_batches)
        candidate.seen_batches[batch_id]={'request_hash':request_hash,'receipt':receipt}
        final_audit=candidate.audit()
        if not final_audit['ok']:
            raise FactoryError('CANDIDATE_INVARIANT_FAILED_NO_COMMIT:'+repr(final_audit['failures']))
        self.core=candidate.core;self.vault=candidate.vault
        self.journal=candidate.journal;self.head=candidate.head
        self.seen_batches=candidate.seen_batches
        return copy.deepcopy(receipt)

    def audit(self):
        failures=[]
        ca=self.core.audit();va=self.vault.audit()
        if not ca['ok']:failures.append('R44_INVARIANT:'+repr(ca.get('reasons',[])))
        if not va['ok']:failures.append('R47_INVARIANT:'+repr(va.get('issues',[])))
        if self.fixture_marker!='SYNTHETIC_NO_OFFICIAL_INVENTORY':failures.append('SANDBOX_MARKER_CHANGED')
        prev=GENESIS
        initial={k:v['quantity'] for k,v in sorted(self.core.initial_lots.items())}
        counts=copy.deepcopy(initial)
        last_r44=self.core.state['events'][0]['previous_hash'] if self.core.state['events'] else self.core.state['head_hash']
        last_r47=AUTH_GENESIS
        orders_seen=set()
        for ix,e in enumerate(self.journal,1):
            p=e.get('event',{})
            if e.get('previous_hash')!=prev or e.get('hash')!=digest({'previous_hash':prev,'event':p}):
                failures.append('R48_JOURNAL_HASH_OR_PREVIOUS_MISMATCH')
            prev=e.get('hash')
            if p.get('sequence')!=ix:failures.append('R48_SEQUENCE_ERROR')
            if p.get('stock_before')!=counts:failures.append('R48_STOCK_BEFORE_NOT_CHAINED')
            for order in p.get('orders',[]):
                oid=order.get('order_id')
                if oid in orders_seen:failures.append('DUPLICATE_CROSS_BATCH_ORDER')
                orders_seen.add(oid)
                for c in order['consumed']:
                    if c['lot_id'] not in counts:
                        failures.append('CONSUMED_UNKNOWN_STOCK');continue
                    counts[c['lot_id']]-=c['quantity']
                    if counts[c['lot_id']]<0:failures.append('STOCK_NEGATIVE')
                if order['physical_measurement_verified'] or order['official_rec_id'] is not None or order['official_materialization']:
                    failures.append('FORBIDDEN_MATERIAL_PROMOTION')
                if any(p.get('official_product_id') is not None or p.get('status')!='SYNTHETIC_OUTPUT_ONLY' for p in order['products']):
                    failures.append('NON_SANDBOX_PRODUCT')
                if order['status']!='EXPERIMENTAL_QA_PASS' and order['products']:
                    failures.append('REJECTED_ORDER_HAS_PRODUCTS')
            if counts!=p.get('stock_after'):failures.append('R48_STOCK_AFTER_NOT_DERIVED')
            batch=p.get('batch_id'); saved=self.seen_batches.get(batch)
            if not saved or digest(saved['receipt'])!=p.get('receipt_hash') or saved['request_hash']!=p.get('request_sha256'):
                failures.append('RECEIPT_NOT_BOUND_TO_JOURNAL')
            last_r44=p.get('r44_ledger_head');last_r47=p.get('r47_head')
        if self.head!=prev:failures.append('R48_HEAD_INCONSISTENT')
        if counts!=self.quantities:failures.append('CURRENT_STOCK_NOT_DERIVED')
        if self.journal:
            if last_r44!=self.core.state['head_hash'] or last_r47!=self.vault.head:
                failures.append('R44_R47_SUBLEDGER_HEAD_MISMATCH')
        if len(self.seen_batches)!=len(self.journal):failures.append('BATCH_IDENTITY_CARDINALITY')
        return {'ok':not failures,'failures':failures,'batches':len(self.journal),
                'orders':len(orders_seen),'head':self.head,'stock':counts,
                'r44_events':len(self.core.state['events']),'r47_events':len(self.vault.events)}

    def snapshot(self):
        if not self.audit()['ok']:raise FactoryError('SNAPSHOT_AUDIT_FAILED')
        data={'schema':SCHEMA,'factory_genesis':GENESIS,'fixture_marker':self.fixture_marker,
              'recipes':self.recipes,'original_lots':list(self.core.initial_lots.values()),
              'core_state':self.core.state,'sources':self.vault.parent.sources,
              'trust_policy':self.vault.trust.policy,
              'r46_parent_events':self.vault.parent.events,'r46_parent_head':self.vault.parent.head,
              'r47_events':self.vault.events,'r47_head':self.vault.head,
              'journal':self.journal,'r48_head':self.head,'seen_batches':self.seen_batches}
        return {**data,'snapshot_sha256':digest(data)}

    @classmethod
    def restore(cls,snapshot:dict,expected_head:str,expected_snapshot_sha256:str|None=None):
        if type(snapshot) is not dict:raise FactoryError('NOT_SNAPSHOT_JSON')
        data=copy.deepcopy(snapshot)
        signature=data.pop('snapshot_sha256',None)
        if signature!=digest(data) or (expected_snapshot_sha256 is not None and signature!=expected_snapshot_sha256):
            raise FactoryError('SNAPSHOT_INTEGRITY_FAILURE')
        if data.get('schema')!=SCHEMA or data.get('factory_genesis')!=GENESIS or data.get('fixture_marker')!='SYNTHETIC_NO_OFFICIAL_INVENTORY':
            raise FactoryError('SNAPSHOT_SCHEMA_OR_SANDBOX_SCOPE')
        obj=cls(data['recipes'],data['original_lots'],data['sources'],data['trust_policy'])
        obj.core.state=data['core_state']
        obj.vault.parent.events=data['r46_parent_events']
        obj.vault.parent.head=data['r46_parent_head']
        obj.vault.parent._events_fingerprint=digest(obj.vault.parent.events)
        obj.vault.events=data['r47_events']
        obj.vault.head=data['r47_head']
        obj.vault._fingerprint=digest(obj.vault.events)
        obj.journal=data['journal'];obj.head=data['r48_head']
        obj.seen_batches=data['seen_batches']
        if obj.head!=expected_head:raise FactoryError('EXTERNAL_EXPECTED_R48_HEAD_MISMATCH')
        result=obj.audit()
        if not result['ok']:raise FactoryError('RESTORED_AUDIT_FAILED:'+repr(result['failures']))
        return obj
