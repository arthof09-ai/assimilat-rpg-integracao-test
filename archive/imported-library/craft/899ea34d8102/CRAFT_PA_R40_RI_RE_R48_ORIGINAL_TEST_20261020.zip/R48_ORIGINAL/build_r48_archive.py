"""Deterministic archive build; the reference artifact v02 is byte-preserved."""
from __future__ import annotations
import hashlib,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
NAME='CRAFT-R48-I0016-FABRICA-INTEGRADA-v01.zip'
DEST=HERE.parent/NAME
IGNORE={'__pycache__','.pytest_cache','.DS_Store'}

def chosen():
    paths=[]
    for f in HERE.rglob('*'):
        if not f.is_file() or any(seg in IGNORE for seg in f.relative_to(HERE).parts):continue
        if f.name=='MANIFEST_SHA256.txt' and f.parent==HERE:continue
        if f.suffix=='.pyc' or f.name.endswith('.inflight'):continue
        paths.append(f)
    return sorted(paths,key=lambda p:p.relative_to(HERE).as_posix())

def write():
    paths=chosen()
    rows=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(HERE).as_posix() for p in paths]
    manifest=HERE/'MANIFEST_SHA256.txt'
    manifest.write_text('# R48 manifest: SHA-256 of exact member bytes; excludes manifest itself.\n'+'\n'.join(rows)+'\n',encoding='utf8')
    with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in [*paths,manifest]:
            rel=f.relative_to(HERE).as_posix()
            info=zipfile.ZipInfo('CRAFT-R48-SANDBOX-I0016/'+rel,date_time=(2026,10,9,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(0o100644 << 16)
            z.writestr(info,f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return {'package':str(DEST),'files':len(paths),'bytes':DEST.stat().st_size,
            'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest()}

if __name__=='__main__':print(write())
