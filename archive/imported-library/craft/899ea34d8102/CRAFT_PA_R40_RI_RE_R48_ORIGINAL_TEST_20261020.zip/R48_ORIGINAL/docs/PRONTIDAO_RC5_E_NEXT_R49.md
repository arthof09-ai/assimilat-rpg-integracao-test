# R48 — duas candidatas a RC5: DRY-RUN, não canonização

A fonte normativa original é PR-ITEM-02 + REC-LIB-01 + REC-MOD-EQA-01 + PR-SC-01 + PR-ECO/Anexo C. Os 2 arquivos JSON em `dryrun/` registram o contrato **proposto** e o write-set **condicional**, sem criar autoridade paralela.

## B30-01 — Tábua Lamelar de Inscrição

**VERIFICADO DOCUMENTAL:** existe ficha PS Ardósia de Geada Lamelar `CRAFT-F5-R01-MIN-01`, página `3f3c2b32-4ede-81ac-af28-c66a6b46e0b2`. A ficha lista Tábua Lamelar como RC0/RC1 candidata; não é receita oficial. R42 detalha metrologia; R44-R48 demonstram cálculo sintético.

**PROPOSTO:** 1 lâmina íntegra e sem fissuras ≥130×90×9 mm, saída 1 tábua 120×80×8 mm, malha passo 10 mm, 55 minutos ativos, ferramental de lapidação/inspeção conforme receita JSON. QA de dimensão/planeza/malha/trinca e ausência de efeito mágico. Tempo, rendimento e tolerâncias não são observações de artesão.

**PENDENTE:** existência e unidade real da lâmina, rendimento por lote, abrasivo gasto, ARTESÃO real, ferramentas, QA medido, custo MED/UTE/CTE em mercado e tempo, demanda e comparação funcional com ardósia/gabarito comuns, local correto REC-LIB, busca anti-duplicata exaustiva, aprovação PS/JIT, fencing C19.

**Plano mínimo de escrita APÓS gates:** reusar ou criar UMA página REC-ID na autoridade competente; se produto não existir, UMA ficha produto; adicionar só backlink no recurso PS original e links únicos receita↔produto↔índice. Não criar novo minério, insumo, loja ou passagem Party por consequência.

## B30-03 — Espaçador de Mica Calibrado

**VERIFICADO DOCUMENTAL:** ficha PS Mica de Bruma Boreal `CRAFT-F5-R01-MIN-02`, página `3f3c2b32-4ede-81e1-b179-e194e2838c84`. O recurso descreve função dimensional/isolante mecânico sem poder de bruma automático. A proposta B30-03 está no dossiê R42/R43.

**PROPOSTO:** 2 folhas ≥60×30 mm, aparadas para 2 peças 50×20 mm, espessura medida e diferença ≤0,10 mm **somente como hipótese R44**, 30 minutos ativos, instrumentação e habilidades da receita JSON. QA de número de peças, trincas, lamelas soltas e encaixe seco. Nada atesta isolamento arcano.

**PENDENTE:** espessura/dimensões/repetibilidade medidas, calibragem física, resistência/carga, rendimento, estoque/transportes, custo MED, substitutos mica comum/calço comum, localização de uma receita única, política PS/JIT, fencing C19.

**Write-set após gates:** mesmas categorias condicionais da tábua, mantendo uma fonte de receita e um produto se não existir equivalência. Sem duplicar página nem inventar dispositivo paralelo.

## Gates oficiais

`F5=RED`; `IBX-38=NOVA sem ACK`; `C19-021=UNKNOWN_EFFECT`; `C19 fencing=NOT-DEMONSTRATED`; `RC5 oficiais=0/30`; `NAC-PASS material=HOLD`. A adequação de uma receita como software não satisfaz todos os requisitos para RC5.

## Ponto exato R49 recomendado

Priorizar o **contrato de admissão transacional** entre a fábrica experimental e o receituário futuro: um `PLAN_WRITE_SET` assinado/ancorado e revisado pela coordenação, conjunto de páginas alvo anti-duplicata e comparações antes/depois; executar integralmente como DRY-RUN sob F5 RED. Não é necessário criar mais uma receita ou nova camada de autenticidade externa enquanto faltam provas físicas. Em paralelo, especificar o primeiro ensaio físico legítimo de comparação funcional usando somente equipamentos/operadores existentes **se e quando** dados forem apresentados; jamais reportar amostra não fornecida como medida.
