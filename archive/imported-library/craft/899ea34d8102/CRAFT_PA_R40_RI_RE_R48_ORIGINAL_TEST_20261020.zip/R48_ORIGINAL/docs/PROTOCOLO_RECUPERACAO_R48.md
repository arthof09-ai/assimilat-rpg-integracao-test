# Protocolo R48 — transações, recuperação e replay

**Escopo:** apenas diretório local de sandbox. O mesmo armazenamento pode ser compartilhado por processos da fábrica R48 no mesmo host/filesystem, nunca constitui fencing externo Notion.

## Fluxo de commit

1. O executor abre o mutex local `flock`, verifica `CURRENT.json`, histórico de hashes, snapshots anteriores e o estado completo restaurado R44+R47+R48.
2. O lote é processado **em cópia de trabalho**: autenticação R47 de cada laudo, correspondência pedido/medida, pré-reserva com estoque compartilhado, `SandboxEngine.run` R44 de cada ordem, QA, recibo e comparador de inventário.
3. A candidata inteira passa `R44.audit`, `R47.audit` e `R48.audit` **antes** de substituir o estado ativo em memória.
4. O armazenamento escreve snapshot novo com `persist_atomic` herdado de R47, fsync de arquivo e diretório, e atualiza **por último** `CURRENT.json` por substituição atômica. O ponteiro contém hash, contador e hashes de **todos** os snapshots históricos.
5. Se o commit foi publicado mas a resposta se perdeu (`AFTER_HEAD_BEFORE_ACK`), o mesmo pedido `batch_id` + bytes iguais é replay idempotente, sem débito adicional. `batch_id` igual com corpo diferente é erro de conflito.

## Estados de falha

- **Antes do commit em memória:** sem alteração de estoque, produto, vault ou journal. Exemplo `AFTER_FIRST_ORDER_STAGED`; pode-se repetir o mesmo lote após verificar o prestate.
- **Checkpoint gravado sem ponteiro:** snapshot órfão detectado; `UNKNOWN_EFFECT_ORPHAN_OR_MISSING_HISTORICAL_COMMIT`. Bloquear retry e pedir reconciliação explícita dos bytes/ponteiro; não apagar órfão às cegas.
- **Ponteiro atualizado sem ACK:** operação efetivamente gravada; repetir mesmo pedido retorna recibo anterior com `idempotent_replay=True`.
- **Arquivo histórico alterado, ponteiro adulterado, imagem desatualizada sem hash HEAD externo:** abortar. Não tentar reparar substituindo snapshots sem auditoria.
- **Duas chamadas concorrentes ao mesmo diretório:** `flock` serializa as transações e reabre o estoque a cada operação. É garantia de software **local**, sem controle sobre escritores Notion.

## Reaplicação e limites

`python fabricar.py --store ./SBX-R48-STATE-DEMO status` verifica HEAD/snapshots/journal. Para executar exatamente o lote A+B em estado limpo: `init`, depois `batch results/r48_batch_request_AB.json`. Para outra produção local, use IDs de pedido/lote/laudo de TESTE inéditos e estoques fictícios apropriados. Não contorne `UNKNOWN_EFFECT` por recriação silenciosa da pasta original.

**Consistência em disco:** `R48.snapshot` reconstitui estado R44/R47 e valida derivação dos saldos a partir de consumos no journal; recuperação exige o hash HEAD esperado, quando fornecido por autoridade externa ao diretório. Hash de arquivo sozinho não prova autoridade produtiva, cadeia de custódia real nem estoque existente.

**Stop-line:** never point this CLI to the campaign's filesystem/API/Notion. `RC5=0/30` até liberação formal de C19, reconciliação C19-021 e gates materiais.
