# PSV — CRAFT R48 / FÁBRICA EXPERIMENTAL INTEGRADA

**Identidade:** CM-000002-I0016 / CM-000002-WS0001 — Mestre-side. **Objetivo:** fábrica funcional de duas receitas já existentes, não uma terceira fórmula nem outra autoridade de certificação.

## Baseline VALIDADO

- ZIP R47 v02: SHA-256 `be76bc7ea2218dce388b1197797d6015891b3bbb1801351f99a2b49bab56252e`, CRC/manifest PASS. Preservados 138/138 arquivos e, dentro deles, R46/R45/R44.
- Regressões reexecutadas R44 **52/52**, R45 **64/64**, R46 **70/70**, R47 **87/87** — total **273/273**.
- Fontes Notion Mestre-side consultadas: IBX-67, IBX-38, OP-ARQ-RIN-REC-01, AUD-F5-REMAP, fichas PS originais, PR-ITEM-02, REC-LIB-01 e REC-MOD-EQA-01. Não houve gravação de receitas, fichas ou dados produtivos. ACK IBX-67 existe apenas como comentário documental.

## Resultado novo

Entrypoint `fabricar.py` e `IntegratedFactory.process_batch`: **Pedido A Tábua + Pedido B Espaçador**, execução coordenada sobre **um único estoque sintético**. R47 valida laudo e assinatura sintética; R44 realiza consumo/transformação/QA; R48 exige correspondência laudo↔pedido e registra reserva, saldo compartilhado e recibo único. Usa transação candidata completa, com auditoria ANTES de publicar; escrita durável local reutiliza a primitiva R47 de `flock` e fsync.

### Demo VERIFICADA DE SOFTWARE, não ensaio empírico

| Pedido | Insumos fictícios | Resultado QA | Produto fictício | Consumo |
|---|---|---|---|---|
| A / B30-01 | 1 lâmina Ardósia `SBX-SLATE-GOOD-01` | `EXPERIMENTAL_QA_PASS` | 1 Tábua (registro) | 1 lâmina |
| B / B30-03 | 1 folha Mica A + 1 Mica B | `EXPERIMENTAL_QA_PASS` | 1 par de Espaçadores (2 unidades) | 2 folhas |

Estado **ANTES** de lote: Ardósia apta 2; Mica A 1; Mica B 1. Estado **DEPOIS**: Ardósia apta 1; Mica A 0; Mica B 0. O restante das fichas sintéticas (ardósia pequena/trincada) continua sem modificação. Dois registros de produto experimental, três peças sintéticas, nenhum produto real. Cada ordem possui rastros de 6/5 etapas, 55/30 minutos PROPOSTOS, IDs SBX de lote/produto, prova R47 sob raiz **de TESTE**, custo simbólico sem preço MED, recibos vinculados aos hashes R44/R47/R48.

## Falhas e segurança

- Pedido seguinte de mica com estoque zero: `REJECTED_PRECHECK`, sem consumo e sem produto.
- Documento com assinatura substituída: `QUARANTINE_EVIDENCE`, sem produção nem saldo afetado.
- Crash injetado após preparar primeira ordem e antes do commit: rollback de TODO o lote, seguida de retry bem-sucedido.
- Mesmo batch ID: replay sem novo débito; mesmo ID com outro payload: conflito; mesmo laudo reutilizado para dois pedidos: BLOQUEADO.
- Disputa **em dois processos de sistema operacional** por uma única lâmina: 1 `EXPERIMENTAL_QA_PASS`, 1 `REJECTED_PRECHECK`, 0 oversell, 2 retries idempotentes; persistência e recuperação PASS. Isto **não** equivale ao gateway Notion C19.
- Snapshot e histórico adulterados: detecção por SHA, HEAD, R44/R47 audit e derivação de estoque. Checkpoint gravado sem HEAD: `UNKNOWN_EFFECT` até reconciliação, não repetir cegamente.

## Prontidão RC5

Dossiês `B30-01_PRONTIDAO_RC5.json` e `B30-03_PRONTIDAO_RC5.json`, com matérias-primas PS reais como páginas verificadas, BOM/QA/tempos **propostos**, substitutos comuns, dependências abertas, write-set candidato mínimo. **0/2 dossiês autorizados a virar RC5**. Duas receitas experimentais continuam **2/2**, RC5 oficiais **0/30**.

## Gates/continuidade

`IBX-38=NOVA sem ACK`; `C19-021=UNKNOWN_EFFECT`; `fencing=NOT-DEMONSTRATED`; `F5=P0/RED`; `NAC-PASS material=HOLD`; `Party/O Primeiro=0 writes`; medições físicas verificadas=0. Tudo desenvolvido em `CRAFT-R48-SANDBOX-I0016` com arquivo R47 original preservado. Não se declara liberação material nem sucesso NAC-PASS terminal de produção.

**Próximo alvo R49:** preparar `PLAN_WRITE_SET` RC5 minimizado, anti-duplicata e préflight de relações sobre cópia; em caso de inexistência física de parent, manter PENDENTE. Não ampliar certificados de teste nem número de receitas para inflar progresso.
