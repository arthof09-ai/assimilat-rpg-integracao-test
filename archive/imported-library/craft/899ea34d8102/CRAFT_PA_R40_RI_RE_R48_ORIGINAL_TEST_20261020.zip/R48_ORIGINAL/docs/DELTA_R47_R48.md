# Capacidade comprovável R47 → R48

| Dimensão | R47 preservado | R48 novo, exercitado |
|---|---|---|
| Objetivo operacional | Verificar autenticidade sintética de laudos + custódia assinada | **Processar pedidos de fabricação multiordem** |
| Pedido | `AuthenticityVault.submit_batch` agrupa laudos, **não** ordens de fabricação | `IntegratedFactory.process_batch` agrupa ordens A+B |
| Transformação | R44 individual continuava disponível e separado | Reuso de `SandboxEngine.run` dentro do fluxo do lote |
| Estoque | Simulação R44 por execução individual | **Um ledger sintético compartilhado, reserva projetada antes de cada consumo** |
| Evidência | Assinatura/CA de TESTE R47, sempre sem verificação física | Insumo obrigatório do gate de fabricação; inválido = quarentena **sem consumo** |
| Produto | R44 gera saídas em seu ledger individual | Dois produtos do mesmo pedido, IDs de origem, QA e recibo de lote integrados |
| Consumo duplo | R44 controle por execução e R47 idempotência de laudos | **R48 impede reaproveitar um único laudo em pedidos diferentes** |
| Persistência | R47 snapshot e diretório com mutex | R48 usa mutex e publicação atômica R47 para **estado conjunto de estoque+fabricação+laudos** |
| Concorrência | Testes documentais, sem arbitragem de estoque comum por diferentes pedidos | Dois processos disputaram 1 lâmina: 1 aceitação, 1 rejeição, 0 oversell |
| Integração RC5 | Protocolo de evidências, sem prontidão concreta para dois produtos | **2 dossiês RC5 DRY-RUN** com write-set condicional e lista de lacunas |
| Estado oficial | 0/30 RC5 | **0/30 RC5**, sem mudança no cânone |

Não chamar a capacidade individual de produção R44 de nova, nem inferir autorização de writer C19 da exclusividade local em R47/R48.
