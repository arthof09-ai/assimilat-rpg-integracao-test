PA/CRAFT R40 - ONLY TEST, MESTRE-SIDE.

Extract this ZIP cleanly; open R40/RELATORIO_R40.md.
R48_ORIGINAL/ contains byte-identical original R48 174 tree-files (not a modified fork).
R40/benchmark_re_e0.py and R40/test_r40_e0.py encode 26 explicit canonical technique ranks +2 unclassified.
R40/EXECUTAR_R48_CANARIO_R40.py runs the original actual R48 and rejects the Pingente before mutation.

Run from extracted root:
python R40/benchmark_re_e0.py
python -m unittest discover -s R40 -p 'test_r40_e0.py' -q
python R40/EXECUTAR_R48_CANARIO_R40.py R48_ORIGINAL
cd R48_ORIGINAL && python -m unittest discover -s tests -q

These tests are local and only use the original R48. They cannot establish real magical transfer or production writer/fencing. Do not install to production or Party.
