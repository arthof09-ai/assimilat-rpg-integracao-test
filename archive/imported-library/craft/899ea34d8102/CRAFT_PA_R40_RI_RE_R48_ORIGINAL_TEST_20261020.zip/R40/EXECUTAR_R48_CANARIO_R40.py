"""Authentic R48 original, READ/TEST only. No new recipes or artifact creation.
Imports are from the verified original directory selected by caller.
"""
from pathlib import Path
import json,sys,hashlib,subprocess,copy

EXPECTED={
 'r48_factory.py':'872dc5bf1e588a9ba6f4c45421a4dddbbe7d261842a4e951fd684bfc374c6801',
 'r48_store.py':'e6f684e80e0d5c95dff8ea94cbae985b0a8e046b48886d593d6e49534f046bd1',
 'legacy/CRAFT-R47-SANDBOX-I0016/baseline/CRAFT-R46-SANDBOX-I0016/r46_evidence.py':'c869d80f243b349d817c63bd0c40fc08d7b43c98ce54ec9c91d62cd42c73c85e'}

def verify(root):
 for name,h in EXPECTED.items():
  p=root/name
  if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise ValueError('R48_ORIGINAL_HASH_MISMATCH:'+name)
 return True

def run(root):
 verify(root)
 sys.path.insert(0,str(root))
 from r48_factory import IntegratedFactory,FactoryError
 from r48_fixtures import lots,pair,REVIEW,order
 factory=IntegratedFactory.fixture_factory(lots())
 before=factory.quantities.copy()
 # Authenticate rejection by ORIGINAL validation. Reject even if new recipe is described fully.
 target=order('tli',48100)
 target['recipe_key']='LAB-CRAFT-VIGILIA-BOREAL-20261020-001'
 original_reason=None
 try:
  factory.process_batch('SBX-R48-BATCH-PINGENTE-R40',[target],REVIEW)
 except FactoryError as exc:
  original_reason=str(exc)
 if original_reason!='ONLY_TWO_EXISTING_RECIPES':raise AssertionError('PINGENTE_MUST_NOT_BE_FAKE_ACCEPTED:'+str(original_reason))
 if before!=factory.quantities or factory.journal:raise AssertionError('R48_MUTATED_ON_REJECTION')
 # Authenticated original positive *synthetic* canary, not item crafting.
 ok=factory.process_batch('SBX-R48-BATCH-R40-BASELINE',pair(index=48090),REVIEW)
 if len(ok['orders'])!=2 or ok['status']!='ALL_SYNTHETIC_QA_PASS' or ok['physical_products']!=0 or ok['official_stock_effect']!=0:raise AssertionError('R48_NATIVE_BASELINE_WRONG')
 audit=factory.audit()
 if not audit['ok']:raise AssertionError('R48_NATIVE_LEDGER_AUDIT_FAILED')
 return {'result':'PASS_R48_NATIVE_ORIGINAL_CANARY','original_source_hashes':EXPECTED,
   'pingente_native_acceptance':'REJECTED_BY_AUTHENTIC_R48',
   'pingente_rejection_reason':original_reason,
   'pingente_stock_unchanged_before_positive':True,
   'positive_control':'TLI/MICA ONLY, SYNTHETIC','positive_status':ok['status'],
   'positive_recipe_orders':2,'physical_products':ok['physical_products'],
   'official_stock_effect':ok['official_stock_effect'],
   'audit_original_r48':audit['ok'],'craft_f5_prod':'RED','c19_021':'UNKNOWN_EFFECT',
   'magic_transfer_proven':False,'rc5_production':False}

if __name__=='__main__':
 root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent/'R48_ORIGINAL'
 res=run(root)
 print(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True))
