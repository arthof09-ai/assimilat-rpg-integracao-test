import unittest
from benchmark_re_e0 import *
class RankVsEvidence(unittest.TestCase):
    def test01_counts(self): self.assertEqual(summary()['rotulos_re_e0'],26)
    def test02_unranked(self): self.assertEqual(summary()['sem_classificacao'],2)
    def test03_categories(self): self.assertEqual(summary()['por_rank'],{'Bronze':2,'Prata':6,'Ouro':12,'Ouro Negro':5,'Lendário':1})
    def test04_no_fake_accuracy(self): self.assertIsNone(summary()['acuracia_mecanica'])
    def test05_no_price_inference(self): self.assertTrue(all(not x['preco_usado'] for x in documents()))
    def test06_url_unique(self):self.assertEqual(len({x['fonte'] for x in documents()}),26)
    def test07_nominal_independent_from_item(self): self.assertTrue(all(x['rank_tipo'].startswith('RE_') for x in documents()))
    def test08_text_mechanics_missing(self): self.assertTrue(all(not x['mecanica_lida_independentemente'] for x in documents()))
    def test09_no_prediction_without_mechanics(self):self.assertEqual(evaluate({},{} )['denominator'],0)
    def test10_no_prediction_without_mask(self):self.assertEqual(evaluate({},dict(descricao_mecanica_independente_revisada=True))['denominator'],0)
    def test11_no_prediction_with_empty(self):self.assertEqual(evaluate({},dict(descricao_mecanica_independente_revisada=True,predictions_frozen_before_unmask=True))['denominator'],0)
    def test12_error_no_objects(self):
      with self.assertRaises(TypeError):evaluate(None,{})
    def test13_limit_holdout(self):
      x=evaluate({'INVALID':{'rank_proposto':'Bronze','mecanica_completa_verificada':True}},dict(descricao_mecanica_independente_revisada=True,predictions_frozen_before_unmask=True))
      self.assertEqual(x['denominator'],0)
    def test14_one_scored_only_if_verified(self):
      k=documents()[0]['notion_page_id'];x=evaluate({k:{'rank_proposto':'Bronze','mecanica_completa_verificada':True}},dict(descricao_mecanica_independente_revisada=True,predictions_frozen_before_unmask=True))
      self.assertEqual(x['denominator'],1);self.assertEqual(x['correct'],1);self.assertEqual(x['coverage'],1/26)
    def test15_unknown_separated(self):
      k=documents()[0]['notion_page_id'];x=evaluate({k:{'rank_proposto':'Prata','mecanica_completa_verificada':False}},dict(descricao_mecanica_independente_revisada=True,predictions_frozen_before_unmask=True))
      self.assertEqual(x['denominator'],0)
    def test16_ranks_known(self): self.assertEqual(set(RANKS),{'Bronze','Prata','Ouro','Ouro Negro','Lendário'})
    def test17_docs_all_images(self): self.assertEqual(sum(d['mecanica_exclusivamente_em_imagem'] for d in documents()),26)
    def test18_e0_does_not_mean_empirical(self): self.assertIsNone(summary()['acertos_sem_predicoes'])
    def test19_names_unique(self):self.assertEqual(len(set(n for n,_,_ in DOCS)),26)
    def test20_source_index(self):self.assertIn('3edc2b324ede81a5b6a8c5a27f0f3aff',SOURCE_INDEX)
if __name__=='__main__': unittest.main()
