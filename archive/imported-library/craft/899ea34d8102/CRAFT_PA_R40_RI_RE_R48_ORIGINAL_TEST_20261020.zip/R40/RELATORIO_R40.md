# PSV R40 — RI/RE canônicos, holdout real e R48 recuperado

AS-OF 20/10/2026 — MESTRE-SIDE — LAB TEST — Ordem direta do Mestre.

## 1. Ranks existentes — não há conflito de existência
- **RI (Rank do Item)**: classificação do item inteiro, pelo ganho mecânico que acrescenta (Atlas PR-ECO-01 Anexo A, §§2.4/10/19).
- **RE (Rank de Efeito)**: patamar de uma habilidade individual do item ou magia/técnica (§2.2). O cálculo por habilidade usa RE; o piso diário usa RI. **RIn** classifica insumo; **RU**, usuário. Não deduzir RE automaticamente de RI nem RI de RIn.
- Itens não possuem estrelas como classificação pública (Atlas nota de revisão); FIP interna pode existir sem criar estrelas de itens.

## 2. Gabarito nominal independente recuperado (26 técnicas)
Origem viva: https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff
Foram reabertas as páginas Mestre correspondentes ao índice. **26/26 habilidades rotuladas com classificação própria**: Bronze 2, Prata 6, Ouro 12, Ouro Negro 5, Lendário 1. Duas habilidades adicionais (Passos do Vazio e Tabela do Caos) não têm rank E0 e permanecem SEM CLASSIFICAÇÃO documental.
**Correção da pendência R39:** há 26 rótulos RE E0 *nominais*. R39 usava um corpus diferente (itens/insumos) e não os havia contemplado. As mecânicas destas 26 técnicas estão essencialmente em blocos de imagem, não transcritas nas páginas de leitura; por isso, **26 ranks documentados ≠ 26 testes cegos completos, 0 previsões mecânicas admissíveis nesta passagem, acurácia (%) não mensurável**. Não imputar 0% ou 100% de acerto. A pesquisa do mecanismo e a imagem precisam de leitura independente antes de congelar previsão cega.

## 3. CRAFT R48 — binário original encontrado e executado
Origem: `/Comestre/CRAFT-COMESTRE-CHAT-v03.zip` (e arquivo raiz correspondente). SHA256 do ZIP histórico: `5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434`.
Árvore preservada `CRAFT-COMESTRE-CHAT-v03/Oficina-v02/CRAFT-R48-SANDBOX-I0016/`: **174 entradas**. Hash original do `r48_factory.py` `872dc5bf1e588a9ba6f4c45421a4dddbbe7d261842a4e951fd684bfc374c6801`; `r48_store.py` `e6f684e80e0d5c95dff8ea94cbae985b0a8e046bd1`; R46 `c869d80f243b349d817c63bd0c40fc08d7b43c98ce54ec9c91d62cd42c73c85e`. Sem alterações.
**40/40 testes nativos PASS nesta sessão.** A cadeia de regressão original R44–R47 também foi executada nesta sessão: R44=52/52, R45=64/64, R46=70/70, R47=87/87, somando **273/273 PASS**. Com 510 testes R39 frescos e 20 testes R40 de rank, há **843/843 testes distintos por suíte** (os 40 R48 incluídos). Canário de R48 autêntico: duas receitas sintéticas históricas TLI/MICA PASS, produto físico=0, estoque produtivo=0; pedido com `LAB-CRAFT-VIGILIA-BOREAL-20261020-001` rejeitado por `ONLY_TWO_EXISTING_RECIPES`, estoque/journal preservados e auditoria R48 PASS. **Não foi executado o Pingente no motor de transformação; não foi observada magia.**
A entrega contém uma **cópia EXATA** da árvore original, empacotada separadamente para que o executor não precise extrair 43 MB de chat anterior. Isso não significa um motor novo ou runtime produtivo. O conteúdo do laboratório CRAFT E11–E20 não deve ser sobrescrito.

## 4. Controle ativo de implantação, F5 e governança
- **A / calculador PA assistido**: prova TEST no R39; execução fresca do runner R39 **510/510 PASS**, motores R26/R27 com SHA preservado. Botas = 25/dia+6 usos=31; Pingente =12/dia+14 usos=26. Uma descrição de item RI Ouro pode conter RE Bronze e RE Prata, cada qual tarifado separadamente.
- **B / QMC-05 nativo LAB**: R28 TEST PASS; entrypoint oficial CRAFT não comprovadamente modificado, TEE produtivo HOLD. A cópia R48 autêntica agora é recuperável para a bancada específica; não herda writer/lease.
- **C / F5 material e receita**: RED, C19-021 UNKNOWN_EFFECT em fontes oficiais, STOP-ACK/RELEASE/fencing não comprovados. O R48 só processa duas receitas históricas; para o Pingente é necessária extensão TEST controlada + receita/QA/mecanismo independentes e controles físicos simulados explicitamente. Um teste sintético não comprova criação de um item mágico.
- Para liberação técnica real, executor competente deve verificar token/epoch com serviço efetivo que impeça predecessor e readback do C19-021. O conector Notion observado não fornece por si só essa garantia. **Não declarar GREEN/fabricação/P4/RC5 por autorização textual isolada**.

## 5. Próxima ação que remove o maior bloqueio
1. Entregar ao executor CRAFT o ZIP R48 miniaturizado, com seus 174 arquivos originais e manifesto, sem nova operação.
2. Fazer canário de recebimento de ZIP e aplicar adaptador do Pingente **apenas numa cópia LAB**, com controles de rejeição sem QA, garantindo que R44/R47 não sejam substituídos.
3. Para rank RE mensurado, recuperar e ler as 26 imagens mecânicas anexas, preparar holdout cego sem revelar rank ao classificador; congelar previsões e só então comparar com os rótulos já verificáveis.
4. Para produção F5, cumprir reconciliação C19-021 + STOP-ACK/RELEASE + fencing comprovado do escritor legítimo. Os passos 2 e 3 podem avançar enquanto F5 permanece HOLD.

Links principais:
- Atlas RI/RE: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- Técnicas: https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff
- Laboratório CRAFT: https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00
- Operação CRAFT: https://app.notion.com/p/3f1c2b324ede81d7aa79c83106240516
- Inbox CRAFT IBX-116: https://app.notion.com/p/3ffc2b324ede817aa3abea3cb7ba8c08

NAC-PASS proporcional: **PASS LAB (reconciliação de RI/RE, labels E0 nominais, entrega do R48 original e canários)**; **HOLD PROD para escritor, implantação QMC-05, transferência mágica e fabricação F5**. Nenhuma alteração em Party/O Primeiro/REC-LIB/fichas/itens históricos.
