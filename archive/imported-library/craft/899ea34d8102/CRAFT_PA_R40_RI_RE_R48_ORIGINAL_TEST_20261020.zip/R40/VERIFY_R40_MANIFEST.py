"""Check manifest from clean extraction, no network or mutable sources."""
import json,hashlib,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((Path(__file__).resolve().parent/'MANIFEST_R40.json').read_text('utf8'))
for name,expected in d['sha256_files'].items():
 p=ROOT/name
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise SystemExit('MANIFEST_FAIL:'+name)
print('PASS_MANIFEST_R40',len(d['sha256_files']))
