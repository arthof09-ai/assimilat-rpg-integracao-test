"""R40: baseline documental de classificacoes das TECNICAS (rank da habilidade).
O Atlas estabelece RE, RI, RIn como dominios distintos. Este modulo NAO
inventa mecanicas que so constam em imagens; NAO estima ranks por titulos.
"""
from __future__ import annotations
import json,hashlib,re
from pathlib import Path

VERSION='PA-RE-HOLDOUT-R40/1.0-TEST'
SOURCE_INDEX='https://app.notion.com/p/3edc2b324ede81a5b6a8c5a27f0f3aff'
DOCS=(
 ('Rajada Mística', 'Bronze','3edc2b324ede8132b862ce2d6efc860a'),
 ('Criar Fogueira','Bronze','3edc2b324ede8165a948c6b6c6c9ab62'),
 ('Sentido Bestial','Prata','3edc2b324ede81319cbaf75263c48326'),
 ('Faca de Gelo','Prata','3edc2b324ede8118a6dce655e4a9b884'),
 ('Lufada','Prata','3edc2b324ede81559680d84589ccfb0f'),
 ('Marca do Caçador','Prata','3edc2b324ede81cda339e07d2ccb64ce'),
 ('Raio de Fogo','Prata','3edc2b324ede8136a10ce73a25d04b3a'),
 ('Ataque Certeiro','Prata','3edc2b324ede81eead95fb791a31b0e0'),
 ('Golpe de Zephyr','Ouro','3edc2b324ede81c8a686c4740ad5dc57'),
 ('Destruição Trovejante','Ouro','3edc2b324ede81c5945ee5cbb1d6a59d'),
 ('Vínculo Com a Besta','Ouro','3edc2b324ede81c5b989eb157f7ce817'),
 ('Repreensão Infernal','Ouro','3edc2b324ede816fb2bed9b071790a96'),
 ('Servo Invisível','Ouro','3edc2b324ede81218562dbce3eb3124a'),
 ('Benção','Ouro','3edc2b324ede81a0a72af24c15df234a'),
 ('Perdição','Ouro','3edc2b324ede81fab67cd15d31615852'),
 ('Destruição Lancinante','Ouro','3edc2b324ede81e3953ad588986b81be'),
 ('Toque Chocante','Ouro','3edc2b324ede81f79aaaeb6c8c10729e'),
 ('Escudo Arcano','Ouro','3edc2b324ede816c8caae26f25e60379'),
 ('Golpe Constritor','Ouro','3edc2b324ede816ea8dae4a171d1d467'),
 ('Saraivada de Espinhos','Ouro','3edc2b324ede81328e2ddeaf4ac3f848'),
 ('Amizade Animal','Ouro Negro','3edc2b324ede8125a87ec820ba101cf6'),
 ('Enfeitiçar Pessoa','Ouro Negro','3edc2b324ede81fd9147d9518152e6a9'),
 ('Orbe Cromática','Ouro Negro','3edc2b324ede81f0975ae7f082c71a1c'),
 ('Falar Com Criaturas','Ouro Negro','3edc2b324ede8132a019f922defa6b57'),
 ('Proteção Contra Lâminas','Ouro Negro','3edc2b324ede81b2b59af3663ea006ec'),
 ('Imobilizar Pessoa','Lendário','3edc2b324ede813f9795d406af37b1b9'),
)
UNLABELED=(('Passos do Vazio','3edc2b324ede81a0b7e8d2368d7e1def'),
           ('Tabela do Caos','3edc2b324ede81629695c21c7e9a6f01'))
RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário')

def documents():
    return [dict(habilidade=n,rank_de_efeito_documentado=r,fonte=f'https://app.notion.com/p/{id}',
                notion_page_id=id,rank_tipo='RE_TECNICA_EXPLICITO_E0_NOMINAL',
                mecanica_exclusivamente_em_imagem=True,mecanica_lida_independentemente=False,
                status='RANK_E0_ROTULADO; MECANICA_AINDA_NAO_OBTIDA',
                evidencia='Texto classificatorio proprio na ficha da TECNICA; Atlas §18',
                preco_usado=False) for n,r,id in DOCS]

def summary():
    arr=documents()
    return dict(versao=VERSION,indice=SOURCE_INDEX,corpus_total=len(arr)+len(UNLABELED),
        rotulos_re_e0=len(arr),sem_classificacao=len(UNLABELED),
        por_rank={r:sum(d['rank_de_efeito_documentado']==r for d in arr) for r in RANKS},
        mecanicas_textuais_completas=0,
        acuracia_mecanica=None,acertos_sem_predicoes=None,
        regra='26 rotulos oficiais de tecnica/habilidade != 26 acertos do classificador. Faltam mecanicas independentemente lidas para comparacao cega.',
        efeito_nao_e_item=True,metodo='Fichas de Tecnicas Mestre reabertas individualmente em 20/10/2026',
        fontes_nao_rank=[dict(habilidade=n,fonte=f'https://app.notion.com/p/{id}') for n,id in UNLABELED])

def evaluate(predictions:dict,methodology:dict)->dict:
    """Accuracy requires independent description + model prediction made while labels masked.
    Gate is intentionally strict: UNKNOWN is not scored as mistake or success.
    """
    if not isinstance(predictions,dict) or not isinstance(methodology,dict):raise TypeError('INPUT_NOT_OBJECT')
    if not methodology.get('descricao_mecanica_independente_revisada'):
        return {'accuracy':None,'denominator':0,'status':'HOLD_MECANICAS_IMAGEM_NAO_INSPECIONADAS',
                'rank_labels_available':26,'reason':'Gabarito RE nominal existe, mas mecanica nao revisada para teste cego.'}
    if not methodology.get('predictions_frozen_before_unmask'):
        return {'accuracy':None,'denominator':0,'status':'HOLD_SEM_PREDICAO_CEGA',
                'rank_labels_available':26}
    allowed={d['notion_page_id']:d for d in documents()}
    admitted=[];unknown=[]
    for k,v in predictions.items():
        if k not in allowed:unknown.append(k);continue
        if not isinstance(v,dict) or not v.get('mecanica_completa_verificada') or v.get('rank_proposto') not in RANKS:
            unknown.append(k);continue
        admitted.append((k,v['rank_proposto'],allowed[k]['rank_de_efeito_documentado']))
    if not admitted:
        return {'accuracy':None,'denominator':0,'status':'HOLD_0_PREDICOES_ADMITIDAS','unknown':unknown}
    matches=sum(p==gold for _,p,gold in admitted)
    return {'accuracy':matches/len(admitted),'correct':matches,'denominator':len(admitted),
            'coverage':len(admitted)/26,'unknown':unknown,'status':'SCORED_SUBSET_ONLY; NUNCA POPULACAO INTEIRA'}

def main():
    root=Path(__file__).resolve().parent
    (root/'RE_E0_26_INDEX.json').write_text(json.dumps({'summary':summary(),'techniques':documents()},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(summary(),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
