# CRAFT — R38 / duas divergências de identidade material (MESTRE-SIDE TEST)

**Leitura direta no Notion em 22/10/2026; nenhuma edição.** Reutiliza os casos BAT-02 e BAT-14 já existentes na fila R27; não cria regras, receitas nem tickets.

## BAT-02 — Faca Voadora Solar

[Fonte física Mestre](https://app.notion.com/p/3edc2b324ede8128b520c8296137a60e) · último carimbo 02/10/2026.

A BOM prevê `4x Orvalho de Solstício`; a primeira etapa utiliza `Pó de Solstício`. É preciso decisão autoral sobre identidade material, processamento, unidade e rendimento. O fato de ambos conterem “Solstício” não demonstra equivalência nem criação de pó a partir de orvalho.

## BAT-14 — Bomba Dracônica

[Fonte física Mestre](https://app.notion.com/p/3edc2b324ede8135a616ea2f5c509d35) · último carimbo 02/10/2026.

A BOM determina `2x Cinzas de Dragão Negro`, mas origem e processo dizem genericamente `Cinzas de Dragão`. É necessário conferir subtipo físico e fonte.

A BOM determina `1x Coração de Titã`, enquanto a origem e o processo empregam `Lágrimas de Titã`. São materiais diferentes até decisão e fonte que sustentem qualquer transformação ou equivalência.

## Contagem preservada

Dos **21 casos** com divergências no corpus de **29 receitas**, agora **8 casos** possuem perguntas autorais aprofundadas (3 R30, 3 R36, 2 R38); **13 casos** continuam pendentes de aprofundamento. Existem **23 perguntas preparadas** entre R30/R36/R38, **0 decisões autenticadas**. Oito receitas restantes sem divergência lexical detectada não são RC5.

**Gates:** IBX38/116/R51 NOVA+ACK; C19-021 UNKNOWN; fencing e destino físico REC-LIB não comprovados; Notion nesta conexão sem update; RC5/P4/PROD HOLD, Party/O Primeiro NO-WRITE. Toda resposta futura requer autenticação do Mestre e releitura canônica antes de edição autorizada.
