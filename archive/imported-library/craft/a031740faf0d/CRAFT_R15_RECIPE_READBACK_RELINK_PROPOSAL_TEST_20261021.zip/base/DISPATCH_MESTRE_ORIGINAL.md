# CRAFT — Despacho decisório único (MESTRE-ONLY)

**Escopo:** sem inventar decisões. Este é um adendo à **IBX-116 existente**, não 21 novas tarefas. Fonte: 29 receitas-filhas dentro dos 34 padrões Mestre, observadas em 21/10/2026. **21 com divergências documentais; 8 com presença apenas lexical.**

## Ordem causal para destravar trabalho real

1. **F5/P0:** obter fencing técnico externo contra instância anterior (IBX-38), avaliar C19-021 e autoridade de writer. Sem isso, nenhuma mudança em fontes, RC5 ou migração.
2. **Óleo de Vedação (upstream):** um insumo textual de 28/29 receitas-filhas. Autorizar a fórmula correta (3x Pó Ferro Celestial Mestre, não 2x histórico), conciliar orvalho/essência do processo, definir lote/porção/rendimento/QA. Não calcular ferro total sem rendimento.
3. **P2 Vedação:** reutilizar P2-SALT-01 e P2-ENERGY-02; reconciliar identidade do sal e operação exclusiva de energização. Localizar fontes/lotes/operador e verificar compatibilidade.
4. **Matrizes Cultivo/Proteção:** definir target para menção quebrada 707d83314e7c40cd89bc70fb240e6076 e quantidade `Ex`; Espelho Mestre Party não conserta por si.
5. **Demais 21 divergências:** decisões por fonte/versão, uma por vez, sem corrigir nomes por semelhança.
6. **R51:** preservar os 29 IDs físicos, não duplicar cinco receitas embutidas ou matriz sem receita, e não mover antes de um parent confirmado e writer verde.

## Fila de 21 receitas com divergência BOM ↔ processo

| Prioridade | Padrão | Problema documentado | Fonte Mestre |
|---|---|---|---|
| P0_RECEITA_P2 | ENC-08 | Sal de Geodo Santo vs Encantado; Pedra da Luz OU Pote Essência Mágica sem etapa explícita | [Receita](https://app.notion.com/p/3edc2b324ede811783dfce62058ca6b8) |
| P1_REFERENCIA_CONSUMO | MAT-03 | linha de ingrediente sem nome: 1x :; Terra Encantada vs Terra de Gigante; Essência de Água da Nascente vs Água de Nascente Élfica | [Receita](https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6) |
| P1_REFERENCIA_CONSUMO | MAT-06 | quantidade do Pó Quartzo Fantasma: Ex (inválida sem resolução autoral); Sopro Vento Mundial vs Sopro Vento Ancestral; Óleo e energizador BOM sem etapa explícita | [Receita](https://app.notion.com/p/3edc2b324ede8129a6c3cfb603027383) |
| P1_PROCESSO | BAT-08 | Pó de Basalto Esplosivo BOM não consumido em etapa própria; Óleo de Criaturas Infernais vs Óleo de Criatura Infernal | [Receita](https://app.notion.com/p/3edc2b324ede81678729e720e953e776) |
| P1_PROCESSO | MAT-01 | chuva de Eclipse Lunar vs Pó de Eclipse Lunar; Teia Sombra Etérea vs Véu Sombra Etérea; Óleo/energizador BOM sem etapas explícitas | [Receita](https://app.notion.com/p/3edc2b324ede81f8a604de666d828b2d) |
| P1_PROCESSO | MAT-05 | Essência de Portal vs Essência de Buraco Negro; Lírio do Vazio vs Fragmentos de Cometa; Cinza Besta Cósmica vs Cinza Dragão Cósmico; Óleo e energizador BOM sem etapa explícita | [Receita](https://app.notion.com/p/3edc2b324ede810f8b29cb9f85cc9776) |
| P2_IDENTIDADE | BAT-02 | Orvalho de Solstício vs Pó de Solstício | [Receita](https://app.notion.com/p/3edc2b324ede8128b520c8296137a60e) |
| P2_IDENTIDADE | BAT-03 | Pó de Gelo Eterno vs Pó do Gelo Eterno; Sopro congelante vs Sopro do Congelante | [Receita](https://app.notion.com/p/3edc2b324ede8156a0fcd3c1e7f9dd68) |
| P2_IDENTIDADE | BAT-04 | Cristais de Gelo Eterno vs Cristais de Gelo Profundo; Essência de Vento Ártico vs Essência de Vento Polar | [Receita](https://app.notion.com/p/3edc2b324ede81c7b50cf545f360f929) |
| P2_IDENTIDADE | BAT-06 | Pó de Cometa Solar vs Pó de Cometa; Essência de Chama Eterna vs Óleo de Chama Eterna; Girassol Místico vs Pétalas de Girassol Místico | [Receita](https://app.notion.com/p/3edc2b324ede81409336ca9a06f72779) |
| P2_IDENTIDADE | BAT-11 | Fragmentos de portais vs Fragmentos de Espelho do Destino | [Receita](https://app.notion.com/p/3edc2b324ede81638027f824ec17667e) |
| P2_IDENTIDADE | BAT-12 | Sangue de Besta Demoníaca vs Sangue de Hidra Carmesim | [Receita](https://app.notion.com/p/3edc2b324ede8149a54ffa0487ba887a) |
| P2_IDENTIDADE | BAT-13 | Essência de Sopro do Leviatã vs Essência do Sopro do Leviatã | [Receita](https://app.notion.com/p/3edc2b324ede8166a324c6e584495526) |
| P2_IDENTIDADE | BAT-14 | Cinzas de Dragão Negro vs Cinzas de Dragão; Coração de Titã vs Lágrimas de Titã | [Receita](https://app.notion.com/p/3edc2b324ede8135a616ea2f5c509d35) |
| P2_IDENTIDADE | ENC-01 | Folhas do Sussurro Congelados (BOM) vs Folhas de Mintaur (passo) | [Receita](https://app.notion.com/p/3edc2b324ede819e850de7e272c1032e) |
| P2_IDENTIDADE | ENC-02 | Cinzas Coração Flamejante vs Cinzas do Coração Flamejante; alias morfológico não aprovado | [Receita](https://app.notion.com/p/3edc2b324ede81b4b912f3f1a8adfd5a) |
| P2_IDENTIDADE | ENC-06 | Essência Sangue das Sombras vs Essência de Sombra | [Receita](https://app.notion.com/p/3edc2b324ede813ca572c8b98443d53f) |
| P2_IDENTIDADE | MAT-01 | Cristais de Alma 2P vs Cristais de Mana Puro; Óleo e energizador alternativo BOM sem passo explícito | [Receita](https://app.notion.com/p/3edc2b324ede81b2b826ef6f6d30dc6c) |
| P2_IDENTIDADE | MAT-02 | Cristais de Gelo de Eterno vs Cristais de Gelo de Gigante; Pena de Asa Harpia vs Poeira de Asa Harpia; Espírito Demoníaco e Óleo BOM sem uso explícito | [Receita](https://app.notion.com/p/3edc2b324ede818a9124ea756f3e1b72) |
| P3_DOCUMENTO | BAT-10 | Sequência de etapas 1,2,3,bullet,1,2; reformatação sem alterar materialidade exige revisão | [Receita](https://app.notion.com/p/3edc2b324ede811abbb8f43d0b642f5d) |
| P3_DOCUMENTO | MAT-04 | Óleo de Vedação e energizador 5x alternativo na BOM sem passo explícito | [Receita](https://app.notion.com/p/3edc2b324ede81bbaa36e7023f74fca0) |

## Sem atalho de produção

Dossiê técnico não substitui decisão autoral, lote, operador, controle físico, PA ou magia. A página de ingrediente, inclusive sob Mestre Itens, não equivale a estoque. Fontes do Espelho do Mestre da Party são somente leitura e não alteram a receita Mestre. F5 RED, C19 UNKNOWN-EFFECT, H2-3A/B HOLD, nenhuma receita RC5 ou P4 foi criada. Não há ACK, INSTANCE-ID ou fencing assumido.

**Ponto de retomada:** resposta da fonte competente na IBX-116 para P2/OIL e da IBX-38 para fencing; depois verificação material e microbloco autorizado.
