"""Somente consistência do snapshot TEST de 29 fontes; não consulta Notion nem concede writer."""
from pathlib import Path
import csv,json,unittest,datetime
ROOT=Path(__file__).resolve().parents[1]
class TestR15(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with (ROOT/'R15_READBACK_29_RECIPES.csv').open(encoding='utf-8') as f:
            cls.rows=list(csv.DictReader(f))
        with (ROOT/'base/DECISIONS_21_ORIGINAL.csv').open(encoding='utf-8-sig') as f:
            cls.dossier=list(csv.DictReader(f))
        cls.summary=json.loads((ROOT/'R15_SUMMARY.json').read_text())
    def test_denominator(self):self.assertEqual(len(self.rows),29)
    def test_uuid_unicity(self):self.assertEqual(len({x['physical_recipe_uuid'] for x in self.rows}),29)
    def test_docket_denominator(self):self.assertEqual(len(self.dossier),21)
    def test_docket_subset(self):self.assertEqual({x['physical_recipe_id'] for x in self.dossier},{x['physical_recipe_uuid'] for x in self.rows if x['docket_class']=='DIVERGENCE_DOCUMENTED'})
    def test_unflagged_eight(self):self.assertEqual(sum(x['docket_class']=='NO_DIVERGENCE_IDENTIFIED_IN_DOCKET' for x in self.rows),8)
    def test_oil_presence(self):self.assertEqual(sum(x['oil_mentioned']=='YES' for x in self.rows),29)
    def test_oil_bom(self):self.assertEqual(sum(x['oil_named_in_BOM']=='YES' for x in self.rows),28)
    def test_only_one_broken(self):self.assertEqual([x['case_key'] for x in self.rows if x['oil_named_in_BOM']=='NO'],['MAT-03'])
    def test_mat_parent_stable(self):self.assertEqual([x['physical_recipe_uuid'] for x in self.rows if x['case_key']=='MAT-03'],['3edc2b324ede81faafa2ce406944d9b6'])
    def test_no_post_docket_edits(self):self.assertTrue(all(x['after_2026_10_21_docket']=='NO' for x in self.rows))
    def test_edited_before_docket(self):self.assertTrue(all(x['live_last_edited']<'2026-10-21T14:46:00Z' for x in self.rows))
    def test_all_master_page_urls(self):self.assertTrue(all(x['url']=='https://app.notion.com/p/'+x['physical_recipe_uuid'] for x in self.rows))
    def test_no_write(self):self.assertTrue(all(x['decision_status']=='HOLD_NO_WRITE' for x in self.rows))
    def test_summary_valid(self):self.assertEqual(self.summary['oil_named_in_BOM'],28)
    def test_broken_link_distinct(self):self.assertNotEqual(self.summary['broken_mention_uuid'],self.summary['candidate_oil_master_item_uuid'])
    def test_hypothesis_explicit(self):self.assertIs(self.summary['candidate_is_inferred_not_validated_historical_link'],True)
    def test_party_nowrite(self):self.assertIs(self.summary['party_modified'],False)
    def test_material_nowrite(self):self.assertEqual(self.summary['material_write_count'],0)
if __name__=='__main__':unittest.main()
