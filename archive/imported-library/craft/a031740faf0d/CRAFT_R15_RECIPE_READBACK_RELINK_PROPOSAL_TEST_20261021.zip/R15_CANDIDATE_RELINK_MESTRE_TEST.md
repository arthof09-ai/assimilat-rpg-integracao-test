# CRAFT R15 — Reconciliação 29/29 e correção PROPOSTA (sem escrita)

**Autoridade:** MESTRE-SIDE / TEST / EXISTING-FIRST. **Objeto:** conservação do dossiê existente de 21 divergências, não é nova norma, motor, receita ou ticket. Fontes consultadas: 29 páginas-filha Mestre (Notion, todas reabertas), inventário `AUD-PRE14-01 — Controle de Receitas — 29 páginas`, dossiê CRAFT_DECISION_DOCKET_34_20261021.zip, páginas Mestre de Óleo e Matriz de Cultivo, e cópias identificadas dentro de Party (Mestre — Espelho) apenas em READ-ONLY.

## ANTES (dossiê que deve ser preservado)

- 29 páginas de receita nos 34 padrões; 21 divergências BOM/processo registradas e oito sem divergência identificada no recorte. Não afirmar 8 homologadas.
- Indicador upstream: **28/29 receitas com Óleo de Vedação textualmente nomeado na BOM**.
- Na Matriz de Cultivo, ingrediente de `1x` aparece sem nome por uma menção a UUID `707d83314e7c40cd89bc70fb240e6076` inacessível. Página pai e receita Mestre são existentes, não faltam.
- F5 P0 RED, C19-021 UNKNOWN-EFFECT, IBX-38 fencing técnico não demonstrado; R51 parent físico da biblioteca de receitas ainda sem decisão. Sem direito de mutação de receitas, F5, RC5 ou Party.

## DEPOIS: observações verificadas por leitura direta

1. **29/29 páginas de receita** reabertas sob 29 UUIDs distintos, editadas pela última vez em 02/10/2026 (antes do dossiê de 21/10). **0 alterações pós-dossiê identificadas no carimbo das páginas**; isso não substitui diff de conteúdo quando houver mudança de origem.
2. **29/29 páginas mencionam Óleo de Vedação em algum local**. **28/29 nomeiam Óleo na lista de ingredientes**. A exceção não é erro de denominador: `MAT-03`, Receita (P) da Matriz de Cultivo, <https://app.notion.com/p/3edc2b324ede81faafa2ce406944d9b6>, contém `1x <mention UUID=707d...6076> :` com descrição de óleo de selamento, e mais abaixo a seção de localização menciona explicitamente `Óleo de Vedação`; o campo de ingrediente está nominalmente ilegível. Não aplicar peso de óleo 29/29 em BOM nem derivar 29 lotes utilizáveis.
3. O **pai correto da receita** já existe na árvore Itens Mestre: <https://app.notion.com/p/3edc2b324ede81fe98faf689b2750291>, filho de Matrizes > Padrões de Inscrições. Outra Matriz de Cultivo homônima pertence a `Party (Mestre — Espelho)`: não usar como destino de escrita.
4. O **candidato para o LINK DO INGREDIENTE** é a ficha Mestre **Óleo de Vedação** <https://app.notion.com/p/3edc2b324ede81f1a88ec69980ab6cfd>, existente em Itens > Consumíveis & Alquimia > Poções; a lista de ingredientes Mestre registra **3x Pó de Ferro Celestial**, diferindo de cópia histórica de **2x** encontrada na Party (Mestre — Espelho). Outra página de Óleo está em Inventário do Espelho, não é fonte canônica Mestre. Essas cópias foram apenas diferenciadas por ancestralidade: **0 escrita Party**.
5. O alvo histórico exato do link `707d...6076` **NÃO FOI RECUPERADO** (acesso NOT_FOUND). Correspondência ao óleo Mestre é **INFERIDA fortemente** pela função material e pela lista de localização, **não** prova matemática de identidade do UUID antigo. Nenhuma alteração foi aplicada.

## Micromudança apenas PROPOSTA, após gate válido

- **Local exclusivo a reparar:** span do ingrediente `1x <mention antiga UUID 707d...6076>` na **receita Mestre Matriz de Cultivo**, UUID `3edc2b324ede81faafa2ce406944d9b6`.
- **Candidato físico de referência:** `3edc2b324ede81f1a88ec69980ab6cfd` (Óleo de Vedação Mestre). Preservar quantidade `1x`, descrição original, URL e UUID da receita, parent, BOM remanescente, relações e Party.
- **Pré-condições obrigatórias:** confirmação pelo Mestre/autor competente ou prova de linhagem se disponível, verificação técnica do fencing C19-021/IBX-38, writer legítimo/lease/epoch/safe-point, e verificação de colisão NAC-CONT/NAC-PASS. Sem uma dessas condições, **HOLD/NO-WRITE**.
- **Gates após eventual autorização:** leitura ANTES, troca de um único link, readback do UUID da receita, auditoria do link de origem, integridade/rollback, contagem física 29/29, sem criar nova receita nem promover RC5. Uma referência corrigida não resolve automaticamente outros conflitos materiais da MAT-03 (Terra Encantada vs Terra de Gigante; Água da Nascente vs Água de Nascente Élfica), falta de etapa de óleo, alternância energizadora e laudo físico.
- **Não alterar fórmula do próprio óleo**: a BOM Mestre com 3x Pó de Ferro Celestial ainda diverge do processo (Orvalho de Dragão / Essência de Vórtice vs orvalho do Amanhecer / Essência de Lua Minguante). Requer outra decisão e prova real de produção/rendimento antes de lotes.

## NAC-PASS proporcional

PASS: descoberta + contagem documental + ancestralidade + identificação de candidato e preservação da fonte anterior. HOLD: equivalência histórica exata do link, substituição física, validação material, R51/RC5/P4/F5/PRODUÇÃO, ACK e writer. Party/O Primeiro NO-WRITE. Próximo exato: obter autorização técnica e da fonte para um **link** no futuro, caso o Mestre a conceda; enquanto RED, continuar melhorias isoladas do CRAFT e investigações read-only sem multiplicar tickets.
