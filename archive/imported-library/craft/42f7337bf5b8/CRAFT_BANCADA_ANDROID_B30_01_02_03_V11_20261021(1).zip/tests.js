const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const L=require('./logic.js');let tests=0;
function check(name,fn){try{fn();tests++;console.log('PASS',name);}catch(e){console.error('FAIL',name,e.message);process.exitCode=1;}}
const base=(type='tli')=>({type,sample_id:'A1',lot_id:'L1',operator:'operador TEST',instrument_id:'micrometro TEST',calibration_reference:'REF TEST',date_time:'2026-10-21T12:00',witness:'',uncertainty_mm:0,claimed_is_actual:false,comparator:false,measurements:type==='tli'?{length_mm:120,width_mm:80,thickness_mm:8,flatness_mm:0.5,grid_mm:10,groove_mm:.2,marking_repeats:3,cracks:false,delamination:false,sharp_edges:false,magic_detected:false}:{piece_count:2,length1_mm:50,width1_mm:20,length2_mm:50,width2_mm:20,thickness1_mm:1,thickness2_mm:1.05,thickness_difference_mm:.05,loose_lamellae:false,cracks:false,mount_fit:true,magic_detected:false}});
check('TLI dentro das tolerâncias de design',()=>assert.equal(L.evaluate(base()).status,'WITHIN_PROPOSED_TOLERANCE'));
check('TLI fora do comprimento',()=>{let x=base();x.measurements.length_mm=121.1;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('TLI espessura no limite inclusivo',()=>{let x=base();x.measurements.thickness_mm=7.5;assert.equal(L.evaluate(x).status,'WITHIN_PROPOSED_TOLERANCE')});
check('TLI medição fronteiriça com incerteza',()=>{let x=base();x.measurements.width_mm=79;x.uncertainty_mm=.04;assert.equal(L.evaluate(x).status,'INDETERMINATE_UNCERTAINTY')});
check('Incerteza ausente não passa automaticamente',()=>{let x=base();x.uncertainty_mm=null;assert.equal(L.evaluate(x).status,'INDETERMINATE_UNCERTAINTY')});
check('Sem calibração é incompleto',()=>{let x=base();x.calibration_reference='';assert.equal(L.evaluate(x).status,'INCOMPLETE_OR_INVALID')});
check('Trinca rejeitada',()=>{let x=base();x.measurements.cracks=true;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Delaminação rejeitada',()=>{let x=base();x.measurements.delamination=true;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Magia detectada impede QA mecânica TEST',()=>{let x=base();x.measurements.magic_detected=true;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Inconsistência marcador de repetições',()=>{let x=base();x.measurements.marking_repeats=2;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Mica dupla dentro das tolerâncias',()=>assert.equal(L.evaluate(base('mica')).status,'WITHIN_PROPOSED_TOLERANCE'));
check('Mica diferença de espessura fora',()=>{let x=base('mica');x.measurements.thickness2_mm=1.2;x.measurements.thickness_difference_mm=.2;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Mica diferença incoerente',()=>{let x=base('mica');x.measurements.thickness2_mm=1.02;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Mica encaixe seco falso',()=>{let x=base('mica');x.measurements.mount_fit=false;assert.equal(L.evaluate(x).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Mica amostra incompleta',()=>{let x=base('mica');delete x.measurements.thickness2_mm;assert.equal(L.evaluate(x).status,'INCOMPLETE_OR_INVALID')});
check('NaN rejeitado',()=>{let x=base();x.measurements.length_mm=NaN;assert.equal(L.evaluate(x).status,'INCOMPLETE_OR_INVALID')});
check('Infinity rejeitado',()=>{let x=base();x.measurements.width_mm=Infinity;assert.equal(L.evaluate(x).status,'INCOMPLETE_OR_INVALID')});
check('Booleano não conta como dimensão',()=>{let x=base();x.measurements.width_mm=true;assert.equal(L.evaluate(x).status,'INCOMPLETE_OR_INVALID')});
check('Tipo desconhecido rejeitado',()=>assert.throws(()=>L.evaluate({type:'weapon'}),/TIPO_INVALIDO/));
check('Lote duplicado rejeitado no batch',()=>assert.throws(()=>L.validateBatch([base(),base()]),/DUPLICATE_SAMPLE/));
check('Mesmo ID em lotes distintos aceito',()=>{const a=base(),b=base();b.lot_id='L2';assert.equal(L.validateBatch([a,b]).length,2)});
check('Mesmo ID para outro tipo aceito',()=>assert.equal(L.validateBatch([base(),base('mica')]).length,2));
check('Comparação não afirma superioridade',()=>{const a=base(),b=base();b.sample_id='A2';b.comparator=true;const s=L.groupSummary([a,b]);assert.equal(s.groups['tli|CANDIDATE'].n,1);assert.equal(s.groups['tli|CONTROL'].n,1);assert.match(s.comparison,/NAO_SUPERIORIDADE/)});
check('Operador afirmando real não cria verificação física',()=>{const x=base();x.claimed_is_actual=true;const r=L.evaluate(x);assert.equal(r.physical_verified,false);assert.equal(r.rc5,false);assert.equal(r.production_authorized,false)});
check('Exportação conserva medidas sem promover RC5',()=>{const e=L.portableExport([base()]);assert.equal(e.records[0].evaluation.rc5,false);assert.equal(e.official_writes,0);assert.equal(e.summary.groups['tli|CANDIDATE'].within,1);});
check('HTML inclui lógica offline e não carrega fontes remotas',()=>{const h=fs.readFileSync('./CRAFT_BANCADA_MESTRE_ANDROID_OFFLINE.html','utf8');assert.match(h,/CraftMobileQA/);assert.doesNotMatch(h,/<script[^>]+src=/);assert.doesNotMatch(h,/<link[^>]+href="https?:/);assert.doesNotMatch(h,/fetch\s*\(/);});
check('Mica propaga incerteza de duas espessuras',()=>{const r=base('mica');r.uncertainty_mm=.03;assert.equal(L.evaluate(r).status,'INDETERMINATE_UNCERTAINTY')});
check('Planicidade zero não cria fronteira negativa física',()=>{const r=base();r.measurements.flatness_mm=0;r.uncertainty_mm=.05;assert.equal(L.evaluate(r).status,'WITHIN_PROPOSED_TOLERANCE')});
check('CSV neutraliza fórmulas em metadados',()=>{const r=base();r.operator='=HYPERLINK("https://malicioso", "x")';const s=L.toCSV([r]);assert.match(s,/"'=HYPERLINK/);});
check('CSV preserva cabeçalho e número de linhas',()=>{const s=L.toCSV([base()]);assert.equal(s.trim().split('\r\n').length,2);});

check('Tempo negativo é invalidado',()=>{const r=base();r.process_minutes=-10;assert.equal(L.evaluate(r).status,'INCOMPLETE_OR_INVALID')});


const cord=()=>({...base(),type:'cordao',measurements:{length_cm:100,fiber_input_m:2,break_load_N:90,test_load_N:60,elongation_pct:12,frayed_knots:false,magic_detected:false}});
check('Cordão com 100 cm não ganha certificado de carga',()=>{const r=L.evaluate(cord());assert.equal(r.status,'NO_HOMOLOGATED_LOAD_THRESHOLD');assert.equal(r.rc5,false);assert.equal(r.physical_verified,false)});
check('Cordão fora de 95-105 cm é reprovado em geometria proposta',()=>{const r=cord();r.measurements.length_cm=110;assert.equal(L.evaluate(r).status,'OUTSIDE_PROPOSED_TOLERANCE')});
check('Carga de ruptura acima de carga de ensaio não gera GREEN',()=>{const r=cord();r.measurements.break_load_N=10000;assert.equal(L.evaluate(r).status,'NO_HOMOLOGATED_LOAD_THRESHOLD')});
check('Carga de ruptura abaixo da carga declarada registra alerta',()=>{const r=cord();r.measurements.break_load_N=10;assert(L.evaluate(r).flags.notes.includes('RUPTURA_ANTES_DA_CARGA_DE_TESTE_DECLARADA'))});
check('Dados negativos de carga são inválidos',()=>{const r=cord();r.measurements.break_load_N=-1;assert.equal(L.evaluate(r).status,'INCOMPLETE_OR_INVALID')});
check('Comprimento 95 cm com incerteza de 1 cm é indeterminado',()=>{const r=cord();r.measurements.length_cm=95;r.uncertainty_mm=1;assert.equal(L.evaluate(r).status,'INDETERMINATE_UNCERTAINTY')});
check('Comparador comum B30-02 não se converte em fonte oficial',()=>{const r=cord();r.comparator=true;const e=L.portableExport([r]);assert.equal(e.summary.groups['cordao|CONTROL'].indeterminate,1);assert.equal(e.records[0].evaluation.source_id,L.SOURCES.cordao)});
check('JSON v1.0 é estruturalmente compatível no v1.1',()=>{const raw=base();assert.equal(L.validateBatch([raw]).length,1);assert.equal(L.evaluate(raw).type,'tli')});

check('Incerteza em mm converte corretamente para cm do cordão',()=>{const r=cord();r.measurements.length_cm=95.2;r.uncertainty_mm=1;assert.equal(L.evaluate(r).status,'NO_HOMOLOGATED_LOAD_THRESHOLD')});
console.log('SUMMARY',tests,'checks',process.exitCode?'FAILED':'PASS');
