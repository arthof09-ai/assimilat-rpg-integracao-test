# CRAFT-MOBILE-CAPTURE-20261021-001 — ANTES
- OP: OP-ARQ-RIN-REC-01; executor lógico CM-000002/WS0001; escopo MESTRE-SIDE/TEST.
- Estado oficial: F5 RED, C19-021 UNKNOWN-SIDE-EFFECT; nenhum writer, epoch, lease, ACK, GREEN.
- Fontes reabertas: ficha PS de Ardósia de Geada Lamelar `3f3c2b32-4ede-81ac-af28-c66a6b46e0b2`, ficha PS Mica de Bruma Boreal `3f3c2b32-4ede-81e1-b179-e194e2838c84`, PR-ITEM-02, REC-MOD-EQA-01, AUD-CRAFT-F5-REMAP-01, histórico R50_PLAN_B30-01.json e B30-03_PRONTIDAO_RC5.json (Biblioteca), QMC-01/02, R45/46.
- Objetivo: não criar outro motor de fabricação/metrologia. Construir interface offline de captura Android de medições e comparador descritivo, e exportação JSON/CSV para processamento competente do R45/46 quando disponível.
- Critérios da proposta PRE-Q2 B30-01: comprimento 119–121 mm, largura 79–81 mm, espessura 7.5–8.5 mm, planicidade 0–1 mm, malha 9–11 mm, profundidade de sulco 0–0.5 mm, >=3 repetições de traço e sem rachaduras/delaminação/quinas cortantes/detecção de magia.
- Critérios da proposta PRE-Q2 B30-03: 2 peças, comprimento 49–51 mm, largura 19–21 mm, diferença de espessuras 0–0.1 mm, nenhuma lamela solta, rachadura, falha encaixe, efeito mágico.
- Marcação essencial: todos limiares são PROPOSTOS no PRE-Q2; nenhuma alegação de lote material real pela existência da UI. Sem fotos automáticas, credencial, persistência/sync nem acesso de rede.
- Saídas: app HTML totalmente offline e responsive; dados brutos com provenance self-declared, QA preliminar, export JSON/CSV, testes JS de regras, teste headless de UI.
