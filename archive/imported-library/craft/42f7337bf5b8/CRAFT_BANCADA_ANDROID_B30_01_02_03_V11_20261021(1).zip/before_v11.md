# CRAFT-MOBILE-FIBER-B30-02-20261021-001 — antes da versão 1.1

- Fonte Mestre realmente reaberta: Fibra de Casca Boreal, `3f3c2b32-4ede-815a-b04a-ce5bd1074e79`, PS/semicanônico.
- Dossiê `AUD-CRAFT-F5-REMAP-01` já prescreve projeto PRE-Q2: 2 m fibras e água processo variável para alvo de 1 m de cordão; 95–105 cm, nós sem desfiar, tração frente a **carga de serviço ainda não homologada**, comparador fibra comum. Não criar limiar novo.
- Base versionada original: `CRAFT_BANCADA_ANDROID_B30_01_03_20261021.zip`, SHA256 `5df67b41eb29aee687c6ed01dbd23cb404fd830582b836defa29df81fbdd0fdb`, 31 testes Node PASS + Chromium 390px PASS, Library `libfile_4d186ea70a4081919c8709b34248debf`.
- Evolução EXCLUSIVA de interface já existente: terceiro projeto B30-02 com registro quantitativo observacional e resultado `NO_HOMOLOGATED_LOAD_THRESHOLD`, jamais RC5 ou PHYSICALLY_VERIFIED. Import JSON v1.0 permitido com recálculo no v1.1.
- No Notion, ANTES trace `CRAFT-MOBILE-FIBER-B30-02-20261021-001` na LAB existente. Party/O Primeiro NO-WRITE; F5 RED/C19 UNKNOWN e nenhum writer/ACK/epoch/lease/fencing herdado.
