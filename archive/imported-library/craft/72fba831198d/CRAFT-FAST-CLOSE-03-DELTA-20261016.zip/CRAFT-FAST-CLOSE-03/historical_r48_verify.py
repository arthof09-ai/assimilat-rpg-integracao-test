"""Re-execute preserved R48 binary content in a new synthetic test store only."""
import json,sys,hashlib,copy
from pathlib import Path
BASE=Path('/mnt/data/CRAFT-FAST-CLOSE-03/inputs/CRAFT-COMESTRE-CHAT-v03/Oficina-v02/CRAFT-R48-SANDBOX-I0016')
sys.path.insert(0,str(BASE))
from r48_factory import IntegratedFactory,FactoryError,digest
from r48_store import DurableFactory
from r48_fixtures import lots, order
from r46_fixtures import REVIEW
OUT=Path('/mnt/data/CRAFT-FAST-CLOSE-03/outputs')
STORE=OUT/'R48_VALID_FIXTURE_TIME'
if STORE.exists():raise RuntimeError('REFUSE_REPLACE_PRIOR_RESULT')
st=DurableFactory(STORE)
init=IntegratedFactory.fixture_factory(lots(slate=2,mica_a=1,mica_b=1))
before=init.quantities
st.initialize(init)
batch='SBX-R48-BATCH-FC03-LEGACY-01'
orders=[order('tli',73001),order('mica',73002)]
a=st.commit_batch(batch,orders,REVIEW)
head=a['r48_head']; f,state=st.recover(head)
assert f.audit()['ok'] and state['sequence']==1
assert a['receipt']['experimental_product_count']==2
assert f.quantities['SBX-SLATE-GOOD-01']==1 and f.quantities['SBX-MICA-GOOD-A']==0 and f.quantities['SBX-MICA-GOOD-B']==0
b=st.commit_batch(batch,orders,REVIEW)
assert b['idempotent_replay'] is True and b['r48_head']==head
neg=st.commit_batch('SBX-R48-BATCH-FC03-NEG-02',[order('mica',73003)],REVIEW)
assert neg['receipt']['orders'][0]['status']=='REJECTED_PRECHECK',neg['receipt']['orders'][0]
f2,s2=st.recover(); assert f2.audit()['ok'] and s2['sequence']==2
assert f2.quantities==f.quantities
result={'experiment':'R48_EXECUTION_UNMODIFIED','baseline_sha256':hashlib.sha256((BASE/'r48_factory.py').read_bytes()).hexdigest(),
 'initial_stock':before,'success_receipt':a['receipt'],'success_head':head,'duplicate':b,
 'negative_receipt':neg['receipt'],'last_audit':f2.audit(),'final_stock':f2.quantities,
 'last_head':f2.head,'sequence':s2['sequence'],'historical_draft_untouched':True}
p=OUT/'r48_fresh_execution.json';p.write_text(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
print(json.dumps({'success_product_count':a['receipt']['experimental_product_count'],'negative_status':neg['receipt']['orders'][0]['status'],'duplicate_no_reconsume':b['idempotent_replay'],'before':before,'after':f2.quantities,'audit_ok':result['last_audit']['ok'],'disk_sequence':s2['sequence'],'head':f2.head},ensure_ascii=False))
