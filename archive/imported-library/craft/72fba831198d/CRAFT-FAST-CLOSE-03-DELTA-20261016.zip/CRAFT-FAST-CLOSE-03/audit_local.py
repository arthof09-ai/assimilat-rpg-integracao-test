"""Fresh interpreter cross-check of R48/R44 TEST ledgers and original v03 integrity."""
import json,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from fastclose03_lab import LabStore
BASE=ROOT/'inputs/CRAFT-COMESTRE-CHAT-v03'
engine=(BASE/'Oficina-v02/CRAFT-R48-SANDBOX-I0016')
sys.path.insert(0,str(BASE));sys.path.insert(0,str(engine))
from verificar_v03 import verify
from r48_store import DurableFactory
print('STEP_orig',flush=True)
orig=verify()
print('STEP_r48,ref',flush=True)
r48,ref=DurableFactory(ROOT/'outputs/R48_VALID_FIXTURE_TIME').recover()
print('STEP_case,p',flush=True)
case,p=LabStore(ROOT/'outputs/B30_22_MAIN_STORE').recover()
print('STEP_q,qp',flush=True)
q,qp=LabStore(ROOT/'outputs/B30_22_QA_FAIL_STORE').recover()
reasons=[]
print('STEP_for_name,fac',flush=True)
for name,factory,pointer in [('R48',r48,ref),('B30-22',case,p),('QA_REJECT',q,qp)]:
    report=factory.audit()
    if not report['ok']:reasons.append(name+':INTEGRITY_FAIL')
    if pointer['sequence']!=len(factory.journal if name=='R48' else factory.state['events']):
        reasons.append(name+':SEQUENCE_MISMATCH')
if ref['sequence']!=2 or p['sequence']!=2 or qp['sequence']!=1:reasons.append('SEQUENCE_UNEXPECTED')
if len(case.state['products'])!=1 or len(q.state['products'])!=0:reasons.append('PRODUCT_COUNT_WRONG')
if sum(v['quantity'] for v in case.state['lots'].values())!=0:reasons.append('SYNTHETIC_QUANTITY_WRONG')
if any(v.get('official_product_id') is not None for v in case.state['products'].values()):reasons.append('OFFICIAL_PRODUCT_ID_PRESENT')
if any(v.get('mechanical_bonus')!=0 for v in case.state['products'].values()):reasons.append('UNAUTHORIZED_MECHANICAL_EFFECT')
if r48.audit()['orders']!=3:reasons.append('R48_ORDER_COUNT_UNEXPECTED')
print('STEP_res',flush=True)
res={'ok':not reasons,'issues':reasons,'baseline':orig,
     'R48':{'sequence':ref['sequence'],'head':ref['r48_head'],'audit':r48.audit(),
            'synthetic_products':len(r48.core.state['products'])},
     'B30_22':{'sequence':p['sequence'],'head':p['head'],'audit':case.audit(),
              'synthetic_products':len(case.state['products']),
              'remaining_lots':{k:v['quantity'] for k,v in case.state['lots'].items()}},
     'QA_negative':{'sequence':qp['sequence'],'head':qp['head'],'audit':q.audit(),
                    'synthetic_products':len(q.state['products'])},
     'Notion_reopen':'NOT_VERIFIED_CONNECTION_ERROR','official_mutations':0}
(ROOT/'outputs/independent_readback_audit.json').write_text(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print(json.dumps({'ok':res['ok'],'issues':res['issues'],'R48':ref['sequence'],'B30_22':p['sequence'],'QA_negative':qp['sequence']},ensure_ascii=False))
if reasons:raise SystemExit(1)
