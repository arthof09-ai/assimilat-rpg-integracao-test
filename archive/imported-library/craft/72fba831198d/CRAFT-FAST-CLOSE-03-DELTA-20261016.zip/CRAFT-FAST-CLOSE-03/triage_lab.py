"""Focused proof/limits: only B30-03 and B30-06; no material claims."""
from __future__ import annotations
import copy,json,sys
from pathlib import Path
HERE=Path(__file__).parent.resolve();sys.path.insert(0,str(HERE))
from fastclose03_lab import R44,CHITIN,FIBER
from experimental_engine import SandboxEngine,load_recipes
BASE=Path('/mnt/data/BACKFILL30-CRAFT-20261014/ESPECIFICACOES-B30-01-a-B30-30.md')
R=load_recipes(R44/'recipes')
fixture=json.loads((R44/'fixtures/demo.json').read_text())
recipe=R['SBX-MICA-R44-v1']
# Control: real PS ID for mica. Test only uses synthetic quantities and results.
eng=SandboxEngine(R,fixture['lots'])
pos=eng.run('SBX-MICA-R44-v1','SBX-FC03-MICA-CONTROL',
  ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B'],fixture['mica_good_measurements'],
  fixture['mica_tools'],fixture['mica_skills'])
assert pos['status']=='EXPERIMENTAL_QA_PASS'
# Source mismatch: replacing both mica lots by a gneiss-labeled fixture is not an
# admissible substitution UNDER THIS RECIPE. Not a material comparison of strength.
gneiss_src='3f3c2b32-4ede-8131-9786-eba0f666cef1'
newlots=copy.deepcopy(fixture['lots'])
for l in newlots:
    if l['lot_id'].startswith('SBX-MICA-GOOD'):
        l['source_page_id']=gneiss_src
alt=SandboxEngine(R,newlots)
neg=alt.run('SBX-MICA-R44-v1','SBX-FC03-MICA-GNEISS-NOT-SAME',
  ['SBX-MICA-GOOD-A','SBX-MICA-GOOD-B'],fixture['mica_good_measurements'],
  fixture['mica_tools'],fixture['mica_skills'])
assert neg['status']=='REJECTED_PRECHECK' and 'SOURCE_OR_UNIT_MISMATCH' in neg['rejection_reasons']
assert eng.audit()['ok'] and alt.audit()['ok']
# B30-06: functionally required porous sleeve's source is unproven.
# A fixture may be mocked for a packaging experiment, not certified as existing.
ZEOLITE='3f3c2b32-4ede-8196-95d6-e7797fd94370'
checklist={'zeolite':{'source_page_id':ZEOLITE,'quantity':200,'unit':'g','status':'PS_SOURCE_IDENTIFIED'},
 'sleeve':{'source_page_id':None,'quantity':1,'unit':'unidade','status':'UNRESOLVED_MATERIAL_DEPENDENCY'},
 'drying_curve':{'status':'UNVERIFIED_PROCESS_CONDITION'},
 'sorption_g_per_g':{'status':'NO_MEASUREMENT_OR_RULE'},
 'regeneration_cycles':{'status':'NO_MEASUREMENT_OR_RULE'}}
missing=[k for k,v in checklist.items() if v['status'] not in ['PS_SOURCE_IDENTIFIED']]
assert 'sleeve' in missing
result={'B30-03':{
  'source_mica':'3f3c2b32-4ede-81e1-b179-e194e2838c84',
  'source_gneiss':gneiss_src,
  'documented_mica_function':'two lamellar shims to define a controlled thin gap; no dielectric/magical/strength claim',
  'prototype_TEST_status':pos['status'],'positive_qa':pos['qa_fixture'] if 'qa_fixture' in pos else pos['transformation_stage_trace'],
  'substitute_gneiss_into_existing_mica_recipe':neg['status'],'reason':neg['rejection_reasons'],
  'comparison_conclusion':'DIFFERENT_SOURCE_REQUIRE_NEW_SPEC_AND_PROOF; no demonstrated independent superiority vs gneiss/common shims',
  'independent_technical_merit':'PENDENTE_DIMENSIONAL_APPLICATION_AND_COMPARATOR',
  'audits':{'mica':eng.audit(),'wrong_source':alt.audit()},
  'QA_INPUT_IS_SYNTHETIC':True},
 'B30-06':{
  'source_zeolite':ZEOLITE,
  'product_architecture':'separate loose charge (200g design) from reusable porous sleeve/vessel; changing charge is maintenance, not separate recipe',
  'material_gate_checklist':checklist,
  'test_result':'BLOCKED_SOURCE',
  'exact_cause':'POROUS_SLEEVE_SOURCE_UNIDENTIFIED; additional sorption/regeneration/thermal conditions unverified',
  'mock_sleeve_permitted_for_future_sandbox':True,
  'mock_sleeve_does_not_close_material_dependency':True,
  'not_proven':'hygroscopic advantage, real mass water uptake, reactivation conditions, real enclosure',
  'RC5_credit':0}}
p=HERE/'outputs/triage_B30_03_B30_06.json';p.write_text(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
print(json.dumps({'B30-03':pos['status'],'gneiss_as_mica':neg['status'],'B30-06':result['B30-06']['test_result'],'missing':missing,'physical_material_test':False},ensure_ascii=False))
