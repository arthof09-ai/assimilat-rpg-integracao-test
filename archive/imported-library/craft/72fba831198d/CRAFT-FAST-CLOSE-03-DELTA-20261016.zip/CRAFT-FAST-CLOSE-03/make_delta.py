from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
P=ROOT.parent/'CRAFT-FAST-CLOSE-03-DELTA-20261016.zip'
files=[]
for path in ROOT.rglob('*'):
 if not path.is_file():continue
 r=path.relative_to(ROOT)
 if r.parts[0]=='inputs' or '__pycache__' in r.parts or r.name in ('MANIFEST_SHA256.json',):continue
 if str(r).startswith('outputs/') or r.parts[0]=='recipes' or path.parent==ROOT:
  files.append(path)
manifest={'schema':'CRAFT-FAST-CLOSE-03-DELTA-v1','operation':'CM-000002 / WS0001 / OP-ARQ-RIN-REC-01',
 'historical_baseline_separate':{'filename':'CRAFT-COMESTRE-CHAT-v03.zip','sha256':'5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434'},
 'files':{str(f.relative_to(ROOT)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(files)}}
(ROOT/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
with zipfile.ZipFile(P,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for f in sorted(files+[ROOT/'MANIFEST_SHA256.json']):
  z.write(f,arcname='CRAFT-FAST-CLOSE-03/'+str(f.relative_to(ROOT)))
with zipfile.ZipFile(P) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)+1
h=hashlib.sha256(P.read_bytes()).hexdigest()
(ROOT/'ARCHIVE_SHA256.txt').write_text(h+'  '+P.name+'\n')
print(json.dumps({'path':str(P),'bytes':P.stat().st_size,'files':len(files)+1,'zip_sha256':h},ensure_ascii=False))
