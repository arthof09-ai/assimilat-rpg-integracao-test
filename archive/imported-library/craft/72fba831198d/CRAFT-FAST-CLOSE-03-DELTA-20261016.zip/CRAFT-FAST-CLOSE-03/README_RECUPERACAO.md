# CRAFT / FAST-CLOSE 03 — delta experimental recuperável

**CM-000002 · WS0001 · OP-ARQ-RIN-REC-01 · 16/10/2026**  
**MESTRE-SIDE; somente sandbox local; sem escrita Notion/Party/O Primeiro ou estoque canônico.**

## O que foi VERIFICADO (não apenas relatado)

- Arquivo histórico `/mnt/data/craft_recovery/CRAFT-COMESTRE-CHAT-v03.zip` verificado SHA-256 `5a9af3ae0568031a59a0248843a3f40b8c020c070b8f00c20eb678d9ec844434`, 205/205 membros, Oficina-v02 verificada, 174/174 arquivos R48 byte-identical ao baseline.
- `CRAFT-CHAT-SESSAO-MESTRE-v03.zip` SHA-256 `02a3643c75cd49d13cbfdffdedaa42fcc1442f877042b4d398a540610aaed57f`. **NÃO confirmar nem cancelar** o plano histórico DRAFT `SBX-R48-BATCH-UI-2afb696406a6e839` sem uma ordem específica; nenhum teste desta rodada o tocou.
- 52 testes R44 + 64 R45 + 70 R46 + 87 R47 + 40 R48 = **313 regressões históricas** nesta sessão; 18 testes adicionais independentes da extensão B30-22, **331 no total**. Arquivos `outputs/historical_regressions.log` e `outputs/fc03_adversarial_tests.log`.
- `historical_r48_verify.py`: no diretório NOVO `outputs/R48_VALID_FIXTURE_TIME`, 1 tábua B30-01 TEST e 1 par de mica B30-03 TEST aprovados, replay idempotente e terceira tentativa de mica rejeitada sem consumo. `outputs/r48_fresh_execution.json` fornece recibos/saldo/HEAD. Houve uma execução preliminar rejeitada corretamente porque a data recente não cabia na validade dos certificados artificiais R47. Este registro foi preservado no store `outputs/R48_UNMODIFIED_STORE`; teste aprovado rodou somente com a data original de fixture (09/10/2026). Não afirma atividade de fabricação nessa data.
- `fastclose03_lab.py` integra a terceira receita B30-22 **ao motor R44 original reutilizado** (código histórico intacto), com primitivos de escrita atômica + mutex R47 e replay/checkpoint. Não utiliza validador de laudo R47, historicamente fechado em duas receitas; uma extensão de evidência é pendência e não será fingida.
- `recipes/B30-22-TEST.json`: duas placas de quitina, 30 cm de Fibra Boreal **diretamente**, peças 50×20 mm, fecho e QA fictícios, sem poderes; zero ligação falsa com receita-base B30-02.
- `outputs/B30_22_MAIN_STORE` contém 1 produto TEST real **no sentido computacional** (nenhum objeto físico), uma segunda tentativa rejeitada por estoque, eventos 2/2, HEAD `051bc39557ce3517bd2acf625952fa4cca62637722e61053a757089189ca8601`. `outputs/B30_22_QA_FAIL_STORE` contém lote separado reprovado em QA, consumo/sucata simulados e zero produto.
- `outputs/triage_B30_03_B30_06.json`: mica PASS sob fixture; substituição por gnaisse na mesma fórmula R44 rejeitada por incompatibilidade de SOURCE_ID, **sem concluir fisicamente que gnaisse não funciona**. B30-06 BLOCKED_SOURCE pela falta de origem competente para invólucro poroso, além de falta de desempenho adsorvente/curva térmica.
- `outputs/rc5_admission_delta.json`: matriz de admissão e contadores: 0/30 cobertura RC5, 0 REC-IDs físicos RC5, 0 item produzido in-game.

## Reproduzir em outra sessão (não precisa computador do Mestre)

1. Disponibilizar o ZIP original `CRAFT-COMESTRE-CHAT-v03.zip` separadamente do ZIP delta. Extrair o ZIP original sob `inputs/`, mantendo a pasta `inputs/CRAFT-COMESTRE-CHAT-v03/`. **Não substituir, recompactar ou alterar o ZIP histórico.**
2. Extrair o ZIP delta na pasta raiz `CRAFT-FAST-CLOSE-03/`. Requisitos Python 3.10+ e `cryptography` para a execução R47/R48.
3. `python -m unittest -v test_fastclose03` roda os 18 adversariais sem tocar nos stores publicados; `python triage_lab.py` reproduz o controle comparativo B30-03 e o gate B30-06.
4. Para criar outra experiência B30-22 sem substituir o histórico: `python fastclose03_lab.py init --store outputs/NOVO_STORE`; `python fastclose03_lab.py run --store outputs/NOVO_STORE --id SBX-FC03-NOVO-01`; `python fastclose03_lab.py status --store outputs/NOVO_STORE`. Usar identificador novo para nova tentativa. Reutilizar exatamente o mesmo ID reabre o recibo sem segundo débito.
5. `outputs/B30_22_MAIN_STORE/CURRENT.json` e `outputs/R48_VALID_FIXTURE_TIME/CURRENT.json` são pontos de reabertura. Não apagar checkpoints, arquivos desconhecidos ou reexecutar após órfãos `UNKNOWN_EFFECT` sem reconciliar.
6. Conferir `MANIFEST_SHA256.json` antes de confiar nos artefatos; hashes referem-se aos membros do delta, não a páginas oficiais do Notion.

## Ciência, economia e autoridade

Todo atributo dimensional, resultado QA de instrumento, tempo, operador e estoque é **fixture ou proposta experimental**. Nenhum tempo ou ciclo de dobradiça foi medido. **Não** existem preço MED, CTE monetário fechado, lote físico ou assinatura confiável de laboratório. A árvore econômica é PR-ECO-01: `CTE=CI+CP+CF+CT+CE+CK+CL+CA+CC`, mas os valores econômicos são desconhecidos. Diferenciar `CTE / N_aprovados` observado em TEST do custo válido em jogo.

Fonte do RPG: Notion Mestre e normas vigentes. Tentativa de leitura do laboratório `https://app.notion.com/p/3fbc2b324ede811db848d35d4739eb00` falhou no conector com `link_id must identify an eligible linked account`; portanto **nenhum registro, checkpoint ou resultado foi verificado ou gravado no Notion nesta rodada**. Não confundir o código local recuperado com o laboratório em nuvem.

**Governança:** escritor oficial não assumido, F5 RED, C19-021 UNKNOWN-SIDE-EFFECT, IBX-38/78 pendentes, NAC-PASS produtivo HOLD. O escopo da ordem autoriza desenvolvimento experimental isolado; não autoriza produto/REC-ID oficial, estoque real ou conteúdo Party. Pesquisa de comparadores antiga foi reutilizada, não declarada globalmente exaustiva.

## Sucessão / fronteira exata

**LAST-VERIFIED-UNIT:** B30-22 `MAIN_STORE` sequência 2 (PASS seguido de falta de estoque), `QA_FAIL_STORE` sequência 1, R48 novo store sequência 2. Ambos recuperáveis e auditáveis. Arquivos anteriores são leitura.

**FIRST-PENDING:** reconciliar laboratório Notion quando o conector estiver apto; confirmar fonte física competente de invólucro B30-06; submeter B30-22 a teste de utilidade diferencial/estabilidade não sintética e a prova de custo/autoridade PS; somente então reavaliar RC5 com gates NAC e biblioteca única.

**NO-REPEAT:** não reconstruir R44–R48, não reproduzir os 30 dossiês, não atribuir REC-ID à B30-02 sem receita-base, não reaproveitar ID de recibo para nova fabricação, não afirmar `RC5-TECH` a partir de QA sintético.
