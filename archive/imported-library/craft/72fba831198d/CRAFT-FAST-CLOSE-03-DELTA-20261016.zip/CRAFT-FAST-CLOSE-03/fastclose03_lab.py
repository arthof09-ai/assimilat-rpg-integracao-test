"""Minimal additive B30-22 TEST adapter to untouched R44 engine, R47 durable primitives.

EXPERIMENTAL ONLY: every lot, dimension, observation and operator is FICTIONAL.
Neither this script nor imported engines have a Notion/Party/production writer.
R47 authenticity for B30-22 is NOT claimed: historical R46/R47 accept only 01/03.
"""
from __future__ import annotations
import copy, hashlib, json, sys
from pathlib import Path
BASE=Path(__file__).parent.resolve()
R48=BASE/'inputs/CRAFT-COMESTRE-CHAT-v03/Oficina-v02/CRAFT-R48-SANDBOX-I0016'
R47=R48/'legacy/CRAFT-R47-SANDBOX-I0016'
R44=R47/'baseline/CRAFT-R46-SANDBOX-I0016/baseline/extracted_R44/CRAFT-R44-SANDBOX-I0016'
sys.path.insert(0,str(R47));sys.path.insert(0,str(R44))
from experimental_engine import SandboxEngine, SandboxError, SimulatedCrash, load_recipes, NAMESPACE, digest
from r47_durable_store import R47DurableStore, persist_atomic, filehash

KEY='SBX-CHITINCASE-CRAFT-FC03-v1'
CHITIN='3f3c2b32-4ede-8141-acdd-f0bb23ffe56c'
FIBER='3f3c2b32-4ede-815a-b04a-ce5bd1074e79'
RECIPES=BASE/'recipes'
SCHEMA='CRAFT-FC03-B30-22-LOCAL-SBX-v1'

class LabError(RuntimeError): pass
class Crash(LabError): pass

def recipes():
    old=load_recipes(R44/'recipes')
    new=load_recipes(RECIPES)
    assert set(new)=={KEY} and not set(old)&set(new)
    return {**old,**new}

def synthetic_lots(chitin_a=1,chitin_b=1,fiber_cm=30):
    def lot(id,src,unit,n,dim=None):
        return {'lot_id':id,'fixture_kind':'SYNTHETIC','source_page_id':src,'unit':unit,
                'quantity':n,'dimensions_mm':dim or {},'cracked':False,
                'delaminated':False,'contaminated':False}
    return [lot('SBX-FC03-CHITIN-A',CHITIN,'placa',chitin_a,{'length':60,'width':30}),
            lot('SBX-FC03-CHITIN-B',CHITIN,'placa',chitin_b,{'length':60,'width':30}),
            lot('SBX-FC03-FIBER-30CM',FIBER,'cm',fiber_cm)]

def measurements_good():
    return {'panel_count':2,'length_mm':50,'width_mm':20,'hinge_open_angle_deg':110,
            'hinge_cycle_count':20,'closure_secure':True,'flat_sample_retained':True,
            'cracks':False,'sharp_edges':False,'magic_detected':False}

def tools():
    return ['serra_fina_reutilizavel','furador_manual_reutilizavel','regua_esquadro',
            'grampos_bancada','epi_oficina']
def skills():return ['artesanato_quitina','costura_amarracao_fibra','metrologia_mecanica']
def lot_ids():return ['SBX-FC03-CHITIN-A','SBX-FC03-CHITIN-B','SBX-FC03-FIBER-30CM']

def snap(engine):
    v={'namespace':NAMESPACE,'schema':'R44-SANDBOX-SNAPSHOT-v1',
       'initial_lots':engine.initial_lots,'initial_hash':engine.initial_hash,
       'recipe_hashes':engine.recipe_hashes,'state':engine.state}
    v['integrity_sha256']=digest(v)
    return (json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode('utf8')

class LabStore:
    def __init__(self,root):
        self.root=Path(root)
        self.legacy=R47DurableStore(root)  # REUSE historical Linux flock implementation
        self.commits=self.root/'commits'
        self.ptr=self.root/'CURRENT.json'

    def publish(self,payload):
        out={**payload,'pointer_sha256':digest(payload)}
        persist_atomic(self.ptr,(json.dumps(out,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode('utf8'))

    def initialize(self,initial_lots=None):
        with self.legacy.lock():
            if self.ptr.exists() or (self.commits.exists() and list(self.commits.iterdir())):
                raise LabError('PREEXISTING_STATE_NO_OVERWRITE')
            core=SandboxEngine(recipes(),initial_lots or synthetic_lots())
            self.commits.mkdir(parents=True,exist_ok=True)
            name=f'000000-{core.state["head_hash"]}.json'
            blob=snap(core)
            persist_atomic(self.commits/name,blob)
            self.publish({'schema':SCHEMA,'sequence':0,'current':name,
                'known':[name],'hashes':{name:filehash(blob)},
                'head':core.state['head_hash'],'sandbox_only':True,'official_stock_effect':0})
            return self._recover_unlocked()[1]

    def _recover_unlocked(self):
        if not self.ptr.exists():raise LabError('NO_POINTER_OR_UNKNOWN_EFFECT')
        data=json.loads(self.ptr.read_text('utf8'))
        proof=data.pop('pointer_sha256',None)
        if proof!=digest(data):raise LabError('POINTER_TAMPERED')
        if data.get('schema')!=SCHEMA or data.get('sandbox_only') is not True or data.get('official_stock_effect')!=0:
            raise LabError('NOT_A_SYNTHETIC_LAB_STORE')
        known=data.get('known');table=data.get('hashes')
        if type(known)!=list or not known or len(known)!=len(set(known)) or data['sequence']!=len(known)-1 or known[-1]!=data['current']:
            raise LabError('SEQUENCE_INDEX_INVALID')
        if type(table)!=dict or set(table)!=set(known):raise LabError('DIGEST_TABLE_INVALID')
        found={x.name for x in self.commits.iterdir()}
        if found!=set(known):raise LabError('UNKNOWN_EFFECT_OR_MISSING_CHECKPOINT:'+repr(sorted(found^set(known))))
        for name in known:
            if name!=Path(name).name or (self.commits/name).is_symlink():raise LabError('INVALID_CHECKPOINT_PATH')
            if filehash((self.commits/name).read_bytes())!=table[name]:raise LabError('CHECKPOINT_BYTES_TAMPERED:'+name)
        core=SandboxEngine.restore(recipes(),self.commits/data['current'])
        if core.state['head_hash']!=data['head'] or len(core.state['events'])!=data['sequence']:
            raise LabError('REPLAY_HEAD_OR_SEQUENCE_MISMATCH')
        if not core.audit()['ok']:raise LabError('R44_LEDGER_AUDIT_FAILURE')
        return core,data

    def recover(self):
        with self.legacy.lock():return self._recover_unlocked()

    def run(self,attempt_id,measurements=None,lot_ids_override=None,tools_override=None,skills_override=None,
            fault_stage=None,commit_fault=None,expected_head=None):
        with self.legacy.lock():
            core,state=self._recover_unlocked()
            if expected_head is not None and state['head']!=expected_head:raise LabError('STALE_HEAD_REJECTED')
            before={k:v['quantity'] for k,v in core.state['lots'].items()}
            stage=fault_stage
            receipt=core.run(KEY,attempt_id,lot_ids_override or lot_ids(),
                             measurements_good() if measurements is None else measurements,
                             tools() if tools_override is None else tools_override,
                             skills() if skills_override is None else skills_override,stage)
            if receipt.get('idempotent_replay'):
                return {'receipt':receipt,'idempotent_replay':True,'head':state['head'],
                        'sequence':state['sequence'],'stock_before':before,'stock_after':before,'official_stock_effect':0}
            if not core.audit()['ok']:raise LabError('FAILED_BEFORE_DISK_COMMIT')
            seq=state['sequence']+1
            name=f'{seq:06d}-{core.state["head_hash"]}.json'
            blob=snap(core)
            persist_atomic(self.commits/name,blob)
            if commit_fault=='AFTER_SNAPSHOT_BEFORE_POINTER':
                raise Crash('UNKNOWN_EFFECT_ORPHAN_CHECKPOINT_REQUIRES_RECONCILIATION')
            nextdata={**state,'sequence':seq,'head':core.state['head_hash'],
                      'current':name,'known':state['known']+[name],
                      'hashes':{**state['hashes'],name:filehash(blob)}}
            self.publish(nextdata)
            if commit_fault=='AFTER_POINTER_BEFORE_ACK':
                raise Crash('COMMITTED_ACK_LOST_RETRY_SAME_ATTEMPT')
            after={k:v['quantity'] for k,v in core.state['lots'].items()}
            return {'receipt':receipt,'idempotent_replay':False,'head':nextdata['head'],
                    'sequence':seq,'stock_before':before,'stock_after':after,
                    'official_stock_effect':0,'cost':{
                    'formula':'CI+CP+CF+CT+CE+CK+CL+CA+CC','currency':'MED_UNDETERMINED',
                    'unit':'per_approved_case_TEST','numeric_cte':None,'price':None}}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('action',choices=['init','run','status'])
    p.add_argument('--store',required=True);p.add_argument('--id',default='SBX-FC03-CASE-CLI')
    a=p.parse_args();x=LabStore(a.store)
    if a.action=='init':v=x.initialize();print(json.dumps({'init':True,'head':v['head']}))
    elif a.action=='run':print(json.dumps(x.run(a.id),indent=2,ensure_ascii=False))
    else:
        engine,state=x.recover();print(json.dumps({'head':state['head'],'audit':engine.audit(),'stock':engine.state['lots'],'products':engine.state['products']},indent=2,ensure_ascii=False))
