"""Verify full byte-level integrity of FAST-CLOSE-03 delta without needing old engines."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text(encoding='utf8'))
fail=[]
for rel,v in manifest['files'].items():
    path=ROOT/rel
    if not path.is_file():fail.append('MISSING:'+rel);continue
    raw=path.read_bytes()
    if len(raw)!=v['bytes'] or hashlib.sha256(raw).hexdigest()!=v['sha256']:
        fail.append('HASH:'+rel)
if fail:print(json.dumps({'ok':False,'failures':fail},indent=2));sys.exit(1)
print(json.dumps({'ok':True,'files':len(manifest['files']),'baseline_separate':True,'official_writes':0}))
