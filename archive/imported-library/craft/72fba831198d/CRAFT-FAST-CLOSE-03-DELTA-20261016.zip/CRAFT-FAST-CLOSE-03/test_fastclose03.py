"""Independent adversarial checks of B30-22 additive extension in TEST namespace."""
import copy,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from fastclose03_lab import LabStore,LabError,Crash,synthetic_lots,measurements_good,KEY,R44,recipes,lot_ids,tools,skills
from fastclose03_lab import SandboxError,SimulatedCrash
from r47_durable_store import filehash

RUNNER=Path(__file__).resolve().parent/'fastclose03_lab.py'
class FastClose03Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sbx-fc03-test-')
        self.path=Path(self.tmp.name)/'store'
        self.lab=LabStore(self.path);self.lab.initialize()
    def tearDown(self):self.tmp.cleanup()
    def status(self):
        core,p=self.lab.recover();return core,p
    def test_01_success_and_durable_replay(self):
        a=self.lab.run('SBX-FC03-TEST-SUCCESS')
        self.assertEqual(a['receipt']['status'],'EXPERIMENTAL_QA_PASS')
        self.assertEqual(len(a['receipt']['products']),1)
        self.assertEqual(len(a['receipt']['consumed']),3)
        self.assertEqual(a['sequence'],1)
        core,ptr=self.status();self.assertTrue(core.audit()['ok'])
        b=self.lab.run('SBX-FC03-TEST-SUCCESS')
        self.assertTrue(b['idempotent_replay'])
        self.assertEqual(b['sequence'],1)
        self.assertEqual(b['head'],a['head'])
        self.assertEqual(len(self.status()[0].state['events']),1)
    def test_02_missing_stock_rejected_without_debit(self):
        x=self.lab.run('SBX-FC03-PASS-FIRST')
        after=x['stock_after']
        y=self.lab.run('SBX-FC03-NO-STOCK')
        self.assertEqual(y['receipt']['status'],'REJECTED_PRECHECK')
        self.assertIn('INSUFFICIENT_QUANTITY',y['receipt']['rejection_reasons'])
        self.assertEqual(y['stock_after'],after)
        self.assertEqual(y['receipt']['consumed'],[])
        self.assertEqual(y['receipt']['products'],[])
    def test_03_QA_fail_scraps_material_without_product(self):
        m=measurements_good();m['closure_secure']=False
        x=self.lab.run('SBX-FC03-QA-FAIL',measurements=m)
        self.assertEqual(x['receipt']['status'],'REJECTED_QUALITY')
        self.assertEqual(x['receipt']['products'],[])
        self.assertEqual(len(x['receipt']['consumed']),3)
        self.assertEqual(len(x['receipt']['scrap']),1)
        self.assertTrue(self.status()[0].audit()['ok'])
    def test_04_duplicate_attempt_conflict(self):
        self.lab.run('SBX-FC03-DUP-CONFLICT')
        m=measurements_good();m['width_mm']=51
        with self.assertRaisesRegex(SandboxError,'IDEMPOTENCY_KEY_REUSE'):
            self.lab.run('SBX-FC03-DUP-CONFLICT',measurements=m)
        self.assertEqual(self.status()[1]['sequence'],1)
    def test_05_missing_tool_preflight(self):
        t=tools()[1:]
        x=self.lab.run('SBX-FC03-MISSING-TOOL',tools_override=t)
        self.assertEqual(x['receipt']['status'],'REJECTED_PRECHECK')
        self.assertIn('MISSING_REQUIRED_TOOL',x['receipt']['rejection_reasons'])
        self.assertEqual(x['stock_before'],x['stock_after'])
    def test_06_adulterated_source_fixture(self):
        self.lab=LabStore(Path(self.tmp.name)/'other')
        items=synthetic_lots();items[2]['source_page_id']='WRONG_SOURCE'
        self.lab.initialize(items)
        x=self.lab.run('SBX-FC03-WRONG-SOURCE')
        self.assertEqual(x['receipt']['status'],'REJECTED_PRECHECK')
        self.assertIn('SOURCE_OR_UNIT_MISMATCH',x['receipt']['rejection_reasons'])
    def test_07_missing_skill_rejected(self):
        x=self.lab.run('SBX-FC03-NO-SKILL',skills_override=skills()[:-1])
        self.assertEqual(x['receipt']['status'],'REJECTED_PRECHECK')
        self.assertIn('MISSING_REQUIRED_SKILL',x['receipt']['rejection_reasons'])
    def test_08_rollback_after_consumption_fault(self):
        core,ptr=self.status()
        with self.assertRaises(SimulatedCrash):
            self.lab.run('SBX-FC03-FAIL-AFTER-CONSUME',fault_stage='AFTER_CONSUME')
        q,h=self.status();self.assertEqual(q.state['lots'],core.state['lots'])
        self.assertEqual(h['sequence'],0)
    def test_09_rollback_after_quality_fault(self):
        with self.assertRaises(SimulatedCrash):
            self.lab.run('SBX-FC03-FAIL-AFTER-QA',fault_stage='AFTER_QA')
        core,ptr=self.status()
        self.assertEqual(ptr['sequence'],0)
        self.assertEqual(len(core.state['products']),0)
    def test_10_orphan_checkpoint_fails_closed(self):
        with self.assertRaisesRegex(Crash,'UNKNOWN_EFFECT'):
            self.lab.run('SBX-FC03-ORPHAN',commit_fault='AFTER_SNAPSHOT_BEFORE_POINTER')
        with self.assertRaisesRegex(LabError,'UNKNOWN_EFFECT'):
            self.lab.recover()
        with self.assertRaisesRegex(LabError,'UNKNOWN_EFFECT'):
            self.lab.run('SBX-FC03-ORPHAN')
    def test_11_lost_ack_safe_idempotent_retry(self):
        with self.assertRaisesRegex(Crash,'ACK_LOST'):
            self.lab.run('SBX-FC03-LOST-ACK',commit_fault='AFTER_POINTER_BEFORE_ACK')
        engine,ptr=self.status();self.assertEqual(ptr['sequence'],1)
        again=self.lab.run('SBX-FC03-LOST-ACK')
        self.assertTrue(again['idempotent_replay'])
        self.assertEqual(again['sequence'],1)
        self.assertTrue(engine.audit()['ok'])
    def test_12_tampered_checkpoint_refused(self):
        self.lab.run('SBX-FC03-CHECKPOINT')
        ptr=json.loads((self.path/'CURRENT.json').read_text())
        p=self.path/'commits'/ptr['current']; p.write_bytes(p.read_bytes()+b'attack')
        with self.assertRaisesRegex(LabError,'CHECKPOINT_BYTES_TAMPERED'):
            self.lab.recover()
    def test_13_stale_head_CAS(self):
        old=self.status()[1]['head']; self.lab.run('SBX-FC03-ADVANCE')
        with self.assertRaisesRegex(LabError,'STALE_HEAD'):
            self.lab.run('SBX-FC03-STALE',expected_head=old)
        self.assertEqual(self.status()[1]['sequence'],1)
    def test_14_concurrency_same_material_one_winner(self):
        ids=['SBX-FC03-RACE-LEFT','SBX-FC03-RACE-RIGHT']
        runners=[subprocess.Popen([sys.executable,str(RUNNER),'run','--store',str(self.path),'--id',i],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for i in ids]
        data=[]
        for p in runners:
            out,err=p.communicate(timeout=20)
            self.assertEqual(p.returncode,0,err)
            data.append(json.loads(out))
        self.assertEqual(sorted([a['receipt']['status'] for a in data]),['EXPERIMENTAL_QA_PASS','REJECTED_PRECHECK'])
        x,p=self.status();self.assertEqual(p['sequence'],2)
        self.assertTrue(x.audit()['ok'])
        self.assertEqual(len(x.state['products']),1)
    def test_15_unknown_lot_no_consume(self):
        x=self.lab.run('SBX-FC03-UNKNOWN-LOT',lot_ids_override=['SBX-FC03-CHITIN-A','SBX-FC03-CHITIN-B','SBX-FAKE-LOT'])
        self.assertEqual(x['receipt']['status'],'REJECTED_PRECHECK')
        self.assertEqual(x['stock_before'],x['stock_after'])
    def test_16_bad_qa_never_passes(self):
        m=measurements_good();m.pop('hinge_cycle_count')
        a=self.lab.run('SBX-FC03-BAD-QA',measurements=m)
        self.assertEqual(a['receipt']['status'],'REJECTED_QUALITY')
        self.assertTrue(any('MISSING_OR_INVALID' in r for r in a['receipt']['rejection_reasons']))
    def test_17_recipe_hash_prevents_silent_change(self):
        self.lab.run('SBX-FC03-IMMUTABLE-RECIPE')
        core,p=self.status();self.assertEqual(core.recipe_hashes[KEY],__import__('fastclose03_lab').digest(recipes()[KEY]))
    def test_18_unauthorized_real_ID_absent(self):
        x=self.lab.run('SBX-FC03-SCOPE')
        self.assertIsNone(x['receipt']['official_rec_id'])
        self.assertFalse(x['receipt']['official_materialization'])
        self.assertEqual(x['official_stock_effect'],0)
        self.assertEqual(x['receipt']['products'][0]['mechanical_bonus'],0)

if __name__=='__main__':unittest.main(verbosity=2)
