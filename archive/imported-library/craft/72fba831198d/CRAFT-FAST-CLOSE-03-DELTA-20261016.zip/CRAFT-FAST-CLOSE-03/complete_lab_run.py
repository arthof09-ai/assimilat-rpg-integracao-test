"""Materialize exact TEST receipts, negative QA case, reopen & economy classification."""
import sys,json,hashlib,copy
from pathlib import Path
HERE=Path(__file__).parent.resolve();sys.path.insert(0,str(HERE))
from fastclose03_lab import LabStore,LabError,measurements_good,CHITIN,FIBER,KEY
from experimental_engine import digest
OUT=HERE/'outputs'
main=LabStore(OUT/'B30_22_MAIN_STORE')
e0,p0=main.recover()
assert p0['sequence']==1 and e0.audit()['ok']
succ=e0.state['attempts']['SBX-FC03-CASE-0001']
assert succ['status']=='EXPERIMENTAL_QA_PASS'
repeat=main.run('SBX-FC03-CASE-0001')
assert repeat['idempotent_replay'] and repeat['sequence']==1
failed=main.run('SBX-FC03-CASE-OUT-OF-STOCK')
assert failed['receipt']['status']=='REJECTED_PRECHECK'
e,p=main.recover();assert e.audit()['ok'] and p['sequence']==2
assert sum(v['quantity'] for v in e.state['lots'].values())==0
other=LabStore(OUT/'B30_22_QA_FAIL_STORE')
other.initialize()
m=measurements_good();m['closure_secure']=False
qa=other.run('SBX-FC03-CASE-QA-BAD',measurements=m)
assert qa['receipt']['status']=='REJECTED_QUALITY'
o,a=other.recover();assert o.audit()['ok']
res={'operation':'CM-000002-WS0001 / OP-ARQ-RIN-REC-01',
 'execution_class':'EXPERIMENTAL_EXECUTED_FIXTURES_NOT_PHYSICAL',
 'baseline_engine':'R44_RECOVERED_UNMODIFIED','r48_extension_scope':'R44_ONE_RECIPE_ADDITIVE_WITH_R47_DURABLE_PRIMITIVES; R47_AUTHENTICITY_NOT_EXTENDED',
 'recipe_key':KEY,'source_ids':{'chitin':CHITIN,'fiber':FIBER},
 'input_lots':[{'source':CHITIN,'qty':2,'unit':'placa','lot_ids':['SBX-FC03-CHITIN-A','SBX-FC03-CHITIN-B']},
               {'source':FIBER,'qty':30,'unit':'cm','lot_ids':['SBX-FC03-FIBER-30CM']}],
 'successful_attempt':succ,'successful_product':succ['products'][0],
 'main_stock_after':{k:v['quantity'] for k,v in e.state['lots'].items()},
 'duplicate_replay':repeat,'no_stock_rejection':failed,
 'quality_failure_separate_store':qa,'main_disk':p,'main_audit':e.audit(),
 'failed_qa_disk':a,'failed_qa_audit':o.audit(),
 'economy':{'standard':'PR-ECO-01 Annex C','formula':'CTE=CI+CP+CF+CT+CE+CK+CL+CA+CC',
   'cost_nodes':{'CI':'two chitin plates + 30cm processed fiber (PS, no sourced price)',
   'CP':'offcut/discard qty per lot unknown','CF':'failure rate unknown; separately simulated rejected QA',
   'CT':'45 proposed active minutes x operator rate unknown','CE':'reused drill/saw/gauge/clamp/PPE wear unknown',
   'CK':'knowhow/licence/operator verification unknown','CL':'route and transport unknown',
   'CA':'storage and contamination protection unknown','CC':'opportunity/capital unknown'},
   'MATERIAL_STOCK_REAL':False,'p_success':None,'MED':None,'CTE_numeric':None,
   'price_per_approved_unit':'CTE_lot / N_approved (only if verified N_approved>0, appropriate sourced costs)'},
 'official_rec_id':None,'official_status':'NOT_PUBLISHED','official_stock_effect':0}
(OUT/'b30_22_experiment_receipts.json').write_text(json.dumps(res,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps({'main_sequence':p['sequence'],'main_head':p['head'],'product_id':succ['products'][0]['product_id'],'success':succ['status'],'duplicate':repeat['idempotent_replay'],'negative_stock':failed['receipt']['status'],'negative_QA':qa['receipt']['status'],'audit_main':e.audit()['ok'],'audit_negative':o.audit()['ok'],'stock_after':res['main_stock_after'],'cost':res['economy']['MED']},ensure_ascii=False))
