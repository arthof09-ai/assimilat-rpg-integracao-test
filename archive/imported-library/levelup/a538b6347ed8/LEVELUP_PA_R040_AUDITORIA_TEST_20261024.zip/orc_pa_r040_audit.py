#!/usr/bin/env python3
"""Auditoria independente de PA do Orc TEST — R216-P23-040.

NÃO é motor de jogo, escritor Notion, patch de ficha ou fornecedor de PA.
É uma fixture de regressão em modo leitura reconstruída das 25 fichas R216-P14
reabertas no Notion Mestre em 24/10/2026. Na dúvida, a ficha e o motor PA R27→R26 prevalecem.
Executar: python3 orc_pa_r040_audit.py
"""
from __future__ import annotations
import json, hashlib, unittest
from pathlib import Path

RANKS = ('Bronze', 'Prata', 'Ouro', 'Ouro Negro', 'Lendário')
FLOOR = {'Bronze':8, 'Prata':11, 'Ouro':21, 'Ouro Negro':35, 'Lendário':90}
USE = {'Bronze':3, 'Prata':7, 'Ouro':14, 'Ouro Negro':21, 'Lendário':30}
ACTIVE_DAY = {'Bronze':3, 'Prata':6, 'Ouro':12, 'Ouro Negro':17, 'Lendário':25}
NAMES = [
 'Couraça da Muralha','Machado da Ruptura','Manoplas da Bigorna',
 'Cinto do Bastião','Botas da Escarpa','Anel da Guarda',
 'Elmo do Estandarte','Capa do Desfiladeiro','Braçadeiras do Golpe Medido',
 'Amuleto da Forja','Anel de Golpe','Insígnia da Escolta',
 'Arnês Antitombo','Espada da Guarda','Escudo de Passagem','Selo de Emergência'
]
BOOST = {2,3,4,9}
ON_BY_LEVEL = {1:8,2:10,3:11,4:12}
MIXED_24 = [
 ('Lendário',90,30,0,'Lendário','E3: CA física fora de escala; efeito reativo L'),
 ('Lendário',90,30,0,'Lendário','E2: Ruptura L, ataque normal Ouro'),
 ('Ouro',21,14,4,'Prata','E3: +4 FOR por dois turnos'),
 ('Ouro',21,14,4,'Prata','E3: +4 CON por dois turnos'),
 ('Prata',11,7,2,'Prata','E3: limiar Bronze/Prata; cenário Bronze alternativo'),
 ('Ouro Negro',35,21,0,'Ouro Negro','E3: +6 CA reativa'),
 ('Prata',11,7,0,'Prata','E3: +4 Vontade versus medo'),
 ('Ouro Negro',35,21,0,'Lendário','E3: +10 Furtividade condicionada'),
 ('Ouro',21,14,0,'Ouro Negro','E3: +8 no acerto preparado'),
 ('Ouro',21,14,4,'Prata','E3: +4 INT em um teste preparado')
]
EXPECTED = [64,80,88,96,112] + [179]*5 + [309]*5 + [475]*5 + [810]*3 + [356]*2
PA_GROSS = {23:969,24:1008,25:1048}


def make_rows(level: int):
    if level <= 5:
        rank, on_count, b = 'Bronze', ON_BY_LEVEL.get(level,13), (2 if level==5 else 1)
    elif level <= 10:
        rank, on_count, b = 'Prata', 13, 4
    elif level <= 15:
        rank, on_count, b = 'Ouro', 13, 6
    elif level <= 20:
        rank, on_count, b = 'Ouro Negro', 13, 8
    elif level <= 23:
        rank, on_count, b = 'Lendário', 9, 10
    else:
        rank, on_count, b = 'Lendário', 10, 0
    rows=[]
    for pos, name in enumerate(NAMES):
        active = pos < on_count
        if level==1 and name=='Braçadeiras do Golpe Medido': active=False
        if level <= 23:
            item_rank=rank
            attr = b if pos in BOOST else 0
            cost = max(FLOOR[item_rank], 5*attr) if active else 0
            use=USE[rank]
            effect_rank = 'Bronze' if name=='Arnês Antitombo' else rank
            evidence = 'E3: provisório'
        else:
            if active:
                item_rank,cost,use,attr,effect_rank,evidence=MIXED_24[pos]
            else:
                item_rank={10:'Ouro',11:'Prata',12:'Ouro',13:'Lendário',14:'Ouro Negro',15:'Ouro Negro'}[pos]
                cost, use, attr, effect_rank, evidence = 0, None, 0, None, 'HOLD: desligado; efeito não ativável'
        rows.append({'slot':pos+1,'item':name,'on':active,'ri_nominal_test':item_rank,
                     'pa_dia_publicado':cost,'pa_uso_publicado':use,'atributo_bonus_test':attr,
                     're_candidato':effect_rank,'evidencia':evidence})
    return {'level':level,'rank_personagem':rank,'slots':rows,
            'total_diario':sum(row['pa_dia_publicado'] for row in rows)}

DATA = [make_rows(lvl) for lvl in range(1,26)]
SLOT_INDEX = {name:i for i,name in enumerate(NAMES)}

def active_by(level):
    return {r['item']:r for r in DATA[level-1]['slots'] if r['on']}


def transition_rows():
    before, after=active_by(23), active_by(24)
    out=[]
    for name in NAMES:
        x=before.get(name);y=after.get(name)
        if x or y:
            out.append({'item':name,'ri_n23':x['ri_nominal_test'] if x else None,
                        'ri_n24':y['ri_nominal_test'] if y else None,
                        'pa_n23':x['pa_dia_publicado'] if x else 0,
                        'pa_n24':y['pa_dia_publicado'] if y else 0,
                        'delta_pa_dia':(y['pa_dia_publicado'] if y else 0)-(x['pa_dia_publicado'] if x else 0)})
    return out


def activation_scenarios():
    published=active_by(24)
    assumed_by_re={name: USE[slot['re_candidato']] for name,slot in published.items()}
    old=sum(slot['pa_uso_publicado'] for slot in published.values())
    alt=sum(assumed_by_re.values())
    boundary=dict(assumed_by_re)
    boundary['Botas da Escarpa']=USE['Bronze']
    return {'soma_de_um_uso_por_item_somente_matematica':old,
            'tarifa_se_re_candidato_confirmado':alt,
            'tarifa_se_botas_bronze_confirmadas':sum(boundary.values()),
            'variantes':{name:{'rank_item':slot['ri_nominal_test'],
                               're_candidato':slot['re_candidato'],
                               'publicado':slot['pa_uso_publicado'],
                               'condicional':assumed_by_re[name],
                               'delta':assumed_by_re[name]-slot['pa_uso_publicado']}
                        for name,slot in published.items()}}


class TestContract(unittest.TestCase):
    def test_all_25_400(self):
        self.assertEqual(len(DATA),25)
        self.assertEqual(sum(len(x['slots']) for x in DATA),400)
        for i,page in enumerate(DATA):
            self.assertEqual(len(page['slots']),16)
            self.assertEqual(len({x['item'] for x in page['slots']}),16)
            self.assertEqual(page['total_diario'],EXPECTED[i],f'N{i+1:02}')

    def test_floor_and_attribute_without_double_count(self):
        for page in DATA:
            for item in page['slots']:
                if not item['on']:
                    self.assertEqual(item['pa_dia_publicado'],0)
                else:
                    rank=item['ri_nominal_test'];attrib=item['atributo_bonus_test']
                    self.assertEqual(item['pa_dia_publicado'],max(FLOOR[rank],5*attrib),
                                     (page['level'],item['item']))

    def test_24_25_identical_loadout(self):
        self.assertEqual(DATA[23]['slots'],DATA[24]['slots'])
        self.assertEqual(sum(1 for r in DATA[23]['slots'] if r['on']),10)
        self.assertEqual(DATA[23]['total_diario'],356)

    def test_transition_is_7_reclassifications_plus_one_new_on(self):
        t=transition_rows()
        down=[x for x in t if x['ri_n23'] and x['ri_n24'] and x['ri_n23']!=x['ri_n24']]
        self.assertEqual(len(down),7)
        self.assertEqual([x['item'] for x in t if x['ri_n23'] is None],['Amuleto da Forja'])
        self.assertEqual(sum(x['delta_pa_dia'] for x in t),-454)
        self.assertEqual(sum(x['delta_pa_dia'] for x in down),-475)

    def test_pa_free_scenarios(self):
        self.assertEqual(PA_GROSS[23]-DATA[22]['total_diario'],159)
        self.assertEqual(PA_GROSS[24]-DATA[23]['total_diario'],652)
        self.assertEqual(PA_GROSS[25]-DATA[24]['total_diario'],692)
        self.assertEqual(PA_GROSS[24]-810,198)
        self.assertEqual(PA_GROSS[25]-810,238)
        self.assertEqual(652-159,493)
        self.assertEqual(493,39+454)

    def test_candidate_cast_tariffs_are_not_published_tariffs(self):
        a=activation_scenarios()
        self.assertEqual(a['soma_de_um_uso_por_item_somente_matematica'],172)
        self.assertEqual(a['tarifa_se_re_candidato_confirmado'],167)
        self.assertEqual(a['tarifa_se_botas_bronze_confirmadas'],163)
        self.assertEqual(sum(1 for v in a['variantes'].values() if v['delta']!=0),5)

    def test_arnes_effect_does_not_scale_with_carrier(self):
        for lvl in range(5,21):
            row=DATA[lvl-1]['slots'][SLOT_INDEX['Arnês Antitombo']]
            self.assertEqual(row['re_candidato'],'Bronze')
            self.assertTrue(row['on'])
        differing=sum(1 for lvl in range(5,21)
                      if DATA[lvl-1]['slots'][SLOT_INDEX['Arnês Antitombo']]['pa_uso_publicado']!=USE['Bronze'])
        self.assertEqual(differing,15)


def main():
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(TestContract)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful()
    out={'id':'IBX17-R216-P23-040-PA-TEST-READONLY','date':'2026-10-24',
        'scope':'MESTRE-SIDE TEST; audit fixture, not native engine nor canonical item ranking',
        'sources':{
           'operation':'https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107',
           'atlas':'https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab',
           'pa_errata':'https://app.notion.com/p/3edc2b324ede81d0b25ec2f3be128db6',
           'N23':'https://app.notion.com/p/400c2b324ede81e894a1f4ac84354ee2',
           'N24':'https://app.notion.com/p/400c2b324ede81789207ccb2bac264b2',
           'N25':'https://app.notion.com/p/400c2b324ede815abca2ce4fb08a8cdc'},
        'status':{'arithmetical_daily':'PASS','rank_effect':'HOLD E3','canonical_items':'HOLD',
                  'real_loadout_swap':'HOLD','native_PA_runner':'NOT EXECUTED',
                  'VLAB_combat':'NOT EXECUTED', 'writer':'NOT CLAIMED'},
        'totals_25':[x['total_diario'] for x in DATA],
        'matrix_25_levels_400_slots':DATA,
        'transition_N23_N24':transition_rows(),
        'activation_conditional_only':activation_scenarios(),
        'change_in_gross_PA':39,'change_in_daily_cost':-454,'change_in_free_PA':493,
        'hypothesis_no_swap':{'N24_pa_free':198,'N25_pa_free':238},
        'test_methods':result.testsRun,'test_failures':len(result.failures),'test_errors':len(result.errors),
        'note':'As tarifas RE e cenários não são comandos para atualizar PA da ficha; confirmar RI/RE pela autoridade Atlas/PA. Alteração em combate/dia não implica restituição retroativa da manutenção paga.'}
    p=Path(__file__).with_name('orc_pa_r040_evidence.json')
    content=json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
    p.write_text(content,encoding='utf8')
    digest=hashlib.sha256(content.encode()).hexdigest()
    print(json.dumps({'test_run':result.testsRun,'pass':result.wasSuccessful(),'25_levels':25,'slots':400,
                      'N23_24_daily_delta':-454,'gross_delta':39,'free_delta':493,
                      'N24_published_activations_one_each':172,
                      'N24_conditional_RE_activations_one_each':167,
                      'json_sha256':digest,'json_path':str(p)},ensure_ascii=False))

if __name__=='__main__':main()
