LEVEL-UP — ORC Alma suficiente: PREVIA MESTRE-ONLY TEST — R216-P23-042 (24/10/2026)

É uma proposta de loadout para as 25 fichas Orc existentes, não uma nova regra ou
motor PA. O código NÃO escreve em Notion, em fichas, no GitHub, no VLAB ou na Party.

FONTE: Evidência R040 de 25 fichas / 400 slots, previamente auditada e guardada
na Biblioteca Mestre. Este pacote usa o ZIP R040 existente como input read-only,
com SHA registrado dentro do JSON. Valores de Alma bruta conferidos nas fichas.

Objetivo do Mestre: equipamento não pode comprometer a capacidade mínima de
transformar, ativar uma técnica realmente acessível e ter sobra de Alma.

Contrato TEST PROPOSTO, NÃO CANÔNICO:
- Bronze 1 a 5: transformação proibida, mas manter Tranco de Guarda 6 PA +
  25% da Alma bruta como reserva após custo diário do arsenal normal.
- Prata 1 a 5: T9 40 PA + Pisada Quebra-Linha 12 PA + 25% Alma bruta.
- Ouro 1 a 5: T9 80 PA + Terremoto Raso 24 PA + 25% Alma bruta.
- Ouro Negro 1 a 5: T9 160 PA + Bastião Vivo 35 PA + 25% Alma bruta.
- Lendário 1 a 5: T9 320 PA + Sentença do Titã 50 PA + 25% Alma bruta.
Cálculo exato: PA bruto (já com apenas 2 Anéis da Alma, +100) −
manutenção TEST − T9 − habilidade >= ceil(0,25 × PA bruto).

Regra de seleção: nunca LIGAR equipamento antes em reserva; preservar a Couraça
(slot1), Machado (slot2) e priorizar Cinto (4), Manoplas (3), Botas (5),
Anel Guarda (6), Braçadeiras (9), Capa (8), Elmo (7), Amuleto (10),
Insígnia (12), Anel Golpe (11) e Arnês (13) até caber no teto diário.
O valor desta seleção é proposta e precisa de análise de combate; não é ranking
canônico de utilidade, não garante retenção de equipamentos no corpo quadrúpede.

A planilha CSV tem todos os 25 cenários e listas completas dos slots ligados e
desligados. O JSON detalha nomes e custos. O script calcula, e unittest valida.
Execute apenas como auditor de saldo em ambiente offline: python preview_r042.py;
python -m unittest test_preview_r042.py. A prova do roteiro é TEST, não VLAB.

N24/N25 preservam orçamento publicado 356/dia mas RI/RE, sete trocas físicas
N23→N24 e custo de ativação dos itens continuam PENDENTES de validação.
Não existe garantia absoluta contra morte por drenagem de Alma: não foi
comprovado nesta rodada um limiar canônico de 'desmaiar/morrer por Alma'.
25% é uma margem PROPOSTA para o Mestre avaliar, não regra geral.

NÃO HOUVE ativação real, compra, item novo, writer/lease/fencing, promoção
PS/P4, edição do personagem, nem publicação à Party.
