import unittest, json, zipfile, hashlib, math
from pathlib import Path
from preview_r042 import SRC,GROSS,CLASS,PREFERENCE,load,calculate,classify

class SoulBudgetPreviewR042(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.src=load();cls.rows=calculate()
    def test_01_original_25_all_slots(self):
        self.assertEqual(len(self.src),25)
        self.assertEqual(sum(map(lambda r:len(r['slots']),self.src)),400)
    def test_02_level_ordinal_rank(self):
        for i,row in enumerate(self.rows,1):
            self.assertEqual(row['n'],i);self.assertEqual(row['rank'],classify(i)[0])
    def test_03_reproduce_baseline_costs(self):
        for orig,row in zip(self.src,self.rows):
            self.assertEqual(sum(s['pa_dia_publicado'] for s in orig['slots']),row['pa_dia_atual'])
            self.assertEqual(row['pa_livre_atual'],row['pa_bruto_com_2_aneis']-row['pa_dia_atual'])
    def test_04_bronze_t9_forbidden(self):
        for row in self.rows[:5]:
            self.assertEqual(row['status'],'BRONZE_SEM_T9');self.assertIsNone(row['t9_custo'])
    def test_05_bronze_one_normal_skill_buffer(self):
        for row in self.rows[:5]:
            self.assertEqual(row['habilidade_custo'],6)
            self.assertGreaterEqual(row['pa_restante_depois_de_t9_e_habilidade_TEST'],row['reserva_alvo_TEST_25pct'])
    def test_06_spirit_20_pay_t9_and_rank_skill(self):
        for row in self.rows[5:]:
            self.assertEqual(row['pa_bruto_com_2_aneis']-row['pa_dia_previa_TEST']-row['t9_custo']-row['habilidade_custo'],row['pa_restante_depois_de_t9_e_habilidade_TEST'])
            self.assertGreater(row['t9_custo'],0);self.assertGreater(row['habilidade_custo'],0)
    def test_07_buffer_25pct_20_eligible(self):
        for row in self.rows[5:]:
            self.assertEqual(row['reserva_alvo_TEST_25pct'],math.ceil(row['pa_bruto_com_2_aneis']/4))
            self.assertGreaterEqual(row['pa_restante_depois_de_t9_e_habilidade_TEST'],row['reserva_alvo_TEST_25pct'])
    def test_08_no_new_equipment_no_off_to_on(self):
        for src,row in zip(self.src,self.rows):
            original_on={s['slot'] for s in src['slots'] if s['on']}
            new_on={s['slot'] for s in row['slots_manter']}
            self.assertTrue(new_on.issubset(original_on))
            self.assertTrue(all(x['slot'] in original_on for x in row['slots_desenergizar']))
    def test_09_weapon_and_armor_remain(self):
        for row in self.rows:
            self.assertTrue({1,2}.issubset({x['slot'] for x in row['slots_manter']}))
    def test_10_exact_maintenance_delta(self):
        for row in self.rows:
            self.assertEqual(row['energia_liberada_diaria'],row['pa_dia_atual']-row['pa_dia_previa_TEST'])
            self.assertEqual(row['energia_liberada_diaria'],sum(z['pa_dia'] for z in row['slots_desenergizar']))
    def test_11_legendary_early_case(self):
        for row in self.rows[20:23]:
            self.assertEqual(row['pa_dia_previa_TEST'],270)
            self.assertEqual(row['t9_custo'],320)
            self.assertEqual(row['habilidade_custo'],50)
            self.assertEqual({x['slot'] for x in row['slots_manter']},{1,2,4})
    def test_12_legendary_4_5_unchanged(self):
        for row in self.rows[23:]:
            self.assertEqual(row['pa_dia_previa_TEST'],356)
            self.assertEqual(row['energia_liberada_diaria'],0)
    def test_13_zero_new_writes(self):
        for row in self.rows:
            self.assertEqual(row['proveniencia'].startswith('R040 inventory'),True)
        self.assertEqual(len(PREFERENCE),13)

if __name__=='__main__':unittest.main(verbosity=2)
