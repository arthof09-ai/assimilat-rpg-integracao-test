"""READ-ONLY Orc energy-budget preview from R040 fixture; not the PA or VLAB engine.
Mestre-only / TEST. No canonization. Uses one spiritual skill + T9 + 25% buffer.
"""
from __future__ import annotations
import json, math, zipfile, hashlib, csv
from pathlib import Path
SRC=Path('/mnt/data/LEVELUP_PA_R040_AUDITORIA_TEST_20261024.zip')
BASE=Path(__file__).parent
GROSS=[122,131,142,154,168,216,234,253,273,295,367,390,414,439,465,578,607,636,666,697,891,930,969,1008,1048]
CLASS=[('Bronze',0,6,'Tranco de Guarda'),('Prata',40,12,'Pisada Quebra-Linha'),('Ouro',80,24,'Terremoto Raso'),('Ouro Negro',160,35,'Bastião Vivo'),('Lendário',320,50,'Sentença do Titã')]
# Scores are TEST equipment-priority preferences, not rule or canonical ranking.
PREFERENCE=[1,2,4,3,5,6,9,8,7,10,12,11,13]

def classify(n):return CLASS[(n-1)//5]

def load():
    with zipfile.ZipFile(SRC) as z:
        assert z.testzip() is None
        obj=json.loads(z.read('orc_pa_r040_evidence.json'))
    return obj['matrix_25_levels_400_slots']

def calculate():
    src=load()
    assert len(src)==25
    results=[]
    for i,cur in enumerate(src):
        n=i+1
        rank,t9,skill,skill_name=classify(n)
        assert cur['level']==n and cur['rank_personagem']==rank
        slots=cur['slots'];assert len(slots)==16 and len(set(s['slot'] for s in slots))==16
        assert sum(s['pa_dia_publicado'] for s in slots)==cur['total_diario']
        gross=GROSS[i];before=cur['total_diario'];free=gross-before
        buffer=math.ceil(gross/4)
        if n<=5:
            # Bronze T9 is expressly forbidden: do not allocate the historic 20 PA cost.
            selected=[s['slot'] for s in slots if s['on']]
            after=before
            post=gross-after-skill
            available=post>=buffer
        else:
            max_daily=gross-t9-skill-buffer
            assert max_daily>=0,(n,max_daily)
            if before<=max_daily:
                selected=[s['slot'] for s in slots if s['on']]
            else:
                # Preserve physical armor and two-handed axe as mandatory combat core,
                # add optional effects by a fixed, explainable priority until daily budget.
                mandatory=[1,2]
                active={s['slot']:s for s in slots if s['on']}
                assert set(mandatory).issubset(active)
                selected=[]
                used=0
                for sid in PREFERENCE:
                    if sid not in active:continue
                    p=active[sid]['pa_dia_publicado']
                    if used+p<=max_daily:
                        selected.append(sid); used+=p
                assert set(mandatory).issubset(selected)
            after=sum(s['pa_dia_publicado'] for s in slots if s['slot'] in selected)
            post=gross-after-t9-skill
            available=post>=buffer
        assert available, (n,post,buffer)
        toturn=[{'slot':s['slot'],'item':s['item'],'pa_dia':s['pa_dia_publicado']} for s in slots if s['on'] and s['slot'] not in selected]
        keep=[{'slot':s['slot'],'item':s['item'],'pa_dia':s['pa_dia_publicado']} for s in slots if s['on'] and s['slot'] in selected]
        assert sum(x['pa_dia'] for x in keep)==after
        assert (before-after)==sum(x['pa_dia'] for x in toturn)
        results.append(dict(n=n,rank=rank,pa_bruto_com_2_aneis=gross,pa_dia_atual=before,pa_livre_atual=free,t9_custo=t9 if n>5 else None,
            habilidade=skill_name,habilidade_custo=skill,reserva_alvo_TEST_25pct=buffer,
            teto_pa_dia_para_meta=(gross-t9-skill-buffer if n>5 else None),pa_dia_previa_TEST=after,
            pa_livre_previa_antes_de_t9=gross-after,pa_restante_depois_de_t9_e_habilidade_TEST=post,
            energia_liberada_diaria=before-after,slots_ativos_antes=sum(1 for s in slots if s['on']),
            slots_ativos_depois=len(selected),slots_manter=keep,slots_desenergizar=toturn,
            status='BRONZE_SEM_T9' if n<=5 else 'T9_HABILIDADE_E_BUFFER_PROPOSTO_PASS',
            proveniencia='R040 inventory + live Alma/PA readback; TEST preview; no equipment writes or actual spending'))
    return results

if __name__=='__main__':
    data=calculate()
    (BASE/'orc_alma_r042_25_previews.json').write_text(json.dumps({'status':'TEST_UNAPPLIED','policy':'25% bruta TEST; T9+one meaningful Spirit technique; Bronze normal technique only',
        'source_r040_zip_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(), 'results':data},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (BASE/'orc_alma_r042_25_previews.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f)
        w.writerow(['Nivel','Rank','PA bruto','PA dia atual','PA livre atual','T9','Habilidade','PA habilidade','25pct buffer','PA dia TEST proposto','PA livre pre T9','PA depois T9+habilidade','PA liberado dia','Manter slots','Desenergizar slots','Resultado'])
        for x in data:
            w.writerow([x['n'],x['rank'],x['pa_bruto_com_2_aneis'],x['pa_dia_atual'],x['pa_livre_atual'],x['t9_custo'] or 'proibido',x['habilidade'],x['habilidade_custo'],x['reserva_alvo_TEST_25pct'],x['pa_dia_previa_TEST'],x['pa_livre_previa_antes_de_t9'],x['pa_restante_depois_de_t9_e_habilidade_TEST'],x['energia_liberada_diaria'],','.join(str(z['slot']) for z in x['slots_manter']),','.join(str(z['slot']) for z in x['slots_desenergizar']),x['status']])
    print('RESULT 25/25', 'eligible T9=',sum(x['n']>5 for x in data),'with buffer=',sum(x['status'].endswith('_PASS') for x in data))
    for x in data:
        print('N%02d %-11s G=%4s current=%3s T9=%3s skill=%2s buffer=%3s proposal_daily=%3s post=%3s off=%s' % (x['n'],x['rank'],x['pa_bruto_com_2_aneis'],x['pa_dia_atual'],x['t9_custo'] or 0,x['habilidade_custo'],x['reserva_alvo_TEST_25pct'],x['pa_dia_previa_TEST'],x['pa_restante_depois_de_t9_e_habilidade_TEST'],','.join(str(z['slot']) for z in x['slots_desenergizar'])))
