from pathlib import Path
import json,hashlib,zipfile,os,unittest,re
ROOT=Path('/mnt/data/orc_quality_p13'); P=Path('/mnt/data/ibx114_p12_corrected/orc25_r216p12_MASTER_CORRECTED/ORC_R216P12_25_NIVEIS_20_TRANSFORMACOES_MASTER_CORRIGIDOS.json')
D=json.loads(P.read_text()); source_sha=hashlib.sha256(P.read_bytes()).hexdigest()
replaced=[]
for p in D['profiles']:
    prev=p['FULL']['combat_attack_dme_preview_TEST'];raw=prev['physical_attack_expression'];new=prev['physical_dice']
    prev['physical_attack_expression_original_P12_RETAINED_HISTORY']=raw
    prev['physical_attack_expression']=new
    a=p['base_attr'];pd={"BRONZE":"1d6","PRATA":"2d6","OURO":"3d6","OURO_NEGRO":"4d6","LENDARIO":"6d6"}[p['rank']]
    prev['attack_test_separate_not_damage_TEST']=f'{pd}+FOR({a["FOR"]})+Lutar inicial +2 (TENTATIVE_ALIAS)'
    prev['damage_components_NOT_auto_applied']=['FOR do usuário','valor da proficiência de Luta/Lutar','soma das pericias nos dados de dano','bônus ainda não ativados']
    prev['confirmed_weapon_damage_base_by_VLAB_TEST']=new
    prev['TEST_RIDER_REQUIRES_PA_AND_VALID_HIT']=prev.get('magical_weapon_rider_if_paid')
    replaced.append({'level':p['ordinal'],'before':raw,'after_weapon_dice':new,'test_attack_after':prev['attack_test_separate_not_damage_TEST']})
D['schema']='IBX114-R216P13-READONLY-REPRESENTATION-NIE_LI_REFERENCE'
D['P13_base_source_sha256']=source_sha
D['P13_field_attack_dice_separated']=True
D['P13_mutation_scope']='ONLY PRESENTATION OF ATTACK EXPRESSION AND EXPLICIT PROVENANCE FIELDS; ORIGINAL P12 ARCHIVE UNCHANGED'
D['P13_Notion_combat_scope']='MESTRE-SIDE TEST. 25 NORMAL + 20 TRANSFORMED IN LAB; not accepted as VLAB combat.'
D['P13_levelup_writer_status']='HOLD_ORC_UNKNOWN_ACTOR_NO_PROD_OR_PARTY_WRITE'
P13=ROOT/'ORC_P13_25_LEVELS_20_TRANSFORMATIONS_FIELD_CORRECTED_VIEW.json';P13.write_text(json.dumps(D,ensure_ascii=False,indent=2))
(ROOT/'ORC_P13_CHANGES_DAMAGE_EXPRESSIONS.json').write_text(json.dumps(replaced,ensure_ascii=False,indent=2))
(ROOT/'README_AUDITORIA_COMPARATIVA_NIE_LI.md').write_text('''# Orc R216-P13 — auditoria comparativa Mestre-only\n\n## Referência\nNie Li Mestre (no Notion): https://app.notion.com/p/86bc2b324ede827699688140e82db00b. A página apresenta pares de painéis completos para forma normal e transformação — Vida/Alma, atributos, defesa, proficiências, ações, itens e poderes para os dois estados. Sua matemática histórica não foi copiada cegamente.\n\n## Desvio P12\nAs 25 fichas do Orc no Notion eram resumos; 20 transformações apareciam como pequenos tópicos dentro das fichas normais; ausência de inventário pormenorizado, perícias completas e habilidades. No pacote JSON P12, 25 campos `physical_attack_expression` continham expressões incompatíveis com o dano físico da arma e indevidamente juntavam FOR/Lutar ao dano.\n\n## Correção P13\n1. Criadas 20 páginas Notion transformadas como filhas das 20 fichas normais de Prata1 a Lendário5, com mesma hierarquia de campos e gates.\n2. Atualizadas as 25 páginas normais de Bronze1 a Lendário5 com arsenal 16 itens e estados de PA, proficiências/ataques, técnicas e contexto de criação.\n3. Corrigidas 15 fichas com reduções físicas equivocadas da reação de item Bronze/Prata/Ouro para 6/14/25; preservadas Ouro Negro45 e Lendário75.\n4. Gerado view-model fiel e derivado, não uma engine paralela: `physical_attack_expression` recebe **somente o dado físico da arma**, `attack_test` passa a campo separado, FF e bônus só após gates. Preservado campo original com sufixo `..._original_P12_RETAINED_HISTORY` para auditoria.\n5. A relação Mestre confirmada é Espírito já Lendário e ex-Titã na assimilação Prata1, dois Anéis da Alma +100 livres sem custo diário; estrela L5, espécie Terra/Rocha, armamento, poderes e cultivo continuam TEST.\n\n## Limites\n- HP/Alma transformadas continuam teóricas T6, equipamento quadrúpede não adaptado, não somar automaticamente CA de armadura, RD ou ataque 20d10 da Besta viva.\n- Custos de PA dos 80 itens são envelopes TEST, não tarifa homologada em produção.\n- Não houve ensaio de combate VLAB nem promoção canônica de habilidades. Testes originais P12 2026/2026 PASS apenas para propriedades efetivamente cobertas.\n- Alterações na representação do Notion e dossiê P13 **não são transações nativas de nível**. Party, O Primeiro, VLAB NO-WRITE.\n\n## QA independente\nSuite P13 valida: 25 perfis, 20 formas, 80 itens e separação total ataque/dano/PA. O estado anterior P12 permanece como ZIP imutável.\n''')
class TestP13(unittest.TestCase):
 def test_level_count(self):self.assertEqual([x['ordinal'] for x in D['profiles']],list(range(1,26)))
 def test_pairing(self):self.assertEqual(len([x for x in D['transformations'] if x['available']]),20)
 def test_eighty_items(self):self.assertEqual(sum(len(v) for v in D['gear_ranked'].values()),80)
 def test_no_new_engine(self):self.assertTrue('READONLY-REPRESENTATION' in D['schema'])
 def test_data_sha(self):self.assertEqual(D['P13_base_source_sha256'],source_sha)
 def test_twenty_five_attack_expressions(self):
  for p in D['profiles']:
   with self.subTest(p=p['ordinal']):
    x=p['FULL']['combat_attack_dme_preview_TEST'];self.assertRegex(x['physical_attack_expression'],r'^\d+d6$');self.assertNotIn('FOR',x['physical_attack_expression']);self.assertNotIn('Lutar',x['physical_attack_expression']);self.assertIn('FOR',x['attack_test_separate_not_damage_TEST']);self.assertEqual(x['FOR_damage_bonus_applied'],0)
 def test_ring_all_levels(self):
  for p in D['profiles']:
   with self.subTest(level=p['ordinal']):
    self.assertEqual(p['pa_max_with_rings'],p['natural_pa']+100);self.assertEqual(p['FULL']['pa_free'],p['pa_max_with_rings']-p['FULL']['daily_pa_items']);self.assertEqual(p['FULL']['daily_pa_two_soul_rings_TEST'],0)
 def test_tap_all_twenty(self):
  for t in D['transformations']:
   if not t['available']:continue
   with self.subTest(level=t['level']):self.assertEqual(t['tap_total_distributed'],t['level']*11);self.assertEqual(sum(t['tap_allocation'].values()),t['tap_total_distributed'])
 def test_no_global_canon_claim(self):self.assertFalse(D['world_canon']);self.assertFalse(D['VLAB_accepted']);self.assertEqual(D['Party_writes'],0)
 def test_last_level(self):
  p=D['profiles'][-1];self.assertEqual(p['rank'],'LENDARIO');self.assertEqual(p['FULL']['pa_free'],148)
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(TestP13);res=unittest.TextTestRunner(verbosity=2).run(suite)
 receipt={'P13_new_test_methods':suite.countTestCases(),'pass':res.wasSuccessful(),'P12_source_sha256':source_sha,'P13_model_sha256':hashlib.sha256(P13.read_bytes()).hexdigest(),'field_damage_repaired':len(replaced),'new_Notion_forms_expected':20,'normal_pages_expected':25,'VLAB_combat_executed':0};(ROOT/'ORC_P13_TEST_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));
 if not res.wasSuccessful():raise SystemExit(1)
 for f in ROOT.glob('*.zip'):f.unlink()
 pack=ROOT/'IBX114_ORC_P13_AUDITORIA_NIELI_PRESENTACAO_MESTRE_ONLY.zip'
 with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as Z:
  for f in sorted(ROOT.iterdir()):
   if f.is_file() and f!=pack:Z.write(f,f.name)
 print('QA',json.dumps(receipt,ensure_ascii=False),'ZIP',pack,pack.stat().st_size)
