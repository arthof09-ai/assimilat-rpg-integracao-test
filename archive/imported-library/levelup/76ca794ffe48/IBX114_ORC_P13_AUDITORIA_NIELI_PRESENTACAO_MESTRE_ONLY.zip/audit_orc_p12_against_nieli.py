import json, re, hashlib, pathlib, statistics
from fractions import Fraction
SOURCE=pathlib.Path('/mnt/data/ibx114_p12_corrected/orc25_r216p12_MASTER_CORRECTED/ORC_R216P12_25_NIVEIS_20_TRANSFORMACOES_MASTER_CORRIGIDOS.json')
D=json.loads(SOURCE.read_text()); RANK=['BRONZE','PRATA','OURO','OURO_NEGRO','LENDARIO']; rankslots=dict(zip(RANK,[0,2,3,4,5]));t9=dict(zip(RANK,[None,40,80,160,320]));flags=[];checks=[]
def ck(cond,key,level,detail=''):
 checks.append({'level':level,'check':key,'pass':bool(cond),'detail':str(detail)[:200]})
assert len(D['profiles'])==25 and len(D['transformations'])==25 and sum(map(len,D['gear_ranked'].values()))==80
for p,t in zip(D['profiles'],D['transformations']):
 lv=p['ordinal'];rk=p['rank'];a=p['base_attr'];f=p['FULL'];r=p['TRANSFORM_READY_TEST'];atk=f['combat_attack_dme_preview_TEST']
 ck(lv==t['level'],'LEVEL_SYNC',lv)
 ck(p['pa_max_with_rings']==p['natural_pa']+100,'RING_GRANT_100',lv)
 ck(f['pa_free']==p['natural_pa']+100-f['daily_pa_items'],'PA_FREE_FULL',lv)
 ck(p['OFF']['pa_free']==p['natural_pa']+100,'PA_FREE_OFF',lv)
 ck(f['daily_pa_two_soul_rings_TEST']==0,'RING_NO_DAILY_COST',lv)
 ck(len(p['FULL']['powered'])+len(p['FULL']['unpowered_carried'])==16,'GEAR_COUNT',lv)
 ck('FOR' in atk['physical_attack_expression'] and atk['FOR_damage_bonus_applied']==0,'ATTACK_FORMULA_INTERNALLY_MISMATCHED_EXPECT_FALSE',lv,atk['physical_attack_expression']) # negative test audit, marked as known anomaly
 ck(atk['physical_dice']==({'BRONZE':'4d6','PRATA':'6d6','OURO':'8d6','OURO_NEGRO':'10d6','LENDARIO':'12d6'}[rk]),'PHYSICAL_DICE_BASE',lv)
 if not t['available']:
  ck(lv<=5,'BRONZE_NO_TRANSFORM',lv); continue
 ck(lv>=6,'TRANSFORM_ALLOWED',lv)
 ck(t['source_rank_already_legendary_before_assimilation'],'LENDARY_FIXED_AT_ASSIMILATION',lv)
 ck(not t['spirit_does_not_level_with_orc'] is False,'SPIRIT_DOES_NOT_EVOLVE',lv)
 ck(t['effective_level']==lv,'T2_CHARACTER_LEVEL',lv)
 ck(t['tap_per_level']==11 and t['tap_total_distributed']==lv*11,'TAP_LENDARY_FROM_P1',lv)
 ck(sum(t['tap_allocation'].values())==lv*11,'TAP_ALLOCATION_SUM',lv)
 ck(all(t['transformed_attributes'][k]-a[k]==t['tap_allocation'][k] for k in a),'TRANSFORM_ATTR_COMPOSITION',lv)
 ck(t['ability_slot_count']==rankslots[rk] and len(t['known_spirit_abilities_TEST'])==rankslots[rk],'ABILITY_SLOTS',lv)
 ck(t['transformed_FF']==10*sum(t['transformed_attributes'][k] for k in ['FOR','DES','CON']),'TRANSFORM_FF_BASE',lv)
 ck(r['PA_free_before_activation']==p['natural_pa']+100-r['daily_PA_items'],'TRANSFORM_READY_PA',lv)
 ck(r['PA_remaining_after_legal_activation_without_form_bonus']==r['PA_free_before_activation']-t9[rk],'TRANSFORM_PA_AFTER_ACTIVATION',lv)
 ck(t['transformed_item_fit'].startswith('NO AUTOMATIC'),'MORPHOLOGY_HOLD',lv)
 ck(t['source_policy'].startswith('T6_B_'),'HP_SOURCING_CONDITIONAL',lv)
for rk,g in D['gear_ranked'].items():
 for item in g:
  ck(item['pa_day_if_powered_TEST']>0,'ITEM_DAILY_TEST',rk,item['name'])
  ck(item['magic_PA_PER_DAY'].startswith('PENDENTE'),'ITEM_CANON_PA_PENDING',rk,item['name'])
  ck(item['rank_item_RI']==rk,'ITEM_RI',rk,item['name'])
anomalies=[]
for p in D['profiles']:
 atk=p['FULL']['combat_attack_dme_preview_TEST'];old=atk['physical_attack_expression'];
 if 'FOR ' in old and '+' in old:
  anomalies.append({'level':p['ordinal'],'classification':'BUG_FIELD_ATTACK_EXPRESSION','raw_expression':old,'physical_weapon_dice':atk['physical_dice'],'for_damage_applied_elsewhere':atk['FOR_damage_bonus_applied'],'correction':'Exibir '+atk['physical_dice']+' como dano físico; FOR e perícia são teste de ataque, FF separado; rider apenas pago.'})
# Test audit flagged negative test is expected; separate all other invariants
fail=[x for x in checks if not x['pass'] and x['check']!='ATTACK_FORMULA_INTERNALLY_MISMATCHED_EXPECT_FALSE']
report={'schema':'ORC-P13-INDEPENDENT-CHECK-20261021','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'notion_nie_li_master_reference':'https://app.notion.com/p/86bc2b324ede827699688140e82db00b','normal_fichas':25,'full_transformed':20,'experimental_equipment':80,'tests_total':len(checks),'tests_pass_ignoring_expected_anomaly':len(checks)-len(fail),'failures':fail,'attack_expression_affected_levels':len(anomalies),'attack_expression_examples':anomalies[:2],'relevant_qa':'P12 suite 2026 tests passed prior to this independent field consistency audit; VLAB native combat executions not evidenced','normal_page_structure_gap':'No full inventory, skill text, attribute projections, separate transformed page','transform_unverified':['Armor fit on quadruped (HOLD)','T6 transformed HP/Alma theoretical','Spirit L5 star is hypothesis','FF milestone dice without roll lock (HOLD)','Full exact equipment per rank/activation costs are TEST','Host writer ORC UNKNOWN_ACTOR','VLAB acceptance absent'],'status':'TEST_CANDIDATE_NOT_VLAB_CERTIFIED'}
path=pathlib.Path('/mnt/data/orc_quality_p13');(path/'ORC_P13_AUDITORIA_INDEPENDENTE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(path/'ORC_P13_ANOMALIAS_DANO_25.json').write_text(json.dumps(anomalies,ensure_ascii=False,indent=2));print(json.dumps({k:report[k] for k in ['tests_total','tests_pass_ignoring_expected_anomaly','failures','attack_expression_affected_levels']},ensure_ascii=False));print('SHA',report['source_sha256'])
