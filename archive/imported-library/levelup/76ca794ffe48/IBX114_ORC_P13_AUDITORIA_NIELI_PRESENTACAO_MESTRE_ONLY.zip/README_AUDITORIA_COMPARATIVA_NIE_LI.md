# Orc R216-P13 — auditoria comparativa Mestre-only

## Referência
Nie Li Mestre (no Notion): https://app.notion.com/p/86bc2b324ede827699688140e82db00b. A página apresenta pares de painéis completos para forma normal e transformação — Vida/Alma, atributos, defesa, proficiências, ações, itens e poderes para os dois estados. Sua matemática histórica não foi copiada cegamente.

## Desvio P12
As 25 fichas do Orc no Notion eram resumos; 20 transformações apareciam como pequenos tópicos dentro das fichas normais; ausência de inventário pormenorizado, perícias completas e habilidades. No pacote JSON P12, 25 campos `physical_attack_expression` continham expressões incompatíveis com o dano físico da arma e indevidamente juntavam FOR/Lutar ao dano.

## Correção P13
1. Criadas 20 páginas Notion transformadas como filhas das 20 fichas normais de Prata1 a Lendário5, com mesma hierarquia de campos e gates.
2. Atualizadas as 25 páginas normais de Bronze1 a Lendário5 com arsenal 16 itens e estados de PA, proficiências/ataques, técnicas e contexto de criação.
3. Corrigidas 15 fichas com reduções físicas equivocadas da reação de item Bronze/Prata/Ouro para 6/14/25; preservadas Ouro Negro45 e Lendário75.
4. Gerado view-model fiel e derivado, não uma engine paralela: `physical_attack_expression` recebe **somente o dado físico da arma**, `attack_test` passa a campo separado, FF e bônus só após gates. Preservado campo original com sufixo `..._original_P12_RETAINED_HISTORY` para auditoria.
5. A relação Mestre confirmada é Espírito já Lendário e ex-Titã na assimilação Prata1, dois Anéis da Alma +100 livres sem custo diário; estrela L5, espécie Terra/Rocha, armamento, poderes e cultivo continuam TEST.

## Limites
- HP/Alma transformadas continuam teóricas T6, equipamento quadrúpede não adaptado, não somar automaticamente CA de armadura, RD ou ataque 20d10 da Besta viva.
- Custos de PA dos 80 itens são envelopes TEST, não tarifa homologada em produção.
- Não houve ensaio de combate VLAB nem promoção canônica de habilidades. Testes originais P12 2026/2026 PASS apenas para propriedades efetivamente cobertas.
- Alterações na representação do Notion e dossiê P13 **não são transações nativas de nível**. Party, O Primeiro, VLAB NO-WRITE.

## QA independente
Suite P13 valida: 25 perfis, 20 formas, 80 itens e separação total ataque/dano/PA. O estado anterior P12 permanece como ZIP imutável.
