import unittest,tempfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'baseline'/'runtime'))
from r177_native_gateway import CanaryPlan,NativeSnapshot,execute_canary,inspect,NativeGateHold
from r173_sqlite_causal_ledger import Ledger,LAB,LedgerHold
from r178_vz_auth_compatibility import reconcile,SourceHold,COMBAT,NORMAL,VZ
from r165_notional_table_source_parser import sample_matrix

class Transport:
 def __init__(self,refuse=False):
  self.parent=LAB;self.pid='LAB-MOCK';self.v=1;self.content='BRIDGE_PHYSICAL: BEFORE';self.calls=[];self.refuse=refuse
 def fetch_page(self,id):
  self.calls.append('fetch')
  return NativeSnapshot(self.pid,self.parent,f'V{self.v}',self.content)
 def append_content(self,id,content):
  self.calls.append('append');self.content+='\n'+content;self.v+=1;return {'page_id':id,'mock_only':True}
 def replace_unique(self,id,old,new):
  self.calls.append('replace')
  if self.refuse:raise PermissionError('OPENAI_CONNECTOR_SECURITY_REFUSAL')
  if self.content.count(old)!=1:raise ValueError('AMBIGUOUS')
  self.content=self.content.replace(old,new);self.v+=1;return {'page_id':id,'mock_only':True}

class NativeTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.db=Path(self.t.name)/'ledger.sqlite'
  self.plan=CanaryPlan('IBX17-R177-UNIT-CANARY','DOC_CANARY','LAB-MOCK','RULE@1','V1','BRIDGE_PHYSICAL: BEFORE','BRIDGE_PHYSICAL: AFTER')
 def tearDown(self):self.t.cleanup()
 def test_authorized_mock_workflow(self):
  t=Transport();result=execute_canary(self.plan,t,str(self.db))
  self.assertEqual(result['state'],'READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION')
  self.assertEqual(t.content.count('R177_INTENT_RECEIPT:'),1)
  self.assertEqual(t.content.count('R177_JOURNAL_RECEIPT:'),1)
  with Ledger(self.db) as l:self.assertEqual(l.verify_chain(self.plan.tx,self.plan.stage)['observations'],5)
 def test_replay_is_noop_and_no_tool_update(self):
  t=Transport();execute_canary(self.plan,t,str(self.db));writes=len([x for x in t.calls if x!='fetch']);
  with self.assertRaises(NativeGateHold):execute_canary(self.plan,t,str(self.db))
  # pre-state is AFTER so a second request is denied before even reading ledger.
  self.assertEqual(t.content.count('R177_JOURNAL_RECEIPT:'),1)
  self.assertEqual(writes,len([x for x in t.calls if x!='fetch']))
 def test_fenced_security_refusal(self):
  t=Transport(refuse=True);out=execute_canary(self.plan,t,str(self.db))
  self.assertEqual(out['state'],'SECURITY_REFUSAL_FENCED_READBACK_BEFORE')
  self.assertIn('BRIDGE_PHYSICAL: BEFORE',t.content)
  with Ledger(self.db) as l:self.assertEqual(l.classify(self.plan.tx,self.plan.stage)['state'],'SECURITY_FENCED_BEFORE')
 def test_foreign_parent_denied(self):
  t=Transport();t.parent='PARTY';
  with self.assertRaises(NativeGateHold):execute_canary(self.plan,t,str(self.db))
 def test_stale_version_denied(self):
  with self.assertRaises(NativeGateHold):execute_canary(CanaryPlan(**(self.plan.__dict__|{'pre_version':'V0'})),Transport(),str(self.db))
 def test_canary_only_stage(self):
  with self.assertRaises(NativeGateHold):CanaryPlan(**(self.plan.__dict__|{'stage':'NORMAL'})).validate()
 def test_not_allowing_mechanical_fields(self):
  with self.assertRaises(NativeGateHold):CanaryPlan(**(self.plan.__dict__|{'old_literal':'NORMAL_HP: 50'})).validate()
 def test_other_state_quarantined(self):
  t=Transport();t.content='BRIDGE_PHYSICAL: OTHER'
  with self.assertRaises(NativeGateHold):execute_canary(self.plan,t,str(self.db))
 def test_ledger_wont_accept_other_authority(self):
  with self.assertRaises(NativeGateHold):CanaryPlan(**(self.plan.__dict__|{'authority':'PARTY_WRITER'})).validate()
 def test_documentary_cas_limitation(self):
  t=Transport();out=execute_canary(self.plan,t,str(self.db));self.assertFalse(out['cas_atomic']);self.assertFalse(out['external_audit']);self.assertFalse(out['provider_independently_attested'])

class CompatTests(unittest.TestCase):
 def setUp(self):
  header=['Personagem','Rank/Lv','FOR','DES','CON','INT','SAB','CAR','Carry','Checksum']
  actor=[('Serah','L1 / 21'),('Darek','L3 / 23'),('Nym','L2 / 22'),('Urosh','L1 / 21'),('Sel-Myr','ON5 / 20'),('Kael','L3 / 23'),('Rhovan','L3 / 23'),('Asha','L1 / 21')]
  self.normal='<table>'+''.join('<tr>'+''.join(f'<td>{y}</td>' for y in x)+'</tr>' for x in [header]+[[a,r,'1','2','3','4','5','6','0','21'] for a,r in actor])+'</table>'
  self.combat='# Compatibilidade\nOs oito Espíritos escolhidos são `COMPATIBLE=YES` por construção temática e de afinidade. Portanto:\n- personagens Lendários: duração base da Transformação `1d12+2`, compatibilidade adiciona `+1` ao resultado → `1d12+3 turnos`;\n- Sel-Myr, Ouro Negro: `1d10+1` → compatível `1d10+2 turnos`;'
  self.args={'combat_text':self.combat,'combat_id':COMBAT[0],'combat_version':COMBAT[1],'normal_text':self.normal,'normal_id':NORMAL[0],'normal_version':NORMAL[1],'vz_text':sample_matrix(),'vz_id':VZ[0],'vz_version':VZ[1]}
 def test_eight_sandbox_contracts(self):
  r=reconcile(**self.args);self.assertEqual((r['numerator'],r['denominator']),(8,8));self.assertEqual({x['compatible'] for x in r['contracts']},{True})
 def test_darek_spirit_cap_not_actor_rank(self):
  x=reconcile(**self.args)['contracts'][1];self.assertEqual((x['actor_ordinal'],x['effective_spirit_ordinal'],x['T9_cost_PA']),(23,20,320))
 def test_sel_myr_ouro_negro(self):
  x=reconcile(**self.args)['contracts'][4];self.assertEqual((x['actor_rank'],x['duration'],x['T9_cost_PA']),('Ouro Negro','1d10+2',160))
 def test_other_seven_legendary(self):
  xs=reconcile(**self.args)['contracts'];self.assertEqual(sum(x['actor_rank']=='Lendário' for x in xs),7)
 def test_missing_explicit_evidence_hold(self):
  with self.assertRaises(SourceHold):reconcile(**(self.args|{'combat_text':self.combat.replace('COMPATIBLE=YES','COMPATIBLE=UNKNOWN')}))
 def test_source_version_stale_hold(self):
  with self.assertRaises(SourceHold):reconcile(**(self.args|{'normal_version':'2026-12-31'}))
 def test_action_wrong_hold(self):
  with self.assertRaises(SourceHold):reconcile(**(self.args|{'vz_text':sample_matrix().replace('Livre · 320 PA · 1d12+3','Completa · 320 PA · 1d12+3',1)}))
 def test_wrong_actor_level_hold(self):
  with self.assertRaises(SourceHold):reconcile(**(self.args|{'normal_text':self.normal.replace('L3 / 23','ON5 / 20',1)}))
 def test_never_canonic(self):
  self.assertTrue(all('NOT_CAMPAIGN' in x['scope'] for x in reconcile(**self.args)['contracts']))
 def test_table_actor_duplicate_hold(self):
  with self.assertRaises(SourceHold):reconcile(**(self.args|{'normal_text':self.normal.replace('<td>Darek</td>','<td>Serah</td>')}))

if __name__=='__main__':unittest.main(verbosity=2)
