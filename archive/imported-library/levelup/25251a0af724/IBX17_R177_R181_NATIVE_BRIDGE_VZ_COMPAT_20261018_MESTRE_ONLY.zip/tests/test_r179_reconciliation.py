import unittest,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'baseline'/'runtime'))
from r177_native_gateway import CanaryPlan,NativeSnapshot
from r179_native_reconciliation import reconcile_observed,ReconcileHold
from r173_sqlite_causal_ledger import Ledger,AUTH,LAB
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.p=str(Path(self.tmp.name)/'x.db')
  self.plan=CanaryPlan('IBX17-R177-TEST-1','DOC_CANARY','TARGET','@source','v0','BRIDGE_PHYSICAL: BEFORE','BRIDGE_PHYSICAL: AFTER')
  with Ledger(self.p) as l:
   l.create_intent(tx=self.plan.tx,stage=self.plan.stage,target=self.plan.target,parent=LAB,source_version='@source',before=self.plan.before(),after=self.plan.after(),pre_version='v0',authority=AUTH)
   l.add_observation(self.plan.tx,self.plan.stage,'READBACK_BEFORE',observed_state=self.plan.before(),page_version='v0')
 def tearDown(self):self.tmp.cleanup()
 def observed(self,state='AFTER'):return NativeSnapshot('TARGET',LAB,'v1','BRIDGE_PHYSICAL: '+state)
 def test_after_without_journal_hold(self):
  self.assertEqual(reconcile_observed(self.plan,self.p,self.observed())['decision'],'AFTER_WITHOUT_COMPLETE_PROOF_HOLD')
 def test_before_hold(self):
  self.assertEqual(reconcile_observed(self.plan,self.p,self.observed('BEFORE'))['decision'],'PHYSICAL_BEFORE_NO_AUTORETRY')
 def test_other_quarantine(self):
  self.assertEqual(reconcile_observed(self.plan,self.p,self.observed('UNKNOWN'))['decision'],'UNKNOWN_EFFECT_QUARANTINE')
 def test_no_wrong_parent(self):
  with self.assertRaises(Exception):reconcile_observed(self.plan,self.p,NativeSnapshot('TARGET','PARTY','v1','BRIDGE_PHYSICAL: AFTER'))
 def test_reopen_complete_self_only(self):
  with Ledger(self.p) as l:
   l.add_observation(self.plan.tx,self.plan.stage,'WRITE_DISPATCHED',page_version='v0')
   l.add_observation(self.plan.tx,self.plan.stage,'WRITE_RESPONSE_OBSERVED',original_response={'page_id':'TARGET'})
   l.add_observation(self.plan.tx,self.plan.stage,'READBACK_AFTER',observed_state=self.plan.after(),page_version='v1')
   l.add_observation(self.plan.tx,self.plan.stage,'JOURNAL_READBACK_CONFIRMED',page_version='v2')
  x=reconcile_observed(self.plan,self.p,self.observed());self.assertEqual(x['decision'],'DOCUMENTARY_TEST_APPLIED_JOURNAL_READBACK_SELF_REVIEW');self.assertFalse(x['independently_audited'])
if __name__=='__main__':unittest.main(verbosity=2)
