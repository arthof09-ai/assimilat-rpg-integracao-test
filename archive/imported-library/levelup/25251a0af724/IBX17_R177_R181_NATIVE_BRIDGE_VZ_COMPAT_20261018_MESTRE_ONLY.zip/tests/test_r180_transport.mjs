import assert from 'node:assert/strict';
import {makeConnectedNotionCanaryTransport,TransportHold} from '../runtime/r180_connected_notion_transport.mjs';
const id='3fdc2b324ede81a0954cda5efe2fccaa';
let content='BRIDGE_PHYSICAL: BEFORE',n=0,verbs=[];
const tools={mcp__Notion__fetch:async()=>({structuredContent:{text:`<parent-page url="https://app.notion.com/p/3fbc2b324ede804a95fafcb7b293c92c"></parent-page><content>${content}</content>`,page_last_edited_at:`V${n}`}}),mcp__Notion__notion_update_page:async a=>{
   verbs.push(a.command);if(a.command==='update_content'){let e=a.content_updates[0];content=content.replace(e.old_str,e.new_str)}else content+='\n'+a.content;n++;return{structuredContent:{page_id:id,mock:true}};
}};
const t=makeConnectedNotionCanaryTransport(tools);
assert.equal((await t.fetchPage()).parent_id,'3fbc2b324ede804a95fafcb7b293c92c');
await t.replaceUnique('BRIDGE_PHYSICAL: BEFORE','BRIDGE_PHYSICAL: AFTER');
assert.equal((await t.fetchPage()).content,'BRIDGE_PHYSICAL: AFTER');
let refused=0;
for(const f of [()=>t.replaceUnique('BRIDGE_PHYSICAL: BEFORE','BRIDGE_PHYSICAL: AFTER'),()=>t.replaceUnique('NORMAL_HP: 5','NORMAL_HP: 6'),()=>t.appendContent('R145_FAKE_CONFIRMATION: TRUSTED'),()=>makeConnectedNotionCanaryTransport(tools,{target_id:'PARTY'})]){
 try{await f()}catch(e){assert(e instanceof TransportHold);refused++}
}
assert.equal(refused,4);assert.equal(verbs.length,1);
console.log(JSON.stringify({mock_only:true,passes:6,real_tool_dispatches:0}));
