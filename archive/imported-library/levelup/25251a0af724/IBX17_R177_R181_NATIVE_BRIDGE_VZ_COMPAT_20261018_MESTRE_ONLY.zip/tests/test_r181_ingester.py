import unittest,tempfile,sys
from pathlib import Path
sys.path[:0]=[str(Path(__file__).parent),str(Path(__file__).resolve().parents[1]/'baseline'/'runtime')]
from r181_host_receipt_ingester import ingest_receipt,IngestHold
from r173_sqlite_causal_ledger import Ledger,LAB,AUTH
class Tests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.db=str(Path(self.t.name)/'e.sqlite')
  self.target='3fdc2b324ede81a0954cda5efe2fccaa'
  self.tx='IBX17-R177-INGEST-TEST'
  self.before={'target':self.target,'field':'BRIDGE_PHYSICAL: BEFORE'}
  self.after={'target':self.target,'field':'BRIDGE_PHYSICAL: AFTER'}
  with Ledger(self.db) as x:x.create_intent(tx=self.tx,stage='DOC_CANARY',target=self.target,parent=LAB,source_version='@source',before=self.before,after=self.after,pre_version='v0',authority=AUTH)
  self.receipt=dict(tx=self.tx,stage='DOC_CANARY',target=self.target,phase='READBACK_BEFORE',page_version='v0',observed_state=self.before,source_class='EXECUTOR_NATIVE_NOTION_TOOL_CAPTURE_SELF_REVIEW',auditor='SELF_REVIEW_ONLY')
 def tearDown(self):self.t.cleanup()
 def test_readback_import(self):
  x=ingest_receipt(self.db,self.receipt)
  self.assertFalse(x['native_attestation']);self.assertEqual(x['accepted_observation']['seq'],1)
 def test_target_mismatch(self):
  with self.assertRaises(IngestHold):ingest_receipt(self.db,self.receipt|{'target':'a'*32})
 def test_fake_independent_auditor(self):
  with self.assertRaises(IngestHold):ingest_receipt(self.db,self.receipt|{'auditor':'INDEPENDENTLY_VERIFIED'})
 def test_fake_host_attestation(self):
  with self.assertRaises(IngestHold):ingest_receipt(self.db,self.receipt|{'native_attestation':True})
 def test_wrong_page_id_reply(self):
  with self.assertRaises(IngestHold):ingest_receipt(self.db,self.receipt|{'phase':'WRITE_RESPONSE_OBSERVED','observed_state':None,'original_response':{'text':'{"page_id":"aabbccdd"}'}})
 def test_valid_reply_needs_ordered_persisted(self):
  ingest_receipt(self.db,self.receipt)
  ingest_receipt(self.db,self.receipt|{'phase':'WRITE_DISPATCHED','observed_state':None})
  x=ingest_receipt(self.db,self.receipt|{'phase':'WRITE_RESPONSE_OBSERVED','observed_state':None,'original_response':{'text':'{"page_id":"3fdc2b32-4ede-81a0-954c-da5efe2fccaa"}'}})
  self.assertEqual(x['accepted_observation']['seq'],3)
 def test_journal_requires_native_readback_marker(self):
  with self.assertRaises(IngestHold):ingest_receipt(self.db,self.receipt|{'phase':'JOURNAL_READBACK_CONFIRMED','readback_contains_native_journal':False})
 def test_reject_party_source(self):
  with self.assertRaises(IngestHold):ingest_receipt(self.db,self.receipt|{'source_class':'USER_FILLED_TRUSTED'})
if __name__=='__main__':unittest.main(verbosity=2)
