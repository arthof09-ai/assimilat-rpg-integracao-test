"""IBX-17 R177: host-injected native Notion connector bridge, laboratory only.

This is a transport boundary, NOT an independent Python Notion API credential.
The host must supply fetch_page and update_content using *the native connected
Notion tools*, with the original structured response. No bypass or automatic
retry is provided for security refusal. No atomic CAS on Notion is claimed.

Uses the existing R173 SQLite ledger. All proof is SELF_REVIEW_ONLY until
independently attested by competent host/auditor. Production always HOLD.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Any
import json
from r173_sqlite_causal_ledger import Ledger,LAB,AUTH,digest,LedgerHold

class NativeGateHold(ValueError): pass

@dataclass(frozen=True)
class NativeSnapshot:
    page_id: str
    parent_id: str
    page_version: str
    content: str

class NativeTransport(Protocol):
    def fetch_page(self, page_id:str) -> NativeSnapshot:...
    def append_content(self,page_id:str,content:str) -> Any:...
    def replace_unique(self,page_id:str,old:str,new:str) -> Any:...

@dataclass(frozen=True)
class CanaryPlan:
    tx:str
    stage:str
    target:str
    source_version:str
    pre_version:str
    old_literal:str
    new_literal:str
    authority:str=AUTH
    parent:str=LAB
    def validate(self):
        if not all((self.tx,self.stage,self.target,self.source_version,self.pre_version,self.old_literal,self.new_literal)):
            raise NativeGateHold('MISSING_FIELD')
        if self.parent!=LAB or self.authority!=AUTH:raise NativeGateHold('NOT_AUTHORIZED_LAB')
        if not self.tx.startswith('IBX17-R177-') or self.stage!='DOC_CANARY':
            raise NativeGateHold('BRIDGE_SCOPE_NOT_CANARY')
        if not (self.old_literal.startswith('BRIDGE_PHYSICAL: ') and self.new_literal.startswith('BRIDGE_PHYSICAL: ')):
            raise NativeGateHold('NON_CANARY_FIELD_FORBIDDEN')
        if self.old_literal==self.new_literal:raise NativeGateHold('NO_EFFECT')
        if any('\n' in v or '<' in v for v in (self.old_literal,self.new_literal)):
            raise NativeGateHold('BLOCK_ESCAPE_FORBIDDEN')
        return self
    def before(self):return {'target':self.target,'field':self.old_literal}
    def after(self):return {'target':self.target,'field':self.new_literal}

def _literal(snapshot:NativeSnapshot,needle:str) -> bool:
    return snapshot.content.count(needle)==1

def inspect(plan:CanaryPlan, snapshot:NativeSnapshot):
    plan.validate()
    if snapshot.page_id!=plan.target or snapshot.parent_id!=LAB:
        raise NativeGateHold('TARGET_OR_PARENT_HOLD')
    before=snapshot.content.count(plan.old_literal)
    after=snapshot.content.count(plan.new_literal)
    if before==1 and after==0:return 'BEFORE'
    if before==0 and after==1:return 'AFTER'
    return 'OTHER'

def _safe_observe(ledger:Ledger,plan:CanaryPlan,snap:NativeSnapshot):
    phase={'BEFORE':'READBACK_BEFORE','AFTER':'READBACK_AFTER','OTHER':'READBACK_OTHER'}[inspect(plan,snap)]
    observed=plan.before() if phase=='READBACK_BEFORE' else plan.after() if phase=='READBACK_AFTER' else {'target':plan.target,'sha_of_unknown_content':digest(snap.content)}
    ledger.add_observation(plan.tx,plan.stage,phase,page_version=snap.page_version,observed_state=observed)
    return phase

def execute_canary(plan:CanaryPlan,transport:NativeTransport,ledger_path:str):
    """One authorized native canary. Returns no permissions or production proof.

    If a tool call refuses or any state is ambiguous, do not retry; reopen and
    persist the original refusal (when available). A documentary intention is
    appended to the target before its sole field mutation.
    """
    plan.validate()
    first=transport.fetch_page(plan.target)
    if first.page_version!=plan.pre_version or inspect(plan,first)!='BEFORE':
        raise NativeGateHold('PRE_VERSION_OR_STATE_STALE')
    with Ledger(ledger_path) as ledger:
        already=ledger.create_intent(tx=plan.tx,stage=plan.stage,target=plan.target,parent=LAB,
            source_version=plan.source_version,before=plan.before(),after=plan.after(),
            pre_version=plan.pre_version,authority=AUTH)
        if already['status']!='INTENT_DURABLY_PERSISTED':
            return {'state':'IDENTICAL_INTENT_ALREADY_EXISTS_NO_REDISPATCH', 'native_calls':0}
        ledger.add_observation(plan.tx,plan.stage,'READBACK_BEFORE',page_version=first.page_version,observed_state=plan.before())
        documentary=(f'R177_INTENT_RECEIPT: tx={plan.tx}; stage={plan.stage}; '
          f'target={plan.target}; pre_version={plan.pre_version}; '
          f'before_sha={digest(plan.before())}; after_sha={digest(plan.after())}; '
          'review=SELF_REVIEW_ONLY; AUTHORITY=LAB_TEST; NATIVE_ID_UNAVAILABLE')
        # Only the connected Notion host may supply this native call; no network is
        # performed from Python and a mock does not constitute native evidence.
        try:
            intent_reply=transport.append_content(plan.target,documentary)
        except Exception as exc:
            after_error=transport.fetch_page(plan.target)
            _safe_observe(ledger,plan,after_error)
            return {'state':'INTENT_APPEND_REFUSED_OR_UNKNOWN', 'error':str(exc),'native_calls':'UNTRUSTED'}
        second=transport.fetch_page(plan.target)
        if inspect(plan,second)!='BEFORE' or documentary not in second.content:
            _safe_observe(ledger,plan,second)
            return {'state':'INTENT_READBACK_CONFLICT_HOLD','native_calls':1}
        # Intent response from the host should be persisted as an observation.
        ledger.add_observation(plan.tx,plan.stage,'WRITE_DISPATCHED',page_version=second.page_version,
            original_response={'documentary_intent_reply':intent_reply})
        # No atomic compare-and-swap exists; this fetch is observational preflight.
        third=transport.fetch_page(plan.target)
        if third.page_version!=second.page_version or inspect(plan,third)!='BEFORE':
            _safe_observe(ledger,plan,third)
            return {'state':'RACE_OR_STATE_HOLD','native_calls':1}
        try:
            native_reply=transport.replace_unique(plan.target,plan.old_literal,plan.new_literal)
        except Exception as exc:
            code=str(exc)
            is_security=('SECURITY' in code.upper() or 'SEGURAN' in code.upper())
            if is_security:
                ledger.add_observation(plan.tx,plan.stage,'SECURITY_REFUSED',error_code=code)
            else:
                ledger.add_observation(plan.tx,plan.stage,'WRITE_RESPONSE_OBSERVED',original_response={'tool_error':code,'not_commit_evidence':True})
            reopened=transport.fetch_page(plan.target)
            phase=_safe_observe(ledger,plan,reopened)
            return {'state':('SECURITY_REFUSAL_FENCED_' if is_security else 'TOOL_ERROR_CAUSE_UNDETERMINED_HOLD_')+phase,'cause':code,'auto_retry':False}
        ledger.add_observation(plan.tx,plan.stage,'WRITE_RESPONSE_OBSERVED',original_response=native_reply)
        after_effect=transport.fetch_page(plan.target)
        phase=_safe_observe(ledger,plan,after_effect)
        if phase!='READBACK_AFTER':
            return {'state':'EFFECT_NOT_CERTIFIABLE_'+phase,'native_calls':2}
        journal=f'R177_JOURNAL_RECEIPT: tx={plan.tx}; stage={plan.stage}; AFTER_SHA={digest(plan.after())}; stage=AFTER_READBACK_CONFIRMED; SELF_REVIEW_ONLY'
        try:
            journal_reply=transport.append_content(plan.target,journal)
        except Exception as exc:
            return {'state':'AFTER_WITHOUT_NATIVE_JOURNAL_HOLD','error':str(exc),'auto_retry':False}
        final=transport.fetch_page(plan.target)
        if journal not in final.content or inspect(plan,final)!='AFTER':
            return {'state':'JOURNAL_READBACK_INCONCLUSIVE_HOLD','auto_retry':False}
        ledger.add_observation(plan.tx,plan.stage,'JOURNAL_READBACK_CONFIRMED',page_version=final.page_version,
            original_response=journal_reply)
        result=ledger.classify(plan.tx,plan.stage)
        return {'state':result['state'], 'transport_reply_observed':True,'provider_independently_attested':False,
            'external_audit':False,'cas_atomic':False,'phase':phase,'journal_version':final.page_version}
