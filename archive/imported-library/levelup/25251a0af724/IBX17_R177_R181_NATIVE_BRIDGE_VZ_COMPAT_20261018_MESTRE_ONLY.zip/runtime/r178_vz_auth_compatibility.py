"""R178 source-bound compatibility resolution for eight VZ SANDBOX actors.

Evidence comes from three specific live Notion pages (versions pinned).
The textual source records explicitly say COMPATIBLE=YES for all 8 and the
NORMAL-STATS table records *actor* ranks, not Spirit effective levels.
The evidence is observed by this executor, not a host cryptographic signature,
and must never be promoted to real-party assimilation.
"""
from __future__ import annotations
import re,json
from r165_notional_table_source_parser import parse_table,parse_transform_matrix
from r175_spirit_activation_source_precedence import parse_literal
from r149_150_spirit_runtime import tier

COMBAT=('3f2c2b324ede8144bcc5cc73d9dd3167','2026-10-07T23:51:19.654Z')
NORMAL=('3f2c2b324ede8168b50ee4254134d821','2026-10-07T21:52:35.997Z')
VZ=('3f2c2b324ede816198a5f0fb525223ee','2026-10-07T21:37:03.824Z')
ACTORS=('Serah','Darek','Nym','Urosh','Sel-Myr','Kael','Rhovan','Asha')
class SourceHold(ValueError):pass

def reconcile(*,combat_text,combat_id,combat_version,normal_text,normal_id,normal_version,
              vz_text,vz_id,vz_version):
    if (combat_id,combat_version)!=COMBAT or (normal_id,normal_version)!=NORMAL or (vz_id,vz_version)!=VZ:
        raise SourceHold('SOURCE_ID_OR_VERSION_CHANGED')
    if not re.search(r'Os oito Espíritos escolhidos são `COMPATIBLE=YES`',combat_text):
        raise SourceHold('COMPATIBILITY_COHORT_EVIDENCE_ABSENT')
    if not re.search(r'personagens Lendários.*?`1d12\+2`.*?`\+1`',combat_text):
        raise SourceHold('LEGENDARY_COMPATIBILITY_RULE_MISSING')
    if not re.search(r'Sel-Myr, Ouro Negro.*?`1d10\+1`.*?`1d10\+2(?:\s+turnos)?`',combat_text):
        raise SourceHold('ON_COMPATIBILITY_RULE_MISSING')
    tables=parse_table(normal_text)
    found=[t for t in tables if len(t)>1 and t[0][:2]==['Personagem','Rank/Lv']]
    if len(found)!=1:raise SourceHold('ACTOR_RANK_TABLE_AMBIGUOUS')
    if len(found[0])!=9:raise SourceHold('ACTOR_DENOMINATOR_MISMATCH')
    actors={}
    for row in found[0][1:]:
        if len(row)<2 or row[0] in actors:raise SourceHold('ACTOR_DUPLICATE_OR_MALFORMED')
        m=re.fullmatch(r'((?:L|ON)\d+) / (\d+)',row[1])
        if not m:raise SourceHold('ACTOR_RANK_NOT_DECLARED')
        category='Lendário' if m.group(1).startswith('L') else 'Ouro Negro'
        ordinal=int(m.group(2))
        if tier(ordinal)['category']!=category:raise SourceHold('ACTOR_RANK_INCONSISTENT')
        actors[row[0]]={'rank':m.group(1),'ordinal':ordinal}
    if set(actors)!=set(ACTORS):raise SourceHold('ACTOR_SET_MISMATCH')
    overlays=parse_transform_matrix(vz_text,source_page_id=vz_id,source_version=vz_version)
    if {x['actor'] for x in overlays}!=set(ACTORS):raise SourceHold('OVERLAY_ACTOR_SET_MISMATCH')
    result=[]
    for o in overlays:
        actor=o['actor'];rank=actors[actor];spec=tier(rank['ordinal']);lit=parse_literal(o['activation_literal'])
        expected={'action':spec['action'],'cost':spec['cost'],'duration_die':spec['die'],'duration_offset':spec['offset']+1}
        if lit!=expected:raise SourceHold('ACTIVATION_DISAGREES_WITH_NORM_'+actor)
        if not o['effective_ordinal']<=rank['ordinal']:raise SourceHold('SPIRIT_EFFECTIVE_ABOVE_ACTOR_'+actor)
        result.append({'actor':actor,'spirit':o['spirit'],'actor_ordinal':rank['ordinal'],
         'actor_rank':spec['category'],'effective_spirit_ordinal':o['effective_ordinal'],
         'T9_action':lit['action'],'T9_cost_PA':lit['cost'],'duration':f"1d{lit['duration_die']}+{lit['duration_offset']}",
         'compatible':True,'compatibility_basis':'EXPLICIT_COHORT_VZ_AND_ACTOR_NORMAL_STATED',
         'scope':'VZ_SANDBOX_SOURCE_RECONCILED_NOT_CAMPAIGN_ASSIMILATION'})
    return {'contracts':result,'numerator':len(result),'denominator':8,'scope':'VZ_SANDBOX_ONLY',
         'source_versions':{'combat':combat_version,'normal':normal_version,'vz':vz_version},
         'native_writes':0,'independent_audit':False}
