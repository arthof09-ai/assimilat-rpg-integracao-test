"""R181: import explicitly structured connected-Notion tool observations into R173.

No API calls or host-attestation signatures are created. Inputs are untrusted
and checked against a previously persisted LAB intent. A successful import is
still SELF_REVIEW_ONLY, never production or cryptographic origin proof.
"""
from __future__ import annotations
import json,re
from r173_sqlite_causal_ledger import Ledger,LAB,LedgerHold

class IngestHold(ValueError):pass
PHASES={'READBACK_BEFORE','WRITE_DISPATCHED','WRITE_RESPONSE_OBSERVED',
        'READBACK_AFTER','READBACK_OTHER','JOURNAL_READBACK_CONFIRMED','SECURITY_REFUSED'}

def ingest_receipt(ledger_path,receipt):
 if not isinstance(receipt,dict):raise IngestHold('RECEIPT_NOT_OBJECT')
 if receipt.get('auditor') not in ('SELF_REVIEW_ONLY',None):raise IngestHold('FORGED_INDEPENDENT_REVIEW')
 tx,stage,target,phase=(receipt.get(k) for k in ('tx','stage','target','phase'))
 if not all(isinstance(x,str) and x for x in (tx,stage,target,phase)) or phase not in PHASES:raise IngestHold('INVALID_EVENT_FIELDS')
 if not tx.startswith('IBX17-R177-') or stage!='DOC_CANARY':raise IngestHold('NOT_CANARY')
 if not re.fullmatch(r'[a-f0-9]{32}',target):raise IngestHold('TARGET_ID_FORMAT')
 if receipt.get('native_attestation') is True:raise IngestHold('UNAVAILABLE_HOST_ATTESTATION_CLAIM')
 if receipt.get('source_class')!='EXECUTOR_NATIVE_NOTION_TOOL_CAPTURE_SELF_REVIEW':raise IngestHold('UNKNOWN_SOURCE_CLASS')
 if phase=='WRITE_RESPONSE_OBSERVED':
  r=receipt.get('original_response')
  if not isinstance(r,dict) or not isinstance(r.get('text'),str):raise IngestHold('ORIGINAL_NATIVE_RESPONSE_MISSING')
  try: result=json.loads(r['text']);page_id=result.get('page_id','').replace('-','')
  except (ValueError,AttributeError):raise IngestHold('NATIVE_RESPONSE_NOT_JSON_PAGE_ID')
  if page_id!=target:raise IngestHold('NATIVE_REPLY_WRONG_TARGET')
 with Ledger(ledger_path) as ledger:
  record=ledger.db.execute('SELECT target,parent FROM intent WHERE tx=? AND stage=?',(tx,stage)).fetchone()
  if not record or record!=(target,LAB):raise IngestHold('INTENT_TARGET_SCOPE_MISMATCH')
  observed=None
  if phase.startswith('READBACK_'):
   observed=receipt.get('observed_state')
   if not isinstance(observed,dict) or observed.get('target')!=target:raise IngestHold('READBACK_SCOPE_MISMATCH')
  if phase=='JOURNAL_READBACK_CONFIRMED' and not receipt.get('readback_contains_native_journal'):
   raise IngestHold('JOURNAL_MARKER_NOT_OBSERVED')
  observation=ledger.add_observation(tx,stage,phase,page_version=receipt.get('page_version'),
   observed_state=observed,original_response=receipt.get('original_response'),
   error_code=receipt.get('error_code'),source_class='SELF_REVIEW_ONLY')
  return {'accepted_observation':observation,'ledger_classification':ledger.classify(tx,stage),
   'native_attestation':False,'replay_allowed':False}
