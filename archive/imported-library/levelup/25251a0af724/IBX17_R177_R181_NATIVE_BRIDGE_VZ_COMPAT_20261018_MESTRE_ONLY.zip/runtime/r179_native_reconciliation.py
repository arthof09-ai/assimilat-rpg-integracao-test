"""R179: independently reopen local ledger and classify observed Notion canary.

The readback dict must be reconstructed from *fresh native connector fetch* by
an authorized host; a forged dict is only a self-reported observation.
The helper does not grant writer authority, attest a host, or use CAS.
"""
from __future__ import annotations
from dataclasses import dataclass
from r173_sqlite_causal_ledger import Ledger,LedgerHold
from r177_native_gateway import CanaryPlan,NativeSnapshot,inspect

class ReconcileHold(ValueError):pass

def reconcile_observed(plan:CanaryPlan,ledger_path:str,observed:NativeSnapshot):
    phase=inspect(plan,observed)
    with Ledger(ledger_path) as l:
        chain=l.verify_chain(plan.tx,plan.stage)
        state=l.classify(plan.tx,plan.stage)
        if phase=='OTHER':return {'decision':'UNKNOWN_EFFECT_QUARANTINE','review':'SELF_REVIEW_ONLY','auto_retry':False}
        if phase=='BEFORE':return {'decision':'PHYSICAL_BEFORE_NO_AUTORETRY','review':'SELF_REVIEW_ONLY','auto_retry':False}
        if state['state']=='READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION':
            return {'decision':'DOCUMENTARY_TEST_APPLIED_JOURNAL_READBACK_SELF_REVIEW',
                    'ledger_chain_sha':chain['chain_head'],'obs':chain['observations'],
                    'readback_version':observed.page_version,'native_write_authority':False,
                    'independently_audited':False,'production':False,'auto_retry':False}
        return {'decision':'AFTER_WITHOUT_COMPLETE_PROOF_HOLD','ledger_state':state['state'],
                'auto_retry':False,'review':'SELF_REVIEW_ONLY'}
