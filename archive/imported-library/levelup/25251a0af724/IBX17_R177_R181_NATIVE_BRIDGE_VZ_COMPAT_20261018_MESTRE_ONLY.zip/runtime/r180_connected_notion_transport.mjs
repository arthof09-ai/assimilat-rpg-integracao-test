/** IBX-17 R180: transport adapter reference for trusted Code Mode `tools`.
 * No credential, browser, network, CAS, party writer, or autonomous prod lease.
 * Host runtime must supply actual mcp__Notion__ actions; tests are mocks.
 * Strictly limited to documentary canary TX in the original TEST lab.
 */
const LAB='3fbc2b324ede804a95fafcb7b293c92c';
const LINK='link_6abff0dd49dc8191a257bd59517b63a0';
const CANARY='3fdc2b324ede81a0954cda5efe2fccaa';
export class TransportHold extends Error {}
function unpackNativeResult(result){
  const p=result?.structuredContent;
  if(!p || typeof p.text!=='string'||typeof p.page_last_edited_at!=='string')throw new TransportHold('NOTION_FETCH_SHAPE_UNKNOWN');
  const match=p.text.match(/<parent-page url="https:\/\/app\.notion\.com\/p\/([a-f0-9]{32})"/);
  const body=p.text.match(/<content>([\s\S]*?)<\/content>/);
  if(!match||!body)throw new TransportHold('NOTION_PARENT_OR_CONTENT_MISSING');
  return {page_id:CANARY,parent_id:match[1],page_version:p.page_last_edited_at,content:body[1]};
}
export function makeConnectedNotionCanaryTransport(tools,{link_id=LINK,target_id=CANARY}={}){
 if(link_id!==LINK||target_id!==CANARY)throw new TransportHold('TEST_CANARY_TARGET_OR_ACCOUNT_NOT_ALLOWED');
 if(!tools?.mcp__Notion__fetch||!tools?.mcp__Notion__notion_update_page)throw new TransportHold('NATIVE_CONNECTOR_MISSING');
 async function snapshot(){
   const p=unpackNativeResult(await tools.mcp__Notion__fetch({id:target_id,link_id}));
   if(p.parent_id!==LAB)throw new TransportHold('OUTSIDE_TEST_LAB');
   return p;
 }
 return {
   async fetchPage(){return snapshot();},
   async appendContent(content){
     if(!/^R177_(?:INTENT|JOURNAL)_RECEIPT: /.test(content))throw new TransportHold('NON_DOCUMENTARY_APPEND_DENIED');
     await snapshot();
     return tools.mcp__Notion__notion_update_page({page_id:target_id,command:'insert_content',position:{type:'end'},content,allow_async:false,link_id});
   },
   async replaceUnique(old_str,new_str){
     if(old_str!=='BRIDGE_PHYSICAL: BEFORE'||new_str!=='BRIDGE_PHYSICAL: AFTER')throw new TransportHold('MECHANICAL_FIELDS_DENIED');
     const p=await snapshot();
     if(p.content.split(old_str).length!==2||p.content.includes(new_str))throw new TransportHold('STALE_OR_AMBIGUOUS_CANARY');
     return tools.mcp__Notion__notion_update_page({page_id:target_id,command:'update_content',content_updates:[{old_str,new_str}],allow_async:false,link_id});
   }
 }
}
