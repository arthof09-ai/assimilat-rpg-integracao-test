import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
import r175_spirit_activation_source_precedence as m
class TestPrecedence(unittest.TestCase):
 def setUp(self):self.rows=m.source_fixture()
 def test_six_legendary_rows_require_compatibility_evidence(self):
  report=m.reconcile_rows(self.rows)
  self.assertEqual(sum(x['decision']=='HOLD_COMPATIBILITY_NOT_ACTOR_ATTESTED' for x in report),6)
  self.assertEqual(sum(x['decision']=='HOLD_ACTOR_RANK_NOT_DEDUCIBLE_FROM_SPIRIT_EFFECTIVE_LEVEL' for x in report),2)
 def test_actor_cap_not_actor_rank(self):
  r=self.rows[1]
  self.assertEqual(r['effective_ordinal'],20)
  x=m.evaluate(r)
  self.assertEqual(x['decision'],'HOLD_ACTOR_RANK_NOT_DEDUCIBLE_FROM_SPIRIT_EFFECTIVE_LEVEL')
 def test_darek_with_test_actor_level21_has_conditional_plus1(self):
  r=self.rows[1]
  x=m.evaluate(r,actor_level=21,actor_evidence={'scope':'UNIT_TEST_ONLY','actor':r['actor']})
  self.assertEqual(x['decision'],'HOLD_COMPATIBILITY_NOT_ACTOR_ATTESTED')
  self.assertEqual(x['actor_rank'],'Lendário')
 def test_sel_myr_test_actor_level20_is_conditional_compatibility(self):
  r=self.rows[4]
  x=m.evaluate(r,actor_level=20,actor_evidence={'scope':'UNIT_TEST_ONLY','actor':r['actor']})
  self.assertEqual(x['decision'],'HOLD_COMPATIBILITY_NOT_ACTOR_ATTESTED')
  self.assertEqual(x['actor_rank'],'Ouro Negro')
 def test_sel_myr_test_actor_level21_action_cost_conflict(self):
  r=self.rows[4]
  x=m.evaluate(r,actor_level=21,actor_evidence={'scope':'UNIT_TEST_ONLY','actor':r['actor']})
  self.assertEqual(x['decision'],'HOLD_ACTION_COST_OR_DIE_CONFLICT')
 def test_forged_source_and_wrong_actor_rejected(self):
  r=self.rows[0]
  for ev in [{'scope':'CANONICAL','actor':r['actor']},{'scope':'UNIT_TEST_ONLY','actor':'OTHER'},None]:
   with self.assertRaises(m.PrecedenceHold):m.evaluate(r,actor_level=22,actor_evidence=ev)
 def test_min_rule_actor_level_below_effective_rejected(self):
  r=self.rows[0]
  with self.assertRaises(m.PrecedenceHold):m.evaluate(r,actor_level=20,actor_evidence={'scope':'UNIT_TEST_ONLY','actor':r['actor']})
 def test_reject_unknown_action_and_scope(self):
  with self.assertRaises(m.PrecedenceHold):m.parse_literal('Ação inventada · 40 PA · 1d6+1')
  with self.assertRaises(m.PrecedenceHold):m.parse_literal('não era duração')
if __name__=='__main__':unittest.main(verbosity=2)
