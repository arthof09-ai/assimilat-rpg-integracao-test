import unittest,tempfile,sys,subprocess,json,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
from r173_sqlite_causal_ledger import Ledger,LedgerHold,LAB,AUTH

class DurableLedgerTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.path=str(Path(self.t.name)/'lab.sqlite');self.l=Ledger(self.path)
  self.data=dict(tx='TEST-TX',stage='NORMAL',target='TARGET',parent=LAB,source_version='RULE@1',before={'level':17},after={'level':18},pre_version='PRE@1',authority=AUTH)
 def tearDown(self):self.l.close();self.t.cleanup()
 def test_durable_identity_reopen(self):
  self.assertEqual(self.l.create_intent(**self.data)['status'],'INTENT_DURABLY_PERSISTED');self.l.close();self.l=Ledger(self.path)
  self.assertEqual(self.l.create_intent(**self.data)['status'],'EXISTING_IDENTICAL_INTENT_READONLY')
 def test_conflicting_same_event_stage_denied(self):
  self.l.create_intent(**self.data)
  with self.assertRaises(LedgerHold):self.l.create_intent(**(self.data|{'after':{'level':99}}))
 def test_crash_after_effect_before_journal_remains_hold(self):
  self.l.create_intent(**self.data)
  self.l.add_observation('TEST-TX','NORMAL','WRITE_DISPATCHED',page_version='PRE@1')
  self.l.add_observation('TEST-TX','NORMAL','WRITE_RESPONSE_OBSERVED',page_version='AFTER@1',original_response={'page_id':'TEST-LOCAL-MOCK'})
  self.l.add_observation('TEST-TX','NORMAL','READBACK_AFTER',page_version='AFTER@1',observed_state={'level':18})
  self.l.close();self.l=Ledger(self.path)
  self.assertEqual(self.l.classify('TEST-TX','NORMAL')['state'],'AFTER_WITHOUT_JOURNAL_CAUSAL_HOLD')
  self.l.add_observation('TEST-TX','NORMAL','JOURNAL_READBACK_CONFIRMED',page_version='AFTER@2')
  self.assertEqual(self.l.classify('TEST-TX','NORMAL')['state'],'READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION')
 def test_secure_before_refusal_and_no_dispatch_replay(self):
  self.l.create_intent(**self.data)
  self.l.add_observation('TEST-TX','NORMAL','WRITE_DISPATCHED')
  self.l.add_observation('TEST-TX','NORMAL','SECURITY_REFUSED',error_code='Security blocked')
  self.l.add_observation('TEST-TX','NORMAL','READBACK_BEFORE',observed_state={'level':17},page_version='AFTER@READ')
  self.assertEqual(self.l.classify('TEST-TX','NORMAL')['state'],'SECURITY_FENCED_BEFORE')
  with self.assertRaises(LedgerHold):self.l.add_observation('TEST-TX','NORMAL','WRITE_DISPATCHED')
 def test_wrong_state_never_accepted_as_before_or_after(self):
  self.l.create_intent(**self.data)
  with self.assertRaises(LedgerHold):self.l.add_observation('TEST-TX','NORMAL','READBACK_AFTER',observed_state={'level':19})
  with self.assertRaises(LedgerHold):self.l.add_observation('TEST-TX','NORMAL','READBACK_BEFORE',observed_state={'level':19})
  self.l.add_observation('TEST-TX','NORMAL','READBACK_OTHER',observed_state={'level':19})
  self.assertEqual(self.l.classify('TEST-TX','NORMAL')['state'],'UNKNOWN_EFFECT_QUARANTINE')
 def test_forged_independent_label_rejected(self):
  self.l.create_intent(**self.data)
  with self.assertRaises(LedgerHold):self.l.add_observation('TEST-TX','NORMAL','READBACK_BEFORE',observed_state={'level':17},source_class='INDEPENDENTLY_VERIFIED')
 def test_journal_before_reply_or_after_blocked(self):
  self.l.create_intent(**self.data)
  with self.assertRaises(LedgerHold):self.l.add_observation('TEST-TX','NORMAL','JOURNAL_READBACK_CONFIRMED',page_version='V')
  self.l.add_observation('TEST-TX','NORMAL','READBACK_AFTER',observed_state={'level':18},page_version='V')
  with self.assertRaises(LedgerHold):self.l.add_observation('TEST-TX','NORMAL','JOURNAL_READBACK_CONFIRMED',page_version='V')
 def test_tampered_history_rejected(self):
  self.l.create_intent(**self.data)
  self.l.add_observation('TEST-TX','NORMAL','WRITE_DISPATCHED')
  self.assertEqual(self.l.verify_chain('TEST-TX','NORMAL')['status'],'LOCAL_HASH_CHAIN_VALID')
  with self.l.db:self.l.db.execute("UPDATE observation SET phase='JOURNAL_READBACK_CONFIRMED' WHERE tx='TEST-TX' AND stage='NORMAL'")
  with self.assertRaises(LedgerHold):self.l.classify('TEST-TX','NORMAL')
 def test_out_of_scope_local_intent_denied(self):
  with self.assertRaises(LedgerHold):self.l.create_intent(**(self.data|{'parent':'PARTY'}))
  with self.assertRaises(LedgerHold):self.l.create_intent(**(self.data|{'authority':'FAKE_WRITER'}))
 def test_actual_process_restart_reads_intent(self):
  self.l.create_intent(**self.data)
  script=f"import sys;sys.path.insert(0,{str(Path(__file__).resolve().parents[1]/'runtime')!r});from r173_sqlite_causal_ledger import Ledger;L=Ledger({self.path!r});print(L.classify('TEST-TX','NORMAL')['state']);L.close()"
  child=subprocess.check_output([sys.executable,'-c',script],text=True).strip()
  self.assertEqual(child,'NO_READBACK_CAUSAL_UNCERTAINTY')
if __name__=='__main__':unittest.main(verbosity=2)
