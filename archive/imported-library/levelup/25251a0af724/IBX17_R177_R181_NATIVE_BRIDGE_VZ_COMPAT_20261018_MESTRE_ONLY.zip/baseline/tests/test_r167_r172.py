import unittest,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
from r149_150_spirit_runtime import make_state,Hold
import r167_event_intent_identity as identity
import r168_compatibility_provenance_gate as comp
import r169_native_recovery_verifier as rec
import r170_normative_table_reconciler as norm
import r171_spirit_state_integrity as integ
import r172_conversational_readonly_dispatch as chat

class EventIntentTests(unittest.TestCase):
    def setUp(self):
        self.s=make_state(ordinal=11,normal_pa=220,normal_pa_max=260,committed=40)
        self.kw={'scene':'ONE','die_result':3,'action':'PADRAO','source_proof':'SYNTHETIC_TEST_ONLY','scene_proof':'SYNTHETIC_TEST_ONLY'}
    def test_new_receipt_and_identical_replay(self):
        s,ok=identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw)
        self.assertEqual(s['normal_pa'],140)
        self.assertEqual(s['spirit_temp_hp'],24)
        self.assertEqual(ok,'TEST_ACTIVATION_APPLIED')
        s2,status=identity.apply(s,event='ACT1',operation='ACTIVATE',params=self.kw)
        self.assertEqual(status,'NOOP_IDENTITY_VERIFIED')
        self.assertEqual(s2,s)
    def test_reused_event_changed_scene_holds(self):
        s,_=identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw)
        with self.assertRaisesRegex(Hold,'EVENT_ID_COLLISION'):
            identity.apply(s,event='ACT1',operation='ACTIVATE',params=self.kw|{'scene':'TWO'})
    def test_reused_event_changed_roll_holds(self):
        s,_=identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw)
        with self.assertRaisesRegex(Hold,'EVENT_ID_COLLISION'):
            identity.apply(s,event='ACT1',operation='ACTIVATE',params=self.kw|{'die_result':8})
    def test_reused_event_changed_operation_holds(self):
        s,_=identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw)
        with self.assertRaisesRegex(Hold,'EVENT_ID_COLLISION'):
            identity.apply(s,event='ACT1',operation='DAMAGE',params={'amount':10})
    def test_old_unbound_consumed_event_does_not_claim_noop(self):
        from r149_150_spirit_runtime import activate
        s,_=activate(self.s,event='ACT1',**self.kw)
        with self.assertRaisesRegex(Hold,'LEGACY_EVENT_NO_INTENT_BINDING'):
            identity.apply(s,event='ACT1',operation='ACTIVATE',params=self.kw)
    def test_source_version_and_actor_identity_hold(self):
        for extra in ({'source_version':'OLD'},{'expected_actor':'OTHER'}):
            with self.assertRaises(Hold):identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw,**extra)
    def test_state_advanced_is_readonly_not_identical_snapshot(self):
        a,_=identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw)
        b,_=identity.apply(a,event='T1',operation='TURN',params={'scene':'ONE'})
        _,decision=identity.apply(b,event='ACT1',operation='ACTIVATE',params=self.kw)
        self.assertEqual(decision,'REPLAY_IDENTITY_VERIFIED_READONLY_STATE_ADVANCED')
    def test_different_payload_with_legacy_event_binding_prohibits_collisions(self):
        a,_=identity.apply(self.s,event='ACT1',operation='ACTIVATE',params=self.kw)
        a['event_bindings']['ACT1']['request']['params']['scene']='TAMPER'
        with self.assertRaises(Hold):identity.apply(a,event='ACT1',operation='ACTIVATE',params=self.kw)

class CompatibilityTests(unittest.TestCase):
    def test_no_bonus_without_pair_source(self):
        self.assertEqual(comp.calculate(actor_ordinal=11,rolled=3,actor_id='A',spirit_id='S')['total'],4)
    def test_synthetic_bonus_test_only(self):
        e=comp.Evidence('UNIT_TEST_SYNTHETIC','A','S')
        r=comp.calculate(actor_ordinal=11,rolled=3,actor_id='A',spirit_id='S',evidence=e)
        self.assertEqual(r['total'],5);self.assertFalse(r['write_allowed'])
    def test_caller_boolean_does_not_prove_specialist_compatibility(self):
        e=comp.Evidence('SPECIALIST_T9_CONFIRMED','A','S',comp.RULE_PAGE,comp.RULE_VERSION,True)
        with self.assertRaisesRegex(Hold,'ATTESTATION_UNAVAILABLE'):
            comp.calculate(actor_ordinal=11,rolled=3,actor_id='A',spirit_id='S',evidence=e)
    def test_caller_attestation_string_not_authoritative(self):
        e=comp.Evidence('SPECIALIST_T9_CONFIRMED','A','S',comp.RULE_PAGE,comp.RULE_VERSION,True,'INDEPENDENTLY_VERIFIED')
        with self.assertRaises(Hold):comp.calculate(actor_ordinal=11,rolled=3,actor_id='A',spirit_id='S',evidence=e)
    def test_wrong_pair_and_bronze_holds(self):
        e=comp.Evidence('UNIT_TEST_SYNTHETIC','OTHER','S')
        with self.assertRaises(Hold):comp.calculate(actor_ordinal=11,rolled=3,actor_id='A',spirit_id='S',evidence=e)
        with self.assertRaises(Hold):comp.calculate(actor_ordinal=5,rolled=3,actor_id='A',spirit_id='S')

class PhysicalRecoveryTests(unittest.TestCase):
    def mk(self,**kw):
        d=dict(tx='T',stage='A',target='TARGET',parent=rec.LAB,source_version='RULE@V',
           pre_version='PRE@V',readback_version='AFTER@V',before={'x':0},after={'x':1},
           observed={'x':1},journal='COMMITTED',terminal='PREPARED',security_refusal=True)
        d.update(kw);return rec.Envelope(**d).classify()
    def test_r155_after_journal_terminal_refused(self):
        self.assertEqual(self.mk()['classification'],'MARKER_STALE_SECURITY_FENCED')
    def test_r158_before_dispatch_refused(self):
        self.assertEqual(self.mk(observed={'x':0},journal='WRITE_DISPATCHED')['classification'],'BEFORE_SECURITY_FENCED')
    def test_no_version_advance_unverified_even_with_after(self):
        self.assertEqual(self.mk(readback_version='PRE@V')['classification'],'VERSION_NOT_ADVANCED_UNCERTAIN')
    def test_other_and_journal_ahead(self):
        self.assertEqual(self.mk(observed={'x':8})['classification'],'UNKNOWN_EFFECT_OTHER')
        self.assertEqual(self.mk(observed={'x':0})['classification'],'JOURNAL_AHEAD_OF_PHYSICAL')
    def test_full_match_and_no_journal(self):
        self.assertEqual(self.mk(terminal='COMMITTED',security_refusal=False)['classification'],'STAGE_CONSISTENT_READ_ONLY')
        self.assertEqual(self.mk(journal='PREPARED')['classification'],'AFTER_JOURNAL_GAP_REQUIRE_NATIVE_CAUSAL_REF')
    def test_foreign_parent_and_reviewer(self):
        self.assertEqual(self.mk(parent='PARTY')['classification'],'AUTHORITY_OR_REVIEW_SCOPE_HOLD')
        self.assertEqual(self.mk(reviewer='INDEPENDENTLY_VERIFIED')['classification'],'AUTHORITY_OR_REVIEW_SCOPE_HOLD')

class SourceTableTests(unittest.TestCase):
    def test_specialist_t9_parses(self):
        p=norm.from_notion(norm.t9_fixture(),source_page_id=norm.T9_ID,version=norm.T9_VERSION,kind='T9')
        self.assertEqual(p['ranks']['Ouro']['cost'],80)
        self.assertEqual(p['ranks']['Lendário']['duration_die'],12)
    def test_rule5_parses(self):
        p=norm.from_notion(norm.rule5_fixture(),source_page_id=norm.R5_ID,version=norm.R5_VERSION,kind='R5')
        self.assertEqual(p['ranks']['Prata']['hp_dice'],8)
        self.assertEqual(p['ranks']['Ouro Negro']['pa_dice'],12)
    def test_duplicate_table_is_blocked(self):
        with self.assertRaises(norm.NormativeHold):norm.from_notion(norm.t9_fixture()*2,source_page_id=norm.T9_ID,version=norm.T9_VERSION,kind='T9')
    def test_mutated_cost_and_pseudorank_rejected(self):
        for x in [norm.t9_fixture().replace('80 PA','81 PA'),norm.t9_fixture().replace('Ouro Negro','Ouro Negro X')]:
            with self.assertRaises(norm.NormativeHold):norm.from_notion(x,source_page_id=norm.T9_ID,version=norm.T9_VERSION,kind='T9')
    def test_stale_source_blocked(self):
        with self.assertRaises(norm.NormativeHold):norm.from_notion(norm.t9_fixture(),source_page_id=norm.T9_ID,version='OLD',kind='T9')

class StateIntegrityTests(unittest.TestCase):
    def setUp(self):self.s=make_state(normal_pa=220,normal_pa_max=260,committed=40)
    def test_good_pre_state(self):self.assertEqual(integ.audit(self.s)['status'],'LOCAL_STATE_INVARIANTS_PASS')
    def test_bad_reserve_over_max(self):
        b=copy.deepcopy(self.s);b['spirit_pa']=b['spirit_pa_max']+1;b['form_active']=True;b['duration_left']=2;b['active_scene']='S';b['used_scenes']=['S'];b['last_activation_ordinal']=1
        with self.assertRaises(Hold):integ.audit(b)
    def test_duplicate_scene_and_event_ids(self):
        b=copy.deepcopy(self.s);b['used_scenes']=['A','A'];b['last_activation_ordinal']=2
        with self.assertRaises(Hold):integ.audit(b)
        b=copy.deepcopy(self.s);b['consumed_events']=['A','A'];b['history']=[{'event':'A'},{'event':'A'}]
        with self.assertRaises(Hold):integ.audit(b)
    def test_active_zero_duration_rejected(self):
        b=copy.deepcopy(self.s);b['form_active']=True;b['active_scene']='A';b['used_scenes']=['A'];b['last_activation_ordinal']=1
        with self.assertRaises(Hold):integ.audit(b)
    def test_history_order_mismatch(self):
        b=copy.deepcopy(self.s);b['consumed_events']=['E'];b['history']=[{'event':'OTHER'}]
        with self.assertRaises(Hold):integ.audit(b)

class ConversationDispatcherTests(unittest.TestCase):
    def setUp(self):self.c=chat.FixtureContext('T',chat.TEST_LAB,'v1','r1')
    def test_status_bound_to_target_and_version(self):
        self.assertEqual(chat.query('status',self.c,readback={'target_id':'T','version':'v1'})['state'],'READ_ONLY_STATUS')
        self.assertEqual(chat.query('status',self.c,readback={'target_id':'T','version':'v2'})['state'],'HOLD_READBACK_CONTEXT_MISMATCH')
    def test_preview_is_not_confirmation(self):
        p=chat.query('level up',self.c,requested_event='E')
        self.assertEqual(p['state'],'AWAITING_CHOICE_OR_PREVIEW');self.assertFalse(p['write_authorized'])
    def test_party_target_and_cancel(self):
        self.assertEqual(chat.query('level up',chat.FixtureContext('X','PARTY','v','r'))['state'],'HOLD_OUTSIDE_LAB')
        self.assertEqual(chat.query('cancelar',self.c)['state'],'CANCELED_NO_WRITE')

if __name__=='__main__':unittest.main(verbosity=2)
