import unittest,tempfile,subprocess,sys,copy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'))
import r174_local_test_transaction as local
from r149_150_spirit_runtime import make_state
from r173_sqlite_causal_ledger import Ledger,LedgerHold

class CrashRecoveryIntegrationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  self.p=self.root/'state.json';self.db=self.root/'rec.sqlite';self.plan=self.root/'plan.json'
  local.write_atomically(self.p,make_state(ordinal=11,normal_pa=220,normal_pa_max=260,committed=40))
  self.args=dict(tx='T',stage='A',event='EVENT-1',operation='ACTIVATE',params=dict(scene='S1',die_result=3,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY'))
  local.prepare(self.p,self.db,self.plan,**self.args)
 def tearDown(self):self.tmp.cleanup()
 def test_process_restart_after_journal_gap(self):
  out=local.execute(self.p,self.db,self.plan,interrupt_at='AFTER_READBACK_BEFORE_JOURNAL')
  self.assertEqual(out['state'],'LOCAL_INTERRUPTED_AFTER_READBACK_BEFORE_JOURNAL')
  # Isolated Python process; no shared interpreter state.
  script=f"import sys,json;sys.path.insert(0,{str(ROOT/'runtime')!r});from r174_local_test_transaction import recover;print(json.dumps(recover({str(self.p)!r},{str(self.db)!r},{str(self.plan)!r})))"
  result=json.loads(subprocess.check_output([sys.executable,'-c',script],text=True))
  self.assertEqual(result['state'],'READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION')
  self.assertEqual(local.read_json(self.p)['normal_pa'],140)
  self.assertEqual(local.recover(self.p,self.db,self.plan)['state'],'READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION')
  self.assertEqual(local.read_json(self.p)['consumed_events'],['EVENT-1'])
 def test_stop_before_tool_response_is_not_certified(self):
  local.execute(self.p,self.db,self.plan,interrupt_at='AFTER_WRITE_BEFORE_RESPONSE')
  x=local.recover(self.p,self.db,self.plan)
  self.assertEqual(x['state'],'LOCAL_AFTER_NO_CAUSAL_RESPONSE_HOLD')
  with Ledger(self.db) as L:self.assertFalse('JOURNAL_READBACK_CONFIRMED' in [r[0] for r in L.db.execute("SELECT phase FROM observation")])
  self.assertEqual(local.execute(self.p,self.db,self.plan)['state'],'LOCAL_AFTER_NO_CAUSAL_RESPONSE_HOLD')
 def test_different_target_state_blocks_precommit(self):
  fake=local.read_json(self.p);fake['normal_pa']=1;local.write_atomically(self.p,fake)
  with self.assertRaises(local.LocalHold):local.execute(self.p,self.db,self.plan)
 def test_tamper_intent_plan_blocks_execution(self):
  plan=local.read_json(self.plan);plan['params']['die_result']=8;local.write_atomically(self.plan,plan)
  with self.assertRaises(local.LocalHold):local.execute(self.p,self.db,self.plan)
 def test_spend_only_once_after_replay(self):
  local.execute(self.p,self.db,self.plan)
  first=local.read_json(self.p)
  again=local.execute(self.p,self.db,self.plan)
  self.assertEqual(again['state'],'READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION')
  self.assertEqual(local.read_json(self.p),first)
 def test_event_collision_mismatched_payload_not_new_intent(self):
  plan=local.read_json(self.plan)
  with self.assertRaises(LedgerHold):
   with Ledger(self.db) as L:
    L.create_intent(tx='T',stage='A',target='LOCAL_FILE_FIXTURE_NOT_NOTION',parent=plan['parent'],source_version=plan['source_version'],before=plan['before'],after={'normal_pa':999},pre_version=plan['pre_version'],authority='DIR-MESTRE-LABS-REPLICAS-20261016-001')

if __name__=='__main__':unittest.main(verbosity=2)
