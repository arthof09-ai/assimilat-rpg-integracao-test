"""R170 parse T9 and Rule5 directly from retrieved Notion enhanced Markdown.

Table values are evidence at a pinned version, not a replacement/new rule.
The parser refuses title-based identities, duplicate categories, malformed cells
and rows that conflict with the known official range 1..25. It only reads.
"""
from __future__ import annotations
import re,html
from hashlib import sha256

class NormativeHold(ValueError):pass
R5_ID='3ebc2b324ede81449222f3c06b840613'
R5_VERSION='2026-10-09T04:07:06.313Z'
T9_ID='3f2c2b324ede81c0ae0ee4e66212edc9'
T9_VERSION='2026-10-09T19:35:48.531Z'
ORDER=['Bronze','Prata','Ouro','Ouro Negro','Lendário']


def clean(x):return html.unescape(re.sub('<[^>]+>','',x)).strip()
def tables(x):
    out=[]
    for table in re.findall(r'<table\b[^>]*>(.*?)</table>',x,re.I|re.S):
        rows=[]
        for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>',table,re.I|re.S):
            cells=[clean(c) for c in re.findall(r'<td\b[^>]*>(.*?)</td>',row,re.I|re.S)]
            if cells:rows.append(cells)
        if rows:out.append(rows)
    return out


def from_notion(body:str,*,source_page_id:str,version:str,kind:str):
    if kind=='T9':
        if (source_page_id,version)!=(T9_ID,T9_VERSION):raise NormativeHold('T9_SOURCE_STALE')
        expected=['Classificação','Duração','Ação','Custo']
    elif kind=='R5':
        if (source_page_id,version)!=(R5_ID,R5_VERSION):raise NormativeHold('R5_SOURCE_STALE')
        expected=['Classificação','Vida por nível','Alma por nível']
    else:raise NormativeHold('UNKNOWN_SPECIALIST_RULE')
    matches=[t for t in tables(body) if t[0]==expected]
    if len(matches)!=1:raise NormativeHold('UNIQUE_COMPETENT_TABLE_REQUIRED')
    rows=matches[0][1:]
    if len(rows)!=5 or [r[0] for r in rows]!=ORDER or any(len(r)!=len(expected) for r in rows):
        raise NormativeHold('RANK_ROWS_NOT_CANONICAL')
    if kind=='R5':
        parsed={}
        for row in rows:
            hp=re.fullmatch(r'1d(\d+)\s*\+\s*CON',row[1])
            pa=re.fullmatch(r'1d(\d+)\s*\+\s*INT',row[2])
            if not hp or not pa:raise NormativeHold('RULE5_ROW_UNPARSEABLE')
            parsed[row[0]]=dict(hp_dice=int(hp.group(1)),pa_dice=int(pa.group(1)))
        if [(x['hp_dice'],x['pa_dice']) for x in parsed.values()]!=[(6,6),(8,8),(10,10),(12,12),(20,20)]:
            raise NormativeHold('RULE5_DICE_CONFLICT')
    else:
        parsed={}
        for row in rows:
            m=re.fullmatch(r'1d(\d+)\s*\+\s*(\d+)\s*(?:turnos)?',row[1])
            c=re.fullmatch(r'(\d+)\s*PA',row[3])
            if not m or not c:raise NormativeHold('T9_ROW_UNPARSEABLE')
            parsed[row[0]]=dict(duration_die=int(m.group(1)),duration_offset=int(m.group(2)),action=row[2],cost=int(c.group(1)),eligible=row[0]!='Bronze')
        if [tuple(v[k] for k in ('duration_die','duration_offset','cost')) for v in parsed.values()]!=[(4,1,20),(6,1,40),(8,1,80),(10,1,160),(12,2,320)]:
            raise NormativeHold('T9_DICE_COST_CONFLICT')
    return {'source_page_id':source_page_id,'version':version,'kind':kind,
            'row_count':len(rows),'literal_table_hash':sha256(str(matches[0]).encode()).hexdigest(),
            'ranks':parsed,'status':'SOURCE_VERSION_BOUND_READ_ONLY_NO_PRODUCTION_APPROVAL'}


def t9_fixture():
    return '<table header-row="true"><tr><td>Classificação</td><td>Duração</td><td>Ação</td><td>Custo</td></tr>'+''.join(f'<tr><td>{a}</td><td>{b}</td><td>{c}</td><td>{d} PA</td></tr>' for a,b,c,d in [
    ('Bronze','1d4 + 1 turnos','Ação Completa',20),('Prata','1d6 + 1','Ação Completa',40),('Ouro','1d8 + 1','Ação Padrão',80),('Ouro Negro','1d10 + 1','Ação de Movimento',160),('Lendário','1d12 + 2','Ação Livre',320)])+'</table>'

def rule5_fixture():
    return '<table header-row="true"><tr><td>Classificação</td><td>Vida por nível</td><td>Alma por nível</td></tr>'+''.join(f'<tr><td>{a}</td><td>1d{d} + CON</td><td>1d{d} + INT</td></tr>' for a,d in zip(ORDER,[6,8,10,12,20]))+'</table>'
