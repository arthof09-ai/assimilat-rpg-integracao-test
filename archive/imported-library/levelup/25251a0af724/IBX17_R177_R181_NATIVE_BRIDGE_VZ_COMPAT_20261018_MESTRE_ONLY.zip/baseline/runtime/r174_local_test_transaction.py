"""R174 local durable test harness for existing IBX-17 mechanics.

This is NOT a Notion adapter. Demonstrates interruption recovery with two
actual processes, filesystem atomic replace, SQLite durable intent/readback/
observed journal. Its evidence class is LOCAL_SIMULATED_FILE, never native.
"""
from __future__ import annotations
import json,os,tempfile
from pathlib import Path
from copy import deepcopy
from r149_150_spirit_runtime import make_state,Hold
from r167_event_intent_identity import apply,canonical,fingerprint,KNOWN_RULE_VERSION
from r171_spirit_state_integrity import audit
from r173_sqlite_causal_ledger import Ledger,LAB,AUTH,LedgerHold

class LocalHold(ValueError):pass

def read_json(path):return json.loads(Path(path).read_text(encoding='utf8'))

def write_atomically(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(dir=str(p.parent),prefix='.ibx-test-',suffix='.tmp')
    try:
        with os.fdopen(fd,'w',encoding='utf8') as f:
            f.write(canonical(obj));f.flush();os.fsync(f.fileno())
        os.replace(name,p)
        dirfd=os.open(str(p.parent),os.O_RDONLY)
        try:os.fsync(dirfd)
        finally:os.close(dirfd)
    finally:
        if os.path.exists(name):os.unlink(name)

def prepare(statefile,ledgerfile,planfile,*,tx,stage,event,operation,params):
    state=read_json(statefile);audit(state)
    after,result=apply(state,event=event,operation=operation,params=params)
    audit(after)
    if result.startswith('NOOP') or result.startswith('REPLAY_'):raise LocalHold('REPLAY_NOT_NEW_WRITE')
    plan={'tx':tx,'stage':stage,'event':event,'operation':operation,'params':params,
          'target':'LOCAL_FILE_FIXTURE_NOT_NOTION','parent':LAB,
          'source_version':KNOWN_RULE_VERSION,'before':state,'after':after,'pre_version':fingerprint(state),
          'scope':'LOCAL_SIMULATED_FILE_ONLY'}
    plan['receipt_hash']=fingerprint(plan)
    with Ledger(ledgerfile) as ledger:
        ledger.create_intent(tx=tx,stage=stage,target=plan['target'],parent=LAB,
            source_version=KNOWN_RULE_VERSION,before=state,after=after,
            pre_version=plan['pre_version'],authority=AUTH)
    write_atomically(planfile,plan)
    return {'phase':'INTENT_DURABLE','tx':tx,'plan_hash':plan['receipt_hash']}

def _validate_plan(plan):
    if plan.get('scope')!='LOCAL_SIMULATED_FILE_ONLY' or plan.get('parent')!=LAB:
        raise LocalHold('SCOPE_MISMATCH')
    original={k:v for k,v in plan.items() if k!='receipt_hash'}
    if fingerprint(original)!=plan.get('receipt_hash'):raise LocalHold('PLAN_TAMPERED')
    if plan.get('source_version')!=KNOWN_RULE_VERSION:raise LocalHold('SOURCE_VERSION_STALE')

def execute(statefile,ledgerfile,planfile,*,interrupt_at=None):
    plan=read_json(planfile);_validate_plan(plan)
    before,after=plan['before'],plan['after'];a=read_json(statefile)
    with Ledger(ledgerfile) as ledger:
        prior=ledger.classify(plan['tx'],plan['stage'])
        if prior['state'].startswith('SECURITY_FENCED'):raise LocalHold('SECURITY_FENCED_NO_RETRY')
        if a==after:return recover(statefile,ledgerfile,planfile)
        if a!=before:raise LocalHold('PHYSICAL_OTHER_HOLD')
        if prior['state']!='NO_READBACK_CAUSAL_UNCERTAINTY':raise LocalHold('ORIGINAL_INTENT_ALREADY_DISPATCHED_HOLD')
        ledger.add_observation(plan['tx'],plan['stage'],'READBACK_BEFORE',page_version=plan['pre_version'],observed_state=before)
        ledger.add_observation(plan['tx'],plan['stage'],'WRITE_DISPATCHED',page_version=plan['pre_version'])
        write_atomically(statefile,after)
        if interrupt_at=='AFTER_WRITE_BEFORE_RESPONSE':return {'state':'LOCAL_INTERRUPTED_AFTER_FILE_WRITE_NO_CAUSAL_RESPONSE'}
        ledger.add_observation(plan['tx'],plan['stage'],'WRITE_RESPONSE_OBSERVED',page_version=fingerprint(after),
            original_response={'kind':'LOCAL_ATOMIC_FILE_REPLACE','not_notion':True,'target':'LOCAL_FILE_FIXTURE_NOT_NOTION'})
        if read_json(statefile)!=after:raise LocalHold('POSTWRITE_NOT_READABLE')
        ledger.add_observation(plan['tx'],plan['stage'],'READBACK_AFTER',page_version=fingerprint(after),observed_state=after)
        if interrupt_at=='AFTER_READBACK_BEFORE_JOURNAL':return {'state':'LOCAL_INTERRUPTED_AFTER_READBACK_BEFORE_JOURNAL'}
        ledger.add_observation(plan['tx'],plan['stage'],'JOURNAL_READBACK_CONFIRMED',page_version=fingerprint(after))
        return ledger.classify(plan['tx'],plan['stage'])

def recover(statefile,ledgerfile,planfile):
    plan=read_json(planfile);_validate_plan(plan)
    x=read_json(statefile)
    if x not in (plan['before'],plan['after']):raise LocalHold('UNKNOWN_EFFECT_OTHER')
    with Ledger(ledgerfile) as ledger:
        out=ledger.classify(plan['tx'],plan['stage']);phases=[row[0] for row in ledger.db.execute('SELECT phase FROM observation WHERE tx=? AND stage=?',(plan['tx'],plan['stage'])).fetchall()]
        if out['state'].startswith('SECURITY_FENCED'):raise LocalHold('PREVIOUS_SECURITY_REFUSAL')
        if x==plan['before']:return {'state':'LOCAL_BEFORE_NO_RETRY','ledger':out}
        if 'WRITE_RESPONSE_OBSERVED' not in phases:
            return {'state':'LOCAL_AFTER_NO_CAUSAL_RESPONSE_HOLD','ledger':out}
        if 'READBACK_AFTER' not in phases:
            ledger.add_observation(plan['tx'],plan['stage'],'READBACK_AFTER',page_version=fingerprint(x),observed_state=x)
        if 'JOURNAL_READBACK_CONFIRMED' not in phases:
            ledger.add_observation(plan['tx'],plan['stage'],'JOURNAL_READBACK_CONFIRMED',page_version=fingerprint(x))
        return ledger.classify(plan['tx'],plan['stage'])


def demo(directory):
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    statepath=root/'state.json';db=root/'ledger.sqlite';planpath=root/'plan.json'
    state=make_state(ordinal=11,normal_pa=220,normal_pa_max=260,committed=40)
    write_atomically(statepath,state)
    out=prepare(statepath,db,planpath,tx='IBX17-R174-LOCAL-INTERRUPTION-20261018-01',
        stage='ACTIVATE',event='R174-LOCAL-ACT',operation='ACTIVATE',
        params={'scene':'SCENE-LOCAL-1','die_result':3,'action':'PADRAO',
                'source_proof':'SYNTHETIC_TEST_ONLY','scene_proof':'SYNTHETIC_TEST_ONLY'})
    a=execute(statepath,db,planpath,interrupt_at='AFTER_READBACK_BEFORE_JOURNAL')
    b=recover(statepath,db,planpath)
    return {'intent':out['phase'],'interruption':a['state'],'recovery':b['state'],
            'final_state':read_json(statepath),'local_only':True}
