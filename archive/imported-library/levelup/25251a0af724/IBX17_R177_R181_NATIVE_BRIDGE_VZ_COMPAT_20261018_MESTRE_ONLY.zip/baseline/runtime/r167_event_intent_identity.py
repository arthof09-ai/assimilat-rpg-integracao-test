"""IBX-17 R167: append-only event-intent fingerprint; fail-closed idempotency.

Adds a verifiable request identity to existing R149/R150 local state changes.
DOES NOT own a Notion writer, authorize production, attest a human, or reconstruct
historical unbound event intents by guessing.
"""
from __future__ import annotations
import json,hashlib
from copy import deepcopy
from typing import Mapping
from r149_150_spirit_runtime import (activate,advance_turn,effect_damage,rest,
    change_spirit,deactivate,Hold,check)

ACTIONS={'ACTIVATE':activate,'TURN':advance_turn,'DAMAGE':effect_damage,
         'REST':rest,'SWITCH_LEGACY':change_spirit,'DEACTIVATE':deactivate}
KNOWN_RULE_VERSION='2026-10-09T19:35:48.531Z'


def canonical(obj):
    return json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)

def fingerprint(x):return hashlib.sha256(canonical(x).encode()).hexdigest()


def apply(state:Mapping,*,event:str,operation:str,params:dict,
          source_version:str=KNOWN_RULE_VERSION,expected_actor:str|None=None):
    """Execute one synthetic TEST state event, or prove an identical replay.

    `event_bindings` is a durable application receipt in a state persisted by
    the caller; a legacy event with no binding is quarantined, not NO-OP.
    """
    check(state)
    if type(event)!=str or not event or type(params)!=dict:raise Hold('INVALID_EVENT_OR_PAYLOAD')
    if operation not in ACTIONS:raise Hold('UNKNOWN_OPERATION')
    if source_version!=KNOWN_RULE_VERSION:raise Hold('SPECIALIST_VERSION_STALE')
    if expected_actor is not None and expected_actor!=state['actor_id']:raise Hold('ACTOR_IDENTITY_MISMATCH')
    if not state['actor_id'] or not state['spirit_id']:raise Hold('ACTOR_SPIRIT_REQUIRED')
    identity={'event':event,'operation':operation,'actor':state['actor_id'],
              'spirit':state['spirit_id'],'source_version':source_version,
              'params':deepcopy(params),'scope':state['scope']}
    intent_hash=fingerprint(identity)
    bindings=state.get('event_bindings',{})
    if not isinstance(bindings,dict):raise Hold('EVENT_BINDING_STORE_CORRUPT')
    if event in state['consumed_events']:
        recorded=bindings.get(event)
        if not recorded:raise Hold('LEGACY_EVENT_NO_INTENT_BINDING')
        if recorded.get('intent_sha256')!=intent_hash or recorded.get('request')!=identity:
            raise Hold('EVENT_ID_COLLISION_DIFFERENT_REQUEST')
        if recorded.get('result_sha256')!=fingerprint(strip_bindings(state)):
            # Another legitimate event may have advanced state; same-event request is still
            # already consumed but cannot certify post-state equal without a journal lookup.
            return deepcopy(state),'REPLAY_IDENTITY_VERIFIED_READONLY_STATE_ADVANCED'
        return deepcopy(state),'NOOP_IDENTITY_VERIFIED'
    if event in bindings:raise Hold('BINDING_FOR_UNCONSUMED_EVENT')
    if len(set(state['consumed_events']))!=len(state['consumed_events']):raise Hold('DUPLICATE_CONSUMED_EVENT_ID')
    before=deepcopy(state)
    result,status=ACTIONS[operation](deepcopy(state),event=event,**params)
    if len(result['consumed_events'])!=len(before['consumed_events'])+1 or result['consumed_events'][-1]!=event:
        raise Hold('RUNTIME_EVENT_HISTORY_INVALID')
    if status.startswith('NOOP'):raise Hold('UNEXPECTED_RUNTIME_NOOP')
    result.setdefault('event_bindings',deepcopy(bindings))
    result['event_bindings'][event]={'request':identity,'intent_sha256':intent_hash,
        'source_version':source_version,'result_sha256':fingerprint(strip_bindings(result)),
        'classification':'SYNTHETIC_TEST_CAUSAL_RECEIPT_NO_NATIVE_AUTHORITY'}
    check(result)
    return result,status


def strip_bindings(state):
    s=deepcopy(state);s.pop('event_bindings',None);return s
