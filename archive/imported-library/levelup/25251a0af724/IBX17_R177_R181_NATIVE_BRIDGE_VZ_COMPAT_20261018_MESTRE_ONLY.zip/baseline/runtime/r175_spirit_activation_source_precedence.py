"""IBX-17 R175: reconcile VZ sandbox activation literal with specialist T9.

Effective Spirit level is MIN(actor ordinal, spirit cap), not actor rank.
Compatibility +1 is conditional and must NOT be self-certified from a VZ
literal or a caller-created boolean. No Party writes or campaign activation.
"""
from __future__ import annotations
from dataclasses import dataclass
import re
from r149_150_spirit_runtime import tier,Hold
from r165_notional_table_source_parser import sample_matrix,parse_transform_matrix

VZ_ID='3f2c2b324ede816198a5f0fb525223ee'
VZ_VERSION='2026-10-07T21:37:03.824Z'
T9_ID='3f2c2b324ede81c0ae0ee4e66212edc9'
T9_VERSION='2026-10-09T19:35:48.531Z'
ACTIONS={'Ação Livre':'LIVRE','Livre':'LIVRE','Movimento':'MOVIMENTO','Ação de Movimento':'MOVIMENTO','Padrão':'PADRAO','Ação Padrão':'PADRAO','Completa':'COMPLETA','Ação Completa':'COMPLETA'}

class PrecedenceHold(ValueError):pass

def parse_literal(s):
    m=re.fullmatch(r'\s*([^·]+)\s*·\s*(\d+)\s*PA\s*·\s*1d(\d+)\s*\+\s*(\d+)\s*',s)
    if not m:raise PrecedenceHold('ACTIVATION_LITERAL_INVALID')
    act=ACTIONS.get(m.group(1).strip())
    if act is None:raise PrecedenceHold('ACTION_UNSUPPORTED')
    return {'action':act,'cost':int(m.group(2)),'duration_die':int(m.group(3)),'duration_offset':int(m.group(4))}

def evaluate(row,*,actor_level=None,actor_evidence=None):
    eff=row['effective_ordinal']
    if not 1<=eff<=25:raise PrecedenceHold('SPIRIT_EFFECTIVE_LEVEL_OUT_OF_RANGE')
    if actor_level is not None:
        if not isinstance(actor_evidence,dict) or actor_evidence.get('scope')!='UNIT_TEST_ONLY' or actor_evidence.get('actor')!=row['actor']:
            raise PrecedenceHold('ACTOR_RANK_SOURCE_NOT_AUTHENTICATED')
        if type(actor_level)!=int or not eff<=actor_level<=25:raise PrecedenceHold('INCONSISTENT_ACTOR_VS_EFFECTIVE_LEVEL')
        category=tier(actor_level)
        rank_basis='TEST_ONLY_ACTOR_ORDINAL_EXPLICIT'
    elif eff>=21:
        # Since effective ordinal = min(actor, spirit cap), actor must be >=21.
        category=tier(21);rank_basis='ACTOR_LEGENDARY_INFERRED_FROM_MIN_GE_21'
    else:
        return {'actor':row['actor'],'spirit':row['spirit'],'decision':'HOLD_ACTOR_RANK_NOT_DEDUCIBLE_FROM_SPIRIT_EFFECTIVE_LEVEL',
                'effective_ordinal':eff,'literal':row['activation_literal'],'campain_eligibility':'NOT_CERTIFIED'}
    x=parse_literal(row['activation_literal']);baseline={k:category[k] for k in ('action','cost','die','offset')}
    main={'actor':row['actor'],'spirit':row['spirit'],'effective_ordinal':eff,
          'actor_rank_basis':rank_basis,'actor_rank':category['category'],
          'literal':x,'T9_baseline':baseline,'classification':'VZ_SANDBOX_NOT_CAMPAIGN',
          'native_writes':0}
    if (x['action'],x['cost'],x['duration_die'])!=(category['action'],category['cost'],category['die']):
        return main|{'decision':'HOLD_ACTION_COST_OR_DIE_CONFLICT'}
    if x['duration_offset']==category['offset']:
        return main|{'decision':'T9_BASE_DURATION_NUMERIC_MATCH_SANDBOX_ONLY'}
    if x['duration_offset']==category['offset']+1:
        return main|{'decision':'HOLD_COMPATIBILITY_NOT_ACTOR_ATTESTED','candidate_bonus':1,
                     'baseline_offset':category['offset'],'VZ_offset':x['duration_offset']}
    return main|{'decision':'HOLD_DURATION_CONFLICT'}

def reconcile_rows(rows):
    if len(rows)!=8:raise PrecedenceHold('VZ_DENOMINATOR_DIFFERENT')
    return [evaluate(r) for r in rows]

def source_fixture():
    return parse_transform_matrix(sample_matrix(),source_page_id=VZ_ID,source_version=VZ_VERSION)
