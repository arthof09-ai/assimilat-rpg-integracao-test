"""R173 local durable stage evidence ledger for LEVEL-UP-ENGINE/IBX-17.

SQLite synchronous=FULL + WAL for durable local evidence across process restarts.
A ledger entry is neither a native Notion write nor an independent host
attestation. Security refusal is an irreversible automatic-retry fence.
Does not create a new motor, canonical journal, lease or writer authority.
"""
from __future__ import annotations
import sqlite3,json,hashlib,datetime
from pathlib import Path

class LedgerHold(ValueError):pass

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

LAB='3fbc2b324ede804a95fafcb7b293c92c'
AUTH='DIR-MESTRE-LABS-REPLICAS-20261016-001'
class Ledger:
    def __init__(self,path):
        self.path=str(Path(path).resolve())
        self.db=sqlite3.connect(self.path,timeout=8)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS intent(
            tx TEXT NOT NULL, stage TEXT NOT NULL, target TEXT NOT NULL,
            parent TEXT NOT NULL, source_version TEXT NOT NULL,
            before_sha TEXT NOT NULL, after_sha TEXT NOT NULL,
            pre_version TEXT NOT NULL, authority TEXT NOT NULL,
            envelope_sha TEXT NOT NULL, created_at TEXT NOT NULL,
            PRIMARY KEY(tx,stage));
        CREATE TABLE IF NOT EXISTS observation(
            tx TEXT NOT NULL, stage TEXT NOT NULL, seq INTEGER NOT NULL,
            phase TEXT NOT NULL, page_version TEXT, observed_sha TEXT,
            response_json TEXT, error_code TEXT, captured_at TEXT NOT NULL,
            source_class TEXT NOT NULL,
            prev_sha TEXT NOT NULL, chain_sha TEXT NOT NULL,
            PRIMARY KEY(tx,stage,seq),
            FOREIGN KEY(tx,stage) REFERENCES intent(tx,stage));
        ''')
        self.db.commit()
    def close(self):self.db.close()
    def __enter__(self):return self
    def __exit__(self,*_):self.close()
    @staticmethod
    def _now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
    def create_intent(self,*,tx,stage,target,parent,source_version,before,after,pre_version,authority):
        if not all(isinstance(x,str) and x for x in (tx,stage,target,parent,source_version,pre_version,authority)):
            raise LedgerHold('IDENTITY_MISSING')
        if parent!=LAB or authority!=AUTH:raise LedgerHold('LAB_AUTHORITY_HOLD')
        if before==after:raise LedgerHold('SAME_BEFORE_AFTER')
        envelope=dict(tx=tx,stage=stage,target=target,parent=parent,source_version=source_version,
            before_sha=digest(before),after_sha=digest(after),pre_version=pre_version,authority=authority)
        record=(*[envelope[k] for k in ('tx','stage','target','parent','source_version','before_sha','after_sha','pre_version','authority')],digest(envelope),self._now())
        with self.db:
            old=self.db.execute('SELECT envelope_sha FROM intent WHERE tx=? AND stage=?',(tx,stage)).fetchone()
            if old:
                if old[0]!=digest(envelope):raise LedgerHold('DUPLICATE_INTENT_CONFLICT')
                return {'status':'EXISTING_IDENTICAL_INTENT_READONLY','intent_sha':old[0]}
            self.db.execute('INSERT INTO intent VALUES(?,?,?,?,?,?,?,?,?,?,?)',record)
        return {'status':'INTENT_DURABLY_PERSISTED','intent_sha':digest(envelope)}
    def verify_chain(self,tx,stage):
        rows=self.db.execute('SELECT seq,phase,page_version,observed_sha,response_json,error_code,captured_at,source_class,prev_sha,chain_sha FROM observation WHERE tx=? AND stage=? ORDER BY seq',(tx,stage)).fetchall()
        prev='GENESIS'
        for i,row in enumerate(rows,1):
            seq,phase,page_version,observed_sha,response_json,error_code,captured_at,source_class,prev_sha,chain_sha=row
            payload={'tx':tx,'stage':stage,'seq':seq,'phase':phase,'page_version':page_version,
                     'observed_sha':observed_sha,'response_json':response_json,
                     'error_code':error_code,'captured_at':captured_at,'source_class':source_class,'prev_sha':prev_sha}
            if seq!=i or prev_sha!=prev or digest(payload)!=chain_sha:
                raise LedgerHold('OBSERVATION_CHAIN_CORRUPTED')
            prev=chain_sha
        return {'status':'LOCAL_HASH_CHAIN_VALID','observations':len(rows),'chain_head':prev,
                'not_an_external_signature':True}

    def add_observation(self,tx,stage,phase,*,page_version=None,observed_state=None,original_response=None,error_code=None,source_class='SELF_REVIEW_ONLY'):
        if phase not in ('WRITE_DISPATCHED','WRITE_RESPONSE_OBSERVED','READBACK_BEFORE','READBACK_AFTER',
                         'READBACK_OTHER','JOURNAL_READBACK_CONFIRMED','SECURITY_REFUSED'):
            raise LedgerHold('UNKNOWN_PHASE')
        if source_class!='SELF_REVIEW_ONLY':raise LedgerHold('CLAIMED_EXTERNAL_AUDITOR_NOT_ALLOWED')
        self.verify_chain(tx,stage)
        with self.db:
            row=self.db.execute('SELECT before_sha,after_sha FROM intent WHERE tx=? AND stage=?',(tx,stage)).fetchone()
            if not row:raise LedgerHold('INTENT_NOT_PERSISTED')
            existing=self.db.execute('SELECT phase FROM observation WHERE tx=? AND stage=? ORDER BY seq',(tx,stage)).fetchall()
            phases=[x[0] for x in existing]
            if 'SECURITY_REFUSED' in phases and phase not in ('READBACK_BEFORE','READBACK_AFTER','READBACK_OTHER'):
                raise LedgerHold('SECURITY_REFUSAL_FENCED')
            if phase=='WRITE_DISPATCHED' and ('WRITE_DISPATCHED' in phases or 'JOURNAL_READBACK_CONFIRMED' in phases):
                raise LedgerHold('DISPATCH_REPLAY_DENIED')
            if phase in ('READBACK_BEFORE','READBACK_AFTER','READBACK_OTHER'):
                if observed_state is None:raise LedgerHold('READBACK_CONTENT_MISSING')
                h=digest(observed_state)
                required={'READBACK_BEFORE':row[0],'READBACK_AFTER':row[1]}.get(phase)
                if required and h!=required:raise LedgerHold('READBACK_HASH_MISMATCH')
                if phase=='READBACK_OTHER' and h in row:raise LedgerHold('OTHER_NOT_OTHER')
            else:h=None
            if phase=='JOURNAL_READBACK_CONFIRMED':
                if 'READBACK_AFTER' not in phases:raise LedgerHold('JOURNAL_WITHOUT_AFTER_READBACK')
                if 'WRITE_RESPONSE_OBSERVED' not in phases:raise LedgerHold('JOURNAL_WITHOUT_CAUSAL_REPLY')
                if not page_version:raise LedgerHold('JOURNAL_READBACK_VERSION_REQUIRED')
            if phase=='SECURITY_REFUSED' and not error_code:raise LedgerHold('SECURITY_ERROR_EVIDENCE_REQUIRED')
            seq=len(existing)+1
            prev=self.db.execute('SELECT chain_sha FROM observation WHERE tx=? AND stage=? ORDER BY seq DESC LIMIT 1',(tx,stage)).fetchone()
            prev_sha=prev[0] if prev else 'GENESIS'
            response_json=json.dumps(original_response,ensure_ascii=False,sort_keys=True) if original_response is not None else None
            when=self._now()
            payload={'tx':tx,'stage':stage,'seq':seq,'phase':phase,'page_version':page_version,
                     'observed_sha':h,'response_json':response_json,'error_code':error_code,
                     'captured_at':when,'source_class':source_class,'prev_sha':prev_sha}
            self.db.execute('INSERT INTO observation VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                (tx,stage,seq,phase,page_version,h,response_json,error_code,when,source_class,prev_sha,digest(payload)))
        return {'seq':seq,'phase':phase,'review':'SELF_REVIEW_ONLY','native_tool_called':False}
    def classify(self,tx,stage):
        self.verify_chain(tx,stage)
        row=self.db.execute('SELECT target,pre_version,before_sha,after_sha FROM intent WHERE tx=? AND stage=?',(tx,stage)).fetchone()
        if not row:raise LedgerHold('NO_INTENT')
        obs=self.db.execute('SELECT phase,page_version,observed_sha,error_code FROM observation WHERE tx=? AND stage=? ORDER BY seq',(tx,stage)).fetchall()
        phases=[x[0] for x in obs];readbacks=[x for x in obs if x[0].startswith('READBACK_')]
        out={'tx':tx,'stage':stage,'target':row[0],'original_pre_version':row[1],
             'observations':len(obs),'native_write_authorized':False,'automatic_retry_allowed':False,
             'review':'SELF_REVIEW_ONLY'}
        if not readbacks:return out|{'state':'NO_READBACK_CAUSAL_UNCERTAINTY'}
        last=readbacks[-1]
        if last[0]=='READBACK_OTHER':return out|{'state':'UNKNOWN_EFFECT_QUARANTINE'}
        if 'SECURITY_REFUSED' in phases:
            return out|{'state':'SECURITY_FENCED_BEFORE' if last[0]=='READBACK_BEFORE' else 'SECURITY_FENCED_AFTER_RECONCILIATION_REQUIRED'}
        if last[0]=='READBACK_BEFORE':return out|{'state':'PHYSICAL_BEFORE'}
        if 'JOURNAL_READBACK_CONFIRMED' in phases:return out|{'state':'READBACK_AND_JOURNAL_OBSERVED_NOT_NATIVE_ATTESTATION'}
        return out|{'state':'AFTER_WITHOUT_JOURNAL_CAUSAL_HOLD'}
