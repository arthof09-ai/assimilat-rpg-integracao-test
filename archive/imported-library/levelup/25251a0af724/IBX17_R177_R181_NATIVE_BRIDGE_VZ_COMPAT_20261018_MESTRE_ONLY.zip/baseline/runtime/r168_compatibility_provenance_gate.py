"""R168: do not grant specialist/actor-specific duration bonus via caller bool.

The T9 rule states compatible Spirits get +1; it does NOT establish that a
particular actor/spirit pairing is compatible. Test can assume compatibility,
canon cannot without independently validated actor-specific origin evidence.
"""
from __future__ import annotations
from dataclasses import dataclass
from r149_150_spirit_runtime import tier,Hold
RULE_PAGE='3f2c2b324ede81c0ae0ee4e66212edc9'
RULE_VERSION='2026-10-09T19:35:48.531Z'

@dataclass(frozen=True)
class Evidence:
    scope:str
    actor_id:str
    spirit_id:str
    source_id:str=''
    source_version:str=''
    caller_claims_readback:bool=False
    external_attestation:str|None=None


def calculate(*,actor_ordinal:int,rolled:int,actor_id:str,spirit_id:str,evidence:Evidence|None=None):
    t=tier(actor_ordinal)
    if type(rolled)!=int or not 1<=rolled<=t['die']:raise Hold('ROLL_INVALID')
    if not actor_id or not spirit_id:raise Hold('ACTOR_SPIRIT_MISSING')
    base=rolled+t['offset']
    if evidence is None:
        return {'base':base,'bonus':0,'total':base,'scope':'UNCONDITIONAL_T9','write_allowed':False}
    if (evidence.actor_id,evidence.spirit_id)!=(actor_id,spirit_id):raise Hold('PAIR_MISMATCH')
    if evidence.scope=='UNIT_TEST_SYNTHETIC':
        return {'base':base,'bonus':1,'total':base+1,'scope':'UNIT_TEST_ONLY','write_allowed':False}
    # Neither native_readback=True nor a string with plausible source URL verifies
    # a particular compatibility relationship. A native external verifier would
    # need a separately trusted capability unavailable here.
    raise Hold('ACTOR_SPIRIT_COMPATIBILITY_ATTESTATION_UNAVAILABLE')
