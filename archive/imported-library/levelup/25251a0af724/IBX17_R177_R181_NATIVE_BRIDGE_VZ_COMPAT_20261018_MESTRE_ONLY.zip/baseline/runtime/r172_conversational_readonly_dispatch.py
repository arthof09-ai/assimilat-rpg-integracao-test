"""R172: minimal mobile-first conversational dispatch, no forged confirmation.
Consistent read-only results for existing historical events and new TEST preview.
Never executes actions from a natural-language message or creates a host token.
"""
from __future__ import annotations
from dataclasses import dataclass

TEST_LAB='3fbc2b324ede804a95fafcb7b293c92c'

class ConversationHold(ValueError):pass

@dataclass(frozen=True)
class FixtureContext:
    target_id:str
    parent_id:str
    physical_version:str
    source_version:str
    scope:str='LAB_TEST'


def query(intent:str,context:FixtureContext,*,requested_event:str|None=None,readback:dict|None=None):
    if context.scope!='LAB_TEST' or context.parent_id!=TEST_LAB:
        return {'state':'HOLD_OUTSIDE_LAB','write_authorized':False}
    if not context.physical_version or not context.source_version:
        return {'state':'HOLD_VERSION_MISSING','write_authorized':False}
    aliases={'status':'STATUS','consultar':'STATUS','level up':'UP_PREVIEW',
      'subir nivel':'UP_PREVIEW','level down':'DOWN_PREVIEW',
      'descer nivel':'DOWN_PREVIEW','transformacao':'SPIRIT_PREVIEW',
      'equipamento':'EQUIPMENT_PREVIEW','cancelar':'CANCEL'}
    key=aliases.get(intent.strip().lower())
    if key is None:return {'state':'CLARIFY_UNSUPPORTED_INTENT','write_authorized':False}
    if key=='CANCEL':return {'state':'CANCELED_NO_WRITE','write_authorized':False}
    if key=='STATUS':
        if not isinstance(readback,dict) or readback.get('target_id')!=context.target_id or readback.get('version')!=context.physical_version:
            return {'state':'HOLD_READBACK_CONTEXT_MISMATCH','write_authorized':False}
        return {'state':'READ_ONLY_STATUS','readback':readback,'write_authorized':False}
    return {'state':'AWAITING_CHOICE_OR_PREVIEW', 'intent':key,'target':context.target_id,
       'source_version':context.source_version,'physical_version':context.physical_version,
       'event':requested_event,'requires_real_post_preview_confirmation':True,
       'write_authorized':False}
