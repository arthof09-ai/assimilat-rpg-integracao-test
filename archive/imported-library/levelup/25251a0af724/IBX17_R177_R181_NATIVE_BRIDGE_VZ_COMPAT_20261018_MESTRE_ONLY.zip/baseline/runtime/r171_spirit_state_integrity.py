"""R171 stronger invariants than legacy R149/150 check, no history rewrite.
Denies corrupted imported states before planning any mechanical action.
"""
from r149_150_spirit_runtime import check,Hold,tier


def audit(state):
    check(state)
    if type(state.get('ordinal'))!=int or not 1<=state['ordinal']<=25:raise Hold('INVALID_ORDINAL')
    if not isinstance(state['actor_id'],str) or not state['actor_id'] or not isinstance(state['spirit_id'],str) or not state['spirit_id']:
        raise Hold('INVALID_ACTOR_SPIRIT_IDS')
    if not isinstance(state['used_scenes'],list) or not all(isinstance(x,str) and x for x in state['used_scenes']):
        raise Hold('INVALID_SCENE_IDS')
    if len(state['used_scenes'])!=len(set(state['used_scenes'])):raise Hold('DUPLICATE_SCENE_ID')
    if not isinstance(state['consumed_events'],list) or len(state['consumed_events'])!=len(set(state['consumed_events'])):
        raise Hold('DUPLICATE_EVENT_IDS')
    if len(state['history'])!=len(state['consumed_events']):raise Hold('HISTORY_COUNT_MISMATCH')
    if [e.get('event') for e in state['history']]!=state['consumed_events']:
        raise Hold('HISTORY_EVENT_ORDER_MISMATCH')
    if state['spirit_temp_hp']>state['spirit_hp_max'] or state['spirit_pa']>state['spirit_pa_max']:
        raise Hold('FORM_RESERVE_EXCEEDS_SOURCE_MAX')
    if state['form_active']:
        if state['duration_left']<1 or state['active_scene'] not in state['used_scenes']:
            raise Hold('INVALID_ACTIVE_FORM_TIME_SCENE')
        if state['ordinal']<6:raise Hold('BRONZE_FORM_ILLEGAL')
    elif state['active_scene'] is not None:raise Hold('INACTIVE_FORM_HAS_SCENE')
    if state['last_activation_ordinal'] is not None:
        if type(state['last_activation_ordinal'])!=int or state['last_activation_ordinal']!=len(state['used_scenes']):
            raise Hold('ACTIVATION_COUNT_SCENE_MISMATCH')
    elif state['used_scenes']:raise Hold('MISSING_LAST_USE_INDEX')
    if state.get('rest_evidence'):
        r=state['rest_evidence']
        if r.get('after_activation_index')!=state['last_activation_ordinal'] or r.get('scope')!='SYNTHETIC_TEST_ONLY':
            raise Hold('UNBOUND_REST_EVIDENCE')
    return {'status':'LOCAL_STATE_INVARIANTS_PASS','actor':state['actor_id'],'events':len(state['consumed_events']),
        'scenes':len(state['used_scenes']),'form_active':state['form_active'],
        'authority':'SYNTHETIC_TEST_ONLY_NO_NATIVE_WRITE'}
