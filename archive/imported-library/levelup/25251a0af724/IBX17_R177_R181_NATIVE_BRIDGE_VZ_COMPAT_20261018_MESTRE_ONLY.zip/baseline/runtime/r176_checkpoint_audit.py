"""R176 combined read-only audit of physical Notion readback and local mechanisms.
Must not invent independent attestation or terminal production certification.
"""
from __future__ import annotations
import json
from pathlib import Path
from r169_native_recovery_verifier import Envelope,LAB,AUTH
from r175_spirit_activation_source_precedence import source_fixture,reconcile_rows
from r170_normative_table_reconciler import from_notion,t9_fixture,rule5_fixture,T9_ID,T9_VERSION,R5_ID,R5_VERSION

def evaluate(path):
    d=json.loads(Path(path).read_text(encoding='utf8'))
    p=d['pages'];r155=p['R155'];r158=p['R158'];r145=p['R145'];vz=p['VZ08']
    assert p['OP']['R166_checkpoint']
    assert r155['normal_journal']=='COMMITTED_AFTER_NATIVE_READBACK' and r155['spirit_journal']=='COMMITTED_AFTER_NATIVE_READBACK'
    assert r155['terminal']=='INTENT_PREPARED' and r155['native_auto_retry_blocked']
    assert r158['normal_pa']==220 and not r158['form_active'] and r158['events_consumed']==0 and r158['security_refusal']
    assert r145['level']==17 and not r145['human_confirmation_after_preview']
    assert vz['scope']=='VZ_SANDBOX_CANON' and vz['rows']==8 and vz['final_totals_complete']==0
    # These examples are *classifications of the above physically observed markers*, not
    # recreated native source bytes; the before/after mechanical objects are minimal.
    a=Envelope(tx='R155',stage='NORMAL+SPIRIT',target=r155['id'],parent=LAB,source_version='RULE@REOPENED',
      pre_version='PRE@R155',readback_version=r155['version'],before={'level':17},after={'level':18},
      observed={'level':18},journal='COMMITTED',terminal='PREPARED',security_refusal=True,authority=AUTH).classify()
    b=Envelope(tx='R158',stage='A',target=r158['id'],parent=LAB,source_version='RULE@REOPENED',
      pre_version='PRE@R158',readback_version=r158['version'],before={'normal_pa':220,'form_active':False},
      after={'normal_pa':140,'form_active':True},observed={'normal_pa':220,'form_active':False},
      journal='WRITE_DISPATCHED',terminal='PREPARED',security_refusal=True,authority=AUTH).classify()
    assert a['classification']=='MARKER_STALE_SECURITY_FENCED'
    assert b['classification']=='BEFORE_SECURITY_FENCED'
    matrix=reconcile_rows(source_fixture())
    assert len(matrix)==8
    assert sum(x['decision']=='HOLD_COMPATIBILITY_NOT_ACTOR_ATTESTED' for x in matrix)==6
    assert sum(x['decision']=='HOLD_ACTOR_RANK_NOT_DEDUCIBLE_FROM_SPIRIT_EFFECTIVE_LEVEL' for x in matrix)==2
    t9=from_notion(t9_fixture(),source_page_id=T9_ID,version=T9_VERSION,kind='T9')
    r5=from_notion(rule5_fixture(),source_page_id=R5_ID,version=R5_VERSION,kind='R5')
    return {'operation':'LEVEL-UP-ENGINE/IBX-17','base_checkpoint':'R166','actor':'MESTRE_SIDE',
      'R155':a['classification'],'R158':b['classification'],'R145':'AWAITING_HOST_ATTESTED_HUMAN_CONFIRMATION',
      'R129_R130':'NO_AUTORETRY_SECURITY_FENCED','R175':{'rows':len(matrix),'possible_compatibility_unattested':6,'actor_rank_undetermined':2},
      'sources':[t9['source_page_id'],r5['source_page_id'],vz['id']],
      'new_notion_mechanical_writes':0,'party_writes':0,'production':'HOLD',
      'review':'SELF_REVIEW_ONLY','native_immutability_not_proved':True,
      'classification_only':True}
if __name__=='__main__':
 import sys
 print(json.dumps(evaluate(sys.argv[1]),ensure_ascii=False,indent=2))
