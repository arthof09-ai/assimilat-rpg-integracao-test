"""R169: two-phase readback verifier for *observed* Notion incident envelopes.

No claim of atomic CAS. No native write method. Strict before/after, identity,
version and provenance checks. Previous security refusal fences all auto-retry.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json

LAB='3fbc2b324ede804a95fafcb7b293c92c'
AUTH='DIR-MESTRE-LABS-REPLICAS-20261016-001'

class RecoveryHold(ValueError):pass

def digest(x):return sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
@dataclass(frozen=True)
class Envelope:
    tx:str;stage:str;target:str;parent:str;source_version:str;pre_version:str
    readback_version:str;before:dict;after:dict;observed:dict
    journal:str;terminal:str;security_refusal:bool;authority:str=AUTH
    original_call_ref:str|None=None
    reviewer:str='SELF_REVIEW_ONLY'

    def classify(self):
        core={'tx':self.tx,'stage':self.stage,'target':self.target,
              'version':self.readback_version,'review':self.reviewer,
              'auto_retry_allowed':False,'native_writes':0}
        if not all((self.tx,self.stage,self.target,self.source_version,self.pre_version,
                    self.readback_version,self.authority)):
            return core|{'classification':'MISSING_PRECONDITION'}
        if self.parent!=LAB or self.authority!=AUTH or self.reviewer!='SELF_REVIEW_ONLY':
            return core|{'classification':'AUTHORITY_OR_REVIEW_SCOPE_HOLD'}
        if self.before==self.after:return core|{'classification':'NO_EFFECT_RECEIPT_INVALID'}
        a,b,x=map(digest,(self.before,self.after,self.observed))
        core|={'before_hash':a,'after_hash':b,'observed_hash':x}
        if x not in (a,b):return core|{'classification':'UNKNOWN_EFFECT_OTHER'}
        if x==a:
            if self.journal=='COMMITTED':return core|{'classification':'JOURNAL_AHEAD_OF_PHYSICAL'}
            return core|{'classification':'BEFORE_SECURITY_FENCED' if self.security_refusal else 'BEFORE_NO_EFFECT'}
        if self.pre_version==self.readback_version:
            return core|{'classification':'VERSION_NOT_ADVANCED_UNCERTAIN'}
        if self.journal=='COMMITTED':
            if self.terminal=='COMMITTED':return core|{'classification':'STAGE_CONSISTENT_READ_ONLY'}
            return core|{'classification':'MARKER_STALE_SECURITY_FENCED' if self.security_refusal else 'MARKER_STALE_REVIEW_REQUIRED'}
        if self.journal in ('PREPARED','WRITE_DISPATCHED'):
            return core|{'classification':'AFTER_JOURNAL_GAP_REQUIRE_NATIVE_CAUSAL_REF'}
        return core|{'classification':'UNRECOGNIZED_JOURNAL_HOLD'}
