# LEVEL-UP-ENGINE / IBX-17 — R167–R176 (MESTRE-ONLY)

## Resume and boundary

Continuation of existing **LEVEL-UP-ENGINE / IBX-17**. Baseline R01–R166 is unchanged. Source operation: `3f2c2b324ede81f48f80f6d27449d107`. Lab parent: `3fbc2b324ede804a95fafcb7b293c92c`. Experimental authority `DIR-MESTRE-LABS-REPLICAS-20261016-001` applies only to isolated TEST materials. No Party/O Primeiro/production writer; no external independent auditor.

The previous package R157–R166 SHA-256 is `16af88e0a3903ba2bc603a53bbc0187b2d78b33c6ec0a11ff8f2b265a049d107`; it is NOT embedded in this package. Two unchanged dependencies in `runtime/` retain their source hashes: `r149_150_spirit_runtime.py` SHA `3c92d8fb27a0832b1e438d74655ae6e5cf91a42d9d2f5d48b6fcfe741a47abe3`, `r165_notional_table_source_parser.py` SHA `01f6764fbe0554b818ba76937a06264e75a20de6a168ec739c24349ee833965a`.

## New functional additions

- R167 `r167_event_intent_identity.py`: binds event ID to actor, Spirit, source version, operation, choices, and request hash. Identical replays are read-only, divergent replays fail, unbound historical event IDs quarantine.
- R168 `r168_compatibility_provenance_gate.py`: real compatibility cannot be granted by a caller-owned `native_readback=True` or `INDEPENDENTLY_VERIFIED` string. UNIT_TEST compatibility only, never production.
- R169 `r169_native_recovery_verifier.py`: strictly read-only physical BEFORE/AFTER/OTHER and journal classifier, security fence and stale version checks; no marker-repair writer.
- R170 `r170_normative_table_reconciler.py`: parse source-pinned Rule5 and T9 Notion tables (live sources were re-opened independently), reject duplicate/stale/malformed table, Bronze historical row is ineligible.
- R171 `r171_spirit_state_integrity.py`: additional scene/event/resource/history invariants for imported synthetic state.
- R172 `r172_conversational_readonly_dispatch.py`: mobile-conversation preview/status/cancel intents with explicit lab and version checks. No human confirmation automatically created.
- R173 `r173_sqlite_causal_ledger.py`: append-only observation tables with SHA-256 chain, SQLite synchronous FULL/WAL, duplicate-intent detection, safety refusal fencing and cross-process persistence. `SELF_REVIEW_ONLY` is not an independent signature and local hash chains are not cryptographic signatures.
- R174 `r174_local_test_transaction.py`: one actual local filesystem activation TEST with durable intent, physical atomic replace, separate process restart and recovery of journal. No Notion write.
- R175 `r175_spirit_activation_source_precedence.py`: reconciliation of VZ-SANDBOX activations with specialized T9, separating actor category from Spirit effective level and conditional compatibility.
- R176 `r176_checkpoint_audit.py`: classify source-pinned Notion readbacks and compile scoped contract matrix.

## Reproduce with Python 3.11+

```sh
python -m unittest discover -s tests -p 'test_*.py' -v
python runtime/r176_checkpoint_audit.py evidence/R176_VERIFIED_MASTER_NOTION_SNAPSHOT_20261018.json
python -c "import sys;sys.path.insert(0,'runtime');from r174_local_test_transaction import recover;print(recover('evidence/R174_DURABLE_LOCAL_DEMO/state.json','evidence/R174_DURABLE_LOCAL_DEMO/evidence.sqlite','evidence/R174_DURABLE_LOCAL_DEMO/intent_plan.json'))"
```

A clean extraction has no need for network or secrets. Existing sqlite demo proves only a local mock boundary, not native Notion completion. Validation on a fresh retrieved Notion source is mandatory before new source-bound operations because retrieved version metadata can change.

## Physical continuation

- R155 `3fcc2b324ede8158a6d5c3bfa225e014`: 2/2 mechanical AFTER + journal COMMITTED, marker `INTENT_PREPARED` due to prior security refusal. DO NOT retry marker via alternate API.
- R158 `3fdc2b324ede8132b0ade1735402ba03`: first intent persisted and dispatched, but Native Notion mechanical state BEFORE and 0/9 events applied, blocked by security. No retry.
- R145 target `3fcc2b324ede81868256e6db67ece28e`, version `2026-10-17T12:04:36.271Z`: AWAITING_CONFIRMATION; no human-turn host attestation.
- R129 0/3 BEFORE; R130 B/C committed and D BEFORE E–H PRE; R110/R121 causal HOLD.
- VZ matrix 8/8 source-scoped attribute budgets verified, 0/8 final HP/PA, not canonical assimilations. New R175 finding: 6/8 compatibility duration conditional proof missing, 2/8 actor category not uniquely deducible.

## Non-goals and risks

This package contains no interface to write Party, no alternative Notion API after refusal, no live service credentials, no authoritative host signature, no independent external audit, no native block UUID ownership, and no claim of universal atomic CAS. A plausible local receipt or self-asserted `trusted` flag cannot elevate to a production commit. Local SQL data is durable but a malicious actor with write access could recompute an unkeyed SHA chain; it is not a platform attestation.
