"""Reopen durable ledger against a manually supplied *native* Notion readback.
Notion native fetch must be obtained by host first; no network, no signing.
"""
from pathlib import Path
import json,sys,sqlite3,hashlib
HERE=Path(__file__).parent
sys.path[:0]=[str(HERE),str(HERE/'baseline'/'runtime')]
from r177_native_gateway import CanaryPlan,NativeSnapshot
from r179_native_reconciliation import reconcile_observed
from r173_sqlite_causal_ledger import Ledger
id='3fdc2b324ede81a0954cda5efe2fccaa';tx='IBX17-R177-NATIVE-LEDGER-CANARY-20261018-01'
plan=CanaryPlan(tx=tx,stage='DOC_CANARY',target=id,source_version='IBX17-R177-DOC-BRIDGE@2026-10-18',pre_version='2026-10-18T15:04:31.327Z',old_literal='BRIDGE_PHYSICAL: BEFORE',new_literal='BRIDGE_PHYSICAL: AFTER')
# Literal source is from 2026-10-18T15:06:15.211Z Notion fetch in this turn.
readback=NativeSnapshot(page_id=id,parent_id='3fbc2b324ede804a95fafcb7b293c92c',page_version='2026-10-18T15:06:15.211Z',content='BRIDGE_PHYSICAL: AFTER\nBRIDGE_JOURNAL: COMMITTED_AFTER_NATIVE_READBACK; tx='+tx+'; stage=DOC_CANARY; after_sha=1ed018467e285ffa8f89cbbfcfa79d8383529dbb64bf7e87dfe4096dd8abceaf; reply_observed=yes; reviewed=SELF_REVIEW_ONLY; no_CAS\nBRIDGE_SENTINEL: PRESERVE_THIS_CONTENT')
with Ledger(HERE/'evidence/r177_native_bridge.sqlite') as l:
 integrity=l.db.execute('PRAGMA integrity_check').fetchone()[0]
 chain=l.verify_chain(tx,'DOC_CANARY')
 classified=l.classify(tx,'DOC_CANARY')
 assert chain['observations']==5 and integrity=='ok'
result=reconcile_observed(plan,str(HERE/'evidence/r177_native_bridge.sqlite'),readback)
assert result['decision']=='DOCUMENTARY_TEST_APPLIED_JOURNAL_READBACK_SELF_REVIEW'
output={'tx':tx,'source_notional_page':'https://app.notion.com/p/'+id,'last_live_readback_version':readback.page_version,
'ledger_chain_head':chain['chain_head'],'ledger_obs':chain['observations'],'sqlite_integrity_check':integrity,
'classification':classified,'reconciler':result,'readback':{'physical':'AFTER','journal':'COMMITTED_AFTER_NATIVE_READBACK','sentinel':True,'parent_lab':True,'terminal':'NOT_CERTIFIED'},
'calls':{'create_page':1,'persist_remote_intent':1,'write_documentary_effect':1,'write_journal':1,'failed_writes':0,'mechanical_levelup_writes':0},
'native_request_id':None,'replay_allowed':False,'readback_source_class':'EXECUTOR_NATIVE_CONNECTED_FETCH_SELF_REVIEW_NOT_CRYPTOGRAPHIC_HOST_ATTESTATION',
'production_authority':False,'party_writes':0}
(HERE/'evidence/r177_native_canary_audit.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'ledger_integrity':integrity,'chain_obs':chain['observations'],'decision':result['decision'],'source_version':readback.page_version},ensure_ascii=False))
