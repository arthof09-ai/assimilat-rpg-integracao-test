#!/usr/bin/env python3
"""R049: compiler of reversible READ-ONLY, Mestre-only plans. NO Notion writer, NO VLAB engine."""
import json,zipfile,math,itertools,hashlib,pathlib,csv,unittest
ROOT=pathlib.Path(__file__).parent
R048=ROOT/'r048/r048_orc_25_niveis_TEST_nao_aplicado.json'
P45=pathlib.Path('/mnt/data/levelup_R048_sources/LEVELUP_ORC_ALMA_R045_BALANCEAMENTO_SEGURO_TEST_20261024.zip')
with zipfile.ZipFile(P45) as z:
  SRC=json.loads(z.read('orc_pa_r040_evidence.json'))['matrix_25_levels_400_slots']
R=json.loads(R048.read_text())
# Subjective ordinal weights to choose options, NOT damage benchmark, independent of old R048 weights.
# Priority: base armor+axe retained, precision and physical support, then situational actions.
WEIGHT={3:9,4:8,9:10,5:5,6:4,7:2,8:3,11:3,12:2,13:1}
# Daily cost quoted by existing 25 TEST pages; power claims and FIP still need VLAB.
MODES=['A_EXISTING_ONLY','B_INT_CONDITIONAL_TACTICAL','C_INT_CONDITIONAL_RESERVE']
OUT=[]
for old,row in zip(SRC,R):
 n=row['n'];rank=row['rank']; gross=row['PA_bruto_fisico'];slots={s['slot']:s for s in old['slots']}
 assert n==old['level'] and rank==old['rank_personagem'] and old['total_diario']==row['PA_dia_fisico']
 energized={i for i,s in slots.items() if s['on']};assert {1,2} <= energized
 available=sorted(energized-{1,2,10})
 scenarios=[]
 for pattern in itertools.product((False,True),repeat=len(available)):
  sel={1,2}|{v for v,on in zip(available,pattern) if on}
  old_cost=sum(slots[k]['pa_dia_publicado'] for k in sel)
  # Reserve for T9/one chosen spiritual technique/axe extra in another LEGAL moment.
  effects=row['t9']+row['tecnica']+row['ruptura_por_uso']
  remained=gross-old_cost-effects
  if remained>=0:
   utility=sum(WEIGHT.get(k,0) for k in sel)
   scenarios.append({'slots':sorted(sel),'old_cost':old_cost,'remain':remained,'utility':utility})
 assert scenarios, ('impossible before INT',n)
 # Baseline real equipment only: maximise useful power while keeping enough soul to afford one more spiritual technique.
 # This is a functional safety buffer, NOT forced 25% or 10%.
 eligible=[s for s in scenarios if s['remain']>=row['tecnica']]
 if not eligible: eligible=scenarios
 a=max(eligible,key=lambda s:(s['utility'],s['remain'], -s['old_cost']))
 def config(s,intcost=0):
  on=set(s['slots']);cost=s['old_cost']+intcost
  # Note 'INT' is an extra slot/item family, never silently inserted into S10 nor acquired.
  return {'slots_on_existing':s['slots'],'slots_off_existing':sorted(energized-on),
    'still_in_inventory_slots':list(range(1,17)),
    'paid_existing_daily':s['old_cost'],'conditional_new_int_daily':intcost,'total_new_daily':cost,
    'free_before_activations':gross-cost,
    'free_after_T9_spiritual_and_rupture_separately':gross-cost-row['t9']-row['tecnica']-row['ruptura_por_uso'],
    'percent_after':round((gross-cost-row['t9']-row['tecnica']-row['ruptura_por_uso'])*100/gross,2),
    'heuristic_available_capability':s['utility'],
    'lost_conditional_equipment': [slots[x]['item'] for x in sorted(energized-on)],
    'all_new_item_changes_hold':bool(intcost),
    'notion_applied':False,'vlab_verified':False}
 b0=row['perfil_tatico'];c0=row['perfil_reserva'];p=row['novo_item_int']
 def imported(m):
  on=set(m['itens_ja_existentes_energizados'])
  return config({'slots':sorted(on),'old_cost':sum(slots[k]['pa_dia_publicado'] for k in on),
               'utility':sum(WEIGHT.get(k,0) for k in on)},p['custo_pa_dia_TEST'])
 b=imported(b0);c=imported(c0)
 # current active configuration in same arithmetic for comparison only
 current_cost=old['total_diario'];current_rem=gross-current_cost-row['t9']-row['tecnica']-row['ruptura_por_uso']
 # Bronze transform prohibited; 0 means no T9. Actual action legality never inferred.
 OUT.append({'n':n,'rank':rank,'page_id':row['page_id'],'url':row['url'],
  'before_live_check':'NOTION R216-P14 STILL UNMODIFIED 2026-10-24, last edit from live recheck',
  'original_gross':gross,'original_daily':current_cost,'original_free_before_activation':gross-current_cost,
  'original_after_three_cost_events':current_rem,'costs':{'T9':row['t9'],'spiritual_test_prospective':row['tecnica'],'rupture_test':row['ruptura_por_uso']},
  'int_proposal':p,'A_existing_only':config(a,0),'B_conditional_int_tactical':b,'C_conditional_int_reserve':c,
  's10_current_amuleto_da_forja_status':{'old_energy_on':slots[10]['on'],'old_maintenance':slots[10]['pa_dia_publicado'],
     'existing_effect':'INT temporaria limitada a Alquimia/Inscricoes, não substitui +INT geral'},
  'writer_status':'RED - NENHUMA ALTERAÇÃO FÍSICA','strongest_verified_claim':'orçamento aritmético apenas; origem CRAFT/VLAB HOLD',
  'patches':{'A_ONLY_EXISTING_ITEMS':{'description':'DESENERGIZAR (nunca apagar item) e atualizar PA/dia e PA livre; conditional on GREEN only',
    'energy_off':config(a)['slots_off_existing'], 'energy_on':config(a)['slots_on_existing'],
    'summary_before':{'PA_bruto':gross,'PA_diario':current_cost,'PA_livre':gross-current_cost},
    'summary_after_preview':{'PA_bruto':gross,'PA_diario':a['old_cost'],'PA_livre':gross-a['old_cost']}},
    'B_OR_C':{'description':'MESMO PLANO, mas só após prova de item +INT, RE/RN/RI, posse, slot, custo, writer GREEN, VLAB; nunca inventar item na mochila'}}})
(ROOT/'R049_ORC_25_PLANOS_FISICOS_SEM_WRITE_MESTRE_ONLY_TEST.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2),encoding='utf8')
with (ROOT/'R049_ORC_25_RESUMO_TEST.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['N','Rank','Alma gross real','Custo atual real','Saldo atual apos eventos hipoteticos','A custo/dia existing-only','A saldo apos eventos','A slots ON','B custo/dia cond INT','B saldo apos eventos','C custo/dia cond INT','C saldo apos eventos','Bonus INT proposto','Custo INT prosp.','Notion modificado?'])
 for r in OUT:
  a=r['A_existing_only'];b=r['B_conditional_int_tactical'];c=r['C_conditional_int_reserve']
  w.writerow([r['n'],r['rank'],r['original_gross'],r['original_daily'],r['original_after_three_cost_events'],a['total_new_daily'],a['free_after_T9_spiritual_and_rupture_separately'],','.join(map(str,a['slots_on_existing'])),b['total_new_daily'],b['free_after_T9_spiritual_and_rupture_separately'],c['total_new_daily'],c['free_after_T9_spiritual_and_rupture_separately'],r['int_proposal']['bonus_int'],r['int_proposal']['custo_pa_dia_TEST'],'NÃO'])
print('NUMLVLS',len(OUT));print('OLD NEGATIVE',sum(r['original_after_three_cost_events']<0 for r in OUT),'A >0',sum(r['A_existing_only']['free_after_T9_spiritual_and_rupture_separately']>0 for r in OUT));print('A/B/C compact:')
for r in OUT:
 print('N%02d %-11s old%d A%d B%d C%d offA=%s'% (r['n'],r['rank'],r['original_after_three_cost_events'],r['A_existing_only']['free_after_T9_spiritual_and_rupture_separately'],r['B_conditional_int_tactical']['free_after_T9_spiritual_and_rupture_separately'],r['C_conditional_int_reserve']['free_after_T9_spiritual_and_rupture_separately'],r['A_existing_only']['slots_off_existing']))
