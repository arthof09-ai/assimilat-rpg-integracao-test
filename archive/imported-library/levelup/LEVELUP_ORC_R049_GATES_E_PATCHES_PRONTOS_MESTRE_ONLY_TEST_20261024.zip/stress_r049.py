"""Static sensitivity ONLY. Never feeds actual combat engine or writes Notion."""
import json,pathlib,csv,math
R=pathlib.Path(__file__).parent
D=json.loads((R/'R049_ORC_25_PLANOS_FISICOS_SEM_WRITE_MESTRE_ONLY_TEST.json').read_text())
S=[]
for d in D:
 base=d['int_proposal']['custo_pa_dia_TEST']
 r={'n':d['n'],'rank':d['rank'],'int_base':base,'soul_from_rings_assumed_in_normal':100}
 for key,name in [('A_existing_only','A'),('B_conditional_int_tactical','B'),('C_conditional_int_reserve','C')]:
  m=d[key];remain=m['free_after_T9_spiritual_and_rupture_separately'];r[name+'_base']=remain
  if name!='A':
   for pct in (25,50,100):
    r[f'{name}_int_cost_plus_{pct}pct']=remain-math.ceil(base*pct/100)
   r[name+'_if_RINGS_DONT_PERSIST_HYPOTHESIS']=remain-100
 S.append(r)
(R/'R049_STRESS_INT_PRESUPPOSTOS_25.json').write_text(json.dumps(S,ensure_ascii=False,indent=2),encoding='utf8')
for tag in ['B','C']:
 for k in ['base','int_cost_plus_25pct','int_cost_plus_50pct','int_cost_plus_100pct','if_RINGS_DONT_PERSIST_HYPOTHESIS']:
  col=tag+'_'+k
  print(col, 'nonnegative',sum(x[col]>=0 for x in S),'of 25','min',min(x[col] for x in S))
