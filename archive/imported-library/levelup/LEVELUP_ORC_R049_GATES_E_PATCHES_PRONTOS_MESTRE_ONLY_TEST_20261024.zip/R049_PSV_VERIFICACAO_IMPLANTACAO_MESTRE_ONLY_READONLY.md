# PSV — LEVEL-UP / R049 — CORREÇÃO FÍSICA PREPARADA, NÃO EXECUTADA

**Classificação: MESTRE-SIDE ONLY · laboratório TEST · READ-ONLY.** 24/10/2026.

## 0. Resultado do trabalho efetivo

- **25/25 fichas originais do Orc Notion reabertas e confrontadas**: R216-P14, Bronze1–Lendário5. Elas continuam com a manutenção e o PA livre ANTES da correção; nenhuma modificação física foi aplicada.
- **0/25 fichas alteradas; 0/5 novos itens de INT adquiridos/criados fisicamente; 0/20 ativações T9 homologadas no VLAB.** O resultado não é promoção PROD.
- Último checkpoint canônico verificado: **IBX17-R216-P23-045**, com Inbox IBX-114 sincronizada até P23-045. As auditorias R046–R048 ainda são artefatos locais, não prova de patches persistidos.
- **Permissão material RED/UNKNOWN:** nem na OP, Inbox, Registry/Central ou Lab foi demonstrado, para esta instância e domínio, pacote válido de `CURRENT-WRITER-ID` + `WRITER-EPOCH` + `LEASE-TOKEN` + `BLOCK-PERMIT GREEN` + fencing/takeover. A ferramenta Notion de edição disponível não é concessão desse pacote. Conforme NAC-CONT-03/U-SUCCESSION e microblock, a execução física **para em READ-ONLY**. A ordem do Mestre autoriza o objetivo, não prova exclusividade técnica do escritor.
- **30/30 testes R049 PASS**, **18/18 testes R048 PASS**, **36/36 testes R044–R045 PASS**, todos reexecutados nesta rodada e independentes de VLAB/Notion-write. Total **84/84 assertions de suíte**; a prova cobre matemática, integridade, conservação de slots e regressão local, não combate.
- O painel offline Android inclui os 25 níveis e três perfis, sem gravação externa/Notion.

## 1. Escopo do modelo e semântica de gasto

O orçamento da auditoria usa **Alma bruta NORMAL documentada**, incluindo dois Anéis da Alma já presentes (+100 no agregado, sem duplicar), menos manutenção do loadout, menos o custo T9 quando elegível, menos uma técnica espiritual de classe, menos um uso legal de Ruptura do Machado em **outro momento válido**. Bronze tem custo T9 ZERO apenas por representar VETO DE TRANSFORMAÇÃO; não é uma ativação gratuita.

**Não é prova de legalidade temporal**: T9 Prata consome Ação Completa, Ouro Padrão, Ouro Negro Movimento e Lendário Livre, com rolagem de duração e T9-A. A técnica e Ruptura podem não caber na mesma duração. PA futuro da T6-B só após transformação válida; não paga antecipadamente T9. INT externa não concede Alma retroativa. A reconfiguração deve valer antes do compromisso diário, nunca ressarcir manutenção já consumida durante uma cena. Retenção dos anéis e compatibilidade anatômica continuam HOLD.

## 2. Resultado da otimização em três perfis

**A — SOMENTE ITENS EXISTENTES:** 25/25 saldos aritméticos positivos. Não inclui bônus de INT geral não possuído. Fichas usam as peças S01 Couraça e S02 Machado, preservam os 16 slots existentes e desligam apenas uma seleção de acessórios (sem apagar item do inventário). Custo/uso de habilidades secundárias não vira passivo. A decisão sobre preservação de poder é heurística, não teste do VLAB.

**B — INT CONDICIONAL TÁTICA (R048):** 25/25 saldos positivos incluindo custo TEST de um item de INT especializada em cada faixa: Bronze +3/15PA-dia; Prata +6/30; Ouro +10/50; Ouro Negro +16/80; Lendário +25/125. Só Bronze +3/15 tem referência direta no catálogo como Amplificador de Atributo; mesmo esse **não foi comprovadamente adquirido pelo Orc**. O conjunto das variantes propostas é RASCUNHO TEST, não cinco itens canonizados. +25 L referencia Grimório lendário real, sem copiar magias/passivos nem atribuí-lo ao Orc.

**C — INT CONDICIONAL RESERVA (R048):** 25/25 saldos positivos, 23/25 alcançam ≥25% (meta opcional). Perde ainda mais opções táticas por desenergizamento. Não demonstrar como build universal superior.

A escala estimada é função de atributos especializados (5 PA/dia por +1), não de preço nem só do piso por rank. Rank do ITEM distinto do rank do EFEITO, conforme Atlas. Amuleto da Forja original S10 confere apenas INT temporária restrita a Alquimia/Inscrições e precisa de ação/PA por uso; não se transforma silenciosamente em bônus permanente de INT geral.

### 2.1 Níveis críticos — saldos reais e hipotéticos

| Nível | PA bruto | PA/dia ATUAL | PA livre ATUAL | PA após T9+técnica+Ruptura no FULL, hipotético | A custo/dia → PA após eventos | B custo/dia → PA após eventos | C custo/dia → PA após eventos |
|---|---:|---:|---:|---:|---|---|---|
| N06 Prata | 216 | 179 | 37 | -22 | 137 → 20 | 134 → 23 | 103 → 54 |
| N11 Ouro | 367 | 309 | 58 | -60 | 216 → 33 | 203 → 46 | 143 → 106 |
| N16 Ouro Negro | 578 | 475 | 103 | -113 | 295 → 67 | 300 → 62 | 185 → 177 |
| N21 Lendário | 891 | 810 | 81 | -319 | 360 → 131 | 395 → 96 | 305 → 186 |
| N24 Lendário | 1008 | 356 | 652 | 252 | 335 → 273 | 460 → 148 | 347 → 261 |

N06: somente peças existentes perfil A desenergiza **S07, S10 e S13**, custo diário **179→137**, PA livre antes de ativação **37→79** e PA após três gastos hipotéticos **−22→+20**. Versão B com +6 INT adicional TEST tem custo 134/dia e saldo 23; versão C 103/dia e saldo 54, ambas dependem de item/proveniência/slot.

N21: somente peças existentes A mantém S01, S02, S03 e S09, desenergiza S04–S08: manutenção **810→360**, PA livre **81→531** e orçamento hipotético pós três gastos **−319→+131**. B mantém S01, S02, S09 e +25 INT TEST: manutenção395, saldo96. C mantém S01,S02 e +25 INT: manutenção305, saldo186. Desenergização de S03/S04/S09 implica perda de poderes condicionais concretos; não chamar de sem enfraquecimento.

## 3. Sensibilidade: custo de INT e integridade dos Anéis

- Ao inflacionar **+50% o custo estimado das peças de INT**, os perfis B/C ainda são >=0 em **25/25** somente para o orçamento contábil hipotético.
- Dobrar totalmente o custo das peças de INT reduz o perfil B para **17/25** casos não negativos; no perfil C, **25/25** permanecem não negativos, à custa de mais acessórios desligados.
- Cenário adversarial **puramente hipotético** de perda dos +100 PA dos Anéis quando relevantes à cena: 4/25 casos B e 14/25 casos C não negativos; a retenção real dos Anéis não está comprovada. Não afirmar que o sistema remove anéis — investigar VLAB/forma/slots.
- Dreno adicional de 100/200 PA não é morte automática nem a mesma coisa que simples saldo zero. O teste de combate depende do VLAB nativo.

## 4. Matriz pronta para implementação com canários (AINDA NÃO APLICAR)

**Canário N06**: checar `page_id` e last-edited atuais contra `R049_CHECAGEM_NOTION_25_TIMESTAMP_TEST.json`; confirmar identidade/controle GREEN; snapshot completo e blocos S07/S10/S13; alterar SOMENTE estado energético de cada peça e derivados de manutenção/PA, preservando item na mochila/alternante; readback visual e mecânico de N06. A versão A existente não requer inventar item novo. Para testar B/C, requer previamente proveniência de item +6 INT, slot, RI/RE/FIP, custo e posse.

**Canário N21**: depois do GREEN revalidado e N06 aceito, conferir variante L, S01/S02/S03/S09 e seus efeitos, T9=320 e técnica real escolhida. Não presumir INT +25 adquirida. Não afirmar que Ruptura + técnica cumulam no mesmo ataque. Desenergizar conforme perfil aprovado; readback, VLAB e reconciliação.

**25 níveis**: usar `R049_ORC_25_PLANOS_FISICOS_SEM_WRITE_MESTRE_ONLY_TEST.json`: cada entrada tem URI da página EXISTENTE, valores antes, seleção de slots, valores esperados depois, itens desligados, limites explícitos. Nunca editar múltiplas páginas a partir de JSON somente sem reabrir preimage e CHECKIN/BLOCK-PERMIT por microbloco. Todas as variantes INT permanecem `all_new_item_changes_hold=true` até evidência de item real.

**CONTENT-GUARD:** Alterações de ficha apenas dados de jogo, sem log de execução/Diário no corpo das fichas. Diário/Inbox para registros quando writer documental competente e controle válido. Nenhuma Party ou O Primeiro editada ou exposta.

## 5. Gate de aceitação e continuação (NAC-PASS-02)

- CANÔNICO: OP P23-045. Não afirmar que R049 foi escrito no Notion. Tabela de 25 reaberturas é levantamento independente desta rodada, não checkpoint persistido.
- FIRST-PENDING: **writer/epoch/lease/token/fence/`BLOCK-PERMIT GREEN` legítimos para DOMAIN LEVEL-UP**, seguido da prova de propriedade/custo dos itens novos e escolha tática homologada.
- NEXT após GREEN: preimage e **canário N06 somente peças existentes**, releitura, VLAB; canário N21; depois microblocos até 25, mantendo os itens de INT condicionais até aquisição/canonização. Caso o canário falhe, STOP localizado/rollback usando preimage.
- NO-REPEAT: 400 RI/RE/FIP já anotados, Ficha Base original, 25 páginas válidas existentes, motor PA, motor VLAB, Party/O Primeiro, cópias históricas P12/P13 e passes R040–R048.
- Estado terminal nesta rodada: **READ-ONLY R049 VERIFICADO / FÍSICO HOLD / ITENS INT HOLD / VLAB HOLD / NAC-PASS MATERIAL NÃO APLICÁVEL**.

## 6. Fonte de evidência

- [Diário OP original IBX-17](https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107) e [Inbox IBX-114](https://app.notion.com/p/3ffc2b324ede81aab557fd267efc02ce).
- [25 fichas atuais do Orc TEST](https://app.notion.com/p/400c2b324ede8137a06bff45c3b5b1bb).
- [Atlas Canônico de Poder](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab).
- [Sistema de Transformação Espiritual](https://app.notion.com/p/3f2c2b324ede81c0ae0ee4e66212edc9).
- [Amplificador de Atributo](https://app.notion.com/p/3c6c2b324ede82baa4a801de533a5975) +3 em um atributo, 15 PA/dia, posse não demonstrada.
- [Grimório Lendário do Arcanista Proibido](https://app.notion.com/p/ed0c2b324ede8335b533810ceb462896) +25 INT com outras habilidades; NÃO está no inventário do Orc.
- [Armadura de Zephyr L](https://app.notion.com/p/a23c2b324ede829bb8168165991577ff) +15 DES com outros efeitos, precedência para avaliar custo composto sem inferir tarifa exata.

Este dossiê é um PLANO DE PATCHES TESTADO, não alteração efetuada; seu resultado comprovado é o arquivo de diffs reversíveis e sua integridade, somado às 25 releituras físicas.
