import unittest,json,math,pathlib,zipfile
R=pathlib.Path(__file__).parent
D=json.loads((R/'R049_ORC_25_PLANOS_FISICOS_SEM_WRITE_MESTRE_ONLY_TEST.json').read_text())
with zipfile.ZipFile('/mnt/data/levelup_R048_sources/LEVELUP_ORC_ALMA_R045_BALANCEAMENTO_SEGURO_TEST_20261024.zip') as z:
 SRC=json.loads(z.read('orc_pa_r040_evidence.json'))['matrix_25_levels_400_slots']
class R049(unittest.TestCase):
 def test_pages_25(self):self.assertEqual(len(D),25)
 def test_identical_target_set(self):self.assertEqual({d['n'] for d in D},set(range(1,26)))
 def test_no_target_duplicates(self):self.assertEqual(len({d['page_id'] for d in D}),25)
 def test_16_slots_all(self):self.assertEqual(sum(len(s['slots']) for s in SRC),400)
 def test_old_energy_total_consistent(self):
  for d,src in zip(D,SRC):
   self.assertEqual(sum(s['pa_dia_publicado'] for s in src['slots'] if s['on']),d['original_daily'])
 def test_old_gross_vs_free(self):
  for d in D:self.assertEqual(d['original_free_before_activation'],d['original_gross']-d['original_daily'])
 def test_modes_present(self):
  for d in D:self.assertEqual(set(k for k in d if k.startswith(('A_existing','B_conditional','C_conditional'))),{'A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve'})
 def test_just_real_items_in_A(self):
  for d,src in zip(D,SRC):
   original={s['slot'] for s in src['slots'] if s['on']}
   a=d['A_existing_only'];self.assertEqual(a['conditional_new_int_daily'],0)
   self.assertTrue(set(a['slots_on_existing'])<=original)
 def test_non_destructive_no_slot_delete(self):
  for d in D:
   for k in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    self.assertEqual(d[k]['still_in_inventory_slots'],list(range(1,17)))
 def test_keep_armor_axe_all(self):
  for d in D:
   for k in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    self.assertTrue({1,2} <= set(d[k]['slots_on_existing']))
 def test_off_equals_delta_energy(self):
  for d,src in zip(D,SRC):
   original={s['slot'] for s in src['slots'] if s['on']}
   for k in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    self.assertEqual(original-set(d[k]['slots_on_existing']),set(d[k]['slots_off_existing']))
 def test_S10_restricted_not_counted_as_generic_INT(self):
  for d in D:
   for k in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    self.assertNotIn(10,d[k]['slots_on_existing'])
 def test_A_positive_all(self):
  for d in D:self.assertGreater(d['A_existing_only']['free_after_T9_spiritual_and_rupture_separately'],0)
 def test_B_positive_all(self):
  for d in D:self.assertGreater(d['B_conditional_int_tactical']['free_after_T9_spiritual_and_rupture_separately'],0)
 def test_C_positive_all(self):
  for d in D:self.assertGreater(d['C_conditional_int_reserve']['free_after_T9_spiritual_and_rupture_separately'],0)
 def test_mode_cost_identity(self):
  for d,src in zip(D,SRC):
   paid={s['slot']:s['pa_dia_publicado'] for s in src['slots']}
   for key in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    m=d[key]
    self.assertEqual(sum(paid[s] for s in m['slots_on_existing']),m['paid_existing_daily'])
    self.assertEqual(m['paid_existing_daily']+m['conditional_new_int_daily'],m['total_new_daily'])
 def test_effect_budget_equation(self):
  for d in D:
   effect=sum(d['costs'].values())
   for key in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    m=d[key];self.assertEqual(d['original_gross']-m['total_new_daily']-effect,m['free_after_T9_spiritual_and_rupture_separately'])
 def test_no_bronze_transform(self):
  for d in D[:5]:self.assertEqual(d['costs']['T9'],0)
 def test_demon_eligible_20(self):
  for d in D[5:]:self.assertGreater(d['costs']['T9'],0)
 def test_soul_only_preparation_no_int_ownership(self):
  for d in D:
   self.assertIn('HOLD',d['int_proposal']['origem_posse'])
   self.assertTrue(d['B_conditional_int_tactical']['all_new_item_changes_hold'])
 def test_no_notional_writes(self):
  for d in D:
   self.assertEqual(d['writer_status'],'RED - NENHUMA ALTERAÇÃO FÍSICA')
   for m in ['A_existing_only','B_conditional_int_tactical','C_conditional_int_reserve']:
    self.assertFalse(d[m]['notion_applied']);self.assertFalse(d[m]['vlab_verified'])
 def test_l21_3_scenarios(self):
  d=D[20];self.assertEqual(d['original_gross'],891)
  self.assertEqual(d['original_after_three_cost_events'],-319)
  self.assertEqual(d['A_existing_only']['free_after_T9_spiritual_and_rupture_separately'],131)
  self.assertEqual(d['B_conditional_int_tactical']['free_after_T9_spiritual_and_rupture_separately'],96)
  self.assertEqual(d['C_conditional_int_reserve']['free_after_T9_spiritual_and_rupture_separately'],186)
 def test_two_soul_rings_already_budgeted(self):
  for d in D:self.assertGreater(d['original_gross'],100)
 def test_expected_branches_level6(self):
  d=D[5];self.assertEqual((d['original_after_three_cost_events'],d['A_existing_only']['free_after_T9_spiritual_and_rupture_separately'],d['B_conditional_int_tactical']['free_after_T9_spiritual_and_rupture_separately'],d['C_conditional_int_reserve']['free_after_T9_spiritual_and_rupture_separately']),(-22,20,23,54))
 def test_own_batch_patch_correct(self):
  for d in D:
   a=d['A_existing_only'];p=d['patches']['A_ONLY_EXISTING_ITEMS']
   self.assertEqual(p['summary_before']['PA_diario'],d['original_daily'])
   self.assertEqual(p['summary_after_preview']['PA_diario'],a['paid_existing_daily'])
   self.assertEqual(p['summary_after_preview']['PA_livre'],d['original_gross']-a['paid_existing_daily'])
 def test_writes_stay_bounded(self):
  for d in D:self.assertNotIn('http://',d['page_id']);self.assertIn('https://app.notion.com',d['url'])
 def test_live_recheck_count_25(self):
  m=json.loads((R/'R049_CHECAGEM_NOTION_25_TIMESTAMP_TEST.json').read_text())
  self.assertEqual(len(m['last_edited_at_by_level']),25)
  self.assertEqual({int(x) for x in m['last_edited_at_by_level']},set(range(1,26)))
  self.assertEqual(m['updated_page_count'],0)
 def test_stress_int_50_percent(self):
  s=json.loads((R/'R049_STRESS_INT_PRESUPPOSTOS_25.json').read_text())
  self.assertTrue(all(row['B_int_cost_plus_50pct']>=0 and row['C_int_cost_plus_50pct']>=0 for row in s))
 def test_stress_int_100_percent_reserve(self):
  s=json.loads((R/'R049_STRESS_INT_PRESUPPOSTOS_25.json').read_text())
  self.assertTrue(all(row['C_int_cost_plus_100pct']>=0 for row in s))
  self.assertTrue(any(row['B_int_cost_plus_100pct']<0 for row in s))
 def test_rings_conditional_risk_not_falsified(self):
  s=json.loads((R/'R049_STRESS_INT_PRESUPPOSTOS_25.json').read_text())
  self.assertTrue(any(row['C_if_RINGS_DONT_PERSIST_HYPOTHESIS']<0 for row in s))
if __name__=='__main__':unittest.main()
