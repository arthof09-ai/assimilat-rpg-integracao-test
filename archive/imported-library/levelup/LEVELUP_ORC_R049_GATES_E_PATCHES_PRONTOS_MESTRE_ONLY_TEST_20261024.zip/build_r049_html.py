import pathlib,html,json
ROOT=pathlib.Path(__file__).parent
D=json.loads((ROOT/'R049_ORC_25_PLANOS_FISICOS_SEM_WRITE_MESTRE_ONLY_TEST.json').read_text())
# Avoid literal script end sequence in embedded JSON.
raw=json.dumps(D,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
page=r'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Orc R049 | Prévia operacional Mestre-only</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Roboto,'Segoe UI',sans-serif;}
*{box-sizing:border-box}body{background:#0b111b;color:#f0f3fa;margin:0;line-height:1.45}main{margin:auto;max-width:960px;padding:16px}
h1{font-size:1.55rem;line-height:1.2;margin:10px 0}h2{font-size:1.18rem;margin-top:24px}p{color:#b4c1d2}
.muted{color:#b4c1d2;font-size:.88rem} .banner{border:1px solid #8e722a;background:#2b240e;color:#ffeab7;padding:12px;border-radius:9px;margin:15px 0}
.controls{display:flex;flex-wrap:wrap;gap:10px;align-items:end;padding:12px;background:#152033;border-radius:9px}
label{display:block;color:#b4c1d2;font-size:.9rem;margin-bottom:5px}select,button{background:#293956;color:white;border:1px solid #536685;border-radius:7px;padding:10px;font-size:1rem}button.selected{background:#256f80;border-color:#51b7c4}button{cursor:pointer;flex:1;min-width:130px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:10px;margin:14px 0}
.box{padding:13px;background:#16243a;border:1px solid #324566;border-radius:9px}.value{font-size:1.8rem;font-weight:750;letter-spacing:-.04em}.sub{color:#b4c1d2;font-size:.82rem}
.good{color:#78d5ac}.warn{color:#ffce75}.bad{color:#ff8c8c}details{background:#172337;border:1px solid #334762;border-radius:9px;padding:10px;margin:10px 0}
summary{cursor:pointer;font-weight:700}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{border-bottom:1px solid #304157;padding:7px;text-align:left;white-space:nowrap;font-size:.87rem}th{background:#1d2e47} .scroll{overflow-x:auto}
a{color:#86c6ff} .pill{display:inline-block;background:#523e1c;border:1px solid #886b2c;color:#ffdc9b;border-radius:100px;padding:4px 10px;font-size:.75rem}
</style></head><body><main>
<div class="pill">MESTRE-ONLY • R049 • TEST / READ-ONLY</div><h1>Orc — prévia de Alma e equipamentos</h1>
<p>Três alternativas verificadas por cálculo para os 25 níveis. Não modifica o Notion, não comprova posse de item novo e não executa o VLAB.</p>
<div class="banner"><b>0 de 25 fichas editadas.</b> Escrita em HOLD por ausência de writer/epoch/lease/BLOCK-PERMIT GREEN. Perfil B/C requer item de INT ainda não demonstrado como adquirido. As técnicas e a Ruptura são consumos separados em momentos válidos.</div>
<div class="controls"><div><label for="lvl">Classificação e nível</label><select id="lvl" aria-label="Nível"></select></div><button id="mA" class="selected">A — itens existentes</button><button id="mB">B — INT tático (condicional)</button><button id="mC">C — INT reserva (condicional)</button></div>
<h2 id="who">Nível</h2><div class="cards"><div class="box"><div class="sub">Alma bruta existente</div><div class="value" id="gross">—</div></div><div class="box"><div class="sub">Manutenção ATUAL</div><div class="value" id="current">—</div></div><div class="box"><div class="sub">Manutenção PROPOSTA</div><div class="value" id="proposed">—</div></div><div class="box"><div class="sub">Saldo após T9, técnica e Ruptura</div><div class="value" id="after">—</div><div class="sub" id="percentage"></div></div></div>
<div class="box"><strong>Resumo do perfil</strong><div id="details"></div><p id="note" class="muted"></p><a id="card" target="_blank" rel="noreferrer">Abrir ficha existente no Notion</a></div>
<details open><summary>Comparar os 25 níveis</summary><div class="scroll"><table><thead><tr><th>Nível</th><th>Rank</th><th>Atual após</th><th>A após</th><th>B após</th><th>C após</th><th>INT TEST</th></tr></thead><tbody id="tbl"></tbody></table></div></details>
<details><summary>O que significa o saldo?</summary><p>Conta: Alma bruta publicada menos manutenção do perfil, custo T9, uma técnica espiritual e Ruptura em evento legal distinto. É um orçamento teórico, não garantia de ações caberem na duração da transformação nem combate homologado.</p><p>O Bronze não recebe T9. Dois Anéis da Alma já estão somados no bruto (100 PA). Não há ganho retroativo de Alma por INT de equipamento. O Amuleto da Forja permanece restrito a teste preparado de Alquimia/Inscrições, não equivale a bônus geral de INT.</p></details>
<p class="muted">Fonte: LEVEL-UP/IBX-17, fichas R216-P14 reabertas, pacote R045 e matriz R048. Próxima ação material: provar writer GREEN e fazer canário N06 → N21 → microblocos. Nenhum segredo foi publicado para a Party.</p>
</main><script>
const DATA=__JSON__;
const selectors={A:'A_existing_only',B:'B_conditional_int_tactical',C:'C_conditional_int_reserve'};
let mode='A';const el=x=>document.getElementById(x);
for(const d of DATA){const op=document.createElement('option');op.value=d.n;op.textContent=`N${String(d.n).padStart(2,'0')} — ${d.rank} ${((d.n-1)%5)+1}★`;el('lvl').appendChild(op)}
function txt(x){return String(x)}
function render(){const d=DATA[Number(el('lvl').value)-1],k=selectors[mode],m=d[k];
 el('who').textContent=`N${String(d.n).padStart(2,'0')} — ${d.rank} ${((d.n-1)%5)+1}★`;
 el('gross').textContent=d.original_gross+' PA';el('current').textContent=d.original_daily+' PA/dia';el('proposed').textContent=m.total_new_daily+' PA/dia';
 el('after').textContent=m.free_after_T9_spiritual_and_rupture_separately+' PA';
 el('after').className='value '+(m.free_after_T9_spiritual_and_rupture_separately>0?'good':'bad');
 el('percentage').textContent=m.percent_after+'% de Alma bruta após os eventos';
 el('details').textContent=`Ativos existentes: ${m.slots_on_existing.join(', ')}. Desenergizar: ${m.slots_off_existing.join(', ')||'nenhum'}. Custo T9: ${d.costs.T9}; técnica: ${d.costs.spiritual_test_prospective}; Ruptura: ${d.costs.rupture_test} PA.`;
 el('note').textContent=mode==='A'?'Só utiliza peças já presentes; efeito real do desenergizamento requer VLAB.':'Hipótese: INT +'+d.int_proposal.bonus_int+' por '+d.int_proposal.custo_pa_dia_TEST+' PA/dia. Item novo NÃO adquirido, NÃO autorizado para aplicação física. Avaliar slot e FIP.';
 el('card').href=d.url;
 for(const z of ['A','B','C']){el('m'+z).className=z===mode?'selected':''}
}
for(const z of ['A','B','C'])el('m'+z).addEventListener('click',()=>{mode=z;render()});el('lvl').addEventListener('change',render);
const tbody=el('tbl');for(const d of DATA){const tr=document.createElement('tr');for(const val of [`N${String(d.n).padStart(2,'0')}`,d.rank,d.original_after_three_cost_events,d.A_existing_only.free_after_T9_spiritual_and_rupture_separately,d.B_conditional_int_tactical.free_after_T9_spiritual_and_rupture_separately,d.C_conditional_int_reserve.free_after_T9_spiritual_and_rupture_separately,'+'+d.int_proposal.bonus_int]){const td=document.createElement('td');td.textContent=val;tr.appendChild(td)}tbody.appendChild(tr)}
el('lvl').value='6';render();
</script></body></html>'''
(ROOT/'R049_ORC_ANDROID_OFFLINE_MESTRE_ONLY_TEST.html').write_text(page.replace('__JSON__',raw),encoding='utf8')
print('HTML bytes:',(ROOT/'R049_ORC_ANDROID_OFFLINE_MESTRE_ONLY_TEST.html').stat().st_size)
