# LEVEL-UP Orc — 28 cenários de validação, sem motor paralelo

**Cenários pendentes de execução no VLAB/nativo.** Resultado é gate esperado, nunca inventar execução. Os dois cenários aritméticos passaram apenas em Python local.

| ID | Cena | Condição observável / invariante | Status |
|---|---|---|---|
| T01 | Ataque comum com Machado | 4/6/8/10/12d6 segundo rank nominal; rolar ataque antes do dano | MOTOR/VLAB HOLD |
| T02 | Ruptura em acerto | PA por uso; +1/2/4/9/16d6; 1/descanso | MOTOR/VLAB HOLD |
| T03 | Ruptura em erro | Nenhum bônus de dano ou cobrança automática de dano | MOTOR/VLAB HOLD |
| T04 | Crítico positivo | Regra de crítico do Sistema de Combate, não 2x automático arbitrário | MOTOR/VLAB HOLD |
| T05 | RD contra arma | Dano bruto separado de pós-RD | MOTOR/VLAB HOLD |
| T06 | Couraça sem encanto | Apenas CA física 14/18/22/26/30; movimento 50% | MOTOR/VLAB HOLD |
| T07 | Encanto da Couraça | CA mágica só durante um ataque declarado e gasto aplicável | MOTOR/VLAB HOLD |
| T08 | Anel da Guarda reação | Uma Reação; 1 ataque declarado | MOTOR/VLAB HOLD |
| T09 | Carapaça concorrente | Não usar simultaneamente com Reação já consumida | MOTOR/VLAB HOLD |
| T10 | Escudo + Machado | Bloquear equipagem de duas mãos com escudo empunhado | MOTOR/VLAB HOLD |
| T11 | Espada + Escudo | Permitido como configuração alternativa, CA escudo continua HOLD | MOTOR/VLAB HOLD |
| T12 | Buff atributo ativo | Aplicar somente durante 2 turnos e PA pago | MOTOR/VLAB HOLD |
| T13 | Buff atributo expirado | Restaurar máximos/FF/testes; não curar ferimentos | MOTOR/VLAB HOLD |
| T14 | INT do Amuleto | Somente teste Alquimia/Inscrições, não CD ED | MOTOR/VLAB HOLD |
| T15 | PA de ativação insuficiente | Recusar ativação sem cobrar efeito/benefício | MOTOR/VLAB HOLD |
| T16 | PA manutenção insuficiente | Não energizar automaticamente peça; reserva 0 | MOTOR/VLAB HOLD |
| T17 | Braçadeiras 1/cena | Sem segundo uso na mesma cena | MOTOR/VLAB HOLD |
| T18 | Capa fora rocha/penumbra | Sem efeito de Furtividade, não regressar para redução dano | MOTOR/VLAB HOLD |
| T19 | Arnês solo firme | 1,5m mitigação por Reação; sem AoO negado | MOTOR/VLAB HOLD |
| T20 | Arnês sem solo | Não aplicar contrato sobre ar ou terreno incompatível | MOTOR/VLAB HOLD |
| T21 | Forma normal/transf. | Retenção anatômica/slots/2 Anéis da Alma exige fonte | MOTOR/VLAB HOLD |
| T22 | T9 custo | N06,N11,N16,N17,N21,N22,N23 possuem déficits de base, sem T9 certificada | MOTOR/VLAB HOLD |
| T23 | Reconfiguração N23→N24 | Não inferir troca física de itens da diferença de 454 PA/dia | MOTOR/VLAB HOLD |
| T24 | Selo de Emergência | Não fornecer Vida temporária nem pagar carga se magnitude não definida | MOTOR/VLAB HOLD |
| T25 | Escudo sem CA | Não atribuir bônus físico/mágico improvisado | MOTOR/VLAB HOLD |
| T26 | CD Espiritual | Proficiencia+INT transformada+bonificadores ativos comprovados; três SP com salva | MOTOR/VLAB HOLD |
| T27 | Uma família/slot | 16 famílias por nível sem duplicação | TESTE DE DADOS PASS |
| T28 | Arsenal 25x16 | 400 slots, custos 25/25 aritmeticamente reconciliados | TESTE DE DADOS PASS |
