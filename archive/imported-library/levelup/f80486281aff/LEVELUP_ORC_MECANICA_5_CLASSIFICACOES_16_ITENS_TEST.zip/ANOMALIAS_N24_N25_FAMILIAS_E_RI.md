# N24/N25 — Auditoria de RI nominal versus potência REAL da variante TEST

**MESTRE-ONLY / TEST — especificação mecânica de referência, NÃO ficha canônica, não catalogada para Players e sem invenção de posse.** Conteúdo transcrito/reconciliado a partir das 25 fichas TEST existentes, Atlas, PR-ITEM-02, PA, DMG-RANK, Combate e PR-SC-01. **Estado de escrita Notion:** a tentativa de alteração documental foi bloqueada pela ferramenta nesta rodada; nenhum UPDATE de ficha ou Diário desta rodada deve ser presumido. Estas especificações são propostas verificáveis para aplicação futura com writer/lease/epoch/BLOCK-PERMIT validado.

Este comparativo **não reclassifica**, **não reequilibra por invenção** e não presume que haja upgrade entre N23 e N24. Mostra conflitos de progressão dentro da própria classificação do ITEM, não da classificação do Orc.

| Nº | Nome | RI nominal N25 TEST | Progressão regular nesse RI | Descrito N25 | Estado |
|---|---|---|---|---|---|
| 01 | Couraça da Muralha | Lendário | +30 CA física | +30 CA física | ALINHADO |
| 02 | Machado da Ruptura | Lendário | 12d6 +16d6 Ruptura | 12d6 +16d6 Ruptura | ALINHADO |
| 03 | Manoplas da Bigorna | Ouro | +6 FOR | +4 FOR | ABAIXO |
| 04 | Cinto do Bastião | Ouro | +6 CON | +4 CON | ABAIXO |
| 05 | Botas da Escarpa | Prata | +4 DES | +2 DES | ABAIXO |
| 06 | Anel da Guarda | Ouro Negro | +5 CA mágica | +6 CA mágica | ACIMA |
| 07 | Elmo do Estandarte | Prata | +4 Vontade contra medo | +4 Vontade contra medo | ALINHADO |
| 08 | Capa do Desfiladeiro | Ouro Negro | +8 Furtividade | +10 Furtividade | ACIMA |
| 09 | Braçadeiras do Golpe Medido | Ouro | +6 acerto duas mãos | +8 acerto duas mãos | ACIMA |
| 10 | Amuleto da Forja | Ouro | +6 INT especializada | +4 INT especializada | ABAIXO |
| 11 | Anel de Golpe | Ouro | +6 acerto (reserva) | +8 acerto (reserva) | ACIMA |
| 12 | Insígnia da Escolta | Prata | +4 Vontade do aliado | +4 Vontade do aliado | ALINHADO |
| 13 | Arnês Antitombo | Ouro | −1,5 m empurrão | −1,5 m empurrão | ALINHADO SEM ESCALADA |
| 14 | Espada da Guarda | Lendário | 6d8 físico | 6d8 físico | ALINHADO RESERVA |
| 15 | Escudo de Passagem | Ouro Negro | CA HOLD | CA HOLD | HOLD |
| 16 | Selo de Emergência | Ouro Negro | carga HOLD | carga HOLD | HOLD |

## Conclusão de auditoria

- **4 ACIMA:** Anel da Guarda (+6 CA ON versus padrão ON +5), Capa (+10 Furtividade ON versus +8), Braçadeiras (+8 acerto O versus +6), Anel de Golpe (+8 acerto O versus +6, RESERVA). Exigem comprovar variante/aprimoramento; não agrupar como efeito homologado do mesmo RI.
- **4 ABAIXO:** Manoplas, Cinto, Botas e Amuleto usam potência inferior à progressão de seu rank nominal (possível design balanceado, sem prova de alteração material).
- **4 ALINHADOS e um efeito invariável:** Couraça, Machado, Elmo e Insígnia alinham números; Arnês 1,5 m continua invariável com RI nominal Ouro; não presumir FIP Ouro.
- **1 arma em RESERVA alinhada:** Espada 6d8 ainda não contém prova do encantamento responsável; não certificar RI Lendário por isso.
- **2 HOLD:** Escudo e Selo sem mecânica numerada; não cobrar ativação fictícia nem promover PS.
- **TOTAL DE CUSTO PUBLICADO N25:** 356 PA/dia para dez energizados, sendo 90+90+21+21+11+35+11+35+21+21; não imputar piso Lendário a todo equipamento do Orc Lendário.
- **PRIMEIRA CORREÇÃO MATERIAL QUANDO GREEN:** confrontar variantes acima com contratos e origens já existentes no Atlas/CRAFT; só depois harmonizar descrição dos slots que forem materialmente inconsistentes. Não reescrever todo o arsenal.
