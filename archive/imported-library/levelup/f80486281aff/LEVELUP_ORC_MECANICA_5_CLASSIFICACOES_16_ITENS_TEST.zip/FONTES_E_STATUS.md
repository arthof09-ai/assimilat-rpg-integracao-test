# Governança, status e fontes — 23/10/2026

**Escopo:** MESTRE-SIDE TEST; 16 famílias existentes ×5 classificações NOMINAIS =80 contratos analíticos, NÃO 80 itens físicos novos, e N01–N25 com 400 slots. Mantenha ficha Base, Party, O Primeiro, CRAFT, GitHub, VLAB NO-WRITE.

**FONTE VERIFICADA:** páginas originais do Orc N01–N25; alterações pós-P23-023 de CDs e atributos verificadas; Diário P23-025. **ATUALIZAÇÃO DE ITENS NO NOTION NESTA RODADA:** NÃO EFETUADA; a ação de escrita de Notion foi bloqueada pelas configurações de segurança da ferramenta. Não usar este pacote como recibo de edição física.

**PROPOSTA EXECUTÁVEL:** especificações de correção, sem poderes novos. CA física vs encanto, base vs Ruptura, custos por efeito rank, limites, ações, compatibilidades, mudanças de carga. **RI/FIP=0/16 homologadas; PS=0/16**, VLAB não homologou.

**LEI:** errata de 20/10: Bronze→Lendário base 6/12/24/35/50; ativo 3/6/12/17/25 PA/dia, 3/7/14/21/30 PA/uso; piso RI nominal 8/11/21/35/90; 1 atributo=5 PA/dia como referência, sem duplicar a mesma passiva. Tarifa de atributos temporários necessita aceite competente quando aplicável.

**BLOQUEIO:** documento de governança MICRO-BLOCK exige CURRENT-WRITER-ID, WRITER-EPOCH, LEASE-TOKEN, BLOCK-PERMIT GREEN e validação; nenhum foi obtido para esta instância. Não inferir writer de uma ordem de conteúdo.

## Links canônicos Mestre

- **diary**: https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107
- **inbox**: https://app.notion.com/p/3ffc2b324ede81aab557fd267efc02ce
- **index**: https://app.notion.com/p/400c2b324ede8137a06bff45c3b5b1bb
- **atlas**: https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab
- **pa**: https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4
- **sc**: https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1
- **dmg**: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- **combate**: https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0

## Lacunas concretas

- *Bronze:* couraça +14 CA física é atípica versus comparadores ON isolados; itens atributivos mudam +1 para +2 na 5ª estrela do personagem sem prova de upgrade físico.
- *Prata/Ouro/Ouro Negro:* itens atributo podem pressionar orçamento T9, 7 déficits entre N06/N11/N16/N17/N21/N22/N23; Capa e Braçadeiras restauradas mas RE sem lastro final.
- *Lendário:* 810 PA/dia em N21–N23 contra 356 em N24–N25 por loadout misto, sem evento físico comprovado; não retroagir.
- *Todas:* Arnês de 1,5 m invariante em cinco ranks, Espada sem fonte de aprimoramento mágico, Escudo sem CA, Selo sem quantificação/carga/receita; comparadores insuficientes para RI/FIP e PR-SC PS.

**Gate de passagem:** reencontrar writer/fencing GREEN, reconciliar versões e eixos, fazer canário, aplicar micro-lote em TEST existente, reabrir e só então registrar como editado; jamais presuma que exportar ZIP modificou Notion.
