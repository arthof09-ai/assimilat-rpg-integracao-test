# LEVEL-UP — Arsenal Orc TEST — Ouro

**MESTRE-ONLY / TEST — especificação mecânica de referência, NÃO ficha canônica, não catalogada para Players e sem invenção de posse.** Conteúdo transcrito/reconciliado a partir das 25 fichas TEST existentes, Atlas, PR-ITEM-02, PA, DMG-RANK, Combate e PR-SC-01. **Estado de escrita Notion:** a tentativa de alteração documental foi bloqueada pela ferramenta nesta rodada; nenhum UPDATE de ficha ou Diário desta rodada deve ser presumido. Estas especificações são propostas verificáveis para aplicação futura com writer/lease/epoch/BLOCK-PERMIT validado.


## Escopo e antes/depois

- **Classificação do portador nas fichas:** N11–N15. Não representa automaticamente classificação/RI do item.
- **Inventário fonte:** cinco fichas × 16 posições = 80 referências, parte das 400 do projeto.
- **PA/dia publicado no loadout fonte, N em ordem:** 309 cada; itens energizados: 13 cada. Isto é aritmética de ficha, não certificação do fornecedor PA.
- **Tarifa de efeito ativo da classificação:** 12 PA/dia; 14 PA/uso; base passiva 24 PA/dia; piso do item 21 PA/dia. O piso é aplicado ao TOTAL diário do item, sem dupla cobrança de um único efeito.
- **RE/RI/FIP:** usar efeito dominante confiável e 14 eixos do Atlas, comparadores vivo/sistêmico/objeto e evidência E0–E3. Sem equivalências, RI e FIP seguem HOLD.
- **Maturidade/produção:** propostas TEST e candidatos a dossiê P2; PS=0, fabricação=0, posse=0; não aplicáveis à Party.

## Dezesseis contratos mecânicos da classificação

### 01. Couraça da Muralha

- **Identidade:** família única #01, slot funcional `armadura`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Tronco; armadura pesada; Portador, contra um ataque declarado.
- **Contrato mecânico:** +22 CA física passiva; deslocamento 50%; encanto +3 CA mágica contra 1 ataque declarado, jamais passivo.
- **Ações, gatilho e limite:** CA física passiva; reação/ação do encanto mágico = HOLD para validação VLAB; duração: Bônus físico enquanto equipado; mágico contra um ataque; frequência: Encanto sujeito a uma Reação livre; recarga não demonstrada.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Defesa**; CA física vs magia; Anel da Guarda, Defender/Esquivar, Carapaça Guardiã; sem dobro de Reação.
- **Incompatibilidades/risco de abuso:** Movimento a 50%; não somar magia à CA passiva nem duas Reações; forma transformada HOLD.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Defesa física +14 Bronze exige confronto com armaduras oficiais; ativação da Couraça e stacking/reação HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 02. Machado da Ruptura

- **Identidade:** família única #02, slot funcional `arma`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Duas mãos; incompatível com escudo empunhado; Alvo atingido por ataque corpo a corpo; alcance físico conforme regra.
- **Contrato mecânico:** 8d6 físico (DME 28) com duas mãos; Ruptura +4d6 (DME adicional 14) paga, após acerto, 1/descanso; DME bruto elegível 42, pós-RD depende do alvo.
- **Ações, gatilho e limite:** Ataque com ação prevista pelo Sistema de Combate; custo de Ruptura condicionado a acerto; duração: Dano instantâneo por acerto; frequência: Ruptura 1/descanso; não é efeito sustentado.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Ofensiva**; Luta/acerto primeiro; após acerto pagar Ruptura; dano intrínseco separado de crítico, RD, títulos e transformação.
- **Incompatibilidades/risco de abuso:** Sem soma automática de FOR; crítico/RD resolvidos pelo motor vigente; não utilizar em conjunto com Espada/Escudo.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. DME separada de burst, crítico e RD; sustentação do rank a partir de comparadores de arma HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 03. Manoplas da Bigorna

- **Identidade:** família única #03, slot funcional `acessório`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Mãos; anatomia transformada HOLD; Portador.
- **Contrato mecânico:** +6 FOR temporário por 2 turnos mediante ativação, sujeito à finalidade do item e atributos efetivos.
- **Ações, gatilho e limite:** Ação Padrão de ativação proposta TEST; duração: 2 turnos desde ativação válida; frequência: Nova ativação exige novo custo; frequência máxima além da duração HOLD.
- **PA:** manutenção **30 PA/dia energizado no desenho-base de Ouro**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Suporte**; FOR efetiva e FF apenas na janela; testes, não valor permanente.
- **Incompatibilidades/risco de abuso:** Sem passiva de FOR ou dano automático; sem dupla cobrança por um único buff.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Contrato de tarifa por bônus temporário e source de melhoria B5 HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 04. Cinto do Bastião

- **Identidade:** família única #04, slot funcional `acessório`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Cintura; anatomia transformada HOLD; Portador.
- **Contrato mecânico:** +6 CON temporário por 2 turnos mediante ativação, sujeito à finalidade do item e atributos efetivos.
- **Ações, gatilho e limite:** Ação Padrão de ativação proposta TEST; duração: 2 turnos desde ativação válida; frequência: Nova ativação exige novo custo; frequência máxima além da duração HOLD.
- **PA:** manutenção **30 PA/dia energizado no desenho-base de Ouro**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Suporte**; CON efetiva, FF e máximos apenas enquanto ativo; dano acumulado preservado.
- **Incompatibilidades/risco de abuso:** Não cura, não recupera Vida perdida, não é aumento permanente de máxima.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Vida máxima temporária sem cura; contrato de tarifa e source de melhoria B5 HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 05. Botas da Escarpa

- **Identidade:** família única #05, slot funcional `acessório`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Pés; anatomia transformada HOLD; Portador.
- **Contrato mecânico:** +6 DES temporário por 2 turnos mediante ativação, sujeito à finalidade do item e atributos efetivos.
- **Ações, gatilho e limite:** Ação Padrão de ativação proposta TEST; duração: 2 turnos desde ativação válida; frequência: Nova ativação exige novo custo; frequência máxima além da duração HOLD.
- **PA:** manutenção **30 PA/dia energizado no desenho-base de Ouro**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Mobilidade**; DES efetiva, testes, CA/FF somente com fórmula correspondente e buff ativo.
- **Incompatibilidades/risco de abuso:** Não anula movimento 50% da Couraça nem concede deslocamento extra automaticamente.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Não neutralizar movimento 50%; tarifa e source de melhoria B5 HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 06. Anel da Guarda

- **Identidade:** família única #06, slot funcional `anel`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Dedo; slots e Anéis da Alma HOLD; Portador contra 1 ataque físico anunciado.
- **Contrato mecânico:** +3 CA mágica por Reação contra apenas 1 ataque físico declarado.
- **Ações, gatilho e limite:** Reação proposta TEST no ataque declarado; duração: Um ataque declarado; frequência: Limitado à disponibilidade da Reação; recarga adicional HOLD.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Defesa**; CA mágica na janela; disputa economia de Reação e portabilidade à forma.
- **Incompatibilidades/risco de abuso:** Não soma automaticamente ao encanto da Couraça ou Carapaça; 1 Reação total.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Uma Reação; slots de anéis e stack HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 07. Elmo do Estandarte

- **Identidade:** família única #07, slot funcional `elmo`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Cabeça; anatomia transformada HOLD; Portador em escolta reconhecível.
- **Contrato mecânico:** +6 Vontade exclusivamente contra medo, escolta reconhecível, um teste.
- **Ações, gatilho e limite:** Ação Padrão de ativação proposta TEST; duração: Até próximo turno, 1 teste de medo; frequência: Um teste por ativação.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Suporte**; Bônus Vontade contra medo somente, sem alteração da Vontade geral.
- **Incompatibilidades/risco de abuso:** Não é aura universal; não resiste a todo tipo de controle.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Gatilho escolta e limite de medo precisam ensaio; sem aura. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 08. Capa do Desfiladeiro

- **Identidade:** família única #08, slot funcional `capa`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Tronco/costas; encaixe forma HOLD; Portador em rochas ou penumbra.
- **Contrato mecânico:** +6 Furtividade em rocha/penumbra por 2 turnos; sem proteção de dano.
- **Ações, gatilho e limite:** Ativação contextual; tipo de Ação definitiva HOLD; duração: 2 turnos; frequência: Custo por ativação; recarga adicional HOLD.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Informação/Percepção**; Somente Furtividade ambiental; preserva progressão sem trocar de função.
- **Incompatibilidades/risco de abuso:** Não mitiga dano, não consome Reação por efeito de Furtividade, não funciona fora do terreno/gatilho.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Somente Furtividade; versões de mitigação antigas superadas. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 09. Braçadeiras do Golpe Medido

- **Identidade:** família única #09, slot funcional `braçadeiras`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Braços; arma de duas mãos requerida; Próximo teste para acertar com arma duas mãos.
- **Contrato mecânico:** +6 no teste de acerto de arma duas mãos após preparo, 1/cena.
- **Ações, gatilho e limite:** Preparar ataque; custo de ação exato HOLD; duração: Um ataque elegível após preparo; janela do preparo HOLD; frequência: 1/cena.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Ofensiva**; Aplicar bônus ao teste de ataque; Ruptura continua condicionada ao acerto e limite próprio.
- **Incompatibilidades/risco de abuso:** Sem aumento de dano, ataque extra, reação defensiva, ou uso sem preparo.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Somente acerto; preparo/ação exata e 1/cena sob ensaio. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 10. Amuleto da Forja

- **Identidade:** família única #10, slot funcional `amuleto`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Pescoço; anatomia/slots HOLD; Um teste preparado de Alquimia ou Inscrições.
- **Contrato mecânico:** +6 INT especializada temporário por 2 turnos mediante ativação, sujeito à finalidade do item e atributos efetivos.
- **Ações, gatilho e limite:** Ação Padrão de preparo proposta TEST; duração: Até 2 turnos após ativação; frequência: Um teste elegível por ativação, limite adicional HOLD.
- **PA:** manutenção **30 PA/dia energizado no desenho-base de Ouro**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Suporte**; INT só no teste especializado e na janela, sem propagação geral.
- **Incompatibilidades/risco de abuso:** NÃO altera CD espiritual, INT global, pontos de PA, proficiência ou treinos.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. INT APENAS Alquimia/Inscrições; não transmitir CD ED. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 11. Anel de Golpe

- **Identidade:** família única #11, slot funcional `anel`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Dedo; compatibilidade com anéis da Alma HOLD; Próximo teste de acerto do portador.
- **Contrato mecânico:** +6 no teste do próximo ataque antes do próximo turno, sem dano extra.
- **Ações, gatilho e limite:** Ação Padrão de preparo proposta TEST; duração: Próximo ataque até próximo turno; frequência: Um teste de ataque por ativação.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Ofensiva**; Teste de ataque; mão/anel e interação com PA/forma HOLD.
- **Incompatibilidades/risco de abuso:** Sem dano adicional, sem ataque extra, sem stack automático com Braçadeiras.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Compatibilidade de anéis e aplicação de preparado HOLD. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 12. Insígnia da Escolta

- **Identidade:** família única #12, slot funcional `insígnia`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Peitoral; equipagem forma HOLD; Um aliado adjacente reconhecido.
- **Contrato mecânico:** +6 Vontade contra medo para um aliado adjacente, uma salvaguarda.
- **Ações, gatilho e limite:** Ação Padrão proposta TEST; duração: Um teste de Vontade até próximo turno; frequência: Um teste por ativação.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Suporte**; Apoio situacional a Vontade contra medo.
- **Incompatibilidades/risco de abuso:** Não fornece Reação adicional, aura, imunidade a medo ou múltiplos alvos.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Um aliado adjacente; escolta reconhecida e duração. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 13. Arnês Antitombo

- **Identidade:** família única #13, slot funcional `arnês`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Tronco; peso e anatomia HOLD; Portador sobre solo firme.
- **Contrato mecânico:** Reduz 1,5m de uma ocorrência de empurrão no solo firme; não aumenta ao subir rank nominal.
- **Ações, gatilho e limite:** Reação proposta TEST ao empurrão; duração: Uma ocorrência de empurrão; frequência: Máximo uma ocorrência por Reação.
- **PA:** manutenção **21 PA/dia energizado (piso RI nominal TEST)**; ativação **14 PA/uso**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Controle**; Redução fixa da distância de movimento forçado; teste de deslocamento e evento VLAB pendentes.
- **Incompatibilidades/risco de abuso:** Não nega AoO; não serve para voo/solo ausente; não justifica evolução de RI sem efeito novo comprovado.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. GAP CRÍTICO: mesmíssima redução 1,5m em todas as cinco classes. Não justificar rank maior por PA. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 14. Espada da Guarda

- **Identidade:** família única #14, slot funcional `arma`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Uma mão, com ou sem Escudo; nunca simultânea a Machado duas mãos; Um alvo corpo a corpo.
- **Contrato mecânico:** Espada de uma mão 4d8 dano físico (DME 18); encantamento e RE não demonstrados.
- **Ações, gatilho e limite:** Ação de ataque conforme Sistema de Combate; duração: Um acerto; frequência: Conforme número de ataques autorizados do portador.
- **PA:** manutenção **0 PA/dia em RESERVA, custo ao equipar/HOLD; ataque físico por si só não cria habilidade ativa cobravel**; ativação **HOLD / N/A conforme ativação mágica não definida**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Ofensiva**; Alternativa de loadout; sem mudança automática de equipamentos em cena ou na forma.
- **Incompatibilidades/risco de abuso:** NÃO imputar 3/7/14/21/30 PA/uso para ataque físico sem habilidade; bônus mágico e RE não demonstrados.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Fonte mágica do dano e hipótese RI superior NÃO demonstradas. Sem cobrar ativação física. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 15. Escudo de Passagem

- **Identidade:** família única #15, slot funcional `escudo`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Uma mão; somente com arma compatível; não com Machado duas mãos; Portador.
- **Contrato mecânico:** Escudo reserva; CA física, CA mágica e frequência de qualquer efeito = HOLD.
- **Ações, gatilho e limite:** Equipagem/defesa sem gatilho mágico comprovado; duração: Enquanto portado de modo válido, efeito preciso HOLD; frequência: N/A até definir defesa concreta.
- **PA:** manutenção **0 PA/dia em RESERVA, custo de eventual energização/uso HOLD**; ativação **HOLD / N/A conforme ativação mágica não definida**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Defesa**; Compatibilidade com Espada, regras de Defender e anatomia; fontes de CA HOLD.
- **Incompatibilidades/risco de abuso:** CA física/mágica NÂO numeradas nas fontes; nenhum poder inventado; PA somente se efeito comprovadamente energizado.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Contrato incompleto: não inventar CA, ação mágica ou rank. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.

### 16. Selo de Emergência

- **Identidade:** família única #16, slot funcional `consumível`; rank do ITEM nominal na ficha TEST = **Ouro**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** Uma unidade em reserva; posse física NÃO comprovada; Portador ou alvo HOLD.
- **Contrato mecânico:** Selo consumível em reserva; proteção temporária proposta, quantidade, ação, carga e transferência = HOLD.
- **Ações, gatilho e limite:** Consumo/ativação HOLD; duração: Vida temporária/magnitude HOLD; frequência: Consumível por ocorrência; cargas/recarga HOLD.
- **PA:** manutenção **0 PA/dia em RESERVA, custo de eventual energização/uso HOLD**; ativação **HOLD / N/A conforme ativação mágica não definida**; base de efeito ativo usada para comparação PA=**12 PA/dia** quando aplicável; piso do RI nominal TEST **21 PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **Suporte**; Vida temporária, CRAFT transferência mágica, componentes materiais e RE HOLD.
- **Incompatibilidades/risco de abuso:** Não copiar efeito do Selo do Último Refúgio; sem valor de Vida, PA por uso ou fabricação demonstrados.
- **Atlas, maturidade e origem:** RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS. Contrato incompleto: não inventar Vida temporária, carga nem transferência mágica. Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.
## Gate de integração desta classificação

- **Cenários reproduzíveis:** somatório de N11–N15, 16 nomes únicos por ficha, alvo/acerto antes de dano, Ruptura somente 1/descanso com 3/7/14/21/30 PA por uso correspondente, Reação única contra Couraça/Anel/Carapaça, mão com Machado versus espada+escudo, buffs expirados e anatomia da transformação.
- **Teste e certificação:** aritmética/documentação pode passar localmente; execução nativa/VLAB e rank RI/FIP/PS permanecem HOLD, sem promover estados por ferramenta de texto.
- **NO-REPEAT:** não sobrescrever ajustes já existentes em N01–N25, não criar novas fichas, não publicar Party nem equipamento de jogo.
- **Próximo lote:** Ouro Negro.
