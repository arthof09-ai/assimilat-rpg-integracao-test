from __future__ import annotations
import json, hashlib, zipfile, re, math, statistics, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RANKS = ['Bronze','Prata','Ouro','Ouro Negro','Lendário']
DAILY_FLOOR = [8,11,21,35,90]
ACTIVE_DAILY = [3,6,12,17,25]
ACTIVE_USE = [3,7,14,21,30]
PASSIVE_BASE = [6,12,24,35,50]
NAMES = ['Couraça da Muralha','Machado da Ruptura','Manoplas da Bigorna','Cinto do Bastião','Botas da Escarpa','Anel da Guarda','Elmo do Estandarte','Capa do Desfiladeiro','Braçadeiras do Golpe Medido','Amuleto da Forja','Anel de Golpe','Insígnia da Escolta','Arnês Antitombo','Espada da Guarda','Escudo de Passagem','Selo de Emergência']
ATLAS_AXES = ['Ofensiva','Defesa','Controle','Mobilidade','Suporte','Informação/Percepção','Invocação/Criação','Alcance/Área','Duração/Permanência','Economia de ações','Confiabilidade','Bypass','Versatilidade','Impacto estratégico']
URLS = dict(diary='https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107',inbox='https://app.notion.com/p/3ffc2b324ede81aab557fd267efc02ce',index='https://app.notion.com/p/400c2b324ede8137a06bff45c3b5b1bb',atlas='https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab',pa='https://app.notion.com/p/3eec2b324ede81ecb058f59f5b67e4f4',sc='https://app.notion.com/p/3f1c2b324ede815e939ff6fd3a8726b1',dmg='https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e',combate='https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0')

# Snapshot confirmado pelas fichas TEST N01-N25, sem inferir que são itens fisicamente construídos.
ARMOR_PHYS = [14,18,22,26,30]
ARMOR_MAGIC = [1,2,3,5,8]
AXE_BASE = [4,6,8,10,12]
AXE_BURST = [1,2,4,9,16]
ATTRIBUTE = [1,4,6,8,10]
GUARD_RING = [1,2,3,5,8]
MOD = [2,4,6,8,10]
SWORD_D8 = [2,3,4,5,6]
ITEMS = [
 dict(axis='Defesa',kind='armadura',equip='Tronco; armadura pesada',action='CA física passiva; reação/ação do encanto mágico = HOLD para validação VLAB',target='Portador, contra um ataque declarado',duration='Bônus físico enquanto equipado; mágico contra um ataque',frequency='Encanto sujeito a uma Reação livre; recarga não demonstrada',restrictions='Movimento a 50%; não somar magia à CA passiva nem duas Reações; forma transformada HOLD',integration='CA física vs magia; Anel da Guarda, Defender/Esquivar, Carapaça Guardiã; sem dobro de Reação'),
 dict(axis='Ofensiva',kind='arma',equip='Duas mãos; incompatível com escudo empunhado',action='Ataque com ação prevista pelo Sistema de Combate; custo de Ruptura condicionado a acerto',target='Alvo atingido por ataque corpo a corpo; alcance físico conforme regra',duration='Dano instantâneo por acerto',frequency='Ruptura 1/descanso; não é efeito sustentado',restrictions='Sem soma automática de FOR; crítico/RD resolvidos pelo motor vigente; não utilizar em conjunto com Espada/Escudo',integration='Luta/acerto primeiro; após acerto pagar Ruptura; dano intrínseco separado de crítico, RD, títulos e transformação'),
 dict(axis='Suporte',kind='acessório',equip='Mãos; anatomia transformada HOLD',action='Ação Padrão de ativação proposta TEST',target='Portador',duration='2 turnos desde ativação válida',frequency='Nova ativação exige novo custo; frequência máxima além da duração HOLD',restrictions='Sem passiva de FOR ou dano automático; sem dupla cobrança por um único buff',integration='FOR efetiva e FF apenas na janela; testes, não valor permanente'),
 dict(axis='Suporte',kind='acessório',equip='Cintura; anatomia transformada HOLD',action='Ação Padrão de ativação proposta TEST',target='Portador',duration='2 turnos desde ativação válida',frequency='Nova ativação exige novo custo; frequência máxima além da duração HOLD',restrictions='Não cura, não recupera Vida perdida, não é aumento permanente de máxima',integration='CON efetiva, FF e máximos apenas enquanto ativo; dano acumulado preservado'),
 dict(axis='Mobilidade',kind='acessório',equip='Pés; anatomia transformada HOLD',action='Ação Padrão de ativação proposta TEST',target='Portador',duration='2 turnos desde ativação válida',frequency='Nova ativação exige novo custo; frequência máxima além da duração HOLD',restrictions='Não anula movimento 50% da Couraça nem concede deslocamento extra automaticamente',integration='DES efetiva, testes, CA/FF somente com fórmula correspondente e buff ativo'),
 dict(axis='Defesa',kind='anel',equip='Dedo; slots e Anéis da Alma HOLD',action='Reação proposta TEST no ataque declarado',target='Portador contra 1 ataque físico anunciado',duration='Um ataque declarado',frequency='Limitado à disponibilidade da Reação; recarga adicional HOLD',restrictions='Não soma automaticamente ao encanto da Couraça ou Carapaça; 1 Reação total',integration='CA mágica na janela; disputa economia de Reação e portabilidade à forma'),
 dict(axis='Suporte',kind='elmo',equip='Cabeça; anatomia transformada HOLD',action='Ação Padrão de ativação proposta TEST',target='Portador em escolta reconhecível',duration='Até próximo turno, 1 teste de medo',frequency='Um teste por ativação',restrictions='Não é aura universal; não resiste a todo tipo de controle',integration='Bônus Vontade contra medo somente, sem alteração da Vontade geral'),
 dict(axis='Informação/Percepção',kind='capa',equip='Tronco/costas; encaixe forma HOLD',action='Ativação contextual; tipo de Ação definitiva HOLD',target='Portador em rochas ou penumbra',duration='2 turnos',frequency='Custo por ativação; recarga adicional HOLD',restrictions='Não mitiga dano, não consome Reação por efeito de Furtividade, não funciona fora do terreno/gatilho',integration='Somente Furtividade ambiental; preserva progressão sem trocar de função'),
 dict(axis='Ofensiva',kind='braçadeiras',equip='Braços; arma de duas mãos requerida',action='Preparar ataque; custo de ação exato HOLD',target='Próximo teste para acertar com arma duas mãos',duration='Um ataque elegível após preparo; janela do preparo HOLD',frequency='1/cena',restrictions='Sem aumento de dano, ataque extra, reação defensiva, ou uso sem preparo',integration='Aplicar bônus ao teste de ataque; Ruptura continua condicionada ao acerto e limite próprio'),
 dict(axis='Suporte',kind='amuleto',equip='Pescoço; anatomia/slots HOLD',action='Ação Padrão de preparo proposta TEST',target='Um teste preparado de Alquimia ou Inscrições',duration='Até 2 turnos após ativação',frequency='Um teste elegível por ativação, limite adicional HOLD',restrictions='NÃO altera CD espiritual, INT global, pontos de PA, proficiência ou treinos',integration='INT só no teste especializado e na janela, sem propagação geral'),
 dict(axis='Ofensiva',kind='anel',equip='Dedo; compatibilidade com anéis da Alma HOLD',action='Ação Padrão de preparo proposta TEST',target='Próximo teste de acerto do portador',duration='Próximo ataque até próximo turno',frequency='Um teste de ataque por ativação',restrictions='Sem dano adicional, sem ataque extra, sem stack automático com Braçadeiras',integration='Teste de ataque; mão/anel e interação com PA/forma HOLD'),
 dict(axis='Suporte',kind='insígnia',equip='Peitoral; equipagem forma HOLD',action='Ação Padrão proposta TEST',target='Um aliado adjacente reconhecido',duration='Um teste de Vontade até próximo turno',frequency='Um teste por ativação',restrictions='Não fornece Reação adicional, aura, imunidade a medo ou múltiplos alvos',integration='Apoio situacional a Vontade contra medo'),
 dict(axis='Controle',kind='arnês',equip='Tronco; peso e anatomia HOLD',action='Reação proposta TEST ao empurrão',target='Portador sobre solo firme',duration='Uma ocorrência de empurrão',frequency='Máximo uma ocorrência por Reação',restrictions='Não nega AoO; não serve para voo/solo ausente; não justifica evolução de RI sem efeito novo comprovado',integration='Redução fixa da distância de movimento forçado; teste de deslocamento e evento VLAB pendentes'),
 dict(axis='Ofensiva',kind='arma',equip='Uma mão, com ou sem Escudo; nunca simultânea a Machado duas mãos',action='Ação de ataque conforme Sistema de Combate',target='Um alvo corpo a corpo',duration='Um acerto',frequency='Conforme número de ataques autorizados do portador',restrictions='NÃO imputar 3/7/14/21/30 PA/uso para ataque físico sem habilidade; bônus mágico e RE não demonstrados',integration='Alternativa de loadout; sem mudança automática de equipamentos em cena ou na forma'),
 dict(axis='Defesa',kind='escudo',equip='Uma mão; somente com arma compatível; não com Machado duas mãos',action='Equipagem/defesa sem gatilho mágico comprovado',target='Portador',duration='Enquanto portado de modo válido, efeito preciso HOLD',frequency='N/A até definir defesa concreta',restrictions='CA física/mágica NÂO numeradas nas fontes; nenhum poder inventado; PA somente se efeito comprovadamente energizado',integration='Compatibilidade com Espada, regras de Defender e anatomia; fontes de CA HOLD'),
 dict(axis='Suporte',kind='consumível',equip='Uma unidade em reserva; posse física NÃO comprovada',action='Consumo/ativação HOLD',target='Portador ou alvo HOLD',duration='Vida temporária/magnitude HOLD',frequency='Consumível por ocorrência; cargas/recarga HOLD',restrictions='Não copiar efeito do Selo do Último Refúgio; sem valor de Vida, PA por uso ou fabricação demonstrados',integration='Vida temporária, CRAFT transferência mágica, componentes materiais e RE HOLD'),
]

assert len(ITEMS)==len(NAMES)==16

# snapshots physically observed, no sheets written here
SNAPS=[]
for n in range(1,26):
    if n <= 5:
        classidx=0
        active=list(range(1, {1:8,2:10,3:11,4:12,5:13}[n]+1))
        c=[0]*16
        for i in active:
            c[i-1] = 10 if n==5 and i in [3,4,5,10] else 8
    elif n<=10:
        classidx=1;active=list(range(1,14));c=[0]*16
        for i in active:c[i-1]=20 if i in [3,4,5,10] else 11
    elif n<=15:
        classidx=2;active=list(range(1,14));c=[0]*16
        for i in active:c[i-1]=30 if i in [3,4,5,10] else 21
    elif n<=20:
        classidx=3;active=list(range(1,14));c=[0]*16
        for i in active:c[i-1]=40 if i in [3,4,5,10] else 35
    elif n<=23:
        classidx=4;active=list(range(1,10));c=[90]*9+[0]*7
    else:
        classidx=4;active=list(range(1,11));c=[90,90,21,21,11,35,11,35,21,21]+[0]*6
    SNAPS.append(dict(level=n,classificacao=RANKS[classidx],energizados=active,pa_por_item=c,pa_diario=sum(c)))
EXPECTED=[64,80,88,96,112]+[179]*5+[309]*5+[475]*5+[810]*3+[356]*2
assert [x['pa_diario'] for x in SNAPS]==EXPECTED

# Value of each item in its nominal rank (NOT authoritative RI). No new powers.
def benefit(item,r):
    if item==1:return f'+{ARMOR_PHYS[r]} CA física passiva; deslocamento 50%; encanto +{ARMOR_MAGIC[r]} CA mágica contra 1 ataque declarado, jamais passivo.'
    if item==2:return f'{AXE_BASE[r]}d6 físico (DME {AXE_BASE[r]*3.5:g}) com duas mãos; Ruptura +{AXE_BURST[r]}d6 (DME adicional {AXE_BURST[r]*3.5:g}) paga, após acerto, 1/descanso; DME bruto elegível {(AXE_BASE[r]+AXE_BURST[r])*3.5:g}, pós-RD depende do alvo.'
    if item in (3,4,5,10):
        stat={3:'FOR',4:'CON',5:'DES',10:'INT especializada'}[item]
        suffix='; em Bronze 5★ N05 o valor histórico muda para +2, sem evento de upgrade demonstrado' if r==0 else ''
        return f'+{ATTRIBUTE[r]} {stat} temporário por 2 turnos mediante ativação, sujeito à finalidade do item e atributos efetivos{suffix}.'
    if item==6:return f'+{GUARD_RING[r]} CA mágica por Reação contra apenas 1 ataque físico declarado.'
    if item==7:return f'+{MOD[r]} Vontade exclusivamente contra medo, escolta reconhecível, um teste.'
    if item==8:return f'+{MOD[r]} Furtividade em rocha/penumbra por 2 turnos; sem proteção de dano.'
    if item==9:return f'+{MOD[r]} no teste de acerto de arma duas mãos após preparo, 1/cena.'
    if item==11:return f'+{MOD[r]} no teste do próximo ataque antes do próximo turno, sem dano extra.'
    if item==12:return f'+{MOD[r]} Vontade contra medo para um aliado adjacente, uma salvaguarda.'
    if item==13:return 'Reduz 1,5m de uma ocorrência de empurrão no solo firme; não aumenta ao subir rank nominal.'
    if item==14:return f'Espada de uma mão {SWORD_D8[r]}d8 dano físico (DME {SWORD_D8[r]*4.5:g}); encantamento e RE não demonstrados.'
    if item==15:return 'Escudo reserva; CA física, CA mágica e frequência de qualquer efeito = HOLD.'
    if item==16:return 'Selo consumível em reserva; proteção temporária proposta, quantidade, ação, carga e transferência = HOLD.'
    raise IndexError

def costs(item,r):
    if item>=14: return dict(daily='0 enquanto RESERVA',use='HOLD / N/A conforme ativação mágica não definida',activebase=None,nominal_floor=DAILY_FLOOR[r])
    if item in (3,4,5,10):
        cost=max(DAILY_FLOOR[r],ATTRIBUTE[r]*5,ACTIVE_DAILY[r])
        return dict(daily=f'{cost} PA/dia energizado no desenho-base de {RANKS[r]}',use=f'{ACTIVE_USE[r]} PA/uso',activebase=ACTIVE_DAILY[r],nominal_floor=DAILY_FLOOR[r])
    return dict(daily=f'{DAILY_FLOOR[r]} PA/dia energizado (piso RI nominal TEST)',use=f'{ACTIVE_USE[r]} PA/uso',activebase=ACTIVE_DAILY[r],nominal_floor=DAILY_FLOOR[r])

def gate(item):
    common='RI nominal TEST NÃO homologado; RE e FIP=HOLD; comparadores Atlas por 14 eixos=pendentes de E0/E1 apropriado; maturidade não promovida a PS.'
    specific={1:'Defesa física +14 Bronze exige confronto com armaduras oficiais; ativação da Couraça e stacking/reação HOLD.',2:'DME separada de burst, crítico e RD; sustentação do rank a partir de comparadores de arma HOLD.',3:'Contrato de tarifa por bônus temporário e source de melhoria B5 HOLD.',4:'Vida máxima temporária sem cura; contrato de tarifa e source de melhoria B5 HOLD.',5:'Não neutralizar movimento 50%; tarifa e source de melhoria B5 HOLD.',6:'Uma Reação; slots de anéis e stack HOLD.',7:'Gatilho escolta e limite de medo precisam ensaio; sem aura.',8:'Somente Furtividade; versões de mitigação antigas superadas.',9:'Somente acerto; preparo/ação exata e 1/cena sob ensaio.',10:'INT APENAS Alquimia/Inscrições; não transmitir CD ED.',11:'Compatibilidade de anéis e aplicação de preparado HOLD.',12:'Um aliado adjacente; escolta reconhecida e duração.',13:'GAP CRÍTICO: mesmíssima redução 1,5m em todas as cinco classes. Não justificar rank maior por PA.',14:'Fonte mágica do dano e hipótese RI superior NÃO demonstradas. Sem cobrar ativação física.',15:'Contrato incompleto: não inventar CA, ação mágica ou rank.',16:'Contrato incompleto: não inventar Vida temporária, carga nem transferência mágica.'}
    return common+' '+specific[item]

DOC_NOTE='''**MESTRE-ONLY / TEST — especificação mecânica de referência, NÃO ficha canônica, não catalogada para Players e sem invenção de posse.** Conteúdo transcrito/reconciliado a partir das 25 fichas TEST existentes, Atlas, PR-ITEM-02, PA, DMG-RANK, Combate e PR-SC-01. **Estado de escrita Notion:** a tentativa de alteração documental foi bloqueada pela ferramenta nesta rodada; nenhum UPDATE de ficha ou Diário desta rodada deve ser presumido. Estas especificações são propostas verificáveis para aplicação futura com writer/lease/epoch/BLOCK-PERMIT validado.\n'''

def dossier(item,r):
    meta=ITEMS[item-1]
    c=costs(item,r)
    if item in (3,4,5,10) and r==0:
        d='8 PA/dia N01–04 (+1 atributo); 10 PA/dia N05 (+2 atributo); sem soma dupla de passiva'
    else:d=c['daily']
    if item==14:
        d='0 PA/dia em RESERVA, custo ao equipar/HOLD; ataque físico por si só não cria habilidade ativa cobravel'
    if item==15 or item==16:d='0 PA/dia em RESERVA, custo de eventual energização/uso HOLD'
    return f'''### {item:02d}. {NAMES[item-1]}

- **Identidade:** família única #{item:02d}, slot funcional `{meta['kind']}`; rank do ITEM nominal na ficha TEST = **{RANKS[r]}**, rank efetivo **RI=HOLD**, rank do efeito principal **RE=HOLD**, **FIP=HOLD**. Não presumir que cinco variações sejam cinco objetos físicos.
- **Equipagem e alcance:** {meta['equip']}; {meta['target']}.
- **Contrato mecânico:** {benefit(item,r)}
- **Ações, gatilho e limite:** {meta['action']}; duração: {meta['duration']}; frequência: {meta['frequency']}.
- **PA:** manutenção **{d}**; ativação **{c['use']}**; base de efeito ativo usada para comparação PA=**{ACTIVE_DAILY[r]} PA/dia** quando aplicável; piso do RI nominal TEST **{DAILY_FLOOR[r]} PA/dia**, não certificado como RI verdadeiro. Bônus de atributo é um efeito único, não cobrança adicional duplicada.
- **Defesa, testes, interação:** eixo dominante candidato = **{meta['axis']}**; {meta['integration']}.
- **Incompatibilidades/risco de abuso:** {meta['restrictions']}.
- **Atlas, maturidade e origem:** {gate(item)} Fabricação/receita/posse = não demonstradas; risco SC a classificar (SC-2 candidato, SC-3/4 se efeito estratégico), AUTO-SC-RECIPE não pode ser presumida; nenhuma PS/P4 declarada.
'''

rankfiles=[]
for r,rank in enumerate(RANKS):
    if r==0:
        lv='N01–N05';sums='64 / 80 / 88 / 96 / 112';active='8 / 10 / 11 / 12 / 13'
    elif r==1:lv='N06–N10';sums='179 cada';active='13 cada'
    elif r==2:lv='N11–N15';sums='309 cada';active='13 cada'
    elif r==3:lv='N16–N20';sums='475 cada';active='13 cada'
    else:lv='N21–N25';sums='810 / 810 / 810 / 356 / 356';active='9 / 9 / 9 / 10 / 10'
    pre=f'''# LEVEL-UP — Arsenal Orc TEST — {rank}

{DOC_NOTE}

## Escopo e antes/depois

- **Classificação do portador nas fichas:** {lv}. Não representa automaticamente classificação/RI do item.
- **Inventário fonte:** cinco fichas × 16 posições = 80 referências, parte das 400 do projeto.
- **PA/dia publicado no loadout fonte, N em ordem:** {sums}; itens energizados: {active}. Isto é aritmética de ficha, não certificação do fornecedor PA.
- **Tarifa de efeito ativo da classificação:** {ACTIVE_DAILY[r]} PA/dia; {ACTIVE_USE[r]} PA/uso; base passiva {PASSIVE_BASE[r]} PA/dia; piso do item {DAILY_FLOOR[r]} PA/dia. O piso é aplicado ao TOTAL diário do item, sem dupla cobrança de um único efeito.
- **RE/RI/FIP:** usar efeito dominante confiável e 14 eixos do Atlas, comparadores vivo/sistêmico/objeto e evidência E0–E3. Sem equivalências, RI e FIP seguem HOLD.
- **Maturidade/produção:** propostas TEST e candidatos a dossiê P2; PS=0, fabricação=0, posse=0; não aplicáveis à Party.

## Dezesseis contratos mecânicos da classificação

'''
    if r==4:
        pre+='''**EXCEÇÃO INEGOCIÁVEL — N24/N25:** classificação do Orc continua Lendário, mas o loadout mistura RI nominais: #01/#02 Lendário, #03/#04/#09/#10 Ouro, #05/#07 Prata, #06/#08 Ouro Negro; demais em reserva. Valores efetivos e custos de N24/N25 NÃO são os da coluna Lendário para todas as 16 famílias. Ver matriz `25_NIVEIS_E_400_SLOTS.json`; não copiar poderes de N21–N23 para N24/N25. Falta evento de troca/upgrades e procedência física.\n\n'''
    if r==0:
        pre+='''**EXCEÇÃO BRONZE:** N01–N04 trazem quatro itens atributivos de +1 (5 PA/dia, piso8); N05 os mesmos quatro efeitos passam a +2 (10 PA/dia) sem prova de upgrade do item. Não transformar estrelas do Orc em FIP.\n\n'''
    body='\n'.join(dossier(i,r) for i in range(1,17))
    post=f'''## Gate de integração desta classificação

- **Cenários reproduzíveis:** somatório de {lv}, 16 nomes únicos por ficha, alvo/acerto antes de dano, Ruptura somente 1/descanso com 3/7/14/21/30 PA por uso correspondente, Reação única contra Couraça/Anel/Carapaça, mão com Machado versus espada+escudo, buffs expirados e anatomia da transformação.
- **Teste e certificação:** aritmética/documentação pode passar localmente; execução nativa/VLAB e rank RI/FIP/PS permanecem HOLD, sem promover estados por ferramenta de texto.
- **NO-REPEAT:** não sobrescrever ajustes já existentes em N01–N25, não criar novas fichas, não publicar Party nem equipamento de jogo.
- **Próximo lote:** {RANKS[r+1] if r+1<len(RANKS) else 'comparadores Atlas e retomada de writer canônico para edição de fichas'}.
'''
    file=ROOT/f'{r+1:02d}_{rank.upper().replace(" ","_")}_16_EQUIPAMENTOS_MECANICA_TEST.md'
    file.write_text(pre+body+post,encoding='utf-8')
    rankfiles.append(file)

# Cross-rank matrix from canonical experimental source; 16 families, five nominal classes, 25 physical sheet slots.
entries=[]
for it in range(1,17):
    for r in range(5):
        entries.append(dict(item_id=it,nome=NAMES[it-1],classe_nominal=RANKS[r],ri_homologado=None,re_homologado=None,fip_homologada=None,beneficio=benefit(it,r),pa=costs(it,r),analise=gate(it),fonte_tipo='Notion Orc TEST; sem writer de fichas',maturidade='TEST/PENDENTE'))
(ROOT/'CONTRATOS_16x5_TEST.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'25_NIVEIS_E_400_SLOTS.json').write_text(json.dumps(SNAPS,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'FONTES_E_STATUS.md').write_text('''# Governança, status e fontes — 23/10/2026

**Escopo:** MESTRE-SIDE TEST; 16 famílias existentes ×5 classificações NOMINAIS =80 contratos analíticos, NÃO 80 itens físicos novos, e N01–N25 com 400 slots. Mantenha ficha Base, Party, O Primeiro, CRAFT, GitHub, VLAB NO-WRITE.\n
**FONTE VERIFICADA:** páginas originais do Orc N01–N25; alterações pós-P23-023 de CDs e atributos verificadas; Diário P23-025. **ATUALIZAÇÃO DE ITENS NO NOTION NESTA RODADA:** NÃO EFETUADA; a ação de escrita de Notion foi bloqueada pelas configurações de segurança da ferramenta. Não usar este pacote como recibo de edição física.\n
**PROPOSTA EXECUTÁVEL:** especificações de correção, sem poderes novos. CA física vs encanto, base vs Ruptura, custos por efeito rank, limites, ações, compatibilidades, mudanças de carga. **RI/FIP=0/16 homologadas; PS=0/16**, VLAB não homologou.\n
**LEI:** errata de 20/10: Bronze→Lendário base 6/12/24/35/50; ativo 3/6/12/17/25 PA/dia, 3/7/14/21/30 PA/uso; piso RI nominal 8/11/21/35/90; 1 atributo=5 PA/dia como referência, sem duplicar a mesma passiva. Tarifa de atributos temporários necessita aceite competente quando aplicável.\n
**BLOQUEIO:** documento de governança MICRO-BLOCK exige CURRENT-WRITER-ID, WRITER-EPOCH, LEASE-TOKEN, BLOCK-PERMIT GREEN e validação; nenhum foi obtido para esta instância. Não inferir writer de uma ordem de conteúdo.\n
## Links canônicos Mestre\n
'''+''.join(f'- **{k}**: {url}\n' for k,url in URLS.items())+'''
## Lacunas concretas\n
- *Bronze:* couraça +14 CA física é atípica versus comparadores ON isolados; itens atributivos mudam +1 para +2 na 5ª estrela do personagem sem prova de upgrade físico.\n- *Prata/Ouro/Ouro Negro:* itens atributo podem pressionar orçamento T9, 7 déficits entre N06/N11/N16/N17/N21/N22/N23; Capa e Braçadeiras restauradas mas RE sem lastro final.\n- *Lendário:* 810 PA/dia em N21–N23 contra 356 em N24–N25 por loadout misto, sem evento físico comprovado; não retroagir.\n- *Todas:* Arnês de 1,5 m invariante em cinco ranks, Espada sem fonte de aprimoramento mágico, Escudo sem CA, Selo sem quantificação/carga/receita; comparadores insuficientes para RI/FIP e PR-SC PS.\n\n**Gate de passagem:** reencontrar writer/fencing GREEN, reconciliar versões e eixos, fazer canário, aplicar micro-lote em TEST existente, reabrir e só então registrar como editado; jamais presuma que exportar ZIP modificou Notion.\n''',encoding='utf-8')


# Existing 25 Orc TEST pages. This maps targets; it is not an API writer.
SUFFIXES = [
'815cb828dbd345c48724','817fba8fde73a1c45020','81d3adc9ef2fdc11604d','81ac9519fd627291eafc','81e883d8e0275f06a674',
'814a8e56fa1275e2bfe3','814889fce8568f04949b','81fcbac7f21254483905','8170b774ea9580ab8e06','81e591ace187c1763b9c',
'81459656d6abd27699a3','81249cbbea651d99dc00','81ffa1f7d112ce18e793','81beb220cc5953504264','81a885b7f80129bfa054',
'817d9900f2c240448cb6','8118a1d0d3a56ee787d9','81a78ff5cc32a157d1b7','81c0a6ded4d52b87ec63','81ef9d94d807933e607b',
'815d8028ca7767b78e1f','81fabc81cf69f0641303','81e894a1f4ac84354ee2','81789207ccb2bac264b2','815abca2ce4fb08a8cdc']
PAGES=[]
for i,suffix in enumerate(SUFFIXES,1):
    uid='400c2b32-4ede-'+suffix[:4]+'-'+suffix[4:8]+'-'+suffix[8:12]+'-'+suffix[12:]
    PAGES.append(dict(nivel=i,page_id=uid,page_url='https://app.notion.com/p/'+uid.replace('-',''),pa_diario_snapshot=SNAPS[i-1]['pa_diario'],estado='TEST; WRITE-DENY; apenas localizar, não alterar'))
(ROOT/'MAPA_25_FICHAS_ORC_NO_WRITE.json').write_text(json.dumps(PAGES,ensure_ascii=False,indent=2),encoding='utf-8')

# Deviations of last-level loadout's specific item variants relative to the generic same nominal rank.
MIX_N25=[
(1,'Lendário','+30 CA física','+30 CA física','ALINHADO'),
(2,'Lendário','12d6 +16d6 Ruptura','12d6 +16d6 Ruptura','ALINHADO'),
(3,'Ouro','+6 FOR','+4 FOR','ABAIXO'),
(4,'Ouro','+6 CON','+4 CON','ABAIXO'),
(5,'Prata','+4 DES','+2 DES','ABAIXO'),
(6,'Ouro Negro','+5 CA mágica','+6 CA mágica','ACIMA'),
(7,'Prata','+4 Vontade contra medo','+4 Vontade contra medo','ALINHADO'),
(8,'Ouro Negro','+8 Furtividade','+10 Furtividade','ACIMA'),
(9,'Ouro','+6 acerto duas mãos','+8 acerto duas mãos','ACIMA'),
(10,'Ouro','+6 INT especializada','+4 INT especializada','ABAIXO'),
(11,'Ouro','+6 acerto (reserva)','+8 acerto (reserva)','ACIMA'),
(12,'Prata','+4 Vontade do aliado','+4 Vontade do aliado','ALINHADO'),
(13,'Ouro','−1,5 m empurrão','−1,5 m empurrão','ALINHADO SEM ESCALADA'),
(14,'Lendário','6d8 físico','6d8 físico','ALINHADO RESERVA'),
(15,'Ouro Negro','CA HOLD','CA HOLD','HOLD'),
(16,'Ouro Negro','carga HOLD','carga HOLD','HOLD')]
assert len(MIX_N25)==16
anomaly_lines=['# N24/N25 — Auditoria de RI nominal versus potência REAL da variante TEST','',DOC_NOTE,
'Este comparativo **não reclassifica**, **não reequilibra por invenção** e não presume que haja upgrade entre N23 e N24. Mostra conflitos de progressão dentro da própria classificação do ITEM, não da classificação do Orc.','',
'| Nº | Nome | RI nominal N25 TEST | Progressão regular nesse RI | Descrito N25 | Estado |','|---|---|---|---|---|---|']
for i,nominal,expected,actual,status in MIX_N25:
    anomaly_lines.append(f'| {i:02d} | {NAMES[i-1]} | {nominal} | {expected} | {actual} | {status} |')
anomaly_lines += ['','## Conclusão de auditoria','',
'- **4 ACIMA:** Anel da Guarda (+6 CA ON versus padrão ON +5), Capa (+10 Furtividade ON versus +8), Braçadeiras (+8 acerto O versus +6), Anel de Golpe (+8 acerto O versus +6, RESERVA). Exigem comprovar variante/aprimoramento; não agrupar como efeito homologado do mesmo RI.',
'- **4 ABAIXO:** Manoplas, Cinto, Botas e Amuleto usam potência inferior à progressão de seu rank nominal (possível design balanceado, sem prova de alteração material).',
'- **4 ALINHADOS e um efeito invariável:** Couraça, Machado, Elmo e Insígnia alinham números; Arnês 1,5 m continua invariável com RI nominal Ouro; não presumir FIP Ouro.',
'- **1 arma em RESERVA alinhada:** Espada 6d8 ainda não contém prova do encantamento responsável; não certificar RI Lendário por isso.',
'- **2 HOLD:** Escudo e Selo sem mecânica numerada; não cobrar ativação fictícia nem promover PS.',
'- **TOTAL DE CUSTO PUBLICADO N25:** 356 PA/dia para dez energizados, sendo 90+90+21+21+11+35+11+35+21+21; não imputar piso Lendário a todo equipamento do Orc Lendário.',
'- **PRIMEIRA CORREÇÃO MATERIAL QUANDO GREEN:** confrontar variantes acima com contratos e origens já existentes no Atlas/CRAFT; só depois harmonizar descrição dos slots que forem materialmente inconsistentes. Não reescrever todo o arsenal.','']
(ROOT/'ANOMALIAS_N24_N25_FAMILIAS_E_RI.md').write_text('\n'.join(anomaly_lines),encoding='utf-8')

# Patch-intent read-only: 5 ordered microblocks and no write operations.
PATCH_INTENT=[]
for r,rank in enumerate(RANKS):
    pages=PAGES[r*5:r*5+5]
    PATCH_INTENT.append(dict(ordem=r+1,classe=rank,paginas=pages,items=16,operacao='COMPARAR_E_CORRIGIR_APENAS_DIVERGENCIAS_REAIS',permite_auto_write=False,
       motivo_bloqueio='NO_VERIFIED_BLOCK_PERMIT_GREEN_AND_TOOL_WRITE_DENIED',
       precondicoes=['reopen Notion and assert page UUID, title and source before', 'validate writer-id epoch lease token and fencing', 'one canonically permitted microblock','NAC-PASS after mutation'],
       no_repeat=['não reaplicar Capa/Braçadeiras já corrigidas','não repetir CDs já corrigidas','não alterar Ficha Base nem Party'],
       artefato=f'{r+1:02d}_{rank.upper().replace(" ","_")}_16_EQUIPAMENTOS_MECANICA_TEST.md'))
(ROOT/'PATCH_INTENT_5_LOTES_NO_WRITE.json').write_text(json.dumps(PATCH_INTENT,ensure_ascii=False,indent=2),encoding='utf-8')


# 224 Atlas axis cells, distinguishing E2 axis comparisons vs E3 unverified vs N/A inapplicable.
ATLAS_APPLICABLE={
1:['Defesa','Mobilidade','Duração/Permanência','Economia de ações','Confiabilidade','Versatilidade'],
2:['Ofensiva','Economia de ações','Confiabilidade'],
3:['Suporte','Duração/Permanência','Economia de ações','Confiabilidade'],
4:['Suporte','Duração/Permanência','Economia de ações','Confiabilidade'],
5:['Suporte','Mobilidade','Duração/Permanência','Economia de ações','Confiabilidade'],
6:['Defesa','Duração/Permanência','Economia de ações','Confiabilidade'],
7:['Defesa','Suporte','Duração/Permanência','Economia de ações','Confiabilidade'],
8:['Informação/Percepção','Duração/Permanência','Economia de ações','Confiabilidade'],
9:['Ofensiva','Duração/Permanência','Economia de ações','Confiabilidade'],
10:['Suporte','Duração/Permanência','Economia de ações','Confiabilidade'],
11:['Ofensiva','Duração/Permanência','Economia de ações','Confiabilidade'],
12:['Suporte','Defesa','Duração/Permanência','Economia de ações','Confiabilidade'],
13:['Defesa','Mobilidade','Duração/Permanência','Economia de ações','Confiabilidade'],
14:['Ofensiva','Economia de ações'],
15:['Defesa','Economia de ações'],
16:['Defesa','Suporte','Duração/Permanência','Economia de ações']}
ATLAS_CELLS=[]
for i in range(1,17):
    for ax in ATLAS_AXES:
        if ax not in ATLAS_APPLICABLE[i]:status='N/A não declarado no contrato TEST'
        elif (i,ax) in [(1,'Defesa'),(2,'Ofensiva'),(14,'Ofensiva')]:status='E2 apenas no EIXO; comparador insuficiente p/ RI/FIP'
        else:status='E3; ensaio/benchmark independente HOLD'
        ATLAS_CELLS.append(dict(item_id=i,nome=NAMES[i-1],eixo=ax,evidencia=status,ri='HOLD',fip='HOLD'))
import csv
with (ROOT/'ATLAS_224_CELULAS_TEST.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['item_id','nome','eixo','evidencia','ri','fip']);w.writeheader();w.writerows(ATLAS_CELLS)

# Existing requirements as test recipes, not fake engine outcomes.
TEST_RECIPES=[
('T01','Ataque comum com Machado','4/6/8/10/12d6 segundo rank nominal; rolar ataque antes do dano','MOTOR/VLAB HOLD'),
('T02','Ruptura em acerto','PA por uso; +1/2/4/9/16d6; 1/descanso','MOTOR/VLAB HOLD'),
('T03','Ruptura em erro','Nenhum bônus de dano ou cobrança automática de dano','MOTOR/VLAB HOLD'),
('T04','Crítico positivo','Regra de crítico do Sistema de Combate, não 2x automático arbitrário','MOTOR/VLAB HOLD'),
('T05','RD contra arma','Dano bruto separado de pós-RD','MOTOR/VLAB HOLD'),
('T06','Couraça sem encanto','Apenas CA física 14/18/22/26/30; movimento 50%','MOTOR/VLAB HOLD'),
('T07','Encanto da Couraça','CA mágica só durante um ataque declarado e gasto aplicável','MOTOR/VLAB HOLD'),
('T08','Anel da Guarda reação','Uma Reação; 1 ataque declarado','MOTOR/VLAB HOLD'),
('T09','Carapaça concorrente','Não usar simultaneamente com Reação já consumida','MOTOR/VLAB HOLD'),
('T10','Escudo + Machado','Bloquear equipagem de duas mãos com escudo empunhado','MOTOR/VLAB HOLD'),
('T11','Espada + Escudo','Permitido como configuração alternativa, CA escudo continua HOLD','MOTOR/VLAB HOLD'),
('T12','Buff atributo ativo','Aplicar somente durante 2 turnos e PA pago','MOTOR/VLAB HOLD'),
('T13','Buff atributo expirado','Restaurar máximos/FF/testes; não curar ferimentos','MOTOR/VLAB HOLD'),
('T14','INT do Amuleto','Somente teste Alquimia/Inscrições, não CD ED','MOTOR/VLAB HOLD'),
('T15','PA de ativação insuficiente','Recusar ativação sem cobrar efeito/benefício','MOTOR/VLAB HOLD'),
('T16','PA manutenção insuficiente','Não energizar automaticamente peça; reserva 0','MOTOR/VLAB HOLD'),
('T17','Braçadeiras 1/cena','Sem segundo uso na mesma cena','MOTOR/VLAB HOLD'),
('T18','Capa fora rocha/penumbra','Sem efeito de Furtividade, não regressar para redução dano','MOTOR/VLAB HOLD'),
('T19','Arnês solo firme','1,5m mitigação por Reação; sem AoO negado','MOTOR/VLAB HOLD'),
('T20','Arnês sem solo','Não aplicar contrato sobre ar ou terreno incompatível','MOTOR/VLAB HOLD'),
('T21','Forma normal/transf.','Retenção anatômica/slots/2 Anéis da Alma exige fonte','MOTOR/VLAB HOLD'),
('T22','T9 custo','N06,N11,N16,N17,N21,N22,N23 possuem déficits de base, sem T9 certificada','MOTOR/VLAB HOLD'),
('T23','Reconfiguração N23→N24','Não inferir troca física de itens da diferença de 454 PA/dia','MOTOR/VLAB HOLD'),
('T24','Selo de Emergência','Não fornecer Vida temporária nem pagar carga se magnitude não definida','MOTOR/VLAB HOLD'),
('T25','Escudo sem CA','Não atribuir bônus físico/mágico improvisado','MOTOR/VLAB HOLD'),
('T26','CD Espiritual','Proficiencia+INT transformada+bonificadores ativos comprovados; três SP com salva','MOTOR/VLAB HOLD'),
('T27','Uma família/slot','16 famílias por nível sem duplicação','TESTE DE DADOS PASS'),
('T28','Arsenal 25x16','400 slots, custos 25/25 aritmeticamente reconciliados','TESTE DE DADOS PASS')]
with (ROOT/'CENAS_DE_REGRESSAO_E_INTEGRACAO.md').open('w',encoding='utf-8') as f:
    f.write('# LEVEL-UP Orc — 28 cenários de validação, sem motor paralelo\n\n')
    f.write('**Cenários pendentes de execução no VLAB/nativo.** Resultado é gate esperado, nunca inventar execução. Os dois cenários aritméticos passaram apenas em Python local.\n\n')
    f.write('| ID | Cena | Condição observável / invariante | Status |\n|---|---|---|---|\n')
    for t,n,x,state in TEST_RECIPES:f.write(f'| {t} | {n} | {x} | {state} |\n')

# Lightweight invariant tests, not combat engine.
class AuditTests(unittest.TestCase):
    def test_01_families(self): self.assertEqual(len(NAMES),16)
    def test_02_ranks(self): self.assertEqual(len(RANKS),5)
    def test_03_no_duplicate_items(self):self.assertEqual(len(set(NAMES)),16)
    def test_04_nominal_cells(self):self.assertEqual(len(entries),80)
    def test_05_all_cells_hold(self):self.assertTrue(all(x['ri_homologado'] is None and x['fip_homologada'] is None for x in entries))
    def test_06_total_25(self):self.assertEqual(len(SNAPS),25)
    def test_07_total_400(self):self.assertEqual(sum(len(x['pa_por_item']) for x in SNAPS),400)
    def test_08_total_expected(self):self.assertEqual([x['pa_diario'] for x in SNAPS],EXPECTED)
    def test_09_activation_costs(self):self.assertEqual(ACTIVE_USE,[3,7,14,21,30])
    def test_10_active_daily(self):self.assertEqual(ACTIVE_DAILY,[3,6,12,17,25])
    def test_11_daily_floor(self):self.assertEqual(DAILY_FLOOR,[8,11,21,35,90])
    def test_12_attr_progression(self):self.assertEqual(ATTRIBUTE,[1,4,6,8,10])
    def test_13_n05_upcharge(self):self.assertEqual(SNAPS[4]['pa_diario']-SNAPS[3]['pa_diario'],16)
    def test_14_armor_phys(self):self.assertEqual(ARMOR_PHYS,[14,18,22,26,30])
    def test_15_armor_magic(self):self.assertEqual(ARMOR_MAGIC,[1,2,3,5,8])
    def test_16_axe(self):self.assertEqual(AXE_BASE,[4,6,8,10,12])
    def test_17_burst(self):self.assertEqual(AXE_BURST,[1,2,4,9,16])
    def test_18_dme(self):self.assertEqual([3.5*(x+y) for x,y in zip(AXE_BASE,AXE_BURST)],[17.5,28,42,66.5,98])
    def test_19_dme_sword(self):self.assertEqual([4.5*x for x in SWORD_D8],[9,13.5,18,22.5,27])
    def test_20_arnes_unchanged(self):self.assertTrue(all(benefit(13,r)==benefit(13,0) for r in range(5)))
    def test_21_keep_reserve(self):self.assertTrue(all(x['pa_por_item'][13:]==[0,0,0] for x in SNAPS))
    def test_22_bronze_active(self):self.assertEqual([len(x['energizados']) for x in SNAPS[:5]],[8,10,11,12,13])
    def test_23_n24_mixed(self):self.assertEqual(SNAPS[23]['pa_por_item'][:10],[90,90,21,21,11,35,11,35,21,21])
    def test_24_legend_cost_drop(self):self.assertEqual(SNAPS[22]['pa_diario']-SNAPS[23]['pa_diario'],454)
    def test_25_13_active_middle(self):self.assertTrue(all(len(x['energizados'])==13 for x in SNAPS[5:20]))
    def test_26_09_active_l21_23(self):self.assertTrue(all(len(x['energizados'])==9 for x in SNAPS[20:23]))
    def test_27_10_active_l24_25(self):self.assertTrue(all(len(x['energizados'])==10 for x in SNAPS[23:25]))
    def test_28_no_double_charging(self):self.assertEqual(max(DAILY_FLOOR[2],ATTRIBUTE[2]*5,ACTIVE_DAILY[2]),30)
    def test_29_legend_mixed_not_copy(self):self.assertNotEqual(SNAPS[20]['pa_por_item'],SNAPS[24]['pa_por_item'])
    def test_30_five_documents(self):self.assertTrue(all(p.exists() and p.stat().st_size>3000 for p in rankfiles))
    def test_31_16_per_document(self):self.assertTrue(all(len(re.findall(r'^### \d\d\. ',p.read_text(encoding='utf-8'),re.M))==16 for p in rankfiles))
    def test_32_no_CDs_promoted(self):self.assertTrue(all(x['re_homologado'] is None for x in entries))
    def test_33_all_five_ranks_natural(self):self.assertEqual(sorted(set(x['classificacao'] for x in SNAPS)),sorted(RANKS))
    def test_34_no_80_objects(self):self.assertEqual(len(rankfiles),5)
    def test_35_weak_shield_and_seal(self):self.assertTrue(all('HOLD' in benefit(15,r) and 'HOLD' in benefit(16,r) for r in range(5)))
    def test_36_unique_atlas_axes(self):self.assertEqual(len(set(ATLAS_AXES)),14)
    def test_37_page_uuid_count(self):self.assertEqual(len({x['page_id'] for x in PAGES}),25)
    def test_38_anomalies_above(self):self.assertEqual(sum(x[4]=='ACIMA' for x in MIX_N25),4)
    def test_39_anomalies_below(self):self.assertEqual(sum(x[4]=='ABAIXO' for x in MIX_N25),4)
    def test_40_patch_never_writes(self):self.assertTrue(all(not x['permite_auto_write'] for x in PATCH_INTENT))
    def test_41_per_rank_pages(self):self.assertTrue(all(len(x['paginas'])==5 for x in PATCH_INTENT))
    def test_42_last_page_uuid(self):self.assertTrue(PAGES[-1]['page_url'].endswith('815abca2ce4fb08a8cdc'))
    def test_43_atlas_224_cells(self):self.assertEqual(len(ATLAS_CELLS),224)
    def test_44_atlas_exactly_three_E2(self):self.assertEqual(sum(x['evidencia'].startswith('E2') for x in ATLAS_CELLS),3)
    def test_45_no_false_E0(self):self.assertTrue(all(not x['evidencia'].startswith('E0') for x in ATLAS_CELLS))
    def test_46_28_test_recipes(self):self.assertEqual(len(TEST_RECIPES),28)
    def test_47_nonlocal_suite_not_faked(self):self.assertEqual(sum(x[3]=='MOTOR/VLAB HOLD' for x in TEST_RECIPES),26)
    def test_48_shield_no_numeric_CA(self):self.assertTrue(all('HOLD' in benefit(15,r) for r in range(5)))

suite=unittest.defaultTestLoader.loadTestsFromTestCase(AuditTests)
with (ROOT/'TESTE_LOCAL.txt').open('w',encoding='utf-8') as f:
    tr=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
assert tr.wasSuccessful() and tr.testsRun==48

# reproducible snapshot via independent unit tests in a single script
# manifest of file contents before archive
manifest=[]
for p in sorted(ROOT.iterdir()):
    if p.is_file() and p.name not in ('MANIFEST_SHA256.json',):
        manifest.append(dict(filename=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ROOT/'MANIFEST_SHA256.json').write_text(json.dumps({'scope':'MESTRE ONLY, TEST, não aplicado no Notion','files':manifest},ensure_ascii=False,indent=2),encoding='utf-8')
zipname=ROOT.parent/'LEVELUP_ORC_MECANICA_5_CLASSIFICACOES_16_ITENS_TEST.zip'
with zipfile.ZipFile(zipname,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.iterdir()):
        if p.is_file():z.write(p,arcname=p.name)
print(json.dumps(dict(zip=str(zipname),sha256=hashlib.sha256(zipname.read_bytes()).hexdigest(),files=len(list(ROOT.iterdir())),tests=tr.testsRun,rank_docs={p.name:p.stat().st_size for p in rankfiles},entries=len(entries),snapshots=len(SNAPS),slots=sum(len(x['pa_por_item']) for x in SNAPS)),ensure_ascii=False,indent=2))
