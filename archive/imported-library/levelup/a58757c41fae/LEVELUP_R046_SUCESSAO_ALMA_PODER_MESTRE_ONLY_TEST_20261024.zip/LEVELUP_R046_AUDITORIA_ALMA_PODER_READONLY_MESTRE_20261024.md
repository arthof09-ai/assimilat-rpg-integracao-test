# LEVEL-UP — R046 candidato de auditoria / ALMA x PODER DO ORC

**MESTRE-ONLY / READ-ONLY / NÃO PUBLICADO NO NOTION / NÃO É CHECKPOINT CANÔNICO.**
Operação existente: LEVEL-UP-ENGINE / IBX-17, Inbox IBX-114. Último checkpoint canônico relido: P23-045. Fontes estáticas: pacotes R044/R045 (R045 não comprovado como patch oficial), 25 fichas do laboratório e Sistema de Transformação.

## Resposta à decisão do Mestre
A meta adotada pelo Mestre é saldo **>= teto(25% do PA bruto normal)** após **uma T9 autorizada + uma habilidade espiritual**; Bronze N01–N05 não transforma, apenas habilidade normal. Não incluir reservatório transformado T6-B antecipadamente. O teste suplementar R045 adiciona uma ativação de equipamento quando possível, mas é diagnóstico, não norma geral.

### Escolha executável a validar (não aplicar sem GREEN)
1. **N06–N20:** manter exclusivamente itens que já estão fisicamente ON, selecionados no R045 para reservar Alma inclusive para uma ativação acessória separada. Núcleo Couraça+Machado ON em 15/15, capacidade de Manoplas+Cinto+Braçadeiras conservada em 15/15, embora esses efeitos exigirem Ação Padrão/PA por uso. Não dar esses bônus automaticamente.
2. **N21:** distinguir alternativas reais, SEM variantes ON importadas. **Rota ofensiva CORE2:** Couraça L 90/dia + Machado L 90/dia =180/dia; uma T9 L 320 + Sentença do Titã 50 + Ruptura do Machado 30 (ataque de arma posterior, nunca empilhar à Sentença por suposição) deixa 311 PA de 891, piso223, folga88. É orçamento de três eventos com peças já escritas, não execução de scheduler VLAB. **Rota precisão:** Couraça+Machado+Braçadeiras L=270/dia; T9+ED35+Braçadeiras30 deixa236, folga13; T9+Sentença50 sem Braçadeiras deixa251, folga28. Escolher **antes** de comprometer PA/dia, sem trocar energia no meio do dia para recuperar custo.
3. **N22–N23:** Couraça+Machado+Braçadeiras (270/dia), T9+Sentença50+Braçadeiras30 ->260 e299, pisos233/243, sempre com preparação/ação a verificar; os outros seis acessórios L desligados não dão bônus.
4. **N24–N25:** manter a ficha como está (356/dia) apenas na prévia; revisar primeiro transição N23→N24 e proveniência das variantes de rank misto. Não chamar upgrade adquirido ou balanço completo.
5. **N01–N05:** manter custos originais; Bronze sem T9. Não aplicar regra universal de 25% via transformação nesse patamar.

### Alternativa de risco: RESERVA25 + 10 PA ADICIONAIS, sem perder a tríade de combate
Quando for indispensável margem operacional além do piso, um subconjunto simples **do próprio R045** pode assegurar pelo menos **10 PA acima do piso** depois de T9+ED+uma ativação: N07 desligar S07 Elmo (−11/dia), N08 S12 Insígnia (−11), N09 S08 Capa (−11), N10 S11 Anel de Golpe (−11), N11 S05 Botas (−30), N12 S06 Anel da Guarda (−21), N18 S06 Anel da Guarda (−35). Os demais níveis mantêm o plano R046 e já cumprem o extra10. Verificação: **20/20** elegíveis com margem≥10; nos 15 N06–N20 permanecem S01/S02/S03/S04/S09 energizados. **Trade-off claro:** cada perda retira uma opção tática condicional, então NÃO homologar equivalência de poder ou supor que tirar Elmo/Anel/Boots é gratuito. Esta é opção de preparação de carga diária, NÃO refund em combate nem patch aplicado.

### CANÁRIO MATERIAL N06 — especificação PREPARADA, ainda não executada
N06 ANTES: bruto216; PA/dia179; PA livre37 (não paga nem T9 Prata40). S01/S02/S03/S04/S05/S06/S07/S08/S09/S10/S11/S12/S13 energizados; demais reservas. DEPOIS PROPOSTO: energizar apenas **S01/S02/S03/S04/S05/S09**, desligar exatamente **S06/S07/S08/S10/S11/S12/S13**; custo diário93; PA livre normal123. T9=40, Pisada=12, um uso Manoplas=7 -> reserva64, piso54, folga10. Só atualizar depois de snapshot, prova de writer GREEN e inspeção do efeito de cada peça desenergizada. CA física da Couraça e arma base permanecem NOMINAIS; perdas incluem Reação do Anel da Guarda, Elmo anti-medo e outras opções situacionais. Ações da Prata em três eventos não se executam automaticamente no mesmo turno/transformação.

### AÇÕES E JANELAS — portas científicas antes de qualquer alegação de combate
| Tier | T9 | ED referência | Extra energizado | Duração mínima teórica | Conclusão |
|---|---|---|---|---|---|
| Prata | Ação Completa | Pisada: Padrão | Manoplas: Padrão | 2 turnos | T9+ED+buff em sequência não comprovados dentro do mínimo; pode exigir 3 momentos de Padrão/Completa |
| Ouro | Ação Padrão | Terremoto: Padrão | Manoplas: Padrão | 2 turnos | Três ações Padrão não cabem automaticamente em 2 turnos; T9+ED sim requer scheduler |
| Ouro Negro | Movimento | Bastião: Padrão | Manoplas: Padrão | 2 turnos | Possível só com atribuição real de ações e duração; sem engine PASS |
| Lendário | Livre | Sentença: Completa | Machado: ataque posterior | 3 turnos | Plano N21 em rodadas distintas é candidato, não stacking nem execução VLAB |

### Prova de impossibilidade e escolha de menor custo
Com N21 FULL (9 itens L de 90 PA/dia =810), PA bruto891 e T9 320+ED50, a reserva seria 891−810−320−50=−289, muito abaixo do piso223. Para **manter os nove energizados** e ainda terminar com 25% após T9+ED50, faltaria um ganho direto de **683 PA brutos sem custo diário**; se esse ganho viesse de item L de 90 PA/dia, exigiria no mínimo **803 PA brutos adicionados**, considerando que o próprio piso de25% também cresce. Isso é uma **conta de impossibilidade**, não recomendação de fabricar tal item. Um bônus de +10 INT de equipamento com custo nominal 50/dia não demonstra ganho retroativo de Alma; em L há piso90/dia.

### Ressalvas para não fingir que o Orc manteve exatamente a mesma força
- A **base física** dos itens de combate Couraça/Machado permanece disponível nos cálculos, mas desenergizar S03–S09 suprime as **opções condicionais de bônus** naquele dia: +FOR/+CON/+DES temporários, +acerto preparado, defesa reativa, etc. A equivalência de CA e dano sustentado precisa ser verificada em forma normal e transformada, especialmente em VLAB. Não afirmar que o conjunto completo se manteve.
- R045 verifica apenas PA matemático: em Prata T9 é Ação Completa e, em Ouro, Ação Padrão; manoplas e a maioria das técnicas usam Ação Padrão. A sequência de três usos pode demandar várias rodadas, e a transformação pode durar somente 2 turnos pelo mínimo do dado. Um saldo suficiente não demonstra sequência **temporal** válida. Em Ouro Negro T9 é Movimento; em L é Ação Livre, mas Sentença do Titã é Ação Completa. Não colapsar atos distintos nem somar golpes sem gatilho.
- O TEST conservador usa Alma normal bruta e não antecipa reserva T6-B; prioridade de gasto entre reservas transformadas ainda requer contrato. Drenagem hipotética100/200 não é um limiar de morte oficial.
- As seis configurações de margem menor que5 depois do teste ampliado (N07, N08, N10, N11, N12, N18) merecem atenção extra: qualquer nova cobrança fora do cenário as derruba abaixo da meta.

## Auditoria por nível: PROPOSTA, não ficha escrita
| Nível | Bruto | PA/dia físico | PA/dia candidato | T9 | ED | Uso equipamento | PA final | Piso25% | Margem |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| N01 | 122 | 64 | 64 | — | 6 | 0 | 52 | 31 | 21 |
| N02 | 131 | 80 | 80 | — | 6 | 0 | 45 | 33 | 12 |
| N03 | 142 | 88 | 88 | — | 6 | 0 | 48 | 36 | 12 |
| N04 | 154 | 96 | 96 | — | 6 | 0 | 52 | 39 | 13 |
| N05 | 168 | 112 | 112 | — | 6 | 0 | 50 | 42 | 8 |
| N06 | 216 | 179 | 93 | 40 | 12 | 7 | 64 | 54 | 10 |
| N07 | 234 | 179 | 115 | 40 | 12 | 7 | 60 | 59 | 1 |
| N08 | 253 | 179 | 126 | 40 | 12 | 7 | 68 | 64 | 4 |
| N09 | 273 | 179 | 137 | 40 | 12 | 7 | 77 | 69 | 8 |
| N10 | 295 | 179 | 159 | 40 | 12 | 7 | 77 | 74 | 3 |
| N11 | 367 | 309 | 153 | 80 | 24 | 14 | 96 | 92 | 4 |
| N12 | 390 | 309 | 174 | 80 | 24 | 14 | 98 | 98 | 0 |
| N13 | 414 | 309 | 174 | 80 | 24 | 14 | 122 | 104 | 18 |
| N14 | 439 | 309 | 195 | 80 | 24 | 14 | 126 | 110 | 16 |
| N15 | 465 | 309 | 216 | 80 | 24 | 14 | 131 | 117 | 14 |
| N16 | 578 | 475 | 185 | 160 | 35 | 21 | 177 | 145 | 32 |
| N17 | 607 | 475 | 225 | 160 | 35 | 21 | 166 | 152 | 14 |
| N18 | 636 | 475 | 260 | 160 | 35 | 21 | 160 | 159 | 1 |
| N19 | 666 | 475 | 260 | 160 | 35 | 21 | 190 | 167 | 23 |
| N20 | 697 | 475 | 295 | 160 | 35 | 21 | 186 | 175 | 11 |
| N21 | 891 | 810 | 180 | 320 | 50 | 30 | 311 | 223 | 88 |
| N22 | 930 | 810 | 270 | 320 | 50 | 30 | 260 | 233 | 27 |
| N23 | 969 | 810 | 270 | 320 | 50 | 30 | 299 | 243 | 56 |
| N24 | 1008 | 356 | 356 | 320 | 50 | 14 | 268 | 252 | 16 |
| N25 | 1048 | 356 | 356 | 320 | 50 | 14 | 308 | 262 | 46 |

**Nota de denominador:** 25/25 perfis PASS apenas na aritmética desta proposta (20/20 com T9 e 5/5 Bronze sem T9); N21 usa ativação de arma, NÃO a exigência de acessório adicional de R045. R045 estrito de acessório continua 19/20; o N21 não é “resolvido” naquela métrica. 0/25 fichas TEST modificadas; 0/20 VLAB homologados.

## Segurança / passo seguinte
LAST-VERIFIED CANÔNICO: P23-045 (Notion). LAST-VERIFIED LOCAL: R046 AUDIT APENAS (algebra 25/25, sem writer). FIRST-PENDING: identificar writer legítimo e gate de BLOCK-PERMIT GREEN; sem isso RED/READ-ONLY. Antes de mutação: preimagem por página, contratos de slot/exclusividade/ações, ensaio de canário N06 ou N11, readback, comparar combate VLAB, atualizar Diário e IBX-114 depois de NAC-PASS; N21 testar duas rotas sem crossrank. NO-REPEAT: 400 slots, 25 páginas, pacotes R040–R045, Ficha Base original, nenhuma criação de item CRAFT, no Party/O Primeiro.
