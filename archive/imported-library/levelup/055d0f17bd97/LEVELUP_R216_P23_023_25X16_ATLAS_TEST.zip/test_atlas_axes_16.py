import unittest
from atlas_axes_16 import AXES,SPECIFIED,PENDING,cells
class AtlasGrid(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=cells()
 def test_axis_count(self):self.assertEqual(len(AXES),14)
 def test_total_224(self):self.assertEqual(len(self.r),224)
 def test_every_item_14(self):
  for i in range(1,17):self.assertEqual(sum(x['slot']==i for x in self.r),14)
 def test_only_status_options(self):self.assertEqual(set(x['status'] for x in self.r),{'DESCRITO_EM_TEST_NAO_HOMOLOGADO','HOLD_CONTRATO_OU_BENCHMARK','SEM_EFEITO_DECLARADO_NO_TEST_NAO_INFERIR'})
 def test_no_ri_fip_authorization(self):self.assertTrue(all(not x['ri_certified'] and not x['fip_certified'] for x in self.r))
 def test_1_defense(self):self.assertEqual(next(x['status'] for x in self.r if x['slot']==1 and x['axis']=='defesa'),'DESCRITO_EM_TEST_NAO_HOMOLOGADO')
 def test_1_action_pending(self):self.assertEqual(next(x['status'] for x in self.r if x['slot']==1 and x['axis']=='economia_acoes'),'HOLD_CONTRATO_OU_BENCHMARK')
 def test_2_axe_hit(self):self.assertEqual(next(x['status'] for x in self.r if x['slot']==2 and x['axis']=='confiabilidade'),'DESCRITO_EM_TEST_NAO_HOMOLOGADO')
 def test_shield_unknown(self):self.assertEqual(next(x['status'] for x in self.r if x['slot']==15 and x['axis']=='defesa'),'HOLD_CONTRATO_OU_BENCHMARK')
 def test_seal_unknown(self):self.assertEqual(next(x['status'] for x in self.r if x['slot']==16 and x['axis']=='defesa'),'HOLD_CONTRATO_OU_BENCHMARK')
 def test_attack_ring_off(self):self.assertIn('ofensiva',SPECIFIED[11])
 def test_legal_strategy_pending(self):self.assertTrue(all('impacto_estrategico' in PENDING[i] for i in range(1,17)))
 def test_no_dup_axis(self):
  for i in range(1,17):self.assertEqual(set(SPECIFIED[i])&set(PENDING[i]),set())
 def test_no_unnamed_axis(self):
  for i in range(1,17):self.assertTrue(set(SPECIFIED[i]+PENDING[i])<=set(AXES))

if __name__=='__main__':unittest.main()
