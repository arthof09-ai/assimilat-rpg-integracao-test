# P23-022 — ACHADOS MECÂNICOS VERIFICADOS / CENÁRIOS TEST

**Fonte-mãe:** [Diário LEVEL-UP P23-018..021](https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107). Último checkpoint no início da rodada: P23-021. Fichas originais NO-WRITE.

## Couraça — seis snapshots

| Ficha | CA física | CA mágica CONDICIONAL | PA/dia | PA/ativação pela política de rank vigente |
|---|---:|---:|---:|---:|
| Bronze N01 | +14 | +1 | 8 | 3 |
| Prata N06 | +18 | +2 | 11 | 7 |
| Ouro N11 | +22 | +3 | 21 | 14 |
| Ouro Negro N16 | +26 | +5 | 35 | 21 |
| Lendário N21 | +30 | +8 | 90 | 30 |
| Lendário N25 | +30 | +8 | 90 | 30 |

**ALERTA DE FRONTEIRA E2/E3:** já em Bronze, +14 CA física da Couraça TEST é numericamente superior à Armadura Guardiã Elemental Ouro Negro +12 e à Armadura Pesada Ouro Negro +13; estas duas últimas possuem outros efeitos (RD, atributos, salvaguardas, dano, alcance situacional), então **não é comparação integral** e não autoriza reduzir ou aumentar automaticamente RI/FIP. A classificação TEST por usuário é não comprovada. Também falta ação da proteção mágica, mecanismo de empilhamento e compatibilidade quadrúpede.

## Machado — seis snapshots

| Ficha | Dado base | Média base | Ruptura pós-acerto | Média extra | Média 1 golpe elegível |
|---|---|---:|---|---:|---:|
| Bronze N01 | 4d6 | 14 | 1d6 | 3,5 | 17,5 |
| Prata N06 | 6d6 | 21 | 2d6 | 7 | 28 |
| Ouro N11 | 8d6 | 28 | 4d6 | 14 | 42 |
| Ouro Negro N16 | 10d6 | 35 | 9d6 | 31,5 | 66,5 |
| Lendário N21–25 | 12d6 | 42 | 16d6 | 56 | 98 |

Ruptura 1/descanso, 30 PA por uso na versão L somente com acerto e economia de ações legal. Sem crítico, RD, chance de acerto, FF concedida ou transformada. Dano-base L 42 fica abaixo de banda DME L padrão 58–160, enquanto golpe condicionado98 fica dentro; **não prova rank do item por si só**. Arco Exterminador Elemental L 8d8+25 média61, +8d12+10 média62 contra elemental (condicionado123); Espada Chamas Vivas ON média65.

## ALERTA NOVO — Custos e T9 por classificação

Pelos saldos publicados no Diário P23-018, 5 Bronze não são elegíveis; entre os 20 seguintes, 15 cobrem T9 aritmeticamente e 5 têm PA insuficiente: N16,N17,N21,N22,N23. 0 ativações reais comprovadas.

**Possível lacuna de tarifa:** as fichas Prata usam +4 FOR/CON/DES/INT por ativação com manutenção piso de 11 PA/dia cada; referência de atributo +1 =5 PA/dia aplicada em N25 seria 20 PA/dia por peça se de fato se aplicasse ao efeito TEMPORÁRIO. Ouro +6 seria30 vs piso21, ON +8 seria40 vs35. A regência efetiva de tarifa por buff de dois turnos exige reconsulta do fornecedor PA R26/R27 e NAC-NORM, pois um campo INT pode ser restrito a perícia. CENÁRIOS NÃO SÃO COBRANÇAS OFICIAIS.

**Gargalo estrutural N23→N24:** N21–N23 9 peças declaradas Lendário com 9×90=810 PA/dia. N24–N25 adotaram loadout misto que custa356. A diferença454 PA/dia explica, junto ao crescimento natural de 39 PA, salto N23 livre159→N24 livre652 (=+493). Trata-se de mudança de loadout, não de mérito automático de nível. Contrato histórico/posse e origem da transição HOLD.

**Correção segura apenas como cenário:** N16/N17, desligar duas peças ON não atributivas antes da cena (slots12,13) liberaria70PA, tornando seus saldos 193/222 e T9 33/62 após o custo160. Se a tarifa de +8 atributo 5PA/nível incidir nas quatro peças mesmo após desligamentos, o extra20 reduz saldos residuais a13/42. N21–N23, desligar 3 peças Lendárias antes da cena (slots7,8,9) reduziria custo810→540, saldos351/390/429 e T9 31/70/109 após custo320. Nenhuma comutação foi gravada ou validada por ato de personagem; podem existir obrigações de manutenção e impossibilidade de troca antes da cena.

N06, N11, N16 sob possível tarifação completa dos quatro buffs (+4/+6/+8) teriam déficits T9 de -3/-22/-57 no loadout original, mesmo que o saldo publicado atualmente seja suficiente em N06/N11; isso mostra por que preços não podem ser corrigidos em lote antes de consultar motor oficial. Sem alterar fichas.

## OUTROS BLOQUEIOS

- 16 famílias × 5 classes: 0/16 homologação final RI/FIP; snapshot cobre 6 estados (N01,N06,N11,N16,N21,N25), não todas as 25 fichas.
- Slots 14 Espada, 15 Escudo, 16 Selo em reserva: efeitos não homologados, não forçar custos de ativação.
- Capa/Braçadeiras têm funções defensivas legadas até N23 e outras funções no loadout N24/25; **drift sem contrato de migração** — não somar efeitos entre versões.
- Reação única Couraça/Anel/Carapaça; CD ED somente SP01/SP03/SP05, ainda não fechadas.
- FF first reach/rolagem de ator, espiritos/formas, rings T6-B, GitHub native P23/VLAB: HOLD.
