"""Source-oriented 14-axis intake. Does not infer rank from coverage."""
from audit import ITEM_NAMES
AXES=(
 'ofensiva','defesa','controle','mobilidade','suporte','informacao_percepcao',
 'invocacao_criacao','alcance_area','duracao_permanencia','economia_acoes',
 'confiabilidade','bypass','versatilidade','impacto_estrategico'
)
# The labels reflect which effect properties were found in the TEST source; no rank E0.
SPECIFIED={
 1:('defesa','mobilidade','duracao_permanencia'),
 2:('ofensiva','alcance_area','duracao_permanencia','confiabilidade'),
 3:('suporte','duracao_permanencia'),
 4:('suporte','duracao_permanencia'),
 5:('suporte','duracao_permanencia'),
 6:('defesa','confiabilidade'),
 7:('suporte','controle','duracao_permanencia'),
 8:('informacao_percepcao','duracao_permanencia'),
 9:('ofensiva','confiabilidade'),
 10:('suporte','informacao_percepcao'),
 11:('ofensiva',),
 12:('suporte','controle','alcance_area'),
 13:('mobilidade','controle'),
 14:('ofensiva',),
 15:(),
 16:(),
}
PENDING={
 1:('economia_acoes','confiabilidade','bypass','versatilidade','impacto_estrategico'),
 2:('economia_acoes','bypass','versatilidade','impacto_estrategico'),
 3:('economia_acoes','confiabilidade','versatilidade','impacto_estrategico'),
 4:('economia_acoes','confiabilidade','versatilidade','impacto_estrategico'),
 5:('economia_acoes','confiabilidade','mobilidade','impacto_estrategico'),
 6:('economia_acoes','duracao_permanencia','versatilidade','impacto_estrategico'),
 7:('economia_acoes','confiabilidade','versatilidade','impacto_estrategico'),
 8:('economia_acoes','confiabilidade','versatilidade','impacto_estrategico'),
 9:('economia_acoes','duracao_permanencia','versatilidade','impacto_estrategico'),
 10:('economia_acoes','confiabilidade','duracao_permanencia','impacto_estrategico'),
 11:('economia_acoes','duracao_permanencia','confiabilidade','impacto_estrategico'),
 12:('economia_acoes','duracao_permanencia','confiabilidade','impacto_estrategico'),
 13:('economia_acoes','duracao_permanencia','confiabilidade','impacto_estrategico'),
 14:('economia_acoes','confiabilidade','bypass','versatilidade','impacto_estrategico'),
 15:('defesa','economia_acoes','confiabilidade','duracao_permanencia','impacto_estrategico'),
 16:('defesa','suporte','economia_acoes','confiabilidade','duracao_permanencia','impacto_estrategico'),
}

def cells():
    a=[]
    for slot,name in enumerate(ITEM_NAMES,1):
        for axis in AXES:
            if axis in SPECIFIED[slot]:status='DESCRITO_EM_TEST_NAO_HOMOLOGADO'
            elif axis in PENDING[slot]:status='HOLD_CONTRATO_OU_BENCHMARK'
            else:status='SEM_EFEITO_DECLARADO_NO_TEST_NAO_INFERIR'
            a.append({'slot':slot,'item':name,'axis':axis,'status':status,'ri_certified':False,'fip_certified':False})
    return a
