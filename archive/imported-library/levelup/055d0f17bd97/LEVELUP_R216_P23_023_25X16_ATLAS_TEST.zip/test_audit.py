import unittest
from audit import *

class Audit(unittest.TestCase):
    def test_rank_safety(self):
        self.assertEqual(RANKS,('Bronze','Prata','Ouro','Ouro Negro','Lendário'))
        self.assertEqual([ITEM_FLOOR[r] for r in RANKS],[8,11,21,35,90])
        self.assertEqual([activation_cost(r) for r in RANKS],[3,7,14,21,30])
        self.assertEqual([activated_daily_base(r) for r in RANKS],[3,6,12,17,25])
    def test_source_identity(self):
        self.assertEqual(len(S),6)
        self.assertEqual(len(ITEM_NAMES),16)
        self.assertEqual(len(set(ITEM_NAMES)),16)
        self.assertTrue(all(s.source and len(s.source)==32 for s in S))
        self.assertEqual([s.ordinal for s in S],[1,6,11,16,21,25])
    def test_armors(self):
        self.assertEqual([s.armor_ca for s in S],[14,18,22,26,30,30])
        self.assertEqual([s.armor_reactive_ca for s in S],[1,2,3,5,8,8])
        self.assertTrue(all(s.armor_ca>0 for s in S))
        self.assertTrue(all(s.armor_reactive_ca<s.armor_ca for s in S))
    def test_weapons(self):
        self.assertEqual([s.axe_base_d6 for s in S],[4,6,8,10,12,12])
        self.assertEqual([s.rupture_d6 for s in S],[1,2,4,9,16,16])
        self.assertEqual([damage_mean(s.axe_base_d6) for s in S],[14,21,28,35,42,42])
        self.assertEqual([damage_mean(s.axe_base_d6+s.rupture_d6) for s in S],[17.5,28,42,66.5,98,98])
    def test_slots(self):
        self.assertEqual([len(s.active_slots) for s in S],[8,13,13,13,9,10])
        self.assertEqual([s.daily_pa for s in S],[64,143,273,455,810,356])
        for s in S:
            self.assertEqual(len(set(s.active_slots)),len(s.active_slots))
            self.assertTrue(all(1<=v<=16 for v in s.active_slots))
    def test_legacy_budgets(self):
        self.assertEqual([baseline_pa(s) for s in S],[None,73,94,123,81,692])
        self.assertEqual([T9_COST[s.rank] for s in S],[None,40,80,160,320,320])
        self.assertEqual([baseline_pa(s)-(T9_COST[s.rank] or 0) if s.gross_pa else None for s in S],[None,33,14,-37,-239,372])
    def test_attribute_conditional(self):
        self.assertEqual([attribute_tariff_scenario(s)['extra_daily_if_attribute_tariff_applies'] for s in S if s.gross_pa],[36,36,20,0,0])
        self.assertEqual([attribute_tariff_scenario(s)['t9_after_if_conditional'] for s in S if s.gross_pa],[-3,-22,-57,-239,372])
        # Attribute-restricted +INT may not meet the universal '+1 attribute' tariff semantics.
        self.assertEqual([attribute_tariff_scenario(s,(3,4,5))['t9_after_if_conditional'] for s in S if s.gross_pa],[6,-13,-52,-239,372])
    def test_options_all_conditional(self):
        p,o,on,l=S[1:5]
        a=active_slots_with_reallocation(p,[10])
        self.assertEqual((a['daily_pa_conditional'],a['free_pa_conditional'],a['t9_balance_if_fully_eligible']),(159,57,17))
        b=active_slots_with_reallocation(o,[10])
        self.assertEqual((b['daily_pa_conditional'],b['free_pa_conditional'],b['t9_balance_if_fully_eligible']),(279,88,8))
        c=active_slots_with_reallocation(on,[10,11])
        self.assertEqual((c['daily_pa_conditional'],c['free_pa_conditional'],c['t9_balance_if_fully_eligible']),(400,178,18))
        d=active_slots_with_reallocation(l,[7,8,9])
        self.assertEqual((d['daily_pa_conditional'],d['free_pa_conditional'],d['t9_balance_if_fully_eligible']),(540,351,31))
    def test_l5_prices(self):
        self.assertEqual([ITEM_FLOOR[L5_RANKS[i-1]] for i in S[-1].active_slots],[90,90,21,21,11,35,11,35,21,21])
        self.assertEqual(sum(ITEM_FLOOR[L5_RANKS[i-1]] for i in S[-1].active_slots),356)
    def test_individual_axes(self):
        for i in range(1,17):
            axes=impact_axes(i)
            self.assertTrue(axes)
            self.assertEqual(len(axes),len(set(axes)))
    def test_reserve_not_billed(self):
        for s in S:
            self.assertEqual(len(set(range(1,17))-set(s.active_slots)),16-len(s.active_slots))
    def test_no_auto_legendary(self):
        self.assertEqual(L5_RANKS.count('Lendário'),3)
        self.assertEqual(L5_RANKS[0:2],('Lendário','Lendário'))

if __name__=='__main__':unittest.main(verbosity=2)
