"""Read-only mechanical audit fixtures. Does not implement/replace LEVEL-UP native engine."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

RANKS=('Bronze','Prata','Ouro','Ouro Negro','Lendário')
ITEM_FLOOR={'Bronze':8,'Prata':11,'Ouro':21,'Ouro Negro':35,'Lendário':90}
ABILITY={'Bronze':6,'Prata':12,'Ouro':24,'Ouro Negro':35,'Lendário':50}
T9_COST={'Bronze':None,'Prata':40,'Ouro':80,'Ouro Negro':160,'Lendário':320}
ITEM_NAMES=('Couraça da Muralha','Machado da Ruptura','Manoplas da Bigorna','Cinto do Bastião','Botas da Escarpa','Anel da Guarda','Elmo do Estandarte','Capa do Desfiladeiro','Braçadeiras do Golpe Medido','Amuleto da Forja','Anel de Golpe','Insígnia da Escolta','Arnês Antitombo','Espada da Guarda','Escudo de Passagem','Selo de Emergência')

@dataclass(frozen=True)
class RankSnapshot:
    ordinal:int
    rank:str
    armor_ca:int
    armor_reactive_ca:int
    axe_base_d6:int
    rupture_d6:int
    daily_pa:int
    active_slots:tuple[int,...]
    gross_pa:Optional[int]
    attribute_increase:int
    attribute_slots:tuple[int,...]
    source:str

SOURCES={
'Bronze':'400c2b324ede815cb828dbd345c48724',
'Prata':'400c2b324ede814a8e56fa1275e2bfe3',
'Ouro':'400c2b324ede81459656d6abd27699a3',
'Ouro Negro':'400c2b324ede817d9900f2c240448cb6',
'Lendário':'400c2b324ede815d8028ca7767b78e1f',
'L5':'400c2b324ede815abca2ce4fb08a8cdc'}
S=(
RankSnapshot(1,'Bronze',14,1,4,1,64,(1,2,3,4,5,6,7,8),None,1,(3,4,5),SOURCES['Bronze']),
RankSnapshot(6,'Prata',18,2,6,2,143,tuple(range(1,14)),216,4,(3,4,5,10),SOURCES['Prata']),
RankSnapshot(11,'Ouro',22,3,8,4,273,tuple(range(1,14)),367,6,(3,4,5,10),SOURCES['Ouro']),
RankSnapshot(16,'Ouro Negro',26,5,10,9,455,tuple(range(1,14)),578,8,(3,4,5,10),SOURCES['Ouro Negro']),
RankSnapshot(21,'Lendário',30,8,12,16,810,tuple(range(1,10)),891,10,(3,4,5),SOURCES['Lendário']),
RankSnapshot(25,'Lendário',30,8,12,16,356,tuple(range(1,11)),1048,0,(),SOURCES['L5']),
)
# N25 stage mixed declared rank; not promoting or adjusting.
L5_RANKS=('Lendário','Lendário','Ouro','Ouro','Prata','Ouro Negro','Prata','Ouro Negro','Ouro','Ouro','Ouro','Prata','Ouro','Lendário','Ouro Negro','Ouro Negro')


def damage_mean(n_d6:int)->float: return n_d6*3.5

def activation_cost(rank):return (ABILITY[rank]*60)//100

def activated_daily_base(rank):return ABILITY[rank]//2

def baseline_pa(snapshot):
    if snapshot.gross_pa is None:return None
    return snapshot.gross_pa-snapshot.daily_pa


def attribute_tariff_scenario(snapshot,charged_slots=(3,4,5,10)):
    """Conditional only! Do not assert active temporary attributes always use 5PA/d."""
    if snapshot.gross_pa is None:return None
    extra=0
    for i in charged_slots:
        if i in snapshot.attribute_slots and i in snapshot.active_slots:
            minimum=5*snapshot.attribute_increase
            extra+=max(ITEM_FLOOR[snapshot.rank],minimum)-ITEM_FLOOR[snapshot.rank]
    return dict(extra_daily_if_attribute_tariff_applies=extra,
                adjusted_daily_if_conditional=snapshot.daily_pa+extra,
                free_if_conditional=snapshot.gross_pa-snapshot.daily_pa-extra,
                t9_cost=T9_COST[snapshot.rank],
                t9_after_if_conditional=snapshot.gross_pa-snapshot.daily_pa-extra-T9_COST[snapshot.rank])


def active_slots_with_reallocation(snapshot,off_slots,charged_slots=(3,4,5,10)):
    """Hypothetical reserve switch; not a legal real-time switch or gear transfer."""
    if snapshot.gross_pa is None:return None
    actual=set(snapshot.active_slots)-set(off_slots)
    assert set(off_slots)<=set(snapshot.active_slots)
    if snapshot.ordinal==25:
        prices={i:ITEM_FLOOR[L5_RANKS[i-1]] for i in snapshot.active_slots}
    else:
        prices={i:ITEM_FLOOR[snapshot.rank] for i in snapshot.active_slots}
    daily=sum(prices[i] for i in actual)
    if snapshot.ordinal!=25:
        for i in charged_slots:
            if i in snapshot.attribute_slots and i in actual:
                daily+=max(0,5*snapshot.attribute_increase-ITEM_FLOOR[snapshot.rank])
    free=snapshot.gross_pa-daily
    t9=T9_COST[snapshot.rank]
    return dict(off_slots=sorted(off_slots),daily_pa_conditional=daily,free_pa_conditional=free,t9_pa=t9,t9_balance_if_fully_eligible=free-t9 if t9 is not None else None,
                eligible_by_pa_only=(t9 is not None and free>=t9))


def impact_axes(slot):
    return {1:['defesa','mobilidade','economia_de_acoes','confiabilidade'],
            2:['ofensiva','economia_de_acoes','confiabilidade','bypass'],
            3:['suporte','ofensiva','economia_de_acoes'],
            4:['suporte','defesa','economia_de_acoes'],
            5:['mobilidade','defesa','economia_de_acoes'],
            6:['defesa','economia_de_acoes','confiabilidade'],
            7:['controle','suporte','confiabilidade'],
            8:['percepcao','mobilidade','confiabilidade'],
            9:['ofensiva','economia_de_acoes'],
            10:['suporte','informacao','economia_de_acoes'],
            11:['ofensiva','economia_de_acoes'],
            12:['suporte','controle'],
            13:['defesa','mobilidade'],
            14:['ofensiva','economia_de_acoes'],
            15:['defesa','economia_de_acoes'],
            16:['defesa','suporte','duracao']}[slot]
