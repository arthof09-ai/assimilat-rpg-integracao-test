"""Checks coverage and fail-closed certification in the generated evidence envelope."""
import unittest,json
from pathlib import Path
from audit import ITEM_FLOOR,ITEM_NAMES,S,L5_RANKS,damage_mean
from t9_25_audit import old_t9_gate,READONLY_ALTERNATIVES
D=Path(__file__).parent
J=lambda p:json.loads((D/p).read_text())
class EvidenceEnvelope(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=J('six_snapshots_96_items.json')['levels']
        cls.budgets=J('rank_energy_budgets.json')['budgets']
        cls.t9=J('t9_25_gate_and_reserve_scenarios.json')['rows']
    def test_96_distinct_records(self):
        self.assertEqual(len(self.rows),96)
        self.assertEqual(len({(x['character_grade'],x['slot']) for x in self.rows}),96)
    def test_each_snapshot_has_16(self):
        for level in ('N01','N06','N11','N16','N21','N25'):
            self.assertEqual(sum(x['character_grade']==level for x in self.rows),16)
    def test_no_real_ranks_certified(self):
        self.assertTrue(all(not x['rank_certified'] and not x['fip_certified'] for x in self.rows))
    def test_no_possession(self):
        self.assertTrue(all(x['does_not_imply_possession'] for x in self.rows))
    def test_six_source_ids(self):
        self.assertEqual(len(set(x['notion_ficha_id'] for x in self.rows)),6)
    def test_only_l5_3_comparator_axes(self):
        self.assertEqual([(x['character_grade'],x['slot']) for x in self.rows if x['comparison_confidence_current']=='E2_EIXO_N25_SEM_RI_FINAL'], [('N25',1),('N25',2),('N25',14)])
    def test_daily_per_snapshot(self):
        for i,s in enumerate(S):
            sub=self.rows[16*i:16*(i+1)]
            self.assertEqual(sum(x['daily_pa_published'] for x in sub),s.daily_pa)
            self.assertEqual(sum(x['mode_test']=='ENERGIZADO' for x in sub),len(s.active_slots))
    def test_modes_and_pa_consistent(self):
        for x in self.rows:
            self.assertEqual(x['daily_pa_published']==0,x['mode_test']=='RESERVA_DESLIGADO')
    def test_3_references_not_fip(self):
        self.assertTrue(all(x['last_grade_comparator_source_id'] for x in self.rows))
        self.assertTrue(all(not x['rank_certified'] for x in self.rows))
    def test_six_armor_correct(self):
        self.assertEqual(len([x for x in self.rows if x['slot']==1]),6)
        self.assertTrue(all('CA física' in x['effect_test'] for x in self.rows if x['slot']==1))
    def test_six_axe_correct(self):
        rows=[x for x in self.rows if x['slot']==2]
        self.assertEqual([x['weapon_base_average'] for x in rows],[14,21,28,35,42,42])
        self.assertEqual([x['weapon_one_rider_average'] for x in rows],[17.5,28,42,66.5,98,98])
    def test_25_t9_rows(self):
        self.assertEqual(len(self.t9),25)
        self.assertEqual([x['n'] for x in self.t9],list(range(1,26)))
    def test_5_payblocked(self):
        self.assertEqual([x['n'] for x in self.t9 if x['pa_only']=='BLOCKED_BY_PA'],[16,17,21,22,23])
    def test_5_hypotheticals_no_proof(self):
        self.assertEqual([x['n'] for x in self.t9 if 'readonly_reallocation' in x],[16,17,21,22,23])
        self.assertTrue(all(not x['readonly_reallocation']['proof_of_switching'] for x in self.t9 if 'readonly_reallocation' in x))
    def test_legacy_ranks_are_not_effect_ranks(self):
        self.assertTrue(all(x['required_gates'] for x in self.rows))
        self.assertTrue(all('power_axis_comparator' in x['required_gates'] for x in self.rows))
    def test_six_budget_rows(self):
        self.assertEqual(len(self.budgets),6)
        self.assertEqual([x['daily_pa_test'] for x in self.budgets],[64,143,273,455,810,356])

if __name__=='__main__':unittest.main()
