# LEVEL-UP R216-P23-023 — auditoria mecânica integral de inventário TEST

## Status MESTRE-ONLY / TEST

Pacote reproduzível de **93 testes independentes** `unittest` em Python normal e Python `-O`, sem simular combate nativo, sem edição das 25 fichas e sem certificação do VLAB. Este pacote evolui P23-022 sem substituir os artefatos anteriores.

### Fontes reabertas fisicamente

- [25 fichas Orc TEST — índice Notion original](https://app.notion.com/p/400c2b324ede8137a06bff45c3b5b1bb).
- [Diário LEVEL-UP — P23-018 a P23-022](https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107).
- [Atlas canônico 14 eixos](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab).
- [Kit — correção PA de 20/10/2026](https://app.notion.com/p/3edc2b324ede81d0b25ec2f3be128db6).
- [Transformação](https://app.notion.com/p/3f2c2b324ede81c0ae0ee4e66212edc9).
- GitHub público: `arthof09-ai/assimilat-rpg-integracao-test`, `main`, runner nativo ORIGINAL R216-P12, **não P23**.

### Resultados da verificação

1. **25/25 fichas fisicamente abertas**, 16 alternantes de item por ficha, **400/400 posições conferidas**; cada página reporta 16 alternantes, estado energizado/reserva e custo publicado. O total diário conferido é o somatório dos títulos dos 16 alternantes, não tarifa certificada.
2. Bronze N01–N05: 8,10,11,12,13 energizados → 64,80,88,96,104 PA/dia; Prata N06–N10 13×11=143; Ouro N11–N15 13×21=273; Ouro Negro N16–N20 13×35=455; Lendário N21–N23 9×90=810; Lendário N24/N25 misto 10 peças por 356. **Nenhuma divergência aritmética nos 25 totais publicados**.
3. FF NORMAL publicado 25/25, confrontado com a lista P23-012; não é prova de FIRST-REACH (41 marcos únicos potenciais, zero escolha/rolagem imputada).
4. Uma falha de CONTINUIDADE funcional: a transição N23→N24 reduz compromisso energético em 454 PA/dia ao reconfigurar TODOS os ranks dos slots, não automaticamente pelo nível. N21–N23 não têm proveniência da mudança para carga mista. CENÁRIOS pré-cena para liberar T9 estão **não executados**.
5. O Atlas recebeu matriz explícita de 16 equipamentos ×14 eixos = **224 células**, com campos descrito em TEST / pendente / efeito não declarado; 0/16 RI/FIP homologados. Cobertura de matriz não é certificação.
6. **Drift real de semântica** da Capa e das Braçadeiras: em N01 Capa = bônus Furtividade, Braçadeiras = bônus teste de ataque; N06–N23 ambas = mitigação pós-RD por Reação com escalas 14/25/45/75; N24–N25 retornam Capa furtividade e Braçadeiras acerto. São especificações diferentes, sem contrato de migração provado. Não combinar benefícios de duas versões do mesmo item.
7. Cenários de tarifas +1 atributo=5PA/dia ainda precisam de verificação de aplicabilidade a buffs temporários (especialmente INT restrita) junto ao fornecedor PA. Nada foi reprecificado.
8. T9: 5 Bronze proibidos, cinco outras fichas sem PA no loadout publicado (N16,N17,N21,N22,N23), 15 com PA matematicamente suficiente, **zero ativações reais, cena/descanso/gasto/compatibilidade certificados**. CD ED numéricas SP01/03/05 e runner P23 seguem HOLD.

### Arquivos e execução

- `physical_notional_scan25.csv/json`: 25 evidências de readback de item/PA/FF (fonte Notion específica e last-edited).
- `six_snapshots_96_items.csv/json`: 16×6 posições em seis fotos do sistema, não 25.
- `atlas_16_x_14_axes.csv/json`: 224 células de avaliação mecânica, não promoção de classe.
- `mechanical_semantic_drift_readback.json`: variação causal que impede migração silenciosa.
- `rank_energy_budgets.json`, `t9_25_gate_and_reserve_scenarios.json`: hipóteses explicitamente rotuladas para PA/T9.
- `audit.py`, `t9_25_audit.py`, `scan25.py`, `atlas_axes_16.py`, `semantic_drift.py`: validadores somente leitura de snapshots, não RPG engine, não writer.
- `test_*.py`: verificações de integridade, contagens, crossrank, classe, caso condicional e anti-canonização.

Para reproduzir: `python -m unittest discover -s . -p 'test*.py' -q` e `python -O -m unittest discover -s . -p 'test*.py' -q`.

### Gates

**PASS:** leitura individual dos 25 itens físicos Notion, aritmética dos 400 títulos, regressão de condições, 93 asserts locais × duas configurações.

**HOLD:** qualquer alteracão automática nas fichas, fontes reais de aquisição/produção e faixa interna, primeiro alcance FF, ação/descanso/gasto T9, reserva transformada, transferências de equipamento e anéis, CD ED, GitHub CI nativo P23 e VLAB global. Ficha Base, Party, O Primeiro, CRAFT, VLAB e GitHub não foram modificados nesta operação.
