import unittest
from t9_25_audit import *

class AuditT9(unittest.TestCase):
    def test_25_source_rows(self):self.assertEqual(len(PA_P23_018),25)
    def test_5_rank_categories(self):self.assertEqual(len(GRADE),25)
    def test_bronze_never_eligible(self):
        self.assertEqual(sum(old_t9_gate(i)['pa_only']=='INELIGIBLE_RANK' for i in range(1,26)),5)
    def test_old_pa_sufficiency(self):
        self.assertEqual(sum(old_t9_gate(i)['pa_only']=='PA_SUFFICIENT_ONLY' for i in range(1,26)),15)
    def test_old_pa_blocks(self):
        self.assertEqual([i for i in range(1,26) if old_t9_gate(i)['pa_only']=='BLOCKED_BY_PA'],[16,17,21,22,23])
    def test_original_20_corrected(self):self.assertEqual(old_t9_gate(20)['pa_after_if_legitimate'],82)
    def test_original_legacy_21_23(self):
        self.assertEqual([old_t9_gate(i)['pa_after_if_legitimate'] for i in (21,22,23)],[-239,-200,-161])
    def test_last_two_can_pay_only(self):
        self.assertEqual([old_t9_gate(i)['pa_after_if_legitimate'] for i in (24,25)],[332,372])
    def test_global_denominator(self):
        self.assertEqual(sum(old_t9_gate(i)['pa_only']=='INELIGIBLE_RANK' for i in range(1,26))+
                         sum(old_t9_gate(i)['pa_only']=='BLOCKED_BY_PA' for i in range(1,26))+
                         sum(old_t9_gate(i)['pa_only']=='PA_SUFFICIENT_ONLY' for i in range(1,26)),25)
    def test_five_can_become_affordable_in_hypothetical_loadout(self):
        self.assertEqual(sorted(READONLY_ALTERNATIVES),[16,17,21,22,23])
        for n in READONLY_ALTERNATIVES:
            self.assertGreaterEqual(READONLY_ALTERNATIVES[n]['after_t9'],0)
    def test_no_actual_transformations(self):
        self.assertTrue(all(x['state']=='HYPOTHETICAL_ONLY' for x in READONLY_ALTERNATIVES.values()))
    def test_offload_loss(self):
        self.assertEqual([len(READONLY_ALTERNATIVES[n]['off_slots']) for n in [16,17,21,22,23]],[2,2,3,3,3])
    def test_avoids_importing_n24_gear_into_n21(self):
        self.assertEqual([x['hypothetical_daily'] for n,x in READONLY_ALTERNATIVES.items() if n>=21],[540]*3)
        self.assertNotEqual(540,356)
    def test_contiguous_income(self):
        self.assertEqual([x-y for x,y in zip(N21_TO_N25_GROSS[1:],N21_TO_N25_GROSS[:-1])],[39,39,39,40])
    def test_n23_to_n24_is_loadout_change_not_only_levelup(self):
        self.assertEqual(N21_TO_N25_DAILY[2]-N21_TO_N25_DAILY[3],454)
        self.assertEqual(N21_TO_N25_FREE[3]-N21_TO_N25_FREE[2],493)
    def test_25_values_align_to_legacy_receipt(self):
        self.assertEqual(tuple(PA_P23_018[20:25]),N21_TO_N25_FREE)
    def test_monotone_gross_for_21_25(self):
        self.assertEqual(tuple(sorted(N21_TO_N25_GROSS)),N21_TO_N25_GROSS)
    def test_not_crediting_activation(self):
        self.assertFalse(all(income_only_reallocation(n)['proof_of_switching'] for n in READONLY_ALTERNATIVES))

if __name__=='__main__':unittest.main(verbosity=2)
