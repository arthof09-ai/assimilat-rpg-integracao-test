"""Cross-rank semantic divergence: recorded facts only, not a migration tool."""
from __future__ import annotations
FAMILY_CHANGE={
 'Capa do Desfiladeiro':[
  dict(level='N01',source_id='400c2b324ede815cb828dbd345c48724',kind='SKILL_BONUS',value=2,metric='Furtividade em rochas/penumbra',mode='ON'),
  dict(level='N06',source_id='400c2b324ede814a8e56fa1275e2bfe3',kind='DAMAGE_MITIGATION_REACTION',value=14,metric='mitigação pós-RD',mode='ON'),
  dict(level='N11',source_id='400c2b324ede81459656d6abd27699a3',kind='DAMAGE_MITIGATION_REACTION',value=25,metric='mitigação pós-RD',mode='ON'),
  dict(level='N16',source_id='400c2b324ede817d9900f2c240448cb6',kind='DAMAGE_MITIGATION_REACTION',value=45,metric='mitigação pós-RD',mode='ON'),
  dict(level='N21',source_id='400c2b324ede815d8028ca7767b78e1f',kind='DAMAGE_MITIGATION_REACTION',value=75,metric='mitigação pós-RD',mode='ON'),
  dict(level='N24',source_id='400c2b324ede81789207ccb2bac264b2',kind='SKILL_BONUS',value=10,metric='Furtividade em rochas/penumbra',mode='ON')],
 'Braçadeiras do Golpe Medido':[
  dict(level='N01',source_id='400c2b324ede815cb828dbd345c48724',kind='HIT_CHECK_BONUS',value=2,metric='teste ataque duas mãos',mode='OFF'),
  dict(level='N06',source_id='400c2b324ede814a8e56fa1275e2bfe3',kind='DAMAGE_MITIGATION_REACTION',value=14,metric='mitigação pós-RD',mode='ON'),
  dict(level='N11',source_id='400c2b324ede81459656d6abd27699a3',kind='DAMAGE_MITIGATION_REACTION',value=25,metric='mitigação pós-RD',mode='ON'),
  dict(level='N16',source_id='400c2b324ede817d9900f2c240448cb6',kind='DAMAGE_MITIGATION_REACTION',value=45,metric='mitigação pós-RD',mode='ON'),
  dict(level='N21',source_id='400c2b324ede815d8028ca7767b78e1f',kind='DAMAGE_MITIGATION_REACTION',value=75,metric='mitigação pós-RD',mode='ON'),
  dict(level='N24',source_id='400c2b324ede81789207ccb2bac264b2',kind='HIT_CHECK_BONUS',value=8,metric='teste ataque duas mãos',mode='ON')],
}

def transitions(name):
    src=FAMILY_CHANGE[name];return [(a['level'],b['level'],a['kind'],b['kind']) for a,b in zip(src,src[1:]) if a['kind']!=b['kind']]
