import unittest
from scan25 import rows
from audit import ITEM_FLOOR

class PhysicalScan25(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.a=rows()
 def test_all_25(self):self.assertEqual([a['n'] for a in self.a],list(range(1,26)))
 def test_every_16_toggle(self):self.assertEqual(sum(a['inventory_slot_toggle_count_physically_read'] for a in self.a),400)
 def test_nonzero_cost(self):self.assertTrue(all(a['daily_pa_sum_of_16_item_headings']>0 for a in self.a))
 def test_25_distinct_source(self):self.assertEqual(len({a['source'] for a in self.a}),25)
 def test_25_source_last_edited(self):self.assertTrue(all(a['native_source_last_edit_utc'].endswith('Z') for a in self.a))
 def test_5_grouped_grades(self):self.assertEqual([sum(a['grade']==rank for a in self.a) for rank in ('Bronze','Prata','Ouro','Ouro Negro','Lendário')],[5]*5)
 def test_bronze_active_increases(self):self.assertEqual([a['inventory_active_item_heading_count'] for a in self.a[:5]],[8,10,11,12,13])
 def test_silver_gold_black_active(self):self.assertEqual([a['inventory_active_item_heading_count'] for a in self.a[5:20]],[13]*15)
 def test_legendary_profiles(self):self.assertEqual([a['inventory_active_item_heading_count'] for a in self.a[20:25]],[9,9,9,10,10])
 def test_br_daily(self):self.assertEqual([a['daily_pa_sum_of_16_item_headings'] for a in self.a[:5]],[64,80,88,96,104])
 def test_p_daily(self):self.assertEqual({a['daily_pa_sum_of_16_item_headings'] for a in self.a[5:10]},{143})
 def test_o_daily(self):self.assertEqual({a['daily_pa_sum_of_16_item_headings'] for a in self.a[10:15]},{273})
 def test_on_daily(self):self.assertEqual({a['daily_pa_sum_of_16_item_headings'] for a in self.a[15:20]},{455})
 def test_l_daily(self):self.assertEqual([a['daily_pa_sum_of_16_item_headings'] for a in self.a[20:25]],[810,810,810,356,356])
 def test_l5_mixed_not_universal_rank(self):self.assertNotEqual(356,10*ITEM_FLOOR['Lendário'])
 def test_bronze_all_floor(self):
  for x in self.a[:5]:self.assertEqual(x['daily_pa_sum_of_16_item_headings'],8*x['inventory_active_item_heading_count'])
 def test_pre_l5_all_floor(self):
  for x in self.a[5:23]:self.assertEqual(x['daily_pa_sum_of_16_item_headings'],ITEM_FLOOR[x['grade']]*x['inventory_active_item_heading_count'])
 def test_ff_exact_5_endpoints(self):self.assertEqual([self.a[i-1]['published_normal_ff_from_physical_read'] for i in (1,6,11,16,21,25)],[280,450,650,850,1380,1610])
 def test_t9_only_from_silver(self):self.assertTrue(all(x['t9_cost'] is None for x in self.a[:5]))
 def test_t9_15_sufficient_pa_only(self):self.assertEqual(sum(x['t9_affordable_in_normal_free_pa_only'] for x in self.a),15)
 def test_t9_paup_shortage_ids(self):self.assertEqual([x['n'] for x in self.a if x['t9_cost'] is not None and not x['t9_affordable_in_normal_free_pa_only']],[16,17,21,22,23])
 def test_no_fake_activation(self):self.assertTrue(all(not x['t9_actually_activated'] for x in self.a))
 def test_no_fake_ri(self):self.assertTrue(all(x['ri_fip_homologation_count']==0 for x in self.a))
 def test_only_small_grade_transition_from_n23_n24(self):
  before=self.a[22];after=self.a[23]
  self.assertEqual(before['daily_pa_sum_of_16_item_headings']-after['daily_pa_sum_of_16_item_headings'],454)
  self.assertEqual(after['pa_free_normal_from_P23_018']-before['pa_free_normal_from_P23_018'],493)
  self.assertEqual(after['gross_pa_arithmetic']-before['gross_pa_arithmetic'],39)
 def test_25_free_pa_matches_diary(self):self.assertEqual([x['pa_free_normal_from_P23_018'] for x in self.a[:5]],[58,51,54,58,64])

if __name__=='__main__':unittest.main()
