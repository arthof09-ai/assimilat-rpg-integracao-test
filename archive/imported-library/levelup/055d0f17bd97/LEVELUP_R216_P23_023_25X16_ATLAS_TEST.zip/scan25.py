"""Physically read Notion 25 entries on 2026-10-23; data are a compact frozen audit receipt."""
from __future__ import annotations
from audit import T9_COST
_IDS=('815cb828dbd345c48724','817fba8fde73a1c45020','81d3adc9ef2fdc11604d','81ac9519fd627291eafc','81e883d8e0275f06a674',
'814a8e56fa1275e2bfe3','814889fce8568f04949b','81fcbac7f21254483905','8170b774ea9580ab8e06','81e591ace187c1763b9c',
'81459656d6abd27699a3','81249cbbea651d99dc00','81ffa1f7d112ce18e793','81beb220cc5953504264','81a885b7f80129bfa054',
'817d9900f2c240448cb6','8118a1d0d3a56ee787d9','81a78ff5cc32a157d1b7','81c0a6ded4d52b87ec63','81ef9d94d807933e607b',
'815d8028ca7767b78e1f','81fabc81cf69f0641303','81e894a1f4ac84354ee2','81789207ccb2bac264b2','815abca2ce4fb08a8cdc')
EDIT_DAYS=('2026-10-22T18:06:08.194Z','2026-10-22T18:07:22.153Z','2026-10-22T18:07:24.548Z','2026-10-22T18:07:27.505Z','2026-10-22T18:07:31.344Z',
'2026-10-23T12:19:39.078Z','2026-10-23T12:19:41.363Z','2026-10-23T12:19:43.442Z','2026-10-23T12:19:45.598Z','2026-10-23T12:19:47.945Z',
'2026-10-23T12:19:50.092Z','2026-10-23T12:19:52.055Z','2026-10-23T12:20:38.296Z','2026-10-23T12:20:40.296Z','2026-10-23T12:20:42.428Z',
'2026-10-23T12:20:44.555Z','2026-10-23T12:20:46.762Z','2026-10-23T12:20:48.910Z','2026-10-23T12:20:50.976Z','2026-10-23T12:21:36.033Z',
'2026-10-23T12:21:38.469Z','2026-10-23T12:21:40.814Z','2026-10-23T12:21:42.783Z','2026-10-23T12:21:44.984Z','2026-10-23T12:16:54.494Z')
_ACTIVE=(8,10,11,12,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,9,9,9,10,10)
_DAILY=(64,80,88,96,104,143,143,143,143,143,273,273,273,273,273,455,455,455,455,455,810,810,810,356,356)
_FF=(280,320,350,390,420,450,490,530,570,600,650,700,740,780,820,850,900,950,990,1030,1380,1430,1490,1560,1610)
_PA_FREE=(58,51,54,58,64,73,91,110,130,152,94,117,141,166,192,123,152,181,211,242,81,120,159,652,692)
assert all(len(x)==25 for x in (_IDS,EDIT_DAYS,_ACTIVE,_DAILY,_FF,_PA_FREE))

def rows():
    result=[]
    for z in range(25):
        n=z+1
        grade=['Bronze','Prata','Ouro','Ouro Negro','Lendário'][(n-1)//5]
        result.append({
          'n':n,'source':'https://app.notion.com/p/400c2b324ede'+_IDS[z],
          'native_source_last_edit_utc':EDIT_DAYS[z],
          'inventory_slot_toggle_count_physically_read':16,
          'inventory_active_item_heading_count':_ACTIVE[z],
          'daily_pa_sum_of_16_item_headings':_DAILY[z],
          'pa_free_normal_from_P23_018':_PA_FREE[z],
          'gross_pa_arithmetic':_PA_FREE[z]+_DAILY[z],
          'published_normal_ff_from_physical_read':_FF[z],
          'grade':grade,'t9_cost':T9_COST[grade],
          't9_affordable_in_normal_free_pa_only':T9_COST[grade] is not None and _PA_FREE[z]>=T9_COST[grade],
          't9_actually_activated':False,
          'ri_fip_homologation_count':0,
          'note':'inventário aritmético reconciliado, não certificação do efeito ou recibo de transformação'
        })
    return result
