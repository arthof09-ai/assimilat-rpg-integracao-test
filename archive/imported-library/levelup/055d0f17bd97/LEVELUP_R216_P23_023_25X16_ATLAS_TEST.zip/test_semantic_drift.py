import unittest
from semantic_drift import FAMILY_CHANGE,transitions
class Drift(unittest.TestCase):
 def test_two_item_families(self):self.assertEqual(len(FAMILY_CHANGE),2)
 def test_six_gates_per_item(self):self.assertEqual([len(x) for x in FAMILY_CHANGE.values()],[6,6])
 def test_cape_returns_to_stealth(self):self.assertEqual(FAMILY_CHANGE['Capa do Desfiladeiro'][0]['kind'],FAMILY_CHANGE['Capa do Desfiladeiro'][-1]['kind'])
 def test_bracers_returns_to_hit(self):self.assertEqual(FAMILY_CHANGE['Braçadeiras do Golpe Medido'][0]['kind'],FAMILY_CHANGE['Braçadeiras do Golpe Medido'][-1]['kind'])
 def test_legacy_defense_exact_values(self):
  for k in FAMILY_CHANGE:self.assertEqual([x['value'] for x in FAMILY_CHANGE[k][1:5]],[14,25,45,75])
 def test_transition_count(self):self.assertEqual([len(transitions(x)) for x in FAMILY_CHANGE],[2,2])
 def test_transition_rank_boundary(self):
  for x in FAMILY_CHANGE:
   self.assertEqual([t[:2] for t in transitions(x)],[('N01','N06'),('N21','N24')])
 def test_no_auto_migration_code(self):self.assertTrue(all('source_id' in x for a in FAMILY_CHANGE.values() for x in a))
if __name__=='__main__':unittest.main()
