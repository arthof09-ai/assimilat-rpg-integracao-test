"""Read-only reconciliation with physically recorded R216-P23-018, not a T9 executor."""
from __future__ import annotations
from audit import T9_COST, S, active_slots_with_reallocation, attribute_tariff_scenario

PA_P23_018=(58,51,54,58,64,73,91,110,130,152,94,117,141,166,192,123,152,181,211,242,81,120,159,652,692)
GRADE=tuple('Bronze' for _ in range(5))+tuple('Prata' for _ in range(5))+tuple('Ouro' for _ in range(5))+tuple('Ouro Negro' for _ in range(5))+tuple('Lendário' for _ in range(5))

def old_t9_gate(n):
    rank=GRADE[n-1]
    cost=T9_COST[rank]
    pa=PA_P23_018[n-1]
    if cost is None: return {'n':n,'grade':rank,'free_pa':pa,'t9_cost':None,'pa_only':'INELIGIBLE_RANK'}
    return {'n':n,'grade':rank,'free_pa':pa,'t9_cost':cost,'pa_only':'PA_SUFFICIENT_ONLY' if pa>=cost else 'BLOCKED_BY_PA','pa_after_if_legitimate':pa-cost}

READONLY_ALTERNATIVES={
    # Existing equipment in reserve from before the scene only, not automatic activation.
    # N16 N17 two Ouro Negro item-maintenance commitments hypothetically switched off:
    16:dict(state='HYPOTHETICAL_ONLY',old_free_pa=123,old_daily=455,off_slots=[12,13],hypothetical_daily=385,base_free=193,after_t9=33),
    17:dict(state='HYPOTHETICAL_ONLY',old_free_pa=152,old_daily=455,off_slots=[12,13],hypothetical_daily=385,base_free=222,after_t9=62),
    21:dict(state='HYPOTHETICAL_ONLY',old_free_pa=81,old_daily=810,off_slots=[7,8,9],hypothetical_daily=540,base_free=351,after_t9=31),
    22:dict(state='HYPOTHETICAL_ONLY',old_free_pa=120,old_daily=810,off_slots=[7,8,9],hypothetical_daily=540,base_free=390,after_t9=70),
    23:dict(state='HYPOTHETICAL_ONLY',old_free_pa=159,old_daily=810,off_slots=[7,8,9],hypothetical_daily=540,base_free=429,after_t9=109),
}

def income_only_reallocation(n):
    x=READONLY_ALTERNATIVES[n]
    return dict(n=n,original=x['old_free_pa'],hypothetical=x['base_free'],improvement=x['base_free']-x['old_free_pa'],t9_residual=x['after_t9'],proof_of_switching=False,proof_of_spirit=False,proof_of_scene=False)

N21_TO_N25_GROSS=(891,930,969,1008,1048)
N21_TO_N25_DAILY=(810,810,810,356,356)
N21_TO_N25_FREE=(81,120,159,652,692)
# N24 new configuration is not evidence the same lower-ranked equipment was carried in N21.

if __name__=='__main__':
    for n in range(1,26): print(old_t9_gate(n))
