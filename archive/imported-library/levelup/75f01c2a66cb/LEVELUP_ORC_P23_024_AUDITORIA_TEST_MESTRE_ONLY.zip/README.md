# LEVEL-UP / Orc TEST — P23-024

Bancada **somente leitura e aritmética** baseada nos valores observados diretamente nas 25 páginas do Notion em 23/10/2026, posterior ao P23-023. Os JSON são extratos reconstruídos manualmente dos valores publicados; a suíte não conecta ao Notion e **não é fonte nova**, não substitui motor LEVEL-UP, VLAB, executor GitHub nem prova a validade dos efeitos do jogo.

Executar: `python -m unittest -v test_readonly.py`.

16 equipamentos permanecem projetos TEST e não constituem fichas canônicas individuais. RI/FIP e PS não são concedidos por testes aritméticos. A elegibilidade T9 avalia só PA, sem conceder transformação, FF, uso da forma, cura ou retenção de anéis. A lista de déficits é a dos saldos novos, diferente do P23-023.

Fontes-mãe Notion: operação `3f2c2b32-4ede-81f4-8f80-f6d27449d107`; índice Orc `400c2b32-4ede-8137-a06b-ff45c3b5b1bb`; exemplares N06 `400c2b32-4ede-814a-8e56-fa1275e2bfe3` e N25 `400c2b32-4ede-815a-bca2-ce4fb08a8cdc`; PR-ITEM-02, PR-SC-01, Atlas, DMG-RANK e errata PA 20/10. Nunca usar este zip como autorização de escrita em Party ou como promoção automática a PS/P4.
