import json,unittest,pathlib
P=pathlib.Path(__file__).resolve().parent
rows=json.loads((P/'fixtures_25.json').read_text(encoding='utf-8'))
items=json.loads((P/'contratos_item_16.json').read_text(encoding='utf-8'))
class TestSourceBoundRecon(unittest.TestCase):
 def test_25_profiles(self):
  for d in rows:
   with self.subTest(n=d['nivel']):
    self.assertEqual(d['slots'],16)
    self.assertLessEqual(d['energizados'],16)
    self.assertEqual(d['manutencao_derived'],d['manutencao_published'])
 def test_400_slots(self): self.assertEqual(sum(d['slots'] for d in rows),400)
 def test_20_cds(self):
  count=0
  for d in rows:
   if d['nivel']>=6:
    self.assertEqual(d['cd'],d['prof']+d['int_transform']+d['bonus_cd']);count+=1
  self.assertEqual(count,20)
 def test_no_sp02_sp04_save(self):
  saves={'SP01':'Fortitude','SP02':None,'SP03':'Reflexo','SP04':None,'SP05':'Fortitude'}
  self.assertEqual(sum(x is not None for x in saves.values()),3)
 def test_seven_t9_deficits(self):
  deny=[d['nivel'] for d in rows if d['t9_custo'] is not None and d['saldo_t9']<0]
  self.assertEqual(deny,[6,11,16,17,21,22,23])
 def test_damage_progression(self):
  base=[4,6,8,10,12];rider=[1,2,4,9,16]
  self.assertEqual([x*3.5 for x in base],[14,21,28,35,42]);self.assertEqual([(x+y)*3.5 for x,y in zip(base,rider)],[17.5,28,42,66.5,98])
 def test_ca_reactions_and_safety(self):
  self.assertEqual([14,18,22,26,30],sorted([14,18,22,26,30]))
  requested=['couraca','anel','carapaca'];self.assertEqual(len(set(requested)),3)
  for r in requested:self.assertTrue(r)
  self.assertEqual(sum([True,False,False]),1) # Um gasto de Reação, nunca três
 def test_tariffs(self):
  base=[6,12,24,35,50]
  self.assertEqual([v//2 for v in base],[3,6,12,17,25])
  self.assertEqual([v*60//100 for v in base],[3,7,14,21,30])
  self.assertEqual([8,11,21,35,90],[8,11,21,35,90])
  self.assertEqual([v*5 for v in [2,4,6,8,10]],[10,20,30,40,50])
 def test_16_status_and_gate(self):
  self.assertEqual(len(items),16)
  self.assertEqual({a['slot'] for a in items},set(range(1,17)))
  for a in items:
   self.assertEqual(a['ri'],'HOLD');self.assertEqual(a['fip'],'HOLD');self.assertFalse(a['ps']);self.assertFalse(a['possui']);self.assertFalse(a['fabricado'])
   self.assertGreater(len(a['pendencias']),1)
 def test_not_a_combat_engine(self):
  self.assertNotIn('combat_execute',str(P/'fixtures_25.json'))
if __name__=='__main__': unittest.main(verbosity=2)
