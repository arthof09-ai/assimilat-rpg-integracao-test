import json,pathlib
P=pathlib.Path('/mnt/data/LEVELUP_ORC_P23_024_TEST')
names=['Couraça da Muralha','Machado da Ruptura','Manoplas da Bigorna','Cinto do Bastião','Botas da Escarpa','Anel da Guarda','Elmo do Estandarte','Capa do Desfiladeiro','Braçadeiras do Golpe Medido','Amuleto da Forja','Anel de Golpe','Insígnia da Escolta','Arnês Antitombo','Espada da Guarda','Escudo de Passagem','Selo de Emergência']
roles=['CA física passiva, deslocamento 50%; CA mágica condicionada ao ataque declarado','dano físico 2 mãos; Ruptura condicionada a acerto, PA, 1/descanso','+FOR temporária 2 turnos','+CON temporária 2 turnos; não cura','+DES temporária 2 turnos; não remove penalidade da Couraça','CA mágica em Reação; concorre Couraça/Carapaça','Vontade contra medo até próximo turno','Furtividade rocha/penumbra por 2 turnos','bônus ao TESTE de acerto de arma 2 mãos, 1/cena','+INT somente no teste preparado de Alquimia/Inscrições','bônus de acerto próximo ataque; não causa dano','Vontade de 1 aliado adjacente contra medo','mitiga 1,5m empurrão em solo firme; não evita AoO','arma 1 mão física, dano projetado; alternativa ao machado','compatível com espada de 1 mão; CA física HOLD','consumível de proteção; magnitude/recarga/transferência HOLD']
gates=[
'ri_fip,benchmark_ca,movimento,reatividade,anatomia',
'ri_fip,fonte_dano,alcance,acerto,descanso,anatomia',
'ri_fip,acao,temporario,tarifa',
'ri_fip,acao,duracao,vida_sem_cura,tarifa',
'ri_fip,acao,duracao,ff,ca,tarifa',
'ri_fip,reacao_unica,empilhamento',
'ri_fip,gatilho_medo,escolta',
'ri_fip,ambiente,duracao,migracao',
'ri_fip,preparo,cena,migracao',
'ri_fip,escopo_teste,nao_cd_espiritual,tarifa',
'ri_fip,anel_slots,sem_ataque_extra',
'ri_fip,alvo,alcance,acao',
'ri_fip,terreno,reacao,anatomia',
'ri_fip,origem_dano,sem_efeito_especial_provado',
'ri_fip,ca_escudo_nao_comprovada,mao_livre',
'ri_fip,magnitude,transferencia,consumo'
]
items=[]
for i,(n,role,g) in enumerate(zip(names,roles,gates),1):
  items.append(dict(slot=i,nome=n,papel=role,pendencias=g.split(','),status='TEST',ri='HOLD',fip='HOLD',pr_sc='P2_CANDIDATO' if i<=13 else 'P1_CANDIDATO',ps=False,possui=False,fabricado=False,fonte='Notion Orc N06 e N25; Diário P23-023; PR-ITEM-02/PR-SC-01',sem_reclassificacao_pelo_preco=True))
(P/'contratos_item_16.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
# Snapshot de PA a partir de 25 páginas relidas em 23/10/2026. Contagem de cabeçalhos de cada ficha: 16.
costs=[64,80,88,96,112]+[179]*5+[309]*5+[475]*5+[810]*3+[356]*2
active=[8,10,11,12,13]+[13]*15+[9]*3+[10]*2
free=[58,51,54,58,56,37,55,74,94,116,58,81,105,130,156,103,132,161,191,222,81,120,159,652,692]
cd=[22,24,26,28,31,34,35,37,39,41,48,49,50,52,54,66,69,70,71,73]
profs=[4]*5+[6]*5+[10]*5+[20]*5
int_transform=[18,20,22,24,27,28,29,31,33,35,38,39,40,42,44,46,49,50,51,53]
rows=[]
for i in range(1,26):
  c=costs[i-1]
  if i<=5: t9=None
  elif i<=10:t9=40
  elif i<=15:t9=80
  elif i<=20:t9=160
  else:t9=320
  d={ 'nivel':i,'slots':16,'energizados':active[i-1],'manutencao_published':c,
    'manutencao_derived':(8*active[i-1] if i<=4 else 9*8+4*10 if i==5 else 9*11+4*20 if i<=10 else 9*21+4*30 if i<=15 else 9*35+4*40 if i<=20 else 9*90 if i<=23 else 2*90+4*21+2*11+2*35),
    'pa_livre_published':free[i-1],'t9_custo':t9,'saldo_t9':None if t9 is None else free[i-1]-t9,
    'proveniencia':'Extrato manual dos valores publicados e das 16 posições conferidas no Notion em 23/10/2026; não é leitura viva do teste.'}
  if i>=6:
    d.update(cd=cd[i-6],prof=profs[i-6],int_transform=int_transform[i-6],bonus_cd=0)
  rows.append(d)
(P/'fixtures_25.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
