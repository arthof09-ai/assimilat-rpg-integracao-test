"""Decision-support only, Orc TEST. Exhaustive subset search of previously active
slots, not the PA engine, not a Notion writer or a VLAB simulator.
"""
from pathlib import Path
import json,csv,math,itertools,hashlib
BASE=Path(__file__).parent
R40=json.loads((BASE/'orc_pa_r040_evidence.json').read_text(encoding='utf-8'))['matrix_25_levels_400_slots']
R42=json.loads((BASE/'orc_alma_r042_25_previews.json').read_text(encoding='utf-8'))['results']
T9=(0,40,80,160,320)
TECH=(6,12,24,35,50)
# Multi-objective priority weights. NOT game-rule-derived quantities;
# all weights are declared to avoid presenting a proxy as actual DPS/CA.
STYLES={
 'balanced':{3:90,4:100,5:74,6:35,7:18,8:9,9:110,10:3,11:7,12:12,13:6},
 'attack':{3:130,4:72,5:76,6:20,7:12,8:8,9:140,10:2,11:8,12:7,13:3},
 'guard':{3:75,4:145,5:70,6:48,7:22,8:9,9:90,10:3,11:6,12:15,13:8}
}
GROSS=[122,131,142,154,168,216,234,253,273,295,367,390,414,439,465,578,607,636,666,697,891,930,969,1008,1048]

def score(sel,style):
 w=STYLES[style]
 a=sum(w.get(i,0) for i in sel)
 # Ação Padrão preparations of short temporary buffs are not all
 # simultaneously guaranteed; reduce the proxy score for stacking them.
 k=sum(i in sel for i in (3,4,5))
 a-={0:0,1:0,2:16,3:42}[k]
 # Reação of Anel da Guarda competes with Couraça/SP02; weak independent utility.
 if 6 in sel and 1 in sel:a-=12
 # Same hand/ring restriction in inventory unresolved.
 if 11 in sel:a-=3
 return a

def candidates(level, style):
 n=level['level'];i=n-1; rank_index=i//5
 old=R42[i];gross=GROSS[i];t9=T9[rank_index];tech=TECH[rank_index]
 src={s['slot']:s for s in level['slots'] if s['on']}
 buffer=math.ceil(gross/4)
 cap=gross-t9-tech-buffer
 assert 1 in src and 2 in src
 if rank_index==0:
  use=frozenset(src)
  cost=sum(src[j]['pa_dia_publicado'] for j in use)
  return [dict(n=n,style=style,selected=sorted(use),off=[],cost=cost,post=gross-cost-tech,buffer=buffer,score=score(use,style),margin=gross-cost-tech-buffer,pa_bruto=gross,cost_current=level['total_diario'],n_current_active=len(src),t9=0,tech=tech,cap=cap)]
 opts=list(j for j in sorted(src) if j not in (1,2))
 minscore=None; rows=[]
 for mask in range(1<<len(opts)):
  selected=frozenset([1,2]+[slot for j,slot in enumerate(opts) if mask&(1<<j)])
  cost=sum(src[j]['pa_dia_publicado'] for j in selected)
  if cost>cap:continue
  s=score(selected,style)
  post=gross-cost-t9-tech
  assert post>=buffer
  # Prefer retained functional utility, then less PA commitment for anti-drain
  # resiliency; minimize changes only as third-level tie break.
  key=(s,post,-len(src.keys()-selected))
  row=dict(n=n,style=style,selected=sorted(selected),off=sorted(src.keys()-selected),cost=cost,post=post,buffer=buffer,score=s,margin=post-buffer,pa_bruto=gross,cost_current=level['total_diario'],n_current_active=len(src),t9=t9,tech=tech,cap=cap,key=key)
  if minscore is None or key>minscore:
   minscore=key;rows=[row]
  elif key==minscore:rows.append(row)
 assert rows,(n,cap)
 for row in rows:row.pop('key')
 return rows

def run():
 assert len(R40)==len(R42)==25
 out=[]
 for x in R40:
  n=x['level'];before=R42[n-1]
  assert before['n']==n
  assert sum(s['pa_dia_publicado'] for s in x['slots'])==x['total_diario']
  assert before['pa_dia_previa_TEST']==sum(s['pa_dia_publicado'] for s in x['slots'] if s['slot'] in [s2['slot'] for s2 in before['slots_manter']])
  for st in STYLES:
   r=candidates(x,st)[0]
   oldsel={q['slot'] for q in before['slots_manter']}
   r['p42_selected']=sorted(oldsel)
   r['p42_cost']=before['pa_dia_previa_TEST']
   r['p42_score_same_metric']=score(oldsel,st)
   r['score_vs_p42']=r['score']-r['p42_score_same_metric']
   # Defend core: axe/cuirass never dropped; passive physical equipment base preserved
   # only conditional on physical stats still applying when magical sustain is off.
   assert 1 in r['selected'] and 2 in r['selected']
   assert r['cost']<=x['total_diario']
   if n>5: assert r['post']>=r['buffer']
   assert r['score_vs_p42']>=0, (n,st)
   out.append(r)
 return out

if __name__=='__main__':
 out=run()
 with open(BASE/'r044_75_presets.csv','w',encoding='utf-8-sig',newline='') as f:
  cols=['n','style','pa_bruto','cost_current','cost','t9','tech','post','buffer','margin','score','p42_cost','p42_score_same_metric','score_vs_p42','selected','off','p42_selected']
  w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows({key:(','.join(map(str,row[key])) if isinstance(row[key],list) else row[key]) for key in cols} for row in out)
 with open(BASE/'r044_75_presets.json','w',encoding='utf-8') as f:json.dump({'status':'PROPOSED_TEST_UNAPPLIED','source':'P040 Notion readback 25×16; R042 existing preview; current authorized T9+tech+25% buffer', 'score_note':'Subjective stated prioritization; not damage/defense proof or VLAB. Temporary buffs need Standard Action, 2turn window; Reactions compete. No PA writer.','presets':out},f,ensure_ascii=False,indent=2)
 for r in out:
  if r['style']=='balanced': print('N%02d %-11s slots:%-25s cost %3s->%3s post:%3s buf:%3s score: +%2s vs P42' % (r['n'],(r['n']-1)//5,r['selected'],r['cost_current'],r['cost'],r['post'],r['buffer'],r['score_vs_p42']))
