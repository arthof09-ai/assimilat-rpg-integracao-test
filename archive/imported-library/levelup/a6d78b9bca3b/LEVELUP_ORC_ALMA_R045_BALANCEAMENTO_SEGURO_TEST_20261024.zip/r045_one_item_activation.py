"""TEST advisory: pay T9 + one documented spirit technique + one existing
energized accessory activation + 25% gross PA buffer, preserving armor/axe.
No engine nor actual writer. Uses exact TEST published equipment activation costs.
"""
import itertools,math,json,csv,pathlib
from optimize_r044 import R40,GROSS,T9,TECH,score
BASE=pathlib.Path(__file__).parent
BAL={x['n']:x for x in json.loads((BASE/'r044_75_presets.json').read_text(encoding='utf8'))['presets'] if x['style']=='balanced'}
KEYS={3,4,9}
def find(n):
 row=R40[n-1];g=GROSS[n-1];tier=(n-1)//5; t9=T9[tier]; tech=TECH[tier];buf=math.ceil(g/4)
 if n<=5:return {'n':n,'eligible':False,'preserve_t9':False,'reason':'BRONZE_RULE_VETO'}
 active={x['slot']:x for x in row['slots'] if x['on']};assert {1,2}.issubset(active)
 can=[s for s in sorted(active) if s not in (1,2)]; best=None
 for mask in range(1<<len(can)):
  sel={1,2}|{s for j,s in enumerate(can) if mask&(1<<j)}
  avail=KEYS&sel
  if not avail:continue
  # one activation only, choose the cheapest documented key held
  cost_use=min((active[i]['pa_uso_publicado'],i) for i in avail)
  if not isinstance(cost_use[0],int):continue
  cost=sum(active[i]['pa_dia_publicado'] for i in sel)
  post=g-cost-t9-tech-cost_use[0]
  if post<buf:continue
  key=(score(sel,'balanced'),post,-len(active.keys()-sel))
  if best is None or key>best[0]:best=(key,{'n':n,'eligible':True,'feasible':True,'gross':g,'daily':cost,'selected':sorted(sel),'off':sorted(active.keys()-sel),'t9':t9,'spirit_skill':tech,'item_activation_slot':cost_use[1],'item_activation_cost':cost_use[0],'post_all':post,'buffer25':buf,'margin':post-buf,'core_armor_axe':True,'active_key_count':len(avail),'active_key_slots':sorted(avail),'score_heuristic':key[0]})
 if best:return best[1]
 return {'n':n,'eligible':True,'feasible':False,'gross':g,'buffer25':buf,'reason':'NO_EXISTING_FULL_RANK_SUBSET_WITH_KEY_USE_AND_BUFFER'}
def run():return [find(n) for n in range(1,26)]
if __name__=='__main__':
 a=run();(BASE/'r045_one_extra_item_use_25.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 with (BASE/'r045_one_extra_item_use_25.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['Nível','T9 permitido','Configuração full-rank atende','Manutenção PA/dia','T9','Técnica','Ativação acessório','PA/uso acessório','PA remanescente','25% bruto','Margem','ON slots','OFF slots','Divergência da proposta anterior R044'])
  for x in a:
   n=x['n'];b=BAL[n];w.writerow([n,x['eligible'],x.get('feasible',False),x.get('daily',''),x.get('t9',''),x.get('spirit_skill',''),x.get('item_activation_slot',''),x.get('item_activation_cost',''),x.get('post_all',''),x.get('buffer25',''),x.get('margin',''),','.join(map(str,x.get('selected',[]))),','.join(map(str,x.get('off',[]))), ('NÃO ELIGÍVEL' if n<=5 else ('HOLD: sem subset real' if not x['feasible'] else x['daily']-b['cost']))])
 print('eligible',sum(x['eligible'] for x in a),'pass fullrank',sum(x.get('feasible',False) for x in a),'fails',[x['n'] for x in a if x['eligible'] and not x['feasible']])
 for x in a:
  if x.get('eligible'):print('N%02d'%x['n'],x.get('daily'),x.get('post_all'),x.get('margin'),x.get('selected'))
