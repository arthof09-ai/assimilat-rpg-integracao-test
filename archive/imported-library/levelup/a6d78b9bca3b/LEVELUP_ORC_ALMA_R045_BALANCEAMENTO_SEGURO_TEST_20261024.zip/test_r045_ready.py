import unittest,json,math
from pathlib import Path
from build_r045 import build,ids
from r045_one_item_activation import run as accessories
from r045_l21_23_branches import OUT
from r045_soul_guard import run as soul
from optimize_r044 import R40,GROSS
ROOT=Path(__file__).parent

class DeploymentPreviewQA(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.plan=build();cls.acc=accessories();cls.bal,cls.guard=soul()
 def test_page_ids_unique(self):self.assertEqual(len(set(ids)),25)
 def test_no_writer_and_no_canon(self):
  self.assertTrue(all(x['notion_write_performed'] is False and x['RI_RE_homologated'] is False for x in self.plan))
 def test_readable_deltas(self):
  for x in self.plan:
   self.assertEqual(x['proposed_free'],x['gross_test']-x['proposed_daily'])
   self.assertEqual(x['before_free'],x['gross_test']-x['before_daily'])
   self.assertTrue(set(x['slots_to_reserve']).isdisjoint(set(x['slots_energized'])))
 def test_only_old_on_slots_selected(self):
  for x in self.plan:
   oldon={z['slot'] for z in R40[x['n']-1]['slots'] if z['on']}
   self.assertTrue(set(x['slots_energized']).issubset(oldon))
 def test_prata_to_lendario_feasible_with_one_accessory_use_except_l21(self):
  self.assertEqual(sum(x.get('feasible',False) for x in self.acc),19)
  self.assertEqual([x['n'] for x in self.acc if x.get('eligible') and not x.get('feasible')],[21])
 def test_19_gate_readiness(self):
  self.assertEqual(sum(x['state']=='PRÉVIA_SEGURA_TEST_SEM_WRITER' for x in self.plan),19)
  self.assertEqual(self.plan[20]['state'],'HOLD_VARIANTE_ON_LEGADO_PROVENIÊNCIA')
 def test_no_bronze_transform(self):self.assertTrue(all(x['t9']==0 and x['state'].startswith('BRONZE') for x in self.plan[:5]))
 def test_25pct_after_ed_and_accessory(self):
  for x in self.plan:
   if x['after_three_uses'] is not None:self.assertGreaterEqual(x['after_three_uses'],math.ceil(x['gross_test']/4))
 def test_pending_patches_no_negative_daily(self):
  for x in self.plan:
   self.assertLessEqual(x['proposed_daily'],x['before_daily'])
   self.assertTrue({1,2}.issubset(x['slots_energized']))
 def test_l21_bridge_exists_but_not_owned(self):
  self.assertEqual(sorted((z['n'],z['mode']) for z in OUT),[(21,'combate'),(21,'guarda'),(22,'combate'),(23,'combate')])
  for z in OUT:
   self.assertGreaterEqual(z['post_after_all'],z['buffer25'])
   self.assertEqual(z['RI_RE_status'],'CANDIDATE_ONLY')
 def test_android_no_network_or_write(self):
  s=(ROOT/'R045_ORC_ALMA_COMBATE_ANDROID_OFFLINE_TEST.html').read_text()
  self.assertIn('Nenhum item ou ficha foi alterado',s)
  self.assertNotIn('fetch(',s)
  self.assertNotIn('XMLHttpRequest',s)
  self.assertIn('NÃO APLICADO',s)
 def test_draina100_limit_correct(self):
  a=[x for x in self.guard if x['achievable']]
  self.assertEqual(len(a),19)
  self.assertEqual([(x['n'],x['shortfall']) for x in self.guard if not x['achievable']],[(6,12)])
 def test_n24_n25_no_item_downrank_automatically(self):
  for x in self.plan[23:]:
   self.assertEqual(x['before_daily'],356)
   self.assertEqual(x['proposed_daily'],356)
   self.assertEqual(len(x['slots_energized']),10)

if __name__=='__main__':unittest.main()
