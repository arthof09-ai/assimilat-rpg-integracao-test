"""Conditional, no physical item sourcing. Uses R040 recorded older-tier variants.
Does not grant ownership or modify any Notion page."""
import json, math,pathlib
from optimize_r044 import R40,GROSS
BASE=pathlib.Path(__file__).parent
OUT=[]
SETS={21:[(1,21),(2,21),(3,16),(9,16)],22:[(1,22),(2,22),(3,16),(4,16),(9,16)],23:[(1,23),(2,23),(3,16),(4,16),(9,16)]}
# For N21, alternate a defensive-first but still offensive hit option
for n,choice in sorted(SETS.items()):
 for name,rr in ([('combate',choice),('guarda',[(1,n),(2,n),(4,16),(9,16)])] if n==21 else [('combate',choice)]):
  items=[dict(slot=slot,from_level=lv,name=R40[lv-1]['slots'][slot-1]['item'],daily=R40[lv-1]['slots'][slot-1]['pa_dia_publicado'],use=R40[lv-1]['slots'][slot-1]['pa_uso_publicado'],bonus_attribute=R40[lv-1]['slots'][slot-1]['atributo_bonus_test']) for slot,lv in rr]
  daily=sum(i['daily'] for i in items)
  active=next(i for i in items if i['slot']==9) # +8 accuracy, pay one effect
  gross=GROSS[n-1];post=gross-daily-320-50-active['use'];buf=math.ceil(gross/4)
  assert daily== (255 if n==21 else 295),daily
  assert post>=buf,(n,post,buf)
  OUT.append({'n':n,'mode':name,'items':items,'daily':daily,'gross':gross,'t9':320,'spirit_skill':'Sentença do Titã','spirit_cost':50,'energized_item_activation':'Braçadeiras do Golpe Medido','item_use_cost':active['use'],'post_after_all':post,'buffer25':buf,'margin':post-buf,'RI_RE_status':'CANDIDATE_ONLY','provenance':'ON variant from N16 already described; NOT proven in N21-23 inventory; no replacement or ownership authorized'})
if __name__=='__main__':
 (BASE/'r045_l21_23_conditional.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 for a in OUT:print(a['n'],a['mode'],a['daily'],a['post_after_all'],a['buffer25'],a['margin'])
