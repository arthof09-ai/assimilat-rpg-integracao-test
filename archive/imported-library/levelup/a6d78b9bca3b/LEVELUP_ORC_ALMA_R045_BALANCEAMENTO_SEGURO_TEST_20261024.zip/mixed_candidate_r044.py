"""Cross-rank mix PROPOSAL ONLY; existing variant examples are not owned items."""
from optimize_r044 import R40,GROSS
import math,csv,json
from pathlib import Path
OUT=Path(__file__).parent

def build():
 # Actor L21-23 retains his own L armor and L axe, only existing ON family
 # exemplars N16 slot 3,4,9 are analytically borrowed as candidates.
 items=[(1,21),(2,21),(3,16),(4,16),(9,16)]
 result=[]
 for n in (21,22,23):
  picked=[]
  for slot,srclev in items:
   q=R40[srclev-1]['slots'][slot-1]
   assert q['slot']==slot and q['on']
   picked.append(dict(slot=slot,family=q['item'],candidate_reference_level=srclev,rank_nominal=q['ri_nominal_test'],daily=q['pa_dia_publicado'],attr_test=q['atributo_bonus_test'],re_test=q['re_candidato'],activation_cost_test=q['pa_uso_publicado'],status='CANDIDATE_VARIANT_NOT_PROVEN_OWNED'))
  gross=GROSS[n-1];daily=sum(x['daily'] for x in picked);end=gross-daily-320-50
  assert daily==295 and end>=math.ceil(gross/4)
  result.append(dict(level=n,rank='Lendário',gross=gross,items=picked,daily=daily,
     t9=320,tech_name='Sentença do Titã',tech=50,post_after_t9_tech=end,buffer25=math.ceil(gross/4),spare_over_buffer=end-math.ceil(gross/4),
     core_physical_reference='Couraça Lendário +30 CA física; Machado Lendário 12d6 média42 + Ruptura16d6 condicional; NO STAT CHANGE to core',
     limitations=['Mix is NOT a factual drop/craft/possession','Upper-body temporary buffs and accuracy require actions/costs; may not overlap effectively','RE/RI/FIP, real effect compatibility and VLAB not certified','Changing L accessories to ON +8 drops conditional magnitude from original L +10','May not recover spent maintenance retroactively']))
 return result
if __name__=='__main__':
 r=build()
 (OUT/'r044_mixed_L21_L23_conditional.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 with open(OUT/'r044_mixed_L21_L23_conditional.csv','w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['Nível','Slots','Origem variante (test)','PA bruto','PA dia candidato','T9','Técnica','PA após T9+técnica','25% reserva','Folga','HOLD'])
  for x in r:w.writerow([x['level'],'1,2,3,4,9','L21 core + ON16 acessórios',x['gross'],x['daily'],320,50,x['post_after_t9_tech'],x['buffer25'],x['spare_over_buffer'],'Posse/identidade/CRAFT/RI/RE/VLAB'])
 for x in r: print(x['level'],x['daily'],x['post_after_t9_tech'],x['buffer25'],x['spare_over_buffer'])
