from pathlib import Path
import unittest,json,csv,math
from optimize_r044 import run,R40,R42,GROSS,T9,TECH,STYLES

class VerifyR044(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=run()
 def test_75_styles(cls):pass
 def test_matrix_complete(self):
  self.assertEqual(len(self.r),75)
  self.assertEqual({x['style'] for x in self.r},set(STYLES))
  self.assertEqual([(x['n'],x['style']) for x in self.r],[(n,st) for n in range(1,26) for st in STYLES])
 def test_source_400_slots(self):
  self.assertEqual(sum(len(x['slots']) for x in R40),400)
  for x in R40:
   self.assertEqual(len({q['slot'] for q in x['slots']}),16)
   self.assertEqual(sum(y['pa_dia_publicado'] for y in x['slots']),x['total_diario'])
 def test_no_mutation_of_full_inventory(self):
  for x in self.r:
   n=x['n']; inv=R40[n-1]
   before={z['slot'] for z in inv['slots'] if z['on']}
   self.assertEqual(before,set(x['selected'])|set(x['off']))
   self.assertFalse(set(x['selected'])&set(x['off']))
   self.assertTrue(set((1,2)).issubset(x['selected']))
   self.assertEqual(x['cost'],sum(z['pa_dia_publicado'] for z in inv['slots'] if z['slot'] in x['selected']))
   self.assertLessEqual(x['cost'],x['cost_current'])
 def test_budget_post_25percent(self):
  for x in self.r:
   n=x['n']; idx=(n-1)//5
   self.assertEqual(x['buffer'],math.ceil(GROSS[n-1]*0.25))
   self.assertEqual(x['post'],GROSS[n-1]-x['cost']-TECH[idx]-T9[idx])
   self.assertGreaterEqual(x['post'],x['buffer'])
 def test_no_t9_bronze(self):
  for x in self.r[:15]:
   self.assertLessEqual(x['n'],5)
   self.assertEqual(x['t9'],0)
   self.assertEqual(x['selected'],list(range(1,len(x['selected'])+1)))
 def test_score_proxy_not_lower_than_r042(self):
  for x in self.r:self.assertGreaterEqual(x['score_vs_p42'],0)
 def test_l21_23_alternatives(self):
  for n in (21,22,23):
   self.assertEqual(next(x['selected'] for x in self.r if x['n']==n and x['style']=='balanced'),[1,2,9])
   self.assertEqual(next(x['selected'] for x in self.r if x['n']==n and x['style']=='guard'),[1,2,4])
 def test_would_not_mislabel_int_or_ankles_as_pa(self):
  for x in self.r:
   self.assertEqual(x['pa_bruto'],GROSS[x['n']-1]);self.assertEqual(x['pa_bruto']-x['cost_current'],R42[x['n']-1]['pa_livre_atual'])
 def test_existing_reference_mixed_l24_25_untouched(self):
  for n in (24,25):
   for x in (u for u in self.r if u['n']==n):
    self.assertEqual(x['cost'],356)
    self.assertEqual(x['off'],[])

if __name__=='__main__':unittest.main(verbosity=2)
