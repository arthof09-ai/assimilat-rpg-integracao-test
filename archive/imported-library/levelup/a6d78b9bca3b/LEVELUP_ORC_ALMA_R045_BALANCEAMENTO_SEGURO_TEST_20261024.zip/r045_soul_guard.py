"""Read-only, transparent decision-support: Orc TEST R216 P23-045.
Not a PA engine, VLAB combat simulation, Notion writer or production policy.
Retains R044 balanced as default, gives precautionary soul-drain loadout.
"""
import csv, json, math, itertools, hashlib, pathlib
from optimize_r044 import R40,GROSS,TECH,T9,score
ROOT=pathlib.Path(__file__).parent
BASE=json.loads((ROOT/'r044_75_presets.json').read_text(encoding='utf8'))['presets']
BAL={r['n']:r for r in BASE if r['style']=='balanced'}
FOCUS=(1,2,3,4,9)
NAMES={1:'Couraça da Muralha',2:'Machado da Ruptura',3:'Manoplas da Bigorna',4:'Cinto do Bastião',5:'Botas da Escarpa',6:'Anel da Guarda',7:'Elmo do Estandarte',8:'Capa do Desfiladeiro',9:'Braçadeiras do Golpe Medido',10:'Amuleto da Forja',11:'Anel de Golpe',12:'Insígnia',13:'Arnês Antitombo',14:'Espada de reserva',15:'Escudo de reserva',16:'Selo de Emergência'}
def opt(n,drain=100):
    src=R40[n-1];g=GROSS[n-1];tier=(n-1)//5;t=T9[tier];h=TECH[tier]
    ceil=math.ceil(g/4); cap=g-t-h-ceil-drain
    act=[x for x in src['slots'] if x['on']];ref={x['slot']:x for x in act};assert 1 in ref and 2 in ref
    if n<=5:return None
    opts=[x['slot'] for x in act if x['slot'] not in (1,2)]
    rows=[]
    for m in range(1<<len(opts)):
      keep={1,2}|{s for j,s in enumerate(opts) if m&(1<<j)}
      daily=sum(ref[s]['pa_dia_publicado'] for s in keep)
      if daily>cap:continue
      post=g-daily-t-h
      sc=score(keep,'balanced');
      # Match R044 basis: proxy utility, surplus, then retention
      rows.append((sc,post,-(len(act)-len(keep)),sorted(keep),daily))
    if not rows:
      core=ref[1]['pa_dia_publicado']+ref[2]['pa_dia_publicado']
      return {'n':n,'achievable':False,'max_post_after_t9_tech_and_core':g-core-t-h,'target':ceil+drain,'shortfall':ceil+drain-(g-core-t-h),'gross':g,'buffer25':ceil,'t9':t,'skill':h}
    sc,post,loss,sel,cost=max(rows)
    return {'n':n,'achievable':True,'gross':g,'selected':sel,'off':sorted(set(ref)-set(sel)),'cost':cost,'post':post,'buffer25':ceil,'surplus_over25':post-ceil,'drain_test':drain,'post_after_synthetic_drain':post-drain,'score_proxy':sc,'combat_core_preserved':all(s in sel for s in (1,2)),'keys_kept':sorted(set(sel)&set(FOCUS)),'lost_families':[NAMES[s] for s in sorted(set(ref)-set(sel))]}
def run():
    comparison=[]
    guard=[]
    for n in range(1,26):
      b=BAL[n];g=GROSS[n-1];std={'n':n,'rank':['Bronze','Prata','Ouro','Ouro Negro','Lendário'][(n-1)//5],'gross':g,'selected':b['selected'],'off':b['off'],'daily':b['cost'],'t9':b['t9'],'skill':b['tech'],'post':b['post'],'reserve25':b['buffer'],'surplus_over25':b['post']-b['buffer'],'key_features':[NAMES[s] for s in FOCUS if s in b['selected']],'key_count':sum(s in b['selected'] for s in FOCUS),'loss_count':len(b['off']),'combat_core_preserved':1 in b['selected'] and 2 in b['selected'],'drain100_positive':(b['post']-100)>0,'drain200_positive':(b['post']-200)>0,'drain100_keeps_25pct':b['post']-100>=b['buffer'],'drain200_keeps_25pct':b['post']-200>=b['buffer']}
      comparison.append(std)
      if n>5:guard.append(opt(n,100))
    return comparison,guard
if __name__=='__main__':
 c,d=run()
 (ROOT/'r045_balanced_capability.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 (ROOT/'r045_draina100_guard.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 with (ROOT/'r045_balanced_25.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['Nível','Rank','PA bruto','PA/dia recomendado TEST','T9','Técnica','PA restante','Piso 25%','Folga sobre piso','Núcleo combatente','Famílias núcleo mantidas','Itens OFF (slot)'])
  for x in c:w.writerow([x['n'],x['rank'],x['gross'],x['daily'],x['t9'],x['skill'],x['post'],x['reserve25'],x['surplus_over25'],x['combat_core_preserved'],','.join(x['key_features']),','.join(map(str,x['off']))])
 with (ROOT/'r045_drain100_20.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['Nível','Consegue 25%+100 drenagem','Custo PA/dia modo antissucção','PA após T9+técnica','PA após -100 sintético','Margem sobre 25% após -100','Itens ON','Itens OFF','Déficit inevitável sobre objetivo com S01/S02'])
  for x in d:w.writerow([x['n'],x['achievable'],x.get('cost',''),x.get('post',''),x.get('post_after_synthetic_drain',''),x.get('post_after_synthetic_drain',0)-x['buffer25'] if x['achievable'] else '',','.join(map(str,x.get('selected',[]))),','.join(map(str,x.get('off',[]))),x.get('shortfall',0)])
 print('total balanced',len(c),'T9+tech+25 successes',sum(x['post']>=x['reserve25'] for x in c),'20 elig',len(d))
 print('all key preserve',sum(x['key_count']==len(FOCUS) for x in c if x['n']>=6),'of 20')
 print('drain100 keep 25%',sum(x['drain100_keeps_25pct'] for x in c if x['n']>=6),'of 20')
 print('drain100 exists with physical core',sum(x['achievable'] for x in d),'of 20', [x['n'] for x in d if not x['achievable']])
 for z in d:print('N%02d'%z['n'],'OK' if z['achievable'] else 'NO',z.get('cost'),z.get('post'),z.get('post_after_synthetic_drain'),z.get('selected'),z.get('shortfall'))
