import unittest,math
from r045_soul_guard import run,R40,GROSS,FOCUS,BAL,TECH,T9,opt

class AuditSoulR045(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.reg,cls.guard=run()
 def test_census(self):
  self.assertEqual(len(self.reg),25);self.assertEqual(len(self.guard),20);self.assertEqual(sum(len(x['slots']) for x in R40),400)
 def test_bronze_t9_veto(self):
  self.assertEqual([r['t9'] for r in self.reg[:5]],[0]*5)
 def test_rank_t9(self):
  self.assertEqual([r['t9'] for r in self.reg[5:]],[40]*5+[80]*5+[160]*5+[320]*5)
 def test_skill_costs(self):
  self.assertEqual([r['skill'] for r in self.reg],[6]*5+[12]*5+[24]*5+[35]*5+[50]*5)
 def test_strict_25_percent_after_actions(self):
  for x in self.reg:self.assertGreaterEqual(x['post'],math.ceil(x['gross']*.25),f"N{x['n']}")
 def test_physical_core_and_active_subset(self):
  for x in self.reg:
   n=x['n'];on={s['slot'] for s in R40[n-1]['slots'] if s['on']};self.assertTrue({1,2}.issubset(set(x['selected'])));self.assertTrue(set(x['selected']).issubset(on));self.assertTrue(set(x['off']).isdisjoint(set(x['selected'])))
 def test_no_attr_creation_or_PA_doublecount(self):
  for x in self.reg:
   n=x['n'];cost=sum(q['pa_dia_publicado'] for q in R40[n-1]['slots'] if q['slot'] in x['selected']);self.assertEqual(cost,x['daily']);self.assertEqual(x['gross']-x['daily']-x['t9']-x['skill'],x['post'])
 def test_original_combat_triad(self):
  self.assertEqual(sum({3,4,9}.issubset(x['selected']) for x in self.reg[5:]),17)
  self.assertEqual([x['n'] for x in self.reg[5:] if not {3,4,9}.issubset(x['selected'])],[21,22,23])
 def test_anti_drain_100(self):
  valid=[x for x in self.guard if x['achievable']];self.assertEqual(len(valid),19)
  self.assertEqual([(x['n'],x['shortfall']) for x in self.guard if not x['achievable']],[(6,12)])
  for x in valid:
   self.assertTrue({1,2}.issubset(set(x['selected'])))
   self.assertGreaterEqual(x['post_after_synthetic_drain'],x['buffer25'])
 def test_anti_drain_not_default(self):
  for x in self.guard:
   if x['achievable']:self.assertLessEqual(x['cost'],BAL[x['n']]['cost'])
 def test_no_false_claim_on_protection_normal(self):
  self.assertEqual(sum(x['drain100_keeps_25pct'] for x in self.reg[5:]),0)
 def test_mixed_in_R044_is_not_ownership(self):
  from mixed_candidate_r044 import build
  for x in build():
   self.assertEqual(x['daily'],295);self.assertGreaterEqual(x['post_after_t9_tech'],x['buffer25'])
   self.assertTrue(all(z['status']=='CANDIDATE_VARIANT_NOT_PROVEN_OWNED' for z in x['items']))
 def test_l21_gross_under_full_gear_fails(self):
  n=21;gross=GROSS[n-1];full=R40[n-1]['total_diario'];self.assertEqual(full,810)
  self.assertLess(gross-full-320-50,math.ceil(gross/4))

if __name__=='__main__':unittest.main()
