"""Generate read-only deployment preview, static Android viewer and auditable QA.
No Notion writer, no mutable state, no second engine.
"""
import pathlib,json,csv,math,hashlib,html
from r045_one_item_activation import run as one_item
from r045_soul_guard import run as soul_guard,NAMES
from r045_l21_23_branches import OUT as conditional
from optimize_r044 import R40,GROSS
P=pathlib.Path(__file__).parent
ids=[
'400c2b32-4ede-815c-b828-dbd345c48724','400c2b32-4ede-817f-ba8f-de73a1c45020','400c2b32-4ede-81d3-adc9-ef2fdc11604d','400c2b32-4ede-81ac-9519-fd627291eafc','400c2b32-4ede-81e8-83d8-e0275f06a674',
'400c2b32-4ede-814a-8e56-fa1275e2bfe3','400c2b32-4ede-8148-89fc-e8568f04949b','400c2b32-4ede-81fc-bac7-f21254483905','400c2b32-4ede-8170-b774-ea9580ab8e06','400c2b32-4ede-81e5-91ac-e187c1763b9c',
'400c2b32-4ede-8145-9656-d6abd27699a3','400c2b32-4ede-8124-9cbb-ea651d99dc00','400c2b32-4ede-81ff-a1f7-d112ce18e793','400c2b32-4ede-81be-b220-cc5953504264','400c2b32-4ede-81a8-85b7-f80129bfa054',
'400c2b32-4ede-817d-9900-f2c240448cb6','400c2b32-4ede-8118-a1d0-d3a56ee787d9','400c2b32-4ede-81a7-8ff5-cc32a157d1b7','400c2b32-4ede-81c0-a6de-d4d52b87ec63','400c2b32-4ede-81ef-9d94-d807933e607b',
'400c2b32-4ede-815d-8028-ca7767b78e1f','400c2b32-4ede-81fa-bc81-cf69f0641303','400c2b32-4ede-81e8-94a1-f4ac84354ee2','400c2b32-4ede-8178-9207-ccb2-bac264b2','400c2b32-4ede-815a-bca2-ce4fb08a8cdc']

BRONZE='BRONZE_T9_PROIBIDO'; READY='PRÉVIA_SEGURA_TEST_SEM_WRITER';HOLD='HOLD_VARIANTE_ON_LEGADO_PROVENIÊNCIA'
def build():
 one=one_item();b,guard=soul_guard();guardby={z['n']:z for z in guard};condby={}
 for c in conditional:condby.setdefault(c['n'],[]).append(c)
 out=[]
 for n in range(1,26):
  g=GROSS[n-1];x=one[n-1];k=R40[n-1];status=BRONZE if n<=5 else (READY if x['feasible'] else HOLD)
  selected=(x['selected'] if status==READY else [z['slot'] for z in k['slots'] if z['on']]);oldon={z['slot'] for z in k['slots'] if z['on']};newon=set(selected)
  oldcost=k['total_diario'];newcost=sum(z['pa_dia_publicado'] for z in k['slots'] if z['slot'] in newon)
  row={'n':n,'page_id':ids[n-1],'url':'https://app.notion.com/p/'+ids[n-1].replace('-',''),'rank':['Bronze','Prata','Ouro','Ouro Negro','Lendário'][(n-1)//5],
     'state':status,'gross_test':g,'before_daily':oldcost,'proposed_daily':newcost,'before_free':g-oldcost,'proposed_free':g-newcost,
     't9':x.get('t9',0),'spirit_skill':x.get('spirit_skill',0),'item_use':x.get('item_activation_cost',0),'item_activation_slot':x.get('item_activation_slot'),
     'after_three_uses':x.get('post_all'),'buffer25':math.ceil(g/4),'after_buffer_margin':x.get('margin'),
     'slots_energized':selected,'slots_to_reserve':sorted(oldon-newon),'slot_names_to_reserve':[NAMES[z] for z in sorted(oldon-newon)],
     'major_keys_kept':[NAMES[z] for z in (1,2,3,4,9) if z in newon],
     'soul_guard_100':guardby.get(n),
     'conditional_L21_23':condby.get(n,[]),
     'notion_write_performed':False,'RI_RE_homologated':False,
     'note':('Não alterar: Bronze e T9 vedado' if n<=5 else ('Full-rank L21 não suporta acessório extra com piso25; opções alternativas sob prova de posse' if status==HOLD else 'Plano de carga antes do compromisso diário; verificar writer e readback'))}
  out.append(row)
 assert len(out)==25
 return out

def dump():
 data=build()
 (P/'r045_25_fichas_PLANO_NAO_APLICADO.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
 with (P/'r045_25_fichas_PLANO_NAO_APLICADO.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['Nível','Página Notion existente','Rank','Estado','PA bruto','PA/dia antes','PA/dia proposto','PA livre antes','PA livre proposto','T9','Técnica ED','Uso de acessório','PA depois de 3 usos','Piso 25%','Margem','Slots energizados','Desenergizar','Nota'])
  for x in data:w.writerow([x['n'],x['url'],x['rank'],x['state'],x['gross_test'],x['before_daily'],x['proposed_daily'],x['before_free'],x['proposed_free'],x['t9'],x['spirit_skill'],x['item_use'],x['after_three_uses'] if x['after_three_uses'] is not None else '',x['buffer25'],x['after_buffer_margin'] if x['after_buffer_margin'] is not None else '',','.join(map(str,x['slots_energized'])),','.join(map(str,x['slots_to_reserve'])),x['note']])
 # Static, no tracking, network, edit tools. User can inspect all 25 levels on mobile.
 public=[]
 for x in data:
  a={k:v for k,v in x.items() if k not in ('soul_guard_100','conditional_L21_23')}
  a['guard']=x['soul_guard_100'];a['conditional']=x['conditional_L21_23'];public.append(a)
 js=json.dumps(public,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
 page=r'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><meta name="color-scheme" content="dark"/>
 <title>ORC — Auditor de Alma 25% (TEST)</title><style>
 :root{color-scheme:dark;--bg:#0a101d;--panel:#172235;--edge:#33425c;--fg:#f3f6ff;--dim:#b3c0d2;--good:#73dfb3;--warn:#ffcb79;--bad:#ff9696}*{box-sizing:border-box}body{background:var(--bg);color:var(--fg);font-family:system-ui,-apple-system,Arial,sans-serif;max-width:850px;margin:0 auto;padding:16px;line-height:1.48}
 header{border-bottom:1px solid var(--edge);padding-bottom:12px}h1{font-size:1.4rem;margin:0 0 5px}.sub{color:var(--dim);font-size:.88rem}.notice{border:1px solid var(--warn);border-radius:12px;padding:10px;margin:12px 0;font-size:.91rem;color:var(--warn)}label{display:block;margin-bottom:4px;color:var(--dim)}select{width:100%;padding:12px;border-radius:10px;border:1px solid var(--edge);background:#1b2a40;color:var(--fg);font-size:1rem}section{margin:12px 0;background:var(--panel);border:1px solid var(--edge);padding:14px;border-radius:12px}h2{font-size:1.1rem;margin:0 0 10px}h3{font-size:1rem;margin:10px 0 6px}p{margin:8px 0}.mono{font-variant-numeric:tabular-nums}.value{font-size:1.65rem;font-weight:800}.good{color:var(--good)}.warn{color:var(--warn)}.bad{color:var(--bad)}.minor{color:var(--dim);font-size:.86rem}.flex{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.metric{padding:10px;background:#0c1829;border-radius:10px}.tag{display:inline-block;font-size:.8rem;padding:4px 7px;background:#213249;border-radius:6px;margin:3px 4px 3px 0}.btn{border:1px solid var(--edge);background:#24374f;color:var(--fg);padding:10px;border-radius:9px;width:100%;font-size:.94rem;margin-top:8px;text-align:center}.foot{padding:12px 0 20px;color:var(--dim);font-size:.83rem}a{color:#abcffe} .progress{height:8px;background:#30445c;border-radius:8px;overflow:hidden}.progress span{display:block;background:var(--good);height:100%}code{color:var(--warn)}
 </style></head><body><header><h1>ORC · Alma e combate</h1><div class="sub">MESTRE-SIDE · P23-045 · painel offline, somente leitura · Nenhum item ou ficha foi alterado</div></header>
 <div class="notice"><strong>TEST — NÃO APLICADO.</strong> Os números são prévias de compromisso diário antes do pagamento real. Não garantem ações viáveis por duração do Espírito, posse de variantes ou resistência a dreno. Bronze não se transforma.</div>
 <label for="lev">Selecione a classificação / nível do Orc</label><select id="lev"></select><section id="view" aria-live="polite"></section>
 <section><h2>Critério aprovado pelo Mestre</h2><p>Depois de uma Transformação Demoníaca, uma técnica espiritual e pelo menos uma ativação de acessório, guardar <b>≥25% da Alma bruta</b>. O requisito extra de acessório é uma precaução desta auditoria. Se não houver renda suficiente, não declarar o perfil pronto.</p><p class="minor">Ação e duração continuam dependentes de T9; item desligado deixa de conceder magia. Reação defensiva exclusiva, proficiências e custos adicionais precisam ser conferidos no VLAB.</p></section>
 <div class="foot">Fontes existentes: P23-040/044, Criação de Ficha Regra 5, Transformação T9, 25 Orc R216-P14. Readback material, writer e NAC-PASS exigidos antes de edição. Nenhum dado sai deste arquivo.</div>
 <script>const DATA=__JSON__;const select=document.getElementById('lev');const view=document.getElementById('view');const safe=t=>String(t==null?'':t).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));for(let d of DATA){let o=document.createElement('option');o.value=d.n;o.textContent=`${d.rank} ${((d.n-1)%5)+1}★ · N${String(d.n).padStart(2,'0')}`;select.appendChild(o)}function chips(a){return a.length?a.map(x=>`<span class="tag">${safe(x)}</span>`).join(''):'<span class="minor">Nenhum</span>'}function render(){let d=DATA[Number(select.value)-1];const bronze=d.n<=5,hold=d.state.includes('HOLD');let html=`<h2>N${String(d.n).padStart(2,'0')} · ${safe(d.rank)}</h2><div class="flex"><div class="metric"><div class="minor">PA/dia atual</div><div class="value mono">${d.before_daily}</div></div><div class="metric"><div class="minor">PA/dia proposto</div><div class="value mono">${d.proposed_daily}</div></div><div class="metric"><div class="minor">Alma bruta</div><div class="value mono">${d.gross_test}</div></div><div class="metric"><div class="minor">Piso 25%</div><div class="value mono">${d.buffer25}</div></div></div>`;
 if(bronze){html+='<p class="warn"><b>Transformação não permitida em Bronze.</b> A ficha original permanece intacta.</p>'}
 else if(hold){html+='<p class="bad"><b>HOLD: variante de rank inferior sem prova de posse.</b> A configuração Lendária inteira não consegue sustentar técnica ED + uso de acessório + 25% no N21.</p>'}
 else{html+=`<h3>Saldo após T9 + técnica ED + ativação de acessório</h3><div class="value good mono">${d.after_three_uses} PA</div><p class="minor">T9 ${d.t9} PA + técnica ${d.spirit_skill} PA + acessório ${d.item_use} PA. Folga sobre os 25%: <b>${d.after_buffer_margin} PA</b>.</p><div class="progress"><span style="width:${Math.min(100,100*d.after_three_uses/d.gross_test).toFixed(2)}%"></span></div>`}
 html+=`<h3>Equipamento energizado previsto</h3>${chips(d.slots_energized.map(i=>`S${i}`))}<h3>Itens a colocar em reserva antes do custo diário</h3>${chips(d.slot_names_to_reserve)}<p class="minor">Couraça S01 e Machado S02 sempre energizados. Intensidade real dos buffs e combates VLAB: PENDENTES.</p>`;
 if(d.conditional.length){html+='<h3>Possíveis variantes inferiores (não possuídas)</h3>';for(let c of d.conditional){html+=`<p class="minor"><b>${safe(c.mode)}</b>: custo diário ${c.daily}, saldo após T9 + Sentença + uso de Braçadeiras ${c.post_after_all}, piso ${c.buffer25}, folga ${c.margin}. Referências de variantes ON de N16; aquisições HOLD.</p>`}}
 if(d.guard){let g=d.guard;html+='<h3>Perfil preventivo contra dreno hipotético de 100 PA</h3>';html+=g.achievable?`<p>Configuração alternativa: ${g.cost} PA/dia. Após T9 + técnica + perda sintética de 100 PA: <b>${g.post_after_synthetic_drain} PA</b> (piso ${g.buffer25}). Retém ${safe(g.selected.join(', '))}.</p>`:`<p class="warn">Mesmo energizando só Couraça/Machado, falta ${g.shortfall} PA para manter 25% após mais 100 de perda sintética.</p>`}
 html+=`<a href="${safe(d.url)}" target="_blank" rel="noopener noreferrer">Abrir a ficha original no Notion</a><button class="btn" id="copy">Copiar prévia para auditoria (não edita Notion)</button>`;view.innerHTML=html;document.getElementById('copy').onclick=()=>{let t=`N${d.n} ${d.rank} TEST NAO APLICADO | PA/dia ${d.before_daily}->${d.proposed_daily}; original ${d.gross_test}; T9 ${d.t9}; ED ${d.spirit_skill}; uso item ${d.item_use}; restante ${d.after_three_uses??'HOLD'}; piso ${d.buffer25}; ON ${d.slots_energized.join(',')}; OFF ${d.slots_to_reserve.join(',')}; writer/HOLD`;if(navigator.clipboard?.writeText)navigator.clipboard.writeText(t).catch(()=>{});else {let el=document.createElement('textarea');el.value=t;document.body.appendChild(el);el.select();document.execCommand('copy');el.remove();}}}
 select.addEventListener('change',render);select.value='6';render();</script></body></html>'''.replace('__JSON__',js)
 (P/'R045_ORC_ALMA_COMBATE_ANDROID_OFFLINE_TEST.html').write_text(page,encoding='utf8')
 print('created plan 25 and HTML',len(page),'bytes');return data
if __name__=='__main__':dump()
