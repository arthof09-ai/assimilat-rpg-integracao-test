# LEVEL-UP / Orc — R216-P23-045

**Escopo:** mesma operação IBX-17/IBX-114, 25 fichas TEST já existentes, sem segunda ficha, regra ou motor. **Status: PREVIEW/TEST, não aplicado**, MESTRE-SIDE. Os arquivos são apenas comparadores de orçamento e plano de mutação PENDENTE de writer/lease/fence.

## Decisão do Mestre
Priorizar sustentabilidade espiritual **sem inutilizar ataque/defesa**. Para N06–N25 o critério mínimo aprovado é **Alma restante ≥ 25% da Alma bruta depois de 1 Transformação Demoníaca + 1 habilidade espiritual**. Para Bronze N01–N05 não há T9 conforme correção oficial. **Complemento de qualidade R045:** testar também pagar **uma ativação de equipamento ofensivo relevante** na mesma previsão de orçamento, para que energizar acessório não seja promessa vazia. Essa exigência complementar é um teste TEST, não uma nova regra canônica.

## Fontes e custódia prévia
- Criação de Ficha Regra 5 (Alma/INT/PA): https://app.notion.com/p/3ebc2b324ede81449222f3c06b840613
- Transformação T9/T6-B: https://app.notion.com/p/3f2c2b324ede81c0ae0ee4e66212edc9
- Diário OP LEVEL-UP / P23-040…044: https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107
- 25 fichas já existentes: https://app.notion.com/p/400c2b324ede8137a06bff45c3b5b1bb
- R044 pacote original, SHA256 `15d11a4bcd5beb5167340616c2ca8af0290940c75de1df418c0f297303a89c10`, recuperado da Biblioteca Mestre; seus 10 testes foram reexecutados PASS. R040 pacote original SHA256 `a538b6347ed84cd594489c5d90eb3b8444f4d4bf5c7aeab74d290ee7639cd8b3`.

## Achados materiais
- R044 baseline: **20/20** elegíveis pagam T9+uma técnica+25%; Bronze 5 T9 VETO. Porém **0/20** preservam ≥25% após um débito sintético extra de 100 PA. Esse débito é experimento, NÃO uma habilidade real nem condição de morte.
- R045 rigor ampliado: enumerando os subconjuntos já energizados de cada nível, retendo sempre S01 Couraça e S02 Machado, **19/20** elegíveis têm configurações que pagam T9+uma técnica espiritual+um uso de acessório de combate (S03/S04/S09)+25%. ÚNICA exceção com as variantes L já escritas = **N21 Lendário 1★**. O carregamento R044 L21 de S01+S02+S09 custa 270/dia e deixa251 após T9+Sentença, mas MAIS 30 PA/uso do acessório resultam221, inferior ao piso223 por 2 PA. Logo R044 em N21 não podia sustentar essa ativação adicional e afirmar os25%.
- **15/15** níveis Prata–Ouro Negro (N06–N20) no R045 mantêm energizados S01 Couraça, S02 Machado, S03 Manoplas +FOR, S04 Cinto +CON e S09 Braçadeiras precisão (tríade de combate ativa), apesar de poupar PA em peças situacionais/redundantes. Em N22/N23 opção L pura retém S09 mas perde buffs FOR/CON energizados; melhorar só com variante comprovada.
- N24/N25 pacote misto já registrado 356/dia atende T9 320+ED50+um acessório14+25%, sem mudar itens. Porém downgrade/transição N23→N24 e qualidade relativa dos buffs são pendências documentais; não declarar crescimento de potência.
- **Alternativa L21 condicional** por variantes Ouro Negro **já descritas** no N16, mas NÃO provadas como itens possuídos: L Couraça90 + L Machado90 + ON Manoplas40 + ON Braçadeiras35 =255/dia. Com T9 320 + Sentença50 + Braçadeiras21, sobra245/891 PA, piso223 (margem22). Opção GUARD troca ON Manoplas por ON Cinto com igual custo e margem. Efeito +8 em vez do antigo +10 e janela 2 turnos; não são equivalentes materiais, não assumir craft/posse.
- **Alternativa L22/L23 condicional**: L Couraça90+Machado90+ON Manoplas40+Cinto40+Braçadeiras35=295/dia, mais uso21: depois T9+Sentença+uso resta244/930 e 283/969, pisos233 e 243. Margens11/40. Identidade/posse HOLD.
- Dreno sintético adicional 100 após T9+ED+25%: perfil preventivo que conserva S01/S02 é matematicamente alcançável em **19/20** elegíveis; exceção N06, faltam12PA mesmo deixando só S01/S02 energizados. Perfil anti-dreno sacrifica opções e NÃO substitui build padrão; apenas com ameaça concreta e compromisso diário prévio. **T9-A, ação/duração, controle de Reações, anatomia bestial, PA transformado e drenagem real não foram executados no VLAB**.

## Arquivos
- `R045_ORC_ALMA_COMBATE_ANDROID_OFFLINE_TEST.html` — painel Android offline (somente leitura, sem fetch/API/storage ou botão de gravação). Inspeciona 25 níveis, ON/OFF, saldo triplo, reserva, modo dreno e variantes condicionais. Botão de copiar texto é local.
- `r045_25_fichas_PLANO_NAO_APLICADO.csv/json` — 25 IDs existentes, ANTES/DEPOIS apenas teórico, estados, códigos dos slots, saldos, próximo patch PENDENTE. NÃO escrever automaticamente nos alvos.
- `r045_one_extra_item_use_25.csv/json` — provas de custo energético ampliado.
- `r045_l21_23_conditional.json` — 4 alternativas cross-rank com HOLD de posse.
- `r045_balanced_25.csv`, `r045_drain100_20.csv`, JSON correspondentes — modos R044 e dreno sintético.
- Scripts `r045_*.py`, `build_r045.py` e dois test suites (26 testes). `optimize_r044.py`, `mixed_candidate_r044.py` e fixtures legadas inclusos APENAS para cold replay, não motores independentes.

## GATE DE APLICAÇÃO
1. Verificar CURRENT-WRITER-ID, WRITER-EPOCH, LEASE-TOKEN, BLOCK-PERMIT e versão física; sem prova GREEN, **não mutar fichas**. A autorização do Mestre sobre a meta não cria lease.
2. Resolver materialidade/posse de variantes ON e reconciliação N23→N24 antes de qualquer swap. Não inventar terceiro Anel da Alma, pontos INT retroativos, item fabricado ou refund de PA diário gasto.
3. Para cada nível elegível, escrever somente campos ativos/de reserva e saldos derivativos dentro dos alternantes existentes, sem registrar logs na ficha, com hash/preimagem/epoch, consulta de valores/efeitos, validação de versão e readback. Atualizar normal+transformado onde real e homologado.
4. Ensaios mecânicos VLAB do perfil de ataque (dano, acerto, defesa), T9+ED+uso acessório na economia de ações, duração mínima e efeito de drenagem antes de certificar "não enfraqueceu"; os scores R044 são heurísticos e NÃO prova de DPS/CA. Condição basal de equipamento energizado ON por si só não prova anatomia da forma transformada.
5. Documentar Diário/Inbox, registrar BEFORE/AFTER, NAC-PASS; Party/O Primeiro/CRAFT/catalogo/GitHub/VLAB NO-WRITE sem atribuição.

**LAST-VERIFIED:** R045 auditoria/testes/plano offline; **FIRST-PENDING:** lease/escritor operacional legítimo + validação física cross-rank + VLAB comparativo. A resposta correta à pergunta "as fichas foram corrigidas?" enquanto gate não passar é **NÃO**.
