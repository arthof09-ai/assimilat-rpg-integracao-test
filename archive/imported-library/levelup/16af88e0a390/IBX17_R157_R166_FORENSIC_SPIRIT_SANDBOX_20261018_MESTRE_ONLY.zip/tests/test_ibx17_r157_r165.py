import unittest,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
import r157_forensic_interlock as r157
import r158_rank_agnostic_spirit_transaction as r158
import r159_source_boundary as r159
import r160_vz_sandbox_overlays as r160
import r161_t9_duration_compat as r161
import r162_actor_spirit_switch_guard as r162
import r163_rank_cross_spirit_preview as r163
import r164_native_bridge_failclosed as r164
import r165_notional_table_source_parser as r165
from r149_150_spirit_runtime import Hold as SpiritHold,make_state,activate,rest,deactivate

class CausalIntegrityTests(unittest.TestCase):
 def test_previous_refusal_survives_full_after(self):
  self.assertEqual(r157.regression()['classification'],'R155_MARKER_STALE_SECURITY_HOLD')
 def test_not_a_new_write(self):
  self.assertEqual(r164.regression()['native_tool_called_by_module'],False)
 def test_security_refusal_never_returns_retry_allowed(self):
  x=r164.WriteIntent('TX','S','T',r164.LAB,'RULE','PRE',r164.h('RULE'),'old','new')
  self.assertFalse(r164.post_dispatch(x,before_page='old',observed_page='old',journal_state='PREPARED',tool_response=None,error_code='Security refusal')['retry_allowed'])
 def test_collision_quarantines(self):
  x=r157.StageObservation('T','S','P',r157.LAB,'v0','v1',{'x':1},{'x':0},{'x':2},'PREPARED','PREPARED',None,False,True,'LAB_TEST_EXPLICIT_FROM_MESTRE','RULE','OP')
  self.assertEqual(x.classify()['classification'],'UNKNOWN_EFFECT')

class SpiritScienceTests(unittest.TestCase):
 def test_ouro_long_rest_plan_nine_stages(self):
  self.assertEqual(r158.regression()['stages'],9)
 def test_source_bound_old_deleted(self):
  self.assertEqual(r159.regression()['status'],'HOLD_SOURCE_IDENTITY_AND_DELETION')
 def test_vz_sandbox_numeric_eight(self):
  self.assertEqual(r160.regression()['rows_valid'],8)
 def test_vz_parser_distinct_corpus(self):
  self.assertEqual(r165.regression()['rows'],8)
 def test_compatibility_requires_provenance(self):
  self.assertEqual(r161.regression()['checks'],10)
 def test_switch_replaces_reserves_and_preserves_scene(self):
  self.assertTrue(r162.regression()['scene_lock_survives_switch'])
 def test_long_rest_valid_and_session_lock(self):
  a=make_state(ordinal=11,normal_pa=220,normal_pa_max=260,committed=40)
  a,_=activate(a,event='A',scene='OLD',die_result=3,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
  a,_=deactivate(a,event='END')
  a,_=rest(a,event='L',kind='LONG',completed=True,after_activation_index=1,scene_for_next='NEW')
  with self.assertRaises(SpiritHold):activate(a,event='AGAIN',scene='OLD',die_result=3,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
  b,_=activate(a,event='NEW_ACT',scene='NEW',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
  self.assertEqual(b['normal_pa'],60)

class LevelUpPreviewTests(unittest.TestCase):
 def test_rank_preview_without_write(self):
  p=r163.preview(r163.baseline(),choice={'INT':2},source_version=r163.RULE_VERSION)
  self.assertEqual(p['after']['hp_max'],54);self.assertEqual(p['after']['pa_max'],142)
  self.assertEqual(p['native_writes'],0)
 def test_prata_unlock_is_not_auto_activation(self):
  p=r163.preview(r163.baseline(),choice={'INT':2},source_version=r163.RULE_VERSION,spirit={'scope':'SYNTHETIC_TEST_ONLY','bap':11,'cap':6})
  self.assertFalse(p['spiritual_eligibility']['form_auto_activated'])
  self.assertEqual(p['spiritual_overlay']['classification'],'HOLD_PRE_PRATA_BACKFILL_NOT_ESTABLISHED')
 def test_bad_rank_before_hold(self):
  p=r163.baseline();p['pa_natural']=228
  with self.assertRaises(r163.RankHold):r163.preview(p,choice={'INT':2},source_version=r163.RULE_VERSION)

if __name__=='__main__':unittest.main(verbosity=2)
