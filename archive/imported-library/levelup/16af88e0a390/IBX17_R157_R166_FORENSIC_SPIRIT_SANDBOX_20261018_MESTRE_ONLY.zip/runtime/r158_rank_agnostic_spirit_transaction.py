"""IBX-17 R158 — source-scoped TEST activation transaction planner.
Combines the already existing R149/150 runtime with durable stage planning.
No Notion credentials; the outer connector must write intent, compare BEFORE,
record original tool response, reopen AFTER and only then persist journal.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from hashlib import sha256
from copy import deepcopy
import json
from r149_150_spirit_runtime import make_state, activate, advance_turn, effect_damage, rest, change_spirit, deactivate, Hold, tier

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sh(x):return sha256(canon(x).encode()).hexdigest()
@dataclass(frozen=True)
class Planned:
    tx: str
    stage: str
    from_hash: str
    to_hash: str
    from_state: dict
    to_state: dict
    event_id: str
    operation: str
    actor_id: str
    scope: str='LAB_TEST'
    result: str='INTENT_ONLY_NOT_APPLIED'

def plan(state, *,tx,stage,event,operation,**kwargs)->Planned:
    if not tx or not stage or not event:raise Hold('TX_ID_REQUIRED')
    if state['scope']!='LAB_TEST':raise Hold('WRONG_SCOPE')
    fns={'ACTIVATE':activate,'TURN':advance_turn,'DAMAGE':effect_damage,'REST':rest,'SWITCH':change_spirit,'DEACTIVATE':deactivate}
    if operation not in fns:raise Hold('UNKNOWN_OPERATION')
    new,result=fns[operation](deepcopy(state),event=event,**kwargs)
    if result.startswith('NOOP'):raise Hold('REPLAY_IS_READONLY_NO_NEW_INTENT')
    return Planned(tx,stage,sh(state),sh(new),deepcopy(state),new,event,operation,state['actor_id'])

def validate_physical(plan:Planned,physical,*,journal,version,source_version,parent,refusal=False):
    if parent!='3fbc2b324ede804a95fafcb7b293c92c' or not source_version or not version:return 'AUTHORITY_OR_VERSION_HOLD'
    x=sh(physical)
    if x not in (plan.from_hash,plan.to_hash):return 'OTHER_QUARANTINE'
    if x==plan.from_hash:return 'BEFORE_SECURITY_HOLD' if refusal else 'BEFORE_UNCONSUMED'
    if journal=='COMMITTED':return 'STAGE_COMPLETE_READBACK'
    return 'AFTER_JOURNAL_MISSING_REQUIRES_CAUSAL_PROOF'

def reference_sequence():
    # Ouro 1, cost 80, 40 PA committed; synthetic 2-scene continuation with LONG rest.
    s=make_state(ordinal=11,actor='SYNTH-IBX17-R158-ACTOR',spirit='SYNTH-IBX17-R158-SPIRIT',
      normal_hp=100,normal_hp_max=180,normal_pa=220,normal_pa_max=260,
      committed=40,item_temp_hp=12,spirit_hp_max=30,spirit_pa_max=25)
    args=[('A','A1','ACTIVATE',dict(scene='SCENE-O1',die_result=3,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')),
      ('B','T1','TURN',dict(scene='SCENE-O1')),
      ('C','D1','DAMAGE',dict(amount=35)),
      ('D','T2','TURN',dict(scene='SCENE-O1')),
      ('E','T3','TURN',dict(scene='SCENE-O1')),
      ('F','T4','TURN',dict(scene='SCENE-O1')),
      ('G','RL','REST',dict(kind='LONG',completed=True,after_activation_index=1,scene_for_next='SCENE-O2',source='SYNTHETIC_TEST_ONLY')),
      ('H','A2','ACTIVATE',dict(scene='SCENE-O2',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')),
      ('I','T5','DEACTIVATE',dict(reason='VOLUNTARY'))]
    out=[];tx='IBX17-R158-OURO-DURATION-LONGREST-20261018-01'
    for stage,event,op,kw in args:
        p=plan(s,tx=tx,stage=stage,event=tx+'-'+event,operation=op,**kw)
        out.append(asdict(p));s=p.to_state
    return {'tx_id':tx,'source_rule':'T6-B T9-A 2026-10-09T19:35:48.531Z','proof':'SYNTHETIC_TEST_ONLY',
           'parent_id':'3fbc2b324ede804a95fafcb7b293c92c','before':out[0]['from_state'],
           'stages':out,'after':s}

def regression():
    r=reference_sequence();seq=r['stages'];assert len(seq)==9
    assert [p['stage'] for p in seq]==list('ABCDEFGHI')
    assert seq[0]['to_state']['normal_pa']==140
    assert seq[0]['to_state']['duration_left']==4
    assert seq[1]['to_state']['duration_left']==3
    assert seq[2]['to_state']['spirit_temp_hp']==0
    assert seq[2]['to_state']['item_temp_hp']==7
    assert seq[5]['to_state']['form_active'] is False
    assert seq[6]['to_state']['rest_evidence']['kind']=='LONG'
    assert seq[7]['to_state']['normal_pa']==60
    assert seq[7]['to_state']['spirit_temp_hp']==30
    assert seq[8]['to_state']['form_active'] is False
    assert r['after']['normal_hp']==100 and r['after']['normal_pa_committed']==40
    for i,p in enumerate(seq):
        assert sh(p['from_state'])==p['from_hash'] and sh(p['to_state'])==p['to_hash']
        if i:assert seq[i-1]['to_hash']==p['from_hash']
    assert tier(11)['category']=='Ouro'
    assert validate_physical(Planned(**seq[0]),seq[0]['from_state'],journal='PREPARED',version='v',source_version='v',parent=r['parent_id'],refusal=True)=='BEFORE_SECURITY_HOLD'
    assert validate_physical(Planned(**seq[0]),seq[0]['to_state'],journal='COMMITTED',version='v',source_version='v',parent=r['parent_id'])=='STAGE_COMPLETE_READBACK'
    return {'stages':9,'tier':'Ouro','duration_decrements':4,'long_rest_synthetic':True,'normal_pa_final':60,'spirit_active_final':False}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
