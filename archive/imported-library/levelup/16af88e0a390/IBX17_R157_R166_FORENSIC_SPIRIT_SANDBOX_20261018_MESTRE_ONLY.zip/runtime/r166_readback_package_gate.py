"""R166 — readback evidence package gate; doesn't claim external auditor proof.
Reports exact observed statuses; labels security refusal as a fence, not retry.
"""
from pathlib import Path
import json
class AuditHold(ValueError):pass

def audit(doc):
  expected={'R155','R158','R145','VZ08','NIEL','LEGACY_SPIRIT','NEW_BEAST_TREE'}
  if not expected.issubset(doc):raise AuditHold('MISSING_LIVE_SOURCE')
  if doc['evidence_scope']!='MESTRE_SIDE_SELF_REVIEW_ONLY' or doc['notion_binary_hash_attested']:
     raise AuditHold('FALSE_INDEPENDENCE_OR_BINARY_ATTESTATION')
  m=doc['R155'];n=doc['R158'];v=doc['VZ08'];k=doc['NIEL'];old=doc['LEGACY_SPIRIT'];new=doc['NEW_BEAST_TREE']
  if m['normal_journal']!='COMMITTED_AFTER_NATIVE_READBACK' or m['spirit_journal']!='COMMITTED_AFTER_NATIVE_READBACK':raise AuditHold('R155_JOURNAL_NOT_MATCHED')
  if m['aggregate_marker']!='INTENT_PREPARED' or not m['security_refusal_on_marker']:raise AuditHold('R155_MARKER_GROUNDING_REQUIRED')
  if n['events_consumed']!=0 or n['normal_pa']!=220 or n['form_active'] or not n['security_refusal_on_stage_A']:raise AuditHold('R158_EFFECT_UNKNOWN')
  if k['mentioned_spirit']!=old['id'] or old['deleted_children']!=7 or new['same_id_as_legacy_spirit']:raise AuditHold('SOURCE_BOUND_CONTEXT_INVALID')
  if v['scope']!='VZ_SANDBOX_CANON' or v['numeric_rows_checked']!=8 or v['numeric_rows_passed']!=8 or v['final_totals_complete']!=0:raise AuditHold('VZ_MISPROMOTION')
  if doc['R145']['human_after_preview_attestation']:raise AuditHold('HOST_ATTESTATION_NOT_PRESENT')
  return {'R155':'2_STAGE_EFFECTS_CONFIRMED_TERMINAL_HOLD',
          'R158':'DISPATCHED_BUT_PHYSICAL_BEFORE_SECURITY_HOLD',
          'R145':'AWAITING_CONFIRMATION',
          'VZ08':'8_OF_8_SANDBOX_NUMERIC_ONLY',
          'NIEL':'LEGACY_SPIRIT_SOURCE_DELETED_HOLD',
          'NAC_PASS':'EXPERIMENTAL_LOCAL_ONLY_PRODUCTION_HOLD',
          'review':'SELF_REVIEW_ONLY','notion_writes':0}

def regression():
  d=json.loads((Path(__file__).resolve().parents[1]/'evidence'/'LIVE_NOTION_READBACK_20261018_MESTRE_ONLY.json').read_text())
  a=audit(d);assert a['R155'].endswith('_HOLD')
  assert a['R158'].endswith('_HOLD')
  assert a['VZ08']=='8_OF_8_SANDBOX_NUMERIC_ONLY'
  bad=dict(d);bad['notion_binary_hash_attested']=True
  try:audit(bad)
  except AuditHold:pass
  else:raise AssertionError('fake binary proof accepted')
  bad=dict(d);bad['R145']=dict(d['R145'],human_after_preview_attestation=True)
  try:audit(bad)
  except AuditHold:pass
  else:raise AssertionError('fake human accepted')
  bad=dict(d);bad['R158']=dict(d['R158'],events_consumed=1)
  try:audit(bad)
  except AuditHold:pass
  else:raise AssertionError('false write accepted')
  return {'checks':6,'verdict':a}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
