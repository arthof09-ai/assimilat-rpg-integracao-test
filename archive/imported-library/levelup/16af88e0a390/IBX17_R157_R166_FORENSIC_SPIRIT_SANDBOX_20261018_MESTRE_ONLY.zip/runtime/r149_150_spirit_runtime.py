"""IBX-17 R149/R150 additive state engine for specialized T9-A/T6-B rules.
No independent Notion writer. LAB TEST consumes synthetic scene/rest only.
PA availability policy explicitly TEST, not asserted canonical global priority.
"""
from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256
import json
class Hold(ValueError):pass
TIERS={
 'Prata':{'minimum':6,'maximum':10,'action':'COMPLETA','cost':40,'die':6,'offset':1},
 'Ouro':{'minimum':11,'maximum':15,'action':'PADRAO','cost':80,'die':8,'offset':1},
 'Ouro Negro':{'minimum':16,'maximum':20,'action':'MOVIMENTO','cost':160,'die':10,'offset':1},
 'Lendário':{'minimum':21,'maximum':25,'action':'LIVRE','cost':320,'die':12,'offset':2}}

def tier(ordinal:int):
 if type(ordinal)!=int or ordinal<1 or ordinal>25:raise Hold('INVALID_LEVEL')
 if ordinal<6:raise Hold('BRONZE_ACTIVATION_PROHIBITED')
 return next(({'category':k,**v} for k,v in TIERS.items() if v['minimum']<=ordinal<=v['maximum']),None)

def make_state(*,ordinal=11,actor='SYNTH-A',spirit='SYNTH-SPIRIT',normal_hp=90,normal_hp_max=180,normal_pa=160,normal_pa_max=240,committed=30,item_temp_hp=15,spirit_hp_max=24,spirit_pa_max=18):
 s={'actor_id':actor,'spirit_id':spirit,'ordinal':ordinal,'normal_hp':normal_hp,'normal_hp_max':normal_hp_max,'normal_pa':normal_pa,'normal_pa_max':normal_pa_max,'normal_pa_committed':committed,'item_temp_hp':item_temp_hp,'spirit_hp_max':spirit_hp_max,'spirit_pa_max':spirit_pa_max,'spirit_temp_hp':0,'spirit_pa':0,'form_active':False,'duration_left':0,'active_scene':None,'used_scenes':[],'last_activation_ordinal':None,'rest_evidence':None,'consumed_events':[],'history':[],'scope':'LAB_TEST','pa_availability_policy':'TEST_CURRENT_MINUS_COMMITTED_NO_OFFICIAL_PRIORITY'}
 return check(s)

def spendable(s):
 check(s)
 if s['pa_availability_policy']!='TEST_CURRENT_MINUS_COMMITTED_NO_OFFICIAL_PRIORITY':raise Hold('SPENDABLE_AUTHORITY_NOT_BOUND')
 return max(0,s['normal_pa']-s['normal_pa_committed'])

def check(s):
 for k in ('normal_hp','normal_hp_max','normal_pa','normal_pa_max','normal_pa_committed','item_temp_hp','spirit_hp_max','spirit_pa_max','spirit_temp_hp','spirit_pa','duration_left'):
  if type(s[k])!=int or s[k]<0:raise Hold('INVALID_RESOURCE_'+k)
 if s['normal_pa']>s['normal_pa_max'] or s['normal_hp']>s['normal_hp_max'] or s['normal_pa_committed']>s['normal_pa_max']:raise Hold('RESOURCE_ABOVE_MAX')
 if not s['form_active'] and (s['spirit_temp_hp'] or s['spirit_pa'] or s['duration_left']):raise Hold('INACTIVE_FORM_LEAKING_RESERVE')
 if s['scope']!='LAB_TEST':raise Hold('NOT_LAB')
 return s

def append(s,event,kind,**detail):
 s['consumed_events'].append(event);s['history'].append({'event':event,'kind':kind,**detail});return check(s)

def activate(s,*,event,scene,die_result,action,source_proof,scene_proof):
 check(s)
 if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
 spec=tier(s['ordinal'])
 if source_proof!='SYNTHETIC_TEST_ONLY' or scene_proof!='SYNTHETIC_TEST_ONLY':raise Hold('SOURCE_OR_SCENE_NOT_ADMITTED')
 if not event or not scene:raise Hold('EVENT_SCENE_MISSING')
 if action!=spec['action']:raise Hold('WRONG_ACTION')
 if type(die_result)!=int or die_result not in range(1,spec['die']+1):raise Hold('DIE_RECEIPT_INVALID')
 if s['form_active']:raise Hold('ALREADY_ACTIVE')
 if scene in s['used_scenes']:raise Hold('SCENE_ALREADY_USED')
 if s['last_activation_ordinal'] is not None:
  rest=s['rest_evidence']
  if not rest or rest['after_activation_index']!=s['last_activation_ordinal'] or not rest['completed'] or rest['kind'] not in ('SHORT','LONG') or rest['scope']!='SYNTHETIC_TEST_ONLY':raise Hold('REST_AFTER_LAST_USE_REQUIRED')
 if spendable(s)<spec['cost']:raise Hold('PA_GASTAVEL_INSUFFICIENT')
 a=deepcopy(s);a['normal_pa']-=spec['cost'];a['spirit_temp_hp']=a['spirit_hp_max'];a['spirit_pa']=a['spirit_pa_max'];a['form_active']=True;a['duration_left']=die_result+spec['offset'];a['active_scene']=scene;a['used_scenes'].append(scene);a['last_activation_ordinal']=len(a['used_scenes']);a['rest_evidence']=None
 return append(a,event,'ACTIVATE_TEST',tier=spec['category'],action=action,cost=spec['cost'],die=die_result,duration=a['duration_left'],scene=scene,spirit=a['spirit_id']),'TEST_ACTIVATION_APPLIED'

def effect_damage(s,*,event,amount):
 check(s)
 if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
 if type(amount)!=int or amount<0:raise Hold('INVALID_DAMAGE')
 a=deepcopy(s);left=amount;hp_sp=min(left,a['spirit_temp_hp']) if a['form_active'] else 0;left-=hp_sp;a['spirit_temp_hp']-=hp_sp
 hp_item=min(left,a['item_temp_hp']);left-=hp_item;a['item_temp_hp']-=hp_item
 hp_normal=min(left,a['normal_hp']);left-=hp_normal;a['normal_hp']-=hp_normal
 return append(a,event,'DAMAGE_TEST',damage=amount,absorbed={'spirit':hp_sp,'item':hp_item,'normal':hp_normal,'overkill':left}),'TEST_EFFECT_APPLIED'

def advance_turn(s,*,event,scene):
 check(s)
 if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
 if not s['form_active'] or scene!=s['active_scene']:raise Hold('TURN_OUTSIDE_ACTIVE_FORM')
 a=deepcopy(s);a['duration_left']-=1;expired=a['duration_left']==0
 if expired:
  a['form_active']=False;a['spirit_temp_hp']=0;a['spirit_pa']=0;a['active_scene']=None
 return append(a,event,'EXPIRE_TEST' if expired else 'TURN_ADVANCE_TEST',remaining=a['duration_left'],expired=expired),'TEST_TURN_APPLIED'

def deactivate(s,*,event,reason='VOLUNTARY'):
 check(s)
 if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
 if not s['form_active']:raise Hold('FORM_INACTIVE')
 if reason not in ('VOLUNTARY','INTERRUPTED'):raise Hold('BAD_DEACTIVATION_REASON')
 a=deepcopy(s);a['form_active']=False;a['spirit_temp_hp']=0;a['spirit_pa']=0;a['duration_left']=0;a['active_scene']=None
 return append(a,event,'DEACTIVATE_TEST',reason=reason),'TEST_DEACTIVATION_APPLIED'

def rest(s,*,event,kind,completed,after_activation_index,scene_for_next,recorded_duration_h=None,source='SYNTHETIC_TEST_ONLY'):
 check(s)
 if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
 if s['form_active']:raise Hold('ACTIVE_FORM_CANNOT_REST')
 if kind not in ('SHORT','LONG') or not completed or source!='SYNTHETIC_TEST_ONLY':raise Hold('REST_NOT_CERTIFIED')
 if kind=='SHORT' and (type(recorded_duration_h) not in (int,float) or not 4<=recorded_duration_h<=6):raise Hold('SHORT_REST_NOT_COMPLETED')
 if s['last_activation_ordinal'] is None or after_activation_index!=s['last_activation_ordinal']:raise Hold('REST_NOT_AFTER_LAST_USE')
 if not scene_for_next or scene_for_next in s['used_scenes']:raise Hold('NEXT_SCENE_UNAVAILABLE')
 a=deepcopy(s);a['rest_evidence']={'kind':kind,'completed':True,'after_activation_index':after_activation_index,'scope':source,'next_scene':scene_for_next,'duration_h_if_provided':recorded_duration_h}
 return append(a,event,'REST_TEST',kind_rest=kind,after_index=after_activation_index,new_scene=scene_for_next),'TEST_REST_RECORDED'

def change_spirit(s,*,event,new_spirit):
 check(s)
 if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
 if s['form_active'] or not new_spirit:raise Hold('SPIRIT_SWITCH_NOT_AUTHORIZED')
 a=deepcopy(s);a['spirit_id']=new_spirit
 return append(a,event,'SPIRIT_SWITCH_TEST',used_scenes_preserved=True),'TEST_SWITCH_RECORDED'

def regression():
 checks=0
 def ok(x):
  nonlocal checks
  assert x;checks+=1
 for lv,t in [(5,None),(6,'Prata'),(10,'Prata'),(11,'Ouro'),(15,'Ouro'),(16,'Ouro Negro'),(20,'Ouro Negro'),(21,'Lendário'),(25,'Lendário')]:
  if lv==5:
   try:tier(lv)
   except Hold:ok(True)
   else:raise AssertionError('Bronze admitted')
  else:ok(tier(lv)['category']==t)
 x=make_state(normal_pa=160,committed=90)
 try:activate(x,event='A',scene='S1',die_result=4,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
 except Hold as e:ok(str(e)=='PA_GASTAVEL_INSUFFICIENT')
 else:raise AssertionError('committed PA spent')
 a=make_state(normal_pa=160,committed=30)
 a,_=activate(a,event='A',scene='S1',die_result=4,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
 ok(a['normal_pa']==80 and a['duration_left']==5 and a['normal_pa_committed']==30)
 ok(activate(a,event='A',scene='S1',die_result=4,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')[1].startswith('NOOP'))
 a,_=effect_damage(a,event='D',amount=44);ok(a['spirit_temp_hp']==0 and a['item_temp_hp']==0 and a['normal_hp']==85)
 for i in range(4):a,_=advance_turn(a,event=f'T{i}',scene='S1')
 ok(a['duration_left']==1 and a['form_active'])
 a,_=advance_turn(a,event='T4',scene='S1');ok(not a['form_active'] and a['spirit_pa']==0 and a['normal_pa']==80)
 try:activate(a,event='B',scene='S2',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
 except Hold as e:ok(str(e)=='REST_AFTER_LAST_USE_REQUIRED')
 else:raise AssertionError('no rest accepted')
 a,_=rest(a,event='REST_LONG',kind='LONG',completed=True,after_activation_index=1,scene_for_next='S2',source='SYNTHETIC_TEST_ONLY')
 ok(a['normal_pa']==80 and a['normal_hp']==85)
 # Need more PA to reach cost80 when committed30: this intentionally remains BLOCKED.
 try:activate(a,event='B',scene='S2',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
 except Hold as e:ok(str(e)=='PA_GASTAVEL_INSUFFICIENT')
 else:raise AssertionError('PA committed bypassed')
 a,_=change_spirit(a,event='SWITCH',new_spirit='OTHER_SYNTH_SPIRIT')
 ok(a['used_scenes']==['S1'] and a['last_activation_ordinal']==1)
 for kwargs in [{'kind':'SHORT','recorded_duration_h':3},{'kind':'LONG','completed':False},{'kind':'SHORT','recorded_duration_h':7}]:
  try:rest(a,event='REST_X',kind=kwargs['kind'],completed=kwargs.get('completed',True),after_activation_index=1,scene_for_next='S3',recorded_duration_h=kwargs.get('recorded_duration_h'))
  except Hold:ok(True)
  else:raise AssertionError('invalid rest accepted')
 lend=make_state(ordinal=21,normal_pa=400,normal_pa_max=500,committed=20)
 lend,_=activate(lend,event='LA',scene='LS',die_result=12,action='LIVRE',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
 ok(lend['duration_left']==14 and lend['normal_pa']==80)
 bronze=make_state(ordinal=5)
 try:activate(bronze,event='BA',scene='BS',die_result=3,action='COMPLETA',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
 except Hold:ok(True)
 else:raise AssertionError('bronze allowed')
 # Actor's used scenes survive spirit switch, and LONG is admissible, independent from duration hours
 return {'checks':checks,'tiers':len(TIERS),'production':'HOLD','resource_policy':'TEST_CURRENT_MINUS_COMMITTED_ONLY'}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
