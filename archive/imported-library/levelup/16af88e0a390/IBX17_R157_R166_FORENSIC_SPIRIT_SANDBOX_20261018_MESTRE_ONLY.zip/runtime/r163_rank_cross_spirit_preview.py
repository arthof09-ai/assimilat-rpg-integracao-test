"""R163 Bronze5->Prata1 counterfactual, with spiritual progression separately gated.
R129 cannot be replayed after security refusal; this module is PURE READONLY.
"""
from __future__ import annotations
from copy import deepcopy
from fractions import Fraction
import json

class RankHold(ValueError):pass
RULE_VERSION='2026-10-09T04:07:06.313Z'
SPIRIT_VERSION='2026-10-09T19:35:48.531Z'

def preview(before,*,choice,source_version,spirit=None):
    if source_version!=RULE_VERSION:raise RankHold('SOURCE_VERSION_NOT_MATCHED')
    if before.get('scope')!='LAB_TEST':raise RankHold('PARTY_OR_PRODUCTION_NOT_AUTHORIZED')
    expected={'level':5,'rank':'Bronze 5','attrs':{'FOR':4,'DES':3,'CON':2,'INT':14,'SAB':6,'CAR':6},
              'hp_natural':42,'pa_natural':86,'hp_current':20,'pa_current':45,'ff':90,'ca':9}
    if any(before.get(k)!=v for k,v in expected.items()):raise RankHold('R129_BEFORE_SOURCE_CONFLICT')
    if choice!={'INT':2}:raise RankHold('CHOICE_NOT_THE_AUTHORIZED_TEST_VECTOR')
    after=deepcopy(before);after.update(level=6,rank='Prata 1',attrs={**before['attrs'],'INT':16},
       hp_natural=54,pa_natural=142,hp_max=54,pa_max=142)
    if after['hp_natural']==96 or after['pa_natural']==228:raise RankHold('DOUBLE_REBASE')
    eligibility={'before':False,'after':True,'form_auto_activated':False,
       'scene_consumed':False,'rest_reset':False,'normal_resource_current_preserved':True}
    spiritual={'classification':'NO_ASSIMILATED_SPIRIT_SOURCE_BOUND','allocation_delta':0,'form_active':False}
    if spirit:
        if spirit.get('scope')!='SYNTHETIC_TEST_ONLY':raise RankHold('REAL_SPIRIT_SOURCE_PROOF_MISSING')
        if type(spirit.get('bap'))!=int or type(spirit.get('cap'))!=int or spirit['bap']<=0 or spirit['cap']<1:raise RankHold('SPIRIT_MATH_BAD')
        ordinal=min(6,spirit['cap']);br=Fraction(spirit['bap'],2)*ordinal
        allocation=br.numerator//br.denominator
        if spirit.get('prior_bronze_backfill_evidenced') is not True:
            spiritual={'classification':'HOLD_PRE_PRATA_BACKFILL_NOT_ESTABLISHED',
              'potential_distributable_if_later_admitted':allocation,
              'carry_if_later_admitted':str(br-allocation),'form_active':False,
              'allocation_delta':'UNDETERMINED_NOT_APPLIED'}
        else:
            # Even synthetic proof of historical points is not an actor's decision;
            # it only permits numerical planning, never actual character allocation.
            spiritual={'classification':'SYNTHETIC_NUMERIC_PREVIEW_ONLY',
              'potential_distributable':allocation,'carry':str(br-allocation),
              'actor_choice_required':True,'form_active':False,'allocation_delta':0}
    return {'decision':'RANK_PREVIEW_READY_WRITE_HOLD_SECURITY_REFUSAL',
      'before':deepcopy(before),'after':after,'rank_transition':'Bronze5→Prata1',
      'source_version':RULE_VERSION,'spirit_rule_version':SPIRIT_VERSION,
      'spiritual_eligibility':eligibility,'spiritual_overlay':spiritual,
      'native_writes':0,'source_fixture':'R129_TEST_SEPARATE_FROM_R110'}

def baseline():return {'scope':'LAB_TEST','level':5,'rank':'Bronze 5',
 'attrs':{'FOR':4,'DES':3,'CON':2,'INT':14,'SAB':6,'CAR':6},
 'hp_natural':42,'pa_natural':86,'hp_max':42,'pa_max':86,
 'hp_current':20,'pa_current':45,'ff':90,'ca':9,'form_active':False,'lock_history':[]}

def regression():
    b=baseline();r=preview(b,choice={'INT':2},source_version=RULE_VERSION)
    assert r['after']['hp_max']==54 and r['after']['pa_max']==142
    assert (r['after']['hp_current'],r['after']['pa_current'])==(20,45)
    assert r['spiritual_eligibility']['after'] and not r['after']['form_active']
    r2=preview(b,choice={'INT':2},source_version=RULE_VERSION,spirit={'scope':'SYNTHETIC_TEST_ONLY','bap':11,'cap':6})
    assert r2['spiritual_overlay']['classification']=='HOLD_PRE_PRATA_BACKFILL_NOT_ESTABLISHED'
    assert r2['spiritual_overlay']['potential_distributable_if_later_admitted']==33
    r3=preview(b,choice={'INT':2},source_version=RULE_VERSION,spirit={'scope':'SYNTHETIC_TEST_ONLY','bap':11,'cap':6,'prior_bronze_backfill_evidenced':True})
    assert r3['spiritual_overlay']['classification']=='SYNTHETIC_NUMERIC_PREVIEW_ONLY' and r3['spiritual_overlay']['actor_choice_required']
    for args in [{'choice':{'INT':1,'SAB':1}}, {'source_version':'OLD'}]:
        try:preview(b,choice=args.get('choice',{'INT':2}),source_version=args.get('source_version',RULE_VERSION))
        except RankHold:pass
        else:raise AssertionError('unauthorized input admitted')
    return {'checks':8,'rank_native_writes':0,'rebase':(42,54,86,142),'spirit_at_prata':'ELIGIBILITY_ONLY','old_pre_prata_budget':'HOLD'}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
