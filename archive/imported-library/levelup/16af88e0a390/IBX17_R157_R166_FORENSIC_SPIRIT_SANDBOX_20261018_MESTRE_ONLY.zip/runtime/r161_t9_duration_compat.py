"""R161 — specialised T9 governs activation; VZ sandbox rows do not override it.
Compatibility duration +1 is allowed only with a provenance label, TEST or
physically attested specialist-source event, never just caller bool.
"""
from r149_150_spirit_runtime import tier,Hold
from dataclasses import dataclass

SPECIALIST_SOURCE='3f2c2b324ede81c0ae0ee4e66212edc9'
SPECIALIST_VERSION='2026-10-09T19:35:48.531Z'

@dataclass(frozen=True)
class CompatibilityEvidence:
    scope:str
    source_page_id:str
    source_version:str
    actor_id:str
    spirit_id:str
    native_readback:bool=False

def duration(*,actor_ordinal:int,rolled:int,actor_id:str,spirit_id:str,compatibility_evidence:CompatibilityEvidence|None=None):
    source=tier(actor_ordinal)
    if type(rolled)!=int or not 1<=rolled<=source['die']:raise Hold('INVALID_DURATION_ROLL')
    bonus=0;admissibility='NO_COMPATIBILITY_BONUS_CLAIMED'
    if compatibility_evidence:
        ev=compatibility_evidence
        if (ev.actor_id,ev.spirit_id)!=(actor_id,spirit_id):raise Hold('COMPATIBILITY_WRONG_ACTOR_SPIRIT')
        if ev.scope=='SYNTHETIC_TEST_ONLY':
            bonus=1;admissibility='TEST_ONLY_COMPATIBILITY_ASSUMPTION'
        elif (ev.scope=='SPECIALIST_T9_CONFIRMED' and ev.source_page_id==SPECIALIST_SOURCE
              and ev.source_version==SPECIALIST_VERSION and ev.native_readback):
            # This record is source-identified, not an independent human attestation;
            # external replay/review still required to promote to campaign effect.
            bonus=1;admissibility='DOCUMENTARY_COMPATIBILITY_CANDIDATE_REVIEW_REQUIRED'
        else:raise Hold('COMPATIBILITY_UNVERIFIED_SOURCE')
    return {'tier':source['category'],'action':source['action'],'cost':source['cost'],
      'die':source['die'],'rolled_test':rolled,'base_duration':rolled+source['offset'],
      'compatibility_bonus':bonus,'computed_duration':rolled+source['offset']+bonus,
      'source_authority':SPECIALIST_SOURCE,'source_version':SPECIALIST_VERSION,
      'evidence_class':admissibility,'native_write':False}

def regression():
    checked=0
    def ck(x):
        nonlocal checked
        assert x;checked+=1
    for ordinal,category,cost,die,offset in [(6,'Prata',40,6,1),(11,'Ouro',80,8,1),
      (16,'Ouro Negro',160,10,1),(21,'Lendário',320,12,2)]:
        r=duration(actor_ordinal=ordinal,rolled=die,actor_id='A',spirit_id='S')
        ck(r['tier']==category and r['cost']==cost and r['computed_duration']==die+offset)
    test=CompatibilityEvidence('SYNTHETIC_TEST_ONLY','','','A','S')
    ck(duration(actor_ordinal=21,rolled=12,actor_id='A',spirit_id='S',compatibility_evidence=test)['computed_duration']==15)
    wrong=CompatibilityEvidence('SYNTHETIC_TEST_ONLY','','','B','S')
    try:duration(actor_ordinal=21,rolled=12,actor_id='A',spirit_id='S',compatibility_evidence=wrong)
    except Hold:ck(True)
    else:raise AssertionError('wrong actor accepted')
    claimed=CompatibilityEvidence('SPECIALIST_T9_CONFIRMED',SPECIALIST_SOURCE,SPECIALIST_VERSION,'A','S',False)
    try:duration(actor_ordinal=21,rolled=12,actor_id='A',spirit_id='S',compatibility_evidence=claimed)
    except Hold:ck(True)
    else:raise AssertionError('self-declared compatibility accepted')
    for bad in [5,0,26]:
        try:duration(actor_ordinal=bad,rolled=2,actor_id='A',spirit_id='S')
        except Hold:ck(True)
        else:raise AssertionError('bad tier accepted')
    return {'checks':checked,'source':'T9_SPECIALIST','additional_compatibility_rule':'PROVENANCE_BOUND','notion_writes':0}
if __name__=='__main__':print(regression())
