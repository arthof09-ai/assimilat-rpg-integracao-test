"""R159 — never conflate actor's deleted spirit mention with a same-title beast.
The Notion evidence here was physically re-opened read-only on 2026-10-18.
No production or PARTY writes; no facts promoted from mere name matching.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
import json

class SourceHold(ValueError):pass
@dataclass(frozen=True)
class SourceNode:
    page_id:str;title:str;version:str;kind:str;child_ids:tuple[str,...]=();deleted_children:int=0
@dataclass(frozen=True)
class Link:
    actor_page_id:str; actor_version:str; spirit_mention_page_id:str

def reconcile(actor:Link,original:SourceNode,current:SourceNode,beast_child:SourceNode,*,assimilation_receipt=None,derived_distributions=None):
    observations={'actor':actor.actor_page_id,'spirit_mention':actor.spirit_mention_page_id,
      'historical_spirit_id':original.page_id,'current_beast_id':current.page_id,
      'beast_child_id':beast_child.page_id,
      'historical_link_physically_matched':actor.spirit_mention_page_id==original.page_id,
      'historical_children_deleted':original.deleted_children,
      'new_tree_is_same_object':current.page_id==original.page_id,
      'new_tree_child_body_matches_root':beast_child.title.startswith(current.title),
      'assimilation_receipt_available':bool(assimilation_receipt),
      'distribution_physically_bound':bool(derived_distributions)}
    if actor.spirit_mention_page_id!=original.page_id:return {'status':'HOLD_WRONG_ACTOR_SOURCE','observations':observations,'certified':False}
    if original.deleted_children or current.page_id!=original.page_id or not observations['new_tree_child_body_matches_root']:
        return {'status':'HOLD_SOURCE_IDENTITY_AND_DELETION','observations':observations,
          'missing':['active_source_relation_between_old_spirit_page_and_new_beast_tree',
                     'active_unambiguous_beast_species_per_rank_child',
                     'assimilated_spirit_receipt_with_actor_and_source_version',
                     'transformation_distribution_and_cap_provenance'],
          'certified':False,'writes':0}
    if not assimilation_receipt or not derived_distributions:
        return {'status':'HOLD_ASSIMILATION_OR_DISTRIBUTION','observations':observations,'certified':False,'writes':0}
    return {'status':'CANDIDATE_EVIDENCE_REQUIRES_INDEPENDENT_SOURCE_REVIEW','observations':observations,'certified':False,'writes':0}

def physical_case():
    link=Link('86bc2b324ede827699688140e82db00b','2026-10-01T09:40:50.721Z','60fc2b324ede836283f381eb62a37400')
    old=SourceNode('60fc2b324ede836283f381eb62a37400','Espectro da Morte','2026-09-30T04:39:09.863Z','LEGACY_SPIRIT_CATALOG',deleted_children=7)
    new=SourceNode('0f8c2b324ede824088f581e806c6a066','Espectro da Morte','2026-10-01T18:00:54.783Z','BEAST_CATALOG',child_ids=('230c2b324ede824d89a4815f1f4391d3',))
    c=SourceNode('230c2b324ede824d89a4815f1f4391d3','Draconis Infernum','UNRESOLVED_CHILD_VERSION','BEAST_RANK_CHILD')
    return link,old,new,c

def regression():
    a,o,n,c=physical_case()
    r=reconcile(a,o,n,c,assimilation_receipt='TEST_ONLY_SIMULATED',derived_distributions={'FOR':999})
    assert r['status']=='HOLD_SOURCE_IDENTITY_AND_DELETION' and not r['certified']
    assert r['observations']['historical_children_deleted']==7
    assert r['observations']['spirit_mention']==o.page_id
    assert r['observations']['new_tree_is_same_object'] is False
    assert r['observations']['new_tree_child_body_matches_root'] is False
    assert r['observations']['assimilation_receipt_available'] is True and r['certified'] is False
    wrong=Link(a.actor_page_id,a.actor_version,'FAKE')
    assert reconcile(wrong,o,n,c)['status']=='HOLD_WRONG_ACTOR_SOURCE'
    assert len(r['missing'])==4
    return {'checks':8,'status':r['status'],'missing':r['missing'],'campaign_write':0}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
