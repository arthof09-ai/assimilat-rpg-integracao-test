"""R162: T11 spirit change must replace overlay, not only spirit_id.
Preserves ACTOR's scene lock/PA/current resources and Spirit previous history.
Only TEST-synthetic overlays are accepted in this standalone runtime.
"""
from copy import deepcopy
from r149_150_spirit_runtime import check,append,Hold

LAB_SCOPE='LAB_TEST'

def switch_with_source(s,*,event,new_spirit_id,evidence,new_max_hp,new_max_pa,cap_ordinal,bap_synthetic):
    check(s)
    if event in s['consumed_events']:return deepcopy(s),'NOOP_EVENT_ALREADY_CONSUMED'
    if s['form_active'] or s['spirit_temp_hp'] or s['spirit_pa']:raise Hold('SPIRIT_SWITCH_WHILE_ACTIVE')
    if not isinstance(evidence,dict):raise Hold('SOURCE_EVIDENCE_MISSING')
    valid=(evidence.get('source_class')=='SYNTHETIC_TEST_ONLY' and evidence.get('scope')==LAB_SCOPE
      and evidence.get('actor_id')==s['actor_id'] and evidence.get('spirit_id')==new_spirit_id
      and evidence.get('event_id')==event)
    if not valid:raise Hold('NEW_SPIRIT_SOURCE_UNVERIFIED')
    if not new_spirit_id or new_spirit_id==s['spirit_id']:raise Hold('INVALID_NEW_SPIRIT')
    if type(new_max_hp)!=int or type(new_max_pa)!=int or min(new_max_hp,new_max_pa)<0:raise Hold('INVALID_NEW_RESERVES')
    if type(cap_ordinal)!=int or type(bap_synthetic)!=int or not 1<=cap_ordinal<=25 or bap_synthetic<1:raise Hold('INVALID_TAP_OR_CAP')
    a=deepcopy(s);old={'spirit_id':a['spirit_id'],'max_hp':a['spirit_hp_max'],
       'max_pa':a['spirit_pa_max'],'used_scenes':list(a['used_scenes'])}
    a['spirit_id']=new_spirit_id;a['spirit_hp_max']=new_max_hp;a['spirit_pa_max']=new_max_pa
    a.setdefault('spirit_sources',[]).append({'event':event,'spirit_id':new_spirit_id,
       'cap':cap_ordinal,'bap_test':bap_synthetic,'scope':'SYNTHETIC_TEST_ONLY'})
    result=append(a,event,'SWITCH_SPIRIT_AND_OVERLAY_TEST',old=old,new_spirit=new_spirit_id,
      new_max_hp=new_max_hp,new_max_pa=new_max_pa,used_scenes_preserved=True)
    assert result['used_scenes']==s['used_scenes'] and result['normal_pa']==s['normal_pa']
    return result,'TEST_SWITCH_WITH_NEW_OVERLAY_SOURCE'

def regression():
    from r149_150_spirit_runtime import make_state,activate,deactivate,rest
    s=make_state(ordinal=11,normal_pa=220,normal_pa_max=260,committed=40)
    s,_=activate(s,event='A',scene='SC-1',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
    s,_=deactivate(s,event='D')
    before=deepcopy(s)
    ev={'source_class':'SYNTHETIC_TEST_ONLY','scope':'LAB_TEST','actor_id':s['actor_id'],
        'spirit_id':'NEW-SYNTH-SPIRIT','event_id':'SW'}
    checks=0
    def ck(q):
        nonlocal checks
        assert q;checks+=1
    try:switch_with_source(s,event='SW',new_spirit_id='NEW-SYNTH-SPIRIT',evidence=None,new_max_hp=999,new_max_pa=999,cap_ordinal=12,bap_synthetic=11)
    except Hold:ck(True)
    else:raise AssertionError('no-source switch accepted')
    bad=ev|{'actor_id':'FAKE'}
    try:switch_with_source(s,event='SW',new_spirit_id='NEW-SYNTH-SPIRIT',evidence=bad,new_max_hp=999,new_max_pa=999,cap_ordinal=12,bap_synthetic=11)
    except Hold:ck(True)
    else:raise AssertionError('wrong actor accepted')
    a,status=switch_with_source(s,event='SW',new_spirit_id='NEW-SYNTH-SPIRIT',evidence=ev,new_max_hp=8,new_max_pa=9,cap_ordinal=12,bap_synthetic=11)
    ck(status=='TEST_SWITCH_WITH_NEW_OVERLAY_SOURCE')
    ck(a['spirit_hp_max']==8 and a['spirit_pa_max']==9)
    ck(a['used_scenes']==['SC-1'] and a['last_activation_ordinal']==1)
    ck(a['normal_pa']==before['normal_pa'] and a['normal_pa_committed']==before['normal_pa_committed'])
    ck(s['spirit_id']==before['spirit_id'])
    ck(switch_with_source(a,event='SW',new_spirit_id='NEW-SYNTH-SPIRIT',evidence=ev,new_max_hp=8,new_max_pa=9,cap_ordinal=12,bap_synthetic=11)[1].startswith('NOOP'))
    try:activate(a,event='A2',scene='SC-2',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
    except Hold as e:ck(str(e)=='REST_AFTER_LAST_USE_REQUIRED')
    else:raise AssertionError('spirit switch incorrectly resets T9-A')
    a,_=rest(a,event='REST',kind='LONG',completed=True,after_activation_index=1,scene_for_next='SC-2')
    a,_=activate(a,event='A2',scene='SC-2',die_result=2,action='PADRAO',source_proof='SYNTHETIC_TEST_ONLY',scene_proof='SYNTHETIC_TEST_ONLY')
    ck(a['spirit_temp_hp']==8 and a['spirit_pa']==9)
    ck(a['used_scenes']==['SC-1','SC-2'])
    return {'checks':checks,'new_spirit_reserve_hp':8,'new_spirit_reserve_pa':9,
       'scene_lock_survives_switch':True,'source_class':'SYNTHETIC_TEST_ONLY','writes':0}
if __name__=='__main__':print(regression())
