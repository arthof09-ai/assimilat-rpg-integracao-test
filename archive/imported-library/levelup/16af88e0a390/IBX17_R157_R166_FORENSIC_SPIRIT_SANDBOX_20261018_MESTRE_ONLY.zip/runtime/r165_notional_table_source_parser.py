"""R165 — Parse structured Notion enhanced Markdown VZ table into numeric sources.
No page/row IDs are invented; identifies source page/version and literal row
fingerprints. Never elevates VZ-SANDBOX-CANON to official campaign assimilation.
"""
from __future__ import annotations
from fractions import Fraction
from hashlib import sha256
import html,json,re
class TableHold(ValueError):pass

def no_markup(x):return html.unescape(re.sub(r'<[^>]*>','',x)).strip()
def normalized(t):return re.sub(r'\s+',' ',no_markup(t))

def parse_table(markdown):
    out=[]
    for raw in re.findall(r'<table\b[^>]*>(.*?)</table>',markdown,flags=re.DOTALL|re.I):
        rows=[]
        for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>',raw,flags=re.DOTALL|re.I):
            cells=re.findall(r'<td\b[^>]*>(.*?)</td>',row,flags=re.DOTALL|re.I)
            if cells:rows.append([normalized(x) for x in cells])
        if rows:out.append(rows)
    return out

def split_actor_spirit(label):
    p=label.split(' / ',1)
    if len(p)!=2 or not all(p):raise TableHold('ACTOR_SPIRIT_ROW_IDENTITY')
    return tuple(p)

def pfrac(v):
    v=v.strip().replace(',','.')
    try:return Fraction(v)
    except (ValueError,ZeroDivisionError):raise TableHold('INVALID_LOCALIZED_FRACTION')

def parse_transform_matrix(page_body,*,source_page_id,source_version):
    if source_page_id!='3f2c2b324ede816198a5f0fb525223ee' or source_version!='2026-10-07T21:37:03.824Z':raise TableHold('SOURCE_VERSION_NOT_PINNED')
    tables=parse_table(page_body)
    matrices=[t for t in tables if len(t)>1 and 'Personagem / Espírito' in t[0]]
    if len(matrices)!=1:raise TableHold('MATRIX_UNIQUE_TABLE_NOT_FOUND')
    rows=[]
    for cells in matrices[0][1:]:
        if len(cells)!=7:raise TableHold('CELL_COUNT_MISMATCH')
        actor,spirit=split_actor_spirit(cells[0])
        try:eff=int(cells[1]);tap=pfrac(cells[2])
        except ValueError:raise TableHold('LEVEL_OR_TAP_INVALID')
        stated_budget=re.search(r'\d+',cells[3]);given=int(stated_budget.group()) if stated_budget else -1
        parts=cells[4].split('=')
        attrs=tuple(int(x) for x in re.findall(r'\+(\d+)',parts[0]))
        if len(attrs)!=6:raise TableHold('SIX_ATTRIBUTES_REQUIRED')
        summed=eff*tap;calculated=sum(attrs)
        carry=summed-int(summed)
        textcarry=Fraction(1,2) if 'carry 0,5' in cells[3] else Fraction(0,1)
        if not (given==calculated==int(summed) and carry==textcarry):raise TableHold('SOURCE_BUDGET_MISMATCH')
        rows.append({'actor':actor,'spirit':spirit,'effective_ordinal':eff,
          'tap_numerator':tap.numerator,'tap_denominator':tap.denominator,
          'budget':given,'carry':str(carry),'attributes':dict(zip(('FOR','DES','CON','INT','SAB','CAR'),attrs)),
          'activation_literal':cells[6], 'source_page_id':source_page_id,'source_version':source_version,
          'row_fingerprint_sha256':sha256('|'.join(cells).encode()).hexdigest(),
          'classification':'VZ_SANDBOX_SOURCE_ROW_VERIFIED_NOT_CAMPAIGN'} )
    if len(rows)!=8 or len({(r['actor'],r['spirit']) for r in rows})!=8:raise TableHold('MATRIX_DENOMINATOR_OR_DUPLICATES')
    return rows

def sample_matrix():
    raw=[
      ('Serah / Arraia L1','21','10,5','220 + carry 0,5','+8 / +70 / +35 / +42 / +50 / +15 = 220','5','Livre · 320 PA · 1d12+3'),
      ('Darek / Tatu ON5','20','4','80','+20 / +10 / +25 / +8 / +13 / +4 = 80','4','Livre · 320 PA · 1d12+3'),
      ('Nym / Coruja L1','21','10,5','220 + carry 0,5','+8 / +50 / +30 / +42 / +75 / +15 = 220','5','Livre · 320 PA · 1d12+3'),
      ('Urosh / Salamandra L1','21','10,5','220 + carry 0,5','+55 / +20 / +70 / +32 / +32 / +11 = 220','5','Livre · 320 PA · 1d12+3'),
      ('Sel-Myr / Cervo ON5','20','4','80','+3 / +18 / +10 / +15 / +28 / +6 = 80','4','Movimento · 160 PA · 1d10+2'),
      ('Kael / Serpente L2','22','10,5','231','+22 / +66 / +33 / +55 / +44 / +11 = 231','5','Livre · 320 PA · 1d12+3'),
      ('Rhovan / Grifo L2','22','10,5','231','+58 / +58 / +33 / +27 / +44 / +11 = 231','5','Livre · 320 PA · 1d12+3'),
      ('Asha / Manta L1','21','10,5','220 + carry 0,5','+13 / +60 / +40 / +32 / +50 / +25 = 220','5','Livre · 320 PA · 1d12+3')]
    headers=['Personagem / Espírito','Lv efetivo','TAP','Orçamento','Delta FOR/DES/CON/INT/SAB/CAR','Habilidades','Ativação']
    return '<table header-row="true">'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in line)+'</tr>' for line in [headers]+raw)+'</table>'

def regression():
    root=sample_matrix();r=parse_transform_matrix(root,source_page_id='3f2c2b324ede816198a5f0fb525223ee',source_version='2026-10-07T21:37:03.824Z')
    assert len(r)==8
    assert sum(x['budget'] for x in r)==1502
    assert sum(x['carry']=='1/2' for x in r)==4
    assert r[0]['attributes']['DES']==70
    assert r[5]['attributes']['INT']==55
    assert all('NOT_CAMPAIGN' in x['classification'] for x in r)
    for replacement in ['220 + carry 0,5','+8 / +70']:
        assert replacement in root
    altered=root.replace('220 + carry 0,5','222 + carry 0,5',1)
    try:parse_transform_matrix(altered,source_page_id='3f2c2b324ede816198a5f0fb525223ee',source_version='2026-10-07T21:37:03.824Z')
    except TableHold:pass
    else:raise AssertionError('misstated budget accepted')
    try:parse_transform_matrix(root,source_page_id='OTHER',source_version='2026-10-07T21:37:03.824Z')
    except TableHold:pass
    else:raise AssertionError('wrong source accepted')
    return {'rows':len(r),'total':sum(x['budget'] for x in r),'source':'VZ_SANDBOX','checks':8}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
