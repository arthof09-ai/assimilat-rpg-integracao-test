"""R160: external physically read VZ-08 v1.1 sandbox numeric corpus.
Every row is VZ-SANDBOX-CANON, NEVER general-campaign assimilation certification.
The active specialised T9 table remains the authority for action/cost/duration.
"""
from fractions import Fraction
from hashlib import sha256
import json

SOURCE={'id':'3f2c2b324ede816198a5f0fb525223ee','version':'2026-10-07T21:37:03.824Z','scope':'VZ_SANDBOX_CANON','final_totals_complete':0,'row_count':8}
ATTRS=('FOR','DES','CON','INT','SAB','CAR')
# Transcribed directly from the root source table and its BAP table, physically read 2026-10-18.
ROWS=[
 ('Serah','Arraia L1',21,21,(8,70,35,42,50,15),220,Fraction(1,2)),
 ('Darek','Tatu ON5',20,8,(20,10,25,8,13,4),80,Fraction(0,1)),
 ('Nym','Coruja L1',21,21,(8,50,30,42,75,15),220,Fraction(1,2)),
 ('Urosh','Salamandra L1',21,21,(55,20,70,32,32,11),220,Fraction(1,2)),
 ('Sel-Myr','Cervo ON5',20,8,(3,18,10,15,28,6),80,Fraction(0,1)),
 ('Kael','Serpente L2',22,21,(22,66,33,55,44,11),231,Fraction(0,1)),
 ('Rhovan','Grifo L2',22,21,(58,58,33,27,44,11),231,Fraction(0,1)),
 ('Asha','Manta L1',21,21,(13,60,40,32,50,25),220,Fraction(1,2)),
]

def evaluate(row):
    actor,spirit,effective_level,bap,attr,documented_total,documented_carry=row
    if effective_level<1 or bap<1 or len(attr)!=len(ATTRS) or any(type(x)!=int or x<0 for x in attr):raise ValueError('INVALID_ROW')
    exact=Fraction(bap,2)*effective_level
    result={'actor':actor,'spirit':spirit,'effective_level':effective_level,'bap':bap,
      'tap_numerator':bap,'tap_denominator':2,'budget_floor':exact.numerator//exact.denominator,
      'carry':str(exact-int(exact)),'allocated':dict(zip(ATTRS,attr)),
      'source_id':SOURCE['id'],'source_version':SOURCE['version'],'authority':'SANDBOX_ONLY_NOT_REAL_ASSIMILATION'}
    result['sum_distributed']=sum(attr)
    result['checks']={'budget_matches':result['budget_floor']==documented_total,
      'carry_matches':exact-int(exact)==documented_carry,
      'distribution_matches':sum(attr)==documented_total,
      'source_scope_correct':SOURCE['scope']=='VZ_SANDBOX_CANON'}
    result['classification']='VZ_SANDBOX_OVERLAY_VERIFIED' if all(result['checks'].values()) else 'HOLD_NUMERIC_CONFLICT'
    result['official_campaign_binding']=False
    blob=json.dumps(result,sort_keys=True,separators=(',',':'),ensure_ascii=False)
    result['receipt_sha256']=sha256(blob.encode()).hexdigest()
    return result

def ledger():return [evaluate(row) for row in ROWS]

def regression():
    v=ledger();assert len(v)==8 and all(x['classification']=='VZ_SANDBOX_OVERLAY_VERIFIED' for x in v)
    assert all(not x['official_campaign_binding'] for x in v)
    assert sum(x['sum_distributed'] for x in v)==sum(x['budget_floor'] for x in v)
    assert [x['budget_floor'] for x in v]==[220,80,220,220,80,231,231,220]
    assert [x['carry'] for x in v]==['1/2','0','1/2','1/2','0','0','0','1/2']
    bad=list(ROWS[0]);bad[5]=221
    assert evaluate(tuple(bad))['classification']=='HOLD_NUMERIC_CONFLICT'
    bad=list(ROWS[0]);bad[4]=(8,70,35,42,50,16)
    assert evaluate(tuple(bad))['classification']=='HOLD_NUMERIC_CONFLICT'
    return {'rows_valid':len(v),'budget_total':sum(x['budget_floor'] for x in v),
      'carry_rows':sum(x['carry']=='1/2' for x in v), 'campaign_bound':0,
      'source_version':SOURCE['version'],'checks':7}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
