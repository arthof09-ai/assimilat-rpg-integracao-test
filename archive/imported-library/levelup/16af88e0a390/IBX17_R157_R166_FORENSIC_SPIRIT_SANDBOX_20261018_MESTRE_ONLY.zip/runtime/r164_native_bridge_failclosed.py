"""R164: reusable pure interlock between generated write-set and Notion calls.
This module never sends Notion requests. The connected executor must perform
intent write -> independent read -> stage write -> independent read -> journal
-> independent read. A safety refusal fences the event, no retry/alternate API.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from hashlib import sha256
import json

LAB='3fbc2b324ede804a95fafcb7b293c92c'
class BridgeHold(ValueError):pass

def h(s):return sha256(s.encode()).hexdigest()
@dataclass(frozen=True)
class WriteIntent:
    tx:str;stage:str;target:str;parent:str;source_version:str
    expected_page_version:str;source_body_hash:str;before:str;after:str
    authority:str='DIR-MESTRE-LABS-REPLICAS-20261016-001'
    def __post_init__(self):
        if self.parent!=LAB or self.authority!='DIR-MESTRE-LABS-REPLICAS-20261016-001':raise BridgeHold('WRITER_SCOPE')
        if not all((self.tx,self.stage,self.target,self.source_version,self.expected_page_version,self.source_body_hash)):raise BridgeHold('INCOMPLETE_INTENT')
        if self.before==self.after:raise BridgeHold('NOOP_NOT_A_WRITE')
    def prepare(self,page_text,current_version):
        if current_version!=self.expected_page_version:raise BridgeHold('STALE_PREVIEW')
        if page_text.count(self.before)!=1:raise BridgeHold('PRECONDITION_NOT_UNIQUE')
        return {'phase':'INTENT_PREPARED','request_contract':{'tool':'mcp__Notion__notion_update_page','command':'update_content',
                'page_id':self.target,'content_updates':[{'old_str':self.before,'new_str':self.after}],
                'allow_async':False},'before_sha256':h(self.before),'after_sha256':h(self.after),
                'page_version_observed':current_version,'write_is_executed':False}

def post_dispatch(intent:WriteIntent,*,before_page,observed_page,journal_state,tool_response,error_code=None):
    if error_code and 'security' in error_code.lower():
        if observed_page==before_page:return {'classification':'SECURITY_REFUSED_BEFORE','write_allowed':False,'retry_allowed':False}
        return {'classification':'UNKNOWN_EFFECT_SECURITY_REFUSAL','write_allowed':False,'retry_allowed':False}
    expected=before_page.replace(intent.before,intent.after,1)
    if observed_page!=expected:return {'classification':'OTHER_QUARANTINE','write_allowed':False,'retry_allowed':False}
    if not tool_response:return {'classification':'AFTER_NATIVE_RESPONSE_MISSING_HOLD','write_allowed':False,'retry_allowed':False}
    if journal_state=='COMMITTED':return {'classification':'AFTER_AND_JOURNAL_READBACK','write_allowed':False,'retry_allowed':False}
    return {'classification':'AFTER_CAUSAL_JOURNAL_CANDIDATE','write_allowed':False,'retry_allowed':False}

def regression():
    intent=WriteIntent('TX','S','P',LAB,'RULE@V1','NOTION@V1',h('SOURCE'),'FIELD: 1','FIELD: 2')
    a='PRE\nFIELD: 1\nSAFE\n';b='PRE\nFIELD: 2\nSAFE\n'
    assert intent.prepare(a,'NOTION@V1')['phase']=='INTENT_PREPARED'
    assert intent.prepare(a,'NOTION@V1')['write_is_executed'] is False
    assert post_dispatch(intent,before_page=a,observed_page=b,journal_state='PREPARED',tool_response={'page_id':'P'})['classification']=='AFTER_CAUSAL_JOURNAL_CANDIDATE'
    assert post_dispatch(intent,before_page=a,observed_page=b,journal_state='COMMITTED',tool_response={'page_id':'P'})['classification']=='AFTER_AND_JOURNAL_READBACK'
    assert post_dispatch(intent,before_page=a,observed_page=a,journal_state='PREPARED',tool_response=None,error_code='blocked by security')['classification']=='SECURITY_REFUSED_BEFORE'
    assert post_dispatch(intent,before_page=a,observed_page='OTHER',journal_state='PREPARED',tool_response=None,error_code='blocked by security')['classification']=='UNKNOWN_EFFECT_SECURITY_REFUSAL'
    assert post_dispatch(intent,before_page=a,observed_page='OTHER',journal_state='PREPARED',tool_response={'page_id':'P'})['classification']=='OTHER_QUARANTINE'
    for args in [(a,'STALE'),(a+'FIELD: 1\n','NOTION@V1')]:
        try:intent.prepare(*args)
        except BridgeHold:pass
        else:raise AssertionError('stale or ambiguous accepted')
    return {'checks':9,'native_tool_called_by_module':False,'safety_refusal':'PERMANENT_FENCE_UNTIL_OFFICIAL_AUTHORIZATION'}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
