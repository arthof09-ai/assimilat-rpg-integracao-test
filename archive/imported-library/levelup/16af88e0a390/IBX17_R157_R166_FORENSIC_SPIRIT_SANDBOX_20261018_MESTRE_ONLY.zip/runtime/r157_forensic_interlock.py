"""IBX-17 R157: strictly observational transaction interlock.

It is NOT a Notion writer, a substitute for atomic CAS or an authorization
oracle. Historical security refusals are terminal to this automated caller.
A separate authorized intervention must be witnessed before any new write.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Any
import json

LAB='3fbc2b324ede804a95fafcb7b293c92c'


def digest(obj: Any) -> str:
    return sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

class Hold(ValueError):pass

@dataclass(frozen=True)
class StageObservation:
    tx_id: str
    stage: str
    target_id: str
    parent_id: str
    receipt_pre_version: str
    observed_version: str
    expected_after: Any
    expected_before: Any
    observed_state: Any
    journal: str
    terminal_marker: str
    original_native_reply: str | None
    provenance_bound_to_stage: bool
    past_security_refusal: bool
    authority: str
    source_version: str
    operator_identity: str

    def classify(self)->dict:
        missing=tuple(k for k in ('tx_id','stage','target_id','parent_id',
          'receipt_pre_version','observed_version','authority','source_version',
          'operator_identity') if not getattr(self,k))
        base={'tx':self.tx_id,'stage':self.stage,'target':self.target_id,
              'readback_version':self.observed_version,'write_authorized':False,
              'requires_external_intervention':True,'review':'SELF_REVIEW_ONLY'}
        def done(category,reason,*,next_action='HOLD'):
            return base|{'classification':category,'reason':reason,'next_action':next_action,
                         'before_sha':digest(self.expected_before),'after_sha':digest(self.expected_after),
                         'observed_sha':digest(self.observed_state)}
        if missing:return done('INCOMPLETE_EVIDENCE','MISSING:'+','.join(missing))
        if self.parent_id!=LAB or self.authority!='LAB_TEST_EXPLICIT_FROM_MESTRE':
            return done('AUTHORITY_HOLD','NO_LAB_WRITER')
        if self.receipt_pre_version==self.observed_version and self.terminal_marker=='COMMITTED':
            return done('VERSION_CONFLICT','TERMINAL_WITHOUT_OBSERVED_VERSION_ADVANCE')
        bp=digest(self.expected_before);ap=digest(self.expected_after);x=digest(self.observed_state)
        if bp==ap:return done('NO_EFFECT_RECEIPT','BEFORE_EQUALS_AFTER_UNSUITABLE_FOR_WRITE')
        if x not in (bp,ap):return done('UNKNOWN_EFFECT','PHYSICAL_OTHER_QUARANTINE')
        if self.terminal_marker=='COMMITTED' and (x!=ap or self.journal!='COMMITTED'):
            return done('FALSE_TERMINAL','TERMINAL_AHEAD_OF_PHYSICAL_OR_JOURNAL')
        if x==bp:
            if self.journal=='COMMITTED':return done('JOURNAL_AHEAD','BEFORE_BUT_COMMITTED_JOURNAL')
            if self.past_security_refusal:return done('REFUSED_BEFORE','SECURITY_REFUSAL_READBACK_BEFORE')
            return done('NOT_APPLIED','BEFORE_CONFIRMED',next_action='WAIT_AUTHORIZED_WRITE_PLAN')
        if self.journal=='COMMITTED':
            if self.terminal_marker=='COMMITTED':return done('FULLY_COMMITTED_OBSERVED','STAGES_SHOULD_STILL_BE_CROSS_CHECKED',next_action='READ_ONLY_NOOP')
            if self.past_security_refusal:return done('MARKER_STALE_SECURITY_HOLD','AFTER_AND_JOURNAL_MATCH_BUT_TERMINAL_REPAIR_WAS_REFUSED')
            return done('MARKER_STALE_CANDIDATE','NO_MECHANICAL_REPLAY',next_action='REQUEST_AUTHORIZED_MARKER_ONLY_RECONCILIATION')
        if self.journal=='PREPARED':
            if self.original_native_reply and self.provenance_bound_to_stage:
                return done('CAUSAL_JOURNAL_REPAIR_CANDIDATE','AFTER_WITH_BOUND_NATIVE_REPLY',next_action='REQUIRE_FRESH_PREFLIGHT_AND_LEGITIMATE_AUTHORITY')
            return done('AFTER_WITHOUT_CAUSAL_PROOF','MATERIAL_AFTER_BUT_JOURNAL_PREPARED')
        return done('UNKNOWN_JOURNAL','JOURNAL_VALUE_UNRECOGNIZED')


def regression():
    def sample(**kwargs):
        o=StageObservation(tx_id='R155',stage='NORMAL',target_id='TARGET',parent_id=LAB,
          receipt_pre_version='v0',observed_version='v1',expected_before={'level':17},
          expected_after={'level':18},observed_state={'level':18},journal='COMMITTED',
          terminal_marker='PREPARED',original_native_reply=None,provenance_bound_to_stage=False,
          past_security_refusal=True,authority='LAB_TEST_EXPLICIT_FROM_MESTRE',
          source_version='RULE@v1',operator_identity='MASTER_CONNECTED_PROFILE')
        return StageObservation(**(o.__dict__|kwargs)).classify()
    pairs=[({},'MARKER_STALE_SECURITY_HOLD'),
       ({'past_security_refusal':False},'MARKER_STALE_CANDIDATE'),
       ({'journal':'PREPARED'},'AFTER_WITHOUT_CAUSAL_PROOF'),
       ({'journal':'PREPARED','original_native_reply':'{page_id:X}','provenance_bound_to_stage':True},'CAUSAL_JOURNAL_REPAIR_CANDIDATE'),
       ({'observed_state':{'level':17},'journal':'PREPARED'},'REFUSED_BEFORE'),
       ({'observed_state':{'level':17},'journal':'COMMITTED'},'JOURNAL_AHEAD'),
       ({'observed_state':{'level':19}},'UNKNOWN_EFFECT'),
       ({'terminal_marker':'COMMITTED','journal':'PREPARED'},'FALSE_TERMINAL'),
       ({'terminal_marker':'COMMITTED','journal':'COMMITTED','past_security_refusal':False},'FULLY_COMMITTED_OBSERVED'),
       ({'authority':'PARTY_WRITER'},'AUTHORITY_HOLD'),
       ({'parent_id':'PARTY'},'AUTHORITY_HOLD'),
       ({'source_version':''},'INCOMPLETE_EVIDENCE')]
    for opts,expect in pairs:
        got=sample(**opts);assert got['classification']==expect,(opts,got)
        assert got['write_authorized'] is False
    assert sample()['next_action']=='HOLD'
    assert sample(past_security_refusal=False)['next_action'].startswith('REQUEST_AUTHORIZED')
    return {'directed_checks':len(pairs)+2,'classification':'R155_MARKER_STALE_SECURITY_HOLD','native_write':'NEVER'}
if __name__=='__main__':print(json.dumps(regression(),ensure_ascii=False))
