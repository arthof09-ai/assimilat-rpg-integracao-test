# LEVEL-UP-ENGINE / IBX-17 — Incremento R157–R166 (MESTRE-ONLY)

**Baseline:** R01–R156 preserved; latest physically confirmed prior checkpoint R156. New work is additive. No new operation, motor, or lab. Production HOLD. Authoritative original is Notion `3f2c2b324ede81f48f80f6d27449d107`, laboratory parent `3fbc2b324ede804a95fafcb7b293c92c`.

## New executable capabilities

- `r157_forensic_interlock.py`: classify R155 stale terminal marker after security refusal without proposing a write.
- `r158_rank_agnostic_spirit_transaction.py`: 9-step Ouro 1 cost/duration/damage/expiry/LONG rest/second activation with source-bound hash chain. The native TEST attempt was refused before first mechanical effect; **not** a native demonstration.
- `r159_source_boundary.py`: actor's actual deleted spirit mention versus different live beast tree; no title-based attribution.
- `r160_vz_sandbox_overlays.py`: source-pinned 8/8 VZ-SANDBOX attribute/TAP/carry math with no campaign certification.
- `r161_t9_duration_compat.py`: apply compatible-spirit +1 duration only when evidence is scoped correctly (synthetic TEST or specialist source with readback); never assume a text boolean.
- `r162_actor_spirit_switch_guard.py`: T11-safe swap of spirit ID **and new reserves**, keeping actor-scene lock and prior use history.
- `r163_rank_cross_spirit_preview.py`: read-only Bronze5→Prata1 natural rebase and spiritual eligibility, with PRE-Prata carry/backfill HOLD absent competent evidence.
- `r164_native_bridge_failclosed.py`: minimal Notion stage write-set, stale-version and ambiguity guards; security refusal locks retry and denies alternate API.
- `r165_notional_table_source_parser.py`: generic parser of the VZ Notion enhanced Markdown row format; regression with 8-row fixture and 8/8 direct live-source readback by connected tool.
- `r166_readback_package_gate.py`: validates the separately captured live readback summary without claiming independent review or Notion binary hashes.

## Reproduce

Use Python 3.11+; no external dependency required for the new subset:

```sh
python test_all.py
python tests/test_ibx17_r157_r165.py
```

`runtime/r149_150_spirit_runtime.py` is an **unchanged dependency** from the R147–R156 package, SHA-256 `3c92d8fb27a0832b1e438d74655ae6e5cf91a42d9d2f5d48b6fcfe741a47abe3`, not a regenerated rule.

## Physical source boundaries

- R155: `3fcc2b324ede8158a6d5c3bfa225e014`; normal and spirit journals COMMITTED, terminal INTENT_PREPARED; prior security refusal means **DO NOT RETRY** marker write through another interface.
- R158: `3fdc2b324ede8132b0ade1735402ba03`; newly created under existing lab, initial stage A `WRITE_DISPATCHED` but still physical BEFORE, NO activation, after security refusal. All remaining journals PREPARED. Its planned 9-stage sequence is **local only**.
- R145: target `3fcc2b324ede81868256e6db67ece28e`, version `2026-10-17T12:04:36.271Z`, human preview remains `AWAITING_CONFIRMATION`; this work does NOT supply consent.
- Nie Li actor `86bc2b324ede827699688140e82db00b` links legacy Spirit `60fc2b324ede836283f381eb62a37400` with 7 deleted children; other beast root `0f8c2b324ede824088f581e806c6a066` does not establish an identical source. No edits to either.
- VZ matrix `3f2c2b324ede816198a5f0fb525223ee` version `2026-10-07T21:37:03.824Z` includes 8 sandbox reconciled rows, with **0/8 full final HP/PA**, not production official assimilations.

## Governance

No actual Notion writer in Python; native writes (if ever admissible) must use the connected Notion interface and physical pre/post readback, with no CAS exclusivity claim. `SELF_REVIEW_ONLY`, production HOLD. This bundle cannot and must not grant writer, human confirmation, source-bound beast assimilation, or external audit status.
