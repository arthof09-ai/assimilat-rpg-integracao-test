from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parent
scripts=['r157_forensic_interlock.py','r158_rank_agnostic_spirit_transaction.py','r159_source_boundary.py','r160_vz_sandbox_overlays.py','r161_t9_duration_compat.py','r162_actor_spirit_switch_guard.py','r163_rank_cross_spirit_preview.py','r164_native_bridge_failclosed.py','r165_notional_table_source_parser.py','r166_readback_package_gate.py']
results={}
for script in scripts:
 p=subprocess.run([sys.executable,str(root/'runtime'/script)],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(f'{script} exit={p.returncode} {p.stderr}')
 results[script]=p.stdout.strip()
unit=subprocess.run([sys.executable,str(root/'tests'/'test_ibx17_r157_r165.py')],capture_output=True,text=True)
if unit.returncode:raise RuntimeError('unit tests failed '+unit.stderr)
print(json.dumps({'suite':'IBX17_R157_R165','runtime_checks':len(results),'unittest':14,'all_pass':True,'outputs':results},indent=2,ensure_ascii=False))
