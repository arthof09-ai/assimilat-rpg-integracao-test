LEVEL-UP / ORC / ALMA / DIFERENCIAL P23-043
24/10/2026 | MESTRE-SIDE | TEST | NAO E MOTOR DE PA | NAO HOMOLOGA ITENS

PRECEDENCIA: continuar a operacao existente LEVEL-UP/IBX-17/IBX-114.
BASE IMUTAVEL: pacote P23-042, biblioteca libfile_80a0d298d3f081918a960cd244ac5c0e, ZIP SHA256 1ba9eed04930cda36c76deabe4062cceb887869ef0215a6d0b0a1f96145b4f12.
INFORMAÇAO CANONICA: Criação de Ficha / Regra 5: PA = Alma; atual livre = PA bruto - manutencao. INT aumenta os ganhos NATURAIS por nivel e entra no rebase somente em transicoes de rank; nenhum equipamento da fixture demonstra transferencia de seu INT temporario para Alma natural em recalculo. Regras T9: Bronze nao transforma; P40 / O80 / ON160 / L320 PA/uso. Dois Aneis da Alma ja somados +100 no bruto; nao duplicar.

RISCO: P23-042 e uma configuracao TEST com buffer de 25% de Alma BRUTA apos custo T9 e tecnica escolhida; isso e PROPOSTO e nao equivale a limiar de morte ou imunidade a drenagem. Esta auditoria confirmou 20/20 atingem o buffer; 13/20 tinham saldo APENAS PARA T9 na base; 2/20 tinham T9+tecnica+buffer na base. Dreno sintético adicional de 100 pontos no saldo projetado apos ambos deixa 15/20 >0; de 200 deixa 6/20 >0. Nenhuma cena foi simulada no VLAB e nenhum limiar de morte e conhecido.

ALTERNATIVAS COMPARADAS:
1) Reduzir equipamento ENERGIZADO antes do compromisso diario: unica via hoje apoiada por itens EXISTENTES, valor diario identificavel e reversibilidade TEST; 25 propostas P23-042 ja calculadas. Exigir identidade, cena, manutencao e efeito real antes de escrever fichas.
2) Item novo +10 INT. Tarifa atributiva minima 50 PA/dia (10 x 5), mas o piso Lendario por item e 90, portanto taxa hipotetica L = 90. Nenhum ganho de Alma imediata foi autorizado por mera melhoria de testes de INT. Numeros "int10_contingent_rebase_only" no CSV sao uma conjectura matematica extrema (+10 x nivel ordinal no rebase, na qual item afeta progressao natural) deliberadamente NAO HOMOLOGADA; nao usar na ficha. Caso real teria de distinguir INT natural, permanente e temporaria, equipar/desequipar, rebase e dupla contagem.
3) Item hipotetico concedendo Alma direta de X pontos UNIVERSAIS (diferente de grimorio +130 apenas 'para lancar magias'): cenarios "min_new_direct_PA_to_achieve_25pct" calculam menor X sob piso de novo item e sem desligar equipamentos antigos. Para N06/N11/N16/N21: +107/+212/+362/+803 PA (respectivamente), sob custo piso 11/21/35/90. Esses X sao alvos matematicos de um item NAO EXISTENTE/NAO FABRICADO, e a legalidade/RI/RE/escala pode resultar em tarifa superior. Nao criar item canonico.
4) BASTA PA para T9 + tecnica NAO e sobrevivencia. Se adversario tem dreno D, buffer real deveria ser calibrado com D e margem sem confundir PA comprometido/PA total/PA livre; sem fonte nao inventar D nem limiar letal.

READBACK: arquivo input_r042_previews.csv e copia da matriz R042 sob rastreio. O script recompute_r043.py e um verificador ARITMETICO INDEPENDENTE do sistema RPG, contem assertions, imprime comparadores e grava CSV. Rodar `python recompute_r043.py`; comparar hashes e 25 linhas com result_r043_25_analytical.csv. Nao altera fichas, Notion, Party, O Primeiro, CRAFT, VLAB, GitHub nem sistema PA original.

NAC-PASS: somente QA ANALITICO. GATES materais RI/RE/FIP, efeito INT na progressao, catalogo/craft novo item, escritor/lease/epoch/fence e T9/VLAB/competencia anatomica permanecem HOLD.
