import csv, json, math, pathlib
from dataclasses import dataclass
ROOT=pathlib.Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'input_r042_previews.csv').open(encoding='utf-8-sig')))
assert len(rows)==25
floor={'Bronze':8,'Prata':11,'Ouro':21,'Ouro Negro':35,'Lendário':90}
result=[]
for row in rows:
    n=int(row['Nivel']); rank=row['Rank']; gross=int(row['PA bruto']); current=int(row['PA dia atual']); planned=int(row['PA dia TEST proposto']); t9=int(row['T9']) if row['T9'].isdigit() else 0; tech=int(row['PA habilidade']); buffer=math.ceil(.25*gross)
    before=gross-current-t9-tech if t9 else None
    after=gross-planned-t9-tech if t9 else gross-planned-tech
    assert after==int(row['PA depois T9+habilidade'])
    cost_int=max(50,floor[rank]); # full INT +10 at +5/unit, same power floor; hypothetical distinct new item
    # conservative NO intrinsic PA credit: +10 INT does not create a flat PA grant
    conservative=gross-(current+cost_int)-t9-tech if t9 else None
    # counterfactual only if separately certified at rank boundary, never actual/current
    rank_reset=gross + (10*n) -(current+cost_int)-t9-tech if t9 else None
    # standalone direct Alma artifact in an ADDITIONAL item (not retroactive); hypoth item at rank floor
    # math ceiling is exact integer; seek finite minimal X that meets 25% goal
    add_item_cost=floor[rank]
    direct_new_min=None
    if t9:
      for x in range(0,10000):
        if gross+x-current-add_item_cost-t9-tech>=math.ceil(.25*(gross+x)):
          direct_new_min=x;break
    # +100 drain stress after transformation+skill; if negative or zero vulnerable
    drain100=after-100;drain200=after-200
    record=dict(n=n,rank=rank,gross=gross,curr_cost=current,proposed_cost=planned,t9=t9,tech=tech,buffer25=buffer,
       remaining_current=before,remaining_p42=after,margin_over_buffer=after-buffer,int10_daily_cost=cost_int,
       int10_no_credible_PA_grant=conservative,int10_contingent_rebase_only=rank_reset,
       hypothetical_new_direct_PA_item_cost_floor=add_item_cost,min_new_direct_PA_to_achieve_25pct=direct_new_min,
       hypothetical_drain100_after_p42=drain100,hypothetical_drain200_after_p42=drain200)
    result.append(record)
# validate consistency
assert sum(r['remaining_current']>=r['buffer25'] for r in result if r['t9'])==2
assert all(r['remaining_p42']>=r['buffer25'] for r in result)
assert len([r for r in result if r['t9']])==20
assert sum(r['remaining_current']<0 for r in result if r['t9'])>=7
assert result[20]['remaining_p42']==251
assert result[5]['remaining_p42']==60
assert result[5]['min_new_direct_PA_to_achieve_25pct']==107
assert result[10]['min_new_direct_PA_to_achieve_25pct']==212
assert result[15]['min_new_direct_PA_to_achieve_25pct']==362
assert result[20]['min_new_direct_PA_to_achieve_25pct']==803
assert result[20]['int10_daily_cost']==90
# note drain metrics are NOT simulated combat; individual balances after normal PA spend only
out=ROOT/'recomputed_r043_25.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(result[0]));w.writeheader();w.writerows(result)
print(json.dumps({'rows':len(result),'pass_independent_checks':12,'costs':{str(k):{k2:v for k2,v in result[k-1].items() if k2 in ('rank','gross','remaining_current','remaining_p42','buffer25','int10_daily_cost','int10_no_credible_PA_grant','int10_contingent_rebase_only','min_new_direct_PA_to_achieve_25pct','hypothetical_drain100_after_p42','hypothetical_drain200_after_p42')} for k in (6,11,16,21,24,25)},'drain100_survivors_after_t9_tech_p42':sum(r['hypothetical_drain100_after_p42']>0 for r in result if r['t9']),'drain200_survivors_after_t9_tech_p42':sum(r['hypothetical_drain200_after_p42']>0 for r in result if r['t9']),'output':str(out)},ensure_ascii=False,indent=2))
