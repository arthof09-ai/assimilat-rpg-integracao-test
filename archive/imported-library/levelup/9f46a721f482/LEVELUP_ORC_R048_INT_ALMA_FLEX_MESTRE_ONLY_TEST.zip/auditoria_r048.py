#!/usr/bin/env python3
"""R048, pesquisa local MESTRE-ONLY. NÃO é motor oficial; lê snapshot R040 em R045."""
import csv, json, math, zipfile, hashlib, itertools, pathlib
ROOT=pathlib.Path(__file__).parent
PACKAGE=pathlib.Path('/mnt/data/levelup_R048_sources/LEVELUP_ORC_ALMA_R045_BALANCEAMENTO_SEGURO_TEST_20261024.zip')
with zipfile.ZipFile(PACKAGE) as z:
    SRC=json.loads(z.read('orc_pa_r040_evidence.json'))['matrix_25_levels_400_slots']
    P45=json.loads(z.read('r045_25_fichas_PLANO_NAO_APLICADO.json'))
# Diretriz do Mestre: 25% flexível, +1 item INT por CLASSIFICAÇÃO, balanço de poder/custo.
# SOMENTE o item Bronze +3/15 está documentado como item pronto existente.
# +6/+10/+16/+25 são projetos INFERIDOS/PROPOSTOS, NÃO classificação homologada.
INT_PROTOTYPES={
 'Bronze':{'int':3,'cost':15,'floor':8,'reference':'Amplificador de Atributo (+3/15), item existente, posse do Orc não comprovada'},
 'Prata':{'int':6,'cost':30,'floor':11,'reference':'Protótipo TEST especializado, magnitude não oficial'},
 'Ouro':{'int':10,'cost':50,'floor':21,'reference':'Protótipo TEST especializado, comparar Amuleto Inteligência +10, custo histórico 30 não migrável'},
 'Ouro Negro':{'int':16,'cost':80,'floor':35,'reference':'Protótipo TEST especializado, magnitude não oficial'},
 'Lendário':{'int':25,'cost':125,'floor':90,'reference':'Referência real Grimório L +25 INT, custo isolado projetado sem extras'},
}
SKILL={'Bronze':6,'Prata':12,'Ouro':24,'Ouro Negro':35,'Lendário':50}
T9={'Bronze':0,'Prata':40,'Ouro':80,'Ouro Negro':160,'Lendário':320}
RUPTURA={'Bronze':3,'Prata':7,'Ouro':14,'Ouro Negro':21,'Lendário':30}
# Não se supõe que efeitos S3,S4,S5 S9 são passivos: todos exigem ação/custo e janela próprios.
HEURISTIC_WEIGHTS={3:8,4:8,9:9,5:4,6:3,7:1,8:1,11:3,12:2,13:1}
RES=[]
for row,p45 in zip(SRC,P45):
    n=row['level'];rank=row['rank_personagem'];p=INT_PROTOTYPES[rank]
    gross=p45['gross_test'];tech=SKILL[rank];trans=T9[rank];rupt=RUPTURA[rank]
    assert n==p45['n'] and row['total_diario']==p45['before_daily']
    slots={x['slot']:x for x in row['slots']}
    old_on={j for j,v in slots.items() if v['on']}
    assert {1,2}.issubset(old_on) and len(slots)==16
    # S10 amuleto original de Alquimia sai apenas do loadout energizado proposto;
    # não remover ficha física. Protótipo INT é substituição/alternativa contingente.
    choices=sorted(old_on-{1,2,10})
    evaluated=[]
    for mask in range(1<<len(choices)):
        selected={1,2}|{s for k,s in enumerate(choices) if mask>>k&1}
        daily=sum(slots[s]['pa_dia_publicado'] for s in selected)+p['cost']
        rem=gross-daily-trans-tech-rupt
        if rem < 0:continue
        capability=sum(HEURISTIC_WEIGHTS.get(s,0) for s in selected)
        evaluated.append((rem,capability,daily,tuple(sorted(selected))))
    if not evaluated:raise RuntimeError(f'N{n} impossivel até com núcleo')
    # Candidato TÁTICO: preservar capacidades com reserva experimental 10%.
    soft_min=math.ceil(gross*.10)
    feasible=[x for x in evaluated if x[0]>=soft_min]
    if not feasible:feasible=evaluated
    tactical=max(feasible,key=lambda x:(x[1],x[0],-x[2]))
    # Candidato RESERVA: aproximar-se de 25%, mas nunca requisito universal.
    target=math.ceil(gross*.25)
    buffered=[x for x in evaluated if x[0]>=target]
    if buffered:
        soul=max(buffered,key=lambda x:(x[1],-abs(x[0]-target),x[0]))
        soul_target='25% disponível'
    else:
        soul=max(evaluated,key=lambda x:(x[0],x[1]))
        soul_target='25% não factível após Ruptura, alvo flexível'
    def entry(value):
        rem,cap,daily,sel=value
        return {'itens_ja_existentes_energizados':list(sel),'nome_itens_ja_existentes':[slots[i]['item'] for i in sel],
           'itens_ja_existentes_desenergizar':[i for i in sorted(old_on) if i not in sel],
           'pa_dia_itens_originais':daily-p['cost'],'pa_dia_item_int_condicional':p['cost'],
           'pa_dia_total_proposto':daily,'pa_livre_antes_de_ativacoes':gross-daily,
           'pa_apos_t9_tecnica_e_ruptura_em_eventos_validos':rem,'percentual_apos_eventos':round(100*rem/gross,1),
           'heuristica_poder_nao_VLAB':cap,
           'mantem_3_4_9':all(s in sel for s in (3,4,9)),
           'item_int_ja_adquirido':False,'teste_vlab_homologado':False}
    result={ 'n':n,'rank':rank,'page_id':p45['page_id'],'url':p45['url'],
       'PA_bruto_fisico':gross,'PA_dia_fisico':row['total_diario'], 'PA_livre_fisico':gross-row['total_diario'],
       't9':trans,'tecnica':tech,'ruptura_por_uso':rupt,'int_natural_nao_alterada':True,
       'novo_item_int':{'bonus_int':p['int'],'custo_pa_dia_TEST':p['cost'],'piso_pa_dia_rank':p['floor'],'situacao':p['reference'],
                        'efeito_alma_imediato_assumido':0,'origem_posse':'HOLD CRAFT/slot/carga/posse'},
       'perfil_tatico':entry(tactical),'perfil_reserva':entry(soul),'situacao_piso25':soul_target,
       'notion_aplicado':False,'selo':'R048-PROPOSTO-READONLY'}
    RES.append(result)
assert len(RES)==25 and len(set(x['page_id'] for x in RES))==25
(ROOT/'r048_orc_25_niveis_TEST_nao_aplicado.json').write_text(json.dumps(RES,ensure_ascii=False,indent=2),encoding='utf8')
with (ROOT/'r048_orc_25_niveis_TEST_nao_aplicado.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Nível','Classificação','PA bruto real','PA/dia real','Item INT + (TEST)','Custo INT/dia TEST','T9','Técnica','Ruptura','PA/dia tático TEST','PA pós eventos tático','% pós tático','Slots tático ON','PA/dia reserva TEST','PA pós eventos reserva','% pós reserva','Slots reserva ON','Possui item novo?','Notion foi alterado?'])
    for x in RES:
        a=x['perfil_tatico'];b=x['perfil_reserva'];z=x['novo_item_int']
        w.writerow([x['n'],x['rank'],x['PA_bruto_fisico'],x['PA_dia_fisico'],z['bonus_int'],z['custo_pa_dia_TEST'],x['t9'],x['tecnica'],x['ruptura_por_uso'],a['pa_dia_total_proposto'],a['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],a['percentual_apos_eventos'],','.join(map(str,a['itens_ja_existentes_energizados'])),b['pa_dia_total_proposto'],b['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],b['percentual_apos_eventos'],','.join(map(str,b['itens_ja_existentes_energizados'])),'NÃO','NÃO'])
print('25 niv TEST; físico read-only; Notion 0 atualizados')
for x in RES:
 a=x['perfil_tatico'];b=x['perfil_reserva']
 print('N%02d %-11s +INT%2d (%3d PA/dia) real%3d -> TAT%3d (%3d, %4.1f%%) slots%-20s RES%3d (%3d, %4.1f%%) slots%-20s'%(
 x['n'],x['rank'],x['novo_item_int']['bonus_int'],x['novo_item_int']['custo_pa_dia_TEST'],x['PA_dia_fisico'],a['pa_dia_total_proposto'],a['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],a['percentual_apos_eventos'],str(a['itens_ja_existentes_energizados']),b['pa_dia_total_proposto'],b['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],b['percentual_apos_eventos'],str(b['itens_ja_existentes_energizados'])))
