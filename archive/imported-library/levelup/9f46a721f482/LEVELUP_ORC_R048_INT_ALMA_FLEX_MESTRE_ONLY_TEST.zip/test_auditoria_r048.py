import unittest,math,json,zipfile,pathlib
ROOT=pathlib.Path(__file__).parent
R=json.loads((ROOT/'r048_orc_25_niveis_TEST_nao_aplicado.json').read_text(encoding='utf8'))
with zipfile.ZipFile('/mnt/data/levelup_R048_sources/LEVELUP_ORC_ALMA_R045_BALANCEAMENTO_SEGURO_TEST_20261024.zip') as z: 
  SRC=json.loads(z.read('orc_pa_r040_evidence.json'))['matrix_25_levels_400_slots']
class R048Audit(unittest.TestCase):
 def test_25_distinct_levels(self): self.assertEqual([x['n'] for x in R],list(range(1,26)))
 def test_25_distinct_page_ids(self):self.assertEqual(len({x['page_id'] for x in R}),25)
 def test_400_original_slots(self):self.assertEqual(sum(len(x['slots']) for x in SRC),400)
 def test_5_rank_types(self):self.assertEqual(len({x['rank'] for x in R}),5)
 def test_5_int_proposals(self): self.assertEqual({x['novo_item_int']['bonus_int'] for x in R},{3,6,10,16,25})
 def test_rank_costs(self):
  for x in R:self.assertGreaterEqual(x['novo_item_int']['custo_pa_dia_TEST'],x['novo_item_int']['piso_pa_dia_rank'])
 def test_5_pa_point_prospective(self):
  for x in R:self.assertEqual(5*x['novo_item_int']['bonus_int'],x['novo_item_int']['custo_pa_dia_TEST'])
 def test_no_retroactive_soul(self):
  for x in R:self.assertEqual(x['novo_item_int']['efeito_alma_imediato_assumido'],0)
 def test_original_gross_and_daily_preserved(self):
  for x,src in zip(R,SRC):
   self.assertEqual(x['PA_dia_fisico'],src['total_diario']);self.assertEqual(x['PA_livre_fisico'],x['PA_bruto_fisico']-x['PA_dia_fisico'])
 def test_bronze_no_t9(self): self.assertTrue(all(x['t9']==0 for x in R[:5]))
 def test_rank_t9(self):self.assertEqual([x['t9'] for x in R], [0]*5+[40]*5+[80]*5+[160]*5+[320]*5)
 def test_rank_tech_and_ruptura(self):
  self.assertEqual([x['tecnica'] for x in R],[6]*5+[12]*5+[24]*5+[35]*5+[50]*5)
  self.assertEqual([x['ruptura_por_uso'] for x in R],[3]*5+[7]*5+[14]*5+[21]*5+[30]*5)
 def test_core_and_original_slots(self):
  for x,src in zip(R,SRC):
   old={y['slot'] for y in src['slots'] if y['on']}
   for mode in ('perfil_tatico','perfil_reserva'):
    on=set(x[mode]['itens_ja_existentes_energizados'])
    self.assertTrue({1,2}.issubset(on));self.assertTrue(on.issubset(old));self.assertNotIn(10,on)
 def test_item_int_not_double_billed(self):
  for x,src in zip(R,SRC):
   costs={s['slot']:s['pa_dia_publicado'] for s in src['slots']}
   for mode in ('perfil_tatico','perfil_reserva'):
    m=x[mode]
    self.assertEqual(m['pa_dia_total_proposto'],m['pa_dia_itens_originais']+m['pa_dia_item_int_condicional'])
    self.assertEqual(m['pa_dia_itens_originais'],sum(costs[j] for j in m['itens_ja_existentes_energizados']))
 def test_calculated_after_cost(self):
  for x in R:
   for mode in ('perfil_tatico','perfil_reserva'):
    m=x[mode]
    self.assertEqual(m['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],x['PA_bruto_fisico']-m['pa_dia_total_proposto']-x['t9']-x['tecnica']-x['ruptura_por_uso'])
    self.assertGreaterEqual(m['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],0)
 def test_tactical_reserve10_percent_experimental(self):
  for x in R:self.assertGreaterEqual(x['perfil_tatico']['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],math.ceil(x['PA_bruto_fisico']*.1))
 def test_no_pretense_canon(self):
  self.assertTrue(all(not x['notion_aplicado'] and not x['perfil_tatico']['item_int_ja_adquirido'] and not x['perfil_reserva']['teste_vlab_homologado'] for x in R))
 def test_l21_values(self):
  x=R[20];self.assertEqual((x['perfil_tatico']['pa_dia_total_proposto'],x['perfil_tatico']['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos'],x['perfil_reserva']['pa_apos_t9_tecnica_e_ruptura_em_eventos_validos']),(395,96,186))
if __name__=='__main__':unittest.main()
