# LEVEL-UP — R048: INT escalonada por rank e Alma flexível do Orc

**CLASSIFICAÇÃO:** MESTRE-ONLY / TEST / AUDITORIA LOCAL READ-ONLY. **Data:** 24/10/2026.

## Decisão expressa do Mestre (substitui o requisito anterior)

- Reserva de Alma de 25% é **objetivo flexível**, não condição obrigatória.
- Tentar incorporar **no mínimo um item que conceda INT em cada uma das cinco classificações**, sem assumir posse ou fabricar cópias por conta própria.
- O poder total de um item é a soma de efeitos úteis; item de +15 DES multifuncional pode ser Lendário. Item especializado em INT pode chegar à referência Lendária de +25 INT. Não transferir custo histórico 90 PA da Zephyr a outros artefatos.
- Prioridade material: capacidade real de pagar T9 + técnica + continuar vivo, preservar Couraça/Machado e poder real de combate; comparar opções situacionais; sem fórmula inventada de Alma retroativa.

## Fontes canônicas relidas

- [Operação original IBX-17, checkpoint físico P23-045](https://app.notion.com/p/3f2c2b324ede81f48f80f6d27449d107) e [Inbox original IBX-114](https://app.notion.com/p/3ffc2b324ede81aab557fd267efc02ce).
- [25 Orcs da Ficha Base original TEST](https://app.notion.com/p/400c2b324ede8137a06bff45c3b5b1bb): 25/25 páginas reabertas nesta rodada, SEM atualização, valores ANTES preservados.
- [Atlas Canônico de Poder por Rank](https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab): rank do efeito ≠ rank nominal do item; outlier não define média; poder real antes de preço.
- [Amplificador de Atributo existente](https://app.notion.com/p/3c6c2b324ede82baa4a801de533a5975): +3 atributo, 15 PA/dia, Bronze conforme decisão do Mestre; posse para Orc não demonstrada.
- [Amuleto de Inteligência existente](https://app.notion.com/p/5dfc2b324ede83e3a98a814ae3ffd8f8): +10 INT e +20 dano mágico OU resistência mágica por 30 PA históricos; rank e transferibilidade ao Orc não confirmados — não reprecificar silenciosamente.
- [Grimório Lendário do Arcanista Proibido](https://app.notion.com/p/ed0c2b324ede8335b533810ceb462896): +25 INT e demais efeitos, não item do Orc; bônus de +130 PA limitado a magias, não é PA genérico.
- [Armadura de Zephyr L](https://app.notion.com/p/a23c2b324ede829bb8168165991577ff): +15 DES junto a defesa, acerto, deslocamento e dano, custo registrado 90 PA histórico não reprecificado.
- Pacotes da Biblioteca Mestre originais R044/R045 recuperados. R045 traz estrutura R040 25×16 e regressões.

## Cinco candidatos de item especializado em INT — NÃO PROD/NÃO POSSUÍDOS

| Classificação | Magnitude de INT proposta | PA/dia prospectivo (5×INT; piso respeitado) | Grau de evidência |
|---|---:|---:|---|
| Bronze | +3 | 15 | Valor do Amplificador existente, aplicar a INT só se disponível/legítimo |
| Prata | +6 | 30 | Projeto TEST, calibre de especialização a homologar |
| Ouro | +10 | 50 | Projeto TEST; há +10 INT em item histórico de múltiplos efeitos, não transplantar seu custo |
| Ouro Negro | +16 | 80 | Projeto TEST, calibre não homologado |
| Lendário | +25 | 125 | Magnitude sustentada por exemplo real do Grimório; preço separado TEST prospectivo |

**Efeito testado:** bônus contínuo no atributo efetivo enquanto o item estiver legitimamente equipado, sem efeito retroativo em Alma natural e sem incremento imediato assumido no PA bruto. O efeito na forma transformada depende de retenção/compatibilidade. Um item especializado não incorpora automaticamente habilidades híbridas. As famílias/protótipos são somente fichas de estudo, NÃO cinco fichas físicas canônicas, e não se presume upgrade do Amuleto da Forja já existente. Slot adicional/substituição física e CRAFT permanecem HOLD.

## Método da simulação independente (NÃO VLAB)

Usou 25 PA brutos ANTES comprovados no Notion, tarifas de equipamento existentes do snapshot R040 e apenas equipamento S01 Couraça + S02 Machado obrigatórios. O Amuleto da Forja atual (S10), especializado em Alquimia/Inscrições, fica desligado na proposta, mas **não é apagado/substituído fisicamente**. Todos os outros itens selecionáveis precisam estar previamente energizados na ficha (sem adquirir peças ausentes). O novo item INT é custo CONDICIONAL, porque nenhuma posse é demonstrada.

Para N01–05 (Bronze) **T9 vetada**; técnica normal 6 e um uso pago da Ruptura 3. Para Prata/Ouro/Ouro Negro/Lendário, descontam-se respectivamente T9 40/80/160/320, técnica ED 12/24/35/50 e Ruptura do Machado 7/14/21/30. Trata-se de orçamento de sequência de eventos **quando ações, cena e descanso permitirem**, nunca ativação simultânea ou uso ilimitado. Não contar reserva T6-B antes de T9; dois Anéis da Alma +100 já fazem parte do bruto.

- **Tático:** seleciona o máximo de utilidade situacional estimada que couber com reserva experimental de aproximadamente 10% do bruto; 10% também não é norma. Pesos heurísticos declarados no código, **não equivalem a dano/CA real**.
- **Reserva:** prefere ficar perto/acima de 25% quando possível, maximizando opções situacionais dentro desse orçamento. A meta não veta uma solução tática mais agressiva.
- Nenhum modo demonstra posse, fabricação, equipagem efetiva, compatibilidade corporal, manutenção já debitada, reações/ações disponíveis, CD, DPS ou combate VLAB.

## Resultado ANTES vs candidatos (PA/dia / PA depois dos eventos)

| Nível | Rank | INT/+custo proposto | PA/dia atual | Tático: manutenção / saldo | Reserva: manutenção / saldo |
|---|---|---|---:|---|---|
| 01 | Bronze | +3 / 15 | 64 | 79 / 34 (27.9%) | 79 / 34 (27.9%) |
| 02 | Bronze | +3 / 15 | 80 | 87 / 35 (26.7%) | 87 / 35 (26.7%) |
| 03 | Bronze | +3 / 15 | 88 | 95 / 38 (26.8%) | 95 / 38 (26.8%) |
| 04 | Bronze | +3 / 15 | 96 | 103 / 42 (27.3%) | 103 / 42 (27.3%) |
| 05 | Bronze | +3 / 15 | 112 | 117 / 42 (25.0%) | 117 / 42 (25.0%) |
| 06 | Prata | +6 / 30 | 179 | 134 / 23 (10.6%) | 103 / 54 (25.0%) |
| 07 | Prata | +6 / 30 | 179 | 145 / 30 (12.8%) | 114 / 61 (26.1%) |
| 08 | Prata | +6 / 30 | 179 | 167 / 27 (10.7%) | 125 / 69 (27.3%) |
| 09 | Prata | +6 / 30 | 179 | 178 / 36 (13.2%) | 145 / 69 (25.3%) |
| 10 | Prata | +6 / 30 | 179 | 189 / 47 (15.9%) | 156 / 80 (27.1%) |
| 11 | Ouro | +10 / 50 | 309 | 203 / 46 (12.5%) | 143 / 106 (28.9%) |
| 12 | Ouro | +10 / 50 | 309 | 224 / 48 (12.3%) | 173 / 99 (25.4%) |
| 13 | Ouro | +10 / 50 | 309 | 245 / 51 (12.3%) | 173 / 123 (29.7%) |
| 14 | Ouro | +10 / 50 | 309 | 266 / 55 (12.5%) | 203 / 118 (26.9%) |
| 15 | Ouro | +10 / 50 | 309 | 287 / 60 (12.9%) | 224 / 123 (26.5%) |
| 16 | Ouro Negro | +16 / 80 | 475 | 300 / 62 (10.7%) | 185 / 177 (30.6%) |
| 17 | Ouro Negro | +16 / 80 | 475 | 305 / 86 (14.2%) | 225 / 166 (27.3%) |
| 18 | Ouro Negro | +16 / 80 | 475 | 340 / 80 (12.6%) | 260 / 160 (25.2%) |
| 19 | Ouro Negro | +16 / 80 | 475 | 375 / 75 (11.3%) | 265 / 185 (27.8%) |
| 20 | Ouro Negro | +16 / 80 | 475 | 410 / 71 (10.2%) | 305 / 176 (25.3%) |
| 21 | Lendário | +25 / 125 | 810 | 395 / 96 (10.8%) | 305 / 186 (20.9%) |
| 22 | Lendário | +25 / 125 | 810 | 395 / 135 (14.5%) | 305 / 225 (24.2%) |
| 23 | Lendário | +25 / 125 | 810 | 395 / 174 (18.0%) | 305 / 264 (27.2%) |
| 24 | Lendário | +25 / 125 | 356 | 460 / 148 (14.7%) | 347 / 261 (25.9%) |
| 25 | Lendário | +25 / 125 | 356 | 460 / 188 (17.9%) | 379 / 269 (25.7%) |

**Totais reexecutados:** Tático = **25/25** saldos positivos, **5/25** alcançam 25%; preserva simultaneamente slots 3,4,9 em **21/25**. Reserva = **25/25** saldos positivos, **23/25** alcançam 25%; preserva 3,4,9 em **16/25**. Diminuição de variedade de acessórios não significa que seus buffs estavam permanentemente ativos: Manoplas/Cinto/Botas ainda exigem custos, ações e janelas de dois turnos. Todos os cálculos positivos pressupõem novo item INT válido/adquirido e troca antes da cobrança diária, **não reembolso em combate**.

### Canários propostos

- N06 Prata 1: físico 216 bruto, 179/dia, 37 livre; tático 134/dia, 23 após T9+técnica+Ruptura; reserva 103/dia e **54** restantes, com Couraça/Machado/Manoplas/Cinto/Braçadeiras. +6 INT TEST a 30/dia seria custo adicional no orçamento, não Alma bônus.
- N11 Ouro 1: físico 367/309/58; tático 203/dia, **46** após eventos; reserva 143/dia, **106**. Ataque/defesa situacionais não homologados.
- N16 ON 1: físico 578/475/103; tático 300/dia, **62**; reserva 185/dia, **177**.
- N21 Lendário 1: físico 891 bruto /810 por dia/81 livre; tático = **395/dia**, +25 INT TEST, S01/S02/S09 ON, **96 PA** pós T9(320)+Sentença(50)+Ruptura(30); reserva = **305/dia**, apenas S01/S02 ON e +25 INT, **186 PA**. Não considerar S09 passivo nem T6-B como recuperação do custo T9.

## Segurança e rastreabilidade

- **Validado localmente:** 18/18 testes R048 nesta rodada; 36/36 regressões originais R044/R045 reexecutadas, 0 falhas. Confere censo 25/400, dois anéis sem duplicação, pisos PA, orçamento sem +Alma inventada, Bronze não transforma, não adquire itens no resultado e Couraça/Machado presentes.
- **Verdade física Notion:** 25/25 relidas; seus números continuam ANTES, **0/25 alteradas**. Novos candidatos não têm posse, fabricação, writer, RI/RE validado, disponibilidade do slot, custo homologado ou regra de manutenção ativa; 0/20 cenários homologados VLAB.
- **Bloqueio de escrita:** não se comprovou CURRENT-WRITER-ID, WRITER-EPOCH, LEASE-TOKEN, BLOCK-PERMIT GREEN e fencing exclusivos do LEVEL-UP, nem TAKEOVER-COMMIT. A autorização geral do Mestre para trabalhar não cancela o gate de concorrência. A atualização material permanece fail-closed; nenhuma página Party/O Primeiro/CRAFT foi alterada.
- **HOLD histórico:** transição N23→N24 de componentes de ranks mistos sem proveniência física; conferir antes de usar N24/N25 como referência oficial.

**LAST-VERIFIED CANÔNICO:** IBX17-R216-P23-045. **R048:** artefato local documental/TEST, ainda não escrito no Diário/Inbox canônicos.
**FIRST-PENDING:** writer/lease/fencing GREEN no domínio original e prova CRAFT/acesso/posse de um item INT adequado por classificação; separar variant vs novo item físico; canário N06 com ANTES→DEPOIS→readback; confronto VLAB **existente** na mesma cena/inimigo das decisões Tático vs Reserva; escolher modo com perda ofensiva/defensiva quantificada; então escalar aos 25.
**NO-REPEAT:** não replicar 25 fichas/400 slots/novos motores, não publicar Party e não homologar por soma.
