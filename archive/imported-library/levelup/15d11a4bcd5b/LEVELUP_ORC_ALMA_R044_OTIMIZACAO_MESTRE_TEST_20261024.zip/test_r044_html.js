'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const s=fs.readFileSync(__dirname+'/LEVELUP_ORC_R044_ANDROID_OFFLINE_TEST.html','utf8');
const jsonMatch=s.match(/<script id="db"[^>]*>([\s\S]*?)<\/script>/);assert(jsonMatch);
const data=JSON.parse(jsonMatch[1]);assert.equal(data.presets.length,75);assert.equal(data.mixed.length,3);
const code=s.match(/<script>([\s\S]*?)<\/script>/)[1];
const el={db:{textContent:jsonMatch[1]},results:{innerHTML:''},mixed:{innerHTML:''}};
const buttons=['balanced','attack','guard'].map(style=>({dataset:{style},aria:'',setAttribute:(n,v)=>{assert.equal(n,'aria-pressed')},addEventListener(n,fn){this.click=fn}}));
const d={getElementById(id){assert(el[id],id);return el[id]},querySelectorAll(q){assert.equal(q,'button[data-style]');return buttons}};
vm.runInNewContext(code,{document:d,JSON,String});
assert.equal((el.results.innerHTML.match(/<article class="card">/g)||[]).length,25);
assert.equal((el.mixed.innerHTML.match(/<div class="card">/g)||[]).length,3);
for(const b of buttons){assert.equal(typeof b.click,'function');b.click();assert.equal((el.results.innerHTML.match(/<article class="card">/g)||[]).length,25);}
console.log('HTML read-only UI: 75 records, 3 modes, 25 cards per mode, mixed 3/3 PASS');
