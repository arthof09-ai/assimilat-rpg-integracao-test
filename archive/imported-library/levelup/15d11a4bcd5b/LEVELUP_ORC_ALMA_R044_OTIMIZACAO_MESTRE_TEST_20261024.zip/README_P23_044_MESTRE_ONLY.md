# P23-044 — Ajuste de Alma 25% do Orc | PREVIEW TEST / NÃO APLICADO

## Escolha do Mestre e limites
O Mestre aprovou a meta de **no mínimo 25% da Alma bruta ainda livre APÓS 1 Transformação Demoníaca elegível e 1 habilidade espiritual**; para Bronze a transformação é proibida e a meta segue após habilidade normal. Isto vale ao orçamento TEST do Orc, não é regra geral de personagem nem prova de segurança absoluta contra dreno. Fonte: Regra 5 da Criação de Ficha, T9/T9-A, Sistema Universal de PA, Diário LEVEL-UP P23-040 a P23-043.

## Operação existente, sem novo motor
Esta é uma otimização descritiva de **subconjuntos de 25×16 itens já existentes**, sem gerar artefatos mágicos, fórmulas novas de PA, personagens ou fichas. Para cada uma das 25 fichas, foram enumerados exaustivamente os subconjuntos das peças já energizadas, retendo em todos os casos o slot 1 Couraça da Muralha e slot 2 Machado da Ruptura. Foram testadas três prioridades não canônicas: balanceada, ofensiva, defensiva. Pontuações internas são meros critérios de escolha e **não** indicam bônus de dano/CA e não substituem o VLAB.

A economia de ações importa: Manoplas/Cinto/Botas ativam bônus temporário após Ação Padrão e duram só 2 turnos, portanto reter os três não prova usufruir todos durante T9 curta. Anel da Guarda concorre pela Reação com Couraça e Carapaça, reduzindo valor marginal. Braçadeiras oferecem precisão de golpe preparado limitado a 1/cena; não são acerto automático nem dano adicionado. O Amuleto melhora INT exclusivamente em teste preparado de Alquimia/Inscrições, não gera Alma e não melhora T9/CD. Dois Anéis da Alma +100 já entram nos saldos.

**GATE de não enfraquecer núcleo:** Couraça/Machado energizados em 25/25, preservando a referência nominal de CA física e ataque-base publicados, SEM certificar rank dos itens; efeitos condicionais desligados PODEM representar perda real de opções, portanto não afirmar que combate inteiro ficou estritamente mais forte. Comparação objetiva exige VLAB com estados e alvos.

## RESULTADOS VALIDÁVEIS
- 25 fichas × 3 estilos = 75 prévias; 20 níveis Prata–Lendário satisfazem orçamento T9 + 1 técnica + 25% ao menos; 5 Bronze sem T9 e com habilidade normal + 25%.
- Manutenção da prévia balanceada: N01–05 64/80/88/96/112; N06–10 104/115/137/148/159; N11–15 153/174/195/216/237; N16–20 225/260/260/295/295; N21–23 270; N24–25 356. CSV detalha slots individuais.
- Em 12/25 níveis, o critério heurístico balanceado ficou acima da seleção P23-042; nos demais não caiu. Isso NÃO equivale a prova de maior dano.
- Ouro1 e ON1 preservam Braçadeiras de precisão (+6/+8 para golpe preparado) em vez de Anel da Guarda reativo, concorrente da Couraça/Carapaça. Com a mesma manutenção P23-042, aumenta opções ofensivas e reduz redundância defensiva.
- L21–L23 (sem trocar item): opção ofensiva/balanceada Couraça+Machado+Braçadeiras L (270/dia, pós T9+Sentença 251/290/329); opção de guarda Couraça+Machado+Cinto L (270/dia, mesmos saldos). Ambas perdem usos secundários existentes se outros seis itens forem desenergizados.
- **Alternativa superior em variedade, MAS NÃO FÍSICA:** Couraça L90 + Machado L90 + Manoplas Ouro Negro40 (+8 FOR temp) + Cinto Ouro Negro40 (+8 CON temp) + Braçadeiras Ouro Negro35 (+8 precisão) = 295 PA/dia; saldo pós T9+Sentença N21=226 (buffer223), N22=265 (buffer233), N23=304 (buffer243). Com isso as bases CA física/ataque continuam L, duas opções de atributo e precisão são conservadas; magnitudes condicionais +8 substituem +10 e a posse das variantes não foi comprovada. MUST OBTAIN IDENTITY/CRAFT/LOADOUT before applying. Margem N21 só +3 acima dos 25%; contra dreno forte não é garantia de sobrevivência.
- N24/N25 mantêm 356/dia e todas 10 energizações existentes, mas o salto N23→N24 sem proveniência histórica permanece HOLD; não tratar a variante como item gratuito.

## Critério de implantação seguro
- Mestre aprovou somente meta de 25% para o Orc. NÃO transformar pesos de prioridade, escolha individual dos três estilos, mecanismo de reajuste de INT, mudança de rank do item, posse de variante, custo real ou dreno arbitrário em norma oficial.
- Para aplicar às fichas existentes, exige preflight de writer/lease/epoch/fence/BLOCK-PERMIT, rastro no Diário e readback real, edição restrita de cabeçalhos de estado e resumos PA, preservação das propriedades/RI-RE/FIP/canon anterior, revisão da versão da base e VLAB. Sem writer comprovado, **NENHUMA ficha foi modificada nesta rodada**. Neste pacote há CSV/JSON/HTML offline prontos para decisão; não há patch que escreva automaticamente.
- PA comprometido de dia já iniciado NÃO é reembolsado por desligamento instantâneo. Valores apenas de pré-compromisso diário.
- T9-A: nova ativação é 1/cena e descanso concluído; 25% depois de habilidade não prova capacidade contra um ataque real de dreno. T6-B da forma só existe depois de ativar T9 e não paga T9 retroativamente.

## CONTINUIDADE
LAST-VERIFIED: cálculos TEST R044 comparados R040/R042 e 25 páginas Notion reabertas (16×25); FIRST-PENDING: writer seguro + testes mecânicos VLAB das decisões de tática, procedência variantes ON nos lendários; NEXT: aplicar modo balanceado por padrão apenas com gate, modos alternativos por cenário definidos pelo Mestre; NO-REPEAT: não refazer 400 anotações de item e não criar motor/objeto/cópia de ficha.
