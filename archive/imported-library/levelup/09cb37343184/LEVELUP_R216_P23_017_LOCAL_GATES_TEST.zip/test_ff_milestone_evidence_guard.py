import unittest
from ff_milestone_evidence_guard import projected_thresholds, audit_without_receipts

class FFProjectionGuardTests(unittest.TestCase):
    def test_normal_16(self):
        x = audit_without_receipts(1610, 4110)
        self.assertEqual(x["normal_candidates"], 16)

    def test_transformed_potential_41(self):
        self.assertEqual(audit_without_receipts(1610, 4110)["transformed_potential_candidates"], 41)

    def test_global_not_16_plus_41(self):
        x = audit_without_receipts(1610, 4110)
        self.assertEqual(x["distinct_global_candidate_count"], 41)
        self.assertEqual(x["additional_if_transform_really_reaches_projection"], 25)

    def test_zero_earned_without_proofs(self):
        x = audit_without_receipts(1610, 4110)
        self.assertEqual(x["permanent_ff_bonuses_authorized"], 0)
        self.assertEqual(x["first_reach_receipts_certified"], 0)

    def test_zero_dice_rolled(self):
        self.assertEqual(audit_without_receipts(1610, 4110)["generated_rolls"], 0)

    def test_no_real_transform_claim(self):
        self.assertIs(audit_without_receipts(1610, 4110)["actual_transformations_observed"], False)

    def test_base_280_has_two_potential_marks(self):
        self.assertEqual(projected_thresholds(280), (100, 200))

    def test_base_1610_last_is_1600(self):
        self.assertEqual(projected_thresholds(1610)[-1], 1600)

    def test_trans_last_is_4100(self):
        self.assertEqual(projected_thresholds(4110)[-1], 4100)

    def test_zero_no_mark(self):
        self.assertEqual(projected_thresholds(0), ())

    def test_ff_float_refused(self):
        with self.assertRaises(ValueError): projected_thresholds(100.0)

    def test_ff_negative_refused(self):
        with self.assertRaises(ValueError): projected_thresholds(-300)

    def test_changed_normal_baseline_refused(self):
        with self.assertRaises(ValueError): audit_without_receipts(1700, 4110)

    def test_changed_trans_baseline_refused(self):
        with self.assertRaises(ValueError): audit_without_receipts(1610, 4200)

    def test_receipts_cannot_be_assumed_verified(self):
        with self.assertRaises(ValueError): audit_without_receipts(1610, 4110, receipts=[{"roll": 4}])

    def test_invalid_receipt_shape_refused(self):
        with self.assertRaises(ValueError): audit_without_receipts(1610, 4110, receipts={"100": 4})

    def test_empty_receipts_is_explicit_hold(self):
        self.assertEqual(audit_without_receipts(1610, 4110, [])["state"], "HOLD_FIRST_REACH_AND_ROLLS")

if __name__ == "__main__": unittest.main()
