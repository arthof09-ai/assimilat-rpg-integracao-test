"""Adversarial guard tests for already-published R216-P23 TEST equipment state."""
import copy
import unittest
from guard import load_snapshot, verify_snapshot

class ArsenalGuardTests(unittest.TestCase):
    def setUp(self):
        self.fixture = load_snapshot()

    def mutate(self, fn):
        x = copy.deepcopy(self.fixture)
        fn(x)
        with self.assertRaises(AssertionError):
            verify_snapshot(x)

    def test_known_baseline(self):
        self.assertEqual(verify_snapshot(self.fixture)["published_conditional_daily_pa"], 356)

    def test_total_16(self):
        self.assertEqual(len(self.fixture["items"]), 16)

    def test_energy_counts(self):
        self.assertEqual([sum(it["mode"] == m for it in self.fixture["items"]) for m in ("energized", "reserve")], [10, 6])

    def test_no_ri_fip_certification(self):
        self.assertEqual(sum(x["ri_fip_certified"] for x in self.fixture["items"]), 0)

    def test_daily_356_no_rings(self):
        self.assertEqual(sum(x["daily_pa"] for x in self.fixture["items"]), 356)
        self.assertEqual(self.fixture["rings_of_soul_daily_cost"], 0)

    def test_no_extra_active(self):
        self.mutate(lambda x: x["items"][10].update(mode="energized"))

    def test_no_dupe(self):
        self.mutate(lambda x: x["items"][7].update(slot=7))

    def test_missing_slot(self):
        self.mutate(lambda x: x["items"].pop())

    def test_extra_slot(self):
        self.mutate(lambda x: x["items"].append(copy.deepcopy(x["items"][0])))

    def test_energy_wrong_floor(self):
        self.mutate(lambda x: x["items"][0].update(daily_pa=35))

    def test_no_activation_billed_daily(self):
        self.mutate(lambda x: x["items"][1].update(daily_pa=120))

    def test_no_reserve_billing(self):
        self.mutate(lambda x: x["items"][12].update(daily_pa=21))

    def test_no_rank_change_silent(self):
        self.mutate(lambda x: x["items"][1].update(rank_declared_test="Ouro Negro"))

    def test_no_reordering(self):
        self.mutate(lambda x: x["items"].reverse())

    def test_no_power_label_change(self):
        self.mutate(lambda x: x["items"][0].update(name="Couraça Lendária Canônica"))

    def test_no_unknown_activation(self):
        self.mutate(lambda x: x["items"][13].update(activation_pa=30))

    def test_no_ri_promotion(self):
        self.mutate(lambda x: x["items"][0].update(ri_fip_certified=True))

    def test_no_fip_filled_by_default(self):
        self.mutate(lambda x: x["items"][0].update(fip="Média"))

    def test_no_global_pass_claim(self):
        self.mutate(lambda x: x.update(ri_fip_global_state="PASS_16_OF_16"))

    def test_no_source_change(self):
        self.mutate(lambda x: x["source"].update(notion_page_id="another-page"))

    def test_no_live_sync_claim(self):
        self.mutate(lambda x: x["source"].update(snapshot_manual=False))

    def test_no_source_version_change(self):
        self.mutate(lambda x: x["source"].update(source_page_last_edited_at="2030-01-01T00:00:00Z"))

    def test_no_rings_double_billing(self):
        self.mutate(lambda x: x.update(rings_of_soul_daily_cost=11))

    def test_no_rings_bonus_change(self):
        self.mutate(lambda x: x.update(rings_of_soul_pa_bonus_total=0))

    def test_no_bad_scope(self):
        self.mutate(lambda x: x.update(status="CANONICAL_PRODUCTION_PASS"))

    def test_no_wrong_energy_denominator(self):
        self.mutate(lambda x: x.update(published_active_count=11))

if __name__ == "__main__":
    unittest.main()
