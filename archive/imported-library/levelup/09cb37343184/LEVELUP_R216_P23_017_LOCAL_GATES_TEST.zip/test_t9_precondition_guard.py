import unittest
from dataclasses import replace
from t9_precondition_guard import T9Snapshot, assess_preconditions, FIVE_PUBLISHED_PA_BLOCKERS

BASE = T9Snapshot(actor_id="ORC_TEST_21", ordinal=21, rank="Lendário", pa_free_normal=500,
                  spirit_assimilated=True, scene_id="S2", used_scene_ids=frozenset({"S1"}),
                  prior_activation=True, rest_completed_after_prior_activation=True,
                  action_available=True)

class T9PreconditionTests(unittest.TestCase):
    def expect(self, value, state, reason):
        self.assertEqual(assess_preconditions(value), (state, reason))

    def test_all_five_known_pa_blockers(self):
        for n, r, pa, cost in FIVE_PUBLISHED_PA_BLOCKERS:
            self.assertLess(pa, cost)
            s = replace(BASE, ordinal=n, rank=r, pa_free_normal=pa)
            self.expect(s, "BLOCKED", "INSUFFICIENT_PA_AT_START")

    def test_bronze_cannot_t9(self):
        self.expect(replace(BASE, ordinal=5, rank="Bronze"), "BLOCKED", "BRONZE_NOT_ELIGIBLE")

    def test_invalid_rank_not_coerced(self):
        self.expect(replace(BASE, ordinal=16, rank="Lendário"), "HOLD", "INVALID_RANK_OR_ORDINAL")

    def test_no_spirit(self):
        self.expect(replace(BASE, spirit_assimilated=False), "BLOCKED", "NO_ASSIMILATED_SPIRIT")

    def test_unknown_spirit(self):
        self.expect(replace(BASE, spirit_assimilated=None), "HOLD", "SPIRIT_PROOF_MISSING")

    def test_zero_actor_identity(self):
        self.expect(replace(BASE, actor_id=""), "HOLD", "ACTOR_ID_UNKNOWN")

    def test_missing_pa(self):
        self.expect(replace(BASE, pa_free_normal=None), "HOLD", "PA_SOURCE_UNKNOWN")

    def test_negative_pa(self):
        self.expect(replace(BASE, pa_free_normal=-1), "HOLD", "PA_SOURCE_UNKNOWN")

    def test_exact_pa_is_not_sufficient_for_combat(self):
        v=replace(BASE, pa_free_normal=320)
        self.expect(v, "PRECONDITIONS_SATISFIED_TEST_ONLY", "NOT_ACTIVATION_OR_COMBAT_CERTIFICATION")

    def test_missing_scene(self):
        self.expect(replace(BASE, scene_id=None), "HOLD", "SCENE_LEDGER_UNKNOWN")

    def test_missing_history(self):
        self.expect(replace(BASE, used_scene_ids=None), "HOLD", "SCENE_LEDGER_UNKNOWN")

    def test_same_scene_denied_after_rest(self):
        self.expect(replace(BASE, scene_id="S1"), "BLOCKED", "ONCE_PER_SCENE")

    def test_next_scene_no_rest_denied(self):
        self.expect(replace(BASE, rest_completed_after_prior_activation=False), "BLOCKED", "REST_NOT_COMPLETED")

    def test_next_scene_unknown_rest_hold(self):
        self.expect(replace(BASE, rest_completed_after_prior_activation=None), "HOLD", "REST_PROOF_MISSING")

    def test_unknown_previous_use_hold(self):
        self.expect(replace(BASE, prior_activation=None), "HOLD", "PREVIOUS_USE_UNKNOWN")

    def test_action_missing(self):
        self.expect(replace(BASE, action_available=False), "BLOCKED", "REQUIRED_ACTION_MISSING")

    def test_action_unknown(self):
        self.expect(replace(BASE, action_available=None), "HOLD", "ACTION_PROOF_MISSING")

    def test_first_activation_can_be_precondition_satisfied(self):
        self.expect(replace(BASE, prior_activation=False, rest_completed_after_prior_activation=None,
                            used_scene_ids=frozenset()),
                    "PRECONDITIONS_SATISFIED_TEST_ONLY", "NOT_ACTIVATION_OR_COMBAT_CERTIFICATION")

    def test_multiple_scene_history_does_not_erase(self):
        self.expect(replace(BASE, scene_id="S1", used_scene_ids=frozenset({"S1", "X"})),
                    "BLOCKED", "ONCE_PER_SCENE")

    def test_pa_replenished_not_same_scene_reset(self):
        self.expect(replace(BASE, scene_id="S1", pa_free_normal=10000), "BLOCKED", "ONCE_PER_SCENE")

if __name__ == "__main__":
    unittest.main()
