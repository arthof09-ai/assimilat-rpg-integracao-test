"""Read-only T9-A precondition oracle for TEST snapshots, not an activation engine.

Only produces BLOCKED, HOLD, or PRECONDITIONS_SATISFIED (not action executed).
Does not allocate PA or spiritual reserves, check the real VLAB scene, or write state.
"""
from dataclasses import dataclass

T9_COSTS = {"Bronze": 20, "Prata": 40, "Ouro": 80, "Ouro Negro": 160, "Lendário": 320}
RANK_BANDS = {"Bronze": range(1, 6), "Prata": range(6, 11), "Ouro": range(11, 16),
              "Ouro Negro": range(16, 21), "Lendário": range(21, 26)}

@dataclass(frozen=True)
class T9Snapshot:
    actor_id: str
    ordinal: int
    rank: str
    pa_free_normal: int | None
    spirit_assimilated: bool | None
    scene_id: str | None
    used_scene_ids: frozenset[str] | None
    prior_activation: bool | None
    rest_completed_after_prior_activation: bool | None
    action_available: bool | None


def assess_preconditions(s: T9Snapshot) -> tuple[str, str]:
    """Fail closed on missing historical proof. No side-effects or state writes."""
    if not s.actor_id or not s.actor_id.strip():
        return "HOLD", "ACTOR_ID_UNKNOWN"
    if s.rank not in T9_COSTS or s.ordinal not in RANK_BANDS.get(s.rank, ()):
        return "HOLD", "INVALID_RANK_OR_ORDINAL"
    if s.ordinal <= 5:
        return "BLOCKED", "BRONZE_NOT_ELIGIBLE"
    if s.spirit_assimilated is False:
        return "BLOCKED", "NO_ASSIMILATED_SPIRIT"
    if s.spirit_assimilated is None:
        return "HOLD", "SPIRIT_PROOF_MISSING"
    if s.pa_free_normal is None or type(s.pa_free_normal) is not int or s.pa_free_normal < 0:
        return "HOLD", "PA_SOURCE_UNKNOWN"
    if s.pa_free_normal < T9_COSTS[s.rank]:
        return "BLOCKED", "INSUFFICIENT_PA_AT_START"
    if s.scene_id is None or s.used_scene_ids is None:
        return "HOLD", "SCENE_LEDGER_UNKNOWN"
    if s.scene_id in s.used_scene_ids:
        return "BLOCKED", "ONCE_PER_SCENE"
    if s.prior_activation is None:
        return "HOLD", "PREVIOUS_USE_UNKNOWN"
    if s.prior_activation and s.rest_completed_after_prior_activation is False:
        return "BLOCKED", "REST_NOT_COMPLETED"
    if s.prior_activation and s.rest_completed_after_prior_activation is None:
        return "HOLD", "REST_PROOF_MISSING"
    if s.action_available is False:
        return "BLOCKED", "REQUIRED_ACTION_MISSING"
    if s.action_available is None:
        return "HOLD", "ACTION_PROOF_MISSING"
    return "PRECONDITIONS_SATISFIED_TEST_ONLY", "NOT_ACTIVATION_OR_COMBAT_CERTIFICATION"


FIVE_PUBLISHED_PA_BLOCKERS = (
    (16, "Ouro Negro", 123, 160),
    (17, "Ouro Negro", 152, 160),
    (21, "Lendário", 81, 320),
    (22, "Lendário", 120, 320),
    (23, "Lendário", 159, 320),
)
