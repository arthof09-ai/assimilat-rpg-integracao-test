# LEVEL-UP — Inventário R216-P23: auditoria de regressão TEST

Pacote **MESTRE-SIDE / TEST, exclusivamente local**, sem contato com motor nativo, VLAB, Party ou O Primeiro. Reproduz um recorte manual da ficha N25 do Notion (última edição da página na captura: 2026-10-22T15:55:24.641Z) com 16 posições: dez energizadas, seis em reserva, 356 PA/dia **condicionais**. Não é sincronização ao vivo com Notion nem prova de rank físico dos itens.

Uso: `python -m unittest discover -s . -p 'test_guard.py' -v` ou `python -c 'from guard import *; print(verify_snapshot(load_snapshot()))'`.

**FAIL CLOSED:** qualquer mudança em custo publicado, modo, nome, rank TEST declarado, ordem de slots, ativação, Anéis da Alma, prova de RI/FIP, source ID/versão ou texto de escopo é motivo de falha até revisão explícita do novo snapshot e fonte. O código compara custo diário apenas com os **pisos do rank declarado**. Nada aqui demonstra que o rank declarado esteja correto; `HOLD_0_OF_16` permanece obrigatório.

O gasto por ativação de itens ativos (somatório aritmético de custos potenciais) **não é gasto diário**; não somar ao 356 PA/dia. Reserva desligada custa 0 PA/dia e não concede poderes. Dois Anéis da Alma: +100 PA bruto, 0 PA/dia, compatibilidade na transformação ainda HOLD.

### Dependências existentes e restrições

A operação original segue IBX-17/IBX-114, Diário P23-016; não criar motor paralelo. Itens precisam Atlas RI/RE/FIP com evidência E0–E3, CRAFT para origem física, contratos de ação/Reação/CD e validação VLAB. A ficha N25 pode mudar; um snapshot antigo que continua passando **não prova integridade do Notion futuro**. No primeiro uso após atualização, o executor deverá reler N25 e substituir dados/expectativas conscientemente, com novo checkpoint/hashes.

**GitHub:** houve tentativa de criar branch de validação, bloqueada pela segurança do conector; este pacote não foi publicado, não gerou PR nem executou CI remoto. Não contornar bloqueio. Sem certificado nativo P23.

### Segundo contrato — T9/T9-A

`t9_precondition_guard.py` e `test_t9_precondition_guard.py` são verificadores READ-ONLY dos pré-requisitos: Bronze não ativa, custo Prata 40/Ouro 80/ON 160/L 320, espírito assimilado, saldo PA, SCENE-ID, ACTOR-ID, utilização prévia, descanso completo após uso anterior e ação apropriada. **Não realizam transformação** nem alteram ACTOR/SCENE registry. Retornam `BLOCKED` ou `HOLD` quando falta requisito/prova; `PRECONDITIONS_SATISFIED_TEST_ONLY` não equivale a autorização de combate.

Inclui os cinco impedimentos publicados do Orc: N16 123/160, N17 152/160, N21 81/320, N22 120/320, N23 159/320. Configurações hipotéticas com equipamentos desligados requerem preparação/cobrança/efeitos validados; não basta simular PA livre maior para autorizar T9. Não há ressurreição de Vida ou PA normal por nova cena/descanso.

**Teste local:** 63/63 PASS (26 inventário + 20 T9 + 17 FF). Na primeira execução, o oráculo de inventário tinha um erro próprio (`184` em vez de `172` na soma das 10 ativações potenciais); foi corrigido antes da versão final e toda a bateria foi reexecutada. Os 172 não integram 356 PA/dia.

### Terceiro contrato — FF, alcance real versus projeção

`ff_milestone_evidence_guard.py` e `test_ff_milestone_evidence_guard.py` são um auditor READ-ONLY da projeção de FF N25: normal FF=1.610 (16 marcos candidatos de 100–1.600) e transformado teórico FF=4.110 (41 marcos candidatos de 100–4.100). O ledger é **global por ACTOR**, não 16+41=57 recibos: há até 25 marcos candidatos adicionais sobre os 16 existentes, **somente se a transformação efetivamente atingir esses valores**. Zero registros reais de primeiro alcance foram certificados nesta auditoria; logo zero escolhas, zero dados rolados e zero bônus permanentes liberados pelo pacote. Qualquer recibo não verificado localmente é rejeitado em vez de ser promovido. Isto NÃO simula evolução nem substitui o ledger nativo.

**Verificação adicional:** o código de validação usa exceções explícitas, não `assert` removível por Python `-O`; a suíte passa em ambas as configurações.
