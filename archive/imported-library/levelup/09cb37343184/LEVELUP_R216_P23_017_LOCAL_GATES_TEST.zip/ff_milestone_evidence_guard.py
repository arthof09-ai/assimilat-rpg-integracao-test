"""FF projection/evidence auditor: does NOT roll, grant or persist any FF reward.

Current Orc N25 FF numbers are theoretical from the published TEST ficha.
A potentially crossed threshold is not proof of a first-reach event.
"""

NORMAL_MAX_TEST = 1610
TRANSFORM_MAX_TEST = 4110


def projected_thresholds(ff: int) -> tuple[int, ...]:
    if type(ff) is not int or ff < 0:
        raise ValueError("FF_MUST_BE_NONNEGATIVE_INTEGER")
    return tuple(range(100, (ff // 100) * 100 + 1, 100))


def audit_without_receipts(normal_ff: int, transformed_ff: int, receipts: list | None = None) -> dict:
    """Check known projection only; evidence of attained FF must come from host ledger."""
    if (normal_ff, transformed_ff) != (NORMAL_MAX_TEST, TRANSFORM_MAX_TEST):
        raise ValueError("BASELINE_CHANGED_REQUIRE_CANONICAL_READBACK")
    if receipts is None:
        receipts = []
    if not isinstance(receipts, list):
        raise ValueError("RECEIPT_LIST_REQUIRED")
    if receipts:
        raise ValueError("LOCAL_PROOF_CANNOT_CERTIFY_FIRST_REACH_OR_DICE")
    normal = set(projected_thresholds(normal_ff))
    transform = set(projected_thresholds(transformed_ff))
    # The milestone ledger is global per ACTOR, never one normal + one transformed.
    return {
        "actor": "ORC_TEST_P23",
        "normal_candidates": len(normal),
        "transformed_potential_candidates": len(transform),
        "additional_if_transform_really_reaches_projection": len(transform - normal),
        "distinct_global_candidate_count": len(normal | transform),
        "first_reach_receipts_certified": 0,
        "permanent_ff_bonuses_authorized": 0,
        "state": "HOLD_FIRST_REACH_AND_ROLLS",
        "actual_transformations_observed": False,
        "generated_rolls": 0,
    }
