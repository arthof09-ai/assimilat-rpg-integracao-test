"""TEST-only validation oracle of a frozen Notion inventory excerpt.

This is NOT a level-up engine, RI/FIP classifier, PA billing engine,
real-time Notion synchronization or VLAB certification.
"""
from __future__ import annotations
import json
from pathlib import Path
FLOOR_BY_TEST_RANK = {'Bronze': 8, 'Prata': 11, 'Ouro': 21, 'Ouro Negro': 35, 'Lendário': 90}
EXPECTED = (('Couraça da Muralha', 'Lendário', 'energized', 90, 30), ('Machado da Ruptura', 'Lendário', 'energized', 90, 30), ('Manoplas da Bigorna', 'Ouro', 'energized', 21, 14), ('Cinto do Bastião', 'Ouro', 'energized', 21, 14), ('Botas da Escarpa', 'Prata', 'energized', 11, 7), ('Anel da Guarda', 'Ouro Negro', 'energized', 35, 21), ('Elmo do Estandarte', 'Prata', 'energized', 11, 7), ('Capa do Desfiladeiro', 'Ouro Negro', 'energized', 35, 21), ('Braçadeiras do Golpe Medido', 'Ouro', 'energized', 21, 14), ('Amuleto da Forja', 'Ouro', 'energized', 21, 14), ('Anel de Golpe', 'Ouro', 'reserve', 0, 14), ('Insígnia da Escolta', 'Prata', 'reserve', 0, 7), ('Arnês Antitombo', 'Ouro', 'reserve', 0, 14), ('Espada da Guarda', 'Lendário', 'reserve', 0, None), ('Escudo de Passagem', 'Ouro Negro', 'reserve', 0, None), ('Selo de Emergência', 'Ouro Negro', 'reserve', 0, None))

def load_snapshot(path: Path | None=None) -> dict:
    if path is None:
        path = Path(__file__).with_name('arsenal_snapshot.json')
    return json.loads(path.read_text(encoding='utf-8'))

def verify_snapshot(document: dict) -> dict:
    """Fail closed if known P23 TEST values changed without a new baseline."""
    if not document['schema'] == 'LEVELUP_R216_P23_ARSENAL_GUARD_V1':
        raise AssertionError('SCHEMA_CHANGED')
    if not document['status'] == 'TEST_ONLY__NOT_CANONICAL_CERTIFICATION':
        raise AssertionError('STATUS_PROMOTED')
    source = document['source']
    if not source['operation'] == 'LEVEL-UP-ENGINE/IBX-17':
        raise AssertionError('OPERATION_CHANGED')
    if not source['notion_page_id'] == '400c2b324ede815abca2ce4fb08a8cdc':
        raise AssertionError('SOURCE_CHANGED')
    if not source['snapshot_manual'] is True:
        raise AssertionError('MUST_DISCLOSE_FROZEN_SNAPSHOT')
    if not source['source_page_last_edited_at'] == '2026-10-22T15:55:24.641Z':
        raise AssertionError('SOURCE_VERSION_CHANGED')
    if not document['ri_fip_global_state'] == 'HOLD_0_OF_16':
        raise AssertionError('UNAUTHORIZED_RI_PROMOTION')
    if not document['rings_of_soul_count'] == 2:
        raise AssertionError('RINGS_CHANGED')
    if not document['rings_of_soul_pa_bonus_total'] == 100:
        raise AssertionError('RINGS_BONUS_CHANGED')
    if not document['rings_of_soul_daily_cost'] == 0:
        raise AssertionError('RINGS_DOUBLE_BILLED')
    if not document['published_active_count'] == 10:
        raise AssertionError('ACTIVE_DENOMINATOR_CHANGED')
    if not document['published_reserve_count'] == 6:
        raise AssertionError('RESERVE_DENOMINATOR_CHANGED')
    if not document['daily_pa_published_conditional'] == 356:
        raise AssertionError('PA_BASELINE_CHANGED')
    items = document['items']
    if not len(items) == 16:
        raise AssertionError('NOT_16_ITEMS')
    if not [i['slot'] for i in items] == list(range(1, 17)):
        raise AssertionError('ITEM_ORDER_OR_DUPLICATE')
    active = reserve = total_daily = 0
    for item, expected in zip(items, EXPECTED):
        name, rank, mode, daily, activation = expected
        if not (item['name'], item['rank_declared_test'], item['mode'], item['daily_pa'], item['activation_pa']) == expected:
            raise AssertionError('SNAPSHOT_DRIFT')
        if not (item['ri_fip_certified'] is False and item['fip'] is None):
            raise AssertionError('HOMOLOGATION_FABRICATED')
        if not (isinstance(item['daily_pa'], int) and item['daily_pa'] >= 0):
            raise AssertionError('DAILY_TYPE')
        if not item['rank_declared_test'] in FLOOR_BY_TEST_RANK:
            raise AssertionError('UNKNOWN_RANK')
        if item['mode'] == 'energized':
            active += 1
            if not daily == FLOOR_BY_TEST_RANK[rank]:
                raise AssertionError('BASELINE_FLOOR_MISMATCH')
            if not item['daily_pa'] == FLOOR_BY_TEST_RANK[rank]:
                raise AssertionError('DAILY_FLOOR_MISMATCH')
        else:
            reserve += 1
            if not item['daily_pa'] == 0:
                raise AssertionError('RESERVE_BILLED')
        total_daily += daily
    if not (active, reserve) == (10, 6):
        raise AssertionError('WRONG_ENERGY_COUNT')
    if not total_daily == 356:
        raise AssertionError('WRONG_DAILY_SUM')
    activation_total = sum((it['activation_pa'] or 0 for it in items if it['mode'] == 'energized'))
    if not activation_total == 172:
        raise AssertionError('ACTIVATIONS_CHANGED')
    return {'state': 'LOCAL_TEST_PASS', 'count': len(items), 'active': active, 'reserve': reserve, 'published_conditional_daily_pa': total_daily, 'possible_active_activation_pa_not_charged_daily': activation_total, 'ri_fip_homologated': 0, 'notion_live_checked': False, 'native_engine_checked': False, 'vlab_checked': False}
