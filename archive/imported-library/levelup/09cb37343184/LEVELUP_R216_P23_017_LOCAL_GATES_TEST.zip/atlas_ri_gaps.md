# Matriz de evidência — 16 perfis do Orc N25 (TEST)

**Fontes:** índice das 25 fichas Orc R216-P14, N25 `400c2b324ede815abca2ce4fb08a8cdc`; Atlas `3eec2b324ede81ea8920c52473ecc3ab`; DMG-RANK `3f2c2b324ede815498cddb7844245f7e`; Diário LEVEL-UP P23-013–016. **Não é homologação.** Cada RI declarado abaixo continua E3/pendente para promoção, porque não há objeto produzido nem prova física de origem; quando há comparadores, tratam-se de indícios de RE e não certificado de RI.

| Slot | Perfil; RI DECLARADO TEST | Eixo dominante a testar | Evidência disponível | Lacuna mínima a fechar |
|---:|---|---|---|---|
| 01 | Couraça da Muralha; Lendário | Defesa: +30 CA física, +8 CA mágica condicional | Comparadores Guarda Elemental ON +12 CA, Pesada ON +13 CA, Zephyr L +11 CA + múltiplos efeitos (Diário P23-014) | Materiais, manufatura, permanência da CA, ação/reação e empilhamento, FIP calibrada por defesa efetiva |
| 02 | Machado da Ruptura; Lendário | Ofensiva: 12d6 básico (42); +16d6 (56), 30 PA/uso, 1/descanso | Arco Exterminador L 8d8+25 (61), rider especializado (62); decomposição P23-015–016 | Item real, RE separado do RI, recarga e regra de empilhar buffs, equivalência com arma brutal |
| 03 | Manoplas da Bigorna; Ouro | +4 FOR por 2 turnos, 14 PA/uso | Piso declarado 21 PA/dia; atributo 4×5 =20 é componente candidato, não cobrança adicional | Ação de ativação, origem do atributo, teto/primeiro alcance FF, FIP e comparadores de buff equivalente |
| 04 | Cinto do Bastião; Ouro | +4 CON por 2 turnos, 14 PA/uso | Igual classe econômica declarada de slot03 | Ação, alteração do máximo de Vida sem cura, guarda de FF, período exato, FIP |
| 05 | Botas da Escarpa; Prata | +2 DES por 2 turnos, 7 PA/uso | Piso declarado 11 PA/dia, 10 PA atributo candidato | Ação, duração, efeito em CA/FF, deslocamento ainda reduzido pela Couraça, FIP |
| 06 | Anel da Guarda; Ouro Negro | +6 CA contra ataque declarado, 21 PA/uso | Comparável à defesa ativa da Couraça (mas ambos TEST, não prova independente) | Reação única, acumulação vedada sem contrato, faixa timing, slots frente aos 2 Anéis da Alma, FIP |
| 07 | Elmo do Estandarte; Prata | +4 Vontade contra medo, 7 PA/uso | Gatilho narrativo de escolta | Preparo e reconhecimento da escolta, salvaguarda de medo, duração, alcance e FIP |
| 08 | Capa do Desfiladeiro; Ouro Negro | +10 Furtividade em rocha/penumbra, 21 PA/uso | Bloqueia texto antigo de redução automática de dano 75 | Condições precisas, duração, acumulação com títulos e testes por rank, FIP |
| 09 | Braçadeiras do Golpe Medido; Ouro | +8 teste de ataque, 14 PA/uso, 1/cena | Separa teste para acertar de dano | Duração de preparação, Ação, limite/cooldown, alvo, FIP e comparadores externos |
| 10 | Amuleto da Forja; Ouro | +4 INT situacional em Alquimia/Inscrições, 14 PA/uso | Não concede treino ou PA por si | Ação, escopo de proficiência, temporário vs atributo geral, FIP e materiais |
| 11 | Anel de Golpe; Ouro, reserva | +8 acerto candidato, 14 PA/uso | Desligado, 0 PA/dia | Slots anatômicos disponíveis, troca por Anel da Guarda, custo após energização, FIP |
| 12 | Insígnia da Escolta; Prata, reserva | +4 Vontade de aliado adjacente contra medo, 7 PA/uso | Desligada, 0 PA/dia | Alcance/ação/alvo, duração e limite; comparador de suporte/condições |
| 13 | Arnês Antitombo; Ouro, reserva | −1,5 m de empurrão de uma ocorrência, 14 PA/uso | Desligado, 0 PA/dia | Gatilho, Reação vs passive/Movimento, ação de empurrão VLAB e compatibilidade |
| 14 | Espada da Guarda; Lendário, reserva | 6d8 físico projetado (média 27) | Faixa DME Ouro Entrada/Prata Alta, aquém da faixa L para golpe comum; P23-013 proposta adicional não homologada | Origem do dano acima do chassi uma mão, encantamento, RI/RE, preparo e troca de arma, FIP |
| 15 | Escudo de Passagem; Ouro Negro, reserva | CA física ainda indefinida | Escudo Materno e Escudo de Proteção contra Magia catalogados, mas não homólogos; P23-013 proposta não implantada | CA básica, reação, material, potência de proteção, incompatibilidade com machado duas mãos, FIP |
| 16 | Selo de Emergência; Ouro Negro, reserva | Consumível defensivo sem efeito físico validado | Selo do Último Refúgio L catalogado com 55 PA, Reação, mitigação até 60 em 3 alvos; P23-013 proposta menor | Produção/transferência mágica CRAFT, objeto disponível, efeito e consumo, RE/RIn/RI separados, FIP |

## Próximos gates decisórios — sem impor rank

1. **Proveniência e efeito isolado:** objeto físico/receita/carga REAL, distinguir RE de RI; dados verbais ou bancada hipotética não são evidência E0.
2. **Três comparadores do Atlas:** sistêmico + personagem/Besta + da mesma família; razões numéricas de CA/DME sozinhas podem informar E2 de um eixo, mas não fecham RI/FIP.
3. **Economia independente:** depois de RI/FIP, refazer PA/dia item a item; não aplicar piso do rank do portador nem somar automaticamente PA de ativação à manutenção.
4. **Cena de combate:** validar ação, uma reação disponível, distância, limite/recarga, anatomia e capacidade real de pagar T9. Sem isso, não chamar combat-ready.
5. **Rastreio:** antes/depois por slot, atualização em Diário + IBX-114 e NAC-PASS proporcional; atualização local não altera a Party/VLAB.

**Denominador preservado:** 16 slots. 10 energizados = 356 PA/dia TEST; 6 reserva = 0 PA/dia. **16/16 RI/FIP ainda HOLD.**
