#!/usr/bin/env python3
"""DMG C36: source-literal conditional PMFs, hypothetical RD, crit max-dice shift.
MESTRE-ONLY, TEST, no writes to Notion or character state.
"""
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import hashlib,csv,json,math,zipfile
ROOT=Path(__file__).resolve().parent
CASES=[
 ('Ravin','Atk','primeira',[(2,6)],37,'14bc2b324ede834daba501e769feda9d'),
 ('Ravin','Atk','parentetica',[(7,6)],20,'14bc2b324ede834daba501e769feda9d'),
 ('Do Ze O2/O5','Bola','d8 alternativa',[(9,8)],0,'1c7c2b324ede83648b6e0104f9bd2146'),
 ('Do Ze O2/O5','Bola','d6 alternativa',[(9,6)],0,'1c7c2b324ede83648b6e0104f9bd2146'),
 ('Do Ze B4','Bola','linha B4',[(3,6)],0,'1c7c2b324ede83648b6e0104f9bd2146'),
 ('Treimor normal','Ataque','principal',[(4,6)],65,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor normal','Ataque','parentetica',[(5,10),(4,8),(3,10)],80,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor normal','Pressao','principal',[(4,6)],80,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor normal','Pressao','parentetica',[(5,10),(4,8),(3,10),(4,12)],105,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor transformado','Ataque','principal',[(4,6)],105,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor transformado','Ataque','parentetica',[(5,10),(4,8)],132,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor transformado','Pressao','principal',[(4,6)],130,'8f6c2b324ede82c88e5d8184dc3a3b90'),
 ('Treimor transformado','Pressao','parentetica',[(5,10),(4,8),(3,10),(4,12)],157,'8f6c2b324ede82c88e5d8184d8986e9c3a3b90')
]
# Guard against typo in copied source identifiers, retain one canonical notion page for Treimor.
CASES[-1]=(*CASES[-1][:5],'8f6c2b324ede82c88e5d8184dc3a3b90')
RDS=[0,20,40,45,48,50,60,80,100,120,150,180,200,250,300]
assert len(CASES)==13
CHECKS=0

def pmf(dice):
    global CHECKS
    p={0:1};denom=1
    for n,s in dice:
        assert 1<=n<=9 and 2<=s<=12
        for _ in range(n):
            new=defaultdict(int)
            for k,v in p.items():
                for face in range(1,s+1):new[k+face]+=v
            p=dict(new);denom*=s
    assert sum(p.values())==denom;CHECKS+=1
    assert min(p)==sum(n for n,s in dice);CHECKS+=1
    assert max(p)==sum(n*s for n,s in dice);CHECKS+=1
    return p,denom

rows=[];summary=[];source_index={}
for entity,ability,variant,dice,bonus,page in CASES:
    counts,den=pmf(dice)
    dice_max=sum(n*s for n,s in dice)
    theoretical_mean=Fraction(bonus)+sum((Fraction(n*(s+1),2) for n,s in dice),Fraction())
    computed_mean=sum(Fraction((d+bonus)*c,den) for d,c in counts.items())
    assert computed_mean==theoretical_mean;CHECKS+=1
    var=sum(Fraction(c,den)*(d+bonus-theoretical_mean)**2 for d,c in counts.items())
    theoretical_var=sum((Fraction(n*(s*s-1),12) for n,s in dice),Fraction())
    assert var==theoretical_var;CHECKS+=1
    per_crit={}
    for mode,shift in [('normal',0),('critico_cenario_regra_dados_maximos',dice_max)]:
        vals=[]
        for rd in RDS:
            e=sum(Fraction(c*max(0,d+bonus+shift-rd),den) for d,c in counts.items())
            chance=sum(c for d,c in counts.items() if d+bonus+shift>rd)
            chance=Fraction(chance,den)
            assert e>=0 and 0<=chance<=1;CHECKS+=1
            assert e<=computed_mean+shift;CHECKS+=1
            vals.append(e)
            rows.append([entity,ability,variant,'+'.join(f'{n}d{s}' for n,s in dice),bonus,mode,dice_max,rd,
                         float(computed_mean+shift),float(e),str(e),float(chance),str(chance),
                         f'https://app.notion.com/p/{page}',
                         'hipotese_RD_plana_so_apos_dano; nao_modela_tipo_CA_acerto_RD_elemental_save'])
        assert all(a>=b for a,b in zip(vals,vals[1:]));CHECKS+=1
        per_crit[mode]=vals
    assert per_crit['critico_cenario_regra_dados_maximos'][0]-per_crit['normal'][0]==dice_max;CHECKS+=1
    summary.append(dict(entity=entity,ability=ability,variant=variant,source_page=page,
       dice='+'.join(f'{n}d{s}' for n,s in dice),bonus=bonus,dice_max=dice_max,
       raw_expected=str(computed_mean),raw_variance=str(var),
       rd48_expected_normal=str(per_crit['normal'][RDS.index(48)]),
       rd48_expected_crit=str(per_crit['critico_cenario_regra_dados_maximos'][RDS.index(48)])))
    source_index[(entity,variant)]=(counts,den,bonus,dice_max)
# Exact Ravin contrast: first alternative caps at 49, second caps at 62; high RD non-equivalence.
a,b=source_index['Ravin','primeira'],source_index['Ravin','parentetica']
def post(x,rd,shift=0):
  c,den,bonus,maxd=x
  return sum((Fraction(n*max(0,d+bonus+shift-rd),den) for d,n in c.items()),Fraction())
assert post(a,50)==0 and post(b,50)>0;CHECKS+=1
assert post(a,0)==44 and post(b,0)==Fraction(89,2);CHECKS+=1
assert post(a,48)==Fraction(1,36) and post(b,48)>post(a,48);CHECKS+=1
assert a[3]==12 and b[3]==42;CHECKS+=1
assert post(a,0,a[3])==56 and post(b,0,b[3])==Fraction(173,2);CHECKS+=1
file_csv=ROOT/'C36_390_PMFS_RD_CRIT_CONDICIONAIS.csv'
with file_csv.open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['entidade','habilidade','alternativa_na_ficha','dados','bonus','modo','max_dados','RD_hipotetica','media_bruta_ou_crit','E_pos_RD_decimal','E_pos_RD_exato','P_dano_pos_RD_decimal','P_dano_pos_RD_exato','fonte_notion','limites']);w.writerows(rows)
assert len(rows)==13*15*2
summary_path=ROOT/'C36_SUMARIO_PMF.json'
summary_path.write_text(json.dumps({'as_of':'2026-10-22','operation':'OP-DMG-CORPUS-EMP-01','environment':'MESTRE-ONLY TEST',
  'entries':summary,'rd_grid':RDS,'expression_count':len(CASES),'scenario_count':len(rows),
  'assertions':CHECKS,'ravin_rd48':{'primeira_normal':str(post(a,48)),
                       'parentetica_normal':str(post(b,48)),'rd50_primeira':str(post(a,50)),
                       'rd50_parentetica':str(post(b,50))},
  'status':'MATH_ONLY; hypothetical flat RD; no type, element, saving throw, hit, extra damage or official migration',
  'baseline':'DMG-RANK-01 v1.1 UNCHANGED', 'F0':'4/8 DOCUMENTAL HOLD'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('cases',len(CASES),'scenarios',len(rows),'checks',CHECKS)
print('Ravin RD48',post(a,48),post(b,48),'RD50',post(a,50),post(b,50),'crit max',a[3],b[3])
for v in summary:
 if v['entity']=='Ravin':print(v)
