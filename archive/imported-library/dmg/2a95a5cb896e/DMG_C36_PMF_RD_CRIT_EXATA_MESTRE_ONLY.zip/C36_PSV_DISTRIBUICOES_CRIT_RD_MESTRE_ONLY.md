# PSV DMG C36 — distribuição exata, RD e crítico em fontes não adjudicadas

**OP existente**: OP-DMG-CORPUS-EMP-01. **Ambiente**: MESTRE-SIDE / TEST. **Autoridade**: sucessão científica autorizada; writer, lease, epoch/identidade material do Notion não demonstrados. **Baseline**: DMG-RANK-01 v1.1 e Sistema de Combate permanecem inalterados. Nenhuma escrita em Notion, Party, O Primeiro, fichas, VLAB ou regras.

## Antes → depois

C35 preservou conflitos de Do Ze e Lan Treimor, comparando médias/variâncias de oito expressões e 150 cenários condicionais. C36 retoma os **mesmos dados** para avaliar matematicamente a distribuição completa, sem decidir versões. Li diretamente no Notion Mestre os originais Ravin, Do Ze, Lan Treimor e Sistema de Combate. O Sistema de Combate descreve o crítico como dano normal com o máximo dos dados normais acrescido; isso permite um cenário *condicional* de crítico. A mitigação aplicada nesta auditoria é **RD plana hipotética**, somente onde o modelo `max(0, dano - RD)` é pertinente; não substitui defesa por tipo/elemento, chance de acerto, salvaguarda, crítico especial, imune ou regras de fonte.

- **13 expressões independentes de análise**, correspondendo a **3 páginas-fonte físicas**, NÃO 13 novos casos do inventário e NÃO versões simultaneamente somáveis. C36 não altera o D0 delimitado da C34 (848 IDs).
- **15 níveis hipotéticos de RD** e **2 modalidades condicionais** (golpe normal e crítico com máximo dos dados adicionado). Total: **390 cenários** calculados com distribuição discreta integral por convolução, frações exatas e probabilidade de superar RD. Script portátil reexecutável.
- **889 verificações locais PASS** no gerador: soma e suporte de PMF, igualdade com média/variância analíticas, monotonicidade em RD, limites de valor esperado, consistência do bônus crítico e comparações Ravin. Além disso, ZIP tem manifesto de hashes e CRC. Nenhum ensaio de VLAB foi rodado.

## Resultado 1 — Ravin: equivalência de média NÃO implica equivalência contra RD

Na mesma ficha, `Atk: 2d6+37 (7d6+20)` é ambíguo quanto ao significado dos parênteses. Tratar as duas expressões como alternativas *hipotéticas* separadas, não como componentes somados.

| Expressão | Média sem RD | Variância | Dano esperado pós-RD 48, acerto normal | Dano esperado pós-RD 50, acerto normal | Bônus aditivo no cenário de crítico |
|---|---:|---:|---:|---:|---:|
| `2d6+37` | 44 | 35/6 | 1/36 ≈ 0,0278 | 0 | +12 |
| `7d6+20` | 44,5 | 245/12 | 8813/15552 ≈ 0,5667 | 7397/31104 ≈ 0,2378 | +42 |

Mesmo com médias brutas apenas 0,5 apartadas, sob hipótese RD=50 a primeira expressão não pode causar dano e a segunda pode. Condicional a um crítico com máximo dos dados, as médias sem RD passam a **56** e **86,5**. A fórmula correta depende de autoridade de fonte; a diferença é evidência de sensibilidade, não de que uma das versões esteja errada.

## Resultado 2 — Do Ze e Lan Treimor

As alternativas `9d8+INT` e `9d6+INT` foram tratadas como dois ramos mutuamente alternativos; o valor de INT, quantidade de ticks e salvaguarda continuam pendentes. Neste cálculo de PMF apenas o componente dos dados do golpe foi isolado com **INT hipotética zero** e sem DoT, para não inventar duração. A C35 conserva as fórmulas simbólicas de salvaguarda e DoT para serem combinadas após decisão competente. O Do Ze B4 usa seu próprio `3d6+INT`, sem equiparar a outras versões.

Para Lan Treimor, os quatro grupos normal/transformação, principal/parentético foram calculados isoladamente para `Ataque` e `Pressao`, preservando a variância distinta dos pools. Transformação não autoriza somar expressão principal e parentética nem criar outro golpe. Os resultados de cada estado e RD estão no CSV com URL da fonte.

## Aplicação responsável, revisão e gate

- O uso de uma média de dano por rank sem condicionar **dados, bônus fixo, crítico e mitigação** pode ser enganoso. Este parecer não estima frequência de crítico, chance de acerto nem TTK; simular qualquer uma sem entrada canônica criaria falsa confiança.
- Os três personagens são **fontes de caso**, não universo estatístico representativo do rank/estrela.
- **F0** permanece 4/8 documental em HOLD; **F6** permanece sem preenchimento positivo elegível, porque C36 apenas analisa fórmulas já escritas. Nenhuma candidata DMG v2 ou mudança em DMG-RANK v1.1.
- **Ponto de retomada**: (i) F6 efeito SEM expressão numérica e com RE/FIP próprios + ação/custo/alvos/entrega completos; (ii) F0-A5 bytes históricos 0/7, A7 holdout cego HOLD, A8 segundo codificador humano e writer HOLD; (iii) usar cenários C36 como matriz de ensaio VLAB apenas por solicitação à autoridade do VLAB e com combate/defesa verificados, sem assumir seu motor.

**NAC-PASS proporcional**: integridade do cálculo matemático e reprodução local PASS; homologação normativa, certificação de corpus, freeze, holdout e promoção global HOLD. **NO-REPEAT**: C22–C35, não repetir as mesmas expressões sob outro ID.
