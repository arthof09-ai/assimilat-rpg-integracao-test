# C54 — Limites de identificação no estudo FAIR v0.5 / 4×1500 seeds (MESTRE-ONLY)

**Fonte existente:** https://app.notion.com/p/3f3c2b324ede81c88733c2f00a05a8f4. Notion Mestre consultado em somente leitura. **Observação:** este estudo reanalisa contadores apresentados no documento, NÃO recria o motor, as seeds ou os logs originais.

## Descoberta VERIFICADA

A fonte apresenta quatro cenários de 1.500 tentativas cada, mas relata porcentagens de vitória **apenas no subconjunto concluído**. Recalculei, em frações exatas, a faixa de fração de vitórias em TODAS as tentativas se cada execução bloqueada/censurada fosse futuramente adjudicada ora como derrota, ora como vitória. Isto não é um intervalo de confiança e não define um resultado já ocorrido.

| Cenário | Concluídos | Win condicional | Limite hipotético todas tentativas |
|---|---:|---:|---:|
| Strong actor in A | 1018/1500 | 85.36% | 57.93% – 90.07% |
| Same strong actor in B | 1042/1500 | 83.69% | 58.13% – 88.67% |
| Identical twins A/B | 1100/1500 | 49.64% | 36.40% – 63.07% |
| Identical twins swapped | 1103/1500 | 50.14% | 36.87% – 63.33% |

## Aplicação correta
- **6.000 tentativas de cenário, não 6.000 combates completos independentes.** 4.263 concluídos condicionalmente e 1.737 com desfecho não observado; cada cenário usa seu próprio denominador.
- Os 482 desfechos ausentes do actor forte em A se decompõem em **271 bloqueios de falha crítica +206 empates de iniciativa +5 censuras**. Na inversão forte em B: **272 +184 +2 =458** ausentes. Este balanço reconcilia o relato da fonte.
- Nos gêmeos, condicionais próximas de 50% podem mostrar ausência de viés grosseiro no submodelo **condicionado à conclusão**, mas nada prova igualdade de chances entre todas as tentativas com 26,5%–32,1% de resultados ausentes por bloqueios do simulador.
- O espelhamento legado dependia da letra A/B na chave RNG, logo forte A vs forte B não é um par estrito SAME-EVENT-RNG. Sua diferença de vitórias condicionais é descritiva, sem inferência causal sobre favoritismo do algoritmo. O scheduler posterior v0.5 repara a invariância de rótulo nos 1.180 pares concluídos, mas não fecha a elegibilidade da grade 1.875.
- Sob hipótese de missingness informativa, IC95 apresentado apenas para partidas concluídas não pode ser anunciado como IC95 do conjunto de tentativas. Para reduzir a amplitude dos limites, a regra de desempate de iniciativa e consequências de falha crítica devem ser adjudicadas pela fonte competente, ou as execuções bloqueadas devem ter tratamento pré-registrado; NUNCA preenchê-las como derrota/vitória por padrão.

## Estado e próximo gate
**A fonte vigente Sistema de Combate descreve a fórmula de iniciativa, mas não apresentou regra geral inequívoca de desempate** no trecho consultado; FAIR v0.5 classifica esse bloqueio como PENDENTE. Não criar tie-breaker novo por engenharia DMG. O Mestre pode decidir depois em fonte competente; simulações hipotéticas alternativas continuam sem crédito canônico.

`F0 4/8 HOLD`, `A5 0/7 bytes`, `A7 0/8 blind certified`, `A8 writer/segundo humano HOLD`, `D0 scoped=870`, `DMG-RANK-01 v1.1 unchanged`. `FIRST-PENDING`: revisão competente dos efeitos de empate/falha crítica na política de combate; depois testes emparelhados por actor/event stream no SIM-DMG já existente. `NO-REPEAT`: não reexecutar FAIR v0.5 nem simular novos resultados sem acesso a logs/autoridade.
