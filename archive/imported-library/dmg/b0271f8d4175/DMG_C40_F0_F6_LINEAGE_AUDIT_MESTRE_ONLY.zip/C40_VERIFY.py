from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json
p=Path(__file__).parent
with ZipFile(p/'DMG_C40_F0_F6_LINEAGE_AUDIT_MESTRE_ONLY.zip') as z:
 assert z.testzip() is None
 m=json.loads(z.read('C40_MANIFEST.json'))
 for name,meta in m.items():
  b=z.read(name); assert len(b)==meta['bytes'] and sha256(b).hexdigest()==meta['sha256']
 ids=z.read('C40_859_DISTINCT_PAGE_IDS.txt').decode().split()
 assert len(ids)==859 and len(set(ids))==859
 gate=json.loads(z.read('C40_CHECKPOINT.json'))
 assert gate['F0'].startswith('4/8') and gate['global_d0']=='HOLD'
 print('C40 VERIFIED',len(m),'manifest sha entries',len(ids),'unique scoped IDs')
