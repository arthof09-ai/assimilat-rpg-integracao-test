# DMG C40 — Auditoria de retomada A5/A6/A7/F6 — MESTRE-ONLY TEST

**Operação existente:** OP-DMG-CORPUS-EMP-01. **Autorização:** sucessão e continuidade da pesquisa pelo Mestre. **Escritor Notion/epoch/lease:** NÃO verificado; não foi realizada escrita no Notion OP, Diário, Inbox, fichas, VLAB ou Party. **Norma oficial:** DMG-RANK-01 v1.1 preservada.

## I. LAST VERIFIED: C39 e fonte histórica F0
O ZIP C39 permaneceu íntegro e o ZIP histórico `DMG_F0_CONTINUIDADE_SNAPSHOTS_HOLDOUT_20261016_MESTRE_ONLY.zip` foi materializado novamente da Biblioteca Mestre: **20/20 entradas presentes, CRC íntegro e SHA256 `e9c135284d7bf8630d80457a1eed334e9bdbdf20279721ce872daf6fba3bdcd2`**. É a evidência física original do **pré-registro** das fases F0–F18, E01–E24 e oito gates, não substituto dos SETE arquivos Markdown anexados posteriormente à Inbox.

## II. F0-A5 — 7 referências localizáveis, 0/7 bytes dos anexos confirmados
Reabri no Notion Mestre a Inbox [IBX-102](https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25), extraí as sete referências originais `notion-file-block://`, solicitei URLs assinadas à integração: **7/7 resolvidas, 0 não resolvidas**. O transporte privado via ferramenta de arquivo recusou 1 tentativa de download com `url not viewed in conversation before`, que exigiria acesso por superfície web incompatível com a separação de URLs privadas. NÃO publiquei tokens e NÃO afirmei readback. 

Consulta aos sete Page-IDs das autoridades revela **6/7 timestamps de última edição idênticos** aos registrados na captura histórica e **1/7 divergência importante:** [Criação de Ficha](https://app.notion.com/p/3ebc2b324ede81449222f3c06b840613) passou da edição `2026-10-09T04:07:06.313Z` para `2026-10-22T09:34:58.332Z`. Timestamp é indicador de possível mudança, **não prova quais regras mudaram**. O conteúdo atual precisa de versão/lineage separada; snapshots antigos jamais sobrescrever a linha histórica. O CSV detalha sete hashes UTF-8 registrados anteriormente como alegações, **não como SHA rebaixado de anexo**.

F0-A5 **HOLD**, sem gate adicional. Caso uma rota privada autorizada para bytes funcione em outra sessão, conferir nome, tamanho, SHA256 contra manifesto e carimbo temporal original; registrar discrepâncias, não inventar reconstituição de bytes.

## III. F0-A6 — 848 -> 859 IDs únicos, 11 fontes realmente lidas
Busquei focadamente fontes com RE/FIP + mecânica ofensiva faltante, obtive **11 páginas-fonte novas fora da união C34 de 848 IDs**, todas abertas por Notion `fetch` Mestre e confrontadas por page-ID (nenhuma duplicata). **859 ID físicos no recorte Mestre documentado**, NÃO D0 global, NÃO 859 efeitos nem páginas completas de todas as ramificações.

As 11 fontes incluem 3 itens de `Criações do Comestre — Semicanônico / Incubação` (não tratá-los como itens totalmente canônicos); 5 NPCs ON5 com equipamentos Lendários e mecânica própria (fontes proposta Mestre, não virar original da Party); 1 feitiço histórico dentro do **espelho do Mestre** (não tocar Party original), 1 material de fabricação e 1 selo defensivo sem ataque. Listagem detalhada no CSV C40.

### F6 — resultado negativo de admissibilidade 0/11 neste recorte, com razões concretas
- **Martelo do Portão Faminto (INCUBAÇÃO):** RE/FIP ON Média escrito, mas fórmula básica `8d10+12` DME 56 JÁ existe; bônus exclusivo a estruturas `+6d8` custa 25 PA após acerto; não falta dano.
- **Manopla do Trovão Cativo (INCUBAÇÃO):** Ouro Entrada, descarga adicional `+5d8+3` DME 25,5, 22 PA, gatilho após acertar; NÃO é lacuna.
- **Lâmina da Queda Contida (INCUBAÇÃO):** ON Entrada, `7d8+15` DME 46,5 em ataque normal; ancoragem é outra ação defensiva.
- **Sikong Feryn/Veyun/Varok/Arveth/Eristan:** rótulos de FIP pertencem a **peças individuais** e atividades próprias têm valores numéricos ou são cura/controle/defesa, com proveniência de proposta de encontro e notação heterogênea. Falta evidência de **efeito ofensivo autônomo sem dano** apto.
- **Ataque Frio Eterno:** no espelho Mestre de ficha Party, `+2d4` de gelo já existe; uso dependendo de espada/besta, sem preencher regra histórica.
- **Zeo Black:** ingrediente/minério para pontas de flecha, RIn e FIP material PENDENTES; efeito derivado da munição não finalizado.
- **Selo do Último Refúgio (INCUBAÇÃO):** proteção de até 60 dano a três alvos, uma Reação +55 PA; NÃO é efeito ofensivo para gerar DME.

**F6 = 0/11 admissíveis após classificação de tipo de fonte; não extrapolar prevalência para todo RPG nem usar faixa default.** O objetivo de F6 não é gerar um número artificial de dano, mas provar v1.1 sobre um caso original elegível, quando identificado.

## IV. A7 — quarentena de reservas históricas
Comparei por ID, sem abrir páginas, as oito reservas `PRODUTO_B_HOLDOUT_PREREG_PRESEAL.json` com a lista física C34: **8/8 já constam na união de 848 IDs**. Fazer parte do índice NÃO prova que seu texto específico foi visto na mesma campanha, mas a cadeia histórica e a classificação anterior não garantem cegamento de vida inteira. **Não posso certificar esse holdout como independente.** O JSON oferece salvaguardas para reservar um NOVO bloco de entidades/famílias ainda não usados no ajuste, antes de calibrar qualquer candidata, excluindo aliases/transformações do treino. Segundo pesquisador humano real ainda pendente.

## V. Ponto exato e gestão de gates
- **F0:** 4/8 DOCUMENTAL, HOLD; A5 0/7 bytes POST-UPLOAD; A6 859 delimitado sem global; A7 novo holdout independente não selado; A8 segundo codificador, Assignment, writer/epoch/lease ausentes.
- **F6:** triagem direcionada concluída em 11 fontes novas, 0 positivas; nenhum teste real de fallback, não declarar PASS de F6.
- **F7–F18:** NÃO PROMOVIDOS; v2 NÃO PROPOSTA/ADOTADA.
- **NAC-PASS proporcional:** artefatos locais com hashes e fontes consultadas PASS documental; gate sistêmico HOLD.
- **FIRST-PENDING:** buscar fonte ofensiva real sem fórmula, com RE/FIP próprios, ação/custo/entrega; ou avançar A6 em ramo de efeitos/armas ainda não vasculhado. Não repetir C22–C40 e nunca inferir rank do portador/insumo.
