# PSV DMG C19 — Teste prospectivo de chassi classificado, orçamento de ação e fronteiras de rank

**AS-OF:** 2026-10-20 | **OP:** `OP-DMG-CORPUS-EMP-01` | **MESTRE-SIDE / TEST**  
**Último checkpoint verificado:** C18, ZIP SHA-256 `d4a76977f690743cbc2da58a471a32a3a4d099feb7bff87f919aeb104c24e98f` (9802 bytes; CRC íntegro nesta execução).  
**Novo ciclo candidato:** C19, condicionado à indisponibilidade de outro executor e preservação de namespace; cópia científica local.  
**Produção:** HOLD | **Party / O Primeiro / páginas canônicas:** NO-WRITE | **DMG-RANK-01 v1.1:** INALTERADA.

## 1. Problema e critério de progresso

A ordem superveniente C17+ cita C16 porque é uma diretriz histórica; C17 e C18 foram posteriormente encontrados e preservados. Não reexecutar nem renumerar C17–C18. O problema novo de C19 é: **o multiplicador prospectivo do chassi físico preserva a posição FIP relativa e fornece por si só o DME integral da banda de classificação?** A hipótese nula operacional foi `multiplicação dos dados preserva a faixa FIP` (rejeitada para 2d6). Testar também se novas famílias confirmam progressão intrínseca independentemente dos atributos.

**Fontes oficiais lidas:**
- Norma DMG-RANK v1.1, §§4–5, 6–8, 13 e 22: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- Operação existente e Plano Supremo: https://app.notion.com/p/3f3c2b324ede813e9fa0c87ebdea0b29
- Pré-registro: https://app.notion.com/p/3f3c2b324ede815faee6f277392b0bb7
- Metodologia: https://app.notion.com/p/3f3c2b324ede81ab8d8ec1c7cce760b3
- QA: https://app.notion.com/p/3f3c2b324ede815cb014dc6294f40170
- Deliberação expressa do Mestre 20/10: comum ×1; Bronze ×2; Prata ×3; Ouro ×4; Ouro Negro ×5; Lendário ×6 no **número de dados físicos**, prospectivamente. Não retroage a itens antigos. Não confundir dado do chassi com cada linha adicional de uma mesma ação composta.

## 2. Preflight de Inbox DMG (as decisões existem; nenhuma alterada no Notion)

Triagem principal física recuperada de IBX-124 e C17, 18 mensagens no CSV anterior. Reabertura dirigida de IBX-102,103,98,94,92,119,124. Não confundir `NOVA` com não executada.

| IBX | Natureza / decisão | Situação nesta execução | Próximo compromisso |
|---|---|---|---|
| 102 | DECISÃO MESTRE: Plano Supremo F0–F18 | ADOTAR; matriz C17 existente lida; F0 4/8 | Resolver hash de A5 antes de gate |
| 103 | HANDOFF VLAB R71 684/R81 128 | ADOTAR já parcialmente consumido C17; sem criar 812 replicações independentes | Usar dados apenas com clusters, versão e unidade |
| 98 | DECISÃO MESTRE: réplicas TEST | ADOTAR; experimento algorítmico novo em isolamento local | não modificar original |
| 94 | Manual DMG | ADOTAR; método e segregação VLAB/DMG respeitados | reaproveitar laboratório, não duplicar |
| 92 | Galidemus Bronze1 e consulta normativa VLAB | ADIAR separadamente; sem decisão da norma por conta própria | FrozenRuleEvidence/decisão competente |
| 119 | IDEIA: defesa VLAB R205 + inscrições PA R42 | ADAPTAR; R205 já analisada C16 | taxonomia PA somente com fonte explícita |
| 124 | Triagem C16/Plano | ADOTAR; consumida por C17 e revisitada C19 | não concluir/ACK sem writer/INSTANCE |

Outras mensagens e litígios históricos C17: IBX-28/32/34/44/50/57/58/66/69/73/76 continuam em crosswalk C17. Não reexecutar B01–B18 ou primários I0003 por mera abertura de Inbox. ACK e alterações de estado: nenhum executado.

## 3. F0-A5, Plano Supremo e gates

`F0-A1..A8` são **rótulos operacionais reconstruídos**, não artigos normativos oficiais. C17 avaliou 4/8 concluídos documentalmente; A5 primeiro candidato. Nesta execução, 7/7 referências a anexos Markdown em IBX-102 retornaram URLs assinadas resolvíveis pelo conector Notion, 0 irresolutas. Esse resultado **NÃO equivale a leitura dos bytes**. Ainda falta baixar os 7 arquivos e verificar SHA-256 do conteúdo imutável contra o manifesto anterior, bem como autoridade temporal, colisão, readback independente e second coder. A5 segue **PARCIAL**; F0 continua **4/8 HOLD**. A6 superfície/D0 global pendente; A7 holdout lacrado pendente; A8 writer/segunda revisão pendente. Q-MATH restrito ao novo TEST é PASS local; nenhum gate global promovido.

D0–D9 = sem novos denominadores globais; E01–E24 = sem novo PASS global; fases F1–F12 = avanços locais históricos apenas; F13–F18 = HOLD, sem candidata v2. A5/A7/A8, L002/L003, R156 UNKNOWN-EFFECT e R138 HOLD mantidos, sem correções retroativas.

## 4. Experimento H6 — chassi físico e orçamento

**Desenho:** chassi físico de nova arma pesada/brutal `2d6` da §8 da norma; multiplicar somente quantidade de dados por 1…6. Comparar expectativa exata com todas as bandas Entrada/Baixa/Média/Alta/Ápice (único alvo, Ação Padrão e outros critérios somente como *referência*). Não incluir FF/FOR/título/PAD/reação/custo/elemento fictícios; efeitos secundários seriam orçados por ação e não injetados aqui. `RE` de efeito não é herdado automaticamente de classificação/RI de item. Contagem = **seis propostas sintéticas**, não seis itens canônicos nem seis observações populacionais.

| Classificação prospectiva | Chassi TEST | DME chassi | Posição numérica em §5 | Lacuna para piso Entrada |
|---|---|---:|---|---:|
| Comum | 2d6 | 7 | sem RE | N/A |
| Bronze | 4d6 | 14 | Alta (13–15) | 0 |
| Prata | 6d6 | 21 | Baixa (19–22) | 0 |
| Ouro | 8d6 | 28 | Entrada (22–28) | 0 |
| Ouro Negro | 10d6 | 35 | abaixo de Entrada (38–48) | 3 |
| Lendário | 12d6 | 42 | abaixo de Entrada (58–72) | 16 |

**Achado matemático novo:** o multiplicador de dados é monotônico, porém **NÃO** preserva FIP/banda e é insuficiente, sozinho, para caracterizar o orçamento ofensivo integral de uma arma ON ou Lendária sob o perfil-padrão §5. A lacuna 3/16 é uma **diferença de comparação**, não um bônus normativo a acrescentar automaticamente. Riders, custos e modos de ação podem alterar o orçamento legítimo, sujeitos à §22; se a arma é classificada RI, isso não implica que seu chassi físico isolado deva igualar um RE integral. A descoberta gera um *controle de admissibilidade*, não uma errata da norma nem retcon.

**Sensibilidade:** 48 células = 6 chassis × 8 RD TEST (`0/5/10/15/20/30/40/50`), definidas sobre distribuição exata de dados, **condicionadas ao acerto, sem crítico**. A métrica `E[max(0,X-RD)]` (apenas no hipotético cenário de resistência aplicável a todo o chassi) é reproduzida com convolução discreta, fórmula combinatória independente de inclusão/exclusão e identidade de soma de caudas. Em RD20:

| Chassi | E pós-RD20 | Probabilidade de causar dano positivo |
|---|---:|---:|
| 4d6 (Bronze) | 0,043209877 | 0,027006173 |
| 6d6 (Prata) | 2,222736626 | 0,546424897 |
| 8d6 (Ouro) | 8,090463535 | 0,939287313 |
| 10d6 (Ouro Negro) | 15,002717552 | 0,997110021 |
| 12d6 (Lendário) | 22,000035535 | 0,999942632 |

**Limitação central:** sem perfil de defensor, ataque vs CA, críticos, resistência por tipo, Vida, custos e número de ações, estes números não representam DPS, chance de vitória nem aprovação de equipamento.

## 5. Corpus real adicional e hipótese de atributo/progressão

**Fontes reabertas:** cinco páginas de duas famílias; universo **direcionado**, não censo global. `SOURCE-PAGES=5`; `FAMILIES=2`; `EFFECT-DEFINITIONS=2` (`Investida Feroz`, `Lâmina de Brisa`); ocorrências nas 5 páginas=5; `COMPARADORES_CROSS_RANK_ESTRITOS=0` devido a ação/custo/linhagem insuficientes; `PAIRS_EXPLORATORIOS=2`. Não tratar esses efeitos relacionados como cinco amostras independentes. A análise já havia estudado qualitativamente Rinolupo e Sussurro em ciclos anteriores; **a contribuição C19** é o novo teste exato e o controle prospectivo, não redescoberta de famílias inéditas.

**Rinolupo — Prata1 vs Prata4:**
- https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3: corpo Prata1, `2d6+FOR`, FOR30, RDF10.
- https://app.notion.com/p/a47c2b324ede821f834481bef49fb8e3: corpo Prata4, `2d6+FOR`, FOR38, RDF10.
- DME intrínseco idêntico, 7 → 7; dano bruto contextual 37 → 45; aumento +8 **inteiramente atribuível ao FOR nas expressões observadas**. Não é inferência causal universal nem autorização para fixar coeficiente de rank. Em RD hipotética 40 aplicável a esse tipo: média pós-RD 0,111111111 → 5; chance de superar a redução 8,33% → 97,22%. A RDF10 é habilidade **do próprio Rinolupo**, não foi imposta ao alvo nesse cálculo.
- https://app.notion.com/p/d58c2b324ede8208b24b014eaaf3ac5c: título `Ouro 5`, corpo `Prata 4`; classificar CONFLITANTE e excluir de progressão Ouro válida, sem resolver silenciosamente.

**Sussurro Celestial — Prata5 vs Ouro1:**
- https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b: `2d6+INT`, INT45, custo 5PA; DME intrínseco 7, contextual 52; suporte dos resultados 47–57.
- https://app.notion.com/p/442c2b324ede8364870a814350dd5051: `2d4+INT`, INT26, custo omitido; DME intrínseco 5, contextual 31; suporte dos resultados 28–34.
- **Reprodução/fortalecimento da inversão C13:** o mínimo P5 (47) é maior que o máximo O1 (34), de modo que a inversão vale para **100% dos resultados brutos de dados** se os modificadores literais forem aplicados como escritos. Diferença nas médias brutas -21 para a ficha O1, decomposta em -2 de dados e -19 INT. Contudo, a página O1 não especifica custo PA/ação, e as fontes podem conter linhagem/tipo incomparável; portanto não constitui falha normativa comprovada, nem par estrito. Os cenários genéricos RD de 0–60 são apenas análise de sensibilidade, **não RD física aplicada automaticamente a dano de Vento**.

**Decisão de admissibilidade:** Rinolupo P1/P4 PARCIAL por ação/custo; Rinolupo página Ouro5 CONFLITANTE; Sussurro P5/O1 PARCIAL por PA/ação e ancestralidade. ZERO novas comparações cross-rank estritas totalmente elegíveis. Isso representa um **resultado negativo delimitado** do estrato e estabelece a lacuna de dados precisa; não propomos falso status ELEGÍVEL.

## 6. Instrumento funcional recomendado para novas criações

**Procedimento TEST de aceitação de arma classificada, sem editar a norma:**

1. Registrar RI do item separadamente de RE de cada efeito e FIP justificada.
2. Extrair chassi físico sem bônus externos; aplicar multiplicador prospectivo à **quantidade** de dados, não ao modificador final.
3. Somar dano intrínseco total apenas dos componentes pertencentes à mesma ação, sem duplicar o orçamento §22.
4. Classificar componentes não ofensivos (controle, bypass, mobilidade, defesa), custo/ação/PA, e limites de frequência.
5. Confrontar DME intrínseco total e o perfil de entrega com bandas §5 e ajustes §§9–13; evitar impor banda Entrada a todo chassi físico isolado.
6. Para o perfil de defensor explicitamente autorizado, calcular distribuição exata de dano pós-RD por tipo, `P(dano>0)` e dano médio condicionado ao acerto.
7. Incorporar precisão/crítico/saves se, e somente se, as regras e atributos do cenário forem conhecidos; caso contrário, marcar UNKNOWN.
8. Registrar o orçamento do mesmo golpe apenas uma vez, incluindo magia/riders; ataques separados têm contratos de custo e ação próprios.
9. Comparar 3+ itens de RI/RE/FIP e função homogêneos antes de atribuir desequilíbrio; fontes históricas calibradoras não são validação cega.
10. Emitir `ADEQUADO / ANOMALIA LOCAL TEST / INSUFICIENTE` com fontes, alternativas e plano confirmatório; sem retcon automático.

**Caso de aplicação:** uma arma pesada nova, hipoteticamente `RI=Lendário`, com chassi 12d6 pode estar correta quanto ao multiplicador e continuar sem documentação de DME total da ação, RE/FIP, custo, controle e módulos. **Resultado: insuficiente para aceitar orçamento final**, não anomalia automaticamente corrigível por +16 fixos. Uma arma histórica como Gorrok Espada Curva 5d8 permanece intacta e não usa multiplicador novo retroativamente.

## 7. Estado depois / continuidade

**LAST-VERIFIED-UNIT:** C18 íntegro; C19 análise local reproduzível pelo `c19_scientific_oracle.py`.  
**NOVAS UNIDADES DE TEST:** 6 classificações × 8 RD = 48 células matemáticas; 2 pares exploratórios × 7 RD = 14 células; 5 páginas fonte reabertas; 2 famílias (não independentes entre si no mesmo estrato, sem 5 indivíduos).  
**FIRST-PENDING:** localizar uma família independente com ação, custo, RE/FIP e mecanismo integralmente especificados; obter o download físico byte-for-byte dos 7 anexos de A5 e conferir hashes contra manifesto; não reivindicar writer sem prova.  
**NEXT-5:** (1) readback A5 7/7; (2) varredura dirigida de fonte strict que inclua ação/custo; (3) teste efetividade com CA/RD/crítico legitimamente autorizados; (4) contrato Chicote Água via rota competente somente se útil; (5) adjudicação de conflito de rank e revisão cega independente.  
**TARGET-REMAINDER:** F0 formal 4/8 HOLD; F1–F18 sem promoção global; E01–E24, D0–D9, A5/A7/A8, L002/L003 e holdouts mantidos com limites; sem criação de DMG v2.  
**Writer/collision/instance:** não demonstrados; **Notion operação/Diário/Inbox NO-WRITE nesta execução**, somente Biblioteca Mestre existente quando persistência tiver recibo físico real.  
**NAC-PASS:** reprodutibilidade matemática local; NAC-PASS canônico **NÃO** concedido.  
**DMG-RANK-01 v1.1:** MANTER; evolução limitada a procedimento TEST e diagnóstico da compatibilidade de armas novas.

## 8. Artefatos e prova

- `c19_scientific_oracle.py`: motor analítico local, NÃO motor de combate concorrente.
- `C19_CHASSI_BANDA_6_CLASSES.csv`: seis classes prospectivas.
- `C19_CHASSI_RD_EXATO_48_CASOS.csv`: sensibilidade física por mitigação.
- `C19_NOVO_READBACK_5_PAGINAS_2_FAMILIAS.csv`: fontes físicas e status.
- `C19_DUAS_FAMILIAS_RD_EXATO_14_CASOS.csv`: análise exata dos dois pares históricos.
- `C19_VERIFICACAO_EXATA.json`: contagens, negativos, provas e limites.
- `C19_MANIFEST_SHA256.json`: hashes de todos os arquivos entregues.

Todo sucesso de produção/Library é informado separadamente após upload/readback; este PSV, isoladamente, não substitui o comprovante da persistência.
