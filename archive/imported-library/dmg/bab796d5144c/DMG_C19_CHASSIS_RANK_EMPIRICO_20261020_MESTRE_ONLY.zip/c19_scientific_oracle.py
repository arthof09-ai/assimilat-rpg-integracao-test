#!/usr/bin/env python3
"""C19 DMG — independent deterministic dice probability evaluator; NO external writes.
This executable evaluates isolated physical weapon chassis and documented beast formulas.
It neither infers attack probability nor changes the official damage table.
"""
from collections import Counter
from fractions import Fraction
from math import comb
import csv, json, hashlib
from pathlib import Path
P=Path(__file__).parent
RANKS=[('Comum',1,None,None),('Bronze',2,4,18),('Prata',3,14,36),('Ouro',4,22,62),('Ouro Negro',5,38,96),('Lendário',6,58,160)]
BANDS={'Bronze':[(4,6,'Entrada'),(7,9,'Baixa'),(10,12,'Média'),(13,15,'Alta'),(16,18,'Ápice')], 'Prata':[(14,18,'Entrada'),(19,22,'Baixa'),(23,26,'Média'),(27,31,'Alta'),(32,36,'Ápice')], 'Ouro':[(22,28,'Entrada'),(29,35,'Baixa'),(36,44,'Média'),(45,52,'Alta'),(53,62,'Ápice')], 'Ouro Negro':[(38,48,'Entrada'),(49,58,'Baixa'),(59,69,'Média'),(70,82,'Alta'),(83,96,'Ápice')], 'Lendário':[(58,72,'Entrada'),(73,90,'Baixa'),(91,112,'Média'),(113,136,'Alta'),(137,160,'Ápice')]}

def dice(n,faces):
    pmf=Counter({0:1})
    for _ in range(n):
        nxt=Counter()
        for s,k in pmf.items():
            for v in range(1,faces+1): nxt[s+v]+=k
        pmf=nxt
    assert sum(pmf.values())==faces**n
    # Independent exact combinatorial oracle by inclusion/exclusion (not a replay of convolution)
    for total,count in pmf.items():
        alt=0
        for j in range((total-n)//faces+1):
            alt+=(-1)**j*comb(n,j)*comb(total-faces*j-1,n-1)
        assert alt==count,('pmf-mismatch',n,faces,total,count,alt)
    return pmf

def metrics(n,faces,fixed,rd):
    p=dice(n,faces)
    den=faces**n
    out={s+fixed:k for s,k in p.items()}
    mean=Fraction(sum(v*c for v,c in out.items()),den)
    ppos=Fraction(sum(c for v,c in out.items() if v>rd),den)
    post=Fraction(sum(max(0,v-rd)*c for v,c in out.items()),den)
    # Alternative tail-sum identity independently evaluates post-RD from survivor counts.
    ceiling=max(out)
    tail=Fraction(sum(sum(c for v,c in out.items() if v>=threshold) for threshold in range(rd+1,ceiling+1)),den)
    assert tail==post
    assert post<=mean
    return {'mean':mean,'after':post,'p_positive':ppos,'min':min(out),'max':ceiling,'n_combinations':den}

def f(x):return f'{float(x):.9f}'
def frac(x):return f'{x.numerator}/{x.denominator}'
def savecsv(name,items):
    with (P/name).open('w',newline='',encoding='utf-8') as o:
        w=csv.DictWriter(o,fieldnames=list(items[0]),extrasaction='ignore');w.writeheader();w.writerows(items)

rows=[];sens=[]
for name,m,lo,hi in RANKS:
    n=2*m
    q=metrics(n,6,0,0)
    mapping='COMUM_SEM_RE'
    if name in BANDS:
        mapping=next((pos for lower,upper,pos in BANDS[name] if lower<=q['mean']<=upper),'ABAIXO_DE_ENTRADA' if q['mean']<lo else 'ACIMA_DE_APICE')
    gap=max(0,lo-q['mean']) if lo is not None else 0
    rows.append({'classificacao_prospectiva':name,'multiplicador':m,'chassi':'2d6','expressao_prospectiva':f'{n}d6','DME_intrinseco_chassi':f(q['mean']),'banda_RE_min':lo if lo is not None else 'NOT_APPLICABLE','banda_RE_max':hi if hi is not None else 'NOT_APPLICABLE','posicao_FIP_referencial_SEM_AUTOMATISMO':mapping,'lacuna_DME_para_ENTRADA':f(gap),'fonte_multiplicador':'ORDEM_MESTRE_20261020','fonte_banda':'DMG-RANK-01_v1.1_sec5','status':'TEST_COMPARACAO_ORCAMENTO_NAO_CLASSIFICA_ITEM_REAL'})
    for rd in [0,5,10,15,20,30,40,50]:
        q=metrics(n,6,0,rd)
        sens.append({'classificacao_prospectiva':name,'expressao':f'{n}d6','RD_TEST':rd,'DME_bruto':f(q['mean']),'P_dano_positivo':f(q['p_positive']),'P_dano_positivo_fraction':frac(q['p_positive']),'E_pos_RD_condicional_acerto':f(q['after']),'E_pos_RD_fraction':frac(q['after']),'combos':q['n_combinations'],'critical_accuracy':'UNKNOWN_NOT_MODELED','enemy_hp':'UNKNOWN','source_type':'SYNTHETIC_TEST_PROSPECTIVE'})
savecsv('C19_CHASSI_BANDA_6_CLASSES.csv',rows)
savecsv('C19_CHASSI_RD_EXATO_48_CASOS.csv',sens)

families=[
 {'family':'Rinolupo','page_id':'034c2b324ede83ffa7118144011beaf3','URL':'https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3','page_title':'Prata 1','body_rank':'Prata 1','attack':'Investida Feroz','formula_literal':'2d6+ for','formula_interpretada_TEST':'2d6+FOR','FOR':30,'INT':None,'cost':'UNKNOWN','action':'UNKNOWN','classification':'PARCIAL','status':'BODY_TITLE_MATCH; same innate dice pool'},
 {'family':'Rinolupo','page_id':'a47c2b324ede821f834481bef49fb8e3','URL':'https://app.notion.com/p/a47c2b324ede821f834481bef49fb8e3','page_title':'Prata 4','body_rank':'Prata 4','attack':'Investida Feroz','formula_literal':'2d6+ for','formula_interpretada_TEST':'2d6+FOR','FOR':38,'INT':None,'cost':'UNKNOWN','action':'UNKNOWN','classification':'PARCIAL','status':'BODY_TITLE_MATCH; same innate dice pool'},
 {'family':'Rinolupo','page_id':'d58c2b324ede8208b24b014eaaf3ac5c','URL':'https://app.notion.com/p/d58c2b324ede8208b24b014eaaf3ac5c','page_title':'Ouro 5','body_rank':'Prata 4','attack':'Investida Feroz','formula_literal':'2d6+ for','formula_interpretada_TEST':'2d6+FOR','FOR':56,'INT':None,'cost':'UNKNOWN','action':'UNKNOWN','classification':'CONFLITANTE','status':'TITLE_BODY_MISMATCH; cannot treat as Ouro5'},
 {'family':'Sussurro Celestial','page_id':'5e9c2b324ede83ed99078151805dec0b','URL':'https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b','page_title':'Prata 5','body_rank':'Prata 5','attack':'Lâmina de Brisa','formula_literal':'2d6 + INT. 5 PA','formula_interpretada_TEST':'2d6+INT','FOR':10,'INT':45,'cost':'5 PA','action':'UNKNOWN','classification':'PARCIAL','status':'MATCH body; attr45; cost5'},
 {'family':'Sussurro Celestial','page_id':'442c2b324ede8364870a814350dd5051','URL':'https://app.notion.com/p/442c2b324ede8364870a814350dd5051','page_title':'Ouro 1','body_rank':'Ouro 1','attack':'Lâmina de Brisa','formula_literal':'2d4 + INT','formula_interpretada_TEST':'2d4+INT','FOR':50,'INT':26,'cost':'UNKNOWN','action':'UNKNOWN','classification':'PARCIAL','status':'MATCH body; attr26; cost missing'}]
savecsv('C19_NOVO_READBACK_5_PAGINAS_2_FAMILIAS.csv',families)
comparisons=[]
def report(a,b,reference):
    for rd in [0,10,20,30,40,50,60]:
        A=metrics(*a['dice'],a['bonus'],rd);B=metrics(*b['dice'],b['bonus'],rd)
        comparisons.append({'comparador':reference,'formula_A':a['text'],'formula_B':b['text'],'RD_TEST':rd,'DME_A':f(A['mean']),'DME_B':f(B['mean']),'DME_delta_B_menos_A':f(B['mean']-A['mean']),'E_postRD_A':f(A['after']),'E_postRD_B':f(B['after']),'E_postRD_delta_B_menos_A':f(B['after']-A['after']),'P_positive_A':f(A['p_positive']),'P_positive_B':f(B['p_positive']),'status':'PAREADO_EXPLORATORIO_NAO_CASO_ESTRITO'})
report({'dice':(2,6),'bonus':30,'text':'Rinolupo Prata1 2d6+30'},{'dice':(2,6),'bonus':38,'text':'Rinolupo Prata4 2d6+38'},'RINOLUPO_P1_VS_P4')
report({'dice':(2,6),'bonus':45,'text':'Sussurro Prata5 2d6+45'},{'dice':(2,4),'bonus':26,'text':'Sussurro Ouro1 2d4+26'},'SUSSURRO_P5_VS_O1')
savecsv('C19_DUAS_FAMILIAS_RD_EXATO_14_CASOS.csv',comparisons)
assert metrics(2,6,45,0)['min']>metrics(2,4,26,0)['max'] # disjoint observed rolls
assert metrics(2,6,38,0)['mean']-metrics(2,6,30,0)['mean']==8
assert metrics(2,6,38,0)['mean']-metrics(2,6,30,0)['mean']==38-30
assert len(rows)==6 and len(sens)==48 and len(families)==5 and len(comparisons)==14
with (P/'C19_VERIFICACAO_EXATA.json').open('w',encoding='utf-8') as o:
    json.dump({'C19_method':'Discrete convolution + combinatorial inclusion-exclusion oracle + survival-tail identity','calibration':'None; synthetic prospective H6 & source-scoped empirical H1/H2/H3','classes':6,'chassis_rd_cases':48,'documented_pages':5,'distinct_families':2,'family_rd_cases':14,'independent_effect_definitions':2,'strict_cross_rank_pairs':0,'exploratory_pairs':2,'Rinolupo_delta_FOR_points':8,'Rinolupo_delta_intrinsic_dice_DME':0,'Sussurro_P5_min':47,'Sussurro_O1_max':34,'Sussurro_nonoverlap_pre_defense':True,'source_censor':'no attack action validated; no crit/hit/PA inferred','F0_formal':'4/8 HOLD','Notion_writes':False},o,ensure_ascii=False,indent=2)
print('SCIENCE_C19_PASS',len(rows),len(sens),len(families),len(comparisons))
for a in rows:print(a['classificacao_prospectiva'],a['DME_intrinseco_chassi'],a['posicao_FIP_referencial_SEM_AUTOMATISMO'],a['lacuna_DME_para_ENTRADA'])
for name in ['Bronze','Prata','Ouro','Ouro Negro','Lendário']:
 print('RD20',name,next((a['E_pos_RD_condicional_acerto'],a['P_dano_positivo']) for a in sens if a['classificacao_prospectiva']==name and a['RD_TEST']==20))
