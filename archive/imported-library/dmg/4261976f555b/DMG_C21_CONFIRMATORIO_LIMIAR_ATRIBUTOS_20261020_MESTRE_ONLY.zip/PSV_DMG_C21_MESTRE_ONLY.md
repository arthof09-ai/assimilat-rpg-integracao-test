# PSV DMG C21 — CONTRASTES CONTROLADOS E ADMISSIBILIDADE (MESTRE-ONLY)

AS-OF: 2026-10-20; OP: OP-DMG-CORPUS-EMP-01; responsável lógico CM-000001, sem assumir writer; ambiente MESTRE-SIDE/TEST; produção HOLD; Party/O Primeiro NO-WRITE.

## 1. LAST-VERIFIED / ANTES
C20 pacote Biblioteca verificado byte a byte no preflight SHA256 `0c4fe2166baaf8dae1509321a3a83409277b486f95842d44e3bd1787774f7ff2`, CRC PASS, manifesto 14/14 PASS. C20: 16 páginas, oito famílias, 20 ocorrências e oito pares classificados A=0/B=3/C=5. F0=4/8 HOLD. Namespace C21 livre à checagem da biblioteca. Não reconstruir C20.

## 2. Pergunta C21 / medida de resultado
Uma unidade adicional de atributo sempre rende uma unidade de dano efetivo contra resistências físicas reais? E a diferença documentada entre efeitos RN adjacentes representa progressão de RE? Investigação distingue dano intrínseco da fórmula, modificador do atacante, mitigação física, eficácia por acerto, acerto por tentativa e custo da ação.

## 3. Contraste CONTROLADO verificável — Galidemus × defesas reais
Fontes reabertas Notion Mestre: Galidemus Bronze1 `https://app.notion.com/p/eddc2b324ede829f8a75011e8acbf429` ("Patada: 1d4 + destreza cortante", DES13); Rinolupo Prata1 `https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3` (Pele Couraçada RDF10); Gorrok `https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474` (resistência a dano físico 15). Tipo cortante é explícito; mitigação física está explicitamente documentada em ambos defensores. Mantêm-se fonte, atacante, ataque e tipo; só muda a defesa no primeiro contraste (duas criaturas, por isso NÃO é mesmo defensor nem prova de efeito causal de +5 RD durante um combate). Para isolar a influência de DEX, mantém-se Gorrok mesmo defensor e usa-se alterações TEST da DEX de Galidemus.

- Fonte real DES13: bruto médio `31/2` = 15,5. Contra RDF10, pós-mitigação médio `11/2` = 5,5 por acerto, P(dano positivo)=1. Contra resistência física15, líquido `3/4` = 0,75 por acerto, P(dano positivo)=`1/2`; 0,75 não representa dano por tentativa. Redução de média 19/4 = 4,75, não 5.
- DES TEST12,13,14,15 contra resistência15: 1/4, 3/4, 3/2, 5/2 líquidos médios; P positivo 1/4,1/2,3/4,1. Ganhos marginais da DEX 12→13,13→14,14→15: 1/2,3/4,1. Demonstra **não-linearidade pós-RD** sem alterar a norma.
- Atributo DEX não integra DME intrínseco da Patada: 1d4 intrínseco médio 2,5. Gross = 15,5 é contextual; não se compara às bandas RE; RE/FIP dessa habilidade não demonstrados.
- Conformidade: cálculo exato da distribuição uniforme dos dados, convolução e enumeração independente; sem críticos, CA ou PA (não aplicados por ausência do contrato ofensivo completo); comparação física aplicada por tipo explicitamente cortante. Se houver imunidade/bypass/defesas adicionais ou exceção normativa, reevaluar; nenhum pressuposto de resultado VLAB.

## 4. Checagem de família independente, não holdout cego
Raposa alfa Bronze5 fonte `https://app.notion.com/p/529c2b324ede82e8a86f81f8cfc0477e`: Soco `1d6 + For20`. Tipo físico é inferência sem campo literal. Sob *hipótese explícita* de Soco físico, RDF10 deixa 13,5 de dano líquido e resistência15 deixa 8,5, diferença integral 5. Todas as 6 faces ultrapassam ambas as resistências. Isso testa o mesmo mecanismo de limiar em faixa diferente, mas **NÃO** constitui admissão canônica do tipo, validação independente cega, nem par inter-rank.

Wyvern: páginas `https://app.notion.com/p/c5bc2b324ede82628e6e01b466fa0f78` e `https://app.notion.com/p/a78c2b324ede83069d7801b3519e2a4f` têm títulos Ouro1/Ouro5 e corpo Lendário; habilidades sem expressões numéricas. Resultado negativo finito, excluído, não dano=zero.

## 5. Sussurro Celestial — sequência de três posições (NOVO desenho de progressão)
P1 `https://app.notion.com/p/56ac2b324ede8352868101e11ea16355` Lâmina de Brisa `1d6 + INT30` DME_intrínseco 3,5 / bruto33,5 / PA ausente.
P5 `https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b` `2d6+INT45` DME_intrínseco 7 / bruto52 / 5PA.
O1 `https://app.notion.com/p/442c2b324ede8364870a814350dd5051` `2d4+INT26` DME_intrínseco 5 / bruto31 / PA ausente.
A sequência do mesmo nome de efeito mostra progressão intrínseca 3,5→7→5: de P1 a P5 +3,5 nos dados e +15 no atributo; de P5 a O1 −2 nos dados e −19 no atributo (C20 já decompôs a última inversão). É um **perfil de expressão não monotônico**, não prova de que RE, poder canônico ou identidade de implementação regrediu com RN. Faltam ação, RE/FIP, condição, custo nos extremos e genealogia.

## 6. Classificação dos três B e autoridades complementares
B1 Suss P1→P5: parâmetro INT/dados explicativo, PA P1 e RE/FIP não recuperados; B para matemática, sem eficiência por PA.
B2 Suss P5→O1: INT/dados exatos (C20), PA O1, RE/FIP e ação desconhecidos; B, sem inferência normativa.
B3 Rinolupo P1→P4: `2d6+FOR30` contra `2d6+FOR38`; diferença em FOR sem alteração de dado, custo/RE/ação/precisão faltam; B.
Fontes competentes reabertas Atlas Canônico PR-ECO-01, DMG-RANK v1.1, Sistema Combate, Sistema Magia, Criação Besta, DMG-METHOD e Taxonomia. Ação padrão de ataque comum e conjuração por padrão NÃO conferem automaticamente tipo da habilidade, nem RE/FIP específico de ficha. Nenhum B promovido a A.

## 7. F0-A5 paralelo
Contrato histórico Notion Inbox IBX-102: `https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25` e manifesto `COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json`. Sete referências anexo Notion são localizáveis/resolvíveis; foram reabertos seus apontadores e hashes históricos. A ferramenta de leitura de upload de attachment retornou resultado vazio; transferência do URL assinado para arquivo em container foi recusada por não estar previamente visualizado em sessão; **0/7 bytes históricos obtidos e verificados**, 7/7 identificadores referenciáveis. Não recriar conteúdos nem certificar hashes novos. F0=4/8 HOLD, A5/A7/A8 pendentes. Autenticação de anexo é independente da ciência TEST.

## 8. VLAB e denominadores
VLAB R71/R81/R205 já triados C16-C20; sem nova leitura de recibos necessária ao teste puramente distributivo. Sem combates novos ou autoridade de writer VLAB, nenhuma execução enviada/aceita. C21 denominadores locais: três fontes do contraste principal (1 atacante, 2 defensores), quatro níveis de DEX TEST (somente 1 canônico), 8 células de distribuição física exata; uma família distinta condicional (Raposa); três fichas Suss (uma família, duas transições dependentes); duas Wyvern excluídas. Não extrapolar D0-D9 globais, n=8 seeds ou observações populacionais.

## 9. Adequação e recomendações (sem alteração da norma)
**Recomendação de avaliação TEST:** em criações, separar DME_intrínseco, modificador do atributo, status de tipo físico/elemental, autorização da RD, chance de dano positivo, média pós-RD e efetividade por tentativa/PA somente quando parâmetros conhecidos. Próximo teste falsificável: o ganho esperado pós-RD por +1 atributo é 1 quando o dano bruto mínimo já supera a RD, e menor/igual a 1 nos estados de truncamento; invalidar se a regra de RD aplicável não usar `max(0,D−RD)` ou se bônus não for aditivo em ação competente. Sem provar/alterar bandas DMG v1.1. Documentar conflitos Wyvern e estados RE/FIP desconhecidos no catálogo da OP em futura janela autorizada; não editar fichas.

## 10. F0–F18 / E01–E24 / D0–D9 / NAC-PASS
F0 4/8 HOLD; F1–F12 contribuições locais históricas sem promoção global; F13–F18 sem candidata. A5 0/7 bytes originais; A7 holdout e A8 revisão independente pendentes. D0–D9 globais NÃO certificados. E01–E24 não promovidos. Oito gates transversais dependem de evidência competente. R138 HOLD e R156 UNKNOWN-EFFECT preservados; nenhuma nova avaliação destes registros. L002/L003, histórico C04–C20 e quarentenas sem alteração. NAC-PASS local MATH/ARQUIVO sujeito ao readback da Biblioteca; global HOLD. Sem novas alterações Notion Mestre, Party, O Primeiro, fichas, regras ou VLAB; writer/epoch/lease/fencing/ACK não presumidos.

## 11. DEPOIS científico e TARGET-REMAINDER
**Avanço novo:** contraste contra duas defesas reais tipadas fisicamente, sensibilidade exata de efeito de atributo sob resistência, comparação textual de três efeitos Suss e busca finita negativa de Wyvern. Domínio: matemática do dano por acerto condicionada; equilíbrio global INDETERMINADO.
**FIRST-PENDING:** teste comparador de RE/FIP explícito com competência de ação/custo ou autenticação 7 anexos F0-A5 com bytes verificados. **NEXT-5:** (1) reabrir regras tipadas de patada para precisão/crit se indispensável, (2) descobrir primeira ficha com RE/FIP documental individual, (3) construir benchmark intra-efeito com defensor tipado e custo da ação, (4) validar contraste em coorte VLAB se justificadamente necessária, (5) recuperar F0-A5 com transferência de bytes autenticamente suportada. **NO-REPEAT:** C20 Suss 576 distribuições, C19 48/62 RD, C16 R205. **Estado formal:** Biblioteca persistência dependente de recibo pós-upload.
