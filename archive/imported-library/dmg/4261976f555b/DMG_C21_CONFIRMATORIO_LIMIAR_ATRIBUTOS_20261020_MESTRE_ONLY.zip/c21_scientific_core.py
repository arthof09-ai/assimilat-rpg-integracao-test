from collections import Counter
from fractions import Fraction
from itertools import product

def die(n): return Counter(range(1,n+1))
def pmf_dice(ds):
  c=Counter({0:1})
  for sides in ds:
    nxt=Counter()
    for v,num in c.items():
      for side in range(1,sides+1):nxt[v+side]+=num
    c=nxt
  return c

def metrics(ds,bonus,rd):
  cnt=pmf_dice(ds);N=sum(cnt.values())
  dmg=Fraction(sum(num*max(0,val+bonus-rd) for val,num in cnt.items()),N)
  pp=Fraction(sum(num for val,num in cnt.items() if val+bonus>rd),N)
  brute=Fraction(sum(num*(val+bonus) for val,num in cnt.items()),N)
  return {'brute':brute,'net':dmg,'p_positive':pp,'outcomes':N,'distribution':[(x, cnt[x]) for x in sorted(cnt)]}

for dex in range(11,17):
 for rd in [10,15]:
  m=metrics([4],dex,rd)
  print('GALI', dex,rd,'gross',m['brute'],'net',m['net'],'P+',m['p_positive'])

for att,ds,bonus in [('SussP1',[6],30),('SussP5',[6,6],45),('SussO1',[4,4],26),('RinP1',[6,6],30),('RinP4',[6,6],38),('RapB5',[6],20)]:
 print('EXPR',att,'dice',metrics(ds,0,0)['brute'],'gross',metrics(ds,bonus,0)['brute'],'net10',metrics(ds,bonus,10)['net'],'net15',metrics(ds,bonus,15)['net'])
