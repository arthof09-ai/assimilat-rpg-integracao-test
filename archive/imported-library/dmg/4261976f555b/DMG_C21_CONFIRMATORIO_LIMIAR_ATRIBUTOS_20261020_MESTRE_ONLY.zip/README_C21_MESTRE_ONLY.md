# DMG C21 — execução TEST independente e auditável

Extraia o ZIP, preserve seu manifesto e execute `python c21_replay_independent.py`: este script usa só a biblioteca padrão e os CSVs incluídos, reproduz 8 células Galidemus, 6 células independentes condicionais e 3 fichas Sussurro, além de verificar os hashes do pacote. Os demais CSVs contêm triagem de autoridade e F0-A5 com URLs originais.

`c21_oracle.py` é o gerador de desenvolvimento e referencia os checkpoints C20 e o manifesto A5 montados na sessão do executor. Ele **não é** o teste independente portátil; este é `c21_replay_independent.py`.

Se algum hash falhar, parar; não reconstruir fontes Notion por inferência. O arquivo não altera fichas, normas, VLAB ou Party. Não usar a análise local para aprovação normativa.
