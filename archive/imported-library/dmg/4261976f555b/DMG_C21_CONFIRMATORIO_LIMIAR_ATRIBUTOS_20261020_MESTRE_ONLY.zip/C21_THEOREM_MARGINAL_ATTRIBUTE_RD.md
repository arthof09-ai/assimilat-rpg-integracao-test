# C21 — Lema do ganho marginal de atributo após RD

**Domínio:** dano inteiro não negativo antes de mitigação, bônus inteiro aditivo `b`, RD física `r` fixa, mitigação por `max(0, dano-r)`, ataque já acertado. Nenhuma afirmação sobre críticos, acerto, salvaguarda, multiplicadores, bônus de outra camada ou dano direto à Alma.

Para variável inteira de dano-base `X` e bônus inteiro `b`, seja

`N(b) = E[max(0, X+b-r)]`.

Então a diferença esperada pelo aumento de um ponto no bônus é

`N(b+1)-N(b)= P(X+b >= r)`.

**Prova ponto a ponto:** para inteiro `y=X+b-r`, `max(0,y+1)-max(0,y)` vale 1 quando `y>=0` e vale zero quando `y<0`. Tirando a esperança, obtém-se a probabilidade desejada. Dessa forma, o ganho marginal pertence ao intervalo `[0,1]`, não sendo universalmente 1.

**Fonte real**: Galidemus (`1d4+DES13`, cortante) contra Gorrok (resistência física 15); ambas documentações Notion Mestre.

Com `b=12`: P(1d4+12>=15)=2/4, portanto passar de DES12 para13 adiciona 0,5 de dano esperado pós-RD.

Com `b=13`: P(1d4+13>=15)=3/4, portanto passar de DES13 para14 adiciona 0,75.

Com `b=14`: P(1d4+14>=15)=4/4, portanto passar de DES14 para15 adiciona 1.

**Uso científico correto**: se uma regra permite +1 no bônus de dano, a melhora real depende da distribuição do ataque e do alvo. Isto não altera a DME intrínseca regulada pela DMG-RANK; informa diagnóstico contextual de efetividade. Sem autoridade de ataque e acerto, não computar dano por tentativa/turno.
