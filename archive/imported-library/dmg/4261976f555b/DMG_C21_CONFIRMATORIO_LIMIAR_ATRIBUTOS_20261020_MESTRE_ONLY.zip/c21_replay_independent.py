"""C21 independent math replay from portable CSV payload, no API or Notion writes.
Run in extracted C21 zip directory: python c21_replay_independent.py
"""
from pathlib import Path
from collections import Counter
from itertools import product
from fractions import Fraction
import csv,json,hashlib,zipfile
P=Path(__file__).resolve().parent

def read(name):return list(csv.DictReader((P/name).open(encoding='utf-8',newline='')))
def calc(ds,b,rd):
 # Independent direct enumeration without convolution / random seeds.
 rolls=[sum(t) for t in product(*[range(1,d+1) for d in ds])]
 n=len(rolls)
 return {'gross':Fraction(sum(x+b for x in rolls),n),'net':Fraction(sum(max(0,x+b-rd) for x in rolls),n),
         'pos':Fraction(sum(1 for x in rolls if x+b>rd),n),'zero':Fraction(sum(1 for x in rolls if x+b<=rd),n),'N':n}

for r in read('C21_GALIDEMUS_RD_TRUE_CONTRAST.csv'):
 x=calc([4],int(r['attribute_dex']),int(r['rd_physical']))
 assert x['gross']==Fraction(r['gross_expected'])
 assert x['net']==Fraction(r['net_expected_on_hit'])
 assert x['pos']==Fraction(r['p_positive_on_hit'])
 assert x['zero']==Fraction(r['p_zero_on_hit'])
 assert x['N']==int(r['n_equiprobable_rolls'])
for r in read('C21_CROSS_FAMILY_HYPOTHESIS_CHECK.csv'):
 import re
 m=re.match(r'(\d+)d(\d+)(?:\+(\d+))?',r['formula'])
 assert m
 num,faces,bonus=map(int,[m.group(1),m.group(2),m.group(3) or '0'])
 x=calc([faces]*num,bonus,int(r['rd']))
 assert x['net']==Fraction(r['net_expected']) and x['pos']==Fraction(r['p_positive'])
for r in read('C21_SUSS_TRIPLE_RN_RE_INTRINSIC.csv'):
 import re
 m=re.match(r'(\d+)d(\d+)\+INT',r['expression'])
 assert m
 d,s=int(m.group(1)),int(m.group(2));INT=int(r['INT'])
 assert calc([s]*d,0,0)['gross']==Fraction(r['intrinsic_dme'])
 assert calc([s]*d,INT,0)['gross']==Fraction(r['gross_dme'])

m=json.loads((P/'C21_MANIFEST_SHA256.json').read_text(encoding='utf-8'))
for f in m['files']:
 p=P/f['name']
 assert p.stat().st_size==f['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
print('C21 independent replay PASS: 8 Galidemus, 6 other-family, 3 Suss; '+str(len(m['files']))+'/'+str(len(m['files']))+' manifest hashes PASS')
