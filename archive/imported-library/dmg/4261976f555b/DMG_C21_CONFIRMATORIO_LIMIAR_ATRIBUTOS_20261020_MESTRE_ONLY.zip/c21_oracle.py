from collections import Counter
from fractions import Fraction
from itertools import product
import json, csv, pathlib, zipfile, hashlib, datetime, shutil
ROOT=pathlib.Path('/mnt/data/dmg_c21')
ROOT.mkdir(exist_ok=True)
BASE=pathlib.Path('/mnt/data/DMG_C20_ADMISSIBILIDADE_PROGRESSAO_20261020_MESTRE_ONLY.zip')
SHA20='0c4fe2166baaf8dae1509321a3a83409277b486f95842d44e3bd1787774f7ff2'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(BASE)==SHA20
with zipfile.ZipFile(BASE) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('C20_MANIFEST_SHA256.json'))
 assert len(manifest['files'])==14
 for rec in manifest['files']:
  b=z.read(rec['name']);assert len(b)==rec['bytes'] and hashlib.sha256(b).hexdigest()==rec['sha256'],rec['name']

# An independent implementation of the probability distribution is used as an internal control.
def convolution(sides):
 c=Counter({0:1})
 for n in sides:
  m=Counter()
  for x,k in c.items():
   for face in range(1,n+1):m[x+face]+=k
  c=m
 return c

def enumeration(sides):
 return Counter(map(sum, product(*[range(1,s+1) for s in sides])))

def calc(ds, bonus=0, rd=0):
 c=convolution(ds)
 assert c==enumeration(ds)
 n=sum(c.values())
 gross=Fraction(sum((r+bonus)*k for r,k in c.items()),n)
 post=Fraction(sum(max(0,r+bonus-rd)*k for r,k in c.items()),n)
 pos=Fraction(sum(k for r,k in c.items() if r+bonus>rd),n)
 z=Fraction(sum(k for r,k in c.items() if r+bonus<=rd),n)
 return dict(n=n,gross=gross,post=post,p_positive=pos,p_zero=z,
             min_gross=min(c)+bonus,max_gross=max(c)+bonus)

def stringify(x):
 if isinstance(x,Fraction):return f'{x.numerator}/{x.denominator}'
 return x

def rows_write(fname, rows):
 with open(ROOT/fname,'w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows([{k:stringify(v) for k,v in row.items()} for row in rows])

# Galidemus source: DEX=13, Patada=1d4+Destreza, cortante.
# Defenders, both physical: Rinolupo RDF10 and Gorrok physical damage resistance 15.
rows=[]
for dex in (12,13,14,15):
 for defensive,rd,uri in [
  ('Rinolupo_P1_PeleCouracada_RDF10',10,'https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3'),
  ('Gorrok_O1_ResistenciaNatural_Fisica15',15,'https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474')
 ]:
  x=calc((4,),dex,rd)
  rows.append({'attacker':'Galidemus (galinha demoníaca) Bronze1','formula':'1d4+DES',
   'attribute_dex':dex,'attribute_status':'REAL' if dex==13 else 'TEST_CONTRAFACTUAL',
   'damage_tag':'CORTANTE EXPLICIT', 'defender':defensive,'defender_source_url':uri,
   'rd_physical':rd,'gross_expected':x['gross'],'net_expected_on_hit':x['post'],
   'p_positive_on_hit':x['p_positive'],'p_zero_on_hit':x['p_zero'],
   'n_equiprobable_rolls':x['n'],'hit_prob':'UNKNOWN','action_cost':'UNKNOWN'})
rows_write('C21_GALIDEMUS_RD_TRUE_CONTRAST.csv',rows)
assert calc((4,),13,10)['post']==Fraction(11,2)
assert calc((4,),13,15)['post']==Fraction(3,4)
assert calc((4,),13,15)['p_positive']==Fraction(1,2)
for dex,expected in [(12,Fraction(1,4)),(13,Fraction(3,4)),(14,Fraction(3,2)),(15,Fraction(5,2))]:
 assert calc((4,),dex,15)['post']==expected

# Cross-family, independently documented *Soco* mechanical expression. Damage type physical is semantically likely but unlabelled in source.
check=[]
for name, ds, b, typ in [
 ('Raposa alfa Bronze5 Soco',(6,),20,'FISICO_PRESUMED_TYPE_NOT_EXPLICIT'),
 ('Rinolupo Prata1 Investida Feroz',(6,6),30,'FISICO_PRESUMED_HORN_ATTACK'),
 ('Gorrok Adaga',(4,),0,'FISICO_PRESUMED_BLADE')]:
 for rd in (10,15):
  r=calc(ds,b,rd)
  check.append(dict(entity_effect=name,formula=f'{len(ds)}d{ds[0]}'+(f'+{b}' if b else ''),
   type_status=typ,defender=('Rinolupo RDF10' if rd==10 else 'Gorrok physical15'),
   defender_source_url=('https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3' if rd==10 else 'https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474'),
   rd=rd,net_expected=r['post'],p_positive=r['p_positive'],status='CONDITIONAL_NOT_STRICT_TYPE'))
rows_write('C21_CROSS_FAMILY_HYPOTHESIS_CHECK.csv',check)
assert calc((6,),20,10)['post']==Fraction(27,2)
assert calc((6,),20,15)['post']==Fraction(17,2)

# Sussurro: 3 physical source pages; this compares formula-intrinsic measures, not RN to RE inference.
sources=[('Prata1',(6,),30,None,'https://app.notion.com/p/56ac2b324ede8352868101e11ea16355'),
 ('Prata5',(6,6),45,5,'https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b'),
 ('Ouro1',(4,4),26,None,'https://app.notion.com/p/442c2b324ede8364870a814350dd5051')]
suss=[]
for rank,ds,INT,PA,url in sources:
 intrinsic=calc(ds,0,0)['gross'];gross=calc(ds,INT,0)['gross']
 suss.append(dict(family='Sussurro Celestial',rn=rank,effect='Lâmina de Brisa',
  expression=f'{len(ds)}d{ds[0]}+INT',intrinsic_dme=intrinsic,INT=INT,
  external_attribute_component=INT,gross_dme=gross,PA=(PA if PA is not None else 'UNKNOWN'),
  RE='UNKNOWN',FIP='UNKNOWN',action='UNKNOWN',hit='UNKNOWN',source_url=url))
rows_write('C21_SUSS_TRIPLE_RN_RE_INTRINSIC.csv',suss)
assert [x['intrinsic_dme'] for x in suss]==[Fraction(7,2),Fraction(7,1),Fraction(5,1)]
assert [x['gross_dme'] for x in suss]==[Fraction(67,2),Fraction(52,1),Fraction(31,1)]

# B-grade lacuna map: only exact necessary fields for the different scientific hypotheses.
b=[
 ('B1','Suss P1 -> P5','mathematical dice+INT','Pa P1 unknown; action both unknown; RE/FIP both unknown','PA-P1 not needed for dice/INT; required for PA efficiency','RE/STAR not substitutable; structural for RN->RE conclusions','Remain B; P1 1d6+30 vs P5 2d6+45; intrinsic +3.5, attribute +15','https://app.notion.com/p/56ac2b324ede8352868101e11ea16355 | https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b'),
 ('B2','Suss P5 -> O1','mathematical dice+INT','PA O1 unknown; action both unknown; RE/FIP both unknown','INT may be standardized in TEST; cost not needed for mathematical difference','RE assignment and costs needed to infer balance/efficiency','Remain B; intrinsic -2, INT -19; see C20 for already proved decomposition','https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b | https://app.notion.com/p/442c2b324ede8364870a814350dd5051'),
 ('B3','Rinolupo P1 -> P4','mathematical dice+FOR','PA/action and RE/FIP unknown; horn charge delivery presumed','FOR can be normalized; PA not needed for same-pool proof','No RE/FIP, precision/action; cannot infer comparative combat efficacy','Remain B; 2d6 stable, FOR30 ->38; RDF10 supports defender model only','https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3 | https://app.notion.com/p/a47c2b324ede821f834481bef49fb8e3')]
rows_write('C21_THREE_B_CONSTRAINT_SPECIFIC_LACUNAE.csv',[dict(id=i,case=nm,valid_domain=vd,not_documented=nd,conditionable_or_nonapplicable=cond,structural=st,decision=d,source_urls=src) for i,nm,vd,nd,cond,st,d,src in b])

# Finite targeted authority search. Do not promote generalized action defaults to individual effect assertions.
auth=[
 ('PR-ECO Atlas Canônico','3eec2b324ede81ea8920c52473ecc3ab','RN/RE/FIP concept and precedent','Defines axes; no individually certified Suss/Rino RE/FIP'),
 ('DMG-RANK v1.1','3f2c2b324ede815498cddb7844245f7e','Intrinsic DME boundary / default budgets','Does not assign RE retroactively to historical beast skill'),
 ('Sistema de Combate','3ebc2b324ede81f1be4be8804ac113c0','Normal attack costs standard action','Cannot presume each beast technique equals ordinary attack'),
 ('Sistema de Magia','3ebc2b324ede81f7b343f7270ff91373','Unspecified spell time 1 standard action','Suss ability not explicitly classified as spell in its page'),
 ('Criação de Besta','3ebc2b324ede81f4992ac88a3588cacd','RN/STAR, base damage and special exceptions','Cannot substitute RN for effect RE'),
 ('DMG-METHOD-EMP-01','3f3c2b324ede81ab8d8ec1c7cce760b3','Cross-rank comparability contract','No new per-skill action/cost fields'),
 ('DMG-TAX-DATA-01','3f3c2b324ede81609a28e18c11d3cae4','Taxonomy and mixed damage','No new per-skill type or RE'),
]
rows_write('C21_TARGETED_AUTHORITY_READBACK.csv',[dict(source=a,page_id=i,source_url=f'https://app.notion.com/p/{i}',utility=u,unresolved=v) for a,i,u,v in auth])

# Finite independent-ish cross-check: Wyvern new pages have no numeric damage and content/body classification mismatch.
rows_write('C21_INDEPENDENT_FAMILY_ELIGIBILITY.csv',[
 {'family':'Wyvern','page_title':'Ouro 1','source_url':'https://app.notion.com/p/c5bc2b324ede82628e6e01b466fa0f78','body_RN':'Lendário (without star)','numeric_damage':'ABSENT','grade':'EXCLUDED','reason':'title/body RN mismatch; no quantitative attack or skill formula'},
 {'family':'Wyvern','page_title':'Ouro 5','source_url':'https://app.notion.com/p/a78c2b324ede83069d7801b3519e2a4f','body_RN':'Lendário (without star)','numeric_damage':'ABSENT','grade':'EXCLUDED','reason':'title/body RN mismatch; no quantitative attack or skill formula'},
 {'family':'Raposa Alfa','page_title':'Bronze 5','source_url':'https://app.notion.com/p/529c2b324ede82e8a86f81f8cfc0477e','body_RN':'Bronze 5','numeric_damage':'1d6+FOR20 (Soco)','grade':'COND_TEST','reason':'Different family; physical tag semantically plausible but not literal; not a blind holdout'}
])

# A5 status per material archived manifest; 7 signed URL refs are available but original bytes cannot be downloaded by current integrated tool.
manifest_p=pathlib.Path('/mnt/data/dmg_work/COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json')
if not manifest_p.exists():
 with zipfile.ZipFile('/mnt/data/dmg_work/DMG_F0_A5_A6_HOLDOUT_GATES_20261016_MASTER_ONLY.zip') as z:
  m=json.loads(z.read('COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json'))
else:m=json.loads(manifest_p.read_text())
A5=[]
for idx,s in enumerate(m['snapshot_entries'],1):
 A5.append({'i':idx,'filename':s['attachment_filename'],'source_url':s['source_url'],
  'upload_bytes_historical':s['attachment_utf8_bytes_at_upload'],
  'source_content_sha256_historical':s['source_content_sha256_utf8_expected'],
  'pointer_in_notion':'READABLE','signed_url':'RESOLVABLE_7_OF_7',
  'original_attachment_bytes':'NOT_DOWNLOADED',
  'download_obstacle':'download_attachment returned empty; signed URL transfer rejected by container due URL provenance; no byte content exposed',
  'byte_hash_vs_source':'NOT_VERIFIED', 'gate':'F0-A5 HOLD'})
rows_write('C21_F0_A5_7_FILE_ATTEMPTS.csv',A5)

# Current global gates explicitly unchanged. Local 3 B mathematical and new controlled contrasts only.
state={'checkpoint':'C21','parent':'C20','baseline_sha256':SHA20,
 'as_of_user_date':'2026-10-20','official_norm':'DMG-RANK-01 v1.1 UNALTERED',
 'C20_manifest': '14/14 PASS','C20_crc':'PASS','C21_namespace':'FREE_AT_PREFLIGHT',
 'compare_A':0,'compare_B':3,'compare_C':5,'new_confirmatory': 'Galidemus physical cortante vs RDF10 and Gorrok physical15',
 'new_scientific_result':'At true defender physical RD15, marginal effective contribution of +1 Dex 12->13=0.5; 13->14=0.75; 14->15=1.0, instead of always +1',
 'f0':'4/8 HOLD','f0_a5_resolved_refs':7,'f0_a5_download_verified_bytes':0,
 'new_global_gate_closed':0,'library_and_notion_write':'LIBRARY_ONLY; NO_WRITE_NOTION',
 'VLAB':'READ_ONLY; NO NEW RUNS', 'holdouts':'NOT_BLIND', 'nac_pass':'LOCAL_MATH_ONLY'}
(ROOT/'C21_STATE_AND_DECISION.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Programmatic assertions independent of CSV serialization
m12=calc((4,),12,15);m13=calc((4,),13,15);m14=calc((4,),14,15);m15=calc((4,),15,15)
assert m13['post']-m12['post']==Fraction(1,2)
assert m14['post']-m13['post']==Fraction(3,4)
assert m15['post']-m14['post']==1
assert calc((4,),13,10)['post']-calc((4,),13,15)['post']==Fraction(19,4)
assert calc((6,),20,10)['post']-calc((6,),20,15)['post']==5
(ROOT/'C21_EXACT_TESTS.json').write_text(json.dumps({
 'baseline_sha':sha(BASE),'cross_checks_passed':True,'galidemus_RDF10': '11/2',
 'galidemus_RD15':'3/4','delta_RD_effect':'19/4','marginal_dex_gain':['1/2','3/4','1'],
 'raposa_conditional_full_five':'5','suss_intrinsic_seq':['7/2','7','5'],
 'count_of_numeric_rolls_conditional':'all outcomes exact, no random seeds',
 'no_inference_on_accuracy_PA_or_combat':True,
},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

psv=f'''# PSV DMG C21 — CONTRASTES CONTROLADOS E ADMISSIBILIDADE (MESTRE-ONLY)

AS-OF: 2026-10-20; OP: OP-DMG-CORPUS-EMP-01; responsável lógico CM-000001, sem assumir writer; ambiente MESTRE-SIDE/TEST; produção HOLD; Party/O Primeiro NO-WRITE.

## 1. LAST-VERIFIED / ANTES
C20 pacote Biblioteca verificado byte a byte no preflight SHA256 `{SHA20}`, CRC PASS, manifesto 14/14 PASS. C20: 16 páginas, oito famílias, 20 ocorrências e oito pares classificados A=0/B=3/C=5. F0=4/8 HOLD. Namespace C21 livre à checagem da biblioteca. Não reconstruir C20.

## 2. Pergunta C21 / medida de resultado
Uma unidade adicional de atributo sempre rende uma unidade de dano efetivo contra resistências físicas reais? E a diferença documentada entre efeitos RN adjacentes representa progressão de RE? Investigação distingue dano intrínseco da fórmula, modificador do atacante, mitigação física, eficácia por acerto, acerto por tentativa e custo da ação.

## 3. Contraste CONTROLADO verificável — Galidemus × defesas reais
Fontes reabertas Notion Mestre: Galidemus Bronze1 `https://app.notion.com/p/eddc2b324ede829f8a75011e8acbf429` ("Patada: 1d4 + destreza cortante", DES13); Rinolupo Prata1 `https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3` (Pele Couraçada RDF10); Gorrok `https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474` (resistência a dano físico 15). Tipo cortante é explícito; mitigação física está explicitamente documentada em ambos defensores. Mantêm-se fonte, atacante, ataque e tipo; só muda a defesa no primeiro contraste (duas criaturas, por isso NÃO é mesmo defensor nem prova de efeito causal de +5 RD durante um combate). Para isolar a influência de DEX, mantém-se Gorrok mesmo defensor e usa-se alterações TEST da DEX de Galidemus.

- Fonte real DES13: bruto médio `31/2` = 15,5. Contra RDF10, pós-mitigação médio `11/2` = 5,5 por acerto, P(dano positivo)=1. Contra resistência física15, líquido `3/4` = 0,75 por acerto, P(dano positivo)=`1/2`; 0,75 não representa dano por tentativa. Redução de média 19/4 = 4,75, não 5.
- DES TEST12,13,14,15 contra resistência15: 1/4, 3/4, 3/2, 5/2 líquidos médios; P positivo 1/4,1/2,3/4,1. Ganhos marginais da DEX 12→13,13→14,14→15: 1/2,3/4,1. Demonstra **não-linearidade pós-RD** sem alterar a norma.
- Atributo DEX não integra DME intrínseco da Patada: 1d4 intrínseco médio 2,5. Gross = 15,5 é contextual; não se compara às bandas RE; RE/FIP dessa habilidade não demonstrados.
- Conformidade: cálculo exato da distribuição uniforme dos dados, convolução e enumeração independente; sem críticos, CA ou PA (não aplicados por ausência do contrato ofensivo completo); comparação física aplicada por tipo explicitamente cortante. Se houver imunidade/bypass/defesas adicionais ou exceção normativa, reevaluar; nenhum pressuposto de resultado VLAB.

## 4. Checagem de família independente, não holdout cego
Raposa alfa Bronze5 fonte `https://app.notion.com/p/529c2b324ede82e8a86f81f8cfc0477e`: Soco `1d6 + For20`. Tipo físico é inferência sem campo literal. Sob *hipótese explícita* de Soco físico, RDF10 deixa 13,5 de dano líquido e resistência15 deixa 8,5, diferença integral 5. Todas as 6 faces ultrapassam ambas as resistências. Isso testa o mesmo mecanismo de limiar em faixa diferente, mas **NÃO** constitui admissão canônica do tipo, validação independente cega, nem par inter-rank.

Wyvern: páginas `https://app.notion.com/p/c5bc2b324ede82628e6e01b466fa0f78` e `https://app.notion.com/p/a78c2b324ede83069d7801b3519e2a4f` têm títulos Ouro1/Ouro5 e corpo Lendário; habilidades sem expressões numéricas. Resultado negativo finito, excluído, não dano=zero.

## 5. Sussurro Celestial — sequência de três posições (NOVO desenho de progressão)
P1 `https://app.notion.com/p/56ac2b324ede8352868101e11ea16355` Lâmina de Brisa `1d6 + INT30` DME_intrínseco 3,5 / bruto33,5 / PA ausente.
P5 `https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b` `2d6+INT45` DME_intrínseco 7 / bruto52 / 5PA.
O1 `https://app.notion.com/p/442c2b324ede8364870a814350dd5051` `2d4+INT26` DME_intrínseco 5 / bruto31 / PA ausente.
A sequência do mesmo nome de efeito mostra progressão intrínseca 3,5→7→5: de P1 a P5 +3,5 nos dados e +15 no atributo; de P5 a O1 −2 nos dados e −19 no atributo (C20 já decompôs a última inversão). É um **perfil de expressão não monotônico**, não prova de que RE, poder canônico ou identidade de implementação regrediu com RN. Faltam ação, RE/FIP, condição, custo nos extremos e genealogia.

## 6. Classificação dos três B e autoridades complementares
B1 Suss P1→P5: parâmetro INT/dados explicativo, PA P1 e RE/FIP não recuperados; B para matemática, sem eficiência por PA.
B2 Suss P5→O1: INT/dados exatos (C20), PA O1, RE/FIP e ação desconhecidos; B, sem inferência normativa.
B3 Rinolupo P1→P4: `2d6+FOR30` contra `2d6+FOR38`; diferença em FOR sem alteração de dado, custo/RE/ação/precisão faltam; B.
Fontes competentes reabertas Atlas Canônico PR-ECO-01, DMG-RANK v1.1, Sistema Combate, Sistema Magia, Criação Besta, DMG-METHOD e Taxonomia. Ação padrão de ataque comum e conjuração por padrão NÃO conferem automaticamente tipo da habilidade, nem RE/FIP específico de ficha. Nenhum B promovido a A.

## 7. F0-A5 paralelo
Contrato histórico Notion Inbox IBX-102: `https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25` e manifesto `COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json`. Sete referências anexo Notion são localizáveis/resolvíveis; foram reabertos seus apontadores e hashes históricos. A ferramenta de leitura de upload de attachment retornou resultado vazio; transferência do URL assinado para arquivo em container foi recusada por não estar previamente visualizado em sessão; **0/7 bytes históricos obtidos e verificados**, 7/7 identificadores referenciáveis. Não recriar conteúdos nem certificar hashes novos. F0=4/8 HOLD, A5/A7/A8 pendentes. Autenticação de anexo é independente da ciência TEST.

## 8. VLAB e denominadores
VLAB R71/R81/R205 já triados C16-C20; sem nova leitura de recibos necessária ao teste puramente distributivo. Sem combates novos ou autoridade de writer VLAB, nenhuma execução enviada/aceita. C21 denominadores locais: três fontes do contraste principal (1 atacante, 2 defensores), quatro níveis de DEX TEST (somente 1 canônico), 8 células de distribuição física exata; uma família distinta condicional (Raposa); três fichas Suss (uma família, duas transições dependentes); duas Wyvern excluídas. Não extrapolar D0-D9 globais, n=8 seeds ou observações populacionais.

## 9. Adequação e recomendações (sem alteração da norma)
**Recomendação de avaliação TEST:** em criações, separar DME_intrínseco, modificador do atributo, status de tipo físico/elemental, autorização da RD, chance de dano positivo, média pós-RD e efetividade por tentativa/PA somente quando parâmetros conhecidos. Próximo teste falsificável: o ganho esperado pós-RD por +1 atributo é 1 quando o dano bruto mínimo já supera a RD, e menor/igual a 1 nos estados de truncamento; invalidar se a regra de RD aplicável não usar `max(0,D−RD)` ou se bônus não for aditivo em ação competente. Sem provar/alterar bandas DMG v1.1. Documentar conflitos Wyvern e estados RE/FIP desconhecidos no catálogo da OP em futura janela autorizada; não editar fichas.

## 10. F0–F18 / E01–E24 / D0–D9 / NAC-PASS
F0 4/8 HOLD; F1–F12 contribuições locais históricas sem promoção global; F13–F18 sem candidata. A5 0/7 bytes originais; A7 holdout e A8 revisão independente pendentes. D0–D9 globais NÃO certificados. E01–E24 não promovidos. Oito gates transversais dependem de evidência competente. R138 HOLD e R156 UNKNOWN-EFFECT preservados; nenhuma nova avaliação destes registros. L002/L003, histórico C04–C20 e quarentenas sem alteração. NAC-PASS local MATH/ARQUIVO sujeito ao readback da Biblioteca; global HOLD. Sem novas alterações Notion Mestre, Party, O Primeiro, fichas, regras ou VLAB; writer/epoch/lease/fencing/ACK não presumidos.

## 11. DEPOIS científico e TARGET-REMAINDER
**Avanço novo:** contraste contra duas defesas reais tipadas fisicamente, sensibilidade exata de efeito de atributo sob resistência, comparação textual de três efeitos Suss e busca finita negativa de Wyvern. Domínio: matemática do dano por acerto condicionada; equilíbrio global INDETERMINADO.
**FIRST-PENDING:** teste comparador de RE/FIP explícito com competência de ação/custo ou autenticação 7 anexos F0-A5 com bytes verificados. **NEXT-5:** (1) reabrir regras tipadas de patada para precisão/crit se indispensável, (2) descobrir primeira ficha com RE/FIP documental individual, (3) construir benchmark intra-efeito com defensor tipado e custo da ação, (4) validar contraste em coorte VLAB se justificadamente necessária, (5) recuperar F0-A5 com transferência de bytes autenticamente suportada. **NO-REPEAT:** C20 Suss 576 distribuições, C19 48/62 RD, C16 R205. **Estado formal:** Biblioteca persistência dependente de recibo pós-upload.
'''
(ROOT/'PSV_DMG_C21_MESTRE_ONLY.md').write_text(psv,encoding='utf-8')
(ROOT/'README_C21_MESTRE_ONLY.md').write_text('# C21 — ciência TEST\nPara reproduzir a matriz, execute `python c21_oracle.py` (este arquivo equivale ao gerador do lote) com dados de fontes rastreadas nas matrizes. Os dados físicos são mencionados com URL Notion; nenhum arquivo original de ficha é modificado.\n',encoding='utf-8')
# Preserve own runnable code in package, no external dependency.
shutil.copyfile(__file__,ROOT/'c21_oracle.py')

# Manifest lists all payload except itself.
files=[]
for path in sorted(ROOT.iterdir()):
 if not path.is_file() or path.name in {'build_c21.py','C21_MANIFEST_SHA256.json'}:continue
 files.append({'name':path.name,'sha256':sha(path),'bytes':path.stat().st_size})
manifest={'checkpoint':'C21','scope':'MESTRE-ONLY/TEST','baseline_C20_sha256':SHA20,'count':len(files),'files':files}
(ROOT/'C21_MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
ZIP=ROOT.parent/'DMG_C21_CONFIRMATORIO_LIMIAR_ATRIBUTOS_20261020_MESTRE_ONLY.zip'
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ROOT.iterdir()):
  if not p.is_file() or p.name=='build_c21.py':continue
  z.write(p,p.name)
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None
 for obj in manifest['files']:
  b=z.read(obj['name']); assert len(b)==obj['bytes'] and hashlib.sha256(b).hexdigest()==obj['sha256']
print(json.dumps({'archive':str(ZIP),'sha256':sha(ZIP),'bytes':ZIP.stat().st_size,'manifest_files':len(files),'pass':'LOCAL_CRC_AND_HASH_PASS','C20_SHA':SHA20},indent=2))
