# ADENDO C29 — A6: TRÊS ÁRVORES FILHAS INDEPENDENTES / MESTRE-ONLY

**Operação:** OP-DMG-CORPUS-EMP-01; **executor lógico:** CM-000001; **Estado:** TEST/READ-ONLY, gate F0 **4/8 HOLD**. **Fonte:** Notion Mestre, páginas reabertas diretamente em 21/10/2026. O relatório C29 principal já foi persistido; esta é uma evidência **aditiva**, sem reabrir ou renomear o checkpoint anterior.

## Delimitação e unidade

O recorte inclui **26 páginas de Magias**, **19 de Armas** e **15 de Artefatos**: **60 Page-IDs físicos únicos**, com pais distintos MAGIA, ARMA, ARTEFATO, seleção congelada antes da leitura das folhas. Os 17 links da mãe Itens são **ramos estruturais**, não 17 observações adicionais. Não é o D0 global do RPG, tampouco se confunde com G1/411. A ficha-fonte original permanece intacta; não houve consulta à Party nem a O Primeiro.

## Descobertas verificadas

1. **Magias 26/26 — efeito mecânico inacessível em texto**: todas possuem imagem, mas após a tag de imagem somente o preço em MED (às vezes sem unidade) permanece como texto. Por isso ``IMAGE_ONLY_TEXT_PRICE``. Não inferir efeito, dano, ação, duração, PA ou RE/FIP pelo nome, preço ou código B/P/O/ON/L no título. **0/26 extrações textuais não equivale a 26 magias sem dano**. Recuperar imagens por canal de mídia autorizado e codificar visualmente em estudo separado, sem OCR automático por conveniência.
2. **Armas 19/19**: **5/19** têm classificação textual nominal explícita (três Lendário, duas Ouro Negro); **14/19** estão “Sem classificação”. **5/19** contêm fórmula numérica de ataque legível em texto; uma delas, a Lança Sopro Congelante, não tem classificação. Rank do item não é RE de cada componente, portanto **RE individual certificado permanece ausente**.
3. **Artefatos 15/15**: **15/15 “Sem classificação”**. Dados de recuperação de cargas da Coroa do Reino Esplendor ``1d6+3`` são carga, NÃO dano. Sem completar classificação ou RE por preço, utilidade ou forma física.
4. **Unidade de cálculo**: formulações legíveis incluem Arco Exterminador ``8d8+25`` (DME 61) mais bônus ``8d12+10`` (DME 62, somente contra elementais); Espada Chamas Vivas ``5d10+5d8+15`` (DME 65); Adaga da Serpente ``5d4+5d8+10`` (45) e veneno ``3d12`` (19,5 por tick condicionado à falha e duração não informada); Espada do Lendário 768 **antes de FOR**; Lança Sopro Congelante ``4d6+INT`` (14 + INT externa) e ``4d8`` (18). Médias analíticas **não** constituem danos efetivos por tentativa nem autorização de somas entre componentes.

## Gates

**A6 ROOT MAP**: passou a ter mais uma **subárvore física diretamente censada 60/60**, com 3 raízes e 60 folhas únicas. **F0-A6 GLOBAL:** PARTIAL, sem aprovação formal: há outros ramos do RPG e falta proveniência recursiva D0. **A5:** imagens e outros anexos não são equivalentes aos sete snapshots históricos; A5 permanece 0/7 originais autenticados. **A7/A8:** HOLD. **F0:** 4/8 HOLD. **DME/FIP independente:** não promovido. **DMG-RANK-01 v1.1:** inalterada.

## NEXT específico

- Abrir as 26 imagens de magias **por fonte visual autorizada e legível**, com codificador independente, registrando fórmula/PA/salvaguarda quando fisicamente existentes. Caso imagens não acessíveis, marcar bloqueio e prosseguir fontes textuais alternativas; não criar equivalentes de D&D ou preencher “0”.
- Completar outros ramos vinculados à página Itens e biblioteca de Técnicas/Pergaminhos sob mesma lógica Page-ID e família; deduplicar com linhas prévias de C22–C29.
- Na trilha F0, trabalhar A5 originais e writer/segundo codificador reais, sem alegar A6 PASS global com esta subamostra.

## Rastreamento

Ver ``C29_A6_SUBCORPUS_60_FONTES_MESTRE_ONLY.csv`` para todos os Page-IDs, URL e marcação; ``C29_A6_OITO_MAGNITUDES_CONDICIONAIS.json`` para cálculos numéricos; manifesto SHA e recibo para integridade. A descrição da seleção é determinística, mas os corpos integrais de Notion não foram congelados nesse pequeno adendo: a auditoria documental independente exige reabrir URL/ID. ``SOURCE_STATUS: DIRECT-READ-NOT-FROZEN``.
