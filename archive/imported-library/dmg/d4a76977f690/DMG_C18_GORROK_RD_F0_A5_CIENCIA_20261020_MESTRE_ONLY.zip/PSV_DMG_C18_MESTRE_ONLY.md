# PSV — DMG C18 / Ciência material em Gorrok e pré-gate F0-A5 (MESTRE-ONLY)

**AS-OF:** 2026-10-20. **Operação preexistente:** OP-DMG-CORPUS-EMP-01. **LAST-VERIFIED-UNIT:** C17 recuperado com SHA256 idêntico ao recibo. **BASELINE:** DMG-RANK-01 v1.1 INALTERADA. **PRODUÇÃO:** HOLD. **PARTY/O PRIMEIRO/FICHAS/RULES:** NO-WRITE.

## 1. ANTES / recuperação
- C17 ZIP `DMG_C17_PLANO_SUPREMO_FIP_R71_CIENCIA_20261020_MESTRE_ONLY.zip`: 32.204 bytes; SHA256 `2a0340e77ad3ea6f2596c9639df7f04fa578f1e3adfdbe1e92bbbf323d897165`; 17 entries, ZIP CRC PASS nesta execução. O manifesto contém 16 SHA de payload; artefato imutável, sem reempacotamento.
- F0 = 4/8; F0-A5 rótulo operacional, não norma autônoma. C17 não publicou C18. Diretório Biblioteca listado neste ciclo sem C18 já existente. Não foi feito censo externo de outros diretórios, portanto apenas disponibilidade no destino pesquisado.
- F0 pacote anterior 81.017 bytes SHA `397cd335096270ee180b834abb2074b84de68909821ffd6192cac8653fdc6a62` e anexação 23.074 bytes SHA `e9a80cd303ed56093424010af961578b839e2bb36b0b5abc4ef6c3e300f96319`; ambos localizados na Biblioteca e integridade ZIP verificada nesta execução.

## 2. Inbox relevante / decisões
- IBX-102 Mestre: ADOTAR plano existente e ciência orientada a resultado. Página reaberta. ACK = NÃO ATESTADO; estado persistente NOVA não é ausência de execução.
- IBX-124 informação: ADOTAR triagem, nada concluir na Inbox; página reaberta. Sem ACK requerido.
- IBX-103: VLAB R71/R81 reutilizados no C17; NÃO repetir, só estratos ainda não estudados; sem comunicação nova.
- IBX-98/94: autonomia TEST e manual, autorizam cópias isoladas sem writer de produção.
- IBX-92: Galidemus e questões normativas pendentes fora desta análise.
- IBX-119: R205 já aproveitado C16, PA R42/RE/FIP pendente. Sem takeover de VLAB/PA/CRAFT.
- 18 mensagens detalhadas permanecem na planilha `C17_INBOX_DMG_TRIAGEM.csv` no C17 (não recriadas em C18). Nenhuma alteração a estados da Inbox.

## 3. Plano Supremo e gate
- F0 documental permanece **4/8**. A5 é o primeiro fechamento potencial mas **NÃO PASS**.
- Manifests prévios provam 7 anexos Markdown em blocos da IBX-102, 7/7 ponteiros e último snapshot textual identificado; **0/7 readbacks binários autenticados**. Nesta execução `notion_download_attachment` para SNAP_01 devolveu objeto vazio; não é comprovação de conteúdo. Reabrir fonte não substitui byte readback do anexo original. Fontes Criação de Ficha e Transformação Espiritual têm mudanças temporais documentadas em relação ao pré-registro anterior; manter versões distintas.
- A6 332 filhos diretos distintos de oito raízes apenas na amostra histórica, sem recursão/censo global. A7 holdout por família sem selagem global. A8 second coder e writer/claim não demonstrados.
- Não foi atribuída porcentagem final a F1–F18. Preparação e ciência exploratória continuam, candidata v2 não criada.

## 4. Fontes e unidades novas
- Fonte S1: `https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474`, Gorrok (caçador), personagem, corpo Gorrok (O1), consultado 2026-10-20.
- Fonte S2: `https://app.notion.com/p/b0cc2b324ede82d990330191e46b1249`, Gorrok (caçador), região/evento, corpo mecânico correspondente.
- **D0 local:** 2 páginas físicas consultadas; **definições independentes:** 1 (duas localizações espelhadas); **efeitos de dano explícitos:** 3 (Espada Curva 5d8, Adaga 1d4, Explosão de Terra 4d6 em área de 9m). **Bônus contextuais:** FF +7 e Aprimoramento Físico +15 dano/2d6 turnos. **Defesa documentada de Gorrok:** RD/resistência física 15. Esses números não provam atributos de uma vítima.
- D0–D9 globais permanecem PENDENTES; os três efeitos não incrementam automaticamente o censo global nem são nova amostra independente de calibração, pois a própria DMG-RANK v1.1 cita Gorrok em sua §6.

## 5. H3/H4: novo teste quantitativo exato e discriminante
- Hipótese: a mesma expressão nominal pode ser inviável após resistência; o ganho de bônus de dano é **não linear** quando existe `max(0, roll + bonus - RD)`.
- Desenho: 3 pools (5d8, 1d4, 4d6) × seis valores de RD TEST (0,10,15,20,25,30) × quatro cenários de bônus TEST (0,+7,+15,+22) = **72 cenários**, **um único cluster de origem**. +22 é mera combinação matemática; empilhamento FF/buff não homologado. Atividade não é combate VLAB, nem apresenta custo de PA, chance de acerto, crítico, economia de ação ou tipo de RD adequado ao elemento Terra.
- Oráculo matemático duplo: PMF por convolução dinâmica vs enumeração completa de `8^5`, `4`, `6^4` resultados; 72/72 médias pós-RD verificadas em fração racional sem discrepância. Sem independência humana externa.

| Pool físico | DME bruto | RD15, bônus0: E[pós-RD] | P(pós-RD > 0) | RD15, bônus+7: E | RD15, bônus+15: E |
|---|---:|---:|---:|---:|---:|
| Espada Curva 5d8 | 22,5 | 7,651672 | 91,156% | 14,500854 | 22,5 |
| Adaga 1d4 | 2,5 | 0 | 0% | 0 | 2,5 |

Observação: resultados condicionados a um acerto e à incidência de RD física 15 no alvo hipotético; nunca declarar dano médio por tentativa ou Vida efetiva. A aplicação de bônus+7/+15 é cenário condicional de elegibilidade e não afirma regra de stacking nem custo/ativação. A Explosão de Terra permanece coluna `ELEMENTAL_TERRA_RD_PHYSICAL_NOT_PROVEN`; seus resultados sob RD15 são matemática contrafactual, **não admissíveis para afirmar mitigação real**.

Sensibilidade adicional: para espada 5d8, RD30, E[pós-RD] sem bônus = 0,151672; com +7 = 1,819092. Uma soma nominal +7 corresponde aqui a aumento de apenas 1,667419 por acerto condicionado; proteção absorve o restante conforme distribuição. Para Adaga sob RD15, +7 não produz qualquer resultado positivo. Assim, modificação fixa de bônus é estado/de defesa-alvo dependente.

## 6. Diagnóstico aplicado à nova criação
- Espada Curva literal: `5d8`, intrínseco 22,5; faixa numérica Ouro Entrada = 22–28 segundo DMG-RANK §5. A ficha escreve O1, mas RE/FIP do efeito e classificação de item não foram autonomamente aprovados nesta ficha; comparabilidade estrita por RE/FIP = **PARCIAL**. A própria norma usa Gorrok como exemplo de calibração (§6): encaixe na banda não é verificação independente.
- Adaga `1d4` contém DME intrínseco 2,5 e exemplifica ação auxiliar/histórica sob RD elevada; não se conclui defeito ou erro de rank sem RI, RE, ação, custo e propósito.
- Explosão de Terra `4d6` (=14 por alvo afetado, antes de acerto/save, área de 9 metros) carece de ação/PA, geometria precisa, número de alvos e mecanismo de resistência; **PARCIAL**, não classificar como insuficiente por comparar DME de área com banda de alvo único.
- FF +7 é bônus EXTERNO; Aprimoramento Físico +15 é temporário, 2d6 turnos, ação/PA e regras de aplicação ausentes. Não somar ao DME intrínseco.
- Conclusão para novas criações: exigir ficha de perfil de defensor com limiares RD, P(dano positivo), esperança pós-RD, ação, custo e risco de inutilidade, além de DME base. Não alterar banda oficial com base neste cluster autorreferente.

## 7. Tratamento de exclusões e comparadores
- Admissíveis em matemática exploratória: 3 pools inequívocos, sem imputação de dados ausentes.
- Comparador ofensivo estrito cross-rank independente: **0 novos**. Duas páginas Gorrok = um mesmo cluster, não duas observações independentes.
- H3 distribuição e RD: TEST local robusto; H4 precisão/críticos: NÃO TESTADOS aqui, mantidos C15/C16/C17 sem mistura. H1 H2 H5 H6: sem nova promoção empiricamente concluída.
- C17 R71=684, R81=128 e R68=338 observações, preservadas fora do denominador C18. Não misturar episódios, sementes, coortes ou total de ações com amostras de criaturas.

## 8. Gates / governança / continuidade
- **Q-MATH local**: PASS matemático independente por algoritmos no mesmo executor, NÃO second coder e NÃO aceite global; 72/72.
- **Gates empíricos globais:** não promovidos. E01–E24 e D0–D9 global permanecem nos estados herdados C17, sem promulgação por este arquivo. A5–A8 HOLD; L002/L003 não reconciliados; R156 UNKNOWN-EFFECT, R138 HOLD, demais quarentenas intactas.
- Writer/INSTANCE/epoch/lease/fencing/STOP-ACK/RELEASE: não provados nesta execução; Notion original, Inbox e Diário **NO-WRITE**. Artefatos científicos somente Biblioteca privada da OP se upload e readback forem efetuados. Não reivindicar NAC-PASS canônico.
- **Decisão DMG-RANK v1.1:** MANTER. Sem nova candidata v2, sem retcon.

**FIRST-PENDING:** (i) byte readback real dos sete anexos F0-A5 e auditoria de versão/autoridade; (ii) comparador ofensivo CURRENT-CANON de família independente com RE/FIP, ação/PA e entrega completos.

**NEXT-5:** 1) encerrar prova física A5 sem alegar PASS prematuro; 2) encontrar família estrita cross-rank não usada na calibração v1.1; 3) avaliar hit/crit e pós-RD em fixtures completos quando fonte permite; 4) submeter contrato confirmatório de Chicote de Água somente via canal VLAB competente; 5) obter codificação humana/segunda instância independente e decisão de autoria para posterior gate.

**TARGET-REMAINDER:** F0 ainda 4/8; C18 ciência experimental material documentada, sem fase global finalizada. Os arquivos anteriores nunca serão sobrescritos. **NAC-PASS:** somente local técnico de consistência, sem claims administrativos.
