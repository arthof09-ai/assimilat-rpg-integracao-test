from collections import Counter
from fractions import Fraction
from itertools import product
import json,csv
from pathlib import Path
p=Path('/mnt/data/dmg_work')
# Independent exact approaches: convolution and brute-force enumeration of 8^5=32768 and 6^4=1296
cases={'Espada Curva':(5,8),'Adaga':(1,4),'Explosão de Terra':(4,6)}

def convolution(n,sides):
    c=Counter({0:1})
    for _ in range(n):
        nc=Counter()
        for v,count in c.items():
            for face in range(1,sides+1): nc[v+face]+=count
        c=nc
    return c

def exact(n,sides,bonus,rd):
    c=convolution(n,sides)
    denom=sides**n
    total_net=sum(max(0,v+bonus-rd)*num for v,num in c.items())
    p_pos=sum(num for v,num in c.items() if v+bonus>rd)
    return {'mean_raw':float(Fraction(n*(sides+1),2)+bonus),'mean_net':float(Fraction(total_net,denom)),'mean_net_fraction':str(Fraction(total_net,denom)),'p_positive':float(Fraction(p_pos,denom)),'p_positive_fraction':str(Fraction(p_pos,denom)),'max_raw':n*sides+bonus,'min_raw':n+bonus}

for n,sides in cases.values():
    a=convolution(n,sides);b=Counter(map(sum,product(range(1,sides+1),repeat=n)))
    assert a==b
rows=[]
for name,(n,sides) in cases.items():
    for rd in (0,10,15,20,25,30):
        for bonus in (0,7,15,22):
            # 7FF/15 buff/22 both are only explicit hypothetical activation scenarios, no authorization to stack
            e=exact(n,sides,bonus,rd)
            rows.append({'effect':name,'n':n,'sides':sides,'external_bonus_TEST':bonus,'RD_TEST':rd,**e})
with open(p/'C18_GORROK_PMF_EXATA_RD_SENSIBILIDADE.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print('n scenarios',len(rows))
for name in cases:
    print('\n',name)
    for rd in (0,15,20,30):
        print('rd',rd,[(bonus,round(exact(*cases[name],bonus,rd)['mean_net'],6),round(exact(*cases[name],bonus,rd)['p_positive']*100,3)) for bonus in [0,7,15,22]])
print('ORC boundary FIP reference: Ouro 22-28/29-35/36-44/45-52/53-62')
print('physical sword base mean', exact(5,8,0,0)['mean_raw'])
print('earth explosion mean', exact(4,6,0,0)['mean_raw'])
(p/'C18_GORROK_METODO.json').write_text(json.dumps({'source':'Gorrok O1 two mirrored pages 2026-09-30','unique_definitions':1,'source_pages':2,'rank':'O1 in body, RE/FIP not independently sourced','RD15':'on Gorrok defender, applied to hypothetical physical victim with Gorrok defense only, not to default recipient','explosion_type':'Terra, no verified physical RD application','calculation':'exact discrete convolution and independent cartesian-product enumeration','scenarios':len(rows),'scenario_axes':{'RD_TEST':[0,10,15,20,25,30],'external_bonus_TEST':[0,7,15,22]},'FF_bonus_7':'source documents FF+7 but exact scope unknown','buff_15':'source documents +15 to damage temporarily but scope, action and PA not given','stacking_22':'counterfactual only, not authorized','N_independent_items':1,'N_independent_design_families':1,'status':'EXPLORATORY_MODEL_ONLY'} ,ensure_ascii=False,indent=2))
checks=0
for name,(n,sides) in cases.items():
    outcomes=[sum(t) for t in product(range(1,sides+1),repeat=n)]
    for rd in (0,10,15,20,25,30):
        prev=-1
        for bonus in (0,7,15,22):
            v=sum(max(0,k+bonus-rd) for k in outcomes)
            from_brute=Fraction(v,len(outcomes))
            from_dp=Fraction(exact(n,sides,bonus,rd)['mean_net_fraction'])
            assert from_brute==from_dp
            assert from_dp>=prev
            prev=from_dp
            checks+=1
print('exact independent per-scenario checks',checks)
(p/'C18_ORACULO_REPLAY_72.json').write_text(json.dumps({'independent_scenario_replays':checks,'pmf_equal_cartesian_product':True,'post_rd_means_byte_exact_as_Fraction':True,'within_each_defender_RD_bonus_monotonic':True,'design_independence':'NO: same entity and correlated source copy','formal_gate':'Q-MATH_LOCAL_ONLY'},indent=2))
