#!/usr/bin/env python3
"""Read-only scientific correction: VZ normal weapon chassis include FF bonuses already."""
from __future__ import annotations
import os,csv,re,json,collections,hashlib
from fractions import Fraction
BASE=os.environ.get('C29_ERRATA_ROOT',os.path.abspath(os.path.join(os.path.dirname(__file__),'..')))
P=os.path.join(BASE,'publication');os.makedirs(P,exist_ok=True)
EVIDENCE=[
 {'legacy_case':'VZ02','character':'Darek','technique':'Corte de Falha','old_C29_formula':'10d10+1d8','old_DME':Fraction(119,2),'weapon_N_literal':'1d8+3','weapon_T_literal':'1d8+5','skill_pool':'10d10','correct_normal':'10d10+1d8+3','correct_N_mean':Fraction(125,2),'correct_T':'10d10+1d8+5','correct_T_mean':Fraction(129,2),'source_chassis_table':'Darek: dano N→T = 1d8+3 → 1d8+5','source_skill_table':'Darek: arma + 10d10'},
 {'legacy_case':'VZ07','character':'Rhovan','technique':'Corte de Fase','old_C29_formula':'10d10+1d6','old_DME':Fraction(117,2),'weapon_N_literal':'1d6+4','weapon_T_literal':'1d6+19','skill_pool':'10d10','correct_normal':'10d10+1d6+4','correct_N_mean':Fraction(125,2),'correct_T':'10d10+1d6+19','correct_T_mean':Fraction(155,2),'source_chassis_table':'Rhovan: dano N→T = 1d6+4 → 1d6+19','source_skill_table':'Rhovan: arma + 10d10'},
 {'legacy_case':'VZ08','character':'Rhovan','technique':'Tempestade de Um Golpe','old_C29_formula':'18d12+1d6','old_DME':Fraction(241,2),'weapon_N_literal':'1d6+4','weapon_T_literal':'1d6+19','skill_pool':'18d12','correct_normal':'18d12+1d6+4','correct_N_mean':Fraction(249,2),'correct_T':'18d12+1d6+19','correct_T_mean':Fraction(279,2),'source_chassis_table':'Rhovan: dano N→T = 1d6+4 → 1d6+19','source_skill_table':'Rhovan: arma + 18d12'},
]
def formula_mean(s):
 total=Fraction(0)
 for part in s.split('+'):
  if m:=re.fullmatch(r'(\d+)d(\d+)',part):total+=Fraction(int(m[1])*(int(m[2])+1),2)
  else:total+=int(part)
 return total
def exact_dist(s):
 counts={0:1}
 for part in s.split('+'):
  if m:=re.fullmatch(r'(\d+)d(\d+)',part):
   a,b=int(m[1]),int(m[2])
   for _ in range(a):
    nxt=collections.Counter()
    for x,c in counts.items():
     for v in range(1,b+1):nxt[x+v]+=c
    counts=nxt
  else: counts={x+int(part):c for x,c in counts.items()}
 return counts
def wcsv(name,rows):
 with open(os.path.join(P,name),'w',encoding='utf8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
def j(name,obj):
 with open(os.path.join(P,name),'w',encoding='utf8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
rows=[];rd=[];checks=[]
for x in EVIDENCE:
 a=formula_mean(x['old_C29_formula']);b=formula_mean(x['correct_normal']);t=formula_mean(x['correct_T'])
 assert(a,b,t)==(x['old_DME'],x['correct_N_mean'],x['correct_T_mean'])
 old=exact_dist(x['old_C29_formula']);new=exact_dist(x['correct_normal']);assert len(old)>0 and len(new)>0
 assert Fraction(sum(k*c for k,c in old.items()),sum(old.values()))==a
 assert Fraction(sum(k*c for k,c in new.items()),sum(new.values()))==b
 assert b-a in (3,4)
 rows.append({'legacy_case':x['legacy_case'],'character':x['character'],'technique':x['technique'],'original_C29_formula':x['old_C29_formula'],'original_C29_DME':float(a),'source_normal_weapon_chassis':x['weapon_N_literal'],'source_skill_pool':x['skill_pool'],'correct_normal_expression':x['correct_normal'],'correct_normal_DME':float(b),'delta_DME':float(b-a),'relative_delta_percent':round(100*float((b-a)/a),4),'conditional_transformed_chassis':x['weapon_T_literal'],'conditional_transformed_expression':x['correct_T'],'conditional_transformed_DME':float(t),'source_page_url':'https://app.notion.com/p/3f2c2b324ede812d8c21fe3afc4748b7','source_page_last_edited_at':'2026-10-07T23:57:53.511Z','source_detail':x['source_chassis_table']+'; '+x['source_skill_table'],'rank_FIP_label_unchanged':True,'nominal_v11_range_compliance_unchanged':True,'caveat':'Base weapon Dano N→T already contains the FF modifier; do not add FF again or import T without transformation state'})
 for rdf in [25,40,60,100]:
  def net(d):
   den=sum(d.values());return (Fraction(sum(max(v-rdf,0)*n for v,n in d.items()),den),Fraction(sum(n for v,n in d.items() if v>rdf),den))
  ea,pa=net(old);eb,pb=net(new)
  assert eb>=ea and pb>=pa
  rd.append({'case':x['legacy_case'],'hypothetical_RDF':rdf,'whole_pool_RDF_elegibility_verified':'NO; mathematical sensitivity only','old_post_RDF_mean':f'{float(ea):.9f}','corrected_post_RDF_mean':f'{float(eb):.9f}','delta_post_RDF_mean':f'{float(eb-ea):.9f}','old_P_positive':f'{float(pa):.9f}','corrected_P_positive':f'{float(pb):.9f}','source_attack_hit_probability':'UNKNOWN','combat_observed':'NO'})
 checks.append({'case':x['legacy_case'],'pass':True,'method':'two implementations: exact discrete polynomial convolution and independent symbolic expectation'})
assert len(rows)==3 and len(rd)==12
wcsv('C29_CORRECTED_FF_CHASSIS_THREE_CASES.csv',rows)
wcsv('C29_CONDITIONAL_RDF_SENSITIVITY_TWELVE_CELLS.csv',rd)
j('C29_FF_CORRECTION_REPLAY_TESTS.json',{'pass':True,'tested_compositions':3,'whole_distribution_convolutions':6,'conditional_RDF_sensitivities':12,'checks':checks,'source_by_page':'https://app.notion.com/p/3f2c2b324ede812d8c21fe3afc4748b7','baseline_original_C29_zip_sha256':'c5e261aacaa5227ed6ebeb8958baeda944613d43b7fe2a1272be930a964e1882','all_original_artifacts_preserved':True,'not_second_human_coder':True,'zero_canonic_writes':True})
print('PASS 3/3 corrections + 12/12 conditional RDF + 3 symbolic vs convolution checks')
