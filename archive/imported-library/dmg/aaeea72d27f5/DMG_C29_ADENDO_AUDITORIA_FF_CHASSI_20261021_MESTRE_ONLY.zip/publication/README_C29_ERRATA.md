# Read-only C29 FF chassis errata

Artifacts: CSV of three corrected combinations, twelve conditional defense sensitivities, exact test JSON and report. Recompute with `python work/verify_c29_ff_errata.py` (no web, Notion, external engine or database access required). This package **does not** include/reissue the original C29 main ZIP, C28 baseline or other C29 adendums; the immutable upstream C29 ZIP SHA256 is in the report and test metadata.

The original VZ source has its own version/authority; classifications are historical VZ-sandbox, not promoted to global. Publication is a corrective scientific append-only artifact and must never be distributed to the Party.
