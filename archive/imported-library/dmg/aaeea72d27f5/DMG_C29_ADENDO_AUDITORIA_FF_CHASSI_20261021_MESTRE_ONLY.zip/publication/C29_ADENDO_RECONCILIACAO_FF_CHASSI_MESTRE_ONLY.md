# ADENDO C29 — Auditoria corretiva de três composições de dano do VZ (FF no chassi)

**21/10/2026 · MESTRE-SIDE / TEST · `OP-DMG-CORPUS-EMP-01` · sem writer canônico**  
**Natureza:** CORREÇÃO ADITIVA AUDITADA, nunca sobrescrita de C29.  
**STATUS:** PASS matemático local; classificação normativa F0/F6, DMG-RANK e produção **INALTERADAS / HOLD**.

## 1. Como a divergência foi descoberta

Antes de emitir um novo C29, o preflight da Biblioteca encontrou os arquivos já existentes `DMG_C29_VZ_RE_FIP_F0_PLANO_SUPREMO_20261021_MESTRE_ONLY.zip` (SHA256 `c5e261aacaa5227ed6ebeb8958baeda944613d43b7fe2a1272be930a964e1882`), `PSV_DMG_C29_MESTRE_ONLY.md`, parecer, readback e dois adendos A6/A6T. O pacote C29 do outro fluxo permanece **a única publicação principal**; não foi sobrescrito nem duplicado.

Ao comparar o CSV `publication/C29_VZ_8_RE_FIP_EXPLICITOS.csv` contido naquele ZIP contra a [fonte VZ diretamente reaberta](https://app.notion.com/p/3f2c2b324ede812d8c21fe3afc4748b7), apareceu um problema de composição. O início da fonte define: **“O dano abaixo já soma o bônus de FF ativo de cada estado”**. A tabela #1 especifica os danos de arma `Darek 1d8+3 → 1d8+5` e `Rhovan 1d6+4 → 1d6+19` (N→T). A tabela #2 define o ataque `arma + 10d10` ou `arma + 18d12`. O CSV publicado no C29 havia empregado apenas `1d8` ou `1d6` como chassi, omitindo o bônus fixo fonte-verificado dos estados normais.

## 2. ANTES / DELTA / DEPOIS — três casos exatos

| Caso | Fórmula C29 anterior | DME anterior | Fórmula correta NORMAL (da fonte) | DME corrigido | Δ |
|---|---|---:|---|---:|---:|
| VZ02 Darek — Corte de Falha | `10d10+1d8` | 59,5 | `10d10+1d8+3` | **62,5** | **+3** |
| VZ07 Rhovan — Corte de Fase | `10d10+1d6` | 58,5 | `10d10+1d6+4` | **62,5** | **+4** |
| VZ08 Rhovan — Tempestade de Um Golpe | `18d12+1d6` | 120,5 | `18d12+1d6+4` | **124,5** | **+4** |

O delta equivale a **+5,04%**, **+6,84%** e **+3,32%** respectivamente nas médias brutas condicionadas ao acerto. **Importante:** esta correção **não adiciona FF novo** ao ataque, apenas restitui o FF que a própria linha de chassi já incorporava. É incorreto somar outro bônus FF sobre os valores corrigidos.

**Estados transformados, apenas se realmente ativados e permitidos:** Darek `10d10+1d8+5` = **64,5**; Rhovan Corte `10d10+1d6+19` = **77,5**; Rhovan Tempestade `18d12+1d6+19` = **139,5**. Não substituir estado N por T sem transformação validada, nem inferir que a técnica sempre esteja disponível no transformado.

## 3. Impacto sobre a análise científica publicada

**Nenhuma conclusão de encaixe de banda normal muda:** Darek e Rhovan Corte permanecem em Lendário Entrada **58–72**, e Tempestade em Lendário Alta **113–136** no confronto numérico não ajustado com DMG-RANK v1.1. Entretanto, a magnitude bruta estava subestimada e esse erro **pode mudar sensivelmente dano pós-defesa, frequência de dano positivo e razão DME/PA**. O erro, portanto, não é estético.

### Prova condicional de importância contra RDF 60

Somente como experimento contrafactual **se todo o pool fosse legitimamente mitigado pela RDF60** (a elegibilidade física dos dados mágicos NÃO foi comprovada), a distribuição exata dá:

| Ataque | Esperança líquida no C29 anterior | Esperança líquida corrigida | Probabilidade de dano positivo anterior → correta |
|---|---:|---:|---:|
| Darek Corte | 3,506709 | **5,132043** | 45,81% → **58,34%** |
| Rhovan Corte | 2,999442 | **5,083932** | 41,55% → **58,45%** |
| Rhovan Tempestade | 60,500022 | **64,500004** | 99,99896% → **99,99977%** |

Esses são **12 cenários exatos** para RDF hipotética 25, 40, 60 e 100, não combates executados. Eles demonstram por que o chassi integral deve ser preservado antes de estudar pós-RD; a categoria de dano dos dados adicionais deve ser autorizada separadamente. Nenhuma probabilidade de acerto foi inventada.

## 4. Teste, lineage e fronteira normativa

O algoritmo de correção `verify_c29_ff_errata.py` reconstitui as duas fórmulas por técnica a partir de literais congelados, calcula valor esperado por álgebra e por distribuição discreta completa, verifica os três deltas, três possibilidades de transformação e os 12 cenários de resistência. **3/3 casos e 12/12 células condicionais PASS; 6/6 distribuições reconstruídas**, sem editar a fonte.

- **Fonte primária:** [DAMAGE-RUNTIME-VZ-08](https://app.notion.com/p/3f2c2b324ede812d8c21fe3afc4748b7); editado `2026-10-07T23:57:53.511Z`; versão histórica autoral VZ v1.0, não norma global.
- **Baseline imutável:** C29 ZIP já na Biblioteca, SHA acima; adendos A6 60 páginas e A6T 28 técnicas não foram recriados.
- **Estado de competência:** mesmo RE/FIP histórico da técnica, sem promoção a RE global independente. Não confundir correção de cálculo com mudança normativa, escolha de versão ou reconhecimento de escritor.
- **Gate:** F0 **4/8 HOLD**, A5 originais **0/7 bytes**, A7/A8 **HOLD**. DMG-RANK v1.1 **inalterada**; Party/O Primeiro e VLAB **NO-WRITE**.
- **Independência:** os dois algoritmos matemáticos não equivalem a segundo codificador humano das fontes.

## 5. Continuidade e REPA

**LAST-VERIFIED-UNIT:** adendo corretivo matemático C29 contra a fonte VZ e o pacote C29 existente.  
**FIRST-PENDING:** futuro consumidor do C29 deve calcular estes três ataques com os valores corrigidos e preservar as versões anteriores como histórico; revisar materialidade da composição física/elemental antes de usar RDF em combate; recuperar bytes originais F0-A5 e auditor independente.  
**NEXT:** quando o legítimo Comestre responsável continuar o Plano Supremo, reconciliar o delta sem reexecutar C22–C29 e sem reescrever automaticamente arquivos/Notion originais. Nenhuma publicação principal ou objeto canônico concorrente foi criado.
