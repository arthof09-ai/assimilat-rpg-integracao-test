# PSV — DMG C11 / DIAGNÓSTICO EMPÍRICO DO SISTEMA DE DANO

**AS-OF:** 2026-10-19 · **OPERATION:** `OP-DMG-CORPUS-EMP-01` · **ENV:** MESTRE-SIDE ONLY · **Baseline oficial:** DMG-RANK-01 v1.1, INALTERADA · **F0 formal:** 4/8 · **PRODUCTION:** HOLD.  
**Tipo de checkpoint:** continuação científica POST-C10, sem outro motor, laboratório ou operação.  
**Autoridade do Mestre:** C11 restaura missão central pesquisa de equilíbrio; sem comissão para modificar regras/fichas/Party/VLAB. **Método:** DMG-METHOD-EMP-01; **taxonomia:** DMG-TAX-DATA-01; **aceite:** DMG-QA-ACCEPT-01; **norma:** DMG-RANK-01 v1.1, fisicamente reabertas por conector Notion Mestre em 19/10/2026.

## Estado ANTES → DEPOIS

| Denominador | ANTES C10 | DEPOIS C11 (recorte delimitado) |
|---|---|---|
| Missão principal | consultor até reação/Defender/Casulo, corpus não convertido em diagnóstico | diagnóstico científico por fonte e estrato; nenhuma regra mudada |
| Baseline C10 | ZIP 117.787 bytes, SHA256 `75c4ed7f19f254adc0f64c0a70c409083fe112eb088a4db1af9250ddadf954cc` | byte-fingerprint C10 revalidado; original intocado |
| Corpos históricos | A6 571 UUIDs; C04 29 páginas; C05 +35 páginas; dados C07–C10 | reutilizados, não recenseados; 15 páginas **reabertas** (0 fontes inéditas reivindicadas) |
| Estratos e efeitos analisados cientificamente neste ciclo | comparações táticas e fontes pontuais, sem nova matriz C11 | 4 estratos, **19 definições selecionadas / 15 UUIDs / 40 contribuições básicas** |
| Amostra Bronze5 | duas páginas C04, outra C05 | 3 páginas; 6 efeitos brutos; identidade Escorpião CONFLICT |
| Amostra Prata1 | 6 efeitos rank concordante C04 | 6 efeitos de 6 fontes, com análise da Concha e sensibilidade leave-one-out |
| ON5 armas | golpes catalogados no consultor | 4 itens Lendários propostos com intrínseco, FIP, FF, riders e custo segregados |
| ON5 magias | Feryn/Eristan/Veyun catalogados | 3 ações/3 fontes com tipo, resolução e PA explicitamente distintos |
| Ciência normativa | v1.1 como fallback/ referência | 4/4 itens propostos em banda Lendário ampla, 3/4 alertas FIP condicionais, nada promovido |
| Ciência futura | ideias genéricas anteriores | 5 hipóteses pré-registradas e testes especificados com lacunas mecânicas |
| F0 formal | 4/8 | **4/8** |

## Dez etapas C11 — entrega por produto e evidência

**ETAPA 1 — PASS documental:** OP, DMG-RANK, METHOD, TAX, QA reabertos; separados RN/STAR × RE/FIP; decisão do Mestre prioriza ciência. Evidência: `C11_PRE_REGISTERED_SCOPE.json`, `C11_DIAGNOSTICO_EQUILIBRIO_EMPIRICO_MESTRE_ONLY.md` e Notion.

**ETAPA 2 — PASS de recuperação delimitada:** C04 SHA `4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629`, C05 SHA `05dbf2e77beed44430109aa54ebc0c83d373d170d86d6a6c753d574636c088dc`, C10 SHA acima, CRC PASS; L002/L003 históricos não obtidos como matrizes binárias (HOLD). Não unir definições, páginas, ocorrências ou coortes VLAB. Evidência: `C11_SOURCE_SCOPE_MANIFEST.json`, `source_snapshots/`.

**ETAPA 3 — PASS com elegibilidade delimitada:** quatro estratos A P1 bestas estritas n6, B Bronze5 n6 efeitos/3 páginas, C ON5 armas Lendário propostas n4, D ON5 magias n3 não homogêneas. Efeitos C05 Prata1 com ancestral discordante excluídos; canal CURA não entrou. Evidência: `C11_19_EFFECTS_SOURCE_SCOPED.csv`, `C11_STRATA_HETEROGENEITY_AND_SENSITIVITY.json`.

**ETAPA 4 — PASS matemático:** 19 PMFs exatas; variâncias, suporte, mediana, quartis, parcelas de atributo, dado e fixo; 40 componentes básicos (dados agrupados + atributo/fixo), 83 dados individuais nas 19 expressões se roladas uma vez cada (NÃO 83 eventos observados). Motor C05 inalterado. Evidência: `c11_empirical_diagnosis.py`, `src/experimental_damage_calc.py`, `C11_MATH_PMF_SUMMARIES.json`.

**ETAPA 5 — PASS científico selecionado:** Prata1 n6 média33,6667, mediana32,25, intervalo31–40,5; sem Concha média32,3 n5. Bronze5 n6 média24,0833, mediana27, intervalo11,5–28,5; no mesmo Escorpião Ártico Rabada26,5 vs Corte11,5. Identidade parent/body CONFLICT Escorpião de Diamante/Ártico. 12/12 naturais escolhidos atributo contribui >50% do bruto; não estimar população. Evidência: `C11_STRATA_HETEROGENEITY_AND_SENSITIVITY.json`, `C11_NOTION_MESTRE_15_READBACK.json`.

**ETAPA 6 — PARTIAL/HOLD por pares:** contraste descritivo Bronze5 vs Prata1 escolhido; nenhuma atribuição causal de progressão por RN/relação item/efeito, nenhum par família/mesmo RE/FIP compatível Bronze5→Prata1. Ouro/Ouro Negro/Lendário global HOLD. Cinco fórmulas Prata1 de C05 com rank ancestral discordante não entram; uma linha de cura adicional excluída. Evidência: `cross_rank_frontiers` em `C11_STRATA_HETEROGENEITY_AND_SENSITIVITY.json`.

**ETAPA 7 — PASS científico condicionado:** Varok bônus bruto+39/60PA uma vez cena; Iskiel +27,5/45PA quando voo20m/acerto uma vez turno; Feryn +22,5/45PA uma vez cena; Arveth +33/55PA uma vez cena. Razões de bônus bruto/PA (0,50–0,65) não são taxas canônicas nem dano pós-RD ou por tentativa. Cenários de pico/sustain para N=1,3,5 sucessos distinguem orçamento. Fontes CRAFT/PA não suplantadas. Evidência: `C11_SOURCE_PAIRED_PA_MARGINAL.csv`, `C11_BURST_VS_SUSTAIN_RIDER_WINDOWS_TEST.csv`.

**ETAPA 8 — PASS nominal / HOLD balanceamento normativo:** quatro armas Lendárias PROPOSTAS com DME intrínseco80,66,5,68,60, todas na banda ampla58–160 da v1.1; Varok FIP Baixa80 dentro73–90; Iskiel FIP Média66,5 vs91–112; Arveth FIP Baixa68; Feryn FIP Baixa60. **3/4 alertas de subfaixa sem rider**, não declarar erro (rider/frequência/PA/controle e promoção PR-ITEM incertos). Em Iskiel, rider condicional eleva de 66,5 para94 no único disparo elegível sem FF. Normativa v1.1 intacta. Evidência: `C11_LENDARIO_FIP_DIAGNOSTIC_NOT_ADJUDICATION.csv`, Notion Mestre, `C11_BURST_VS_SUSTAIN_RIDER_WINDOWS_TEST.csv`.

**ETAPA 9 — PASS hipótese / HOLD execução VLAB e holdout:** cinco hipóteses falsificáveis e prioridades de evidência; A7 0/8 reservas cegas não reusadas. Novo pedido a VLAB somente após eliminar duplicação R161–R170 e assegurar fonte mecanicamente admissível. Evidência: `C11_PRE_REGISTERED_SCOPE.json`, relatório científico e roteiro em seu capítulo Hipóteses.

**ETAPA 10 — PASS técnico local, PASS científico delimitado, HOLD formal:** relatório utilizável pelas cinco perguntas A–E, 15 fontes reabertas, 19 efeitos e auditoria matemática implementada independentemente (ver recibo), reprodução sem caminho absoluto, ZIP autenticado. A ciência nova é interpretação da comparabilidade e dos orçamentos, não outro resolvedor. Evidência: `C11_DIAGNOSTICO_EQUILIBRIO_EMPIRICO_MESTRE_ONLY.md`, `C11_FIVE_MESTRE_QUESTIONS_REPRODUCED.json`, `C11_INDEPENDENT_MATH_ORACLE_PASS.json`.

## Causalidade, independência e coortes observacionais

- A Concha 40,5 > Mamute34 em BRUTO, mas dados puros 10,5 < Mamute12, **inversão por camada externa FOR**. O mesmo ocorre Arveth68 > Feryn60 em DME item, mas Arveth79 < Feryn83 equipado **por FF**. Evidência de potencial erro na leitura, não de regra defeituosa.
- VLAB R162/R169 permanecem coortes **separadas**, com 154/137 recibos e 9/5 RUN. R162 pós-RD11870, Vida11808, overkill62; R169 pós-RD11831, Vida11563, overkill268. `C11_VLAB_SEPARATE_COHORT_RECEIPT.json`; nenhum replay e nenhuma dupla contagem. Não são dados de calibração universal por rank.
- A DMG-RANK v1.1 define explicitamente banda **intrínseca do efeito**, não dano bruto do portador; critério de elegibilidade para confronto sempre distingue RE de RN/RI/FIP. Uma ação AOE, um ataque físico e descarga mágica são modalidades distintas.

## Leitura das fontes, QA e conflitos

**SOURCE_SCOPE:** 15/15 UUIDs existentes com last-edited do Notion Mestre reabertos em 19/10; os registros C04/C05 são históricos recuperados e não foram sobrescritos. Uma página de corpo “escorpião Ártico” tem ancestral Escorpião de Diamante; outra de mesmo nome tem ancestral Escorpião Ártico. Estado `CONFLICT_IDENTITY`. Outra Concha inanimada possui elegibilidade de ataque `PENDING`. Sem escrever correções em Bestas.

**MISSING:** L002/L003 como ZIP com tabelas de pertencimento; F0 4/8; A5 0/7 histórico; A7 0/8 cego; A8 writer/lease/epoch/ACK ausentes. Não atribuir melhor qualidade a um corpus por tamanho sem controlar seleção.

**Q-COVERAGE:** PARTIAL; **Q-CODEBOOK:** PARTIAL (normalização Vida vs CURA testada, aliases pendentes); **Q-MATH:** PASS local para 19 PMFs/exatos e oráculo separado; **Q-TARGET:** HOLD muitas ações Beast sem precisão, PA, RD; **Q-HOLDOUT:** HOLD blindagem formal; **Q-TRACE:** PASS local para os 19 casos e fontes; **Q-CHANGE-SAFETY:** v1.1 não editada; **NAC-PASS-02:** PASS técnico delimitado, não PASS normativo.

## Operações de produção e autoridade

**NO-REPEAT:** A6-571, grafos C04/C05, C05–C10, R160/R162/R169 e respectivos SQLite originais intocados; nenhuma nova operação, Inbox, Diário ou motor; script apenas análise estatística da evidência. **NOTION_WRITES=0; PARTY_WRITES=0; FIRST_WRITES=0; SQLITE_WRITES=0.** Apenas Biblioteca original se publicada/verificada.

**LAST-VERIFIED-UNIT:** análise C11 de 19 efeitos, código, matriz e testes reproduzidos sobre cópias físicas; checkpoint congelado mediante publicação e readback a registrar separadamente no comprovante final.

**FIRST-PENDING:** obtenção de pares fonte-admissíveis da **mesma família** para Bronze5→Prata1 com classificação RE/FIP e contextos de dano; concorrentemente, adjudicação de identidade Escorpião de Diamante/Ártico e rigor do DME de itens propostos com rider.

**DENOMINATORS:** 15 páginas únicas reabertas, 19 efeitos, 40 componentes de fórmula, quatro estratos, 12 efeitos naturais em 9 páginas (6 P1 +3 B5), quatro armas propostas em quatro páginas, três magias ON5 em três páginas com sobreposição de uma página arma, zero páginas inéditas globalmente, zero novas lutas. Lotes históricos e global D0 não contabilizados como recuperados.

**CONFLICTS:** nomes/famílias Escorpião; rank Prata1 ancestral de cinco efeitos C05; Concha inanimada; FIP de itens ON5 propostos; dano físico/elemental misto; RD/PA e frequência sem adjudicação completa; não somar FF nem atributos duas vezes.

**UNKNOWN-EFFECT:** VLAB R156 permanece quarantined; R138 espacial HOLD. Nenhuma vitória/derrota inventada.

**NEXT-5:** (1) reconciliar identidade de duas páginas Escorpião por autoridade documental/Mestre, sem escrita não autorizada; (2) buscar pares Bronze5→Prata1 da mesma família com RE e tipo/ação pareados; (3) aumentar n por estrato e família até robustez básica exigida DMG-METHOD, sem contaminar holdout; (4) auditar quatro itens Lendários propostos com orçamento completo e janela PA; (5) usar VLAB para cenário **novo** somente depois de documentação mecânica suficiente, sem repetir R161–R170.

**TARGET-REMAINDER:** F0–F18, A5 0/7, A7 0/8, A8 sem titular legítimo, L002/L003, D0 census, E01–E24, oito gates transversais, estudo tipo×rank global, DMG v2 candidate-only com tabela de impacto e NAC-NORM/decisão Mestre.

**AUTHORITY/WRITER STATE:** leitura Notion Mestre, análise local TEST autorizada; nenhum writer, lease, epoch, fencing, ACK, aprovação de v2 ou permissão produtiva herdados; nenhum acesso Party/O Primeiro. Não reivindicar auditor externo cego.

**NAC-PASS-02:** gate proporcional sobre arquivos finais: matemática (oráculo independente de código), proveniência (UUID + hashes), integridade ZIP, extração limpa, readback da Biblioteca. RESULTADO TÉCNICO local PASS se comprovado em recibos; PLAN SUPREMO/F0 e homologação normativa **HOLD**. F0 permanece 4/8, DMG-RANK v1.1 inalterada.

**Conclusão científica:** há diagnóstico empírico de distorções de camada, seleção e janela; não existe base para novos multiplicadores universais ou renormalização de dano canônico. O sistema oficial mantém precedência.
