# DMG C11 — Primeiro diagnóstico empírico de equilíbrio do dano

**AS-OF:** 2026-10-19 (America/Recife)  
**OPERATION:** `OP-DMG-CORPUS-EMP-01` | **MESTRE-SIDE ONLY** | **Baseline oficial:** DMG-RANK-01 v1.1 INALTERADA | **F0:** 4/8 | **Produção:** HOLD  
**Governo científico:** OP-DMG-CORPUS-EMP-01, DMG-METHOD-EMP-01, DMG-TAX-DATA-01, DMG-QA-ACCEPT-01 e DMG-RANK-01 v1.1 fisicamente reabertos.  
**Fonte histórica autêntica:** C10 SHA-256 `75c4ed7f19f254adc0f64c0a70c409083fe112eb088a4db1af9250ddadf954cc`. C04/C05 autenticados (ver README).

## Síntese executiva — o que a evidência permite concluir

1. **Os atributos externos dominam o dano nominal das Bestas neste recorte escolhido.** Nos 12 efeitos naturais Bronze 5/Prata 1 analisados, a participação média do atributo na média bruta é 80,24%; a mediana das 12 participações é 78,35%; **12/12** têm fração de atributo maior que 50%. Isto é a descrição do conjunto **selecionado**, não a população de Bestas. Por esse motivo, o dano publicado da ficha não é equivalente à magnitude intrínseca de efeito da DMG-RANK.
2. **Um ataque pode ser o maior nominal e não o maior intrínseco.** A Concha Marinha Luminosa (`3d6+FOR30`) rende DME bruto 40,5 contra 34 do Mamute Antigo (`2d6+2d4+FOR22`), mas os dados isolados rendem 10,5 versus 12. A ordenação inverte ao remover os atributos. Diferença bruta de +6,5 a favor da Concha; diferença da parcela de dados de +1,5 a favor do Mamute. A capacidade real de a Concha atacar permanece uma ressalva de elegibilidade.
3. **O estrato Bronze 5 não é uma amostra homogênea.** O Escorpião Ártico tem Rabada 26,5 versus Corte 11,5, diferença 15 causada principalmente por DES24 versus FOR8. Outra página, sob a família Escorpião de Diamante, se nomeia no corpo “escorpião Ártico”; duas páginas/UUIDs não demonstram necessariamente duas espécies independentes.
4. **Quatro armas Lendárias PROPOSTAS ON5 cabem na banda Lendária ampla da norma (DME intrínseco 58–160), mas três ficam abaixo de sua subfaixa FIP nominal quando o poder condicionado não é contado.** O arco de Iskiel, FIP Média, tem DME intrínseco 66,5 versus 91–112, diferença 24,5 para o piso. Com o bônus condicional +5d10, um disparo elegível teria 94 de DME de item antes de FF, RD e precisão. Isso não prova desequilíbrio nem corrige a FIP: custo, voo e frequência importam.
5. **Não há evidência neste recorte para recalibrar coeficientes universais de Bronze a Lendário.** RN da entidade e estrelas NÃO determinam automaticamente RE e FIP do efeito; não há pares trans-rank admissíveis suficientes nem atribuição completa de tipo, PA, precisão, defesa e janela temporal. As propostas são hipóteses investigativas, não DMG v2.

## Escopo, unidade estatística e denominadores

| Estrato | Páginas-fonte únicas | Definições de efeitos Vida | Regra de inclusão |
|---|---:|---:|---|
| A — Bestas Prata 1 | 6 | 6 | título, corpo e ancestralidade de rank concordantes no arquivo C04; uma fórmula de Vida por fonte |
| B — Bestas Bronze 5 | 3 | 6 | duas fontes C04 + uma C05; cada uma com duas habilidades; colisão de alias conservada |
| C — Armas equipadas de NPCs ON5 | 4 | 4 | cálculo **intrínseco** de item Lendário e FIP documental; equipamentos MESTRE-SIDE PROPOSTOS |
| D — Magias ON5 | 3 páginas, das quais 1 já em C | 3 | fontes específicas com PA; entregas/defesas diferentes, não tratadas como uma população homogênea |
| **União única** | **15 UUIDs** | **19 efeitos** | 40 contribuições de fórmula (termos de dados + atributos ou bônus fixos), 83 dados individuais por execução conceitual das 19 definições |

As 15 folhas foram reabertas no Notion Mestre em 2026-10-19, mas não são novas descobertas globais. O corpus histórico recuperado C04 mantém 29 páginas/37 efeitos, C05 mantém 35 páginas/58 efeitos; não concatenar definições e ocorrências heterogêneas. A6 571 UUIDs é união estrutural histórica congelada, não censo mundial. L002/L003 não foram localizados como ZIPs binários na pasta da operação. A7 0/8 holdouts cegos, A5 0/7 readbacks binários históricos, A8 sem writer/lease/epoch/ACK; nenhuma fase formal promovida. Os 19 efeitos não são uma amostra aleatória; a unidade natural é definição agrupada por UUID/família.

## Estrato A — Prata 1 de Bestas: seis fontes concordantes

| Entidade (nome de origem; aliases sujeitos a adjudicação) | Habilidade | Fórmula | Dados isolados (média) | Atributo | Bruto médio |
|---|---|---|---:|---:|---:|
| Águia Arranha Céu | Raio paralisante | `1d4+INT30` | 2,5 | 30 | 32,5 |
| Lupusventus | Patada | `2d6+FOR25` | 7 | 25 | 32 |
| Tigris Sombrio / família Tigre Dente de Sabre | Presas Fantasmais | `2d6+FOR24` | 7 | 24 | 31 |
| Gambá Demoníaco | Arranhão Putrificador | `2d6+DES25` | 7 | 25 | 32 |
| Mamute Antigo | Chifrada | `2d6+2d4+FOR22` | 12 | 22 | 34 |
| Concha Marinha Luminosa | Mordida | `3d6+FOR30` | 10,5 | 30 | 40,5 |

**Resumo descritivo:** n=6 fontes/n=6 efeitos; mínimo 31; máximo 40,5; média 33,6667; mediana 32,25; IQR por quantis discretos 2; MAD 0,75. Sem Concha (somente sensibilidade, não exclusão furtiva), n=5, intervalo 31–34; média 32,3; mediana 32. Ela eleva a média selecionada em aproximadamente **1,3667**. O valor mais alto é explicado pelo bônus FOR30 + três dados, mas a aptidão da Concha inanimada para executar Mordida, seu acerto, sua ação e sua RD alvo permanecem desconhecidos. "Outlier bruto" ≠ "erro de balanceamento". Os estados de paralisia do Raio/Arranhão/Presas não recebem valor de dano inventado.

Comparação exata em rolagens independentes, brutas e TEST: Arranhão Gambá supera Chifrada Mamute com probabilidade 1339/5184 ≈25,829%; Mamute supera Arranhão com 125/192 ≈65,104%; empate 235/2592 ≈9,066%. **Isso não representa P(acerto), P(vitória) nem resultado de combate.**

## Estrato B — Bronze 5: seis efeitos de três páginas, dependências explícitas

| Página/família | Efeito | Bruto médio | Atributo aplicado |
|---|---|---:|---:|
| Escorpião de Diamante, corpo “escorpião Ártico” | Rabada | 28 | FOR22 |
| Mesma página | Corte | 28,5 | DES25 |
| Azuragon | Jato de Bolhas | 27,5 | INT24 |
| Mesmo Azuragon | Cauda de Coral | 22,5 | DES19 |
| Escorpião Ártico (outra UUID) | Rabada | 26,5 | DES24 |
| Mesmo Escorpião Ártico | Corte | 11,5 | FOR8 |

Resumo **por efeito, não por espécie independente**: n=6 efeitos, 3 páginas; média 24,0833; mediana 27; intervalo 11,5–28,5; IQR 5,5; MAD 1,25. O Corte11,5 é a cauda baixa da distribuição, mas na própria ficha do Escorpião Ártico tem explicação aritmética (FOR muito menor que DES). Nenhum valor de PA/precisão/posição foi inferido. Identidade da página Escorpião de Diamante permanece conflito, não deduplicação silenciosa. Duplicar seis efeitos como seis espécies inflaria artificialmente a amostra.

## Estrato C — Armas de NPCs ON5 com Rank de Item Lendário

**Autoridade:** [DMG-RANK-01 v1.1](https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e), banda Lendário ampla 58–160 de DME **intrínseco**. FIP Baixa 73–90; FIP Média 91–112. Materiais e equipamentos das fichas de encontro são **PROPOSTOS Mestre-side**, não itens oficialmente materializados em acervo.

| Fonte | FIP | DME intrínseco do item | Dano equipado após FF | Bônus adicional condicionado | Desvio do piso FIP (sem rider) |
|---|---|---:|---:|---|---:|
| Varok — Machado Raiz-Ferro | Baixa | 80 | 103 (+23 FF) | +6d12 média39 / 60PA, 1/cena após acerto | 0 |
| Iskiel — Arco da Asa Rasgada | Média | 66,5 | 87,5 (+21 FF) | +5d10 média27,5 /45PA, voo20m e acerto, 1/turno | -24,5 |
| Arveth — Bastião | Baixa | 68 | 79 (+11 FF) | +6d10 Terra média33 /55PA, 1/cena | -5 |
| Feryn — Presas | Baixa | 60 | 83 (+23 FF) | +5d8 Vento média22,5 /45PA, 1/cena | -13 |

**4/4** intrínsecos cabem na banda ampla Lendária, **3/4** ficam abaixo do piso FIP nominal antes de rider. Isto é um alerta **de referência parcial** e NÃO um diagnóstico de erro: o orçamento da norma considera o efeito/ação completa, controle, custo, entrega e frequência. A diferença Iskiel de 24,5 é investigação prioritária, não motivo para elevar o arco 24,5 pontos automaticamente. O tipo misto Vento/perfurante não autoriza aplicação automática de RD física ao todo.

**Inversão por FF:** a lança intrínseca de Arveth (68) supera as Presas de Feryn (60), mas o dano equipado se inverte: Feryn 83 supera Arveth 79. FF é camada externa, não pode contaminar o benchmarking de DME intrínseco.

### Pico versus sustentação: hipóteses de janela, não novas regras

Na janela TEST com **um** acerto elegível, intrínseco + rider usado uma vez: Varok119, Iskiel94, Arveth101, Feryn82,5. Para uma janela com **cinco acertos bem-sucedidos** e rider **uma única vez**: Varok87,8, Iskiel72, Arveth74,6, Feryn64,5 por acerto em média. Se Iskiel efetivamente voar 20m e tiver cinco turnos elegíveis, ele **poderia** usar cinco Mergulhos, mantendo 94 por disparo, a custo de 225 PA extras. Essas são janelas alternativas, não cenas VLAB nem autorização para assumir cinco acertos, cinco turnos, recursos ilimitados ou regra FIP por janela. Elas demonstram que classificar uma arma só por seu ataque-base ou só por seu pico pode produzir leituras opostas.

## Estrato D — Magias ofensivas de ED ON5, heterogêneas

| Fonte | Entrega | DME bruto por alvo antes da defesa | PA/uso | Bruto/PA/alvo em TEST sem salvaguarda/RD |
|---|---|---:|---:|---:|
| Feryn, Turbilhão Cinzento | Cone de 8m; Reflexo versus Luta `4d6+92` | 57,5 | 60 | 0,9583 |
| Eristan, Tempestade de Esporos | Área raio 5m; Fortitude CD76 | 65 | 80 | 0,8125 |
| Veyun, Cetro da Prisão Prismática | Alvo único; Reflexo CD72 | 70 | 65 | 1,0769 |

PA é custo por **conjuração**, não por alvo; entregar uma área a dois alvos pode alterar o total plausível. A dificuldade de Reflexo/Fortitude difere, a RD elemental competente não foi demonstrada para todos os alvos, e o arredondamento de metade ímpar permanece não adjudicado. A maior razão bruta/PA de Veyun **não** prova vantagem em batalha nem desbalanceamento sobre Feryn e Eristan. A magia do Cetro exclui FF por cláusula específica apesar de glosa contraditória.

## Fronteira Bronze 5 → Prata 1 e insuficiência de progressão

O resumo numérico escolhido fornece Bronze5 média bruta 24,0833 versus Prata1 33,6667 (diferença nominal +9,5833), mas Bronze possui 6 efeitos agrupados em apenas 3 páginas e conflito de identidade; Prata tem 6 efeitos de 6 páginas. Não há comparação por família/mesmo efeito com RN, estrela, RE, FIP, atributo, entrega, ação, RD e PA pareados. Não é estimativa causal da evolução Bronze→Prata. Nenhuma conclusão populacional está autorizada sobre Ouro, Ouro Negro ou Lendário a partir dos estratos qualitativamente diferentes ON5.

Cinco efeitos C05 com rótulo+corpo Prata1 têm ancestralidade discordante; média exploratória 39,7, mas foram **excluídos** do estrato estrito. Misturá-los produziria 36,4091, alteração artificial de +2,7424 sem mudar o sistema. Uma sexta linha com rótulo Prata1 era **CURA**, não dano de Vida; foi detectada e excluída durante controle do codebook. Não atribuir ao universo Prata1 nenhuma das seis linhas inadequadamente.

## Aderência empírica à DMG-RANK-01 v1.1: o que se sustenta

- **Estrutura e separação:** as fontes sustentam fortemente a necessidade do contrato normativo de separar RN, RE, RI, FIP, FF, atributos e os riders. Demonstrada inversão de ranking ao separar atributo ou FF.
- **Banda Lendária ampla 58–160:** quatro itens Lendários de fichas propostas examinados têm DME intrínseco dentro. É conformidade nominal **nesses quatro casos**, não validação estatística da banda geral.
- **Subfaixas FIP:** 3/4 itens propostos abaixo do piso sem rider, mas suas ativações pós-acerto explicam parte do orçamento. **NECESSITA AVALIAÇÃO DE ITEM COMPLETO**, não acusação de erro oficial.
- **Bandas Bronze, Prata, Ouro, ON, Lendário universais:** **INDETERMINADO** nesta pesquisa para efeitos naturais, pois RN/estrela do portador não é RE; nem todos os modificadores externos estão segregados e faltam pares controle entre ranks. Comparar bruto de Besta com piso/teto RE seria erro metodológico.
- **PA/ação, área e riders:** documentação confirma diferenças qualitativas; não há comparação controlada suficiente para certificar porcentagens recomendadas na norma.

## Hipóteses priorizadas para futura candidata — nenhuma alteração normativa proposta agora

| Hipótese | Evidência | Predição falsificável | Dado/ensaio necessário | Estado |
|---|---|---|---|---|
| H1 — Atributos explicam grande parte da heterogeneidade nominal | 12/12 efeitos naturais escolhidos com atributo >50% do bruto; Concha/Mamute invertem ranking ao remover atributo | Nos próximos estratos fonte-matched, remover camada do usuário altera ordenação de vários pares | pelo menos n≥10 famílias elegíveis por célula tipo×RE/FIP, fontes físicas independentes e dados de atributos/hit | PROPOSTO TESTÁVEL |
| H2 — Assimetria local no Escorpião é principalmente atributo, não dados | Rabada26,5 vs Corte11,5; DES24 vs FOR8 | Sob mesma ação/hit/RD e sem riders, Rabada mantém dominância, salvo contrapeso documentado | precisão, tipo, condição, alcance e economia de ação de ambos | PROPOSTO TESTÁVEL |
| H3 — Posição FIP precisa ser interpretada com orçamento de item completo e janela | Iskiel base66,5 < FIP Média91 mas base+rider94 no tiro elegível | classificação do item pode inverter conforme rider/uso/frequência, não bastando bruto de um tiro | contratos de aplicação por cena/turno, pares de itens de mesma FIP e situação | PROPOSTO TESTÁVEL |
| H4 — PA não tem taxa universal bruta/PA extrapolável | deltas riders 0,50 a 0,65 bruto/PA, três magias 0,8125–1,0769 bruto/PA por alvo | ordem de eficiência varia com hit/save/RD, alvos e janela temporal | fontes de PA competentes CRAFT, alvos e RD, eventuais cenas VLAB adicionais **não cobertas R170** | PROPOSTO TESTÁVEL |
| H5 — Conflitos de rank/identidade deslocam a amostra | cinco efeitos P1 históricos com ancestral discordante; duas páginas bronze com mesmo nome corporal | revisão cega por família produzirá amostra distinta da seleção textual automática | árbitro para identidade, fonte RN/RE/FIP, revisão dupla; preservar oito holdouts A7 blindados | HOLD DOCUMENTAL |

Não se propõem coeficientes numéricos universais de uma DMG-RANK v2. Candidatas futuras exigem impact table, grupos disjuntos por família, grupos reserva para auditor cego e regressão sobre baseline imutável antes dos gates NAC-NORM.

## Cinco consultas que o Mestre já pode fazer ao DMG

**A — “Quais Prata1 parecem distantes?”** A Concha (40,5) é extrema em bruto contra a mediana32,25, mas a camada de FOR30 e a elegibilidade inanimada explicam por que não se deve alterar dano. Sem Concha, os outros cinco estão entre31 e34, sem inferência populacional.

**B — “Quais ON5 destoam?”** O arco de Iskiel é FIP Média e tem intrínseco66,5, abaixo do piso nominal91; com Mergulho +27,5 seria94 quando as condições forem atendidas. Desvio candidato a estudo, **não erro confirmado**. Varok intrínseco80, Arveth68 e Feryn60 têm FIP Baixa; riders/custos impedem comparação automática.

**C — “O PA compensa o acréscimo?”** Varok +39 por60PA, Iskiel +27,5 por45PA, Arveth +33 por55PA, Feryn +22,5 por45PA, todos condicionados ao acerto, com limites distintos; ordens de eficiência pós-RD desconhecidas. Não é tarifa universal de dano por PA nem comparação direta com dano de magia em área.

**D — “O que a v1.1 acerta?”** Separar camada intrínseca, atributo, FF, FIP e entrega evita dois erros verificáveis de comparação. Os quatro itens propostos cabem na banda Lendária ampla; n=4 não comprova validade universal ou percentuais de ajuste.

**E — “O que melhorar?”** Priorizar a **separação explícita bruto/intrínseco/burst/sustain na pesquisa e pré-cálculo**, adjudicar identidade, atribuir RE/FIP de efeitos por fonte competente, recuperar pares legítimos de fronteira de classificação e completar hit/RD/PA antes de ajustar bandas. Não há justificativa para alterar a DMG-RANK v1.1 neste ciclo.

## Dependência do VLAB e ciência observacional

As coortes **R162 corrigida (154 recibos, 9 RUN, pós-RD 11.870, Vida retirada 11.808, overkill 62)** e **R169 nova (137 recibos, 5 RUN, pós-RD 11.831, Vida retirada 11.563, overkill 268)** foram lidas e recalculadas aritmeticamente **em registros separados**. Elas demonstram que efetividade e overkill exigem evidência de estado, não que uma técnica seja superior por rank. Não há 291 ensaios independentes, reexecução de batalha ou resultado oficial novo. A ponte científica usa o VLAB para experimentos futuros somente quando as fontes e cenários necessários ainda não constarem de R161–R170.

## Fraquezas científicas e bloqueios reais

- **Q-COVERAGE:** faltam censo D0 e matrizes L002/L003 binárias para inferência populacional; não inventar percentuais de cobertura.
- **Q-CODEBOOK:** aliases conflitantes e efeitos que somam cura/dano ou Alma precisam filtragem; as seis entradas impróprias de sensibilidade Prata1 foram excluídas do estrato.
- **Q-TARGET:** acerto, RD por tipo, localização, ação e PA frequentemente ausentes nas Bestas; sem dano por tentativa universal.
- **Q-HOLDOUT:** A7 0/8 de revisão cega; nenhuma hipótese foi treinada e depois testada sobre o mesmo holdout reservado.
- **Q-CHANGE:** fonte proposta ON5 e suas FIP não são licença para reescrever fichas nem regra vigente.
- **Q-TRACE:** há UUID, versões reabertas, fórmulas literais, PMFs, corpus original e script reproduzível; não há auditor humano externo cego.

## Próxima investigação de maior valor científico

**Antes de expandir catálogo ou construir mais interface:** buscar de maneira estratificada **pares da MESMA família e mesmo tipo/entrega entre Bronze 5 e Prata 1, com RN/RE/FIP confiáveis**, e uma família adicional por rank onde haja documentação de acerto, PA e RD. Em paralelo, fechar o conflito Escorpião de Diamante × Escorpião Ártico por autoridade de identidade, sem alteração unilateral. Depois, usar o material para avaliar a proporção relativa de dados/atributos e bandas **sem usar ON5 proposto como população**. Só se precisar de execução mecanicamente nova encaminhar protocolo discriminante ao VLAB.

**Conclusão C11:** PASS científico **delimitado** para demonstrar heterogeneidade real, origens de distorção nominal e riscos de interpretação FIP. **Não há diagnóstico validado de desbalanceamento universal nem autorização para recalibrar a v1.1.**
