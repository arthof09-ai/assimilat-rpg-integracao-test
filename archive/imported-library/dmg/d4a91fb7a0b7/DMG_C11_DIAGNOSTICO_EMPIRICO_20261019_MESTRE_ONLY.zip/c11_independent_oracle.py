#!/usr/bin/env python3
"""Independent exact mathematical oracle for DMG C11. Not a second combat engine.
Uses separately implemented dice polynomial convolution and source snapshot checks.
"""
import csv, json, math, re, sys, hashlib, ast
from collections import Counter, defaultdict
from fractions import Fraction as Q
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RUN=ROOT/'C11_19_EFFECTS_SOURCE_SCOPED.csv'
FIP={'Baixa':(73,90),'Média':(91,112)}
TESTS=[]
def check(cond,msg):
 TESTS.append((bool(cond),msg))
 if not cond:raise AssertionError(msg)

def oracle(expr,attr):
 expr=expr.lower().replace(' ','')
 terms=expr.split('+');dice=[];fixed=0
 for term in terms:
  d=re.fullmatch(r'(\d+)d(\d+)',term)
  if d:
   n,k=map(int,d.groups());check(1<=n<=20 and 2<=k<=20,'bounded oracle die '+term)
   dice += [k]*n
  elif term in ('for','força','des','destreza','int','inteligência','inteligencia'):
   v={'for':'FOR','força':'FOR','des':'DES','destreza':'DES','int':'INT','inteligência':'INT','inteligencia':'INT'}[term]
   check(v in attr,'attribute documented '+str(v));fixed+=int(attr[v])
  elif term.isdigit():fixed+=int(term)
  else:raise AssertionError('unparsed independent expression '+term)
 c=Counter({fixed:1});den=1
 for faces in dice:
  nxt=Counter()
  for prev,count in c.items():
   for face in range(1,faces+1):nxt[prev+face]+=count
  c=nxt;den*=faces
 check(sum(c.values())==den,'oracle normalized combinations '+expr)
 exp=sum(Q(value*count,den) for value,count in c.items())
 var=sum((Q(value)-exp)**2*Q(count,den) for value,count in c.items())
 return {'dist':{k:Q(v,den) for k,v in c.items()},'mean':exp,'variance':var,'min':min(c),'max':max(c),'total_individual_dice':len(dice),'fixed':fixed}

def main():
 with RUN.open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 check(len(rows)==19,'19 base effect definitions');check(len(set(x['effect_id'] for x in rows))==19,'distinct effect definitions');check(len(set(x['source_uuid'] for x in rows))==15,'15 distinct page UUIDs')
 check(sum(x['stratum']=='P1_NATURAL_STRICT' for x in rows)==6,'6 strict P1');check(sum(x['stratum']=='B5_NATURAL_STRICT' for x in rows)==6,'6 strict B5')
 check(sum(x['stratum']=='ON5_WEAPON_PROPOSED' for x in rows)==4,'4 proposed ON5 weapons');check(sum(x['stratum']=='ON5_MAGIC_PROPOSED_ENCOUNTER' for x in rows)==3,'3 source ON5 spells')
 number_dice=0
 for x in rows:
  p=oracle(x['source_formula_literal'],ast.literal_eval(x['resolved_attribute']))
  check(p['mean']==Q(str(x['mean_gross'])),'mean exact '+x['effect_id'])
  check(float(p['variance'])==float(x['variance_gross']),'variance '+x['effect_id'])
  check(p['min']==int(x['min_gross']) and p['max']==int(x['max_gross']),'extrema '+x['effect_id'])
  def quantile(prob):
   tally=Q(0)
   for value,weight in sorted(p['dist'].items()):
    tally+=weight
    if tally>=prob:return value
   raise AssertionError('quantile not found')
  for q,field in [(Q(1,4),'q25_gross'),(Q(1,2),'median_gross'),(Q(3,4),'q75_gross')]:
   check(quantile(q)==int(x[field]),'exact distribution quartile '+field+' '+x['effect_id'])
  number_dice+=p['total_individual_dice']
  check(x['source_uuid'] in x['source_url'],'explicit uuid URL '+x['effect_id'])
  check(x['RE_effect']=='UNKNOWN_NOT_INHERITED_FROM_RN','not inherit RE '+x['effect_id'])
  check('last_edited_at' in x and x['last_edited_at'],'last edited lineage '+x['effect_id'])
  if x['stratum']=='ON5_WEAPON_PROPOSED':
   check(x['verification']=='SOURCE_VERIFIED_BUT_EQUIPMENT_PROPOSED','no canonical promotion '+x['effect_id'])
   check(int(x['FF_external_if_equipped'])=={'Sikong Varok':23,'Sikong Iskiel':21,'Sikong Arveth':11,'Sikong Feryn':23}[x['entity']],'FF external accurately coded '+x['entity'])
   check(int(x['PA_daily_item_link'])=={'Sikong Varok':95,'Sikong Iskiel':95,'Sikong Arveth':85,'Sikong Feryn':90}[x['entity']],'PA daily independent of PA activation '+x['entity'])
 p1=sorted([Q(str(x['mean_gross'])) for x in rows if x['stratum']=='P1_NATURAL_STRICT']);b5=sorted([Q(str(x['mean_gross'])) for x in rows if x['stratum']=='B5_NATURAL_STRICT'])
 check(p1==[Q(31),Q(32),Q(32),Q('32.5'),Q(34),Q('40.5')],'strict P1 six raw means')
 check(sum(p1)==202,'strict P1 mean 33 2/3')
 check(b5==[Q('11.5'),Q('22.5'),Q('26.5'),Q('27.5'),Q(28),Q('28.5')],'strict B5 six raw means')
 check(sum(b5)==Q('144.5'),'strict B5 mean 24 1/12')
 p1_no_concha=[Q(str(x['mean_gross'])) for x in rows if x['stratum']=='P1_NATURAL_STRICT' and 'Concha' not in x['entity']]
 check(len(p1_no_concha)==5 and sum(p1_no_concha)==Q('161.5'),'5 non Concha = 32.3')
 check(all(float(x['attribute_fraction'])>.5 for x in rows if x['stratum']=='P1_NATURAL_STRICT'),'six P1 attribute dominant')
 # page-conflict negative check
 check(any(x['entity']=='Escorpião de Diamante' for x in rows if x['stratum']=='B5_NATURAL_STRICT'),'Diamante source preserved')
 check(any(x['entity']=='Escorpião Ártico' for x in rows if x['stratum']=='B5_NATURAL_STRICT'),'Artico source preserved')
 # FIP scientific warning, no promotion
 fiprows=list(csv.DictReader((ROOT/'C11_LENDARIO_FIP_DIAGNOSTIC_NOT_ADJUDICATION.csv').open(encoding='utf-8')))
 check(len(fiprows)==4,'four intrinsic proposed items')
 for x in fiprows:
  lo,hi=FIP[x['FIP_item']];v=Q(x['mean_gross']);check(Q(58)<=v<=Q(160),'broad Legendary inside '+x['entity'])
  check(Q(x['intrinsic_gap_below_fip_floor'])==max(Q(0),Q(lo)-v),'FIP gap '+x['entity'])
 check(sum(Q(x['intrinsic_gap_below_fip_floor'])>0 for x in fiprows)==3,'3/4 FIP floor warnings')
 # Distinct C09 source patch supports source values (fails on regression mismatch)
 patch=json.loads((ROOT/'source_snapshots/C09_VERIFIED_PATCH.json').read_text());sources={x['uuid']:x for x in patch['sources']}
 for x in rows:
  if x['stratum']=='ON5_WEAPON_PROPOSED' and x['entity']!='Sikong Feryn':
   check(x['source_uuid'] in sources,'source patch uuid '+x['entity'])
   e=sources[x['source_uuid']]['effects'][0]
   check(e['intrinsic']==x['source_formula_literal'],'intrinsic C09 match '+x['entity'])
   check(e['damage_formula']=={'Sikong Varok':'10d10+48','Sikong Iskiel':'9d8+47','Sikong Arveth':'8d10+35'}[x['entity']],'equipped C09 match '+x['entity'])
 # Independent exact probability for real documented paired formulas
 src={x['ability']:x for x in rows if x['stratum']=='P1_NATURAL_STRICT'}
 g=next(x for x in rows if x['entity']=='Gambá Demoníaco');m=next(x for x in rows if x['entity']=='Mamute Antigo')
 A=oracle(g['source_formula_literal'],ast.literal_eval(g['resolved_attribute']))['dist'];B=oracle(m['source_formula_literal'],ast.literal_eval(m['resolved_attribute']))['dist']
 gt=sum((pa*pb for a,pa in A.items() for b,pb in B.items() if a>b),Q(0));lt=sum((pa*pb for a,pa in A.items() for b,pb in B.items() if a<b),Q(0));eq=1-gt-lt
 check(gt+lt+eq==1,'source pair exact sum')
 bronze=[x for x in rows if x['stratum']=='B5_NATURAL_STRICT' and x['entity']=='Escorpião Ártico']
 check(len(bronze)==2 and Q(str(bronze[0]['mean_gross']))!=Q(str(bronze[1]['mean_gross'])),'same-uuid Bronze within-pair')
 # independently compute rider mean per documented PA as fraction and verify source paired data
 for r in csv.DictReader((ROOT/'C11_SOURCE_PAIRED_PA_MARGINAL.csv').open(encoding='utf-8')):
  amt=Q(str(r['rider_gross_mean_conditional_on_trigger']));pa=int(r['rider_cost_PA_per_activation'])
  check(abs(float(amt/pa)-float(r['gross_rider_DME_per_activation_PA']))<1e-14,'delta PA raw per-use TEST '+r['entity'])
 proof={'status':'PASS_IF_ALL_CHECKS_TRUE','total_checks':len(TESTS),'passed_checks':sum(ok for ok,msg in TESTS if ok),'independent_mathematics':'Separate dice convolution, independent from C05 pmf source (no C05 module imported)','source_scope':'19 selected definitions 15 UUIDs 4 strata; no global census','total_dice_individual_in_19_definitions':number_dice,'p_gamba_gross_gt_mamute_exact':str(gt),'p_gamba_gross_lt_mamute_exact':str(lt),'p_gamba_gross_equal_mamute_exact':str(eq),'p_gamba_gt_pct':float(gt)*100,'source_p1_means':[str(v) for v in p1],'source_b5_means':[str(v) for v in b5],'limitations':'NO independent human auditor, selected sources, no formal blind holdout, no attribution of rank effect; experimental snapshots only'}
 (ROOT/'C11_INDEPENDENT_MATH_ORACLE_PASS.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
 print(json.dumps(proof,ensure_ascii=False))
if __name__=='__main__':main()
