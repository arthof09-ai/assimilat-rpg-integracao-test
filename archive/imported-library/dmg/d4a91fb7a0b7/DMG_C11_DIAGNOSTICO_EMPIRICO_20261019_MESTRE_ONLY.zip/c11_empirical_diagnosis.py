#!/usr/bin/env python3
"""DMG C11 evidence-bound diagnostics; read-only; reuses unchanged C05 exact PMF.
Run: python c11_empirical_diagnosis.py (stdlib only, from any working directory)
Bundled data snapshots originate from physically recovered C04, C05, C09/C10.
Does not infer effect ranks from creature rank or assume source independence.
"""
from __future__ import annotations
import sys,csv,json,statistics,hashlib,argparse,math,ast
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from collections import defaultdict,Counter
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'src'))
from experimental_damage_calc import pmf
SRC=HERE/'source_snapshots'
BAND={'Bronze':(4,18),'Prata':(14,36),'Ouro':(22,62),'Ouro Negro':(38,96),'Lendário':(58,160)}
FIP={'Lendário':{'Entrada':(58,72),'Baixa':(73,90),'Média':(91,112),'Alta':(113,136),'Ápice':(137,160)}}

def csvread(p):
 with open(p,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def dec(x):return float(x)
def means(fracs):return sum(fracs,F(0))/len(fracs)
def empirical_quant(v,q):
 v=sorted(v);i=max(0,math.ceil(q*len(v))-1);return float(v[i])
def median(v):return float(statistics.median(v))
def mad(v):return median([abs(float(t)-median(v)) for t in v])
def stats(v):
 v=sorted(float(x) for x in v);n=len(v);m=sum(v)/n
 return {'n_effects':n,'min':v[0],'q10_nearest_rank':empirical_quant(v,.1),'q25_nearest_rank':empirical_quant(v,.25),'median':median(v),'mean':m,'trimmed_20pct_mean':(sum(v[max(0,int(n*.2)):n-max(0,int(n*.2))])/len(v[max(0,int(n*.2)):n-max(0,int(n*.2))])),'q75_nearest_rank':empirical_quant(v,.75),'q90_nearest_rank':empirical_quant(v,.9),'max':v[-1],'IQR':empirical_quant(v,.75)-empirical_quant(v,.25),'MAD':mad(v),'std_population':statistics.pstdev(v),'CV_descriptive':statistics.pstdev(v)/m if m else None,'scope':'SELECTED_NON_RANDOM_N_LT10_DO_NOT_GENERALIZE'}
def jsonwrite(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def csvwrite(p,rows,fields):
 with open(p,'w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def first_pmfs(formula,attrs=None):
 dist,parse=pmf(formula,attrs or {})
 mean=sum(F(val)*p for val,p in dist.items());var=sum((F(val)-mean)**2*p for val,p in dist.items())
 seq=sorted(dist);cum=F(0)
 quant={}
 for v in seq:
  cum+=dist[v]
  for q in [F(1,4),F(1,2),F(3,4)]:
   if str(q) not in quant and cum>=q:quant[str(q)]=v
 return {'mean_exact':str(mean),'mean':float(mean),'minimum':min(dist),'maximum':max(dist),'variance':float(var),'q25':quant[str(F(1,4))],'median':quant[str(F(1,2))],'q75':quant[str(F(3,4))],'dice_mean':float(parse['die_mean']),'fixed_attribute':parse['fixed'] if parse['attribute'] else 0,'fixed_literal':parse['fixed'] if not parse['attribute'] else 0,'attribute_code':parse['attribute'],'dice_terms':len(parse['dice']),'total_individual_dice':sum(n for n,_ in parse['dice']),'pmf_support':len(dist),'distribution':{str(k):str(v) for k,v in dist.items()}}
def create():
 pages={x['page_uuid']:x for x in csvread(SRC/'C04_SOURCE_PAGE_CYCLE4_FORENSIC.csv')}
 c04=csvread(SRC/'C04_DAMAGE_EFFECT_CYCLE4_NORMALIZED.csv')
 c05=csvread(SRC/'C05_DAMAGE_EFFECTS_NORMALIZED_58.csv')
 patch=json.loads((SRC/'C09_VERIFIED_PATCH.json').read_text())
 rows=[];mathmeta={}
 def add(stratum,source,entity,ability,formula,attrs,rank_label,rank_effect=None,fip=None,item_rank=None,classification='VERIFIED_SOURCE_MESTRE',type_desc='NOT_DOCUMENTED',delivery='NOT_DOCUMENTED',cost='NOT_DOCUMENTED',condition='NOT_DOCUMENTED',family=None,ff_external=0,link_daily=None,intrinsic_formula=None,notes='',url=None,edit=None):
  math=first_pmfs(formula,attrs);id=f'{source}::{ability}'
  if id in mathmeta:raise AssertionError('DUPLICATE_EFFECT_DEFINITION_'+id)
  mathmeta[id]=math
  rows.append({'effect_id':id,'stratum':stratum,'source_uuid':source,'source_url':url or 'https://app.notion.com/p/'+source,'last_edited_at':edit or '2026-10-01 archived C04/C05; source reopened 2026-10-19','family_parent':family or entity,'entity':entity,'ability':ability,'source_formula_literal':formula,'resolved_attribute':str(attrs),'RN_star':rank_label,'RE_effect':rank_effect or 'UNKNOWN_NOT_INHERITED_FROM_RN','FIP_item':fip or 'UNKNOWN','RI_item':item_rank or 'NOT_ITEM','verification':classification,'damage_type':type_desc,'delivery':delivery,'cost_PA_per_use':cost,'condition':condition,'mean_gross':math['mean'],'min_gross':math['minimum'],'max_gross':math['maximum'],'variance_gross':math['variance'],'q25_gross':math['q25'],'median_gross':math['median'],'q75_gross':math['q75'],'dice_mean':math['dice_mean'],'attribute_bonus':math['fixed_attribute'],'literal_fixed_bonus':math['fixed_literal'],'FF_external_if_equipped':ff_external,'PA_daily_item_link':link_daily if link_daily is not None else 'NOT_APPLICABLE_OR_UNKNOWN','intrinsic_formula':intrinsic_formula or formula,'dice_fraction':math['dice_mean']/math['mean'] if math['mean'] else 0,'attribute_fraction':math['fixed_attribute']/math['mean'] if math['mean'] else 0,'notes':notes})
 # PRATA1 strict one HP effect per physical UUID in original C04
 for e in c04:
  u=e['source_page_uuid'];p=pages.get(u,{});
  if p.get('rank_label')=='Prata 1' and p.get('rank_triple_concordance')=='YES' and e['channel']=='VIDA' and e['gross_mean']:
   alias=p['ancestor_name'];name=p.get('body_name') or alias
   attrs={e['attribute_code']:int(e['attribute_value'])} if e['attribute_code'] and e['attribute_value'] else {}
   add('P1_NATURAL_STRICT',u,alias,e['name_literal'],e['formula_literal'],attrs,'Prata 1','',family=p['species_parent_uuid'],notes=f'BODY_NAME={name}; ORIGINAL_C04_CLASSIFICATION={e["classification_eligibility"]}; COST/ACCURACY=UNKNOWN; Concha inanimate caveat if applicable',edit=p['version'])
 # Bronze5 only rank triple valid source sheets, not a global population
 for e in c04:
  u=e['source_page_uuid'];p=pages.get(u,{});
  if p.get('rank_label')=='Bronze 5' and p.get('rank_triple_concordance')=='YES' and e['channel']=='VIDA' and e['gross_mean']:
   attrs={e['attribute_code']:int(e['attribute_value'])} if e['attribute_code'] and e['attribute_value'] else {}
   add('B5_NATURAL_STRICT',u,p['ancestor_name'],e['name_literal'],e['formula_literal'],attrs,'Bronze 5',family=p['species_parent_uuid'],notes=f'BODY_NAME={p["body_name"]}; FAMILY_ALIAS_CONFLICT_if_Escorpiao_Diamante; COST/ACCURACY_UNKNOWN',edit=p['version'])
 for e in c05:
  if e['page_uuid']=='c28c2b324ede8217937c8165a19eafa9' and e['gross_mean_conditional']:
   # same documented body page, TWO effects, NO extra species count
   attrs={'DES':24,'FOR':8}; add('B5_NATURAL_STRICT',e['page_uuid'],'Escorpião Ártico',e['name_literal'],e['formula_literal'],attrs,'Bronze 5',family=e['species_parent_uuid'],notes='TITLE_BODY_ANCESTOR_BRONZE5; BODY_NAME_COLLIDES_WITH_C04_DIAMANTE_PAGE; NOT_DECLARED_INDEPENDENT',edit=e['source_date'])
 # equipped weapons from C09 physical source patch; Feryn from C07
 weapon=[
 ('3f6c2b324ede81f49ea9efbe1a811091','Sikong Varok','Machado do Juramento Raiz-Ferro','10d10+25','10d10+48','Baixa',23,'FISICO_IMPACTO_CORTE',95,'ON5 PROPOSTO, rider +6d12/60 PA 1 per scene'),
 ('3f6c2b324ede81a78a59d3d81fd5e966','Sikong Iskiel','Arco da Asa Rasgada','9d8+26','9d8+47','Média',21,'MISTO_VENTO_PERFURANTE',95,'ON5 PROPOSTO, rider +5d10/45PA requires 20m flight once/turn'),
 ('3f6c2b324ede8105891fc647242e61ca','Sikong Arveth','Bastião das Sete Gargantas','8d10+24','8d10+35','Baixa',11,'FISICO_PERFURANTE',85,'ON5 PROPOSTO, rider +6d10 Terra/55 PA once/scene'),
 ('3f6c2b324ede81ce9c61db8127bf0e31','Sikong Feryn','Presas da Noite sem Pegadas','8d8+24','8d8+47','Baixa',23,'FISICO_CORTANTE',90,'ON5 PROPOSTO, rider +5d8 Vento/45 PA once/scene')]
 changes={'3f6c2b324ede81f49ea9efbe1a811091':'2026-10-16T10:33:26.087Z','3f6c2b324ede81a78a59d3d81fd5e966':'2026-10-16T10:33:53.226Z','3f6c2b324ede8105891fc647242e61ca':'2026-10-16T10:33:37.349Z','3f6c2b324ede81ce9c61db8127bf0e31':'2026-10-16T10:33:13.379Z','3f6c2b324ede819cae98ec0f6a63de76':'2026-10-16T10:33:32.392Z','3f6c2b324ede819e879beabb795001ba':'2026-10-16T10:33:46.339Z'}
 for uuid,entity,ability,intr,eq,fip,ff,typ,cost,note in weapon:
  add('ON5_WEAPON_PROPOSED',uuid,entity,ability,intr,{},'Ouro Negro 5',item_rank='Lendário',fip=fip,classification='SOURCE_VERIFIED_BUT_EQUIPMENT_PROPOSED',type_desc=typ,delivery='SINGLE_WEAPON_ATTACK_CONDITIONAL_HIT',cost='NOT_DOCUMENTED_BASE_ATTACK',family=uuid,notes=note,edit=changes[uuid],intrinsic_formula=intr,ff_external=ff,link_daily=cost)
 # three offensive ON5 spells, with different delivery; NOT homogeneous calibration group
 spells=[
 ('3f6c2b324ede81ce9c61db8127bf0e31','Sikong Feryn','Turbilhão Cinzento','9d10+8','VENTO','CONE_8M_REFLEXO_VS_ATTACK_ROLL',60),
 ('3f6c2b324ede819cae98ec0f6a63de76','Sikong Eristan','Tempestade de Esporos','10d10+10','PLANTA','AREA_RADIUS_5M_FORTITUDE_CD76',80),
 ('3f6c2b324ede819e879beabb795001ba','Sikong Veyun','Cetro da Prisão Prismática','8d10+26','TERRA','SINGLE_TARGET_REFLEXO_CD72',65)]
 for uuid,entity,ability,formula,typ,delivery,cost in spells:
  add('ON5_MAGIC_PROPOSED_ENCOUNTER',uuid,entity,ability,formula,{},'Ouro Negro 5',classification='MESTRE_SOURCE_ENCOUNTER_PRECALC_NO_RE_EFFECT_CONFIRMED',type_desc=typ,delivery=delivery,cost=cost,notes='PA known per cast; RD element unproven; defense types differ; NO_CRITICAL_MAGIC; NOT RE/FIP ADJUDICATED',edit=changes[uuid])
 # source eligibility checks
 assert len([x for x in rows if x['stratum']=='P1_NATURAL_STRICT'])==6
 assert len([x for x in rows if x['stratum']=='B5_NATURAL_STRICT'])==6
 assert len([x for x in rows if x['stratum']=='ON5_WEAPON_PROPOSED'])==4
 assert len([x for x in rows if x['stratum']=='ON5_MAGIC_PROPOSED_ENCOUNTER'])==3
 assert len(rows)==19
 assert len(set(x['source_uuid'] for x in rows))==15
 # component denominator: 1 term per ndfaces expression + fixed or attr distinct (C05 original component rules)
 components=sum(first_pmfs(x['source_formula_literal'],ast.literal_eval(x['resolved_attribute']))['dice_terms']+int(bool(x['attribute_bonus']))+int(bool(x['literal_fixed_bonus'])) for x in rows)
 assert components==40,components
 # verification of means that correspond to historical numeric rows
 for e in c04:
  r=[x for x in rows if x['source_uuid']==e['source_page_uuid'] and x['ability']==e['name_literal']]
  if r and e['gross_mean'] and r[0]['stratum'] in ('P1_NATURAL_STRICT','B5_NATURAL_STRICT'):
   assert float(e['gross_mean'])==r[0]['mean_gross'],('C04_NUMERIC_DRIFT',e)
 for e in c05:
  r=[x for x in rows if x['source_uuid']==e['page_uuid'] and x['ability']==e['name_literal']]
  if r and e['gross_mean_conditional'] and r[0]['stratum']=='B5_NATURAL_STRICT':assert float(e['gross_mean_conditional'])==r[0]['mean_gross']
 fields=list(rows[0]);csvwrite(HERE/'C11_19_EFFECTS_SOURCE_SCOPED.csv',rows,fields)
 strata={}
 for stratum in sorted(set(x['stratum'] for x in rows)):
  subset=[x for x in rows if x['stratum']==stratum];m=[x['mean_gross'] for x in subset]
  strata[stratum]={'stats':stats(m),'n_unique_source_uuids':len(set(x['source_uuid'] for x in subset)),'n_unique_family_keys':len(set(x['family_parent'] for x in subset)),'mean_gross':sum(m)/len(m),'records':[{'source':x['source_uuid'],'entity':x['entity'],'ability':x['ability'],'gross':x['mean_gross']} for x in subset],'caveat':'NOT a population inference; source-family clustering, delivery and mechanical eligibility remain separate'}
 p1=[x for x in rows if x['stratum']=='P1_NATURAL_STRICT'];p1_no_concha=[x for x in p1 if 'Concha' not in x['entity']];strata['P1_NATURAL_STRICT']['sensitivity_excluding_inanimate_Concha']=stats([x['mean_gross'] for x in p1_no_concha]);strata['P1_NATURAL_STRICT']['attributes_above_50pct']=sum(x['attribute_fraction']>.5 for x in p1)
 bronze=[x for x in rows if x['stratum']=='B5_NATURAL_STRICT'];strata['B5_NATURAL_STRICT']['alias_collision']={'uuid_a':'92bc2b324ede834ca813812ff4783805','parent_a':'Escorpião de Diamante','body_a':'Escorpião Ártico','uuid_b':'c28c2b324ede8217937c8165a19eafa9','parent_b':'Escorpião Ártico','body_b':'Escorpião Ártico','state':'IDENTITY_DISPUTED_TWO_UUIDS_NOT_AUTOMATIC_INDEPENDENT_CREATURES','worst_case_family_independence':'UNRESOLVED'}
 for x in rows:
  if x['stratum']=='ON5_WEAPON_PROPOSED':
   intr=x['mean_gross'];lo,hi=FIP['Lendário'][x['FIP_item']];
   x['intrinsic_nominal_fip_band_min']=lo;x['intrinsic_nominal_fip_band_max']=hi;x['intrinsic_gap_below_fip_floor']=max(0,lo-intr)
   x['equipped_gross_mean_from_documented_FF']=intr+int(x['notes'].split(' FF=')[-1]) if ' FF=' in x['notes'] else intr+{'Sikong Varok':23,'Sikong Iskiel':21,'Sikong Arveth':11,'Sikong Feryn':23}[x['entity']]
   x['broad_lendario_band_check']='WITHIN_58_160' if 58<=intr<=160 else 'OUTSIDE_58_160'
 band=[{k:x[k] for k in ('source_uuid','entity','ability','source_formula_literal','mean_gross','FIP_item','intrinsic_nominal_fip_band_min','intrinsic_nominal_fip_band_max','intrinsic_gap_below_fip_floor','equipped_gross_mean_from_documented_FF','PA_daily_item_link','broad_lendario_band_check','verification')} for x in rows if x['stratum']=='ON5_WEAPON_PROPOSED'];csvwrite(HERE/'C11_LENDARIO_FIP_DIAGNOSTIC_NOT_ADJUDICATION.csv',band,list(band[0]))
 strata['ON5_WEAPON_PROPOSED']['count_below_nominal_fip_floor']=sum(x['intrinsic_gap_below_fip_floor']>0 for x in band)
 strata['ON5_WEAPON_PROPOSED']['count_inside_broad_lendario']=sum(x['broad_lendario_band_check']=='WITHIN_58_160' for x in band)
 # conditional PA comparisons and other discriminating tests
 pairs=[]
 for entity,base,rider,pa,when,cadence in [
  ('Sikong Varok','10d10+48','6d12',60,'AFTER_HIT','ONCE_PER_SCENE'),
  ('Sikong Iskiel','9d8+47','5d10',45,'AFTER_HIT_AND_FLY20M','ONCE_PER_TURN'),
  ('Sikong Feryn','8d8+47','5d8',45,'AFTER_HIT','ONCE_PER_SCENE'),
  ('Sikong Arveth','8d10+35','6d10',55,'AFTER_HIT','ONCE_PER_SCENE')]:
  b=first_pmfs(base);e=first_pmfs(rider);pairs.append({'entity':entity,'base_equipped_gross_mean':b['mean'],'rider_gross_mean_conditional_on_trigger':e['mean'],'gross_combined_mean_if_triggered':b['mean']+e['mean'],'rider_cost_PA_per_activation':pa,'gross_rider_DME_per_activation_PA':e['mean']/pa,'rider_to_base_ratio':e['mean']/b['mean'],'prerequisites':when,'cadence':cadence,'shared_RD_policy':'UNKNOWN; bonus is not an extra attack; no adjusted per-PA comparison','other_costs':'ITEM_LINK_PA_DAY_SEPARATE'})
 csvwrite(HERE/'C11_SOURCE_PAIRED_PA_MARGINAL.csv',pairs,list(pairs[0]));strata['rider_pairs']=pairs
 # Time-window / burst versus sustain: exploratory only, item budget is NOT normalized by unproven scene rules.
 fip_rows=[]
 rider_meta={r['entity']:r for r in pairs}
 for x in band:
  r=rider_meta[x['entity']];base=x['mean_gross'];bonus=r['rider_gross_mean_conditional_on_trigger'];lo=x['intrinsic_nominal_fip_band_min'];hi=x['intrinsic_nominal_fip_band_max']
  for n in (1,3,5):
   # once-scene used once, except Iskiel once/turn: report both low/maximum eligibility; NOT actual policy choice
   for activations in ([1,n] if x['entity']=='Sikong Iskiel' and n>1 else [1]):
    window=(base*n+bonus*activations)/n
    fip_rows.append({'entity':x['entity'],'FIP_item':x['FIP_item'],'nominal_FIP_lo':lo,'nominal_FIP_hi':hi,'intrinsic_base_mean':base,'successful_hits_TEST':n,'activated_rider_count_TEST':activations,'rider_mean':bonus,'avg_item_intrinsic_plus_rider_per_successful_hit_TEST':window,'inside_nominal_window_TEST':lo<=window<=hi,'scope':'NO_CRITICAL_NO_RD_NO_HIT_PROB; SAME_ITEM_SUFFICIENT_PA; SCENE_LENGTH_TEST_ONLY; NOT_BALANCE_ADJUDICATION','assumption':'ALL_HITS_ELIGIBLE_AND_RIDER_USED; ISKIEL_REQUIRED_FLIGHT_AND_TURN_SEPARATION_IF_MULTIPLE'})
 csvwrite(HERE/'C11_BURST_VS_SUSTAIN_RIDER_WINDOWS_TEST.csv',fip_rows,list(fip_rows[0]));strata['window_sensitivity_TEST']=fip_rows
 spells_rows=[x for x in rows if x['stratum']=='ON5_MAGIC_PROPOSED_ENCOUNTER'];strata['ON5_MAGIC_PROPOSED_ENCOUNTER']['per_cast_gross_if_all_failed_save_zero_RD_TEST']=[{'name':x['ability'],'mean':x['mean_gross'],'cost_PA':x['cost_PA_per_use'],'gross_per_PA_per_target_if_full_TEST':x['mean_gross']/x['cost_PA_per_use'],'delivery':x['delivery']} for x in spells_rows]
 # C05 label-body Prata 1 conflicted but ancestor dissonant; 5 records observational as sensitivity never ranked
 conflicted=[x for x in c05 if x['rank_title']=='Prata 1' and x['rank_body']=='Prata 1' and x['rank_triple']=='False' and x['effect_channel']=='VIDA' and x['gross_mean_conditional']];assert len(conflicted)==5,len(conflicted)
 strata['conflicted_Prata1_C05_sensitivity_only']={'n_effects':len(conflicted),'n_pages':len(set(x['page_uuid'] for x in conflicted)),'gross_means':[float(x['gross_mean_conditional']) for x in conflicted],'descriptive_mean_excluded_from_Prata1':sum(float(x['gross_mean_conditional']) for x in conflicted)/len(conflicted),'reason':'ANCESTOR RANK CONTRADICTS TITLE AND BODY'}
 # Bronze/Prata across adjacent ranks: NO strict matched pairs and even nominal means cannot establish growth law
 strata['cross_rank_frontiers']={'Bronze5_vs_Prata1':'DESCRIPTIVE_UNMATCHED_ONLY; different source families, stars, damage types, attributes; no rank effect causal estimate','Ouro_vs_ON':'HOLD_NO_EFFECT_RE_FIP_MATCHED_PAIRS','ON_vs_Lendario':'HOLD_ON5_USER_RANK_NOT_EFFECT_RANK_AND_WEAPONS_HAVE_LENDARIO_RI','other':'NO_RANK_EFFECT_FIP_ADMISSIBLE_MATCHED_PAIRS_IN_CURRENT_19_EFFECT_SCOPE'}
 # broad standard Bronze/Prata band cannot be scored against beast gross or intrinsic without RE adjudication; dry-run demonstration only
 strata['normative_comparison']={'source':'DMG-RANK-01 v1.1','bands':BAND,'invalid_gross_vs_rank_indicator':'DO_NOT_SCORE RN RANK VS RE BAND','Lendario_proposed_item_numeric':'4/4 intrinsics in broad 58-160; 3/4 below nominal FIP subband before riders; cannot label official imbalance; equipment PROPOSED, riders not priced','nominal_checks':'CANDIDATE_REVIEW_ONLY_NOT_CANONICAL_ADHERENCE'}
 jsonwrite(HERE/'C11_STRATA_HETEROGENEITY_AND_SENSITIVITY.json',strata)
 pmfs={key:{k:v for k,v in m.items() if k!='distribution'} for key,m in mathmeta.items()};jsonwrite(HERE/'C11_MATH_PMF_SUMMARIES.json',pmfs)
 # DATA lineage counts/metric scope
 fact={'checkpoint_C10_sha256':'75c4ed7f19f254adc0f64c0a70c409083fe112eb088a4db1af9250ddadf954cc','sources_15_unique_uuid':len(set(x['source_uuid'] for x in rows)),'effects_19_total':len(rows),'math_components_grouped_dice_and_fixed_attribute':components,'genuine_new_source_pages_this_cycle':0,'notion_physically_reopened_on_2026_10_19':15,'source_clusters_Prata1':6,'source_clusters_Bronze5':3,'source_clusters_ON5':6,'reused_C04_29_and_C05_35':'NOT_CENSUS_GLOBAL','historical_A6_uuid_structural_571':'INHERITED_FROZEN_NO_NEW_RECOUNT','not_recovered_L002_L003_binary':'YES','R162_154_R169_137':'TWO_SEPARATE_OBSERVATIONAL_COHORTS_NOT_MERGED','F0':'4/8','corpus_formal_phase':'NO_FORMAL_PROMOTION','source_snapshots':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(SRC.glob('*'))]};jsonwrite(HERE/'C11_SOURCE_SCOPE_MANIFEST.json',fact)
 return rows,strata,fact
if __name__=='__main__':
 rows,strata,fact=create();print(json.dumps({'status':'LOCAL_DIAGNOSIS_GENERATED','effects':len(rows),'pages':fact['sources_15_unique_uuid'],'component_contributions':fact['math_components_grouped_dice_and_fixed_attribute'],'strict_p1':strata['P1_NATURAL_STRICT']['stats'],'bronze5':strata['B5_NATURAL_STRICT']['stats'],'l_intrinsic_fip':strata['ON5_WEAPON_PROPOSED']['count_below_nominal_fip_floor']},ensure_ascii=False))
