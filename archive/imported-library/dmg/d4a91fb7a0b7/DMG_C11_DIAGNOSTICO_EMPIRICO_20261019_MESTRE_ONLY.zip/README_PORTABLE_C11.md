# DMG C11 — recuperação científica portátil (MESTRE-SIDE)

Operação EXISTENTE: `OP-DMG-CORPUS-EMP-01`. Nada neste ZIP cria regras, motor de combate ou fonte oficial; DMG-RANK-01 v1.1 permanece intacta.

**Produto de primeira leitura:** `C11_DIAGNOSTICO_EQUILIBRIO_EMPIRICO_MESTRE_ONLY.md` (responde às consultas A–E do Mestre, com fontes, valores, alertas, metodologia e limites). **PSV:** `PSV_DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.md`.

## Proveniência e dependências

* C10 original ZIP fisicamente autenticado fora deste pacote, SHA-256 `75c4ed7f19f254adc0f64c0a70c409083fe112eb088a4db1af9250ddadf954cc`.
* C04 original ZIP SHA-256 `4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629`, C05 SHA-256 `05dbf2e77beed44430109aa54ebc0c83d373d170d86d6a6c753d574636c088dc`.
* `source_snapshots/` contém **somente recortes históricos usados** de C04/C05/C09, com fingerprints em `C11_SOURCE_SCOPE_MANIFEST.json`, não substitui o corpus original.
* `src/experimental_damage_calc.py` é uma **cópia byte a byte** da calculadora C05 imutável, para reexecução independente de diretórios absolutos.
* `C11_NOTION_MESTRE_15_READBACK.json` registra 15 páginas Mestre existentes reabertas e timestamps nativos. Não contém dump binário de todos os blocos e não confere acesso automático ao Notion para os scripts.
* `C11_VLAB_SEPARATE_COHORT_RECEIPT.json`: coortes R162 e R169 mantidas em separados; CSVs originais vêm do C10/VLAB já autenticado, não duplicados neste delta.
* As FIP de itens das fichas ON5 ainda são **propostas de encontro**, não certificados PR-ITEM. Não usar como estatística populacional.
* Os oito holdouts formais A7 permanecem sem revisão cega; esta pesquisa não se apresenta como validação externa independente.

## Reproduzir em uma pasta completamente diferente, Python 3.10+ padrão

```bash
unzip DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.zip -d /caminho/novo/dmg_c11
cd /caminho/novo/dmg_c11
python c11_empirical_diagnosis.py
python c11_independent_oracle.py
python generate_c11_queries.py
```

Não há caminhos absolutos. Esses comandos geram as mesmas matrizes delimitadas e 5 consultas científicas a partir dos snapshots incluídos; a segunda implementação usa convolução de dados própria, não importa o C05. O script não busca novas páginas, escreve apenas no diretório extraído e não altera fonte original ou SQLite.

**Auditoria técnica do ZIP:** verifique CRC, SHA do manifesto `C11_SHA256_MANIFEST.json` e igualdade dos artefatos reproduzidos. Confira readback e SHA do ZIP na `C11_LIBRARY_COLD_READBACK_RECEIPT_20261019.json`, publicado externamente à versão congelada.

## Arquivos de análise

- `C11_PRE_REGISTERED_SCOPE.json`: critérios e hipóteses registrados antes da transformação numérica desta C11 (não pré-registro independente externo).
- `C11_19_EFFECTS_SOURCE_SCOPED.csv`: 19 efeitos em 15 páginas, com estado e origem.
- `C11_STRATA_HETEROGENEITY_AND_SENSITIVITY.json`: quatro estratos, estatísticas, sensibilidades e não elegibilidade de certos conflitos.
- `C11_MATH_PMF_SUMMARIES.json`: média, variância e quartis exatos (PMF construível pelo código).
- `C11_LENDARIO_FIP_DIAGNOSTIC_NOT_ADJUDICATION.csv`: quatro itens Lendários PROPOSTOS, FIP e bônus FF isolados.
- `C11_SOURCE_PAIRED_PA_MARGINAL.csv`: deltas de dano/PA condicionais, sem alvos nem mitigação inventados.
- `C11_BURST_VS_SUSTAIN_RIDER_WINDOWS_TEST.csv`: cenários teste de 1, 3 e 5 acertos, sem combate executado.
- `C11_INDEPENDENT_MATH_ORACLE_PASS.json`: oráculo de convolução independente e provas algébricas.
- `C11_FIVE_MESTRE_QUESTIONS_REPRODUCED.json`: respostas A–E legíveis em português.
- `C11_SOURCE_SCOPE_MANIFEST.json`: denominadores e SHA das fontes recortadas.

## Fronteiras de autoridade

F0 4/8; A5 0/7 readbacks históricos; A7 0/8 revisão cega; A8 sem writer/lease/epoch/ACK; E01–E24 e oito gates inalterados. Nenhuma promoção v2, nenhuma escrita Notion canônica/Party/O Primeiro, nenhuma alteração em fichas ou dados VLAB. Fontes MESTRE-ONLY jamais reutilizar como material de player automaticamente.
