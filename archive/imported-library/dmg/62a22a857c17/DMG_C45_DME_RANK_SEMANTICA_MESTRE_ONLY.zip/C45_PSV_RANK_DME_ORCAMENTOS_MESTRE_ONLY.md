# C45 — Auditoria científica RE/FIP × DME e orçamento de entrega (MESTRE-ONLY, TEST)

**OP:** OP-DMG-CORPUS-EMP-01. **Fonte v1.1:** <https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e>. **Controle:** somente leitura de quatro páginas Mestre, nenhuma alteração do original, DMG-RANK, Party, O Primeiro, VLAB ou OP/Diário. Resultados exatos por expressões; não é ranking final nem recalibração.

## Pergunta respondida
RE/FIP não pode ser recalculado mecanicamente só pelo valor médio de uma expressão de dano. O orçamento depende do efeito isolado, forma de entrega, custo, alvo, rider, chance de acerto e fonte competente.

## Dados de sete efeitos reais do texto-fonte
- **Martelo do Portão Faminto (semicanônico/incubação):** texto indica **Ouro Negro Média**, mas ataque comum 8d10+12 = **56**, abaixo da banda OURO NEGRO MÉDIA **59–69** da v1.1, e dentro da banda Baixa **49–58**. **DIVERGÊNCIA DE TRIAGEM, NÃO ERRO CANÔNICO APROVADO.** O item também tem poder de demolição restrito a estruturas, +6d8 com 25PA, DME especializado **83** somente após acerto. Não somar o dano de demolição contra criaturas nem forçar mudança de FIP do item.
- **Manopla do Trovão Cativo:** FIP Ouro Entrada 22–28, descarga +5d8+3 = **25,5**, dentro do intervalo numérico; porém a descarga é bônus após acertar com outra arma, requer **22PA**, uma vez por descanso. Uma comparação de banda não é homologação autônoma do efeito.
- **Lâmina da Queda Contida:** ON Entrada, 7d8+15 = **46,5**, dentro 38–48. Sua reação de estabilização é defesa separada e não inflaciona dano.
- **Sikong Iskiel — Flecha da Fenda:** própria habilidade ON5 Ápice, 12d12+10 = **88**, dentro ON Ápice 83–96. Seu **FF +21** é externo ao DME, não entra no 88. Custo 80PA, padrão, alvo único e crítico elegível por golpe físico.
- **Sikong Iskiel — Chuva das Cornijas:** 9d10+8 = **57,5/alvo**, classificada como **Área ON5**, não como FIP Entrada/Baixa/Média. Para orçamento hipotético de área média 55–70% por alvo, esse 57,5 pode surgir de base Ouro Negro Ápice entre **83–96** com fator entre **0.598958 e 0.692771** (interseção do orçamento permitido). **Compatibilidade matemática não é prova de FIP Ápice**, pois ela não está escrita.
- **Iskiel — Flecha de Trava:** 8d10+12 = **56** com controle leve. Se hipoteticamente fosse banda Média 59–69 e rider 85–95%, um DME 56 permitiria base aproximada 58,95–65,88, com sobreposição à faixa Média. Isso **não atribui FIP Média à ficha**, que não a informa.

**Leitura de auditoria:** 7 casos; 3 dentro da banda nominal bruta, 2 fora da banda bruta (um por restrição de alvo), 2 sem FIP numericamente comparável. Nenhuma página considerada ofensiva sem dano explícito elegível ao fallback F6.

## Gates
F0 4/8 documental HOLD. A5 bytes 0/7; A6 universo global HOLD (870 IDs no recorte); A7 holdout cego HOLD; A8 writer/segundo humano HOLD. F6 sem caso positivo, v2 não lançada. **NAC-PASS local:** cálculo/manifesto/CRC PASS; NÃO normativa.

## Próximo ponto útil
Antes de calibrar uma banda ou reparar FIP, a instância autorizada precisa confirmar o significado da classificação do **item inteiro** versus a classificação da **ofensiva intrínseca** e os riders. Jamais alterar o Martelo/Iskiel por comparação de média isolada. Buscar fonte com dano ausente + RE/FIP legítimo + entrega/PA completos. Preservar o corpus 870, não recensear anteriores.

## Arquivos
`C45_07_EFEITOS_AUDITORIA_FIP_DME.csv`, `C45_CHECKPOINT.json`, `C45_PSV_RANK_DME_ORCAMENTOS_MESTRE_ONLY.md`, `C45_MANIFEST.json` em ZIP Mestre-only.
