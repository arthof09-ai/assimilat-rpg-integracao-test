#!/usr/bin/env python3
"""C06 compatibility/portability runner for untouched C05 ZIP.
Runs original C05 tests/audits from an arbitrary extraction directory using only
runtime path substitutions; mathematical formulas/logic are NOT edited.
"""
import argparse,tempfile,zipfile,pathlib,json,sys,hashlib,subprocess
EXPECTED={'c05':'05dbf2e77beed44430109aa54ebc0c83d373d170d86d6a6c753d574636c088dc','c04':'4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629'}

def h(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def check_file(p,name):
 if not p or not p.is_file():raise RuntimeError('MISSING_DECLARED_DEPENDENCY_'+name)
 if name in EXPECTED and h(p)!=EXPECTED[name]:raise RuntimeError('SOURCE_HASH_MISMATCH_'+name)

def main():
 p=argparse.ArgumentParser(description='C05 portable regression, no hard-coded absolute directory')
 p.add_argument('--c05',type=pathlib.Path,required=True);p.add_argument('--c04',type=pathlib.Path);p.add_argument('--r160-zip',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path);p.add_argument('--functional-only',action='store_true')
 a=p.parse_args();check_file(a.c05,'c05')
 if not a.functional_only:check_file(a.c04,'c04');check_file(a.r160_zip,'r160')
 runs=[]
 with tempfile.TemporaryDirectory(prefix='dm_c06_external_extract_') as td:
  work=pathlib.Path(td)/'completely-new-root-not-cycle5';work.mkdir()
  with zipfile.ZipFile(a.c05) as z:
   if z.testzip() is not None:raise RuntimeError('C05_CRC_FAIL')
   z.extractall(work)
  # Only change IO references: no arithmetic or criteria edits.
  replacements={'/mnt/data/dmg_succession/cycle5':str(work),'/mnt/data/DMG_F0_C04_CORPUS_EFICIENCIA_VLAB_20261016_MESTRE_ONLY.zip':str(a.c04.absolute()) if a.c04 else '/MISSING_C04_DEPENDENCY'}
  for filename in ['c05_functional_tests.py','c05_terminal_cross_audit.py','r160_reaudit.py']:
   source=work/filename;txt=source.read_text()
   for before,after in replacements.items():txt=txt.replace(before,after)
   source.write_text(txt)
  if a.r160_zip:
   (work/'incoming').mkdir(exist_ok=True)
   # external source ZIP remains read-only, local reference is symlink no byte copy
   (work/'incoming'/'VLAB_R151_R160_TACTICAL_R42_R43_CASULO_ED_BE_VERIFIED_MESTRE_ONLY.zip').symlink_to(a.r160_zip.absolute())
  scripts=['c05_functional_tests.py']+([] if a.functional_only else ['c05_terminal_cross_audit.py','r160_reaudit.py'])
  for name in scripts:
   completed=subprocess.run([sys.executable,str(work/name)],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
   runs.append({'script':name,'returncode':completed.returncode,'stdout':completed.stdout[-2000:],'stderr':completed.stderr[-2000:],'extraction_root':str(work),'relative_to_original_path':str(work)!='/mnt/data/dmg_succession/cycle5'})
   if completed.returncode:break
 result={'version':'PORTABILITY_C06','original_c05_hash':h(a.c05),'c04_dependency':h(a.c04) if a.c04 else 'OMITTED_FUNCTIONAL_ONLY','r160_original_hash':h(a.r160_zip) if a.r160_zip else 'OMITTED_FUNCTIONAL_ONLY','tested_in_new_directory':True,'run_results':runs,'pass':all(r['returncode']==0 for r in runs) and len(runs)==len(scripts),'semantic_edits_to_C05_math':False,'mutation_scope':'temporary extracted C05 copies and optional caller-selected report only'}
 if a.output:
  a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 if not result['pass']:sys.exit(2)
if __name__=='__main__':main()
