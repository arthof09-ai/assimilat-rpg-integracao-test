#!/usr/bin/env python3
"""Produce C06 auditable artifacts from typed source assertions and read-only R160 receipt CSV."""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as Q
import json,csv,sys,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from experimental_damage_calc import metrics
from c06_damage_resolver import evaluate_spell,evaluate_physical,mode_distribution,dot_effect,component_effect,dist,mean,pack
from c06_r160_observer import load,summary
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
W=lambda fn,data:(OUT/fn).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
N='https://app.notion.com/p/'
refs={'feryn':N+'3f6c2b324ede81ce9c61db8127bf0e31','eristan':N+'3f6c2b324ede819cae98ec0f6a63de76','auren':N+'3ebc2b324ede814bb730d47dd7bd5f02','combat':N+'3ebc2b324ede81f1be4be8804ac113c0','magic':N+'3ebc2b324ede81f7b343f7270ff91373'}
profile={'as_of':'2026-10-17 America/Recife','environment':'MESTRE-SIDE','canonical_rule_baseline':'DMG-RANK-01 v1.1 unchanged','Feryn':{'url':refs['feryn'],'notion_last_edit':'2026-10-16T10:33:13.379Z','authority':'MESTRE_SIDE_PROPOSED_NPC_NOT_OFFICIAL_PRODUCTION','spell':'Turbilhão Cinzento','action':'PADRAO','cost_PA':60,'wind_formula':'9d10+8','area':'cone 8m','damage_type':'vento','delivery':'Per target REFLEXO VS LUTA DES 4d6+92, strictly higher save -> half; equal/full; no critical','limit':'instant; no additional attacks','free_PA':424,'weapon_attack':'4d6+92','weapon_damage_normal':'8d8+47 physical'},'Eristan':{'url':refs['eristan'],'notion_last_edit':'2026-10-16T10:33:32.392Z','authority':'MESTRE_SIDE_PROPOSED_NPC_NOT_OFFICIAL_PRODUCTION','Reflexo':'4d6+28','CA':76,'RD_fisico':25,'RD_vento':'NOT_DOCUMENTED','Vida_max':630},'Auren':{'url':refs['auren'],'notion_last_edit':'2026-09-30T23:10:35.044Z','Reflexo':'6d6+166','state':'combat atalho tested; other transformed values exist - do not mix','RD_vento':'NOT_DOCUMENTED'},'system_sources':{'combat':refs['combat'],'magic':refs['magic'],'strict_rule':'Target save must SURPASS source attack roll; equal does not halve'},'undetermined':['RD vento vs Eristan/Auren','rounding of half of odd HP','actual simultaneous targets in cone','physical critical odds in C06 conditional comparison','reaction/reflection activation']}
W('C06_FERYN_ERISTAN_AUREN_SOURCE_PROFILE.json',profile)
full=evaluate_spell(attacker_formula='4d6+92',defender_formula='4d6+28',damage_formula='9d10+8',damage_type='vento',cost=60,action='PADRAO',source_refs=[refs['feryn'],refs['eristan']])
half=evaluate_spell(attacker_formula='4d6+92',defender_formula='6d6+166',damage_formula='9d10+8',damage_type='vento',cost=60,action='PADRAO',source_refs=[refs['feryn'],refs['auren']])
rounding={k:evaluate_spell(attacker_formula='4d6+92',defender_formula='6d6+166',damage_formula='9d10+8',damage_type='vento',cost=60,action='PADRAO',source_refs=[refs['feryn'],refs['auren']],half_rounding=k)['damage']['hp_effective_expected'] for k in ['RATIONAL_TEST','FLOOR_TEST','CEIL_TEST']}
physical=evaluate_physical(attacker_roll='4d6+92',defender_ca=76,damage_formula='8d8+47',damage_type='fisico',source_refs=[refs['feryn'],refs['eristan']],rd=25,rd_type='fisico',rd_evidence='DOCUMENTED')
physical['source_weapon']='One standard attack with equipped pair; no additional attack; crit not modeled and must not be mistaken for exact complete physical expected'
scenarios={f'RD_VENTO_TEST_{v}':mode_distribution('9d10+8',damage_type='vento',rd_value=v,rd_type='vento',rd_evidence='TEST',pa_cost=60)['hp_effective_expected'] for v in (0,1,2,3,10,57,98,99)}
app={'Feryn_vs_Eristan':full,'Feryn_vs_Auren':half,'half_rounding_alternatives':rounding,'physical_weapon_vs_Eristan':physical,'wind_RD_TEST_sensitivity':scenarios,'conditional_2_targets_no_independence_assumed':mode_distribution('9d10+8',damage_type='vento',pa_cost=60,target_count=2)['total_expected_HP_if_each_target_eligible'],'classification':'SOURCE_DOCUMENTED_FORMULA + LIMITED_EXPERIMENTAL_RESOLUTION; NO_COMBAT_RUN','numeric_conclusion':'normal physical 8d8+47 vs physical RD25 -> E=58 per landed hit; Turbilhao 9d10+8 vs documented failed Reflexo -> E=57.5 before unknown wind RD, PA60; physical crit intentionally omitted; WIND area may change efficiency only if >=2 valid targets'}
W('C06_INTEGRATED_FERYN_OFFENSE_EVALUATION.json',app)
# 82-point PMF plus exact checks generated automatically
with (OUT/'C06_FERYN_9D10_PLUS8_PMF.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.writer(f);w.writerow(['damage','probability_numerator','probability_denominator','source','damage_channel','classification'])
 for v,p in dist('9d10+8').items():w.writerow([v,p.numerator,p.denominator,refs['feryn'],'Vida / Vento','SOURCE_LITERAL_IN_PROPOSED_NPC; NO_AUTO_RD'])
# five physical variants, don't collapse identity with equal name
variants=[
 ('266c2b324ede8258b97c017633c22ca6','Prata 5','Grifo Guardião','Ouro','7f5c2b324ede83fbaa310131884fb636','Ouro 5/Luz',500,700,44,'10/33/20/40/10/10','Garras Terrafirmes; Voo Tempestuoso; Olhar Penetrante','NONE','2026-10-01T18:01:03.896Z','POSSIBLE_SIBLING_SAME_BODY_BUT_STATS_DIFFER'),
 ('95cc2b324ede82cabae401bc73662386','Prata 5','Grifo Guardião','Ouro','225c2b324ede82a9a05d0104c2f94990','Ouro 5/Luz',400,600,47,'10/33/20/40/10/10','Garras Terrafirmes; Voo Tempestuoso; Olhar Penetrante','NONE','2026-10-01T18:01:03.648Z','POSSIBLE_SIBLING_SAME_BODY_BUT_STATS_DIFFER'),
 ('6f9c2b324ede82dfb9a5812d7fd2ed48','Prata 5','Tempestade Sombria','Lendário','d09c2b324ede8312a2d8814a16d28c00','Ouro 5/Raio',450,490,52,'40/37/25/29/13/3','Garras do Relâmpago; Rugido Trovejante; Aura de Tempestade','NONE','2026-10-01T18:00:51.474Z','VARIANT_SIBLING_NOT_INDEPENDENT_BY_DEFAULT'),
 ('a59c2b324ede82a9b464810a3e5c0962','Ouro 5','Leão Draconiano da Tempestade','Lendário','d09c2b324ede8312a2d8814a16d28c00','Ouro 5/Raio',930,750,73,'74/57/32/20/16/15','Rugido do Trovão; Garras de Energia; Manipulação da Tempestade','NONE','2026-10-01T18:00:52.695Z','VARIANT_SIBLING_NOT_INDEPENDENT_BY_DEFAULT'),
 ('be0c2b324ede8336b8348165d395226d','Ouro 2','Beemote das Plumas de Gelo','NOT_DECLARED','e1ec2b324ede82f3ae250179bc746953','Ouro 5/Gelo',552,1200,67,'12/54/16/70/16/4','Sopro Gélido; Guarda Glacial; Voo Gélido; Invocação de Nevasca; Aura Congelante','INDETERMINATE_DOT_POWER_AND_DURATION','2026-10-01T18:00:44.263Z','LACKS_BODY_RANK_AND_DAMAGE_POWER'),
]
with (OUT/'C06_FIVE_DEEP_VARIANTS_FORENSIC.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.writer(f);w.writerow(['uuid','url','page_title','body_identity','body_rank','parent_uuid','ancestor_rank_element','life','soul','CA','attributes_FOR_DES_CON_INT_SAB_CAR','abilities_literal_names','HP_damaging_numeric_formula','Notion_last_edit','classification_issue','L002_L003_membership','statistical_eligibility'])
 for x in variants:
  uid,title,name,rank,parent,anc,life,soul,ca,attrs,abilities,formula,edit,conflict=x
  w.writerow([uid,N+uid,title,name,rank,parent,anc,life,soul,ca,attrs,abilities,formula,edit,conflict,'UNKNOWN_ORIGINAL_LOTS_NOT_BINARY_RECOVERED','EXCLUDE_FROM_NUMERIC_DAMAGE_COMPARISON'])
# DOT: positive documented incremental source, but trigger unresolved: Frígido extra 1d4 Gelo after hit only IF activation proven.
W('C06_TEMPORAL_AND_COMPONENT_POLICY.json',{'negative':[{'source':N+'be0c2b324ede8336b8348165d395226d','effect':'Aura Congelante','status':dot_effect(potency_formula=None,duration_ticks=None,trigger=None,damage_type='gelo')}], 'positive_conditional':[{'source':N+'f0dc2b324ede820ab9470168d4a53315','effect':'Lâminas Ósseas Geladas: +1d4 Gelo','component':'1d4 Gelo','status':component_effect(parts=[{'formula':'1d6+18','type':'fisico'},{'formula':'1d4','type':'gelo'}],each_part_activated=False),'notes':'Do not add 1d4 to Rabada automatically; no trigger/stacking proven'},{'source':'TEST_DO_NOT_ATTRIBUTE_TO_BEEMOTE','effect':'Demonstration only: 1d4 per tick x 2 documented hypothetical ticks','status':dot_effect(potency_formula='1d4',duration_ticks=2,trigger='EACH_TURN_TEST',roll_policy='INDEPENDENT_EACH_TICK',channel='HP',damage_type='gelo')}], 'channels':['Vida','Alma','PA','Controle','Cura'],'quality_gate':'NO_DOT_NUMBER_WHEN_MISSING_POWER_OR_DURATION'})
# R157 fixed-tape counterfactual, not a true new replay
rows=load();byrun=defaultdict(list)
for r in rows:byrun[r['run_id']].append(r)
ran={}
for rn in ['R157_TACTIC_BASIC_DEV_S997617','R157_TACTIC_WIND_DEV_S997617']:
 r=byrun[rn]
 actors={actor:{k:sum(int(x[k]) for x in r if x['actor']==actor) for k in ['damage_raw','rd_applied','net_post_RD','hp_effectively_lost','overkill','PA_spent']} for actor in ('F','E')}
 spells=[int(x['damage_raw']) for x in r if x['actor']=='F' and x['action']=='spell']
 ran[rn]={'source_receipts':len(r),'actors_reported':actors,'feryn_casts':len(spells),'feryn_wind_raw_rolls':spells,'target_e_hp_expected_native_state_start':630,'feryn_HP_realized_reported_source':actors['F']['hp_effectively_lost']}
wind=ran['R157_TACTIC_WIND_DEV_S997617'];basic=ran['R157_TACTIC_BASIC_DEV_S997617']
delta=[]
for rd in range(0,61):
  wind_effective=sum(max(0,x-rd) for x in wind['feryn_wind_raw_rolls'])+41 # last documented physical 66 - RD físico25
  delta.append({'RD_wind_TEST':rd,'Feryn_wind_fixed_tape_HP':wind_effective,'Feryn_basic_fixed_tape_HP':basic['actors_reported']['F']['hp_effectively_lost'],'difference_FIXED_TAPE':wind_effective-basic['actors_reported']['F']['hp_effectively_lost'],'validity':'NUMERIC_COUNTERFACTUAL_ONLY_NO_AI_REPLAY'})
r157={'comparison_seed':'997617 DEVELOPMENT 1 paired seed; not independent holdout','runs':ran,'R157_source_reported_scenario_effective_HP':[912,928],'R157_per_receipt_raw_HP_totals':[925,941],'difference_explained_by_final_Eristan_spell_receipt_HP_OVERCLAIM':[13,13],'feryn_policy_diff_HP':16,'feryn_policy_diff_PA':420,'observed_marginal_HP_per_added_PA':str(Q(16,420)),'wind_spells_seven_x60_PA':420,'wind_RD_authentic':'NOT_DOCUMENTED_ERISTAN_HAS_RD_FISICO25_ONLY','fixed_roll_sensitivity':delta,'warning':'RD changes might affect decisions and RNG; same roll tape is not a new executed combat; after 8 rounds further skill availability not derived','half_rounding':'TURB_SAVE_FAILED_IN_R157_ALL_7_AS_RECORDED; NOT AN EVEN_HALF_TEST'}
W('C06_R157_CAUSAL_SENSITIVITY_NOT_REPLAY.json',r157)
 # simple per-event query snapshots
sr=summary(rows);sr['nonduplicated_event_tuple']=['run_id','seq_R18','action_index_in_tx'];sr['R156']='excluded unknown_effect';sr['native_state_discrepancy_ref']='C06_R160_NATIVE_STATE_DISCREPANCIES.json'
W('C06_R160_EVENT_BRIDGE_SUMMARY.json',sr)
W('C06_POWER_CONDITIONAL_SCENARIOS.json',{'case_a':'Feryn vs Eristan normal physical vs Turbilhao single-target; physical 8d8+47, hit automatic against CA76, documented RD25 physical -> expected58 WITHOUT CRITICAL; Turbilhao 9d10+8 always full due Reflexo4d6+28 vs4d6+92, expected57.5 BEFORE UNKNOWN VENTO RD; PA60; no universal balance conclusion','case_b':'at two individually eligible targets in cone, no RD wind and no HP caps, E(sum)=115 per cast at same PA60; whether two targets are reachable is not documented; correlation affects variance not expectation','case_c':'Auren Ref6d6+166 always saves vs Feryn, expected 28.75 rational half, 28.5 floor or29 ceil; rounding policy unknown; RD wind remains unknown','case_d':'Physical strike with greater raw may lose against defense source-conditioned if CA higher, not asserted win probability across target categories','case_e':'Observed R157 tactical policy wind spent420 PA more for +16 realized HP at RD Wind 0 lab assumption; source RD wind unknown; only one DEV seed'})
print(json.dumps({'profile':'DONE','five_variants':5,'Feryn_vs_Eristan_gross':full['damage']['gross_expected'],'physical_normal_E':physical['hit_conditional']['post_RD_expected'],'R157_paired_delta':16,'R160_events':sr['n_events']},ensure_ascii=False))
