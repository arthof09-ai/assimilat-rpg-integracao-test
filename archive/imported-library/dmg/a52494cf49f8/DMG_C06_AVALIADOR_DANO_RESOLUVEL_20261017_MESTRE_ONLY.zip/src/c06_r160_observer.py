#!/usr/bin/env python3
"""C06 read-only per-event R160 evidence queries; optionally verify native SQLite.
Do not treat events as independent seeds, or csv hp_effectively_lost as verified state delta.
"""
import argparse,csv,collections,json,hashlib,sqlite3,zipfile,tempfile,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
DEFAULT=ROOT/'data'/'R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv'
METRICS=['damage_raw','rd_applied','net_post_RD','hp_effectively_lost','overkill','PA_spent']

def load(path=DEFAULT):
 with open(path,encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 if len(rows)!=154: raise ValueError('R160_COUNTS_CHANGED expected154 actual'+str(len(rows)))
 ids=[(r['run_id'],r['seq_R18'],r['action_index_in_tx']) for r in rows]
 if len(ids)!=len(set(ids)):raise ValueError('DUPLICATE_EVENT_ID')
 for r in rows:
  for k in METRICS:
   if not r[k].isdigit():raise ValueError('NONINTEGER_FIELD_'+k)
  if int(r['damage_raw'])!=int(r['rd_applied'])+int(r['net_post_RD']):raise ValueError('BAD_RAW_IDENTITY')
  if int(r['net_post_RD'])!=int(r['hp_effectively_lost'])+int(r['overkill']):raise ValueError('BAD_REPORTED_NET_IDENTITY')
 return rows

def summary(rows):
 d={'n_events':len(rows),'n_runs':len(set(x['run_id'] for x in rows)),'by_origin':dict(collections.Counter(x['attack_origin'] for x in rows)),'by_resolution':dict(collections.Counter(x['hit'] for x in rows)),'by_critical':dict(collections.Counter(x['critical'] for x in rows)),'totals_reported':{k:sum(int(x[k]) for x in rows) for k in METRICS},'one_event_is_not_one_seed':True,'native_state_overkill_not_inferred_from_reported_overkill':True,'handoff':'PREPARED_NO_ACK','R156':'UNKNOWN_EFFECT_HOLD'}
 return d

def native_check(rows, source_zip):
 result=[];sampled=0;with_both=0
 with zipfile.ZipFile(source_zip) as z, tempfile.TemporaryDirectory() as td:
  if z.testzip() is not None:raise ValueError('R160_ZIP_BAD_CRC')
  manifest=json.loads(z.read('R160_SHA256_MANIFEST.json'))
  if len(manifest['files'])!=365:raise ValueError('R160_MANIFEST_COUNT_CHANGED')
  for item in manifest['files']:
   b=z.read(item['path'])
   if len(b)!=item['size'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('R160_MEMBER_INVALID_'+item['path'])
  embedded=z.read('r151_r160/R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv')
  if embedded!=pathlib.Path(DEFAULT).read_bytes():raise ValueError('R160_CSV_NOT_BINARY_IDENTICAL_TO_ORIGINAL')
  byrun=collections.defaultdict(list)
  for r in rows:byrun[r['run_id']].append(r)
  commits=0
  for run,arr in sorted(byrun.items()):
   raw=z.read(f'r151_r160/runs/{run}.sqlite');q=pathlib.Path(td)/(run+'.sqlite');q.write_bytes(raw)
   # URI read-only, immutable snapshot in disposable directory.
   conn=sqlite3.connect('file:'+str(q)+'?mode=ro',uri=True)
   if conn.execute('select count(*) from pending').fetchone()[0]:raise ValueError('PENDING_'+run)
   ledger={str(seq):(cmd,row,hashv) for seq,cmd,row,hashv in conn.execute('select seq,cmd_id,row_json,row_sha from events')}
   commits+=len(ledger)
   for r in arr:
    cmd,rawrow,hashv=ledger[r['seq_R18']];ev=json.loads(rawrow)
    detail=ev.get('detail') or {};acts=detail.get('native_actions') or ([detail['native_action']] if detail.get('native_action') else [])
    act=acts[int(r['action_index_in_tx'])-1];sampled+=1
    if cmd!=r['cmd_id'] or hashv!=r['row_SHA256']:raise ValueError('SOURCE_ID_MISMATCH_'+run)
    if any(int(act.get(key) or 0)!=int(r[field]) for key,field in [('raw','damage_raw'),('rd_applied','rd_applied'),('PA_spent','PA_spent')]):raise ValueError('NATIVE_RECEIPT_MISMATCH_'+run)
    before=act.get('hp_before');after=act.get('hp_after')
    if before is not None and after is not None:
     with_both+=1;observed=max(0,int(before)-int(after));reported=int(r['hp_effectively_lost'])
     if reported!=observed:
      result.append({'run_id':run,'seq':r['seq_R18'],'action_index':r['action_index_in_tx'],'actor':r['actor'],'target':r['target'],'action':r['action'],'hp_before':int(before),'hp_after':int(after),'receipt_hp_effectively_lost':reported,'native_actual_hp_drop':observed,'overstatement':reported-observed,'receipt_overkill':int(r['overkill']),'corrected_overkill_if_pre_rd_action_metric':int(r['overkill'])+(reported-observed),'row_SHA256':r['row_SHA256']})
   conn.close()
 if commits!=466 or sampled!=154:raise ValueError('R160_BASELINE_LEDGER_CHANGED')
 return {'zip_crc':True,'manifest_members_verified':365,'native_commits':commits,'native_events_verified':sampled,'events_with_both_hp_snapshots':with_both,'other_events_hp_snapshot_missing':sampled-with_both,'event_state_disagreements':result,'discrepancy_count':len(result),'overstatement_on_checked_events':sum(x['overstatement'] for x in result),'global_corrected_hp_if_all_remaining_reported_labels_trusted':sum(int(r['hp_effectively_lost']) for r in rows)-sum(x['overstatement'] for x in result),'global_corrected_hp_status':'CONDITIONAL_NOT_CERTIFIED_FOR_122_ROWS','source_scope':'VLAB_DEV_TECHNICAL_NOT_CANONICAL','R156':'UNKNOWN_EFFECT_NO_RETRY'}

def query(rows,run=None,actor=None,target=None,origin=None,action=None):
 q=[r for r in rows if (run is None or r['run_id']==run) and (actor is None or r['actor']==actor) and (target is None or r['target']==target) and (origin is None or r['attack_origin']==origin) and (action is None or r['action']==action)]
 return {'filters':{'run':run,'actor':actor,'target':target,'origin':origin,'action':action},'summary':summary(q),'events':q[:200]}

if __name__=='__main__':
 p=argparse.ArgumentParser(description='DMG read-only R160 query')
 p.add_argument('--csv',type=pathlib.Path,default=DEFAULT);p.add_argument('--r160-zip',type=pathlib.Path);p.add_argument('--run');p.add_argument('--actor');p.add_argument('--target');p.add_argument('--origin');p.add_argument('--action');p.add_argument('--summary-only',action='store_true');p.add_argument('--native-audit',action='store_true')
 a=p.parse_args();r=load(a.csv);o=query(r,a.run,a.actor,a.target,a.origin,a.action)
 if a.summary_only:o.pop('events')
 if a.native_audit:
  if not a.r160_zip: p.error('--native-audit REQUIRES --r160-zip <original authenticated R160 ZIP>')
  o['native_audit']=native_check(r,a.r160_zip)
 print(json.dumps(o,ensure_ascii=False,indent=2))
