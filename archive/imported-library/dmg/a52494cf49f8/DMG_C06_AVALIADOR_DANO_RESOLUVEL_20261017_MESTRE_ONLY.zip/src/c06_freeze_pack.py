#!/usr/bin/env python3
"""Freeze C06 research artifact with recursive SHA-256 manifest; archive remains portable."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/DMG_C06_AVALIADOR_DANO_RESOLUVEL_20261017_MESTRE_ONLY.zip')
FILES=[]
for prefix in ('src','tests','data','evidence','qa','docs','handoff'):
 for p in (ROOT/prefix).rglob('*'):
  if p.is_file() and not ('__pycache__' in p.parts or p.suffix=='.pyc'):FILES.append(p)
FILES.extend([ROOT/'DMG_C06_CONSULTA_MESTRE_MOBILE.html',ROOT/'PSV_DMG_C06_AVALIADOR_RESOLUVEL_20261017_MESTRE_ONLY.md'])
FILES=sorted(FILES,key=lambda x:str(x.relative_to(ROOT)))
manifest={'operation':'OP-DMG-CORPUS-EMP-01','checkpoint':'C06','as_of':'2026-10-17 America/Recife','baseline':'DMG-RANK-01 v1.1 unchanged','source_c05_sha256':'05dbf2e77beed44430109aa54ebc0c83d373d170d86d6a6c753d574636c088dc','files':[{'path':str(p.relative_to(ROOT)),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in FILES]}
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in FILES:z.write(p,str(p.relative_to(ROOT)))
 z.writestr('C06_SHA256_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(FILES)+1
 for x in manifest['files']:
  b=z.read(x['path']);assert len(b)==x['size'] and hashlib.sha256(b).hexdigest()==x['sha256']
print(json.dumps({'path':str(OUT),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'zip_entries':len(FILES)+1,'manifest_members_passed':len(FILES),'crc':'PASS'},indent=2))
