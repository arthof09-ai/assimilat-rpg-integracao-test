# HANDOFF C06 → VLAB — MESTRE-ONLY, PREPARED / NÃO ACK

**Origem:** OP-DMG-CORPUS-EMP-01; **destino previsto:** OP-VLAB-FUSION-SANDBOX-01; **as-of:** 17/10/2026. **Sem roteamento confirmado ou ACK; não escrevi na Inbox ou na OP VLAB.** Pacote experimental somente de leitura, sem proposta de motor concorrente.

## Evidência urgente: rótulo de PV efetivos no R160

`C06_R160_NATIVE_STATE_DISCREPANCIES.json`: os eventos R157 BASIC seq48 e R157 WIND seq48 registram cada um `hp_effectively_lost=73`, mas o defensor tinha 60 PV e terminou com 0; evento R158 seq48 registra 59 apesar de antes=48 e depois=0. Excesso documental 13+13+11=37 PV. A auditoria C05/R160 2637/2637 valida correspondência recibo↔native, **não** validade semântica de `hp_effectively_lost` contra os estados nativos. Verificar modelo de recibo e reconciliação de Vida sem modificar SQLite históricos, sem reexecutar R156. Só 32/154 eventos tinham hp_before/after no native payload; para os demais exigir recuperação por estado/ledger em verificação futura. Falha pode inflar agregados e contaminar eficiência.

## Casos científicos discriminantes, não executados

### VLAB-H1 — Diferença entre teste ofensivo e salvaguarda
Fonte: [Feryn](https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31), [Eristan](https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76) e [Auren](https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02). Turbilhão `9d10+8`, 60 PA, Padrão, `4d6+92` vs Reflexo; Eristan `4d6+28`, Auren `6d6+166` (estado de combate específico). Resultado matemático previsto: Eristan **nunca** salva; Auren **sempre** salva. Métrica: paridade entre saves do motor e PMF matemática, causa de empate. Confundidores: reação de reflexão, estado transformado, habilidades fora do escopo. Pré-requisitos: posicionamento válido, ação/PA disponível, RD vento definida ou cenário sem RD explicitamente TEST. Aceite: recibo causal fiel, recurso/vida reconciliados, sem escalada normativa.

### VLAB-H2 — RD de Vento versus dano efetivo
Fonte: Feryn Turbilhão contra Eristan; `RD físico25` é documentação REAL, **não RD vento**. Não existe RD Vento admissível na ficha revisitada. Condição de admissão: recuperar fonte competente de RD Vento, ou executar múltiplas cópias TEST identificadas separadamente e sem alteração de ficha original. Variável: RD Vento por evento, pré-registrada. Métrica: dano realizado, overkill, ações e economia de PA. Critério discriminante: redução/ponto de anulação observáveis, consistência por tipo. Nunca usar RD física como substituta.

### VLAB-H3 — R157 BASIC vs WIND, causalidade tática
**Seed 997617 é DESENVOLVIMENTO e já explorada: NÃO é holdout.** BASIC 433 PV realizados por Feryn, WIND 449 (+16); custo ofensivo adicional de WIND 7 × 60=420 PA; Eristan ganha ambos os cenários técnicos. Estudo no DMG com rolagens FIXAS RD vento TEST `delta=16-7×RD` para RD0–52; inversão no cenário aritmético RD3. Isso **não** constitui replay: a nova RD pode mudar ações futuras, alvo, RNG e horizonte. Para testar causalidade: preregistrar políticas, sequência e condições antes de uma *nova* seed independente aprovada pelo VLAB, comparar em cópias distintas e registrar censura. Métrica primária PV efetivos por ator e PA consumidos. Aceite: estados antes/depois, eventos, overkill corrigido, não apenas totais iguais.

### VLAB-H4 — Precisão vs dano bruto
Usar Feryn ataque físico normal `4d6+92`, `8d8+47`, versus Eristan CA76 e RD físico25; teste sempre supera CA, média condicional após RD 58 PV sem crítico. Turbilhão média57,5 pré-RD Vento, custa60 PA, sem crítico. Em outros defensores, buscar exemplo fonte-válido com probabilidade de acerto entre 0 e 1 e comparar expectativa por tentativa. Não definir defesa/PA genérica fictícia. Métrica principal expectativa pós-RD por ação elegível, incluindo política de crítico oficial quando aplicável. Censura de combates inconclusivos.

### VLAB-H5 — Multi-alvo não equivale a golpes extras
Turbilhão é 9d10+8 **por alvo** num cone 8m; 60 PA **por conjuração**. Caso com dois alvos somente após comprovar posição, área e salvaguardas; expectativa condicional pré-RD 115 PV somados se ambos elegíveis e falharem. Não dividir 60 PA em múltiplas ativações ou declarar alvos hipotéticos como fonte. Registrar se as rolagens de dano são compartilhadas ou independentes para calcular variância; a média total é linear. Aceite: 1 ação/1 custo, N alvos reais, cada alvo único, ledger íntegro.

### VLAB-H6 — Censura e identidade de fonte
Combates com fontes propostas versus canônicas separados. Preservar R138 HOLD espacial e R156 UNKNOWN_EFFECT, sem reruns; impedir múltiplos eventos da mesma cena como seeds independentes. Preferir nova amostra que consiga provar uma conclusão discriminante sem produzir empate de ataque inevitável; se houver impasse, resultado deve permanecer **CENSORED**. Reserva de holdout independente feita por revisor competente, sem examinar nem substituir as oito reservas antigas do DMG.

## Campos a devolver ao DMG, quando autorizado
RUN-ID, hash da fonte, ID e revisão dos atores, seed, config experimental, origem da ação, evento nativo/seq/row-sha, estado PV antes/depois, PA antes/depois, RD por tipo comprovada, tiras RNG, condições de Reflexo, política de arredondamento, gasto real de ação, overkill baseado em PV, número real de alvos, regra aplicada, horizonte/censura, handoff com ACK. **Sem edição da ficha canônica, Party, O Primeiro, VLAB motor ou SQLite histórico.**
