#!/usr/bin/env python3
"""C06 cross-artifact audit, independent arithmetic from production resolver."""
import pathlib,json,csv,math,collections,hashlib,sys
from fractions import Fraction as F
ROOT=pathlib.Path(__file__).resolve().parents[1];E=ROOT/'evidence';Q=ROOT/'qa';Q.mkdir(exist_ok=True)
passed=0
def ck(ok,label):
 global passed
 if not ok:raise AssertionError(label)
 passed+=1
r=lambda fn:json.loads((E/fn).read_text())
rows=lambda fn:list(csv.DictReader(open(E/fn,newline='',encoding='utf8')))
profile=r('C06_FERYN_ERISTAN_AUREN_SOURCE_PROFILE.json');ck(profile['Feryn']['cost_PA']==60,'cost')
ck(profile['Feryn']['wind_formula']=='9d10+8','spell')
ck(profile['Eristan']['RD_vento']=='NOT_DOCUMENTED','no invented wind RD')
ck(profile['Eristan']['RD_fisico']==25,'physical rd')
ck(profile['Eristan']['Reflexo']=='4d6+28','save eristan')
ck(profile['Auren']['Reflexo']=='6d6+166','save auren')
calc=r('C06_INTEGRATED_FERYN_OFFENSE_EVALUATION.json');ck(calc['Feryn_vs_Eristan']['opposed']['defender_strict_success']=='0','eristan full')
ck(calc['Feryn_vs_Auren']['opposed']['defender_strict_success']=='1','auren half')
ck(calc['Feryn_vs_Auren']['damage']['status']=='PARTIAL_HALF_ROUNDING_UNKNOWN','odd policy pending')
ck(calc['physical_weapon_vs_Eristan']['p_hit']=='1','physical always hit in noncrit model')
ck(calc['physical_weapon_vs_Eristan']['hit_conditional']['post_RD_expected']=='58','phys after RD')
ck(calc['Feryn_vs_Eristan']['damage']['post_RD_expected']=='115/2','wind pre RD')
ck(calc['conditional_2_targets_no_independence_assumed']=='115','two target linear only')
ck(calc['half_rounding_alternatives']=={'RATIONAL_TEST':'115/4','FLOOR_TEST':'57/2','CEIL_TEST':'29'},'round')
# independent count of 9d10 dice results using inclusion-exclusion (no imported resolver).
pc=rows('C06_FERYN_9D10_PLUS8_PMF.csv');ck(len(pc)==82,'pmf 82 outcomes')
for x in pc:
 value=int(x['damage']);s=value-8;ways=sum((-1)**j*math.comb(9,j)*math.comb(s-10*j-1,8) for j in range(10) if s-10*j-1>=8)
 ck(F(int(x['probability_numerator']),int(x['probability_denominator']))==F(ways,10**9),'direct inclusion exclusion '+str(value))
ck(sum(F(int(x['probability_numerator']),int(x['probability_denominator'])) for x in pc)==1,'PMF sum')
ck(sum(int(x['damage'])*F(int(x['probability_numerator']),int(x['probability_denominator'])) for x in pc)==F(115,2),'PMF mean')
variants=rows('C06_FIVE_DEEP_VARIANTS_FORENSIC.csv');ck(len(variants)==5 and len({x['uuid'] for x in variants})==5,'5 physical refs unique')
for x in variants:
 ck(x['url'].endswith(x['uuid']),'Notion URL')
 ck(x['HP_damaging_numeric_formula'] in ('NONE','INDETERMINATE_DOT_POWER_AND_DURATION'),'variants no damage invented')
 ck(x['statistical_eligibility']=='EXCLUDE_FROM_NUMERIC_DAMAGE_COMPARISON','rank and formula gate')
ck(sum(x['body_identity']=='Grifo Guardião' for x in variants)==2,'both Griffins')
ck({x['life'] for x in variants if x['body_identity']=='Grifo Guardião'}=={'500','400'},'Griffin life conflict preserved')
ck({x['CA'] for x in variants if x['body_identity']=='Grifo Guardião'}=={'44','47'},'Griffin CA conflict preserved')
ck(sum(x['body_rank']=='Lendário' for x in variants)==2,'two contested legendary bodies')
ck(sum(x['body_rank']=='NOT_DECLARED' for x in variants)==1,'beemote incomplete')
P=r('C06_TEMPORAL_AND_COMPONENT_POLICY.json');ck(P['negative'][0]['status']['status']=='INDETERMINATE_DOT_POWER_OR_DURATION_OR_TRIGGER','negative DOT')
ck(P['positive_conditional'][0]['status']['status']=='INDETERMINATE_COMPONENT_ACTIVATION','incremental condition unknown')
ck(P['positive_conditional'][1]['status']['status']=='EXACT_CONDITIONAL_DOT','TEST temporal')
obs=r('C06_R160_NATIVE_STATE_DISCREPANCIES.json');report=obs['native_audit'];ck(report['native_events_verified']==154,'154 native')
ck(report['manifest_members_verified']==365,'manifest 365')
ck(report['native_commits']==466,'466 commits')
ck(report['events_with_both_hp_snapshots']==32 and report['other_events_hp_snapshot_missing']==122,'PV state denominator')
ck(report['discrepancy_count']==3 and report['overstatement_on_checked_events']==37,'37 excess')
for row in report['event_state_disagreements']:
 ck(row['receipt_hp_effectively_lost']-row['native_actual_hp_drop']==row['overstatement'],'event causality delta')
 ck(row['hp_before']-row['hp_after']==row['native_actual_hp_drop'],'HP before/after')
ck(report['global_corrected_hp_status']=='CONDITIONAL_NOT_CERTIFIED_FOR_122_ROWS','no misleading global')
bridge=r('C06_R160_EVENT_BRIDGE_SUMMARY.json');ck(bridge['n_events']==154 and bridge['n_runs']==9,'R160 event/run denom')
ck(bridge['totals_reported']['hp_effectively_lost']==11845,'historical reported, not corrected claim')
ck(bridge['totals_reported']['PA_spent']==2395,'event PA')
R=r('C06_R157_CAUSAL_SENSITIVITY_NOT_REPLAY.json');ck(R['comparison_seed'].startswith('997617 DEVELOPMENT'),'DEV seed')
ck(R['feryn_policy_diff_HP']==16 and R['feryn_policy_diff_PA']==420,'paired delta')
wind=R['runs']['R157_TACTIC_WIND_DEV_S997617'];basic=R['runs']['R157_TACTIC_BASIC_DEV_S997617']
ck(wind['feryn_casts']==7 and basic['feryn_casts']==0,'7 wind and 0 basic')
ck(sum(wind['feryn_wind_raw_rolls'])==408,'7 documented spell raw scores')
ck(wind['feryn_HP_realized_reported_source']==449 and basic['feryn_HP_realized_reported_source']==433,'Feryn source realization')
ck(wind['actors_reported']['F']['PA_spent']==420,'7 spells paid')
for x in R['fixed_roll_sensitivity']:
 rd=x['RD_wind_TEST'];calculated=sum(max(0,v-rd) for v in wind['feryn_wind_raw_rolls'])+41
 ck(x['Feryn_wind_fixed_tape_HP']==calculated,'RD counterfactual exact '+str(rd))
 ck(x['difference_FIXED_TAPE']==calculated-433,'differential test '+str(rd))
ck(next(x['RD_wind_TEST'] for x in R['fixed_roll_sensitivity'] if x['difference_FIXED_TAPE']<0)==3,'breakpoint at TEST RD3')
port=json.loads((Q/'C06_PORTABILITY_FRESH_DIRECTORY.json').read_text());ck(port['pass'] is True and len(port['run_results'])==3,'portable 3 suites')
ck('functional tests 26 PASS' in port['run_results'][0]['stdout'],'legacy functional')
ck('"passed": 460' in port['run_results'][1]['stdout'],'cross audit')
ck('"passed": 2637' in port['run_results'][2]['stdout'],'R160 native audit')
ck(all(x['relative_to_original_path'] and x['returncode']==0 for x in port['run_results']),'different root valid')
ck((ROOT/'DMG_C06_CONSULTA_MESTRE_MOBILE.html').is_file(),'mobile user portal')
ck((ROOT/'handoff'/'C06_TO_VLAB_SCIENTIFIC_HANDOFF_PREPARED_NOT_ACK.md').is_file(),'VLAB prepared handoff')
result={'verdict':'PASS_LOCAL_TECHNICAL_NOT_BLIND_OR_CANONICAL','checks':passed,'passed':passed,'failed':0,'scope':'Five physical Notion variants, Feryn+two defenders, typed RD and exact PMFs, 154 R160 native events, 32 visible HP state pairs, 3 source semantic mismatches, R157 fixed tape, mobile UI, portability.','independence':'Independent exact combinatorial checker in same assistant process; no external human certification','normalization':'NO_NEW_FORMULA_FOR_FIVE_VARIANTS','NAC_PASS_02':'LOCAL_EVIDENCE_ONLY_F0_FORMAL_STILL_4_OF_8'}
(Q/'C06_INDEPENDENT_CROSS_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
