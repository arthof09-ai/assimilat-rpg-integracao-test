#!/usr/bin/env python3
"""Independent C06 focused regression. Run from any working directory."""
import sys, pathlib, math
from fractions import Fraction as F
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from c06_damage_resolver import *
from experimental_damage_calc import metrics

passed=0
def ck(ok,msg):
 global passed
 assert ok,msg
 passed+=1

def raises(f,contains):
 try:f()
 except (ValueError,NeedsSource) as e:ck(contains in str(e),'wrong error: '+str(e))
 else:raise AssertionError('missed reject '+contains)

# Feryn exact gross damage and unaltered C05 engine.
p=dist('9d10+8')
ck(len(p)==82,'support')
ck(min(p)==17 and max(p)==98,'support bounds')
ck(mean(p)==F(115,2),'gross mean')
ck(sum(p.values())==1,'PMF normalized')
ck(metrics('9d10+8')['gross_mean']==57.5,'C05 preserved')

# Independent exact counting oracle: n d m coefficient via binomial inclusion-exclusion.
def dice_ways(n,faces,s):
 return sum((-1)**j*math.comb(n,j)*math.comb(s-faces*j-1,n-1) for j in range(n+1) if s-faces*j-1>=n-1)
for value,pr in p.items():ck(pr==F(dice_ways(9,10,value-8),10**9),'independent closed-form pmf '+str(value))

Feryn='https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31'
Eristan='https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76'
Auren='https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02'
e=evaluate_spell(attacker_formula='4d6+92',defender_formula='4d6+28',damage_formula='9d10+8',damage_type='vento',cost=60,action='PADRAO',source_refs=[Feryn,Eristan])
ck(e['opposed']['defender_strict_success']=='0','Eristan max 52 below attacker min 96')
ck(e['damage']['status']=='EXACT_TEST_OR_DOCUMENTED_AS_SCOPED','full branch no rounding')
ck(e['damage']['hp_effective_expected']=='115/2','Eristan before wind rd expected')
ck(e['damage']['expected_hp_per_PA']=='23/24','Eristan ratio 57.5/60')
ck(e['damage']['RD']=='MISSING','RD wind unknown')

a=evaluate_spell(attacker_formula='4d6+92',defender_formula='6d6+166',damage_formula='9d10+8',damage_type='vento',cost=60,action='PADRAO',source_refs=[Feryn,Auren])
ck(a['opposed']['defender_strict_success']=='1','Auren min172>max116')
ck(a['damage']['status']=='PARTIAL_HALF_ROUNDING_UNKNOWN','Auren rounding still unresolved')
ck(a['damage']['half_exact_rational_expectation']=='115/4','half rational 28.75')
for mode,ex in [('RATIONAL_TEST','115/4'),('FLOOR_TEST','57/2'),('CEIL_TEST','29')]:
 x=evaluate_spell(attacker_formula='4d6+92',defender_formula='6d6+166',damage_formula='9d10+8',damage_type='vento',cost=60,action='PADRAO',source_refs=[Feryn,Auren],half_rounding=mode)
 ck(x['damage']['hp_effective_expected']==ex,'half scenario '+mode)

ck(mode_distribution('9d10+8',damage_type='vento',rd_value=100,rd_type='vento',rd_evidence='TEST')['hp_effective_expected']=='0','rd eliminates spell')
ck(mode_distribution('9d10+8',damage_type='vento',rd_value=20,rd_type='vento',rd_evidence='TEST')['hp_effective_expected']!='0','partial mitigated')
ck(mode_distribution('9d10+8',damage_type='vento',target_hp=10)['hp_effective_expected']=='10','HP cap and overkill')
ck(mode_distribution('9d10+8',damage_type='vento',target_hp=10)['overkill_expected']==str(F(95,2)),'overkill 47.5')
ck(mode_distribution('9d10+8',damage_type='vento',pa_cost=60,target_count=3)['total_expected_HP_if_each_target_eligible']==str(F(345,2)),'three eligible targets mean only')
ck(mode_distribution('9d10+8',damage_type='vento',pa_cost=60,pa_available=50)['status']=='NOT_EXECUTABLE_INSUFFICIENT_FREE_PA','PA unavailable')
raises(lambda:mode_distribution('9d10+8',damage_type='vento',rd_value=22,rd_type='fisico',rd_evidence='DOCUMENTED'),'RD_TYPE_MISMATCH')
raises(lambda:mode_distribution('9d10+8',damage_type='vento',rd_value=22,rd_type='vento'),'RD_PROVENANCE')
raises(lambda:evaluate_physical(attacker_roll='4d6+92',defender_ca=None,damage_formula='1d6+8',damage_type='fisico',source_refs=[Feryn]),'TARGET_CA_MISSING')
raises(lambda:mode_distribution('9d10+8',damage_type='vento',crit_policy='DEFAULT'),'CRITICAL_SOURCE_POLICY_REQUIRED')
ck(mode_distribution('1d4',damage_type='fisico',target_hp=0)['hp_effective_expected']=='0','zero HP')
ck(evaluate_physical(attacker_roll='1d4+10',defender_ca=14,damage_formula='1d6+8',damage_type='fisico',source_refs=[Feryn,Eristan])['p_hit']=='0','physical tie defense')
ck(evaluate_physical(attacker_roll='1d4+10',defender_ca=13,damage_formula='1d6+8',damage_type='fisico',source_refs=[Feryn,Eristan])['p_hit']=='1/4','physical ca')
ck(dot_effect(potency_formula=None,duration_ticks=3,trigger='ON_TURN')['status']=='INDETERMINATE_DOT_POWER_OR_DURATION_OR_TRIGGER','Beemote no number')
ck(dot_effect(potency_formula='1d4',duration_ticks=None,trigger='ON_TURN')['status']=='INDETERMINATE_DOT_POWER_OR_DURATION_OR_TRIGGER','dot missing ticks')
ck(dot_effect(potency_formula='1d4',duration_ticks=2,trigger='ON_TURN')['status']=='INDETERMINATE_DOT_ROLL_POLICY','dot roll policy missing')
ck(dot_effect(potency_formula='1d4',duration_ticks=2,trigger='ON_TURN',roll_policy='INDEPENDENT_EACH_TICK')['expected_total']=='5','dot independent two')
ck(dot_effect(potency_formula='1d4',duration_ticks=2,trigger='ON_TURN',roll_policy='SINGLE_ROLL_REUSED')['expected_total']=='5','dot same roll')
ck(component_effect(parts=[{'formula':'1d6','type':'fisico'},{'formula':'1d4','type':'vento'}],each_part_activated=False)['status']=='INDETERMINATE_COMPONENT_ACTIVATION','dependent added parts')
ck(component_effect(parts=[{'formula':'1d6','type':'fisico'},{'formula':'1d4','type':'vento'}],each_part_activated=True)['expected']=='6','composite exact mean')
ck(component_effect(parts=[{'formula':'1d6','type':'fisico'},{'formula':'1d4','type':'vento'}],each_part_activated=True,rd_mapping={'fisico':1})['status']=='INDETERMINATE_RD_FOR_COMPONENT_TYPE','composite typed rd incomplete')
ck(compare_rolls('4d6+92','4d6+92')['tie']>0,'tie possible')
print('C06 resolver focused checks PASS',passed)
(ROOT/'qa'/'C06_RESOLVER_TEST_COUNTS.json').write_text(__import__('json').dumps({'checks':passed,'passed':passed,'failed':0},indent=2)+'\n')
