# C06 — Guia de reprodução e consulta no telefone

**MESTRE-SIDE · DMG-RANK-01 v1.1 inalterada · Estudo experimental, não engine VLAB.**

## Usar pelo ChatGPT (sem terminal)

Pergunte, neste projeto: “Calcule o Turbilhão Cinzento de Sikong Feryn contra Eristan, separando Reflexo, RD documentada, Vida restante e PA. Não invente dados ausentes.” O calculador interno `src/c06_damage_resolver.py` executa a distribuição exata; os resultados de fontes verificadas estão em `evidence/C06_INTEGRATED_FERYN_OFFENSE_EVALUATION.json`.

Abra **`DMG_C06_CONSULTA_MESTRE_MOBILE.html`** no celular para mudar o defensor e simular RD Vento **TEST**, vida e quantidade de alvos. O HTML funciona offline sem servidor, mas não atribui valores TEST ao cânone e não salva estado do jogo.

## Reproduzir em outro diretório (Python padrão, sem instalar pacotes)

```bash
python src/c06_damage_resolver.py --attacker 4d6+92 --defender 4d6+28 --damage 9d10+8 --pa 60
python tests/test_c06_resolver.py
python src/c06_r160_observer.py --summary-only
python src/c06_r160_observer.py --run R157_TACTIC_WIND_DEV_S997617 --summary-only
```

**Dependências explícitas para auditoria histórica:**
- C05 ZIP original SHA256 `05dbf2e77beed44430109aa54ebc0c83d373d170d86d6a6c753d574636c088dc`
- C04 ZIP original SHA256 `4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629`
- R160 ZIP original SHA256 `7b208fe553809df6a999a1e4f9a70d7ad116033e929256bc71dbcd61843f3410`

Estes três ZIPs **não** foram duplicados dentro do C06. Recupere-os das pastas existentes DMG/VLAB. Ao não fornecê-los, a auditoria histórica dá erro claro em vez de fingir PASS:

```bash
python src/c06_portability.py --c05 /caminho/C05.zip --c04 /caminho/C04.zip --r160-zip /caminho/R160.zip --output /caminho/portability.json
python src/c06_portability.py --c05 /caminho/C05.zip --functional-only
python src/c06_r160_observer.py --native-audit --r160-zip /caminho/R160.zip --summary-only
```

O runner extrai o C05 em um **diretório temporário aleatório**, corrige **somente três caminhos de IO em scripts copiados** e executa os testes originais sem alterar o algoritmo. Testado com C04/R160 verdadeiros: 26/26, 460/460 e 2637/2637 PASS. `qa/C06_PORTABILITY_FRESH_DIRECTORY.json` comprova execução fora da pasta C05.

## Escopos de leitura

`C06_FIVE_DEEP_VARIANTS_FORENSIC.csv`: 5 identidades físicas, versões contraditórias; NÃO classificar drops como dano. `C06_R160_NATIVE_STATE_DISCREPANCIES.json`: 32 eventos com estados PV antes/depois e 3 falhas semânticas documentadas; outros 122 requerem modo independente de recuperar estado. `C06_R157_CAUSAL_SENSITIVITY_NOT_REPLAY.json`: só contrafactuais aritméticos, não novas lutas.

## Rejeições e limites

- Dano Vento não aceita RD Física pelo simples fato de ser RD.
- Feryn não sofre crítico no Turbilhão; arma física precisa política crítica própria para expectativa integral.
- Regra de metade ímpar ainda não adjudicada: frações TEST e arredondamentos alternativos explícitos.
- Quantidade real de alvos e posição dentro do cone ainda não comprovadas; n alvos condicionais.
- Sem custo, defesa ou condição da fonte, o campo fica INDETERMINATE.
- Dano de Alma, cura, controle, veneno por turno e overkill pertencem a canais separados.
- Não rodar ferramenta sobre SQLite histórico em modo escrita. Não reexecutar R156.
