"""C05: literal short excerpts transcribed from direct Notion Mestre fetches 2026-10-17.
No claim of full-page byte snapshots. One tuple per physically read leaf.
Tuple: UUID, parent species UUID, species-parent title, rank ancestor title, body classification,
FOR, DES, INT, relevant effect excerpts separated by semicolon.
Potential damage channels marked in final catalog; unquantified effects stay unresolved.
"""
DATA = r'''
a01c2b324ede8347b691819d3509d7d7|1cac2b324ede820ebbaf0105a747407f|Crocossuário|Prata 2 · 5|Bronze 5|22|20|6|Mordida Trituradora~1d6+1d4+For~VIDA;Cauda de Correnteza~SEM FORMULA~CONTROLE
f0dc2b324ede820ab9470168d4a53315|51cc2b324ede82d5940d81bef3c7c0cd|Frígido Ossário|Prata 3 · 1|Bronze 5|18|18|12|Rabada~1d6+força~VIDA;Lâminas Ósseas Geladas~+1d4 de gelo~INCREMENTO;Sopro Gélido~SEM FORMULA~CONTROLE
529c2b324ede82e8a86f81f8cfc0477e|e84c2b324ede83c696e8817b1c154103|Raposa Flamejante|Prata 5 · 2|Bronze 5|20|20|15|Punhos de fogo~1d4~VIDA;Soco~1d6 + força~VIDA;Passos flamejante~SEM FORMULA~PERSISTENTE_PENDENTE
35ec2b324ede823bbb5281e4b5ccf0d9|1adc2b324ede823fa30801fd1ca6cc49|Aranha das Cavernas|Prata 2 · 2|Bronze 5|24|18|19|Patada~1d6+força~VIDA;Sucção~2d6 de alma~ALMA;Teia~SEM FORMULA~CONTROLE
6c6c2b324ede8378862581feae2c1807|bb8c2b324ede83268dfe81455cb6c5cb|Serpente do Equinócio|Lendário 1 · 1|Bronze sem estrela no corpo|10|23|19|Mordida Iluminada~SEM FORMULA~VIDA_PENDENTE;Brilho Equinocial~SEM FORMULA~CONTROLE
7cfc2b324ede8307861981852366b0c7|0dcc2b324ede831e9f1e0151bbb83e03|Basilisco|Lendário 2 · 2|Bronze sem estrela no corpo|7|20|28|Sopro de Pedregulho~SEM FORMULA~VIDA_PENDENTE
c28c2b324ede8217937c8165a19eafa9|0b3c2b324ede83478b41815218877e37|Escorpião Ártico|Bronze 5 · 1|Bronze 5|8|24|18|Rabada~1d4 + destreza~VIDA;Corte~1d6 + força~VIDA
341c2b324ede8272aef80156a5633b7b|c7dc2b324ede837e89638122de721c31|Serpente flamejante|Ouro Negro 2 · 3|Bronze sem estrela no corpo|4|29|16|Mordida Iluminada~SEM FORMULA~VIDA_PENDENTE
728c2b324ede8254879601340a0b23e6|4d2c2b324ede8247a62e81bac03b07a0|Bicefalia|Ouro 5 · 4|Prata sem estrela no corpo|6|7|5|Mordida Dupla~SEM FORMULA~VIDA_PENDENTE;Sibilar Paralisante~SEM FORMULA~CONTROLE
23dc2b324ede8261856701444f7a39c3|271c2b324ede832683630163083439ee|Pegasus folium|Ouro 2 · 7|Lendário sem estrela no corpo|10|24|18|Canto da Floresta~SEM FORMULA~CURA_PENDENTE
fe9c2b324ede83f6853f01b48b5b6df3|bc2c2b324ede8216b21481c16b7307ee|Ovelha de Chifres|Prata 5 · 2|Bronze 4|33|16|2|Investida~1d6 + força~VIDA

e89c2b324ede825192528100f510f708|f10c2b324ede82048085810351fd52dd|Cactigre|Ouro 5 · 4|Ouro Negro sem estrela no corpo|8|80|6|Garras Afiadas~SEM FORMULA~VIDA_PENDENTE
 a4bc2b324ede8398a9398132bde05f31|129c2b324ede836ba89e015bf903c37a|Draquilarto|Ouro 5 · 2|Bronze sem estrela no corpo|60|55|6|Cauda Poderosa~SEM FORMULA~VIDA_PENDENTE
 e56c2b324ede82cabbeb016441a0bc2a|fb4c2b324ede82aea528014cee739186|Blastoise|Ouro 5 · 2|Bronze sem estrela no corpo|8|47||Canhões de Água~SEM FORMULA~VIDA_PENDENTE;Investida Poderosa~SEM FORMULA~VIDA_PENDENTE
9b5c2b324ede833f92e5819001f044a8|54fc2b324ede8356b918810c68782c9c|Furão Elétrico|Ouro 5 · 7|Lendário sem estrela no corpo|6|55|60|Descarga Elétrica~SEM FORMULA~VIDA_PENDENTE
35fc2b324ede830ab551017811f0fbae|7ebc2b324ede825d9480811959c4496f|Lagarto Vulcan|Ouro 5 · 7|Lendário sem estrela no corpo|10|48||Sopro de Fogo~SEM FORMULA~VIDA_PENDENTE;Garras Afiadas~SEM FORMULA~VIDA_PENDENTE
266c2b324ede8327b4e98197278f602b|1b6c2b324ede83f3ae250179bc746953|Felivolante|Ouro 5 · 3|Lendário sem estrela no corpo|8|90|27|Garras Afiadas~SEM FORMULA~VIDA_PENDENTE
89dc2b324ede82b28bc901a40b91a59a|e07c2b324ede82c399e4010915db6957|Pantera Sombria|Ouro 5 · 2|Bronze sem estrela no corpo|10|89|6|Garras Sombrias~SEM FORMULA~VIDA_PENDENTE
 a78c2b324ede83069d7801b3519e2a4f|ee4c2b324ede83888f2e81b77681f32c|Wyvern|Lendário 4 · 2|Lendário sem estrela no corpo|9|68|76|Garras Afiadas~SEM FORMULA~VIDA_PENDENTE;Sopro de Vento~SEM FORMULA~VIDA_PENDENTE
21ec2b324ede83ee8652012a90225428|8a3c2b324ede82648f76012e6b86930e|Dragcornio Flamejante|Ouro 5 · 7|Bronze sem estrela no corpo|72|62|30|Cuspe de Lava~SEM FORMULA~DOT_PENDENTE;Pele Incandescente~SEM FORMULA~VIDA_PENDENTE
ad7c2b324ede82caa886810086579598|9bbc2b324ede824ead1d8121ab575f29|Espectro da Escuridão|Ouro 5 · 2|Ouro Negro sem estrela no corpo|89|61|7|Garras das Trevas~SEM FORMULA~VIDA_PENDENTE
21bc2b324ede83faafda8180fd885936|702c2b324ede82cab14101a9f66d65ea|Leopardo de Lava|Ouro 5 · 7|Bronze sem estrela no corpo|79|59|20|Pele de Lava~SEM FORMULA~VIDA_PENDENTE;Garras de Magma~SEM FORMULA~VIDA_PENDENTE
8b3c2b324ede8374925981c6c3e36da7|e1ec2b324ede82f3a0088100e9786ce5|Grifo de Gelo|Ouro 5 · 3|Sem classificação explícita|12|67|90|Aura Congelante~SEM FORMULA~DOT_PENDENTE;Sopro Gélido~SEM FORMULA~CONTROLE
481c2b324ede83539bce0157cbe4555f|237c2b324ede830689bc813824bc1722|Trysolaris|Ouro 5 · 3|Bronze sem estrela no corpo|48|46|25|Golpe de Rocha~SEM FORMULA~VIDA_PENDENTE;Explosão de Luz~SEM FORMULA~VIDA_PENDENTE
 d58c2b324ede8208b24b014eaaf3ac5c|29bc2b324ede831c9c62812e214cdff9|Rinolupo|Ouro 5 · 3|Prata 4|56|47|10|Investida Feroz~2d6+for~VIDA;Pele Couraçada~RDF 10~DEFESA
 e70c2b324ede83fc9683016f46e3570c|1cfc2b324ede833aaf9501ce6db36905|Anjo|Lendário 2 · 2|Bronze sem estrela no corpo|15|60|75|Manipulação de Energia~SEM FORMULA~OFENSIVO_INCOMPLETO
328c2b324ede8238a19281a98c40b91d|ea2c2b324ede821593ed017ba57e735a|Aurafelis Mystica|Ouro 5 · 4|Lendário sem estrela no corpo|8|90|7|Invocação de Espíritos da Floresta~SEM FORMULA~INVOCAÇÃO
 d12c2b324ede8294ba338136132291e2|7f5c2b324ede83fbaa310131884fb636|Grifo Divino|Ouro 5 · 3|Sem classificação explícita|14|60|74|Garras Luminosas~SEM FORMULA~VIDA_PENDENTE;Invocação de Constelações~SEM FORMULA~VIDA_PENDENTE
759c2b324ede837eb82c81104da7721e|225c2b324ede82a9a05d0104c2f94990|Grifo|Ouro 5 · 3|Ouro sem estrela no corpo|10|63|50|Garras Terrafirmes~SEM FORMULA~VIDA_PENDENTE

1c6c2b324ede8252872c81bd287fb516|580c2b324ede8209b1dc01590ab9cf39|Aurora Radiante|Ouro 1 · 1|Prata 1|4|29|40|Raio purificador~1d6+int~VIDA;Toque Iluminado~1d4+int~CURA_OU_PURIFICAÇÃO
0c9c2b324ede82ab8be801371d927931|574c2b324ede83a494ec810ac51c2b7b|Cristalino Gélido|Prata 5 · 4|Prata 1|9|30|40|Estalactite Afiada~1d6+Int~VIDA;Sopro Congelante~SEM FORMULA~CONTROLE
336c2b324ede82ac82ab01ac0eb062a2|bcfc2b324ede82f9a1590183c2fb2d1f|Verdantis Sibilante|Ouro 2 · 7|Prata 1|6|28|42|folhas cortantes~1d6+Int~VIDA;Chicote de Vinha~SEM FORMULA~CONTROLE
778c2b324ede83d0a89281a4c12ba768|bd6c2b324ede835495c581c8f98bed95|Símio Demoníaco (Raios de Tempestade)|Ouro 2 · 4|Prata 1|23|20|5|Ataque de Garras Eletrizadas~2d6+For~VIDA
77ec2b324ede82d49662812c1e72b7b0|7e3c2b324ede82978871811684281c2f|Polvo da Floresta|Ouro 1 · 1|Prata 1|3|22|29|Corte cerebral~2d6+int~VIDA
383c2b324ede8266ad2b819fc078a66a|1abc2b324ede83ffa88701dd065bdfbd|Símio Demoníaco (Fúria de Chamas)|Ouro 2 · 6|Épico (não rank reconciliado)|23|20|12|Lança-chamas~3d6 + int~VIDA;Ataque colossal~2d6+for~VIDA
'''

def catalog():
    rows=[]
    for line in DATA.splitlines():
        line=line.strip()
        if not line:continue
        parts=[p.strip() for p in line.split('|')]
        if len(parts)!=9:raise ValueError((line,len(parts)))
        uid,parent,species,folder,rank,force,dex,intel,skills=parts
        assert len(uid)==len(parent)==32,(uid,parent)
        abilities=[]
        for s in skills.split(';'):
            a=s.split('~'); assert len(a)==3,(uid,s)
            abilities.append({'name':a[0],'literal_formula':a[1],'channel':a[2]})
        rows.append({'page_uuid':uid,'url':'https://app.notion.com/p/'+uid,'parent_species_uuid':parent,'species':species,'rank_folder':folder,'rank_body':rank,'FOR':force,'DES':dex,'INT':intel,'abilities':abilities,'fetch_scope':'MESTRE_READ_ONLY_DIRECT_SOURCE_EXCERPT_20261017','source_last_edit_date':'2026-10-01','full_body_byte_snapshot':False})
    assert len(rows)==35,len(rows)
    assert len({r['page_uuid'] for r in rows})==35
    return rows
if __name__=='__main__':
 import json
 print('pages',len(catalog()),'ability-excerpts',sum(len(r['abilities']) for r in catalog()),'literal-numeric',sum(a['literal_formula']!='SEM FORMULA' for r in catalog() for a in r['abilities']))
