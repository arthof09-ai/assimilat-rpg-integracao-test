# Handoff VLAB R160 → DMG — MESTRE-ONLY / PREPARADO, SEM ACK

Não escrever na OP-DMG; handoff disponível somente na Biblioteca competente.

## Coortes novas e proveniência
- R157_TACTIC_BASIC_DEV_S997617 (49 commits, basic F 8 ataques, 8 Esporos E).
- R157_TACTIC_WIND_DEV_S997617 (49 commits, Wind F 7 Turbilhões+1 golpe, 8 Esporos E).
- R158_NEGATIVE_CRITICAL_TACTIC_DEV_S997946 (49 commits, primeiro ataque negativo R42 `[1,1,1]`, 0 dano).
- R159_ED_GRIFO_AUREN_BE_BASIC_DEV_S998803 (150 commits; 50 turnos, Grifo sem especial).
- R159_ED_GRIFO_AUREN_BE_SPECIAL_DEV_S998803 (150 commits; um Descarga de 55PA e 14d10, salvo Reflexo).
- R153_CASULO_CA_SOURCE_DEV_S999013 (9 commits, ataque com CA modificada; não é batalha completa).
- R154_TWO_AOO_FULL_SOURCE_DEV_S999141 / KO_DEV_S999142 e R155_AOO_NEGATIVE_R42_R43_DEV_S999353 (10 commits combinados, AOO sob R43).

**Fonte de verdade dos dados brutos:** bancos SQLite + arquivos genesis e checkpoints incluídos no ZIP; auditores r159_cold_* independentes. Não gerar recibo numérico que não esteja no evento; NÃO concatenar automaticamente com R97 1344 (errata), R116 212, R125 165, R135 7, R145 3, R150 3.

## Limites científicos
- Feryn/Eristan são NPCs Mestreside propostos sem Espírito Demoníaco. Dano Vento/Planta sob hipótese condicional de RD elementar não especificada=0 NO LAB, não RD oficial.
- Auren ED versus Grifo L3: iniciativa natural Besta indecidida, abertura exógena, alcance 1.5m laboratório, RD Lightning de Auren não documentada; seed emparelhada, não holdout cego.
- S998801 tentativa de Descarga com meia-dano ímpar parou e seu banco é não selecionado; S998801 basic completo não conta como par.
- R156 tem intenção pendente após exceção na habilidade por bônus fixo nativo originalmente omitido; UNKNOWN_EFFECT/HOLD; não reexecutar.

**Status DMG:** PREPARED_NOT_DELIVERED/NOT_ACKNOWLEDGED.
