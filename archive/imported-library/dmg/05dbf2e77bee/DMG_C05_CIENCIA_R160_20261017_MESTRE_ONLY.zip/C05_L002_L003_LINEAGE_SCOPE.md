# C05 — L002/L003 lineage, exact scope and blockers

**Operation:** OP-DMG-CORPUS-EMP-01 (same original). **As-of:** 2026-10-17. **Baseline:** DMG-RANK-01 v1.1 unchanged.

## Original claims (RELATADO, not reauthored)
- Lote 002: 45 physical pages, 58 mechanical records, 38 potentially offensive effect groups, 68 mathematical parcels, 64 documentary occurrences.
- Lote 003: 71 additional pages, 56 numeric-formula records within 35 pages, 108 mathematical parcels, 36 remaining pages with incomplete/ambiguous information.
- The original L002/L003 ZIPs and row-wise definitive lot membership matrix were **not recovered as original physical bytes** in C05. Past records give library identifier `libfile_84761c9a591c8191bc304533e4074ee9` for L002, but this reference is not a materialized, byte-authenticated archive here. Do not infer a sandbox file path from identifier.

## Physically re-opened C05 evidence
- Existing full ZIP C04 139159 bytes / SHA `4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629` was used for direct identifiers of R02/R03/R04 and REALIGNMENT24.
- Old R07/R08/R09/R10 ZIPs were physically available and ZIP CRC PASS. Directed scan of their text/JSON/CSV entries found **0 explicit matches** among the 19 C04 previous `POTENTIALLY_NEW_SOURCE_NOT_GLOBAL_CERTIFIED` UUIDs. This negative result is limited to these accessible files, not a lot-membership proof.
- 35 C05 fresh page IDs were compared by literal UUID against R02/R03/R04/REALIGNMENT24: **15 historical exact UUID matches**, **20 not found in those accessible matrices**. Each item has a row in C05_HISTORICAL_LINEAGE_DEDUP_35.csv. These are *not* new global D0 counts or L002/L003-certified omissions.
- The 19 C04 historical lot-membership unknowns remain unknown; no artificial deduction from historic 71/45 denominators. The 35 C05 lot-membership flags remain unknown, regardless of their relation to R02/R04.

## Dedup acceptance and next block
Identity key: `(source_page_uuid, named_effect_in_variant, literal_formula, source_version)`. Species parent and alias are secondary clustering keys, never sufficient to merge different variant pages. One source can contain several damaging effects but must not count as multiple independent creatures.

**Confirmed material progress:** 35 new page-body checks vs C04, 15 existing known UUID identities excluded from 'novel vs known' attribution, 20 uncovered in accessible selected matrices.

**Unresolved:** original L002/L003 individual exact UUID memberships; historical version snapshots and complete attachment hashes; any claims about D0 all-RPG population. File-existence references alone cannot certify the original.

**NO-REPEAT:** Do not retry identical blocked Notion signed URL/attachment object-empty transfer. Seek genuinely different authorized raw-byte mechanism or reconstruct separately with explicit `RECONSTRUÍDO` provenance.
