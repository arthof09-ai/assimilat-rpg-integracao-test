# PSV — DMG C05 / DEZ ETAPAS EXECUTADAS

**AS-OF:** 2026-10-17, America/Recife. **OPERATION:** `OP-DMG-CORPUS-EMP-01` (existente). **MESTRE-SIDE.** **BASELINE:** `DMG-RANK-01 v1.1` oficial, **INALTERADA**. **HISTORICAL WORKSTREAM:** CM-000001/DMG, sem reapropriação da identidade do Coordenador. **FASE FORMAL:** F0 `4/8`, não promovida.

**LAST-VERIFIED-UNIT:** C05 com matrizes de 35 páginas-folha, 58 registros de efeito/habilidade, 17 distribuições numéricas (16 Vida + 1 Alma), 34 componentes, grafo de 648 nós, VLAB R160 154 recibos/9 RUN-IDs reconciliados com seus SQLite, auditoria funcional e cruzada, artefatos locais e publicação/recuperação da Biblioteca quando demonstradas. **FIRST-PENDING:** leitura das cinco variantes referenciadas, mas não abertas, IDs em `C05_GRAPH_DELTA_AND_NEXT5.json`, seguida de adjudicação de fontes/rank e da autenticidade individual L002/L003. **NAC-PASS-02:** PASS proporcional para pesquisa local e integridade do pacote após readback; HOLD para a homologação canônica F0, revisão cega, escritores e DMG v2.

## Execução da ordem em dez etapas — antes → depois

| Etapa | ANTES | DEPOIS físico/funcional | Aceite |
|---|---|---|---|
| 1. Oito menções | 8/8 referências estruturais não adjudicadas contextualmente | 8/8 espécies físicas reabertas no Notion Mestre; 12 URLs descendentes identificadas; 0 criatura ficticiamente contada | PASS estrutural delimitado |
| 2. Novas fontes | C04 29 páginas/37 efeitos/45 componentes | 35 páginas-folha **adicionais** lidas; 58 entradas de habilidade; 16 ataques Vida de fórmula literal completa e 1 Alma; 34 componentes; sem D0 global | PASS para lote selecionado, não censo global |
| 3. L002/L003 | Arquivos originais inacessíveis; 19 páginas C04 com pertencimento incerto | 35 novos UUIDs comparados aos R02/R03/R04/REALIGNMENT24: 15 matches literais, 20 ausências relativas; L002/L003 originais ainda sem readback; 19 antigos permanecem indeterminados | PARTIAL externo |
| 4. Calculadora | Tabelas C04, sem módulo experimental desta sucessão | `experimental_damage_calc.py`, PMF exata/estatísticas, RD/limiar e PA/acerto **somente se input documentado**; 26/26 testes funcionais | PASS local experimental |
| 5. Atributos/dados | Três pares R04 e coorte restrita Prata1 | 15/15 fórmulas de Vida com atributo explicitado têm parcela do atributo superior à metade da média bruta (amostra selecionada, mediana de participação ≈85,11%); coorte P1 não mistura ancestry conflitante | PASS analítico restrito |
| 6. Fronteiras de rank | C04 seis fontes Prata1 classificadas de modo triplo | cinco novos casos título/corpo Prata1 mas ancestral conflitante: média 39,7 vs 33,67 em seis estritos; Ouro5 contém numerosas divergências; sem benchmark universal | PASS diagnóstico, HOLD classificação |
| 7. R160 | R125/R137/R150 anteriores; R160 preparado | ZIP 15.175.798 bytes, 367 entradas CRC, 365/365 hashes, 9 SQLite/466 commits e 154 recibos autenticados; auditoria de 2.637 verificações | PASS read-only, handoff PREPARED/sem ACK |
| 8. Eficiência | R116/R125/R150 anteriores | R157 pareado seed997617: política WIND +16 PV por +420 PA frente BASIC; limiar teste de RD de vento 3 por Turbilhão torna −5 PV. Nenhum custo/precisão ausente inventado | PASS inferência condicionada, não escolha normativa |
| 9. Hipóteses | Necessidade de testes | 5 hipóteses com fontes, unidades, critérios de refutação, limitações e próximo teste VLAB; sem seeds cegas reusadas | PASS pré-registro local, HOLD validação cega |
| 10. Auditoria/continuidade | C04 2.048/2.048 locais | 883/883 checks da pesquisa exata, 26/26 funcionais, 2.637/2.637 cross-readback R160, **460/460 cruzamentos independentes locais**, ZIP manifesto/readback C05 anexados após execução | PASS técnico; formal F0 HOLD |

## Denominadores científicos: preservar unidades

- **A6** congelado em 571 UUIDs estruturais de duas profundidades: 332 RECONSTRUÍDOS +239 RECUPERADOS, interseção 0; nenhuma recontagem neste ciclo.
- **Grafo:** 608 nós C04 → **648 nós C05** = 35 páginas físicas novas vs C04 + cinco referências profundas **não lidas**. Oito menções existentes reclassificadas **sem nós duplicados**. Não significa 648 criaturas.
- **Corpus C05:** **35 SOURCE-PAGES únicas adicionais a C04**; **58 DAMAGE-EFFECT/ability excerpts** (inclui controle, cura e efeitos incompletos); **17 fórmulas de distribuição numérica** das quais **16 ataque bruto à Vida** e **uma perda de Alma**, **34 DAMAGE-COMPONENTS** das fórmulas parsed. 0/35 fontes simultaneamente completas para ataque+precisão+PA+RD competentes.
- **R02/R03/R04/REALIGNMENT24** elegíveis acessíveis: 15/35 UUIDs C05 já existentes neles, 20/35 sem match **nessas matrizes, não ausência em L002/L003**. Os 19 casos C04 anteriormente indeterminados quanto a L002/L003 permanecem indeterminados.
- **R160:** 154 recibos de ataque em 9 RUN-IDs (não 154 sementes/cenas independentes). 117 NORMAL, 32 SPELL_NO_PHYSICAL_ATTACK, 5 OPPORTUNITY; 68 acertos físicos, 54 falhas, 32 magias por salvaguarda; dois críticos negativos. 466 commits dos 9 ledgers. **0** material canônico de combate certificado pelo DMG.
- **F0:** 4/8 marcos históricos; A5 original 0/7 readbacks; A7 revisão cega 0/8; A8 writer sem claim. E01–E24 e oito gates transversais sem certificação adicional; F13–F18 não iniciadas.

## Descobertas científicas, grau de inferência e ferramentas

1. **Domínio do atributo em amostra dirigida (VERIFICADO local, não generalizável):** das 16 fórmulas ofensivas à Vida, 15 têm atributo explícito; nas 15, sua participação na média bruta supera 50%. Mediana da participação ≈85,11%. A dependência de páginas com múltiplos ataques e critérios de seleção impede inferir prevalência do RPG todo.
2. **Pares da mesma entidade:** Escorpião Ártico `[c28c...]` Rabada `1d4+DES24` média 26,5 e Corte `1d6+FOR8` média 11,5; Raposa Flamejante `[529c...]` Soco `1d6+FOR20` média 23,5 vs Punhos de Fogo `1d4` média 2,5. Ambas: primeira alternativa maior em toda rolagem bruta, sem inversão estrita nas curvas RD calculadas. Escorpião pode ter espelho nominal em outra página; Raposa com ancestral Prata5. Não certificar população de Bronze5.
3. **Rank/seleção:** grupo C04 estritamente Prata1 (título/corpo/ancestral) seis fórmulas, média 33,667; cinco novos casos título+corpo Prata1 mas ancestral diferente, média 39,7. Fusão ingênua daria 36,409, um **teste ilustrativo inválido como benchmark canônico**. Uma habilidade de rank inferior pode ultrapassar nominalmente outra de rank superior em amostras, mas sem adjudicação do rank e controle de precisão/PA não demonstra balanceamento ou vitória.
4. **R160 perda de dano:** bruto 16.064 = RD 4.194 + pós-RD 11.870; pós-RD 11.870 = PV efetivamente retirados 11.845 + overkill 25. 68/122 acertos físicos observados sob ambientes selecionados, 32 magias por salvaguarda analisadas separadamente. Nenhum percentual universal, especialmente não fundir hits e saves.
5. **R157 custo × tática / RD:** na mesma seed desenvolvimental 997617, BASIC Feryn 433 PV com PA ofensivo 0, WIND 449 PV com PA adicional 420; ganho marginal de 16/420=0,0381 PV por PA **incremental**; PA=0 em ataques físicos não significa ação sem custo. Sete Turbilhões têm valor bruto mínimo 52 e RD vento da fonte ainda desconhecida. No cenário TEST de RD vento 2 por Turbilhão, WIND supera BASIC por +2; em RD3, perde por −5. Nenhum novo combate executado pelo DMG e políticas podem consumir RNG em ordem diferente.
6. **R159 observacional:** caso técnico BASIC Grifo 0/25 hits físicos e Auren 25/25, sem inferir probabilidades intrínsecas 0% ou 100%; comparação especial 37 PV adicional por 55PA numa seed de desenvolvimento, sob RD elétrica incompleta e fontes de personagens propostas. R156 continua `UNKNOWN_EFFECT` e R138 `HOLD` espacial.

**Calculadora experimental:**

```bash
python experimental_damage_calc.py '1d6+1d4+For' --FOR 22 --RD 15 --threshold 30
python experimental_damage_calc.py '2d6+2d4+For' --FOR 22
```

O primeiro exemplo corresponde à fórmula literal de Mordida Trituradora de Crocossuário, mas **RD15 é input TEST**, não resistência automaticamente documentada. Argumentos `--PA` e `--hit-prob` funcionam somente como cenários condicionados a fontes competentes. Ausência de informações retorna `INDETERMINATE`, e parser rejeita expressões incompletas/incompatíveis. A biblioteca matemática **não simula combate, não cria nova regra e não aplica a v1.1 para substituir fontes explícitas**.

## Proveniência R160 e admissibilidade

Fonte recuperada: `VLAB_R151_R160_TACTICAL_R42_R43_CASULO_ED_BE_VERIFIED_MESTRE_ONLY.zip`, SHA256 `7b208fe553809df6a999a1e4f9a70d7ad116033e929256bc71dbcd61843f3410`, com 365/365 arquivos de manifesto autenticados, ZIP CRC PASS, nove cópias originais SQLite 466 eventos. CSV `R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv` 83.683 bytes, SHA256 `c20a7f2cae18e6c55b385f8c04d9c8650ef032e2f0d19196ee8fa9d9c5d102e3`, idêntico ao ZIP; `R160_INDEPENDENT_OBSERVATIONAL_AUDIT.json` valida 2.637/2.637 campos e junções.

Admissão dos nove RUNs: todos **TECHNICAL_CONDITIONAL_READ_ONLY**; quatro runs técnicos de AOO/CA (1+2+1+2 eventos), dois táticos R157 pareados (16+16), um R158 crítico negativo (16), dois R159 ED/Besta (50+50). Não há PASS oficial de combate. Cenas são agrupadas, podendo ter dependência por fixture/família. R156 UNKNOWN_EFFECT não consta entre estes RUNs e não deve ser repetido nem incorporado; outros casos HOLD também excluídos. Handoff `R160_DMG_HANDOFF_READONLY.md`: **PREPARED_NOT_DELIVERED/NOT_ACKNOWLEDGED**; leitura física não concede ACK.

## L002/L003 — auditoria de linhagem e exclusões

Denominadores **RELATADOS:** L002 45 páginas/58 registros/38 grupos ofensivos/68 parcelas/64 ocorrências. L003 +71 páginas/56 fórmulas em 35 folhas/108 parcelas/36 páginas com pendências. Os ZIPs originais/matrizes de membro continuam sem byte-readback neste ciclo. R07–R10 ZIPs CRC PASS, porém busca limitada não encontrou os 19 C04 UUIDs pendentes em seus materiais de texto. Nenhuma linha foi indevidamente atribuída a L002 ou L003. Critério de exclusão é UUID de fonte + identidade literal de efeito + versão, não nomes iguais entre criaturas, espelhos ou versões.

## Plano Supremo e governança

A matriz F0–F18 **existente** continua a ser a fonte canônica; `C05_PLAN_SUPREMO_ANTES_DEPOIS_F0_F18.csv` é apenas um DELTA auxiliar local para não solicitar writer inexistente. F1 (descoberta), F2 (dedup), F3 (extração), F4 (normalização), F5 (taxonomia), F6 (filtro de aplicação v1.1), F7 (faixa/rank), F8 (distribuição), F9 (pares), F10 (fronteiras), F11 (benchmarks técnicos) e F12 (vieses) **avançaram exploratoriamente**, mas nenhum recebeu PASS formal. F13–F18 não iniciadas. Nenhuma proposta DMG v2.

**A5**: 7/7 fingerprints textuais herdados, 0/7 bytes históricos; sem repetir o mesmo mecanismo inoperante. **A7**: oito holdouts continuam reservados, nenhum resultado de avaliação cega ou decisão por família. **A8**: sem INSTANCE-ID/claim, writer, lease, epoch, fencing, ACK ou escrita Notion; arquivos locais e Biblioteca persistente são entregas cientificamente auditáveis, não promoção normativa. **UNKNOWN-EFFECT**: quarentena histórica R156 mantida; C05 produziu apenas cálculos, leitura e publicação de artefatos sem executar VLAB.

**NO-REPEAT:** não recontar A6 571, não reabrir os 20 índices por rotina, não rerodar os 212 R116, 165 R125, 7 R137 ou 3 R150 eventos, não repetir downloads de A5 sabidamente vazios, não refazer R156. Reutilizar matrizes/recibos existentes e checks direcionados de integridade.

**CONFLICTS:** Espelho nominal Escorpião Ártico/diamante, Raposa Bronze5 sob ancestral Prata5, Rinolupo variante corpo Prata4 sob pasta Ouro5, cinco novos Prata1 com ancestral diverso, 18 páginas título Ouro5 com corpo Bronze/Lendário/Ouro Negro/Prata/outros, Concha Marinha inanimada, RD vento ainda TEST e dependência RNG entre políticas. Nenhuma adjudicação silenciosa.

**NEXT-5:** ler variantes profundas exatas do grafo C05: `266c2b324ede8258b97c017633c22ca6`, `6f9c2b324ede82dfb9a5812d7fd2ed48`, `95cc2b324ede82cabae401bc73662386`, `a59c2b324ede82a9b464810a3e5c0962`, `be0c2b324ede8336b8348165d395226d`; comparar contra todos os registros atuais/históricos antes da normalização. A leitura destas cinco referências deve prosseguir enquanto houver acesso admissível, sem reiniciar C05.

**TARGET-REMAINDER:** (a) L002/L003 ZIPs originais ou matriz de pertencimento em via autorizada diferente; (b) ampliar fontes com PA+acerto+RD e rank adjudicado; (c) revisão independente cega por família e seeds; (d) fonte original de RD vento para testar marco R157; (e) writer/fencing/ACK por competência, somente para futura mutação compartilhada; (f) resolver A5 autenticação histórica ou snapshots atuais íntegros; (g) F0 formal 4/8, E01–E24 e oito gates sem terminalidade.

**NAC-CONT-03:** LER C04/governança → ANTES imutável → pesquisar/calcular local sem writer → REABRIR originais Notion e ZIPs VLAB → reconciliar identidades e controles → DEPOIS matrizes+auditor+hashes → readback Biblioteca → PSV. **NAC-NORM-01:** nenhuma regra revista; aplicabilidade a promoção futura mantida. **NAC-PASS-02 LOCAL:** integridade e utilidade técnica PASS somente quando o pacote final congelado for novamente recuperado da Biblioteca; **formal/canônico HOLD**. Sem escrita na Party, O Primeiro, DMG-RANK-01 ou operações alheias.
