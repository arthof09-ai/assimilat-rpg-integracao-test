"""Positive/negative C05 formula tests with true direct PMF enumeration checks in science module."""
from experimental_damage_calc import parse_literal,pmf,metrics,compare
from fractions import Fraction
from pathlib import Path
import json,sys
passed=0

def test(v,msg):
 global passed
 assert v,msg
 passed+=1

def raises(fun,kind):
 try:fun()
 except ValueError as exc:test(kind in str(exc),'wrong rejection: '+str(exc))
 else:raise AssertionError('not rejected '+kind)

test(metrics('1d6+for',{'FOR':20})['gross_mean']==23.5,'Raposa socio')
test(metrics('1d4',{})['gross_mean']==2.5,'Punhos')
test(metrics('1d6+1d4+For',{'FOR':22})['gross_mean']==28,'Crocossuário')
test(metrics('2d6+2d4+FOR',{'FOR':22})['gross_mean']==34,'Mamute')
test(metrics('1d4+destreza',{'DES':24})['gross_mean']==26.5,'Escorpião')
test(metrics('1d6+for',{'FOR':8})['gross_mean']==11.5,'Corte Escorpião')
test(metrics('1d6+INT',{'INT':40})['gross_mean']==43.5,'Aurora')
test(metrics('2d6+Int',{'INT':29})['gross_mean']==36,'Polvo')
test(metrics('1d6+60',{})['gross_mean']==63.5,'numeric explicit fixed')
test(metrics('2d6+2d4+FOR',{'FOR':22})['gross_min']==26,'minimum Mamute')
test(metrics('2d6+2d4+FOR',{'FOR':22})['gross_max']==42,'maximum Mamute')
test(metrics('2d6+2d4+FOR',{'FOR':22},rd=35)['post_rd_expected_on_hit']>0,'correct RD')
test(metrics('1d6+FOR',{'FOR':8})['per_attempt_expected']=='INDETERMINATE_NO_SOURCE_HIT_CHANCE','absence hit')
test(metrics('1d6+FOR',{'FOR':8})['per_pa_expected_conditional_on_hit']=='INDETERMINATE_NO_SOURCE_PA_COST','absence PA')
test(compare('1d4+DES','1d6+FOR',{'DES':24},{'FOR':8})['fraction']==[1,1],'strict win')
test(metrics('1d6+FOR',{'FOR':8},rd=30)['post_rd_expected_on_hit']==0,'RD annuls')
test(metrics('1d6+FOR',{'FOR':8},threshold=14)['P_gross_strictly_above_threshold']==0,'no exceed max')
test(abs(metrics('1d6+FOR',{'FOR':8},rd=7,hit_probability=.5,pa_cost=10)['per_attempt_expected']-2.25)<1e-12,'conditional hit calculation')
raises(lambda:metrics('2d6+INT',{}),'MISSING_SOURCE_ATTRIBUTE_INT')
raises(lambda:metrics('2d6 + INT + 10',{'INT':5}),'UNSUPPORTED_OR_INCOMPLETE_FORMULA')
raises(lambda:metrics('0d6+FOR',{'FOR':5}),'INVALID_DICE')
raises(lambda:metrics('1d6+FOR',{'FOR':5},rd=-1),'RD_NONNEGATIVE_INTEGER_REQUIRED')
raises(lambda:metrics('1d6+FOR',{'FOR':5},pa_cost=0),'PA_POSITIVE_INTEGER_REQUIRED')
raises(lambda:metrics('1d6+FOR',{'FOR':5},hit_probability=1.01),'HIT_PROBABILITY_OUTSIDE_0_1')
raises(lambda:metrics('SIN_FÓRMULA',{}),'UNSUPPORTED_OR_INCOMPLETE_FORMULA')
raises(lambda:metrics('1d6+FOR',{ 'FOR':None}),'MISSING_SOURCE_ATTRIBUTE_FOR')
Path('/mnt/data/dmg_succession/cycle5/C05_CALCULATOR_TESTS.json').write_text(json.dumps({'functional_tests':passed,'passed':passed,'failed':0,'scope':'local experimental library no combat engine','benchmarks':'source genuine formula; precision/PA conditional only; invalid missing sources rejected'},indent=2)+'\n')
print('functional tests',passed,'PASS')
