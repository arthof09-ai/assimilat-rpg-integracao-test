"""Additive provenance graph: never re-count or rewrite A6 baseline 571 UUIDs."""
from c05_sources import catalog
import json,csv,io,zipfile,pathlib,collections
P=pathlib.Path('/mnt/data/dmg_succession/cycle5');Z=zipfile.ZipFile('/mnt/data/DMG_F0_C04_CORPUS_EFICIENCIA_VLAB_20261016_MESTRE_ONLY.zip')
nodes=list(csv.DictReader(io.StringIO(Z.read('PROVENANCE_GRAPH_NODES_CYCLE4.csv').decode())));edges=list(csv.DictReader(io.StringIO(Z.read('PROVENANCE_GRAPH_EDGES_CYCLE4.csv').decode()))); nodeby={n['uuid']:n for n in nodes};assert len(nodes)==608
for p in json.loads((P/'C05_SOURCE_PAGES_35_FORENSIC.json').read_text()):
 assert p['page_uuid'] not in nodeby
 node={'uuid':p['page_uuid'],'url':p['url'],'node_type':'SOURCE_LEAF_BODY_EXCERPT_READ','from_A6':'NO_DEEPER_THAN_A6','physical_parent_uuid':p['parent_species_uuid'],'discovery_origin':p['rank_folder'],'A6_link_parent':p['parent_species_uuid'],'depth_A6':'DESCENDANT_NOT_A6_COUNTER','Notion_edited_source':'2026-10-01','direct_body_read':'YES_EXCERPT_ONLY_20261017','master_side':'YES','candidate_offense':'TRIAGED_PER_EFFECT','authority':'MESTRE_READ_ONLY','conflict':p['rank_conflict']}
 nodes.append(node);nodeby[p['page_uuid']]=node
 edges.append({'parent':p['parent_species_uuid'],'child':p['page_uuid'],'relation':'NOTION_DIRECT_PHYSICAL_PARENT_AS_OF_FETCH','verified':'YES_NOTION_SOURCE_ANCESTOR_ONLY','sample_window':'C05_20261017','unit':'SOURCE_PAGE'})
mentions=[
('c12c2b324ede837cb34001ff00aabede','d381f1e75a43447a994bff04fb6ce857'),
('702c2b324ede82cab14101a9f66d65ea','49699c4b34984446b521c06294234dde'),
('237c2b324ede830689bc813824bc1722','b81e9e65a95c493c87144810a44cd5a1'),
('d09c2b324ede8312a2d8814a16d28c00','875e515ce8704773b04eef8fff672605'),
('1b6c2b324ede83f3ae250179bc746953','6a4fa249d69c4310b8b83d50e8986804'),
('e1ec2b324ede82f3a0088100e9786ce5','6a4fa249d69c4310b8b83d50e8986804'),
('7f5c2b324ede83fbaa310131884fb636','b81e9e65a95c493c87144810a44cd5a1'),
('225c2b324ede82a9a05d0104c2f94990','b81e9e65a95c493c87144810a44cd5a1')]
ment=json.loads((P/'C05_EIGHT_MENTIONS_ADJUDICATED.json').read_text());mlink={x['uuid']:x for x in ment};assert {i for i,_ in mentions}==set(mlink)
for uid,parent in mentions:
 if uid in nodeby:
  nodeby[uid]['node_type']='SPECIES_CROSS_REFERENCE_RECONCILED_EXISTING'
  nodeby[uid]['direct_body_read']='SPECIES_CHILD_LINKS_READ_ONLY_20261017'
  nodeby[uid]['physical_parent_uuid']=parent
  nodeby[uid]['candidate_offense']='READ_VARIANT_LEAVES_NOT_SPECIES_PARENT'
  nodeby[uid]['conflict']='C04_MENTION_POINTED_TO_OTHER_ELEMENTAL_TREE_NOT_DUPLICATE_ADJUDICATED'
 else:raise AssertionError('expected A6 or prior '+uid)
 edges.append({'parent':parent,'child':uid,'relation':'NOTION_PHYSICAL_RANK_FOLDER_CHILD','verified':'YES_20261017_DIRECT_SPECIES_FETCH_PARENT_PATH','sample_window':'C05_20261017','unit':'SPECIES_FOLDER'})
 for child in mlink[uid]['page_children_UUIDs']:
  if child not in nodeby:
   nd={'uuid':child,'url':'https://app.notion.com/p/'+child,'node_type':'VARIANT_CHILD_LINK_ONLY_UNREAD','from_A6':'NO_DEEPER_THAN_A6','physical_parent_uuid':uid,'discovery_origin':mlink[uid]['physical_element'],'A6_link_parent':uid,'depth_A6':'DESCENDANT_NOT_A6_COUNTER','Notion_edited_source':'PENDING','direct_body_read':'NO_CHILD_LINK_ONLY','master_side':'YES','candidate_offense':'UNASSESSED_PENDING_NEXT','authority':'MESTRE_READ_ONLY','conflict':'UNKNOWN_BODY_RANK_MIRROR'}
   nodes.append(nd);nodeby[child]=nd
  edges.append({'parent':uid,'child':child,'relation':'NOTION_DIRECT_CHILD_OF_SPECIES','verified':'YES_20261017_SPECIES_FETCH_LINK_NOT_CHILD_BODY','sample_window':'C05_20261017','unit':'VARIANT_REFERENCE'})

def out(name,arr):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(arr[0]));w.writeheader();w.writerows(arr)
out('C05_EXTENDED_PROVENANCE_NODES.csv',nodes)
out('C05_EXTENDED_PROVENANCE_EDGES.csv',edges)
prev_unread=sorted(x['uuid'] for x in nodes if x['node_type']=='VARIANT_CHILD_LINK_ONLY_UNREAD')
assert len(nodes)==648 and len(prev_unread)==5,(len(nodes),prev_unread)
assert len(set(x['uuid'] for x in nodes))==len(nodes)
D={'original_A6_571_UNCHANGED':True,'C04_graph_nodes':608,'C05_graph_nodes':len(nodes),'C05_new_physically_fetched_leaf_nodes':35,'C05_unread_direct_variant_reference_nodes':5,'C05_mentions_resolved_reusing_A6_nodes':8,'next_five_variant_uuids':prev_unread,'not_global_discovery':True}
(P/'C05_GRAPH_DELTA_AND_NEXT5.json').write_text(json.dumps(D,indent=2)+'\n');print(D)
