#!/usr/bin/env python3
"""C05 independent cross-artifact audit. No effects or canonical mutations.
Same research instance, independent code path; NOT blind human auditor.
"""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import product
from fractions import Fraction
import hashlib,json,csv,sys,zipfile,statistics
ROOT=Path('/mnt/data/dmg_succession/cycle5')
C04=Path('/mnt/data/DMG_F0_C04_CORPUS_EFICIENCIA_VLAB_20261016_MESTRE_ONLY.zip')
checks=Counter()
def gate(ok,desc):
 checks['total']+=1
 if not ok:raise AssertionError(desc)
 checks['pass']+=1
j=lambda name:json.loads((ROOT/name).read_text())
cl=lambda name:list(csv.DictReader((ROOT/name).open(newline='',encoding='utf8')))
with zipfile.ZipFile(C04) as z:
 gate(z.testzip() is None,'C04 ZIP CRC'); gate(hashlib.sha256(C04.read_bytes()).hexdigest()=='4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629','C04 original checkpoint hash')
 old=list(csv.DictReader(z.read('SOURCE_PAGE_CYCLE4_FORENSIC.csv').decode('utf8').splitlines()))
 oldpages={r.get('page_uuid') or r.get('uuid') for r in old}
 gate(len(oldpages)==29,'29 unique old pages')
C=j('C05_SOURCE_DENOMINATORS.json'); S=j('C05_SOURCE_PAGES_35_FORENSIC.json'); E=cl('C05_DAMAGE_EFFECTS_NORMALIZED_58.csv'); M=cl('C05_DAMAGE_COMPONENTS_EXACT.csv'); P=j('C05_DAMAGE_PMF_EXACT.json'); H=cl('C05_HISTORICAL_LINEAGE_DEDUP_35.csv')
gate(len(S)==35,'35 new pages'); gate(len({s['page_uuid'] for s in S})==35,'new unique ids'); gate(not oldpages.intersection(s['page_uuid'] for s in S),'C05 C04 page exact crosswalk no repeats')
gate(len(E)==58,'58 effects');gate(len({e['effect_id'] for e in E})==58,'effects unique ID');gate(len(M)==34,'34 new numeric components');gate(len(H)==35,'lineage row count')
smap={s['page_uuid']:s for s in S}; effects_by_source=defaultdict(list)
for e in E:
 gate(e['page_uuid'] in smap,'effect physical source');gate(e['url']=='https://app.notion.com/p/'+e['page_uuid'],'effect source URL');effects_by_source[e['page_uuid']].append(e)
for s in S:
 gate(s['url']=='https://app.notion.com/p/'+s['page_uuid'],'page physical URL')
 gate(len(effects_by_source[s['page_uuid']])>0,'source physical effects')
 gate(s.get('full_body_byte_snapshot') is False,'no false Notion binary claim')
gate(C['C05_effect_rows']==len(E),'denom effects');gate(C['C05_exact_formula_HP_rows']==16,'denom hp');gate(C['C05_component_rows_for_parsed_effects']==len(M),'denom components')
ch=Counter(e['evidence_layer'] for e in E)
for name,v in C['C05_channels'].items():gate(ch[name]==v,'channel '+name)
hp=[e for e in E if e['evidence_layer']=='HP_RAW_FORMULA_NUMERIC'];gate(len(hp)==16,'16 HP formula')
# Calculate by literal dice extraction (without importing experimental_damage_calc): independent oracle.
import re
for e in hp:
 formula=e['formula_literal'].replace(' ','').lower().replace('força','for').replace('destreza','des').replace('inteligência','int')
 ds=[(int(n),int(sides)) for n,sides in re.findall(r'(\d+)d(\d+)',formula)]
 assert ds
 u=smap[e['page_uuid']]; code=None
 if 'for' in formula:code='FOR'
 if 'des' in formula:code='DES'
 if 'int' in formula:code='INT'
 fixed=int(u[code]) if code else 0
 if code is None:
  rest=re.sub(r'\d+d\d+','',formula).strip('+');fixed+=int(rest) if rest else 0
 expected=fixed+sum(n*(faces+1)/2 for n,faces in ds)
 gate(abs(expected-float(e['gross_mean_conditional']))<1e-12,'literal formula mean '+e['effect_id'])
 gate(float(e['gross_min'])==fixed+sum(n for n,_ in ds),'literal min')
 gate(float(e['gross_max'])==fixed+sum(n*faces for n,faces in ds),'literal max')
 gate(abs(float(e['post_rd15_mean_TEST'])-sum(max(0,fixed+sum(vals)-15) for vals in product(*([range(1,faces+1) for n,faces in ds for _ in range(n)])))/__import__('math').prod(faces**n for n,faces in ds))<1e-12,'exact cross rd15 '+e['effect_id'])
 gate(e['precision']=='NOT_DOCUMENTED' and e['PA_cost']=='NOT_DOCUMENTED','missing fields marked')
gate(len(P)==17 if isinstance(P,list) else len(P)>0,'PMF all numeric channels present')
co=j('C05_COHORT_STRATA_AND_SENSITIVITY.json');gate(len(co['C04_triple_P1_gross_means'])==6,'strict P1 six');gate(len(co['C05_new_title_body_Prata1_ancestor_conflicted'])==5,'conflicted five')
gate(abs(statistics.mean(co['C05_new_title_body_Prata1_ancestor_conflicted'])-39.7)<1e-12,'selected conflict mean')
N=cl('C05_EXTENDED_PROVENANCE_NODES.csv');G=cl('C05_EXTENDED_PROVENANCE_EDGES.csv');mn=j('C05_GRAPH_DELTA_AND_NEXT5.json')
gate(len(N)==648,'node count');gate(len(set(n['uuid'] for n in N))==648,'unique graph');gate(mn['C04_graph_nodes']==608,'old graph');gate(mn['C05_new_physically_fetched_leaf_nodes']==35,'new graph sources');gate(mn['C05_unread_direct_variant_reference_nodes']==5,'unread linked refs');gate(sum(n['node_type']=='VARIANT_CHILD_LINK_ONLY_UNREAD' for n in N)==5,'five unread flagged')
for s in S:gate(any(n['uuid']==s['page_uuid'] for n in N),'source in graph')
A=j('C05_EIGHT_MENTIONS_ADJUDICATED.json');gate(len(A)==8,'8 mentions');gate(sum(len(x['page_children_UUIDs']) for x in A)==12,'12 children')
for x in A:gate(x['uuid'] in {n['uuid'] for n in N},'mentions already graph')
L=j('R160_INDEPENDENT_OBSERVATIONAL_AUDIT.json');gate(L['audit_checks']=={'all':2637,'passed':2637},'R160 cold internal auditor claim')
gate(L['checkpoints_verified']['source_scoped_receipts']==154,'R160 154')
gate(L['checkpoints_verified']['event_commit_ledgers']==9,'9 ledgers')
gate(L['checkpoints_verified']['file_manifest_hashed']==365,'manifest')
rs=cl('R160_RUNLEVEL_EFFECTIVE_DAMAGE.csv');gate(len(rs)==9,'per-run reconciliation 9')
with (ROOT/'incoming/R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv').open(newline='',encoding='utf-8-sig') as f:V=list(csv.DictReader(f))
gate(len(V)==154,'R160 raw CSV 154')
for metric in ['damage_raw','rd_applied','net_post_RD','hp_effectively_lost','overkill','PA_spent']:
 gate(sum(int(v[metric]) for v in V)==L['total'][metric],f'raw→audit R160 {metric}')
gate(L['total']['damage_raw']==L['total']['rd_applied']+L['total']['net_post_RD'],'raw+RD conservation')
gate(L['total']['net_post_RD']==L['total']['hp_effectively_lost']+L['total']['overkill'],'HP conservation')
gate(C['C05_exact_formula_HP_rows']==16,'C05 active source formulas')
for f in ['C05_SCIENCE_NEW_WITHIN_SPECIES_RD.json','C05_R160_EFFICIENCY_PAIRED_RESEARCH.json','C05_HYPOTHESES_PRE_REGISTERED_AND_RESTRICTIONS.json']:
 gate((ROOT/f).is_file(),'audit path '+f)
science=j('C05_SCIENCE_NEW_WITHIN_SPECIES_RD.json');gate(science['brute_auditor_checks']['total']==883 and science['brute_auditor_checks']['pass']==883,'independent PMF oracle 883')
fn=j('C05_CALCULATOR_TESTS.json');gate(fn['functional_tests']==26 and fn['passed']==26 and fn['failed']==0,'functional 26')
rd=cl('C05_R160_RD_TACTIC_BREAKPOINT.csv');gate(len(rd)==53,'conditional breakpoint grid 53')
for x in rd:
 r=int(x['RD_per_TURB_TEST']);gate(int(x['delta_HP_TEST'])==16-7*r,'seven Turb spells RD0..52 linear')
gate(next(int(x['RD_per_TURB_TEST']) for x in rd if int(x['delta_HP_TEST'])<0)==3,'first policy sensitivity reversal at TEST RD3')
hyp=j('C05_HYPOTHESES_PRE_REGISTERED_AND_RESTRICTIONS.json');gate(len(hyp)==5,'five hypothesis protocols')
for h in hyp:gate(bool(h.get('refutation') and h.get('limitations') and h.get('next_VLAB')),'hypothesis refutation and limits')
gates=j('C05_GATES_NAC_STATUS.json');gate(gates['F0_formal_numerator']==4 and gates['F0_formal_denominator']==8,'F0 no unofficial promotion')
gate('unchanged' in gates['baseline'],'baseline v1.1 unchanged')
P=j('C05_SOURCE_DENOMINATORS.json');gate(P['L002_original_archive_recovered'] is False and P['L003_original_archive_recovered'] is False,'lots not invented')
res={'audit':'C05_INDEPENDENT_CROSS_ARTIFACT_LOCAL','independence':'DIFFERENT_CODE_WITHIN_SAME_RESEARCH_INSTANCE_NOT_BLIND_REVIEWER','total':checks['total'],'passed':checks['pass'],'failed':checks['total']-checks['pass'],'scope':'C04 source baseline, 35 C05 pages, 58 effects, 17 exact PMFs (16 HP+1 SOUL), 648 graph, R160 receipts, scenario breakpoint, F0 gates','NAC_PASS_02':'LOCAL_PRE_FREEZE_PASS_NOT_PRODUCTION_HOMOLOGATION'}
(ROOT/'C05_INDEPENDENT_CROSS_ARTIFACT_AUDIT.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(res,indent=2))
