#!/usr/bin/env python3
"""C05 source-excerpt registry and precise denominators, no canonical writes."""
from c05_sources import catalog
from experimental_damage_calc import metrics,parse_literal,compare
import csv,io,json,zipfile,re,statistics,collections,math,pathlib
OUT=pathlib.Path('/mnt/data/dmg_succession/cycle5')
C04=pathlib.Path('/mnt/data/DMG_F0_C04_CORPUS_EFICIENCIA_VLAB_20261016_MESTRE_ONLY.zip')
with zipfile.ZipFile(C04) as z:
 base=list(csv.DictReader(io.StringIO(z.read('SOURCE_PAGE_CYCLE4_FORENSIC.csv').decode())))
 previous={r['page_uuid'] for r in base}
 legacy={}
 for f,field in [('readonly_sources/R02_DAMAGE_A_B_C.csv','page_id'),('readonly_sources/R03_INITIAL_DAMAGE.csv','\ufeffpage_id'),('readonly_sources/R04_ALL_INITIAL_ACTIONS.csv','page_id')]:
  for r in csv.DictReader(io.StringIO(z.read(f).decode('utf-8'))):legacy.setdefault(r.get(field,''),set()).add(f.split('/')[-1].split('_')[0])
 for r in json.loads(z.read('readonly_sources/SOURCE_LEDGER_24.json')):legacy.setdefault(r['id'],set()).add('REALIGNMENT24')
 base_effects=list(csv.DictReader(io.StringIO(z.read('DAMAGE_EFFECT_CYCLE4_NORMALIZED.csv').decode())))

mentions=[
('c12c2b324ede837cb34001ff00aabede','Demônio Vermelho','Fogo','Prata 1 · 2',['5fcc2b324ede8339a5bd01cd65ea103e']),
('702c2b324ede82cab14101a9f66d65ea','Leopardo de Lava','Fogo','Ouro 5 · 7',['21bc2b324ede83faafda8180fd885936']),
('237c2b324ede830689bc813824bc1722','Trysolaris','Luz','Ouro 5 · 3',['481c2b324ede83539bce0157cbe4555f']),
('d09c2b324ede8312a2d8814a16d28c00','Caelumonstrum fulminis','Raio','Ouro 5 · 7',['6f9c2b324ede82dfb9a5812d7fd2ed48','a59c2b324ede82a9b464810a3e5c0962']),
('1b6c2b324ede83f3ae250179bc746953','Felivolante','Gelo','Ouro 5 · 3',['266c2b324ede8327b4e98197278f602b']),
('e1ec2b324ede82f3a0088100e9786ce5','Grifo de Gelo','Gelo','Ouro 5 · 3',['be0c2b324ede8336b8348165d395226d','8b3c2b324ede8374925981c6c3e36da7']),
('7f5c2b324ede83fbaa310131884fb636','Grifo Divino','Luz','Ouro 5 · 3',['266c2b324ede8258b97c017633c22ca6','d12c2b324ede8294ba338136132291e2']),
('225c2b324ede82a9a05d0104c2f94990','Grifo','Luz','Ouro 5 · 3',['95cc2b324ede82cabae401bc73662386','759c2b324ede837eb82c81104da7721e'])]

pages=catalog(); page_map={p['page_uuid']:p for p in pages}
assert len(pages)==35 and not(previous&set(page_map))
for p in pages:
 p['prior_known_accessible'] = sorted(legacy.get(p['page_uuid'],set()))
 p['novel_vs_C04_29'] = True
 p['novel_vs_C04_accessible_R02_R03_R04_REALIGNMENT24'] = not bool(p['prior_known_accessible'])
 p['historical_L002_membership']='UNKNOWN_NOT_AUTHENTICATED'
 p['historical_L003_membership']='UNKNOWN_NOT_AUTHENTICATED'
 p['rank_title']='Bronze 5' if p['page_uuid'] in set(x['page_uuid'] for x in pages[:11]) else ('Ouro 5' if p['page_uuid'] in set(x['page_uuid'] for x in pages[11:29]) else 'Prata 1')
 p['rank_triple_concordance']=p['rank_body'].lower()==p['rank_title'].lower() and p['rank_folder'].lower().startswith(p['rank_title'].lower())
 p['source_state']='READ_ONLY_NOTION_MASTER_BODY_EXCERPT_TRANSCRIBED_NOT_RAW_TEXT_SNAPSHOT'
 p['rank_conflict']='NONE_RANK' if p['rank_triple_concordance'] else 'TITLE_BODY_ANCESTOR_NOT_ALL_CONCORDANT'

normal=[]; components=[]; pmfs=[];id_count=collections.Counter()
for p in pages:
 for pos,a in enumerate(p['abilities'],1):
  uid=p['page_uuid'];eid=f'{uid}::C05_EFFECT::{pos:02d}';f=a['literal_formula'];channel=a['channel'];state='INCOMPLETE_NO_NUMERIC_SOURCE'
  group='CONDITIONAL_UNRESOLVED'
  if channel=='VIDA':group='HP_RAW_FORMULA_NUMERIC'
  elif channel=='ALMA':group='SOUL_RESOURCE_NOT_HP'
  elif channel in ('CURA_OU_PURIFICAÇÃO','CURA_PENDENTE'):group='NON_OFFENSIVE_OR_ALTERNATIVE_UNRESOLVED'
  elif channel=='DEFESA':group='NON_OFFENSIVE_DEFENSE'
  elif channel in ('INCREMENTO',):group='INCREMENTAL_DAMAGE_NOT_STANDALONE'
  else:group='NON_NUMERIC_OR_OTHER_CHANNEL'
  attr={k:(int(p[k]) if p[k]!='' else None) for k in ('FOR','DES','INT')}
  stat={}
  if f!='SEM FORMULA' and channel in ('VIDA','ALMA','CURA_OU_PURIFICAÇÃO'):
   try:
    stat=metrics(f,attr,rd=15 if channel=='VIDA' else None,threshold=35)
    state='EXACT_FORMULA_CONDITIONAL_ON_HIT_OR_EFFECT_NOT_COMPLETE_COMBAT'
   except ValueError as exc:state='UNSUPPORTED_EXPRESSION_'+str(exc)
  elif channel=='INCREMENTO':state='NUMERIC_MODIFIER_TRIGGER_AND_STACKING_NOT_DOCUMENTED'
  elif channel=='DEFESA':state='RDF_NOT_DAMAGE'
  elif f!='SEM FORMULA':state='NUMERIC_NON_HP_OR_COMBINED_EFFECT_UNRESOLVED'
  if stat:
   pmfs.append({'effect_id':eid,'page_uuid':uid,'source_url':p['url'],'channel':channel,'parsed':stat})
   for idx,(n,faces) in enumerate(stat['dice'],1):components.append({'effect_id':eid,'component_id':f'{eid}:DICE{idx}','kind':'DICE','literal':f'{n}d{faces}','mean':n*(faces+1)/2,'classification':group})
   if stat['attribute_code']:components.append({'effect_id':eid,'component_id':f'{eid}:ATTR','kind':'ATTRIBUTE','literal':stat['attribute_code']+'='+str(stat['attribute_value']),'mean':stat['attribute_value'],'classification':group})
  normal.append({'effect_id':eid,'page_uuid':uid,'url':p['url'],'species_parent_uuid':p['parent_species_uuid'],'species_parent_name':p['species'],'rank_title':p['rank_title'],'rank_body':p['rank_body'],'rank_ancestor':p['rank_folder'],'rank_triple':p['rank_triple_concordance'],'name_literal':a['name'],'formula_literal':f,'effect_channel':channel,'evidence_layer':group,'precision':'NOT_DOCUMENTED','PA_cost':'NOT_DOCUMENTED','action_economy':'NOT_DOCUMENTED','RD':'NOT_DOCUMENTED_TYPE_TARGET','duration':'NOT_DOCUMENTED','conditions':'SEE_SOURCE_NO_INVENTION','math_state':state,'gross_mean_conditional':stat.get('gross_mean'),'gross_min':stat.get('gross_min'),'gross_max':stat.get('gross_max'),'post_rd15_mean_TEST':stat.get('post_rd_expected_on_hit'),'source_date':p['source_last_edit_date'],'legacy_overlap':','.join(p['prior_known_accessible']),'source_verification':'NOTION_DIRECT_READ_OCT17_EXCERPT_ONLY'})
  id_count[group]+=1

out_pages=OUT/'C05_SOURCE_PAGES_35_FORENSIC.json';out_pages.write_text(json.dumps(pages,ensure_ascii=False,indent=2)+'\n')
(OUT/'C05_DAMAGE_PMF_EXACT.json').write_text(json.dumps(pmfs,ensure_ascii=False,indent=2)+'\n')
(OUT/'C05_EIGHT_MENTIONS_ADJUDICATED.json').write_text(json.dumps([{'uuid':u,'url':'https://app.notion.com/p/'+u,'species':name,'physical_element':element,'physical_rank_folder':rank,'page_children_UUIDs':children,'decision':'LEGITIMATE_CROSS_REFERENCE_TO_EXISTING_SPECIES_IN_OTHER_ELEMENT_INDEX','does_not_create_new_creature':True,'access':'NOTION_MASTER_DIRECT_2026-10-17'} for u,name,element,rank,children in mentions],ensure_ascii=False,indent=2)+'\n')
def writecsv(name,rows):
 with (OUT/name).open('w',newline='',encoding='utf8') as f:
  if rows:
   fields=list(rows[0]);w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
writecsv('C05_DAMAGE_EFFECTS_NORMALIZED_58.csv',normal)
writecsv('C05_DAMAGE_COMPONENTS_EXACT.csv',components)
lineage=[]
for p in pages:
 lineage.append({'uuid':p['page_uuid'],'source_url':p['url'],'C04_prior':False,'R02_R03_R04_REALIGNMENT24':','.join(p['prior_known_accessible']) or 'NOT_FOUND','L002_ORIGINAL':'UNKNOWN','L003_ORIGINAL':'UNKNOWN','novel_vs_accessible_matrices':p['novel_vs_C04_accessible_R02_R03_R04_REALIGNMENT24'],'outcome':'NEW_RELATIVE_TO_ACCESSIBLE_MATRICES_NOT_ASSERTING_LOT_MEMBERSHIP' if p['novel_vs_C04_accessible_R02_R03_R04_REALIGNMENT24'] else 'HISTORICAL_EXCLUSION_ID_MATCH'})
writecsv('C05_HISTORICAL_LINEAGE_DEDUP_35.csv',lineage)
cohort_old=[x for x in base_effects if x['source_page_uuid'] in {'206c2b324ede835383a1818a6edd5273','4bac2b324ede8321af6b01eb96452d04','474c2b324ede82d08ea6819069c17043','725c2b324ede8301baed01d62bd2b8e0','966c2b324ede83d7962b019b1861b6b1','92bc2b324ede828f9b040180a09d926d'} and x['channel']=='VIDA' and x['gross_mean']]
assert len(cohort_old)==6,len(cohort_old)
cohort_new=[]
for p in pages:
 if p['rank_triple_concordance']:
  cohort_new.extend(x for x in normal if x['page_uuid']==p['page_uuid'] and x['evidence_layer']=='HP_RAW_FORMULA_NUMERIC' and x['gross_mean_conditional'] is not None)
old_prata=sorted(float(x['gross_mean']) for x in cohort_old)
new_prata=sorted(float(x['gross_mean_conditional']) for x in normal if x['page_uuid'] in {'1c6c2b324ede8252872c81bd287fb516','0c9c2b324ede82ab8be801371d927931','336c2b324ede82ac82ab01ac0eb062a2','778c2b324ede83d0a89281a4c12ba768','77ec2b324ede82d49662812c1e72b7b0'} and x['evidence_layer']=='HP_RAW_FORMULA_NUMERIC' and x['gross_mean_conditional'] is not None)
# This expanded title/body P1 stratum is NOT rank-ancestral concordant; DO NOT merge with triple-concordant population.
cohort={'C04_triple_P1_gross_means':old_prata,'C05_new_title_body_Prata1_ancestor_conflicted':new_prata,'C05_strict_triple_P1_new':0,'C05_new_triple_Bronze5_EFFECTS':[{'effect':x['name_literal'],'gross':x['gross_mean_conditional'],'source':x['url']} for x in cohort_new],'scientific_strata':'NEVER_MERGE_CONFLICTED_ANCESTRY_INTO_TRIPLE_P1_COHORT','complete_combat_action_fully_documented':0}
(OUT/'C05_COHORT_STRATA_AND_SENSITIVITY.json').write_text(json.dumps(cohort,ensure_ascii=False,indent=2)+'\n')
summary={'C04_baseline_pages':29,'C04_baseline_effects':37,'C04_baseline_components':45,'C05_leaf_pages_fetched':len(pages),'C05_pages_not_in_C04':len(pages),'C05_pages_not_in_R02_R03_R04_REALIGNMENT24':sum(p['novel_vs_C04_accessible_R02_R03_R04_REALIGNMENT24'] for p in pages),'C05_pages_known_R02_R03_R04_REALIGNMENT24':sum(not p['novel_vs_C04_accessible_R02_R03_R04_REALIGNMENT24'] for p in pages),'C05_effect_rows':len(normal),'C05_channels':dict(id_count),'C05_exact_formula_rows_all_channels':len(pmfs),'C05_exact_formula_HP_rows':sum(x['evidence_layer']=='HP_RAW_FORMULA_NUMERIC' and x['gross_mean_conditional'] is not None for x in normal),'C05_component_rows_for_parsed_effects':len(components),'C05_rank_triple_pages':sum(p['rank_triple_concordance'] for p in pages),'C05_additional_title_body_P1_with_ancestor_conflict':len(new_prata),'C05_effects_with_complete_hit_PA_RD':0,'C05_eight_mentioned_species_reconciled':len(mentions),'C05_mentioned_species_children_linked':sum(len(x[-1]) for x in mentions),'L002_original_archive_recovered':False,'L003_original_archive_recovered':False,'C05_selected_scope_is_not_global':True}
(OUT/'C05_SOURCE_DENOMINATORS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
