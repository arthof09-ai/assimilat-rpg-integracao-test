# DMG C05 — Pacote científico Mestre-only

**OPERATION**: OP-DMG-CORPUS-EMP-01 (existente). **State**: F0=4/8. **DMG-RANK-01 v1.1**: sem mudança.

## Recuperar e reproduzir

Extrair este ZIP em uma pasta local sem sobrepor as fontes normativas. Em Python 3, sem dependências extras:

```bash
python c05_sources.py
python experimental_damage_calc.py '1d6+1d4+For' --FOR 22 --RD 15
python c05_functional_tests.py
python c05_terminal_cross_audit.py
```

`c05_terminal_cross_audit.py` depende também do arquivo histórico C04 autenticado no caminho que aparece no seu início. Para reprodução em novo ambiente, materializar o arquivo C04 da Biblioteca (SHA256 `4c76b4e61b506b2a1bb593f452c3d997be973559fda765c0eab81d5cf786d629`) e ajustar a variável `C04` ao caminho local; o mesmo vale para `r160_reaudit.py`, que exige o ZIP R160 original da Biblioteca VLAB e os arquivos no diretório `incoming/`. Nenhum dos dois ZIPs anteriores foi incorporado novamente a este delta para evitar duplicação; apenas um CSV R160 e seu handoff legível estão incluídos como insumos de prova.

## Fontes e fronteiras

- `C05_SOURCE_PAGES_35_FORENSIC.json`: 35 páginas de variantes físicas reabertas no Notion Mestre; **trechos relevantes transcritos/normalizados, não snapshots completos da página**.
- `C05_DAMAGE_EFFECTS_NORMALIZED_58.csv`: 58 registros de habilidades/efeitos de canais variados; **não** 58 efeitos de dano à Vida mensuráveis.
- `C05_DAMAGE_PMF_EXACT.json`: 17 distribuições numéricas com probabilidade exata (16 Vida, 1 Alma) em camadas separadas.
- `C05_EXTENDED_PROVENANCE_NODES.csv` e `...EDGES.csv`: grafo C04 imutavelmente ampliado 608→648; A6 571 intacto; cinco referências pendentes não lidas.
- `C05_HISTORICAL_LINEAGE_DEDUP_35.csv`: 15/35 matches em matrizes antigas acessíveis, 20 ausentes **daquelas matrizes**. Não adjudica L002/003.
- `R160_INDEPENDENT_OBSERVATIONAL_AUDIT.json`: 154 registros, 9 RUN-IDs e 466 commits originais verificados; os testes em `r160_reaudit.py` acessam o arquivo source ZIP R160 histórico, de 15 MB, na pasta existente do VLAB.
- `C05_R160_RD_TACTIC_BREAKPOINT.csv`: cenário TEST de RD vento extra a cada magia, derivado de sete lançamentos existentes; **não é combate novo**.
- `C05_PLAN_SUPREMO_ANTES_DEPOIS_F0_F18.csv`: delta científico local; matriz Notion existente não editada.
- `C05_GATES_NAC_STATUS.json`: sem writer/lease/epoch/ACK, sem certificação formal.

## Auditoria

O primeiro cruzamento da auditoria local encontrou uma asserção excessivamente restrita do próprio auditor (`16 total PMFs`), pois havia uma décima sétima distribuição de canal ALMA. A asserção foi corrigida **para 17 PMFs, 16 de Vida**, sem alterar fonte ou fórmula. O auditor cruzado passou depois em 460/460 checagens. Esse é um ajuste de critério de auditoria, não uma evidência de duplicata ou nova fórmula de Vida.

As verificações de código dentro da mesma instância são **checks de implementação**, não codificação cega por revisor independente, não substituem NAC-PASS-02 terminal e não homologam F0.
