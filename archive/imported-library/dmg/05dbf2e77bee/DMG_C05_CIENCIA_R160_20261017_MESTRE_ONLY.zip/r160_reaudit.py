#!/usr/bin/env python3
"""Read-only independent R160 evidence audit. Never executes VLAB engine or modifies source ZIP."""
import collections,csv,hashlib,io,json,sqlite3,tempfile,zipfile,pathlib,os
P=pathlib.Path('/mnt/data/dmg_succession/cycle5')
IN=P/'incoming';C04=pathlib.Path('/mnt/data/DMG_F0_C04_CORPUS_EFICIENCIA_VLAB_20261016_MESTRE_ONLY.zip')
ZIP=IN/'VLAB_R151_R160_TACTICAL_R42_R43_CASULO_ED_BE_VERIFIED_MESTRE_ONLY.zip'
CSV=IN/'R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv'
A=collections.Counter()
def check(cond,name):
 A['all']+=1
 if not cond:raise AssertionError(name)
 A['passed']+=1

def i(r,k):return int(r[k] or 0)
with zipfile.ZipFile(ZIP) as z:
 check(z.testzip() is None,'ZIP CRC')
 manifest=json.loads(z.read('R160_SHA256_MANIFEST.json'))
 for x in manifest['files']:
  n=x['path'];b=z.read(n)
  check(len(b)==x['size'],'MANIFEST SIZE '+n)
  check(hashlib.sha256(b).hexdigest()==x['sha256'],'MANIFEST SHA '+n)
 check(len(manifest['files'])==365,'MANIFEST 365 files')
 check(z.read('r151_r160/R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv')==CSV.read_bytes(),'source scoped CSV embedded bytes')
 check(z.read('r151_r160/R160_DMG_HANDOFF_READONLY.md')==(IN/'R160_DMG_HANDOFF_READONLY.md').read_bytes(),'handoff')
 check(z.read('r151_r160/R160_SCIENCE_A_B_C_D_AND_PAIRED_COMPARISON.json')==(IN/'R160_SCIENCE_A_B_C_D_AND_PAIRED_COMPARISON.json').read_bytes(),'science')
 check(z.read('r151_r160/R160_CANDIDATE_ELIGIBILITY_SOURCE_MATRIX.json')==(IN/'R160_CANDIDATE_ELIGIBILITY_SOURCE_MATRIX.json').read_bytes(),'eligibility')
 ledger=json.loads(z.read('r151_r160/R160_SELECTED_LEDGER_COUNTS.json'))
 quarantine=json.loads(z.read('r151_r160/R160_QUARANTINE_UNKNOWN_EFFECT_NO_REPEAT.json'))
 check('R156_TACTIC_FERYN_ERISTAN_S997601' in quarantine['known_holds'],'R156 preserved')
 with CSV.open(newline='',encoding='utf-8-sig') as f: r=list(csv.DictReader(f))
 check(len(r)==154,'154 receipts')
 check(len(ledger['per_run'])==9,'9 run IDs')
 check({x['run_id'] for x in r}==set(ledger['per_run']),'run IDs matching ledger')
 check(len({(x['run_id'],x['seq_R18'],x['action_index_in_tx']) for x in r})==154,'event identity unique')
 check(len({x['cmd_id'] for x in r})<154,'cmd_id may share within multi action chain')
 with zipfile.ZipFile(C04) as old:
  prev=list(csv.DictReader(io.StringIO(old.read('VLAB_R125_R137_R150_EVENT_IDENTITY.csv').decode())))
  prevruns={x['run'] for x in prev}
 check(not({x['run_id'] for x in r}&prevruns),'R125-R137-R150 no run collision')
 for x in r:
  check(x['audit_status']=='COLD_TECHNICAL_PASS_NOT_OFFICIAL','scope')
  check(i(x,'damage_raw')==i(x,'rd_applied')+i(x,'net_post_RD'),'raw=rd+net '+x['run_id'])
  check(i(x,'net_post_RD')==i(x,'hp_effectively_lost')+i(x,'overkill'),'net=hp+overkill '+x['run_id'])
  check(x['run_id']!='R156_TACTIC_FERYN_ERISTAN_S997601','R156 excluded')
 # Independent event proof: compare each R160 CSV receipt to immutable sqlite row_sha and native_action action payload.
 byrun=collections.defaultdict(list)
 for x in r:byrun[x['run_id']].append(x)
 commit_sum=0
 with tempfile.TemporaryDirectory() as td:
  for run,arr in byrun.items():
   for ext in ('.sqlite','.genesis.json'):
    path=f'r151_r160/runs/{run}{ext}';b=z.read(path)
    check(hashlib.sha256(b).hexdigest()==ledger['per_run'][run]['sqlite_sha256' if ext=='.sqlite' else 'genesis_sha256'],'source hash '+path)
    if ext=='.sqlite':sp=pathlib.Path(td)/(run+'.sqlite');sp.write_bytes(b)
   con=sqlite3.connect(sp);con.row_factory=sqlite3.Row
   commits=con.execute('select seq,cmd_id,row_json,row_sha from events order by seq').fetchall()
   pending=con.execute('select count(*) from pending').fetchone()[0]
   commit_sum+=len(commits)
   check(pending==0,'no pending selected '+run)
   check(len(commits)==ledger['per_run'][run]['commits'],'ledger commits '+run)
   events={str(y['seq']):y for y in commits}
   check(len(arr)==ledger['per_run'][run]['native_offenses'],'native offense count '+run)
   for x in arr:
    sr=events[x['seq_R18']];item=json.loads(sr['row_json']);detail=item.get('detail') or {};acts=detail.get('native_actions') or ([] if not detail.get('native_action') else [detail['native_action']]);idx=int(x['action_index_in_tx'])-1
    check(0<=idx<len(acts),'native action at committed event')
    native=acts[idx]
    check(sr['row_sha']==x['row_SHA256'],'exact event row_SHA256')
    check(sr['cmd_id']==x['cmd_id'],'exact cmd id')
    check(native.get('action')==x['action'],'native action name')
    check(x['kind']==item['kind'],'event kind')
    check(int(native.get('raw') or 0)==i(x,'damage_raw'),'native damage raw')
    check(int(native.get('rd_applied') or 0)==i(x,'rd_applied'),'native rd')
    check(int(native.get('PA_spent') or 0)==i(x,'PA_spent'),'native pa')
   con.close()
 check(commit_sum==466,'sum commits 466')

groups={}
for run,arr in sorted(byrun.items()):
 count=collections.Counter(x['attack_origin'] for x in arr)
 m={k:sum(i(x,k) for x in arr) for k in ['damage_raw','rd_applied','net_post_RD','hp_effectively_lost','overkill','PA_spent']}
 groups[run]={'receipts':len(arr),'actors':sorted(set(x['actor'] for x in arr)),'targets':sorted(set(x['target'] for x in arr)),'kinds':dict(collections.Counter(x['kind'] for x in arr)),'attack_origins':dict(count),'hits':sum(x['hit']=='True' for x in arr),'misses':sum(x['hit']=='False' for x in arr),'save_based':sum(x['hit']=='SAVE_EFFECT' for x in arr),'negative_critical':sum(x['critical']=='NEGATIVE' for x in arr),'damage':m,'source_assumptions':sorted(set(x['source_assumption'] for x in arr)),'status':'COLD_TECHNICAL_CONDITIONAL_ONLY'}
total={k:sum(i(x,k) for x in r) for k in ['damage_raw','rd_applied','net_post_RD','hp_effectively_lost','overkill','PA_spent']}
hit_counts=dict(collections.Counter(x['hit'] for x in r));kinds=dict(collections.Counter(x['kind'] for x in r));origins=dict(collections.Counter(x['attack_origin'] for x in r));crit=dict(collections.Counter(x['critical'] for x in r));source=dict(collections.Counter(x['source_spec'] for x in r))
assert total['damage_raw']==total['rd_applied']+total['net_post_RD']
assert total['net_post_RD']==total['hp_effectively_lost']+total['overkill']
# Three event tiers, not three independent combats.
classification={'R153_CASULO_CA_SOURCE_DEV_S999013':'TECHNICAL_PROBE_CA','R154_TWO_AOO_FULL_SOURCE_DEV_S999141':'TECHNICAL_AOO','R154_TWO_AOO_KO_SOURCE_DEV_S999142':'TECHNICAL_AOO_KO','R155_AOO_NEGATIVE_R42_R43_DEV_S999353':'TECHNICAL_AOO_REJECTION','R157_TACTIC_BASIC_DEV_S997617':'DEV_TACTICAL_CONDITIONAL','R157_TACTIC_WIND_DEV_S997617':'DEV_TACTICAL_CONDITIONAL','R158_NEGATIVE_CRITICAL_TACTIC_DEV_S997946':'DEV_NEGATIVE_CRIT_CONDITIONAL','R159_ED_GRIFO_AUREN_BE_BASIC_DEV_S998803':'DEV_ED_BE_CONDITIONAL','R159_ED_GRIFO_AUREN_BE_SPECIAL_DEV_S998803':'DEV_ED_BE_CONDITIONAL'}
for run,g in groups.items():g['admissibility']=classification[run]
P.mkdir(parents=True,exist_ok=True)
report={'evidence_sha256':{'R160_source_zip':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'R160_csv':hashlib.sha256(CSV.read_bytes()).hexdigest()},'checkpoints_verified':{'zip_crc':True,'file_manifest_hashed':len(manifest['files']),'manifest_entries_not_included':['README_R160_SAFE_RESTORE.md'],'event_commit_ledgers':9,'selected_commits':466,'source_scoped_receipts':154,'cross_batch_R125_R137_R150_RUN_ID_intersection':0},'audit_checks':dict(A),'total':total,'origins':origins,'kind_counts':kinds,'hits':hit_counts,'critical':crit,'source_spec':source,'per_run':groups,'quarantined':ledger['exclude_from_science'],'R156_unknown_effect':'HOLD, NEVER REEXECUTED','handoff':'PREPARED_ONLY_NO_ACK','official_canonical_combat':False,'physical_attack_hit_rate_observed':68/122,'save_spell_events':32,'independent_experimental_units':'paired scenario families per seed, not 154 independent actions'}
(P/'R160_INDEPENDENT_OBSERVATIONAL_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
with (P/'R160_RUNLEVEL_EFFECTIVE_DAMAGE.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['run_id','class','receipts','hit_attacks','missed_attacks','save_based_spells','raw','rd','net','hp_lost','overkill','PA_spent','hp_to_raw_ratio','PA_scope'])
 for run,g in groups.items():
  d=g['damage'];w.writerow([run,g['admissibility'],g['receipts'],g['hits'],g['misses'],g['save_based'],*[d[k] for k in ['damage_raw','rd_applied','net_post_RD','hp_effectively_lost','overkill','PA_spent']],round(d['hp_effectively_lost']/d['damage_raw'],6) if d['damage_raw'] else '', 'ONLY_NATIVE_OFFENSIVE_ACTION_COST_RECORDED; NO TOTAL_SCENE_PA'])
print(json.dumps({'audit':report['audit_checks'],'totals':total,'hit':hit_counts,'origins':origins,'runs':len(groups)},ensure_ascii=False))
