# Calculadora científica experimental C05 — guia de reprodução

Este módulo **não é motor de combate, não altera DMG-RANK-01 v1.1, não autoriza aplicação de fallback em fontes com fórmulas explícitas**. A inclusão de `--RD`, `--PA`, `--hit-prob` e `--threshold` representa input documentado pelo usuário ou simulação explicitamente condicionada; o módulo não prova essas fontes.

## Uso de CLI

```bash
python experimental_damage_calc.py '1d6+1d4+For' --FOR 22 --RD 15 --threshold 30
python experimental_damage_calc.py '2d6+2d4+For' --FOR 22
python experimental_damage_calc.py '1d4+Des' --DES 24
python c05_functional_tests.py
python c05_terminal_cross_audit.py
```

Os casos são derivados de páginas verdadeiras (UUIDs em `C05_DAMAGE_EFFECTS_NORMALIZED_58.csv`); **RD=15 é TEST**, não RD normativa daquele ataque e alvo. O programa conserva distribuições como numeradores/denominadores de frações exatas e os resumos `float` servem à apresentação.

A função `metrics(formula,attrs,rd=?,hit_probability=?,pa_cost=?,threshold=?)` disponibiliza suporte bruto, PMF, media, mediana (quantil por inversão de CDF discreta), quartis, variância, participação de dados, suporte pós-RD, média pós-RD, probabilidade de dano pós-RD positivo e de superar limiar bruto. Se PA ou acerto estão ausentes, devolve INDETERMINATE. Fórmulas não suportadas ou atributos ausentes geram erro. `compare` fornece P[A>B] para rolagens independentes e RD escalar comum, hipótese não canônica.

### Limitações

- Não trata críticos, armadura por tipo, salvaguardas, reações, economia global de ação, TTK, duração não documentada, buffs ou dano de Alma/PA como Vida.
- Não infere custo de PA, porcentagem de acerto, crit chance, rank, RE/FIP nem elegibilidade normativa.
- O vetor original possui 58 registros, mas **somente 16 são ataques com fórmula numérica de Vida** e 1 efeito com fórmula de Alma (tratado em canal separado). Não denominar 58 fórmulas ofensivas completas.
- Testes: 26/26 funcionais; 883/883 comprovações combinatórias da investigação; 460/460 checks cruzados adicionais pela mesma instância (não revisão humana cega).
- Código testado em Python 3 no ambiente atual. Partidas de dados de escala extremamente grande não estão sujeitas a garantia de performance.
