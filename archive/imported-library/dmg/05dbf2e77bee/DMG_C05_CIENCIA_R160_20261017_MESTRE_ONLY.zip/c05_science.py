#!/usr/bin/env python3
"""Independent exact combinatorics, conditional rank and RD science, VLAB observational counterfactual.
All calculations deliberately distinguish reported source metrics, experimental RD and official rules.
"""
from c05_sources import catalog
from experimental_damage_calc import pmf,metrics,compare
from itertools import product
from collections import Counter
from fractions import Fraction
import json,csv,pathlib,statistics,math,zipfile,io
P=pathlib.Path('/mnt/data/dmg_succession/cycle5')
S={x['page_uuid']:x for x in catalog()}
A=json.loads((P/'C05_SOURCE_DENOMINATORS.json').read_text())
rows=list(csv.DictReader((P/'C05_DAMAGE_EFFECTS_NORMALIZED_58.csv').open()))
num=[x for x in rows if x['evidence_layer']=='HP_RAW_FORMULA_NUMERIC' and x['gross_mean_conditional']!='']
assert len(num)==16
checks=Counter()
def ok(test,label):
 checks['total']+=1
 if not test:raise AssertionError(label)
 checks['pass']+=1

def brute(formula,attrs):
 d,parsed=pmf(formula,attrs);faces=[]
 for n,f in parsed['dice']:faces += [range(1,f+1)]*n
 # Different implementation directly enumerates all Cartesian sample points
 c=Counter(parsed['fixed']+sum(values) for values in product(*faces))
 total=sum(c.values())
 return {value:Fraction(n,total) for value,n in c.items()}

brute_pass=[];stats={}
for row in num:
 p=S[row['page_uuid']];attrs={k:int(p[k]) if p[k] else None for k in ('FOR','DES','INT')}
 actual,parsed=pmf(row['formula_literal'],attrs);expected=brute(row['formula_literal'],attrs)
 ok(actual==expected,'PMF independent enumeration '+row['effect_id'])
 for v,prob in actual.items():ok(prob==expected[v],'PMF exact mass '+row['effect_id'])
 for rd in range(0,max(actual)+2):
  net=sum(Fraction(max(0,x-rd))*pr for x,pr in actual.items())
  reduced=sum(Fraction(min(x,rd))*pr for x,pr in actual.items())
  ok(net+reduced==sum(Fraction(x)*pr for x,pr in actual.items()),'damage conservation '+row['effect_id'])
 stats[row['effect_id']]={'source':row['url'],'species':row['species_parent_name'],'formula':row['formula_literal'],'rank_triple':row['rank_triple'],'mean':float(sum(k*v for k,v in actual.items())),'range':[min(actual),max(actual)],'var':float(sum(pr*(k-sum(x*q for x,q in actual.items()))**2 for k,pr in actual.items())),'dice_expected':float(parsed['die_mean']),'attribute_bonus':parsed['fixed'] if parsed['attribute'] else None,'pmf_points':len(actual)}
 brute_pass.append(row['effect_id'])

pairs=[
 ('c28c2b324ede8217937c8165a19eafa9','Rabada','Corte', 'NEW_BRONZE5_TITLE_BODY_ANCESTOR_AGREES; potential content mirror with different 92bc page'),
 ('529c2b324ede82e8a86f81f8cfc0477e','Soco','Punhos de fogo','BRONZE5_BODY_TITLE; ancestor PRATA5 conflicting'),
]
paired=[]
for page,first,second,label in pairs:
 p=S[page];a={k:int(p[k]) if p[k] else None for k in ('FOR','DES','INT')}
 byname={e['name']:e['literal_formula'] for e in p['abilities']}
 assert first in byname and second in byname
 f1,f2=byname[first],byname[second];left,right=pmf(f1,a)[0],pmf(f2,a)[0]
 curves=[]
 for rd in range(0,max(max(left),max(right))+2):
  ex1=sum(Fraction(max(0,x-rd))*prob for x,prob in left.items())
  ex2=sum(Fraction(max(0,x-rd))*prob for x,prob in right.items())
  greater=sum(pa*pb for x,pa in left.items() for y,pb in right.items() if max(0,x-rd)>max(0,y-rd))
  curves.append({'rd':rd,'mean_A':float(ex1),'mean_B':float(ex2),'prob_A_strict_greater_given_rolled_independently':float(greater),'delta':float(ex1-ex2)})
  ok(ex1>=0 and ex2>=0,'non-negative post-RD')
 paired.append({'page_uuid':page,'source_url':p['url'],'species':p['species'],'a_name':first,'a_formula':f1,'b_name':second,'b_formula':f2,'rank_status':label,'gross_mean_difference':float(sum(x*v for x,v in left.items())-sum(x*v for x,v in right.items())),'P_A_gt_B_without_RD':compare(f1,f2,a,a)['P_A_strictly_greater_than_B'],'curves':curves,'strict_order_sign_reversal':any(x['delta']<0 for x in curves),'note':'Only scalar equal RD LAB sensitivity, no hit probabilities or PA documented.'})

# Same species lineage across rank-variant pages is a confounded comparison, not independent species observations.
prior_formula='2d6+for';old=metrics(prior_formula,{'FOR':30});new=metrics(prior_formula,{'FOR':56})
assert old['gross_mean']==37 and new['gross_mean']==63
variant={'parent_species_uuid':'29bc2b324ede831c9c62812e214cdff9','species':'Rinolupo','source_P1':'https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3','source_P4':'https://app.notion.com/p/d58c2b324ede8208b24b014eaaf3ac5c','rank_conflict':'source P4 is physically title Ouro5 / body Prata4 / ancestor Ouro5; no canonical rank adjudication','formula_held_constant':'2d6+FOR','initial_FOR':30,'later_FOR':56,'gross_expected_initial':old['gross_mean'],'gross_expected_later':new['gross_mean'],'difference':26,'interpretation':'arithmetical effect of two documented FOR values, not isolated causal influence of rank or official level progression'}

with (P/'incoming/R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv').open(encoding='utf-8-sig',newline='') as f:r160=list(csv.DictReader(f))
winds=[x for x in r160 if x['run_id']=='R157_TACTIC_WIND_DEV_S997617' and x['source_spec']=='TURB']
assert len(winds)==7 and all(int(x['PA_spent'])==60 for x in winds)
basic=[x for x in r160 if x['run_id']=='R157_TACTIC_BASIC_DEV_S997617' and x['actor']=='F']
wind=[x for x in r160 if x['run_id']=='R157_TACTIC_WIND_DEV_S997617' and x['actor']=='F']
basic_hp=sum(int(x['hp_effectively_lost']) for x in basic); wind_hp=sum(int(x['hp_effectively_lost']) for x in wind)
assert basic_hp==433 and wind_hp==449
rd_sensitivity=[]
for additional_wind_RD in range(0,53):
 turbs_hp=sum(max(0,int(x['damage_raw'])-additional_wind_RD) for x in winds)
 wind_hp_new=sum(int(x['hp_effectively_lost']) for x in wind if x['source_spec']!='TURB')+turbs_hp
 rd_sensitivity.append({'RD_wind_TEST_per_spell':additional_wind_RD,'hp_total_wind_policy':wind_hp_new,'baseline_basic_policy':basic_hp,'difference':wind_hp_new-basic_hp})
 for val in [wind_hp_new,basic_hp]:ok(val>=0,'hp conditional nonnegative')
assert rd_sensitivity[0]['difference']==16
assert rd_sensitivity[2]['difference']==2
assert rd_sensitivity[3]['difference']==-5
# These are new ANALYTICAL counterfactual calculations, not VLAB reruns.
obs={'paired_seed_997617':'DEV_PAIR_N1_NOT_BLIND','Feryn_basic_HP':basic_hp,'Feryn_wind_HP_at_lab_wind_RD0':wind_hp,'Feryn_basic_PA_spent_offense_events':sum(int(x['PA_spent']) for x in basic),'Feryn_wind_PA_spent_offense_events':sum(int(x['PA_spent']) for x in wind),'incremental_HP_wind_minus_basic_at_RD0':16,'incremental_PA_wind_minus_basic':420,'marginal_HP_per_additional_PA_at_RD0':16/420,'source_spell_wind_n':7,'source_spell_wind_min_raw':min(int(x['damage_raw']) for x in winds),'exact_RD_crossover_for_wind_policy_if_same_scalar_RD_each_hit':3,'sensitivities':rd_sensitivity,'assumptions':['Same source policies and seed but RNG event alignment must be audited separately','Wind elemental RD missing in original documentation, laboratory assumed zero','One extra scalar RD per WIND spell, not automatically physical RD','No invented target CA/PA for corpus sources','This is conditional postprocessing of immutable receipts, NOT a new VLAB combat']}

a=(P/'C05_COHORT_STRATA_AND_SENSITIVITY.json')
co=json.loads(a.read_text());old=co['C04_triple_P1_gross_means'];new=co['C05_new_title_body_Prata1_ancestor_conflicted']
co['C04_strict_mean']=statistics.mean(old);co['C05_relaxed_title_body_only_mean']=statistics.mean(new);co['invalid_merged_mean_demonstration_TEST_ONLY']=statistics.mean(old+new)
co['difference_if_naively_merge_TEST_ONLY']=statistics.mean(old+new)-statistics.mean(old)
co['scope_warning']='The 5 new effects fail ancestor-rank concordance. Merging with 6 strict effects is a sensitivity diagnostic only, not a certified Prata1 population estimate.'
a.write_text(json.dumps(co,ensure_ascii=False,indent=2)+'\n')
( P/'C05_SCIENCE_NEW_WITHIN_SPECIES_RD.json').write_text(json.dumps({'exact_numeric_actions':len(num),'independent_brute_checked':len(brute_pass),'brute_auditor_checks':dict(checks),'all_numeric_formula_rows':stats,'new_pairs':paired,'source_rank_variants':variant,'R160_new_conditional_wind_RD_breakpoint':obs,'cohort_rank_sensitivity':co},ensure_ascii=False,indent=2)+'\n')
(P/'C05_R160_RD_TACTIC_BREAKPOINT.csv').write_text('RD_per_TURB_TEST,Feryn_WIND_HP_TEST,Feryn_BASIC_HP_observed,delta_HP_TEST\n'+''.join(f"{r['RD_wind_TEST_per_spell']},{r['hp_total_wind_policy']},{r['baseline_basic_policy']},{r['difference']}\n" for r in rd_sensitivity))
print(json.dumps({'pmf_brute_validated_actions':len(num),'checks':dict(checks),'pairs':[{k:x[k] for k in ('species','gross_mean_difference','P_A_gt_B_without_RD','strict_order_sign_reversal')} for x in paired],'R157_RD_breakpoint':3,'C04_P1_mean':co['C04_strict_mean'],'relaxed_but_conflicted_P1_mean':co['C05_relaxed_title_body_only_mean']},ensure_ascii=False,indent=2))
