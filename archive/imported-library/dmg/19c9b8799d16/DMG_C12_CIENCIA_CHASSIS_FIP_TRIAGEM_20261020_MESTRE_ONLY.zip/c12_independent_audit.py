#!/usr/bin/env python3
"""Auditoria independente C12: lê as saídas congeladas e recalcula com frações exatas."""
import csv,hashlib,math,json,collections,pathlib,zipfile
from fractions import Fraction
P=pathlib.Path(__file__).resolve().parent/'output'
read=lambda fn:list(csv.DictReader(open(P/fn,encoding='utf-8')))
rows=read('C12_PROSPECTIVE_PHYSICAL_CHASSIS_36.csv')
assert len(rows)==36
m={'Comum':1,'Bronze':2,'Prata':3,'Ouro':4,'Ouro Negro':5,'Lendário':6}
floor={'Bronze':4,'Prata':14,'Ouro':22,'Ouro Negro':38,'Lendário':58}
tests=0
for r in rows:
 n,d=map(int,r['literal_common'].split('d'))
 mult=m[r['rank']];k=n*mult
 mu=Fraction(k*(d+1),2)
 var=Fraction(k*(d*d-1),12)
 assert Fraction(r['mean'])==mu
 assert abs(float(r['variance'])-float(var))<1e-10
 assert r['physical_formula_TEST']==f'{k}d{d}'
 assert int(r['min'])==k and int(r['max'])==k*d
 assert math.isclose(float(r['stddev']),math.sqrt(float(var)),abs_tol=1e-10)
 assert r['relation_to_band_numeric_ONLY']==('NO_COMMON_RE_BAND' if mult==1 else ('BELOW' if mu<floor[r['rank']] else ('ABOVE' if mu>{'Bronze':18,'Prata':36,'Ouro':62,'Ouro Negro':96,'Lendário':160}[r['rank']] else 'INSIDE')))
 tests+=7
assert sum(r['rank']=='Lendário' and r['relation_to_band_numeric_ONLY']=='BELOW' for r in rows)==6
assert sum(r['rank']=='Ouro Negro' and r['relation_to_band_numeric_ONLY']=='BELOW' for r in rows)>=2
screens=read('C12_SCREENING_NOTION_25_PAGES.csv')
assert len(screens)==25 and len({r['page_uuid'] for r in screens})==25
assert sum(r['search_title_stratum']=='P1' for r in screens)==20
assert sum(r['search_title_stratum']=='B5' for r in screens)==5
assert sum(r['rank_consistency']=='CONSISTENT' for r in screens)==2
assert sum(r['candidate_direct_Vida_eligible']=='YES' for r in screens)==0
assert sum(r['prior_C05_record']=='YES' for r in screens)==10
assert sum(r['prior_C05_record']=='NO' for r in screens)==15
assert all(r['page_url'].endswith(r['page_uuid']) for r in screens)
tests+=8
fps=read('C12_FIP_WINDOW_SENSITIVITY_4_ITEMS.csv')
assert {r['item'] for r in fps}=={'Varok','Iskiel','Arveth','Feryn'}
seen=set()
for r in fps:
 name=r['item'];n=int(r['window_successful_hits_TEST']);k=int(r['number_riders_TEST']);base=Fraction(r['item_base_intrinsic_mean']);bonus=Fraction(r['rider_intrinsic_mean']);lo=Fraction(r['fip_nominal_lo']);hi=Fraction(r['fip_nominal_hi']);v=base+Fraction(k,n)*bonus
 assert abs(float(v)-float(r['item_intrinsic_mean_per_success_TEST']))<1e-8
 assert r['position_numeric_ONLY']==('BELOW' if v<lo else 'ABOVE' if v>hi else 'INSIDE')
 assert 1<=k<=n
 if name!='Iskiel':assert k==1
 assert int(r['PA_spent_in_window'])==k*{'Varok':60,'Iskiel':45,'Arveth':55,'Feryn':45}[name]
 seen.add((name,n,k));tests+=5
assert len(fps)==len(seen)
assert abs(float(Fraction(66.5)+Fraction(27.5))-94)<1e-12
assert any(r['item']=='Iskiel' and r['window_successful_hits_TEST']=='5' and r['number_riders_TEST']=='5' and r['PA_spent_in_window']=='225' for r in fps)
source=P.parent/'c11'/'C11_19_EFFECTS_SOURCE_SCOPED.csv'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='257494ae989c96f9bb753f93f388af0bda9e13066d4534f0c9bdd53097315836'
assert len(list(csv.DictReader(open(source,encoding='utf-8'))))==19
legacy=P.parent/'c11'/'DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.zip'
if legacy.exists():
 assert hashlib.sha256(legacy.read_bytes()).hexdigest()=='d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e'
 with zipfile.ZipFile(legacy) as z:assert z.testzip() is None
tests+=4
report={'status':'PASS_C12_INDEPENDENT_REPLAY','as_of':'2026-10-20','independent_checks':tests,'source_C11_snapshot_hash_pass':True,'source_C11_original_zip_verified_this_run':legacy.exists(),'chassis_rows':len(rows),'screened_source_pages':len(screens),'fip_rows':len(fps),'none_rank_inferred_from_user':True,'notion_writes':0,'official_rule_promotion':'NONE'}
(P/'C12_INDEPENDENT_QA_PASS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(report,indent=2))
