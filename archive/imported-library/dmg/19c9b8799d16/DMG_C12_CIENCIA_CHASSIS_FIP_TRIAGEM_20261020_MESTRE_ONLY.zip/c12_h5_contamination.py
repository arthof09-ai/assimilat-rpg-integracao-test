#!/usr/bin/env python3
"""Contrafactual *inadmissível* para mensurar perigo de usar título como rank; sem alterar recorte estrito."""
import csv,statistics,json,pathlib
P=pathlib.Path(__file__).resolve().parent/'output'
# Dados conferidos em páginas Notion; estas ocorrências foram EXCLUÍDAS do recorte P1 válido.
# Cabra tem 2 efeitos em uma página: nunca classificar como 2 fontes independentes.
rows=[
('034c','Investida Feroz','2d6+FOR30',37,'Ouro 5','rank ancestral difere'),
('be5c','Patada','1d6+FOR24',27.5,'Prata 5','bônus +2 FOR não incorporado; origem divergente'),
('1c6c','Raio Purificador','1d6+INT40',43.5,'Ouro 1','rank ancestral difere'),
('336c','Folhas Cortantes','1d6+INT42',45.5,'Ouro 2','cone; entrega difere e rank ancestral difere'),
('5e4c','Esmagamento Terrano','2d6+FOR26',33,'Ouro 2','entidade folha divergente'),
('778c','Garras Eletrizadas','2d6+FOR23',30,'Ouro 2','rider condicional paralisia; rank ancestral difere'),
('77ec','Corte Cerebral','2d6+INT29',36,'Ouro 1','natureza incerta; rank ancestral difere'),
('0c9c','Estalactite Afiada','1d6+INT40',43.5,'Prata 5','rider congelamento; rank ancestral difere'),
('b34c','Arranhão Duplo','2d4+DES25',30,'Prata 5','duas fórmulas uma fonte; rank ancestral difere'),
('b34c','Investida','1d6+FOR10',13.5,'Prata 5','mesma fonte da linha anterior; efeito de empurrão'),
('3bfc','Garras Congelantes','1d6+FOR28',31.5,'Ouro 4','corpo Bronze5, título P1, ancestral Ouro4'),
('c70c','Mordida Necrótica','3d6+1d4+FOR28',41,'Ouro 1','dano contínuo indefinido e bônus Dark não adicionado'),
]
import sys
sys.path.insert(0,str(P.parent))
# Resolver UUID pela matriz de triagem reprodutível, sem novo lookup.
screens={r['page_uuid'][:4]:r for r in csv.DictReader(open(P/'C12_SCREENING_NOTION_25_PAGES.csv',encoding='utf-8'))}
assert all(x[0] in screens and screens[x[0]]['rank_consistency']=='CONFLICT' for x in rows)
with open(P/'C12_H5_FALSE_TITLE_STRATUM_NEGATIVE_CONTROL.csv','w',newline='',encoding='utf-8') as h:
 w=csv.writer(h);w.writerow(['source_page_uuid','page_url','ability','formula_original_excerpt','mean_gross_conditional','ancestor_not_P1','exclusion_reason','unit','state'])
 for a,b,c,d,e,f in rows:w.writerow([screens[a]['page_uuid'],screens[a]['page_url'],b,c,d,e,f,'EFFECT; clustered by page UUID','EXCLUDED_FROM_STRICT_STATISTICS'])
strict=list(csv.DictReader(open(P.parent/'c11'/'C11_19_EFFECTS_SOURCE_SCOPED.csv',encoding='utf-8')))
a=[float(r['mean_gross']) for r in strict if r['stratum']=='P1_NATURAL_STRICT']
assert len(a)==6
bad=[r[3] for r in rows]
res={}
for k,x in [('C11_strict_P1_unmodified',a),('C12_false_titled_P1_EXCLUDED',bad),('INVALID_hypothetical_pool_NEVER_USE',a+bad)]:
 res[k]={'n_effects':len(x),'mean':statistics.mean(x),'median':statistics.median(x),'min':min(x),'max':max(x),'range':max(x)-min(x)}
res.update({'rows_C12_excluded':len(rows),'unique_page_sources_C12_excluded':len({r[0] for r in rows}), 'warning':'MATHEMATICAL_NEGATIVE_CONTROL_ONLY. NEVER ADD THESE TO STRICT_P1. Not an estimate of rank population or rank differences.'})
(P/'C12_H5_SOURCE_SELECTION_BIAS_TEST.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(res,ensure_ascii=False,indent=2))

with open(P/'C12_DIAGNOSTICO_EMPIRICO_PROSPECTIVO_MESTRE_ONLY.md','a',encoding='utf-8') as doc:
 doc.write('\n### H5 — Contrafactual de contaminação, com dados de fontes REAIS mas exclusão obrigatória\n\nEm **11 páginas** de rank ancestral discordante há **12 expressões autônomas** de dano à Vida, uma página com dois ataques distintos. São fontes reabertas no Notion, **não** são efeitos P1 elegíveis, e não foram somadas ao C11. Para provar como uma busca por título pode distorcer a ciência, simulamos **somente como controle negativo matemático** a junção incorreta dessas expressões ao conjunto P1 estrito C11:\n\n| Distribuição de médias por efeito | n efeitos | Média entre efeitos | Mediana | Extremos | Amplitude |\n|---|---:|---:|---:|---|---:|\n| C11 P1 **estrito verdadeiro** | 6 | 33,67 | 32,25 | 31–40,5 | 9,5 |\n| C12 títulos P1 **excluídos por conflito** | 12 (11 fontes) | 34,33 | 34,5 | 13,5–45,5 | 32 |\n| **Junção proibida, apenas para detectar viés** | 18 (17 fontes, não necessariamente independentes) | 34,11 | 32,75 | 13,5–45,5 | 32 |\n\nEmbora a média mudasse pouco, a amplitude subiria de **9,5 para 32**, mais de **3,36×**, o que poderia fazer a dispersão aparente parecer um problema do dano quando é principalmente **um problema de linhagem**. Não inferir erro de regra, variância populacional, FIP ou progressão com essa junção. `C12_H5_FALSE_TITLE_STRATUM_NEGATIVE_CONTROL.csv` e `C12_H5_SOURCE_SELECTION_BIAS_TEST.json` congelam o experimento negativo. Fonte da comparação verdadeira: seis efeitos C11 preservados sem modificação.\n' )
