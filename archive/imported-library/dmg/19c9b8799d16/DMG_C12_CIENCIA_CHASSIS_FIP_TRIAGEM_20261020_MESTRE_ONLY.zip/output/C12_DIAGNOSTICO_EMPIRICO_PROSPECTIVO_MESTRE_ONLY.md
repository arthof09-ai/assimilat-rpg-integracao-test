# PSV — DMG C12+ / PRIMEIRA RECONCILIAÇÃO PROSPECTIVA E TRIAGEM EMPÍRICA

**AS-OF** 2026-10-20 | **OPERATION** OP-DMG-CORPUS-EMP-01 | **BASELINE** DMG-RANK-01 v1.1 VIGENTE | **F0** 4/8 | **PROD** HOLD | **READ-ONLY / MESTRE-SIDE**.

## Perguntas científicas

1. A regra prospectiva do Mestre `chassi NdS × rank` cabe no mesmo eixo que o orçamento RE/FIP da DMG-RANK v1.1? **Não: eixos distintos, confronto nominal abaixo.**
2. Os alertas FIP C11 persistem após incorporar riders e janelas de sucesso? **A classificação numérica pode mudar dependendo das ativações; portanto o alerta de dano-base sozinho NÃO diagnostica desbalanceamento.**
3. Buscar páginas pelos rótulos Bronze5/Prata1 aumenta a amostra comparável? **Nas 25 páginas de conveniência reabertas, zero novo efeito ofensivo direto de Vida admissível ao estrato estrito; isso expõe viés de amostragem, não prova ausência no restante do corpus.**

## Recuperação ANTES→DEPOIS

**ANTES**: C11 original SHA `d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e`, 19 efeitos/15 fontes/4 estratos/40 parcelas. A6=571 UUIDs estruturais congelados, NÃO 571 habilidades. Dois `(1)` C11 são análises redundantes e NÃO entram no denominador. F0 4/8.

**DEPOIS**: 25 novas leituras físicas de triagem P1/B5 como páginas distintas; 10 já possuem registros no CSV C05, 15 ausentes daquele CSV (não afirmar inéditas globais); zero novas definições Vida admitidas ao estrato estrito. 36 células `chassi×rank`, quatro itens ON5 em análise de janela FIP, nenhuma nova regra, nenhuma luta. **F0 formal não avança.**

## Experimento C18 — diferença entre chassi físico obrigatório e DME do efeito

Fonte do chassis: DMG-RANK-01 §8 (Comum) e **decisão expressa do Mestre recebida nesta missão** multiplicando a quantidade total de dados por Comum1/Bronze2/Prata3/Ouro4/OuroNegro5/Lendário6. A §5 exige 38–96 DME do efeito ON e 58–160 do efeito Lendário, não do puro chassi. §13 separa bônus externos. §22 atribui o orçamento à ação/efeito inteiro, não a cada tipo de componente.

| Chassi | Comum | Bronze | Prata | Ouro | Ouro Negro | Lendário |
|---|---:|---:|---:|---:|---:|---:|
| Espada 1d8 | 4,5 | 9 | 13,5 | 18 | 22,5 | 27 |
| Brutal 2d6 | 7 | 14 | 21 | 28 | 35 | 42 |

**Achado novo:** os **6/6 chassis típicos** `1d3,1d4,1d6,1d8,1d10,2d6` escalados a Lendário ×6 apresentam média física <58. **Não tratar isso como seis erros da norma:** a decisão nova descreve a CAMADA FÍSICA; as bandas da v1.1 referem-se ao efeito ofensivo intrínseco classificado em condições específicas. É ilegítimo (a) impor piso58 à camada física nua, (b) aplicar efeito mágico completo por cima de um orçamento que já inclui chassi, ou (c) usar esse teste para retcon de armas históricas.

**Conclusão operacional PROPOSTA, não regra promulgada:** contrato de novas armas `CHASSI_FÍSICO_PROSPECTIVO` + `DME_EFEITO_CLASSIFICADO/COMPONENTES/RI/FIP` + `ATRIBUTOS/FF/OUTROS_BÔNUS_EXTERNOS`, com prova de unicidade da parcela física e prova de que o orçamento de efeito/ação completa não duplica a parcela. Qual ponto recebe RI/RE deve ser decidido pela fonte competente; não estabelecer nova hierarquia silenciosamente. Endereçar REC-MOD-ARM, DMG-RANK, CRAFT/PA, VLAB TEST e normas via NAC-NORM se houver proposta de implantação. **Nada foi escrito nesses entrypoints.**

**Segundo resultado físico:** ao multiplicar o número de dados, a média e a variância aumentam linearmente com o multiplicador, mas a dispersão relativa `desvio-padrão/média` diminui como `1/sqrt(rank_multiplier)`. Nova arma de rank maior fica relativamente menos volátil, consequência da decisão física, não de hipótese de magia.

## H3 — janela e custo mudam alertas FIP (C11 reusado, nova sensibilidade)

| Item Lendário PROPOSTO | DME item-base | Rider e custo | Média do item em 1 sucesso com rider | Média por sucesso em janela de 5 sucessos, 1 rider |
|---|---:|---|---:|---:|
| Varok Baixa 73–90 | 80 | +39 por 60 PA 1/cena | 119 | 87,8 |
| Iskiel Média 91–112 | 66,5 | +27,5 por 45 PA; voo 20m; 1/turno | 94 | 72 |
| Arveth Baixa 73–90 | 68 | +33 por 55 PA 1/cena | 101 | 74,6 |
| Feryn Baixa 73–90 | 60 | +22,5 por 45 PA 1/cena | 82,5 | 64,5 |

**Condição que invalida uma equivalência ingênua:** se Iskiel conseguir acionar seu Mergulho em cinco TURNOS elegíveis distintos, a média do item nos cinco tiros seria 94, com gasto ativo **225 PA**, em vez de 72 com uma ativação. Não assumir turnos=acertos, voo garantido, PA atual suficiente, RD universal, acerto, crítico, Vida nem regra de FIP por janela. **Isso NÃO homologa o equilíbrio dos itens**; reforça que a subfaixa não pode ser julgada pela base isolada nem pelo único pico.

## C13/C14 — triagem anti-contaminação, não censo

Dois conjuntos oportunísticos obtidos por busca Notion Mestre em 20/10: **20** páginas-filhas chamadas `Prata 1` e **5** chamadas `Bronze 5`, reabertas. Entre P1, somente **2/20** apresentam corpo E ancestral Prata1 concordantes. Nenhuma fornece NOVA fórmula **autônoma de dano direto à Vida** homologável ao estrato C11; um perfil tem dano à Alma e outro somente bônus `+3 dano`. Nas 5 Bronze5, **0/5** têm ancestral Bronze5, apesar de alguns corpos alegarem Bronze5. É um resultado de seleção de candidatos, sem inferência sobre proporções no acervo global. Mais **2 páginas P1** foram identificadas, mas fetch falhou; são `INACCESSIBLE`, não cobertura positiva.

Páginas P1 cujo corpo menciona Prata1, mas cuja ancestralidade aponta Ouro2/Prata5 etc., NÃO foram reclassificadas nem usadas na média. CSV individual contém todos os 25 UUIDs, ancestrais, expressões relevantes, pertinência ao C05 e motivo de exclusão. O recorte antigo C11 segue 19 efeitos, 15 páginas, **sem acrescentar o que já aparecia em C05**. Não afirmar que 15 páginas ausentes do CSV C05 estejam ausentes do restante dos lotes históricos, A6 ou Notion. `A6=571` é índice de referências estruturais, não censo de páginas de efeito.

## Estado F0 e plano científico

F0 permanece 4/8 conforme C11, sem writer/lease/epoch comprovados; A5, A7, A8 requerem gates, blindagem ou autorização adicional. **F1–F12: estudos exploratórios parciais, fases formalmente não promovidas; F13–F18: não iniciadas nesta C12+.** L002/L003 sem matriz de pertinência binária recuperada e confirmada; não inventar filiação. A7 oito holdouts cegos **NÃO foram usados na calibração**. Nenhuma observação VLAB nova reivindicada: R162=154, R169=137 em coortes separadas; R156 UNKNOWN_EFFECT e R138 HOLD preservados.

## Hipóteses e parecer

- **H1 atributo:** C11 registrou predomínio de atributo em 12/12 efeitos selecionados; este lote NÃO acrescentou controle novo homogeneamente classificado, de modo que H1 permanece hipótese do recorte, sem generalização.
- **H2 diferença intra-Besta:** Corte/Rabada do Escorpião permanecem inconclusivos por atributo e conflito familiar; sem acerto/PA universal.
- **H3 FIP e rider:** análise de janelas acima discrimina hipóteses concorrentes sobre considerar base/pico/ativação; apoio a auditoria do orçamento COMPLETO, nenhuma reclassificação autorizada.
- **H4 PA:** +dano bruto/PA é apenas limite marginal condicionado; PA diário e PA por ativação continuam distintos, política universal pertence ao Executor PA.
- **H5 identidade:** 23/25 páginas selecionadas por título têm **alguma divergência de ancestral**, evidência nova de risco elevado de contaminação numa busca ingênua; não estimativa populacional.
- **H6 PROSPECTIVA TEST:** chassi físico ×rank e DME intrínseco não são a mesma variável. Testar entrada de 1d8, 2d6 e 1d10 em cada rank no pré-validador técnico competente ANTES de implantar regra; validar que soma física não é duplicada no orçamento de item+magia.

**Decisão científica:** MANTER DMG-RANK v1.1; não existe evidência para propor v2. **Recomendação específica:** integração prospectiva deve preservar separação física/mágica e auditoria de soma única; não retroagir. Confiança `ALTA para aritmética TEST e leitura da regra`, `MODERADA para diagnóstico estrutural de integração`, `BAIXA para hipóteses de equilíbrio populacional`.

**LAST-VERIFIED-UNIT:** C11 original autenticado, Notion OP/DMG/REC-MOD/QA/METHOD/TAX reabertos, 25 páginas candidatas fisicamente lidas em escopo. **FIRST-PENDING:** adjudicar roteamento prospectivo de chassis entre REC-MOD-ARM e DMG-RANK via autoridade normativa, sem mudar v1.1; em paralelo, buscar fontes rank concordante em outras rotas, não por título.

**D0–D9:** universo global ainda `UNKNOWN/NOT CERTIFIED`; C11 19 definições, 15 fontes, quatro estratos; C12 screening 25 páginas (10 sobrepostas ao CSV C05, 15 ausentes), **0** adições elegíveis a estrato estrito; 36 células analíticas prospectivas e 4 perfis FIP de sensibilidade não são 36 fontes reais nem 4 items homologados. A6 571 UUIDs referenciais intactos; L002/L003 HISTORICAL_UNRECONCILED. Denominadores não somados indiscriminadamente.

**NO-REPEAT:** C04–C11, A6-571, VLAB R162/R169 e históricos imutáveis. Nenhum motor, plugin, Diário, Inbox ou v2 criados. **CONFLICTS:** rank ancestral, Escorpião, Concha inanimada, FIP e fonte proposta ON5, RD mista, metade ímpar. **UNKNOWN-EFFECT:** R156 quarantine; R138 spatial HOLD. **NEXT-5:** censo multivia de famílias com rank concordante; documentação de RE/FIP de efeitos naturais; experimento discriminante de orçamento item/RI; conciliação CRAFT/PA/VLAB no LAB TEST com titular legítimo; F0 autoridade, holdout e auditor independente. **TARGET-REMAINDER:** F0–F18, A5/A7/A8, E01–E24, oito gates, L002/L003, D0–D9, eventual candidata com holdout.

**AUTHORITY/WRITER:** MESTRE-SIDE READ-ONLY + laboratório local TEST, sem writer/lease/epoch/fencing/ACK herdado. NOTION_WRITES=0, PARTY/O_PRIMEIRO=0, SQLITE=0, OFFICIAL_RULE_CHANGE=0. **NAC-NORM-01:** não iniciado para alteração normativa, porque proposta candidata não foi submetida nem autorizada a promover. **NAC-PASS-02:** PASS técnico delimitado após hash/replay/readback; formal e produção HOLD.

### H5 — Contrafactual de contaminação, com dados de fontes REAIS mas exclusão obrigatória

Em **11 páginas** de rank ancestral discordante há **12 expressões autônomas** de dano à Vida, uma página com dois ataques distintos. São fontes reabertas no Notion, **não** são efeitos P1 elegíveis, e não foram somadas ao C11. Para provar como uma busca por título pode distorcer a ciência, simulamos **somente como controle negativo matemático** a junção incorreta dessas expressões ao conjunto P1 estrito C11:

| Distribuição de médias por efeito | n efeitos | Média entre efeitos | Mediana | Extremos | Amplitude |
|---|---:|---:|---:|---|---:|
| C11 P1 **estrito verdadeiro** | 6 | 33,67 | 32,25 | 31–40,5 | 9,5 |
| C12 títulos P1 **excluídos por conflito** | 12 (11 fontes) | 34,33 | 34,5 | 13,5–45,5 | 32 |
| **Junção proibida, apenas para detectar viés** | 18 (17 fontes, não necessariamente independentes) | 34,11 | 32,75 | 13,5–45,5 | 32 |

Embora a média mudasse pouco, a amplitude subiria de **9,5 para 32**, mais de **3,36×**, o que poderia fazer a dispersão aparente parecer um problema do dano quando é principalmente **um problema de linhagem**. Não inferir erro de regra, variância populacional, FIP ou progressão com essa junção. `C12_H5_FALSE_TITLE_STRATUM_NEGATIVE_CONTROL.csv` e `C12_H5_SOURCE_SELECTION_BIAS_TEST.json` congelam o experimento negativo. Fonte da comparação verdadeira: seis efeitos C11 preservados sem modificação.


## C12–C21 — estado de execução, sem inflar fases F0–F18

| Unidade | Entrega científica neste checkpoint | Estado |
|---|---|---|
| C12 | C11 autenticado; F0 reconciliado; hipótese prioritária e contraste novo | PASS técnico / F0 HOLD |
| C13 | 25 páginas triadas; recusa legítima de novas amostras estritas | PARCIAL |
| C14 | Revisão de pertinência ao C05 e não inclusão de duplicatas | HOLD L002/L003 primários indisponíveis |
| C15 | Camadas físico/rider/FF/FIP separadas, C11 reutilizado | PARCIAL |
| C16 | Fronteiras numéricas prospectivas em 36 chassis-rank; sem pares reais válidos | TEST / fronteira empírica HOLD |
| C17 | H3 janelas FIP e H5 controle negativo; H1/H2 ainda não falsificados | PARCIAL |
| C18 | Regras físicas novas confrontadas com §§5/8/13/22 da v1.1 | PASS TEST / normativo HOLD |
| C19 | C10 e coortes R162/R169 mantidos, sem observações novas | REUTILIZADO |
| C20 | Parecer de NÃO criar v2 por falta de base; propor roteiro de integração prospectiva | PASS científico delimitado |
| C21 | Oráculo separado, pacote delta portátil e readback após publicação | PASS técnico após prova material |

Nenhum desses estados promove automaticamente F1–F18. F0 formal permanece 4/8; F13–F18 não foram executadas/homologadas.
