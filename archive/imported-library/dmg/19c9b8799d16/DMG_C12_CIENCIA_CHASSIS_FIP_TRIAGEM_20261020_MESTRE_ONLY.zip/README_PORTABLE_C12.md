# C12+ DMG — Pacote científico portátil | MESTRE-SIDE

**Não é novo motor:** scripts pequenos produzem CSV de auditoria científica e NÃO consultam Notion automaticamente. Usam duas planilhas CSV históricas byte-identificadas do C05/C11 e 25 transcrições de metadados extraídos via conector Mestre em 20/10/2026. Conferir fontes vivas no Notion antes de adotar novos números. O ZIP C11 original permanece em Biblioteca, SHA `d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e` (não duplicado aqui).

## Leitura mais útil
- `output/C12_DIAGNOSTICO_EMPIRICO_PROSPECTIVO_MESTRE_ONLY.md`: conclusões e limites; não necessita de terminal.
- `output/C12_SCREENING_NOTION_25_PAGES.csv`: 25 UUIDs, nome, ancestral, corpo, edição, exclusão.
- `output/C12_H5_FALSE_TITLE_STRATUM_NEGATIVE_CONTROL.csv` e JSON: controle NEGATIVO, não misturar a amostra inválida.
- `output/C12_PROSPECTIVE_PHYSICAL_CHASSIS_36.csv`: 6 chassis × 6 ranks incluindo Comum (decisão prospectiva do Mestre TEST).
- `output/C12_FIP_WINDOW_SENSITIVITY_4_ITEMS.csv`: 4 itens ON5 propostos; janelas hipotéticas, não adjudicação FIP.
- `output/C12_C21_STAGE_AND_PHASE_STATUS.csv`: execução delimitada / HOLD por unidade.

## Reproduzir com Python 3 sem bibliotecas externas
Extraia este ZIP num diretório de sua escolha e execute sequencialmente:

```
python build_c12.py
python c12_h5_contamination.py
python c12_status_finalize.py
python c12_independent_audit.py
```

O último comando deve produzir `PASS_C12_INDEPENDENT_REPLAY` com 459 verificações. Os scripts não têm API, login, gravação Notion, operação de combate VLAB ou escrita de regras. O ZIP C11 original, se presente opcionalmente em `c11/` com nome original, também tem hash/CRC verificados; sem ele, valida-se a extração CSV C11 autêntica por SHA-256.

## Autoridade e limitações
- DMG-RANK-01 v1.1 oficial imutável; PA/CRAFT e VLAB competentes por suas operações.
- 25 páginas de seleção conveniente não são uma amostra aleatória, nem 25 efeitos independentes ou 25 fontes globais inéditas.
- Resultado de equações físicas por rank é DEMONSTRAÇÃO TEST da decisão expressa do Mestre, não implantação formal na norma.
- Um script capaz de calcular efeitos não prova equivalência mecânica nem execução em mesa. F0 4/8, produção HOLD.
