#!/usr/bin/env python3
"""Materialização determinística da tabela de estado C12–C21, não um motor científico."""
import csv,pathlib
P=pathlib.Path(__file__).resolve().parent/'output'
rows=[
('C12','C11 cold/hash + F0 reconciliation + first new science','PASS_TECH / F0_HOLD','C11 sha verified; 4/8; H3/H5/C18 studies'),
('C13','Discover new source candidates without conflating title and ancestor','PARTIAL_SCREENING','25 direct Notion page reads; 0 new strict Vida effect; 15 pages absent C05 only'),
('C14','Reconcile L002/L003 lineage with C04/C05/A6','HOLD_ORIGINAL_LOTS_NOT_FOUND','No L002/L003 primary membership ZIP; keep 571 refs + C11 source dedup'),
('C15','Normalize intrinsic/external layers in existing cohort','REUSED_C11 / PARTIAL_NEW','19 effects C11 unmodified; four ON5 items rider/FIP scenarios new'),
('C16','Rank boundaries across matched family','HOLD_NO_MATCHED_RE_FIP','36 TEST physical chassis×rank cells are not source effects or cross-rank paired observations'),
('C17','Falsify C11 hypotheses','PARTIAL_PASS_H3_H5','39 FIP window TEST cases; 12 excluded counterfactual effects / 11 pages'),
('C18','Prospective physical rank rule compatibility','PASS_TEST / NORM_HOLD','36 chassis-rank cases; six of six Lendario chassis below 58 effect-DME floor, axis separation'),
('C19','Use C10 defense/VLAB newer receipts when available','REUSED / NEW_OBSERVATIONS_NONE','C10 and two historical R162/R169 cohorts frozen; no VLAB new claims'),
('C20','Evidence sufficient for v2?','NO_RECOMMEND_V2','Maintain v1.1; consider only prospective interface contract for physical chassis'),
('C21','Validation, portable science delta, readback','PASS_LOCAL / LIBRARY_READBACK_TO_FOLLOW','459 independent math QA checks; ZIP/readback status logged separately')]
with open(P/'C12_C21_STAGE_AND_PHASE_STATUS.csv','w',encoding='utf-8',newline='') as h:
 w=csv.writer(h);w.writerow(['unit','objective','result_state','material_evidence']);w.writerows(rows)
with open(P/'C12_DIAGNOSTICO_EMPIRICO_PROSPECTIVO_MESTRE_ONLY.md','a',encoding='utf-8') as h:
 h.write('\n\n## C12–C21 — estado de execução, sem inflar fases F0–F18\n\n| Unidade | Entrega científica neste checkpoint | Estado |\n|---|---|---|\n| C12 | C11 autenticado; F0 reconciliado; hipótese prioritária e contraste novo | PASS técnico / F0 HOLD |\n| C13 | 25 páginas triadas; recusa legítima de novas amostras estritas | PARCIAL |\n| C14 | Revisão de pertinência ao C05 e não inclusão de duplicatas | HOLD L002/L003 primários indisponíveis |\n| C15 | Camadas físico/rider/FF/FIP separadas, C11 reutilizado | PARCIAL |\n| C16 | Fronteiras numéricas prospectivas em 36 chassis-rank; sem pares reais válidos | TEST / fronteira empírica HOLD |\n| C17 | H3 janelas FIP e H5 controle negativo; H1/H2 ainda não falsificados | PARCIAL |\n| C18 | Regras físicas novas confrontadas com §§5/8/13/22 da v1.1 | PASS TEST / normativo HOLD |\n| C19 | C10 e coortes R162/R169 mantidos, sem observações novas | REUTILIZADO |\n| C20 | Parecer de NÃO criar v2 por falta de base; propor roteiro de integração prospectiva | PASS científico delimitado |\n| C21 | Oráculo separado, pacote delta portátil e readback após publicação | PASS técnico após prova material |\n\nNenhum desses estados promove automaticamente F1–F18. F0 formal permanece 4/8; F13–F18 não foram executadas/homologadas.\n')
