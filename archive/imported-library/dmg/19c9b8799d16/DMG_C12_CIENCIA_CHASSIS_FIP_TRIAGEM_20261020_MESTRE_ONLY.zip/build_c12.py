#!/usr/bin/env python3
"""C12+ delta científico: usa C11 pré-registrado, sem motor concorrente nem mudanças canônicas."""
from pathlib import Path
import csv, json, math, hashlib, zipfile, statistics, collections, re
from fractions import Fraction

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
SRC=ROOT/'c11'
SHA=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

# Linhas de triagem são transcrição delimitada de páginas Notion Mestre reabertas em 20/10/2026;
# NOTA: os UUIDs são páginas de ficha-estrela, não criam espécie independente ou cânone.
# code, candidate_title, parent, ancestor, body, Vida-effect admissibility, source formula, comment
S=[
('034c','P1','Rinolupo','Ouro 5','Prata 1','2d6+FOR30','CONFLICT_ANCESTOR'),
('987c','P1','Morcego Gasoso','Prata 1','Prata 1','4d6 ALMA; 1d4/tick TOXICO incerto','ALMA_NOT_VIDA; DOT_UNCERTAIN'),
('be5c','P1','Lobo das Cavernas','Prata 5','Prata 1','1d6+FOR24','CONFLICT_ANCESTOR'),
('1c6c','P1','Aurora Radiante','Ouro 1','Prata 1','1d6+INT40','CONFLICT_ANCESTOR'),
('336c','P1','Verdantis Sibilante','Ouro 2','Prata 1','1d6+INT42 cone 4.5m','CONFLICT_ANCESTOR'),
('5e4c','P1','Símio Demoníaco / Golem de Pedra','Ouro 2','Prata 1','2d6+FOR26','CONFLICT_ANCESTOR'),
('45bc','P1','Véu Noturno','Ouro 4','Prata 1','2d4+INT14 PA drenado','PA_NOT_VIDA; CONFLICT'),
('778c','P1','Símio Demoníaco / Raios de Tempestade','Ouro 2','Prata 1','2d6+FOR23','CONFLICT_ANCESTOR'),
('77ec','P1','Polvo da Floresta','Ouro 1','Prata 1','2d6+INT29','CONFLICT_ANCESTOR'),
('5fcc','P1','Demônio Vermelho','Prata 1','Prata 1','+3 dano, bônus sem fórmula-base','RIDER_ONLY; NOT_EFFECT_DEFINITION'),
('0c9c','P1','Cristalino Gélido','Prata 5','Prata 1','1d6+INT40','CONFLICT_ANCESTOR'),
('8aac','P1','Símio Demoníaco / Guardião Sombrio','Ouro 2','Prata 1','+5 dano, bônus sem fórmula-base','RIDER_ONLY; CONFLICT_ANCESTOR'),
('b34c','P1','Ovelha de Chifres / Cabra','Prata 5','Prata 1','2d4+DES25; 1d6+FOR10','CONFLICT_ANCESTOR'),
('945c','P1','Basilisco / Dracarídeo','Lendário 2','Bronze','sem dano Vida explícito','CONFLICT_ANCESTOR; NO_FORMULA'),
('2a7c','P1','Anjo / Ser de Energia','Lendário 2','Bronze','sem dano Vida explícito','CONFLICT_ANCESTOR; NO_FORMULA'),
('3bfc','P1','Leopardo das Montanhas','Ouro 4','Bronze 5','1d6+FOR28','CONFLICT_ANCESTOR_BODY_TITLE'),
('c1ec','P1','Gárgula / Dracapra','Ouro Negro 5','Bronze','sem dano Vida explícito','CONFLICT_ANCESTOR; NO_FORMULA'),
('102c','P1','Neve Cornífera','Prata 1','Bronze','sem dano Vida explícito','CONFLICT_BODY_TITLE'),
('9d0c','P1','Guepardo Luminoso','Ouro 2','Bronze','sem dano Vida explícito','CONFLICT_ANCESTOR_BODY_TITLE'),
('c70c','P1','Crocossuário Corrompido / Crocossombra','Ouro 1','Prata sem estrela','3d6+1d4+FOR28','CONFLICT_ANCESTOR; RIDER_DARK_UNCERTAIN'),
('7cfc','B5','Basilisco / Dracarídeo','Lendário 2','Bronze','sem dano Vida explícito','CONFLICT_ANCESTOR'),
('a01c','B5','Crocossuário Aquático','Prata 2','Bronze 5','1d6+1d4+FOR22','CONFLICT_ANCESTOR'),
('35ec','B5','Aranha das Cavernas','Prata 2','Bronze 5','1d6+FOR24; 2d6 ALMA','CONFLICT_ANCESTOR; ALMA_SEPARATE'),
('f0dc','B5','Frígido Ossário','Prata 3','Bronze 5','1d6+FOR18; +1d4 gelo condicional','CONFLICT_ANCESTOR; RIDER_UNRESOLVED'),
('6c6c','B5','Serpente do Equinócio','Lendário 1','Bronze','sem dano Vida explícito','CONFLICT_ANCESTOR; NO_FORMULA'),
]
# UUIDs lidos diretamente; short prefixes das fichas título não são chaves de identidade de família.
UUID={
'034c':'034c2b324ede83ffa7118144011beaf3','987c':'987c2b324ede82768b4c819713d0dc31','be5c':'be5c2b324ede832e8b7a81c5460571c1','1c6c':'1c6c2b324ede8252872c81bd287fb516','336c':'336c2b324ede82ac82ab01ac0eb062a2','5e4c':'5e4c2b324ede8282ad2c01c9363c3098','45bc':'45bc2b324ede823cb1328108c91421b4','778c':'778c2b324ede83d0a89281a4c12ba768','77ec':'77ec2b324ede82d49662812c1e72b7b0','5fcc':'5fcc2b324ede8339a5bd01cd65ea103e','0c9c':'0c9c2b324ede82ab8be801371d927931','8aac':'8aac2b324ede837391a481ce32a03119','b34c':'b34c2b324ede82a88079016b52ba498e','945c':'945c2b324ede82a99ef201ead7561c49','2a7c':'2a7c2b324ede836abefc81af3e7aeef6','3bfc':'3bfc2b324ede826b9a1881a45c3050df','c1ec':'c1ec2b324ede82e59b8181001666041f','102c':'102c2b324ede83da9f3381d817425372','9d0c':'9d0c2b324ede83f2a3ca817b6475bd61','c70c':'c70c2b324ede831c8f6c018c0b9295bd','7cfc':'7cfc2b324ede8307861981852366b0c7','a01c':'a01c2b324ede8347b691819d3509d7d7','35ec':'35ec2b324ede823bbb5281e4b5ccf0d9','f0dc':'f0dc2b324ede820ab9470168d4a53315','6c6c':'6c6c2b324ede8378862581feae2c1807',
}
EDITED_AT={
'034c':'2026-10-01T18:00:46.623Z','987c':'2026-10-01T18:00:42.818Z','be5c':'2026-10-01T18:00:33.930Z',
'1c6c':'2026-10-01T18:01:00.329Z','336c':'2026-10-01T18:00:55.106Z','5e4c':'2026-10-01T18:01:07.090Z',
'45bc':'2026-10-01T18:00:53.269Z','778c':'2026-10-01T18:00:52.773Z','77ec':'2026-10-01T18:00:59.760Z',
'5fcc':'2026-10-01T18:00:47.413Z','0c9c':'2026-10-01T18:00:42.714Z','8aac':'2026-10-01T18:00:53.897Z',
'b34c':'2026-10-01T18:00:34.133Z','945c':'2026-10-01T18:01:09.611Z','2a7c':'2026-10-01T18:01:00.490Z',
'3bfc':'2026-10-01T18:00:42.892Z','c1ec':'2026-10-01T18:01:06.798Z','102c':'2026-10-01T18:00:43.782Z',
'9d0c':'2026-10-01T18:01:03.116Z','c70c':'2026-10-01T18:00:40.278Z',
'7cfc':'2026-10-01T18:01:09.124Z','a01c':'2026-10-01T18:00:40.722Z','35ec':'2026-10-01T18:00:54.978Z',
'f0dc':'2026-10-01T18:00:42.693Z','6c6c':'2026-10-01T18:01:00.604Z',
}
assert len(S)==len(UUID)==len(EDITED_AT)==25

c05_file=ROOT/'c05'/'C05_DAMAGE_EFFECTS_NORMALIZED_58.csv'
assert SHA(c05_file)=='11f2dc2178967cbf8de9530ed5f2c965269d4344a0e877abede82ef4320bd24b'
c05rows=list(csv.DictReader(open(c05_file,encoding='utf-8')))
c05={r['page_uuid'] for r in c05rows}
with open(OUT/'C12_SCREENING_NOTION_25_PAGES.csv','w',newline='',encoding='utf-8') as h:
 w=csv.writer(h);w.writerow(['page_uuid','page_url','notion_last_edited_at','fetch_date','search_title_stratum','parent_entity_title','ancestor_rank','body_rank','offensive_content_excerpt','rank_consistency','candidate_direct_Vida_eligible','prior_C05_record','provenance','limitations'])
 for short,folder,entity,ancestor,body,formula,notes in S:
  uuid=UUID[short]; consistent=(folder=='P1' and ancestor=='Prata 1' and body=='Prata 1') or (folder=='B5' and ancestor=='Bronze 5' and body=='Bronze 5')
  isvida=consistent and bool(re.search(r'\d+d\d+', formula)) and 'ALMA' not in formula and 'RIDER_ONLY' not in notes and 'DOT' not in notes and 'PA ' not in formula
  w.writerow([uuid,'https://app.notion.com/p/'+uuid,EDITED_AT[short],'2026-10-20',folder,entity,ancestor,body,formula,'CONSISTENT' if consistent else 'CONFLICT','YES' if isvida else 'NO', 'YES' if uuid in c05 else 'NO','NOTION_MESTRE_FETCH_2026-10-20',notes])

bands={'Bronze':(4,18),'Prata':(14,36),'Ouro':(22,62),'Ouro Negro':(38,96),'Lendário':(58,160)}
mult={'Comum':1,'Bronze':2,'Prata':3,'Ouro':4,'Ouro Negro':5,'Lendário':6}
chassis=[('Improvisada','1d3',1,3),('Leve','1d4',1,4),('Leve-marcial','1d6',1,6),('Marcial','1d8',1,8),('Pesada/versátil','1d10',1,10),('Brutal duas mãos','2d6',2,6)]
with open(OUT/'C12_PROSPECTIVE_PHYSICAL_CHASSIS_36.csv','w',newline='',encoding='utf-8') as h:
 w=csv.writer(h);w.writerow(['chassis','literal_common','rank','master_multiplier','physical_formula_TEST','min','max','mean','variance','stddev','coefficient_variation','DMG_rank_intrinsic_band','relation_to_band_numeric_ONLY','source'])
 for name,form,n,d in chassis:
  for rank,m in mult.items():
   mean=n*m*(d+1)/2;var=n*m*(d*d-1)/12;std=math.sqrt(var)
   b=bands.get(rank)
   rel=('BELOW' if mean<b[0] else 'ABOVE' if mean>b[1] else 'INSIDE') if b else 'NO_COMMON_RE_BAND'
   w.writerow([name,form,rank,m,f'{n*m}d{d}',n*m,n*m*d,mean,var,std,std/mean,str(b) if b else 'N_A',rel,'MASTER_PROSPECTIVE_SCALING_TEST__DMG_RANK_V1_1_CHASSIS'])

# FIP análise do orçamento completo com janelas (não classifica normativamente por média temporal).
items=[('Varok','Baixa',80,39,60,'ONCE_PER_SCENE',95,'4d6+100','10d10+25','SOURCE_PROPOSED'),('Iskiel','Média',66.5,27.5,45,'ONCE_PER_TURN_REQUIRES_FLY20M',95,'4d6+101','9d8+26','SOURCE_PROPOSED'),('Arveth','Baixa',68,33,55,'ONCE_PER_SCENE',85,'4d6+72','8d10+24','SOURCE_PROPOSED'),('Feryn','Baixa',60,22.5,45,'ONCE_PER_SCENE',90,'4d6+92','8d8+24','SOURCE_PROPOSED')]
fip={'Baixa':(73,90),'Média':(91,112)}
with open(OUT/'C12_FIP_WINDOW_SENSITIVITY_4_ITEMS.csv','w',newline='',encoding='utf-8') as h:
 w=csv.writer(h);w.writerow(['item','FIP_PROPOSED','window_successful_hits_TEST','number_riders_TEST','item_base_intrinsic_mean','rider_intrinsic_mean','item_intrinsic_mean_per_success_TEST','fip_nominal_lo','fip_nominal_hi','position_numeric_ONLY','PA_spent_in_window','PA_link_daily_NOT_PER_HIT','frequency','assumptions'])
 for name,position,base,bonus,cost,freq,daily,atk,form,state in items:
  for n in [1,2,3,4,5,6,7,10]:
   for k in ([1,n] if name=='Iskiel' and n>1 else [1]):
    v=base+bonus*k/n;low,high=fip[position];label='BELOW' if v<low else 'ABOVE' if v>high else 'INSIDE'
    w.writerow([name,position,n,k,base,bonus,round(v,9),low,high,label,k*cost,daily,freq,'SUCCESSFUL_HITS_NOT_TURNS; ASSUME_TRIGGER_ELIGIBLE; NO_RD_NO_CRITICAL_NO_DOUBLE_FF; ISKIEL_MULTIPLE_USES_REQUIRE_DIFFERENT_ELIGIBLE_TURNS_AND_FLIGHT; NOT_CANON_FIP_ADJUDICATION'])

source_c11=list(csv.DictReader(open(SRC/'C11_19_EFFECTS_SOURCE_SCOPED.csv',encoding='utf-8')))
assert len(source_c11)==19
c11_sha='d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e'
assert SHA(SRC/'C11_19_EFFECTS_SOURCE_SCOPED.csv')=='257494ae989c96f9bb753f93f388af0bda9e13066d4534f0c9bdd53097315836'
original_c11=ROOT/'c11'/'DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.zip'
if original_c11.exists():
 assert SHA(original_c11)==c11_sha
summary={
 'as_of':'2026-10-20','operation':'OP-DMG-CORPUS-EMP-01','formal_F0':'4/8 HOLD','baseline':'DMG-RANK-01 v1.1 unchanged',
 'C11_sha_verified':c11_sha,'C11_19_effects':len(source_c11),'C11_unique_pages':len({r['source_uuid'] for r in source_c11}),
 'screened_fetched_leaf_pages':len(S),'screened_pages_P1_title':sum(r[1]=='P1' for r in S),'screened_pages_B5_title':sum(r[1]=='B5' for r in S),
 'rank_consistent_P1':sum(r[1]=='P1' and r[3]=='Prata 1' and r[4]=='Prata 1' for r in S),
 'rank_consistent_B5':sum(r[1]=='B5' and r[3]=='Bronze 5' and r[4]=='Bronze 5' for r in S),
 'new_comparable_direct_Vida_effects_in_screen':0,
 'screened_pages_already_in_C05':sum(UUID[r[0]] in c05 for r in S),
 'screened_pages_absent_from_C05_only':sum(UUID[r[0]] not in c05 for r in S),
 'query_results_not_fetched_due_to_errors':['56ac2b324ede83528681e11ea16355','383c2b324ede8266adb819fc078a66a'],
 'sampling':'TITLE_SEARCH_CONVENIENCE_SCREENING; NOT_COMPLETE_CENSUS; NO_HOLDOUT_USED_FOR_CALIBRATION; NO_GLOBAL_RECALL_CLAIM',
 'prospective_scaling_chassis':len(chassis),'prospective_scaling_ranks':len(mult),'prospective_scaling_cells':len(chassis)*len(mult),
 'FIP_items':len(items),'new_norm_version':'NONE','notion_writes':0,'party_writes':0,'sqlite_writes':0,
 'scientific_results':[
  'All six DMG-RANK §8 typical physical chassis at Legendary scale x6 have mean below 58 DME floor; physical chassis axis is not equivalent to classified offensive effect DME.',
  'At Black Gold x5, 1d8=22.5 and 2d6=35 below the effect DME floor 38; avoid forced band normalization or budget double-counting.',
  'Physical chassis variance scales with rank multiplier and coefficient of variation shrinks as inverse square root; no invented numeric magical rider.',
  'FIP base-versus-rider positioning changes with scene success-window and trigger eligibility; C11 3/4 FIP alerts must not be promoted to rules.',
  'Title-only sampling demonstrated rank conflicts and no extra strict direct Vida effects in these chosen pages; confidence in census still low.'
 ],
 'F0_8_status':['4/8 reported in C11, not re-certified by write readback','source/fixture fingerprint and root map still pending','holdout/independent double coder and writer state pending'],
 'R156':'UNKNOWN_EFFECT_QUARANTINE','R138':'SPATIAL_HOLD','R162':'154_SEPARATE','R169':'137_SEPARATE',
}
(OUT/'C12_RECONCILIATION_AND_FINDINGS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

# Public report: durable scientific output, not a calculator or v2.
with open(OUT/'C12_DIAGNOSTICO_EMPIRICO_PROSPECTIVO_MESTRE_ONLY.md','w',encoding='utf-8') as h:
 h.write('''# PSV — DMG C12+ / PRIMEIRA RECONCILIAÇÃO PROSPECTIVA E TRIAGEM EMPÍRICA

**AS-OF** 2026-10-20 | **OPERATION** OP-DMG-CORPUS-EMP-01 | **BASELINE** DMG-RANK-01 v1.1 VIGENTE | **F0** 4/8 | **PROD** HOLD | **READ-ONLY / MESTRE-SIDE**.

## Perguntas científicas

1. A regra prospectiva do Mestre `chassi NdS × rank` cabe no mesmo eixo que o orçamento RE/FIP da DMG-RANK v1.1? **Não: eixos distintos, confronto nominal abaixo.**
2. Os alertas FIP C11 persistem após incorporar riders e janelas de sucesso? **A classificação numérica pode mudar dependendo das ativações; portanto o alerta de dano-base sozinho NÃO diagnostica desbalanceamento.**
3. Buscar páginas pelos rótulos Bronze5/Prata1 aumenta a amostra comparável? **Nas 25 páginas de conveniência reabertas, zero novo efeito ofensivo direto de Vida admissível ao estrato estrito; isso expõe viés de amostragem, não prova ausência no restante do corpus.**

## Recuperação ANTES→DEPOIS

**ANTES**: C11 original SHA `d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e`, 19 efeitos/15 fontes/4 estratos/40 parcelas. A6=571 UUIDs estruturais congelados, NÃO 571 habilidades. Dois `(1)` C11 são análises redundantes e NÃO entram no denominador. F0 4/8.

**DEPOIS**: 25 novas leituras físicas de triagem P1/B5 como páginas distintas; 10 já possuem registros no CSV C05, 15 ausentes daquele CSV (não afirmar inéditas globais); zero novas definições Vida admitidas ao estrato estrito. 36 células `chassi×rank`, quatro itens ON5 em análise de janela FIP, nenhuma nova regra, nenhuma luta. **F0 formal não avança.**

## Experimento C18 — diferença entre chassi físico obrigatório e DME do efeito

Fonte do chassis: DMG-RANK-01 §8 (Comum) e **decisão expressa do Mestre recebida nesta missão** multiplicando a quantidade total de dados por Comum1/Bronze2/Prata3/Ouro4/OuroNegro5/Lendário6. A §5 exige 38–96 DME do efeito ON e 58–160 do efeito Lendário, não do puro chassi. §13 separa bônus externos. §22 atribui o orçamento à ação/efeito inteiro, não a cada tipo de componente.

| Chassi | Comum | Bronze | Prata | Ouro | Ouro Negro | Lendário |
|---|---:|---:|---:|---:|---:|---:|
| Espada 1d8 | 4,5 | 9 | 13,5 | 18 | 22,5 | 27 |
| Brutal 2d6 | 7 | 14 | 21 | 28 | 35 | 42 |

**Achado novo:** os **6/6 chassis típicos** `1d3,1d4,1d6,1d8,1d10,2d6` escalados a Lendário ×6 apresentam média física <58. **Não tratar isso como seis erros da norma:** a decisão nova descreve a CAMADA FÍSICA; as bandas da v1.1 referem-se ao efeito ofensivo intrínseco classificado em condições específicas. É ilegítimo (a) impor piso58 à camada física nua, (b) aplicar efeito mágico completo por cima de um orçamento que já inclui chassi, ou (c) usar esse teste para retcon de armas históricas.

**Conclusão operacional PROPOSTA, não regra promulgada:** contrato de novas armas `CHASSI_FÍSICO_PROSPECTIVO` + `DME_EFEITO_CLASSIFICADO/COMPONENTES/RI/FIP` + `ATRIBUTOS/FF/OUTROS_BÔNUS_EXTERNOS`, com prova de unicidade da parcela física e prova de que o orçamento de efeito/ação completa não duplica a parcela. Qual ponto recebe RI/RE deve ser decidido pela fonte competente; não estabelecer nova hierarquia silenciosamente. Endereçar REC-MOD-ARM, DMG-RANK, CRAFT/PA, VLAB TEST e normas via NAC-NORM se houver proposta de implantação. **Nada foi escrito nesses entrypoints.**

**Segundo resultado físico:** ao multiplicar o número de dados, a média e a variância aumentam linearmente com o multiplicador, mas a dispersão relativa `desvio-padrão/média` diminui como `1/sqrt(rank_multiplier)`. Nova arma de rank maior fica relativamente menos volátil, consequência da decisão física, não de hipótese de magia.

## H3 — janela e custo mudam alertas FIP (C11 reusado, nova sensibilidade)

| Item Lendário PROPOSTO | DME item-base | Rider e custo | Média do item em 1 sucesso com rider | Média por sucesso em janela de 5 sucessos, 1 rider |
|---|---:|---|---:|---:|
| Varok Baixa 73–90 | 80 | +39 por 60 PA 1/cena | 119 | 87,8 |
| Iskiel Média 91–112 | 66,5 | +27,5 por 45 PA; voo 20m; 1/turno | 94 | 72 |
| Arveth Baixa 73–90 | 68 | +33 por 55 PA 1/cena | 101 | 74,6 |
| Feryn Baixa 73–90 | 60 | +22,5 por 45 PA 1/cena | 82,5 | 64,5 |

**Condição que invalida uma equivalência ingênua:** se Iskiel conseguir acionar seu Mergulho em cinco TURNOS elegíveis distintos, a média do item nos cinco tiros seria 94, com gasto ativo **225 PA**, em vez de 72 com uma ativação. Não assumir turnos=acertos, voo garantido, PA atual suficiente, RD universal, acerto, crítico, Vida nem regra de FIP por janela. **Isso NÃO homologa o equilíbrio dos itens**; reforça que a subfaixa não pode ser julgada pela base isolada nem pelo único pico.

## C13/C14 — triagem anti-contaminação, não censo

Dois conjuntos oportunísticos obtidos por busca Notion Mestre em 20/10: **20** páginas-filhas chamadas `Prata 1` e **5** chamadas `Bronze 5`, reabertas. Entre P1, somente **2/20** apresentam corpo E ancestral Prata1 concordantes. Nenhuma fornece NOVA fórmula **autônoma de dano direto à Vida** homologável ao estrato C11; um perfil tem dano à Alma e outro somente bônus `+3 dano`. Nas 5 Bronze5, **0/5** têm ancestral Bronze5, apesar de alguns corpos alegarem Bronze5. É um resultado de seleção de candidatos, sem inferência sobre proporções no acervo global. Mais **2 páginas P1** foram identificadas, mas fetch falhou; são `INACCESSIBLE`, não cobertura positiva.

Páginas P1 cujo corpo menciona Prata1, mas cuja ancestralidade aponta Ouro2/Prata5 etc., NÃO foram reclassificadas nem usadas na média. CSV individual contém todos os 25 UUIDs, ancestrais, expressões relevantes, pertinência ao C05 e motivo de exclusão. O recorte antigo C11 segue 19 efeitos, 15 páginas, **sem acrescentar o que já aparecia em C05**. Não afirmar que 15 páginas ausentes do CSV C05 estejam ausentes do restante dos lotes históricos, A6 ou Notion. `A6=571` é índice de referências estruturais, não censo de páginas de efeito.

## Estado F0 e plano científico

F0 permanece 4/8 conforme C11, sem writer/lease/epoch comprovados; A5, A7, A8 requerem gates, blindagem ou autorização adicional. **F1–F12: estudos exploratórios parciais, fases formalmente não promovidas; F13–F18: não iniciadas nesta C12+.** L002/L003 sem matriz de pertinência binária recuperada e confirmada; não inventar filiação. A7 oito holdouts cegos **NÃO foram usados na calibração**. Nenhuma observação VLAB nova reivindicada: R162=154, R169=137 em coortes separadas; R156 UNKNOWN_EFFECT e R138 HOLD preservados.

## Hipóteses e parecer

- **H1 atributo:** C11 registrou predomínio de atributo em 12/12 efeitos selecionados; este lote NÃO acrescentou controle novo homogeneamente classificado, de modo que H1 permanece hipótese do recorte, sem generalização.
- **H2 diferença intra-Besta:** Corte/Rabada do Escorpião permanecem inconclusivos por atributo e conflito familiar; sem acerto/PA universal.
- **H3 FIP e rider:** análise de janelas acima discrimina hipóteses concorrentes sobre considerar base/pico/ativação; apoio a auditoria do orçamento COMPLETO, nenhuma reclassificação autorizada.
- **H4 PA:** +dano bruto/PA é apenas limite marginal condicionado; PA diário e PA por ativação continuam distintos, política universal pertence ao Executor PA.
- **H5 identidade:** 23/25 páginas selecionadas por título têm **alguma divergência de ancestral**, evidência nova de risco elevado de contaminação numa busca ingênua; não estimativa populacional.
- **H6 PROSPECTIVA TEST:** chassi físico ×rank e DME intrínseco não são a mesma variável. Testar entrada de 1d8, 2d6 e 1d10 em cada rank no pré-validador técnico competente ANTES de implantar regra; validar que soma física não é duplicada no orçamento de item+magia.

**Decisão científica:** MANTER DMG-RANK v1.1; não existe evidência para propor v2. **Recomendação específica:** integração prospectiva deve preservar separação física/mágica e auditoria de soma única; não retroagir. Confiança `ALTA para aritmética TEST e leitura da regra`, `MODERADA para diagnóstico estrutural de integração`, `BAIXA para hipóteses de equilíbrio populacional`.

**LAST-VERIFIED-UNIT:** C11 original autenticado, Notion OP/DMG/REC-MOD/QA/METHOD/TAX reabertos, 25 páginas candidatas fisicamente lidas em escopo. **FIRST-PENDING:** adjudicar roteamento prospectivo de chassis entre REC-MOD-ARM e DMG-RANK via autoridade normativa, sem mudar v1.1; em paralelo, buscar fontes rank concordante em outras rotas, não por título.

**D0–D9:** universo global ainda `UNKNOWN/NOT CERTIFIED`; C11 19 definições, 15 fontes, quatro estratos; C12 screening 25 páginas (10 sobrepostas ao CSV C05, 15 ausentes), **0** adições elegíveis a estrato estrito; 36 células analíticas prospectivas e 4 perfis FIP de sensibilidade não são 36 fontes reais nem 4 items homologados. A6 571 UUIDs referenciais intactos; L002/L003 HISTORICAL_UNRECONCILED. Denominadores não somados indiscriminadamente.

**NO-REPEAT:** C04–C11, A6-571, VLAB R162/R169 e históricos imutáveis. Nenhum motor, plugin, Diário, Inbox ou v2 criados. **CONFLICTS:** rank ancestral, Escorpião, Concha inanimada, FIP e fonte proposta ON5, RD mista, metade ímpar. **UNKNOWN-EFFECT:** R156 quarantine; R138 spatial HOLD. **NEXT-5:** censo multivia de famílias com rank concordante; documentação de RE/FIP de efeitos naturais; experimento discriminante de orçamento item/RI; conciliação CRAFT/PA/VLAB no LAB TEST com titular legítimo; F0 autoridade, holdout e auditor independente. **TARGET-REMAINDER:** F0–F18, A5/A7/A8, E01–E24, oito gates, L002/L003, D0–D9, eventual candidata com holdout.

**AUTHORITY/WRITER:** MESTRE-SIDE READ-ONLY + laboratório local TEST, sem writer/lease/epoch/fencing/ACK herdado. NOTION_WRITES=0, PARTY/O_PRIMEIRO=0, SQLITE=0, OFFICIAL_RULE_CHANGE=0. **NAC-NORM-01:** não iniciado para alteração normativa, porque proposta candidata não foi submetida nem autorizada a promover. **NAC-PASS-02:** PASS técnico delimitado após hash/replay/readback; formal e produção HOLD.
''')
print(json.dumps(summary,ensure_ascii=False,indent=2))
