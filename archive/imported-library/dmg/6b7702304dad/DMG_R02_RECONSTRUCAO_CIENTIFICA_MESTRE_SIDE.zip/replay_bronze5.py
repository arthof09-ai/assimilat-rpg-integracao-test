import json, hashlib, itertools, pathlib
R=[
('Azuragon','cd7c2b324ede822f89e9015f9812673d', [('Jato de Bolhas',[(1,6)],24,'INT'),('Cauda de Coral',[(1,6)],19,'DES')], None),
('Raposa Alfa','529c2b324ede82e8a86f81f8cfc0477e',[('Punhos de Fogo',[(1,4)],0,None),('Soco',[(1,6)],20,'FOR')],None),
('Escorpião Ártico','c28c2b324ede8217937c8165a19eafa9',[('Rabada',[(1,4)],24,'DES'),('Corte',[(1,6)],8,'FOR')],None),
('Escorpião de Diamante (nome do corpo: Escorpião Ártico)','92bc2b324ede834ca813812ff4783805',[('Rabada',[(1,6),(1,4)],22,'FOR'),('Corte',[(1,6)],25,'DES')],'CONFLITO_IDENTIDADE'),
]
out=[]
for name,pid,attacks,conflict in R:
 arr=[]
 for an,pools,attribute,attrname in attacks:
  dist=[1]
  for n,s in pools:
   for _ in range(n):
    nextd=[0]*(len(dist)+s)
    for idx,ways in enumerate(dist):
     for face in range(1,s+1):nextd[idx+face]+=ways
    dist=nextd
  tot=sum(dist)
  base=sum(i*w for i,w in enumerate(dist))/tot
  gross=base+attribute
  arr.append(dict(name=an,dice='+'.join(f'{n}d{s}' for n,s in pools),attr_name=attrname,attribute=attribute,base_mean=base,gross_mean=gross,attr_fraction=(attribute/gross if gross else None),min_damage=sum(n for n,s in pools)+attribute,max_damage=sum(n*s for n,s in pools)+attribute,distribution={str(i+attribute):int(w) for i,w in enumerate(dist) if w},distribution_total=tot))
 delta0=arr[0]['base_mean']-arr[1]['base_mean'];delta1=arr[0]['gross_mean']-arr[1]['gross_mean']
 status='INVERSION' if delta0*delta1<0 else 'BASE_TIE' if delta0==0 else 'GROSS_TIE' if delta1==0 else 'ORDER_PRESERVED'
 out.append(dict(creature=name,source='https://app.notion.com/p/'+pid,source_page_id=pid,source_status='CANON_PAGE_READ; analytical conflict may apply',conflict=conflict,attacks=arr,delta_base=delta0,delta_gross=delta1,ordering=status))
summary=dict(operation='OP-DMG-CORPUS-EMP-01',as_of='2026-10-15',scope='MASTER_SIDE_READ_ONLY',baseline='DMG-RANK-01 v1.1 unchanged',method='uniform independent faces within a single documented attack expression; no hit chance, RD or combat derived',page_count=4,paired_creatures=4,attack_expressions=8,order_inversions=sum(x['ordering']=='INVERSION' for x in out),base_ties=sum(x['ordering']=='BASE_TIE' for x in out),status='NEW_INDEPENDENT_REPLAY_OF_PRIMARY_NOTION_PAGE_FORMULAS; NOT CLAIMED AS SAME HISTORICAL FIVE_PAIRS',source_units=out)
positive=[a['attr_fraction'] for r in out for a in r['attacks'] if a['attribute']>0]
summary['attribute_positive_actions']=len(positive)
summary['attribute_share_at_least_80_percent']=sum(v>=0.8 for v in positive)
summary['attribute_share_median_of_positive_actions']=sorted(positive)[len(positive)//2]
p=pathlib.Path('/mnt/data/dmg_recovery/bronze5_four_pairs_replay.json');p.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');
assert summary['order_inversions']==2 and summary['page_count']==4 and summary['attack_expressions']==8
for x in out:
 for a in x['attacks']:
  dist=a['distribution']; assert sum(dist.values())==a['distribution_total'] and abs(sum(int(k)*v for k,v in dist.items())/sum(dist.values())-a['gross_mean'])<1e-9
print('PASS: 4 physical pages, 8 expressions, 4 page-pairs, 2 strict inversions; exact finite discrete distributions verified')
print('Attribute 7 positive',summary['attribute_positive_actions'],'share >= 80%',summary['attribute_share_at_least_80_percent'],'median fraction',summary['attribute_share_median_of_positive_actions'])
print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
for x in out:print(x['creature'],x['ordering'],[(a['name'],a['base_mean'],a['gross_mean']) for a in x['attacks']])
