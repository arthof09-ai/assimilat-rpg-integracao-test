#!/usr/bin/env python3
"""OP-DMG-CORPUS-EMP-01 R02: documentary source-gated math, not combat.

All source expressions and attributes manually transcribed from primary Notion
pages physically fetched 2026-10-15. No Notion writer. Cannot certify lot 003
membership or a canonical hit/cost. Python standard library only.
"""
from __future__ import annotations
import csv,hashlib,itertools,json,statistics,collections,math,pathlib,datetime
ROOT=pathlib.Path(__file__).resolve().parent
ASOF='2026-10-15'; OP='OP-DMG-CORPUS-EMP-01'; RANKRULE='DMG-RANK-01 v1.1'
RULE_RD='https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd'
RULE_COMBAT='https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0'
# fields are physical page evidence, not adjudications; parent rank is ancestor-2
PAGES=[
 # source_id, tree_species, body_species, title, body_rank, ancestor_rank, CA, printed attrs, provenance confidence
 ('cd7c2b324ede822f89e9015f9812673d','Azuragon','Azuragon','Bronze 5','Bronze 5','Bronze 5',30,{'FOR':5,'DES':19,'INT':24},'B5'),
 ('a01c2b324ede8347b691819d3509d7d7','Crocossuário','Crocossáurio Aquático','Bronze 5','Bronze 5','Prata 2',34,{'FOR':22,'DES':20,'INT':6},'B5'),
 ('f0dc2b324ede820ab9470168d4a53315','Frígido Ossário','Frígido Ossário','Bronze 5','Bronze 5','Prata 3',31,{'FOR':18,'DES':18,'INT':12},'B5'),
 ('35ec2b324ede823bbb5281e4b5ccf0d9','Aranha das Cavernas','aranha das cavernas','Bronze 5','Bronze 5','Prata 2',29,{'FOR':24,'DES':18,'INT':19},'B5'),
 ('7cfc2b324ede8307861981852366b0c7','Basilisco','Dracarídeo Verde','Bronze 5','Bronze sem estrela','Lendário 2',33,{'FOR':7,'DES':20,'INT':28},'B5'),
 ('529c2b324ede82e8a86f81f8cfc0477e','Raposa Flamejante','raposa alfa','Bronze 5','Bronze 5','Prata 5',33,{'FOR':20,'DES':20,'INT':15},'B5'),
 ('6c6c2b324ede8378862581feae2c1807','Serpente do Equinócio','Serpentes do Equinócio','Bronze 5','Bronze sem estrela','Lendário 1',35,{'FOR':10,'DES':23,'INT':19},'B5'),
 ('c28c2b324ede8217937c8165a19eafa9','Escorpião Ártico','escorpião Ártico','Bronze 5','Bronze 5','Bronze 5',37,{'FOR':8,'DES':24,'INT':18},'B5'),
 ('92bc2b324ede834ca813812ff4783805','Escorpião de Diamante','escorpião Ártico','Bronze 5','Bronze 5','Bronze 5',37,{'FOR':22,'DES':25,'INT':7},'B5'),
 ('728c2b324ede8254879601340a0b23e6','Bicefalia','Bicefalia','Bronze 5','Prata sem estrela','Ouro 5',16,{'FOR':6,'DES':7,'INT':5},'B5'),
 ('341c2b324ede8272aef80156a5633b7b','Serpente Flamejante','Serpentes do Equinócio [conteúdo misturado]','Bronze 5','Bronze sem estrela','Ouro Negro 2',37,{'FOR':4,'DES':29,'INT':16},'B5'),
 ('fe9c2b324ede83f6853f01b48b5b6df3','Ovelha de Chifres','Cabra de chifres','Bronze 5','Bronze 4','Prata 5',29,{'FOR':33,'DES':16,'INT':2},'B5'),
 ('23dc2b324ede8261856701444f7a39c3','Pegasus folium','Equídeo Alado da Floresta','Bronze 5','Lendário sem estrela','Ouro 2',38,{'FOR':10,'DES':24,'INT':18},'B5'),
 # cross rank comparator set from Lote 002 textual report; re-opened physically in R02
 ('eddc2b324ede829f8a75011e8acbf429','Galidemus','galinha demoníaca','Bronze 1','Bronze 1','Bronze 1',21,{'FOR':5,'DES':13,'INT':6},'L002_REPORTED'),
 ('391c2b324ede8252b0cc810423cdbfa6','Ovelha de Chifres','Cabra de chifres','Bronze 1','Bronze 1','Prata 5',20,{'FOR':13,'DES':8,'INT':2},'L002_REPORTED'),
 ('40ec2b324ede825990c2014b4ef594cb','Felpudo','felpudo','Bronze 1','Bronze sem estrela','Bronze 1',19,{'FOR':3,'DES':8,'INT':5},'L002_REPORTED'),
 ('00ac2b324ede831caf1e01e90e81df3b','Rato Corrompido','Cerebrato','Bronze 1','Bronze 1','Bronze 1',19,{'FOR':2,'DES':8,'INT':21},'L002_REPORTED'),
 ('4d0c2b324ede827b9925018be01e60ca','Raposa Flamejante','raposa flamejante','Bronze 2','Bronze 2','Prata 5',25,{'FOR':2,'DES':14,'INT':16},'L002_REPORTED'),
 ('301c2b324ede828caccb813d3979267a','Símio Demoníaco','macaco rei','Prata 5 (titã)','Prata 5','Ouro Negro 5',67,{'FOR':54,'DES':40,'INT':30},'L002_REPORTED'),
 ('5dac2b324ede83f39cdb01a904ce3cfd','Behemoth Glacial','Behemoth Glacial','Ouro 1','Ouro 1','Ouro 1',68,{'FOR':18,'DES':52,'INT':30},'L002_REPORTED'),
]
SOURCE_EDITED={
 'cd7c2b324ede822f89e9015f9812673d':'2026-10-01T18:00:40.591Z',
 'a01c2b324ede8347b691819d3509d7d7':'2026-10-01T18:00:40.722Z',
 'f0dc2b324ede820ab9470168d4a53315':'2026-10-01T18:00:42.693Z',
 '35ec2b324ede823bbb5281e4b5ccf0d9':'2026-10-01T18:00:54.978Z',
 '7cfc2b324ede8307861981852366b0c7':'2026-10-01T18:01:09.124Z',
 '529c2b324ede82e8a86f81f8cfc0477e':'2026-10-01T18:00:46.167Z',
 '6c6c2b324ede8378862581feae2c1807':'2026-10-01T18:01:00.604Z',
 'c28c2b324ede8217937c8165a19eafa9':'2026-10-01T18:00:42.825Z',
 '92bc2b324ede834ca813812ff4783805':'2026-10-01T18:01:03.712Z',
 '728c2b324ede8254879601340a0b23e6':'2026-10-01T18:01:00.489Z',
 '341c2b324ede8272aef80156a5633b7b':'2026-10-01T18:00:51.832Z',
 'fe9c2b324ede83f6853f01b48b5b6df3':'2026-10-01T18:00:34.085Z',
 '23dc2b324ede8261856701444f7a39c3':'2026-10-01T18:01:00.747Z',
 'eddc2b324ede829f8a75011e8acbf429':'2026-10-01T18:00:52.905Z',
 '391c2b324ede8252b0cc810423cdbfa6':'2026-10-01T18:00:34.040Z',
 '40ec2b324ede825990c2014b4ef594cb':'2026-10-01T18:00:55.533Z',
 '00ac2b324ede831caf1e01e90e81df3b':'2026-10-01T18:00:53.041Z',
 '4d0c2b324ede827b9925018be01e60ca':'2026-10-01T18:00:46.092Z',
 '301c2b324ede828caccb813d3979267a':'2026-10-01T18:00:42.589Z',
 '5dac2b324ede83f39cdb01a904ce3cfd':'2026-10-01T18:00:46.539Z',
}
D={p[0]:dict(id=p[0],url='https://app.notion.com/p/'+p[0],species_tree=p[1],species_body=p[2],title_rank=p[3],body_rank=p[4],ancestor_rank=p[5],CA=p[6],attributes=p[7],source_subset=p[8],source_last_edited=SOURCE_EDITED[p[0]],lot_003_membership='NOT_PROVEN',outside_existing_lots='NOT_PROVEN') for p in PAGES}
# Only attributes explicitly attached to an attack formula may be counted.
# attacks: id, name, formula literal, dice pools, attribute marker, intrinsic fixed, known cost, known rider, type
A=[
 ('cd7c2b324ede822f89e9015f9812673d','Jato de Bolhas','1d6+ int',[(1,6)],'INT',0,None,'desorienta (sem número)','não tipado'),
 ('cd7c2b324ede822f89e9015f9812673d','Cauda de Coral','1d6+Des',[(1,6)],'DES',0,None,'cauda com espinhos','não tipado'),
 ('a01c2b324ede8347b691819d3509d7d7','Mordida Trituradora','1d6+1d4+For',[(1,6),(1,4)],'FOR',0,None,'narrativa de perfurar armadura (sem bypass numérico)','não tipado'),
 ('f0dc2b324ede820ab9470168d4a53315','Rabada','1d6+força',[(1,6)],'FOR',0,None,'Lâminas Ósseas +1d4 gelo é um efeito separado; não combinar sem gatilho','não tipado'),
 ('35ec2b324ede823bbb5281e4b5ccf0d9','Patada','1d6+força',[(1,6)],'FOR',0,None,'Sucção 2d6 é de Alma, fora de dano Vida','não tipado'),
 ('529c2b324ede82e8a86f81f8cfc0477e','Punhos de fogo','1d4',[(1,4)],None,0,None,'fogo sem atributo expresso nesta linha','fogo narrativo (sem tipo separado garantido)'),
 ('529c2b324ede82e8a86f81f8cfc0477e','Soco','1d6 + força',[(1,6)],'FOR',0,None,None,'não tipado'),
 ('c28c2b324ede8217937c8165a19eafa9','Rabada','1d4 + destreza',[(1,4)],'DES',0,None,None,'não tipado'),
 ('c28c2b324ede8217937c8165a19eafa9','Corte','1d6 + força',[(1,6)],'FOR',0,None,None,'não tipado'),
 ('92bc2b324ede834ca813812ff4783805','Rabada','1d6+1d4+ força',[(1,6),(1,4)],'FOR',0,None,'nome do corpo Escorpião Ártico difere da árvore Diamante','não tipado'),
 ('92bc2b324ede834ca813812ff4783805','Corte','1d6+ destreza',[(1,6)],'DES',0,None,'nome do corpo Escorpião Ártico difere da árvore Diamante','não tipado'),
 ('fe9c2b324ede83f6853f01b48b5b6df3','Investida','1d6 + força',[(1,6)],'FOR',0,None,'empurrão distância/save pendentes','impacto'),
 ('eddc2b324ede829f8a75011e8acbf429','Patada','1d4 + destreza',[(1,4)],'DES',0,None,None,'cortante'),
 ('391c2b324ede8252b0cc810423cdbfa6','Investida','1d6 + força',[(1,6)],'FOR',0,None,'empurrão não parametrizado','impacto'),
 ('40ec2b324ede825990c2014b4ef594cb','Espinhos perfurantes','1d4 + destreza',[(1,4)],'DES',0,None,'veneno não quantificado, habilidade relacionada com recarga 3 rodadas','perfurante'),
 ('00ac2b324ede831caf1e01e90e81df3b','Raio de Putrificação','2d6+Int',[(2,6)],'INT',0,None,'+1d4 Dark condicionado; não somado ao dano bruto sem comprovar gatilho','não tipado'),
 ('4d0c2b324ede827b9925018be01e60ca','Bola de fogo','1d4+5',[(1,4)],None,5,None,None,'fogo narrativo'),
 ('301c2b324ede828caccb813d3979267a','Patada','2d6 + força',[(2,6)],'FOR',0,None,None,'impacto'),
 ('301c2b324ede828caccb813d3979267a','Mordida','1d6 + força',[(1,6)],'FOR',0,None,None,'perfurante'),
 ('301c2b324ede828caccb813d3979267a','Poder elemental','1d10+ inteligência',[(1,10)],'INT',0,'10 PA',None,'elemental não especificado'),
 ('5dac2b324ede83f39cdb01a904ce3cfd','Estilhaços de Gelo','2d6 + Dês',[(2,6)],'DES',0,None,None,'gelo declarado, tipo exato pendente'),
 ('5dac2b324ede83f39cdb01a904ce3cfd','Mordida','3d6 + Força',[(3,6)],'FOR',0,None,None,'não tipado'),
]
# NOTE: 12 physical B5-title formula actions includes Cabra B5-title/B4-body;
# 11 accepted for the 7-page B5 body+title comparison.
ACTIONS=[]
def dist(pools,addon):
 d={0:1}
 for n,s in pools:
  for _ in range(n):
   dd=collections.Counter()
   for x,w in d.items():
    for f in range(1,s+1):dd[x+f]+=w
   d=dict(dd)
 return {x+addon:w for x,w in sorted(d.items())}
def moments(d):
 n=sum(d.values()); mu=sum(x*w for x,w in d.items())/n
 var=sum((x-mu)**2*w for x,w in d.items())/n
 return mu,var,min(d),max(d),n
for pid,name,lit,pools,attr,fixed,cost,rider,typ in A:
 page=D[pid]; val=page['attributes'].get(attr,0) if attr else 0
 assert not attr or attr in page['attributes']
 db=dist(pools,0); dg=dist(pools,val+fixed)
 base,_,_,_,_=moments(db); gross,var,mi,ma,_=moments(dg)
 assert abs(gross-base-val-fixed)<1e-9
 rd={}
 for rdval in [0,5,15,25,35,45,75]:
  trunc=collections.Counter()
  for outcome,w in dg.items(): trunc[max(0,outcome-rdval)]+=w
  mu,_,_,_,n=moments(trunc)
  rd[str(rdval)]={'expected_per_hit':mu,'penetration_given_hit':sum(w for z,w in dg.items() if z>rdval)/n,'max_after_RD':max(trunc),'min_after_RD':min(trunc)}
 aid=f'{pid}:{name.lower().replace(" ","_")}'
 ACTIONS.append(dict(action_id=aid,page_id=pid,species=page['species_tree'],source='https://app.notion.com/p/'+pid,body_rank=page['body_rank'],title_rank=page['title_rank'],ancestor_rank=page['ancestor_rank'],attack=name,formula_original=lit,dice=[{'n':n,'sides':s} for n,s in pools],attribute=attr,attribute_printed_value=val if attr else None,fixed_intrinsic=fixed,dme_intrinsic=base+fixed,gross_conditional_on_hit=gross,attribute_share_of_gross=val/gross if attr and gross else None,variance_conditional=var,min=mi,max=ma,cost_documented=cost or 'NOT_DOCUMENTED_FOR_NAMED_ABILITY',rider_documented=rider,type_documented=typ,can_calculate_hit=False,can_calculate_actual_PA_efficiency=bool(cost) and False,source_subset=page['source_subset'],lot_003_membership='NOT_PROVEN',rd_scenarios=rd,distribution_gross=dg))
# Categories must not use ancestor rank silently: title+body are the explicitly defined candidate filter.
b5=[a for a in ACTIONS if D[a['page_id']]['source_subset']=='B5' and a['title_rank']=='Bronze 5' and a['body_rank']=='Bronze 5']
assert len(b5)==11 and len({a['page_id'] for a in b5})==7
# Post-hoc reconstruction candidate selection: named close-contact hit with explicit attr, excluding ranged Jato and unbonused Punhos.
melee_names={'Cauda de Coral','Mordida Trituradora','Rabada','Patada','Soco','Corte'}
cohort=[a for a in b5 if a['attribute'] and a['attack'] in melee_names]
assert len(cohort)==9 and len({a['page_id'] for a in cohort})==7
# Discrete stats: median and interpolated Type-7 quartiles (n=9 Q1 is third value).
def summaries(values):
 v=sorted(values); med=statistics.median(v)
 def percentile_type7(p):
  rank=(len(v)-1)*p;lo=math.floor(rank);hi=math.ceil(rank)
  return v[lo]+(v[hi]-v[lo])*(rank-lo)
 q1=percentile_type7(.25);q3=percentile_type7(.75)
 return dict(count=len(v),sorted=v,mean=statistics.mean(v),median=med,min=v[0],max=v[-1],q1=q1,q3=q3,IQR=q3-q1,MAD=statistics.median([abs(z-med) for z in v]))
S=summaries([a['gross_conditional_on_hit'] for a in cohort]);hist={'count':9,'median':26.5,'min':11.5,'max':28.5,'mean_reported_2dp':24.17,'IQR':5.5,'MAD':2.0}
assert S['count']==hist['count'] and S['median']==hist['median'] and S['min']==hist['min'] and S['max']==hist['max'] and round(S['mean'],2)==hist['mean_reported_2dp'] and S['IQR']==hist['IQR'] and S['MAD']==hist['MAD']
# Uniqueness only within the ten observed explicit attribute expressions from these seven pages.
attr10=[a for a in b5 if a['attribute']]
candidates=[]
for combo in itertools.combinations(attr10,9):
 s=summaries([a['gross_conditional_on_hit'] for a in combo]);
 if len({a['page_id'] for a in combo})==7 and s['median']==hist['median'] and s['min']==hist['min'] and s['max']==hist['max'] and round(s['mean'],2)==24.17 and s['IQR']==5.5 and s['MAD']==2:
  candidates.append([a['action_id'] for a in combo])
assert len(attr10)==10 and len(candidates)==1 and set(candidates[0])=={a['action_id'] for a in cohort}
# Pair type/order; these five match historical reported number and inversion count, NOT historical physical membership.
PAIR_IDS=[
 ('Azuragon','cd7c2b324ede822f89e9015f9812673d','Jato de Bolhas','Cauda de Coral'),
 ('Raposa Alfa','529c2b324ede82e8a86f81f8cfc0477e','Punhos de fogo','Soco'),
 ('Escorpião Ártico','c28c2b324ede8217937c8165a19eafa9','Rabada','Corte'),
 ('Escorpião de Diamante (identidade conflituosa)','92bc2b324ede834ca813812ff4783805','Rabada','Corte'),
 ('Behemoth Glacial Ouro 1','5dac2b324ede83f39cdb01a904ce3cfd','Estilhaços de Gelo','Mordida'),
]
PAIRS=[]
for group,pid,first,second in PAIR_IDS:
 aa=next(a for a in ACTIONS if a['page_id']==pid and a['attack']==first)
 bb=next(a for a in ACTIONS if a['page_id']==pid and a['attack']==second)
 db=aa['dme_intrinsic']-bb['dme_intrinsic'];dg=aa['gross_conditional_on_hit']-bb['gross_conditional_on_hit']
 result='INVERSION' if db*dg<0 else 'BASE_TIE' if db==0 else 'GROSS_TIE' if dg==0 else 'PRESERVED'
 PAIRS.append(dict(group=group,source_page_id=pid,source=D[pid]['url'],attack_1=first,attack_2=second,delta_data_intrinsic=db,delta_gross_conditional=dg,result=result,unknown='This is a candidate five-pair reconstruction only; historical pair IDs remain unavailable'))
assert len(PAIRS)==5 and sum(x['result']=='INVERSION' for x in PAIRS)==3
# rank coherence diagnostic; body rank does not supersede conflicting ancestor here.
for p in D.values():
 p['title_body_grade']='MATCH' if p['body_rank']==p['title_rank'].replace(' (titã)','') else ('INCOMPLETE_STAR' if 'sem estrela' in p['body_rank'] and p['body_rank'].split()[0] == p['title_rank'].split()[0] else 'CONFLICT')
 p['tree_disagrees_with_title']=p['ancestor_rank'] != p['title_rank'].replace(' (titã)','')
 p['identity_issue']= ('Escorpião de Diamante' in p['species_tree'] or 'Basilisco' in p['species_tree'] or 'Serpente Flamejante' in p['species_tree'])
 p['reconciled_rank']='PENDING_TREE_CONFLICT' if p['tree_disagrees_with_title'] else ('PENDING_TITLE_BODY' if p['title_body_grade']!='MATCH' else 'DOCUMENTALLY_CONCORDANT_RANK')
 p['any_rank_conflict']=p['tree_disagrees_with_title'] or p['title_body_grade']=='CONFLICT'
 p['source_role']='TITLE_B5_CANDIDATE' if p['source_subset']=='B5' else 'CROSS_RANK_CONTROL_FROM_002_REPORT'
 p['actions_numeric']=[a['action_id'] for a in ACTIONS if a['page_id']==p['id']]
 p['cost_and_conditions']='see per action ledger; undocumented means unknown, not zero'
 p['notion_source_opened_this_turn']=True
 p['native_page_content_hash_verified']=False
# Entity-level balance of means (not independent actions)
byid=collections.defaultdict(list)
for a in cohort:byid[a['page_id']].append(a)
entity_means={D[pid]['species_tree']:statistics.mean([a['gross_conditional_on_hit'] for a in seq]) for pid,seq in byid.items()}
base_sum=sum(a['dme_intrinsic'] for a in cohort); attr_sum=sum(a['attribute_printed_value'] for a in cohort)
assert base_sum+attr_sum==sum(a['gross_conditional_on_hit'] for a in cohort)
# Compare a pair with same gross mean but distinct variance and RD performance.
diam=next(a for a in ACTIONS if a['page_id']=='92bc2b324ede834ca813812ff4783805' and a['attack']=='Corte')
behm=next(a for a in ACTIONS if a['page_id']=='5dac2b324ede83f39cdb01a904ce3cfd' and a['attack']=='Mordida')
assert diam['gross_conditional_on_hit']==behm['gross_conditional_on_hit']==28.5
results={
 'schema':'DMG-R02-RECONSTRUCTION-VERIFIABLE-v01','operation':OP,'date':ASOF,'baseline':RANKRULE,
 'authority_note':'Mestre 2026-10-15 approved research continuation; no productive write, no new canonical damage rules',
 'source_rules':{'RD':RULE_RD,'combat':RULE_COMBAT},
 'historical_lot_002':{'reported_pages':45,'reported_effect_records':58,'reported_components':68,'reported_groups':38,'zip_catalog_path':'/Comestre/DMG_F0_F6_LOTE_CIENTIFICO_002.zip','catalog_size_bytes':1027152,'reported_sha256_not_verified':'4b76b69612105956805c7f6ca067f0022fb1ddc335eaed61dcbc8cb72c57c307','materialization':'NOT_AUTHORIZED; NOT RETRIED IN R02'},
 'historical_lot_003':{'reported_additional_pages':71,'reported_numerical_records':56,'reported_math_parts':108,'reported_rank_conflict_pages':23,'reported_bronze5_actions':9,'reported_bronze5_pages':7,'reported_pairs':5,'reported_inversions':3,'confirmed_003_membership_pages':0,'reason':'missing original 003 physical ID ledger/manifest; matching summary stats cannot prove same observations'},
 'r02_page_discovery':{'physical_b5_title_pages_opened':13,'cross_rank_pages_reopened':7,'distinct_physical_pages_reopened':20,'b5_title_body_rank_match':sum(p['title_body_grade']=='MATCH' for p in D.values() if p['source_subset']=='B5'),'b5_title_body_star_incomplete':sum(p['title_body_grade']=='INCOMPLETE_STAR' for p in D.values() if p['source_subset']=='B5'),'b5_title_body_conflict':sum(p['title_body_grade']=='CONFLICT' for p in D.values() if p['source_subset']=='B5'),'b5_tree_disagrees_with_title':sum(p['tree_disagrees_with_title'] for p in D.values() if p['source_subset']=='B5'),'b5_title_body_numeric_action_pages':7,'b5_title_body_numeric_actions':len(b5),'b5_with_explicit_attribute_actions':len(attr10),'cross_rank_numeric_actions':len(ACTIONS)-sum(p['source_subset']=='B5' for p in [D[a['page_id']] for a in ACTIONS]),'reproduced_numerical_expressions':len(ACTIONS),'historical_003_matched_pages':0,'proven_new_outside_lots':0},
 'candidate_nine':{'selection':'source title Bronze 5 and source body Bronze 5; named contact/melee actions with a literal FOR or DES damage term. Exclude ranged Jato de Bolhas and unbonused Punhos de Fogo; preserve all rank-tree/identity conflicts explicitly. This is post-hoc exploratory selection, not preregistered historical method.','source_pages':list(byid),'action_ids':[a['action_id'] for a in cohort],'summary':S,'historical_report_aggregates':hist,'matches_all_six_historical_descriptive_metrics':True,'unique_nine_subset_within_observed_ten_attr_expressions_and_seven_pages':len(candidates)==1,'NOT_same_cohort_proven':True,'data_only_sum':base_sum,'attribute_sum':attr_sum,'gross_conditional_sum':base_sum+attr_sum,'attribute_weighted_share':attr_sum/(base_sum+attr_sum),'data_weighted_share':base_sum/(base_sum+attr_sum),'independent_entity_count':len(byid),'entity_mean_by_page':entity_means,'entity_balanced_mean':statistics.mean(entity_means.values()),'gross_min_max_ratio':S['max']/S['min'],'tier_A_physically_concordant_identity_and_tree_actions':len([a for a in b5 if a['page_id'] in {'cd7c2b324ede822f89e9015f9812673d','c28c2b324ede8217937c8165a19eafa9'}])},
 'candidate_five_pairs':PAIRS,
 'conditional_RD':{'assumption':'subtract one ordinary target RD per delivered attack instance, floor zero; no separate type resistance, hit/miss, reaction, crit or simultaneous rider. This is an explicit conditional cross-rank calculation, not a native fight.', 'rd_values':{'Bronze normal':5,'Prata normal':15,'Ouro normal':25,'Ouro Negro normal':35,'Ouro titã':45,'Lendário titã':75},'candidate_nine_count_with_nonzero_possible_against_RD25':sum(a['rd_scenarios']['25']['penetration_given_hit']>0 for a in cohort),'candidate_nine_count_with_nonzero_possible_against_RD35':sum(a['rd_scenarios']['35']['penetration_given_hit']>0 for a in cohort),'mean_post_RD25_over_nine':statistics.mean(a['rd_scenarios']['25']['expected_per_hit'] for a in cohort),'mean_post_RD15_over_nine':statistics.mean(a['rd_scenarios']['15']['expected_per_hit'] for a in cohort),'same_gross_28_5_different_after_RD25':{'diamond_corte':diam['rd_scenarios']['25'],'behemoth_mordida':behm['rd_scenarios']['25']},'generic_bronze_3d6_vs_RD25':{'expected_per_hit':sum(max(0,x-25)*w for x,w in dist([(3,6)],0).items())/216,'P_positive':0}},
 'missing_layers':{'D_hit_probability':'cannot infer competent Luta/proficiency/attack attribute for all abilities, reaction states, and native engine contract','E_efficiency':'named action type, costs, positioning and activation missing on most abilities; Macaco Poder elemental alone shows 10PA without full opportunity cost','F_native_combat':'none executed by DMG R02; VLAB R31 separate; Mestre ruled Frigido Rabada Luta +6 only for that action, not copied to other beasts'},
 'no_canon_write':True,
}
assert results['r02_page_discovery']['b5_title_body_rank_match']==7
assert results['r02_page_discovery']['b5_tree_disagrees_with_title']==10
assert results['r02_page_discovery']['b5_title_body_conflict']==3
assert results['r02_page_discovery']['b5_title_body_star_incomplete']==3
assert results['r02_page_discovery']['reproduced_numerical_expressions']==22
assert results['conditional_RD']['candidate_nine_count_with_nonzero_possible_against_RD25']==6
assert results['conditional_RD']['candidate_nine_count_with_nonzero_possible_against_RD35']==0
# exact enumeration invariants and monotonicity
for a in ACTIONS:
 d=a['distribution_gross'];mu,var,mi,ma,n=moments(d)
 assert math.isclose(mu,a['gross_conditional_on_hit']);assert mi==a['min'] and ma==a['max'];assert n==math.prod(s**q for q,s in [(x['n'],x['sides']) for x in a['dice']]);
 assert all(a['rd_scenarios'][str(hi)]['expected_per_hit']<=a['rd_scenarios'][str(lo)]['expected_per_hit']+1e-10 for lo,hi in [(0,5),(5,15),(15,25),(25,35),(35,45),(45,75)])
# Export machine readable ledger and brief TSV format
(ROOT/'R02_PAGE_LEDGER.json').write_text(json.dumps(list(D.values()),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'R02_ACTION_LEDGER.json').write_text(json.dumps(ACTIONS,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'R02_COMPARATIVE_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (ROOT/'R02_DAMAGE_A_B_C.csv').open('w',encoding='utf-8',newline='') as f:
 cols=['page_id','species','title_rank','body_rank','ancestor_rank','attack','formula_original','dme_intrinsic','attribute','attribute_printed_value','gross_conditional_on_hit','attribute_share_of_gross','cost_documented','rd5_mean_if_hit','rd15_mean_if_hit','rd25_mean_if_hit','rd25_probability_positive_given_hit','rd35_mean_if_hit','included_in_candidate_nine','lot_003_membership']
 w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
 for a in ACTIONS:
  w.writerow({k:(a[k] if k in a else a['rd_scenarios'][{'rd5_mean_if_hit':'5','rd15_mean_if_hit':'15','rd25_mean_if_hit':'25','rd35_mean_if_hit':'35'}.get(k,'5')]['expected_per_hit'] if k in ['rd5_mean_if_hit','rd15_mean_if_hit','rd25_mean_if_hit','rd35_mean_if_hit'] else a['rd_scenarios']['25']['penetration_given_hit'] if k=='rd25_probability_positive_given_hit' else int(a['action_id'] in {c['action_id'] for c in cohort}) if k=='included_in_candidate_nine' else a.get(k)) for k in cols})

# Existing integration contract, original VLAB R32 operation physically read back.
frig=next(a for a in ACTIONS if a['page_id']=='f0dc2b324ede820ab9470168d4a53315' and a['attack']=='Rabada')
assert frig['gross_conditional_on_hit']==21.5 and frig['rd_scenarios']['5']['expected_per_hit']==16.5
narrow_attack_base=18+6  # FOR18 + Master-authorized Luta6, ONLY Frigido Rabada
CA_SCENARIOS=[
 ('Cabra de Chifres B1 (R32 laboratory target)','391c2b324ede8252b0cc810423cdbfa6',20,5),
 ('Aranha das Cavernas (rank tree conflicts)','35ec2b324ede823bbb5281e4b5ccf0d9',29,5),
 ('Azuragon B5','cd7c2b324ede822f89e9015f9812673d',30,5),
 ('Behemoth Glacial O1','5dac2b324ede83f39cdb01a904ce3cfd',68,25),
]
frag_ca=[]
for label,pid,ca,rdv in CA_SCENARIOS:
 p=sum((d+narrow_attack_base)>ca for d in range(1,7))/6
 after=frig['rd_scenarios'][str(rdv)]['expected_per_hit']
 frag_ca.append({'defender':label,'defender_page':D[pid]['url'],'CA_as_printed':ca,'RD_conditional_normal_table':rdv,'frigid_hit_formula':'1d6+FOR18+Luta6','basic_hit_probability_no_reaction':p,'expected_damage_on_hit_post_RD':after,'expected_damage_per_attempt_no_reactions_or_crits':p*after,'native_executed':'YES_R32_ONLY' if ca==20 else 'NO_SCENARIO_ONLY'})
assert [r['basic_hit_probability_no_reaction'] for r in frag_ca]==[1,1/6,0,0]
assert frag_ca[0]['expected_damage_per_attempt_no_reactions_or_crits']==16.5
assert frag_ca[1]['expected_damage_per_attempt_no_reactions_or_crits']==2.75
bridge={
 'contract_id':'DMG-CORPUS-TO-VLAB-READONLY-01','contract_version':'0.2-proposal-noncanonical','producer':OP,'consumer':'CM-000006 / OP-VLAB-FUSION-SANDBOX-01','mode':'MASTER_SIDE_READ_ONLY','new_engine_created':False,
 'source_facts':{'rules_besta':RULE_RD,'combat':RULE_COMBAT,'frigid':D['f0dc2b324ede820ab9470168d4a53315']['url'],'cabra':D['391c2b324ede8252b0cc810423cdbfa6']['url'],'VLAB_R32_OP':'https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2','VLAB_OP_readback_edited':'2026-10-15T17:22:16.731Z'},
 'master_ruling':'Frigido Ossario Rabada Luta +6 in HIT ONLY; not damage; not for other beasts',
 'already_executed_VLAB_R32':{'status':'DOCUMENTED_IN_NOTION_OP_READBACK; DMG_HAS_NOT_REOPENED_SQLITE_BYTES','scenario':'Frigido B5 Rabada → Cabra B1, adjacency, no voluntary reaction, Ação Padrão, no extra PA','seed':223,'native_d6_hit':3,'attack_total':27,'native_d6_damage':3,'gross_damage':21,'RD':5,'net_damage':16,'cabra_HP_before':38,'cabra_HP_after':22,'native_events_reported':1,'full_combat_count':0,'campaign_effect_count':0,'not_to_repeat':True},
 'documentary_expected_under_uniform_d6':{'gross_conditional':21.5,'post_RD5_conditional':16.5,'observed_native_gross_minus_expected':-0.5,'observed_native_net_minus_expected':-0.5,'n_of_native_observations':1,'interpretation':'ONE valid draw consistent with distribution; NOT evidence of balanced fights or model calibration'},
 'conditional_CA_sensitivity_without_reaction_or_crit':frag_ca,
 'next_discriminant_cases':[{'source':D['c28c2b324ede8217937c8165a19eafa9']['url'],'case':'Escorpião Ártico: Rabada vs Corte, rank/identity concordant, DME inversion','required_before_VLAB':'Luta per skill, action cost, hit/rider, authoritative opponent/reaction snapshot','currently_admissible':'MATH_ONLY'},{'source':D['5dac2b324ede83f39cdb01a904ce3cfd']['url'],'case':'Behemoth O1: Estilhaços vs Mordida, inverted intrinsic vs gross; conditional RD25','required_before_VLAB':'separate action definitions, Luta or attack/save, PA, range and snapshot','currently_admissible':'MATH_ONLY'},{'source':D['cd7c2b324ede822f89e9015f9812673d']['url'],'case':'Azuragon Jato and Cauda, compare INT and DES in hit and damage, uncertainty of control','required_before_VLAB':'native legality, type, costs and hit/stat mapping','currently_admissible':'MATH_ONLY'}],
 'cannot_claim':'No new VLAB action, no full fight, no probability of hit across other skills, no canonical write'
}
(ROOT/'R02_VLAB_HANDOFF_READONLY.json').write_text(json.dumps(bridge,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
results['post_VLAB_R32_alignment']={'VLAB_OP_readback_confirmed':True,'R32_integral_action_documented':1,'R32_full_combat_documented':0,'R32_principal_gross':21,'R32_principal_net':16,'our_derived_mean_gross':21.5,'our_derived_mean_netRD5':16.5,'independent_binary_check_of_R32_SQLite':False,'not_claimed_as_DMG_run':True}
results['frigid_narrow_CA_sensitivity']=frag_ca
(ROOT/'R02_COMPARATIVE_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Manifest includes hashes of prior R01, to show not mutated (these local hashes are not hashes of Notion)
files=['PSV_SUCESSAO_DMG_R01_20261015.md','bronze5_four_pairs_replay.json','replay_bronze5.py','replay_dmg_r02.py','R02_PAGE_LEDGER.json','R02_ACTION_LEDGER.json','R02_COMPARATIVE_RESULTS.json','R02_DAMAGE_A_B_C.csv','R02_VLAB_HANDOFF_READONLY.json','PSV_DMG_R02_20261015.md','R02_CHECKPOINT.json']
manifest={'date':ASOF,'operation':OP,'r02_replay_tests':'PASS','notion_write_count':0,'r01_preserved_sha256':{},'members':{}}
for f in files:
 raw=(ROOT/f).read_bytes();entry={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};manifest['members'][f]=entry
 if 'R01' in f or f in ['replay_bronze5.py','bronze5_four_pairs_replay.json']:manifest['r01_preserved_sha256'][f]=entry['sha256']
(ROOT/'R02_MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PASS: '+str(len(PAGES))+' primary physical pages, '+str(len(ACTIONS))+' numeric damage formulas, 7 B5-body matching source pages and 11 actions')
print('REPORT MATCH: nine actions / seven pages; summary',S)
print('ATTR_SUM',base_sum,attr_sum,'share',attr_sum/(base_sum+attr_sum),'entity balanced',statistics.mean(entity_means.values()))
print('5 PAIRS',[(p['group'],p['result']) for p in PAIRS])
print('RD25 penetration 9',results['conditional_RD']['candidate_nine_count_with_nonzero_possible_against_RD25'])
print('RD25 mean n9',results['conditional_RD']['mean_post_RD25_over_nine'])
print('SAME GROSS 28.5',results['conditional_RD']['same_gross_28_5_different_after_RD25'])
print('FILES',[(x,v['bytes'],v['sha256']) for x,v in manifest['members'].items()]);print('R02_TESTS_PASS')
