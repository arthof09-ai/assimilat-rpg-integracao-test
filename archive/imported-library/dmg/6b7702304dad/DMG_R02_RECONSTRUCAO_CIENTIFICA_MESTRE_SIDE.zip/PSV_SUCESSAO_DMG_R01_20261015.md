# PSV — OP-DMG-CORPUS-EMP-01 | Sucessão científico-forense R01

**AS-OF:** 2026-10-15 (consulta Mestre-side desta sessão). **BASELINE:** DMG-RANK-01 v1.1 OFICIAL, INALTERADA. **IDENTIDADE:** CM-000001 como papel lógico do sucessor designado; sem credencial de INSTANCE-ID, writer, lease, epoch, fencing ou ACK material herdado. **NAC-PASS-02:** sem encerramento produtivo; verificação documental local parcial.

## Fonte de verdade

Notion OP `3f3c2b324ede813e9fa0c87ebdea0b29`, DMG-RANK `3f2c2b324ede815498cddb7844245f7e`, DMG-TAX `3f3c2b324ede81609a28e18c11d3cae4`, DMG-METHOD `3f3c2b324ede81ab8d8ec1c7cce760b3`, DMG-QA `3f3c2b324ede815cb014dc6294f40170`, LONGRUN `3f3c2b324ede8157ae2bd99794e9cd65`, EXT `3f3c2b324ede81f4a9a7ce7d292cb6e0`, Comestre root `3ecc2b324ede8197911cdd9fe0a4998c`. Recuperação e sucessão lidas no Kit e MODELO, sem atribuir lease de instância histórica.

## Unidade → evidência histórica → artefato atual → integridade → status → próxima ação

| Unidade | Evidência histórica | Artefato atual | Integridade | Status | Próxima ação |
|---|---|---|---|---|---|
| OP / F0-F18 | registro canônico | página Notion fisicamente reaberta | conteúdo legível; datas antigas no dossiê | RECUPERADO documental | conservar OP |
| Baseline DMG v1.1 | oficial | página DMG-RANK fisicamente reaberta | legível, sem alteração | RECUPERADO documental | não modificar |
| Metodologia / taxonomia / QA / E01-E24 | páginas canônicas | seis páginas reabertas | legíveis | RECUPERADO documental | seguir gates |
| Lote 002 ZIP | 45 páginas; SHA informado `4b76b69612105956805c7f6ca067f0022fb1ddc335eaed61dcbc8cb72c57c307` | `/Comestre/DMG_F0_F6_LOTE_CIENTIFICO_002.zip` 1.027.152 bytes de metadados | bytes indisponíveis; hash/CRC não conferidos | LOCALIZADO-NÃO-RECUPERADO-BINÁRIO | recuperar bytes em superfície autorizada |
| Lote 002 relatório | histórico 58 registros, 38 grupos, 68 parcelas e 64 ocorrências | `/Comestre/RELATORIO_CIENTIFICO_LOTE_002.md` 15.834 bytes | 107 linhas de texto lidas; sem conferência hash local | RECUPERADO-TEXTO | usar como exclusão provisória, NÃO fechar set de 45 IDs |
| Lote 002 matriz de exclusão | 45 páginas / identidades físicas | possível no ZIP original | não disponível por bytes | PENDENTE | obter lista de SOURCE-PAGE-ID e EFFECT-ID |
| Lote 003 pacote final | 71 páginas novas relatadas | nenhum ZIP ou relatório nominal `LOTE_003` encontrado no subconjunto pesquisado da Biblioteca | não aplicável | RELATADO / LOCALIZAÇÃO PENDENTE | procurar outras pastas e persistências históricas sem inventar arquivo |
| Lote 003 71 IDs | 71 páginas relatadas | nenhum ledger completo recuperado | sem lista de IDs de 71 | RELATADO | reconstituir manifesto somente do necessário |
| Lote 003 registros | 56 de 35 páginas relatados | sem dataset integral | não reproduzíveis integralmente | RELATADO | extrair progressivamente IDs faltantes |
| Lote 003 parcelas | 108 relatadas | sem dataset integral | não recontadas | RELATADO | não confundir partes com efeitos |
| Conflitos Lote 003 | 23 relatados | conflito físico confirmado na página Escorpião de Diamante / corpo Ártico e outras divergências na busca; sem lista completa | conflitos parciais de identidade e/ou rank | PARCIAL, NÃO CONCILIADO 23/23 | mapear conflito por SOURCE-PAGE-ID |
| Bronze 5 9 ações/7 fontes | estatísticas relatadas | 4 páginas físicas reabertas, 8 expressões recomputadas em `bronze5_four_pairs_replay.json` | replay exato das oito expressões; pertencimento ao nove histórico NÃO certificado | RECONSTRUÍDO-PARCIAL | recuperar seleção original e calcular estatísticas da mesma coorte |
| Cinco pares históricos | 5 pares, 3 inversões relatadas | quatro pares documentais de 4 páginas reproduzidos; dois inversores | 4/4 pares deste recorte refeitos, mas a identidade dos cinco originais é desconhecida | REPLAY INDEPENDENTE / NÃO CONCILIADO | reconciliar com pares originais e Lote 002 antes de creditar novas unidades |
| Ponte DMG→VLAB | 3d6 fictício vs 4 ataques B1, quatro RDs | `OP-DMG-VLAB-INTEGRATION-CONTRACT-v02.json` localizado na Biblioteca; recortes B1 documentados no relatório Lote 002 | contrato encontrado por texto, não execução de combate | RECUPERADO DOCUMENTAL PARCIAL | obter tabela original e reexecutar apenas as lacunas |
| Writer / lease / instância | sucessão não herda writer | nenhuma prova de claim desta instância | sem autorização material | HOLD | leitura e cálculos somente |

## Nova análise reproduzida em 4 páginas físicas de Bestas

Dano condicionado ao acerto apenas; não é o DME intrínseco oficial com atributo incluído. A fórmula literal de cada ataque é preservada. Cada par compartilha fonte e não representa duas criaturas.

| Página / par | Ataque 1: dados → com atributo | Ataque 2: dados → com atributo | Ordenação |
|---|---|---|---|
| [Azuragon](https://app.notion.com/p/cd7c2b324ede822f89e9015f9812673d) | Jato `1d6+INT24`: 3,5→27,5 | Cauda `1d6+DES19`: 3,5→22,5 | empate basal desfeito |
| [Raposa Alfa](https://app.notion.com/p/529c2b324ede82e8a86f81f8cfc0477e) | Punhos `1d4`: 2,5→2,5 | Soco `1d6+FOR20`: 3,5→23,5 | ordem preservada |
| [Escorpião Ártico](https://app.notion.com/p/c28c2b324ede8217937c8165a19eafa9) | Rabada `1d4+DES24`: 2,5→26,5 | Corte `1d6+FOR8`: 3,5→11,5 | INVERSÃO |
| [Escorpião de Diamante, corpo diz Ártico](https://app.notion.com/p/92bc2b324ede834ca813812ff4783805) | Rabada `1d6+1d4+FOR22`: 6→28 | Corte `1d6+DES25`: 3,5→28,5 | INVERSÃO; conflito de identidade |

**Total próprio deste replay:** 4 páginas / 4 pares / 8 expressões / 2 inversões estritas / 1 empate basal. Entre as 7 expressões com atributo positivo, 5 possuem participação do atributo de pelo menos 80% do bruto médio condicional (mediana da participação entre as sete = 85,1%). Isto é apenas uma descrição do recorte, sem validade populacional. O recorte NÃO se soma automaticamente às 116 páginas históricas e NÃO certifica os cinco pares originais ou a mediana das nove ações. **Distribuições exatas e testes em** `bronze5_four_pairs_replay.json` e `replay_bronze5.py`.

### Consequência científica concreta

Na ficha do Escorpião Ártico, a ação com menor média de dados (Rabada 2,5) obtém maior média bruta condicionada ao atributo (26,5) que Corte (dados 3,5; condicional 11,5). A inversão ocorre porque `DES24` e `FOR8` são grandezas separadas dos dados. Para o escorpião sob árvore Diamante, a diferença é de apenas 0,5 a favor do Corte após atributo, apesar da Rabada usar maior pool de dados. Sem saber PA, acerto e defesa, isto não demonstra eficiência por turno nem vitória.

## Checkpoint

- **LAST-VERIFIED-UNIT:** quatro fontes Bronze 5 relidas e oito fórmulas refeitas em análise local; método das distribuições finitas validado por teste determinístico; Lote 002 relatório integral lido.
- **FIRST-PENDING:** recuperar bytes do ZIP 002 para hash e matriz de IDs; localizar manifesto/Lote 003 para reconciliar os cinco pares originais.
- **DENOMINATORS:** 002 = 45 páginas, 58 linhas, 38 grupos, 68 partes, 64 ocorrências RELATADOS NO RELATÓRIO; 003 = 71 páginas, 56 linhas numéricas, 108 partes, 23 conflitos RELATADOS, sem ledger; replay próprio = 4 páginas, 8 expressões, 4 pares, 2 inversões.
- **NO-REPEAT:** não revarrer indiscriminadamente as 45 fontes de 002, não reiniciar R01–R31, não somar URLs antes do diff físico.
- **CONFLICTS:** identificação Escorpião de Diamante vs nome interno Ártico; outros conflitos descritos mas não exaustivamente reconciliados.
- **UNKNOWN-EFFECT:** nenhuma escrita foi iniciada nesta sucessão; persistência do ZIP 003 não demonstrada.
- **AUTHORITY/WRITER:** READ-ONLY científica; nenhum TAKEOVER-OK, writer, lease ou epoch certificado.
- **TARGET-REMAINDER:** elegibilidade terminal das 19 fases F0–F18 NÃO DETERMINÁVEL; nem contagem global de páginas/famílias.
- **NEXT-5:** (1) recuperar matriz física 002 e seu hash; (2) localizar pacote/manifesto 003 fora dos nomes pesquisados; (3) reconciliar as 71 IDs e evitar repetição; (4) identificar os 5 pares históricos e sua seleção; (5) ampliar o estudo de atributo com agrupamento por criatura e enviar somente casos reproduzíveis ao contrato VLAB.

**NAC-PASS-02, escopo deste arquivo:** NÃO-PASS para encerramento total de sucessão, canonização, escrita Notion ou certificação de 003; conformidade local de não-escrita e identificação de limites conferida. O relatório é artefato local, NÃO persistência oficial Notion.
