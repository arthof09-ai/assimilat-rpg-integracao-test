#!/usr/bin/env python3
"""Read-only audit of literal DMG-RANK-01 v1.1 bands; not a damage generator."""
from fractions import Fraction
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parent
RANKS={
 'Bronze':[(4,6),(7,9),(10,12),(13,15),(16,18)],
 'Prata':[(14,18),(19,22),(23,26),(27,31),(32,36)],
 'Ouro':[(22,28),(29,35),(36,44),(45,52),(53,62)],
 'Ouro Negro':[(38,48),(49,58),(59,69),(70,82),(83,96)],
 'Lendário':[(58,72),(73,90),(91,112),(113,136),(137,160)]
}
FIPS=['Entrada','Baixa','Média','Alta','Ápice']
checks=0
# Cell continuity and expected rank bounds
for rank,bands in RANKS.items():
    assert len(bands)==5;checks+=1
    for i,(low,high) in enumerate(bands):
        assert low<=high;checks+=1
        if i:assert low==bands[i-1][1]+1;checks+=1
assert sum(len(x) for x in RANKS.values())==25;checks+=1
assert RANKS['Bronze'][0][0]==4 and RANKS['Lendário'][-1][1]==160;checks+=1

inverse=[]
for dme in range(4,161):
    options=[]
    for rank,bands in RANKS.items():
        for i,(a,b) in enumerate(bands):
            if a<=dme<=b: options.append((rank,FIPS[i]))
    assert len(options)>=1;checks+=1
    inverse.append((dme,options))
ambig=[x for x in inverse if len({r for r,f in x[1]})>=2]
triples=[x for x in inverse if len({r for r,f in x[1]})>=3]
assert len(ambig)==79;checks+=1
assert len(triples)==5 and [x[0] for x in triples]==[58,59,60,61,62];checks+=1
assert [f'{r}/{f}' for r,f in next(x[1] for x in inverse if x[0]==60)]==['Ouro/Ápice','Ouro Negro/Média','Lendário/Entrada'];checks+=1

# Compare text example means to literal band bounds. Exact fractions, no rules rewritten.
EXAMPLES=[
 ('Bronze','Média',[(3,6)]),
 ('Prata','Média',[(5,8)]),
 ('Prata','Média',[(4,10)]),
 ('Ouro','Média',[(8,10)]),
 ('Ouro Negro','Média',[(11,10)]),
 ('Lendário','Média',[(16,12)])
]
exam=[]
for rank,fip,parts in EXAMPLES:
    mean=sum((Fraction(n*(s+1),2) for n,s in parts),Fraction())
    a,b=RANKS[rank][FIPS.index(fip)]
    distance= a-mean if mean<a else mean-b if mean>b else Fraction(0)
    exam.append({'rank':rank,'fip':fip,'dados':'+'.join(f'{n}d{s}' for n,s in parts),'dme':str(mean),'intervalo':f'{a}–{b}','dentro_do_intervalo':distance==0,'distancia_ate_intervalo':str(distance)})
    assert distance>=0;checks+=1
assert sum(not e['dentro_do_intervalo'] for e in exam)==2;checks+=1

# Fail closed: metadata gate for ORIGINAL missing-damage case. Test scaffolding only.
def candidate_gate(x):
    if x.get('explicit_damage') is True:return 'USE_SOURCE_EXPLICIT_DAMAGE'
    if x.get('effect_category') not in ('offensive','offensive_with_rider'):return 'HOLD_NON_OFFENSIVE'
    if x.get('status') not in ('canonical','authorized_experiment'):return 'HOLD_SOURCE_STATUS'
    if x.get('rank_origin')!='effect':return 'HOLD_RE_FROM_OTHER_ENTITY'
    if x.get('fip_origin')!='effect':return 'HOLD_FIP_FROM_OTHER_ENTITY'
    if x.get('RE') not in RANKS:return 'HOLD_RE_MISSING'
    if x.get('FIP') not in FIPS:return 'HOLD_FIP_MISSING'
    for field in ['action','cost','delivery','targets','damage_type','conditions']:
        if x.get(field) is None:return 'HOLD_MISSING_'+field.upper()
    return 'TEST_ELIGIBLE_METADATA_ONLY_NOT_NORMATIVE_CERTIFIED'

base=dict(explicit_damage=False,effect_category='offensive',status='authorized_experiment',rank_origin='effect',fip_origin='effect',RE='Prata',FIP='Média',action='Ação Padrão',cost='12 PA',delivery='ataque com salvo definido',targets='1 alvo',damage_type='Fogo',conditions='sem rider')
tests=[
 ('explicit_precedence',{'explicit_damage':True},'USE_SOURCE_EXPLICIT_DAMAGE'),
 ('nonoffensive',{'effect_category':'defensive'},'HOLD_NON_OFFENSIVE'),
 ('draft_source',{'status':'proposal_unratified'},'HOLD_SOURCE_STATUS'),
 ('portador_rank',{'rank_origin':'actor'},'HOLD_RE_FROM_OTHER_ENTITY'),
 ('RCMIN_fip',{'fip_origin':'material'},'HOLD_FIP_FROM_OTHER_ENTITY'),
 ('no_re',{'RE':None},'HOLD_RE_MISSING'),
 ('no_fip',{'FIP':None},'HOLD_FIP_MISSING'),
 ('no_action',{'action':None},'HOLD_MISSING_ACTION'),
 ('no_cost',{'cost':None},'HOLD_MISSING_COST'),
 ('no_delivery',{'delivery':None},'HOLD_MISSING_DELIVERY'),
 ('no_targets',{'targets':None},'HOLD_MISSING_TARGETS'),
 ('no_damage_type',{'damage_type':None},'HOLD_MISSING_DAMAGE_TYPE'),
 ('no_conditions',{'conditions':None},'HOLD_MISSING_CONDITIONS'),
 ('positive_synthetic',{},'TEST_ELIGIBLE_METADATA_ONLY_NOT_NORMATIVE_CERTIFIED')
]
for label,delta,expect in tests:
   x=base|delta
   assert candidate_gate(x)==expect,(label,candidate_gate(x),expect);checks+=1
assert checks== (5+25+20+2+157+3+6+1+14) # sum checks enumeration

p=ROOT/'C37_DME_INVERSAO_AMBIGUIDADE_157_LINHAS.csv'
with p.open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['DME_inteira','ranks_possiveis','FIP_por_rank','contagem_ranks','ambigua_inferencia_por_DME','TRAVA'])
 for dme,options in inverse:
    ranks=list(dict.fromkeys(r for r,fip in options))
    w.writerow([dme,';'.join(ranks),';'.join(f'{r}:{fi}' for r,fi in options),len(ranks),len(ranks)>1,'DME NAO INVERTE RE; EXIGIR RE/FIP COMPETENTES'])
p2=ROOT/'C37_EXEMPLOS_NORMATIVOS_6.csv'
with p2.open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(exam[0]));w.writeheader();w.writerows(exam)
p3=ROOT/'C37_F6_FAIL_CLOSED_14_TESTS.csv'
with p3.open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['case','expected','result','pass']);
 for label,delta,expect in tests:
    got=candidate_gate(base|delta);w.writerow([label,expect,got,got==expect])
summary={'source':'https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e',
 'reference':'DMG-RANK-01 v1.1 literal table, sections 5,7,9,14',
 'fip_cells':25,'dme_integer_values_checked':157,'ambiguous_by_dme_alone':79,'triple_rank_values':[58,59,60,61,62],
 'reference_examples_checked':6,'approx_examples_below_table_minimum':2,'prata_media_examples':exam[1:3],
 'metadata_tests':14,'local_assertions':checks,'F6_positive_real_source':0,
 'status':'METADATA LINT, READ-ONLY, NO DAMAGE ENGINE, NO RANK REVERSE INFERENCE'}
(ROOT/'C37_RESULTADOS_LINT.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('C37 audited',len(RANKS)*5,'band cells; ambiguities',len(ambig),'triple',len(triples),'checks',checks)
