# PSV DMG C37 — auditoria das bandas v1.1 e prevenção de falsa inferência de RE/FIP

**Operação:** OP-DMG-CORPUS-EMP-01 (existente). **Ambiente:** MESTRE-SIDE TEST / auditoria read-only. **Fonte canônica reaberta:** [DMG-RANK-01 v1.1](https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e), §§5, 7, 9, 14. **Norma, Party, O Primeiro, fichas, VLAB, OP/Diário Notion:** sem alteração. **F0:** 4/8 documental HOLD.

## 1. Contrato auditado

A seção 5 da v1.1 contém **25 bandas de DME**: cinco Ranks de Efeito (Bronze, Prata, Ouro, Ouro Negro, Lendário) × cinco posições FIP (Entrada, Baixa, Média, Alta, Ápice). Os valores descrevem efeito ofensivo padrão de alvo único, Ação Padrão, sem hard-control/bypass relevante e **não incluem bônus externos**. A seção 7 determina que estrela é só *aproximação inicial* e não substitui classificação competente; magia sem FIP não recebe Média automaticamente. A seção 9 define ajustes de criação de efeito que **não são multiplicadores aplicados em mesa**.

## 2. Resultado quantitativo — inversão DME → rank é não identificável

O script portátil independente transcreveu e verificou as 25 bandas textuais, inclusive continuidade interna por rank e os valores extremos 4..160. Percorreu **157 valores inteiros de DME (4 a 160)**: **79 valores** (50,3%) são compatíveis com pelo menos **dois ranks**, e os valores **58, 59, 60, 61 e 62** são compatíveis simultaneamente com **três ranks**.

Exemplo **DME=60** (não uma recomendação de pool): Ouro/Ápice, Ouro Negro/Média e Lendário/Entrada são todos intervalos possíveis pelo número isolado. Portanto: **não reclassificar efeito por DME** e não deduzir FIP do valor ou do rank do usuário. O relatório contém CSV completo com as 157 linhas e possíveis células. O percentual refere-se apenas aos **inteiros dentro das bandas**, não a frequências de personagens, efeitos ou ataques.

## 3. Nota editorial de 2 exemplos aproximados (não é mudança normativa)

No §14, a fonte cita “Prata Média: `5d8≈22,5` ou `4d10≈22`”; a banda literal de **Prata/Média é 23–26** no §5. Ambas as expressões exemplificativas ficam abaixo do limite por 0,5 e 1 DME respectivamente. A fonte avisa que são exemplos **aproximados** e não formatos obrigatórios, portanto o estado correto é `EXEMPLO_APROXIMADO_FORA_DA_BANDA`, não `DMG-RANK-01 ERRO CERTIFICADO`. Os outros quatro exemplos explicitados (Bronze, Ouro, Ouro Negro e Lendário Média) estão dentro de suas respectivas bandas. **Nenhum número oficial foi corrigido ou sobrescrito**; compete ao Mestre avaliar ajuste meramente textual futuro, se desejar.

## 4. F6 — linter de metadados TEST, não motor de dano

Um conjunto de **14 testes sintéticos** valida apenas o pré-requisito para propor preenchimento em réplica. Ele bloqueia substituição de fonte explícita, tipo não ofensivo, fonte ainda não autorizada, rank do portador no lugar de RE, FIP de material/RC-MIN no lugar do efeito, RE/FIP ausentes e ausência de ação, custo, entrega, alvo, tipo de dano ou condições. O único canário positivo sinaliza `TEST_ELIGIBLE_METADATA_ONLY_NOT_NORMATIVE_CERTIFIED`, sem gerar expressão numérica nem receber validação normativa. Este canário **não é a fonte real positiva exigida por F6**, que permanece pendente.

A negativa preserva o contrato da v1.1: dano explícito válido na fonte prevalece; dados, Besta ou item de outro titular não definem automaticamente o rank do efeito; fatores de custo/área/rider exigem avaliação antes da criação de dados.

## 5. Verificação, limitações e ponto de retomada

- **25 células**, **157 linhas do mapa inverso**, **6 exemplos literais** e **14 testes de falha/avanço de metadados**; **233 asserções locais PASS**. O script lê apenas constantes transcritas da tabela oficial; **não calcula dano de personagem, não cria motor, não faz migração**.
- O F0-A5 ainda tem 7 referências assinadas localizáveis, mas **0/7 bytes autenticados**. A7 holdout e A8 codificador independente, Assignment/writer/epoch/lease: HOLD. F6 fonte real com RE+FIP+ação+custo+entrega sem dano explícito: **não encontrada**; C37 não promove C37 a F6 PASS.
- **NAC-PASS proporcional:** integridade/sintaxe/asserções do linter local PASS; interpretação oficial e gates científicos globais HOLD.
- **LAST-VERIFIED:** C37 mapa de bandas e testes fail-closed. **FIRST-PENDING:** localizar caso F6 válido ou reconhecer bloqueio; resolver A5 por transporte autorizado e A7/A8 por revisão humana real/autoridade. **NO-REPEAT:** C22–C36 e seus denominadores, sem novo inventário por motivo cosmético.
