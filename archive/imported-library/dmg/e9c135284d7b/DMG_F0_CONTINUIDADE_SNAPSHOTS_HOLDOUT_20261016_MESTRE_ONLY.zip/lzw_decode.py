import base64, hashlib, pathlib, sys

def decode_lzw16(data):
    if len(data)%2: raise ValueError('unaligned 16-bit codes')
    codes=[(data[i]<<8)|data[i+1] for i in range(0,len(data),2)]
    if not codes: return b''
    table={i:bytes([i]) for i in range(256)}
    next_code=256
    w=table[codes[0]]
    result=bytearray(w)
    for code in codes[1:]:
        if code in table: entry=table[code]
        elif code==next_code: entry=w+w[:1]
        else: raise ValueError(f'bad LZW code {code}, next={next_code}')
        result.extend(entry)
        if next_code<65535:
            table[next_code]=w+entry[:1]
            next_code+=1
        w=entry
    return bytes(result)

if __name__=='__main__':
    name=sys.argv[1]
    b64=sys.stdin.read().strip()
    raw=decode_lzw16(base64.b64decode(b64))
    p=pathlib.Path('/mnt/data/dmg_recovery/f0_material_snapshots_20261016/sources')/(name+'.md')
    p.write_bytes(raw)
    print(name,len(raw),hashlib.sha256(raw).hexdigest(),p)
