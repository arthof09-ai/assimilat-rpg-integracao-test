#!/usr/bin/env python3
"""DMG F0 continuation. All source snapshots are POINTERS until raw markdown bytes are secured.
No Notion/shared writer. Reuses authenticated previous checkpoint and immutable VLAB archive.
"""
from pathlib import Path
import csv, hashlib, io, json, zipfile, collections, statistics, datetime, shutil
ROOT=Path('/mnt/data/dmg_recovery/f0_material_snapshots_20261016')
ROOT.mkdir(parents=True,exist_ok=True)
PARENT=Path('/mnt/data/dmg_recovery/post_realignment_gate_20261016/DMG_POS_REALINHAMENTO_F0_GATE_PROVA_V11_20261016_MESTRE_ONLY.zip')
EVID=ROOT/'evidence_readonly'
EVID.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,obj):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')

def loadz(n):
  with zipfile.ZipFile(PARENT) as z:return json.loads(z.read(n))
old=loadz('results/SOURCE_FINGERPRINTS_NOTION.json')
base=loadz('results/F0_OITO_REQUISITOS_CROSSWALK.json')
ref={(s['name'].lower().replace(' v1.1','')):s for s in old['sources']}
files=[]
linkdata={
 'DMG-RANK-01 v1.1':{'refs':3,'mentions':0,'media':0,'extra':0},
 'Sistema de Combate':{'refs':1,'mentions':2,'media':0,'extra':0},
 'Criação de Ficha':{'refs':1,'mentions':3,'media':0,'extra':0},
 'Criação de Besta':{'refs':1,'mentions':6,'media':0,'extra':0},
 'Sistema de Magia':{'refs':1,'mentions':1,'media':0,'extra':0},
 'Transformação Espiritual':{'refs':1,'mentions':5,'media':0,'extra':0},
 'Atlas PR-ECO':{'refs':0,'mentions':6,'media':0,'extra':0},
}
assert len(old['sources'])>=7
for s in old['sources'][:7]:
  name=s['name']; data=linkdata[name]
  files.append({'name':name,'id':s['id'],'url':'https://app.notion.com/p/'+s['id'].replace('-',''),'last_edited_current':s['last_edited_at'],
    'captured_content_characters':s['content_characters'],'previously_verified_sha256_utf8_markdown':s['content_utf8_sha256'],
    'readback_by_coordinator':'7/7 hashes independently recalculated and matched (user supplied coordination order)',
    'full_content_archived_this_cycle':False,'full_content_independent_readback_this_cycle':False,
    'reference_counts_rendered':data,'source_scope':'Notion fetch <content> plain text, not assets, descendants, live relations, or full database',
    'gate':'PARTIAL_POINTER_ONLY_NOT_IMMUTABLE_SNAPSHOT'})
assert len(files)==7
frozen={'as_of':'2026-10-16','operation':'OP-DMG-CORPUS-EMP-01','baseline':'DMG-RANK-01 v1.1 unchanged',
 'source_count':7,'sources':files,'snapshot_status':'UNSATISFIED_MATERIAL_COMPLETE',
 'reason':'Notion page bodies were fetched and SHA256 independently confirmed by coordinator, but the 7 raw UTF-8 Markdown bodies have not been durably exported in these archival files. Hashes plus URLs are verifiable pointers, not immutable bytes.',
 'archive_criterion':'Must preserve every exact body byte with filename, source ID/version, and read back SHA256; separately enumerate attached media, child pages, mention targets, databases and access. Cannot call F0-A5 PASS now.',
 'unknown_external_scope':'References are counted in rendered Notion Markdown but not recursively fetched or snapshotted.',
 'source_historical_index_url':'https://app.notion.com/p/3f3c2b324ede815faee6f277392b0bb7'}
dump(ROOT/'PRODUTO_A_FINGERPRINTS_SNAPSHOTS_PENDENTES.json',frozen)

versions=[
 {'authority':'Criação de Ficha','id':'3ebc2b324ede81449222f3c06b840613','historical_index_edit':'2026-10-07T23:51:09.023Z','current_edit':'2026-10-09T04:07:06.313Z','markers_observed_current':['Esclarecimento Mestre 09/10/2026 sobre d12 = 7 (60%, arredondamento)', 'Campo obrigatório de progressão — decisão expressa Mestre 09/10/2026'],'independently_proved_text_diff':False,'historical_10_07_raw_snapshot':'MISSING'},
 {'authority':'Transformação Espiritual','id':'3f2c2b324ede81c0ae0ee4e66212edc9','historical_index_edit':'2026-10-07T23:51:17.368Z','current_edit':'2026-10-09T19:35:48.531Z','markers_observed_current':['T6-B: diferença de máximos, decisão Mestre 09/10/2026','d12 fixo oficial=7, 8 erro histórico','ativação apenas Prata1+ e Bronze1–5 proibido','T9-A: duração/descanso e controle por cena'],'independently_proved_text_diff':False,'historical_10_07_raw_snapshot':'MISSING'}]
for x in versions:
 oldtime=datetime.datetime.fromisoformat(x['historical_index_edit'].replace('Z','+00:00'))
 newtime=datetime.datetime.fromisoformat(x['current_edit'].replace('Z','+00:00'))
 x['mtime_delta_seconds']=(newtime-oldtime).total_seconds()
dump(ROOT/'TEMPORAL_VERSION_CONFLICTS.json',{'status':'CURRENT_MARKERS_VERIFIED_OLD_CONTENT_NOT_RECOVERED','records':versions,
 'historical_legacy_ficha_page':'https://app.notion.com/p/52ec2b324ede829fbfd881f261df8d0e',
 'legacy_page_caution':'Legacy page 2026-09-30 is not proof of the exact 2026-10-07 snapshot.',
 'transform_audit':'https://app.notion.com/p/3f2c2b324ede81549ef3e6a25ceb26c5',
 'transform_audit_caution':'Audit documents later amendments but not exact historical version bytes.'})

root_rows=[
 ('BEASTS','Bestas Demoníacas','3ecc2b324ede815c902bdbd889827bc4','2026-10-01T20:41:30.729Z',14,0,'12 elemental branches + pending balance + legacy branch'),
 ('CHARACTERS','Personagens','3ecc2b324ede818cb8e0cb65caf84542','2026-10-01T13:25:59.117Z',233,0,'References may include family/nuclear branches, not 233 distinct combat-ready sheets'),
 ('ITEMS','Itens','3edc2b324ede8184b487c0735f1eabb4','2026-10-04T23:20:51.567Z',17,0,'Armas and Artefatos are children; link overlap expected'),
 ('WEAPONS','Armas','3edc2b324ede8140b8a0e645630b8387','2026-10-02T06:41:50.267Z',19,0,'Contains variants and legacy links; not 19 accepted effects'),
 ('SPELLS','Magias','f96c2b324ede82b8a2f2011efade45bd','2026-09-30T04:45:18.899Z',26,0,'Several child leaves have only image and price'),
 ('ARTIFACTS','Artefatos','3edc2b324ede8164bd84fc7e4673cb76','2026-10-02T06:42:31.830Z',15,0,'15 unclassified at index level; context individually needed'),
 ('MATRICES','Matrizes','3edc2b324ede815091c6df1cf42d2484','2026-10-02T12:55:04.350Z',8,0,'Distinct matrix family, not automatically spell'),
 ('INSCRIPTIONS','Inscrições','7f0c2b324ede83638d1481aedd3eca12','2026-09-30T04:45:22.792Z',0,5,'Mention-page links in the document, no page children captured by this regex'),
]
with (ROOT/'PRODUTO_B_MAPA_RAIZES_F0.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.writer(f);w.writerow(['surface','title','page_id','url','last_edited','rendered_child_page_refs','sample_mention_page_refs','access_status','coverage_status','notes'])
 for a,n,id,ed,count,m,note in root_rows:w.writerow([a,n,id,'https://app.notion.com/p/'+id,ed,count,m,'MESTRE_FETCH_OK','ROOT_INDEX_READ_NOT_RECURSIVE',note])
assert sum(x[4] for x in root_rows)==332
map_summary={'root_indexes':8,'root_indexes_fetched':8,'rendered_child_page_refs_sum':332,'unique_child_pages_across_all_roots':'UNKNOWN_UNDEDUPED',
 'global_D0_pages':'UNKNOWN','party_root_scanned':False,'root_ref_count_is_denominator':False,'known_overlaps':['Itens -> Armas','Itens -> Artefatos'],
 'taxonomy_categories_not_evidenced':['armor offensive','accessories','potions','traps','summons','historical archives','transformation overlays','Party originals','external files/images'],
 'next_preflight':'Enumerate actual child IDs by root, deduplicate by Notion ID, preserve visibility and inaccessible status, then establish D0 versioned scope.'}
dump(ROOT/'PRODUTO_B_MAPA_SUPERFICIES_DELTA.json',map_summary)

holdout=[
 ('SPELL_LIGHTNING','Toque Chocante (O)','909c2b324ede8351ae0901bbca9a2769','MAGIAS-O-TOQUE'),
 ('SPELL_AIR','Golpe de Zephyr (O)','60fc2b324ede8340b447010fe0c08dc2','MAGIAS-O-ZEPHYR'),
 ('SPELL_CONTROL','Perdição (O)','c95c2b324ede8210a2630139e16eb60e','MAGIAS-O-PERDICAO'),
 ('SPELL_MARK','Marca do Caçador (P)','6ddc2b324ede828285eb0125f5b18a19','MAGIAS-P-MARCA'),
 ('WEAPON_ASTRAL','Reflexo Astral','3edc2b324ede813e87cdfad79239a1b6','ARMAS-REFLEXO'),
 ('WEAPON_SEA','Oráculo das Marés','3edc2b324ede81c0a4b8eb8d44610b03','ARMAS-MARES'),
 ('MATRIX_COMBAT','Matriz de Combate (-) (CG)','3edc2b324ede81d68e1bec250fc5291f','MATRIZ-COMBATE'),
 ('MATRIX_SUMMON','Matriz de invocação (-) (CG)','3edc2b324ede813686edff9348a893ad','MATRIZ-INVOCACAO')]
reserve=[{'category':x,'name':n,'source_page_id':i,'source_url':'https://app.notion.com/p/'+i,'provisional_family_group':g,'assignment':'CANDIDATE_HOLDOUT_RESERVED','content_fetched_this_cycle':False,'prior_historical_exposure':'UNKNOWN_CHECK_BEFORE_SEAL','canonical_status':'UNKNOWN','RE_FIP':'NOT_READ','do_not_train_future_candidate_on_this_family_without_review':True} for x,n,i,g in holdout]
dump(ROOT/'PRODUTO_B_HOLDOUT_PREREG_PRESEAL.json',{'as_of':'2026-10-16','selection_method':'Only titles and page IDs exposed in root index fetch before any per-item content opening',
 'scope':'CANDIDATE_HOLDOUT_PRESEAL_NOT_BLIND_VALIDATION','records':reserve,'candidate_count':len(reserve),
 'restrictions':['No source content opened in this cycle','Historical L002/L003 and prior chats may already have exposed some: lineage scan pending','Entities and definition families require dedup/cluster before final seal','No candidate DMG v2 fit before preseal completion','The list is not a full 60/20/20 split; corpus is not enumerated','Second independent reviewer not evidenced'],
 'independent_validation_eligible':False})

negative=[
('SPELL','Rajada Mística (B)','34dc2b324ede8203b0fd01433367893e','IMAGE_AND_PRICE_ONLY','Title suggests Bronze but RE/FIP, action, cost, target/damage type not present in accessible text',178),
('SPELL','Criar Fogueira (B)','b04c2b324ede825bb5f081b7fc9c59d3','IMAGE_AND_PRICE_ONLY','No readable effect mechanics, FIP, cost or use conditions',174),
('SPELL','Faca de Gelo (P)','449c2b324ede83638abf01dead93effa','IMAGE_AND_PRICE_ONLY','No readable mechanical damage/type/RE/FIP/action/cost; image unexamined',180),
('SPELL','Despedaçar (O)','b20c2b324ede82b1a93e81a969c015ec','IMAGE_AND_PRICE_ONLY','No readable mechanical damage/type/RE/FIP/action/cost; title not authority',180),
('SPELL','Destruição Trovejante (O)','c4cc2b324ede83679b7081d728bad271','IMAGE_AND_PRICE_ONLY','No readable RE/FIP/conditions/amount despite offensive title',180),
('SPELL','Repreensão Infernal (O)','987c2b324ede831fa34081d1f5ec10b5','IMAGE_AND_PRICE_ONLY','No mechanical description accessible; price cannot create effect rank',180),
('MATRIX','Matriz: Dança das Estrelas Cadentes','3edc2b324ede81119927f733aafc8af5','NARRATIVE_DAMAGE_RE_MISSING_DELIVERY','Lendário label but FIP internal, action, cost, geometry/targets, split damage+buff unavailable; image embedded with uninspected mechanics',1895),
('WEAPON','Lança Sopro Congelante','3edc2b324ede81ecbae3cf4b0cf274e5','EXPLICIT_DAMAGE_AND_NO_RI','Numerical 4d8 chassis and active 4d6+INT already defined; item unclassified; cannot overwrite with v1.1',1205)
]
with (ROOT/'PRODUTO_C_ADMISSIBILIDADE_NEGATIVA_NOVA.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.writer(f);w.writerow(['family','source_name','id','url','status','missing_or_blocking_conditions','accessible_markdown_chars'])
 for fam,name,id,st,why,cc in negative:w.writerow([fam,name,id,'https://app.notion.com/p/'+id,st,why,cc])
assert len({x[2] for x in negative})==8
assert set(x[2] for x in negative).isdisjoint(set(x[2] for x in holdout))
dump(ROOT/'PRODUTO_C_PROVA_ESCOPO.json',{'new_sources_screened':8,'prior_sources_not_repeated':True,'admitted_original_missing_damage':0,
 'new_negative_eligible':8,'cause_counts':dict(collections.Counter(x[3] for x in negative)),
 'notion_index_spell_source':'https://app.notion.com/p/f96c2b324ede82b8a2f2011efade45bd',
 'notion_matrix_source':'https://app.notion.com/p/3edc2b324ede815091c6df1cf42d2484',
 'source_extraction_warning':'Embedded images may contain missing mechanics, not inspected; negative admission is for accessible text only, not exhaustive absence.',
 'next_eligible_search':'Seek modern Mestre-side authored offensive effect with explicit RE/FIP/action/cost but damage still blank; do not infer RE from title or owner.'})

# R81 physical evidence: original ZIP and 128 exact receipts, no replay by DMG.
rv=ROOT/'vlab_readonly'/'VLAB_R72_R81_BENCHMARK_BESTA_ED_MESTRE_ONLY.zip'
rc=ROOT/'vlab_readonly'/'R77_DMGMETRICS_ATTACK_RECEIPTS_128.csv'
with zipfile.ZipFile(rv) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('FILE_MANIFEST_R81.json'))
 valid=0
 for item in manifest['files']:
  bb=z.read(item['path']);assert len(bb)==item['bytes']
  assert hashlib.sha256(bb).hexdigest()==item['sha256']
  valid+=1
 rows=list(csv.DictReader(io.StringIO(z.read('r72_r81/R77_DMGMETRICS_ATTACK_RECEIPTS_128.csv').decode('utf8'))))
 assert len(rows)==128
 assert hashlib.sha256(z.read('r72_r81/R77_DMGMETRICS_ATTACK_RECEIPTS_128.csv')).hexdigest()==sha(rc)
 metrics=json.loads(z.read('r72_r81/R77_R81_SCIENTIFIC_METRICS.json'))
 assert sum(v['attempts'] for v in metrics['by_actor'].values())==128
 assert sum(v['hits'] for v in metrics['by_actor'].values())==92
 stats={'zip_sha256':sha(rv),'csv_sha256':sha(rc),'zip_crc':'PASS','manifest_entries_checked':valid,'zip_members':len(z.namelist()),
 'attack_receipts':len(rows),'distinct_run_ids':len({r['run_id'] for r in rows}),'unique_seed_values':len({r['seed'] for r in rows}),
 'hit_count':sum(r['hit']=='True' for r in rows),'actor_counts':dict(collections.Counter(r['actor'] for r in rows)),
 'cohort_counts':dict(collections.Counter(r['cohort'] for r in rows)),'all_schema_status':dict(collections.Counter(r['schema_status'] for r in rows)),
 'official_benchmark_cells':0,'terminal_contracts':0,'VLAB_mode':'SOURCE_CONDITIONAL_RD0_ED_NOT_ATTESTED',
 'causal_inference_caution':'14 mirrored runs of 7 seeds; 128 correlated attacks; missing ED RD; no general population inference',
 'DMG_F0_gate_use':'INDEPENDENT_READONLY_CONTEXT_ONLY; does not close F0 root-map, snapshot or blind holdout requirements'}
dump(ROOT/'VLAB_R81_COMPLEMENTO_READONLY.json',stats)

f0_items=[]
for i,item in enumerate(base['items']):
 state=item['state']; after=state
 if item['id']=='F0-A5':after='PARTIAL_FINGERPRINT_VERIFIED_MATERIAL_FULL_SNAPSHOT_HOLD'
 if item['id']=='F0-A6':after='PARTIAL_ROOT_INDEX_8_VERIFIED_GLOBAL_D0_PENDING'
 if item['id']=='F0-A7':after='PARTIAL_HOLDOUT_PRESEAL_8_IDS_NOT_BLIND'
 if item['id']=='F0-A8':after='PENDING_WRITER_SECOND_CODER'
 f0_items.append({**item,'before':state,'after':after,'new_evidence_file':{'F0-A5':'PRODUTO_A_FINGERPRINTS_SNAPSHOTS_PENDENTES.json','F0-A6':'PRODUTO_B_MAPA_RAIZES_F0.csv','F0-A7':'PRODUTO_B_HOLDOUT_PREREG_PRESEAL.json','F0-A8':'MATRIZ_GATE_F0_POST_CONTINUIDADE.json'}.get(item['id']),
   'formal_new_pass':False})
dump(ROOT/'MATRIZ_GATE_F0_POST_CONTINUIDADE.json',{'source':'F0 crosswalk previous checkpoint; operational NOT canonical numbered list','F0_baseline_pass':4,'F0_after_pass':4,'new_formal_pass':0,
 'criterion_count':8,'items':f0_items,'gate_first_next':'F0-A5 actual immutable bytes + gap extent + independent readback, or F0-A6 root coverage map with dedup',
 'NAC_PASS':'SCIENTIFIC_READ_ONLY_PASS; FORMAL_F0_HOLD; PRODUCTION_HOLD'})

# Historical matrices are preserved by reference, with copies in this ZIP if small enough (not relabeled new research).
with zipfile.ZipFile(PARENT) as z:
 for f in ['results/MATRIZ_ATIVACAO_19_FASES.json','results/MATRIZ_E01_E24.json','results/MATRIZ_8_GATES_TRANSVERSAIS.json','results/F0_OITO_REQUISITOS_CROSSWALK.json','results/SOURCE_FINGERPRINTS_NOTION.json']:
  target=EVID/Path(f).name;target.write_bytes(z.read(f))

checkpoint={'AS_OF':'2026-10-16','OPERATION':'CM-000001 / OP-DMG-CORPUS-EMP-01','BASELINE':'DMG-RANK-01 v1.1 UNCHANGED',
 'LAST_VERIFIED_UNIT':'8 Mestre surface roots fetched, 332 overlapping page link refs; 8 new ineligible sources; 8 candidate holdout identities uninspected; original VLAB R81 ZIP/128 receipts; 7 prior authority SHA256 pointers confirmed by Coordenação',
 'FIRST_PENDING':'A5: immutable raw Markdown byte snapshots of all 7 authorities and independent readback; A6 dedup/census; A7 holdout contamination check, A8 writer and blind second coder',
 'DENOMINATORS':{'formal_F0_pass_before':4,'formal_F0_pass_after':4,'formal_F0_total':8,'new_formal_F0_pass':0,'phase_plan_defined':19,
 'EXT_guarantees':24,'cross_gates':8,'indexed_surface_roots_accessible':8,'sum_rendered_page_refs_not_distinct':332,'global_D0':None,'prereserved_holdout_sources':8,
 'distinct_new_negative_screen_sources':8,'source_full_body_snapshots_preserved_this_cycle':0,'source_hashes_reused':7,'original_VLAB_R81_runs':14,'original_VLAB_R81_attack_receipts':128},
 'NO_REPEAT':['R02-R04','Galidemus and Iskiel','24 targeted high-rank Beast pages','148 inherited mathematical tests','R71/R81 full combat reruns'],
 'CONFLICTS':['A1-A8 operational reconstruction not canonical individual enumeration','Criação de Ficha 2026-10-09 later than 2026-10-07 indexed baseline','Transformação Espiritual 2026-10-09 later than 2026-10-07 indexed baseline','Google/Notion content text not present in local snapshot: fingerprints do not substitute immutable source bytes'],
 'UNKNOWN_EFFECT':'No Notion or Party writes attempted','NEXT_5':['Obtain byte-exact 7-body export in authorized storage and verify against 7 SHA256 hashes',
 'Reconcile old revisions through historical snapshots rather than guessing changed text',
 'Dedup actual root child IDs and inaccessible surfaces without scanning already covered effects',
 'Audit holdout prior contamination, group by entity/family, second blind coder if competent',
 'Identify genuine offensive source with RE/FIP/action/cost, no explicit damage, then TEST-only v1.1'],
 'TARGET_REMAINDER':'F0 4/8 formal; no v2; 7 raw snapshots and 8 F0 items unresolved as documented','AUTHORITY_WRITER_STATE':'Mestre LAB TEST authorization valid; Notion OP/Diário writer/lease/epoch/INSTANCE not evidenced; HOLD shared writes',
 'NAC_PASS':'LOCAL_READ_DATA_PASS / F0_FORMAL_HOLD / CANON_HOLD','HANDOFF':'Resume from library checkpoint; no duplicate plans, no new operation, no ACK claims'}
dump(ROOT/'FAST_RESUME_F0_CHECKPOINT.json',checkpoint)

# Self-audit of claims, not fake independent coder.
checks={
 'eight_roots':len(root_rows)==8,
 'root_ref_sum':sum(x[4] for x in root_rows)==332,
 'holdout_count':len(reserve)==8,
 'holdout_unique':len({r['source_page_id'] for r in reserve})==8,
 'holdout_not_opened':all(not r['content_fetched_this_cycle'] for r in reserve),
 'negative_count':len(negative)==8,
 'negative_unique':len({x[2] for x in negative})==8,
 'negative_holdout_disjoint':set(x[2] for x in negative).isdisjoint(set(x[2] for x in holdout)),
 'seven_prior_hash_pointers':len(files)==7 and all(len(x['previously_verified_sha256_utf8_markdown'])==64 for x in files),
 'snapshots_not_false_claimed':all(not x['full_content_archived_this_cycle'] for x in files),
 'F0_unchanged':checkpoint['DENOMINATORS']['formal_F0_pass_before']==checkpoint['DENOMINATORS']['formal_F0_pass_after']==4,
 'R81_manifest':stats['manifest_entries_checked']>=90,
 'R81_attack_rows':len(rows)==128,
 'R81_hits':stats['hit_count']==92,
 'R81_condition_all':list(stats['all_schema_status'])==['SOURCE_CONDITIONAL_RD0_ED_NOT_ATTESTED'],
 'existing_parent_zip_unchanged':sha(PARENT)=='c77448b17f0797eb52b6bafe2f69154fb102d06c2fc42a428b3828c8172fa337',
}
assert all(checks.values()),[k for k,v in checks.items() if not v]
dump(ROOT/'LOCAL_INVARIANTS.json',{'verifications':len(checks),'passed':sum(checks.values()),'checks':checks,'kind':'deterministic self-validation, not independent blind second-coder'})

report=f'''# PSV — DMG / Pós-F0: congelamento e fontes / 16-10-2026

**OPERATION:** CM-000001 / OP-DMG-CORPUS-EMP-01. **Baseline:** DMG-RANK-01 v1.1 inalterada.
**AS-OF:** 2026-10-16. **Direção:** Plano Supremo F0–F18 existente; sem novos planos.

## ANTES -> DEPOIS
- **F0 documental:** 4/8 -> **4/8**. Certificações F0 novas: **0**.
- **F0-A5 fingerprint:** 7/7 previamente auditados -> 7/7 pointers versionados e alcance externo anotado; **0/7 corpos integrais de Markdown imutavelmente preservados nesta entrega**. Não chamar de snapshots completos. Exportação material dos bytes é PRIMEIRO PENDENTE.
- **F0-A6 superfície:** índices de oito famílias Mestre reabertos; soma bruta de 332 links `<page>` com duplicações possíveis; D0 global NÃO DETERMINÁVEL. Não escrevemos em Party.
- **F0-A7 holdout:** 8 identidades/famílias pré-reservadas antes da leitura individual de conteúdo; blindagem genuína HOLD até auditoria de exposição prévia e segregação por família.
- **F0-A8:** writer/lease/INSTANCE/second coder independente ainda NÃO comprovados.
- **Prova v1.1:** oito novas fontes investigadas, 0/8 realmente elegíveis no texto acessível; sete fontes anteriores não reusadas como 'novas'. Seis magias só exibem imagem e preço; matriz ofensiva sem ação/custo/FIP; lança com dano explícito e RI ausente. Sem inventar RE por título.
- **VLAB R81:** ZIP original SHA256 `{stats['zip_sha256']}`; {stats['zip_members']} membros / {stats['manifest_entries_checked']} hashes / CRC PASS; 128 recibos, 14 corridas espelhadas, 7 seeds, 92 hits, RD ED0 condicional e 0 células oficiais. Uso leitura científica complementar, sem reexecutar motor.

## Primeiro gate legitimamente fechável
F0-A5 continua prioritário tecnicamente. Para PASS material: exportar bytes exatos dos sete corpos Notion, versionar identidade e momento, readback SHA256, e qualificar separadamente subpáginas/mídia, com auditoria aplicável. Para PASS formal: writer/segunda auditoria e gate competente da operação. Metadados/hash sem bytes arquivados NÃO satisfazem.

## VERSÕES / NÃO RETROATIVIDADE
- Criação de Ficha: índice original 2026-10-07T23:51:09.023Z; fonte atual 2026-10-09T04:07:06.313Z. Contém decisões Mestre 09/10, inclusive d12 fixo=7; exata diferença textual 07→09 NÃO reconstruível sem snapshot antigo.
- Transformação Espiritual: índice original 2026-10-07T23:51:17.368Z; atual 2026-10-09T19:35:48.531Z. Conteúdo atual inclui T6-B, d12=7 e elegibilidade Prata1+; não projetar isso retroativamente sobre o corpo antigo desconhecido.

## PRESERVAÇÃO
Não foi criado motor, regra, operação, página ou réplicas em Notion. Nenhum original, Party/O Primeiro, fichas ou DMG-RANK modificado. Biblioteca é o destino autorizado; arquivos deste pacote devem ser reabertos e hashes comparados. A referência ao pacote anterior mantém a cadeia: `{PARENT.name}` SHA256 `{sha(PARENT)}`.

## GATES
**Local documentação/metodologia:** PASS proporcional para artefatos novos e checks; **F0 formal:** HOLD; **NAC-PASS terminal/canonização:** HOLD.
A1–A8 são crosswalk operacional, não uma nova lista normativa de oito gates.

## HANDOFF
AS-OF 2026-10-16 | OP OP-DMG-CORPUS-EMP-01 | BASELINE v1.1 congelada | LAST VERIFIED oito raízes + 8 negativos + 8 holdout candidatos + VLAB R81 bytes | FIRST PENDING sete corpos brutos imutáveis e mapa D0 deduplicado | NO REPEAT R02–R04/Galidemus/Iskiel/24 bestas/148 testes/R71-R81 combates | UNKNOWN EFFECT nenhum write shared | WRITER não comprovado. Consultar `FAST_RESUME_F0_CHECKPOINT.json` para NEXT-5 e denominadores.
'''
(ROOT/'PSV_CICLO_F0_CONGELAMENTO_PARCIAL.md').write_text(report,encoding='utf8')

# Build archive with only new evidence and tiny copied former matrices. Do not duplicate two large VLAB archives.
archive=ROOT/'DMG_F0_CONTINUIDADE_SNAPSHOTS_HOLDOUT_20261016_MESTRE_ONLY.zip'
include=[p for p in ROOT.rglob('*') if p.is_file() and p!=archive and not ('vlab_readonly' in p.parts or '__pycache__' in p.parts or 'sources' in p.parts)]
include=[p for p in include if p.suffix in {'.json','.csv','.md','.py'}]
manifest={'operation':'OP-DMG-CORPUS-EMP-01','as_of':'2026-10-16','contents':[],'excluded_large_sources':'VLAB R81 original retained in its own existing Library op; parent DMG checkpoint remains in its own ZIP'}
for p in sorted(include,key=lambda x:str(x)):
 data=p.read_bytes();manifest['contents'].append({'path':str(p.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
dump(ROOT/'MANIFEST_SHA256.json',manifest)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in include+[ROOT/'MANIFEST_SHA256.json']:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for m in manifest['contents']:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'entries':len(manifest['contents'])+1,'checks':len(checks),'F0':'4/8','raw_snapshots':'0/7 HOLD','root_refs_raw_sum':332,'holdout_preseal':8,'new_negative':8,'R81_manifest':valid,'R81_attacks':len(rows)},ensure_ascii=False,indent=2))
