# DMG C48 — A5: divergências de serialização vs alteração canônica real (MESTRE-ONLY)

**Operação:** OP-DMG-CORPUS-EMP-01. **Fontes:** manifesto COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json, pacote F0 arquivado na Biblioteca, leitura ao vivo de sete fontes Notion Mestre. **Sem escrita em Notion.**

## Antes
A5 era descrita como 7 refs para arquivos privados anexados à Inbox, 0/7 bytes históricos baixados depois da publicação; F0 4/8 documental HOLD. C40 já havia flagrado edição da Criação de Ficha.

## Depois
Reabri cada uma das **7 fontes por ID**, extraí separadamente texto que o conector atual retorna entre `<content>` e `</content>` e calculei **SHA256 UTF-8** por implementação independente testada contra vetor SHA256("abc") de referência. Comparei com os sete digests e tamanhos no manifesto histórico, e com `page_last_edited_at` devolvido pelo Notion.

**Evidência: 6/7 timestamps históricos iguais**, mas **0/7 render-body digests atuais iguais ao manifesto**, inclusive os seis de timestamp igual. Não se pode inferir mudança efetiva do conteúdo desses seis, pois texto e extensão da serialização do conector diferem do procedimento/fonte prévia: seriam necessários bytes originais em formato idêntico ou diff de blocos/versionamento. Resultado técnico = **não comparável / divergência de fingerprint**, e NÃO "seis documentos mudaram".

**Edição confirmada temporalmente:** Criação de Ficha tem horário no manifesto 2026-10-09T04:07:06.313Z versus atual 2026-10-22T10:22:24.951Z. O corpo atual foi renderizado com 54.470 caracteres contra 29.886 caracteres capturados no procedimento anterior. A magnitude reforça necessidade de nova edição/versionamento, mas não permite identificar por si só cada conteúdo adicionado sem diff de versões. Houve também registro intermediário anterior na campanha C40 de edição no mesmo dia.

**Notion `fetch` das sete páginas não reportou corte conhecido.** Isso não significa que anexos, conteúdos embutidos e páginas descendentes foram baixados. A escrita material do snapshot antigo não é validada por ler a página-fonte atual.

## Efeito sobre gates
`A5 0/7` de bytes pós-anexo autenticados **HOLD**; metadados e URLs não dão PASS. `F0 4/8 HOLD`. `A7 holdout` e `A8 writer+segunda codificação` permanecem HOLD. Baseline de dano v1.1 não foi editada. `A6 870` IDs delimitados, D0 total ainda não certificado. F6 real sem candidato aprovado.

**FIRST-PENDING:** garantir leitura privada dos sete `.md` anexados ao Notion e comparar `attachment_utf8_bytes_at_upload` / hash esperado dos bytes do arquivo; pesquisar histórico de edição da Criação de Ficha com autoridade, ou versionar uma nova captura corrente **sem sobrescrever** o snapshot de 16/10. **NO-REPEAT:** nunca rever 26 magias C46 ou executar 2048 gates C47 sem alteração de evidência; continuar de C48.

**NAC-PASS:** verificação de digest atual e artefatos locais PASS; prova de congelamento histórico A5 não passou. Nenhuma declaração de sincronização Party ou homologação global.
