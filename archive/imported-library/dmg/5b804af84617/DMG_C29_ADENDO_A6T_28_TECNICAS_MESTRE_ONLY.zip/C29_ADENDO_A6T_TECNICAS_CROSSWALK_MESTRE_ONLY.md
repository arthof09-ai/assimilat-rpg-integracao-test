# C29 — ADENDO A6T: TÉCNICAS, LINHAGENS NOMINAIS E PREÇOS DISCORDANTES — MESTRE-ONLY

**OP:** OP-DMG-CORPUS-EMP-01; **SOURCE:** Notion Mestre diretamente reaberto; **data:** 21/10/2026. Adendo da campanha C29, não sobrepõe C29 e A6-60 existentes.

## Denominador sem dupla contagem

O ramo **Técnicas & Pergaminhos** contém **28 Page-IDs únicos**, todos diretamente reabertos. A árvore **Magias** anterior contém **26 Page-IDs**. **25 nomes são idênticos entre árvores, mas são 50 páginas físicas distintas**. A união física desses dois ramos tem **54 IDs**. O recorte completo C29 A6 anterior Magias (26), Armas (19), Artefatos (15) + Técnicas (28) = **88 páginas físicas distintas**, porque nenhum dos IDs de Técnicas aparece na seleção anterior de 60. **Essa contagem não significa 88 definições independentes de habilidades!**

- Magia sem homônimo no ramo Técnicas: **Despedaçar (O)**.
- Técnicas sem homônimo no ramo Magias: **Orbe Cromática (ON), Passos do Vazio, Tabela do Caos**.
- Entre os **25 pares de mesmo título**, 5 têm preços textuais coincidentes e **20 discordam**. Isso é um CONFLITO DE METADADOS E EVIDÊNCIA DE GENEALOGIA PENDENTE, não prova de duas versões do mesmo efeito. Fonte original da imagem é outra referência física; não foi feita comparação byte/visual. O título é um elo de busca, não igualdade de semântica/cânone. Não somar os dois como amostras independentes em D0/F7.

## Natureza da fonte

**26/28 técnicas**: texto apresenta nome, classificação nominal do produto/técnica e preço; a mecânica que interessa à DMG está em **imagem não extraída**, logo não se pode certificar fórmula, ação, alvo, duração, PA, RE e FIP do efeito. Mesmo que o item/técnica esteja nominalmente Ouro/Prata, **não converter automaticamente o rank da mercadoria em RE individual**.

**Passos do Vazio**: habilidade canônica explicitamente **sem classificação**, sem dano textual. **Tabela do Caos**: habilidade explicitamente **sem classificação** e tabela de consequências; um resultado menciona **5d10 de dano psíquico** (DME 27,5 SOMENTE naquele ramo); outros resultados transformam, movem ou concedem resistência. Sem probabilidade de ramo, custos ou RE, não calcular dano esperado do efeito completo.

## Efeito sobre os gates

**A6 ROOT-MAP** ganha 28 IDs físicos sob mais uma raiz; **F0-A6 GLOBAL permanece PARTIAL**. **A5 originais** 0/7 bytes autenticados; A7/A8 HOLD; F0 formal 4/8 HOLD. Não modificar DMG-RANK v1.1, fichas, Notion, Party, O Primeiro, VLAB nem criar duplicatas.

## FIRST-PENDING

1. Reabrir as duas imagens em pelo menos um par nominal com divergência de preço e conferir se o **efeito mecânico** é igual, histórico, editado ou desconhecido; exigir evidência antes de reconciliar autoridade.
2. Reunir lineage técnico e classificador Atlas para casos com efeito textual completo e RE original, em TEST; não usar preço como classificação.
3. Prosseguir A5 download de originais somente através de fluxo privado autorizado; sem resolver URL temporária como prova de hash.

## Referências de auditoria

`C29_A6T_TECNICAS_28_FONTE_IDS.csv`, `C29_A6T_CRUZAMENTO_25_NOMES.csv`, `C29_A6T_SUMARIO_CROSSWALK.json`. Fonte integral com imagem deve ser buscada pelo Page-ID correspondente. Codificação humana independente não realizada; ledger de nomes/preços veio de leitura direta do texto do Notion e cálculo automático do par, sem equivalência canônica presumida.
