# PSV — DMG C81 | Consolidação C77–C80 e travas reais

**Operação existente:** [OP-DMG-CORPUS-EMP-01](https://app.notion.com/p/3f3c2b324ede813e9fa0c87ebdea0b29). **MESTRE-SIDE / TEST • 22/10/2026 • nenhuma escrita de regras, Notion, Party ou laboratórios.**

## Produção desta rodada

- **C77:** abriu 28/28 fichas em Técnicas & Pergaminhos: 27 com mecânicas apenas em imagem (bytes não acessados), uma com **Tabela do Caos** textual de 20 bandas d100; confirmou cinco bandas com mecanismos de dano (quatro imediatos, uma aura condicional) e uma banda de cura. Calculou médias brutas somente quando o efeito e alvo eram condicionados. Detectou duas versões distintas de preço de *Raio de Fogo* (1,44 versus 2,44 milhão MED), sem corrigir preço.
- **C78:** abriu **54** equipamentos em quatro famílias (19 armas, 7 armaduras, 13 roupas/acessórios, 15 artefatos); **0 novos IDs**. Fez sete observações de lacunas, incluindo veneno `3d12/turno` sem duração escrita e dardos com bypass narrativo não formalizado.
- **C79:** abriu **27** fichas de consumíveis (7 poções, 20 pílulas); **0 novos IDs**. Registrou cinco lacunas, entre elas paralisia sem CD/duração e divergência de receita da *Poção de Liquidação*. Sem interferência no CRAFT.
- **C80:** montou fila de **22 fontes de Padrões** para segundo revisor realmente independente: 11 casos de primeira triagem com narrativa de dano e 11 controles, embaralhados sem rótulos no arquivo do revisor. **Revisor humano não executou leitura; A8 permanece HOLD**. Os 17 IDs de Bestas reservados para A7 não foram consultados.

A **união de 950 Page-IDs delimitados permanece em 950**. Esta rodada certificou, pela representação textual do conector, **109 corpos de fontes** nos 28+54+27 registros, além da leitura prévia dos 34 Padrões+29 receitas (63 folhas). Nenhuma dessas contagens constitui censo global D0, inspeção de imagens ou homologação de efeito.

## Fronteira adicional de censo (INDEX-ONLY)

As seis raízes de recursos/materiais do índice Itens foram abertas apenas como **índices**, e seus filhos diretos contabilizados: Ervas/Botânica **116**, Minérios **77**, Essências **1**, Drops **11**, Outros Materiais **7**, Ingredientes de Alquimia **0**. Soma de **212 ocorrências de links diretos**, **não 212 novas páginas únicas**. Não houve crosswalk de seus IDs contra os 950 nem leitura dos corpos; **não somar à união**. O zero em Ingredientes de Alquimia significa nenhuma tag filho `<page>` observada na resposta da raiz, não ausência de ingredientes no sistema.

## GATES

`F0 4/8 HOLD • A5 0/7 bytes de anexos originais • F6 0 elegíveis • A7 prospectivo HOLD • A8 revisão humana HOLD • D0 global HOLD • SIM-DMG 0/1875 • DMG-RANK-01 v1.1 intacta.`

A recuperação via URLs assinadas do Notion por si só **não autenticou conteúdo de anexos**, e fazer circular links privados na busca pública é proibido. A falta de writer/epoch/lease impede alterações normativas da operação. Nenhuma simulação sintética foi convertida em evidência real ou crédito de grade.

**NAC-PASS proporcional:** hashes internos e cold replay dos quatro pacotes, sem promoção oficial. **LAST-VERIFIED C81**. `FIRST-PENDING A5 privado → F6 fonte competente → A7 independente → A8 revisão humana real`; prosseguir em próximo perímetro seguro sem duplicar C77–C81.
