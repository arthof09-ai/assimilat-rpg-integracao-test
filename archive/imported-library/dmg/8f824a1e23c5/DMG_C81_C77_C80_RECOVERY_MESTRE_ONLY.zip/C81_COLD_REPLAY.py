#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,zipfile,csv,io
p=Path(__file__).resolve().parent
names=['DMG_C77_TECHNIQUES_D100_MESTRE_ONLY.zip','DMG_C78_EQUIPMENT_54_SOURCE_RISK_MESTRE_ONLY.zip','DMG_C79_CONSUMABLES_SOURCE_GATES_MESTRE_ONLY.zip','DMG_C80_A8_INDEPENDENT_REVIEW_PREP_MESTRE_ONLY.zip']
checks=0;zips={}
for name in names:
 z=zipfile.ZipFile(p/name)
 assert z.testzip() is None;checks+=1
 manifest=[n for n in z.namelist() if n.endswith('_MANIFEST.json') or n=='C77_MANIFEST_SHA256.json']
 assert len(manifest)==1;checks+=1
 m=json.loads(z.read(manifest[0]));
 for fname,digest in m.items():
  assert hashlib.sha256(z.read(fname)).hexdigest()==digest;checks+=1
 zips[name.split('_')[1]]=z
z=zips['C77'];a=list(csv.DictReader(io.StringIO(z.read('C77_28_TECHNIQUES_PROVENANCE.csv').decode())));assert len(a)==28;checks+=1
assert sum(x['rendered_body_type']=='IMAGE_REF_ONLY' for x in a)==27;checks+=1
x=list(csv.DictReader(io.StringIO(z.read('C77_20_D100_PROVEN_OUTCOMES.csv').decode())));assert len(x)==20;checks+=1
z=zips['C78'];a=list(csv.DictReader(io.StringIO(z.read('C78_54_EQUIPMENT_SOURCE_IDS.csv').decode())));assert len(a)==54;checks+=1
old=set(z.read('C78_PREVIOUS_950_UNION.txt').decode().split());assert len(old)==950 and {r['page_id'] for r in a}.issubset(old);checks+=1
z=zips['C79'];a=list(csv.DictReader(io.StringIO(z.read('C79_27_CONSUMABLE_PROVENANCE.csv').decode())));assert len(a)==27;checks+=1
assert {r['page_id'] for r in a}.issubset(old);checks+=1
z=zips['C80'];s=z.read('C80_BLIND_SECOND_READER_QUEUE.csv').decode();a=list(csv.DictReader(io.StringIO(s)));assert len(a)==22;checks+=1
assert 'NARRATIVE_DAMAGE' not in s and 'CONTROL_REVIEW' not in s;checks+=1
assert len(json.loads(z.read('C80_FIRST_PASS_MASTER_ONLY_KEY.json')))==22;checks+=1
assert sum([116,77,1,11,7,0])==212;checks+=1
print(f'C81 PASS {checks} verifications, 4 ZIPs, 950 scoped IDs; global gates HOLD')
