#!/usr/bin/env python3
"""OP-DMG-CORPUS-EMP-01, autonomous R12-R21 scientific oracle, Mestre-side.

NOT a VLAB combat executor. Pure math on physically reopened source constants.
Crit-positive = Mestre auto-hit; negative auto-miss = LAB R42 only.
Dice/check rolls independent only where explicitly stated; not official RNG.
"""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter
import json

ROOT=Path(__file__).resolve().parent
P_PLUS=Q(1,108)
P_MINUS=Q(1,108)
P_NEUTRAL=Q(106,108)
TESTS=0

def check(value,reason):
    global TESTS
    TESTS+=1
    if not value:raise AssertionError(reason)

def fq(v):
    return {'fraction':str(v),'decimal':round(float(v),12)}

def counts(n,sides):
    hist=Counter({0:1})
    for _ in range(n):
        nextone=Counter()
        for v,c in hist.items():
            for d in range(1,sides+1):nextone[v+d]+=c
        hist=nextone
    check(sum(hist.values())==sides**n,'count normalization')
    return hist

def pmf(n,sides):
    ct=counts(n,sides);den=sides**n
    return {v:Q(c,den) for v,c in ct.items()}

def convolve(a,b):
    out=Counter()
    for x,u in a.items():
        for y,v in b.items():out[x+y]+=u*v
    return out

def repeated(a,n):
    v=Counter({0:1})
    for i in range(n):v=convolve(v,a)
    return v

def expectation(dist):
    return sum((Q(k)*v for k,v in dist.items()),Q())

def pcondition(dist,predicate):
    return sum((v for k,v in dist.items() if predicate(k)),Q())

def attack_vs(attacker,defender,use_evasion=False,rd_mode='none'):
    # only physical/physical-or-mixed, never turns spell save into attack
    atk=ACTORS[attacker];tar=ACTORS[defender]
    support=pmf(4,6)
    defense=tar['evade'] if use_evasion else tar['ca']
    p_normal_support=pcondition(support,lambda x:x+atk['attack_bonus']>defense)
    p_normal=P_NEUTRAL*p_normal_support
    p_hit=P_PLUS+p_normal
    d=pmf(atk['damage_n'],atk['damage_sides'])
    applied_RD=(tar['physical_RD'] if rd_mode=='assume_physical_RD' else 0)
    def mean_damage(extra):
        return sum((max(0,k+atk['damage_fixed']+extra-applied_RD)*v for k,v in d.items()),Q())
    normal=mean_damage(0)
    critical=mean_damage(atk['damage_n']*atk['damage_sides'])
    positive=lambda extra:sum((v for k,v in d.items() if k+atk['damage_fixed']+extra>applied_RD),Q())
    p_injure=p_normal*positive(0)+P_PLUS*positive(atk['damage_n']*atk['damage_sides'])
    edmg=p_normal*normal+P_PLUS*critical
    check(p_injure<=p_hit,'positive damage > hits')
    return {'attacker':attacker,'target':defender,'defense':defense,
            'p_normal_given_no_critical':fq(p_normal_support),
            'p_normal_unconditional':fq(p_normal),'p_auto_critical':fq(P_PLUS),
            'p_total_hit':fq(p_hit),'p_positive_damage':fq(p_injure),
            'E_normal_hit_damage':fq(normal),'E_critical_hit_damage':fq(critical),
            'E_damage_per_attempt':fq(edmg),
            'RD_model':rd_mode,'RD_applied':applied_RD,'critical_negative_model':'R42 LAB only'}

ACTORS={
  'Feryn':dict(ca=123,evade=125,physical_RD=22,life=479,reflex_fixed=82,initiative_fixed=82,attack_bonus=92,damage_n=8,damage_sides=8,damage_fixed=47,weapon_type='cortante physical'),
  'Varok':dict(ca=83,evade=83,physical_RD=35,life=734,reflex_fixed=27,initiative_fixed=29,attack_bonus=100,damage_n=10,damage_sides=10,damage_fixed=48,weapon_type='impact/corte physical'),
  'Arveth':dict(ca=93,evade=95,physical_RD=30,life=806,reflex_fixed=25,initiative_fixed=25,attack_bonus=72,damage_n=8,damage_sides=10,damage_fixed=35,weapon_type='perfurante physical'),
  'Iskiel':dict(ca=132,evade=134,physical_RD=25,life=514,reflex_fixed=89,initiative_fixed=89,attack_bonus=101,damage_n=9,damage_sides=8,damage_fixed=47,weapon_type='Vento/perfurante mixed: physical RD uncertain'),
  'Eristan':dict(ca=76,evade=76,physical_RD=25,life=630,reflex_fixed=28,initiative_fixed=30,attack_bonus=None,damage_n=None,damage_sides=None,damage_fixed=None,weapon_type='Plant magic save, not melee attack'),
}

# STRATIFIED STEP 3: physical sword and mixed arrow; no actor without documented weapon attack.
cross={
 'Iskiel_to_Feryn_unmitigated':attack_vs('Iskiel','Feryn'),
 'Iskiel_to_Feryn_if_single_physical_RD':attack_vs('Iskiel','Feryn',rd_mode='assume_physical_RD'),
 'Iskiel_to_Feryn_if_evaded_RD':attack_vs('Iskiel','Feryn',use_evasion=True,rd_mode='assume_physical_RD'),
 'Feryn_to_Iskiel_physical_RD':attack_vs('Feryn','Iskiel',rd_mode='assume_physical_RD'),
 'Feryn_to_Iskiel_if_evaded_RD':attack_vs('Feryn','Iskiel',use_evasion=True,rd_mode='assume_physical_RD'),
 'Iskiel_to_Varok_if_physical_RD':attack_vs('Iskiel','Varok',rd_mode='assume_physical_RD'),
 'Iskiel_to_Arveth_if_physical_RD':attack_vs('Iskiel','Arveth',rd_mode='assume_physical_RD'),
}
check(cross['Iskiel_to_Feryn_unmitigated']['p_normal_given_no_critical']['fraction']=='5/1296','Iskiel CA123 hit threshold')
check(cross['Iskiel_to_Feryn_if_evaded_RD']['p_normal_given_no_critical']['fraction']=='0','Feryn evade125 blocks noncritical 4d6+101')
check(cross['Feryn_to_Iskiel_physical_RD']['p_normal_given_no_critical']['fraction']=='0','Feryn max116 below Iskiel CA132')

# STEP 5: initiative fixed offsets and independent 4d6, equal remaining dice.
init_dice=pmf(4,6)
initiative={}
for nameA,nameB in [('Iskiel','Feryn'),('Iskiel','Varok'),('Eristan','Varok'),('Feryn','Eristan')]:
    A=ACTORS[nameA]['initiative_fixed'];B=ACTORS[nameB]['initiative_fixed']
    pn=pt=Q()
    for a,pa in init_dice.items():
        for b,pb in init_dice.items():
            if a+A>b+B:pn+=pa*pb
            if a+A==b+B:pt+=pa*pb
    initiative[f'{nameA}_vs_{nameB}']={'strictly_first':fq(pn),'ties':fq(pt),'strictly_second':fq(1-pn-pt),
      'tie_resolution':'R26 winner not assigned here, since tie may depend on competent rules'}
check(initiative['Iskiel_vs_Varok']['strictly_first']['fraction']=='1','Iskiel min93 > Varok max53')

# STEP 6: Eristan discharge 8d10+26 Plant magical; Reflexo DC76, half on success,
# NO sequential critical, no universally imported hit roll, NO FF. RD physical is
# not applied to Plant; elemental resistances unspecified.
SP_COST=65;SP_POOL=counts(8,10);BASE_COUNT=10**8
SPELL_DIST={v+26:Q(count,BASE_COUNT) for v,count in SP_POOL.items()}
check(expectation(SPELL_DIST)==70,'Plant magic mean70')
magic_targets={}
for target,a in ACTORS.items():
    p_save=pcondition(init_dice,lambda die:die+a['reflex_fixed']>76)
    magic_targets[target]={'reflex_test':f"4d6+{a['reflex_fixed']}",
        'p_reflex_save':fq(p_save),'p_reflex_fail':fq(1-p_save),
        'E_pre_elemental_RD_if_exact_half':fq(70*(1-p_save)+35*p_save),
        'E_pre_elemental_RD_per_paid_PA':fq((70*(1-p_save)+35*p_save)/65),
        'magic_critical_probability':fq(Q(0)),
        'elemental_RD':'UNDEFINED for Plant, no physical RD assumed'}
check(magic_targets['Feryn']['p_reflex_save']['fraction']=='1','Feryn always saves DC76')
check(magic_targets['Iskiel']['p_reflex_save']['fraction']=='1','Iskiel always saves CD76')
for name in ['Varok','Arveth','Eristan']:
    check(magic_targets[name]['p_reflex_save']['fraction']=='0',f'{name} always fails CD76')

# STEP 7: 804 PA means up to 12 spells. Opponent uninterrupted, all targets in 25m,
# target takes modeled Plant damage, no other mitigation. This is a mathematical
# upper-bound / stress, not a fight; save-reflex is fixed for each actor.
CASTS=804//65
check(CASTS==12 and 804-CASTS*65==24,'Eristan PA ledger')
base_half_floor=Counter()
base_half_ceil=Counter()
base_full=Counter()
for v,count in SP_POOL.items():
    raw=v+26
    base_half_floor[raw//2]+=count
    base_half_ceil[(raw+1)//2]+=count
    base_full[raw]+=count

def hit_by_n_casts(pool,life):
    cnt=repeated(pool,CASTS)
    den=sum(pool.values())**CASTS
    successful=sum(v for k,v in cnt.items() if k>=life)
    check(successful>=0 and successful<=den,'tail numerator sane')
    return fq(Q(successful,den))

pa_scenario={
  'pa_available':804,'cost_each':65,'max_casts_if_uninterrupted':CASTS,'remaining_PA':804-CASTS*65,
  'E_total_pre_resistance_if_Feryn_always_saves':fq(Q(35*CASTS)),
  'E_total_pre_resistance_if_Varok_always_fails':fq(Q(70*CASTS)),
  'P_reduces_Feryn479_by_12_pre_resistance_floor_half_per_cast':hit_by_n_casts(base_half_floor,479),
  'P_reduces_Feryn479_by_12_pre_resistance_ceil_half_per_cast':hit_by_n_casts(base_half_ceil,479),
  'P_reduces_Varok734_by_12_pre_resistance_full':hit_by_n_casts(base_full,734),
  'scope':'PA exhaustion ceiling / target is passive; no counterattacks, no movement costs, no Plant resistance, no restoration. Does NOT predict full-combat winner',
}
check(pa_scenario['P_reduces_Feryn479_by_12_pre_resistance_floor_half_per_cast']['decimal'] <= pa_scenario['P_reduces_Feryn479_by_12_pre_resistance_ceil_half_per_cast']['decimal'],'rounding bounds ordered')

# Distinguish unconstrained time-to-HP from PA-limited 12 cast maximum. Target passive,
# independent 8d10 each legal spell, no Plant resistance, no enemy turn or spatial limit.
def time_to_HP_if_unlimited_pa(cast_hist,life):
    den=sum(cast_hist.values())
    alive=Counter({0:1})
    n=0
    e=Q(0)
    tail=[]
    while alive:
        e+=Q(sum(alive.values()),den**n)
        n+=1
        next_states=Counter()
        for damage_so_far,weight in alive.items():
            for hit_damage,frequency in cast_hist.items():
                if damage_so_far+hit_damage < life:
                    next_states[damage_so_far+hit_damage]+=weight*frequency
        alive=next_states
        survival=Q(sum(alive.values()),den**n)
        tail.append((n,survival))
        check(n<=50,'bounded positive magic increments terminal by 50')
    qvalues={}
    for perc in (10,50,90,95,99):
        qvalues[str(perc)]=min(k for k,surv in tail if 1-surv>=Q(perc,100))
    return {'expected_casts_if_unlimited_PA':fq(e),'quantile_casts':qvalues,
            'max_possible_casts_to_guarantee_HP_if_PA_unlimited':n,
            'not_a_real_fight':'enemy passive; no PA cap, interrupts, or Plant resistance'}

pa_scenario['if_PA_were_unlimited_Feryn_round_floor']=time_to_HP_if_unlimited_pa(base_half_floor,479)
pa_scenario['if_PA_were_unlimited_Feryn_round_ceil']=time_to_HP_if_unlimited_pa(base_half_ceil,479)
pa_scenario['if_PA_were_unlimited_Varok_full']=time_to_HP_if_unlimited_pa(base_full,734)
check(pa_scenario['if_PA_were_unlimited_Feryn_round_floor']['expected_casts_if_unlimited_PA']['decimal']>CASTS,
      'Feryn expected spells exceeds PA budget')
check(pa_scenario['if_PA_were_unlimited_Varok_full']['expected_casts_if_unlimited_PA']['decimal']<CASTS,
      'Varok expected spells within PA budget')

# STEP 4: historical version conflict and DOT components; NOT independent units.
version_math={
  'ataque_frio_eterno':{
    'v1':dict(family='Chen Yi-Min/Ataque Frio',expression='2d4',intrinsic_E=fq(Q(5)),sword_PA=4,crossbow_PA=10,freeze_trigger=fq(Q(15,100)),conditional_dot_tick='2d6 if failure, tick count unspecified'),
    'v2':dict(expression='2d8+2',intrinsic_E=fq(Q(11)),sword_PA=9,crossbow_PA=15,freeze_trigger=fq(Q(20,100)),conditional_rider='2d6 after failed CON test, temporal contract insufficient'),
    'v3_header':dict(expression='4d8+8',intrinsic_E=fq(Q(26)),sword_PA=20,crossbow_PA=30),
    'v3_body':dict(expression='2d8+2',intrinsic_E=fq(Q(11)),sword_PA=20,crossbow_PA=30),
    'v3_header_to_body_ratio_DME':fq(Q(26,11)),
    'interpretation':'Do not select v3 header/body without competent precedence; versions not independent trials; 15/20% triggers are not unconditional freeze probabilities',
  },
  'coluna_gelo':{
    'v2_header':dict(expression='3d6/tick',intrinsic_E=fq(Q(21,2)),PA=12),
    'v2_body':dict(expression='2d6/tick',intrinsic_E=fq(Q(7)),PA=11),
    'v3_header_body':dict(expression='6d6/tick',intrinsic_E=fq(Q(21)),PA=11),
    'v2_and_v3_are_related':'YES; current/historical authority must be reconciled independently',
    'tick_duration':'NOT ESTABLISHED; while immobilized and if lacking ice resistance',
    'v3_over_v2_body_conditional_tick_ratio':fq(Q(3)),
  },
  'adaga_serpente':dict(expression='5d4+5d8+10',E_raw=fq(Q(45)),min_raw=20,max_raw=70,
       conditional_venom='3d12/tick, raw E19.5, after CON save CD25 fail, duration unknown',PA_cost=35,
       p_save='NOT MODELLED (actor or constitution proficiency absent)'),
  'sangramento':dict(dot_per_wound='1d6 per target turn, then constitution CD25 save or Medicine action',E_raw_tick_per_wound=fq(Q(7,2)),
      symbolic_E_ticks='1/p on independent saves after every tick, for p>0; infinity when p=0 absent other cure',
      symbolic_E_raw_damage='3.5/p per single wound, p is conditional pass chance, NOT calibrated',
      caveats=['legacy catalog source, not automatically current canon','cannot replace NECROTICO with DARK','stacks count by successful wounds; do not invent max','other cures and turn timings may change formula']),
  'vendaval':dict(prata={'cast_PA':15,'upkeep_PA_per_turn':5,'buff_mean_per_eligible_wind_attack':7},
       ouro={'cast_PA':35,'upkeep_PA_per_turn':12,'buff_mean_per_eligible_wind_attack':14},
       scope='9m area; cast time 1 turn; complex saves/targets; costs 15+5t or 35+12t, no hidden damage turn equivalence'),
  'correntes_julgamento':dict(cost_PA=30,dot_raw_4d12_E=fq(Q(26)),conditional_heal_half_damage_no_rounding_E=fq(Q(13)),
       symbolic='n ticks E=26n raw conditional on failing save and staying bound; t unknown; heal from actual received not gross',
       status='partial: Reflexo/Fortitude tests and repeat duration/rounding unproven')
}

# STEP 5 new crossrank: Goat Bronze1 Investida has critical raw 1d6+FOR13+maxdie6 = 20..25.
# Correct: +6 is *attack proficiency* only and must NOT be added twice to damage.
GOAT_RAW_CRIT=range(20,26)
goat_crossrank={}
for target in ACTORS:
   rd=ACTORS[target]['physical_RD']
   damages=[max(0,d-rd) for d in GOAT_RAW_CRIT]
   goat_crossrank[target]={'target_RD_physical':rd,
      'critical_raw_domain':'20..25 (1d6 + FOR13 + maxd6; Luta+6 is NOT damage bonus)',
      'critical_net_support':damages,
      'p_positive_damage_given_critical':fq(Q(sum(d>0 for d in damages),6)),
      'E_damage_per_goat_attack_if_ordinary_hits_all_blocked':fq(P_PLUS*Q(sum(damages),6)),
      'scope':'one source-authorized Investida only, no equipment/reaction/other abilities'}
check(goat_crossrank['Feryn']['p_positive_damage_given_critical']['fraction']=='1/2','Goat against RD22 crit positive 3/6')
for t in ['Varok','Arveth','Iskiel','Eristan']:
    check(goat_crossrank[t]['p_positive_damage_given_critical']['fraction']=='0',t+' RD blocks Goat crit')

# STEP 8 R50/51 local normative oracle only, NOT VLAB runner.
reaction_cases=[
 {'case':'normal_miss_counter_declared_before_RNG','attack_kind':'normal_standard','critical':False,'normal_score_below_CA':True,'actual_hit':False,'reaction_was_predeclared':True,'reaction_slot_before':1,'expected_response':'normal_attack_with_advantage','slot_after':0,'authority':'Mestre R50'},
 {'case':'normal_hit_counter_declared_before_RNG','attack_kind':'normal_standard','critical':False,'normal_score_below_CA':False,'actual_hit':True,'reaction_was_predeclared':True,'reaction_slot_before':1,'expected_response':'NO_RESPONSE','slot_after':0,'authority':'Mestre R50'},
 {'case':'positive_crit_score_low','attack_kind':'normal_standard','critical':True,'normal_score_below_CA':True,'actual_hit':True,'reaction_was_predeclared':True,'reaction_slot_before':1,'expected_response':'NO_RESPONSE','slot_after':0,'authority':'Mestre R41/R50'},
 {'case':'positive_crit_damage_zero_after_RD','attack_kind':'normal_standard','critical':True,'normal_score_below_CA':True,'actual_hit':True,'net_damage':0,'reaction_was_predeclared':True,'reaction_slot_before':1,'expected_response':'NO_RESPONSE','slot_after':0,'authority':'Mestre R41/R50'},
 {'case':'nested_attack_generated_by_counter','attack_kind':'COUNTER_RESPONSE','critical':False,'normal_score_below_CA':True,'actual_hit':False,'reaction_was_predeclared':False,'reaction_slot_before':1,'expected_response':'NOT_ELIGIBLE_PRE_GATE','slot_after':1,'authority':'Mestre R51'},
 {'case':'later_normal_attack_from_B_own_turn','attack_kind':'normal_standard','critical':False,'normal_score_below_CA':True,'actual_hit':False,'reaction_was_predeclared':True,'reaction_slot_before':1,'expected_response':'normal_attack_with_advantage','slot_after':0,'authority':'Mestre R51 follow-up'},
 {'case':'second_attack_before_reaction_refresh','attack_kind':'normal_standard','critical':False,'normal_score_below_CA':True,'actual_hit':False,'reaction_was_predeclared':False,'reaction_slot_before':0,'expected_response':'NO_RESPONSE','slot_after':0,'authority':'R39B/R26'},
 {'case':'counter_requested_after_roll','attack_kind':'normal_standard','critical':False,'normal_score_below_CA':True,'actual_hit':False,'reaction_was_predeclared':False,'reaction_slot_before':1,'expected_response':'NOT_ELIGIBLE_PRE_GATE','slot_after':1,'authority':'Sistema de Combate + Mestre R50'},
]
check(sum(c['expected_response']=='normal_attack_with_advantage' for c in reaction_cases)==2,'two authorized response cases')
check(all(c['expected_response']!='normal_attack_with_advantage' for c in reaction_cases if c.get('critical')),'no counter to crit')
check(all(c['expected_response']!='normal_attack_with_advantage' for c in reaction_cases if c['attack_kind']=='COUNTER_RESPONSE'),'no nested counter')

# Source population counts / conflicts from frozen cohort only, not universe.
ledger=json.loads((ROOT/'COHORT_SOURCE_LEDGER.json').read_text())
source_quality={
  'pages_examined_in_preselected_cohort':len(ledger['candidates']),
  'explicit_numeric_damage_definition_pages':sum(i['key'] in ['ataque_frio_v1','ataque_frio_v2','ataque_frio_v3','coluna_gelo_v2','coluna_gelo_v3','adaga_serpente','sangramento','vendaval','correntes','iskiel','eristan','prata3b'] for i in ledger['candidates']),
  'numeric_formula_plus_named_actual_resolution':2, # Iskiel physical, Eristan magic; qualified by physical type/element as discussed
  'rank_body_title_conflicts_in_4_prespecified_rank_leaf_pages':3,
  'rank_leaf_pages_preselected':4,
  'distinct_cluster_ids_in_cohort':len(set(x['cluster'] for x in ledger['candidates'])),
  'Lote003_individually_authenticated':0,
  'global_coverage_denominator':'UNKNOWN',
  'holdout_locked':'NO; pre-reg was selection-based exploratory, all members viewed and none eligible as blinded holdout',
  'grouped_development_only':True,
}
check(source_quality['pages_examined_in_preselected_cohort']==15,'cohort count')
check(source_quality['distinct_cluster_ids_in_cohort']==11,'within-cohort clusters')

OUT={
 'operation':'OP-DMG-CORPUS-EMP-01','checkpoint':'POST-C11-AUTO10-R12_R21','date':'2026-10-16','baseline':'DMG-RANK-01 v1.1 unchanged',
 'methods':'exact discrete enumeration and integer convolution, never native VLAB execution',
 'source_quality':source_quality,
 'cross_pair_ON5':cross,'actor_constants':ACTORS,'initiative_competition':initiative,
 'magic_Eristan_CD76':{'spell':'Cajado da Última Seiva 8d10+26 Planta, 65 PA, 25m; Reflexo CD76 half; no magic crit; no FF',
                       'outcome_by_actor':magic_targets,'pa_sustainability':pa_scenario},
 'version_and_effect_math':version_math,
 'bronze_goat_vs_new_ON5':goat_crossrank,
 'R50_R51_lab_oracle_cases':reaction_cases,
 'counts':{'exact_assertions':TESTS,'new_native_fights':0,'new_native_events':0,'canonical_writes':0,'VLAB_terminal_contracts':0,'VLAB_canonical_cells':0},
 'limitations':['Never classify these ON5 proposed encounters as a population or Party state',
                'The Iskiel Vento/perfurante mixed hit has no fully certified physical+elemental RD combining rule in this report',
                'Eristan Plant spell has no sourced elemental resistance for targets; HP depletion is pre-resistance only',
                'PA-limited 12 cast model assumes caster uninterrupted and all 12 casts legal within 25m',
                'No Monte Carlo seeded tests are claimed; integer-exact method sufficient for new bounded queries',
                'No negative-critical consequence imported to spells, which cannot score positive/negative attack crit',
                'Rank or version conflicts cannot be resolved with inferred star or historical precedence',
                'No VLAB engine or SQLite state modified; local reaction cases are test vector oracles only']
}
outpath=ROOT/'R12_R21_RESULTS_EXACT.json'
outpath.write_text(json.dumps(OUT,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('PASS local exact checks=',TESTS)
print('Iskiel normal vs Feryn',cross['Iskiel_to_Feryn_unmitigated']['p_normal_given_no_critical'])
print('Eristan save groups',[(x,magic_targets[x]['p_reflex_save']['fraction']) for x in ACTORS])
print('PA Feryn floor-tail',pa_scenario['P_reduces_Feryn479_by_12_pre_resistance_floor_half_per_cast'])
print('PA Feryn ceil-tail',pa_scenario['P_reduces_Feryn479_by_12_pre_resistance_ceil_half_per_cast'])
print('PA Varok full-tail',pa_scenario['P_reduces_Varok734_by_12_pre_resistance_full'])
print('New Goat targets',[(x,goat_crossrank[x]['p_positive_damage_given_critical']['fraction']) for x in ACTORS])
print('OUT',outpath)
