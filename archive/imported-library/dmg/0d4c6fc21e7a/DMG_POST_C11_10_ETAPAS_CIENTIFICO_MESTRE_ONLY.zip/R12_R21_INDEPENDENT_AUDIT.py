#!/usr/bin/env python3
"""Cold independent mathematical audit for OP-DMG-CORPUS-EMP-01 R12-R21.
Does NOT import R12_R21_EXACT_MODEL.py. Comb counting based on inclusion-exclusion
and independent list-convolution. Does NOT execute combat or modify source data.
"""
from math import comb
from fractions import Fraction as F
from pathlib import Path
import json, hashlib, zipfile, re

ROOT=Path(__file__).resolve().parent
A=json.loads((ROOT/'R12_R21_RESULTS_EXACT.json').read_text())
passed=[]

def check(c,label):
    if not c: raise AssertionError(label)
    passed.append(label)

def num_fraction(field):
    return F(field['fraction'])

def bounded(n,m,total):
    # coefficient of x^(total-n) in ((1-x^m)/(1-x))^n
    t=total-n
    if t<0 or t>n*(m-1):return 0
    return sum((-1)**j*comb(n,j)*comb(t-m*j+n-1,n-1) for j in range(min(n,t//m)+1))

def power_list(poly,n):
    out=[1]
    for _ in range(n):
        nxt=[0]*(len(out)+len(poly)-1)
        for i,iv in enumerate(out):
            if not iv:continue
            for j,jv in enumerate(poly):
                if jv:nxt[i+j]+=iv*jv
        out=nxt
    return out

# critical formula and 4d6 direct check independent of prior module
seq=[(a,b,c) for a in range(1,7) for b in range(1,7) for c in range(1,7) if a==b==6 and c>=5]
check(len(seq)==2,'sequential crit domain is exactly 2/216')
ct4={total:bounded(4,6,total) for total in range(4,25)}
check(sum(ct4.values())==6**4,'4d6 independent inclusion-exclusion counts 1296')
isk_common=sum(w for total,w in ct4.items() if 101+total>123)
check(isk_common==5,'Iskiel threshold ordinary hits Feryn exactly five faces')
check(num_fraction(A['cross_pair_ON5']['Iskiel_to_Feryn_unmitigated']['p_normal_given_no_critical'])==F(5,1296),'Iskiel ordinary hit probability')
check(all(101+t<=125 for t in ct4),'Iskiel cannot beat Feryn Esquiva125 ordinary')
check(max(92+t for t in ct4)<132,'Feryn cannot beat Iskiel CA132 ordinary')
check(num_fraction(A['cross_pair_ON5']['Feryn_to_Iskiel_physical_RD']['p_total_hit'])==F(1,108),'Feryn only critical hits Iskiel')
for who,bonus,expected in [('Feryn',82,1),('Iskiel',89,1),('Varok',27,0),('Arveth',25,0),('Eristan',28,0)]:
    hits=sum(w for t,w in ct4.items() if t+bonus>76)
    check(hits==expected*6**4,f'{who} Reflexo threshold CD76')
    check(num_fraction(A['magic_Eristan_CD76']['outcome_by_actor'][who]['p_reflex_save'])==F(expected),f'{who} oracle save probability')
check(num_fraction(A['magic_Eristan_CD76']['outcome_by_actor']['Feryn']['E_pre_elemental_RD_if_exact_half'])==35,'Feryn half mean35')
check(num_fraction(A['magic_Eristan_CD76']['outcome_by_actor']['Varok']['E_pre_elemental_RD_if_exact_half'])==70,'Varok full mean70')

# Independent per-spell hist by INCLUSION-EXCLUSION, rather than 8 d10 enumeration
sp={26+t:bounded(8,10,t) for t in range(8,81)}
check(sum(sp.values())==10**8,'8d10 independent compositions')
check(sum(v*w for v,w in sp.items())==70*10**8,'8d10+26 mean70')
lo=[0]*54;hi=[0]*54;full=[0]*107
for total,w in sp.items():
    lo[total//2]+=w
    hi[(total+1)//2]+=w
    full[total]+=w

def tail(poly,cost,life):
    n=len(poly)
    hist=power_list(poly,12)
    den=sum(poly)**12
    # sum event of at least hp life removed
    result=F(sum(hist[life:]),den)
    check(sum(hist)==den,f'{cost} distribution normalized')
    return result

pa=A['magic_Eristan_CD76']['pa_sustainability']
lo_p=tail(lo,'floor',479)
hi_p=tail(hi,'ceil',479)
va_p=tail(full,'full',734)
check(lo_p==num_fraction(pa['P_reduces_Feryn479_by_12_pre_resistance_floor_half_per_cast']),'Feryn floor12 exact independent')
check(hi_p==num_fraction(pa['P_reduces_Feryn479_by_12_pre_resistance_ceil_half_per_cast']),'Feryn ceil12 exact independent')
check(va_p==num_fraction(pa['P_reduces_Varok734_by_12_pre_resistance_full']),'Varok full12 exact independent')
check(0<lo_p<=hi_p<F(1,1000),'Feryn PA limit unlikely to kill in 12 passive spells')
check(va_p>F(999,1000),'Varok full12 near-certain pre-elemental-resistance')
check(pa['remaining_PA']==24 and pa['max_casts_if_uninterrupted']==12,'Eristan PA arithmetic')

# Independent end-time by summing convolution survival at every n, NOT by
# the primary model's absorbing-state recurrence.
def E_casts_by_full_convolution(poly, life, max_n):
    den=sum(poly)
    hist=[1]
    total=F(0)
    for n in range(max_n):
        total+=F(sum(hist[:life]),den**n)
        next_hist=[0]*(len(hist)+len(poly)-1)
        for j,weight in enumerate(poly):
            if weight:
                for i,previous in enumerate(hist):
                    if previous:next_hist[i+j]+=previous*weight
        hist=next_hist
    check(sum(hist[:life])==0,'maximum number of casts must reach HP by support')
    return total
for label,poly,life,field in [
    ('FerynFloor',lo,479,'if_PA_were_unlimited_Feryn_round_floor'),
    ('FerynCeil',hi,479,'if_PA_were_unlimited_Feryn_round_ceil'),
    ('Varok',full,734,'if_PA_were_unlimited_Varok_full')]:
    v=pa[field]
    q=E_casts_by_full_convolution(poly,life,v['max_possible_casts_to_guarantee_HP_if_PA_unlimited'])
    check(q==num_fraction(v['expected_casts_if_unlimited_PA']),label+' time-to-HP independently exact')

# R50/R51 invariant through independent contract predicate, no engine execution.
for c in A['R50_R51_lab_oracle_cases']:
    response=(c['attack_kind']=='normal_standard' and c['reaction_was_predeclared'] and c['reaction_slot_before']==1 and not c['actual_hit'])
    expected='normal_attack_with_advantage' if response else ('NOT_ELIGIBLE_PRE_GATE' if c['reaction_slot_before'] and not c['reaction_was_predeclared'] else 'NO_RESPONSE')
    check(expected==c['expected_response'],f"R50/R51 oracle '{c['case']}'")
    # Eager pre-declaration consumption only in already-declared eligible slot; never award gratis refresh
    after=0 if c['reaction_was_predeclared'] and c['reaction_slot_before']==1 else c['reaction_slot_before']
    check(after==c['slot_after'],f"slot conservation '{c['case']}'")

# Critical done with RD, using exact source numeric 1d6+FOR13+max d6.
for who,d in {'Feryn':22,'Varok':35,'Arveth':30,'Iskiel':25,'Eristan':25}.items():
    valid=sum(1 for face in range(1,7) if (face+13+6)>d)
    x=num_fraction(A['bronze_goat_vs_new_ON5'][who]['p_positive_damage_given_critical'])
    check(x==F(valid,6),f'critical auto-hit without damage through RD for {who}')

# Version conflict independent arithmetic, no source choice.
z=A['version_and_effect_math']
check(num_fraction(z['ataque_frio_eterno']['v3_header']['intrinsic_E'])==26,'Frio III headline 4d8+8 mean26')
check(num_fraction(z['ataque_frio_eterno']['v3_body']['intrinsic_E'])==11,'Frio III body 2d8+2 mean11')
check(num_fraction(z['coluna_gelo']['v2_header']['intrinsic_E'])==F(21,2),'Coluna II headline 3d6 mean10.5')
check(num_fraction(z['coluna_gelo']['v2_body']['intrinsic_E'])==7,'Coluna II body 2d6 mean7')
check(num_fraction(z['coluna_gelo']['v3_header_body']['intrinsic_E'])==21,'Coluna III 6d6 mean21')

# Preservation auditor: no older files changed in this invocation. Granular manifest.
old_checkpoints={
 'R10':'/mnt/data/dmg_recovery/r10/R10_CHECKPOINT_SHA256.json',
 'C01':'/mnt/data/dmg_recovery/post_r10_c01/C01_CHECKPOINT_SHA256.json',
 'C02_C06':'/mnt/data/dmg_recovery/post_r10_cycles/C02_C06_FINAL_CHECKPOINT.json',
 'C07_C11':'/mnt/data/dmg_recovery/post_r10_cycles/C07_C11/C07_C11_FINAL_CHECKPOINT.json'
}
retained={}
for name,path in old_checkpoints.items():
    p=Path(path); retained[name]={'checkpoint_path':str(p),'checkpoint_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'verified_file_hashes':0,'mount_missing':0,'hash_mismatch':0}
    old=json.loads(p.read_text())
    if name=='R10': arr=[(x,v['sha256']) for x,v in old.get('files',{}).items()]
    elif name=='C01':arr=[(x['relative_path'],x['sha256']) for x in old.get('artifacts',[])]
    elif name=='C02_C06':arr=[(x,y if isinstance(y,str) else y.get('sha256')) for x,y in old.get('new_files_and_sha256',{}).items()] if isinstance(old.get('new_files_and_sha256'),dict) else []
    else:arr=[(x,y if isinstance(y,str) else y.get('sha256')) for x,y in old.get('new_files_sha256',{}).items()]
    for rel,sha in arr:
        f=p.parent/rel
        if not f.is_file():retained[name]['mount_missing']+=1
        elif hashlib.sha256(f.read_bytes()).hexdigest()!=sha:retained[name]['hash_mismatch']+=1
        else:retained[name]['verified_file_hashes']+=1
    check(retained[name]['hash_mismatch']==0,name+' no verified file hash divergence')

vlab='/mnt/data/dmg_recovery/post_r10_cycles/evidence_readonly/VLAB_R47_R48_R49_CRITICO_CONTRA_ANINHAMENTO_ON5_MESTRE_ONLY.zip'
f=Path(vlab)
if f.is_file():
  digest=hashlib.sha256(f.read_bytes()).hexdigest()
  check(digest=='fada8b0a413edfcdccc54af60c258c0bd25274848a9c10ff4df37d11cf0ed7d2','VLAB R47-R49 historical zip preserved')
  with zipfile.ZipFile(f) as zp:
    check(zp.testzip() is None,'VLAB R47-R49 zip CRC good')
  archive={'path':vlab,'sha256':digest,'crc_pass':True,'reused_historical':True,'replayed_here':False}
else:archive={'present':False,'replayed_here':False}

qa={'operation':'OP-DMG-CORPUS-EMP-01','checkpoint':'POST-C11-AUTO10-R12_R21',
    'independent_impl':'Inclusion-exclusion per dice distribution + array polynomial convolution, no import from primary model',
    'passed_assertions':len(passed),'passed_labels':passed,
    'historical_checkpoint_availability':retained,'VLAB_historical_zip':archive,
    'new_native_vlab_runs':0,'production_writes':0,
    'independence_limit':'second independently written LOCAL code, NOT a second human auditor or canonical homologation'}
(ROOT/'R12_R21_INDEPENDENT_QA.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False)+'\n')
print('AUDIT PASS',len(passed))
print('old retention', {k:(v['verified_file_hashes'],v['mount_missing'],v['hash_mismatch']) for k,v in retained.items()})
print('floor/ceil Varok',float(lo_p),float(hi_p),float(va_p))
