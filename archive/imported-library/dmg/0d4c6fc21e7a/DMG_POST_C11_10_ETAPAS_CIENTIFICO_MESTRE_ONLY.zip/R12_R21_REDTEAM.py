#!/usr/bin/env python3
"""Adversarial tests against LOCAL DMG scientific oracles only (not VLAB!)."""
import copy,json
from pathlib import Path
P=Path(__file__).resolve().parent
r=json.loads((P/'R12_R21_RESULTS_EXACT.json').read_text())

def gate(row):
    # Contract oracle anchored to documented Mestre/VLAB decisions, not engine API.
    if row['kind']=='counter':
        response_allowed=(row['from_normal_attack'] and row['declared_before_rng'] and row['available_slot'] and not row['actual_hit'])
        return row['response_performed']==response_allowed
    if row['kind']=='goat_critical_damage':
        return row['damage']==max(0,row['die']+13+6-row['RD'])
    if row['kind']=='magic_no_critical':
        return not row['applied_sequential_critical']
    if row['kind']=='PA_ledger':
        return row['initial_PA']>=row['casts']*row['PA_cost'] and row['remaining']==row['initial_PA']-row['casts']*row['PA_cost']
    if row['kind']=='source_conflict':
        return not(row['has_unresolved_discordance'] and row['claims_single_canonical_value'])
    if row['kind']=='terminal_censorship':
        return not(row['censored'] and row['winner'] is not None)
    if row['kind']=='holdout':
        return not(row['was_read_during_development'] and row['claims_independent_blind_holdout'])
    if row['kind']=='reaction_refresh':
        return not(row['claimed_second_reaction'] and not row['renewal_occurred'])
    if row['kind']=='rank_class':
        return not(row['conflict'] and row['promotes_one_rank_without_competent_decision'])
    return False

# Positive controls must be admitted. Mutations must fail.
cases=[
('critical_hit_blocks_counter',{'kind':'counter','from_normal_attack':True,'declared_before_rng':True,'available_slot':True,'actual_hit':True,'response_performed':False},'response_performed',True),
('normal_miss_enables_counter',{'kind':'counter','from_normal_attack':True,'declared_before_rng':True,'available_slot':True,'actual_hit':False,'response_performed':True},'response_performed',False),
('nested_counter_prohibited',{'kind':'counter','from_normal_attack':False,'declared_before_rng':True,'available_slot':True,'actual_hit':False,'response_performed':False},'response_performed',True),
('no_post_rng_counter',{'kind':'counter','from_normal_attack':True,'declared_before_rng':False,'available_slot':True,'actual_hit':False,'response_performed':False},'response_performed',True),
('goat_luta_is_attack_only',{'kind':'goat_critical_damage','die':4,'RD':22,'damage':1},'damage',7),
('magic_has_no_sequential_crit',{'kind':'magic_no_critical','applied_sequential_critical':False},'applied_sequential_critical',True),
('PA_ledger_no_free_cast',{'kind':'PA_ledger','initial_PA':804,'casts':12,'PA_cost':65,'remaining':24},'casts',13),
('V3_header_body_not_auto_resolved',{'kind':'source_conflict','has_unresolved_discordance':True,'claims_single_canonical_value':False},'claims_single_canonical_value',True),
('censorship_not_tie',{'kind':'terminal_censorship','censored':True,'winner':None},'winner','EMPATE'),
('blind_holdout_not_dev_cohort',{'kind':'holdout','was_read_during_development':True,'claims_independent_blind_holdout':False},'claims_independent_blind_holdout',True),
('reaction_cannot_refresh_without_turn',{'kind':'reaction_refresh','claimed_second_reaction':False,'renewal_occurred':False},'claimed_second_reaction',True),
('rank_conflict_no_silent_choice',{'kind':'rank_class','conflict':True,'promotes_one_rank_without_competent_decision':False},'promotes_one_rank_without_competent_decision',True)
]
report=[]
for case,positive,field,bad in cases:
    assert gate(positive),case+' positive control invalid'
    mutation=copy.deepcopy(positive);mutation[field]=bad
    assert not gate(mutation),case+' mutation was accepted'
    report.append({'case':case,'positive':'PASS','adversarial_mutation':'REJECTED','scope':'LOCAL_CHECK_ONLY; VLAB behavior NOT executed'})
res={'checkpoint':'POST-C11-AUTO10-R12_R21','new_test_cases':len(cases),'positive_controls_passed':len(cases),'locally_mutated_oracle_inputs_rejected':len(cases),
     'not_VLAB_engine':True,'not_proof_of_canonical_compliance':True,'cases':report}
(P/'R12_R21_REDTEAM_RESULTS.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print('REDTEAM LOCAL PASS',len(cases),'mutations rejected')
