# PSV — DMG R12–R21 / Continuidade pós-C11 — Dez etapas autônomas

**OPERAÇÃO:** CM-000001 / OP-DMG-CORPUS-EMP-01 (existente). **SIDE:** MESTRE. **AS-OF:** 2026-10-16. **BASELINE OFICIAL:** DMG-RANK-01 v1.1, inalterada. **CHECKPOINT ANTES:** POST-R10-C07-C11. **CHECKPOINT DEPOIS:** POST-C11-AUTO10-R12_R21. **Escritas canônicas:** ZERO. **NAC-PASS produtivo:** HOLD.

> Este dossiê trata exclusivamente da pesquisa científica de dano. Todos os cálculos novos são **MATH-ONLY** e testes adversariais locais. Nenhum combate nativo foi iniciado, nenhum motor histórico VLAB foi modificado, nenhuma Party/O Primeiro foi consultada ou escrita. Fontes Mestre-only não devem ser retransmitidas à Party.

## A. Programa operacional executado (10/10 tentativas, sem 10 novos projetos)

| Passo | Questão executada | Estado/evidência | Resultado material |
|---|---|---|---|
| 1 | Recuperação físico-preservacional | **PARCIAL FÍSICO** | Manifests R10/C01/C02-C06/C07-C11 reabertos; 27/58 referências de arquivos montadas e SHA válido, 31 **não montadas**, 0 divergência entre presentes. Não dizer que arquivos não montados foram destruídos. |
| 2 | VLAB e decisões mais recentes | **VERIFICADO DOCUMENTAL** | OP original Notion encerra em **R51** (último corpo consultado). R50 real miss para Contra; R51 veda cadeia Counter→Counter. Não há prova R52+ na Biblioteca consultada. |
| 3 | Veado/Regalis | **PARTIAL / BLOCKED POR CAMPOS** | Veado título Bronze4 / corpo Bronze2 e Luta Galha ausente; Regalis parent Ouro2, Nome vazio, texto Aurora Radiante e classificação técnica/magia incompleta. Não declarar nativo pronto. |
| 4 | Expandir corpus dirigido | **EXECUTADO EXPLORATÓRIO** | Pré-registro local antes de abrir os corpos: **15 páginas físicas**, **11 clusters documentais dentro da coorte**, 12 páginas contendo ao menos um componente numérico ofensivo, conflitos por versão e rank. |
| 5 | Cross-rank e precisão | **EXATO CONDICIONAL** | Iskiel/Feryn cai na fronteira de críticos; Cabra B1 Investida não perfura RD25 nem em crítico. |
| 6 | PA, DoT, efeitos e ações | **EXATO/PARCIAL** | Nova descarga Eristan Planta (65 PA, Reflexo CD76, sem crítico); efeitos Frio/Coluna/veneno/sangramento/Vendaval/Correntes individualizados sem duração inventada. |
| 7 | Duração com PA e Salvaguardas | **EXATO CONDICIONAL** | 12 casts máximo sobre PA804; probabilidade de incapacitação 479/734 HP, expectativa de conjurações se PA ilimitado e dependência do arredondamento. |
| 8 | Redteam e VLAB | **12 TESTES DE ORÁCULO LOCAL PASS** | Injeções negativas em CLONES das entradas locais rejeitadas; handoff incremental PREPARED, não entregue nem executado. |
| 9 | Auditoria independente / F0–F18 | **PASS MATEMÁTICO; HOLD GOVERNANÇA** | Segundo código sem importar o primeiro reproduz com inclusão-exclusão e convolução de polinômios. F0 **4/8**, Lote003 **0/71**, nenhum holdout independente novo. |
| 10 | Gate final | **LOCAL PASS, PRODUTIVO HOLD** | Código/script/JSON/relatório reabertos e resumidos no manifesto SHA. Ponto exato de retomada descrito ao fim. |

As dez etapas **foram materialmente tentadas**. Estados PARCIAL/HOLD sinalizam lacunas físicas ou normativas, não falsos PASS terminais.

## B. Reconciliação física e temporal

O Notion original da operação DMG (`3f3c2b324ede813e9fa0c87ebdea0b29`) mantém a matriz F0–F18 e o adendo E01–E24; seu último registro de plano é historicamente anterior à presente sequência local. A velha tarefa nomeada DMG R11→R12, de 09/10, **não é** nossa rodada R12–R21 pós-C11. Nenhum registro foi sobrescrito. R10_RESULTS é estado intermediário de auditoria R40, R10_SECONDARY_AUDIT e o PSV R10 correspondem à execução posterior.

Na sessão, quatro manifests pré-existentes foram fisicamente abertos. Foram encontrados SHA válidos para **8/12 arquivos indicados por R10**, **8/18 por C01**, **5/18 por C02–C06** e **6/10 por C07–C11**. Os demais **31 arquivos não estavam montados nos caminhos indicados no runtime**, sem prova de que não existam em Biblioteca. Nenhum dos 27 presentes divergiu de seu hash. Os quatro manifests físicos possuem sua própria identidade/hash no relatório `R12_R21_INDEPENDENT_QA.json`.

A última consulta física da OP-VLAB mostrou `R47–R49` REGISTRO DEPOIS e decisões R50/R51. A Biblioteca original examinada não retornou artefato R52+, mas **trabalho concorrente não comprovado não deve ser descartado**. O ZIP histórico R47–R49 já recuperado teve SHA `fada8b0a413edfcdccc54af60c258c0bd25274848a9c10ff4df37d11cf0ed7d2` e CRC reafirmados nesta sessão. Suas 6 cenas/15 eventos foram auditados em C08; NÃO ocorreu uma nova execução VLAB neste estudo.

**R50 expressa:** Contra-atacar só quando o ataque entrante **realmente ERRA**; um crítico positivo, mesmo com pontuação comum baixa ou dano zerado pela RD, é um acerto e não produz Contra-resposta. **R51 expressa:** resposta de Contra-atacar nunca abre outro Contra-atacar; ataque normal futuro no turno do outro combatente pode abrir nova oportunidade legal. Os bloqueios normativos C11 sobre essas duas questões estão **SUPERADOS**. Ainda faltam regressões nativas **sob esses contratos novos**, e não se deve chamar decisão textual de prova de implementação ou edição da regra geral Sistema de Combate.

## C. Descoberta 1 — Eristan apresenta uma bifurcação determinística de Salvaguarda no mesmo ON5

Fonte direta Mestre: [Sikong Eristan](https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76), NPC ON5 de encontro proposto, Cajado da Última Seiva: **Ação Padrão**, 65 PA, até **25m**, dano `8d10+26` Planta, alvo **Reflexo CD76 para metade**, sem FF adicional na descarga. Não usa crítico sequencial, conforme [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373). A passagem textual adjacente apresenta uma referência a FF+2, mas a descarga explicita sem FF e o quadro operacional fixa `8d10+26`: **não somamos FF duas vezes**, mantemos a anotação ambígua como alerta de proveniência.

Sistemas de referência das demais fichas de encontro ON5 (propostas Mestre-side, **não população geral**): [Feryn](https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31) Reflexo `4d6+82`; [Iskiel](https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966) `4d6+89`; [Varok](https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091) `4d6+27`; [Arveth](https://app.notion.com/p/3f6c2b324ede8105891fc647242e61ca) `4d6+25`.

| Alvo ON5 | Suporte do Reflexo | Chance de superar CD76 | Dano médio **bruto** antes de RD elemental |
|---|---|---:|---:|
| Feryn | 86–106 | **1** | **35** |
| Iskiel | 93–113 | **1** | **35** |
| Varok | 31–51 | **0** | **70** |
| Arveth | 29–49 | **0** | **70** |

**PERGUNTA:** Dois ON5 semelhantes recebem a mesma descarga de forma semelhante? **HIPÓTESE refutável:** sim, se a defesa não deslocar os suportes para lados opostos da CD. **MÉTODO:** enumeração exata de todos os `4d6`. **RESULTADO VERIFICADO MATEMATICAMENTE:** salvaguarda é determinística nas quatro fichas citadas, dobrando o dano bruto médio para os que falham. **FALSIFICADOR:** mudança comprovada de Reflexo, CD, interpretação da salvaguarda ou modificação de defesa. **LIMITAÇÃO:** os alvos ainda podem possuir resistência específica a Planta; RD física não pode ser aplicada arbitrariamente à Planta. Não é um combate completo; defesa/luta não podem ser inferidas da classe ON5.

## D. Descoberta 2 — Orçamento de 804 PA e a probabilidade exata de incapacitação

Eristan tem **804 PA livres**, podendo pagar `⌊804/65⌋=12` descargas, restando 24 PA, se não tiver outros gastos ou regeneração.

Dessa fonte única e dos dois alvos legítimos calculei exatamente o efeito de 12 conjurações **contra um alvo passivo que permanece a até 25m e não opõe outras ações**, com danos não negativos e sem mitigação específica a Planta. Estes são **oráculos de capacidade energética**, não previsão de vitória em combate contra Varok ou Feryn atuando.

| Alvo | Vida alvo | Dano médio após 12 casts, antes de RD específica | P(HP retirado até cast 12) | E(casts até HP retirado) **se PA ilimitado** |
|---|---:|---:|---:|---:|
| Feryn, sempre salva | 479 | 420 | **0,000537% a 0,003679%** | **14,08–14,27** |
| Varok, sempre falha | 734 | 840 | **99,992994%** | **10,99167** |

O intervalo para Feryn vem da divergência legítima de **arredondar metade para baixo ou para cima a cada cast** — ainda não aceitei uma convenção pela ausência de autoridade específica na amostra. Médias de 35 e 70 usam a magnitude exata antes do arredondamento. Medianas do tempo ilimitado são **14 casts para Feryn** e **11 casts para Varok**; o percentil 95 é **15** e **12** respectivamente.

**MÉTODO:** uma implementação enumerou exatamente as distribuições com inteiros e estados de sobrevivência; outra usou inclusão-exclusão de composições limitadas para `8d10` e convolução independente por polinômios. Ambas produziram as mesmas frações racionais para as três caudas e tempos esperados. Simulação Monte Carlo seria menos precisa para um evento tão raro: não foi usada nem alegada.

**DESCObERTA:** a capacidade de 12 casts permite expectativa de incapacitação em um alvo mas não no outro, apesar de ambos serem ON5, sem mudar a magia. **LIMITAÇÕES:** resistência Planta, Reflexões, terreno, distância, turno do inimigo, cura, custos adicionais, exaustão espiritual e arredondamento final ainda podem alterar ou bloquear o resultado. Se houver resistência adicional, os valores de P(incapacitação) calculados **antes dessa resistência** constituem limites otimistas, não números oficiais de vitória.

## E. Descoberta 3 — Fronteira de precisão entre Iskiel e Feryn ON5

[Sikong Iskiel](https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966): arma **realmente equipada** no snapshot de encontro, ataque `4d6+101`, dano `9d8+47` **Vento/perfurante**, CA132, Esquiva134, RD física25, Iniciativa `4d6+89`. [Feryn](https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31): ataque equipado `4d6+92`, CA123, Esquiva125, RD física22, Iniciativa `4d6+82`.

- **Iskiel→Feryn CA123:** 5 das **1.296** combinações do `4d6` atingem **comumente**; `P(normal | sem verificação crítica)=5/1296=0,385802%`.
- **Iskiel→Feryn Esquiva125:** nenhuma combinação comum supera; depende de **crítico positivo 1/108** enquanto a defesa é legal e renovada.
- **Feryn→Iskiel CA132:** máximo de ataque comum 116; nenhuma combinação comum acerta; depende do crítico.
- **Iniciativa Iskiel vs Feryn:** Iskiel é estritamente primeiro em **90,9347%** das combinações, empate inicial em **2,9940%**; não atribuí automaticamente o vencedor dos empates (mecanismo R26 competente).

A análise de **dano** do arco Iskiel é condicional: sua expressão **Vento/perfurante** combina natureza elemental e física, e este estudo não certifica se a RD física22 é aplicada ao total ou só à fração física. No contrafactual em que uma única RD física22 abate todo o golpe, a esperança de dano Iskiel→Feryn é **1,52117 por tentativa** sem Esquiva, e **1,27315** com Esquiva. Não usar esses valores como cânone antes de fechar a mitigação competente. Para o corte físico Feryn→Iskiel sob RD física25, a expectativa pela via crítica isolada é **1,12963 por tentativa**, em modelo LAB R42 para falha crítica negativa; crítico positivo segue decisão do Mestre.

**CONSEQUÊNCIA:** o patamar ON5 sozinho não determina taxa de acertos; duas fichas de mesmo rank podem ser críticas-dependentes, e a iniciativa não elimina a fronteira de precisão. Não medir equilíbrio populacional por duas fichas de encontro propostas.

## F. Descoberta 4 — Ataque que acerta não necessariamente causa Vida

Cabra B1: Investida com Luta+6 **somente no teste de acerto** e dano normal `1d6+FOR13`. Crítico positivo válido usa dano `1d6+13+6 = 20..25`, não `1d6+13+6 da Luta+6 crítico` (o bônus da perícia não é bônus do dano). Contra o conjunto ON5 equipado:

| Alvo | RD física | Fração dos críticos da Cabra que produzem Vida positiva |
|---|---:|---:|
| Feryn | 22 | **3/6 = 50%** (1, 2 ou 3 líquido) |
| Varok | 35 | **0/6** |
| Arveth | 30 | **0/6** |
| Iskiel | 25 | **0/6** |
| Eristan | 25 | **0/6** |

Contra esses cinco alvos, os ataques comuns da Cabra também não superam a CA publicada. Nos quatro últimos casos, a Investida isolada não apresenta transição de HP mesmo com crítico — isso NÃO demonstra que a Cabra não possui outra estratégia, item ou meio de interferência.

**FALSIFICADOR:** equipamento ativado, tipo de dano imune/bypass, estado de RD alterado ou bônus de dano legitimamente documentado. **INTERPRETAÇÃO:** a estrutura de ranks pode legitimamente produzir regiões de inacessibilidade ofensiva para técnicas antigas, que devem ser distinguidas de defeitos no RNG ou crítico.

## G. Descoberta 5 — A economia por versão e o DoT não podem ser colapsados em uma única média

A coorte de 15 páginas, congelada em `PRE_REGISTERED_COHORT.json` antes da leitura dos corpos, recuperou famílias históricas com conflitos de variante:

**Ataque Frio Eterno** (Chen Yi-Min, fontes [v1](https://app.notion.com/p/57cc2b324ede82a791e381d9359fcb6a), [v2](https://app.notion.com/p/c28c2b324ede821997dd819b167c070b), [v3](https://app.notion.com/p/a9ec2b324ede82a5a0170114791bdf60)):

| Variante | Dano extra literal | DME intrínseco | PA espada / besta | Observação |
|---|---|---:|---|---|
| v1 | 2d4 gelo | 5 | 4 / 10 | 15% gatilho congelamento, depois salvaguarda e DoT condicionado |
| v2 | 2d8+2 gelo | 11 | 9 / 15 | 20% gatilho congelamento, ainda exige salvaguarda |
| v3 cabeçalho | **4d8+8** | **26** | 20 / 30 | NÃO CONCILIA com corpo |
| v3 corpo | **2d8+2** | **11** | 20 / 30 | NÃO CONCILIA com cabeçalho |

**Coluna de Gelo** ([v2](https://app.notion.com/p/091c2b324ede821cb4c8815dbc7f37cb), [v3](https://app.notion.com/p/bd4c2b324ede826ba2ad01d4d33903c7)):

| Variante | Dano/tick | DME/tick | PA | Limitação |
|---|---|---:|---:|---|
| v2 cabeçalho | 3d6 | 10,5 | 12 | conflito com corpo |
| v2 corpo | 2d6 | 7 | 11 | conflito com cabeçalho |
| v3 | 6d6 | 21 | 11 | exige imobilização e ausência de resistência gelo; duração desconhecida |

Essas expressões **não são cinco habilidades independentes**; são ocorrências/versionamentos de **duas famílias**. Não interpretei v3 como correção oficial de v2 sem cadeia de autoridade. O erro v3 Frio equivale a selecionar DME26 ou DME11, uma diferença de **2,3636×** no numerador do dano por uso, sem variar seus 20/30 PA — distorção documental grave para qualquer auditoria automática de eficiência.

Novos exemplos de tipos:

- [Adaga da Serpente Enfeitiçada (ON)](https://app.notion.com/p/3edc2b324ede811787a0de913622b14d): `5d4+5d8+10` DME bruto45, e `3d12` veneno/tick DME19,5 somente após falha de salvaguarda Constituição CD25; 35 PA. **Duração/portador e chances de ataque não verificadas.**
- [Sangramento — aprimoramento legado](https://app.notion.com/p/7d9c2b324ede83698dc381e76c958649): 1d6 necrótico por ferimento/tick, resistência Constituição CD25 depois do tick ou ação de Medicina. Com probabilidade de cura por resistência `p>0` constante e independente, expectativa condicional `3,5/p` de dano bruto por ferimento se não houver outra cura. Esse `p` NÃO foi preenchido por valor imaginado. **NECRÓTICO legado não foi convertido em DARK**.
- [M — Vendaval da Perdição](https://app.notion.com/p/d75c2b324ede825abd088110fb734d65): Prata, conjurar 15 PA e manter 5/turno; Ouro, conjurar 35 PA e manter 12/turno; área raio9m e conjuração de um turno. Bônus condicionais a aliados manipuladores de Vento/Dark `+2d6` e `+4d6` por dano elegível, sem inventar número de alvos ou ações.
- [ED — Correntes do Julgamento](https://app.notion.com/p/b1ac2b324ede834c8e3501a4ba341a52): condição após teste Reflexo/Fortitude falho, `4d12`/turno preso DME26, restaura metade do dano efetivamente recebido, 30 PA; DME por cena não calculável sem duração/saídas e arredondamento.

Além disso, em quatro folhas escolhidas por busca específica de patamares (duas Prata3, duas Ouro3), **três apresentaram discordância de classificação título/corpo**. Isso é 3/4 **na amostra dirigida**, não estimativa de prevalência do corpus. A Frígido Prata3 é variante da espécie já estudada; bônus Luta+6 de uma Rabada B5 anterior **não** foi generalizado para sua Rabada 2d4+FOR23.

## H. Redteam, auditoria e ciência negativa

**Método executor local:** `R12_R21_EXACT_MODEL.py`, enumeração exata de d6/d8/d10, função de massa de probabilidade e convolução inteira de 12 usos. `R12_R21_RESULTS_EXACT.json` preserva todas as frações e premissas.

**Método independente:** `R12_R21_INDEPENDENT_AUDIT.py` usa **inclusão-exclusão para composições limitadas** e **convolução de arrays**, sem importar a implementação executora. `R12_R21_INDEPENDENT_QA.json` concluiu **68 verificações locais** de resultados, consistência de arquivos e limites; não é segundo auditor humano.

**Falsificação adversarial:** `R12_R21_REDTEAM.py` gerou 12 alterações dirigidas em CLONES de vetores locais e recusou 12/12, incluindo falso Counter contra crítico, Counter aninhado, declaração retrospectiva, Luta do ataque incorretamente adicionada ao dano, crítico de magia, PA extra gratuito, falso consenso de versão, falsa cura de censura, segundo slot sem renovação e escolha silenciosa de rank em conflito. **Nenhuma dessas mutações foi aplicada ao VLAB**, portanto não há alegação de 12 bugs nativos.

**Testes NEGATIVOS importantes:** não se certificou dano Planta pós-RD nem Vento/perfurante pós-RD; não foi possível calcular taxa geral de paralisação do Regalis; não se inferiu duração de congelamento/DoT; nenhuma amostra exploratória virou holdout; nenhuma PA diária de vínculo foi cobrada novamente por golpe; nada reclassificado como cânone por falta de regra específica.

## I. Matriz F0–F18 e denominadores

Fonte: [F0](https://app.notion.com/p/3f3c2b324ede815faee6f277392b0bb7), [DMG-QA-ACCEPT-01](https://app.notion.com/p/3f3c2b324ede815cb014dc6294f40170), [DMG-TAX-DATA-01](https://app.notion.com/p/3f3c2b324ede81609a28e18c11d3cae4) e [DMG-METHOD-EMP-01](https://app.notion.com/p/3f3c2b324ede81ab8d8ec1c7cce760b3).

- **F0 4/8 MARCOS DOCUMENTAIS:** SEM NOVO ACEITE. As fontes originais enumeram requisitos/faltas mas não listam claramente todos os IDs individuais dos quatro marcados PASS. Este estudo acrescenta 15 IDs e datas, crosswalk de clusters e cálculo reprodutível, mas NÃO tem fingerprints integrais para a população, mapa exaustivo de raízes, holdout realmente cego, dupla codificação humana nem autoridade de writer para aprovação.
- **F1–F3:** nova amostra física 15/15 selecionadas; agrupamento de 11 clusters, **não** 11 famílias novas provadas. Adaga/Frio/Coluna/DoT/área, novos NPCs e quatro folhas de Bestas.
- **F4–F6:** extrações e conflitos com bloqueios explícitos; nenhum conflito resolvido por rank/corpo automaticamente.
- **F7–F8:** novos benchmarks OFFICIAL-SOURCE-EXPLORATORY para Reflexo CD76 e eficácia energética; NÃO existe distribuição representativa por rank.
- **F9–F12:** novos oráculos comparativos e checks metamórficos com classes de defesa/mitigação distintas; nenhum novo full-fight VLAB foi executado pela DMG.
- **F13–F18:** não existe candidata DMG v2, regressão global ou playtest humano; revisão/Mestre/migração NÃO acionadas.
- **Lote003:** **0/71** unidades individualmente autenticadas; a amostra atual não preenche automaticamente nenhum desses 71 IDs históricos.
- **VLAB:** 0/17 contratos terminais, 0/1.875 células canônicas pelo último registro da operação. Arquivos anteriores/nova coorte/contratos não somados como cenas de combate.
- **Conflito de autorias:** DMG preparou arquivo read-only para o VLAB; entrega/recebimento e execução NO VLAB = NÃO VERIFICADOS.

## J. Handoff incremental VLAB (NÃO EXECUTADO)

`R12_R21_VLAB_HANDOFF_READONLY.json` não altera o contrato antigo da R10 e contém vetores de testes R50/R51, Eristan CD76 contra Feryn/Varok, Iskiel ataque limítrofe e crítico da Cabra contra RD25, com autoria por fonte e condições pendentes. As prioridades para o executor autônomo do VLAB são **regressão causal R50/R51 em NOVOS bancos/IDs**, controle de custos+Salvaguarda de uma descarga completa e mitigação mista Vento/perfurante apenas se houver autoridade. Não reiniciar R47–R49, nem rodar novo combate para demonstrar fato já provado por repetição.

Nenhuma janela tem `NATIVE_READY` integral e automático só porque a matemática fechou: ação, alcance, resistências, política de reação, RNG, checkpoint, evento, revisão mecânica independente e NAC devem fechar o contrato competente.

## K. Estado ANTES / DEPOIS, checkpoint e retomada

| Denominador | ANTES C11 | DEPOIS R21 |
|---|---|---|
| Etapas desta ordem | 0/10 | **10/10 tentadas, executadas dentro do escopo cientificamente admissível** |
| Fontes dirigidas reabertas nesta ordem | 0 | **15/15 páginas** |
| Clusters documentais nessa coorte | — | **11 agrupamentos locais** |
| F0 | **4/8** | **4/8**, sem aceite indevido |
| Lote003 individual autenticado | **0/71** | **0/71** |
| Full fights VLAB históricos reconhecidos até R40 | **18** | **18** (não somar subcenas R41–R49) |
| Contratos terminais | **0/17** | **0/17** |
| Células canônicas | **0/1875** | **0/1875** |
| Novo combate do VLAB executado pela DMG | **0** | **0** |
| Alteração Notion/Party/O Primeiro/campanha/regra/motor | **0** | **0** |
| NAC-PASS produtivo | **HOLD** | **HOLD** |

**PRIMEIRA FRONTEIRA PENDENTE E MATERIALMENTE IDENTIFICADA:** fechar o tratamento fonte autorizado de **mitigação de dano misto Vento/perfurante** e resistência específica Planta/termos de arredondamento da metade; antes de pedir nova regra, buscar o contrato competente em Sistema de Magia, Criação de Ficha, item e decisão Mestre existentes. Isso permitiria transformar os limites aqui calculados em oráculos pós-mitigação mais fortes. Em frente paralela independente, obter no VLAB prova **nativa e auditada** de R50/R51; sem reivindicar writer nem usar o mesmo ID de R47/R48.

**PONTO EXATO DE RETOMADA:** ler manifesto `R12_R21_CHECKPOINT_SHA256.json`, script modelo, QA independente e ledger congelado; reabrir fontes com ID e last-edit para detectar alteração; não repetir a coorte de 15 nem os pacotes antigos. Reconciliar novos registros VLAB posteriores a R51 se surgirem. Emite próxima operação científica local da **MESMA** OP-DMG-CORPUS-EMP-01, sem nova operação paralela.

**NAC-PASS local científico:** modelos PASS após readback e auditoria numérica; **NAC-PASS PRODUTIVO / NORMATIVO HOLD**, pois faltam writer/lease, certificação de fonte completa, revisão normativa e contratos terminais. Nenhuma hipótese foi promovida à regra oficial DMG-RANK-01 v1.1.
