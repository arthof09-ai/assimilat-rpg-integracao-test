#!/usr/bin/env python3
"""MESTRE-SIDE TEST/READ-ONLY. Does not execute combat or alter any canonical source.
Source: byte-authenticated historical DMG_REALINHAMENTO_SISTEMICO...zip R03/R04;
spotcheck current Notion source pages documented separately in PROVENANCE.json.
Questions: conditional P(net>0), exact E[net] under hypothetical scalar RD,
paired rank crossover and source-specific cost limits. Source rank conflicts retained.
"""
import zipfile,csv,io,collections,itertools,json,re,hashlib,statistics
from fractions import Fraction
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ZIP=Path('/mnt/data/dmg_succession/historical/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip')
ZSHA=hashlib.sha256(ZIP.read_bytes()).hexdigest()
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None
 dat={p:list(csv.DictReader(io.StringIO(z.read(p).decode('utf-8-sig')))) for p in ['readonly_sources/R03_INITIAL_DAMAGE.csv','readonly_sources/R04_ALL_INITIAL_ACTIONS.csv']}
r03,r04=dat.values()
assert len(r03)==21 and len(r04)==29
new=[r for r in r04 if r['page_id'] not in {x['page_id'] for x in r03}]
assert len(new)==8

def mass(formula,attr):
 pairs=[(int(n),int(f)) for n,f in re.findall(r'(\d+)d(\d+)',formula.lower().replace(' ',''))]
 assert pairs and attr is not None
 base=int(attr or 0)
 m=collections.Counter({base:1})
 for n,f in pairs:
  for _ in range(n):
   nxt=collections.Counter()
   for k,c in m.items():
    for v in range(1,f+1):nxt[k+v]+=c
   m=nxt
 return m

def e_net(m,rd):return Fraction(sum(max(0,x-rd)*c for x,c in m.items()),sum(m.values()))
def p_pos(m,rd):return Fraction(sum(c for x,c in m.items() if x>rd),sum(m.values()))
def dec(f):return round(float(f),10)

rows=[]
for r in r04:
 m=mass(r['literal_formula'],r['attribute_value'])
 mu=Fraction(sum(x*c for x,c in m.items()),sum(m.values()))
 assert abs(float(mu)-float(r['gross_mean']))<1e-8
 var=sum(Fraction(c,sum(m.values()))*(x-mu)**2 for x,c in m.items())
 rows.append({'page_id':r['page_id'],'url':r['url'],'ability':r['name'],'formula_literal':r['literal_formula'],'attribute_code':r['attr_code'],'attribute_printed':r['attribute_value'] or None,'conditions':r['conditions'] or None,'cost_documented':r['cost_documented'] or None,'gross_expected':float(mu),'variance_gross':float(var),'support_min':min(m),'support_max':max(m),'original_r03':r['page_id'] in {x['page_id'] for x in r03},'rd31_net_expected':dec(e_net(m,31)),'rd31_p_positive':dec(p_pos(m,31)),'rd35_net_expected':dec(e_net(m,35)),'rd35_p_positive':dec(p_pos(m,35)),'pmf':{str(k):v for k,v in sorted(m.items())}})
with (ROOT/'R04_29_ACTIONS_NEW_EXACT_DISTRIBUTIONS.json').open('w',encoding='utf-8') as f:json.dump(rows,f,ensure_ascii=False,indent=2)

# Four targeted source-verified distinct pages; target comparisons are conditional on one scalar RD.
P={r['page_id']:r for r in rows}
targets=[('PAIR_A_R03_PRATA1_TRIPLE','206c2b324ede835383a1818a6edd5273','4bac2b324ede8321af6b01eb96452d04'),('PAIR_B_R04_PRATA1_TITLE_BODY','56ac2b324ede8352868101e11ea16355','5e4c2b324ede8282ad2c01c9363c3098')]
curves=[];target_reports=[]
for key,a,b in targets:
 x,y=P[a],P[b];ma=mass(x['formula_literal'],x['attribute_printed']);mb=mass(y['formula_literal'],y['attribute_printed']); mx=max(max(ma),max(mb))+1
 inversions=[]; crossings=[]; last=None
 for rd in range(mx+1):
  ex,ey=e_net(ma,rd),e_net(mb,rd);diff=ex-ey; s=(diff>0)-(diff<0)
  if last is not None and last!=s:crossings.append({'rd':rd,'sign':s})
  last=s
  # inversion relative gross expectation (first source gross larger)
  if x['gross_expected']>y['gross_expected'] and s<0:inversions.append(rd)
  curves.append({'pair':key,'rd':rd,'net_a':dec(ex),'net_b':dec(ey),'delta_a_minus_b':dec(diff),'p_positive_a':dec(p_pos(ma,rd)),'p_positive_b':dec(p_pos(mb,rd))})
 target_reports.append({'pair':key,'source_a':{k:x[k] for k in ('page_id','url','ability','formula_literal','attribute_printed','gross_expected','support_min','support_max')},'source_b':{k:y[k] for k in ('page_id','url','ability','formula_literal','attribute_printed','gross_expected','support_min','support_max')},'rd_range':[0,mx], 'strict_inversion_rds':inversions,'crossings':crossings,'rd31':[str(e_net(ma,31)),str(e_net(mb,31))],'rd35':[str(e_net(ma,35)),str(e_net(mb,35))],'p_positive_rd31':[str(p_pos(ma,31)),str(p_pos(mb,31))],'positive_probability_note':'Conditional on hit and scalar RD applicable; not hit chance, not combat, not class-reconciled admission'})
with (ROOT/'R03_R04_MATCHED_PAIR_RD_CURVES.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,curves[0].keys());w.writeheader();w.writerows(curves)

# Historical R03 source CSV rank claims, independence and class conflict preserved.
triple=[r for r in r03 if r['rank_triple_concordance'].lower()=='true'];groups=collections.defaultdict(list)
for r in triple:groups[r['rank_title']].append(r)
registry={'ZIP_baseline_sha256':ZSHA,'R03_records':len(r03),'R03_pages_unique':len(set(r['page_id'] for r in r03)),'R03_triple_concordance_count':len(triple),'R03_triple_groups':{k:{'effect_rows':len(v),'page_ids':sorted({r['page_id'] for r in v})} for k,v in groups.items()},'R04_records':len(r04),'R04_pages_unique':len(set(r['page_id'] for r in r04)),'R04_only_new_pages_v_R03':len(new),'R04_only_new_page_ids':sorted(r['page_id'] for r in new),'matchup_count':len(targets),'matching_page_ids_distinct':len(set(a for _,a,b in targets)|set(b for _,a,b in targets)),'pairs':target_reports,'notional_formal_status':'NOVO E VERIFICADO LOCALMENTE — independent mathematical recomputation; source Notion spotcheck target four pages; no double coder/production acceptance','limits':['Source pages are historical read-only, their title/body/ancestry may conflict','Cannot assume same RD applies to both attack types; conditional comparison only','Target pair B Prata 1 title/body but ancestors differ (Ouro 5, Ouro 2)','R03 original six concordant is archival claim; 2 primary sources reopened in Notion','Attribute support based on printed value, no transient buffs','Cost for 1d6+INT30 absent; 2d6+INT45 has PA5','No inferred hit chance, RD or combat outcomes']}
(ROOT/'R03_R04_COHORT_AND_PAIR_REPORT.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2),encoding='utf-8')

# Separate verification: brute enumeration independent of convolution's dynamic program.
checks=0
for key,a,b in targets:
 for id in (a,b):
  row=P[id];dice=[(int(n),int(f)) for n,f in re.findall(r'(\d+)d(\d+)',row['formula_literal'].lower().replace(' ',''))];faces=[range(1,f+1) for n,f in dice for _ in range(n)];base=int(row['attribute_printed'] or 0)
  enum=collections.Counter(base+sum(vs) for vs in itertools.product(*faces))
  assert enum==mass(row['formula_literal'],row['attribute_printed']);checks+=len(enum)
  for rd in range(max(enum)+2):
   assert e_net(enum,rd)==e_net(mass(row['formula_literal'],row['attribute_printed']),rd)
   assert p_pos(enum,rd)==p_pos(mass(row['formula_literal'],row['attribute_printed']),rd)
   checks+=2
assert len(rows)==29
(ROOT/'R03_R04_NEW_AUDIT.json').write_text(json.dumps({'status':'PASS','independent_exact_comparison_checks':checks,'R03_21_R04_29_PMF_checks':29,'matchups':len(targets),'gross_and_pmf': 'discrete convolution vs Cartesian brute outcomes, exact rational equality','source_zip_sha256':ZSHA},indent=2))
print(json.dumps({'audit':checks,'pairs':target_reports,'cohort':{k:registry[k] for k in ['R03_records','R03_pages_unique','R03_triple_concordance_count','R03_triple_groups','R04_records','R04_pages_unique','R04_only_new_pages_v_R03']}},ensure_ascii=False,indent=2))
