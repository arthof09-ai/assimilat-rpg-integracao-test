# PSV CORRETIVO — OP-DMG-CORPUS-EMP-01 — 16/10/2026 — MESTRE-SIDE

## Identidade e proteção
- `OPERATION`: OP-DMG-CORPUS-EMP-01; identidade histórica `CM-000001 / DMG`, sem herança de INSTANCE-ID.
- `BASELINE`: DMG-RANK-01 v1.1 OFICIAL/INALTERADA.
- `AS-OF`: 2026-10-16; `PREDECESSOR-LAST-VERIFIED`: DMG-F0-CIENCIA-P0-20261016, 81.017 bytes, SHA256 397cd335096270ee180b834abb2074b84de68909821ffd6192cac8653fdc6a62.
- `SUCCESSOR-LAST-VERIFIED`: prévia entrega local de 16.194 bytes, agora armazenada e fisicamente reaberta da mesma pasta Biblioteca; novo A6 239 registros de URL/ID; novas curvas exatas R03/R04.
- `AUTHORITY/WRITER STATE`: NO-ASSUMPTION; no Assignment/INSTANCE-ID/lease/epoch/fence/writer comprovados nesta instância; Notion OP, Diário, páginas canônicas, fichas, Party, O Primeiro e VLAB não editados.

## Prioridade 1 — persistência do ZIP sucessor já produzido
- Destino EXISTENTE: `/Comestre/OP-DMG-CORPUS-EMP-01/DMG_SUCESSAO_P0_CIENCIA_DELTA_20261016_MESTRE_ONLY.zip`.
- File ID da Biblioteca: `file_00000000e864820eadc865b6057fbbe8`, Library ID `libfile_7f389b776e04819184b278651c7b2b20`.
- Tamanho 16194 bytes; SHA256 `f7a2e12f3133a6df3a639d74a869f11c4d50488d13b0cfce44f9eba40171fc11`.
- Fonte local e cópia rematerializada comparadas byte a byte: PASS; 7 membros ZIP, CRC PASS, manifesto 6/6 PASS. A persistência não é certificação F0 documental.

## Prioridade 2 — RD da sucessão anterior (NO-REPEAT)
- Oito pares são oito comparações derivadas de seis UUIDs de páginas da matriz recuperada; Coordenação relata cinco páginas, divergência de identidade não adjudicada.
- Varredura anterior: 380 avaliações `RD=0,...,max_dano` mais oito sentinelas `max_dano+1` (uma por par), total **388**.
- Escorpião RD31 continua descoberta histórica, não reportada como nova.

## Prioridade 3 — A6 mapa de identidades: prova parcial, não 571 final
- A6 `ANTES`: 332 links diretos distintos preservados no CSV de Inbox Mestre IBX-102 sem bytes disponíveis para esta instância; 239 filhos de 12 ramos declarados no checkpoint P0; união 571 relatada sem arquivo integral de 571 IDs.
- A6 `DEPOIS`: 12/12 ramos Mestre efetivamente reabertos; 239/239 identificadores diretos extraídos em CSV físico da instância; 239 distintos, zero duplicatas exatas entre ramos. Validação independente de fingerprints FNV-1a/contagens nos 12 ramos (ver certificado e script). Inclui ID, URL, ramo, ancestral, profundidade, acesso ao **índice de origem** e data Notion de edição do índice; identidade de fonte, habilidade e espelho não foram inventadas.
- A comparação com os 332 IDs originais continua **PENDENTE**: anexo específico `DMG_F0_A6_DIRECT_CHILD_IDS_8_ROOTS_20261016.csv` está efetivamente na Inbox; Signed URL resolvida e temporariamente copiada, mas download de bytes ainda devolve `{}`. Rescanner dos oito índices NÃO executado. A prova de união e zero-interseção de 571 do antecessor permanece RELATADA. D0 global NÃO DETERMINÁVEL.
- Relação por ramo: Água 40, Gelo 25, Vento 10, Fogo 24, Raio 17, Dark 26, Caos 14, Planta 28, Luz 12, Terra 32, Normal 10, Espectro 1 = 239.

## Prioridade 4 — A5 autenticidade e bloqueio concreto
- A5 `ANTES`: sete anexos Markdown UTF8 na mesma Inbox, sete fingerprints históricos, zero readbacks de bytes após upload.
- A5 `DEPOIS`: oito stable Notion attachment refs reabertas, oito Signed URLs resolvidas. Rota técnica diferente experimentada: transferir CSV original de 332 via URL assinado usando integração `create_attachment(source_url)` → upload temporário `status=uploaded` (44534 bytes); `download_attachment` do próprio novo upload devolveu `{}`. Essa rota não certificou um único byte; arquivos originais A5 permanecem 0/7 readbacks. Nenhuma nova captura UTF8 materializada foi simulada. Classificação **BLOCKER-VERIFICADO para critério de bytes originais**, PARTIAL documental para links/metadata; cópia temporária não é readback de conteúdo.
- Condição mínima: obter bytes originais por ferramenta aprovada ou capturas *atuais* integralmente materializadas com UTF8/metadata/hash/readback próprio; não confundir com anexos históricos de 07/10.

## Prioridade 5 — A7/A8
- A7 oito candidaturas reservadas, zero independência cega certificada. Nada neste pacote publica IDs das reservas ou constitui revisão independente.
- A8 writer/lease/epoch/assignment não provados. Inbox/ACK não assumidos; instância de DMG não herda identificação do Coordenador.
- F0 formal **4/8 ANTES → 4/8 DEPOIS**, nenhuma homologação nova. F1–F12 podem receber análise exploratória sem alegar conclusão terminal.

## Ciência NOVA E VERIFICADA nesta instância
- Recuperado fisicamente o ZIP histórico `DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip` (SHA256 `ba871e3c1103958ca0f5f241033e839054e050f7e34eed4890b2774c0a1f89b3`); contém `R03_INITIAL_DAMAGE.csv` (21 ações / 18 páginas) e `R04_ALL_INITIAL_ACTIONS.csv` (29 ações / 26 páginas, oito IDs não presentes no R03). Não recontar tais páginas como novas observações históricas inéditas.
- Criadas NOVAS distribuições exatas de 29 fórmulas e duas comparações RD de quatro páginas-fonte Notion reabertas. `R03_R04_NEW_AUDIT.json`: **338/338 verificações aritméticas locais**, duas implementações: convolução vs produto cartesiano racional.
- Par A — Prata1 fontes distintas: Águia Arranha Céu, Raio Paralisante `1d4+INT30` gross 32,5 vs Lupusventus, Patada `2d6+FOR25` gross 32,0; sob RD31 escalar, pós-RD 1,5 vs 14/9≈1,556; Ppositivo 3/4 vs 7/12. **RD31–36 inverte média pós-RD**. URLs Notion respectivas `https://app.notion.com/p/206c2b324ede835383a1818a6edd5273` e `https://app.notion.com/p/4bac2b324ede8321af6b01eb96452d04`.
- Par B — fontes rotuladas Prata1 mas ancestral divergente: Sussurro Celestial, Lâmina de Brisa `1d6+INT30` gross 33,5 vs Golem de Pedra `2d6+FOR26` gross 33; sob RD35 1/6 vs 5/18, inversão RD34–37. URLs `https://app.notion.com/p/56ac2b324ede8352868101e11ea16355` e `https://app.notion.com/p/5e4c2b324ede8282ad2c01c9363c3098`.
- Amostra direcionada não representa universal RPG; RD escalar TEST pode não ser aplicável a ambos tipos; efeitos adicionais de Fortitude, CA, saves, ação, PA ausente e crítico ficam fora; criaturas de mesma classificação não equivalem a ações independentes da população.
- Classe: **NOVO E VERIFICADO LOCALMENTE** como análise matemática de fontes antigas, não como dados brutos de combate novos, revisão cega ou norma oficial.
- VLAB R93/R95 critical adapter = HISTORICAL_REPLAY_PASS / NORMATIVE_HOLD. 212 recibos R116: 27.232 bruto, 7.958 mitigado, 19.274 potencial, 18.806 Vida, 468 overkill (preservados, não contados como ciência nova deste lote).
- DMG v1.1 aplicação genuína de fonte sem dano e RE/FIP/entrega íntegros: **0 certificadas**; provas de fórmula explícita e TEST não equivalem a fallback genuíno.

## Plano Supremo, critérios e ciência dirigida
- Matriz F0–F18 = **19 fases originais existentes**, não criada outra matriz normativa. F0 4/8, A6 avançou materialmente mas HOLD global. F1–F12 recebem curvas de RD e viés de classificação como subevidência exploratória, **zero fases terminais novas**. F13 candidato não autorizado; F14–F18 dependem dos gates e revisão Mestre.
- Evidência adicional apoia o critério de qualidade científico: medir simultaneamente DME bruto, distribuição pós-RD, `P(dano>0)` e magnitude condicional, por estratos/famílias; não é prova suficiente para alterar a banda DMG-RANK.

## Continuidade e interlocks
- `DENOMINATORS`: F0 4/8; A5 byte 0/7; A6 filhos ramo 239/239 documentados, 332 CSV existente não rematerializado, união alegada 571 NÃO CERTIFICADA; A7 0/8 independentes; A8 writer 0 certificados; ciência R03 21 ações/18 páginas, R04 29 ações/26 páginas, pares TEST2/4 páginas; auditor 338/338.
- `CONFLICTS`: Scorpion ancestral Diamante/corpo Ártico; cinco vs seis UUIDs no lote oito pares anterior; Ouro ancestrais divergentes em duas fontes R04; R93/R95 críticos históricos divergentes; versões 07/10 vs 09/10 de duas autoridades sem snapshots históricos integrais.
- `UNKNOWN-EFFECT`: zero nova escrita em página compartilhada ou em engine; cópia temporária Notion existe por resposta `status=uploaded`, não anexada nem contabilizada como leitura; não reivindicar byte readback nem efeito normativo. Histórico UNKNOWN-EFFECT anterior não foi reexecutado.
- `NO-REPEAT`: não reexecutar P0 1616, auditorias antigas 116/148, oito pares R02, 24 fontes R01, R91/R97, combates VLAB, raiz oito índices, nem clonar plano F0–F18.
- `NEXT-5`: 1) recuperar bytes do CSV 332 por interface autorizada **diferente das já bloqueadas** e unir sem duplicar; 2) com nova rota certificar sete bytes A5 ou snapshots atuais com readback; 3) submeter holdout/famílias ao segundo leitor independente e conciliar writer; 4) obter lote002/003 de origem autenticável, cruzar 26 páginas R04 sem dupla contagem, ampliar dano/atributo/PA por entidade; 5) selecionar fonte RE/FIP realmente sem fórmula, ou provar inelegibilidade caso a caso para aplicação genuína.
- `FIRST-PENDING`: A6 crosswalk 332 IDs originais indisponíveis em bytes, seguido por A5 7/7 readbacks.
- `TARGET-REMAINDER`: A5–A8 documentais, D0–D9, lotes físico/revisão, F1–F12 por gate; nenhum v2 ou migração sem Mestre/NAC-NORM/NAC-PASS.
- `NAC-PASS`: cálculos e pacote LOCAL PASS, produção/Notion/F0 formal **HOLD**.
