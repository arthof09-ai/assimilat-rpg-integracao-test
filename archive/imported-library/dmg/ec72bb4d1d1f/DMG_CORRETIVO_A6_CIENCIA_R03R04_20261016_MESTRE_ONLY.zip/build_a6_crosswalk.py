"""Materialize previously fetched 12 Beast branch direct-child UUIDs without refetching 8 root indexes.
The compact source preserves tokens taken from read-only Notion parent fetch output.
No attempt at defining creature identities/effects, global census, or exposing heldout.
"""
import csv,json,hashlib,collections
from pathlib import Path
O=Path(__file__).resolve().parent
I=O/'A6_BRANCH_RAW_COMPACT_20261016.txt'
counts_expected={'Água':40,'Gelo':25,'Vento':10,'Fogo':24,'Raio':17,'Dark':26,'Caos':14,'Planta':28,'Luz':12,'Terra':32,'Normal':10,'Espectro':1}
rows=[];parents={}
for line in I.read_text(encoding='utf-8').splitlines():
 name,parent,edited,shorts=line.split('|');ids=shorts.split(',');assert len(ids)==counts_expected[name]
 parents[name]={'uuid':parent,'url':'https://app.notion.com/p/'+parent,'edited_at':edited,'count':len(ids)}
 for s in ids:
  assert len(s)==24 and all(c in '0123456789abcdef' for c in s)
  uid=s[:4]+'2b324ede'+s[4:]
  rows.append({'uuid':uid,'url':'https://app.notion.com/p/'+uid,'source_branch':name,'source_branch_uuid':parent,'ancestor_uuid':parent,'depth':2,'evidence_of_access':'READ_ONLY_PARENT_FETCH_DIRECT_PAGE_LINK','direct_target_read':'NOT_ASSERTED','possible_mirror_or_duplicate':'UNKNOWN_NON_UUID_MIRRORS','source_status':'STRUCTURAL_REFERENCE_ONLY_NOT_OFFENSIVE_CLASSIFIED','parent_last_edited_at':edited,'reference_snapshot_as_of':'2026-10-16','scope':'MESTRE_SNAPSHOT_TWO_DEPTHS','root_index_identity':'Bestas Demoníacas','version':'SOURCE_PARENT_FETCH_CURRENT_RENDERED_NOTION'})
assert len(rows)==239 and len({r['uuid'] for r in rows})==239
assert len(set(r['source_branch_uuid'] for r in rows))==12
R=O/'A6_239_BEAST_BRANCH_CHILD_IDENTITIES_VERIFIED.csv'
with R.open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
M={'OPERATION':'OP-DMG-CORPUS-EMP-01','AS_OF':'2026-10-16','BASELINE':'DMG-RANK-01 v1.1 unaltered','cohort':'second depth under twelve Beast branches','branches':parents,'materialized_rows':239,'distinct_UUIDs':239,'cross_branch_same_UUID':0,'root_332':'Attachment exists in Notion IBX-102 DMG_F0_A6_DIRECT_CHILD_IDS_8_ROOTS_20261016.csv but original bytes not downloadable; not materialized in this cycle','two_depth_union_571':'RELATADO in P0 and Coordinator, not independently recomputed from 571 line items here','intersection_root_vs_branches':'P0 reported zero; current proof is missing 332-row byte baseline','global_D0':'UNDETERMINED','not_239_creatures':'structural pages linked from branch indexes, species and offensive effects not opened individually','holdout':'Not accessed; all pages are link metadata only','source_file_sha256':hashlib.sha256(I.read_bytes()).hexdigest(),'crosswalk_csv_sha256':hashlib.sha256(R.read_bytes()).hexdigest()}
(O/'A6_SCOPE_CERTIFICATE_PARTIAL.json').write_text(json.dumps(M,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'rows':239,'branch_counts':counts_expected,'distinct':239,'csv_sha256':M['crosswalk_csv_sha256']},ensure_ascii=False))
