#!/usr/bin/env python3
"""Deterministic Mestre-only scientific PSV and decision memo based on C27 CSV/JSON assets."""
from pathlib import Path
import json,csv
P=Path(__file__).resolve().parent/'publication'
J=json.loads((P/'C27_DENOMINATORS_STATE.json').read_text())
def rows(f):
 with (P/f).open(encoding='utf-8',newline='') as q:return list(csv.DictReader(q))
E=rows('C27_G1_20_NUMERIC_EFFECT_CANDIDATES.csv')
R=rows('C27_20_CONDITIONAL_REAL_RDF_SCENARIOS.csv')
G=rows('C27_G0_G14_QUALITY_GATE_DELTA.csv')
H=rows('C27_5_HYPOTHESES_FALSIFIABLE.csv')
assert (len(E),len(R),len(H),len(G))==(20,20,5,15)
def link(id):return 'https://app.notion.com/p/'+id
text='''# PSV DMG C27 — Fechamento estrutural G1, taxonomia de efeito e resistência física condicional

**Operação preexistente:** `OP-DMG-CORPUS-EMP-01`  
**Ciclo:** C27 · 21/10/2026 · MESTRE-SIDE / LABORATÓRIO TEST  
**Baseline:** C26 autenticado, `DMG-RANK-01 v1.1` INALTERADA  
**Produção:** HOLD · **Party e O Primeiro:** NO-WRITE · **NAC-PASS global:** HOLD  
**Status:** ACEITE TÉCNICO LOCAL DO C27, NÃO ACEITE NORMATIVO F0/F18.

## 1. Sumário científico com limitações explícitas

No universo *estrutural* G1 de 411 Page-IDs, C22–C26 haviam examinado cumulativamente 345; o C27 calculou a diferença de conjuntos e reabriu no Notion Mestre todos os 66 Page-IDs restantes. A operação agora tem **411/411 IDs estruturalmente cobertos**, sem extrapolar essa contagem ao universo de magias, itens, técnicas, inscrições, invocações ou ao restante do RPG.

Os 66 registros C27 foram decididos em nível de página: **14** com pelo menos um efeito numérico candidato, **49** sem expressão ofensiva numérica utilizável e **3** com corpo vazio. Os 14 produziram **20 ocorrências candidatas** e **21 termos de dados**. Uma ocorrência (*Poder elemental*, macaco rei `1d10+INT`, custo 10 PA) não identifica expressamente dano/Alma/Vida e permanece `EFFECT_TARGET_AMBIGUOUS`; as outras 19 são candidatas de ataque, efeito ofensivo ou magia concedida, sem prova suficiente para equivalência de entrega.

**Qualificação fundamental:** os 345 IDs anteriores são lastreados nos pacotes aceitos C22–C26, NÃO foram reabertos pela segunda vez nesta campanha; o arquivo C27 preserva a lista desses Page-IDs e sua proveniência. A codificação das 66 novas fontes foi feita pelo mesmo executor, portanto a reexecução matemática ou o readback de Biblioteca **não é revisão documental independente por outro codificador**. Tampouco há prova do hash dos bytes de 66 anexos originais do Notion; o registro é da leitura do conteúdo retornado.

**Resultados decisórios:** a taxonomia por Page-ID é indispensável para separar aliases, bônus de atributo, dados de drops, efeitos em área e recursos. Nenhuma instância nova apresentou RE/FIP de efeito individual certificado (**0/20**), logo as bandas da norma **não foram validadas nem refutadas**. C27 conclui descoberta estrutural G1 sem avançar automaticamente F0: **4/8 — HOLD**.

## 2. Protocolo de seleção, cronologia e integridade da cobertura

1. Reaberto o manifesto G1 no Notion Mestre (`{manifest}`).
2. Reconciliados 256 IDs C22–C25 e 89 IDs C26, formando 345 IDs anteriores únicos. A identidade usada é Page-ID integral; prefixos só auxiliam transcrição e não são chaves canônicas.
3. Pré-selecionados os 66 restantes pela diferença de conjuntos ANTES da leitura dos seus efeitos, sem restrição posterior de relevância. Todos foram efetivamente solicitados ao Notion.
4. Duplicações entre ciclos: **0**. Cobertura resultante: **345 + 66 = 411**. O denominador G1 e as 66 linhas estão nos artefatos `C27_G1_66_SOURCE_REGISTER.csv` e no baseline C26.
5. Em cada página: verificar corpo, nome interno, rank expresso, fórmulas literais, separação de dado de drop versus efeito, recurso-alvo, modificadores externos e lacunas de RE/FIP. Datas de edição conferidas nesta coorte apontam para 01/10/2026.

Este recorte é o **complemento final determinístico**, não uma amostra aleatória nem holdout independente. Um mesmo texto-modelo em várias páginas não produz réplicas científicas independentes.

## 3. Catálogo numérico novo

Preservamos a formulação literal de cada ataque, o número de termos e o contexto. DME intrínseco inclui só dados e eventuais constantes pertencentes à expressão, **não** FOR/INT/DES da criatura.

| Página / entidade | Efeito literal | DME intrínseco | Média bruta por acerto sob atributo da ficha | Observação crítica |
|---|---|---:|---:|---|
'''.format(manifest=link('3f0c2b324ede8196b704dc8e04b94fe5'))
for e in E:
 gross='**PENDENTE**' if e['gross_mean_conditioned_on_attr']=='' else str(e['gross_mean_conditioned_on_attr'])
 flag='ALVO INCERTO' if e['classification']=='EFFECT_TARGET_AMBIGUOUS' else 'ATRIBUTO DUPLO' if e['classification']=='LITERAL_ATTACK_WITH_AMBIGUOUS_ATTRIBUTE' else 'GROSS CONDICIONAL' if e['classification']=='LITERAL_ATTACK_WITH_EXTERNAL_BONUS_QUESTION' else 'CANDIDATO'
 text+=f"| {e['owner']} ([fonte]({e['source_url']})) | `{e['ability']}: {e['raw_formula']}` | {e['DME_intrinsic']} | {gross} | {flag} |\n"
text+='''
### Dicionário de inferências proibidas

- `Rank: Bronze 1 (1d6)` pode registrar chassi/rank; não gera automaticamente um ataque adicional `1d6`.
- Dado em *drop* / ingrediente / rendimento de material não é ataque da Besta.
- `Poder elemental: 1d10+INT, 10 PA` tem expressão e PA, **mas o texto não identifica explicitamente recurso ou dano**; não foi convertido em dano certificado à Vida.
- `Raio de Putrificação 2d6+INT` da Peste Negra e `+1d4 em ataques/magias Dark` são *efeito e modificador* distintos; o +1d4 não é segunda magia.
- Dano bruto com atributo é útil como benchmark contextual, mas o DME **intrínseco** normativo não inclui FOR/DES/INT.
- As anotações em fichas de criaturas não estabelecem custo, chance de acerto, duração, alvos, reflexões, gatilhos ou redução em resistência sem fonte competente.

## 4. Descobertas forenses — correções e não equivalências

### 4.1 Dois Escorpiões Árticos Bronze 5 — **verificado**

A estrutura G1 registra uma ficha na família Gelo (`{ice}`), e outra na família Terra (`{earth}`). Ambas dizem literalmente *escorpião Ártico*, Bronze 5, mas têm atributos e mecânicas diferentes:

| Medida | Página Gelo | Página Terra |
|---|---:|---:|
| FOR | 8 | 22 |
| DES | 24 | 25 |
| Rabada | `1d4+DES` | `1d6+1d4+FOR` |
| Média bruta Rabada | 26,5 | 28 |
| Corte | `1d6+FOR` | `1d6+DES` |
| Média bruta Corte | 11,5 | 28,5 |

**Conclusão:** nome e rank iguais não bastam para unir as fichas nem atribuir progressão. **PENDENTE** saber se é duplicata incorreta, variante válida ou entrada de família equivocada. Não alterar as duas originais.

### 4.2 Croctus Sombrio — campo ambíguo **verificado**

A ficha `{croctus}` contém literalmente `Força: 39 19`, `Constituição: 30 15`, `Vida: 840 420` e `Mordida Infectada: 2d6+FOR CD 6+CON`. Sem rótulo que identifique cada coluna, o dano médio intrínseco da Mordida é **7**, mas a média bruta pode ser **46** usando FOR39 ou **26** usando FOR19. As duas são *cenários*, não escolha oficial. A CD igualmente permanece ambígua; a fórmula não pode virar registro unívoco.

### 4.3 Bônus possivelmente incorporados — **condição não resolvida**

- *Behemoth Selvagem* `{behemoth}`: FOR55, Investida `2d6+FOR`, *Força Titânica* `+5 FOR`. A média da Investida é 62 usando FOR55, **ou 67** somente se o +5 incidir adicionalmente e ainda não estiver embutido no atributo.
- *macaco rei* `{macaco}`: FOR54, Patada `2d6+FOR`, *Força Titânica* `+2 FOR`. Média 61 com o número impresso, ou 63 no cenário de modificador adicional.
- *Cerebrato* `{cerebrato}`: Peste Negra concede raio `2d6+INT21` e bônus `+1d4` para ataques/magias Dark. Média bruta 28 para o raio; **30,5 apenas no cenário** em que o bônus for pertinente e não estiver contabilizado. Não assumir acumulação reiterada.

### 4.4 Dano à Vida, controle, veneno e área são eixos separados

*Behemoth Selvagem*: Investida `2d6+FOR` e Sismo `6d6` não são ações comparáveis sem quantidade de alvos, ação e custo. O Sismo tem DME intrínseco por instância 21; não existe base para afirmar DPT garantido de um turno inteiro.

*Escamorte*: Espinhos Venenosos `2d6+DES35` são um ataque numérico com veneno narrativo; não foi registrado valor numérico do veneno.

*Felpudo*: Espinhos perfurantes `1d4+DES8`, e outra habilidade *Espinhos Venenosos* causa veneno por três rodadas com intervalo de três rodadas; **dano de cada tick não está documentado**. Sua duração não autoriza criar uma expressão para o veneno.

## 5. Benchmarks de resistência física real — 20 cenários, NÃO 20 combates

Quatro fichas Mestre foram reabertas como defensores: Rinolupo Prata 1 com RDF10 (`{rinolupo}`) e Guardião Pétreo Prata 3, Ouro 1 e Ouro 5 com RDF15/20/25 (`{p15}`, `{p20}`, `{p25}`).

Sob o contrato estritamente **condicional** *um ataque bem-sucedido, dano efetivamente físico e RDF subtraída de cada resultado individual*, calcular `E[max(0, dados + atributo + bônus intrínseco - RDF)]`. **Não** equiparar a `max(0, média bruta - RDF)`.

- **12 cenários com tipo físico explícito**, Macaco Patada impacto, Macaco Mordida perfurante e Galinha Patada cortante, cada um diante de 4 defensores.
- **8 cenários tipados por inferência**, os dois efeitos chamados `Corte` dos dois Escorpiões, diante dos mesmos 4 defensores. Não canonizar o tipo de dano apenas pelo nome.

| Atacante | RDF10 | RDF15 | RDF20 | RDF25 |
|---|---:|---:|---:|---:|
'''.format(ice=link('c28c2b324ede8217937c8165a19eafa9'),earth=link('92bc2b324ede834ca813812ff4783805'),croctus=link('8cdc2b324ede83aaaaeb01bbb7a6c452'),behemoth=link('1e9c2b324ede833db9f601eac58d7de4'),macaco=link('301c2b324ede828caccb813d3979267a'),cerebrato=link('00ac2b324ede831caf1e01e90e81df3b'),rinolupo=link('034c2b324ede83ffa7118144011beaf3'),p15=link('549c2b324ede8375b21181335038aad1'),p20=link('b0ec2b324ede835a927601b4cbd8fca6'),p25=link('371c2b324ede837fad4c01bbfe9a95fb'))
for eid,label in [('C27-E005','Macaco Patada (impacto explícito)'),('C27-E006','Macaco Mordida (perfurante explícito)'),('C27-E013','Galinha Patada (cortante explícito)'),('C27-E010','Escorpião Gelo Corte (inferido)'),('C27-E020','Escorpião Terra Corte (inferido)')]:
 rr=[x for x in R if x['effect_id']==eid]
 assert len(rr)==4,eid
 vals={int(x['documented_RDF']):float(x['per_hit_post_RDF_mean_decimal']) for x in rr}
 text+=f"| {label} | "+' | '.join(f'{vals[d]:.6g}' for d in (10,15,20,25))+' |\n'
text+='''
A Patada da galinha, `1d4+DES13`, possui média bruta 15,5. Contra RDF15, a média **exata** pós-resistência é `3/4 = 0,75`, enquanto a falsa aproximação `max(0, 15,5−15)` gera 0,5: **viés por truncamento à esquerda**. Com RDF20, 100% das faces geram 0, mas isso é somente uma previsão por acerto para aquele defensor e dano físico sob o contrato hipotetizado. Não foram simulados acerto, crítico, iniciativa, PA, custo de ação, turnos nem TTK.

## 6. Cinco hipóteses, refutação e incertezas

| Hipótese | Resultado | Motivo |
|---|---|---|
'''
for h in H:
 text+=f"| `{h['H']}` — {h['hypothesis']} | {h['verdict']} | {h['counterevidence']} |\n"
text+='''
**Análise estatística e viés:** as 20 ocorrências candidatas estão agrupadas em 14 páginas, não são 20 Bestas independentes e as 20 células RDF constituem cruzamento dos mesmos cinco ataques com quatro defensores. A coorte final não é aleatória. Não calcule taxas populacionais de dano ou rank do G1 ou do RPG a partir deste ciclo isolado. A revisão matemática com algoritmo distinto confirma as consequências da extração, não a fidelidade de cada transcrição original por outro pesquisador.

## 7. Gates e governança

| Gate | Estado | Prova/bloqueio |
|---|---|---|
'''
for g in G:text+=f"| {g['gate']} | {g['state']} | {g['evidence']} |\n"
text+='''
**F0–F18:** sem promoção formal. F0 continua **4/8 HOLD**; F1–F18 não recebem PASS por leitura de manifesto.  
**D0–D9/E01–E24:** nenhum fechamento normativo inferido ou antecipado.  
**A5 original:** **0/7 bytes originais autenticados**; A7/A8 HOLD.  
**Oito gates principais e Q-COVERAGE/Q-CODEBOOK/Q-MATH/Q-TARGET/Q-HOLDOUT/Q-REDTEAM/Q-TRACE:** progresso local de descoberta e matemática, sem PASS global nem revisão documental independente.  
**NAC-CONT-03, NAC-NORM-01, NAC-PASS-02:** todas as transições para produção/Party/O Primeiro bloqueadas.  
**Fonte de verdade persistente:** Notion Mestre, jamais o CSV derivado isolado. Nenhuma ficha original ou regra vigente foi alterada.

## 8. Decisões e recomendações priorizadas

1. **Prioridade P0 — Habilitar certificação RE/FIP:** recuperar e verificar habilidades/magias/técnicas/itens com patamar competente *do efeito* documentado. RN, RI ou estrela da criatura não satisfazem sozinho.
2. **P0 — Segunda codificação documental independente** da coorte de 14 páginas numéricas, preservando divergências, acordo por campo e adjudicação em fontes Notion.
3. **P1 — Resolver Croctus**, duas colunas numéricas sem rótulo, e origem dos bônus já embutidos em atributo em Behemoth/macaco. Não alterar fichas sem ordem do Mestre.
4. **P1 — Separar orçamento de Vida / Alma / PA / controle / veneno / área / bypass** antes de propor bandas ou ações por turno.
5. **P2 — Orientar benchmark defensivo** com tipos explícitos, mitigação por resultado, custos e ações, sem transformar células matemáticas em playtests.

## 9. Registro de continuidade, FIRST-PENDING, NO-REPEAT

**ANTES:** C26 com 345/411 páginas estruturais G1 documentadas; classificação RE/FIP individual ainda indisponível e F0 HOLD.  
**DEPOIS:** C27 com 411/411 IDs do manifesto G1, +66 páginas examinadas, +20 candidatos numéricos em 14 páginas, 100 testes matemáticos locais e 20 cenários condicionais RDF; sem autorização de escrita canônica nem progressão dos gates F0.  
**LAST-VERIFIED-UNIT:** C27 — leitura física das 66 fichas, 14 fontes com candidato numérico e defesa real RDF 10/15/20/25; reprodução matemática e verificação do ZIP à parte no recibo.  
**FIRST-PENDING:** primeira amostra *independentemente codificada* por outro pesquisador e pelo menos uma fonte com RE/FIP competente individual. Se essa independência não puder ser obtida, não simular uma segunda pessoa/algoritmo como pesquisador.  
**NO-REPEAT:** manter C22–C26 íntegros, não recatalogar 411 para inflar a cobertura.  
**NEXT-5:** fontes RE/FIP rastreáveis; revisão documental independente; reconciliação Croctus; fontes de custos/ação de Sismo/Poder Elemental; projeto de validação baseline×candidato pareada somente após autoridade e gate.
**TARGET-REMAINDER:** fontes fora do G1 para magias/técnicas/armas, recuperação dos sete snapshots originais de A5, preparação de fixtures reais e futura validação F0–F18 autorizada com o Mestre.

## 10. Arquivos, hashes e readback

Este PSV acompanha CSVs de fontes, fórmulas, controles, hipóteses, matrix de gates, método de reconstrução, código portátil de replay, manifesto SHA-256 e a baseline C26. Os hashes demonstram integridade do artefato, **não equivalência dos dados ao corpo do Notion por revisor independente**. Recibos finais de Biblioteca são separados e exigem download/materialização após o upload.
'''
(P/'PSV_DMG_C27_MESTRE_ONLY.md').write_text(text,encoding='utf-8')
memo='''# PARECER DECISÓRIO DMG C27 — MESTRE-SIDE

**Operação** `OP-DMG-CORPUS-EMP-01` — **Regra oficial** `DMG-RANK-01 v1.1` INALTERADA.

## Resultado

**G1 estrutural 411/411 Page-IDs examinado cumulativamente** (345 de C22–C26 + 66 lidos neste C27, sem interseção). Isso não é certificação do RPG completo. A coorte final: **14/66 páginas** com 20 candidatos numéricos (um alvo indefinido), 49 páginas sem fórmula ofensiva utilizável e 3 corpos vazios. **RE/FIP competente 0/20**.

**Novos diagnósticos:**

1. Mesmo nome e rank não definem criatura única: dois Escorpiões Árticos Bronze5 em famílias Gelo/Terra têm atributos e ataques diferentes.
2. Croctus Sombrio tem duas FOR/CON/Vida justapostas sem rótulo, deixando a Mordida como DME intrínseco7 e dano contextual NÃO RESOLVIDO.
3. Behemoth Selvagem (+5 FOR), macaco rei (+2 FOR) e Cerebrato (+1d4 Dark) mostram risco de aplicação duplicada de bônus.
4. Efeito `Poder elemental 1d10+INT, 10PA` não pode virar automaticamente dano à Vida.
5. **20 cenários pós-RDF** com defesas reais RDF10/15/20/25 (12 com tipo físico explícito; 8 inferidos). Galinha 1d4+DES13 vs RDF15: média exata 0,75, não 0,5 da fórmula de médias truncadas.

## Decisão

**RECOMENDO** preservar a DMG-RANK-01 v1.1, sem candidato v2, sem migração de fichas e sem alteração Party/O Primeiro. As bandas não foram empiricamente homologadas nem refutadas. O G1 deve sair da fila de expansão bruta e entrar em uma fase de certificação documental de efeitos, RE/FIP, ações, custos, alvos e tipos.

**PRÓXIMA QUESTÃO:** levantar fontes com RE/FIP individual competente e obter outro codificador físico das 14 páginas; reconciliar Croctus e bônus sem escrever no cânone.

**GOVERNANÇA:** F0 4/8 HOLD; A5 originais 0/7; A7/A8 HOLD; NAC-PASS global HOLD; laboratório TEST only; sem writer/canonização fictícia.

**EVIDÊNCIA:** pacote C27, manifestos e PSV completos, com readback de Biblioteca em recibo separado. Preservar C22–C26.
'''
(P/'C27_PARECER_DECISORIO_MESTRE_ONLY.md').write_text(memo,encoding='utf-8')
print('PSV bytes',len(text.encode()),'memo bytes',len(memo.encode()))
