#!/usr/bin/env python3
"""C27 internal scientific data reconstruction from direct Notion readbacks of 66 unique G1 pages.
This is a manual, executor-controlled documentary coding and arithmetic test, NOT independent documental audit.
Keeps raw attack expressions and identity fields separate. No modification to canonical sources.
"""
import csv,json,re,hashlib,collections,math
from pathlib import Path
from fractions import Fraction
R=Path(__file__).resolve().parent
P=R/'publication';P.mkdir(exist_ok=True)
# Freeze selection by exact canonical Notion Page-ID, derived as complement of C22-C26 against G1 manifest.
IDS='''842c2b324ede83f7bd9081aaf2a23e2e ae5c2b324ede838bbb9681e1977fc324 e56c2b324ede82cabbeb016441a0bc2a a4bc2b324ede8398a9398132bde05f31 f86c2b324ede839d83078151c8c9b238 8cdc2b324ede83aaaaeb01bbb7a6c452 70ac2b324ede8365ad1f81951c87d9eb 76dc2b324ede82f2bf4e0181da034812 517c2b324ede827489fc81ece2f64c92 a53c2b324ede830ab253016d7a9fea23 eafc2b324ede83c6a5da81ff46fb10ba 65ec2b324ede834b98268172f600a685 474c2b324ede82d08ea6819069c17043 cd7c2b324ede822f89e9015f9812673d fc0c2b324ede829c8df481fad592e285 301c2b324ede828caccb813d3979267a af1c2b324ede8269a7a5812349149aa9 266c2b324ede8327b4e98197278f602b 102c2b324ede83da9f3381d817425372 d68c2b324ede8331a59e81ba69df564b c28c2b324ede8217937c8165a19eafa9 c00c2b324ede8303815881275b2e2993 3bfc2b324ede82a295c8018c35d148a5 60ac2b324ede836398360185ce7cd852 53fc2b324ede833eba54017dbed7918e 56fc2b324ede82d6ab3e01249ff73c2d d69c2b324ede83a8839501e4d1c29dfc 7eac2b324ede8246bb3b810b4e8a5d9e ea5c2b324ede83ad9c03819fca3ef1fe 86ac2b324ede8210915f01f9442719f8 966c2b324ede83d7962b019b1861b6b1 eddc2b324ede829f8a75011e8acbf429 00ac2b324ede831caf1e01e90e81df3b 6dec2b324ede827c9bdb81846765531e 9bfc2b324ede834abefc01308b5f0df9 ed3c2b324ede82babb998175ed0382ca 328c2b324ede8238a19281a98c40b91d 6bac2b324ede820286e5818114426958 ae5c2b324ede82cd989e8125970f2c4a 7e5c2b324ede830a8fcb81fa0b19eddb df7c2b324ede83d790410150a5f6d492 b5ac2b324ede836b87a20106e3d7c0f3 6bec2b324ede8261af8b8185b07ad9b0 40ec2b324ede825990c2014b4ef594cb 95cc2b324ede82cabae401bc73662386 759c2b324ede837eb82c81104da7721e 82bc2b324ede8359882801cd01eceb76 319c2b324ede82a0b5c481d073179889 8cac2b324ede835699f5017d7fd5467b 617c2b324ede825f8045813ebef49806 5eec2b324ede83c6b41b8151fe9501f0 f28c2b324ede834b8db781887d0019fa 0e2c2b324ede83fa8032016593efec3e 290c2b324ede838dbde401437cb06f52 c61c2b324ede830a8aa6811691278110 2f7c2b324ede837eb1a981c0bbd43cf1 1e9c2b324ede833db9f601eac58d7de4 edcc2b324ede82819a69811a01bf8016 7bdc2b324ede83b5b5e281761cf8c6dc 92bc2b324ede834ca813812ff4783805 9c1c2b324ede83debb4681e9e1eb967d 1edc2b324ede82a09548019dafa94830 bdbc2b324ede83b09e56014278be74d8 d3ec2b324ede83d9afc081a8b123af34 cbfc2b324ede8294abfd01edc63815d8 51bc2b324ede82dd97de011d6fea632c'''.split()
assert len(IDS)==len(set(IDS))==66
# Internal name and source-body rank when explicitly identified, as checked by the same researcher.
# Missing and nonstandard classifications not imputed from page title.
META='''
842c|Polvo Colossal|Bronze
ae5c|Serpente Fantasmagórica|Bronze
e56c|Tartaruga de Canhão|Bronze
a4bc|Dragão Aquático|Bronze
f86c|Crocodilo Anfíbio|Prata
8cdc|Croctus Sombrio|Ouro 4
70ac|Dracélio Nebuloso|Ouro Negro
76dc|Leviatã Abissal|Lendário
517c|Serpente Aquática|Bronze
a53c|NOT_IDENTIFIED|NOT_A_RANK_FIELD
eafc|Leviatãzul|Prata 2
65ec|Tubarão Espectral|Prata 2
474c|Concha Marinha Luminosa|Prata 1
cd7c|Azuragon|Bronze 5
fc0c|Gigante Glacial|Bronze
301c|macaco rei|Prata 5 (2d6)
af1c|EMPTY_BODY|NO_BODY
266c|Felivolante|Lendário
102c|Fera Cornífera das Neves|Bronze
d68c|Slothar Gigantus|Prata 1
c28c|escorpião Ártico|Bronze 5
c00c|Dracopássaro das Tempestades|Bronze
3bfc|Dragão Celestial|Ouro Negro
60ac|Guardião das Ruínas|Bronze
53fc|Monstro das Sombras|Ouro 4
56fc|Leão Celestial|Bronze
d69c|Nocturnequus|Bronze
7eac|Aquaflectere Draco|Lendário
ea5c|UNKNOWN_NAME|Bronze
86ac|Sussurro Sombrio|Bronze
966c|gambá|Prata 1 (2d6)
eddc|galinha demoníaca|Bronze 1 (1d6)
00ac|Cerebrato|Bronze 1
6dec|Guardião do Olho Único|Lendário
9bfc|Borboleta Mística|Bronze
ed3c|Guardião Cósmico|NOT_A_RANK_FIELD
328c|Aurafelis Mystica|Lendário
6bac|Cactursus|Bronze
ae5c2|Grifo da Floresta|NOT_A_RANK_FIELD
7e5c|Seraphis Arborícola|Bronze
df7c|Leão da Floresta Encantada|Bronze
b5ac|Luminar Arborae|Bronze
6bec|Escamorte|Prata 2
40ec|felpudo|Bronze (1d6)
95cc|Grifo Guardião|Ouro
759c|Grifo Guardião|Ouro
82bc|Kuxcoatl|Lendário
319c|Guardião do Deserto|Lendário
8cac|Beemote das Montanhas|Lendário
617c|Mamute de Pedra|Ouro Negro
5eec|Aracnóide Espiral|Lendário
f28c|Espinodonte|Lendário
0e2c|Cervatox|Bronze
290c|Ursocristal|Ouro
c61c|Dracoterra|Ouro
2f7c|Dragão Blindado|Bronze
1e9c|Behemoth Selvagem|Ouro 3
edcc|Dragão do Deserto|Bronze
7bdc|Grifo do Deserto|Ouro
92bc|escorpião Ártico|Bronze 5
9c1c|Dragão das Montanhas|Lendário
1edc|Minotauro Colossal|Bronze
bdbc|Corvo carniceiro|Bronze 3
d3ec|Dragão Alfa das Sombras|Lendário
cbfc|EMPTY_BODY|NO_BODY
51bc|EMPTY_BODY|NO_BODY
'''
# Because the two 'ae5c' prefixes collide, use exact first 8 for one row; the remaining metadata table is supplemented below.
meta={}
for line in META.strip().splitlines():
 p=line.split('|'); assert len(p)==3,p
 pref,name,rank=p
 matching=[i for i in IDS if i.startswith(pref)]
 if len(matching)!=1: # Different ae5c page prefixes resolved by content keyword below
  if pref=='ae5c': matching=['ae5c2b324ede838bbb9681e1977fc324']
  elif pref=='ae5c2':matching=['ae5c2b324ede82cd989e8125970f2c4a']
  else: raise AssertionError((pref,matching))
 meta[matching[0]]={'name':name,'rank':rank}
assert len(meta)==66,len(meta)
EMPTY={'af1c2b324ede8269a7a5812349149aa9','cbfc2b324ede8294abfd01edc63815d8','51bc2b324ede82dd97de011d6fea632c'}
# Numeric effect candidates. 'Explicit' means expression exists in ability, not RE nor exact delivery.
# Attribute values copied from the literal source in this cycle; Croctus has TWO ambiguous FOR values.
AT={
 '8cdc':{'FOR':None,'FOR_VALUES':[39,19],'CON_VALUES':[30,15]},
 '474c':{'FOR':30},'cd7c':{'INT':24,'DES':19},'301c':{'FOR':54,'INT':30},
 'd68c':{'FOR':44},'c28c':{'DES':24,'FOR':8},'53fc':{'FOR':74},
 '966c':{'DES':25},'eddc':{'DES':13},'00ac':{'INT':21},
 '6bec':{'DES':35},'40ec':{'DES':8},'1e9c':{'FOR':55},'92bc':{'FOR':22,'DES':25}
}
# tuple: prefix, ability, raw, class, target, delivery, type/rider provenance, PA
E=[
 ('8cdc','Mordida Infectada','2d6+FOR','LITERAL_ATTACK_WITH_AMBIGUOUS_ATTRIBUTE','VIDA','MELEE','infectious rider; FOR source 39 19 unresolved; CD 6+CON also ambiguous','UNKNOWN'),
 ('474c','Mordida','3d6+FOR','LITERAL_ATTACK','VIDA','MELEE','defensive shell +5 CA for one turn, attack/action unspecified','UNKNOWN'),
 ('cd7c','Jato de Bolhas','1d6+INT','LITERAL_ATTACK','VIDA','RANGED','may disorient, probability unspecified','UNKNOWN'),
 ('cd7c','Cauda de Coral','1d6+DES','LITERAL_ATTACK','VIDA','MELEE','natural attack, coral spikes','UNKNOWN'),
 ('301c','Patada','2d6+FOR','LITERAL_ATTACK_WITH_EXTERNAL_BONUS_QUESTION','VIDA','MELEE_IMPACT','+2 FOR Força Titânica may be already included in FOR54','UNKNOWN'),
 ('301c','Mordida','1d6+FOR','LITERAL_ATTACK_WITH_EXTERNAL_BONUS_QUESTION','VIDA','MELEE_PIERCING','+2 FOR Força Titânica may be already included in FOR54','UNKNOWN'),
 ('301c','Poder elemental','1d10+INT','EFFECT_TARGET_AMBIGUOUS','UNKNOWN','ELEMENTAL','not explicitly says damage; do not classify as confirmed damage; 10PA','10'),
 ('d68c','Golpe Glacial','3d6+FOR','LITERAL_ATTACK','VIDA','MELEE','freeze condition not resolved, vulnerability fire','UNKNOWN'),
 ('c28c','Rabada','1d4+DES','LITERAL_ATTACK','VIDA','MELEE','distinct identity from other Escorpião Ártico Bronze5','UNKNOWN'),
 ('c28c','Corte','1d6+FOR','LITERAL_ATTACK','VIDA','MELEE_CUTTING','distinct from second page, same alias/rank','UNKNOWN'),
 ('53fc','Dentes Afiados','2d6+FOR','LITERAL_ATTACK','VIDA','MELEE','5 RD is DEFENDER property, not extra attack damage','UNKNOWN'),
 ('966c','Arranhão putrificador','2d6+DES','LITERAL_ATTACK','VIDA','MELEE','Fortitude check for paralysis, not guaranteed','UNKNOWN'),
 ('eddc','Patada','1d4+DES','LITERAL_ATTACK','VIDA','MELEE_CUTTING','one attack, bronze1','UNKNOWN'),
 ('00ac','Raio de Putrificação (Peste Negra)','2d6+INT','LITERAL_GRANTED_SPELL','VIDA_CANDIDATE','SPELL_DARK','+1d4 Dark ability independent external bonus may or may not apply; no double add','UNKNOWN'),
 ('6bec','Espinhos Venenosos','2d6+DES','LITERAL_ATTACK','VIDA','RANGED','envenena; poison duration and tick damage unspecified','UNKNOWN'),
 ('40ec','Espinhos perfurantes','1d4+DES','LITERAL_ATTACK','VIDA','RANGED_PIERCING','separate Venomous Spines cooldown 3 rounds, venom numeric magnitude not specified','UNKNOWN'),
 ('1e9c','Investida Selvagem','2d6+FOR','LITERAL_ATTACK_WITH_EXTERNAL_BONUS_QUESTION','VIDA','MELEE','+5 FOR Força Titânica may be embedded in FOR55; avoid double count','UNKNOWN'),
 ('1e9c','Sismo','6d6','LITERAL_DAMAGE','VIDA','AREA_UNSPECIFIED','area/target count and action/PA unspecified','UNKNOWN'),
 ('92bc','Rabada','1d6+1d4+FOR','LITERAL_ATTACK','VIDA','MELEE','same alias and Bronze5 as Ice Escorpião Ártico but different family','UNKNOWN'),
 ('92bc','Corte','1d6+DES','LITERAL_ATTACK','VIDA','MELEE_CUTTING','same alias and Bronze5 as Ice Escorpião Ártico but different family','UNKNOWN'),
]
assert len(E)==20
lookup={i[:4]:i for i in IDS};assert len(lookup)==65 # 2 ae5c prefix aliases; neither has numeric E entries
# Tool-observed source has E=one source page, no mistaken conversion of drop dice to attacks.
NUMERIC_IDS={lookup[e[0]] for e in E};assert len(NUMERIC_IDS)==14
# Verify the 3 empty bodies; all other 49 nonnumeric? 66-14-3=49.
old=json.loads((R.parent/'baseline'/'prev_ids_c22_c25.json').read_text())
with (R.parent/'baseline'/'C26_G1_89_SOURCE_REGISTER.csv').open(encoding='utf-8',newline='') as prev_fp:
 prev26={v['page_id'] for v in csv.DictReader(prev_fp)}
prior=set(old)|prev26
assert len(prior)==345,(len(prior),len(old))
assert not prior.intersection(IDS), 'Previously examined pages may never be double counted.'
assert len(prior.union(IDS))==411
# titles observed separately; on all 66 there are no effect-specific RE/FIP fields found in body scan.
S=[]
for i in IDS:
 s=meta[i];v='EMPTY_BODY' if i in EMPTY else 'NUMERIC_ABILITY_PRESENT' if i in NUMERIC_IDS else 'NO_NUMERIC_OFFENSIVE_FORMULA'
 S.append({'page_id':i,'source_url':'https://app.notion.com/p/'+i,'name_internal_observed':s['name'],'rank_internal_observed':s['rank'],'source_status':v,'numeric_candidates':sum(1 for e in E if lookup[e[0]]==i),'source_edit_day':'2026-10-01','RE_effect':'NOT_DOCUMENTED','FIP_effect':'NOT_DOCUMENTED','coder':'SAME_EXECUTOR_CROSSCHECK_NOT_INDEPENDENT','raw_notion_attachment_snap_verified':'NO','selection':'G1_FINAL_COMPLEMENT_ID_SET'})
assert len(S)==66 and sum(x['numeric_candidates'] for x in S)==20
assert collections.Counter(x['source_status'] for x in S)=={'NO_NUMERIC_OFFENSIVE_FORMULA':49,'NUMERIC_ABILITY_PRESENT':14,'EMPTY_BODY':3}
# Parse dice pools as exact literal; attr is not intrinsic in DMG-RANK §4.
DICERE=re.compile(r'(?i)(\d+)\s*d\s*(4|6|8|10|12|20)')
EX=[]
checks=[]
for k,entry in enumerate(E,1):
 pref,ability,raw,status,target,delivery,notes,pa=entry
 page=lookup[pref]
 terms=[(int(n),int(f)) for n,f in DICERE.findall(raw)];assert terms
 dice_min=sum(n for n,f in terms);dice_max=sum(n*f for n,f in terms)
 intrinsic_mean=Fraction(sum(n*(f+1) for n,f in terms),2)
 # literal + numeric constants, if any
 tail=DICERE.sub('',raw);attr='NONE'
 for v in ['FOR','DES','INT']:
  if re.search(r'\b'+v+r'\b',tail):attr=v;tail=tail.replace(v,'');break
 constants=[int(x) for x in re.findall(r'(?<!\d)\d+',tail)];fix=sum(constants)
 base_min=dice_min+fix;base_max=dice_max+fix;base_mean=intrinsic_mean+fix
 a=AT.get(pref,{}).get(attr,None) if attr!='NONE' else 0
 # if attribute ambiguous, do not set a derived authoritative gross total
 gross=None if a is None else base_mean+a
 gross_min=None if a is None else base_min+a
 gross_max=None if a is None else base_max+a
 # independently recompute using convolution of single die PMFs
 P0={0:1}
 for n,f in terms:
  for _ in range(n):
   nxt=collections.defaultdict(int)
   for x,c in P0.items():
    for face in range(1,f+1):nxt[x+face]+=c
   P0=nxt
 total=sum(P0.values())
 mean2=Fraction(sum(x*c for x,c in P0.items()),total)+fix
 checks.extend([
  {'effect':k,'test':'dice_min','pass':min(P0)+fix==base_min},
  {'effect':k,'test':'dice_max','pass':max(P0)+fix==base_max},
  {'effect':k,'test':'DME_exact_independent_convolution','pass':mean2==base_mean},
  {'effect':k,'test':'support_total','pass':total==math.prod(f**n for n,f in terms)},
  {'effect':k,'test':'nonnegative_dice','pass':all(n>0 and f in (4,6,8,10,12,20) for n,f in terms)},
 ])
 EX.append({'effect_id':f'C27-E{k:03d}','page_id':page,'source_url':'https://app.notion.com/p/'+page,'owner':meta[page]['name'],'source_body_rank':meta[page]['rank'],'ability':ability,'raw_formula':raw,'classification':status,'target':target,'delivery':delivery,'terms':';'.join(f'{n}d{f}' for n,f in terms),'number_of_dice_terms':len(terms),'num_individual_dice':sum(n for n,f in terms),'intrinsic_fixed':fix,'attribute_field':attr,'attribute_value_certified':a,'DME_intrinsic':str(base_mean),'DME_intrinsic_decimal':float(base_mean),'dice_plus_fixed_min':base_min,'dice_plus_fixed_max':base_max,'gross_mean_conditioned_on_attr':float(gross) if gross is not None else None,'gross_min_conditioned_on_attr':gross_min,'gross_max_conditioned_on_attr':gross_max,'PA':pa,'notes':notes,'RE':'NOT_DOCUMENTED','FIP':'NOT_DOCUMENTED','evidence_class':'INTERNAL_LITERAL_REOPEN_NOT_INDEPENDENT'})
assert len(checks)==100 and all(t['pass'] for t in checks)
# Name+ranks can collide materially. No merge by label permitted.
sc=[x for x in EX if x['page_id'] in {'c28c2b324ede8217937c8165a19eafa9','92bc2b324ede834ca813812ff4783805'}]
assert len(sc)==4 and {x['source_body_rank'] for x in sc}=={'Bronze 5'}
# Exact same-label/rank DIFFERENT source Page-IDs. Structural family differs (Gelo vs Terra).
comparisons=[
 {'case':'Escorpião Ártico Bronze5','first_page':'c28c2b324ede8217937c8165a19eafa9','second_page':'92bc2b324ede834ca813812ff4783805','first_family':'Gelo','second_family':'Terra','first_rabada':'1d4+DES24','second_rabada':'1d6+1d4+FOR22','first_rabada_gross_mean':'26.5','second_rabada_gross_mean':'28','meaning':'NAME_RANK_NOT_UNIQUE_ENTITY; NOT independent rank-progression comparison'},
 {'case':'Escorpião Ártico Bronze5 corte','first_page':'c28c2b324ede8217937c8165a19eafa9','second_page':'92bc2b324ede834ca813812ff4783805','first_family':'Gelo','second_family':'Terra','first_corte':'1d6+FOR8','second_corte':'1d6+DES25','first_corte_gross_mean':'11.5','second_corte_gross_mean':'28.5','meaning':'STRUCTURAL/ATTRIBUTE/IDENTITY CONFOUND; no independent RE/FIP'},
 {'case':'Croctus Sombrio force field','page':'8cdc2b324ede83aaaaeb01bbb7a6c452','raw_literal':'Força: 39 19','attack':'2d6+For','possibility_FOR39_gross_mean':'46','possibility_FOR19_gross_mean':'26','meaning':'SOURCE_HAS_TWO_UNLABELED_VALUES; gross DME unresolved, no arbitrary choice'},
 {'case':'Behemoth Selvagem Força Titânica','page':'1e9c2b324ede833db9f601eac58d7de4','raw_LITERAL':'FOR55; 2d6+FOR; +5 Força','current_gross_if_FOR55':'62','current_gross_if_bonus_applies_after':'67','meaning':'DOUBLE_COUNT_RISK; neither postbonus choice certified'},
 {'case':'Macaco rei Força Titânica','page':'301c2b324ede828caccb813d3979267a','raw_LITERAL':'FOR54; +2 Força; Patada 2d6+FOR','current_gross_if_FOR54':'61','current_gross_if_bonus_applies_after':'63','meaning':'DOUBLE_COUNT_RISK'},
 {'case':'Sismo delivery','page':'1e9c2b324ede833db9f601eac58d7de4','raw_LITERAL':'6d6 de dano','per_target_intrinsic_mean':'21','meaning':'No target count, per-action PA or area semantics; cannot compare action DPT to melee Investida'},
 {'case':'Peste Negra extra Dark die','page':'00ac2b324ede831caf1e01e90e81df3b','raw_LITERAL':'Raio 2d6+INT21; +1d4 ataques/magias Dark','unmodified_gross_mean':'28','if_separate_1d4_enters':'30.5','meaning':'External +1d4 is a modifier, not second independent damage effect; conditions/reapplication unknown'},
]
negative=[
 {'page_id':'af1c2b324ede8269a7a5812349149aa9','case':'Símio Demoníaco title ON5','observation':'Empty body with title and image/parent metadata; no offense to extract','correct':'EMPTY_BODY'},
 {'page_id':'cbfc2b324ede8294abfd01edc63815d8','case':'Vazio antigo 1.1','observation':'Empty body','correct':'EMPTY_BODY'},
 {'page_id':'51bc2b324ede82dd97de011d6fea632c','case':'Vazio antigo 2.1','observation':'Empty body','correct':'EMPTY_BODY'},
 {'page_id':'a53c2b324ede830ab253016d7a9fea23','case':'Cavalo Alado Aquático','observation':'1d10/1d8/1d6 in drop resources, not attacks','correct':'NO_NUMERIC_OFFENSIVE_FORMULA'},
 {'page_id':'ae5c2b324ede82cd989e8125970f2c4a','case':'Grifo da Floresta','observation':'1d10/1d8/1d6 drops; ability garras narrativo','correct':'NO_NUMERIC_OFFENSIVE_FORMULA'},
 {'page_id':'301c2b324ede828caccb813d3979267a','case':'Poder elemental','observation':'1d10+INT, 10 PA but no word damage next to ability','correct':'EFFECT_TARGET_AMBIGUOUS'},
 {'page_id':'40ec2b324ede825990c2014b4ef594cb','case':'Felpudo veneno','observation':'3 rounds duration, cooldown 3 rounds; no venom tick dice','correct':'NO_POISON_DAMAGE_AMOUNT'},
]
# hypothese->counterexample: name/rank not unique, source dual attribute, sparse numeric, external bonus.
hypotheses=[
 {'H':'C27-H1','hypothesis':'Same internal name and body rank imply equivalent mechanics','favorable':'Both escorpião Ártico and Bronze5','counterevidence':'Two different source family branches and FOR/DES pools and spells differ','verdict':'REFUTED for observed pair','limitation':'No declaration which is official duplicate vs intentional variant'},
 {'H':'C27-H2','hypothesis':'More dice intrinsically imply more practical damage per action','favorable':'Sismo 6d6 intrinsic mean21 exceeds Investida 2d6 mean7','counterevidence':'Investida includes FOR55, area target counts and actions unknown; target dependency','verdict':'NOT ESTABLISHED','limitation':'No hit/save, PA, target count or RE'},
 {'H':'C27-H3','hypothesis':'All dN syntax in G1 is offensive numeric damage','favorable':'14 numeric attack pages','counterevidence':'Numerous loot-die lines, one rank parenthetical die, trigger die / cooldown die; 49 nonnumeric and 3 empty','verdict':'REFUTED','limitation':'Selection C27 is final residual complement not random sample'},
 {'H':'C27-H4','hypothesis':'Explicit source numeric modifier necessarily applies in addition to all sheet attributes','favorable':'Behemoth +5 FOR, macaco rei +2 FOR','counterevidence':'No declaration whether abilities already baked into sheet; dual FOR Croctus unresolved','verdict':'NOT ESTABLISHED','limitation':'Requires creator/Mestre authority or verified source versioning'},
 {'H':'C27-H5','hypothesis':'Post-RDF expected damage is max(0, average gross minus RDF)','favorable':'Linear cases with all dice rolls above RDF threshold agree','counterevidence':'Galinha Patada 1d4+DES13 vs RDF15 has exact expectation 3/4, versus naive max(0,15.5-15)=1/2','verdict':'REFUTED IN THRESHOLD CROSSING CASE','limitation':'Assumes conditional per-hit RDF subtraction and no hit/save/crit; not in vivo evidence'},
]
# Audit states. F0 is STILL formal 4/8, not advanced by 100% of G1 IDs if RE/FIP etc pending.
gates=[
 {'gate':'G0 GOVERNANCE','state':'LOCAL PASS; writer-to-canon HOLD','evidence':'MESTRE_ONLY, NO_WRITE original, baseline stable'},
 {'gate':'G1 DISCOVERY','state':'STRUCTURAL G1 411/411 PASS; global coverage UNKNOWN','evidence':'345 prior +66 new unique IDs by page ID; other classes outside G1 open'},
 {'gate':'G2 DEDUP','state':'LOCAL PASS','evidence':'Full IDs unique, aliases not merged, 20 occurrence keys unique'},
 {'gate':'G3 EXTRACTION','state':'LOCAL PASS FOR 66 ID-DECISIONS ONLY','evidence':'14 numeric,49 no numeric,3 empty; independent coding absent'},
 {'gate':'G4 TAXONOMY','state':'PARTIAL','evidence':'19 actionable +1 ambiguous, Vida vs unknown separated'},
 {'gate':'G5 CLASSIFICATION','state':'HOLD','evidence':'RE/FIP effect specifically documented 0/20; page rank != RE'},
 {'gate':'G6 MATH','state':'LOCAL PASS 100/100','evidence':'exact fractions, independent convolution and support checks'},
 {'gate':'G7 DOSSIERS','state':'PARTIAL','evidence':'G1 bestiary catalog structurally complete only; other domains open'},
 {'gate':'G8 STATS','state':'PARTIAL','evidence':'purposive selection prevents prevalence estimates'},
 {'gate':'G9 BIAS','state':'PARTIAL','evidence':'conflicts, missing, legacy text/document duplicates logged'},
 {'gate':'G10 CANDIDATE','state':'NOT_STARTED','evidence':'No statistically and authoritatively justified revision'},
 {'gate':'G11 REGRESSION','state':'NOT_STARTED','evidence':'No v2 candidate'},
 {'gate':'G12 STRESS','state':'PARTIAL','evidence':'algebraic buff and identity stress only, full fights untested'},
 {'gate':'G13 PLAYTEST','state':'NOT_TESTED','evidence':'Human playtests not commissioned here'},
 {'gate':'G14 MASTER/NAC','state':'HOLD','evidence':'F0 4/8, A5 0/7 byte originals, no production or NAC-PASS'},
]
def csvwrite(name,items):
 assert items
 with open(P/name,'w',encoding='utf-8',newline='') as fp:
  fields=sorted({k for item in items for k in item.keys()})
  w=csv.DictWriter(fp,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(items)
# CONDITIONAL defensive benchmark against four real RDF fields physically re-opened in Notion Mestre.
# No CA/hit chance, crit, action, PA, rider, counterattack, transformation, damage type guessed as canonical.
defenses=[
 ('Rinolupo Prata1','034c2b324ede83ffa7118144011beaf3',10),
 ('Guardião Pétreo Prata3','549c2b324ede8375b21181335038aad1',15),
 ('Guardião Pétreo Ouro1','b0ec2b324ede835a927601b4cbd8fca6',20),
 ('Guardião Pétreo Ouro5','371c2b324ede837fad4c01bbfe9a95fb',25)
]
strict=[('301c','Patada','PHYSICAL_IMPACT_EXPLICIT'),('301c','Mordida','PHYSICAL_PIERCING_EXPLICIT'),('eddc','Patada','PHYSICAL_CUTTING_EXPLICIT')]
inferred=[('c28c','Corte','CUTTING_INFERRED_BY_NAME_ONLY'),('92bc','Corte','CUTTING_INFERRED_BY_NAME_ONLY')]
decision=[]
for pref,ability,typ in strict+inferred:
 ee=next(x for x in EX if x['page_id']==lookup[pref] and x['ability']==ability)
 assert ee['attribute_value_certified'] is not None
 terms=[(int(m.group(1)),int(m.group(2))) for m in DICERE.finditer(ee['raw_formula'])]
 dist={0:1}
 for nn,faces in terms:
  for _ in range(nn):
   q=collections.defaultdict(int)
   for dmg,c in dist.items():
    for die in range(1,faces+1):q[dmg+die]+=c
   dist=q
 denom=sum(dist.values())
 for dn,di,rd in defenses:
  a=int(ee['attribute_value_certified'])
  # Formula per successful hit under an assumed subtraction of listed RDF against physically typed damage.
  expected=Fraction(sum(max(0,value+a+ee['intrinsic_fixed']-rd)*cnt for value,cnt in dist.items()),denom)
  second=Fraction(sum(max(0,value+a+ee['intrinsic_fixed']-rd)*cnt for value,cnt in dist.items()),math.prod(f**n for n,f in terms))
  assert expected==second
  decision.append({'effect_id':ee['effect_id'],'owner':ee['owner'],'ability':ability,'attacker_page_id':ee['page_id'],'defender':dn,'defender_page_id':di,'documented_RDF':rd,'type_eligibility':typ,'per_hit_post_RDF_mean_exact':str(expected),'per_hit_post_RDF_mean_decimal':float(expected),'per_hit_gross_mean':ee['gross_mean_conditioned_on_attr'],'per_attempt_DPT':'UNAVAILABLE','note':'CONDITIONAL ON SUCCESSFUL HIT; no turn/PA/crit. RDF subtraction treated as conditional physical defense contract, not proven for every damage kind.'})
assert len(decision)==20
assert collections.Counter(x['type_eligibility'] for x in decision)=={'PHYSICAL_IMPACT_EXPLICIT':4,'PHYSICAL_PIERCING_EXPLICIT':4,'PHYSICAL_CUTTING_EXPLICIT':4,'CUTTING_INFERRED_BY_NAME_ONLY':8}
csvwrite('C27_20_CONDITIONAL_REAL_RDF_SCENARIOS.csv',decision)
csvwrite('C27_G1_66_SOURCE_REGISTER.csv',S)
csvwrite('C27_G1_20_NUMERIC_EFFECT_CANDIDATES.csv',EX)
csvwrite('C27_100_INDEPENDENT_EXACT_MATH_CHECKS.csv',checks)
csvwrite('C27_7_CONTROLLED_DISCREPANCY_CASES.csv',comparisons)
csvwrite('C27_NEGATIVE_CONTROLS_7.csv',negative)
csvwrite('C27_5_HYPOTHESES_FALSIFIABLE.csv',hypotheses)
csvwrite('C27_G0_G14_QUALITY_GATE_DELTA.csv',gates)
summary={'cycle':'C27','operation':'OP-DMG-CORPUS-EMP-01','authority':'MESTRE_SIDE_TEST','canonical_DMG_RANK':'v1.1_UNMODIFIED','G1_manifest_count':411,'prior_c22_c26_unique_ids':345,'new_c27_ids':66,'cumulative_g1_unique_ids':411,'G1_other_IDs_remaining':0,'new_numeric_source_pages':14,'new_numeric_effect_candidates':20,'new_numeric_effect_candidates_nonUNKNOWN_target':19,'new_numeric_effect_candidates_ambiguous_target':1,'new_non_numeric_source_pages':49,'new_empty_source_pages':3,'new_RE_FIP_certified':0,'source_original_bytes_authenticated':0,'independent_documental_coder':0,'math_checks_exact':100,'conditional_real_RDF_scenarios':20,'strict_explicit_physical_RDF_scenarios':12,'type_inferred_physical_RDF_scenarios':8,'quality_G5':'HOLD','F0':'4/8 HOLD','A5_original_bytes':'0/7','NAC_PASS':'HOLD','scope_warning':'G1 is only a structural manifest, not a census of all RPG sources and not normatively validated by page access. C22-C26 prior observations not physically re-opened in C27.'}
(P/'C27_DENOMINATORS_STATE.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
# further assertion on raw data / gross conditioned only
assert sum(x['number_of_dice_terms'] for x in EX)==21
assert [x for x in EX if x['attribute_value_certified'] is None and x['attribute_field']!='NONE'][0]['page_id']=='8cdc2b324ede83aaaaeb01bbb7a6c452'
assert len([x for x in EX if x['target']=='UNKNOWN'])==1
print(json.dumps(summary,ensure_ascii=False,sort_keys=True))
