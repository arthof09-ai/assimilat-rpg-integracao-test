# DMG C27 — Dossiê Mestre-only

Ciclo C27 da operação **existente** `OP-DMG-CORPUS-EMP-01`, sem escrita canônica nem alteração à DMG-RANK-01 v1.1.

## Como usar

1. O relatório principal é `work/publication/PSV_DMG_C27_MESTRE_ONLY.md`.
2. Verifique a integridade com `C27_SHA256_MANIFEST.json` e CRC do ZIP.
3. Extraia o ZIP inteiro e execute `python C27_PORTABLE_REPLAY.py`. O replay recalcula todas as saídas derivadas de C27 em diretório limpo e as compara por SHA-256.
4. Para auditar uma expressão, encontre o `page_id` na tabela `C27_G1_20_NUMERIC_EFFECT_CANDIDATES.csv` e confronte diretamente com o Notion Mestre em `https://app.notion.com/p/<page_id>`.
5. Não use a Library ou os hashes de dados analíticos como evidência de captura de bytes originais da ficha. A transcrição foi executada por um codificador, a revisão independente segue PENDENTE.

## Inclusões

- 66 Page-IDs finais G1 com status por fonte; 345 Page-IDs anteriores autenticados como lista e 89 fichas C26.
- 20 ocorrências candidatas, 100 verificações de suporte/média por duas abordagens, 20 cenários condicionais RDF.
- 7 contraexemplos/reconciliações, controles negativos, 5 hipóteses, matriz G0–G14 e nota decisória.
- Pacote anterior C26 íntegro como baseline; **sem** recriar ou substituir fichas oficiais.

## Restrição

Não importar em Party, O Primeiro ou produção; não deduzir RE/FIP de RN, classe de título, item ou estrela. F0 4/8 HOLD; A5 originals 0/7; NAC-PASS global HOLD.
