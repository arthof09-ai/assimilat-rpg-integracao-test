# PSV DMG C27 — Fechamento estrutural G1, taxonomia de efeito e resistência física condicional

**Operação preexistente:** `OP-DMG-CORPUS-EMP-01`  
**Ciclo:** C27 · 21/10/2026 · MESTRE-SIDE / LABORATÓRIO TEST  
**Baseline:** C26 autenticado, `DMG-RANK-01 v1.1` INALTERADA  
**Produção:** HOLD · **Party e O Primeiro:** NO-WRITE · **NAC-PASS global:** HOLD  
**Status:** ACEITE TÉCNICO LOCAL DO C27, NÃO ACEITE NORMATIVO F0/F18.

## 1. Sumário científico com limitações explícitas

No universo *estrutural* G1 de 411 Page-IDs, C22–C26 haviam examinado cumulativamente 345; o C27 calculou a diferença de conjuntos e reabriu no Notion Mestre todos os 66 Page-IDs restantes. A operação agora tem **411/411 IDs estruturalmente cobertos**, sem extrapolar essa contagem ao universo de magias, itens, técnicas, inscrições, invocações ou ao restante do RPG.

Os 66 registros C27 foram decididos em nível de página: **14** com pelo menos um efeito numérico candidato, **49** sem expressão ofensiva numérica utilizável e **3** com corpo vazio. Os 14 produziram **20 ocorrências candidatas** e **21 termos de dados**. Uma ocorrência (*Poder elemental*, macaco rei `1d10+INT`, custo 10 PA) não identifica expressamente dano/Alma/Vida e permanece `EFFECT_TARGET_AMBIGUOUS`; as outras 19 são candidatas de ataque, efeito ofensivo ou magia concedida, sem prova suficiente para equivalência de entrega.

**Qualificação fundamental:** os 345 IDs anteriores são lastreados nos pacotes aceitos C22–C26, NÃO foram reabertos pela segunda vez nesta campanha; o arquivo C27 preserva a lista desses Page-IDs e sua proveniência. A codificação das 66 novas fontes foi feita pelo mesmo executor, portanto a reexecução matemática ou o readback de Biblioteca **não é revisão documental independente por outro codificador**. Tampouco há prova do hash dos bytes de 66 anexos originais do Notion; o registro é da leitura do conteúdo retornado.

**Resultados decisórios:** a taxonomia por Page-ID é indispensável para separar aliases, bônus de atributo, dados de drops, efeitos em área e recursos. Nenhuma instância nova apresentou RE/FIP de efeito individual certificado (**0/20**), logo as bandas da norma **não foram validadas nem refutadas**. C27 conclui descoberta estrutural G1 sem avançar automaticamente F0: **4/8 — HOLD**.

## 2. Protocolo de seleção, cronologia e integridade da cobertura

1. Reaberto o manifesto G1 no Notion Mestre (`https://app.notion.com/p/3f0c2b324ede8196b704dc8e04b94fe5`).
2. Reconciliados 256 IDs C22–C25 e 89 IDs C26, formando 345 IDs anteriores únicos. A identidade usada é Page-ID integral; prefixos só auxiliam transcrição e não são chaves canônicas.
3. Pré-selecionados os 66 restantes pela diferença de conjuntos ANTES da leitura dos seus efeitos, sem restrição posterior de relevância. Todos foram efetivamente solicitados ao Notion.
4. Duplicações entre ciclos: **0**. Cobertura resultante: **345 + 66 = 411**. O denominador G1 e as 66 linhas estão nos artefatos `C27_G1_66_SOURCE_REGISTER.csv` e no baseline C26.
5. Em cada página: verificar corpo, nome interno, rank expresso, fórmulas literais, separação de dado de drop versus efeito, recurso-alvo, modificadores externos e lacunas de RE/FIP. Datas de edição conferidas nesta coorte apontam para 01/10/2026.

Este recorte é o **complemento final determinístico**, não uma amostra aleatória nem holdout independente. Um mesmo texto-modelo em várias páginas não produz réplicas científicas independentes.

## 3. Catálogo numérico novo

Preservamos a formulação literal de cada ataque, o número de termos e o contexto. DME intrínseco inclui só dados e eventuais constantes pertencentes à expressão, **não** FOR/INT/DES da criatura.

| Página / entidade | Efeito literal | DME intrínseco | Média bruta por acerto sob atributo da ficha | Observação crítica |
|---|---|---:|---:|---|
| Croctus Sombrio ([fonte](https://app.notion.com/p/8cdc2b324ede83aaaaeb01bbb7a6c452)) | `Mordida Infectada: 2d6+FOR` | 7 | **PENDENTE** | ATRIBUTO DUPLO |
| Concha Marinha Luminosa ([fonte](https://app.notion.com/p/474c2b324ede82d08ea6819069c17043)) | `Mordida: 3d6+FOR` | 21/2 | 40.5 | CANDIDATO |
| Azuragon ([fonte](https://app.notion.com/p/cd7c2b324ede822f89e9015f9812673d)) | `Jato de Bolhas: 1d6+INT` | 7/2 | 27.5 | CANDIDATO |
| Azuragon ([fonte](https://app.notion.com/p/cd7c2b324ede822f89e9015f9812673d)) | `Cauda de Coral: 1d6+DES` | 7/2 | 22.5 | CANDIDATO |
| macaco rei ([fonte](https://app.notion.com/p/301c2b324ede828caccb813d3979267a)) | `Patada: 2d6+FOR` | 7 | 61.0 | GROSS CONDICIONAL |
| macaco rei ([fonte](https://app.notion.com/p/301c2b324ede828caccb813d3979267a)) | `Mordida: 1d6+FOR` | 7/2 | 57.5 | GROSS CONDICIONAL |
| macaco rei ([fonte](https://app.notion.com/p/301c2b324ede828caccb813d3979267a)) | `Poder elemental: 1d10+INT` | 11/2 | 35.5 | ALVO INCERTO |
| Slothar Gigantus ([fonte](https://app.notion.com/p/d68c2b324ede8331a59e81ba69df564b)) | `Golpe Glacial: 3d6+FOR` | 21/2 | 54.5 | CANDIDATO |
| escorpião Ártico ([fonte](https://app.notion.com/p/c28c2b324ede8217937c8165a19eafa9)) | `Rabada: 1d4+DES` | 5/2 | 26.5 | CANDIDATO |
| escorpião Ártico ([fonte](https://app.notion.com/p/c28c2b324ede8217937c8165a19eafa9)) | `Corte: 1d6+FOR` | 7/2 | 11.5 | CANDIDATO |
| Monstro das Sombras ([fonte](https://app.notion.com/p/53fc2b324ede833eba54017dbed7918e)) | `Dentes Afiados: 2d6+FOR` | 7 | 81.0 | CANDIDATO |
| gambá ([fonte](https://app.notion.com/p/966c2b324ede83d7962b019b1861b6b1)) | `Arranhão putrificador: 2d6+DES` | 7 | 32.0 | CANDIDATO |
| galinha demoníaca ([fonte](https://app.notion.com/p/eddc2b324ede829f8a75011e8acbf429)) | `Patada: 1d4+DES` | 5/2 | 15.5 | CANDIDATO |
| Cerebrato ([fonte](https://app.notion.com/p/00ac2b324ede831caf1e01e90e81df3b)) | `Raio de Putrificação (Peste Negra): 2d6+INT` | 7 | 28.0 | CANDIDATO |
| Escamorte ([fonte](https://app.notion.com/p/6bec2b324ede8261af8b8185b07ad9b0)) | `Espinhos Venenosos: 2d6+DES` | 7 | 42.0 | CANDIDATO |
| felpudo ([fonte](https://app.notion.com/p/40ec2b324ede825990c2014b4ef594cb)) | `Espinhos perfurantes: 1d4+DES` | 5/2 | 10.5 | CANDIDATO |
| Behemoth Selvagem ([fonte](https://app.notion.com/p/1e9c2b324ede833db9f601eac58d7de4)) | `Investida Selvagem: 2d6+FOR` | 7 | 62.0 | GROSS CONDICIONAL |
| Behemoth Selvagem ([fonte](https://app.notion.com/p/1e9c2b324ede833db9f601eac58d7de4)) | `Sismo: 6d6` | 21 | 21.0 | CANDIDATO |
| escorpião Ártico ([fonte](https://app.notion.com/p/92bc2b324ede834ca813812ff4783805)) | `Rabada: 1d6+1d4+FOR` | 6 | 28.0 | CANDIDATO |
| escorpião Ártico ([fonte](https://app.notion.com/p/92bc2b324ede834ca813812ff4783805)) | `Corte: 1d6+DES` | 7/2 | 28.5 | CANDIDATO |

### Dicionário de inferências proibidas

- `Rank: Bronze 1 (1d6)` pode registrar chassi/rank; não gera automaticamente um ataque adicional `1d6`.
- Dado em *drop* / ingrediente / rendimento de material não é ataque da Besta.
- `Poder elemental: 1d10+INT, 10 PA` tem expressão e PA, **mas o texto não identifica explicitamente recurso ou dano**; não foi convertido em dano certificado à Vida.
- `Raio de Putrificação 2d6+INT` da Peste Negra e `+1d4 em ataques/magias Dark` são *efeito e modificador* distintos; o +1d4 não é segunda magia.
- Dano bruto com atributo é útil como benchmark contextual, mas o DME **intrínseco** normativo não inclui FOR/DES/INT.
- As anotações em fichas de criaturas não estabelecem custo, chance de acerto, duração, alvos, reflexões, gatilhos ou redução em resistência sem fonte competente.

## 4. Descobertas forenses — correções e não equivalências

### 4.1 Dois Escorpiões Árticos Bronze 5 — **verificado**

A estrutura G1 registra uma ficha na família Gelo (`https://app.notion.com/p/c28c2b324ede8217937c8165a19eafa9`), e outra na família Terra (`https://app.notion.com/p/92bc2b324ede834ca813812ff4783805`). Ambas dizem literalmente *escorpião Ártico*, Bronze 5, mas têm atributos e mecânicas diferentes:

| Medida | Página Gelo | Página Terra |
|---|---:|---:|
| FOR | 8 | 22 |
| DES | 24 | 25 |
| Rabada | `1d4+DES` | `1d6+1d4+FOR` |
| Média bruta Rabada | 26,5 | 28 |
| Corte | `1d6+FOR` | `1d6+DES` |
| Média bruta Corte | 11,5 | 28,5 |

**Conclusão:** nome e rank iguais não bastam para unir as fichas nem atribuir progressão. **PENDENTE** saber se é duplicata incorreta, variante válida ou entrada de família equivocada. Não alterar as duas originais.

### 4.2 Croctus Sombrio — campo ambíguo **verificado**

A ficha `https://app.notion.com/p/8cdc2b324ede83aaaaeb01bbb7a6c452` contém literalmente `Força: 39 19`, `Constituição: 30 15`, `Vida: 840 420` e `Mordida Infectada: 2d6+FOR CD 6+CON`. Sem rótulo que identifique cada coluna, o dano médio intrínseco da Mordida é **7**, mas a média bruta pode ser **46** usando FOR39 ou **26** usando FOR19. As duas são *cenários*, não escolha oficial. A CD igualmente permanece ambígua; a fórmula não pode virar registro unívoco.

### 4.3 Bônus possivelmente incorporados — **condição não resolvida**

- *Behemoth Selvagem* `https://app.notion.com/p/1e9c2b324ede833db9f601eac58d7de4`: FOR55, Investida `2d6+FOR`, *Força Titânica* `+5 FOR`. A média da Investida é 62 usando FOR55, **ou 67** somente se o +5 incidir adicionalmente e ainda não estiver embutido no atributo.
- *macaco rei* `https://app.notion.com/p/301c2b324ede828caccb813d3979267a`: FOR54, Patada `2d6+FOR`, *Força Titânica* `+2 FOR`. Média 61 com o número impresso, ou 63 no cenário de modificador adicional.
- *Cerebrato* `https://app.notion.com/p/00ac2b324ede831caf1e01e90e81df3b`: Peste Negra concede raio `2d6+INT21` e bônus `+1d4` para ataques/magias Dark. Média bruta 28 para o raio; **30,5 apenas no cenário** em que o bônus for pertinente e não estiver contabilizado. Não assumir acumulação reiterada.

### 4.4 Dano à Vida, controle, veneno e área são eixos separados

*Behemoth Selvagem*: Investida `2d6+FOR` e Sismo `6d6` não são ações comparáveis sem quantidade de alvos, ação e custo. O Sismo tem DME intrínseco por instância 21; não existe base para afirmar DPT garantido de um turno inteiro.

*Escamorte*: Espinhos Venenosos `2d6+DES35` são um ataque numérico com veneno narrativo; não foi registrado valor numérico do veneno.

*Felpudo*: Espinhos perfurantes `1d4+DES8`, e outra habilidade *Espinhos Venenosos* causa veneno por três rodadas com intervalo de três rodadas; **dano de cada tick não está documentado**. Sua duração não autoriza criar uma expressão para o veneno.

## 5. Benchmarks de resistência física real — 20 cenários, NÃO 20 combates

Quatro fichas Mestre foram reabertas como defensores: Rinolupo Prata 1 com RDF10 (`https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3`) e Guardião Pétreo Prata 3, Ouro 1 e Ouro 5 com RDF15/20/25 (`https://app.notion.com/p/549c2b324ede8375b21181335038aad1`, `https://app.notion.com/p/b0ec2b324ede835a927601b4cbd8fca6`, `https://app.notion.com/p/371c2b324ede837fad4c01bbfe9a95fb`).

Sob o contrato estritamente **condicional** *um ataque bem-sucedido, dano efetivamente físico e RDF subtraída de cada resultado individual*, calcular `E[max(0, dados + atributo + bônus intrínseco - RDF)]`. **Não** equiparar a `max(0, média bruta - RDF)`.

- **12 cenários com tipo físico explícito**, Macaco Patada impacto, Macaco Mordida perfurante e Galinha Patada cortante, cada um diante de 4 defensores.
- **8 cenários tipados por inferência**, os dois efeitos chamados `Corte` dos dois Escorpiões, diante dos mesmos 4 defensores. Não canonizar o tipo de dano apenas pelo nome.

| Atacante | RDF10 | RDF15 | RDF20 | RDF25 |
|---|---:|---:|---:|---:|
| Macaco Patada (impacto explícito) | 51 | 46 | 41 | 36 |
| Macaco Mordida (perfurante explícito) | 47.5 | 42.5 | 37.5 | 32.5 |
| Galinha Patada (cortante explícito) | 5.5 | 0.75 | 0 | 0 |
| Escorpião Gelo Corte (inferido) | 1.66667 | 0 | 0 | 0 |
| Escorpião Terra Corte (inferido) | 18.5 | 13.5 | 8.5 | 3.5 |

A Patada da galinha, `1d4+DES13`, possui média bruta 15,5. Contra RDF15, a média **exata** pós-resistência é `3/4 = 0,75`, enquanto a falsa aproximação `max(0, 15,5−15)` gera 0,5: **viés por truncamento à esquerda**. Com RDF20, 100% das faces geram 0, mas isso é somente uma previsão por acerto para aquele defensor e dano físico sob o contrato hipotetizado. Não foram simulados acerto, crítico, iniciativa, PA, custo de ação, turnos nem TTK.

## 6. Cinco hipóteses, refutação e incertezas

| Hipótese | Resultado | Motivo |
|---|---|---|
| `C27-H1` — Same internal name and body rank imply equivalent mechanics | REFUTED for observed pair | Two different source family branches and FOR/DES pools and spells differ |
| `C27-H2` — More dice intrinsically imply more practical damage per action | NOT ESTABLISHED | Investida includes FOR55, area target counts and actions unknown; target dependency |
| `C27-H3` — All dN syntax in G1 is offensive numeric damage | REFUTED | Numerous loot-die lines, one rank parenthetical die, trigger die / cooldown die; 49 nonnumeric and 3 empty |
| `C27-H4` — Explicit source numeric modifier necessarily applies in addition to all sheet attributes | NOT ESTABLISHED | No declaration whether abilities already baked into sheet; dual FOR Croctus unresolved |
| `C27-H5` — Post-RDF expected damage is max(0, average gross minus RDF) | REFUTED IN THRESHOLD CROSSING CASE | Galinha Patada 1d4+DES13 vs RDF15 has exact expectation 3/4, versus naive max(0,15.5-15)=1/2 |

**Análise estatística e viés:** as 20 ocorrências candidatas estão agrupadas em 14 páginas, não são 20 Bestas independentes e as 20 células RDF constituem cruzamento dos mesmos cinco ataques com quatro defensores. A coorte final não é aleatória. Não calcule taxas populacionais de dano ou rank do G1 ou do RPG a partir deste ciclo isolado. A revisão matemática com algoritmo distinto confirma as consequências da extração, não a fidelidade de cada transcrição original por outro pesquisador.

## 7. Gates e governança

| Gate | Estado | Prova/bloqueio |
|---|---|---|
| G0 GOVERNANCE | LOCAL PASS; writer-to-canon HOLD | MESTRE_ONLY, NO_WRITE original, baseline stable |
| G1 DISCOVERY | STRUCTURAL G1 411/411 PASS; global coverage UNKNOWN | 345 prior +66 new unique IDs by page ID; other classes outside G1 open |
| G2 DEDUP | LOCAL PASS | Full IDs unique, aliases not merged, 20 occurrence keys unique |
| G3 EXTRACTION | LOCAL PASS FOR 66 ID-DECISIONS ONLY | 14 numeric,49 no numeric,3 empty; independent coding absent |
| G4 TAXONOMY | PARTIAL | 19 actionable +1 ambiguous, Vida vs unknown separated |
| G5 CLASSIFICATION | HOLD | RE/FIP effect specifically documented 0/20; page rank != RE |
| G6 MATH | LOCAL PASS 100/100 | exact fractions, independent convolution and support checks |
| G7 DOSSIERS | PARTIAL | G1 bestiary catalog structurally complete only; other domains open |
| G8 STATS | PARTIAL | purposive selection prevents prevalence estimates |
| G9 BIAS | PARTIAL | conflicts, missing, legacy text/document duplicates logged |
| G10 CANDIDATE | NOT_STARTED | No statistically and authoritatively justified revision |
| G11 REGRESSION | NOT_STARTED | No v2 candidate |
| G12 STRESS | PARTIAL | algebraic buff and identity stress only, full fights untested |
| G13 PLAYTEST | NOT_TESTED | Human playtests not commissioned here |
| G14 MASTER/NAC | HOLD | F0 4/8, A5 0/7 byte originals, no production or NAC-PASS |

**F0–F18:** sem promoção formal. F0 continua **4/8 HOLD**; F1–F18 não recebem PASS por leitura de manifesto.  
**D0–D9/E01–E24:** nenhum fechamento normativo inferido ou antecipado.  
**A5 original:** **0/7 bytes originais autenticados**; A7/A8 HOLD.  
**Oito gates principais e Q-COVERAGE/Q-CODEBOOK/Q-MATH/Q-TARGET/Q-HOLDOUT/Q-REDTEAM/Q-TRACE:** progresso local de descoberta e matemática, sem PASS global nem revisão documental independente.  
**NAC-CONT-03, NAC-NORM-01, NAC-PASS-02:** todas as transições para produção/Party/O Primeiro bloqueadas.  
**Fonte de verdade persistente:** Notion Mestre, jamais o CSV derivado isolado. Nenhuma ficha original ou regra vigente foi alterada.

## 8. Decisões e recomendações priorizadas

1. **Prioridade P0 — Habilitar certificação RE/FIP:** recuperar e verificar habilidades/magias/técnicas/itens com patamar competente *do efeito* documentado. RN, RI ou estrela da criatura não satisfazem sozinho.
2. **P0 — Segunda codificação documental independente** da coorte de 14 páginas numéricas, preservando divergências, acordo por campo e adjudicação em fontes Notion.
3. **P1 — Resolver Croctus**, duas colunas numéricas sem rótulo, e origem dos bônus já embutidos em atributo em Behemoth/macaco. Não alterar fichas sem ordem do Mestre.
4. **P1 — Separar orçamento de Vida / Alma / PA / controle / veneno / área / bypass** antes de propor bandas ou ações por turno.
5. **P2 — Orientar benchmark defensivo** com tipos explícitos, mitigação por resultado, custos e ações, sem transformar células matemáticas em playtests.

## 9. Registro de continuidade, FIRST-PENDING, NO-REPEAT

**ANTES:** C26 com 345/411 páginas estruturais G1 documentadas; classificação RE/FIP individual ainda indisponível e F0 HOLD.  
**DEPOIS:** C27 com 411/411 IDs do manifesto G1, +66 páginas examinadas, +20 candidatos numéricos em 14 páginas, 100 testes matemáticos locais e 20 cenários condicionais RDF; sem autorização de escrita canônica nem progressão dos gates F0.  
**LAST-VERIFIED-UNIT:** C27 — leitura física das 66 fichas, 14 fontes com candidato numérico e defesa real RDF 10/15/20/25; reprodução matemática e verificação do ZIP à parte no recibo.  
**FIRST-PENDING:** primeira amostra *independentemente codificada* por outro pesquisador e pelo menos uma fonte com RE/FIP competente individual. Se essa independência não puder ser obtida, não simular uma segunda pessoa/algoritmo como pesquisador.  
**NO-REPEAT:** manter C22–C26 íntegros, não recatalogar 411 para inflar a cobertura.  
**NEXT-5:** fontes RE/FIP rastreáveis; revisão documental independente; reconciliação Croctus; fontes de custos/ação de Sismo/Poder Elemental; projeto de validação baseline×candidato pareada somente após autoridade e gate.
**TARGET-REMAINDER:** fontes fora do G1 para magias/técnicas/armas, recuperação dos sete snapshots originais de A5, preparação de fixtures reais e futura validação F0–F18 autorizada com o Mestre.

## 10. Arquivos, hashes e readback

Este PSV acompanha CSVs de fontes, fórmulas, controles, hipóteses, matrix de gates, método de reconstrução, código portátil de replay, manifesto SHA-256 e a baseline C26. Os hashes demonstram integridade do artefato, **não equivalência dos dados ao corpo do Notion por revisor independente**. Recibos finais de Biblioteca são separados e exigem download/materialização após o upload.
