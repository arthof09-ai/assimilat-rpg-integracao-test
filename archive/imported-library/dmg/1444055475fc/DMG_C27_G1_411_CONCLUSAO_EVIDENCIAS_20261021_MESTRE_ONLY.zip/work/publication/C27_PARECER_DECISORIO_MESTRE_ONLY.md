# PARECER DECISÓRIO DMG C27 — MESTRE-SIDE

**Operação** `OP-DMG-CORPUS-EMP-01` — **Regra oficial** `DMG-RANK-01 v1.1` INALTERADA.

## Resultado

**G1 estrutural 411/411 Page-IDs examinado cumulativamente** (345 de C22–C26 + 66 lidos neste C27, sem interseção). Isso não é certificação do RPG completo. A coorte final: **14/66 páginas** com 20 candidatos numéricos (um alvo indefinido), 49 páginas sem fórmula ofensiva utilizável e 3 corpos vazios. **RE/FIP competente 0/20**.

**Novos diagnósticos:**

1. Mesmo nome e rank não definem criatura única: dois Escorpiões Árticos Bronze5 em famílias Gelo/Terra têm atributos e ataques diferentes.
2. Croctus Sombrio tem duas FOR/CON/Vida justapostas sem rótulo, deixando a Mordida como DME intrínseco7 e dano contextual NÃO RESOLVIDO.
3. Behemoth Selvagem (+5 FOR), macaco rei (+2 FOR) e Cerebrato (+1d4 Dark) mostram risco de aplicação duplicada de bônus.
4. Efeito `Poder elemental 1d10+INT, 10PA` não pode virar automaticamente dano à Vida.
5. **20 cenários pós-RDF** com defesas reais RDF10/15/20/25 (12 com tipo físico explícito; 8 inferidos). Galinha 1d4+DES13 vs RDF15: média exata 0,75, não 0,5 da fórmula de médias truncadas.

## Decisão

**RECOMENDO** preservar a DMG-RANK-01 v1.1, sem candidato v2, sem migração de fichas e sem alteração Party/O Primeiro. As bandas não foram empiricamente homologadas nem refutadas. O G1 deve sair da fila de expansão bruta e entrar em uma fase de certificação documental de efeitos, RE/FIP, ações, custos, alvos e tipos.

**PRÓXIMA QUESTÃO:** levantar fontes com RE/FIP individual competente e obter outro codificador físico das 14 páginas; reconciliar Croctus e bônus sem escrever no cânone.

**GOVERNANÇA:** F0 4/8 HOLD; A5 originais 0/7; A7/A8 HOLD; NAC-PASS global HOLD; laboratório TEST only; sem writer/canonização fictícia.

**EVIDÊNCIA:** pacote C27, manifestos e PSV completos, com readback de Biblioteca em recibo separado. Preservar C22–C26.
