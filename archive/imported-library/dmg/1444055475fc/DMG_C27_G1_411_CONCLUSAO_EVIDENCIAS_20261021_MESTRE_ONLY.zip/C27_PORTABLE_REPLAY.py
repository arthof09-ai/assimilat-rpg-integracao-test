#!/usr/bin/env python3
"""Portable exact output regeneration for C27. Stdlib Python 3.11+ required.
Requires ONLY files extracted from C27 package, not connections to Notion.
Cannot independently certify transcription fidelity or RE/FIP authority.
"""
from pathlib import Path
from hashlib import sha256
import csv,json,subprocess,tempfile,shutil,sys
ROOT=Path(__file__).resolve().parent
MAN=json.loads((ROOT/'C27_SHA256_MANIFEST.json').read_text())
for filename,expect in MAN['sha256'].items():
 p=ROOT/filename
 assert p.is_file(),f'missing {filename}'
 assert sha256(p.read_bytes()).hexdigest()==expect,(filename,'digest_mismatch')
rel=[p for p in MAN['sha256'] if p.startswith('work/publication/')]
with tempfile.TemporaryDirectory(prefix='dmg_c27_replay_') as td:
 t=Path(td)
 (t/'work').mkdir();(t/'baseline').mkdir()
 for filename in ('work/build_c27.py','work/write_reports_c27.py','baseline/prev_ids_c22_c25.json','baseline/C26_G1_89_SOURCE_REGISTER.csv'):
  out=t/filename;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/filename,out)
 for script in ('build_c27.py','write_reports_c27.py'):
  subprocess.run([sys.executable,str(t/'work'/script)],cwd=t,check=True,capture_output=True,text=True,timeout=80)
 for filename in rel:
  b=(t/filename).read_bytes()
  assert sha256(b).hexdigest()==MAN['sha256'][filename],f'replay divergence {filename}'
 s=json.loads((t/'work/publication/C27_DENOMINATORS_STATE.json').read_text())
 with (t/'work/publication/C27_100_INDEPENDENT_EXACT_MATH_CHECKS.csv').open(newline='',encoding='utf-8') as f:checks=list(csv.DictReader(f))
 assert s['cumulative_g1_unique_ids']==411 and s['new_c27_ids']==66
 assert len(checks)==100 and all(x['pass']=='True' for x in checks)
 print(f'C27 PORTABLE REPLAY PASS: {len(rel)}/{len(rel)} regenerated exactly; {len(MAN["sha256"])} sha256 entries verified; {len(checks)} exact arithmetic checks; 66+345=411 unique structural sources; NOT independent documentary validation.')
