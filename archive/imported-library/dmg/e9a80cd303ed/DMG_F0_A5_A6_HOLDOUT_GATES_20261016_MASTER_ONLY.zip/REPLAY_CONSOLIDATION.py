from pathlib import Path
import hashlib,json,csv,zipfile,datetime,collections,os
ROOT=Path('/mnt/data/dmg_recovery')
PRIOR=ROOT/'f0_material_snapshots_20261016'
COORD=PRIOR/'coordinator_evidence/COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json'
OUT=ROOT/'f0_post_attachment_audit_20261016'
OUT.mkdir(exist_ok=True)
MAN=json.loads(COORD.read_text(encoding='utf8'))
now='2026-10-16'

# Produto A, each attachment originally created by Coordenação; this executor verified pointers but not bytes.
a=[]
for i,e in enumerate(MAN['snapshot_entries'],1):
    a.append({'sequence':i,'name':e['name'],'source_id':e['source_page_id'],'url':e['source_url'],
     'notion_current_edited':e['source_notional_last_edit_at_snapshot'],'source_text_sha256_expected':e['source_content_sha256_utf8_expected'],
     'source_text_chars':e['source_content_characters'],'notion_attached_filename':e['attachment_filename'],
     'notion_file_upload_id':e['attachment_file_upload_id'],'notion_attachment_parent':e['notion_inbox_page'],
     'notion_file_block_pointer_present':True,'notion_file_block_pointer_reopened_by_executor':True,
     'readback_of_binary_content':False,'readback_sha256_match':None,
     'scope':'Notion fetch <content> UTF8 Markdown; no nested linked content or attachments',
     'version_conflict_with_original_prereg': e['name'] in {'Criação de Ficha','Transformação Espiritual'},
     'authority_source_unchanged_by_executor':True})
pa={'operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','as_of':now,'source':'COORDINATOR EXISTING INBOX-102 + library evidence manifest',
    'attachment_creator':'Comestre Coordenador (not DMG Executor)','expected_source_hashes_verified_prior':'7/7 independently by Coordenador',
    'attachment_file_pointers_independently_reopened_by_executor':'7/7','source_body_file_attached_to_notion':'7/7',
    'signed_file_urls_resolved':'7/7','signed_url_byte_download_result':'BLOCKED from current runtime; no byte readback',
    'small_notion_download_attachment_tool':'returns empty object even for a 4-character control attachment',
    'attachment_byte_readbacks_verified':'0/7','formal_F0_change':0,'formal_F0':'4/8 HOLD',
    'format_scope':'Markdown text representation accessible to Notion fetch; not full block REST tree; no media/binary/descendants',
    'sources':a}
(OUT/'PRODUTO_A_7_ANEXOS_GAP_READBACK.json').write_text(json.dumps(pa,ensure_ascii=False,indent=2),encoding='utf8')

branches=[
 ('Água','824c2b324ede8232bc8c81ff7cf58802','2026-10-01T20:40:33.445Z',40,3),
 ('Gelo','85fc2b324ede82c99db101ab105f182f','2026-10-01T18:46:18.055Z',25,0),
 ('Vento','17bc2b324ede82ffb5028109bbee810c','2026-10-01T20:40:55.340Z',10,13),
 ('Fogo','988c2b324ede8398b6f8019b49e032ea','2026-10-01T20:40:58.317Z',24,6),
 ('Raio','5dac2b324ede82ddbf4c81db6c5623b7','2026-10-01T20:45:43.255Z',17,11),
 ('Dark','805c2b324ede82708b9e81ba40cda2c1','2026-10-01T20:45:57.877Z',26,17),
 ('Caos','f81c2b324ede83f88fdc0118d5d8ed62','2026-10-01T20:41:56.805Z',14,1),
 ('Planta','6edc2b324ede833aa26901d305cff5bb','2026-10-01T20:41:59.099Z',28,4),
 ('Luz','f76c2b324ede833b875f81f4ea32f47d','2026-10-01T20:42:22.980Z',12,9),
 ('Terra','75fc2b324ede82f4a9fd01bba8d41833','2026-10-01T20:42:26.088Z',32,8),
 ('Normal','b8ac2b324ede8210a9f00165f3d8ada6','2026-10-01T18:53:36.168Z',10,0),
 ('Espectro','9f5c2b324ede830d81ac01194b033054','2026-10-01T20:42:52.360Z',1,83)
]
with (OUT/'PRODUTO_B_12_RAMIFICACOES_BESTAS.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.writer(f);w.writerow(['elemento','id_pagina','url','ultima_edicao','page_child_refs','mention_page_refs','scope','unique_count_note'])
 for (name,id,edit,pg,ment) in branches:w.writerow([name,id,'https://app.notion.com/p/'+id,edit,pg,ment,'one Notion source page direct children','counts are links, not effects or creatures'])
bm={'operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','root_parent':'3ecc2b324ede815c902bdbd889827bc4',
 'read_element_branches':12,'total_beast_root_direct_children':14,'other_root_children_not_descended_here':2,
 'branch_direct_child_links':sum(x[3] for x in branches),'distinct_child_ids_across_branches':239,
 'cross_branch_duplicate_child_ids':0,'mention_page_occurrences':sum(x[4] for x in branches),
 'distinct_mentioned_page_ids':121,'mentioned_ids_not_present_among_239_child_ids':0,
 'direct_link_count_8_master_roots_from_coord':332,'direct_ids_8_master_roots_from_coord':332,
 'root_count':8,'global_D0':None,'notes':['Do not add 239 to global 332 as an organism denominator','Original 332 links include twelve Beast element pages themselves','Nested branches and other sources not exhaustively traversed','notion linked child pages not validated as mechanical records','93 repeated mention occurrences among 155 total; all mention IDs already amongst 239 children'],
 'method':'Notion fetch per 12 branch + regex <page url> / <mention-page url>; JS sets for uniqueness, independent integer sum below'}
(OUT/'PRODUTO_B_ESCOPO_E_DENOMINADORES.json').write_text(json.dumps(bm,ensure_ascii=False,indent=2),encoding='utf8')

# Holdout exposure scan: no one of 8 IDs or exact names appears in local pre-prereg artifacts.
pre=json.loads((PRIOR/'PRODUTO_B_HOLDOUT_PREREG_PRESEAL.json').read_text())['records']
local=[]
for p in ROOT.rglob('*'):
 if not p.is_file() or OUT in p.parents or PRIOR in p.parents or any(k in str(p) for k in ['library_readback','__pycache__']):continue
 if p.suffix.lower() in {'.md','.csv','.json','.txt','.py'}:
  try:
   v=p.read_bytes()
   if len(v)<=5_000_000:local.append((str(p.relative_to(ROOT)),v))
  except:pass
 elif p.suffix.lower()=='.zip':
  try:
   with zipfile.ZipFile(p) as z:
    for n in z.namelist():
     if n.lower().endswith(('.md','.csv','.json','.txt','.py')) and z.getinfo(n).file_size<=5_000_000:
      local.append((str(p.relative_to(ROOT))+'::'+n,z.read(n)))
  except:pass
records=[]
for e in pre:
 ident=e['source_page_id'].encode('ascii');title=e['name'].lower().encode('utf8')
 matches=[name for name,b in local if ident in b or title in b.lower()]
 records.append({'id':e['source_page_id'],'name':e['name'],'family_candidate':e['provisional_family_group'],
  'matches_in_local_pre_prereg_artifacts':len(matches),'sample_match_paths':matches[:8],
  'content_read_this_cycle':False,'eligible_to_seal_as_blind_holdout':False})
ho={'scope':'LOCAL ARTIFACT EXPOSURE SCREEN ONLY','as_of':now,'files_or_archive_entries_checked':len(local),
 'reserved_candidates':8,'candidate_id_and_exact_title_matches_local_prior_artifacts':sum(bool(x['matches_in_local_pre_prereg_artifacts']) for x in records),
 'conclusion':'0/8 observed identity/title exposures in accessible pre-prereg local corpus; DOES NOT PROVE blind holdout, due unavailable total historic corpus and family alias genealogies',
 'notion_source_content_read':0,'global_historical_union_tested':False,'holdout_seal':'HOLD',
 'candidate_records':records}
(OUT/'PRODUTO_B_HOLDOUT_AUDITORIA_EXPOSICAO_LOCAL.json').write_text(json.dumps(ho,ensure_ascii=False,indent=2),encoding='utf8')

screens=[
 ['Lâmina da Queda Contida','3f5c2b324ede81e9aa8ec51f568600e8','Ouro Negro/Entrada','1 Ação Padrão, corpo a corpo','7d8+15','EXPLICIT_DAMAGE_PRECEDENCE','Fonte já define 7d8+15; v1.1 não pode substituir'],
 ['Gancho da Rocha Errante','3f5c2b324ede815f8fa0cf88b0508930','Ouro/Entrada','1 Ação Padrão +16PA','nenhum','NON_OFFENSIVE','Ancoragem, não ataque; não cria dano automaticamente'],
 ['Pó da Brasa Clara','3f5c2b324ede8145a12febac8558aeb8','Prata/Entrada','1 Ação Padrão, 1 dose','não ofensivo','NON_OFFENSIVE','Mitigação climática até 12/ocorrência; não ataque'],
 ['Inscrição Explosão Repentina (O) (CG)','9a7c2b324ede8346acab01835165bb14','Ouro? no título, RE/FIP NÃO atribuído por autoridade','armadilha, ação e PA ausentes','não consta','MISSING_RE_FIP_ACTION_COST_AND_DELIVERY','Explosão que pode regenerar 2 vezes; falta RE/FIP, ação, custo, área, gatilho/recarga e dano'],
 ['Inscrição Raio Poente (B)','badc2b324ede83a3ba3a01c93724db40','Bronze? no título, RE/FIP NÃO atribuído por autoridade','inscrição aplicada à arma; custo não verificado','não consta','MISSING_RE_FIP_ATTACK_CONTEXT','Efeito especial elétrico/controle, não estabelece pool de dano independente'],
 ['Braçadeira do Pulmão de Ferro','3f5c2b324ede81eaa080cad94c16dd3b','Ouro/Entrada','1 Ação Padrão +15PA','mitigação até 20 por ocorrência','NON_OFFENSIVE','Acessório de redução ambiental, sem ataque ofensivo novo']
]
with (OUT/'PRODUTO_C_TRIAGEM_SEIS_FONTES_NOVAS.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.writer(f);w.writerow(['nome','pagina_id','url','RE_FIP_achado','acao_custo','dano_explicito','veredito','justificativa']);
 for row in screens:w.writerow([row[0],row[1],'https://app.notion.com/p/'+row[1],*row[2:]])

f0=[]
for i in range(1,9):
 key=f'F0-A{i}'
 if i<=4:before=after='DOCUMENTADO_HISTORICO_NAO_RECERTIFICADO';note='No new work on inherited accepted documentation'
 elif i==5:before='7/7 fingerprints, 0/7 immutable bodies confirmed in Library';after='7/7 Markdown attachments physically pointed in Notion Coordinator Inbox, 0/7 byte redownload';note='download_attachment connector yielded empty {}; signed links resolved 7/7 but runtime could not retrieve bytes'
 elif i==6:before='8 roots with 332 distinct direct IDs, deeper branches not scanned';after='12 elemental branches of Beast index inspected, 239 distinct direct child IDs; 155 mention occurrences map to same IDs';note='Still no global D0; 2 other Beast root branches unexpanded'
 elif i==7:before='8 candidate IDs, unknown prior exposure';after='8 candidate IDs screened against locally available pre-prereg archive texts without observed ID/title exposure; NOT blind certified';note='Not all historical sources nor alias families covered'
 else:before='HOLD unassigned writer and second coder';after='HOLD; no writer/lease/epoch/INSTANCE claimed, second independent human coder absent';note='Mathematical audits do not replace separate source coder'
 f0.append({'id':key,'authority':'DMG-F0-PREREG-01 + OP + EXT + QA; A-number operational mapping, NOT normative IDs','before':before,'after':after,'formal_pass':i<=4,'new_formal_pass':False,'delta':note})
gates={'as_of':now,'operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','baseline':'DMG-RANK-01 v1.1 unchanged',
       'formally_documented_before':4,'formally_documented_after':4,'total_operational_F0_criteria':8,
       'new_formal_pass':0,'items':f0,'nac_pass':'SCIENTIFIC_READ_ONLY_EVIDENCE_PASS; F0_FORMAL_HOLD; WRITER_HOLD',
       'plan_phases_defined':19,'ext_guarantees_defined':24,'transversal_gates_defined':8,
       'plan_phases_productively_certified_this_cycle':0,'first_near_closable':'F0-A5 archival physical byte readback then scope/temporal version and independent audit'}
(OUT/'PRODUTO_D_F0_GATE_ANTES_DEPOIS.json').write_text(json.dumps(gates,ensure_ascii=False,indent=2),encoding='utf8')

resume={'AS_OF':now,'OPERATION':'CM-000001 / OP-DMG-CORPUS-EMP-01','BASELINE':'DMG-RANK-01 v1.1 unchanged',
 'CHECKPOINT':'F0-POST-COORD-ATTACHMENT-20261016-01','LAST_VERIFIED_UNIT':
 'seven source Markdown attachment blocks exist in Coordinator Inbox, complete 7-entry attachment manifest; 12 Beast elemental branch pages opened, 239 distinct child IDs; eight prior holdout identities scanned against local archives; six new sources tested for eligibility',
 'FIRST_PENDING':'Retrieve actual bytes of 7 Notion Markdown attachments for independent SHA256 readback, then reconcile textual 07Oct variants versus 09Oct pages; complete full source-family genealogy, independent blind coder and legitimate writer',
 'DENOMINATORS':{'F0_formal_before':4,'F0_formal_after':4,'F0_total':8,'A5_attached_notion':7,'A5_actual_byte_readback':0,'surface_roots':8,'root_direct_distinct_links':332,'Beast_element_branches_read':12,'Beast_second_level_child_ids':239,'holdout_reserved':8,'holdout_globally_certified':0,'new_v11_negative_screens':6,'new_authentic_v11_applications':0,'D0_global':None},
 'NO_REPEAT':['R02-R04','post realignment 116/148 math tests','Galidemus Iskiel six test replicas','24 high rank Bestas','VLAB R71/R81 native runs','copy the 7 Notion files already attached by Coordinator'],
 'CONFLICTS':['A1-A8 is operational mapping, not officially labeled eight gates','07Oct original baseline versus post09Oct revisions on Ficha and Transformacao; no literal historical diff verified','Notion attachments reachable as pointers but runtime could not read back bytes','Item rank != RE; current global D0 unknown'],
 'UNKNOWN_EFFECT':'No shared Notion edits, no Party/O Primeiro writes; temporary unattached 4B TEST tool experiment has 1hr expiry, no canonical mutation',
 'NEXT_5':['Recover independent bytes of seven attached sources; compare SHA256 and preserve in original OP Library without duplicate administrative page','Recover genuine 07Oct historical source versions separately and reconcile current 09Oct deltas','Follow Beast root balance/legacy remaining two branches and other families with bounded structure map; no global D0 inference','Perform holdout family alias collisions against full historical matrix and competent blind reviewer','Request classification for offensive missing-damage inscription in correct authority or search further; no invent RE/FIP'],
 'TARGET_REMAINDER':'F0 4/8; v1.1 unchanged; future F1-F18 gated; no normative v2',
 'AUTHORITY_WRITER_STATE':'LAB TEST autonomy per Mestre; OP/Diario shared writer/epoch/lease/INSTANCE identity unproved, HOLD; Notion Coordinator Inbox attachment write physically attributed to Coordenação, not executor',
 'NAC_PASS':'LOCAL_SCIENTIFIC_PRESERVATION_PASS; F0_FORMAL_HOLD; CANON_HOLD',
 'HANDOFF':'Use original operation + existing Coordinator Inbox attachments + this checkpoint and previous historical packages. No duplicated lab, page, plan or id claims'}
(OUT/'FAST_RESUME_F0_POST_ATTACHMENT.json').write_text(json.dumps(resume,ensure_ascii=False,indent=2),encoding='utf8')

psv=f'''# PSV — DMG / F0 pós-arquivamento pela Coordenação — 16/10/2026

**Ambiente:** MESTRE-SIDE. **Operação:** CM-000001 / OP-DMG-CORPUS-EMP-01. **Baseline:** DMG-RANK-01 v1.1 inalterada.

## Resposta do gate
F0 formal **4/8 → 4/8**. Novo PASS formal **zero**. A1–A8 são classificação operacional e não identificadores canônicos de certificação.

## Produto A — sete fontes (evidência atribuída à Coordenação)
A Coordenação materializou sete anexos `.md` na Inbox Mestre existente `https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25`. A instância DMG recuperou seu manifesto do diretório autorizado da Biblioteca, abriu a página Inbox e conferiu sete ponteiros `notion-file-block://`, nomes e correspondência de fonte. Os sete fingerprints do conteúdo-fonte já haviam sido comprovados independentemente pela Coordenação. Os sete **bytes do próprio anexo ainda não foram recuperados independentemente**: download por file_upload_id devolve objeto vazio no conector, e signed URLs não foram transferidos para a área de execução. Portanto A5 preservação física é PARCIAL, não um snapshot de toda árvore. Temporais 09/10 em Criação de Ficha e Transformação não representam versão histórica de 07/10.

## Produto B — inventário, holdout e denominadores
Oito índices diretos de superfície Mestre tinham 332 referências diretas distintas na matriz da Coordenação. Novo: 12 ramos elementais de Bestas reabertos com **239 IDs filhos distintos**, **155 ocorrências por menção referenciando somente esses IDs**, das quais **121 IDs distintos por menção**. 2 ramos extras da raiz (balanceamento e arquivo antigo) não foram expandidos. Nenhuma inferência de D0 global.

Holdout: oito reservas pré-existentes verificadas em busca literal de IDs e nomes nos arquivos locais históricos, antes de acessar suas fichas reservadas: 0/8 achados fora do próprio pré-registro. Isso NÃO demonstra ausência em todas as versões históricas nem equivalência de famílias/aliases; **holdout blindado continua 0/8 certificado**.

## Produto C — 6 novos candidatos
A Lâmina da Queda Contida já tem `7d8+15`; o Gancho da Rocha Errante e Pó da Brasa Clara não são ataques; Braçadeira do Pulmão de Ferro é defensiva; Inscrição Raio Poente não estabelece um pool ofensivo. A **Inscrição Explosão Repentina (O) (CG)** é de fato ofensiva sem fórmula, mas falta RE/FIP de autoridade, custo, ação, área, gatilho e detalhes da entrega. Resultado genuinamente admitido **0/6**, sem inventar mecânica.

## Produto D — primeiro gate fechável
A5 é o primeiro candidato técnico: os sete anexos deixam de ser só ponteiros para fontes atuais, mas o **readback byte-exato do anexo** e a cobertura exigida do snapshot permanecem pendentes. Não há writer legitimado, second-coder independente nem prova de versão original de 07/10 para as duas fontes mutadas. As 19 fases, 24 garantias e oito gates seguem as definições anteriores; nenhuma promoção oficial.

## Estado de segurança
Nenhuma escrita na operação compartilhada, regras, fichas, Party ou O Primeiro. Acesso Notion exclusivo pelo vínculo Mestre. Sem nova operação, laboratório, plano concorrente ou novos cenários do VLAB.

## Próxima retomada
Reproduzir hash SHA256 dos **bytes realmente baixados** de cada um dos sete anexos contra o manifesto da Coordenação, arquivá-los na pasta original Biblioteca como snapshot sem sobrescrever anteriores, autenticar 07Out histórico, completar mapa estrutural/holdout e obter writer/second-coder por gate competente. A execução matemática independente continua permitida sem depender de motor VLAB.

**NAC-PASS:** pacote local e integridade: PASS; F0 documental: HOLD 4/8; canônico/Party: NO-WRITE/HOLD.
'''
(OUT/'PSV_DMGCYCLE_POS_ATTACHMENT_20261016.md').write_text(psv,encoding='utf8')

# Keep reconstruction code and coordinator's prior manifest, without altering them.
import shutil
shutil.copy2(COORD, OUT/'COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json')
shutil.copy2(Path(__file__), OUT/'REPLAY_CONSOLIDATION.py')

# Integrity constraints and local package.
assert len(a)==7 and sum(x[3] for x in branches)==239 and sum(x[4] for x in branches)==155
assert len(pre)==8 and len(records)==8 and len(screens)==6
assert len([e for e in f0 if e['formal_pass']])==4
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in {'MANIFEST_SHA256.json','DMG_F0_A5_A6_HOLDOUT_GATES_20261016_MASTER_ONLY.zip'})
manifest={'operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','type':'ADDENDUM_APPEND_ONLY_F0','entries':[]}
for p in files:manifest['entries'].append({'filename':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(OUT/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
zipp=OUT/'DMG_F0_A5_A6_HOLDOUT_GATES_20261016_MASTER_ONLY.zip'
with zipfile.ZipFile(zipp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(OUT.iterdir()):
  if p.is_file() and p!=zipp:z.write(p,p.name)
with zipfile.ZipFile(zipp) as z:
 assert z.testzip() is None
 for it in manifest['entries']:
  raw=z.read(it['filename']);assert hashlib.sha256(raw).hexdigest()==it['sha256']
print(json.dumps({'created_zip':str(zipp),'archive_bytes':zipp.stat().st_size,'zip_sha256':hashlib.sha256(zipp.read_bytes()).hexdigest(),
 'manifest_entries':len(manifest['entries']),'local_artifact_entries_scanned_for_holdout':len(local),
 'notion_attachments_pointers':len(a),'new_Beasts_branch_refs':239,'holdout_ID_name_matches':sum(x['matches_in_local_pre_prereg_artifacts']>0 for x in records),
 'new_neg_screen_sources':len(screens),'formal_F0_pass':4},ensure_ascii=False,indent=2))
