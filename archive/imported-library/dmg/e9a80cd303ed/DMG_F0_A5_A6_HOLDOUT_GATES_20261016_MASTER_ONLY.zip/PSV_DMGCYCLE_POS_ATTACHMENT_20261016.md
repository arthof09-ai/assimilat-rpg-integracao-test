# PSV — DMG / F0 pós-arquivamento pela Coordenação — 16/10/2026

**Ambiente:** MESTRE-SIDE. **Operação:** CM-000001 / OP-DMG-CORPUS-EMP-01. **Baseline:** DMG-RANK-01 v1.1 inalterada.

## Resposta do gate
F0 formal **4/8 → 4/8**. Novo PASS formal **zero**. A1–A8 são classificação operacional e não identificadores canônicos de certificação.

## Produto A — sete fontes (evidência atribuída à Coordenação)
A Coordenação materializou sete anexos `.md` na Inbox Mestre existente `https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25`. A instância DMG recuperou seu manifesto do diretório autorizado da Biblioteca, abriu a página Inbox e conferiu sete ponteiros `notion-file-block://`, nomes e correspondência de fonte. Os sete fingerprints do conteúdo-fonte já haviam sido comprovados independentemente pela Coordenação. Os sete **bytes do próprio anexo ainda não foram recuperados independentemente**: download por file_upload_id devolve objeto vazio no conector, e signed URLs não foram transferidos para a área de execução. Portanto A5 preservação física é PARCIAL, não um snapshot de toda árvore. Temporais 09/10 em Criação de Ficha e Transformação não representam versão histórica de 07/10.

## Produto B — inventário, holdout e denominadores
Oito índices diretos de superfície Mestre tinham 332 referências diretas distintas na matriz da Coordenação. Novo: 12 ramos elementais de Bestas reabertos com **239 IDs filhos distintos**, **155 ocorrências por menção referenciando somente esses IDs**, das quais **121 IDs distintos por menção**. 2 ramos extras da raiz (balanceamento e arquivo antigo) não foram expandidos. Nenhuma inferência de D0 global.

Holdout: oito reservas pré-existentes verificadas em busca literal de IDs e nomes nos arquivos locais históricos, antes de acessar suas fichas reservadas: 0/8 achados fora do próprio pré-registro. Isso NÃO demonstra ausência em todas as versões históricas nem equivalência de famílias/aliases; **holdout blindado continua 0/8 certificado**.

## Produto C — 6 novos candidatos
A Lâmina da Queda Contida já tem `7d8+15`; o Gancho da Rocha Errante e Pó da Brasa Clara não são ataques; Braçadeira do Pulmão de Ferro é defensiva; Inscrição Raio Poente não estabelece um pool ofensivo. A **Inscrição Explosão Repentina (O) (CG)** é de fato ofensiva sem fórmula, mas falta RE/FIP de autoridade, custo, ação, área, gatilho e detalhes da entrega. Resultado genuinamente admitido **0/6**, sem inventar mecânica.

## Produto D — primeiro gate fechável
A5 é o primeiro candidato técnico: os sete anexos deixam de ser só ponteiros para fontes atuais, mas o **readback byte-exato do anexo** e a cobertura exigida do snapshot permanecem pendentes. Não há writer legitimado, second-coder independente nem prova de versão original de 07/10 para as duas fontes mutadas. As 19 fases, 24 garantias e oito gates seguem as definições anteriores; nenhuma promoção oficial.

## Estado de segurança
Nenhuma escrita na operação compartilhada, regras, fichas, Party ou O Primeiro. Acesso Notion exclusivo pelo vínculo Mestre. Sem nova operação, laboratório, plano concorrente ou novos cenários do VLAB.

## Próxima retomada
Reproduzir hash SHA256 dos **bytes realmente baixados** de cada um dos sete anexos contra o manifesto da Coordenação, arquivá-los na pasta original Biblioteca como snapshot sem sobrescrever anteriores, autenticar 07Out histórico, completar mapa estrutural/holdout e obter writer/second-coder por gate competente. A execução matemática independente continua permitida sem depender de motor VLAB.

**NAC-PASS:** pacote local e integridade: PASS; F0 documental: HOLD 4/8; canônico/Party: NO-WRITE/HOLD.
