# PSV — DMG C34 / Recursão dirigida de recursos + prevenção de falso RE

**Ambiente:** MESTRE-SIDE / TEST. **OP existente:** OP-DMG-CORPUS-EMP-01. **Norma oficial v1.1:** preservada. **Autoridade:** sucessão de trabalho autorizada, escritor/lease/epoch/INSTANCE do Notion NÃO confirmado. Party/O Primeiro/OP/Diário/Inbox/regras/VLAB: NO-WRITE.

## ANTES
C33 tinha 813 Page-IDs físicos verificados em coortes, sem D0 global nem aplicação legal F6.

## DEPOIS
Em revisão das categorias filhas do índice `Itens` Mestre, foram recuperadas por Notion diretamente:
- 11/11 fichas-filhas de `Drops & Materiais de Criaturas`
- 7/7 de `Outros Materiais`
- 1/1 de `Essências Mágicas` (a ficha matriz `Essência Mágica (CG)`)
- 16/16 fichas-filhas físicas de `Essência Mágica (CG)` descobertas por recursão interna.

As **35** páginas físicas foram lidas individualmente por ID Notion, tiveram nome e ancestral confirmados e foram confrontadas contra os 813 IDs C33: **zero sobreposições**. União contextual delimitada: **813+35 = 848 Page-IDs**. Não constitui denominação final D0 do RPG, efeitos de ataque ou relevância estatística do DMG. Preservados 35 IDs/nomes/URLs no CSV e índice completo de 848 no ZIP.

## Achado metodológico — FIP enganoso de material
As fichas de recursos incluem `RC-MIN — Recurso Pronto para Crafting`, por vezes `FIP interna: Entrada/Baixa/Alta/Ápice`. O próprio texto marca `Estado da informação: INFERIDO`, frequentemente `Poder direto: não reclassificado por RC-MIN`. **FIP de ingrediente/material e RIn NÃO provam Rank de Efeito de ataque (RE), FIP de efeito ofensivo, ação, PA ou dano.** Seria erro copiar o FIP do Coração de Fênix, Espinhos de Viúva Negra, Ossos do Discípulo de Bink ou Essência de Titã para criar dano automático.

Nem a presença da palavra veneno em um insumo valida número de dano, DoT, duração ou stacking. A classificação dos **35 como fontes materiais, e não como efeitos ofensivos prontos**, foi realizada no texto renderizado. Eventuais usos ofensivos exigem a receita e efeito final com autoridade e parâmetros independentes. **0/35 fontes admissíveis para F6 na condição em que foram consultadas**, sem inferência de prevalência no corpus.

## Gates e retomada
F0-A6 avanço verificável +35 IDs em quatro estratos, D0 global ainda HOLD; F6 sem positivo, após triagem MATERIAL. F0-A5 signed URL 7/7 resolvidos, bytes 0/7 por bloqueio de transporte privado, HOLD; A7 blind holdout HOLD; A8 second human coder e writer Notion HOLD. F7–F18 e candidato v2 sem promoção; nenhum dado ou norma oficial alterados.

**NÃO REPETIR:** C22–C33, 813 coorte anterior, 11 Drops, 7 Outros, 1 Essência-mãe e 16 Essências-filhas. **FIRST-PENDING:** encontrar efeito ofensivo original sem fórmula, porém RE/FIP e condições próprias, preferencialmente fora das fontes de matéria-prima; seguir F0-A6 nas árvores inéditas relevantes, não trabalhar infinitamente recursos por contagem. Usar a ficha/efeito e não a matéria-prima para dano.
**NAC-PASS:** integridade dos registros local e readback do ZIP proporcional; certificação global F0/F6/normativa HOLD.
