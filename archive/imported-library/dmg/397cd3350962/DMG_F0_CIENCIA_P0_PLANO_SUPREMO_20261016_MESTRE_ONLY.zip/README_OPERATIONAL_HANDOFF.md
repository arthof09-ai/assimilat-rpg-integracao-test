# Recuperação / EXECUTOR CM-000001 DMG

Pacote ADITIVO de OP-DMG-CORPUS-EMP-01, MESTRE-SIDE, 16/10/2026. Não substitui artefatos anteriores, matriz F0 original ou DMG-RANK-01.

1. Leia `products/FAST_RESUME_DMG_P0.json` e `products/PSV_PLANO_SUPREMO_CONTINUIDADE_20261016.md`.
2. Evidência matemática antiga reutilizada: `readonly_sources/R02_DAMAGE_A_B_C.csv`. R91 matriz original de ataques, runs e pares incluída em read-only. ZIP R91 integral permanece na Biblioteca VLAB original (não replicado neste pacote).
3. Para reexecutar análise, extraia este ZIP de modo isolado. `src/build_science.py` usa diretórios de operação originais preservados no runtime do projeto; ajuste ROOT e apontadores aos artefatos preservados se retomar em outro computador. `src/audit_science_independent.py` compara outputs sem convalidar classificação cega.
4. O pacote NÃO contém os sete corpos de anexos Markdown pós-upload: só manifesto e nomes/IDs. Dizer o contrário seria falso. Baixe os bytes via ferramenta autorizada nova, recalcule o SHA e só então reavalie F0-A5.
5. F0 formal = 4/8, writer e segundo codificador não provados; não editar Party/O Primeiro ou sistema oficial.

Manifest SHA256 protege todas as entradas exceto ele mesmo, CRC do ZIP validado, e o ZIP é armazenado na pasta já existente `/Comestre/OP-DMG-CORPUS-EMP-01/`.
