from __future__ import annotations
from itertools import product
from fractions import Fraction
from collections import Counter,defaultdict
import csv,re,zipfile,hashlib,json,random,pathlib,math,collections
ROOT=pathlib.Path('/mnt/data/dmg_recovery/p0_supreme_continuation_20261016')
OUT=ROOT/'products'
ZIP=ROOT/'vlab_readonly/VLAB_R82_R91_BENCHMARK_MULTIDIMENSIONAL_MESTRE_ONLY.zip'

def csvr(name):
 with (OUT/name).open(encoding='utf8') as f:return list(csv.DictReader(f))
checks=[];fail=[]
def check(label,predicate):
 (checks if predicate else fail).append(label)

def exact_enumeration(s,bonus):
 pool=[]
 for a,b in re.findall(r'(\d+)d(\d+)',s,re.I):pool.extend([range(1,int(b)+1)]*int(a))
 assert pool
 vals=[sum(x)+int(bonus) for x in product(*pool)]
 return Counter(vals)

def expected_rd(p,rd):
 return sum(Fraction(max(k-rd,0)*n, sum(p.values())) for k,n in p.items())

records=csvr('ANALISE_EXATA_22_ACOES_R02_RD.csv')
by=collections.defaultdict(list)
for r in records:by[(r['page_id'],r['attack'])].append(r)
check('exact number of distinct effects',len(by)==22)
for key,rows in by.items():
 rows=sorted(rows,key=lambda x:int(x['rd']))
 sample=rows[0];fixed=float(sample['mean_bruto'])
 dice_mean=sum(int(c)*(int(s)+1)/2 for c,s in re.findall(r'(\d+)d(\d+)',sample['formula_literal'],re.I))
 add=round(fixed-dice_mean)
 p=exact_enumeration(sample['formula_literal'],add)
 for row in rows:
  rd=int(row['rd']);d=expected_rd(p,rd)
  check('PMF RD exact '+str(key)+' RD'+str(rd),abs(float(d)-float(row['mean_apos_rd']))<1e-10)
  check('P_positive exact '+str(key)+' RD'+str(rd),abs(sum(n for k,n in p.items() if k>rd)/sum(p.values())-float(row['prob_liquido_positivo']))<1e-10)

pA=exact_enumeration('1d6+1d4',22);pB=exact_enumeration('1d6',25)
check('A gross 28',expected_rd(pA,0)==28)
check('B gross 28.5',expected_rd(pB,0)==Fraction(57,2))
check('A RD31',expected_rd(pA,31)==Fraction(1,24))
check('B RD31',expected_rd(pB,31)==0)
check('RD30 equality',expected_rd(pA,30)==expected_rd(pB,30)==Fraction(1,6))

# Independently check attack ledger per RunID and no false mirror denominator.
R91=ROOT/'vlab_readonly'
with (R91/'R90_ATTACK_RECEIPTS_884.csv').open() as f:att=list(csv.DictReader(f))
with (R91/'R90_BENCHMARK_RUNS_48.csv').open() as f:runs=list(csv.DictReader(f))
with (R91/'R90_PAIRED_BLOCKS_24.csv').open() as f:blocks=list(csv.DictReader(f))
check('884 receipts',len(att)==884)
check('48 runs',len(runs)==48)
check('24 matched blocks',len(blocks)==24)
att_by=defaultdict(list)
for row in att:att_by[row['run_id']].append(row)
for run in runs:
 x=att_by[run['run_id']]
 check('run attempts '+run['run_id'],len(x)==int(run['attacks']))
 check('run hits '+run['run_id'],sum(int(i['hit']) for i in x)==int(run['hits']))
 for side in ['B','E']:
  y=[t for t in x if t['actor_side']==side]
  check('side attempts '+side+run['run_id'],len(y)==int(run[side+'_attempts']))
  for f,col in [('hits','hit'),('raw','damage_raw'),('post_RD','damage_post_rd_potential'),('real_hp_loss','hp_real_loss')]:
   check('side sum '+side+f+run['run_id'],sum(int(z[col]) for z in y)==int(run[side+'_'+f]))
blocks_ids=defaultdict(list)
for run in runs:blocks_ids[(run['matchup_id'],run['seed'])].append(run)
for (match,seed),rs in blocks_ids.items():
 check('two paired sides '+match+seed,len(rs)==2 and {r['side'] for r in rs}=={'B_LEFT','E_LEFT'})
 for fld in ['B_attempts','B_hits','E_attempts','E_hits','B_real_hp_loss','E_real_hp_loss','phase','winner_id','turns']:
  check('paired invariance '+match+seed+fld,rs[0][fld]==rs[1][fld])
primary={next(r['run_id'] for r in rs if r['side']=='B_LEFT') for rs in blocks_ids.values()}
x=[t for t in att if t['run_id'] in primary]
check('primary receipts 442',len(x)==442)
check('primary hits 112',sum(int(r['hit']) for r in x)==112)
check('primary potential raw 13026',sum(int(r['damage_raw']) for r in x)==13026)
check('primary post 10186',sum(int(r['damage_post_rd_potential']) for r in x)==10186)
check('primary real 8485',sum(int(r['hp_real_loss']) for r in x)==8485)
check('primary 4 censored',sum(r['phase']=='CENSORED_HORIZON' for r in runs if r['side']=='B_LEFT')==4)

with zipfile.ZipFile(ZIP) as z:
 check('ZIP CRC',z.testzip() is None)
 m=json.loads(z.read('SHA256_MANIFEST_R91.json'))
 for n,entry in m['sha256_files'].items():
  b=z.read(n)
  check('R91 manifest '+n,len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256'])

result={'status':'PASS' if not fail else 'FAIL','pass_checks':len(checks),'fail_checks':len(fail),'failing':fail[:35],
'independence':'Separate enumeration using itertools.product, not reused dynamic convolution; CSV run-level aggregates independently reconstructed',
'not_a_second_blind_coder':True,'no_production_certificate':True,'temporal_source_bytes_blocker':'Not tested by this mathematical audit',
'asof':'2026-10-16'}
(OUT/'AUDITORIA_CIENTIFICA_INDEPENDENTE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(result)
if fail:raise SystemExit(1)
