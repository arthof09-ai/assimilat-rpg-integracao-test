from __future__ import annotations
import csv, io, json, zipfile, hashlib, itertools, re, math, statistics, pathlib
from collections import Counter, defaultdict
from fractions import Fraction
from datetime import datetime, timezone

ROOT=pathlib.Path('/mnt/data/dmg_recovery/p0_supreme_continuation_20261016')
OUT=ROOT/'products';OUT.mkdir(parents=True,exist_ok=True)
BASE=pathlib.Path('/mnt/data/dmg_recovery')
ARCH=BASE/'systemic_realignment_20261016/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip'
VLAB=ROOT/'vlab_readonly'
CSV91=VLAB/'R90_ATTACK_RECEIPTS_884.csv'
RUN91=VLAB/'R90_BENCHMARK_RUNS_48.csv'
BLOCK91=VLAB/'R90_PAIRED_BLOCKS_24.csv'
ZIP91=VLAB/'VLAB_R82_R91_BENCHMARK_MULTIDIMENSIONAL_MESTRE_ONLY.zip'
ZIP81=BASE/'f0_material_snapshots_20261016/vlab_readonly/VLAB_R72_R81_BENCHMARK_BESTA_ED_MESTRE_ONLY.zip'
CSV81=BASE/'f0_material_snapshots_20261016/vlab_readonly/R77_DMGMETRICS_ATTACK_RECEIPTS_128.csv'
CSV71=BASE/'post_realignment_gate_20261016/evidence_readonly/DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv'
META=BASE/'f0_material_snapshots_20261016/coordinator_evidence/COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json'
ASOF='2026-10-16'

def dump(name,data):
 p=OUT/name;p.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True,default=str)+'\n',encoding='utf-8');return p

def csvwrite(name,rows,headers=None):
 p=OUT/name;rows=list(rows); headers=headers or list(rows[0])
 with p.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=headers,extrasaction='ignore');w.writeheader();w.writerows(rows)
 return p

def csvread(path):
 with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def exact_die_pmf(expr, bonus):
 matches=re.findall(r'(\d+)d(\d+)',expr,re.I)
 if not matches: raise ValueError('NO_DICE:'+expr)
 groups=[]
 for cnt,sides in matches:
  if int(cnt)>20 or int(sides)>100:raise ValueError('BOUNDS')
  groups.extend([int(sides)]*int(cnt))
 pmf=Counter({int(bonus):1})
 for sides in groups:
  next_=Counter()
  for k,v in pmf.items():
   for x in range(1,sides+1):next_[k+x]+=v
  pmf=next_
 assert sum(pmf.values()) == math.prod(groups)
 return pmf,groups

def metrics(pmf,rd):
 denom=sum(pmf.values())
 return {'rd':rd,'mean_bruto':float(Fraction(sum(k*v for k,v in pmf.items()),denom)),'min_bruto':min(pmf),'max_bruto':max(pmf),
 'mean_apos_rd':float(Fraction(sum(max(0,k-rd)*v for k,v in pmf.items()),denom)),
 'prob_liquido_positivo':float(Fraction(sum(v for k,v in pmf.items() if k>rd),denom)),
 'n_microstates':denom}

# Reuse recovered empirical input only. No claim of new read for each old source.
with zipfile.ZipFile(ARCH) as z:
 assert z.testzip() is None
 prior=list(csv.DictReader(io.StringIO(z.read('readonly_sources/R02_DAMAGE_A_B_C.csv').decode('utf-8-sig'))))
 old_29=list(csv.DictReader(io.StringIO(z.read('readonly_sources/R04_ALL_INITIAL_ACTIONS.csv').decode('utf-8-sig'))))
 out_r03=list(csv.DictReader(io.StringIO(z.read('readonly_sources/R03_INITIAL_DAMAGE.csv').decode('utf-8-sig'))))
cohort=[]
for x in prior:
 attr=int(x['attribute_printed_value']) if x['attribute_printed_value'].strip() else 0
 dice=re.findall(r'(\d+)d(\d+)',x['formula_original'],re.I)
 intrinsic=sum(int(c)*(int(s)+1)/2 for c,s in dice)
 fixed=float(x['gross_conditional_on_hit'])-intrinsic-attr
 if abs(fixed-round(fixed))>1e-7:raise AssertionError(('nonint fixed',x['formula_original'],fixed))
 pmf,ds=exact_die_pmf(x['formula_original'],attr+int(round(fixed)))
 assert math.isclose(metrics(pmf,0)['mean_bruto'],float(x['gross_conditional_on_hit']),abs_tol=1e-8)
 assert math.isclose(metrics(pmf,25)['mean_apos_rd'],float(x['rd25_mean_if_hit']),abs_tol=1e-8)
 k=(x['page_id'],x['attack'])
 rec=dict(page_id=x['page_id'],source_url='https://app.notion.com/p/'+x['page_id'],species=x['species'],attack=x['attack'],formula_literal=x['formula_original'],rank_title=x['title_rank'],rank_body=x['body_rank'],rank_tree=x['ancestor_rank'],attr_code=x['attribute'],attr_value=attr,fixed_intrinsic=int(round(fixed)),dice_intrinsic_dme=intrinsic,mean_bruto=metrics(pmf,0)['mean_bruto'],
 attr_share=(attr/metrics(pmf,0)['mean_bruto'] if attr else 0),page_rank_conflict=(len({x['title_rank'],x['body_rank'],x['ancestor_rank']})>1),source_input='R02_HISTORY_REUSED_NOT_NEW_INDEPENDENT',cost_known=x['cost_documented'])
 cohort.append((rec,pmf,ds))
assert len(cohort)==22 and len({(x[0]['page_id'],x[0]['attack']) for x in cohort})==22

rd_values=[0,5,15,22,25,29,30,31,35,50]
rows=[]
for rec,pmf,ds in cohort:
 for rd in rd_values:
  row={k:rec[k] for k in ['page_id','source_url','species','attack','formula_literal','attr_code','attr_value','rank_title','rank_body','rank_tree']}
  row.update(metrics(pmf,rd));row['scenario']='CONDICIONAL_AO_ACERTO; RD_UNICA_FISICA_SE_COMPATIVEL';rows.append(row)
csvwrite('ANALISE_EXATA_22_ACOES_R02_RD.csv',rows)

pairs=[]
sp=defaultdict(list)
for rec,pmf,ds in cohort:sp[rec['page_id']].append((rec,pmf,ds))
for page_id,effects in sp.items():
 if len(effects)<2:continue
 for (a,pmfa,_),(b,pmfb,_) in itertools.combinations(effects,2):
  dmA=metrics(pmfa,0)['mean_bruto'];dmB=metrics(pmfb,0)['mean_bruto']
  changes=[]
  for rd in range(0,max(max(pmfa),max(pmfb))+1):
   d=metrics(pmfa,rd)['mean_apos_rd']-metrics(pmfb,rd)['mean_apos_rd']
   sign=0 if abs(d)<1e-11 else (1 if d>0 else -1)
   changes.append({'rd':rd,'delta_A_minus_B':round(d,12),'ordering':sign})
  reversal=[x for x in changes if ((dmA-dmB)>1e-8 and x['ordering']<0) or ((dmB-dmA)>1e-8 and x['ordering']>0)]
  tie=[x['rd'] for x in changes if x['ordering']==0 and (metrics(pmfa,x['rd'])['mean_apos_rd']>0 or metrics(pmfb,x['rd'])['mean_apos_rd']>0)]
  pairs.append({'page_id':page_id,'source_url':'https://app.notion.com/p/'+page_id,'source_name':a['species'],'ability_A':a['attack'],'ability_B':b['attack'],
  'gross_A':dmA,'gross_B':dmB,'first_conditional_rd_reversal':reversal[0] if reversal else None,'positive_tie_RD':tie,
  'same_page_two_effects_not_independent_creatures':True,'rank_conflict':a['page_rank_conflict'] or b['page_rank_conflict']})
csvwrite('PAIRS_SAME_PAGE.csv',[{**p,'first_conditional_rd_reversal':json.dumps(p['first_conditional_rd_reversal'],ensure_ascii=False),'positive_tie_RD':json.dumps(p['positive_tie_RD'])} for p in pairs])

# Verify both science cases against authoritative source excerpts read in Notion in current turn.
scorp=[x for x in cohort if x[0]['page_id']=='92bc2b324ede834ca813812ff4783805']
assert len(scorp)==2
rab=next(pmf for rec,pmf,_ in scorp if rec['attack']=='Rabada')
cut=next(pmf for rec,pmf,_ in scorp if rec['attack']=='Corte')
assert metrics(rab,0)['mean_bruto']==28 and metrics(cut,0)['mean_bruto']==28.5
assert metrics(rab,31)['mean_apos_rd']==(1/24) and metrics(cut,31)['mean_apos_rd']==0
oss=next(pmf for rec,pmf,_ in cohort if rec['page_id']=='f0dc2b324ede820ab9470168d4a53315' and rec['attack']=='Rabada')
assert math.isclose(metrics(oss,22)['mean_apos_rd'],0.5)
assert math.isclose(metrics(oss,22)['prob_liquido_positivo'],1/3)

source_proof={
 'source_kind':'REAL_RPG_DOCUMENTED_COMPONENTS; CONDITIONAL_SCENARIOS',
 'source_conflict_scorp':'Page called Escorpião de Diamante by title and Escorpião Ártico in body; no identity adjudication; paired only within page.',
 'paired_ability_source':'https://app.notion.com/p/92bc2b324ede834ca813812ff4783805',
 'rabada':'1d6+1d4+FOR22', 'corte':'1d6+DES25',
 'positive_comparison_RD31':{'rabada':metrics(rab,31),'corte':metrics(cut,31)},
 'experimental_RD_31_not_attributed_to_a_canonical_target':True,
 'conditional_cross_rank':{'attacker':'Frígido Ossário Bronze5, Rabada 1d6+FOR18','attacker_source':'https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315',
 'target':'Sikong Feryn Ouro Negro5, RD física22','target_source':'https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31',
 'only_if_legitimate_hit_and_physical_RD_applies':True,'derived':metrics(oss,22),'no_winning_probability':True},
 'limitations':['Historical R02 formulas relinked to current source excerpts; rank disputes not adjudicated','No general hit chance, actions or costs inferred','A single attack producing >0 net damage does not establish victory','No formal F0 gate certified by formula tests']}
dump('ACHADOS_NOVOS_RD_INVERSAO_RANKS.json',source_proof)

# Genuine new sensitivity analysis (no need for new creature sources); same-page family clustered.
sensitivity=[]
for rec,pmf,ds in cohort:
 if not rec['attr_code']:continue
 base=rec['attr_value']+rec['fixed_intrinsic']
 delta_attr=Counter({k+5:v for k,v in pmf.items()})
 extra6=Counter()
 for k,v in pmf.items():
  for d in range(1,7):extra6[k+d]+=v
 for rd in [0,15,22,25,30,31,35,50]:
  mm=metrics(pmf,rd);aa=metrics(delta_attr,rd);bb=metrics(extra6,rd)
  sensitivity.append({'page_id':rec['page_id'],'species':rec['species'],'ability':rec['attack'],'rd_hypothetical':rd,'base_expected_net':mm['mean_apos_rd'],
  'attribute_plus5_delta_net':aa['mean_apos_rd']-mm['mean_apos_rd'],'extra_1d6_delta_net':bb['mean_apos_rd']-mm['mean_apos_rd'],
  'delta_attr_beats_extra_d6':aa['mean_apos_rd']>bb['mean_apos_rd'],'scenario':'COUNTERFACTUAL TEST source preserved, additional d6 NOT a rule change'})
csvwrite('TEST_SENSIBILIDADE_ATTR5_VS_PLUS1D6.csv',sensitivity)

# VLAB original R91 evidence and arithmetic checking independent from authors' scripts.
with zipfile.ZipFile(ZIP91) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('SHA256_MANIFEST_R91.json'))
 entries=manifest['sha256_files'];checked=0;bad=[]
 for name,meta in entries.items():
  if name not in z.namelist():bad.append('missing:'+name);continue
  b=z.read(name)
  if len(b)!=meta['bytes'] or hashlib.sha256(b).hexdigest()!=meta['sha256']:bad.append(name)
  checked+=1
 assert not bad and checked==len(entries)

atk=csvread(CSV91);runs=csvread(RUN91);blocks=csvread(BLOCK91)
assert len(atk)==884 and len(runs)==48 and len(blocks)==24
assert len({r['run_id'] for r in runs})==48
assert len({(r['matchup_id'],r['seed']) for r in blocks})==24
assert len({(r['matchup_id'],r['seed'],r['side']) for r in runs})==48
assert sum(int(x['hit']) for x in atk)==224
runids={r['run_id'] for r in runs}
assert all(x['run_id'] in runids for x in atk)
for row in atk:
 assert int(row['hp_real_loss'])<=int(row['damage_post_rd_potential']) <= int(row['damage_raw'])
 if int(row['hit'])==0:assert int(row['damage_raw'])==int(row['damage_post_rd_potential'])==int(row['hp_real_loss'])==0

# Mirror duplicates: 2 physical executions in one block. Present both and unique conditional primary.
blockmap=defaultdict(list)
for r in runs:blockmap[(r['matchup_id'],r['seed'])].append(r)
assert all(len(v)==2 for v in blockmap.values())
primary_ids={v[0]['run_id'] for v in blockmap.values() if v[0]['side']=='B_LEFT'}
# Explicitly choose by side rather than iteration order; no premature interpretation of side.
primary_ids={next(r['run_id'] for r in v if r['side']=='B_LEFT') for v in blockmap.values()}
primary=[r for r in atk if r['run_id'] in primary_ids]
assert len(primary)==442

# Verify paired results agree in all totals/results. Totals for paired mirrored runs are not 48 independent biological entities.
mirror_invariants=['B_attempts','B_hits','B_real_hp_loss','E_attempts','E_hits','E_real_hp_loss','B_HP_final','E_HP_final','phase','winner_id','turns']
mirror_bad=[]
for k,v in blockmap.items():
 for f in mirror_invariants:
  if v[0][f]!=v[1][f]:mirror_bad.append([k,f,v[0][f],v[1][f]])
assert not mirror_bad

def attack_stats(A):
 hits=sum(int(x['hit']) for x in A);raw=sum(int(x['damage_raw']) for x in A);post=sum(int(x['damage_post_rd_potential']) for x in A);real=sum(int(x['hp_real_loss']) for x in A)
 return {'n_attempts':len(A),'n_hits':hits,'hit_fraction_descriptive':hits/len(A) if A else None,
 'raw_damage_on_all_attempts_total':raw,'after_RD_on_all_attempts_total':post,'real_hp_loss_total':real,
 'raw_avg_per_attempt':raw/len(A) if A else None,'after_RD_avg_per_attempt':post/len(A) if A else None,'real_avg_per_attempt':real/len(A) if A else None,
 'raw_avg_per_observed_hit':raw/hits if hits else None,'real_avg_per_observed_hit':real/hits if hits else None,
 'RD_removed_total':raw-post,'RD_removed_fraction_of_raw':(raw-post)/raw if raw else None,
 'overkill_or_hp_cap_total':post-real,'realized_fraction_of_potential_post_RD':real/post if post else None}
by_actor=[]
for actor in sorted({r['actor_id'] for r in primary}):
 subset=[r for r in primary if r['actor_id']==actor];by_actor.append({'actor_id':actor,**attack_stats(subset), 'unique_runs_n':len({r['run_id'] for r in subset})})
by_match=[]
for match in sorted({r['matchup_id'] for r in primary}):
 subset=[r for r in primary if r['matchup_id']==match]
 rr=[r for r in runs if r['matchup_id']==match and r['side']=='B_LEFT']
 by_match.append({'matchup_id':match,'distinct_seeds':len({r['seed'] for r in rr}),'censored_primary_runs':sum(r['phase']=='CENSORED_HORIZON' for r in rr),'complete_primary_runs':sum(r['phase']=='COMPLETE' for r in rr),'winner_ids':sorted({r['winner_id'] for r in rr}),
  'cohorts':sorted({r['cohort'] for r in rr}),**attack_stats(subset)})

VLAB_SUM={
 'source_VLAB_R91_ZIP':str(ZIP91), 'archive_sha256':sha(ZIP91),'entries':len(zipfile.ZipFile(ZIP91).namelist()),
 'manifest_items_checked':checked,'manifest_items_expected':len(entries),'crc':'PASS','run_ids':48,'mirrored_blocks':24,
 'primary_selection_rule':'B_LEFT side only; one run per matchup×seed; mirroring used for consistency, not independent replication',
 'all_48_runs':attack_stats(atk),'primary_24_runs':attack_stats(primary),
 'primary_completed':sum(r['phase']=='COMPLETE' for r in runs if r['side']=='B_LEFT'),
 'primary_censored':sum(r['phase']=='CENSORED_HORIZON' for r in runs if r['side']=='B_LEFT'),
 'per_actor_primary':by_actor,'per_match_primary':by_match,'mirror_agreement_24_blocks':'PASS',
 'inference_warning':'24 blocks within 6 matchup families, not 24 independent creatures; 48 runs include paired mirrors; no population probabilities from 2 seeds per cohort per matchup',
 'source_gates':sorted({x['admission'] for x in atk}),
 'no_official_benchmark':all(r['official_benchmark']=='0' for r in runs),
 'PA_spent_in_primary':sum(int(r['pa_spent']) for r in primary),
 'PA_efficiency_warning':'R91 attacks have PA_spent=0; cannot claim resource efficiency for costly abilities.',
 'overkill_definition':'post_RD_potential − HP_real_loss; includes remaining HP cap and other execution clipping, do not attribute everything to rule RD',
 'unit_note':'realized attack receipt, nested in runs, paired mirror, seeds, and matchup family',
 'scientific_result':'Precision and mitigation contribute separately, demonstrating inadequacy of raw DME to explain realized damage in selected conditional fights.'}
dump('ANALISE_EMPIRICA_VLAB_R91_DMG.json',VLAB_SUM)
csvwrite('R91_ACERTO_RD_REAL_POR_CONFRONTO.csv',by_match)
csvwrite('R91_ACERTO_RD_REAL_POR_ATOR.csv',by_actor)

# Material integrity of R71/R81 as recovered in older deliveries. Not cross-cohort independence.
old_vlab=[]
for stage,path in [('R71',CSV71),('R81',CSV81),('R91',CSV91)]:
 assert path.exists()
 source=csvread(path)
 old_vlab.append({'stage':stage,'file':path.name,'n_receipts':len(source),'sha256':sha(path),'headers':list(source[0]),'grain':'ATTACK_RECEIPT nested in runs or seeds; NOT independent creatures'})
assert [x['n_receipts'] for x in old_vlab]==[684,128,884]
dump('CROSSWALK_VLAB_R71_R81_R91.json',{'historical_distinct_delivery_files':old_vlab,'summed_receipts_if_reported':1696,
 'summed_receipts_not_statistical_sample_size':True,'run_id_cross_linkage':'PENDING: source versions/seeds/family dependencies not fully reconciled across R71/R81/R91',
 'position':'Use R91 per-block conditional evidence alone for current science; R71/R81 retained separate, do not merge hit rates without common protocol.'})

# F0 and plan state - add deltas only, no new PASS.
prior_xwalk=json.load(open(BASE/'f0_material_snapshots_20261016/evidence_readonly/F0_OITO_REQUISITOS_CROSSWALK.json'))
plan=json.load(open(BASE/'f0_material_snapshots_20261016/evidence_readonly/MATRIZ_ATIVACAO_19_FASES.json'))
guarantees=json.load(open(BASE/'f0_material_snapshots_20261016/evidence_readonly/MATRIZ_E01_E24.json'))
gates=json.load(open(BASE/'f0_material_snapshots_20261016/evidence_readonly/MATRIZ_8_GATES_TRANSVERSAIS.json'))
assert len(prior_xwalk['items'])==8 and len(plan['phases'])==19 and len(guarantees['items'])==24 and len(gates['items'])==8
coord=json.load(open(META))
assert len(coord['snapshot_entries'])==7
f0=[]
for item in prior_xwalk['items']:
 id_=item['id'];before=item['state'];after=before;delta='NO CHANGE';pending=item['minimum_pending'];
 if id_=='F0-A5':after='PARTIAL: 7/7 Notion Markdown attachments reported, 0/7 independent byte readbacks';delta='Previous coordinator material physically linked; connector download by file_upload_id returned empty {}, signed URLs resolved but file transfer to current sandbox not achieved';pending='Signed S3 authenticated transfer or authorized source-body transfer; byte SHA per file; scope + version; legitimate writer+second audit'
 if id_=='F0-A6':after='PARTIAL: 332 distinct direct links (coordinator; file); 239 subtree branch links reported, union not proven';delta='Existing 8-root inventory preserved; no rescan or double counting';pending='Identity-level dedup direct+branch IDs, provenance/version + root coverage; D0 global open'
 if id_=='F0-A7':after='PRESEAL: 8 reserved ids, 0 independently certified holdout';delta='Reused documented prior negative literal exposure scan (2685 members, 0 matches) no new blind certification';pending='Independent assessor, family alias/versions and exposure closure; blind source not consumed'
 if id_=='F0-A8':after='HOLD authority/writer/epoch/lease, independent blind coder absent';pending='Writer/collision state and second coder by competent review (not this assistant)'
 f0.append({'id':id_,'criterion':item['criterion'],'authority':item['authority'],'before':before,'after':after,'delta':delta,'formal_new_PASS':False,
 'next_minimum':pending,'writer_required':item['writer_required_for_documentary_acceptance'],'second_coder':item['second_coder_required'],'VLAB_required':item['v-lab_required']})
dump('PRODUTO_1_F0_ANTES_DEPOIS.json',{'formal_F0_before':'4/8','formal_F0_after':'4/8','crosswalk_not_normative':True,'steps':f0,'first_technically_closable':'F0-A5; needs byte readback and legitimate writer+independent revision; A6/A7/A8 remain open'})

authorities=[]
for item in coord['snapshot_entries']:
 authorities.append({'name':item['name'],'source_id':item['source_page_id'],'url':item['source_url'],'edited_current_at_snapshot':item['source_notional_last_edit_at_snapshot'],
  'sha256_of_previously_fetched_UTF8_body':item['source_content_sha256_utf8_expected'],
  'expected_size_UTF8':item['attachment_utf8_bytes_at_upload'],'notion_attachment_filename':item['attachment_filename'],
  'notion_attachment_file_upload_id':item['attachment_file_upload_id'],'attachment_location':item['notion_inbox_page'],
  'pointer_physically_seen':True,'attachment_bytes_readback':'NOT_VERIFIED: Notion connector download() returned {}','library_body_bytes':'NOT_PERSISTED_IN_THIS_CYCLE',
  'scope':'Rendered Notion page body only; not entire subtree/external binary/media or dated 7 October historical snapshot'})
dump('PRODUTO_2_MANIFESTO_7_AUTORIDADES_STATUS_BYTES.json',{'source':'Coordinator prior attachment manifest authenticated local copy', 'entries':authorities,
 'seven_physical_attachments_exist':True,'post_upload_downloaded_verifiable_bytes':0,
 'alternate_signed_url':'Notion stable file pointers successfully resolved into expiring AWS signed URLs; transferring into container rejected by runtime condition that URL be first opened through host browsing; no user secret exposed; no post-upload byte proof',
 'blocker_verified':'NOTION_DOWNLOAD_ATTACHMENT returns empty object {} for legitimate file_upload_id; one signed download route also unavailable; do not retry in blind loop',
 'temporal_notice':'Creation of Sheet and Transformation last edited 2026-10-09, after prereg 2026-10-07; historical originals were not reconstructed',
 'formal_F0_A5':'HOLD'})

phase_delta=[]
for ph in plan['phases']:
 name=ph['phase'];d={**ph}
 if name=='F0':d['new_science']='Documented blocker A5 no 7/7 verified bytes. A6/A7 partial, A8 HOLD. Formal F0 stays 4/8.'
 if name=='F4':d['new_science']='22 R02 formula PMFs recomputed exactly across 10 RDs and 21 attr counterfactuals; preterminal research only.'
 if name in ('F8','F9','F10'):
  d['new_science']='Exact within-page ordering reversal at RD31 for two source abilities; role of distribution/attributes conditioned on physical mitigation.'
 if name in ('F12','F16'):
  d['new_science']='R91 native conditional attack receipts analyzed by unique mirrored seed block, precision/mitigation/HP cap separately, censures preserved; no official benchmark.'
 d['terminal_phase_accepted_in_this_cycle']=False
 phase_delta.append(d)
dump('PRODUTO_4_MATRIZ_PLANO_SUPREMO_19_FASES.json',{'operation':'OP-DMG-CORPUS-EMP-01','baseline':'DMG-RANK-01 v1.1','plan_already_approved':True,'phase_count':19,'phases':phase_delta,
 'next':'A5 readback via genuinely different authorized route; A6/A7 independent coverage; corpus science ongoing without pretending production completion.'})
dump('PRODUTO_4_E01_E24_GATES_CONSERVADOS.json',{'guarantees':guarantees,'transversal_gates':gates,'change':'No terminal guarantee or cross-gate promoted; math replay materially tested locally; blind second coder absent.'})

# README/PSV generated separately for legibility.
summary={
 'as_of':ASOF,'operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','baseline':'DMG-RANK-01 v1.1 INALTERADA',
 'historical_source_rows_R02':len(cohort),'source_page_ids_R02':len({x[0]['page_id'] for x in cohort}),
 'within_page_pairs_R02':len(pairs),'total_exact_RD_rows':len(rows),'sensitivity_counterfactual_rows':len(sensitivity),
 'source_conflicts_not_solved':len([x[0] for x in cohort if x[0]['page_rank_conflict']]),
 'v_lab_R91_unique_block_reconciliation':'24 distinct matchup×seed / 48 mirrored runs',
 'R91_raw_attack_receipts':len(atk),'R91_hit_receipts':sum(int(r['hit']) for r in atk),'R91_primary_attempts':len(primary),
 'R91_primary_hit_receipts':sum(int(r['hit']) for r in primary),
 'R91_primary_censored_runs':VLAB_SUM['primary_censored'],'F0_formal':'4/8 unchanged',
 'seven_text_attachments':'7 pointers / zero audited postupload bytes','new_v11_genuine_case':'Not certified; no new admissible real no-formula source',
 'v11_test_trail':'Existing masked-martelo control preserved; no new fake canonical formula',
 'no_normative_changes':True,'party_write':False,'authoritative_Notion_write':False}
dump('SCIENTIFIC_READOUT_METRICS.json',summary)
print(json.dumps(summary,indent=2))
