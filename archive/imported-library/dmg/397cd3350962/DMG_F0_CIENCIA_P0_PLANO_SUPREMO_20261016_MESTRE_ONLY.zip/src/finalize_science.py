from __future__ import annotations
import csv,json,hashlib,zipfile,math,os,pathlib
from collections import Counter
from fractions import Fraction
from datetime import datetime
from importlib.machinery import SourceFileLoader

ROOT=pathlib.Path('/mnt/data/dmg_recovery/p0_supreme_continuation_20261016')
OUT=ROOT/'products';BASE=pathlib.Path('/mnt/data/dmg_recovery')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
get=lambda n:json.loads((OUT/n).read_text(encoding='utf8'))
put=lambda n,o:(OUT/n).write_text(json.dumps(o,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')

# Reproduce *new* masked-with-RE/FIP comparison from two actual, already explicit source pages.
model=SourceFileLoader('dmg_reused_exact_model',str(ROOT/'build_science.py')).load_module()
case=[]
for item in [
 ('MART-ON-MED','Martelo do Portão Faminto','https://app.notion.com/p/3f5c2b324ede81658982d8f47b3ad647','Ouro Negro','Média',59,69,'8d10+12',0,'CONTUNDENTE/IMPACTO','1 Ação Padrão, golpe corpo a corpo, ataque vs CA; extra +6d8 reservado para estruturas com 25 PA/1 descanso, não criaturas'),
 ('MAN-OU-ENT','Manopla do Trovão Cativo','https://app.notion.com/p/3f5c2b324ede81f5ac62fb940204cdac','Ouro','Entrada',22,28,'5d8+3',22,'RAIO','Adicional a golpe corpo a corpo que já acertou, 22 PA/1 descanso, sem novo teste/ação; RD/resistência de Raio apenas para pool adicional')]:
  cid,name,url,rank,fip,low,high,expr,PA,dtype,conditions=item
  import re
  dm=sum(int(c)*(int(s)+1)/2 for c,s in re.findall(r'(\d+)d(\d+)',expr))
  fixed=float(expr.split('+')[-1]) if '+' in expr else 0
  pmf,dice=model.exact_die_pmf(expr,fixed)
  metrics=[model.metrics(pmf,rd) for rd in [0,15,22,25,30,35,50,60]]
  case.append({'id':cid,'real_source_name':name,'source_url':url,'source_has_explicit_damage':True,'v11_priority':'DO_NOT_OVERWRITE_SOURCE_EXPLICIT','rank_effect':rank,'fip':fip,'v11_intrinsic_band':[low,high],'explicit_formula':expr,'explicit_conditional_dme':dm+fixed,
   'inside_generic_intrinsic_band_descriptive':low<=dm+fixed<=high,'not_a_violation_if_outside':True,'damage_type':dtype,'PA_per_trigger':PA,'conditions':conditions,
   'derived_PMFS_under_hypothetical_type_compatible_RD':metrics,'evidence':'Notion page read current turn; experimental masked comparison only, no official damage modified',
   'no_universal_chance_to_hit':True})
put('TRILHA2_V11_DUAS_FONTES_REAIS_MASCARADAS.json',{'description':'Comparação da regra v1.1 com duas fontes explícitas, sem aplicar retroativamente v1.1', 'cases':case,
 'trilha1':'NOT_FOUND_ELIGIBLE in existing targeted cohorts: no offensive source with no explicit damage and competent RE+FIP+delivery has been certified',
 'selection':'These two are already-existing known reference cases, not newly discovered independent creatures or a new source census'})

# Independent smaller exact dice check for Trail 2.
def independent(expr,bonus):
 import itertools,re
 a=[]
 for count,d in re.findall(r'(\d+)d(\d+)',expr):a += [range(1,int(d)+1)]*int(count)
 c=Counter(sum(t)+bonus for t in itertools.product(*a));return c
for row in case:
 expr=row['explicit_formula'];bonus=int(expr.split('+')[-1]);x=independent(expr,bonus)
 for m in row['derived_PMFS_under_hypothetical_type_compatible_RD']:
  v=Fraction(sum(max(k-m['rd'],0)*freq for k,freq in x.items()),sum(x.values()))
  assert abs(float(v)-m['mean_apos_rd'])<1e-9
assert case[0]['explicit_conditional_dme']==56 and case[1]['explicit_conditional_dme']==25.5

# Recovery manifest of scope of twenty physical index readbacks. Do NOT claim global coverage.
root_counts={'Bestas Demoníacas':14,'Personagens':233,'Itens':17,'Armas':19,'Magias':26,'Artefatos':15,'Matrizes':8,'Inscrições':0}
branches={'Água':40,'Gelo':25,'Vento':10,'Fogo':24,'Raio':17,'Dark':26,'Caos':14,'Planta':28,'Luz':12,'Terra':32,'Normal':10,'Espectro':1}
assert sum(root_counts.values())==332 and sum(branches.values())==239
summary={'scope':'20 named Mestre Notion index pages physically refetched once to compute an identity union at depth 1/2',
 'root_counts':root_counts,'beast_12_branch_counts':branches,
 'root_direct_children_uuid_distinct':332,'branch_direct_children_uuid_distinct':239,'root_to_branch_uuid_intersection':0,
 'union_direct_uuid_unique':571,'twelve_branch_parent_uuids_already_among_root_332':True,
 'parent_index_pages_8':'not included in 571 child UUID count','more_nesting_not_walked':True,
 'not_global_D0':True,'not_571_damaging_sources':True,'not_571_creature_independent':True,'by_uuid_not_by_species_name':True,
 'source_roots':['3ecc2b324ede815c902bdbd889827bc4','3ecc2b324ede818cb8e0cb65caf84542','3edc2b324ede8184b487c0735f1eabb4','3edc2b324ede8140b8a0e645630b8387','f96c2b324ede82b8a2f2011efade45bd','3edc2b324ede8164bd84fc7e4673cb76','3edc2b324ede815091c6df1cf42d2484','7f0c2b324ede83638d1481aedd3eca12'],
 'source_branches':['824c2b324ede8232bc8c81ff7cf58802','85fc2b324ede82c99db101ab105f182f','17bc2b324ede82ffb5028109bbee810c','988c2b324ede8398b6f8019b49e032ea','5dac2b324ede82ddbf4c81db6c5623b7','805c2b324ede82708b9e81ba40cda2c1','f81c2b324ede83f88fdc0118d5d8ed62','6edc2b324ede833aa26901d305cff5bb','f76c2b324ede833b875f81f4ea32f47d','75fc2b324ede82f4a9fd01bba8d41833','b8ac2b324ede8210a9f00165f3d8ada6','9f5c2b324ede830d81ac01194b033054'],
 'method':'single targeted Notion fetch of 20 pages, parse direct <page url> IDs, two set union and intersection checks, source timestamps available from Notion; aggregate states reproducible but full 571 UUID enumeration not materialized here',
 'A6_gate':'PARTIAL; only target two-level direct UUIDs, no census of all source surfaces, mirrors, definitions or effects'}
put('PRODUTO_1_F0_A6_UNIAO_571_IDS_DIRETOS.json',summary)

# For science source-level summary count, use repaired R02 data and R91 actual.
sc=get('SCIENTIFIC_READOUT_METRICS.json');r91=get('ANALISE_EMPIRICA_VLAB_R91_DMG.json')
scientific=r91['primary_24_runs'];pairs=list(csv.DictReader((OUT/'PAIRS_SAME_PAGE.csv').open()))
sensitive=list(csv.DictReader((OUT/'TEST_SENSIBILIDADE_ATTR5_VS_PLUS1D6.csv').open()))
plus6=sum(float(x['extra_1d6_delta_net'])>float(x['attribute_plus5_delta_net'])+1e-10 for x in sensitive)
equal=sum(abs(float(x['extra_1d6_delta_net'])-float(x['attribute_plus5_delta_net']))<=1e-10 for x in sensitive)
summary={'reused_historical_source_ability_rows':22,'reused_historical_source_page_ids':15,'pairs_same_page':len(pairs),'RD_contrasts_computed_exact':220,
 'attribute_bonus_vs_die_sensitivities':len(sensitive),'extra_1d6_outperforms_plus5_attr_in_hypothetical_conditions':plus6,
 'ties':equal,'plus5_outperforms_extra_d6_in_hypothetical_conditions':len(sensitive)-plus6-equal,
 'R91_24_blocks':r91['mirrored_blocks'],'R91_primary_24_runs_attack_stats':scientific,'R91_CENSORED_primary_runs':r91['primary_censored'],
 'R91_no_resource_efficiency_due_all_zero_PA':True,'science_cannot_prove_global_imbalance':True,'R91_run_mirroring':'B_LEFT primary only',
 'critical_definitions':'No claim of victory probabilities or general hit probabilities from selected conditional fights',
 'interpretation':'Attributes dominate means in selected historical formulas but RD tails can occasionally favor larger dice over fixed bonus; both hit and RD are key in native receipts.',
 'scoped_findings':['At RD31 1d6+1d4+22 outruns 1d6+25 although gross means reversed: expected 1/24 vs 0',
 'At physical RD22 and IF a valid hit, Bronze5 Frígido Ossário 1d6+FOR18 has P(net>0)=1/3, E(net)=0.5 vs Feryn physical armor; not a win chance',
 'Among primary 24 mirrored R91 runs, 442 attempts 112 hits and 8485 realized HP damage, with 4 censored runs',
 'R91 sandbox conditional version different from campaign; cannot claim class-wide imbalance']}
put('PRODUTO_3_SINTESE_ANALITICA_NOVA.json',summary)

# History preservation references, no external writes.
manifest=json.loads((BASE/'f0_material_snapshots_20261016/coordinator_evidence/COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json').read_text())
files=[BASE/'systemic_realignment_20261016/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip',
 BASE/'post_realignment_gate_20261016/DMG_POS_REALINHAMENTO_F0_GATE_PROVA_V11_20261016_MESTRE_ONLY.zip',
 BASE/'f0_material_snapshots_20261016/DMG_F0_CONTINUIDADE_SNAPSHOTS_HOLDOUT_20261016_MESTRE_ONLY.zip',
 ROOT/'coordinator_readonly/DMG_F0_A5_A6_HOLDOUT_GATES_20261016_MASTER_ONLY.zip',
 ROOT/'vlab_readonly/VLAB_R82_R91_BENCHMARK_MULTIDIMENSIONAL_MESTRE_ONLY.zip']
put('MANIFESTO_REFERENCIAS_HISTORICAS.json',{'files':[{'name':f.name,'bytes':f.stat().st_size,'sha256':sha(f),'stored_readonly_local':str(f)} for f in files],
 'no_historical_overwrite':True,'operation':'OP-DMG-CORPUS-EMP-01'})

p=OUT/'PSV_PLANO_SUPREMO_CONTINUIDADE_20261016.md'
text=f'''# PSV DMG / CONCLUSÃO DA MISSÃO PENDENTE — 16/10/2026

**OPERATION:** CM-000001 / OP-DMG-CORPUS-EMP-01. **Baseline:** DMG-RANK-01 v1.1 oficial, intacta. **AS-OF:** 2026-10-16. **Master-side.**

## VEREDITO GERAL

F0 formal **4/8 ANTES → 4/8 DEPOIS**. Nenhum PASS formal novo; nenhuma autorização de writer, lease, epoch, segunda codificação cega ou promoção normativa foi presumida. **Avanço científico efetivamente novo**, distinto da recuperação documental anterior: análise matemática exata de 22 habilidades (15 páginas R02, reutilizadas), 220 contrastes de RD e 160 testes de sensibilidade; 8 pares dentro da mesma página; análise independente dos 24 blocos espelhados R91 com 442 tentativas primárias e 112 acertos. O auditor local de matemática está em **PASS** (não equivale a segundo pesquisador/codificador cego).

## PRODUTO 1 — F0 ANTES/DEPOIS

- A1–A4: 4 requisitos documentais históricos, sem nova certificação ou alteração. A1–A8 = mapa operacional, não identificação canônica homologada de oito certificados.
- A5: **7/7 arquivos markdown já anexados pela Coordenação no Inbox Mestre**. Objeto `notion_download_attachment(file_upload_id)` retornou JSON vazio `{{}}` ao executar o readback neste ciclo. O mecanismo de signed URLs do Notion retornou sete URLs temporários, mas a transferência ao contêiner foi recusada com a condição `url not viewed in conversation before`. **0/7 hashes dos bytes *baixados depois do upload* autenticados. BLOCKER-VERIFICADO desta rota, sem repetição automática.** O manifesto de upload prévio contém sete IDs, hashes de corpo original e timestamps. Nem os hashes prévios nem a referência na Inbox certificam pós-upload bytes.
- A6: novo cruzamento por UUID de 8 índices (332 referências diretas distintas) com 12 ramos elementais de Bestas (239 filhos diretos distintos). Intersecção **0 IDs**; união **571 UUIDs distintos no escopo de duas profundidades**. Os 12 próprios pais dos ramos estão nos 332 IDs da raiz. Esses 571 IDs não equivalem a 571 efeitos, 571 espécies, D0 global ou cobertura recursiva fechada; aliases, hierarquia, versão e Party não certificados. Ver `PRODUTO_1_F0_A6_UNIAO_571_IDS_DIRETOS.json`.
- A7: oito fontes reservadas, não abertas; procura histórica local negativa por nomes/IDs relatada anteriormente. Não declarar holdout cego ou exclusão de exposição por parentesco sem auditor independente.
- A8: **HOLD writer/INSTANCE-ID/epoch/lease, collision domain e segundo codificador cego E06/E07**; segunda implementação matemática local não substitui segunda codificação nem segundo auditor formal.
- F1–F18: plano existente 19/19 **definido**; sem nova fase terminal certificada. Novas provas indexadas a F4/F8/F9/F10/F12/F16 em matriz de continuidade.

## PRODUTO 2 — SITUAÇÃO DAS CÓPIAS DOCUMENTAIS

Sete corpos atuais estão materialmente anexados ao Inbox Mestre (IBX-102) pela Coordenação. **Ainda NÃO foram preservados como sete arquivos físicos autenticados na Biblioteca neste ciclo**. O arquivo `PRODUTO_2_MANIFESTO_7_AUTORIDADES_STATUS_BYTES.json` especifica SHA-256 esperado de cada corpo, URL/ID de autoridade, nome/ID de anexo, tamanho e STATUS DE READBACK PENDENTE. Escopo = `<content>` Markdown vigente na captura, não REST completo, páginas filhas, mídia externa nem snapshot datado em 07/10. Duas fontes (Criação de Ficha e Transformação Espiritual) tiveram edição em 09/10, posterior ao pré-registro de 07/10: não há diff histórico autenticado.

**Rota alternativa precisa:** exportar anexos por ferramenta capaz de acessar signed S3 privado no contexto autorizado **ou** transferir corpos da API Notion para arquivo local por integração legítima, persistir `/Comestre/OP-DMG-CORPUS-EMP-01/` e comparar bytes e SHA-256 por leitor independente. Somente então reavaliar A5, inclusive o escopo aceito pela norma. Não produzir mais hashes decorativos.

## PRODUTO 3 — CIÊNCIA FUNCIONAL REAL E TEST

### Inversão por RD dentro da mesma fonte

Página Escorpião de Diamante (`https://app.notion.com/p/92bc2b324ede834ca813812ff4783805`), fonte com conflito entre título e nome do corpo. Rabada `1d6+1d4+FOR22`: média bruta 28. Corte `1d6+DES25`: média bruta 28,5. Em RD30 as duas médias líquidas são 1/6; em RD31 **Rabada=1/24 e Corte=0**, uma inversão objetiva na mesma página, não duas criaturas independentes. A RD31 é apenas stress hipotético, não RD oficial de um ator não citado.

### Ataque inferior contra RD superior

Frígido Ossário Bronze5 `1d6+FOR18` vs **RD físico 22** confirmada da armadura de Sikong Feryn Ouro Negro5. **Se** o ataque é validamente aplicado e a RD física é a competente, probabilidade de dano positivo por acerto = **1/3**, média líquida por acerto **0,5**, máximo **2**. O hit-rate, ações/custos e a possibilidade de vitória continuam indeterminados; dano possível ≠ vitória provável.

### Atributos versus dados

22 ações R02 reutilizadas, 15 páginas únicas, 8 pares intra-página; modelos EXATOS com PMF discreta e RD0/5/15/22/25/29/30/31/35/50. Nos **160 cenários TEST** +5 no atributo versus adicionar 1d6: aumento fixo +5 foi superior em {len(sensitive)-plus6-equal}, 1d6 extra foi superior em {plus6}, e {equal} empataram. Estes são contrastes de sensibilidades em cenários artificiais, altamente correlacionados, NÃO estatística de 160 criaturas. Demonstram como o efeito de alteração no atributo pode ser nulo em limiares em que dado maior ainda consegue cruzar a RD.

### R91 — golpe realizado não é DME bruto

ZIP R82–R91 readback físico e auditoria **{r91['manifest_items_checked']}/{r91['manifest_items_expected']} SHA de manifesto + CRC PASS**. Os 884 recibos foram reconciliados aos 48 RUN-IDs, emparelhados por 24 pares matchup×seed. Para retirar mirroring na análise: selecionar **B_LEFT** por bloco, resultando em **442 ataques e 112 acertos** (25,34% descritivo). Dano bruto observado **13.026**; após RD potencial **10.186**; perda real de Vida **8.485**. A RD retirou 2.840 (21,80% do dano bruto) e o limite de Vida/overkill reduziu outros 1.701 (16,70% do dano pós-RD). Médias por tentativa: **29,47 bruto, 23,05 pós-RD, 19,20 Vida efetivamente perdida**. Foram **20 runs primárias concluídas e 4 censuradas**, espelhadas em 40 concluídas/8 censuradas. Em confronto Ouro1×Ouro1, as quatro primárias ficaram censuradas no horizonte 60; 240 tentativas geraram dois acertos: um resultado de cenário, não taxa populacional. Gastos de PA dos ataques registrados = zero; eficiência PA das habilidades com custos não é admissível. Todas as execuções R91 são **SANDBOX CONDICIONAL**, nenhuma célula oficial.

R71 684 recibos e R81 128 foram identificados e mantidos em interfaces separadas; RUN-IDs/versões/famílias ainda precisam de crosswalk para qualquer combinação, não declarar `684+128+884` observações independentes.

### Regra v1.1, duas trilhas

**Trilha 1 genuína:** nenhuma fonte originalmente sem dano mas com RE/FIP/entrega completos foi certificada nas buscas dirigidas disponíveis; manter matriz negativa sem atribuição automática de classificação.

**Trilha 2 TEST:** comparar Martelo do Portão Faminto (Ouro Negro, FIP Média, dano canônico explícito `8d10+12`, DME56) com banda v1.1 `59–69`; e Manopla do Trovão Cativo (Ouro Entrada, `+5d8+3` Raio, DME25,5) com banda `22–28`. A manopla adiciona pool após acerto, custa 22 PA e é 1/descanso: não cria ataque novo. Martelo só concede +6d8/25PA extra contra estrutura, não criatura. A divergência antiga do Martelo NÃO é infração da v1.1; dano explícito prevalece. Em ambos, PMF/RD condicional em TEST, sem retcon.

## PRODUTO 4 — PLANO SUPREMO E NEXT

Matriz existente F0–F18, E01–E24 e oito gates preservados, com apontadores a novos artefatos científicos. O gate atual continua o F0. Não adentrar v2 ou promover 17 contratos VLAB. Próximo fechamento legítimo: A5 byte-readback pela rota técnica alternativa, depois A6 estrutura global+origem, A7 bloqueio familiar+segundo auditor, A8 identidade/writer. Produção científica na trilha permitida F3–F12 segue em modo experimental não terminal enquanto F0 formal permanecer aberto.

## SUCESSÃO / FAST-RESUME

- **LAST-VERIFIED:** sete anexos listados na Inbox e download bloqueado; uniões UUID 332 + 239 = 571 IDs sem interseção direta; 22 ações R02; prova RD31/RD22; R91 344/344 manifest, 24 pares, 884 recibos e 442 primários.
- **FIRST-PENDING:** primeira via legítima que gere sete arquivos físicos e readback de bytes autenticados, sem repetir ferramenta que já retornou `{{}}`; segunda frente independente: consolidar identidade do censo e gate E06/E07 com codificador competente.
- **DENOMINATORS:** F0 4/8; plano 19 fases; garantias 24; gates 8; anexos 7 apontados/0 readback pós-upload; árvore 20 índices, 571 UUIDs diretos duas profundidades (NÃO D0); R02 15 páginas/22 efeitos/8 pares; R91 24 blocos, 48 runs, 884 ataques; censuras 8 runs.
- **NO-REPEAT:** não repetir R02–R04, Galidemus/Iskiel, 24 Bestas, 148 tests, 7 fingerprints, 12 branches ou 332 direct IDs sem hipótese nova; não contornar decisão de divisão Mestre/Party; não reiniciar DMG v2.
- **CONFLICTS:** Escorpião Diamante title/body; R02 árvore vs rank; Criação Ficha/Transformação versões de 09/10 contra pré-registro 07/10; recursos binários e subpáginas não preservados no snapshot textual.
- **UNKNOWN-EFFECT:** nenhuma escrita ambígua nesta instância; download `{{}}` e signed URLs sem bytes não constituem mutação. Auditoria do estado original de todas as fichas não executada, mas não houve escrita nelas pela instância.
- **NEXT-5:** 1 readback bytes A5 com rota distinta; 2 mapear diferença temporal histórica se arquivo autenticado; 3 auditar parentesco das 8 reservas holdout sem ler conteúdo; 4 solicitar segundo codificador independente via autoridade; 5 ampliar contrastes de fonte reais por tipo×rank somente em estratos admissíveis.
- **TARGET-REMAINDER:** fechar F0 legitimamente antes de qualquer certificação terminal das fases seguintes.
- **AUTHORITY/WRITER:** writer/INSTANCE/lease/epoch/ACK produção no Notion NÃO PROVADOS; laboratório TEST e Biblioteca do OP apenas.
- **NAC-PASS:** investigação, ciência local e integridade ZIP PASS; F0 formal, segunda revisão cega, snapshots integrais e upgrade canônico HOLD.
- **HANDOFF:** usar este mesmo pacote, scripts e arquivos primários; read-only para coordenação até writer legitimado.
'''
p.write_text(text,encoding='utf8')

# Checkpoint machine readable
checkpoint={'AS_OF':'2026-10-16','OPERATION':'CM-000001 / OP-DMG-CORPUS-EMP-01','BASELINE':'DMG-RANK-01 v1.1 unalterada',
 'LAST_VERIFIED':'F0 4/8; current attachment refs 7/7; Notion readback 0/7; direct tree 571 IDs 2-level; 22 historical R02 formulas with new exact RD models; R91 884 receipts 24 blocks 344 manifest',
 'FIRST_PENDING':'transfer and independently hash seven attachments bytes in allowed local/LIBRARY route, then independent writer/codebook and scope review',
 'DENOMINATORS':{'F0':{'pass':4,'total':8},'plan_phases':19,'method_guarantees':24,'transversal_gates':8,'Notion_links_depth_1_2':571,'D0_global':None,'R02_source_pages':15,'R02_effects':22,'R91_mirrored_blocks':24},
 'NO_REPEAT':['R02/R03/R04 as novel observations','24 Bestas baseline','148 F0 tests','Notion seven hashes','download_attachment with no changed hypothesis'],
 'CONFLICTS':['Scorpion title/body identity','source rank R02','Creation Ficha and Spiritual Transformation 09/10 vs prereg 07/10'],
 'UNKNOWN_EFFECT':'None known on canonical writes: this execution has no Notion write, no Party write; signed download unsuccessful without file creation',
 'NEXT_5':['Genuinely different authorized byte transfer','Temporally authentic legacy version if source exists','Holdout familial audit before reveal','Second independent researcher coder','Continue PMF/efficiency on eligible strata'],
 'TARGET_REMAINDER':'F0 A5/A6/A7/A8 under competent gate then F1 phase release; F3-F12 science sandbox can continue',
 'AUTHORITY_WRITER_STATE':'NOT PROVEN; DO NOT ACK/EDIT NOTION','NAC_PASS':'LOCAL_SCIENCE_PASS; FORMAL_F0_HOLD; CANON_HOLD',
 'HANDOFF':'Persist in existing OP Library, no duplicate plan/operation, manifest+script reproducible'}
put('FAST_RESUME_DMG_P0.json',checkpoint)
print('Prepared',len(list(OUT.iterdir())),'output files; PSV size',p.stat().st_size)
