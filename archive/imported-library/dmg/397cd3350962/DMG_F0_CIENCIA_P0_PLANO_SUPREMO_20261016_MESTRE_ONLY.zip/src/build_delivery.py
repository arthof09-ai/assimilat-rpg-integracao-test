import pathlib,hashlib,json,zipfile,io,shutil,os,csv
ROOT=pathlib.Path('/mnt/data/dmg_recovery/p0_supreme_continuation_20261016');OUT=ROOT/'products'
NAME='DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip'
p=ROOT/NAME
files=[]
for x in sorted(OUT.iterdir()):
 if x.is_file():files.append((x,'products/'+x.name))
for name in ['build_science.py','audit_science_independent.py','finalize_science.py','build_delivery.py']:
 x=ROOT/name;files.append((x,'src/'+name))
with zipfile.ZipFile('/mnt/data/dmg_recovery/systemic_realignment_20261016/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip') as z:
 (ROOT/'readonly_R02_DAMAGE_A_B_C.csv').write_bytes(z.read('readonly_sources/R02_DAMAGE_A_B_C.csv'))
files.append((ROOT/'readonly_R02_DAMAGE_A_B_C.csv','readonly_sources/R02_DAMAGE_A_B_C.csv'))
for name in ['R90_ATTACK_RECEIPTS_884.csv','R90_BENCHMARK_RUNS_48.csv','R90_PAIRED_BLOCKS_24.csv']:
 files.append((ROOT/'vlab_readonly'/name,'readonly_sources/R91_'+name))
files.append((ROOT/'coordinator_readonly/COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json','readonly_sources/COORD_ATTACHMENT_MANIFEST_ORIGINAL.json'))
for name in ['F0_OITO_REQUISITOS_CROSSWALK.json','MATRIZ_E01_E24.json','MATRIZ_8_GATES_TRANSVERSAIS.json','MATRIZ_ATIVACAO_19_FASES.json']:
 x=pathlib.Path('/mnt/data/dmg_recovery/f0_material_snapshots_20261016/evidence_readonly')/name
 files.append((x,'readonly_sources/'+name))
for root in ['README_OPERATIONAL_HANDOFF.md']:
 t=ROOT/root
 t.write_text('''# Recuperação / EXECUTOR CM-000001 DMG\n\nPacote ADITIVO de OP-DMG-CORPUS-EMP-01, MESTRE-SIDE, 16/10/2026. Não substitui artefatos anteriores, matriz F0 original ou DMG-RANK-01.\n\n1. Leia `products/FAST_RESUME_DMG_P0.json` e `products/PSV_PLANO_SUPREMO_CONTINUIDADE_20261016.md`.\n2. Evidência matemática antiga reutilizada: `readonly_sources/R02_DAMAGE_A_B_C.csv`. R91 matriz original de ataques, runs e pares incluída em read-only. ZIP R91 integral permanece na Biblioteca VLAB original (não replicado neste pacote).\n3. Para reexecutar análise, extraia este ZIP de modo isolado. `src/build_science.py` usa diretórios de operação originais preservados no runtime do projeto; ajuste ROOT e apontadores aos artefatos preservados se retomar em outro computador. `src/audit_science_independent.py` compara outputs sem convalidar classificação cega.\n4. O pacote NÃO contém os sete corpos de anexos Markdown pós-upload: só manifesto e nomes/IDs. Dizer o contrário seria falso. Baixe os bytes via ferramenta autorizada nova, recalcule o SHA e só então reavalie F0-A5.\n5. F0 formal = 4/8, writer e segundo codificador não provados; não editar Party/O Primeiro ou sistema oficial.\n\nManifest SHA256 protege todas as entradas exceto ele mesmo, CRC do ZIP validado, e o ZIP é armazenado na pasta já existente `/Comestre/OP-DMG-CORPUS-EMP-01/`.\n''',encoding='utf8')
 files.append((t,root))
manifest={'operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','checkpoint':'DMG-F0-CIENCIA-P0-20261016',
'baseline':'DMG-RANK-01 v1.1 READ-ONLY','as_of':'2026-10-16','count':len(files),'files':{},
'gates':'local science PASS, formal F0 4/8 HOLD, blind coder HOLD, seven source byte readbacks 0/7',
'validation':'reopen ZIP, testzip CRC, each file size/hash and compare recovered Library bytes'}
for file,arc in files:
 data=file.read_bytes();manifest['files'][arc]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
assert len(files)==len(set(arc for _,arc in files))
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f,arc in files:z.write(f,arc)
 z.writestr('SHA256_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 m=json.loads(z.read('SHA256_MANIFEST.json'))
 assert len(z.namelist())==len(files)+1
 for name,v in m['files'].items():
  raw=z.read(name)
  assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
'zip_entries':len(files)+1,'manifested_files':len(files),'status':'PASS'},indent=2))
(ROOT/'DELIVERY_RECEIPT.json').write_text(json.dumps({'filename':NAME,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
'manifested_files':len(files),'zip_entries':len(files)+1,'originals_preserved':True,'writer_state':'HOLD'},indent=2)+'\n')
