#!/usr/bin/env python3
"""Independent C10 oracle: Cartesian 4d6 enumeration, direct d10 mean, binomial tails.
Does not use c10_reaction_analyst to calculate any expected value.
"""
from __future__ import annotations
import json,itertools,math,subprocess,sys
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
rolls=Counter(sum(v) for v in itertools.product(range(1,7),repeat=4));assert sum(rolls.values())==1296

def expected(att_bonus,ca,damage_dice,damage_faces,fixed,rd):
    hit=sum(n for s,n in rolls.items() if s+att_bonus>ca)
    avg=F(damage_dice*(damage_faces+1),2)+fixed-rd
    return F(hit,1296), F(hit,1296)*avg

def query(attacker,defender,option):
    cmd=[sys.executable,str(ROOT/'c10_reaction_analyst.py'),'--attacker',attacker,'--defender',defender,'--option',option,'--json']
    return json.loads(subprocess.check_output(cmd,text=True))

checks=[]
def ck(k,b):
    checks.append((k,bool(b)))
    if not b:raise AssertionError(k)

p,damage=expected(100,123,10,10,48,22)
normal=query('Varok','Sikong Feryn','normal')
ck('varok_probability',F(normal['p_hit'])==p)
ck('varok_expectation',F(normal['expected_damage_per_attempt_pre_hp'])==damage)
ck('varok_max_one_roll',p==F(1,1296))
ck('varok_expected',damage==F(1,16))
ck('varok_ca_123',normal['normal_CA']==123)
ck('varok_rd22',normal['physical_rd_documented']==22)

# 1 disadvantage: min of TWO full independent rolls and -2.
# P(min(X,Y)-2>123) = P(X>125)^2 = 0.
for o,cost in [('capa',35),('selo',40)]:
 r=query('Varok','Sikong Feryn',o)
 ck(o+'_p0',F(r['p_hit'])==0)
 ck(o+'_cost',r['reaction_cost_PA_if_used']==cost)
 ck(o+'_max',r['modified_attack_roll']['max']==122)
 ck(o+'_excludes_extra_attacks',r['positive_damage_gate']=='ATTACK_OVER_BOTH_NORMAL_CA_AND_DEFENSE_REACTION')

r=query('Varok','Sikong Feryn','defender')
ck('defender_not_lower_CA',r['effective_CA']==123)
ck('defender_same_probability',F(r['p_hit'])==F(1,1296))
ck('defender_zero_extra_contact_blocked',F(r['p_physical_contact_defended'])==0)
r=query('Varok','Sikong Feryn','esquivar')
ck('esquivar_125',r['effective_CA']==125)
ck('esquivar_p0',F(r['p_hit'])==0)
ck('esquivar_is_reaction',r['reaction'])

p,damage=expected(72,76,8,10,35,25)
r=query('Arveth','Sikong Eristan','normal')
ck('arveth_hit',F(r['p_hit'])==F(1295,1296)==p)
ck('arveth_expectation',F(r['expected_damage_per_attempt_pre_hp'])==F(1295,24)==damage)
ck('arveth_rd',r['physical_rd_documented']==25)
ck('arveth_pmf_min',r['attack_pmf']['min']==76)
ck('arveth_pmf_max',r['attack_pmf']['max']==96)

p,damage=expected(72,85,8,10,35,25)
r=query('Arveth','Sikong Eristan','defender')
ck('arveth_defender_p',F(r['p_hit'])==F(721,1296)==p)
ck('arveth_defender_expected',F(r['expected_damage_per_attempt_pre_hp'])==F(721,24)==damage)
ck('arveth_defender_ca_floor',r['effective_CA']==85)
ck('arveth_defender_absorbs_contact',F(r['p_physical_contact_defended'])==F(574,1296))
ck('arveth_defender_ca_not_altered',r['normal_CA']==76)

r=query('Arveth','Sikong Eristan','casulo')
ck('casulo_zero',F(r['p_hit'])==0)
ck('casulo_98',r['effective_CA']==98)
ck('casulo_cost60_precast',r['precast_standard_action_cost_PA_if_cast']==60)
ck('casulo_not_reaction',not r['reaction'])
ck('casulo_gate_requires_ally','ALLY_WITHIN_15M' in r['gate'])
ck('casulo_duration','TWO_TURNS_CURRENT' in r['gate'])

r=query('Varok','Sikong Feryn','normal')
ck('source_proof',r['source_defender'].endswith('3f6c2b324ede81ce9c61db8127bf0e31'))
ck('source_attack',r['source_attacker'].endswith('3f6c2b324ede81f49ea9efbe1a811091'))
ck('no_crit','NO_CRITICAL' in r['assumptions'])
ck('no_combat','NO_RNG_SCENE_RUN' in r['assumptions'])
ck('no_attack_PA_fabrication',r['base_PA_cost_per_attack']=='UNKNOWN_IF_NOT_EXPLICIT_C09')
assert len(checks)>=30
print(json.dumps({'status':'PASS','independent_oracle_checks':len(checks),'source':'Cartesian 4d6 / exact fractions / source-preserving tested program as black box','details':checks},ensure_ascii=False,indent=2))
