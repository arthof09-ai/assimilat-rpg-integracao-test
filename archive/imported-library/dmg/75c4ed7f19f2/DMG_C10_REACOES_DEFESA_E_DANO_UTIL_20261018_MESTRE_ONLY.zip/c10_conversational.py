#!/usr/bin/env python3
"""Chat-first C10 bridge. Parses Portuguese, delegates C09 unchanged or C10 defense branch.
The Python CLI does not connect to Notion; Comestre physically supplies source provenance.
"""
from __future__ import annotations
import argparse,json,re,sys,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'c09_baseline'))
import c09_effective as c09
import c10_reaction_analyst as c10

def norm(x):
    return ''.join(c for c in unicodedata.normalize('NFD',x.lower()) if unicodedata.category(c)!='Mn')

def choose(query):
    q=norm(query)
    # Only explicit defense modes; 'defensor' will never count as 'defender'.
    modes={
        'capa':('capa de poeira','capa poeira'),
        'selo':('selo do retorno obscuro','selo retorno obscuro'),
        'casulo':('casulo de brotos','casulo'),
        'esquivar':('esquivar','esquiva'),
        'defender':('defender','defesa defender')
    }
    match=[]
    for k,terms in modes.items():
        if any(re.search(r'(?<!\w)'+re.escape(v)+r'(?!\w)',q) for v in terms):match.append(k)
    if len(match)>1:raise c10.SourceConflict('AMBIGUOUS_MULTIPLE_REACTIONS_OR_BUFFS_CHOOSE_ONE')
    return match[0] if match else 'normal'

def question(q, *,pa_current=None,hp_current=None,reaction_available=None,spell_active=None,ally_eligible=None,remaining_uses=None):
    # Existing C09 physical/save/VLAB path wins if new C10 defense not relevant.
    attacker=c09.Catalog();e,s=attacker.attacker(q) if any(re.search(r'(?<!\w)'+re.escape(c09.c08.norm(n))+r'(?!\w)',c09.c08.norm(q)) for n in ('varok','arveth')) else (None,None)
    defenders={'feryn':'Sikong Feryn','eristan':'Sikong Eristan'}
    matches=[v for k,v in defenders.items() if re.search(r'(?<!\w)'+k+r'(?!\w)',norm(q))]
    if e and len(matches)==1:
        return c10.defend(s['name'],matches[0],option=choose(q),pa_current=pa_current,hp_current=hp_current,
             reaction_available=reaction_available,spell_active=spell_active,ally_eligible=ally_eligible,
             remaining_reaction_uses=remaining_uses)
    if len(matches)>1:raise c10.SourceConflict('AMBIGUOUS_DEFENDER')
    if choose(q)!='normal':raise c10.SourceConflict('SPECIFIC_DEFENSE_NEEDS_VERIFIED_C10_ATTACKER_AND_DEFENDER')
    return c09.ask(q,pa_current=pa_current,hp_current=hp_current)

def answer(res):
    if res.get('schema')=='DMG-C10-SOURCE_BOUND_DEFENSE-1':
        a=c10.answer_pt(res)
        return a+(' Evento bloqueado: numeros acima são contrafactual TEST, não resultado executável.' if res['blocked_branch_is_only_counterfactual'] else '')
    return c09.respond(res)

if __name__=='__main__':
    p=argparse.ArgumentParser(description='DMG C10 consultor de reações em perguntas em português; fonte Notion recuperada por Comestre')
    p.add_argument('query',nargs='+');p.add_argument('--pa-current',type=int);p.add_argument('--hp-current',type=int)
    p.add_argument('--reaction-free',choices=['yes','no','unknown'],default='unknown');p.add_argument('--spell-active',choices=['yes','no','unknown'],default='unknown');p.add_argument('--ally-eligible',choices=['yes','no','unknown'],default='unknown')
    p.add_argument('--remaining-uses',type=int);p.add_argument('--json',action='store_true')
    a=p.parse_args();tri={'yes':True,'no':False,'unknown':None}
    try:
        r=question(' '.join(a.query),pa_current=a.pa_current,hp_current=a.hp_current,
              reaction_available=tri[a.reaction_free],spell_active=tri[a.spell_active],
              ally_eligible=tri[a.ally_eligible],remaining_uses=a.remaining_uses)
        print(json.dumps(r,ensure_ascii=False,indent=2,default=str) if a.json else answer(r))
    except (ValueError,KeyError,TypeError) as e:
        print('PENDENTE / CONSULTA_INVALIDA:',str(e));sys.exit(2)
