#!/usr/bin/env python3
"""Additive, portable DMG C10 analytical defense branches. No VLAB engine or Notion writes.
Scientific TEST: reactions and buffs are hypothetical branches, never assumed committed.
C09 imported unchanged. Numeric distributions exact with Fraction.
"""
from __future__ import annotations
import argparse, json, sys
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'c09_baseline'))
import c09_effective as base

class SourceConflict(ValueError):pass

def source_db(path=ROOT/'C10_DEFENSE_SOURCES_MESTRE.json'):
    src=json.loads(Path(path).read_text(encoding='utf-8'))
    if src.get('schema')!='DMG-C10-READONLY-DEFENSE-DELTA-1':raise SourceConflict('C10_SOURCE_SCHEMA_MISMATCH')
    return src

def altered_roll_distribution(dice_pmf, *, advantage=0, disadvantage=0):
    """Best/worst of 1+level independent full attack-rolls, +/-2 per level.
    This is a PMF over FINAL attacks, not a hit probability shortcut.
    """
    if type(advantage)!=int or type(disadvantage)!=int or min(advantage,disadvantage)<0 or max(advantage,disadvantage)>4:
        raise SourceConflict('INVALID_ADVANTAGE_DISADVANTAGE_LEVEL')
    if advantage and disadvantage:raise SourceConflict('CONCURRENT_ADVANTAGE_DISADVANTAGE_NET_RULE_NOT_VERIFIED')
    if advantage==disadvantage==0:return dict(dice_pmf)
    level=max(advantage,disadvantage);n=level+1
    values=sorted(dice_pmf);cumulative=F(0);previous=F(0);ret={}
    for value in values:
        cumulative+=dice_pmf[value]
        if advantage:
            cdf=cumulative**n
            p=cdf-previous
            transformed=value+2*level
        else:
            # min<=v: 1 - (1-P(X<=v))**n
            cdf=1-(1-cumulative)**n
            p=cdf-previous
            transformed=value-2*level
        ret[transformed]=p;previous=cdf
    if sum(ret.values(),F(0))!=1:raise AssertionError('BAD_PMF_NORMALIZATION')
    return {k:p for k,p in ret.items() if p>0}

def stat(d):
    a=base.metric(d)
    a['variance']=base.fracstr(sum((F((x-base.avg(d))**2)*p for x,p in d.items()),F(0)))
    return a

def defend(attacker:str, defender:str, *,option='normal',pa_current=None,reaction_available=None,
           spell_active=None,ally_eligible=None,hp_current=None,remaining_reaction_uses=None,
           target_ca_override=None):
    """Conditions must be true to certify a branch executable. Unknown = mathematical TEST only.
    Defense options are source-bound, named; no free-form invented numeric bonuses.
    """
    if pa_current is not None and (type(pa_current)!=int or pa_current<0):raise SourceConflict('PA_CURRENT_MUST_BE_NONNEGATIVE_INTEGER')
    if hp_current is not None and (type(hp_current)!=int or hp_current<0):raise SourceConflict('HP_CURRENT_MUST_BE_NONNEGATIVE_INTEGER')
    for v in [reaction_available,spell_active,ally_eligible]:
        if v is not None and type(v)!=bool:raise SourceConflict('STATE_MUST_BE_BOOL_OR_UNKNOWN')
    if remaining_reaction_uses is not None and (type(remaining_reaction_uses)!=int or remaining_reaction_uses<0):raise SourceConflict('INVALID_REACTION_REMAINING')
    if target_ca_override is not None:raise SourceConflict('EXTERNAL_CA_OVERRIDE_NOT_ADMITTED_USE_SOURCE_OR_EXPLICIT_TEST_MODULE')
    db=source_db();catalog=base.Catalog();e,s=catalog.attacker(attacker)
    if e.get('resolution')!='PHYSICAL_VS_CA':raise SourceConflict('ONLY_PHYSICAL_CA_RESOLUTION_SCOPED_IN_C10_USE_C09_FOR_SAVE')
    entry=next((v for v in db['sources'] if base.c08.norm(v['name'])==base.c08.norm(defender)),None)
    if not entry:raise SourceConflict('DEFENDER_NOT_IN_VERIFIED_C10_PROFILES')
    info=entry['defender'];ca=info['ca'];op=None;gate=[];cost=None;modified=False;reaction=False
    status='SOURCED_NORMAL_DEFENSE_TEST_CONTEXT_NOT_COMBAT'
    if option=='normal':pass
    elif option=='casulo':
        # +22 is from Eristan as the CASTER, but this model's defender must be an eligible target.
        buff=next((x['protective_spell'] for x in db['sources'] if x['name']=='Sikong Eristan'),None)
        if not buff:raise SourceConflict('CASULO_SOURCE_NOT_FOUND')
        ca+=buff['ca_bonus'];cost=buff['pa_per_cast'];modified=True
        gate=['ALLY_WITHIN_15M', 'PREVIOUSLY_CAST_STANDARD_ACTION','TWO_TURNS_CURRENT']
        if spell_active is False or ally_eligible is False:status='NOT_EXECUTABLE_BUFF_NOT_ACTIVE_OR_TARGET_INELIGIBLE'
        elif spell_active is None or ally_eligible is None:status='CONDITIONAL_TEST_CAST_OR_TARGET_NOT_VERIFIED'
        else:status='CONDITIONAL_TEST_BUFF_PREEXISTS_NOT_A_REACTION'
        # current PA refers to defender; caster's PA is unknown; cannot charge to defender
    else:
        opts=entry['defense_options'];op=next((x for x in opts if x['id']==option),None)
        if op is None:raise SourceConflict('DEFENSE_OPTION_NOT_DOCUMENTED_FOR_TARGET')
        reaction=True;gate=['PHYSICAL_ATTACK_ANNOUNCED','REACTION_SLOT_FREE']
        cost=op['pa_per_activation'];modified=True
        if op['kind']=='STATIC_DEFENSE_REPLACEMENT':ca=max(ca,op['defense_value'])  # CA remains a floor: Defender can stop harm without making a missed attack hit
        elif op['kind']!='PHYSICAL_ATTACK_DISADVANTAGE_1':raise SourceConflict('UNKNOWN_REACTION_KIND')
        if op.get('frequency')=='ONCE_PER_SCENE':gate.append('NOT_PREVIOUSLY_USED_THIS_SCENE')
        if reaction_available is False or remaining_reaction_uses==0:status='BLOCKED_REACTION_USED'
        elif cost is not None and pa_current is not None and pa_current<cost:status='BLOCKED_CURRENT_PA_LT_COST'
        elif reaction_available is None or pa_current is None and cost is not None or op.get('frequency')=='ONCE_PER_SCENE' and remaining_reaction_uses is None:
            status='CONDITIONAL_TEST_REACTION_PA_OR_FREQUENCY_UNKNOWN'
        else:status='CONDITIONAL_TEST_REACTION_ELIGIBLE_IF_SCENE_ANNOUNCED'
    # physical base with 1 total damage event, never critical and never activation
    roller=base.dist(e['attack_roll']); die=base.dist(e['damage_formula'])
    disadv=1 if op and op['kind']=='PHYSICAL_ATTACK_DISADVANTAGE_1' else 0
    if e['damage_type'].startswith('FISICO_'):
        phys_rd=info.get('physical_rd')
    else:phys_rd=None
    hitroll=altered_roll_distribution(roller,disadvantage=disadv)
    p=base.exact_beat(hitroll,ca)
    p_physical_land=base.exact_beat(hitroll,info['ca'])
    raw=stat(die)
    if phys_rd is not None:
        post=base.mapped(die,lambda v:max(0,v-phys_rd))
        postmetric=stat(post)
        mean_expected=p*base.avg(post)
        if hp_current is not None:
            useful=p*base.avg(base.mapped(post,lambda x:min(hp_current,x)))
            over=p*base.avg(base.mapped(post,lambda x:max(0,x-hp_current)))
        else:useful=over=None
    else:postmetric=None;mean_expected=None;useful=over=None
    normal_success=base.exact_beat(roller,info['ca'])
    avoided=F(0) if phys_rd is None else (normal_success-p)*base.avg(post)
    max_modified=max(hitroll);min_modified=min(hitroll)
    return {'schema':'DMG-C10-SOURCE_BOUND_DEFENSE-1','source_attacker':'https://app.notion.com/p/'+s['uuid'],'source_defender':entry['url'],
      'source_system':'https://app.notion.com/p/'+db['general_rule']['source_uuid'],
      'attacker':s['name'],'attack_ability':e['name'],'attack_roll':e['attack_roll'],'attack_pmf':stat(roller),
      'defender':defender,'defense_option':option,'normal_CA':info['ca'],'effective_CA':ca,
      'reaction':reaction,'reaction_cost_PA_if_used':cost if reaction else None,
      'precast_standard_action_cost_PA_if_cast':cost if option=='casulo' else None,
      'reaction_PA_current_supplied':pa_current if reaction else None,
      'reaction_free_supplied':reaction_available,'gate':gate,'gate_status':status,
      'roll_disadvantage_levels':disadv,'modified_attack_roll':stat(hitroll),'p_hit':base.fracstr(p),
      'p_miss_or_defended':base.fracstr(1-p),'p_attack_over_normal_CA':base.fracstr(p_physical_land),'p_physical_contact_defended':base.fracstr(p_physical_land-p),'positive_damage_gate':'ATTACK_OVER_BOTH_NORMAL_CA_AND_DEFENSE_REACTION', 'defense_tie_wins':True,
      'CA_needed_to_guarantee_zero_damage_without_other_modifiers':max_modified,
      'CA_extra_needed_from_normal_to_force_zero':max(0,max_modified-info['ca']),
      'CA_max_to_guarantee_positive_damage_from_all_rolls':min_modified-1,
      'expected_damage_avoided_per_attempt_relative_to_normal':base.fracstr(avoided) if phys_rd is not None else 'HOLD_MIXED_RD',
      'avoided_by_defense_only_if_branch_eligible':True,
      'expected_avoided_damage_per_PA_if_reaction_used':base.fracstr(avoided/cost) if phys_rd is not None and reaction and isinstance(cost,int) and cost>0 else 'NOT_APPLICABLE_OR_UNDOCUMENTED',
      'provided_states_eligible_in_model_NOT_SCENE_PROOF':True if status=='SOURCED_NORMAL_DEFENSE_TEST_CONTEXT_NOT_COMBAT' else (status in ('CONDITIONAL_TEST_REACTION_ELIGIBLE_IF_SCENE_ANNOUNCED','CONDITIONAL_TEST_BUFF_PREEXISTS_NOT_A_REACTION')),
      'blocked_branch_is_only_counterfactual':status.startswith('BLOCKED') or status.startswith('NOT_EXECUTABLE'),'damage_formula':e['damage_formula'],
      'gross_on_hit':raw,'physical_rd_documented':phys_rd,'post_rd_on_hit':postmetric,
      'expected_damage_per_attempt_pre_hp':base.fracstr(mean_expected) if mean_expected is not None else 'HOLD_MIXED_RD',
      'hp_current_provided':hp_current,'expected_hp_removed_per_attempt':base.fracstr(useful) if useful is not None else 'HOLD_HP_CURRENT_OR_RD',
      'expected_overkill_per_attempt':base.fracstr(over) if over is not None else 'HOLD_HP_CURRENT_OR_RD',
      'defender_RD_source':'DOCUMENTED_PHYSICAL' if phys_rd is not None else 'UNKNOWN_MIXED_TYPE',
      'base_PA_cost_per_attack':'UNKNOWN_IF_NOT_EXPLICIT_C09',
      'assumptions':['ALL_TEST_CONDITIONAL_ON_EQUIPMENT_AND_SCENE','NO_CRITICAL','NO_OTHER_MODIFIERS','NO_RNG_SCENE_RUN','NO_OFFICIAL_RULE_CHANGE']}

def compare_defenses(attacker,defender,options,**kw):
    items=[]
    for o in options:
        # default unknown states; preserve controlled states supplied if any
        items.append(defend(attacker,defender,option=o,**kw))
    return {'kind':'C10_DEFENSE_COMPARISON','source_scoped':True,'attacker':attacker,'defender':defender,'branches':items,
            'comparison_not_new_combat':True,'branch_statuses_different_possible':True}

def answer_pt(result):
    if result.get('kind')=='C10_DEFENSE_COMPARISON':return '\n'.join(answer_pt(x) for x in result['branches'])
    cost=(f"{result['reaction_cost_PA_if_used']} PA por reação" if result['reaction_cost_PA_if_used'] is not None else 'PA por reação não especificado')
    precast=(f"{result['precast_standard_action_cost_PA_if_cast']} PA por conjuração anterior" if result['precast_standard_action_cost_PA_if_cast'] is not None else 'sem conjuração anterior nesta opção')
    p_display=(f"{result['p_hit']} (≈{float(F(result['p_hit'])*100):.4f}%)" if result['p_hit'] not in ('HOLD','UNKNOWN') else result['p_hit'])
    return (f"{result['attacker']} usa {result['attack_ability']} contra {result['defender']}: "
            f"{result['attack_roll']} vs CA {result['effective_CA']} ({result['defense_option']}). "
            f"P(dano positivo antes de RD)={p_display}; P(superar CA normal)={result['p_attack_over_normal_CA']}; dano bruto médio {result['gross_on_hit']['mean']}; "
            f"RD física fonte {result['physical_rd_documented']}; dano esperado/tentativa "
            f"{result['expected_damage_per_attempt_pre_hp']}. "
            f"Vida efetiva/tentativa {result['expected_hp_removed_per_attempt']} e overkill "
            f"{result['expected_overkill_per_attempt']} (se Vida atual fornecida). "
            f"Recursos: {cost}; {precast}. "
            f"Gate {result['gate_status']}; cenário TEST, sem execução de combate nem crítico.")

if __name__=='__main__':
    p=argparse.ArgumentParser(description='DMG C10: análise de reações, prebuffs e dano por tentativa, sem alterar C09')
    p.add_argument('--attacker',required=True);p.add_argument('--defender',required=True)
    p.add_argument('--option',default='normal',choices=['normal','esquivar','defender','capa','selo','casulo'])
    p.add_argument('--pa-current',type=int);p.add_argument('--hp-current',type=int)
    p.add_argument('--reaction-free',choices=['yes','no','unknown'],default='unknown')
    p.add_argument('--spell-active',choices=['yes','no','unknown'],default='unknown')
    p.add_argument('--ally-eligible',choices=['yes','no','unknown'],default='unknown')
    p.add_argument('--reactions-remaining',type=int)
    p.add_argument('--json',action='store_true')
    args=p.parse_args()
    d={'yes':True,'no':False,'unknown':None}
    try:
        r=defend(args.attacker,args.defender,option=args.option,pa_current=args.pa_current,
          hp_current=args.hp_current,reaction_available=d[args.reaction_free],
          spell_active=d[args.spell_active],ally_eligible=d[args.ally_eligible],
          remaining_reaction_uses=args.reactions_remaining)
        print(json.dumps(r,indent=2,ensure_ascii=False) if args.json else answer_pt(r))
    except (ValueError,KeyError) as e:
        print('PENDENTE / INVALID_INPUT:',str(e));sys.exit(2)
