from __future__ import annotations
import json,sys,unittest
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import c10_reaction_analyst as mod

class TestC10ReactionAnalysis(unittest.TestCase):
    def R(self,a='Varok',d='Sikong Feryn',**kw):return mod.defend(a,d,**kw)
    def test_01_varok_feryn_baseline(self):self.assertEqual(self.R()['p_hit'],'1/1296')
    def test_02_expected_gross(self):self.assertEqual(self.R()['gross_on_hit']['mean'],'103')
    def test_03_after_rd(self):self.assertEqual(self.R()['expected_damage_per_attempt_pre_hp'],'1/16')
    def test_04_defense_and_rd_documented(self):self.assertEqual((self.R()['normal_CA'],self.R()['physical_rd_documented']),(123,22))
    def test_05_capa_exact_zero(self):self.assertEqual(self.R(option='capa',pa_current=35,reaction_available=True)['p_hit'],'0')
    def test_06_capa_cost(self):self.assertEqual(self.R(option='capa')['reaction_cost_PA_if_used'],35)
    def test_07_capa_consumed_reaction(self):self.assertEqual(self.R(option='capa',reaction_available=False)['gate_status'],'BLOCKED_REACTION_USED')
    def test_08_capa_insufficient_pa(self):self.assertEqual(self.R(option='capa',reaction_available=True,pa_current=34)['gate_status'],'BLOCKED_CURRENT_PA_LT_COST')
    def test_09_capa_sufficient_pa(self):self.assertEqual(self.R(option='capa',reaction_available=True,pa_current=35)['gate_status'],'CONDITIONAL_TEST_REACTION_ELIGIBLE_IF_SCENE_ANNOUNCED')
    def test_10_capa_unknown_pa(self):self.assertEqual(self.R(option='capa',reaction_available=True)['gate_status'],'CONDITIONAL_TEST_REACTION_PA_OR_FREQUENCY_UNKNOWN')
    def test_11_selo_40pa(self):self.assertEqual(self.R(option='selo')['reaction_cost_PA_if_used'],40)
    def test_12_selo_frequency_unknown(self):self.assertIn('FREQUENCY_UNKNOWN',self.R(option='selo',reaction_available=True,pa_current=60)['gate_status'])
    def test_13_selo_scene_spent(self):self.assertEqual(self.R(option='selo',reaction_available=True,pa_current=60,remaining_reaction_uses=0)['gate_status'],'BLOCKED_REACTION_USED')
    def test_14_selo_frequency_positive(self):self.assertEqual(self.R(option='selo',reaction_available=True,pa_current=60,remaining_reaction_uses=1)['gate_status'],'CONDITIONAL_TEST_REACTION_ELIGIBLE_IF_SCENE_ANNOUNCED')
    def test_15_esquivar_prevents_damage(self):self.assertEqual(self.R(option='esquivar')['p_hit'],'0')
    def test_16_esquivar_blocks_contact_not_ca(self):self.assertEqual(self.R(option='esquivar')['p_physical_contact_defended'],'1/1296')
    def test_17_defender_ca_floor(self):self.assertEqual((self.R(option='defender')['effective_CA'],self.R(option='defender')['p_hit']),(123,'1/1296'))
    def test_18_defender_feryn_no_extra(self):self.assertEqual(self.R(option='defender')['p_physical_contact_defended'],'0')
    def test_19_arveth_baseline(self):self.assertEqual(self.R('Arveth','Sikong Eristan')['p_hit'],'1295/1296')
    def test_20_arveth_mean(self):self.assertEqual(self.R('Arveth','Sikong Eristan')['expected_damage_per_attempt_pre_hp'],'1295/24')
    def test_21_arveth_defender_reaction(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='defender')['p_hit'],'721/1296')
    def test_22_arveth_defender_contact(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='defender')['p_attack_over_normal_CA'],'1295/1296')
    def test_23_arveth_defender_blocked_contact(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='defender')['p_physical_contact_defended'],'287/648')
    def test_24_arveth_defender_mean(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='defender')['expected_damage_per_attempt_pre_hp'],'721/24')
    def test_25_casulo_effective_ca(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='casulo')['effective_CA'],98)
    def test_26_casulo_not_reaction(self):self.assertFalse(self.R('Arveth','Sikong Eristan',option='casulo')['reaction'])
    def test_27_casulo_zero(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='casulo')['p_hit'],'0')
    def test_28_casulo_cast_cost_only(self):
        x=self.R('Arveth','Sikong Eristan',option='casulo');self.assertEqual(x['precast_standard_action_cost_PA_if_cast'],60);self.assertIsNone(x['reaction_cost_PA_if_used'])
    def test_29_casulo_inactive_blocks(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='casulo',spell_active=False,ally_eligible=True)['gate_status'],'NOT_EXECUTABLE_BUFF_NOT_ACTIVE_OR_TARGET_INELIGIBLE')
    def test_30_casulo_ally_unknown(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='casulo',spell_active=True)['gate_status'],'CONDITIONAL_TEST_CAST_OR_TARGET_NOT_VERIFIED')
    def test_31_casulo_ally_confirmed_test(self):self.assertEqual(self.R('Arveth','Sikong Eristan',option='casulo',spell_active=True,ally_eligible=True)['gate_status'],'CONDITIONAL_TEST_BUFF_PREEXISTS_NOT_A_REACTION')
    def test_32_hp_exact_reconciles(self):
        x=self.R(hp_current=40);self.assertEqual(F(x['expected_damage_per_attempt_pre_hp']),F(x['expected_hp_removed_per_attempt'])+F(x['expected_overkill_per_attempt']))
    def test_33_zero_hp_all_overkill(self):
        x=self.R(hp_current=0);self.assertEqual(x['expected_hp_removed_per_attempt'],'0');self.assertEqual(x['expected_overkill_per_attempt'],'1/16')
    def test_34_sufficient_hp_zero_overkill(self):self.assertEqual(self.R(hp_current=200)['expected_overkill_per_attempt'],'0')
    def test_35_missing_hp_hold(self):self.assertEqual(self.R()['expected_hp_removed_per_attempt'],'HOLD_HP_CURRENT_OR_RD')
    def test_36_unknown_defender_reject(self):
        with self.assertRaisesRegex(mod.SourceConflict,'DEFENDER_NOT_IN_VERIFIED'):self.R(d='Ghost Test')
    def test_37_unknown_option_reject(self):
        with self.assertRaisesRegex(mod.SourceConflict,'DEFENSE_OPTION_NOT_DOCUMENTED'):self.R(option='imaginary')
    def test_38_negative_pa_reject(self):
        with self.assertRaisesRegex(mod.SourceConflict,'PA_CURRENT'):self.R(pa_current=-1)
    def test_39_negative_hp_reject(self):
        with self.assertRaisesRegex(mod.SourceConflict,'HP_CURRENT'):self.R(hp_current=-1)
    def test_40_override_reject(self):
        with self.assertRaisesRegex(mod.SourceConflict,'CA_OVERRIDE'):self.R(target_ca_override=999)
    def test_41_not_magic_physical_reaction(self):
        with self.assertRaisesRegex(mod.SourceConflict,'ONLY_PHYSICAL'):self.R(a='Veyun')
    def test_42_levels_reject_both(self):
        with self.assertRaisesRegex(mod.SourceConflict,'CONCURRENT_ADVANTAGE'):mod.altered_roll_distribution({2:F(1)},advantage=1,disadvantage=1)
    def test_43_levels_max4(self):
        with self.assertRaisesRegex(mod.SourceConflict,'INVALID_ADVANTAGE'):mod.altered_roll_distribution({2:F(1)},disadvantage=5)
    def test_44_probabilities_normalized(self):
        x=mod.altered_roll_distribution(mod.base.dist('4d6+100'),disadvantage=1);self.assertEqual(sum(x.values()),1)
    def test_45_disadvantage_max_minus2(self):self.assertEqual(max(mod.altered_roll_distribution(mod.base.dist('4d6+100'),disadvantage=1)),122)
    def test_46_advantage_min_plus2(self):self.assertEqual(min(mod.altered_roll_distribution(mod.base.dist('4d6+100'),advantage=1)),106)
    def test_47_no_crit(self):self.assertIn('NO_CRITICAL',self.R()['assumptions'])
    def test_48_no_vlab_combat(self):self.assertIn('NO_RNG_SCENE_RUN',self.R()['assumptions'])
    def test_49_compare_four(self):self.assertEqual(len(mod.compare_defenses('Varok','Sikong Feryn',['normal','esquivar','capa','selo'])['branches']),4)
    def test_50_uncertified_data_scoped(self):self.assertEqual(mod.source_db()['source_scope'],'MESTRE_SIDE_EXPERIMENTAL_NO_CAMPAIGN_ADOPTION')

if __name__=='__main__':unittest.main(verbosity=2)
