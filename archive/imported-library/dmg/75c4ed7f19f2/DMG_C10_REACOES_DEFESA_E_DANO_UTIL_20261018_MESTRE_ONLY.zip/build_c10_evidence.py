from __future__ import annotations
import json, subprocess,sys,hashlib,zipfile,datetime,math
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
cases=[
 {'name':'01_VAROK_FERYN_NORMAL','query':'Quanto dano Varok causa contra Feryn sem reação?','flags':['--hp-current','40'],'p':'1/1296'},
 {'name':'02_VAROK_FERYN_CAPA_PA35','query':'Quanto dano Varok causa contra Feryn usando Capa de Poeira?','flags':['--pa-current','35','--reaction-free','yes'],'p':'0'},
 {'name':'03_VAROK_FERYN_CAPA_PA34','query':'Varok contra Feryn com Capa de Poeira','flags':['--pa-current','34','--reaction-free','yes'],'p':'0','blocked':True},
 {'name':'04_VAROK_FERYN_SELO','query':'Varok contra Feryn usando Selo do Retorno Obscuro','flags':['--pa-current','40','--reaction-free','yes','--remaining-uses','1'],'p':'0'},
 {'name':'05_VAROK_FERYN_ESQUIVAR','query':'Varok contra Feryn com Esquivar','flags':['--reaction-free','yes'],'p':'0'},
 {'name':'06_VAROK_FERYN_DEFENDER','query':'Varok contra Feryn com Defender','flags':['--reaction-free','yes'],'p':'1/1296'},
 {'name':'07_ARVETH_ERISTAN_NORMAL','query':'Quanto dano Arveth causa contra Eristan?','flags':['--hp-current','40'],'p':'1295/1296'},
 {'name':'08_ARVETH_ERISTAN_DEFENDER','query':'Arveth contra Eristan usando Defender','flags':['--reaction-free','yes','--hp-current','40'],'p':'721/1296'},
 {'name':'09_ARVETH_ERISTAN_CASULO','query':'Arveth contra Eristan com Casulo previamente ativo','flags':['--spell-active','yes','--ally-eligible','yes'],'p':'0'},
 {'name':'10_C09_VAROK_ERISTAN_REGRESSION','query':'Varok Machado Raiz-Ferro contra Eristan','flags':[],'old':True},
 {'name':'11_C09_VEYUN_AUREN_REGRESSION','query':'Veyun Cetro Prisao Prismatica contra Auren','flags':[],'old':True},
 {'name':'12_C07_VLAB_R157_REGRESSION','query':'Explique R157 BASIC sequencia 48','flags':[],'old':True},
]
for c in cases:
    cmd=[sys.executable,str(ROOT/'c10_conversational.py'),c['query'],'--json',*c['flags']]
    out=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=30)
    assert out.returncode==0,(c['name'],out.stderr,out.stdout[:700])
    data=json.loads(out.stdout)
    if 'p' in c:assert data['p_hit']==c['p'],(c['name'],data.get('p_hit'))
    if c.get('blocked'):assert data['blocked_branch_is_only_counterfactual'] is True
    if c['name']=='12_C07_VLAB_R157_REGRESSION':
        assert '73' in json.dumps(data) and '60' in json.dumps(data) and '13' in json.dumps(data)
    c['status']='PASS';c['output_kind']=data.get('schema') or data.get('kind');c['result']=data
(ROOT/'C10_12_QUERY_SMOKE.json').write_text(json.dumps({'as_of':'2026-10-18','status':'PASS','cases':cases,'count':len(cases),'source_scope':'MESTRE_ONLY TEST','verified_source_urls':list({x['result'].get('source_defender') for x in cases if x['result'].get('source_defender')})},indent=2,ensure_ascii=False),encoding='utf-8')
print('PASS',len(cases),'natural-language query cases')
