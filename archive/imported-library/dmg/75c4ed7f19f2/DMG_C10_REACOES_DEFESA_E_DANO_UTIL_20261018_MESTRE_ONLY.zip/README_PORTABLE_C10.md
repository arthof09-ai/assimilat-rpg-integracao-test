# DMG / OP-DMG-CORPUS-EMP-01 — incremento pós-C09 (C10 TEST)

**Ambiente:** MESTRE-SIDE, pesquisa em cópia local. **Produção HOLD.** DMG-RANK-01 v1.1 oficial **inalterada**; F0 4/8. Não constitui outro motor VLAB, uma regra nova, ou sincronização automática com Notion.

## O que mudou de fato

O C09 conseguia calcular ataque/CA/RD **sem** reação. Este delta acrescenta **ramificações defensivas documentadas** e **pré-proteção** com distribuição exata do resultado ofensivo após Desvantagem, comparação com CA e Defender/Esquivar, PV restante/overkill e condições de PA/Reação/frequência. Reconhece português natural para essas opções e delega as demais perguntas ao C09, preservado integralmente dentro de `c09_baseline/`.

## Fontes Mestre physically fetched (read-only)

- Varok: `https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091`, edit 2026-10-16T10:33:26.087Z. `4d6+100`, machado `10d10+48` físico, seu FF já incluído.
- Arveth: `https://app.notion.com/p/3f6c2b324ede8105891fc647242e61ca`, edit 2026-10-16T10:33:37.349Z. `4d6+72`, lança `8d10+35` físico, FF já incluído.
- Feryn: `https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31`, edit 2026-10-16T10:33:13.379Z. CA123, RD físico22, Defender56, Esquivar125; **Capa de Poeira** reação 35 PA, Desvantagem1 em um ataque físico; Selo do Retorno Obscuro reação40 PA, Desvantagem1, uma vez por cena. Uma Reação por rodada.
- Eristan: `https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76`, edit 2026-10-16T10:33:32.392Z. CA76, RD físico25, Defender85, Esquivar76; **Casulo de Brotos**: Ação Padrão 60PA, um aliado a15m, +22 CA por dois turnos, -4m deslocamento; não acumula com outro Casulo do mesmo conjurador.
- Sistema de Combate: `https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0`, edit 2026-10-07T23:51:04.971Z. Ataque deve **superar estritamente** defesa; Desvantagem1 = pior de duas rolagens completas menos2. Defender impede **dano** se teste não o superar; não transforma golpe que já erraria CA em golpe que causa dano.
- DMG-RANK-01 v1.1 `https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e`. Tags de componentes preservados; ausência de adjudicação inequívoca da RD por componente não foi inventada.

As fichas de encontro são **fontes Mestre fisicamente consultadas**, mas incluem elementos de encontro/equipamentos **PROPOSTOS**; o sistema não os canonizou nem escreveu no Notion.

## Uso em pasta nova

Requer Python 3.11+ e biblioteca padrão; **nenhum caminho absoluto** nem conector dentro do Python. Exemplos, após extrair o ZIP em qualquer pasta:

```sh
python c10_conversational.py "Quanto dano Varok causa contra Feryn sem reação?"
python c10_conversational.py "Varok contra Feryn usando Capa de Poeira" --pa-current 35 --reaction-free yes
python c10_conversational.py "Varok contra Feryn usando Selo do Retorno Obscuro" --pa-current 40 --reaction-free yes --remaining-uses 1
python c10_conversational.py "Arveth contra Eristan usando Defender" --reaction-free yes
python c10_conversational.py "Arveth contra Eristan com Casulo previamente ativo" --spell-active yes --ally-eligible yes
python c10_conversational.py "Arveth contra Eristan" --hp-current 40
python c10_conversational.py "Varok Machado Raiz-Ferro contra Eristan"
python c10_conversational.py "Explique R157 BASIC sequencia 48"
python -m unittest -q test_c10_reactions.py
python c10_independent_oracle.py
python -m unittest discover -s c09_baseline/tests -p 'test_c09_effective.py'
python c09_baseline/tests/c09_independent_oracle.py
```

`--json` fornece frações exatas e metadados de proveniência. Para uso **principal** pelo Mestre, basta escrever a pergunta no ChatGPT; o Comestre recupera/consulta o checkpoint e pode buscar no Notion Mestre a fonte de um nome novo. **Não** alegar conexão automática Python↔Notion nem persistência permanente no chat.

## Ciência nova

**Varok × Feryn:** `4d6+100` vs CA123: `P=1/1296`; após RD22, `E[dano por tentativa]=1/16=0,0625 PV` (sem crítico, sem reações). Capa 35PA ou Selo 40PA impõem -2 e pior de duas rolagens; `P=0`, se habilitados. Esquivar125 também torna zero. Defender56 **não** reduz a proteção abaixo de CA123. Só uma Reação por rodada, portanto opções alternativas, não acumuladas.

**Arveth × Eristan:** `4d6+72` contra CA76: `P=1295/1296`, RD25 -> `E=1295/24≈53,9583`. Com Defender85, chance de ataque produzir dano antes da RD `721/1296`, e `E=721/24≈30,0417`. Os `574/1296` resultados intermediários superam CA, mas são **bloqueados por Defender**. Com Casulo pré-ativo +22, CA98, `P=0`; este último é TEST dependente de alvo aliado elegível, conjuração **anterior**, duração em curso e custo no lançamento. Não é reação e não afirma elegibilidade de autoalvo.

**PA/risco:** Capa de Feryn 35 PA evita somente 1/16 PV *esperado* por uma tentativa como a de Varok; a métrica contrafactual ≈1/560 PV evitados por PA não determina decisão tática universal. Custos diários do atacante não são atribuídos ao evento. Para eventos reais, PA e Vida atuais devem ser recuperados.

## Bloqueios e limites

- Desvantagem e pré-proteção: cenários matemáticos **TEST**, não ações VLAB realizadas. Se falta PA atual, Reação disponível, uso do Selo ou validade do Casulo, status `CONDITIONAL`/`BLOCKED`; uma branch bloqueada não pode ser tomada como dano final.
- Não há histórico de RNG/cena, alcance posicional atual, criticidade conjunta, RD elemental certificada ou verificação do número de ações até o evento. Não calcular vitória ou taxas universais.
- A fonte de Casulo exige um **aliado**. O comparador pode usar números defensivos de Eristan apenas como **perfil TEST de alvo elegível**, sem declarar que Eristan pode conjurar sobre si mesmo.
- Um ataque fisicamente incidente pode ser neutralizado pelo Defender. Campo `p_attack_over_normal_CA` é separado de `p_hit` (gate de dano) e `p_physical_contact_defended`.
- **RD múltipla** e **componente misto** permanecem HOLD normativo/documental; não resolvidos por analogia.
- C09 e seus 19 arquivos estão anexados em `c09_baseline/` **sem mutação**. R162/R169 nativos permanecem apenas dados de leitura; nenhuma cena foi reexecutada.

## Entrega e auditoria

`test_c10_reactions.py`: 50 asserts dirigidos; `c10_independent_oracle.py`: 41 verificações da implementação por aritmética/contagem cartesiana independentes; regressões originais C09 40/40 + 29/29. `C10_CLEAN_RECOVERY_AUDIT.json` registra reprodução em extração limpa. `C10_SHA256_MANIFEST.json` guarda hashes do pacote sem autocircularidade. PSV especifica gates F0/continuidade. A publicação exige **Library readback SHA idêntico** antes de ser considerada concluída.
