# DMG C09 — consultor de dano por tentativa (MESTRE-SIDE)

Operation: `OP-DMG-CORPUS-EMP-01`. Scientific TEST. Baseline `DMG-RANK-01 v1.1` **unchanged**; F0 **4/8**. This is a portable, additive resolver, **NOT** a VLAB combat engine or a Notion API client.

## Clean extraction / no absolute paths

Python 3.11+ standard library only. From any directory after extracting this ZIP:

```sh
python c09_effective.py "Varok Machado Raiz-Ferro contra Eristan"
python c09_effective.py "Varok Quebra do Tronco contra Eristan" --activate --pa-current 100 --already-used no --hp-current 40
python c09_effective.py "Iskiel Mergulho Cortante contra Eristan" --activate --fly-m 20 --already-used no --pa-current 100
python c09_effective.py "Veyun Cetro Prisao Prismatica contra Auren"
python c09_effective.py "Arveth Bastiao das Sete Gargantas contra Eristan"
python c09_effective.py "Quanto dano causa o Arranhão Putrificador?"
python c09_effective.py "Explique R157 BASIC sequencia 48"
python -m unittest discover -s tests -p 'test_c09_effective.py'
python tests/c09_independent_oracle.py
```

`--json` gives structured results; without it, human-readable Portuguese. `--catalog FILE.json` accepts a replacement C09 source registry in the same schema, enabling future verified sources **without rewriting the resolver**. `--supplement FILE.json` accepts an external C08-style supplement, **always TEST/unverified**, with controlled required-field errors rather than `KeyError`. The conversation itself can use these same computations after the Comestre physically reads the Notion Mestre source. There is **no automatic Notion sync** inside Python or persistent live plugin.

## Dependencies and provenance

Exact and unchanged C05–C08 modules in `src/`. Baseline identity certified by `evidence/C09_C08_UNMODIFIED_REUSE_CERTIFICATE.json` against original C08 SHA256 `4653b03dd640326a449588fb902a076e85cd802324b97827cdb3be2d58c259ef`. Historical read-only R162/R169 CSV also copied unchanged so C07 event queries remain portable.

The C09 source delta has four physically reopened Notion Mestre attackers: Varok, Iskiel, Veyun and holdout Arveth; two source-attested defender profiles: Eristan and Auren. All have exact source UUIDs, edit timestamps, name and encounter/canonical status. **Source text existence is verified; the proposed encounter/equipment is not promoted to official catalogue/campaign.** Source excerpts and limits in `docs/C09_SOURCE_SCOPES_AND_MECHANICS.md`. Source patch: `C09_VERIFIED_PATCH.json`.

## Critical distinctions

* Accuracy: strictly `attack_roll > CA`; equal results favor defense. Every die outcome counted exactly, not Monte Carlo.
* The base of Varok is `10d10+48`, with FF +23 already included. Equipment accuracy is already in `4d6+100`. Eristan has physical RD25.
* Quebra do Tronco `+6d12` costs 60 PA only after hit, once per scene, no extra attack. Applying physical RD once to the combined hit versus separately to components remains two explicitly labeled TEST branches, not silently resolved.
* Iskiel's base `9d8+47` is tagged Vento/perfurante without a numeric split. RD physical is **not** automatically deducted from the total. `+5d10` Vento requires 20 m flight in same turn, hit, one use/turn and 45 PA. Any combined result without elemental RD is TEST, not final canonical PV.
* Veyun's Prisma is `8d10+26` Terra, save Reflexo CD72 with strict greater success and half damage. Specific operational clause says **no FF**; contrary explanatory sentence flagged. No crit. Odd half rounding unresolved: calculator shows rational/floor/ceil scenarios, not a new rule. Earth RD missing from defenders.
* Daily equipment PA commitment is **not spent per attack**. C09 uses source-scoped free PA maximum only; current balance must be supplied to adjudicate affordability. Unknown base swing cost is not treated as zero.
* PV actually removed requires **current** Life, not ficha maximum. Critical hits/reactions/censorship require scoped data; C09 does not synthesize them or execute combat.
* New Arveth holdout was documented **after** generic engine code design; no Arveth-specific branch. `4d6+72` vs CA76 has strict win probability `1295/1296`, not 100%.

## Artifact usage & independent audit

`evidence/C09_12_EXECUTED_CONVERSATIONAL_QUERIES.json` records calculated queries A/B/C, holdout and legacy R162 event. `tests/test_c09_effective.py` exercises 40 directed assertions including PA failure, repeated activation, missing metadata, regression C08 and VLAB event. `tests/c09_independent_oracle.py` performs 29 independent analytic/cartesian checks. All artifacts include SHA256 integrity manifest in the package root. Do not mutate historical source files or claim ACK / production.
