# PSV — DMG C09 / CONSULTOR DE DANO EFETIVO POR TENTATIVA

**AS-OF** 17/10/2026 · **OPERATION** OP-DMG-CORPUS-EMP-01 · **MESTRE-SIDE** · **BASELINE** DMG-RANK-01 v1.1 OFICIAL/INALTERADA · **F0** 4/8 · **PRODUÇÃO** HOLD.

## ANTES → DEPOIS

ANTES C08 SHA256 `4653b03dd640326a449588fb902a076e85cd802324b97827cdb3be2d58c259ef`; consultor com fontes extensíveis, mas sem `p_hit` genérico para 4d6+mod contra CA; suplemento incompleto podia `KeyError` em `last_edited`. DEPOIS C09: parser protegido para metadados; física vs CA e magia vs CD; acerto exato e dano/PA/efeito condicionais; Varok, Iskiel, Veyun adicionados apenas por registro mais Arveth holdout admitido depois, sem novo módulo por nome; C05–C08 **7/7 arquivos copiados byte-identicamente**.

## Dez etapas (execução e aceitação)

1. **C08 recuperado:** ZIP original SHA verificado; 7/7 arquivos usados iguais; suplemento sem `last_edited` rejeitado por `SUPPLEMENT_SOURCE_0_MISSING_REQUIRED: last_edited`, sem exceção descontrolada. EXTERNAL VERIFIED rebaixado TEST. PASS.
2. **Varok:** Notion Mestre UUID `3f6c2b324ede81f49ea9efbe1a811091`, edição `2026-10-16T10:33:26.087Z`, 4d6+100, 10d10+48 com FF23 incorporada, vínculo95 PA/dia. Fonte fisicamente VERIFICADA, encontro/equipamento PROPOSTO, sem canonização. PASS documental.
3. **Precisão:** contra Eristan UUID `3f6c2b324ede819cae98ec0f6a63de76` (CA76 RD físico25), ataque 104–124: `p_hit=1`, gross mean103, post-RD/per-attempt78. Sem reação, críticos, combate ou PV atual presumidos. PASS matemático condicionado.
4. **Quebra:** +6d12, média39, somente no acerto, 60 PA e 1/cena; combinado bruto142. RD física conjunta uma vez TEST117; RD separada por componente TEST `68795233/746496` ≈92,1575. Sem adjudicação de stacking; uso anterior, PA livre insuficiente e vida limitada tratados. PASS técnico / HOLD normativo RD.
5. **Iskiel:** Notion UUID `3f6c2b324ede81a78a59d3d81fd5e966`, 4d6+101, 9d8+47 mixed Vento/perfurante mean87,5, já inclui FF21; Mergulho +5d10 Vento expected27,5 após voar 20m e acertar, 45 PA, 1/turno, 95 PA/dia. TEST sem RD conjunto115; RD competente do golpe misto PENDENTE. PASS parcial.
6. **Veyun:** UUID `3f6c2b324ede819e879beabb795001ba`, 8d10+26 Terra mean70, Reflexo CD72 metade no sucesso, custo65PA/uso, vínculo85PA/dia, 30m, sem crítico/FF por cláusula específica apesar de glosa contraditória. Eristan salva 0%, mean70 pré-RD. Auren (`6d6+166`) salva 100%: FLOOR 34,75, CEIL35,25, racional35 TEST. RD Terra e arredondamento oficial PENDENTES. PASS parcial.
7. **Recursos:** PA máximo/livre da fonte não tratado como PA atual; vínculo diário não repetido por uso; ativação pós-acerto distinta; 19m voo, PA insuficiente, frequência esgotada impedem adicional. Base-hit custo PA não documentado nunca recebe zero fictício. PASS.
8. **Admissão sob demanda:** após desenho do resolvedor foi reaberto Arveth UUID `3f6c2b324ede8105891fc647242e61ca` edição `2026-10-16T10:33:37.349Z`, lança 4d6+72 versus CA76 => `1295/1296` porque empate perde; 8d10+35 físico perfurante mean79; pós-RD25 expected per attempt `1295/24` ≈53,9583; sem ramo Arveth no código. Fissura Terra separada sem RD física indevida. PASS.
9. **Testes:** 40/40 verificações dirigidas e 29/29 verificador combinatório independente; C08 Arranhão/TEST e C07 R162 evento R157 BASIC seq48 preservados. Igualdade binária 7/7 das dependências originais. PASS; não certificado combate/holdout de RNG.
10. **Checkpoint:** `c09_effective.py` + fontes patch JSON + quatro fontes + dois defensores + 12 consultas gravadas + QA e documentação, testados em extração isolada, manifesto, ZIP e Biblioteca readback. PASS apenas depois do recibo físico.

## DENOMINATORS

C09 quatro fichas ofensivas reabertas e registradas (Varok, Iskiel, Veyun, Arveth), dois defensores competentes (Eristan e Auren), quatro fórmulas-base e três habilitações condicionais (Quebra, Mergulho, Fissura); 12 demos executadas, 40 testes dirigidos, 29 checks independentes, sete arquivos C08 imutáveis com readback hash. **Nenhuma cobertura global**; C08 nove fórmulas e A6-571 permanecem históricos sem recontagem. R162 154 recibos e R169 137 separados, inalterados. C07 evento R157 BASIC seq48 regressão 73 pós-RD/60 vida/13 overkill.

## Cientificamente demonstrado / pendente

Varok sem reação/acerto/crit e com RD25 pós-hit: esperado78/tentativa. Arveth apresenta um caso não trivial: `p_hit=1295/1296`, expected `1295/24`. Iskiel: dano multitype sem decomposição de tipos, RD não dedutível. Quebra: RD por componentes conflituosa. Veyun: a CD72 interage deterministicamente com rolagens legítimas Eristan/Auren, sem adotar política de arredondamento ou RD Terra por inferência. PA por ataque básico não equivale a zero e PA/dia não é gasto por golpe. Vida atual não se presume de Vida máxima.

## Governança, gate e continuidade

**LAST-VERIFIED-UNIT** C09 local congelado e reaberto da Biblioteca, hash e CRC/manifesto conforme comprovante de publicação (não promover antes do readback).

**FIRST-PENDING** localizar política competente de RD para dano adicional no mesmo golpe, especialmente impacto físico de Quebra, e repartir Vento/perfurante do arco quando a fonte a documentar.

**CONFLICTS** FF +6 de Veyun em glosa vs sem FF na cláusula operacional; metade ímpar sem regra competente; impactos da Quebra sob RD; multitype sem proporção; encontros/equipamentos apresentados como PROPOSTOS mestre-side.

**NO-REPEAT** A6-571, C04-C08, R162/R169, 466 commits R160, 413 commits R169, R170 0/17 e 0/1875, R156 UNKNOWN_EFFECT, R138 HOLD preservados. Apenas testes dirigidos. Nenhum combate executado, nenhuma planilha oficial ou SQLite regravado.

**NEXT-5** (1) Adjudicar RD física pós-hit/por componente na fonte competente; (2) obter discriminação de dano Vento/perfurante; (3) testar novos ataques com CA intermediária + reações legitimamente documentadas; (4) receber valores reais de PA atual, posição e PV atual da cena para avaliação limitada; (5) expandir catálogo por Notion Mestre sob demanda sem alterar motor.

**TARGET-REMAINDER** F0–F18, A5 readback histórico 0/7, A7 revisão cega 0/8, A8 authority/writer, L002/003, E01–E24 e oito gates transversais. F0 4/8, zero novo certificado, produção HOLD.

**AUTHORITY/WRITER STATE** nenhum lease/epoch/fencing/writer/ACK herdado. Somente cópias locais e publicação do artefato na Biblioteca permitida; nada escrito em Notion canônico, fichas, Party, O Primeiro, operações alheias ou SQLite.

**UNKNOWN-EFFECT** R156 em quarentena; R138 HOLD espacial. Nenhum side effect desconhecido nesta C09 local.

**NAC-PASS-02** PASS técnico delimitado para código, tests, provenance e readback; HOLD normativo/canônico e produção. Aplicado sobre o checkpoint final após ANTES/DEPOIS/reopen. Promover por autoridade externa apenas.
