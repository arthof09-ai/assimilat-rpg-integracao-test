#!/usr/bin/env python3
"""C09 DMG Mestre-side: data-driven extension to C05/C06/C07/C08.
NOT an RNG combat engine; never changes Notion or SQLite.
Numeric PMFs come from unchanged C05; conditional/defense policies are explicit.
"""
from __future__ import annotations
import argparse, json, re, sys, unicodedata
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from experimental_damage_calc import pmf
import c08_generalized as c08

CATALOG=ROOT/'C09_VERIFIED_PATCH.json'
class ContractError(ValueError):pass

def must_fields(obj,fields,label):
    if not isinstance(obj,dict):raise ContractError(f'{label}_NOT_AN_OBJECT')
    missing=[v for v in fields if v not in obj or obj[v] is None]
    if missing:raise ContractError(f'{label}_MISSING_REQUIRED: '+', '.join(missing))

def validate_supplement(path:Path):
    """Control external input: it is always TEST even if user says VERIFIED.
    This guards C08's optional .last_edited KeyError without mutating C08.
    """
    try:data=json.loads(Path(path).read_text('utf-8'))
    except (OSError,ValueError) as e:raise ContractError('SUPPLEMENT_IO_OR_JSON_INVALID: '+str(e))
    must_fields(data,['sources','effects'],'SUPPLEMENT')
    if not isinstance(data['sources'],list) or not isinstance(data['effects'],list):raise ContractError('SUPPLEMENT_LISTS_REQUIRED')
    for i,s in enumerate(data['sources']):
        must_fields(s,['uuid','url','name','last_edited','attributes','classification_body','classification_status'],f'SUPPLEMENT_SOURCE_{i}')
        for optional,default in [('ca',None),('max_hp',None),('physical_rd',None),('elemental_rd',{})]:s.setdefault(optional,default)
        if not re.fullmatch(r'20\d\d-\d\d-\d\dT[\d:.]+Z',str(s['last_edited'])):raise ContractError('SUPPLEMENT_INVALID_LAST_EDITED')
        if s.get('source_evidence') in ('VERIFICADO','CANONICAL','OFFICIAL'):
            # Remove false caller authority in the proxy before C08; never persist.
            s['source_evidence']='TEST_UNVERIFIED_SUPPLEMENT'
    for i,e in enumerate(data['effects']):must_fields(e,['id','source_uuid','name','literal_formula','damage_channel','damage_type'],f'SUPPLEMENT_EFFECT_{i}')
    return data

def fracstr(f):
    f=F(f);return str(f) if f.denominator!=1 else str(f.numerator)

def avg(d):return sum((F(x)*p for x,p in d.items()),F(0))
def dist(formula):return pmf(formula)[0]
def combine(a,b):
    out=defaultdict(F)
    for x,px in a.items():
        for y,py in b.items():out[x+y]+=px*py
    return dict(out)
def mapped(a,fun):
    out=defaultdict(F)
    for x,p in a.items():out[fun(x)]+=p
    return dict(out)
def metric(d):return {'min':min(d),'max':max(d),'mean':fracstr(avg(d)),'support':len(d)}
def exact_beat(attack,ca):
    if not isinstance(ca,int):raise ContractError('DEFENSE_CA_DOCUMENTATION_REQUIRED')
    return sum((p for a,p in attack.items() if a>ca),F(0))
def exact_save(save,cd):
    if not isinstance(cd,int):raise ContractError('SAVE_CD_DOCUMENTATION_REQUIRED')
    return sum((p for x,p in save.items() if x>cd),F(0))
def hp_metric(d,remaining=None):
    if remaining is not None and (type(remaining)!=int or remaining<0):raise ContractError('INVALID_CURRENT_HP')
    loss= mapped(d,lambda x:min(x,remaining) if remaining is not None else x)
    over=mapped(d,lambda x:max(0,x-remaining) if remaining is not None else 0)
    return {'post_mitigation':metric(d),'hp_lost':metric(loss) if remaining is not None else 'PENDING_HP_CURRENT','overkill':metric(over) if remaining is not None else 'PENDING_HP_CURRENT'}

class Catalog:
    def __init__(self,path=CATALOG):
        raw=json.loads(Path(path).read_text('utf-8'))
        if raw.get('schema')!='DMG-C09-SOURCE-ADMISSION-1':raise ContractError('CATALOG_C09_SCHEMA')
        self.sources={};self.defenders={};self.effects={}
        for s in raw['sources']:
            must_fields(s,['uuid','last_edited','name','canonical_status','effects'],'SOURCE_C09')
            if s['uuid'] in self.sources:raise ContractError('DUP_SOURCE_UUID')
            self.sources[s['uuid']]=s
            for e in s['effects']:
                must_fields(e,['id','name','damage_formula','resolution'],'EFFECT_C09')
                if e['id'] in self.effects:raise ContractError('DUP_EFFECT_ID')
                self.effects[e['id']]=(e,s)
        for d in raw['defenders']:
            must_fields(d,['uuid','name','last_edited'],'DEFENDER_C09')
            if d['name'] in self.defenders:raise ContractError('DUP_DEFENDER_NAME')
            self.defenders[d['name']]=d
        self.raw=raw
    def attacker(self,query):
        q=c08.norm(query);matches=[]
        for e,s in self.effects.values():
            names=[e['name'],s['name'],*e.get('aliases',[]),*s.get('aliases',[])]
            if any(re.search(r'(?<!\w)'+re.escape(c08.norm(v))+r'(?!\w)',q) for v in names):matches.append((e,s))
        if not matches:raise ContractError('ATTACKER_NOT_IN_ADMITTED_C09_SOURCES; TRY_C08_OR_FETCH_NOTION_MESTRE')
        if len(matches)!=1:raise ContractError('AMBIGUOUS_C09_ATTACKER: '+', '.join(x[0]['name'] for x in matches))
        return matches[0]
    def defender(self,query):
        q=c08.norm(query);found=[]
        for d in self.defenders.values():
            if any(re.search(r'(?<!\w)'+re.escape(c08.norm(k))+r'(?!\w)',q) for k in [d['name'],*d.get('aliases',[]) ]):found.append(d)
        if len(found)!=1:raise ContractError('DEFENDER_NOT_ADMITTED_OR_AMBIGUOUS')
        return found[0]

def compute(e,s,d, *,activate=False,pa_current=None,already_used=None,fly_distance=None,hp_current=None,rd_override=None,rd_override_type=None):
    """Physical CA or specific Reflexo save; independent math, not scene execution."""
    if pa_current is not None and (type(pa_current)!=int or pa_current<0):raise ContractError('INVALID_PA_CURRENT')
    if hp_current is not None and (type(hp_current)!=int or hp_current<0):raise ContractError('INVALID_CURRENT_HP')
    if fly_distance is not None and (type(fly_distance)!=int or fly_distance<0):raise ContractError('INVALID_FLY_DISTANCE')
    if already_used not in (True,False,None):raise ContractError('INVALID_FREQUENCY_STATE')
    base=dist(e['damage_formula'])
    out={'kind':'C09_SOURCE_ATTACK','source':{'uuid':s['uuid'],'url':'https://app.notion.com/p/'+s['uuid'],'last_edited':s['last_edited'],'status':s['canonical_status']},
         'attacker':s['name'],'ability':e['name'],'defender':d['name'],'defender_source':'https://app.notion.com/p/'+d['uuid'],
         'defender_last_edited':d['last_edited'],'damage_formula':e['damage_formula'],'resolution':e['resolution'],
         'damage_type':e['damage_type'],'gross_on_hit':metric(base),'resource':{'pa_total':s.get('pa_total'),'pa_committed_total':s.get('pa_committed_total'),'pa_free_max_NOT_CURRENT':s.get('pa_free_max'),'link_pa_daily':e.get('link_pa_per_day'),'base_attack_PA_per_use':e.get('pa_per_use'), 'pa_current_supplied':pa_current},
         'no_automatic_critical':True,'no_vlab_combat_executed':True,'hp_current':hp_current}
    if 'ff_included' in e:out['FF_ALREADY_IN_GROSS']=e['ff_included']
    if e['resolution']=='PHYSICAL_VS_CA':
        rolls=dist(e['attack_roll'])
        out.update({'attack_roll':e['attack_roll'],'attack_min':min(rolls),'attack_max':max(rolls),'defender_CA':d['ca'],'p_hit':fracstr(exact_beat(rolls,d['ca'])),'tie_favors_defense':True,'mode':'NORMAL_CA_NO_REACTION_NO_CRITICAL'})
        p=F(out['p_hit'])
        if e['damage_type'].startswith('FISICO_'):
            competent=d['physical_rd']
            if competent is None:rd=None
            else:rd=competent
            if rd_override is not None:
                if rd_override_type not in ('FISICO',e['damage_type']):raise ContractError('RD_OVERRIDE_TYPE_MISMATCH_PHYSICAL')
                rd=rd_override;out['rd_source']='TEST_OVERRIDE_NOT_CANONICAL'
            else:out['rd_source']='DOCUMENTED_DEFENDER_PHYSICAL' if rd is not None else 'UNKNOWN'
            out['rd_applied']=rd if rd is not None else 'PENDING';post=mapped(base,lambda x:max(0,x-rd)) if rd is not None else None
            if post is not None:
                out['base_post_RD_on_hit']=metric(post)
                out['base_expected_per_attempt']=fracstr(p*avg(post))
                if hp_current is not None:
                    out['base_hp_per_attempt']=fracstr(p*avg(mapped(post,lambda x:min(x,hp_current))))
                    out['base_overkill_per_attempt']=fracstr(p*avg(mapped(post,lambda x:max(0,x-hp_current))))
                else:out['base_hp_per_attempt']='HOLD_CURRENT_HP'
            else:
                out['base_expected_per_attempt']='HOLD_RD_NOT_SOURCE_CONFIRMED'
        else:
            # Mixed typed bow formula cannot be split into scalar physical and wind subcomponents.
            out['base_expected_per_attempt']='HOLD_MIXED_WIND_PIERCING_RD_PARTITION';out['base_RD']='MIXED_DAMAGE_PARTITION_UNKNOWN'
            out['baseline_NO_RD_TEST']={'conditional_assumption':'ALL_DAMAGE_UNMITIGATED_TEST_NOT_CANONICAL','mean_per_attempt':fracstr(p*avg(base)),'min':min(base),'max':max(base)}
    elif e['resolution']=='SAVE_VS_FIXED_CD':
        out.update({'save_type':e['save_type'],'save_cd':e['save_cd'],'save_roll':d.get('reflex_roll'),'no_critical':True,'pa_per_use':e['pa_per_use'],'link_pa_daily':e['link_pa_per_day'],'action':e.get('action'),'ff_included_in_magical_discharge':False})
        if not d.get('reflex_roll'):
            out['save_success']='HOLD_DEFENDER_REFLEX_ROLL'
            return out
        dr=dist(d['reflex_roll']);success=exact_save(dr,e['save_cd'])
        out['p_save_strictly_greater']=fracstr(success);out['p_full_damage']=fracstr(1-success)
        # If successful save: half. Rounding policy has no authorized source.
        out['pre_elemental_RD']={'RATIONAL_TEST':fracstr(avg(base)*(1-success/2)),
         'FLOOR_TEST':fracstr((1-success)*avg(base)+success*avg(mapped(base,lambda x:x//2))),
         'CEIL_TEST':fracstr((1-success)*avg(base)+success*avg(mapped(base,lambda x:(x+1)//2)))}
        out['expected_pre_RD_after_save']='ROUNDING_PENDING_IF_SUCCESS' if success else fracstr(avg(base))
        out['RD_TERRA']='UNVERIFIED_NOT_APPLIED'
        out['expected_hp_per_attempt']='HOLD_RD_TERRA_AND_CURRENT_HP'
        out['PA_per_cast']=e['pa_per_use']
        out['PA_charged_only_if_cast']=True
        if pa_current is not None:
            out['affordability']='NOT_EXECUTABLE_PA_INSUFFICIENT' if pa_current<e['pa_per_use'] else 'AFFORDABLE_IF_OTHER_PRECONDITIONS_MET'
        else:out['affordability']='CURRENT_PA_UNKNOWN_SOURCE_MAX_ONLY'
        return out
    else:raise ContractError('UNSUPPORTED_RESOLUTION_KIND')
    act=e.get('activation')
    if not act or not activate:return out
    out['conditional_activation']={'name':act['name'],'extra_formula':act['extra_formula'],'extra_expected':fracstr(avg(dist(act['extra_formula']))),'activation_PA':act['pa_per_use'],'frequency':act['frequency'],'trigger':act['when'],'no_extra_attack':not act.get('extra_attack',True),'status':'CONDITIONAL_EXPLORATION_NOT_SCENE_COMMIT'}
    a=out['conditional_activation']
    if already_used is True:
        a['availability']='BLOCKED_ALREADY_USED';return out
    if pa_current is not None and pa_current<act['pa_per_use']:
        a['availability']='BLOCKED_INSUFFICIENT_PA';return out
    if 'FLY_20M' in act['when'] and (fly_distance is None or fly_distance<20):
        a['availability']='HOLD_FLY_DISTANCE_UNKNOWN' if fly_distance is None else 'BLOCKED_FLY_DISTANCE_LT20';return out
    if already_used is None:a['availability']='HOLD_FREQUENCY_STATE_TEST_ASSUME_UNUSED'
    elif pa_current is None:a['availability']='HOLD_CURRENT_PA_TEST_ASSUME_AFFORDABLE'
    else:a['availability']='PRECONDITIONS_DOCUMENTED_FOR_TEST'
    extra=dist(act['extra_formula']);both=combine(base,extra)
    a['gross_combined_on_hit']=metric(both);a['gross_combined_expected_per_attempt']=fracstr(F(out['p_hit'])*avg(both))
    a['PA_on_success_only']=act['pa_per_use'];a['expected_activation_PA_per_attempt_IF_ENABLED']=fracstr(F(out['p_hit'])*act['pa_per_use'])
    if e['damage_type']=='FISICO_IMPACTO_CORTE' and isinstance(out.get('rd_applied'),int):
        rd=out['rd_applied'];once=mapped(both,lambda x:max(0,x-rd))
        separate=combine(mapped(base,lambda x:max(0,x-rd)),mapped(extra,lambda x:max(0,x-rd)))
        a['rd_policy']='UNDETERMINED_NO_DOUBLE_APPLICATION_ASSUMED'
        a['scenarios_TEST']={
         'RD_ONCE_JOINT_TEST':{'post_RD':metric(once),'per_attempt':fracstr(F(out['p_hit'])*avg(once)),'hp':hp_metric(once,hp_current)},
         'RD_SEPARATE_COMPONENTS_TEST':{'post_RD':metric(separate),'per_attempt':fracstr(F(out['p_hit'])*avg(separate)),'hp':hp_metric(separate,hp_current)} }
    else:
        a['rd_policy']='HOLD_MIXED_TYPES_RD_PARTITION_OR_ELEMENTAL_RD'
        a['NO_RD_TEST']={'post_RD':metric(both),'per_attempt':fracstr(F(out['p_hit'])*avg(both)),'hp':hp_metric(both,hp_current)}
    return out

def ask(question,*,activate=None,pa_current=None,already_used=None,fly_distance=None,hp_current=None,catalog=None,supplement=None):
    # User-provided external material never self-certifies.
    if supplement is not None:validate_supplement(Path(supplement))
    if catalog is None:catalog=Catalog()
    try:
        e,s=catalog.attacker(question)
    except ContractError as err:
        # Actual legacy C08 catalog remains valid; never silently fabricate fields.
        try:
            base=c08.Registry(supplemental=Path(supplement) if supplement else None)
            result=c08.ask(question,base)
            return {'kind':'LEGACY_C08_PRESERVED','result':c08.json_safe(result),'answer':c08.answer_pt(result)}
        except (ValueError,KeyError,TypeError,FileNotFoundError) as legacy_err:
            raise ContractError(str(err)+'; LEGACY_REJECTION: '+str(legacy_err))
    try:d=catalog.defender(question)
    except ContractError:
        return {'kind':'C09_PARTIAL_NO_DOCUMENTED_DEFENDER','source_url':'https://app.notion.com/p/'+s['uuid'],
          'source_last_edited':s['last_edited'],'name':e['name'],'actor':s['name'],
          'gross_formula':e['damage_formula'],'gross_on_hit':metric(dist(e['damage_formula'])),
          'attack_roll':e.get('attack_roll'),'source_status':s['canonical_status'],
          'p_hit':'PENDING_DEFENDER_CA_OR_REFLEX','damage_per_attempt':'PENDING_DEFENDER_AND_RD',
          'link_PA_daily':e.get('link_pa_per_day'),'PA_per_activation':e.get('pa_per_use'),
          'message':'Dano bruto exato; fonte do alvo necessária para acerto, RD e PV.'}
    # Infer request for activation from name, not any common verb.
    if activate is None:
        activate=c08.norm(e.get('activation',{}).get('name','')) in c08.norm(question) if e.get('activation') else False
    return compute(e,s,d,activate=activate,pa_current=pa_current,already_used=already_used,fly_distance=fly_distance,hp_current=hp_current)

def respond(x):
    if x.get('kind')=='LEGACY_C08_PRESERVED':return x['answer']
    a=x
    if a.get('kind')=='C09_PARTIAL_NO_DOCUMENTED_DEFENDER':
        return f"{a['actor']} usa {a['name']} ({a['gross_formula']}): bruto {a['gross_on_hit']['min']}–{a['gross_on_hit']['max']}, média {a['gross_on_hit']['mean']}. Falta defensor documentado; dano por tentativa, RD e Vida permanecem pendentes. Fonte {a['source_url']}"
    if a['resolution']=='SAVE_VS_FIXED_CD':
        s=(f"{a['attacker']} usa {a['ability']} contra {a['defender']}. Ataque por salvaguarda, NÃO contra CA. "
           f"Dano {a['damage_formula']} {a['damage_type']}, média bruta {a['gross_on_hit']['mean']}. "
           f"Reflexo {a['save_roll']} versus CD{a['save_cd']}; P(superar)={a['p_save_strictly_greater']}. "
           f"Após salvaguarda antes de RD elemental: FLOOR TEST={a['pre_elemental_RD']['FLOOR_TEST']}, "
           f"CEIL TEST={a['pre_elemental_RD']['CEIL_TEST']}; RD Terra pendente. "
           f"65 PA/uso, 85 PA/dia em vínculo; sem FF/crítico. {a.get('affordability')}. Fonte {a['source']['url']}; "
           f"custo e resolução documentados, cena e arredondamento não homologados.")
        return s
    s=(f"{a['attacker']} usa {a['ability']} contra {a['defender']}. "
       f"Ataque {a['attack_roll']} vs CA {a['defender_CA']}: P(acerto)={a['p_hit']} "
       f"(empate favorece defesa). Dano {a['damage_formula']}, média bruta {a['gross_on_hit']['mean']}. "
       f"Dano esperado pós-RD por tentativa: {a['base_expected_per_attempt']}. "
       f"Vínculo PA/dia {a['resource']['link_pa_daily']}; PA golpe-base {a['resource']['base_attack_PA_per_use']} (se ausente, indeterminado). ")
    if a.get('conditional_activation'):
        v=a['conditional_activation'];s+=(f"Adicional {v['name']}: +{v['extra_formula']} (média {v['extra_expected']}), "
          f"PA/ativação {v['activation_PA']}, {v['frequency']}; {v['availability']}. ")
        if 'scenarios_TEST' in v:
            s+=f"TEST RD uma aplicação: {v['scenarios_TEST']['RD_ONCE_JOINT_TEST']['per_attempt']} PV/tentativa; RD por componente: {v['scenarios_TEST']['RD_SEPARATE_COMPONENTS_TEST']['per_attempt']} (não adjudicar). "
        elif 'NO_RD_TEST' in v:s+=f"TEST sem RD: {v['NO_RD_TEST']['per_attempt']} PV/tentativa. "
    s+='Não equivale a vitória nem a combate VLAB. Fonte '+a['source']['url']
    return s

if __name__=='__main__':
    p=argparse.ArgumentParser(description='DMG C09 extensão experimental consultor de dano: usa C05-C08 intactos')
    p.add_argument('query',nargs='+');p.add_argument('--activate',action='store_true');p.add_argument('--no-activate',action='store_true')
    p.add_argument('--pa-current',type=int);p.add_argument('--already-used',choices=['yes','no','unknown'],default='unknown');p.add_argument('--fly-m',type=int);p.add_argument('--hp-current',type=int)
    p.add_argument('--supplement',type=Path);p.add_argument('--catalog',type=Path,default=CATALOG);p.add_argument('--json',action='store_true')
    a=p.parse_args()
    try:
        result=ask(' '.join(a.query),activate=True if a.activate else False if a.no_activate else None,pa_current=a.pa_current,already_used=True if a.already_used=='yes' else False if a.already_used=='no' else None,fly_distance=a.fly_m,hp_current=a.hp_current,supplement=a.supplement,catalog=Catalog(a.catalog))
        print(json.dumps(result,ensure_ascii=False,indent=2) if a.json else respond(result))
    except (ValueError,ContractError) as e:
        print('PENDENTE / ENTRADA INVÁLIDA:',str(e));sys.exit(2)
