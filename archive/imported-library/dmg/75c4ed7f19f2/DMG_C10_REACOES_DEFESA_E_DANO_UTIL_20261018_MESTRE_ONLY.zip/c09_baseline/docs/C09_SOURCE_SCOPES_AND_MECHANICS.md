# C09 — Notion Mestre reopened sources, documentary limits

All sources fetched **read-only 17/10/2026** via Notion Mestre authorized connection, not Party.

| UUID | Source and edit | Scoped mechanics | State |
|---|---|---|---|
| `3f6c2b324ede81f49ea9efbe1a811091` | [Sikong Varok](https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091), `2026-10-16T10:33:26.087Z` | `4d6+100` attack vs CA; `10d10+48` physical impact/cut, including +23 FF; 95 PA/day; Quebra +`6d12` impact after hit for 60 PA 1/scene; free PA maximum324 | VERIFIED SOURCE; PROPOSED encounter/equipment; not canonized loot |
| `3f6c2b324ede81a78a59d3d81fd5e966` | [Sikong Iskiel](https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966), `2026-10-16T10:33:53.226Z` | `4d6+101` accuracy, `9d8+47` Vento/perfurante including +21 FF, 80 m LOS; 95 PA/day; Mergulho +`5d10` Vento after 20 m flight and hit, 45 PA, 1/turn; free PA maximum484 | VERIFIED SOURCE; PROPOSED encounter; type split missing |
| `3f6c2b324ede819e879beabb795001ba` | [Sikong Veyun](https://app.notion.com/p/3f6c2b324ede819e879beabb795001ba), `2026-10-16T10:33:46.339Z` | Cetro `8d10+26` Terra, Padrão, 65 PA/use, 85 PA/day, 30 m, Reflexo CD72 for half; **specific clause no FF or critical**; free PA maximum781 | VERIFIED SOURCE; PROPOSED encounter; contradictory introductory FF +6 wording flagged, not applied |
| `3f6c2b324ede8105891fc647242e61ca` | [Sikong Arveth](https://app.notion.com/p/3f6c2b324ede8105891fc647242e61ca), `2026-10-16T10:33:37.349Z` | **post-engine-design holdout**, lance `4d6+72` vs CA; `8d10+35` physical piercing, +11 FF already included, 85 PA/day; Fissura +`6d10` Terra 55 PA 1/scene; free PA maximum344 | VERIFIED SOURCE; PROPOSED encounter; earth RD missing |
| `3f6c2b324ede819cae98ec0f6a63de76` | [Sikong Eristan](https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76), `2026-10-16T10:33:32.392Z` | CA76, physical RD25, `4d6+28` Reflexo, recorded PV maximum630; not current PV | VERFIED SOURCE; scope unreacted CA; no RD Terra/Wind demonstrated |
| `3ebc2b324ede814bb730d47dd7bd5f02` | [Sikong Auren](https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02), `2026-09-30T23:10:35.044Z` | `6d6+166` Reflexo, min172; historical physical RD35 and Dark RD60, neither proof of RD Terra | Source state must be scoped; transform/current state are not assumed |

**Authoritative systems reopened:** [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0) edit `2026-10-07T23:51:04.971Z`: an attack succeeds strictly over applicable defense; equality defends; reactions can change defense. [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373) edit `2026-10-07T23:51:07.044Z`: successful save strictly over DC, spell-specific outcome. Neither authorizes silently choosing HALF rounding.

**Not a combat result:** All C09 evaluations assume a legitimate opportunity to use the item/skill and the specified target. Conditional PA and movement/resource/frequency gates are verified only when supplied as experimental inputs. Historical SQLite untouched.
