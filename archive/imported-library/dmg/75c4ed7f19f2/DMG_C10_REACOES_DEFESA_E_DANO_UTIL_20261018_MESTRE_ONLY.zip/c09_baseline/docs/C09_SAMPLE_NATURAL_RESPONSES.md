# C09 conversational demos — MESTRE-ONLY

**A — "Quanto dano Varok causa em Eristan com Machado Raiz-Ferro?"**

Documented Varok `4d6+100` versus documented Eristan normal CA76: exact p(hit)=1 (104–124). Documented physical damage `10d10+48` including FF +23: gross 58–148, expected103 on hit. Physical RD25 from Eristan: 33–123 and expected78 per *attempt*, before unknown reactions/crits and life cap. The axe commits 95 PA/day; a normal hit does not have a separately specified activation PA cost. Target PV maximum630 is not PV currently available. Source: https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091 and https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76.

**A2 — "E com Quebra do Tronco?"**

After the hit, if 60 PA **current free** are available and the ability was not previously used this scene, `+6d12` (mean39) enters the same hit, no extra attack. Combined gross mean142. RD once jointly: conditional TEST 117 per attempt; independently subtracting RD25 from each component: conditional TEST about92.1575. Competing interpretation not adjudicated. At *current* target Vida 40, cap loss at40 and treat excess as overkill (exact PMF available). Daily linkage 95 PA is not recosted. No false assertion about historical use.

**B — "Quanto dano Iskiel consegue com Mergulho Cortante?"**

`4d6+101` vs CA76 hits 100% in no-reaction/no-crit scenario. Bow `9d8+47` Wind/perforating, expected87.5 raw. After 20m flight *same turn* and a successful shot, 45 PA and not already used this turn, extra `5d10` Wind expected27.5 produces gross mean115 on the same shot. **Because base attack has mixed typed damage without numeric allocation, actual RD effect/final PV remain unknown.** When flight <20m, no hit, used already, or insufficient PA, the add-on is blocked. Bow 95 PA/day commitment, not per shot. Source https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966.

**C — "Veyun Cetro em Eristan ou Auren"**

Specific magic discharge `8d10+26` Earth, expected70 gross, 65 PA/use, 85 PA/day bound, Reflexo CD72, higher save leads half; no physical attack roll, critical or FF addition. Eristan `4d6+28` max52 cannot exceed CD72, so mean70 pre-RD Earth. Auren `6d6+166` min172 always saves: half rounding hypotheticals yield floor34.75, ceil35.25, exact rational35. RD Earth not documented for either; no final canonical PV. The source has explanatory FF contradiction; explicit operational "sem FF" clause used only in this source-specific action. Sources https://app.notion.com/p/3f6c2b324ede819e879beabb795001ba, Eristan and Auren.

**E — Held-out on-demand source Arveth**

Read after generic engine implementation: `4d6+72` vs CA76. Only 4d6=4 ties, so 1295/1296 hits. Spear `8d10+35` physical piercing (FF +11 already present), mean79 raw and mean `1295/24` ≈53.9583 per attempt after Eristan physical RD25. Adding Fissura of Earth requires distinct RD, an on-hit trigger and once/scene PA gating, never automatically physical RD on Earth. Source https://app.notion.com/p/3f6c2b324ede8105891fc647242e61ca.

**R — Legacy regression (C07/C08)**

"Explique R157 BASIC sequencia 48": corrected R162 SPORES Eristan→Feryn, 73 after mitigation, 60 HP actually removed, overkill13, 80 PA recorded; do not apply save twice. These laboratory receipts and R169 remain separate, and no combat was rerun.
