# OP-DMG-CORPUS-EMP-01 — C09 ANTES/DEPOIS (10 product-directed stages)

AS-OF 17/10/2026. Baseline DMG-RANK-01 v1.1 unchanged. C08 SHA256 `4653b03dd640326a449588fb902a076e85cd802324b97827cdb3be2d58c259ef`. F0 remains 4/8.

| Stage | ANTES C08 | DEPOIS verified/tested C09 | Acceptance / remaining |
|---|---|---|---|
| 1 Input hardening | Supplemental missing `last_edited` could produce Python KeyError | C09 validates missing metadata as `SUPPLEMENT_SOURCE_0_MISSING_REQUIRED: last_edited`, explicitly TEST regardless claimed verified | PASS technical / source still must be physically fetched |
| 2 Varok source | Not in C08 catalog | Physically reopened, new data patch; 4d6+100, 10d10+48, FF already included | PASS documentation; encounter proposal |
| 3 Exact hit probability | C08 did not derive generic p_hit from offense roll vs CA | `P(4d6+100 > 76)=1`, gross103, physical RD25, per attempt78 | PASS scoped to CA no reaction/no critical |
| 4 Triggered activation | No generic resource/frequency/trigger branch | Quebra +6d12 and +60PA after hit, 1/scene; branches RD once total (TEST117) vs separate (TEST ≈92.16) | PASS conditional; competent RD stacking policy needed |
| 5 Iskiel source | Absent | Generic `4d6+101` vs CA76; base 9d8+47; +5d10 Wind 45PA only if 20m flight and hit and not already used; 95PA/day | PASS partial; mixed base Wind/perforating RD partition unknown |
| 6 Veyun magic save | C08 only earlier fixed known spell cases | Generic Reflexo vs CD72, 8d10+26 Earth, Eristan full70 and Auren half34.75–35.25 TEST | PASS conditional; earth RD and odd rounding unknown, no FF/crit |
| 7 Resource semantics | PA/daily and activation separate in C08 but no general triggered cost | Source PA total/committed/free_max; cost paid after hit if eligibility; already_used, 19m flight, insufficient PA controlled | PASS; PA **currently available** not inferred from max |
| 8 New source on-demand | More catalog entries often imply code edits | Arveth fetched *after design*, admitted in patch unchanged; p_hit1295/1296 vs CA76 | PASS holdout source; not independent campaign execution |
| 9 Directed & independent QA | 48 C08 tests baseline | 40 directed C09, 29 independent combinatorial checks, 3 C08/C07 regressions; original seven files byte-identical | PASS / no official terminal benchmark |
| 10 Portable package & readback | C08 package authenticated | C09 portable archive, clean extraction, hash manifest, Library readback receipt | PASS technical only if physically materialized identical |

**Denominators are distinct.** Four new source-attacker pages (Varok, Iskiel, Veyun, Arveth), two examined source-defenders (Eristan, Auren), four main formula PMFs, three conditional add-ons, 12 recorded query demonstrations, 40 targeted tests, 29 independent oracle checks. This is not RPG-wide corpus coverage; 571 A6 historical IDs remain frozen.

**Formal plan:** F1–F4 evidence of physically sourced parameter-rich effects; F7–F9 source-scoped accuracy and conditional cost; F11 experimental benchmark groundwork; F12 bias/unknown RD, rounding and encounter proposal segregation. **No F0–F18 phase promoted** and no E01–E24/8 transverse gates certified. F0 4/8, A5 0/7 historical binary readbacks, A7 0/8 blind validations, A8 no writer/lease/epoch. R156 UNKNOWN_EFFECT, R138 HOLD unchanged. R162 (154 corrected) and R169 (137 independent cohort) historical CSV reused without retcon, R170 0/17 terminal and 0/1875 official cells.

**Follow-up:** Determine official RD policy for triggered impacts, split Wind/perforating bow damage if source competent, secure current PA/PV plus target positions, verify half rounding through competent rule, broaden on-demand source admissions. No party disclosure, no sheet/SQLite modifications.
