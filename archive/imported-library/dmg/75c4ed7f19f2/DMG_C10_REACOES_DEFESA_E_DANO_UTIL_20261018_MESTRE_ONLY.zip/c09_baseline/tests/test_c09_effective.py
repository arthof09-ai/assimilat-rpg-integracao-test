from __future__ import annotations
import sys, json, tempfile, unittest, copy
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import c09_effective as m
class C09Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.cat=m.Catalog()
 def run_case(self,ask,**kw):return m.ask(ask,catalog=self.cat,**kw)
 def test_01_varok_hit(self):
  x=self.run_case('Varok Machado Raiz-Ferro contra Eristan');self.assertEqual(x['p_hit'],'1');self.assertEqual(x['attack_min'],104);self.assertEqual(x['attack_max'],124)
 def test_02_varok_raw(self):
  x=self.run_case('Varok contra Eristan');self.assertEqual(x['gross_on_hit']['mean'],'103');self.assertEqual(x['gross_on_hit']['min'],58);self.assertEqual(x['gross_on_hit']['max'],148)
 def test_03_varok_rd(self):
  x=self.run_case('Varok contra Eristan');self.assertEqual(x['base_expected_per_attempt'],'78');self.assertEqual(x['base_post_RD_on_hit']['min'],33);self.assertEqual(x['rd_source'],'DOCUMENTED_DEFENDER_PHYSICAL')
 def test_04_varok_daily_PA(self):
  x=self.run_case('Varok contra Eristan');self.assertEqual(x['resource']['link_pa_daily'],95);self.assertEqual(x['resource']['base_attack_PA_per_use'],None)
 def test_05_varok_extra(self):
  x=self.run_case('Varok Quebra do Tronco contra Eristan',activate=True,already_used=False,pa_current=80)
  a=x['conditional_activation'];self.assertEqual(a['gross_combined_on_hit']['mean'],'142');self.assertEqual(a['scenarios_TEST']['RD_ONCE_JOINT_TEST']['per_attempt'],'117');self.assertEqual(a['expected_activation_PA_per_attempt_IF_ENABLED'],'60')
 def test_06_varok_second_RD_scenario(self):
  x=self.run_case('Varok Quebra do Tronco contra Eristan',activate=True,already_used=False,pa_current=80)
  a=x['conditional_activation'];self.assertLess(F(a['scenarios_TEST']['RD_SEPARATE_COMPONENTS_TEST']['per_attempt']),117)
 def test_07_used_once(self):
  x=self.run_case('Varok Quebra do Tronco contra Eristan',activate=True,already_used=True,pa_current=100)
  self.assertEqual(x['conditional_activation']['availability'],'BLOCKED_ALREADY_USED');self.assertNotIn('scenarios_TEST',x['conditional_activation'])
 def test_08_insufficient_PA(self):
  x=self.run_case('Varok Quebra do Tronco contra Eristan',activate=True,already_used=False,pa_current=59)
  self.assertEqual(x['conditional_activation']['availability'],'BLOCKED_INSUFFICIENT_PA')
 def test_09_frequency_unknown(self):
  x=self.run_case('Varok Quebra do Tronco contra Eristan',activate=True,pa_current=100)
  self.assertEqual(x['conditional_activation']['availability'],'HOLD_FREQUENCY_STATE_TEST_ASSUME_UNUSED')
 def test_10_no_extra_attack(self):
  x=self.run_case('Varok Quebra do Tronco contra Eristan',activate=True,pa_current=100)
  self.assertEqual(x['conditional_activation']['no_extra_attack'],True)
 def test_11_hp_limit(self):
  x=self.run_case('Varok contra Eristan',hp_current=1)
  self.assertEqual(x['base_hp_per_attempt'],'1');self.assertEqual(x['base_overkill_per_attempt'],'77')
 def test_12_iskiel_normal(self):
  x=self.run_case('Iskiel Arco da Asa Rasgada contra Eristan');self.assertEqual(x['p_hit'],'1');self.assertEqual(x['gross_on_hit']['mean'],'175/2');self.assertIn('HOLD_MIXED',x['base_expected_per_attempt'])
 def test_13_iskiel_addition(self):
  x=self.run_case('Iskiel Mergulho Cortante contra Eristan',activate=True,already_used=False,pa_current=45,fly_distance=20)
  a=x['conditional_activation'];self.assertEqual(a['gross_combined_on_hit']['mean'],'115');self.assertEqual(a['availability'],'PRECONDITIONS_DOCUMENTED_FOR_TEST');self.assertEqual(a['PA_on_success_only'],45)
 def test_14_flight_insufficient(self):
  x=self.run_case('Iskiel Mergulho Cortante contra Eristan',activate=True,already_used=False,pa_current=60,fly_distance=19)
  self.assertEqual(x['conditional_activation']['availability'],'BLOCKED_FLY_DISTANCE_LT20')
 def test_15_is_95_daily_not_attack(self):
  x=self.run_case('Iskiel contra Eristan');self.assertEqual(x['resource']['link_pa_daily'],95);self.assertIsNone(x['resource']['base_attack_PA_per_use'])
 def test_16_save_eristan(self):
  x=self.run_case('Veyun Cetro contra Eristan');self.assertEqual(x['p_save_strictly_greater'],'0');self.assertEqual(x['pre_elemental_RD']['FLOOR_TEST'],'70')
 def test_17_save_auren(self):
  x=self.run_case('Veyun Cetro contra Auren');self.assertEqual(x['p_save_strictly_greater'],'1');self.assertEqual(x['pre_elemental_RD']['FLOOR_TEST'],'139/4');self.assertEqual(x['pre_elemental_RD']['CEIL_TEST'],'141/4')
 def test_18_mage_no_ff(self):
  x=self.run_case('Veyun Cetro contra Eristan');self.assertFalse(x['ff_included_in_magical_discharge']);self.assertEqual(x['gross_on_hit']['mean'],'70')
 def test_19_mage_two_kinds_pa(self):
  x=self.run_case('Veyun contra Eristan');self.assertEqual(x['resource']['link_pa_daily'],85);self.assertEqual(x['PA_per_cast'],65)
 def test_20_mage_no_physical_RD(self):
  x=self.run_case('Veyun contra Eristan');self.assertEqual(x['RD_TERRA'],'UNVERIFIED_NOT_APPLIED')
 def test_21_mage_not_ca(self):
  x=self.run_case('Veyun contra Eristan');self.assertEqual(x['resolution'],'SAVE_VS_FIXED_CD');self.assertNotIn('p_hit',x)
 def test_22_mage_affordability(self):
  x=self.run_case('Veyun contra Eristan',pa_current=64);self.assertEqual(x['affordability'],'NOT_EXECUTABLE_PA_INSUFFICIENT')
 def test_23_holdout_arveth(self):
  x=self.run_case('Arveth Bastião contra Eristan');self.assertEqual(x['p_hit'],'1295/1296');self.assertEqual(x['gross_on_hit']['mean'],'79');self.assertEqual(x['base_expected_per_attempt'],'1295/24')
 def test_24_holdout_no_Rd_earth(self):
  x=self.run_case('Arveth Fissura da Garganta contra Eristan',activate=True,already_used=False,pa_current=100)
  self.assertEqual(x['conditional_activation']['rd_policy'],'HOLD_MIXED_TYPES_RD_PARTITION_OR_ELEMENTAL_RD');self.assertNotIn('scenarios_TEST',x['conditional_activation'])
 def test_25_holdout_tie(self):
  x=self.run_case('Arveth Bastião contra Eristan');self.assertEqual(x['attack_min'],76);self.assertTrue(x['tie_favors_defense'])
 def test_26_partial_without_defender(self):
  x=self.run_case('Varok Machado Raiz-Ferro');self.assertEqual(x['kind'],'C09_PARTIAL_NO_DOCUMENTED_DEFENDER');self.assertEqual(x['gross_on_hit']['mean'],'103')
 def test_27_invalid_pa(self):
  with self.assertRaises(m.ContractError):self.run_case('Varok contra Eristan',pa_current=-1)
 def test_28_invalid_hp(self):
  with self.assertRaises(m.ContractError):self.run_case('Varok contra Eristan',hp_current=-1)
 def test_29_missing_last_edited(self):
  with tempfile.TemporaryDirectory() as q:
   p=Path(q)/'source.json';p.write_text(json.dumps({'sources':[{'uuid':'f'*32,'url':'https://app.notion.com/p/'+('f'*32),'name':'Teste','attributes':{},'classification_body':'TEST','classification_status':'PENDENTE'}],'effects':[]}),encoding='utf-8')
   with self.assertRaisesRegex(m.ContractError,'SUPPLEMENT_SOURCE_0_MISSING_REQUIRED: last_edited'):m.validate_supplement(p)
 def test_30_self_declaration_not_verified(self):
  with tempfile.TemporaryDirectory() as q:
   p=Path(q)/'source.json';p.write_text(json.dumps({'sources':[{'uuid':'e'*32,'url':'https://app.notion.com/p/'+('e'*32),'name':'Suplemento','last_edited':'2026-10-17T01:01:00.000Z','attributes':{},'classification_body':'TEST','classification_status':'PENDENTE','source_evidence':'VERIFICADO'}],'effects':[]}),encoding='utf-8')
   x=m.validate_supplement(p);self.assertEqual(x['sources'][0]['source_evidence'],'TEST_UNVERIFIED_SUPPLEMENT')
 def test_31_c08_gamba(self):
  x=self.run_case('Quanto dano causa o Arranhão Putrificador?');self.assertEqual(x['kind'],'LEGACY_C08_PRESERVED');self.assertIn('média exata 32',x['answer'])
 def test_32_c08_test(self):
  x=self.run_case('Calcule 2d6+25 RD fisica 10 Vida 40 como TEST');self.assertEqual(x['kind'],'LEGACY_C08_PRESERVED');self.assertIn('média 22',x['answer'])
 def test_33_c07_r157(self):
  x=self.run_case('Explique o evento R157 BASIC sequencia 48');self.assertEqual(x['kind'],'LEGACY_C08_PRESERVED');self.assertIn('13',x['answer']);self.assertIn('73',x['answer']);self.assertIn('60',x['answer'])
 def test_34_reflex_missing(self):
  fake=copy.deepcopy(self.cat);fake.defenders['Sikong Eristan']['reflex_roll']=None
  x=m.compute(*fake.effects['veyun_scepter'],fake.defenders['Sikong Eristan']);self.assertEqual(x['save_success'],'HOLD_DEFENDER_REFLEX_ROLL')
 def test_35_defender_ca_unknown(self):
  fake=copy.deepcopy(self.cat);fake.defenders['Sikong Eristan']['ca']=None
  with self.assertRaisesRegex(m.ContractError,'DEFENSE_CA_DOCUMENTATION_REQUIRED'):m.compute(*fake.effects['varok_axe'],fake.defenders['Sikong Eristan'])
 def test_36_rd_type_wrong(self):
  with self.assertRaisesRegex(m.ContractError,'RD_OVERRIDE_TYPE_MISMATCH'):m.ask('Varok contra Eristan',catalog=self.cat) if False else m.compute(*self.cat.effects['varok_axe'],self.cat.defenders['Sikong Eristan'],rd_override=10,rd_override_type='VENTO')
 def test_37_no_unknown_critical(self):
  x=self.run_case('Varok contra Eristan');self.assertTrue(x['no_automatic_critical'])
 def test_38_damage_type_source_varok(self):
  x=self.run_case('Varok contra Eristan');self.assertEqual(x['FF_ALREADY_IN_GROSS'],23)
 def test_39_damage_type_source_iskiel(self):
  x=self.run_case('Iskiel contra Eristan');self.assertEqual(x['FF_ALREADY_IN_GROSS'],21)
 def test_40_result_is_not_combat(self):
  x=self.run_case('Varok contra Eristan');self.assertTrue(x['no_vlab_combat_executed'])
if __name__=='__main__':unittest.main(verbosity=1)
