#!/usr/bin/env python3
"""Independent combinatorial oracle, not using C05 PMF to derive reference answers."""
from __future__ import annotations
import sys,json
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
from itertools import product
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import c09_effective as actual

counter={'checks':0}
def ck(label,condition):
 counter['checks']+=1
 if not condition:raise AssertionError(label)

def poly(n,faces,fixed=0):
 c=Counter({fixed:1})
 for _ in range(n):
  new=Counter()
  for score,ways in c.items():
   for die in range(1,faces+1):new[score+die]+=ways
  c=new
 return c

def expectation(c):return F(sum(x*p for x,p in c.items()),sum(c.values()))
def transform(c,fn):return F(sum(fn(x)*p for x,p in c.items()),sum(c.values()))
def pwin(c,threshold):return F(sum(p for x,p in c.items() if x>threshold),sum(c.values()))

v=actual.ask('Varok contra Eristan')
d=poly(4,6,100)
ck('Varok pwin',F(v['p_hit'])==pwin(d,76)==1)
ck('Varok minmax',v['attack_min']==104 and v['attack_max']==124)
d=poly(10,10,48)
ck('Varok gross',expectation(d)==F(v['gross_on_hit']['mean'])==103)
ck('Varok mitigation',transform(d,lambda x:max(0,x-25))==F(v['base_expected_per_attempt'])==78)
ck('Varok hp1',F(actual.ask('Varok contra Eristan',hp_current=1)['base_hp_per_attempt'])==1)
v=actual.ask('Varok Quebra do Tronco contra Eristan',activate=True,already_used=False,pa_current=60)
a=v['conditional_activation'];aux=poly(6,12)
ck('Extra mean',expectation(aux)==39==F(a['extra_expected']))
ck('Joint gross',103+39==F(a['gross_combined_on_hit']['mean'])==142)
ck('Joint RD once',F(a['scenarios_TEST']['RD_ONCE_JOINT_TEST']['per_attempt'])==117)
# Independent product exact, verify different RD policy without reusing C05 convolution.
separate=transform(d,lambda x:max(0,x-25))+transform(aux,lambda x:max(0,x-25))
ck('Separate RD exact',F(a['scenarios_TEST']['RD_SEPARATE_COMPONENTS_TEST']['per_attempt'])==separate)
ck('Distinct modes',separate<117)
# Independent count of all six-face outcomes includes tie at exactly 76 only (1,1,1,1).
attack=[sum(roll)+72 for roll in product(range(1,7),repeat=4)]
p=F(sum(x>76 for x in attack),len(attack))
a=actual.ask('Arveth Bastião contra Eristan')
ck('Holdout p',p==F(1295,1296)==F(a['p_hit']))
sp=poly(8,10,35)
ck('Holdout gross',expectation(sp)==79==F(a['gross_on_hit']['mean']))
ck('Holdout RD',F(a['base_expected_per_attempt'])==p*transform(sp,lambda x:max(0,x-25)))
# Veyun save against two source-scoped reflex tests.
attack=poly(8,10,26)
ck('Veyun gross',expectation(attack)==70)
rE=poly(4,6,28);rA=poly(6,6,166)
ck('Eristan save',pwin(rE,72)==F(actual.ask('Veyun contra Eristan')['p_save_strictly_greater'])==0)
ck('Auren save',pwin(rA,72)==F(actual.ask('Veyun contra Auren')['p_save_strictly_greater'])==1)
ck('Half floor',transform(attack,lambda x:x//2)==F(actual.ask('Veyun contra Auren')['pre_elemental_RD']['FLOOR_TEST'])==F(139,4))
ck('Half ceil',transform(attack,lambda x:(x+1)//2)==F(actual.ask('Veyun contra Auren')['pre_elemental_RD']['CEIL_TEST'])==F(141,4))
ck('Rational half',expectation(attack)/2==35)
i=actual.ask('Iskiel contra Eristan')
ck('Iskiel mean',expectation(poly(9,8,47))==F(i['gross_on_hit']['mean'])==F(175,2))
ck('Iskiel not mis-rd',i['base_expected_per_attempt']=='HOLD_MIXED_WIND_PIERCING_RD_PARTITION')
iv=actual.ask('Iskiel Mergulho Cortante contra Eristan',activate=True,already_used=False,pa_current=100,fly_distance=20)
ck('Iskiel plus 5d10',expectation(poly(5,10))==F(55,2))
ck('Iskiel plus combined',F(iv['conditional_activation']['gross_combined_on_hit']['mean'])==115)
ck('Iskiel no rd claim',iv['conditional_activation']['rd_policy']=='HOLD_MIXED_TYPES_RD_PARTITION_OR_ELEMENTAL_RD')
# Regulatory policy and controlled rejection tests.
ck('No reapplication FF',v['FF_ALREADY_IN_GROSS']==23)
ck('Daily different from activation',v['resource']['link_pa_daily']==95 and a is not None)
ck('No magic FF',actual.ask('Veyun contra Eristan')['ff_included_in_magical_discharge']==False)
ck('Save not physical',actual.ask('Veyun contra Eristan')['resolution']=='SAVE_VS_FIXED_CD')
ck('Holdout attested not canonized',actual.ask('Arveth contra Eristan')['source']['status'].startswith('PROPOSTO'))
print(json.dumps({'status':'PASS','independent_checks':counter['checks'],'oracle':'polynomial convolution + manual cartesian 4d6 + exact parity and fraction; independent implementation','baseline':'C05-C08 unchanged'},ensure_ascii=False,indent=2))
