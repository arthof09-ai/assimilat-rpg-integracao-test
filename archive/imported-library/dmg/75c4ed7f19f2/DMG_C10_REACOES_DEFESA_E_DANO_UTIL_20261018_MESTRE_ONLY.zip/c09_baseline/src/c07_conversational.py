#!/usr/bin/env python3
"""DMG C07 — consultation router for Portuguese Mestre-side questions.
NO network, NO mutations, NO VLAB simulation, NO DMG-RANK edits.
The finite registry is a versioned whitelist of individually read Mestre sources.
The C06 mathematical distribution engine is used WITHOUT modifications.
"""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import argparse, csv, json, re, unicodedata
from c06_damage_resolver import dist, mean, compare_rolls, mode_distribution, evaluate_physical, NeedsSource

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / 'data'
SRC={
 'feryn':'https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31',
 'eristan':'https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76',
 'auren':'https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02',
 'combat':'https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0',
 'magic':'https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373'
}
VERSION={'feryn':'2026-10-16T10:33:13.379Z','eristan':'2026-10-16T10:33:32.392Z','auren':'2026-09-30T23:10:35.044Z','combat':'2026-10-07T23:51:04.971Z','magic':'2026-10-07T23:51:07.044Z'}
PROFILES={
 'eristan': {'reflex':'4d6+28','ca':76,'physical_rd':25,'name':'Sikong Eristan'},
 'auren': {'reflex':'6d6+166','ca':None,'physical_rd':None,'name':'Sikong Auren'},
 'feryn': {'reflex':'4d6+82','ca':123,'physical_rd':22,'name':'Sikong Feryn'},
}
ATTACKS={
 'turbilhao': {'name':'Turbilhão Cinzento','actor':'feryn','damage':'9d10+8','type':'vento','cost':60,'action':'Padrão','range':'cone 8 m','resolve':'opposed_save','offense':'4d6+92','success':'half','crit':'EXCLUDED_BY_SOURCE','single_cast_cost':True},
 'presas': {'name':'Presas da Noite sem Pegadas — golpe normal','actor':'feryn','damage':'8d8+47','type':'fisico','cost':None,'action':'Padrão','range':'corpo a corpo','resolve':'physical_vs_CA','offense':'4d6+92','crit':'EXCLUDED_BY_TEST_NO_CRIT','single_cast_cost':False},
 'descarga': {'name':'Descarga do Cajado da Última Seiva','actor':'eristan','damage':'8d10+26','type':'planta','cost':65,'action':'Padrão','range':'25 m','resolve':'fixed_save','save_cd':76,'success':'half','crit':'EXCLUDED_BY_SOURCE','single_cast_cost':True}
}

def norm(s):
 s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
 return re.sub(r'\s+',' ',s)

def fmt(value, digits=4):
 if value is None: return 'INDETERMINADO'
 if isinstance(value,str):
  try:value=F(value)
  except (ValueError,ZeroDivisionError):return value
 if isinstance(value,F):return str(value.numerator) if value.denominator==1 else f'{float(value):.{digits}f}'.rstrip('0').rstrip('.').replace('.',',')
 return str(value)

def pick_profile(s):
 normalized=norm(s)
 if 'auren' in normalized:return 'auren'
 if 'eristan' in normalized:return 'eristan'
 if 'feryn' in normalized:return 'feryn'
 return None

def pick_attack(s):
 q=norm(s)
 if 'turbilhao' in q:return 'turbilhao'
 if 'presas' in q or 'adaga' in q or 'golpe fisico' in q or 'golpe normal' in q:return 'presas'
 if 'descarga' in q or 'cajado' in q:return 'descarga'
 return None

def named_parameters(s):
 q=norm(s)
 rd=re.search(r'\brd(?:\s+(?:de|do|da))?\s*(?:de\s+)?(vento|fisic[ao]|planta|fogo|gelo|raio)?\s*[:=]?\s*(\d+)\b',q)
 hp=re.search(r'\b(?:vida(?:\s+atual)?|pv(?:\s+atual)?|hp)\s*[:=]?\s*(\d+)\b',q)
 n=re.search(r'\b(\d+)\s+alvos?\b',q)
 return {'rd_type':('fisico' if rd and rd.group(1) and rd.group(1).startswith('fisic') else rd.group(1) if rd else None),'rd':int(rd.group(2)) if rd else None,'hp':int(hp.group(1)) if hp else None,'targets':int(n.group(1)) if n else None}

def _get_rd(attack, defender, kwargs):
 if kwargs.get('rd') is not None:
  if not kwargs.get('rd_type'):return None,'HOLD: RD fornecida sem tipo elemental.'
  if kwargs['rd_type']!=attack['type']:return None,f"HOLD: RD {kwargs['rd_type']} incompatível com {attack['type']}."
  return kwargs['rd'],'TEST — parâmetro fornecido na pergunta, não fonte canônica.'
 if attack['type']=='fisico' and defender.get('physical_rd') is not None:
  return defender['physical_rd'],'DOCUMENTADO — RD física da ficha do defensor.'
 return None,'INDETERMINADO — RD compatível por tipo não documentada nas fontes consultadas.'

def _half_results(d, success_probability, rd, hp, pa_cost):
 # Separate authorized fractional expectation from noncanonical integer choices.
 rounds={}
 for mode in ['FLOOR_TEST','CEIL_TEST']:
  r=mode_distribution(d,defender_success=success_probability,success_effect='HALF',half_rounding=mode,damage_type='vento',rd_value=rd,rd_type='vento' if rd is not None else None,rd_evidence='TEST' if rd is not None else None,target_hp=hp,pa_cost=pa_cost)
  rounds[mode]={'post_rd':F(r['post_RD_expected']),'hp':F(r['hp_effective_expected']),'overkill':F(r['overkill_expected'])}
 return rounds

def compute_attack(key, target, *,rd=None,rd_type=None,hp=None,targets=None):
 if key not in ATTACKS or target not in PROFILES:raise NeedsSource('Fonte de atacante/habilidade/defensor ainda não indexada.')
 a=ATTACKS[key];p=PROFILES[target]
 if a['actor']==target:raise NeedsSource('Atacante igual ao defensor não é consulta de ataque válida sem alvo próprio explicitamente documentado.')
 d=dist(a['damage']);gross=mean(d);rd_used,rd_note=_get_rd(a,p,{'rd':rd,'rd_type':rd_type})
 if rd is not None and rd_used is None:raise NeedsSource(rd_note)
 out={'kind':'ACTION','actor':a['actor'],'target':target,'attack':a['name'],'damage':a['damage'],'type':a['type'],'gross_expected':gross,'min':min(d),'max':max(d),'cost_PA':a['cost'],'action':a['action'],'range':a['range'],'sources':[SRC[a['actor']],SRC[target],SRC['combat'],SRC['magic']],'source_edited':{k:VERSION[k] for k in set([a['actor'],target,'combat','magic'])},'rd':rd_used,'rd_note':rd_note,'missing_rd_math_scope':'ONLY_PRE_RD_OR_RD_0_TEST_NEVER_FINAL_CANON' if rd_used is None else None,'hp_input':hp,'targets_input':targets,'critical_status':a['crit'],'provenance':'MESTRE_SIDE_DOCUMENTED_SOURCE_PROPOSED_NPC_PLUS_CONDITIONAL_MATH_NOT_COMBAT'}
 if a['resolve']=='opposed_save':
  opposition=compare_rolls(a['offense'],p['reflex'])
  s=opposition['defender_strict_success']
  out['resolve']='REFLEXO_VS_LUTA_SPECIFIC';out['attack_roll']=a['offense'];out['defense_roll']=p['reflex'];out['p_defender_exceeds']=s;out['p_tie']=opposition['tie'];out['expected_pre_RD_rational_half']=gross*(1-s/F(2));out['rounding']='HALF_ODD_POLICY_UNRESOLVED';out['half_bounds']={}
  for mode in ['FLOOR_TEST','CEIL_TEST']:
   r=mode_distribution(a['damage'],defender_success=s,success_effect='HALF',half_rounding=mode,damage_type=a['type'],rd_value=rd_used,rd_type=a['type'] if rd_used is not None else None,rd_evidence='TEST' if rd_used is not None else None,target_hp=hp,pa_cost=a['cost'],target_count=targets)
   out['half_bounds'][mode]={'pre_or_post_RD_expected':F(r['post_RD_expected']),'hp_effective_expected':F(r['hp_effective_expected']),'overkill_expected':F(r['overkill_expected']),'pv_per_PA':F(r['hp_effective_expected'])/a['cost'],'total_targets_expected':F(r['hp_effective_expected'])*(targets or 1)}
 elif a['resolve']=='physical_vs_CA':
  if p['ca'] is None:raise NeedsSource('CA do defensor não documentada nesta seleção.')
  res=evaluate_physical(attacker_roll=a['offense'],defender_ca=p['ca'],damage_formula=a['damage'],damage_type=a['type'],source_refs=out['sources'],rd=rd_used,rd_type=a['type'] if rd_used is not None else None,rd_evidence='DOCUMENTED' if rd_used is not None else None,target_hp=hp)
  out.update({'resolve':'PHYSICAL_VS_CA_NO_CRIT','p_hit':F(res['p_hit']),'expected_per_attempt_pre_or_post_RD':F(res['hp_per_attempt']),'on_hit_expected':F(res['hit_conditional']['post_RD_expected']),'hp_effective_expected':F(res['hit_conditional']['hp_effective_expected']),'overkill_expected':F(res['hit_conditional']['overkill_expected']),'warning':'CRÍTICO excluído deste comparador; não é expectativa de combate integral.'})
 elif a['resolve']=='fixed_save':
  opp=dist(p['reflex']);s=sum((v for val,v in opp.items() if val>a['save_cd']),F(0));out.update({'resolve':'FIXED_CD_SAVE','save_CD':a['save_cd'],'defender_roll':p['reflex'],'p_defender_exceeds':s,'half_bounds':{}})
  for mode in ['FLOOR_TEST','CEIL_TEST']:
   r=mode_distribution(a['damage'],defender_success=s,success_effect='HALF',half_rounding=mode,damage_type=a['type'],rd_value=rd_used,rd_type=a['type'] if rd_used is not None else None,rd_evidence='TEST' if rd_used is not None else None,target_hp=hp,pa_cost=a['cost'],target_count=targets)
   out['half_bounds'][mode]={'pre_or_post_RD_expected':F(r['post_RD_expected']),'hp_effective_expected':F(r['hp_effective_expected']),'overkill_expected':F(r['overkill_expected']),'pv_per_PA':F(r['hp_effective_expected'])/a['cost'],'total_targets_expected':F(r['hp_effective_expected'])*(targets or 1)}
 return out

def run_load(cohort):
 if cohort not in ('R162','R169'):raise NeedsSource('Coorte R162 (R160 corrigido) ou R169 obrigatória.')
 path=DATA/('R162_CORRECTED_RECEIPTS_R160_HISTORICAL_UNMODIFIED.csv' if cohort=='R162' else 'R169_NEW_NATIVE_RECEIPTS_137_SOURCE_SCOPED.csv')
 if not path.is_file():raise FileNotFoundError(f'DEPENDENCY_REQUIRED: {path.name}')
 with open(path,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def agg(cohort, filter_run=None):
 rows=run_load(cohort)
 if filter_run:
  rows=[r for r in rows if r['run_id'].casefold()==filter_run.casefold()]
  if not rows:raise NeedsSource('RUN-ID não pertence a essa coorte.')
 k='damage_raw' if cohort=='R162' else 'raw_damage';pa='PA_spent' if cohort=='R162' else 'PA_spent_allocated_to_event'
 out={'kind':'COHORT' if not filter_run else 'RUN','cohort':cohort,'run_id':filter_run,'n_events':len(rows),'n_runs':len(set(r['run_id'] for r in rows)),'raw':sum(int(r[k]) for r in rows),'rd':sum(int(r['rd_applied']) for r in rows),'post':sum(int(r['net_post_RD']) for r in rows),'hp':sum(int(r['hp_effectively_lost']) for r in rows),'overkill':sum(int(r['overkill']) for r in rows),'PA_allocated_sum':sum(int(r[pa] or 0) for r in rows),'origins':{x:sum(1 for r in rows if r['attack_origin']==x) for x in sorted(set(r['attack_origin'] for r in rows))},'warnings':['Recibos correlacionados por cena; não são sementes independentes.','PA_evento pode omitir reservas e custos de oportunidade, não inferir PA da cena.','Fonte VLAB sandbox SOURCE-SCOPED, não campanha oficial.']}
 if out['post']!=out['hp']+out['overkill'] or out['raw']!=out['rd']+out['post']:raise RuntimeError('LEDGER_MISMATCH')
 return out

def event_query(cohort, run_id=None, seq=None, actor=None,target=None,action_index=None):
 rows=run_load(cohort)
 if run_id:rows=[r for r in rows if run_id.casefold() in r['run_id'].casefold()]
 if seq is not None:rows=[r for r in rows if int(r['seq_R18'])==int(seq)]
 idx_key='action_index_in_tx' if cohort=='R162' else 'native_action_in_commit'
 if action_index is not None:rows=[r for r in rows if int(r[idx_key])==int(action_index)]
 ak='actor' if cohort=='R162' else 'source_actor';tk='target' if cohort=='R162' else 'source_target'
 if actor:rows=[r for r in rows if norm(actor) in norm(r[ak])];
 if target:rows=[r for r in rows if norm(target) in norm(r[tk])]
 if not rows:raise NeedsSource('Nenhum recibo para os filtros; não substituí por outro RUN-ID.')
 if len(rows)!=1:return {'kind':'EVENT_SELECTION','cohort':cohort,'matched':len(rows),'candidates':[{'run_id':r['run_id'],'seq':r['seq_R18'],'native_action_index':r[idx_key],'actor':r[ak],'target':r[tk]} for r in rows[:12]],'message':'Identifique RUN-ID completo e sequência para selecionar um evento univocamente.'}
 r=rows[0];after=int(r['hp_after']);before=int(r['hp_before']);raw=int(r['damage_raw' if cohort=='R162' else 'raw_damage']);rd=int(r['rd_applied']);post=int(r['net_post_RD']);hp=int(r['hp_effectively_lost']);ov=int(r['overkill'])
 if raw-rd!=post or post!=hp+ov or before-after!=hp:raise RuntimeError('NATIVE_STATE_INCONSISTENT')
 return {'kind':'EVENT','cohort':cohort,'run':r['run_id'],'seed':r['seed'],'seq':int(r['seq_R18']),'native_action_index':int(r[idx_key]),'event_hash':r['source_event_sha256' if cohort=='R162' else 'event_SHA256'],'actor':r[ak],'target':r[tk],'actor_label':({'E':'Sikong Eristan','F':'Sikong Feryn'}.get(r[ak],r[ak]) if cohort=='R162' and r['run_id'].startswith(('R157_','R158_')) else r[ak]),'target_label':({'E':'Sikong Eristan','F':'Sikong Feryn'}.get(r[tk],r[tk]) if cohort=='R162' and r['run_id'].startswith(('R157_','R158_')) else r[tk]),'action':r['action'] if cohort=='R162' else 'NATIVE_OFFENSE_EVENT','ability':r['source_spec'] if cohort=='R162' else 'INDETERMINATE_FROM_CSV','scene_scope':r.get('scenario_scope',''),'origin':r['attack_origin'],'type':r['damage_type'],'raw':raw,'rd':rd,'post':post,'hp_before':before,'hp_after':after,'hp':hp,'overkill':ov,'PA':int(r['PA_spent'] if cohort=='R162' else r['PA_spent_allocated_to_event'] or 0),'hit':r['hit'],'save':r.get('save_effect','') if cohort=='R162' else r.get('save_or_reaction',''),'save_CD':r.get('save_CD',''),'save_score':r.get('save_score',''),'critical':r['critical' if cohort=='R162' else 'crit'],'semantics':'R162 native spell raw may already be POST SAVE; do not halve twice.' if cohort=='R162' else 'R169 native already resolved receipt','scope':'LAB_ONLY_NON_OFFICIAL','limitations':r.get('limitations',r.get('source_assumption',''))}

def jsonable(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return{k:jsonable(v) for k,v in x.items()}
 if isinstance(x,list):return [jsonable(v) for v in x]
 return x

def ask(question):
 """Deterministic bounded Portuguese query interface. Unknown or ambiguous -> explicit unresolved.
 No network, no automatic synthesis of a new source, no prior history required.
 """
 q=norm(question);parm=named_parameters(question)
 if 'r169' in q or 'r162' in q or 'r160' in q or 'vlab' in q or re.search(r'\br1(?:57|58|65|66|68)\b',q):
  cohort='R169' if ('r169' in q or 'r165' in q or 'r166' in q or 'r168' in q) else 'R162'
  run=re.search(r'\bR(?:15[34789]|16[568])_[A-Za-z0-9_]+',question,re.I)
  seq=re.search(r'(?:seq(?:uencia)?|evento|commit)\s*(?:=|:|#|n[º°]?)?\s*(\d+)\b',q)
  idx=re.search(r'(?:indice|index|action_index|acao\s+nativa)\s*(?:=|:|#)?\s*(\d+)\b',q)
  if seq:
   return event_query(cohort,run.group(0) if run else None,int(seq.group(1)),action_index=int(idx.group(1)) if idx else None)
  if 'coorte' in q or 'total' in q or ('r169' in q and not run) or ('r160' in q and not run):return agg(cohort)
  if run:return agg(cohort,run.group(0))
  return {'kind':'REQUEST_MORE_EVENT_ID','cohorts':['R162','R169'],'needed':'RUN-ID e sequência; também aceito nome de coorte para agregado'}
 if any(x in q for x in ('compare','compar','versus',' vs ',' ou ')):
  mentioned=[key for key in ATTACKS if ((key=='turbilhao' and 'turbilhao' in q) or (key=='presas' and any(x in q for x in ('presas','adaga','golpe fisico','golpe normal'))) or (key=='descarga' and any(x in q for x in ('descarga','cajado'))))]
  if not mentioned and 'feryn' in q:mentioned=['presas','turbilhao']
  if len(mentioned)==1 and mentioned[0]=='turbilhao' and 'feryn' in q:mentioned=['presas','turbilhao']
  if len(mentioned)!=2:raise NeedsSource('Comparação exige duas habilidades identificadas; disponíveis: Presas, Turbilhão e Descarga.')
  tgt=[k for k in PROFILES if ('contra '+k in q or 'alvo '+k in q or 'defensor '+k in q)]
  target=tgt[0] if len(tgt)==1 else None
  if target is None: return {'kind':'PARTIAL_NEEDS_TARGET','abilities':[ATTACKS[k]['name'] for k in mentioned],'missing':'Defensor comum explícito: contra Eristan, Auren ou Feryn, conforme habilidades.'}
  a=compute_attack(mentioned[0],target,**parm);b=compute_attack(mentioned[1],target,**parm)
  return {'kind':'COMPARISON','target':target,'a':a,'b':b,'scope':'TWO_SOURCE_ATTACKS_SAME_DEFENDER; no universal winner','notes':['Críticos omitidos apenas nas consultas que explicitam esse recorte','RD elemental desconhecida permanece TEST','PA de golpe físico padrão não especificado como custo por uso na fonte; não calcular PV/PA para esse ataque']}
 attack=pick_attack(question) or ('turbilhao' if 'feryn' in q else None)
 target=pick_profile(question)
 # If named actor Feryn and no other target: require defender; do not default to Feryn target.
 if not attack:raise NeedsSource('Habilidade não reconhecida. Catálogo autorizado: Turbilhão Cinzento, Presas de Feryn, Descarga de Eristan.')
 if not target or target==ATTACKS[attack]['actor']:
  return {'kind':'PARTIAL_NEEDS_TARGET','source':SRC[ATTACKS[attack]['actor']],'ability':ATTACKS[attack]['name'],'gross_expected':mean(dist(ATTACKS[attack]['damage'])),'cost_PA':ATTACKS[attack]['cost'],'missing':'Defensor documentado: Eristan, Auren ou Feryn quando não for o atacante.'}
 return compute_attack(attack,target,**parm)

def pt_answer(out):
 o=out;k=o.get('kind')
 if k=='EVENT':
  return (f"VLAB {o['cohort']} — RUN {o['run']}, seq {o['seq']}, índice nativo {o['native_action_index']} (seed {o['seed']}).\n"
          f"{o['actor_label']} ({o['actor']}) → {o['target_label']} ({o['target']}); {o['origin']}; ação {o['action']}, habilidade {o['ability']}. Dano registrado {o['raw']}, RD {o['rd']}, pós-RD {o['post']}.\n"
          f"Vida {o['hp_before']} → {o['hp_after']}: {o['hp']} PV realmente retirados; overkill {o['overkill']}. PA atribuído ao evento {o['PA']}.\n"
          f"Salvaguarda/efeito: {o['save'] or 'não descrito nesse campo'}; CD {o['save_CD'] or 'N/A'}, teste {o['save_score'] or 'N/A'}; {o['semantics']}\n"
          f"Fonte SHA-256 do evento: {o['event_hash']}; laboratório, não jogo oficial. Limite: {o['limitations']}.")
 if k in ('COHORT','RUN'):
  return (f"VLAB {o['cohort']} ({o['run_id'] or 'coorte inteira'}): {o['n_events']} recibos, {o['n_runs']} RUN-IDs. "
          f"Dano bruto {o['raw']}, RD {o['rd']}, pós-RD {o['post']}, PV reais {o['hp']}, overkill {o['overkill']}. "
          f"PA atribuível aos eventos {o['PA_allocated_sum']}; não igualar a gasto total de cena. Não são {o['n_events']} ensaios independentes.")
 if k=='ACTION':
  s=(f"{o['attack']} de {o['actor']} contra {o['target']}. Fonte {SRC[o['actor']]}; defensor {SRC[o['target']]}.\n"
     f"Fórmula {o['damage']} ({o['type']}), bruto {o['min']}–{o['max']}, média {fmt(o['gross_expected'])}. "
     f"Ação {o['action']}, custo PA {o['cost_PA'] if o['cost_PA'] is not None else 'NÃO DOCUMENTADO'}, alcance {o['range']}.\n")
  if o['resolve']=='PHYSICAL_VS_CA_NO_CRIT':s+=f"Acerto vs CA documentada: {fmt(o['p_hit']*100)}% condicional sem crítico. Pós-RD por acerto {fmt(o['on_hit_expected'])}; PV úteis esperados/tentativa {fmt(o['expected_per_attempt_pre_or_post_RD'])}.\n"
  else:
   s+=f"Salvaguarda: {o['resolve']}, P(defesa supera) {fmt(o['p_defender_exceeds']*100)}%. Antes de RD esperados {fmt(o['gross_expected'] if o['p_defender_exceeds']==0 else o['gross_expected']*(1-o['p_defender_exceeds']/2))} no modelo racional.\n"
   vals=o['half_bounds'];s+=('Arredondamento metade ímpar não documentado: ' if o['p_defender_exceeds']>0 else 'Defesa falha em todo o suporte: ')+f"cenário FLOOR {fmt(vals['FLOOR_TEST']['hp_effective_expected'])}; CEIL {fmt(vals['CEIL_TEST']['hp_effective_expected'])} de dano condicionado por alvo (PV reais somente com RD e Vida competentes).\n"
  s+=f"RD: {o['rd_note']} "
  if o['rd'] is None:s+='Números de PV útil sob a hipótese auxiliar RD=0 TEST; não representam dano final canônico. '
  if o['hp_input'] is None:s+='Vida atual não fornecida; não afirmar PV efetivos absolutos ou overkill. '
  if o['targets_input'] is None:s+='Número de alvos realmente dentro do alcance não demonstrado. '
  return s
 if k=='COMPARISON':
  a,b=o['a'],o['b'];lines=['Comparação de duas habilidades reais contra '+o['target']+':']
  for i,v in enumerate((a,b),1):
   if v['resolve']=='PHYSICAL_VS_CA_NO_CRIT':summary=f"p(acerto)={fmt(v['p_hit']*100)}%; dano útil esperado/tentativa={fmt(v['expected_per_attempt_pre_or_post_RD'])} (sem crítico)."
   else:summary=f"p(defesa supera)={fmt(v['p_defender_exceeds']*100)}%; dano condicional FLOOR/CEIL={fmt(v['half_bounds']['FLOOR_TEST']['hp_effective_expected'])}/{fmt(v['half_bounds']['CEIL_TEST']['hp_effective_expected'])}."
   lines.append(f"{i}) {v['attack']} ({v['actor']}): bruto {fmt(v['gross_expected'])}; {summary} RD: {v['rd_note']}; PA por uso {v['cost_PA'] if v['cost_PA'] is not None else 'desconhecido'}.")
  lines.append('Conclusão condicional: comparar dano efetivo somente quando RD por tipo e presença do alvo forem competentes; crítico e PA ausentes impedem ranking universal.')
  return '\n'.join(lines)
 return json.dumps(jsonable(o),ensure_ascii=False,indent=2)

if __name__=='__main__':
 parser=argparse.ArgumentParser(description='Consulta natural MESTRE-SIDE — Python stdlib, read-only, no combate VLAB')
 parser.add_argument('question',nargs='+',help='Pergunta em português, entre aspas')
 parser.add_argument('--json',action='store_true')
 args=parser.parse_args()
 try:
  result=ask(' '.join(args.question));print(json.dumps(jsonable(result),ensure_ascii=False,indent=2) if args.json else pt_answer(result))
 except (NeedsSource,ValueError,FileNotFoundError) as ex:
  print('PENDENTE / SEM DADO INVENTADO:',str(ex));raise SystemExit(2)
