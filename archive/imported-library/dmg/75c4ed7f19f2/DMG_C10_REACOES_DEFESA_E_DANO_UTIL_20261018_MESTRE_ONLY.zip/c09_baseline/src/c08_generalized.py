#!/usr/bin/env python3
"""C08 generalized DMG Mestre-side scientific consultation.

Data-driven, NOT a VLAB combat engine and NOT a Notion API client. The Comestre
physically verifies sources in Notion Mestre before authoring a verified registry.
New records enter JSON; mathematical engines C05 and C06 are imported unchanged.
User-supplied formulas and external supplements are TEST / unverified by default.
"""
from __future__ import annotations
import argparse, json, re, unicodedata
from fractions import Fraction as Q
from pathlib import Path
from collections import defaultdict
from experimental_damage_calc import pmf
from c06_damage_resolver import mean, NeedsSource, mode_distribution, component_effect
import c07_conversational as old

ROOT=Path(__file__).resolve().parent.parent
DEFAULT_REGISTRY=ROOT/'data'/'C08_MESTRE_VERIFIED_SOURCES.json'
RXID=re.compile(r'^[0-9a-f]{32}$')
RXURL=re.compile(r'^https://app\.notion\.com/p/([0-9a-f]{32})$')
DAMAGE_LITERAL=re.compile(r'(?<![\w])((?:\d+d\d+)(?:\s*\+\s*(?:\d+d\d+|\d+|[a-z]+))*)\b',re.I)
RD_RX=re.compile(r'\brd\s*(?:(?:de|do|da)\s+)?(fisic[ao]|vento|dark|trevas|raio|gelo|fogo|planta|agua)?\s*(?:[:=]|de)?\s*(\d+)\b',re.I)
HP_RX=re.compile(r'\b(?:vida(?:\s+atual)?|pv(?:\s+atual)?|hp)\s*(?:[:=])?\s*(\d+)\b',re.I)

def norm(s: str) -> str:
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().casefold()
    return re.sub(r'\s+',' ',s).strip()

def ffmt(x) -> str:
    if x is None:return 'INDETERMINADO'
    v=Q(x)
    if v.denominator==1:return str(v.numerator)
    return f'{float(v):.5f}'.rstrip('0').rstrip('.').replace('.',',')

def source_validate(s):
    if not RXID.fullmatch(s.get('uuid','')):raise ValueError('INVALID_UUID_IN_CATALOG')
    m=RXURL.fullmatch(s.get('url',''))
    if not m or m.group(1)!=s['uuid']:raise ValueError('SOURCE_URL_UUID_MISMATCH')
    if not isinstance(s.get('attributes'),dict):raise ValueError('SOURCE_ATTRIBUTES_REQUIRED')
    for key in ('ca','max_hp'):
        if s.get(key) is not None and (type(s[key])!=int or s[key]<0):raise ValueError('INVALID_SOURCE_'+key)

def validate_record(rec,sources):
    if not rec.get('id') or rec.get('source_uuid') not in sources:raise ValueError('EFFECT_WITHOUT_SOURCE')
    if not rec.get('name') or not rec.get('literal_formula'):raise ValueError('EFFECT_NAME_FORMULA_REQUIRED')
    # Syntax/attribute validation BEFORE loading anything as calculable.
    formula=compile_formula(rec['literal_formula'],sources[rec['source_uuid']]['attributes'])
    pmf(formula) # exact support; rejects unsafe, impossible, or non-numeric arithmetic
    if rec.get('damage_channel') not in ('VIDA','ALMA'):raise ValueError('CHANNEL_UNSUPPORTED')

def compile_formula(literal, attrs=None):
    """Preserve literal external wording and resolve ONLY explicitly supplied attributes."""
    expr=norm(literal).replace(' ','')
    attr={'for':'FOR','forca':'FOR','des':'DES','destreza':'DES','int':'INT','inteligencia':'INT'}
    m=re.search(r'\+([a-z]+)$',expr)
    if m:
        k=attr.get(m.group(1))
        if not k:raise NeedsSource('ATRIBUTO_NAO_SUPORTADO_OU_SEM_FONTE: '+m.group(1))
        if attrs is None or attrs.get(k) is None:raise NeedsSource('ATRIBUTO_SEM_VALOR_VERIFICADO: '+k)
        expr=expr[:m.start(1)]+str(attrs[k])
    pmf(expr) # same trusted C05 exact parser
    return expr

class Registry:
    def __init__(self, path:Path=DEFAULT_REGISTRY, supplemental:Path|None=None):
        root=json.loads(Path(path).read_text('utf-8'))
        if root.get('schema')!='DMG-C08-SOURCE-ADMISSION-1':raise ValueError('REGISTRY_SCHEMA_UNSUPPORTED')
        self.sources={};self.effects={};self.origin={}
        for source in root['sources']:
            source_validate(source)
            if source['uuid'] in self.sources:raise ValueError('DUPLICATE_SOURCE_UUID')
            self.sources[source['uuid']]=source
        for rec in root['effects']:
            validate_record(rec,self.sources)
            if rec['id'] in self.effects:raise ValueError('DUPLICATE_EFFECT_ID')
            self.effects[rec['id']]=rec;self.origin[rec['id']]='SOURCE_READ_NOTION_MESTRE_C08'
        if supplemental:
            external=json.loads(Path(supplemental).read_text('utf-8'))
            if set(external)-{'sources','effects'}:raise ValueError('UNEXPECTED_SUPPLEMENT_FIELDS')
            for source in external.get('sources',[]):
                source_validate(source)
                if source['uuid'] in self.sources:raise ValueError('EXTERNAL_REDEFINES_EXISTING_SOURCE')
                # Caller cannot self-promote unverified external input to a verified Notion source.
                s=dict(source);s['source_evidence']='EXTERNAL_DECLARED_NOT_PHYSICALLY_VERIFIED_BY_C08'
                self.sources[s['uuid']]=s
            for rec in external.get('effects',[]):
                validate_record(rec,self.sources)
                if rec['id'] in self.effects:raise ValueError('EXTERNAL_REDEFINES_EXISTING_EFFECT')
                self.effects[rec['id']]=rec;self.origin[rec['id']]='TEST_EXTERNAL_SUPPLEMENT_UNVERIFIED'

    def effect_matches(self,question):
        q=norm(question);matched=[]
        for ident, rec in self.effects.items():
            actor=self.sources[rec['source_uuid']]
            aliases=[rec['name'],*rec.get('aliases',[])]
            # Scoped aliases may be required to prevent common ambiguous single words.
            found=[norm(a) for a in aliases if norm(a) and re.search(r'(?<!\w)'+re.escape(norm(a))+r'(?!\w)',q)]
            if found:matched.append((max(map(len,found)),ident))
        matched.sort(reverse=True)
        return [self.effects[ident] for _,ident in matched]

    def defender_matches(self,text):
        q=norm(text);matches=[]
        for source in self.sources.values():
            if any(re.search(r'(?<!\w)'+re.escape(norm(n))+r'(?!\w)',q) for n in [source['name'],*source.get('aliases',[]) ]):
                matches.append(source)
        return matches


def params(question):
    q=norm(question)
    rd=RD_RX.search(q);hp=HP_RX.search(q)
    rd_type=rd.group(1) if rd else None
    if rd_type and rd_type.startswith('fisic'):rd_type='fisico'
    direct_type=None
    if re.search(r'\b(?:dano|ataque)\s+(?:de\s+tipo\s+)?fisic[oa]\b',q):direct_type='fisico'
    else:
        m=re.search(r'\b(?:dano|ataque)\s+(?:de\s+tipo\s+)?(vento|dark|trevas|raio|gelo|fogo|planta|agua)\b',q)
        if m:direct_type=m.group(1)
    return {'rd':int(rd.group(2)) if rd else None,'rd_type':rd_type,'damage_type_explicit':direct_type,'hp_current':int(hp.group(1)) if hp else None}

def exact_compare(A,B,rd=None):
    da,db=A['dist'],B['dist']
    def adjust(v):return max(0,v-rd) if rd is not None else v
    pg=sum(pa*pb for x,pa in da.items() for y,pb in db.items() if adjust(x)>adjust(y))
    pl=sum(pa*pb for x,pa in da.items() for y,pb in db.items() if adjust(x)<adjust(y))
    pt=Q(1)-pg-pl
    return {'p_A_gt_B':str(pg),'p_B_gt_A':str(pl),'p_tie':str(pt),'assumption':'TEST independent damage rolls; no accuracy, no same-actor independence claim'}

def effect_eval(rec,registry:Registry,question='', *,data_override=None):
    s=registry.sources[rec['source_uuid']];q=params(question);base=compile_formula(rec['literal_formula'],s['attributes'])
    distribution,_=pmf(base);gross=mean(distribution)
    result={'kind':'SOURCE_EFFECT','name':rec['name'],'actor':s['name'],'source_uuid':s['uuid'],'source_url':s['url'],'source_last_edited':s['last_edited'],'evidence':registry.origin[rec['id']],'source_classification':s['classification_body'],'classification_status':s['classification_status'],'literal_formula':rec['literal_formula'],'resolved_formula':base,'gross_min':min(distribution),'gross_max':max(distribution),'gross_mean':str(gross),'damage_channel':rec['damage_channel'],'damage_type':rec['damage_type'],'ca_attacker':s.get('ca'),'cost_PA':rec.get('pa_per_use'),'action':rec.get('action'),'precision':rec.get('offense_roll'),'defense_mode':rec.get('defense_mode'),'continuous_additional':rec.get('extra',[]),'incremental':rec.get('conditional_components',[]),'offense_bonus_specific':rec.get('offense_bonus_specific'),'exact_distribution':{str(k):str(v) for k,v in distribution.items()},'distribution_internal':distribution}
    if rec.get('conditional_components'):
        result['conditional_official_status']='HOLD_TRIGGER_AND_DISTINCTNESS_NOT_VERIFIED'
        question_normalized=norm(question)
        if 'dark' in question_normalized and any(w in question_normalized for w in ('independente','distinto','separado')):
            # Two distinct components under a NEW explicit TEST premise.
            part=rec['conditional_components'][0]
            variant=component_effect(parts=[{'formula':base,'type':'BASE_UNKNOWN'},{'formula':part['literal_formula'],'type':'DARK'}],each_part_activated=True)
            values=[(Q(x['value']),Q(x['num'],x['den'])) for x in variant['distribution']]
            result['conditional_variant_TEST']={'premise':'SOMENTE SE o efeito for Dark, o bônus estiver ativo e o +1d4 não estiver incluído na base; independência entre dados TEST','formula_components':[base,part['literal_formula']],'min':str(min(v for v,_ in values)),'max':str(max(v for v,_ in values)),'expected':str(sum((v*p for v,p in values),Q(0))),'official_status':'NOT_ADJUDICATED_TEST_ONLY'}
    result['p_hit']='INDETERMINATE_OFFENSE_ROLL_OR_DEFENSE_MODE' if not rec.get('offense_roll') else 'UNRESOLVED_SPECIFIC_MECHANIC'
    result['damage_per_attempt']='INDETERMINATE_PRECISION'
    result['pve_per_pa']='INDETERMINATE_PA_COST_OR_PRECISION'
    # Never borrow physical RD from a different damage type. UNKNOWN remains unknown.
    if q['rd'] is not None:
        if not q['rd_type']:result['rd_status']='HOLD_RD_TYPE_UNSTATED'
        elif q['damage_type_explicit'] and q['damage_type_explicit']!=q['rd_type']:
            result['rd_status']='REJECT_RD_TYPE_MISMATCH'
        else:
            conditional=q['damage_type_explicit'] is None or rec['damage_type']!=q['damage_type_explicit']
            result['rd_status']='TEST_CONDITIONAL_ON_MATCHING_DAMAGE_TYPE' if conditional else 'TEST_DECLARED_RD'
            result['rd_hypothesis']='Assume que o dano é '+q['rd_type']+' para este cenário; a fonte não adota automaticamente essa natureza.' if conditional else 'RD introduzida pelo Mestre para TEST; não implica RD canônica.'
            out=mode_distribution(base,damage_type=q['rd_type'],defender_success=Q(0),success_effect='NONE',rd_value=q['rd'],rd_type=q['rd_type'],rd_evidence='TEST',target_hp=q['hp_current'])
            result['post_rd_min']=min(int(v['value']) for v in out['post_RD_exact'])
            result['post_rd_max']=max(int(v['value']) for v in out['post_RD_exact'])
            result['post_rd_mean']=out['post_RD_expected'];result['hp_loss_mean']=out['hp_effective_expected'];result['overkill_mean']=out['overkill_expected'];result['rd_test_value']=q['rd']
    elif q['hp_current'] is not None:
        out=mode_distribution(base,damage_type='UNSPECIFIED',defender_success=Q(0),success_effect='NONE',target_hp=q['hp_current'])
        result['hp_loss_mean_if_hit_and_RD0_TEST']=out['hp_effective_expected'];result['overkill_mean_if_hit_and_RD0_TEST']=out['overkill_expected'];result['rd_status']='MISSING_NO_RD_PROVEN'
    else:result['rd_status']='MISSING_NO_RD_PROVEN'
    result['defender']=None
    if 'contra' in norm(question):
        target_text=norm(question).split('contra',1)[-1]
        defenders=[v for v in registry.defender_matches(target_text) if v['uuid']!=rec['source_uuid']]
        if len(defenders)==1:
            df=defenders[0]
            result['defender']={'name':df['name'],'url':df['url'],'ca':df['ca'],'max_hp':df['max_hp'],'hp_current':'NOT_DOCUMENTED_IN_THIS_QUERY' if q['hp_current'] is None else q['hp_current'],'physical_rd':df['physical_rd'],'elemental_rd':df['elemental_rd']}
            result['p_hit']='INDETERMINATE_ATTACK_ROLL_EVEN_WITH_DOCUMENTED_CA' if df['ca'] is not None and rec.get('offense_roll') is None else result['p_hit']
        elif len(defenders)>1:result['defender_ambiguity']='MORE_THAN_ONE_MATCH'
        else:result['defender_ambiguity']='SOURCE_NOT_LOCATED'
    result['notes']=['Dano condicional à habilidade realmente atingir/ser resolvida.','Não inferir chance de acerto apenas com CA do defensor.','Vida máxima na ficha não é Vida restante.','Efeitos de controle/DoT não receberam números fictícios.']
    return result

def test_formula(question):
    q=params(question);m=DAMAGE_LITERAL.search(norm(question))
    if not m:raise NeedsSource('FÓRMULA TEST não identificada: informar expressão nDm+valor.')
    formula=m.group(1).replace(' ','')
    if re.search(r'[*/^-]',norm(question)[m.end():m.end()+3]):raise ValueError('UNSUPPORTED_FORMULA_OPERATOR')
    matches=list(DAMAGE_LITERAL.finditer(norm(question)))
    if len(matches)>1:raise NeedsSource('MULTIPLE_TEST_FORMULAS_REQUIRE_EXPLICIT_COMPARISON')
    distribution,_=pmf(formula);gross=mean(distribution)
    r={'kind':'TEST_FORMULA','formula':formula,'provenance':'TEST_FÓRMULA_FORNECIDA_PELO_MESTRE_NÃO_CANÔNICA','gross_min':min(distribution),'gross_max':max(distribution),'gross_mean':str(gross),'damage_type':q['damage_type_explicit'] or 'UNSPECIFIED','hp_current_test':q['hp_current'],'rd_declared':q['rd'],'rd_type':q['rd_type'],'per_attempt':'INDETERMINATE_NO_PRECISION','pa':'INDETERMINATE_NO_PA','exact_distribution':{str(k):str(v) for k,v in distribution.items()}}
    if q['rd'] is not None:
        if not q['rd_type']:r['rd_status']='HOLD_RD_TYPE_MISSING';return r
        if q['damage_type_explicit'] is not None and q['damage_type_explicit']!=q['rd_type']:
            r['rd_status']='REJECT_DAMAGETYPE_RD_MISMATCH';return r
        r['rd_status']='TEST_CONDITIONAL_DAMAGE_TYPE_PREMISE' if q['damage_type_explicit'] is None else 'TEST_MATCHING_TYPE_DECLARED'
        r['type_premise']='SE O DANO FOR '+q['rd_type'].upper() if q['damage_type_explicit'] is None else 'TIPO DE DANO TEST EXPLICITAMENTE DECLARADO'
        out=mode_distribution(formula,damage_type=q['rd_type'],defender_success=Q(0),success_effect='NONE',rd_value=q['rd'],rd_type=q['rd_type'],rd_evidence='TEST',target_hp=q['hp_current'])
        r.update({'post_rd_min':min(int(v['value']) for v in out['post_RD_exact']),'post_rd_max':max(int(v['value']) for v in out['post_RD_exact']),'post_rd_mean':out['post_RD_expected'],'hp_loss_mean':out['hp_effective_expected'],'overkill_mean':out['overkill_expected']})
    elif q['hp_current'] is not None:
        r['rd_status']='MISSING_RD';r['post_RD']='INDETERMINATE_RD'
    return r

def registered_comparison(effects,registry,q):
    if len(effects)!=2:raise NeedsSource('COMPARAÇÃO AMBÍGUA: citar exatamente dois nomes de habilidades.')
    A=effect_eval(effects[0],registry,q);B=effect_eval(effects[1],registry,q)
    a={'dist':{int(k):Q(v) for k,v in A['exact_distribution'].items()}}
    b={'dist':{int(k):Q(v) for k,v in B['exact_distribution'].items()}}
    pa=params(q)
    rd=pa['rd'] if pa['rd'] is not None and pa['rd_type'] and pa['damage_type_explicit']==pa['rd_type'] else None
    out={'kind':'SOURCE_COMPARISON','a':A,'b':B,'delta_gross_mean_B_minus_A':str(Q(B['gross_mean'])-Q(A['gross_mean'])),'independent_dice_test':exact_compare(a,b,rd=rd),'scope':'SELECTED_SOURCE_FORMULAS_CONDITIONAL_HIT_NO_PRECISION_NO_COMBAT_WINNER'}
    if rd is not None:
        out['shared_RD_TEST']=rd
        out['post_rd_delta_mean_B_minus_A_TEST']=str(Q(B['post_rd_mean'])-Q(A['post_rd_mean']))
    if any(x['classification_status'].startswith('CONFLICT') for x in (A,B)):out['rank_restriction']='AT_LEAST_ONE_SOURCE_HAS_RANK_CONFLICT'
    return out

def ask(question, registry:Registry|None=None):
    reg=registry or Registry()
    q=norm(question)
    # Preserve C07 event parser and native receipt semantics; add generic RUN-token filtering.
    if re.search(r'\b(?:vlab|r1\d{2}(?:_|\b))',q):
        ev_match=re.search(r'\b(r\d{3})(?:[_\s-]+([a-z]+))?',q)
        exact_run=re.search(r'\bR\d{3}_[A-Za-z0-9_]+\b',question,re.I)
        seq_match=re.search(r'(?:seq(?:uencia)?|sequencia|evento|commit)\s*(?:=|:|#)?\s*(\d+)\b',q)
        if ev_match and seq_match:
            candidates=[]
            phase=ev_match.group(1).upper();policy=ev_match.group(2)
            for co in ('R162','R169'):
                for r in old.run_load(co):
                    if not r['run_id'].upper().startswith(phase+'_'):continue
                    if exact_run and r['run_id'].casefold()!=exact_run.group(0).casefold():continue
                    if not exact_run and policy and policy not in ('basic','wind') and policy not in norm(r['run_id']):continue
                    if not exact_run and policy in ('basic','wind') and ('_'+policy.upper()+'_') not in r['run_id'].upper():continue
                    if int(r['seq_R18'])!=int(seq_match.group(1)):continue
                    candidates.append((co,r))
            if len(candidates)==1:
                cohort,r=candidates[0]
                return old.event_query(cohort,run_id=r['run_id'],seq=int(seq_match.group(1)),action_index=int(r['action_index_in_tx'] if cohort=='R162' else r['native_action_in_commit']))
            if len(candidates)>1:return {'kind':'AMBIGUOUS_NATIVE_EVENT','matches':[{'cohort':co,'run':r['run_id'],'seq':r['seq_R18'],'index':r['action_index_in_tx'] if co=='R162' else r['native_action_in_commit']} for co,r in candidates], 'message':'Informar índice nativo para desambiguar ações no mesmo commit.'}
        return old.ask(question)
    matches=reg.effect_matches(question)
    comparison=any(s in q for s in ('compare','comparar','comparacao',' versus ',' vs '))
    if comparison and len(matches)==2:
        return registered_comparison(matches,reg,question)
    if comparison and len(matches)==1:
        # Join new registry with C07 legacy by generic data conversion, no new named computation.
        legacy_keys=[key for key in old.ATTACKS if (key=='turbilhao' and 'turbilhao' in q) or (key=='presas' and 'presas' in q) or (key=='descarga' and 'descarga' in q)]
        if len(legacy_keys)==1:
            A=effect_eval(matches[0],reg,question);Brec=old.ATTACKS[legacy_keys[0]];bd,_=pmf(Brec['damage']);
            B={'kind':'C07_SOURCE_EFFECT','name':Brec['name'],'actor':Brec['actor'],'source_url':old.SRC[Brec['actor']],'literal_formula':Brec['damage'],'gross_min':min(bd),'gross_max':max(bd),'gross_mean':str(mean(bd)),'cost_PA':Brec['cost'],'damage_type':Brec['type'],'defense_mode':Brec['resolve'],'exact_distribution':{str(k):str(v) for k,v in bd.items()}}
            return {'kind':'CROSS_C07_COMPARISON','a':A,'b':B,'delta_gross_mean_B_minus_A':str(Q(B['gross_mean'])-Q(A['gross_mean'])),'scope':'RAW_DISTRIBUTIONS_ONLY; different ranks/defense/cost; no universal winner'}
    if matches and not comparison:
        if len(matches)>1:
            return {'kind':'AMBIGUOUS_EFFECT','candidates':[{'effect':v['name'],'source':reg.sources[v['source_uuid']]['url']} for v in matches], 'message':'Especificar habilidade ou criatura para selecionar exatamente um efeito.'}
        return effect_eval(matches[0],reg,question)
    # A documented creature with one eligible numeric attack can be queried without
    # naming that attack; several attacks REQUIRE selection, not a silent default.
    if not matches and not comparison:
        actors=reg.defender_matches(question)
        direct=re.search(r'https://app\.notion\.com/p/([0-9a-f]{32})',question,re.I)
        if direct and direct.group(1) in reg.sources:
            actors=[reg.sources[direct.group(1)]]
        if len(actors)==1:
            options=[r for r in reg.effects.values() if r['source_uuid']==actors[0]['uuid']]
            if len(options)==1:return effect_eval(options[0],reg,question)
            if len(options)>1:return {'kind':'MULTIPLE_SOURCE_EFFECTS','actor':actors[0]['name'],'url':actors[0]['url'],'options':[r['name'] for r in options],'message':'Especificar habilidade; não escolho uma das várias ações automaticamente.'}
    if DAMAGE_LITERAL.search(q) and any(w in q for w in ('calcule','formula','formula:','test','cenario','rd','vida')):
        return test_formula(question)
    if not comparison:
        # Preserve legacy Feryn/Eristan/Auren consultations
        return old.ask(question)
    raise NeedsSource('HABILIDADES_NÃO_IDENTIFICADAS; informe nomes e/ou fórmula TEST e fonte.')


def answer_pt(o):
    if o['kind'] in ('EVENT','COHORT','RUN','ACTION','COMPARISON'):return old.pt_answer(o)
    kind=o['kind']
    if kind=='SOURCE_EFFECT':
        text=f"{o['name']} — {o['actor']}. Fonte {o['source_url']} (edição {o['source_last_edited']}; {o['evidence']}).\n"
        text+=f"Fórmula literal {o['literal_formula']} = {o['resolved_formula']}; canal {o['damage_channel']}; bruto {o['gross_min']}–{o['gross_max']}; média exata {ffmt(o['gross_mean'])}, condicionado ao efeito ocorrer.\n"
        if o['defender']:
            df=o['defender'];text+=f"Defensor {df['name']}, CA {df['ca']}, Vida máxima de ficha {df['max_hp']}; Vida atual não presumida.\n"
        text+=f"Dano por tentativa: {o['damage_per_attempt']}; PA por uso: {o['cost_PA'] if o['cost_PA'] is not None else 'NÃO DOCUMENTADO'}; tipo exato: {o['damage_type']}; classificação: {o['classification_status']}.\n"
        if o.get('rd_status')=='TEST_CONDITIONAL_ON_MATCHING_DAMAGE_TYPE' or o.get('rd_status')=='TEST_DECLARED_RD':text+=f"TEST RD {o['rd_test_value']}: {o['rd_hypothesis']} Pós-RD {o['post_rd_min']}–{o['post_rd_max']}, média {ffmt(o['post_rd_mean'])}; PV condicionais {ffmt(o['hp_loss_mean'])}; overkill {ffmt(o['overkill_mean'])}.\n"
        if o['rd_status']=='MISSING_NO_RD_PROVEN':text+='RD compatível ausente: não afirmar PV finais, probabilidade de acerto nem eficiência por tentativa.\n'
        if o.get('conditional_variant_TEST'):
            v=o['conditional_variant_TEST'];text+=f"Variante TEST separada (+componente Dark independente, NÃO oficial): {v['min']}–{v['max']}, média {ffmt(v['expected'])}.\n"
        text+='Efeitos extras não quantificados: '+'; '.join(o['continuous_additional'])
        return text
    if kind=='TEST_FORMULA':
        text=f"TEST — fórmula declarada {o['formula']}; bruto {o['gross_min']}–{o['gross_max']}; média {ffmt(o['gross_mean'])}. Não é uma habilidade canônica por si só.\n"
        if 'post_rd_mean' in o:text+=f"{o['type_premise']}: RD {o['rd_declared']} ({o['rd_type']}); pós-RD {o['post_rd_min']}–{o['post_rd_max']} e média {ffmt(o['post_rd_mean'])}; PV condicionais {ffmt(o['hp_loss_mean'])}, overkill {ffmt(o['overkill_mean'])} com Vida {o['hp_current_test'] if o['hp_current_test'] is not None else 'não informada'}.\n"
        else:text+='RD/tipo não admissíveis para calcular dano pós-mitigação conclusivo.\n'
        return text+'Dano por tentativa e PV/PA INDETERMINADOS até conhecer acerto e custo. O cálculo assume acerto/efeito ocorrido.'
    if kind=='MULTIPLE_SOURCE_EFFECTS':
        return 'A fonte '+o['actor']+' possui várias ações: '+', '.join(o['options'])+'. Informe a habilidade desejada; não escolherei arbitrariamente. Fonte '+o['url']
    if kind=='SOURCE_COMPARISON':
        A,B=o['a'],o['b'];pr=o['independent_dice_test']
        rd_extra=(f" Cenário TEST de dano físico com RD {o['shared_RD_TEST']} para ambos: médias pós-RD {ffmt(A['post_rd_mean'])} e {ffmt(B['post_rd_mean'])}; diferença segunda−primeira {ffmt(o['post_rd_delta_mean_B_minus_A_TEST'])}." if 'shared_RD_TEST' in o else '')
        return (f"Comparação TEST de fórmulas documentadas (não combate): {A['name']} {A['resolved_formula']} ({ffmt(A['gross_mean'])} bruto médio, {A['gross_min']}–{A['gross_max']}) vs {B['name']} {B['resolved_formula']} ({ffmt(B['gross_mean'])} bruto médio, {B['gross_min']}–{B['gross_max']}).\n"+f"Diferença segunda−primeira {ffmt(o['delta_gross_mean_B_minus_A'])}; P(primeira>segunda)={ffmt(Q(pr['p_A_gt_B'])*100)}%, P(segunda>primeira)={ffmt(Q(pr['p_B_gt_A'])*100)}%, empate {ffmt(Q(pr['p_tie'])*100)}%, assumindo dados independentes.\nPrecisão, defesa competente, PA e RD fonte-válida faltantes impedem declarar vencedora em combate."+rd_extra)
    if kind=='CROSS_C07_COMPARISON':
        A,B=o['a'],o['b'];return f"Comparação mista C08 × C07: {A['name']} média {ffmt(A['gross_mean'])} vs {B['name']} média {ffmt(B['gross_mean'])}; tipos, patamares e resolução são diferentes. Sem defensor e parâmetros comparáveis, NÃO definir superioridade tática."
    return json.dumps({k:v for k,v in o.items() if k!='distribution_internal'},ensure_ascii=False,indent=2)


def json_safe(o):
    if isinstance(o,Q):return str(o)
    if isinstance(o,dict):return {k:json_safe(v) for k,v in o.items() if k!='distribution_internal'}
    if isinstance(o,list):return [json_safe(v) for v in o]
    return o

if __name__=='__main__':
    p=argparse.ArgumentParser(description='DMG C08 consultor generalizável — MESTRE-SIDE, não VLAB, sem internet automática')
    p.add_argument('question',nargs='+');p.add_argument('--catalog',type=Path,default=DEFAULT_REGISTRY);p.add_argument('--supplement',type=Path,help='Novos registros declarados ainda NÃO VERIFICADOS (TEST)');p.add_argument('--json',action='store_true');a=p.parse_args()
    try:
        reg=Registry(a.catalog,a.supplement);result=ask(' '.join(a.question),reg)
        print(json.dumps(json_safe(result),ensure_ascii=False,indent=2) if a.json else answer_pt(result))
    except (ValueError,NeedsSource,FileNotFoundError) as e:
        print('PENDENTE / NÃO INVENTAR:',str(e));raise SystemExit(2)
