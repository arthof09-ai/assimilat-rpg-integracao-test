#!/usr/bin/env python3
"""C06 additive exact damage resolver for Mestre-side analysis (not a combat engine).
No dice RNG execution. Only reads source-identified formulas and conditional scenarios.
Technical interpretations requiring a rule absent from sources are explicitly flagged.
"""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction as Q
from itertools import product
from typing import Optional
import json
from experimental_damage_calc import pmf

class NeedsSource(ValueError): pass


def dist(expr: str, attrs: Optional[dict]=None):
    return pmf(expr,attrs or {})[0]


def mean(p): return sum((Q(k)*v for k,v in p.items()),Q(0))
def pack(p):
    return [{'value':str(k),'num':v.numerator,'den':v.denominator} for k,v in sorted(p.items())]
def total_prob(p):return sum(p.values(),Q(0))

def compare_rolls(attacker_formula:str,defender_formula:str,*,attacker_attrs=None,defender_attrs=None,win_rule='STRICT_GREATER'):
    """General opposed roll. For Feryn spell, defender wins ONLY on strictly greater roll.
    Results are probabilities over independent dice; no runtime RNG or initiative.
    """
    if win_rule != 'STRICT_GREATER': raise NeedsSource('UNSUPPORTED_WIN_RULE')
    a=dist(attacker_formula,attacker_attrs);b=dist(defender_formula,defender_attrs)
    gt=sum((ap*bp for av,ap in a.items() for bv,bp in b.items() if bv>av),Q(0))
    eq=sum((ap*bp for av,ap in a.items() for bv,bp in b.items() if bv==av),Q(0))
    return {'defender_strict_success':gt,'tie':eq,'defender_not_greater':Q(1)-gt,'attack_support':[min(a),max(a)],'defense_support':[min(b),max(b)],'attacker_distribution':a,'defender_distribution':b}

def _half(x, policy:str):
    if policy=='RATIONAL_TEST': return Q(x,2)
    if policy=='FLOOR_TEST':return Q(x//2)
    if policy=='CEIL_TEST':return Q((x+1)//2)
    raise NeedsSource('ODD_HALF_ROUNDING_POLICY_UNRESOLVED')

def mode_distribution(damage_formula, *, damage_attrs=None, defender_success=Q(0), success_effect='HALF', half_rounding='UNRESOLVED',damage_type='UNKNOWN',rd_value=None,rd_type=None,rd_evidence=None,target_hp=None,pa_cost=None,pa_available=None,crit_policy='NONE',target_count=None):
    """Resolve a single target marginal exact PMF and optional documented type-specific RD.
    Target count n outputs expected sum only; target dependencies remain UNKNOWN.
    """
    if crit_policy!='NONE':raise NeedsSource('CRITICAL_SOURCE_POLICY_REQUIRED; NEVER_INVENT_CRIT')
    d=dist(damage_formula,damage_attrs)
    if not isinstance(defender_success,Q):defender_success=Q(str(defender_success))
    if not 0<=defender_success<=1:raise ValueError('DEFENSE_PROBABILITY_OUTSIDE_UNIT_INTERVAL')
    if success_effect not in ('HALF','ZERO','NONE'):raise NeedsSource('SUCCESS_EFFECT_NOT_DOCUMENTED')
    if success_effect=='HALF' and defender_success>0 and half_rounding=='UNRESOLVED':
        return {'status':'PARTIAL_HALF_ROUNDING_UNKNOWN','gross_exact':pack(d),'gross_mean':str(mean(d)),'defender_success':str(defender_success),'half_exact_rational_expectation':str(mean(d)*(Q(1)-defender_success/2)),'possible_rounding':['RATIONAL_TEST','FLOOR_TEST','CEIL_TEST'],'damage_type':damage_type,'RD':'MISSING' if rd_value is None else 'REQUIRES_ROUNDING_BEFORE_RD_TO_RESOLVE'}
    if rd_value is not None:
        if not isinstance(rd_value,int) or rd_value<0:raise ValueError('INVALID_RD')
        if rd_type!=damage_type:raise NeedsSource('RD_TYPE_MISMATCH: '+str(rd_type)+' NOT '+str(damage_type))
        if rd_evidence not in ('DOCUMENTED','TEST'):raise NeedsSource('RD_PROVENANCE_REQUIRED_DOCUMENTED_OR_TEST')
    if target_hp is not None and (not isinstance(target_hp,int) or target_hp<0):raise ValueError('INVALID_TARGET_HP')
    if pa_cost is not None and (not isinstance(pa_cost,int) or pa_cost<=0):raise ValueError('INVALID_PA_COST')
    if pa_available is not None:
        if pa_cost is None:raise NeedsSource('PA_COST_REQUIRED_TO_CHECK_AFFORDABILITY')
        if not isinstance(pa_available,int) or pa_available<0:raise ValueError('INVALID_PA_AVAILABLE')
        if pa_available<pa_cost:return {'status':'NOT_EXECUTABLE_INSUFFICIENT_FREE_PA','pa_required':pa_cost,'pa_available':pa_available,'no_attack_or_damage_inferred':True}
    if target_count is not None and (not isinstance(target_count,int) or target_count<1):raise ValueError('INVALID_TARGET_COUNT')
    # Represent paths separately so overkill and RD decomposition are exact.
    paths=[]; net=defaultdict(Q); hp=defaultdict(Q); raw=mean(d); mitigated=Q(0);wasted=Q(0)
    for val,pr in d.items():
        outcomes=[('DEFENSE_NOT_GREATER',Q(1)-defender_success,Q(val))]
        if defender_success:
            succ = Q(val) if success_effect=='NONE' else Q(0) if success_effect=='ZERO' else _half(val,half_rounding)
            outcomes.append(('DEFENSE_GREATER',defender_success,succ))
        for label,p,pre_rd in outcomes:
            if not p:continue
            prob=p*pr
            after=max(Q(0),pre_rd-Q(rd_value or 0));loss=after if target_hp is None else min(after,Q(target_hp));ov=after-loss
            mitigated+=(pre_rd-after)*prob;wasted+=ov*prob;net[after]+=prob;hp[loss]+=prob
    expected=mean(net);hpex=mean(hp)
    return {'status':'EXACT_TEST_OR_DOCUMENTED_AS_SCOPED','damage_type':damage_type,'gross_formula':damage_formula,'gross_expected':str(raw),'gross_min':min(d),'gross_max':max(d),'defender_success_probability':str(defender_success),'success_effect':success_effect,'half_rounding':half_rounding,'RD':rd_value if rd_value is not None else 'MISSING','RD_evidence':rd_evidence or 'NOT_PROVIDED','pre_RD_expected':str(raw*(Q(1)-defender_success/2) if success_effect=='HALF' else raw*(Q(1)-defender_success) if success_effect=='ZERO' else raw),'post_RD_expected':str(expected),'damage_prevented_by_RD_expected':str(mitigated),'hp_effective_expected':str(hpex),'overkill_expected':str(wasted),'post_RD_exact':pack(net),'hp_effective_exact':pack(hp),'pa_cost':pa_cost if pa_cost is not None else 'MISSING','expected_hp_per_PA':str(hpex/Q(pa_cost)) if pa_cost else 'INDETERMINATE_MISSING_PA','target_count':target_count,'total_expected_HP_if_each_target_eligible':str(hpex*target_count) if target_count else 'INDETERMINATE_TARGET_NUMBER','multi_target_independence':'NOT_ASSUMED; aggregate mean uses expectation linearity only'}

def evaluate_spell(*, attacker_formula,defender_formula,damage_formula,damage_type,cost,action,source_refs,rd=None,rd_evidence=None,rd_type=None,half_rounding='UNRESOLVED',target_hp=None,target_count=None,pa_available=None):
    if not source_refs or len(source_refs)<2:raise NeedsSource('ATTACKER_AND_DEFENDER_SOURCE_REQUIRED')
    if cost is None or action is None:raise NeedsSource('SPELL_ACTION_AND_COST_REQUIRED')
    opposed=compare_rolls(attacker_formula,defender_formula)
    damage=mode_distribution(damage_formula,defender_success=opposed['defender_strict_success'],success_effect='HALF',half_rounding=half_rounding,damage_type=damage_type,rd_value=rd,rd_type=rd_type,rd_evidence=rd_evidence,target_hp=target_hp,pa_cost=cost,pa_available=pa_available,target_count=target_count)
    return {'mode':'SPELL_SPECIFIC_SAVE_NOT_PHYSICAL_HIT','source_refs':source_refs,'attacker_roll':attacker_formula,'defender_roll':defender_formula,'opposed':{k:(str(v) if isinstance(v,Q) else v) for k,v in opposed.items() if not k.endswith('_distribution')},'damage':damage,'action':action,'pa_cost_single_cast':cost,'no_critical':True,'resolution':'DEFENDER_GREATER_RECEIVES_HALF; EQUAL_RECEIVES_FULL'}

def evaluate_physical(*,attacker_roll,defender_ca,damage_formula,damage_type,source_refs,rd=None,rd_type=None,rd_evidence=None,target_hp=None,pa_cost=None):
    if defender_ca is None:raise NeedsSource('TARGET_CA_MISSING')
    if not isinstance(defender_ca,int) or defender_ca<0:raise ValueError('INVALID_CA')
    attack=dist(attacker_roll);p_hit=sum((v for x,v in attack.items() if x>defender_ca),Q(0))
    hit=mode_distribution(damage_formula,defender_success=Q(0),success_effect='NONE',damage_type=damage_type,rd_value=rd,rd_type=rd_type,rd_evidence=rd_evidence,target_hp=target_hp,pa_cost=pa_cost)
    return {'mode':'PHYSICAL_ATTACK_VS_CA','p_hit':str(p_hit),'hit_tie_defense':True,'hit_conditional':hit,'hp_per_attempt':str(p_hit*Q(hit['hp_effective_expected'])),'source_refs':source_refs,'critical':'EXCLUDED_UNLESS_CRITICAL_RULE_AND_ROLL_SOURCE_PROVIDED'}

def dot_effect(*,potency_formula=None,duration_ticks=None,trigger=None,roll_policy=None,channel='HP',damage_type=None):
    if potency_formula is None or duration_ticks is None or trigger is None:
        return {'status':'INDETERMINATE_DOT_POWER_OR_DURATION_OR_TRIGGER','missing':[name for name,val in [('potency_formula',potency_formula),('duration_ticks',duration_ticks),('trigger',trigger)] if val is None],'must_not_infer_damage':True}
    if roll_policy not in ('INDEPENDENT_EACH_TICK','SINGLE_ROLL_REUSED'):
        return {'status':'INDETERMINATE_DOT_ROLL_POLICY','conditional_modes':['INDEPENDENT_EACH_TICK','SINGLE_ROLL_REUSED']}
    if not isinstance(duration_ticks,int) or duration_ticks<1:raise ValueError('INVALID_DURATION')
    d=dist(potency_formula)
    if roll_policy=='SINGLE_ROLL_REUSED':out={k*duration_ticks:v for k,v in d.items()}
    else:
        curr={0:Q(1)}
        for _ in range(duration_ticks):
            nxt=defaultdict(Q)
            for k,v in curr.items():
                for a,p in d.items():nxt[k+a]+=v*p
            curr=nxt
        out=curr
    return {'status':'EXACT_CONDITIONAL_DOT','channel':channel,'damage_type':damage_type or 'UNKNOWN','trigger':trigger,'ticks':duration_ticks,'roll_policy':roll_policy,'expected_total':str(mean(out)),'distribution':pack(out)}

def component_effect(*,parts,each_part_activated,rd_mapping=None):
    """Components are summed only with explicit joint activation. RD per type requires caller proof."""
    if each_part_activated is not True:return {'status':'INDETERMINATE_COMPONENT_ACTIVATION','no_automatic_stacking':True}
    if any(not p.get('formula') or not p.get('type') for p in parts):raise NeedsSource('COMPONENT_SOURCE_FORMULA_AND_TYPE_REQUIRED')
    if rd_mapping is not None:
        if any(p['type'] not in rd_mapping for p in parts):return {'status':'INDETERMINATE_RD_FOR_COMPONENT_TYPE','missing_types':sorted(set(p['type'] for p in parts)-set(rd_mapping))}
    d={0:Q(1)}
    for p in parts:
        nxt=defaultdict(Q);pm=dist(p['formula'],p.get('attrs'))
        for base,p0 in d.items():
            for damage,p1 in pm.items():nxt[base+(max(0,damage-rd_mapping[p['type']]) if rd_mapping else damage)]+=p0*p1
        d=nxt
    return {'status':'EXACT_CONDITIONAL_COMPONENTS','expected':str(mean(d)),'distribution':pack(d),'independence_assumption':'DICE_COMPONENTS_INDEPENDENT_TEST','RD_status':'SOURCE_REQUIRED' if rd_mapping else 'NOT_APPLIED'}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description='Scientific damage inquiry (no VLAB combat)')
    p.add_argument('--attacker',default='4d6+92');p.add_argument('--defender',default='4d6+28');p.add_argument('--damage',default='9d10+8');p.add_argument('--damage-type',default='vento');p.add_argument('--pa',type=int,default=60)
    p.add_argument('--defender-source',help='Notion URL proving the declared Reflexo, REQUIRED for custom defender');p.add_argument('--rd',type=int);p.add_argument('--rd-type');p.add_argument('--rd-provenance',choices=['DOCUMENTED','TEST']);p.add_argument('--half-rounding',choices=['UNRESOLVED','RATIONAL_TEST','FLOOR_TEST','CEIL_TEST'],default='UNRESOLVED');p.add_argument('--target-hp',type=int);p.add_argument('--target-count',type=int)
    a=p.parse_args()
    known={'4d6+28':'https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76','6d6+166':'https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02'}
    defender_source=a.defender_source or known.get(a.defender)
    if not defender_source or not defender_source.startswith('https://app.notion.com/p/'):
        parser.error('DEFENDER_SOURCE_REQUIRED: pass --defender-source https://app.notion.com/p/<uuid>')
    x=evaluate_spell(attacker_formula=a.attacker,defender_formula=a.defender,damage_formula=a.damage,damage_type=a.damage_type,cost=a.pa,action='PADRAO',source_refs=['https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31',defender_source],rd=a.rd,rd_type=a.rd_type,rd_evidence=a.rd_provenance,half_rounding=a.half_rounding,target_hp=a.target_hp,target_count=a.target_count)
    print(json.dumps(x,ensure_ascii=False,indent=2))
