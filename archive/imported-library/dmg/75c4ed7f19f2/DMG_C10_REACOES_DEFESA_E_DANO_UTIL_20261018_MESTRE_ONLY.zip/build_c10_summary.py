from __future__ import annotations
import csv,json,hashlib
from pathlib import Path
import c10_reaction_analyst as c10
ROOT=Path(__file__).resolve().parent
scenes=[('Varok','Sikong Feryn','normal'),('Varok','Sikong Feryn','defender'),('Varok','Sikong Feryn','esquivar'),('Varok','Sikong Feryn','capa'),('Varok','Sikong Feryn','selo'),('Arveth','Sikong Eristan','normal'),('Arveth','Sikong Eristan','defender'),('Arveth','Sikong Eristan','esquivar'),('Arveth','Sikong Eristan','casulo')]
rows=[]
for a,d,o in scenes:
    r=c10.defend(a,d,option=o,hp_current=40)
    rows.append({k:r[k] for k in ('attacker','defender','defense_option','normal_CA','effective_CA','p_attack_over_normal_CA','p_hit','p_physical_contact_defended','physical_rd_documented','expected_damage_per_attempt_pre_hp','expected_hp_removed_per_attempt','expected_overkill_per_attempt','expected_damage_avoided_per_attempt_relative_to_normal','CA_extra_needed_from_normal_to_force_zero','gate_status','reaction_cost_PA_if_used','precast_standard_action_cost_PA_if_cast')})
out=ROOT/'C10_SCIENCE_MATRIX_SOURCE_SCOPED.csv'
with out.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,rows[0]);w.writeheader();w.writerows(rows)
print(out,len(rows))
