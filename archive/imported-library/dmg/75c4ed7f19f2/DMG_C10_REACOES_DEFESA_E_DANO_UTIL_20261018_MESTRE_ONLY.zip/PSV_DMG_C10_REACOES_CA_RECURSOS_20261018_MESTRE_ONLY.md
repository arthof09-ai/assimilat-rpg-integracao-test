# PSV — DMG C10 / Reações, defesa preparada e dano útil

**AS-OF:** 18/10/2026 (America/Recife)  
**OPERATION:** `OP-DMG-CORPUS-EMP-01` · **AMBIENTE:** `MESTRE-SIDE`  
**BASELINE:** `DMG-RANK-01 v1.1` oficial, **inalterada**  
**F0:** **4/8** · **Produção:** HOLD · **Estado:** TEST local, nenhuma homologação/nova regra  
**LAST-VERIFIED-UNIT:** C10 teste de 50 casos + oráculo independente 41 verificações + 12 consultas naturais + regressão C09 40/40, auditoria independente C09 29/29; pacote e readback exigidos e registrados em recibo separado após publicação.

## Ponto de retomada exato

A última entrega C09, ZIP `DMG_C09_EFETIVO_POR_TENTATIVA_20261017_MESTRE_ONLY.zip`, SHA-256 `00aa09b0e8cb7364ecfa58a61c4a6f729a1188d5e600356bbc869f7fe4fd8735`, foi fisicamente recuperada. Todos os 19 membros e scripts originais foram mantidos dentro de `c09_baseline/` sem alteração. **Não** reabrimos A6/R160/R162/R169 nem reexecutamos combate VLAB.

## ANTES → DEPOIS

| Capacidade | C09 antes | C10 depois |
|---|---|---|
| Ataque versus CA | Precisão exata contra CA normal | Precisão exata após reação e atributos defensivos competentes |
| Desvantagem | Não modelada genericamente no consultor | Distribuição exata do pior de duas rolagens de ataque, penalidade −2 por nível |
| Defender versus CA | Não comparados numa mesma consulta | CA como piso, reação bloqueia dano sem causar inversão espúria |
| Esquivar | Não explicitado em comparação | Valor absoluto documentado e consumo de Reação, sem custo PA inventado |
| Proteção prévia | Ausente | Casulo +22 CA condicionada a aplicação já ativa, alvo aliado elegível, dois turnos |
| Vida corrente | C09 já sabia limitar PV | C10 preserva PV e overkill sob probabilidade alterada pela defesa |
| Recursos | PA de ataque/ativação C09 | PA de Reação e conjuração anterior separados do vínculo diário |
| Interface | Perguntas C09 sem reação | Perguntas em português reconhecendo opções por nome, com fallback C09 |
| Regra | DMG-RANK v1.1 | **Idêntica, não modificada** |

## Evidência documental de fontes fisicamente abertas

- `Varok` e `Arveth` (Notion Mestre, versões 16/10/2026): fórmulas de ataque/dano C09 **reusadas**, sem reinscrição de FF nem ataques extras. URLs originais, UUIDs e parâmetros em `C09_VERIFIED_PATCH.json`.
- `Feryn`: `https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31` (edit 2026-10-16T10:33:13.379Z), CA123, Defender56, Esquivar125, RD física22, 1 reação/rodada, Capa de Poeira reação35 PA Desvantagem1, Selo do Retorno Obscuro reação40 PA uma vez/cena, não acumulados nesta análise.
- `Eristan`: `https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76` (edit 2026-10-16T10:33:32.392Z), CA76, Defender85, Esquivar76, RD física25, Casulo de Brotos ação Padrão60 PA, aliado até15m, 2 turnos, +22 CA, −4m deslocamento, sem acúmulo do mesmo conjurador.
- `Sistema de Combate`: `https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0` (edit 2026-10-07T23:51:04.971Z), ataque deve superar defesa, Desvantagem1 = pior de duas rolagens completas menos2; Defender neutraliza dano de golpe que não supere seu valor.
- `DMG-RANK-01 v1.1`: `https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e`; permanecem distintos magnitude e tipo/tags, e sem política nova de RD por componente.

## Ciência demonstrada (todos cenários TEST, sem crítico, sem circunstâncias ou compromissos de reação reais)

### Varok × Feryn

- `4d6+100` vs CA 123: só `4d6=24` vence; **P(acerto)=1/1296**. `10d10+48` tem média103, RD físico22, dano pós-RD em acerto médio81; **dano médio por tentativa=81/1296=1/16=0,0625**.
- Capa de Poeira, se Reação disponível e PA atual ≥35: Desvantagem1, teste máximo `4d6+100−2=122`, **P=0** e dano esperado0; **35 PA ativados antes do resultado do ataque**. Sem PA suficiente a opção fica BLOCKED e o cálculo é apenas contrafactual.
- Selo do Retorno Obscuro dá efeito equivalente, custa40 PA, necessita Reação livre e uso por cena disponível. **Não se acumulam** opções na mesma rodada.
- Esquivar 125: P=0, necessita Reação livre; **não atribuir custo zero de PA se custo não documentado**.
- Defender 56: NÃO reduz defesa efetiva abaixo da CA123. P de dano permanece 1/1296, não 100%. Esta é uma correção científica importante contra modelagem ingênua de substituição de CA.
- CA adicional mínimo para eliminar chance de dano do ataque normal: **+1**, pois empate favorece defesa (CA124 impede máximo ataque124).
- Se Vida corrente TEST=40: expectativa de Vida perdida `11111111101/360000000000≈0,0308642`, overkill `11388888899/360000000000≈0,0316358`. O ganho de defesa de Capa é apenas **1/16 PV por tentativa em média** para esse ataque particular, não demonstra superioridade tática universal de gastar35 PA.

### Arveth × Eristan

- Ataque `4d6+72` vs CA76: **P=1295/1296** (a rolagem `1+1+1+1` empata e falha). Golpe físico `8d10+35` tem média79; RD física25; após RD média54; dano esperado/tentativa **1295/24≈53,9583**.
- Defender85, se reação: atacante precisa `4d6≥14`. **P de dano=721/1296≈55,633%**, expectativa **721/24≈30,0417**. Em **574/1296** rolagens o ataque supera a CA normal, mas não supera o valor Defender, logo não produz dano por essa ação defensiva.
- Casulo de Brotos previamente ativo: CA98, acima do máximo ataque96, então P=0; exige um alvo aliado elegível, ação Padrão anterior, custo de60PA pelo **conjurador**, duração ainda vigente, sem autoalvo presumido. Não é uma reação imediata.
- CA adicional mínimo para forçar P=0 neste atacante: **+20** (de CA76 até CA96); Casulo dá +22. Este é um ponto de ruptura matemático, não uma regra de balanceamento.
- Esquivar 76 não altera o limiar normal para este alvo, mas pode consumir a reação — custo de oportunidade contextual não calculado sem cena.

### Regressão VLAB preservada

Pergunta “Explique R157 BASIC sequência 48” passou pelo **C09/C07 originais**: 73 pós-RD; 60 PV realmente retirados; 13 de overkill no R162 derivado. R169 continua segregado; SQLite históricos intactos. Nenhum combate novo foi realizado.

## Produtos materiais

- `c10_reaction_analyst.py`: nova camada genérica defensiva, PMFs exatas, reações, prebuff, Vida/overkill e gates.
- `c10_conversational.py`: roteador de perguntas em português para opções defensivas, com fallback C09 intacto.
- `C10_DEFENSE_SOURCES_MESTRE.json`: fonte, edição, aliases, regras e efeitos documentados; MESTRE-SIDE.
- `C10_SCIENCE_MATRIX_SOURCE_SCOPED.csv`: nove ramificações comparáveis com denominadores próprios.
- `C10_12_QUERY_SMOKE.json`: doze consultas reais executadas, inclusive fallback e regressão VLAB.
- `test_c10_reactions.py`: 50 testes; `c10_independent_oracle.py`: 41 verificações por método independente do resolvedor (enumeração e frações); regressões C09: 40/40 + 29/29.
- `README_PORTABLE_C10.md`: recuperação em diretório limpo, sem conexão Python–Notion nem terminal como requisito de uso Mestre/ChatGPT.
- `C10_SHA256_MANIFEST.json`, auditoria de extração limpa, recibo de readback após publicação.

## Situação dos gates

**NAC-PASS-02:** PASS técnico local de cálculo, regressões, escopo, integridade e portabilidade quando recibos presentes. Homologação científica externa, F0 formal e produção **HOLD**. Sem criação de regra; NAC-NORM-01 **não acionada para nova norma**. **F0=4/8**.

**DENOMINATORS:** dois perfis defensivos reabertos, dois atacantes anteriormente cadastrados, nove comparações de ramos, 12 consultas em linguagem natural, 50 testes dirigidos, 41 checagens de oráculo C10; 40 testes +29 checagens legadas C09; zero novos combates, zero novas fichas oficiais.

**FIRST-PENDING:** fonte/decisão competente de RD por componentes do mesmo golpe (Varok e Iskiel), repartição do arco Vento/perfurante, arredondamento de metade ímpar, e condição dinâmica de PA/Reação/posições numa cena real.

**CONFLICTS:** nenhum conflito resolvido por improvisação; Defender não substitui CA para permitir dano antes bloqueado; Casulo não é Reação nem demonstra autoalvo; fontes de equipamento/encounter Mestre-side têm status PROPOSTO.

**UNKNOWN-EFFECT:** R156 continua em quarentena. R138 conserva HOLD espacial.

**NO-REPEAT:** A6-571, C04-608, C05-648, C05–C09, R160/R162 e R169 e históricos VLAB preservados. C09 zip incorporado sem tocar bytes.

**AUTHORITY/WRITER STATE:** writer, lease, epoch, fencing e ACK não herdados. Notion, Party, O Primeiro, regras, fichas e SQLite READ-ONLY. Biblioteca pessoal experimental é destino de arquivo, não norma do RPG.

**NEXT-5:** 1) consultar estado de reação real e PA da cena quando fornecido; 2) investigar política de RD por componentes com fonte competente; 3) obter tipo/repartição do dano misto de Iskiel; 4) confrontar Esquivar/Defender em cenário VLAB fonte-admissível novo, sem repetir combate; 5) conectar consultas atuais de Vida/PA a recibos de eventos reais se surgirem entradas adequadas.

**TARGET-REMAINDER:** F0 4/8 (A5, A7, A8), F0–F18, E01–E24, oito gates transversais, L002/L003, fonte RD elemental e validação científica independente.
