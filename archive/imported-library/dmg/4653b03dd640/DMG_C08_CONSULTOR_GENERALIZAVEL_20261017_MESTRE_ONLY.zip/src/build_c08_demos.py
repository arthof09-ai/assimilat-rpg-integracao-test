#!/usr/bin/env python3
"""Demonstration generator from actual C08 consultor outputs; no combat or canonical writes."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from c08_generalized import Registry,ask,answer_pt,json_safe
queries={
 'A':'Quanto dano causa o Arranhão Putrificador?',
 'A_DEFENDER':'Quanto dano causa o Arranhão Putrificador do Gambá Demoníaco contra o Mamute Antigo?',
 'B':'Compare Arranhão Putrificador e Chifrada',
 'C':'Calcule 2d6+25, RD física 10, Vida 40, como TEST',
 'D':'Qual o dano da Mordida Necrótica e quais efeitos ainda não podem ser quantificados?',
 'E':'Explique novamente o evento R157 BASIC, sequência 48',
 'SECOND':'Quanto dano causa a Chifrada do Mamute Antigo?',
 'FOURTH':'Qual o dano do Raio Paralisante da Águia Arranha Céu?',
 'C07_LEGACY':'Quanto dano o Turbilhão Cinzento de Feryn faz contra Eristan?'
}
reg=Registry();out={key:{'question':q,'answer_structured':json_safe(ask(q,reg)),'answer_pt':answer_pt(ask(q,reg))} for key,q in queries.items()}
assert out['A']['answer_structured']['gross_mean']=='32'
assert out['B']['answer_structured']['delta_gross_mean_B_minus_A']=='2'
assert out['C']['answer_structured']['post_rd_mean']=='22'
assert out['D']['answer_structured']['gross_mean']=='41'
assert out['E']['answer_structured']['overkill']==13
(ROOT/'evidence/C08_CHAT_QUERIES_A_B_C_D_E.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
md=['# C08 — Consultas conversacionais executadas MESTRE-SIDE','', 'Todas as respostas abaixo foram geradas com a mesma função `ask()` em `src/c08_generalized.py`. `TEST` não é cânone.','']
for k,d in out.items():
 md+=['## '+k+' — '+d['question'],'','```text',d['answer_pt'],'```','']
(ROOT/'docs/C08_CHAT_QUERIES_EXECUTED_MESTRE_ONLY.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','demonstrations':len(out),'required_A_E':all(x in out for x in 'ABCDE'),'calculated_values':{'gamba':out['A']['answer_structured']['gross_mean'],'mamute':out['SECOND']['answer_structured']['gross_mean'],'mordida':out['D']['answer_structured']['gross_mean'],'test_post_RD':out['C']['answer_structured']['post_rd_mean'],'event_R157_Basic_48_hp':out['E']['answer_structured']['hp']}},ensure_ascii=False,indent=2))
