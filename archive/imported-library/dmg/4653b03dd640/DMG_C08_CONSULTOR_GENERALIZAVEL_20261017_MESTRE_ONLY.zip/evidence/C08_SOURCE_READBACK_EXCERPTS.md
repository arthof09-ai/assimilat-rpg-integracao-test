# C08 — Source-page readback excerpts, MESTRE-SIDE (2026-10-17)

Read with connected **Notion Mestre** `mcp__Notion__fetch`, project-surface restricted, without Party access or canonical writes. **These are selected literal excerpts, not full binary snapshots of historical pages or proof of canonization.** Source metadata and page edits were returned by fetch.

1. `966c2b324ede83d7962b019b1861b6b1`, edited `2026-10-01T18:00:52.851Z`. Page title `Prata 1`; parent `Gambá Demoníaco🌑`; rank-folder `Prata 1 · 3`, Dark. Body states: `Nome: gambá`; `Vida: 240`; `Ca: 39`; `Rank: prata 1 (2d6)`; `Destreza: 25`; `Arranhão putrificador: 2d6+Des, a ferida não pode ser curada facilmente. Teste de fortitude pra ver se fica paralisado`.
2. `92bc2b324ede828f9b040180a09d926d`, edited `2026-10-01T18:00:42.671Z`. Page title `Prata 1`; parent `Mamute Antigo❄️🪨`; rank-folder `Prata 1 · 3`, Gelo. Body states: `Nome: Mamute Antigo`; `Classificação: Prata 1`; `Vida: 240`; `CA: 33`; `Força: 22`; `Chifrada: 2d6+2d4+Força`.
3. `c70c2b324ede831c8f6c018c0b9295bd`, edited `2026-10-01T18:00:40.278Z`. Page title `Prata 1`; parent `Crocossuário Corrompido 🌊🌑☠️`; ancestor rank-folder `Ouro 1 · 3`, Água. Body states: `Nome: Crocossombra`; `Classificação: Prata`; `Vida: 336`; `CA: 40`; `Força: 28`; `Destreza: 25`; `Inteligência: 23`; `- A besta ganha a magia raio de Putrificação 2d6+Int`; `- +1d4 para ataques ou magias do tipo Dark`; `- Mordida Necrótica: Uma mordida que pode infectar o alvo com energia Dark, causando dano contínuo. 3d6+1d4+For`; `- Cauda Fantasma: ... 2d6+Dês (+5 para acertar)`. Rank conflict not resolved.
4. `206c2b324ede835383a1818a6edd5273`, edited `2026-10-01T18:00:49.453Z`. Page title `Prata 1`; parent `Águia Arranha Céu`; rank-folder `Prata 1 · 1`, Raio. Body states: `Nome: arranha céus`; `Vida: 156`; `Ca: 31`; `Rank: prata 1 (1d6)`; `Inteligência: 30`; `Raio paralisante: 1d4 + inteligência, teste de fortitude para não ficar paralisado`.

## Controls
- `SOURCE-PAGE`: four UUIDs, four URLs (no assumption of four entirely new pages relative to historical corpora).
- `DAMAGE-EFFECT`: six explicitly enumerated numeric damaging actions supported by those four pages (1+1+3+1).
- `DAMAGE-COMPONENT`: one-to-many formula terms; +1d4 conditional Dark separate and unadjudicated.
- `RANK`: Crocossombra title/body/ancestor disagreement; do not silently assign Prata1 or Ouro1.
- `DAMAGE TYPE`: physical or elemental identification absent/ambiguous in numeric attacks; only TEST assumption can authorize typed RD from user-provided parameters.
- `PA/precision/critical`: unknown unless proven by other authoritative source, not assumed.
- `VIDA` on page is maximum/source stat, not actual Vida remaining in a running combat.
- `PROVENANCE`: PHYSICALLY REOPENED pages, with version/date; selected excerpts manually copied from returned tool content. Full historical binary snapshots not recovered.
