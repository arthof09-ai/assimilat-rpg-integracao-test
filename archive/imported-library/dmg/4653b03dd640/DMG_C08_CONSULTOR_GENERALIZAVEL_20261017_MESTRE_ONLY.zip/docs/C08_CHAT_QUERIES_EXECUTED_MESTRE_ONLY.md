# C08 — Consultas conversacionais executadas MESTRE-SIDE

Todas as respostas abaixo foram geradas com a mesma função `ask()` em `src/c08_generalized.py`. `TEST` não é cânone.

## A — Quanto dano causa o Arranhão Putrificador?

```text
Arranhão Putrificador — Gambá Demoníaco. Fonte https://app.notion.com/p/966c2b324ede83d7962b019b1861b6b1 (edição 2026-10-01T18:00:52.851Z; SOURCE_READ_NOTION_MESTRE_C08).
Fórmula literal 2d6+Des = 2d6+25; canal VIDA; bruto 27–37; média exata 32, condicionado ao efeito ocorrer.
Dano por tentativa: INDETERMINATE_PRECISION; PA por uso: NÃO DOCUMENTADO; tipo exato: UNKNOWN; classificação: TITLE_BODY_ANCESTOR_CONCORDANT_NOMINAL_ALIAS_OPEN.
RD compatível ausente: não afirmar PV finais, probabilidade de acerto nem eficiência por tentativa.
Efeitos extras não quantificados: Ferida difícil de curar: parâmetros não documentados.; Teste de Fortitude para paralisia: CD, gatilho e consequência quantitativa não completos.
```

## A_DEFENDER — Quanto dano causa o Arranhão Putrificador do Gambá Demoníaco contra o Mamute Antigo?

```text
Arranhão Putrificador — Gambá Demoníaco. Fonte https://app.notion.com/p/966c2b324ede83d7962b019b1861b6b1 (edição 2026-10-01T18:00:52.851Z; SOURCE_READ_NOTION_MESTRE_C08).
Fórmula literal 2d6+Des = 2d6+25; canal VIDA; bruto 27–37; média exata 32, condicionado ao efeito ocorrer.
Defensor Mamute Antigo, CA 33, Vida máxima de ficha 240; Vida atual não presumida.
Dano por tentativa: INDETERMINATE_PRECISION; PA por uso: NÃO DOCUMENTADO; tipo exato: UNKNOWN; classificação: TITLE_BODY_ANCESTOR_CONCORDANT_NOMINAL_ALIAS_OPEN.
RD compatível ausente: não afirmar PV finais, probabilidade de acerto nem eficiência por tentativa.
Efeitos extras não quantificados: Ferida difícil de curar: parâmetros não documentados.; Teste de Fortitude para paralisia: CD, gatilho e consequência quantitativa não completos.
```

## B — Compare Arranhão Putrificador e Chifrada

```text
Comparação TEST de fórmulas documentadas (não combate): Arranhão Putrificador 2d6+25 (32 bruto médio, 27–37) vs Chifrada 2d6+2d4+22 (34 bruto médio, 26–42).
Diferença segunda−primeira 2; P(primeira>segunda)=25,82948%, P(segunda>primeira)=65,10417%, empate 9,06636%, assumindo dados independentes.
Precisão, defesa competente, PA e RD fonte-válida faltantes impedem declarar vencedora em combate.
```

## C — Calcule 2d6+25, RD física 10, Vida 40, como TEST

```text
TEST — fórmula declarada 2d6+25; bruto 27–37; média 32. Não é uma habilidade canônica por si só.
SE O DANO FOR FISICO: RD 10 (fisico); pós-RD 17–27 e média 22; PV condicionais 22, overkill 0 com Vida 40.
Dano por tentativa e PV/PA INDETERMINADOS até conhecer acerto e custo. O cálculo assume acerto/efeito ocorrido.
```

## D — Qual o dano da Mordida Necrótica e quais efeitos ainda não podem ser quantificados?

```text
Mordida Necrótica — Crocossombra. Fonte https://app.notion.com/p/c70c2b324ede831c8f6c018c0b9295bd (edição 2026-10-01T18:00:40.278Z; SOURCE_READ_NOTION_MESTRE_C08).
Fórmula literal 3d6+1d4+For = 3d6+1d4+28; canal VIDA; bruto 32–50; média exata 41, condicionado ao efeito ocorrer.
Dano por tentativa: INDETERMINATE_PRECISION; PA por uso: NÃO DOCUMENTADO; tipo exato: UNKNOWN_MIXED_WITH_DARK_NARRATIVE; classificação: CONFLICT_TITLE_PRATA1_BODY_PRATA_UNSTARRED_ANCESTOR_OURO1.
RD compatível ausente: não afirmar PV finais, probabilidade de acerto nem eficiência por tentativa.
Efeitos extras não quantificados: Infecção e dano contínuo sem potência/duração completa.; Habilidade Peste Negra: +1d4 para ataques ou magias Dark; não somar automaticamente ao 1d4 já incluído na Mordida.
```

## E — Explique novamente o evento R157 BASIC, sequência 48

```text
VLAB R162 — RUN R157_TACTIC_BASIC_DEV_S997617, seq 48, índice nativo 1 (seed 997617).
Sikong Eristan (E) → Sikong Feryn (F); SPELL_NO_PHYSICAL_ATTACK; ação spell, habilidade SPORES. Dano registrado 73, RD 0, pós-RD 73.
Vida 60 → 0: 60 PV realmente retirados; overkill 13. PA atribuído ao evento 80.
Salvaguarda/efeito: SAVE-HALF; CD 76, teste 35; R162 native spell raw may already be POST SAVE; do not halve twice.
Fonte SHA-256 do evento: b96f0d8dede4156a285d6689dd38b1e75cea1924874be320405cb91af29a0508; laboratório, não jogo oficial. Limite: MESTRE_SIDE_PROPOSED_NPCS|ELEMENTAL_RD_ZERO_LAB_ONLY_IF_SPELL.
```

## SECOND — Quanto dano causa a Chifrada do Mamute Antigo?

```text
Chifrada — Mamute Antigo. Fonte https://app.notion.com/p/92bc2b324ede828f9b040180a09d926d (edição 2026-10-01T18:00:42.671Z; SOURCE_READ_NOTION_MESTRE_C08).
Fórmula literal 2d6+2d4+Força = 2d6+2d4+22; canal VIDA; bruto 26–42; média exata 34, condicionado ao efeito ocorrer.
Dano por tentativa: INDETERMINATE_PRECISION; PA por uso: NÃO DOCUMENTADO; tipo exato: UNKNOWN; classificação: TITLE_BODY_ANCESTOR_CONCORDANT.
RD compatível ausente: não afirmar PV finais, probabilidade de acerto nem eficiência por tentativa.
Efeitos extras não quantificados: A ficha não fornece Luta, precisão, PA por ativação ou RD do alvo.
```

## FOURTH — Qual o dano do Raio Paralisante da Águia Arranha Céu?

```text
Raio Paralisante — Águia Arranha Céu. Fonte https://app.notion.com/p/206c2b324ede835383a1818a6edd5273 (edição 2026-10-01T18:00:49.453Z; SOURCE_READ_NOTION_MESTRE_C08).
Fórmula literal 1d4+Inteligência = 1d4+30; canal VIDA; bruto 31–34; média exata 32,5, condicionado ao efeito ocorrer.
Dano por tentativa: INDETERMINATE_PRECISION; PA por uso: NÃO DOCUMENTADO; tipo exato: UNKNOWN; classificação: TITLE_BODY_ANCESTOR_CONCORDANT_NOMINAL_ALIAS_OPEN.
RD compatível ausente: não afirmar PV finais, probabilidade de acerto nem eficiência por tentativa.
Efeitos extras não quantificados: Teste Fortitude contra paralisia descrito sem CD completa.
```

## C07_LEGACY — Quanto dano o Turbilhão Cinzento de Feryn faz contra Eristan?

```text
Turbilhão Cinzento de feryn contra eristan. Fonte https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31; defensor https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76.
Fórmula 9d10+8 (vento), bruto 17–98, média 57,5. Ação Padrão, custo PA 60, alcance cone 8 m.
Salvaguarda: REFLEXO_VS_LUTA_SPECIFIC, P(defesa supera) 0%. Antes de RD esperados 57,5 no modelo racional.
Defesa falha em todo o suporte: cenário FLOOR 57,5; CEIL 57,5 de dano condicionado por alvo (PV reais somente com RD e Vida competentes).
RD: INDETERMINADO — RD compatível por tipo não documentada nas fontes consultadas. Números de PV útil sob a hipótese auxiliar RD=0 TEST; não representam dano final canônico. Vida atual não fornecida; não afirmar PV efetivos absolutos ou overkill. Número de alvos realmente dentro do alcance não demonstrado. 
```

