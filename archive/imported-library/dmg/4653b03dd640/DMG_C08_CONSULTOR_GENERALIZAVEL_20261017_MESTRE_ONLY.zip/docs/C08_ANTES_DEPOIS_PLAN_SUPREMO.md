# ANTES → DEPOIS · DMG C08 · MESTRE-SIDE

| Axis | C07 ANTES | C08 DEPOIS | Terminal? |
|---|---|---|---|
| Mechanically indexed abilities | 3 name-coded | 3 legacy + 6 C08 effects via JSON records (9 overall) | No global corpus claim |
| Actor/defender catalog | 3 legacy profiles | +4 physically re-opened creature records; Mamute first new defender CA33 / max HP240 | Partial CA only |
| New name | Unknown Arranhão rejected | Exact `2d6+DES25`: 27–37, mean32 | PASS gross |
| Second name | Unknown Chifrada rejected | Exact `2d6+2d4+FOR22`: 26–42, mean34 | PASS gross |
| Third source | Unknown Crocossombra rejected | Mordida/Cauda/Raio each data-driven; rank conflict and conditional +1d4 kept apart | PASS gross / HOLD extras |
| Fourth source canary | Unknown Raio Paralisante | `1d4+INT30`: 31–34, mean32.5 | PASS gross |
| Arbitrary formula | Rejected | TEST `2d6+25` against conditional physical RD10 and HP40 → post 17–27, mean22, overkill0 | PASS TEST |
| Compared actions | Only hard-coded C07 catalog | Exact new–new and cross C08–C07 gross comparisons | PASS raw, HOLD combat |
| Defenders | Fixed Feryn/Eristan/Auren | Record-based attacker or defender lookup; CA33/HPMAX240 no guessed to-hit | PASS partial |
| Complex components | C06 component library only | Conditional Dark bonus metadata + optional independent TEST branch | PASS conditional |
| VLAB R162/R169 | Corrected sandbox event queries | Same files, no historical engine rewrite; R157 BASIC/48 generic run-token disambiguation | PASS directed regression |
| Portability | C07 fresh-dir PASS | Relative src/data paths, no absolute env dirs | To certify by fresh extraction |
| Formal governance | F0 4/8 | F0 4/8; A5/A7/A8 untouched | HOLD |

### Phase relevance (without promotion)
- F1/F2/F3: no claim of newly discovered global pages; 4 previously located physical pages re-opened and admitted as checked C08 records. Identity and aliases preserved.
- F4/F5/F6: attribute normalization, formula decomposition and source rank conflicts preserved; no retroactive fallback DMG-RANK application.
- F7/F8/F9: original coorte and exact independent-roll probabilities studied in source-conditioned model; no population significance from a tiny selected set.
- F10/F11/F12: Crocossombra rank conflict and source-selection bias documented. No full benchmark or gate certification.
- F13–F18: untouched; no candidate DMG v2.
- E01–E24 and transverse eight gates: no blanket PASS due to code tests.

### Runtime counters
- 4 source UUIDs physically re-opened on 17/10/2026.
- 6 new cataloged numeric effects, 14 base mathematical terms (dice/attribute), 1 separate conditional Dark +1d4 rule used by more than one attack.
- 3 pre-existing C07 effects and 3 original profiles retained untouched.
- 0 new global D0 proof; 0 official combat victories inferred; 0 canonic rules edited.

### Conflicts & external gates
- Crocossombra rank/ancestor mismatch; damage type/PA/offense missing.
- Generic sourced attack/defender combo allows gross, not precise per-attempt comparison without hit mechanic.
- C07 wind RD/odd-half rounding remain unresolved; R156 UNKNOWN_EFFECT and R138 HOLD unchanged.
- L002/L003 raw original attachments still inaccessible; no claims of historical uniqueness.
- A5 historical 0/7; A7 blind review 0/8; A8 no live writer/lease/epoch/ACK; F0 4/8.
