# DMG C08 — Consultor Generalizável · MESTRE-SIDE

**Operação existente:** `OP-DMG-CORPUS-EMP-01`. Baseline DMG-RANK-01 v1.1 **unchanged**. F0 formal **4/8**. This is a portable, read-only exact formula evaluator **and not a VLAB combat engine or automatic Notion agent**.

## Product: talk to the Comestre in ChatGPT

Ask in Portuguese, for example:

- “Quanto dano causa o Arranhão Putrificador do Gambá Demoníaco contra o Mamute Antigo?”
- “Compare Arranhão Putrificador e Chifrada.”
- “Calcule 2d6+25, RD física 10, Vida 40, como TEST.”
- “Qual o dano da Mordida Necrótica e o +1d4 Dark já está incluído?”
- “Explique o evento R157 BASIC, sequência 48.”

When the source is **not** in the approved registry, the Comestre must fetch the real page through authorized **Notion Mestre** and verify page identity, ancestors, last-edit, literal formula, attribute values and conditions **before** admitting it as sourced. The Python program **cannot connect to Notion by itself**. A user-supplied formula alone receives **TEST**, not source authority. A new source becomes queryable by appending a verified source/effect record to `data/C08_MESTRE_VERIFIED_SOURCES.json`; `src/c08_generalized.py` itself does not change. Re-freeze and independently audit the updated registry.

The registry in this checkpoint contains **4 previously located pages physically reopened during C08**, **6 source effects** (Gambá1, Mamute1, Crocossombra3, Águia1) and four extensible defender profiles. The historical C07 module still has 3 earlier abilities/3 profiles: **9 numeric ability options now exist across the two engines**, not 9 newly discovered canonical effects. No global corpus coverage claim.

## Run in any new directory — Python 3 standard library

```sh
python src/c08_generalized.py 'Quanto dano causa o Arranhão Putrificador?'
python src/c08_generalized.py 'Compare Arranhão Putrificador e Chifrada'
python src/c08_generalized.py 'Calcule dano físico 2d6+25, RD física 10, Vida 40, como TEST'
python src/c08_generalized.py 'Explique o evento R157 BASIC, sequência 48'
python src/c08_generalized.py 'Mordida Necrótica se o bônus Dark for independente, TEST'
python src/c08_generalized.py 'Quanto dano do Crocossombra?'
python src/c08_generalized.py 'Quanto dano da fonte https://app.notion.com/p/966c2b324ede83d7962b019b1861b6b1?'
```

JSON machine-readable: append `--json`. Keep executable relative to its `src` sibling, even if the working directory is elsewhere. C07 CSV data live in adjacent `data/`. No path under `/mnt/data/dmg_succession` is required at runtime.

## QA in a fresh extract

```sh
python -m unittest discover -s tests -p 'test_c08_generalized.py' -q
python -m unittest discover -s tests -p 'test_c07_consult.py' -q
python tests/c08_independent_oracle.py
python tests/c07_math_independent.py
python src/build_c08_demos.py
```

Optional original VLAB R170 external ZIP audit is deliberately separate; not a hidden dependency of the consultor. `tests/c07_independent_audit.py` requires its documented `--vlab-zip` archive argument. No scene simulation or SQLite historical mutation.

## Extend with a third-party or human-declared TEST record without code modifications

Prepare `{ "sources": [ ... ], "effects": [ ... ] }` with UUID, source URL, attributes, effect name and literal formula; invoke:

```sh
python src/c08_generalized.py --supplement new_source.json 'Quanto dano causa Corte TEST Alfa?'
```

**Security semantic:** every supplemental record is forcibly classified `TEST_EXTERNAL_SUPPLEMENT_UNVERIFIED`, even if its author claims `VERIFICADO`. That source cannot be promoted to verified automatically. To admit it as a physically verified RPG source, the Comestre reopens the page in Notion Mestre and updates the approved registry, with new source/version proof, re-audit, and re-freeze. The local approved registry itself is protected by the checkpoint SHA-256 manifest, not cryptographically signed by Notion.

## Mechanics & limitations

1. C05 exact PMF reused byte-for-byte, including supported positive dice+one fixed/attribute term. C06 defensive and component resolvers untouched; C07 events and spell/physical cases untouched. No new DMG v2 rule.
2. Formula and attribute source alone resolve **gross damage conditional on landing/triggering**, not per-attempt damage, hit probability, PA, crit or final PV.
3. Unknown damage type means **no type-validated RD**. With “RD física 10” but no physical damage declaration, output is a **TEST premise IF physical**, not a canonical mitigation.
4. The Mamute has CA33 and maximum HP240; neither implies its hit probability when Gambá's attack roll is absent, nor its current HP.
5. Crocossombra rank conflict **Prata1 title vs Prata body vs Ouro1 ancestor** stays HOLD. Dark +1d4 bonus is not stacked automatically with base 1d4. Only explicit hypothetical “se o bônus Dark for independente, TEST” produces a second conditional branch.
6. Threat/control/paralysis/DoT not assigned a numerical effect unless trigger, numeric amount and duration are adequately sourced.
7. C07 R162/R169 tables are read-only corrected technical sandbox receipts, **not official campaign attacks**. Event query must disambiguate RUN/sequence/native-action index; R157 BASIC/48 now resolves using a generic policy-token matcher.
8. User-interface responses are provided by the Comestre directly in the ChatGPT conversation. This archive does not install a plugin, establish automatic persistent Notion sync, or carry an inherited writer/lease/epoch/ACK.
9. Source pages and last-edit versions may change after this snapshot; re-open before claiming current source correctness. MESTRE-ONLY text must never be forwarded to Party without an appropriate authorization/canonization gate.

## Recovery

Check `C08_SHA256_MANIFEST.json`, unpack, run the QA steps, read `PSV_DMG_C08_CONSULTOR_GENERALIZAVEL_20261017_MESTRE_ONLY.md`, then continue from FIRST-PENDING. This C08 package is an additive delta; it does not overwrite historical C05–C07 ZIP files or original Notion pages.
