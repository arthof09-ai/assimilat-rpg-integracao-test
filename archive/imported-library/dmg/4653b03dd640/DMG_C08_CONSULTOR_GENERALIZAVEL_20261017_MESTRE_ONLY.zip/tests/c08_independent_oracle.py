#!/usr/bin/env python3
"""Independent oracle for C08: stand-alone Counter enumeration; never imports C05/C06 evaluator.
Checks math of selected sources and conditional scenarios, plus C07 file immutability.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from itertools import product
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
checks=0

def ck(test,msg):
 global checks
 checks+=1
 if not test:raise AssertionError(msg)

def independent_dice(dice,fixed):
 count=Counter({fixed:1})
 for n,faces in dice:
  for _ in range(n):
   tmp=Counter()
   for k,v in count.items():
    for rolled in range(1,faces+1):tmp[k+rolled]+=v
   count=tmp
 z=sum(count.values())
 return {k:F(v,z) for k,v in count.items()}

def avg(dist):return sum((F(k)*v for k,v in dist.items()),F(0))

records=json.loads((ROOT/'data/C08_MESTRE_VERIFIED_SOURCES.json').read_text('utf-8'))
source={r['uuid']:r for r in records['sources']}
for s in records['sources']:
 ck(s['url'].endswith(s['uuid']),'source URL identity');ck(s['source_evidence']=='VERIFICADO_NOTION_MESTRE_20261017','read provenance');ck(len(s['last_edited'])>=20,'edited');ck(s['ca']>=0 and s['max_hp']>=0,'HP CA positive')
ck(len(records['effects'])==6,'six effects');ck(len(records['sources'])==4,'four sources')

# Independent static tuples transcribed from physically fetched source excerpts.
known={
 'e-gamba-arranhao':([(2,6)],25,27,37,F(32)),
 'e-mamute-chifrada':([(2,6),(2,4)],22,26,42,F(34)),
 'e-croco-mordida':([(3,6),(1,4)],28,32,50,F(41)),
 'e-croco-cauda':([(2,6)],25,27,37,F(32)),
 'e-croco-raio':([(2,6)],23,25,35,F(30)),
 'e-aguia-raio':([(1,4)],30,31,34,F(65,2))}
assert set(known)=={e['id'] for e in records['effects']}
independent={}
for ident,(dice,fixed,low,high,expected) in known.items():
 d=independent_dice(dice,fixed);independent[ident]=d
 ck(min(d)==low,ident+' min');ck(max(d)==high,ident+' max');ck(avg(d)==expected,ident+' mean');ck(sum(d.values())==1,ident+' probability');ck(min(d)>=0,ident+' nonnegative')

A=independent['e-gamba-arranhao'];B=independent['e-mamute-chifrada']
pa_gt=sum(a*b for x,a in A.items() for y,b in B.items() if x>y)
pb_gt=sum(a*b for x,a in A.items() for y,b in B.items() if x<y)
p_tie=sum(a*b for x,a in A.items() for y,b in B.items() if x==y)
ck(pa_gt+pb_gt+p_tie==1,'compare probs total');ck(avg(B)-avg(A)==2,'compare delta +2')
# TEST: if and ONLY if the source formula really is physical, RD10, Life40.
post={max(0,v-10):pr for v,pr in A.items()}
ck(min(post)==17 and max(post)==27,'post RD range');ck(avg(post)==22,'post RD mean');ck(max(post)<40,'HP cap no overkill')
# Counterfactual high RD gap no invented hit probability:
for rd in [0,1,10,31,100]:
 da=Counter();db=Counter()
 for k,v in A.items():da[max(0,k-rd)]+=v
 for k,v in B.items():db[max(0,k-rd)]+=v
 ck(min(da)>=0 and min(db)>=0,'RD no negative '+str(rd))
 ck(sum(da.values())==1 and sum(db.values())==1,'probabilities normalization '+str(rd))
# Verify damage type remains UNKNOWN; no false Fortitude/PA inference.
for eff in records['effects']:
 ck(eff['pa_per_use'] is None,'PA absent '+eff['id'])
 ck(eff['offense_roll'] is None,'offense absent '+eff['id'])
 ck(eff['damage_channel']=='VIDA','HP channel '+eff['id'])
ck(records['effects'][2]['conditional_components'][0]['already_in_base_unknown'],'Dark bonus not double counted')
ck(records['effects'][3]['offense_bonus_specific']==5,'Cauda +5 to hit, not damage')
ck(source['c70c2b324ede831c8f6c018c0b9295bd']['classification_status'].startswith('CONFLICT'),'Crocossombra rank HOLD')
# Preexisting C05/C06/C07 engine fingerprints unchanged.
frozen={'experimental_damage_calc.py':'01fd5eb99a782665fc0ad9aedf47ae1e96977ab2f99c7f35d815c4b2c045d2e9','c06_damage_resolver.py':'9cf3f7ad8fc19d85d77c75a12d807c7ea21e9652dc1393f1540c18673f9d711a'}
for m,sha in frozen.items():ck(hashlib.sha256((ROOT/'src'/m).read_bytes()).hexdigest()==sha,'C06 unchanged '+m)
check_c07=hashlib.sha256((ROOT/'src/c07_conversational.py').read_bytes()).hexdigest()
original_manifest=json.loads((ROOT/'evidence/C07_ORIGINAL_MANIFEST_READONLY.json').read_text('utf-8'))
ck(check_c07==original_manifest['files']['src/c07_conversational.py']['sha256'],'C07 unchanged')
result={'status':'PASS','independent_counter_oracle_checks':checks,'gamba_mean':'32','mamute_mean':'34','croco_mordida_mean':'41','exact_P_gamba_gt_mamute':str(pa_gt),'exact_P_mamute_gt_gamba':str(pb_gt),'exact_P_equal':str(p_tie),'damage_TEST_if_physical_RD10':'17–27 mean22, Vida40 no overkill','provenance':'four physically Notion Mestre reopened pages, not a global census','out_of_scope':['source full binary freeze','VLAB native re-audit','formal F0 gate']}
(ROOT/'qa/C08_INDEPENDENT_ORACLE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
