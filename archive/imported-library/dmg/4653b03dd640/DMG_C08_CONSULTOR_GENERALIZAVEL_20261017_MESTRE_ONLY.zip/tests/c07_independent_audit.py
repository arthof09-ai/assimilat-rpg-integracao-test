#!/usr/bin/env python3
"""Standalone cold audit. Readonly: only reads original VLAB R170 archive and local C07 output.
External VLAB original MUST be explicitly supplied; no magical hidden absolute paths.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, sqlite3, tempfile, zipfile
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE='VLAB_R161_R170_RECEIPTS_TEMPORAL_CROC_ED_CORRECTED_MESTRE_ONLY.zip'

def H(data):return hashlib.sha256(data).hexdigest()
def read_csv(data):return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
def primitive_row_checks(rows,cohort):
 checks=0
 for r in rows:
  raw=int(r['damage_raw' if cohort=='R162' else 'raw_damage']);rd=int(r['rd_applied']);post=int(r['net_post_RD']);hp=int(r['hp_effectively_lost']);ov=int(r['overkill']);before=int(r['hp_before']);after=int(r['hp_after'])
  assert raw-rd==post,(cohort,r['run_id'],r['seq_R18'],'RD')
  assert post==hp+ov,(cohort,r['run_id'],r['seq_R18'],'overkill')
  assert before-after==hp,(cohort,r['run_id'],r['seq_R18'],'HP')
  assert hp>=0 and ov>=0 and before>=after>=0
  checks+=4
 return checks

def open_readonly_sqlite_bytes(ar:zipfile.ZipFile,prefix:str,name:str):
 """Open extracted COPY in tempdir, not historical native. WAL handled without mutation of source."""
 tmp=tempfile.TemporaryDirectory(prefix='dmgc07audit-')
 for suffix in ('.sqlite','.sqlite-shm','.sqlite-wal'):
  key=prefix+name+suffix
  if key in ar.namelist(): (Path(tmp.name)/(name+suffix)).write_bytes(ar.read(key))
 p=Path(tmp.name)/(name+'.sqlite');assert p.exists(),p
 conn=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True)
 return tmp,conn

def run(zip_path, c06_zip=None, write=None):
 assert Path(zip_path).is_file(),f'MISSING_EXPLICIT_VLAB_ARCHIVE: {zip_path}'
 src=zipfile.ZipFile(zip_path)
 assert src.testzip() is None
 manifest=json.loads(src.read('R170_SHA256_MANIFEST.json'))
 for name, expected in manifest['files'].items():
  assert H(src.read(name))==expected,(name,'HASH_FAIL')
 nmanifest=len(manifest['files']);assert nmanifest==len(src.namelist())-1
 embedded160=zipfile.ZipFile(io.BytesIO(src.read('R160_BASELINE_EXACT.zip')))
 corrected=src.read('r161_r170/R162_CORRECTED_RECEIPTS_R160_HISTORICAL_UNMODIFIED.csv')
 new=src.read('r161_r170/R169_NEW_NATIVE_RECEIPTS_137_SOURCE_SCOPED.csv')
 assert corrected==(ROOT/'data/R162_CORRECTED_RECEIPTS_R160_HISTORICAL_UNMODIFIED.csv').read_bytes()
 assert new==(ROOT/'data/R169_NEW_NATIVE_RECEIPTS_137_SOURCE_SCOPED.csv').read_bytes()
 r162=read_csv(corrected);r169=read_csv(new);assert (len(r162),len(r169))==(154,137)
 checks=primitive_row_checks(r162,'R162')+primitive_row_checks(r169,'R169')
 def sums(rows,rawkey):return {k:sum(int(r[k] or 0) for r in rows) for k in [rawkey,'rd_applied','net_post_RD','hp_effectively_lost','overkill']}
 a=sums(r162,'damage_raw');b=sums(r169,'raw_damage');assert a==dict(damage_raw=16064,rd_applied=4194,net_post_RD=11870,hp_effectively_lost=11808,overkill=62);assert b==dict(raw_damage=16876,rd_applied=5045,net_post_RD=11831,hp_effectively_lost=11563,overkill=268)
 assert len({r['run_id'] for r in r162})==9 and len({r['run_id'] for r in r169})==5
 assert {r['run_id'] for r in r162}.isdisjoint({r['run_id'] for r in r169})
 assert {r['source_event_sha256'] for r in r162}.isdisjoint({r['event_SHA256'] for r in r169})
 checks+=12+nmanifest
 reconciliation=json.loads(src.read('r161_r170/R161_R162_NATIVE_RECONCILIATION.json'))
 assert (reconciliation['original_post_rd'],reconciliation['correct_hp_effective'],reconciliation['old_sum_hp_effectively_lost'])==(11870,11808,11845)
 assert sum(x['overkill_extra'] for x in reconciliation['old_incorrect_records'])==37
 checks+=4
 # Original historical R160 table embedded within native baseline, do not re-run original producer.
 origpath=[x for x in embedded160.namelist() if x.endswith('R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv')]
 assert len(origpath)==1,origpath
 old=read_csv(embedded160.read(origpath[0]));assert len(old)==154
 orig={(r['run_id'],int(r['seq_R18']),int(r['action_index_in_tx'])):r for r in old}
 newmap={(r['run_id'],int(r['seq_R18']),int(r['action_index_in_tx'])):r for r in r162};assert orig.keys()==newmap.keys()
 changed=[]
 for key,x in newmap.items():
  o=orig[key]
  assert x['source_event_sha256']==o['row_SHA256']==x['row_SHA256']
  # Original posted damage, RD, actor and target must stay byte-invariant.
  for k in ('damage_raw','net_post_RD','rd_applied','actor','target','kind','PA_spent','save_score','save_CD'):
   assert x[k]==o[k],(key,k)
   checks+=1
  if (int(x['hp_effectively_lost']),int(x['overkill']))!=(int(o['hp_effectively_lost']),int(o['overkill'])):
   changed.append({'run_id':key[0],'seq':key[1],'idx':key[2],'old_HP':int(o['hp_effectively_lost']),'new_HP':int(x['hp_effectively_lost']),'old_ov':int(o['overkill']),'new_ov':int(x['overkill'])})
 assert len(changed)==3;assert sorted(z['old_HP']-z['new_HP'] for z in changed)==[11,13,13]
 checks+=5
 # Limited, discriminatory native samples; the other 122 were already independently traced by VLAB.
 samples160=[('R157_TACTIC_BASIC_DEV_S997617',48,1),('R157_TACTIC_WIND_DEV_S997617',48,1),('R158_NEGATIVE_CRITICAL_TACTIC_DEV_S997946',48,1),('R157_TACTIC_BASIC_DEV_S997617',3,1),('R157_TACTIC_BASIC_DEV_S997617',6,1),('R159_ED_GRIFO_AUREN_BE_SPECIAL_DEV_S998803',5,1)]
 samples169=[('R166_V2_CASULO_AOO_KO_DEV_S1205088',5,1),('R168_ED_AUREN_VS_CROC_BASIC_DEV_S1168001',197,1),('R168_ED_AUREN_VS_CROC_BASIC_RESERVED_NONBLIND_S1169001',197,1),('R165_FLECHA_TURN_EXPLICIT_V3_DEV_S1185114',2,1)]
 native=[]
 for cohort,samples,rows,archive,prefix in [('R162',samples160,r162,embedded160,'r151_r160/runs/'),('R169',samples169,r169,src,'r161_r170/runs/')]:
  for runid,seq,index in samples:
   matches=[r for r in rows if r['run_id']==runid and int(r['seq_R18'])==seq and int(r['action_index_in_tx' if cohort=='R162' else 'native_action_in_commit'])==index]
   assert len(matches)==1,(cohort,runid,seq,index)
   r=matches[0];tmp,conn=open_readonly_sqlite_bytes(archive,prefix,runid)
   try:
    row=conn.execute('SELECT row_json,row_sha FROM events WHERE seq=?',(seq,)).fetchone();assert row
    ev=json.loads(row[0]);sha=r['source_event_sha256' if cohort=='R162' else 'event_SHA256'];assert row[1]==sha
    detail=ev['detail'];actions=detail.get('native_actions') or [detail.get('native_action')]
    assert len(actions)>=index and actions[index-1]
    action=actions[index-1];before=action.get('hp_before',action.get('before_hp'));after=action.get('hp_after',action.get('after_hp'))
    assert (int(before),int(after))==(int(r['hp_before']),int(r['hp_after']))
    damage=action.get('effective',action.get('net'))
    assert int(damage)==int(r['net_post_RD'])
    assert int(action.get('rd_applied',0))==int(r['rd_applied'])
    native.append({'cohort':cohort,'run_id':runid,'seq':seq,'native_index':index,'sha':sha,'hp_before':int(before),'hp_after':int(after),'post_RD':int(damage),'hp_actual':int(r['hp_effectively_lost']),'overkill':int(r['overkill']),'native_action_semantic':action.get('action'),'passed':True})
    checks+=7
   finally:conn.close();tmp.cleanup()
 # Check scene level denominators WITHOUT replay; read only events count, not historical modification.
 commits_by_cohort={}
 for label,archive,prefix,rows in [('R162',embedded160,'r151_r160/runs/',r162),('R169',src,'r161_r170/runs/',r169)]:
  total=0;per_run={}
  for name in sorted(set(r['run_id'] for r in rows)):
   tmp,conn=open_readonly_sqlite_bytes(archive,prefix,name)
   try:
    n=conn.execute('select count(*) from events').fetchone()[0];pending=conn.execute('select count(*) from pending').fetchone()[0];assert pending==0
    per_run[name]=n;total+=n;checks+=2
   finally:conn.close();tmp.cleanup()
  commits_by_cohort[label]=total
 assert commits_by_cohort=={'R162':466,'R169':413};checks+=2
 result={'status':'PASS','audit':'C07_COLD_PROPORTIONAL_PLUS_PORTABLE','archive_sha256':H(Path(zip_path).read_bytes()),'original_R160_baseline_SHA256':H(src.read('R160_BASELINE_EXACT.zip')),'manifest_files':nmanifest,'c07_files_match_original_R170':True,'R162':{'n':154,'runs':9,'commits':466,'sums':a},'R169':{'n':137,'runs':5,'commits':413,'sums':b},'old_R160_corrected_event_deltas':changed,'native_spot_sample_count':len(native),'native_spot_samples':native,'independent_checks':checks,'science_limits':['sample does not replace VLAB exhaustive nine-bank reconstruction','event receipts correlated within 14 scenes; not 291 independent trials','RD elemental not imputed','R159/R168 special fixture/reserved NONBLIND not official holdout','no historical sqlite modified']}
 if write:Path(write).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return result

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--vlab-zip',required=True,help='Explicit original R170 ZIP; required for hash and native SQLite spot audit');ap.add_argument('--out',help='write JSON evidence')
 a=ap.parse_args();r=run(a.vlab_zip,write=a.out);print(json.dumps({k:r[k] for k in ['status','manifest_files','native_spot_sample_count','independent_checks','R162','R169']},ensure_ascii=False,indent=2))
