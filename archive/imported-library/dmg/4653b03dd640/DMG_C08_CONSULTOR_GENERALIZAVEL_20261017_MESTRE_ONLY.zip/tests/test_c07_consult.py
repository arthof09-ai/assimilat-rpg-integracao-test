#!/usr/bin/env python3
"""Focused new C07 behavioral tests, run from any extract directory."""
import unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from c07_conversational import *
from fractions import Fraction as Q

class ConversationalContract(unittest.TestCase):
 def test_question_router_turbilhao(self):
  x=ask('Quanto dano o Turbilhão Cinzento de Feryn faz contra Eristan? Reflexo e PA?');self.assertEqual(x['kind'],'ACTION');self.assertEqual(x['gross_expected'],Q(115,2));self.assertEqual(x['p_defender_exceeds'],Q(0));self.assertEqual(x['cost_PA'],60);self.assertIsNone(x['rd']);self.assertEqual((x['min'],x['max']),(17,98))
 def test_question_auren(self):
  x=ask('Turbilhão de Feryn contra Auren');self.assertEqual(x['p_defender_exceeds'],Q(1));self.assertEqual(x['half_bounds']['FLOOR_TEST']['hp_effective_expected'],Q(57,2));self.assertEqual(x['half_bounds']['CEIL_TEST']['hp_effective_expected'],Q(29))
 def test_unknown_typed_wind(self):
  self.assertIsNone(ask('Turbilhão de Feryn contra Eristan')['rd']);self.assertEqual(ask('Turbilhão de Feryn contra Eristan RD Vento 3')['rd'],3)
 def test_rd_mismatch_rejected(self):
  with self.assertRaises(NeedsSource):ask('Turbilhão de Feryn contra Eristan RD fisico 25')
 def test_half_round_not_default(self):
  x=ask('Turbilhão de Feryn contra Auren');self.assertEqual(x['rounding'],'HALF_ODD_POLICY_UNRESOLVED');self.assertLess(x['half_bounds']['FLOOR_TEST']['hp_effective_expected'],x['half_bounds']['CEIL_TEST']['hp_effective_expected'])
 def test_exact_hp_cap_and_ov(self):
  x=ask('Turbilhão de Feryn contra Eristan Vida 10 RD vento 0');self.assertEqual(x['half_bounds']['FLOOR_TEST']['hp_effective_expected'],Q(10));self.assertEqual(x['half_bounds']['FLOOR_TEST']['overkill_expected'],Q(95,2));self.assertEqual(x['half_bounds']['FLOOR_TEST']['pv_per_PA'],Q(1,6))
 def test_attack_physical_vs_ca(self):
  x=ask('Presas de Feryn contra Eristan');self.assertEqual(x['p_hit'],Q(1));self.assertEqual(x['on_hit_expected'],Q(58));self.assertEqual(x['gross_expected'],Q(83));self.assertEqual(x['rd'],25);self.assertIsNone(x['cost_PA']);self.assertEqual(x['critical_status'],'EXCLUDED_BY_TEST_NO_CRIT')
 def test_save_tie_rule(self):
  from c06_damage_resolver import compare_rolls
  x=compare_rolls('1d6+0','1d6+0');self.assertEqual(x['tie'],Q(1,6));self.assertEqual(x['defender_strict_success'],Q(5,12))
 def test_missing_defense(self):
  x=ask('Quanto dano Feryn causa com Turbilhão?');self.assertEqual(x['kind'],'PARTIAL_NEEDS_TARGET')
 def test_missing_actor(self):
  with self.assertRaises(NeedsSource):ask('Quanto dano ataque especial nível 5 de desconhecido?')
 def test_alvo_duplo_linear(self):
  x=ask('Turbilhão de Feryn contra Eristan 2 alvos');self.assertEqual(x['targets_input'],2);self.assertEqual(x['half_bounds']['FLOOR_TEST']['total_targets_expected'],115)
 def test_compare_two_real(self):
  x=ask('Compare Presas e Turbilhão contra Eristan');self.assertEqual(x['kind'],'COMPARISON');self.assertEqual({x['a']['gross_expected'],x['b']['gross_expected']},{Q(83),Q(115,2)})
 def test_compare_two_different_casters(self):
  x=ask('Compare Descarga e Turbilhão contra Auren');self.assertEqual({x['a']['actor'],x['b']['actor']},{'eristan','feryn'});self.assertEqual({x['a']['cost_PA'],x['b']['cost_PA']},{65,60})
 def test_incomparable_rejected(self):
  with self.assertRaises(NeedsSource):ask('Compare três ataques diferentes contra Auren')
 def test_event_r162(self):
  x=ask('Explique VLAB R157_TACTIC_BASIC_DEV_S997617 evento 48');self.assertEqual((x['post'],x['hp'],x['overkill'],x['hp_before'],x['hp_after'],x['PA']),(73,60,13,60,0,80));self.assertEqual(x['cohort'],'R162')
 def test_event_r169(self):
  x=ask('VLAB R166_V2_CASULO_AOO_KO_DEV_S1205088 evento 5');self.assertEqual((x['post'],x['hp'],x['overkill'],x['origin']),(114,60,54,'OPPORTUNITY'));self.assertEqual(x['cohort'],'R169')
 def test_ambiguity_no_fake_event(self):
  x=ask('Explique VLAB R157 evento 48');self.assertEqual(x['kind'],'EVENT_SELECTION');self.assertEqual(x['matched'],3)
 def test_aggregates_separate(self):
  a=agg('R162');b=agg('R169');self.assertEqual((a['n_events'],a['n_runs'],a['post'],a['hp'],a['overkill']),(154,9,11870,11808,62));self.assertEqual((b['n_events'],b['n_runs'],b['post'],b['hp'],b['overkill']),(137,5,11831,11563,268))
 def test_ledger_event_invariant_all(self):
  for cohort in ('R162','R169'):
   for r in run_load(cohort):
    idx=r['action_index_in_tx' if cohort=='R162' else 'native_action_in_commit'];x=event_query(cohort,r['run_id'],r['seq_R18'],action_index=idx);self.assertEqual(x['kind'],'EVENT');self.assertEqual(x['post'],x['hp']+x['overkill']);self.assertEqual(x['hp'],x['hp_before']-x['hp_after'])
 def test_multi_action_same_commit_not_silently_selected(self):
  x=event_query('R162','R154_TWO_AOO_FULL_SOURCE_DEV_S999141',2)
  self.assertEqual(x['kind'],'EVENT_SELECTION');self.assertEqual(x['matched'],2)
  self.assertEqual(event_query('R162','R154_TWO_AOO_FULL_SOURCE_DEV_S999141',2,action_index=2)['kind'],'EVENT')
 def test_same_run_not_independent(self):
  b=agg('R169');self.assertEqual(b['n_runs'],5);self.assertEqual(b['n_events'],137)
 def test_spelling_normalization(self):
  self.assertEqual(norm('TURBILHÃO CINZENTO'),'turbilhao cinzento')
 def test_vlab_save_not_doubled(self):
  x=event_query('R162','R157_TACTIC_BASIC_DEV_S997617',48);self.assertEqual(x['raw'],73);self.assertEqual(x['post'],73);self.assertIn('do not halve twice',x['semantics'])
 def test_zero_rd_provenance(self):
  x=ask('Turbilhão de Feryn contra Eristan RD vento 0');self.assertIn('TEST',x['rd_note']);self.assertEqual(x['rd'],0)
 def test_invalid_pa(self):
  from c06_damage_resolver import mode_distribution
  x=mode_distribution('1d6+2',damage_type='vento',pa_cost=60,pa_available=59);self.assertEqual(x['status'],'NOT_EXECUTABLE_INSUFFICIENT_FREE_PA')
 def test_bad_formula(self):
  with self.assertRaises(ValueError):dist('3d6+HACK')
 def test_no_leak_for_source(self):
  self.assertTrue(all('app.notion.com' in u for u in SRC.values()))

if __name__=='__main__':unittest.main(verbosity=2)
