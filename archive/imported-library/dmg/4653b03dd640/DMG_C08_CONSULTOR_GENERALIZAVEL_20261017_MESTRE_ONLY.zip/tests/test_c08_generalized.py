#!/usr/bin/env python3
"""C08 finite discriminant tests, no networking, no Notion/Party writes."""
import json,sys,tempfile,copy,unittest
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from c08_generalized import Registry,ask,answer_pt,json_safe,source_validate,compile_formula,exact_compare,DEFAULT_REGISTRY
from c06_damage_resolver import NeedsSource

class C08(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.reg=Registry()
 def q(self,s):return ask(s,self.reg)
 def test_source_count(self):self.assertEqual(len(self.reg.sources),4)
 def test_effect_count(self):self.assertEqual(len(self.reg.effects),6)
 def test_authority(self):self.assertTrue(all(x['source_evidence'].startswith('VERIFICADO') for x in self.reg.sources.values()))
 def test_registry_source_ids(self):self.assertEqual(len({v['uuid'] for v in self.reg.sources.values()}),4)
 def test_actor_only_single_effect(self):self.assertEqual(self.q('Quanto dano causa o Gambá Demoníaco?')['name'],'Arranhão Putrificador')
 def test_actor_only_multiple_effects(self):self.assertEqual(self.q('Quanto dano causa o Crocossombra?')['kind'],'MULTIPLE_SOURCE_EFFECTS')
 def test_direct_source_url(self):self.assertEqual(self.q('Quanto dano da fonte https://app.notion.com/p/966c2b324ede83d7962b019b1861b6b1?')['name'],'Arranhão Putrificador')
 def test_croco_dark_independent_only_test(self):
  x=self.q('Mordida Necrótica se o bônus Dark for independente, TEST');self.assertEqual(x['conditional_variant_TEST']['expected'],'87/2');self.assertEqual(x['gross_mean'],'41')
 def test_first_new_name(self):x=self.q('Quanto dano causa o Arranhão Putrificador?');self.assertEqual((x['gross_min'],x['gross_max'],x['gross_mean']),(27,37,'32'))
 def test_first_new_missing_accuracy(self):x=self.q('Quanto dano causa Arranhão?');self.assertEqual(x['damage_per_attempt'],'INDETERMINATE_PRECISION')
 def test_gamba_no_fake_pa(self):self.assertIsNone(self.q('Arranhão Putrificador')['cost_PA'])
 def test_gamba_no_fake_paralysis(self):self.assertIn('Fortitude',' '.join(self.q('Arranhão Putrificador')['continuous_additional']))
 def test_second_new_name(self):x=self.q('Quanto dano causa a Chifrada do Mamute Antigo?');self.assertEqual((x['gross_min'],x['gross_max'],x['gross_mean']),(26,42,'34'))
 def test_mamute_defender_ca(self):x=self.q('Arranhão Putrificador contra Mamute Antigo');self.assertEqual((x['defender']['ca'],x['defender']['max_hp']),(33,240))
 def test_mamute_defender_hp_current_unknown(self):self.assertEqual(self.q('Arranhão Putrificador contra Mamute Antigo')['defender']['hp_current'],'NOT_DOCUMENTED_IN_THIS_QUERY')
 def test_mamute_not_auto_hit(self):self.assertEqual(self.q('Arranhão contra Mamute')['p_hit'],'INDETERMINATE_ATTACK_ROLL_EVEN_WITH_DOCUMENTED_CA')
 def test_croco_mordida(self):x=self.q('Qual dano da Mordida Necrótica?');self.assertEqual((x['gross_min'],x['gross_max'],x['gross_mean']),(32,50,'41'))
 def test_croco_rank_conflict(self):self.assertIn('CONFLICT',self.q('Mordida Necrótica')['classification_status'])
 def test_croco_conditional_component_hold(self):self.assertEqual(self.q('Mordida Necrótica')['incremental'][0]['admission'],'HOLD_UNTIL_DISTINCTNESS_PROVEN')
 def test_croco_no_double_dark(self):self.assertEqual(self.q('Mordida Necrótica')['resolved_formula'],'3d6+1d4+28')
 def test_croco_cauda_precision_not_damage(self):x=self.q('Cauda Fantasma');self.assertEqual(x['gross_mean'],'32');self.assertEqual(x['offense_bonus_specific'],5)
 def test_croco_raio(self):x=self.q('Raio de Putrificação');self.assertEqual((x['gross_min'],x['gross_max'],x['gross_mean']),(25,35,'30'))
 def test_fourth_entity_without_algorithm_change(self):x=self.q('Raio Paralisante da Águia Arranha Céu');self.assertEqual((x['gross_min'],x['gross_max'],x['gross_mean']),(31,34,'65/2'))
 def test_comparison_a_b(self):x=self.q('Compare Arranhão Putrificador e Chifrada');self.assertEqual(x['kind'],'SOURCE_COMPARISON');self.assertEqual(F(x['delta_gross_mean_B_minus_A']),2)
 def test_comparison_probabilities_complete(self):x=self.q('Compare Arranhão Putrificador e Chifrada');d=x['independent_dice_test'];self.assertEqual(sum(F(d[k]) for k in ('p_A_gt_B','p_B_gt_A','p_tie')),1)
 def test_comparison_not_winner_claim(self):self.assertIn('NO_COMBAT_WINNER',self.q('Compare Arranhão e Chifrada')['scope'])
 def test_test_formula(self):x=self.q('Calcule 2d6+25, RD física 10, Vida 40, como TEST');self.assertEqual((x['gross_min'],x['gross_max'],x['gross_mean']),(27,37,'32'));self.assertEqual((x['post_rd_min'],x['post_rd_max'],x['post_rd_mean']),(17,27,'22'))
 def test_test_formula_hp(self):x=self.q('Calcule 2d6+25, RD física 10, Vida 40, como TEST');self.assertEqual((x['hp_loss_mean'],x['overkill_mean']),('22','0'))
 def test_test_formula_type_conditional(self):x=self.q('Calcule 2d6+25, RD física 10, Vida 40, como TEST');self.assertEqual(x['rd_status'],'TEST_CONDITIONAL_DAMAGE_TYPE_PREMISE')
 def test_test_explicit_physical(self):x=self.q('Calcule dano físico 2d6+25 com RD física 10 e vida 40');self.assertEqual(x['rd_status'],'TEST_MATCHING_TYPE_DECLARED')
 def test_test_rd_type_mismatch(self):self.assertEqual(self.q('Calcule dano vento 2d6+25 com RD física 10')['rd_status'],'REJECT_DAMAGETYPE_RD_MISMATCH')
 def test_bad_formula_unsupported(self):
  with self.assertRaises(ValueError):self.q('Calcule 2d6+HACK com RD física 10')
 def test_bad_formula_negative(self):
  with self.assertRaises(ValueError):self.q('Calcule 2d6-7 com RD física 10')
 def test_bad_formula_multiply(self):
  with self.assertRaises(ValueError):self.q('Calcule 2d6*7 com RD física 10')
 def test_bad_formula_multiple(self):
  with self.assertRaises(NeedsSource):self.q('Calcule 2d6+25 ou 1d6+10')
 def test_bad_formula_nonstandard_sides(self):
  with self.assertRaises(ValueError):self.q('Calcule 1d1+5')
 def test_cross_c07(self):x=self.q('Compare Arranhão Putrificador e Presas de Feryn');self.assertEqual(x['kind'],'CROSS_C07_COMPARISON');self.assertEqual(x['b']['gross_mean'],'83')
 def test_c07_query_unchanged(self):x=self.q('Turbilhão de Feryn contra Eristan');self.assertEqual((x['kind'],str(x['gross_expected']),str(x['p_defender_exceeds'])),('ACTION','115/2','0'))
 def test_c07_vlab_r162(self):x=self.q('Explique o evento R157 BASIC, sequência 48');self.assertEqual((x['cohort'],x['hp'],x['overkill']),('R162',60,13))
 def test_c07_vlab_r169(self):x=self.q('VLAB R166_V2_CASULO_AOO_KO_DEV_S1205088 evento 5');self.assertEqual((x['cohort'],x['post'],x['hp'],x['overkill']),('R169',114,60,54))
 def test_safeguard_nosave_2(self):self.assertIn('do not halve twice',self.q('Explique o evento R157 BASIC, sequência 48')['semantics'])
 def test_rd_in_new_effect_conditional(self):x=self.q('Mordida Necrótica contra Mamute Antigo RD física 10');self.assertEqual(x['rd_status'],'TEST_CONDITIONAL_ON_MATCHING_DAMAGE_TYPE')
 def test_rd_not_auto_from_nominal(self):self.assertEqual(self.q('Mordida Necrótica contra Mamute Antigo')['rd_status'],'MISSING_NO_RD_PROVEN')
 def test_source_url_uuid_mismatch_rejected(self):
  s=copy.deepcopy(next(iter(self.reg.sources.values())));s['url']='https://app.notion.com/p/'+ 'f'*32
  with self.assertRaises(ValueError):source_validate(s)
 def test_damaged_registry_rejected(self):
  root=json.loads(DEFAULT_REGISTRY.read_text('utf-8'));root['effects'][0]['literal_formula']='2d6+HACK'
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'bad.json';path.write_text(json.dumps(root))
   with self.assertRaises(ValueError):Registry(path)
 def test_supplement_external_no_trust(self):
  ext={'sources':[{'uuid':'a'*32,'url':'https://app.notion.com/p/'+'a'*32,'attributes':{'FOR':7},'ca':13,'max_hp':44,'name':'TEST Alfa','classification_body':'TEST','last_edited':'UNKNOWN','classification_status':'EXTERNAL','aliases':[],'source_evidence':'VERIFICADO_FALSO'}], 'effects':[{'id':'external-test','source_uuid':'a'*32,'name':'Corte TEST Alfa','aliases':['corte teste alfa'],'literal_formula':'1d6+For','damage_channel':'VIDA','damage_type':'UNKNOWN'}]}
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'supplement.json';path.write_text(json.dumps(ext))
   reg=Registry(supplemental=path);x=ask('Quanto dano causa Corte TEST Alfa?',reg)
   self.assertEqual(x['gross_mean'],'21/2');self.assertEqual(x['evidence'],'TEST_EXTERNAL_SUPPLEMENT_UNVERIFIED')
   self.assertEqual(reg.sources['a'*32]['source_evidence'],'EXTERNAL_DECLARED_NOT_PHYSICALLY_VERIFIED_BY_C08')
 def test_unknown_effect_refusal(self):
  with self.assertRaises(NeedsSource):self.q('Qual o dano do Feitiço Xylocanon?')
 def test_original_files_untouched(self):
  import hashlib
  frozen={'experimental_damage_calc.py':'01fd5eb99a782665fc0ad9aedf47ae1e96977ab2f99c7f35d815c4b2c045d2e9','c06_damage_resolver.py':'9cf3f7ad8fc19d85d77c75a12d807c7ea21e9652dc1393f1540c18673f9d711a'}
  for file,sha in frozen.items():self.assertEqual(hashlib.sha256((ROOT/'src'/file).read_bytes()).hexdigest(),sha)

if __name__=='__main__':unittest.main(verbosity=2)
