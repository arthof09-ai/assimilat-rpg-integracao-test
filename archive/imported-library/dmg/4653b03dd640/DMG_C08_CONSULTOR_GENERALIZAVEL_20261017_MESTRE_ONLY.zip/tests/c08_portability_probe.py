#!/usr/bin/env python3
"""Copies current product to an unrelated temp path then exercises declared commands."""
import subprocess,shutil,tempfile,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
QUESTIONS=[
'Quanto dano causa o Arranhão Putrificador?',
'Quanto dano causa a Chifrada do Mamute Antigo?',
'Qual o dano da Mordida Necrótica?',
'Compare Arranhão Putrificador e Chifrada',
'Calcule 2d6+25, RD física 10 e Vida 40, como TEST',
'Explique o evento R157 BASIC, sequência 48',
'Turbilhão Cinzento contra Eristan',
]
with tempfile.TemporaryDirectory(prefix='dmgaudit-C08-NOT-ORIGINAL-',dir='/tmp') as d:
 t=Path(d)/'randomized_checkout'
 shutil.copytree(ROOT,t,ignore=shutil.ignore_patterns('__pycache__'))
 cmds=[[sys.executable,'src/c08_generalized.py',q] for q in QUESTIONS]+[
 [sys.executable,'-m','unittest','discover','-s','tests','-p','test_c08_generalized.py','-q'],
 [sys.executable,'-m','unittest','discover','-s','tests','-p','test_c07_consult.py','-q'],
 [sys.executable,'tests/c08_independent_oracle.py'],
 [sys.executable,'tests/c07_math_independent.py'],
 [sys.executable,'src/build_c08_demos.py']]
 res=[]
 for cmd in cmds:
  p=subprocess.run(cmd,cwd=t,capture_output=True,text=True,timeout=30)
  if p.returncode!=0:raise AssertionError('PORTABILITY_COMMAND_FAIL '+str(cmd)+' stdout '+p.stdout[-1000:]+' stderr '+p.stderr[-1000:])
  res.append({'command':cmd[1:],'returncode':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'stderr_tail':p.stderr[-120:]})
 result={'status':'PASS','environment':'fresh temp folder outside /mnt/data, recreated from current product, stdlib Python; no Notion/SQLite mutation','commands_ok':len(res),'command_records':res,'has_no_absolute_root_dependency':True,'preserved_sources':4,'new_effects':6,'legacy_effects':3}
 (ROOT/'qa/C08_PORTABILITY_FRESH_DIRECTORY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':'PASS','commands_ok':len(res),'test_suites':['C08 48','C07 27','independent 87','math C07 26'],'temporary_directory_deleted':True},ensure_ascii=False,indent=2))
