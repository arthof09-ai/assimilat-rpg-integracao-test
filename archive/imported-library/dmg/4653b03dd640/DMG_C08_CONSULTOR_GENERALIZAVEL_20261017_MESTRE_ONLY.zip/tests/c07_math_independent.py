#!/usr/bin/env python3
"""Independent math / source-contract auditor, not calling evaluator to generate expectations."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import hashlib,io,json,zipfile,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from c07_conversational import ask
checks=0

def ck(cond,label):
 global checks
 checks+=1
 if not cond:raise AssertionError(label)

def poly(dice_n,faces,offset):
 c=Counter({offset:1})
 for _ in range(dice_n):
  nextc=Counter()
  for v,n in c.items():
   for f in range(1,faces+1):nextc[v+f]+=n
  c=nextc
 return {v:F(cnt,faces**dice_n) for v,cnt in c.items()}

def exp(p):return sum((F(x)*v for x,v in p.items()),F(0))

# independent from c06 pmf, check exact moments, support and conditional integer rounding
wind=poly(9,10,8);physical=poly(8,8,47)
ck(sum(wind.values())==1,'total wind');ck(len(wind)==82,'wind support size');ck((min(wind),max(wind))==(17,98),'support endpoints');ck(exp(wind)==F(115,2),'wind mean');ck(exp(physical)==83,'physical mean');ck((min(physical),max(physical))==(55,111),'physical support');
ck(sum(F(v//2)*p for v,p in wind.items())==F(57,2),'floor half');ck(sum(F((v+1)//2)*p for v,p in wind.items())==29,'ceil half')
ck(sum(max(0,v-25)*p for v,p in physical.items())==58,'physical RD Eristan')
ck(max(range(4,25))<min(range(4+92,25+92)),'Eristan reflex strictly loses')
ck(min(range(6+166,37+166))>max(range(4+92,25+92)),'Auren reflex strictly wins')
# Recover C06 functional engine fingerprints from authenticated prior checkpoint,
# without requiring any fixed absolute path or an external dependency.
FROZEN={'experimental_damage_calc.py':'01fd5eb99a782665fc0ad9aedf47ae1e96977ab2f99c7f35d815c4b2c045d2e9','c06_damage_resolver.py':'9cf3f7ad8fc19d85d77c75a12d807c7ea21e9652dc1393f1540c18673f9d711a'}
for m,expected in FROZEN.items():
 ck(hashlib.sha256((ROOT/'src'/m).read_bytes()).hexdigest()==expected,'C06 frozen byte SHA unchanged '+m)
# compare consultation against independent oracle
v=ask('Turbilhão Cinzento de Feryn contra Eristan');ck(v['gross_expected']==F(115,2),'query wind average');ck(v['p_defender_exceeds']==0,'Eristan save probability');ck(v['rd'] is None,'no invented wind RD');ck(v['cost_PA']==60,'PA per cast');
v=ask('Turbilhão Cinzento de Feryn contra Auren');ck(v['p_defender_exceeds']==1,'Auren save prob');ck(v['half_bounds']['FLOOR_TEST']['hp_effective_expected']==F(57,2),'Auren floor half');ck(v['half_bounds']['CEIL_TEST']['hp_effective_expected']==29,'Auren ceil half');
v=ask('Presas de Feryn contra Eristan');ck(v['p_hit']==1,'physical hit vs CA');ck(v['expected_per_attempt_pre_or_post_RD']==58,'physical after RD');ck(v['cost_PA'] is None,'PA unknown');
a=ask('VLAB R157_TACTIC_BASIC_DEV_S997617 evento 48');ck(a['post']==a['hp']+a['overkill'],'native actual');ck(a['post']==73 and a['hp']==60 and a['overkill']==13,'native triple correction');
b=ask('VLAB R166_V2_CASULO_AOO_KO_DEV_S1205088 evento 5');ck(b['post']==114 and b['hp']==60 and b['overkill']==54,'native KO new cohort');
result={'status':'PASS','independent_checks':checks,'math_source':'Counter convolution independent of c06 PMF','wind_exact_expected':'115/2','auren_floor_expected':'57/2','auren_ceil_expected':'29','physical_after_RD25_expected':'58','C06_modules_unchanged':True,'limits':['not source classification adjudication','wind RD unknown','C06 phys crit intentionally excluded']}
(ROOT/'qa/C07_INDEPENDENT_MATH_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
