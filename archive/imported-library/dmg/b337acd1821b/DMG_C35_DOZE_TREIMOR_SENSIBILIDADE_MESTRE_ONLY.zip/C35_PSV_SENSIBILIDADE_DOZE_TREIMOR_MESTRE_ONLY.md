# PSV — C35 DMG: incerteza simbólica do dano (Do Ze e Lan Treimor) — MESTRE-ONLY / TEST

OP existente OP-DMG-CORPUS-EMP-01; DMG-RANK-01 v1.1 inalterada; Notion/Party/O Primeiro/VLAB NO-WRITE; writer Notion não comprovado. F0 formal 4/8 HOLD.

## Questão executada
Em vez de escolher silenciosamente versões incompatíveis, medi exatamente quanto as incertezas de salvaguarda, duração e modo podem alterar os resultados do dano, e se médias iguais escondem variâncias diferentes.

### Do Ze
Na página física de Do Ze, quatro blocos de versões O5/O2 repetem `9d8+INT (9d6+INT)` com `4d12` por tick condicionado e 20 PA. Um bloco B4 tem `3d6+INT` com `2d12` por tick e 3 PA. Esses são contextos de UMA página e não cinco experimentos independentes.

Defini apenas para **análise hipotética** `p=P(Fortitude bem-sucedida)`, `T=número de ticks após falha` e `I=INT`. Sob leitura de que salvar causa metade do dano primário e falhar causa dano primário mais `T` ticks, sem resistências e sem chance de acerto, a fórmula é:

`E_total(p,T,I) = (1 - p/2) * (μ_primário + I) + (1-p) * μ_tick * T`.

Para d8, μ_primário 40,5; para d6, 31,5; em ambos μ_tick 26; o delta entre as alternativas é `9*(1-p/2)` **em qualquer T**, se as demais hipóteses forem iguais. B4 tem μ_primário 10,5 e μ_tick 13, com PA3; não é automaticamente sua evolução ou versão equiparável a O5/O2.

Enumerei 150 combinações matemáticas (três ramos × dois I hipotéticos × cinco p hipotéticos × cinco T hipotéticos) com aritmética racional e verifiquei monotonicidade e diferença entre os dois pools. **p, T, CD, imunidade e aplicação de RD não foram comprovados**; não se afirma valor de dano real, TTK ou nova norma.

### Lan Treimor
A fonte física tem blocos distintos NORMAL e TRANSFORMAÇÃO. Comparei 8 fórmulas (principal e entre parênteses em Ataque e Pressão, normal/transformada). Nas fórmulas principais com 4d6, a transformação muda bônus fixo e preserva a variância. Entretanto, na expressão parentética de Ataque o normal registra `5d10+4d8+3d10+80` (μ=142, variância=87) e o transformado `5d10+4d8+132` (μ=177,5, variância=62,25): removem-se 3d10 da expressão transformada. A pressão parentética passa de μ=193 para 245 **mantendo o pool de dados e a variância**. Nenhuma regra da página autoriza interpretar as expressões entre parênteses como golpes somáveis às fórmulas principais, nem resolver a discrepância de nome Pan/Lan.

## Resultado e gate
150 combinações de Do Ze, 8 fórmulas Treimor, 390 verificações de não negatividade/monotonicidade, 50 verificações do delta entre pools e 8 asserções estruturais: **448 verificações locais PASS**. Não houve novo combate, nenhuma fonte canônica alterada. Trata-se de sensibilidade **MATH-ONLY**, não playtest. F0/F6/HOLD, D0 delimitado C34=848, nenhum efeito canônico promovido.

**FIRST-PENDING** F6 fonte original sem dano, com RE/FIP próprio, ação/custo e entrega; reconciliação por autoridade de Do Ze e Pan/Lan para uso em testes VLAB; A5 bytes ainda 0/7. Não repetir C32–C34 nem mascarar o conflito.
