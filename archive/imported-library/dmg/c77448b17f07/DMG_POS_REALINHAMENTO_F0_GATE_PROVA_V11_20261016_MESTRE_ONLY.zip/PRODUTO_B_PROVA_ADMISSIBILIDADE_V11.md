# PRODUTO B — APLICAÇÃO DMG-RANK v1.1: ADMISSIBILIDADE E TESTE MASCARADO

**MESTRE-SIDE — OP-DMG-CORPUS-EMP-01 — 16/10/2026.**

**RESULTADO NORMATIVO:** **0 fontes elegíveis entre sete grupos verificados/recuperados** para uma aplicação legítima da v1.1 em fonte originalmente **sem fórmula de dano** com RE/FIP e mecânica de entrega completa. Esta conclusão é limitada a esta busca dirigida, NÃO ao acervo inteiro. **RESULTADO TÉCNICO:** execução completa do procedimento de construção em uma **réplica TEST com dano removido artificialmente**, explicitamente diferente de uma fonte original sem dano.

## Matriz negativa individual

| ID | Fonte | Informação favorável | Bloqueio decisivo |
|---|---|---|---|
| ADM-01 | Martelo do Portão Faminto | Ouro Negro/Média; Impacto, corpo a corpo, ação Padrão, custo 0 ataque básico, alvo 1 | **BLOCKED_EXPLICIT_DAMAGE** — Fórmula explicitada possui precedência sobre DMG-RANK; clone mascarado não vira fonte original sem dano |
| ADM-02 | Manopla do Trovão Cativo | Ouro/Entrada; Raio, depois de acerto, +22 PA, 1/8h, sem ação extra, rider -3m | **BLOCKED_EXPLICIT_DAMAGE** — Não reclassificar rider como dano ausente; fonte já define dano |
| ADM-03 | Orbe da Palavra Guardada | Ouro/Entrada; Ação Padrão captação10PA e reprodução5PA, raio de escuta, 0 dano | **BLOCKED_NONOFFENSIVE** — FIP de objeto não implica efeito ofensivo; gerar dano seria inventar |
| ADM-04 | Guardião Verde / Sopro Vital | RN Prata3, RE/FIP não definidos; Revitalização, não ataque, custo e alvo insuficientes | **BLOCKED_NONOFFENSIVE_AND_RE_MISSING** — Rank nominal da Besta não autoriza RE; habilidade é benéfica |
| ADM-05 | Behemoth Glacial / Sopro Congelante | RN Ouro1, RE/FIP não definidos; Gelo, 10PA, CD 6+INT, congelamento hard-control, ação/alcance não fixados | **BLOCKED_MISSING_RE_FIP_DELIVERY** — Mecânica de congelamento, duração, alvo, ação, chance e orçamento dependem da fonte |
| ADM-06 | Dracoterra / Sopro de Dragão | Título Ouro4/corpo Ouro; RE/FIP ausentes; Sopro área, custo, geometria/ação/alvo ausentes | **BLOCKED_CLASSIFICATION_AND_DELIVERY** — Risco de duplicar orçamento em múltiplos alvos; rank da besta não é RE |
| ADM-07 | Grupo Bestas Ouro5/ON1/L1 anterior | Título/corpo/ancestral conflitantes; 23/24 sem fórmula completa; delivery ausente em muitas | **BLOCKED_UNRESOLVED_CONTEXT** — Não repetir a leitura das 24 páginas nem reivindicar 24 novos casos neste ciclo |

**Requisitos de admissão em fonte realmente sem dano:** (1) é ofensiva; (2) não possui dano vigente escrito; (3) RE do efeito validado pela fonte competente, não pelo RN do dono; (4) FIP validado por comparadores/autoridade; (5) natureza física/elemental; (6) ação; (7) alcance/alvo/área; (8) custo PA/Alma; (9) controle/rider; (10) duração, salvaguarda, condição e frequência conforme o tipo; (11) fonte/ver­são/hierarquia sem conflito material. A ausência isolada de número não autoriza preencher tudo por imaginação.

## Controle positivo de engenharia: Martelo do Portão Faminto

Fonte real: https://app.notion.com/p/3f5c2b324ede81658982d8f47b3ad647.

- **Original (preservado):** arma Ouro Negro, FIP interna **Média**, dano explícito do golpe comum `8d10+12`, DME 56, tipo físico Impacto, corpo a corpo, **Ação Padrão**, sem PA adicional para ataque comum. Dano adicional de demolição contra estruturas é um ramo separado e já possui fórmula própria.
- **TEST-EPISTÊMICO:** numa cópia **local**, o campo de dano explícito foi temporariamente ocultado. Nenhuma página original/Notion foi editada. RE/FIP permanecem da própria fonte; a cópia não ganha legitimidade para o original.
- **Aplicabilidade só do TEST:** DMG-RANK-01 v1.1, Ouro Negro Média, alvo único, ação Padrão, sem hard-control/bypass do ataque comum → orçamento **DME 59–69**. Escolha ilustrativa `11d10` = 60,5. A norma não impõe essa expressão específica; `5d12+28` também tem DME 60,5, porém outra variância. Nenhuma é dano canônico.
- **Bônus externos:** nenhum foi imputado. FOR/FF/títulos/estados somente se a ficha portadora e a regra permitirem, fora do DME intrínseco.
- **Defesa:** as linhas RD5/15/25/35/60/75 correspondem a **cenários condicionais de RD física** sob fonte especializada para Bestas; não pressupõem que a habilidade acertou nem que há fixture de ator/terreno.
- **Probabilidade de acerto:** INDETERMINADA por falta de ator/ataque válido, iniciativa, reação, alcance situacional e defesa. Dano por tentativa e probabilidade de vitória não foram calculados.

## Distribuições exatas comparáveis

| Fórmula | Origem | DME bruto | RD25: média líquida | RD35: média líquida | RD60: média líquida | P(líquido positivo) RD60 |
|---|---|---:|---:|---:|---:|---:|
| `8d10+12` | Original explícito, somente-leitura | 56.000 | 31.000007 | 21.008115 | 1.636840 | 29.302% |
| `11d10` | TEST artificial | 60.500 | 35.500052 | 25.507773 | 4.070098 | 50.000% |
| `5d12+28` | TEST artificial | 60.500 | 35.500000 | 25.500028 | 3.364069 | 50.000% |

**Interpretação:** um DME dentro da banda não determina um número único de dados. Mesmo `11d10` e `5d12+28` tendo DME idêntico, acima de RD60 o dano líquido esperado muda. Não use média isolada para substituir a fórmula explícita.

## Negativos que impedem falsos PASS

- Martelo e Manopla com dano explícito → v1.1 **não substitui** o original.
- Orbe da Palavra Guardada e Guardião Verde: efeito não ofensivo → dano **não gerado**, mesmo com classe de item.
- Behemoth Glacial / Sopro Congelante: informa RN Ouro 1, custo10PA e CD, mas falta RE/FIP e contrato de controle → indeferido.
- Dracoterra / Sopro de Dragão: título/corpo pouco específico e área não contratada, RE/FIP e custo ausentes → indeferido.
- Tipos elementais diferentes não herdam RD física sem fonte; cenários de Raio/Planta não foram artificialmente tratados como Impacto.
- Nenhum evento nativo VLAB ou combate de campanha foi produzido para esta prova.

**PRÓXIMO PONTO EXATO:** buscar UMA definição ofensiva sem dano numérico com RE/FIP certificados, possivelmente em nova família item/magia/efeito; se RE/FIP da fonte não existe, encaminhar classificação ao mecanismo competente, não ao DMG para inventar. Registrar snapshot e executar a v1.1 em TEST só depois da admissão.

**Arquivos reproduzíveis:** `src/DMG_GATE_V11_MODEL.py`, `src/INDEPENDENT_AUDIT_GATE_V11.py`, `results/PROVA_B_ADMISSIBILIDADE.json`, `results/PROVA_B_TEST_MASCARADO_RESULTADOS.json`.
