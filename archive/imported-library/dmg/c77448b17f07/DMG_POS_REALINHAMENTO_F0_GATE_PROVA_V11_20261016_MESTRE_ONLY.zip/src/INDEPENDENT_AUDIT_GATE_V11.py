#!/usr/bin/env python3
"""Independent arithmetic oracle via bounded-composition inclusion/exclusion.
Does NOT import primary convolution model. This is an independent algorithm,
NOT an independent human codification or a VLAB-native audit.
"""
import csv,hashlib,json,math,pathlib,zipfile,collections
from fractions import Fraction
P=pathlib.Path(__file__).resolve().parents[1];R=P/'results';tests=[]
def check(label,condition):
 tests.append({'id':label,'pass':bool(condition)})
 if not condition:raise AssertionError(label)
def load(name):return json.loads((R/name).read_text(encoding='utf8'))
def ways(n,f,s):
 # number of ordered n-rolls in [1,f] whose sum is s; stars-and-bars, exclusion.
 t=s-n
 if t<0:return 0
 return sum(((-1)**k)*math.comb(n,k)*math.comb(t-k*f+n-1,n-1) for k in range(min(n,t//f)+1) if t-k*f>=0)
def die_summary(n,f,add,rd):
 m={x+add:ways(n,f,x) for x in range(n,n*f+1)}
 check(f'positive_roll_weights:{n}d{f}+{add}',all(v>0 for v in m.values()))
 check(f'partition_of_rolls:{n}d{f}+{add}',sum(m.values())==f**n)
 total=f**n
 return Fraction(sum(max(0,x-rd)*w for x,w in m.items()),total),Fraction(sum(w for x,w in m.items() if x>rd),total),Fraction(sum(x*w for x,w in m.items()),total)
asserts=load('PROVA_B_TEST_MASCARADO_RESULTADOS.json')
var={'11d10':(11,10,0),'5d12+28':(5,12,28),'8d10+12':(8,10,12)}
for y in asserts['numeric_output']:
 n,f,add=var[y['formula']]
 net,p,gross=die_summary(n,f,add,y['RD'])
 check('DME '+y['formula']+' RD'+str(y['RD']),str(gross)==y['gross_DME_fraction'])
 check('NET '+y['formula']+' RD'+str(y['RD']),str(net)==y['mean_after_RD_fraction'])
 check('POS '+y['formula']+' RD'+str(y['RD']),str(p)==y['P_positive_fraction'])
check('band ON Media 11d10 valid',59<=float(die_summary(11,10,0,0)[2])<=69)
check('original explicit not overwritten',asserts['source_official_formula']=='8d10+12' and 'Explicit' in asserts['why_actual_source_not_admissible'])
# Contract checking independent source screen
ad=load('PROVA_B_ADMISSIBILIDADE.json');check('seven candidate groups',len(ad['candidates'])==7)
check('no strict actual source passes',all(x['status'].startswith('BLOCKED') for x in ad['candidates']) and ad['strict_actual_source_admitted_count']==0)
check('Orbe rejects nonoffensive',any('Orbe' in x['name'] and 'NONOFFENSIVE' in x['status'] for x in ad['candidates']))
check('two existing numeric sources preserved',sum('EXPLICIT_DAMAGE' in x['status'] for x in ad['candidates'])==2)
# F0 trace contracts: historical unchanged, new hashes 7/7 but no claimed freeze
f0=load('F0_OITO_REQUISITOS_CROSSWALK.json');fp=load('SOURCE_FINGERPRINTS_NOTION.json');check('F0 eight operational rows',len(f0['items'])==8)
check('F0 no false formal promotion',f0['after']['F0_documental'].startswith('4/8'))
check('seven authority fingerprint rows',len(fp['sources'])>=7)
check('full_source_text_not_archived',fp['full_utf8_text_archived'] is False)
for x in fp['sources']:
 check('sha256:'+x['name'],len(x['content_utf8_sha256'])==64 and all(c in '0123456789abcdef' for c in x['content_utf8_sha256']))
check('two edited post historical baseline',len(fp['last_edited_baseline_drift'])==2)
ph=load('MATRIZ_ATIVACAO_19_FASES.json');check('phases 19',len(ph['phases'])==19);check('phases unique',len(set(z['phase'] for z in ph['phases']))==19)
E=load('MATRIZ_E01_E24.json');check('E24',len(E['items'])==24)
t=load('MATRIZ_8_GATES_TRANSVERSAIS.json');check('eight transversal',len(t['items'])==8)
# VLAB CSV fully independent read, with physical original hash and scenes/actors.
p=P/'evidence_readonly'/'DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv';z=P/'evidence_readonly'/'VLAB_R62_R71_COMBATES_POTENCIA_DANO_MESTRE_ONLY.zip'
check('csv original sha',hashlib.sha256(p.read_bytes()).hexdigest()=='f8996f7d3953d83e50b90faf612d7ac037df9ecc15d14238e59ca6ab20760f63')
check('zip original sha',hashlib.sha256(z.read_bytes()).hexdigest()=='8991c76284dcbfbc04f17aafa20e4d7916ba5b4d442c0c633276e7c3a2223cb3')
with zipfile.ZipFile(z) as zh:
 check('zip 96 entries',len(zh.infolist())==96)
 check('zip CRC',zh.testzip() is None)
with p.open(newline='',encoding='utf8') as file:rows=list(csv.DictReader(file))
check('684 receipts',len(rows)==684)
check('12 scenes',len(set(x['scene_run_id'] for x in rows))==12)
check('3 actor sources',len(set(x['source_page_id'] for x in rows))==3)
check('row uniqueness',len({(x['scene_run_id'],x['event_seq'],x['attack_subindex']) for x in rows})==684)
check('no campaign events',all(x['official_campaign_event']=='False' for x in rows))
check('no damage on miss',all(int(x['damage_gross'])==0 if x['hit']=='0' else True for x in rows))
check('postRD loss never above potential',all(int(x['actual_hp_loss'])<=int(x['damage_after_rd_potential']) for x in rows))
co=collections.Counter(x['cohort'] for x in rows)
check('R62 exploratory 346',co['R62_EXPLORATORY']==346)
check('R68 paired 338',co['R68_V2_PAIRED']==338)
check('Feryn R68 188 hits 188',sum(x['hit']=='1' for x in rows if x['cohort']=='R68_V2_PAIRED' and x['attacker_name']=='Sikong Feryn')==188)
check('other R68 0 hits',sum(x['hit']=='1' for x in rows if x['cohort']=='R68_V2_PAIRED' and x['attacker_name']!='Sikong Feryn')==0)
res={'independent_method':'bounded composition via inclusion-exclusion, no primary-model imports','not_independent_human_second_coder':True,'all_pass':all(x['pass'] for x in tests),'checks':len(tests),'checks_detail':tests}
(R/'INDEPENDENT_AUDIT_GATE_V11.json').write_text(json.dumps(res,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
print('AUDIT',len(tests), 'PASS')
