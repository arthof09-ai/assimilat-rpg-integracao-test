import pathlib,hashlib,json,zipfile,datetime
P=pathlib.Path(__file__).resolve().parents[1]
package='DMG_POS_REALINHAMENTO_F0_GATE_PROVA_V11_20261016_MESTRE_ONLY.zip'
include=[x for x in P.rglob('*') if x.is_file() and 'library_readback' not in str(x) and x.name not in (package,'MANIFEST_SHA256.json','LIBRARY_PERSISTENCE_RECEIPT.md') and '/evidence_readonly/VLAB_R62_R71_COMBATES_POTENCIA_DANO_MESTRE_ONLY.zip' not in str(x)]
include=sorted(include,key=lambda x:str(x.relative_to(P)))
manifest={'checkpoint':'POST-SYSTEMIC-REALIGN-F0-V11-20261016','as_of':'2026-10-16','operation':'CM-000001 / OP-DMG-CORPUS-EMP-01','status':'LAB_MATH_PASS; F0_HOLD; CANONICAL_HOLD','source_archive':'VLAB ZIP R62–R71 recovered physically but original NOT duplicated in this package; remains in VLAB Library','sources':{'DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv':{'location':'/Comestre/OP-VLAB-FUSION-SANDBOX-01/DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv','sha256':'f8996f7d3953d83e50b90faf612d7ac037df9ecc15d14238e59ca6ab20760f63'},'VLAB_R62_R71_COMBATES_POTENCIA_DANO_MESTRE_ONLY.zip':{'location':'/Comestre/OP-VLAB-FUSION-SANDBOX-01/VLAB_R62_R71_COMBATES_POTENCIA_DANO_MESTRE_ONLY.zip','sha256':'8991c76284dcbfbc04f17aafa20e4d7916ba5b4d442c0c633276e7c3a2223cb3'}},'entries':[]}
for f in include:
 b=f.read_bytes();manifest['entries'].append({'name':str(f.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(P/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
with zipfile.ZipFile(P/package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zh:
 for f in include+[P/'MANIFEST_SHA256.json']:
  zh.write(f,str(f.relative_to(P)))
path=P/package
with zipfile.ZipFile(path) as zh:
 assert zh.testzip() is None
 assert len(zh.namelist())==len(include)+1
 for x in manifest['entries']:
  data=zh.read(x['name']);assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
print(json.dumps({'zip':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'zip_bytes':path.stat().st_size,'files_included':len(include)+1,'manifest_members':len(include),'crc':'PASS','member_integrity':'PASS'},ensure_ascii=False,indent=2))
