# PRODUTO A — MATRIZ DE ATIVAÇÃO E AVANÇO DO PLANO SUPREMO

**MESTRE-SIDE — OP-DMG-CORPUS-EMP-01 — 16/10/2026.**

**Estado ANTES:** F0 = **4/8 marcos documentais reportados**; 19/19 fases do plano existentes, 24/24 garantias especificadas e oito subgates transversais; zero atualização normativa v1.1. **Estado DEPOIS:** F0 = **4/8 formalmente**, com **novo fingerprint atual do corpo de 7/7 autoridades-base e 4 fontes-candidatas**. Nenhuma nova certificação formal foi reivindicada. A etapa F0-A5 obteve um artefato verificável de hashing, porém faltam snapshots integrais dos bytes, blind-review e writer para ratificação.

**Atenção à taxonomia dos oito:** a documentação Notion informa o agregado `4/8`, mas não enumera uma tabela canônica A1–A8 com correspondência inequívoca a quatro PASS individuais. A enumeração abaixo é **CROSSWALK OPERACIONAL PARA AUDITORIA**, não regra nova nem declaração retroativa de oito certificados. O estado das quatro primeiras linhas é reconstrução de documentação existente, NÃO nova aprovação independente.

## Oito componentes F0 — escopo, autoridade e próxima ação

| Unidade | Critério | Estado DEPOIS | Fonte | Menor pendência |
|---|---|---|---|---|
| F0-A1 | Execução autorizada; baseline v1.1 e não-interferência congelados | **DOCUMENTADO_HISTORICO** | F0 + OP; ordem Mestre posteriores | Reabrir fonte baseline ao aplicar; sem writer normativo |
| F0-A2 | Sete autoridades basais indexadas, RN separado de RE/FIP | **DOCUMENTADO_HISTORICO** | DMG-F0-PREREG-01 | Reconciliar versões posteriores e fonte oficial de cada fixture |
| F0-A3 | Pré-registro Q1–Q4, H1–H4 e critérios de inclusões sem extrapolação | **DOCUMENTADO_HISTORICO** | DMG-F0-PREREG-01 + DMG-METHOD-EMP-01 | Amostra confirmatória cega não executada |
| F0-A4 | Protocolo comparativo ANTES/DEPOIS aprovado; matriz teórica 1875 | **DOCUMENTADO_HISTORICO** | SIM-DMG-PAIRED-01 + DMG-QA-ACCEPT-01 | Sem fixtures completos para liberar coorte produtiva |
| F0-A5 | Fingerprint completo, versionamento e snapshot de fontes por fixture | **PARCIAL** | F0: SOURCE-SNAPSHOT-CERTIFIED=NO; E09/E23 | Salvar bytes imutáveis do texto exato e obter readback independente; quem mudou exige versão própria |
| F0-A6 | Mapa estrutural e denominadores de superfícies/acessos | **PENDENTE** | EXT E02–E04; OP D0–D9 | Enumerar raízes e acessos autorizado; registrar inaccessible; D0 global |
| F0-A7 | Holdout por entidade/família pré-fixado e não contaminado | **PENDENTE** | F0/QA; EXT E01/E19 | Pré-registrar IDs de famílias não usadas antes de ajuste v2 e preservar selagem |
| F0-A8 | Verificação de escritor/instância e segunda codificação independente | **PENDENTE** | OP F0; BOOTSTRAP/NAC-CONT; EXT E06/E07 | Confirmar identidade/claim+writer para gravação; segundo agente independente para blind-review |

**Primeiro ponto técnicamente fechável:** F0-A5, não F1/F13. Antes desta rodada não havia uma tabela verificável dos SHA-256 contemporâneos dos sete corpos de autoridade indexados por F0. Agora essa tabela existe, com ID, tamanho textual, última edição e digest SHA256 calculados diretamente do `<content>` entregue pelo Notion. Entretanto o digest NÃO arquiva o texto original nem comprova conteúdo de arquivos binários/subpáginas; portanto `SOURCE-SNAPSHOT-CERTIFIED` continua **NÃO**.

**Revisão temporal importante:** Criação de Ficha e Transformação Espiritual foram atualizadas após as datas de F0/08-10. **Não** assumir que os hashes atuais representam o baseline antigo sem uma captura íntegra daquele estado.

## Matriz F0–F18 (19 fases existentes)

| Fase | Função | Estado verificável desta rodada | Principal pendência | VLAB indispensável agora? |
|---|---|---|---|---|
| F0 | Preflight/writer/freeze | ATIVA-PARCIAL | Completar freeze integral, raízes, holdout, second coder e gate writer | Não |
| F1 | Discovery D0 | PARCIAL-EXPLORATÓRIO | D0 global e raiz física+exclusões | Não |
| F2 | Dedup/lineage | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F3 | Extração forense | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F4 | Normalização | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F5 | Taxonomia | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F6 | RE/FIP/RN/RI | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F7 | Dossiês tipo×rank | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F8 | Estatística robusta | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F9 | Matched pairs / entrega | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F10 | Fronteiras RN | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F11 | Benchmarks | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F12 | Vieses | EVIDÊNCIA-PARCIAL-SEM-GATE-TERMINAL | F0 + census e elegibilidade por família | Não |
| F13 | Candidata v2 | NÃO_INICIADA | Sequência científica F0–F12 e gates aplicáveis | Não |
| F14 | Regressão | NÃO_INICIADA | Sequência científica F0–F12 e gates aplicáveis | Não |
| F15 | Stress | NÃO_INICIADA | Sequência científica F0–F12 e gates aplicáveis | Não |
| F16 | Playtest | NÃO_INICIADA | Sequência científica F0–F12 e gates aplicáveis | Sim (posterior) |
| F17 | Revisão Mestre/NAC | NÃO_INICIADA | Sequência científica F0–F12 e gates aplicáveis | Não |
| F18 | Migração dirigida | NÃO_INICIADA | Sequência científica F0–F12 e gates aplicáveis | Não |

A evidência matemática da DMG pode ser usada em F4/F8/F9 e a amostra VLAB R71 em F6/F8/F12, mas nenhuma dessas contribuições substitui o gate de fase. F1 teve leituras piloto posteriores ao registro inicial; não reivindicar censura global nem recontar as mesmas páginas.

## Oito subgates transversais aprovados

| Subgate | Situação |
|---|---|
| EVIDENCE-COVERAGE | PENDENTE: raiz e D0 global |
| SOURCE-LINEAGE | PARCIAL: IDs e versões locais; lotes L003 não reconciliados |
| CODEBOOK | PENDENTE: second coder real |
| MATH-REPLAY | PASS LOCAL apenas: modelo e auditor, NÃO corpus |
| DEFENSE-ECOLOGY | PARCIAL: RD e CA em coortes reais/nativas, 3 atores |
| OUT-OF-SAMPLE | PENDENTE: nenhum holdout cego confirmatório |
| EXPLOIT-REDTEAM | PARCIAL: redteam histórico e negativos atuais |
| CHANGE-SAFETY | PASS preservacional local; sem canônico |

## Vinte e quatro garantias aprovadas (E01–E24)

| Item | Requisito | Crédito empírico nesta rodada |
|---|---|---|
| E01 | Pré-registro antes de F1 | EVIDÊNCIA PARCIAL |
| E02 | Censo de superfície e inacessíveis | PENDENTE |
| E03 | Busca independente em quatro vias | PENDENTE |
| E04 | Cobertura proporcional com denominador | PENDENTE |
| E05 | SOURCE/DEFINITION/OCCURRENCE/EFFECT/COMPONENT | EVIDÊNCIA PARCIAL |
| E06 | Segunda leitura de classificação realmente independente | PENDENTE |
| E07 | Métrica de concordância/adjudicação | PENDENTE |
| E08 | Negativos e fronteiras sem dano | EVIDÊNCIA PARCIAL |
| E09 | Versão/autoridade temporal | EVIDÊNCIA PARCIAL |
| E10 | Confiança propagada | EVIDÊNCIA PARCIAL |
| E11 | Distribuição matemática exata | EVIDÊNCIA PARCIAL |
| E12 | Magnitude, acerto e mitigação separados | EVIDÊNCIA PARCIAL |
| E13 | Economia temporal de ações e recursos | EVIDÊNCIA PARCIAL |
| E14 | Crítico/fraqueza/FF: aplicação correta | EVIDÊNCIA PARCIAL |
| E15 | Matriz de alvos e defesas por rank | EVIDÊNCIA PARCIAL |
| E16 | Eficiência além de DME | EVIDÊNCIA PARCIAL |
| E17 | Contrafactuais e metamórficos | EVIDÊNCIA PARCIAL |
| E18 | Red team de exploração | EVIDÊNCIA PARCIAL |
| E19 | Holdout por família lacrado | PENDENTE |
| E20 | Células esparsas e incerteza | EVIDÊNCIA PARCIAL |
| E21 | Análise de sensibilidade | EVIDÊNCIA PARCIAL |
| E22 | Matriz reversível de decisão e impacto | PENDENTE |
| E23 | Pacote paper+dataset+testes reproduzível | PASS LOCAL DE REPRODUTIBILIDADE NESTA ENTREGA; GATE GLOBAL PENDENTE |
| E24 | Gate anti-infinito/continuidade proporcional | EVIDÊNCIA PARCIAL |

Nenhuma garantia se torna terminal simplesmente por ter sido escrita; E23 recebeu um pacote local reproduzível, não um PASS do plano global. A revisão humana independente E06/E07 permanece pendente: a segunda implementação matemática deste ciclo não equivale a segundo codificador cego.

## Critérios de avanço e governança

1. **Primeira ação fechável:** congelar snapshot físico de conteúdo completo para as sete autoridades e cada fixture com URL/last-edit/hash, preservando as duas derivações temporais B1.1+. Reabrir e verificar por outra instância quando competente.
2. Enumerar raízes e inacessíveis para um D0 defensável, sem reabrir R02–R04/24 páginas já lidas apenas para gerar volume.
3. Pré-registro e selagem de holdout por família antes de ajustar coeficientes, e segunda codificação independente; manter bloqueio se não houver segunda instância.
4. Provar Assignment/INSTANCE-ID e writer/lease/epoch/collision para gravar no Notion; sem isso, esta entrega permanece na Biblioteca autorizada.
5. Reconciliar F0 com QA/LONG antes de alegar `5/8`; F0 `4/8` fica inalterado até readback do gate competente.

**D0–D9:** sem denominadores globais inventados; D0 páginas, D1 efeitos, D2 componentes, D3 vigentes, D4 históricos, D5 PS, D6 conflitos, D7 sem rank, D8 não resolvidos, D9 espelhos excluídos. Eventos VLAB e variantes TEST não ampliam páginas/espécies únicas.

**Fonte principal:** OP, DMG-F0-PREREG, QA, EXT, LONG-RUN; hashes de corpo em `results/SOURCE_FINGERPRINTS_NOTION.json`.
