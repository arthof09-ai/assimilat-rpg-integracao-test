# PSV / HANDOFF — DMG PÓS-REALINHAMENTO E GATES DO PLANO SUPREMO

**AS-OF:** 2026-10-16 • **OPERATION:** CM-000001 / OP-DMG-CORPUS-EMP-01 • **BASELINE:** DMG-RANK-01 v1.1 oficial INALTERADA.

## Resultado verificável ANTES → DEPOIS

| Objeto | ANTES | DEPOIS verificado | Terminal? |
|---|---|---|---|
| F0 documental | 4/8 históricos | 4/8 históricos; nenhuma nova aprovação inventada | NÃO |
| Fingerprint das 7 fontes basais | sete indexadas, `SOURCE-SNAPSHOT-CERTIFIED=NO`, sem tabela hash | sete corpos Notion com SHA256/versão registrados; duas mudanças de data frente à abertura F0 | PARCIAL LOCAL |
| Phases F0–F18 | 19 planejadas | 19 crosswalks com evidências e lacunas sem renumerar | matriz pronta, fases não certificadas |
| Garantias E01–E24 | 24 aprovadas | 24 mapeadas aos estados de evidência | nenhuma terminal nova |
| Subgates transversais | oito aprovados | oito descritos com estados e pendências | nenhuma certificação global |
| Fonte originalmente sem dano com RE/FIP+contexto | desconhecida | sete grupos triados, 0 elegíveis completos no escopo | BUSCA NEGATIVA, não impossibilidade global |
| Procedimento em réplica TEST | anterior não para ausência de dano | uma réplica mascarada, duas variantes exatas (21 cenários), fonte original intacta | PASS somente demonstração matemática |
| VLAB R71 (IBX-103) | encaminhado pela Coordenação | CSV + ZIP recuperados com SHA/CRC, 684 linhas/12 cenas/3 atores | insumo, não certificação VLAB |

## PRODUTO A — avanço do Plano Supremo

- `PRODUTO_A_MATRIZ_ATIVACAO_PLANO_SUPREMO.md` e quatro matrizes JSON completas: 19 fases; oito correspondências operacionais F0; 24 garantias; oito transversais.
- **Primeiro requisito F0 fechável:** F0-A5, congelamento de fontes e fingerprints. **Trabalho útil realizado:** hash íntegro da representação textual das sete autoridades; a duas versões recentes não podem ser confundidas com o congelamento histórico original. **Pendência:** bytes integrais imutáveis, readback independente, retenção, claim de escrita/lease para registrar formalmente. Nenhum novo F0 PASS.
- O mapa D0–D9 global não foi inventado; 0/71 Lote003 individual autenticado segundo checkpoint anterior, 0/9 CSV I0003 originais; não reabrimos 47 CSV/114 ZIP sem novo identificador.
- `4/8` é referência histórica documental; oito IDs A1–A8 são **crosswalk analítico**, não certidões canônicas descobertas com numeração oficial. Sem segunda auditoria humana, não adjudicar individualmente PASS.

## PRODUTO B — prova v1.1

- **0 fonte real estritamente elegível entre 7 grupos pesquisados**; matriz negativa por fonte em `PRODUTO_B_PROVA_ADMISSIBILIDADE_V11.md`. Isso NÃO é ausência de habilidade sem dano no RPG inteiro.
- **Controle técnico válido:** Martelo do Portão Faminto, Ouro Negro Média, ataque de Impacto, Ação Padrão, alvo único; fonte original já possui `8d10+12`. No **TEST** apenas, ocultar o campo de dano gera banda 59–69, e `11d10` DME60,5 é expressão admissível **ao TEST**, não revisão da arma original.
- Dano, chances pós-RD e P(dano positivo) enumerados por distribuição exata e verificados por segundo ALGORITMO de inclusão-exclusão. A fonte real nunca foi editada.
- Acerto/TTK/combate não computáveis sem ator e contratos próprios.

## IBX-103 / VLAB R71 — aproveitamento estritamente científico

**Arquivo real:** `DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv`, SHA256 `f8996f7d3953d83e50b90faf612d7ac037df9ecc15d14238e59ca6ab20760f63`, 368.949 bytes.

**Replay:** `VLAB_R62_R71_COMBATES_POTENCIA_DANO_MESTRE_ONLY.zip`, SHA256 `8991c76284dcbfbc04f17aafa20e4d7916ba5b4d442c0c633276e7c3a2223cb3`, 96 membros, CRC PASS.

- 684 recibos, 380 acertos e 304 erros, 12 cenas, **três NPCs ON5**. R62: 346 tentativas/192 acertos; R68: 338 tentativas/188 acertos.
- Na coorte R68, 188/188 ataques de Feryn acertaram; Varok 0/55, Arveth 0/95. As três fontes-propostas têm perfis de bônus/CA díspares.
- Não projetar porcentagens como taxa populacional por classe, nem afirmar igualdade causal entre políticas quando a trajetória do RNG mudou. A perda total de Vida relatada pode ser limitada pela Vida remanescente do alvo; não usar soma de recibos como soma de dano potencial da fórmula.
- Evidência **complementar** de F6/F8/F12, sem converter combates em 684 criaturas, sem executar/adjudicar VLAB.

## Validação e limites

- Algoritmo A: convolução de polinômios inteiros para distribuição ndfixo. Algoritmo B: contagem exata de composições limitadas por inclusão-exclusão, **sem importação do A**.
- Auditoria independente algorítmica passa, **não equivale a segundo agente humano cego de E06/E07**.
- Fonte e arquivo SHA/CRC devem ser reabertos por sucessor antes de novas afirmações. Não mudar DMG-RANK v1.1.
- Nenhuma escrita a Notion Mestre/Party/O Primeiro, motor VLAB ou páginas canônicas. Não se registrou ACK em nome de INSTANCE-ID não comprovada.

## FAST RESUME: ponto exato

1. Reabrir OP/F0/QA/EXT/LONG e confirmar que nenhuma unidade posterior foi certificada.
2. Confirmar ZIP aqui arquivado, manifesto, hashes e `INDEPENDENT_AUDIT_GATE_V11.json`.
3. F0-A5: capturar snapshots integrais UTF8 das sete autoridades, resolver duas diferenças temporais, readback por segunda instância.
4. F0-A6/A7/A8: root map e inacessíveis, prelock holdout por família, writer/lease/second coder reais.
5. Prova B: procurar fonte ofensiva com dano AUSENTE e RE/FIP+entrega realmente competentes; não mascarar origem real para alegar elegibilidade.

**NAC-PASS local:** integridade matemática/testes e arquivos locais PASS. **NAC-PASS formal F0/produção/canônico:** HOLD. Sem 100% global ou v2.
