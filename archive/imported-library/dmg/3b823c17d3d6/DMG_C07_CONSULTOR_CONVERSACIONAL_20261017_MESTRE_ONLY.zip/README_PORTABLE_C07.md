# DMG C07 — Consultor Conversacional de Dano (MESTRE-SIDE)

**OP:** `OP-DMG-CORPUS-EMP-01` — continuação C06. **Baseline:** DMG-RANK-01 v1.1 (não alterada). **F0:** 4/8. **Release:** somente ferramenta científica local, não integração canônica nem motor VLAB.

## Uso principal (dentro do ChatGPT, sem terminal)

O Mestre pode perguntar diretamente neste chat ou em uma sucessão que recupere este pacote:

- **Consulta A:** “Quanto dano o Turbilhão Cinzento de Feryn causa contra Eristan? E contra Auren?”
- **Consulta B:** “Compare Presas da Noite e Turbilhão de Feryn contra Eristan. Qual entrega mais dano por tentativa, considerando RD e PA?”
- **Consulta C:** “Explique o evento VLAB R157_TACTIC_BASIC_DEV_S997617, sequência 48” (coorte R162) ou “Explique R166_V2_CASULO_AOO_KO_DEV_S1205088, evento 5” (coorte R169).
- Perguntas adicionais: “Turbilhão de Feryn contra Auren, Vida 20, RD Vento 3” é cenário **TEST**, não afirma RD oficial.

**O consultor é um protocolo + biblioteca Python reutilizada pelo Comestre para responder no ChatGPT.** Este arquivo não implanta um plugin nem uma integração always-on. Em novo chat, recupere o pacote e carregue as fontes antes de responder.

## Recuperação portátil

1. Extraia este ZIP em qualquer diretório local (sem assumir `/mnt/data/dmg_succession/cycle7`).
2. Python 3.10+ padrão, sem bibliotecas externas:

```bash
python src/c07_conversational.py 'Quanto dano Turbilhão Cinzento de Feryn contra Eristan?'
python src/c07_conversational.py 'Compare Presas e Turbilhão contra Eristan'
python src/c07_conversational.py 'VLAB R157_TACTIC_BASIC_DEV_S997617 evento 48'
python src/c07_conversational.py 'VLAB R166_V2_CASULO_AOO_KO_DEV_S1205088 evento 5'
python src/c07_conversational.py 'Qual total coorte R169 VLAB?' --json
python -m unittest discover -s tests -p 'test_c07_consult.py' -v
```

3. Recalcular demonstrações `python src/build_c07_demos.py` (atualiza apenas artefatos da cópia experimental).
4. A auditoria nativa exige **ZIP R170 original externo**, não embutido de 15 MB; se não estiver disponível, emitir DEPENDENCY_REQUIRED, não afirmar readback físico:

```bash
python tests/c07_independent_audit.py --vlab-zip /caminho/EXATO/VLAB_R161_R170_RECEIPTS_TEMPORAL_CROC_ED_CORRECTED_MESTRE_ONLY.zip --out qa/audit_from_original.json
```

O C06 original, quando exigido para regressão matemática independente, deve ser fornecido explicitamente. Os dois módulos C06 `experimental_damage_calc.py` e `c06_damage_resolver.py` foram preservados byte a byte dentro de `src/`.

## Contratos de fonte e semântica

- A fonte de Feryn é documento MESTRE-SIDE contendo NPC/equipamento **PROPOSTO** para encontro; isso não prova promoção de itens ao catálogo nem encontro já ocorrido.
- Turbilhão `9d10+8` Vento, Reflexo contra Luta `4d6+92`, 60 PA/conjuração, ação Padrão, cone 8 m, instantâneo; Defesa que supera sofre metade; empate resulta em dano integral conforme redação da habilidade. Sem crítico.
- Eristan tem Reflexo `4d6+28` e RD **física** 25; NÃO aplicar RD física a Turbilhão de Vento. Auren Reflexo `6d6+166`. Metade ímpar não adjudicada: mostrar FLOOR/CEIL TEST.
- Presas `8d8+47` dano físico, ataque `4d6+92` contra CA; comparação sem crítico não representa o uso integral das regras de críticos. RD física Eristan 25. Custo de PA de ataque físico normal não presumido.
- RD de Vento só se fornecida explicitamente como `RD Vento N` e permanece TEST sem URL e versão fonte competente.
- Somente os defensores do registro local e as habilidades localmente autorizadas são calculadas; outros nomes geram pendência de recuperação de fonte, não preenchimento de valores imaginados.
- Sem RD documentada, exibir média pós-salvaguarda mas NÃO declarar PV reais; qualquer perda limitada por Vida com RD não fornecida equivale a hipótese auxiliar RD0 e deve ser rotulada TEST.
- R162 (154 eventos, 9 runs, 466 commits) é tabela derivada CORRIGIDA, preservando original R160; `raw` de magia **pode já estar pós-salvaguarda**. Não dividir por dois novamente.
- R169 (137 eventos, 5 runs, 413 commits) é coorte distinta, com dois duelos ED × Crocodilo sob ataque físico limitado, iniciativa exógena e sem holdout cego. Não somar como campanhas independentes.
- Evento é identificado por `(cohort, run_id, seq_R18, index da ação nativa)` quando seq comporta múltiplas ações. Respostas ambíguas retornam candidatos, não escolhem evento.
- `PA_spent`/`PA_spent_allocated_to_event` é recurso do **evento** e não custo total da cena nem oportunidade futura.

## Proveniência

- Notion Mestre Feryn: https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31
- Notion Mestre Eristan: https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76
- Notion Mestre Auren: https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02
- Regras Combate/Magia: https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0 e https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373
- Original VLAB R170: `/Comestre/OP-VLAB-FUSION-SANDBOX-01/VLAB_R161_R170_RECEIPTS_TEMPORAL_CROC_ED_CORRECTED_MESTRE_ONLY.zip`. ZIP SHA `ab34cad5a0b26455f9a0ad659735867fa3a9a430e526e08fa2dcd6a13b776ed0`. Manifest 149/149.
- C06 baseline SHA `a52494cf49f8a56890981a9093b72a1fa9a8c146bfd1c312a7fd57dccf16fb10`.

## Gates

NAC-CONT-03: read → before → execute in copy → reopen verify → after → PSV. NAC-PASS-02 técnico sobre artefatos = possível, normativo formal F0 4/8 = HOLD. No writer/lease/epoch/ACK claim. Não mexer em Party, O Primeiro, fichas, regras DMG, combat motor, SQLite originais. VLAB R156 UNKNOWN_EFFECT e R138 HOLD permanecem preservados. Nenhum handoff é ACK sem autoridade competente.
