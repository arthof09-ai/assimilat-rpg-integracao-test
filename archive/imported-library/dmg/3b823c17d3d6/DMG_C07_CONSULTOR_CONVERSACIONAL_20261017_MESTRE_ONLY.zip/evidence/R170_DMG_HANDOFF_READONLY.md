# R170 — Handoff somente leitura ao DMG existente

**OP:** OP-DMG-CORPUS-EMP-01 é receptor científico COMPETENTE; VLAB CM-000006 não tem writer/ACK DMG. Não importar nem concatenar por padrão.

**Coorte histórica conciliada:** `R162_CORRECTED_RECEIPTS_R160_HISTORICAL_UNMODIFIED.csv`, 154 ofensivas R160, 9 bancos, 466 commits, pós-RD 11.870, Vida retirada 11.808, overkill 62. Três retificações de exportação: R157 BASIC13, WIND13, R15811; preservar CSV histórico anterior e diferenças, não alterar banco antigo.

**Coorte nova distinta:** `R169_NEW_NATIVE_RECEIPTS_137_SOURCE_SCOPED.csv`, 137 ofensivas nativas em 5 bancos, 413 commits, 11.831 pós-RD, Vida retirada 11.563, overkill 268. Contém identificação de cena/seed/committed SHA, origem do ataque, ator-alvo, tipo, crítico, tentativa de acerto, raw/RD/net/HP real/overkill e custo PA atribuível ao evento. Cinco runs incluem duas lutas completas Auren L3 x Crocodilo L3 **somente básico físico com iniciativa Besta exógena**, uma Flecha temporal e duas AoO técnicas; partidas com mesma espécie/política não são observações independentes de espécies.

**Limites científicos:** Lightning RD Auren incerta, Beast natural Initiative incerta, alcance de Grifo Descarga condicionado, nenhum holdout cego, fixture crítica dirigida não conta probabilidade, spell effects metade ímpar HOLD. R166 KO prova prospectiva de classificação correta 114 pós-RD, 60 HP real, 54 overkill. R165 Flecha deve ser lida literalmente do recibo comprometido, sem extrapolação.

**Status:** PREPARADO/NÃO RECEBIDO/NÃO ACK, sem escrita no OP DMG, sem alterar DMG-RANK-01 v1.1. Fonte URLs disponíveis na matriz R164, SHA/manifestos R170 para auditoria independente.

**Semântica crítica de salvaguarda:** para magia, `raw` nativo pode já representar o valor após salvaguarda; em R159 a fita real produziu 74 antes da salvaguarda, 37 após e 37 PV efetivos. O classificador R162 prospectivo expõe `gross_spell_dice_pre_save` em separado, sem arredondar metade ímpar.
