#!/usr/bin/env python3
"""Rebuild Portuguese consultation demonstrations; bounded real source registry."""
from pathlib import Path
import json
from c07_conversational import ask,jsonable,pt_answer,SRC,VERSION,agg
ROOT=Path(__file__).resolve().parents[1]
questions={
'A_FERYN_ERISTAN':'Quanto dano o Turbilhão Cinzento de Feryn pode causar contra Eristan? Considere Reflexo, RD aplicável, Vida e custo PA.',
'A2_FERYN_AUREN':'Quanto dano o Turbilhão de Feryn pode causar contra Auren?',
'A3_EXPLICIT_RD_TEST':'Quanto dano o Turbilhão de Feryn pode causar contra Eristan RD Vento 3 Vida 20?',
'B_COMPARE_ATTACKS':'Compare Presas e Turbilhão contra Eristan. Qual entrega mais por tentativa?',
'B2_CONE_TWO_ELIGIBLE_TARGETS_TEST':'Turbilhão de Feryn contra Eristan 2 alvos RD Vento 0',
'C_R162_CORRECTED_EVENT':'Explique evento VLAB R157_TACTIC_BASIC_DEV_S997617 evento 48',
'C2_R169_OVERKILL_EVENT':'Explique evento VLAB R166_V2_CASULO_AOO_KO_DEV_S1205088 evento 5',
'C3_R169_CROCODILE_FINISH':'Explique evento VLAB R168_ED_AUREN_VS_CROC_BASIC_DEV_S1168001 evento 197',
'C4_R162_COHORT':'Qual total da coorte VLAB R160?',
'C5_R169_COHORT':'Qual total da coorte VLAB R169?',
}
results={}
for key,q in questions.items():
 x=ask(q)
 results[key]={'question':q,'response':jsonable(x),'text':pt_answer(x),'status':'SOURCE_DOCUMENTED_PLUS_CONDITIONAL_OR_SANDBOX','no_external_effects':True}
(ROOT/'evidence/C07_CONVERSATIONAL_DEMOS_ABC.json').write_text(json.dumps({'as_of':'2026-10-17','questions':results,'source_registry':SRC,'source_last_edit':VERSION},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=['# DMG — C07 | Demonstração no chat (MESTRE-ONLY)','', '**As perguntas abaixo são resolvidas pelo mesmo módulo Python de consulta, que também pode ser utilizado por este Comestre diretamente nesta conversa.**','']
for key,v in results.items():lines+=['## '+key,'','> '+v['question'],'','```text',v['text'],'```','']
(ROOT/'docs/C07_CHAT_DEMONSTRATIONS.md').write_text('\n'.join(lines),encoding='utf-8')
print('GENERATED',len(results),'chat consultations')
