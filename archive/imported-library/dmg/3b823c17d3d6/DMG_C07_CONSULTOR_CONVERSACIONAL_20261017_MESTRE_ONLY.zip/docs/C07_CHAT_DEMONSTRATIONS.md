# DMG — C07 | Demonstração no chat (MESTRE-ONLY)

**As perguntas abaixo são resolvidas pelo mesmo módulo Python de consulta, que também pode ser utilizado por este Comestre diretamente nesta conversa.**

## A_FERYN_ERISTAN

> Quanto dano o Turbilhão Cinzento de Feryn pode causar contra Eristan? Considere Reflexo, RD aplicável, Vida e custo PA.

```text
Turbilhão Cinzento de feryn contra eristan. Fonte https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31; defensor https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76.
Fórmula 9d10+8 (vento), bruto 17–98, média 57,5. Ação Padrão, custo PA 60, alcance cone 8 m.
Salvaguarda: REFLEXO_VS_LUTA_SPECIFIC, P(defesa supera) 0%. Antes de RD esperados 57,5 no modelo racional.
Defesa falha em todo o suporte: cenário FLOOR 57,5; CEIL 57,5 de dano condicionado por alvo (PV reais somente com RD e Vida competentes).
RD: INDETERMINADO — RD compatível por tipo não documentada nas fontes consultadas. Números de PV útil sob a hipótese auxiliar RD=0 TEST; não representam dano final canônico. Vida atual não fornecida; não afirmar PV efetivos absolutos ou overkill. Número de alvos realmente dentro do alcance não demonstrado. 
```

## A2_FERYN_AUREN

> Quanto dano o Turbilhão de Feryn pode causar contra Auren?

```text
Turbilhão Cinzento de feryn contra auren. Fonte https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31; defensor https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02.
Fórmula 9d10+8 (vento), bruto 17–98, média 57,5. Ação Padrão, custo PA 60, alcance cone 8 m.
Salvaguarda: REFLEXO_VS_LUTA_SPECIFIC, P(defesa supera) 100%. Antes de RD esperados 28,75 no modelo racional.
Arredondamento metade ímpar não documentado: cenário FLOOR 28,5; CEIL 29 de dano condicionado por alvo (PV reais somente com RD e Vida competentes).
RD: INDETERMINADO — RD compatível por tipo não documentada nas fontes consultadas. Números de PV útil sob a hipótese auxiliar RD=0 TEST; não representam dano final canônico. Vida atual não fornecida; não afirmar PV efetivos absolutos ou overkill. Número de alvos realmente dentro do alcance não demonstrado. 
```

## A3_EXPLICIT_RD_TEST

> Quanto dano o Turbilhão de Feryn pode causar contra Eristan RD Vento 3 Vida 20?

```text
Turbilhão Cinzento de feryn contra eristan. Fonte https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31; defensor https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76.
Fórmula 9d10+8 (vento), bruto 17–98, média 57,5. Ação Padrão, custo PA 60, alcance cone 8 m.
Salvaguarda: REFLEXO_VS_LUTA_SPECIFIC, P(defesa supera) 0%. Antes de RD esperados 57,5 no modelo racional.
Defesa falha em todo o suporte: cenário FLOOR 20; CEIL 20 de dano condicionado por alvo (PV reais somente com RD e Vida competentes).
RD: TEST — parâmetro fornecido na pergunta, não fonte canônica. Número de alvos realmente dentro do alcance não demonstrado. 
```

## B_COMPARE_ATTACKS

> Compare Presas e Turbilhão contra Eristan. Qual entrega mais por tentativa?

```text
Comparação de duas habilidades reais contra eristan:
1) Turbilhão Cinzento (feryn): bruto 57,5; p(defesa supera)=0%; dano condicional FLOOR/CEIL=57,5/57,5. RD: INDETERMINADO — RD compatível por tipo não documentada nas fontes consultadas.; PA por uso 60.
2) Presas da Noite sem Pegadas — golpe normal (feryn): bruto 83; p(acerto)=100%; dano útil esperado/tentativa=58 (sem crítico). RD: DOCUMENTADO — RD física da ficha do defensor.; PA por uso desconhecido.
Conclusão condicional: comparar dano efetivo somente quando RD por tipo e presença do alvo forem competentes; crítico e PA ausentes impedem ranking universal.
```

## B2_CONE_TWO_ELIGIBLE_TARGETS_TEST

> Turbilhão de Feryn contra Eristan 2 alvos RD Vento 0

```text
Turbilhão Cinzento de feryn contra eristan. Fonte https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31; defensor https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76.
Fórmula 9d10+8 (vento), bruto 17–98, média 57,5. Ação Padrão, custo PA 60, alcance cone 8 m.
Salvaguarda: REFLEXO_VS_LUTA_SPECIFIC, P(defesa supera) 0%. Antes de RD esperados 57,5 no modelo racional.
Defesa falha em todo o suporte: cenário FLOOR 57,5; CEIL 57,5 de dano condicionado por alvo (PV reais somente com RD e Vida competentes).
RD: TEST — parâmetro fornecido na pergunta, não fonte canônica. Vida atual não fornecida; não afirmar PV efetivos absolutos ou overkill. 
```

## C_R162_CORRECTED_EVENT

> Explique evento VLAB R157_TACTIC_BASIC_DEV_S997617 evento 48

```text
VLAB R162 — RUN R157_TACTIC_BASIC_DEV_S997617, seq 48, índice nativo 1 (seed 997617).
Sikong Eristan (E) → Sikong Feryn (F); SPELL_NO_PHYSICAL_ATTACK; ação spell, habilidade SPORES. Dano registrado 73, RD 0, pós-RD 73.
Vida 60 → 0: 60 PV realmente retirados; overkill 13. PA atribuído ao evento 80.
Salvaguarda/efeito: SAVE-HALF; CD 76, teste 35; R162 native spell raw may already be POST SAVE; do not halve twice.
Fonte SHA-256 do evento: b96f0d8dede4156a285d6689dd38b1e75cea1924874be320405cb91af29a0508; laboratório, não jogo oficial. Limite: MESTRE_SIDE_PROPOSED_NPCS|ELEMENTAL_RD_ZERO_LAB_ONLY_IF_SPELL.
```

## C2_R169_OVERKILL_EVENT

> Explique evento VLAB R166_V2_CASULO_AOO_KO_DEV_S1205088 evento 5

```text
VLAB R169 — RUN R166_V2_CASULO_AOO_KO_DEV_S1205088, seq 5, índice nativo 1 (seed 1205088).
Feryn (Feryn) → Auren (Auren); OPPORTUNITY; ação NATIVE_OFFENSE_EVENT, habilidade INDETERMINATE_FROM_CSV. Dano registrado 149, RD 35, pós-RD 114.
Vida 60 → 0: 60 PV realmente retirados; overkill 54. PA atribuído ao evento 0.
Salvaguarda/efeito: null; CD N/A, teste N/A; R169 native already resolved receipt
Fonte SHA-256 do evento: e28b3cf55ca3cb2e8803ff086f1ba66a826a495ee6d1385bf1d62f9443c3bdc1; laboratório, não jogo oficial. Limite: directed R42 crit, conditional Casulo expiry and synthetic initial wound.
```

## C3_R169_CROCODILE_FINISH

> Explique evento VLAB R168_ED_AUREN_VS_CROC_BASIC_DEV_S1168001 evento 197

```text
VLAB R169 — RUN R168_ED_AUREN_VS_CROC_BASIC_DEV_S1168001, seq 197, índice nativo 1 (seed 1168001).
Auren (Auren) → Crocodilo de Lodo Astral Ancião (Crocodilo de Lodo Astral Ancião); NORMAL; ação NATIVE_OFFENSE_EVENT, habilidade INDETERMINATE_FROM_CSV. Dano registrado 239, RD 75, pós-RD 164.
Vida 12 → 0: 12 PV realmente retirados; overkill 152. PA atribuído ao evento 0.
Salvaguarda/efeito: null; CD N/A, teste N/A; R169 native already resolved receipt
Fonte SHA-256 do evento: f06184f5a3511f3b32532120769761e52d2e3e36093c16dd65da37f51ae3606a; laboratório, não jogo oficial. Limite: exogenous Beast initiative, physical-only repertoire, nonblind reserved seed.
```

## C4_R162_COHORT

> Qual total da coorte VLAB R160?

```text
VLAB R162 (coorte inteira): 154 recibos, 9 RUN-IDs. Dano bruto 16064, RD 4194, pós-RD 11870, PV reais 11808, overkill 62. PA atribuível aos eventos 2395; não igualar a gasto total de cena. Não são 154 ensaios independentes.
```

## C5_R169_COHORT

> Qual total da coorte VLAB R169?

```text
VLAB R169 (coorte inteira): 137 recibos, 5 RUN-IDs. Dano bruto 16876, RD 5045, pós-RD 11831, PV reais 11563, overkill 268. PA atribuível aos eventos 55; não igualar a gasto total de cena. Não são 137 ensaios independentes.
```
