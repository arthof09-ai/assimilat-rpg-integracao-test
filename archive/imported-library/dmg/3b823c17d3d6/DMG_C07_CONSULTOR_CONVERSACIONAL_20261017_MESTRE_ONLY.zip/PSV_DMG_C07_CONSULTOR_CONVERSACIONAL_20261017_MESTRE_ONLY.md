# PSV — DMG C07 / CONSULTOR CONVERSACIONAL DE DANO REAL

**AS-OF:** 2026-10-17 · **OPERATION:** `OP-DMG-CORPUS-EMP-01` · **MESTRE-SIDE** · **BASELINE:** `DMG-RANK-01 v1.1`, OFICIAL e INALTERADA. **F0 FORMAL:** 4/8, sem promoção. **HIST-ID:** CM-000001 (não equivale a identidade/instância/writer atual).

## DECISÃO DE ESCOPO
C07 implementou interface de consulta de dano em linguagem natural portuguesa dentro da experiência ChatGPT, reutilizando os DOIS módulos matemáticos C06 literalmente sem reescrever seus bytes. A ferramenta é um protocolo de interpretação + código recuperável em ZIP e não um novo motor de combate, app desktop, integração automática de Notion, plugin persistente ou aplicação canônica. A recuperação em outro chat exige este pacote + fontes atualizadas. Nenhuma ação na Party, O Primeiro ou VLAB.

## ANTES → DEPOIS / 10 ETAPAS

| Etapa | ANTES | DESENVOLVIMENTO / DEPOIS REAL | ACEITE |
|---|---|---|---|
| 1 C06 | C06 matemático/portável mas consulta natural não indexada | Reutilizados `experimental_damage_calc.py` e `c06_damage_resolver.py`, byte idênticos; consulta matemática Feryn→Eristan reproduzida | PASS técnico |
| 2 R162 | R160 original interpretava 11.845 PV como efetivo | Arquivo derivado R162, 154 eventos, nove bancos/466 commits; 11.870 pós-RD = 11.808 PV +62 overkill; confrontadas originais 154/154 (somente 3 células de correção de HP/overkill); dez amostras nativas em conjunto | PASS documental/semântico delimitado |
| 3 R169 | R169 ainda não consumido pelo DMG conversacional | Importação separada 137 eventos, cinco bancos/413 commits, 11.831 pós = 11.563 PV+268 overkill; 5 RUNs novos; não concatenado com R162 por padrão | PASS científico delimitado |
| 4 Linguagem natural | Comandos CLI técnicos e HTML auxiliares | `src/c07_conversational.py`: detecta intenção ação/comparação/evento/coorte, lookup fonte e incerteza, responde em português, sem terminal ao Mestre durante conversa | PASS funcional no chat assistido |
| 5 Defesa | C06 resolvedor já previa físico vs CA, salva-halve, RD tipo, crítico scope | Bounded registry semântica R162 (raw de magia pode estar pós-save), empates exigem superação estrita, recusa RD incompatível, preserva floor/ceil TEST, exige índice nativo em seq de múltiplas ações | PASS 27 testes dirigidos |
| 6 Feryn | Fórmula registrada e C06 cálculo | Turbilhão `9d10+8` vento, 60 PA, cone 8m, `4d6+92`; contra Eristan Reflexo `4d6+28` sempre falha, esperado 57,5 pré RD; contra Auren `6d6+166` sempre supera, média 28,5 FLOOR TEST ou 29 CEIL TEST, RD vento indisponível | PASS condicional |
| 7 Comparação | C06 fórmulas separadas | Presas `8d8+47` física normal contra CA76 Eristan acerta sempre no suporte sem crítico; RD física25 reduz média 83→58. Turbilhão57,5 pre RD vento custando 60 PA. Com dois alvos elegíveis com mesmo perfil, RD vento0 TEST média115 por cast; custos/alcances preservados | PASS comparador condicional, sem vencedor universal |
| 8 Evento VLAB | R160 importado principalmente como série de recibos | Consulta `(coorte, RUN, seq, action_index)` explica R157 BASIC seq48 73 pós=60 vida+13 overkill, PA80; R166 KO 114 pós=60 vida+54 overkill | PASS contra evento nativo |
| 9 Handoff | Seis casos C06 já preparados | Condensados 3 casos genuinamente pendentes: RD Vento fonte-válida, arredondamento metade ímpar por autoridade, elegibilidade de alvos de cone; excluir rerun 154 R160 e R169 | PREPARED, SEM ACK |
| 10 QA/Checkpoint | C06 válido | 27 testes C07; 26 checks matemáticos independentes; 2.820 verificações auditoria de R170, CSV original→corrigido e 10 amostras SQLite; empacotamento, teste em extrato limpo e publicação com comprovante externo | PASS técnico para artefatos; publicação/readback comprovados no recibo separado quando existente |

## A, B, C — DEMONSTRAÇÕES CONVERSACIONAIS
**Consulta A — Feryn contra Eristan:** `9d10+8` Vento, 17–98, média57,5, Reflexo Eristan `4d6+28` nunca vence `4d6+92` Feryn. 60 PA por cast, ação Padrão; RD Vento não provada, PV final INDETERMINADOS sem RD. Auren `6d6+166` supera sempre; metade FLOOR=28,5, CEIL=29 (antes RD vento).

**Consulta B — mesmo defensor Eristan:** Presas `8d8+47` física normal, média83; ataque físico `4d6+92` supera CA76, RD física25, esperado58 por tentativa SEM crítico. Turbilhão vento média57,5 PRÉ RD vento, custa60 PA. Não converter RD física em vento, não calcular PV/PA de golpe físico sem custo fonte-competente. Dois alvos hipotéticos equivalentes com RD vento0 TEST geram expectativa total115 se ambos estiverem no cone.

**Consulta C — VLAB R157 BASIC seq48:** magia SPORES `raw=73` já resolvida após save, RD0, pós73, alvo tinha60→0, PV efetivos60, overkill13, PA80; event SHA `b96f0d8dede4156a285d6689dd38b1e75cea1924874be320405cb91af29a0508`. R166 V2 KO seq5 também demonstrado: 149 bruto -35 RD =114 pós, Vida60→0, overkill54, lab-only dirigido.

Resultados estruturados e frases reproduzidas em `evidence/C07_CONVERSATIONAL_DEMOS_ABC.json` e `docs/C07_CHAT_DEMONSTRATIONS.md`.

## DADOS E DENOMINADORES
- Novas fontes/páginas descobertas C07: **0**, intenção funcional. Fontes de personagem usadas: 3 (Feryn, Eristan, Auren), duas fontes-base de regras (Combate/Magia), todas já conhecidas; módulos C06 preservados **2/2**; habilidades indexadas **3** (Turbilhão, Presas, Descarga).
- R162: **154** recibos, **9** RUNs, **466** commits; R169: **137** recibos, **5** RUNs, **413** commits. Total referenciável: **291** recibos, **14** RUNs, **879** commits, **NÃO** 291 observações independentes. Comparação entre coortes por fonte/semântica, não mesclagem automática.
- Correções históricas da tabela derivada: **3/154** recibos com diferença HP: 13+13+11=37; `11.845→11.808` PV e `25→62` overkill. CSV/R160 histórico não alterado.
- Auditor independente: **149/149** hashes de membros R170, todas 291 linhas de dados com 4 invariantes, **10 eventos nativos** contra SQLite original extraído em cópia, **2.820** checks gerais, **26** verificações matemáticas independentes, **27** testes funcionais de interface. Testes não equivalem a auditoria externa por outra pessoa.

## FONTES E ESTADOS
Mestre Notion: Feryn `https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31` (edit 2026-10-16), Eristan `https://app.notion.com/p/3f6c2b324ede819cae98ec0f6a63de76`, Auren `https://app.notion.com/p/3ebc2b324ede814bb730d47dd7bd5f02`, Sistema Combate `https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0`, Magia `https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373`. NPC/equipamentos de Feryn possuem estado PROPOSTO MESTRE-SIDE; fórmula documentada pode suportar cálculo sem promover item a cânone. Fonte de resistência de Vento do alvo não encontrada/validada; RD física conhecida não basta.

VLAB: `VLAB_R161_R170_RECEIPTS_TEMPORAL_CROC_ED_CORRECTED_MESTRE_ONLY.zip`, 15.604.260 bytes, SHA `ab34cad5a0b26455f9a0ad659735867fa3a9a430e526e08fa2dcd6a13b776ed0`, 149/149 membros manifestados; contém original R160 ZIP imutável. Arquivos R162 e R169 recuperados byte-equivalentes aos membros internos do ZIP. Ver `qa/C07_INDEPENDENT_NATIVE_SPOT_AUDIT.json` para identidade dos dez eventos e hashes.

## PLANO SUPREMO / GARANTIAS
**F0 4/8 ANTES e DEPOIS.** C07 reduz lacuna funcional em F3/F4/F5/F8/F9/F11/F12, mas nenhuma fase F1–F18 recebe certificação terminal. E01–E24: zero novas homologações terminais; oito gates transversais: zero promoções. F13–F18 dependem do corpus e supervisão científica. Proibida revisão DMG-RANK-01 v1.1.

## ESTADO DE CONTINUIDADE
**LAST-VERIFIED-UNIT:** C07 módulo em diretório portátil, demos ABC e CSVs derivados originais; check de publicação física documentado em `C07_LIBRARY_COLD_READBACK_RECEIPT_20261017.json` quando anexo.

**FIRST-PENDING:** Fonte competente de RD Vento do alvo e regra oficial para metade ímpar; sem isso perfil Feryn permanece condicional, não erro do motor.

**NO-REPEAT:** A6-571, C05-648, R160 nove bancos reconciliação integral, R169 cenas, R156 UNKNOWN_EFFECT, R138 HOLD; não reabrir loop para repetir provas completas nem reconstruir motores históricos.

**CONFLICTS:** post-save `raw` versus bruto pré-save (preservar semântica nativa); NPCs propostos sem promoção; RD Físico≠RD Vento; múltiplas ações no mesmo commit exigem `action_index`; holdout R168 reservado não cego.

**UNKNOWN-EFFECT:** R156 permanece em quarentena, sem reexecução; não há escrita em fontes originais nesta operação.

**NEXT-5:** (1) usar o consultor em pergunta real adicional do Mestre (sem recodificar); (2) obter fonte e versão RD Vento; (3) resolver regra de metade ímpar se realmente não existir autoridade; (4) admitir novo personagem/habilidade somente após documento físico e QA específico; (5) remeter H1–H3 ao VLAB apenas por rota competente se nova experiência necessária.

**TARGET-REMAINDER:** A5 histórico 0/7, A7 holdout cego 0/8, A8 writer/lease/epoch/ACK não herdados, L002/L003 materiais, cobertura global F0–F18, contratos VLAB terminais 0/17, células oficiais 0/1875.

**AUTHORITY/WRITER STATE:** READ-ONLY Notion Mestre / Library addon, teste local na cópia, publicação de checkpoint independente na pasta Library DMG original; SEM CLAIM de writer canônico, lease, fencing, epoch, identidade executor atual, ACK VLAB, acesso de escrita Party/O Primeiro, promoção de regras ou homologação de produção.

**NAC-PASS-02:** gate técnico aplicável ao calculador local/portabilidade/hash/readback: PASS quando evidência final estiver anexada; gate formal normativo e promoção científica: HOLD. Mudança do pacote após auditoria exige novo hash/check.
