#!/usr/bin/env python3
"""Read-only independent audit of C56-C59 and scientific lineage from the Library raw ZIPs.
    Usage: python C60_REPLAY_INDEPENDENT.py SOURCE_DIR
    Requires raw ZIPs C42/C52/C56/C57/C58/C59 in SOURCE_DIR; no Notion writes, no network.
"""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from fractions import Fraction as F
from tempfile import TemporaryDirectory
import csv,io,json,subprocess,sys,statistics,math

NAMES={
'C42':'DMG_C42_MAGIAS_CONFLITOS_CENSO_MESTRE_ONLY.zip',
'C52':'DMG_C52_25_BANDS_EQUAL_DME_RD_MESTRE_ONLY.zip',
'C56':'DMG_C56_FAIR_CRITICAL_INITIATIVE_GATES_MESTRE_ONLY.zip',
'C57':'DMG_C57_22_SEMICANON_A6_F6_MESTRE_ONLY.zip',
'C58':'DMG_C58_12_MAGIAS_ALIAS_DEDUP_MESTRE_ONLY.zip',
'C59':'DMG_C59_C52_RD_ZERO_RISK_REANALYSIS_MESTRE_ONLY.zip'}

def contents(filepath):
    with ZipFile(filepath,'r') as z:
        assert z.testzip() is None,filepath
        files={n:z.read(n) for n in z.namelist()}
        mp=next((n for n in files if n.endswith('MANIFEST.json')),None)
        if mp:
            data=json.loads(files[mp])
            for n,meta in data.items():
                assert n in files,('missing manifest member',n)
                assert len(files[n])==int(meta.get('bytes',meta.get('size'))),n
                assert sha256(files[n]).hexdigest()==meta['sha256'],n
        return files,len(json.loads(files[mp])) if mp else 0

def csvrows(data):return list(csv.DictReader(io.StringIO(data.decode('utf8'))))

def main(root):
    root=Path(root)
    archive={};internal=0
    for k,n in NAMES.items():
        p=root/n
        assert p.exists(),f'Missing {p}'
        archive[k],valid=contents(p);internal+=valid
    d42=set(archive['C42']['C42_UNIAO_870_PAGE_IDS.txt'].decode().split())
    d57=set(archive['C57']['C57_UNIAO_892_PHYSICAL_IDS.txt'].decode().split())
    d58=set(archive['C58']['C58_UNIAO_904_PAGE_IDS.txt'].decode().split())
    assert (len(d42),len(d57),len(d58))==(870,892,904)
    c57=csvrows(archive['C57']['C57_22_SEMICANON_NOVOS_FONTES.csv'])
    new57={r['notion_page_id'] for r in c57}
    assert len(new57)==22 and not (new57 & d42) and d57==d42|new57
    c58=csvrows(archive['C58']['C58_12_PARES_CHEN_TEXT_EQUIVALENCE.csv'])
    old58={r['first_page_id'] for r in c58}
    new58={r['other_page_id'] for r in c58}
    assert len(new58)==12 and old58<=d57 and not (new58&d57) and d58==d57|new58
    assert all(r['normalized_text_equal']=='SIM' and r['image_byte_equivalence']=='NAO_VERIFICADO' for r in c58)
    # This test verifies the captured comparisons, not direct live Notion text. Do not relabel.
    cases=csvrows(archive['C52']['C52_100_EQUAL_DME_RD_PAIR_CASES.csv'])
    assert len(cases)==100
    summ=csvrows(archive['C59']['C59_04_RD_SCENARIO_PREMIUM_SUMMARY.csv'])
    assert len(summ)==4
    cnt=0
    for entry in summ:
        c=[r for r in cases if r['RD_scenario']==entry['scenario']]
        assert len(c)==25
        premiums=[F(r['volatile_minus_stable']) for r in c]
        zeroshifts=[F(r['P_no_damage_volatile'])-F(r['P_no_damage_stable']) for r in c]
        assert sum(x>0 for x in premiums)==int(entry['volatile_more_damage'])
        assert sum(x==0 for x in premiums)==int(entry['volatile_equal_damage'])
        assert sum(x<0 for x in premiums)==int(entry['volatile_less_damage'])
        assert sum(x>0 for x in zeroshifts)==int(entry['volatile_more_zero'])
        assert sum(x<0 for x in zeroshifts)==int(entry['volatile_less_zero'])
        assert sum(x==0 for x in zeroshifts)==int(entry['volatile_equal_zero'])
        median=round(100*statistics.median(float(F(r['volatile_minus_stable'])/F(r['same_intrinsic_DME'])) for r in c),3)
        assert abs(median-float(entry['median_premium_as_pct_of_raw_DME']))<1e-9
        cnt+=7
    # C56 full exact mathematically reproducible; direct source script in the ZIP.
    with TemporaryDirectory() as temp:
        script=Path(temp)/'verify_c56.py'
        script.write_bytes(archive['C56']['verify_c56.py'])
        result=subprocess.run([sys.executable,str(script)],cwd=temp,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        assert result.returncode==0,(result.stdout,result.stderr)
        before=csvrows(archive['C56']['C56_COLLISION_PROBABILITIES_35.csv'])
        after=csvrows((Path(temp)/'C56_COLLISION_PROBABILITIES_35.csv').read_bytes())
        assert before==after and len(after)==35
        assert (Path(temp)/'C56_CHECKPOINT.json').exists()
    return {'zip_crc_pass':6,'manifests_internal_hash_pass':internal,'physical_ids_before_after':[870,892,904],'cohort57_new':22,'cohort58_new':12,'chen_text_claims_logged':12,'chen_text_independent_notional_refetch':'NOT_PERFORMED_BY_LOCAL_REPLAY','C52_rows_revalidated':len(cases),'C56_exact_math_reexecuted':True,'C59_aggregate_tests_pass':cnt,'notion_writer':'NO-WRITE','F0_global':'HOLD'}

if __name__=='__main__':
    assert len(sys.argv)==2
    print(json.dumps(main(sys.argv[1]),indent=2,ensure_ascii=False))
