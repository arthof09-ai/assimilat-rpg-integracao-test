# Delta honesto — R20 → R21

| Dimensão | R20 | R21 | Nível da prova |
|---|---|---|---|
| Pacote precedente | R19/R14 conferidos | R20 SHA `aceee489...20...` conferido; R19/R14 mantidos bit a bit | Físico local |
| Nove CSV I0003 originais | **0/9 bytes/hashes** | **0/9**; escopo exato pesquisado e acesso a ZIPs pré-R03 limitado | Falta primária persistente, não maquiar |
| União histórica | Projeção indexada 198 | Reexecução pelo ledger derivado R20, diff vazio, 130+111−43=198 | DERIVADO CONFIRMADO, não nove brutos |
| Fórmulas | 46 ocorrências/20 páginas | 46/20 reafirmados e auditados; 12 páginas em198, 8 fora | Reprodutibilidade, não universo global |
| B05 | Menu parcial | Catálogo nominal do Macaco com custo elemental 10PA, omissões ativas explicitadas e contraexemplo custo Patada0 proibido | Novo detalhamento fonte-gated |
| B08 | Fórmula e Luta pendente | Liu `37−29=48−40=8`, prova do residual agregado, sem atribuir +8 a proficiência | Nova identificação de ambiguidade |
| B11 | Crítico sequencial, Brutal pendente | **Nova cláusula primária: magias não recebem crítico normal**; Patada físico com máximo +12; magia como negativo | Novo discriminador documental |
| B12 | Veneno e Fúria parcialmente listados | Adaga CON CD25, 3d12 por tick, 35PA; duração e ticks ausentes; Fúria trigger separado | Precisão positiva/negativa |
| B15 | Elemento/tag parcial | **Exemplo oficial misto 1d8 físico+2d6 Fogo → 1d8+5d6 Fogo** com fraqueza; Behemoth vulnerável a Fogo | Nova prova de não aumento físico |
| B14/B17 | Exame documental sem evento | Exclusões Behemoth/reflexão e interpretação exaustão/morte prática auditadas contra regras | Contratos ainda não testados integralmente |
| B01–B18 | 1 PASS DOC/9 PARTIAL/6 BLOCKED/2 NOT-TESTED | **Sem alteração de veredito**, porém com evidências e faltas mínimas por contrato | Não há crédito fraudulento |
| STRICT | 0/2 | 0/2, com falta mínima por primeiro e segundo combate | Gate HOLD |

A alternativa de seguir criando batches sintéticos foi **rejeitada por menor ganho marginal**. Preferiu-se fechar proveniência, evidências reais e bloqueios específicos; a continuidade a partir daqui depende primeiro da identificação dos arquivos originais I0003 ou de snapshots de combate oficiais. Nenhuma escrita foi feita no Notion, Party, O Primeiro, DMG-RANK ou VLAB.
