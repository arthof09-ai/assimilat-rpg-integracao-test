# R21 — Auditoria de evidência dos cinco critérios prioritários

**Operação:** CM-000001 / OP-DMG-CORPUS-EMP-01 · **escopo:** Mestre-side, somente leitura canônica · **métrica:** PASS INTEGRAL dos predicados B05, B08, B11, B12, B15, não aprovação de subcálculos isolados.

> Proveniência: os URLs abaixo são fontes Notion lidas por conector na execução R21. Texto revisitado não equivale a snapshot assinado em epoch de cena. Os resultados calculados são matemáticos/documentais ou provas **condicionais**, nunca combates completos STRICT.

## B05 — ACTION_INVENTORY

**Predicado original preservado:** inventário completo e legal das ações possíveis de cada ator e forma durante a cena, com classificação, disponibilidade e fontes verificáveis.

**Fontes atuais:** [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0), [Macaco Rei — Prata 5](https://app.notion.com/p/301c2b324ede828caccb813d3979267a), [Liu — ficha Mestre](https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010).

**Leitura primária:** o Sistema estabelece ação padrão, movimento, reação e livres, e informa que uma Ação Completa normalmente consome também a Reação. O Macaco lista Patada `2d6+FOR` (impacto), Mordida `1d6+FOR` (perfurante), Poder Elemental `1d10+INT` (custa **10 PA**), Manipulação Mágica, Força Titânica `+2 FOR` e Comunicação Telepática. A fonte **não especifica** legalidade, custo e temporização de todas as entradas, nem as separa inequivocamente em ativa/passiva/reativa; categorias não devem ser impostas por heurística. Liu possui Extensão Corporal, Fúria, ataque e efeitos de itens, igualmente condicionados por PA e ativação.

**Teste positivo auditável:** uma entrada para Poder Elemental preserva custo `10 PA` com origem e não inventa elemento ofensivo. **Contraexemplo obrigatório:** um compilador que converte ausência de custo da Patada em custo **0 PA**, ou que define o elemento de Poder Elemental como Gelo por herança do pai, deve ser recusado. O `tag_action` herdado de R13 rejeita tag elemental de Poder Elemental.

**Veredito:** **PARTIAL**. Falta o catálogo integral legal da forma escolhida, parâmetros de custos/ativação e aceitação do adaptador oficial. Próximo ato: recuperar ficha e contrato de ações da cena/ator, marcar cada capacidade com *rule_id/source_id, action economy, PA cost, passive/active, timing, cooldown, target*, exigir ACK técnico do responsável pelo motor, sem liberar STRICT nesta frente.

## B08 — HIT_FORMULA_AND_SKILLS

**Predicado original preservado:** fórmula de acerto com atributo, proficiência, equipamento, vantagem/desvantagem e rolagem efetiva, por ação e personagem, demonstrada sem modifier inventado.

**Fontes:** [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0) Regra 3; [Liu](https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010); [Macaco](https://app.notion.com/p/301c2b324ede828caccb813d3979267a).

**Evidência:** regra `dados da classificação + atributo utilizado em Luta + bônus de Luta`; ação padrão, ataque só acerta se **superar** a defesa. Liu imprime ataque normal `2d6+37` com FOR 29; transformada `2d6+48` com FOR40. Resíduo algébrico `37−29=8` e `48−40=8` demonstra constância do componente agregado, **não que Luta selecionada valha +8**. O resíduo pode incorporar arma, técnica e outras fontes impressas; várias habilidades do machado geram modificadores condicionais. Macaco imprime FOR54, mas sem seleção de proficiência Luta, por isso `2d6+54` é somente **ramo Luta0 hipotético**.

**Teste positivo:** reproduzir as subtrações e os dados de classificação Prata `2d6`. **Contraexemplo:** chamar o `+8` de proficiência e somá-lo novamente à fórmula impressa; ou usar `FOR56` supondo embutir o +2 da Força Titânica sem fonte de aplicação. **Bloqueios:** seleção real de atributo/Luta, item ativo, vantagens, ação, RNG e defesa do alvo.

**Veredito:** **PARTIAL**. Próximo ato: recuperar a ficha com seleções reais de proficiência e o evento de ataque no mesmo epoch/scene, confrontar todos os bônus que já integram o total impresso; só depois executar teste integral de acerto.

## B11 — CRIT_EFFECT_INTERACTION

**Predicado original preservado:** crítico físico sequencial, margem, dano crítico e interações com talentos/efeitos de arma e tipo de ataque em um evento elegível.

**Fontes:** [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0) Regra 6; [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373) Regra 5; [Liu](https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010) Crítico Brutal e Decepadora; [Macaco](https://app.notion.com/p/301c2b324ede828caccb813d3979267a).

**Evidência nova decisiva sobre o escopo da regra:** o Sistema de Magia **nega crítico normal às magias**, mesmo quando têm teste próprio, salvo exceção expressa. Crítico físico exige 3d6 rolados **sequencialmente**, com `(6,6,5)` ou `(6,6,6)` no caso sem margem; `(6,5,6)` falha. A probabilidade base é `2/216 = 1/108` por verificação válida. Dano crítico usa dados normais mais o **máximo dos dados de dano**, sem multiplicar por regra genérica.

**Teste positivo condicional:** a Patada, `2d6+FOR54`, tem máximo dos dados `12`, logo, se ocorrer um crítico físico elegível conforme as condições oficiais, o dano vira `2d6+54+12 = 2d6+66` (sem assumir que ação, Luta, estado ou rolamento real sejam legalmente demonstrados). **Negativos:** `(6,5,6)` não é crítico; uma magia com `(6,6,6)` não recebe crítico comum. A habilidade antiga **Crítico Brutal +2 multiplicador** e Decepadora (dano extra/decepamento em crítico) carecem de regra de composição e evento reais para interagir corretamente com o cálculo atualizado.

**Veredito:** **PARTIAL** apesar de subregras demonstradas. Próximo ato: determinar formalmente precedência de Crítico Brutal/Decepadora sob NAC-NORM-01, separar magia de arma, confirmar margem efetiva, três rolagens ordenadas e evento, com fonte congelada e efeito aplicado; não importar multiplicador antigo por padrão.

## B12 — STATUS_DURATION_DOT

**Predicado original preservado:** condições/status, seus gatilhos, duração, tick, reaplicação e término reais, incluindo dano por turno/efeitos persistentes, com ledger do alvo.

**Fontes:** [Adaga da Serpente Enfeitiçada](https://app.notion.com/p/3edc2b324ede811787a0de913622b14d), [Liu](https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010), [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373).

**Evidência literal:** adaga Ouro Negro: dano imediato `5d4+5d8+10`; se falhar salvaguarda CON CD25, recebe veneno **`3d12` por turno**, item tem custo `35 PA`. A ficha **não especifica a duração em turnos**, início do tick, empilhamento nem remoção por efeito/descanso. A distribuição de **um único tick** vai de 3 a36, média exata `39/2=19,5`, sem preencher duração. Liu: Fúria ao atingir metade da Vida normal máxima `235/2=117,5`, custo12 PA, bônus +15FOR e +80Vida; vida e contexto real não verificados.

**Teste positivo:** após **um** tick legalmente confirmado e salvaguarda falha, calcular `3d12` é válido. **Negativos:** inferir 3, 5 ou 10 turnos de veneno por padrão; aplicar DoT na salvaguarda bem-sucedida; disparar Fúria quando HP118/235 sem habilidade de ampliação de gatilho.

**Veredito:** **PARTIAL**. Falta evento de aplicação, sucesso/falha da salvaguarda, cadência e duração oficial, tick e fim; não se pode fechar STATUS_DURATION_DOT com uma ficha que só quantifica dano por turno.

## B15 — ELEMENTAL_WEAKNESS

**Predicado original preservado:** tipagem explícita de todos os componentes do ataque, fraqueza/resistência efetiva do alvo, bônus e ordem de resolução em evento com fonte elegível.

**Fontes:** [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0) Regra 11; [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373); [Behemoth Glacial](https://app.notion.com/p/1fdc2b324ede82bd9d4f811abb689440); [Raposa Flamejante](https://app.notion.com/p/4d0c2b324ede827b9925018be01e60ca).

**Evidência primária:** o Sistema fornece exemplo explícito com tipos separados: `1d8 físico cortante + 2d6 Fogo`. Contra **fraqueza a Fogo**, acrescenta **3d6 de Fogo**, resultando `1d8 físico + 5d6 Fogo`, sem alterar `1d8`. DME matemático: base `11,5`; contra fraqueza `22`; diferença `10,5`. Behemoth tem fraqueza Fogo explicitamente; Raposa lista Bola de Fogo `1d4+5`, mas a ficha não prova elegibilidade do alvo/alcance/tempo/custo/rolagem da cena e o rótulo não deve substituir verificação do tipo de dano no evento.

**Teste positivo:** exemplo oficial `1d8+2d6` tipado dá `1d8+5d6` contra fraqueza declarada. **Contraexemplos:** aplicar +3d8 ao componente físico por ser dado numericamente maior; aplicar fraqueza Fogo à Patada impacto por o Macaco estar na árvore de Bestas de Gelo; aplicar bônus sem a fraqueza do alvo estar comprovada.

**Veredito:** **PARTIAL**. Próximo ato: resolver etiquetas específicas do ataque, defesa elemental do alvo na cena e mitigação RD/RDF/ordem, comprovando que o efeito realmente ocorreu no evento; só então B15 integral.

## Fechamento transversal

Nenhum dos cinco contratos foi integralmente certificado em R21. As subregras e contraexemplos são úteis para implementação futura, mas um predicado composto de evento real não vira PASS por acumular cinco derivações corretas. O bloqueio é **documentado por parâmetro** e transferível ao executor competente quando houver fonte/epoch e aceitação legítima.
