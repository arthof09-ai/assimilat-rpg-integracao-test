#!/usr/bin/env python3
"""Independent zero-write-to-canonical recovery test for R21 ZIP.
Usage: python verify_clean_r21.py /mnt/data/DMG-F1-R21-FONTES-PRIMARIAS-E-GATES-v01.zip
"""
import hashlib,json,zipfile,sys,tempfile,subprocess
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()

def main(zip_path):
 with tempfile.TemporaryDirectory(prefix='DMG_R21_CLEAN_') as tmp:
  work=Path(tmp)
  with zipfile.ZipFile(zip_path) as z:
   assert z.testzip() is None
   safe=[]
   for member in z.namelist():
    p=Path(member)
    assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='DMG_R21_EVIDENCIAS_PRIMARIAS'
    safe.append(member)
   z.extractall(work)
  folder=work/'DMG_R21_EVIDENCIAS_PRIMARIAS'
  manifest=json.loads((folder/'manifest_R21_SHA256.json').read_text())
  expected=set(manifest['files'])|{'manifest_R21_SHA256.json'}
  actual={p.name for p in folder.iterdir() if p.is_file()}
  assert actual==expected,(expected-actual,actual-expected)
  for name,e in manifest['files'].items():
   f=folder/name
   assert f.stat().st_size==e['size']
   assert sha(f.read_bytes())==e['sha256'],name
  assert sha((folder/'R20_ORIGINAL_READONLY.zip').read_bytes())==manifest['R20_parent_SHA256']
  assert sha((folder/'r13_oracle.py').read_bytes())==manifest['R13_original_oracle_sha256']
  with zipfile.ZipFile(folder/'R20_ORIGINAL_READONLY.zip') as z:
   assert z.testzip() is None
   for rfile,sha_expected in [('R19_ORIGINAL_READONLY.zip',manifest['R19_ancestor_SHA256']),('R14_ORIGINAL_READONLY.zip',manifest['R14_ancestor_SHA256'])]:
    assert sha(z.read('DMG_R20_EVIDENCE_RECOVERY/'+rfile))==sha_expected
  # Recalculate R21 derived ledgers from original R20; they must be byte-identical to packaged outputs.
  run=subprocess.run([sys.executable,'build_r21.py'],cwd=folder,check=True,capture_output=True,text=True)
  assert 'R21_BUILD_PASS' in run.stdout
  for name in ('R21_RECON_198_AUDIT.json','R21_198x46_NOMINAL_LEDGER.csv','R21_46_FORMULAS_LEDGER.csv','R21_B01_B18_LEDGER.csv','R21_B01_B18_LEDGER.json','R21_NOVE_ORIGINAIS_PENDENTES.json','R21_TESTES_PONTA_A_PONTA.json'):
   assert sha((folder/name).read_bytes())==manifest['files'][name]['sha256'],name
  test=subprocess.run([sys.executable,'-m','unittest','discover','-s','.','-p','test_r21_documental.py','-q'],cwd=folder,check=True,capture_output=True,text=True)
  assert 'Ran 36 tests' in test.stderr and test.stderr.strip().endswith('OK'),test.stderr
  return {'zip_sha256':sha(Path(zip_path).read_bytes()),'zip_entries':len(safe),'manifest_entries':len(manifest['files']),'all_crc':'PASS','sha256_files_verified':len(manifest['files']),'R20_sha':'PASS','R19_sha':'PASS','R14_sha':'PASS','R13_oracle_sha':'PASS','regenerated_diffs':0,'unit_tests':'36/36 PASS','strict':'0/2','B_total':'1/18','originals_i0003':'0/9'}

if __name__=='__main__':
 result=main(Path(sys.argv[1]))
 print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))
