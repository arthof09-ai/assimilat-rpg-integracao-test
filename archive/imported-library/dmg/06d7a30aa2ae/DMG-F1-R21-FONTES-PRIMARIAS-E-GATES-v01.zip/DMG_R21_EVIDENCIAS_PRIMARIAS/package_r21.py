#!/usr/bin/env python3
"""Package R21 immutable scientific checkpoint without touching canonical sources."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
ZIP=ROOT.parent/'DMG-F1-R21-FONTES-PRIMARIAS-E-GATES-v01.zip'

files=sorted(p for p in ROOT.iterdir() if p.is_file() and p.name!='manifest_R21_SHA256.json' and not p.name.endswith('.pyc'))
def hashf(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={
 'schema':'DMG-R21-CHECKPOINT-MANIFEST-v01','operation':'CM-000001/OP-DMG-CORPUS-EMP-01',
 'surface':'MESTRE-SIDE-SANDBOX','canon_writer':'NONE','nine_i0003_orig_verified':0,'integral_B_certified':1,'strict_fights':0,'NAC_PASS':'HOLD',
 'R20_parent_SHA256':'aceee48951936c9de78ac758395bc9c90bf9a04bdce20b6091991cf9d7e52095',
 'R19_ancestor_SHA256':'828cfa4a1cc662b9a79867f233bfc7872ebddee3c99097ab92319572746a44c8',
 'R14_ancestor_SHA256':'3721ba149fc885840403c160e231f1f7a3e72a06e421f09ec2758afa10d03387',
 'R13_original_oracle_sha256':'799fbaba2cd1c150c350cc46edd9c1d17c1f95eb66ed010f46df53a703212209',
 'original_nine_CSV_content':'NOT_INCLUDED__NOT_RECOVERED',
 'projection_source_level':'DERIVED_INDEX_FROM_R20',
 'files':{p.name:{'size':p.stat().st_size,'sha256':hashf(p)} for p in files}
}
m=ROOT/'manifest_R21_SHA256.json';m.write_text(json.dumps(manifest,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(files+[m]):z.write(p,arcname='DMG_R21_EVIDENCIAS_PRIMARIAS/'+p.name)
print('R21_PACKAGE',ZIP,'members',len(files)+1,'bytes',ZIP.stat().st_size,'sha256',hashf(ZIP))
