"""OP-DMG-CORPUS-EMP-01 R13: isolated, EXPLICITLY SYNTHETIC scientific oracle.
NOT the CM-000006 engine, not official STRICT, never canonical actor state.
Only conditions stated in fixtures are executed; unknowns fail closed.
"""
from dataclasses import dataclass, replace, asdict
from enum import Enum
from itertools import product
from hashlib import sha256
import json
import random

class Rejected(ValueError):
    pass

class Evidence(str, Enum):
    PRINTED = "PRINTED_SOURCE"
    HYPOTHETICAL = "SYNTHETIC_HYPOTHESIS"
    UNKNOWN = "UNKNOWN"

@dataclass(frozen=True)
class Assumption:
    value: object
    provenance: Evidence
    note: str = ""

@dataclass(frozen=True)
class SyntheticScene:
    scene_id: str
    asof: str
    synthetic: bool = True
    # These are not real coordinates or actual current actor records.
    distance_m: float | None = None
    attack_reach_m: float | None = None
    line_of_sight: bool | None = None
    source_frozen: bool = False
    official_approval: bool = False

@dataclass(frozen=True)
class Actor:
    actor_id: str
    hp: int
    hp_max: int
    pa_free: int | None
    strength: int | None
    defense_ca: int
    dodge_total: int | None
    action_budget: int = 1
    reaction_budget: int = 1
    equipment_confirmed: bool = False
    proficiency_luta: int | None = None
    form: str = "normal"
    transform_spirit_assimilated: bool | None = None
    transform_paid: bool = False

@dataclass(frozen=True)
class TransformLedger:
    actor_id: str
    used_scene_ids: tuple[str, ...] = ()
    last_transform_event_id: str | None = None
    completed_rest_after_last_use: bool | None = None
    rest_proof_id: str | None = None
    rest_type: str | None = None
    completed_rest_hours: float | None = None

TITAN_CA_LITERAL = 67
LITERAL_LIU_CA = {"normal": 46, "transformada": 60}
LITERAL_LIU_DODGE_TOTAL = {"normal": 49, "transformada": 63}

# B09. Already-computed defensive totals are not an added modifier.
def expected_ca(form: str) -> int:
    if form == "normal":
        return 6 + 16 + 15 + (4 + 3 + 2)
    if form == "transformada":
        return 6 + 27 + 15 + (4 + 3 + 2 + 3)
    raise Rejected("UNKNOWN_FORM")

def dodge_total(form: str) -> int:
    if form not in LITERAL_LIU_DODGE_TOTAL:
        raise Rejected("UNKNOWN_FORM")
    return LITERAL_LIU_DODGE_TOTAL[form]

def defender_total(form: str, fortitude: int | None, external_con4: bool | None) -> int:
    if fortitude is None or external_con4 is None:
        raise Rejected("UNRESOLVED_FORTITUDE_OR_EQUIPMENT")
    base = {"normal": 6+16+15, "transformada": 6+25+15}.get(form)
    if base is None:
        raise Rejected("UNKNOWN_FORM")
    return base + fortitude + (4 if external_con4 else 0)

def lossless_dice(n: int, sides: int):
    return product(range(1, sides + 1), repeat=n)

def hits_2d6(force: int, defense: int, luta: int = 0):
    return sum(1 for a, b in lossless_dice(2,6) if a+b+force+luta > defense)

def chance_hits(force: int, defense: int, luta: int = 0):
    return hits_2d6(force, defense, luta) / 36

def crit_check(sequence, margin=0, ordered=True):
    if len(sequence) != 3 or any(type(d) is not int or not (1 <= d <= 6) for d in sequence):
        raise Rejected("INVALID_CRITICAL_DICE")
    if not ordered:
        return False
    if not isinstance(margin, int) or not 0 <= margin <= 4:
        raise Rejected("MARGIN_OUT_OF_BOUNDS")
    return sequence[:2] == (6,6) and sequence[2] >= 5-margin

def critical_fail(sequence, ordered=True):
    if len(sequence) != 3 or any(type(d) is not int or not (1 <= d <= 6) for d in sequence):
        raise Rejected("INVALID_CRITICAL_DICE")
    return bool(ordered and sequence[:2] == (1,1) and sequence[2] <= 2)

def all_critical_outcomes(margin=0):
    return sum(crit_check(p, margin=margin) for p in lossless_dice(3,6))

def require_synthetic_scene(scene: SyntheticScene):
    if not scene.synthetic or not scene.scene_id or not scene.asof:
        raise Rejected("SYNTHETIC_SCENE_ID_ASOF_REQUIRED")
    if scene.official_approval:
        raise Rejected("OFFICIAL_AUTHORIZATION_NOT_PROVIDED_BY_THIS_ORACLE")

def reach_preflight(scene: SyntheticScene):
    require_synthetic_scene(scene)
    if scene.distance_m is None or scene.attack_reach_m is None or scene.line_of_sight is None:
        raise Rejected("UNSPECIFIED_MAP_RANGE_LOS")
    if scene.distance_m < 0 or scene.attack_reach_m < 0:
        raise Rejected("NEGATIVE_DISTANCE")
    if not scene.line_of_sight:
        raise Rejected("LINE_OF_SIGHT_BLOCKED")
    if scene.distance_m > scene.attack_reach_m:
        raise Rejected("OUT_OF_REACH")
    return True

def source_gate(scene: SyntheticScene, actor: Actor):
    require_synthetic_scene(scene)
    if not scene.source_frozen:
        raise Rejected("SOURCE_FINGERPRINT_NOT_FROZEN")
    if not actor.equipment_confirmed or actor.proficiency_luta is None:
        raise Rejected("CURRENT_EQUIPMENT_OR_LUTA_UNKNOWN")
    return True

def compute_pa_subtotal():
    return 170 + 50 - (15+30+60+42)

def transform_can_pay(pa_free: int | None):
    if pa_free is None:
        raise Rejected("PA_FREE_UNKNOWN")
    if pa_free < 0:
        raise Rejected("NEGATIVE_PA")
    return pa_free >= 40

def transform_once(scene: SyntheticScene, actor: Actor, ledger: TransformLedger, event_id: str):
    require_synthetic_scene(scene)
    if ledger.actor_id != actor.actor_id or not event_id:
        raise Rejected("ACTOR_LEDGER_MISMATCH")
    if actor.transform_spirit_assimilated is not True:
        raise Rejected("SPIRIT_ASSIMILATION_UNKNOWN_OR_FALSE")
    if actor.form != "normal" or actor.action_budget < 1:
        raise Rejected("TRANSFORM_REQUIRES_FULL_ACTION_AND_NORMAL_FORM")
    if scene.scene_id in ledger.used_scene_ids:
        raise Rejected("ONE_TRANSFORMATION_PER_SCENE")
    if ledger.last_transform_event_id:
        if ledger.completed_rest_after_last_use is not True:
            raise Rejected("REST_NOT_VERIFIED")
        if not ledger.rest_proof_id or ledger.rest_type not in ("short", "long"):
            raise Rejected("REST_PROOF_TYPE_MISSING")
        if ledger.rest_type == "short" and (ledger.completed_rest_hours is None or ledger.completed_rest_hours < 4):
            raise Rejected("SHORT_REST_DURATION_NOT_VERIFIED")
    if not transform_can_pay(actor.pa_free):
        raise Rejected("PA_INSUFFICIENT_FOR_TRANSFORM")
    # No temp HP/PA overlay inferred: only cost and lock are modeled.
    after = replace(actor, pa_free=actor.pa_free-40, action_budget=actor.action_budget-1,
                    form="transformada", transform_paid=True)
    return after, replace(ledger, used_scene_ids=ledger.used_scene_ids+(scene.scene_id,),
                          last_transform_event_id=event_id, completed_rest_after_last_use=False,
                          rest_proof_id=None, rest_type=None, completed_rest_hours=None)

def consume_reaction(target: Actor, reaction: str):
    if target.reaction_budget < 1:
        raise Rejected("NO_REACTION_REMAINING")
    if reaction not in ("dodge", "defend", "counterattack"):
        raise Rejected("UNKNOWN_REACTION")
    return replace(target, reaction_budget=target.reaction_budget-1)

def tag_action(name: str):
    # Only these component tags are printed on Macaco's own page.
    tags={"Patada": "IMPACTO", "Mordida": "PERFURANTE"}
    if name not in tags:
        raise Rejected("NO_SOURCE_ELEMENT_FOR_ACTION")
    return tags[name]

def beast_vitals(branch: str):
    if branch == "LITERAL_HISTORICAL":
        return (750,700)
    if branch == "SYNTHETIC_CURRENT_RULE_SENSITIVITY":
        return (810,760)
    raise Rejected("BEAST_VITALS_BRANCH_UNKNOWN_OR_HYBRID")

def synthetic_basic_attack(scene: SyntheticScene, attacker: Actor, defender: Actor,
                           hit_roll: tuple[int,int], damage_roll: tuple[int,int],
                           defense_mode: str, assumed_impact_rdf: int | None,
                           action_cost_pa: int | None, event_id: str):
    """One hypothetical event. Conditions are EXPLICIT; no implicit canon or PAs.
    Uses Patada: hit rolls 2d6+FOR+Luta; damage separate 2d6+FOR.
    RDF coverage for IMPACTO is an assumption, never promoted here.
    """
    source_gate(scene, attacker)
    reach_preflight(scene)
    if not event_id or attacker.action_budget < 1:
        raise Rejected("NO_ACTION_OR_EVENT_ID")
    if attacker.strength is None or attacker.proficiency_luta is None:
        raise Rejected("MISSING_STRENGTH_OR_LUTA")
    if assumed_impact_rdf is None or assumed_impact_rdf < 0:
        raise Rejected("RDF_APPLICATION_UNDECIDED")
    if action_cost_pa is None:
        raise Rejected("UNSPECIFIED_PATADA_PA_COST")
    if attacker.pa_free is None or attacker.pa_free < action_cost_pa:
        raise Rejected("PA_UNKNOWN_OR_INSUFFICIENT")
    if defender.hp < 0 or defender.hp > defender.hp_max:
        raise Rejected("INVALID_HP_STATE")
    for roll in (hit_roll,damage_roll):
        if len(roll)!=2 or any(type(x) is not int or x<1 or x>6 for x in roll):
            raise Rejected("INVALID_DICE")
    if hit_roll is damage_roll:
        raise Rejected("HIT_AND_DAMAGE_ROLLS_CANNOT_SHARE_SAME_TUPLE_OBJECT")
    if defense_mode=="dodge":
        defender=consume_reaction(defender,"dodge")
        if defender.dodge_total is None:
            raise Rejected("DODGE_TOTAL_UNKNOWN")
        defense=defender.dodge_total
    elif defense_mode=="CA":
        defense=defender.defense_ca
    else:
        raise Rejected("REACTION_MODE_NEEDS_EXPLICIT_HYPOTHESIS")
    hit_total=sum(hit_roll)+attacker.strength+attacker.proficiency_luta
    hit=hit_total > defense
    gross = sum(damage_roll)+attacker.strength if hit else 0
    net=max(0,gross-assumed_impact_rdf) if hit else 0
    defender_after=replace(defender,hp=max(0,defender.hp-net))
    attacker_after=replace(attacker,pa_free=attacker.pa_free-action_cost_pa,
                           action_budget=attacker.action_budget-1)
    report={"event_id":event_id,"watermark":"SYNTHETIC_ONLY_NON_CANON",
            "hit_total":hit_total,"defense_total":defense,"hit":hit,
            "gross_impact_damage":gross,"rdf_assumption":assumed_impact_rdf,
            "net_damage":net,"hp_before":defender.hp,"hp_after":defender_after.hp,
            "hit_roll":list(hit_roll),"damage_roll":list(damage_roll),
            "attacker_before":asdict(attacker),"attacker_after":asdict(attacker_after),
            "defender_before":asdict(replace(defender,reaction_budget=defender.reaction_budget+(1 if defense_mode=='dodge' else 0))),
            "defender_after":asdict(defender_after),"scene":asdict(scene),
            "source_frozen_flag_scope":"ONLY_AN_EXPLICIT_SYNTHETIC_FIXTURE_ASSUMPTION_NOT_A_NOTION_READBACK",
            "all_official_gates":"HOLD","source_acceptance":"LAB_NOT_REQUESTED"}
    report["event_sha256"]=sha256(json.dumps(report,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return attacker_after,defender_after,report

def replay_verify(report):
    sample={k:v for k,v in report.items() if k!="event_sha256"}
    digest=sha256(json.dumps(sample,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    if digest != report.get("event_sha256"):
        raise Rejected("REPLAY_HASH_MISMATCH")
    return True

def initiative_pairwise_certainty(pL: int,pM: int):
    """Historically conditional source expression (Liu DES16+instinct4 vs Macaco DES40)."""
    wins=ties=0
    for l in lossless_dice(2,6):
        for m in lossless_dice(2,6):
            L=sum(l)+16+4+pL
            M=sum(m)+40+pM
            wins+=(M>L)
            ties+=(M==L)
    return wins,ties

# Synthetic *illustrative* end-state only. Actual defeat/death/flee must be set by Mestre.
def hypothetical_finish(hp: int, defeat_rule: str | None):
    if defeat_rule != "HP_ZERO_ENDS_SYNTHETIC_SCENE":
        raise Rejected("UNAUTHORIZED_END_CONDITION")
    return "SYNTHETIC_END" if hp<=0 else "SYNTHETIC_CONTINUE"

def seeded_example(seed=1313):
    rng=random.Random(seed)
    scene=SyntheticScene("SYNTH-R13-P5-PAIR-001", "2026-10-09T09:00:00-03:00",
                         distance_m=1.0,attack_reach_m=2.0,line_of_sight=True,source_frozen=True)
    mac=Actor("BESTIA-GELO-SIMIO-P5-301c2b32",750,750,700,54,67,None,
              equipment_confirmed=True,proficiency_luta=0)
    liu=Actor("SYNTHETIC-LIU-SOURCE-0b4c2b32",235,235,73,29,46,49,
              equipment_confirmed=True,proficiency_luta=0)
    hit=tuple(rng.randint(1,6) for _ in range(2))
    damage=tuple(rng.randint(1,6) for _ in range(2))
    _,_,event=synthetic_basic_attack(scene,mac,liu,hit,damage,"dodge",10,0,"SYNTH-R13-ATTACK-0001")
    return event

@dataclass(frozen=True)
class HitPointLayers:
    normal: int
    normal_max: int
    item_temp: int = 0
    transformed_temp: int = 0


def apply_damage_layers(layers: HitPointLayers, damage: int):
    if damage < 0 or min(layers.normal,layers.item_temp,layers.transformed_temp) < 0:
        raise Rejected("NEGATIVE_HP_OR_DAMAGE")
    spill=damage
    transformed=min(layers.transformed_temp,spill); spill-=transformed
    item=min(layers.item_temp,spill); spill-=item
    normal=min(layers.normal,spill)
    after=HitPointLayers(layers.normal-normal,layers.normal_max,
                         layers.item_temp-item,layers.transformed_temp-transformed)
    return after,{"transformed_spent":transformed,"items_spent":item,
                  "normal_spent":normal,"excess":spill-normal}


def fury_activation(hp_current: int, hp_max: int, pa_free: int | None,
                    chosen: bool, scene_action_available: bool):
    if pa_free is None:
        raise Rejected("PA_FREE_UNKNOWN")
    if hp_max<=0 or hp_current<0 or hp_current>hp_max:
        raise Rejected("INVALID_HP_STATE")
    if not chosen or not scene_action_available or hp_current*2 > hp_max:
        raise Rejected("FURY_PRECONDITIONS_NOT_MET")
    if pa_free < 12:
        raise Rejected("FURY_PA_INSUFFICIENT")
    # Printed +80 Vida, but unspecified temporary-vs-max semantics: return modifier only.
    return {"pa_remaining":pa_free-12,"FOR_modifier":15,"HP_bonus_UNADJUDICATED":80,
            "watermark":"SOURCE_MODIFIERS_ONLY_NOT_A_LIVE_HP_EVENT"}


def synthetic_trace(seed: int, pa_branch: str):
    if pa_branch not in ("P73", "P27"):
        raise Rejected("NO_OTHER_PA_BRANCH_ADMITTED")
    rng=random.Random(seed)
    scene=SyntheticScene("SYNTH-R13-EXPLICIT-001","2026-10-09T09:00:00-03:00",
                         distance_m=1,attack_reach_m=2,line_of_sight=True,source_frozen=True)
    pa=73 if pa_branch=="P73" else 27
    liu=Actor("SYNTH-LIU-0b4c2b32",235,235,pa,29,46,49,
              equipment_confirmed=True,proficiency_luta=0,transform_spirit_assimilated=True)
    mac=Actor("SYNTH-MACACO-301c2b32",750,750,700,54,67,None,
              equipment_confirmed=True,proficiency_luta=0)
    ledger=TransformLedger(liu.actor_id)
    events=[]
    try:
        liu,ledger=transform_once(scene,liu,ledger,"SYNTH-TX-0001")
        events.append({"event":"SYNTHETIC_TRANSFORM_ALLOWED","pa_after":liu.pa_free,
                       "assumed_duration_turns":rng.randint(1,6)+1,
                       "notes":"Spirit, rest, PA, action assumed for fixture; +HP/+PA overlay deliberately not inferred"})
        liu=replace(liu,defense_ca=60,dodge_total=63,strength=40,action_budget=1)
    except Rejected as e:
        events.append({"event":"SYNTHETIC_TRANSFORM_REJECTED","reason":str(e),"pa_after":liu.pa_free})
    hit=tuple(rng.randint(1,6) for _ in range(2))
    dmg=tuple(rng.randint(1,6) for _ in range(2))
    _,liu_after,shot=synthetic_basic_attack(scene,mac,liu,hit,dmg,"dodge",10,0,"SYNTH-HIT-0001")
    events.append(shot)
    events.append({"event":"SYNTHETIC_FINISH_CHECK",
                   "policy":"HP_ZERO_ENDS_SYNTHETIC_SCENE",
                   "outcome":hypothetical_finish(liu_after.hp,"HP_ZERO_ENDS_SYNTHETIC_SCENE")})
    bundle={"classification":"SYNTHETIC_NON_OFFICIAL","seed":seed,"branch":pa_branch,
            "scene":asdict(scene),"events":events,"finish_is_not_official":True,
            "source_frozen_flag_scope":"ONLY_SYNTHETIC_ASSUMPTION_NOT_A_HASHED_SCENE_SOURCE",
            "contract_progress_certified":1,"full_fights_strict_certified":0}
    bundle["sha256"]=sha256(json.dumps(bundle,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return bundle

def behemoth_reflection_sensitivity(gross: int, rdf: int | None,
                                    attack_delivery: str | None,
                                    reflection_basis: str | None,
                                    rounding: str | None):
    """B14 HYPOTHETICAL ONLY, tests exactly the ambiguity the source leaves.
    Printed Behemoth: reflects 15% of eligible damage, EXCLUDES magic/projectiles.
    This function does not decide whether damage is pre/post RDF or how to round.
    """
    if attack_delivery is None or reflection_basis is None or rounding is None or rdf is None:
        raise Rejected("UNRESOLVED_REFLECTION_POLICY")
    if gross < 0 or rdf < 0:
        raise Rejected("NEGATIVE_DAMAGE_OR_RD")
    if attack_delivery not in ("physical_melee", "magic", "projectile"):
        raise Rejected("UNVERIFIED_DAMAGE_DELIVERY")
    if attack_delivery in ("magic","projectile"):
        return 0
    if reflection_basis not in ("GROSS_HYPOTHESIS", "AFTER_RDF_HYPOTHESIS"):
        raise Rejected("UNRESOLVED_REFLECTION_ORDER")
    amount = gross if reflection_basis=="GROSS_HYPOTHESIS" else max(0,gross-rdf)
    exact=amount * 15 / 100
    import math
    if rounding == "FLOOR_HYPOTHESIS":
        return math.floor(exact)
    if rounding == "CEIL_HYPOTHESIS":
        return math.ceil(exact)
    if rounding == "HALF_UP_HYPOTHESIS":
        return math.floor(exact+0.5)
    raise Rejected("UNRESOLVED_REFLECTION_ROUNDING")
