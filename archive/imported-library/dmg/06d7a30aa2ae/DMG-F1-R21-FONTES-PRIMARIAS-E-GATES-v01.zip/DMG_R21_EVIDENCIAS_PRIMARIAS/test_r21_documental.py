"""R21 fail-closed scientific checks. 26+ targeted tests, no mass synthetic stress.
       These tests do not grant official certification or canonical writer.
"""
import csv, hashlib, json, sys, unittest, zipfile
from fractions import Fraction
from pathlib import Path
from collections import Counter

ROOT=Path(__file__).resolve().parent
DATA=ROOT.parent
sys.path.insert(0,str(ROOT))
def r20_member(name):
    with zipfile.ZipFile(ROOT/'R20_ORIGINAL_READONLY.zip') as z:
        return z.read('DMG_R20_EVIDENCE_RECOVERY/'+name)
from r13_oracle import crit_check, all_critical_outcomes, tag_action, compute_pa_subtotal, Rejected

def load(name):return json.loads((ROOT/name).read_text())
def csvload(name):
    with (ROOT/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

class R21PrimaryEvidenceTests(unittest.TestCase):
    def test_r20_immutable_sha(self):self.assertEqual(sha(ROOT/'R20_ORIGINAL_READONLY.zip'),'aceee48951936c9de78ac758395bc9c90bf9a04bdce20b6091991cf9d7e52095')
    def test_r19_immutable_sha(self):self.assertEqual(hashlib.sha256(r20_member('R19_ORIGINAL_READONLY.zip')).hexdigest(),'828cfa4a1cc662b9a79867f233bfc7872ebddee3c99097ab92319572746a44c8')
    def test_r14_immutable_sha(self):self.assertEqual(hashlib.sha256(r20_member('R14_ORIGINAL_READONLY.zip')).hexdigest(),'3721ba149fc885840403c160e231f1f7a3e72a06e421f09ec2758afa10d03387')
    def test_orig_nine_count(self):self.assertEqual(len(load('R21_NOVE_ORIGINAIS_PENDENTES.json')['originals']),9)
    def test_orig_nine_all_unknown(self):self.assertTrue(all(x['R21_exact_original_sha256'] is None for x in load('R21_NOVE_ORIGINAIS_PENDENTES.json')['originals']))
    def test_orig_nine_no_forged_filename(self):self.assertTrue(all(x['filename']=='NOT_RECOVERED_NO_GUESS' for x in load('R21_NOVE_ORIGINAIS_PENDENTES.json')['originals']))
    def test_originals_0_of_9(self):self.assertEqual(load('R21_RECON_198_AUDIT.json')['original_nine_bytes_verified'],0)
    def test_union_198(self):self.assertEqual(130+111-43,198)
    def test_recon_198_rows_ids(self):
        r=csvload('R21_198x46_NOMINAL_LEDGER.csv');self.assertEqual(len(r),198);self.assertEqual(len(set(x['page_id'] for x in r)),198)
    def test_recon_exact_memberships(self):
        r=csvload('R21_198x46_NOMINAL_LEDGER.csv');a={x['page_id'] for x in r if x['i0003_historic']=='1'};b={x['page_id'] for x in r if x['local_111']=='1'}
        self.assertEqual((len(a),len(b),len(a&b),len(a|b)),(130,111,43,198))
    def test_sub104(self):self.assertEqual(sum(int(x['prior_104']) for x in csvload('R21_198x46_NOMINAL_LEDGER.csv')),104)
    def test_recon_diff_empty(self):self.assertEqual(load('R21_RECON_198_AUDIT.json')['198_source_id_diffs'],{'missing_from_derived_198':[],'unexplained_in_derived_198':[]})
    def test_formula_occurrences_not_pages(self):
        a=csvload('R21_46_FORMULAS_LEDGER.csv');self.assertEqual(len(a),46);self.assertEqual(len({x['page_id'] for x in a}),20)
    def test_formula_overlap_12_8(self):
        a=csvload('R21_46_FORMULAS_LEDGER.csv');p=set(x['page_id'] for x in a);ids=set(x['page_id'] for x in csvload('R21_198x46_NOMINAL_LEDGER.csv'))
        self.assertEqual((len(p&ids),len(p-ids)),(12,8))
    def test_occurrences_not_canon_entities(self):self.assertTrue(all(x['is_unique_effect']=='NOT_ESTABLISHED' for x in csvload('R21_46_FORMULAS_LEDGER.csv')))
    def test_matrix_18_no_new_pass(self):
        j=load('R21_B01_B18_LEDGER.json');self.assertEqual(len(j['rows']),18);self.assertEqual(j['certified_full_count'],1)
        self.assertFalse(any(x['new_R21_full_criterion_certificate'] for x in j['rows']))
    def test_matrix_exact_predicates_stable(self):
        j=load('R21_B01_B18_LEDGER.json');prior=json.loads(r20_member('MATRIZ_B01_B18_R20.json'))
        self.assertEqual([x['original_predicate'] for x in j['rows']],[x['original_predicate'] for x in prior['rows']])
    def test_matrix_status_counts(self):self.assertEqual(load('R21_B01_B18_LEDGER.json')['statuses'],{'PASS_DOCUMENTAL':1,'PARTIAL':9,'BLOCKED':6,'NOT_TESTED':2})
    def test_combat_source_exact(self):self.assertEqual(next(x for x in load('R21_FONTES_MESTRE_READONLY.json')['references'] if x['evidence_id']=='S-COMBAT')['page_id'],'3ebc2b324ede81f1be4be8804ac113c0')
    def test_b05_not_invent_patada_cost(self):self.assertEqual(load('R21_TESTES_PONTA_A_PONTA.json')['B05_action_menu']['documented_actions']['Patada']['cost_pa'],'UNKNOWN')
    def test_b05_known_elemental_cost(self):self.assertEqual(load('R21_TESTES_PONTA_A_PONTA.json')['B05_action_menu']['documented_actions']['Poder elemental']['cost_pa'],10)
    def test_b08_same_residual_without_skill_assignment(self):self.assertEqual((37-29,48-40),(8,8))
    def test_b09_no_double_count_dodge(self):self.assertEqual((49-46,63-60),(3,3))
    def test_b11_ordered_two_successes(self):self.assertEqual(all_critical_outcomes(),2);self.assertTrue(crit_check((6,6,5)))
    def test_b11_order_adversarial(self):self.assertFalse(crit_check((6,5,6)));self.assertFalse(crit_check((5,6,6)))
    def test_b11_patada_bonus_only(self):self.assertEqual(2*6+54,66)
    def test_b12_poison_one_tick_exact_mean(self):self.assertEqual(Fraction(3*(1+12),2),Fraction(39,2))
    def test_b12_no_arbitrary_duration(self):self.assertEqual(load('R21_TESTES_PONTA_A_PONTA.json')['B12_DOT_and_status']['poison']['duration'],'UNKNOWN')
    def test_b12_rage_half(self):self.assertTrue(117<=235/2);self.assertFalse(118<=235/2)
    def test_b15_elemental_example_exact(self):
        non=Fraction(1+8,2)+2*Fraction(1+6,2);weak=Fraction(1+8,2)+5*Fraction(1+6,2)
        self.assertEqual((non,weak,weak-non),(Fraction(23,2),Fraction(22),Fraction(21,2)))
    def test_b15_does_not_increase_physical(self):self.assertEqual(next(x for x in load('R21_TESTES_PONTA_A_PONTA.json')['B15_element_weakness']['system_explicit_example'].values() if x.startswith('1d8')), '1d8 PHYSICAL + 2d6 FOGO')
    def test_b14_fractional_reflect_rounding_unknown(self):self.assertEqual(Fraction(81*15,100),Fraction(243,20));self.assertEqual(load('R21_TESTES_PONTA_A_PONTA.json')['B14_reflection']['rounding'],'UNKNOWN')
    def test_b17_exhaustion_not_automatic_transform(self):self.assertEqual(load('R21_TESTES_PONTA_A_PONTA.json')['B17_exhaustion']['combat_end_receipt'],'UNKNOWN')
    def test_b04_subtotal_not_temporal(self):self.assertEqual(compute_pa_subtotal(),73);self.assertEqual(load('R21_TESTES_PONTA_A_PONTA.json')['B04_B09_critical_lacuna']['Perdido_minus46'],'UNRESOLVED_TIMESTAMP')
    def test_macaco_elemental_not_auto_fogo(self):
        with self.assertRaises(Rejected):tag_action('Poder elemental')
    def test_no_strict_fights(self):self.assertEqual(load('R21_STRICT_SCENE_GAPS.json')['completed_full_fights'],0)

if __name__=='__main__':unittest.main(verbosity=2)
