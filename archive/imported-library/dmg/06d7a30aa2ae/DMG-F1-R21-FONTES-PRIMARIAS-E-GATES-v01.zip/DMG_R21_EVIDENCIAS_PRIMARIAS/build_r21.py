#!/usr/bin/env python3
"""R21: audit-only evidence ledger; reuses immutable R20/R13; NEVER writes Notion or canon."""
from __future__ import annotations
import csv, hashlib, json, re, sys, io, zipfile
from pathlib import Path
from collections import Counter
from fractions import Fraction

ROOT=Path(__file__).resolve().parent
DATA=ROOT.parent
R20_ZIP=ROOT/'R20_ORIGINAL_READONLY.zip'
R13=ROOT
R20_ZIP_SHA='aceee48951936c9de78ac758395bc9c90bf9a04bdce20b6091991cf9d7e52095'
R19_SHA='828cfa4a1cc662b9a79867f233bfc7872ebddee3c99097ab92319572746a44c8'
R14_SHA='3721ba149fc885840403c160e231f1f7a3e72a06e421f09ec2758afa10d03387'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def out(name,value): (ROOT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
def page(id):return 'https://app.notion.com/p/'+id
assert sha(R20_ZIP)==R20_ZIP_SHA
def original_r20(name):
    with zipfile.ZipFile(R20_ZIP) as z:
        return z.read('DMG_R20_EVIDENCE_RECOVERY/'+name)
assert hashlib.sha256(original_r20('R19_ORIGINAL_READONLY.zip')).hexdigest()==R19_SHA
assert hashlib.sha256(original_r20('R14_ORIGINAL_READONLY.zip')).hexdigest()==R14_SHA
assert sha(ROOT/'r13_oracle.py')=='799fbaba2cd1c150c350cc46edd9c1d17c1f95eb66ed010f46df53a703212209'

# IDS: Read-only materialized R20 result of Library-derived 198 source (not the 9 raw I0003 files).
r20recon=list(csv.DictReader(io.StringIO(original_r20('RECON_198_104_46_R20.csv').decode('utf-8'))))
r20forms=list(csv.DictReader(io.StringIO(original_r20('RECON_46_FORMULAS_R20.csv').decode('utf-8'))))
assert len(r20recon)==198 and len({r['page_id'] for r in r20recon})==198
assert len(r20forms)==46 and len({r['source_page_id'] for r in r20forms})==20
ids={r['page_id']:r for r in r20recon}
historical={id for id,r in ids.items() if r['in_I0003_130']=='1'}
local={id for id,r in ids.items() if r['in_local_111']=='1'}
weapon={id for id,r in ids.items() if r['origin_mask']=='W'}
fogo={id for id,r in ids.items() if r['origin_mask']=='F'}
subset104={id for id,r in ids.items() if r['in_local_104']=='1'}
formula_pages={r['source_page_id'] for r in r20forms}
assert len(historical)==130 and len(weapon)==87 and len(fogo)==43
assert len(local)==111 and len(local&historical)==43 and len(local|historical)==198
assert len(subset104)==104 and subset104<=set(ids)
assert len(formula_pages&set(ids))==12 and len(formula_pages-set(ids))==8
assert len(formula_pages&local)==8 and len(formula_pages&weapon)==4
assert sum(int(r['formula_occurrence_count']) for r in r20recon)==sum(r['source_page_id'] in ids for r in r20forms)

audit={
  'operation':'CM-000001/OP-DMG-CORPUS-EMP-01','revision':'R21','evidence_tier':'INDEPENDENT_REEXEC_OF_R20_INDEXED_DERIVED_LEDGER__NOT_ORIGINAL_9_CSV',
  'R20_zip_sha256_verified':R20_ZIP_SHA,
  'historical_I0003':130,'historic_weapons_tech_artifact_inscription_matrix':87,'historic_Fogo':43,
  'local_111':111,'shared_43':43,'calculated_union_198':len(local|historical),
  '198_source_id_diffs':{'missing_from_derived_198':sorted((local|historical)-set(ids)), 'unexplained_in_derived_198':sorted(set(ids)-(historical|local))},
  'prior_104_subset_of_198':len(subset104),
  'formula_occurrences':46,'formula_source_pages':20,'formula_source_pages_inside_198':len(formula_pages&set(ids)),
  'formula_source_pages_outside_delimited_198':len(formula_pages-set(ids)),
  'formula_pages_local_111':len(formula_pages&local),'formula_pages_87_historical_weapons':len(formula_pages&weapon),
  'original_nine_bytes_verified':0,'source_authority':'Derived Library index, original upstream CSVs not physically authenticated',
  'global_universe_size':'UNKNOWN', 'unidentified_149_manifest':'UNKNOWN'
}
out('R21_RECON_198_AUDIT.json',audit)

with (ROOT/'R21_198x46_NOMINAL_LEDGER.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['page_id','origin_derived','i0003_historic','local_111','prior_104','formula_count','recovery_level','source_page_url'])
 for id,r in sorted(ids.items()):w.writerow([id,r['origin_mask'],int(id in historical),int(id in local),int(id in subset104),int(r['formula_occurrence_count']),'DERIVED_INDEX_ONLY',page(id)])
with (ROOT/'R21_46_FORMULAS_LEDGER.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['occurrence_key','page_id','formula','in_delimited_198','source_graded','is_unique_effect','RE','FIP','source_url'])
 for r in r20forms:
  w.writerow([r['occurrence_key'],r['source_page_id'],r['literal_expression'],int(r['source_page_id'] in ids),'READ_ONLY_SOURCE_OBSERVATION','NOT_ESTABLISHED',r['effect_RE'],r['effect_FIP'],r['source_url']])

sources=[
 ('S-COMBAT','3ebc2b324ede81f1be4be8804ac113c0','Sistema de Combate','2026-10-07T23:51:04.971Z',
  ['Turno: Ação Padrão+Movimento+Reação, completa normalmente compromete a reação', 'Ataque: dados da classificação + atributo Luta + bônus Luta; 1 Ação Padrão; superar defesa','Crit: verificar 3d6 ordenados 6,6,5 ou 6,6,6; 6,5,6 falha; dano crítico soma máximo dados','Fraqueza: +3 rolagens do maior dado ELEMENTAL, sem triplicar dano físico','Defender=6+CON+Armadura+Fortitude; Esquiva=CA+Reflexo']),
 ('S-MAGIC','3ebc2b324ede81f7b343f7270ff91373','Sistema de Magia','2026-10-07T23:51:07.044Z',
  ['Magias não causam crítico salvo exceção explícita','Não existe rolagem de ataque mágico universal; salvaguarda só quando indicada','Conjuração sem PA Livre gera exaustão: inconsciência por 2d10 dias; morte é descrição prática na batalha','Fraqueza 2d6 Fogo -> 5d6 Fogo']),
 ('S-LIU','0b4c2b324ede837cb6be818dc8e36010','Liu Xiaua ficha Mestre','2026-10-01T09:40:50.721Z',
  ['Ataque normal 2d6+37, FOR29; transformação 2d6+48 FOR40; residual algébrico +8 em ambos, origem não demonstrada','Proficiências impressas como lista sem seleção preservada pelo fetch','Crítico Brutal antigo: multiplicador aumenta +2; interação com crit atual sem decisão','Fúria: quando vida chega à metade, +15 FOR +80 Vida, custo12PA','Alma exibida 170+50−15−30−60−42=73; Perdido -46 sem timing','CA46/60; esquiva exibição49/63; reação real desconhecida']),
 ('S-MAC','301c2b324ede828caccb813d3979267a','Macaco Rei ficha','2026-10-01T18:00:42.589Z',
  ['Prata 5 (Titã); Patada 2d6+FOR impacto; Mordida 1d6+FOR perfurante; Poder elemental 1d10+INT custo10PA','Força Titânica +2 FOR sem prova de inclusão em FOR54','Manipulação Mágica, Telepatia não têm economia detalhada','Luta escolhida e custo de Patada/Mordida faltantes']),
 ('S-RAPOSA','4d0c2b324ede827b9925018be01e60ca','Raposa Flamejante ficha','2026-10-01T18:00:46.092Z',
  ['Bronze2; Bola de Fogo 1d4+5; rastro de fogo Passos Flamejantes sem magnitude temporal/alcance','Tipo elemental e custos/salvaguarda de cada ação não totalmente parametrizados']),
 ('S-BEHEMOTH','1fdc2b324ede82bd9d4f811abb689440','Behemoth Glacial ficha','2026-10-01T18:00:46.463Z',
  ['Prata5 Gelo; vulnerabilidade explícita a Fogo; vida500 alma560','Armadura de Gelo: +3CA; devolve 15% do dano recebido, exclui magias e projéteis; custo20PA mais3PA por turno','Sem arredondamento e precedência detalhados para reflexão']),
 ('S-DAGGER','3edc2b324ede811787a0de913622b14d','Adaga da Serpente Enfeitiçada','2026-10-03T04:47:17.045Z',
  ['Dano imediato 5d4+5d8+10','Se alvo falhar salvaguarda CON CD25, dano de veneno 3d12 POR TURNO; 35PA','Duração, cadência exata, estado e rolls do alvo não fornecidos']),
 ('S-CHEN','90ac2b324ede8220b226816fd255c9cb','Chen Yi-Min M Bronze V','2026-09-30T04:35:47.347Z',
  ['Foice de Vento 2d6+INT (10), alcance9m, custo 2PA (ficha personagem)', 'Arma 1d10+12, 1d10+14; habilidades de vento e gelo coexistem']),
 ('S-FOICE','9edc2b324ede8373ab2f018fd3f4da72','Foice de Vento página isolada','2026-09-30T04:44:59.712Z',
  ['Foice de Vento 2d6+INT alcance9m custo 13PA (página específica)', 'Contradição 2PA vs13PA não adjudicada']),
 ('S-TRANS','3f2c2b324ede81c0ae0ee4e66212edc9','Transformação especializada','2026-10-09T04:07:43.987Z',
  ['T9-A uma por cena, outra cena precisa descanso concluído 4–6h no curto; sem máximo diário fixo de três','Gates NAC-NORM e NAC-PASS especializados pendentes para canonização global']),
]
out('R21_FONTES_MESTRE_READONLY.json',{'origin':'Notion connector read this turn, textual excerpts, NOT binary/complete snapshot','references':[{'evidence_id':k,'page_id':id,'url':page(id),'source_title':title,'as_of':asof,'documentary_assertions':assertions,'full_page_binary_sha':None,'source_frozen_for_STRICT':False} for k,id,title,asof,assertions in sources]})

orig=json.loads(original_r20('INVENTARIO_NOVE_CSV_R20.json'))
for s in orig['originals']:
 s.update({'R21_validation':'UNLOCATED_RAW_BYTES__NOT_VERIFIED','R21_exact_original_sha256':None,'R21_original_library_id':None,'R21_source_path':None,'R21_reconstructed_replica_not_created':True})
orig['R21_recovery_status']='ZERO_OF_NINE_ORIGINAL_RAW_AUTHENTICATED';orig['R21_scope']='Seven item CSV and two Fogo CSV only, not consolidated v05'
orig['R21_targeted_searches']=[
 {'tool':'Library /Comestre recursive, exact CSV filter','finding':'47 CSV indexed, 4 relevant DMG derived; none with original 7+2 basename/independent SHA','conclusion':'NOT_IN_TOP_LEVEL_CSV_INDEX_DOES_NOT_PROVE_ABSENT_IN_ARCHIVES'},
 {'tool':'Library /Comestre/OP-DMG-CORPUS-EMP-01 zip inventory','finding':'R07-R11 ZIP exist; nine CSV original member names/hashes not shown in readable index','conclusion':'ARCHIVE_INNER_MEMBERS_UNVERIFIED'},
 {'tool':'Library all ZIP metadata','finding':'114 ZIP files indexed including R07-R20; no individually named original I0003 package verified','conclusion':'INDIRECT_ARCHIVE_POSSIBILITY'},
 {'tool':'Library markdown and JSON manifest title search','finding':'R03 scientific dossier confirms 7+2 and numeric totals, but does not provide nine individual original filenames/hashes','conclusion':'SECONDARY_HISTORICAL_REPORT_ONLY'},
 {'tool':'Notion IBX34 R03 / IBX69 / OP-DMG / Central','finding':'R03 asserts nine CSV recovered in predecessor execution, not original bytes/hashes or filenames','conclusion':'DO_NOT_CREDIT_ORIGINAL_RECOVERY'},
 {'tool':'Prior-work context search','finding':'No exact nine original filenames, Library IDs, original ZIP archive paths or SHA were documented','conclusion':'NO_GROUNDED_ORIGINAL_LOCATOR'},
 {'tool':'Current local mounted /mnt/data','finding':'R13–R20 artifacts present; no identifiable nine raw original CSV','conclusion':'LOCAL_RECOVERY_UNAVAILABLE'},
 {'tool':'Library raw-byte materialization of derived v05','finding':'Not authorized / 401, textual indexed reading remains available','conclusion':'TEXTUAL_RECON_ONLY'}]
out('R21_NOVE_ORIGINAIS_PENDENTES.json',orig)

# Exact measured isolated tests, sourced inputs and declared unknowns.
sys.path.insert(0,str(R13))
from r13_oracle import crit_check,all_critical_outcomes, compute_pa_subtotal,tag_action,Rejected
assert all_critical_outcomes()==2 and crit_check((6,6,5)) is True and crit_check((6,5,6)) is False
assert compute_pa_subtotal()==73 and tag_action('Patada')=='IMPACTO'

steps={
 'B02_historically_bounded_PASSED':{'source':'S-MAC and Beast/Titan rules, R20 verified','parameters':{'DES':40,'CON':35,'titan_base_CA':20,'observed_CA':67},'formula':'20+40+35/5','computed':67,'counterexample_non_titan':'10+40+35/5 = 57','verdict':'PASS_DOCUMENTAL_ALREADY_CERTIFIED_R11'},
 'B05_action_menu':{'source':'S-MAC and S-COMBAT','documented_actions':{'Patada':{'formula':'2d6+FOR','tag':'impacto','cost_pa':'UNKNOWN','action_economy':'UNKNOWN_ON_THIS_PAGE'},'Mordida':{'formula':'1d6+FOR','tag':'perfurante','cost_pa':'UNKNOWN','action_economy':'UNKNOWN_ON_THIS_PAGE'},'Poder elemental':{'formula':'1d10+INT','cost_pa':10,'element_tag':'UNKNOWN','action_economy':'UNKNOWN_ON_THIS_PAGE'}},'remaining_unmapped':['Manipulação Mágica','Força Titânica passive or activation','Comunicação Telepática'],'positive':'Known Poder elemental cost exactly 10 PA','negative':'Treat Patada cost as 0 or classify Poder elemental as Fogo without source = REJECT','verdict':'PARTIAL'},
 'B08_hit_and_skills':{'source':'S-COMBAT+S-LIU+S-MAC','normal':{'display_bonus':37,'printed_FOR':29,'residual':8},'transform':{'display_bonus':48,'printed_FOR':40,'residual':8},'macaco':{'FOR_source':54,'Luta':None},'positive':'37-29=48-40=8 algebraically; printed hit not invented','negative':'Residual8 is not proof of Luta+8; equipment/selected attribute unknown','verdict':'PARTIAL'},
 'B11_critical_interaction':{'source':'S-COMBAT+S-MAGIC+S-LIU','ordered_success':[[6,6,5],[6,6,6]],'ordered_failure':[[6,5,6],[5,6,6]],'probability_exact':'2/216','patada_conditional':{'normal_damage':'2d6+54','critical_max_dice_bonus':12,'critical_damage':'2d6+66','luta_and_actual_roll':'UNKNOWN'},'magic_global_no_critical_without_explicit_exception':True,'conflict':'Liu old Critico Brutal +2 multiplier lacks authority vs current additive-max critical; never stack','positive':'Ordered attack check and damage derivation','negative':'Magic with 6,6,6 cannot crit by the ordinary global rule','verdict':'PARTIAL'},
 'B12_DOT_and_status':{'source':'S-DAGGER+S-LIU','poison':{'conditional_save':'CON CD25 fails','per_turn':'3d12','min':3,'max':36,'mean_exact':'39/2','duration':'UNKNOWN','ticks_observed':0},'rage':{'normal_HP_max':235,'half_HP_threshold':'<=117.5 when rule says reaches half','cost_PA':12,'FOR_bonus':15,'Vida_bonus':80,'activation_clock':'UNKNOWN'},'positive':'If failed CON and legally active one tick, damage mathematical range 3..36','negative':'Cannot multiply 3d12 by arbitrary number of turns or silently apply Poison on successful save','verdict':'PARTIAL'},
 'B15_element_weakness':{'source':'S-COMBAT+S-MAGIC+S-RAPOSA+S-BEHEMOTH','system_explicit_example':{'mixed_base':'1d8 PHYSICAL + 2d6 FOGO','mixed_vs_weak_fire':'1d8 PHYSICAL + 5d6 FOGO','base_expected':'23/2','weak_expected':'22','increase_exact':'21/2'},'source_candidate':{'Raposa_Bola_Fogo':'1d4+5','Behemoth_explicit_weakness':'FOGO','IF_fire_tag_rule_applicable_result':'4d4+5','source_tag_confirmed':'BY_NAME_ONLY__NOT_EVENT_FROZEN'},'positive':'Official example separately increases only fire component by 3d6','negative':'Do not add 3d8 physically or infer elemental tag from beast family','verdict':'PARTIAL'},
 'B14_reflection':{'source':'S-BEHEMOTH+S-COMBAT','textual':'15% received damage only from compatible nonmagic nonprojectile','example_unrounded':'81*15/100=12.15','rounding':'UNKNOWN','mitigation_order':'UNKNOWN','active_at_event':'UNKNOWN','negative':'Magic or projectile gives no Behemoth armor reflect even if target hit','verdict':'NOT_TESTED_FULL'},
 'B17_exhaustion':{'source':'S-MAGIC','if_illegal_magical_cast':'unconscious 2d10 DAYS','interval_days':[2,20],'mean_days':'11','actual_cast':'UNKNOWN','combat_end_receipt':'UNKNOWN','negative':'Cannot treat rejected transform as illegal spell with 2d10 penalty; practical death not ontological death','verdict':'NOT_TESTED_FULL'},
 'B04_B09_critical_lacuna':{'source':'S-LIU+S-COMBAT','PA_shorthand_73':73,'Perdido_minus46':'UNRESOLVED_TIMESTAMP','reported_CA':[46,60],'reported_dodge_totals':[49,63],'reaction_state':'UNKNOWN','fortitude_luta_selected':'UNKNOWN','no_official_attack_or_dodge_claim':True},
}
out('R21_TESTES_PONTA_A_PONTA.json',steps)

prev=json.loads(original_r20('MATRIZ_B01_B18_R20.json'))
rows=prev['rows']
updates={
'B01':('R21 indexed 198 is well-scoped but source freeze at scene still absent.','Need actor-scene effective_at, snapshot SHA + status; Library index not an official scene.'),
'B02':('Independent R13 20+40+35/5=67 retained, no double-credit.','No new terminal barrier within bounded documental title and Titan identity.'),
'B03':('Behemoth 500/560 and Macaco 750/700 literal, rule-adjusted values conflict.','Need scene authority select both Vida/Alma for each actor; no hybrid.'),
'B04':('Liu 73 displayed and Perdido -46 duplicates across normal/transform print, not two payments.','Need ledger with dated charges 15/60/11/20PA per-day, 30/42 ambiguity, 46 temporal and chosen form.'),
'B05':('Enumerated Macaco Patada/Mordida/Poder elemental; only elemental explicitly costs 10PA.','Need legal timing, complete legal menu and costs of Patada/Mordida/Manipulação/Telepatia; adapter accepted.'),
'B06':('Standard+Move+Reaction documented, complete action normally forfeits reaction.','Need actual action order and proof of exception if any, receipt consumption and legal response.'),
'B07':('Initiative rank dice Prata2d6, bonuses must be source-verified.','Need actual initiative proficiency and action scene rolls/tie policy.'),
'B08':('Observed Liu residual attack bonus 37-29=48-40=8, origin unknown; Macaco FOR54, Luta unset.','Need chosen fighting attr, Luta selection, equipment stacking, actual hit roll and defense.'),
'B09':('Esquiva displayed 49/63 not additive to CA46/60; reaction availability unverified.','Need real selected Reflexo/Fortitude and action/reaction ledger.'),
'B10':('RDF10 printed on Liu armor, Behemoth reflect excls spell/projectile.','Need typed mitigation rule, stacking and actual event damage decomposition.'),
'B11':('New rule crosswalk: ordered physical crit 6,6,5 / 6,6,6; magics NO CRIT unless exception. Patada 2d6+54 -> 2d6+66 only conditional.','Need whether legacy Brutal +2 multiplier, Decepadora item, crit rerolls override/add; event and source authority.'),
'B12':('New literal Adaga ON: fail CON CD25 =>3d12 poison PER TURN (3..36, mean19.5). Liu rage half235=117.5 threshold.','Need save receipt, tick timing/end/duration/target defenses and rage activation timestamp.'),
'B13':('No real map or LoS; source ranges documented only for specific skills.','Need actual map and positions/reach/cover/time.'),
'B14':('Behemoth 15% return spell/projectile exempt; 81 damage 12.15 unrounded, no integer rule.','Need activation proof, timing of mitigation, rounding, eligible damage and event receipt.'),
'B15':('New primary Sistema de Combate mixed example 1d8 physical+2d6 Fire ->1d8+5d6 on explicit Fire weakness; Behemoth weak Fire.','Need valid typed attack component and actual target/weakness event, resistance interactions, source freeze.'),
'B16':('T9-A scene/rest documented but official modification gate not finalized.','Need actual transformation paid/PA/form/Spirit/scene/rest proof and independent norm gate.'),
'B17':('Magic insufficient PA causes 2d10 unconscious days, rule describes practical death in fight; NOT certified end-state.','Need specific illegal cast, end-of-fight authority/fixture and ledger, distinguish literal death.'),
'B18':('No CM-000006 official STRICT reader acceptance; source docs alone cannot certify.','Need legitimate source-frozen CM-000006 controlled replay and NAC-PASS independent.')}
for row in rows:
 id=row['criterion'];a,b=updates[id];row['state_before_R21']=row['state_after_R20'];row['state_after_R21']=row['state_after_R20'];row['R21_primary_evidence_delta']=a;row['R21_specific_blocker']=b
 row['R21_source_grade']='DOCUMENTAL_READ_NOT_SCENE' if id!='B02' else 'ALREADY_DOC_PASS_BOUNDED';row['new_R21_full_criterion_certificate']=False
 row['R21_test_outcome']='R21_DOCUMENTARY_TEST_PARTIAL_NO_FULL_PASS' if id in ['B05','B08','B11','B12','B15'] else 'GATE_INCOMPLETE_OR_ALREADY_CERTIFIED'
 assert row['original_terminal_requirement_preserved'] and row['original_predicate']
assert len(rows)==18 and sum(x['state_after_R21']=='PASS_DOCUMENTAL' for x in rows)==1
assert Counter(x['state_after_R21'] for x in rows)=={'PASS_DOCUMENTAL':1,'PARTIAL':9,'BLOCKED':6,'NOT_TESTED':2}
out('R21_B01_B18_LEDGER.json',{'revision':'R21','base':'R20 unmodified predicates','certified_full_count':1,'full_strict_fights':0,'nac_pass':'HOLD','statuses':dict(Counter(x['state_after_R21'] for x in rows)),'rows':rows})
with (ROOT/'R21_B01_B18_LEDGER.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['id','predicate_original','R20_state','R21_state','new_documentary_evidence','minimal_blocker','source_urls','full_test_outcome','next_act'])
 for row in rows:w.writerow([row['criterion'],row['original_predicate'],row['state_before_R21'],row['state_after_R21'],row['R21_primary_evidence_delta'],row['R21_specific_blocker'],';'.join(row['source_urls']),row['R21_test_outcome'],row['next_decisive_act']])

strict={
 'target_full_fights':2,'completed_full_fights':0,'flight1_Liu_vs_Macaco':{'source_id':'S-LIU,S-MAC','missing':['Scene ID effective_at and source-frozen actor snapshots','Macaco current Vida/Alma branch and cost/time for all actions','Liu PA temporal ledger including Perdido −46 and current items','Selected Luta Fortitude Reflexo and reaction/action availability','Map actual range LoS cover, positions and initiative rolls','Mitigation and mixed damage approvals','CM-000006 authorized execution and independent NAC-PASS']},
 'flight2':'No second complete real selected encounter and timeline of combat evidenced; choose legitimate actor+beast sources, source freeze and eligible engine gate; do not invent second duel.',
 'strict_engine_ownership':'CM-000006, no writer claimed','state':'0/2 STRICT HOLD'
}
out('R21_STRICT_SCENE_GAPS.json',strict)

print('R21_BUILD_PASS originals=0/9, derived_union=',len(local|historical),'formula_occurrences=',len(r20forms),'matrix=',len(rows),'new_PASS=0')
