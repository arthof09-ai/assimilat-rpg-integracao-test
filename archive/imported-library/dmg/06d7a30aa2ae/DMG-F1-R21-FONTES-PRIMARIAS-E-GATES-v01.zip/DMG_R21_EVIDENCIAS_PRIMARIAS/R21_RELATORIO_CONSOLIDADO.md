# OP-DMG-CORPUS-EMP-01 — Relatório científico R21

**COMESTRE:** CM-000001 — Coordenação Científica de Dano · **Classe:** MESTRE-SIDE · **Autoridade:** pesquisa local READ-ONLY · **Data:** 09/10/2026 · **IBX-69:** https://app.notion.com/p/3f4c2b324ede81d18883c4039f0a6305

## 0. PSV / conclusão de governança

| Eixo | Antes (R20) | Depois (R21) | Confiança e critério |
|---|---:|---:|---|
| CSV **originais I0003**, bytes/SHA individualmente identificados | 0/9 | **0/9** | BLOQUEADO por ausência de originais recuperáveis no acesso atual |
| IDs da projeção derivada nominal | 198 | **198** | Reexecução matemática contra R20/derivado indexado, não originais 9 CSV |
| Fórmulas direcionadas | 46 ocorrências em 20 páginas | **46 em 20** | Proveniência R15/R16 e diff nominal, não universo global |
| B01–B18 integralmente certificados | 1/18 (B02 documental) | **1/18 (B02 documental)** | Nenhum PASS artificial |
| STRICT completos | 0/2 | **0/2** | Documentos de cena não comprovados; CM-000006 separado |
| Status da matriz | 1 PASS, 9 PARTIAL, 6 BLOCKED, 2 NOT-TESTED | **inalterado** | Predicados originais preservados |
| Regra DMG, fichas, Party/O Primeiro, engine VLAB | READ-ONLY | **0 alterações** | Operação sandbox; sem writer/instance/lease/epoch/ACK |
| NAC-PASS-02 terminal | HOLD | **HOLD** | Não emitir certificação final do organismo |

**Nota de qualidade:** o resultado não cumpre a meta aspiracional 9/18. A mudança de foco gerou documentação e limites de evidência mais precisos, mas **não superou fisicamente os bloqueios de fonte primária e cena**. Nem o número de testes nem a existência deste ZIP servem para contornar esse fato.

## 1. Preservação integral do estado disponível R01–R20

- **R20 pacote verificado em bytes locais**: `DMG-F1-R20-RECUPERACAO-CORPUS-EVIDENCIAS-v01.zip`, SHA-256 `aceee48951936c9de78ac758395bc9c90bf9a04bdce20b6091991cf9d7e52095`. Copiado **byte a byte** para `R20_ORIGINAL_READONLY.zip`.
- O R20 contém `R19_ORIGINAL_READONLY.zip`, SHA `828cfa4a1cc662b9a79867f233bfc7872ebddee3c99097ab92319572746a44c8`, e `R14_ORIGINAL_READONLY.zip`, SHA `3721ba149fc885840403c160e231f1f7a3e72a06e421f09ec2758afa10d03387`. Validação exata no script R21. R19 referencia R18→R15→R14, R14 preserva R13.
- O **oráculo original R13** (`r13_oracle.py`) é incluído como cópia **byte-identical** de referência, SHA-256 `799fbaba2cd1c150c350cc46edd9c1d17c1f95eb66ed010f46df53a703212209`, **não refatorado**. R21 importa funções desse arquivo para provas e contraexemplos, sem introduzir novo motor.
- R01–R12: os registros Notion e Library históricos referenciados permanecem externos, não todos os ZIPs brutos foram incorporados neste pacote. É indevido declarar preservação byte a byte de arquivos R01–R12 que não foram disponibilizados como bytes nesta execução. Os históricos não foram sobrescritos nem modificados.

## 2. P0 — Recuperar nove CSV históricos I0003

**O que foi tentado:** inventário da Biblioteca `/Comestre` incluindo **47 CSV** e **114 ZIP**, consulta dos pacotes R07–R11 em `/Comestre/OP-DMG-CORPUS-EMP-01`, documentos e manifestos `.md` e `.json`, buscas nominais Notion em OP, Central, IBX-34 R03 e IBX-69; recuperação da continuidade histórica da missão. Todos os originais possuem apenas a **descrição agregada**, sem nome exato, Library ID, path ou SHA individual. Um arquivo ZIP anterior indexado pode fisicamente conter algum original, mas não foi possível certificar conteúdo interno por interface raw. No contexto corrente não há nomes/arquivos confiáveis para reivindicar 1/9.

**Inventário:** `R21_NOVE_ORIGINAIS_PENDENTES.json` discrimina sete slots do grupo Armas/Técnicas/Artefatos/Inscrições/Matrizes e dois Fogo (`01–12`, `13–24`). Esses nomes dos dois lotes são **rótulos históricos**, não basenames reais recuperados. **Nove fontes individualmente autenticadas: 0/9.** Não foram criadas cópias que se apresentem como originais.

**O que existe com identidade real:**

| Objeto | Identidade física/indexada | Limite |
|---|---|---|
| Derivado união 198, v05 | `/Comestre/DMG-CORPUS-130x111-UNION-198-v05.csv`, `libfile_cbbdcaefcd2c8191b67b1386ce54b9f7` | Indexado e lido, não prova os nove bytes de origem |
| Derivado histórico 87, v04 | `DMG-I0003-87-SUBCONJUNTO-ID-RECONCILIADO-v04.csv`, `libfile_72a79e090de4819198d246cdeea6a7bd` | IDs agregados, sem partição física das sete fontes originais |
| Manifesto local 111, v03 | `OP-DMG-F1-MANIFESTO-LOCAL-111-v03.csv`, `libfile_b77e8ce2ae9c81918664a4acc1a203ae` | Não é original I0003; contém 43 Fogo comuns |
| União parcial anterior, v04 | `DMG-CORPUS-87x111-UNION-PARCIAL-v04.csv`, `libfile_faf2055e307c8191aaf0b542051e1119` | Inventário derivado anterior |

**Reconciliação determinística R21** (`build_r21.py` lendo R20 original imutável): 87 páginas `W` históricas + 43 páginas `F` históricas = **130**; manifesto local = **111**; interseção = **43**; conjunto final = **130+111−43=198**. Nenhuma duplicação interna entre 198; **104/104** IDs da coorte conhecida pertencem a eles. Diff nominal com 198 do R20 = **0 IDs faltantes, 0 espúrios**. Não se interpretou esse cálculo como autenticidade dos nove originais.

As **46 fórmulas** continuam sendo **ocorrências** de **20 páginas**: 12 dentro dos 198 (8 fontes locais e 4 histórico-armas) e 8 páginas fora desse conjunto delimitado; nenhuma soma produzida de 206 fontes globais. Persistem `effect_RE` e `effect_FIP` desconhecidos quando não comprovados. `R21_198x46_NOMINAL_LEDGER.csv` e `R21_46_FORMULAS_LEDGER.csv` preservam uma linha por ID e ocorrência.

**Decisão técnica preferível:** buscar uma cópia autorizada do ZIP bruto do predecessor I0003 ou IDs da Biblioteca dos originais e fazer 9× SHA/sets. Repetir busca textual por termos genéricos não gera evidência nova; após triagem esgotada, redirecionar esforço a ficha/cena real e a outros contratos B.

## 3. P0 paralelo — cinco critérios prioritários

| Critério | Evidência nova ou melhor delimitada | Teste/contraexemplo | Resultado |
|---|---|---|---|
| **B05** — inventário legal completo | Macaco tem Patada, Mordida, Poder Elemental **10PA**, Manipulação Mágica, Titânica, Telepatia. Ação Padrão e Reação por regra. | Rejeita custo 0 inferido para Patada; Poder Elemental não ganha tag Gelo por pai. | **PARTIAL**, faltam economia e menu legal integral |
| **B08** — acerto + perícias | Liu normal `2d6+37`/FOR29 e transformada `2d6+48`/FOR40 têm **residual agregado +8 em ambas**. | Calcula 37−29=48−40=8, mas não afirma `Luta=8`; Macaco Luta ausente. | **PARTIAL**, falta seleções e rolamento real |
| **B11** — interação de crítico | Crítico físico exige ordem 6,6,5/6; **magia não recebe crítico comum**, salvo exceção expressa; Patada física `2d6+54` poderia ganhar +12 de dados máximos. | `(6,5,6)` não é crítico; magia com 6,6,6 não recebe crítico comum. | **PARTIAL**, falta precedência Crítico Brutal +2, Decepadora, margem e cena |
| **B12** — DoT/status | Adaga ON: falha CON CD25 → **3d12 veneno por turno**, um tick de 3–36 (média19,5); Fúria Liu custo12PA ao chegar à metade da Vida. | Não supor duração ou salvaguarda falha sem evento; HP118/235 ainda acima da metade. | **PARTIAL**, falta tick, duração, ledger e status real |
| **B15** — fraqueza elemental | Exemplo **oficial** misto: `1d8 físico+2d6 Fogo` → `1d8 físico+5d6 Fogo` quando fraqueza Fogo, DME11,5→22; Behemoth apresenta fraqueza Fogo. | Bônus +3d6 só no Fogo, não +3d8 no físico; elemento da espécie não etiqueta toda ação. | **PARTIAL**, falta ataque/target/RD/tag/epoch reais |

Todos os cinco contratos foram confrontados com fontes primárias do [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0), [Sistema de Magia](https://app.notion.com/p/3ebc2b324ede81f7b343f7270ff91373), [Liu Mestre](https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010), [Macaco](https://app.notion.com/p/301c2b324ede828caccb813d3979267a), [Adaga Ouro Negro](https://app.notion.com/p/3edc2b324ede811787a0de913622b14d), [Behemoth](https://app.notion.com/p/1fdc2b324ede82bd9d4f811abb689440) e [Raposa](https://app.notion.com/p/4d0c2b324ede827b9925018be01e60ca). A ficha textual é fonte documental, mas **não é um evento de combate com autorização**. Para todos os detalhes, ver `R21_CINCO_CONTRATOS_ANALISE.md`.

### 3.1 Prova ponta a ponta com parâmetros documentados (e fronteira negativa)

- Fonte ator: Macaco Rei Prata5, dano Patada `2d6+FOR`, FOR literal54, natureza **impacto**.
- Fonte regra: Sistema de Combate, Crítico **3d6 sequencial** e dano de ataque físico acrescenta o máximo dos dados da expressão original.
- Condição matemática de exemplo **sem alegar ocorrência real**: sequência crítica `(6,6,5)` satisfaz, `(6,5,6)` não satisfaz. Para a Patada física de referência, máximo do componente 2d6=12, então **`2d6+54 → 2d6+66`** é a transformação algébrica aplicável se um crítico físico legal ocorrer. `all_critical_outcomes()==2` entre 216 triplas equiprováveis.
- Verificação: importação de funções exatas do oráculo R13, mais testes dirigidos R21; contraexemplo de magia sob regra especial evita falso crítico.
- **Veredito correto:** regra aritmética condicional = **PASS MATEMÁTICO**; contrato B11 **PARTIAL**, pois margem, item/Crítico Brutal, Luta, evento e fonte congelada não estão certificados. Esse percurso não pode ser apresentado como combate ou PASS B11.

### 3.2 B14, B17, B04, B09 e STRICT

**B14:** Behemoth reflete15% de dano recebido que não seja magia/projétil, custa20PA+3PA/turno e dá +3CA. `81×0,15=12,15` mostra ausência de arredondamento explícito; ordem bruto/mitigado e gatilho realmente ocorrido não constam de um receipt. Não confundir com Refletir Magias, que é outro efeito de Reação/50%. B14 permanece NOT-TESTED **integral**.

**B17:** Sistema de Magia pune tentativa de conjuração com PA Livre insuficiente com inconsciência 2d10 dias e descrição de morte **na prática** em combate, sem formalizar que houve morte literal ou que o encontro terminou. Sem evento real e condição oficial de vitória/fuga/inconsciência registrada, B17 NOT-TESTED integral.

**B04:** `Perdido−46` sem timestamp; a soma impressa73 não comprova PA Livre no início nem ação pagável. **B09:** CA46/60 e esquiva impressa49/63, mas proficiências e reação escolhidas desconhecidas; após Ação Completa reação normalmente indisponível. Cálculos condicionais não promovem B04/B09.

**STRICT:** **0/2**. O primeiro par Liu×Macaco carece de `scene_id, effective_at, SOURCE-SHA, actor-form, PA timeline, Luta/Fortitude/Reflexo, HP/Alma vigente, ações e custo, map+LOS, iniciativa, RNGeffects, mitigation, replay/ACK e NAC-PASS`; o segundo carece ainda de par de fontes/escopo de cena selecionado e de log oficial. O responsável CM-000006 não foi acionado como writer nem teve motor modificado.

## 4. Matriz integral B01–B18

**Artefato completo:** `R21_B01_B18_LEDGER.json` e `.csv`: 18 predicados sem reescrita, fontes, estado R20, estado R21, evidência nova, bloqueio mínimo, teste e próximo ato. Resumo:

| Estado R21 | Critérios | Quantidade |
|---|---|---:|
| PASS DOCUMENTAL | B02 (rank/nome/Titã, escopo bounded) | **1** |
| PARTIAL | B01, B05, B06, B08, B09, B11, B12, B15, B16 | **9** |
| BLOCKED | B03, B04, B07, B10, B13, B18 | **6** |
| NOT-TESTED integral (exame documental feito) | B14, B17 | **2** |

A classificação B02 não comprova os status correntes nem duas lutas completas; os demais não foram alterados por conveniência. Qualquer eventual mudança depende de reabertura da fonte, predicado integral, gate NAC-NORM/NAC-PASS, autorizações, registros e readback.

## 5. QA e recuperação

- `build_r21.py` reusa **somente as saídas originais** do ZIP R20 (`R20_ORIGINAL_READONLY.zip`) e funções copiadas byte-identicamente do oráculo R13, sem dependências de Notion ou web para replay analítico.
- `test_r21_documental.py` realiza **36 testes dirigidos**: SHA R20/R19/R14; 0/9 original; contas 198/104/46; preservação dos predicados; casos positivos/negativos B05/B08/B11/B12/B15; bloqueios B04/B09/B14/B17; 0/2 STRICT.
- `R21_FONTES_MESTRE_READONLY.json` fornece URLs, título e data *as of* consultada, com assertivas curtas; não proclama hash binário de fonte Notion ou *scene freeze*.
- `manifest_R21_SHA256.json` registra SHA256/tamanho dos arquivos do ZIP; a recuperação limpa reexecuta código/testes e compara estado antes/depois. **Hashes SHA256 da projeção derivada não são hashes dos nove CSV primários**.

## 6. GOVERNANÇA — antes/depois, pendências e R22

**ANTES:** R20 198 IDs derivados, 46 fórmulas, 0/9 originais, B02 1/18, 0/2 STRICT. **DEPOIS:** mesmas contagens de evidência primária e certificados, porém com cinco contratos auditados contra regras/fichas primárias e bloqueios precisos; 36 regressões dirigidas, pipeline de recuperação portátil, memória de arquivos preservada sem sobrescrita.

**IBX-69** `Estado=NOVA`/Lida por instância sem preenchimento quando consultada; não foi realizado ACK falso, claim de identidade ou writer de pesquisa. Nenhuma alteração em Notion, Diário, Party, Primeiro, DMG-RANK, VZ/CRAFT ou CM-000006. O gate de sincronização pós-succession permanece **PENDING**, NAC-CONT-03/NAC-PASS terminal HOLD. No fim do turno, o trabalho não prossegue em background.

**Fronteira exata R22:** (1) adquirir manifesto/arquivos brutos originais I0003 autorizados para auditoria 9× SHA, se disponíveis; (2) procurar `scene_id/effective_at` e ledger de PA/ações/defesas de Liu, inclusive `Perdido−46`, confrontar original e atual; (3) obter regra explícita para Crítico Brutal e semântica de tick/duração de veneno, se outra fonte autorizada existir; (4) migrar evidência ao Inbox bilateral apenas após legitimidade, teste de ação e ACK/readback, sem tocar writer protegido; (5) não gastar rodada adicional apenas tentando forçar 9 PASS por simulação.

**Critério de aceite do próximo avanço:** original bruto individual autenticado **ou** contrato B individual concluído com evento/autoridade verdadeiros **ou** nova fonte primária que feche lacuna identificada. O resto pode permanecer BLOCKED justificado sem fingir progresso terminal.
