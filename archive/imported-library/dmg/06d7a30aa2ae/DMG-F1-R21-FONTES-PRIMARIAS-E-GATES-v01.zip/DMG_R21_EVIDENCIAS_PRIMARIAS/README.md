# DMG R21 — fontes primárias e certificação científica, checkpoint local

**Somente Mestre-side, somente sandbox.** Nenhum writer, lease, epoch, ACK ou PASS terminal foi obtido. Nenhum CSV histórico bruto foi criado/renomeado como original. `R20_ORIGINAL_READONLY.zip` é uma cópia bit a bit do R20 e contém a cadeia de artefatos antigos declarada.

Arquivos principais: `R21_RECON_198_AUDIT.json`, `R21_198x46_NOMINAL_LEDGER.csv`, `R21_46_FORMULAS_LEDGER.csv`, `R21_NOVE_ORIGINAIS_PENDENTES.json`, `R21_FONTES_MESTRE_READONLY.json`, `R21_TESTES_PONTA_A_PONTA.json`, `R21_B01_B18_LEDGER.json`, `R21_B01_B18_LEDGER.csv`, `R21_CINCO_CONTRATOS_ANALISE.md`, `R21_B04_B09_B14_B17_E_STRICT.md`, `R21_R20_DELTA_CHECKPOINT.md`, `R21_STRICT_SCENE_GAPS.json`, `R21_HANDOFF_FAST_RESUME.md` e testes.

Há **0/9 CSV I0003 originais brutos autenticados**; a união 198 é prova de projeção derivada indexada, com 46 ocorrências matemáticas em 20 páginas e 12 páginas sobrepostas com o índice histórico. A matriz científica mantém um único PASS documental B02, 0/2 STRICT e NAC-PASS HOLD.

Executar `python -m unittest discover -s . -p 'test_r21_documental.py' -q` a partir da extração limpa do ZIP R21, sem depender de `/mnt/data` de outro chat. O código `build_r21.py` recalcula os ledgers diretamente dos membros do `R20_ORIGINAL_READONLY.zip` incluído, e reutiliza funções do oráculo R13 via cópia comprovadamente byte-idêntica `r13_oracle.py` sem reconstruí-lo. Resultados e hashes no manifesto do ZIP.
