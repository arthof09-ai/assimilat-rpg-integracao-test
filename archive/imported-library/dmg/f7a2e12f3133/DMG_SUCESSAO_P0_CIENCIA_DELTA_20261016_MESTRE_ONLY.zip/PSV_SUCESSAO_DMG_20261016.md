# PSV DE SUCESSÃO — OP-DMG-CORPUS-EMP-01 — MESTRE-SIDE

**AS-OF:** 2026-10-16 (sucessão nesta instância; evidências com datas históricas preservadas).  
**OPERATION:** OP-DMG-CORPUS-EMP-01; histórico CM-000001/DMG, sem reuso ou posse de INSTANCE-ID.  
**BASELINE:** DMG-RANK-01 v1.1 OFICIAL/INALTERADA.  
**PREDECESSOR-LAST-VERIFIED:** DMG-F0-CIENCIA-P0-20261016 / 81.017 bytes / SHA256 `397cd335096270ee180b834abb2074b84de68909821ffd6192cac8653fdc6a62` / 35 entradas / 34 manifestadas / 1.616 testes anteriores relatados no auditor certificado.  
**SUCCESSOR-FIRST-VERIFIED:** Materialização no runtime independente, tamanho, SHA256 externo, ZIP CRC e 34/34 arquivos internos verificados individualmente por hash e tamanho; leitura de handoff e produtos-chave.  
**LAST-VERIFIED-UNIT:** experimento local de limiares RD exatos para oito pares da coorte R02 e auditoria dos 212 recibos de ataque/efeito VLAB R116, recebidos somente em READ-ONLY, verificados por hashes e matemática de lançamentos.  
**FIRST-PENDING:** F0-A5 snapshots byte-exatos pós-upload 0/7; A6 crosswalk nominal 571 não materializado; A7 independência cega 0/8; A8 segunda codificação/writer HOLD.  

## DENOMINATORS E GATES (ANTES → DEPOIS)

- **F0:** 4/8 → **4/8 formal**, 0 PASS institucional novo. Os marcos A1–A8 são crosswalk operacional, não declaração de oito PASS individualizados canônicos.
- **A5:** corpos Notion sete anexados em histórico, download pós-upload 0/7 → 0/7 certificado; rota `notion_download_attachment` não repetida sem técnica realmente diferente.
- **A6:** oito raízes 332 IDs diretos; 12 ramos 239 IDs diretos; união 571 declarada em pacote, **lista individual não incluída** → 571 declarados, não promovidos a 571 cobertos. D0 global indeterminado.
- **A7:** oito candidatos em pré-reserva, zero independentemente cegos → idêntico, não revelados nesta análise.
- **A8:** writer/lease/epoch/instance/collision e segundo codificador não reconciliados → HOLD.
- **Histórico R02:** 22 ações/15 páginas, 8 pares intra-página agrupados em 6 páginas; reutilizados sem nova observação de campo. Nova exploração: 388 pontos RD exatos, 8 pares, 1 inversão estrita entre as oito comparações condicionais ao RD 31 (já exemplificada anteriormente), nenhuma inversão adicional no universo de inteiros RD=0 até a anulação total de ambos os efeitos em cada par. Auditor independente por enumeração direta: 2.948 verificações aritméticas PASS (inclui recibos R116).
- **VLAB R91:** 884 recibos/48 execuções espelhadas/24 blocos históricos; não recontados como novos.
- **VLAB R97:** 1.344 recibos em 24 RUNs / 12 blocos espelhados; R93/R95 `HISTORICAL_TECHNICAL_PASS / NORMATIVE_PARITY_HOLD`, 6 críticos com fórmula antiga errada; original imutável.
- **VLAB R112/R116/R117:** R116 read-only, 212 eventos ofensivos de seis run-ledgers, três seeds numéricas espelhadas, dois tipos de cenário (208 ataques normais + 4 especiais). Resultados originários do VLAB; DMG não executou combates. Nova recomposição DMG: 27.232 bruto após crítico/save, 7.958 mitigação RD aplicada, 19.274 potencial após RD, 18.806 HP efetivo, 468 overkill, PA gasto 220. Não tratar os 212 eventos ou seis espelhos como trials independentes.
- **Plano Supremo:** 19/19 fases previstas; F0 ATIVA 4/8, F1 descoberta exploratória e F4/F8/F9 evidência local não terminal; F13 candidata não autorizada por pesquisa exploratória; F14–F18 HOLD dependente.
- **D0–D9:** globais não determinados; categorias pages/abilities/components/occurrences/attacks separadas.

## PROVA CIENTÍFICA NOVA NA SUCESSÃO

Uma investigação exaustiva, por inteiro RD, das fórmulas R02 *preexistentes* dentro de cada mesma página detectou oito pares (seis páginas únicas) e isolou **apenas um intervalo de inversão estrita do ordenamento por dano médio bruto**: Escorpião de Diamante, `Rabada 1d6+1d4+FOR22` vs `Corte 1d6+DES25`: bruto 28 vs 28,5; RD=30 empate de pós-RD; RD=31, Rabada 1/24 > Corte 0; RD=32 ambas 0. Essa inversão já havia sido exemplificada no P0, portanto o resultado novo é a **checagem exaustiva dos intervalos** para todos os oito pares, e não a descoberta original da inversão. Os demais sete pares não invertiram no domínio de RD analisado. **Isso não implica prevalência populacional:** fonte selecionada, fórmulas historicamente transcritas, conflitos de título/corpo e mistura possível de tipos de dano; RD uniforme só é admissível quando a defesa é aplicável a ambas.

A origem Notion `92bc2b324ede834ca813812ff4783805` foi reaberta e confirma as fórmulas literais sob a página `Bronze 5`, mas a página-pai se chama Escorpião de Diamante enquanto o corpo nomeia `escorpião Ártico`. Isso constitui **CONFLICT** que não foi corrigido. Nada neste estudo infere o RE a partir de RN ou promove efeitos oficiais. Ver `THRESHOLD_RD_PAIR_MAP.json`, `THRESHOLD_RD_EXACT_CURVES.csv` e scripts.

## CONFLICTS / UNKNOWN-EFFECT / NO-REPEAT

**CONFLICTS:** Escorpião de Diamante vs corpo escorpião Ártico; demais fontes histórico com título/corpo/ancestral conflitantes; baseline de Criação de Ficha e Transformação Espiritual de 07/10 vs versões atualizadas em 09/10; casos de crítico R93/R95; Fraco/esforço final com fonte e políticas incompletas; regras de meia-dano ímpar, iniciativa Besta, transformação Auren pendentes em VLAB.  
**UNKNOWN-EFFECT:** nenhuma escrita canônica tentada pelo sucessor; nenhuma alteração remota solicitada. Incidentes R109/R110/R115 VLAB preservados e explicitamente não repetidos; exame somente de leitura.  
**NO-REPEAT:** não repetir 1.616 testes P0 como novos, nem 148 históricos, nem 220 cenários RD, 160 contrastes, 7 hashes antigos, 8 holdouts, R02/R03/R04 como novos dados, R91/R97/R112 como novos combates. Não ACK ou modificar OP VLAB.

## AUTHORITY/WRITER STATE

OP/Diário/Inbox vistos em Notion MESTRE-SIDE. IBX-102 explicitamente `ROUTING_ONLY; DMG writer NÃO CONCEDIDO`. A sucessão não recebeu instância, claim, writer, lease, epoch ou fencing materialmente provados. **SHARED WRITE = HOLD**. O pacote novo está apenas no sandbox local disponibilizado ao Mestre; não enviado para Notion ou Biblioteca persistentemente. Party, O Primeiro, regras, fichas e originais intactos. A origem MESTRE-SIDE permanece a fronteira.

## NEXT-5 E TARGET-REMAINDER

1. Recuperar os anexos 7/7 por rota de bytes autorizada e efetivamente nova, comparando hashes contra o manifesto histórico; se impossível, novos snapshots atuais separados e marcar A5 HOLD.
2. Materializar crosswalk 571 IDs com cada ID, raiz, família, espelho, versão, sobreposições e dedup; não chamar 571 de corpus global.
3. Auditar aliases/famílias dos oito holdouts sem abertura cega; buscar avaliador independente formal.
4. Reconciliação competente de Assignment/INSTANCE-ID, writer/lease/epoch/collision e segundo codificador; sem ACK até GREEN comprovado.
5. Continuar F4/F8/F9 em fonte ofensiva completa e aplicar v1.1 em TEST **somente** se ausência de dano, RE/FIP e precedência explicitamente admissíveis; comparar tipos/RD/acerto/recursos; R116/R117 fica coorte VLAB separada.

**TARGET-REMAINDER:** F0 A5–A8 + D0–D9 + gate correspondente F1–F12; F13–F18 sob critérios originais Mestre/NAC.  
**NAC-PASS:** integridade do ZIP histórico, cálculos novos, verificação de R116 e registro local PASS *no escopo declarado*; fase F0 terminal, governança de writer, homologação de VLAB, produção, promoção normativa = HOLD.

### Linhagem / fontes

- P0 Biblioteca: `/Comestre/OP-DMG-CORPUS-EMP-01/DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip`.
- OP Notion: https://app.notion.com/p/3f3c2b324ede813e9fa0c87ebdea0b29
- Inbox IBX-102: https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25
- DMG-RANK v1.1: https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e
- Fonte escorpião conflictual: https://app.notion.com/p/92bc2b324ede834ca813812ff4783805
- VLAB R116/R117 Biblioteca: `/Comestre/OP-VLAB-FUSION-SANDBOX-01/VLAB_R108_R117_NATIVE_CRITICO_FRACO_DESCARGA_MESTRE_ONLY.zip`.

## IDENTIDADE DA ENTREGA

**RECUPERADO:** pacote P0 íntegro e dados VLAB R97/R116/R117 (em cópias locais verificadas). **RECONSTRUÍDO:** nenhuma versão histórica inacessível foi alegada restaurada. **RELATADO / PARCIAL:** 571 IDs sem lista, anexos 7/7 sem readback bytes, holdout sem cegamento e status de autoria/writer. **NOVO E VERIFICADO:** sweep RD integral dos oito pares e recomputação dos 212 recibos de R116, com artefatos, critérios e scripts de auditoria independentes. Nenhuma nova batalha executada.
