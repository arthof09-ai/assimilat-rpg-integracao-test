from pathlib import Path
from itertools import product
from collections import Counter,defaultdict
import json,csv,re,hashlib
base=Path(__file__).resolve().parent
src=base.parent/'p0/readonly_sources/R02_DAMAGE_A_B_C.csv'
curve=list(csv.DictReader((base/'THRESHOLD_RD_EXACT_CURVES.csv').open()))
orig={ (r['page_id'],r['attack']):r for r in csv.DictReader(src.open()) }
counts={}
for key,r in orig.items():
    f=r['formula_original'].lower()
    terms=[(int(a),int(b)) for a,b in re.findall(r'(\d+)d(\d+)',f)]
    fixed=int(r['attribute_printed_value'] or 0)
    remainder=re.sub(r'\d+d\d+','',f)
    fixed+=sum(int(t) for t in re.findall(r'\+(\d+)',remainder))
    spaces=[range(1,face+1) for n,face in terms for _ in range(n)]
    counts[key]=[sum(x)+fixed for x in product(*spaces)]
checks=0
for x in curve:
    pg=x['source_page_id'];a=counts[pg,x['ability_a']];b=counts[pg,x['ability_b']];rd=int(x['rd'])
    for name,arr in [('a',a),('b',b)]:
        exact=sum(max(0,n-rd) for n in arr)/len(arr)
        p=sum(n>rd for n in arr)/len(arr)
        assert abs(float(x['expect_'+name])-exact)<1e-9
        assert abs(float(x['p_positive_'+name])-p)<1e-9
        checks+=2
    # E[(X-r)+] is nonincreasing and convex in integer r
    if rd>0:
        for arr in (a,b):
            dif=sum(max(0,n-rd+1) - max(0,n-rd) for n in arr)/len(arr)
            assert 0<=dif<=1
            checks+=1

recfile=base.parent/'vlab/R116_DMG_NATIVE_RECEIPTS_212.csv'
recs=list(csv.DictReader(recfile.open()))
assert len(recs)==212
runs=defaultdict(list)
for r in recs:
    runs[r['run_id']].append(r)
    raw=int(r['actual_raw_after_crit_and_save']);rd=int(r['RD_applied']);pot=int(r['potential_after_RD']);hp=int(r['actual_HP_taken']);over=int(r['overkill'])
    assert max(0,raw-rd)==pot,(r['run_id'],r['event_seq'])
    assert pot==hp+over
    assert int(r['before_HP_target'])-int(r['after_HP_target'])==hp
    checks+=3
assert len(runs)==6
stats=[]
for rid,rs in sorted(runs.items()):
   s={'run_id':rid,'experiment':rs[0]['experiment_type'],'seed':rs[0]['seed'],'side':rs[0]['side'],'n_offensive_events':len(rs),'n_normal_attacks':sum(r['event_kind']=='NATIVE_ATTACK' for r in rs),'n_spell_events':sum(r['event_kind']=='NATIVE_SPECIAL' for r in rs),'n_positive_crits':sum(r['critical_status']=='POSITIVE' for r in rs),'n_weak_attacks':sum(r['weak_attacker']=='True' for r in rs),'n_final_efforts':sum(r['final_effort_option']=='True' for r in rs),'raw_after_crit_saves':sum(int(r['actual_raw_after_crit_and_save']) for r in rs),'rd_removed_effective':sum(int(r['actual_raw_after_crit_and_save'])-int(r['potential_after_RD']) for r in rs),'post_rd_potential':sum(int(r['potential_after_RD']) for r in rs),'hp_actual':sum(int(r['actual_HP_taken']) for r in rs),'overkill':sum(int(r['overkill']) for r in rs),'pa_spent':sum(int(r['pa_spent']) for r in rs),'source_status':'VLAB controlled copy, read-only external; not current campaign'}
   stats.append(s)
assert sum(s['n_offensive_events'] for s in stats)==212
assert sum(s['pa_spent'] for s in stats)==220
assert len({s['seed'] for s in stats})==3
artifact={'operation':'OP-DMG-CORPUS-EMP-01','date':'2026-10-16','status':'NEW_VERIFIED_LOCAL_ROLLUP_OF_EXISTING_VLAB_RECEIPTS_NOT_NEW_COMBATS','origin':'OP-VLAB-FUSION-SANDBOX-01 R116 CSV inside R117 ZIP','input_sha256':hashlib.sha256(recfile.read_bytes()).hexdigest(),'critical_errata':'R93/R95 historic norm parity HOLD, kept separate from R112 controlled copy','runs':stats,'rollup':{'runs':6,'numeric_seed_values':3,'mirror_pairs':3,'attacks':sum(s['n_normal_attacks'] for s in stats),'specials':sum(s['n_spell_events'] for s in stats),'pa':220,'raw_damage_after_crit_and_saves':sum(s['raw_after_crit_saves'] for s in stats),'rd_effective_removed':sum(s['rd_removed_effective'] for s in stats),'post_rd_potential':sum(s['post_rd_potential'] for s in stats),'hp_actual':sum(s['hp_actual'] for s in stats),'overkill':sum(s['overkill'] for s in stats)},'limitations':['three selected numeric seeds, six mirrored runs, only two scenarios','no official v1.1 efficacy implication; no generalized victory probability','effort condition artificially created, not an ordinary full fight','existing VLAB engines executed events, DMG only audited CSV math','R93/R95 never blended with R112']}
(base/'R116_VERIFIED_DMG_ROLLUP.json').write_text(json.dumps(artifact,indent=2,ensure_ascii=False),encoding='utf8')
print('INDEPENDENT_CHECKS',checks,'CURVE_ROWS',len(curve),'R116_RUNS',len(runs),'R116_ROLLUP',artifact['rollup'])
