"""NEW exploratory RD threshold maps, not official damage nor live combat.
Input: immutable P0 R02 CSV. Exhaustive dice enumeration, grouped by page.
"""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import product,combinations
import csv,re,json,hashlib,math
BASE=Path(__file__).resolve().parent.parent/'p0/readonly_sources/R02_DAMAGE_A_B_C.csv'
OUT=Path(__file__).resolve().parent
rows=list(csv.DictReader(BASE.open(encoding='utf-8')))
assert len(rows)==22

def pmf(r):
 f=r['formula_original'].lower().replace(' ','')
 dice=[int(x) for x in re.findall(r'(\d+)d(\d+)',f) for x in []] # parsed below
 terms=[(int(n),int(face)) for n,face in re.findall(r'(\d+)d(\d+)',f)]
 assert terms, f
 base=int(r['attribute_printed_value']) if r['attribute_printed_value'] else 0
 erased=re.sub(r'\d+d\d+','',f)
 if re.search(r'\+\d+',erased):base+=sum(int(n) for n in re.findall(r'\+(\d+)',erased))
 outcomes=Counter({base:1})
 for n,face in terms:
  for _ in range(n):
   nxt=Counter()
   for v,mult in outcomes.items():
    for d in range(1,face+1):nxt[v+d]+=mult
   outcomes=nxt
 return outcomes

def mean_after(c,rd):return sum(max(0,n-rd)*v for n,v in c.items())/sum(c.values())

def positive(c,rd):return sum(v for n,v in c.items() if n>rd)/sum(c.values())

by_page=defaultdict(list)
for r in rows:
 c=pmf(r); r['pmf']=c; r['mean_exhaustive']=mean_after(c,0)
 assert abs(r['mean_exhaustive']-float(r['gross_conditional_on_hit']))<1e-8,(r['species'],r['attack'])
 by_page[r['page_id']].append(r)

pairs=[]; curves=[]
for pg,rs in by_page.items():
 for a,b in combinations(rs,2):
  ca,cb=a['pmf'],b['pmf']
  # extend beyond support to prove zero thereafter
  maxrd=max(max(ca),max(cb))+1
  changes=[]; old=None; pos=[]; neg=[]; ties=[]
  for rd in range(maxrd+1):
   ma,mb=mean_after(ca,rd),mean_after(cb,rd)
   diff=ma-mb
   sign=(diff>1e-10)-(diff< -1e-10)
   if old is not None and sign!=old:changes.append({'rd':rd,'new_sign':sign,'delta':round(diff,9)})
   old=sign
   (pos if sign>0 else neg if sign<0 else ties).append(rd)
   curves.append({'source_page_id':pg,'source_name':a['species'],'ability_a':a['attack'],'ability_b':b['attack'],'rd':rd,'expect_a':round(ma,12),'expect_b':round(mb,12),'p_positive_a':round(positive(ca,rd),12),'p_positive_b':round(positive(cb,rd),12)})
  grossdiff=a['mean_exhaustive']-b['mean_exhaustive']
  inverse=[r for r in (neg if grossdiff>0 else pos if grossdiff<0 else [])]
  pairs.append({'source_page_id':pg,'source_name':a['species'],'rank_title':a['title_rank'],'rank_body':a['body_rank'],'rank_ancestor':a['ancestor_rank'],'source_rank_conflict':len({a['title_rank'],a['body_rank'],a['ancestor_rank']})>1 or len({b['title_rank'],b['body_rank'],b['ancestor_rank']})>1,'ability_a':a['attack'],'ability_b':b['attack'],'formula_a':a['formula_original'],'formula_b':b['formula_original'],'gross_difference_a_minus_b':round(grossdiff,6),'rd_min':0,'rd_max_inclusive':maxrd,'positive_rds':pos,'negative_rds':neg,'tie_rds':ties,'rd_inverse_gross_order':inverse,'sign_changes':changes,'grouped_source_unit':'single page, not two independent creatures'})

meta={'operation':'OP-DMG-CORPUS-EMP-01','as_of':'2026-10-16','baseline':'DMG-RANK-01 v1.1 untouched','status':'NOVO E VERIFICADO LOCALMENTE / ANALISE EXPLORATORIA DE FONTE HISTORICA REUSADA','input_csv':'readonly_sources/R02_DAMAGE_A_B_C.csv','input_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'source_pages':len(by_page),'abilities':len(rows),'pair_comparisons':len(pairs),'pair_clusters':len({x['source_page_id'] for x in pairs}),'threshold_rows':len(curves),'assumptions':['all literal dice fair, independent within attack','printed attribute numerically fixed only when present','post-RD net=max(0,gross-RD), one single RD applied to total for compatible type','conditioned on a successful hit; not CA, saves, resistance-specific, PA, crit, death, turn, official combat','no inferential claim from historical selected 22 abilities','no second coder or evidence of source version beyond previous P0 provenance','rank conflicts left unresolved']}
meta['pairs_with_strict_gross_reversal']=sum(bool(x['rd_inverse_gross_order']) for x in pairs)
meta['pairs_with_any_sign_transition']=sum(bool(x['sign_changes']) for x in pairs)
(OUT/'THRESHOLD_RD_PAIR_MAP.json').write_text(json.dumps({'metadata':meta,'pairs':pairs},indent=2,ensure_ascii=False),encoding='utf8')
with (OUT/'THRESHOLD_RD_EXACT_CURVES.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.DictWriter(f,fieldnames=curves[0].keys());w.writeheader();w.writerows(curves)
print(json.dumps(meta,ensure_ascii=False,indent=2));
for p in pairs:
 print(p['source_name'],p['ability_a'],'vs',p['ability_b'],'grossdiff',p['gross_difference_a_minus_b'],'inversion',p['rd_inverse_gross_order'][:5],'-',p['rd_inverse_gross_order'][-5:],'transitions',p['sign_changes'])
