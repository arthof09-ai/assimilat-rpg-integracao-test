import csv,io,json,zipfile,statistics,math,hashlib,pathlib,collections
ROOT=pathlib.Path(__file__).resolve().parent
C05=zipfile.ZipFile('/mnt/data/DMG_C05_CIENCIA_R160_20261017_MESTRE_ONLY.zip')
C10=zipfile.ZipFile('/mnt/data/DMG_C10_REACOES_DEFESA_E_DANO_UTIL_20261018_MESTRE_ONLY.zip')
rows=list(csv.DictReader(io.StringIO(C05.read('C05_DAMAGE_EFFECTS_NORMALIZED_58.csv').decode())))
comp=list(csv.DictReader(io.StringIO(C05.read('C05_DAMAGE_COMPONENTS_EXACT.csv').decode())))
assert len(rows)==58
hp=[r for r in rows if r['effect_channel']=='VIDA' and r['gross_mean_conditional']]
assert len(hp)==16,len(hp)
parts=collections.defaultdict(list)
for c in comp:parts[c['effect_id']].append(c)
for r in hp:
 r['mean']=float(r['gross_mean_conditional']);r['dice_mean']=sum(float(c['mean']) for c in parts[r['effect_id']] if c['kind']=='DICE');r['attr_mean']=sum(float(c['mean']) for c in parts[r['effect_id']] if c['kind']=='ATTRIBUTE');r['attr_share']=r['attr_mean']/r['mean'];r['source_url']=r['url']
assert all(abs(r['dice_mean']+r['attr_mean']-r['mean'])<1e-9 for r in hp)
# Independent exact moments for n d s + k, no simulated samples
sources=[
 ('Gambá Demoníaco','Arranhão Putrificador',[(2,6)],25,'Prata 1','https://app.notion.com/p/966c2b324ede83d7962b019b1861b6b1','VERIFICADO','DES'),
 ('Mamute Antigo','Chifrada',[(2,6),(2,4)],22,'Prata 1','https://app.notion.com/p/92bc2b324ede828f9b040180a09d926d','VERIFICADO','FOR'),
 ('Varok','Raiz-Ferro equipado',[(10,10)],48,'Ouro Negro 5 / item Lendário','https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091','PROPOSTO_MESTRE_SIDE','FF23_INCLUDED'),
 ('Iskiel','Arco equipado',[(9,8)],47,'Ouro Negro 5 / item Lendário','https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966','PROPOSTO_MESTRE_SIDE','FF21_INCLUDED'),
 ('Veyun','Prisma Terra',[(8,10)],26,'Ouro Negro 5 / item Lendário','https://app.notion.com/p/3f6c2b324ede819e879beabb795001ba','PROPOSTO_CONFLICT_FF','NO_FF_BY_CLAUSE'),
 ('Varok','Quebra do Tronco (rider)',[(6,12)],0,'item Lendário','https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091','PROPOSTO_MESTRE_SIDE','60PA_AFTER_HIT_ONCE_SCENE'),
 ('Iskiel','Mergulho Cortante (rider)',[(5,10)],0,'item Lendário','https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966','PROPOSTO_MESTRE_SIDE','45PA_WIND_FLIGHT20M'),
]
def moments(ds,k):
 return {'min':k+sum(n for n,s in ds),'max':k+sum(n*s for n,s in ds),'mean':k+sum(n*(s+1)/2 for n,s in ds),'variance':sum(n*(s*s-1)/12 for n,s in ds),'dice_mean':sum(n*(s+1)/2 for n,s in ds),'fixed':k}
new=[dict(entity=e,effect=h,dice='+'.join(f'{n}d{s}' for n,s in ds),rank=r,source=url,state=state,component_note=note,**moments(ds,k)) for e,h,ds,k,r,url,state,note in sources]
assert new[0]['mean']==32 and new[1]['mean']==34 and new[2]['mean']==103 and new[3]['mean']==87.5 and new[4]['mean']==70
# Within page pair; rank triple only Escorpiao
pairs=[]
for page,rr in collections.defaultdict(list,((p,[x for x in hp if x['page_uuid']==p]) for p in set(x['page_uuid'] for x in hp))).items():
 if len(rr)>1:
  rr=sorted(rr,key=lambda r:r['mean']);pairs.append({'source':rr[0]['url'],'rank_title':rr[0]['rank_title'],'rank_body':rr[0]['rank_body'],'rank_ancestor':rr[0]['rank_ancestor'],'triple':rr[0]['rank_triple'],'low':rr[0]['name_literal'],'low_mean':rr[0]['mean'],'high':rr[-1]['name_literal'],'high_mean':rr[-1]['mean'],'difference':rr[-1]['mean']-rr[0]['mean'],'ratio':rr[-1]['mean']/rr[0]['mean']})
# Historical Prata strict and contaminated alternative
sensitivity=json.loads(C05.read('C05_COHORT_STRATA_AND_SENSITIVITY.json'))
strict=sensitivity['C04_triple_P1_gross_means'];relaxed=sensitivity['C05_new_title_body_Prata1_ancestor_conflicted']
assert len(strict)==6 and len(relaxed)==5
# Separate rank/RE: do not assert that ON5 user or L item means L rank effect
rank_bands={'Bronze':[4,18],'Prata':[14,36],'Ouro':[22,62],'Ouro Negro':[38,96],'Lendário':[58,160]}
# source-intrinsic only, excluding user FF/attribute, no claim RE/FIP eligibility
bench=[{'entity':'Varok','equipped_mean':103,'item_intrinsic_mean':80,'user_FF':23,'hypothetical_L_band':[58,160],'RE_FIP_adjudicated':False}, {'entity':'Iskiel','equipped_mean':87.5,'item_intrinsic_mean':66.5,'user_FF':21,'hypothetical_L_band':[58,160],'RE_FIP_adjudicated':False},{'entity':'Veyun','equipped_mean':70,'item_intrinsic_mean':70,'user_FF':'CONFLICT_LITERAL_PLUS6_NOT_APPLIED','hypothetical_L_band':[58,160],'RE_FIP_adjudicated':False}]
# controlled comparisons
cost=[{'pair':'Varok normal vs Quebra','base_mean':103,'extra_mean':39,'total_gross_mean':142,'extra_PA':60,'extra_mean_per_PA':39/60,'constraint':'hit, once/scene, no second attack, RD composite unresolved'}, {'pair':'Iskiel normal vs Mergulho','base_mean':87.5,'extra_mean':27.5,'total_gross_mean':115,'extra_PA':45,'extra_mean_per_PA':27.5/45,'constraint':'hit, flight >=20m, once/turn, wind RD unknown'}]
assert cost[0]['total_gross_mean']==142 and cost[1]['total_gross_mean']==115
report={'scope':'C11 source-scoped diagnosis, not global RPG census','C05_effect_rows':len(rows),'C05_hp_formula_effects':len(hp),'C05_hp_distinct_pages':len(set(r['page_uuid'] for r in hp)),'C05_numeric_components':len(comp),'C05_hp_attribute_effects':sum(r['attr_mean']>0 for r in hp),'C05_attribute_dominance':sum(r['attr_share']>.5 for r in hp if r['attr_mean']>0),'C05_hp_effects':[{k:r[k] for k in ['page_uuid','source_url','name_literal','formula_literal','rank_title','rank_body','rank_ancestor','rank_triple','mean','dice_mean','attr_mean','attr_share']} for r in hp], 'within_page_pairs':pairs,'C04_strict_Prata1_means':strict,'C05_conflicted_Prata1_means':relaxed,'C04_strict_Prata1_mean':statistics.mean(strict),'C05_conflicted_Prata1_mean':statistics.mean(relaxed),'new_physical_source_analyses':new,'ON5_cost_pairs':cost,'DMG_bands':rank_bands,'item_intrinsic_comparison_NOT_RE_FIP_ADJUDICATED':bench,'confidence':'scoped descriptive; 0 universal balance verdicts; no independent blind holdout'}
(ROOT/'C11_ANALYTIC_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'C11_EFFECT_MATRIX.csv').open('w',encoding='utf-8',newline='') as f:
 keys=['page_uuid','source_url','name_literal','formula_literal','rank_title','rank_body','rank_ancestor','rank_triple','mean','dice_mean','attr_mean','attr_share'];w=csv.DictWriter(f,keys);w.writeheader();w.writerows({k:r[k] for k in keys} for r in hp)
print(json.dumps({k:v for k,v in report.items() if k in ['C05_effect_rows','C05_hp_formula_effects','C05_hp_distinct_pages','C05_numeric_components','C05_hp_attribute_effects','C05_attribute_dominance','within_page_pairs','C04_strict_Prata1_mean','C05_conflicted_Prata1_mean']},ensure_ascii=False,indent=2))
