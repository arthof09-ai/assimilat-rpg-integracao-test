# PSV — DMG C11 / Primeiro diagnóstico empírico de equilíbrio

AS-OF: 2026-10-19 · OPERATION: OP-DMG-CORPUS-EMP-01 · MESTRE-SIDE · BASELINE: DMG-RANK-01 v1.1 INALTERADA · F0: 4/8 · PRODUÇÃO: HOLD

## Mandato e ANTES → DEPOIS
ANTES: C10 era um resolvedor de ataques, defesa, reação, Vida e PA, não um diagnóstico do corpus. DEPOIS: análise reprodutível de 16 fórmulas HP do C05, 3 pares intrapágina, dois subconjuntos Prata 1 separados por proveniência, sete expressões documentadas em cinco páginas Notion reabertas, dois pares PA condicionais, e triagem da aplicabilidade das bandas oficiais. Não há v2, não há nova regra, não há combate VLAB.

## Dez etapas: resultado e fronteira
1. MANDATO: cinco fontes físicas reabertas: OP-DMG-CORPUS-EMP-01, DMG-RANK-01 v1.1, DMG-METHOD-EMP-01, DMG-TAX-DATA-01 e DMG-QA-ACCEPT-01. Autoridade de dano explícito prevalece sobre banda substitutiva. 
2. REUSO: C05 ZIP e C10 ZIP reabertos localmente. C05 58 efeitos, 16 fórmulas de dano à Vida, 13 páginas distintas entre esses efeitos, 34 componentes no arquivo integral incluindo drenagem ALMA. A6 571 é referência histórica estrutural, NÃO censo novo. L002/L003 não autenticados por bytes neste ciclo. R162 e R169 preservados, NÃO agregados.
3. ESTRATOS: natural Prata 1 estrito histórico C04 6 fórmulas; Prata 1 com ancestralidade conflitante C05 5 fórmulas em grupo separado; C05 16 HP, sem extrapolação de rank; três propostas ON5 equipadas Varok/Iskiel/Veyun separadas de Bestas. Pares de técnicas em uma mesma página são dependentes, não observações independentes.
4. MATEMÁTICA: médias, mínimos, máximos, variâncias de dados e decomposição dados/atributo/fixo para 7 expressões de cinco páginas Notion Mestre. Código c11_science.py reproduz; expressões da fonte preservadas no arquivo analítico. Atributos e FF não se confundem com DME intrínseco.
5. OUTLIERS: Escorpião Ártico Bronze5 (tríplice) Corte 1d6+FOR8 = 11,5 vs Rabada 1d4+DES24 = 26,5; diferença 15, razão 2,304; requer contexto de entrega antes de classificar como defeito. Raposa Flamejante Punhos de Fogo 1d4 = 2,5 vs Soco 1d6+FOR20 = 23,5; diferença 21; rank ancestral conflita. C05 15/15 HP com atributo documentado têm participação >50% na média, mas não são amostra independente representativa.
6. FRONTEIRAS: C04 seis Prata1 estritos média 33,6667; C05 cinco Prata1 de título+corpo mas ancestrais conflitantes média 39,7. Misturar grupos geraria média 36,4091 e conclusão não-admissível. Sem adjudicação RN/RE/FIP, progressão Bronze→Lendário não estimável.
7. PA/ENTREGA: Varok equipado 10d10+48 média103, Quebra 6d12 média39, custo60 PA pós-acerto, uma vez/cena; total bruto condicionado142, ganho 0,65 bruto/PA incremental (não dano útil/PA). Iskiel equipado 9d8+47 média87,5, Mergulho 5d10 média27,5, custo45 PA, voo >=20m e acerto, uma vez/turno; total bruto115, ganho0,6111 bruto/PA incremental. Compromisso diário de cada arma 95 PA/dia, não por golpe. Sem RD do Vento ou frequência observada, não concluir eficiência real. Veyun 8d10+26 Terra média70, 65 PA por descarga, 85 PA/dia; sem comparador equivalente de entrega, não inferir eficiência relativa.
8. DMG-RANK v1.1: bandas de DME INTRÍNSECO para efeito padrão, alvo único, Ação Padrão, sem hard control ou bypass maior: Bronze4–18, Prata14–36, Ouro22–62, Ouro Negro38–96, Lendário58–160. Exemplos item Lendário: Varok intrínseco 10d10+25 =80, Iskiel 9d8+26 =66,5, Veyun descarga 8d10+26=70; esses três números caem numericamente na faixa Lendária 58–160, MAS RE/FIP/entrega ainda não adjudicados, logo não são três passes normativos certificados. Equipados 103/87,5/70 NÃO devem ser comparados como DME intrínseco. A DMG-RANK não é recalibração retroativa.
9. HIPÓTESES FALSIFICÁVEIS: H1 dominância de atributo: confrontar ataques da mesma RE/FIP com atributos distintos e comparar DME intrínseco vs final, holdout por família. H2 amplitude intraficha: comparar Rabada/Corte e Punhos/Soco com precisão, alcance, ação, PA e riders; se equivalentes, diferença pede investigação. H3 eficiência: testar marginal pós-RD e frequência de uso de Quebra/Mergulho em condições pareadas pelo VLAB, sem simular no DMG. H4 viés de seleção por rank: adjudicar ancestrais e reestimar grupo estrito, mantendo holdout por espécie. H5 banda intrínseca: identificar RE/FIP documentados e confrontar efeitos sem atributos/FF com bandas, sem reclassificar automaticamente.
10. ENTREGA: arquivos C11_ANALYTIC_RESULTS.json, C11_EFFECT_MATRIX.csv, c11_science.py, PSV e SHA256_MANIFEST.json, ZIP autocontido de análise. Não substitui os arquivos C05–C10, que permanecem na operação. Consulta científica respondida em PSV e chat.

## Perguntas do Mestre
A — Prata1: 6 efeitos estritos históricos média33,667 e 5 conflitantes média39,7 NÃO são um único estrato; Gambá 2d6+25 média32, Mamute 2d6+2d4+22 média34, ambos com fontes diretas, não equivalem a uma população. Diferença2 explicada por dados +5 contra atributo −3.
B — ON5: Varok103 e Iskiel87,5 são dano equipado de armas diferentes; Veyun70 é descarga mágica de Terra com salvaguarda, portanto três entregas não homogêneas. O outlier matemático equipado não é outlier de equilíbrio.
C — Varok +39/60=0,65 dano bruto incremental por PA; Iskiel +27,5/45=0,6111; diferenças de RD, pré-condição e frequência impedem comparação de eficiência real.
D — DME intrínseco separa atributos/FF e não substitui valores explícitos. Três exemplos de itens Lendários estão numericamente dentro da faixa Lendária apenas sob comparação exploratória; nenhuma validação de banda por RE/FIP foi certificada.
E — Não mudar coeficientes agora. Investigar atributos, intraficha, rank ancestral e eficiência pós-RD. Proposta futura apenas depois de holdout por família, fontes independentes e gates.

## Evidências e denominadores
Fontes físicas reabertas nesta execução: 5 normas/OP + 5 fichas (Gambá, Mamute, Varok, Iskiel, Veyun) = 10 páginas Notion distintas; outras páginas C05 têm extratos físicos preservados, NÃO foram reabertas nesta execução. Corpus histórico recuperado: 58 efeitos, 16 HP numéricos, 13 páginas no subconjunto, 34 componentes no arquivo completo (inclui ALMA), 3 pares intrapágina; 7 expressões diretas para comparação; 2 pares PA. O conjunto não representa todas as criaturas, efeitos ou classes. A6 571 estrutural congelado.

## LAST-VERIFIED-UNIT / FIRST-PENDING / NO-REPEAT
LAST-VERIFIED-UNIT: C11 cálculo científico local com CSV, JSON e código; fontes diretas Notion reabertas.
FIRST-PENDING: adjudicar RE/FIP/entrega de efeitos antes de inferir aderência às bandas; confirmar condições comparáveis Rabada/Corte e conflitos de rank; recuperar matrizes L002/L003 por bytes se disponíveis.
NO-REPEAT: C05–C10 preservados; não refazer varredura global, VLAB R160/R162/R169 nem SQLite.
CONFLICTS: Raposa e outros ancestrais; Veyun FF +6 em descrição mas cláusula específica sem FF; RD composta/elemental e arredondamento não resolvidos.
UNKNOWN-EFFECT: R156 permanece quarentena. R138 HOLD. Nenhuma promoção de recibo VLAB a cânone.
NEXT-5: (1) adjudicação de rank/RE/FIP; (2) pareamento intraficha com contexto; (3) separar família/holdout antes de estimar parâmetros; (4) dossiê pós-RD/PA fonte-documentado; (5) ensaio de fronteira Bronze/Prata e ON/L com entrega homogênea.
TARGET-REMAINDER: F0–F18, E01–E24, 8 gates transversais, A5/A7/A8, L002/L003.
AUTHORITY/WRITER STATE: sem writer, lease, epoch, ACK, alteração canônica ou acesso Party/O Primeiro.
NAC-PASS-02: PASS técnico local de integridade, reprodução e separação de evidência; HOLD para aceitação normativa/canônica e para inferência global.
