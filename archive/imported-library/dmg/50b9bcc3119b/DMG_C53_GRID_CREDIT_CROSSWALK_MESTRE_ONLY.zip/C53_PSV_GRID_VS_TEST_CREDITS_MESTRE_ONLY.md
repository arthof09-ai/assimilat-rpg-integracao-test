# DMG C53 — Auditoria anti-dupla-contagem de simulação e cobertura (MESTRE-ONLY)

## Fonte e motivo

A OP já possui **SIM-DMG-PAIRED-01**, **SIM-DMG-CASE-LEDGER-01** e a subárvore histórica **PLAN-SIM-DMG-VLAB-01**. Estas estruturas não devem ser reconstruídas ou duplicadas. Reabri Notion Mestre em leitura, inclusive protótipos LAB-L05/L06-v0.4, FAIR-v0.5 e AI09-v0.9, e confrontei com os dados TEST novos do DMG C47/C50/C52. Não fiz download/replay dos códigos v0.4/v0.5/v0.9 históricos nesta campanha: as conclusões são documentais, não novas execuções daqueles softwares.

## DENOMINADORES EQUIVOCADOS — ERRO IMPEDIDO

1. **Grade central SIM-DMG**: 25 níveis ×25 oponentes = 625 células ED×ED, 625 ED×Besta, 625 Besta×Besta, total **1.875 células DEFINIDAS**. Na página física do ledger (edição 08/10/2026), constam **0/1.875 com fonte VALIDATED, 0 full-fight baseline VERIFIED e 0 comparações baseline↔candidate**. Isto não prova inexistência de trabalho em outros arquivos/labs depois daquela edição, mas não autoriza somar evidência diferente como célula oficial verificada.
2. **Protótipo L05/L06 v0.4**, fonte Notion: **500 seeds tentadas**, 336 `CONDITIONAL-COMPLETE` (**67,2%**), 100 bloqueadas por consequência de crítico, 61 por empate de iniciativa, 3 censuradas; balanço 500/500. Não são 336 novas células core.
3. **Submodelo FAIR v0.5**, fonte Notion: **2.000 seeds tentadas**, 1.180 pares espelhados concluídos (**59%**), 660 bloqueios por empate, 160 por falha crítica (**41% bloqueios**); total 2.000/2.000. 1.180 correspondências em engine restrito não demonstram equilíbrio canônico nem 1.180 células.
4. **AI09 v0.9**, fonte Notion: 251 testes unitários PASS relatados e 20.000 operações sintéticas de stress relatadas; não são lutas full-fight ou verificações das 1.875 células.
5. **VLAB R214/C50:** 15 seeds com 38 ataques aninhados, 3 sementes censuradas no horizonte e cenários de contrato funcional. Pertencem a outro escopo VLAB; **zero crédito SIM-DMG**.
6. **DMG C52:** 100 perfis pareados de dano teórico pós-RD, sem ator, criatura, turno ou estratégia; **zero crédito SIM-DMG**.
7. **DMG C47:** 2.048 combinações booleanas da matriz de elegibilidade F6, nenhum combate; **zero crédito SIM-DMG**.

## Interpretação física

O organismo **tem protótipos e testes úteis**, portanto não é correto dizer que a engenharia de batalha nunca rodou; entretanto, o **ledger canônico específico** ainda não demonstra 1.875 execuções com fonte e gate. As taxas 67,2% vs 59% NÃO constituem regressão do motor: são condições, versões e filtros diferentes, não comparação pareada de mesma amostra. A censura e a seleção por bloqueios tornam inválida inferência de winrate ou TTK global.

**Sem criar novo motor ou novo ledger**, a passagem para F7 exige um `CASE-KEY` no objeto existente, combatentes com proveniência canônica e parâmetros completos (ou sintéticos explicitamente separados), definição de seed por evento, relatório completo/algoritmo/replay, guarda de colisão com VLAB, congelamento F0 e NAC-PASS proporcional. O status de célula muda apenas quando o próprio ledger competente registrar evidência suficiente.

## Encerramento proporcional

Verificada a existência das fontes Notion e sua interpretação histórica, sem modificar-as. `F0 4/8 HOLD`, `A5 0/7 bytes`, `A7 holdout não cego`, `A8 writer/segundo humano HOLD`, `F6 nenhum positivo real`, `D0 global UNKNOWN (870 Page-IDs limitados)`, `DMG-RANK-01 v1.1 OFICIAL INALTERADA`. `FIRST-PENDING`: primeira célula core realmente `SOURCE-ELIGIBLE` e posteriormente combate completo, **sem contabilizar o C50 ou C52 no grid**. Não criar 1.875 linhas duplicadas nem avançar engine de outros executores.
