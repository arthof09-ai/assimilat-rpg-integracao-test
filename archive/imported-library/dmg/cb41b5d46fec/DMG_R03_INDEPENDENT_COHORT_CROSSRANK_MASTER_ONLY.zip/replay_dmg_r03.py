#!/usr/bin/env python3
"""R03 scientific read-only replay. Inputs are independently transcribed verified Notion snippets;
not a Notion client and NOT a combat resolver. Fixed cohort frozen in R03_PREREG_FROZEN.json.
"""
import csv,hashlib,itertools,json,math,statistics,zipfile
from collections import Counter,defaultdict
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
PREREG=ROOT/'R03_PREREG_FROZEN.json'
OUT=ROOT

# Rows: page ID (no hyphens), parent species, body identity, ancestor rank, body rank,
# CA, attributes FOR/DES/INT, exact named numerical effects as present (no invented terms).
# Expr syntax ('dice'=[(n,s)], attr=FOR/DES/INT/null, fixed=integer, role=INITIAL/CONDITIONAL_TICK/PA_DRAIN/HEAL/REACTIVE).
def p(id,parent,body,ancestor,rank,ca,for_,des,int_,effects=(),notes=''):
    return dict(id=id,tree_identity=parent,body_identity=body,ancestral_rank=ancestor,body_rank=rank,CA=ca,attributes=dict(FOR=for_,DES=des,INT=int_),effects=[dict(x) for x in effects],notes=notes)
def e(name,formula,dice,attr=None,fixed=0,role='INITIAL',condition='',cost=None,damage_type=None,qualifier=''):
    return dict(name=name,literal_formula=formula,dice=[list(z) for z in dice],attribute=attr,fixed=fixed,role=role,condition=condition,cost_documented=cost,damage_type_documented=damage_type,qualifier=qualifier)
P={
'034c2b324ede83ffa7118144011beaf3':p('034c2b324ede83ffa7118144011beaf3','Rinolupo','Rinolupo','Ouro 5','Prata 1',27,30,13,10,[e('Investida Feroz','2d6+ for',[(2,6)],'FOR',condition='charge; numerical action cost unknown')],notes='Pele Couraçada RDF10 vs general RD15: stacking/precedence unresolved'),
'0c9c2b324ede82ab8be801371d927931':p('0c9c2b324ede82ab8be801371d927931','Cristalino Gélido','Cristalino Gélido','Prata 5','Prata 1',42,9,30,40,[e('Estalactite Afiada','1d6+Int',[(1,6)],'INT',condition='after four attacks may freeze; save CD6+INT')]),
'102c2b324ede83da9f3381d817425372':p('102c2b324ede83da9f3381d817425372','Neve Cornífera','Fera Cornífera das Neves','Prata 1','Bronze',38,26,24,12,notes='No numeric damage; drop dice not attacks; title/body conflict'),
'1c6c2b324ede8252872c81bd287fb516':p('1c6c2b324ede8252872c81bd287fb516','Aurora Radiante','Aurora Radiante','Ouro 1','Prata 1',42,4,29,40,[e('Raio purificador','1d6+int de dano',[(1,6)],'INT'),e('Toque Iluminado','1d4+int',[(1,4)],'INT',role='HEAL',condition='heals or purifies; not attack damage')]),
'206c2b324ede835383a1818a6edd5273':p('206c2b324ede835383a1818a6edd5273','Águia Arranha Céu','arranha céus','Prata 1','Prata 1',31,18,20,30,[e('Raio paralisante','1d4 + inteligência',[(1,4)],'INT',condition='Fortitude test against paralysis',damage_type='raio (ability wording); component exact type not certified')],notes='Tree/body partial aliases; body prints Rank prata1 (1d6), but Sistema de Combate gives Prata test dice 2d6. Separate mechanic/test-die conflict; does not change literal damage 1d4+INT; D precision remains blocked.'),
'2a7c2b324ede836abefc81af3e7aeef6':p('2a7c2b324ede836abefc81af3e7aeef6','Anjo','Ser de Energia Cósmica','Lendário 2','Bronze',48,7,36,45,notes='No numeric attack; rank conflict'),
'336c2b324ede82ac82ab01ac0eb062a2':p('336c2b324ede82ac82ab01ac0eb062a2','Verdantis Sibilante','Verdantis Sibilante','Ouro 2','Prata 1',41,6,28,42,[e('Folhas cortantes','1d6+Int',[(1,6)],'INT',condition='cone of 4.5m; number of targets unknown')]),
'383c2b324ede8266ad2b819fc078a66a':p('383c2b324ede8266ad2b819fc078a66a','Símio Demoníaco','Fúria de Chamas','Ouro 2','Épico',33,23,20,12,[e('Lança-chamas','3d6 + int',[(3,6)],'INT',qualifier='Passive +5 de dano exists but stacking to this skill unproven'),e('Ataque colossal','2d6+for',[(2,6)],'FOR',qualifier='Passive +5 de dano exists but stacking to this skill unproven')],notes='Non-standard body classification Épico; cannot assign Prata rank'),
'3bfc2b324ede826b9a1881a45c3050df':p('3bfc2b324ede826b9a1881a45c3050df','Leopardo das Montanhas','leopardo das montanhas','Ouro 4','Bronze 5',36,28,22,9,[e('Garras congelante','1d6 + força',[(1,6)],'FOR',condition='freeze after three successful hits')]),
'45bc2b324ede823cb1328108c91421b4':p('45bc2b324ede823cb1328108c91421b4','Véu Noturno','Véu Noturno','Ouro 4','Prata 1',53,5,42,14,[e('Toque Sombrio','2d4+ INT de PA',[(2,4)],'INT',role='PA_DRAIN',condition='PA drainage, not HP damage')]),
'474c2b324ede82d08ea6819069c17043':p('474c2b324ede82d08ea6819069c17043','Concha Marinha','Concha Marinha Luminosa','Prata 1','Prata 1',40,30,27,4,[e('Mordida','3d6 + Força',[(3,6)],'FOR')],notes='Tree/body name extended by epithet'),
'4bac2b324ede8321af6b01eb96452d04':p('4bac2b324ede8321af6b01eb96452d04','Lupusventus','lobo da caverna','Prata 1','Prata 1',37,25,24,9,[e('Patada','2d6 + força',[(2,6)],'FOR',qualifier='+2 Força Ancetral mentioned separately, not applied without buff/snapshot proof')],notes='Tree/body species labels differ, physical page fixed; behavior mentions forest elemental wolf'),
'02ec2b324ede834b812b81e9c50d6a8f':p('02ec2b324ede834b812b81e9c50d6a8f','Nocturalupus astralis','Lobo Celestial','Ouro 3','Bronze',48,44,34,18,notes='No numerical damage; drop dice excluded'),
'08cc2b324ede8378a3a7018646e2d5cd':p('08cc2b324ede8378a3a7018646e2d5cd','Cristalino Gélido','Cristalino Gélido','Prata 5','Prata 5',70,10,45,52,[e('Estalactite Afiada','1d6+Int',[(1,6)],'INT',condition='after four attacks may freeze')]),
'08ec2b324ede8299836201f423a9f6f4':p('08ec2b324ede8299836201f423a9f6f4','Ursantler','Ursantler','Prata 5','Bronze',46,18,32,35,notes='No numerical damage; attack/control textual only'),
'09fc2b324ede8394b99e0145eda350a2':p('09fc2b324ede8394b99e0145eda350a2','Giganthrix algidus','Criatura das Neves Ancestrais','Ouro 2','Bronze',48,40,34,11,notes='No numerical damage'),
'0ecc2b324ede822a8d6501f79d53b34a':p('0ecc2b324ede822a8d6501f79d53b34a','Grifo','Grifo Guardião','Ouro 4','Ouro',47,10,33,40,notes='No numerical attack; drop dice excluded'),
'15ec2b324ede82a390758102c9f159d4':p('15ec2b324ede82a390758102c9f159d4','Dracoflora Fluvialis','Dracoflora Fluvialis','Ouro 4','Bronze',60,4,46,50,notes='No numerical attack'),
'1fdc2b324ede82bd9d4f811abb689440':p('1fdc2b324ede82bd9d4f811abb689440','Behemoth Glacial','Behemoth Glacial','Ouro 1','Prata 5',61,15,45,36,[e('Estilhaços de Gelo','2d6 + Dês',[(2,6)],'DES'),e('Mordida','3d6 + Força',[(3,6)],'FOR')],notes='Armadura de Gelo changes CA and reflects 15% damage under conditions; resource costs 20 PA setup, 3 PA per turn, not offensive action costs'),
'266c2b324ede8258b97c017633c22ca6':p('266c2b324ede8258b97c017633c22ca6','Grifo Divino','Grifo Guardião','Ouro 5','Ouro',44,10,33,40,notes='Rank and species conflict; no numerical attacks'),
'2c8c2b324ede82dc858581d59296a712':p('2c8c2b324ede82dc858581d59296a712','Basilisco','Dracarídeo Verde','Lendário 2','Bronze',46,7,33,43,notes='No numerical damage; drop dice excluded'),
'2f3c2b324ede830c94af0113e39a1a50':p('2f3c2b324ede830c94af0113e39a1a50','Raposa Flamejante','raposa alfa','Prata 5','Bronze 5',33,60,20,15,[e('Punhos de fogo','1d4',[(1,4)]),e('Soco','1d6 + força',[(1,6)],'FOR')],notes='Different physical sheet from R02 Raposa Alfa B5; do not merge or overwrite historical version'),
'2fbc2b324ede8202969b8149c24869a1':p('2fbc2b324ede8202969b8149c24869a1','Lagarto Pântano','Escamorte','Ouro 3','Bronze',44,37,30,4,notes='Jato dÁgua damage qualitatively, no expression; drop dice excluded'),
'398c2b324ede82e4bd71011de3e2377f':p('398c2b324ede82e4bd71011de3e2377f','Abissalhor','Abissalhor','Prata 5','Prata 5',44,35,30,20,[e('Furadeira (impacto inicial)','2d6+ força',[(2,6)],'FOR',condition='pins target after piercing; no guaranteed additional ticks'),e('Furadeira (presa, por turno)','2d4+15',[(2,4)],fixed=15,role='CONDITIONAL_TICK',condition='target remains pinned, later turns; rate/duration unresolved'),e('Sopro das Profundezas (por turno)','2d6+int',[(2,6)],'INT',role='CONDITIONAL_TICK',condition='Fortitude fails, then each turn; not instantaneous damage')],notes='Two conditional tick effects cannot be added to initial furadeira damage'),
'254c2b324ede82d392d80140dd4c9f35':p('254c2b324ede82d392d80140dd4c9f35','Centelha Tempestuosa','Centelha Tempestuosa','Ouro Negro 2','Ouro 1',61,20,46,55,[e('Impacto Fulminante','2d6+int',[(2,6)],'INT',condition='Fortitude success halves damage; no documented rounding, no automatic layer-E'),e('Aura Eletrizante','1d8',[(1,8)],role='REACTIVE',condition='melee foe fails Reflex save; reactive aura not normal action')]),
'2bfc2b324ede82699fbf0187858cf72d':p('2bfc2b324ede82699fbf0187858cf72d','Demônio de Gelo','Dragão de Gelo Azul','Ouro Negro 4','Ouro 3',68,60,50,20,[e('Esmaga crânio','4d6 + For',[(4,6)],'FOR',condition='+10 de dano while in habitat mentioned as separate trait; not included in primary')],notes='Title Ouro1; body Ouro3; tree OuroNegro4; not a valid Ouro1 rank case'),
'442c2b324ede8364870a814350dd5051':p('442c2b324ede8364870a814350dd5051','Sussurro Celestial','Sussurro Celestial','Ouro 5','Ouro 1',63,50,49,26,[e('Lâmina de Brisa','2d4 + INT',[(2,4)],'INT')],notes='Forma Etérea 1/cena can negate physical attacks; defensive rider not in simple raw arithmetic'),
'4aac2b324ede8225a29b815053e5fcb3':p('4aac2b324ede8225a29b815053e5fcb3','Ignisaurus','Escarlate Flamejante','Ouro 5','Ouro 1',42,36,34,13,notes='Chama Ardente no dice; Cura Solar 1d6 heal per turn not damage'),
'5a5c2b324ede82d8bf7d0180c85e55e8':p('5a5c2b324ede82d8bf7d0180c85e55e8','Cervídea Arbórea','Cervídea Arbórea','Ouro 5','Bronze',67,33,48,15,notes='No numerical damage; regenerative effects qualitative'),
'5dac2b324ede83eaa831811e1fbe13d2':p('5dac2b324ede83eaa831811e1fbe13d2','Formiga Ardente','Escarlate Sombrio','Ouro 1','Bronze',79,16,65,34,notes='No numeric damage; identity and rank conflicts'),
'783c2b324ede8200b08681808730daef':p('783c2b324ede8200b08681808730daef','Maré Misteriosa','Maré Misteriosa','Ouro 1','Ouro 1',50,38,36,33,[e('Mordida/patada','3d6 + For',[(3,6)],'FOR')],notes='Terrain slow/reaction on other abilities cannot be added as same attack'),
'80cc2b324ede82af80a1815df3cac448':p('80cc2b324ede82af80a1815df3cac448','Capríleo','Capríleo Escamoso','Ouro 4','Bronze',55,36,40,12,notes='No numerical damage; only drop dice'),
'84ac2b324ede834abc5181e3228ae375':p('84ac2b324ede834abc5181e3228ae375','Caostik','Abominação Arcana','Ouro 1','Lendário',64,8,50,70,[e('Vórtice Arcano por turno','6d6+Int',[(6,6)],'INT',role='CONDITIONAL_TICK',condition='failed spell CD while in center, ongoing each turn; 40 PA cost',cost='40PA'),e('Membros Espectrais','dano da arma+Inteligência',[],'INT',role='INCOMPLETE',condition='one attack via movement action, 40PA + 5PA per turn; weapon die unspecified',cost='40PA+5PA/turn')],notes='Title Ouro1, body Lendário; no comparison by rank'),
'99bc2b324ede8353b872017eb3d57afc':p('99bc2b324ede8353b872017eb3d57afc','Aurora Radiante','Aurora Radiante','Ouro 1','Prata 1',63,4,49,70,[e('Raio purificador','1d6+int',[(1,6)],'INT'),e('Toque Iluminado','1d4+int',[(1,4)],'INT',role='HEAL',condition='may heal or purify')],notes='Title Ouro1 but body states Prata1; cannot use Ouro1 rank stats'),
'a53c2b324ede830ab253016d7a9fea23':p('a53c2b324ede830ab253016d7a9fea23','Cavalo Alado Aquático','Cavalo Alado Aquático','Ouro 1',None,65,15,51,50,notes='Body section Classificação blank; numeric drops not damage'),
'a6ac2b324ede83338bd9817502b3232a':p('a6ac2b324ede83338bd9817502b3232a','Gárgula','Dracapra','Ouro Negro 5','Bronze',56,47,40,3,notes='No damage numeric; material drops do not count')
}

# exact last-edited times as reported by Notion fetch; not a native content checksum
EDITED_AT={
'034c':'18:00:46.623','0c9c':'18:00:42.714','102c':'18:00:43.782','1c6c':'18:01:00.329','206c':'18:00:49.453','2a7c':'18:01:00.490','336c':'18:00:55.106','383c':'18:00:46.348','3bfc':'18:00:42.892','45bc':'18:00:53.269','474c':'18:00:39.179','4bac':'18:00:45.677',
'02ec':'18:01:00.305','08cc':'18:00:42.767','08ec':'18:00:43.648','09fc':'18:00:44.107','0ecc':'18:00:45.731','15ec':'18:00:59.734','1fdc':'18:00:46.463','266c':'18:01:03.896','2c8c':'18:01:06.892','2f3c':'18:00:46.258','2fbc':'18:00:41.158','398c':'18:00:40.289',
'254c':'18:01:02.989','2bfc':'18:00:42.609','442c':'18:00:42.678','4aac':'18:00:47.675','5a5c':'18:01:00.712','5dac':'18:00:47.666','783c':'18:00:40.615','80cc':'18:00:34.018','84ac':'18:00:55.192','99bc':'18:01:00.409','a53c':'18:00:43.404','a6ac':'18:01:07.078'
}
assert len(EDITED_AT)==36

def dice_pmf(dice):
    counts={0:1}
    for n,s in dice:
        if not isinstance(n,int) or not isinstance(s,int) or n<1 or s<2: raise ValueError((n,s))
        for _ in range(n):
            out=defaultdict(int)
            for total,mul in counts.items():
                for face in range(1,s+1):out[total+face]+=mul
            counts=dict(out)
    return counts

def expect(counts):
    d=sum(counts.values());return Fraction(sum(x*m for x,m in counts.items()),d)

def metric(counts,rd):
    total=sum(counts.values())
    reduced=Counter({max(0,k-rd):v for k,v in counts.items()})
    reduced=defaultdict(int)
    for k,v in counts.items():reduced[max(0,k-rd)]+=v
    average=expect(reduced);pen=sum(v for k,v in counts.items() if k>rd)
    return dict(rd=rd,mean=float(average),fraction=f'{average.numerator}/{average.denominator}',penetration_probability=float(Fraction(pen,total)),penetration_fraction=f'{Fraction(pen,total).numerator}/{Fraction(pen,total).denominator}',min=min(reduced),max=max(reduced),distribution={str(k):v for k,v in sorted(reduced.items())},equally_weighted_microstates=total)

reg=json.loads(PREREG.read_text())
assert sum(len(v) for v in reg['cohort_source_ids'].values())==36
assert set(sum(reg['cohort_source_ids'].values(),[]))==set(P), 'Fixed prereg samples changed'
# R02 20 physical IDs kept separate, no reuse:
r02pages=json.loads((ROOT.parent/'R02_PAGE_LEDGER.json').read_text())
r02ids={x['id'] for x in r02pages}
assert not (set(P)&r02ids), 'A sample was reused from R02'

pages=[];actions=[];rank_counts=Counter()
for rank,ids in reg['cohort_source_ids'].items():
    for id in ids:
        src=P[id];body=src['body_rank']
        rank_competent=rank==body==src['ancestral_rank']
        rank_tb=rank==body
        has_identity_issue=src['tree_identity'].lower().strip()!=src['body_identity'].lower().strip()
        pn=dict(page_id=id,url='https://app.notion.com/p/'+id,selection_stratum=rank,title_rank=rank,body_rank=body,tree_rank=src['ancestral_rank'],source_tree_identity=src['tree_identity'],source_body_identity=src['body_identity'],CA_printed=src['CA'],attributes=src['attributes'],rank_triple_concordance=rank_competent,rank_title_body_concordance=rank_tb,rank_conflict=('TITLE_BODY_AND_TREE' if not rank_tb and src['ancestral_rank']!=rank else 'TITLE_BODY' if not rank_tb else 'ANCESTOR_V_TITLE' if src['ancestral_rank']!=rank else 'NONE'),identity_label_difference=has_identity_issue,source_last_edited_at='2026-10-01T'+EDITED_AT[id[:4]]+'Z',notes=src['notes'],lot_003_membership='NOT_PROVEN',outside_L002_L003='NOT_PROVEN',r02_excluded=True,source_read='NOTION_MASTER_DIRECT_FETCH_R03',source_scope='BESTAS_DEMONIACAS')
        page_n=0
        for i,fx in enumerate(src['effects']):
            fx=dict(fx)
            if fx['role']!='INCOMPLETE' and not fx['dice']:
                raise AssertionError('no dice for parsed effect')
            if fx['role']=='INCOMPLETE':
                a=dict(page_id=id,action_id=f'{id}:{i:02}',formula=fx['literal_formula'],role=fx['role'],status='INCOMPLETE_NO_DICE',source=pn['url'],conditions=fx['condition'],cost=fx['cost_documented'])
                actions.append(a);page_n+=1;continue
            d=dice_pmf([tuple(z) for z in fx['dice']]);intrinsic={k+fx['fixed']:v for k,v in d.items()}
            b=src['attributes'][fx['attribute']] if fx['attribute'] else 0
            gross={k+b:v for k,v in intrinsic.items()}
            a=dict(page_id=id,action_id=f'{id}:{i:02}',species_tree=src['tree_identity'],species_body=src['body_identity'],rank_title=rank,rank_body=body,rank_tree=src['ancestral_rank'],rank_triple_concordance=rank_competent,rank_title_body_concordance=rank_tb,name=fx['name'],formula=fx['literal_formula'],dice=fx['dice'],attribute=fx['attribute'],attribute_value=(b if fx['attribute'] else None),fixed_intrinsic=fx['fixed'],role=fx['role'],conditions=fx['condition'],cost_documented=fx['cost_documented'],damage_type_documented=fx['damage_type_documented'],qualifier=fx['qualifier'],source=pn['url'],source_last_edited=pn['source_last_edited_at'],analysis_role='A_B_FORMULA_ONLY' if fx['role']!='INITIAL' else 'INITIAL_DAMAGE_CONDITIONAL_ON_HIT',intrinsic_expected=float(expect(intrinsic)),gross_expected=float(expect(gross)),attribute_share=float(Fraction(b,1)/expect(gross)) if fx['attribute'] else 0.0,min=min(gross),max=max(gross),pmf_gross={str(k):v for k,v in sorted(gross.items())},pmf_total=sum(gross.values()),components=len(fx['dice'])+(1 if fx['attribute'] else 0)+(1 if fx['fixed'] else 0),RD_conditional={str(rd):metric(gross,rd) for rd in [5,15,25,30,31,35,45]},precision_status='NO_NAMED_ATTACK_BONUS_DOCUMENTED',lot_003_membership='NOT_PROVEN')
            actions.append(a);page_n+=1
        pn.update(numeric_formula_count=page_n,initial_action_count=sum(a['page_id']==id and a.get('role')=='INITIAL' for a in actions),non_initial_numeric_count=sum(a['page_id']==id and a.get('role')not in ['INITIAL','INCOMPLETE'] for a in actions))
        pages.append(pn)
assert len(pages)==36
numeric=[a for a in actions if 'gross_expected' in a]
initial=[a for a in numeric if a['role']=='INITIAL']
strict=[a for a in initial if a['rank_triple_concordance']]
strict_ids={a['page_id'] for a in strict}
assert len(strict)==6 and len(strict_ids)==6,(len(strict),len(strict_ids),[(a['name'],a['rank_title']) for a in strict])

def agg_subset(a):
    total_g=sum(x['gross_expected'] for x in a);att=sum(x['attribute_value'] or 0 for x in a)
    return dict(action_count=len(a),physical_creature_count=len(set(x['page_id'] for x in a)),total_action_mean_gross=total_g,mean_gross_per_action=total_g/len(a) if a else None,dice_mean_sum=sum(x['intrinsic_expected'] for x in a),attribute_sum=att,attribute_pooled_share=(att/total_g if total_g else None),mean_per_creature_of_ability_means=(statistics.mean([statistics.mean([q['gross_expected'] for q in a if q['page_id']==pid]) for pid in sorted(set(x['page_id'] for x in a))]) if a else None))

rank_agg={rank:agg_subset([a for a in strict if a['rank_title']==rank]) for rank in reg['cohort_source_ids']}
strata_conflicts={rank:dict(pages=12,triple_agree=sum(x['rank_triple_concordance'] and x['selection_stratum']==rank for x in pages),title_body_agree=sum(x['rank_title_body_concordance'] and x['selection_stratum']==rank for x in pages),title_body_mismatch=sum(not x['rank_title_body_concordance'] and x['selection_stratum']==rank for x in pages),tree_mismatch=sum(x['tree_rank']!=rank and x['selection_stratum']==rank for x in pages),numeric_pages=sum(x['numeric_formula_count']>0 and x['selection_stratum']==rank for x in pages)) for rank in reg['cohort_source_ids']}

# exact pair ordering if both roles INITIAL; not blindly 2 actions = 2 creatures
pairs=[]
for pid in sorted(set(a['page_id'] for a in initial)):
    acts=[a for a in initial if a['page_id']==pid]
    for x,y in itertools.combinations(acts,2):
        di=x['intrinsic_expected']-y['intrinsic_expected'];dg=x['gross_expected']-y['gross_expected']
        pairs.append(dict(page_id=pid,species=x['species_body'],a=x['name'],b=y['name'],delta_intrinsic=di,delta_gross=dg,strict_inversion=di*dg<0,rank_triple_concordance=x['rank_triple_concordance'],interpretation='WITHIN_PHYSICAL_CREATURE_ONLY'))

byrank={rank:[a for a in strict if a['rank_title']==rank] for rank in reg['cohort_source_ids']}
# Prata1 crossing counterexample: Eagle vs Lupusventus physical pages, same rank title/body/tree but not same damage modality.
eagle=next(a for a in strict if a['page_id'].startswith('206c'))
wolf=next(a for a in strict if a['page_id'].startswith('4bac'))
crossover=[dict(rd=rd,raio=eagle['RD_conditional'][str(rd)],patada=wolf['RD_conditional'][str(rd)],winner='RAIO' if eagle['RD_conditional'][str(rd)]['mean']>wolf['RD_conditional'][str(rd)]['mean'] else 'PATADA' if eagle['RD_conditional'][str(rd)]['mean']<wolf['RD_conditional'][str(rd)]['mean'] else 'EMPATE') for rd in [5,15,25,30,31,35,45]]
# Accurate symbolic sensitivity: E_A = p_A * C_A, E_B = p_B * C_B. If C_A>C_B, A loses when p_A/p_B<C_B/C_A.
break_even=[]
for rd in [5,15,25,30,31,35]:
    av=eagle['RD_conditional'][str(rd)]['mean'];bv=wolf['RD_conditional'][str(rd)]['mean']
    break_even.append(dict(rd=rd,raio_C=av,patada_C=bv,hit_probability_ratio_raio_over_patada_threshold=bv/av if av else None,note='Ratio only; distinct ability hit mechanics, actual p unknown; no direct performance claim'))

# Mathematical conditional for authorized Frigido R32 only, no new fight or canon damage.
frigido={}
for ca in [20,25,26,27,28,29,30,31,37,40,50]:
    # attack 1d6 + FOR18 + Luta6; success > CA
    hits=[d for d in range(1,7) if (d+18+6)>ca]
    frac=Fraction(len(hits),6)
    # Noncritical Rabada damage 1d6+18, RD5 -> means 16.5, with no voluntary defensive reaction.
    value=frac*Fraction(33,2)
    frigido[str(ca)]=dict(hit_probability=float(frac),hit_fraction=str(frac),damage_after_RD5_per_hit_noncritical=16.5,expected_noncritical_net_per_eligible_basic_attack=float(value),expected_fraction=f'{value.numerator}/{value.denominator}')

# Official generic Besta damage baselines (mathematical only), not replacements for explicit named skills.
generic={}
for rank,dice in {'Bronze':[(3,6)],'Prata':[(6,6)],'Ouro':[(9,6)],'Ouro Negro':[(12,6)]}.items():
    pmf=dice_pmf(dice)
    generic[rank]=dict(formula=' + '.join(str(n)+'d'+str(s) for n,s in dice),intrinsic_mean=float(expect(pmf)),RD={str(rd):metric(pmf,rd) for rd in [5,15,25,30,31,35,45]})
# A paired same-name/same-ability documentary comparison across two physical sheets; no proof of causal progression.
r02acts=json.loads((ROOT.parent/'R02_ACTION_LEDGER.json').read_text())
old_behemoth=[a for a in r02acts if a['page_id']=='5dac2b324ede83f39cdb01a904ce3cfd']
new_behemoth=[a for a in initial if a['page_id']=='1fdc2b324ede82bd9d4f811abb689440']
behemoth_versions=[]
for current in new_behemoth:
    candidates=[a for a in old_behemoth if a.get('attack','').lower().startswith(current['name'].lower().split(' ')[0])]
    if candidates:
        old=candidates[0]
        behemoth_versions.append(dict(ability=current['name'],silver5_physical_page=current['page_id'],gold1_physical_page=old['page_id'],Silver5_gross=current['gross_expected'],Gold1_gross=old['gross_conditional_on_hit'],delta_gold1_minus_silver5=old['gross_conditional_on_hit']-current['gross_expected'],delta_intrinsic=old['dme_intrinsic']-current['intrinsic_expected'],classification_caution='Silver5 title/body agree but ancestor tree Ouro1; Gold1 title/body/tree agree; two pages not one repeated event'))
# Matched family, same literal die and ability, but early version tree rank conflicts.
crystals=[a for a in initial if a['page_id'] in ('0c9c2b324ede82ab8be801371d927931','08cc2b324ede8378a3a7018646e2d5cd')]
assert len(crystals)==2
crystal_versions=dict(source_pages=[a['page_id'] for a in crystals],ability='Estalactite Afiada',recorded_rank_title_body=['Prata1','Prata5'],initial_dice_means=[a['intrinsic_expected'] for a in crystals],gross_means=[a['gross_expected'] for a in crystals],delta_from_attribute=12,prata1_tree_conflict='Prata1 leaf under Prata5 ancestor; not strict stage comparison')

summary={
 'schema':'DMG-R03-INDEPENDENT-COMPARISON-v1',
 'operation':'OP-DMG-CORPUS-EMP-01','baseline':'DMG-RANK-01 v1.1 unchanged','as_of':'2026-10-15',
 'prereg_sha256':hashlib.sha256(PREREG.read_bytes()).hexdigest(),
 'sample_scope':'36 previously non-R02 Notion beast pages selected by exact titles/lexicographic ID BEFORE their damage contents were fetched; not a random sample',
 'source_page_count':len(pages),'source_beast_page_id_count':len(P),'distinct_species_parent_labels':len(set(q['source_tree_identity'] for q in pages)),'distinct_species_body_labels':len(set(q['source_body_identity'] for q in pages)),'duplicate_parent_species_labels_in_fixed_roster':{z:sum(q['source_tree_identity']==z for q in pages) for z in sorted(set(q['source_tree_identity'] for q in pages)) if sum(q['source_tree_identity']==z for q in pages)>1},
 'numeric_expression_count':len(numeric),'all_recorded_effect_count':len(actions),'initial_HP_damage_formula_count':len(initial),'independent_rank_agreed_initial_count':len(strict),'strict_rank_independent_page_count':len(strict_ids),'explicit_attribute_initial_count':sum(a['attribute'] is not None for a in initial),
 'mathematical_component_count':sum(a['components'] for a in numeric),
 'conditional_tick_count':sum(a['role']=='CONDITIONAL_TICK' for a in numeric),
 'reactive_count':sum(a['role']=='REACTIVE' for a in numeric),
 'PA_DRAIN_count':sum(a['role']=='PA_DRAIN' for a in numeric),
 'HEAL_count':sum(a['role']=='HEAL' for a in numeric),
 'incomplete_mechanical_formula_count':sum(a['role']=='INCOMPLETE' for a in actions),
 'cohort_primary_strict':agg_subset(strict),'primary_rank_buckets':rank_agg,
 'strata_rank_conflicts':strata_conflicts,'all_initial_exploratory':agg_subset(initial),
 'within_creature_pairs':pairs,'within_pair_count':len(pairs),'within_pair_inversions':sum(a['strict_inversion'] for a in pairs),
 'RD_crossover_Prata1':dict(raio_source=eagle['source'],patada_source=wolf['source'],raio_formula=eagle['formula'],patada_formula=wolf['formula'],raio_gross=eagle['gross_expected'],patada_gross=wolf['gross_expected'],conditional_equal_RD=crossover,interpretation='Applies only to mathematical post-hit mitigation under common RD. Raio has Fortitude paralysis; Patada damage nature and targeting may differ. No known p_hit or reactions.'),
 'hit_probability_ratio_conditional':break_even,
 'generic_comparison_not_replacing_fichas':generic,
 'behemoth_two_version_comparison':behemoth_versions,
 'cristalino_two_version_comparison':crystal_versions,
 'VLAB_R32_existing_event_reference':dict(source='https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2',ability='Frigido Ossario Rabada ONLY',authorized_Luta_bonus=6,FOR=18,CA_Cabra=20,recorded_hit_total=27,recorded_bruto=21,recorded_RD=5,recorded_net=16,recorded_HP_transition='38->22, sandbox only',new_native_execution_by_DMG=0,conditional_no_reaction_no_crit=frigido),
 'historic_L002':dict(reported_pages=45,zip_status='LOCATED_BYTES_INACCESSIBLE_NO_NEW_MATERIALIZE_ATTEMPT',historic_sha256='4b76b69612105956805c7f6ca067f0022fb1ddc335eaed61dcbc8cb72c57c307'),
 'historic_L003':dict(reported_pages=71,reported_records=56,reported_parts=108,reported_conflict_pages=23,proven_membership_new=0,proven_membership_total=0,seven_nine_historic='REPORTED_NO_MANIFEST',historical_five_pairs_authenticated=0),
 'R02_candidate_preserved':dict(n_actions=9,n_pages=7,mean_gross=24.166666666666668,median_gross=26.5,IQR=5.5,MAD=2.0,dice_mean_sum=35.5,attribute_sum=182,pairs=5,inversions=3,identity_with_historic_L003='NOT_PROVEN'),
 'rank_canon_comment':'No title-vs-body-vs-tree conflict silently adjudicated. Strict tier uses concordant triple only; body species labels recorded even when tree differs; do not merge across page UUIDs.',
 'RD_comment':'Layer C always a scenario assuming RD applies uniformly; real typed mitigation may be different. Negative damage floored to zero; unresolved special resistances and ongoing effects separate.',
 'D_E_F_comment':'No complete offense probability for new abilities. Known R32 decision is narrow and scenarios above deliberately noncritical/no-reaction. No VLAB engine executed.',
 'no_canon_writes':True, 'F0_gate':'4/8 documentary historical unchanged','NAC_PASS_02':'LOCAL_REPRO_QA_ONLY_GLOBAL_HOLD'
}

def dump(obj,name):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

dump(pages,'R03_PAGE_LEDGER.json')
dump(actions,'R03_EXPRESSION_LEDGER.json')
dump(summary,'R03_COMPARATIVE_RESULTS.json')

with (OUT/'R03_INITIAL_DAMAGE.csv').open('w',newline='',encoding='utf-8-sig') as f:
    fields=['page_id','species_body','rank_title','rank_body','rank_tree','rank_triple_concordance','name','formula','role','intrinsic_expected','attribute','attribute_value','gross_expected','min','max','RD5','RD15','RD25','RD31','RD35','source']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for a in initial:
        w.writerow({k:(a.get(k) if k not in ['RD5','RD15','RD25','RD31','RD35'] else a['RD_conditional'][k[2:]]['mean']) for k in fields})

# Atomic exact tests, independent brute-force Cartesian products for every expression.
tests=[]
for a in numeric:
    ds=a['dice']
    naive=Counter()
    for rolls in itertools.product(*[range(1,s+1) for n,s in ds for _ in range(n)]):
        v=sum(rolls)+a['fixed_intrinsic']+(a['attribute_value'] or 0);naive[v]+=1
    assert {int(k):v for k,v in a['pmf_gross'].items()}==naive, a['action_id'];tests.append('PMF_'+a['action_id'])
    for rd in [5,15,25,30,31,35,45]:
        q=metric(naive,rd); assert q['fraction']==a['RD_conditional'][str(rd)]['fraction'];tests.append('RD_'+a['action_id']+'_'+str(rd))
# Specific cross-over, three-way rank, no duplicate pages
assert float(eagle['gross_expected'])==32.5 and wolf['gross_expected']==32.0
assert float(eagle['RD_conditional']['35']['mean'])==0.0 and float(wolf['RD_conditional']['35']['mean'])>0
assert summary['historic_L003']['proven_membership_total']==0
assert len({x['page_id'] for x in pages})==36
assert all(a['page_id'] not in r02ids for a in initial)
tests.extend(['INDEPENDENT_PAGE_ID_EXCLUSION','PREREG_ROSTER_36','RD35_CROSSOVER','NO_L003_FALSE_AUTHENTICATION'])
(OUT/'R03_REPLAY_TEST_RECEIPT.txt').write_text('R03 MATH ONLY - NO COMBAT RESOLVER\n'+f'PASS {len(tests)}/{len(tests)} deterministic microchecks\n'+'\n'.join(tests)+'\n',encoding='utf-8')
print(json.dumps(dict(selected_pages=36,total_effects=len(actions),numeric_expressions=len(numeric),initial_attacks=len(initial),primary_strict_attacks=len(strict),component_count=summary['mathematical_component_count'],pages_numeric=sum(p['numeric_formula_count']>0 for p in pages),strict_primary=summary['cohort_primary_strict'],byrank=rank_agg,conflicts=strata_conflicts,pairs=pairs,rd_crossover=crossover,microchecks=len(tests)),ensure_ascii=False,indent=2))
