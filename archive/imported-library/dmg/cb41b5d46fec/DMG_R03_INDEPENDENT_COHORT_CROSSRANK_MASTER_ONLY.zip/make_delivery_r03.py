#!/usr/bin/env python3
"""Create R03 documentary handoff/PSV; no Notion or Party write.
Uses sealed prereg, replay-derived artifacts, and canonical source IDs.
"""
import hashlib,json,zipfile,csv,statistics
from pathlib import Path
R=Path(__file__).resolve().parent
OLD=R.parent
D=json.loads((R/'R03_COMPARATIVE_RESULTS.json').read_text())
P=json.loads((R/'R03_PAGE_LEDGER.json').read_text())
A=json.loads((R/'R03_EXPRESSION_LEDGER.json').read_text())

def save(obj,name): (R/name).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')

# Explicitly non-numeric attacks/statuses found in page bodies: not zero damage.
qualitative={
'102c':['Garras Geladas: pode congelar/desacelerar; dano numérico não declarado','Tentáculos Espirais: ataque surpresa/defesa sem dado'],
'2a7c':['Manipulação de Energia: ofensiva potencial sem expressão'],
'08ec':['Garras de Gelo: efeito de congelamento sem dado','Rugido Congelante: dano de gelo e atordoamento sem fórmula'],
'09fc':['Braços Ramificados: ataques/agarre sem dado'],
'0ecc':['Garras Terrafirmes: efeito de solo sem fórmula de dano'],
'15ec':['Vinhas Enredantes: controle sem expressão danosa'],
'266c':['Garras Terrafirmes: sem fórmula numérica'],
'2c8c':['Sopro de Pedregulho: descrição de dano físico sem dado'],
'2fbc':['Jato de Água: dano/empurrão sem expressão'],
'4aac':['Chama Ardente: fogo e incêndio sem fórmula','Cura Solar: 1d6 por turno é cura, não ataque'],
'5dac':['Chama Obscura e Garras Incandescentes: danos descritos, sem fórmulas'],
'80cc':['Chifres Enrolados: ataque de impacto sem expressão'],
'84ac':['Membros Espectrais: dano da arma + Inteligência, arma-base desconhecida'],
'a53c':['Galope Marinho: ondas sem dano expresso'],
'a6ac':['Carga de Chifres: perfurante sem expressão'],
'398c':['Mordida do Abismo: sangramento descrito sem fórmula inicial'],
'1fdc':['Sopro Congelante: custo 10 PA e CD6+INT sem dados de dano','Armadura de Gelo: condição defensiva com reflexão 15%, não ataque'],
'336c':['Chicote de Vinha: imobilização sem dado de dano'],
'034c':['Pele Couraçada: RDF 10 documentado, interação com RD geral não adjudicada'],
'1c6c':['Clarão Deslumbrante: CD6+INT sem dano numérico; Toque Iluminado heal/purify'],
'206c':['Rasante: captura/queda posterior não quantificada','CONFLITO MECÂNICO: a ficha escreve Rank prata1 (1d6), mas o Sistema de Combate determina teste Prata 2d6; ataque e precisão ficam sem fechamento, sem tocar na fórmula de dano 1d4+INT'],
'474c':['Casca revestida: +5 CA por turno, não dano'],
'783c':['Torrente Obscura: derrubada/terreno difícil sem dado'],
'254c':['Impacto Fulminante: salvaguarda Fortitude pode reduzir à metade; ordem de arredondamento não comprovada']
}
source_pending=[]
for k,notes in qualitative.items():
    src=next(p for p in P if p['page_id'].startswith(k))
    for note in notes:
        source_pending.append(dict(page_id=src['page_id'],page_url=src['url'],source_body_identity=src['source_body_identity'],evidence_note=note,classification='PENDING_NUMERIC_OR_MECHANIC',lot_003_membership='NOT_PROVEN'))
save(source_pending,'R03_NONNUMERIC_AND_CONDITIONAL_LEDGER.json')

# Source-constrained exploratory test packages, never authorization to use a full-fight engine.
hand={
    'contract_id':'DMG-CORPUS-TO-VLAB-READONLY-01',
    'inherits_contract_version':'0.2-proposal-noncanonical',
    'operation':'OP-DMG-CORPUS-EMP-01',
    'producer':'CM-000001 DMG MESTRE-SIDE',
    'consumer':'CM-000006 OP-VLAB-FUSION-SANDBOX-01',
    'mode':'MATH_ONLY_WITH_OPTIONAL_FUTURE_VLAB_GATE',
    'baseline':'DMG-RANK-01 v1.1 unchanged',
    'no_engine_execution_by_DMG':True,
    'prohibited':['NO_PRODUCTION_WRITE','NO_FIGHT_CREDIT_FROM_MATH','NO_PARTY_TRANSFER','NO_UNKNOWN_AS_ZERO','NO_UNAUTHORIZED_LUTA6_GENERALIZATION'],
    'cases':[
      {'id':'R03-DISC-01','kind':'POST_HIT_RD_CROSSOVER','sources':['https://app.notion.com/p/206c2b324ede835383a1818a6edd5273','https://app.notion.com/p/4bac2b324ede8321af6b01eb96452d04'],'formulas':['1d4+INT30','2d6+FOR25'],'rank_source':'Prata1 title/body/tree each','C_rd25':[7.5,7.0],'C_rd30':[2.5,41/18],'C_rd31':[1.5,14/9],'C_rd35':[0.0,1/9],'barriers':['raio elemental vs patada physical typing','competent attack bonus of each','actual target CA, RD and resistance','reactions, PA and action economy, status and Fortitude','Lupusventus vs lobo da caverna identity label unresolved','Águia sheet Rank prata1 (1d6) versus canonical Prata test 2d6, do not decide hit dice by convenience'],'purpose':'Test when heavier variance reverses mean-after-RD ordering despite lower gross mean; must not assume equal p_hit or same target mitigation'},
      {'id':'R03-DISC-02','kind':'WITHIN_BEAST_ATTRIBUTE_ORDER_INVERSION','sources':['https://app.notion.com/p/1fdc2b324ede82bd9d4f811abb689440'],'formulas':['2d6+DES45 = 52 mean','3d6+FOR15 = 25.5 mean'],'rank_source':'Prata5 title/body match; ancestral Ouro1 conflict','barriers':['title/tree reconciliation','which attribute applies to accuracy, not inferred from damage','ability cost, range, RD type, reactions'],'purpose':'Distinguish intrinsic die order from attribute-added gross order'},
      {'id':'R03-DISC-03','kind':'CROSS_RANK_GROSS_OVERLAP','sources':['https://app.notion.com/p/08cc2b324ede8378a3a7018646e2d5cd','https://app.notion.com/p/783c2b324ede8200b08681808730daef'],'formulas':['Prata5 Estalactite 1d6+INT52 = 55.5','Ouro1 Mordida/patada 3d6+FOR38 = 48.5'],'rank_source':'Both concordant triple','barriers':['magic save/attack vs physical hit','cross-target damage type and RD','action cost, accuracy and multiple-target/rider mechanics'],'purpose':'Check local raw rank overlap without extrapolating population or declaring victory'},
      {'id':'R03-DISC-04','kind':'DEFENSIVE_LAYER_PRECEDENCE','sources':['https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3','https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd'],'formula_and_special':'Rinolupo Prata1, base RD15 versus RDF10 Pelle Couraçada as separate recorded field','rank_source':'Title/body Prata1, tree Ouro5','barriers':['competent authority for RDF relation, stacking and damage type','reaction, equipment buffs and collision of effects'],'purpose':'Adjudicate RD/RDF only by competent source; do not sum or choose max speculatively'},
      {'id':'R03-DISC-05','kind':'PREVIOUS_VLAB_R32_CONDITIONAL_CA_BOUNDARY_NOT_A_RERUN','sources':['https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315','https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6','https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2'],'ability':'Frigido Ossario Rabada ONLY','attack_basic_formula':'1d6+FOR18+Luta6','on_hit_noncritical':'1d6+FOR18 vs RD5','documented_action_cost':'1 Ação Padrão, +0 PA, adjacente','known_old_lab_result':'R32 27>20, gross21, RD5 net16, HP38->22 only sandbox','conditional_expectation_CA20':16.5,'conditional_expectation_CA29':2.75,'conditional_expectation_CA30':0,'barriers':['no critical branch in this noncritical math','no voluntary reaction only as in prior scoped R32 lab','do not execute old seed223 again','future full-fight needs Cabra Investida push and Luta permissions'],'purpose':'Measure sensitivity to a change in CA without erasing prior full-admission receipt'}
    ],
    'unknown_effect':'No external VLAB run or transaction attempted by DMG; no pending write intentions'
}
save(hand,'R03_VLAB_HANDOFF_READONLY.json')

# provenance continuity and no-repeat
old_files=['PSV_SUCESSAO_DMG_R01_20261015.md','bronze5_four_pairs_replay.json','replay_bronze5.py','PSV_DMG_R02_20261015.md','R02_PAGE_LEDGER.json','R02_ACTION_LEDGER.json','R02_COMPARATIVE_RESULTS.json','R02_CHECKPOINT.json','DMG_R02_RECONSTRUCAO_CIENTIFICA_MESTRE_SIDE.zip']
old_manifest=[dict(filename=f,sha256=hashlib.sha256((OLD/f).read_bytes()).hexdigest(),size=(OLD/f).stat().st_size,untouched=True) for f in old_files]
save(old_manifest,'R03_PARENT_INTEGRITY_READBACK.json')

# Independent summary results, no global %
primary=[a for a in A if a.get('role')=='INITIAL' and a['rank_triple_concordance']]
lines=[]
for a in sorted(primary,key=lambda x:('Prata 1','Prata 5','Ouro 1').index(x['rank_title'])):
    lines.append('| [%-s](%s) | %s | `%s` | %.1f | %d | %.1f | %.3f | %.3f |' % (a['species_body'],a['source'],a['name'],a['formula'],a['intrinsic_expected'],a['attribute_value'],a['gross_expected'],a['RD_conditional']['25']['mean'],a['RD_conditional']['35']['mean']))
page_stats=D['strata_rank_conflicts'];allconf=sum(x['title_body_mismatch'] for x in page_stats.values());treeconf=sum(x['tree_mismatch'] for x in page_stats.values());concord=sum(x['triple_agree'] for x in page_stats.values())
assert allconf==21 and treeconf==23 and concord==6
rd_tab=[]
for v in D['RD_crossover_Prata1']['conditional_equal_RD']:
    if v['rd'] in [5,15,25,30,31,35]:
        rd_tab.append(f"| {v['rd']} | {v['raio']['mean']:.4f} | {v['patada']['mean']:.4f} | {v['winner']} |")
generic=D['generic_comparison_not_replacing_fichas']['Prata']
R03='''# PSV — OP-DMG-CORPUS-EMP-01 | R03, coorte congelada independente e sensibilidade RD/CA

**AS-OF:** 15/10/2026. **Natureza:** pesquisa Mestre-side READ-ONLY, não canônica. **Identidade:** CM-000001 funcional (sem writer/lease/INSTANCE-ID herdado). **Base normativa:** DMG-RANK-01 v1.1 preservada. **R02 aceita pelo Mestre, R01–R02 arquivos originais intocados.**

## ANTES — fronteira R02

- Lote Científico 002: 45 páginas relatadas, relatório textual recuperado, ZIP físico localizado 1.027.152 bytes (catálogo), SHA histórico `4b76b69612105956805c7f6ca067f0022fb1ddc335eaed61dcbc8cb72c57c307` **sem auditoria independente**. Nenhuma nova tentativa de materialização.
- Lote Científico 003: 71 páginas, 56 registros, 108 componentes e 23 conflitos **RELATADOS**, sem manifesto; pertencimento físico individual autenticado: **0/71**.
- Duas coortes SEPARADAS: coorte histórica 003 relatada 9 ações/7 páginas/5 pares/3 inversões; reconstrução pós-hoc R02 9/7/5/3, com média `24,1667`, mediana `26,5`, IQR `5,5`, MAD `2,0`, mínimo `11,5`, máximo `28,5`, soma de médias dos dados `35,5` e atributos `182`. Igualdade de estatísticas **NÃO prova a mesma proveniência**.
- R02 reabriu 20 páginas, reproduziu 22 expressões e não provou incremento de cobertura das 116. F0 4/8 documentais, global não certificado.

## DESENHO CONGELADO **ANTES** dos dados numéricos da R03

`R03_PREREG_FROZEN.json`, SHA-256 **%s**. Consulta nominal Notion Bronze5, Prata1, Prata5, Ouro1; exclusão dos 20 IDs R02; até 12 IDs exatos lexicograficamente menores em cada Prata1/Prata5/Ouro1. As 13 fichas de título Bronze5 já estavam nas 20 de R02, portanto **0 novas Bronze5 elegíveis neste recorte**, sem substituição oportunista. Seleção: **36 páginas fixadas** antes da inspeção das mecânicas, sem filtrar pelo dano; sem amostragem probabilística nem validação cega global.

## DEPOIS — cobertura física e denominadores **separados**

| Indicador R03 | Comprovação local |
|---|---:|
| Páginas oficiais do recorte predefinido reabertas | **36/36** (novas em relação às 20 R02, sobreposição com L002/L003 desconhecida) |
| Rótulos de espécie na árvore (não equivalem a IDs individuais) | **34 rótulos/36 páginas**; Cristalino Gélido e Aurora Radiante aparecem em 2 fichas cada |
| Páginas com ao menos um registro matemático selecionado | **20/36** |
| Páginas sem registro matemático selecionado | **16/36** (não = dano zero) |
| Expressões matemáticas classificadas por papel | **28**, das quais **21** fórmulas iniciais de dano potencial, além de curas/drenagem/ticks/reação separados |
| Registros de efeito analisados, incluindo fórmula incompleta | **29** |
| Componentes matemáticos nas 28 expressões | **54** (grupos de dados, atributos e fixos; não são ataques independentes) |
| Outros efeitos com matemática não equivalente a impacto | **3** ticks condicionais, **1** reação/aura, **1** drenagem de PA e **2** curas |
| Fonte com fórmula incompleta | **1** (dano da arma + INT sem arma conhecida) |
| Páginas título/corpo/árvore rank integralmente concordantes | **6/36** |
| Páginas título/corpo rank discordantes | **%d/36** |
| Páginas árvore/título rank discordantes | **%d/36** |
| Páginas conflitantes ao menos em um desses dois eixos | **30/36** (conjuntos sobrepostos) |
| Fórmulas iniciais elegíveis na comparação por rank estrito | **6 ações / 6 páginas / 6 clusters físicos** |
| Páginas da R03 provadas pertencentes ao L003 | **0/36** |
| Incremento comprovado do histórico de 116 | **0**, não incrementar denominador sem IDs |

**Importante:** %d conflitos árvore/título neste *novo recorte* não são os 23 conflitos históricos alegados no Lote 003. Nas fichas com árvore, título e corpo discordantes não existe decisão universal desta pesquisa de qual evidência vence. Rankings científicos estritos incluem só as páginas três-vias concordantes. Etiquetas de identidade divergentes permanecem registradas por UUID físico sem fusão de criaturas.

## 1. Camada A e B — a coorte primária realmente independente

| Ficha física | Habilidade | Fórmula literal | Dado médio A | Atributo | Bruto médio B | C após RD25 | C após RD35 |
|---|---|---|---:|---:|---:|---:|---:|
%s

Totais das **6 ações de 6 páginas**: médias dos dados somam **41**; atributos explícitos somam **210**; médias brutas somam **251**. Participação descritiva ponderada pelo dano bruto **210/251 = 83,6653%%**. Cada uma das seis expressões tem bônus do atributo maior que seu valor médio de dados. Isso se sustenta **nesta nova seleção pré-fixada**, mas não valida o universo de Bestas nem é replicação cega do L002/L003.

Por rank reconciliado três-vias: **Prata1 3 criaturas/3 ações, média bruta 35,0**; **Prata5 2/2, 48,75**; **Ouro1 1/1, 48,5**. Há sobreposição entre patamares: a Estalactite Prata5 apresenta 55,5 > Mordida/Patada Ouro1 de 48,5; uma criatura Ouro1 isolada não estabelece média geral Ouro. A inferência correta é de **sobreposição de fontes**, não progressão sistematicamente decrescente nem desequilíbrio populacional demonstrado.

As médias são **dano bruto condicionado à realização do efeito**, não incluem acerto, ação adicional, defesa, crítico ou magias de resistência; as colunas de C usam cenários numéricos de RD homogênea aplicável. Tipos de dano e salvaguardas não foram artificialmente convertidos em um mesmo evento real.

## 2. Achado novo discriminante: RD inverte a hierarquia mesmo sem inverter o bruto

Duas páginas Prata1 com classificação concordante foram recuperadas:
- [Águia Arranha Céu](https://app.notion.com/p/206c2b324ede835383a1818a6edd5273), Raio Paralisante `1d4+INT30`, bruto médio **32,5**, mínimo31/máximo34; Fortitude interfere no efeito de paralisia.
- [Lupusventus / lobo da caverna](https://app.notion.com/p/4bac2b324ede8321af6b01eb96452d04), Patada `2d6+FOR25`, bruto médio **32**, mínimo27/máximo37; identidade árvore/corpo exige cautela, UUID distinto. Bônus narrativo +2 FOR não adicionado sem demonstrar ativação/estado.

Aplicando **somente como cenário de mitigação comum e condicional ao acerto** `max(0, bruto − RD)`:

| RD | Raio, média líquida | Patada, média líquida | Ordem |
|---:|---:|---:|---|
%s

Em **RD31**, o Raio ainda supera o limiar de dano positivo em **3/4** dos lançamentos e a Patada em **7/12**, mas a Patada tem **média líquida maior** (**14/9** contra **3/2**) por sua cauda de resultados. Em **RD35**, o Raio não causa dano líquido nas rolagens comuns (**0**), enquanto a Patada tem **P(dano>0)=1/12** e dano líquido médio **1/9** condicionado ao acerto.

Portanto, a simples média bruta é insuficiente para hierarquizar habilidades quando RD corta a cauda da distribuição. **Conflito mecânico novo:** a ficha da Águia declara `Rank: prata 1 (1d6)`, enquanto o Sistema de Combate define Prata como `2d6` para testes. Isso não altera o dado de **dano** `1d4`, mas impede inferir legitimamente a distribuição de **acerto** sem aplicar precedência competente.\n\n**Limite essencial:** Raio e Patada têm naturezas distintas, e não foi comprovado que a mesma RD/resistência se aplica integralmente a ambos em um alvo real. Isso é um *experimento matemático controlado*, não prova de que uma delas é superior em combate.

## 3. Controles históricos e novos conflitos de dependência

- [Behemoth Glacial, ficha Prata5](https://app.notion.com/p/1fdc2b324ede82bd9d4f811abb689440): Estilhaços `2d6+DES45` **52** versus Mordida `3d6+FOR15` **25,5**. A média intrínseca é 7 versus 10,5, invertida após atributos. A árvore ancestral indica Ouro1; este **par é válido aritmeticamente na mesma página**, não entra nos seis casos três-vias de rank.
- [Behemoth Glacial, ficha Ouro1](https://app.notion.com/p/5dac2b324ede83f39cdb01a904ce3cfd), já conhecida do R02: mesmas fórmulas de dados; DES52 e FOR18 dão **59** e **28,5**. Entre as duas páginas o aumento de médias (+7 e +3) vem **exclusivamente dos atributos transcritos**, não de novos dados. Comparação de versões físicas de mesma espécie, **não prova que se tratou da mesma Besta evoluindo**.
- [Cristalino Gélido P1](https://app.notion.com/p/0c9c2b324ede82ab8be801371d927931) e [P5](https://app.notion.com/p/08cc2b324ede8378a3a7018646e2d5cd): `1d6+INT40` → `1d6+INT52`; salto aritmético **+12**, totalmente no atributo, mas o ancestral P1 aparece em árvore Prata5, pendendo genealogia/rank.
- Três pares intraficha exploratórios foram comparados, **2 inversões** (Behemoth e Fúria de Chamas), **nenhuma com todas as classificações três-vias concordantes**. As páginas de Fúria e Raposa não entram em análises canônicas de rank sem decisões de classificação. Nenhum par equivale automaticamente aos 5 pares históricos L003 nem aos 5 pares R02.
- [Rinolupo](https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3): possui `RDF 10` documentada além da RD geral Prata15 da norma. **Não somar 10+15 nem escolher máximo** até a precedência de efeitos físicos ser demonstrada; a transcrição é útil para um teste discriminante do VLAB.

A média bruta mais baixa das 21 fórmulas iniciais no recorte amplo foi **2,5**, a maior **74**, com mediana **42**; várias dessas ações têm classificações conflitantes. Portanto **não** calcular uma tendência entre ranks a partir das 21 como se fossem 21 criaturas independentes ou todas válidas por rank.

## 4. Ataque genérico não pode apagar exceções legítimas

A Criação de Besta estabelece Prata normal `6d6` (média **21**) como dano-base genérico, enquanto a fonte de ação específica pode trazer `1d4+INT` ou `2d6+FOR`. Contra RD25, o `6d6` genérico apresenta dano líquido médio exato **%s** (≈ %.4f) por ocorrência condicional e **não** substitui os ataques impressos. Contra RD35, o `6d6` ainda pode superar o limite apenas com seis resultados 6, de probabilidade **1/46.656**, com dano líquido médio **1/46.656**, ao passo que a Patada específica causa média **1/9** no modelo RD homogênea. Isso mostra tanto o potencial quanto o risco de substituições genéricas: comparar DME intrínseco com bruto+atributo são grandezas distintas.

## 5. Camadas D, E e F — precisão, ações, VLAB

**Para os seis novos ataques de rank concordante:** Luta/proficiência individual, modo exato de acertar magia e alvos, custos especiais e Reações ainda não estão documentados de forma que permita probabilidades reais de acerto ou eficiência por turno. Portanto **D e E ficam PENDENTES**, não zerados. Um *modelo apenas algébrico* para os dois ataques Prata1 acima em RD25 dá `7,5×p_raio` contra `7×p_patada`; com `p_patada>0`, o raio só domina se `p_raio/p_patada > 14/15`. A perda relativa superior a **6,67%%** de precisão, se realmente ocorrer, já reverte a pequena vantagem em C. Qualquer Reação que altere essa proporção pode mudar o resultado; não presumimos sua frequência.

**Exceção documentada e restrita:** a Rabada do Frígido Ossário na [operação VLAB R32](https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2) recebeu **Luta+6** apenas na rolagem de acerto daquela habilidade, FOR18, `1d6+FOR18`, uma Ação Padrão, sem PA adicional. Na sonda R32 real-fonte de sandbox, ataque27>CA20, bruto21, RD5, líquido16; Vida da Cabra38→22 só em sandbox. **DMG não abriu nem executou evento novo de VLAB.**

Como sensibilidade teórica **sem crítico e sem Reação voluntária**, com d6 de acerto +24 (FOR18+Luta6) e RD5 na Cabra, o dano líquido médio por tentativa elegível é: **16,5 contra CA20**, **2,75 contra CA29** e **0 contra CA30**. Uma Ação Padrão perdida nesse cenário condicional equivale a renunciar ao valor 16,5 de um ataque elegível; não aplicar isso universalmente a magias ou a outras Bestas. Isso explicita a força da CA sem reexecutar a R32.

## 6. Limites de prova e Lote 003

- L003 **0/71 páginas** com pertencimento original autenticado; 56 registros e 108 parcelas históricas permanecem RELATADOS, não contados neste delta.
- Lote 002 segue **LOCALIZADO — INTEGRIDADE BINÁRIA NÃO VERIFICADA**; nenhuma tentativa de materialização repetida.
- A R03 contém **36 fichas realmente reabertas**, e são novas **somente em relação às 20 da R02**, não comprova 36 novos fora das 116 relatadas. Não declarar 152 nem novo D0 global.
- 21 divergências título/corpo e 23 de árvore/título neste recorte selecionado **não** são 44 conflitos distintos e tampouco reconstituem os 23 do histórico L003.
- Ranks e identidades sob conflito não foram corrigidos nas fichas. O rank competente não foi atribuído silenciosamente por título, corpo ou árvore quando divergentes.
- Holdout cego externo, auditor cego independente, custo de PA, RD/RDF por tipo, alcance/área, precisão, custo por ação e resistências especiais impedem conclusão de balanceamento global.

## 7. Estado de continuidade (checkpoint antes/depois)

- **OPERATION:** OP-DMG-CORPUS-EMP-01.
- **BASELINE:** DMG-RANK-01 v1.1 inalterada; F0 documental histórico **4/8**, não promovido.
- **LAST-VERIFIED-UNIT:** 36 fichas do prereg R03 reabertas; 28 distribuições A/B e 7 limiares RD por expressão verificados por exaustão discreta (ver recibo local); seis páginas três-vias concordantes para comparações por rank.
- **FIRST-PENDING:** identidade dos 71 IDs do Lote003, rank de 30/36 páginas discrepantes nesta nova amostra, gates de acerto/ações para seis habilidades principais.
- **NO-REPEAT:** R01/R02 originais preservados; não reenviar ZIP002 bloqueado para materialização; não contar fichas R03 como L003; não repetir Rabada seed223 VLAB; não promover coorte candidata pós-hoc R02 a histórico autenticado.
- **UNKNOWN-EFFECT:** sem operações de escrita no Notion nesta rodada; sem resultado produtivo não reconciliado.
- **AUTHORITY/WRITER:** leitura e cálculo documental autorizados, nenhuma herança de instance/writer/lease, produção **HOLD**.
- **NEXT-5:** (1) preservar e entregar pacote local e hashes R01/R02 já conferidos; (2) confrontar, quando surgir manifesto antigo, os 36 novos IDs com 71 L003 por interseção; (3) obter autoridade específica título/corpo/árvore nos 30 conflitos sem mexer em fichas; (4) encaminhar os cinco casos discriminantes ao VLAB pelo contrato existente com gate próprio; (5) expandir próxima coorte fixa para fontes novas, inclusive B5 não reutilizadas se houver fontes oficiais adicionais, e controlar regressões estatísticas.
- **TARGET REMAINDER:** L003 71 IDs por conciliar, 56 fórmulas e 108 componentes históricos por proveniência, 23 conflitos históricos pendentes, F0 4/8, denominador de corpus global **NÃO DETERMINÁVEL**.
- **F0–F18:** avanço local demonstrado em F1–F6 (descoberta, proveniência, extração e rank/efeito) e F7–F12 (sensibilidade de dano, RD/CA e hipóteses para VLAB); nenhum gate terminal/global certificado.
- **NAC-PASS-02:** integridade e matemática do sandbox PASS local; aprovação/sincronização física no Notion e gate de escrita produtiva **HOLD**. Zero alterações canônicas.

**Conclusão científica limitada:** numa nova amostra não ajustada aos nove ataques históricos, bônus explícitos continuam dominando a média bruta do recorte validado (83,6653%%); e a ordem de eficiência *condicionada ao acerto e a uma mesma RD* pode inverter-se a partir de RD31 **mesmo sem mudança das fórmulas e sem vantagem na média bruta**. Isso justifica ensaios discriminantes sobre exata RD, precisão e reações, mas ainda não autoriza recalibrar DMG-RANK ou concluir equilíbrio/desequilíbrio do RPG.
''' % (D['prereg_sha256'],allconf,treeconf,treeconf,'\n'.join(lines),'\n'.join(rd_tab),generic['RD']['25']['fraction'],generic['RD']['25']['mean'])
(R/'PSV_DMG_R03_20261015.md').write_text(R03,encoding='utf-8')

# Structured checkpoint that survives a new chat
checkpoint={
 'AS_OF':'2026-10-15', 'OPERATION':'OP-DMG-CORPUS-EMP-01',
 'BASELINE':'DMG-RANK-01 v1.1 OFICIAL INALTERADA; R01/R02 original files preserved; F0 4/8',
 'ANTES_R02':'20 pages, 22 numerical expressions, posthoc 9/7, lot003 0/71, PDF/ZIP002 bytes inaccessible',
 'DEPOIS_R03':'36 distinct non-R02 pages, 20 with numeric evidence, 28 exact PMFs, 21 initial damage expressions, 54 math parts, 6 rank-triple-concordant independent initial actions, 3 within-page pairs with 2 inversions, one RD crossover at RD31; no Notion writes',
 'LAST_VERIFIED_UNIT':'Preregistered 36/36 source UUID readbacks; 28 PMFs exact; RD scenarios and strict rank strata reproduced; last source a6ac2b324ede83338bd9817502b3232a (Gárgula Ouro1-title) no numeric attack',
 'FIRST_PENDING':'Obtain original Lote003 71 source ID manifest; resolve rank authority of title/body/tree for 30/36 conflicts when competent; document hit/cost/reaction for six strict actions',
 'DENOMINATORS':{'historic_L002_reported_pages':45,'historic_L003_reported_pages':71,'historic_union_reported_pages':116,'new_R03_pages_fetched':36,'new_relative_to_R02_20':36,'new_proven_outside_L002_003':0,'pages_proven_L003':0,'numeric_expr_R03':28,'initial_damage_expr_R03':21,'math_components_R03':54,'strict_page_rank_agreement':6,'strict_initial_damage_actions':6,'title_body_disagreement_R03':21,'tree_title_disagreement_R03':23,'conflict_union_R03':30,'historical_conflicts_L003_reconciled':0,'pairs_historic_auth':0,'pairs_R03_exploratory':3,'within_pair_inversions_R03':2},
 'NO_REPEAT':['Never re-count R02 pages or L003 pages by title','Do not retry ZIP002 materialization without new route','Do not reexecute R32 native seed223','Do not relabel Prata1/P5/O1 conflicts as canonical rankings','Do not treat new dossier as official Notion synchronization'],
 'CONFLICTS':'30/36 ranking discordances in fixed sample; Rinolupo RDF10 vs RD15 unresolved; skill costs, precision and resource save unresolved; R02 nine/seven remains posthoc separate from L003',
 'UNKNOWN_EFFECT':'No Notion mutation attempted; no VLAB run by DMG',
 'NEXT_5':['Preserve artifacts and read back local hash manifest','Reconcile R03 36 IDs against physical L003 manifest if recovered','Decide authority/precedence for 30 ranking-conflicted source pages without editing','Route qualified VLAB discriminator cases under existing contract after receiving acceptance','Pre-register next discovery cohort if new distinct B5 pages or higher-star sources exist'],
 'TARGET_REMAINDER':'71 L003 historical source identities, 56 formula rows, 108 math parts, 23 historic conflict IDs; total global NOT_DETERMINABLE',
 'AUTHORITY_WRITER_STATE':'MESTRE-SIDE READ_ONLY; CM-000001 functional only; no inherited instance/writer/lease; production HOLD',
 'F0_STATUS':'4/8 documentary unpromoted', 'F1_F12':'LOCAL_SCIENTIFIC_DELTA_NON_TERMINAL',
 'CANONICAL_MUTATIONS':0, 'NOTION_WRITE':False,'VLAB_NEW_EVENTS':0,
 'LOCAL_QA':'R03_REPLAY_TEST_RECEIPT.txt PASS; external blind QA not performed',
 'NAC_PASS_02':'LOCAL_MATH_PASS_GLOBAL_HOLD'
}
save(checkpoint,'R03_CHECKPOINT.json')

# Manifest over all fixed data/code/report/handoff excluding the manifest itself and bundle.
files=['R03_PREREG_FROZEN.json','replay_dmg_r03.py','make_delivery_r03.py','R03_PAGE_LEDGER.json','R03_EXPRESSION_LEDGER.json','R03_NONNUMERIC_AND_CONDITIONAL_LEDGER.json','R03_COMPARATIVE_RESULTS.json','R03_INITIAL_DAMAGE.csv','R03_RUNTIME_SUMMARY.json','R03_REPLAY_TEST_RECEIPT.txt','R03_PARENT_INTEGRITY_READBACK.json','R03_VLAB_HANDOFF_READONLY.json','PSV_DMG_R03_20261015.md','R03_CHECKPOINT.json']
manifest={'schema':'R03-SHA256-MANIFEST','operation':'OP-DMG-CORPUS-EMP-01','as_of':'2026-10-15','file_count':len(files),'files':[{'name':n,'bytes':(R/n).stat().st_size,'sha256':hashlib.sha256((R/n).read_bytes()).hexdigest()} for n in files]}
save(manifest,'R03_MANIFEST_SHA256.json')
files.append('R03_MANIFEST_SHA256.json')
zipname='DMG_R03_INDEPENDENT_COHORT_CROSSRANK_MASTER_ONLY.zip'
with zipfile.ZipFile(R/zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in sorted(files):z.write(R/file,arcname=file)
with zipfile.ZipFile(R/zipname) as z:
    assert z.testzip() is None
    zset=set(z.namelist())
    assert zset==set(files)
    check=json.loads(z.read('R03_MANIFEST_SHA256.json'))
    for f in check['files']:
        assert hashlib.sha256(z.read(f['name'])).hexdigest()==f['sha256'],f['name']
assert all(hashlib.sha256((OLD/f['filename']).read_bytes()).hexdigest()==f['sha256'] for f in old_manifest)
print(json.dumps({'report_lines':len(R03.splitlines()),'zip':str(R/zipname),'zip_sha256':hashlib.sha256((R/zipname).read_bytes()).hexdigest(),'zip_bytes':(R/zipname).stat().st_size,'manifest_files':len(files),'pages':len(P),'initial_actions':D['initial_HP_damage_formula_count'],'strict':D['independent_rank_agreed_initial_count'],'local_PASSED':True},ensure_ascii=False,indent=2))
