#!/usr/bin/env python3
"""C76 reproducible cold QA of OP-DMG-CORPUS-EMP-01 C71-C75 packages.
Source ZIPs are adjacent to script. No API/network. No canonical writing.
"""
from pathlib import Path
import hashlib,zipfile,io,csv,json,tempfile,subprocess,sys
root=Path(__file__).resolve().parent
filenames={
'C70':'DMG_C70_C66_C69_REPLAY_AND_SCOPE_MESTRE_ONLY.zip',
'C71':'DMG_C71_CRITICAL_WEAKNESS_BOUND_MESTRE_ONLY.zip',
'C72':'DMG_C72_MANOPLA_RIDER_PMF_MESTRE_ONLY.zip',
'C73':'DMG_C73_INSCRIPTIONS_TREE_CLOSURE_MESTRE_ONLY.zip',
'C74':'DMG_C74_MATRIZES_TWO_LEVEL_SCOPE_MESTRE_ONLY.zip',
'C75':'DMG_C75_34_PADROES_29_RECEITAS_MESTRE_ONLY.zip'}
assertions=0
archives={}
for name,f in filenames.items():
    assert (root/f).is_file()
    z=zipfile.ZipFile(root/f)
    assert z.testzip() is None
    manifests=[n for n in z.namelist() if n.endswith('_MANIFEST.json')]
    assert len(manifests)==1,(name,manifests)
    manifest=json.loads(z.read(manifests[0]))
    for n,rec in manifest.items():
        assert hashlib.sha256(z.read(n)).hexdigest()==rec['sha256']
    assertions+=2+len(manifest)
    archives[name]=z

# Reproducible exact-math script replay without original filesystem paths.
for n,script,csvname in [('C71','exact_weakness_crit_sensitivity.py','C71_30_HYPOTHETICAL_ROWS.csv'),('C72','C72_source_conditionals.py','C72_45_SCENARIOS_MANOPLA.csv')]:
    z=archives[n]
    with tempfile.TemporaryDirectory() as d:
        d=Path(d);(d/script).write_bytes(z.read(script))
        out=subprocess.run([sys.executable,str(d/script)],capture_output=True,text=True,timeout=20)
        assert out.returncode==0,(n,out.stdout,out.stderr)
        assert (d/csvname).read_bytes()==z.read(csvname)
        assertions+=2

c69=zipfile.ZipFile(io.BytesIO(archives['C70'].read('DMG_C69_RECETAS_C47_FAILCLOSED_MESTRE_ONLY.zip')))
old=set(c69.read('C69_935_MIXED_PROVENANCE_IDS.txt').decode().split())
intermediate=set(archives['C74'].read('C74_942_KNOWN_SCOPED_IDS.txt').decode().split())
end=set(archives['C75'].read('C75_ALL_950_SCOPED_IDS.txt').decode().split())
assert (len(old),len(intermediate),len(end))==(935,942,950);assert old<intermediate<end
assert len(intermediate-old)==7 and len(end-intermediate)==8
assertions+=4

rows73=list(csv.DictReader(io.StringIO(archives['C73'].read('C73_17_PARENTS_14_RECIPES.csv').decode())))
rows74=list(csv.DictReader(io.StringIO(archives['C74'].read('C74_MATRIZES_8_7_PROVENANCE.csv').decode())))
rows75=list(csv.DictReader(io.StringIO(archives['C75'].read('C75_9_ENCHANTMENTS_8_RECIPES.csv').decode())))
assert len(rows73)==17 and len(rows74)==9 and len(rows75)==9
parents73={r['parent_id'] for r in rows73}
parents74={r['parent_id'] for r in rows74}
parents75={r['parent_id'] for r in rows75}
child73={r['recipe_child_id'] for r in rows73 if r['recipe_child_id']}
child74={r['child_recipe_id'] for r in rows74 if r['child_recipe_id']}
child75={r['recipe_id'] for r in rows75 if r['recipe_id']}
assert len(parents73)==17 and len(parents74)==8 and len(parents75)==9
assert len(child73)==14 and len(child74)==7 and len(child75)==8
assert len(parents73|parents74|parents75)==34
assert len(child73|child74|child75)==29
assert not ((parents73|parents74|parents75)&(child73|child74|child75))
assert child73|child74|child75 <= end
assert child74 == intermediate-old
assert child75 == end-intermediate
assertions+=10
c69_rows=list(csv.DictReader(io.StringIO(c69.read('C69_C47_FAILCLOSED_7_OFFENSE.csv').decode())))
assert len(c69_rows)==7 and all(r['admissible'].lower()=='false' for r in c69_rows)
assert sum(r['effect_kind']=='OFFENSE_NARRATIVE' for r in rows74)==2
assert sum('OFFENSE_NARRATIVE' in r['description_category'] for r in rows75)==2
assertions+=3

for z in archives.values():z.close()
c69.close()
print('C76 COLD PASS', assertions, 'checks;','6 ZIP CRC + 6 manifests; exact scripts replayed; IDs 935→942→950; 34 patterns/29 linked recipes; F6 0/11')
