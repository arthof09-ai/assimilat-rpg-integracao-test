#!/usr/bin/env python3
"""DMG C17: source-scoped science only; never runs VLAB or modifies Notion.
Usage: python c17_empirical_science.py --r71 <R71.csv> --r81 <R81.csv> --plan <historical_plan.zip> --out <dir>
"""
import argparse,csv,hashlib,itertools,json,math,statistics,zipfile
from collections import Counter,defaultdict
from pathlib import Path

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def jwrite(p,data):Path(p).write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
def cwrite(p,rows):
 rows=list(rows)
 if not rows:return
 with open(p,'w',encoding='utf8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def pmf(expr):
 # no general evaluator: these exact source-owned dice contracts only
 dice,fix=expr
 a={0:1}
 for n,sides in dice:
  for _ in range(n):
   b=defaultdict(int)
   for x,nways in a.items():
    for v in range(1,sides+1):b[x+v]+=nways
   a=dict(b)
 return {k+fix:v for k,v in a.items()}
def quantile(p,q):
 total=sum(p.values());acc=0
 for x,w in sorted(p.items()):
  acc+=w
  if acc/total>=q:return x
 return max(p)
def exact_stats(p,rd=0):
 total=sum(p.values());values={max(0,x-rd):w for x,w in p.items()} # not for aggregated bins; directly below
 mu=sum(max(0,x-rd)*w for x,w in p.items())/total
 positive=sum(w for x,w in p.items() if x>rd)/total
 return {'mean_after_rd':mu,'p_positive_after_rd':positive}
def moments(p):
 total=sum(p.values());mu=sum(x*w for x,w in p.items())/total
 var=sum((x-mu)**2*w for x,w in p.items())/total
 return {'min':min(p),'max':max(p),'mean':mu,'variance':var,'stdev':math.sqrt(var),'p10':quantile(p,.1),'p25':quantile(p,.25),'p50':quantile(p,.5),'p75':quantile(p,.75),'p90':quantile(p,.9),'microstates':total}

SOURCE=[
 {'name':'Lâmina da Queda Contida','page_id':'3f5c2b324ede81e9aa8ec51f568600e8','last_edited':'2026-10-11T10:48:44.164Z','uri':'https://app.notion.com/p/3f5c2b324ede81e9aa8ec51f568600e8','status':'SEMICANON_INCUBACAO','rank_item':'Ouro Negro','fip':'Entrada','formula':'7d8+15','dice':[[7,8]],'fixed':15,'damage_type':'Cortante ou Perfurante, escolhido antes do ataque, nunca ambos','attack_action':'Ação Padrão','attack_PA':'NOT_EXPLICIT','attack_delivery':'melee single-target on-hit physical','special':'Ancoragem defensiva por Reação, +18 PA, uma vez por descanso, sob deslocamento físico e solo adequado','rider_dice':[], 'rider_pa':None},
 {'name':'Martelo do Portão Faminto','page_id':'3f5c2b324ede81658982d8f47b3ad647','last_edited':'2026-10-10T18:39:05.841Z','uri':'https://app.notion.com/p/3f5c2b324ede81658982d8f47b3ad647','status':'SEMICANON_INCUBACAO','rank_item':'Ouro Negro','fip':'Média','formula':'8d10+12','dice':[[8,10]],'fixed':12,'damage_type':'Impacto/Contundente','attack_action':'Ação Padrão','attack_PA':'NOT_EXPLICIT','attack_delivery':'melee single-target on-hit physical','special':'Apenas contra estrutura não viva, após acerto, +6d8, 25 PA, uma vez por descanso','rider_dice':[[6,8]],'rider_pa':25}
]
BANDS=[('Entrada',38,48),('Baixa',49,58),('Média',59,69),('Alta',70,82),('Ápice',83,96)]
def label(x):
 hits=[n for n,a,b in BANDS if a<=x<=b]
 return hits[0] if hits else 'FORA_SUBBAND_INTEGER_BOUNDARIES_OR_OUT_OF_BAND'

def run(r71,r81,plan,out):
 o=Path(out);o.mkdir(parents=True,exist_ok=True)
 inputs={'r71':{'sha256':sha(r71),'bytes':Path(r71).stat().st_size},'r81':{'sha256':sha(r81),'bytes':Path(r81).stat().st_size},'plan':{'sha256':sha(plan),'bytes':Path(plan).stat().st_size}}
 with zipfile.ZipFile(plan) as z:
  x=json.loads(z.read('products/PRODUTO_4_MATRIZ_PLANO_SUPREMO_19_FASES.json'))
  f=json.loads(z.read('readonly_sources/F0_OITO_REQUISITOS_CROSSWALK.json'))
  gates=json.loads(z.read('readonly_sources/MATRIZ_8_GATES_TRANSVERSAIS.json'))
 matrix=[]
 for item in x['phases']:
  phase=item['phase']
  if phase in ('F3','F5','F6','F7','F8','F9'):
   delta='Two new semicanon ON melee attack definitions with documented RI/FIP/PA caveats'
  elif phase=='F0':
   delta='Existing 19-phase Plan recovered; F0-A5 still first documentary blocker'
  elif phase in ('F11','F12'):
   delta='R68 V2 three-seed native attacks: new cross-cohort sensitivity analysis'
  else:
   delta='No formal change'
  matrix.append({'phase':phase,'objective':item.get('name',''),'before':item.get('state',''),
                 'evidence_inherited':item.get('evidence',''),'minimum_pending':item.get('minimum_pending',''),
                 'C17_delta':delta,'after':'LOCAL_DELTA_NO_FORMAL_PASS','terminal_gate_pass':False})
 cwrite(o/'C17_PLANO_SUPREMO_F0_F18_MATRIZ.csv',matrix)
 f0=[]
 for item in f['items']:
  f0.append({'map_id':item['id'],'mapping_status':'OPERATIONAL_RECONSTRUCTION_NOT_CANONICAL_A_NUMBERING','criterion':item['criterion'],'evidence_inherited':item['observed_evidence'],'state':item['state'],'minimum_pending':item['minimum_pending'],'C17_new_formal_pass':False})
 cwrite(o/'C17_F0_8_REQUISITOS_GAP.csv',f0)
 g=[]
 for item in gates['items']:
  g.append({'gate':item['gate'],'historical_state':item['status'],'C17_new_state':'LOCAL_NOT_TERMINAL','terminal_empirical_certification':False})
 cwrite(o/'C17_8_GATES_QUALITY.csv',g)

 catalog=[];dist=[];cases={}
 for s in SOURCE:
  p=pmf((s['dice'],s['fixed']));m=moments(p)
  full=pmf((s['dice']+s['rider_dice'],s['fixed'])) if s['rider_dice'] else None
  row={k:s[k] for k in ['page_id','uri','name','last_edited','status','rank_item','fip','formula','damage_type','attack_action','attack_PA','attack_delivery','special']}
  row.update({k:m[k] for k in ['min','max','mean','variance','stdev','p10','p50','p90']})
  row['numeric_subband_at_base_mean']=label(m['mean']);row['fip_alignment']='MATCHES_NUMERIC_SUBBAND' if s['fip']==label(m['mean']) else 'NUMERIC_FIP_DIFFERENCE_CONTEXT_REQUIRED';row['explicit_RE_effect']=False;row['independent_definition_count']=1
  row['rider_increment_DME']=sum(n*(faces+1)/2 for n,faces in s['rider_dice']);row['rider_PA_after_eligible_hit']=s['rider_pa'];row['rider_eligible_for_living_targets']=False if s['rider_dice'] else 'NO_OFFENSIVE_RIDER';row['conditional_full_DME_on_eligible_structure_hit']=moments(full)['mean'] if full else None
  catalog.append(row)
  cases[s['page_id']]={'source':s,'base_moments':m,'pmf':p,'rider_full_moments':moments(full) if full else None}
  for rd in [0,15,25,30,40,45,50,55,60,70]:
   d=exact_stats(p,rd)
   dist.append({'page_id':s['page_id'],'source_formula':s['formula'],'hypothetical_physical_RD':rd,**d,'only_if_hit':True,'actual_target_RD_proven':False,'claim':'CONDITIONAL_MODEL_ONLY_NOT_OBSERVED'})
 cwrite(o/'C17_NOVAS_ARMAS_SEMICANON_FIP_ADMISSIBILIDADE.csv',catalog)
 cwrite(o/'C17_DISTRIBUICOES_FISICAS_RD_CONDICIONAL.csv',dist)
 rider=[{'item':'Martelo do Portão Faminto','target':'estrutura não viva','successful_eligible_hits_in_window':hits,'rider_activations':1 if hits>0 else 0,'sum_expected_damage_in_window':(56*hits+27) if hits>0 else 0,'mean_per_successful_hit':56+27/hits if hits else None,'PA_rider':25 if hits>0 else 0,'interpretation':'conditional-on-hit, no attack accuracy, no actor PA viability asserted'} for hits in [1,2,3,5,10,20]]
 rider.append({'item':'Martelo do Portão Faminto','target':'criatura viva','successful_eligible_hits_in_window':5,'rider_activations':0,'sum_expected_damage_in_window':5*56,'mean_per_successful_hit':56,'PA_rider':0,'interpretation':'rider ineligible against creature; attack PA still NOT_EXPLICIT'})
 cwrite(o/'C17_MARTELO_ESPECIALIZACAO_JANELA.csv',rider)

 with open(r71,encoding='utf8',newline='') as fi:raw=list(csv.DictReader(fi))
 a=[r for r in raw if r['cohort']=='R68_V2_PAIRED'];summary=[]
 for k in sorted({(r['attacker_name'],r['target_ca'],r['target_rd']) for r in a}):
  nm,ca,rd=k;rr=[x for x in a if (x['attacker_name'],x['target_ca'],x['target_rd'])==k];bonus=int(rr[0]['source_attack_bonus']);ca=int(ca)
  totals=[sum(v)+bonus for v in itertools.product(range(1,7),repeat=4)];p=sum(v>ca for v in totals)/len(totals);p2=sum(v>ca+2 for v in totals)/len(totals)
  flip=[x for x in rr if x['hit']=='1' and x['positive_critical']=='0' and x['negative_critical']=='0' and ca<int(x['score'])<=ca+2]
  chk=[x for x in rr if ((int(x['score'])>ca)!= (x['hit']=='1')) and x['positive_critical']=='0' and x['negative_critical']=='0']
  summary.append({'cohort':'R68_V2_PAIRED','attacker':nm,'rank_attacker':rr[0]['attacker_rank'],'source_id':rr[0]['source_page_id'],'source_status':rr[0]['source_authenticity'],'source_formula_damage':rr[0]['source_damage_formula'],'source_attack_bonus':bonus,'target_ca':ca,'target_rd':rd,'events':len(rr),'distinct_seeds':len(set(x['seed'] for x in rr)),'runs':len(set(x['scene_run_id'] for x in rr)),'hit_observed':sum(x['hit']=='1' for x in rr),'hit_exact_probability_4d6_no_crit':p,'hit_exact_probability_plus2CA_no_crit':p2,'expected_plus2CA_hitrate_reduction':p-p2,'static_counterfactual_hits_blocked_plus2CA':len(flip),'positive_crit_count':sum(x['positive_critical']=='1' for x in rr),'negative_crit_count':sum(x['negative_critical']=='1' for x in rr),'hit_rule_disagreement_noncrit':len(chk),'damage_post_RD_observed':sum(int(x['damage_after_rd_potential']) for x in rr),'hp_loss_observed':sum(int(x['actual_hp_loss']) for x in rr),'unit_independence':'3 seeds with two policies repeated; attacks dependent','claim':'TEST_PROPOSED_SOURCE_ONLY; static CA sensitivity not full replay'})
 cwrite(o/'C17_R71_R68_PRECISAO_CA2_COMPARADORES.csv',summary)
 r68={'events':len(a),'runs':len(set(x['scene_run_id'] for x in a)),'seeds':len(set(x['seed'] for x in a)),'hits':sum(x['hit']=='1' for x in a),'blocked_by_CA_plus2_static':sum(x['static_counterfactual_hits_blocked_plus2CA'] for x in summary),'positive_crit':sum(x['positive_critical']=='1' for x in a),'negative_crit':sum(x['negative_critical']=='1' for x in a),'unexplained_hit_disagreements':sum(x['hit_rule_disagreement_noncrit'] for x in summary)}
 r62=[x for x in raw if x['cohort']=='R62_EXPLORATORY']
 with open(r81,encoding='utf8',newline='') as fi:v=list(csv.DictReader(fi))
 new={'r71_all_event_rows':len(raw),'r71_all_runs':len(set(x['scene_run_id'] for x in raw)),'r71_all_seeds':len(set((x['cohort'],x['seed']) for x in raw)),'r62_exploratory_event_rows':len(r62),'R68_v2':r68,'r81_all_event_rows':len(v),'r81_runs':len(set(x['run_id'] for x in v)),'r81_distinct_seeds':len(set(x['seed'] for x in v)),'r81_development_event_rows':sum(x['cohort']=='development' for x in v),'r81_holdout_event_rows':sum(x['cohort']=='holdout' for x in v),'r81_holdout_not_used_for_calibration':True,'all_namespaces_distinct':True,'input_provenance':inputs}
 jwrite(o/'C17_PROVENANCE_UNITS_AND_NEGATIVE_CONTROL.json',new)
 # Derived diagnostics and oracle
 expected={'lanc_dme':7*(8+1)/2+15,'hammer_dme':8*(10+1)/2+12,'hammer_rider':6*(8+1)/2,'lanc_var':7*(8*8-1)/12,'hammer_var':8*(10*10-1)/12,'hammer_total_one_hit':8*5.5+12+6*4.5}
 assert catalog[0]['mean']==expected['lanc_dme'] and catalog[1]['mean']==expected['hammer_dme'];assert catalog[0]['variance']==expected['lanc_var'] and catalog[1]['variance']==expected['hammer_var'];assert catalog[1]['rider_increment_DME']==expected['hammer_rider'];assert catalog[1]['conditional_full_DME_on_eligible_structure_hit']==expected['hammer_total_one_hit']
 assert r68['events']==338 and r68['runs']==6 and r68['seeds']==3 and r68['hits']==188 and r68['blocked_by_CA_plus2_static']==0 and r68['unexplained_hit_disagreements']==0
 assert new['r71_all_event_rows']==684 and new['r81_all_event_rows']==128
 assert len(x['phases'])==19 and len(f['items'])==8 and len(gates['items'])==8
 jwrite(o/'C17_INDEPENDENT_MOMENT_ORACLE.json',{'input_hashes':inputs,'closed_form_expected':expected,'PMF_means':[catalog[0]['mean'],catalog[1]['mean']],'PMF_vars':[catalog[0]['variance'],catalog[1]['variance']],'checks':'PASS: independent closed-form dice moments, exact PMF counts, source-cohort denominators, R68 CA no-crit invariants; no codebook second researcher', 'R68_hit_explanation':'Feryn guaranteed over CA83/93 at 4d6+92; Arveth max96 vs CA123; Varok 4d6+100 vs CA123 has 1/1296 ordinary hit; CA+2 eliminates this rare window','evidence_status':'LOCAL_SCIENCE_REPLAY_NOT_CANONICAL_ACCEPTANCE'})
 return {'catalog':catalog,'rider':rider,'r71':summary,'cohorts':new,'files':len(list(o.iterdir()))}

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--r71',required=True);ap.add_argument('--r81',required=True);ap.add_argument('--plan',required=True);ap.add_argument('--out',required=True);z=ap.parse_args();print(json.dumps(run(z.r71,z.r81,z.plan,z.out),ensure_ascii=False,indent=2)[:11000])
