#!/usr/bin/env python3
from pathlib import Path
import csv
out=Path(__file__).resolve().parents[1]/'results'/'C17_INBOX_DMG_TRIAGEM.csv'
records=[
(28,'INFORMAÇÃO','P2-ALTA','HISTORICO','ADAPTAR','R01 origem corpus/VLAB, 104/149 históricos; não reabrir para novo censo sem novo material','C04-C16; IBX34/IBX103','ANTERIOR ao C17; destinatário laboratório sem instance; ACK da origem pendente'),
(32,'INFORMAÇÃO','P2-ALTA','HISTORICO','ADAPTAR','R02 13 fontes e 32 ocorrências, 71 conflitos textuais; não somar às amostras C11','C05 e histórico R02','Fogo 44/43 explicado no IBX34; F0 A6 segue aberto'),
(34,'INFORMAÇÃO','P2-ALTA','HISTORICO','ADAPTAR','R03 Fogo 43 e nove CSV reportados; autorias e versões podem divergir de reconciliação posterior','C04-C16 histórico','Primários I0003 0/9 em leitura posterior IBX69; não canonizar 9/9'),
(44,'DECISÃO DO MESTRE','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R11-R12 B01-B18; B02 PASS documental reportado; 0/2 STRICT','checkpoint R11-R23 histórico','Reconciliação B01-B18 específica separada de F0-F18; não renumerar'),
(50,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R13 B01-B18, Liu e 18 critérios','R11-R23','PA cronologia Liu B04 e B09 continuam fonte-gated'),
(57,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R15 R14 1/18 e 0/2; não confundir testes com critério','R11-R23','Não repetir testes para inflar métricas'),
(58,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R15 auditar B01-B18 e dois combates STRICT se fontes completas','R11-R23','Relato de 18 dossiês não prova aceites finais'),
(66,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R20 primários I0003 e B01-B18; dificuldade de originais','R20 e histórico F0','Sem nova pista não repetir busca genérica; recuperar por ID certo'),
(69,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R21 87+43=130;111 local; interseção43; união198; 0/9 CSV originais na leitura posterior','R20-R23','Verificar 9 primários por hash quando rota material funcionar'),
(73,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R22 B11 crítico, B12 veneno, B15 prova; decisões Mestre pendentes','R22-R23','Não recalcular regra como já aprovada'),
(76,'HANDOFF','P1-URGENTE','HISTORICO_PENDENCIA','ADAPTAR','R23 decisões B11/B12 não canônicas; B15 evento insuficiente','R23 e C16','Sem nova evidência não insistir'),
(92,'HANDOFF','P2-ALTA','VIGENTE_PARCIAL','ADOTAR_DELIMITADO','Galidemus Bronze1 1d4+DES13, apenas documental; 3 questões normativas','C17 triagem fonte; não VLAB engine','FrozenRuleEvidence e decisão normativa PENDENTES'),
(94,'INFORMAÇÃO','P2-ALTA','VIGENTE','ADOTAR','Manual DMG laboratório competente, dados de fonte e VLAB contratos','C04-C17','Autonomia lab não confere writer produção'),
(98,'DECISÃO DO MESTRE','P2-ALTA','VIGENTE','ADOTAR','Réplicas TEST múltiplas autorizadas, sem tocar original','C17 análise local','Não abrir clones Notion sem domínio writer específico'),
(102,'DECISÃO DO MESTRE','P2-ALTA','VIGENTE','ADOTAR','Plano Supremo existente F0-F18 e matriz; mudar objetivo de infraestrutura para ciência','C17 recuperar Plano físico 35 membros','F0 A5 0/7 bytes rebaixada a HOLD, primeiro gate aberto'),
(103,'HANDOFF','P3-NORMAL','VIGENTE_CONSUMIDA_PARCIAL','ADOTAR','R71 684 ataques; R81 128; C17 estratificou R68 338 eventos/3 seeds sem abrir holdout R81','C17 nova sensibilidade CA +2','Não ACK sem writer legítimo'),
(119,'INFORMAÇÃO','P3-NORMAL','VIGENTE_PARCIAL','ADAPTAR','R205 benefício defensivo C16 já analisado; PA R42 só se efeitos fonte-admissíveis','C16 e C17','Não duplicar R205; classificação inscrições PA PENDENTE'),
(124,'INFORMAÇÃO','P2-ALTA','VIGENTE_ANALISADA','ADOTAR','Triagem DMG e Plano Supremo C17, sem reexecutar C16','C17 documento e Biblioteca','Não marcar LIDA/ACK/CONCLUÍDA sem readback e instance'),
]
urls={28:'3f3c2b324ede812d8d9bfc6e398b21b6',32:'3f3c2b324ede8193ad71fb28cc640963',34:'3f3c2b324ede81fb8f6cf31d58f5e605',44:'3f4c2b324ede8101a7f8e5a2c9ab9f43',50:'3f4c2b324ede81859ef8ca78f5cea298',57:'3f4c2b324ede812a89eee06cfa5d046f',58:'3f4c2b324ede81dfbbf0db58b55044a0',66:'3f4c2b324ede81588272fa944dcef641',69:'3f4c2b324ede81d18883c4039f0a6305',73:'3f4c2b324ede81ce9d33d46554ac98ff',76:'3f4c2b324ede81f1bc88e140c79817da',92:'3f9c2b324ede810fa8d2fdac0fea2ab4',94:'3fbc2b324ede813b8272f0c12eeb2a8a',98:'3fbc2b324ede81ecb70de876022f1b5e',102:'3fbc2b324ede813285ebfeaeee964f25',103:'3fbc2b324ede819d8004e6a35aab5b16',119:'3ffc2b324ede81c5bd6ff578a0fa2328',124:'3ffc2b324ede81099311f9621b41273a'}
with out.open('w',encoding='utf8',newline='') as f:
 w=csv.writer(f);w.writerow(['IBX_ID','Notion_URL','Type','Priority','Persistent_State','Requires_ACK','Current_Scientific_Status','Decision','What_Remains_Useful','Evidence','Unresolved'])
 for r in records:
  n,t,p,status,decision,use,evidence,pending=r
  w.writerow([f'IBX-{n}','https://app.notion.com/p/'+urls[n],t,p,'NOVA' if n not in [] else 'UNKNOWN','NO' if n in (119,124) else 'YES',status,decision,use,evidence,pending])
print('Inbox rows:',len(records), 'path:',out)
