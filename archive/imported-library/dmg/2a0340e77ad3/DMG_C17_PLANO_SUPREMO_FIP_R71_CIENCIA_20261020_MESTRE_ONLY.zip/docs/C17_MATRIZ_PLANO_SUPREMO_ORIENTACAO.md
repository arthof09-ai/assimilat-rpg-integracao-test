# C17 — Crosswalk executivo do Plano Supremo EXISTENTE (MESTRE-SIDE)

Este documento **não é outro Plano Supremo**: indexa os arquivos canônicos já existentes em `OP-DMG-CORPUS-EMP-01`, `DMG-METHOD-EMP-01`, `DMG-QA-ACCEPT-01`, `EXT-DMG-EVIDENCE-02`, `PROMPT-DMG-CORPUS-LONGRUN-01` e o ZIP `DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip`.

## Fase ativa e menor lacuna

**F0 = 4/8**, sem novo PASS. F0-A1–A8 são **rótulos operacionais reconstruídos pelos próprios arquivos históricos**, não identificadores normativos oficiais. A5 é o primeiro fechamento formal candidato: sete links/Markdown anexos estão documentados, mas 0/7 arquivos de conteúdo imutável foram recuperados byte a byte no teste histórico; resta prova física independente + writer/documentação do domínio. A6 raiz e D0 parcial, A7 blind holdout não selado, A8 segunda codificação/claim ainda desconhecido. Bloqueio de F0 ≠ proibição de pesquisa exploratória source-scoped.

## Crosswalk por objetivo científico

| Fases existentes | Evidência reutilizada | Trabalho C17 | Limite para PASS |
|---|---|---|---|
| F0 | F0 pré-registro, 7 autoridades, A5–A8 pendentes | Reabertos Plano, Inbox e guardas | 7/7 bytes+readback independente; writer/collision; holdout e second coder |
| F1–F2 | A6 571 referências estruturais, C04–C16 e lotes relatados | Duas novas fontes semicanônicas com UUID; R71/R81 separados | Censo D0 por superfície, alias, mirrors e original L002/L003 |
| F3–F6 | Taxonomia DME, RN/RE/RI/FIP e status | 2 armas, 3 componentes ofensivos, 1 efeito defensivo; sem RE inventado | Mais efeitos elegíveis e código revisado por 2º agente independente |
| F7–F8 | §5 bandas por rank, método de PMF | Convoluções exatas e caudas das 2 armas ON; sem circularidade confirmatória | Células atuais tipo×rank e fontes de origem independente |
| F9–F10 | Estudos R02/R71/R91 e matrizes C11–C16 | Pareamento por RI/entrega; contrafactual R68×R205 apenas H4 | Pareamentos não viciados por chassi, custo, alvo e versão |
| F11–F12 | VLAB R71, R81, R200–R205 | Seeds e fluxo de eventos segregados, holdout R81 não ajustado | Estudos confirmatórios e análise de vieses |
| F13–F18 | Normas e playtest contratados | Não criar candidata v2 | Evidência suficiente, regressão, stress, playtest e decisão Mestre/NAC |

**Primeiro gate local verificável agora:** Q-MATH, limitado às duas fontes e ao contrafactual R68. **Gate empírico global:** nenhum promovido. Ver `C17_PLANO_SUPREMO_F0_F18_MATRIZ.csv`, `C17_F0_8_REQUISITOS_GAP.csv` e `C17_8_GATES_QUALITY.csv`.

**Proibição de inferência circular:** as armas semicanônicas podem ter sido criadas com conhecimento da DMG v1.1. Portanto, estar dentro de sua banda não verifica independentemente a banda; apenas o processo de aplicação e contagem.
