# DMG C17 — Recuperação sem reinício

Operação `OP-DMG-CORPUS-EMP-01`, Mestre-side. O ZIP C17 contém apenas delta científico e scripts simples de **análise offline**; não incorpora, altera ou executa o motor VLAB. DMG-RANK v1.1 e fontes Notion permanecem read-only.

Dependências externas da Biblioteca:
- `DMG_C16_DEFESAS_DINAMICAS_R205_CIENCIA_20261020_MESTRE_ONLY.zip` SHA256 `8169eb651a833dfbfbc00244b4ba259ba2f891e02b4104434e1f15191db1505e`.
- `DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip` SHA256 `397cd335096270ee180b834abb2074b84de68909821ffd6192cac8653fdc6a62`.
- `DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv` SHA256 `f8996f7d3953d83e50b90faf612d7ac037df9ecc15d14238e59ca6ab20760f63`.
- `R77_DMGMETRICS_ATTACK_RECEIPTS_128.csv` SHA256 `cd20b48f9b9633ab26c684c98985b241e42bc88762627915fcf8ec77270a51cd`.

Reprodução (Python stdlib) com esses 3 últimos insumos apontados por caminhos corretos:

```bash
python src/c17_empirical_science.py --r71 '/caminho/DMG_INTERFACE_ATTACK_RECEIPTS_R62_R69.csv' --r81 '/caminho/R77_DMGMETRICS_ATTACK_RECEIPTS_128.csv' --plan '/caminho/DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip' --out '/pasta-vazia/resultados'
python src/c17_inbox_triage.py
```

`c17_inbox_triage.py` sempre escreve em `results/C17_INBOX_DMG_TRIAGEM.csv` relativo à sua localização, portanto para replay independente rode a partir de uma cópia da árvore completa em que `results/` exista.

Não há pretensão de segundo pesquisador real, holdout global ou replay de combate. O método exato calcula as distribuições combinatórias das armas e as chances de CA fixadas em eventos antigos, sem executar lutas. Comparem hashes dos arquivos gerados com as saídas congeladas. R81 holdout não é usado para calibrar hipótese. `MANIFEST_SHA256.json` traz SHA dos membros do pacote; verificação é LOCAL e readback Biblioteca deve ser efetuado separadamente.

**Ponto de retomada:** F0-A5 precisa de 7/7 readbacks físicos dos snapshots e writer legítimo, mantendo pesquisa F1–F12 incremental. Não duplicar Plano Supremo, metodologia, laboratórios nem artefatos C04–C16.
