# DMG C17 — Primeiro parecer de execução científica do Plano Supremo (MESTRE-SIDE)

**AS-OF:** 20/10/2026. **OP:** `OP-DMG-CORPUS-EMP-01`. **Baseline:** `DMG-RANK-01 v1.1` oficial e sem alterações. **Escrita canônica:** NO-WRITE. **F0 formal:** 4/8; **produção:** HOLD.

## A. Pergunta e desenho pré-existente

**Problema central:** um valor de dano de mesmo rank pode ser inadequado por distribuição, defesa, finalidade, ação, PA, frequência ou procedência? A análise C17 confronta novas armas documentadas e antigas observações VLAB que NÃO haviam sido comparadas nesse recorte. Não propõe segunda metodologia nem outro motor.

**Plano recuperado:** `DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip`, SHA256 `397cd335096270ee180b834abb2074b84de68909821ffd6192cac8653fdc6a62`, 35 entradas. Matriz original `products/PRODUTO_4_MATRIZ_PLANO_SUPREMO_19_FASES.json`; oito requisitos locais F0 e oito gates em `readonly_sources/` (F0-A1...A8 constituem **mapeamento operacional reconstruído**, não nova numeração canônica). A fase formal ativa é F0, 4/8; F1–F12 têm contribuições exploratórias, sem PASS formal. F13–F18 não receberam candidata homologada.

**Gate mais próximo da promoção formal:** F0-A5, congelamento da fonte. Histórico: 7/7 fingerprints e sete ponteiros de anexo, mas 0/7 readbacks de **bytes integrais** desses anexos, com versões / escopo parcial e writer/dupla leitura sem prova; A5 permanece PENDENTE. A6 raiz/censo, A7 holdout blindado e A8 autoria/segunda codificação continuam sem aceite. Isso não paralisa comparações locais. A matriz de 19 fases e a matriz de oito gates incluídas neste delta mostram status antes/depois, sem PASS inflado.

## B. Dados primários e denominadores

**Novas fontes deste recorte de C17 (novas em relação ao recorte C04–C16 auditado, não 'inéditas em todo Notion'):**

- `3f5c2b324ede81e9aa8ec51f568600e8` — [Lâmina da Queda Contida](https://app.notion.com/p/3f5c2b324ede81e9aa8ec51f568600e8), última edição Notion 11/10/2026 10:48:44Z. Uma definição de arma, ataque-base `7d8+15`, dano Cortante **ou** Perfurante declarado antes de acertar, Ação Padrão; RI Ouro Negro, FIP Entrada. Poder secundário DEFENSIVO de ancoragem, Reação 18 PA e 1 uso/descanso. Ataque-base PA não explicitado. **Semicanônico/incubação**, sem RE ofensivo independente comprovado.
- `3f5c2b324ede81658982d8f47b3ad647` — [Martelo do Portão Faminto](https://app.notion.com/p/3f5c2b324ede81658982d8f47b3ad647), última edição 10/10/2026 18:39:05Z. Uma definição de arma, base `8d10+12` de Impacto/Contundente, Ação Padrão, corpo a corpo; RI Ouro Negro, FIP Média. **Rider ofensivo** `+6d8` APÓS acerto, 25 PA, 1 vez/descanso e SOMENTE estrutura não viva. Ataque-base PA não explicitado. **Semicanônico/incubação**, sem RE ofensivo autônomo comprovado.

**Denominadores de nova análise documental:** 2 páginas físicas, 2 definições de armas e 3 componentes de dano (2 bases +1 rider), além de 1 efeito defensivo não numérico. Não são 3 armas, 3 criaturas, nem 2 amostras canônicas independentes de calibração. Mesma superfície de origem semicanônica, com risco de viés de design.

**Reutilizados em análise inédita deste recorte:** `R71` CSV original 684 eventos de ataque, 12 execuções; isolou-se `R68_V2_PAIRED` com 338 eventos, 6 execuções e **3 seeds**. R71 contém 3 fichas propostas ON5, não populações independente. `R81` CSV original 128 eventos, 14 execuções, **7 seeds**, das quais 52 linhas desenvolvimento e 76 linhas rotuladas holdout; **não utilizado para calibrar parâmetro** ou promover aceite. R200/R204/R205 preservados, sem rerun.

## C. Resultado novo H3 — FIP não se resume ao ataque-base

DMG-RANK §5 fixa banda Ouro Negro de DME intrínseco **38–96**, com Entrada 38–48, Baixa 49–58, Média 59–69, Alta 70–82, Ápice 83–96; §22 obriga orçamento único da ação composta. Esse DME não inclui atributos ou FF externos.

| Item | DME base | Min–Máx | Variância | p10–p90 | FIP de origem | Subfaixa pelo DME-base |
|---|---:|---:|---:|---:|---|---|
| Lâmina da Queda Contida | **46,5** | 22–71 | **36,75** | 39–54 | **Entrada** | Entrada |
| Martelo do Portão Faminto | **56** | 20–92 | **66** | 46–66 | **Média** | Baixa |

**Não inferir uma classificação alternativa para o Martelo.** A classificação FIP é multicritério e o efeito situacional fornece +27 de DME, elevando uma ÚNICA ação elegível a **83** de dano médio bruto, exclusivamente contra estruturas após acerto e 25 PA. Esse 83 é **o pacote completo** `8d10+12+6d8`, não uma banda integral adicionada por componente. Contra criaturas a parcela +6d8 é INELEGÍVEL.

Sensibilidade por janela **hipotética de acertos elegíveis efetivos**, sem alegar que a estrutura sobreviverá ou que o usuário terá PA: 1 hit = 83; 2 hits = 69,5 por hit; 5 hits = **61,4**; 10 hits = **58,7**; 20 hits = **57,35**. Atribuir 83 a todo acerto seria outro erro; a +27 é uma vez por descanso e depende de oportunidade.

**Resultado científico:** a tensão entre FIP Média documentada e DME-base numericamente Baixa pode ser explicada pela função estrutural. É **alerta contextual**, não defeito nem proposta de reclassificação. A arma semicanônica pode ter sido elaborada CONHECENDO as bandas v1.1, então o encaixe numérico de ambas **não é validação empírica independente** da v1.1: serve para auditar a correta aplicação e detectar problemas de camadas/frequência. Essas fontes não entram no conjunto confirmatório de calibração.

## D. Resultado novo H-C — dano médio não determina utilidade sob RD

Distribuições inteiras exatas obtidas por convolução de dados, verificadas contra médias e variâncias por fórmula fechada. **Teste de sensibilidade, NÃO uma RD atribuída a personagem ou estrutura:** um único componente físico recebe RD55 e se considera acerto válido.

- Lâmina `7d8+15`: DME 46,5; `E[max(dano−55,0)] = 0,2123208046`, `P(positivo)=6,986618%`.
- Martelo `8d10+12`: DME 56; `E[max(dano−55,0)] = 3,78226475`, `P(positivo)=52,408015%`.

A vantagem bruta do Martelo é 9,5 de dano médio (+20,43% sobre a Lâmina), enquanto a diferença pós-RD55 é 3,57 por acerto e o quociente é ~17,8. **Isto demonstra sensibilidade distributiva, não uma regra de balanceamento a partir de RD inventada.** O dado faltante para TTK ou eficiência real é alvo/cenário com CA, RD, Vida, frequência, recursos e atribuição de tipo. Não aplicar a dano misto.

## E. Resultado novo H4 — benefício de +2 CA não é constante entre coortes

Recibo primário [R71/IBX-103](https://app.notion.com/p/3fbc2b324ede819d8004e6a35aab5b16). Coorte R68 V2, seis execuções pareadas, três seeds. As fichas ON5 são PROPOSTAS R52.

| Atacante (ON5) | Acertos / tentativas | `4d6+bônus` × CA | Prob. ordinária exata | Se +2 CA, prob. ordinária |
|---|---:|---|---:|---:|
| Feryn | 188/188 | +92 vs 83 ou 93 | 100% | 100% |
| Arveth | 0/95 | +72 vs 123 | 0% | 0% |
| Varok | 0/55 | +100 vs 123 | 1/1296 ≈ 0,077% | 0% |

**Contrafactual estático sobre rolagens já registradas:** +2 CA mudaria **0/338 resultados observados de acerto ordinário**. Isso não significa que +2 CA seria sempre inútil; a janela de Varok teve probabilidade teórica não nula, mas não ocorreu nas 55 tentativas. Dois críticos NEGATIVOS aparecem na R68, tratados separadamente. O cálculo não executa combate nem reestima Vida terminal.

**Controle externo documental C16/R205:** em 132 ataques com mesmos dados e turno nos dois braços, +2 CA de Defesa de Vento bloqueou **28** oportunidades. Nesse contrato R205 a faixa matemática de acerto ordinário passou de `81/216=37,5%` para `35/216≈16,20%`. Comparar as duas coortes prova HETEROGENEIDADE MATEMÁTICA DE OPORTUNIDADE, não desempenho geral de rank. R205 usa `3d6+60` TEST, R68 usa `4d6+...` e outros atributos/CA. Não agregar 132 e 338 em amostra homogênea.

**Implicação para novas criações:** avaliação de defesa baseada em CA precisa verificar o ataque e a distribuição do adversário, não converter `+2 CA` em um número fixo universal de dano evitado.

## F. Inbox DMG — rota e pendências

A query SQL sobre a Inbox canônica filtrou **18 mensagens** de operação/workstream DMG. Todos os 18 registros persistentes retornaram estado NOVA, o que NÃO prova falta de execução histórica. Metadados mais leitura do corpo das 18 páginas foram triados. A matriz `C17_INBOX_DMG_TRIAGEM.csv` decide individualmente.

- IBX-102: decisão vigente do Mestre → plano já recuperado, matriz C17 ativada, sem cópia concorrente.
- IBX-103: R71/R81 recuperados byte a byte, hash íntegro. Nova análise de R68. R81 holdout não utilizado em ajuste.
- IBX-98: autonomia de réplicas TEST válida, restrita ao laboratório; não legitima escrita canônica.
- IBX-94: reaproveitar carta de laboratório; não criar simulador próprio.
- IBX-92: Galidemus Bronze1 `1d4+DES13` oferece teste DOCUMENTÁRIO 14–17, DME bruto15,5, mas não full-fight; FrozenRuleEvidence e três decisões normativas pendentes. Não reutilizar como combate já aprovado.
- IBX-119: R205 analisado em C16, apenas tipagem de inscrições PA R42 residual.
- IBX-124: triagem realizada aqui; Exige ACK=NO.
- IBX-44/50/57/58/66/69/73/76: instruções históricas R11–R23 sobre B01–B18 e originais I0003. Não estão automaticamente encerradas, mas não reiniciar testes sem novidade. B02 PASS DOCUMENTAL histórico, 1/18, STRICT 0/2 e CSV I0003 0/9 em relatório posterior permanecem **RELATADOS / sem nova recertificação**. Contradição entre IBX34 (nove CSV relatados recuperados) e IBX69 (nenhum primário recuperado posteriormente) demanda readback dos primários, não escolha silenciosa.
- IBX-28/32/34: origem da transferência de dados e da linhagem R01–R03, tratadas como HISTÓRICAS; identidade/ACK do destinatário não presumidos.

**ACK/LIDA/CONCLUÍDA persistente:** sem alteração. A identidade operacional/escritor real não foi comprovada para mudança da Inbox; nenhuma resposta é rotulada como enviada. A análise é COMPLETA LOCALMENTE, não conclusão transacional da comunicação.

## G. Decisão de melhoria e matriz de aceite

1. **MANTER DMG-RANK-01 v1.1** neste checkpoint; sem argumento honesto para recalibrar banda universal.
2. **ADOTAR como critério científico de avaliação**, não nova norma: separar (i) DME intrínseco e suas caudas, (ii) precisão ordinária e críticos, (iii) RD aplicável/tipo, (iv) Vida efetiva, (v) ação e custo, (vi) frequência e alvo/condição, (vii) orçamento único físico+rider. Esse critério deriva das autoridades DMG existentes, especialmente §§4,5,9–11,22.
3. **Novo comparador semicanônico:** 2 fontes físicas / 2 definições de arma / 3 componentes ofensivos; mesmo RI Ouro Negro, Ação Padrão, corpo-a-corpo, mas chassis e condicionais diferentes. **Estrito somente nos eixos identificados**; insuficiente para calibrar o sistema canônico por si só.
4. **Novo comparador VLAB:** R68 V2 338 eventos em 3 seeds, não 338 replicações independentes; efeito de +2 CA ausente nesse cenário vs 28/132 em R205. Não fundir coortes nem contar R62/R81 como independentes comparáveis.
5. **Gate concreto:** Q-MATH **PASS LOCAL** para as duas distribuições e contrafactual fixo de eventos; EVIDENCE-COVERAGE, SOURCE-LINEAGE global, CODEBOOK independente, F0-A5 e OUT-OF-SAMPLE permanecem PENDENTES. **Nenhum F0 pass novo.**

## H. Primeiro ponto de retomada e próximo valor científico

**LAST-VERIFIED-UNIT:** pacotes históricos de Plano Supremo e C16 recuperados; IBX-102/103 e 18 mensagens triadas; nova análise de duas armas semicanônicas, 338 ataques R68 e 128 recibos R81 apenas identificados (sem utilização do holdout). **FIRST-PENDING formal:** F0-A5: recuperar 7/7 bytes integrais dos anexos originais do baseline com readback independente, sob writer/documentação competente; depois A6–A8. **FIRST-PENDING científico independente:** fontes atuais com RE/FIP/ação/custo/alvo completos e independentes da DMG v1.1 para verificar sua adequação sem circularidade.

**NEXT-5:** (1) obter rota de bytes A5 e confirmar 7 snapshots; (2) segunda codificação humana independente/legítima; (3) buscar efeito ofensivo canônico com RI/RE/custo/ação completos para matched pair não circular; (4) negociar seed-pilot VLAB de Chicote se Coordenação priorizar, sem dizer que foi enviado; (5) conciliar prospectivamente chassi físico do Mestre com orçamento único de RI/RE/FIP sob NAC-NORM competente.

**PROVENANCE/NO-REPEAT:** C04–C16, A6-571, L002/L003, R156 UNKNOWN-EFFECT, R138 HOLD, R162/R169 e coortes R200–R205 intactos. Sem inferir rate de vitória de censuras. D0–D9 e E01–E24 são campos de cobertura/gates em aberto, não percentuais certificados. Não reexecutar VLAB, nem modificar SQL/RUN-IDs, sistemas, Bestas, Party ou O Primeiro.

**AUTHORITY/WRITER STATE:** identidade CM-000001 é referência lógica, não credencial de instância; sem writer/lease/epoch/fencing/ACK verificados. Pesquisa em arquivos locais/Library Mestre autorizada, NOTION CANON NO-WRITE. **NAC-PASS:** gate matemático local; aceite formal F0, NAC-PASS global, F13–F18 e produção = HOLD.
