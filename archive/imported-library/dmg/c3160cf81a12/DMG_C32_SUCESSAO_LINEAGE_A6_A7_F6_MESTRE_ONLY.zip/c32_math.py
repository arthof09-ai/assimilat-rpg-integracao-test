#!/usr/bin/env python3
"""RPG Assimilação DMG C32 — exact dice math, independent of VLAB; no canonical interpretation."""
import re,json,collections,itertools,math
from fractions import Fraction
from pathlib import Path
OUT=Path(__file__).resolve().parent
# All lines extracted from directly fetched NOTION MESTRE pages. Parenthetical pools are NOT adjudicated as equivalent modes.
CASES=[
 ('DZ-O','Do Ze','O5/O2 normal+transformada (4 repetições)', '9d8+INT','principal literal A'),
 ('DZ-P','Do Ze','O5/O2 normal+transformada (4 repetições)', '9d6+INT','principal entre parênteses B'),
 ('DZ-T','Do Ze','O5/O2 normal+transformada (4 repetições)', '4d12','tick de morte condicionado à falha'),
 ('DZ-B4','Do Ze','B4 normal (1 ocorrência)', '3d6+INT','principal'),
 ('DZ-B4-T','Do Ze','B4 normal (1 ocorrência)', '2d12','tick de morte condicionado à falha'),
 ('PAN-N-A','Lan Treimor','ON1 bloco normal', '4d6+65','H Ataque principal'),
 ('PAN-N-B','Lan Treimor','ON1 bloco normal', '5d10+4d8+3d10+80','H Ataque parentético'),
 ('PAN-N-P','Lan Treimor','ON1 bloco normal', '4d6+80','Pressão principal'),
 ('PAN-N-PB','Lan Treimor','ON1 bloco normal', '5d10+4d8+3d10+4d12+105','Pressão parentética'),
 ('PAN-T-A','Lan Treimor','ON1 bloco Transformação Espiritual', '4d6+105','H Ataque principal'),
 ('PAN-T-B','Lan Treimor','ON1 bloco Transformação Espiritual', '5d10+4d8+132','H Ataque parentético'),
 ('PAN-T-P','Lan Treimor','ON1 bloco Transformação Espiritual', '4d6+130','Pressão principal'),
 ('PAN-T-PB','Lan Treimor','ON1 bloco Transformação Espiritual', '5d10+4d8+3d10+4d12+157','Pressão parentética'),
 ('RAV-A','Ravin','bloco Atk (não adjudicar modo)', '2d6+37','principal'),
 ('RAV-B','Ravin','bloco Atk (não adjudicar modo)', '7d6+20','parentética'),
]
SOURCE={'Do Ze':{'url':'https://app.notion.com/p/1c7c2b324ede83648b6e0104f9bd2146','notion_last_edited':'2026-10-09T16:49:07.955Z','scope_note':'ONE physical page with 4 high-variant blocks plus B4 normal; not 5 independent spells'},'Lan Treimor':{'url':'https://app.notion.com/p/8f6c2b324ede82c88e5d8184dc3a3b90','notion_last_edited':'2026-09-30T04:36:00.043Z','scope_note':'Indexed Pan Tueimor; body Lan Treimor; normal and transformation headings observed'},'Ravin':{'url':'https://app.notion.com/p/14bc2b324ede834daba501e769feda9d','notion_last_edited':'2026-10-01T09:40:50.721Z','scope_note':'One Atk line with two explicit pools, mode unspecified'}}
RDS=[0,15,25,35,50,75,100,150,200,250]
DICERE=re.compile(r'(\d+)d(\d+)')
def terms(expr):
 dice=[tuple(map(int,m.groups())) for m in DICERE.finditer(expr)]
 remain=DICERE.sub('',expr).replace(' ','').replace('+INT','')
 remain=re.sub(r'\++','+',remain)
 fixed=sum(int(x) for x in re.findall(r'\+([0-9]+)',remain))
 has_INT='+INT' in expr
 assert dice and re.fullmatch(r'(?:\+\d+)*',remain),expr
 return dice,fixed,has_INT

def pmf(dice,fixed):
 counts={fixed:1};total=1
 for n,faces in dice:
  assert 1<=n<=20 and 2<=faces<=20
  for _ in range(n):
   out=collections.defaultdict(int)
   for v,k in counts.items():
    for face in range(1,faces+1):out[v+face]+=k
   counts=out;total*=faces
 assert sum(counts.values())==total
 return counts,total

def expected_after_RD(counts,total,rd):
 numer=sum((v-rd)*n for v,n in counts.items() if v>rd)
 prob=sum(n for v,n in counts.items() if v>rd)
 return Fraction(numer,total),Fraction(prob,total)

def exact_str(f):return f'{f.numerator}/{f.denominator}'

rows=[];checks=0
for ident,who,mode,formula,note in CASES:
 ds,fix,hasINT=terms(formula)
 freq,N=pmf(ds,fix)
 expected=Fraction(sum(k*v for k,v in freq.items()),N)
 moment_formula=Fraction(sum(n*(faces+1) for n,faces in ds),2)+fix
 assert expected==moment_formula,(ident,expected,moment_formula); checks+=1
 variance=Fraction(sum(k*(v-expected)**2 for v,k in freq.items()),N)
 variance_formula=sum((Fraction(n*(faces**2-1),12) for n,faces in ds),Fraction(0))
 assert variance==variance_formula,(ident,variance,variance_formula);checks+=1
 lo=fix+sum(n for n,_ in ds);hi=fix+sum(n*faces for n,faces in ds)
 assert min(freq)==lo and max(freq)==hi;checks+=1
 if N<=300000:
  brute=collections.Counter(fix+sum(xs) for xs in itertools.product(*(range(1,faces+1) for n,faces in ds for _ in range(n))))
  assert brute==freq,(ident,'brute_count');checks+=1
 scenarios={str(rd):{'E_net_exact':exact_str(expected_after_RD(freq,N,rd)[0]),'E_net_float':round(float(expected_after_RD(freq,N,rd)[0]),8),'P_positive_exact':exact_str(expected_after_RD(freq,N,rd)[1])} for rd in RDS}
 prev=Fraction(10**10)
 for rd in RDS:
  val=expected_after_RD(freq,N,rd)[0]
  assert val<=prev; prev=val;checks+=1
 # Note that INT was normalized to zero here ONLY to study distribution: not a claim about character INT.
 rows.append({'id':ident,'source':SOURCE[who]['url'],'body_identity':who,'context':mode,'formula_literal':formula,'role':note,'variable_INT_not_supplied':hasINT,'calculation_INT_parameter':0 if hasINT else None,'mean_without_INT_exact':exact_str(expected),'mean_float':float(expected),'variance_exact':exact_str(variance),'minimum_without_INT':lo,'maximum_without_INT':hi,'total_equally_likely_outcomes':N,'RD_synthetic_sensitivity':scenarios,'RE_FIP_authentication':'NOT_FOUND_IN_LOCAL_SOURCE_FOR_THIS_EFFECT','source_temporal_authority':'CONFLICT_OR_PENDING'})
assert len(rows)==15
by={r['id']:r for r in rows}
assert by['DZ-O']['mean_float']==40.5 and by['DZ-P']['mean_float']==31.5
assert by['DZ-B4']['mean_float']==10.5 and by['DZ-T']['mean_float']==26
assert by['PAN-N-A']['mean_float']==79 and by['PAN-N-B']['mean_float']==142
assert by['PAN-N-P']['mean_float']==94 and by['PAN-N-PB']['mean_float']==193
assert by['PAN-T-A']['mean_float']==119 and by['PAN-T-B']['mean_float']==177.5
assert by['PAN-T-P']['mean_float']==144 and by['PAN-T-PB']['mean_float']==245
assert by['RAV-A']['mean_float']==44 and by['RAV-B']['mean_float']==44.5
checks+=14
result={'operation':'OP-DMG-CORPUS-EMP-01','campaign':'C32 LOCAL / MESTRE-SIDE TEST','baseline':'DMG-RANK-01 v1.1 PRESERVED','certification':'MATH_ONLY, NOT A DMG-RANK TEST NOR F6 fallback proof','notes':['Mode labels derive from section headings; meaning of parenthesized pools remains unresolved.','Do Ze O5/O2 four repeated blocks are not four independent sources/effects; B4 is separate within same physical page.','INT=0 is a mathematical placeholder for distribution, NOT a character statistic.','RD scenarios are synthetic, with no proof applicable to the effect tags, wards, DoT or per-action interpretation.','No chance-to-hit, save, critical, action economy, PA or full-turn duration model.','This package contains no real combat and cannot serve as VLAB contract completion.'], 'source_facts':SOURCE,'cases':rows,'mathematical_assertions_passed':checks,'denominators':{'physical_pages':3,'distinct_literal_formulas':len(rows),'synthetic_RD_values':len(RDS),'mathematical_scenarios':len(rows)*len(RDS)}}
(OUT/'C32_EXACT_DAMAGE_VARIANTS_15.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'RESULT':'PASS','tests':checks,'formulas':len(rows),'RD_cases':len(rows)*len(RDS),'samples':{k:by[k]['mean_float'] for k in ['DZ-O','DZ-P','DZ-B4','PAN-N-A','PAN-T-A','PAN-T-PB','RAV-A','RAV-B']}},ensure_ascii=False))
