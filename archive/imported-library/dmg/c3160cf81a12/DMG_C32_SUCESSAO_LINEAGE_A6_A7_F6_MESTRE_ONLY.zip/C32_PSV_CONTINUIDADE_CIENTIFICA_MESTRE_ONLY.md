# PSV — DMG C32 / retomada científica pós-sucessão — MESTRE-ONLY / TEST

**OPERAÇÃO CANÔNICA EXISTENTE:** `OP-DMG-CORPUS-EMP-01` (https://app.notion.com/p/3f3c2b324ede813e9fa0c87ebdea0b29).  
**ORDEM DO MESTRE:** sucessão autorizada neste chat em 22/10/2026; continuar o Plano Supremo, sem repetir resultados anteriores.  
**ESTADO DA INSTÂNCIA:** executor analítico atual, **sem claim/epoch/lease/writer Notion comprovado**; este relatório NÃO declara posse administrativa exclusiva, ACK da Inbox, nem autorização de escrever OP/Diário/fichas.  
**AMBIENTE:** MESTRE-SIDE; pesquisa TEST e Biblioteca Mestre. Party/O Primeiro: NO-WRITE. VLAB e demais Comestres: NO-WRITE.  
**REGRA:** `DMG-RANK-01 v1.1` oficial INALTERADA. F0 formal **4/8 documental, HOLD**. F1–F18 sem nova promoção. Sem DMG v2, sem combate novo, sem alteração de fonte canônica.

## ANTES — checkpoint legitimamente recuperado

- Última publicação localizada antes deste pacote: `C31_REGISTRO_F6_F0_A6_CONFLITOS_DME_MESTRE_ONLY.md`, na pasta `/Comestre/OP-DMG-CORPUS-EMP-01/`. C31 e adendo reportam G1=411, C29 externo=88, C30=49, C31=131, C31 adendo=120: **799 Page-IDs em coortes delimitadas**, sem D0 global.
- Fonte `DMG-RANK-01 v1.1`: valor explícito tem precedência; RE/RANK + FIP próprios são exigidos para preencher efeito sem número; RI, rank da criatura, título ou preço isolados não provam RE. `PR-ECO-01 — Anexo A — Atlas Canônico de Poder por Rank` exige classificação de efeito separada da classificação de ser/item, três comparadores quando possível e E3 para insuficiência.
- F0-A5: **0/7 corpos dos anexos históricos Notion rebaixados por bytes e hash**; F0-A6 D0 global parcial; A7 oito reservas antigas sem cegamento certificado; A8 sem humano independente, writer/lease/epoch Notion HOLD. Inbox do escopo contém IBX-141, 128, 126, 124, 119, 103, 102 etc em `NOVA`, sem declarar LIDA/ACK. Não atualizar apenas por leitura.
- No R27 original, G1 C26 apresentava 89 linhas com Page-IDs; nenhuma correção direta no pacote histórico permitida.

## DEPOIS 1 — integridade e linhagem física do censo

**EXECUTADO AGORA**: seis ZIPs históricos C27, C29-A6, C29-A6T, C30, C31 e adendo C31 foram rematerializados a partir de IDs nativos da Biblioteca e auditados por script novo (`c32_verify.py`). Todos os seis: `testzip/CRC PASS`; **56/56 entradas cobertas pelos manifests sem divergência de SHA-256 nem tamanho declarado**. O resultado valida **artefatos da Biblioteca**, não bytes integrais Notion das 799 páginas.

A união independente dos Page-IDs, deduplicada por string e depois pela reconciliação do único Page-ID incorreto, confirmou **411+88+49+131+120=799**, com **zero colisões entre coortes** e **zero duplicatas internas**. `C32_799_PHYSICAL_PAGE_IDS.txt` contém os 799 IDs normalizados para leitura, SEM reescrever ZIP anterior. Importante: uma contagem de páginas não certifica o número de efeitos ou componentes e não equivale a `D0-PAGES` global.

**CORREÇÃO REAL NOVA — ERRO DE C26:** em `baseline/C26_G1_89_SOURCE_REGISTER.csv`, a linha do *Guardião da Tempestade* tinha URL/Page-ID **inválido de 31 hex**: `ac3c2b324ede837fa57a013b59118e3`. Localizado por busca dirigida e reaberto pelo conector Notion Mestre: Page-ID completo **`ac3c2b324ede837fa57a013b59118e3d`**, título físico `Ouro Negro 3`, pai `Golem da Tempestade`, nome interno `Guardião da Tempestade`, última edição da fonte `2026-10-01T18:01:08.314Z`. **VALIDADO um crosswalk de 1 linha** no `C32_ID_REPAIR_AUDIT.json`; C27 e C26 originais PERMANECEM INALTERADOS. O número bruto de linhas não aumentou. Nenhuma classificação Ouro versus Ouro Negro foi adjudicada.

## DEPOIS 2 — revisão fonte→bloco→modo de combate

Três fontes reais **já conhecidas**, mas agora reabertas por conteúdo Notion diretamente, foram examinadas por *estrutura de blocos* além do pool numérico. O resultado corrige interpretação, não cria páginas físicas novas.

1. **Do Ze**: https://app.notion.com/p/1c7c2b324ede83648b6e0104f9bd2146 (última edição 2026-10-09T16:49:07.955Z). UMA página física preserva cinco blocos do personagem: `Do ze (O5)`, `Do ze (O5), Transformação Espiritual`, `Do ze (O2)`, `Do ze (O2), Transformação Espiritual` e `Do ze (B4)`. Os quatro blocos O5/O2 replicam, na Bola de Putrificação, `9d8+INT (9d6+INT)` + `4d12` por tick condicionado + `20 PA`. O bloco B4 contém `3d6+INT`, `2d12` por tick e `3 PA`. **Não contar quatro cópias numéricas como quatro efeitos independentes.** Conflitos literais entre `O5` e cabeçalho interno Ouro 2 (ou Ouro 1 no transformado) permanecem sem decisão; rank do efeito RE/FIP não foi autenticado. Número de turnos, resolução de save e resistência a morte/DoT não demonstrados.
2. **Página indexada Pan Tueimor; corpo Lan Treimor**: https://app.notion.com/p/8f6c2b324ede82c88e5d8184dc3a3b90 (última edição 2026-09-30T04:36:00.043Z). Uma auditoria C31 anterior não vinculava os quatro pools ao estado. A leitura do *invólucro parental* agora comprova pelo menos uma fronteira documental: há o bloco `Lan Treimor (ON1)` e, depois, um bloco `Lan Treimor (ON1), Transformação Espiritual`. **Os pools da segunda seção pertencem ao bloco rotulado transformação**, diferente do normal. Isso NÃO esclarece se a fórmula entre parênteses na MESMA linha corresponde a dado de FF, dano calculado, versão antiga ou modo alternativo. Ataque normal `4d6+65` (bruto 79) e seu parentético `5d10+4d8+3d10+80` (142); Pressão normal `4d6+80` (94) e parentético (193). Ataque no bloco transformado `4d6+105` (119) e parentético `5d10+4d8+132` (177,5); Pressão transformada `4d6+130` (144) e parentético completo (245). A identidade Pan versus Lan permanece HOLD. **Não somar os dois números de uma linha.**
3. **Ravin**: https://app.notion.com/p/14bc2b324ede834daba501e769feda9d (última edição 2026-10-01T09:40:50.721Z): `Atk: 2d6+37 (7d6+20)`, DME bruto condicional 44 versus 44,5. Quase igualdade de média não prova igualdade de distribuição, comportamento pós-RD ou equivalência de modo.

`C32_BODY_SECTION_LINEAGE.json` preserva fonte, seção, posição no texto renderizado, fórmulas, limitações e proveniência. Os números de linha são **localizadores da representação consultada**, não âncoras permanentes da norma.

## DEPOIS 3 — matemática exata, sem substituição do VLAB

**Execução nova:** `c32_math.py` enumerou distribuições exatas por convolução discreta de **15 expressões literais diferentes em 3 páginas físicas**, com **10 hipóteses de RD por expressão = 150 cenários matemáticos condicionais**. Houve **218 verificações locais PASS**, incluindo média por fórmula fechada, variância por identidade independente, extremos, monotonicidade de dano após RD e enumeração direta de faces nos pools combinatoriamente pequenos.

Exemplos: com INT artificialmente **0 apenas para cálculo** e RD sintética **35**: `9d8+INT` gera dano líquido esperado **6,326…** (média bruta 40,5); `9d6+INT`, **0,753…** (bruto 31,5). No bloco Treimor, o ataque normal `4d6+65` tem dano médio bruto 79 e líquido sintético RD35=44; o `4d6+105` explicitamente contido no bloco transformado tem bruto 119 e líquido sintético RD35=84. A alternativa parentética tem outro espectro. **RD35 foi escolhido como cenário de sensibilidade**, não como armadura canônica desses combatentes. Não foi provado que RD deva incidir sobre morte/veneno a cada tick.

Cenários sem chance de acerto, saves, PA por rodada, duração, crítico, imunidades, controle, stacking e forma atualmente ativa **NÃO** estimam dano esperado por tentativa ou TTK de encontro. Resultado matemático não prova erro da v1.1. Os 15 cálculos não significam 15 efeitos canônicos independentes; 3 Page-IDs físicos permanecem 3.

## DEPOIS 4 — F0-A7 holdout: prova independente de exposição, não liberação

Oito reservas históricas de `C30_A7_RESERVA_OITO_EXPOSICAO_MESTRE_ONLY.json` foram cruzadas por código novo com os manifestos físicos C29-A6 e C30 (SEM abrir o conteúdo dos efeitos reservados). **8/8 identificadas; 6/8** aparecem em índice de metadados/título C29 e **2/8** foram lidas como descrição textual de Matrizes C30. A classificação de exposição reproduz a C30 com verificação de pertença independente. Não equivale a oito leituras de mecânica completas. **Blind holdout 0/8 CERTIFICADO; A7 HOLD** até isolamento por família/novo seal e auditor independente; proibição de treinar ou escolher v2 sobre a reserva mantida.

## GATES, FRONTEIRA E RESULTADOS NÃO PROMOVIDOS

| Frente | ANTES | DEPOIS desta campanha C32 | Efeito normativo |
|---|---|---|---|
| F0-A5 | 0/7 bytes de anexos Notion conferidos | 0/7; rota privada bloqueada não repetida | HOLD |
| F0-A6 | 799 Page-IDs na união documental | 799 IDs com 6/6 ZIP CRC, 56/56 manifest e 1 erro de ID corrigido em crosswalk | D0 GLOBAL HOLD |
| F0-A7 | 8 reservas não blindadas | prova cruzada 6 metadados + 2 textos | HOLD |
| F0-A8 | second-coder humano e writer não comprovados | nenhum ACK/claim fingido, 0 independent-human review | HOLD |
| F6 | casos positivos de preenchimento real v1.1 não provados | 3 páginas com dano EXPLÍCITO: NÃO elegíveis para fallback; 15 expressões só diagnóstico | HOLD |
| F7–F12 | pesquisas exploratórias anteriores | dados de distribuição e lineage reutilizáveis em estratos futuros | SEM PROMOÇÃO |
| F13–F18 | candidata, regressão geral, playtest e promoção não aprovados | nenhum efeito | HOLD |
| VLAB | laboratório separado | 0 cenas novas, 0 contratos creditados | SEM ALTERAÇÃO |
| Notion/Party/O Primeiro | NO-WRITE | 0 escrituras | PRESERVADO |

**Conflitos centrais vivos:** Page-ID C26 resolvido no índice auxiliar, mas rank da Besta não; Do Ze O5/body O2/transform O1; Pan/Lan identidade e fórmula principal × parentética; Ravin modo; RONKI/HONGYUE genealogia pré-C32; `/301`, `/220`, Serpentáqua +105, DoT duração; fontes oficiais de RE/FIP não demonstradas; snapshot A5, D0, second-coder, A7, writer não fechados.

## FIRST-PENDING, NEXT-5 E NÃO REPETIR

**Primeira tarefa útil após esta C32:** inspecionar **fontes Mestre específicas de efeito** que identifiquem RE/FIP, ação, entrega, custo e ausências reais de dano (F6), em vez de inferir classificação a partir de usuário/RI/valor monetário. Manter resultado negativo com causa quando não existir fonte admissível. Paralelamente completar recursão A6 dirigida com diferenças de manifestos, sem reler as 233 fichas diretas de Personagens ou censo G1. O primeiro requisito F0 fechável continua A5 quando houver transporte autorizado dos 7 corpos e hash; não ficar repetindo rota de download bloqueada.

**NEXT-5:** (1) fontes F6 dirigidas com três comparadores Atlas e prova de ação/custo, sem falsa admissibilidade; (2) D0 recursivo não repetido e genealogia de variantes dentro da própria página; (3) A5 reabrir apenas com rota privada viável e bytes; (4) preparar lote independente A8 sem fingir segundo humano, e requalificar A7 antes de seleção v2; (5) repassar ao executor VLAB somente fixtures completas e provenientes de fonte canônica, respeitando seu domínio. 

**NO-REPEAT:** C22–C31, 411 G1, 88 C29, 49 C30, 131+120 C31, 233 páginas diretas de Personagens, 116/148 testes históricos, R02–R04, FF C29, casos VLAB e PR #17; não reexecutar nem substituir seus resultados por novos IDs artificialmente.

**PONTO DE RETOMADA EXATO:** `OP-DMG-CORPUS-EMP-01` → Biblioteca `/Comestre/OP-DMG-CORPUS-EMP-01/` → pacote C32 desta execução → fontes JSON/scripts C32 → DMG-RANK-01 v1.1/QA/Atlas → FIRST-PENDING F6 dirigida e A6 recursivo, A5/A7/A8 HOLD. Antes de registrar em Notion OP/Diário, legitimar identidade/writer/epoch/lease e reconciliar a Inbox. Sem permissão não produzir ACK. Revalidar últimos timestamps se houver novos pacotes.

**NAC-PASS PROPORCIONAL:** verificação de artefatos antigos 6/6 CRC e 56/56 manifest PASS; crosswalk do identificador 1/1 fonte Notion confirmada; aritmética 218 checks e 150 cenários PASS; holdout 8/8 cruzado sem abrir mecânica. Verificação independente humana das classificações: NÃO EXECUTADA. Certificação F0, DMG v2, regras, combate, playtest, Party/produção: **HOLD / NÃO CONCEDIDA**.
