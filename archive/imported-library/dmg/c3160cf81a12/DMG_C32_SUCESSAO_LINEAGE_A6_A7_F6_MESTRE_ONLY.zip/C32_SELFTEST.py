from pathlib import Path
import csv,json,hashlib
D=Path(__file__).resolve().parent
x=json.loads((D/'C32_ID_MANIFEST_VERIFICATION.json').read_text())
m=json.loads((D/'C32_EXACT_DAMAGE_VARIANTS_15.json').read_text())
h=json.loads((D/'C32_F0_A7_HOLDOUT_RECONCILIATION.json').read_text())
lineage=json.loads((D/'C32_BODY_SECTION_LINEAGE.json').read_text())
repair=json.loads((D/'C32_ID_REPAIR_AUDIT.json').read_text())
ids=(D/'C32_799_PHYSICAL_PAGE_IDS.txt').read_text().splitlines()
phase=list(csv.DictReader((D/'C32_F0_F18_STATUS_DELTA.csv').open()))
assert x['distinct_physical_pages_union']==len(ids)==799
assert len(set(ids))==799 and all(len(a)==32 for a in ids)
assert repair['corrected_id_from_notion_search_and_fetch_32_hex'] in ids
assert repair['original_id_invalid_31_hex'] not in ids
assert sum(v['manifest_checks'] for v in x['source_archives'].values())==56
assert all(v['CRC_OK'] and not v['manifest_errors'] for v in x['source_archives'].values())
assert len(m['cases'])==15 and m['denominators']['mathematical_scenarios']==150
assert m['mathematical_assertions_passed']==218
assert len(h['records'])==8 and h['C29_A6_metadata_exposed']==6 and h['C30_text_read']==2
assert len(lineage['physical_sources'])==3
assert len(phase)==19 and [x['phase'] for x in phase]==[f'F{i}' for i in range(19)]
assert all(r['gate_promoted']=='NO' for r in phase)
print('C32 SELFTEST PASS: ID799, ZIP6/manifest56, math15/218/150, A7 8/8, F0–F18 19, lineage3')
