"""Independent cross-check of old F0-A7 reserved Page-IDs against C29/C30 manifests; NO ACCESS TO RESERVED EFFECTS."""
import zipfile,json,csv,io,os
from pathlib import Path
O=Path(__file__).resolve().parent; S=Path(os.environ.get('DMG_SOURCE_DIR',str(O/'dmg_source')))
def rows(zip_name,csv_name):
 with zipfile.ZipFile(S/zip_name) as z:return list(csv.DictReader(io.StringIO(z.read(csv_name).decode('utf-8-sig'))))
a6={x['page_id'] for x in rows('DMG_C29_ADENDO_A6_60_FICHAS_MESTRE_ONLY.zip','C29_A6_SUBCORPUS_60_FONTES_MESTRE_ONLY.csv')}
c30={x['page_id'] for x in rows('DMG_C30_PLANO_SUPREMO_CENSO_F6_A7_VLAB_MESTRE_ONLY.zip','C30_D0_FONTE_A_FONTE_49_MESTRE_ONLY.csv')}
with zipfile.ZipFile(S/'DMG_C30_PLANO_SUPREMO_CENSO_F6_A7_VLAB_MESTRE_ONLY.zip') as z:record=json.loads(z.read('C30_A7_RESERVA_OITO_EXPOSICAO_MESTRE_ONLY.json'))
review=[]
for r in record['records']:
 pid=r['reserved_page_id'];kind='C29_A6_METADATA' if pid in a6 else 'C30_BODY_ALREADY_READ' if pid in c30 else 'NOT_IN_THE_TWO_KNOWN_SETS'
 assert kind!='NOT_IN_THE_TWO_KNOWN_SETS',pid
 assert (pid in a6)==r['prior_C29_A6_documentary_index']
 assert (pid in c30)==r['C30_matrix_source_read']
 review.append({'reserved_page_id':pid,'family':r['reserved_family_group'],'known_exposure':kind,'previous_c30_assessment':r['content_exposure_confirmed'],'certified_blind':False})
assert len(review)==8 and len([x for x in review if x['known_exposure']=='C29_A6_METADATA'])==6 and len([x for x in review if x['known_exposure']=='C30_BODY_ALREADY_READ'])==2
out={'status':'PASS of cross-source membership proof only; BLIND HOLDOUT CERTIFICATION=HOLD','verified_8_reserved_members':8,'C29_A6_metadata_exposed':6,'C30_text_read':2,'action':'quarantine old reserve; second independent assessor must decide whether new seal is needed before training; do NOT read reserve as test/training now','records':review}
(O/'C32_F0_A7_HOLDOUT_RECONCILIATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verify':'PASS','reservations':8,'C29_metadata':6,'C30_text':2,'blind_certified':0}))
