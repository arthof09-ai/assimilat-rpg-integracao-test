# DMG C32 — Guia de replay frio / MESTRE-ONLY TEST

O pacote é um adendo à OP-DMG-CORPUS-EMP-01, NÃO nova operação ou sistema. Todos os arquivos C22–C31 permanecem imutáveis.

## A. Fontes necessárias para a integridade estrutural e A7

Recuperar como arquivos ZIP exatamente nomeados, em um diretório privado `dmg_source` adjacente a estes scripts, ou passar o diretório pela variável de ambiente `DMG_SOURCE_DIR`:

1. `DMG_C27_G1_411_CONCLUSAO_EVIDENCIAS_20261021_MESTRE_ONLY.zip`
2. `DMG_C29_ADENDO_A6_60_FICHAS_MESTRE_ONLY.zip`
3. `DMG_C29_ADENDO_A6T_28_TECNICAS_MESTRE_ONLY.zip`
4. `DMG_C30_PLANO_SUPREMO_CENSO_F6_A7_VLAB_MESTRE_ONLY.zip`
5. `DMG_C31_PLANO_SUPREMO_A6_F6_IDENTIDADE_MATH_MESTRE_ONLY.zip`
6. `DMG_C31_ADENDO_PERSONAGENS_120_GATES_MESTRE_ONLY.zip`

Fonte persistente: Biblioteca Mestre `/Comestre/OP-DMG-CORPUS-EMP-01/`. Seus SHA-256 esperados constam no JSON `C32_ID_MANIFEST_VERIFICATION.json` e devem coincidir antes de usar. Não baixar imagens nem anexos Notion de origem por ferramenta pública.

## B. Sequência

Na pasta de trabalho do C32:

```bash
python c32_math.py
DMG_SOURCE_DIR=/caminho/privado/dmg_source python c32_verify.py
DMG_SOURCE_DIR=/caminho/privado/dmg_source python c32_holdout_audit.py
python C32_SELFTEST.py
```

- `c32_math.py` usa apenas biblioteca padrão do Python; gera 15 expressões e 150 hipóteses matemáticas RD, com 218 assertions. 
- `c32_verify.py` faz SHA256 de seis ZIPs/56 entradas manifestadas e cruza 799 Page-IDs, aplicando **somente** crosswalk explícito de um ID C26 verificado por leitura Notion. Reproduz o JSON de integridade e a lista ordenada dos Page-IDs. 
- `c32_holdout_audit.py` confere 8 reservas por Page-ID sem abrir mecânica reservada; não produz certificado de holdout cego.
- `C32_SELFTEST.py` verifica integridade estrutural dos produtos locais publicados, inclusive 19 fases e 799 Page-IDs, sem depender dos ZIPs originais.

## C. Limites de verificação

Os scripts não obtêm lease, writer, CAS/epoch, ACK, fonte RE/FIP, prova da época histórica dos documentos Notion, dados de imagem, independência humana nem aprovação da v2. As médias não incluem fórmula de acerto, custo/ação, save, RD real ou duração. São apenas análises científicas condicionais. Não executar transações nas páginas Mestre/Party nem no VLAB.
