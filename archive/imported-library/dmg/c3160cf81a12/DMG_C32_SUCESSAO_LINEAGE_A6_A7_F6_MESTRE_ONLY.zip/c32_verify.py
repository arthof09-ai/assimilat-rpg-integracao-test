#!/usr/bin/env python3
"""Independent verifier of persisted DMG C27/C29/C30/C31 subsets; TEST/NO-WRITE."""
from __future__ import annotations
import json,csv,hashlib,zipfile,glob,io,os,collections,re
from pathlib import Path
S=Path(os.environ.get('DMG_SOURCE_DIR',str(Path(__file__).resolve().parent/'dmg_source')))
FILES={
 'g1': 'DMG_C27_G1_411_CONCLUSAO_EVIDENCIAS_20261021_MESTRE_ONLY.zip',
 'a6':'DMG_C29_ADENDO_A6_60_FICHAS_MESTRE_ONLY.zip',
 'a6t':'DMG_C29_ADENDO_A6T_28_TECNICAS_MESTRE_ONLY.zip',
 'c30':'DMG_C30_PLANO_SUPREMO_CENSO_F6_A7_VLAB_MESTRE_ONLY.zip',
 'c31':'DMG_C31_PLANO_SUPREMO_A6_F6_IDENTIDADE_MATH_MESTRE_ONLY.zip',
 'c31add':'DMG_C31_ADENDO_PERSONAGENS_120_GATES_MESTRE_ONLY.zip',
}
def csv_rows(z,n):
 return list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))))
def manifest_entries(z):
 for name in z.namelist():
  if 'MANIFEST' in name.upper() and name.lower().endswith('.json'):
   val=json.loads(z.read(name)); fil=val.get('files') or val.get('sha256') or val.get('payload');
   if isinstance(fil,dict):
    for fn,spec in fil.items():
     if isinstance(spec,dict): yield fn, spec
     elif isinstance(spec,str): yield fn, {'sha256':spec}
   elif isinstance(fil,list):
    for spec in fil: yield spec.get('name') or spec.get('file'),spec
   return
 return
reports={}; co={}; internal_errors=[]
for key,fn in FILES.items():
 p=S/fn;blob=p.read_bytes();z=zipfile.ZipFile(p)
 err=z.testzip();cnt=0;manifest_errors=[]
 for entry,spec in manifest_entries(z):
  if entry not in z.namelist(): manifest_errors.append(f'MISSING {entry}');continue
  b=z.read(entry);h=hashlib.sha256(b).hexdigest(); exp=spec.get('sha256');size=spec.get('bytes',spec.get('size_bytes',spec.get('size')))
  if exp and exp!=h: manifest_errors.append(f'HASH {entry}')
  if size is not None and size!=len(b): manifest_errors.append(f'SIZE {entry}')
  cnt+=1
 reports[key]={'zip_name':fn,'zip_sha256':hashlib.sha256(blob).hexdigest(),'CRC_OK':err is None,'member_count':len(z.namelist()),'manifest_checks':cnt,'manifest_errors':manifest_errors}
 if key=='g1':
  a=json.loads(z.read('baseline/prev_ids_c22_c25.json'))
  b=[r['page_id'] for r in csv_rows(z,'baseline/C26_G1_89_SOURCE_REGISTER.csv')]
  c=[r['page_id'] for r in csv_rows(z,'work/publication/C27_G1_66_SOURCE_REGISTER.csv')]
  co['G1_C22_C25']=a;co['G1_C26']=b;co['G1_C27']=c
 elif key=='a6': co['C29_A6']=[r['page_id'] for r in csv_rows(z,'C29_A6_SUBCORPUS_60_FONTES_MESTRE_ONLY.csv')]
 elif key=='a6t':co['C29_A6T']=[r['page_id'] for r in csv_rows(z,'C29_A6T_TECNICAS_28_FONTE_IDS.csv')]
 elif key=='c30': co['C30']=[r['page_id'] for r in csv_rows(z,'C30_D0_FONTE_A_FONTE_49_MESTRE_ONLY.csv')]
 elif key=='c31':
  co['C31_47']=[r['page_id'] for r in csv_rows(z,'C31_D0_47_NOVAS_FONTES_LEDGER.csv')]
  co['C31_32']=[r['page_id'] for r in csv_rows(z,'C31_D0_PERSONAGENS_32_FONTES_LEDGER.csv')]
  co['C31_52']=[r['page_id'] for r in csv_rows(z,'C31_D0_52_PAGINAS_SEM_TITULO.csv')]
 elif key=='c31add': co['C31_ADD120']=[r['source_page_id'] for r in csv_rows(z,'C31_ADENDO_D0_120_PERSONAGENS_FONTE_A_FONTE.csv')]

idre=re.compile(r'^[0-9a-f]{32}$');owners=collections.defaultdict(list)
# ADDITIVE RECONCILIATION: C26 archived CSV dropped last nibble of original Notion Page-ID.
# Verified by Notion search AND successful direct fetch, no overwrite of prior ZIP.
VERIFIED_SOURCE_ID_CROSSWALK={'ac3c2b324ede837fa57a013b59118e3':'ac3c2b324ede837fa57a013b59118e3d'}
raw_owner_count=sum(len(v) for v in co.values())
raw_invalid={k:[x for x in v if not idre.fullmatch(x.lower())] for k,v in co.items()}
raw_invalid={k:v for k,v in raw_invalid.items() if v}
co={k:[VERIFIED_SOURCE_ID_CROSSWALK.get(x,x) for x in ids] for k,ids in co.items()}
for source,ids in co.items():
 for x in ids: owners[x].append(source)
invalid={k:[x for x in v if not idre.fullmatch(x.lower())] for k,v in co.items()}
invalid={k:v for k,v in invalid.items() if v}
within={k:len(ids)-len(set(ids)) for k,ids in co.items()}
between={key:val for key,val in owners.items() if len(set(val))>1}
G1=set(co['G1_C22_C25']+co['G1_C26']+co['G1_C27'])
C29=set(co['C29_A6']+co['C29_A6T'])
C30=set(co['C30'])
C31=set(co['C31_47']+co['C31_32']+co['C31_52'])
C31_ADD=set(co['C31_ADD120'])
canonical={'G1':G1,'C29':C29,'C30':C30,'C31':C31,'C31_ADENDO':C31_ADD}
union=set().union(*canonical.values())
assert all(z['CRC_OK'] and not z['manifest_errors'] for z in reports.values()),reports
assert not invalid and not any(within.values()) and not between,{'invalid':invalid,'within':within,'between':between}
assert {k:len(v) for k,v in canonical.items()}=={'G1':411,'C29':88,'C30':49,'C31':131,'C31_ADENDO':120},{k:len(v) for k,v in canonical.items()}
assert len(union)==799
summary={'status':'PASS: physical dataset ID/hash consistency only; no Notion original-byte attestation','source_archives':reports,'subcohorts':{k:len(v) for k,v in co.items()},'physical_cohorts':{k:len(v) for k,v in canonical.items()},'distinct_physical_pages_union':len(union),'raw_source_id_format_errors':raw_invalid,'verified_id_corrections':VERIFIED_SOURCE_ID_CROSSWALK,'normalized_id_format_errors':invalid,'duplicate_within_cohorts':within,'duplicate_cross_cohorts':len(between),'scope_warning':'799 is a bounded union of Page-IDs only. It is NOT complete D0, 799 independently modeled effects, nor source image coverage.','F0_formal':'4/8 documented (as reported in governing records), global PASS withheld'}
out=Path(__file__).resolve().parent/'C32_ID_MANIFEST_VERIFICATION.json';out.write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
(Path(__file__).resolve().parent/'C32_799_PHYSICAL_PAGE_IDS.txt').write_text('\n'.join(sorted(union))+'\n')
print(json.dumps({'CHECK':'PASS','cohorts':summary['physical_cohorts'],'total':len(union),'archive_manifest_tests':sum(z['manifest_checks'] for z in reports.values()),'hashes':{k:v['zip_sha256'][:12] for k,v in reports.items()}},ensure_ascii=False))
