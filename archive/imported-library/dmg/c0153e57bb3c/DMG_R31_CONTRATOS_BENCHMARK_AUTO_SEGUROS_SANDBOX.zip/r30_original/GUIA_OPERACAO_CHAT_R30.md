# DMG R30 — Operação diretamente pelo ChatGPT (somente Mestre)

**Identidade:** CM-000001 / OP-DMG-CORPUS-EMP-01. Apenas sandbox de ensaio, sem produção.

O Mestre **não precisa de computador, Python, JSON ou terminal**. Pode usar mensagens como:

- **“Quais ações o Macaco Rei pode executar neste turno?”** — Comestre reabre o snapshot experimental adequado, executa `compilador_r30.py --state ... --actor-id macaco --menu` e resume PERMITIDA/PROIBIDA/PENDENTE com recibo.
- **“Quero usar Patada”** — Comestre reconsulta o menu na revisão corrente, exige alvo e janela quando não demonstrados, NÃO presume acerto, calcula somente componente bruto com contrato R29 se habilitado e solicitado; não debita PA automaticamente.
- **“O Macaco tem só 5 PA”** — Comestre registra uma nova revisão **manualmente declarada de fixture** e recompila; Poder Elemental resulta PROIBIDA por 10 PA. Em cena real, não alterar sem writer/gate.
- **“A Ação Padrão foi gasta no meu ensaio”** — Comestre revisa somente o snapshot experimental e recompila; a Patada então aparece PROIBIDA. Não é um evento histórico nem um recibo de consumo real.
- **“Liu está transformada neste cenário hipotético”** — Comestre seleciona a **variante alternativa do snapshot**; não ativa T9 nem altera a ficha original. As opções de Liu transformada não reutilizam os atributos da normal.
- **“Preparar Patada para o VLAB”** — Comestre gera envelope de interoperabilidade **NOT_SENT**, exige ACK e fonte nativa congelada antes de qualquer entrega real ao receptor.

## Estados de elegibilidade

`PERMITIDA`: todos os requisitos **implementados do subconjunto de declaração em fixture** estão provados neste estado fictício. **Não** certifica custo total, acerto, execução, HP, efeitos ou B05 integral.

`PROIBIDA`: ao menos um impedimento concreto de orçamento, janela, recurso, equipamento ou alcance documentado.

`PENDENTE`: não existe impedimento suficiente para proibir, mas faltam informações essenciais.

Os recibos incluem `scene_id`, `state_revision`, `state_sha256`, fonte URL e última edição (não confundir com época histórica), motivos, custo PA comprovado ou não, resultado e SHA-256. `source_digest=null` de propósito: não foi recuperado um hash nativo da fonte e isso bloqueia aceitação produtiva pelo VLAB.

## CLI operacional para o próprio Comestre (não para o Mestre)

```bash
python compilador_r30.py --state fixtures/01_macaco_turno.json --actor-id macaco --menu
python compilador_r30.py --state fixtures/01_macaco_turno.json --actor-id macaco --calculate MACACO_P5::PATADA --rolls '[3,5]'
python compilador_r30.py --state fixtures/01_macaco_turno.json --actor-id macaco --intent MACACO_P5::PATADA
python compilador_r30.py --state fixtures/01_macaco_turno.json --patch-json '{"request_id":"MANUAL-02","expected_state_revision":0,"actor_id":"macaco","changes":{"budget.standard_consumed":true}}'
```

Para exercícios adicionais, **copie o fixture antes de aplicar patch**; os arquivos originais, históricos e canônicos não são modificados. O patch guarda `request_id`, precondition revision, hashes ANTES/DEPOIS e diário de alterações locais; não constitui commit único garantido em Notion ou VLAB. O consumidor VLAB, quando legítimo, é quem executará scheduler, dano, recursos e replay, e só após gates competentes.

R28 e R29 são importados exatamente do pacote R29 preservado. R30 não cria segundo resolvedor nem motor de turnos.
