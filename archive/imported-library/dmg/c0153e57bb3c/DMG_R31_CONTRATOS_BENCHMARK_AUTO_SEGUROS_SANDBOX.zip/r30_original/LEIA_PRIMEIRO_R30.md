# OP-DMG-CORPUS-EMP-01 / R30 — Compilador de elegibilidade

**Mestre usa ChatGPT pelo celular.** O Comestre opera os scripts; os exemplos de terminal são apenas instrumentos de manutenção/replay, não exigência ao Mestre.

Comece com `RELATORIO_CIENTIFICO_R30.md`, `GUIA_OPERACAO_CHAT_R30.md` e `documentos/PSV_R30.md`.

- `compilador_r30.py` recebe snapshot de estado; retorna menu PERMITIDA/PROIBIDA/PENDENTE, justificativa e recibo.
- `politicas_b05_b06_r30.json` **não** recria fonte: crosswalk 43 entradas R29 e 19 usos de ações universais do Sistema de Combate. Resultados são *subset-scoped*, B05 e B06 permanecem PARTIAL.
- `fixtures/01_macaco_turno.json`, `02_liu_normal.json`, `03_liu_transformada_alternativa.json` são ensaios fictícios; `04_snapshot_apos_patch_manual.json` traz revisão 1 após alteração local explícita, com journal idempotente.
- `recibos/*.json`: 20 recibos A–J + menu baseline.
- `documentos/MATRIZ_TERMINAL_B05_R30.json` e `FRONTEIRA_B06_R30.json`: condições terminais para aceite futuro.
- `historico/R29_ORIGINAL_INTACTO.zip` é cópia byte a byte do R29. `r29_original` extrai o próprio R29 e importa os históricos R28/R27 embutidos. O código original NÃO foi modificado.
- `GERAR...` arquivos .py reproduzem crosswalk, fixtures, recibos e matrizes locais; `testes_r30.py` contém 43 testes novos.

## Resultado reproduzível imediato

Macaco em seu próprio turno, Padrão livre, target melee comprovado **somente no fixture**: Patada PERMITIDA, Mordida PERMITIDA. Poder Elemental PENDENTE porque tipo de ação/elemento/alvo são indefinidos apesar do custo10; com PA5 fica PROIBIDA; com PA null continua PENDENTE. Defender fora da janela é PROIBIDA. Uma atualização manual do snapshot para Ação Padrão consumida reclassifica Patada PROIBIDA, sem aplicar dano/PA/HP.

**Limites:** `source_digest=null` no envelope de interoperabilidade por falta de byte source nativo autenticado. `transport=NOT_SENT`. Nenhum ACK/consulta executória VLAB, sem novo Inbox. STRICT 0/2; B01–B18 1/18; NAC-PASS produtivo HOLD. R26 binário não conferido nesta execução.
