import json
from pathlib import Path
R=Path(__file__).parent
b05={
 'schema':'OPDMG-R30-B05-TERMINAL-EVIDENCE-v1',
 'original_requirement':'Complete legal action loadouts and owned abilities for all actors not adjudicated',
 'original_gate':'ACTION_INVENTORY',
 'original_test':'Compiler emits allowed/rejected action with explicit per-field provenance and atomic effect plan',
 'original_terminal_gap':'Complete official legal action inventory under chosen scene form, ranges, costs, items/buffs, proof adapters and exclusions, reader acceptance',
 'original_sources':['DMG-F1-R11-MATRIZ-B01-B18-v01.json (R29 inherited research corpus)',
     'R26_B01_B18_MATRIX.csv (historical R26 mirrored)',
     'https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010',
     'https://app.notion.com/p/301c2b324ede828caccb813d3979267a',
     'https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0'],
 'historical_R29_items':43,'source_items_carried_through':43,
 'universal_applicabilities_added':19,'current_directed_crosswalk_items':62,
 'global_B05_whole_gate_denominator':'NÃO DETERMINÁVEL com corpus/snapshots disponíveis',
 'full_gate_pass':False,'official_status':'PARTIAL','nac_pass':'HOLD',
 'requirements':[
  {'id':'B05-01','name':'Universe of legal actor actions, form and scene','coverage':'PARTIAL','done':'43/43 inherited R29 candidates mapped + 19 universal applicability rows; active actor+form fixture','missing':'Full authoritative encounter actor/loadout set and date/epoch source freeze; no global denominator'},
  {'id':'B05-02','name':'Provenance by field','coverage':'PARTIAL','done':'source URL+edit date per catalog row; universal action from combat system R1/R3/R4/R8/R9','missing':'Native source content digest and authoritative frozen scene binding for VLAB consumer'},
  {'id':'B05-03','name':'Actors, forms, attributes, rank','coverage':'PARTIAL','done':'Macaco Prata5 title Titã and FOR54 printed; Liu normal FOR29 and transformed FOR40 separate','missing':'Real selected form/Spirit-ID/T9 action and actor snapshot epoch; B02 certificate not widened'},
  {'id':'B05-04','name':'Activation conditions and passives','coverage':'PARTIAL','done':'Tri-valued status incl equipment, half HP, passive force not double applied','missing':'Live activation/event receipts; duration and stacking/legacy D&D action bonus'},
  {'id':'B05-05','name':'Action economy','coverage':'PARTIAL','done':'Standard attack and reaction before enemy attack windows implemented','missing':'Special powers class/timing, named ability actions, full action exceptions, simultaneous ordering'},
  {'id':'B05-06','name':'Resources/charges/cooldowns','coverage':'PARTIAL','done':'Known explicit 10/12/30/40/45 PA costs and zero-versus-null protection; PA>=required','missing':'Actual PA Livre, item commitments/daily charges/cooldowns; unpriced attack PA not assumed zero'},
  {'id':'B05-07','name':'Rolls/bonuses/proficiencies','coverage':'PARTIAL','done':'R29 raw-component calculator bound only after subset eligibility; FOR54 no +2','missing':'Attack roll and full skill/proficiency/effect stack, live RNG and critical proofs'},
  {'id':'B05-08','name':'Damage typing and components','coverage':'PARTIAL','done':'Macaco impact/piercing, untyped elemental; Liu electric isolated','missing':'Electricity vs raio tag authority, target immunity/RD, full composed source reconciled'},
  {'id':'B05-09','name':'Later effects/time','coverage':'PARTIAL','done':'R29 Estocada Cruel tick inherits; R30 reaction window excludes wrong phase','missing':'Full condition onset/expiration and event order, selected scene status ledger'},
  {'id':'B05-10','name':'Range/target/position limitations','coverage':'PARTIAL','done':'melee_reach_confirmed fixture only; unknown yields PENDENTE; 6m throw normal-range guard','missing':'Signed coordinates and line of sight, real scene map, reach and cover, exact target restrictions'},
  {'id':'B05-11','name':'Tests/consumer/atomic event plan','coverage':'PARTIAL','done':'43 R30 unit tests, 26 R28 +50 R29 regression, 20 demo receipts; explicit no dispatch effect plan','missing':'VLAB legitimate source-frozen ingest/readback with acceptance, event+replay, independent NAC-PASS'}
 ],
 'deltas_for_original_pair':[
  {'actor':'MACACO','forms':['MACACO_P5'],'action_state':'Patada/Mordida candidate PERMITIDA within fictional subset when standard and melee target proven; costs unspecified, no official dispatch'},
  {'actor':'LIU','forms':['LIU_NORMAL','LIU_TRANSFORMADA'],'action_state':'normal item activation/PA holds; transformed alternative never treated as successful historical T9'}
 ]
}
b06={
 'schema':'OPDMG-R30-B06-BOUNDARY-v1','original_gate':'ACTION_COST_AND_REACTION_WINDOWS',
 'original_requirement':'time/action/cost/reaction triggers; official event order and single-use reaction receipt',
 'official_status':'PARTIAL','full_gate_pass':False,
 'documentary_rules':{
  'STANDARD':'Sistema de Combate R1+R3: ataque normal consome uma Padrão',
  'MOVEMENT':'Sistema de Combate R1',
  'REACTION':'Sistema de Combate R1 e R4: declaração antes de ataque do adversário',
  'FULL':'Sistema de Combate R1 e R9: foco total normalmente Padrão+Movimento+Reação, T9 Prata 40 PA',
  'FREE':'Sistema de Combate R1; apenas quando ação específica documentada',
  'BONUS':'Ação bônus de D&D não existe na taxonomia oficial; sem mapeamento'},
 'tested_subsets':[
  'Declaração de defesa fora da janela -> PROIBIDA',
  'Janela BEFORE_ENEMY_ATTACK com evento declarado e reação não consumida -> PERMITIDA no subset',
  'Reação consumida -> PROIBIDA',
  'Padrão consumida -> Patada PROIBIDA',
  'Padrão desconhecida -> Patada PENDENTE',
  'Poder Elemental PA5<10 -> PROIBIDA; PA null -> PENDENTE',
  'Liu T9 em forma normal: PENDENTE Spirit-ID apesar de custo40 e Ação Completa documentados'],
 'not_tested_event_claims':['single committed reaction in actual scheduler','interrupt simultaneous events','real PA debit',
                           'replay of living actor event','VLAB native scheduler integration'],
 'next_acceptance':'Recover signed scene epoch and action budget, authoritative ability class, valid timeline and real VLAB consumer ACK/readback for B06 gate',
 'nac_pass':'HOLD'}
for n,o in [('MATRIZ_TERMINAL_B05_R30.json',b05),('FRONTEIRA_B06_R30.json',b06)]:
    (R/'documentos'/n).write_text(json.dumps(o,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print('B05 requirements',len(b05['requirements']))
