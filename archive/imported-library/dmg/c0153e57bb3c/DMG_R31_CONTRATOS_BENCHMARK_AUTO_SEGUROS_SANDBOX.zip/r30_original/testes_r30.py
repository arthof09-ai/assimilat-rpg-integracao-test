import copy,json,tempfile,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import compilador_r30 as r
ROOT=Path(__file__).parent
s0=json.loads((ROOT/'fixtures/01_macaco_turno.json').read_text())
s1=json.loads((ROOT/'fixtures/02_liu_normal.json').read_text())
s2=json.loads((ROOT/'fixtures/03_liu_transformada_alternativa.json').read_text())

def decision(state,actor,short):
    m=r.compile_scene(state,actor)
    k=state['actors'][actor]['form_id']+'::'+short
    return next(x for x in m['decisions'] if x['action_id']==k)

class TestR30(unittest.TestCase):
    def test_A_patada_elegivel_sem_gasto(self):
        j=decision(s0,'macaco','PATADA');self.assertEqual(j['eligibility'],r.ALLOW)
        self.assertIsNone(j['resource_requirements']['actual_pa_debit']);self.assertIsNone(j['resource_requirements']['cost_pa_explicit'])
        self.assertEqual(j['effect_plan']['atomic_effect'],'DOCUMENTAL_COMPONENT_ONLY')
    def test_A_mordida_elegivel(self):self.assertEqual(decision(s0,'macaco','MORDIDA')['eligibility'],r.ALLOW)
    def test_A_melee_desconhecido_pendente(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['target']['melee_reach_confirmed']=None
        self.assertEqual(decision(x,'macaco','PATADA')['eligibility'],r.PENDING)
    def test_A_sem_alvo_pendente(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['target']['target_id']=None
        self.assertEqual(decision(x,'macaco','MORDIDA')['eligibility'],r.PENDING)
    def test_A_alvo_fora_proibido(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['target']['melee_reach_confirmed']=False
        self.assertEqual(decision(x,'macaco','PATADA')['eligibility'],r.DENY)
    def test_B_pa5_bloqueia_poder(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['pa_available']=5
        j=decision(x,'macaco','PODER_ELEMENTAL');self.assertEqual(j['eligibility'],r.DENY)
        self.assertTrue(any('PA_INSUFFICIENT' in k for k in j['prohibited_reasons']))
    def test_B_pa0_bloqueia(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['pa_available']=0
        self.assertEqual(decision(x,'macaco','PODER_ELEMENTAL')['eligibility'],r.DENY)
    def test_C_pa_indefinido_pendente(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['pa_available']=None
        j=decision(x,'macaco','PODER_ELEMENTAL');self.assertEqual(j['eligibility'],r.PENDING)
        self.assertIn('PA_AVAILABLE_NOT_PROVED',j['unresolved_requirements'])
    def test_C_poder_pa20_ainda_pendente_economia_e_elemento(self):
        j=decision(s0,'macaco','PODER_ELEMENTAL');self.assertEqual(j['eligibility'],r.PENDING)
        self.assertIn('ELEMENT_TYPE_UNSPECIFIED',j['unresolved_requirements'])
        self.assertIsNone(j['resource_requirements']['actual_pa_debit'])
    def test_D_formas_com_menus_diferentes(self):
        a=r.compile_scene(s1,'liu');b=r.compile_scene(s2,'liu');x={k['action_id'] for k in a['decisions']};y={k['action_id'] for k in b['decisions']}
        self.assertIn('LIU_NORMAL::MACHADO_BASE',x);self.assertNotIn('LIU_NORMAL::MACHADO_BASE',y)
        self.assertIn('LIU_TRANSFORMADA::RETALIACAO',y);self.assertNotIn('LIU_TRANSFORMADA::RETALIACAO',x)
        self.assertEqual(s1['actors']['liu']['attributes']['FOR'],29)
        self.assertEqual(s2['actors']['liu']['attributes']['FOR'],40)
    def test_D_transformed_active_false_denied(self):
        a=copy.deepcopy(s2);a['actors']['liu']['conditions']['form_active']=False
        self.assertEqual(decision(a,'liu','ATAQUE_TRANSFORMADO')['eligibility'],r.DENY)
    def test_D_normal_if_active_false_not_transform(self):
        a=copy.deepcopy(s1);a['actors']['liu']['conditions']['form_active']=True
        self.assertEqual(decision(a,'liu','MACHADO_BASE')['eligibility'],r.DENY)
    def test_E_passiva_nao_soma_automaticamente(self):
        x=decision(s0,'macaco','FORCA_TITANICA');self.assertEqual(x['eligibility'],r.PENDING)
        receipt=r.calculate_isolated(s0,'macaco','MACACO_P5::PATADA',[3,5])
        self.assertEqual(receipt['r29_receipt']['result']['raw_damage'],62)
        self.assertEqual(receipt['r29_receipt']['authorized_parts'][0]['value'],54)
    def test_E_force_override56_bloqueado(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['conditions']['force_override']=56
        self.assertEqual(decision(x,'macaco','PATADA')['eligibility'],r.DENY)
    def test_F_arma_nao_equipada_proibido(self):
        x=copy.deepcopy(s1);x['actors']['liu']['equipment']['axe_equipped']=False
        self.assertEqual(decision(x,'liu','MACHADO_BASE')['eligibility'],r.DENY)
    def test_F_arma_desconhecida_pendente(self):
        x=copy.deepcopy(s1);x['actors']['liu']['equipment']['axe_equipped']=None
        self.assertEqual(decision(x,'liu','MACHADO_BASE')['eligibility'],r.PENDING)
    def test_F_arma_status_ok_fixture_permitida_parcela_base(self):
        j=decision(s1,'liu','MACHADO_BASE');self.assertEqual(j['eligibility'],r.PENDING)
        self.assertIn('ITEM_PA_ACCOUNTING_OR_DAILY_COMMITMENT_UNRESOLVED',j['unresolved_requirements'])
    def test_F_modificador_nao_independente(self):
        self.assertEqual(decision(s1,'liu','MACHADO_CRUEL_CERTEIRA')['eligibility'],r.PENDING)
    def test_F_nao_somar_damage_impresso(self):
        x=r.calculate_isolated(s1,'liu','LIU_NORMAL::MACHADO_BASE',[1,3,5,7,9]);self.assertEqual(x['status'],'HOLD_ACTION_NOT_ELIGIBLE')
    def test_G_reacao_fora_janela_proibida(self):
        j=decision(s0,'macaco','UNIVERSAL_REACAO_DEFENDER');self.assertEqual(j['eligibility'],r.DENY)
        self.assertIn('REACTION_OUTSIDE_BEFORE_ENEMY_ATTACK_WINDOW',j['prohibited_reasons'])
    def test_G_reacao_validada_momento_ficticio(self):
        x=copy.deepcopy(s0);x['scene']['phase']='BEFORE_ENEMY_ATTACK';x['scene']['incoming_attack']=True
        self.assertEqual(decision(x,'macaco','UNIVERSAL_REACAO_DEFENDER')['eligibility'],r.ALLOW)
    def test_G_reacao_ja_consumida_proibida(self):
        x=copy.deepcopy(s0);x['scene']['phase']='BEFORE_ENEMY_ATTACK';x['scene']['incoming_attack']=True
        x['actors']['macaco']['budget']['reaction_consumed']=True
        self.assertEqual(decision(x,'macaco','UNIVERSAL_REACAO_DEFENDER')['eligibility'],r.DENY)
    def test_G_padrão_consumida_impede_patada(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['budget']['standard_consumed']=True
        self.assertEqual(decision(x,'macaco','PATADA')['eligibility'],r.DENY)
    def test_G_std_null_hold(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['budget']['standard_consumed']=None
        self.assertEqual(decision(x,'macaco','PATADA')['eligibility'],r.PENDING)
    def test_G_acao_completa_bloqueia_attack(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['budget']['full_consumed']=True
        self.assertEqual(decision(x,'macaco','PATADA')['eligibility'],r.DENY)
    def test_H_patch_revisao_e_idempotencia(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'snapshot.json';p.write_text(json.dumps(s0,ensure_ascii=False))
            m=r.compile_scene(json.loads(p.read_text()),'macaco')
            patch={'request_id':'CMR30-H-01','actor_id':'macaco','expected_state_revision':0,
                   'changes':{'budget.standard_consumed':True}}
            a=r.apply_manual_patch(p,patch);self.assertEqual(a['receipt']['new_revision'],1)
            after=json.loads(p.read_text());self.assertEqual(after['state_revision'],1)
            self.assertEqual(decision(after,'macaco','PATADA')['eligibility'],r.DENY)
            replay=r.apply_manual_patch(p,patch);self.assertEqual(replay['status'],'IDEMPOTENT_REPLAY')
            self.assertEqual(len(json.loads(Path(str(p)+'.manual_journal.json').read_text())),1)
            self.assertNotEqual(r.compile_scene(after,'macaco')['state_sha256'],m['state_sha256'])
    def test_H_revision_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s.json';p.write_text(json.dumps(s0))
            with self.assertRaisesRegex(ValueError,'REVISION_CONFLICT'):
                r.apply_manual_patch(p,{'request_id':'r1','actor_id':'macaco','expected_state_revision':9,'changes':{'budget.standard_consumed':True}})
    def test_H_improper_patch_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s.json';p.write_text(json.dumps(s0))
            with self.assertRaisesRegex(ValueError,'UNSUPPORTED_PATCH_FIELDS'):
                r.apply_manual_patch(p,{'request_id':'bad','actor_id':'macaco','expected_state_revision':0,
                    'changes':{'attributes.FOR':56}})
    def test_H_request_collision(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s.json';p.write_text(json.dumps(s0))
            r.apply_manual_patch(p,{'request_id':'stable','actor_id':'macaco','expected_state_revision':0,
                    'changes':{'budget.standard_consumed':True}})
            with self.assertRaisesRegex(ValueError,'REQUEST_ID_COLLISION'):
                r.apply_manual_patch(p,{'request_id':'stable','actor_id':'macaco','expected_state_revision':1,
                    'changes':{'budget.standard_consumed':False}})
    def test_I_intencao_nao_enviada(self):
        i=r.create_vlab_intent(s0,'macaco','MACACO_P5::PATADA')
        self.assertEqual(i['eligibility'],r.ALLOW);self.assertEqual(i['transport'],'NOT_SENT')
        self.assertIsNone(i['source_digest']);self.assertIsNone(i['VLAB_result']);self.assertEqual(i['NAC_PASS'],'HOLD')
        for fld in ['scene_id','actor_id','source_id','source_digest','form_id','state_revision','action_id','action_type',
                    'eligibility','resource_requirements','target_requirements','temporal_window','effect_plan','unresolved_requirements','receipt_id']:
            self.assertIn(fld,i)
    def test_I_intencao_pendente_nao_implanta(self):
        i=r.create_vlab_intent(s0,'macaco','MACACO_P5::PODER_ELEMENTAL')
        self.assertEqual(i['eligibility'],r.PENDING);self.assertEqual(i['transport'],'NOT_SENT')
    def test_J_regressao_formula_R29_vinculada(self):
        out=r.calculate_isolated(s0,'macaco','MACACO_P5::MORDIDA',[4]);self.assertEqual(out['r29_receipt']['result']['raw_damage'],58)
        self.assertEqual(out['r29_receipt']['status'],r.v29.STATUS_ALLOW)
    def test_J_dados_invalidos_R29_rejeita(self):
        x=r.calculate_isolated(s0,'macaco','MACACO_P5::PATADA',[7,3]);self.assertEqual(x['r29_receipt']['status'],r.v29.STATUS_REJECT)
    def test_J_sem_dado_gera_hold(self):
        x=r.calculate_isolated(s0,'macaco','MACACO_P5::PATADA',None);self.assertEqual(x['r29_receipt']['status'],r.v29.STATUS_HOLD)
    def test_state_identity_source_rank_guard(self):
        for tweak in [('attributes','FOR',56),('rank_documental',None,'Ouro 5'),('source_id',None,'LIU')]:
            x=copy.deepcopy(s0);a=x['actors']['macaco']
            if tweak[1] is None:a[tweak[0]]=tweak[2]
            else:a[tweak[0]][tweak[1]]=tweak[2]
            with self.assertRaises(ValueError):r.compile_scene(x,'macaco')
    def test_source_digest_not_claimed(self):
        m=r.compile_scene(s0,'macaco');self.assertIsNone(m['source_digest'])
        self.assertTrue(all(x['source_digest'] is None for x in m['decisions']))
    def test_reproducible_hash_and_no_effect(self):
        a=r.compile_scene(s0,'macaco');b=r.compile_scene(s0,'macaco')
        self.assertEqual(a['content_sha256'],b['content_sha256']);self.assertFalse(a['authorization']['Notion_writes'])
    def test_target_missing_distinguish_none(self):
        x=copy.deepcopy(s0);x['actors']['macaco']['target']['melee_reach_confirmed']=None
        y=r.create_vlab_intent(x,'macaco','MACACO_P5::PATADA')
        self.assertEqual(y['eligibility'],r.PENDING)
    def test_no_modifiers_from_other_forms(self):
        with self.assertRaisesRegex(ValueError,'ACTION_NOT_OF_SELECTED_FORM'):
            r.create_vlab_intent(s2,'liu','LIU_NORMAL::MACHADO_BASE')
    def test_normal_liu_unknown_PA_gates_fury(self):
        x=copy.deepcopy(s1);x['actors']['liu']['pa_available']=None;x['actors']['liu']['conditions']['hp_half_or_less']=True
        j=decision(x,'liu','FURIA');self.assertEqual(j['eligibility'],r.PENDING)
        self.assertIn('PA_AVAILABLE_NOT_PROVED',j['unresolved_requirements'])
    def test_normal_liu_full_t9_missing_spirit_pending(self):
        j=decision(s1,'liu','UNIVERSAL_TRANSFORMAR_PRATA')
        self.assertEqual(j['eligibility'],r.PENDING)
        self.assertIn('SPIRIT_ID_AND_T9_SOURCE_VALID',j['unresolved_requirements'])
    def test_poder_sem_emoji_gelo(self):
        a=decision(s0,'macaco','PODER_ELEMENTAL');self.assertIn('ELEMENT_TYPE_UNSPECIFIED',a['unresolved_requirements'])
    def test_43_original_19_universal(self):
        self.assertEqual(r.POLICY['history_original_count'],43)
        self.assertEqual(r.POLICY['universal_applicabilities'],19)
        self.assertEqual(len(r.ACTIONS),62)

if __name__=='__main__':unittest.main(verbosity=2)
