"""Ponte de campos da matriz R29 para requisitos executáveis de B05/B06.
Não escreve nas fontes: cada política é uma interpretação delimitada auditável.
"""
import csv,json
from pathlib import Path
ROOT=Path(__file__).parent
prev=ROOT/'r29_original'
rows=list(csv.DictReader((prev/'INVENTARIO_B05_R29.csv').open(encoding='utf8')))
assert len(rows)==43
reg=json.loads((prev/'registry_r29.json').read_text(encoding='utf8'))
base={}
for r in rows:
    k=r['profile']+'::'+r['action_key']
    source=reg['sources'][r['source']]
    base[k]={
        'id':k,'profile':r['profile'],'name':r['action_key'],
        'role':r['kind'],'source_id':r['source'],'source_url':source['url'],
        'source_edited_at':source['last_edited'],
        'linked_calculator':r['dice_only_case'] or None,
        'documented_window':r['window'], 'documented_cost':r['cost_documented'],
        'legacy_unknowns':r['fields_missing_for_full_action'].split(';'),
        'budget':'UNRESOLVED','timing':'UNRESOLVED','target':'UNKNOWN','cost_pa':None,
        'cost_kind':'UNSPECIFIED','source_evidence':'R29 inventory + reabertura Notion R30',
        'checks':[],'supported_scope':'DOCUMENTAL_ELIGIBILITY_ONLY',
        'effect_kind':'NO_EXECUTION',
        'possible_damage_component':r['dice_only_case'] or None,
    }

def set_(p,a,**kw):
    d=base[p+'::'+a]
    for k,v in kw.items():d[k]=v
# Macaco: regrinha geral, 1 padrão por ataque físico; alcance não inferido; um campo de fixture comprova a condição.
for key in ('PATADA','MORDIDA'):
    set_('MACACO_P5',key,budget='STANDARD',timing='OWN_TURN',target='MELEE_CONFIRMED',
         checks=['MACACO_FORCE_LITERAL_ONLY'],effect_kind='IMPACT_IF_HIT_UNCALCULATED',
         cost_kind='UNSPECIFIED_IN_SOURCE_NO_PA_DEBIT',
         source_evidence='Macaco ação física; Sistema Combate Regra 3: atacar custa 1 Ação Padrão')
set_('MACACO_P5','PODER_ELEMENTAL',budget='UNRESOLVED',timing='UNRESOLVED',target='TARGET_UNRESOLVED',
     cost_pa=10,cost_kind='EXPLICIT_PER_USE',checks=['ELEMENT_NOT_INFERRED'],effect_kind='ELEMENTAL_UNTYPED')
set_('MACACO_P5','MANIPULACAO_MAGICA',budget='UNRESOLVED',timing='UNRESOLVED',target='TARGET_UNRESOLVED',effect_kind='UNDEFINED_MAGIC')
set_('MACACO_P5','TELEPATIA',budget='UNRESOLVED',timing='UNRESOLVED',target='TARGET_UNRESOLVED',effect_kind='NON_DAMAGING_COMMUNICATION')
set_('MACACO_P5','FORCA_TITANICA',budget='PASSIVE',timing='PASSIVE',target='NONE',
     checks=['PASSIVE_FF_STACKING_UNRESOLVED'],effect_kind='PASSIVE_PLUS2_FOR_NOT_APPLIED')
# Liu normal: distinguir ação do modificador/passiva; condicionantes não conferidos permanecem UNKNOWN.
set_('LIU_NORMAL','MACHADO_BASE',budget='STANDARD',timing='OWN_TURN',target='MELEE_CONFIRMED',
     checks=['LIU_AXE_EQUIPPED','LIU_AXE_ACTIVE','LIU_ITEM_PA_LEDGER_UNVERIFIED'],effect_kind='WEAPON_INTRINSIC_ONLY',
     cost_kind='DAILY_EQUIPMENT_COMMITMENT_UNRESOLVED')
set_('LIU_NORMAL','ATAQUE_BASICO',budget='STANDARD',timing='OWN_TURN',target='MELEE_CONFIRMED',
     checks=['LIU_SHORTCUT_UNRECONCILED'],effect_kind='UNRECONCILED_COMPOSITE')
for k in ('MACHADO_CRUEL_CERTEIRA','MACHADO_INFUSAO','MACHADO_DECEPADORA'):
    set_('LIU_NORMAL',k,budget='MODIFIER',timing='ON_VALID_WEAPON_HIT',target='MELEE_CONFIRMED',
         checks=['LIU_AXE_EQUIPPED','LIU_AXE_ACTIVE','NO_DOUBLE_COUNT_PROOF'],effect_kind='MODIFIER_NEVER_STANDALONE')
set_('LIU_NORMAL','MACHADO_ARREMESSAVEL',budget='STANDARD',timing='OWN_TURN',target='THROW_6M',
     checks=['LIU_AXE_EQUIPPED','LIU_AXE_ACTIVE'],cost_kind='DAILY_EQUIPMENT_COMMITMENT_UNRESOLVED',
     effect_kind='THROW_DOCUMENTED_LIMITED')
set_('LIU_NORMAL','EXTENSAO_CORPORAL',budget='UNRESOLVED',timing='UNRESOLVED',target='UNKNOWN',
     cost_pa=30,cost_kind='EXPLICIT_PER_USE',effect_kind='OPTIONAL_3D6_OR_6CA')
set_('LIU_NORMAL','FURIA',budget='UNRESOLVED',timing='OWN_TURN',target='NONE',
     cost_pa=12,cost_kind='EXPLICIT_PER_USE',checks=['HALF_HP_CONFIRMED'],effect_kind='CONDITIONAL_BUFF')
set_('LIU_NORMAL','BOTAS_VELOCIDADE',budget='BONUS_UNMAPPED',timing='UNRESOLVED',target='NONE',
     checks=['BONUS_ACTION_NOT_SYSTEM'],cost_kind='DAILY_COMMITMENT_UNRESOLVED')
set_('LIU_NORMAL','ANEL_ATRIBUTO',budget='UNRESOLVED',timing='UNRESOLVED',target='NONE',
     cost_kind='ITEM_COST_SEMANTICS_UNRESOLVED')
set_('LIU_NORMAL','ANEL_ALMA',budget='PASSIVE',timing='PASSIVE',target='NONE',checks=['EQUIPMENT_PA_LEDGER_UNVERIFIED'])
set_('LIU_NORMAL','ARMADURA_PESADA',budget='PASSIVE',timing='PASSIVE',target='NONE',checks=['EQUIPMENT_PA_LEDGER_UNVERIFIED'])
set_('LIU_NORMAL','INSTINTO_SELVAGEM',budget='PASSIVE',timing='PASSIVE',target='NONE',effect_kind='INITIATIVE_PERCEPTION_PLUS4')
set_('LIU_NORMAL','VONTADE_INABALAVEL',budget='PASSIVE',timing='PASSIVE',target='NONE',checks=['FURY_ACTIVE_CONFIRMED'],effect_kind='WILL_PLUS6')
set_('LIU_NORMAL','DESTRUIDOR',budget='MODIFIER',timing='ON_VALID_WEAPON_DAMAGE',target='NONE',checks=['TWO_HANDED_CONFIRMED'])
set_('LIU_NORMAL','CRITICO_BRUTAL',budget='MODIFIER',timing='ON_CRITICAL',target='NONE',checks=['DEC_B11_PENDING','HEAVY_WEAPON_CONFIRMED'])
# Forma transformada não herda o menu normal sem prova; custos de PA especializados tratados como literal.
set_('LIU_TRANSFORMADA','ATAQUE_TRANSFORMADO',budget='STANDARD',timing='OWN_TURN',target='MELEE_CONFIRMED',
     checks=['TRANSFORMED_FORM_ACTIVE','LIU_SHORTCUT_UNRECONCILED'],effect_kind='TRANSFORMED_ATTACK_SHORTCUT_UNRECONCILED')
set_('LIU_TRANSFORMADA','TRANSFORMAR',budget='FULL',timing='OWN_TURN',target='NONE',
     cost_pa=40,cost_kind='EXPLICIT_PRATA_T9',checks=['TRANSFORM_SOURCE_SPIRIT_ID_UNVERIFIED'],effect_kind='T9_NOT_ACTIVATED')
set_('LIU_TRANSFORMADA','EXTENSAO_TRANSFORMADA',budget='UNRESOLVED',timing='UNRESOLVED',target='UNKNOWN',
     cost_pa=45,cost_kind='EXPLICIT_PER_USE',checks=['TRANSFORMED_FORM_ACTIVE'])
set_('LIU_TRANSFORMADA','RETALIACAO',budget='MODIFIER',timing='ON_COUNTERATTACK',target='INCOMING_ATTACK',
     checks=['TRANSFORMED_FORM_ACTIVE','COUNTERATTACK_HAS_LEGAL_RECEIPT'],effect_kind='PLUS20_COUNTERATTACK_ONLY')
# Valor legado: mantido e classificado sem liberar combate.
assert len(base)==43
universal={}
comb=reg['sources']['COMBAT']
for profile in ['MACACO_P5','LIU_NORMAL','LIU_TRANSFORMADA']:
    for key, budget,tm,tar,effect in [
       ('REACAO_DEFENDER','REACTION','BEFORE_ENEMY_ATTACK','INCOMING_ATTACK','DEFENSE_DECLARATION_ONLY'),
       ('REACAO_ESQUIVAR','REACTION','BEFORE_ENEMY_ATTACK','INCOMING_ATTACK','DEFENSE_DECLARATION_ONLY'),
       ('REACAO_CONTRAATACAR','REACTION','BEFORE_ENEMY_ATTACK','INCOMING_ATTACK','COUNTERATTACK_INTENT_ONLY'),
       ('REACAO_REFLETIR_MAGIA','REACTION','BEFORE_ENEMY_MAGIC','INCOMING_MAGIC','MAGIC_REFLECTION_INTENT_ONLY'),
       ('MOVIMENTAR','MOVEMENT','OWN_TURN','DESTINATION_UNRESOLVED','MOVE_INTENT_ONLY'),
       ('AFASTAR_SE_EM_SEGURANCA','STANDARD_MOVEMENT','OWN_TURN','ONE_ENEMY_AND_DESTINATION','DISENGAGE_INTENT_ONLY'),
    ]:
        k=f'{profile}::UNIVERSAL_{key}'
        universal[k]={'id':k,'profile':profile,'name':'UNIVERSAL_'+key,
            'role':'UNIVERSAL_ACTION','source_id':'COMBAT','source_url':comb['url'],'source_edited_at':comb['last_edited'],
            'linked_calculator':None,'documented_window':'Sistema Combate R1/R3/R4/R8',
            'documented_cost':'Ação/reação declarada; PA não atribuído',
            'legacy_unknowns':['alvo/cena/ordem/efeito definitivos'],
            'budget':budget,'timing':tm,'target':tar,'cost_pa':None,'cost_kind':'UNSPECIFIED_IN_SOURCE_NO_PA_DEBIT',
            'source_evidence':'Sistema de Combate regras R1, R3, R4, R8',
            'checks':[],'supported_scope':'DOCUMENTAL_ELIGIBILITY_ONLY','effect_kind':effect,'possible_damage_component':None}
# Apenas normal pode tentar iniciar transformação T9, sem presumir a ficha de Espírito.
k='LIU_NORMAL::UNIVERSAL_TRANSFORMAR_PRATA'
universal[k]={'id':k,'profile':'LIU_NORMAL','name':'UNIVERSAL_TRANSFORMAR_PRATA','role':'TRANSFORMATION',
   'source_id':'COMBAT','source_url':comb['url'],'source_edited_at':comb['last_edited'],
   'linked_calculator':None,'documented_window':'Ação Completa Prata, duração 1d6+1 turnos',
   'documented_cost':'40 PA','legacy_unknowns':['Spirit-ID','T9 snapshot','form legality'],
   'budget':'FULL','timing':'OWN_TURN','target':'NONE','cost_pa':40,'cost_kind':'EXPLICIT_PER_USE',
   'source_evidence':'Sistema de Combate Regra 9; Espírito especializado pendente',
   'checks':['TRANSFORM_SOURCE_SPIRIT_ID_UNVERIFIED'],'supported_scope':'DOCUMENTAL_ELIGIBILITY_ONLY',
   'effect_kind':'TRANSFORMATION_INTENT_NEVER_AUTO_APPLY','possible_damage_component':None}
combined={**base,**universal}
assert len(combined)==62
output={'schema':'DMG_R30_ACTION_ELIGIBILITY_CROSSWALK_v1','authority':'R29 original action inventory + Sistema Combate R1/R3/R4/R8/R9',
  'history_original_count':43,'universal_applicabilities':len(universal),
  'universe_not_b05_whole_gate':True,'actions':combined}
(ROOT/'politicas_b05_b06_r30.json').write_text(json.dumps(output,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print('R29 base',len(base),'universal applicability',len(universal),'total',len(combined))
