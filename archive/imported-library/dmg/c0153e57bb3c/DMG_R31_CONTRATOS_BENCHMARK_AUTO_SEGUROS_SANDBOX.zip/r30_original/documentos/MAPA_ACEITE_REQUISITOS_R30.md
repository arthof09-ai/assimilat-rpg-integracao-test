# DMG R30 — Matriz de aceite A–J

| Prova | Entrada | Saída comprovada | Recibo |
|---|---|---|---|
| A Patada | Macaco turno1, Padrão não consumida, melee confirmado em fixture | PERMITIDA declaração no subconjunto | `A_patada_elegivel.json` |
| B Falta PA | Macaco PA5, Poder Elemental custo10 | PROIBIDA | `B_poder_elemental_PA5_proibido.json` |
| C PA desconhecido | Macaco `pa_available=null` | PENDENTE | `C_poder_elemental_PA_desconhecido_pendente.json` |
| D Forma | Liu normal vs transformada alternativa | 23 vs 10 opções de escopo, atributos separados | `D_liu_normal_menu.json`, `D_liu_transformada_menu.json` |
| E Passiva | Força Titânica +2 não adjudicada no FOR54 | PENDENTE como bônus; Patada [3,5] = 62 só FOR54 | `E_forca_titanica_passiva_pendente.json`, `E_patada_calculo_R29_encadeado.json` |
| F Equipamento | Liu machado não equipado | PROIBIDA | `F_liu_sem_machado_proibido.json` |
| G Janela | Reação em próprio turno; antes de ataque; já consumida | PROIBIDA → PERMITIDA → PROIBIDA | `G_*.json` |
| H Estado persistido | Revisão 0→1 por patch manual `standard_consumed=true` | Patada PERMITIDA → PROIBIDA; mesmo request id idempotente | `H_*.json`, `fixtures/04_*.json` |
| I Interoperabilidade | intenção Macaco Patada | envelope contrato, `transport=NOT_SENT`, source_digest null | `I_intencao_VLAB_nao_enviada.json` |
| J Regressão | R28/R29 intactos, R30 novo | 26+50+43 = 119 testes locais PASS | `TESTES_R30_43.log`, `REGRESSAO_R29_50.log`, `REGRESSAO_R28_26.log` |

`PERMITIDA` nunca equivale a ação produtiva executada, nem prova de custo PA omitido. O caso E não agrega a passiva; o cálculo bruto é delegado ao R29 inalterado após consulta a R30. Nenhum consumo foi efetivado ou afirmado.
