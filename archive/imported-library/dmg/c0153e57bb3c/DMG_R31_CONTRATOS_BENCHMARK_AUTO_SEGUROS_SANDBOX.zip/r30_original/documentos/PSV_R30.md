# PSV R30 — OP-DMG-CORPUS-EMP-01

## LER / ANTES
- Arquivo R29 recapturado em bytes (hash verificado), R28+R27 inclusos e coincidentes com arquivos locais.
- R26 original não conferido como bytes; referências e SHA históricos preservados da pesquisa.
- B05 `ACTION_INVENTORY` PARTIAL e B06 `ACTION_COST_AND_REACTION_WINDOWS` PARTIAL; matriz original não modificada.
- B01–B18: `1/18 PASS_DOCUMENTAL`, `9/18 PARTIAL`, `6/18 BLOCKED`, `2/18 NOT_TESTED`.
- STRICT `0/2`; I0003 CSV `0/9`; B11/B12 decisões `0/5`; IBX-90 `NOVA`, `Lida por INSTANCE-ID = null` (consulta Notion dirigida).

## EXEC / VERIFY
- Perfil controlado: Macaco Rei Prata5 (titã título) vs Liu Xiaua normal; alternativa Liu transformada não deriva automaticamente de T9.
- Inventário R29 original: `43/43` entradas reenquadradas em campos de elegibilidade; `19` aplicabilidades de ações universais de Sistema de Combate para Macaco, Liu normal e Liu transformada, total de `62` entradas no *recorte*, não no universo canônico B05.
- `20` recibos de demonstração após compilação real de estados; cenário A-J coberto.
- Testes compilador: `43/43` PASS. Regressão R29: `50/50` PASS, R28 `26/26` PASS, total `119/119` verificações automatizadas; nenhuma UAT humana reivindicada.
- Reação Padrão/Momento validada no subconjunto; sem segundo scheduler A1 nem HP/PA reducer.
- Três resultados: PERMITIDA (competência experimental delimitada), PROIBIDA (impedimento comprovado), PENDENTE (entrada faltante).

## DEPOIS
- B01–B18 **INALTERADOS**: 1/18 PASS_DOCUMENTAL (5,56%), 9/18 PARTIAL, 6/18 BLOCKED, 2/18 NOT_TESTED.
- B05 e B06 PARCIAIS; universo terminal de B05 **NÃO DETERMINÁVEL AINDA**. 62 entradas não tornam B05 certificado.
- STRICT 0/2, I0003 CSV 0/9, B11/B12 0/5; DEC-B11-A/B/C, DEC-B12-A/B, DEC-BONUS-JAKU-01, DEC-INFUSION-JAKU-01 sem aprovação.
- IBX-90 reutilizada exclusivamente por menção no envelope de proposta. Nenhuma escrita ou entrega VLAB.
- DMG-RANK, fichas oficiais, Party e O Primeiro sem escrita; writer, lease, epoch, fencing, GREEN, NAC-PASS produtivo HOLD.

## Fronteira real
B05: fixar `scene_id` competente, ator+forma, inventário legal fechado, cargas de PA e itens, condição de combate e geometria, hash nativo da fonte, aceitar em receptor VLAB legítimo com readback. B06: fontes de ação/janela específicas, ordem e reação única com evento real ou equivalente autorizado. **Não** solicitar exceção de bônus D&D; não promover resultado experimental a evento oficial.
