import json,copy
from pathlib import Path
R=Path(__file__).resolve().parent

def actor(actor_id,source_id,form_id,attrs,rank,pa,form_basis):
    return {
      'actor_id':actor_id,'source_id':source_id,'form_id':form_id,
      'form_basis':form_basis,'rank_documental':rank,'attributes':attrs,
      'pa_available':pa, 'budget':{'standard_consumed':False,'movement_consumed':False,
                                   'reaction_consumed':False,'full_consumed':False},
      'target':{'target_id':'liu' if actor_id=='macaco' else 'macaco',
                'melee_reach_confirmed':True,'distance_m':1.5,'distance_fixture_only':True},
      'equipment':{'axe_equipped':None,'axe_active':None,'equipment_pa_ledger_verified':None},
      'conditions':{'fury_active':None,'hp_half_or_less':None,'spirit_verified':None,
                    'form_active':form_id!='LIU_NORMAL','axe_two_handed_confirmed':None,
                    'heavy_weapon_confirmed':None,'passive_stack_resolved':None,
                    'no_double_count_verified':None,'melee_action_validated':True,
                    'reaction_eligible':None,'force_override':None},
      'documentary_snapshot_is_not_actor_from_campaign':True
    }
base={
 'schema':'R30_SCENE_FIXTURE_NOT_CANON', 'mode':'EXPERIMENTAL_FIXTURE_ONLY',
 'scene_id':'EXP-R30-LIU-MACACO-01', 'state_revision':0,
 'scene':{'round':1,'phase':'OWN_TURN','active_actor_id':'macaco',
          'incoming_attack':False,'incoming_magic':False,'tempo_is_not_historical':True},
 'actors':{
   'macaco':actor('macaco','MACACO','MACACO_P5',{'FOR':54,'DES':40,'CON':35,'INT':30},
                  'Prata 5 (titã) na hierarquia do Bestiário',20,'LITERAL_SOURCE_PROFILE_FIXED_FICTITIOUS_STATE'),
   'liu':actor('liu','LIU','LIU_NORMAL',{'FOR':29,'DES':16,'CON':16,'INT':11},
               'Prata 5',None,'NOT_TRANSFORMED_IN_FICTITIOUS_STATE')
 },
 'known_fixture_assumptions':['Rodada 1','Macaco em seu turno','nenhuma ação consumida',
       'alvo Liu ao alcance corpo a corpo marcado como hipótese de fixture',
       'PA20 Macaco meramente inventado para ensaio','não houve cena real'],
 'historical_event':False,'official_write':False,'synthetic_input':True
}
# Distinguish two alternative Liu profiles, NEVER upgrade stats in this test.
liu_normal=copy.deepcopy(base)
liu_normal['scene']['active_actor_id']='liu'
liu_normal['actors']['liu']['equipment'].update({'axe_equipped':True,'axe_active':True,
                                                  'equipment_pa_ledger_verified':True})
liu_normal['actors']['liu']['conditions']['no_double_count_verified']=True
liu_normal['actors']['liu']['pa_available']=50
liu_normal['known_fixture_assumptions']+=['Liu tem machado equipado ativo; PA/itens hipoteticamente reconciliados SOMENTE dentro do fixture']
transformed=copy.deepcopy(liu_normal)
transformed['scene_id']='EXP-R30-LIU-TRANSFORMADA-ALTERNATIVA-01'
transformed['state_revision']=0
transformed['actors']['liu']['form_id']='LIU_TRANSFORMADA'
transformed['actors']['liu']['attributes']={'FOR':40,'DES':27,'CON':25,'INT':14}
transformed['actors']['liu']['form_basis']='ALTERNATIVE_FIXTURE_ASSUMED_TRANSFORMED_NOT_T9_EVENT'
transformed['actors']['liu']['conditions']['form_active']=True
transformed['known_fixture_assumptions']+=['Formulário transformado escolhido como alternativa hipotética; NÃO inferir que T9 foi usada']

for filename,data in [('01_macaco_turno.json',base),('02_liu_normal.json',liu_normal),
                      ('03_liu_transformada_alternativa.json',transformed)]:
    (R/'fixtures'/filename).write_text(json.dumps(data,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
print('Fixtures definidos: Macaco turno, Liu normal, Liu transformada alternativa')
