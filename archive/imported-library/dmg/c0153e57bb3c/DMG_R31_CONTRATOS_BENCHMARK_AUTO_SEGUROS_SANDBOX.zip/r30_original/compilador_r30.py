#!/usr/bin/env python3
"""OP-DMG-CORPUS-EMP-01 R30 / Mestre-side: compilador EXPERIMENTAL de elegibilidade.
Importa os contratos R29/R28 inalterados. Não é executor VLAB, scheduler A1,
reducer HP, escritor Notion, nem adjudicador de fonte histórica.

Estados de saída são limitados a condições implementadas, nunca PASS integral B05.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,sys,os,tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'r29_original'))
import verificador_r29 as v29
POLICY=json.loads((ROOT/'politicas_b05_b06_r30.json').read_text(encoding='utf8'))
ACTIONS=POLICY['actions']
REG=v29.REG
ALLOW='PERMITIDA'
DENY='PROIBIDA'
PENDING='PENDENTE'
PATCH_PATHS={
 'budget.standard_consumed','budget.movement_consumed','budget.reaction_consumed','budget.full_consumed',
 'pa_available','target.melee_reach_confirmed','target.target_id','target.distance_m',
 'equipment.axe_equipped','equipment.axe_active','equipment.equipment_pa_ledger_verified',
 'conditions.fury_active','conditions.hp_half_or_less','conditions.spirit_verified',
 'conditions.form_active','conditions.axe_two_handed_confirmed','conditions.heavy_weapon_confirmed',
 'conditions.passive_stack_resolved','conditions.no_double_count_verified',
 'conditions.melee_action_validated','conditions.reaction_eligible',
 'scene.phase','scene.active_actor_id','scene.incoming_attack','scene.incoming_magic',
 'scene.round'
}


def digest(obj):
    canonical=json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))
    return hashlib.sha256(canonical.encode('utf8')).hexdigest()


def validate_snapshot(state):
    if not isinstance(state,dict):raise ValueError('STATE_NOT_OBJECT')
    for k in ('scene_id','mode','state_revision','scene','actors'):
        if k not in state:raise ValueError('MISSING_STATE_'+k)
    if state['mode']!='EXPERIMENTAL_FIXTURE_ONLY':raise ValueError('ONLY_EXPERIMENTAL_FIXTURE')
    if type(state['state_revision'])!=int or state['state_revision']<0:raise ValueError('INVALID_REVISION')
    if not isinstance(state['actors'],dict) or not isinstance(state['scene'],dict):raise ValueError('INVALID_STATE_SHAPE')
    if type(state.get('scene_id'))!=str or not state['scene_id'].startswith('EXP-R30-'):raise ValueError('SCENE_ID_MUST_BE_EXPERIMENTAL')
    for actor_id,a in state['actors'].items():
        if a.get('actor_id')!=actor_id:raise ValueError('ACTOR_ID_MISMATCH')
        if a.get('source_id') not in REG['sources']:raise ValueError('UNKNOWN_SOURCE')
        if a.get('form_id') not in REG['profiles']:raise ValueError('UNKNOWN_FORM')
        if REG['profiles'][a['form_id']]['source']!=a['source_id']:raise ValueError('SOURCE_FORM_MISMATCH')
        if a.get('attributes')!=state_attribute_fixture(a['form_id']):raise ValueError('ATTRIBUTE_SOURCE_FORM_MISMATCH')
        if a['form_id'] in ('MACACO_P5','LIU_NORMAL','LIU_TRANSFORMADA') and not a.get('rank_documental','').startswith('Prata 5'):
            raise ValueError('RANK_CONFLICT_WITH_DOCUMENTARY_PROFILE')
        pa=a.get('pa_available')
        if pa is not None and (type(pa)!=int or pa<0):raise ValueError('PA_MUST_BE_NONNEG_INT_OR_NULL')
        for k in ['budget','target','equipment','conditions']:
            if k not in a or not isinstance(a[k],dict):raise ValueError('MISSING_ACTOR_'+k)
    return True


def state_attribute_fixture(form):
    return {
      'MACACO_P5':{'FOR':54,'DES':40,'CON':35,'INT':30},
      'LIU_NORMAL':{'FOR':29,'DES':16,'CON':16,'INT':11},
      'LIU_TRANSFORMADA':{'FOR':40,'DES':27,'CON':25,'INT':14},
      'JAKU_P3':{'FOR':22,'DES':13,'CON':7,'INT':7},
      'DRAGON_A':{'FOR':36,'DES':28,'CON':33,'INT':16},
      'DRAGON_B':{'FOR':60,'DES':50,'CON':38,'INT':20}
    }[form]


def _known(x):return x is True or x is False


def evaluate(action,actor,state):
    """Tri-estado: impedimento certo ganha de lacuna; nenhuma ausência vira falso ou custo zero."""
    denied=[];pending=[];verified=[]
    phase=state['scene'].get('phase')
    active=state['scene'].get('active_actor_id')
    bud=actor['budget']; target=actor['target']; eq=actor['equipment']; cond=actor['conditions']
    def test(label,value,if_missing=True):
        if value is True:verified.append(label)
        elif value is False:denied.append(label)
        elif if_missing:pending.append(label)
    budget=action['budget'];win=action['timing'];tg=action['target']
    if actor['form_id']=='LIU_TRANSFORMADA':
        test('TRANSFORMED_FORM_FIXTURE_ACTIVE',cond.get('form_active'))
    elif actor['form_id']=='LIU_NORMAL' and cond.get('form_active') is True:
        denied.append('NORMAL_FORM_CONTRADICTS_TRANSFORMED_ACTIVE_FLAG')
    # Budget and moment distinguish reaction from own action. No synthetic scheduler.
    if budget in ('STANDARD','MOVEMENT','STANDARD_MOVEMENT','FULL'):
        if phase!='OWN_TURN':
            if phase is None:pending.append('TURN_PHASE_UNPROVED')
            else:denied.append('OUTSIDE_OWN_TURN')
        if active is None:pending.append('ACTIVE_ACTOR_UNPROVED')
        elif active!=actor['actor_id']:denied.append('NOT_ACTORS_TURN')
        if budget in ('STANDARD','STANDARD_MOVEMENT','FULL'):
            test('STANDARD_ACTION_BUDGET',None if bud.get('standard_consumed') is None else not bud['standard_consumed'])
        if budget in ('MOVEMENT','STANDARD_MOVEMENT','FULL'):
            test('MOVEMENT_ACTION_BUDGET',None if bud.get('movement_consumed') is None else not bud['movement_consumed'])
        if budget=='FULL':
            # Regra completa normalmente exige abrir mão da reação: não tratamos como custo tácito padrão.
            if bud.get('reaction_consumed') is True:pending.append('FULL_ACTION_AFTER_REACTION_NOT_ADJUDICATED')
        if bud.get('full_consumed') is True:denied.append('FULL_ACTION_ALREADY_USED')
        elif bud.get('full_consumed') is None:pending.append('FULL_CONSUMPTION_UNKNOWN')
    elif budget=='REACTION':
        test('REACTION_BUDGET',None if bud.get('reaction_consumed') is None else not bud['reaction_consumed'])
        if bud.get('full_consumed') is True:denied.append('FULL_ACTION_ALREADY_USED_REACTION_UNAVAILABLE')
        elif bud.get('full_consumed') is None:pending.append('FULL_ACTION_HISTORY_UNKNOWN')
    elif budget=='PASSIVE':
        verified.append('PASSIVE_NOT_ACTION_BUDGET')
    elif budget=='MODIFIER':
        pending.append('MODIFIER_NOT_STANDALONE_ACTION')
    elif budget=='BONUS_UNMAPPED':
        pending.append('BONUS_ACTION_NOT_IN_ASSIMILACAO_ACTION_TAXONOMY')
    else:
        pending.append('ACTION_BUDGET_UNRESOLVED')
    if win=='BEFORE_ENEMY_ATTACK':
        if phase=='BEFORE_ENEMY_ATTACK':
            test('INCOMING_ATTACK_PROVED',state['scene'].get('incoming_attack'))
        elif phase is None:pending.append('REACTION_WINDOW_UNKNOWN')
        else:denied.append('REACTION_OUTSIDE_BEFORE_ENEMY_ATTACK_WINDOW')
    if win=='BEFORE_ENEMY_MAGIC':
        if phase=='BEFORE_ENEMY_MAGIC':test('INCOMING_MAGIC_PROVED',state['scene'].get('incoming_magic'))
        elif phase is None:pending.append('MAGIC_WINDOW_UNKNOWN')
        else:denied.append('MAGIC_REACTION_OUTSIDE_WINDOW')
    if win=='ON_COUNTERATTACK':
        if phase!='BEFORE_ENEMY_ATTACK':denied.append('NO_COUNTERATTACK_WINDOW')
        if cond.get('reaction_eligible') is not True:pending.append('COUNTERATTACK_SEQUENCE_RECEIPT_MISSING')
    if win in ('UNRESOLVED','ON_VALID_WEAPON_HIT','ON_VALID_WEAPON_DAMAGE','ON_CRITICAL'):
        pending.append('EFFECT_TRIGGER_OR_ACTIVATION_TIMING_UNRESOLVED')
    if tg=='MELEE_CONFIRMED':
        test('TARGET_ID_PRESENT',bool(target.get('target_id')) if target.get('target_id') is not None else None)
        test('MELEE_REACH_CONFIRMED_BY_FIXTURE',target.get('melee_reach_confirmed'))
    elif tg=='INCOMING_ATTACK':
        if state['scene'].get('incoming_attack') is not True and phase=='BEFORE_ENEMY_ATTACK':
            pending.append('INCOMING_ATTACK_EVENT_REQUIRED')
    elif tg=='INCOMING_MAGIC':
        if state['scene'].get('incoming_magic') is not True and phase=='BEFORE_ENEMY_MAGIC':
            pending.append('INCOMING_MAGIC_EVENT_REQUIRED')
    elif tg=='THROW_6M':
        test('TARGET_ID_PRESENT',bool(target.get('target_id')) if target.get('target_id') is not None else None)
        distance=target.get('distance_m')
        if distance is None:pending.append('TARGET_DISTANCE_NOT_PROVED')
        elif type(distance) not in (int,float) or distance<0:denied.append('INVALID_DISTANCE')
        elif distance>6:pending.append('RANGE_OUTSIDE_DOCUMENTED_NORMAL_6M_NOT_ADJUDICATED')
        else:verified.append('WITHIN_DOCUMENTED_NORMAL_THROW_RANGE_6M')
    elif tg in ('UNKNOWN','TARGET_UNRESOLVED','DESTINATION_UNRESOLVED','ONE_ENEMY_AND_DESTINATION'):
        pending.append('TARGET_RANGE_OR_GEOMETRY_UNRESOLVED')
    cost=action.get('cost_pa')
    if cost is not None:
        pa=actor.get('pa_available')
        if pa is None:pending.append('PA_AVAILABLE_NOT_PROVED')
        elif pa<cost:denied.append(f'PA_INSUFFICIENT:{pa}<{cost}')
        else:verified.append(f'PA_AVAILABLE_GE_COST:{pa}>={cost}')
    elif action['cost_kind'] not in ('UNSPECIFIED_IN_SOURCE_NO_PA_DEBIT','UNSPECIFIED'):
        pending.append('ITEM_PA_ACCOUNTING_OR_DAILY_COMMITMENT_UNRESOLVED')
    else:
        # No cost subtraction. The action may be DECLARE-eligible within the rule subset;
        # full spending policy remains excluded from proof by design.
        verified.append('NO_PA_DEBIT_AUTHORIZED_FOR_THIS_SUBSET')
    checks=action.get('checks',[])
    if 'MACACO_FORCE_LITERAL_ONLY' in checks:
        verified.append('FOR54_LITERAL;NO_AUTOMATIC_PLUS2_TITANIC')
        if cond.get('force_override') not in (None,54):denied.append('FOR_OVERRIDE_NOT_AUTHORIZED')
    if 'LIU_AXE_EQUIPPED' in checks:test('AXE_EQUIPPED',eq.get('axe_equipped'))
    if 'LIU_AXE_ACTIVE' in checks:test('AXE_ACTIVE',eq.get('axe_active'))
    if 'LIU_ITEM_PA_LEDGER_UNVERIFIED' in checks or 'EQUIPMENT_PA_LEDGER_UNVERIFIED' in checks:
        test('EQUIPMENT_PA_LEDGER_PROVED',eq.get('equipment_pa_ledger_verified'))
    if 'NO_DOUBLE_COUNT_PROOF' in checks:test('NO_DOUBLE_COUNT_PROVED',cond.get('no_double_count_verified'))
    if 'HALF_HP_CONFIRMED' in checks:test('HP_BELOW_OR_EQUALS_HALF',cond.get('hp_half_or_less'))
    if 'FURY_ACTIVE_CONFIRMED' in checks:test('FURY_ACTIVE',cond.get('fury_active'))
    if 'TWO_HANDED_CONFIRMED' in checks:test('WEAPON_TWO_HANDED',cond.get('axe_two_handed_confirmed'))
    if 'HEAVY_WEAPON_CONFIRMED' in checks:test('WEAPON_HEAVY',cond.get('heavy_weapon_confirmed'))
    if 'TRANSFORMED_FORM_ACTIVE' in checks:test('TRANSFORMED_FORM_ACTIVE_FIXTURE',cond.get('form_active'))
    if 'TRANSFORM_SOURCE_SPIRIT_ID_UNVERIFIED' in checks:
        test('SPIRIT_ID_AND_T9_SOURCE_VALID',cond.get('spirit_verified'))
        if cond.get('spirit_verified') is True:
            pending.append('SOURCE_ADJUDICATION_BEFORE_T9_COMMIT_PENDING')
    if 'COUNTERATTACK_HAS_LEGAL_RECEIPT' in checks:pending.append('COUNTERATTACK_EVENT_RECEIPT_REQUIRED')
    if 'LIU_SHORTCUT_UNRECONCILED' in checks:pending.append('LIU_ATTACK_SHORTCUT_UNRECONCILED')
    if 'PASSIVE_FF_STACKING_UNRESOLVED' in checks:pending.append('FORCA_TITANICA_INCLUSION_IN_PRINTED_FOR54_UNKNOWN')
    if 'BONUS_ACTION_NOT_SYSTEM' in checks:pending.append('BONUS_ACTION_NO_SYSTEM_MAPPING')
    if 'DEC_B11_PENDING' in checks:pending.append('DEC_B11_UNDECIDED')
    if 'ELEMENT_NOT_INFERRED' in checks:pending.append('ELEMENT_TYPE_UNSPECIFIED')
    if action['effect_kind']=='UNRECONCILED_COMPOSITE':pending.append('DAMAGE_COMPONENTS_NOT_RECONCILED')
    if action['effect_kind']=='UNDEFINED_MAGIC':pending.append('SPELL_EFFECT_COST_RANGE_UNDEFINED')
    if action['effect_kind']=='NON_DAMAGING_COMMUNICATION':pending.append('TELEPATHY_COST_RANGE_WINDOW_UNDEFINED')
    if action['budget']=='PASSIVE' and action['role']=='ITEM_PASSIVE':
        pending.append('PASSIVE_EQUIPMENT_LOADOUT_NOT_CONFIRMED')
    if action['role']=='UNIVERSAL_ACTION' and 'DEFENSE_DECLARATION' in action['effect_kind']:
        # Defense method calculation intentionally owned by VLAB;
        # legality of declaration is all this subset attempts.
        verified.append('ONLY_DECLARATION_NOT_DEFENSE_RESOLUTION')
    status=DENY if denied else PENDING if pending else ALLOW
    return {'eligibility':status,'proved':sorted(set(verified)),'prohibited_reasons':sorted(set(denied)),
            'unresolved_requirements':sorted(set(pending))}


def compile_scene(state,actor_id):
    validate_snapshot(state)
    if actor_id not in state['actors']:
        raise ValueError('ACTOR_NOT_IN_SCENE')
    actor=state['actors'][actor_id]
    form=actor['form_id']
    subset=[v for v in ACTIONS.values() if v['profile']==form]
    decisions=[]
    for a in sorted(subset,key=lambda x:x['id']):
        r=evaluate(a,actor,state)
        ref=REG['sources'][a['source_id']]
        rules=REG['sources']['COMBAT']
        entry={
          'action_id':a['id'],'name':a['name'],'action_type':a['budget'],
          'action_role':a['role'],
          'selectable_as_declaration_in_sandbox':r['eligibility']==ALLOW and a['budget'] in ('STANDARD','MOVEMENT','STANDARD_MOVEMENT','FULL','REACTION'),
          'eligibility':r['eligibility'],'verified_reasons':r['proved'],
          'prohibited_reasons':r['prohibited_reasons'],'unresolved_requirements':r['unresolved_requirements'],
          'resource_requirements':{'documentary_cost':a['documented_cost'],'cost_pa_explicit':a['cost_pa'],
                                   'cost_kind':a['cost_kind'],'pa_available_fixture':actor.get('pa_available'),
                                   'actual_pa_debit':None},
          'target_requirements':{'type':a['target'],'target_id_fixture':actor['target'].get('target_id'),
                                 'melee_reach_fixture':actor['target'].get('melee_reach_confirmed')},
          'temporal_window':{'rule':a['timing'],'phase_fixture':state['scene'].get('phase'),
                             'consumption':a['budget'],'event_execution':False},
          'source_id':a['source_id'],'source_url':ref['url'],'source_last_edited_at_not_effective_at':ref['last_edited'],
          'source_digest':None,'source_digest_state':'NATIVE_NOTION_BYTES_NOT_FROZEN',
          'field_authorities':{
               'named_ability':a['source_url'],'action_budget':rules['url'] if a['budget'] in ('STANDARD','REACTION','FULL','MOVEMENT','STANDARD_MOVEMENT') else a['source_url'],
               'cost':a['source_url'] if a['cost_pa'] is not None else None,
               'target': 'SIMULATION_FIXTURE_NOT_HISTORIC' if a['target'] in ('MELEE_CONFIRMED','THROW_6M') else a['source_url'],
               'damage_formula':a['source_url'] if a.get('linked_calculator') else None},
          'effect_plan':{'mode':'NO_DISPATCH','kind':a['effect_kind'],'r29_calculation_case':a.get('linked_calculator'),
                         'atomic_effect':'DOCUMENTAL_COMPONENT_ONLY' if a.get('linked_calculator') else 'NONE',
                         'hp_delta':None,'pa_delta':None,'do_not_apply':True},
          'scope':'EXPERIMENTAL_SUBSET_ELIGIBILITY_NOT_B05_ACCEPTANCE',
          'no_official_execution':True,
        }
        entry['receipt_id']='R30E-'+digest({k:v for k,v in entry.items() if k!='receipt_id'})[:24]
        decisions.append(entry)
    counts={s:sum(x['eligibility']==s for x in decisions) for s in (ALLOW,DENY,PENDING)}
    out={'schema':'OPDMG_R30_ELIGIBILITY_MENU_v1', 'operation':'OP-DMG-CORPUS-EMP-01',
         'scene_id':state['scene_id'],'state_revision':state['state_revision'],'state_sha256':digest(state),
         'actor_id':actor_id,'source_id':actor['source_id'],'form_id':form,
         'rank_text_documental':actor.get('rank_documental'),
         'active_form_basis':actor.get('form_basis'),
         'source_digest':None,'source_digest_note':'NATIVE_SOURCE_NOT_FROZEN_FOR_CONSUMER',
         'combat_outcome':'NOT_EXECUTED','STRICT':'DENY','B05':'PARTIAL','B06':'PARTIAL',
         'menu_counts':counts,'total':len(decisions),'decisions':decisions,
         'eligible_meaning':'LEGAL_TO_DECLARE_WITHIN_IMPLEMENTED_FIXTURE_SUBSET_ONLY,NOT_VALIDATED_FOR_OFFICIAL_COMMIT',
         'authorization':{'Notion_writes':False,'VLAB_sent':False,'HP_delta':False,'PA_delta':False}}
    out['receipt_id']='R30M-'+digest(out)[:24]
    out['content_sha256']=digest(out)
    return out


def create_vlab_intent(state,actor_id,action_id):
    menu=compile_scene(state,actor_id)
    candidates={a['action_id']:a for a in menu['decisions']}
    if action_id not in candidates:raise ValueError('ACTION_NOT_OF_SELECTED_FORM')
    a=candidates[action_id]
    # Builder never submits and never claims source lock, source digest, resource spend or resolver integration.
    intent={
      'contract':'OPDMG_R30_TO_VLAB_TRIAGE_PROPOSAL_v0.1_NOT_CANONICAL',
      'scene_id':state['scene_id'],'actor_id':actor_id,'source_id':a['source_id'],
      'source_digest':None,'form_id':state['actors'][actor_id]['form_id'],
      'state_revision':state['state_revision'],'action_id':action_id,'action_type':a['action_type'],
      'eligibility':a['eligibility'],'resource_requirements':a['resource_requirements'],
      'target_requirements':a['target_requirements'],'temporal_window':a['temporal_window'],
      'effect_plan':a['effect_plan'],'unresolved_requirements':sorted(set(a['unresolved_requirements']+(
         [] if a['selectable_as_declaration_in_sandbox'] else ['NOT_SELECTABLE_AS_AN_ACTION_IN_THIS_SUBSET'])+[
         'VLAB_CONSUMER_ACK_AND_CAPABILITY_UNVERIFIED','NATIVE_SOURCE_DIGEST_UNAVAILABLE',
         'SOURCE_FROZEN_SCENE_AND_COMMIT_GATE_NOT_SATISFIED'])),
      'receipt_id':a['receipt_id'],'ibx_existing':'IBX-90','source_url':a['source_url'],
      'dispatchable_action':a['selectable_as_declaration_in_sandbox'],
      'transport':'NOT_SENT','VLAB_result':None,'execution_status':'TRIAGE_ONLY_NO_DISPATCH',
      'writer':'HOLD','lease':'HOLD','epoch':'HOLD','fencing':'HOLD','GREEN':'HOLD','NAC_PASS':'HOLD'
    }
    intent['content_sha256']=digest(intent)
    return intent


def calculate_isolated(state,actor_id,action_id,rolls):
    m=compile_scene(state,actor_id)
    by={x['action_id']:x for x in m['decisions']}
    if action_id not in by:raise ValueError('ACTION_NOT_IN_SELECTED_FORM')
    a=by[action_id]
    if a['eligibility']!=ALLOW:
        return {'status':'HOLD_ACTION_NOT_ELIGIBLE','eligibility':a['eligibility'],
                'reasons':a['prohibited_reasons']+a['unresolved_requirements'],
                'action_id':action_id,'state_revision':state['state_revision'],'raw_damage':None}
    old= ACTIONS[action_id]['linked_calculator']
    if not old:
        return {'status':'HOLD_NO_R29_DICE_CONTRACT','action_id':action_id,'raw_damage':None}
    result=v29.calculate({'mode':'DOCUMENTAL_DICE_ONLY','action_id':old,'rolls':rolls})
    r={'schema':'OPDMG_R30_BOUND_R29_MATH_v1','eligibility_receipt_id':a['receipt_id'],
       'action_id':action_id,'state_revision':state['state_revision'],
       'state_sha256':m['state_sha256'], 'r29_receipt':result,
       'not_hit':True,'no_pa_debit':True,'no_hp_update':True,'strict':False}
    r['receipt_id']='R30C-'+digest(r)[:24]
    return r


def apply_manual_patch(path,change):
    """Only the Mestre/Comestre fixture state changes; no scheduler/reducer/PA/HP execution.
    Patch is a user-declared fact for the sandbox, not the consequence of action resolution.
    """
    state=json.loads(Path(path).read_text(encoding='utf8'));validate_snapshot(state)
    rid=change.get('request_id');actor_id=change.get('actor_id')
    if not isinstance(rid,str) or not rid or len(rid)>80:raise ValueError('REQUEST_ID_INVALID')
    if actor_id not in state['actors']:raise ValueError('ACTOR_NOT_IN_SCENE')
    changes=change.get('changes')
    if not isinstance(changes,dict) or not changes:raise ValueError('CHANGES_EMPTY')
    invalid=set(changes)-PATCH_PATHS
    if invalid:raise ValueError('UNSUPPORTED_PATCH_FIELDS:'+','.join(sorted(invalid)))
    ledger_path=Path(str(path)+'.manual_journal.json')
    ledger=json.loads(ledger_path.read_text(encoding='utf8')) if ledger_path.exists() else []
    original_digest=digest({'actor_id':actor_id,'changes':changes})
    for e in ledger:
        if e['request_id']==rid:
            if e['request_digest']!=original_digest:raise ValueError('REQUEST_ID_COLLISION_DIFFERENT_PATCH')
            return {'status':'IDEMPOTENT_REPLAY','stored_receipt':e,'revision':state['state_revision']}
    if state['state_revision']!=change.get('expected_state_revision'):
        raise ValueError('REVISION_CONFLICT_EXPECTED_'+str(change.get('expected_state_revision'))+'_ACTUAL_'+str(state['state_revision']))
    oldsha=digest(state);new=copy.deepcopy(state)
    for field,value in changes.items():
        if field.startswith('scene.'):
            new['scene'][field[6:]]=value
            continue
        parts=field.split('.')
        root=parts[0]
        if root=='pa_available':
            if value is not None and (type(value)!=int or value<0):raise ValueError('BAD_PA_VALUE')
            new['actors'][actor_id]['pa_available']=value
        elif root=='budget':
            if value is not None and type(value)!=bool:raise ValueError('BAD_BUDGET_FLAG')
            new['actors'][actor_id]['budget'][parts[1]]=value
        elif root=='target':
            if field=='target.melee_reach_confirmed' and value is not None and type(value)!=bool:raise ValueError('BAD_REACH_FLAG')
            new['actors'][actor_id]['target'][parts[1]]=value
        elif root=='equipment':
            if value is not None and type(value)!=bool:raise ValueError('BAD_EQUIPMENT_FLAG')
            new['actors'][actor_id]['equipment'][parts[1]]=value
        elif root=='conditions':
            if value is not None and type(value)!=bool:raise ValueError('BAD_CONDITION_FLAG')
            new['actors'][actor_id]['conditions'][parts[1]]=value
    new['state_revision']+=1
    validate_snapshot(new)
    receipt={'schema':'OPDMG_R30_MANUAL_FIXTURE_STATE_REVISION_v1','request_id':rid,
             'request_digest':original_digest,'prior_revision':state['state_revision'],
             'new_revision':new['state_revision'],'old_sha256':oldsha,'new_sha256':digest(new),
             'changes':changes,'actor_id':actor_id,'official_event':False,'automatic_spending':False,
             'note':'Copia de ensaio: mudanca declarada manualmente, NAO aplicada por motor VLAB'}
    receipt['receipt_id']='R30P-'+digest(receipt)[:24]
    ledger.append(receipt)
    # Local atomic file replacements (no claim of transaction across both files / no runtime authority).
    for target,data in [(Path(path),new),(ledger_path,ledger)]:
        target.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix='.r30-',suffix='.tmp',dir=str(target.parent));os.close(fd)
        try:
            Path(tmp).write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
            os.replace(tmp,target)
        finally:
            if Path(tmp).exists():Path(tmp).unlink()
    return {'status':'PATCHED_FIXTURE_ONLY','receipt':receipt}


def main():
    cli=argparse.ArgumentParser(description='DMG R30: compiler de elegibilidade experimental (Comestre usa diretamente pelo chat)')
    cli.add_argument('--state',type=Path,required=True)
    options=cli.add_mutually_exclusive_group(required=True)
    options.add_argument('--menu',action='store_true')
    options.add_argument('--intent',type=str)
    options.add_argument('--calculate',type=str)
    options.add_argument('--patch-json',type=str)
    cli.add_argument('--actor-id',type=str)
    cli.add_argument('--rolls',type=str)
    a=cli.parse_args()
    if a.patch_json:
        result=apply_manual_patch(a.state,json.loads(a.patch_json))
    else:
        state=json.loads(a.state.read_text(encoding='utf8'))
        if not a.actor_id:cli.error('--actor-id required for menu/intent/calculate')
        if a.menu:result=compile_scene(state,a.actor_id)
        elif a.intent:result=create_vlab_intent(state,a.actor_id,a.intent)
        else:
            if not a.rolls:cli.error('--rolls required for calculate')
            result=calculate_isolated(state,a.actor_id,a.calculate,json.loads(a.rolls))
    print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True))
if __name__=='__main__':main()
