import hashlib,json,unittest
from pathlib import Path
from verificador_r28 import inspect_ff,verify_event,eval_bleed_tick,stats,REGISTRY

def sample(case,rolls,mode='DOCUMENTAL'):
 return {'modo':mode,'tipo':'DANO_ISOLADO','caso':case,'dados':rolls}
class ScientificContractTests(unittest.TestCase):
 def test_parent_binary_sha(self):
  f=Path(__file__).parent/'historico'/'R27_EXPERIMENTAL_ORIGINAL_READONLY.zip'
  self.assertEqual(hashlib.sha256(f.read_bytes()).hexdigest(),'b1fe89d8b5560779ec19ac7a5b16fa056eaa75d6633d61c786974c7c9fcbb096')
 def test_ff_calc(self):self.assertEqual(inspect_ff()['FF_formula_atual'],420)
 def test_ff_printed(self):self.assertEqual(inspect_ff()['FF_impresso'],390)
 def test_ff_difference(self):self.assertEqual(inspect_ff()['diferenca_FF'],30)
 def test_ff_locks(self):self.assertEqual(inspect_ff()['total_FF_dano_registrado'],5)
 def test_ff_fourth_block(self):self.assertIn('NAO_DOCUMENTADA',inspect_ff()['marco_400_escolha'])
 def test_amplifier_delta(self):self.assertEqual(inspect_ff()['item_candidato']['delta_FF_se_FOR_DES_ou_CON_ativado'],30)
 def test_jaku_only_lance(self):
  r=verify_event(sample('JAKU_LANCA_INTRINSECA',[3,6]));self.assertEqual(r['result']['dano_bruto_isolado'],11)
  self.assertEqual(r['components'][-1]['value'],2)
 def test_dragon_a_for_authorized(self):
  r=verify_event(sample('DRAGAO_A_ESMAGA_CRANIO',[2,3,4,5]));self.assertEqual(r['result']['dano_bruto_isolado'],50)
 def test_dragon_b_for_authorized(self):
  r=verify_event(sample('DRAGAO_B_ESMAGA_CRANIO',[2,3,4,5]));self.assertEqual(r['result']['dano_bruto_isolado'],74)
 def test_isolated_sources(self):
  a=verify_event(sample('DRAGAO_A_ESMAGA_CRANIO',[1]*4));b=verify_event(sample('DRAGAO_B_ESMAGA_CRANIO',[1]*4))
  self.assertNotEqual(a['fonte'],b['fonte']);self.assertNotEqual(a['result']['dano_bruto_isolado'],b['result']['dano_bruto_isolado'])
 def test_dragon_expected_mean_a(self): self.assertEqual(stats('DRAGAO_A_ESMAGA_CRANIO')['mean_fraction'],'50')
 def test_dragon_expected_mean_b(self): self.assertEqual(stats('DRAGAO_B_ESMAGA_CRANIO')['mean_fraction'],'74')
 def test_dragon_distribution(self): self.assertEqual(stats('DRAGAO_A_ESMAGA_CRANIO')['outcomes_equiprobable'],1296)
 def test_wrong_die_rejected(self):
  with self.assertRaises(ValueError):verify_event(sample('DRAGAO_A_ESMAGA_CRANIO',[2,3,4,7]))
 def test_wrong_dice_length_rejected(self):
  with self.assertRaises(ValueError):verify_event(sample('JAKU_LANCA_INTRINSECA',[2,3,4]))
 def test_extra_for_on_jaku_rejected(self):
  e=sample('JAKU_LANCA_INTRINSECA',[1,2]);e['FOR_bonus']=22
  with self.assertRaises(ValueError):verify_event(e)
 def test_gloves_unauthorized_rejected(self):
  e=sample('JAKU_LANCA_INTRINSECA',[1,2]);e['manoplas_ativas']=True
  with self.assertRaises(ValueError):verify_event(e)
 def test_strict_rejected(self):
  with self.assertRaises(ValueError):verify_event(sample('DRAGAO_A_ESMAGA_CRANIO',[1]*4,'STRICT'))
 def test_bleed_failure(self):
  e={'modo':'DOCUMENTAL','tipo':'ESTOCADA_CRUEL_TICK','instante':'INICIO_TURNO_DA_VITIMA','estado':'SANGRANDO','salvaguarda':'FALHA','dados':[4]}
  r=eval_bleed_tick(e);self.assertEqual(r['result']['dano_bruto_status'],4);self.assertEqual(r['result']['novo_estado'],'SANGRANDO');self.assertIsNone(r['result']['HP_depois'])
 def test_bleed_success(self):
  e={'modo':'DOCUMENTAL','tipo':'ESTOCADA_CRUEL_TICK','instante':'INICIO_TURNO_DA_VITIMA','estado':'SANGRANDO','salvaguarda':'SUCESSO','dados':[]}
  r=eval_bleed_tick(e);self.assertEqual(r['result']['dano_bruto_status'],0);self.assertEqual(r['result']['novo_estado'],'ESTABILIZADO')
 def test_bleed_early_rejected(self):
  e={'modo':'DOCUMENTAL','tipo':'ESTOCADA_CRUEL_TICK','instante':'IMPACTO','estado':'SANGRANDO','salvaguarda':'FALHA','dados':[4]}
  with self.assertRaises(ValueError):eval_bleed_tick(e)
 def test_bleed_dice_without_fail_rejected(self):
  e={'modo':'DOCUMENTAL','tipo':'ESTOCADA_CRUEL_TICK','instante':'INICIO_TURNO_DA_VITIMA','estado':'SANGRANDO','salvaguarda':'SUCESSO','dados':[4]}
  with self.assertRaises(ValueError):eval_bleed_tick(e)
 def test_no_hp_or_strict(self):
  r=verify_event(sample('DRAGAO_B_ESMAGA_CRANIO',[2,3,4,5]));self.assertIsNone(r['result']['HP_depois']);self.assertEqual(r['STRICT'],'DENY')
 def test_negative_synthetic_ca_write_rejected(self):
  e=sample('DRAGAO_A_ESMAGA_CRANIO',[1,1,1,1]);e['CA_APLICAVEL']=44.6
  with self.assertRaises(ValueError):verify_event(e)
 def test_receipt_deterministic(self):
  a=verify_event(sample('DRAGAO_A_ESMAGA_CRANIO',[1,2,3,4]));b=verify_event(sample('DRAGAO_A_ESMAGA_CRANIO',[1,2,3,4]));self.assertEqual(a['hash_conteudo'],b['hash_conteudo'])
if __name__=='__main__':unittest.main(verbosity=2)
