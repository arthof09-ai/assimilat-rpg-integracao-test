# Uso pelo ChatGPT no celular — Mestre-side

**Nenhum computador ou navegador local é necessário ao Mestre.** O Comestre executou o verificador e entregou recibos prontos nesta conversa. O arquivo de código serve para reexecução pelo próprio Comestre quando estiver disponível no ambiente de ferramentas.

Para novas análises, peça em português, por exemplo:

- "Calcule em sandbox o Esmaga Crânio da Fonte A com 4d6: 2,3,4,5."
- "Calcule a lança intrínseca de Jaku com 2d8: 3,6."
- "Teste o início do turno da vítima sangrando, CON CD17 falhou, d6=4."

O Comestre deverá sempre verificar a fonte/variante e rejeitar STRICT, combinação de HP, manoplas ou FOR não comprovado.

Para reexecutar em um ambiente de Python disponível ao Comestre:
`python verificador_r28.py --input entrada.json`
`python verificador_r28.py --stats DRAGAO_A_ESMAGA_CRANIO`
`python -m unittest -v testes_r28.py`

Entradas modelo em examples.json, recibos completos em recibos/*.json. Nenhum código toca Notion nem ficha real.
