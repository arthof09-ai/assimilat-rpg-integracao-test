#!/usr/bin/env python3
# OP-DMG-CORPUS-EMP-01 / R28 sandbox scientist Mestre-only
# No external I/O, writer, database, Notion, combat engine, or official state.
import argparse
import hashlib
import json
from itertools import product
from collections import Counter
from fractions import Fraction
from pathlib import Path

SOURCES = {
  'JAKU_SHEET': 'https://app.notion.com/p/07dc2b324ede82aeb27501f9414bfc81',
  'DRAGON_EVENT': 'https://app.notion.com/p/4fac2b324ede824da70d0189f19533de',
  'DRAGON_BESTIARY': 'https://app.notion.com/p/2bfc2b324ede82699fbf0187858cf72d',
  'EVENT_ROOT': 'https://app.notion.com/p/132c2b324ede83128e248190ca5ff975',
  'EVENT_BESTAS': 'https://app.notion.com/p/c1fc2b324ede821d9d16010613958fde',
  'FF_CURRENT': 'https://app.notion.com/p/3ebc2b324ede81449222f3c06b840613',
  'FF_HISTORICAL': 'https://app.notion.com/p/52ec2b324ede829fbfd881f261df8d0e',
  'DMG_RANK': 'https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e',
  'COMBAT': 'https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0',
}
REGISTRY = {
 'JAKU_LANCA_INTRINSECA': {
  'variant':'JAKU_P3_2026-09-30', 'source':'JAKU_SHEET',
  'literal':'2d8+2', 'dice_count':2,'die_sides':8,'constant':2,
  'component_ids':['JAKU_LANCE_BASE'], 'attribute_authorized':False,
  'meaning':'Somente dano intrinsicamente descrito na lança; sem infusão, manoplas, FF, buffs ou rider posterior'
 },
 'DRAGAO_A_ESMAGA_CRANIO': {
  'variant':'DRAGON_A_POSSIVE_EVENT_OURO1_CA39_LITERAL', 'source':'DRAGON_EVENT',
  'literal':'4d6 + For','dice_count':4,'die_sides':6,'constant':36,
  'component_ids':['DRAGON_A_ESMAGA_4D6','DRAGON_A_FOR36'], 'attribute_authorized':True,
  'meaning':'Dano documentado da habilidade do Dragão A, não resultado histórico de ataque'
 },
 'DRAGAO_B_ESMAGA_CRANIO': {
  'variant':'DRAGON_B_BESTIARY_BODY_OURO3_TITLE_OURO1_CA68', 'source':'DRAGON_BESTIARY',
  'literal':'4d6 + For','dice_count':4,'die_sides':6,'constant':60,
  'component_ids':['DRAGON_B_ESMAGA_4D6','DRAGON_B_FOR60'], 'attribute_authorized':True,
  'meaning':'Dano documentado da habilidade do Dragão B, rank de título e corpo divergentes'
 }
}
EXCLUDED = [
 'JAKU_FOR22_NO_DAMAGE_PERMISSION', 'JAKU_FF_4TH_MILESTONE_UNKNOWN',
 'JAKU_INFUSION_TAG_UNRESOLVED','JAKU_GLOVES_BONUS_ACTION_UNMAPPED',
 'JAKU_ESTOCADA_NOT_ON_HIT','DRAGON_GLACIAL_PLUS10_HABITAT_NOT_VERIFIED',
 'DRAGON_RD_ORDER_UNKNOWN', 'CA_EPOCH_NOT_SETTLED'
]

def sha(o):
 return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def require(p, description):
 if not p: raise ValueError(description)

def inspect_ff():
 ff_calculated=(22+13+7)*10
 return {
  'tipo':'CONTROLE_FF_JAKU_SNAPSHOT', 'fonte_atributos':SOURCES['JAKU_SHEET'],
  'fonte_regra_atual':SOURCES['FF_CURRENT'],
  'fonte_versao_antiga':SOURCES['FF_HISTORICAL'],
  'atributos_impressos':{'FOR':22,'DES':13,'CON':7},
  'FF_impresso':390,'FF_formula_atual':ff_calculated, 'diferenca_FF':ff_calculated-390,
  'marcos_por_FF_impressa':[100,200,300],
  'marcos_pela_formula_atual':[100,200,300,400],
  'resultados_registrados_dano':[2,2,1], 'total_FF_dano_registrado':5,
  'marco_400_escolha':'NAO_DOCUMENTADA_NAO_ROLAR',
  'item_candidato':{'literal':'+3 em um Atributo. 15 PA por dia.',
                    'delta_FF_se_FOR_DES_ou_CON_ativado':30,
                    'atributo_selecionado':'PENDENTE', 'ativacao':'PENDENTE',
                    'incorporacao_na_ficha':'PENDENTE'},
  'causa_historica_diferenca':'NAO_COMPROVADA',
  'regra_anterior_contem_formula_FF':'NAO_IDENTIFICADA',
  'restricao':'Proibido conceder marco_400 sem recibo original de escolha e resultado'
 }

def verify_event(event):
 require(isinstance(event,dict),'Evento deve ser objeto JSON')
 require(event.get('modo')=='DOCUMENTAL','Somente modo DOCUMENTAL: STRICT e HIPOTETICO indisponíveis nesta prova')
 require(event.get('tipo')=='DANO_ISOLADO','Somente DANO_ISOLADO; não aceita hit/HP/RD/recursos/combate')
 require(set(event)=={'modo','tipo','caso','dados'},'Campo inesperado ou obrigatório ausente')
 case_id=event['caso']
 require(case_id in REGISTRY,'Caso desconhecido; não cruzar variantes')
 case=REGISTRY[case_id]
 rolls=event['dados']
 require(isinstance(rolls,list) and len(rolls)==case['dice_count'], 'Quantidade de dados diferente da fonte')
 require(all(type(v) is int and 1<=v<=case['die_sides'] for v in rolls), 'Dados inválidos para a expressão da fonte')
 raw=sum(rolls)+case['constant']
 receipt={
  'contrato':'CM000001-OP-DMG-R28-SANDBOX-DAMAGE-ONLY',
  'estado':'DOCUMENTAL_EXPERIMENTAL_SEM_COMBATE',
  'STRICT':'DENY','write':'DENY', 'historic_combat':False,
  'input':event,'fonte':SOURCES[case['source']], 'fonte_ultima_edicao':
     '2026-09-30T04:36:35.745Z' if case_id.startswith('JAKU') else
     '2026-09-30T04:43:29.920Z' if case_id.startswith('DRAGAO_A') else '2026-10-01T18:00:42.609Z',
  'variante':case['variant'], 'literal':case['literal'],
  'components':[{'id':case['component_ids'][0],'value':sum(rolls),'kind':'dice'},
                {'id':case['component_ids'][-1],'value':case['constant'],'kind':'constant'}],
  'result':{'dano_bruto_isolado':raw,'dano_liquido':None,'HP_depois':None,
            'mitigacao':None,'hit':None,'critico':None},
  'excluidos':EXCLUDED, 'observacao':case['meaning']}
 receipt['hash_conteudo']=sha(receipt)
 return receipt

def eval_bleed_tick(event):
 require(isinstance(event,dict),'Objeto JSON obrigatório')
 require(event.get('modo')=='DOCUMENTAL','Proibido outro modo')
 require(event.get('tipo')=='ESTOCADA_CRUEL_TICK','Contrato restrito ao tick documentado')
 require(set(event)=={'modo','tipo','instante','estado','salvaguarda','dados'},'Campo inesperado ou ausente')
 require(event['instante']=='INICIO_TURNO_DA_VITIMA','Tick só no início do turno do alvo')
 require(event['estado']=='SANGRANDO','Não avaliar tick com condição não comprovada')
 require(event['salvaguarda'] in ('SUCESSO','FALHA'),'Salvar resultado externo; não criar dados de CON')
 die=event['dados']
 if event['salvaguarda']=='SUCESSO':
  require(die==[],'Sucesso estabiliza sem rolagem de dano')
  dano=0; new='ESTABILIZADO'
 else:
  require(isinstance(die,list) and len(die)==1 and type(die[0])==int and 1<=die[0]<=6,'Falha exige 1d6 válido')
  dano=die[0];new='SANGRANDO'
 receipt={
 'contrato':'CM000001-OP-DMG-R28-ESTOCADA-TICK-ONLY','estado':'DOCUMENTAL_EXPERIMENTAL',
 'STRICT':'DENY', 'write':'DENY', 'historic_combat':False,
 'input':event,'fonte':SOURCES['JAKU_SHEET'],
 'literais':['no início de cada turno','CON CD 17','sucesso estabiliza','falha 1d6 e continua sangrando'],
 'result':{'dano_bruto_status':dano,'novo_estado':new,'HP_depois':None,'dano_impacto':None},
 'restricoes':['Salvaguarda entra como veredicto externo','Não inventa dados de CON','Não calcula mitigação nem altera HP','Não incorpora 1d6 no dano imediato da lança']
 }
 receipt['hash_conteudo']=sha(receipt)
 return receipt

def stats(case_id):
 require(case_id in REGISTRY,'Caso inválido')
 c=REGISTRY[case_id]
 scores=Counter(sum(comb)+c['constant'] for comb in product(range(1,c['die_sides']+1),repeat=c['dice_count']))
 n=sum(scores.values())
 avg=Fraction(sum(k*v for k,v in scores.items()),n)
 result={'case':case_id,'source':SOURCES[c['source']],'literal':c['literal'],
         'min':min(scores),'max':max(scores),'mean_fraction':str(avg),
         'mean':float(avg),'outcomes_equiprobable':n, 'distribution':dict(sorted(scores.items()))}
 result['hash_conteudo']=sha(result)
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser(description='Verificador DMG R28 sem execução canônica')
 p.add_argument('--input',help='Arquivo JSON com evento documental; omitindo, resume FF')
 p.add_argument('--stats',choices=list(REGISTRY),help='Distribuição exata, sem combate')
 a=p.parse_args()
 if a.stats: out=stats(a.stats)
 elif a.input:
  event=json.loads(Path(a.input).read_text(encoding='utf-8'))
  out=eval_bleed_tick(event) if event.get('tipo')=='ESTOCADA_CRUEL_TICK' else verify_event(event)
 else:out=inspect_ff()
 print(json.dumps(out,indent=2,ensure_ascii=False,sort_keys=True))
