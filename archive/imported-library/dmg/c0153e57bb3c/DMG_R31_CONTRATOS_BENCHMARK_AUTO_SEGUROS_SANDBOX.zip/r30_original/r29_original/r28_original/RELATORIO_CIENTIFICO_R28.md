# DMG R28 — Reconciliacao de FF, autoridade temporal e prova mecanica independente

**Operação existente:** OP-DMG-CORPUS-EMP-01. **Identidade logica:** CM-000001. **Superficie:** MESTRE-ONLY. **Natureza:** execução documental+sandbox, sem nova instância reivindicada e sem escrita Notion. **Data de recuperação:** 2026-10-14.

## 0. Recuperacao antes de executar

- ZIP pai R27 `DMG_R27_PROVENIENCIA_JAKU_DRAGAO_EXPERIMENTAL.zip` SHA-256 fisicamente recalculado `b1fe89d8b5560779ec19ac7a5b16fa056eaa75d6633d61c786974c7c9fcbb096`, igual ao esperado. 14 membros, ZIP CRC PASS, 13 itens de manifesto validos (0 falhas). Copia byte-identica incluida em `historico/`, somente-leitura.
- R26 `DMG-F1-R26-NORMATIVA-INTEGRACAO-JAKU-v02.zip` localizado no catalogo anterior; SHA-256 esperado/historico `30884db099db7267665ffea5732fef8113f55551426edad52f47289b61954964`; **bytes ainda nao recuperados e SHA NAO recalculado** nesta instancia. Cadeia R01–R26 nao reconstruida ou alterada.
- Checagem dirigida no Notion (OP e Inbox) e na superficie acessivel nao mostrou checkpoint R28 oficial posterior. Negativa limitada ao escopo consultado, nao prova ausencia universal.
- IBX-90 fisicamente consultada como linha `INBOX-ID=90` via tabela unica Notion em 14/10/2026: estado `NOVA`, destinatario CM-000006, `Lida por INSTANCE-ID = NULL`, ultima edição 13/10/2026 13:43:08Z. Query textual por Jaku/DMG R26 devolveu apenas a propria IBX-90. ACK/parecer autentico nao encontrado neste escopo; nenhuma nova Inbox foi criada.

## 1. FONTES, recortes e periodo

|Ref.|Local e fonte|Fato literal|Ultima edicao observada|Tipo|
|---|---|---|---|---|
|JAKU|[Ficha Mestre Jaku](https://app.notion.com/p/07dc2b324ede82aeb27501f9414bfc81)|FOR22 DES13 CON7; FF390; tres bonus FF +2+2+1; lança 2d8+2; Estocada Cruel 1d6 apos falha de CON no inicio do turno; item +3 atributo|30/09/2026|Ficha Mestre|
|CR-FICHA|[Criação de Ficha atual](https://app.notion.com/p/3ebc2b324ede81449222f3c06b840613)|FF=(FOR+DES+CON)x10; 1 marco/100 FF; cada marco escolhe dano +1d4, CA +1d4 ou Vida +2d6; resultado e escolha travados|09/10/2026|Regra atual|
|CR-ANTIGA|[Criação de Ficha histórica](https://app.notion.com/p/52ec2b324ede829fbfd881f261df8d0e)|Texto historico reaberto: nao foi encontrada formula FF explicita nessa versao|30/09/2026|Historico, nao canon vigente|
|DMG|[DMG-RANK-01](https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e)|Atributo so acrescenta dano quando outra regra autorizar. Componente original nao duplica bonus externo.|08/10/2026|Especializada|
|DRAGON-A|[Dragão Gelo Azul A](https://app.notion.com/p/4fac2b324ede824da70d0189f19533de)|Ouro 1, FOR36, DES28, CON33, CA39; Esmaga Crânio `4d6 + For`|30/09/2026|Entrada de evento possivel|
|EVENTO|[Possíveis Eventos](https://app.notion.com/p/132c2b324ede83128e248190ca5ff975) → [Bestas](https://app.notion.com/p/c1fc2b324ede821d9d16010613958fde)|Guerra de Territorio: dois monstros disputam liderança. Pagina filhas Fera Glacial, Sussurro Celestial e Dragão Gelo Azul A.|30/09 a 03/10/2026|Semente de evento, não combate|
|DRAGON-B|[Dragão Gelo Azul B](https://app.notion.com/p/2bfc2b324ede82699fbf0187858cf72d)|Página intitulada `Ouro 1`, corpo classifica Ouro 3; FOR60 DES50 CON38, CA68; Esmaga Crânio `4d6 + For`|01/10/2026|Bestiario alternativo|
|BEAST|[Criação de Besta](https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd) e [antiga](https://app.notion.com/p/e22c2b324ede836cb582819ac2ad27c5)|CA normal=10+DES+CON/5; Titã=20+DES+CON/5, nas duas versões|07/10 e 30/09|Regra/historico|

Estas datas são de **última edição**, não comprovam vigência exata em combate nem quando as escolhas foram feitas.

## 2. P0 — FF 390 vs 420: veredito de autoridade

- LITERAL da ficha Jaku: FF `390`; três resultados escritos de dano `+2`, `+2`, `+1`, soma `+5`.
- RECÁLCULO pela regra vigente: `(22+13+7)*10=420`, uma diferença de `+30` FF, exatamente três pontos de algum atributo físico.
- ESTADO FF390 implica 3 marcos possiveis (100,200,300). Os três resultados registrados são coerentes numericamente com 3 marcos, mas a ficha **não etiqueta qual resultado pertence a qual ID de marco**; não criar correspondencia falsa por ordem.
- ESTADO FF420 implica 4 marcos possiveis (100,200,300,400); **escolha e valor do marco 400 nao encontrados**. Pode ter sido alocado a outro eixo; nenhuma escolha pode ser presumida, rerrolada ou transferida.
- Fonte candidata **VERIFICADA COMO EXISTENTE**: na mochila da ficha Jaku, `Amplificador de Atributo +3 em um Atributo. 15 PA por dia.` Se os atributos atuais incorporarem +3 em FOR, DES ou CON, o valor sem esse aumento seria 39 pontos físicos e geraria FF390; atribuir a diferença ao item seria, porém, **INFERÊNCIA**, pois nao há atributo escolhido, ativacao, PA, instante ou prova de que a ficha imprimiu atributos ja modificados. Se o item afetar atributo mental, delta FF=0.
- Os dois blocos da mesma página, P3 normal e P3 Transformação Espiritual, **repetem FF390 e os mesmos atributos**; nao são snapshots independentes em épocas distintas.
- `Criação de Ficha — Versão Antiga` foi reaberta; a formula explicita atual nao foi localizada na antiga; logo NAO existe prova nessa versao de que 390 derive de regra anterior. O modelo atual de locks pode ter sido consolidado depois da ultima edicao da ficha; nao afirmar retroatividade.

**Resultado P0:** O trio FF390 + 3 linhas +5 é coerente internamente. O trio (atributos impressos + FF390 + fórmula atual) é incompatível sem fator temporal/modificador. A única fonte de modificador `+3` reaberta na própria ficha fornece candidato exato, nao causalidade demonstrada. Ficha original permanece intacta e quarto marco em HOLD.

## 3. P1 — dano por parcelas e instantes

|Instante|Componente|Fonte e literal|Estado mecanico|
|---|---|---|---|
|T0, configuração da ficha|FF `+2 +2 +1`|Jaku → FF|Resultados escritos; marcos sem ID individual e estado de cena ausente|
|T1, ataque fisico se acertar|Lança `2d8+2`|Jaku → Lança|Dano intrínseco VERIFICADO, independente de manopla|
|T1, somente se infusão legal|`+2d8+2 espiritual flamejante`|Jaku → Infusão|Fonte existe; tag, ativação e simultaneidade ausentes|
|T1, somente se chamas legalmente ativas|`+1d8+2 Fogo`|Jaku → Manoplas|Expressão existe, mas ação bônus do item segue nao homologada|
|T1, somente se FF ativa nesse estado|`+5`|Jaku → FF|Registrado em FF390; recibo ativo no instante ainda ausente|
|T1, bônus de FOR|`+22`|Jaku → Atributos|FOR existe; arma nao declara FOR ao dano. DMG §8/15 exige cláusula expressa; NAO autorizar na lança por analogia|
|T1, se Investida Sanguinária em efeito|`+4` e `+1 ataque`|Jaku → habilidade, 5 PA, livre, duracao1d4+1|Ativacao e validade na cena nao verificadas; nao adicionar aos +33|
|T2, inicio de cada turno da vitima sangrando|`1d6`, teste CON CD17 falho|Jaku → Estocada Cruel|Rider posterior; sucesso estabiliza sem tick; NUNCA fonte de 1d6 automatico em T1|

`2d8+2 + 2d8+2 + 1d8+2 = 5d8+6` apenas se as 3 fontes efetivamente coexistirem. Impresso `5d8+1d6+33` tem residual algébrico `1d6+27`. Correspondencia de numeros `FOR22+FF5 =27` NAO certifica `+FOR` nem empilhamento. `1d6` de sangramento pertence a outro instante (T2); sua presença na fórmula da ficha pode ser um atalho misto legado, hipótese nao confirmada.

**Prova mecânica comparativa NOVA:** o próprio Dragão A/B escreve em **Esmaga Crânio** `4d6 + For`. Nesse caso há autorização explícita e a regra DMG-RANK permite somar FOR36 (A) ou FOR60 (B). Em Jaku a descrição da lança diz `2d8+2`, não `+FOR`; portanto a mesma operação NAO é autorizada. Nao se importou regra de D&D ou analogia entre criaturas.

Chassi genérico da arma comum no DMG-RANK **não soma outro 1d6** à lança, porque a lança já tem dano explícito específico e não existe norma de duplicação do chassi.

## 4. P2 — Dragão: variante por função de fonte, nao por palpite temporal

A cadeia física da **Fonte A** é Região 02 → Possíveis Eventos → Guerra de Território → Bestas → Dragão Gelo Azul. O evento descreve monstros disputando o domínio e lista também Fera Glacial e Sussurro Celestial. Isso prova que A está ASSOCIADA AO PLANEJAMENTO DO EVENTO, mas nao que um combate ocorreu ou que o Dragão lutou. Jaku nao aparece como participante nesse registro.

**Fonte A:** Ouro 1, FOR36, DES28, CON33, CA impressa 39. A fórmula normal produz `44,6`; a fórmula Titã comparadora `54,6`, sem status Titã provado. Para reproduzir documento de Guerra de Território a CA literal é 39, **sem certificar a sua correção normativa**.

**Fonte B:** título da página Ouro 1, conteúdo classifica Ouro 3, FOR60, DES50, CON38, CA impressa 68. Fórmula normal = `67,6`; eventual arredondamento 67,6→68 é hipótese de origem, não regra geral encontrada. CA Titã hipotética 77,6, sem prova da caracteristica. Dados de B **não corrigem** nem substituem A.

Ambas as fichas usam o mesmo nome de espécie e habilidades, mas não contêm `creature_id`, datas de nivel, vínculos de evolução ou recibos de sessão que estabeleçam identidade pessoal ou temporal. Nao foi encontrado registro de execução do encontro em pesquisa dirigida no catálogo de eventos e nos resumos de sessões 20/21 consultados. Cobertura de sessões 100% NAO DETERMINAVEL.

## 5. Contrato científico executado nesta R28 (em vez de mais um painel)

`verificador_r28.py` tem **somente três ações de dano isolado com fonte verificável**:
- `JAKU_LANCA_INTRINSECA = 2d8+2` com amostra **fictícia** `[3,6] → 11` dano bruto da lança. Não soma FF, FOR, infusão ou manoplas.
- `DRAGAO_A_ESMAGA_CRANIO = 4d6+FOR36` com amostra **fictícia** `[2,3,4,5] → 50` dano bruto isolado. Distribuição exata de 1296 quadras: min40, max60, média50.
- `DRAGAO_B_ESMAGA_CRANIO = 4d6+FOR60` com MESMOS dados **fictícios** `[2,3,4,5] → 74` bruto isolado. Distribuição: min64, max84, média74.

Contrato adicional de **efeito temporal, sem HP**: `ESTOCADA_CRUEL_TICK` apenas no INÍCIO DO TURNO DA VÍTIMA, com estado SANGRANDO e veredicto externo do teste CON CD17. `FALHA` e 1d6 fixture `[4]` → 4 dano bruto de status, permanece sangrando. `SUCESSO` → 0 dano e ESTABILIZADO. Sem teste CON artificial nem evento histórico.

Todos os recibos têm entrada integral, URL da fonte, expressão original, componentes, resultado, hash de conteúdo e `STRICT=DENY`. API proíbe soma de FOR na lança de Jaku, habilitar manoplas, enviar CA arbitrária, dados inválidos, campos novos, HP após e STRICT. **Executar cálculo de componente não significa acertar ataque, causar perda efetiva de Vida ou combate.**

## 6. B01–B18: ganho restrito, sem promoção

- **B05 ACTION_INVENTORY**: ganhamos evidência literal nova de ação `Esmaga Crânio 4d6+FOR` para as duas fichas de Besta, integrando catálogo PARCIAL de ações com fonte e variante. Menu completo legal de Jaku/Dragão e recursos/cenas continuam faltando; **B05 PARTIAL→PARTIAL**.
- **B08 HIT_FORMULA_AND_SKILLS**: vinculo fisico Fonte A→Guerra de Território permite identificar CA literal39 da ficha de preparação; o valor normativo 44,6 permanece em conflito e nao houve dado de hit real; **B08 PARTIAL→PARTIAL**.
- **B12 STATUS_DURATION_DOT**: contrato de tick da Estocada Cruel separa inicio do turno, veredicto CON e estado em recibo. Isso NÃO resolve B12 original veneno de Serpente, nem duração/remoção normativa; **B12 PARTIAL→PARTIAL**.
- Demais 15 critérios sem evidência terminal nova. **Certificados B02 1/18→1/18 (5,56%)**, 9 PARTIAL, 6 BLOCKED, 2 NOT_TESTED.
- STRICT 0/2; CSV originais I0003 0/9; 5 decisões B11/B12 0/5; DEC-BONUS-JAKU-01 e DEC-INFUSION-JAKU-01 pendentes. DMG-RANK oficial e todas as fichas NÃO alterados.

## 7. Decisões competentes vs fato pendente

**Documental a recuperar antes de pedir regra nova:** (i) momento e atributo do Amplificador +3, se realmente foi usado; (ii) estado histórico dos atributos e dos locks FF100/200/300/400, sem reroll; (iii) roll/ledger do encontro e criatura, se ocorreu; (iv) instante de uso de manoplas, lança, infusão e sangramento; (v) catalogo das ações legais completas para B05; (vi) descrição de dano de Jaku que autorize FOR (não encontrada).

**Normativo:** se a regra de atribuição de FOR à lança não estiver em nenhuma fonte vigente, **não presumir**; se Mestre criar exceção, é NOVA REGRA, sob NAC-NORM-01, não um esclarecimento automático. CA 39 vs 44,6 só entra em cena real depois de documentar epoch e regra aplicável, ou deliberar explicitamente a exceção/correção. Se quatro marcos forem mesmo validos e não houver registro do quarto, nova escolha histórica requer procedimento competente, nunca sorteio automático.

**Reservado:** DEC-B11-A/B/C, DEC-B12-A/B, DEC-BONUS-JAKU-01, DEC-INFUSION-JAKU-01, todos sem aprovação. Nenhuma nova decisão criada nesta rodada.

## 8. Gate de retorno e PSV

R27 pai byte-verificado; R26 pai remoto hash legado NÃO VERIFICADO local; identidade de instância não reivindicada; escritor/lease/epoch/fencing/GREEN H O L D. IBX-90 NOVA sem ACK próprio. Nenhum Notion, Party, O Primeiro ou DMG-RANK modificado. 26/26 testes automáticos do contrato sandbox passaram, incluindo negativas anti-duplicação/STRICT e teste hash do R27; isso **não** é UAT humana, certificação B05 ou execução STRICT.

**Ponto de retomada:** obter evidência do Amplificador/atributos ou registro de marcos historicos de Jaku; conciliar regra de dano/epoch com as únicas cenas fisicamente encontradas. Em paralelo, expandir o catálogo B05 utilizando **Esmaga Crânio A/B** com fuente clara; priorizar ação com rota comprovada e só depois preflight VLAB pela IBX90 existente. Conteúdo científico desta rodada não foi escrito no Notion por ausência de writer comprovado.

**NAC-PASS terminal: HOLD.**
