import json
from pathlib import Path
from verificador_r28 import inspect_ff,verify_event,eval_bleed_tick,stats
root=Path(__file__).parent
examples=json.loads((root/'examples.json').read_text())
for name,e in examples.items():
 out=eval_bleed_tick(e) if e['tipo']=='ESTOCADA_CRUEL_TICK' else verify_event(e)
 (root/'recibos'/f'{name}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
(root/'recibos'/'jaku_FF_390_420.json').write_text(json.dumps(inspect_ff(),indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
for k in ['DRAGAO_A_ESMAGA_CRANIO','DRAGAO_B_ESMAGA_CRANIO','JAKU_LANCA_INTRINSECA']:
 (root/'recibos'/('distribuicao_'+k+'.json')).write_text(json.dumps(stats(k),indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
print('Recibos:',len(list((root/'recibos').glob('*.json'))))
for p in sorted((root/'recibos').glob('*.json')):
 d=json.loads(p.read_text());print(p.name,(d.get('result') or {}).get('dano_bruto_isolado') or (d.get('result') or {}).get('dano_bruto_status'), d.get('hash_conteudo',''))
