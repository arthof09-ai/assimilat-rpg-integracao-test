# DMG R29 — Corpus de ações operável pelo Comestre (MESTRE-SIDE)

**Operação pré-existente:** `OP-DMG-CORPUS-EMP-01` · **Identidade lógica:** `CM-000001` · **Natureza:** sandbox documental, não canônico, sem reivindicar INSTANCE-ID, writer, gateway, lease, epoch, fencing, GREEN, NAC-PASS produtivo ou ACK do VLAB.

## 0. Recuperação / integridade e checkpoint

- Pacote pai **R28** fisicamente recuperado da Biblioteca e revalidado por bytes: `DMG_R28_RECONCILIACAO_MECANICA_SANDBOX.zip` SHA-256 `85c4c9f2f62d1da5ca0661811e1ca0bc1d6003bd5bfb9b89db8ed054ea5d95f0`, CRC ZIP PASS, `MANIFEST_SHA256` original revalidado integralmente.
- Cópia R28 incluída integralmente e **byte idêntica** em `historico/DMG_R28_ORIGINAL_READONLY.zip`. R28 contém uma cópia R27 original, cujo SHA é `b1fe89d8b5560779ec19ac7a5b16fa056eaa75d6633d61c786974c7c9fcbb096`; integridade nested igualmente preservada.
- R26 original `DMG-F1-R26-NORMATIVA-INTEGRACAO-JAKU-v02.zip`, hash histórico esperado `30884db099db7267665ffea5732fef8113f55551426edad52f47289b61954964`: catalogado, bytes não recuperados nesta etapa; NÃO reivindicar verificação binária, inclusão no ZIP R29 ou preservação interna verificável de todos os pacotes R01–R26.
- Não se identificou um checkpoint científico DMG R29/R30 posterior nas buscas dirigidas do Notion da OP/Inbox e no catálogo recente da Biblioteca; negativa limitada às superfícies consultadas, não um censo global.
- IBX-90 confirmada por consulta estruturada à única Inbox: `NOVA`, CM-000006, sem `Lida por INSTANCE-ID` (NULL), última edição 13/10/2026 13:43:08Z. Nenhum ACK comprovado nem nova Inbox criada.

## 1. B05 — requisito original recuperado (não afrouxado)

Fontes de definição preservadas: R11 `DMG-F1-R11-MATRIZ-B01-B18-v01.json` e R26 `R26_B01_B18_MATRIX.csv`.

- **ID/nome:** B05 / `ACTION_INVENTORY` — *complete legal actor action inventory*.
- **Original:** `Complete legal action loadouts and owned abilities for all actors not adjudicated`.
- **Teste de aceite original:** `Compiler emits allowed/rejected action with explicit per-field provenance and atomic effect plan`.
- **Lacuna terminal confirmada na R26:** `Compile each actor action in chosen form into complete provenance-linked legal menu and obtain reader acceptance`.
- **Dependência de prova:** estado selecionado da cena, fonte vigente/imutável, formulário, equipamento, passivas, alcance/alvo, economia, custos e recursos, prioridade e reação quando aplicável, componentes por tipo, efeitos posteriores, planos atômicos e aceite legítimo do receptor. Um lote de fórmulas matemáticas não satisfaz sozinho o gate.
- **Estado oficial:** PARTIAL. Nenhum novo PASS científico. Não são 43/43 ações legais do universo; são 43 candidatas descobertas em cinco páginas físicas e seis perfis de fonte.

### Inventário dirigido ao par original, expandido sem duplicar B01–B18

`INVENTARIO_B05_R29.json` e `.csv` enumeram **43 candidatos identificados**, com identificador estável por perfil+ação, tipo, texto-fonte, URL, última edição, janela/custo documentado, condições, campos bloqueantes e contrato isolado quando existir.

| Perfil da fonte | Entradas localizadas | Relevância |
|---|---:|---|
| Macaco Rei Prata 5 (Titã, página-fonte) | 6 | Ator do corpus original; passiva +2 FOR não automaticamente adicionada a FOR54 |
| Liu Xiaua normal P5 | 16 | Ator do corpus original; crítico, FF, equipamento, infusão e ações com economia conflitante separados |
| Liu Xiaua transformada P5 | 4 | Forma não ativada na cena; não herda automaticamente permissões ativas |
| Jaku Nadta P3 | 9 | Somente componente intrínseco e tick já fechados documentalmente |
| Dragão A Ouro 1 | 4 | Variante do possível evento territorial, não evento executado |
| Dragão B Bestiário | 4 | Conflito título Ouro1 / corpo Ouro3 preservado |
| **Recorte recuperado** | **43** | **Não equivale ao denominador terminal de B05** |

**Causa de PARTIAL:** o recorte original Liu × Macaco não possui estado de cenário/forma assinado, inventário ativo legal completo, PA Livre/cargas, ocupação/alcance, integração de action compiler nativo nem readback/aceite independente. Por exemplo, `Manipulação Mágica` não enumera feitiços/custos; `Poder elemental` do Macaco tem dano e 10 PA, porém não designa elemento, tipo de defesa ou classe de ação; `Fúria` de Liu depende de HP e PA; `Decepadora`, `Crítico Brutal` e equipamento exigem decisões B11. Mapear componentes não inventa essas lacunas.

### Campos com autoridade e lacunas

| Campo B05 | Comprovável neste recorte | Lacuna terminal para combate real |
|---|---|---|
| Identidade/versão | URLs das 5 páginas, última edição, formas documentais | `effective_at`, scene-ID, identidade contemporânea do evento e eventual evolução |
| Ações e descrições | 43 candidatos, incluindo passivas/equipamentos; 10 contratos isolados | Demonstração de enumeração completa de ações legalmente disponíveis por ator |
| Economia | Ataque normal = ação padrão na regra geral; textos específicos quando declarados | `ação bônus` sem equivalência, ativação/reação/ordem de evento, ação especial |
| Custos | Macaco Poder elemental 10 PA; Liu Fúria12/Extensão30 e itens; alguns itens com PA/dia | Ledger PA Livre, cobrança, usos/dia restantes, custos não declarados |
| Dano/tipos | Patada impacto, Mordida perfurante; Infusão Elétrica textualmente elétrica | Habilidade elemental do Macaco sem tag, ordem RD/RDF, stacking e buffs históricos |
| Condições/tempo | Sangramento no começo do turno com CON CD17; Fúria requer metade Vida | Ativação, duração, expiração, status e salvaguardas de cena com readback |
| Efeito atômico | Compilador novo emite PLANO DICE_ONLY + DENY FULL_ACTION | Aceite real do receptor, snapshot estado, eventos de hit/HP, replay oficial |

## 2. Capacidade funcional entregue

**`verificador_r29.py`** importa **o código R28 sem modificar** e usa seu resolvedor fonte-gated para `Esmaga Crânio` A/B, `Lança` e `Estocada Cruel`. Adiciona seis novos componentes isolados de Macaco e Liu, sem inventar golpe novo:

| Caso | Literal / cálculo documental permitido | Escopo NÃO autorizado |
|---|---|---|
| `MACACO_PATADA` | `2d6 + FOR54`, impacto | Não somar `Força Titânica +2`; sem hit/custos/HP |
| `MACACO_MORDIDA` | `1d6 + FOR54`, perfurante | Mesmo bloqueio da passiva/scene |
| `MACACO_PODER_ELEMENTAL_BASE` | `1d10 + INT30`, custo literal 10 PA | **Não** atribuir Gelo pelo emoji pai; sem pagamento PA ou classe de magia |
| `LIU_MACHADO_BASE` | `5d12`, dano intrínseco da arma | Sem `+FOR`, FF, infusão ou bônus não combinados |
| `LIU_MACHADO_CRUEL_CERTEIRA_PARCELA` | `+2` dano comprovado do modificador | **Parcela isolada**, não golpe autônomo; não contar duas vezes no atalho impresso |
| `LIU_MACHADO_INFUSAO_ELETRICA_PARCELA` | `3d8+6` adicional elétrico textual | Parcela isolada; sem declarar item ativo, PA pago, alvo fraco ou equivalência automática com Raio |

O status `ALLOW_DOCUMENTAL_COMPONENT_ONLY` **não declara ação legal numa cena**. Em todos os dez contratos (três fontes prévias + seis fontes novas + tick), o compilador fornece preflight `combat_decision=DENY_UNFROZEN_SCENE`, URL original, atributos literais, modificadores permitidos, janela, custo textual, lacunas, exclusões e plano atômico de **cálculo isolado**, sem mutação da Vida/PA.

**Segurança e temporalidade:** entrada sem dados fica `HOLD_MISSING_INPUT`, nunca gera rolagem silenciosa. Campos extras que tentem adicionar FOR22 de Jaku, passiva não adjudicada, Gelo ao Macaco, consumo PA/HP ou ativação STRICT ficam `REJECTED_SOURCE_OR_POLICY`. Tick de sangramento não é impacto, requer estado e salvaguarda explicitamente fornecidos. Resultados de VIDA/RD/dano aplicado/HIT permanecem `null`.

### Operação efetiva pelo Comestre no chat

As chamadas abaixo são **internas ao Comestre** quando o Mestre faz uma escolha no celular; o Mestre não precisa de computador, instalação nem executar comandos:

```bash
python verificador_r29.py --prepare MACACO_PATADA
python verificador_r29.py --json '{"mode":"DOCUMENTAL_DICE_ONLY","action_id":"MACACO_PATADA","rolls":[3,5]}'
python verificador_r29.py --roll MACACO_PATADA
python verificador_r29.py --roll MACACO_PATADA --seed 0123456789abcdef0123456789abcdef
python verificador_r29.py --interactive
```

No modo interativo, é possível selecionar o caso e **somente depois** informar roladas, ou escolher `ROLAR` para obter dados fictícios gerados pelo verificador. A rolagem pedida explicitamente usa semente hex gravada e expansão SHA-256 com rejeição de viés; pode ser reproduzida exatamente. A fonte prova **a expressão**, não que a rolagem ocorreu numa sessão. A ação de sangramento exige salvaguarda previamente determinada; não se inventa teste de CON.

## 3. Execuções e recibos R29

`recibos_r29/` preserva **15 recibos**, cada um com input, fonte, última edição, variantes, autorização/negação, campos de efeito isolado e SHA-256 do conteúdo:

| Entrada experimental fictícia | Resultado isolado | Estado |
|---|---:|---|
| Macaco Patada d6=[3,5] + FOR54 | 62 impacto bruto | Documento calculável |
| Macaco Mordida d6=[4] + FOR54 | 58 perfurante bruto | Documento calculável |
| Macaco Poder elemental d10=[7] + INT30 | 37 bruto **sem tipo** | Documento calculável, não ação executada |
| Liu Machado d12=[1,3,5,7,9] | 25 bruto intrínseco | Documento calculável |
| Liu Cruel/Certeira | +2 como parcela de item | Não é golpe autônomo |
| Liu Infusão elétrica d8=[2,4,6] + 6 | 18 bruto do rider | Não empilhado nem mitigado |
| Dragão A Esmaga d6=[2,3,4,5] + FOR36 | 50 bruto | Adaptador R28 |
| Dragão B Esmaga mesmos d6 + FOR60 | 74 bruto | Adaptador R28 isolado |
| Jaku lança d8=[3,6] + 2 | 11 bruto | Adaptador R28 sem FOR/FF |
| Jaku Estocada, início do turno, CON falhou, d6=[4] | 4 de tick bruto | Continua sangrando |
| Jaku Estocada, início do turno, CON passou | 0 | Estabiliza |
| Macaco Patada sem dado | Sem cálculo | HOLD explícito |
| Jaku lança com FOR22 arbitrário | Sem cálculo | REJECT |
| Poder elemental com Gelo atribuído | Sem cálculo | REJECT |
| Macaco Patada `--roll` seed `0123456789abcdef0123456789abcdef` | dados [2,2] → 58 bruto | ROLAGEM FICTÍCIA com seed/replay |

*Valores brutos correspondem a componentes, não perdas de Vida ou dano líquido. Condições da cena são fixtures, não evidência de execução histórica.*

## 4. Testes executados

- **R28 original imutável:** 26/26 testes PASS reexecutados sobre extração recuperada, além de validação do manifesto e CRC.
- **R29 novos:** 50/50 testes PASS. Cobrem exigências A–H: atributo autorizado, FOR22 rejeitado, temporalidade de Estocada, variantes isoladas, HOLD de dado ausente, execução interativa com escolha posterior, recibos/sha determinísticos, limites oficiais; ainda testam Macaco sem Gelo herdado, passiva +2 não aplicada, Liu sem auto-stacking, PA não debitado, seed reproduzível/registro, modo STRICT e tentativa de escrita rejeitados.
- **Total de testes da cadeia R28+R29 reexecutados nesta etapa: 76/76 PASS.** Nenhum é UAT do Mestre, aceite científico terminal, integração VLAB ou combate.

## 5. VLAB — contrato de triagem preparado, não integrado

`CONTRATO_VLAB_IBX90_TRIAGEM_R29.json` oferece catálogo de componentes com URL, versão de fonte, expressão, dados, tag literal, janela, custos textuais e campos bloqueantes, **somente para eventual triagem pela IBX-90 já existente**. Declara compatibilidade e integração ao resolvedor nativo como **NÃO COMPROVADAS**, sem envio automático, ACK presumido ou novo envelope.

IBX-90 consultada em 14/10/2026: `NOVA`, `Lida por INSTANCE-ID=NULL`, CM-000006, sem evidência de resposta legítima neste recorte. Nenhum caso de Macaco/Liu foi entregue ao VLAB para execução; somente o motor documental local foi operado.

## 6. Questões congeladas e governança

Jaku FF390/420, amplificador +3, quarto marco, FOR22 não autorizado no dano imediato, Estocada T2, CA39/44,6 e segundo Dragão continuam **PENDENTES COM CAUSA IDENTIFICADA**, sem novas buscas idênticas. Não inventar `1d6+27`, atribuição do +3, rolamento histórico nem alteração de ficha.

**Decisões reservadas, intactas:** `DEC-B11-A`, `DEC-B11-B`, `DEC-B11-C`, `DEC-B12-A`, `DEC-B12-B`, `DEC-BONUS-JAKU-01`, `DEC-INFUSION-JAKU-01`. Nenhuma foi aprovada ou duplicada.

| Gate oficial | R28 ANTES | R29 DEPOIS |
|---|---:|---:|
| B02 PASS_DOCUMENTAL / B01–B18 certificados | 1/18 (5,56%) | 1/18 (5,56%) |
| PARTIAL | 9/18 | 9/18 |
| BLOCKED | 6/18 | 6/18 |
| NOT_TESTED | 2/18 | 2/18 |
| STRICT | 0/2 | 0/2 |
| CSV I0003 original | 0/9 | 0/9 |
| B11/B12 decisões aprovadas | 0/5 | 0/5 |
| Contratos de componentes no motor de chat | 4 (R28: 3 dano + tick) | 10 (R29: 9 dano/modificadores + tick) |
| Testes reexecutados dos motores | 26/26 | 26/26 regressão + 50/50 novos |

**Escritas Notion/Party/O Primeiro:** zero. **Writer, lease, epoch, fencing, GREEN e NAC-PASS produtivo:** HOLD. Não houve atualização material de DMG-RANK ou de qualquer critério oficial.

## 7. Fronteira de retomada — próximo ganho sem prolongar Jaku

1. **B05: fechar original Liu × Macaco na forma realmente selecionada**, incluindo passiva FOR54+2, PA Livre/itens/cargas, ação padrão vs poder elemental, extensão e T9, tags/componentes, alcance, alvo, e emitir menú permitido/rejeitado **para aquela cena**, não para fixture. Requer fonte freeze de época e leitura/aceite por receptor competente.
2. **B06: testar janelas e consumo transacional** com ação completa/ataque padrão/reação usando menus B05 quando validados. Sem ledger real, o contrato atual segue documental.
3. **B15: explorar o rider elétrico de Liu** somente se houver alvo, elemento/tag equivalentes, condições e recibo de ataque real; a presença de `3d8+6 elétrico` não é fraqueza ou RD comprovada.

Se não surgir prova de cena, prosseguir preenchendo campos **que já tenham fonte competente** do inventário original, sem alterar o denominador terminal ou creditar B05 prematuramente. Continuar calculando pelo chat usando R29; não acrescentar interface HTML.

**Checkpoint de saída:** OP original preservada, R28 original SHA validado e embutido, 43 entradas B05/6 perfis, 10 componentes calculáveis, 15 recibos, 76/76 testes, IBX-90 NOVA/SEM ACK, produção HOLD. Estado R29: **ENTREGA EXPERIMENTAL FUNCIONAL NÃO CANÔNICA**, não versão oficialmente registrada no Notion.
