import json
from pathlib import Path
from verificador_r29 import ROOT,CASES,BLEED_ID,REG,calculate,prepare

fixtures={
'01_jaku_lanca_intrinseca':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'JAKU_LANCA_INTRINSECA','rolls':[3,6]},
'02_dragao_a_esmagacranio':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'DRAGAO_A_ESMAGA_CRANIO','rolls':[2,3,4,5]},
'03_dragao_b_esmagacranio':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'DRAGAO_B_ESMAGA_CRANIO','rolls':[2,3,4,5]},
'04_macaco_patada':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'MACACO_PATADA','rolls':[3,5]},
'05_macaco_mordida':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'MACACO_MORDIDA','rolls':[4]},
'06_macaco_poder_elemental_sem_tipo':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'MACACO_PODER_ELEMENTAL_BASE','rolls':[7]},
'07_liu_machado_base':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'LIU_MACHADO_BASE','rolls':[1,3,5,7,9]},
'08_liu_cruel_certeira_parcela':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'LIU_MACHADO_CRUEL_CERTEIRA_PARCELA','rolls':[]},
'09_liu_infusao_eletrica_parcela':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'LIU_MACHADO_INFUSAO_ELETRICA_PARCELA','rolls':[2,4,6]},
'10_estocada_falha_tick':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':BLEED_ID,'rolls':[4],'instante':'INICIO_TURNO_DA_VITIMA','estado':'SANGRANDO','salvaguarda':'FALHA'},
'11_estocada_sucesso_tick':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':BLEED_ID,'rolls':[],'instante':'INICIO_TURNO_DA_VITIMA','estado':'SANGRANDO','salvaguarda':'SUCESSO'},
'12_HOLD_sem_dados_obrigatorios':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'MACACO_PATADA'},
'13_DENY_forca_indevida_Jaku':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'JAKU_LANCA_INTRINSECA','rolls':[3,6],'FOR':22},
'14_DENY_tag_gelo_indevida':{'mode':'DOCUMENTAL_DICE_ONLY','action_id':'MACACO_PODER_ELEMENTAL_BASE','rolls':[7],'elemento':'GELO'},
}
receipts=ROOT/'recibos_r29';receipts.mkdir(exist_ok=True)
check=[]
for name,req in fixtures.items():
    r=calculate(req)
    (receipts/(name+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
    check.append({'fixture':name,'action':req['action_id'],'status':r['status'],'raw':r.get('result',{}).get('raw_damage'),
                  'raw_tick':r.get('result',{}).get('raw_status_damage'),'modifier':r.get('result',{}).get('raw_isolated_modifier'),
                  'receipt_sha256_content':r['receipt_hash']})
(ROOT/'FIXTURES_R29.json').write_text(json.dumps({'provenance':'Invented fixture input for scientific testing only; NO historical RNG','inputs':fixtures},ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
(ROOT/'INDICE_RECIBOS_R29.json').write_text(json.dumps(check,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
triage={'schema':'OPDMG-R29-SOURCE-ONLY-CATALOG-FOR-VLAB-TRIAGE','request_existing':'REQ-CM000001-DMG-R26-JAKU-VLAB-20261013-001',
        'inbox':'IBX-90','state':'PREPARED_LOCAL_ONLY_NOT_SENT','ack':False,'author':'CM-000001 / no claimed INSTANCE-ID',
        'contains_real_fight_inputs':False,'strict':False,'production_writer':False,
        'source_signature_method':'Notion URL plus last-edited; not a source snapshot cryptographic signature',
        'runtime_integration':'NOT_DONE_NO_NATIVE_VLAB_RECEIPT',
        'scope':'R29 action corpus scientific dice-only; excludes HP, PA commits, initiative, positions and RNG historic',
        'interface_compatibility':'NOT_CLAIMED',
        'compiler_contract':{'intent':'READ_ONLY_PROVENANCE_TRIAGE','input_case':'action_id + rolls fixture','full_action_request_policy':'REJECT'},
        'action_components':[{ 'id':k, 'profile':v['profile'],'source':REG['sources'][v['source']]['url'],
         'source_last_edited':REG['sources'][v['source']]['last_edited'], 'source_literal':v['literal'],
         'dice_schema':v['dice'], 'fixed':v['fixed'], 'type_literal':v['damage_type'],
         'cost':v['cost'],'action_economy':v['action_economy'],'missing':v['requires'],
         'full_action_legal':False } for k,v in CASES.items()]}
(ROOT/'CONTRATO_VLAB_IBX90_TRIAGEM_R29.json').write_text(json.dumps(triage,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps(check,indent=2,ensure_ascii=False))
