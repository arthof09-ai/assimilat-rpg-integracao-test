# DMG R29 — Uso pelo Comestre no chat

**Não exige PC do Mestre.** O Comestre abre o pacote no próprio ambiente e conduz a escolha de ação, variante e rolagens em conversa.

## Fluxo imediato

- **"Calcule Patada do Macaco Rei"** → consultar `--prepare MACACO_PATADA`, conferir que a fonte FOR54 é documental, pedir dados ou autorização para rolar fixture, executar `--json` ou `--roll`, devolver recibo e hash.
- **"Compare Esmaga Crânio A/B"** → rodar ambos com os mesmos 4d6 fornecidos (ou seeds explícitas independentes) e listar diferenças fonte FOR36/60 sem misturar as fichas.
- **"Calcule o Poder elemental"** → fórmula `1d10+INT30`, 10 PA só informativo, tipo desconhecido e nenhuma reserva cobrada.
- **"Faça Estocada Cruel"** → sem golpe histórico, pedir estado de sangramento e resultado da salvaguarda CON CD17; tick ocorre no INÍCIO DO TURNO da vítima, separado do golpe.
- **"Some FOR22 ao dano da lança"** → rejeitar o acréscimo não autorizado; contrato calculável da lança `2d8+2` não é novo ataque com componente extra.

## Arquivos importantes

- `verificador_r29.py` — comando operado pelo Comestre, inclusive `--interactive`, `--roll`, `--json`, `--prepare`, `--catalog`.
- `registry_r29.json` — contrato de fonte e limitações.
- `INVENTARIO_B05_R29.json/.csv` — 43 entradas, seis perfis, B05 não certificado.
- `recibos_r29/` — 15 recibos com resultado/proveniência/denial/HOLD e hashes.
- `testes_r29.py` — 50 verificações novas; `REGRESSAO_R28_R29.log` — 26 do R28.
- `historico/DMG_R28_ORIGINAL_READONLY.zip` — ZIP pai byte preservado com R27 dentro.
- `CONTRATO_VLAB_IBX90_TRIAGEM_R29.json` — não integrado, não enviado, sem ACK.

**Escopo:** SOMENTE dano bruto de componente e ticks explicitamente condicionados em sandbox. Não calcular acerto, dano aplicado, Vida posterior, RD, PA pago, execução histórica, STRICT ou escrever no Notion. NAC-PASS e IBX-90 HOLD.
