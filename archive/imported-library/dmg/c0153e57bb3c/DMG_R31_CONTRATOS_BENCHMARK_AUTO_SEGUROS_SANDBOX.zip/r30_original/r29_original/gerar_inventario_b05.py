"""Closed list of physically observed named action candidates in 5 source pages.
Not a declaration of exhaustive native actor legality or original B05 completion.
"""
import json
from pathlib import Path
from verificador_r29 import REG,prepare,CASES,BLEED_ID
ROOT=Path(__file__).resolve().parent
items=[]
def add(profile,key,kind,literal,window,cost,preconditions,missing,executable=None):
  source=REG['profiles'][profile]['source']
  items.append({'action_key':key,'profile':profile,'kind':kind,'source':source,
                'url':REG['sources'][source]['url'],'source_last_edited':REG['sources'][source]['last_edited'],
                'literal_source':literal,'window':window,'cost_documented':cost,
                'activation_conditions':preconditions,'fields_missing_for_full_action':missing,
                'dice_only_case':executable,'status':'DOCUMENTED_CANDIDATE_NOT_LEGAL_SCENE_ACTION',
                'actor_form_unverified':True,'writer':'DENY'})
# Original B05 paired corpus first: Monkey and Liu.
M='MACACO_P5'
add(M,'PATADA','OFFENSIVE','Patada: 2d6 + força impacto','ATTACK_GENERAL_STD_NOT_ACTUAL','not stated',['FOR54 literal','target/hit not frozen'],['PA_policy','target','hit','mitigation','+2 Titanic passive state'],'MACACO_PATADA')
add(M,'MORDIDA','OFFENSIVE','Mordida: 1d6 + força perfurante','ATTACK_GENERAL_STD_NOT_ACTUAL','not stated',['FOR54 literal','target/hit not frozen'],['PA_policy','target','hit','mitigation','+2 Titanic passive state'],'MACACO_MORDIDA')
add(M,'PODER_ELEMENTAL','OFFENSIVE','Poder elemental: 1d10 + inteligência, custa 10PA','UNKNOWN_ACTION_CLASS','10 PA',['INT30 literal'],['magic vs attack classification','element','PA_available','target/defense','RDF'],'MACACO_PODER_ELEMENTAL_BASE')
add(M,'MANIPULACAO_MAGICA','ABILITY','Manipulação Mágica: barreiras defensivas e feitiços ofensivos','UNKNOWN','not stated',[],['spell identity','damage','range','cost','effect'],'')
add(M,'FORCA_TITANICA','PASSIVE','Força Titânica: +2 força','PASSIVE','not stated',['physical state'],['whether included in printed FOR54','activation/stacking'],'')
add(M,'TELEPATIA','UTILITY','Comunicação Telepática','UNKNOWN','not stated',[],['range','targets','activation','duration'],'')
L='LIU_NORMAL'
add(L,'ATAQUE_BASICO','OFFENSIVE','Ataque Básico: 2d6+37 (5d12+3d8+1d6+45)','GENERAL_STD_ATTACK','not stated',['normal form printed'],['provenance of +1d6 and fixed damage','equipment/PA state','scene hit'],'')
add(L,'INSTINTO_SELVAGEM','PASSIVE','+4 em iniciativa e percepção','PASSIVE','not stated',[],['scope/activation/compatibility'],'')
add(L,'VONTADE_INABALAVEL','PASSIVE','+6 vontade quando em Fúria','PASSIVE','not stated',['in Fury'],['Fury activation/scene'],'')
add(L,'DESTRUIDOR','DAMAGE_REROLL','Em arma duas mãos, pode rerrolar qualquer 1 ou 2 dos dados de dano da arma','ON_WEAPON_DAMAGE','not stated',['weapon actually two handed'],['axe 2h property not proved','reroll sequence','usage event'],'')
add(L,'CRITICO_BRUTAL','CRITICAL_MODIFIER','Multiplicador de crítico com armas pesadas aumenta +2','ON_CRIT','not stated',['heavy weapon','critical'],['DEC-B11-A','scope and stacking','critical receipt'],'')
add(L,'EXTENSAO_CORPORAL','ACTIVATION','+3d6 dano OU +6 CA; 30 PA','unconfirmed historical timing / specialized activation',30,['select damage or CA','physical 620 displayed'],['PA available','source form','activation and duration'],'')
add(L,'FURIA','ACTIVATION','Quando Vida chega à metade: +15 FOR e +80 Vida; 12 PA','when HP <= half',12,['HP threshold'],['HP current','action window','duration','PA status'],'')
add(L,'BOTAS_VELOCIDADE','ITEM_ACTIVATION','Ação bônus externa; +8m; 15PA por dia','BONUS_UNMAPPED','15 PA/day',['boots active and worn'],['action bonus conversion','remaining charges'],'')
add(L,'ANEL_ATRIBUTO','ITEM_ACTIVATION','Anel atributo: +6; 30 PA','UNKNOWN',30,[],['target attribute','activation/charges','timing'],'')
add(L,'ANEL_ALMA','ITEM_PASSIVE','Anel da Alma +50PA','PASSIVE','none explicit',[],['equipped status','PA accounting'],'')
add(L,'MACHADO_BASE','WEAPON_POOL','Machado de Guerra Elétrico 5d12 de dano','ATTACK_GENERAL_STD','-60PA/day equipment',['weapon hit hypothetical'],['wield status','RNG for hit','RD','PA status'],'LIU_MACHADO_BASE')
add(L,'MACHADO_ARREMESSAVEL','WEAPON_THROW','6 metros normal, +3 acerto +8 dano, volta como Ação Livre; 11PA/dia','throw + free return','11 PA/day',['thrown attack','range <=6m'],['target distance','throw legal action','charges','damage stacking'],'')
add(L,'MACHADO_CRUEL_CERTEIRA','WEAPON_MODIFIER','+2 em testes de ataque e dano','MODIFIER_ONLY','equipment cost unknown',[],['no double count','wielded in scene'],'LIU_MACHADO_CRUEL_CERTEIRA_PARCELA')
add(L,'MACHADO_DECEPADORA','CRITICAL_TRIGGER','Ao critar criatura +18 cortante; segundo crítico possivelmente decepação','CRIT_TRIGGER','20PA/day',['weapon crit'],['DEC-B11-B/C','reroll sequence','weapon type description sword vs axe'],'')
add(L,'MACHADO_INFUSAO','ELEMENTAL_RIDER','Infusão Elétrica 3d8+6 dano elétrico adicional','RIDER_ONLY','equipped item -60PA/day',['item equipped/active'],['electric vs lightning equivalence','scene hit','PA','target resistance'],'LIU_MACHADO_INFUSAO_ELETRICA_PARCELA')
add(L,'ARMADURA_PESADA','ITEM_PASSIVE','Armadura +15CA RDF10, +8 FOR, 42PA','PASSIVE_WHEN_EQUIPPED','42PA',['equipped armor'],['whether FOR included in raw printed FOR','PA ledger'],'')
LT='LIU_TRANSFORMADA'
add(LT,'TRANSFORMAR','TRANSFORMATION','Regra Prata requer ação completa 40PA; transformação em ficha Liu','FULL_ACTION','40PA',['Spirit ID and form'],['T9 eligibility','PA/HP epoch','actual activation','duration'],'')
add(LT,'ATAQUE_TRANSFORMADO','OFFENSIVE','Ataque transformado 2d6+48 (5d12+3d8+1d6+60)','GENERAL_STD_ATTACK','not stated',['transformed form'],['form activation','unexplained +1d6','resource/gear state'],'')
add(LT,'EXTENSAO_TRANSFORMADA','ACTIVATION','Extensão +3d9 dano OU +9CA; 45PA','unconfirmed historical timing','45PA',['transformed state'],['T9 active','available PA','status'],'')
add(LT,'RETALIACAO','REACTION_MODIFIER','Retaliação +20 dano em contra-ataques','COUNTERATTACK','not stated',['transformed','counterattack legal'],['reaction budget','hit/order','timing'],'')
J='JAKU_P3'
add(J,'ATAQUE_BASICO','OFFENSIVE','Ataque 2d6+30 (5d8+1d6+33)','GENERAL_STD_ATTACK','not stated',['normal form'],['origin 1d6+27','hand/gear paid','target/scene'],'')
add(J,'LANCA_BASE','WEAPON_POOL','Lança 2d8+2','GENERAL_STD_ATTACK','20PA/day',['weapon wielded'],['cost/activation','hit','damage tags'],'JAKU_LANCA_INTRINSECA')
add(J,'ESTOCADA_CRUEL','ON_HIT_STATUS','Perfuração hit aplica sangramento; CON CD17 a cada início turno; falha 1d6','ON_HIT then TARGET_START_TURN','not stated',['piercing hit','bleeding state'],['hit/event','save transcript','ongoing tick source'],'JAKU_ESTOCADA_CRUEL_TICK')
add(J,'INVESTIDA_SANGUINARIA','ACTIVATION','Ação Livre; +1 ataque,+4 dano por 1d4+1 rodadas,5 usos/dia;5PA','FREE_ACTION','5PA',['activates skill'],['remaining uses','PA','duration fixture'],'')
add(J,'POSTURA_DEFENSIVA','ACTIVATION','Postura Defensiva +3 CA, 5PA','UNSPECIFIED','5PA',[],['action window','duration','PA'],'')
add(J,'OPORTUNIDADE_ESTENDIDA','REACTION_TRIGGER','Raio 3m entrada ou saída; ataque oportunidade 3PA','REACTION_GENERAL','3PA',['target enters/exits 3m'],['reaction available','movement geometry','PA'],'')
add(J,'INFUSAO_ESPIRITUAL','ELEMENTAL_RIDER','+2d8+2 espiritual flamejante','UNKNOWN','20PA/day lance',['lance effect'],['DEC-INFUSION-JAKU-01','tag','activation'],'')
add(J,'MANOPLAS','ITEM_ACTIVATION','Ação bônus externa; +1d8+2 fogo mágico ao envolver armas','BONUS_UNMAPPED','13PA/day',['gloves wielded'],['DEC-BONUS-JAKU-01','charges','activation'],'')
add(J,'AMPLIFICADOR','ITEM_ACTIVATION','Amplificador +3 a um atributo; 15PA/day','UNSPECIFIED','15PA/day',['specific stat chosen'],['stat target','PA','activation epoch','FF lock'],'')
for D in ['DRAGON_A','DRAGON_B']:
  add(D,'ESMAGA_CRANIO','OFFENSIVE','Esmaga crânio: 4d6 + For','GENERAL_STD_ATTACK','not stated',['FOR literal in variant'],['target/hit','activation/PA','RD'], 'DRAGAO_A_ESMAGA_CRANIO' if D=='DRAGON_A' else 'DRAGAO_B_ESMAGA_CRANIO')
  add(D,'SOPRO_CONGELANTE','STATUS_ABILITY','Sopro Congelante: congelar, CD=6+INT+1/2lvl,15PA','UNKNOWN','15PA',['target eligible'],['lvl effective','freeze mechanics','target save','geometry'],'')
  add(D,'FORCA_GLACIAL','PASSIVE','+10 dano no habitat natural','PASSIVE_IF_HABITAT','not stated',['natural habitat'],['actual habitat','stacking','valid timing'],'')
  add(D,'MESTRE_NEVASCAS','CONTROL','Nevascas e manipulação de gelo,20PA','UNKNOWN','20PA',['area compatible'],['range','duration','hit/defense','resource'],'')

counts={}
for v in items:counts[v['profile']]=counts.get(v['profile'],0)+1
calculated=[i for i in items if i['dice_only_case']]
assert len(set((i['profile'],i['action_key']) for i in items))==len(items)
assert all(x['dice_only_case'] in CASES or x['dice_only_case']==BLEED_ID for x in calculated)
output={'operation':'OP-DMG-CORPUS-EMP-01','schema':'R29-B05-BOUNDED-SOURCE-INVENTORY',
 'original_gate':{
  'id':'B05','original_label':'complete legal actor action inventory','original_requirement':'Complete legal action loadouts and owned abilities for all actors not adjudicated',
  'acceptance':'Compiler emits allowed/rejected action with explicit per-field provenance and atomic effect plan',
  'r26_terminal_missing':'Compile each actor action in chosen form into complete provenance-linked legal menu and obtain reader acceptance',
  'source':'R11 and R26 historical matrices; preserved as references, not recreated'},
 'source_bounded_profiles':list(REG['profiles']),
 'inventory_candidates_documented':len(items),'profiles_count':len(counts),
 'counts_by_profile':counts,'documental_components_executable':len(calculated),
 'unresolved_entire_legal_universe':'NOT_DETERMINABLE: scene epoch, form/gear and all actors not frozen',
 'B05_whole_gate':'PARTIAL_NOT_CERTIFIED','nac_pass':'HOLD','writer':'DENY',
 'rows':items}
(ROOT/'INVENTARIO_B05_R29.json').write_text(json.dumps(output,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
(ROOT/'INVENTARIO_B05_R29.csv').write_text('profile,action_key,kind,source,dice_only_case,window,cost_documented,fields_missing_for_full_action\n'+''.join('"'+v['profile']+'","'+v['action_key']+'","'+v['kind']+'","'+v['source']+'","'+(v['dice_only_case'] or '')+'","'+v['window']+'","'+str(v['cost_documented'])+'","'+';'.join(v['fields_missing_for_full_action'])+'"\n' for v in items),encoding='utf8')
print(json.dumps({k:v for k,v in output.items() if k!='rows'},indent=2,ensure_ascii=False))
