#!/usr/bin/env python3
"""Mestre-side: OP-DMG-CORPUS-EMP-01 / DMG R29. Strictly documentary dice and
conditioned tick. Explicitly no historical fight, hit, HP, PA commit, RD or write.
Reuses unchanged R28 verifier for its three damage cases and the Jaku tick.
"""
import argparse
import hashlib
import secrets
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'r28_original'))
import verificador_r28 as parent

REG=json.loads((ROOT/'registry_r29.json').read_text(encoding='utf8'))
CASES=REG['calculable']; BLEED_ID=REG['bleed_action']['id']
STATUS_ALLOW='ALLOW_DOCUMENTAL_COMPONENT_ONLY'
STATUS_HOLD='HOLD_MISSING_INPUT'
STATUS_REJECT='REJECTED_SOURCE_OR_POLICY'


def evidence(action_id):
    a=CASES[action_id] if action_id in CASES else REG['bleed_action']
    s=REG['sources'][a['source']]
    p=REG['profiles'][a['profile']]
    return {'actor':p['actor'],'profile_id':a['profile'], 'form':p['form'],
            'form_status':p['state'],'source_key':a['source'],
            'source_url':s['url'],'source_last_edited_not_effective_at':s['last_edited'],
            'rule_urls':[REG['sources']['COMBAT']['url'],REG['sources']['DMG_RANK']['url']]}


def prepare(action_id):
    """Bounded compiler, never a real combat legality grant."""
    if action_id!=BLEED_ID and action_id not in CASES:
        return {'status':STATUS_REJECT,'reason':'UNKNOWN_ACTION_NOT_IN_SOURCE_CATALOG','action_id':action_id}
    a=REG['bleed_action'] if action_id==BLEED_ID else CASES[action_id]
    base={'catalog':'DMG_R29_B05_SUBSET_NOT_FULL_GATE','action_id':action_id,
          'catalog_decision':STATUS_ALLOW,'combat_decision':'DENY_UNFROZEN_SCENE',
          'provenance':evidence(action_id),'source_literal':a['literal'],
          'action_economy':a['action_economy'],'resource_cost':a['cost'],
          'temporal_window':a.get('temporal',a.get('trigger')),
          'full_action_missing':a['requires'],'contract_mode':'DOCUMENTAL_DICE_ONLY',
          'effect_plan':['read source','verify exact dice','compute isolated component','issue deterministic receipt','NO impact on HP/PA/world'],
          'prohibited':['STRICT','hit resolution','HP update','RD/resistance','PA debit','invented tags','Notion write']}
    if action_id==BLEED_ID:
        base['next_inputs']=['instante=INICIO_TURNO_DA_VITIMA','estado=SANGRANDO','salvaguarda=FALHA|SUCESSO','rolls=[1d6] if FALHA else []']
        base['damage_semantics']='TEMPORAL_STATUS_TICK_NOT_INITIAL_IMPACT'
    else:
        base['dice_schema']=a['dice']
        base['fixed_parts']=a['fixed']
        base['damage_type_literal']=a['damage_type']
        base['condition']=a['condition']
        base['excluded']=a['excluded']
        base['next_inputs']=[f"{a['dice']['count']} dice of d{a['dice']['sides']} (fixture user supplied)"] if a['dice']['count'] else ['rolls=[] (fixed modifier only)']
        base['damage_semantics']=a['kind']
    base['receipt_hash']=parent.sha(base)
    return base


def rejection(event,reason,status=STATUS_REJECT):
    reply={'schema':'OPDMG_R29_EXECUTION_RECEIPT_v1','status':status,'reason':reason,'input':event,
           'STRICT':'DENY','historic_combat':False,'writes':False,'HP_after':None,'PA_after':None,
           'raw_damage':None,'applied_damage':None,'RD':None,'hit':None}
    reply['receipt_hash']=parent.sha(reply)
    return reply


def calculate(event):
    """Supports runtime inputs one by one; no embedded scripted rolls."""
    if not isinstance(event,dict): return rejection(str(event),'INPUT_MUST_BE_OBJECT')
    if event.get('mode')!='DOCUMENTAL_DICE_ONLY':return rejection(event,'MODE_ONLY_DOCUMENTAL_DICE_ONLY')
    action_id=event.get('action_id')
    if action_id!=BLEED_ID and action_id not in CASES:return rejection(event,'UNKNOWN_ACTION')
    is_bleed=(action_id==BLEED_ID)
    allowed={'mode','action_id','rolls'}|({'instante','estado','salvaguarda'} if is_bleed else set())
    if set(event)-allowed:return rejection(event,'UNAUTHORIZED_EXTRA_FIELD:'+','.join(sorted(set(event)-allowed)))
    if 'rolls' not in event or event['rolls'] is None:return rejection(event,'ROLLS_REQUIRED_NO_AUTO_ROLL',STATUS_HOLD)
    rolls=event['rolls']
    if is_bleed:
        need={'instante','estado','salvaguarda'}-set(event)
        if need:return rejection(event,'MISSING_BLEED_PRECONDITION:'+','.join(sorted(need)),STATUS_HOLD)
        e={'modo':'DOCUMENTAL','tipo':'ESTOCADA_CRUEL_TICK','dados':rolls,
           'instante':event['instante'],'estado':event['estado'],'salvaguarda':event['salvaguarda']}
        try: old=parent.eval_bleed_tick(e)
        except (KeyError,ValueError,TypeError) as er:return rejection(event,'BLEED_CONTRACT_INVALID:'+str(er))
        value=old['result']['dano_bruto_status']
        out_result={'raw_status_damage':value,'isolated_impact_damage':None,'status_after':old['result']['novo_estado'],
                    'raw_damage':value,'applied_damage':None,'HP_after':None,'PA_after':None,
                    'hit':None,'RD':None,'defense_roll':None,'save_result_is_fixtured':True,
                    'time':'INICIO_TURNO_DA_VITIMA'}
        provenance=evidence(action_id)
        source_parent_hash=old['hash_conteudo']
    else:
        a=CASES[action_id];count=a['dice']['count'];sides=a['dice']['sides']
        if not isinstance(rolls,list):return rejection(event,'ROLLS_MUST_BE_LIST')
        if len(rolls)!=count:return rejection(event,'DICE_COUNT_MUST_MATCH_SOURCE')
        if any(type(v)!=int or v<1 or v>sides for v in rolls):return rejection(event,'DIE_OUT_OF_RANGE_OR_NOT_INTEGER')
        if a['adapter']=='R28':
            mapped={'JAKU_LANCA_INTRINSECA':'JAKU_LANCA_INTRINSECA',
                    'DRAGAO_A_ESMAGA_CRANIO':'DRAGAO_A_ESMAGA_CRANIO',
                    'DRAGAO_B_ESMAGA_CRANIO':'DRAGAO_B_ESMAGA_CRANIO'}
            old=parent.verify_event({'modo':'DOCUMENTAL','tipo':'DANO_ISOLADO','caso':mapped[action_id],'dados':rolls})
            value=old['result']['dano_bruto_isolado'];source_parent_hash=old['hash_conteudo']
        else:
            value=sum(rolls)+sum(x['value'] for x in a['fixed']);source_parent_hash=None
        is_modifier=(a['kind']=='WEAPON_MODIFIER_ONLY')
        out_result={'raw_damage':None if is_modifier else value,
                    'raw_isolated_modifier':value if is_modifier else None,
                    'applied_damage':None,'HP_after':None,'PA_after':None,
                    'hit':None,'RD':None,'resistance':None,'critical':None,
                    'resource_spent':False,'temporal':a['temporal']}
        provenance=evidence(action_id)
    plan=prepare(action_id)
    receipt={'schema':'OPDMG_R29_EXECUTION_RECEIPT_v1','status':STATUS_ALLOW,
             'contract':'OP-DMG-CORPUS-EMP-01/CM-000001/R29-DICE-ONLY',
             'mode':'DOCUMENTAL_DICE_ONLY','STRICT':'DENY','historic_combat':False,
             'input_fixture':event,'provenance':provenance,
             'source_literal':plan['source_literal'],
             'source_condition':plan.get('condition'),'action_economy':plan['action_economy'],
             'resource_cost_documented':plan['resource_cost'],
             'resource_actual_commit':False,'damage_type_literal':plan.get('damage_type_literal'),
             'temporal_window':plan['temporal_window'],
             'authorized_parts':plan.get('fixed_parts',[]),
             'component_rolls':rolls,'result':out_result,
             'excluded_components':plan.get('excluded',[]),
             'full_action_missing':plan['full_action_missing'],
             'full_action_legal':'NOT_CERTIFIED','parent_r28_receipt_hash':source_parent_hash,
             'verification_scope':'MATH_AND_SOURCE_FIELDS_ONLY',
             'write':'DENY','NAC_PASS':'HOLD','B05':'PARTIAL_NOT_CERTIFIED'}
    receipt['receipt_hash']=parent.sha(receipt)
    return receipt


def roll_fixture(action_id,seed_hex=None):
    """Only on affirmative ROLAR request; deterministic SHA256 expansion with
    rejection sampling over bytes, seed included in replay receipt. Never real RNG.
    """
    if action_id not in CASES:
        return rejection({'action_id':action_id},'ROLL_SUPPORTED_ONLY_FOR_SOURCE_DICE_CASES')
    if seed_hex is None:
        seed_hex=secrets.token_hex(16)
    if not isinstance(seed_hex,str) or len(seed_hex)<32 or len(seed_hex)>128 or len(seed_hex)%2:
        return rejection({'seed_hex':seed_hex},'SEED_HEX_LENGTH_INVALID')
    try:seed=bytes.fromhex(seed_hex)
    except ValueError:return rejection({'seed_hex':seed_hex},'SEED_NOT_HEX')
    a=CASES[action_id];rolls=[]
    for i in range(a['dice']['count']):
        sides=a['dice']['sides'];limit=256-(256%sides)
        j=0
        while True:
            b=hashlib.sha256(b'OPDMG_R29_FIXTURE_ONLY'+seed+action_id.encode('utf8')+i.to_bytes(2,'big')+j.to_bytes(2,'big')).digest()[0]
            if b<limit:
                rolls.append(b%sides+1)
                break
            j+=1
            if j>65534:raise RuntimeError('Impossible RNG rejection sample loop limit')
    receipt=calculate({'mode':'DOCUMENTAL_DICE_ONLY','action_id':action_id,'rolls':rolls})
    receipt['fixture_rng']={'explicitly_requested':True,'source':'OS_RANDOM_SEED_OR_USER_SEED',
                            'seed_hex':seed_hex,'algorithm':'SHA256_REJECTION_SAMPLING_0_BASED_BYTE_COUNTER',
                            'dice_generated':rolls,'not_historical_rolls':True}
    receipt['receipt_hash']=parent.sha({k:v for k,v in receipt.items() if k!='receipt_hash'})
    return receipt

def interactive():
    """A real conversation/terminal session: one case selected at a time, later rolls."""
    choices=list(CASES)+[BLEED_ID]
    print('OP-DMG R29 / Mestre-only / experimental / sem HP ou STRICT',flush=True)
    while True:
        print('CASOS DISPONIVEIS: '+', '.join(choices),flush=True)
        case=input('ACTION_ID [ou SAIR]: ').strip().upper()
        if case in ('SAIR','EXIT','QUIT',''):
            print('SESSAO ENCERRADA SEM MUDANCA',flush=True);break
        prep=prepare(case)
        print(json.dumps(prep,ensure_ascii=False,sort_keys=True),flush=True)
        if prep.get('catalog_decision')!=STATUS_ALLOW:continue
        if case==BLEED_ID:
            instant='INICIO_TURNO_DA_VITIMA';condition=input('ESTADO DA VITIMA [SANGRANDO]: ').strip().upper()
            verdict=input('SALVAGUARDA [FALHA/SUCESSO]: ').strip().upper()
            dice_text=input('1D6 resultado se FALHA, vazio se SUCESSO: ').strip()
            try: rolls=[int(dice_text)] if dice_text else []
            except ValueError: rolls=['NAO_NUMERICO']
            event={'mode':'DOCUMENTAL_DICE_ONLY','action_id':case,'instante':instant,'estado':condition,'salvaguarda':verdict,'rolls':rolls}
        else:
            text=input('ROLAGENS ficticias separadas por virgula, ROLAR (reprodutivel), ou vazio = HOLD: ').strip()
            if text.upper()=='ROLAR':
                print('RECIBO: '+json.dumps(roll_fixture(case),ensure_ascii=False,sort_keys=True),flush=True)
                again=input('OUTRA ACAO? [S/N]: ').strip().upper()
                if again!='S':break
                continue
            try:rolls=[int(x.strip()) for x in text.split(',')] if text else None
            except ValueError:rolls=[]
            event={'mode':'DOCUMENTAL_DICE_ONLY','action_id':case,'rolls':rolls}
        print('RECIBO: '+json.dumps(calculate(event),ensure_ascii=False,sort_keys=True),flush=True)
        again=input('OUTRA ACAO? [S/N]: ').strip().upper()
        if again!='S':break
    print('SOMENTE FIXTURES; NENHUMA ESCRITA OFICIAL',flush=True)


def main():
    cli=argparse.ArgumentParser(description='DMG R29 cientista: calculo pelo chat em fontes canonicas, sem runtime oficial')
    g=cli.add_mutually_exclusive_group()
    g.add_argument('--catalog',action='store_true')
    g.add_argument('--prepare',type=str)
    g.add_argument('--json',type=str,help='JSON com entrada fornecida ao vivo pelo Mestre')
    g.add_argument('--input',type=Path,help='JSON de entrada em arquivo')
    g.add_argument('--interactive',action='store_true')
    g.add_argument('--roll',type=str,help='ROLA fixture explicitamente: somente caso de fonte com dado; sem ataque historico')
    cli.add_argument('--seed',type=str,help='Hex seed para reproduzir --roll; omitida, gera semente de SO gravada no recibo')
    args=cli.parse_args()
    if args.seed and not args.roll:
        cli.error('--seed só pode ser usada com --roll')
    if args.catalog:
        print(json.dumps({key:prepare(key) for key in list(CASES)+[BLEED_ID]},indent=2,ensure_ascii=False,sort_keys=True));return
    if args.prepare:out=prepare(args.prepare.upper())
    elif args.roll:out=roll_fixture(args.roll.upper(),args.seed)
    elif args.json:
        try:out=calculate(json.loads(args.json))
        except json.JSONDecodeError as e:out=rejection(args.json,'INVALID_JSON:'+str(e))
    elif args.input:
        try:out=calculate(json.loads(args.input.read_text(encoding='utf8')))
        except (OSError,json.JSONDecodeError) as e:out=rejection(str(args.input),'INVALID_INPUT_FILE:'+str(e))
    elif args.interactive:
        interactive();return
    else:
        cli.print_help();return
    print(json.dumps(out,indent=2,ensure_ascii=False,sort_keys=True))
if __name__=='__main__':main()
