import unittest,subprocess,sys,json,copy
from pathlib import Path
from verificador_r29 import ROOT,REG,CASES,BLEED_ID,prepare,calculate,roll_fixture,STATUS_ALLOW,STATUS_HOLD,STATUS_REJECT,parent


def make(action,rolls,**kw):
    return {'mode':'DOCUMENTAL_DICE_ONLY','action_id':action,'rolls':rolls,**kw}
class R29Tests(unittest.TestCase):
    def test_all_registry_cases_have_source(self):
        for key,val in CASES.items():
            with self.subTest(key=key):
                self.assertIn(val['source'],REG['sources']);self.assertIn(val['profile'],REG['profiles'])
    def test_all_source_urls_not_party(self):
        for key,val in REG['sources'].items():
            self.assertTrue(val['url'].startswith('https://app.notion.com/p/'))
    def test_compiler_covers_all_cases(self):
        for key in list(CASES)+[BLEED_ID]:
            p=prepare(key)
            self.assertEqual(p['catalog_decision'],STATUS_ALLOW)
            self.assertEqual(p['combat_decision'],'DENY_UNFROZEN_SCENE')
            self.assertGreaterEqual(len(p['full_action_missing']),2)
            self.assertEqual(p['contract_mode'],'DOCUMENTAL_DICE_ONLY')
    def test_original_B05_inventory_bounded_and_no_certification(self):
        doc=json.loads((ROOT/'INVENTARIO_B05_R29.json').read_text())
        self.assertEqual(doc['inventory_candidates_documented'],43)
        self.assertEqual(doc['profiles_count'],6)
        self.assertEqual(doc['documental_components_executable'],10)
        self.assertEqual(doc['B05_whole_gate'],'PARTIAL_NOT_CERTIFIED')
        self.assertEqual(len(doc['rows']),43)
    def test_original_Liu_Macaco_not_ignored(self):
        doc=json.loads((ROOT/'INVENTARIO_B05_R29.json').read_text())
        self.assertEqual(doc['counts_by_profile']['MACACO_P5'],6)
        self.assertEqual(doc['counts_by_profile']['LIU_NORMAL'],16)
        self.assertEqual(doc['counts_by_profile']['LIU_TRANSFORMADA'],4)
    def test_dragon_A_FOR_enabled_from_literal(self):
        r=calculate(make('DRAGAO_A_ESMAGA_CRANIO',[2,3,4,5]));self.assertEqual(r['result']['raw_damage'],50)
        self.assertEqual(r['authorized_parts'][0]['authorization'],'4d6 + For')
    def test_dragon_B_FOR_distinct(self):
        r=calculate(make('DRAGAO_B_ESMAGA_CRANIO',[2,3,4,5]));self.assertEqual(r['result']['raw_damage'],74)
        self.assertEqual(r['authorized_parts'][0]['value'],60)
    def test_dragon_exact_forms_not_mixed(self):
        a=calculate(make('DRAGAO_A_ESMAGA_CRANIO',[1,1,1,1]));b=calculate(make('DRAGAO_B_ESMAGA_CRANIO',[1,1,1,1]));self.assertEqual(a['result']['raw_damage'],40);self.assertEqual(b['result']['raw_damage'],64);self.assertNotEqual(a['provenance']['source_url'],b['provenance']['source_url'])
    def test_dragon_manual_for_cross_rejected(self):
        e=make('DRAGAO_A_ESMAGA_CRANIO',[1]*4,FOR=60)
        self.assertEqual(calculate(e)['status'],STATUS_REJECT)
    def test_jaku_base_legacy_adapter(self):
        r=calculate(make('JAKU_LANCA_INTRINSECA',[3,6]));self.assertEqual(r['result']['raw_damage'],11)
        self.assertIsNotNone(r['parent_r28_receipt_hash'])
    def test_jaku_for22_rejected(self):
        self.assertEqual(calculate(make('JAKU_LANCA_INTRINSECA',[3,6],FOR22=22))['status'],STATUS_REJECT)
    def test_jaku_bonus_ff_and_gloves_rejected(self):
        for key in ['FF_bonus','manoplas_ativas','infusao','ca','HP_depois']:
            with self.subTest(key=key):self.assertEqual(calculate(make('JAKU_LANCA_INTRINSECA',[3,6],**{key:True}))['status'],STATUS_REJECT)
    def test_bleed_failure_separate(self):
        r=calculate(make(BLEED_ID,[4],instante='INICIO_TURNO_DA_VITIMA',estado='SANGRANDO',salvaguarda='FALHA'))
        self.assertEqual(r['result']['raw_status_damage'],4)
        self.assertIsNone(r['result']['isolated_impact_damage'])
        self.assertEqual(r['result']['status_after'],'SANGRANDO')
        self.assertEqual(r['result']['time'],'INICIO_TURNO_DA_VITIMA')
    def test_bleed_success_separate(self):
        r=calculate(make(BLEED_ID,[],instante='INICIO_TURNO_DA_VITIMA',estado='SANGRANDO',salvaguarda='SUCESSO'))
        self.assertEqual(r['result']['raw_status_damage'],0)
        self.assertEqual(r['result']['status_after'],'ESTABILIZADO')
    def test_bleed_trigger_wrong(self):
        r=calculate(make(BLEED_ID,[4],instante='IMPACTO',estado='SANGRANDO',salvaguarda='FALHA'))
        self.assertEqual(r['status'],STATUS_REJECT)
    def test_bleed_missing_save_hold(self):
        self.assertEqual(calculate(make(BLEED_ID,[4],instante='INICIO_TURNO_DA_VITIMA',estado='SANGRANDO'))['status'],STATUS_HOLD)
    def test_bleed_unknown_condition_rejected(self):
        self.assertEqual(calculate(make(BLEED_ID,[4],instante='INICIO_TURNO_DA_VITIMA',estado='NAO_SANGRANDO',salvaguarda='FALHA'))['status'],STATUS_REJECT)
    def test_bleed_success_must_not_roll(self):
        self.assertEqual(calculate(make(BLEED_ID,[6],instante='INICIO_TURNO_DA_VITIMA',estado='SANGRANDO',salvaguarda='SUCESSO'))['status'],STATUS_REJECT)
    def test_monkey_impact(self):
        r=calculate(make('MACACO_PATADA',[3,5]));self.assertEqual(r['result']['raw_damage'],62)
        self.assertEqual(r['damage_type_literal'],'IMPACTO')
        self.assertIn('TITANIC_FORCE_PLUS2',r['excluded_components'])
    def test_monkey_piercing(self):
        r=calculate(make('MACACO_MORDIDA',[4]));self.assertEqual(r['result']['raw_damage'],58)
        self.assertEqual(r['damage_type_literal'],'PERFURANTE')
    def test_monkey_untagged_power(self):
        r=calculate(make('MACACO_PODER_ELEMENTAL_BASE',[7]));self.assertEqual(r['result']['raw_damage'],37)
        self.assertIsNone(r['damage_type_literal']);self.assertIn('10 PA',r['resource_cost_documented'])
        self.assertFalse(r['resource_actual_commit'])
    def test_monkey_no_ice_inherit(self):
        r=calculate(make('MACACO_PODER_ELEMENTAL_BASE',[7]))
        self.assertIn('GELO_POR_EMOJI_PARENTAL',r['excluded_components'])
    def test_monkey_plus2_passive_rejected(self):
        r=calculate(make('MACACO_PATADA',[3,5],titanic_force=True));self.assertEqual(r['status'],STATUS_REJECT)
    def test_liu_axe_intrinsic(self):
        r=calculate(make('LIU_MACHADO_BASE',[1,3,5,7,9]));self.assertEqual(r['result']['raw_damage'],25)
        self.assertIsNone(r['damage_type_literal'])
    def test_liu_axe_explicit_plus2_separately(self):
        r=calculate(make('LIU_MACHADO_CRUEL_CERTEIRA_PARCELA',[]))
        self.assertEqual(r['result']['raw_isolated_modifier'],2)
        self.assertIsNone(r['result']['raw_damage'])
        self.assertIn('NO_DOUBLE_COUNT',r['full_action_missing'])
    def test_liu_axe_electric_rider(self):
        r=calculate(make('LIU_MACHADO_INFUSAO_ELETRICA_PARCELA',[2,4,6]))
        self.assertEqual(r['result']['raw_damage'],18)
        self.assertEqual(r['damage_type_literal'],'ELETRICO_LITERAL')
        self.assertIn('LIGHTNING_EQUIVALENCE',r['excluded_components'])
    def test_liu_rider_not_auto_stack(self):
        r=calculate(make('LIU_MACHADO_BASE',[1,3,5,7,9],extra_electric_damage=18))
        self.assertEqual(r['status'],STATUS_REJECT)
    def test_dice_missing_is_hold(self):
        r=calculate({'mode':'DOCUMENTAL_DICE_ONLY','action_id':'MACACO_PATADA'})
        self.assertEqual(r['status'],STATUS_HOLD);self.assertIsNone(r['raw_damage'])
    def test_dice_none_is_hold(self):
        self.assertEqual(calculate(make('MACACO_PATADA',None))['status'],STATUS_HOLD)
    def test_missing_source_case_rejected(self):
        self.assertEqual(calculate(make('DRAGAO_OURO7',[1]))['status'],STATUS_REJECT)
    def test_bad_roll_count_rejected(self):
        self.assertEqual(calculate(make('MACACO_PATADA',[1]))['status'],STATUS_REJECT)
    def test_bad_die_or_type_rejected(self):
        for v in [0,7,True,'4',None,-1,1.5]:
            with self.subTest(v=v):self.assertEqual(calculate(make('MACACO_PATADA',[1,v]))['status'],STATUS_REJECT)
    def test_dice_fixed_modifier_zero(self):
        self.assertEqual(calculate(make('LIU_MACHADO_CRUEL_CERTEIRA_PARCELA',None))['status'],STATUS_HOLD)
    def test_fake_resource_commit_rejected(self):
        self.assertEqual(calculate(make('MACACO_PODER_ELEMENTAL_BASE',[6],PA_pago=True))['status'],STATUS_REJECT)
    def test_strict_and_hypothetical_rejected(self):
        for mode in ['STRICT','PRODUCTION','HYPOTHETICAL']:
            with self.subTest(m=mode):self.assertEqual(calculate({'mode':mode,'action_id':'MACACO_PATADA','rolls':[1,2]})['status'],STATUS_REJECT)
    def test_no_official_changes_any_source(self):
        for key in list(CASES)+[BLEED_ID]:
            rolls=[1]*CASES[key]['dice']['count'] if key in CASES else [1]
            e=make(key,rolls,**({'instante':'INICIO_TURNO_DA_VITIMA','estado':'SANGRANDO','salvaguarda':'FALHA'} if key==BLEED_ID else {}))
            r=calculate(e)
            self.assertFalse(r['historic_combat']);self.assertEqual(r['STRICT'],'DENY');self.assertEqual(r['write'],'DENY')
            self.assertEqual(r['B05'],'PARTIAL_NOT_CERTIFIED');self.assertIsNone(r['result']['HP_after'])
    def test_provenance_and_hash_receipt(self):
        e=make('MACACO_PATADA',[2,5])
        r=calculate(e)
        self.assertEqual(r['receipt_hash'],parent.sha({k:v for k,v in r.items() if k!='receipt_hash'}))
        self.assertTrue(r['provenance']['source_url'].startswith('https://app.notion.com/p/'))
        self.assertEqual(r['input_fixture'],e)
    def test_receipt_repeat_is_identical(self):
        e=make('MACACO_PATADA',[3,5])
        self.assertEqual(calculate(e)['receipt_hash'],calculate(copy.deepcopy(e))['receipt_hash'])
    def test_different_roll_changes_hash(self):
        self.assertNotEqual(calculate(make('MACACO_PATADA',[3,5]))['receipt_hash'],calculate(make('MACACO_PATADA',[4,5]))['receipt_hash'])
    def test_chat_incremental_two_runs_not_prescripted(self):
        s='MACACO_PATADA\n2,5\nS\nLIU_MACHADO_BASE\n1,2,3,4,5\nN\n'
        r=subprocess.run([sys.executable,'-u',str(ROOT/'verificador_r29.py'),'--interactive'],input=s,text=True,capture_output=True,timeout=8)
        self.assertEqual(r.returncode,0, r.stderr)
        self.assertEqual(r.stdout.count('RECIBO:'),2)
        self.assertIn('MACACO_PATADA',r.stdout);self.assertIn('LIU_MACHADO_BASE',r.stdout)
        self.assertIn('"raw_damage": 61',r.stdout);self.assertIn('"raw_damage": 15',r.stdout)
    def test_chat_hold_no_roll(self):
        s='MACACO_PATADA\n\nN\n'
        r=subprocess.run([sys.executable,'-u',str(ROOT/'verificador_r29.py'),'--interactive'],input=s,text=True,capture_output=True,timeout=8)
        self.assertEqual(r.returncode,0,r.stderr);self.assertIn(STATUS_HOLD,r.stdout)
    def test_cli_json_dynamic_input(self):
        e=json.dumps(make('MACACO_MORDIDA',[6]))
        r=subprocess.run([sys.executable,str(ROOT/'verificador_r29.py'),'--json',e],capture_output=True,text=True,timeout=8)
        self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(json.loads(r.stdout)['result']['raw_damage'],60)
    def test_roll_seed_replay(self):
        seed='0123456789abcdef0123456789abcdef'
        a=roll_fixture('MACACO_PATADA',seed);b=roll_fixture('MACACO_PATADA',seed)
        self.assertEqual(a['receipt_hash'],b['receipt_hash'])
        self.assertEqual(a['input_fixture']['rolls'],b['input_fixture']['rolls'])
        self.assertTrue(all(1<=x<=6 for x in a['input_fixture']['rolls']))
    def test_roll_seed_is_not_historical(self):
        r=roll_fixture('MACACO_MORDIDA','0123456789abcdef0123456789abcdef')
        self.assertTrue(r['fixture_rng']['not_historical_rolls'])
        self.assertIsNone(r['result']['applied_damage'])
        self.assertFalse(r['historic_combat'])
    def test_roll_auto_seed_recorded(self):
        r=roll_fixture('MACACO_PATADA');self.assertEqual(len(r['fixture_rng']['seed_hex']),32)
        self.assertEqual(r['receipt_hash'],parent.sha({k:v for k,v in r.items() if k!='receipt_hash'}))
    def test_roll_on_bleed_without_save_is_rejected(self):
        self.assertEqual(roll_fixture(BLEED_ID)['status'],STATUS_REJECT)
    def test_roll_malformed_seed_rejected(self):
        for seed in ['abc','xyz'*12,42,'00']:
            self.assertEqual(roll_fixture('MACACO_PATADA',seed)['status'],STATUS_REJECT)
    def test_roll_cli_in_chat(self):
        r=subprocess.run([sys.executable,str(ROOT/'verificador_r29.py'),'--roll','MACACO_PATADA','--seed','0123456789abcdef0123456789abcdef'],capture_output=True,text=True,timeout=8)
        self.assertEqual(r.returncode,0,r.stderr)
        v=json.loads(r.stdout)
        self.assertTrue(v['fixture_rng']['explicitly_requested'])
    def test_dynamic_roll_interactive(self):
        s='MACACO_PATADA\nROLAR\nN\n'
        r=subprocess.run([sys.executable,'-u',str(ROOT/'verificador_r29.py'),'--interactive'],input=s,text=True,capture_output=True,timeout=8)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('"fixture_rng"',r.stdout)
    def test_catalog_readable_cli(self):
        r=subprocess.run([sys.executable,str(ROOT/'verificador_r29.py'),'--catalog'],capture_output=True,text=True,timeout=8)
        self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(len(json.loads(r.stdout)),10)

if __name__=='__main__':unittest.main(verbosity=2)
