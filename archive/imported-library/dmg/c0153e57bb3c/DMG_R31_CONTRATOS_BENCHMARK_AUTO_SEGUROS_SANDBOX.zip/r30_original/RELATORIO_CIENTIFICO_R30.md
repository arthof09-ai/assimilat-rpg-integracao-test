# DMG R30 — Compilador experimental de ações legais

**OPERAÇÃO EXISTENTE:** `CM-000001 / OP-DMG-CORPUS-EMP-01` | **Natureza:** Mestre-side, sandbox documental, read-only Notion. **Data:** 14/10/2026.

## Resumo executivo

Foi implementado e executado um compilador tri-estado sobre snapshots experimentais de **Liu Xiaua (normal e transformada alternativa)** e **Macaco Rei (Prata 5, titã conforme página)**. R29/R28 permanecem importados sem edições no código histórico; R30 avalia orçamento e janelas, PA explicitamente documentado, alcance comprovado apenas em fixture, equipamentos e passivas; não resolve ataques reais. O catálogo legado R29 de 43 linhas foi preservado como origem. R30 adiciona 19 **aplicabilidades por perfil** de ações universais do Sistema de Combate, totalizando 62 linhas de análise. **62 não é o universo B05 terminal.**

## 1. Recuperação, ANTES e detecção de continuação

- R29 Mestre-side `DMG_R29_CORPUS_CHAT_B05_EXPERIMENTAL.zip` recuperado como bytes, SHA-256 `de1753a608a28b3fb1980c94a26c8ad8b130951e9e9b48969d1d510379e7224d` confere; 52 entradas, `testzip` sem corrupção.
- Dentro dele, R28 ZIP tem SHA-256 `85c4c9f2f62d1da5ca0661811e1ca0bc1d6003bd5bfb9b89db8ed054ea5d95f0`; aninhado R27 confere `b1fe89d8b5560779ec19ac7a5b16fa056eaa75d6633d61c786974c7c9fcbb096`. **R26 original não foi comparado como bytes nesta execução.**
- Pesquisa dirigida de Notion `DMG R30`, `DMG R31` e operação DMG não localizou checkpoint posterior correspondente. Não é prova global de inexistência, nem de ownership.
- B05 original R11: `Complete legal action loadouts and owned abilities for all actors not adjudicated`; `ACTION_INVENTORY`; teste de aceite `Compiler emits allowed/rejected action with explicit per-field provenance and atomic effect plan`. R26 mantém necessidade de **menu completo sob forma e estado de cena e aceitação pelo receptor**.

## 2. Fontes reabertas e autoridade

| Fonte | URL | Última edição observada, não epoch do combate |
|---|---|---|
| Macaco Rei Prata 5 (titã) | https://app.notion.com/p/301c2b324ede828caccb813d3979267a | 2026-10-01T18:00:42.589Z |
| Liu Xiaua, dois estados | https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010 | 2026-10-01T09:40:50.721Z |
| Sistema de Combate R1/R3/R4/R8/R9 | https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0 | 2026-10-07T23:51:04.971Z |
| IBX-90 | https://app.notion.com/p/3f8c2b324ede8111829bf629405e721c | 2026-10-13T13:43:08.074Z |

O título da ficha do Macaco informa `Prata 5 (titã)` e seu corpo `Rank Prata 5 (2d6)` e `FOR54`, com **Força Titânica +2 FOR** descrita; a inclusão de +2 nos valores impressos continua sem prova. B02 permanece PASS_DOCUMENTAL **somente no escopo histórico já reconhecido**, sem nova certificação. Liu normal tem FOR29, DES16, CON16, INT11; Liu transformada impressa tem FOR40, DES27, CON25, INT14. A segunda forma foi carregada como cenário **alternativo fictício**, nunca como ativação T9 comprovada.

**Limite de autoridade:** a ficha diz Patada `2d6+FOR` (Impacto), Mordida `1d6+FOR` (Perfurante), Poder Elemental `1d10+INT` e custo `10 PA` mas não define elemento ou tipo de ação do Poder. A regra geral faz ataque normal gastar Ação Padrão. Para a Patada e Mordida, elegibilidade PERMITIDA **somente para declaração no subconjunto** quando turno, orçamento e alcance corpo a corpo são explicitamente afirmados no fixture; **custo de PA não especificado não é custo zero**, e nenhum PA é debitado. Um combate produtivo exigirá política competente sobre custo/estado completo e event log.

## 3. Entrega A — Compilador de subconjunto

Pipeline: `43 fichas candidatas R29 (read-only) → crosswalk por ação/perfil/fonte → adicionar 19 aplicabilidades de ações universais → validar cena e forma contra atributos literais → orçamento e janela → equipamento/passiva/PA/alvo → PERMITIDA | PROIBIDA | PENDENTE → recibo determinístico SHA → opcional: encadear cálculo bruto R29 se elegível; opcional: preparar envelope de triagem VLAB sem envio.`

Regras de precedência: impedimento provado (`PROIBIDA`) precede falta de dados (`PENDENTE`); ausência de requisito não é interpretada como cumprimento; a ação só recebe `PERMITIDA` se todos os requisitos **implementados do subconjunto** forem cumpridos. R30 guarda as lacunas do **gate integral B05 separadamente**. Uma passiva, um modificador e uma reação possuem planos diferentes. Fonte nativa não congelada: `source_digest=null` no contrato de integração.

Ação física Macaco Prata5: a fonte habilita Patada/Mordida com FOR54 literal, **sem** somar passiva +2. O compilador não produz crítico, acerto, RD, mitigação ou Vida posterior. Poder Elemental: classe de ação, alcance e tipo elemental pendentes, mesmo com PA suficiente; mas PA insuficiente como condição impeditiva prova `PROIBIDA` antes de resolver demais lacunas.

Liu: Machado `5d12`, Cruel/Certeira `+2` e infusão `3d8+6` mantidos como **componentes distintos**. Propriedade sem arma equipada é `PROIBIDA`. Mesmo com equipamento hipoteticamente presente, débitos diários da arma e provas de ativação permanecem pendentes; soma automática proibida. Fúria (`HP <= metade`, `12 PA`) e Extensão normal (`30 PA`) exigem estado e ação legais antes da aplicação. T9 Prata (`Ação Completa`, `40 PA`, duração `1d6+1`) tem base normativa mas depende de Espírito, forma e ledger real; não houve aplicação de transformação. Forma transformada é variante de entrada distinta.

## 4. Resultados dos ensaios A–J

| Identificador | Dado de ensaio (fictício) | Saída real do compilador | Alcance da prova |
|---|---|---|---|
| A | Macaco, rodada 1, turno dele, Padrão disponível, alvo melee comprovado **no fixture** | Patada PERMITIDA | Somente declaração no subconjunto |
| B | Poder Elemental, PA disponível = 5, custo documental = 10 | PROIBIDA | Insuficiência decidida; sem debitar recursos |
| C | Poder Elemental, PA disponível `null` | PENDENTE | Sem presumir recurso suficiente |
| D | Liu normal vs Liu transformada **alternativa**, forma isolada | Menus diferentes, FOR29 vs FOR40 | Sem evento T9 e sem transposição de atributos |
| E | Força Titânica `+2` ao lado de FOR54 impressa | PENDENTE para empilhamento; Patada R29 `[3,5]` = 62, FOR54 apenas | Nenhuma dupla contagem |
| F | Liu sem machado equipado | Machado PROIBIDA | Equipamento interfere na elegibilidade; modifiers não autônomos |
| G | Defender no próprio turno; depois janela BEFORE_ENEMY_ATTACK; depois Reação gasta | PROIBIDA → PERMITIDA (declaração) → PROIBIDA | Sem uso de scheduler A1 |
| H | Patch manual de fixture `standard_consumed=true`, revisão 0→1 | Patada PERMITIDA → PROIBIDA; replay idempotente | Snapshot versionado local, **não** execução de ação |
| I | Envelope Patada para VLAB | `transport=NOT_SENT`, `source_digest=null`, NAC-PASS HOLD | Triagem apenas, nenhum ACK/consumo |
| J | Regressão de R29 e R28 | Python R29 50 PASS + R28 26 PASS | Matemática testada, nunca combate STRICT |

A execução de R30 passou em **43/43 testes novos**, abrangendo PA nulo/insuficiente, alvo e distância, forma, orçamento de reações, equipamento, passivas, revisão de estado, replay idempotente, colisão de ID, bloqueios oficiais, permissões de fonte e hash de recibo. Somados às regressões de R29/R28, **119/119 testes automatizados PASS**. Isso não constitui UAT humana do Mestre nem validação nativa do VLAB.

## 5. Entrega B — Matriz terminal B05 (inalterada em alcance)

Arquivo `documentos/MATRIZ_TERMINAL_B05_R30.json` tem 11 grupos de requisito: universo, fonte, forma/atributos, ativação, economia, custo, dados, componentes, temporalidade, alcance, aceite. Para **cada um** indica evidência parcial e lacuna. O compile de 62 entradas cobre 100% das **43 linhas do inventário dirigido R29** + 19 aplicabilidades de ações universais, **não uma fração conhecida do B05 global**. Sem ator real congelado, catálogo legal fechado, ledger de recursos e equipamento, geometria, status temporal, digest nativo e `reader acceptance`, o B05 permanece **PARTIAL**. Divisor do gate B05 total: **NÃO DETERMINÁVEL AINDA**. Não há novo PASS.

## 6. Fronteira B06

R30 valida a parte documental da economia: Ação Padrão consumida bloqueia Patada; Reação fora da janela e Reação consumida bloqueiam Defender; Ação Completa ocupada bloqueia ação; necessidade de custo10 PA é checada sem supor PA Livre; bônus D&D não mapeado. A classe especial de Poder Elemental, o timing de Extensão, itens e o scheduler A1 permanecem externos. Prova real de reação e de custo depende de VLAB e fonte ativa congelada; B06 **PARTIAL**. Leia `documentos/FRONTEIRA_B06_R30.json`.

## 7. Interoperabilidade IBX-90, sem recepção declarada

O envelope `recibos/I_intencao_VLAB_nao_enviada.json` oferece `scene_id`, `actor_id`, `source_id`, `source_digest` (intencionalmente `null`), `form_id`, `state_revision`, `action_id`, `action_type`, `eligibility`, `resource_requirements`, `target_requirements`, `temporal_window`, `effect_plan`, `unresolved_requirements`, `receipt_id`. O preenchimento não dispensa fonte nativa, status real, capa de PA, alvo e reação, ACK do receptor nem gate físico de escrita. **IBX-90 NOVA, sem INSTANCE-ID de leitura na consulta dirigida da base; não entregue, não presumido ACK.**

## 8. PSV / NAC-CONT-03 / NAC-NORM-01 / NAC-PASS

- **ANTES:** R29 com 43 candidatos em 6 perfis, 10 componentes matemáticos isolados, B05 e B06 PARTIAL; B01–B18 1/18 certificado; 9/18 PARTIAL, 6/18 BLOCKED, 2/18 NOT_TESTED; STRICT 0/2; I0003 0/9; B11/B12 0/5; IBX-90 sem ACK.
- **EXECUÇÃO:** cópia experimental, código histórico R29/R28 preservado; compilador tri-estado; 62 linhas de comparação (43 existentes + 19 universais); cenários A–J e 20 recibos; testes novos + regressão local. Nenhuma nova norma/proposta canônica, nenhuma Inbox duplicada.
- **DEPOIS:** B01–B18 **1/18 (5,56%)**; PARTIAL **9/18**, BLOCKED **6/18**, NOT_TESTED **2/18**; B05 PARTIAL e B06 PARTIAL; STRICT **0/2**; I0003 **0/9**; B11/B12 **0/5**; decisões DEC-BONUS-JAKU/DEC-INFUSION-JAKU e DEC-B11-A/B/C, DEC-B12-A/B em HOLD.
- **SEPARAÇÃO:** ChatGPT opera sandbox. DMG-RANK oficial, fichas, Party/O Primeiro, Diário e Notion **sem escrita**. Writer, lease, epoch, fencing, GREEN e NAC-PASS produtivo HOLD.
- **PRÓXIMO REQUISITO REAL:** B05, obter um snapshot de ator+forma para o encontro autorizado, com ações, equipamento, PA, alcance e fontes específicas aprovados pelo leitor competente; em paralelo fechar campos B06 de economia e reação ainda indefinidos. B18 não atacável produtivamente sem VLAB runtime apropriado. O progresso imediato deve ser consolidar o `ActionCatalog` do par original por legitimação documental/consumidor, **não** produzir outra calculadora ou scheduler.

## 9. Limites científicos e honestidade epistemológica

**Verificado fisicamente:** URLs consultadas em leitura, ZIP R29 e hashes aninhados R28/R27, compilador executado localmente, recibos e testes. **Inferido apenas em fixture:** alvo ao alcance, PA20 Macaco, equipado/ativo Liu, transformação alternativa; não são feitos narrativos. **Proposto:** envelope de interoperabilidade VLAB. **Pendente:** owner writer, Scene-ID histórico, source digest nativo, runtime ACK/ingest, eventos com hit/PA/HP e NAC-PASS.

Referências de histórico: matriz R11, matriz R26 e R29, preservados no pacote, são evidência científica anterior; arquivos e IDs não são recriados. R26 original não verificado como bytes nesta rodada.
