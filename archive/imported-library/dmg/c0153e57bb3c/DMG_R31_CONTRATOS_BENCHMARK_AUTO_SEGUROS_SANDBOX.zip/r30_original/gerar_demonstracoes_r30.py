"""Executa os cenários mandatórios A-J pelo compilador R30, guarda prova para replay."""
import copy,json,shutil
from pathlib import Path
import compilador_r30 as c
R=Path(__file__).parent
F=R/'fixtures';D=R/'recibos'
D.mkdir(exist_ok=True)
s0=json.loads((F/'01_macaco_turno.json').read_text())
s1=json.loads((F/'02_liu_normal.json').read_text())
s2=json.loads((F/'03_liu_transformada_alternativa.json').read_text())
def store(name,obj):
    p=D/(name+'.json');p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
    return p

def short(s,actor,action):
    m=c.compile_scene(s,actor)
    d=next(x for x in m['decisions'] if x['action_id']==s['actors'][actor]['form_id']+'::'+action)
    return {'scene_id':s['scene_id'],'state_revision':s['state_revision'],'actor_id':actor,
            'action':d,'menu_receipt_id':m['receipt_id'],'menu_sha256':m['content_sha256']}

store('A_patada_elegivel',short(s0,'macaco','PATADA'))
b=copy.deepcopy(s0);b['actors']['macaco']['pa_available']=5
store('B_poder_elemental_PA5_proibido',short(b,'macaco','PODER_ELEMENTAL'))
c0=copy.deepcopy(s0);c0['actors']['macaco']['pa_available']=None
store('C_poder_elemental_PA_desconhecido_pendente',short(c0,'macaco','PODER_ELEMENTAL'))
store('D_liu_normal_menu',c.compile_scene(s1,'liu'))
store('D_liu_transformada_menu',c.compile_scene(s2,'liu'))
store('E_forca_titanica_passiva_pendente',short(s0,'macaco','FORCA_TITANICA'))
store('E_patada_calculo_R29_encadeado',c.calculate_isolated(s0,'macaco','MACACO_P5::PATADA',[3,5]))
f=copy.deepcopy(s1);f['actors']['liu']['equipment']['axe_equipped']=False
store('F_liu_sem_machado_proibido',short(f,'liu','MACHADO_BASE'))
store('F_liu_infusao_ativacao_pendente',short(s1,'liu','MACHADO_INFUSAO'))
store('G_reacao_janela_errada',short(s0,'macaco','UNIVERSAL_REACAO_DEFENDER'))
g=copy.deepcopy(s0);g['scene'].update({'phase':'BEFORE_ENEMY_ATTACK','incoming_attack':True})
store('G_reacao_janela_ficticia_aberta',short(g,'macaco','UNIVERSAL_REACAO_DEFENDER'))
g2=copy.deepcopy(g);g2['actors']['macaco']['budget']['reaction_consumed']=True
store('G_reacao_ja_consumida',short(g2,'macaco','UNIVERSAL_REACAO_DEFENDER'))
# H: copia de snapshot em disco; solicitação manual incrementa revision (não simula gasto / PA).
p=F/'04_snapshot_apos_patch_manual.json'
p.write_text(json.dumps(s0,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
log=Path(str(p)+'.manual_journal.json')
if log.exists():log.unlink()
patch={'request_id':'R30-FIXTURE-H-001','expected_state_revision':0,'actor_id':'macaco',
       'changes':{'budget.standard_consumed':True}}
response=c.apply_manual_patch(p,patch)
store('H_alteracao_manual_snapshot',response)
new=json.loads(p.read_text())
store('H_menu_depois_snapshot',c.compile_scene(new,'macaco'))
store('H_idempotent_replay',c.apply_manual_patch(p,patch))
store('I_intencao_VLAB_nao_enviada',c.create_vlab_intent(s0,'macaco','MACACO_P5::PATADA'))
store('I_intencao_PODER_pendente_nao_enviada',c.create_vlab_intent(s0,'macaco','MACACO_P5::PODER_ELEMENTAL'))
store('J_hold_Liu_math_acao_pendente',c.calculate_isolated(s1,'liu','LIU_NORMAL::MACHADO_BASE',[1,3,5,7,9]))
store('J_rejeicao_dados_fora_escopo',c.calculate_isolated(s0,'macaco','MACACO_P5::PATADA',[9,3]))
allfiles=list(D.glob('*.json'))
summary={'schema':'DMG_R30_DEMOS_INDEX_v1','cases_written':len(allfiles),
         'source_guarded':True,'strict_events':0,'official_writes':0,
         'scenario_a':short(s0,'macaco','PATADA')['action']['eligibility'],
         'scenario_b':short(b,'macaco','PODER_ELEMENTAL')['action']['eligibility'],
         'scenario_c':short(c0,'macaco','PODER_ELEMENTAL')['action']['eligibility'],
         'scenario_g_before_attack':short(g,'macaco','UNIVERSAL_REACAO_DEFENDER')['action']['eligibility'],
         'scenario_h_after':next(x for x in c.compile_scene(new,'macaco')['decisions'] if x['name']=='PATADA')['eligibility'],
         'triage_sent':False}
(R/'INDICE_DEMONSTRACOES_R30.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
