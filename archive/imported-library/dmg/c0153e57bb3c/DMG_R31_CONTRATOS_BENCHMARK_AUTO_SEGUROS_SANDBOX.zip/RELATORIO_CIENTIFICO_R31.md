# DMG R31 — Fornecedor seguro de contratos para benchmarks automáticos

**Operação original:** `OP-DMG-CORPUS-EMP-01` · **Identidade lógica:** `CM-000001` · **classificação:** MESTRE-ONLY / SANDBOX / NÃO CANÔNICO  
**Data:** 2026-10-14 · **estado oficial:** B02 PASS_DOCUMENTAL somente; 1/18 B01–B18; B05 e B06 PARCIAL.  
**Sem escrita Notion, Party, O Primeiro, VLAB oficial; sem combate STRICT ou emissão de ACK.**

## 1. Checkpoint e recuperação

- Recuperado do armazenamento disponível: `DMG_R30_COMPILADOR_ACOES_LEGAIS_CHAT_SANDBOX.zip`, Biblioteca ID `libfile_f5835f779e9081919d0a1ff5875f5b2b`; SHA-256 **`ce79a7218956eadba6bf4687164618dbc9d4fee20c5122c6883d229800b60df6`**; ZIP/CRC íntegros. Cópia exata preservada em `R30_BASELINE_INTACTO.zip` e árvore inalterada em `r30_original/`.
- Cadeia aninhada de bytes verificada R30→R29→R28→R27: R29 `de1753a608a28b3fb1980c94a26c8ad8b130951e9e9b48969d1d510379e7224d`, R28 `85c4c9f2f62d1da5ca0661811e1ca0bc1d6003bd5bfb9b89db8ed054ea5d95f0`, R27 `b1fe89d8b5560779ec19ac7a5b16fa056eaa75d6633d61c786974c7c9fcbb096`.
- R30 96/96 entradas do manifesto original podem ser verificadas novamente e foram preservadas em ZIP binário íntegro. Não se reivindica integridade de R01–R26 históricos não presentes como bytes em R27–R30.
- Consulta dirigida ao Notion e Biblioteca não identificou checkpoint **DMG** R31 posterior antes da implementação. Não é uma alegação de busca exaustiva em todas as superfícies.
- Reabertas fichas Notion: Liu (`https://app.notion.com/p/0b4c2b324ede837cb6be818dc8e36010`), editada 2026-10-01 09:40:50Z; Macaco (`https://app.notion.com/p/301c2b324ede828caccb813d3979267a`), editada 2026-10-01 18:00:42Z; Sistema de Combate (`https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0`); DMG-RANK oficial (`https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e`); DMG-METHOD (`https://app.notion.com/p/3f3c2b324ede81ab8d8ec1c7cce760b3`). Os horários de edição não constituem epoch/fingerprint de cena nativa.

## 2. P0 — Risco semântico corrigido em contrato **novo**

Na intenção R30 já preservada, para `MACACO_P5::PATADA`: `eligibility=PERMITIDA`, `dispatchable_action=true`, `effect_plan.mode=NO_DISPATCH`, `source_digest=null`, `execution_status=TRIAGE_ONLY_NO_DISPATCH`. O sinal booleano podia induzir consumidor inseguro à falsa liberação. **Não se reescreveu o R30:** o fornecedor R31 remove `dispatchable_action` e nunca concede despacho por um campo A.

Cinco gates **independentes** são emitidos por ação:

| Gate | Domínio | Patada no fixture R31 |
|---|---|---|
| A | Legalidade da declaração, derivada **do compilador R30 não alterado** | `PERMITIDA` |
| B | Completude mecânica do efeito/condições | `INCOMPLETA` |
| C | Capacidade **atestada** do resolvedor nativo para a ação | `NAO_VERIFICADA` |
| D | Segurança de reserva/commit único/readback | `NAO_VERIFICADA` |
| E | Autoridade e congelamento de fonte/snapshot | `DOCUMENTAL_SANDBOX_APENAS`, digest nativo `null` |

**Resultado: `execution_authorization=DENY`, `ready_for_full_automatic_combat=false`**. Nenhuma combinação de R30 A verdadeiro com B–E pendentes autoriza consumo, ação, HP, PA, combate oficial ou benchmark completo. Declaração A não é suficiente para agendar. Valor ausente de custo permanece desconhecido, não zero. Booleanos extras de autorização inseridos pelo consumidor são rejeitados (`REJECT_UNKNOWN_OR_PRIVILEGE_ESCALATION_REQUEST_FIELDS`). Nenhum canal de autoatestado pelo fornecedor para C/D/E produtivos foi implementado.

## 3. P1 — API de consulta compilada e auditoria dos 62 contratos

Novo módulo **`fornecedor_benchmarks_r31.py`** chama `compilador_r30.compile_scene()` e lê as políticas R30 preservadas, sem recriar scheduler A1, regra de dano, fórmulas ou mecanismo de persistência de combate. Entrada: estado experimental de R30 e identidade de ator, modalidade `AUTO_BENCHMARK_SANDBOX`, `OFFICIAL_PREFLIGHT` ou `COMPONENT_MATH_PROBE_ONLY`. Saída: recibo de menu com hash reproduzível, razões A–E, classificação da entrada, `policy_considerable_actions`, `dispatch_authorized_actions=[]`, passivas e modificadores separados, janelas e orçamento, fonte e estado.

**Inventário original:** 62 entradas R30 intactas (= 43 candidatas documentais + 19 aplicabilidades universais). O universo de **B05** permanece o original, indeterminável sem congelar as fontes/cena/atores competentes. No recorte R31, 45/62 entradas foram avaliadas em três snapshots fictícios (Macaco P5, Liu normal, Liu transformada alternativa); 17/62 estão fora dos snapshots, **não classificadas como rejeitadas**, conforme `COBERTURA_62_ACOES_R31.csv`. Nenhuma das 45 vira ação integralmente despachável.

Menu experimental de Macaco: A=2 PERMITIDA (Patada e Mordida), 4 PROIBIDA (defesas fora de janela), 6 PENDENTE; `C/D/E` insuficientes e 0/12 despacháveis. Liu normal: A=1 PERMITIDA (passiva, que não é ataque), 10 PROIBIDAS, 12 PENDENTES; 0/23 despacháveis. Liu transformada alternativa: A=0 PERMITIDAS, 5 PROIBIDAS, 5 PENDENTES; 0/10 despacháveis. São contagens de linhas no snapshot, **não percentuais globais B05**.

- Patada `2d6 + FOR54`, tipo **IMPACTO**, e Mordida `1d6 + FOR54`, tipo **PERFURANTE**. R30 usava `IMPACT_IF_HIT_UNCALCULATED` também para Mordida: a R31 tipa explicitamente a Mordida conforme fonte e verificador R29, sem mudar o R30 histórico.
- Poder Elemental `1d10+INT30` e 10 PA: sem elemento definido, economia, alvo, alcance ou efeito completo. PA 5→**PROIBIDA**; PA desconhecido→**PENDENTE**; matemática bruta ainda é amostrada com referência, separadamente.
- Força Titânica +2 FOR: passiva isolada, sem soma automática à FOR54 impressa. Instinto Selvagem +4 em Iniciativa e Percepção: passiva de Liu, não ataque selecionável.
- Machado Liu: `5d12` parcela intrínseca; Cruel/Certeira `+2` e Infusão Elétrica `3d8+6` são parcelas associáveis a arma, nunca ataques isolados nem `rank do usuário = rank da arma`. Título `(ON)` do item é distinto de Liu Prata5 e de Rank de Efeito/FIP. Equipamento e compromisso de PA diário não reconciliados, sem autorização de golpe composto/crit.
- A forma transformada não injeta FOR40 na normal FOR29. Espírito/ativação/40 PA/epoch não foram materialmente reconfirmados.
- As reações só são declaráveis no instante documentado, se orçamento e gatilho declarados forem compatíveis, mas o DMG não aplica ação nem renova reação.

## 4. P2 — Calculadora documental **reutilizada**, sem resolvedor paralelo

O módulo de cálculo é o **R29 preservado**, acessado através do R30: `math_probe` chama diretamente `R30.v29.calculate(...)`. Cada recibo marca `CALCULO_ISOLADO`, `no_combat=true`, `HP_delta=null`, `PA_delta=null`, `action_dispatch=DENY`, roladas ficcionais e `source_digest=null`.

Fixture da Patada, dados `[3,5]`: resultado **bruto 62**, não dano aplicado, não ataque ocorrido. Fixture de Poder Elemental `[7]` produz **bruto 37**, sem tag elemental adjudicada. Um dado inválido `[9,5]` num pool `2d6` é recusado por R29 com `REJECTED_SOURCE_OR_POLICY` e **retransmitido por R31 como `REJECT_COMPONENT_R29`**, sem falso resultado. Essa foi uma correção de bug da própria camada R31 detectada na primeira bateria de testes; o motor R29 não foi alterado.

## 5. P3 — Ponte com VLAB: compatibilidade física negativa

Materializado, sem instalar ou alterar VLAB, o pacote **R23** da Biblioteca `libfile_b9343973ee908191be76cfebe03c741b`, SHA `e017b356719334de0c26b306c74bbae52de2ea5a6ccc8361137fb98b3c952ce3`. É posterior ao R22 informado originalmente na ordem e já representa `BENCHMARK_AUTO`. Seu código nativo (`vlab_r23_benchmark_auto.spec_validate` + `action_policy`) foi importado em **cópia local isolada somente para testes de preflight**. Resultados reproduzíveis em `recibos/NATIVO_R23_SCHEMA_NEGATIVE_RECEIPT.json`:

1. Spec técnica R23, `source_status=FICTITIOUS_LAB_ONLY`, cenário B/1 seed: **aceita** como configuração de benchmark fictício, sem executar o benchmark nesta rodada DMG.
2. Campo de contrato R31 inesperado: **HOLD `UNKNOWN_EXPERIMENT_FIELDS`**.
3. `source_status=CANONICAL_SOURCE`: **HOLD `CANONICAL_SOURCE_NOT_ADMITTED_FOR_FULL_FIGHT`**.
4. Envelope R31 submetido diretamente ao validador: **HOLD `UNKNOWN_EXPERIMENT_FIELDS`**.
5. Política R23 confrontada com `PATADA` não nativa em lista simulada: **HOLD `NO_EXECUTABLE_ACTION_MENU`**.

Portanto **não há ACK nem integração de ação DMG ao VLAB**. O validador R23 prova a lacuna concreta de adaptador: ele só aceita o contrato de specs técnicas que já conhece, não o envelope R31, e não admite fonte real nas batalhas técnicas. O adaptador proposto `build_bridge_request()` é interface de consulta, não um novo resolvedor. O R23 relatou 32 combates técnicos completos (16 primários +16 de sensibilidade) em 1 célula fictícia, **0 células canônicas**; nenhum destes 32 resultados é produzido ou certificado pela R31.

A IBX-90 real foi lida através da database `INBOX-COMESTRE-01`: ID 90, `NOVA`, destinatário `CM-000006`, `Lida por INSTANCE-ID` vazio, última edição 2026-10-13T13:43:08Z. Sem ACK e sem escrita. A ponte está `NOT_SENT`, consumidor id `null`. **A IBX-56 continua BLOCKED-EXTERNAL**, sem ação de engenharia nova nesta frente.

## 6. P4/P5 — Denominadores de balanceamento e taxonomia de dano

O DMG-METHOD e a matriz R23 separam `rank` × `estrela`, tipo de ator, fonte, forma, ação e modalidade. `COBERTURA_75_TIPO_RANK_ESTRELA_R31.csv` contém exatamente 5 ranks × 5 estrelas × 3 categorias de ator **=75 estratos de presença documental**; apenas **2/75** têm ao menos uma entidade documentada no **par original específico** (Liu Prata5, Macaco Titã Prata5), sem implicar amostragem de outras criaturas/ranks. Separadamente, a matriz central de confronto vigente do VLAB contém **625 ED×ED + 625 ED×BE + 625 BE×BE = 1.875 células**; elegíveis canônicas 0/1.875, executadas canônicas 0/1.875 (conforme R23, não recalculadas pela R31).

Os pedidos futuros 2vs1, 3vs1 e grupos equilibrados **não possuem o mesmo denominador de 1.875 definido para 1vs1**, e aparecem em lista separada sem percentuais inventados. O bench R23 reportou 32 corridas técnicas, 1 célula técnica fictícia; esses dados não se somam às 1.875 células canônicas.

Cada linha do catálogo R31 preserva origem, forma, janela, custo conhecido ou `UNKNOWN_NOT_ZERO`, alvo, contrato R29 local, tipo e distinção `rank usuário`, `rank do item`, `rank de efeito`, `FIP`, `estrelas`. Componentes diagnósticos distinguem dano da habilidade, arma intrínseca, atributo explícito, rider elétrico, crítico, elemental, passiva, mitigação, DOT e transformações. **Cálculo bruto de componente não produz conclusão de balanceamento, DME aplicado, DPS por PA, vitória, regressão estatística ou mudança no DMG-RANK.**

## 7. J — Idempotência demonstrada no escopo correto

`adapter_local_apenas_probe_r31.py` recebe **somente recibos de cálculo isolado** que preservam `action_dispatch=DENY`, hashes locais, sem HP/PA ou combate. Em memória: uma primeira leitura gera `ACCEPTED_MATH_PROBE_ONLY`; replay da mesma chave retorna `REPLAY_NO_ADDITIONAL_PROCESSING`, **1 processamento único em 2 chamadas**. Ele rejeita recibo adulterado e envelope VLAB. **Não é ack ou commit nativo**, não comprova transação distribuída ou idempotência de ação real. A proteção de R23 não foi modificada.

## 8. Testes e aceites

- R31 **53/53 testes** novos, após correção de propagação de rejeição do R29. Cobrem A–L, separação de passiva/modificador, cinco gates, custos/PA, forma, janela, anti-falsificação de flags, fonte sem digest, idempotência local de prova e compatibilidade do contrato.
- R30 **43/43 regressões**, R29 **50/50**, R28 **26/26** reaproveitadas, scripts originais inalterados: somatório **172/172 verificações de unidade**, sem contagem dupla de testes. Prova adicional de **5 ensaios de preflight direto R23** (1 aceite técnico e 4 HOLD), **fora** do denominador de 172.
- R30 baseline recuperado; R29/R28/R27 ZIP aninhados hash idênticos, arquivo original não alterado.
- B05 e B06 **não** passam ao status PASS. Não há aceitação do catálogo em cena real, adaptação ao motor nativo, contrato de efeito completo, política de PA, fonte congelada ou recibo transacional. Os cinco gates recusam despacho automático sobre o original par Liu × Macaco.

## 9. Comparação R30→R31

| Controle | R30 | R31 | Natureza |
|---|---|---|---|
| Triagem de declaração | Triestado | Triestado preservado | Regressão |
| Triagem de completude/nativo/transação/fonte | Confundida no booleano `dispatchable_action` | **5 gates independentes** | **Delta funcional principal** |
| Fórmulas R29 | 10 parcelas preservadas | 10 parcelas preservadas | Sem reconstrução |
| Catálogo histórico | 62 entradas | 62 preservadas; 45 contextualizadas em três snapshots | Cobertura, sem diluir aceite |
| Ações realmente despacháveis do par | 0 comprovadas | **0/45 linhas avaliadas** | HOLD competente |
| Consultas reproduzíveis | Menus/intents | **Menus + preflight + bridge + maths probes** | API utilizável |
| Teste com consumidor nativo | Nenhum | **R23 valida spec fictícia, rejeita envelope e real source** | Compatibilidade NEGATIVA comprovada |
| ACK do VLAB para DMG | 0 | 0 | Não enviar sem gate |
| Certificados B01–B18 | 1/18 | 1/18 | Sem promoção |

## 10. PSV e ponto de retomada exato

**ANTES:** R30 sabia declarar ações de fixture, e um campo `dispatchable_action=true` podia ser confundido com execução apesar de `NO_DISPATCH`. 119/119 testes históricos relatados. **DEPOIS:** R31 fornece consultor de cinco gates fail-closed e envelope de benchmark com `authorized_dispatch_ids=[]`, 172/172 testes novos + herdados, e rejeição comprovada no validador nativo R23; nunca declara resultado de combate ou integração.

**Estado oficial sem mudança:** B01–B18 1/18 (5,56%), PARTIAL 9, BLOCKED 6, NOT_TESTED 2; B05/B06 PARTIAL; STRICT 0/2; CSV I0003 originais 0/9; DEC-B11-A/B/C e DEC-B12-A/B 0/5 aprovadas; DEC-BONUS-JAKU-01/DEC-INFUSION-JAKU-01 ainda pendentes; VLAB 0/17 contratos terminais; IBX-90 NOVA/sem ACK; IBX-56 BLOCKED-EXTERNAL; DMG-RANK v1.1 oficial inalterado; Party e O Primeiro 0 escritas; writer/lease/epoch/fencing/GREEN/NAC-PASS produtivo HOLD. Não foi criada operação/Inbox/página nova.

**Ponto exato de retomada:** 1. CM-000006 precisa reconhecer a IBX-90 e produzir **contrato de pré-flight de ingestão de ação canônica** ou declarar incompetência do atual resolvedor, com ID de build e readback; 2. confirmar identidade, source-native digest, forma, contexto/estado, PA/alcance/custos/reação e componentes de **uma** ação priorizada sem premissas fictícias; 3. somente então avaliar suportes C, D e E com documentos nativos e gates de execução; 4. VLAB executa — se autorizado — um evento/replay nativo e registra recibo; 5. DMG reabre o recibo para auditar B05/B06; sem execução, não há promoção. O objetivo prioritário do próximo passo é primeira célula de fonte real do benchmark, não retornar à interação turno a turno.

**A classificação de fontes desta entrega:** VERIFICADOS bytes R30→R27, observações Notion, R23 ZIP e testes executados; RELATADOS resultados anteriores de 32 combates técnicos do VLAB R23 conforme relatório; PROPOSTO contrato R31 para consumidor; PENDENTES autoridade/integração/aceite produtivos.
