# PSV DMG R31 — OP-DMG-CORPUS-EMP-01

**AS-OF:** 2026-10-14 · CM-000001 · Mestre-only · sandbox.

| Métrica | Denominador | Estado verificado |
|---|---:|---:|
| Arquivo R30 + cadeia R29/R28/R27 | 4 hashes | 4/4 coincidentes com esperados |
| Manifesto original R30 | 96 entradas | 96/96 preservadas (validação local) |
| Catálogo original | 62 linhas | 62/62 preservadas |
| Linhas avaliadas no snapshot original do par e forma alternativa | 62 | 45/62 (17 sem estado selecionado) |
| Componentes R29 ligados ao catálogo | 62 | 10/62 isoladamente calculáveis, NÃO ações completas |
| Componentes R29 para original Liu/Macaco | 6 contratos | 6/6 preservados |
| Ações do subconjunto integralmente seguras para VLAB | 45 linhas avaliadas | 0/45 |
| Testes de R31 | 53 | 53/53 |
| Regressão R30/R29/R28 | 119 | 119/119 |
| Testes combinados | 172 | 172/172, suites separadas |
| R23 teste de pré-flight real do validador | 5 | 5/5 comportamento esperado (1 spec fictícia aceita; 4 HOLD) |
| Tipo de ator × rank × estrela na grade exploratória do par | 75 | 2/75 com fontes documentais no par, 0 completos |
| Posições globais rank/estrela | 25 | 0/25 elegíveis canônicas no R23 |
| Células de confronto centrais pré-registradas R23 | 1.875 | 0/1.875 canônicas elegíveis e executadas |
| VLAB R23 corridas técnicas anteriores | 32 | 32 relatadas pelo VLAB R23; não executadas neste DMG |
| B01–B18 | 18 | 1/18 certificado, B05 e B06 PARCIAL |
| Combate STRICT / CSV original I0003 | 2 / 9 | 0/2 e 0/9 |
| Decisões B11/B12 | 5 | 0/5 |
| Contratos terminais VLAB | 17 | 0/17 |
| ACK IBX-90 | 1 | 0/1 comprovado; NOVA/INSTANCE-ID vazio |

**ANTES:** R30 continha `dispatchable_action=true` embora NO_DISPATCH. **DEPOIS:** cinco gates independentes e `execution_authorization=DENY`, envelope `NOT_SENT`, receptor R23 rejeita contrato diretamente; proibida qualquer interpretação booleana de autorização. Nenhum scheduler, resolvedor, escrituração ou execução de combate novo.

**UNKNOWN:** actor/forma/epoch produtivos, PA real, origem de poderes de Liu, geometria/proficiências/acerto, composição de dano, custo de ataque não especificado, capacidade nativa da ação, suporte de transação, digest competente e aceitação pelo VLAB. **PENDING DECISIONS:** B11-A/B/C, B12-A/B, BONUS-JAKU-01, INFUSION-JAKU-01.

**NEXT FRONTIER:** CM-000006 legitimar ACK de IBX-90 → declarar/adaptar uma ação documentada a contrato preflight nativo R23+ → obter fonte congelada com atributos/PA e prova de acerto/mitigação → teste autorizado nativo com idempotência/readback → auditoria B05/B06/NAC-PASS sem promover antes. IBX-56 BLOCKED-EXTERNAL independente, sem ação técnica repetida.

**OFFICIAL HOLD:** writer/lease/epoch/fencing/GREEN/NAC-PASS produtivo; B05/B06 PARCIAL; Party/O Primeiro/DMG-RANK intocados.
