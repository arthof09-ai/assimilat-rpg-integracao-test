# OP-DMG-CORPUS-EMP-01 — R31 / HANDOFF E RECUPERAÇÃO

**Leia primeiro `RELATORIO_CIENTIFICO_R31.md` e `PSV_R31.md`.** Esta entrega é sandbox Mestre-side, não autorização de execução/benchmark histórico nem DMG-RANK oficial.

## Entrega principal

`fornecedor_benchmarks_r31.py` fornece `COMPILE`, `CHECK_ACTION`, `BRIDGE_PREFLIGHT`, `COMPONENT_PROBE` com cinco gates independentes. **R30/R29/R28/R27 não foram alterados.** `adapter_local_apenas_probe_r31.py` demonstra somente leitura/idempotência de *componente matemático*, não commit de VLAB. `verificacao_consumidor_R23_LOCAL.py` testou **compatibilidade nativa negativa** de `spec_validate` e `action_policy` do R23 com a API DMG, sem executar batalha. Os 172 testes locais passaram (53+43+50+26).

## Integridade da linhagem

- R30 SHA `ce79a7218956eadba6bf4687164618dbc9d4fee20c5122c6883d229800b60df6` recuperado e contido em `R30_BASELINE_INTACTO.zip`.
- R29 SHA `de1753a608a28b3fb1980c94a26c8ad8b130951e9e9b48969d1d510379e7224d` aninhado em R30.
- R28 SHA `85c4c9f2f62d1da5ca0661811e1ca0bc1d6003bd5bfb9b89db8ed054ea5d95f0` aninhado em R29.
- R27 SHA `b1fe89d8b5560779ec19ac7a5b16fa056eaa75d6633d61c786974c7c9fcbb096` aninhado em R28.

A R31 também preserva a árvore original `r30_original/` e seus 96 hashes de conteúdo; demais versões mais antigas são históricas aninhadas quando fisicamente presentes, não certificadas integralmente aqui.

## Escopo físico

62 políticas originais, 45 contextualizadas em Macaco/Liu normal/transformada; 17 fora da cena analisada. B05 e B06 PARCIAL, 0 ações integralmente despacháveis. 10 calculadores isolados R29 preservados. `source_digest` nativo não conhecido, status C/D sem ACK de resolvedor/transação. **IBX-90 NOVA; nenhum ACK; writer e NAC-PASS HOLD.**

O VLAB R23 foi apenas referenciado, não incorporado ao ZIP DMG; SHA externo `e017b356719334de0c26b306c74bbae52de2ea5a6ccc8361137fb98b3c952ce3`, Biblioteca `libfile_b9343973ee908191be76cfebe03c741b`.

## Fronteira a retomar

Não inventar ação de combate nativa para Patada/Mordida. Abrir IBX-90 somente com identidade competente, confirmar API de preflight de ações do VLAB (atualmente schema R23 rejeita contrato DMG), selecionar uma fonte real e reunir custos, acerto, defesa, RD, estado, source-native hash, epoch e recibo de consumo único. Até então executar **somente provas de componente** e preflight local.
