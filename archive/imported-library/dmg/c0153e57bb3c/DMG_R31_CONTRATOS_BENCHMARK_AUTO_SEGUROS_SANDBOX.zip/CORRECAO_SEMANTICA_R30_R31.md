# Mudança de semântica R30 → R31 sem quebrar o histórico

R30 `recibos/I_intencao_VLAB_nao_enviada.json` declara uma **intenção**, com `eligibility=PERMITIDA`, `dispatchable_action=true`, `effect_plan.mode=NO_DISPATCH`, `source_digest=null`, `execution_status=TRIAGE_ONLY_NO_DISPATCH`. Não é executável apesar do booleano. A R31 **não altera o arquivo anterior**: qualquer consumidor deve ignorar `dispatchable_action` antigo; nada no R30 valida ingestão nativa.

Contrato R31: cinco gates A–E independentes por ação, `execution_authorization=DENY`, `ready_for_full_automatic_combat=false`, `effect_plan.type=PREVIEW_REQUIREMENTS_ONLY`, `transport=NOT_SENT`, `authorized_dispatch_ids=[]`. `automatic_policy_consideration=true` significa somente candidato de **avaliação**, nunca despacho. A futura autorização produtiva precisará de evidência externa do VLAB e das normas NAC; o produtor DMG não pode se autoatestar C/D e não forja digest nativo E.

Prova com o validador real R23: `spec_validate` reconhece apenas seu próprio schema fictício; contrato DMG R31 recebe `HOLD UNKNOWN_EXPERIMENT_FIELDS`; `source_status CANONICAL_SOURCE` recebe `HOLD CANONICAL_SOURCE_NOT_ADMITTED_FOR_FULL_FIGHT`; política não conhece `PATADA` fora de `ATTACK` e retorna `HOLD NO_EXECUTABLE_ACTION_MENU`. Ver `recibos/NATIVO_R23_SCHEMA_NEGATIVE_RECEIPT.json`.

**Aceite parcial bem delimitado:** R31 passa na produção de intenção segura sem falsear integração, não no consumo de ação real pelo VLAB. B05/B06 inalterados.
