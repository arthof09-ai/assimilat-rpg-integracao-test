#!/usr/bin/env python3
"""Emite recibos documentais + matriz técnica R31. Sem escrita em Notion/VLAB."""
import copy,csv,json,sys,hashlib
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import fornecedor_benchmarks_r31 as F
from adapter_local_apenas_probe_r31 import ReadOnlyMathProbeConsumer
R30=ROOT/'r30_original'
REC=ROOT/'recibos';DOC=ROOT/'documentos';REC.mkdir(exist_ok=True);DOC.mkdir(exist_ok=True)

def save(name,obj,folder=REC):
    path=folder/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    return obj

scene=json.loads((R30/'fixtures/01_macaco_turno.json').read_text(encoding='utf8'))
transform=json.loads((R30/'fixtures/03_liu_transformada_alternativa.json').read_text(encoding='utf8'))
menu_m=save('A_macaco_5_gates_menu.json',F.compile_actor(scene,'macaco'))
menu_l=save('F_liu_normal_menu.json',F.compile_actor(scene,'liu'))
menu_t=save('F_liu_transformada_menu.json',F.compile_actor(transform,'liu'))
pat=save('A_patada_5_gates.json',F.query_action(scene,'macaco','MACACO_P5::PATADA'))
mordida=save('A_mordida_5_gates.json',F.query_action(scene,'macaco','MACACO_P5::MORDIDA'))
passive=save('B_C_passivas_modificadores.json',F.seal({'schema':'OPDMG_R31_NON_ACTION_COMPONENTS_v1',
    'macaco_passives':menu_m['passives'],'liu_passives':menu_l['passives'],
    'liu_modifiers':menu_l['modifiers'],
    'attack_selector_excludes_all_passives':True,'attack_selector_excludes_all_modifiers':True,
    'forca_titanica_delta_to_FOR54':None,
    'cruel_certeira_parent_action_requirement':'MACHADO_EQUIPPED_AND_ACTIVE_PLUS_NO_DOUBLE_COUNT',
    'execution_authorization':'DENY'},'R31D-'))
low=copy.deepcopy(scene);low['actors']['macaco']['pa_available']=5
save('D_poder_PA5_proibido.json',F.query_action(low,'macaco','MACACO_P5::PODER_ELEMENTAL'))
unknown=copy.deepcopy(scene);unknown['actors']['macaco']['pa_available']=None
save('E_poder_PA_desconhecido.json',F.query_action(unknown,'macaco','MACACO_P5::PODER_ELEMENTAL'))
wrong=save('G_reacao_janela_errada.json',F.query_action(scene,'macaco','MACACO_P5::UNIVERSAL_REACAO_DEFENDER'))
opened=copy.deepcopy(scene);opened['scene'].update({'phase':'BEFORE_ENEMY_ATTACK','incoming_attack':True,'active_actor_id':'liu'})
save('G_reacao_janela_ficticia.json',F.query_action(opened,'macaco','MACACO_P5::UNIVERSAL_REACAO_DEFENDER'))
spent=copy.deepcopy(scene);spent['actors']['macaco']['budget']['standard_consumed']=True;spent['state_revision']=1
save('G_after_manual_action_budget_change.json',F.query_action(spent,'macaco','MACACO_P5::PATADA'))
save('H_modo_OFICIAL_fonte_sem_digest.json',F.query_action(scene,'macaco','MACACO_P5::PATADA','OFFICIAL_PREFLIGHT'))
save('I_resolvedor_nao_suportado_alegacao.json',F.query_action(scene,'macaco','MACACO_P5::PATADA',engine_claim='REPORTED_UNSUPPORTED'))
bridge=save('I_ponte_VLAB_NAO_ENVIADA.json',F.build_bridge_request(scene,'macaco','MACACO_P5::PATADA'))
probe=save('K_prova_componente_Macaco_Patada.json',F.math_probe(scene,'macaco','MACACO_P5::PATADA',[3,5]))
save('K_prova_componente_Macaco_Poder.json',F.math_probe(scene,'macaco','MACACO_P5::PODER_ELEMENTAL',[7]))
save('K_rejeicao_dado_d9_para_d6.json',F.math_probe(scene,'macaco','MACACO_P5::PATADA',[9,5]))
consumer=ReadOnlyMathProbeConsumer()
ack1=save('J_adapter_local_primeira_leitura.json',consumer.ingest('R31-LOCAL-STUB-01',probe))
ack2=save('J_adapter_local_replay_idempotente.json',consumer.ingest('R31-LOCAL-STUB-01',probe))
assert consumer.accepted_unique==1 and ack1['status']=='ACCEPTED_MATH_PROBE_ONLY' and ack2['status']=='REPLAY_NO_ADDITIONAL_PROCESSING'
save('L_r30_risco_semantico_preexistente.json',F.seal({'schema':'OPDMG_R31_LEGACY_R30_ENVELOPE_RISK_ANALYSIS',
      'old_R30_intent_preserved_not_overwritten':True,'old_R30_dispatchable_action':True,
      'old_R30_effect_plan_mode':'NO_DISPATCH','old_R30_source_digest':None,
      'old_R30_execution_status':'TRIAGE_ONLY_NO_DISPATCH',
      'new_R31_boolean_dispatchable_action':'REMOVED',
      'new_R31_auth':'DENY_UNTIL_FIVE_GATES_WITH_COMPETENT_EVIDENCE',
      'R30_baseline_SHA256':'ce79a7218956eadba6bf4687164618dbc9d4fee20c5122c6883d229800b60df6'},'R31D-'))

# Exhaustive policy coverage: 62 rows in unchanged R30; only 45 rows in selected R31 actor/form snapshots.
by_id={a['action_id']:a for m in (menu_m,menu_l,menu_t) for a in m['decisions']}
policy=F.R30.POLICY['actions']
fields=['action_id','source_id','source_url','profile','role','name','budget','timing','cost_pa','cost_kind',
        'target','linked_calculator','snapshot_context','declaration','mechanical_full','resolver_native_verified',
        'transaction_verified','source_native_frozen','full_auto_dispatch','capability_class','terminal_B05','terminal_B06']
rows=[]
for aid,a in sorted(policy.items()):
    d=by_id.get(aid)
    if d:
        declaration=d['gates']['A_declaracao']['status']
        snap='R31_ORIGINAL_PAIR_EXPERIMENTAL' if a['profile'] in ('MACACO_P5','LIU_NORMAL') else 'R31_TRANSFORM_FICTITIOUS'
    else:declaration='NAO_AVALIADA_SEM_CENA_R31';snap='NAO_SELECIONADO_NESTA_CENA'
    if d and declaration=='PROIBIDA':cls='CAPACIDADE_BLOQUEADA_POR_ESTADO'
    elif a.get('linked_calculator'):cls='CAPACIDADE_PARCIAL_COMPONENTE_R29'
    elif a['role'] in ('PASSIVE','ITEM_PASSIVE','WEAPON_MODIFIER','ELEMENTAL_RIDER'):
        cls='CAPACIDADE_PARCIAL_NAO_ACAO'
    else:cls='CAPACIDADE_NAO_DOCUMENTADA_O_SUFICIENTE'
    rows.append({'action_id':aid,'source_id':a['source_id'],'source_url':a['source_url'],
        'profile':a['profile'],'role':a['role'],'name':a['name'],'budget':a['budget'],
        'timing':a['timing'],'cost_pa':a['cost_pa'] if a['cost_pa'] is not None else 'UNKNOWN_NOT_ZERO',
        'cost_kind':a['cost_kind'],'target':a['target'],'linked_calculator':a.get('linked_calculator') or '',
        'snapshot_context':snap,'declaration':declaration,'mechanical_full':'NO',
        'resolver_native_verified':'NO','transaction_verified':'NO',
        'source_native_frozen':'NO','full_auto_dispatch':'NO',
        'capability_class':cls,'terminal_B05':'PARTIAL','terminal_B06':'PARTIAL'})
with (DOC/'COBERTURA_62_ACOES_R31.csv').open('w',encoding='utf8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

# R23 denominators are fixed by VLAB; do not replace them with DMG R31 actors.
rank=('Bronze','Prata','Ouro','Ouro Negro','Lendário')
star_rows=[]
for rank_name in rank:
    for star in range(1,6):
        for typ in ('ESPIRITUALISTA','BESTA_NORMAL','BESTA_TITA'):
            actor_refs=(['LIU_NORMAL','LIU_TRANSFORMADA_ALTERNATIVA'] if rank_name=='Prata' and star==5 and typ=='ESPIRITUALISTA' else
                        ['MACACO_P5'] if rank_name=='Prata' and star==5 and typ=='BESTA_TITA' else [])
            # Two forms of Liu do not count as two independent entity sources.
            star_rows.append({'rank':rank_name,'star':star,'actor_type':typ,
                  'documentary_actor_count':1 if actor_refs else 0,
                  'documentary_forms_seen':','.join(actor_refs),
                  'complete_mechanical_profiles':0,'native_vlab_dispatch_eligible':0,
                  'official_admission':0,'balance_verdict':'NAO_DETERMINAVEL'})
with (DOC/'COBERTURA_75_TIPO_RANK_ESTRELA_R31.csv').open('w',encoding='utf8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(star_rows[0]));w.writeheader();w.writerows(star_rows)

modes=[{'mode':x,'planned':625,'canonical_eligible':0,'canonical_run_credit':0} for x in ('EDxED','EDxBE','BExBE')]
coverage={
 'schema':'OPDMG_R31_BENCHMARK_COVERAGE_v1','scientific_reference':'DMG-METHOD-EMP-01; VLAB R23 reported predeclared matrix',
 'R23_Library_report':'libfile_595d52090fc081918e0efd848d798e34',
 'total_rank_star_positions':25,'actor_type_rank_star_strata_in_narrow_R31_grid':75,
 'strata_with_at_least_one_documented_entity_in_selected_original_pair':2,
 'distinct_documentary_source_entities_in_pair':2,
 'R31_evaluated_actor_form_snapshots':3,'R31_evaluated_catalog_rows':len(by_id),
 'catalog_total_rows_R30_unchanged':len(policy),
 'catalog_rows_out_of_R31_defined_snapshots':len(policy)-len(by_id),
 'R31_linked_R29_calculators_in_pair':sum(bool(a['r29_component_id']) for a in by_id.values()),
 'R31_linked_R29_calculators_across_62':sum(bool(a.get('linked_calculator')) for a in policy.values()),
 'R31_full_mechanic_actions_ready':0,
 'VLAB_R23_modes_predeclared':modes,'VLAB_R23_core_cells_total':1875,
 'VLAB_R23_canonical_eligible_cells':0,'VLAB_R23_canonical_runs':0,
 'VLAB_R23_technical_full_fights_reported':32,
 'VLAB_R23_technical_fixture_cells_reported':1,
 'VLAB_R23_native_support_reported_only': ['fictitious two actors','BASIC_ATTACK with 1d6 technical fixture',
       'DEFENDER conditional','reproducible seeded simulated combat','A1 scheduling without tie'],
 'VLAB_R23_not_supported_as_canonical_source_actors':['Macaco Rei','Liu Xiaua'],
 'additional_modes_outside_R23_core_matrix':[
     {'name':'2_Espiritualistas_vs_1_Besta','denominator':'NOT_PREDECLARED_AS_R23_CORE_CELL'},
     {'name':'3_Espiritualistas_vs_1_Besta','denominator':'NOT_PREDECLARED_AS_R23_CORE_CELL'},
     {'name':'grupos_equilibrados','denominator':'NOT_PREDECLARED_AS_R23_CORE_CELL'}],
 'no_balance_conclusion':True,'DMG_RANK_official_unchanged':True,
 'stratification_note':'Rank do usuário != Rank de Efeito; estrela != FIP; categoria de item != rank da pessoa.'}
save('COBERTURA_E_DENOMINADORES_BENCHMARK_R31.json',coverage,DOC)

# Matrix gates taken from R30, not rewritten or upgraded.
b05=json.loads((R30/'documentos/MATRIZ_TERMINAL_B05_R30.json').read_text(encoding='utf8'))
b06=json.loads((R30/'documentos/FRONTEIRA_B06_R30.json').read_text(encoding='utf8'))
terminal={'schema':'OPDMG_R31_B05_B06_DELTA_NO_PROMOTION',
 'B05_original_requirement':b05['original_requirement'], 'B05_gate':b05['original_gate'],
 'B05_status_before_after':['PARTIAL','PARTIAL'],'B05_terminal_denominator':'NÃO DETERMINÁVEL AINDA',
 'B05_outstanding':[x['missing'] for x in b05['requirements']],
 'B06_status_before_after':['PARTIAL','PARTIAL'],
 'R31_delta':'five independent execution gates, fail-closed VLAB proposal, no source-native acceptance',
 'B05_original_json_copy':'r30_original/documentos/MATRIZ_TERMINAL_B05_R30.json',
 'B06_original_json_copy':'r30_original/documentos/FRONTEIRA_B06_R30.json',
 'B06_critical_gap':'VLAB real event action/reaction window, resource ledger, current source/epoch; no independently verified native contract',
 'integral_acceptance':False,'NAC_PASS_prod':'HOLD'}
save('MATRIZ_B05_B06_FRONTEIRA_R31.json',terminal,DOC)

report={'schema':'OPDMG_R31_GATES_COUNTS_AND_RECIPTS','original_R30_sha':'ce79a7218956eadba6bf4687164618dbc9d4fee20c5122c6883d229800b60df6',
 'scenes':['macaco','liu normal','liu transformada ficticia alternativa'],
 'counts':{x['actor_id']+x['form_id']:x['summary'] for x in (menu_m,menu_l,menu_t)},
 'total_R31_catalog_rows_evaluated':len(by_id),'catalog_policy_total':len(policy),
 'R31_total_generated_json_receipts':len(list(REC.glob('*.json'))),
 'record_integrity_sha256_validation':'COMPONENT_IDS_HASHED_NOT_A_NATIVE_SOURCE_ATTESTATION',
 'R30_baseline_unchanged':True,'dispatch_count':0,'notion_write_count':0,
 'VLAB_native_event_count':0,'VLAB_native_ACK_count':0,
 'R29_component_probe_count':2,'stub_unique_receipt_ingestions':1,'stub_replay_count':1,
 'B05':'PARTIAL','B06':'PARTIAL'}
save('INDICE_EVIDENCIAS_R31.json',report,DOC)
print(json.dumps({'rows':len(rows),'evaluated':len(by_id),'star_rows':len(star_rows),'menu_counts':[x['summary'] for x in [menu_m,menu_l,menu_t]],'json_receipts':len(list(REC.glob('*.json')))},ensure_ascii=False,indent=2))
