#!/usr/bin/env python3
"""Adapter de teste em memória: prova de contrato de recibo e deduplicação.
NÃO é o consumidor VLAB, NÃO realiza ação de combate e NÃO é um scheduler/reducer.
Aceita exclusivamente recibo pré-calculado por R29 para experimento de matemática isolada.
"""
from __future__ import annotations
import copy,hashlib,json
from fornecedor_benchmarks_r31 import verify_seal,digest,seal

class ReadOnlyMathProbeConsumer:
    def __init__(self):self._seen={};self._count=0
    @property
    def accepted_unique(self):return self._count

    def ingest(self,request_id,probe):
        if not isinstance(request_id,str) or not request_id:
            return seal({'status':'REJECT','reason':'REQUEST_ID_REQUIRED','no_execution':True},'R31L-')
        if not isinstance(probe,dict) or probe.get('schema')!='OPDMG_R31_COMPONENT_PROBE_v1' or not verify_seal(probe):
            return seal({'status':'REJECT','reason':'ONLY_VALID_R31_COMPONENT_PROBE','no_execution':True},'R31L-')
        if probe.get('status')!='CALCULO_ISOLADO' or probe.get('action_dispatch')!='DENY' or probe.get('HP_delta') is not None or probe.get('PA_delta') is not None or probe.get('no_combat') is not True:
            return seal({'status':'REJECT','reason':'COMBAT_OR_EFFECT_REQUEST_FORBIDDEN','no_execution':True},'R31L-')
        key=(probe['scene_id'],probe['actor_id'],probe['state_revision'],probe['action_id'],request_id)
        previous=self._seen.get(key)
        if previous is not None:
            if previous['probe_receipt_hash']!=probe['content_sha256']:
                return seal({'status':'REJECT','reason':'IDEMPOTENCY_KEY_COLLISION','no_execution':True},'R31L-')
            result=copy.deepcopy(previous);result['status']='REPLAY_NO_ADDITIONAL_PROCESSING'
            return seal(result,'R31L-')
        ack={'schema':'OPDMG_R31_LOCAL_READONLY_STUB_ACK_v1','status':'ACCEPTED_MATH_PROBE_ONLY',
             'request_id':request_id,'key':list(key), 'probe_receipt_id':probe['receipt_id'],
             'probe_receipt_hash':probe['content_sha256'],'native_vlab':False,
             'A1_scheduler':False,'HP_delta':None,'PA_delta':None,
             'combat_action_applied':False,'reservation_or_commit':False,'no_execution':True,
             'note':'In-memory receipt/dedup test only, NOT VLAB ACK or transaction claim'}
        self._seen[key]=copy.deepcopy(ack);self._count+=1
        return seal(ack,'R31L-')
