#!/usr/bin/env python3
"""TESTE DE COMPATIBILIDADE DE API, não integração ou execução VLAB.
Exige cópia de leitura isolada do R23 externo; não está incluída no ZIP DMG.
"""
import argparse,hashlib,json,sys
from pathlib import Path

def digest(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def run(native_python_dir):
    sys.path.insert(0,str(native_python_dir))
    import vlab_r23_benchmark_auto as V
    base={'schema':V.VERSION,'case_id':'R31_TECHNICAL_FIXTURE_ONLY','scenario':'B',
          'source_status':'FICTITIOUS_LAB_ONLY','policies':['BASIC_ATTACK'],'seeds':[11],'max_rounds':2}
    out={'protocol':'R31_VLAB_R23_NATIVE_SCHEMA_PREFLIGHT_ONLY','consumer_version':V.VERSION,
         'external_r23_zip_sha256':'e017b356719334de0c26b306c74bbae52de2ea5a6ccc8361137fb98b3c952ce3',
         'consumer_R23_source_library_file_id':'libfile_b9343973ee908191be76cfebe03c741b',
         'native_schema_requests':[],'VLAB_combat_run':False,'native_receipt_of_action':None,
         'no_writes_VLAB':True,'no_native_ingest_R31_action':True,'strict':False}
    test_cases=[
      ('TECHNICAL_FIXTURE_VALIDATED',base),
      ('R31_EXTRA_CONTRACT_FIELD_REJECTED',{**base,'dispatch_gate':'DENY'}),
      ('CANONICAL_SOURCE_NOT_ADMITTED',{**base,'source_status':'CANONICAL_SOURCE'}),
      ('DMG_R31_ENVELOPE_DIRECT_REJECTED',{'protocol':'OPDMG_R31_TO_VLAB_AUTOMATED_BENCHMARK_QUERY_RESPONSE_v0.1_PROPOSED',
           'actor_id':'macaco','action_id':'MACACO_P5::PATADA','dispatch_gate':'DENY'})]
    for label,q in test_cases:
        try:
            rv=V.spec_validate(q)
            row={'case':label,'status':'ACCEPTED_TECHNICAL_SPEC_ONLY','source_status':rv.get('source_status')}
        except V.BenchmarkHold as e:row={'case':label,'status':'HOLD','reason':str(e)}
        out['native_schema_requests'].append(row)
    mock={'phase':'ACTIVE','active_actor':'macaco',
           'available':[{'action':'PATADA','actor':'macaco','target':'liu','standard_required':1}]}
    try:
        c=V.action_policy(mock,'BASIC_ATTACK')
        out['real_action_id_not_in_native_menu']={'status':'UNEXPECTED','result':c}
    except V.BenchmarkHold as e:
        out['real_action_id_not_in_native_menu']={'status':'HOLD','reason':str(e)}
    out['receipt_id']='R31N-'+digest(out)[:24]
    out['content_sha256']=digest(out)
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--native-python-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();res=run(a.native_python_dir)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True))
