#!/usr/bin/env python3
"""Testes A-L e redteam de fail-closed; nenhuma transação VLAB."""
import copy,json,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import fornecedor_benchmarks_r31 as F
from adapter_local_apenas_probe_r31 import ReadOnlyMathProbeConsumer

class GatesR31(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scene=json.loads((ROOT/'r30_original/fixtures/01_macaco_turno.json').read_text())
        cls.liu_form=json.loads((ROOT/'r30_original/fixtures/03_liu_transformada_alternativa.json').read_text())
    def menu(self,state=None,actor='macaco',mode='AUTO_BENCHMARK_SANDBOX'):
        return F.compile_actor(copy.deepcopy(state or self.scene),actor,mode)
    def action(self,aid,state=None,actor='macaco',mode='AUTO_BENCHMARK_SANDBOX'):
        return next(a for a in self.menu(state,actor,mode)['decisions'] if a['action_id']==aid)

    # A: demonstrar distintamente os cinco gates.
    def test_A_patada_declared_not_executable(self):
        a=self.action('MACACO_P5::PATADA');g=a['gates']
        self.assertEqual(g['A_declaracao']['status'],'PERMITIDA')
        self.assertEqual(g['B_completude']['status'],'INCOMPLETA')
        self.assertEqual(g['C_resolvedor']['status'],'NAO_VERIFICADA')
        self.assertEqual(g['D_transacao']['status'],'NAO_VERIFICADA')
        self.assertEqual(g['E_autoridade_fonte']['status'],'DOCUMENTAL_SANDBOX_APENAS')
        self.assertEqual(a['execution_authorization'],'DENY')
        self.assertFalse(a['ready_for_full_automatic_combat'])
    def test_A_no_dispatchable_boolean(self):
        s=json.dumps(F.build_bridge_request(self.scene,'macaco','MACACO_P5::PATADA'))
        self.assertNotIn('dispatchable_action',s)
        self.assertIn('"dispatch_gate": "DENY"',s)
    def test_A_menu_policy_only_not_native_ready(self):
        m=self.menu();self.assertEqual(m['summary']['policy_considerable_not_dispatchable'],2)
        self.assertEqual(m['dispatch_authorized_actions'],[])
    def test_A_mordida_damage_type_documented(self):
        a=self.action('MACACO_P5::MORDIDA')
        self.assertEqual(a['diagnostics']['components'][0]['damage_type_literal'],'PERFURANTE')
        self.assertEqual(a['execution_authorization'],'DENY')
    def test_A_mordida_not_executable(self):
        a=self.action('MACACO_P5::MORDIDA')
        self.assertTrue(a['gates']['B_completude']['component_calculable_with_r29'])
        self.assertFalse(a['gates']['B_completude']['full_effect_resolvable'])
    def test_A_source_digit_never_claimed(self):
        a=self.action('MACACO_P5::PATADA');self.assertIsNone(a['source_digest'])
        self.assertFalse(a['gates']['E_autoridade_fonte']['source_snapshot_native_attested'])

    # B: passivas não selecionáveis.
    def test_B_forca_titanica_passive_not_attack(self):
        m=self.menu();a=self.action('MACACO_P5::FORCA_TITANICA')
        self.assertIn(a['action_id'],m['passives'])
        self.assertNotIn(a['action_id'],m['policy_considerable_actions'])
        self.assertEqual(a['category'],'PASSIVA')
    def test_B_instinto_selvagem_passive_not_attack(self):
        m=self.menu(actor='liu')
        self.assertIn('LIU_NORMAL::INSTINTO_SELVAGEM',m['passives'])
        self.assertNotIn('LIU_NORMAL::INSTINTO_SELVAGEM',m['policy_considerable_actions'])
    def test_B_force54_no_auto_plus2(self):
        a=self.action('MACACO_P5::PATADA')
        self.assertIn('FOR54',str(a['diagnostics']))
        self.assertNotIn('FOR56',str(a['diagnostics']))

    # C: item modifiers never stand-alone.
    def test_C_cruel_certeira_never_action(self):
        m=self.menu(actor='liu');a=next(x for x in m['decisions'] if x['action_id']=='LIU_NORMAL::MACHADO_CRUEL_CERTEIRA')
        self.assertEqual(a['category'],'MODIFICADOR')
        self.assertIn(a['action_id'],m['modifiers'])
        self.assertNotIn(a['action_id'],m['policy_considerable_actions'])
    def test_C_infusao_electrica_never_action(self):
        a=next(x for x in self.menu(actor='liu')['decisions'] if x['action_id']=='LIU_NORMAL::MACHADO_INFUSAO')
        self.assertEqual(a['category'],'MODIFICADOR')
        self.assertIsNone(a['effect_plan']['resolved_atomic_effect'])
    def test_C_mod_2_no_doublecount_claim(self):
        a=next(x for x in self.menu(actor='liu')['decisions'] if x['action_id']=='LIU_NORMAL::MACHADO_CRUEL_CERTEIRA')
        self.assertTrue(a['diagnostics']['components'][0]['parent_required'])

    # D/E: insuficiente e desconhecido.
    def test_D_insufficient_PA_for_power(self):
        s=copy.deepcopy(self.scene);s['actors']['macaco']['pa_available']=5
        a=self.action('MACACO_P5::PODER_ELEMENTAL',s)
        self.assertEqual(a['gates']['A_declaracao']['status'],'PROIBIDA')
        self.assertTrue(any('PA_INSUFFICIENT' in x for x in a['gates']['A_declaracao']['prohibited']))
        self.assertEqual(a['execution_authorization'],'DENY')
    def test_E_unknown_PA_for_power(self):
        s=copy.deepcopy(self.scene);s['actors']['macaco']['pa_available']=None
        a=self.action('MACACO_P5::PODER_ELEMENTAL',s)
        self.assertEqual(a['gates']['A_declaracao']['status'],'PENDENTE')
        self.assertIn('PA_AVAILABLE_NOT_PROVED',a['gates']['A_declaracao']['pending'])
    def test_E_missing_cost_not_zero(self):
        a=self.action('MACACO_P5::PATADA')
        self.assertIsNone(a['cost']['cost_pa_explicit'])
        self.assertIn('PA_COST_UNSPECIFIED_NOT_PROOF_OF_ZERO',a['gates']['B_completude']['reasons'])

    # F: nenhuma forma mistura atributos.
    def test_F_liu_normal_attributes(self):
        m=self.menu(actor='liu')
        self.assertEqual(m['form_id'],'LIU_NORMAL')
        self.assertEqual(self.scene['actors']['liu']['attributes']['FOR'],29)
        self.assertNotIn('LIU_TRANSFORMADA::ATAQUE_TRANSFORMADO',[x['action_id'] for x in m['decisions']])
    def test_F_liu_transformed_separate(self):
        m=self.menu(self.liu_form,'liu')
        self.assertEqual(m['form_id'],'LIU_TRANSFORMADA')
        self.assertEqual(self.liu_form['actors']['liu']['attributes']['FOR'],40)
        self.assertNotIn('LIU_NORMAL::MACHADO_BASE',[x['action_id'] for x in m['decisions']])
    def test_F_wrong_form_stats_rejected(self):
        s=copy.deepcopy(self.scene);s['actors']['liu']['attributes']['FOR']=40
        with self.assertRaisesRegex(ValueError,'ATTRIBUTE_SOURCE_FORM_MISMATCH'):F.compile_actor(s,'liu')
    def test_F_transformed_source_not_historic(self):
        m=self.menu(self.liu_form,'liu')
        self.assertEqual(m['dispatch_authorized_actions'],[])
        for a in m['decisions']:
            self.assertIn('TRANSFORM_ID_DURATION_AND_SCENE_ACTIVE_SOURCE_NOT_VERIFIED',a['gates']['B_completude']['reasons'])

    # G: janela errada e orçamento.
    def test_G_reaction_wrong_window(self):
        a=self.action('MACACO_P5::UNIVERSAL_REACAO_DEFENDER')
        self.assertEqual(a['gates']['A_declaracao']['status'],'PROIBIDA')
        self.assertIn('REACTION_OUTSIDE_BEFORE_ENEMY_ATTACK_WINDOW',a['gates']['A_declaracao']['prohibited'])
    def test_G_standard_already_spent(self):
        s=copy.deepcopy(self.scene);s['actors']['macaco']['budget']['standard_consumed']=True
        a=self.action('MACACO_P5::PATADA',s)
        self.assertEqual(a['gates']['A_declaracao']['status'],'PROIBIDA')
    def test_G_before_enemy_attack_fixture(self):
        s=copy.deepcopy(self.scene);s['scene'].update({'phase':'BEFORE_ENEMY_ATTACK','incoming_attack':True,'active_actor_id':'liu'})
        a=self.action('MACACO_P5::UNIVERSAL_REACAO_DEFENDER',s)
        self.assertEqual(a['gates']['A_declaracao']['status'],'PERMITIDA')
        self.assertEqual(a['execution_authorization'],'DENY')

    # H: source digest incompetent.
    def test_H_official_mode_denied(self):
        m=self.menu(mode='OFFICIAL_PREFLIGHT')
        self.assertEqual(m['dispatch_authorized_actions'],[])
        a=next(x for x in m['decisions'] if x['action_id']=='MACACO_P5::PATADA')
        self.assertEqual(a['gates']['E_autoridade_fonte']['status'],'NAO_VERIFICADA_PRODUTIVA')
        self.assertIn('OFFICIAL_PREFLIGHT_WITH_EXPERIMENTAL_FIXTURE',a['dispatch_blockers'])
    def test_H_no_native_digest_attestation(self):
        m=self.menu()
        self.assertEqual(m['source_freeze'],'NOT_SOURCE_NATIVE_ATTESTED')
        self.assertIsNone(m['source_digest'])

    # I: resolver capability is not forgeable via input.
    def test_I_native_unverified(self):
        a=self.action('MACACO_P5::PATADA')
        self.assertIsNone(a['gates']['C_resolvedor']['qualified_resolver'])
    def test_I_explicit_unsupported_fail_closed(self):
        m=F.compile_actor(self.scene,'macaco',engine_claim='REPORTED_UNSUPPORTED')
        a=next(x for x in m['decisions'] if x['action_id']=='MACACO_P5::PATADA')
        self.assertEqual(a['gates']['C_resolvedor']['status'],'NAO_SUPORTADA')
        self.assertEqual(a['execution_authorization'],'DENY')
    def test_I_unverified_support_claim_rejected(self):
        with self.assertRaisesRegex(ValueError,'UNVERIFIED_ENGINE_CAPABILITY_CLAIM_FORBIDDEN'):
            F.compile_actor(self.scene,'macaco',engine_claim='SUPPORTED_BY_REAL_VLAB')

    # J: local stub read-only: dedup != native transaction.
    def test_J_local_readonly_stub_duplicate(self):
        c=ReadOnlyMathProbeConsumer();p=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5])
        x=c.ingest('req-fixture-1',p);y=c.ingest('req-fixture-1',p)
        self.assertEqual(x['status'],'ACCEPTED_MATH_PROBE_ONLY')
        self.assertEqual(y['status'],'REPLAY_NO_ADDITIONAL_PROCESSING')
        self.assertEqual(c.accepted_unique,1)
        self.assertFalse(x['native_vlab'])
        self.assertTrue(x['no_execution'])
    def test_J_hash_tamper_rejected(self):
        c=ReadOnlyMathProbeConsumer();p=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5]);p['status']='FAKE_APPLIED'
        x=c.ingest('req-fixture-2',p)
        self.assertEqual(x['status'],'REJECT')
        self.assertEqual(c.accepted_unique,0)
    def test_J_stub_different_request_two_independent_samples(self):
        c=ReadOnlyMathProbeConsumer();p=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5])
        c.ingest('req-1',p);c.ingest('req-2',p)
        self.assertEqual(c.accepted_unique,2)
    def test_J_stub_never_accept_benchmark_bridge(self):
        c=ReadOnlyMathProbeConsumer();v=F.build_bridge_request(self.scene,'macaco','MACACO_P5::PATADA')
        r=c.ingest('req-bad',v);self.assertEqual(r['status'],'REJECT')

    # K: component probe positive mathematics only.
    def test_K_synthetic_probe_success(self):
        p=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5])
        self.assertEqual(p['status'],'CALCULO_ISOLADO')
        self.assertEqual(p['action_dispatch'],'DENY')
        self.assertFalse(p['full_benchmark_action_ready'])
        self.assertIsNone(p['HP_delta']);self.assertIsNone(p['PA_delta'])
        self.assertTrue(F.verify_seal(p))
    def test_K_probe_matches_original_math(self):
        p=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5]);r=p['original_r29_verifier_result']
        self.assertEqual(r['result']['raw_damage'],62)
    def test_K_probe_repeatable_bytes_and_receipts(self):
        a=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5])
        b=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[3,5])
        self.assertEqual(a,b)
        self.assertTrue(F.verify_seal(a))
    def test_K_modifier_probe_math_allowed_but_not_attack(self):
        p=F.math_probe(self.scene,'liu','LIU_NORMAL::MACHADO_CRUEL_CERTEIRA',[])
        self.assertEqual(p['status'],'CALCULO_ISOLADO')
        self.assertEqual(p['action_dispatch'],'DENY')
    def test_K_poder_elemental_probes_have_no_tag(self):
        p=F.math_probe(self.scene,'macaco','MACACO_P5::PODER_ELEMENTAL',[7])
        self.assertEqual(p['action_dispatch'],'DENY')
        self.assertIn('ELEMENT',str(p['original_r29_verifier_result']).upper())
    def test_K_no_calculator_hold(self):
        p=F.math_probe(self.scene,'macaco','MACACO_P5::MANIPULACAO_MAGICA',[])
        self.assertEqual(p['status'],'HOLD_NO_ISOLATED_CALCULATOR')
    def test_K_invalid_die_rejected(self):
        r=F.math_probe(self.scene,'macaco','MACACO_P5::PATADA',[9,5])
        self.assertEqual(r['status'],'REJECT_COMPONENT_R29')
        self.assertIsNone(r['raw_damage'])
        self.assertEqual(r['action_dispatch'],'DENY')

    # bridge/query contract and adversarial cases.
    def test_bridge_not_sent_not_ack(self):
        b=F.build_bridge_request(self.scene,'macaco','MACACO_P5::PATADA')
        self.assertEqual(b['transport'],'NOT_SENT')
        self.assertIsNone(b['consumer_ack'])
        self.assertEqual(b['authorized_dispatch_ids'],[])
    def test_bridge_contains_all_required_ids(self):
        b=F.build_bridge_request(self.scene,'macaco','MACACO_P5::PATADA')
        for k in ('scene_id','actor_id','source_id','source_digest','form_id','state_revision','action_id','action_query','menu_receipt_id'):
            self.assertIn(k,b)
    def test_query_explicit_unknown_action_holds(self):
        b=F.query_action(self.scene,'macaco','LIU_NORMAL::MACHADO_BASE')
        self.assertEqual(b['status'],'REJECT_ACTION_NOT_IN_SELECTED_FORM')
        self.assertEqual(b['dispatch_authorization'],'DENY')
    def test_query_bad_mode(self):
        with self.assertRaises(ValueError):F.compile_actor(self.scene,'macaco','LIVE_VLAB')
    def test_interface_unknown_field_is_rejected(self):
        q={'protocol':'DMG_R31_BENCHMARK_QUERY_v0.1','request_id':'1',
           'operation':'OP-DMG-CORPUS-EMP-01','operation_type':'COMPILE',
           'state':self.scene,'actor_id':'macaco','dispatchable_action':True}
        self.assertEqual(F.interface_safe(q)['status'],'REJECT')
    def test_interface_wrong_protocol_is_rejected(self):
        q={'protocol':'DMG_R30_TO_VLAB','request_id':'1','operation':'OP-DMG-CORPUS-EMP-01',
           'operation_type':'COMPILE','state':self.scene,'actor_id':'macaco'}
        self.assertEqual(F.interface_safe(q)['dispatch_gate'],'DENY')
    def test_interface_valid_compilation(self):
        q={'protocol':'DMG_R31_BENCHMARK_QUERY_v0.1','request_id':'1',
           'operation':'OP-DMG-CORPUS-EMP-01','operation_type':'COMPILE',
           'state':self.scene,'actor_id':'macaco'}
        r=F.interface_safe(q);self.assertEqual(r['schema'],'OPDMG_R31_AUTOMATED_BENCHMARK_PREFLIGHT_v1')
        self.assertEqual(r['global_dispatch_authorization'],'DENY')
    def test_interface_never_accepts_true_directive(self):
        q={'protocol':'DMG_R31_BENCHMARK_QUERY_v0.1','request_id':'1',
           'operation':'OP-DMG-CORPUS-EMP-01','operation_type':'CHECK_ACTION',
           'state':self.scene,'actor_id':'macaco','action_id':'MACACO_P5::PATADA',
           'dispatch_authorization':'ALLOW'}
        self.assertEqual(F.interface_safe(q)['status'],'REJECT')
    def test_receipt_consistency(self):
        m=self.menu();self.assertTrue(F.verify_seal(m))
        self.assertTrue(all(F.verify_seal(a) for a in m['decisions']))
        self.assertTrue(F.verify_seal(F.build_bridge_request(self.scene,'macaco')))
    def test_receipt_detects_tamper(self):
        m=self.menu();m['summary']['full_auto_benchmark_dispatch_ready']=1
        self.assertFalse(F.verify_seal(m))
    def test_all_62_policy_ids_stay_unmutated(self):
        original=F.R30.POLICY['actions'];seen={}
        for profile in ('MACACO_P5','LIU_NORMAL','LIU_TRANSFORMADA','JAKU_P3','DRAGON_A','DRAGON_B'):
            s=copy.deepcopy(self.scene)
            if profile not in ('MACACO_P5','LIU_NORMAL'):
                # Validate source catalog raw ids without inventing state for missing profiles.
                pass
            seen.update({k:a for k,a in original.items() if a['profile']==profile})
        self.assertEqual(set(seen),set(original))
        self.assertEqual(len(seen),62)
    def test_form_fixture_mismatch_fails_closed(self):
        s=copy.deepcopy(self.scene);s['actors']['macaco']['source_id']='LIU'
        r=F.interface_safe({'protocol':'DMG_R31_BENCHMARK_QUERY_v0.1','request_id':'1',
           'operation':'OP-DMG-CORPUS-EMP-01','operation_type':'COMPILE','state':s,'actor_id':'macaco'})
        self.assertEqual(r['dispatch_gate'],'DENY')
        self.assertEqual(r['status'],'REJECT')
    def test_unknown_engine_capability_claim_cannot_elevate(self):
        with self.assertRaises(ValueError):F.compile_actor(self.scene,'macaco',engine_claim='COMPETENT_ACK_TRUE')
    def test_typed_benchmark_diagnostics_no_re_fip_star_hybrid(self):
        a=self.action('MACACO_P5::PATADA')
        self.assertIsNone(a['diagnostics']['effect_rank']);self.assertIsNone(a['diagnostics']['fip'])
        self.assertEqual(a['diagnostics']['user_stars'],5)
    def test_not_integrated_and_no_official_counter_promotion(self):
        m=self.menu();self.assertFalse(m['vlab_received'])
        self.assertEqual(m['official_gates']['B05'],'PARTIAL')
        self.assertEqual(m['official_gates']['B06'],'PARTIAL')
        self.assertEqual(m['official_gates']['VLAB_contracts'],'0/17')
        self.assertEqual(m['official_gates']['strict'],'0/2')

if __name__=='__main__':unittest.main(verbosity=2)
