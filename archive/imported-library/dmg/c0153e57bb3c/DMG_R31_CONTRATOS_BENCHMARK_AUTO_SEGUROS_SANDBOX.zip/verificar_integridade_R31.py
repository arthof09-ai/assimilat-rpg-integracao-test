#!/usr/bin/env python3
"""Inspeciona manifesto SHA da pasta ou arquivo ZIP R31 (não modifica fontes)."""
from __future__ import annotations
import argparse,hashlib,io,zipfile
from pathlib import Path

def verify_dir(root):
    manifest=(root/'MANIFESTO_SHA256_R31.txt').read_text(encoding='utf8').splitlines()
    for line in manifest:
        h,rel=line.split('  ',1)
        f=root/rel
        if not f.is_file():raise AssertionError('MISSING:'+rel)
        if hashlib.sha256(f.read_bytes()).hexdigest()!=h:raise AssertionError('HASH_MISMATCH:'+rel)
    files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc')}
    expected={s.split('  ',1)[1] for s in manifest}|{'MANIFESTO_SHA256_R31.txt'}
    assert expected==files, ('FILES_NOT_MANIFESTED',sorted(files-expected),sorted(expected-files))
    return {'manifest_sha_ok':len(manifest),'manifest_total_files':len(files)}

def verify_zip(path):
    with zipfile.ZipFile(path,'r') as z:
        corrupted=z.testzip()
        if corrupted:raise AssertionError('ZIP_CRC:'+corrupted)
        lines=z.read('MANIFESTO_SHA256_R31.txt').decode('utf8').splitlines()
        for line in lines:
            h,rel=line.split('  ',1)
            if hashlib.sha256(z.read(rel)).hexdigest()!=h:raise AssertionError('ZIP_HASH:'+rel)
        names=set(z.namelist());expected={s.split('  ',1)[1] for s in lines}|{'MANIFESTO_SHA256_R31.txt'}
        assert names==expected,(sorted(names-expected),sorted(expected-names))
        return {'zip_crc':'PASS','manifest_sha_ok':len(lines),'zip_entries':len(names),'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('path',type=Path);args=p.parse_args()
    print(verify_dir(args.path) if args.path.is_dir() else verify_zip(args.path))
