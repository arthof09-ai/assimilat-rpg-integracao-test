#!/usr/bin/env python3
"""DMG R31 - fornecedor de contratos de autoridade mecânica, NÃO resolvedor de combate.
Reaproveita sem alterar R30 (regras/menus) e R29/R28 (aritmética documental).
NENHUMA chamada a VLAB; NENHUMA escrita Notion; NENHUM scheduler, HP reducer ou consumo de PA.

Segurança: nenhum booleano de elegibilidade é autorização de despacho. Capacidades
VLAB, gates de transação e fonte de produção NÃO são autoatestáveis pelo produtor DMG.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'r30_original'))
import compilador_r30 as R30

MODELS = ('AUTO_BENCHMARK_SANDBOX','OFFICIAL_PREFLIGHT','COMPONENT_MATH_PROBE_ONLY')
SELECTABLE_ROLES=frozenset(('OFFENSIVE','WEAPON_POOL','WEAPON_THROW','UNIVERSAL_ACTION','ACTIVATION','TRANSFORMATION','ABILITY','UTILITY'))
PASSIVE_ROLES=frozenset(('PASSIVE','ITEM_PASSIVE'))
MODIFIER_ROLES=frozenset(('WEAPON_MODIFIER','ELEMENTAL_RIDER','CRITICAL_MODIFIER','CRITICAL_TRIGGER','DAMAGE_REROLL','REACTION_MODIFIER'))
# No action in these classes is itself a selectable physical attack.
INTERNAL_COMPONENT_ONLY_ROLES=frozenset(('PASSIVE','ITEM_PASSIVE','WEAPON_MODIFIER','ELEMENTAL_RIDER','CRITICAL_MODIFIER','CRITICAL_TRIGGER','DAMAGE_REROLL','REACTION_MODIFIER','ITEM_ACTIVATION'))


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest()


def seal(obj, prefix):
    body={k:v for k,v in obj.items() if k not in ('receipt_id','content_sha256')}
    obj['receipt_id']=prefix+digest(body)[:24]
    obj['content_sha256']=digest({k:v for k,v in obj.items() if k!='content_sha256'})
    return obj


def verify_seal(obj):
    try:
        prefix=obj['receipt_id'].split('-',1)[0]+'-'
        bare={k:v for k,v in obj.items() if k not in ('receipt_id','content_sha256')}
        return obj['receipt_id']==prefix+digest(bare)[:24] and obj['content_sha256']==digest({k:v for k,v in obj.items() if k!='content_sha256'})
    except (KeyError,TypeError,ValueError):return False


def validate_mode(mode):
    if mode not in MODELS:raise ValueError('R31_UNSUPPORTED_QUERY_MODE')


def _mechanical(action, prior, actor):
    """Separação entre pool aritmético e plano de ação completo.
    Não converte conhecimento de um pool em prova de acerto, cobertura, defesa ou débito.
    """
    missing=[]
    role=action['role']; kind=action['effect_kind']
    if role in PASSIVE_ROLES:
        missing.append('PASSIVE_IS_NOT_INDEPENDENT_ACTION')
        if 'FORCA_TITANICA' in action['id']:missing.append('PRINTED_FOR54_PASSIVE_PLUS2_STACK_NOT_RECONCILED')
    elif role in MODIFIER_ROLES:
        missing.extend(['MODIFIER_NOT_STANDALONE_ACTION','PARENT_ACTION_HIT_AND_APPLICATION_RECEIPT_ABSENT'])
    elif role=='ITEM_ACTIVATION':missing.append('ITEM_ACTIVATION_COST_OR_BUDGET_UNRECONCILED')
    else:
        missing.append('ATOMIC_EFFECT_AND_ORDER_NOT_SOURCE_PROVEN_FOR_THIS_ACTOR_EVENT')
    if role in ('OFFENSIVE','WEAPON_POOL','WEAPON_THROW'):
        missing.extend(['HIT_CHECK_AND_PROFICIENCY_NOT_FROZEN','SELECTED_TARGET_DEFENSE_REACTION_AND_RD_NOT_FROZEN'])
    if role=='UNIVERSAL_ACTION':
        missing.append('VLAB_NATIVE_ACTION_REDUCER_AND_TARGET_VALIDATION_NOT_VERIFIED')
    if action['cost_pa'] is None and action['cost_kind'] in ('UNSPECIFIED','UNSPECIFIED_IN_SOURCE_NO_PA_DEBIT'):
        missing.append('PA_COST_UNSPECIFIED_NOT_PROOF_OF_ZERO')
    if action['cost_kind'] not in ('EXPLICIT_PER_USE','EXPLICIT_PRATA_T9','UNSPECIFIED_IN_SOURCE_NO_PA_DEBIT'):
        missing.append('RESOURCE_CHARGES_OR_COMMITMENT_LEDGER_UNRESOLVED')
    if action['budget'] in ('UNRESOLVED','BONUS_UNMAPPED'):
        missing.append('ACTION_CLASS_AND_TIMING_NOT_RESOLVED')
    if action['target'] in ('UNKNOWN','TARGET_UNRESOLVED','DESTINATION_UNRESOLVED','ONE_ENEMY_AND_DESTINATION'):
        missing.append('TARGET_GEOMETRY_OR_RANGE_UNRESOLVED')
    if action['timing'] in ('UNRESOLVED','ON_VALID_WEAPON_HIT','ON_VALID_WEAPON_DAMAGE','ON_CRITICAL','ON_COUNTERATTACK'):
        missing.append('ACTIVATION_OR_EFFECT_WINDOW_NOT_VERIFIED')
    if action.get('linked_calculator'):
        missing.append('R29_LINKED_CALCULATOR_IS_COMPONENT_ONLY')
    if kind in ('UNRECONCILED_COMPOSITE','TRANSFORMED_ATTACK_SHORTCUT_UNRECONCILED','ELEMENTAL_UNTYPED'):
        missing.append('COMPONENT_STACK_OR_ELEMENT_TYPE_UNRESOLVED')
    if actor['form_id']=='LIU_TRANSFORMADA':missing.append('TRANSFORM_ID_DURATION_AND_SCENE_ACTIVE_SOURCE_NOT_VERIFIED')
    missing.extend('R30:'+x for x in prior['unresolved_requirements'])
    return {'status':'INCOMPLETA','full_effect_resolvable':False,
            'component_calculable_with_r29':bool(action.get('linked_calculator')),
            'r29_component_id':action.get('linked_calculator'),
            'reasons':sorted(set(missing)),'integration_scope':'NO_FULL_ACTION_PLAN'}


def _resolver(action, engine_claim):
    # Explicit untrusted negative claims may block. Positive capability needs independent
    # recipient readback + execution receipt, which this producer does not possess.
    if engine_claim=='REPORTED_UNSUPPORTED':
        return {'status':'NAO_SUPORTADA','qualified_resolver':None,
                'evidence':'REPORTED_UNSUPPORTED_UNVERIFIED_CLAIM_ONLY; FAIL_CLOSED',
                'r29_local_component_engine':bool(action.get('linked_calculator'))}
    if engine_claim not in (None,'UNKNOWN'):
        raise ValueError('UNVERIFIED_ENGINE_CAPABILITY_CLAIM_FORBIDDEN')
    return {'status':'NAO_VERIFICADA','qualified_resolver':None,
            'evidence':'NO_VLAB_NATIVE_CAPABILITY_ACK_OR_RECEIPT',
            'r29_local_component_engine':bool(action.get('linked_calculator'))}


def _source(action, mode):
    return {'status':'DOCUMENTAL_SANDBOX_APENAS' if mode!='OFFICIAL_PREFLIGHT' else 'NAO_VERIFICADA_PRODUTIVA',
            'source_id':action['source_id'],'url':action['source_url'],
            'source_last_edited_at':action['source_edited_at'],
            'source_digest':None,'source_snapshot_native_attested':False,
            'scene_epoch_bound':False,
            'reasons':['NATIVE_SOURCE_DIGEST_UNAVAILABLE','ACTOR_SCENE_EPOCH_AND_SOURCE_FREEZE_NOT_ATTESTED']}


def _tx():
    return {'status':'NAO_VERIFICADA','reservation_lease':None,'fencing_epoch':None,
            'idempotent_commit_receipt':None,
            'reasons':['NO_VLAB_RESERVATION_SINGLE_COMMIT_AND_READBACK_EVIDENCE',
                       'WRITER_LEASE_EPOCH_FENCING_GREEN_NAC_PASS_HOLD']}


def _diagnostic_components(action):
    k=action['id']; q=action.get('linked_calculator')
    if q=='MACACO_PATADA':parts=[{'kind':'habilidade','dice':'2d6','source':'MACACO','damage_type_literal':'IMPACTO'}, {'kind':'atributo_explicito','value':'FOR54','source':'MACACO','stack_with_force_titanica':False}]
    elif q=='MACACO_MORDIDA':parts=[{'kind':'habilidade','dice':'1d6','source':'MACACO','damage_type_literal':'PERFURANTE'}, {'kind':'atributo_explicito','value':'FOR54','source':'MACACO','stack_with_force_titanica':False}]
    elif q=='MACACO_PODER_ELEMENTAL_BASE':parts=[{'kind':'habilidade','dice':'1d10','source':'MACACO','element':None,'damage_type_literal':None}, {'kind':'atributo_explicito','value':'INT30','source':'MACACO'}]
    elif q=='LIU_MACHADO_BASE':parts=[{'kind':'arma_intrinseca','dice':'5d12','source':'LIU'}]
    elif q=='LIU_MACHADO_CRUEL_CERTEIRA_PARCELA':parts=[{'kind':'modificador_arma','value':2,'source':'LIU','parent_required':True,'standalone':False}]
    elif q=='LIU_MACHADO_INFUSAO_ELETRICA_PARCELA':parts=[{'kind':'efeito_elemental_arma','dice':'3d8','fixed':6,'source':'LIU','parent_required':True,'standalone':False,'tag':'ELETRICO_LITERAL_NAO_EQUIPARAR_RAIO'}]
    else:parts=[]
    return {'components':parts,'effect_rank':None,'user_rank_from_fixture':action['profile'],'item_rank':'ON_LITERAL_DO_MACHADO' if q in ('LIU_MACHADO_BASE','LIU_MACHADO_CRUEL_CERTEIRA_PARCELA','LIU_MACHADO_INFUSAO_ELETRICA_PARCELA') else None,'fip':None,
            'user_stars':5 if action['profile'] in ('MACACO_P5','LIU_NORMAL','LIU_TRANSFORMADA') else None,
            'physical_force':'FOR54_LITERAL_ONLY_NO_DOUBLE_COUNT' if k.startswith('MACACO') else None,
            'critical':'NOT_APPLIED','weakness':'NOT_APPLIED','resistance':'NOT_APPLIED',
            'continuous_damage':'NOT_APPLIED','mitigation':'NOT_APPLIED',
            'damage_applied':None,'not_equilibrium_conclusion':True}


def compile_actor(state,actor_id,mode='AUTO_BENCHMARK_SANDBOX',engine_claim=None):
    validate_mode(mode)
    base=R30.compile_scene(state,actor_id)
    actor=state['actors'][actor_id]
    source_catalog=R30.POLICY['actions']
    entries=[]
    for previous in base['decisions']:
        a=source_catalog[previous['action_id']]
        kind=('PASSIVA' if a['role'] in PASSIVE_ROLES else
              'MODIFICADOR' if a['role'] in MODIFIER_ROLES else
              'NAO_SELECIONAVEL' if a['role']=='ITEM_ACTIVATION' else 'ACAO')
        declarable=previous['eligibility']=='PERMITIDA'
        selectable=kind=='ACAO'
        mechanical=_mechanical(a,previous,actor)
        resolver=_resolver(a,engine_claim)
        txn=_tx()
        source=_source(a,mode)
        blockers=['EFFECT_INTEGRAL_INCOMPLETO','VLAB_NATIVE_RESOLVER_UNVERIFIED',
                  'VLAB_TRANSACTION_GATE_UNVERIFIED','SOURCE_NOT_FROZEN_OR_ATTESTED']
        if not selectable:blockers.append('PASSIVE_MODIFIER_OR_ACTIVATION_NOT_SELECTABLE')
        if not declarable:blockers.append('DECLARATION_NOT_ALLOWED_OR_PENDING')
        if mode=='OFFICIAL_PREFLIGHT':blockers.append('OFFICIAL_PREFLIGHT_WITH_EXPERIMENTAL_FIXTURE')
        if resolver['status']=='NAO_SUPORTADA':blockers.append('CONSUMER_CAPABILITY_REPORTED_UNSUPPORTED')
        entry={'action_id':a['id'],'name':a['name'],'source_id':a['source_id'],'source_url':a['source_url'],
          'source_version':a['source_edited_at'],'source_digest':None,
          'form_id':actor['form_id'],'role':a['role'],'category':kind,
          'action_type':a['budget'],'window':a['timing'],
          'budget':previous['temporal_window'], 'cost':previous['resource_requirements'],
          'target':previous['target_requirements'],
          'gates':{
            'A_declaracao':{'status':previous['eligibility'], 'proved':previous['verified_reasons'],
                            'prohibited':previous['prohibited_reasons'],'pending':previous['unresolved_requirements']},
            'B_completude':mechanical,
            'C_resolvedor':resolver,
            'D_transacao':txn,
            'E_autoridade_fonte':source},
          'r29_component_id':a.get('linked_calculator'),
          'source_reasons':a['source_evidence'],
          'legacy_unknowns':a['legacy_unknowns'],
          'diagnostics':_diagnostic_components(a),
          'automatic_policy_consideration': bool(selectable and declarable and mode=='AUTO_BENCHMARK_SANDBOX'),
          'ready_for_full_automatic_combat':False,
          'execution_authorization':'DENY',
          'dispatch_blockers':sorted(set(blockers)),
          'effect_plan':{'type':'PREVIEW_REQUIREMENTS_ONLY','current_order':[
              'VLAB_ACTOR_SOURCE_STATE_PREFLIGHT','VLAB_ACTION_DECLARATION',
              'VLAB_VALIDATED_HIT_AND_REACTION','R29_COMPONENT_MATH_IF_APPLICABLE',
              'VLAB_MITIGATION_AND_TIME','VLAB_RESERVE_COMMIT_REPLAY'],
              'resolved_atomic_effect':None,'apply_damage':False,'spend_pa':False,
              'consumer_owner':'VLAB_ONLY','no_dispatch':True},
          'r30_declaration_receipt':previous['receipt_id']}
        seal(entry,'R31A-')
        entries.append(entry)
    grouping={x['category']:[v['action_id'] for v in entries if v['category']==x['category']]
              for x in entries}
    groups={key:sorted(value) for key,value in grouping.items()}
    summary={
       'documentary_declared_permitted':sum(x['gates']['A_declaracao']['status']=='PERMITIDA' for x in entries),
       'documentary_declared_prohibited':sum(x['gates']['A_declaracao']['status']=='PROIBIDA' for x in entries),
       'documentary_declared_pending':sum(x['gates']['A_declaracao']['status']=='PENDENTE' for x in entries),
       'source_action_rows':len(entries),
       'policy_considerable_not_dispatchable':sum(x['automatic_policy_consideration'] for x in entries),
       'full_auto_benchmark_dispatch_ready':0,
       'locally_calculable_raw_components':sum(bool(x['r29_component_id']) for x in entries),
       'passive_rows':sum(x['category']=='PASSIVA' for x in entries),
       'modifier_rows':sum(x['category']=='MODIFICADOR' for x in entries)}
    out={'schema':'OPDMG_R31_AUTOMATED_BENCHMARK_PREFLIGHT_v1','operation':'OP-DMG-CORPUS-EMP-01',
      'mode':mode,'scene_id':state['scene_id'],'actor_id':actor_id,'state_revision':state['state_revision'],
      'state_sha256':R30.digest(state),'form_id':actor['form_id'],'source_id':actor['source_id'],
      'source_digest':None,'source_freeze':'NOT_SOURCE_NATIVE_ATTESTED',
      'benchmark_mode':'EXPERIMENTAL_NOT_REPRESENTATIVE',
      'scope_warning':'ONLY_DOCUMENTARY_LAB_PREFLIGHT_NOT_TURN_RESOLUTION',
      'policy_considerable_actions':[x['action_id'] for x in entries if x['automatic_policy_consideration']],
      'dispatch_authorized_actions':[],
      'passives':[x['action_id'] for x in entries if x['category']=='PASSIVA'],
      'modifiers':[x['action_id'] for x in entries if x['category']=='MODIFICADOR'],
      'not_selectable':[x['action_id'] for x in entries if x['category']=='NAO_SELECIONAVEL'],
      'source_action_ids':groups.get('ACAO',[]),'summary':summary,
      'decisions':entries,
      'global_dispatch_authorization':'DENY',
      'transport':'NOT_SENT','vlab_received':False,
      'vlab_native_consumption_receipt':None,
      'ibx_reused':'IBX-90','official_gates':{'B05':'PARTIAL','B06':'PARTIAL','B01_B18':'1/18',
             'VLAB_contracts':'0/17','strict':'0/2','original_I0003':'0/9',
             'writer':'HOLD','lease':'HOLD','epoch':'HOLD','fencing':'HOLD','GREEN':'HOLD','NAC_PASS':'HOLD'},
      'no_hp_change':True,'no_pa_spend':True,'no_scheduler':True}
    return seal(out,'R31M-')


def query_action(state,actor_id,action_id,mode='AUTO_BENCHMARK_SANDBOX',engine_claim=None):
    menu=compile_actor(state,actor_id,mode,engine_claim)
    for d in menu['decisions']:
        if d['action_id']==action_id:
            return seal({'schema':'OPDMG_R31_ACTION_PREFLIGHT_v1','scene_id':menu['scene_id'],
              'actor_id':actor_id,'state_revision':menu['state_revision'],
              'mode':mode,'action':d,'menu_receipt_id':menu['receipt_id'],
              'dispatch_authorization':'DENY','vlab_execution':'NOT_EXECUTED'},'R31Q-')
    return seal({'schema':'OPDMG_R31_ACTION_PREFLIGHT_v1','scene_id':menu['scene_id'],
       'actor_id':actor_id,'state_revision':menu['state_revision'],
       'mode':mode,'requested_action_id':action_id,'status':'REJECT_ACTION_NOT_IN_SELECTED_FORM',
       'dispatch_authorization':'DENY','vlab_execution':'NOT_EXECUTED'},'R31Q-')


def math_probe(state,actor_id,action_id,rolls):
    """Uma amostra de COMPONENTE via verificador R29 legado, nunca ataque/turno."""
    menu=compile_actor(state,actor_id,'COMPONENT_MATH_PROBE_ONLY')
    by={a['action_id']:a for a in menu['decisions']}
    if action_id not in by:raise ValueError('ACTION_NOT_IN_SELECTED_FORM')
    action=by[action_id]
    case=action['r29_component_id']
    if case is None:
        return seal({'schema':'OPDMG_R31_COMPONENT_PROBE_v1','status':'HOLD_NO_ISOLATED_CALCULATOR',
          'action_id':action_id,'scene_id':menu['scene_id'], 'action_dispatch':'DENY',
          'raw_damage':None,'HP_delta':None,'PA_delta':None,'no_combat':True},'R31P-')
    result=R30.v29.calculate({'mode':'DOCUMENTAL_DICE_ONLY','action_id':case,'rolls':rolls})
    # R29 does not raise on invalid dice; it returns an explicit rejected receipt.
    # Never wrap a rejected R29 receipt as successful R31 probe.
    if result.get('status')!='ALLOW_DOCUMENTAL_COMPONENT_ONLY':
        return seal({'schema':'OPDMG_R31_COMPONENT_PROBE_v1','status':'REJECT_COMPONENT_R29',
          'scene_id':menu['scene_id'],'actor_id':actor_id,'action_id':action_id,
          'original_r29_verifier_result':result,'raw_damage':None,
          'component_local_calculation_supported':False,'full_benchmark_action_ready':False,
          'action_dispatch':'DENY','HP_delta':None,'PA_delta':None,'no_combat':True},'R31P-')
    return seal({'schema':'OPDMG_R31_COMPONENT_PROBE_v1','status':'CALCULO_ISOLADO',
      'scene_id':menu['scene_id'],'actor_id':actor_id,'state_revision':menu['state_revision'],
      'state_sha256':menu['state_sha256'],'action_id':action_id,'form_id':menu['form_id'],
      'source_id':action['source_id'],'source_url':action['source_url'],
      'source_digest':None,'data_kind':'FIXTURE_NOT_HISTORIC',
      'original_r29_verifier_result':result,
      'declaration_gate_status':action['gates']['A_declaracao']['status'],
      'full_benchmark_action_ready':False,
      'component_local_calculation_supported':True,
      'action_dispatch':'DENY','HP_delta':None,'PA_delta':None,
      'not_hit':True,'not_damage_applied':True,'no_combat':True,
      'source_type':'R29_VERIFIER_UNCHANGED'},'R31P-')


def build_bridge_request(state,actor_id,action_id=None,mode='AUTO_BENCHMARK_SANDBOX',engine_claim=None):
    validate_mode(mode)
    menu=compile_actor(state,actor_id,mode,engine_claim)
    result=query_action(state,actor_id,action_id,mode,engine_claim) if action_id else None
    body={
      'protocol':'OPDMG_R31_TO_VLAB_AUTOMATED_BENCHMARK_QUERY_RESPONSE_v0.1_PROPOSED',
      'actor_id':actor_id,'scene_id':state['scene_id'],'state_revision':state['state_revision'],
      'state_digest':menu['state_sha256'],'source_id':menu['source_id'],
      'source_digest':None,'form_id':menu['form_id'],
      'requested_mode':mode,'menu_receipt_id':menu['receipt_id'],
      'action_id':action_id,
      'action_receipt_id':result['receipt_id'] if result else None,
      'eligibility_summary':menu['summary'],
      'policy_candidate_ids':menu['policy_considerable_actions'],
      'authorized_dispatch_ids':[],
      'action_query':result,
      'policy_requirements':{
           'all_five_gates_must_have_competent_evidence':True,
           'consumer_must_verify_source_digest_and_scene_epoch':True,
           'consumer_must_ack_resolver_version_and_effect_plan':True,
           'consumer_must_reserve_and_commit_idempotently':True,
           'no_boolean_eligibility_dispatch':True,
           'source_side_cannot_self_certify_vlab_transaction':True},
      'dispatch_gate':'DENY','transport':'NOT_SENT',
      'execution_status':'PREPARED_NOT_DELIVERED',
      'consumer_ack':None,'native_engine_receipt':None,
      'next_required_owner':'CM-000006 VLAB WHEN AUTHORIZED',
      'ibx_existing':'IBX-90','write_gate':'HOLD',
      'effect_execution_ownership':'VLAB_ONLY',
      'not_official_source_status':True}
    return seal(body,'R31V-')


def interface_query(request):
    """Estrutura JSON do consumidor: valida campos estritos para impedir bypass por flags."""
    allowed={'protocol','request_id','operation','mode','state','actor_id','action_id','operation_type','rolls'}
    if not isinstance(request,dict) or set(request)-allowed:
        raise ValueError('REJECT_UNKNOWN_OR_PRIVILEGE_ESCALATION_REQUEST_FIELDS')
    if request.get('protocol')!='DMG_R31_BENCHMARK_QUERY_v0.1':raise ValueError('BAD_INTERFACE_PROTOCOL')
    if request.get('operation')!='OP-DMG-CORPUS-EMP-01':raise ValueError('WRONG_OPERATION')
    if not isinstance(request.get('request_id'),str) or not request['request_id']:
        raise ValueError('REQUEST_ID_REQUIRED')
    state=request['state'];actor_id=request['actor_id'];mode=request.get('mode','AUTO_BENCHMARK_SANDBOX')
    kind=request.get('operation_type')
    if kind=='COMPILE':return compile_actor(state,actor_id,mode)
    if kind=='CHECK_ACTION':return query_action(state,actor_id,request['action_id'],mode)
    if kind=='BRIDGE_PREFLIGHT':return build_bridge_request(state,actor_id,request.get('action_id'),mode)
    if kind=='COMPONENT_PROBE':
        if mode!='COMPONENT_MATH_PROBE_ONLY':raise ValueError('PROBE_REQUIRES_ISOLATED_MATH_MODE')
        return math_probe(state,actor_id,request['action_id'],request['rolls'])
    raise ValueError('UNKNOWN_QUERY_OPERATION')


def interface_safe(request):
    """Para consumidor: erros viram negativas assinadas, nunca ação permitida."""
    try:return interface_query(request)
    except (ValueError,TypeError,KeyError,IndexError) as error:
        return seal({'schema':'OPDMG_R31_FAIL_CLOSED_v1','status':'REJECT',
          'reason':str(error),'dispatch_gate':'DENY',
          'transport':'NOT_SENT','HP_delta':None,'PA_delta':None},'R31X-')


def main():
    p=argparse.ArgumentParser(description='DMG R31 - consulta de preflight para benchmark, sem scheduler/dispatch')
    p.add_argument('--request-file',type=Path,required=True)
    args=p.parse_args()
    try:
        request=json.loads(args.request_file.read_text(encoding='utf8'))
        result=interface_safe(request)
    except (ValueError,OSError) as e:
        result=seal({'schema':'OPDMG_R31_FAIL_CLOSED_v1','status':'REJECT',
                     'reason':str(e),'dispatch_gate':'DENY','transport':'NOT_SENT'},'R31X-')
    print(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False))

if __name__=='__main__':main()
