# Operação DMG R31 pelo Comestre — uso no chat e pelo VLAB

**O Mestre não precisa executar código, instalar Python ou operar terminal.** Este pacote é Mestre-only. O Comestre deve usar os arquivos dentro de seu ambiente de ferramentas e interpretar os resultados, sem colar dados sigilosos na Party.

## Interface de consulta local

- `fornecedor_benchmarks_r31.py` é o único ponto de entrada DMG R31. Não substitui R30 ou R29. O script é um **pré-flight**, não um motor de luta.
- Entrada para futuro cliente: `DMG_R31_BENCHMARK_QUERY_v0.1`, `operation='OP-DMG-CORPUS-EMP-01'`, `request_id`, `operation_type` (COMPILE | CHECK_ACTION | BRIDGE_PREFLIGHT | COMPONENT_PROBE), `state` (= snapshot fictício R30), `actor_id`, `mode`, e opcional `action_id`/`rolls`.
- `operation_type=COMPILE` devolve menus divididos em ações selecionáveis, passivas, modificadores, entradas não selecionáveis; cada opção tem `gates.A_declaracao ... E_autoridade_fonte`, custos/tempo, efeito e motivos.
- `BRIDGE_PREFLIGHT` devolve intenção proposta ao VLAB `NOT_SENT` e `dispatch_gate=DENY`; o consumidor nunca deve interpretar `automatic_policy_consideration=true` como autorização.
- `COMPONENT_PROBE` reutiliza `R29.v29.calculate` para dano **bruto de um componente**, não para dano aplicado. Dados inválidos devolvem `REJECT_COMPONENT_R29`, nunca status de cálculo concluído.
- `OFFICIAL_PREFLIGHT` é uma consulta de bloqueios, **não** uma chave que ativa produção.

Exemplo interno do Comestre, já incluído em `exemplos/`:

```bash
python fornecedor_benchmarks_r31.py --request-file exemplos/consulta_macaco_preflight.json
python fornecedor_benchmarks_r31.py --request-file exemplos/consulta_macaco_probe.json
```

A implementação de automação do VLAB deve consumir somente contrato com **autorização explícita obtida por autoridade do próprio VLAB** após validação independentemente competente dos cinco gates. A R31 atual emite **0 ações com autorização**. Rejeitar campos de autorização forjados. Não adicionar campos arbitrários ao `spec_validate` R23; a API real retorna `UNKNOWN_EXPERIMENT_FIELDS`.

## Exemplo de conversa adequada

> Mestre: “Quais ações do Macaco são seguras para benchmark?”
>
> Comestre: “Na fixture, Patada e Mordida podem ser declaradas; nenhuma está pronta para combate automático. Os cálculos brutos isolados podem ser amostrados. Poder Elemental tem 10 PA explícitos, porém tipo de ação/elemento e alvo faltam. A ponte VLAB retorna DENY. Nenhuma Vida ou PA muda.”

Se o Mestre solicitar cálculo do componente (não combate), o Comestre faz a amostragem via R29, rotula dados fictícios e emite recibo. Se solicitar confronto automático real, não substitui o resolvedor nativo por sorteio manual ou simulação narrativa.

## Reproduzir os testes

```bash
python testes_r31.py
(cd r30_original && python testes_r30.py)
(cd r30_original/r29_original && python testes_r29.py)
(cd r30_original/r29_original/r28_original && python testes_r28.py)
```

O arquivo `verificacao_consumidor_R23_LOCAL.py` exige o ZIP R23 **externo**, não incluído no pacote DMG, para executar seu `spec_validate` nativo em uma cópia isolada. O resultado já executado está em `recibos/NATIVO_R23_SCHEMA_NEGATIVE_RECEIPT.json`, com SHA da versão auditada. Ele não executa batalhas e não fornece ACK.

## Intertravamentos

Reprovar toda promoção automática baseada somente em `eligibility`, `dispatchable_action`, `policy_considerable_actions`, `source_last_edited_at` ou hash de JSON criado no sandbox. Não reescrever R30. Não alegar saída de efeitos reais, nem escrever Notion/Party/O Primeiro. Usar IBX-90 existente para coordenação legítima. Certificação somente com gates NAC-NORM/NAC-CONT/NAC-PASS aplicáveis.
