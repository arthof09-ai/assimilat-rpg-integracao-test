# PSV — DMG / DELTA CIENTÍFICO E AUDITORIA A5–A8 / 16-10-2026

**AMBIENTE:** MESTRE-SIDE; **OPERATION:** `OP-DMG-CORPUS-EMP-01` (preexistente); **BASELINE:** `DMG-RANK-01 v1.1`, inalterada. **Fase ativa:** F0, 4/8 documental, sem PASS novo.

## Fronteira autenticada ANTES
- Pacote oficial P0 `DMG-F0-CIENCIA-P0-20261016`: 81017 bytes, hash `397cd335096270ee180b834abb2074b84de68909821ffd6192cac8653fdc6a62` (checado na sucessão anterior).
- Delta da sucessão 16194 bytes `f7a2e12f3133a6df3a639d74a869f11c4d50488d13b0cfce44f9eba40171fc11`: persistido e readback PASS no ciclo anterior.
- Delta A6/R03/R04 31750 bytes `ec72bb4d1d1f59c8c3776d4c44b0c1dc15e780a1290a21fafddf71e5fee18c09`: persistido com readback no ciclo anterior.
- A6 CSV 239 registros persistido. Fonte do CSV de 332 IDs antigos localizada na Inbox IBX-102 mas sem bytes rematerializados. Não foi repetido o censo das oito raízes.

## A5 — sete autoridades revalidadas nesta instância, sem confundir fingerprint e snapshot
- Consulta direta às 7 fontes Mestre já identificadas: 7/7 hashes SHA-256 UTF8 dos corpos de `<content>` INTEGRAIS conferem byte/char e timestamp com o manifesto histórico da Coordenação. Self-test SHA-256 `abc` PASS.
- Registro por fonte: `A5_SEVEN_CURRENT_TEXT_FINGERPRINTS_REVALIDATED.json`.
- **0/7** downloads pós-upload dos anexos originais certificados. Não houve snapshots integrais de texto arquivados nesta entrega; SHA do corpo atual não equivale a captura de seus bytes em arquivo físico. Blocos binários, páginas filhas, edições 07/10 e 09/10 não foram reconstruídos por inferência.
- Via técnica tentada nesta sucessão: signed URL + tentativa de transferência ao contêiner, bloqueada por `url not viewed in conversation before` mesmo após abertura externa; via Notion de upload temporário com readback retornou `{}` até em teste de controle curto. `BLOCKER-VERIFICADO` para anexos históricos; PARTIAL de corpo textual atual.

## A6 — capacidade disponível
- **239/239** IDs/URLs dos 12 ramos de Bestas fisicamente persistidos no pacote anterior; 239 distintos. Este pacote não reexecuta seus scans.
- **332** IDs diretos das oito raízes existem como CSV anexado na Inbox; seu fluxo binário não foi materializado. A união 571 fica **RELATADA**, não `571/571 VERIFIED` na versão CSV unificada.
- Original D0 global **NÃO DETERMINÁVEL**. Páginas não equivalem a criaturas, habilidades, componentes ou resultados independentes.

## A7 e A8
- A7 oito candidatos previamente reservados: **0 correspondências por UUID exato** com a lista de 239 referências de Bestas, usando só os IDs preservados, **sem abrir conteúdo dos oito holdouts**. Isso não prova cegamento, ausência de aliases ou independência de famílias, especialmente sem o arquivo 332. `0/8` independentemente certificados.
- A8: Registry Mestre identifica **CM-000001 como Coordenador 1**, enquanto a operação DMG vincula um workstream histórico ao mesmo COMESTRE-ID. Identidade de workstream não permite apropriação de instância coordenadora. Assignment, nova INSTANCE-ID, writer, epoch, lease, fencing, collision domain e ACK DMG não comprovados nesta sucessão. **NO SHARED WRITES**.

## Ciência NOVA E VERIFICADA — três páginas da coorte R04 fora dos oito pares R02
- Base material: `DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip`, original SHA256 `ba871e3c1103958ca0f5f241033e839054e050f7e34eed4890b2774c0a1f89b3`; membro `R04_ALL_INITIAL_ACTIONS.csv` SHA256 `ad21b008373f1d953b31e4a0ade4ebe0570d201d1e310d510edfaf599e8e229c`, cópia de leitura preservada aqui. `PAIRS_SAME_PAGE_R02_HISTORICAL.csv` usado exclusivamente para exclusão de sobreposição por UUID, três páginas novas = **0 coincidências**.
- Total **3 páginas físicas / 6 fórmulas explícitas / 3 pares dentro da mesma página**. Uma página = um cluster, não seis criaturas independentes. Todas as ações seguem sua fórmula literal, atributo da ficha e sem crit/PA/precisão inventados.
- `Fúria de Chamas` `383c2b...a66a`: `Lança-chamas 3d6+INT12` DME22,5 e `Ataque colossal 2d6+FOR23` DME30,0; diferença 7,5 explicada por **+11 de atributo -3,5 de média intrínseca de dados**. Sob rolagens hipotéticas independentes, Ataque Colossal supera Lança em `209/216 = 96,7593%`, empate `7/432`, inversão de evento `7/432`. Modificador genérico +5 de Força Bruta não somado sem regra de aplicação. Título Prata1/corpo Épico/ancestral Ouro2: CLASSIFICAÇÃO HOLD.
- `Behemoth Glacial` `1fdc2b...9440`: `Estilhaços de Gelo 2d6+DES45` DME52,0 e `Mordida 3d6+FOR15` DME25,5. Diferença 26,5 a favor de Estilhaços: +30 de atributo, -3,5 por dado adicional da Mordida. Estilhaços sempre supera Mordida no TEST de dados separados por suportes disjuntos (mín47 vs máx33). Título/corpo Prata5/ancestral Ouro1: CLASSIFICAÇÃO HOLD.
- `Raposa alfa` `2f3c2b...1a50`: `Punhos de fogo 1d4` DME2,5 e `Soco 1d6+FOR60` DME63,5. Diferença +61, sendo +60 atributo e +1 dado. Sob fórmula pura, Soco sempre supera Punhos; não somar dano ambiental do rastro nem supor custo. Título/ancestral Prata5 vs corpo Bronze5: CLASSIFICAÇÃO HOLD.
- Audit: 683/683 checagens do auditor matemático independente, em **164** pontos de RD escalar condicional; gerador principal 346 checagens de aritmética +12 de proveniência. Distribuições geradas por convolução e conferidas por enumeração cartesiana. Nenhuma execução de VLAB/combate foi feita.
- Cientificamente observável nos três casos: parte relevante das diferenças de DME se explica pela desigualdade entre atributos na MESMA entidade, não por mais dados. Não isola causalidade geral e não demonstra balanceamento universal. Custos ofensivos PA não documentados para essas ações; eficiência PA=PENDENTE.
- **Hipótese testável para F8/F9/F12, sem promover fases:** em pares de uma mesma criatura com classificação reconciliada, comparar o diferencial ATTR e o diferencial intrínseco de dados, controlando entrega, efeito especial, recurso e defesa, e testar limites por rank/família sem misturar clusters.

## Plano Supremo e aceitação
- Matriz original F0–F18 preservada: F0 **4/8 → 4/8**, A5 PARTIAL, A6 partial 239/571 referência estrutural, A7 HOLD, A8 HOLD. Nenhuma nova fase terminal. F1–F12 recebem estudo exploratório útil somente; F13–F18 dependem de corpus, regressão, Mestre e NAC-NORM.
- Aplicação genuína DMG v1.1 de fonte SEM fórmula explícita com RE/FIP/entrega/autoridade verificados: **0 novos casos CERTIFICADOS**.
- **CONFLICTS:** Escorpião ancestral Diamante/corpo Ártico preservado; cinco vs seis UUIDs da coorte histórica R02 não adjudicados; três conflitos classificatórios desta coorte R04; R93/R95 crítico normativo em HOLD; versões de 07/10/09/10 não reconstituídas.
- **UNKNOWN-EFFECT:** nenhuma escrita em Notion/OP/Diário/Party/O Primeiro/VLAB, nenhuma execução de combate. Uploads temporários de diagnóstico foram não anexados, sem confirmação de download e sem promoção como persistência; UNKNOWN-EFFECT histórico anterior segue separado e não foi repetido.
- **NO-REPEAT:** P0 1616, retrospectivo 116/148, oito pares R02, 29 fórmulas globais R04, rodadas R91/R97, combates VLAB, oito raízes Notion. Este ciclo concentrou-se em TRÊS NOVOS PARES intrafonte e A5 hashes.
- **NAC-PASS:** matemática/proveniência dos seis pares locais + pacote de Biblioteca com readback **PASS TÉCNICO LOCAL**, F0 formal e qualquer escrita/produção **HOLD**.
- **FIRST-PENDING:** CSV original 332 em bytes para unir a A6 239; A5 bytes dos sete anexos originais ou snapshot exportado autorizadamente; revisão de A7 pelo segundo codificador e preflight writer A8.
- **NEXT-5:** 1 recuperar CSV 332 por ferramenta de bytes realmente suportada; 2 preservar texto atual das 7 autoridades em arquivos reais com readback sem reivindicar bytes históricos; 3 recuperar Lotes 002/003 por IDs/hash materiais acessíveis; 4 revisar os três pares novos e fontes classificatórias por autoridade competente, ampliar matched sources sem inventar elegibilidade; 5 obter segundo codificador independente e Assignment/writer antes de qualquer alteração canônica.
- **TARGET REMAINDER:** F0 A5–A8, D0–D9, fases F1–F18 conforme o Plano Supremo original, sem nova matriz nem motor.
