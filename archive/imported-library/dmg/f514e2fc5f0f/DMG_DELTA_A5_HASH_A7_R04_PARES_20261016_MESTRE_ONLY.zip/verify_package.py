#!/usr/bin/env python3
"""Manifest/CRC audit for the delivered DMG delta zip. Usage: python verify_package.py PACKAGE.zip"""
import sys, json, hashlib, zipfile
from pathlib import Path
p=Path(sys.argv[1]);z=zipfile.ZipFile(p)
assert z.testzip() is None,'CRC failure'
m=json.loads(z.read('SHA256_MANIFEST.json'))
actual=set(z.namelist())-{'SHA256_MANIFEST.json'}
assert actual==set(m['members']),('file-set mismatch',actual^set(m['members']))
for f in m['members']:
 b=z.read(f)
 assert hashlib.sha256(b).hexdigest()==m['members'][f]['sha256'],f+' hash'
 assert len(b)==m['members'][f]['bytes'],f+' size'
print(json.dumps({'zip':p.name,'crc':'PASS','member_hashes':len(actual),'hashes':'PASS','zip_bytes':p.stat().st_size},ensure_ascii=False))
