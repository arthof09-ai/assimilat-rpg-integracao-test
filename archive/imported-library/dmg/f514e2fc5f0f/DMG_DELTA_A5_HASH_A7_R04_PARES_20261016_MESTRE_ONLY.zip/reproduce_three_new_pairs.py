#!/usr/bin/env python3
"""DMG CYCLE2 -- read-only exact enumerations on three R04 page-cluster pairs.
No Notion mutation, VLAB engine, RNG, F0 certification, or normative patch.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
from hashlib import sha256
import csv, io, json, zipfile
from datetime import date

ROOT=Path('/mnt/data/dmg_succession/cycle2')
HIST=Path('/mnt/data/dmg_succession/historical/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip')
R02=ROOT/'readonly_sources/PAIRS_SAME_PAGE_R02_HISTORICAL.csv'
R04_MEMBER='readonly_sources/R04_ALL_INITIAL_ACTIONS.csv'
SOURCES={
 '383c2b324ede8266ad2b819fc078a66a':{
  'entity':'Fúria de Chamas','title':'Prata 1','body_class':'Épico (não reconciliado)','ancestor':'Ouro 2 · 6','modifiers_excluded':['Força Bruta: +5 de dano — aplicação a cada habilidade não demonstrada'],
  'actions':[('Lança-chamas','3d6+INT',12,3,6),('Ataque colossal','2d6+FOR',23,2,6)]},
 '1fdc2b324ede82bd9d4f811abb689440':{
  'entity':'Behemoth Glacial','title':'Prata 5','body_class':'Prata 5','ancestor':'Ouro 1 · 1','modifiers_excluded':['Sopro Congelante 10 PA é habilidade DIFERENTE','Armadura de Gelo 20 PA não é custo de Estilhaços/Mordida'],
  'actions':[('Estilhaços de Gelo','2d6+DES',45,2,6),('Mordida','3d6+FOR',15,3,6)]},
 '2f3c2b324ede830c94af0113e39a1a50':{
  'entity':'Raposa alfa / Raposa Flamejante','title':'Prata 5','body_class':'bronze 5','ancestor':'Prata 5 · 2','modifiers_excluded':['Passos flamejante causa rastro sem dano numérico e não foi somado'],
  'actions':[('Punhos de fogo','1d4',0,1,4),('Soco','1d6+FOR',60,1,6)]},
}

def exact(n,s,add):
    d=Counter({0:1})
    for _ in range(n):
        nxt=Counter()
        for k,v in d.items():
            for die in range(1,s+1):nxt[k+die]+=v
        d=nxt
    return Counter({k+add:v for k,v in d.items()})

def brute(n,s,add):
    d=Counter()
    for dice in product(range(1,s+1), repeat=n):d[sum(dice)+add]+=1
    return d

def mean(v): return Fraction(sum(k*c for k,c in v.items()),sum(v.values()))
def post(v,rd):return Fraction(sum(max(0,k-rd)*c for k,c in v.items()),sum(v.values()))
def positive(v,rd):return Fraction(sum(c for k,c in v.items() if k>rd),sum(v.values()))
def fmt(q):return {'num':q.numerator,'den':q.denominator,'decimal':round(float(q),12)}

def joint(a,b):
    N=sum(a.values())*sum(b.values())
    return {key:Fraction(sum(ca*cb for xa,ca in a.items() for xb,cb in b.items() if op(xa,xb)),N) for key,op in [('A_gt_B',lambda x,y:x>y),('B_gt_A',lambda x,y:y>x),('equal',lambda x,y:x==y)]}

if HIST.exists():
    with zipfile.ZipFile(HIST) as z: raw=z.read(R04_MEMBER)
else: raw=(ROOT/'readonly_sources/R04_ALL_INITIAL_ACTIONS.csv').read_bytes()
rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
historical=set(x['page_id'] for x in csv.DictReader(R02.open(encoding='utf-8-sig')))
byid={}
for r in rows:byid.setdefault(r['page_id'],[]).append(r)
assert not (historical&set(SOURCES)), 'Historical R02 overlap detected'
assert all(len(byid[x])==2 for x in SOURCES), 'One physical page must have exactly two selected actions'
counts={'arithmetic_checks':0,'provenance_checks':0}
science=[]; curves=[]; source_register=[]
for page_id,entry in SOURCES.items():
    acts=entry['actions'];dist=[]
    for name,literal,attr,n,s in acts:
        x=next(y for y in byid[page_id] if y['name'].casefold()==name.casefold())
        assert x['literal_formula'].replace(' ','').lower().replace('dês','des').replace('força','for').replace('inteligência','int')==literal.lower().replace('des','des').replace('for','for'),(name,x['literal_formula'],literal)
        assert int(float(x['attribute_value'] or 0))==attr
        counts['provenance_checks']+=2
        p=exact(n,s,attr);v=brute(n,s,attr)
        assert p==v
        counts['arithmetic_checks']+=1
        mu=mean(p)
        assert abs(float(mu)-float(x['gross_mean']))<1e-9
        counts['arithmetic_checks']+=1
        dist.append(p)
    means=[mean(d) for d in dist]
    dominance=joint(*dist)
    assert sum(dominance.values())==1
    counts['arithmetic_checks']+=1
    dice_expect=[Fraction(n*(s+1),2) for _,_,_,n,s in acts]
    attrs=[a[2] for a in acts]
    assert means[1]-means[0] == (attrs[1]-attrs[0])+(dice_expect[1]-dice_expect[0])
    counts['arithmetic_checks']+=1
    scenarios=[]
    rd_max=max(max(d) for d in dist)+1
    dominance_rd_change=[]
    for rd in range(rd_max+1):
        p1,p2=(post(d,rd) for d in dist)
        q1,q2=(positive(d,rd) for d in dist)
        assert 0<=q1<=1 and 0<=q2<=1 and p1>=0 and p2>=0
        # Positive probabilities checked via direct count and tail-sum expectation
        for di,(d,pv,qv) in enumerate(zip(dist,[p1,p2],[q1,q2])):
            tail=Fraction(sum(sum(c for k,c in d.items() if k>=t) for t in range(rd+1,max(d)+1)),sum(d.values()))
            assert tail==pv
            counts['arithmetic_checks']+=1
        curves.append({'physical_page_id':page_id,'entity':entry['entity'],'rd_test':rd,
          'A_mean_post':str(p1),'B_mean_post':str(p2),'A_p_positive':str(q1),'B_p_positive':str(q2),
          'A_minus_B':str(p1-p2), 'not_realized_damage':True})
        if rd in (0,5,15,25,31,35,45,55,65):scenarios.append({'RD':rd,'A_net_mean':fmt(p1),'B_net_mean':fmt(p2),'A_Ppositive':fmt(q1),'B_Ppositive':fmt(q2)})
        sign=1 if p1>p2 else -1 if p1<p2 else 0
        dominance_rd_change.append(sign)
    record={'physical_page_id':page_id,'source_url':'https://app.notion.com/p/'+page_id,
      'entity':entry['entity'],'title_class':entry['title'],'body_class':entry['body_class'],'ancestor_class':entry['ancestor'],
      'classification_status':'CONFLICT / exclude from rank-generalized inference',
      'unit':'1 physical page cluster = 2 action formulas, NOT 2 independent creatures',
      'source_version_last_edited_at':{'383c2b324ede8266ad2b819fc078a66a':'2026-10-01T18:00:46.348Z','1fdc2b324ede82bd9d4f811abb689440':'2026-10-01T18:00:46.463Z','2f3c2b324ede830c94af0113e39a1a50':'2026-10-01T18:00:46.258Z'}[page_id],
      'rank_taxonomy_admission':'HOLD','condition':'on hit; conventional independent dice for hypothetical paired comparison; equal scalar RD hypothetical',
      'cost_PA':'UNKNOWN for both offensive actions, cannot estimate per-PA efficiency',
      'excluded_modifiers':entry['modifiers_excluded'],
      'A':{'name':acts[0][0],'literal':next(x['literal_formula'] for x in byid[page_id] if x['name']==acts[0][0]),'attribute_value':acts[0][2], 'mean':fmt(means[0]), 'min':min(dist[0]), 'max':max(dist[0])},
      'B':{'name':acts[1][0],'literal':next(x['literal_formula'] for x in byid[page_id] if x['name']==acts[1][0]),'attribute_value':acts[1][2], 'mean':fmt(means[1]), 'min':min(dist[1]), 'max':max(dist[1])},
      'B_minus_A_mean':fmt(means[1]-means[0]),'B_minus_A_attribute':attrs[1]-attrs[0],
      'B_minus_A_intrinsic_dice':fmt(dice_expect[1]-dice_expect[0]),
      'on_independent_dice_rolls_hypothetical':{k:fmt(v) for k,v in dominance.items()},
      'RD_test_count':rd_max+1,'RD_test_last':rd_max,
      'RD_sign_presence':{'A_gt_B':dominance_rd_change.count(1),'B_gt_A':dominance_rd_change.count(-1),'equal':dominance_rd_change.count(0)},
      'scenarios':scenarios}
    science.append(record)
    source_register.append({'page_id':page_id,'url':record['source_url'],'body_class':entry['body_class'], 'title_class':entry['title'],'ancestor_class':entry['ancestor'], 'n_actions':2,'historical_R02_overlap':False,'source_check':'Notion MESTRE fetch verified as of 2026-10-16; noncanonical class conflicts retained'})

out={'as_of':'2026-10-16','operation':'OP-DMG-CORPUS-EMP-01','baseline':'DMG-RANK-01 v1.1 UNCHANGED',
 'historical_source_zip_name':HIST.name,'historical_source_zip_sha256':sha256(HIST.read_bytes()).hexdigest() if HIST.exists() else 'ba871e3c1103958ca0f5f241033e839054e050f7e34eed4890b2774c0a1f89b3',
 'r04_member':R04_MEMBER,'r04_member_sha256':sha256(raw).hexdigest(),
 'hypothesis':'Does attribute-dice allocation alter dominance within one physical creature when comparing existing explicit damage formulas?',
 'preanalysis_constraint':'Select only three within-page R04 pairs absent from historical R02 pairs, preserving rank conflicts. All calculations conditioned on hit and fixed RD scalar in TEST.',
 'counts':{'physical_pages':len(SOURCES),'action_formulas':sum(len(v['actions']) for v in SOURCES.values()),'page_clusters':3,'rank_homogeneous_certificates':0,'certified_PA_efficiency':0,'math_and_provenance_checks':counts},
 'cases':science,'not_claimed':['official rank benchmarking','win chance','hit probability','VLAB combat executed','new mechanical rule','formal F0 PASS']}
(ROOT/'THREE_SAME_PAGE_ATTRIBUTE_VS_DICE_EXACT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
(ROOT/'SOURCE_REGISTER_THREE_PAGES.json').write_text(json.dumps(source_register,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
with (ROOT/'RD_CURVES_THREE_PAGE_PAIRS.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=list(curves[0]));writer.writeheader();writer.writerows(curves)
print(json.dumps({'counts':out['counts'],'case_summary':[{k:v for k,v in x.items() if k in ('entity','B_minus_A_mean','B_minus_A_attribute','B_minus_A_intrinsic_dice','on_independent_dice_rolls_hypothetical','RD_sign_presence','RD_test_count')} for x in science]},ensure_ascii=False,indent=2))
