#!/usr/bin/env python3
"""Independently enumerate R04 selected formula support and audit all full RD curves."""
from collections import Counter
from itertools import product
from fractions import Fraction
from pathlib import Path
import csv,json,hashlib,zipfile
D=Path(__file__).parent
J=json.loads((D/'THREE_SAME_PAGE_ATTRIBUTE_VS_DICE_EXACT.json').read_text(encoding='utf-8'))
raw=(D/'readonly_sources/R04_ALL_INITIAL_ACTIONS.csv').read_bytes()
assert hashlib.sha256(raw).hexdigest()==J['r04_member_sha256']
source={}
for r in csv.DictReader(raw.decode('utf-8-sig').splitlines()):source.setdefault(r['page_id'],[]).append(r)
curves={}
with (D/'RD_CURVES_THREE_PAGE_PAIRS.csv').open(encoding='utf-8',newline='') as f:
 for r in csv.DictReader(f): curves[(r['physical_page_id'],int(r['rd_test']))]=r
checks=0
for case in J['cases']:
 pid=case['physical_page_id']; rr=source[pid]; assert len(rr)==2
 attacks=[]
 for action in ('A','B'):
  a=case[action]
  rawrow=next(x for x in rr if x['name']==a['name'])
  assert rawrow['literal_formula']==a['literal'];checks+=1
  form=a['literal'].lower().replace(' ','').split('d'); n=int(form[0]);side=int(form[1].split('+')[0]);boost=int(rawrow['attribute_value'] or 0)
  counts=Counter(sum(rolls)+boost for rolls in product(range(1,side+1),repeat=n))
  assert min(counts)==a['min'] and max(counts)==a['max'];checks+=2
  m=Fraction(sum(v*freq for v,freq in counts.items()),sum(counts.values()))
  assert m==Fraction(a['mean']['num'],a['mean']['den']);checks+=1
  attacks.append(counts)
 for rd in range(case['RD_test_count']):
  r=curves[(pid,rd)]
  for tag,cnts in zip(('A','B'),attacks):
   N=sum(cnts.values())
   net=Fraction(sum(freq*max(0,v-rd) for v,freq in cnts.items()),N)
   pos=Fraction(sum(freq for v,freq in cnts.items() if v>rd),N)
   assert net==Fraction(r[tag+'_mean_post']);checks+=1
   assert pos==Fraction(r[tag+'_p_positive']);checks+=1
 assert len({rd for x,rd in curves if x==pid})==case['RD_test_count'];checks+=1
assert sum(c['RD_test_count'] for c in J['cases'])==len(curves)
report={'verdict':'PASS','independent_arithmetic_checks':checks,'rd_curve_rows':len(curves),'physical_page_clusters':3,'source_formula_occurrences':6,'source_zip_hash':J['historical_source_zip_sha256'],'R04_sha256':J['r04_member_sha256'],'no_engine_runs':True,'no_writer':True,'no_normative_promotion':True}
(D/'INDEPENDENT_AUDIT_CYCLE2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
