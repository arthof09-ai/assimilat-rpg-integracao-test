# PSV — DMG C20 | Comparadores, Progressão e Admissibilidade Científica

**MESTRE-ONLY — RPG DO MESTRE / ASSIMILAÇÃO — 20/10/2026**  
**OP existente:** `OP-DMG-CORPUS-EMP-01` · **Coordenação lógica:** `CM-000001` · **Ambiente:** LABORATÓRIO TEST.  
**NORMATIVA:** `DMG-RANK-01 v1.1` intocada. Produção HOLD. Party e O Primeiro NO-WRITE. SQLite VLAB READ-ONLY e NÃO ACESSADO. Sem escritor Notion, lease, epoch, fencing ou ACK reivindicados.

## 1. LAST-VERIFIED-UNIT / ANTES / namespace

**ANTES:** C19 foi comunicado tecnicamente PASS pela Coordenação, o que não é gate empírico global. O ZIP C19 foi recuperado nesta execução da Biblioteca nativa; 15.015 bytes, SHA-256 `bab796d5144c5c5140f6812b28b313ca3d354f13136faee0de737ef3e4e8b627`, CRC PASS. C13/C14/C18 também foram recuperados com ZIP CRC íntegro. **Checagem de namespace antes de criar C20:** 0 arquivos C20 em `/Comestre/OP-DMG-CORPUS-EMP-01/`. Não reemitir C19 e anteriores como novas descobertas.

**DEPOIS científico de C20:** 16 páginas de fontes Mestre reabertas diretamente nesta execução, oito famílias documentais, 20 ocorrências de efeitos ofensivos e oito comparações/candidaturas finitas — **A=0, B=3, C=5**. Matemática nova: Sussurro normalizado com 576 pares de rolagens exatos; sensibilidade contra perfis reais de defesa; controle negativo de duas famílias; matriz de razões para não homologar pares. A documentação foi feita como anexo experimental independente, não como nova regra/OP.

## 2. Reaproveitamento / NO-REPEAT

- **C11–C14:** corpus e método, A6 571 referências estruturais (não D0 global), família Sussurro/Rinolupo/Crocossuário/Hidrargos, Aetheria/Raposa/Wyvern e negativos. As decomposições já publicadas de médias e parcelas de atributos não são descobertas C20.
- **C15:** referência exata Chicote de Água `4d6+19 > CA34`, 435/1296; dependência entre seeds e discrepância ainda não confirmada.
- **C16:** R205 Defesa de Vento e Anel, críticos, censura/KO, sem inferência de vitória. Nenhuma reexecução de R205.
- **C17:** Plano Supremo, triagem da Inbox 18 mensagens, R71 684/R81 128 eventos, F0 A5–A8 sem promoção.
- **C18:** Gorrok 5d8/1d4/4d6, +7 FF, RD15 e separação de dano intrínseco, contextual e pós-RD. Não repetir suas 72 sensibilidades.
- **C19:** chassi prospectivo ×1...×6, 48 cenários de RD, 14 cenários de famílias, conflito RI/RE/FIP e inversão documental. Não repetir esses ensaios.

## 3. Fontes / denominadores / hierarquia

A amostra FINITA C20 foi dirigida por C13/C14, não amostragem probabilística nem censo. **D0 local = 16 source-page IDs realmente reabertos**; **20 EFFECT-OCCURRENCES** entre essas 16 páginas, reunidas em **10 rótulos família×efeito**, mas variantes/versões não constituem 10 definições canônicas únicas certificadas. **Oito famílias**: Sussurro Celestial, Rinolupo, Aetheria, Raposa Flamejante, Hidrargos, Crocossuário, Galinha Demoníaca, Lobo da Caverna. Componentes compostos foram mantidos como ocorrências sem declarar D2 global. Três páginas locais com conflitos TÍTULO×CORPO diretos: Sussurro Ouro5/Ouro1, Raposa Prata5/Bronze5, Hidrargos Ouro5/Ouro4. Crocossuário tem variante Titã e divergência contextual de ancestralidade conhecida.

Todos os ataques examinados carecem de **RE do efeito/FIP independentemente homologados**. Uma página com RN/estrela não atribui automaticamente RE. RI de arma não se confunde com RE. Sem definição adequada de ação, PA, acerto e restrições, o par não ganha grau A por fórmula similar.

**D0–D9 global NÃO FECHADOS.** D0 local 16 páginas, ocorrências ofensivas 20; D6 conflito local >=3 page IDs; D7 RE efetivo desconhecido nas 20 ocorrências; D8 custos/ações faltantes em grande parte; D9 duplicação global não inspecionada neste lote. D1 de definições canônicas, D2 componentes canônicos, D3–D5 e cobertura populacional global permanecem NÃO CERTIFICADOS. Nunca chamar 20 ocorrências de 20 criaturas independentes nem 8 candidatos de 8 amostras independentes.

## 4. Matriz de admissibilidade e resultados B/C

A = par estrito, autoridade RN/RE/FIP/ação/custo/entrega suficientemente reconciliada. B = normalização condicional dentro da mesma família/definição, insuficiente para inferência causal de rank. C = conflito ou confundidor importante. Oito candidatos:

1. **B Sussurro Prata1→Prata5:** mesmo efeito, INT/dados diferem, custo da Prata1 ausente; unidade estatística uma família.
2. **B Sussurro Prata5→Ouro1:** mesmo efeito, INT padronizável mas PA/ação Ouro1 e RE não homologados.
3. **B Rinolupo Prata1→Prata4:** mesma Investida e dados, FOR distinta; PA/ação/acerto/RE ausentes.
4. **C Aetheria ON2→ON4 Titã:** dois efeitos correlacionados da mesma dupla, com Titã/área/controle/ação/PA confundidos.
5. **C Raposa Bronze5→Prata5:** ficha Prata5 tem corpo Bronze5; não imputar progressão entre ranks.
6. **C Hidrargos Ouro4→Ouro5 Titã:** segunda ficha corpo Ouro4; notas `/161`, `/209` não adjudicadas.
7. **C Crocossuário Bronze5→Prata2 Titã:** mudança Titã e contexto, sem PA/RE; não permite isolar classificação.
8. **C Galinha Demoníaca Bronze1→Lobo Prata1:** controle negativo entre famílias: `1d4+DES13` DME contextual 15,5 vs `1d6+FOR24` 27,5. Diferença +12 = +1 de dados e +11 de valores atributivos diferentes; **não** é estimativa de efeito de rank.

**Resultado:** zero pares A. A busca não foi infinita: o escopo fechou em 16 páginas/8 candidatos, e os motivos de exclusão foram especificados. A ausência de pares A neste escopo não demonstra inexistência de pares A no RPG.

## 5. Sussurro Celestial: contrafactual novo C20

Fontes verificadas: `https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b` (P5, `2d6+INT45`, custo 5 PA) e `https://app.notion.com/p/442c2b324ede8364870a814350dd5051` (O1, `2d4+INT26`, PA ausente).

| INT dos dois | Média Prata5 | Média Ouro1 | Delta Ouro−Prata |
| --- | ---: | ---: | ---: |
| Original 45 vs 26 | 52 | 31 | -21 |
| Ambas 26 | 33 | 31 | -2 |
| Ambas 45 | 52 | 50 | -2 |

Decomposição matemática já identificada no C14/C19 e novamente **controlada**, não descoberta atribuída ao C20: `Δ=-21 = -19 INT -2 dados`, 90,476% da diferença absoluta provêm da divergência de INT; 9,524% dos dados.

**NOVO experimento discriminante**: todas as `36×16=576` combinações hipotéticas independentes de `2d6` e `2d4` foram enumeradas. Com INT comum: 398/576 (69,097%) o pool P5 supera O1, 62/576 (10,764%) empata, 116/576 (20,139%) O1 supera P5. Sem normalização, todos os 576 resultados P5 superam O1. Foram conferidos por duas estratégias: PMF por convolução e enumeração explícita de quatro dados. A normalização destrói a separação completa dos suportes, mas mantém vantagem estocástica P5. Não simula ações, custos ou saves.

**Hipótese testada:** “a inversão é apenas INT” = **refutada no sentido matemático estrito** (resíduo intrínseco −2), embora INT explique a maior parte. **Equilíbrio normativo / RE / efeito causal da ascensão:** INDETERMINADOS, por custo Ouro1 desconhecido, possíveis diferenças de versão/ancestralidade/entrega e RE não confirmado.

## 6. Controle independente Aetheria (confundimento Titã)

Páginas `4acc2b324ede8352909d81293c163bbf` (ON2, INT80) e `bc6c2b324ede834cb396816167377462` (ON4 Titã, INT120). Canto das Alturas muda de 171 para 247,5 de média (+76,5), dos quais +40 INT, +33,5 dados, +3 fixo. Com INT80 **em ambas**, as médias são 171 vs 207,5 (+36,5). Lâminas Prismáticas passa de 158 a 230,5 (+72,5), sendo +40 INT, +29,5 dados e +3 fixo; com INT80, 158 vs 190,5 (+32,5). **Esses dois efeitos compartilham as MESMAS duas criaturas e não são amostras independentes.** Resultados condicionais reiteram que dados e atributos podem contribuir conjuntamente, sem isolar rank de Titã.

## 7. Defesas documentadas: mudança da interpretação por RD

Rinolupo Prata1/Prata4: `2d6+FOR30/38`, dano bruto médio 37/45, RDF10 e CA27/41 documentados. Alvos reais consultados: Rinolupo RDF10; Hidrargos Ouro4 RD45 CA82; Hidrargos folha Ouro5/corpo Ouro4 RD50 CA100. A aplicação da **RD genérica Hidrargos a investida física é premissa TEST não homologada**, enquanto a RDF10 é explicitamente resistência física. Nenhum dado de probabilidade de acerto foi fabricado.

| RD documentada | Dano P1 pós-RD/acerto | Dano P4 pós-RD/acerto |
| --- | ---: | ---: |
| RDF 10 (Rinolupo) | 27 | 35 |
| RD 45 (Hidrargos, aplicabilidade condicional) | 0 | 35/36 = 0,972222... |
| RD 50 (Hidrargos conflitado, aplicabilidade condicional) | 0 | 0 |

No alvo RD45, P4 tem **15/36** resultados com dano positivo e P1 0/36. Em RD50, ambos zero; a diferença de +8 DME contextual pode desaparecer completamente. Sem bônus de ataque/RNG/críticos/reação/defesa elementar completos, **dano por tentativa/TTK/win rate/PA não são estimáveis**. Isso não implica erro de norma: demonstra por que comparação de bruto é insuficiente e porque real defender importa.

## 8. VLAB — confronto honesto e dependência

Recuperados em C13–C17, sem reexecutar VLAB:
- R200: sensibilidade de thresholds de CA/RD já publicada, evidência de que precisão pode dominar bruto; não contém intervenção C20 para Sussurro/Rinolupo.
- R204 V2: 40 combates, 184 conjurações, 81 acertos, 3.380 dano pós-RD, 3.322 Vida efetiva, 58 overkill, 1.472 PA, **eventos dependentes, coortes V1/V2/V2B não mescladas**.
- R205: CA71→73 com Defesa de Vento; 28 oportunidades eliminadas em 132 ataques ordinários pareados. Críticos e KO/censura separados. É suporte **metodológico**, não confirmação dos resultados novos de progressão.
- R71/R81: 684+128 recibos recuperados anteriormente; não contam como 812 experimentos independentes; nenhuma ponte matched-control C20 foi certificada com essas coortes.

Contrato Chicote de Água 256 seeds continua PREPARADO/NÃO ENVIADO; não foi submetido/aceito por VLAB nesta execução. **Nenhuma execução nova do VLAB foi inventada.**

## 9. Parecer de melhoria real, proporcional

- **APROVAR APENAS COMO CRITÉRIO TEST DE AVALIAÇÃO:** ficha de comparação de novas criações deve documentar RN/estrela, RE/FIP independente, RI, tipo, entrega, ação, custo, expressão, atributos separados, PMF/caudas, defensor real, CA/acerto, RD pertinente, crítica, Vida efetiva e confiança. É aplicação específica da metodologia e QA já existentes, **não nova norma**.
- **DOCUMENTAÇÃO A CORRIGIR PELA AUTORIDADE COMPETENTE, NÃO POR ESTE EXECUTOR:** título/corpo conflitantes de Sussurro O5, Raposa P5, Hidrargos O5; anexar custos/ações onde fonte os omite. Não editar fichas originais.
- **PRÓXIMA HIPÓTESE FALSIFICÁVEL:** depois de adjudicar custo, RE e linhagem do par Sussurro, comparar as MESMAS habilidades sob INT fixa, custo verificado, mesmo defensor/cenário e streams pareados. Se a vantagem de dados persistir e houver prejuízo de objetivo nas mesmas condições, investigar anomalia localizada; caso contrário manter v1.1. Exige autoridade VLAB somente para combate, não para PMF.
- **DMG-RANK-01 v1.1:** MANTER. Nem C20 nem corpus selecionado permitem recalibração das bandas ou adição de +16 fixo ao chassi Lendário. §22 proíbe duplicar orçamento da ação composta.

## 10. Plano Supremo e gates

**Fase real ativa:** F0 **4/8 HOLD**. A1–A8 são rótulos operacionais da matriz C17, não subnormas canonizadas. **A5** 7/7 anexos Notion localizáveis/links resolvidos em C19, **0/7 bytes de anexos originais rebaixados/confirmados por SHA256 nesta unidade**: assinatura de URL ≠ readback. Referências históricas dos hashes no manifesto `COORD_DMG_F0_A5_SNAPSHOT_ATTACHMENT_MANIFEST_20261016.json`. A6 censo estrutural parcial, A7 holdout blind não selado, A8 segunda codificação e writer não demonstrados. Primeiro gate formal fechável candidato A5 ainda pendente de bytes e autoridade; **nenhum novo PASS formal**.

F1–F12: só INSUMOS LOCAIS para extração/matemática/métricas e viés, sem certificação de cobertura global. F13–F18: candidata/after/validação em mesa/migração não iniciadas. `D0–D9` GLOBAIS desconhecidos; `E01–E24` sem promoção global; **Q-MATH LOCAL PASS** para distribuições explícitas C20, `Q-COVERAGE`, `Q-CODEBOOK` independente, `Q-HOLDOUT`, `Q-TARGET` completo, `Q-REDTEAM`, `Q-TRACE` global: PENDENTES/NOT-TESTED. Oito gates de evidência não foram declarados globalmente concluídos. Holdouts anteriores preservados; B01–B18, STRICT, L002/L003 não alterados nem falsamente completados. R138 HOLD; R156 UNKNOWN-EFFECT; A5/A7/A8 HOLD.

## 11. Inbox específica DMG

`IBX-102` adotar orientação Plano Supremo; `103` evidência R71/R81 reaproveitada sem simular; `98` réplica TEST permitida; `94` manual do laboratório existente; `92` Galidemus Bronze1 reaberto, questões iniciativa/reação VLAB pendentes; `119` R205 já tratado C16 e PA R42 sem novo efeito numérico admissível; `124` triagem e realinhamento cumpridos parcialmente C17–C20. Estados administrativos LIDA/ACK/CONCLUÍDA **não modificados**. Fonte `IBX-102`: https://app.notion.com/p/3fbc2b324ede813285ebfeaeee964f25 ; `IBX-124`: https://app.notion.com/p/3ffc2b324ede81099311f9621b41273a .

## 12. Artefatos, verificação, NAC-PASS, FIRST-PENDING

**Pacote C20:** fontes CSV, candidatos A/B/C, contrafactual PMF/enumeração, controles Aetheria, perfis reais de RD condicionados, controle negativo, Inbox, ponte VLAB, matriz F0–F18, resumo científico, código de reprodução sem rede, manifesto de SHA256 e este PSV. **Readback da Biblioteca e seu hash são informados em recibo aditivo após efetiva persistência; NÃO antecipar PASS.**

**GATE DE AUTORIDADE:** pesquisa e arquivos TEST na Biblioteca Mestre existente permitidos conforme governança; writer canônico Notion não demonstrado e **não exercido**; Party/O Primeiro/fichas/sistemas/VLAB não alterados. `NAC-PASS-02`: somente matemática e integridade técnica locais sujeitas a readback; NENHUM PASS global, nenhuma v2 promulgada.

**LAST-VERIFIED-UNIT previsto após readback:** C20 científico LOCAL, mantendo C19 documentalmente PASS. **FIRST-PENDING:** (i) RE/FIP/ação/custo homologados para pelo menos um par dentro da mesma família; (ii) sete anexos A5 recuperados com bytes/hash; (iii) perfil RD e bônus de acerto competente; (iv) separação holdout/adjudicação de conflitos.  
**NEXT-5:** 1) recuperar a fonte competente de custo/ação de Sussurro Ouro1; 2) reconciliar RE/FIP independentemente do RN e cruzar status; 3) confirmar escopo RD45 Hidrargos / bônus de acerto; 4) projetar contrato VLAB matched-case **se** inputs homologados; 5) autenticar bytes A5 e solicitar revisão independente do codebook.  
**TARGET-REMAINDER:** avançar F0 A5/A7/A8 quando houver evidência física, crescer corpus estrito por novas superfícies/famílias, executar análise de cobertura F1–F12, somente depois considerar candidata F13–F18.

**DECISÃO:** C20 é ciência source-scoped auditável de maior poder discriminante; **não** é homologação normativa ou declaração de defeito universal do jogo.
