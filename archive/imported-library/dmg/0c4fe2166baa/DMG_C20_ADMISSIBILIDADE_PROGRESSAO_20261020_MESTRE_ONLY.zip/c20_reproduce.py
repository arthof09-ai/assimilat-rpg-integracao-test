#!/usr/bin/env python3
"""DMG C20 MESTRE-SIDE TEST. Recomputable exact mathematics from a closed, source-scoped Notion ledger.
Does not connect to or edit live Notion, Party, VLAB, or rules.
"""
from __future__ import annotations
import csv,json,hashlib,zipfile,collections,math,os
from pathlib import Path
from itertools import product
from fractions import Fraction
BASE=Path(__file__).resolve().parent
URL=lambda id:'https://app.notion.com/p/'+id

def dice(n, sides):
    p={0:1}
    for _ in range(n):
        nextp=collections.Counter()
        for value,number in p.items():
            for face in range(1,sides+1): nextp[value+face]+=number
        p=dict(nextp)
    assert sum(p.values())==sides**n
    return p,sides**n

def expectation(p,den,shift=0,rd=0):
    return Fraction(sum(c*max(0,k+shift-rd) for k,c in p.items()),den)

def asfloat(x):return round(float(x),12)

def writecsv(name,head,rows):
    with open(BASE/name,'w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=head); writer.writeheader();writer.writerows(rows)

def writejson(name,value):
    (BASE/name).write_text(json.dumps(value,sort_keys=True,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

sources=[ # page_id, family, source leaf, body RN, attack/ability, literal damage, attr, kind, extras
('56ac2b324ede8352868101e11ea16355','Sussurro Celestial','Prata 1','Prata 1','Lâmina de Brisa','1d6+INT',30,'vento','ação/PA faltantes'),
('5e9c2b324ede83ed99078151805dec0b','Sussurro Celestial','Prata 5','Prata 5','Lâmina de Brisa','2d6+INT',45,'vento','5 PA; ação/acerto faltantes'),
('442c2b324ede8364870a814350dd5051','Sussurro Celestial','Ouro 1','Ouro 1','Lâmina de Brisa','2d4+INT',26,'vento','ação/PA/acerto faltantes'),
('597c2b324ede8242bd5881027ef8d21f','Sussurro Celestial','Ouro 5','Ouro 1','Lâmina de Brisa','2d4+INT',40,'vento','título/corpo CONFLITO, excluir promoção Ouro5'),
('034c2b324ede83ffa7118144011beaf3','Rinolupo','Prata 1','Prata 1','Investida Feroz','2d6+FOR',30,'chifres/carga físico inferido','CA27; RDF10; ação/PA/acerto faltantes'),
('a47c2b324ede821f834481bef49fb8e3','Rinolupo','Prata 4','Prata 4','Investida Feroz','2d6+FOR',38,'chifres/carga físico inferido','CA41; RDF10; ação/PA/acerto faltantes'),
('4acc2b324ede8352909d81293c163bbf','Aetheria','Ouro Negro 2','Ouro Negro 2','Canto das Alturas','14d6+42+INT',80,'vento/área controle','PA/ação/acerto e área exata faltantes'),
('4acc2b324ede8352909d81293c163bbf','Aetheria','Ouro Negro 2','Ouro Negro 2','Lâminas de Luz Prismática','12d6+36+INT',80,'luz/linha sangramento','PA/ação/acerto faltantes'),
('bc6c2b324ede834cb396816167377462','Aetheria','Ouro Negro 4 Titã','Ouro Negro 4','Canto das Alturas','15d10+45+INT',120,'vento/área controle','Titã; PA/ação/acerto faltantes'),
('bc6c2b324ede834cb396816167377462','Aetheria','Ouro Negro 4 Titã','Ouro Negro 4','Lâminas de Luz Prismática','13d10+39+INT',120,'luz/linha sangramento','Titã; PA/ação/acerto faltantes'),
('529c2b324ede82e8a86f81f8cfc0477e','Raposa Flamejante','Bronze 5','Bronze 5','Punhos de Fogo','1d4',0,'fogo físico/misto não explicitado','ação/PA faltantes'),
('529c2b324ede82e8a86f81f8cfc0477e','Raposa Flamejante','Bronze 5','Bronze 5','Soco','1d6+FOR',20,'físico (inferido)','ação/PA faltantes'),
('2f3c2b324ede830c94af0113e39a1a50','Raposa Flamejante','Prata 5','Bronze 5','Punhos de Fogo','1d4',0,'fogo físico/misto não explicitado','título/corpo conflito; ação/PA faltantes'),
('2f3c2b324ede830c94af0113e39a1a50','Raposa Flamejante','Prata 5','Bronze 5','Soco','1d6+FOR',60,'físico (inferido)','título/corpo conflito; ação/PA faltantes'),
('b85c2b324ede824dbfb301ccd441a96e','Hidrargos','Ouro 4 Titã','Ouro 4','Mordida','6d12+120 / 161 de Dano',120,'físico (inferido)','RD45, CA82; nota /161 não reconciliada'),
('bc7c2b324ede82ef97330199ec466b1b','Hidrargos','Ouro 5 Titã','Ouro 4','Mordida','10d12+145 / 209 de Dano',145,'físico (inferido)','RD50, CA100; título/corpo CONFLITO; nota /209 não reconciliada'),
('a01c2b324ede8347b691819d3509d7d7','Crocossuário','Bronze 5','Bronze 5','Mordida Trituradora','1d6+1d4+FOR',22,'perfurar (texto) / físico','CA34; ação/PA faltantes'),
('ca3c2b324ede83ef923501ae00136097','Crocossuário','Prata 2 Titã','Prata 2','Mordida Trituradora','2d6+FOR',32,'perfurar (texto) / físico','Titã; CA51; ação/PA faltantes'),
('eddc2b324ede829f8a75011e8acbf429','Galinha Demoníaca','Bronze 1','Bronze 1','Patada','1d4+DES',13,'cortante (literal)','CA21; PA/ação/acerto faltantes'),
('be5c2b324ede832e8b7a81c5460571c1','Lobo da Caverna','Prata 1','Prata 1','Patada','1d6+FOR',24,'físico inferido','CA34; PA/ação/acerto faltantes'),
]
assert len(sources)==20 and len(set(s[0] for s in sources))==16 and len(set(s[1] for s in sources))==8
pages=sorted(set(s[0] for s in sources))
occ=[]
for id,fam,leaf,body,effect,formula,attr,tag,notes in sources:
    status='CONFLITANTE' if ('CONFLITO' in notes or 'conflito' in notes) else 'PARCIAL'
    occ.append(dict(source_url=URL(id),page_id=id,family=fam,title_rank=leaf,body_rank=body,effect=effect,literal_formula=formula,attribute=attr,tag=tag,RE_effect='NÃO RECONCILIADO',FIP='NÃO RECONCILIADO',RI='NÃO APLICÁVEL/UNKNOWN',action='NÃO DOCUMENTADA',PA='5 (SUSS P5)' if id.startswith('5e9c') else 'NÃO DOCUMENTADO',status=status,remarks=notes,readback='NOTION_FETCH_C20',origin='MASTER_SIDE_READ_ONLY'))
writecsv('C20_SOURCE_20_OCCURRENCES_16_PAGES.csv',list(occ[0]),occ)

pairs=[
 dict(case='SUSS_P1_P5',family='Sussurro Celestial',from_rank='Prata 1',to_rank='Prata 5',grade='B',reason='mesma definição, atributos/dados variam; PA P1 desconhecido; RE/FIP e ação ausentes; ancestrais Ouro5',denominator='1 família; 2 páginas; 1 par dependente'),
 dict(case='SUSS_P5_O1',family='Sussurro Celestial',from_rank='Prata 5',to_rank='Ouro 1',grade='B',reason='mesma definição, modelo normalizável; Ouro1 PA/acerto/ação ausentes; RE/FIP não demonstrados',denominator='1 família; 2 páginas; 1 par dependente'),
 dict(case='RIN_P1_P4',family='Rinolupo',from_rank='Prata 1',to_rank='Prata 4',grade='B',reason='mesma Investida, FOR varia, dado estável; custo/ação/RE não demonstrados; defesa de espécie fixa',denominator='1 família; 2 páginas; 1 par dependente'),
 dict(case='AETH_ON2_ON4_TITAN',family='Aetheria',from_rank='Ouro Negro 2',to_rank='Ouro Negro 4 Titã',grade='C',reason='mudança Titã, INT/fixos/dados/ação/custo/área/controle confusos; dois efeitos da MESMA dupla não independentes',denominator='1 família; 2 páginas; 2 efeitos correlacionados'),
 dict(case='RAP_B5_P5_CONFLICT',family='Raposa Flamejante',from_rank='Bronze 5',to_rank='Prata 5 título / Bronze 5 corpo',grade='C',reason='título/corpo conflitantes; soco não prova progressão de rank',denominator='1 família; 2 páginas; 2 efeitos correlacionados'),
 dict(case='HID_O4_O5_CONFLICT',family='Hidrargos',from_rank='Ouro 4 Titã',to_rank='Ouro 5 Titã título / Ouro 4 corpo',grade='C',reason='título/corpo conflitantes; /161 /209 não interpretados; Titã',denominator='1 família; 2 páginas; 1 efeito dependente'),
 dict(case='CROC_B5_P2_TITAN',family='Crocossuário',from_rank='Bronze 5',to_rank='Prata 2 Titã',grade='C',reason='mudança Titã + possível efeito de rank; ação/PA e RE insuficientes; ancestralidade conflitante',denominator='1 família; 2 páginas; 1 efeito dependente'),
 dict(case='GAL_B1_LOBO_P1_NEGATIVE',family='Galinha Demoníaca / Lobo da Caverna',from_rank='Bronze 1',to_rank='Prata 1',grade='C',reason='controle negativo: famílias diferentes, DES contra FOR, 1d4 contra 1d6; patada cortante vs físico indeterminado',denominator='2 famílias; 2 páginas; 1 par NÃO homogêneo'),
]
writecsv('C20_ADMISSIBILITY_8_PAIRS.csv',list(pairs[0]),pairs)
assert sum(p['grade']=='A' for p in pairs)==0 and sum(p['grade']=='B' for p in pairs)==3

silver,ds=dice(2,6);gold,dg=dice(2,4);assert(ds,dg)==(36,16)
controls=[]
for name,s_int,g_int in [('ORIGINAL',45,26),('INT_COMMON_26',26,26),('INT_COMMON_45',45,45)]:
    b=expectation(silver,ds,s_int);g=expectation(gold,dg,g_int)
    # exact independent product PMFs, without conflating with game combat correlations
    gt=eq=lt=0
    for a,ca in silver.items():
        for z,cb in gold.items():
            x,y=a+s_int,z+g_int
            if x>y:gt+=ca*cb
            elif x==y:eq+=ca*cb
            else:lt+=ca*cb
    assert gt+eq+lt==576
    controls.append(dict(case=name,INT_silver=s_int,INT_gold=g_int,silver_intrinsic_mean=7,gold_intrinsic_mean=5,mean_silver=asfloat(b),mean_gold=asfloat(g),delta_gold_minus_silver=asfloat(g-b),p_silver_gt_gold_n=gt,p_equal_n=eq,p_gold_gt_silver_n=lt,total_outcomes=576,p_silver_gt_gold=round(gt/576,12),p_gold_gt_silver=round(lt/576,12),method='EXACT_PMF_INDEPENDENT_HYPOTHETICAL_DRAWS'))
assert controls[0]['p_silver_gt_gold_n']==576
assert controls[1]['p_silver_gt_gold_n']==398 and controls[1]['p_equal_n']==62 and controls[1]['p_gold_gt_silver_n']==116
assert controls[2]['p_silver_gt_gold_n']==398
writecsv('C20_SUSS_EXACT_ATTRIBUTE_STANDARDIZATION.csv',list(controls[0]),controls)

# New independent method: full 4-die ordered exhaustive enumeration exactly 576 outcomes
for row in controls:
    s_int,g_int=row['INT_silver'],row['INT_gold']
    gt=sum(1 for a,b,c,d in product(range(1,7),range(1,7),range(1,5),range(1,5)) if a+b+s_int>c+d+g_int)
    assert gt==row['p_silver_gt_gold_n']

# Independent corroborating family: Aetheria; mechanics are NOT strictly comparable due to Titan.
aeth=[]
for effect,nlow,dlow,fixlow,nhigh,dhigh,fixhigh in [
('Canto das Alturas',14,6,42,15,10,45),
('Lâminas de Luz Prismática',12,6,36,13,10,39)]:
    for scenario,lowint,highint in [('ORIGINAL',80,120),('COMMON_INT_80',80,80),('COMMON_INT_120',120,120)]:
        elo=Fraction(nlow*(dlow+1),2)+fixlow+lowint
        ehi=Fraction(nhigh*(dhigh+1),2)+fixhigh+highint
        aeth.append(dict(family='Aetheria',effect=effect,grade='C',scenario=scenario,mean_ON2=asfloat(elo),mean_ON4_Titan=asfloat(ehi),delta=asfloat(ehi-elo),dice_delta=asfloat(Fraction(nhigh*(dhigh+1)-nlow*(dlow+1),2)),fixed_delta=fixhigh-fixlow,attribute_delta=highint-lowint,Titan_confounded=True,RE_undetermined=True,PA_undetermined=True))
assert aeth[0]['delta']==76.5 and aeth[0]['dice_delta']==33.5
writecsv('C20_AETHERIA_TITAN_ATTR_CONTROL.csv',list(aeth[0]),aeth)

# Physical melee, defendant source grounding: Rinolupo RDF10, Hidrargos RD45 and RD50.
# General RD45/50 applicability to physical attacks NOT verified; results conditional ONLY.
phys=[]
for target,source,rd,ca,certainty in [
 ('Rinolupo Prata 1','034c2b324ede83ffa7118144011beaf3',10,27,'RDF 10 explicit, Investida physical inferred'),
 ('Rinolupo Prata 4','a47c2b324ede821f834481bef49fb8e3',10,41,'RDF 10 explicit, Investida physical inferred'),
 ('Hidrargos Ouro 4','b85c2b324ede824dbfb301ccd441a96e',45,82,'RD 45 general, physical applicability unverified'),
 ('Hidrargos Ouro 5 title/Ouro 4 body','bc7c2b324ede82ef97330199ec466b1b',50,100,'RD 50 general, rank CONFLICT; physical applicability unverified')]:
 for attacker,attr in [('Rinolupo Prata 1',30),('Rinolupo Prata 4',38)]:
    p,den=dice(2,6)
    mean=expectation(p,den,attr,rd)
    positive=sum(c for v,c in p.items() if v+attr>rd)
    phys.append(dict(attacker=attacker,target=target,defender_url=URL(source),documented_CA=ca,documented_RD=rd,attack_literal='2d6+FOR',attacker_FOR=attr,gross_mean=attr+7,post_RD_mean=asfloat(mean),post_RD_exact_numerator=mean.numerator,post_RD_exact_denominator=mean.denominator,p_positive_given_hit=round(positive/den,12),positive_dice_outcomes=positive,possible_dice_outcomes=den,mitigation_assumption=certainty,hit_probability='UNKNOWN',damage_per_attempt='UNKNOWN',critical_effect='NOT_EVALUATED',scope='CONDITIONAL_TEST_NOT_VLAB'))
assert next(x for x in phys if x['documented_RD']==45 and x['attacker_FOR']==38)['post_RD_mean']==round(35/36,12)
writecsv('C20_REAL_DOCUMENTED_DEFENDER_CONDITIONAL.csv',list(phys[0]),phys)

# Additional scoped control: two cross-family patada effects: mean difference cannot indicate rank causation.
negative=dict(familyA='Galinha Demoníaca',rankA='Bronze 1',damageA='1d4+DES13',meanA=15.5,familyB='Lobo da Caverna',rankB='Prata 1',damageB='1d6+FOR24',meanB=27.5,total_difference=12.0,change_in_dice_mean=1.0,change_in_ATTRIBUTE_VALUE=11.0,valid_rank_causal_inference=False,negative_control='C_ONLY_DISTINCT_FAMILY_DISTINCT_ATTRIBUTE_TYPE_ABILITY_DELIVERY')
writejson('C20_NEGATIVE_CROSS_FAMILY_CONTROL.json',negative)

# Carry forward VLAB evidence without treating event rows as independent combat units.
vlab=[
 dict(cohort='R200',source='C13 archived receipts',evidence='attack threshold/RD variability in scoped historical TEST',independence='RUN/SEED not each hit',C20_use='methodological correspondence only; no Sussurro/Rinolupo same-case validation',admission='REUSED_SCOPED'),
 dict(cohort='R204 V2',source='C14/C15 archived',evidence='40 fights, 184 admitted spells, 81 hits, 3380 post-RD, 3322 Vida, 58 overkill, 1472 PA',independence='40 fights in known seeds; 184 casts are dependent events',C20_use='no alignment to new family comparisons, NOT confirmatory for rank',admission='REUSED_SCOPED'),
 dict(cohort='R205',source='C16 archived',evidence='Defesa de Vento CA71->73, 28 ordinary opportunities removed in 132 paired attacks',independence='six pairs / ten seeds originally; events dependent',C20_use='supports separating chance of hit from conditional magnitude, no new fight',admission='REUSED_SCOPED'),
 dict(cohort='R71/R81',source='C17 recovered handoff',evidence='684 plus 128 attack event receipts',independence='unknown independent event clusters until grouping',C20_use='no matched source-to-rank experimental bridge certified',admission='READONLY_HANDOFF_NOT_REANALYZED')]
writecsv('C20_VLAB_EVIDENCE_BRIDGE.csv',list(vlab[0]),vlab)

inbox=[('IBX-102','ADOTAR','Plano Supremo F0–F18 prioriza resultados; C17/C19 recuperados; sem writer/ACK','F0-A5, F4–F6','ACK legítimo pendente'),('IBX-103','APROVEITAR PARCIAL','R71 684/R81 128 recuperados C17; eventos dependentes; não simular novamente','F7–F12','ACK pendente'),('IBX-98','ADOTAR','réplicas TEST permitidas, fontes originais READ-ONLY','TEST','ACK pendente'),('IBX-94','ADOTAR','manual laboratório existente; não criar motor','F0/Q-MATH','ACK pendente'),('IBX-92','ADIAR NORMATIVO','Galidemus reaberto Bronze1; não decidir iniciativa/reação VLAB','G4–G6','resposta e autoridade pendentes'),('IBX-119','APROVEITAR PARCIAL','R205 defesa já avaliada C16; R42 PA não demonstrada numericamente','F6/QA','sem ACK exigido'),('IBX-124','ADOTAR/ATENDER PARCIAL','triagem e orientação F0 executadas em C17–C20','F0/continuidade','sem ACK exigido')]
writecsv('C20_INBOX_SCIENCE_TRIAGE.csv',['inbox_id','decision','documented_marginal_value','plan_relationship','ack_status'],[dict(zip(['inbox_id','decision','documented_marginal_value','plan_relationship','ack_status'],x)) for x in inbox])

phase=[]
for i in range(19):
    status='PARCIAL_LOCAL_4_OF_8_HOLD' if i==0 else ('INSUMOS_LOCAIS_SEM_PROMOCAO' if i<=12 else 'NAO_INICIADA_CANDIDATA')
    gap='F0-A5 7/7 refs, 0/7 bytes redownload; writer/holdout/indep audit' if i==0 else ('corpus global, categorias, coortes, cobertura e aceites ainda não certificados' if i<=12 else 'candidata v2, before/after, playtest e aprovação inexistentes')
    phase.append(dict(phase=f'F{i}',state=status,evidence='C11-C20 source-scoped scientific increments; no global promotion' if i<13 else 'no validated v2',scope='LOCAL_ONLY',gap=gap,writer='HOLD',dependency='DMG/VLAB/Mestre conforme fase',Q_GATES='NOT_GLOBAL_PASS'))
writecsv('C20_PHASE_F0_F18_MATRIX.csv',list(phase[0]),phase)

f0=dict(gate='F0-A5',original_sources=7,reference_links_resolved_in_C19=7,attachment_raw_bytes_readback_C20=0,sha256_original_verification='PENDING',formal_F0='4/8 HOLD',notes='signed download URLs resolved in C19; URL resolution is NOT byte readback, nor certification of immutable original text')
writejson('C20_F0_A5_STATE.json',f0)

summary=dict(as_of='2026-10-20',operation='OP-DMG-CORPUS-EMP-01',checkpoint='C20',C19_sha256_reverified='bab796d5144c5c5140f6812b28b313ca3d354f13136faee0de737ef3e4e8b627',sources_pages_unique=len(pages),families_unique=len(set(s[1] for s in sources)),effect_occurrences=len(occ),family_effect_labels=len(set((s[1],s[4]) for s in sources)),pair_candidates=len(pairs),gradeA=0,gradeB=3,gradeC=5,canonical_RE_resolved_for_pairs=0,suss_decomposition=dict(delta_total=-21,delta_attribute=-19,delta_dice=-2,attribute_fraction=19/21,dice_fraction=2/21),suss_counterfactual_probs=dict(silver_wins=Fraction(398,576).__str__(),draws=Fraction(62,576).__str__(),gold_wins=Fraction(116,576).__str__()),defender_RD45=dict(RinoP1=0,RinoP4='35/36',p_P4_positive='15/36'),rigor='exact arithmetic, conditional on hit; no VLAB new runs',f0='4/8 HOLD',party_no_write=True,notion_no_write=True,global_NAC_PASS='HOLD',RE='unknown for studied individual effects')
writejson('C20_SCIENTIFIC_CHECKS.json',summary)

# Repeatability/invariant tests of results
assert len(phys)==8 and len(aeth)==6 and len(controls)==3 and len(occ)==20 and len(pairs)==8
assert sum(x['grade']=='C' for x in pairs)==5
assert controls[0]['delta_gold_minus_silver']==-21 and controls[1]['delta_gold_minus_silver']==-2
assert [x['post_RD_mean'] for x in phys if x['documented_RD']==50]==[0,0]
assert [x['post_RD_mean'] for x in phys if x['documented_RD']==10][:2]==[27,35]

print(json.dumps({'status':'PASS_LOCAL_Q_MATH','pages':len(pages),'effects':len(occ),'families':8,'pairs':len(pairs),'strictA':0,'normalizedB':3,'exploratoryC':5,'suss_chances_normalized':{'P5_gt_O1':398,'ties':62,'P5_lt_O1':116,'denom':576},'real_defender_RD45':{'P1':0,'P4':'35/36'}},ensure_ascii=False,sort_keys=True))
