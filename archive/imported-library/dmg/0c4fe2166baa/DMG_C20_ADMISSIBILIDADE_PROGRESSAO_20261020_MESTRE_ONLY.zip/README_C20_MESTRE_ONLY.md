# C20 — instruções de reprodução (MESTRE-SIDE)

**Escopo:** oito famílias, 16 páginas Mestre reabertas via Notion, 20 ocorrências de efeitos, oito pares candidatos. O método não executa combates nem consulta dados pessoais. Todos os dados de fontes foram extraídos para um livro razão delimitado, com URLs de origem. Sem rank de efeito atribuído artificialmente.

Rode `python c20_reproduce.py` na pasta extraída em Python 3 padrão, **sem rede**. Gera os arquivos `C20_SOURCE_20_OCCURRENCES_16_PAGES.csv`, `C20_ADMISSIBILITY_8_PAIRS.csv`, `C20_SUSS_EXACT_ATTRIBUTE_STANDARDIZATION.csv`, `C20_AETHERIA_TITAN_ATTR_CONTROL.csv`, `C20_REAL_DOCUMENTED_DEFENDER_CONDITIONAL.csv`, `C20_NEGATIVE_CROSS_FAMILY_CONTROL.json`, `C20_VLAB_EVIDENCE_BRIDGE.csv`, `C20_INBOX_SCIENCE_TRIAGE.csv`, `C20_PHASE_F0_F18_MATRIX.csv`, `C20_F0_A5_STATE.json`, `C20_SCIENTIFIC_CHECKS.json`.

**Aviso:** A pesquisa não congela os bytes integrais das páginas Notion. Reabrir fontes e hashes/versões antes de promover um efeito. C20 não substitui `DMG-METHOD-EMP-01`, `DMG-QA-ACCEPT-01` nem `DMG-RANK-01 v1.1`. Sussurro com INT igual é um contrafactual puramente matemático. RD45/50 de Hidrargos é documentada, mas sua aplicação à Investida é uma suposição explícita. Probabilidades de acerto, turnos, críticos e efeitos VLAB não são simulados.
