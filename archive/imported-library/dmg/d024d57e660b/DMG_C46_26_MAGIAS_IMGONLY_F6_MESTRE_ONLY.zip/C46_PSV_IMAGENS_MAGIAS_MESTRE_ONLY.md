# C46 — Triagem F6: 26 magias de catálogo com mecânica baseada em imagem (MESTRE-ONLY)

**Data:** 22/10/2026. **Operação:** OP-DMG-CORPUS-EMP-01. **Governança:** baseline DMG-RANK v1.1 intacta, Party/O Primeiro NO-WRITE, sem write de Notion/OP/Diário ou na estrutura do catálogo.

## Achado VERIFICADO

Reabertas 26/26 páginas-filha diretas do índice de Magias no **Party (Mestre — Espelho)** do Notion Mestre, por URL de Page-ID e conector do espaço do Mestre. **Todas as 26** continham um bloco de imagem e um preço MED como único conteúdo textual não estrutural visível; 0/26 continham mecânica de RE/FIP, dano, ação, PA e alvos em texto recuperado. Cobertura de rótulos de página: Bronze 2; Prata 6; Ouro 13; Ouro Negro 4; Lendário 1. Inventário de fonte no CSV preserva os 26 Page-IDs/links/preços/ranks textuais.

**Cautela central:** `conteúdo não está no corpo textual` ≠ `conteúdo mecânico não existe`. Não foram baixados/inspecionados os 26 arquivos de imagem privados. O conteúdo mecânico da imagem permanece **DESCONHECIDO**, nunca codificado como zero-dano. Preço em MED não autoriza inferir DME, rank do efeito, FIP ou perfil ofensivo. Nome da magia não transforma controle/defesa em dano. Não usar fallback F6 com base em preço e rótulo de classificação.

As mesmas 26 páginas já pertenciam à união física C42 de 870 Page-IDs: **delta D0=0**; neste trabalho houve aprofundamento **sem duplicar contagem**.

## Limite da evidência

A fonte está no **espelho Mestre da Party**, não no catálogo primário independente de todos os materiais; a autoridade da Party oficial prevalece onde aplicável, mas não se faz leitura/escrita da Party original. A imagem original pode conter elementos relevantes que o fetch Notion não inclui em texto: não é legítimo carimbar nenhuma página como *efeito sem dano explícito* antes de conferir a imagem com autorização.

## Protocolo F6 aplicável

1. Caso texto mecânico completo já exista: usar o valor explícito e não aplicar DMG-RANK a posteriori.
2. Caso o texto não mostre a mecânica mas haja imagem: classificar `MEDIA_UNREAD`, F6 HOLD; requer leitura de imagem pelo conector privado apto.
3. Caso a magia não seja ofensiva: nunca inserir dano por classificação de nome/rank.
4. Caso ofensiva sem dano explícito e imagem efetivamente lida: ainda exigir RE/FIP próprio, ação, custo, alvo, defesa, duração, entrega, autoridade canônica e gate de validação.
5. Nunca recalibrar sem mesmo cenário, mesmo ator, mesmos alvos/seeds e controles antes/depois.

## Gates e pendência

Censo físico delimitado 870 IDs, D0 global não encerrado. F0 4/8 documental HOLD. A5 bytes 0/7, A7 holdout sem prova de cegamento, A8 revisor humano cego + writer/epoch/lease não demonstrados. F6 positivo elegível 0/26 **nesta triagem documental de imagem não lida**. `LAST-VERIFIED=C46/26` e `FIRST-PENDING=verificar imagens por canal autorizado, OU selecionar outras fontes textuais competentes e inéditas`. Não repetir leitura textual dos 26 IDs.
