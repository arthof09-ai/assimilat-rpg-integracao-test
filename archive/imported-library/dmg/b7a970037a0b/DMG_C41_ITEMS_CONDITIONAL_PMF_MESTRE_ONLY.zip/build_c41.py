from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib, json, csv, math, zipfile
OUT=Path(__file__).parent

def pmf(pool,constant):
 c=Counter({constant:1})
 for n,sides in pool:
  for _ in range(n):
   nc=Counter()
   for raw,m in c.items():
    for face in range(1,sides+1):nc[raw+face]+=m
   c=nc
 den=math.prod(sides**n for n,sides in pool)
 assert sum(c.values())==den
 return c,den

def measure(pool,base,rd):
 c,N=pmf(pool,base)
 E=Fraction(sum(v*k for k,v in c.items()),N)
 post=Fraction(sum(max(0,k-rd)*v for k,v in c.items()),N)
 chance=Fraction(sum(v for k,v in c.items() if k>rd),N)
 var=Fraction(sum(k*k*v for k,v in c.items()),N)-E*E
 return {'E_raw':str(E),'E_post_RD':str(post),'E_post_RD_dec':round(float(post),7),'P_pass_RD':str(chance),'P_pass_RD_dec':round(float(chance),7),'variance':str(var),'min_raw':min(c),'max_raw':max(c),'count_support':len(c)}

cases={
 'martelo_base': {'dice':[(8,10)],'fixed':12,'source':'3f5c2b324ede81658982d8f47b3ad647','rank':'ON-Média ITEM','profile':'Ataque Padrão em criatura/estrutura; 1 acerto por golpe'},
 'martelo_estrutura_ativo': {'dice':[(8,10),(6,8)],'fixed':12,'source':'3f5c2b324ede81658982d8f47b3ad647','rank':'ON-Média ITEM','profile':'APENAS estrutura não viva; 25 PA; 1/8h; após acerto'},
 'manopla_extra_raio': {'dice':[(5,8)],'fixed':3,'source':'3f5c2b324ede81f5ac62fb940204cdac','rank':'Ouro Entrada ITEM','profile':'Somente bônus extra ao golpe acertado; 22 PA; 1/8h; sem ataque extra'},
 'lamina_base': {'dice':[(7,8)],'fixed':15,'source':'3f5c2b324ede81e9aa8ec51f568600e8','rank':'ON Entrada ITEM','profile':'Golpe físico Padrão; reação defensiva distinta; custo reação 18 PA'}
}
assert measure(cases['martelo_base']['dice'],12,0)['E_raw']=='56'
assert measure(cases['martelo_estrutura_ativo']['dice'],12,0)['E_raw']=='83'
assert measure(cases['manopla_extra_raio']['dice'],3,0)['E_raw']=='51/2'
assert measure(cases['lamina_base']['dice'],15,0)['E_raw']=='93/2'

cfile=OUT/'C41_PMF_ITEM_INTRINSECO_CONDICIONAL_24_ROWS.csv'
RDs=[0,20,35,50,75,100]
checks=0
with cfile.open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['case','rank_FIP_do_item','dados','fixo','RD_HIPOTETICA','media_bruta','media_pos_RD_exata','media_pos_RD_decimal','P_D_supera_RD_exata','P_D_supera_RD_decimal','variancia','range','source_id','regras_de_contexto'])
 for name,c in cases.items():
  lastE=None;lastP=None
  for RD in RDs:
   t=measure(c['dice'],c['fixed'],RD)
   thisE=Fraction(t['E_post_RD']);thisP=Fraction(t['P_pass_RD'])
   assert thisE>=0 and thisP>=0 and thisP<=1; checks+=4
   if lastE is not None:assert thisE<=lastE and thisP<=lastP;checks+=2
   lastE,lastP=thisE,thisP
   w.writerow([name,c['rank'],'+'.join(str(n)+'d'+str(s) for n,s in c['dice']),c['fixed'],RD,t['E_raw'],t['E_post_RD'],t['E_post_RD_dec'],t['P_pass_RD'],t['P_pass_RD_dec'],t['variance'],str(t['min_raw'])+'..'+str(t['max_raw']),c['source'],c['profile']])
# zero-RD means E bruto for positive damage
for name,v in cases.items():
 assert measure(v['dice'],v['fixed'],0)['E_raw']==measure(v['dice'],v['fixed'],0)['E_post_RD'];checks+=1
# hammer: active mode never less damage per paired identical base rolls (add dice>=6)
for RD in RDs:
 m0=measure(cases['martelo_base']['dice'],12,RD)
 m1=measure(cases['martelo_estrutura_ativo']['dice'],12,RD)
 assert Fraction(m1['E_post_RD'])>=Fraction(m0['E_post_RD']); checks+=1
 # causal effect: exactly 6d8 added mean27 before RD; after RD nonlinear
 if RD==0:assert Fraction(m1['E_post_RD'])-Fraction(m0['E_post_RD'])==27; checks+=1
# crit=normal dice roll plus max of dice component, not separate guaranteed burst or free action
critfixed={'martelo_base':80,'martelo_estrutura_ativo':80+48,'manopla_extra_raio':40,'lamina_base':56}
for name,c in cases.items():
 n=critfixed[name];maxdice=sum(num*side for num,side in c['dice'])
 assert n==maxdice;checks+=1
 assert Fraction(measure(c['dice'],c['fixed']+n,0)['E_raw'])==Fraction(measure(c['dice'],c['fixed'],0)['E_raw'])+n;checks+=1
# defense Selo: per target shield 60, same damage occurrence, max 3 targets and once use; no offensive DME created
seals=[]
for targets in range(1,4):
 for incoming in [0,10,59,60,80,120,200]:
  per=min(incoming,60)
  absorbed=per*targets
  remaining=targets*(incoming-per)
  assert absorbed+remaining==targets*incoming;checks+=1
  assert absorbed<=60*targets;checks+=1
  seals.append({'targets':targets,'incoming_per_target_same_occurrence':incoming,'absorbed_total':absorbed,'remaining_total':remaining,'PA_cost_trigger':55,'scenario':'hypothetical TEST, if incoming is eligible damage and subjects within 4 m'})
with (OUT/'C41_SELO_DEFESA_21_NEGATIVE_CONTROLS.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(seals[0]));w.writeheader();w.writerows(seals)
met={
'workstream':'DMG TEST side/ scientific',
'mathematical_rows':len(cases)*len(RDs),
'defense_rows':len(seals),
'checks':checks,
'martelo_DME':{'base':56,'against_structure_after_paid_activation':83,'paid_extra_mean':27,'offensive_rank_from_item':'ON Média (declared overall item, not uniquely inferred from raw DME)'},
'manopla':{'additional_5d8_plus3_mean':25.5,'source':'Ouro Entrada ITEM, NOT additional attack'},
'lamina':{'7d8_plus15_mean':46.5,'source':'ON Entrada ITEM, separates defensive reaction'},
'critical_reference':'Sistema de Combate; max normal attack dice added to normal damage only when eligible (physical weapon). Conditional additions require declared before damage and legal hit; do not infer standalone spells crit.',
'NOTES':['All RD values purely hypothetical and assume appropriate defense applies to that damage type','Manopla lightning resistance may differ from physical RD; do not apply physical RD to elemental pool without authority','Selo is defensive damage prevention; cannot convert to offensive DME','No VLAB original usage or Party mutation','Criações do Comestre still Semicanônico/Incubação, NOT canonical items of Party or official shop'],
'official_baseline':'DMG-RANK-01 v1.1 unchanged',
'F0_F6':'HOLD'
}
(OUT/'C41_FINDINGS.json').write_text(json.dumps(met,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report='''# DMG C41 — Análise científica de dano intrínseco × entrega condicional × defesa (TEST Mestre-only)

**OP:** OP-DMG-CORPUS-EMP-01, mesma operação. **Baseline:** DMG-RANK-01 v1.1 sem alteração. **Escrita:** somente Biblioteca Mestre; Notion fichas/OP, Party, VLAB e Sistema NO-WRITE. Itens analisados localizados na subárvore `Criações do Comestre — Semicanônico / Incubação`, logo **não são itens oficiais automaticamente homologados**. A base de 859 Page-IDs de C40 permanece como denominador DELIMITADO; C41 não finge avançar D0.

## Fontes reabertas no Notion Mestre e fenômenos medidos

1. [Martelo do Portão Faminto](https://app.notion.com/p/3f5c2b324ede81658982d8f47b3ad647). ON Média declarada para o item, não para uma magia isolada. Golpe base `8d10+12` tem **DME 56**; poder opcional acrescenta `6d8` (média 27) só após atingir **estrutura não viva**, a 25 PA, 1/descanso de oito horas; **DME condicional 83** para o mesmo golpe. O valor 56 está na banda numérica ON Baixa 49–58, enquanto 83 chega ao intervalo ON Ápice 83–96, MAS isso **não significa que o item mudou de rank**: descrição, seleção do alvo, frequência e função estrutural governam a FIP global, que não equivale a um golpe bruto unidimensional.
2. [Manopla do Trovão Cativo](https://app.notion.com/p/3f5c2b324ede81f5ac62fb940204cdac). Ouro Entrada; descarga `+5d8+3` = **DME adicional 25,5**, consome **22 PA**, só depois do acerto, sem segunda Ação Padrão ou segundo teste. Condição de −3m ocorre somente se ao menos 1 ponto de Raio atravessar resistência/imunidade, não dá atordoamento gratuito. Não somar dano físico do golpe de origem na ficha do item como dano intrínseco duplicado; não aplicar RD física ao Raio sem prova de que tal mitigação é competente.
3. [Lâmina da Queda Contida](https://app.notion.com/p/3f5c2b324ede81e9aa8ec51f568600e8). ON Entrada, `7d8+15` = **DME 46,5**, dentro da banda Entrada 38–48. A ancoragem de deslocamento usa reação separada, não amplia o dano.
4. [Selo do Último Refúgio](https://app.notion.com/p/3f5c2b324ede81d0874ed4d96752812c). Item defensivo Lendário Entrada, Reação 55 PA, uso único; reduz **até 60** pontos do mesmo evento de dano em até **três alvos** no raio definido. Calculamos 21 cenários sintéticos de absorção e demonstramos que o total prevenido pode atingir 180 se três alvos elegíveis sofrerem 60+ no mesmo evento, mas não cria 180 pontos ofensivos e não protege três eventos independentes.

## Matemática exata, limites e invariantes
4 pools ofensivos documentados × 6 RDs hipotéticas (0, 20, 35, 50, 75, 100) = **24 linhas de distribuição exata** obtidas por convolução inteira de dados, sem amostragem Monte Carlo. Para cada linha calculei média bruta, variância, média efetiva após RD, probabilidade de o dano superar RD e suporte. O par Martelo básico/condicional verifica monotonicidade na mesma classe de alvo hipotética. A regra do crítico para ataques físicos segue acréscimo máximo dos dados da instância: martelo base +80, Martelo contra estrutura declarado antes da rolagem +128, Lâmina +56; descarga da Manopla pode integrar o ataque crítico apenas nas condições estritas da fonte, sem criar crítico separado.

**Exatamente {CHECKS} verificações programáticas locais PASS**, 24 linhas de PMF e 21 controles de defesa; CRC/manifesto SHA verificados no pacote de evidência. Estes são **testes matemáticos condicionais**, não 24 combates VLAB e não 24 novas fichas do RPG. O evento de referência para aplicar RD física à eletricidade é propositalmente OMITIDO por autoridade insuficiente. A fórmula é `E[max(0, D-RD)]` onde RD é o valor aplicável àquela camada, não necessariamente defesa global do alvo.

## Produtos, gates e próxima unidade
- **C41 PASS delimitado:** reprodução de pools, custos e restrições em quatro fontes Mestre de incubação; invariante de não duplicar dano de ataque, não multiplicar dano de um uso por alvos/eventos e não inferir RE por média somente.
- **F0 A5/A6/A7/A8:** estados herdados de C40, HOLD. **F6:** continua sem fonte original admissível para preencher dano ausente. Nenhuma F0–F18 certificação nova, nenhuma v2.
- **FIRST-PENDING C42:** investigar superfícies ofensivas novas, priorizando famílias de magias com RE/FIP realmente próprio e ação/custo; auditar A5 versão de Criação de Ficha sem retcon; preparar proposta de nova partição cega por família que exclua o holdout original contaminado por exposição histórica.
- **NO-REPEAT:** C22–C41; não usar estes quatro itens de incubação como amostra representativa de categoria ou como equipamento Party.
'''.replace('{CHECKS}',str(checks))
(OUT/'C41_PSV_CONDICIONAIS_E_RD_MESTRE_ONLY.md').write_text(report,encoding='utf-8')
# checkpoint concise
(OUT/'C41_CHECKPOINT.json').write_text(json.dumps({'operation':'OP-DMG-CORPUS-EMP-01','last_verified':'C41 PMF exact 4 sources and Selo 21 controls','first_pending':'C42 source-level RE FIP, A5 Criação de Ficha version fork, A7 protocol, A8 independent coder','global_d0':'HOLD','scoped_ids':859,'F0':'4/8 HOLD','F6':'HOLD','official':'DMG-RANK-01 v1.1 unchanged','checks':checks,'NAC_PASS':'LOCAL_MATH_PASS,GLOBAL_HOLD'},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
files=[p for p in OUT.iterdir() if p.name not in ['build_c41.py'] and p.is_file() and not p.name.startswith('DMG_C41_')]
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
(OUT/'C41_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'DMG_C41_ITEMS_CONDITIONAL_PMF_MESTRE_ONLY.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[OUT/'C41_MANIFEST.json',OUT/'build_c41.py']:z.write(p,p.name)
with zipfile.ZipFile(OUT/'DMG_C41_ITEMS_CONDITIONAL_PMF_MESTRE_ONLY.zip') as z:
 assert z.testzip() is None
 for key,v in manifest.items():assert len(z.read(key))==v['bytes'] and hashlib.sha256(z.read(key)).hexdigest()==v['sha256']
print('C41 PASS', checks,'checks',len(cases)*len(RDs),'PMF',len(seals),'defense cases')
for name,c in cases.items():
 print(name,'DME',measure(c['dice'],c['fixed'],0)['E_raw'],'RD50',measure(c['dice'],c['fixed'],50)['E_post_RD'])
