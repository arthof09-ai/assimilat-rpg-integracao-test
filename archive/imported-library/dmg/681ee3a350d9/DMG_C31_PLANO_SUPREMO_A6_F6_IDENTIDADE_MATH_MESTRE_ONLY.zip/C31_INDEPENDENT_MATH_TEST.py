"""C31 math-only controls. No Notion writes, no RPG engine.
This script verifies arithmetic for explicit Hongyue expressions and
synthetic noncanonical distribution sensitivity of a pre-existing 4d6 example.
"""
from fractions import Fraction
from collections import Counter
from itertools import product
import unittest

def linear_mean(expression):
    # Purposefully narrow grammar; no attack rolls, PA, FF or transforms.
    import re
    parts=expression.split('+')
    if not parts or not all(re.fullmatch(r'(?:[1-9]\d*d[1-9]\d*|\d+)',s) for s in parts):
        raise ValueError('UNSUPPORTED_OR_UNRESOLVED_EXPRESSION')
    out=Fraction(0)
    for part in parts:
        if 'd' in part:
            count,faces=map(int,part.split('d'))
            if faces<2:raise ValueError('INVALID_DIE')
            out += Fraction(count*(faces+1),2)
        else:out += int(part)
    return out

def enumeration(num=4, faces=6, bonus=0, rd=0):
    xs=[max(0,sum(r)+bonus-rd) for r in product(range(1,faces+1),repeat=num)]
    return {'n':len(xs),'ev':Fraction(sum(xs),len(xs)), 'positive':Fraction(sum(x>0 for x in xs),len(xs))}

def convolution(num=4,faces=6,bonus=0,rd=0):
    state=Counter({0:1})
    for _ in range(num):
        nxt=Counter()
        for total,n in state.items():
            for face in range(1,faces+1):nxt[total+face]+=n
        state=nxt
    denom=faces**num
    return {'n':sum(state.values()),'ev':Fraction(sum(max(0,s+bonus-rd)*k for s,k in state.items()),denom), 'positive':Fraction(sum(k for s,k in state.items() if s+bonus>rd),denom)}

class MathOnlyC31(unittest.TestCase):
    def test_hongyue_first_raw(self):self.assertEqual(linear_mean('44+3d6'),Fraction(109,2))
    def test_hongyue_second_raw(self):self.assertEqual(linear_mean('7d10+3d10+5d8+56'),Fraction(267,2))
    def test_hongyue_difference(self):self.assertEqual(linear_mean('7d10+3d10+5d8+56')-linear_mean('44+3d6'),79)
    def test_hongyue_no_mode_inferred(self):
        for expression in ('normal:44+3d6','4d6+INT','2d6 +2','4d6 x2','no damage','3d0'):
            with self.subTest(expression=expression):
                with self.assertRaises(ValueError):linear_mean(expression)
    def test_distinct_algorithms(self):
        for rd in (0,10,15,20,24,35):
            for bonus in (0,2,4,10):
                with self.subTest(rd=rd,bonus=bonus):
                    self.assertEqual(enumeration(bonus=bonus,rd=rd),convolution(bonus=bonus,rd=rd))
    def test_conditional_rd15(self):
        self.assertEqual(enumeration(rd=15,bonus=0)['ev'],Fraction(401,432))
        self.assertEqual(enumeration(rd=15,bonus=2)['ev'],Fraction(833,432))
        self.assertEqual(enumeration(rd=15,bonus=4)['ev'],Fraction(2173,648))
    def test_bonus_not_assumed_twice(self):
        self.assertNotEqual(enumeration(rd=15,bonus=2)['ev'],enumeration(rd=15,bonus=4)['ev'])
    def test_rd35_zero_for_this_hypothetical_pool(self):
        self.assertEqual(enumeration(rd=35,bonus=0)['ev'],0)
        self.assertEqual(enumeration(rd=35,bonus=10)['ev'],0)

if __name__=='__main__':
    unittest.main(verbosity=2)
