# DMG — C31 (local) | Parecer científico, correção de censo e continuidade

**Operação canônica existente:** `OP-DMG-CORPUS-EMP-01`. **Ambiente:** MESTRE-SIDE / pesquisa TEST. **Norma oficial:** `DMG-RANK-01 v1.1`, **inalterada**. **Ciclo:** C31 (marcação local após conferência de ausência de C31 na Biblioteca da OP e na busca Notion; não constitui atribuição de INSTANCE-ID). **Autoridade/writer Notion:** sem lease/epoch/claim de sucessor comprovados, **NO-WRITE em OP, Diário, Inbox e todas as fichas**. Party e O Primeiro: **NO-WRITE**. **F0 formal:** `4/8 HOLD` antes e depois. Nenhuma homologação ou nova versão da regra.

## 1. Produto verificado: censo D0 ampliado sem duplicação

Foram buscadas e lidas diretamente no Notion Mestre **131 novas páginas físicas**: 20 Pílulas, 7 Poções, 7 Armaduras, 13 Roupas/Acessórios, 32 Personagens com título no índice e 52 páginas de Personagens cujo marcador de página não exibia título literal. Todos os 131 Page-IDs são únicos entre si. O corpus encontra-se dividido em três CSVs: `C31_D0_47_NOVAS_FONTES_LEDGER.csv`, `C31_D0_PERSONAGENS_32_FONTES_LEDGER.csv` e `C31_D0_52_PAGINAS_SEM_TITULO.csv`. A leitura direta não equivale a congelamento byte a byte, a inspeção de mídias ou a segunda codificação cega.

Foi recuperado dos arquivos históricos o conjunto **411 G1** (256 dos lotes C22–C25, 89 C26 e 66 C27), e dos pacotes C29 a relação de 60+28 Page-IDs, além dos 49 Page-IDs do C30. **Interseção dos 131 IDs novos com G1 411, C29 60/28 e C30 49: ZERO**, com comparação computacional por Page-ID dos respectivos manifestos/datasets. A união física delimitada das quatro coortes é, portanto, **411+88+49+131 = 679 Page-IDs**. Essa soma NÃO é D0 global, nem 679 habilidades independentes. C28, cujo índice canônico foi comparado, também não apresentou interseção com os 131. Preservar todos os denominadores por árvore/coorte.

### Correção do erro de extração que afetava a C30

O índice `Personagens` continha historicamente 233 Page-IDs. A C30 observou somente 181 por usar uma extração que exigia texto de título imediatamente depois de `<page url=...>`. Reexecutei o censo dos **oito índices F0 históricos** contando o marcador `<page>` por ID, sem exigir título. Resultado: **332 links diretos / 332 Page-IDs distintos**, distribuídos em Bestas 14, Personagens 233, Itens 17, Armas 19, Magias 26, Artefatos 15, Matrizes 8 e Inscrições (espelho) 0 links diretos. O índice de Inscrições é diferente: contém menções e não páginas-filhas diretas no texto recuperado; não deve ser somado como contagem de páginas oficial/Party.

A diferença **233–181=52** era falso déficit de parser: 52 blocos `<page>` tinham elemento vazio, por exemplo `<page url="..."></page>`, logo foram perdidos pelo regex de título. Essas **52 páginas foram TODAS abertas individualmente** pelo Page-ID. Todas retornaram título físico **`New page`**, com link de imagem externa ou parágrafo vazio; em nenhum corpo textual acessível foi encontrado pool de dano, RE ou FIP. **Não foram visualizadas as imagens externas; não afirmar ausência de mecânica binária.** O erro histórico é corrigido ADITIVAMENTE neste relatório; os arquivos originais C30 não foram sobrescritos.

A cobertura adicional de 131 páginas e a correção do parser não encerram os outros ramos, descendentes recursivos, arquivos nem D0 global. O conjunto `332` é um mapa direto de **oito índices heterogêneos**, não a população total de definições do RPG.

## 2. Produto F6: controles negativos genuínos, sem falso fallback

Além da triagem C30 de 12 inscrições, esta C31 selecionou **12 controles negativos/limítrofes novos** entre os itens Mestre lidos (`C31_F6_NEGATIVE_CONTROLS_12.csv`). Os controles distinguem cura/suporte (Pílula das Nove Transformações; Pílula de Recuperação), controle (Poção de Paralisia), buff (Poção Troca Atributos), redução de cultivo sem dano literal (Essência do Abismo), defesa (Armadura Guardiã Elemental; Manto de Abismo), bônus externo de dano (Constelação Guardiã; Sombra Sussurrante), movimento (Bota Caminho Veloz), reação defensiva (Traje Águia Celeste) e precisão sem dano intrínseco (Veste Dragão Ascendente).

Nenhum desses 12 controles satisfaz o contrato de **efeito ofensivo real sem dano explícito, porém com RE/FIP individual, entrega, ação/custo e autoridade competentes**. Assim, resultado **0/12 ELEGÍVEIS nesse subconjunto deliberadamente negativo**, que não deve ser usado como estimativa populacional de prevalência. Não somar RI da armadura ou medalha da pílula ao RE de uma habilidade. As 52 páginas `New page` sem texto ofensivo também não autorizam criar dano fictício.

**Dois pontos relevantes de não dupla contagem:** a armadura `SOMBRA SUSSURRANTE` menciona `+2 Dano` nos bônus gerais e novamente na habilidade passiva; isso pode corresponder à mesma origem. É proibido transformá-lo em `+4` cumulativo sem autoridade específica. `Constelação Guardiã` fornece `+10 de dano`, bônus **externo** do item, não DME intrínseco de uma técnica nem RE comprovado. A armadura `Guardiã Elemental` descreve `RD 35 a ataques de elemental`, `+6 CA contra Elementais` e `55 PA/dia`; não é prova de efeito ofensivo próprio.

## 3. Produto de identidade: Ronki e Hongyue

**Ronki O1:** três Page-IDs distintos compartilham o sujeito textual `Ronki, O1`. O texto renderizado apresenta similaridade elevada medida por multiconjunto de sequências de cinco palavras: **0,96334** (pares 0–1), **0,94272** (0–2) e **0,97957** (1–2). As páginas NÃO são idênticas. Duas contêm `Alma: 770+50+50-14-35-13-12-18-45-40-20-45-10-16-15=587`; a terceira, `770+50+50-14-19-13-12-18-45-40-20-45-10-16=618`. Ambas as expressões são aritmeticamente corretas. **Não assumir três combatentes independentes nem consolidar apagando variantes históricas.** Adjudicação de identidade e autoridade pendente. Fonte IDs e método no arquivo `C31_ALIAS_LINEAGE_3_RONKI_2_HONGYUE.json`.

**Sikong Hongyue:** duas páginas homônimas; uma contém ficha extensa de Ouro 5 e registra, numa única seção H–Ataque, `44+3d6` e `7d10+3d10+5d8+56`. Médias matemáticas brutas, condicionais a cada expressão separada: **54,5** e **133,5**; diferença **79**. A fonte não fornece, nessa linha, regra competente para escolher, somar ou nomear modos. A outra página homônima é um stub de 189 caracteres de texto renderizado. **Ambiguidade HOLD, sem alterar fonte.** Também há o personagem Lendário 3 `Sikong Auren`, com ficha extensa, mas sem RE/FIP literal individual identificado na triagem — não equiparar rank de ator ao efeito.

## 4. Produto de matemática independente (TEST, sem motor VLAB)

`C31_INDEPENDENT_MATH_TEST.py` executou **8 métodos de teste PASS** após uma correção local de regex de suporte ao dado `d10` (falha inicial reprodutível e corrigida antes da entrega). Um experimento sintético com pool `4d6` (matriz de 1.296 resultados possíveis) foi conferido por **duas rotas diferentes**: enumeração completa de faces e convolução de frequências. Foram conferidas **24 combinações de RD hipotética (0/10/15/20/24/35) e bônus externo hipotético (0/2/4/10)**, todas concordantes bit a bit quanto às frações racionais de dano líquido e `P(dano>0)`. Por exemplo, RD15: bônus 0 → E=401/432≈0,92824; bônus +2 → E=833/432≈1,92824; bônus +4 → E=2173/648≈3,35340.

**LIMITAÇÃO INEGOCIÁVEL:** o `4d6` e os bônus externos pertencem a fontes físicas diferentes, **não foi provado que um personagem poderia equipar ou combinar os efeitos**. Esses 24 cenários são matemática condicional de não dupla contagem, não fixture de combate REAL nem certificação da v1.1. Sem chance de acerto, saves, crítico, imunidades ou turnos. `C31_MATHONLY_SENSITIVITY_24_CASES.json` contém resultados e frações exatas.

## 5. Gates, continuidade e fronteiras

| Frente | Antes da C31 | Depois comprovado | Estado formal |
|---|---|---|---|
| F0-A5 | 0/7 bytes de anexos históricos autenticados | não tentou rota repetida; 0/7 | HOLD |
| F0-A6 / D0 | 548 IDs da união de coortes conhecidas; parser omitia 52 sem títulos | 131 páginas novas diretas; união documental delimitada 679; oito índices reconciliados 332/332 | PARCIAL, D0 global HOLD |
| F6 | C30 0/12 fontes admissíveis | 12 controles negativos novos documentados; 0/12 aplicáveis por desenho | HOLD, nenhum fallback real certificado |
| F0-A7 | 8 reservas sem blindagem certificada | não abertas, não treinadas; estado anterior preservado | HOLD |
| F0-A8 | sem segundo humano comprovado | nenhum segundo humano/ACK simulado | HOLD |
| PR #17 | draft com CI PASS e consumo local de 3 exemplos | rechecado: aberta, draft, não mesclada, 2 arquivos, head `15f827c0`, workflow 39701452295 SUCCESS | PASS CI restrito, integração universal HOLD |
| VLAB | três triagens matemáticas C30, 0 lutas novas | math-only adicional, 0 combates, nenhuma escrita em VLAB | PENDENTE por executor competente |
| DMG-RANK-01 | v1.1 | v1.1 | OFICIAL, INALTERADA |

**Não afirmar PASS científico F0, NAC-PASS terminal ou evolução para v2.** Integridade do ZIP e das tabelas pode passar após hash/readback; conteúdo canônico, second-coder, holdout e escritura permanecem exigências separadas.

**FIRST-PENDING prioritário:** A6 prosseguir em fontes Mestre ofensivas com fontes RE/FIP completas, escolhendo classes fora do corpus imagem-preço e fichas sem dados; cruzar os 120 demais Page-IDs do índice de Personagens não lidos em C30/C31 (quando puder reconstruir fila pela versão do índice) sem afirmar que são inéditos a C22–C29. Antes de usar valores, adjudicar Ronki/Hongyue e impedir contagem tripla. Em F6, preparar caso genuinamente admissível com efeito sem dano, sem fabricar RE do usuário. F0-A5 não deve bloquear trabalho novo; manter 0/7 até download privado e re-hash. A7 aguarda novo holdout sem vazamento e A8 leitor independente real.

**Princípios operacionais preservados:** RESULT-FIRST; múltiplas frentes; NO-REPEAT C22–C30; não duplicar O Primeiro/Party, Notion OP/Diário ou laboratórios alheios; evidência física por Page-ID; decisões expressas do Mestre prevalecem; nenhuma escrita de produção; checkpoint exato, sem falso lease/epoch/ACK.
