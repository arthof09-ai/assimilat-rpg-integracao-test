from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import csv,hashlib,json,zipfile
root=Path(__file__).parent
cases=[
{'key':'COL_GEL_V2_CALLOUT','page_id':'99fc2b324ede82a89d9d01ca9846aeb9','dice':(3,6),'PA':12,'case':'CALL-OUT 3d6/turno; 12 PA','role':'testado sem decidir fonte'},
{'key':'COL_GEL_V2_BODY','page_id':'99fc2b324ede82a89d9d01ca9846aeb9','dice':(2,6),'PA':11,'case':'DESCRICAO 2d6/turno; 11 PA','role':'testado sem decidir fonte'},
{'key':'COL_GEL_V3','page_id':'bd4c2b324ede826ba2ad01d4d33903c7','dice':(6,6),'PA':11,'case':'6d6/turno; 11 PA, nas duas camadas','role':'testado sem decidir fonte'}]
probs=[Fraction(i,4) for i in range(5)]
Ts=list(range(7))
checks=0
p=root/'C43_COLUNA_GEL_DOT_315_CONDICIONAIS.csv'
with p.open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['formula','page_id','falta_salvaguarda_p_hipotetica','sem_resistencia_q_hipotetica','ticks_hipoteticos','DME_por_tick_se_aplicar','E_total_condicional','PA_atestados_pelo_trecho','incerteza'])
 for qcase in cases:
  n,faces=qcase['dice'];dm=Fraction(n*(faces+1),2)
  for fail in probs:
   for no_res in [Fraction(0),Fraction(1,2),Fraction(1)]:
    for T in Ts:
     E=fail*no_res*T*dm
     assert E>=0;checks+=1
     if T>0:assert E>=fail*no_res*(T-1)*dm;checks+=1
     w.writerow([qcase['key'],qcase['page_id'],str(fail),str(no_res),T,str(dm),str(E),qcase['PA'],'T,CD,fail prob,resistance unknown; no trigger-to-attack rate'])
assert sum(1 for _ in open(p,encoding='utf-8'))-1==315
# 105 triplets verify linear delta 3.5 p q T, exactly 1/2 factor V3 vs? 21 vs 10.5
for f in probs:
 for q in [Fraction(0),Fraction(1,2),Fraction(1)]:
  for T in Ts:
   assert f*q*T*(Fraction(21,2)-Fraction(7))==Fraction(7,2)*f*q*T;checks+=1
   assert f*q*T*Fraction(21)==2*f*q*T*Fraction(21,2);checks+=1
# Frio V3 expected conditional on hit, no FD/FF etc.
frio=[]
for pcon in probs:
 trig=Fraction(1,5);freeze_extra=Fraction(7)
 a=Fraction(4*9,2)+8;b=Fraction(2*9,2)+2
 rider=trig*pcon*freeze_extra
 frio.append({'P_con_save_fails_hypothetical':str(pcon),'base_V3_callout':str(a),'base_V3_description':str(b),'P_freeze_proc_20_percent':str(trig),'rider_E_conditional_2d6':str(rider),'total_header_given_hit':str(a+rider),'total_body_given_hit':str(b+rider),'difference_in_all_conditions':str((a+rider)-(b+rider))})
 assert (a+rider)-(b+rider)==15;checks+=1
with (root/'C43_FRIO_V3_SENSIBILIDADE_5.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(frio[0]));w.writeheader();w.writerows(frio)
# 3 masters provenance references under same page, 0 edits. Separate proposals: no auto-choice
jud=[
{'case':'DEFESA_DE_VENTO_V3','page_id':'3e9c2b324ede836593b20129a64f36e5','callout':'+9 CA, 9 PA','body':'+12 CA, Reação; 1 turno','adjudication_required':'valor da CA (+9 vs +12) e se PA do callout aplica a Reação','impact_if_unresolved':'3 CA; hit chance impact target-dependent; no invented crit/hit'},
{'case':'FRIO_ETERNO_V3','page_id':'49fc2b324ede82f7972401f6f4bb33ed','callout':'4d8+8 adicional; 20 PA espada/30 PA besta','body':'2d8+2 adicional, com 20% congelar e 2d6 sob falha CON','adjudication_required':'formula de dano adicional da V3; manter/ajustar rider e timing','impact_if_unresolved':'15 DME bruto dado acerto; proc até 1.4 se fail CON=100%'},
{'case':'COLUNA_DE_GELO_V2','page_id':'99fc2b324ede82a89d9d01ca9846aeb9','callout':'3d6/tick; 12 PA','body':'2d6/tick; 11 PA','adjudication_required':'dado por tick e custo efetivo; duração, salvaguarda e resistência','impact_if_unresolved':'3.5 DME por tick elegível e 1 PA; total depende de T'}]
with (root/'C43_DECISION_QUEUE_MESTRE_ONLY.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(jud[0]));w.writeheader();w.writerows(jud)
(root/'C43_CHECKPOINT.json').write_text(json.dumps({'operation':'OP-DMG-CORPUS-EMP-01','checkpoint':'C43', 'subject':'3 conflicts C42 quantified using conditional mathematics, no adjudication','C42_scope_distinct_pages':870,'new_pages_C43':0,'F0':'4/8 HOLD','F6':'HOLD','A5':'0/7 historic attachments post-upload bytes','A7':'HOLD','A8':'HOLD','checks':checks,'table_rows':315+5+3,'first_pending':'C44 QA persistent package reconciliation and new positive F6 case search; A5/A7/A8 require evidence'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# DMG C43 — Incerteza das versões Chen Yi-Min (Mestre-only / MATEMÁTICA TEST)

**OP existente:** OP-DMG-CORPUS-EMP-01. **Fonte:** espelho Mestre, read-only. Nenhuma alteração à Party, regra oficial DMG-RANK v1.1, VLAB, ficha ou sistema. **Não se escolheu nenhuma fórmula histórica.**

## Resultados de experimentos condicionais (sem inventar probabilidades canônicas)

**Coluna de Gelo V²**, [fonte](https://app.notion.com/p/99fc2b324ede82a89d9d01ca9846aeb9), tem `3d6 por turno / 12 PA` no callout (média por tick 10,5), mas `2d6 por turno / 11 PA` no corpo (média 7). **V³**, [fonte](https://app.notion.com/p/bd4c2b324ede826ba2ad01d4d33903c7), tem `6d6/tick / 11 PA` (média 21) coerente nas duas camadas. Para probabilidades **hipotéticas** `p=probabilidade falhar salvaguarda` e `q=probabilidade da mitigação por resistência NÃO bloquear dano`, e `T=quantidade de ticks após o efeito`, sob hipótese de mesmo evento sem ataques adicionais:

- `E_V2-callout=10,5 × p × q × T`
- `E_V2-body=7 × p × q × T`
- `E_V3=21 × p × q × T`.

A diferença entre as leituras de V² é `3,5 × p × q × T`. Não há `T`, `p`, `q` ou CD certificados; fórmula é condicional apenas e não TTK canônico. Rodei **315 combinações** (=3 fórmulas ×5 p ×3 q ×7 T) com aritmética racional, verificando monotonicidade e relação entre versões. A maior DME/tick não obriga mudança normativa: controle, alcance, duração e ação podem mudar orçamento sem prova comparável.

**Ataque Frio Eterno V³**, [fonte](https://app.notion.com/p/49fc2b324ede82f7972401f6f4bb33ed), tem `4d8+8` no callout (**26**) versus `2d8+2` no texto (**11**) — delta de **15 DME** incondicional à chance de congelar; ambas as leituras dão uma chance textual de 20% de congelar e condicional adicional `2d6` se falhar CON. Se `p_con` fosse probabilidade de falha da CON e chance literal 20% sobre acerto, rider esperável seria `0,20 × p_con × 7 = 1,4 × p_con` dano extra por tentativa de congelamento válida. Assim o delta entre as duas leituras continua 15 antes de acerto/RD. Se a chance de congelar não for independente da salvaguarda, é preciso contrato adicional. **5 combinações matemáticas**, nenhum resultado usado para mexer na ficha.

**Defesa de Vento V³**, [fonte](https://app.notion.com/p/3e9c2b324ede836593b20129a64f36e5), declara +9 CA no callout com custo 9 PA, porém a reação na descrição concede +12 CA. São **3 CA** de incerteza; não calculamos porcentagem de acerto sem teste do atacante e regras de empate, pois no RPG a distribuição por rank/atributo muda o impacto.

## Encaminhamento de decisão
Fila de **3 casos** descritos no `C43_DECISION_QUEUE_MESTRE_ONLY.csv`: duas alternativas literais e seu impacto, sem transformar hipótese em decisão do Mestre. **Nenhuma solicitação de interrupção ao Mestre foi disparada**; a decisão é necessária apenas antes de usar essas magias em benchmark/combate e é competência de ficha/Party. O DMG não edita a original Party nem força o espelho.

**{checks} asserções locais PASS** no conjunto de cenários; **NAC-PASS apenas para as fórmulas de sensibilidade**, não F0, F6, v2 nem validação de acerto. **D0 recortado permanece 870** Page-IDs. F0 4/8 documental HOLD; A5 bytes 0/7, A7 e A8 HOLD.

**FIRST-PENDING C44:** consolidar C40–C43 fisicamente, cruzar hashes e proibições; procurar caso F6 externo à Party com RE/FIP e dano omitido se existir, sem repetir amostras; revalidar Criação de Ficha pós-edição.
'''
(root/'C43_PSV_SENSIBILIDADE_MAGIAS_MESTRE_ONLY.md').write_text(report,encoding='utf-8')
files=[x for x in root.iterdir() if x.is_file() and x.name!='build_c43.py']
man={x.name:{'sha256':hashlib.sha256(x.read_bytes()).hexdigest(),'bytes':x.stat().st_size} for x in files}
(root/'C43_MANIFEST.json').write_text(json.dumps(man,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
zp=root/'DMG_C43_SENSIBILIDADE_CONFLITOS_DOT_MESTRE_ONLY.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for x in files+[root/'C43_MANIFEST.json',root/'build_c43.py']:z.write(x,x.name)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 for name,meta in man.items(): assert hashlib.sha256(z.read(name)).hexdigest()==meta['sha256']
print('C43 PASS',checks,'internal checks, 315 DoT +5 cold +3 decisions; zip bytes',zp.stat().st_size)
