# DMG C43 — Incerteza das versões Chen Yi-Min (Mestre-only / MATEMÁTICA TEST)

**OP existente:** OP-DMG-CORPUS-EMP-01. **Fonte:** espelho Mestre, read-only. Nenhuma alteração à Party, regra oficial DMG-RANK v1.1, VLAB, ficha ou sistema. **Não se escolheu nenhuma fórmula histórica.**

## Resultados de experimentos condicionais (sem inventar probabilidades canônicas)

**Coluna de Gelo V²**, [fonte](https://app.notion.com/p/99fc2b324ede82a89d9d01ca9846aeb9), tem `3d6 por turno / 12 PA` no callout (média por tick 10,5), mas `2d6 por turno / 11 PA` no corpo (média 7). **V³**, [fonte](https://app.notion.com/p/bd4c2b324ede826ba2ad01d4d33903c7), tem `6d6/tick / 11 PA` (média 21) coerente nas duas camadas. Para probabilidades **hipotéticas** `p=probabilidade falhar salvaguarda` e `q=probabilidade da mitigação por resistência NÃO bloquear dano`, e `T=quantidade de ticks após o efeito`, sob hipótese de mesmo evento sem ataques adicionais:

- `E_V2-callout=10,5 × p × q × T`
- `E_V2-body=7 × p × q × T`
- `E_V3=21 × p × q × T`.

A diferença entre as leituras de V² é `3,5 × p × q × T`. Não há `T`, `p`, `q` ou CD certificados; fórmula é condicional apenas e não TTK canônico. Rodei **315 combinações** (=3 fórmulas ×5 p ×3 q ×7 T) com aritmética racional, verificando monotonicidade e relação entre versões. A maior DME/tick não obriga mudança normativa: controle, alcance, duração e ação podem mudar orçamento sem prova comparável.

**Ataque Frio Eterno V³**, [fonte](https://app.notion.com/p/49fc2b324ede82f7972401f6f4bb33ed), tem `4d8+8` no callout (**26**) versus `2d8+2` no texto (**11**) — delta de **15 DME** incondicional à chance de congelar; ambas as leituras dão uma chance textual de 20% de congelar e condicional adicional `2d6` se falhar CON. Se `p_con` fosse probabilidade de falha da CON e chance literal 20% sobre acerto, rider esperável seria `0,20 × p_con × 7 = 1,4 × p_con` dano extra por tentativa de congelamento válida. Assim o delta entre as duas leituras continua 15 antes de acerto/RD. Se a chance de congelar não for independente da salvaguarda, é preciso contrato adicional. **5 combinações matemáticas**, nenhum resultado usado para mexer na ficha.

**Defesa de Vento V³**, [fonte](https://app.notion.com/p/3e9c2b324ede836593b20129a64f36e5), declara +9 CA no callout com custo 9 PA, porém a reação na descrição concede +12 CA. São **3 CA** de incerteza; não calculamos porcentagem de acerto sem teste do atacante e regras de empate, pois no RPG a distribuição por rank/atributo muda o impacto.

## Encaminhamento de decisão
Fila de **3 casos** descritos no `C43_DECISION_QUEUE_MESTRE_ONLY.csv`: duas alternativas literais e seu impacto, sem transformar hipótese em decisão do Mestre. **Nenhuma solicitação de interrupção ao Mestre foi disparada**; a decisão é necessária apenas antes de usar essas magias em benchmark/combate e é competência de ficha/Party. O DMG não edita a original Party nem força o espelho.

**800 asserções locais PASS** no conjunto de cenários; **NAC-PASS apenas para as fórmulas de sensibilidade**, não F0, F6, v2 nem validação de acerto. **D0 recortado permanece 870** Page-IDs. F0 4/8 documental HOLD; A5 bytes 0/7, A7 e A8 HOLD.

**FIRST-PENDING C44:** consolidar C40–C43 fisicamente, cruzar hashes e proibições; procurar caso F6 externo à Party com RE/FIP e dano omitido se existir, sem repetir amostras; revalidar Criação de Ficha pós-edição.
