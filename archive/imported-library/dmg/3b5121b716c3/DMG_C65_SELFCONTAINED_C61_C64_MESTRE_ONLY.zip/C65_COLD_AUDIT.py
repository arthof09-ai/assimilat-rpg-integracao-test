#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,csv,io
root=Path(__file__).resolve().parent
sources={
 'C61':'DMG_C61_HOLDOUT_GROUP_PRESEAL_MESTRE_ONLY.zip',
 'C62':'DMG_C62_CRIT_RISK_25_BANDS_MESTRE_ONLY.zip',
 'C63':'DMG_C63_CRIT_RATE_DESIGN_IID_MESTRE_ONLY.zip',
 'C64':'DMG_C64_A7_UNREAD_BEAST_FRONTIER_MESTRE_ONLY.zip',
}
check={};checks=0
for campaign,name in sources.items():
    p=root/name
    with ZipFile(p) as z:
        assert z.testzip() is None;checks+=1
        namelist=z.namelist()
        manifestname=campaign+'_MANIFEST.json'
        assert manifestname in namelist;checks+=1
        manifest=json.loads(z.read(manifestname))
        for entry,value in manifest.items():
            assert entry in namelist and hashlib.sha256(z.read(entry)).hexdigest()==value['sha256'];checks+=1
        check[campaign]={'source_zip_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'entries':len(namelist),'internal_manifest_hashes_pass':len(manifest)}
        if campaign=='C62':
            rows=list(csv.DictReader(io.StringIO(z.read('C62_1000_EXACT_CRIT_RD_SCENARIOS.csv').decode())))
            js=json.loads(z.read('C62_CHECKPOINT.json'))
            assert len(rows)==1000 and js['assertions']==1675;checks+=2
        if campaign=='C63':
            js=json.loads(z.read('C63_CHECKPOINT.json'))
            assert js['tests']==347 and js['distinct_seeds']==15 and js['seeds_with_attack_events']==13 and js['observed_nested_attacks']==38;checks+=1
            assert js['power_min_independent_trials_margin0_vs_margin4']['n']==326;checks+=1
        if campaign=='C64':
            js=json.loads(z.read('C64_CHECKPOINT.json'))
            ids=set(z.read('C64_UNIAO_921_IDS_MIXED_PROVENANCE.txt').decode().split())
            cand=list(csv.DictReader(io.StringIO(z.read('C64_17_NOVAS_REFERENCIAS_METADATA_ONLY.csv').decode())))
            assert len(ids)==921 and len(cand)==17 and all(x['body_consulted_in_C64']=='NO' for x in cand);checks+=1
            assert all(x['prospective_holdout_sealed']=='NO' for x in cand) and js['new_holdout_sealed_count']==0;checks+=1
        if campaign=='C61':
            js=json.loads(z.read('C61_FAST_RESUME_CHECKPOINT.json'))
            assert 'A7' in js['checkpoint'] and js['A7_formal'].startswith('HOLD');checks+=1
assert len(check)==4
cp={
 'operation':'OP-DMG-CORPUS-EMP-01','campaign':'C65','date':'2026-10-22',
 'baseline':'DMG-RANK-01 v1.1 unchanged','before':'LAST-VERIFIED C61','after':'LAST-VERIFIED C65',
 'evidence_A6':{'C61_known_unique':904,'C64_metadata_new':17,'C64_total_mixed_known':921,'global_D0_complete':False,'new_body_consulted':0},
 'scientific_C62':{'exact_contexts':1000,'local_checks':1675,'source':'synthetic 25 bands from C52'},
 'scientific_C63':{'nested_attacks':38,'seeds':15,'seeds_with_attack_records':13,'crit_positive':1,'statistical_design':'IID hypothetical, no validity assertion for VLAB','local_checks':347},
 'scientific_C64':{'meta_only_children':17,'holdout_sealed':0,'alias_safety':'no text consulted, no second human approval'},
 'auditor':{'packages':4,'cross_manifest_checks_total':checks,'sources':check},
 'F0':'4/8 DOCUMENTAL HOLD','A5':'0/7 verified historical bytes','A6':'921 mixed refs, global D0 open','A7':'0 blind real','A8':'human second coder/assignment/writer HOLD','F6':'0 verified eligible real missing-damage effect',
 'SIM_DMG_LEDGER':'0/1875 validated full-fight cells','VLAB':'NO-WRITE','PARTY':'NO-WRITE','O_PRIMEIRO':'NO-WRITE',
 'no_repeat':'C22-C65; 86 direct known children; 12 Chen alias groups; 8 contaminated original holdout; 17 new meta-only beast children',
 'next_five':['A5 authenticate byte-level historical 7 annexes with allowed secure transfer; no signed links to public search','F6 source only if genuine missing base damage and complete RE/FIP/action/PA/target delivery','A7 independent evaluator preseal family version before any source body on 17 metadata-only pointers','A8 second human coder and approved writer/epoch/lease before Notion logging/promotion','F7-F18 wait for genuine preflight, new candidate v2, real paired fixtures and NAC-PASS'],
 'last_verified_unit':'C65 4 ZIP archives manifests and checkpoints reverified','first_pending':'A5/F6/A7/A8 external gates; no protected source body opened',
 'collision_scope':'Library Mestre scientific package only, no parallel engine or Notion page'
}
(root/'C65_FAST_RESUME_CHECKPOINT.json').write_text(json.dumps(cp,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(root/'C65_PSV_FINAL_MESTRE_ONLY.md').write_text(f'''PSV — DMG C65 | Encerramento científico MESTRE-ONLY / TEST

**OP existente:** [OP-DMG-CORPUS-EMP-01](https://app.notion.com/p/3f3c2b324ede813e9fa0c87ebdea0b29). **Base oficial:** DMG-RANK-01 v1.1 intocada. **Escopo:** auditoria independente, sem writer Notion, sem alteração de ficha/Party/O Primeiro/VLAB, e sem homologação nova.

## Avanço C62–C65
- **C62:** 1.000 PMFs sintéticas exatas em 25 faixas oficiais, 1.675 verificações; mesmos DMEs podem divergir fortemente após RD/crítico. Modelo sempre-acertando; não é probabilidade real de vitória ou dano por tentativa.
- **C63:** 38 ataques R214 TEST aparecem em **13 das 15 seeds**, com 1 crítico positivo. Modelo de dimensionamento separa matemática IID de efetiva correlação de ataques/seed; 326 verificações IID seriam necessárias no teste hipotético especificado para distinguir margem +0 vs +4 com 80% poder, não 326 combates VLAB. 347 verificações locais.
- **C64:** 17 novos IDs não presentes no conjunto anterior de 904 foram descobertos **APENAS POR LINKS NAS PÁGINAS-PAI** de Bestas, total misto de **921 Page-IDs conhecidos**, dos quais **os 17 NOVOS não tiveram corpo lido nem gate A7**. São 12 índices elementais, 1 índice de pendências, 1 arquivo histórico, 3 referências a Bestas regionais; não contam como 17 Bestas elegíveis, nem D0 global.
- **C65:** 4 ZIPs reabertos, CRC e **{checks} validações cruzadas** de manifestos/estado. Checkpoint serializado com denominador e NEXT-5. Proibido declarar PASS normativo por CHECK LOCAL.

## Gates reais e governança
**F0 4/8 documental HOLD; A5 0/7 snapshots privados autenticados por leitura de bytes; F6 0 fontes admissíveis verificadas; A7 0 holdouts cegos certificados; A8 segunda codificação independente/writer/lease HOLD; SIM-DMG 0/1.875 casos full-fight homologados.** A busca por anexo via connector `notion_download_attachment` retornou resposta sem conteúdo para FileUpload antigo, logo não constituiu leitura. Os 7 links assinados resolvidos nunca bastaram como autenticação pós-upload.

**Gates NAC:** NAC-CONT-03 v2 e NAC-NORM-01 aplicáveis; NAC-PASS-02 aqui limitado à INTEGRIDADE E REPRODUÇÃO dos artefatos científicos, não publicação normativa. Nova ordem Mestre permite pesquisa, mas writer/epoch/lease não foram comprovados. **Sem escrita Notion, sem novas regras, sem duplicatas**.

## NEXT-5 protegido
1. Resolver A5 com transferência privada de bytes e hash histórico; jamais usar links assinados em buscador público.
2. F6: procurar habilidade ofensiva real com dano-base AUSENTE, RE e FIP próprios, ação/custo/alvo/entrega presentes e sem alias; rejeitar materiais, habilidades em imagem não lida, efeitos defensivos e fontes PS sem homologação.
3. A7: segundo avaliador pré-registra seleção por família/versão em árvore inédita ANTES de alguém ler corpo. NÃO reutilizar as 8 reservas originais contaminadas nem promover os 17 links de C64 automaticamente.
4. A8: revisão humana independente e writer/epoch/lease; nenhum lançamento de log no Notion/OP/Diário enquanto a autorização não estiver demonstrada.
5. Só após gates: fixtures BEFORE/AFTER reais indexadas e SIM-DMG, sem atribuir crédito por cálculos sintéticos.

**Ponto exato:** `LAST-VERIFIED C65 → FIRST-PENDING A5/F6/A7/A8`; abrir `C65_FAST_RESUME_CHECKPOINT.json`, não repetir C22–C65, não atribuir 921 como censo global.
''',encoding='utf8')
files=[root/'C65_FAST_RESUME_CHECKPOINT.json',root/'C65_PSV_FINAL_MESTRE_ONLY.md',root/'C65_COLD_AUDIT.py']
manifest={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
(root/'C65_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with ZipFile(root/'DMG_C65_SELFCONTAINED_C61_C64_MESTRE_ONLY.zip','w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[root/'C65_MANIFEST.json']+ [root/n for n in sources.values()]:z.write(p,p.name)
with ZipFile(root/'DMG_C65_SELFCONTAINED_C61_C64_MESTRE_ONLY.zip') as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in manifest.items())
print('C65 verified',checks,'cross-checks, SHA',hashlib.sha256((root/'DMG_C65_SELFCONTAINED_C61_C64_MESTRE_ONLY.zip').read_bytes()).hexdigest())
