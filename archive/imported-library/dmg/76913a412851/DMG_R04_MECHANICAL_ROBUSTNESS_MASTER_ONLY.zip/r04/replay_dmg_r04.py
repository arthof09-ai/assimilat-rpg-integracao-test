#!/usr/bin/env python3
"""R04 reproducible mathematical analyses; read-only; no RPG canon writes."""
import json, csv, hashlib, itertools, math, collections, statistics, pathlib
from fractions import Fraction
from datetime import datetime,timezone
ROOT=pathlib.Path(__file__).parent
PARENT=ROOT.parent
R03=PARENT/'r03'

def load(p): return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def put(name,obj): (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def pmf(dice=(),addon=0):
    a=collections.Counter({int(addon):1});
    for n,k in dice:
        for _ in range(n):
            a=conv(a,k)
    return dict(sorted(a.items()))
def conv(a,k):
    b=collections.Counter()
    for val,count in a.items():
        for i in range(1,k+1):b[val+i]+=count
    return b
def expectation(a):return Fraction(sum(v*n for v,n in a.items()),sum(a.values()))
def RD(a,rd):return {k:max(0,k-rd) for k in a}
def damp(a,rd):return Fraction(sum(max(0,v-rd)*n for v,n in a.items()),sum(a.values()))
def penetration(a,rd):return Fraction(sum(n for v,n in a.items() if v>rd),sum(a.values()))
def outcome(a,rd):
    d=collections.Counter()
    for v,n in a.items():d[max(0,v-rd)]+=n
    return {'rd':rd,'p_positive':str(penetration(a,rd)),'E_net_fraction':str(damp(a,rd)),'E_net':float(damp(a,rd)),'pmf_after_rd_counts':{str(k):v for k,v in sorted(d.items())},'total_microstates':sum(d.values())}
def abil(page,name,formula,dice,attrib,attr_code=None,role='INITIAL',type_doc=None,conditions='',cost=None,rank=None,section=None,side='MASTER',identity_conflict=False):
    add=attrib if attrib is not None else 0
    d=pmf(dice,add)
    return {'page_id':page,'name':name,'literal_formula':formula,'dice':[list(z) for z in dice],'attr_code':attr_code,'attribute_value':attrib,'kind':role,'damage_type_documented':type_doc,'conditions':conditions,'cost_documented':cost,'gross_mean_fraction':str(expectation(d)),'gross_mean':float(expectation(d)),'intrinsic_mean':float(expectation(pmf(dice))), 'dice_count':sum(x[0] for x in dice), 'fraction_attribute':float(Fraction(add,1)/expectation(d)) if attrib is not None and expectation(d)>0 else 0,'pmf_gross_counts':{str(k):v for k,v in d.items()},'microstates':sum(d.values()),'rd_scenarios':{str(rd):outcome(d,rd) for rd in [5,15,25,30,31,35,40,45,60]},'rank_title':rank,'group':section,'scope':side,'identity_conflict':identity_conflict,'url':f'https://app.notion.com/p/{page}'}

# The selection IDs were frozen before any of these pages were fetched; source content transcribed from current Notion readbacks. 
D=[
('56ac2b324ede8352868101e11ea16355','Sussurro Celestial','Sussurro Celestial','Prata 1','Prata 1','Ouro 5',30,'INT','Lâmina de Brisa','1d6 + INT',((1,6),),'vento (lâmina)',None,'-25% movimento separate skill','MASTER'),
('5e4c2b324ede8282ad2c01c9363c3098','Golem de Pedra','Símio Demoníaco 🪨','Prata 1','Prata 1','Ouro 2',26,'FOR','Esmagamento Terrano','2d6 + força',((2,6),),'esmagamento físico textual',None,'5 RD own Pele Rochosa; hierarchy unresolved','MASTER'),
('5fcc2b324ede8339a5bd01cd65ea103e','Demônios Vermelhos','Demônio Vermelho','Prata 1','Prata 1','Prata 1',None,None,None,None,None,None,None,'Força Demoniaca +3 dano unspecified target action; 5 RM','MASTER'),
('725c2b324ede8301baed01d62bd2b8e0','Tigris Sombrio','Tigre Dente de Sabre','Prata 1','Prata 1','Prata 1',24,'FOR','Presas Fantasmais','2d6+força',((2,6),),'mordida/presas físico, medo secundário',None,'chance de paralisia por medo não quantificada','MASTER'),
('778c2b324ede83d0a89281a4c12ba768','Raios de Tempestade','Símio Demoníaco ⚡','Prata 1','Prata 1','Ouro 2',23,'FOR','Ataque de Garras Eletrizadas','2d6+For',((2,6),),'garras + eletricidade não parceladas',None,'paralisia após 3 ataques; Aura Energia +2 ataque não verificada','MASTER'),
('77ec2b324ede82d49662812c1e72b7b0','Polvo da Floresta Encantada','Polvo da Floresta','Prata 1','Prata 1','Ouro 1',29,'INT','Corte cerebral','2d6+int',((2,6),),'corte cerebral tipo não classificado',None,'','MASTER'),
('3b0c2b324ede83cc931801874fb504b5','Soberano da Luz da Lua','Zephyrax','Prata 5','Bronze','Ouro 5',None,None,None,None,None,None,None,'conjuração de tempestades sem dano explícito','MASTER'),
('432c2b324ede8393a90501de383cbe81','Cervídeo Glacial','Cervídeo Glacial','Prata 5','Bronze','Ouro 3',None,None,None,None,None,None,None,'galhada perfurante e cortante sem expressão','MASTER'),
('44fc2b324ede8240813d8187bd1a6778','Escarlate Sombrio','Ignisaurus','Prata 5','Prata 5','Ouro 5',38,'FOR','Mordida','1d6+força',((1,6),),'mordida física inferível',None,'Agilidade de Chama +4 DES and +1d8 fogo conditional; unknown application','MASTER'),
('46ec2b324ede824bad03818efd5838ac','Abissalvorax','Abissalvorax','Prata 5','Ouro Negro','Ouro 2',None,None,None,None,None,None,None,'engolir/corte sem expressão','MASTER'),
('530c2b324ede826da039011f56008eb6','Gorgonídeo','Gorgonídeo','Prata 5','Bronze','Ouro 2',None,None,None,None,None,None,None,'garras e paralisia sem dano explícito','MASTER'),
('5e9c2b324ede83ed99078151805dec0b','Sussurro Celestial','Sussurro Celestial','Prata 5','Prata 5','Ouro 5',45,'INT','Lâmina de Brisa','2d6 + INT',((2,6),),'vento (lâmina)','5 PA','separate reflex +3 10 PA, Sopro -50% 10 PA, etéreo 15 PA','MASTER'),
('b0ec2b324ede835a927601b4cbd8fca6','Guardião Pétreo','Cervídeo Petreo','Ouro 1','Lendário','Ouro 5',40,'FOR','Chifres Petrificados','4d6+for',((4,6),),'chifres físico',None,'RDF20 armor separate, applicability unresolved','MASTER'),
('c5bc2b324ede82628e6e01b466fa0f78','Wyvern','Wyvern','Ouro 1','Lendário','Lendário 4',None,None,None,None,None,None,None,'garras físicas e sopro vento sem fórmula','MASTER'),
('c96c2b324ede8228ab1b81f11f1f0804','Escarlate Flamejante','Ignisaurus','Ouro 1','Ouro 1','PARTY_MIRROR',None,None,None,None,None,None,None,'Party (Mestre — Espelho), excluded from Master analytical denominator; only provenance detected','PARTY_MIRROR'),
('d1dc2b324ede829d9e4e01ee9c063c34','Escarâmnio','Escarâmnio','Ouro 1','Bronze','Ouro 4',None,None,None,None,None,None,None,'Investida Sísmica damage based on CON without numeric coefficient','MASTER'),
('dd7c2b324ede83b084e3019984b6e281','Felino Cósmico','Felino Cósmico','Ouro 1','Bronze','Ouro 1',None,None,None,None,None,None,None,'patas e outros sem fórmula','MASTER'),
('e85c2b324ede838185340120868b73a0','Criatura das Neves Ancestrais','Giganthrix algidus','Ouro 1','Bronze','Ouro 2',None,None,None,None,None,None,None,'braços ramificados ataque sem fórmula','MASTER')
]
# Last-edited timestamps supplied by fresh Notion readbacks (not assertions of date last reverified).
EDITED={
 '56ac2b324ede8352868101e11ea16355':'2026-10-01T18:00:42.552Z',
 '5e4c2b324ede8282ad2c01c9363c3098':'2026-10-01T18:01:07.090Z',
 '5fcc2b324ede8339a5bd01cd65ea103e':'2026-10-01T18:00:47.413Z',
 '725c2b324ede8301baed01d62bd2b8e0':'2026-10-01T18:01:00.789Z',
 '778c2b324ede83d0a89281a4c12ba768':'2026-10-01T18:00:52.773Z',
 '77ec2b324ede82d49662812c1e72b7b0':'2026-10-01T18:00:59.760Z',
 '3b0c2b324ede83cc931801874fb504b5':'2026-10-01T18:00:47.161Z',
 '432c2b324ede8393a90501de383cbe81':'2026-10-01T18:00:43.869Z',
 '44fc2b324ede8240813d8187bd1a6778':'2026-10-01T18:00:46.502Z',
 '46ec2b324ede824bad03818efd5838ac':'2026-10-01T18:00:42.738Z',
 '530c2b324ede826da039011f56008eb6':'2026-10-01T18:01:07.596Z',
 '5e9c2b324ede83ed99078151805dec0b':'2026-10-01T18:00:42.615Z',
 'b0ec2b324ede835a927601b4cbd8fca6':'2026-10-01T18:01:07.076Z',
 'c5bc2b324ede82628e6e01b466fa0f78':'2026-10-01T18:00:48.604Z',
 'c96c2b324ede8228ab1b81f11f1f0804':'2026-09-30T04:47:51.645Z',
 'd1dc2b324ede829d9e4e01ee9c063c34':'2026-10-01T18:01:03.987Z',
 'dd7c2b324ede83b084e3019984b6e281':'2026-10-01T18:00:58.322Z',
 'e85c2b324ede838185340120868b73a0':'2026-10-01T18:00:45.419Z',
}
assert len(EDITED)==18

# Registration lines hold one entry per physical page; duplicate species are not merged.
ledger=[];new=[]
for page,body,tree,rank,bodyrank,ancestor,attr,attrib_type,action,formula,dice,typ,cost,notes,scope in D:
    assert (action is None) == (formula is None)
    identity_conflict=(body.casefold()!=tree.casefold())
    entry={'page_id':page,'url':f'https://app.notion.com/p/{page}','side':scope,'rank_title':rank,'rank_body':bodyrank,'ancestor_rank':ancestor,'body_identity':body,'tree_identity':tree,'identity_label_difference':identity_conflict,'rank_triple_concordance':rank==bodyrank==ancestor,'numeric_initial':int(bool(formula)),'name':action,'literal_formula':formula,'attr_value':attr,'attr_name':attrib_type,'cost':cost,'damage_type':typ,'notes':notes,'lot_003_member':'NOT_PROVEN','source':'NOTION_DIRECT_READBACK_R04_20261015','source_last_edited_at':EDITED[page]}
    ledger.append(entry)
    if formula: new.append(abil(page,action,formula,dice,attr,attrib_type,type_doc=typ,conditions=notes,cost=cost,rank=rank,section='R04_FROZEN18',side=scope,identity_conflict=identity_conflict))
assert len(ledger)==18 and len(new)==8 and len({x['page_id'] for x in ledger})==18
put('R04_NEW_PAGE_LEDGER.json',ledger)
put('R04_NEW_INITIAL_EXACT.json',new)

parent_ledger=(R03/'R03_EXPRESSION_LEDGER.json') if (R03/'R03_EXPRESSION_LEDGER.json').exists() else (ROOT/'R03_BASELINE_EXPRESSION_LEDGER.json')
old=[e for e in load(parent_ledger) if e.get('role')=='INITIAL']
assert len(old)==21 and len(new)==8
old2=[]
for x in old:
    dic=[tuple(z) for z in x['dice']]
    z=abil(x['page_id'],x['name'],x['formula'],dic,x.get('attribute_value'),x.get('attribute'),type_doc=x.get('damage_type_documented'),conditions=x.get('conditions',''),cost=x.get('cost_documented'),rank=x.get('rank_title'),section='R03_FROZEN36')
    assert abs(z['gross_mean']-x['gross_expected'])<1e-8
    old2.append(z)
master=[x for x in new if x['scope']=='MASTER']
assert len(master)==8
all29=old2+master
attr=[x for x in all29 if x['attribute_value'] is not None]
noattr=[x for x in all29 if x['attribute_value'] is None]
assert len(attr)==28 and len(noattr)==1
for_sums={'attr_total':sum(x['attribute_value'] or 0 for x in all29),'intrinsic_total':sum(x['intrinsic_mean'] for x in all29),'total':sum(x['gross_mean'] for x in all29)}
for_sums['attrib_share_of_all_numeric_initial']=for_sums['attr_total']/for_sums['total']
for_sums['attrib_share_attr_only']=for_sums['attr_total']/sum(x['gross_mean'] for x in attr)
for_sums['attr_action_count']=len(attr)
for_sums['noattr_action_count']=len(noattr)
for_sums['numeric_initial_actions']=len(all29)
for_sums['r03_36_pages']=36
for_sums['r04_frozen_new_master_pages']=17
for_sums['r04_frozen_party_mirror_page_excluded']=1
for_sums['r04_new_numeric_initial']=8
for_sums['r04_new_noattr_numeric_initial']=0
for_sums['eligible_master_discovery_pages_total']=53
for_sums['numeric_initial_action_percent_of_explored_pages']=len(all29)/53 # actions / pages NOT coverage; explanatory only
put('R04_BIAS_CONTROL.json',{'full_formula_census':for_sums,'new_action_formula_ids':[x['page_id'] for x in master], 'source_mismatch_caveat':'29 numeric initial actions spread over 53 Master pages; selection on title/UUID before damage, but numeric-only denominator excludes incomplete effects, thus not population statistic. No rank prevalence claims. Same-species versions appear in same 53 pages, so independent creature count is lower than pages.','nonattr_observation':f"{len(noattr)}/29 literal numerically complete initial damage expressions omit attributes",'zero_attribute_are_not_zero_damage':'No-attribute example Prata 5 Raposa Alfa `Punhos de fogo 1d4` from R03 source page 2f3c..., body says Bronze5, ancestral Prata5; kept arithmetically but excluded rank analyses.','other_categories':{'r03_conditional_ticks':3,'r03_heals':2,'r03_pa_drain':1,'r03_reactive_damage':1,'r03_incomplete_formula':1,'r04_intrinsic_fire_rider_1d8':'conditional on Agilidade de Chama, not identified as direct independent impact','r04_fixed_other_3':'Demônios Vermelhos Força Demoniaca +3 dano, without standalone dice','r04_non_damage_action_attack_bonus_2':'Raios de Tempestade Aura Energia +2 ataque, not generic damage','r04_incomplete_offense':'Several named abilities have attack descriptions without numeric damage; counted by page in ledger, not assigned 0.'}})

# Lupusventus A/B and original electric R03, show sensitivity only under equal RD and no type equivalence.
lupus={};eagle=pmf(((1,4),),30)
for force in [25,27]:
    d=pmf(((2,6),),force)
    lupus[str(force)]={'FOR':force,'mean_bruto':float(expectation(d)),'PMF':{str(k):v for k,v in d.items()},'RD':{str(rd):outcome(d,rd) for rd in [5,15,25,30,31,35,37,40]}}
put('R04_LUPUS_A_B.json',{'source':'https://app.notion.com/p/4bac2b324ede8321af6b01eb96452d04','authority':'Força Ancestral +2 printed, PASSIVE_OR_ACTIVATED_OR_PREINCORPORATED UNKNOWN','scenario_A':lupus['25'],'scenario_B':lupus['27'],'eagle_R03_DISC_01':{'source':'https://app.notion.com/p/206c2b324ede835383a1818a6edd5273','formula':'1d4 + INT30','classification':'not same mitigation type; R03 conditional comparison only'},'comparisons':{str(rd):{'eagle_E':float(damp(eagle,rd)),'lupus_A_E':float(damp(pmf(((2,6),),25),rd)),'lupus_B_E':float(damp(pmf(((2,6),),27),rd))} for rd in [15,25,30,31,35,37,40]}})

# Within one monster both attacks explicitly physical but different subtypes; general physical RD same if target has no subtype-specific resistance.
monkey_id='301c2b324ede828caccb813d3979267a';monkey={}
for force in [54,56]:
  pat=pmf(((2,6),),force); bite=pmf(((1,6),),force)
  monkey[str(force)]={'FOR':force,'Patada_impacto':{'formula':f'2d6+{force}','mean':float(expectation(pat)),'min':min(pat),'max':max(pat)},'Mordida_perfurante':{'formula':f'1d6+{force}','mean':float(expectation(bite)),'min':min(bite),'max':max(bite)},'rd':{str(rd):{'Patada':outcome(pat,rd),'Mordida':outcome(bite,rd),'expected_patada_minus_mordida':str(damp(pat,rd)-damp(bite,rd))} for rd in [5,15,25,30,35,45,55,60,65]}}
  # Pathwise dominance: double dice min >= single dice min with same first die, + second die>=1, independent samples not required for stochastic dominance
  for rd in [0,5,15,25,30,35,45,55,60,65]: assert damp(pat,rd)>=damp(bite,rd)
put('R04_PHYSICAL_HOMOGENEOUS.json',{'source':f'https://app.notion.com/p/{monkey_id}','classification':'Title Prata5(titã), body Prata5, ancestor Ouro Negro5: cannot use cross-rank inference','effect_types':{'Patada':'impacto explicitly written','Mordida':'perfurante explicitly written'},'same_actor_both_physical':True,'generic_physical_RD_scenario':'Shared generic physical RD only, not subtype-specific. No bonus to accuracy inferred.','FOR54_printed_vs_FOR56_Force_Titanica_uncertain':'both states kept; printed +2 força not proven as extra over printed FOR54','scenarios':monkey,'result':'Patada distribution first-order stochastically dominates Mordida in every RD scenario, if same hit and cost conditions; no RD-only inversion possible here.'})

# Same-species, same named Vento skill in Prata1 vs Prata5 labels; no automatic evolution identity or equal defense-class applicability.
wind1=pmf(((1,6),),30);wind5=pmf(((2,6),),45)
wind={'sources':['https://app.notion.com/p/56ac2b324ede8352868101e11ea16355','https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b'],'ability':'Lâmina de Brisa','type':'Vento blade for both pages, no additional physical assumption','source_shared_tree_species':'Sussurro Celestial, both under ancestral Ouro5, but printed Prata1/Prata5 and both bodies match respective title; cannot assign precise rank without ancestor adjudication','Prata1':{'formula':'1d6+INT30','gross_mean':str(expectation(wind1)),'range':[min(wind1),max(wind1)],'documented_PA':None},'Prata5':{'formula':'2d6+INT45','gross_mean':str(expectation(wind5)),'range':[min(wind5),max(wind5)],'documented_PA':5},'delta':{'gross_mean':str(expectation(wind5)-expectation(wind1)),'attribute_increment':15,'intrinsic_dice_mean_increment':'7/2','attribute_share_of_increment':'30/37'},'conditional_same_RD':{str(rd):{'Prata1':outcome(wind1,rd),'Prata5':outcome(wind5,rd)} for rd in [5,15,25,35,45,55]},'PA_qualification':'Prata5 per documented activation = 5 PA, Prata1 no cost stated; no comparison of per action, chance to hit, and no inference that Prata1 is zero-cost.'}
put('R04_SAME_ELEMENT_WIND.json',wind)

# Conditional accuracy on official tiger target. L=0 is explicit sensitivity parameter, not documented Luta.
tiger={'source':'https://app.notion.com/p/725c2b324ede8301baed01d62bd2b8e0','CA':33,'RD':15,'rank':'Prata1 title/body/ancestor concordant','reaction':'not quantified'}
precision=[]
for L in [0,2,4,6]:
 for f in [25,27]:
    atk=pmf(((2,6),),f+L);p=penetration(atk,tiger['CA']);net=damp(pmf(((2,6),),f),tiger['RD']); precision.append({'Luta_counterfactual':L,'FOR_scenario':f,'attacker_test_dice':'2d6','target_CA':33,'target_RD':15,'P_hit_fraction':str(p),'P_hit':float(p),'E_net_given_hit':float(net),'E_net_per_attempt_no_crit_no_reaction':float(p*net),'E_fraction':str(p*net)})
# Concha natural bite vs identical target with defensive Casca preactive. Not execution, active ability cost unknown.
concha=[]
for target_ca in [40,45]:
    attack=pmf(((2,6),),30)
    p=penetration(attack,target_ca)
    gross=pmf(((3,6),),30)
    net=damp(gross,15)
    concha.append({'CONCHA_Luta_counterfactual':0,'CA':target_ca,'CA_origin':'+5 casca revestida activated for one turn' if target_ca==45 else 'printed CA','P_hit':str(p),'E_net_on_hit_RD15':str(net),'E_net_per_attempt':str(p*net)})
# R32 event known and qualified: explicit one action normal in VLAB readback.
frigid_action={'source':'https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315','VLAB_source':'https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2','target':'Cabra de Chifres Bronze1 CA20 CON10 RD5','source_rule':'Rabada only: Luta +6 sanctioned, FOR18, 1d6+FOR damage, 1 Ação Padrão, +0 PA, no mandatory rider','basic_hit_P_no_reaction':'1/1','E_damage_after_RD_no_crit':str(damp(pmf(((1,6),),18),5)),'one_action_opportunity_cost_no_crit_no_reaction':'33/2','Defender_formula':'6+CON10+Armor+Fortitude = 16 + Armor + Fortitude','VLAB_R32_roll':'attack27 vs CA20, raw21, net16, cabra HP38->22, no voluntary reaction','condition_to_nullify_that_specific_27_attack_if_Defender_declared':'Armor+Fortitude >= 11, if defensive reaction legally available; both unknown, not claim effect actual'}
put('R04_PRECISION_ACTION_SENSITIVITY.json',{'Lupus_vs_Tigris':{'notes':'ILLUSTRATIVE ONLY: Lupus Patada use FOR and Prata2d6 normal-attack interpretation; L=0/2/4/6 are counterfactual parameters, not granted bonuses. No crit, no reaction, damage roll independent. Prata1 target rank/body/title/ancestor coherent. FOR27 conditional on +2 non-double-counting.','target':tiger,'rows':precision},'Concha_vs_equivalent_Concha':{'notes':'HYPOTHETICAL same-species matching target; generic physical RD15, attacker and defender full ability activations unknown; Casca revestida +5CA for 1 turn does not claim reaction','rows':concha},'R32_frigid_action':frigid_action})

# Basic brute-force QA checks implemented independently of counter-convolution for selected formulas.
checks=[]
def ck(label,got,expected):
 ok=got==expected;checks.append({'label':label,'PASS':ok,'actual':str(got),'expected':str(expected)}); assert ok,(label,got,expected)
ck('cohort all 18 physical pages unique',len({x['page_id'] for x in ledger}),18)
ck('party mirrors excluded exactly one',sum(x['side']=='PARTY_MIRROR' for x in ledger),1)
ck('R03 initial 20 attrs',sum(x['attribute_value'] is not None for x in old2),20)
ck('R03 initial 1 no attr',sum(x['attribute_value'] is None for x in old2),1)
ck('R04 initial 8 attr',len(master),8)
ck('Lupus A brute gross',expectation(pmf(((2,6),),25)),Fraction(32,1))
ck('Lupus B brute gross',expectation(pmf(((2,6),),27)),Fraction(34,1))
ck('Lupus A RD31',damp(pmf(((2,6),),25),31),Fraction(14,9))
ck('Lupus B RD31',damp(pmf(((2,6),),27),31),Fraction(28,9))
ck('Lupus A RD35',damp(pmf(((2,6),),25),35),Fraction(1,9))
ck('Lupus B RD35',damp(pmf(((2,6),),27),35),Fraction(5,9))
ck('Eagle RD31',damp(eagle,31),Fraction(3,2))
ck('Eagle RD35',damp(eagle,35),Fraction(0,1))
ck('Símio physical Patada E',expectation(pmf(((2,6),),54)),Fraction(61,1))
ck('Símio physical Mordida E',expectation(pmf(((1,6),),54)),Fraction(115,2))
ck('RD60 Patada expected',damp(pmf(((2,6),),54),60),Fraction(14,9))
ck('RD60 Mordida zero',damp(pmf(((1,6),),54),60),Fraction(0))
ck('Tigris L=0 FOR25 P hit',penetration(pmf(((2,6),),25),33),Fraction(10,36))
ck('Tigris L=0 FOR27 P hit',penetration(pmf(((2,6),),27),33),Fraction(21,36))
ck('Concha self baseline P hit',penetration(pmf(((2,6),),30),40),Fraction(3,36))
ck('Concha self defensive P hit',penetration(pmf(((2,6),),30),45),Fraction(0))
ck('wind Prata1 mean',expectation(wind1),Fraction(67,2))
ck('wind Prata5 mean',expectation(wind5),Fraction(52))
ck('wind delta attribute',Fraction(45-30),Fraction(15))
ck('wind delta intrinsic',expectation(pmf(((2,6),)))-expectation(pmf(((1,6),))),Fraction(7,2))
ck('wind Prata1 RD35',damp(wind1,35),Fraction(1,6))
ck('wind Prata5 RD35',damp(wind5,35),Fraction(17))
ck('wind Prata5 RD45',damp(wind5,45),Fraction(7))
ck('R32 opportunity',damp(pmf(((1,6),),18),5),Fraction(33,2))
for dic in master:
 dice=dic['dice'];vals=[sum(s)+int(dic['attribute_value'] or 0) for s in itertools.product(*[range(1,k+1) for n,k in dice for _ in range(n)])];b=collections.Counter(vals);x=pmf([tuple(t) for t in dice],dic['attribute_value'] or 0)
 ck('bruteforce new '+dic['page_id'][:5],b,x)
 for rd in [5,15,25,30,31,35,40]:
  ck('bruteforce RD '+dic['page_id'][:5]+' '+str(rd),damp(x,rd),Fraction(sum(max(0,y-rd) for y in vals),len(vals)))
put('R04_QA_MATHEMATICAL.json',{'total_checks':len(checks),'passed':sum(x['PASS'] for x in checks),'all_passed':all(x['PASS'] for x in checks),'checks':checks})

# All complete initial actions in prior 36, plus 17 new MASTER pages, no reconstructed historic L003 coalescence.
with (ROOT/'R04_ALL_INITIAL_ACTIONS.csv').open('w',newline='',encoding='utf-8') as f:
 fields=['section','page_id','url','name','literal_formula','attr_code','attribute_value','intrinsic_mean','gross_mean','fraction_attribute','damage_type_documented','cost_documented','conditions']
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
 for x in all29:writer.writerow({k:x.get(k) for k in fields})

handoff={
 'id':'DMG-R04-TO-VLAB-READONLY-DELTA','producer':'CM-000001 / OP-DMG-CORPUS-EMP-01','consumer':'CM-000006 / OP-VLAB-FUSION-SANDBOX-01','not_automatic_delivery':True,'source':'DMG-RANK-01 v1.1 official unchanged','requires_VLAB_explicit_admission':True,'no_canonic_writes':True,
 'cases':[
  {'case':'R04-PHYS-01','source_ids':['301c2b324ede828caccb813d3979267a'],'A':'Patada:2d6+FOR54 impacto','B':'Mordida:1d6+FOR54 perfurante','hypothesis':'under same generic physical RD, same atk precision & action costs, Patada stochastically dominates Mordida','expected':'for RD15, E=46 and 42.5; for RD60, E=1.5556 and0','falsifies':'authenticated evidence of subtype differential resistance, different attack/consumption, mandatory rider or precision differences overturning conditional comparison','contract_status':'MATH_ONLY','missing':['rank title Prata5/titã vs tree Ouro Negro5','FOR +2 Força Titânica status','Luta for each ability','both attacks action model','target actual physical RD and reaction'],'event_executed':False},
  {'case':'R04-VENTO-PRATA-PAIR','source_ids':['56ac2b324ede8352868101e11ea16355','5e9c2b324ede83ed99078151805dec0b'],'A':'Lâmina de Brisa 1d6+INT30 Prata1','B':'Lâmina de Brisa 2d6+INT45 Prata5 (5PA documented)','hypothesis':'same named Vento ability changes 18.5 mean damage, including 15 attribute and 3.5 dice, at fixed identical mitigation','expected':'bruto33.5 vs52, RD35 conditional0.166667 vs17; Prata5 cost5PA vs Prata1 not documented','falsifies':'distinct damage type, incompatible species/version identity, different target RD, cost/accuracy/CA reactions','contract_status':'MATH_ONLY','missing':['ancestor tree Ouro5 despite title/body Prata1 and Prata5','Prata1 cost','Luta or save per attack','whether same targeting and action economy','Vento damage applicability to chosen RD'],'event_executed':False},
  {'case':'R04-LUPUS-AB-01','source_ids':['4bac2b324ede8321af6b01eb96452d04','725c2b324ede8301baed01d62bd2b8e0'],'states':['FOR25','FOR27 additional +2 not double counted'], 'hypothesis':'IF +2 is legitimate in atk and damage, against Prata1 Tigris CA33 RD15, chance to land a non-critical normal attack at Luta fixed hypothetical 0 rises 10/36->21/36','expected':'expected damage attempt 85/18? no: 17*(10/36)=85/18=4.7222 vs 19*(21/36)=133/12=11.0833','falsifies':'verified +2 already included, bonuses do not apply to attack, different Luta, reaction or mitigation','contract_status':'MATH_ONLY','missing':['Força Ancestral active or already included','named skill Luta','classification/identity reconciliation Lupusventus/lobo da caverna','reactions'],'event_executed':False},
  {'case':'R04-R03-DISC-01','source_ids':['206c2b324ede835383a1818a6edd5273','4bac2b324ede8321af6b01eb96452d04'],'A':'Raio Paralisante 1d4+INT30','B':'Patada2d6+FOR25|27','hypothesis':'uniform RD crossover at31 for A status, not necessarily real-world because electric vs physical','expected':'RD31 E Eagle1.5 Lupus A1.55556 B3.11111','falsifies':'difference in actual resistance applicability or bonus state','contract_status':'MATH_ONLY_NOT_DAMAGE_TYPE_COMPARABLE','missing':['RD electric vs physical','paralysis','Luta','+2 Force'],'event_executed':False},
  {'case':'R04-DEF-CA-01','source_ids':['474c2b324ede82d08ea6819069c17043'],'A':'Concha Mordida3d6+FOR30 vs identical Concha hypothetical target printed CA40','B':'target Casca revestida activated +5 CA for 1 turn','hypothesis':'if Prata2d6+FOR attack, Luta fixed hypothetical0, reaction none, p=3/36 vs0','expected':'E after Prata RD15=25.5 if hit; E per attempt 2.125 vs0','falsifies':'Casca must take reaction/cost incompatible with circumstance, attack Luta not0 or alternate hit defense','contract_status':'MATH_ONLY','missing':['Luta true','Casca action activation and PA','defensive reaction','critical'],'event_executed':False},
  {'case':'R04-R32-OPPORTUNITY','source_ids':['f0dc2b324ede820ab9470168d4a53315','391c2b324ede8252b0cc810423cdbfa6'],'A':'authorized native R32 Rabada action','hypothesis':'no reaction, no crit, losing one opportunity to Rabada forfeits 16.5 expected HP damage per action (including any replacement cost unknown)','expected':'R32 existing journal hit27 raw21 net16; theoretical E(net|hit)=16.5','falsifies':'new valid reaction, environmental constraint, crit, target change or alternate opportunity','contract_status':'REFERENCE_DOCUMENTED_R32_ONLY_NO_NEW_ENGINE','missing':['Crit expectation complete','additional reactions'],'event_executed':False}
 ],'handoff_not_sent_to_other_instance':True}
put('R04_VLAB_CASES_READONLY.json',handoff)

summary={'newly_reopened_pages':18,'new_master_pages':17,'new_party_mirror_page_metadata_only':1,'cumulative_distinct_exploration_pages_R03_plus_R04':54,'master_exploration_pages':53,'new_initial_damage_actions':8,'prior_R03_initial_damage_actions':21,'combined_initial_actions':29,'prior_R03_36_pages':36,'new_actions_with_attr':8,'new_actions_without_attr':0,'all_formula_initial_with_attr':28,'all_formula_initial_without_attr':1,'classification_new_full_concordant_pages':sum(x['rank_triple_concordance'] for x in ledger if x['side']=='MASTER'),'classification_new_conflict_pages':sum(not x['rank_triple_concordance'] for x in ledger if x['side']=='MASTER'),'printed_body_rank_discrepancies_new':sum(x['rank_title']!=x['rank_body'] for x in ledger if x['side']=='MASTER'),'tree_title_rank_discrepancies_new':sum(x['rank_title']!=x['ancestor_rank'] for x in ledger if x['side']=='MASTER'),'historic_l003_authenticated_pages':0,'historic_l003_reported_pages':71,'historic_l003_pairs_authenticated':0,'f0_documentary_gates':'4/8','productive_writes':0,'event_new_VLAB':0,'qa':len(checks),'result_core':'A controlled same-source pair of physical attacks obeys stochastic ordering under uniform physical RD, whereas R03 electric-vs-physical inversion is non-admissible as unconditional live-combat ranking. Lupus bonus A/B dramatically affects conditional precision and damage.'}
put('R04_SUMMARY.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2));print('QA',len(checks),'PASS')
