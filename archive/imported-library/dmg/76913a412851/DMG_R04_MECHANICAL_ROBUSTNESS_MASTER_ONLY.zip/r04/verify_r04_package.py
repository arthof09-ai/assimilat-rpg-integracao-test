#!/usr/bin/env python3
import json,zipfile,hashlib,sys,io,pathlib
p=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path(__file__).with_name('DMG_R04_MECHANICAL_ROBUSTNESS_MASTER_ONLY.zip')
with zipfile.ZipFile(p) as z:
 bad=z.testzip(); assert bad is None, f'Bad CRC at {bad}'
 name='R04_MANIFEST_SHA256.json'
 m=json.loads(z.read(name)); records=m['entries']; assert len(records)>10
 assert len(set(records))==len(records)
 for rel,record in records.items():
  data=z.read(rel)
  assert hashlib.sha256(data).hexdigest()==record['sha256'],rel
  assert len(data)==record['size_bytes'],rel
  assert rel.startswith('r04/'),rel
 assert set(z.namelist())==set(records)|{name},'ZIP manifest mismatch'
 print(json.dumps({'zip':str(p),'files_verified':len(records),'crc':'PASS','content_sha256':'PASS','zip_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
