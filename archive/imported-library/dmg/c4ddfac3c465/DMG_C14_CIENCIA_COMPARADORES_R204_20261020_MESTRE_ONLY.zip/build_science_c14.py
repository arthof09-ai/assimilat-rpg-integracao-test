#!/usr/bin/env python3
"""C14 scientific records and numeric decompositions. No Notion/SQLite writes."""
from pathlib import Path
from fractions import Fraction
import csv,json,math,hashlib
root=Path(__file__).resolve().parent
BASE='https://app.notion.com/p/'
# Source facts physically fetched from the Mestre Notion connector, per-source page version.
# Domain/effect ranks are never inferred from a leaf title or a family's highest-rank folder.
rows=[
# Family, uuid, title, body rank, ancestry, timestamp, ability, expression, attr, fixed, dice, extra, status
('Sussurro Celestial','56ac2b324ede8352868101e11ea16355','Prata 1','Prata 1','Ouro 5 · 8','2026-10-01T18:00:42.552Z','Lâmina de Brisa','1d6+INT',30,0,[(1,6)],'PA não documentado','CONFIRMADA_LOCAL;ANALISE_EXPLORATORIA'),
('Sussurro Celestial','5e9c2b324ede83ed99078151805dec0b','Prata 5','Prata 5','Ouro 5 · 8','2026-10-01T18:00:42.615Z','Lâmina de Brisa','2d6+INT',45,0,[(2,6)],'5 PA publicado junto à habilidade','CONFIRMADA_LOCAL;ANALISE_EXPLORATORIA'),
('Sussurro Celestial','442c2b324ede8364870a814350dd5051','Ouro 1','Ouro 1','Ouro 5 · 8','2026-10-01T18:00:42.678Z','Lâmina de Brisa','2d4+INT',26,0,[(2,4)],'PA não documentado','CONFIRMADA_LOCAL;ANALISE_EXPLORATORIA'),
('Sussurro Celestial','597c2b324ede8242bd5881027ef8d21f','Ouro 5','Ouro 1','Ouro 5 · 8','2026-10-01T18:00:42.749Z','Lâmina de Brisa','2d4+INT',40,0,[(2,4)],'título/corpo divergem; PA não documentado','CONFLITANTE;EXCLUIDA_STRICT'),
('Hidrargos','b85c2b324ede824dbfb301ccd441a96e','Ouro 4 Titã','Ouro 4','Ouro 4','2026-10-01T18:00:39.410Z','Mordida','6d12+120 /161 de Dano',120,0,[(6,12)],'nota /161 sem significado estatístico confirmado','CONFIRMADA_LOCAL;NOTA_AMBIGUA;EXPLORATORIA'),
('Hidrargos','bc7c2b324ede82ef97330199ec466b1b','Ouro 5 Titã','Ouro 4','Ouro 4','2026-10-01T18:00:39.466Z','Mordida','10d12+145 /209 de Dano',145,0,[(10,12)],'nota /209 sem significado estatístico confirmado','CONFLITANTE;NOTA_AMBIGUA;EXCLUIDA_STRICT'),
('Hidrargos','31ec2b324ede8305beae81f92349faa9','Ouro Negro 1 Titã','Ouro 4','Ouro 4','2026-10-01T18:00:39.542Z','Mordida','19d12+173 /295 de Dano',173,0,[(19,12)],'nota /295 sem significado estatístico confirmado','CONFLITANTE;NOTA_AMBIGUA;EXCLUIDA_STRICT'),
('Aetheria','4acc2b324ede8352909d81293c163bbf','Ouro Negro 2','Ouro Negro 2','Ouro Negro 4 · 1','2026-10-01T18:00:46.141Z','Canto das Alturas','14d6+42+INT',80,42,[(14,6)],'área + chance de derrubar; PA, acerto e área exata ausentes','CONFIRMADA_LOCAL;EXPLORATORIA_TITA'),
('Aetheria','4acc2b324ede8352909d81293c163bbf','Ouro Negro 2','Ouro Negro 2','Ouro Negro 4 · 1','2026-10-01T18:00:46.141Z','Lâminas de Luz Prismática','12d6+36+INT',80,36,[(12,6)],'linha reta + sangramento/mobilidade; PA e acerto ausentes','CONFIRMADA_LOCAL;EXPLORATORIA_TITA'),
('Aetheria','bc6c2b324ede834cb396816167377462','Ouro Negro 4 Titã','Ouro Negro 4','Ouro Negro 4 · 1','2026-10-01T18:00:46.263Z','Canto das Alturas','15d10+45+INT',120,45,[(15,10)],'área + chance de derrubar; variante Titã, PA e acerto ausentes','CONFIRMADA_LOCAL;EXPLORATORIA_TITA'),
('Aetheria','bc6c2b324ede834cb396816167377462','Ouro Negro 4 Titã','Ouro Negro 4','Ouro Negro 4 · 1','2026-10-01T18:00:46.263Z','Lâminas de Luz Prismática','13d10+39+INT',120,39,[(13,10)],'linha reta + sangramento/mobilidade; variante Titã, PA e acerto ausentes','CONFIRMADA_LOCAL;EXPLORATORIA_TITA'),
('Raposa Flamejante','4d0c2b324ede827b9925018be01e60ca','Bronze 2','Bronze 2','Prata 5 · 2','2026-10-01T18:00:46.092Z','Bola de Fogo','1d4+5',0,5,[(1,4)],'habilidade distinta, não comparar com Soco/Punhos','CONFIRMADA_LOCAL;NAO_HOMOGENEA'),
('Raposa Flamejante','529c2b324ede82e8a86f81f8cfc0477e','Bronze 5','Bronze 5','Prata 5 · 2','2026-10-01T18:00:46.167Z','Punhos de Fogo','1d4',0,0,[(1,4)],'sem PA publicado; distinta de Soco','CONFIRMADA_LOCAL;EXPLORATORIA'),
('Raposa Flamejante','529c2b324ede82e8a86f81f8cfc0477e','Bronze 5','Bronze 5','Prata 5 · 2','2026-10-01T18:00:46.167Z','Soco','1d6+FOR',20,0,[(1,6)],'sem custo/acerto publicado','CONFIRMADA_LOCAL;EXPLORATORIA'),
('Raposa Flamejante','2f3c2b324ede830c94af0113e39a1a50','Prata 5','Bronze 5','Prata 5 · 2','2026-10-01T18:00:46.258Z','Punhos de Fogo','1d4',0,0,[(1,4)],'título Prata5, corpo Bronze5; excluir progressão estrita','CONFLITANTE;EXCLUIDA_STRICT'),
('Raposa Flamejante','2f3c2b324ede830c94af0113e39a1a50','Prata 5','Bronze 5','Prata 5 · 2','2026-10-01T18:00:46.258Z','Soco','1d6+FOR',60,0,[(1,6)],'título Prata5, corpo Bronze5; excluir progressão estrita','CONFLITANTE;EXCLUIDA_STRICT'),
]
headers=['family','source_uuid','source_url','source_last_edited_at','title_rank','body_rank','ancestor_container','effect','literal_formula','dice_pool','dice_intrinsic_mean','fixed_nonattribute_mean','external_attribute','gross_mean','gross_min','gross_max','variance_dice','external_attribute_share','rank_status','effect_rank_state','comparability','conditions_pa']
records=[]
for family,uid,title,body,anc,edit,effect,expr,attr,fixed,dice,extra,flags in rows:
    mean=sum(Fraction(n*(s+1),2) for n,s in dice);var=sum(Fraction(n*(s*s-1),12) for n,s in dice)
    gross=mean+attr+fixed; mn=sum(n for n,s in dice)+attr+fixed;mx=sum(n*s for n,s in dice)+attr+fixed
    state='CONFLITANTE' if 'CONFLITANTE' in flags else 'CONFIRMADA_LOCAL'
    comp='EXCLUIDA_STRICT' if 'EXCLUIDA_STRICT' in flags else 'EXPLORATORIA' if 'EXPLORATORIA' in flags else 'NAO_HOMOGENEA'
    records.append(dict(zip(headers,[family,uid,BASE+uid,edit,title,body,anc,effect,expr,'+'.join(f'{n}d{s}' for n,s in dice),float(mean),fixed,attr,float(gross),mn,mx,float(var),round(attr/float(gross),6),state,'NAO_DOCUMENTADO_INDEPENDENTEMENTE',comp,extra])))
assert len(records)==16 and len(set(x['source_uuid'] for x in records))==12
assert len(set((x['family'],x['effect']) for x in records))==7
with (root/'C14_SOURCE_CLASSIFICATION_AND_EFFECTS.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(records)
by={(x['family'],x['effect'],x['title_rank']):x for x in records}
pairs=[('Sussurro Celestial','Lâmina de Brisa','Prata 5','Ouro 1','EXPLORATORIA_FAMILY_ANCESTOR_HIGH_RANK_PA_DIFFERENT'),('Aetheria','Canto das Alturas','Ouro Negro 2','Ouro Negro 4 Titã','EXPLORATORIA_TITAN_DELIVERY_COST_UNRESOLVED'),('Aetheria','Lâminas de Luz Prismática','Ouro Negro 2','Ouro Negro 4 Titã','EXPLORATORIA_TITAN_DELIVERY_COST_UNRESOLVED'),('Raposa Flamejante','Soco','Bronze 5','Prata 5','EXCLUIDA_STRICT_TITLE_BODY_CONFLICT')]
report=[]
for family,e,a,b,state in pairs:
 x=by[(family,e,a)];y=by[(family,e,b)]
 delta_dice=y['dice_intrinsic_mean']-x['dice_intrinsic_mean'];delta_f=y['fixed_nonattribute_mean']-x['fixed_nonattribute_mean'];delta_attr=y['external_attribute']-x['external_attribute'];delta_total=y['gross_mean']-x['gross_mean']; assert abs(delta_dice+delta_f+delta_attr-delta_total)<1e-8
 report.append({'family':family,'effect':e,'from_rank_title':a,'to_rank_title':b,'source_from_uuid':x['source_uuid'],'source_to_uuid':y['source_uuid'],'from_gross_mean':x['gross_mean'],'to_gross_mean':y['gross_mean'],'total_difference':delta_total,'difference_intrinsic_dice':delta_dice,'difference_intrinsic_fixed':delta_f,'difference_external_attr':delta_attr,'difference_dice_share_of_delta':round(delta_dice/delta_total,6) if delta_total else None,'difference_attr_share_of_delta':round(delta_attr/delta_total,6) if delta_total else None,'admissibility':state})
with (root/'C14_PAIRED_DECOMPOSITIONS.csv').open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(report[0]));w.writeheader();w.writerows(report)
# Negative controls verified in Mestre Notion; no numeric damage ability (drops excluded).
negative=[('Wyvern','c5bc2b324ede82628e6e01b466fa0f78','Ouro 1','Lendário','dano ofensivo apenas qualitativo'),('Wyvern','a78c2b324ede83069d7801b3519e2a4f','Ouro 5','Lendário','dano ofensivo apenas qualitativo'),('Wyvern','d35c2b324ede8253a4398137a8c7b9cc','Ouro Negro 2','Lendário','dano ofensivo apenas qualitativo'),('Wyvern','36fc2b324ede839ca820017c2275f47f','Ouro Negro 4 Titã','Lendário','dano ofensivo apenas qualitativo'),('Wyvern','6c6c2b324ede8295ad98813f0db138f4','Lendário 1','Lendário','dano ofensivo apenas qualitativo'),('Wyvern','e09c2b324ede83c8b8d101a3c90ccbcc','Lendário 4','Lendário','dano ofensivo apenas qualitativo')]
with (root/'C14_NEGATIVE_FAMILY_CONTROL.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['family','uuid','title_rank','body_rank','admission','reason']);w.writerows([(f,u,t,b,'EXCLUIDA_DANO_NUMERICO',reason) for f,u,t,b,reason in negative])
# Prospective equipment: independent chassi only, whole action DME is not a free second budget.
arms=[]
for n,s,label in [(1,8,'espada'),(2,6,'arma brutal')]:
 for rank,mult in [('Comum',1),('Bronze',2),('Prata',3),('Ouro',4),('Ouro Negro',5),('Lendário',6)]:
  arms.append({'chassis':label,'rank':rank,'base_dice':f'{n}d{s}','new_physical_dice':f'{n*mult}d{s}','physical_mean':n*mult*(s+1)/2,'extra_test_dice':'1d4' if rank=='Prata' else '', 'combined_test_example_mean':n*mult*(s+1)/2+2.5 if rank=='Prata' else '', 'normative_state':'MESTRE_PROSPECTIVE_DECISION_NOT_CANONICALLY_INTEGRATED','full_action_budget':'MUST_INCLUDE_PHYSICAL_PLUS_OTHER_INTRINSIC_NO_DUPLICATE'})
with (root/'C14_PROSPECTIVE_ARMS_COMPATIBILITY.csv').open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(arms[0]));w.writeheader();w.writerows(arms)
(root/'C14_SOURCE_MATRIX_SUMMARY.json').write_text(json.dumps({'as_of':'2026-10-20','operation':'OP-DMG-CORPUS-EMP-01','source_leaf_pages_numeric':len(set(x['source_uuid'] for x in records)),'effect_occurrences':len(records),'independent_definitions_by_family_effect':len(set((x['family'],x['effect']) for x in records)),'families_numeric':sorted(set(x['family'] for x in records)),'negative_leaf_pages_qualitative':len(negative),'new_families_not_in_C13':['Aetheria','Raposa Flamejante'],'pair_rows':report,'note':'Source facts from direct Mestre Notion readback. No independent second researcher; no rank-of-effect promoted from actor rank.'},ensure_ascii=False,indent=2),encoding='utf-8')
print('C14_SOURCE_MATRIX',len(records),'occurrences',len(set(x['source_uuid'] for x in records)),'pages',len(set((x['family'],x['effect']) for x in records)),'definitions',len(negative),'negative pages')
for x in report:print(x['family'],x['effect'],x['total_difference'],x['difference_intrinsic_dice'],x['difference_intrinsic_fixed'],x['difference_external_attr'],x['admissibility'])
