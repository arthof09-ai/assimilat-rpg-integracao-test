# DMG C14 — Reconciliação portável (MESTRE-SIDE)

Operation: `OP-DMG-CORPUS-EMP-01` · As-of 2026-10-20 · DMG-RANK-01 v1.1 preserved · F0 4/8 · production HOLD.

No new DMG or VLAB engine. The package is a *scientific delta*: hand-curated, physically re-fetched Mestre Notion source fields (with UUID/date), scientific pair comparisons, source exclusions, read-only audit of R204 primary SQLite events, resource/target statistics, and a prospective item-interoperability audit. The historic C13, R200, R204, C04–C12, source pages, and SQLite files are **not copied or modified**. All participant/sample fields remain Mestre-only.

## Primary external archives (read-only required for full replay)

- C13: `DMG_C13_COMPARADORES_HOMOGENEOS_VLAB_R200_20261020_MESTRE_ONLY.zip`, SHA-256 `78a8107755bd9fd0a1ffdb24890a603c3e7380a3eb4f077badd8fe0522a10f14`
- R201–R204: `VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip`, SHA-256 `80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2`
- Read-only metadata: `https://app.notion.com/p/3ffc2b324ede81c78726c3b9ab27073a`

## Cold replay

From the extracted C14 folder (no Notion API or network call is performed by these scripts):

```bash
python build_science_c14.py
python analyze_r204.py /absolute/path/VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip .
python build_paired_r204.py /absolute/path/VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip .
python audit_c14_independent.py .
```

`build_paired_r204.py` reads the VLAB paired JSON source records from the same frozen external R204 ZIP; the CSV `C14_R204_PAIRED_SEEDS_AND_POLICY.csv` is reproducible by re-execution. Native R204 SQLite events are read through disposable temporary copies with `mode=ro&immutable=1`; **no combat runner is ever invoked**. R204 V1 historic incorrect attack implementation is excluded, V2 and V2B remain distinct and group comparisons are by seed.

`build_science_c14.py` records direct Notion re-fetched field snapshots. Its source-field tuples are a deterministic frozen extract, not a live Notion client. All rank decisions are documentary judgments by this same Comestre; an independent second reviewer remains PENDING. The pipeline does not calibrate or use holdout samples.

Scientific claims are documented in `C14_SCIENTIFIC_PARECER.md` and `PSV_DMG_C14_MESTRE_ONLY.md`. This package doesn't canonize a rule, certify a whole phase, make VLAB runs, or establish writer/lease/ACK.
