#!/usr/bin/env python3
"""Read-only forensic arithmetic: never runs VLAB or modifies historical SQLite."""
import json,zipfile,sqlite3,os,tempfile,collections,itertools,math,csv,hashlib
from pathlib import Path
import sys
ZIP=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('/mnt/data/dmg_c13_incoming/VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip')
ROOT=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path('/mnt/data/dmg_c14_work')
ROOT.mkdir(parents=True,exist_ok=True)
Z=zipfile.ZipFile(ZIP)
RECORDS=[];RUNS=[]
for batch,subdir in [('V2','new/evidence/v2_db/'),('V2B','new/evidence/v2b_db/')]:
    names=sorted(n for n in Z.namelist() if n.startswith(subdir) and n.endswith('.sqlite'))
    assert (batch,len(names)) in [('V2',32),('V2B',8)]
    for n in names:
        b=Z.read(n); run=n.split('/')[-1].removesuffix('.sqlite')
        with tempfile.TemporaryDirectory(prefix='c14_r204_') as td:
            f=Path(td)/'native.sqlite';f.write_bytes(b)
            c=sqlite3.connect(f'file:{f}?mode=ro&immutable=1',uri=True)
            casts=[];refusals=[];rows=c.execute('SELECT seq,row_json FROM events ORDER BY seq').fetchall()
            for seq,line in rows:
                o=json.loads(line)
                if o['kind']=='R204_ACTUAL_SOURCE_MAGIC_NO_CRIT':
                    e=o['detail']['effect'];hit=bool(e['hit']);score=sum(e['attack_roll'])+e['attack_bonus']
                    assert score==e['attack_score'] and hit==(score>e['target_ca'])
                    assert e['spell_attack_test_literal']=='4d6+INT19'
                    assert e['dice_expression']=='8d6+28' and len(e['rolls'])==8
                    assert e['PA_cost']==o['detail']['PA_paid']==8
                    assert e['critical']=='NONE'
                    assert e['PA_before']-e['PA_after']==8
                    assert int(e['is_in_range']) and float(e['distance_m'])<=9
                    assert e['hp_before']-e['hp_after']==e['hp_loss_actual']
                    assert (e['hp_loss_actual']==0) or hit
                    assert (not hit and e['raw']==0 and e['net']==0 and e['hp_loss_actual']==0) or hit
                    if hit:
                        assert e['raw']==sum(e['rolls'])+28
                        assert e['rd_applied']==15 and e['net']==e['raw']-15
                        assert e['hp_loss_actual']==min(e['net'],e['hp_before'])
                        assert e['overkill']==e['net']-e['hp_loss_actual']
                    entry={'batch':batch,'run_id':run,'seed':int(run.split('_S')[1].split('_')[0]),'initial_distance':('9.5' if 'DIST9p5' in run else '9'), 'policy':('CAST_WHEN_IN_RANGE' if 'CAST_WHEN_IN_RANGE' in run else 'NEVER_CAST_CONTROL'), 'seq':seq,'roll_score':score, 'hit':int(hit),'raw':e['raw'],'net':e['net'],'hp_actual':e['hp_loss_actual'],'overkill':e['overkill'],'pa':e['PA_cost'],'distance_at_cast':e['distance_m'],'round':o['detail'].get('next_turn',{}).get('round')}
                    RECORDS.append(entry);casts.append(entry)
                elif o['kind']=='R204_SPATIAL_SPELL_REJECT_OR_DECLINE':
                    if o['detail'].get('reason')=='OUTSIDE_9M':
                        assert o['payload']['PA_spent']==0
                        refusals.append({'run':run,'seq':seq,'reason':'OUTSIDE_9M','distance':o['payload'].get('distance_m')})
            c.close()
        RUNS.append({'batch':batch,'run_id':run,'seed':int(run.split('_S')[1].split('_')[0]), 'initial_distance':('9.5' if 'DIST9p5' in run else '9'), 'policy':('CAST_WHEN_IN_RANGE' if 'CAST_WHEN_IN_RANGE' in run else 'NEVER_CAST_CONTROL'), 'db_sha256':hashlib.sha256(b).hexdigest(), 'cast_count':len(casts),'hits':sum(x['hit'] for x in casts),'pa':sum(x['pa'] for x in casts),'hp_actual':sum(x['hp_actual'] for x in casts),'overkill':sum(x['overkill'] for x in casts),'range_refusals':len(refusals),'sqlite_commits':len(rows)})
for batch in ['V2','V2B','V2+V2B']:
    rr=[r for r in RUNS if batch=='V2+V2B' or r['batch']==batch];cr=[r for r in RECORDS if batch=='V2+V2B' or r['batch']==batch]
    cases=[r for r in rr if r['policy']=='CAST_WHEN_IN_RANGE']
    hits=sum(x['hit'] for x in cr)
    print(batch,'ALL RUNS',len(rr),'CAST POLICY',len(cases),'CASTS',len(cr),'HITS',hits,'hit%',round(100*hits/len(cr),3),'HP',sum(x['hp_actual'] for x in cr),'PA',sum(x['pa'] for x in cr),'GROSS ON HIT',sum(x['raw'] for x in cr),'NET',sum(x['net'] for x in cr),'OVERKILL',sum(x['overkill'] for x in cr),'REFUSALS',sum(x['range_refusals'] for x in rr),'COMMITs',sum(x['sqlite_commits'] for x in rr))
# exact theoretical model: distribution of sum of four d6 and on-hit damage distribution with 8d6
outcomes=collections.Counter(sum(dice)+19 for dice in itertools.product(range(1,7),repeat=4))
p_hit=sum(n for score,n in outcomes.items() if score>34)/1296
onhit_mean=8*3.5+28
post=onhit_mean-15
print('MATH',p_hit,'onhit_gross',onhit_mean,'post_rd',post,'per_cast_expected',p_hit*post,'pa_per_hit_ideal',8/p_hit,'hp_per_pa_model',p_hit*post/8)
ROOT.joinpath('C14_R204_SPELL_EVENTS_V2_V2B.csv').write_text('',encoding='utf-8')
for dest,data in [('C14_R204_SPELL_EVENTS_V2_V2B.csv',RECORDS),('C14_R204_RUNS_READONLY.csv',RUNS)]:
    with (ROOT/dest).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
with (ROOT/'C14_R204_SCIENTIFIC_SUMMARY.json').open('w',encoding='utf-8') as f:
    json.dump({'source_zip_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'batch_run_counts':{'V2':32,'V2B':8},'total_casts':len(RECORDS),'hits':sum(x['hit'] for x in RECORDS),'pa':sum(x['pa'] for x in RECORDS),'actual_hp':sum(x['hp_actual'] for x in RECORDS),'gross_dmg_on_hits':sum(x['raw'] for x in RECORDS),'net_on_hit':sum(x['net'] for x in RECORDS),'overkill':sum(x['overkill'] for x in RECORDS),'refusals':sum(x['range_refusals'] for x in RUNS),'p_hit_exact':p_hit,'expected_onhit_gross':onhit_mean,'expected_after_rd_per_hit':post,'expected_after_rd_per_admitted_cast':p_hit*post,'per_seed_not_independent':True,'test_only':True},f,ensure_ascii=False,indent=2)
print('WROTE',len(RECORDS),'EVENTS',len(RUNS),'RUNS')
