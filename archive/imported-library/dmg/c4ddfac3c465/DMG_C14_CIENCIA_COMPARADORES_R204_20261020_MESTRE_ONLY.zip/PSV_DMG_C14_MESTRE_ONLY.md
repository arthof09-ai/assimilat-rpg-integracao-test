# PSV — DMG C14 | Continuidade científica local

**AS-OF:** 2026-10-20 · **OP:** `OP-DMG-CORPUS-EMP-01` · **MESTRE-SIDE** · **Baseline:** DMG-RANK-01 v1.1 inalterada · **F0:** 4/8 · **Produção:** HOLD.

**ANTES:** C13 material recuperado e autenticado, comparações Sussurro/Hidrargos e física R200; R204 sem análise DMG de eventos nativos. **DEPOIS:** C14 com duas famílias adicionais Aetheria/Raposa e exclusão negativa Wyvern; classificação documental de Sussurro/Hidrargos; análise dos 40 SQLite corrigidos da magia R204 (sem rerun ou escrita) e demonstração de pseudorreplicação e custo/dano; parecer de interoperabilidade física prospectiva sem recalibrar DMG-RANK.

## Resultados prioritários

1. **Corpus:** 12 páginas-folha numéricas em 4 famílias, **16 ocorrências**, **7 definições únicas**. Aetheria e Raposa estão fora da matriz C13, mas Raposa Bronze5 já aparecia no C05/C11; seis folhas negativas Wyvern excluídas por habilidades ofensivas sem expressão numérica. Não há reivindicação de amostra populacional nem nova certidão A6.
2. **Ciência:** Aetheria ON2→ON4 Titã: Canto171→247,5 (+76,5 = dados33,5 + fixo3 + INT40) e Lâminas158→230,5 (+72,5 = dados29,5 + fixo3 + INT40). Compare como *intrafamília exploratório*, não rank isolado: Titã, PA/ação/RE ainda incompletos. Raposa B5 Soco23,5→folha P5 Soco63,5 por FOR+40, mas **corpo da suposta P5 permanece B5**, logo excluída da progressão estrita. Sussurro Prata5→Ouro1 −21 (dados−2/INT−19) continua dado local, não regra universal; Hidrargos notas /161,/209,/295 têm significado incerto.
3. **VLAB R204 magia:** ZIP externo original recuperado SHA `80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2`, 281/281 hashes e CRC PASS. V1 24 lutas com acerto errado **excluídas**. V2 32 lutas, 116 conjurações/54 hits, 2214 HP, 928 PA; V2B 8 lutas dirigidas, 68 conjurações/27 hits, 1108 HP, 544 PA e 4 recusas a 9,5m sem custo. Total descritivo corrigido **40 lutas, 184 casts, 81 hits, 3380 pós-RD, 3322 HP, 58 overkill, 1472 PA**.
4. **Distribuição:** `4d6+19 > CA34` = **435/1296=33,56%**; `8d6+28` E bruto56, pós-RD LAB15 E=41 por acerto, E=13,7616 por conjuração admitida. Observado **44,02% hits**, **18,05 HP/cast**, **2,26 HP/PA**; não são estimativas populacionais. As oito seeds da V2 repetem trajetórias idênticas em 9m e9,5m; a V2B escolhe seeds especiais; apenas **12 seeds únicas**, unidades correlacionadas. V2 mudou vencedor em duas cenas que representam uma mesma seed, não duas evidências independentes. Nenhum combate VLAB reexecutado.
5. **Interop:** chassi classificado `NdS×fator`, físico distinto das camadas mágicas e do portador; orçamento do efeito/ação §22 inclui *todas* parcelas intrínsecas, não se adicionam dois orçamentos completos. Exemplo TEST espada Prata3d8 E=13,5 + rider1d4 E=2,5 ⇒ pacote E=16, não outro efeito Prata completo automaticamente. DMG-RANK §5 não exclusivamente mágica; pendência RI/RE/FIP pelo Atlas/REC.

## Fases, riscos e próximo passo

**F0–F18:** F0 formal4/8; F1–F12 estudos locais sem promoção de fase; F13–F18 HOLD/não executadas. **D0–D9:** cobertura global não certificada. **A5/A7/A8:** sem liberação nova; **A6-571**, L002/L003, R162/R169 preservados. **R156 UNKNOWN_EFFECT / R138 HOLD.** **E01–E24:** não certificadas globalmente; segundo revisor independente PENDING, holdout antigo não usado para calibrar coeficiente.

**LAST-VERIFIED-UNIT:** C14, matriz documental + R204 nativo corrigido. **FIRST-PENDING:** pares de mesma habilidade e RN/RE mecanicamente concordantes **sem Titã**; segundo coder; novas seeds R204 pré-registradas com unidade amostral por seed. **NO-REPEAT:** C04–C13, R200/R204 e SQLite históricos não modificados; nenhum motor, OP ou norma duplicado.

**CONFLICTS:** Sussurro O5 título/corpo; Hidrargos variantes superiores e notas slash; Raposa Prata5 título/corpo; Aetheria RE/PA e Titã; Wyvern sem dados ofensivos; RD mista ainda indefinida.

**NEXT-5:** buscar pares de rank estrito; verificar habilidade com custo/acerto/frequência em Aetheria; encaminhar conflitos das variantes ao Mestre; solicitar nova coorte VLAB sem pseudorreplicação; consensuar física/RI/RE/FIP no processo competente. **TARGET-REMAINDER:** F0–F18, D0–D9, E01–E24, A5/A7/A8 e corpus não recenseado.

**AUTHORITY/WRITER:** nenhum writer/lease/epoch/fencing/ACK herdado; nenhum original canônico, Party, O Primeiro ou SQLite escrito. **NAC-PASS-02:** PASS técnico local sujeito ao check final de pacote/readback; homologação e produção HOLD. **Decisão científica:** manter DMG-RANK-01 v1.1 até evidência de comparação mais forte, não criar v2 artificial.

Parecer integral: `C14_SCIENTIFIC_PARECER_MESTRE_ONLY.md`. Evidências CSV, scripts, auditor independente e manifesto estão no ZIP C14, com R204 externo como dependência read-only (sem sua cópia).
