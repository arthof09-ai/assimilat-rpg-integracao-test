#!/usr/bin/env python3
"""Independent math and consistency readback, without importing C14 analysis modules."""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import product
import csv,json,sys,hashlib
R=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
load=lambda p:list(csv.DictReader(open(R/p,encoding='utf-8',newline='')))
source=load('C14_SOURCE_CLASSIFICATION_AND_EFFECTS.csv')
pairs=load('C14_PAIRED_DECOMPOSITIONS.csv')
events=load('C14_R204_SPELL_EVENTS_V2_V2B.csv')
runs=load('C14_R204_RUNS_READONLY.csv')
arms=load('C14_PROSPECTIVE_ARMS_COMPATIBILITY.csv')
assert len(source)==16 and len({r['source_uuid'] for r in source})==12 and len({(r['family'],r['effect']) for r in source})==7
assert len(runs)==40 and len(events)==184
# Oracle parses source dice as a roll polynomial; independent from builder's exact arithmetic.
for row in source:
    dice=row['dice_pool'].split('+')
    total=Fraction(0,1);variance=Fraction(0,1)
    minroll=0;maxroll=0
    for term in dice:
        n,s=map(int,term.split('d'))
        total+=Fraction(n*(s+1),2);variance+=Fraction(n*(s*s-1),12);minroll+=n;maxroll+=n*s
    gross=total+int(row['fixed_nonattribute_mean'])+int(row['external_attribute'])
    assert gross==Fraction(str(row['gross_mean']))
    assert float(variance)==float(row['variance_dice']) or abs(float(variance)-float(row['variance_dice']))<1e-8
    assert int(row['gross_min'])==minroll+int(row['fixed_nonattribute_mean'])+int(row['external_attribute'])
    assert int(row['gross_max'])==maxroll+int(row['fixed_nonattribute_mean'])+int(row['external_attribute'])
for p in pairs:
    from_row=next(r for r in source if r['source_uuid']==p['source_from_uuid'] and r['effect']==p['effect'])
    to_row=next(r for r in source if r['source_uuid']==p['source_to_uuid'] and r['effect']==p['effect'])
    delta=Fraction(str(to_row['gross_mean']))-Fraction(str(from_row['gross_mean']))
    assert delta==Fraction(str(p['total_difference']))
    assert delta==sum(Fraction(str(p[k])) for k in ['difference_intrinsic_dice','difference_intrinsic_fixed','difference_external_attr'])
for a in arms:
    n,s=map(int,a['base_dice'].split('d'))
    k=int(a['new_physical_dice'].split('d')[0])//n
    assert Fraction(str(a['physical_mean']))==Fraction(n*k*(s+1),2)
# Exact combinatorial count, not a normal approx or simulation.
c=Counter(sum(rolls)+19 for rolls in product(range(1,7),repeat=4))
assert sum(c.values())==1296
p=Fraction(sum(freq for score,freq in c.items() if score>34),1296)
assert p==Fraction(435,1296)
assert Fraction(8*7,1)-15==41
assert p*41==Fraction(17835,1296)
for batch,nb,nc,nh,pa,hp,net,over,rej in [('V2',32,116,54,928,2214,2248,34,0),('V2B',8,68,27,544,1108,1132,24,4)]:
    q=[e for e in events if e['batch']==batch]
    r=[e for e in runs if e['batch']==batch]
    assert len(r)==nb and len(q)==nc and sum(int(x['hit']) for x in q)==nh
    assert sum(int(x['pa']) for x in q)==pa and sum(int(x['hp_actual']) for x in q)==hp
    assert sum(int(x['net']) for x in q)==net and sum(int(x['overkill']) for x in q)==over
    assert sum(int(x['range_refusals']) for x in r)==rej
    assert all(int(x['pa'])==8 and ((int(x['roll_score'])>34)==bool(int(x['hit']))) for x in q)
    assert all(int(x['net'])-int(x['hp_actual'])==int(x['overkill']) for x in q)
# Avoid pseudoreplication. V2 paired 9 and 9.5 streams have identical outcomes.
group=defaultdict(dict)
for e in events:
    if e['batch']!='V2':continue
    group[e['seed']].setdefault(e['initial_distance'],[]).append(tuple(e[k] for k in ['roll_score','hit','raw','net','hp_actual','overkill']))
assert len(group)==8 and all(len(x)==2 and len(set(map(tuple,x.values())))==1 for x in group.values())
# V2B 9.5m refusals are confined to four directed run records, not casts.
ref=[r for r in runs if r['batch']=='V2B' and int(r['range_refusals'])>0]
assert len(ref)==4 and all(r['initial_distance']=='9.5' for r in ref)
assert sum(int(x['hp_actual']) for x in events)==3322
assert sum(int(x['net']) for x in events)==3380
assert sum(int(x['overkill']) for x in events)==58
assert sum(int(x['pa']) for x in events)==1472
out={'result':'PASS_LOCAL_INDEPENDENT_MATH_AND_COHORT_READBACK','as_of':'2026-10-20','source_rows':len(source),'source_pages':len({r['source_uuid'] for r in source}),'definitions':len({(r['family'],r['effect']) for r in source}),'pairs':len(pairs),'v2batches':{'V2':32,'V2B':8},'casts':len(events),'hit_count':sum(int(x['hit']) for x in events),'hit_probability_exact':f'{p.numerator}/{p.denominator}','v2_same_seed_duplicate_distance_streams':8,'refusal_zero_pa':4,'external_second_reviewer':'PENDING','pass_scope':'arithmetic, parsed-native-event reconciliation, and source-record internal consistency; not source-independent second coder and not scientific phase gate'}
(R/'C14_INDEPENDENT_RECONCILIATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
