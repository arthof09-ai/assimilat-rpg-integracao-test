# PSV — DMG C14 | Parecer científico: classificação, família, dano efetivo e magia R204

**AS-OF:** 2026-10-20 · **OPERATION:** `OP-DMG-CORPUS-EMP-01` · **MESTRE-SIDE ONLY** · **BASELINE:** DMG-RANK-01 v1.1, vigente e intocada · **F0:** 4/8 · **PRODUÇÃO:** HOLD.

## 1. Perguntas e avanço ANTES → DEPOIS

**ANTES:** C13 autenticado (ZIP SHA-256 `78a8107755bd9fd0a1ffdb24890a603c3e7380a3eb4f077badd8fe0522a10f14`), seis definições intrafamília, 14 folhas de fontes selecionadas, achados exploratórios Sussurro/Hidrargos e análise física R200; R204 ainda não tratado pelo DMG em nível de evento nativo.

**DEPOIS:** duas famílias adicionais à matriz C13 (Aetheria e Raposa Flamejante), quatro comparações de família/camada explicitamente elegíveis ou excluídas; adjudicação documental de Sussurro/Hidrargos sem retcon; seis variantes negativas Wyvern excluídas como dano não quantificado; **40 SQLite R204 corrigidos inspecionados em cópias read-only, 184 conjurações reconciliadas** e uma descoberta de pseudorreplicação da V2; matriz numérica prospectiva físico/efeito/portador. Nenhum coeficiente da DMG-RANK foi recalibrado.

### 1.1. Denominador dessa unidade, sem misturar entidades

- Famílias numéricas examinadas: **4** (duas reutilizadas C13: Sussurro, Hidrargos; duas expandidas fora da matriz C13: Aetheria, Raposa Flamejante).
- Páginas-folha numericamente modeladas: **12 UUIDs**, não 16 amostras independentes; registros de ocorrência de fórmula: **16**; definições de habilidade por família/nome: **7**. Subdivisão: Sussurro 4 folhas/4 ocorrências/1 definição, Hidrargos 3/3/1, Aetheria 2/4/2, Raposa 3/5/3.
- Uma quinta família negativa, **Wyvern**, com seis folhas fisicamente lidas e habilidades ofensivas apenas qualitativas; seus `d4/d6/d8` de drops são **fora de escopo de dano de Vida**. Seis exclusões, não seis fórmulas.
- Novas páginas em relação à **matriz local C13**: cinco folhas de Aetheria e Raposa (duas Aetheria, três Raposa), sem afirmar descoberta global. Raposa Bronze 5 já constava historicamente no C05/C11; não é fonte globalmente nova.
- Comparações analíticas novas: dois pares Aetheria, um par Raposa com conflito, mais o par Sussurro readjudicado (não vendido como nova definição). A mesma habilidade observada em várias versões não multiplica N de definições.
- Coorte R204: 24 V1 históricas incorretas **excluídas da inferência do mecanismo corrigido**, 32 V2 + 8 V2B **corrigidas, separadas**, 40 bancos lidos, 184 conjurações admitidas, quatro preflights recusados, doze seeds distintas (oito V2 e quatro V2B, não 40 seeds independentes).
- A6=571 UUIDs é histórico estrutural sem censo global de dano; L002/L003 não têm reconciliação binária completa. **D0–D9 global sem fechamento certificado.** Nenhum progresso formal de F0–F18 atribuído a este delta.

## 2. Adjudicação sem alteração da fonte

Regra de decisão local: **CONFIRMADA_LOCALMENTE** significa título e corpo concordantes no rank da variante, não RE certificado; **CONFLITANTE** quando há divergência literal do título com o corpo; **INDETERMINADA** quando falta dado; **EXPLORATÓRIA** significa fórmula quantificável mas entrega, custos, variante ou rank de efeito impedem inferência normativa; **EXCLUÍDA_STRICT** não entra na análise estrita de rank. Pasta ancestral de família (por exemplo Ouro 5) pode identificar a colocação da raiz, não necessariamente a classificação de cada folha. Codificação por segundo pesquisador independente: **PENDENTE**.

| Família / folha | Rank título | Rank corpo | Raiz/ancestral | Estado RN local | Fórmula | Admissibilidade |
|---|---|---|---|---|---|---|
| Sussurro `56ac...` | Prata 1 | Prata 1 | Ouro 5 · 8 | Confirmada localmente | `1d6+INT30` | Exploratória intrafamília |
| Sussurro `5e9c...` | Prata 5 | Prata 5 | Ouro 5 · 8 | Confirmada localmente | `2d6+INT45` | Exploratória; 5 PA escrito |
| Sussurro `442c...` | Ouro 1 | Ouro 1 | Ouro 5 · 8 | Confirmada localmente | `2d4+INT26` | Exploratória; custo não publicado |
| Sussurro `597c...` | Ouro 5 | Ouro 1 | Ouro 5 · 8 | **Conflitante** | `2d4+INT40` | **Excluída strict Ouro 5** |
| Hidrargos `b85c...` | Ouro 4 Titã | Ouro 4 | Ouro 4 | Confirmada localmente | `6d12+120 /161` | Exploratória, barra ambígua |
| Hidrargos `bc7c...` | Ouro 5 Titã | Ouro 4 | Ouro 4 | **Conflitante** | `10d12+145 /209` | **Excluída strict Ouro 5** |
| Hidrargos `31ec...` | Ouro Negro 1 Titã | Ouro 4 | Ouro 4 | **Conflitante** | `19d12+173 /295` | **Excluída strict ON1** |
| Aetheria `4acc...` | Ouro Negro 2 | Ouro Negro 2 | Ouro Negro 4 · 1 | Confirmada localmente | dois efeitos numéricos | Exploratória, RE não publicado |
| Aetheria `bc6c...` | Ouro Negro 4 Titã | Ouro Negro 4 | Ouro Negro 4 · 1 | Confirmada localmente com Titã | dois efeitos numéricos | Exploratória, Titã confunde evolução |
| Raposa `4d0c...` | Bronze 2 | Bronze 2 | Prata 5 · 2 | Confirmada localmente | `1d4+5` | Outras habilidades, não parear com Soco |
| Raposa `529c...` | Bronze 5 | Bronze 5 | Prata 5 · 2 | Confirmada localmente | `1d4`, `1d6+FOR20` | Exploratória local |
| Raposa `2f3c...` | Prata 5 | Bronze 5 | Prata 5 · 2 | **Conflitante** | `1d4`, `1d6+FOR60` | **Excluída strict Prata 5** |

**Fórmulas verificadas** são expressões legíveis; não é permitido reinterpretar atributos por RE. O número depois de barra nas Mordidas Hidrargos (`/161`, `/209`, `/295`) carece de rótulo de média, realização ou dano final. As médias de fórmula são respectivamente **159, 210 e 296,5**; diferenças **+2, −1, −1,5** da anotação. A barra não é automaticamente a média nem prova aritmética de dano executado.

**Sussurro:** a queda Prata5→Ouro1 continua **−21 bruto**, repartida em dados **−2** e INT **−19**; elegibilidade normativa inter-rank ainda exploratória por ausência de custos/RE e organização familiar. **Não corrigir a ficha**; se o Mestre for adjudicar, primeiro determinar o significado da pasta ancestral e a variante Ouro 5 com corpo Ouro 1. **Hidrargos:** solicitar rótulo das anotações, confirmar a classificação de cada folha, não inferir média pela barra.

## 3. Duas famílias adicionais, discriminantes

### Aetheria (Vento/Luz, duas habilidades idênticas por nome nos dois perfis)

| Ataque | Ouro Negro 2 | Ouro Negro 4 Titã | Δ total | Δ dados | Δ fixo | Δ INT |
|---|---:|---:|---:|---:|---:|---:|
| Canto das Alturas — área, chance de derrubar | `14d6+42+INT80` = **171** | `15d10+45+INT120` = **247,5** | **+76,5** | +33,5 | +3 | +40 |
| Lâminas de Luz Prismática — linha, sangramento/mobilidade | `12d6+36+INT80` = **158** | `13d10+39+INT120` = **230,5** | **+72,5** | +29,5 | +3 | +40 |

Verificado: ambas as folhas possuem rank de corpo coerente com título; a superior **é Titã**. Em cada ataque, o bônus de INT explica **52,29%** (Canto) e **55,17%** (Lâminas) do crescimento, e os dados explicam parcela relevante de **43,79%** e **40,69%**; +3 fixos respondem pelo restante. Os custos, acerto, PA, número de alvos e RE autônomo não estão completos. Portanto, **H1 “crescimento exclusivamente/predominantemente por atributos em todas as famílias” não é universal**; H1 restrita “atributos explicam grande parcela em muitas famílias” ainda é compatível. Não atribuir FIP nem concluir desequilíbrio contra outra natureza/entrega.

### Raposa Flamejante (controle de contaminação)

A variante Bronze 5 documenta `Soco 1d6+FOR20`, E=23,5. Uma folha de título Prata 5 usa o **mesmo `1d6`**, mas `FOR60`, E=63,5; o corpo dessa folha continua **Bronze 5**. O incremento bruto **+40** vem 100% do atributo (dados estáveis), mas o par **não valida crescimento Bronze5→Prata5** e não entra na série strict. A variante Bronze 2 possui *Bola de Fogo* `1d4+5`; não comparar como se fosse o mesmo Soco. Esse é um exemplo independente de formulações onde soma bruta mascara o verdadeiro orçamento intrínseco.

### Controle negativo Wyvern

Seis folhas da mesma família percorrem Ouro 1 até Lendário 4, mas *Garras Afiadas* e *Sopro de Vento* são qualitativos; os dados nos drops pertencem a materiais e **não a dano**. O correto é **seis fontes de família inspecionadas e zero efeitos numéricos de Vida admitidos**, não criar dados para “preencher” a progressão. Muitas folhas têm corpo Lendário apesar do título inferior: documentação com conflito, não amostra estrita.

## 4. VLAB R204 — extração de evento nativo corrigido

Fontes: página `https://app.notion.com/p/3ffc2b324ede81c78726c3b9ab27073a`, ONG fonte `https://app.notion.com/p/2b6c2b324ede82a2b415019eae21eaf5`, Lobo `https://app.notion.com/p/be5c2b324ede832e8b7a81c5460571c1`. ZIP externo recuperado `VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip`, SHA-256 `80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2`, **282 entradas, 281 SHA/281 CRC PASS**. Leitura de 40 SQLite via cópias `mode=ro&immutable=1`, nenhuma batalha reproduzida, nenhum banco modificado.

**EXCLUSÃO HISTÓRICA V1:** 24 combates V1 assumiram acerto direto incorretamente. Mantidos na história, **não utilizados na estimativa de acerto corrigido**, tampouco somados aos 40 corrigidos para estimar dano por tentativa.

**V2:** 32 lutas (16 `CAST_WHEN_IN_RANGE` e 16 `NEVER_CAST_CONTROL`), oito seeds, duas distâncias por seed. Somente as 16 lutas de política de conjuração produziram os 116 casts; 54 hits (46,55%), pós-RD 2.248, Vida 2.214, overkill 34, PA 928. **As séries de 9m e 9,5m são idênticas para cada uma das oito seeds**, porque Lobo se moveu primeiro; os 116 casts não são 116 observações independentes. Em oito seeds, **uma seed (`20401205`) muda de vencedor quando conjura**, e aparece duas vezes por distância. Nenhum combate controle lançou a magia.

**V2B:** oito lutas com quatro seeds propositalmente selecionadas para Ong agir primeiro; duas distâncias por seed. 68 casts, 27 hits (39,71%), pós-RD 1.132, Vida 1.108, overkill 24, PA 544, quatro preflights `OUTSIDE_9M` exatamente a 9,5m **sem PA**, antes de Lobo aproximar. **V2B não é amostra aleatória** e não pode validar a taxa populacional de vitória/acerto.

**TOTAL descritivo corrigido V2+V2B:** 40 lutas, **184 conjurações admitidas**, **81 hits** (44,02% dos casts), **3.380 pós-RD** = **3.322 Vida efetiva + 58 overkill**, **1.472 PA** = 8 PA/cast. Observado **18,05 Vida por cast**, **2,26 Vida/PA**, **18,17 PA/hit**. Esses valores são medidas descritivas de uma microcoorte TEST, não coeficientes universais. Cada cast é dependente da cena/seed e pode apresentar viés de seleção temporal.

**DISTRIBUIÇÃO EXATA** do ataque `4d6+INT19` contra CA 34 com empate favorável à defesa: `P(acerto)=435/1296=33,5648%`. Dano `8d6+28` = min36, máximo76, média56. Na política R204 de RD15 aplicada ao evento, o dano **por hit** está entre21–61, média41; a expectativa **pós-RD por conjuração admitida antes de overkill** é `41*(435/1296)=13,761574`, sem crítico mágico. 8 PA são debitados em uma conjuração admitida mesmo se falha; 9,5m fora de alcance **não é conjuração admitida**. PA teórico por acerto `8/(435/1296)=23,83` em ensaio ideal independente, somente referência.

**DIFERENÇA TEÓRICO vs OBSERVADO:** 33,56% de acerto matemático vs 44,02% de acerto observado em 184 casts, porém 12 seeds distintas, uma das políticas V2 repete os mesmos fluxos entre distâncias e a V2B é escolhida por condição. Não realizar um teste binomial de 184 observações independentes nem atribuir o desvio à norma de dano sem pesquisa. Para identificar viés de RNG, política, condicionamento ou duração, solicitar ao VLAB **NOVAS seeds pré-registradas**, com unidade estatística por combate/seed e cronologia/estado por tentativa.

**Contraste físico R200:** Orc Prata1 `2d6+22` não supera CA34, logo o golpe físico tem dano ordinário esperado por tentativa zero nesse confronto, embora o chassi da espada Prata tenha dano bruto. Essa é uma comparação de *mecanismos de entrega* distinta, não uma comparação homogênea de efeitos ou uma luta DMG executada.

## 5. Interoperabilidade prospectiva física e classificada

Autoridades: Mestre `https://app.notion.com/p/3ffc2b324ede81c5a5c3d56cc6a29f84`, DMG-RANK §§5,8,13,22 `https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e`, REC-MOD-ARM-01 `https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649`.

**Regra Mestre de novos chassis:** `NdS` multiplica N por Comum1, Bronze2, Prata3, Ouro4, Ouro Negro5, Lendário6. Uma espada Prata `3d8` dá E=13,5 e uma arma brutal Prata `6d6` dá E=21, **sem FF ou usuário**. Ainda não é prova de publicação normativa em todas as autoridades oficiais.

**Conciliação:** o chassi físico classificado é uma parcela do dano intrínseco físico; efeito/ação inteira deve ter orçamento único conforme §22 — incluindo físico+magia, riders, ticks, ação/área. Exemplo **TEST** espada Prata `3d8` + efeito numérico adicional `1d4` faz E=16 no conjunto antes de bônus externos, **não** 13,5 + um “efeito Prata completo” já composto por dano físico (dupla contagem). Se o efeito é técnica separada e é explicitamente outro uso/ação, comparar seu delta e o gasto de PA/frequência sem incluí-lo permanentemente em cada golpe. Exemplo sem magia: `3d8` continua presente no estado SEM encantamento. Exemplo de portador: `+FOR` ou `+FF` entra somente quando autorizado e não estiver incluído na expressão equipada.

**Pendência normativa precisa:** delimitar, junto às autoridades DMG/REC/Atlas, se RI mede o pacote total do item físico classificado ou se uma habilidade adicional tem RE/FIP autônomo, e como contabilizar por uso. Não criar hierarquia concorrente, não impor o piso de banda RE §5 ao chassi físico isolado, não tratar a banda §5 como exclusivamente mágica, não duplicar orçamentos §22 e não retcon de armas existentes. Os doze cenários de chassi estão na planilha CSV, com exemplos Prata TEST.

## 6. Hipóteses, qualidade e recomendações

- **H1 atributos dominam?** Apoio local para maior contribuição de INT em Aetheria e FOR em Raposa, mas os dados Aetheria também são relevantes (Canto +33,5; Lâminas +29,5). Generalização universal: **não sustentada**. Próximo discriminante: mesmo RE/entrega, sem Titã, ranks adjacentes com par físico confirmado.
- **H2 diferenças internas?** Em Aetheria ON2, Canto171 vs Lâminas158; ON4 Titã 247,5 vs230,5. Naturezas e entregas diferentes (área/controle versus linha/sangramento), não concluir força relativa só pelo bruto. Próximo: ação, PA, hit/save e alvos efetivos.
- **H3 FIP:** falta RE/FIP da habilidade como autoridade e condições de pacote completo. **Não há novo PASS**.
- **H4 eficiência PA:** R204 corrigida fornece 184 gastos legítimos, hit, pós-RD, Vida e overkill; mostra discordância de cálculo ideal e realização de microcoorte. **Avanço observacional delimitado**, não tarifa universal PA/dano.
- **H5 contaminação documental:** Sussurro O5, Hidrargos O5/ON1 e Raposa P5 têm conflitos título/corpo; excluídos da calibração estrita, confirmando concretamente o risco de falso padrão de progressão. Observação negativa Wyvern evita contar drops como dano.
- **H6 chassi físico:** separação de três camadas compatível como interpretação de trabalho com §22; **integração normativa requer decisão**, nenhuma alteração efetuada.

**Q-COVERAGE:** parcial; raiz de elementos/famílias visitadas sob amostragem, D0 global não fechado. **Q-CODEBOOK:** rastreabilidade de UUID/corpo/título/ancestral em CSV; double-coder independente PENDING. **Q-MATH:** reprodução por script+oráculo separado PASS. **Q-TARGET:** R204 ataques, acertos, RD, PA, HP e overkill diferenciados. **Q-HOLDOUT:** não calibrado novo coeficiente; holdout antigo preservado, validação cega global PENDING. **Q-REDTEAM:** controles negativos Wyvern/Raposa e pseudorreplicação V2 demonstrados; gate amplo PENDING. **Q-TRACE:** links UUID/última edição, arquivo, SHAs e notas por status. Demais gates E01–E24 não certificados.

**Decisão material recomendada:** manter **DMG-RANK-01 v1.1** até evidência suficiente; adotar **análise prospectiva por camada e entrega** como método de avaliação, sujeito à conciliação com REC/Atlas, e exigir **acerto, PA, RD, alvo e condição** ao comparar magias reais ou técnicas. Essa recomendação não publica regra nem corrige fichas.

## 7. Continuidade e delimitação de autoridade

**LAST-VERIFIED-UNIT:** C14, páginas-fonte reabertas, C13 autenticado, R204 autenticado e 40 SQLite V2/V2B inspecionados sob leitura imutável; scripts de reconstrução e hashes próprios no pacote científico.

**FIRST-PENDING:** recuperar a autoridade de classificação RE/FIP e entrega de efeitos específicos para tornar um par intrafamília comparável em rank estrito; obter segundo coder competente e nova coorte R204 não enviesada por seeds selecionadas se for estimar probabilidade populacional.

**F0–F18:** F0 **4/8**; F1–F12 resultados de pesquisa TEST exploratórios **sem PASS de fase**; F13–F18 candidata/integração normativa/produção não iniciadas ou HOLD. **D0–D9:** cobertura global/denominadores formais não certificados; indicadores locais do presente relatório não representam censo. **A5/A7/A8:** bloqueios históricos preservados, sem writer/lease/ACK adicional; **A6:** 571 UUIDs estruturais históricos não promovidos a censo. **L002/L003:** pertinência fonte-a-fonte ainda não fisicamente reconciliada. **E01–E24:** gates globais PENDING onde não há evidência independente.

**NO-REPEAT:** não alterar C04–C13 nem R200/R201–R204, nenhum motor novo, nenhum combate refeito, V1 inválida isolada, R162/R169 intocados, R156 UNKNOWN_EFFECT, R138 HOLD.

**CONFLICTS:** Hidrargos title/body/nota slash; Sussurro Ouro5 title/body e hierarquia de família; Raposa Prata5 title/body; Aetheria Titã e efeito RE não independente; Wyvern sem magnitude; RD por componentes e dano misto continuam sem adjudicação. **HOLDOUT** não vazado para calibração (zero candidata nova); revisão independente fonte-semantics PENDING.

**NEXT-5:** (1) conseguir duas novas famílias de mesma habilidade com rank local concordante e sem Titã; (2) exigir fonte explícita RE/FIP/acerto/custo de Aetheria para separar entrega; (3) preparar conflito específico título/corpo de Raposa/Hidrargos/Sussurro ao Mestre em procedimento competente, sem retcon; (4) solicitar ao VLAB seed-split pré-registrado para magia corrigida, evitando duplicidade de fluxos; (5) validar nova arma física por RI/RE/FIP em coordenação com REC/PA, sem alterar a norma v1.1.

**TARGET-REMAINDER:** pesquisa F0–F18, gates E01–E24, D0–D9, A5/A7/A8, L002/L003, mais famílias de ataque/controle/PA e validação independente. **WRITER/AUTHORITY:** nenhum writer, lease, epoch, fencing ou ACK herdado; somente produção de artefatos TEST MESTRE-SIDE na Biblioteca autorizada, sem escrita em Notion canônico, Party/O Primeiro, fichas ou SQLite. **NAC-PASS-02:** PASS apenas local de integridade/aritimética/reprodução/readback; homologação científica independente, mudança normativa e produção: HOLD.
