from pathlib import Path
import zipfile,json,csv,sys
R=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path(__file__).resolve().parent
R.mkdir(parents=True,exist_ok=True)
Z=zipfile.ZipFile(Path(sys.argv[1]).resolve() if len(sys.argv)>1 else '/mnt/data/dmg_c13_incoming/VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip')
allrows=[]
for batch,n in [('V2','new/evidence/R204_V2_LIVE_MAGIC_RESULTS.json'),('V2B','new/evidence/R204_V2B_LIVE_MAGIC_RESULTS.json')]:
  entries=json.loads(Z.read(n))
  lookup={(e['seed'],e['initial_distance_m'],e['policy']):e for e in entries}
  for e in entries:
    if e['policy']!='CAST_WHEN_IN_RANGE':continue
    control=lookup.get((e['seed'],e['initial_distance_m'],'NEVER_CAST_CONTROL'))
    allrows.append({'cohort':batch,'seed':e['seed'],'initial_distance_m':e['initial_distance_m'],'cast_winner':e['winner'],'no_cast_control_winner':control['winner'] if control else 'NOT_RUN_IN_V2B','paired_outcome_changed':int(control is not None and e['winner']!=control['winner']),'admitted_casts':e['spell_casts'],'pa_spent':e['PA_spell_spent'],'hp_actual':e['HP_removed_by_spell'],'preflight_refusals':e['range_refusals'],'paired_seed_not_independent':True})
with (R/'C14_R204_PAIRED_SEEDS_AND_POLICY.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.DictWriter(f,list(allrows[0]));w.writeheader();w.writerows(allrows)
print('C14 pair rows',len(allrows),'V2 outcome changes',sum(r['paired_outcome_changed'] for r in allrows),'unique V2 changed seeds',set(r['seed'] for r in allrows if r['paired_outcome_changed']))
