# DMG C15 — PARECER CIENTÍFICO | MESTRE-SIDE

**AS-OF:** 2026-10-20. **OPERATION:** `OP-DMG-CORPUS-EMP-01`. **BASELINE:** DMG-RANK-01 v1.1 inalterada. **FORMAL F0:** 4/8. **PRODUÇÃO:** HOLD. **LAST-VERIFIED-UNIT:** R204 V2/V2B reproduzida por leitura de 40 SQLite em cópias temporárias, mais triagem de quatro famílias das árvores Notion Mestre. Sem writer/lease/epoch/fencing/ACK herdado.

## ANTES → DEPOIS

ANTES C14: 184 conjurações em 40 lutas R204 corrigidas, 81 acertos e 3.322 HP retirados, mas fluxos V2 duplicados nas distâncias pareadas e observação sem unidade efetiva de inferência estimada. C14: 12 folhas de quatro famílias no estudo da época; sem parecer de calibração de probabilidade condicionado ao número de conjurações. DMG-RANK v1.1 preservada.

DEPOIS C15: 184/184 ataques mágicos reabertos e auditados desde os bancos SQLite históricos somente para leitura; oito fluxos V2 pareados 9/9,5m comprovadamente idênticos nos dados de ataque/dano; oito seeds independentes de identidade para V2, quatro seeds V2B dirigidas; análise estratificada por ordem de conjuração e por seed; 11 páginas Mestre adicionais triadas de quatro famílias; oito ocorrências de fórmula, quatro definições familiares, três folhas sem fórmula numérica; matriz de uso para novas criações com RI/RE/FIP separados e pedido experimental VLAB **PREPARADO MAS NÃO ENVIADO**.

## A — Hipótese sobre o R204 (distinguir matemática de combate)

**Fonte Ong Mefita:** https://app.notion.com/p/2b6c2b324ede82a2b415019eae21eaf5 — magia Chicote de Água, rolagem específica `4d6+INT19`, custo 8 PA, dano `8d6+28`. **Alvo:** Lobo Prata 1 https://app.notion.com/p/be5c2b324ede832e8b7a81c5460571c1, CA34 e RD15 conforme contrato do VLAB TEST. **Combate:** https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0, empate em defesa. **R204 V2/V2B:** https://app.notion.com/p/3ffc2b324ede81c78726c3b9ab27073a.

Probabilidade exata de acerto `435/1296 ≈ 33,5648%`, para rolagem `4d6+19 >34`. Dano bruto `8d6+28`, média 56; após RD15 aplicável a esta magia no contrato LAB, média 41 por hit, com piso nunca ativado porque dano bruto mínimo36; esperança `41×435/1296 ≈ 13,76157` dano pós-RD por tentativa admitida. Dano efetivo na Vida depende de HP atual do alvo; não pressupor PV40 nem vitória automática. O custo 8 PA é pago após conjuração admitida, mesmo se falhar; recusa pré-cast em 9,5m antes de aproximação é 0 PA, se a geometria realmente a impedir.

**Evidência nativa C15:** 40 arquivos SQLite V2/V2B reabertos sem executar runner nem modificar banco; 184 magias admitidas, 81 acertos, 1.472 PA, 3.380 pós-RD, 3.322 HP, 58 overkill. Cada rolagem `sum(attack_roll)+19` foi confrontada com CA34, operador `>`, resultado, custo e RD; **184/184 eventos** também reconciliados ao CSV C14. V1 inválida não admitida.

**Dependência:** em V2 as 116 conjurações físicas (54 acertos) equivalem a **58 eventos com stream diferente**, em oito seeds, quando se escolhe apenas 9m; as oito duplas de distância 9m/9,5m têm sequência idêntica para rolagem, dano e HP. As 68 conjurações V2B vêm de quatro seeds dirigidas para iniciar conjuração antes de movimento e não podem fornecer frequência populacional aleatória. Portanto, o total de 184 eventos NÃO constitui N=184 independente; 12 seeds também não são 12 seeds de mesma política de seleção.

**V2 estratificada:** primeiros três feitiços de cada seed `8/24 =33,333%`; posteriores `19/34 =55,882%`; agregado `27/58=46,552%`. As oito taxas por seed variam de 25% a 75%, média por seed 45,774% e intervalo t95 ilustrativo `[31,32%;60,22%]` (supõe seeds relativamente independentes, n=8; não é certificação estatística). A diferença posterior é observada após condicionar na manutenção do combate, duração e RNG, por isso NÃO prova viés do motor nem taxa geral de acerto maior que a combinatória exata.

**Dano V2 sem duplicar:** `1124/58=19,3793` dano pós-RD por conjuração; `1107/58=19,0862` Vida retirada por conjuração; `1124/27=41,6296` pós-RD por hit. Excesso aparente pós-RD contra p teórico `19,3793−13,7616 =5,6177`: `5,3246` é a parcela da frequência de acerto e `0,2931` da média de dano nos acertos; aproximadamente **94,8% do excesso descritivo decorre da frequência de acerto amostral**. Não é atribuição causal de viés; descarta alegação de falha clara na escala nominal dos dados com esta evidência. A distribuição de primeiros ataques, custos e RD estão coerentes nos recibos verificados.

**Resultado H4:** *calibração de dano da magia: INCONCLUSIVA para mudar v1.1*. *Aplicação do teste 4d6+19 contra CA34 nos registros: PASS local*. *Dependência por seed e stream: DEMONSTRADA*. Solicitação discriminante ao VLAB no arquivo C15_VLAB_EXPERIMENTAL_REQUEST_NOT_SENT.md (256 seeds de uma conjuração e braço separado de combate pareado), **sem envio**.

## B — Corpus novo por família (comparações estritas exigem 10 fatores)

Arquitetura consultada: árvore oficial Bestas Demoníacas, famílias de Normal, Planta e Gelo e folhas das linhagens. **Denominador desta frente:** 4 famílias, 11 páginas-folha fisicamente reabertas, 8 ocorrências de fórmula ofensiva à Vida, 4 definições família×habilidade, 3 páginas sem fórmula. Fonte já usada pelo VLAB/C14: Lobo P1; reabertura não o torna novo globalmente. 10 outras páginas não constavam do recorte de quatro famílias C14, sem prova de que sejam globalmente inéditas. Não contam como 11 novas habilidades. Título, corpo e ancestral foram confrontados; RE autônomo, FIP e ação/custo frequentemente não estão declarados. Segunda revisão classificatória por pesquisador independente PENDENTE.

**Tigre Flora, Garras de Espinhos** (fonte Planta):
- Prata3 título/corpo concordam: https://app.notion.com/p/67bc2b324ede832ba95a01a5160aa46d, `2d4+FOR41`, média 46 (dados 5, atributo 41), variância de dados 2,5; efeito adicional `envenena CD6+CON20 = CD26` documentado, sem dano adicional numérico. Comparável **como fórmula local**, RE/ação/PA não confirmados.
- Prata4 https://app.notion.com/p/5f1c2b324ede8320bcfb81725919671a corpo segue Prata3, `2d4+FOR49`, média54; Ouro2 https://app.notion.com/p/12fc2b324ede82da84a581e33f2e1d56 corpo segue Prata3, `2d4+FOR72`, média77. A média cresce 46→54→77 sem alteração de dados: +8 e +23 são só FOR, mas **NÃO** é progressão estrita de Prata→Ouro. RE e PA ausentes, CD do veneno varia CON20→21 e não vira dano calculado.

**Lobo das Cavernas, Patada:** Prata1 https://app.notion.com/p/be5c2b324ede832e8b7a81c5460571c1 tem `1d6+FOR24`, média27,5; a folha intitulada Prata5 https://app.notion.com/p/74ec2b324ede82b2a92401642e909be6 também diz Prata1 no corpo, `1d6+FOR40`, média43,5. +16 é somente FOR, comparativo de assinatura, **EXCLUÍDO** como progressão entre rank/estrelas; atributo pode já incorporar bônus `+2 FOR` da Força Ancestral, não somar de novo.

**Polvo da Floresta, Corte cerebral:** Prata1 https://app.notion.com/p/77ec2b324ede82d49662812c1e72b7b0, `2d6+INT29`, média36 (dados7, INT29), fórmula local válida; RE, PA, teste de acerto e tipo concreto do ataque não identificados. Prata3 https://app.notion.com/p/a94c2b324ede83b4a2b3018d2c8d503d e Ouro1 https://app.notion.com/p/9ddc2b324ede8366a5c981be65f440d2 sem dano numérico legível; não construir progressão por preenchimento.

**Cervídeo Glacial, Galhada:** folha Prata2 https://app.notion.com/p/929c2b324ede82ecb04201f553eaad96 `2d6+DES27` média34; folha Ouro3 https://app.notion.com/p/1fac2b324ede8311a1da01ed6a84e18b `4d6+DES54` média68. +34 contém +7 dados e +27 DES, mas os corpos publicam **Bronze** em ambas; a folha Prata5 https://app.notion.com/p/432c2b324ede8393a90501de383cbe81 tem descrição sem fórmula. Todos excluídos de inferência normativa de fronteira de rank.

**Resultado H1/H5:** assinatura mecânica em três famílias mostra heterogeneidade explicável por atributo e, em Cervídeo, por dados+atributo; classificação organizacional conflictante impede usar mudanças nominais de rank para calibrar bandas. **Zero novos pares inter-rank plenamente estritos** com RE, ação, custo e entrega confirmados nesta amostra. Isso é um resultado negativo válido, não paralisa os estudos VLAB.

## C — Critérios prospectivos de RI, RE, FIP e chassi

Autoridades Mestre READ-ONLY: DMG-RANK-01 v1.1 https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e, §4/§5/§8/§22; Atlas https://app.notion.com/p/3eec2b324ede81ea8920c52473ecc3ab; REC-MOD-ARM-01 https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649; decisão prospectiva do Mestre https://app.notion.com/p/3ffc2b324ede81c5a5c3d56cc6a29f84.

**VERIFICADO:** RI = patamar do item por poder próprio; RE = patamar de cada efeito específico; FIP = gradação interna Entrada→Ápice do mesmo RI (não é estrela pública, não se decide por dados sozinhos); RN do usuário/estrela NÃO é RE/RI. §5 abrange efeito ofensivo padrão físico OU mágico, com ação/entrega padronizadas; §22 preserva orçamento único da ação/efeito composto. Histórico explícito não recebe retroatividade automática.

**Decisão Mestre prospectiva:** novo chassi físico `NdS × fator(Comum1,Bronze2,Prata3,Ouro4,Ouro Negro5,Lendário6)` na quantidade de dados, preservando tipo. Uma espada Prata tem `3d8`, DME físico13,5, mesmo desligando efeitos mágicos.

**Casos TEST não canônicos:** espada Prata `3d8` (13,5). Se efeito adicional de 1d4 (2,5) ocorre **no mesmo golpe e como componente da mesma ação**, a média intrínseca total é 16, NÃO `13,5+16=29,5` e também NÃO duas bandas completas por efeito. Se é **ação própria**, não pode ser somado ao golpe físico sem contrato de combo. Se FOR+10 é externa e legítima, dano final condicional23,5, mas DME intrínseco do chassi permanece13,5. Se rider é elemental com RD específica não publicada, pós-RD do golpe composto permanece HOLD, embora bruto seja calculável. Nenhuma dessas imagens TEST classifica RI/RE/FIP automaticamente.

**PENDÊNCIA NORMATIVA:** como a decisão nova por classificação física integra pontuação RI e orçamento total definido no REC-MOD-ARM/DMG sem dupla contagem; quando um rider tem RE autônomo; como rank de efeitos adicionais e FIP respondem a custo/controle/bypass. Encaminhar via NAC-NORM-01 à autoridade apropriada; não editar DMG-RANK v1.1.

## D — Produtos utilizáveis para novas criações

Antes de julgar dano: (1) classificar origem/versão/status, separar RN estrela, RI, RE, FIP; (2) respeitar fórmula explícita e chassi físico prospectivo aplicável, sem retcon; (3) decompor dados intrínsecos, atributo externo, FF e condições sem duplicar; (4) declarar ação, alcance, área, controle, custo diário/por ativação e frequência; (5) para defesa admissível, exibir p(acerto), dano por hit, RD específica, dano por tentativa, HP/overkill; (6) comparar só efeitos dentro de eixo mecânico homogêneo e com número de famílias/definições, não contar níveis repetidos como N populacional; (7) confrontar banda v1.1 §5 **apenas quando RE e perfil de entrega forem comprovados**; (8) emitir VERIFICADO/INFERIDO/PROPOSTO/PENDENTE e dependência concreta. Em R204 o dado esperado por tentativa pós-RD é 13,7616 e não 56; porém v1.1 não deve ser recalibrada por uma coorte pequena, selecionada e com semântica LAB.

## E — Estado e gates

- **F0–F18:** F0 4/8 formal; F1–F12 pesquisa exploratória com contribuições localizadas e sem PASS de fase; F13–F18 não acionadas para promoção normativa/produção. **D0–D9:** dados e denominadores locais acima, cobertura global NÃO certificada; superfícies L002/L003 e grafo A6 histórico ainda precisam de reconciliação de pertinência individual.
- **E01–E24 / oito gates:** Q-MATH fonte e registros R204 PASS delimitado (184/184), Q-COVERAGE apenas recorte local e raízes parcialmente buscadas, Q-CODEBOOK segunda codificação independente PENDENTE, Q-TARGET testado localmente, Q-HOLDOUT nenhuma calibração realizada e nenhum holdout reivindicado, Q-REDTEAM candidato NOT-TESTED, Q-TRACE pacote/readback a verificar. Sem marcar garantias formalmente completas.
- **A5/A7/A8:** pendências formais mantidas, sem writer identificado para fechamento. **R156:** UNKNOWN_EFFECT preservado. **R138:** HOLD preservado. **R200/R204:** coortes distintas; V1 histórica erro. **R205:** novo pacote detectado na Biblioteca VLAB, **não misturado nem analisado neste estudo**, requer admissão própria.
- **NO-REPEAT:** C04–C14, 571 UUIDs A6, L002/L003, R162/R169, 30 bancos R200 e V1 R204 intocados. 0 combates reexecutados, 0 alterações SQLite, 0 fichas/Party/O Primeiro/regras alteradas.
- **FIRST-PENDING científico:** nova bateria de precisão com seeds independentes e no máximo uma conjuração por seed; em paralelo, encontrar pares com RE+ação+custo legitimamente completos. **NEXT-5:** (1) propor ao VLAB contrato A/B via rota competente; (2) nova árvore/famílias com efeitos completos; (3) obter segunda leitura classificatória independente; (4) examinar R205 separadamente e sem sobreposição; (5) encaminhar ponte chassi–RI–RE–FIP via NAC-NORM.
- **TARGET-REMAINDER:** F0–F18, E01–E24, oito gates, D0–D9, reconciliação A5/A7/A8 e L002/L003, holdout e candidato somente se houver fundamento.
- **AUTHORITY/WRITER:** nenhum writer/lease/epoch/fencing/ACK, nenhum envio Inbox; persistência exclusivamente Biblioteca existente se readback for realizado. **NAC-PASS-02:** PASS matemático/corpus local condicionado a verificações de pacote, HOLD para ciência global e produção.

**DECISÃO:** manter DMG-RANK-01 v1.1 intacta; não propor novos coeficientes. Os resultados fortalecem o critério de separar probabilidade e magnitude antes de calibrar dano, e de usar rank local concordante antes de inferir progressão.
