# PEDIDO CIENTÍFICO VLAB → DMG | C15 | MESTRE-SIDE | NÃO ENVIADO

**Operação de destino existente:** `OP-VLAB-FUSION-SANDBOX-01`. **Operação solicitante existente:** `OP-DMG-CORPUS-EMP-01`. **Estado:** PROPOSTO / não houve roteamento por Inbox nem ACK / sem writer, lease, epoch ou fencing.

## Problema empírico observado

No VLAB R204 V2, `4d6+INT19 > CA34` possui probabilidade exata `435/1296 = 0,3356481481`, mas a trajetória única de cada uma das oito seeds gerou 27 acertos em 58 conjurações (46,55%). Os primeiros três eventos de cada seed foram 8/24 (33,33%); os eventos tardios, 19/34 (55,88%). Os cenários 9/9,5 m das mesmas seeds em V2 reproduziram fluxos de rolagem iguais. As quatro seeds V2B foram selecionadas especificamente para iniciativa e geometria, portanto não são amostra aleatória. O DMG não atribui a diferença a erro do motor nem a dano inadequado.

## Experimento A — precisão fonte-específica com um evento por seed (prioridade)

- Pré-registrar **256 seeds novas** que não colidam com R01–R205 nem consumam RUN-IDs antigos, antes de executar ou conhecer desfechos; preservar a lista e SHA no laboratório VLAB existente. 256 oportunidades independentes dão erro-padrão aproximado de 2,95 pontos percentuais perto de p=0,3356; margem normal nominal de cerca de ±5,8 p.p. (não garantia de exatidão).
- Usar a mesma regra específica `Chicote de Água`, `4d6+19` contra CA34, RD15, dano `8d6+28`, custo 8 PA. Uma conjuração admitida por seed, alvo em alcance 9 m, sem reação adicional/bonificação desconhecida/crítico mágico, com estado inicial e ação documentados. Se a infraestrutura de combate produzir movimento ou morte antes dessa conjuração, registrar a exclusão como evento e NÃO substituir silenciosamente a seed.
- Manter a mecânica do VLAB e utilizar cópias/testes já autorizados. O executor do VLAB define a via legal de teste; isto **não** autoriza o DMG a rodar ou modificar seu motor.
- Cada recibo deve incluir seed, versão do adaptador e código, fonte/version/hash, `attack_roll=[d6,d6,d6,d6]`, soma, bônus, CA, operador de empate, hit/miss, 8 PA debitado inclusive miss, geometria, HP anterior/posterior, RD e dano, hash de evento e status do run. Não classificar como evento independente um mesmo stream copiado a outra distância.
- Estimador primário: proporção de acertos entre seeds **com uma conjuração realmente admitida** e diferença contra 435/1296; reportar exclusões e sensibilidade, sem inferir população a partir de seeds descartadas seletivamente. Auditar literalmente a regra de acerto contra recibo de cada evento.

## Experimento B — políticas, duração e seleção em combate (subsequente)

- Pré-registrar **64 seeds adicionais e distintas** para combate com políticas de conjurar/não conjurar, pareadas por seed, atributos, CA, RD e condições; registrar dois braços como medidas **pareadas**, nunca independentes. Se também variar distância 9/9,5 m, tratar essa distância como fator intra-seed. Não selecionar seeds retrospectivamente por iniciativa.
- Registrar cada rodada, ordem de iniciativa, distância antes/depois de movimento, pré-recusas sem PA, Vida/PA atuais, ataque de 4d6, sucesso, dano, RD, HP efetivo, overkill, número de turnos e motivo de encerramento ou censura. Não confundir KO, vitória, censura e empate pré-commit.
- Comparar taxa da primeira conjuração, primeiras três (se presentes) e posteriores com controle de sobrevivência. A variação do número de tentativas por seed é um *desfecho*, não justificação para converter os eventos em amostras independentes.
- R204 V1=incidente histórico, V2=coorte corrigida, V2B=fronteira dirigida; a nova coorte recebe RUN-IDs próprios, nenhum replay/reutilização de seeds anteriores. **R205 já existe** e deve permanecer separado.

## Critérios de aceite e uso pelo DMG

Aceite científico local: evento 1×1 fonte-admissível, sem alteração de fórmula para forçar concordância; recibos frios inspecionáveis; denominador de tentativas/seed e recusas; V1 e V2B segregados; paridade e integridade de hashes/SQLite; Q-TARGET/Q-MATH/Q-TRACE; interpretação honesta do poder estatístico. A homogeneidade observada pode sustentar **manter** DMG-RANK v1.1; discrepância persistente exige primeiro investigação de RNG/política/seleção, não ajuste universal de dano.

**ROTA:** encaminhar apenas pelo coordenador e pela Inbox existente quando houver autoridade de comunicação/ACK verificada. Este arquivo não prova envio nem reserva de execução.
