import csv,json,hashlib,math
from pathlib import Path
root=Path(__file__).resolve().parent;date='2026-10-20'
# IDs and mechanical expressions were directly re-opened on Notion Mestre 2026-10-20.
rec=[
('Tigre Flora','67bc2b324ede832ba95a01a5160aa46d','Prata 3','Prata 3','Ouro 2','2026-10-01T18:00:55.339Z','Garras de Espinhos','2d4+FOR41',2,4,41,20,'envenena: CD 6+CON; teste e dano não especificados','CONFIRMADA_LOCAL','FORMULA_VERIFICADA_SOZINHA'),
('Tigre Flora','5f1c2b324ede8320bcfb81725919671a','Prata 4','Prata 3','Ouro 2','2026-10-08T02:24:42.487Z','Garras de Espinhos','2d4+FOR49',2,4,49,21,'envenena: CD 6+CON; teste e dano não especificados','CONFLITANTE','EXPLORATORIO_NAO_INTER_RANK'),
('Tigre Flora','12fc2b324ede82da84a581e33f2e1d56','Ouro 2','Prata 3','Ouro 2','2026-10-01T18:00:55.469Z','Garras de Espinhos','2d4+FOR72',2,4,72,21,'envenena: CD 6+CON; teste e dano não especificados','CONFLITANTE','EXCLUIDO_INTER_RANK'),
('Lobo das Cavernas','be5c2b324ede832e8b7a81c5460571c1','Prata 1','Prata 1','Prata 5','2026-10-01T18:00:33.930Z','Patada','1d6+FOR24',1,6,24,None,'+2 FOR de Força Ancestral: inclusão no atributo ainda não provada','CONFIRMADA_LOCAL','FORMULA_VERIFICADA_SOZINHA'),
('Lobo das Cavernas','74ec2b324ede82b2a92401642e909be6','Prata 5','Prata 1','Prata 5','2026-10-01T18:00:33.992Z','Patada','1d6+FOR40',1,6,40,None,'+2 FOR de Força Ancestral: inclusão no atributo ainda não provada','CONFLITANTE','EXCLUIDO_INTER_RANK'),
('Polvo da Floresta','77ec2b324ede82d49662812c1e72b7b0','Prata 1','Prata 1','Ouro 1','2026-10-01T18:00:59.760Z','Corte cerebral','2d6+INT29',2,6,29,None,'modalidade da entrega, alvo, PA e RE não documentados','CONFIRMADA_LOCAL','FORMULA_VERIFICADA_SOZINHA'),
('Polvo da Floresta','a94c2b324ede83b4a2b3018d2c8d503d','Prata 3','INDETERMINADO','Ouro 1','2026-10-01T18:00:54.968Z','—','—',0,0,0,None,'página-folha sem fórmula utilizável','INDETERMINADA','SEM_EFEITO_NUMERICO'),
('Polvo da Floresta','9ddc2b324ede8366a5c981be65f440d2','Ouro 1','INDETERMINADO','Ouro 1','2026-10-01T18:00:55.026Z','—','—',0,0,0,None,'página-folha sem fórmula utilizável','INDETERMINADA','SEM_EFEITO_NUMERICO'),
('Cervídeo Glacial','929c2b324ede82ecb04201f553eaad96','Prata 2','Bronze','Ouro 3','2026-10-01T18:00:43.807Z','Galhada Glacial','2d6+DES27',2,6,27,None,'ataque perfurante e cortante; custo e ação não especificados','CONFLITANTE','EXCLUIDO_INTER_RANK'),
('Cervídeo Glacial','432c2b324ede8393a90501de383cbe81','Prata 5','Bronze','Ouro 3','2026-10-01T18:00:43.869Z','Galhada Glacial','—',0,0,0,None,'ataque qualitativo sem expressão publicada nesta variante','CONFLITANTE','SEM_EFEITO_NUMERICO'),
('Cervídeo Glacial','1fac2b324ede8311a1da01ed6a84e18b','Ouro 3','Bronze','Ouro 3','2026-10-01T18:00:43.929Z','Galhada Glacial','4d6+DES54',4,6,54,None,'ataque perfurante e cortante; custo e ação não especificados','CONFLITANTE','EXCLUIDO_INTER_RANK')]
rows=[]
for (fam,uuid,title,body,anc,ed,effect,lit,n,s,attr,con,note,status,comp) in rec:
 intr=n*(s+1)/2 if n else None
 rows.append({'family':fam,'source_uuid':uuid,'source_url':'https://app.notion.com/p/'+uuid,'page_edited_at':ed,'title_rank':title,'body_rank':body,'ancestor_rank_container':anc,'effect_definition_key':fam+'::'+effect if n else '', 'effect':effect,'source_expression_literal':lit,'dice_mean_intrinsic':intr if n else '', 'external_attribute':attr if n else '', 'mean_published_formula':intr+attr if n else '', 'variance_dice':n*(s*s-1)/12 if n else '', 'attribute_fraction':round(attr/(intr+attr),8) if n else '', 'numeric_poison_cd_if_present':6+con if con is not None else '', 'rank_status':status,'comparability':comp,'effect_rank_RE':'NOT_VERIFIED','action_cost':'NOT_VERIFIED','PA_cost':'NOT_VERIFIED','notes':note})
with (root/'C15_NEW_FAMILY_SOURCE_ADMISSIBILITY.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
assert len(rows)==11 and sum(bool(x['dice_mean_intrinsic']!='') for x in rows)==8
assert len(set(x['effect_definition_key'] for x in rows if x['effect_definition_key']))==4
# Scoped prospective evaluator: no schema/rule changes, only decision instructions.
items=[
 ('A','Espada Prata física sem magia','Prata','3d8','13.5','sem rider','13.5','INDETERMINADO','A decisão Mestre manda 3d8 físico; não exigir piso de RE na parcela de chassi isolada'),
 ('B','Espada Prata TEST + rider próprio 1d4 aditivo no MESMO acerto','Prata','3d8','13.5','1d4: 2.5','16','INDETERMINADO','Orçamento da ação inteira é 16; nunca somar 13.5 + 16; RI/RE/FIP dependem classificação do efeito completo'),
 ('C','Espada Prata TEST com habilidade como ação distinta','Prata','3d8','13.5','ação distinta 1d4: 2.5','nao_aditivo_automatico','INDETERMINADO','Apenas uma ação por vez salvo contrato específico; custo da habilidade não foi inventado'),
 ('D','Espada Prata equipada por usuário com FOR+10','Prata','3d8','13.5','atributo externo +10','23.5 final_condicional','INDETERMINADO','O bônus é externo e não eleva DME intrínseco de 13.5 para 23.5'),
 ('E','Espada Prata teste rider elemental condicionado','Prata','3d8','13.5','1d4 elemental após acerto','16 bruto condicionado','INDETERMINADO','Sem regra sobre RD por componente não afirmar dano final nem eficiência PA'),
]
with (root/'C15_PROSPECTIVE_RI_RE_FIP_DECISIONS.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['case','test_scenario','physical_classification','chassis','physical_dme','additional_effect','whole_action_dme_or_rule','FIP_assignment','interpretation']);w.writerows(items)
(root/'C15_CORPUS_NUMBERS.json').write_text(json.dumps({'physically_read_leaf_pages':11,'families':4,'formula_occurrences':8,'independent_family_effect_definitions':4,'leaf_pages_without_numeric_life_damage':3,'fully_strict_interrank_pairs_with_documented_RE_cost_action':0,'family_counts':{'Tigre Flora':3,'Lobo das Cavernas':2,'Polvo da Floresta':3,'Cervídeo Glacial':3},'source_status':'MASTER_READ_ONLY_VERIFIED_AS_DOC','second_independent_reviewer':'PENDING','holdout':'NO_MODEL_FIT_OR_HOLDOUT_PROMOTED'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pages':len(rows),'numeric':sum(x['dice_mean_intrinsic']!='' for x in rows),'defs':4}))
