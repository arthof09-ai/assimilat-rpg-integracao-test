# PSV — DMG C15 | COMPARABILIDADE, SEEDS R204 E CRITÉRIOS PROSPECTIVOS

**AS-OF:** 20/10/2026. **OPERATION:** `OP-DMG-CORPUS-EMP-01`. **AMBIENTE:** MESTRE-SIDE. **BASELINE:** DMG-RANK-01 v1.1 vigente. **F0:** 4/8. **PRODUÇÃO:** HOLD.

## Resultado primeiro

O C14 original SHA `c4ddfac3c465d3464aab6afa004ba464d96f200fe1b750b5a94e35a98c7ffbf1` foi recuperado da Biblioteca; a pasta DMG não apresentava C15 prévio. O R204 primário SHA `80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2` foi reaberto em leitura somente. **NÃO** reexecutar C14 ou combates VLAB.

**Avanço científico A — precisão dependente da trajetória:** 40 SQLite corrigidos auditados, **184/184 conjurações** com 4d6+19, CA34, RD15, HP, overkill e PA reencontrados. 81 hits, 1.472PA, 3.380 dano pós-RD, 3.322 Vida e 58 overkill; oito streams V2 pares 9/9,5m literalmente iguais, logo 116 registros físicos da V2 são 58 eventos distintos em oito seeds. Primeiras três conjurações/seed acertam 8/24 (33,33%); posteriores 19/34 (55,88%). Referência matemática p=435/1296 (33,56%). Média das taxas por seed 45,77%, intervalo t95 ilustrativo 31,32%–60,22% (n=8 sementes, hipóteses de independência limitadas). **NÃO** afirmar viés nem alterar regra.

**Avanço B — a discrepância pós-RD V2 está na frequência de acerto:** 58 eventos distintos = 27 hits, 1.124 pós-RD, 1.107 HP e 464 PA. Por cast: pós-RD 19,379 vs esperado teórico13,762; diferença5,618, composta por5,325 de frequência e0,293 de média por hit. Apenas correlação/descritiva; não inferir causalidade. V2B quatro seeds dirigidas e V1 inválida segregadas.

**Avanço C — corpus e elegibilidade:** 11 folhas reabertas em **4 famílias** (Tigre Flora, Lobo das Cavernas, Polvo da Floresta, Cervídeo Glacial), 8 ocorrências numéricas, 4 definições, 3 folhas sem fórmula. Tigre Flora P3 `2d4+FOR41` =46; folha P4 corpo P3 =54; folha O2 corpo P3 =77, todas com dados intrínsecos média5, aumento externo FOR. Lobo P1 `1d6+FOR24` 27,5 vs folha intitulada P5 com corpo P1 `1d6+FOR40` 43,5. Polvo P1 `2d6+INT29` =36; superiores vazias. Cervídeo folha P2 `2d6+DES27`=34 vs O3 `4d6+DES54`=68, ambos corpos Bronze. **0 novos pares completos inter-rank** com RE+rank+ação+custo+entrega verificados; nenhuma hipótese de banda universal foi validada por falsos títulos.

**Avanço D — critérios para novas armas:** RI classifica o item, RE o efeito, FIP é gradação interna não pública. Chassi físico novo Prata espada `3d8` DME13,5; TEST rider `1d4` no mesmo golpe dá DME total16, NÃO29,5; ação distinta não soma automaticamente. FOR+10 externa dá dano final condicional23,5 sem alterar DME intrínseco13,5. Sem RD competente para misto, pós-RD HOLD. Alinhado DMG v1.1 §§5/8/22 e nova determinação prospectiva do Mestre; nenhum item histórico recalculado.

## Decisão e continuidade

**Hipóteses:** H1 atributos dominam certos ataques, mas não houve validação populacional; H4 R204 indicação de seleção por duração, não prova de desvio do dado; H5 efeitos com títulos conflitantes excluídos de fronteiras; H6 composição física+efeito sem dupla contagem. **Manter DMG-RANK v1.1 oficial; não criar v2.**

**FIRST-PENDING:** pedido VLAB cientificamente discriminante (um feitiço por seed independente, seguido de política pareada) pronto mas **NÃO ENVIADO**; também localizar efeitos comparáveis com RE, custo e ação publicados. **LAST-VERIFIED-UNIT:** C15 auditoria de 184 eventos e matrizes de quatro famílias.

**DENOMINATORS/D0–D9:** dados locais 11 folhas/4 famílias/8 ocorrências/4 definições/3 negativas; 40 DB R204, 8 seeds V2 e 4 V2B dirigidas; sem censo global certificado. C14 e A6-571 históricos sem soma artificial. **F0–F18:** F0 4/8; F1–F12 evidência localizada, PASS formal não promovido; F13–F18 HOLD/sem candidata. **E01–E24:** verificações proporcionais de fonte, cálculo, alvo e rastreio; Q-COVERAGE global e Q-HOLDOUT formal não certificados. Segunda leitura classificatória independente PENDENTE.

**NO-REPEAT:** C04–C14, A6, lotes L002/L003, R162/R169, R200, V1 R204 e V2/V2B originais intocados. **CONFLICTS:** ranks de Tigre, Lobo, Cervídeo; RE/ação/PA ausentes; RD misto e RI/RE/FIP aguardam autoridade. **UNKNOWN-EFFECT:** R156 mantida, R138 HOLD. R205 identificada como coorte posterior em VLAB, fora do denominador C15.

**NEXT-5:** 1) encaminhar experimento ao VLAB pela rota competente; 2) descobrir pares efetivamente completos; 3) obter segunda classificação independente; 4) estudar R205 em coorte separada; 5) solicitar parecer normativo de coexistência de chassis e orçamento integral, sem mudar v1.1. **TARGET-REMAINDER:** F0–F18, E01–E24, oito gates, D0–D9, A5/A7/A8, L002/L003 e holdout.

**AUTHORITY/WRITER:** nenhum writer/lease/epoch/fencing/ACK; nenhuma escrita em Notion original, Party, O Primeiro, fichas ou SQLite. Persistência autorizada apenas na pasta existente da Biblioteca DMG, após verificação. **NAC-PASS-02:** PASS técnico de análise local condicionado ao congelamento e readback final; ciência global, norma e produção HOLD.

**FULL SCIENCE:** `C15_DIAGNOSTICO_CIENTIFICO_MESTRE_ONLY.md`. **VLAB HANDOFF:** `C15_VLAB_EXPERIMENTAL_REQUEST_NOT_SENT.md`. **COLD RECOVERY:** `README_C15_REPRODUCE.md`.
