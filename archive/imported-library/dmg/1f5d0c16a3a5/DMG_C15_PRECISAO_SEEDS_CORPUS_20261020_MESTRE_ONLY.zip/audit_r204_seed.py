#!/usr/bin/env python3
"""DMG C15: read-only scientific audit; DOES NOT execute VLAB runner."""
import zipfile, sqlite3, tempfile, os, json, csv, re, collections, math, hashlib, statistics
from pathlib import Path
from scipy.stats import t as student_t
R=Path(__file__).resolve().parent; IN=Path(os.environ.get('DMG_R204_ZIP','/mnt/data/dmg_c15_input/VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip'))
Z=zipfile.ZipFile(IN)
inputs=[x for x in Z.namelist() if x.endswith('.sqlite') and ('new/evidence/v2_db/' in x or 'new/evidence/v2b_db/' in x)]
assert len(inputs)==40,(len(inputs),inputs)
allruns=[]; casts=[]; issues=[]; refuses=[]
for path in sorted(inputs):
    b=Z.read(path);sha=hashlib.sha256(b).hexdigest()
    f=tempfile.NamedTemporaryFile(delete=False,suffix='.sqlite');f.write(b);f.close()
    uri=Path(f.name).as_uri()+'?mode=ro'
    try:
        con=sqlite3.connect(uri,uri=True)
        rawrows=[json.loads(y[0]) for y in con.execute('SELECT row_json FROM events ORDER BY seq')];con.close()
    finally:os.unlink(f.name)
    name=path.rsplit('/',1)[-1].replace('.sqlite','')
    cohort='V2B' if name.startswith('R204V2B_') else 'V2'
    m=re.search(r'_S(\d+)_DIST(9p5|9)_([^/]+)',name);assert m,name
    seed=int(m.group(1));dist=9.5 if m.group(2)=='9p5' else 9.0;policy=m.group(3)
    nr={'cohort':cohort,'seed':seed,'distance':dist,'policy':policy,'run_id':name,'sha256':sha,'db_events':len(rawrows),'admitted':0,'hit':0,'pa':0,'net':0,'hp':0,'overkill':0,'refusals':0}
    castseq=0
    for x in rawrows:
        d=x.get('detail') or {};kind=d.get('kind',''); s=json.dumps(d,ensure_ascii=False)
        if kind=='NATIVE_RD_SPATIAL_MAGIC_CAST':
            eff=d['effect'];atk=eff['attack_roll'];score=sum(atk)+int(eff['attack_bonus']);hit=score>int(eff['target_ca']);
            assert len(atk)==4 and all(isinstance(x,int) and 1<=x<=6 for x in atk)
            assert score==eff['attack_score'] and hit==eff['hit']
            assert eff['critical']=='NONE' and int(eff['PA_cost'])==8
            assert int(d['PA_paid'])==8
            assert float(eff['distance_m'])<=9.0
            if hit:
                assert int(eff['rd_applied'])==15 and int(eff['raw'])-15==int(eff['net'])
            else:
                assert int(eff['raw'])==0 and int(eff['net'])==0
            assert int(eff['net'])==int(eff['hp_loss_actual'])+int(eff['overkill'])
            castseq+=1;nr['admitted']+=1;nr['hit']+=int(hit);nr['pa']+=8
            for key,field in [('net','net'),('hp','hp_loss_actual'),('overkill','overkill')]:nr[key]+=int(eff[field])
            casts.append({'cohort':cohort,'seed':seed,'distance_m':dist,'policy':policy,'run_id':name,'ordinal_in_fight':castseq,'attack_dice':','.join(map(str,atk)),'score':score,'ca':eff['target_ca'],'hit':int(hit),'raw':eff['raw'],'net':eff['net'],'hp_actual':eff['hp_loss_actual'],'overkill':eff['overkill'],'pa':8,'round':d.get('round',None),'sqlite_event_seq':x.get('seq')})
        if 'REFUS' in kind.upper() or 'OUT_OF_RANGE' in kind.upper():
            refuses.append({'cohort':cohort,'seed':seed,'distance':dist,'kind':kind,'seq':x.get('seq'),'cost':d.get('PA_paid',None),'detail':s[:300]})
            nr['refusals']+=1
    allruns.append(nr)
assert sum(x['admitted'] for x in allruns)==184
assert sum(x['hit'] for x in allruns)==81
assert sum(x['net'] for x in allruns)==3380
assert sum(x['hp'] for x in allruns)==3322
assert sum(x['overkill'] for x in allruns)==58
assert sum(x['pa'] for x in allruns)==1472
v2=[x for x in allruns if x['cohort']=='V2' and x['policy']=='CAST_WHEN_IN_RANGE'];v2b=[x for x in allruns if x['cohort']=='V2B'];assert len(v2)==16 and len(v2b)==8
for seed in sorted(set(x['seed'] for x in v2)):
 a=sorted([x for x in casts if x['cohort']=='V2' and x['seed']==seed and x['distance_m']==9.0],key=lambda x:x['ordinal_in_fight']);b=sorted([x for x in casts if x['cohort']=='V2' and x['seed']==seed and x['distance_m']==9.5],key=lambda x:x['ordinal_in_fight']);assert len(a)==len(b)
 for x,y in zip(a,b):
  for k in ['attack_dice','score','hit','raw','net','hp_actual','overkill']:
   assert str(x[k])==str(y[k]),(seed,k,x,y)
assert len([x for x in casts if x['cohort']=='V2' and x['distance_m']==9.0])==58
seed_rows=[]
for cohort in ['V2','V2B']:
 for seed in sorted(set(x['seed'] for x in casts if x['cohort']==cohort)):
  variants=[x for x in allruns if x['seed']==seed and x['cohort']==cohort and x['policy']=='CAST_WHEN_IN_RANGE']
  for v in sorted(variants,key=lambda x:x['distance']):
   c=sorted([x for x in casts if x['run_id']==v['run_id']],key=lambda x:x['ordinal_in_fight']);n=len(c)
   early=c[:3];later=c[3:]
   seed_rows.append({'cohort':cohort,'seed':seed,'distance_m':v['distance'],'admitted':n,'hits':v['hit'],'p_observed':round(v['hit']/n,8) if n else None,'first3_attempts':len(early),'first3_hits':sum(x['hit'] for x in early),'late_attempts':len(later),'late_hits':sum(x['hit'] for x in later),'net':v['net'],'hp_actual':v['hp'],'pa':v['pa']})
control=[x for x in seed_rows if x['cohort']=='V2' and x['distance_m']==9.0];rates=[x['p_observed'] for x in control];mean=statistics.mean(rates);se=statistics.stdev(rates)/math.sqrt(8);margin=student_t.ppf(.975,7)*se;theory=435/1296
assert sum(x['hits'] for x in control)==27 and sum(x['admitted'] for x in control)==58
assert sum(x['first3_hits'] for x in control)==8 and sum(x['first3_attempts'] for x in control)==24
assert sum(x['late_hits'] for x in control)==19 and sum(x['late_attempts'] for x in control)==34
c14_path=Path(os.environ.get('DMG_C14_CASTS_CSV', str(R/'c14/C14_R204_SPELL_EVENTS_V2_V2B.csv')))
if c14_path.exists():
 seen_c14=list(csv.DictReader(c14_path.open()));assert len(seen_c14)==len(casts)
 for row in seen_c14:
  q=[c for c in casts if c['run_id']==row['run_id'] and c['sqlite_event_seq']==int(row['seq'])]
  assert len(q)==1,(row['run_id'],row['seq'])
  for k,tgt in [('hit','hit'),('score','roll_score'),('net','net'),('hp_actual','hp_actual'),('overkill','overkill'),('pa','pa')]:assert int(q[0][k])==int(row[tgt])
# End-of-run totals and overkill verified; note outside range may be logged as a rejected preflight before SQLite commit.
summary={'source_zip':str(IN),'source_sha256':hashlib.sha256(IN.read_bytes()).hexdigest(),'db_files_readonly':len(inputs),'sqlite_accepted_casts':len(casts),'hits':sum(c['hit'] for c in casts),'total_pa':sum(c['pa'] for c in casts),'net_damage':sum(int(c['net']) for c in casts),'hp_removed':sum(int(c['hp_actual']) for c in casts),'overkill':sum(int(c['overkill']) for c in casts),'v2_unique_seed_count':8,'v2_duplicate_distance_streams_verified':8,'v2_physically_recorded_casts':sum(x['admitted'] for x in v2),'v2_unique_stream_casts':sum(x['admitted'] for x in v2)//2,'v2_unique_stream_hits':sum(x['hit'] for x in v2)//2,'v2_early3_hit_rate':8/24,'v2_late_hit_rate':19/34,'v2_unique_cast_hit_rate':27/58,'v2_seed_equal_weight_rate':mean,'v2_seed_t95_interval':[mean-margin,mean+margin],'theory_exact_probability':theory,'v2b_purposive_seeds':4,'v2b_recorded_casts':sum(x['admitted'] for x in v2b),'claim':'DESCRIPTIVE_ONLY_SMALL_CLUSTERED_NONIID','c14_direct_event_reconciliation':'184/184' if c14_path.exists() else 'NOT_RECHECKED_OPTIONAL_EXTERNAL_C14','new_simulations':0,'write_to_vlab_db':0,'preflight_refusals_in_committed_events':len(refuses)}
for fn,rs in [('C15_R204_NATIVE_CAST_AUDIT.csv',casts),('C15_R204_SEED_CLUSTER_SUMMARY.csv',seed_rows)]:
 with (R/fn).open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=rs[0].keys());w.writeheader();w.writerows(rs)
(R/'C15_R204_INDEPENDENCE_DIAGNOSTIC.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
