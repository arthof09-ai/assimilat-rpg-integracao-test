# DMG C15 — Recuperação portátil, evidência sem duplicação

**Somente MESTRE-SIDE.** Produto científico delta, não motor de combate, não RE/FIP canonizado, não homologação DMG v2. Nenhum banco SQLite histórico entra neste pacote.

## Entradas externas imutáveis

- C14 original: `DMG_C14_CIENCIA_COMPARADORES_R204_20261020_MESTRE_ONLY.zip` SHA-256 `c4ddfac3c465d3464aab6afa004ba464d96f200fe1b750b5a94e35a98c7ffbf1`. Dentro dele: `C14_R204_SPELL_EVENTS_V2_V2B.csv`.
- VLAB original: `VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip` SHA-256 `80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2`. Contém 40 DB corrigidos e V1 histórica, que o script **não** consulta.
- Árvores e páginas físicas Notion Mestre: URLs, UUIDs, edições e expressões em `C15_NEW_FAMILY_SOURCE_ADMISSIBILITY.csv`. Script `create_c15_sources.py` congela esta matriz documentária, não possui acesso automático ao Notion.

## Procedimento em pasta limpa

```bash
unzip DMG_C15_PRECISAO_SEEDS_CORPUS_20261020_MESTRE_ONLY.zip -d c15
cd c15
export DMG_R204_ZIP=/caminho/para/VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip
export DMG_C14_CASTS_CSV=/caminho/para/C14_R204_SPELL_EVENTS_V2_V2B.csv
python audit_r204_seed.py
python create_c15_sources.py
```

`audit_r204_seed.py` lê os 40 SQLite direto do ZIP externo via arquivos temporários em modo `ro`, audita cada dado de 4d6, CA34, empate, 8PA, RD15, HP e overkill, cruza eventos com C14 e gera 3 resultados. `create_c15_sources.py` refaz 3 tabelas/resumos de fonte documentária. O ZIP retém as 6 saídas pré-reproduzidas. Comparar bytes/hashes depois de reexecutar. `C15_SHA256_MANIFEST.json` abrange todos os membros anteriores ao próprio manifesto. Nenhum runner VLAB é chamado. Python3 + SciPy para intervalo t descritivo, sem rede.

## Interpretação estatística

N físico de eventos R204=184, mas V2 possui 8 sementes, fluxos de ataque 9m/9,5m duplicados. V2B possui 4 seeds dirigidas, não aleatórias. Não multiplicar independência pelo número de conjurações, não combinar V1 errada e V2/V2B corrigidas, não tratar censura como vitória. Hipótese observacional *trajetória sobrevivente* não equivale a causalidade. A ausência de discordância nos eventos não prova que uma implementação geral seja correta em outros cenários.

## Continuidade/gates

Autoridade: OP-DMG-CORPUS-EMP-01, DMG-RANK v1.1. F0 formal 4/8. C04–C14, A6-571, L002/L003, R162/R169 e VLAB histórico preservados. R156 UNKNOWN_EFFECT, R138 HOLD. `SECOND-REVIEW=PENDING`; P0-NORM e produção HOLD. Sem writer/lease/epoch/fencing/ACK; sem Notion/Party/O Primeiro/SQLite write. Biblioteca readback será comprovado em recibo externo pós-publicação, não por declaração no ZIP.
