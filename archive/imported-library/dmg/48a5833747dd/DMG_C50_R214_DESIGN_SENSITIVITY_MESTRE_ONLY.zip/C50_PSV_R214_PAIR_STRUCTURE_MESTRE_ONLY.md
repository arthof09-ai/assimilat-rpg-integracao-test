# DMG C50 — VLAB R214: efeito de desenho de ensaio, pares e censura (MESTRE-ONLY/TEST)

**Objetivo:** proteger o DMG de inferir balanceamento populacional a partir de uma bateria VLAB de contratos funcionais. Fonte exclusiva: pacote DMG C38, já proveniente do ZIP R214 do VLAB; a fonte do VLAB NÃO foi modificada ou repetida.

## VERIFICADO

O pacote R214 tem **15 seeds distintos, 38 eventos de ataque aninhados**, distribuídos em `AO0_OPPORTUNITY` **12 seeds** (seis casos funcionais, cada qual duas seeds) e `BILATERAL` **3 seeds** (todos `CENSORED_HORIZON`). Reconciliou-se cada uma das 38 linhas de ataque até seus 15 agrupamentos seed por campos `raw`, `rd`, `post_rd`, `vida`, `overkill` e acertos/críticos; 130 asserções numéricas locais.

Totais preservados: **3.172 bruto - 1.070 RD - 26 overkill = 2.076 Vida efetiva**. A fração de RD sobre dano bruto é **36.14%** em AO0 e **32.63%** em BILATERAL; isto é *descritivo*, não efeito causal de uma política.

Os pares de seeds dentro do mesmo **caso funcional** AO0 produzem os seguintes deltas ABSOLUTOS de Vida: DOUBLE 33, SPENT_CHAIN 10, TIE 5, LETHAL 0, MISS 0, NO_ADJ 0. O valor do caso LETHAL permanece em 38 Vida nas duas seeds; a diferença bruta vai para overkill (10 vs 16). No conjunto de seis pares, soma das diferenças absolutas por caso é **48 Vida** e **54 dano bruto**. Não se trata de diferenças antes/depois DMG, pois são seeds de um mesmo *tipo de caso*, não intervenção/política.

Em BILATERAL as três seeds são **3/3 censuradas por horizonte**. Dano bruto variou de 658 a 855 (amplitude **197**) e Vida efetiva 433 a 595 (amplitude **162**). Sem tempo final de encerramento observado, não é permitido derivar tempo médio de morte/TTK completo. O único crítico positivo de todo R214 pertence ao grupo BILATERAL e não estima taxa de críticos real.

## Implicações científicas

- **Não** tratar 38 ataques como 38 batalhas independentes; a unidade primária aqui é seed/combate e ainda há desenho por caso.
- **Não** produzir intervalos de confiança populacionais bootstrap de missões deliberadamente desenhadas para testar contratos.
- **Não** comparar AO0 e BILATERAL como grupos aleatorizados ou tomar a diferença de médias como efeito causal de uma versão de dano. Os cenários, número de eventos e horizontes diferem por construção.
- Os casos NO_ADJ/MISS mostram 4 seeds com dano zero por gatilho funcional — agregá-los ingenuamente reduziria artificialmente o dano médio da operação, confundindo natureza do caso com capacidade do personagem.
- Para etapa futura F7–F18, selecionar inputs de batalhas comparáveis, rastrear rank, defesa, custo, RD/overkill, censura, seeds emparelhadas SAME-SCENE e registrar decisão de amostragem antes de qualquer inferência sobre balanceamento.

## Estado e retomada

F0 formal 4/8 HOLD; A5 bytes 0/7, A7 sem cegamento, A8 segundo humano e writer faltantes, D0 global desconhecido (870 IDs delimitados), F6 sem positivo real. Nenhum combatente, atributo, PA, evento ou regra foi editado. `LAST_VERIFIED=C50`, `FIRST_PENDING=amostra legítima de combates pré-registrados com parâmetros completos + gates F0`.
