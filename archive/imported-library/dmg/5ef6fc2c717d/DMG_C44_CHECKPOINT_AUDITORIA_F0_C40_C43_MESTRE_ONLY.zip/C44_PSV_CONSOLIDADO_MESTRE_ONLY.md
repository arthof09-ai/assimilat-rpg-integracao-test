# PSV DMG C44 — Readback físico C40–C43 e sucessão científica (MESTRE-SIDE)

**OP EXISTENTE:** OP-DMG-CORPUS-EMP-01; **baseline:** DMG-RANK-01 v1.1 vigente, imutável nesta execução. **Autoridade:** Mestre autorizou sucessão científica; Notion OP/Diário/Inbox, fichas, Party, O Primeiro e VLAB **NO-WRITE** por inexistência de prova de writer/lease. Resultados semântico/científico TEST, nenhum ajuste homologado ou v2.

## Recebimento físico e validação do pacote completo
O C44 releu **cinco arquivos ZIP** C39–C43 do filesystem preservado: CRC em 5/5, integridade dos hashes internos dos manifestos, e **quatro arquivos C40–C43** que haviam sido publicados na Biblioteca Mestre foram baixados novamente e comparados **byte-a-byte com o ZIP de origem (4/4)**. A verificação de C39 está aqui para encadear com a campanha anterior, não reapresentar 7 ZIP históricos C32–C38 como novos testes.

Foi revalidado separadamente o pacote F0 de 16/10: **20 entradas, 19/19 hashes/tamanhos do manifesto fisicamente verificados** e SHA de arquivo raiz `e9c135284d7bf8630d80457a1eed334e9bdbdf20279721ce872daf6fba3bdcd2`. O F0 ZIP NÃO contém os sete arquivos Markdown anexados depois ao Notion; não foi usado para fabricar 7/7 readback.

**115 asserts locais PASS** (checksum/cadeia/persistência de HOLD), leitura de 5/5 ZIP, readback de 4/4, 19/19 arquivos F0, verificações de não repetição 859 → 870 e existência de checkpoints. Manifests e cadeia de custódia estão no CSV.

## Linha de produção C39→C44 e produtos científicos
- **C39 antes:** 848 Page-IDs no recorte de Mestre, F0 4/8 HOLD.
- **C40 depois:** +11 fontes dirigidas Mestre, 859 IDs; 7/7 links privados A5 resolvidos/0 bytes; mudança de timestamp da regra Criação de Ficha identificada, seis outras autoridades com timestamp original; 8 reservas A7 indexadas e histórico não blindado; 0/11 casos F6 admissíveis na amostra.
- **C41:** 4 fontes de itens Semicanônicos/Incubação; 24 PMF exatas de RD em quatro pools +21 negativos defensivos Selo, **197 checks**, nenhuma nova ficha física.
- **C42:** +11 páginas do espelho Mestre `Magias — Chen Yi-Min`, 870 IDs no recorte (NÃO global D0); 3 contradições internas literal (Defesa Vento V3, Frio Eterno V3, Coluna Gelo V2); nenhuma escrita Party e nenhuma fórmula sobrescrita.
- **C43:** 315 cenários algébricos condicionais DoT, 5 de congelamento, fila de 3 decisões pendentes em ficha original, **800 checks**. Não é playtest VLAB nem solução automática de regras conflitantes.

**Total Page-ID físico no recorte:** 870, com 22 novas fontes individuais realmente lidas nesta sucessão após C39, sem duplicatas; múltiplas formas e técnicas não são entidades independentes para estatística de efeito. **D0 global F0-A6 continua PENDENTE.**

## Gate proporcional / não-aceite global
| Eixo | Estado após C44 | Motivo |
|---|---|---|
| Integridade de pacotes C40–C43 | PASS local | hash/CRC, byte readback, scripts TEST |
| F0 (documental) | **4/8 HOLD** | pré-registro parcial, sem blindagem e writer |
| A5 | **0/7 bytes POST-UPLOAD** | roteamento privado impede baixar bytes dos anexos A5; localizador ≠ SHA |
| A6 | **870 Page-IDs de escopo** | resto do Notion e identidade/famílias globais não fechados |
| A7 | **HOLD** | oito casos reservados anteriormente não têm prova de cegamento vitalício; precisa novo holdout agrupado |
| A8 | **HOLD** | sem codificador humano realmente independente e sem escritor/lease/epoch notional |
| F6 | **HOLD** | não há caso ofensivo original válido sem dano, mas com RE/FIP próprio e ação/custo/entrega totalmente comprovados |
| F7–F18 / candidata v2 | **NÃO HOMOLOGADOS** | sem calibração, validação humana, playtest e aprovação |

## Próxima fronteira real (não repetir o conhecido)
**LAST-VERIFIED:** C44 readback 5/5 arquivos e 19/19 original F0, ligação 859→870. **FIRST-PENDING:** A5 obter bytes por canal privado legítimo e confrontar hashes/edições; buscar fonte F6 ofensiva válida fora da Party e holdout, não inventar FIP; A7 preseal novo em famílias não expostas antes de calibrar, com segundo pesquisador humano e prova de exclusão de aliases; A8 resolver atribuição de writer/lease/epoch com autoridade para OP/Diário. Depois ampliar A6 por classes de habilidades não auditadas; avisar Mestre só ao alcançar decisão efetivamente necessária.

**NAC-PASS aplicado:** PASS de integridade dos artefatos e álgebra local, **NO-PASS F0/F6/norma global**. Não usar esses resultados para aplicar dano novos em sessão até autoridades competentes resolverem as divergências.
