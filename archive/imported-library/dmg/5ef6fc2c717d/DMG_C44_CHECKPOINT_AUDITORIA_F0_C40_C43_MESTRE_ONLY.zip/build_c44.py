from pathlib import Path
import hashlib,csv,json,zipfile,collections
p=Path(__file__).parent
base=Path('/mnt/data')
paths={
'C39':base/'dmg_c40_inputs/DMG_C39_RECAP_HANDOFF_C32_C38_MESTRE_ONLY.zip',
'C40':base/'dmg_c40/DMG_C40_F0_F6_LINEAGE_AUDIT_MESTRE_ONLY.zip',
'C41':base/'dmg_c41/DMG_C41_ITEMS_CONDITIONAL_PMF_MESTRE_ONLY.zip',
'C42':base/'dmg_c42/DMG_C42_MAGIAS_CONFLITOS_CENSO_MESTRE_ONLY.zip',
'C43':base/'dmg_c43/DMG_C43_SENSIBILIDADE_CONFLITOS_DOT_MESTRE_ONLY.zip'}
readbacks={
'C40':base/'dmg_c40_readback/DMG_C40_F0_F6_LINEAGE_AUDIT_MESTRE_ONLY.zip',
'C41':base/'dmg_c41_readback/DMG_C41_ITEMS_CONDITIONAL_PMF_MESTRE_ONLY.zip',
'C42':base/'dmg_c42_readback/DMG_C42_MAGIAS_CONFLITOS_CENSO_MESTRE_ONLY.zip',
'C43':base/'dmg_c43_readback/DMG_C43_SENSIBILIDADE_CONFLITOS_DOT_MESTRE_ONLY.zip'}
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[];summ={};checks=0
for k,zp in paths.items():
 assert zp.is_file()
 z=zipfile.ZipFile(zp)
 assert z.testzip() is None;checks+=1
 mm={}
 if k=='C39':m=json.loads(z.read('C39_MANIFEST.json'));mm={key:{'sha256':v['sha256'],'bytes':v['size']} for key,v in m.items()}
 else:
  m=json.loads(z.read(f'{k}_MANIFEST.json'))
  mm={key:{'sha256':v['sha256'],'bytes':v['bytes']} for key,v in m.items()}
 assert set(mm).issubset(set(z.namelist()))
 for name,m in mm.items():
  data=z.read(name);assert len(data)==m['bytes'] and sha(data)==m['sha256'];checks+=2
 if k in readbacks:
  ob=readbacks[k].read_bytes();sb=zp.read_bytes()
  assert ob==sb;checks+=1
 rows.append({'batch':k,'name':zp.name,'zip_bytes':zp.stat().st_size,'zip_sha256':sha(zp.read_bytes()),'entries':len(z.namelist()),'sha_files_verified':len(mm),'CRC':'PASS','independent_library_readback':'PASS' if k in readbacks else 'not repeated — prior C39 check'})
 summ[k]={'archive_checksum':sha(zp.read_bytes()),'entry_count':len(z.namelist()),'internal_hashes_verified':len(mm)}
# Verify lineage append-only, exact novelty
with zipfile.ZipFile(paths['C40']) as z:
 a=set(z.read('C40_859_DISTINCT_PAGE_IDS.txt').decode().split()); assert len(a)==859
with zipfile.ZipFile(paths['C42']) as z:
 b=set(z.read('C42_UNIAO_870_PAGE_IDS.txt').decode().split()); assert len(b)==870
assert a<b and len(b-a)==11;checks+=3
# Original F0 archive readback and manifest 19 SHA; SHA of root immutable
oldf0=base/'dmg_c40_inputs/DMG_F0_CONTINUIDADE_SNAPSHOTS_HOLDOUT_20261016_MESTRE_ONLY.zip'
assert sha(oldf0.read_bytes())=='e9c135284d7bf8630d80457a1eed334e9bdbdf20279721ce872daf6fba3bdcd2';checks+=1
with zipfile.ZipFile(oldf0) as z:
 assert z.testzip() is None;checks+=1
 m=json.loads(z.read('MANIFEST_SHA256.json'))['contents']
 assert len(m)==19;checks+=1
 for obj in m:
  body=z.read(obj['path']);assert len(body)==obj['bytes'] and sha(body)==obj['sha256'];checks+=2
# Read semantic checkpoints and assert all holds persist
for name in ['C40','C41','C42','C43']:
 with zipfile.ZipFile(paths[name]) as z:
  x=json.loads(z.read(name+'_CHECKPOINT.json'))
  assert x.get('operation')=='OP-DMG-CORPUS-EMP-01' or (name=='C40' and x.get('checkpoint','').startswith('C40-OP-DMG-'));checks+=1
  assert '4/8' in x['F0'];checks+=1
  assert 'HOLD' in (x.get('F6') or x.get('global_d0') or 'HOLD') or str(x.get('F6')).startswith('0/');checks+=1
# flatten
with (p/'C44_ARCHIVE_READBACK_LINEAGE.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
status={
'operation':'OP-DMG-CORPUS-EMP-01', 'campaign':'C44',
'last_verified':'5 archives C39-C43 sha/CRC; 4 Library byte readbacks C40-C43; 19 original F0 historic sha; 870 lineage',
'first_pending':'A5 private bytes 0/7, A7 genuine fresh blind cohort, A8 independent second human reviewer / Notion writer; F6 positive real effect with no damage but RE/FIP/action/PA/target sufficient',
'F0':'4/8 documentary HOLD', 'A5':'7 signed refs but 0 postupload bytes', 'A6':'870 scoped Notion physical IDs; global D0 HOLD',
'A7':'8 historic reserved cannot be certified blind; not fit future v2',
'A8':'no independent human double-coder, no writer/epoch/lease',
'F6':'0/11 targeted C40; 0/11 targeted C42; no legal fallback demonstrated',
'F7_to_F18':'not promoted','V2':'not proposed/promoted',
'Official':'DMG-RANK-01 v1.1 unchanged', 'Party_OPrimeiro':'NO-WRITE',
'master_only':'yes', 'new_source_pages_current_cycle':22,
'unique_scoped_ids_C39':848,'unique_scoped_ids_C44':870,
'check_count':checks,'archive_checksums':summ,'root_historical_F0_entries':20,'root_historical_F0_internal_hashes':19,
'no_repeat':'C22-C44; G1 411; C29 88; C30 49; C31 251; C32 799; C33 14; C34 35; C35-39 prior; C40 11; C41 math4; C42 11; C43 math3.'}
(p/'C44_FAST_RESUME_CHECKPOINT.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
report=f'''# PSV DMG C44 — Readback físico C40–C43 e sucessão científica (MESTRE-SIDE)

**OP EXISTENTE:** OP-DMG-CORPUS-EMP-01; **baseline:** DMG-RANK-01 v1.1 vigente, imutável nesta execução. **Autoridade:** Mestre autorizou sucessão científica; Notion OP/Diário/Inbox, fichas, Party, O Primeiro e VLAB **NO-WRITE** por inexistência de prova de writer/lease. Resultados semântico/científico TEST, nenhum ajuste homologado ou v2.

## Recebimento físico e validação do pacote completo
O C44 releu **cinco arquivos ZIP** C39–C43 do filesystem preservado: CRC em 5/5, integridade dos hashes internos dos manifestos, e **quatro arquivos C40–C43** que haviam sido publicados na Biblioteca Mestre foram baixados novamente e comparados **byte-a-byte com o ZIP de origem (4/4)**. A verificação de C39 está aqui para encadear com a campanha anterior, não reapresentar 7 ZIP históricos C32–C38 como novos testes.

Foi revalidado separadamente o pacote F0 de 16/10: **20 entradas, 19/19 hashes/tamanhos do manifesto fisicamente verificados** e SHA de arquivo raiz `e9c135284d7bf8630d80457a1eed334e9bdbdf20279721ce872daf6fba3bdcd2`. O F0 ZIP NÃO contém os sete arquivos Markdown anexados depois ao Notion; não foi usado para fabricar 7/7 readback.

**{checks} asserts locais PASS** (checksum/cadeia/persistência de HOLD), leitura de 5/5 ZIP, readback de 4/4, 19/19 arquivos F0, verificações de não repetição 859 → 870 e existência de checkpoints. Manifests e cadeia de custódia estão no CSV.

## Linha de produção C39→C44 e produtos científicos
- **C39 antes:** 848 Page-IDs no recorte de Mestre, F0 4/8 HOLD.
- **C40 depois:** +11 fontes dirigidas Mestre, 859 IDs; 7/7 links privados A5 resolvidos/0 bytes; mudança de timestamp da regra Criação de Ficha identificada, seis outras autoridades com timestamp original; 8 reservas A7 indexadas e histórico não blindado; 0/11 casos F6 admissíveis na amostra.
- **C41:** 4 fontes de itens Semicanônicos/Incubação; 24 PMF exatas de RD em quatro pools +21 negativos defensivos Selo, **197 checks**, nenhuma nova ficha física.
- **C42:** +11 páginas do espelho Mestre `Magias — Chen Yi-Min`, 870 IDs no recorte (NÃO global D0); 3 contradições internas literal (Defesa Vento V3, Frio Eterno V3, Coluna Gelo V2); nenhuma escrita Party e nenhuma fórmula sobrescrita.
- **C43:** 315 cenários algébricos condicionais DoT, 5 de congelamento, fila de 3 decisões pendentes em ficha original, **800 checks**. Não é playtest VLAB nem solução automática de regras conflitantes.

**Total Page-ID físico no recorte:** 870, com 22 novas fontes individuais realmente lidas nesta sucessão após C39, sem duplicatas; múltiplas formas e técnicas não são entidades independentes para estatística de efeito. **D0 global F0-A6 continua PENDENTE.**

## Gate proporcional / não-aceite global
| Eixo | Estado após C44 | Motivo |
|---|---|---|
| Integridade de pacotes C40–C43 | PASS local | hash/CRC, byte readback, scripts TEST |
| F0 (documental) | **4/8 HOLD** | pré-registro parcial, sem blindagem e writer |
| A5 | **0/7 bytes POST-UPLOAD** | roteamento privado impede baixar bytes dos anexos A5; localizador ≠ SHA |
| A6 | **870 Page-IDs de escopo** | resto do Notion e identidade/famílias globais não fechados |
| A7 | **HOLD** | oito casos reservados anteriormente não têm prova de cegamento vitalício; precisa novo holdout agrupado |
| A8 | **HOLD** | sem codificador humano realmente independente e sem escritor/lease/epoch notional |
| F6 | **HOLD** | não há caso ofensivo original válido sem dano, mas com RE/FIP próprio e ação/custo/entrega totalmente comprovados |
| F7–F18 / candidata v2 | **NÃO HOMOLOGADOS** | sem calibração, validação humana, playtest e aprovação |

## Próxima fronteira real (não repetir o conhecido)
**LAST-VERIFIED:** C44 readback 5/5 arquivos e 19/19 original F0, ligação 859→870. **FIRST-PENDING:** A5 obter bytes por canal privado legítimo e confrontar hashes/edições; buscar fonte F6 ofensiva válida fora da Party e holdout, não inventar FIP; A7 preseal novo em famílias não expostas antes de calibrar, com segundo pesquisador humano e prova de exclusão de aliases; A8 resolver atribuição de writer/lease/epoch com autoridade para OP/Diário. Depois ampliar A6 por classes de habilidades não auditadas; avisar Mestre só ao alcançar decisão efetivamente necessária.

**NAC-PASS aplicado:** PASS de integridade dos artefatos e álgebra local, **NO-PASS F0/F6/norma global**. Não usar esses resultados para aplicar dano novos em sessão até autoridades competentes resolverem as divergências.
'''
(p/'C44_PSV_CONSOLIDADO_MESTRE_ONLY.md').write_text(report,encoding='utf8')
# immutable package
fs=[p/'C44_ARCHIVE_READBACK_LINEAGE.csv',p/'C44_FAST_RESUME_CHECKPOINT.json',p/'C44_PSV_CONSOLIDADO_MESTRE_ONLY.md']
manifest={x.name:{'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in fs}
(p/'C44_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
with zipfile.ZipFile(p/'DMG_C44_CHECKPOINT_AUDITORIA_F0_C40_C43_MESTRE_ONLY.zip','w',zipfile.ZIP_DEFLATED) as z:
 for x in fs+[p/'C44_MANIFEST.json',p/'build_c44.py']:z.write(x,x.name)
with zipfile.ZipFile(p/'DMG_C44_CHECKPOINT_AUDITORIA_F0_C40_C43_MESTRE_ONLY.zip') as z:
 assert z.testzip() is None
 for n,v in manifest.items():assert sha(z.read(n))==v['sha256']
print('C44 PASS',checks,'checks, 5 ZIP roots, 4 byte readbacks; 19 original F0 SHA; scope 870')
