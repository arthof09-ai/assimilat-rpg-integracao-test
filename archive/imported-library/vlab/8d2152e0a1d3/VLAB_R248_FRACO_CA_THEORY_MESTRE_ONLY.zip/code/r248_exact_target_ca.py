#!/usr/bin/env python3
"""R248 controlled mathematical target CA sensitivity; no R18 executions, no canonical claims."""
import collections,hashlib,itertools,json
from fractions import Fraction
from pathlib import Path
ROOT=Path('/mnt/data');OUT=ROOT/'VLAB_R248_FRACO_CA_THEORY_MESTRE_ONLY'
F=ROOT/'VLAB_R240_FRACO_PAIRS_MESTRE_ONLY/sources/R234_BEAST_FROZEN_EXCERPTS.json'
S=json.loads(F.read_text());B=S['beasts'];src_damage_bonus=B['C']['attack_bonus'];actual_ca=B['G']['ca']
assert src_damage_bonus==134 and actual_ca==153 and B['C']['ordinal']==23
c=collections.Counter(map(sum,itertools.product(range(1,7),repeat=6)));all_=6**6
assert sum(c.values())==all_
case_list=sorted(set([135,140,145,150,152,153,154,155,156,158,160,162,165,170,175]))
rows=[]
for ca in case_list:
 # 1 common roll for normal; weak takes lower of two and -2: the 2nd is a reserved independent draw.
 normal=Fraction(sum(n for s,n in c.items() if s+src_damage_bonus>ca),all_)
 one_weak=Fraction(sum(n for s,n in c.items() if s+src_damage_bonus-2>ca),all_)
 weak=one_weak**2
 assert weak<=normal
 rows.append({'CA':ca,'normal_attack_success_crit_excluded':str(normal),'weak_attack_success_crit_excluded':str(weak),'weak_minus_normal':str(weak-normal),'prob_normal_hit_weak_miss':str(normal-weak),'p_normal_float':float(normal),'p_weak_float':float(weak)})
row=next(x for x in rows if x['CA']==153)
from math import sqrt
obsN=Fraction(88,128);obsW=Fraction(27,128)
# Not a p-value for a fixed rule; descriptive checking of Monte Carlo deviation.
Sreport={'stage':'R248','result':'PASS_EXACT_6D6_MATHONLY_WITH_SOURCE_CA','source_sha256':hashlib.sha256(F.read_bytes()).hexdigest(),'actor_C_attack_bonus':134,'actor_G_CA':153,'classification':'Lendario 3, source VZ-PRECREATE-NONP4','dice':'6d6 (rank Lendário)','pair_samples_in_R240':128,'normal_success_observed':str(obsN),'weak_success_observed':str(obsW),'normal_success_crit_excluded_theoretical':row['normal_attack_success_crit_excluded'],'weak_success_crit_excluded_theoretical':row['weak_attack_success_crit_excluded'],'approximation_warning':'exact for attack-roll mechanism only; excludes sequential critical overrides, source actions, HP and reactions; R240 has its own true native ledger','scenario_count':len(rows),'official_cells':0,'new_native_turns':0,'terminal_contracts':0,'canonical_writes':0}
(OUT/'reports/R248_THEORETICAL_TARGET_CA_SWEEP.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False))
(OUT/'reports/R248_SUMMARY.json').write_text(json.dumps(Sreport,indent=2,ensure_ascii=False))
print(json.dumps(Sreport,indent=2,ensure_ascii=False))
