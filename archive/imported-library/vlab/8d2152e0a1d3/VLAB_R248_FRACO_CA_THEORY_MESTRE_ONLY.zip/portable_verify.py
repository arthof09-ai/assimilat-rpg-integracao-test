#!/usr/bin/env python3
"""Independent portable hash gate for this self-contained evidence ZIP or extracted directory."""
import hashlib,json,sys,zipfile
from pathlib import Path
def check(reader,names):
 m=json.loads(reader('SHA256_MANIFEST.json'))['files']
 assert set(m)==set(names)-{'SHA256_MANIFEST.json'}, 'MANIFEST_FILESET_MISMATCH'
 for name,digest in m.items(): assert hashlib.sha256(reader(name)).hexdigest()==digest, name
 return len(m)
if __name__=='__main__':
 p=Path(sys.argv[1])
 if p.is_file():
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   count=check(z.read,z.namelist())
 else:
  files=[str(q.relative_to(p)) for q in p.rglob('*') if q.is_file()]
  count=check(lambda name:(p/name).read_bytes(),files)
 print(json.dumps({'status':'PASS_HASH_CRC_EXACT_FILESET','files':count}))
