#!/usr/bin/env python3
"""R247: exact paired-inference audit of original R240 clusters; no simulations."""
import collections,hashlib,json,math
from fractions import Fraction
from pathlib import Path
SRC=Path('/mnt/data/VLAB_R240_FRACO_PAIRS_MESTRE_ONLY/reports/R240_RUN_RAW.json')
OUT=Path('/mnt/data/VLAB_R247_FRACO_PAIRED_EXACT_INFERENCE_MESTRE_ONLY')
x=json.loads(SRC.read_text())
assert x['arm_runs']==256 and x['seed_clusters']==128
pairs=collections.defaultdict(dict)
for r in x['results']:
 assert r['arm'] in ('EXACT_558','BELOW_557')
 assert r['arm'] not in pairs[r['seed']]
 pairs[r['seed']][r['arm']]=r
assert len(pairs)==128 and all(len(p)==2 for p in pairs.values())
counts=collections.Counter();diffs=[];scores=[];details=[]
for seed,arms in sorted(pairs.items()):
 e,w=arms['EXACT_558'],arms['BELOW_557']
 assert e['weak'] is False and w['weak'] is True
 assert e['hp']==558 and w['hp']==557
 assert e['speed']=='50' and w['speed']=='25'
 k=(bool(e['hit']),bool(w['hit']));counts[k]+=1
 diffs.append(w['damage']-e['damage']); scores.append(w['score']-e['score'])
 details.append({'seed':seed,'normal_hit':bool(e['hit']),'fraco_hit':bool(w['hit']),'score_normal':e['score'],'score_fraco':w['score'],'damage_normal':e['damage'],'damage_fraco':w['damage'],'pair_damage_diff':w['damage']-e['damage']})
assert counts[True,True]==27 and counts[True,False]==61 and counts[False,True]==0 and counts[False,False]==40,counts
# Exact conditional McNemar for paired binary discordance b=61, c=0.
b=counts[True,False];c=counts[False,True]
assert b+c==61
mcnemar_exact_two_sided=Fraction(2,2**(b+c))
mean_effect=Fraction(sum(int(x['fraco_hit'])-int(x['normal_hit']) for x in details),len(details))
assert mean_effect==Fraction(-61,128)
# paired damage changes and inconclusive cases
mean_damage=Fraction(sum(diffs),128)
assert mean_damage==Fraction(-2102,128)
assert max(scores)<=0 # weak penalty can only reduce outcome in this frozen seed pairing
# pure exact paired Hodges-Lehmann? Not needed; preserve cluster dependence.
independence_assertion={'unit':'seed_pair','independent_seed_clusters':128,'dependent_arms_per_seed':2,'raw_runs':256,'not_independent_runs':256,'no_new_combat':True}
summary={'stage':'R247','status':'PASS_EXACT_PAIRED_INFERENCE_R240_READONLY','normal_hit_count':88,'weak_hit_count':27,'both_hit':counts[True,True],'normal_only':b,'weak_only':c,'neither_hit':counts[False,False],'exact_mcnemar_two_sided_p':str(mcnemar_exact_two_sided),'hit_delta_weak_minus_exact':str(mean_effect),'damage_delta_weak_minus_exact':str(mean_damage),'number_of_seed_clusters':128,'test_interpretation':'strong within-fixture paired evidence; not generalizable to other ranks, equipment, actors or Party','source_status':'VZ_PRECREATE_NONP4','source_report_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'new_combat_commits':0,'terminal_contracts_certified':0,'official_cells':0,'canonic_writes':0,'design':independence_assertion}
(OUT/'reports/R247_STATS.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
(OUT/'reports/R247_128_SEED_PAIR_EVIDENCE.json').write_text(json.dumps(details,indent=2,ensure_ascii=False))
print(json.dumps(summary,indent=2,ensure_ascii=False))
