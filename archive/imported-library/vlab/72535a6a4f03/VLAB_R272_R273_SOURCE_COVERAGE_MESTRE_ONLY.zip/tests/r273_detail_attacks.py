"""Mutate only last archived event DETAIL, recompute local journal hash, require science auditor denial."""
from pathlib import Path
import contextlib,importlib,json,os,sqlite3,shutil,sys,tempfile
stage=sys.argv[1];R=Path(sys.argv[2]).resolve()
modules={'234':('r234_source_complete_beast_battle','r234_independent_readonly_audit'),
         '235':('r235_beast_magic_vs_basic','r235_independent_readonly_audit'),
         '236':('r236_weak_hp0_native_beasts','r236_independent_readonly_audit')}
name,aname=modules[stage]
sys.path[:0]=[str(R/'code'),str(R/'runtime/native'),str(R/'runtime/fusion_stage12')]
m=importlib.import_module(name);a=importlib.import_module(aname)
if stage=='234':
 cases=[('FLIP_HIT',lambda d:d.update(hit=not d['hit']),None),('ADD_LOSS',lambda d:d.update(hp_loss=d['hp_loss']+1),None),('FORGE_NEXT_ACTOR',lambda d:d.update(new_active='STRANGER'),None)]
elif stage=='235':
 cases=[('FORGE_FOCUS_GROSS',lambda d:d.update(gross_damage=d['gross_damage']+1),'SAVE_FOCUS'),('FORGE_FOCUS_ROUNDING',lambda d:d.update(rounding='FAKE_RULE'),'SAVE_FOCUS'),('FORGE_STATS_PA',lambda d:d['stats'].update(pa_spent=d['stats']['pa_spent']+1),'PHYSICAL'),('FORGE_TURN_ACTOR',lambda d:d.update(who='STRANGER'),'PHYSICAL')]
else:
 cases=[('FLIP_HIT',lambda d:d.update(hit=not d['hit']),None),('ADD_LOSS',lambda d:d.update(actual_hp_loss=d['actual_hp_loss']+1),None),('FORGE_TARGET',lambda d:d.update(to='WRONG_TARGET'),None),('FORGE_NEXT_ACTOR',lambda d:d.update(active_after='STRANGER'),None)]
rows=[]
for label,attack,filter_arm in cases:
 with tempfile.TemporaryDirectory(prefix=f'R273_{stage}_{label}_') as temp:
  t=Path(temp);shutil.copytree(R/'sources',t/'sources');shutil.copytree(R/'evidence/db',t/'evidence/db')
  choices=sorted((t/'evidence/db').glob('*.sqlite'))
  if filter_arm:choices=[x for x in choices if filter_arm in x.name]
  assert choices
  db=choices[0]
  with sqlite3.connect(db) as c:
   seq,raw=c.execute('SELECT seq,row_json FROM events ORDER BY seq DESC LIMIT 1').fetchone()
   row=json.loads(raw);attack(row['detail'])
   digest=m.j.sha(row)
   c.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=?',(m.j.canonical(row),digest,seq))
   c.execute('UPDATE meta SET value=? WHERE key="head"',(digest,))
  c.close() # sqlite3's context manager commits but does not close or release WAL.
  # Test generic journal in a separate copy: its SQLite connection may create WAL sidecars.
  generic_db=t/'GENERIC_ONLY.sqlite';shutil.copyfile(db,generic_db)
  try:
   m.j.load(str(generic_db),source_initial_authority=m.source_initial_authority)
   generic='ACCEPTED_REHASHED_NON_SOURCE_DETAIL'
  except Exception as e:generic='DENIED_GENERIC:'+str(e)[:100]
  try:
   with contextlib.redirect_stdout(open(os.devnull,'w')):a.audit(t,write=False)
   strict='UNSAFE_PASS'
  except AssertionError as e:strict='DENIED_SOURCE:'+str(e)
  except Exception as e:strict='ERROR_NON_ASSERT:'+repr(e)
  assert strict.startswith('DENIED_SOURCE:'),(stage,label,generic,strict)
  rows.append({'label':label,'generic':generic,'independent_source_auditor':strict,'db':db.name})
print(json.dumps({'stage':stage,'cases':len(rows),'results':rows,'all_blocked':True},ensure_ascii=False,indent=2))
