"""R272 source-anchored negative tests for pre-existing R234/R235/R236 - no canonical writes."""
from pathlib import Path
import contextlib,hashlib,importlib,json,os,shutil,sqlite3,sys,tempfile,traceback
STAGE=sys.argv[1]
ROOT=Path(sys.argv[2]).resolve()
SCENES={'234':('r234_source_complete_beast_battle','r234_independent_readonly_audit'),
        '235':('r235_beast_magic_vs_basic','r235_independent_readonly_audit'),
        '236':('r236_weak_hp0_native_beasts','r236_independent_readonly_audit')}
assert STAGE in SCENES
sys.path[:0]=[str(ROOT/'code'),str(ROOT/'runtime/native'),str(ROOT/'runtime/fusion_stage12')]
name,auditname=SCENES[STAGE]
m=importlib.import_module(name)
a=importlib.import_module(auditname)
D=sorted((ROOT/'evidence/db').glob('*.sqlite'))
assert len(D)=={'234':8,'235':20,'236':12}[STAGE]
reports=[]

def expect_hold(label, action):
    try:action()
    except Exception as err:
        # Journal load errors must be controlled LabHold, auditors should signal source assertion.
        assert isinstance(err,(m.j.LabHold,AssertionError)),(label,repr(err),type(err))
        reports.append({'case':label,'status':'DENIED','reason':str(err)[:145]});return
    raise AssertionError('UNSAFE_ACCEPT:'+label)

def with_db(label, mutate, *, method='journal'):
    with tempfile.TemporaryDirectory(prefix=f'VLAB_R272_{STAGE}_{label}_') as td:
        p=Path(td)/D[0].name;shutil.copyfile(D[0],p)
        with sqlite3.connect(p) as c:
            mutate(c)
        if method=='journal':expect_hold(label,lambda:m.j.load(str(p),source_initial_authority=m.source_initial_authority))
        else:raise ValueError

# Core source-gate positives and negatives across 3 distinct preregistered fixture families.
for db in D:
    state,head,rev=m.j.load(str(db),source_initial_authority=m.source_initial_authority)
    assert rev>0 and state['synthetic'] is True
reports.append({'case':'VALID_ALL_HISTORICAL_SQLITE','status':'PASS','count':len(D)})
expect_hold('FAIL_CLOSED_NO_SOURCE_AUTHORITY',lambda:m.j.load(str(D[0])))
with_db('REJECT_UNREGISTERED_SEED', lambda c:c.execute("UPDATE meta SET value=json_set(value,'$.seed',99999123) WHERE key='state'"))
with_db('REJECT_SCENE_SPOOF', lambda c:c.execute("UPDATE meta SET value=json_set(value,'$.scene','UNAUTHORIZED') WHERE key='state'"))
with_db('REJECT_FOREIGN_GENESIS', lambda c:c.execute("UPDATE meta SET value=? WHERE key='genesis'",('a'*64,)))
with_db('REJECT_INITIAL_WOUNDED_HP_TAMPER',lambda c:c.execute("UPDATE meta SET value=json_set(value,'$.actors.C.hp',999999) WHERE key='state'"))
with_db('REJECT_STATE_NOT_OBJECT',lambda c:c.execute("UPDATE meta SET value='[]' WHERE key='state'"))

def frozen_temp():
    td=tempfile.TemporaryDirectory(prefix=f'R272_{STAGE}_AUDIT_')
    root=Path(td.name)
    shutil.copytree(ROOT/'sources',root/'sources')
    shutil.copytree(ROOT/'evidence/db',root/'evidence/db')
    return td,root
with contextlib.redirect_stdout(open(os.devnull,'w')):
    baseline=a.audit(ROOT,write=False)
reports.append({'case':'INDEPENDENT_ORIGINAL_AUDIT','status':'PASS','total_dbs':len(D)})
for label,mod in [('REJECT_SOURCE_GENESIS_FORGERY','genesis'),('REJECT_FIRST_SNAPSHOT_FORGERY','first'),('REJECT_WAL_SIDECAR','wal')]:
    td,rt=frozen_temp()
    try:
        db=rt/'evidence/db'/D[0].name
        if mod=='genesis':
            with sqlite3.connect(db) as c:
                c.execute('UPDATE meta SET value=? WHERE key="genesis"',('f'*64,))
        elif mod=='first':
            with sqlite3.connect(db) as c:
                seq,body=c.execute('SELECT seq,row_json FROM events ORDER BY seq LIMIT 1').fetchone()
                row=json.loads(body);row['before_sha']='b'*64
                c.execute('UPDATE events SET before_sha=?,row_json=?,row_sha=? WHERE seq=?',('b'*64,m.j.canonical(row),m.j.sha(row),seq))
        else:
            Path(str(db)+'-wal').write_bytes(b'TEST_NOT_A_REAL_WAL')
        if mod!='wal':c.close() # sqlite3 context manager commits but does not close the connection.
        def audit_func():
            with contextlib.redirect_stdout(open(os.devnull,'w')):return a.audit(rt,write=False)
        expect_hold(label,audit_func)
    finally:td.cleanup()
print(json.dumps({'stage':STAGE,'test_cases':len(reports),'results':reports,'all_passed':True},indent=2,ensure_ascii=False))
