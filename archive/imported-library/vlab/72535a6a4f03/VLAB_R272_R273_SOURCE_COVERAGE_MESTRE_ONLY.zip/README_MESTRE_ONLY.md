PSV — VLAB R272/R273 — MESTRE-SIDE / TEST — patch incremental, NÃO outro motor

OP existente: OP-VLAB-FUSION-SANDBOX-01. LAST: R271; este pacote: R272 (fonte/política), R273 (auditor READ-ONLY). PRÓXIMO: R274 candidato. Sem identidade de instância/writer/lease/epoch/fencing demonstrada. Notion OP/Diário/Inbox, Party/O Primeiro, DMG, LEVEL-UP, fichas vivas e produção: NO-WRITE.

ACHADO: A correção de gênese R269 validou apenas R237/R239/R240; R234/R235/R236 ainda usavam o núcleo R18 original. Aplicar R269 diretamente bloqueava esses experimentos PRECREATE. R272 introduz em cada adaptador EXISTENTE um source_initial_authority com seed/arm/pre-reg/fonte fechados. Nenhuma autorização genérica ou reprocessamento dos ZIPs originais. R273 fortalece cada auditor CIENTÍFICO existente, sem importar o motor.

CONTRA-FORÇA: os autores hipotéticos com acesso a todos os artefatos poderiam reescrever fontes e manifestos; SHA local não é assinatura externa. Os 40 primeiros hashes de snapshot foram obtidos dos bancos congelados nos três ZIPs verificados e fixados nos PATCHES + manifesto desta entrega. Essa é uma âncora de proveniência do ZIP, não garantia externa contra adversário capaz de substituir o release inteiro.

UNIDADES TESTADAS:
R234: 8/8 SQLite byte-exact, 120 commits, 500 eventos nativos, 8 CENSORED_HORIZON.
R235: 20/20 SQLite byte-exact, 196 commits, 816 eventos nativos, 16 censuras por horizonte + 4 conjurações focais. Sem reclassificar 4 casts em 4 combates.
R236: 12/12 SQLite byte-exact, 59 commits, 264 eventos nativos, 12 paradas HP0 LAB (NÃO morte de RPG).
Total: 40 bancos históricos, 375 commits, 1580 eventos já existentes; R272 apenas reproduziu os mesmos dados, 0 combates novos oficiais.
Cada pacote histórico passou seu auditor original e o auditor R273 reforçado. Source-adapters aprovaram 33 controles dirigidos no conjunto das três coortes (incluindo 27 controles de negativa); após teste de sidecar, fonte, seed, gênese e first-event anchor, os 11 resumos semanticamente adulterados mas rehashed foram ACEITOS pelo journal genérico e NEGADOS pelos auditores independentes próprios. A responsabilidade pela verdade física das ações fica no auditor de fonte, nunca no SHA sozinho.
Núcleo único: arquivo runtime/fusion_stage12/vlab_r18_interactive.py original SHA f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368; patch cumulativo R269 obtido do pacote R267_R271 existente. Núcleo corrigido SHA 7d067adb99fe1f9e59e3c79791564c9c8e18b2d0f52c41339550ba1c09a94bd9. NÃO incluir/reescrever cópias históricas. Regressões confirmadas nesse mesmo código em cópia R18 independente: 8 testes originais + 54 testes do delta R266 PASS.

APLICAÇÃO EM CLONE ISOLADO, uma coorte de cada vez:
1. Materialize o ZIP HISTÓRICO exato R234/R235/R236 da Biblioteca e confira o SHA no arquivo sources/HISTORICAL_SOURCE_ARCHIVE_PINS.json. Extraia apenas em sandbox TEST novo. Não sobrescreva evidências originais.
2. Aplique patch/R269_CUMULATIVE_R18_TO_R269.patch do pacote R267–R271 na RAIZ runtime/ usando patch -p1 (somente se o módulo estiver no hash ORIGINAL f133...; nunca duas vezes). Esse arquivo R269 não é duplicado neste release.
3. Aplique patch/R234_SOURCE_ADAPTER.patch e patch/R234_INDEPENDENT_AUDITOR.patch na RAIZ da cópia R234 com patch -p1 (ou correspondentes R235 ou R236). Preserve a versão original externa como baseline.
4. Para reproduzir, num CLONE sem bancos: remova SOMENTE os bancos da cópia, execute python code/r234_source_complete_beast_battle.py, ou R235/R236, compare SHA dos bancos com os ZIPs originais. Nunca execute esses scripts dentro do arquivo autoritativo ou no pacote publicado.
5. Para testar apenas integridade e fonte sem execução, execute o auditor existente python code/r234_independent_readonly_audit.py; os auditores R273 exigem SQLite fechado sem -wal/-shm ativos. Em TEST clone rode python tests/r272_adversarial_tri.py 234 /path/clone_r234 e python tests/r273_detail_attacks.py 234 /path/clone_r234.

PROVENIÊNCIA: patches verificáveis, SHA e scripts de negativos aqui; bancos históricos e executores completos não são redistribuídos. Os relatórios já distinguem campo DERIVADO, TEST, QUARENTENA, NORM HOLD. Nenhum de 17 contratos tem certificação terminal e zero células R91: 0/17; 0/1875. Nenhuma decisão de desempate de iniciativa, crítico negativo, encerramento HP0, P4 Besta nem E item foi feita.

INBOX: últimos envelopes IBX-160 e IBX-152 (GitHub gratuito opcional), IBX-138 (encaminhamento integral), IBX-120 (interfaces consultivas). Perfil CM000006 PAUSED, 14 ACKs requeridos sem writer, não editar Inbox. GH-CI NOT-RUN; testes foram locais, sem custo extra.

NEXT R274: atacar primeiro fontes completas P4/ação/reação/custos ou conectar a interface legítima de leitura do LEVEL-UP quando houver versão proveniente. Repetir patches R272 por contagem de estágios não é objetivo; o trabalho dos 17 contratos exige novas funcionalidades e aceite independente. Antes de iniciar, checar colisões de unidade e novos avisos Inbox.
