from pathlib import Path
import zipfile,json,hashlib,sys
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
if p.is_file():
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  man=json.loads(z.read('SHA256_MANIFEST.json'))
  assert set(z.namelist())==set(man['files'])|{'SHA256_MANIFEST.json'}
  for name,expected in man['files'].items():
   assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
else:
 man=json.loads((p/'SHA256_MANIFEST.json').read_text())
 for name,expected in man['files'].items():
  assert hashlib.sha256((p/name).read_bytes()).hexdigest()==expected,name
print(json.dumps({'result':'PASS_BYTES_ONLY','number_of_files':len(man['files']),'NAC_PASS_TERMINAL':'HOLD'},ensure_ascii=False))
