# VLAB R34 — PRIMEIRO COMBATE COMPLETO ENTRE DUAS BESTAS REAIS (SANDBOX MESTRE-SIDE)

**Operação persistente:** CM-000006 · OP-VLAB-FUSION-SANDBOX-01. **Natureza:** execução científica real-fonte, não evento da campanha. **Baseline:** R27 ANTES, R28–R33 intactas; DMG-RANK-01 v1.1 inalterada. **Data:** 15/10/2026.

## 1. Ordem e decisão nova — VERIFICADA FISICAMENTE

A proposta da R33 para Investida da Cabra foi aprovada expressamente pelo Mestre **com alteração exclusiva da distância do empurrão**: em lugar de 1 bloco fixo, **1,5 m para cada 300 pontos de Força Física**. Permanecem as decisões específicas P1–P6: Luta+6 somente nesta Investida (somente acerto), ataque natural impacto corpo a corpo contra adjacente, uma Ação Padrão, 0 PA extra, aproximação por Movimento normal sem corrida mínima, empurrão quando acertar e causar dano líquido positivo, sem salvaguarda adicional, direção para longe, obstáculos bloqueiam sem dano extra, deslocamento forçado não provoca ataque de oportunidade, iniciativa +0 para ambos somente neste LAB e decisão deliberada de nenhuma Reação voluntária com renovação dos slots pelo R26.

A decisão foi registrada e fisicamente reaberta na [OP original](https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2) com última edição observada `2026-10-15T18:10:59.687Z`. Não se criou regra universal nem se modificou a ficha da Cabra. Fonte da fórmula FF: [Criação de Ficha](https://app.notion.com/p/3ebc2b324ede81449222f3c06b840613), `FF=(FOR+DES+CON)×10`; para a Cabra `FOR13 + DES8 + CON10 =31`, **310 FF**, logo o primeiro marco completo de 300 autoriza **1,5 m** neste exemplo. Arredondamento geral para outros números de FF não foi normatizado por esta execução.

## 2. Fontes oficiais reabertas e snapshots

- **Frígido Ossário Bronze5:** [página](https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315), FOR18/DES18/CON15, Vida125, Alma120, CA31, Rabada `1d6+FOR`; Luta+6 e demais campos da Rabada por decisão expressa R31–R32, exclusiva da habilidade.
- **Cabra de Chifres Bronze1:** [página](https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6), FOR13/DES8/CON10, Vida38, Alma22, CA20, Investida `1d6+FOR` de impacto e empurrão; Luta+6 e demais campos exclusivamente pela decisão R34.
- **Criação de Besta atual:** RD normal Bronze5; velocidade Bronze `8+DES/4` → **12,5 m** para Frígido e **10 m** para Cabra. Não houve movimento necessário na luta observada. Sistema de Combate autoriza ataque normal com Ação Padrão, turnos/reação/críticos. As decisões individuais de habilidade prevalecem no seu escopo, sem recalcular os HP/CA legados da fonte.

Os arquivos de autoridade da R32 e R34 são envelopes locais derivados da observação após reabertura; **não** são assinaturas digitais emitidas pelo Notion. Última edição das duas fichas após a execução permaneceu em outubro 1 às `18:00:42.693Z` e `18:00:34.040Z` respectivamente. A cena experimental é `LAB-REAL-MASTER-FONTE-AUTENTICADA-NONCAN` com células adjacentes a 1,5 m, arena aberta sem obstáculos e sem escrita nos estados persistentes das fontes.

## 3. Execução — VERIFICADA POR RECIBO NATIVO E REPLAY

**Semente única pré-declarada:** 347. **Banco novo e exclusivo:** `runs/R34_REAL_SOURCE_FULL_FIGHT_SEED347.sqlite`. Mesmo motor: gateway real-fonte R31, `v0.8.1.apply_weapon_attack` em cada ação, scheduler `R18._next_turn`, iniciativa/renovação `R26`, SQLite WAL R18 com intenção durável e hashes encadeados. Não houve motor alternativo, importação D&D ou reescrita dos arquivos históricos. O ledger usa internamente `synthetic=true` para sinalizar **cena simulada e não-canônica**, mas os ACTORS são vinculados a IDs reais oficiais — **não** substituídos por criaturas fictícias.

**Iniciativa:** dado da Cabra 5 + DES8 + bônus LAB0 =13; dado do Frígido 2 + DES18 + bônus LAB0=20. Frígido age primeiro. Cinco turnos resolvidos, na ordem abaixo.

| Rodada | Atacante/ação | d6 de ataque | Total vs CA | d6 de dano | Dano bruto; RD; líquido | Vida final do alvo |
|---|---|---:|---|---:|---|---|
| 1 | Frígido, Rabada | 2 | 26 > CA20, ACERTO | 4 | 22; RD5; **17** | Cabra **38→21** |
| 1 | Cabra, Investida | 4 | 23 ≤ CA31, ERRO | 5 | nenhum dano aplicado | Frígido **125→125** |
| 2 | Frígido, Rabada | 6 | 30 > CA20, ACERTO | 6 | 24; RD5; **19** | Cabra **21→2** |
| 2 | Cabra, Investida | 2 | 21 ≤ CA31, ERRO | 5 | nenhum dano aplicado | Frígido **125→125** |
| 3 | Frígido, Rabada | 4 | 28 > CA20, ACERTO | 4 | 22; RD5; **17** | Cabra **2→0** |

**Encerramento:** Cabra chega a HP0 na rodada3; vencedor Frígido com Vida125, PA120. Cabra final HP0, PA22. Dano líquido total solicitado pelas três Rabadas = **53**; Vida efetivamente retirada =38; **overkill=15** no golpe final. A Cabra recebeu **dois turnos normais** e efetivamente atacou duas vezes, com Ação Padrão gasta. Não ficou paralisada artificialmente nem se contou ataque contra morto.

**Críticos:** nenhuma das cinco verificações produziu crítico positivo ou negativo; sequências e dados preservados. **Reações:** ambos **escolheram não anunciar Reação voluntária**, como autorizado na proposta P6, mas a renovação no início do turno próprio foi efetivamente processada pelo R26. Isso **não** equivale à remoção da Reação do jogo. **Geometria e empurrão:** posições permaneceram adjacentes; duas Investidas erraram, portanto **zero empurrões reais**. O código do empurrão de 1,5 m foi auditado separadamente em estado descartável (acerto com dano líquido positivo, erro, líquido zero e obstáculo-limite). Esses testes de ramo **não** são eventos da luta nem prova empírica de empurrão no combate.

## 4. Validação física / replay / preservação

- A primeira passagem pós-commit encontrou uma divergência **somente de representação** (`tuple` local ≠ `list` após desserialização JSON) na prévia de crítico do replay. Não se repetiu nenhuma transação. Foi ajustado exclusivamente o comparador de replay no script de extensão (sequência de 3 números serializável como `list`). O banco histórico já COMMITTED foi preservado, e o replay corrigido passou em **6/6 eventos** por reaplicação independente do núcleo histórico a partir do snapshot ANTES, verificando `detail`, `after_sha`, HP e estado final.
- Auditoria posterior em leitura comprovou **37/37 gates locais**, integridade SQLite `ok`, pending=0, revision=6, events=6, `head=fdd08c0bd4a335c288f4cd3aae739e0aed36360f7d30422704e9d045371a3dcd`.
- Banco SQLite SHA256 **`3c407b349688702cc35681f5a84135e5abb0b68252a1093e219518fb22b5cc5c`**. Checkpoint em outro SQLite por backup lógico, com `history`, head, revisão, state e replay independentes idênticos. SQLite gerado por backup **não precisa ter bytes iguais** ao WAL original para ser transacionalmente equivalente.
- R31, R32, R33 materializados de arquivos Library; respectivos ZIPs SHA256 confirmados como `98841bf...`, `20530947...` e `ceeab4d4...`, sem escrever nos originais; R27 base original e bibliotecas de regras importadas em modo de leitura. Seed53 R29 e UNKNOWN_EFFECT R27 não foram tocados. Nenhuma escrita em Party, O Primeiro, fichas oficiais, DMG-RANK e world state.

## 5. PSV — CONTADORES E LIMITES

| Métrica | ANTES R33 | DEPOIS R34 |
|---|---:|---:|
| Habilidades reais individualmente admitidas no caso | 1/2 (Rabada) | **2/2** (Rabada + Investida) |
| Combates completos entre duas Bestas reais em sandbox | 0 | **1** |
| Novos ataques nativos em R34 | 0 | **5** |
| Novos eventos nativos R34 incluindo iniciativa | 0 | **6** |
| Rodadas do primeiro combate real-fonte | 0 | **3** |
| Empurrões ocorridos efetivamente | 0 | **0** |
| Patamares representados em combate real-fonte completo | 0/25 | **2/25** (Bronze1, Bronze5) |
| Contratos VLAB terminais certificados | 0/17 | **0/17** |
| Células canônicas creditadas | 0/1.875 | **0/1.875** |
| Combates canônicos da campanha | 0 | **0** |

**Não concluir equilíbrio universal:** o ataque da Cabra com Luta+6 possui teto25 contra CA31 — probabilidade normal de acerto zero nesse repertório, independentemente dos dados de dano. O combate 3 rodadas reflete uma semente e políticas específicas, não distribuição universal nem playtest humano. A Rabada R32 segue uma ação isolada histórica, não contada novamente como combate completo. R33 mantém a iniciativa condicionada histórica, não promovida retrospectivamente. VLAB R34 é comparação ANTES (DMG v1.1) em sandbox. **NAC-PASS-02 de homologação produtiva, writer, lease, epoch, fencing e GREEN continuam HOLD.**

## 6. Próxima fronteira científica

A rotina de turnos e dois contratos reais-fonte são funcionais. Próximos testes de alto valor: dupla de Bestas **mais próximas de classificação** com fichas e habilidades integralmente admitidas (sem inventar ataques); segundo confronto com **Reações defensivas efetivamente utilizadas** e seus modificadores comprovados; ensaio de **empurrão real** contra alvo cuja CA possa ser legitimamente superada pela Investida, para observar geometricamente os 1,5 m sem adulterar a CA do Frígido; então comparação entre rank/estrela e base de benchmarks. A pendência do Rinolupo RD geral × RDF específica continua separada. Não iniciar outro motor.

**Ponto de retomada:** ledger R34 fechado na revisão6, head acima; abrir receipt/SQLite e passar auditoria de reprodução; NÃO reexecutar `main()` sobre essa transação; manter todos os pacotes históricos congelados. Próxima fronteira material é selecionar alvo compatível para teste nativo de deslocamento ou política de Reação com fonte competente; nenhum novo regulamento geral foi aprovado.
