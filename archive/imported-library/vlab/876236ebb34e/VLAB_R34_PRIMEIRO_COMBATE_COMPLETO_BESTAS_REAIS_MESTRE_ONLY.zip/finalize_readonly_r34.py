"""R34: post-commit audit only. Never calls main() or writes event_commit on live DB.
In particular, an initial replay comparison mismatch between JSON list and tuple was
fixed in the replay adapter; physical ledger was not rerun or overwritten.
"""
import copy,hashlib,json,sqlite3,tempfile,sys
from pathlib import Path
import run_full_fight_r34 as r
ROOT=r.ROOT

def save(name,obj):
 p=ROOT/'evidence'/name
 if p.exists():raise RuntimeError('AUDIT_ARTIFACT_EXISTING_HOLD')
 p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
 return p

def audit():
 if not r.DB.exists():raise RuntimeError('NO_R34_ACTIONS_TO_AUDIT')
 original_hash=r.digest(r.DB)
 st,head,rev=r.g.checked(r.DB)
 events=r.j.history(r.DB)['events']
 gen=json.loads((ROOT/'evidence'/'R34_GENESIS_BEFORE.json').read_text())['state']
 gate=[]
 def assert_gate(name,ok):
  if not ok:raise RuntimeError('AUDIT_GATE_FAILED:'+name)
  gate.append(name)
 assert_gate('two_bestas_source_readonly',set(v['source_page_id'] for v in st['actors'].values())=={r.g.BEAST_SOURCE,r.g.TARGET_SOURCE})
 assert_gate('goat_decision_scoped_master',r.authority()['luta_scope']=='GOAT_BRONZE1_INVESTIDA_ONLY_HIT_NOT_DAMAGE')
 assert_gate('goat_exactly_310FF',(13+8+10)*10==310)
 assert_gate('push_distance_1point5m_for_310FF',st['r34_battle']['geometry']['goat_push_m']==1.5)
 assert_gate('lab_initiative_zero_only',all(st['actors'][a]['stats']['init_bonus']==0 for a in r.ACTORS))
 assert_gate('fr_rabada6_goat_investida6_scope',st['actors'][r.g.AID]['stats']['luta_bonus']==6 and st['actors'][r.g.TID]['stats']['luta_bonus']==6)
 assert_gate('luta_goat_not_damage',all(e['detail']['dice']['damage_to_core']<=19 for e in events[1:] if e['detail']['actor']==r.g.TID))
 assert_gate('genuine_v081_each_turn',len(events)==6 and all(e['detail']['native']['native_resolver']=='v0.8.1.apply_weapon_attack' for e in events[1:]))
 assert_gate('R26_real_initiative_first',events[0]['detail']['historical_R26_initiative']['order'][0]==r.g.AID)
 assert_gate('goat_actually_attacked_twice',sum(e['detail'].get('actor')==r.g.TID for e in events)==2)
 assert_gate('fr_actually_attacked_thrice',sum(e['detail'].get('actor')==r.g.AID for e in events)==3)
 assert_gate('all_dice_retained',all(len(e['detail']['dice']['critical_sequence'])==3 for e in events[1:]))
 assert_gate('native_ca_and_RD',all(e['detail']['native']['effect']['ca_exact']==('20' if e['detail']['actor']==r.g.AID else '31') for e in events[1:]))
 assert_gate('fr_hit_goat_miss',[e['detail']['native']['effect']['hit'] for e in events[1:]]==[True,False,True,False,True])
 assert_gate('raw_damage_and_rd_correct',all(e['detail']['native']['effect']['rd_applied']==5 for e in events[1:] if e['detail']['native']['effect']['hit']))
 assert_gate('HP_final_right',st['actors'][r.g.TID]['resource']['hp']==0 and st['actors'][r.g.AID]['resource']['hp']==125)
 assert_gate('PA_unchanged',st['actors'][r.g.AID]['resource']['pa']==120 and st['actors'][r.g.TID]['resource']['pa']==22)
 assert_gate('R26_reaction_refresh_on_next_turn',all(e['detail']['reaction_refresh_native_R26']['after']==1 for e in events[1:-1]))
 assert_gate('reaction_declined_not_removed',all(e['detail']['reaction_consumed'] is False for e in events[1:]))
 assert_gate('movement_and_push_absent_in_REAL_fight',all(e['detail']['movement'] is None and e['detail']['forced_push'] is None for e in events[1:]))
 assert_gate('terminal_not_other_actor_attack',st['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS' and st['winner']==r.g.AID)
 assert_gate('R18_chain_revision_complete',len(events)==rev and events[-1]['hash']==head)
 con=r.j.connect(r.DB)
 try:
  integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
  pend=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
 finally:con.close()
 assert_gate('sqlite_integrity',integrity=='ok')
 assert_gate('unknown_effect_zero',pend==0)
 assert_gate('world_effects_zero',st['r34_battle']['world_effects']==0)
 assert_gate('no_invented_crit_in_fight',st['r34_battle']['negative_crits']==0 and st['r34_battle']['positive_crits']==0)
 assert_gate('no_missed_push_in_fight',st['r34_battle']['pushes']==0)
 assert_gate('no_unapproved_fight_refinement',st['r34_battle']['geometry']['normal_bronze_speed_m']=={r.g.AID:12.5,r.g.TID:10.0})
 replay=r.independent_replay(gen,events,st)
 assert_gate('independent_full_native_replay',replay['complete'] and replay['events']==rev)
 # Counterfactual geometry UNIT TEST ONLY: source facts/HP remain untouched in db.
 scratch=copy.deepcopy(st)
 scratch['r34_battle']['geometry']=r.geometry_init()
 before=copy.deepcopy(scratch)
 pushed=r.forced_push(scratch,r.g.TID,r.g.AID,{'hit':True,'net':1})
 assert_gate('push_unit_if_hit_positive',pushed is not None and pushed['distance_m']==1.5 and pushed['destination']==[-1.5,0.0])
 scratch=copy.deepcopy(before)
 assert_gate('no_push_on_miss',r.forced_push(scratch,r.g.TID,r.g.AID,{'hit':False,'net':3}) is None and scratch==before)
 scratch=copy.deepcopy(before)
 assert_gate('no_push_on_zero_net',r.forced_push(scratch,r.g.TID,r.g.AID,{'hit':True,'net':0}) is None and scratch==before)
 scratch=copy.deepcopy(before);scratch['r34_battle']['geometry']['positions'][r.g.AID]=[-19.0,0.0];scratch['r34_battle']['geometry']['positions'][r.g.TID]=[-17.5,0.0]
 try:
  r.forced_push(scratch,r.g.TID,r.g.AID,{'hit':True,'net':1})
  raise RuntimeError('EDGE_NOT_BLOCKED')
 except r.BattleHold as e:
  assert_gate('no_push_past_scene_edge',str(e)=='SCENE_EDGE_PUSH_NEEDS_INTERACTION')
 assert_gate('full_original_sqlite_immutable_audit',r.digest(r.DB)==original_hash)
 # SQLite backup: comparison by history, state, revision, chain; not binary equal.
 path=ROOT/'checkpoints'/f'R34_FULL_FIGHT_SEED{r.SEED}.sqlite'
 cp=r.checkpoint(r.DB,path)
 snap,h2,v2=r.g.checked(path)
 assert_gate('checkpoint_state_and_head',snap==st and h2==head and v2==rev)
 assert_gate('checkpoint_history_same',r.j.history(path)==r.j.history(r.DB))
 re2=r.independent_replay(gen,r.j.history(path)['events'],snap)
 assert_gate('checkpoint_independent_replay',re2['complete'] and re2['final_state_sha']==replay['final_state_sha'])
 out={'schema':'R34_INDEPENDENT_POSTCOMMIT_AUDIT_V1','status':'PASS',
     'gate_count':len(gate),'gate_names':gate,'ledger_sha256':r.digest(r.DB),
     'checkpoint_sha256':r.digest(path),'revision':rev,'head':head,
     'sqlite_integrity':integrity,'pending':pend,
     'independent_replay':replay,'second_replay_from_checkpoint':re2,
     'extra_push_unit_tests':4,'push_real_events':0,
     'replay_json_tuple_list_comparison_fixed_without_reexecuting_actions':True,
     'official_campaign_writes':0,'canonical_cell_credit':0}
 save('R34_POSTCOMMIT_INDEPENDENT_AUDIT.json',out)
 detail=[]
 for e in events[1:]:
  x=e['detail'];n=x['native']['effect'];dd=x['dice'];detail.append({
     'seq':e['seq'],'round':x['turn'],'actor':x['actor'],
     'attack_die':dd['hit_die'],'attack_total':dd['hit_total'],
     'critical_sequence':dd['critical_sequence'],'critical':dd['crit_kind'],
     'ca':int(n['ca_exact']),'hit':n['hit'],
     'damage_die':dd['damage_die'],'gross_if_hit':dd['damage_to_core'],
     'native_raw':n['raw'],'rd_applied':n['rd_applied'],
     'native_net':n['net'],'hp_before':n['before_hp'],'hp_after':n['after_hp'],
     'hp_actually_removed':n['before_hp']-n['after_hp'],
     'overkill':max(0,n['net']-(n['before_hp']-n['after_hp'])),
     'reaction_consumed':x['reaction_consumed'],
     'forced_push':x['forced_push'],'movement':x['movement']})
 receipt={'schema':'R34_FIRST_COMPLETE_REAL_SOURCE_BEAST_VS_BEAST_RECEIPT_V1',
     'type':'REAL_SOURCE_EXPERIMENTAL_BOTH_COMBATANTS_NOT_CANONICAL_CAMPAIGN',
     'seed':r.SEED,'decision_sha256':r.digest(r.AUTH),
     'r32_decision_sha256':r.digest(r.AUTH_FR),
     'source_real_ids':{r.g.AID:r.g.BEAST_SOURCE,r.g.TID:r.g.TARGET_SOURCE},
     'ledger':r.audit_schema(r.DB),'replay':replay,'checkpoint':cp,
     'new_full_fight_count':1,'native_attack_events':len(detail),
     'rounds':st['round'],'initiative':events[0]['detail']['historical_R26_initiative'],
     'attack_transcript':detail,'winner':st['winner'],'hp_before':{r.g.AID:125,r.g.TID:38},
     'hp_after':{a:st['actors'][a]['resource']['hp'] for a in r.ACTORS},
     'goat_ff':310,'approved_push_meters':1.5,'push_triggered_in_fight':False,
     'push_tested_only_in_detached_noncanonical_unit_fixture':True,
     'world_effects':0,'promotion_gate':'HOLD','terminal_contracts_VLAB':0,
     'canonical_cells':0,'sqlite_sha256':r.digest(r.DB),
     'checkpoint_sha256':r.digest(path),
     'previous_acts_R32_and_setup_R33_not_replayed_as_new':True}
 save('R34_FIRST_COMPLETE_FIGHT_RECEIPT.json',receipt)
 print(json.dumps({'status':out['status'],'gates':len(gate),'replay':replay['status'],
    'events':rev,'rounds':st['round'],'attacks':len(detail),'winner':st['winner'],
    'hp_after':receipt['hp_after'],'push_real_events':0,
    'checkpoint':cp['status'],'sqlite_sha256':receipt['sqlite_sha256']},ensure_ascii=False,indent=2))

if __name__=='__main__':audit()
