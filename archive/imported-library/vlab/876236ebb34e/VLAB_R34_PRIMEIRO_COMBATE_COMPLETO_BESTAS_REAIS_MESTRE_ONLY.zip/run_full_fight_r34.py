"""R34: real-source Goat Investida approved by Mestre (P1-P6 with FF push), native full battle.
No new combat engine. The historical v0.8.1 resolves EVERY attack; R18 journals each
turn action, R26 resolves initiative/tie and renews Reactions. Geometry only adapts
Mestre push contract, external to weapon damage, with provenance and explicit scene.
No existing database is ever resumed or overwritten by the runner.
"""
from __future__ import annotations
import sys,json,hashlib,copy,sqlite3,math,zipfile,tempfile,os
from pathlib import Path
from dataclasses import asdict
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'extension'))
sys.path.insert(0,str(ROOT/'r27'/'fusion_stage12'))
import vlab_r31_real_source_gateway as g
import vlab_r18_interactive as j
import vlab_r26_master_rulings as r26
from vlab_action_catalog_v01 import ActorActionState,AbilitySource,FrozenRuleEvidence,action_menu
from vlab_effects_v08 import Combatant,Scene,apply_weapon_attack
from vlab_rd_v08 import Resistances
SEED=347
DB=ROOT/'runs'/f'R34_REAL_SOURCE_FULL_FIGHT_SEED{SEED}.sqlite'
ACTORS=(g.AID,g.TID)
FRID=g.ACTION_ID
GOID='CABRA_INVESTIDA_MESTRE_R34_FF300'
GO_RULE='MESTRE-INVESTIDA-CABRA-B1-P1-P6-FF300-20261015'
AUTH=ROOT/'authority'/'MESTRE_INVESTIDA_R34_VERIFIED.json'
AUTH_FR=ROOT/'authority'/'MESTRE_LUTA_DECISION_VERIFIED.json'
OP='3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2'
MAX_EVENTS=30
class BattleHold(RuntimeError):pass

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_json(rel,x):
 p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
 return p

def authority():
 x=json.loads(AUTH.read_text());fr=json.loads(AUTH_FR.read_text())
 if g._validated_luta_authority(fr)!=6:raise BattleHold('FRIGIDO_MASTER_LUTA6_UNVERIFIED')
 if (x.get('master_explicit') is not True or x.get('verified_by_comestre_after_notion_readback') is not True or
     x.get('operation_page')!=OP or x.get('goat_source_page')!=g.TARGET_SOURCE or
     x.get('luta_bonus')!=6 or x.get('resulting_push_meters')!=1.5 or
     x.get('derived_goat_FF')!=310 or x.get('scope')!='NOTION_REAL_SOURCE_MASTER_LAB_NO_CANON'):
  raise BattleHold('GOAT_AUTHORITY_BINDING_FAILURE')
 if x.get('reactions')!='AVAILABLE_REFRESH_R26_BOTH_DECLINE_VOLUNTARY_REACTIONS_FIRST_BATTERY':
  raise BattleHold('REACTION_POLICY_UNAUTHORIZED')
 if x.get('damage')!='1d6+FOR13' or x.get('distance_formula')!='1.5 meters per complete 300 Forca Fisica':
  raise BattleHold('GOAT_ABILITY_UNAUTHORIZED_CHANGE')
 if x.get('push_trigger')!='HIT_AND_NET_DAMAGE_POSITIVE' or x.get('additional_PA')!=0:
  raise BattleHold('UNAUTHORIZED_EFFECT_OR_PA')
 if (g.SOURCES['goat']['for']+g.SOURCES['goat']['des']+g.SOURCES['goat']['con'])*10!=310:
  raise BattleHold('DERIVED_FF_INCONSISTENT')
 return x

def source_digest():return j.sha({'r31':g.evidence_manifest(),'goat_authority':authority(),'fr_auth':json.loads(AUTH_FR.read_text())})

def goat_source():
 return AbilitySource(GOID,'attack','STANDARD',g.TARGET_SOURCE,GO_RULE,
   'EXPLICIT-CANON',required_pa=0,target_scope='ENEMY',max_targets=1,
   min_rank_index=1,requires_range_check=True,effect_adapter_ready=True,
   effect_adapter_id='NATIVE-V081-APPLY-WEAPON-ATTACK')

def goat_proof():
 return FrozenRuleEvidence(g.TARGET_SOURCE,GO_RULE,source_digest(),
        '2026-10-15:NOTION_OP_READBACK','OP-VLAB-R34-MASTER-P1-P6-APPROVAL')

def geometry_init():
 return {'unit':'meters','scene_grid_unit_meters':1.5,
   'positions':{g.AID:[0.0,0.0],g.TID:[1.5,0.0]},
   'terrain':'OPEN_LAB_NO_OBSTACLES','bounds_m':[-20.0,20.0],
   'adjacency_m':1.5,'scene_not_world':True,'no_external_entities':True,
   'force_push_formula':'1.5 METERS PER COMPLETE 300 FF',
   'goat_ff':310,'goat_push_m':1.5,
   'normal_bronze_speed_m':{g.AID:12.5,g.TID:10.0}}

def genesis(st):
 if st['phase']!='ACTIVE' or st['roll_nonce']!=0:raise BattleHold('BAD_PREEXISTING_SCENE')
 st['phase']='INIT';st['round']=0;st['turn']=0;st['active']=None;st['order']=[]
 for a in ACTORS:
  st['actors'][a]['stats']['init_bonus']=0
  st['actors'][a]['stats']['init_bonus_origin']='MASTER_R33_LAB_P5_ONLY'
  st['actors'][a]['stats']['luta_bonus']=6
  st['actors'][a]['stats']['luta_origin']='MASTER_SPECIFIC_R32' if a==g.AID else 'MASTER_SPECIFIC_R34'
 st['r31_source']['experimental_turn_override']=False
 st['r31_source']['reaction_policy']='BOTH_DECLINE_VOLUNTARY_REACTIONS_R34_FIRST_BATTERY'
 st['r31_source']['luta_status']='TWO_MASTER_EXPLICIT_SCOPED_DECISIONS'
 st['r31_source']['luta_value']=6
 st['r34_battle']={'schema':'R34_REAL_SOURCE_FULL_FIGHT_LAB_V1',
    'goat_source':g.TARGET_SOURCE,'goat_source_sig_sha':source_digest(),
    'fr_source':g.BEAST_SOURCE,'frigido_decision_sha':digest(AUTH_FR),
    'goat_decision_sha':digest(AUTH),'geometry':geometry_init(),
    'reaction_policy':'P6_BOTH_CHOOSE_NO_VOLUNTARY_REACTION; REFRESH_OWN_TURN_R26',
    'choice':'both use each individually approved natural attack while target alive and adjacent',
    'attack_policy':{g.AID:FRID,g.TID:GOID},
    'allowed_actions':{g.AID:['STANDARD:RABADA'],g.TID:['STANDARD:INVESTIDA']},
    'turns':0,'attacks':0,'pushes':0,'full_fight_credit':False,
    'positive_crits':0,'negative_crits':0,'movement_events':0,
    'critical_negative_policy':'R27_MESTRE_LAB_NEGATIVE_AUTO_MISS_NO_ADDITIONAL_PENALTY',
    'critical_positive_policy':'OFFICIAL_ADD_MAX_1D6',
    'reactions_selected':{g.AID:0,g.TID:0},
    'world_effects':0,'source_mode':g.MODE}
 return st

def create_new(db=DB):
 if db.exists():raise BattleHold('NEVER_REUSE_OR_AUTORETRY_EXISTING_DB')
 _=authority();g.create(db,seed=SEED)
 c=j.connect(db)
 try:
  c.execute('BEGIN IMMEDIATE');m=dict(c.execute('SELECT key,value FROM meta'))
  assert int(m['revision'])==0 and not c.execute('SELECT 1 FROM events').fetchone()
  st=genesis(json.loads(m['state']))
  c.execute('UPDATE meta SET value=? WHERE key="state"',(j.canonical(st),));c.commit()
 except: c.rollback();raise
 finally:c.close()
 st,_,v=g.checked(db)
 assert v==0 and st['phase']=='INIT'
 return st

def distance(st):
 p=st['r34_battle']['geometry']['positions'];a,b=(p[k] for k in ACTORS)
 return round(math.dist(a,b),8)

def prereq(st):
 _=authority()
 b=st['r34_battle']
 if b['source_mode']!=g.MODE or b['goat_source_sig_sha']!=source_digest():raise BattleHold('SOURCE_MANIFEST_MISMATCH')
 if b['goat_decision_sha']!=digest(AUTH) or b['frigido_decision_sha']!=digest(AUTH_FR):
  raise BattleHold('DECISION_FILES_CHANGED')
 if b['geometry']['goat_ff']!=310 or b['geometry']['goat_push_m']!=1.5:
  raise BattleHold('FF_PUSH_AMOUNT_CHANGED')
 if any(x['source_page_id'] not in (g.BEAST_SOURCE,g.TARGET_SOURCE) for x in st['actors'].values()):
  raise BattleHold('NOT_SOURCE_AUTHENTICATED')
 if st['r34_battle']['reaction_policy']!='P6_BOTH_CHOOSE_NO_VOLUNTARY_REACTION; REFRESH_OWN_TURN_R26':
  raise BattleHold('REACTION_POLICY_TAMPER')
 return True

def candidate_menu(st,aid):
 src=g.ability() if aid==g.AID else goat_source()
 proof=g.proof() if aid==g.AID else goat_proof()
 target=g.TID if aid==g.AID else g.AID
 aa=st['actors'][aid]['resource']
 ready=distance(st)<=1.50000001
 state=ActorActionState(actor_id=aid,ordinal_level=5 if aid==g.AID else 1,
   available_pa=aa['pa'],known_action_ids=(src.action_id,),
   standard_available=aa['standard']==1,reaction_available=aa['reaction']==1,
   range_confirmed=ready,geometry_confirmed=True,enemy_ids_visible=(target,))
 out=action_menu(state,(src,),strict=True,source_evidence=(proof,))
 if len(out.legal_options)!=1 or out.rejected:raise BattleHold('STRICT_MENU_DENIED:'+repr(out.rejected))
 return src,proof,state

def dice_preview(st):
 aid=st['active'];nonce=st['roll_nonce']+1
 crit=tuple(j.dice(st['seed'],nonce,'R34-CRIT-'+aid+'-'+str(k),1,6)[0] for k in (1,2,3))
 pos=crit[:2]==(6,6) and crit[2]>=5
 neg=crit[:2]==(1,1) and crit[2]<=2
 hit=j.dice(st['seed'],nonce,'R34-HIT-'+aid,1,6)[0]
 dmg=j.dice(st['seed'],nonce,'R34-DAMAGE-'+aid,1,6)[0]
 fort=18 if aid==g.AID else 13
 return {'actor':aid,'target':g.TID if aid==g.AID else g.AID,'nonce':nonce,
  'critical_sequence':list(crit),'crit_kind':'POSITIVE' if pos else ('NEGATIVE' if neg else 'NONE'),
  'hit_die':hit,'damage_die':dmg,'luta':6,'for':fort,
  'hit_total':hit+fort+6,'score_to_core':0 if neg else hit+fort+6,
  'damage_to_core':0 if neg else dmg+fort+(6 if pos else 0),
  'critical_extra_damage':6 if pos else 0}

def move_for_attack(st,aid):
 # A movement action is used only if the push previously broke adjacency.
 b=st['r34_battle'];p=b['geometry']['positions'];target=g.TID if aid==g.AID else g.AID
 d=distance(st);old=list(p[aid]);r=st['actors'][aid]['resource']
 if d<=1.50000001:return None
 if r['movement']!=1:raise BattleHold('MOVEMENT_ALREADY_SPENT')
 allowance=b['geometry']['normal_bronze_speed_m'][aid]
 needed=d-1.5
 if needed>allowance+1e-9:raise BattleHold('CANNOT_REACH_ADJACENCY_WITH_NORMAL_MOVEMENT')
 dx=(p[target][0]-p[aid][0])/d;dy=(p[target][1]-p[aid][1])/d
 p[aid]=[round(p[aid][0]+needed*dx,8),round(p[aid][1]+needed*dy,8)]
 r['movement']=0;r['position']='R34-LAB-MOVE-'+str(p[aid])
 b['movement_events']+=1
 if distance(st)>1.5000001:raise BattleHold('MOVE_GEOMETRY_POSTCONDITION')
 return {'action':'MOVEMENT','by':aid,'from':old,'to':list(p[aid]),'meters':needed,
     'cost':'one Movement Action','speed_limit_m':allowance,'only_lab':True}

def forced_push(st,aid,target,event):
 if aid!=g.TID or not event['hit'] or event['net']<=0:return None
 b=st['r34_battle'];p=b['geometry']['positions'];ap=p[aid];tp=p[target]
 d=math.dist(ap,tp)
 if d<0.000001:raise BattleHold('PUSH_ZERO_VECTOR')
 n=math.floor(b['geometry']['goat_ff']/300)
 meters=1.5*n
 if meters!=1.5:raise BattleHold('PUSH_FF_NOT_PROVEN')
 direction=[(tp[k]-ap[k])/d for k in range(2)]
 new=[round(tp[k]+meters*direction[k],8) for k in range(2)]
 lower,upper=b['geometry']['bounds_m']
 if any(v<lower or v>upper for v in new):raise BattleHold('SCENE_EDGE_PUSH_NEEDS_INTERACTION')
 if b['geometry']['terrain']!='OPEN_LAB_NO_OBSTACLES':raise BattleHold('OBSTACLE_NOT_RESOLVED')
 old=list(tp);p[target]=new
 st['actors'][target]['resource']['position']='R34-LAB-PUSH-'+str(new)
 b['pushes']+=1
 return {'action':'FORCED_PUSH','by':aid,'target':target,'origin':old,'destination':new,
    'distance_m':meters,'source_FF':310,'threshold_FF':300,
    'trigger':'HIT_AND_NET_DAMAGE_POSITIVE','no_extra_damage':True,
    'no_opportunity_from_forced_move':True,'obstacle':'none_in_scenario',
    'post_distance_m':distance(st),'recalculate_adjacency':True,'only_lab':True}

def native_attack(st,p):
 g.verify_pins();aid=p['actor'];target=p['target']
 src,proof,astate=candidate_menu(st,aid)
 first_hp={k:v['resource']['hp'] for k,v in st['actors'].items()}
 first_pa={k:v['resource']['pa'] for k,v in st['actors'].items()}
 scene=Scene({a:Combatant(**copy.deepcopy(v['resource'])) for a,v in st['actors'].items()},
     seed=st['seed'],provenance='LAB-REAL-MASTER-FONTE-AUTENTICADA-NONCAN')
 result=apply_weapon_attack(scene,aid,target,source=src,state=astate,proofs=(proof,),
    roll_score=p['score_to_core'],damage=p['damage_to_core'],
    damage_tag='impacto',rd=Resistances(general=5,specific=(),
    provenance='CREACAO_BESTA_BRONZE_NORMAL_RD5'),strict=True)
 if len(scene.events)!=1:raise BattleHold('EXPECTED_SINGLE_NATIVE_V081_ATTACK')
 if result['roll_score']!=p['score_to_core'] or result['to']!=target or result['ca_exact']!=str(st['actors'][target]['resource']['ca']):
  raise BattleHold('NATIVE_TO_HIT_OR_CA_DIFF')
 if p['crit_kind']=='NEGATIVE' and (result['hit'] or result['net']):raise BattleHold('NEGATIVE_CRIT_EFFECT_DIFF')
 if result['before_hp']-result['after_hp']!=min(result['before_hp'],result['net']):
  raise BattleHold('NATIVE_HP_DELTA_INVALID')
 for k,v in scene.actors.items():st['actors'][k]['resource']=asdict(v)
 if {k:v['resource']['pa'] for k,v in st['actors'].items()}!=first_pa:raise BattleHold('PA_CHANGED_WITHOUT_COST')
 if st['actors'][aid]['resource']['standard']!=0:raise BattleHold('STANDARD_NOT_CONSUMED')
 if any(v['resource']['hp']>first_hp[k] for k,v in st['actors'].items()):raise BattleHold('HP_GREW')
 return {'effect':result,'scene_event_sha':scene.checksum(),'source_action':src.action_id,
  'source_page':g.BEAST_SOURCE if aid==g.AID else g.TARGET_SOURCE,
  'fr_or_goat':'fr' if aid==g.AID else 'goat','native_resolver':'v0.8.1.apply_weapon_attack'}

def initiate(st,payload,seq):
 prereq(st)
 if st['phase']!='INIT' or payload['kind']!='INIT' or seq!=1:raise BattleHold('INIT_PRECONDITION')
 e=r26.resolve_initial_state(st);refresh=r26.refresh_own_turn(st,st['active'])
 return {'historical_R26_initiative':e,'R26_reaction_refresh':refresh,
  'HP_unchanged':True,'world_effects':0}

def turn(st,payload,seq):
 prereq(st)
 if st['phase']!='ACTIVE' or payload['kind']!='TURN':raise BattleHold('NOT_ACTIVE_TURN')
 actor=st['active'];target=g.TID if actor==g.AID else g.AID
 if actor!=payload['actor'] or target!=payload['target'] or st['round']!=payload['round']:
  raise BattleHold('TURN_OR_TARGET_MISMATCH')
 if st['actors'][actor]['resource']['hp']<=0 or st['actors'][target]['resource']['hp']<=0:
  raise BattleHold('UNAVAILABLE_ACTOR')
 if st['actors'][actor]['resource']['standard']!=1:raise BattleHold('NO_STANDARD_ACTION')
 b=st['r34_battle'];moved=move_for_attack(st,actor)
 p=dice_preview(st)
 if p!=payload['dice_preview']:raise BattleHold('STAGE_PREVIEW_CHANGED')
 # Defensive windows retained; policy approved by Mestre is conscious NO VOLUNTARY REACTION.
 if b['reaction_policy']!='P6_BOTH_CHOOSE_NO_VOLUNTARY_REACTION; REFRESH_OWN_TURN_R26':
  raise BattleHold('REACTION_POLICY_CHANGED')
 core=native_attack(st,p)
 hit=core['effect']['hit'];damage=core['effect']['net']
 push=forced_push(st,actor,target,core['effect'])
 b['turns']+=1;b['attacks']+=1
 if p['crit_kind']=='POSITIVE':b['positive_crits']+=1
 if p['crit_kind']=='NEGATIVE':b['negative_crits']+=1
 st['roll_nonce']=p['nonce']
 if st['actors'][target]['resource']['hp']<=0:
  st['phase']='COMPLETE_LAB_REAL_SOURCE_BESTAS'
  st['winner']=actor;st['finish_reason']='HP_ZERO_FULL_REAL_SOURCE_NONCAN_SANDBOX'
  st['active']=None;h={'end':True,'winner':actor};r=None
 else:
  h=j._next_turn(st);r=r26.refresh_own_turn(st,st['active'])
 return {'turn':payload['round'],'actor':actor,'target':target,'dice':p,
   'movement':moved,'reaction_policy':'DECLINED_VOLUNTARILY_BOTH_ACTORS',
   'reaction_consumed':False,'native':core,'forced_push':push,
   'advance_native_R18':h,'reaction_refresh_native_R26':r,
   'hp_after':{a:v['resource']['hp'] for a,v in st['actors'].items()},
   'pa_after':{a:v['resource']['pa'] for a,v in st['actors'].items()},
   'round_after':st['round'],'phase_after':st['phase'],'world_effects':0}

def action_payload(st,head,revision):
 preview=dice_preview(st)
 return {'kind':'TURN','actor':st['active'],'target':preview['target'],
  'round':st['round'],'nonce':preview['nonce'],'dice_preview':preview,
  'expected_revision':revision,'expected_head':head,'source_authority_sha':source_digest(),
  'policy':'both_attacks_each_own_turn_until_HP0_noncanon'}

def audit_schema(db):
 st,h,v=g.checked(db);hist=j.history(db)
 c=j.connect(db)
 try:
  integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
  pending=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
  rows=c.execute('SELECT COUNT(*) FROM events').fetchone()[0]
 finally:c.close()
 return {'revision':v,'head':h,'events':rows,'sqlite_integrity':integrity,'pending':pending,
 'phase':st['phase'],'hp':{a:st['actors'][a]['resource']['hp'] for a in ACTORS},
 'pa':{a:st['actors'][a]['resource']['pa'] for a in ACTORS},
 'reactions':{a:st['actors'][a]['resource']['reaction'] for a in ACTORS},
 'turns':st['r34_battle']['turns'],'attacks':st['r34_battle']['attacks'],
 'pushes':st['r34_battle']['pushes'],'winner':st.get('winner'),'source_ids':{a:st['actors'][a]['source_page_id'] for a in ACTORS},
 'world_effects':st['r34_battle']['world_effects']}

def independent_replay(bootstrap,evidence_events,final):
 cp=copy.deepcopy(bootstrap)
 for n,row in enumerate(evidence_events,1):
  x=initiate(cp,row['payload'],n) if n==1 else turn(cp,row['payload'],n)
  if j.sha(x)!=j.sha(row['detail']):raise BattleHold('REPLAY_DIFF_DETAIL:'+str(n))
  if j.sha(cp)!=row['after_sha']:raise BattleHold('REPLAY_DIFF_STATE:'+str(n))
 if cp!=final:raise BattleHold('REPLAY_FINAL_STATE_DIFF')
 return {'status':'PASS_INDEPENDENT_REPLAY_R26_R18_V081_SOURCE_REAL',
 'events':len(evidence_events),'complete':final['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS',
 'final_state_sha':j.sha(cp),'event_chain':evidence_events[-1]['hash']}

def checkpoint(db,dest):
 if dest.exists():raise BattleHold('NEVER_OVERWRITE_CHECKPOINT')
 c=sqlite3.connect(db);d=sqlite3.connect(dest)
 try:c.backup(d)
 finally:d.close();c.close()
 if j.history(db)!=j.history(dest):raise BattleHold('PORTABLE_SNAPSHOT_HISTORY_MISMATCH')
 return {'status':'PASS','snapshot_sha256':digest(dest),'logical_identical':True}

def main():
 if DB.exists():raise BattleHold('R34_RUN_ALREADY_EXISTS_NO_RETRY')
 g.verify_pins();write_json('evidence/R34_DECISION_READBACK_FROZEN.json',{'goat_authority':authority(),
   'goat_authority_file_sha256':digest(AUTH),'fr_authority_file_sha256':digest(AUTH_FR),
   'source_real_manifest_hash':source_digest(),
   'source_ids':[g.BEAST_SOURCE,g.TARGET_SOURCE],
   'notion_op_last_edited_readback':'2026-10-15T18:10:59.687Z'})
 write_json('evidence/R34_PRE_REGISTERED_SCENE.json',{'seed':SEED,
   'intent':'FIRST_COMPLETE_REAL_SOURCE_BEAST_FIGHT_IN_ISOLATED_SANDBOX',
   'source_ids':[g.BEAST_SOURCE,g.TARGET_SOURCE],
   'geometry':geometry_init(),'initiative_bonus':{'fr':0,'goat':0,'experiment_only':True},
   'luta_approved_only_by_ability':{'fr_rabada':6,'goat_investida':6},
   'reaction_policy':'BOTH_DECLINE_FIRST_BATTERY_WITH_R26_REFRESH',
   'max_event_budget':MAX_EVENTS,'world_effects':0,'noncanon':True})
 st0=create_new();st,h,v=g.checked(DB);assert st0==st and v==0
 write_json('evidence/R34_GENESIS_BEFORE.json',{'state':st,'head':h,'rev':v})
 payload={'kind':'INIT','authority_sha':source_digest(),'phase':'INIT', 'no_canon':True}
 candidate=copy.deepcopy(st);initiate(candidate,payload,1)
 j.event_commit(DB,'LAB-CMD-R34-INIT-'+j.sha(payload)[:32], 'R34_REAL_BEAST_INITIATIVE',payload,initiate)
 for i in range(MAX_EVENTS):
  st,head,rev=g.checked(DB)
  if st['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS':break
  if st['phase']!='ACTIVE':raise BattleHold('R34_UNRECOGNIZED_STATE')
  p=action_payload(st,head,rev)
  # Preflight on a detached copy BEFORE recording durable intent.
  shadow=copy.deepcopy(st);turn(shadow,p,rev+1)
  j.event_commit(DB,'LAB-CMD-R34-TURN-'+j.sha({'head':head,'payload':p})[:32],
      'R34_REAL_BEAST_NATIVE_TURN',p,turn)
 st,head,rev=g.checked(DB)
 if st['phase']!='COMPLETE_LAB_REAL_SOURCE_BESTAS':raise BattleHold('BUDGET_REACHED_CENSORED_NOT_COMPLETE')
 hist=j.history(DB);ev=hist['events']
 gen=json.loads((ROOT/'evidence'/'R34_GENESIS_BEFORE.json').read_text())['state']
 re=independent_replay(gen,ev,st)
 report=audit_schema(DB)
 if report['pending']!=0 or report['sqlite_integrity']!='ok' or report['events']!=report['revision']:
  raise BattleHold('LEDGER_NOT_INTEGRAL')
 ckp=checkpoint(DB,ROOT/'checkpoints'/f'R34_FULL_FIGHT_SEED{SEED}.sqlite')
 out={'schema':'R34_FIRST_COMPLETE_BESTA_REAL_SOURCE_SANDBOX_V1',
  'classification':'SANDBOX_REAL_MASTER_SOURCE_NOT_WORLD_CANON',
  'seed':SEED,'source_authority_sha':source_digest(),'ledger':report,
  'native_attacks':[{'seq':e['seq'],'actor':e['payload'].get('actor'),
       'attack_total':e['detail'].get('dice',{}).get('hit_total'),
       'damage_after_RD':e['detail'].get('native',{}).get('effect',{}).get('net'),
       'hit':e['detail'].get('native',{}).get('effect',{}).get('hit'),
       'critical':e['detail'].get('dice',{}).get('crit_kind'),
       'push':e['detail'].get('forced_push'),
       'movement':e['detail'].get('movement')} for e in ev if e['kind']=='R34_REAL_BEAST_NATIVE_TURN'],
  'completed_fight':True,'canonical_fight':False,'canonical_credit':0,
  'replay':re,'checkpoint':ckp,'sqlite_sha256':digest(DB),
  'goat_push_effect_events':sum(bool(e['detail'].get('forced_push')) for e in ev),
  'old_R32_and_R33_states_modified':False}
 write_json('evidence/R34_COMPLETE_FIGHT_RECEIPT.json',out)
 print(json.dumps({'status':'COMPLETE_REAL_SOURCE_NONCAN','audit':report,
  'replay':re['status'],'attacks':out['native_attacks'],
  'sqlite_sha':out['sqlite_sha256']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
