"""Package only the R34 experimental delta. Never copy/overwrite old baselines."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent/'VLAB_R34_PRIMEIRO_COMBATE_COMPLETO_BESTAS_REAIS_MESTRE_ONLY.zip'
paths=[
 'R34_RELATORIO_MESTRE_ONLY.md','README_REPRODUCAO_R34.md',
 'run_full_fight_r34.py','finalize_readonly_r34.py','verify_r34_standalone.py','build_r34_package.py',
 'extension/vlab_r31_real_source_gateway.py',
 'authority/MESTRE_LUTA_DECISION_VERIFIED.json','authority/MESTRE_INVESTIDA_R34_VERIFIED.json',
 'evidence/R34_DECISION_READBACK_FROZEN.json','evidence/R34_PRE_REGISTERED_SCENE.json',
 'evidence/R34_GENESIS_BEFORE.json','evidence/R34_FIRST_COMPLETE_FIGHT_RECEIPT.json',
 'evidence/R34_POSTCOMMIT_INDEPENDENT_AUDIT.json',
 'runs/R34_REAL_SOURCE_FULL_FIGHT_SEED347.sqlite',
 'checkpoints/R34_FULL_FIGHT_SEED347.sqlite'
]
if DEST.exists():raise RuntimeError('NEVER_OVERWRITE_EXISTING_PACKAGE')
hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
manifest={'schema':'R34_IMMUTABLE_DELTA_FILE_HASHES_V1','file_sha256':hashes,
 'base_VLAB_R27_SHA256':'d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1',
 'R31_SHA256':'98841bf0473545005bdb107597981805199a35081e2dc84a4b6d150b97fa6835',
 'R32_SHA256':'20530947c8349d8e544fa5ee506e7327b31a8e6d37eb3aab23c180d1639c4a53',
 'R33_SHA256':'ceeab4d4786ee3670959be477c90c2dc42cce0806fb9d773e5814ca14bb9bb8b',
 'VLAB_terminal_contracts':0,'canonical_cells':0,'campaign_effects':0,'full_real_source_lab_fights_this_run':1,
 'historical_originals_modified':False,
 'not_a_standalone_motor':True}
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in paths:z.write(ROOT/p,arcname=p)
 z.writestr('R34_FILE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(DEST) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(paths)+1
 for n,sha in hashes.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha
print(json.dumps({'path':str(DEST),'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),
 'members':len(paths)+1,'files_hashed':len(paths),'crc':'PASS','bytes':DEST.stat().st_size},ensure_ascii=False,indent=2))
