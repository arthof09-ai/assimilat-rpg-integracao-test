# R34 — Reproduzir a primeira luta integral entre Bestas reais no sandbox

**Arquivo principal para ler:** `R34_RELATORIO_MESTRE_ONLY.md`. **Recibo auditável:** `evidence/R34_FIRST_COMPLETE_FIGHT_RECEIPT.json`. **SQLite:** `runs/R34_REAL_SOURCE_FULL_FIGHT_SEED347.sqlite`. **Checkpoint lógico:** `checkpoints/R34_FULL_FIGHT_SEED347.sqlite`. Identidade dos dois atores e autoridade do Mestre em `authority/` e `evidence/R34_DECISION_READBACK_FROZEN.json`.

## Auditoria autônoma sem instalar motor

Extraia o ZIP para uma pasta. Com Python 3 padrão: `python verify_r34_standalone.py VLAB_R34_PRIMEIRO_COMBATE_COMPLETO_BESTAS_REAIS_MESTRE_ONLY.zip`. Este verificador é **somente leitura**; confere CRC, manifestos SHA, cadeia de hashes SQLite e o checkpoint. Não roda novamente a batalha.

## Replay mecânico independente com o núcleo histórico

O gateway R31 foi copiado **byte a byte** da entrega R32 em `extension/vlab_r31_real_source_gateway.py`. O módulo `run_full_fight_r34.py` chama `v0.8.1.apply_weapon_attack`, `R18.event_commit` e `R26.resolve_initial_state`/`refresh_own_turn`; não reimplementa cálculo de acerto, CA, RD ou dano. Para executar o replay **em ambiente limpo**, recupere da Biblioteca existente o baseline R27 (SHA256 `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`) e extraia sua raiz original `r27` ao lado de `extension`. Preserve o layout original para os pinos de hash que verificam bibliotecas históricas. No ambiente original preservado, executar `independent_replay` a partir de `evidence/R34_GENESIS_BEFORE.json` e dos eventos lidos do banco com `R18.history`. Esta ação foi executada e passou 6/6, com hash do estado final conforme recibo.

**Não execute `run_full_fight_r34.py` outra vez no banco existente.** Seu `main` é propositalmente `NO_OVERWRITE_EXISTING_DB`; a R34 possui transação terminal. O replay usa estado descartável, não grava novos eventos. Em caso de suspeita de corrupção, preservar o arquivo e confrontar recibo e checkpoint antes de qualquer tentativa.

**Importante:** o motor de combate conserva o sinalizador `synthetic=true` do R18 para a *cena simulada*, enquanto os IDs dos combatentes apontam para fichas reais Mestre. Esses são estados distintos. `MESTRE_LUTA_DECISION_VERIFIED.json` (Frígido) e `MESTRE_INVESTIDA_R34_VERIFIED.json` (Cabra) são atestados locais de decisão registrada e reaberta no Notion, não certificados digitais Notion. A luta **não é episódio oficial da campanha**.
