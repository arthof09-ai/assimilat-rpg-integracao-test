"""Independent stdlib-only R34 ZIP verifier: SHA/CRC/SQLite hash-chained ledger.
This verifies durable evidence WITHOUT importing or executing the combat engine.
For recomputation of hit/RD/HP, run finalize_readonly_r34.py with the immutable
historical VLAB R27 environment. Never invoke run_full_fight_r34.main() on old DB.
"""
import hashlib,io,json,sqlite3,sys,tempfile,zipfile
from pathlib import Path

def h(b):return hashlib.sha256(b).hexdigest()
def canon(o):return json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
def verify(src):
 with zipfile.ZipFile(src,'r') as z:
  assert z.testzip() is None
  data=json.loads(z.read('R34_FILE_MANIFEST.json'))
  assert set(z.namelist())==set(data['file_sha256'])|{'R34_FILE_MANIFEST.json'}
  for fn,sha in data['file_sha256'].items():assert h(z.read(fn))==sha,(fn,'hash')
  binary=z.read('runs/R34_REAL_SOURCE_FULL_FIGHT_SEED347.sqlite')
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'cold.sqlite';p.write_bytes(binary)
   c=sqlite3.connect(f'file:{p}?mode=ro',uri=True)
   try:
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert c.execute('select count(*) from pending').fetchone()[0]==0
    m=dict(c.execute('select key,value from meta'))
    rows=list(c.execute('select seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha from events order by seq'))
   finally:c.close()
  st=json.loads(m['state']);assert len(rows)==int(m['revision'])==6
  prev=m['genesis'];before_sha=None
  for i,cmd,pre,row_json,sha,bef,aft in rows:
   r=json.loads(row_json)
   assert i==r['seq'] and cmd==r['cmd_id'] and pre==prev==r['prev']
   assert h(canon(r))==sha and r['before_sha']==bef and r['after_sha']==aft
   if before_sha is not None:assert bef==before_sha
   before_sha=aft;prev=sha
  assert prev==m['head'] and before_sha==h(canon(st))
  assert st['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS'
  assert st['winner']=='LAB_REAL_FRIGIDO_B5'
  assert st['actors']['LAB_REAL_CABRA_B1']['resource']['hp']==0
  assert st['actors']['LAB_REAL_FRIGIDO_B5']['resource']['hp']==125
  assert st['r34_battle']['turns']==5
  assert st['r34_battle']['pushes']==0
  assert st['r34_battle']['world_effects']==0
  rc=json.loads(z.read('evidence/R34_FIRST_COMPLETE_FIGHT_RECEIPT.json'))
  assert rc['sqlite_sha256']==h(binary)
  assert rc['ledger']['head']==m['head'] and rc['ledger']['revision']==6
  assert rc['replay']['status']=='PASS_INDEPENDENT_REPLAY_R26_R18_V081_SOURCE_REAL'
  cp=z.read('checkpoints/R34_FULL_FIGHT_SEED347.sqlite')
  assert h(cp)==rc['checkpoint_sha256']
  return {'status':'PASS','file_hashes':len(data['file_sha256']),
       'events':len(rows),'attacks':st['r34_battle']['attacks'],'rounds':st['round'],
       'winner':st['winner'],'canonical_effects':0,'sqlite_sha256':h(binary),
       'head':m['head'],'checkpoint_sha256':h(cp)}
if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('usage: python verify_r34_standalone.py archive.zip')
 print(json.dumps(verify(sys.argv[1]),ensure_ascii=False,indent=2))
