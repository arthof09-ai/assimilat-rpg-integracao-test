# Reproduzir R43 — Mestre-side

1. Para auditoria independente, instalar apenas Python 3.11+ e executar: `python extension/verify_r43_standalone.py VLAB_R43_PRIORIDADE_AOO_MESTRE_ONLY.zip` ou `python extension/verify_r43_standalone.py .` após extrair o ZIP.
2. O auditor não importa nenhum motor histórico. Inspeciona **todos** os arquivos dos ledgers e checkpoints, confirma hashes/SQL, reproduz os d6 por implementação separada da especificação RNG R18 e recalcula a ordem pela Destreza e rerrolagens apenas entre empatados.
3. `extension/r43_aoo_priority.py` e `extension/test_r43_priority.py` são o código aditivo de execução e testes. Reexecutar esses scripts **em pasta nova com bancos novos** para reproduzir efeitos experimentais, nunca contra as instâncias entregues. O algoritmo reutiliza R18/R26 históricos distribuídos no pacote de base R27, cujo código e hashes não foram alterados.
4. `extension/r43_adversarial_rechain.py` exige a base local da própria R43 e realiza mutações exclusivamente em diretórios temporários. O resultado da bateria original acompanha `evidence/R43_ADVERSARIAL_RECHAINED.json`.
5. O código e a saída se restringem à **ordem dos gatilhos**, não a ações ofensivas. As duas habilidades com +6 na R32 e R34 são escopos específicos, e nenhum Luta para Ataque de Oportunidade foi admitido.
