# PSV R43 — Decisão expressa do Mestre / Prioridade entre Ataques de Oportunidade

**OP:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01, original, MESTRE-SIDE. **Marco:** R42 → R43. **Natureza:** camada experimental aditiva, sem escritores de combate/campanha. **Autoridade:** ordem textual do Mestre de 15/10/2026: “Ataca quem tiver mais destreza, se tiver a destreza tiver empatado, tira a sorte no dado, quem tiver o maior número ataca primeiro”.

## 1. Critério e autoridade

1. Identificar os atacantes com gatilho legítimo por saída **voluntária** do bloco adjacente e um slot individual de Reação disponível.
2. Ordenar os candidatos elegíveis por **Destreza decrescente**, sem usar a iniciativa global como substituto.
3. Em empate de Destreza entre Bestas Bronze, usar o **dado da classificação Bronze = 1d6**: cada interessado recebe uma nova rolagem por RNG experimental R18. Maior resultado fica primeiro.
4. Se houver novo empate no dado, aplicar o procedimento anteriormente autorizado **R26**: repetir **apenas** os empatados até resolver. Ninguém é beneficiado por nome/ID nem por posição do vetor.
5. O escopo de resolução testado é Bronze×Bronze. Dado competente em empate entre classificações com dados diferentes exige reconciliação específica antes de ampliar a implementação; **não presume d6 universal**.

**Fontes:** [Sistema de Combate](https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0) (oportunidade, Reação, afastamento seguro, dado Bronze1d6), [Cabra Bronze1](https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6) (DES8) e [Frígido Bronze5](https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315) (DES18). Decisão nova está **registrada e reaberta na OP existente**. Norma global não foi editada.

## 2. Implementação concreta

- Módulo novo `extension/r43_aoo_priority.py` reutiliza diretamente `R26.tie_order` para o desempate e `R18.dice` para consumir dados **gerados pelo RNG experimental**, nunca injetados como resultados.
- A ordenação de prioridade é gravada na **mesma unidade transacional R18** via `event_commit`, com um evento `R43_AOO_PRIORITY`, fita por ator, verificadores de fonte e checkpoint SQLite íntegro.
- **Separação de efeitos:** prioridade ≠ ataque efetivamente autorizado. A ficha Cabra e a do Frígido não publicam Luta para um ataque NORMAL de oportunidade. Os bônus +6 concedidos somente para Investida/Rabada não são transferidos. O evento permanece `PRIORITY_RESOLVED_ATTACK_SOURCE_HOLD`, sem movimentar ninguém, gastar slot, causar dano ou criar evento de campanha.
- Erros de admissibilidade (Luta falsa, dado/rank alterado, slots inválidos, mais de um alvo protegido pelo afastamento seguro e fonte desconhecida) são rejeitados antes de publicar qualquer evento.

## 3. Resultados de sete cenas novas

| Cena/seed | Participantes e DES | Dados R18, quando necessários | Prioridade registrada |
| --- | --- | --- | --- |
| `B1_EQUAL_DES` / 96001 | Cabra B8 × Cabra C8 | B6, C4 | B → C |
| `UNEQUAL_DES` / 96002 | Cabra B8 × Frígido C18 | Nenhum, diferença DES suficiente | Frígido C → Cabra B |
| `REPEATED_DICE_TIE` / **96082** | Duas Cabras DES8 | B3/C3; B1/C1; B1/C4 | Cabra C → Cabra B |
| `SAFE_ONE_OTHER_ELIGIBLE` / 96004 | Duas Cabras DES8; ação segura contra B | Nenhum, só C elegível | C |
| `FORCED_MOVEMENT_NOT_AOO` / 96005 | Duas Cabras | Nenhum | Ninguém elegível |
| `SPENT_SLOT` / 96006 | Duas Cabras; B já gastou Reação | Nenhum | C |
| `THREE_ELIGIBLE_MIXED_DES` / 96007 | Frígido D18, Cabras B8/C8 | B3, C6 | Frígido D → Cabra C → Cabra B |

A semente **96082** foi encontrada em **busca dirigida** entre 80 sementes examinadas (96003–96082), escolhendo a primeira com empate de d6 também na segunda rodada; **não é amostra para inferência de frequência**.

**194/194 verificações PASSED:** 14 dirigidas de fronteira/admissão e 180 execuções adicionais do resolvedor de prioridade sem publicação transacional. Nesta série exploratória de 180 sementes prefixadas, B ficou primeiro em 85 e C em 95; isso não atesta uniformidade canônica do RNG.

**Auditoria fria:** `verify_r43_standalone.py` não importa nem chama os motores R18/R26 ou o resolvedor novo. Reproduziu os dados por SHA-256 + Python MT seguindo a especificação congelada, a ordenação por DES, o processo de rerrolagem apenas dos empatados e os estados finais. **7/7 ledgers + 7/7 backups SQLite**, **7 eventos** e **10 lançamentos de dados** rastreados, integridade estrutural+causal PASS.

**Adversarial:** em oito cópias temporárias, os hashes de eventos foram **recalculados** após adulterações. O leitor estrutural R18 aceitou os oito ledgers, mas o auditor independente rejeitou **8/8 alterações** (ordem adulterada, d6 fora do domínio, dado alterado, autorização de Luta inventada, Reação gasta, movimento publicado, transcript de empate alterado e seed adulterada). Nenhum banco original foi modificado.

## 4. Quatro camadas de aceitação

| Camada | Resultado | Limite |
| --- | --- | --- |
| A — Implementação | **PASS limitado** | Ordenação AoO concorrente entre fontes Bronze; não despacho do ataque |
| B — Provas | **PASS limitado** | Dados nativos de prioridade e ledger; não dano AoO |
| C — Autoridade | **PASS para ordem** | DES maior e dado em empate conforme Mestre; roll Bronze/R26. Ataque normal segue sem Luta legitimada |
| D — Homologação | **HOLD** | NAC-NORM, avaliação independente formal/NAC-PASS, produção não autorizada |

**Contratos originais:** `REACTION_TRIGGER_AND_SINGLE_USE` avança em precedência/ordenamento de gatilhos alcançáveis, **não recebe TECHNICALLY_COMPLETE** enquanto Ataques de Oportunidade efetivos, Contra-atacar e outras interrupções não estiverem legalmente admitidos. `TURN_SCHEDULER_EVENT_SOURCING` e `RNG_REPLAY_STATISTICS` recebem evidência adicional de ordenação e tape de desempate, sem alteração do contador terminal **0/17**. Células canônicas **0/1.875**, combates canônicos **0**.

## 5. Antes/depois e retomada

**ANTES:** R42 demonstrou dois gatilhos legítimos mas `BLOCKED_NORMATIVE_PRECEDENCE`, sem ordem. **DEPOIS:** R43 resolve ordem e a persiste com replay/checkpoint; primeiro bloqueio passa a ser **`BLOCKED_SOURCE_NORMAL_LUTA`** para efeito de Ataque de Oportunidade, não prioridade normativa entre Bronze. Na hipótese de empate entre classificações com dados de teste distintos, a definição do dado segue pendente de reconciliação.

**Denominadores preservados:** 18 combates completos historicamente reconhecidos até R40; cenas condicionais R41/R42 e censuras/sondas permanecem segregadas. Novos combates R43 **0**, novas prioridades transacionais **7**, novos ataques de oportunidade com dano **0**, efeitos em mundo **0**. Baselines R01–R42, seed53 R29, UNKNOWN_EFFECT, Party, O Primeiro, fichas e motores históricos intocados. `IBX-56=BLOCKED-EXTERNAL`, writer/lease/epoch/fencing/GREEN e NAC-PASS terminal=HOLD.

**NEXT:** recuperar autoridade de bônus de Luta do **ataque normal** usado em Ataque de Oportunidade/Contra-atacar sem herdar o +6 especial da Investida; só depois conectar a prioridade R43 a uma sequência de ataques real-fonte e validar quem mantém ou perde elegibilidade após a primeira resolução. Não reutilizar IDs/SQLite R43 nem refazer o ledger R42.
