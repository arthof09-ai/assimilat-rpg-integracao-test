from __future__ import annotations
import zipfile,json,hashlib,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/VLAB_R43_PRIORIDADE_AOO_MESTRE_ONLY.zip')
include=sorted([p for folder in ['extension','evidence','ledgers','checkpoints','delivery'] for p in (R/folder).rglob('*') if p.is_file() and p.suffix not in ('.pyc','.wal','.shm') and '__pycache__' not in p.parts])
manifest={'schema':'R43_SOURCEBOUND_DELTA_MANIFEST','source':'MESTRE_R43_AOO_DES_DIE_DECISION','sha256':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in include},'historical_engine_included':False,'history_untouched':True,'real_world_effects':0,'no_native_AOO_attack_claim':True}
(R/'R43_FILE_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
assert not OUT.exists(),'DO_NOT_OVERWRITE_ARCHIVE'
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in include+[R/'R43_FILE_MANIFEST.json']:z.write(file,str(file.relative_to(R)))
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(manifest['sha256'])+1
print(json.dumps({'zip':str(OUT),'files':len(include)+1,'hashes':len(include),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()}))
