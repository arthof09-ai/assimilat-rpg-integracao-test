"""R43 MESTRE-SIDE additive AoO ordering; no attacks, damage or canonical writes.
Uses the R26 tie-order algorithm and R18 experimental RNG/SQLite transactional ledger.
Unknown normal attack Luta stays None: priority does not authorize attack resolution.
"""
from __future__ import annotations
import copy, json, hashlib, math, sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
RUNTIME=Path('/mnt/data/vlab_r42/work/runtime_copy')
R27=RUNTIME/'r27/fusion_stage12'
sys.path[:0]=[str(R27),str(RUNTIME)]
import vlab_r18_interactive as j
import vlab_r26_master_rulings as r26
GOAT='391c2b32-4ede-8252-b0cc-810423cdbfa6'
FRIGID='f0dc2b32-4ede-820a-b947-0168d4a53315'
KNOWN={GOAT:{'des':8,'rank':'Bronze1','faces':6,'name':'Cabra de Chifres'},FRIGID:{'des':18,'rank':'Bronze5','faces':6,'name':'Frigido Ossario'}}
VERSION='R43-AOO-PRIORITY-ORDER-ONLY-v1'
class Hold(Exception):pass

def actor(aid,source,position,reaction=1):
    x=KNOWN[source]
    return {'id':aid,'source_page_id':source,'name':x['name'],'des':x['des'],'rank':x['rank'],'rank_faces':x['faces'],'position':list(position),'reaction':reaction,'normal_luta':None}

def adjacency(a,b):return math.dist(a,b)<=1.5000001

def eligible(scene):
    if scene['movement_kind']!='VOLUNTARY':return []
    before=scene['mover_from'];after=scene['mover_to'];out=[]
    for aid,x in sorted(scene['attackers'].items()):
        if not isinstance(x.get('source_page_id'),str) or x['source_page_id'] not in KNOWN:raise Hold('UNKNOWN_SOURCE')
        src=KNOWN[x['source_page_id']]
        if x['des']!=src['des'] or x['rank']!=src['rank'] or x['rank_faces']!=src['faces']:raise Hold('SOURCE_MISMATCH')
        if x['reaction'] not in (0,1):raise Hold('INVALID_REACTION')
        if x['normal_luta'] is not None:raise Hold('UNAUTHORIZED_NORMAL_LUTA')
        if aid==scene['mover']:raise Hold('DUPLICATE_MOVER')
        if x['reaction']==1 and aid not in scene['safe_against'] and adjacency(before,x['position']) and not adjacency(after,x['position']):out.append(aid)
    if len(scene['safe_against'])>1:raise Hold('SAFE_EXIT_AT_MOST_ONE')
    if scene['safe_against'] and not scene['safe_standard_paid']:raise Hold('SAFE_WITHOUT_STANDARD')
    return out

def order(scene):
    cand=eligible(scene)
    if not cand:return {'order':[],'rng_tape':[],'tie_resolution':None,'candidate_ids':[], 'mode':'NO_ELIGIBLE_TRIGGERS'}
    # Mixed-rank ties require explicit interpretation of "no dado"; not assumed here.
    by_des={}
    for aid in cand:by_des.setdefault(scene['attackers'][aid]['des'],[]).append(aid)
    if any(len({scene['attackers'][aid]['rank_faces'] for aid in group})>1 for group in by_des.values()):
        raise Hold('MIXED_DICE_TIE_UNRESOLVED')
    tape=[]
    seed=scene['seed']
    def reroll(aid,n):
        faces=scene['attackers'][aid]['rank_faces']
        label='R43-AOO-PRIORITY:'+aid
        roll=j.dice(seed,n,label,1,faces)[0]
        tape.append({'id':aid,'step':n,'label':label,'faces':faces,'die':roll,'source':'R18_SHA256_TO_MT_EXPERIMENTAL'})
        return roll
    rows=[{'id':aid,'total':0,'des':scene['attackers'][aid]['des']} for aid in cand]
    tie=r26.tie_order(rows,reroll)
    return {'order':tie['order'],'rng_tape':tape,'tie_resolution':tie['rerolls'],'candidate_ids':cand, 'mode':'MESTRE_R43_DES_THEN_R26_TIED_ROLL_ONLY'}

def genesis(seed,attackers,movement_kind='VOLUNTARY',safe_against=(),safe_standard_paid=False,mover_to=(0.,-1.5)):
    if len(set(attackers))!=len(attackers):raise Hold('DUP_ACTORS')
    state=j.initial('A',seed)
    state.update({'scene':'R43-AOO-'+str(seed),'phase':'R43_AOO_PREREQUISITE_ONLY','order':[], 'active':None,'actors':{},'mover':'LAB_R43_GOAT_MOVER',
      'r43':{'version':VERSION,'authority':'MESTRE_20261015_DES_THEN_HIGHEST_DIE','source_page':'3ebc2b32-4ede-81f1-be4b-e8804ac113c0',
       'goat_page':GOAT,'frigid_page':FRIGID,'world_effects':0,'decision_scope':'AOO_CONCURRENT_ONLY','priority':None,'pending_attack_effects':False},
      'attackers':copy.deepcopy(attackers),'mover_from':[0.,0.],'mover_to':list(mover_to),'movement_kind':movement_kind,
      'safe_against':list(safe_against),'safe_standard_paid':bool(safe_standard_paid),'movement_published':False,'reaction_consumed':0,'damage_published':0})
    return state

def make_db(seed,tag,attackers,**kw):
    db=HERE/'ledgers'/('R43_'+tag+'_SEED'+str(seed)+'.sqlite')
    j.init_db(db,'A',seed)
    con=j.connect(db)
    try:
        con.execute('BEGIN IMMEDIATE');st=genesis(seed,attackers,**kw)
        head=j.sha({'R43':VERSION,'seed':seed,'scene':st['scene'],'actors':attackers,'policy':st['r43']['authority']})
        for key,val in [('scene',st['scene']),('state',j.canonical(st)),('head',head),('genesis',head)]:con.execute('UPDATE meta SET value=? WHERE key=?',(val,key))
        con.commit()
    except:con.rollback();raise
    finally:con.close()
    return db

def runner(st,p,seq):
    if seq!=1 or st['r43']['priority'] is not None or p!={'kind':'AOO_PRIORITY','seed':st['seed']}:
        raise Hold('DUPLICATE_OR_STALE_PRIORITY')
    computed=order(st)
    st['r43']['priority']=computed
    st['phase']='PRIORITY_RESOLVED_ATTACK_SOURCE_HOLD' if computed['order'] else 'NO_AOO_TRIGGER'
    # Do not grant real AoO attacks: normal Luta does not exist in either beast sheet.
    return {'kind':'R43_AOO_ORDER','decision':'MESTRE_DES_THEN_HIGHER_DIE','computed':computed,
      'movement_published':False,'reaction_consumed':0,'damage_published':0,'actor_turn_modified':False,
      'attack_gate':'BLOCKED_SOURCE_NORMAL_LUTA' if computed['order'] else 'NOT_APPLICABLE',
      'rng_kind':'R18_EXPERIMENTAL_SHA256_MT_NOT_CANONICAL','world_effects':0}

def commit(db):
    st,head,rev=j.load(db)
    if rev!=0:raise Hold('NON_GENESIS')
    p={'kind':'AOO_PRIORITY','seed':st['seed']};cmd='LAB-CMD-R43-'+j.sha({'head':head,'p':p})[:32]
    row=j.event_commit(db,cmd,'R43_AOO_PRIORITY',p,runner)
    state,head2,rev2=j.load(db)
    if rev2!=1 or state['movement_published'] or state['reaction_consumed'] or state['damage_published']:raise Hold('UNAUTHORIZED_EFFECTS')
    return row

if __name__=='__main__':
    a={'LAB_R43_B':actor('LAB_R43_B',GOAT,(1.5,0)), 'LAB_R43_C':actor('LAB_R43_C',GOAT,(0,1.5))}
    db=make_db(96001,'B1_EQUAL_DES',a);print(json.dumps({'db':str(db),'event':commit(db)['detail']},ensure_ascii=False))
