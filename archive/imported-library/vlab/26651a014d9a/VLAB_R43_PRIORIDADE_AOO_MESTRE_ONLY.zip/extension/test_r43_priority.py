"""R43 priority evidence: newly opened scenes and discarded test-only cases.
Never repeats or touches historical R01-R42 ledgers.
"""
from __future__ import annotations
import json,sys,math,copy,sqlite3,shutil,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'extension'))
import r43_aoo_priority as p
J=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False,indent=2)+'\n'
GOAT=p.GOAT;FRIGID=p.FRIGID
B='LAB_R43_B';C='LAB_R43_C';D='LAB_R43_D'
base={B:p.actor(B,GOAT,(1.5,0)),C:p.actor(C,GOAT,(0.,1.5))}
cases=[];scenes=[]
def check(name,test,detail):
    assert test,name+': '+str(detail)
    cases.append({'name':name,'result':'PASS','detail':detail})

def create(tag,seed,attackers=base,**kw):
    db=HERE/'ledgers'/('R43_'+tag+'_SEED'+str(seed)+'.sqlite')
    if db.exists():
        # Preserve a successful commit from an interrupted test harness; never retry.
        co0=sqlite3.connect(db);old=co0.execute('SELECT row_json FROM events ORDER BY seq').fetchall();co0.close()
        assert len(old)==1,'AMBIGUOUS_EXISTING_LEDGER'
        row=json.loads(old[0][0])
    else:
        db=p.make_db(seed,tag,attackers,**kw)
        row=p.commit(db)
    state,head,rev=p.j.load(db)
    assert rev==1 and p.j.sha(row)==head
    dest=HERE/'checkpoints'/db.name
    # hot-backup via SQLite API; never mutate active source.
    co=sqlite3.connect(db);backup=sqlite3.connect(dest)
    co.backup(backup);backup.close();co.close()
    scenes.append({'name':tag,'seed':seed,'db':str(db.relative_to(HERE)),'checkpoint':str(dest.relative_to(HERE)),'source_kind':'REALSOURCE_CONDITIONAL_LAB_PRIORITY_ONLY','kind':'AOO_PRIORITY_ONLY','head':head,'revision':rev,'order':state['r43']['priority']['order'],'tape':state['r43']['priority']['rng_tape'],'status':state['phase'],'no_world_mutations':True,'sha_live':hashlib.sha256(db.read_bytes()).hexdigest(),'sha_checkpoint':hashlib.sha256(dest.read_bytes()).hexdigest()})
    return row,state

# 1 R43 two Goats B1 identical DES, R18 dice without injection.
r,s=p.j.load(HERE/'ledgers/R43_B1_EQUAL_DES_SEED96001.sqlite')[:2] if False else (None,None)
# This seed is already recorded by the new R43 independent order event; do not execute again.
DB1=HERE/'ledgers/R43_B1_EQUAL_DES_SEED96001.sqlite'
st,head,rev=p.j.load(DB1)
co=sqlite3.connect(DB1);bk=sqlite3.connect(HERE/'checkpoints'/DB1.name);co.backup(bk);bk.close();co.close()
scenes.append({'name':'B1_EQUAL_DES','seed':96001,'db':str(DB1.relative_to(HERE)),'checkpoint':'checkpoints/'+DB1.name,'head':head,'revision':rev,'order':st['r43']['priority']['order'],'tape':st['r43']['priority']['rng_tape'],'status':st['phase'],'source_kind':'REALSOURCE_CONDITIONAL_LAB_PRIORITY_ONLY','no_world_mutations':True,'sha_live':hashlib.sha256(DB1.read_bytes()).hexdigest(),'sha_checkpoint':hashlib.sha256((HERE/'checkpoints'/DB1.name).read_bytes()).hexdigest()})
check('R43_BRONZE_EQUAL_DES_REAL_RNG',st['r43']['priority']['order']==[B,C] and [d['die'] for d in st['r43']['priority']['rng_tape']]==[6,4] and rev==1,st['r43']['priority'])
# 2 Frigido DES18 and Goat DES8: no dice tie and priority DES18.
r,st=create('UNEQUAL_DES',96002,{B:base[B],C:p.actor(C,FRIGID,(0,1.5))})
check('HIGH_DES_FIRST_NO_RNG',[C,B]==st['r43']['priority']['order'] and st['r43']['priority']['rng_tape']==[],st['r43']['priority'])
# 3 Scan for FIRST deterministic tie B/C on first drawn d6, including a recurrent tie on second.
scan=[];second=None
for seed in range(96003,99000):
  first=[p.j.dice(seed,1,'R43-AOO-PRIORITY:'+aid,1,6)[0] for aid in (B,C)]
  if first[0]!=first[1]:continue
  second=[p.j.dice(seed,2,'R43-AOO-PRIORITY:'+aid,1,6)[0] for aid in (B,C)]
  if second[0]==second[1]:
    scan=[{'seed':seed,'step1':first,'step2':second}];break
assert scan,'SCAN_NO_REPEATED_TIE'
seed=scan[0]['seed'];r,st=create('REPEATED_DICE_TIE',seed)
re=st['r43']['priority'];check('TIED_DICE_REROLL_TIED_ONLY',len(re['rng_tape'])>=6 and re['rng_tape'][0]['die']==re['rng_tape'][1]['die'] and re['rng_tape'][2]['die']==re['rng_tape'][3]['die'] and len(re['order'])==2,re)
# 4 One enemy safe from attack of opportunity, another still eligible.
r,st=create('SAFE_ONE_OTHER_ELIGIBLE',96004,base,safe_against=(B,),safe_standard_paid=True)
check('SAFE_EXIT_SINGLE_TARGET_OTHER_PRIORITY',st['r43']['priority']['candidate_ids']==[C] and st['r43']['priority']['order']==[C] and st['r43']['priority']['rng_tape']==[],st['r43']['priority'])
# 5 Forced movement suppresses both opportunities, no dice or reactions.
r,st=create('FORCED_MOVEMENT_NOT_AOO',96005,base,movement_kind='FORCED')
check('FORCED_PUSH_NO_AOO',st['r43']['priority']['order']==[] and st['phase']=='NO_AOO_TRIGGER' and st['reaction_consumed']==0,st['phase'])
# 6 One has spent slot, only the other may attack.
spent=copy.deepcopy(base);spent[B]['reaction']=0
r,st=create('SPENT_SLOT',96006,spent)
check('SPENT_SLOT_CANNOT_QUEUE',st['r43']['priority']['order']==[C] and st['reaction_consumed']==0,st['r43']['priority'])
# 7 Three distinct eligible attackers, 18 DEX first and tie-break the two DES8.
three={B:base[B],C:base[C],D:p.actor(D,FRIGID,(-1.5,0))}
r,st=create('THREE_ELIGIBLE_MIXED_DES',96007,three)
check('THREE_CANDIDATES_DES_AND_TIE',st['r43']['priority']['order'][0]==D and set(st['r43']['priority']['order'][1:])=={B,C} and {d['id'] for d in st['r43']['priority']['rng_tape']}=={B,C},st['r43']['priority'])
# Rejected source / action scenarios without publishing or touching original ledgers.
base_state=p.genesis(96008,base)
for name,changes,expected in [
  ('UNAUTHORIZED_FAKE_LUTA',lambda s:s['attackers'][B].update({'normal_luta':6}),'UNAUTHORIZED_NORMAL_LUTA'),
  ('DICE_SOURCE_MISMATCH',lambda s:s['attackers'][B].update({'rank_faces':20}),'SOURCE_MISMATCH'),
  ('INVALID_REACTION_STOCKPILE',lambda s:s['attackers'][B].update({'reaction':2}),'INVALID_REACTION'),
  ('SAFE_EXIT_WITHOUT_STANDARD',lambda s:s.update({'safe_against':[B],'safe_standard_paid':False}),'SAFE_WITHOUT_STANDARD'),
  ('TWO_SAFE_TARGETS_ILLEGAL',lambda s:s.update({'safe_against':[B,C],'safe_standard_paid':True}),'SAFE_EXIT_AT_MOST_ONE'),
  ('UNKNOWN_ACTOR_SOURCE',lambda s:s['attackers'][B].update({'source_page_id':'NOT_REAL'}),'UNKNOWN_SOURCE')]:
    t=copy.deepcopy(base_state);changes(t)
    try:p.order(t)
    except p.Hold as e:check('GATE_'+name,str(e)==expected,{'expected':expected,'got':str(e)})
    else:raise AssertionError('INVALID_ACCEPTED_'+name)
# Does not let the command be dispatched twice.
try:p.commit(DB1)
except p.Hold as e:check('DUPLICATE_PRIORITY_PREVENTED',str(e)=='NON_GENESIS',str(e))
else:raise AssertionError('DUPLICATE_ACCEPTED')
# Across 180 additional nonpersisted seeds, priority never uses actor name as fallback.
counts={B:0,C:0};max_step=0
for seed in range(100000,100180):
 st0=p.genesis(seed,base)
 out=p.order(st0);counts[out['order'][0]]+=1
 max_step=max(max_step,max([d['step'] for d in out['rng_tape']] or [0]))
 check('SEED_'+str(seed)+'_VALID_ORDER_NO_DAMAGE',set(out['order'])=={B,C} and all(1<=d['die']<=6 for d in out['rng_tape']),{'first':out['order'][0],'steps':len(out['rng_tape'])//2})
# Final records for independent audit and replay.
summary={'schema':'R43_MESTRE_AOO_PRIORITY_TESTS_V1','authority':'MESTRE_DES_THEN_HIGHEST_DIE','r26':'REROLL_ONLY_TIED_BRONZE_D6','status':'PASS','tests':len(cases),'scenes':len(scenes),'scenes_with_event_commit':len(scenes),'checks':cases,'scene_receipts':scenes,'repeated_tie_selected_first_in_96003_98999':scan,'unconditioned_observation_first_attacker_counts':counts,'unconditioned_observation_n':sum(counts.values()),'max_tie_steps':max_step,'movement_commits':0,'reaction_commits':0,'attack_commits':0,'canonical_effects':0,'no_claim_about_universal_fairness':True,'assumption':'Among identical Bronze1 sources, use Bronze rank 1d6 as R26 ties; independent cases of different-rank tied DEX not admitted here.'}
(HERE/'evidence/R43_PRIORITY_TESTS.json').write_text(J(summary))
print(json.dumps({'tests':len(cases),'scenes':len(scenes),'seed_repeated_tie':seed if False else scan[0]['seed'],'observation_counts':counts,'max_steps':max_step,'status':'PASS'}))
