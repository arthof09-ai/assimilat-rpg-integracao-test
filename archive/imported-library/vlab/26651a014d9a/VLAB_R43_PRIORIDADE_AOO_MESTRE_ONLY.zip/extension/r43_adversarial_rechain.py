"""R43 adversarial: mutate copied SQLite events then rehash chain; independent auditor MUST reject."""
from __future__ import annotations
import copy,json,hashlib,sqlite3,shutil,sys,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'extension'))
import r43_aoo_priority as p
J=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False,indent=2)+'\n'
SOURCE=ROOT/'checkpoints/R43_B1_EQUAL_DES_SEED96001.sqlite'
AUDITOR=ROOT/'extension/verify_r43_standalone.py'
CASES={
 'FLIP_ORDER':lambda row:row['detail']['computed']['order'].reverse(),
 'DICE_OUT_OF_RANGE':lambda row:row['detail']['computed']['rng_tape'][0].update({'die':7}),
 'DICE_CHANGED_WITHIN_RANGE':lambda row:row['detail']['computed']['rng_tape'][0].update({'die':1}),
 'FAKE_NORMAL_LUTA_GATE':lambda row:row['detail'].update({'attack_gate':'ATTACK_AUTHORIZED'}),
 'REACTION_CONSUMED_WITHOUT_ATTACK':lambda row:row['detail'].update({'reaction_consumed':1}),
 'FORGED_MOVEMENT_PUBLISHED':lambda row:row['detail'].update({'movement_published':True}),
 'TIED_DICE_TRANSCRIPT_FALSIFIED':lambda row:row['detail']['computed']['tie_resolution'][0]['draws'][0].update({'roll_total':2}),
 'SEED_CHANGED_WITHOUT_NEW_TAPE':lambda row:row['payload'].update({'seed':96003}),
}
results=[]
for name,mutation in CASES.items():
 with tempfile.TemporaryDirectory(prefix='R43_ADVERSARY_') as temp:
  file=Path(temp)/'mutated.sqlite';shutil.copy2(SOURCE,file)
  con=sqlite3.connect(file)
  seq,raw=con.execute('SELECT seq,row_json FROM events ORDER BY seq').fetchone();row=json.loads(raw)
  mutation(row)
  h=p.j.sha(row)
  con.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=?',(p.j.canonical(row),h,seq))
  con.execute('UPDATE meta SET value=? WHERE key=?',(h,'head'));con.commit();con.close()
  # Structural integrity is valid with regenerated hash, so only a mechanical check can catch it.
  state,head,rev=p.j.load(file)
  assert rev==1 and head==h,name+'_STRUCTURAL'
  rr=subprocess.run([sys.executable,str(AUDITOR),str(file)],capture_output=True,text=True,timeout=20)
  assert rr.returncode!=0 and rr.stderr.startswith('AUDIT_FAIL:'),name+' ADMITTED: '+rr.stdout+' '+rr.stderr
  results.append({'name':name,'structural_R18':'PASS_RECHAINED','mechanical_external':'REJECTED','reason':rr.stderr.strip(),'original_modified':False})
out={'schema':'R43_RECHAINED_AOO_MECHANICAL_NEGATIVE','status':'PASS','cases':len(results),'results':results,'mode':'MUTATE_TEMPORARY_COPY_ONLY','baseline_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'original_modified':False,'scope':'ORDER_AND_RESOURCE_AUDIT_NOT_NATIVE_DAMAGE'}
(ROOT/'evidence/R43_ADVERSARIAL_RECHAINED.json').write_text(J(out))
print(json.dumps({'status':'PASS','cases':len(results),'structural':'REHASH_ACCEPTED_EACH','mechanical':'REJECTED_EACH'},sort_keys=True))
