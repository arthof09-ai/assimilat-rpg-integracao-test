"""Independent R43 audit: no import of the R18/R26 engine or R43 resolver.
Verifies SQLite journal integrity AND mechanically reconstructs AoO order from
frozen source stats and a fresh implementation of R18 experimental dice stream.
"""
from __future__ import annotations
import copy,hashlib,json,math,random,sqlite3,sys,tempfile,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
GOAT='391c2b32-4ede-8252-b0cc-810423cdbfa6';FRIGID='f0dc2b32-4ede-820a-b947-0168d4a53315'
SOURCES={GOAT:('Bronze1',8,6),FRIGID:('Bronze5',18,6)}
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def H(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def check(cond,reason):
 if not cond:raise AssertionError(reason)
def dice(seed,step,label,faces):
 material=f'{seed}|{step}|{label}|1d{faces}|{VERSION}'
 return random.Random(int.from_bytes(hashlib.sha256(material.encode()).digest(),'big')).randint(1,faces)
def adjacent(a,b):return math.dist(a,b)<=1.5000001

def replay_rule(st):
 candidates=[]
 safe=st['safe_against']
 check(len(safe)<=1,'SAFE_MULTIPLE')
 check(not safe or st['safe_standard_paid'],'SAFE_FREE')
 for aid,a in sorted(st['attackers'].items()):
  check(a['id']==aid,'ACTOR_ID_MISMATCH')
  check(a['source_page_id'] in SOURCES,'SOURCE_UNKNOWN')
  rank,des,faces=SOURCES[a['source_page_id']]
  check((a['rank'],a['des'],a['rank_faces'])==(rank,des,faces),'ATTR_OR_DICE_FORGED')
  check(a['normal_luta'] is None,'FAKE_NORMAL_LUTA')
  check(a['reaction'] in (0,1),'REACTION_INVALID')
  if (st['movement_kind']=='VOLUNTARY' and aid not in safe and a['reaction']==1
     and adjacent(st['mover_from'],a['position']) and not adjacent(st['mover_to'],a['position'])):
   candidates.append(aid)
 if st['movement_kind']!='VOLUNTARY':check(st['movement_kind']=='FORCED','BAD_MOVEMENT_KIND')
 if not candidates:return {'order':[],'rng_tape':[],'tie_resolution':None,'candidate_ids':[], 'mode':'NO_ELIGIBLE_TRIGGERS'}
 grouped={}
 for aid in candidates:grouped.setdefault(st['attackers'][aid]['des'],[]).append(aid)
 tape=[];transcript=[];order=[]
 # Independent DES grouping and recursively rerolled tied dice; NO actor-ID fallback.
 def redivide(actors,step,des):
  if len(actors)==1:return actors
  check(step<=128,'TIE_LIMIT_REACHED')
  outcomes=[]
  for aid in actors:
   faces=st['attackers'][aid]['rank_faces']
   v=dice(st['seed'],step,'R43-AOO-PRIORITY:'+aid,faces)
   tape.append({'id':aid,'step':step,'label':'R43-AOO-PRIORITY:'+aid,'faces':faces,'die':v,'source':'R18_SHA256_TO_MT_EXPERIMENTAL'})
   outcomes.append({'id':aid,'roll_total':v,'ordinal':step})
  transcript.append({'initial_tie_total':0,'des':des,'step':step,'only_tied':actors,'draws':outcomes})
  grouped_roll={}
  for o in outcomes:grouped_roll.setdefault(o['roll_total'],[]).append(o['id'])
  result=[]
  for total in sorted(grouped_roll,reverse=True):
   result+=redivide(grouped_roll[total],step+1,des)
  return result
 for des in sorted(grouped,reverse=True):
  ids=grouped[des]
  check(len({st['attackers'][aid]['rank_faces'] for aid in ids})==1,'MIXED_DICE_TIE')
  order+=redivide(ids,1,des)
 return {'order':order,'rng_tape':tape,'tie_resolution':transcript,'candidate_ids':candidates,'mode':'MESTRE_R43_DES_THEN_R26_TIED_ROLL_ONLY'}

def audit(db):
 db=Path(db)
 conn=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
 try:
  check(conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLITE_INTEGRITY')
  me=dict(conn.execute('SELECT key,value FROM meta'))
  check(me.get('mode')=='EXPERIMENTAL_LAB_ONLY','NOT_LAB')
  check(conn.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0,'PENDING_EFFECT')
  st=json.loads(me['state']);rows=conn.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
  check(len(rows)==int(me['revision'])==1,'EVENT_DENOMINATOR')
  seq,cmd_id,prev,raw,row_sha,before_sha,after_sha=rows[0];row=json.loads(raw)
  check(seq==1 and row['seq']==1 and cmd_id==row['cmd_id'],'EVENT_SEQ_OR_ID')
  check(cmd_id.startswith('LAB-CMD-R43-'),'CMD_SCOPE')
  check(prev==row['prev']==me['genesis'],'GENESIS_CHAIN')
  check(H(row)==row_sha==me['head'],'HASH_RECHAIN_INVALID')
  check(after_sha==row['after_sha']==H(st),'FINAL_STATE_HASH')
  check(row['before_sha']==before_sha,'BEFORE_HASH_FIELD')
  check(row['kind']=='R43_AOO_PRIORITY' and row['payload']=={'kind':'AOO_PRIORITY','seed':st['seed']},'EVENT_CONTRACT')
  check(row['synthetic'] is True and row['official_effects']==0,'OFFICIAL_EFFECT_FLAG')
  check(st['synthetic'] is True and st['version']==VERSION,'BASELINE_VERSION')
  check(st['scene']=='R43-AOO-'+str(st['seed'])==me['scene'],'SCENE_ID')
  check(st['actors']=={},'REAL_WORLD_RESOURCE_STATE')
  check(st['r43']['version']=='R43-AOO-PRIORITY-ORDER-ONLY-v1','WRONG_POLICY_VERSION')
  check(st['r43']['authority']=='MESTRE_20261015_DES_THEN_HIGHEST_DIE','WRONG_POLICY_AUTHORITY')
  check(st['r43']['world_effects']==0 and st['r43']['pending_attack_effects'] is False,'WORLD_EFFECTS')
  check(st['mover']=='LAB_R43_GOAT_MOVER' and st['mover_from']==[0.,0.],'MOVER_SOURCE')
  orig=copy.deepcopy(st);orig['r43']['priority']=None;orig['phase']='R43_AOO_PREREQUISITE_ONLY'
  check(H(orig)==before_sha,'BEFORE_STATE_NOT_RECONSTRUCTIBLE')
  expected=replay_rule(st)
  check(st['r43']['priority']==expected,'RNG_OR_PRIORITY_MECHANIC_INVALID')
  detail=row['detail'];check(detail['computed']==expected,'EVENT_PRIORITY_DIVERGENCE')
  check(detail['kind']=='R43_AOO_ORDER' and detail['decision']=='MESTRE_DES_THEN_HIGHER_DIE','EVENT_DECISION')
  check(detail['attack_gate']==('BLOCKED_SOURCE_NORMAL_LUTA' if expected['order'] else 'NOT_APPLICABLE'),'ATTACK_GATE')
  check(st['phase']==('PRIORITY_RESOLVED_ATTACK_SOURCE_HOLD' if expected['order'] else 'NO_AOO_TRIGGER'),'BAD_PHASE')
  check(not st['movement_published'] and st['reaction_consumed']==0 and st['damage_published']==0,'UNAUTHORIZED_STATE_EFFECTS')
  check(detail['movement_published'] is False and detail['reaction_consumed']==0 and detail['damage_published']==0 and detail['actor_turn_modified'] is False and detail['world_effects']==0,'UNAUTHORIZED_EVENT_EFFECTS')
  return {'scene':st['scene'],'seed':st['seed'],'event_count':1,'head':row_sha,'order':expected['order'],'R18_dice_reproduced':len(expected['rng_tape']),'R26_rerolls':len(expected['tie_resolution'] or []),'damage':0,'reaction_spent':0,'passed':True}
 finally:conn.close()

def all_from_directory(root):
 root=Path(root);files=sorted((root/'ledgers').glob('R43_*.sqlite'))
 check(files,'NO_LEDGER_FILES')
 outputs=[]
 for f in files:
  orig=audit(f)
  checkpoint=root/'checkpoints'/f.name
  check(checkpoint.exists(),'CHECKPOINT_MISSING')
  cp=audit(checkpoint)
  check(orig['head']==cp['head'] and orig['order']==cp['order'] and orig['seed']==cp['seed'],'CHECKPOINT_LOGIC_DIVERGENT')
  outputs.append(orig)
 return {'status':'PASS','scenes':len(outputs),'ledgers_and_checkpoints':2*len(outputs),'events':len(outputs),'dice_reproduced':sum(x['R18_dice_reproduced'] for x in outputs),'scenes_report':outputs,'oracle':'INDEPENDENT_PYTHON_STDLIB_NO_R18_R26_IMPORT'}

if __name__=='__main__':
 try:
  target=Path(sys.argv[1]) if len(sys.argv)>1 else R
  if target.is_file() and target.suffix=='.sqlite':result=audit(target)
  elif target.is_file() and target.suffix=='.zip':
   with tempfile.TemporaryDirectory(prefix='R43COLD_') as temp:
    with zipfile.ZipFile(target) as z:
     check(z.testzip() is None,'ZIP_CRC')
     for name in z.namelist():
      check(not name.startswith('/') and '..' not in Path(name).parts,'UNSAFE_ZIP_PATH')
     z.extractall(temp)
    root=Path(temp)
    manifest=root/'R43_FILE_MANIFEST.json';check(manifest.exists(),'NO_FILE_MANIFEST')
    mm=json.loads(manifest.read_text())
    for path,sha in mm['sha256'].items():
     p=root/path;check(p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==sha,'BAD_MANIFEST_'+path)
    result=all_from_directory(root);result['file_hashes']=len(mm['sha256'])
  else:result=all_from_directory(target)
  print(json.dumps(result,ensure_ascii=False,sort_keys=True))
 except Exception as e:
  print('AUDIT_FAIL: '+type(e).__name__+': '+str(e),file=sys.stderr);sys.exit(2)
