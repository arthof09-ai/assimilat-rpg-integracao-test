import sys,unittest,pathlib,json,copy
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'code'))
import r251_inbox_validator as z
class Inbox(unittest.TestCase):
 def test_crosswalk(self):self.assertEqual(z.verify()['target_items'],17)
 def test_no_ack_forgery(self):self.assertEqual(z.verify()['ack_created'],0)
 def test_priority_four(self):self.assertEqual(z.verify()['p1'],4)
 def test_14_ack_required(self):self.assertEqual(z.verify()['ack_required'],14)
 def test_single_db(self):self.assertEqual(z.ROOT.joinpath('reports/R251_INBOX_17_SNAPSHOT.json').exists(),True)
 def test_related_coord_in_separate_namespace(self):
  s=json.loads(z.ROOT.joinpath('reports/R251_INBOX_17_SNAPSHOT.json').read_text());self.assertTrue({39,112}.isdisjoint({i['id'] for i in s['rows']}))
if __name__=='__main__':unittest.main()
