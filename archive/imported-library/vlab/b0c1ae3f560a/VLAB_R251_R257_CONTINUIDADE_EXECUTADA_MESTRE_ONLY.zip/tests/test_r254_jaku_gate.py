"""Independent tests against actual historical R18 source tree, not a new VLAB motor."""
import unittest,sys,tempfile,pathlib,hashlib,sqlite3
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'code'))
import r254_jaku_gate as g
class JakuGate(unittest.TestCase):
 def setUp(self):
  self.d=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.d.name)/'lab.sqlite';g.init_db(self.p,'A',88251)
 def tearDown(self):self.d.cleanup()
 def test_printed_ca39(self):self.assertEqual(g.attack_pmf(39)['hits'],6)
 def test_normative_ca44_6(self):self.assertEqual(g.attack_pmf('44.6')['hits'],0)
 def test_44_6_fraction(self):self.assertEqual(g.attack_pmf(44.6)['prob'],'0')
 def test_source_residual(self):self.assertEqual(g.component_analysis()['unattributed_residual_if_all_three_stack'],'1d6+27')
 def test_source_not_equipped(self):self.assertFalse(g.component_analysis()['components_currently_stacking_legally'])
 def test_fire_tag_not_assumed(self):self.assertFalse(g.component_analysis()['source_tag_fire_legal'])
 def test_gate_holds_unverified(self):self.assertEqual(g.admission_preflight(self.p)['status'],'SOURCE_GATE_HOLD_NO_EXECUTION')
 def test_self_attestation_cannot_override(self):self.assertEqual(g.admission_preflight(self.p,supplied_decisions={k:True for k in g.GAPS})['status'],'SOURCE_GATE_HOLD_NO_EXECUTION')
 def test_original_admission_denies(self):self.assertEqual(g.admission_preflight(self.p)['original_a3_official_admission'],'DENY_HOLD')
 def test_zero_commits(self):self.assertEqual(g.admission_preflight(self.p)['new_r18_commits'],0)
 def test_byte_identity(self):
  s=self.p.read_bytes();g.admission_preflight(self.p);self.assertEqual(self.p.read_bytes(),s)
 def test_duplicate_read_only(self):
  a=g.admission_preflight(self.p);b=g.admission_preflight(self.p);self.assertEqual(a['r18_existing_state_head'],b['r18_existing_state_head'])
 def test_tampered_snapshot_rejected(self):
  c=sqlite3.connect(self.p);c.execute("update meta set value='{}' where key='state'");c.commit();c.close()
  with self.assertRaises(Exception):g.admission_preflight(self.p)
 def test_absent_source_id_denied(self):self.assertEqual(len(g.SOURCES),5)
 def test_both_modes_gated(self):
  for s in [39,44.6]:self.assertEqual(g.admission_preflight(self.p)['new_r18_commits'],0)
 def test_components_never_apply_weakness(self):self.assertFalse(g.component_analysis()['vulnerability_bonus_applied'])
if __name__=='__main__':unittest.main()
