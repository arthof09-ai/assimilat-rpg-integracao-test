PSV — VLAB / CHECKPOINT R251–R257 / MESTRE-SIDE TEST / SEM WRITER NOTION

# Leitura rápida

Esta entrega é um conjunto **incremental, não um motor paralelo**. Contém auditoria da única Inbox oficial, recuperação nativa do arquivo R18, pré-voo negativo do caso Jaku×Dragão, correções de interface para as opções `--seed` e `--scene` exclusivamente em cópia de laboratório, e ensaio de reprodutibilidade do RNG em paths distintos. Não altera R01–R250 nem a fonte oficial das fichas.

## Resultados de execução verificados

- R251: leitura SQL da `INBOX-COMESTRE-01` pela coluna nativa `Destinatário COMESTRE-ID`: 17 envelopes CM-000006, todos NOVA, quatro P1 (40,62,70,86), 14 exigem ACK. IBX-39 e IBX-112 foram classificados no grupo do Coordenador CM-000001, jamais apropriados pelo laboratório. Não houve ACK, writer ou mudança de Estado, porque perfil CM-000006 está PAUSED/I0001 não consumida.
- R252: R18 original integral recuperado da Biblioteca: ZIP **2.198 membros, 14.691.125 bytes, SHA256 e079da7aa5c16364a18515de3f4941583e394dc345493adabb9d2db06faceefc**, CRC PASS. Motor raiz em `fusion_stage12/vlab_r18_interactive.py` SHA256 f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368. **8/8** testes originais R18 executados PASS. O R237 parcial (945.394 bytes, SHA256 49c2db6ebf8fdae8e378355c3f017e95afe879c7e29ba72086044afdd190d4de) passou o cold auditor 299/299, 155 commits e 640 eventos históricos, mas não contém todo o runtime necessário para a suíte geral R18. O arquivo central `vlab_r18_interactive.py` tem hash idêntico no R18 e R237. Não é defeito de core por si.
- R253: fontes Mestre-only de Jaku, Manoplas e Dragão reabertas. Com `2d6+30` e ataque **estritamente superior** à CA: `CA39` permite 6/36; a fórmula não adjudicada `CA44,6` permite 0/36. Soma condicional de três componentes = `5d8+6`, mas ficha imprime `5d8+1d6+33`; residual `1d6+27` sem fonte individual comprovada. Não converter `ação bônus` nem `13 PA/dia` em PA/ativação, nem infusão espiritual flamejante em elemento Fogo sem norma. Nenhum evento oficial Jaku×Dragão.
- R254: adaptador de **admissão somente** liga `vlab_r18_interactive.load` e `a3_r03_source_admission.official_admission` existentes, sem resolvedor novo e sem execução de ataque. **16/16 testes PASS**, inclusive imutabilidade bytewise de SQLite, source inconsistente, falsa atestação, snapshot adulterado, CA física e normativa. Houve um `TypeError` inicial sobre CA decimal string, corrigido antes do PASS.
- R255: comprovado que o R18 original aceita `--seed 251111`, mas usa de fato `20261014` em `demo` com SQLite novo. Correção na **cópia R255**, sem alterar original, 8/8 regressões herdadas PASS, quatro cenas adicionais e 30 commits sintéticos, replay após conclusão sem novo commit e seed divergente recusada.
- R256: comprovado que o R18 original aceita `--scene B` ao reabrir `--scene A`, mas mantém A sem aviso. Correção incremental na **cópia R256**, 8/8 testes herdados PASS, três cenas adicionais e 24 commits sintéticos, tipo/seed incompatíveis rejeitados sem mutação, retoma B quando argumento omitido. Patch cumulativo `patch/R256_COMBINED_FROM_R18.patch` é o que deve ser aplicado ao R18 em **nova cópia descartável**, sem sobrescrever a fonte.
- R257: cinco pares com sementes iguais em caminhos SQLite diferentes executados sobre a cópia R256: 10 cenas e 78 commits sintéticos; HP/PA finais, vencedor e número de commits iguais em todos os pares. Hash da cadeia diferente porque `cmd_id` incorpora path; isso não prova falha de RNG.

## Provas, escopo e governança

`reports/*.json`: dados e checkpoints; `tests/`: 22 testes próprios R251/R254; `patch/`: diffs e provas executáveis R255/R256/R257; `code/`: somente validadores e adaptador fonte-gated; `SHA256_MANIFEST.json`: SHA de cada arquivo do pacote; `portable_verify.py`: readback local do manifesto. O pacote **não contém** cópia extra do ZIP histórico R18 de 14,7 MB: o original já está na Biblioteca, preservado.

**NAC-PASS-02 proporcional ao escopo da bancada:** patches/testes próprios verificados. **Terminal 0/17; células oficiais 0/1875; Green/Strict/writer/epoch/lease/fencing HOLD; nenhuma escrita em Party, O Primeiro, DMG, fichas, Inbox, OP ou Diário Notion.** Não declarar ACK por instância não legitimada.

## Recuperar em outra execução

1. Reabrir o R18 original na pasta Mestre `/Comestre/OP-VLAB-FUSION-SANDBOX-01/`; confirmar tamanho, hash e CRC. Extrair numa pasta imutável e criar outra cópia para experimento.
2. Aplicar na cópia `patch -p1 < patch/R256_COMBINED_FROM_R18.patch`. `R255` é histórico do primeiro delta; não aplicar R255 novamente após o patch combinado.
3. Rodar 8 testes originais `test_vlab_r18_interactive.py` com `PYTHONPATH=fusion_stage12:native:reconstruction:working` dentro da cópia. Definir `VLAB_R18_ROOT=/caminho/copia` e rodar os 22 testes de `tests` e os scripts de patch R255/R256/R257. O `portable_verify.py` sozinho valida o arquivo do pacote; não substitui regressões.
4. Reabrir Inbox antes de qualquer resposta/ACK. O item IBX-40 permanece ancorado em CM-000006 com P1, writer da OP indisponível. Não consumir `I0001` por analogia; continuar laboratório isolado.
5. **FIRST-PENDING R258:** aplicar guards de cenário/seed na interface de demonstração em uma cópia integrada mais recente, após diff e verificação de que ainda existem, sem duplicar código. Em paralelo, resolver fonte/legalidade de Jaku×Dragão apenas com decisão competente; progredir contratos nativos (zero terminal) e benchmarks B/D/E após fichas P4.

**Ponto exato:** LAST VERIFIED R257; no-repeat R01–R257; source historical ZIP R18 intacto; normalized successor controls HOLD.
