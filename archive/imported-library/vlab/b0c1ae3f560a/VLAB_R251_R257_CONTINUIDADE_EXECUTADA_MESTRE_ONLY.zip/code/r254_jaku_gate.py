"""VLAB R254 — admission-only bridge into ORIGINAL Stage12 R18 / A3 source gate.
No combat resolver. No action executed. NO-WRITE to Notion, Party, original runtime.
"""
from __future__ import annotations
import sys, pathlib, hashlib, itertools, json, os
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[1]
R18=pathlib.Path(os.environ.get('VLAB_R18_ROOT','/mnt/data/vlab_r251_work/R18_ORIGINAL_EXTRACT'))
for d in [R18/'fusion_stage12',R18/'native',R18/'reconstruction',R18/'working']:
    sys.path.insert(0,str(d))
from vlab_r18_interactive import init_db, load, LabHold, connect
from a3_r03_source_admission import official_admission

SOURCES={
  'jaku':'07dc2b324ede82aeb27501f9414bfc81',
  'gauntlets':'592c2b324ede8385b926013aac7146ca',
  'dragon':'4fac2b324ede824da70d0189f19533de',
  'combat':'3ebc2b324ede81f1be4be8804ac113c0',
  'beast':'3ebc2b324ede81f4992ac88a3588cacd'
}
GAPS=(
 'DEC_BONUS_ACTION_NO_EQUIVALENCE',
 'DEC_INFUSION_SPIRITUAL_FLAMEJANTE_NOT_FIRE_TAG_PROVEN',
 'DRAGON_CA_39_VS_NORMATIVE_44_6_CONFLICT',
 'EQUIPMENT_EQUIPPED_AND_ACTIVATED_NOT_RECONCILED',
 'PA_13_PER_DAY_NOT_ACTIVATION_COST',
 'SCENE_TURN_REACTION_RNG_AND_SOURCE_FREEZE_MISSING',
 'DRAGON_RD_AND_VULNERABILITY_COMPONENT_TAG_PENDING',
 'JAKU_HP_PA_CURRENT_SESSION_UNVERIFIED',
 'P4_COMPLETE_LEGAL_FIXTURE_AND_INDEPENDENT_REVIEW_MISSING',
 'WRITER_LEASE_EPOCH_FENCING_UNVERIFIED',
)
def attack_pmf(ca):
    ca=Fraction(str(ca))
    num=sum(1 for a,b in itertools.product(range(1,7),repeat=2) if a+b+30>ca)
    return {'CA':str(ca),'hits':num,'total':36,'prob':str(Fraction(num,36))}
def component_analysis():
    # Jaku source prints weapon 2d8+2, infusion +2d8+2, gauntlet +1d8+2
    return {'possible_additive_pool':'5d8+6',
      'printed_attack_pool':'5d8+1d6+33',
      'unattributed_residual_if_all_three_stack':'1d6+27',
      'components_currently_stacking_legally':False,
      'source_tag_fire_legal':False,'vulnerability_bonus_applied':False}
def admission_preflight(lab_db, *, supplied_decisions=None):
    """Read original R18 state and original A3 official gate; return HOLD with no commands."""
    before=pathlib.Path(lab_db).read_bytes()
    state,head,rev=load(lab_db)
    if state['synthetic'] is not True:raise LabHold('NOT_ISOLATED_LAB')
    official=official_admission({'canonical_credits':0,'official_duels':0},None,requested_mode='OFFICIAL')
    assert official['status']=='DENY_HOLD' and official['credits_written']==0
    # Self-reported decisions/booleans NEVER override unverified external authority.
    if pathlib.Path(lab_db).read_bytes()!=before:raise AssertionError('READ_ONLY_MUTATED_DB')
    return {'status':'SOURCE_GATE_HOLD_NO_EXECUTION','source_page_ids':SOURCES,
      'scene_is_synthetic':True,'r18_existing_state_head':head,
      'r18_existing_revision':rev,'blocked_by':list(GAPS),
      'reported_decisions_not_attested':bool(supplied_decisions),
      'original_a3_official_admission':official['status'],
      'original_a3_canonical_credits':official['credits_written'],
      'new_r18_commits':0,'source_legal_full_fights':0,'official_cells':0,
      'no_effects_applied':True,'policy':'MESTRE_SIDE_TEST_READ_ONLY'}
