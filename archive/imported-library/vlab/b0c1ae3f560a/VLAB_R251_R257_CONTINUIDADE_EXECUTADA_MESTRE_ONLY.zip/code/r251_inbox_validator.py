"""Read-only closed snapshot auditor; NOT a Notion inbox updater."""
import pathlib,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
def verify():
 d=json.loads((ROOT/'reports/R251_INBOX_17_SNAPSHOT.json').read_text())
 rows=d['rows'];assert len(rows)==17 and len({r['id'] for r in rows})==17
 assert all(r['status']=='NOVA' for r in rows)
 assert sum(r['ack_required'] for r in rows)==14
 assert {r['id'] for r in rows if r['priority']=='P1-URGENTE'}=={40,62,70,86}
 assert {r['id'] for r in rows if not r['ack_required']}=={120,152,160}
 assert all(r['id'] not in {39,112} for r in rows)
 assert d['acked_by_authenticated_instance']==0 and not d['writer_fencing_verified']
 assert d['notion_writes']==0 and d['party_writes']==0
 return {'result':'PASS_BOUND_RECIPIENT_SNAPSHOT','target_items':17,'ack_required':14,'p1':4,'ack_created':0,'db_writes':0}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False))
