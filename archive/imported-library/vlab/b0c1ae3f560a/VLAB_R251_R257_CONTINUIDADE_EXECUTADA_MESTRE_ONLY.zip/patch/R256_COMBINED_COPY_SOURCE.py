"""VLAB R18 — interface humana CLI sobre o motor nativo v0.8.1 e preflight v0.7.

Nada aqui calcula acerto, defesa, redução ou dano líquido: os resolvedores
históricos são os únicos que aplicam o ataque e a reação. O controlador somente
organiza decisões de um Mestre e avança turnos fictícios, sem autoridade STRICT.
SQLite WAL em host local, not a gateway distributed/Notion; os efeitos nativos
são calculados em cópias descartáveis e somente publicados com recibo durável.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, os, random, sqlite3, sys
from dataclasses import asdict, replace
from pathlib import Path

from a1_event_reducer import digest
from a2_r06_interattack_hp import _frame, _action_state, v07
from a2_r08_reaction_bridge import lab_defense_source
from unified_gateway import RebuiltManualRuntime, UnifiedSyntheticGateway, verify_pins
from vlab_action_catalog_v01 import AbilitySource, FrozenRuleEvidence, action_menu
from vlab_effects_v08 import Combatant, Scene, COMBAT_PAGE
from vlab_rd_v08 import Resistances
from vlab_transformation_limit_v09_rebuilt import TransformationUseLedger

VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
class LabHold(RuntimeError):pass

# FICTÍCIOS, não correspondem a combatentes vivos nem a Galidemus.
SCENARIOS={
 'A':{'title':'Duelo dos Vigias (fictício, sem reações)', 'reaction':False,
      'fighters':[
        {'id':'LAB_VIGIA_A','name':'Vigia da Aurora','hp':28,'pa':30,'ca':12,'for':13,'des':20,'con':6,'luta':0,'init_bonus':0,'damage_bonus':4,'damage_tag':'impacto','fort':1,'reflex':0},
        {'id':'LAB_VIGIA_B','name':'Vigia da Névoa','hp':28,'pa':30,'ca':12,'for':14,'des':5,'con':5,'luta':0,'init_bonus':0,'damage_bonus':5,'damage_tag':'cortante','fort':1,'reflex':0},
      ]},
 'B':{'title':'Guarda e Defesa (fictício, DEFENDER 0 PA)', 'reaction':True,
      'fighters':[
        {'id':'LAB_SENTINELA_A','name':'Sentinela Vermelha','hp':24,'pa':30,'ca':12,'for':13,'des':20,'con':6,'luta':0,'init_bonus':0,'damage_bonus':4,'damage_tag':'impacto','fort':1,'reflex':0},
        {'id':'LAB_SENTINELA_B','name':'Guardião do Portão','hp':30,'pa':30,'ca':13,'for':13,'des':5,'con':10,'luta':0,'init_bonus':0,'damage_bonus':5,'damage_tag':'cortante','fort':5,'reflex':0},
      ]}}

def canonical(obj):return json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha(obj):return hashlib.sha256(canonical(obj).encode()).hexdigest()
def dice(seed,seq,label,count,faces):
    """PRNG experimental auditável. Não há reivindicação de rolagem física ou certificada."""
    entropy=hashlib.sha256(f'{seed}|{seq}|{label}|{count}d{faces}|{VERSION}'.encode()).digest()
    rng=random.Random(int.from_bytes(entropy,'big'))
    return [rng.randint(1,faces) for _ in range(count)]

def initial(kind,seed):
    if kind not in SCENARIOS:raise LabHold('CENÁRIO NÃO SUPORTADO')
    actors={}
    for f in SCENARIOS[kind]['fighters']:
        if f['id'] in actors:raise LabHold('DUPLICATE_ACTOR')
        actors[f['id']]={'name':f['name'],'stats':copy.deepcopy(f),
          'resource':asdict(Combatant(f['id'],f['hp'],f['pa'],f['ca'],f['con'],0,f['fort'],f['reflex'],
                       'LAB-ZONE-1',rank='Bronze'))}
    return {'version':VERSION,'synthetic':True,'scene':kind,'seed':seed,'phase':'INIT',
      'round':0,'turn':0,'order':[],'active':None,'actors':actors,'roll_nonce':0,
      'winner':None,'finish_reason':None,'source_status':'LAB_ASSUMPTION_NO_CREDENTIALS',
      'historical_core':'RebuiltManualRuntime + Stage11ManualBridge + v0.8.1 resolver',
      'source_confidence':'FICTITIOUS_TEST_ONLY','terminal_contracts':0}

def connect(db):
    path=Path(db);path.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(str(path), timeout=15,isolation_level=None)
    con.execute('PRAGMA busy_timeout=15000')
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA synchronous=FULL')
    con.execute('PRAGMA foreign_keys=ON')
    return con

def init_db(db,scene,seed):
    db=Path(db)
    if db.exists() or db.with_suffix(db.suffix+'-wal').exists():raise LabHold('ARQUIVO JÁ EXISTE; NÃO SOBRESCREVER')
    con=connect(db)
    con.executescript('''CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
       CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY,cmd_id TEXT UNIQUE NOT NULL,
         prev TEXT NOT NULL,row_json TEXT NOT NULL,row_sha TEXT NOT NULL,
         before_sha TEXT NOT NULL,after_sha TEXT NOT NULL);
       CREATE TABLE IF NOT EXISTS pending(cmd_id TEXT PRIMARY KEY,base_head TEXT NOT NULL,
         kind TEXT NOT NULL,payload_json TEXT NOT NULL);
       ''')
    state=initial(scene,seed)
    entries={'scene':scene,'genesis':sha({'seed':seed,'scene':scene,'version':VERSION}),
       'head':sha({'seed':seed,'scene':scene,'version':VERSION}),'state':canonical(state),
       'revision':'0','mode':'EXPERIMENTAL_LAB_ONLY'}
    with con:
        for k,v in entries.items():con.execute('INSERT INTO meta(key,value) VALUES (?,?)',(k,v))
    con.close()
    return state

def _meta(con):return dict(con.execute('SELECT key,value FROM meta'))
def _read(con):
    meta=_meta(con)
    if meta.get('mode')!='EXPERIMENTAL_LAB_ONLY':raise LabHold('MODO NÃO AUTORIZADO')
    if con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]:
        raise LabHold('UNKNOWN_EFFECT: comando pendente; reconciliação manual, sem auto-replay')
    try:state=json.loads(meta['state']);head=meta['head'];prev=meta['genesis'];revision=int(meta['revision'])
    except (KeyError,ValueError,TypeError) as e:raise LabHold('METADATA CORROMPIDO') from e
    rows=list(con.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq'))
    if len(rows)!=revision:raise LabHold('LOG VS CONTADOR INCONSISTENTES')
    past=None
    for i,cmd_id,p,row_json,row_sha,before_sha,after_sha in rows:
        try:row=json.loads(row_json)
        except ValueError as e:raise LabHold('JOURNAL JSON INVÁLIDO') from e
        if (i!=row['seq'] or cmd_id!=row['cmd_id'] or p!=prev or row['prev']!=prev
            or sha(row)!=row_sha or row['before_sha']!=before_sha or row['after_sha']!=after_sha
            or (past is not None and before_sha!=past)):
            raise LabHold('HISTÓRICO OU ENCADEAMENTO ADULTERADO')
        prev=row_sha;past=after_sha
    if prev!=head or (past is not None and past!=sha(state)) or state.get('version')!=VERSION:
        raise LabHold('SNAPSHOT VS JOURNAL DIVERGENTE')
    if meta['scene']!=state.get('scene') or state.get('synthetic') is not True:
        raise LabHold('CENÁRIO CORROMPIDO OU NÃO SINTÉTICO')
    return state,head,revision

def load(db):
    if not Path(db).exists():raise LabHold('ARQUIVO NÃO ENCONTRADO')
    c=connect(db)
    try:return _read(c)
    finally:c.close()

def event_commit(db,cmd_id,kind,payload,runner,failpoint=None):
    """Durable intent, native calculation on a clone, then one SQLite atomic publish.

    On an unknown effect, a durable pending intent locks recovery. No retries.
    """
    if not isinstance(cmd_id,str) or not cmd_id.startswith('LAB-CMD-'):raise LabHold('CMD ID INVÁLIDO')
    con=connect(db)
    try:
        state,head,revision=_read(con)
        if con.execute('SELECT 1 FROM events WHERE cmd_id=?',(cmd_id,)).fetchone():
            raise LabHold('DUPLICATE COMMAND REJECTED')
        con.execute('BEGIN IMMEDIATE')
        s2,h2,r2=_read(con)
        if (s2,h2,r2)!=(state,head,revision):raise LabHold('OUTRA INSTÂNCIA AVANÇOU; REABRIR')
        con.execute('INSERT INTO pending VALUES (?,?,?,?)',(cmd_id,head,kind,canonical(payload)))
        con.commit() # durable intent before attempting any native calculation
        if failpoint=='AFTER_INTENT':os._exit(78)
        candidate=copy.deepcopy(state)
        try:detail=runner(candidate,payload,revision+1)
        except Exception as exc:
            # No published candidate, but effects might have run in memory.
            # fail closed rather than guessing that source has no side effect.
            raise LabHold('UNKNOWN_EFFECT_PENDENTE: '+str(exc)) from exc
        con.execute('BEGIN IMMEDIATE')
        meta=_meta(con)
        if (meta['head']!=head or int(meta['revision'])!=revision
          or con.execute('SELECT base_head FROM pending WHERE cmd_id=?',(cmd_id,)).fetchone()!=(head,)):
            raise LabHold('STALE_OR_MISSING_INTENT_LOCK')
        row={'seq':revision+1,'cmd_id':cmd_id,'kind':kind,'payload':payload,
             'detail':detail,'prev':head,'before_sha':sha(state),'after_sha':sha(candidate),
             'synthetic':True,'official_effects':0}
        row_sha=sha(row)
        con.execute('INSERT INTO events VALUES (?,?,?,?,?,?,?)',
                    (revision+1,cmd_id,head,canonical(row),row_sha,row['before_sha'],row['after_sha']))
        con.execute('UPDATE meta SET value=? WHERE key=?',(canonical(candidate),'state'))
        con.execute('UPDATE meta SET value=? WHERE key=?',(row_sha,'head'))
        con.execute('UPDATE meta SET value=? WHERE key=?',(str(revision+1),'revision'))
        con.execute('DELETE FROM pending WHERE cmd_id=?',(cmd_id,))
        con.commit()
        if failpoint=='AFTER_COMMIT':os._exit(77)
        return row
    finally:con.close()

def _source():
    source=AbilitySource('LAB-R18-BASIC-ATTACK','attack','STANDARD',COMBAT_PAGE,
       'LAB-R18-EXPLICIT-FICTITIOUS-1D6+BONUS','LAB-ASSUMPTION',required_pa=0,
       target_scope='ENEMY',effect_adapter_ready=True,effect_adapter_id='LAB-V081-NATIVE-ATTACK')
    proof=FrozenRuleEvidence(source.source_page_id,source.rule_id,
             hashlib.sha256((source.rule_id+'|LAB-FAKE-NOT-CANON').encode()).hexdigest(),
             'TEST_FIXTURE_NO_OFFICIAL_AUDIT','MOCK-R18-BASIC')
    return source,proof

def _native(candidate,actor,target,reaction,hit_roll,damage_roll,revision):
    verify_pins()
    # The historical v0.8.1 combat core does all hit, guard, mitigation,
    # HP and budget mechanics. We only provide scored rolls and source IDs.
    fighters={}
    for aid,obj in candidate['actors'].items():
        fighters[aid]=Combatant(**obj['resource'])
    before_pa={k:v.pa for k,v in fighters.items()}
    scene=Scene(fighters,seed=candidate['seed'])
    ledger=TransformationUseLedger(test_fixture_authorized=True)
    for aid in fighters:ledger.register(aid)
    native=RebuiltManualRuntime(scene=scene,ledger=ledger,
        scene_id='LAB-SCENE-R18-'+candidate['scene'],test_fixture_authorized=True)
    bridge=UnifiedSyntheticGateway(native,test_only=True)
    src,proof=_source()
    attack_state=_action_state(native,actor,src)
    payload={'roll_score':hit_roll,'damage':damage_roll,
          'damage_tag':candidate['actors'][actor]['stats']['damage_tag'],
          'rd':Resistances(general=0,specific=(),provenance='LAB-FIXTURE-RD0')}
    kw={'event_id':'LAB-EVT-R18-'+str(revision),'attacker_id':actor,
        'defender_id':target,'attacker_frame':_frame(native,actor,'LAB-R18-'+str(revision)),
        'defender_frame':_frame(native,target,'LAB-R18-'+str(revision)),
        'strict':False,'attack_source':src,'attack_proofs':(proof,),
        'attack_payload':payload}
    if reaction=='DEFENDER':
        defense,defproof=lab_defense_source(defense_kind='DEFENDER',
             proof_label='LAB-FIXTURE-V081-BEFORE-ATTACK',cost_pa=0)
        ds=replace(_action_state(native,target,defense),reaction_trigger_observed='BEFORE-ATTACK')
        result=bridge.attack_with_defense(**kw,attack_state=attack_state,
              defense_source=defense,defense_state=ds,defense_proofs=(defproof,),
              defense_kind='DEFENDER',announced_before=True,trigger_source='BEFORE-ATTACK')
        fx=native.trace[-1]['effect_event'];att=fx['attack'];react=fx['reaction']
    else:
        result=bridge.action(event_id=kw['event_id'],actor_id=actor,
          frame=kw['attacker_frame'],strict=False,action_id=src.action_id+':'+target,
          sources=(src,),state=attack_state,proofs=(proof,),payload=payload,
          manual_turn_start=True)
        att=native.trace[-1]['effect_event'];react=None
    cp=bridge.checkpoint()
    if cp['executed']!=1 or not native.validate_trace() or len(native.trace)!=1:
        raise LabHold('RECEIPT NATIVO INVALIDO')
    if att['to']!=target or att['roll_score']!=hit_roll or att['before_hp']!=candidate['actors'][target]['resource']['hp']:
        raise LabHold('HP ANTES OU ROLAGEM NATIVA DIVERGENTES')
    if att['before_hp']-att['after_hp']!=min(att['before_hp'],att['net']) or att['net']<0:
        raise LabHold('DANO NATIVO INCONSISTENTE')
    for aid,entry in native.scene.actors.items():
        candidate['actors'][aid]['resource']=asdict(entry)
    if (candidate['actors'][actor]['resource']['pa']!=before_pa[actor] or
        candidate['actors'][target]['resource']['pa']!=before_pa[target]):
        raise LabHold('PA POSITIVO NÃO SUPORTADO SEM DEBITO NATIVO')
    return {'hit':att['hit'],'damage':att['net'],'damage_raw_effective':att['raw'],
       'defense_event':react,'native_attack_receipt':att,'native_trace_sha':native.trace[0]['chain_hash'],
       'native_gateway_receipt_sha':digest(result),'native_calls':1,
       'source_page_id':src.source_page_id,'source_rule':src.rule_id,
       'source_status':'LAB-ASSUMPTION','reaction_pa_cost':0,
       'reaction_spent_once':bool(react),'core':'v0.8.1 ATOMIC NATIVE RESOLVER'}

def do_start(st,params,revision):
    if st['phase']!='INIT':raise LabHold('JÁ INICIADO')
    rolls=[]
    for k,aid in enumerate(st['actors']):
        fs=st['actors'][aid]['stats'];draw=dice(st['seed'],0,'initiative:'+aid,1,6)
        rolls.append({'id':aid,'dice':draw,'des':fs['des'],'bonus':fs['init_bonus'],
                      'total':sum(draw)+fs['des']+fs['init_bonus']})
    if len(set(x['total'] for x in rolls))!=len(rolls):
        raise LabHold('INICIATIVA EMPATADA: NORMATIVA INDEFINIDA; ESCOLHER OUTRO CENÁRIO')
    rolls.sort(key=lambda x:-x['total'])
    st['order']=[x['id'] for x in rolls];st['phase']='ACTIVE';st['round']=1
    st['turn']=0;st['active']=st['order'][0]
    return {'kind':'INITIATIVE','rolls':rolls,'order':st['order'],'source':'Sistema de Combate — Dados Bronze 1d6 + DES + bônus',
            'tie_rule':'BLOCKED','turn_started':st['active']}

def _next_turn(st):
    prev=st['active']
    if st['phase']!='ACTIVE':return {'turn_end':prev,'next_turn':None}
    st['turn']=(st['turn']+1)%len(st['order'])
    if st['turn']==0:st['round']+=1
    st['active']=st['order'][st['turn']]
    a=st['actors'][st['active']]['resource']
    # Um novo turno abre uma nova ação padrão; reação NÃO renova automaticamente
    # porque momento exato de refresh está pendente para cenários avançados.
    a['standard']=1;a['movement']=1
    return {'turn_end':prev,'next_turn':st['active'],'round':st['round'],
            'standard_refreshed_at_new_turn':True,'reaction_auto_refresh':False}

def do_attack(st,params,revision):
    if st['phase']!='ACTIVE':raise LabHold('COMBATE NÃO ATIVO')
    actor=st['active'];target=params.get('target');reaction=params.get('reaction','NONE')
    if target not in st['actors'] or target==actor:raise LabHold('ALVO INVÁLIDO')
    if st['actors'][actor]['resource']['hp']<=0 or st['actors'][target]['resource']['hp']<=0:
        raise LabHold('ALVO/ATACANTE FORA DE COMBATE')
    if st['actors'][actor]['resource']['standard']!=1:raise LabHold('AÇÃO PADRÃO JÁ CONSUMIDA')
    if reaction not in ('NONE','DEFENDER'):raise LabHold('REAÇÃO NÃO SUPORTADA')
    if reaction!='NONE' and not SCENARIOS[st['scene']]['reaction']:raise LabHold('REAÇÃO INDISPONÍVEL NO CENÁRIO')
    if reaction!='NONE' and st['actors'][target]['resource']['reaction']!=1:
        raise LabHold('SEM REAÇÃO DISPONÍVEL')
    fs=st['actors'][actor]['stats'];nonce=st['roll_nonce']+1
    # Checking v0.7 existing reservation — not a second resource calculation.
    src,proof=_source()
    actor_obj=st['actors'][actor]['resource']
    round_state=v07.RoundState(actor_id=actor,available_pa=actor_obj['pa'],
                  pa_baseline_audited=True,reaction_available=actor_obj['reaction']==1)
    rv=v07.ActionReservation(actor_id=actor,action_id=src.action_id+':'+target,
                  source_page_id=src.source_page_id,action_slot='STANDARD',cost_pa=0,
                  source_state='UNIT_FIXTURE',effect_resolver_state='UNIT_FIXTURE')
    reservation=v07.reserve_turn(round_state,(rv,),action_windows=(None,),strict=False)
    if not reservation['permitted']:raise LabHold('V07 PREFLIGHT RECUSOU: '+str(reservation['blockers']))
    if reaction!='NONE':
        rdstate=v07.RoundState(actor_id=target,available_pa=st['actors'][target]['resource']['pa'],
                      pa_baseline_audited=True,reaction_available=True)
        dr=v07.ActionReservation(actor_id=target,action_id='LAB-R18-DEFENDER:'+target,
                     source_page_id=COMBAT_PAGE,action_slot='REACTION',cost_pa=0,
                     source_state='UNIT_FIXTURE',effect_resolver_state='UNIT_FIXTURE',
                     trigger_window='BEFORE_ATTACK')
        drp=v07.reserve_turn(rdstate,(dr,),action_windows=('BEFORE_ATTACK',),strict=False)
        if not drp['permitted']:raise LabHold('V07 REACTION DENIED: '+str(drp['blockers']))
    attack_dice=dice(st['seed'],nonce,'tohit:'+actor,1,6)
    damage_dice=dice(st['seed'],nonce,'damage:'+actor,1,6)
    attack_score=sum(attack_dice)+fs['for']+fs['luta']
    raw_damage=sum(damage_dice)+fs['damage_bonus']
    native=_native(st,actor,target,reaction,attack_score,raw_damage,revision)
    st['roll_nonce']=nonce
    victims=[aid for aid,x in st['actors'].items() if x['resource']['hp']<=0]
    if victims:
        st['phase']='COMPLETE_LAB';st['winner']=actor
        st['finish_reason']='HP_ZERO_LOCAL_EXPERIMENTAL';st['active']=None
        control={'turn_end':actor,'next_turn':None,'combat_ended':True}
    else:control=_next_turn(st)
    return {'kind':'ATTACK','attacker':actor,'target':target,'reaction':reaction,
      'dice':{'attack':attack_dice,'damage':damage_dice,'attack_modifier':fs['for']+fs['luta'],
              'damage_modifier':fs['damage_bonus'],'attack_score':attack_score,
              'damage_requested':raw_damage},'native':native,'v07_reservation':reservation['plan_sha256'],
      'control':control,'state_hp':{a:x['resource']['hp'] for a,x in st['actors'].items()},
      'state_pa':{a:x['resource']['pa'] for a,x in st['actors'].items()},
      'finish_reason':st['finish_reason'],'canonical_credits':0}

def do_pass(st,params,revision):
    if st['phase']!='ACTIVE':raise LabHold('COMBATE NÃO ATIVO')
    who=st['active'];st['actors'][who]['resource']['standard']=0
    return {'kind':'PASS','actor':who,'control':_next_turn(st),'canonical_credits':0}

def history(db):
    c=connect(db)
    try:
        st,head,rev=_read(c)
        rows=[{'seq':i,'hash':rh,**json.loads(j)} for i,rh,j in c.execute('SELECT seq,row_sha,row_json FROM events ORDER BY seq')]
        return {'state':st,'head':head,'events':rows,'revision':rev,'source':'LAB_ONLY'}
    finally:c.close()

def export(db,path):
    data=history(db)
    out=Path(path);out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():raise LabHold('EXPORT JÁ EXISTE; NÃO SOBRESCREVER')
    temp=out.with_suffix(out.suffix+'.tmp')
    with open(temp,'x',encoding='utf-8') as f:
        json.dump(data,f,indent=2,sort_keys=True,ensure_ascii=False)
        f.flush();os.fsync(f.fileno())
    os.replace(temp,out)
    return {'path':str(out),'hash':hashlib.sha256(out.read_bytes()).hexdigest(),'events':len(data['events'])}

def _show(st):
    print('\n=== VLAB EXPERIMENTAL — '+SCENARIOS[st['scene']]['title']+' ===')
    print('Estado:',st['phase'],'| rodada:',st['round'],'| turno:',st['active'] or '-')
    for aid,o in st['actors'].items():
        a=o['resource'];s=o['stats']
        print(f'  {aid} — {o["name"]}: Vida {a["hp"]}/{s["hp"]} | Alma {a["pa"]} | CA {a["ca"]} | Reação {a["reaction"]}')
        print(f'    FOR {s["for"]} / DES {s["des"]} / CON {s["con"]} / Fort {s["fort"]} / Reflex {s["reflex"]}; dados B1 1d6, Luta {s["luta"]}; dano fictício 1d6+{s["damage_bonus"]} {s["damage_tag"]}')
        print(f'    Padrão {a["standard"]} | Movimento {a["movement"]} | Condições: nenhuma na fixture (efeitos avançados HOLD)')
    if st['winner']:print('FIM: vencedor',st['winner'],'—',st['finish_reason'])

def prompt(msg,options):
    while True:
        try:x=input(msg).strip().lower()
        except EOFError:raise LabHold('ENCERRAMENTO DE ENTRADA: SALVO')
        if x in options:return x
        print('Opção inválida:',', '.join(sorted(options)))

def _uid(db,revision,kind):return 'LAB-CMD-'+sha({'db':str(Path(db).resolve()),'rev':revision,'kind':kind})[:24]

def next_save(db):
    p=Path(db)
    for n in range(2,10000):
        candidate=p.with_name(p.stem+f'_novo_{n:03d}'+p.suffix)
        if not candidate.exists():return str(candidate)
    raise LabHold('LIMITE DE ARQUIVOS; INFORMAR NOVO CAMINHO')

def play(db=None,seed=20261014):
    root=Path(__file__).resolve().parents[1]
    if db is None:db=root/'combates_experimentais'/'meu_combate.sqlite'
    db=str(db)
    if not Path(db).exists():
        print('Escolha: A = duelo fictício | B = duelo com reação DEFENDER')
        kind=prompt('Cenário [a/b]: ',{'a','b'}).upper()
        init_db(db,kind,seed)
    while True:
        state,head,rev=load(db)
        _show(state)
        if state['phase']=='INIT':
            choice=prompt('1 Iniciar combate | 2 Histórico | 0 Sair: ',{'1','2','0'})
            if choice=='0':print('Salvo em',db);return
            if choice=='2':print('Eventos:',rev);continue
            row=event_commit(db,_uid(db,rev,'START'),'START',{},do_start)
            print('Iniciativa:',row['detail']['rolls']);continue
        if state['phase']=='COMPLETE_LAB':
            choice=prompt('1 Histórico | 2 Exportar recibo | 3 Novo combate | 0 Encerrar: ',{'0','1','2','3'})
            if choice=='1':
                for r in history(db)['events']:print(r['seq'],r['kind'],r['detail'].get('kind'),r['row_sha'] if 'row_sha' in r else r['hash'])
                continue
            if choice=='3':
                db=next_save(db)
                print('Novo salvamento:',db)
                kind=prompt('Cenário A ou B: ',{'a','b'}).upper()
                init_db(db,kind,seed)
                continue
            if choice=='2':
                path=Path(db).with_name(Path(db).stem+'_recibo.json')
                print(export(db,path));continue
            print('Combate preservado em',db);return
        choice=prompt('1 Atacar | 2 Passar turno | 3 Histórico | 4 Salvar e sair | 5 Exportar | 6 Novo combate: ',{'1','2','3','4','5','6'})
        if choice=='4':print('Combate salvo em',db);return
        if choice=='6':
            db=next_save(db)
            print('Combate anterior preservado. Novo arquivo:',db)
            kind=prompt('Cenário A ou B: ',{'a','b'}).upper()
            init_db(db,kind,seed)
            continue
        if choice=='3':
            for r in history(db)['events']:
                d=r['detail'];print('#',r['seq'],r['kind'],d.get('attacker',''),d.get('target',''),
                  'dano',d.get('native',{}).get('damage',''),r['hash'][:16])
            continue
        if choice=='5':
            print(export(db,Path(db).with_name(Path(db).stem+'_recibo.json')));continue
        if choice=='2':
            row=event_commit(db,_uid(db,rev,'PASS'),'PASS',{},do_pass)
            print('Turno encerrado. Próximo:',row['detail']['control']['next_turn']);continue
        target=next(a for a in state['actors'] if a!=state['active'])
        print('Alvo elegível: [1]',target,'—',state['actors'][target]['name'])
        if prompt('Escolher alvo: [1] selecionar / [0] voltar: ',{'1','0'})=='0':continue
        reaction='NONE'
        if SCENARIOS[state['scene']]['reaction'] and state['actors'][target]['resource']['reaction']==1:
            r=prompt('Defensor declara ANTES do ataque: [0] sem reação, [1] DEFENDER (0 PA): ',{'0','1'})
            if r=='1':reaction='DEFENDER'
        row=event_commit(db,_uid(db,rev,'ATTACK'),'ATTACK',{'target':target,'reaction':reaction},do_attack)
        info=row['detail'];print('Rolagem:',info['dice'],'Acerto bruto:',info['native']['hit'],
                                'Dano líquido:',info['native']['damage'])
        if info['native']['defense_event']:print('Defesa:',info['native']['defense_event'])
        if info['finish_reason']:print('Encerrado por HP zero no cenário fictício!')

def demo(db,scenario='A',use_reaction=False,crash_after=None,seed=None):
    if not Path(db).exists():
        init_db(db,'A' if scenario is None else scenario,20261014 if seed is None else seed)
    else:
        existing,_,_=load(db)
        if scenario is not None and existing['scene']!=scenario:
            raise LabHold('EXISTING_SCENE_TYPE_MISMATCH: use a different save path')
        if seed is not None and existing['seed']!=seed:
            raise LabHold('EXISTING_SCENE_SEED_MISMATCH: use a different save path')
    for _ in range(80):
        st,_,rev=load(db)
        if st['phase']=='COMPLETE_LAB':return history(db)
        cmd='START' if st['phase']=='INIT' else 'ATTACK'
        if cmd=='START':event_commit(db,_uid(db,rev,cmd),cmd,{},do_start)
        else:
            target=next(a for a in st['actors'] if a!=st['active'])
            reaction='DEFENDER' if use_reaction and SCENARIOS[st['scene']]['reaction'] and st['actors'][target]['resource']['reaction']==1 else 'NONE'
            fail='AFTER_COMMIT' if crash_after==rev+1 else None
            event_commit(db,_uid(db,rev,cmd),cmd,{'target':target,'reaction':reaction},do_attack,failpoint=fail)
    raise LabHold('DEMO SAFETY LIMIT 80 STEPS')

def main(argv=None):
    ap=argparse.ArgumentParser(description='VLAB R18 — combate fictício interativo Mestre-side')
    ap.add_argument('command',nargs='?',default='play',choices=['play','demo','status','history','export'])
    ap.add_argument('--save',default=None,help='arquivo SQLite salvo, para recuperar depois')
    ap.add_argument('--scene',choices=['A','B'],default=None)
    ap.add_argument('--seed',type=int,default=None,help='semente auditável experimental (use outro número para rolagens diferentes)')
    ap.add_argument('--reaction',action='store_true',help='demo: defensor usa DEFENDER quando elegível')
    ap.add_argument('--crash-after',type=int,help='demo: encerrar após commit da revisão indicada')
    ap.add_argument('--output',help='exportar JSON para arquivo NOVO')
    ns=ap.parse_args(argv)
    db=ns.save or str(Path(__file__).resolve().parents[1]/'combates_experimentais'/'meu_combate.sqlite')
    try:
        if ns.command=='play':play(db,20261014 if ns.seed is None else ns.seed)
        elif ns.command=='demo':
            result=demo(db,ns.scene,ns.reaction,ns.crash_after,seed=ns.seed)
            print(canonical({'status':result['state']['phase'],'events':result['revision'],
                 'winner':result['state']['winner'],'head':result['head'],
                 'hp':{a:x['resource']['hp'] for a,x in result['state']['actors'].items()}}))
        elif ns.command=='status':s,head,rev=load(db);_show(s);print('Eventos',rev,'hash',head)
        elif ns.command=='history':print(json.dumps(history(db),ensure_ascii=False,indent=2))
        elif ns.command=='export':
            if not ns.output:raise LabHold('--output é obrigatório')
            print(json.dumps(export(db,ns.output),ensure_ascii=False))
    except (LabHold,sqlite3.Error) as exc:
        print('HOLD: '+str(exc),file=sys.stderr);return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
