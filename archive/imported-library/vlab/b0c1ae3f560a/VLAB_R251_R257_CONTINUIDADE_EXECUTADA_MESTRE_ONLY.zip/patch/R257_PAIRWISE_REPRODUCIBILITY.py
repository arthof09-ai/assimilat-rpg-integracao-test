"""R257: repeat synthetic R18 scene seed on distinct SQLite paths in fully isolated copy."""
import pathlib,subprocess,tempfile,sys,sqlite3,json,os,hashlib
ROOT=pathlib.Path(os.environ.get('VLAB_R18_ROOT','/mnt/data/vlab_r251_work/R256_PATCHED_EXPERIMENTAL_COPY'))
CLI=ROOT/'INICIAR_VLAB.py'
def run(db,scene,seed):
 cmd=[sys.executable,str(CLI),'demo','--save',str(db),'--scene',scene,'--seed',str(seed)]+(['--reaction'] if scene=='B' else [])
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,cwd=ROOT,timeout=90)
 assert p.returncode==0,(p.stdout,p.stderr)
 with sqlite3.connect(db) as conn:
  d=dict(conn.execute('select key,value from meta'));s=json.loads(d['state']);commits=conn.execute('select count(*) from events').fetchone()[0]
  assert int(d['revision'])==commits and s['seed']==seed and s['scene']==scene and s['phase']=='COMPLETE_LAB'
  assert not conn.execute('select * from pending').fetchall()
  return {'seed':seed,'scene':scene,'commits':commits,'head':d['head'],
          'hp':{k:v['resource']['hp'] for k,v in s['actors'].items()},
          'winner':s['winner'],'stats':{k:v['resource']['pa'] for k,v in s['actors'].items()}}
def verify():
 pairs=[];total=0
 with tempfile.TemporaryDirectory() as temp:
  for idx,(scene,seed) in enumerate([('A',257410),('A',257411),('B',257412),('B',257413),('A',257414)]):
   a=run(pathlib.Path(temp)/f'a{idx}.sqlite',scene,seed)
   b=run(pathlib.Path(temp)/f'b{idx}.sqlite',scene,seed)
   assert a['hp']==b['hp'] and a['stats']==b['stats'] and a['winner']==b['winner'] and a['commits']==b['commits']
   # command-ID depends on absolute save path. Journal SHA may differ despite identical battle stats.
   pairs.append({'scene':scene,'seed':seed,'commits_per_clone':a['commits'], 'identical_final_hp':True,
    'identical_final_pa':True,'identical_winner':True,'identical_journal_head':a['head']==b['head']})
   total+=a['commits']+b['commits']
 return {'status':'PASS_R257_REPEATABILITY_5_INDEPENDENT_SEED_PAIRS',
   'pairs':pairs,'pairs_independent':5,'native_fictional_scenes':10,
   'total_lab_event_commits':total,'official_cells':0,'terminal_contracts':0,
   'note':'Narrative outcomes reproducible. Journal SHA is path-specific, not proof of RNG failure.'}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
