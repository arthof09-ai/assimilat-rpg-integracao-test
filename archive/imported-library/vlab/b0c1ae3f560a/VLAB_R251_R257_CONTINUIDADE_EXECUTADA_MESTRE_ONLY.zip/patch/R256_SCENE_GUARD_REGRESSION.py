"""R256 — typed scene mismatch fail-closed for new and resumed R18 demo."""
import os,sys,pathlib,subprocess,tempfile,sqlite3,json,hashlib
ROOT=pathlib.Path(os.environ.get('VLAB_R18_ROOT','/mnt/data/vlab_r251_work/R256_PATCHED_EXPERIMENTAL_COPY'))
CLI=ROOT/'INICIAR_VLAB.py'
def run(db,*args):
 return subprocess.run([sys.executable,str(CLI),'demo','--save',str(db),*args],capture_output=True,text=True,cwd=ROOT,timeout=90)
def state(db):
 with sqlite3.connect(db) as c:
  m=dict(c.execute('select key,value from meta'));s=json.loads(m['state']);return s,int(m['revision']),m['head']
def verify():
 with tempfile.TemporaryDirectory() as d:
  p=pathlib.Path(d)/'a.sqlite'
  a=run(p,'--scene','A','--seed','256901');assert a.returncode==0,a.stderr
  s,n,h=state(p);assert s['scene']=='A' and s['seed']==256901 and n>0
  by=p.read_bytes();wrong=run(p,'--scene','B','--seed','256901');assert wrong.returncode!=0 and 'EXISTING_SCENE_TYPE_MISMATCH' in wrong.stderr+wrong.stdout
  assert by==p.read_bytes()
  saved=run(p,'--scene','A','--seed','256902');assert saved.returncode!=0 and 'EXISTING_SCENE_SEED_MISMATCH' in saved.stderr+saved.stdout
  assert p.read_bytes()==by
  p2=pathlib.Path(d)/'b.sqlite';b=run(p2,'--scene','B','--seed','256902','--reaction');assert b.returncode==0,b.stderr
  sb,nb,hb=state(p2);assert sb['scene']=='B' and sb['seed']==256902
  # --scene omitted means do not overwrite the saved scene or require A.
  prior=p2.read_bytes();again=run(p2,'--seed','256902');assert again.returncode==0,again.stderr
  assert prior==p2.read_bytes()
  p3=pathlib.Path(d)/'default.sqlite';default=run(p3)
  assert default.returncode==0,default.stderr
  sd,nd,hd=state(p3);assert sd['scene']=='A' and sd['seed']==20261014
  return {'result':'PASS_R256_SCENE_AND_SEED_INPUT_GATES','native_new_scenes':3,
   'commits':n+nb+nd,'new_scenes':[['A',256901,n],['B',256902,nb],['A',20261014,nd]],
   'wrong_scene_rejected_without_write':True,'wrong_seed_rejected_without_write':True,
   'implicit_resume_existing_B_passed':True,'default_scene_A_passed':True,
   'official_contracts_credited':0,'party_writes':0}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
