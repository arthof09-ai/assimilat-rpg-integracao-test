"""Run against the copied full R18 Stage12 tree (not the historical zip, not official)."""
import subprocess,sys,tempfile,pathlib,sqlite3,json,hashlib,os
ROOT=pathlib.Path(os.environ.get('VLAB_R18_ROOT','/mnt/data/vlab_r251_work/R255_PATCHED_EXPERIMENTAL_COPY'))
CLI=ROOT/'INICIAR_VLAB.py'
def cli(path,scene,seed,react=False):
 cmd=[sys.executable,str(CLI),'demo','--save',str(path),'--scene',scene]
 if seed is not None:cmd+=['--seed',str(seed)]
 if react:cmd+=['--reaction']
 return subprocess.run(cmd,capture_output=True,text=True,cwd=ROOT,timeout=90)
def inspect(path):
 with sqlite3.connect(path) as c:
  meta=dict(c.execute('select key,value from meta'))
  state=json.loads(meta['state'])
  return {'seed':state['seed'],'phase':state['phase'],'revision':int(meta['revision']),
          'event_count':c.execute('select count(*) from events').fetchone()[0],
          'pending_count':c.execute('select count(*) from pending').fetchone()[0],
          'scene':state['scene'],'synthetic':state['synthetic'],
          'terminal_contracts':state['terminal_contracts'],
          'head':meta['head']}
def verify():
 assert CLI.is_file()
 out=[]
 with tempfile.TemporaryDirectory() as d:
  for i,(scene,seed,react) in enumerate([('A',251111,False),('B',251112,True),('A',251113,False),('B',None,True)]):
   p=pathlib.Path(d)/f'scene{i}.sqlite'
   r=cli(p,scene,seed,react)
   assert r.returncode==0,(r.stdout,r.stderr)
   a=inspect(p)
   assert a['seed']==(seed if seed is not None else 20261014)
   assert a['scene']==scene and a['phase']=='COMPLETE_LAB' and a['synthetic']
   assert a['pending_count']==0 and a['terminal_contracts']==0
   assert a['revision']==a['event_count'] and a['revision']>0
   snap=p.read_bytes();rerun=cli(p,scene,seed,react)
   assert rerun.returncode==0,(rerun.stdout,rerun.stderr)
   assert p.read_bytes()==snap,'NO NEW COMMIT EXPECTED ON COMPLETED SCENE'
   a['source_file_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
   a['command_output_sha256']=hashlib.sha256(r.stdout.encode()).hexdigest()
   out.append(a)
  # Explicit seed conflict must fail closed, with no mutation to completed scene.
  p=pathlib.Path(d)/'scene0.sqlite';before=p.read_bytes()
  bad=cli(p,'A',777777,False)
  assert bad.returncode!=0 and 'EXISTING_SCENE_SEED_MISMATCH' in (bad.stdout+bad.stderr)
  assert p.read_bytes()==before
 assert len({a['seed'] for a in out})==4
 return {'status':'PASS_R255_PATCHED_ORIGINAL_R18','runs':len(out),'native_synthetic_commits':sum(a['event_count'] for a in out),
         'resume_duplicate_commits':0,'seed_mismatch_rejected':True,
         'all_original_terminal_credits':0,'scenes':out,
         'canonical_credits':0,'source_r18_untouched':True}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
