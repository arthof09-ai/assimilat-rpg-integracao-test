"""Cold readback of package contents; not a claim of runtime replay or Notion writer."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent

def verify():
 m=json.loads((ROOT/'SHA256_MANIFEST.json').read_text())['files']
 actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256_MANIFEST.json'}
 assert actual==set(m),{'missing':sorted(set(m)-actual),'extra':sorted(actual-set(m))}
 for path,sha in m.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha,path
 import importlib.util
 p=ROOT/'code/r251_inbox_validator.py';spec=importlib.util.spec_from_file_location('x',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 assert mod.verify()['target_items']==17
 summary=json.loads((ROOT/'reports/OPERATIONAL_CHECKPOINT_R251_R257.json').read_text())
 assert summary['status']['terminal_contracts']=='0/17' and summary['inbox']['legitimate_ack_written']==0
 return {'status':'PASS_PACKAGE_BYTES_AND_BOUNDED_INBOX_INVARIANTS','files':len(m),'has_r18_runtime_in_package':False,'original_r18_tests_reexecuted_by_this_script':0,'official_terminal_certification':0}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
