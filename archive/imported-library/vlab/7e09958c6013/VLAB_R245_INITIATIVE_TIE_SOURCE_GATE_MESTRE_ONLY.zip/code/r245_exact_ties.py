#!/usr/bin/env python3
"""Pure mathematical source-gated initiative-tie study; no official tie-breaker supplied."""
import collections,itertools,json,hashlib
from fractions import Fraction
from pathlib import Path
OUT=Path('/mnt/data/VLAB_R245_INITIATIVE_TIE_SOURCE_GATE_MESTRE_ONLY')
RANKS={'Bronze':1,'Prata':2,'Ouro':3,'Ouro Negro':4,'Lendário':6}
D={}
for rank,n in RANKS.items():
    dp={0:1}
    for _ in range(n):
        new=collections.Counter()
        for a,num in dp.items():
            for d in range(1,7):new[a+d]+=num
        dp=dict(new)
    assert sum(dp.values())==6**n
    # independent brute force for manageable ranks (6 dice, 46656 terms)
    brute=collections.Counter(map(sum,itertools.product(range(1,7),repeat=n)))
    assert dp==dict(brute),(rank,'distribution mismatch')
    D[rank]=dp
rows=[]
for rank_a,dp_a in D.items():
 for rank_b,dp_b in D.items():
  all_states=6**(RANKS[rank_a]+RANKS[rank_b])
  for delta in [-20,-10,-5,-2,-1,0,1,2,5,10,20]:
   # delta = (DES_A + bonus_A) - (DES_B + bonus_B)
   count=sum(na*nb for va,na in dp_a.items() for vb,nb in dp_b.items() if va+delta==vb)
   prob=Fraction(count,all_states)
   rows.append({'rank_a':rank_a,'rank_b':rank_b,'dice_a':f'{RANKS[rank_a]}d6','dice_b':f'{RANKS[rank_b]}d6','bonus_delta_A_minus_B':delta,'tie_count':count,'sample_space':all_states,'tie_probability_exact':str(prob),'tie_probability_float':float(prob),'classification':'MATH_ONLY_NOT_R18_TEST'})
assert len(rows)==275
by={(r['rank_a'],r['rank_b'],r['bonus_delta_A_minus_B']):r for r in rows}
# A vs B symmetry (negate difference, exchange ranks)
for r in rows:
 s=by[r['rank_b'],r['rank_a'],-r['bonus_delta_A_minus_B']]
 assert s['tie_probability_exact']==r['tie_probability_exact']
# For same dice distributions, probability exactly equal with no bonuses is > 0 and decreases for moderate shifts.
for rank in RANKS:
 p0=by[rank,rank,0]['tie_probability_float']
 pm=by[rank,rank,10]['tie_probability_float']
 assert p0>0 and p0>=pm
# Tests of common incorrect rules: wrong 5d6 legendary, treating same star as initiative mod, or using d20.
assert RANKS['Lendário']==6
assert by['Bronze','Bronze',0]['tie_probability_exact']=='1/6'
summary={'stage':'R245','result':'PASS_EXACT_MATH_AND_SOURCE_GAP','authorities':['Sistema de Combate — Regra 2 (d6 por classificação, DES + bônus)','VLAB R218–R222 — tie blocked until source-guided norm'],'distinct_rank_pairs':25,'delta_samples_each':11,'conditional_scenarios':len(rows),'enumeration_tested':5,'pair_swap_symmetry_checks':len(rows),'bronze_bronze_no_bonuses_tie_probability':'1/6','legendary_legendary_zero_delta_tie_probability':by['Lendário','Lendário',0]['tie_probability_exact'],'rule_to_resolve_tie':'UNSPECIFIED_IN_CURRENT_SOURCE','official_initiative_tie_breaks_executed':0,'official_matrix_cells':0,'terminal_certificates':0,'result_scope':'MATH_ONLY / NO-CANON / NO-NEW-RULE / HOLD_NORM-004'}
(OUT/'reports/R245_EXACT_ENUMERATION_275.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(OUT/'reports/R245_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
