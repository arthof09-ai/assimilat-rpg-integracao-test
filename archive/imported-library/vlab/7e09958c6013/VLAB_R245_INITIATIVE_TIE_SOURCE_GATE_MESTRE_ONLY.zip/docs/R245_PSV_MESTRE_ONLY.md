PSV — R245 / OP-VLAB-FUSION-SANDBOX-01 / MESTRE-ONLY / TEST / NON-CANON

R245 — Probabilidade exata de empate de iniciativa por rank e delta de bonus. 275 cenarios matematicos; a fonte nao determina desempate. NORM-004 HOLD.

AUTORIA: executor tecnico em sandbox isolada, nao reivindica CM-000006, Instance-ID, lease, epoch, fencing, writer, ou GREEN.

ANTES: ultimo checkpoint historico R243; corpus R01–R243 e motor original preservados.
DEPOIS: resultado restrito aos arquivos e relatorios deste pacote.
NO-WRITE: Party, O Primeiro, fichas, combate, norma, DMG, LEVEL-UP, matrizes oficiais.
NAC-PASS-02: verificacao local dos artefatos e consistencia delimitada; terminal/global = HOLD.
Fonte primaria VLAB: https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2
Plano: https://app.notion.com/p/3f3c2b324ede81d480dbf11732734463
Pasta unica persistente: /Comestre/OP-VLAB-FUSION-SANDBOX-01/

Verificacao portatil: python portable_verify.py VLAB_R245_INITIATIVE_TIE_SOURCE_GATE_MESTRE_ONLY.zip
Sem arquivo ZIP nao confere a execucao real; reports e codigo preservam metodo e resultado.
