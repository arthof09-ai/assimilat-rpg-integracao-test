# SIM-DMG-VLAB-L04 — Gerador virtual experimental

**Classificação:** Mestre-only, PROTÓTIPO, não é cânone nem motor de combate completo. 08/10/2026.

O protótipo implementa o **gerador de snapshots efêmeros** para Espiritualistas de cinco raças oficiais (Humano, Orc, Abissiano, Asa Prateada, Raça Superior) e Bestas normais, com opções explícitas de traits somente como premissa experimental. Não cria fichas no Notion, não modifica o RPG, não executa lutas nem concede crédito à matriz de 1.875 células.

## Fontes mecânicas consultadas
- Criação de Ficha: `3ebc2b32-4ede-8144-9222-f3c06b840613`
- Criação de Besta: `3ebc2b32-4ede-81f4-992a-c88a3588cacd`
- Sistema de Combate: `3ebc2b32-4ede-81f1-be4b-e8804ac113c0`
- DMG-RANK-01 v1.1: `3f2c2b32-4ede-8154-98cd-db7844245f7e`
- SPEC L00–L03: `3f3c2b32-4ede-8176-8b38-d416ef3c9e3b`

## Executar
```bash
python -m unittest -v test_vlab_l04 test_vlab_l05_preflight
python generate_examples.py
```

Somente a biblioteca padrão de Python é utilizada. `build_human`, `build_beast` e `scenario_template` funcionam sem internet, login ou credenciais.

## Gaps tratados sem alteração de regra
- GAP-01: CA de Besta é fração exata, com status `integer_ready` e bloqueio condicional quando o arredondamento não consta da autoridade. Crescimento fixo 60% é arredondado ao inteiro mais próximo (Regra 5 da ficha). Não inventar método global.
- GAP-02: esta entrega **não implementa iniciativa/reações simultâneas**; sem ação sem fonte, não transforma `ActorSnapshot` em luta validada.
- GAP-03: esta entrega **não implementa terreno/alcance/AoE sem efeito específico**; `scenario_template` só monta elencos e hashes.

## Limitações explícitas
- A alocação round-robin dos atributos é uma **política de laboratório**, não distribuição canônica universal. Dados de raças além de Humanos não foram implementados. Cada raça obedece ao orçamento de criação e à progressão específicos documentados na Criação de Ficha. A interpretação Bronze1 como primeiro nível de progressão é rastreada como opção de laboratório.
- Marcos de FF são escolhas e rolagens fixas por seed e marco, com reuso; não são rerrolados em cada rodada. Os snapshots não incluem ainda proficiências, armas completas, técnicas nem IA tática.
- Bestas usam progressão, Vida/Alma, CA, RD e dano-base; não recebem habilidades fictícias nem PA presumido (`None`). Para Besta Divina/Chefe de Reino Subsidiário, a aplicabilidade da linha especial `140 + atributo` depende de interpretação competente: Vida/Alma ficam `None` e o caso é bloqueado para FULL-FIGHT. Atributos de Bestas Lendárias recebem as regras automáticas de Titã e ascensão.
- Traços ADM, Divina ou Titã antes do Lendário somente por premissa explícita; casos especiais são `CONDITIONAL-SENSITIVITY` e exigem revisão adicional da regra competente antes de simulação canônica.
- `scenario_template` compõe 2..200 instâncias (limite de preview de laboratório, não regra do RPG), com IDs e hashes; 20×20 é um **manifesto planejado**, não combate executado.
- `full_fight_eligible` permanece `False` para os exemplos por lacunas de ataque, economia de ação específica, equipamento, proficiência, posicionamento e política. Não há `RUN-EXECUTED` nem `REPLAY-VERIFIED`.

## L05 pré-flight seguro (parcial)
O arquivo `vlab_l05_preflight.py` demonstra validação estrita de uma ação por recurso, defesa antes do ataque, crítico sequencial 3d6, acerto estritamente maior que defesa, proibição de duplicar alvos e bloqueio de AoE sem fonte explícita. Não é scheduler funcional nem combate completo: a etapa L05 permanece PARCIAL.

## Critérios L04 de aceite técnico
1. Rank ordinal 1..25 íntegro para dois tipos de ator.
2. As escolhas sintéticas têm `seed` e `policy` explícitos.
3. Vida/Alma, CA, RD e FF são calculadas sem ignorar exceções de fonte; ausências são `None`/pendências.
4. Mesmo input gera o mesmo snapshot/hashes.
5. Composições 10×10 e 20×20 são montadas sem uma página Notion por combatente.
6. Baterias unitárias e stress sintético de invariantes passam; **nenhum PASS científico/experimental é reivindicado**.

## Evidência técnica de regressão
- 26 testes unitários PASS (L04 e pré-flight parcial L05).
- 1.906 verificações de propriedades e fail-closed sobre arquétipos e equipes, com seed fixa; 0 falhas.
- Os testes não são lutas. 0 FULL-FIGHTS, 0 pareamentos ANTES/DEPOIS.

## Próxima fronteira
L04 permanece como PROTÓTIPO TESTADO, aguardando revisão sobre escolhas de alocação e procedência. L05 exige adaptadores de ação, hit/defense/save, reações, target e desempate somente após autoridades/gates. O primeiro FULL-FIGHT ainda não foi executado.
