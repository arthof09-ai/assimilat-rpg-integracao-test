# SIM-DMG-VLAB | Protótipo L04–L06 v0.4

**Data:** 08/10/2026. **Superfície:** Projeto Comestre, Mestre-side. **Classificação:** engenharia de laboratório, *não* cânone, *não* playtest humano. O Sistema de Dano DMG-RANK-01 v1.1 e o ledger canônico não foram modificados.

## O que existe

O gerador `vlab_l04.py` constrói 150 arquétipos efêmeros, sendo 125 Espiritualistas (5 raças × 25 níveis) e 25 Bestas-base. O preflight `vlab_l05_preflight.py` valida orçamento de ações, reações, acerto estrito, críticos sequenciais e targeting. Nenhuma página de personagem é criada no Notion.

`vlab_l05_duel.py` realiza o primeiro ciclo completo **condicional de laboratório**: dois Humanos Bronze 1★, ambos com arma leve comum `1d4`, escolha de proficiência Luta `+2`, bônus de Força Física congelados, distância adjacente e política de ataque regular sem movimento, magia ou uso opcional de reação. Usa iniciativa, CA, ação padrão, rolagem de ataque, crítico sequencial, dano, Vida e encerramento experimental. A semente `1` produz **8 rodadas, 15 ações; lado A chega ao critério de término com 17 Vida restante**. `independent_replay()` é reexecução do mesmo motor com comparação completa do evento.

`audit_vlab_l05.py` é um *checker de traço separado*, que reconstrói rolagens determinísticas e verifica aritmética/eventos a partir do JSON, sem invocar o motor do duelo. **Não é auditoria humana independente.**

`vlab_l05_team.py` valida o primeiro **2×1 condicional de Humanos Bronze 1★** (dois do lado A contra um do lado B, ainda sem Besta). Semente `2`: **5 rodadas, 13 ações; vitória do lado A pelo critério experimental**. `audit_vlab_l05_team.py` verifica o traço coletado em outro módulo.

`stress_vlab_l05_duel.py` roda 500 sementes apenas como teste de execução e bloqueio: 336 cenários condicionais finalizados, 100 bloqueados por falha crítica sem consequência normatizada, 61 bloqueados por empate de iniciativa e 3 censurados por limite de 30 rodadas. Estes são **ensaios sintéticos e não evidência de equilíbrio do RPG**.

## Como reproduzir

```bash
python -m unittest -q test_vlab_l04 test_vlab_l05_preflight test_vlab_l05_duel test_vlab_l05_team
python run_vlab_l05.py
python audit_vlab_l05.py
python run_vlab_l05_team.py
python audit_vlab_l05_team.py
python stress_vlab_l05_duel.py
```

Python 3.10+ e biblioteca padrão, sem login, rede ou chave de API. **Os JSON integrais de combate e os arquivos CSV de eventos estão em `samples/`.** As sementes e hashes ficam nos relatórios.

## Fonte mecânica e procedência

- Criação de Ficha `3ebc2b32-4ede-8144-9222-f3c06b840613` — Vida/Alma/FF/CA/Proficiências, progressão e atributos.
- Sistema de Combate `3ebc2b32-4ede-81f1-be4b-e8804ac113c0` — iniciativa, ações, acerto, reações, crítico.
- DMG-RANK-01 v1.1 `3f2c2b32-4ede-8154-98cd-db7844245f7e` — dano da arma leve comum e bônus externos.
- Criação de Besta `3ebc2b32-4ede-81f4-992a-c88a3588cacd` — disponível no gerador, ainda **não consumida no piloto 2×1**.
- Especificação L00–L03 `3f3c2b32-4ede-8176-8b38-d416ef3c9e3b` e plano `3f3c2b32-4ede-81d4-80db-f11732734463`.

## Limitações que impedem crédito de combate canônico

1. **Vida ≤ 0 é somente condição de parada do experimento**, sem afirmar morte/incapacitação oficial.
2. A verificação sequencial `3d6` a cada tentativa de ataque é uma escolha protocolar de laboratório; a oportunidade exata dessa checagem precisa de reconciliação normativa. Se ocorrer `CRITICAL-FAIL`, o motor interrompe o ensaio e **não inventa o efeito**.
3. Se a iniciativa empatar, o run aborta; não foi criado desempate canônico.
4. As políticas de atacar sempre, não reagir, ficar adjacente e focar o primeiro alvo vivo são hipóteses explícitas, não comportamento obrigatório de personagens.
5. Efeitos em área, movimentação/alcance múltiplo, RD de Bestas, magias, controle, condições complexas e origem de poderes ainda precisam de integração e gates próprios.
6. Replay idêntico e checks de aritmética **não são aprovação NAC-NORM-01, nem auditoria independente de regras**. O ledger de 1.875 confrontos canônicos continua com **0** novos casos elegíveis/validados por esta entrega.
7. O protótipo de 2×1 comprova scheduler restrito com 3 atores Humanos, **não** 2 Espiritualistas contra Besta. Próxima integração: adaptador de Besta com aplicação da RD, CA fracionária, proficiência ofensiva, turnos/objetivos e reações fundamentadas.

## Continuidade

- **L04:** gerador parcial funcional/testado. Não declara cobertura de armas e habilidades completa.
- **L05:** kernel restrito de duelos e equipes pequenas com cenário condicional, sem generalização para todos os efeitos.
- **L06:** reexecução determinística com trilha, hashes e verificação por código independente limitada; não há auditoria externa.
- **L07+:** fases de teste/escala não iniciadas formalmente. Um ensaio 2×1 de compatibilidade não fecha L08.
- **Next:** fechar o contrato de Besta, auditoria normativa das lacunas e expandir para 2×1 ED×Besta; depois controles e cenários 5×5/10×10/20×20.
