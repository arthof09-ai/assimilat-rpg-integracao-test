# AUD-SIM-DMG-FAIR-AI-BEAST-01 — Auditoria de Justiça, IA Tática e Banco Experimental de Bestas

Status: Research/prototype-only, Mestre-side, not a new rule, no modification to DMG-RANK-01/Criação de Besta/Party.

## Findings from code inspection
- First 1×1 v0.4 used different legal Human Bronze1 builds (A FOR6 DES5, B FOR4 DES6), single cherry-picked representative seed without side test, identical basic-attack policy. A has 2/6 raw probability to exceed B CA12; B has 1/6 to exceed A CA11, before critical/ability effects. Different chances are part of attributes, not proof of A-coded favoritism.
- First 2×1 v0.4 hardcoded A1,A2 vs B1; role-reversal 1×2 rejected outright. A has two combatants and twice action budget in principle; not a 50/50 matchup.
- The legacy engine has no adaptive combat AI. Targets chosen by roster order; no healing, control, positioning, defense reaction, technique, magic or retreat.
- Legacy RNG streams depend on A/B labels and fixture hash; same seed under side swap does not provide true matched random paths.
- Critical failure and initiative ties abort; rates measured from COMPLETED only cannot be generalized to full fights, especially if aborts correlate with build or survival.

## Retrospective fairness audit
1,500 attempted seeds per orientation: Original stronger actor first A: 869/1018 completed won (85.36%; Wilson CI approx 83.06–87.40). Stronger actor moved to B: 872/1042 completed won (83.69%; CI by opposite-side A approx 81.32–85.80). This points to fixture strength, not obvious letter A favoritism.
Identical-stat twins: A win 546/1100 (49.64%; 95% CI 46.69–52.59) and 553/1103 (50.14%; CI 47.19–53.08). Strong evidence AGAINST obvious 1×1 letter favoritism **in this restricted conditional sample**, but no proof for all strategies and phases.

## Corrective v0.1 prototype
- One TacticalObservation schema and choose function for every fighter: role and tactical sophistication from source, current health and observable enemy cues; NO side input and NO secret enemy sheet or legal action creation.
- Action whitelist legal externally; propose attack/protect/heal/control/retreat/move/buff choices only if source adapter already authorized them.
- Side-independent actor-ID RNG stream and membership-normalized fixture; mirrored AB/BA the same physical actors and per-actor rolls. Tactic is a LAB HEURISTIC, not canonical.
- Generic conditional team scheduler accepts A/B swaps, source-legal Bronze1 ED attack adapter, and safe fail-closed for unknown critical failure, tie initiative. Unsupported beast adapters remain blocked.
- 2,000 attempted seeds for 2×1 side swaps: 1,180 complete mirror pairs with exact identical events/HP/physical winner; 660 blocked initiative ties, 160 blocked critical consequence. This is mirror SYMMETRY, not an unbiased tactical quality certificate.
- 71/71 unit tests across previous L04-L06 plus new fairness/tactics/data-ledger modules. No new official simulated full-fight credit.

## Tactical IA inspiration — NOT imported rules
1. The Monsters Know What They're Doing, 'Why These Tactics?' — creature survival motives, instincts and intelligence; adapt qualitative behavior only, NOT ability thresholds or flee-at-X% rule from D&D.
   https://www.themonstersknow.com/why-these-tactics/
2. The Monsters Know What They're Doing, 'Intelligent Enemy Tactics' — read the observable battlefield, coordinate based on capabilities, avoid omniscience or pre-knowledge of player sheets; adjust planning to RPG Assimilação.
   https://www.themonstersknow.com/intelligent-enemy-tactics/
3. Pathfinder 2e GM Core encounter design — compare party sizes, action economy, categories of threat and monster synergies. **Do not import XP budget, AC +2 cover, level offsets or encounter thresholds.**
   https://2e.aonprd.com/Rules.aspx?ID=+499
4. PF2e Building Creatures — calibrate holistic target outcomes and compensating strengths/weaknesses, not copy its numerical benchmarks.
   https://2e.aonprd.com/%28X%281%29S%28jukc1iyfrq5k4iqmyheysq45%29%29/Rules.aspx?ID=995
5. Sly Flourish Running Combat-Focused Adventures — encounter objectives, mixed roles and terrain; NOT rule import.
   https://slyflourish.com/running_combat_adventures.html
6. Sly Flourish Roll to Target (2026) — objective target choice should sometimes be uncertain rather than maximally optimized; use legal, fair contextual choice and symmetrical randomization.
   https://slyflourish.com/roll_to_target.html?rss=1

## AI competence contract
- No better decision engine for side A than B/C; same compute budget, available legal moves, per-fighter sensory knowledge and RNG fairness.
- Tactical differences may arise from **abilities, wisdom/intelligence, training, coordination, wounds, morale, mission** when supported, not faction letter. Unverified proficiency labels -> CONDITIONAL.
- Policies to compare: uniform-valid/random, basic survive, offensive, defensive, support/protection, focus fire, skirmish, control, mixed-group synergy, adversarial opponent; versioned and blinded.
- Threat judgment uses visible behavior and registered knowledge; no invisible HP or stat-block oracle in production unless experiment explicitly ORACLE-HYPOTHETICAL.
- Measure decision quality by legal-action rate, unused resources, exposure, team target coordination, retaliation, survival vs tactical goals, sensitivity to seed, cost; audit distinct sides and behavior stratification.

## Bestiary calibration future workflow
BEAST source snapshot (canon/provenance) -> build/legal source-matched fixture -> choose representative 25-level ED challengers -> run solo and 3–4-person balanced parties -> opponent policy tournaments & seed/swap strata -> distribute win rate/TTK/party casualties/remaining HP/damage/actions/resources -> compare *within RPG* creature cohort curves and holdout families -> flag expected-vs-observed difficulty, probable overstated/understated or missing attribute -> Mestre review -> NAC-NORM/NAC-PASS only if modifying Criação de Besta or rank.
- Balanced parties: 3 roles (frontline defender, damage dealer, controller/support), 4 roles (+healer or magical striker), only if actual class-free skills/actions are defined. Policy roles are tags, not character classes.
- Challenge of one boss for many PCs is not expected to be 50% unless intended design goal. Distinguish normalized encounter difficulty from actor mirror parity.
- Do not assert exact appropriate rank/star from one comparison. Report ordinal class likelihood, disagreement, uncertainty, source gaps and conditional assumptions; Mestre retains canonical title/rank decision.
- All existing beasts eventually scanned with traceability but no unsupported claim universal denominator while F1 still open. Preserve historical data for baseline and future AFTER comparison.
- For new beast future QA, run candidate through frozen suite, compare with source-aligned cohort/thresholds and produce recommendation only, not silent source modification.

## Gates and next
G-FAIR1: identical fixtures AB/BA mirror with same actor rolls; current v0.1 PASS for completed restricted 2×1.
G-FAIR2: simultaneous reactions/initiative ties/legal techniques resolved; PENDING, major scaling blocker.
G-TACTIC: baseline/random/adaptive policy test on source-legal action catalog and no hidden knowledge; only decision unit tests PASS, full fights PENDING.
G-BEAST: bestial CA fraction/RD/proficiency/magical/bestiary snapshot certified; PENDING, no ED-vs-BE full fight validated.
G-CALIBRATE: enough representative samples and independent playtests/holdout; PENDING. No creature re-ranked.
G-NORM: NAC-NORM-01/NAC-PASS and Mestre approval for rule changes; PENDING.

Next material: authorize source-driven bestial adapter, repair neutral tie-resolution only as LAB-ASSUMPTION after Mestre decision, integrate sophisticated TacticalPolicy with full legal actions, run true ED×BE and 3–4-person parties, collect observed challenge; benchmark 10×10 and 20×20 only after these foundational checks.
