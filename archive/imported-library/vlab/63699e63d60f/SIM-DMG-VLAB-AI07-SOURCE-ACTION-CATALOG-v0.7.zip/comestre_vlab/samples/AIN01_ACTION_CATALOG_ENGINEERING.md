# AIN01 — Catálogo de Ações Fonte-Gated v0.1

**Escopo:** MESTRE-ONLY, protótipo experimental e não-canônico. O módulo `vlab_action_catalog_v01.py` define `AbilitySource`, `ActorActionState`, `FrozenRuleEvidence` e `action_menu`. Não executa magias, cura, ataques ou reações; seu output é uma lista de ações **preflight elegíveis para decisão**, ainda sujeitas a verificação de execução de efeitos.

## Contrato de legalidade

Antes de qualquer ação entrar na política tática, o catálogo exige:
- Identidade do combatente, lista de habilidades conhecidas e source action_id;
- Status de autoridade resolvido e correspondência com fonte/regra;
- Modo strict com `FrozenRuleEvidence` (hash SHA256 da evidência auditada, audit record e as-of); sem evidence `SOURCE-EVIDENCE-NOT-FROZEN`;
- Adaptador específico do efeito pronto; flag sem implementação não pode abrir magia;
- Rank, PA disponível e custos, recarga, economia de ação, movimento, reação e gatilho;
- Escopo/alvo, distância, LoS e geometria validados quando necessário;
- Sem duplicatas, sem `UNKNOWN/CONFLICT`, sem poderes não presentes no loadout;
- Nenhum token `TEST-SOURCED`/prova simulada de teste pode ser considerado evidência Notion válida na prática.

## Falhas fechadas representativas

`EFFECT-ADAPTER-NOT-READY`, `PA-NOT-KNOWN`, `INSUFFICIENT-PA`, `NOT-IN-ACTOR-LOADOUT`, `RANK-RESTRICTED`, `SOURCE-EVIDENCE-NOT-FROZEN`, `NO-SOURCE-TRIGGER`, `RANGE-UNRESOLVED`, `LINE-OF-SIGHT-UNRESOLVED`, `GEOMETRY-UNRESOLVED`, `AREA-TARGETS-UNVERIFIED`, `STANDARD-SPENT`, `FULL-UNAVAILABLE`.

O catálogo permite combinar a seleção `TACTICAL-OBSERVABLE-v0.2` com spells, reaction, move ou control **em testes unitários onde o input é sintético**, sem afirmar que os efeitos foram executados. Por exemplo, fonte de magia da página `3ebc2b32-4ede-81f7-b343-f7270ff91373` serve como categoria de autoridade, mas a habilidade concreta deve ser identificada e validada individualmente antes da execução.

## Estado e próximos gates

- AIN01 software preflight prototipado e validado com testes unitários.
- Snapshot de regra proveniente do Notion e adaptadores individuais de efeitos reais NÃO estão todos congelados; modo FULL-CANON permanece bloqueado.
- AIN03 (reação) e AIN04 (magia) precisam de implementação de efeitos, não só seleção.
- AIN07 (dossiê tático específico de cada Besta) depende da classificação de fontes e correção Mestre; política sintética seedada é apenas fallback.
- AIN10 side-mirror mantido em decisões; ampliar teste quando efeitos reais estiverem integrados.
- Não alterar Sistema de Combate, DMG-RANK-01 v1.1, Criação de Besta, Party nem dados do CM-000001.

**Prova executada:** 156/156 unit tests PASS na suíte completa após adição do catálogo e verificações de source freeze.
