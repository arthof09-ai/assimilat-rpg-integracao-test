# RPG Assimilação — AI06 — Crosswalk externo de combate avançado

**Classificação:** MESTRE-ONLY · Pesquisa aplicada · Proposta de IA de laboratório, NÃO regra canônica.

| Referência externa | Princípio transferível | Implementação segura | Não importar |
|---|---|---|---|
| Jambô / Tormenta20, Kit Introdutório, combate e manobras | Manobras além de dano, posicionamento, custo de oportunidade | A IA pode considerar controlar/empurrar/defender **somente se ação existir** no Sistema de Combate de Assimilação | d20, bônus manobra, multiplicador, desempate por Luta de T20 |
| Tormenta20, Movimento RPG, táticas avançadas de área | Cobertura altera decisões espaciais e confiabilidade de AoE | Verificar origem/alvos/linha de visão em `ActionDefinition` da magia antes de selecionar | Valores de cobertura e regra de área Tormenta20 |
| D&D Beyond Free Rules 2024 | Atacar, ajudar, preparar, esquivar, mover e conjurar são opções táticas condicionadas | Gerar catálogo apenas de ações habilitadas pelo source adapter, não copiar verbos como regras | action economy, d20, bônus, vantagem, slots de D&D |
| Chaosium Call of Cthulhu 7e Combat | Esquiva versus contra-ataque; força numérica; autopreservação e manobras | Perfil de decisão tática e vulnerabilidade de alvo cercado como *observação* | bonus die por Outnumbered, D100, combate por DEX |
| Pathfinder 2e GM Core Choosing Adversaries Actions | Adversário usa seu conhecimento, aprende e comete erros | Observabilidade, tiers de planejamento, registro de erro e escolhas pessoais | economia de 3 ações, XP budget, níveis PF2e |
| The Monsters Know What They're Doing | Criatura age por instinto, objetivo, recursos e ameaça; tipos diferentes lutam diferente | Perfis predador/emboscador/guardião/caçador coletivo/etc com scores de laboratório | thresholds INT, WIS, 40% HP, regras 5e |
| Pathfinder 2e Secondary Objectives | Missões além de matar tornam decisões táticas relevantes | objetivos de cenário com fontes e critérios explícitos; nunca mutar regras da campanha | XP, condições e efeitos de PF2e |

## Fontes auditáveis (consultadas em 08/10/2026)
- https://jamboeditora.com.br/wp-content/uploads/2023/06/Tormenta20-Resumo-de-Regras.pdf
- https://movimentorpg.com.br/combate-avancado-em-t20-area-de-tormenta/
- https://www.dndbeyond.com/sources/dnd/br-2024/playing-the-game
- https://cthulhuwiki.chaosium.com/rules/combat.html
- https://2e.aonprd.com/Rules.aspx?ID=2545
- https://2e.aonprd.com/Rules.aspx?ID=983
- https://www.themonstersknow.com/why-these-tactics/
- https://www.themonstersknow.com/intelligent-enemy-tactics/

**Governança:** informações externas são referências METODOLÓGICAS de IA. Não determinam dados, fórmulas, regras de empate, iniciativa, falha crítica, RD, bônus, ranks nem poderes de Assimilação.

## Requisitos finais da IA (futuros gates, AIN01–AIN12)
- **AIN01**: ações legais da ficha e custos/limites.
- **AIN02**: movimento, alcance, cobertura e posicionamento pela autoridade.
- **AIN03**: reação, janela temporal, disputa por orçamento de reação.
- **AIN04**: magia — CD, custo de PA, duração, alvos, área, recursos, refletir.
- **AIN05**: manobras/controle/buffs/debuffs e efeitos persistentes.
- **AIN06**: repertório de armas, equipamentos, transformações e técnicas.
- **AIN07**: espécie/Besta/NPC com doutrina individual e motivação.
- **AIN08**: cooperação, papéis de party, liderança e ameaça avaliada.
- **AIN09**: observabilidade e crenças (sem leitura telepática de ficha inimiga).
- **AIN10**: igualdade técnica A/B/C, mirror RNG e QA comparável.
- **AIN11**: escalabilidade 1×1→20×20 com efeitos em área, invocações, multi-alvos.
- **AIN12**: replay, telemetria, avaliação humana, holdout e calibração do Bestiário.

**AIN01–AIN12 estão ESPECIFICADOS, NÃO aprovados nem executados integralmente.** `TACTICAL-OBSERVABLE-v0.2` implementa o seletor de alternativas já legais e perfis, mas não realiza todos os efeitos listados.
