# AI06 — Laboratório de combate misto e IA tática v0.6 — resultados

**Escopo:** MESTRE-ONLY; protótipo CONDICIONAL; nenhuma regra oficial do RPG atualizada.
**Comparabilidade:** RD SUBTRACT-LAB e OFF-LAB são hipóteses de sensibilidade; nunca declarar a primeira como regra canônica.

## Testes por modalidade (250 seeds por regime de RD; mirror A/B por seed)

| Modalidade | RD hipotética | Outcomes | Média rodadas | Mirrors | Ações auditadas | Checks |
|---|---|---|---:|---:|---:|---:|
| 1x1 | SUBTRACT-LAB | {'B': 250} | 2.54 | 250 | 1077 | 11020 |
| 1x1 | OFF-LAB | {'B': 250} | 2.54 | 250 | 1077 | 11020 |
| 2x1 | SUBTRACT-LAB | {'B': 250} | 5.44 | 250 | 3052 | 30770 |
| 2x1 | OFF-LAB | {'B': 250} | 5.44 | 250 | 3052 | 30770 |
| 3x1 | SUBTRACT-LAB | {'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK': 250} | 6.26 | 250 | 4220 | 42450 |
| 3x1 | OFF-LAB | {'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK': 250} | 6.26 | 250 | 4220 | 42450 |
| 4x1 | SUBTRACT-LAB | {'MAX-ROUNDS-CENSORED': 52, 'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK': 198} | 21.38 | 250 | 17026 | 170510 |
| 4x1 | OFF-LAB | {'MAX-ROUNDS-CENSORED': 52, 'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK': 198} | 21.38 | 250 | 17026 | 170510 |
| 5x1 | SUBTRACT-LAB | {'MAX-ROUNDS-CENSORED': 60, 'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK': 190} | 23.18 | 250 | 20853 | 208780 |
| 5x1 | OFF-LAB | {'MAX-ROUNDS-CENSORED': 60, 'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK': 190} | 23.18 | 250 | 20853 | 208780 |

## Testes condicionais de guerra (NÃO guerra canônica)

### 10x10
- Seed 101: 4 rodadas, 52 eventos, mirror=True, checks=521, winner-lab=B, trace=09d68f5f9fd7793d322532b5d6715524b188321760295da11b3c6879a10ac35a.
- Seed 202: 3 rodadas, 43 eventos, mirror=True, checks=431, winner-lab=B, trace=d91c56085d2796175e9be9ca62e06a5a408bf31dec72178097dbed2dc3a23a59.
- Seed 303: 4 rodadas, 52 eventos, mirror=True, checks=521, winner-lab=B, trace=9f7e5ffbe45b5b5af1288abdae33f5b5b2400d9091b0c31e78f372e3c096b8a3.
### 20x20
- Seed 101: 4 rodadas, 102 eventos, mirror=True, checks=1021, winner-lab=B, trace=3a8281113a60569b0509b223f369a70256c03e4af0c40dbecca3abc0f7553bdd.
- Seed 202: 4 rodadas, 103 eventos, mirror=True, checks=1031, winner-lab=B, trace=15d5d99b64e0a3757b272125d9860fc2d431ae6c6ce2c3916ea78a81cc415192.
- Seed 303: 4 rodadas, 101 eventos, mirror=True, checks=1011, winner-lab=B, trace=f03e69daf0615595a7f5d1aa6a52bc2b678b27e90e59661efe0bc1aac0227bf8.

## Evidência de impasse mecânico
No roster sintético 3×1, o Orc fica com CA 93/4 (=23,25) e a Besta tem teto de ataque 1d6 +14=20. Por outro lado, o Orc ataca com teto de 1d6+12=18 contra CA Besta 93/5 (=18,6). Sem magias, manobras ou terceiros que consigam golpear, nenhuma dessas duas entidades consegue acertar a outra. Quando os demais combatentes caem, o estado remanescente pode ficar em impasse no submodelo básico.

## Limitações e governança
- RD-subtract hypothetical
- initiative tie seeded lab policy
- critical fail no effect lab
- HP zero lab stop
- BE generic proficiency as Luta hypothetical
- BE base attack as one attack assumption
- ED common weapon +2 Luta chosen
- no spells/reactions/movement/control/positioning resolved in fight
- ranks mixed in 10x10 and 20x20 are not balanced challenge design

Os percentuais/contadores não estimam ainda o equilíbrio real por rank, pois os arquétipos, ações e hipóteses não estão certificados como FULL-FIGHT. 

**FIRST-PENDING:** homologar interpretação RD/iniciativa/crit-fail/morte e todos os adaptadores de magia, reação, movimentação, Besta; treinar/fazer QA do decisor com ações completas e confrontos espelhados; só então usar o banco científico de Bestas para propostas ao Mestre.
