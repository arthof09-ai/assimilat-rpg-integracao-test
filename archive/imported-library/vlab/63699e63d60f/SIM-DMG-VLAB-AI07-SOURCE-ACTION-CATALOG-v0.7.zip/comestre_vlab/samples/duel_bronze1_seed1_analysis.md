# Duelo virtual condicional — VL05-EDB1-EDB1-COMMON-LIGHT

**Mestre-only. Não canônico. Não é playtest humano.**
Semente: `1` · regras: `VL05-DUEL-0.1` · hash da fixture: `6d2daec983040d4c0659cdd6f33cd94034e2ead887d697cc69dd42dd8a47a95f`
Hash do log: `aeb949e67d455b5a2aae6bfdfc7602cefdab09f652f2ebffe4b80a3075f82fa3` · replay: **PASS**

**Resultado condicional:** vitória lado A, por Vida chegando a zero no protocolo experimental, após 8 rodadas e 15 ações.
Sem conclusão sobre morte canônica ou balanceamento oficial.

## Parâmetros

| Campo | Lado A | Lado B |
|---|---|---|
| rank | Bronze | Bronze |
| star | 1 | 1 |
| health | 22 | 23 |
| soul | 22 | 22 |
| defense_ca | 11 | 12 |
| weapon | COMMON-LIGHT-1d4 | COMMON-LIGHT-1d4 |
| luta_prof_bonus | 2 | 2 |
| ff_damage_fixed | 3 | 3 |
| FOR | 6 | 4 |
| DES | 5 | 6 |
| CON | 4 | 5 |
| INT | 4 | 4 |
| SAB | 4 | 4 |
| CAR | 4 | 4 |

## Eventos

| Rodada | Ator | Rolagem ataque | Contra CA | Acertou? | Dano | Vida-alvo (antes→depois) |
|---:|---|---|---:|---|---:|---|
| 1 | A | 4 + 6 + 2 = 12 | 12 | NÃO | 0 | 23→23 |
| 1 | B | 6 + 4 + 2 = 12 | 11 | SIM | 5 | 22→17 |
| 2 | A | 5 + 6 + 2 = 13 | 12 | SIM | 5 | 23→18 |
| 2 | B | 4 + 4 + 2 = 10 | 11 | NÃO | 0 | 17→17 |
| 3 | A | 2 + 6 + 2 = 10 | 12 | NÃO | 0 | 18→18 |
| 3 | B | 5 + 4 + 2 = 11 | 11 | NÃO | 0 | 17→17 |
| 4 | A | 6 + 6 + 2 = 14 | 12 | SIM | 7 | 18→11 |
| 4 | B | 2 + 4 + 2 = 8 | 11 | NÃO | 0 | 17→17 |
| 5 | A | 1 + 6 + 2 = 9 | 12 | NÃO | 0 | 11→11 |
| 5 | B | 1 + 4 + 2 = 7 | 11 | NÃO | 0 | 17→17 |
| 6 | A | 6 + 6 + 2 = 14 | 12 | SIM | 5 | 11→6 |
| 6 | B | 3 + 4 + 2 = 9 | 11 | NÃO | 0 | 17→17 |
| 7 | A | 5 + 6 + 2 = 13 | 12 | SIM | 4 | 6→2 |
| 7 | B | 2 + 4 + 2 = 8 | 11 | NÃO | 0 | 17→17 |
| 8 | A | 6 + 6 + 2 = 14 | 12 | SIM | 6 | 2→0 |

## Avisos metodológicos

- Critério de término HP≤0 é **LAB ASSUMPTION**, não regra de morte/incapacitação canônica.
- Aplicabilidade e momento do teste de crítico sequencial por tentativa precisam de gate competente; sorteios de falha crítica bloqueiam a execução.
- Política “atacar sempre” e “não usar reação” são escolhas laboratoriais legítimas neste caso restrito, não previsão do comportamento de players.
- O replay reproduz logs dentro do mesmo motor; **auditoria independente** ainda PENDENTE.
- Crédito de células FULL-FIGHT/VERIFIED do ledger oficial permanece **0**.
- A equipe do Coordenador 1 mantém fontes D0–D9; nenhuma regra do sistema foi alterada.

Fontes: Criação de Ficha; Sistema de Combate; DMG-RANK-01 v1.1; plano e especificação L00–L03.
