"""Read-only hashes and package integrity. No combat execution or official attestation."""
import hashlib,json,sys,zipfile
from pathlib import Path

def verify_root(root):
 root=Path(root)
 d=json.loads((root/'SHA256_MANIFEST.json').read_text())
 fs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
     for p in root.rglob('*') if p.is_file() and p.name!='SHA256_MANIFEST.json'
       and '__pycache__' not in p.parts}
 if d['files']!=fs:raise ValueError({'missing':sorted(d['files'].keys()-fs.keys()),'extra':sorted(fs.keys()-d['files'].keys()),'changed':[x for x in fs.keys() & d['files'].keys() if d['files'][x]!=fs[x]]})
 print('PASS_R267_R271_PORTABLE_FILE_HASHES',len(fs))

def verify_zip(path):
 with zipfile.ZipFile(path) as z:
  err=z.testzip()
  if err:raise ValueError('CRC_FAIL '+err)
  d=json.loads(z.read('SHA256_MANIFEST.json'))
  files={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n!='SHA256_MANIFEST.json' and not n.endswith('/')}
  if d['files']!=files:raise ValueError('ZIP_MANIFEST_MISMATCH')
  print('PASS_R267_R271_PORTABLE_ZIP_CRC_SHA256',len(files))
if __name__=='__main__':
 arg=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent)
 verify_zip(arg) if arg.is_file() else verify_root(arg)
