# VLAB Assimilação — R267–R271 / Evidência executável MESTRE-ONLY

**OP:** OP-VLAB-FUSION-SANDBOX-01. **Anterior:** R266 verificado. **Depois:** R271 TEST delimitado. **NEXT:** R272 (candidato). **Autoridade:** SEM claim de INSTANCE-ID, writer, lease, epoch, fencing ou GREEN. **Party/O Primeiro, DMG, LEVEL-UP e fichas canônicas: NO-WRITE.**

## Achado real: R266 ≠ compatibilidade científica automática

O R265 inseriu comparação do estado inicial de `vlab_r18_interactive` com um dos cenários embutidos A/B. O R237, R239 e R240 reutilizam esse mesmo journal, mas materializam cenas científicas de criaturas pré-criadas com gênese diferente da A/B. Assim, **aplicar o R266 diretamente ao R237** reproduziu `LabHold: GENESIS_SCENE_SEED_INVALID`; o núcleo R18 original era idêntico por SHA nos quatro pacotes. A correção R267–R268 preserva o mesmo motor e exige `source_initial_authority` **explícita por experimento**, com `pre-registration`, conjunto de seeds e hash de fonte congelados. Desconhecidos não têm passagem automática. A cena A/B rejeita qualquer override da autoridade externa.

## Correção de integridade material R268

Em R267 inicial, um journal de 1 evento admitia **primeiro `before_sha` falsificado e rehash atualizado**. A correção R268 requer `rows[0].before_sha == sha(expected_initial)`, inclusive em cenários científicos fonte-gated; reproduzimos a falha ANTES e a rejeição DEPOIS. Há risco residual se um adversário puder substituir todos os artefatos e reescrever proveniência sem autenticação externa; este gate não é assinatura criptográfica de terceiros.

## Resultado das verificações

| Escopo | Evidência observada | Estado |
|---|---|---|
| R18 interface genuína com patch cumulativo | 8/8 testes nativos históricos, 54/54 testes R258–266 | PASS TEST |
| R267–268 controlador/gênese R237 | 15/15 novos testes adversariais, incluindo dois de primeira âncora | PASS TEST |
| R237 bilateral / Fraco / HP0 LAB | 8/8 SQLite exatamente iguais aos históricos, 155 commits, 640 eventos; auditor fonte independente | PASS LOCAL |
| R239 Fraco limite | 48/48 SQLite exatamente iguais; auditor científico próprio após atualização | PASS LOCAL |
| R240 Fraco pareado | 256/256 SQLite exatamente iguais; auditor científico próprio após atualização | PASS LOCAL |
| R269 auditor R237 | 8/8 adulterações com hash refeito rejeitadas; WAL ativo recusado, read-after-close aceito | PASS TEST |
| R271 auditores R239 e R240 | 12/12 adulterações com hash refeito rejeitadas; auditoria de cópias limpas | PASS TEST |
| Matriz de 17 contratos | 0/17 terminalmente certificados | HOLD |
| Matriz R91 | 0/1.875 células oficiais homologadas | HOLD |

**Não são combates novos:** R237 e R239/R240 foram reexecutados como *verificação de paridade*, preservando 8 + 48 + 256 = 312 fixtures históricas. Não adicionar 312 créditos científicos ao denominador original, não duplicar R91 nem relatórios de comparação.

## Conteúdo e instalação segura (nenhum motor paralelo)

Há **patches, testes e relatórios**, não uma cópia redistribuída do executor de 14,7 MB nem bancos científicos. A fonte recuperada da Biblioteca continua obrigatória. Só instalar em diretórios TEST independentes depois de conferir SHA original e ausência de colisão:

1. R18 original: SHA256 do módulo `fusion_stage12/vlab_r18_interactive.py` = `f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368`.
2. Para um R18 original limpo, na raiz usar `patch -p1 < patch/R269_CUMULATIVE_R18_TO_R269.patch`. **Se o R266 já estiver aplicado, usar somente o arquivo incremental** `patch/R267_R268_INCREMENTAL_FROM_R266.patch`. NÃO aplicar ambos.
3. Para uma cópia do R237, R239 ou R240, aplicar o **mesmo cumulativo** na pasta `runtime/` do respectivo pacote (preserva o módulo original intacto em sua origem). Na raiz do pacote, aplicar os dois patches da respectiva origem: `R267_R237_SOURCE_ADAPTER.patch` + `R269_R237_SOURCE_AUDITOR.patch`, ou `R270_R239_SOURCE_ADAPTER.patch` + `R271_R239_SOURCE_AUDITOR.patch`, ou equivalentes R240.
4. Correr regressões R18 com `PYTHONPATH=fusion_stage12:working/historical_v081_verified_original:reconstruction python -m unittest fusion_stage12/test_vlab_r18_interactive.py -q`. Correr testes existentes do delta R266 usando as instruções da README do próprio pacote R266. Para R237: copiar `tests/test_r267_source_authority.py` e `tests/test_r268_initial_event_anchor.py` para `tests/` de sua cópia R237 e executar `python -m unittest discover -s tests -p 'test_r2*.py' -q`.
5. O script `tests/r269_adversarial_source_audit.py` deve ficar na pasta `tests/` da cópia R237. O `tests/r271_adversarial12.py` depende de `VLAB_R271_WORK_ROOT`, diretório contendo as cópias `r239_threshold` e `r240_fraco_pairs`.
6. Scripts de auditoria que operam sobre cópias extraídas devem terminar com readback e hashes; NUNCA rodar novamente `run()` dentro do ZIP oficial já auditado, para não sobrescrever evidências.

## Inbox, prioridade e consumo

Fonte: INBOX-COMESTRE-01 Notion, leitura de dados atual. 17 itens dirigidos a CM-000006, quatro P1 `IBX-40/62/70/86`, 14 requerendo ACK. Mais recentes: **IBX-160** continuidade nativa mesmo se GitHub Free falhar (informativo, não obriga CI), **IBX-152** GitHub proporcional opcional (P3), **IBX-138** encaminhamento integral de respostas (P2, dedup de ordens por ID), **IBX-120** integração consultiva Level-Up/DMG (não vinculante). **Não criar uma missão paralela de GitHub**; GitHub CI: NOT-RUN nesta execução. Sem INSTANCE-ID legítima, não alterar `NOVA` para `LIDA/ACK/CONCLUÍDA`, nem escrever em OP/Diário compartilhados.

## Gate e NEXT

**NAC-CONT-03:** sucessão com ANTES, DEPOIS e ponto de retomada; históricos intactos. **NAC-NORM-01:** desempate de iniciativa, falha crítica negativa, HP0, fonte P4, ação bônus e interações DMG seguem sem resolução normativa por testes. **NAC-PASS-02:** PASS para patch/reprodutibilidade/auditoria **TEST**, aceite STRICT/terminal/HOMOLOGAÇÃO=HOLD. **R272 candidato:** aplicar o mesmo padrão de proveniência ao próximo adaptador científico realmente elegível e fechar contratos via fonte/cena/QA, não via simples contagem de testes. Antes de produzir novo pacote, conferir a pasta existente da Biblioteca para não criar colisão R272.
