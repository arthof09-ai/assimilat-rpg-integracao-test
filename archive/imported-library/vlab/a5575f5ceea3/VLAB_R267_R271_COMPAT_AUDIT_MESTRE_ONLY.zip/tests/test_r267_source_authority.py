"""R267, Mestre TEST: adversarial compatibility between R265 genesis and R237 scenes.

Run only on isolated extracted copies, never on the canonical R237 evidence.
"""
import copy, json, os, random, sqlite3, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for p in (ROOT/'code',ROOT/'runtime/native',ROOT/'runtime/fusion_stage12'):
    if str(p) not in sys.path:sys.path.insert(0,str(p))
import r237_live_weak_onset as run
j=run.j

class R267Compatibility(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='R267_TEST_MESTRE_')
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/'s.sqlite'

    def make(self,seed=23777001,arm='SOLO_G_C_TRANSITION'):
        run.setup(self.db,seed,arm)
        return self.db

    def test_all_frozen_eight_read_back(self):
        for seed in run.P['seeds']:
            for arm in run.P['arms']:
                db=ROOT/'evidence/db'/f'R237_{arm}_S{seed}.sqlite'
                state,head,rev=j.load(db,source_initial_authority=run.source_initial_authority)
                self.assertEqual(state['r237']['seed'],seed)
                self.assertEqual(state['r237']['arm'],arm)
                self.assertGreater(rev,0)

    def test_external_without_explicit_authority_must_fail(self):
        self.make()
        with self.assertRaisesRegex(j.LabHold,'AUTHORITY_REQUIRED'):j.load(self.db)

    def test_custom_source_initial_untouched_passes(self):
        self.make()
        state,head,rev=j.load(self.db,source_initial_authority=run.source_initial_authority)
        self.assertEqual((rev,state['r237']['source_status']),(0,'VZ-PRECREATE-NONP4'))

    def test_zero_revision_hp_injection_rejected(self):
        self.make()
        self.mutate(lambda state: state['actors']['C'].update(hp=123456))
        with self.assertRaisesRegex(j.LabHold,'TAMPERED'):j.load(self.db,source_initial_authority=run.source_initial_authority)

    def test_zero_revision_actor_injection_rejected(self):
        self.make()
        self.mutate(lambda state: state['actors'].update({'INJECTED':{}}))
        with self.assertRaisesRegex(j.LabHold,'TAMPERED'):j.load(self.db,source_initial_authority=run.source_initial_authority)

    def test_source_genesis_tamper_rejected(self):
        self.make()
        with sqlite3.connect(self.db) as c:c.execute('update meta set value=? where key="genesis"',('0'*64,))
        with self.assertRaisesRegex(j.LabHold,'GENESIS_HASH_MISMATCH'):j.load(self.db,source_initial_authority=run.source_initial_authority)

    def test_missing_source_data_denied(self):
        self.make()
        self.mutate(lambda state: state.pop('r237'))
        with self.assertRaises(j.LabHold):j.load(self.db,source_initial_authority=run.source_initial_authority)

    def test_seed_beyond_preg_denied(self):
        self.make()
        self.mutate(lambda state: state.update(seed=987654))
        with self.assertRaises(j.LabHold):j.load(self.db,source_initial_authority=run.source_initial_authority)

    def test_bad_callback_shape_denied(self):
        self.make()
        with self.assertRaisesRegex(j.LabHold,'INVALID_RESPONSE'):
            j.load(self.db,source_initial_authority=lambda state:('oops',state))

    def test_callback_exception_denied(self):
        self.make()
        def bad(state):raise TypeError('x')
        with self.assertRaisesRegex(j.LabHold,'SOURCE_VERIFICATION_FAILED'):
            j.load(self.db,source_initial_authority=bad)

    def test_standard_scene_rejects_source_override(self):
        j.init_db(self.db,'A',1254)
        with self.assertRaisesRegex(j.LabHold,'OVERRIDE_DENIED'):
            j.load(self.db,source_initial_authority=run.source_initial_authority)
        s,h,rev=j.load(self.db)
        self.assertEqual((s['scene'],rev),('A',0))

    def test_external_commit_requires_source_gate(self):
        self.make()
        st,h,rev=j.load(self.db,source_initial_authority=run.source_initial_authority)
        who=st['active'];own=1
        payload={'arm':'SOLO_G_C_TRANSITION','seed':23777001,'who':who,'own':own,
            'prereg_sha':run.PH,'source_sha':run.SH}
        with self.assertRaisesRegex(j.LabHold,'AUTHORITY_REQUIRED'):
            j.event_commit(self.db,'LAB-CMD-DENY', 'TEST',payload, run.do_turn)
        st2,h2,rev2=j.load(self.db,source_initial_authority=run.source_initial_authority)
        self.assertEqual((h2,rev2),(h,0))
        row=j.event_commit(self.db,'LAB-CMD-ALLOW', 'R237_WEAK_BEAST_SOURCE_NATIVE_TURN',payload, run.do_turn,
            source_initial_authority=run.source_initial_authority)
        self.assertEqual(row['seq'],1)
        self.assertEqual(j.load(self.db,source_initial_authority=run.source_initial_authority)[2],1)

    def test_pending_intent_denies_source_gate(self):
        self.make()
        with sqlite3.connect(self.db) as c:
            c.execute('INSERT INTO pending VALUES(?,?,?,?)',('LAB-CMD-UNKNOWN','abc','X','{}'))
        with self.assertRaisesRegex(j.LabHold,'UNKNOWN_EFFECT'):
            j.load(self.db,source_initial_authority=run.source_initial_authority)

    def mutate(self,fn):
        with sqlite3.connect(self.db) as c:
            s=json.loads(c.execute('select value from meta where key="state"').fetchone()[0])
            fn(s)
            c.execute('update meta set value=? where key="state"',(j.canonical(s),))

if __name__=='__main__':unittest.main()
