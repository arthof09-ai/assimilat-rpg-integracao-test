"""R268: pin first committed event to the deterministic/source-verified initial state."""
import json,sqlite3,sys,tempfile,unittest
from contextlib import closing
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for p in (ROOT/'code',ROOT/'runtime/native',ROOT/'runtime/fusion_stage12'):
 if str(p) not in sys.path:sys.path.insert(0,str(p))
import r237_live_weak_onset as exp
j=exp.j
class FirstAnchor(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='R268_MESTRE_');self.addCleanup(self.tmp.cleanup)
  self.db=Path(self.tmp.name)/'journal.sqlite'
 def corrupt_first_before(self):
  with closing(sqlite3.connect(self.db)) as c, c:
   seq,data=c.execute('select seq,row_json from events where seq=1').fetchone()
   row=json.loads(data);row['before_sha']='f'*64
   digest=j.sha(row)
   c.execute('UPDATE events SET before_sha=?,row_json=?,row_sha=? WHERE seq=1',(row['before_sha'],j.canonical(row),digest))
   c.execute('UPDATE meta SET value=? WHERE key="head"',(digest,))
 def test_custom_scientific_first_before_must_be_authenticated(self):
  exp.setup(self.db,exp.P['seeds'][0],exp.P['arms'][0]);s,_,_=j.load(self.db,source_initial_authority=exp.source_initial_authority)
  payload={'arm':exp.P['arms'][0],'seed':exp.P['seeds'][0],'who':s['active'],'own':1,'prereg_sha':exp.PH,'source_sha':exp.SH}
  j.event_commit(self.db,'LAB-CMD-ORIGIN','R237_WEAK_BEAST_SOURCE_NATIVE_TURN',payload,exp.do_turn,source_initial_authority=exp.source_initial_authority)
  self.corrupt_first_before()
  with self.assertRaisesRegex(j.LabHold,'FIRST_EVENT_BEFORE_MISMATCH'):
   j.load(self.db,source_initial_authority=exp.source_initial_authority)
 def test_standard_r18_first_before_must_be_authenticated(self):
  j.init_db(self.db,'A',1010)
  j.event_commit(self.db,'LAB-CMD-INIT','START',{},j.do_start)
  self.corrupt_first_before()
  with self.assertRaisesRegex(j.LabHold,'FIRST_EVENT_BEFORE_MISMATCH'):j.load(self.db)
if __name__=='__main__':unittest.main()
