"""R269 source-audit boundary: R18 journal hashes alone do not certify source mechanics."""
from pathlib import Path
import tempfile,shutil,sqlite3,json,sys
from contextlib import closing
R=Path(__file__).resolve().parents[1]
for p in (R/'code',R/'runtime/native',R/'runtime/fusion_stage12'):sys.path.insert(0,str(p))
import r237_live_weak_onset as r
from r237_independent_readonly_audit import audit

cases={
 'flip_hit':lambda x:x['detail'].update(hit=not x['detail']['hit']),
 'alter_loss':lambda x:x['detail'].update(actual_hp_loss=x['detail']['actual_hp_loss']+1),
 'fake_native_action':lambda x:x['detail']['events_new'][-2].update(action='SCIENCE_FORGERY'),
 'claim_official':lambda x:x.update(official_effects=1),
 'claim_nonsynthetic':lambda x:x.update(synthetic=False),
 'alter_target':lambda x:x['detail'].update(to='MISTAKEN_TARGET'),
 'alter_payload':lambda x:x['payload'].update(who='OTHER'),
 'forge_dice':lambda x:x['detail']['events_new'][-3].update(attack_attempts=[[6]*6]),
}
res=[]
for label,attack in cases.items():
 with tempfile.TemporaryDirectory(prefix='R269_') as td:
  temp=Path(td)
  shutil.copytree(R/'sources',temp/'sources')
  shutil.copytree(R/'evidence/db',temp/'evidence/db')
  db=sorted((temp/'evidence/db').glob('*.sqlite'))[0]
  with closing(sqlite3.connect(db)) as c, c:
   seq,raw=c.execute('select seq,row_json from events order by seq desc limit 1').fetchone()
   row=json.loads(raw);attack(row)
   digest=r.j.sha(row)
   c.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=?',(r.j.canonical(row),digest,seq))
   c.execute('UPDATE meta SET value=? WHERE key="head"',(digest,))
  try:
   _=r.j.load(db,source_initial_authority=r.source_initial_authority)
   generic='ACCEPTED_REHASHED_NON_SOURCE_JOURNAL'
  except Exception as e:
   generic='DENIED:'+str(e)
  try:
   import contextlib,io
   with contextlib.redirect_stdout(io.StringIO()):result=audit(temp,write=False)
   strict='UNEXPECTED_PASS:'+str(result.get('status'))
  except Exception as e:
   strict='DENIED:'+str(e)
  res.append({'case':label,'generic':generic,'independent_source_audit':strict})
print(json.dumps(res,ensure_ascii=False,indent=2))
assert all(z['independent_source_audit'].startswith('DENIED') for z in res)
