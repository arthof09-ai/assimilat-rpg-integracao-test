from pathlib import Path
import tempfile,shutil,json,sqlite3,sys,contextlib,io,os
from contextlib import closing
ROOT=Path(os.environ.get('VLAB_R271_WORK_ROOT', Path.cwd())).resolve()
changes={
 'detail_after_HP':lambda x:x['detail']['after']['G'].update(hp=987654),
 'detail_before_PA':lambda x:x['detail']['before']['C'].update(pa=1),
 'detail_attack':lambda x:x['detail']['attack_detail'].update(hit=not x['detail']['attack_detail']['hit']),
 'detail_result_score':lambda x:x['detail'].update(attack_score=x['detail']['attack_score']+1),
 'detail_phase':lambda x:x['detail'].update(phase='OFFICIAL_WIN'),
 'detail_action':lambda x:x['detail']['events_new'][-2].update(action='FALSE_EVENT'),
}
results=[]
for n,folder,run in [(239,'r239_threshold','r239_native_boundary'),(240,'r240_fraco_pairs','r240_native_pairs')]:
 R=ROOT/folder;sys.path[:0]=[str(R/'code'),str(R/'runtime/native'),str(R/'runtime/fusion_stage12')]
 import importlib
 source=importlib.import_module(run);aud=importlib.import_module(f'r{n}_independent_readonly_audit')
 for label,fn in changes.items():
  with tempfile.TemporaryDirectory(prefix=f'R271_{n}_') as td:
   p=Path(td)
   shutil.copytree(R/'sources',p/'sources');shutil.copytree(R/'evidence/db',p/'evidence/db')
   db=sorted((p/'evidence/db').glob('*.sqlite'))[0]
   with closing(sqlite3.connect(db)) as c,c:
    raw=c.execute('select row_json from events').fetchone()[0];row=json.loads(raw)
    fn(row);digest=source.j.sha(row)
    c.execute('update events set row_json=?,row_sha=?',(source.j.canonical(row),digest))
    c.execute('update meta set value=? where key="head"',(digest,))
   try:
    with contextlib.redirect_stdout(io.StringIO()):aud.audit(p,write=False)
    result='UNEXPECTED_ACCEPT'
   except (AssertionError,KeyError,ValueError) as e:result='DENY:'+str(e)
   results.append({'cohort':n,'case':label,'result':result})
 for name in [run,f'r{n}_independent_readonly_audit','r234_source_complete_beast_battle','vlab_r18_interactive','vlab_effects_v08']:
  sys.modules.pop(name,None)
 for p in [str(R/'code'),str(R/'runtime/native'),str(R/'runtime/fusion_stage12')]:
  if p in sys.path:sys.path.remove(p)
import json
print(json.dumps(results,indent=2,ensure_ascii=False))
assert len(results)==12 and all(r['result'].startswith('DENY:') for r in results)
