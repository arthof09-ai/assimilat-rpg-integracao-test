"""Independent readback of R32, no mutation to the original R32 transaction.
Runs strict admission review and independently restored checkpoint replay.
"""
from __future__ import annotations
from pathlib import Path
import sys,hashlib,json,sqlite3,tempfile,zipfile,shutil,unittest
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'extension'))
import vlab_r31_real_source_gateway as g
import vlab_r18_interactive as j
DB=HERE/'runs'/'R32_RABADA_REAL_AUTH_LUTA6_SEED223.sqlite'
CP=HERE/'checkpoints'/'R32_CHECKPOINT_RABADA_SEED223.zip'
AUTH=HERE/'authority'/'MESTRE_LUTA_DECISION_VERIFIED.json'
REC=HERE/'evidence'/'R32_INTEGRAL_RABADA_RECEIPT.json'
DECISION_ID='MASTER-RABADA-FRIGIDO-LUTA6-20261015-R32'

def hashbytes(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def strict_gate():
 a=json.loads(AUTH.read_text())
 state,head,rev=g.checked(DB)
 c=g.catalog(DB)
 receipt=json.loads(REC.read_text())
 row=j.history(DB)['events'][0]
 pre=json.loads((HERE/'evidence'/'R32_ANTES_READBACK.json').read_text())
 # The legacy R31 catalog returns signature-ready with attack_legal_complete=False
 # prior to Mestre Luta decision (verified separately). DO NOT lie about this fact.
 # Combine the original strict source-action preflight with per-ability Mestreside
 # decision, original native receipt, and independent replay to certify this
 # specific R32 authorization. Not a new engine or a canon promotion.
 assert pre['catalog']['status']=='ACTION_CATALOG_SOURCE_SIGNATURE_READY'
 assert pre['catalog']['action_id']==g.ACTION_ID+':'+g.TID
 assert pre['catalog']['attack_legal_complete'] is False
 assert g._validated_luta_authority(a)==6
 assert a['action_id']==g.ACTION_ID and a['decision_id']==DECISION_ID
 assert 'Rabada do Frígido Ossário' in a['exact_decision_text']
 assert a['decision_only_for'].startswith('Rabada do Frígido Ossário')
 assert row['kind']=='R31_REAL_SOURCE_SANDBOX_ATTACK'
 assert row['payload']['luta_authority']==a
 assert row['detail']['authority_digest']==g.sha(a)
 assert row['detail']['canonical_credit']==0
 assert row['detail']['native_event']['provenance']=='LAB-REAL-MASTER-FONTE-AUTENTICADA-NONCAN'
 assert row['detail']['native_event']['roll_score']==27
 assert row['detail']['native_event']['raw']==21
 assert row['detail']['native_event']['rd_applied']==5
 assert row['detail']['native_event']['net']==16
 assert row['detail']['native_event']['before_hp']==38
 assert row['detail']['native_event']['after_hp']==22
 assert row['detail']['native_event']['defensive_reaction'] is None
 assert row['detail']['native_event']['official_death_derived'] is False
 assert state['actors'][g.AID]['stats']['luta_bonus']==6
 assert state['actors'][g.AID]['resource']['standard']==0
 assert state['actors'][g.AID]['resource']['pa']==120
 assert state['actors'][g.TID]['resource']['reaction']==1
 assert state['actors'][g.TID]['resource']['hp']==22
 assert state['actors'][g.AID]['resource']['hp']==125
 assert state['r31_source']['geometry']['adjacent'] is True
 assert state['r31_source']['reaction_policy']=='NO_VOLUNTARY_REACTION_IN_SINGLE_ACTION_LAB_PROBE'
 assert state['r31_source']['luta_status']=='MESTRE_EXPLICIT_ISOLATED_LAB_ONLY'
 assert not state['r31_source'].get('conditional_only',False)
 assert state['r31_source']['official_effects']==0
 return {'gate':'PASS_STRICT_SOURCE_PLUS_MASTER_LUTA_PLUS_NATIVE_TRANSACTION','scope':'ONE_RABADA_ONLY_REAL_SOURCE_SANDBOX_NONCAN',
  'original_r31_catalog_full_flag_at_genesis':False,'original_r31_catalog_status_at_genesis':pre['catalog']['status'],
  'extra_verified_master_luta_gate':True,'source_binding':True,'strict_catalog_legal_one_action':True,
  'transaction_native_full_authorized':True,'fully_admitted_R32_one_action':True,'not_world_canon':True,
  'gate_receipt_detail':'R31 catalog signature-ready is combined with verified authority to permit one authorized action; no global catalog mutation.'}

class AuditR32(unittest.TestCase):
 def test_01_source_pin(self):
  s,_,_=g.checked(DB);self.assertEqual(s['actors'][g.AID]['source_page_id'],g.BEAST_SOURCE);self.assertEqual(s['actors'][g.TID]['source_page_id'],g.TARGET_SOURCE)
 def test_02_ability_authority(self):
  a=json.loads(AUTH.read_text());self.assertEqual(g._validated_luta_authority(a),6);self.assertEqual(a['decision_id'],DECISION_ID)
 def test_03_strict_composite(self):self.assertEqual(strict_gate()['gate'],'PASS_STRICT_SOURCE_PLUS_MASTER_LUTA_PLUS_NATIVE_TRANSACTION')
 def test_04_sqlite_integrity(self):
  with sqlite3.connect(DB) as c:self.assertEqual(c.execute('pragma integrity_check').fetchone()[0],'ok')
 def test_05_pending_zero(self):
  with sqlite3.connect(DB) as c:self.assertEqual(c.execute('select count(*) from pending').fetchone()[0],0)
 def test_06_ledger_exactly_one(self):
  h=j.history(DB);self.assertEqual(len(h['events']),1);self.assertEqual(h['events'][0]['seq'],1);self.assertEqual(h['events'][0]['kind'],'R31_REAL_SOURCE_SANDBOX_ATTACK')
 def test_07_roll_and_rd(self):
  evt=j.history(DB)['events'][0]['detail']['native_event'];self.assertEqual((evt['roll_score'],evt['ca_exact'],evt['raw'],evt['rd_applied'],evt['net']),(27,'20',21,5,16))
 def test_08_hp_and_action_economy(self):
  st,_,rev=g.checked(DB);self.assertEqual(rev,1);self.assertEqual(st['actors'][g.TID]['resource']['hp'],22);self.assertEqual(st['actors'][g.AID]['resource']['standard'],0)
 def test_09_no_extra_pa(self):
  st,_,_=g.checked(DB);self.assertEqual(st['actors'][g.AID]['resource']['pa'],120);self.assertEqual(st['actors'][g.TID]['resource']['pa'],22)
 def test_10_native_replay(self):
  r=g.replay_verify(DB);self.assertTrue(r['fully_admitted']);self.assertEqual(r['status'],'PASS_R18_JOURNAL_AND_NATIVE_V081_REPLAY')
 def test_11_checkpoint_verify(self):self.assertEqual(g.verify_checkpoint(CP)['status'],'PASS')
 def test_12_restore_independent_and_replay(self):
  with tempfile.TemporaryDirectory(prefix='R32-RESTORE-') as d:
   to=Path(d)/'restored.sqlite';g.verify_checkpoint(CP,restore_to=to);v=g.replay_verify(to);self.assertTrue(v['fully_admitted']);self.assertEqual(v['head'],j.history(DB)['head'])
 def test_13_reexecution_refused(self):
  with tempfile.TemporaryDirectory(prefix='R32-NO-REPEAT-') as d:
   cp=Path(d)/'dup.sqlite';g.verify_checkpoint(CP,restore_to=cp)
   with self.assertRaisesRegex(g.Hold,'ONLY_FIRST_TURN_CAN_BE_EXECUTED_ONCE'):g.execute_authorized(cp,json.loads(AUTH.read_text()))
   self.assertEqual(g.checked(cp)[2],1)
 def test_14_wrong_auth_scope_denied(self):
  wrong=json.loads(AUTH.read_text());wrong['scope']='GENERAL_ALL_BEAST_ATTACKS'
  with self.assertRaises(g.Hold):g._validated_luta_authority(wrong)
 def test_15_wrong_bonus_denied(self):
  wrong=json.loads(AUTH.read_text());wrong['bonus']=7
  with self.assertRaises(g.Hold):g._validated_luta_authority(wrong)
 def test_16_world_effects_zero(self):
  st,_,_=g.checked(DB);self.assertEqual(st['r31_source']['official_effects'],0);self.assertFalse(j.history(DB)['events'][0]['detail']['native_event']['official_death_derived'])
 def test_17_old_R31_conditional_immutable(self):
  root=HERE.parent/'vlab_r31'/'evidence'
  old={'R31_REAL_SOURCE_CONDITIONAL_LUTA_0_SEED211.sqlite':'829f7464b963a693e60472076ff919b4d46b3eac1251a1fe9c5c83577f9d7b26',
   'R31_REAL_SOURCE_CONDITIONAL_LUTA_6_SEED211.sqlite':'123d3cda22b7444752689f6cc95b0a8c54cf8716ad4c214c3f3ff926974d9c0a'}
  for key,d in old.items():self.assertEqual(hashbytes(root/key),d)
 def test_18_unmodified_r31_gateway(self):
  self.assertEqual(hashbytes(HERE/'extension'/'vlab_r31_real_source_gateway.py'),'061a073f5aa0e3f079efe453cc7fb4fe069b5160ac90c92a603cdf4e7a2779b7')
 def test_19_baseline_r27(self):
  self.assertEqual(hashbytes(HERE.parent/'vlab_r31'/'VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip'),'d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1')
 def test_20_seed_211_not_reused(self):
  st,_,_=g.checked(DB);self.assertEqual(st['seed'],223);self.assertNotEqual(st['seed'],211)

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(AuditR32)
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 gate=strict_gate()
 out={'schema':'R32_INDEPENDENT_READBACK_AUDIT_V1','passed':result.testsRun-len(result.failures)-len(result.errors),'total':result.testsRun,'failed':len(result.failures)+len(result.errors),'strict_gate':gate,'sqlite_sha256':hashbytes(DB),'checkpoint_sha256':hashbytes(CP),
      'authority_sha256':hashbytes(AUTH),'one_integral_action_noncanonical':result.wasSuccessful()}
 (HERE/'evidence'/'R32_INDEPENDENT_AUDIT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
 if not result.wasSuccessful():sys.exit(1)
