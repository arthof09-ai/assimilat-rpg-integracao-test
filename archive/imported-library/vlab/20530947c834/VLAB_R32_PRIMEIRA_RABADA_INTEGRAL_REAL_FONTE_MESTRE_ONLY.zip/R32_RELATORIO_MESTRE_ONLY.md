# PSV — VLAB R32 | Primeira Rabada integralmente admitida com Bestas reais em sandbox

**Operação existente:** `CM-000006 / OP-VLAB-FUSION-SANDBOX-01` · **Data:** 15/10/2026 · **Escopo:** MESTRE-SIDE / fonte de Besta real em sandbox isolado / **NÃO CANÔNICO COMO EVENTO DE CAMPANHA**.  
**Baseline normativa:** DMG-RANK-01 v1.1 inalterada. **Baseline científica:** R27 ANTES, R28, R29, R30 e R31 preservadas. **Nenhuma promoção de produção nem de sistema universal.**

## 1. ANTES e autoridade expressa

- **ANTES R31:** o gateway aditivo já admitia 2/2 fichas de Bestas reais e executara **duas** Rabadas **condicionais**, com Luta 0 ou Luta +6 matemáticos, seed 211. Ambas continuaram etiquetadas `QA_NOT_FULL_ADMISSION`; a ação plenamente admitida permanecia **0/1**.
- **Nova decisão vinculante do Mestre, não inferência:** **“O bônus de Luta da habilidade Rabada do Frígido Ossário é +6.”** Apenas esta habilidade recebe o bônus na **rolagem de acerto**, nunca dano; não há regra geral nova para demais Bestas.
- **Decisões anteriores conservadas:** ataque natural físico, corpo a corpo, alvo adjacente, consome 1 Ação Padrão, zero custo adicional de PA, dano `1d6+FOR`, sem rider obrigatório.
- **Sincronização da decisão:** decisão R32 inserida na **página operacional original**, não nas fichas das Bestas; reabertura física do Notion confirmou a decisão, escopo e não universalidade. URL da OP: https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2; edição observada após registro `2026-10-15T17:12:46.500Z`. Fichas Frígido/Cabra reabertas, `last_edited` preservados `2026-10-01T18:00:42.693Z` / `2026-10-01T18:00:34.040Z`.
- **Envelope local congelado:** `authority/MESTRE_LUTA_DECISION_VERIFIED.json`. O conteúdo tem ID da operação, ID da fonte, ID da habilidade, texto expresso, bônus 6, escopo `ISOLATED_REAL_SOURCE_LAB_ONLY`, leitura física e procedência. Não é assinatura criptográfica do Notion; é um atestado local verificável contra readback da OP e contra a decisão expressa do Mestre.

## 2. Fonte real e cena isolada ANTES

| Campo | Frígido Ossário | Cabra de Chifres |
|---|---|---|
| Fonte | [Bronze 5](https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315) | [Bronze 1](https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6) |
| FOR | 18 | 13 |
| CA impressa | 31 | 20 |
| Vida impressa no início experimental | 125 | 38 |
| Alma impressa | 120 | 22 |
| RD aplicável | não testada como alvo | 5, Criação de Besta / Bronze normal |

**Registro ANTES:** nova cena SQLite `runs/R32_RABADA_REAL_AUTH_LUTA6_SEED223.sqlite`, semente pré-declarada 223, revisão 0; Frígido e Cabra em **células adjacentes definidas apenas para o laboratório**; turno experimental do Frígido ativo, ação Padrão disponível; política `NO_VOLUNTARY_REACTION_IN_SINGLE_ACTION_LAB_PROBE`; nenhum efeito no mundo da campanha. Não houve disputa de iniciativa nem turno completo da Cabra: esta entrega certifica **uma ação**, não um combate completo.

**Autenticidade:** `source_kind=NOTION_MASTER_REAL` e IDs das páginas originais; `source_manifest_sha` dos valores extraídos localmente. Valores legados impressos preservados, sem recalcular Vida ou CA. Subtipo técnico interno `impacto` é **somente um transporte do v0.8.1** para natureza *física* autorizada; o Mestre não definiu que a Rabada causa especificamente impacto. A RD geral Bronze5 reduz igualmente os três subtipos físicos verificados no laboratório; não transportar `impacto` como tag canônica da ficha.

## 3. Gateway e admissão estrita

- **Reuso do mesmo gateway R31**, cópia byte-a-byte do Python (`SHA256 061a073f5aa0e3f079efe453cc7fb4fe069b5160ac90c92a603cdf4e7a2779b7`), e da **mesma resolução nativa original v0.8.1** (`vlab_effects_v08.apply_weapon_attack`) com journal histórico R18 SQLite WAL (`vlab_r18_interactive.event_commit`). **Nenhum motor paralelo e nenhuma alteração nos binários históricos.**
- O `action_menu(strict=True)` validou identidade, prova de fonte, alcance, adjacência, recurso e economia da Rabada.
- **Nuance de interoperabilidade:** o método `catalog()` herdado de R31 ainda produz o rótulo preliminar `ACTION_CATALOG_SOURCE_SIGNATURE_READY` e `attack_legal_complete:false` **antes de avaliar** a nova decisão sobre Luta. Isto NÃO foi ocultado nem falsamente editado no histórico. O segundo gate, `execute_authorized()`, verifica fisicamente o envelope de autoridade da Rabada e, só então, admite a ação e emite `R31_REAL_SOURCE_SANDBOX_ATTACK` no journal nativo. O verificador R32 audita **ambos os gates** e exige evento/payload/decisão correspondentes. Conclusão de admissão vale para **esta transação específica** e não converte `catalog()` em uma API geral de FULL-FIGHT.
- Testes adversariais: escopo de autoridade trocado, bônus 7 adulterado e reexecução do mesmo estado são recusados. Qualquer interrupção de efeito desconhecido continuaria submetida à proteção histórica de `pending` e HOLD, sem retry automático.

## 4. DEPOIS: primeira execução INTEGRAL com recibo nativo

**Novo run** `R32_RABADA_REAL_AUTH_LUTA6_SEED223.sqlite` · **semente 223** (não reuso dos bancos seed211 condicionais) · revisão 0→1.

| Verificação | Resultado nativo |
|---|---:|
| d6 de acerto | **3** |
| FOR da ficha | **18** |
| Luta autorizada pelo Mestre | **+6** |
| **Ataque total** | **27** |
| CA da Cabra | 20 |
| Acerto | **SIM** (`27 > 20`) |
| d6 de dano | **3** |
| **Dano bruto** | **21** (`3+18`) |
| RD geral Bronze | 5 |
| **Dano líquido** | **16** |
| Vida da Cabra, somente sandbox | **38→22** |
| Vida do Frígido | 125→125 |
| Alma Frígido | 120→120 |
| Alma Cabra | 22→22 |
| Ação Padrão do Frígido | **1→0** |
| Reação voluntária | nenhuma (política explícita deste ensaio) |
| Crítico | nenhum (sequência `[6,3,3]` não atende contrato de crítico) |
| Eventos nativos no journal | 1 |
| Intenções pendentes | **0** |
| Integridade SQLite | `ok` |
| Replay do resolvedor original | **PASS**, `fully_admitted=true` |
| Checkpoint portátil + restauração em novo banco | **PASS** |
| Efeitos oficiais de campanha | **0** |

Recibo primário: `evidence/R32_INTEGRAL_RABADA_RECEIPT.json`. O núcleo histórico produziu o evento `COMBAT-EFFECT-ADAPTER-PARTIAL-v0.8`, `LAB-REAL-MASTER-FONTE-AUTENTICADA-NONCAN`, com ataque 27, `raw=21`, `rd_applied=5`, `net=16`, HP38→22. Não foi um cálculo manual disfarçado de execução. O ledger foi reaberto, a cadeia de eventos checada, `pending=0`, e outro SQLite foi restaurado a partir do checkpoint e teve seu replay verificado de forma independente.

**SHA-256 SQLite novo:** `d89813e2f376f0acdfcf0d774142723593bf8613d0682d6b941cfb8e273f8b63`  
**SHA-256 checkpoint ZIP:** `d1d2fa1ef6f87ed303e6a11669d939a909d7ce34daa4ba23916899e5503e2370`  
**Head do journal (revisão 1):** `98e7e047897b0313fee80a8dfaecc24ba7b93dec4846fffd0b159412bacaa2e6`.

## 5. Verificação independente e regressão

- **20/20** testes da auditoria independente R32 PASS, incluindo integridade, fontes, autoridade, limites de escopo, custo, CA, RD, estado, snapshot restaurado, dupla verificação de replay, imutabilidade R31 e R27.
- **13/13** testes históricos R31 originais PASS; **10/10** testes R27 PASS. Teste de compatibilidade R32, derivado do R31, foi adaptado unicamente para aceitar a mensagem de recusa de autoridade **diferente do envelope verificado**, pois o arquivo de decisão agora existe; **13/13 PASS**. Houve uma falha inicial de **expectativa textual do teste antigo** antes desta adequação; não foi falha do motor nem efeito aplicado. Fonte R31 e testes históricos R31 originais não foram modificados.
- **Preservação:** R27 ZIP SHA `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`, R28 ZIP `68da72d6fe71020ce4a555089484514cc86cab67d90c92a77e52d2166c46fdfa`, R29 ZIP `0c9beb35b030f844cb109d44fa40bb2f5731665f0e056601252a7ec3c5ee2eb0`, R30 ZIP `55328526ce48c1acfa6568e6bc9e713762c8e33bf818b5aa2bc174c95c1838ae`, R31 ZIP `98841bf0473545005bdb107597981805199a35081e2dc84a4b6d150b97fa6835`. Bancos condicionais R31 Luta0 SHA `829f7464b963a693e60472076ff919b4d46b3eac1251a1fe9c5c83577f9d7b26` e Luta6 SHA `123d3cda22b7444752689f6cc95b0a8c54cf8716ad4c214c3f3ff926974d9c0a` permanecem intocados. Seed53 R29 e dois `UNKNOWN_EFFECT` de R27 intocados.

## 6. Progresso após o marco funcional

| Denominador exclusivo | ANTES (R31) | DEPOIS (R32) |
|---|---:|---:|
| Ação **Rabada** integralmente admitida | 0/1 | **1/1** |
| Bestas reais autenticadas na cena | 2/2 | 2/2 |
| Execuções condicionais históricas R31 | 2 | 2, não creditadas como integrais |
| Execuções nativas integrais reais-fonte no sandbox | 0 | **1** |
| Combates completos entre Bestas reais | 0 | **0** |
| Sementes novas integrais da rodada | 0 | **1** |
| Cenas desta rodada interrompidas ou censuradas | 0 | 0 |
| Patamares com combate **completo** real-fonte | 0/25 | **0/25** |
| Contratos VLAB terminais de produção | 0/17 | **0/17** |
| Células canônicas creditadas | 0/1.875 | **0/1.875** |

**Não calcular percentual global** de pesquisa com universo aberto. Uma ação executada não é um duelo, não conta vitória, não registra derrota da Cabra e não consome a Vida oficial de nenhum personagem.

## 7. Primeiro impedimento para **combate completo** de Bestas reais

A próxima ação requerida pelo escalonamento de turnos pertenceria à **Cabra de Chifres**. Sua única ação nomeada na ficha consultada é **Investida**, com dano `1d6+FOR13` e um **empurrão obrigatório** descrito como “joga a pessoa para longe”. Após pesquisa documental dirigida, **não estão definidos** a proficiência Luta específica da Cabra, a distância/direção e eventual salvaguarda do empurrão, nem a classificação/custo e geometria completos dessa ação. Não houve autorização para omitir o empurrão, conceder Luta+6 à Cabra, substituir a Investida por ataque fictício, ou tratar um turno perdido como inatividade automática.

**Próxima fronteira:** fechar a ação de Investida com Mestre e fontes competentes, sem alterar a decisão específica da Rabada; executar turnos com reação/renovação legitimamente declaradas, gerar os primeiros dois sentidos de ação real-fonte e só depois intentar combate completo. O estudo separado RD15 × RDF10 do Rinolupo continua PENDENTE; não interfere no ensaio da Cabra.

## 8. NAC-CONT-03 / NAC-PASS-02 / estado final

**LER→ANTES→verificar autoridade→executar no sandbox separado→reabrir ledger→replay→checkpoint restaurado→DEPOIS→sincronizar OP→PSV.** Validação funcional isolada: **PASS**; a promoção terminal de produção **NAC-PASS-02 = HOLD**, porque não há contrato de produção, nem writer, lease, epoch, fencing ou GREEN. A decisão do Mestre registrada na OP não modifica o sistema oficial de combate, DMG-RANK nem a ficha. Party/O Primeiro não receberam dados ou escritas.

**Recuperação imediata:** baixar o ZIP científico R32 junto ao R27 original e ao ZIP delta R31; verificar SHA, obter gateway histórico v0.8.1 e R18 desses pacotes, rodar `auditar_r32_independente.py` sobre novo banco R32 e `replay_verify()` na cópia restaurada de `R32_CHECKPOINT_RABADA_SEED223.zip`. Não rodar `run_integral_rabada_r32.py` se o arquivo da cena já existir. Cada novo teste usa identidade SQLite nova, nunca reescreve o lote histórico.
