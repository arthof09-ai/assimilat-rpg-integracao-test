"""R32 one-shot legitimate Mestre-specified Rabada, source-real experimental only.
Uses byte-identical R31 gateway and historical R27 modules. No retries.
"""
import sys, json, hashlib, sqlite3, traceback
from pathlib import Path
from datetime import datetime, timezone
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'extension'))
import vlab_r31_real_source_gateway as g

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
 p=HERE/'evidence'/name;p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8');return p

def main():
 from copy import deepcopy
 import vlab_r18_interactive as j
 db=HERE/'runs'/'R32_RABADA_REAL_AUTH_LUTA6_SEED223.sqlite'
 authpath=HERE/'authority'/'MESTRE_LUTA_DECISION_VERIFIED.json'
 auth=json.loads(authpath.read_text(encoding='utf8'))
 assert g._validated_luta_authority(auth)==6
 assert not db.exists(), 'Must not overwrite a previous run'
 save('R32_PRE_REGISTERED_SCENE.json',{
   'schema':'R32_PRE_REGISTERED_SCENE_V1','decision_id':auth['decision_id'],'seed':223,
   'actor':g.BEAST_SOURCE,'target':g.TARGET_SOURCE,'action_id':g.ACTION_ID,
   'world_effects':0,'source_mode':g.MODE,'start_hp':{g.AID:125,g.TID:38},
   'start_pa':{g.AID:120,g.TID:22},'target_ca':20,'target_rd':5,
   'geometry':{'adjacent':True,'scenario_only':True},
   'reactions':'NO_VOLUNTARY_REACTION_SINGLE_ACTION_PROBE',
   'luta_source':'MASTER_EXPLICIT_PHYSICAL_NOTION_READBACK',
   'luta_bonus':6,'no_automatic_prof_rule':True,
   'combat_actions':1,'not_full_fight':True,'no_party_or_canon_writes':True,
   'source_page_lastedits':{g.BEAST_SOURCE:'2026-10-01T18:00:42.693Z',g.TARGET_SOURCE:'2026-10-01T18:00:34.040Z'}
 })
 genesis=g.create(db,seed=223)
 st,head,rev=g.checked(db)
 assert rev==0
 before={'revision':rev,'head':head,'actors':deepcopy(st['actors']),
         'source':deepcopy(st['r31_source']),'catalog':g.catalog(db),
         'sqlite_path':str(db),'source_sha':g.sha(g.evidence_manifest())}
 save('R32_ANTES_READBACK.json',before)
 print('GENESIS',json.dumps({'revision':rev,'head':head,'catalog':before['catalog'],'expected_preview':g.attack_preview(st,6,rev+1)},ensure_ascii=False))
 try:
  result=g.execute_authorized(db,auth)
 except Exception as e:
  p=save('R32_FAILED_HOLD_NO_RETRY.json',{
    'error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),
    'db':str(db),'no_automatic_retry':True})
  print('FAIL',type(e).__name__,str(e),'evidence',p)
  raise
 after,head2,rev2=g.checked(db)
 hist=j.history(db)
 rv=g.replay_verify(db)
 assert rv['fully_admitted'] and rv['official_effects']==0
 assert rev2==1 and len(hist['events'])==1
 assert result['event']['kind']=='R31_REAL_SOURCE_SANDBOX_ATTACK'
 assert after['actors'][g.AID]['stats']['luta_bonus']==6
 assert after['actors'][g.AID]['resource']['standard']==0
 assert after['actors'][g.AID]['resource']['pa']==120
 assert after['actors'][g.TID]['resource']['pa']==22
 assert after['actors'][g.TID]['resource']['hp']>=0
 assert after['r31_source']['world_effects'] if 'world_effects' in after['r31_source'] else True
 assert not after['r31_source'].get('conditional_only',False)
 con=sqlite3.connect(db)
 try:
  integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
  pending=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
  events=con.execute('SELECT COUNT(*) FROM events').fetchone()[0]
  assert (integrity,pending,events)==('ok',0,1)
 finally:con.close()
 cp=HERE/'checkpoints'/'R32_CHECKPOINT_RABADA_SEED223.zip'
 chk=g.export_checkpoint(db,cp)
 verification=g.verify_checkpoint(cp)
 assert chk['status']==verification['status']=='PASS'
 receipt={
   'schema':'R32_FIRST_INTEGRALLY_ADMITTED_REAL_SOURCE_ACTION_RECEIPT_V1',
   'classification':'REAL_MASTER_SOURCE_SANDBOX_NONCANONICAL',
   'decision_id':auth['decision_id'],
   'authority_sha256':digest(authpath),
   'source_manifest_sha':g.sha(g.evidence_manifest()),
   'before':{'revision':rev,'head':head,'hp':{k:v['resource']['hp'] for k,v in st['actors'].items()},'pa':{k:v['resource']['pa'] for k,v in st['actors'].items()}},
   'after':{'revision':rev2,'head':head2,'hp':{k:v['resource']['hp'] for k,v in after['actors'].items()},'pa':{k:v['resource']['pa'] for k,v in after['actors'].items()}},
   'native_event':result['event'],'replay':rv,'checkpoint':verification,
   'sqlite_integrity':integrity,'pending_intents':pending,'event_count':events,
   'sqlite_sha256':digest(db),'checkpoint_sha256':digest(cp),
   'world_effects':0,'canonical_credit':0,
   'R31_legacy_conditioned_runs_counted_as_new':False
 }
 save('R32_INTEGRAL_RABADA_RECEIPT.json',receipt)
 print('SUCCESS',json.dumps({'roll':result['event']['detail']['preview'],
    'native':result['event']['detail']['native_event'],
    'before_hp':receipt['before']['hp'],'after_hp':receipt['after']['hp'],
    'revision':rev2,'sqlite_sha256':receipt['sqlite_sha256'],
    'cp_sha256':receipt['checkpoint_sha256'],'replay':rv,'pending':pending,
    'action_kind':result['event']['kind']},ensure_ascii=False,default=str))

if __name__=='__main__':main()
