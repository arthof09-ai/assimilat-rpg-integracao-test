# R32 — reprodução / Mestre-side / SANDBOX

Este pacote é uma extensão **delta** do VLAB R31, não contém a baseline de ~21 MB R27. Dependências verificadas: arquivo R27 original SHA `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`; gateway R31 `vlab_r31_real_source_gateway.py` SHA `061a073f5aa0e3f079efe453cc7fb4fe069b5160ac90c92a603cdf4e7a2779b7` (incluído intacto); código de v0.8.1 em R27.

Estrutura esperada: manter **R31 original extraído** e R32 delta como pastas irmãs `vlab_r31/` e `vlab_r32/` sob o mesmo diretório. Extrair R27 dentro de `vlab_r31/r27/`. O pacote R32 verifica fisicamente também o ZIP R27 original e dois SQLite condicionais R31, por isso requer esses originais na pasta irmã `vlab_r31/`. Em `vlab_r32/`, usar o mesmo conteúdo R27 em `r27/` por cópia read-only ou um link simbólico (sem reescrita).

Estrutura interna do delta R32:

- `r27/fusion_stage12/...` — resolvers originais; **não modificar**.
- `extension/vlab_r31_real_source_gateway.py` — gateway byte-idêntico da R31.
- `authority/MESTRE_LUTA_DECISION_VERIFIED.json` — decisão verificada da operação original.
- `runs/R32_RABADA_REAL_AUTH_LUTA6_SEED223.sqlite` — transação real-fonte integral da R32.
- `checkpoints/R32_CHECKPOINT_RABADA_SEED223.zip` — checkpoint.
- `evidence/` — recibo nativo, antes, log, oráculo de verificação e SHA.

O runtime usa `Path(__file__).resolve().parents[1]/'r27'` para localizar R27. O ZIP R32 **não substitui** o código do resolvedor. O pacote foi testado em Python 3.13, usando somente stdlib.

Na pasta `vlab_r32/` com `r27/` resolvendo os originais e com `vlab_r31/` como irmã, execute:

```bash
python auditar_r32_independente.py
python extension/test_r31_real_source_gateway.py
python r27/fusion_stage12/test_vlab_r27_scientific_baseline.py
```

Para replicar o evento, use o `run_integral_rabada_r32.py` em uma pasta de teste com **banco não existente**; esse script recusa sobrescrever a transação entregue. O `audit` verifica o banco entregue sem modificá-lo e valida restore de checkpoint em arquivo temporário. `execute_authorized()` recusa autoridade trocada, bônus não aprovado e reexecução sobre revisão1.

**Observação importante:** `catalog()` no gateway R31 marca o **pré-gate de fonte/assinatura** como `attack_legal_complete:false` quando Luta ainda não foi examinada. A entrada `execute_authorized()` é um **gate adicional de Luta**, com readback e vinculação expressa; o resultado nativo tem kind `R31_REAL_SOURCE_SANDBOX_ATTACK`, diferentemente da QA `R31_NATIVE_CONDITIONAL_REAL_SOURCE_QA`. A auditoria conjunta avalia os dois gates e não adultera o catálogo original.

**Proibições:** jamais tratar a cena como acontecimento canônico, alterar fichas, promover Luta+6 para outras Bestas ou executar o mesmo banco duas vezes. O rótulo técnico de transporte `impacto` **não canoniza subtipo físico** da Rabada. NAC-PASS-02 de produção permanece HOLD.
