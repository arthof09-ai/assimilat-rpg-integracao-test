"""VLAB R31: additive, source-authenticated REAL-MASTER-SNAPSHOT in isolated LAB.

Historical resolver: original v0.8.1 apply_weapon_attack (imported; no copied
hit/RD/HP rules). Historical R18 SQLite ledger: init_db/event_commit/load/history.
Read-only source snapshots, never a game-world event. Fail closed if Luta unknown.
No mutation of R01-R30 or Notion sheets. QA mock is *never* a real action.
"""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from copy import deepcopy
import hashlib,json,sqlite3,sys

ROOT=Path(__file__).resolve().parents[1]/'r27'
sys.path.insert(0,str(ROOT/'fusion_stage12'))
from unified_gateway import verify_pins
import vlab_r18_interactive as journal
from vlab_action_catalog_v01 import ActorActionState,AbilitySource,FrozenRuleEvidence,action_menu
from vlab_effects_v08 import Combatant,Scene,apply_weapon_attack,EffectBlocked
from vlab_rd_v08 import Resistances

MODE='MASTER_REAL_SOURCE_AUTHENTICATED_SANDBOX_NO_CANON'
AID='LAB_REAL_FRIGIDO_B5';TID='LAB_REAL_CABRA_B1'
BEAST_SOURCE='f0dc2b32-4ede-820a-b947-0168d4a53315'
TARGET_SOURCE='391c2b32-4ede-8252-b0cc-810423cdbfa6'
RULE_SOURCE='3ebc2b32-4ede-81f1-be4b-e8804ac113c0'
RD_SOURCE='3ebc2b32-4ede-81f4-992a-c88a3588cacd'
OP_SOURCE='3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2'
ACTION_ID='FRIGIDO_RABADA_MESTRE_20261015'
RULE_ID='MASTER-EXPRESS-RABADA-FRIGIDO-20261015-01'

SOURCES={
 'fr': {'page':BEAST_SOURCE,'url':'https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315',
  'as_of':'2026-10-01T18:00:42.693Z','name':'Frígido Ossário','rank':'Bronze','star':5,
  'hp':125,'pa':120,'ca':31,'for':18,'des':18,'con':15,'int':12,'sab':9,'car':3,
  'literal_ability':'Rabada: 1d6+força'},
 'goat': {'page':TARGET_SOURCE,'url':'https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6',
  'as_of':'2026-10-01T18:00:34.040Z','name':'Cabra de chifres','rank':'Bronze','star':1,
  'hp':38,'pa':22,'ca':20,'for':13,'des':8,'con':10,'int':2,'sab':8,'car':2,
  'literal_ability':'Investida: joga a pessoa para longe, o alvo sofre 1d6 + força impacto.'}}
MASTER_RULING={
 'authority':'MESTRE_DIRECT_THIS_CONVERSATION_20261015', 'registered_in_operation':OP_SOURCE,
 'mechanic':'Rabada do Frígido Ossário', 'nature':'natural physical attack',
 'modality':'melee','range':'adjacent','economy':'STANDARD', 'pa_extra':0,
 'damage':'1d6+FOR','rider':'none','scope':'THIS_ABILITIY_ONLY_AND_ISOLATED_LAB',
 'not_game_world':True,'no_general_proficiency_ruling':True}

class Hold(Exception):pass

def sha(x):return journal.sha(x)

def evidence_manifest():
 """Frozen observation assembled after Notion fetch, not a Notion-signed snapshot."""
 return {'schema':'R31_REAL_SOURCE_LOCAL_READBACK_EVIDENCE', 'source_auth':'physically_reopened_not_notarized',
  'sources':deepcopy(SOURCES),'master_decision':deepcopy(MASTER_RULING),
  'combat_page':RULE_SOURCE,'beast_creation_page':RD_SOURCE,
  'source_kind':'REAL_MASTER_FICHA_READONLY','world_effects':0}

def proof():
 return FrozenRuleEvidence(BEAST_SOURCE,RULE_ID,sha(evidence_manifest()),
   '2026-10-15:REOPENED_SAME_TURN','OP-VLAB-R31-MESTRE-DECISION-READBACK')

def ability():
 return AbilitySource(ACTION_ID,'attack','STANDARD',BEAST_SOURCE,RULE_ID,
  'EXPLICIT-CANON',required_pa=0,target_scope='ENEMY',max_targets=1,
  min_rank_index=1,requires_range_check=True,effect_adapter_ready=True,
  effect_adapter_id='NATIVE-V081-APPLY-WEAPON-ATTACK')

def real_scene_state(seed:int):
 if type(seed)!=int or seed<0 or seed>999999999:raise Hold('SEED_NOT_VALID')
 st=journal.initial('A',seed)
 st['phase']='ACTIVE';st['round']=1;st['turn']=0;st['active']=AID
 st['order']=[AID,TID];st['actors']={}
 for aid,key,position in ((AID,'fr','LAB-R31-CELL-A'),(TID,'goat','LAB-R31-CELL-B')):
  src=SOURCES[key]
  # Null/unknown combat stats stay unknown. Defense is explicitly NOT selected.
  c=Combatant(aid,src['hp'],src['pa'],src['ca'],src['con'],None,None,None,position,
              rank=src['rank'],standard=1,movement=1,reaction=1)
  st['actors'][aid]={'name':src['name'], 'source_kind':'NOTION_MASTER_REAL',
                     'source_page_id':src['page'],'source_as_of':src['as_of'],
                     'stats':{'for':src['for'],'des':src['des'],'con':src['con'],
                              'rank':src['rank'],'star':src['star'],'luta_bonus':None},
                     'resource':asdict(c)}
 st['source_status']='SOURCE_REAL_READONLY_ISOLATED_SANDBOX'
 st['source_confidence']='SOURCE_REOPENED_EXCERPTS_NOT_NATIVE_SIGNED'
 st['r31_source']={'mode':MODE,'source_manifest_sha':sha(evidence_manifest()),
       'ruling_id':RULE_ID,'actor_source':BEAST_SOURCE,'target_source':TARGET_SOURCE,
       'geometry':{'adjacent':True,'cells':{AID:'LAB-R31-CELL-A',TID:'LAB-R31-CELL-B'},
                   'choice':'AUTHORIZED_EXPERIMENTAL_SETUP_NO_CANON_WORLD_LOCATION'},
       'reaction_policy':'NO_VOLUNTARY_REACTION_IN_SINGLE_ACTION_LAB_PROBE',
       'luta_status':'UNKNOWN_NOT_ZERO','luta_value':None,
       'damage_transport_tag':'impacto',
       'damage_transport_note':'TECHNICAL PHYSICAL SUBTYPE PLACEHOLDER ONLY; rank-general RD5 independent of physical subtype; no specific RD in scene',
       'official_effects':0,'canonical_credit':0,'historical_low_level_resolver':'v0.8.1 apply_weapon_attack',
       'experimental_turn_override':True}
 return st

def create(db:Path,seed:int=211):
 """Reuse original R18 SQLite genesis schema, then bind a REAL SOURCE scene.

 R18 `synthetic=True` means event/world *simulation*, not actor kind. Actor kind
 is unambiguously NOTION_MASTER_REAL, never disguised as a fictitious beast.
 """
 verify_pins();db=Path(db)
 if db.exists():raise Hold('NO_OVERWRITE_DB_EXISTING')
 journal.init_db(db,'A',seed)
 st=real_scene_state(seed)
 c=journal.connect(db)
 try:
  c.execute('BEGIN IMMEDIATE')
  meta=dict(c.execute('SELECT key,value FROM meta'))
  if meta['revision']!='0' or c.execute('SELECT count(*) FROM events').fetchone()[0]:raise Hold('GENESIS_UNCLEAN')
  gen=sha({'lab_only':True,'noncanonical_scene_synthetic':True,'actors_are_real_source':True,
           'mode':MODE,'source_sha':st['r31_source']['source_manifest_sha'],'seed':seed,'core':journal.VERSION})
  for key,val in [('genesis',gen),('head',gen),('state',journal.canonical(st))]:
   c.execute('UPDATE meta SET value=? WHERE key=?',(val,key))
  c.commit()
 except: c.rollback();raise
 finally:c.close()
 assert checked(db)[2]==0
 return {'status':'REAL_SOURCE_SCENE_ADMITTED_NO_ATTACK','sqlite':str(db),'genesis':gen,
         'source_sha':st['r31_source']['source_manifest_sha'],'luta_status':'HOLD',
         'authoritative_actor_count':2,'native_attacks':0,'world_effects':0}

def checked(db):
 st,head,rev=journal.load(db)
 cfg=st.get('r31_source')
 if not cfg or cfg['mode']!=MODE or cfg['source_manifest_sha']!=sha(evidence_manifest()):raise Hold('SOURCE_PIN_MISMATCH')
 if st['source_status']!='SOURCE_REAL_READONLY_ISOLATED_SANDBOX':raise Hold('NOT_REAL_SOURCE_MODE')
 if {k:a['source_page_id'] for k,a in st['actors'].items()}!={AID:BEAST_SOURCE,TID:TARGET_SOURCE}:
  raise Hold('ACTOR_SOURCE_BINDING_CHANGED')
 if st['r31_source']['official_effects']!=0:raise Hold('CANONICAL_LEAK')
 return st,head,rev

def catalog(db):
 st,head,rev=checked(db)
 if st['phase']=='COMPLETE_LAB_SINGLE_ACTION':
  return {'status':'ACTION_ALREADY_EXECUTED','allowed':0,'full_admission':False,'revision':rev}
 a=st['actors'][AID]['resource'];d=st['actors'][TID]['resource'];cfg=st['r31_source']
 if cfg['geometry']['adjacent'] is not True:raise Hold('NOT_ADJACENT')
 state=ActorActionState(actor_id=AID,ordinal_level=5,available_pa=a['pa'],
   known_action_ids=(ACTION_ID,),standard_available=a['standard']==1,
   reaction_available=a['reaction']==1,range_confirmed=True,
   geometry_confirmed=True,enemy_ids_visible=(TID,))
 out=action_menu(state,(ability(),),strict=True,source_evidence=(proof(),))
 if len(out.legal_options)!=1 or out.rejected:raise Hold('SOURCE_ACTION_CATALOG_DENIED:'+repr(out.rejected))
 return {'status':'ACTION_CATALOG_SOURCE_SIGNATURE_READY',
         'action_id':out.legal_options[0].action_id,'source_kind':'MASTER_REAL',
         'source_rule_hash':proof().content_sha256,'attack_legal_complete':False,
         'missing':'LUTA_BONUS_MESTRE_AUTHORITY'}

def _native(st,roll,damage,tag='impacto'):
 """CALL ORIGINAL v0.8.1, NOT reimplement hit/RD/HP. On a detached clone."""
 verify_pins()
 if tag!='impacto':raise Hold('TRANSPORT_TAG_NOT_WHITELISTED_FOR_THIS_PROBE')
 if st['r31_source']['luta_value'] is None:raise Hold('LUTA_UNRESOLVED_BEFORE_NATIVE')
 scene=Scene({a:Combatant(**deepcopy(v['resource'])) for a,v in st['actors'].items()},
    seed=st['seed'],provenance='LAB-REAL-MASTER-FONTE-AUTENTICADA-NONCAN')
 pa_before={a:o.pa for a,o in scene.actors.items()}; before=[scene.actors[a].hp for a in sorted(scene.actors)]
 state=ActorActionState(AID,5,scene.actors[AID].pa,(ACTION_ID,),
    standard_available=scene.actors[AID].standard==1,range_confirmed=True,
    geometry_confirmed=True,enemy_ids_visible=(TID,))
 evt=apply_weapon_attack(scene,AID,TID,source=ability(),state=state,
    proofs=(proof(),),roll_score=roll,damage=damage,damage_tag=tag,
    rd=Resistances(general=5,specific=(),provenance='CREACAO_BESTA_BRONZE_NORMAL_RD5'),strict=True)
 if len(scene.events)!=1 or evt['official_death_derived'] is not False:raise Hold('NATIVE_EVENT_CONTRACT_MISMATCH')
 if any(o.pa!=pa_before[a] for a,o in scene.actors.items()):raise Hold('UNAUTHORIZED_PA_DEBIT')
 if scene.actors[AID].standard!=0:raise Hold('STANDARD_NOT_CONSUMED')
 if evt['before_hp']-evt['after_hp']!=min(evt['before_hp'],evt['net']):raise Hold('BAD_NATIVE_HP_DELTA')
 for aid,obj in scene.actors.items():st['actors'][aid]['resource']=asdict(obj)
 st['phase']='COMPLETE_LAB_SINGLE_ACTION';st['active']=None
 return {'native_event':evt,'scene_event_sha':scene.checksum(),
    'source_action':ACTION_ID,'source_id':BEAST_SOURCE,'target_id':TARGET_SOURCE,
    'source_mode':MODE,'world_effects':0,'before_hp':before,'after_hp':[scene.actors[a].hp for a in sorted(scene.actors)]}

def _validated_luta_authority(auth):
 """Require a concrete, non-test Master's ruling pointer. Local pointers alone
 are NOT cryptographic verification of Notion: upstream Comestre must physically
 reopen and reconcile the stated decision before providing this dict.
 """
 if not isinstance(auth,dict):raise Hold('LUTA_AUTHORITY_RECORD_MISSING')
 # The trusted decision must be materialized by the Comestre from a *later*
 # authoritative Notion readback. No such file exists in this R31 delivery.
 # Arbitrary inline truthy flags or invented source IDs are insufficient.
 authority_file=Path(__file__).resolve().parents[1]/'authority'/'MESTRE_LUTA_DECISION_VERIFIED.json'
 if not authority_file.is_file():raise Hold('MESTRE_LUTA_DECISION_STILL_REQUIRED')
 attested=json.loads(authority_file.read_text(encoding='utf8'))
 if sha(attested)!=sha(auth):raise Hold('LUTA_AUTHORITY_DIFFERS_FROM_LOCALLY_ATTESTED_DECISION')
 if (auth.get('verified_by_comestre_after_notion_readback') is not True or
     auth.get('master_explicit') is not True or
     auth.get('scope')!='ISOLATED_REAL_SOURCE_LAB_ONLY' or
     auth.get('provenance')!='PHYSICAL_NOTION_READBACK'):
  raise Hold('LUTA_COMPETENT_SOURCE_PHYSICALLY_UNVERIFIED')
 if auth.get('evidence_page_id')!=OP_SOURCE or auth.get('action_source_id')!=BEAST_SOURCE:
  raise Hold('LUTA_DECISION_BINDING_WRONG_OPERATION_OR_BEAST')
 if auth.get('decision_id') in (None,'','MOCK','TEST') or not auth.get('exact_decision_text'):
  raise Hold('LUTA_MESTRE_DECISION_TEXT_REQUIRED')
 bonus=auth.get('bonus')
 if type(bonus)!=int or bonus<0 or bonus>100:raise Hold('LUTA_BONUS_INVALID')
 # The authority is an explicitly reviewed proposal, not a newly inferred rule;
 # never infer the value from +6 general beast proficiency.
 return bonus


def attack_preview(st, bonus, seq):
 nonce=st['roll_nonce']+1;seed=st['seed']
 critical=tuple(journal.dice(seed,nonce,'R31-CRIT-'+str(k),1,6)[0] for k in (1,2,3))
 pos=critical[:2]==(6,6) and critical[2]>=5
 neg=critical[:2]==(1,1) and critical[2]<=2
 hit_die=journal.dice(seed,nonce,'R31-HIT-'+AID,1,6)[0]
 damage_die=journal.dice(seed,nonce,'R31-DAMAGE-'+AID,1,6)[0]
 natural_score=hit_die+SOURCES['fr']['for']+bonus
 # R27 Mestre LAB critical-negative policy: guaranteed miss/no penalty; positive
 # critical inherits official +max die overlay, without duplicating fixed FOR.
 return {'nonce':nonce,'critical_sequence':list(critical),'critical':
    'POSITIVE' if pos else ('NEGATIVE' if neg else None),
    'hit_die':hit_die,'damage_die':damage_die,'luta_bonus':bonus,
    'natural_hit_total':natural_score,'hit_score_to_native':0 if neg else natural_score,
    'damage_to_native':0 if neg else damage_die+SOURCES['fr']['for']+(6 if pos else 0),
    'damage_base':damage_die+SOURCES['fr']['for'],
    'critical_negative_uses_r27_lab_policy':bool(neg),
    'critical_positive_uses_max_die_bonus':bool(pos),
    'damage_transport_tag_only':'impacto','target_ca':SOURCES['goat']['ca']}


def _runner(st, payload, seq):
 """R18 invokes this runner on an isolated clone after durable pending intent.
 Only the ORIGINAL v0.8.1 performs hit/RD/HP/standard action update.
 """
 if st['phase']!='ACTIVE' or st['active']!=AID:raise Hold('ACTOR_TURN_NOT_ACTIVE')
 bonus=_validated_luta_authority(payload['luta_authority'])
 p=attack_preview(st,bonus,seq)
 if p!=payload['preview']:raise Hold('STALE_PREVIEW_AFTER_DURABLE_INTENT')
 if st['r31_source']['luta_value'] is not None:raise Hold('REPEATED_LUTA_BIND')
 st['r31_source']['luta_value']=bonus
 st['r31_source']['luta_status']='MESTRE_EXPLICIT_ISOLATED_LAB_ONLY'
 st['actors'][AID]['stats']['luta_bonus']=bonus
 native=_native(st,p['hit_score_to_native'],p['damage_to_native'])
 st['roll_nonce']=p['nonce']
 native['preview']=p
 native['authority_digest']=sha(payload['luta_authority'])
 native['canonical_credit']=0
 return native


def execute_authorized(db, authority_luta:dict):
 """Executable only after *real* decision about natural Luta is physically
 validated; never a default. On valid input: genuine v0.8.1 event in R18 WAL,
 replay-safe event_commit, official objects untouched. A failed native candidate
 leaves UNKNOWN_EFFECT pending by historical R18 contract (no auto-retry).
 """
 st,head,rev=checked(db)
 catalog(db)
 if rev!=0 or st['phase']!='ACTIVE':raise Hold('ONLY_FIRST_TURN_CAN_BE_EXECUTED_ONCE')
 bonus=_validated_luta_authority(authority_luta)
 p=attack_preview(st,bonus,rev+1)
 payload={'mode':MODE,'kind':'R31_REAL_SOURCE_RABADA','source_sha':sha(evidence_manifest()),
  'preview':p,'luta_authority':deepcopy(authority_luta),'expected_head':head,
  'expected_revision':rev,'experimental_only':True,'canonical_effects':0}
 # Pre-evaluate on a detached clone BEFORE the durable intent. If anything is
 # incomplete there is no pending command or partial live state.
 dummy=deepcopy(st)
 _runner(dummy,payload,rev+1)
 command='LAB-CMD-R31-'+sha({'payload':payload,'head':head})[:32]
 entry=journal.event_commit(db,command,'R31_REAL_SOURCE_SANDBOX_ATTACK',payload,_runner)
 current,h,v=checked(db)
 if v!=rev+1 or len(journal.history(db)['events'])!=v:raise Hold('POST_COMMIT_EVENT_COUNT_MISMATCH')
 return {'status':'NATIVE_REAL_SOURCE_SANDBOX_ACTION_EXPERIMENTAL_ONLY','event':entry,
         'state':current,'head':h,'revision':v,'official_effects':0}


def _conditional_runner(st,payload,seq):
 """DOES NOT certify an action. Real-source numbers + a declared science-only
 proficiency hypothesis. Shared original native v0.8.1 and R18 receipt ledger.
 """
 if payload['mode']!=MODE or payload['conditional_mode']!='LUTA_UNRESOLVED_NOT_REAL_ADMISSION':
  raise Hold('QA_CONDITIONAL_FLAG_MISSING')
 bonus=payload['conditioned_luta_bonus']
 if bonus not in (0,6) or type(bonus)!=int:raise Hold('ONLY_TWO_PREDECLARED_MATH_SCENARIOS')
 if st['phase']!='ACTIVE' or st['active']!=AID:raise Hold('SINGLE_ACTION_ALREADY_SPENT')
 preview=attack_preview(st,bonus,seq)
 if preview!=payload['preview']:raise Hold('R31_QA_PREVIEW_CHANGED')
 if st['r31_source']['luta_value'] is not None:raise Hold('R31_QA_ALREADY_EXECUTED')
 st['r31_source']['luta_value']=bonus
 st['r31_source']['luta_status']='EXPERIMENTAL_LUTA_CONDITION_NOT_RULE'
 st['actors'][AID]['stats']['luta_bonus']=bonus
 n=_native(st,preview['hit_score_to_native'],preview['damage_to_native'])
 st['roll_nonce']=preview['nonce'];st['r31_source']['conditional_only']=True
 n.update({'preview':preview,'source_kind':'NOTION_MASTER_REAL_READONLY',
   'proficiency_kind':'SCIENTIFIC_HYPOTHESIS_ONLY','real_action_fully_admitted':False,
   'not_canonical':True,'official_effects':0,'mechanical_stack':'native v0.8.1 / R18 SQLite'})
 return n


def execute_conditioned_for_qa(db,bonus):
 """A verifiable REAL-SOURCE NUMBERS / UNRESOLVED LUTA experimental test.
 DOES NOT represent the first fully lawful real-source action. Never promote.
 """
 if bonus not in (0,6) or type(bonus)!=int:raise Hold('QA_LUTA_MUST_BE_PREDECLARED_0_OR_6')
 st,head,rev=checked(db);catalog(db)
 if rev!=0 or st['phase']!='ACTIVE':raise Hold('REPLAY_NOT_ALLOWED_ON_EXISTING_ACTION')
 preview=attack_preview(st,bonus,rev+1)
 payload={'mode':MODE,'conditional_mode':'LUTA_UNRESOLVED_NOT_REAL_ADMISSION',
   'conditioned_luta_bonus':bonus,'source_manifest_sha':sha(evidence_manifest()),
   'preview':preview,'parent_head':head,'parent_rev':rev,
   'world_effects':0,'fully_admitted':False}
 # Exact detached dry-run before creating persistent intent.
 _conditional_runner(deepcopy(st),payload,rev+1)
 cmd='LAB-CMD-R31-QA-'+sha({'payload':payload,'head':head})[:25]
 row=journal.event_commit(db,cmd,'R31_NATIVE_CONDITIONAL_REAL_SOURCE_QA',payload,_conditional_runner)
 final,h,v=checked(db)
 if v!=1 or h!=journal.history(db)['head']:raise Hold('JOURNAL_NOT_REOPENED')
 return {'status':'NATIVE_CONDITIONAL_REAL_SOURCE_QA_NOT_FULL_ADMISSION',
     'source_kind':'NOTION_REAL','world_effects':0,'revision':v,'head':h,
     'effect':row['detail']['native_event'],'source_sha':sha(evidence_manifest()),
     'sqlite_sha256':hashlib.sha256(Path(db).read_bytes()).hexdigest()}


def replay_verify(db):
 st,head,rev=checked(db)
 rows=journal.history(db)['events']
 if rev not in (0,1) or len(rows)!=rev:raise Hold('REPLAY_UNEXPECTED_REVISION')
 if not rows:return {'status':'GENESIS_ONLY','head':head,'revision':rev,'native_events':0}
 row=rows[0];p=row['payload'];native=row['detail']['native_event']
 if row['kind']=='R31_NATIVE_CONDITIONAL_REAL_SOURCE_QA':
  bonus=p['conditioned_luta_bonus']
  if st['r31_source'].get('luta_status')!='EXPERIMENTAL_LUTA_CONDITION_NOT_RULE':raise Hold('QA_STATUS_MISMATCH')
  if row['detail']['real_action_fully_admitted'] is not False:raise Hold('QA_FALSE_CREDIT')
 else:
  auth=p['luta_authority'];bonus=_validated_luta_authority(auth)
 original=real_scene_state(st['seed']);original['r31_source']['luta_value']=bonus
 original['actors'][AID]['stats']['luta_bonus']=bonus
 expected=_native(original,p['preview']['hit_score_to_native'],p['preview']['damage_to_native'])
 for key in ('native_event','scene_event_sha','after_hp'):
  if expected[key]!=row['detail'][key]:raise Hold('INDEPENDENT_NATIVE_REPLAY_MISMATCH:'+key)
 if {k:v['resource']['hp'] for k,v in original['actors'].items()}!={k:v['resource']['hp'] for k,v in st['actors'].items()}:
  raise Hold('REPLAY_FINAL_HP_DIFFERS')
 return {'status':'PASS_R18_JOURNAL_AND_NATIVE_V081_REPLAY','head':head,'revision':rev,
  'native_effect_sha':expected['scene_event_sha'],'official_effects':0,
  'source_kind':'MASTER_REAL_SOURCE_READONLY','fully_admitted':row['kind']!='R31_NATIVE_CONDITIONAL_REAL_SOURCE_QA',
  'sqlite':str(db)}

def status(db):
 st,head,rev=checked(db)
 out={'schema':'R31_GATEWAY_STATUS','revision':rev,'head':head,'mode':MODE,
      'actor_provenance':{k:v['source_page_id'] for k,v in st['actors'].items()},
      'source_sha':st['r31_source']['source_manifest_sha'],
      'catalog':catalog(db),'outstanding_luta':st['r31_source']['luta_status'],
      'hp':{k:v['resource']['hp'] for k,v in st['actors'].items()},
      'pa':{k:v['resource']['pa'] for k,v in st['actors'].items()},
      'effective_attacks':rev,'canonical_effects':0,
      'native_method':'v0.8.1 apply_weapon_attack','separate_laboratory_sqlite':True}
 return out


def export_checkpoint(db,out_zip):
 """Portable independent SQLite backup + hashes; NEVER overwrite history."""
 import tempfile,zipfile
 db=Path(db);out_zip=Path(out_zip)
 if out_zip.exists():raise Hold('CHECKPOINT_ALREADY_EXISTS')
 source=journal.history(db);orig_state,head,revision=checked(db)
 with tempfile.TemporaryDirectory(prefix='R31-CP-',dir=out_zip.parent) as t:
  snap=Path(t)/'readback.sqlite';c=sqlite3.connect(db);d=sqlite3.connect(snap)
  try:c.backup(d)
  finally:d.close();c.close()
  duplicate=journal.history(snap);snapshot_state,snapshot_head,snapshot_rev=checked(snap)
  if source!=duplicate or snapshot_head!=head or snapshot_rev!=revision or snapshot_state!=orig_state:
   raise Hold('CHECKPOINT_BACKUP_STATE_DIFF')
  rb=journal.canonical(duplicate).encode('utf8');binary=snap.read_bytes()
  manifest={'schema':'R31_PORTABLE_REAL_SOURCE_EXPERIMENTAL_CHECKPOINT',
    'sqlite_sha256':hashlib.sha256(binary).hexdigest(),
    'history_sha256':hashlib.sha256(rb).hexdigest(),'source_sha':sha(evidence_manifest()),
    'head':head,'revision':revision,'canonical_effects':0,
    'real_source_actor_but_noncanonical_scene':True}
  with zipfile.ZipFile(out_zip,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   z.writestr('manifest.json',journal.canonical(manifest))
   z.writestr('snapshot.sqlite',binary);z.writestr('history.json',rb)
 return verify_checkpoint(out_zip)


def verify_checkpoint(path,restore_to=None):
 import zipfile,tempfile
 path=Path(path)
 with zipfile.ZipFile(path) as z:
  if sorted(z.namelist())!=['history.json','manifest.json','snapshot.sqlite'] or z.testzip():
   raise Hold('CHECKPOINT_ZIP_CORRUPT')
  m=json.loads(z.read('manifest.json'));binary=z.read('snapshot.sqlite');rb=z.read('history.json')
 if (m['source_sha']!=sha(evidence_manifest()) or
     m['sqlite_sha256']!=hashlib.sha256(binary).hexdigest() or
     m['history_sha256']!=hashlib.sha256(rb).hexdigest()):raise Hold('CHECKPOINT_SOURCE_OR_HASH_MISMATCH')
 with tempfile.TemporaryDirectory(prefix='R31-CHK-',dir=path.parent) as t:
  snap=Path(t)/'snapshot.sqlite';snap.write_bytes(binary)
  hist=journal.history(snap);state,head,rev=checked(snap)
  if (journal.canonical(hist).encode()!=rb or head!=m['head'] or rev!=m['revision']):
   raise Hold('CHECKPOINT_HISTORY_REPLAY_DIFF')
 if restore_to is not None:
  restore_to=Path(restore_to)
  if restore_to.exists():raise Hold('CHECKPOINT_RESTORE_NEVER_OVERWRITES')
  with open(restore_to,'xb') as f:f.write(binary);f.flush()
  checked(restore_to)
 return {'status':'PASS','revision':m['revision'],'head':m['head'],
  'zip_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
  'world_effects':0,'source_kind':'REAL_MASTER_IN_EXPERIMENTAL_SCENE'}
