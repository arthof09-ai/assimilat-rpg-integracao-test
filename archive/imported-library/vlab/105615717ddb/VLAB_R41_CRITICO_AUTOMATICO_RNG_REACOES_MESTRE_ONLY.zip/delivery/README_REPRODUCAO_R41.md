# VLAB R41 — Reprodução, procedência e preservação

**Identidade:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01 / MESTRE-SIDE. **Natureza:** pacote **delta** após R40, sem motores históricos incluídos e sem dados canônicos alterados.

## 1. Verificação independente do pacote, sem motor

Para o próximo Comestre, com o pacote materializado:

```bash
python verify_r41_package_standalone.py VLAB_R41_CRITICO_AUTOMATICO_RNG_REACOES_MESTRE_ONLY.zip
```

Esse verificador é **stdlib-only**, lê CRC e 1 hash SHA256 por membro declarado, extrai apenas para pasta temporária e audita as **6 cenas experimentais, 6 checkpoints** com os módulos `extension/verify_r41_mechanics_standalone.py` e `extension/verify_r41_long_standalone.py`. **Não importa v0.8.1, R18, R26 ou adapters executores.** Confere a intenção pendente portátil e as provas de 18 fixtures e 17 mutações. Não aprova por si só fonte canônica de RNG nem NAC-PASS produtivo.

## 2. Recuperar capacidade de execução em outro container

1. Materialize da Biblioteca as versões imutáveis originais **R27**, **R35**, **R36** e **R40** na pasta `/mnt/data/vlab_r41/input`, com os nomes originais. Mantenha o pacote R41 separado.
2. Extraia somente o delta R41 em `/mnt/data/vlab_r41/working`, **sem sobrescrever** os arquivos históricos.
3. Coloque os arquivos de script da extensão em `/mnt/data/vlab_r41/working/extension/`, o código fonte original de R40 como evidência em `/mnt/data/vlab_r41/working/r40/extension` e recupere `setup_runtime.py` (caso todos os insumos estejam presentes) para reconstruir `/mnt/data/vlab_r41/working/runtime_copy` a partir das fontes anteriores. O setup **copia** ou extrai componentes dos ZIPs originais, nunca os altera.
4. O script `r41_integrated_three_actors.py` usa deliberadamente esse caminho de sandbox. Nenhum script executa ao importar o pacote ZIP.
5. Para **verificação** dos cenários existentes, execute os oráculos independentes de cada SQLite e leia `evidence/R41_COLD_INDEPENDENT_AUDIT.json`; **NÃO** chame `run`/`create` ou `event_commit` contra um banco terminado ou com intenção pendente.
6. Testes novos exigem **seed, nome de banco, cmd_id e cenário todos novos**, fonte Mestre reaberta e decisão ainda vigente. Dado injetado é FIXTURE e não comprova rolagem natural.

## 3. Pontos específicos

- **Seed94208:** iniciativa R26 condicional +0, crítico natural primeiro evento, checkpoint em **revisão2**, ledger final **revisão14**. O verificador trata corretamente o checkpoint como prefixo causal, não como estado final.
- **Seeds94501–94504:** quatro observações **censuradas** ao surgir crítico negativo ainda sem efeito definido. Banco permanece em fase ACTIVE e com `winner=null`, sem evento fictício de empate. Nenhuma retentativa.
- **Seed94603:** batalha dirigida, após três seeds de busca, 84 rodadas e eliminação por crítico natural. É uma **semente selecionada**, não amostra representativa.
- **Unit fail after calculation:** backup `evidence/R41_FROZEN_PENDING_PORTABLE_BACKUP.sqlite` mantém **uma intenção pendente**, revisão1, um evento apenas; **NÃO RETENTAR**. Não confundir com seed53 R29, também intocada.
- **Iniciativa:** bônus +0 P5 pertencia à cena R34, **não se declara bônus verdadeiro da ficha** nas cenas R41. Crédito de combate fonte-completo adicional zero enquanto não houver fonte/autoridade.
- **Crítico positivo:** extensão `r41_critical_bridge.py` utiliza source-gate e RD originais, mas o crit hit override é **novo e experimental**. Nunca afirmar que v0.8.1 original já o fazia.
- **Contra-atacar:** gatilhos são pesquisados, mas ataque normal da Cabra sem Luta publicada não é admitido com +6 da Investida; concorrência AoO de duas criaturas é alcançável e precedência está pendente.

## 4. Proveniência normativa verificável

- <https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2> — OP-VLAB original, registro ANTES R41 da decisão Mestre, registro DEPOIS e readback obrigatórios.
- <https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0> — Sistema de Combate atual (fonte de sequências críticas, RD e Reações). **Não afirmar que sua página mudou** sem auditoria NAC-NORM competente.
- <https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6> — Cabra Bronze1, dados naturais somente leitura.
- <https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315> — Frígido Ossário Bronze5, ficha somente leitura.
- ZIP R27 / R39 / R39B / R40 preservados; `R41_COLD_INDEPENDENT_AUDIT.json` contém hashes.

## 5. Gate terminal

`REACTION_TRIGGER_AND_SINGLE_USE`, `TURN_SCHEDULER_EVENT_SOURCING`, `RNG_REPLAY_STATISTICS`: **todos continuam técnicos parciais**, pois nenhuma prova isolada cobre integralmente seus critérios R18. `0/17` certificados, `0/1875` células canônicas, `NAC-PASS-02` produtivo HOLD, writer/lease/epoch/fencing/GREEN HOLD e IBX-56 BLOCKED-EXTERNAL. R41 não abre produção, Party ou O Primeiro.
