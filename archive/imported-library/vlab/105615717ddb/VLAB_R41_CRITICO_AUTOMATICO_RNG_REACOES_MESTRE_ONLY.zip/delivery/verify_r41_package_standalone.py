"""R41 package-level stdlib cold verification. Does not import VLAB engine or any connector.
Requires only ZIP file. Extracts into a temporary path; never writes historical DB.
"""
import hashlib,zipfile,json,sys,tempfile,importlib.util,sqlite3
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()
def load_py(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def verify(zippath):
 p=Path(zippath)
 with zipfile.ZipFile(p) as z:
  if z.testzip() is not None:raise ValueError('ZIP_CRC_FAILED')
  listed=z.namelist();assert 'R41_FILE_MANIFEST.json' in listed
  man=json.loads(z.read('R41_FILE_MANIFEST.json'));print('ENTRY_COUNT',len(listed),'DECLARED_FILES',len(man['sha256']))
  if set(man['sha256'])!={n for n in listed if n!='R41_FILE_MANIFEST.json'}:raise ValueError('MANIFEST_ENTRY_SET_MISMATCH')
  for key,expected in man['sha256'].items():
   if key.startswith('/') or '..' in Path(key).parts:raise ValueError('ZIP_UNSAFE_PATH')
   if sha(z.read(key))!=expected:raise ValueError('FILE_HASH_INVALID:'+key)
  with tempfile.TemporaryDirectory(prefix='R41_AUDIT_ONLY_') as folder:
   z.extractall(folder);r=Path(folder);three=load_py(r/'extension'/'verify_r41_mechanics_standalone.py','r41three');long=load_py(r/'extension'/'verify_r41_long_standalone.py','r41long')
   p3=r/'ledgers'/'R41_FIRST_NATIVE_CRITICAL_SEED_SELECTED_208_SEED94208.sqlite';q3=r/'checkpoints'/('CHECKPOINT_'+p3.stem+'.sqlite')
   a=three.inspect(p3);b=three.inspect(q3,allow_active_prefix=True)
   if a['events']!=14 or b['events']!=2:raise ValueError('PREFIX_CHECKPOINT_INVALID')
   metrics=[a];prefixes=[b]
   for seed in (94501,94502,94503,94504,94603):
    f=r/'ledgers'/f'R41_LONG_OBSERVE_CRIT_VS_EVERY_DODGE_SEED{seed}.sqlite';cp=r/'checkpoints'/('CHECKPOINT_'+f.stem+'.sqlite')
    x=long.inspect(f);y=long.inspect(cp)
    if x!=y:raise ValueError('LONG_CHECKPOINT_CAUSAL_DIFF:'+str(seed))
    metrics.append(x);prefixes.append(y)
   attacks=sum(q.get('attacks',q.get('native_attacks')) for q in metrics)
   events=sum(q['events'] for q in metrics)
   critical=1+sum(q.get('critical_positive',0) for q in metrics[1:])
   if (events,attacks,critical)!=(475,469,9):raise ValueError('DENOMINATOR_FALSE')
   unit=json.loads((r/'evidence'/'R41_CRITICAL_DIRECTED_18_CASES.json').read_text())
   mutants=json.loads((r/'evidence'/'R41_RECHAINED_MUTATIONS_INDEPENDENT.json').read_text())
   if unit['pass']!=18 or mutants['pass']!=17:raise ValueError('TEST_REPORT_NOT_COMPLETE')
   con=sqlite3.connect(f'file:{(r/"evidence"/"R41_FROZEN_PENDING_PORTABLE_BACKUP.sqlite").resolve()}?mode=ro',uri=True)
   try:pend=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0];rev=int(con.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0])
   finally:con.close()
   if (pend,rev)!=(1,1):raise ValueError('FROZEN_PENDING_NOT_PRESERVED')
 return {'status':'PASS_R41_ARCHIVE_AND_COLD_MECHANICS','zip_sha256':sha(p.read_bytes()),'members':len(listed),'verified_sha256':len(man['sha256']),'scenes':6,'ledger_events':events,'native_attacks':attacks,'native_positive_crits':critical,'checkpoints':len(prefixes),'controlled_cases':unit['pass'],'rechained_adversarial_rejections':mutants['pass'],'unknown_effect_frozen':True,'terminal_certified':0,'canonical_writes':0}

if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('usage: verify_r41_package_standalone.py FILE.zip')
 print(json.dumps(verify(sys.argv[1]),ensure_ascii=False,indent=2))
