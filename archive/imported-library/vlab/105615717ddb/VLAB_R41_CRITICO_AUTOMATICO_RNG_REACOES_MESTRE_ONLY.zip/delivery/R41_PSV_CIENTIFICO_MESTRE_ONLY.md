# PSV — VLAB R41 | Crítico automático, integração nativa, censura científica e contratos

**Autoridade:** Ordem Suprema do Mestre R41 (15/10/2026) · **Executor:** CM-000006 · **Operação existente:** OP-VLAB-FUSION-SANDBOX-01 · **Ambiente:** MESTRE-SIDE / sandbox isolado · **Baseline:** R01–R40 e errata R39B imutáveis, motor v0.8.1, ledger R18, iniciativa/reação R26, gateway R31/R35/R36. **Crédito oficial/campanha = 0.**

## 1. Resultado executivo, com denominadores

A R41 **corrigiu por extensão experimental o ramo de acerto automático do crítico positivo**, sem editar v0.8.1. Além de reproduzir o erro e executar os 18 casos dirigidos, integrou a mudança em **6 novas cenas SQLite**: uma cena condicional multiator e cinco duelos com política contínua de Esquivar. O auditor frio, sem importar o motor, verificou **475 eventos, 469 ataques gerados pelo RNG experimental e 9 críticos positivos**; seis ledgers e seis checkpoints tiveram a causalidade conferida. Foram rejeitadas **17/17 mutações mecanicamente inválidas** apesar de suas cadeias de hashes terem sido reconstruídas. O motor original passou em **2/2 regressões R40** com 42 ataques históricos intactos.

| Tipo de evidência | N | Crédito | Critério |
|---|---:|---|---|
| Bateria dirigida de dados **injetados** C01–C18 | 18/18 PASS | Técnico UNITÁRIO | Não é amostragem RNG nem combates |
| Primeiro crítico R18 **realmente sorteado** em cena multiator | seed **94208**, 14 eventos e 13 ataques | Integração experimental **CONDICIONAL** | Bônus de Iniciativa +0 não atestado nas novas cenas |
| Duelo de Esquiva contínua, seeds previamente escolhidas independentemente | 94501–94504, 4/4 **CENSURADAS** | Ciência observacional, **sem vencedores** | Falha crítica negativa ainda sem efeito normativo completo |
| Duelo dirigido até eliminação por crítico | seed **94603**, 169 eventos e 168 ataques | Integrado, **semente selecionada pelo desfecho**, iniciativa condicional | Não usar para inferir taxa ou duração típica |
| Prova interespécies Cabra→Frígido | 1 fixture | Fonte real + dados controlados, **não combate** | Frígido sem Reflexo publicado, nenhuma Reação dele inventada |
| Auditoria de mutações (SQLite recadeado) | **17/17 rejeitadas** | Prova adversarial independente | Hash íntegro não basta |
| Reachability de Reações | 8 hipóteses classificadas | Pré-gate e diagnóstico normativo | Nenhum Contra-ataque real-fonte executado sem Luta normal |
| Contratos terminais originais | 3/17 examinados, **0/17 certificados** | Técnico parcial | NAC-PASS produtivo HOLD |

**Contadores preservacionais:** os **18 combates completos históricos de sandbox até R40** permanecem como base sem recontar esta rodada. As duas novas cenas que chegaram a término usam premissa **condicional** de bônus de Iniciativa zero, logo são creditadas separadamente como testes de integração e **não promovidas à categoria de combate com iniciativa totalmente autenticada**. As duas observações censuradas e cinco sondas históricas de R37 continuam separadas das quatro novas observações censuradas da R41. Patamares de combate fonte-real autenticado continuam **Bronze1 e Bronze5 (2/25, um único rank Bronze)**. Campanha0; terminais0/17; células canônicas0/1.875.

## 2. A — Defeito reproduzido no motor original

**Fonte física:** `vlab_effects_v08.apply_weapon_attack` original usa exclusivamente `hit = roll_score > CA`; `react_defensively` registra `damage_negated = (attack_score <= defense)` para Esquivar. O script R40 calculava a bonificação de dano do crítico, mas enviava ao resolvedor a pontuação comum do ataque; seu auditor herdava a mesma premissa. Nos 42 ataques R40 nenhum crítico positivo ocorreu, portanto **não se diagnosticou execução histórica errada nesses eventos**.

**Prova dirigida antes da correção:** Esquiva anunciada antes do ataque, `hit_die=1`, `score=1+FOR13+Luta6=20`, defesa26, crítico `6→6→5`, `damage_die=4`, bruto `4+13+6=23`, RD5. Sem adaptação: v0.8.1 classifica `hit=false`, dano0, Vida38→38. Com adaptação R41 em cena nova idêntica: **`hit=true` por crítico**, bruto23, RD5, líquido18, Vida38→20; Esquiva consumida. **Nenhum score99/999**, nenhum bypass da RD. Recibo: `evidence/R41_BEFORE_AFTER_CRITICAL_DEFECT_REPRO.json`.

## 3. B — Correção aditiva, sem alterar v0.8.1

`extension/r41_critical_bridge.py`: detecta **somente** as sequências positivas ordenadas `6,6,5` e `6,6,6` com margem base zero; recusa dado fora 1–6 e sequência negativa com consequência ainda indefinida. Para ataques comuns, chama **a função original v0.8.1**. Para crítico positivo, reutiliza catálogo/prova de fonte v0.8.1, `mitigate` de RD, `Scene.record` e orçamento de ação, mas resolve o acerto por **flag explícita** independente da pontuação comum. O recibo distingue `r41_positive_auto_hit`, `r41_hit_reason`, pontuação comum não inflada, dados individuais, máximo6 incorporado **uma vez**, mitigação, Vida e `numeric_dodge_would_negate`.

A Reação originalmente declarada permanece consumida e registrada pela função v0.8.1. Quando a condição positiva é válida, seu **resultado numérico de Esquiva não nega acerto automático**. Quando não existe crítico, a regra antiga de empate favorável à defesa continua funcionando. Crítico contra **Defender** fica retido no adaptador porque a interação entre acerto automático e essa mitigação potencialmente independente não foi materialmente homologada para fontes reais; não há bônus de Armadura/Fortitude inventado. Falha crítica negativa permanece fail-closed antes do ataque.

**Limite honesto:** o caminho de crítico positivo é um **adaptador experimental apoiado nas primitivas históricas**, e não uma alegação de que `apply_weapon_attack` original possua parâmetro de crítico automático. O motor v0.8.1 e os módulos R18/R26 originais estão **byte-idênticos** aos arquivos do ZIP R27.

## 4. C — Matriz dirigida de 18 casos e auditor adversarial

**18/18 PASS** na bateria C01–C18; controles de ataque comum e erro comum, positivo com e sem acerto comum, crítico atravessando CA e Esquiva26, alvo sem slot, segundo gatilho sem slot, inválida `6,5,6`, positivas `6,6,5`/`6,6,6`, negativo sem efeito inventado, empurrão positivo, RD sintética total, eliminação em fixture de HP baixo, skip de KO em fixture, replay/checkpoint do primeiro crítico nativo, comando duplicado e falha entre cálculo e commit.

**Etiquetas:** C01–C15 são **DADOS INJETADOS, FIXTURE**; RD30/HP10 são recursos **sintéticos declarados**, não dados das Cabras. C16 consulta SQLite real-fonte/RNG R18 por replay, C17/C18 usam bancos laboratoriais novos. Na C18 há **uma intenção durável pendente, revisão1, um evento de iniciativa e zero ataques publicados além dele**; o banco está congelado, o loader nativo recusa UNKNOWN_EFFECT e nenhuma retentativa foi efetuada.

**17/17 mutações rejeitadas:** em *cópias descartáveis*, a cadeia hash SHA256 foi recalculada para ficar **estruturalmente válida**. O auditor independente rejeitou crítico positivo como erro, Esquiva que nega crítico, sequência inválida, máximo de dano omitido/duplicado, RD inválida, d6=7, flag de crítico oculta na fita, label de RNG adulterado, Vida falsa, distância do empurrão, score/fonte/Luta indevidos, Reação inconsistente, ator fora da vez e **empurrão fabricado em ataque sem dano**. O replay criptográfico por si não passou a ser confundido com prova de mecânica.

## 5. D/F/G — RNG, combate e scheduler em cadeia verdadeira

**Pré-registro da seleção inicial:** SHA256 `f0b9628f9730f2484c15e6b2ce916803b3b172dbccd2e2379b718fd1ee9d4811`; universo 94001–104000, busca crescente, primeiro evento com crítico natural `6,6,5/6` e primeiro ator A/C atacando B com Reação. Foram examinadas **208 seeds**; a primeira elegível foi **94208**. O RNG R18 efetivamente produziu crítico `6,6,5`, dado comum1, dano3. Esquiva26 consumida; ataque comum20 não superaria nem CA20; crítico produziu bruto22, RD5, líquido17, B 38→21. A extensão persistiu **2 eventos iniciais** e checkpoint de revisão2 imediatamente após o crítico, preservado como **prefixo recuperável**, não como checkpoint final da cena. A execução nova prosseguiu até revisão14: **13 ataques nativos, duas mortes por golpes nativos (não atribuídas a crítico) e Cabra C sobrevivente com Vida7**, rodada6. Auditor independente e replay do motor concordam; iniciativa é **CONDITIONAL_ZERO_BONUS**.

**Crítico causando eliminação após Esquivar sempre:** o protocolo foi registrado **antes** da seleção de seeds, SHA256 `9b3e81d5f8636f3f88ea6a3c43a64405195daa2ebf52a543b4fecff920b7f62a`. Em universo ascendente de seeds 94601–104600, a primeira com eliminação por crítico antes de negativo foi **94603**, encontrada após **3 seeds** examinadas; as duas anteriores falhavam por crítico negativo. Nova cena transitória de duas Cabras: 84 rodadas, **168 ataques nativos e 168 Esquivas declaradas**, quatro críticos positivos, quatro empurrões, três Movimentos. No último ataque, `hit_die=1`, score comum20, crítico ordenado `6,6,5`, dado de dano4, bruto23, RD5, líquido18; Cabra A 4→0 durante a Reação de Esquiva declarada; Cabra B terminou com Vida19. **169 eventos/SQLite, replay e checkpoint PASS**, sem conceder turno extra ao eliminado. Essa é semente **direcionada**, não frequência amostral.

**Controle Frígido Bronze5:** o ataque de Investida da Cabra, em fixture com dados `hit1/crit665/dano4`, superou automaticamente CA31 do Frígido; RD geral Bronze5, Vida125→107. Fonte do Frígido foi lida no Notion; **não se supôs seu Reflexo ou bônus de Luta para ataques que não foram executados**. Não houve iniciativa nem combate completo neste controle.

## 6. I — Observação prolongada, sem empates inventados

Protocolo independente pré-registrado SHA256 `5974ae09c0e9b4b1d4b6c896a7b8adb182ee43a3f1c4b2306401e3fa3ebc8ba1`: seeds **94501–94504**, política Esquivar em TODO ataque quando slot disponível, horizonte150 rodadas, resultado de falha crítica negativa bloqueia a próxima intenção e **censura observação**. Resultados:

| Seed | Rodada observada | Ataques | Críticos positivos | HP final A/B | Estado |
|---|---:|---:|---:|---|---|
| 94501 | 33 | 64 | 0 | 38/38 | **CENSURADA por crítico negativo pré-evento** |
| 94502 | 5 | 9 | 0 | 38/38 | **CENSURADA** |
| 94503 | 11 | 21 | 1 | 18/38 | **CENSURADA** |
| 94504 | 98 | 194 | 3 | 3/22 | **CENSURADA** |

Todos os **288 ataques** foram gerados por R18 e tiveram a Esquiva anunciada; os críticos positivos causaram dano, os ataques comuns não. São **quatro observações censuradas adicionais** àquelas históricas de R37, não combates completos, nem empate de campanha. A probabilidade teórica básica de crítico positivo é **1/108 por verificação válida**, e a chance de zero positivos em42 verificações independentes é `(107/108)^42 ≈ 67,7%`; essa conta não valida independência do RNG. Com duas Investidas críticas na mesma criatura, o dano líquido é `1d6+14`; a soma de dois críticos basta para eliminar HP38 em **6/36 = 1/6** das combinações de danos, e caso contrário um terceiro crítico sem cura supera38. As decisões de qual combatente recebe dano, falhas críticas, censura e Reações tornam o tempo real de luta mais complexo. Não generalizar tempo ou vitórias das cinco seeds dirigidas/independentes misturadas.

## 7. E — Reações concorrentes e Contra-atacar

A regra atual de Ataque de Oportunidade concede Reação com Vantagem a cada inimigo deixado por movimento **voluntário** para fora de adjacência; a manobra Afastar-se com Segurança protege contra **um único inimigo**, não contra todos. Uma criatura no ponto (0,0) adjacente a inimigos distintos (1,5;0) e (0;1,5) pode sair para (−1,5;−1,5), disparando **duas oportunidades elegíveis de atores distintos no mesmo movimento**. Logo, **concorrência alcançável** é fato geométrico/regulatório. O Sistema de Combate pesquisado não resolve qual ataque acontece primeiro quando a ordem afeta morte/interrupção da movimentação. A cena foi **rejeitada antes de publicar evento, gastar reação ou aplicar dano**. Essa é pendência normativa real e mínima, não preferência do executor.

O deslocamento **forçado** pela Investida está expressamente excluído de Ataque de Oportunidade por decisão anterior do Mestre. Um ator não pode anunciar Esquivar e Defender simultaneamente com um único slot; serialização normal de dois ataques no scheduler e rejeição da segunda Reação já estão provadas. Contra-atacar é definido por ataque entrante **não superior à CA** e gera ataque normal com **Vantagem**; um Contra-ataque que também não supere a CA pode criar gatilho aninhado em regra geral. Porém o +6 de Luta da Cabra pertence **somente à Investida** e falta bônus competente para seu ataque normal de Contra-ataque; portanto não se simulou um Contra-ataque real-fonte com +6 indevido. **Nenhuma norma nova de precedência foi criada.** Os oito casos e a pergunta mínima constam em `R41_REACTION_REACHABILITY_TRIAGE.json`.

## 8. H — Reconciliação da iniciativa +0

A aprovação P5 em R34 autorizou `init_bonus=0` **apenas naquela cena específica**; R40 reutilizou a premissa, e a ordem R41 exige revisão. Não foi localizada autorização posterior competente para promovê-la a atributo publicado das Cabras em outras cenas. Os bancos R40 não foram editados nem invalidados matematicamente por retroação. Os bancos R41 registram explicitamente a premissa `R41_CONDITIONAL_SCENE_INIT_ZERO_NOT_SOURCE` e são contabilizados **fora de combat source-complete accepted credit**, embora iniciativa d6 e desempate tenham sido efetivamente gerados pela R26.

O mestre **não precisa repetir** decisões sobre Luta, Esquiva, crítico ou empurrão. Para cenas futuras com iniciativa plenamente fonte-autenticada, a primeira pendência é **valor individual de bônus de Iniciativa da Cabra B1 ou autorização experimental expressa da premissa +0 para mais cenas**; não converter essa pergunta em bloqueio para o desenvolvimento de ataques e Reações em testes sem iniciativa.

## 9. J — Matriz original dos três contratos prioritários

A matriz R18 **original, denominator17**, foi lida do ZIP R27 (`reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json`, hash no `R41_DELTA_MATRIX_3_OF_ORIGINAL_17.json`); não foi substituída. R41 altera **somente deltas de evidência em 3 IDs originais**:

| Contrato original | Implementação/prova R41 | Autoridade e revisão | Técnico integral / terminal / produção |
|---|---|---|---|
| `REACTION_TRIGGER_AND_SINGLE_USE` | Esquivar+crítico, consumo, replay e ataque seguinte, concorrência alcançável/blocked | Mestre e combate vigente; auditor 17 mutações | **NÃO / HOLD / HOLD**: prioridade AoO de dois atores e Contra-atacar real-source incompletos |
| `TURN_SCHEDULER_EVENT_SOURCING` | 3 atores com crítico, 2 atores KO por crítico, ordem/skip, checkpoint/censura | R26 e source; iniciativa+0 condicional | **NÃO / HOLD / HOLD**: iniciativa individual não autenticada, interrupções e fonte-composta incompletos |
| `RNG_REPLAY_STATISTICS` | 475 eventos,469 ataques, 9 críticos positivos, seleções dirigidas, quatro observações independentes e oráculo frio | RNG R18 experimental, não campanha; auditor externo ao motor | **NÃO / HOLD / HOLD**: origem canônica e efeitos de negativo ainda pendentes; seleção de seeds não inferencial |

Os outros **14 contratos** não foram alterados. **0/17 terminais certificados; 0/1.875 células canônicas; campanha0; writer/lease/epoch/fencing/GREEN produtivos e NAC-PASS-02 HOLD; IBX-56 BLOCKED-EXTERNAL.** NORM-FUSION-ABSORB-01 não foi invocada como promoção de fusão ou absorção.

## 10. K — Preservação, arquivos, falha congelada e auditoria

**Nove ZIPs originais R27/R31/R32/R34/R35/R36/R39/R39B/R40** foram conferidos byte a byte contra seus hashes conhecidos. O histórico v0.8.1, R18 e R26 reconstruídos em pasta de trabalho coincidem exatamente com os membros do ZIP R27, sem sobrescrita. Regressões R40 **2/2 PASS** (18+24 ataques históricos, nenhum crítico positivo). O auditor frio R41 validou **6 ledgers e 6 checkpoints**; o primeiro checkpoint da semente94208 é **prefixo rev2**, enquanto o ledger final é rev14, por isso não se exigiu identidade com o head terminal. Nos cinco duelos longos o checkpoint corresponde ao estado observado final. Bancos R39/R39B/seed53 e antigos UNKNOWN_EFFECT intocados.

Uma **cópia experimental R41 separada** possui intenção pendente após falha entre cálculo e commit. A leitura estrutural por SQLite mostrou `pending=1`, `revision=1`, `events=1` (somente iniciativa), ação adicional não publicada e integridade OK. O loader histórico não a aceita; **DO NOT RETRY**. Outra cópia com cmd_id duplicado preservou `revision=1`, `pending=0`, sem evento duplicado.

**Quatro dimensões verificadas:** (1) integridade SHA/CRC/SQLite, (2) oráculo independente de dados/fórmulas/dano/defesa, (3) scheduler/janelas/KO/checkpoint, (4) autoridades Mestre/Notion/gates. PASS local é **restrito** a esse escopo, não atestado produtivo nem autenticação de RNG da campanha.

## 11. L — Última unidade verificada e próxima fronteira

**Última unidade fisicamente verificada:** auditor frio `R41_COLD_INDEPENDENT_AUDIT.json` PASS sobre 6 cenas, 475 eventos e 469 ataques; matriz C01–C18 PASS; 17 mutações rejeitadas; 8 hipóteses de concorrência classificadas; R40 2/2 regressões; hashes históricos preservados. Artefatos do novo pacote são DELTAS que dependem do ZIP R27 e das extensões anteriores; não contêm cópia de todos os motores.

**Primeira pendência mecânica:** prioridade para resolver simultaneamente dois Ataques de Oportunidade de **oponentes distintos** acionados pela mesma movimentação voluntária, incluindo efeito do primeiro sobre a continuidade do deslocamento. **Segunda:** identificar fonte completa de ataque normal e seu bônus para testar Contra-atacar e interrupção aninhada. **Terceira:** validar o efeito do **crítico negativo** vigente; até lá, observações param antes dessa ação, sem criar efeito. **Quarta:** decisão de Iniciativa individual/continuidade da premissa zero para liberar cenas fonte-completas, quando exigível. **Quinta:** autenticar RNG canônico e independência estatística suficiente para critérios originais.

A correção do crítico foi **efetivamente executada, auditada e preservada**, não apenas proposta. **NAC-PASS de produção/canonização permanece HOLD**. Nenhum writer oficial, Party/O Primeiro ou combate da campanha foi utilizado.
