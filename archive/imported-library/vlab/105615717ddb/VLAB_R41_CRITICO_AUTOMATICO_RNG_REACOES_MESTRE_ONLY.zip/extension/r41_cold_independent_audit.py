"""R41 independent cold acceptance auditor. Does NOT import native resolver/gateway/R18/R26.
Only stdlib, previous readonly R40 oracle, independent R41 critical/long oracles.
"""
from __future__ import annotations
import hashlib,zipfile,json,sqlite3,sys
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working');sys.path.insert(0,str(R/'extension'));sys.path.insert(0,str(R/'r40'/'extension'))
import verify_r41_mechanics_standalone as three
import verify_r41_long_standalone as duel
import verify_r40_mechanics_standalone as previous

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(c,m):
 if not c:raise ValueError('R41_COLD_AUDIT_FAIL: '+m)
def readonly_meta(path):
 c=sqlite3.connect(f'file:{Path(path).resolve()}?mode=ro',uri=True)
 try:
  chk=c.execute('PRAGMA integrity_check').fetchone()[0];meta=dict(c.execute('SELECT key,value FROM meta'))
  events=c.execute('SELECT COUNT(*) FROM events').fetchone()[0];pending=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
 finally:c.close()
 return {'integrity':chk,'revision':int(meta['revision']),'head':meta['head'],'events':events,'pending':pending}

def run():
    orig=R.parent/'input';prev_expected={
      'VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip':'d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1',
      'VLAB_R31_PRIMEIRA_RABADA_NATIVA_CONDICIONAL_MESTRE_ONLY.zip':'98841bf0473545005bdb107597981805199a35081e2dc84a4b6d150b97fa6835',
      'VLAB_R32_PRIMEIRA_RABADA_INTEGRAL_REAL_FONTE_MESTRE_ONLY.zip':'20530947c8349d8e544fa5ee506e7327b31a8e6d37eb3aab23c180d1639c4a53',
      'VLAB_R34_PRIMEIRO_COMBATE_COMPLETO_BESTAS_REAIS_MESTRE_ONLY.zip':'876236ebb34ee76f514b17d3ff765f32d40e1b8c81ef7f21248e0d34187705bc',
      'VLAB_R35_EMPURRAO_GEOMETRIA_COMPARACAO_MESTRE_ONLY.zip':'61c952c6d1896845fd2e96433bf65d1986eb313810304e708190109ce3b02413',
      'VLAB_R36_ESQUIVA_NATIVA_PAREADA_MESTRE_ONLY.zip':'b35f748db057f137a768d50e986037b87b7f8e0b2ddb17a70f23a5b2321506e5',
      'VLAB_R39_GATES_REACAO_SCHEDULER_RNG_MESTRE_ONLY.zip':'2a2a5f6774da7d917d61a66b1cdb206de5195e2665c8807bf5c8c4a46ca09892',
      'VLAB_R39B_ERRATA_FONTE_INVESTIDA_REACAO_MESTRE_ONLY.zip':'3333d215042d0de9ec92a1d10d125f2417864cd5dc474e5f62b9090bf3552166',
      'VLAB_R40_INTEGRACAO_TRES_ATORES_VALIDACAO_MECANICA_MESTRE_ONLY.zip':'2be2d7b8cb39fd4aa340afc07a200c8c1c5234475256635e2dad85a2aeeb1e71'}
    archives={}
    for name,exp in prev_expected.items():
        p=orig/name;check(p.exists() and sha(p)==exp,'HISTORICAL_PACKAGE_CHANGED_'+name)
        archives[name]=exp
    # Confirm historic engine byte equality. R27 originals are source of reconstructed runtime.
    with zipfile.ZipFile(orig/'VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip') as z:
        for name,entry in [('vlab_effects_v08.py','working/historical_v081_verified_original/comestre_vlab/vlab_effects_v08.py'),('vlab_r18_interactive.py','fusion_stage12/vlab_r18_interactive.py'),('vlab_r26_master_rulings.py','fusion_stage12/vlab_r26_master_rulings.py')]:
            p=R/'runtime_copy'/'r27'/entry
            check(p.is_file() and p.read_bytes()==z.read(entry),'HISTORIC_CODE_MUTATED_'+name)
    target=R/'ledgers'/'R41_FIRST_NATIVE_CRITICAL_SEED_SELECTED_208_SEED94208.sqlite'
    verified=[{'name':target.name,'native':three.inspect(target),'checkpoint':three.inspect(R/'checkpoints'/('CHECKPOINT_'+target.stem+'.sqlite'),allow_active_prefix=True)}]
    for seed in [94501,94502,94503,94504,94603]:
        p=R/'ledgers'/f'R41_LONG_OBSERVE_CRIT_VS_EVERY_DODGE_SEED{seed}.sqlite'
        verified.append({'name':p.name,'native':duel.inspect(p),'checkpoint':duel.inspect(R/'checkpoints'/('CHECKPOINT_'+p.stem+'.sqlite'))})
    check(len(verified)==6,'EXPECTED_SIX_NEW_SCENES')
    for q in verified:
        check(q['native']['status']=='PASS' and q['checkpoint']['status']=='PASS','CHECKPOINT_REPLAY_FAIL')
        if q['name']==target.name:
            check(q['checkpoint']['events']==2 and q['native']['events']==14,'CRITICAL_CHECKPOINT_NOT_PREFIX')
        else:check(q['native']['checksum']==q['checkpoint']['checksum'],'CHECKPOINT_NOT_REPLAY_EQUIVALENT')
    origR40=[]
    for name in ('R40_FIRST_ELIGIBLE_ACB_SEED91001.sqlite','R40_FIRST_ELIGIBLE_UNTIED_SEED91002.sqlite'):
        p=R/'r40'/'ledgers'/name;v=previous.inspect(p);check(v['status']=='PASS','R40_REGRESSION_FAILED_'+name);origR40.append(v)
    suites={k:json.loads((R/'evidence'/k).read_text()) for k in ('R41_CRITICAL_DIRECTED_18_CASES.json','R41_RECHAINED_MUTATIONS_INDEPENDENT.json','R41_REACTION_REACHABILITY_TRIAGE.json','R41_CRITICAL_KO_SEED_SEARCH_RESULT.json','R41_DIRECTED_SEED_SELECTION_RESULT.json','R41_BEFORE_AFTER_CRITICAL_DEFECT_REPRO.json')}
    check(suites['R41_CRITICAL_DIRECTED_18_CASES.json']['pass']==18,'C_MATRIX_INCOMPLETE')
    check(suites['R41_RECHAINED_MUTATIONS_INDEPENDENT.json']['pass']==17,'MUTATION_MATRIX_INCOMPLETE')
    check(suites['R41_REACTION_REACHABILITY_TRIAGE.json']['fail_closed_concurrent_aoo'],'REACTION_PRIORITY_INVENTED')
    check(suites['R41_BEFORE_AFTER_CRITICAL_DEFECT_REPRO.json']['status']=='DEFECT_REPRODUCED_ADD_ON_FIX_PASS','BEFORE_AFTER_INVALID')
    # Frozen pending never read via historical j.load; open raw SQLite read-only.
    pending=readonly_meta(R/'ledgers'/'R41_UNIT_FAIL_AFTER_CALC_SEED94199.sqlite')
    check(pending['integrity']=='ok' and pending['pending']==1 and pending['events']==1,'PENDING_FROZEN_NOT_PRESERVED')
    duplicates=readonly_meta(R/'ledgers'/'R41_UNIT_DUPLICATE_CMD_SEED94198.sqlite')
    check(duplicates['pending']==0 and duplicates['events']==1,'IDEMPOTENCY_FIXTURE_BAD')
    # Summarize without double counting checkpoint or fixtures.
    native_attacks=sum(v['native']['native_attacks'] if 'native_attacks' in v['native'] else v['native']['attacks'] for v in verified)
    native_events=sum(v['native']['events'] for v in verified)
    critpos=sum(v['native'].get('critical_positive',0) for v in verified[1:])+1
    check(native_attacks==469 and native_events==475 and critpos==9,'R41_DENOMINATOR')
    result={'schema':'R41_COLD_INDEPENDENT_AUDIT_V1','scope':'READONLY_STRUCTURAL_MECHANICAL_CAUSAL_NOT_PRODUCTIVE','status':'PASS_WITH_NORMATIVE_LIMITS','historical_archives_preserved':archives,'original_motor_bytes_unchanged':True,'new_scenes':verified,'new_scenes_count':6,'new_native_attacks':native_attacks,'new_native_ledger_events':native_events,'new_native_positive_criticals':critpos,'replay_checkpoint_pairs':6,'fixtures':{'directed_matrix':18,'rechain_mechanical_mutants':17,'reaction_reachability_cases':8,'Frigido_controlled_probe':1},'historical_R40_rechecked':origR40,'frozen_R41_pending':pending,'idempotent_test':duplicates,'directed_selection_counts':{'first_native_critical':suites['R41_DIRECTED_SEED_SELECTION_RESULT.json']['examined'],'first_long_crit_KO':suites['R41_CRITICAL_KO_SEED_SEARCH_RESULT.json']['scanned_seeds']},'censured_long_scenes':4,'long_directed_terminal':1,'three_actor_directed_terminal':1,'real_source_full_credit':0,'initiative0_is_conditional_only':True,'new_canonical_writes':0,'terminal_contracts':0,'official_cells':0}
    return result
if __name__=='__main__':
 x=run();p=R/'evidence'/'R41_COLD_INDEPENDENT_AUDIT.json';p.write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n');print('COLD AUDIT',x['status'],'scenes',x['new_scenes_count'],'events',x['new_native_ledger_events'],'attacks',x['new_native_attacks'],'crit',x['new_native_positive_criticals'])
