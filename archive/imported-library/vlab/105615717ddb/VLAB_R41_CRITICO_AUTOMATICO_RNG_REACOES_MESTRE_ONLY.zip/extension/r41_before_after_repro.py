"""One controlled-dice fixture compares genuine historical v081 behavior against R41 add-on.
Does not alter original engine or official material. DICE INJECTED, not native RNG.
"""
from __future__ import annotations
import sys,json
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r41_integrated_three_actors as h
from vlab_effects_v08 import Scene,Combatant,apply_weapon_attack,react_defensively
from vlab_action_catalog_v01 import ActorActionState
from vlab_rd_v08 import Resistances
from r41_critical_bridge import apply_source_attack
b=h.b;m=h.m

def frame():
 ids=('FIXTURE_GOAT_ATTACKER','FIXTURE_GOAT_TARGET');a,t=ids
 s=Scene({a:Combatant(a,38,22,20,10,None,None,6,'ADJ-A'),t:Combatant(t,38,22,20,10,None,None,6,'ADJ-B')},seed=0,provenance='R41_CONTROLLED_REPRO_NOT_NATIVE_RNG')
 attack=ActorActionState(actor_id=a,ordinal_level=1,available_pa=22,known_action_ids=(b.GO_ACTION,),standard_available=True,reaction_available=True,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(t,))
 rx=ActorActionState(actor_id=t,ordinal_level=1,available_pa=22,known_action_ids=(m.DODGE_ACTION,),reaction_available=True,reaction_trigger_observed='BEFORE-ATTACK',enemy_ids_visible=(a,))
 reaction=react_defensively(s,t,kind='ESQUIVAR',attack_score=20,announced_before=True,trigger_source='BEFORE-ATTACK',source=m.source_reaction(),state=rx,proofs=(m.proof_reaction(),),strict=True)
 return s,a,t,attack,reaction

def run():
 s,a,t,state,rx=frame()
 old=apply_weapon_attack(s,a,t,source=b.native_source(),state=state,proofs=(b.proof('MIRROR'),),roll_score=20,damage=23,damage_tag='impacto',rd=Resistances(general=5,specific=(),provenance='BRONZE_RD5'),strict=True,defense_event=rx)
 before={'engine':'unaltered_v0.8.1','critical_sequence_input':[6,6,5],'critical_score_for_native':20,'damage_crit_already_assembled':23,'hit':old['hit'],'net':old['net'],'hp_after':s.actors[t].hp,'reaction_spent':s.actors[t].reaction==0}
 s,a,t,state,rx=frame()
 new=apply_source_attack(s,a,t,source=b.native_source(),state=state,proofs=(b.proof('MIRROR'),),attack_die=1,damage_die=4,critical_dice=(6,6,5),force=13,luta=6,rd=Resistances(general=5,specific=(),provenance='BRONZE_RD5'),reaction_event=rx)
 after={'engine':'v0.8.1_original_catalog_Rd_reaction_primitives+R41_ADD_ON','score_not_inflated':new['roll_score']==20,'critical_status':new['r41_critical_status'],'reason':new['r41_hit_reason'],'hit':new['hit'],'raw':new['raw'],'rd':new['rd_applied'],'net':new['net'],'hp_after':s.actors[t].hp,'reaction_spent':s.actors[t].reaction==0,'numeric_dodge_would_negate':new['numeric_dodge_would_negate']}
 assert before['net']==0 and before['hit'] is False and before['hp_after']==38 and before['reaction_spent']
 assert after['hit'] and after['net']==18 and after['hp_after']==20 and after['reaction_spent'] and after['score_not_inflated']
 return {'defect':'original_v081_only_score_gt_CA_and_numeric_dodge_negates_valid_critical','controlled_dice':{'crit':[6,6,5],'hit':1,'damage':4},'before':before,'after':after,'source_origin':'real-goat source values, controlled dice synthetic fixture NOT native RNG','original_modified':False,'status':'DEFECT_REPRODUCED_ADD_ON_FIX_PASS'}
if __name__=='__main__':
 z=run();p=R/'evidence'/'R41_BEFORE_AFTER_CRITICAL_DEFECT_REPRO.json';p.write_text(json.dumps(z,indent=2,ensure_ascii=False)+'\n');print(json.dumps(z,ensure_ascii=False))
