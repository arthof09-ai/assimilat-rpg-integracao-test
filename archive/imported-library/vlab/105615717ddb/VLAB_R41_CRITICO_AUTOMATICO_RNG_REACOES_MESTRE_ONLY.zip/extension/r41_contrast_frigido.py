"""Directed critical against second REAL documented beast source, no turn initiative.
Controlled dice only: not native RNG, not a full fight, no world changes.
"""
import json,sys
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r41_integrated_three_actors as h
from r41_critical_bridge import apply_source_attack
import run_r35_native as b
from vlab_effects_v08 import Scene,Combatant
from vlab_action_catalog_v01 import ActorActionState
from vlab_rd_v08 import Resistances
fr='f0dc2b32-4ede-820a-b947-0168d4a53315';go=b.GOAT
fighters={'R41_GOAT':Combatant('R41_GOAT',38,22,20,10,None,None,6,'LAB-A'),'R41_FRIGIDO':Combatant('R41_FRIGIDO',125,120,31,15,None,None,None,'LAB-B')}
sc=Scene(fighters,seed=123,provenance='R41_CONTROLLED_DICE_REAL_SOURCE_READONLY_NO_INIT')
state=ActorActionState(actor_id='R41_GOAT',ordinal_level=1,available_pa=22,known_action_ids=(b.GO_ACTION,),standard_available=True,reaction_available=True,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=('R41_FRIGIDO',))
row=apply_source_attack(sc,'R41_GOAT','R41_FRIGIDO',source=b.native_source(),state=state,proofs=(b.proof('PROBE'),),attack_die=1,damage_die=4,critical_dice=(6,6,5),force=13,luta=6,rd=Resistances(general=5,specific=(),provenance='BEAST_BRONZE_NORMAL_RD5'),reaction_event=None)
assert row['roll_score']==20 and row['hit'] and row['net']==18 and sc.actors['R41_FRIGIDO'].hp==107
out={'kind':'CONTROLLED_DICE_SOURCE_VALID_ATTACK_TO_FRIGIDO','source_goat':go,'source_frigido':fr,'source_frigido_as_of':'2026-10-01T18:00:42.693Z','attack_score':20,'target_ca':31,'crit':[6,6,5],'damage_die':4,'gross':23,'rd':5,'net':18,'target_hp':{'before':125,'after':107},'source_gate':'original v0.8.1 ActionCatalog + R41 add-on','origin':'controlled dice, NOT RNG R18, NOT complete combat'}
p=R/'evidence'/'R41_FRIGIDO_CONTROLLED_CRIT_PROBE.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
