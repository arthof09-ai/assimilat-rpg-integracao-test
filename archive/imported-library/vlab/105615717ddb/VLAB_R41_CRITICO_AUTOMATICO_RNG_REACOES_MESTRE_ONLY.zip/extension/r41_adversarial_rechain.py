"""R41 adversarial structural-valid/mechanical-invalid disposable SQLite chain tests.
NEVER edits the original db, only temp copied clones. Reads independent stdlib oracle.
"""
from __future__ import annotations
import copy,hashlib,json,sqlite3,tempfile,shutil,sys
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working');sys.path.insert(0,str(R/'extension'))
import verify_r41_mechanics_standalone as oracle
BASE=R/'ledgers'/'R41_FIRST_NATIVE_CRITICAL_SEED_SELECTED_208_SEED94208.sqlite'

def write_mutation_clone(original,target,mutator,at_seq=2):
    shutil.copy2(original,target)
    con=sqlite3.connect(target)
    try:
        rows=con.execute('SELECT seq,row_json,before_sha,after_sha,cmd_id FROM events ORDER BY seq').fetchall()
        meta=dict(con.execute('SELECT key,value FROM meta'))
        head=meta['genesis'];changed=False
        for seq,jsonrow,before_sha,after_sha,cmdid in rows:
            row=json.loads(jsonrow)
            if seq==at_seq:
                mutator(row);changed=True
            row['prev']=head
            # after_sha unchanged to intentionally keep published state locally consistent;
            # the event itself can still be mechanically false despite valid chain.
            row_hash=oracle.H(row)
            con.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(head,oracle.J(row),row_hash,seq))
            head=row_hash
        assert changed
        con.execute("UPDATE meta SET value=? WHERE key='head'",(head,))
        con.commit()
    finally:con.close()

def structural_valid(path):
    meta,rows=oracle.read(path);prev=meta['genesis'];past=None
    for seq,cmd,p,row_json,row_sha,before_sha,after_sha in rows:
        row=json.loads(row_json)
        if not (row['prev']==p==prev and row['seq']==seq and row['before_sha']==before_sha and row['after_sha']==after_sha and row_sha==oracle.H(row)):return False
        if past is not None and past!=before_sha:return False
        past=after_sha;prev=row_sha
    return prev==meta['head'] and past==oracle.H(json.loads(meta['state']))

MUTANTS={
 '01_VALID_CRIT_MISCLASSIFIED_MISS':lambda r:r['detail']['native_attack'].__setitem__('hit',False),
 '02_VALID_CRIT_NUMERIC_DODGE_NEGATES':lambda r:r['detail']['native_attack'].__setitem__('defense_negated',True),
 '03_INVALID_CRIT_SEQUENCE_APPLIED':lambda r:r['detail']['native_attack'].__setitem__('r41_critical_dice',[6,5,6]),
 '04_CRIT_MAX_NOT_ADDED':lambda r:r['detail']['native_attack'].__setitem__('r41_max_dice_added',0),
 '05_CRIT_MAX_TWICE':lambda r:r['detail']['native_attack'].__setitem__('raw',28),
 '06_RD_INCORRECT':lambda r:r['detail']['native_attack'].__setitem__('rd_applied',0),
 '07_CRIT_DIE_OUTSIDE_RANGE':lambda r:r['detail']['RNG']['critical_dice'].__setitem__(2,7),
 '08_CRIT_FLAG_NOT_IN_TAPE':lambda r:r['detail']['RNG'].__setitem__('critical_positive',False),
 '09_CRIT_RNG_LABEL_CHANGED':lambda r:r['detail']['RNG']['critical_labels'].__setitem__(0,'UNAUTHORIZED_LABEL'),
 '10_FINAL_HP_FALSE':lambda r:r['detail']['native_attack'].__setitem__('after_hp',38),
 '11_PUSH_WITHOUT_POSITIVE_CAUSE':lambda r:r['detail']['push'].__setitem__('m',3.0),
 '12_EVENT_STILL_HASHED_BUT_FALSE_DAMAGE':lambda r:r['detail']['native_attack'].__setitem__('net',0),
 '13_FAKED_CRIT_HIT_REASON':lambda r:r['detail']['native_attack'].__setitem__('r41_hit_reason','NORMAL_ROLL'),
 '14_DODGE_SLOT_BEFORE_ATTACK_FALSE':lambda r:r['detail']['voluntary_reaction'].__setitem__('consumes_reaction',False),
 '15_ACTOR_OUT_OF_TURN':lambda r:r['detail'].__setitem__('actor','LAB_R41_GOAT_B'),
 '16_UNAUTHORIZED_LUTA_BONUS':lambda r:r['detail']['RNG'].__setitem__('luta',7),
 '17_PUSH_WITHOUT_HIT_OR_DAMAGE':lambda r:r['detail'].__setitem__('push',{'m':1.5,'from':[0.,0.],'to':[1.5,0.],'ff':310}),
}

def run():
    positive=oracle.inspect(BASE)
    out=[]
    with tempfile.TemporaryDirectory(prefix='R41_MUTATIONS_ONLY_') as td:
        for name,mut in MUTANTS.items():
            tgt=Path(td)/(name+'.sqlite');write_mutation_clone(BASE,tgt,mut,at_seq=7 if name=='17_PUSH_WITHOUT_HIT_OR_DAMAGE' else 2)
            goodchain=structural_valid(tgt)
            bad=False;reason=''
            try:oracle.inspect(tgt)
            except Exception as exc:bad=True;reason=str(exc)
            ok=goodchain and bad
            out.append({'name':name,'status':'PASS' if ok else 'FAIL','structural_rechained_valid':goodchain,'independent_mechanical_rejected':bad,'mechanical_reason':reason[:220]})
            if not ok:raise AssertionError(name+repr(out[-1]))
    return {'source_db':str(BASE),'unmodified_source_head':positive['head'],'tests':len(out),'pass':sum(x['status']=='PASS' for x in out),'mutations':out,'clones':'deleted temporary, no historical change'}
if __name__=='__main__':
 x=run();p=R/'evidence'/'R41_RECHAINED_MUTATIONS_INDEPENDENT.json';p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');print('RECHAINED MUTANTS',x['pass'],'/',x['tests'])
