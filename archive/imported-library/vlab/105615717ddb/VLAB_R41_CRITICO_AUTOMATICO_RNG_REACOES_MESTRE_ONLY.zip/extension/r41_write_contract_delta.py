from __future__ import annotations
import json,hashlib
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working')
orig=R/'evidence'/'R41_ORIGINAL_R18_MATRIX_REFERENCE.json';src=json.loads(orig.read_text());assert src['denominator']==17 and len(src['rows'])==17
ids=[r['contract_id'] for r in src['rows']];assert len(set(ids))==17
new={
 'REACTION_TRIGGER_AND_SINGLE_USE':{
  'implementation':'PASS_EXPERIMENTAL_FOR_ESQUIVAR_CRITICAL_OVERRIDE','proof':'PASS_18_CASE_FIXTURES_PLUS_NATIVE_CRIT_AND_LONG_DUEL','authority':'PASS_FOR_POSITIVE_CRIT_MASTER_DECISION_AND_R26_SINGLE_SLOT','independent_review':'PASS_READONLY_MECHANICS_17_RECHAINED_MUTANTS','technical_integral':False,'terminal':False,'production':False,
  'new_evidence':['R41 first native critical consumes Esquiva while score20 insufficient vs defense26','R41 long seed94603 168 Esquivas with critical KO','18/18 directed C1–C18 cases','8-reachability-case triage + reachable dual AoO geometry, preintent HOLD'],
  'original_missing':'MULTI_TRIGGER_INTERRUPTS_AND_NORMATIVE_PRECEDENCE','residual':'Resolve normative order of two distinct opportunity attacks on one voluntary movement; test nested Counter when a genuinely authorized normal-attack Luta exists; Defender against critical must preserve independent mitigation.'},
 'TURN_SCHEDULER_EVENT_SOURCING':{
  'implementation':'PASS_EXPERIMENTAL_FOR_ACTIVE_ADVANCE_AND_KO','proof':'PASS_TWO_CONDITIONAL_TERMINALS_FOUR_LONG_CENSORS_READONLY','authority':'PARTIAL_INIT_BONUS_ZERO_NOT_SOURCE_AUTHORIZED_NEW_SCENES','independent_review':'PASS_R41_3ACTOR_AND_2ACTOR_CAUSAL_VERIFIERS','technical_integral':False,'terminal':False,'production':False,
  'new_evidence':['seed94208 three actor conditional fight, 14 events, native critical plus two native knockouts','seed94603 long two actor conditional fight, 169 events, native critical knockout during declared Esquiva','4 long observations censored BEFORE negative crit without winner','R40 original next_alive wrapper persisted and matched R41 independent oracle'],
  'original_missing':'CANON_INITIATIVE_TIE_INTERRUPTION_AND_SOURCE_COMPLETE_EVENTS','residual':'Re-authorize/resolve individual initiative bonus beyond R34 P5; sources for Counter and reaction-kill interrupt; cases 0 survivors with source-legal simultaneous effects.'},
 'RNG_REPLAY_STATISTICS':{
  'implementation':'PASS_R18_DICE_R41_3D6_CONSUMPTION','proof':'PASS_FIRST_NATIVE_SEED94208_AND_DIRECTED_KO_SEED94603_AND_READONLY_COLD','authority':'PARTIAL_EXPERIMENTAL_RNG_NOT_CANONICAL','independent_review':'PASS_475_EVENTS_469_ATTACKS_9_POS_CRITS_AND_16_TAMPERS','technical_integral':False,'terminal':False,'production':False,
  'new_evidence':['R18 native first positive critical selected after exactly 208 seeds; rolled ordered 665, score20, Esquiva26, net17','directed critical knockout after screening 3 seeds, 168 turns, last score20 net18','4 independent pre-registered long seeds all censored on negative critical, not victories','independent cold oracle reconstructs every attack die and applies auto-hit and RD','R40 original no critical: 2 scenarios regressions PASS'],
  'original_missing':'CANONICAL_DICE_SOURCE_AND_STATISTICAL_HOLDOUT','residual':'Canonical dice source not authenticated; negative-critical consequences and critical modifier of other species not generalized; selected seeds cannot estimate frequency or win rate.'}
}
rows=[]
for r in src['rows']:
 if r['contract_id'] in new:
  rows.append({'original_id':r['contract_id'],'original_acceptance_still_required':r['original_acceptance_still_required'],'r18_terminal_after':r['terminal_after'],'r40_prior':'TECHNICAL_PARTIAL_TERMINAL_HOLD','r41':new[r['contract_id']]})
assert len(rows)==3
out={'schema':'R41_DELTA_3_OF_ORIGINAL_R18_17_CONTRACTS','baseline_matrix_sha256':hashlib.sha256(orig.read_bytes()).hexdigest(),'original_denominator':17,'original_ids':ids,'touched_requirements':3,'unchanged_requirements':14,'fully_certified_terminal':0,'canonic_cells_credit':0,'rows':rows,'no_rewrite_of_original_17_matrix':True,'NAC_PASS_TERMINAL':'HOLD','IBX_56':'BLOCKED_EXTERNAL'}
p=R/'evidence'/'R41_DELTA_MATRIX_3_OF_ORIGINAL_17.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False,sort_keys=True)+'\n');print('MATRIX',len(rows),'of',len(ids),'SHA',out['baseline_matrix_sha256'])
