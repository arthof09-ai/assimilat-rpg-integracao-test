"""R41 directed CASES C01..C18: isolated fixtures with exact labels.
Only C16/C17/C18 exercise R18 SQLite; C01-C15 are controlled-die unit fixtures.
Does not add full combats or canonical events. No historical DB opened for write.
"""
from __future__ import annotations
import json,sys,copy,sqlite3
from pathlib import Path
from dataclasses import asdict
R=Path('/mnt/data/vlab_r41/working')
sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r41_integrated_three_actors as h
from r41_critical_bridge import apply_source_attack,ordered_critical
from vlab_effects_v08 import Scene,Combatant,react_defensively,EffectBlocked
from vlab_action_catalog_v01 import ActorActionState,action_menu
from vlab_rd_v08 import Resistances
m=h.m;b=h.b;j=h.j
O={}
def record(k,ok,detail,kind='DICE_INJECTED_UNIT_TEST'):
    O[k]={'status':'PASS' if ok else 'FAIL','kind':kind,'detail':detail}
    if not ok:raise AssertionError(k+':'+str(detail))
def sample(*,crit=(3,4,2),hit=5,dam=4,dodge=False,defender_hp=38,rd=5,reaction=1):
    aa='R41_UNIT_A';bb='R41_UNIT_B'
    sn=Scene({aa:Combatant(aa,38,22,20,10,None,None,6,'LAB-A'),bb:Combatant(bb,defender_hp,22,20,10,None,None,6,'LAB-B',reaction=reaction)},seed=0,provenance='SYNTHETIC_UNIT_FIXTURE_NO_CANON')
    src=b.native_source();p=b.proof('MIRROR');state=ActorActionState(actor_id=aa,ordinal_level=1,available_pa=22,known_action_ids=(b.GO_ACTION,),standard_available=True,reaction_available=True,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(bb,))
    re=None
    if dodge:
        ds=ActorActionState(actor_id=bb,ordinal_level=1,available_pa=22,known_action_ids=(m.DODGE_ACTION,),reaction_available=reaction==1,reaction_trigger_observed='BEFORE-ATTACK',enemy_ids_visible=(aa,))
        re=react_defensively(sn,bb,kind='ESQUIVAR',attack_score=hit+19,announced_before=True,trigger_source='BEFORE-ATTACK',source=m.source_reaction(),state=ds,proofs=(m.proof_reaction(),),strict=True)
    row=apply_source_attack(sn,aa,bb,source=src,state=state,proofs=(p,),attack_die=hit,damage_die=dam,critical_dice=crit,force=13,luta=6,rd=Resistances(general=rd,specific=(),provenance='UNIT_FIXTURE_RD'),reaction_event=re)
    return sn,row,re

def run():
    b.authorization();m.auth()
    s,e,_=sample();record('C01_COMMON_HIT',e['hit'] and e['net']==12 and e['r41_positive_auto_hit'] is False,e)
    s,e,_=sample(hit=1);record('C02_COMMON_MISS',not e['hit'] and e['net']==0,e)
    s,e,_=sample(hit=6,crit=(6,6,5));record('C03_CRIT_WITH_COMMON_HIT',e['hit'] and e['r41_positive_auto_hit'] and e['net']==18,e)
    s,e,_=sample(hit=1,crit=(6,6,5));record('C04_CRIT_CA_INSUFFICIENT',e['roll_score']==20 and e['hit'] and e['net']==18,e)
    s,e,re=sample(hit=1,crit=(6,6,5),dodge=True);record('C05_CRIT_VS_DODGE',e['hit'] and e['net']==18 and re['damage_negated'] and e['numeric_dodge_would_negate'] and s.actors['R41_UNIT_B'].reaction==0,e)
    s,e,_=sample(crit=(6,6,5),reaction=0);record('C06_CRIT_REACTION_UNAVAILABLE',e['hit'] and e['defensive_reaction'] is None,e)
    # One reaction previously used; the next attempted reaction must fail without changing scene.
    s,e,_=sample(crit=(6,6,5),reaction=0)
    state=ActorActionState(actor_id='R41_UNIT_B',ordinal_level=1,available_pa=22,known_action_ids=(m.DODGE_ACTION,),reaction_available=False,reaction_trigger_observed='BEFORE-ATTACK',enemy_ids_visible=('R41_UNIT_A',))
    chk=s.checksum();blocked=False
    try:react_defensively(s,'R41_UNIT_B',kind='ESQUIVAR',attack_score=24,announced_before=True,trigger_source='BEFORE-ATTACK',source=m.source_reaction(),state=state,proofs=(m.proof_reaction(),),strict=True)
    except EffectBlocked as exc:blocked='reaction not available' in str(exc)
    record('C07_CRIT_SECOND_THREAT_NO_SLOT',blocked and chk==s.checksum() and e['net']==18,{'blocked':blocked,'second_attack_net':e['net']})
    s,e,_=sample(crit=(6,5,6),hit=1);record('C08_INVALID_ORDER_NOT_CRITICAL',e['hit'] is False and e['r41_critical_status']=='NONE',e)
    s,e,_=sample(crit=(6,6,5),hit=1);record('C09_ORDER_665_VALID',e['r41_critical_status']=='POSITIVE' and e['net']==18,e)
    s,e,_=sample(crit=(6,6,6),hit=1);record('C10_ORDER_666_VALID',e['r41_critical_status']=='POSITIVE' and e['net']==18,e)
    neg=False
    try:sample(crit=(1,1,1))
    except EffectBlocked as exc:neg='NEGATIVE_CRIT_CONSEQUENCE_UNRESOLVED' in str(exc)
    record('C11_CRITICAL_NEGATIVE_FAIL_CLOSED',neg,{'reason':'Negative critical has no assumed damage/penalty'})
    s,e,_=sample(crit=(6,6,5),hit=1)
    xs=[0.,0.];xt=[1.5,0.];expected=[3.,0.];record('C12_CRIT_NET_POSITIVE_PUSH',e['hit'] and e['net']==18 and [xt[0]+1.5,xt[1]]==expected,{'native_net':e['net'],'before':xt,'after':expected,'geometry':'LAB_DIRECTION_AWAY_NOT_WORLD'})
    s,e,_=sample(crit=(6,6,5),hit=1,rd=30);record('C13_CRIT_FULLY_MITIGATED_NO_PUSH',e['hit'] and e['net']==0 and s.actors['R41_UNIT_B'].hp==38,e)
    s,e,_=sample(crit=(6,6,5),hit=1,defender_hp=10);record('C14_CRIT_KILLS_LOWER_HP_FIXTURE',s.actors['R41_UNIT_B'].hp==0 and e['net']==18,e)
    # A combat scheduler must never give a next turn to an actor killed by damage.
    st=h.make_state(j.initial('A',94208),94208);st['phase']='ACTIVE';st['order']=[h.A,h.B,h.C];st['active']=h.A;st['turn']=0;st['round']=1
    st['actors'][h.B]['resource']['hp']=0;st['actors'][h.B]['resource']['standard']=0;st['actors'][h.B]['resource']['reaction']=0
    st['actors'][h.A]['resource']['standard']=0
    nxt=h.alive_advance(st)
    record('C15_SKIP_KO_IN_SCHEDULER_FIXTURE',nxt['skipped']==[h.B] and nxt['active']==h.C and st['actors'][h.B]['resource']['reaction']==0,{'transition':nxt,'note':'fixture KO, not credited as native kill'})
    db=R/'ledgers'/'R41_FIRST_NATIVE_CRITICAL_SEED_SELECTED_208_SEED94208.sqlite'
    gen=h.make_state(j.initial('A',94208),94208);status=h.replay(db,gen)
    cp=R/'checkpoints'/('CHECKPOINT_'+db.stem+'.sqlite')
    record('C16_NATIVE_CRIT_LEDGER_REPLAY_CHECKPOINT',status['status']=='PASS' and h.replay(cp,gen)['status']=='PASS',{'events':status['events'],'checkpoint':str(cp),'native_generated_crit':True},kind='NATIVE_R18_RNG_READONLY_REPLAY')
    # Reopen already committed/new scenes, NEVER repeat a previously executed command.
    db2=R/'ledgers'/'R41_UNIT_DUPLICATE_CMD_SEED94198.sqlite'
    if not db2.exists():
        db2,g2=h.create(94198,'UNIT_DUPLICATE_CMD')
        j.event_commit(db2,'LAB-CMD-R41-UNIT-DUPLICATE','R41_INITIATIVE',{'kind':'INIT','seed':94198},h.init_runner)
        try:j.event_commit(db2,'LAB-CMD-R41-UNIT-DUPLICATE','R41_INITIATIVE',{'kind':'INIT','seed':94198},h.init_runner)
        except Exception:pass
    con=sqlite3.connect(db2)
    evs=con.execute('SELECT cmd_id FROM events').fetchall();pending=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0];rev=int(con.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0]);con.close()
    record('C17_DUPLICATE_CRITICAL_COMMAND_REJECTS',evs==[('LAB-CMD-R41-UNIT-DUPLICATE',)] and rev==1 and pending==0,{'published_events':rev,'duplicate_no_extra_effect':True},kind='NEW_R18_SANDBOX_IDEMPOTENCY')
    db3=R/'ledgers'/'R41_UNIT_FAIL_AFTER_CALC_SEED94199.sqlite'
    if not db3.exists():
        db3,g3=h.create(94199,'UNIT_FAIL_AFTER_CALC')
        j.event_commit(db3,'LAB-CMD-R41-UNIT-FAIL-INIT','R41_INITIATIVE',{'kind':'INIT','seed':94199},h.init_runner)
        st,hh,rv=h.checked(db3);p=h.payload(st)
        def dying(candidate,payload,seq):
            _=h.do_turn(candidate,payload,seq)
            raise ValueError('INJECTED_AFTER_CALC_BEFORE_COMMIT')
        try:j.event_commit(db3,'LAB-CMD-R41-UNIT-FAIL-ATTACK','R41_TURN',p,dying)
        except Exception:pass
    # No `j.load` allowed when pending; inspect SQLite read-only using raw rows.
    con=sqlite3.connect(f'file:{db3}?mode=ro',uri=True)
    mt=dict(con.execute('SELECT key,value FROM meta'));cnt=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
    intent=con.execute('SELECT cmd_id FROM pending').fetchone();valid=con.execute('PRAGMA integrity_check').fetchone()[0]
    ev_count=con.execute('SELECT COUNT(*) FROM events').fetchone()[0];con.close()
    st=json.loads(mt['state']);active=st['active']
    record('C18_FAIL_AFTER_CALC_PREPUBLICATION',cnt==1 and intent==('LAB-CMD-R41-UNIT-FAIL-ATTACK',) and int(mt['revision'])==1 and ev_count==1 and valid=='ok' and st['actors'][active]['resource']['standard']==1,{'pending':cnt,'events':ev_count,'no_retry':True,'integrity':valid},kind='NEW_R18_SANDBOX_PENDING_FROZEN')
    return {'total':len(O),'pass':sum(v['status']=='PASS' for v in O.values()),'cases':O,'new_synthetic_db':[db2.name,db3.name],'native_replay_db':db.name}
if __name__=='__main__':
 out=run();p=R/'evidence'/'R41_CRITICAL_DIRECTED_18_CASES.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True,default=str)+'\n');print('CASES',out['pass'],'/',out['total'])
