from __future__ import annotations
import json,sys,copy,sqlite3
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r41_long_duel_core as g
j=g.j

def observe(seed,horizon=150):
 db,gen=g.create(seed,'OBSERVE_CRIT_VS_EVERY_DODGE')
 g.commit(db,'R41_LONG_INITIATIVE',{'kind':'INIT','seed':seed},g.init_runner)
 reason=None
 for _ in range(2*horizon+4):
  st,hd,rev=g.checked(db)
  if st['phase']!='ACTIVE':reason='LEGITIMATE_HP_ELIMINATION';break
  if st['round']>horizon:reason='HORIZON';break
  try:payload=g.payload(st)
  except g.Hold as e:
   if 'NEGATIVE_CRIT_UNRESOLVED' in str(e):reason='NEGATIVE_CRITICAL_RULE_NOT_DETERMINED';break
   raise
  g.commit(db,'R41_LONG_TURN',payload,g.do_turn)
 else:reason='UNEXPECTED_LOOP_LIMIT';raise ValueError(reason)
 st,hd,rev=g.checked(db)
 if reason!='LEGITIMATE_HP_ELIMINATION':
  # Retain native phase ACTIVE in SQLite. Stop of scientific OBSERVATION is outside
  # the RPG event history, not a synthetic turn or a fictitious draw.
  assert st['phase']=='ACTIVE' and st['winner'] is None
 rep=g.replay(db,gen);check=g.backup(db,gen)
 hist=j.history(db)['events'];turns=[r for r in hist if r['kind']=='R41_LONG_TURN'];crits=[r for r in turns if r['detail']['RNG']['critical_positive']]
 out={'seed':seed,'endpoint':reason,'official_winner':None,'lab_winner':st['winner'] if reason=='LEGITIMATE_HP_ELIMINATION' else None,'observed_round':st['round'],'completed_attacks':len(turns),'positive_crits':len(crits),'positive_critical_receipt_events':[r['seq'] for r in crits],'last_state':{'phase':st['phase'],'active':st['active'],'hp':{a:v['resource']['hp'] for a,v in st['actors'].items()},'reaction':{a:v['resource']['reaction'] for a,v in st['actors'].items()},'positions':st['r40']['positions'],'winner':st['winner'],'round':st['round']},'ledger':{'name':db.name,'sha256':g.sha_file(db),'events':rev,'head':hd,'pending':0},'replay':rep,'checkpoint':check,'counts':{'attacks':st['r40']['attacks'],'pushes':st['r40']['pushes'],'movements':st['r40']['movements'],'announced_reactions':st['r40']['reaction_announcements']},'censored':reason!='LEGITIMATE_HP_ELIMINATION','source_complete_initiative':False,'full_fight_real_source_credited':False}
 p=R/'evidence'/('R41_LONG_DUEL_SEED'+str(seed)+'.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:out[k] for k in ('seed','endpoint','observed_round','completed_attacks','positive_crits','lab_winner','censored')},ensure_ascii=False))
 return out
if __name__=='__main__':
 a=[]
 for seed in (94501,94502,94503,94504):a.append(observe(seed))
 (R/'evidence'/'R41_LONG_DUEL_SUMMARY.json').write_text(json.dumps({'plan':'R41_LONG_DUEL_PREREGISTERED.json','samples':len(a),'results':a},indent=2,ensure_ascii=False)+'\n')
