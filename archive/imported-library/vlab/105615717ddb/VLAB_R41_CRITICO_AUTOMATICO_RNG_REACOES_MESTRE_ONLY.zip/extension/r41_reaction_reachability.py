"""Reachability and fail-closed concurrency triage, NOT a combat/reaction resolver.
Rules physically read: Combat System current; Mestre R34 forbids AoO from forced push.
"""
from __future__ import annotations
import math,json
from pathlib import Path
R=Path('/mnt/data/vlab_r41/working')

def dist(p,q):return math.dist(p,q)
def triage():
    m=(0.,0.);e1=(1.5,0.);e2=(0.,1.5);dest=(-1.5,-1.5)
    before={i:dist(m,p)<=1.5 for i,p in [('E1',e1),('E2',e2)]}
    after={i:dist(dest,p)>1.5 for i,p in [('E1',e1),('E2',e2)]}
    legal_both=[i for i in ('E1','E2') if before[i] and after[i]]
    assert legal_both==['E1','E2']
    # Engine preflight cannot order two distinct AoOs under the current authority;
    # no reaction is spent and no movement/HP changed, before any pending intent.
    resources={'E1':1,'E2':1,'M':1};snapshot=resources.copy();p0=m
    blocked='MULTIPLE_ELIGIBLE_AOO_ORDER_NOT_AUTHORIZED' if len(legal_both)>1 else None
    assert resources==snapshot and m==p0
    # Safe retreat from one enemy spends STANDARD, so E2 still has one legal trigger.
    safe={'excluded':'E1','eligible':['E2'],'cost_standard':1,'movement_cost':1}
    # Enemy A attacks B and misses CA; B may Counter. The counter itself is an
    # attack and can create a new trigger for A when A has a reaction left.
    generic_counter={'first_attack_score':20,'defender_CA':20,'counter_legal_trigger':True,
                     'counter_attack_default_dice':'Bronze normal 1d6 + attribute + Luta + VANTAGEM(2dice,+2)',
                     'counter_attack_source_luta':'UNRESOLVED_IN_GOAT_SHEET',
                     'nested_reaction_priority':'UNRESOLVED'}
    cases=[
      {'case':'MOVE_VOLUNTARY_EXITS_TWO_THREATS','classification':'REACHABLE_PRECEDENCE_PENDING','sources':'Sistema de Combate AoO','geometry':{'mover_before':m,'mover_after':dest,'threats':{'E1':e1,'E2':e2}},'eligible_actors':legal_both,'block':blocked,'effects_published':0},
      {'case':'SAFE_RETREAT_ONE_THREAT','classification':'REACHABLE_SERIAL_SINGLE','source':'Sistema de Combate Afastar-se com segurança','consequence':safe},
      {'case':'FORCED_PUSH_TRIGGERS_AOO','classification':'ILLEGAL_CURRENT_R34_RULE','source':'Mestre R34 P4 forced push no AoO','effects_published':0},
      {'case':'COUNTER_AFTER_ATTACK_FAILS_CA','classification':'REACHABLE_TRIGGER_BUT_ATTACK_SOURCE_INCOMPLETE','source':'Sistema de Combate Contra-atacar','contract':generic_counter},
      {'case':'COUNTER_COUNTER_NESTED','classification':'REACHABLE_GENERICALLY_PRECEDENCE_PENDING_SOURCE_BLOCKED','source':'Sistema de Combate Reação+Contra-atacar','note':'New normal attack from counter could fail CA, but Goat has no authorized general Luta or priority sequence; no actual counter executed'},
      {'case':'ESQUIVAR_AND_DEFENDER_BY_SAME_ACTOR_ON_ONE_ATTACK','classification':'ILLEGAL_DOUBLE_SLOT','source':'Sistema de Combate reaction1 per actor, Mestre R26','note':'Exactly one voluntary reaction consumes slot; cannot stack both'},
      {'case':'TWO_INCOMING_SERIAL_ATTEMPTS_WITHOUT_REFRESH','classification':'REACHABLE_AND_NATIVE_PASS_R39B_R40','source':'R26 renewal and R39B,R40 native evidence','note':'Second attempt rejected without slot; not simultaneous collision'},
      {'case':'MULTIPLE_SIMULTANEOUS_MAGIC_DEFENSES','classification':'NOT_DETERMINABLE_SOURCE_INCOMPLETE','source':'Sistema de Magia/CD/Refletir, not admitted in goat'}
    ]
    assert [c['classification'] for c in cases].count('REACHABLE_PRECEDENCE_PENDING')==1
    return {'operation':'OP-VLAB-FUSION-SANDBOX-01','authority':'NOTION_SYSTEM_COMBAT+MASTER_R34_R26','test_kind':'REACHABILITY_GATES_ONLY_NONCOMBAT','scenarios':cases,'positive_geometry_evidence':len(legal_both),'fail_closed_concurrent_aoo':True,'double_slot_consumed':False,'effects_published':0,'first_normative_question':'When ONE voluntary move triggers two or more legal Attacks of Opportunity from DISTINCT opponents, what determines resolution order, and when does movement stop if the first attack kills/interrupts the mover?','do_not_ask_again':'crit automatic, dodge reflex6, forced push AoO exclusion, tie defender'}
if __name__=='__main__':
 x=triage();p=R/'evidence'/'R41_REACTION_REACHABILITY_TRIAGE.json';p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print('CLASSIFIED',len(x['scenarios']),'CONCURRENT_REACHABLE',x['positive_geometry_evidence'])
