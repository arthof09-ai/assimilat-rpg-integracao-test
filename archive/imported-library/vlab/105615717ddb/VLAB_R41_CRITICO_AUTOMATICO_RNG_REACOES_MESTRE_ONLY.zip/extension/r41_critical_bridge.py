"""R41 additive adapter: native v0.8.1 source/menu/RD/event primitives, explicit critical-hit override.
Historical v0.8.1 modules are imported unchanged. This is experimental, NOT canon.
Positive critical detection from ordered 3d6 is a separate boolean, never fake attack score.
"""
from __future__ import annotations
from vlab_effects_v08 import Scene,EffectBlocked,apply_weapon_attack,_require_option
from vlab_rd_v08 import DamageComponent,mitigate

def ordered_critical(crit,margin=0):
    if type(margin) is not int or not 0<=margin<=4:raise EffectBlocked('UNAUTHORIZED_CRITICAL_MARGIN')
    if not isinstance(crit,(tuple,list)) or len(crit)!=3 or any(type(x) is not int or x not in range(1,7) for x in crit):raise EffectBlocked('CRIT_DICE_INVALID')
    positive=crit[0]==crit[1]==6 and crit[2]>=5-margin
    negative=crit[0]==crit[1]==1 and crit[2]<=2
    return 'POSITIVE' if positive else 'NEGATIVE' if negative else 'NONE'

def apply_source_attack(scene:Scene,attacker_id,defender_id,*,source,state,proofs,
                        attack_die,damage_die,critical_dice,force,luta,rd,
                        reaction_event=None,strict=True,damage_tag='impacto',critical_margin=0):
    if type(attack_die) is not int or not 1<=attack_die<=6:raise EffectBlocked('HIT_DIE_INVALID')
    if type(damage_die) is not int or not 1<=damage_die<=6:raise EffectBlocked('DAMAGE_DIE_INVALID')
    if (force,luta)!=(13,6):raise EffectBlocked('NOT_THE_APPROVED_GOAT_INVESTIDA_BONUS')
    kind=ordered_critical(critical_dice,margin=critical_margin)
    if kind=='NEGATIVE':raise EffectBlocked('NEGATIVE_CRIT_CONSEQUENCE_UNRESOLVED')
    score=attack_die+force+luta
    raw=damage_die+force+(6 if kind=='POSITIVE' else 0)
    if scene.actors[attacker_id].standard!=1:raise EffectBlocked('STANDARD_SPENT')
    if scene.actors[defender_id].hp<=0 or scene.actors[attacker_id].hp<=0:raise EffectBlocked('KO_SOURCE_OR_TARGET')
    if source.kind!='attack' or source.economy!='STANDARD':raise EffectBlocked('NOT_STANDARD_ATTACK')
    _require_option(scene,attacker_id,source,state,proofs,strict=strict,target=defender_id)
    if reaction_event is not None:
        if (not scene.events or scene.events[-1]!=reaction_event or reaction_event.get('by')!=defender_id or
            reaction_event.get('attack_score')!=score or reaction_event.get('seq')!=len(scene.events) or
            reaction_event.get('action') not in ('ESQUIVAR','DEFENDER')):
            raise EffectBlocked('REACTION_NOT_IMMEDIATE_OR_UNLINKED')
    if kind!='POSITIVE':
        # Ordinary events take the original native attack path without modification.
        row=apply_weapon_attack(scene,attacker_id,defender_id,source=source,state=state,proofs=proofs,
            roll_score=score,damage=raw,damage_tag=damage_tag,rd=rd,strict=strict,defense_event=reaction_event)
        row.update({'r41_critical_status':kind,'r41_hit_reason':'NORMAL_ROLL' if row['hit'] else 'NORMAL_MISS',
                    'r41_critical_dice':list(critical_dice),'r41_hit_die':attack_die,'r41_damage_die':damage_die,
                    'r41_damage_formula':'1d6+FOR13','r41_max_dice_added':0,'r41_positive_auto_hit':False})
        return row
    # The historical low-level API has no `critical_hit` parameter. Use its catalog
    # and damage primitives, but explicitly override numeric hit selection IN THE EXTENSION.
    # The reaction remains spent/recorded, yet numeric dodge cannot nullify a positive crit.
    d=scene.actors[defender_id];a=scene.actors[attacker_id]
    if reaction_event is not None and reaction_event['action']!='ESQUIVAR':
        raise EffectBlocked('CRITICAL_VS_DEFENDER_DISTINCT_MITIGATION_NOT_YET_VERIFIED')
    before=d.hp
    mitigated=mitigate((DamageComponent(raw,damage_tag,source.action_id),),rd)
    a.standard=0;d.hp=max(0,d.hp-mitigated.effective)
    return scene.record({'action':'weapon_attack','from':attacker_id,'to':defender_id,
        'roll_score':score,'ca_exact':str(d.ca),'hit':True,'r41_positive_auto_hit':True,
        'r41_hit_reason':'VALID_POSITIVE_CRITICAL_AUTO_HIT',
        'r41_critical_status':'POSITIVE','r41_critical_dice':list(critical_dice),
        'r41_hit_die':attack_die,'r41_damage_die':damage_die,
        'r41_damage_formula':'1d6+FOR13+MAX(1d6)','r41_max_dice_added':6,
        'defensive_reaction':reaction_event['action'] if reaction_event else None,
        'defense_negated':False,'numeric_dodge_would_negate':bool(reaction_event and reaction_event['damage_negated']),
        'raw':raw,'type':damage_tag,'rd_applied':mitigated.applicable_rd,
        'net':mitigated.effective,'before_hp':before,'after_hp':d.hp,
        'official_death_derived':False,'status':'LAB-STOP-HP0-NOT-CANON'})
