import zipfile,os,pathlib,shutil
R=pathlib.Path('/mnt/data/vlab_r41/working');runtime=R/'runtime_copy';runtime.mkdir(exist_ok=True)
for a,b in [('r36/run_r35_native.py','run_r35_native.py'),('r36/run_r36_dodge.py','run_r36_dodge.py')]:shutil.copy2(R/a,runtime/b)
for folder in ('authority','extension'):
 (runtime/folder).mkdir(exist_ok=True)
for p in (R/'r36/authority').glob('*.json'):shutil.copy2(p,runtime/'authority'/p.name)
shutil.copy2(R/'r35/extension/vlab_r31_real_source_gateway.py',runtime/'extension/vlab_r31_real_source_gateway.py')
with zipfile.ZipFile('/mnt/data/vlab_r41/input/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip') as z:
 for n in z.namelist():
  if n.startswith('fusion_stage12/') and n.endswith('.py'):
   p=runtime/'r27'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
  elif n.startswith('working/historical_v081_verified_original/comestre_vlab/') and n.endswith('.py'):
   p=runtime/'r27'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
  elif n.startswith('fusion_stage12/') and n.endswith('.json'):
   p=runtime/'r27'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
for p in (R/'runtime').glob('*.py'):
 shutil.copy2(p,runtime/p.name)
# shadow direct historical v0.8.1 at runtime root for normal package use; historical files remain unchanged
print('runtime files',len(list(runtime.rglob('*'))))
