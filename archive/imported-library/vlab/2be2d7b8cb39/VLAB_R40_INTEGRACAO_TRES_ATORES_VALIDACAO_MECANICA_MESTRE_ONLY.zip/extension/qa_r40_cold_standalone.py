"""Final cold audit only. Imports standalone oracle, never combat engine."""
import json,hashlib,sys,sqlite3,zipfile,tempfile,math
from pathlib import Path
from verify_r40_mechanics_standalone import inspect,die,H
ROOT=Path('/mnt/data/vlab_r40')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def count(db,sql):
 c=sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True)
 try:return c.execute(sql).fetchone()[0]
 finally:c.close()
def main():
 cases=[]
 for tag,seed in [('FIRST_ELIGIBLE_ACB',91001),('FIRST_ELIGIBLE_UNTIED',91002)]:
  base='R40_'+tag+'_SEED'+str(seed)
  db=ROOT/'ledgers'/(base+'.sqlite');ck=ROOT/'checkpoints'/('CHECKPOINT_'+base+'.sqlite');rec=json.loads((ROOT/'evidence'/(base+'_RECEIPT.json')).read_text())
  r=inspect(db);b=inspect(ck)
  assert r==b and r['events']==rec['ledger']['revision'] and rec['ledger']['head']==r['head']
  assert sha(db)==rec['ledger']['sha256'] and sha(ck)==rec['checkpoint']['sha256']
  cases.append({'seed':seed,'status':'PASS','ledger':db.name,'checkpoint':ck.name,'events':r['events'],'attacks':r['attacks'],'reactions':r['reactions'],'rejects':r['second_reactions_rejected'],'pushes':r['pushes'],'movement_actions':r['movement_actions'],'eliminations':r['eliminations'],'winner':r['winner'],'head':r['head']})
 assert sum(r['events'] for r in cases)==44 and sum(r['attacks'] for r in cases)==42
 fault=ROOT/'evidence/R40_FAULT_PENDING_PORTABLE_FROZEN.sqlite';assert count(fault,'select count(*) from pending')==1 and count(fault,'select count(*) from events')==1
 pre=ROOT/'ledgers/R40_INVALID_CMD_BEFORE_RESERVATION_SEED91013.sqlite';assert count(pre,'select count(*) from pending')==0 and count(pre,'select count(*) from events')==0
 stat=json.loads((ROOT/'evidence/R40_CRITICAL_HOLDOUT_RESULTS.json').read_text());proto=json.loads((ROOT/'evidence/R40_CRITICAL_HOLDOUT_PREREGISTERED.json').read_text())
 assert stat['protocol_sha256']==H(proto)
 assert len(stat['individual_trials'])==1200 and sum(stat['observed'].values())==1200
 obs={'POSITIVE':0,'NEGATIVE':0,'OTHER':0}
 for row in stat['individual_trials']:
  seed=row['seed'];v=[die(seed,1,'R40-CRIT-LAB_R40_GOAT_A-'+str(i)) for i in (1,2,3)]
  kind='POSITIVE' if v[:2]==[6,6] and v[2] in (5,6) else 'NEGATIVE' if v[:2]==[1,1] and v[2] in (1,2) else 'OTHER'
  assert v==row['dice'] and kind==row['kind']
  obs[kind]+=1
 assert obs==stat['observed']
 q=json.loads((ROOT/'evidence/R40_MECHANICAL_MUTATION_MATRIX.json').read_text());assert q['pass_numerator']==q['denominator']==8
 original={'R39':{'path':'/mnt/data/VLAB_R39_GATES_REACAO_SCHEDULER_RNG_MESTRE_ONLY.zip','sha':'2a2a5f6774da7d917d61a66b1cdb206de5195e2665c8807bf5c8c4a46ca09892'},'R39B':{'path':'/mnt/data/VLAB_R39B_ERRATA_FONTE_INVESTIDA_REACAO_MESTRE_ONLY.zip','sha':'3333d215042d0de9ec92a1d10d125f2417864cd5dc474e5f62b9090bf3552166'}}
 for name,obj in original.items():assert sha(obj['path'])==obj['sha']
 # RECHECK THE ORIGINAL R39 SOURCE-INVALID ACTION from original ZIP, not from cached report.
 with zipfile.ZipFile(original['R39']['path']) as z:
  with tempfile.TemporaryDirectory() as d:
   for fname in z.namelist():
    if fname.startswith('ledgers/R39_REACTION_SEQUENTIAL.sqlite'):z.extract(fname,d)
   co=sqlite3.connect(f'file:{Path(d,"ledgers/R39_REACTION_SEQUENTIAL.sqlite").resolve()}?mode=ro',uri=True)
   try:
    row=json.loads(co.execute('select row_json from events where seq=2').fetchone()[0]);e=row['detail']['native_events'][0]
   finally:co.close()
   assert e['raw']==20 and e['net']==15 and e['after_hp']==23 and e['before_hp']==38
   assert not (14<=e['raw']<=19)
 findings={'schema':'R40_COLD_INDEPENDENT_FOUR_LAYER_AUDIT_V1','engine_imported':False,'cases':cases,'causal_structural_mechanical_independent':'PASS_BOTH_SCENES_AND_CHECKPOINTS','new_ledger_events':44,'new_native_attacks':42,'reaction_announcements':sum(x['reactions'] for x in cases),'second_reactions_rejected':sum(x['rejects'] for x in cases),'new_native_deaths':sum(len(x['eliminations']) for x in cases),'critical_holdout':{'N':1200,'counts':obs,'chi2':stat['chi_square'],'p':stat['p_value'],'alpha':0.01,'decision':stat['decision'],'not_canonical':True},'negative_regression_old_R39_invalid_20':'REJECTED_MECHANICALLY','mutation_matrix':{'pass':8,'total':8},'atomicity_failure_pending_frozen':1,'pre_reservation_reject_no_events':True,'historical_pins_verified':{k:v['sha'] for k,v in original.items()},'terminal_contracts_certified':0,'official_effects':0}
 path=ROOT/'evidence/R40_COLD_INDEPENDENT_AUDIT.json'
 with path.open('x',encoding='utf8') as f:json.dump(findings,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps({k:v for k,v in findings.items() if k not in ('cases','historical_pins_verified')},indent=2))

if __name__=='__main__':main()
