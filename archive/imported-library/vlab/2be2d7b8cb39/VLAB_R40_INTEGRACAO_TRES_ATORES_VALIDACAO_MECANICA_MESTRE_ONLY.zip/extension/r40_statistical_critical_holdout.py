"""Pre-registered independent critical sequence analysis; does not import VLAB engines."""
import json,math,collections
from pathlib import Path
from verify_r40_mechanics_standalone import die,H
ROOT=Path('/mnt/data/vlab_r40');proto=json.loads((ROOT/'evidence/R40_CRITICAL_HOLDOUT_PREREGISTERED.json').read_text())
assert proto['seed_range_inclusive']==[92001,93200]
c=collections.Counter();digest_seq=[]
for seed in range(92001,93201):
 d=tuple(die(seed,1,'R40-CRIT-LAB_R40_GOAT_A-'+str(i)) for i in range(1,4))
 label='POSITIVE' if d[:2]==(6,6) and d[2] in (5,6) else 'NEGATIVE' if d[:2]==(1,1) and d[2] in (1,2) else 'OTHER'
 c[label]+=1;digest_seq.append({'seed':seed,'dice':list(d),'kind':label})
N=sum(c.values());exp={'POSITIVE':N/108,'NEGATIVE':N/108,'OTHER':N*106/108}
chi=sum((c[k]-exp[k])**2/exp[k] for k in exp)
# chi-square df=2 survival exactly exp(-chi-square/2)
p=math.exp(-chi/2)
assert N==1200
exact={'POSITIVE':0,'NEGATIVE':0,'OTHER':0}
for a in range(1,7):
 for b in range(1,7):
  for d in range(1,7):
   k='POSITIVE' if a==b==6 and d in (5,6) else 'NEGATIVE' if a==b==1 and d in (1,2) else 'OTHER'
   exact[k]+=1
assert exact=={'POSITIVE':2,'NEGATIVE':2,'OTHER':212}
results={'protocol_sha256':H(proto),'n':N,'observed':dict(c),'expected':exp,'chi_square':chi,'df':2,'p_value':p,'alpha':0.01,'decision':'FAIL_TO_REJECT_UNIFORM_TRIPLE_H0' if p>=0.01 else 'REJECT_H0','scope':'EXPERIMENTAL_DETERMINISTIC_RNG_NOT_OFFICIAL_OR_PROOF_OF_UNIFORMITY','exact_sequence_distribution_per_216':exact,'excluded_false_positive_656':True,'seed_range':[92001,93200],'draws_total':N*3,'tape_sha256':H(digest_seq),'individual_trials':digest_seq}
with (ROOT/'evidence/R40_CRITICAL_HOLDOUT_RESULTS.json').open('x') as f:json.dump(results,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in results.items() if k!='individual_trials'},indent=2))
