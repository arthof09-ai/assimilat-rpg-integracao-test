"""R40 differential adversary: rehashed ledgers pass native R18 structure but fail independent rule oracle.
No copies persist: all 8 mutated databases live in private TemporaryDirectory and are destroyed.
"""
import copy,json,sqlite3,tempfile
from pathlib import Path
import r40_integrated_three_actors as n
import verify_r40_mechanics_standalone as v
base=n.R/'ledgers/R40_FIRST_ELIGIBLE_ACB_SEED91001.sqlite'

def mutate(name,fn):
 with tempfile.TemporaryDirectory(prefix='r40-mut-') as temp:
  db=Path(temp)/'mut.sqlite';s=sqlite3.connect(base);d=sqlite3.connect(db)
  try:s.backup(d)
  finally:s.close();d.close()
  co=sqlite3.connect(db)
  try:
   co.execute('BEGIN IMMEDIATE');events=co.execute('SELECT seq,row_json FROM events ORDER BY seq').fetchall()
   prev=co.execute("SELECT value FROM meta WHERE key='genesis'").fetchone()[0]
   for seq,text in events:
    row=json.loads(text)
    if seq==3:fn(row)
    row['prev']=prev;new=v.J(row);h=v.H(row)
    co.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(prev,new,h,seq));prev=h
   co.execute("UPDATE meta SET value=? WHERE key='head'",(prev,));co.commit()
  finally:co.close()
  structurally=n.j.load(db)[2]==19
  reason=None
  try:v.inspect(db)
  except v.AuditFail as exc:reason=str(exc)
  assert structurally and reason is not None,(name,structurally,reason)
  return {'case':name,'R18_structural':'PASS_REHASHED','independent_mechanics':'REJECTED_AS_REQUIRED','reason':reason}

cases=[
 ('d6_seven', lambda r: [r['detail']['RNG'].__setitem__('damage_die',7),r['payload']['tape'].__setitem__('damage_die',7),r['detail']['RNG'].__setitem__('damage_total',20),r['payload']['tape'].__setitem__('damage_total',20)]),
 ('attack_plus_1',lambda r:[r['detail']['RNG'].__setitem__('attack_total',r['detail']['RNG']['attack_total']+1),r['payload']['tape'].__setitem__('attack_total',r['payload']['tape']['attack_total']+1)]),
 ('unauthorized_luta_plus_1',lambda r:[r['detail']['RNG'].__setitem__('luta',7),r['payload']['tape'].__setitem__('luta',7)]),
 ('wrong_rd',lambda r:r['detail']['native_attack'].__setitem__('rd_applied',4)),
 ('wrong_net_damage',lambda r:r['detail']['native_attack'].__setitem__('net',13)),
 ('wrong_hp',lambda r:r['detail']['native_attack'].__setitem__('after_hp',23)),
 ('wrong_position',lambda r:r['detail']['push'].__setitem__('to',[99.,99.])),
 ('unauthorized_actor',lambda r:[r['detail'].__setitem__('actor',n.B),r['payload'].__setitem__('actor',n.B)])
]
result={'schema':'R40_MUTATION_MATRIX_SOURCE_IMPOSSIBLE_V1','scopes':'TEMPORARY_CLONES_ONLY_NO_HISTORICAL_WRITES','original_sha256_before':n.sha_file(base),'cases':[mutate(name,fn) for name,fn in cases]}
result['original_sha256_after']=n.sha_file(base);assert result['original_sha256_before']==result['original_sha256_after']
result['pass_numerator']=len(result['cases']);result['denominator']=len(cases)
n.dump('evidence/R40_MECHANICAL_MUTATION_MATRIX.json',result)
print(json.dumps({'pass':result['pass_numerator'],'total':result['denominator'],'tests':[{'case':x['case'],'reason':x['reason']} for x in result['cases']]},indent=2))
