"""R40 new controlled fault and tamper fixtures. Preserves real terminal DBs read-only."""
from __future__ import annotations
import sys,json,copy,sqlite3,hashlib,tempfile
from pathlib import Path
import r40_integrated_three_actors as core
import verify_r40_mechanics_standalone as v
R=core.R

def raw(db):
 with sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True) as c:
  meta=dict(c.execute('SELECT key,value FROM meta'))
  return {'meta':meta,'events':c.execute('SELECT COUNT(*) FROM events').fetchone()[0], 'pending':c.execute('SELECT COUNT(*) FROM pending').fetchone()[0], 'integrity':c.execute('PRAGMA integrity_check').fetchone()[0]}

def atomicity_fault():
 db,gen=core.create(91011,'CONTROLLED_FAULT_NEW_SCENE')
 core.commit(db,'R40_INITIATIVE',{'kind':'INIT','seed':91011},core.init_runner)
 st,h,rev=core.checked(db);before=copy.deepcopy(st)
 p=core.payload(st);orig=raw(db)
 def runner(candidate,payload,seq):
  _=core.do_turn(candidate,payload,seq)
  raise RuntimeError('R40_INJECTED_AFTER_NATIVE_BEFORE_COMMIT')
 err=''
 try:core.j.event_commit(db,'LAB-CMD-R40-CONTROLLED-FAULT-91011','R40_TURN',p,runner)
 except core.j.LabHold as exc:err=str(exc)
 after=raw(db)
 assert 'UNKNOWN_EFFECT_PENDENTE' in err and after['pending']==1 and after['events']==orig['events']==1 and after['meta']['head']==orig['meta']['head'] and after['meta']['state']==orig['meta']['state'] and after['integrity']=='ok'
 try:core.j.load(db)
 except core.j.LabHold as exc:assert 'UNKNOWN_EFFECT' in str(exc)
 else:raise AssertionError('PENDING_UNKNOWN_NOT_REJECTED')
 return {'scene':db.name,'status':'PASS_UNKNOWN_EFFECT_FROZEN','replay_allowed':False,'after_native_before_commit':True,'published_events_after_fail':0,'pending':1,'hp_pa_standard_movement_reaction_unchanged':True,'head_unchanged':True,'original_revision':1,'new_revision':1,'failure':err,'sha256':core.sha_file(db)}

def preflight_reject():
 db,gen=core.create(91013,'INVALID_CMD_BEFORE_RESERVATION')
 before=raw(db);err=''
 try:core.j.event_commit(db,'ILLEGAL_ID','INVALID',{},lambda *_: {})
 except core.j.LabHold as exc:err=str(exc)
 after=raw(db)
 assert 'CMD ID INVÁLIDO' in err and after==before and after['pending']==0 and after['events']==0
 return {'scene':db.name,'status':'PASS_FAIL_CLOSED_PRE_RESERVATION','revision':0,'events':0,'pending':0,'integrity':'ok','sha256':core.sha_file(db)}

def structural_valid_mechanically_false_fixture():
 original=R/'ledgers/R40_FIRST_ELIGIBLE_ACB_SEED91001.sqlite'
 target=R/'evidence/R40_TAMPERED_RECHAINED_MECHANICALLY_IMPOSSIBLE_TEST_ONLY.sqlite'
 if target.exists():raise RuntimeError('TAMPER_TEST_ALREADY_EXISTS')
 src=sqlite3.connect(original);dst=sqlite3.connect(target)
 try:src.backup(dst)
 finally:src.close();dst.close()
 co=sqlite3.connect(target)
 try:
  co.execute('BEGIN IMMEDIATE');rows=co.execute('SELECT seq,row_json FROM events ORDER BY seq').fetchall()
  previous=co.execute("SELECT value FROM meta WHERE key='genesis'").fetchone()[0]
  for seq,s in rows:
   item=json.loads(s)
   if seq==3:
    # R39 defect replay: 1d6+13 impossible raw 20, but cryptographic chain is re-signed.
    item['payload']['tape']['damage_die']=7
    item['payload']['tape']['damage_total']=20
    item['detail']['RNG']['damage_die']=7
    item['detail']['RNG']['damage_total']=20
    item['detail']['native_attack']['raw']=20
    item['detail']['native_attack']['net']=15
    item['detail']['native_attack']['after_hp']=23
    # leave final state and after_sha unchanged: a log can be cryptographically self-consistent while mechanically false
   item['prev']=previous
   d=v.J(item);h=v.H(item)
   co.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(previous,d,h,seq));previous=h
  co.execute("UPDATE meta SET value=? WHERE key='head'",(previous,));co.commit()
 finally:co.close()
 # Structural original R18 checks continue to pass by construction (all hash fields chained).
 st,head,revision=core.j.load(target)
 assert revision==19 and head==previous
 er=''
 try:v.inspect(target)
 except v.AuditFail as exc:er=str(exc)
 assert er in ('RNG_TAPE_NOT_GENERATED','DICE_OUTSIDE_1_6','IMPOSSIBLE_DAMAGE_OR_ATTACK','MECHANICAL_DAMAGE_RD_OR_HP_FALSE'),er
 return {'scene':target.name,'status':'PASS_REJECT_MECHANICALLY_IMPOSSIBLE_WITH_VALID_REHASHED_SQLITE','structural_R18_load':'PASS','mechanical_oracle':'FAIL_CORRECTLY','detected':er,'domain_violation':'damage_die=7 and damage_total=20 where 1d6+13 maximum19','fixture_is_synthetic_and_NOT_combat':True,'sha256':core.sha_file(target)}

def guard_matrix():
 original=R/'ledgers/R40_FIRST_ELIGIBLE_ACB_SEED91001.sqlite';receipt=[]
 state,head,rev=core.checked(original)
 try:core.payload(copy.deepcopy(state))
 except core.Hold as ex:receipt.append({'test':'ACTION_AFTER_COMPLETE','rejected':True,'exception':str(ex)})
 else:raise RuntimeError('POST_WIN_ACTION_POSSIBLE')
 # Replay a CLONE of the first valid real turn; then try a second attack by A,
 # which has already consumed its standard. Never submit this to the official journal.
 genesis=json.load(open(R/'evidence/R40_FIRST_ELIGIBLE_ACB_SEED91001_BEFORE.json'))['state']
 events=core.j.history(original)['events'];shadow=copy.deepcopy(genesis)
 core.init_runner(shadow,events[0]['payload'],1)
 core.do_turn(shadow,events[1]['payload'],2)
 assert shadow['actors'][core.A]['resource']['standard']==0 and shadow['actors'][core.B]['resource']['hp']==38
 shadow['active']=core.A
 pp={'kind':'TURN','actor':core.A,'target':core.B,'round':shadow['round'],'tape':core.tape(shadow,core.A)}
 snap=core.j.sha(shadow)
 try:core.do_turn(shadow,pp,3)
 except core.Hold as ex:
  assert 'STANDARD_UNAVAILABLE' in str(ex),str(ex)
  receipt.append({'test':'SECOND_STANDARD_ACTION_WITH_NEW_ID_BEFORE_RESERVATION','rejected':True,'exception':str(ex),'unchanged':core.j.sha(shadow)==snap})
 else:raise RuntimeError('DUPLICATE_STANDARD_ALLOWED')
 # Existing command ID is rejected by R18 without durable intent on portable COPY.
 import tempfile
 with tempfile.TemporaryDirectory() as temp:
  z=Path(temp)/'repeated.sqlite';s=sqlite3.connect(original);t=sqlite3.connect(z)
  try:s.backup(t)
  finally:s.close();t.close()
  prior=raw(z);same=events[0]['cmd_id'];message=''
  try:core.j.event_commit(z,same,'R40_INITIATIVE',events[0]['payload'],core.init_runner)
  except core.j.LabHold as ex:message=str(ex)
  after=raw(z)
  assert message=='DUPLICATE COMMAND REJECTED' and after==prior
  receipt.append({'test':'SAME_COMMAND_ID_ON_DISPOSABLE_CHECKPOINT','rejected':True,'unchanged':True,'message':message})
 # All-zero is technically handled, but impossible by single-target normal attack
 full=copy.deepcopy(state);full['phase']='ACTIVE';full['active']=core.C
 for aid in core.IDS:full['actors'][aid]['resource']['hp']=0
 x=core.alive_advance(full)
 assert x['completed'] is True and x['winner'] is None and full['phase']=='COMPLETE_LAB_R40_NO_SURVIVORS'
 receipt.append({'test':'ALL_ZERO_FIXTURE_ONLY','result':'SAFE_TERMINAL_NO_WINNER_NOT_NATIVE_COMBAT'})
 assert all(x['rejected'] for x in receipt[:3])
 return {'checks':receipt,'source_db_sha_after':core.sha_file(original),'status':'PASS','all_zero_scope':'SYNTHETIC_COMPLEMENT_ONLY'}

def main():
 # Earlier independent tests were executed once and their frozen ledgers are never retried.
 faildb=R/'ledgers/R40_CONTROLLED_FAULT_NEW_SCENE_SEED91011.sqlite'
 bad=R/'ledgers/R40_INVALID_CMD_BEFORE_RESERVATION_SEED91013.sqlite'
 mutated=R/'evidence/R40_TAMPERED_RECHAINED_MECHANICALLY_IMPOSSIBLE_TEST_ONLY.sqlite'
 f=raw(faildb);p=raw(bad)
 assert f['pending']==1 and f['events']==1 and f['meta']['revision']=='1' and p['pending']==0 and p['events']==0
 m=core.j.load(mutated);assert m[2]==19
 reason=''
 try:v.inspect(mutated)
 except v.AuditFail as ex:reason=str(ex)
 assert reason=='RNG_TAPE_NOT_GENERATED'
 results={'schema':'R40_NEGATIVE_ADVERSARIAL_V1',
  'preflight_no_intent':{'status':'PASS_FAIL_CLOSED_PRE_RESERVATION','scene':bad.name,'revision':0,'events':0,'pending':0,'integrity':'ok','sha256':core.sha_file(bad)},
  'failure_after_native_before_commit':{'status':'PASS_UNKNOWN_EFFECT_FROZEN','scene':faildb.name,'replay_allowed':False,'published_events_after_fail':0,'pending':1,'hp_pa_standard_movement_reaction_unchanged':True,'head_unchanged':True,'new_revision':1,'sha256':core.sha_file(faildb)},
  'structurally_valid_mechanically_wrong':{'status':'PASS_REJECT_MECHANICALLY_IMPOSSIBLE_WITH_VALID_REHASHED_SQLITE','scene':mutated.name,'structural_R18_load':'PASS','mechanical_oracle':'FAIL_CORRECTLY','detected':reason,'domain_violation':'damage_die=7 and raw_damage=20 where 1d6+13 maximum19','fixture_is_synthetic_and_NOT_combat':True,'sha256':core.sha_file(mutated)},
  'guard_matrix':guard_matrix(),'original_combats_mutated':False,'campaign_effects':0}
 core.dump('evidence/R40_ADVERSARIAL_RESULTS.json',results)
 print(json.dumps({k:results[k]['status'] for k in ('preflight_no_intent','failure_after_native_before_commit','structurally_valid_mechanically_wrong','guard_matrix')},indent=2))

if __name__=='__main__':main()
