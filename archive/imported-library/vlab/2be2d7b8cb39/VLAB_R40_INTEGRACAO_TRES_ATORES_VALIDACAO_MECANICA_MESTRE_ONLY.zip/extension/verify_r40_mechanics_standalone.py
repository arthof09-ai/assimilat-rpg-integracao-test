"""Independent mechanical + structural + causal read-only oracle for R40. Stdlib only.
DOES NOT import original motor, gateway, R18, R26 or R40 executor. Strictly recomputes
R18 SHA256-seeded experimental draws and applies the official frozen Goat formulas.
Read-only audit; failures are expected in TEST-ONLY mutated copies.
"""
from __future__ import annotations
import hashlib,json,math,random,sqlite3,sys
from pathlib import Path
IDS=['LAB_R40_GOAT_A','LAB_R40_GOAT_B','LAB_R40_GOAT_C'];A,B,C=IDS
VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
class AuditFail(RuntimeError):pass

def J(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def H(x):return hashlib.sha256(J(x).encode()).hexdigest()
def require(cond,msg):
 if not cond:raise AuditFail(msg)
def die(seed,index,label):
 entropy=hashlib.sha256(f'{seed}|{index}|{label}|1d6|{VERSION}'.encode('utf8')).digest()
 return random.Random(int.from_bytes(entropy,'big')).randint(1,6)

def read(db):
 co=sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True)
 try:
  require(co.execute('PRAGMA integrity_check').fetchone()[0]=='ok','STRUCTURAL_SQLITE_INTEGRITY')
  require(co.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0,'UNKNOWN_EFFECT_PENDING')
  meta=dict(co.execute('SELECT key,value FROM meta'))
  rs=co.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
 finally:co.close()
 return meta,rs

def inspect(db,expected_actor_count=3):
 meta,rows=read(db);st=json.loads(meta['state']);seed=st['seed'];initial_head=meta['genesis'];previous=initial_head;earlier_after=None
 require(st['scene'].startswith('R40_REAL_GOAT_THREE_NATIVE_RNG_SCHEDULER_'),'SOURCE_SCENE_NOT_R40')
 require(len(rows)==int(meta['revision']) and len(rows)>1,'STRUCTURAL_REVISION_OR_EMPTY')
 require(len(st['actors'])==expected_actor_count==3 and sorted(st['actors'])==IDS,'ACTOR_COUNT_OR_IDENTITY')
 for actor in st['actors'].values():
  require(actor['source_page_id']=='391c2b32-4ede-8252-b0cc-810423cdbfa6','SOURCE_NOT_GOAT')
  require(actor['source_kind']=='NOTION_MASTER_REAL' and actor['stats']['for']==13 and actor['stats']['des']==8 and actor['stats']['con']==10,'SOURCE_STATS_DIFFER')
  require(actor['resource']['ca']==20 and actor['resource']['reflex']==6 and actor['resource']['armor'] is None and actor['resource']['fortitude'] is None,'DEFENSE_SOURCE_BOGUS')
 require(st['r40']['world_effects']==0 and st['synthetic'] is True,'CANON_EFFECT_PRESENT')
 # Model reconstructs mechanical state and turn windows from the event details, not from the executor state.
 hp={id:38 for id in IDS};pa={id:22 for id in IDS};reaction={id:1 for id in IDS};standard={id:1 for id in IDS};movement={id:1 for id in IDS}
 xy={A:[0.,0.],B:[1.5,0.],C:[0.,1.5]};own_ix={id:0 for id in IDS};order=None;round_=0;turn_ix=0;active=None
 attacks=0;skips=[];reactions=0;rej=0;pushes=0;moves=0;first_attackers=[];eliminated=[]
 for idx,(seq,cmd,p,row_json,row_sha,before_sha,after_sha) in enumerate(rows,1):
  require(seq==idx,'STRUCTURAL_SEQUENCE')
  row=json.loads(row_json)
  require(row['seq']==seq and row['cmd_id']==cmd and row['prev']==previous and p==previous,'STRUCTURAL_PREVIOUS_HEAD')
  require(row['before_sha']==before_sha and row['after_sha']==after_sha and H(row)==row_sha,'STRUCTURAL_ROW_SHA')
  if earlier_after is not None:require(before_sha==earlier_after,'STRUCTURAL_STATE_CHAIN')
  previous=row_sha;earlier_after=after_sha;d=row['detail'];p0=row['payload']
  require(row.get('official_effects')==0 and row.get('synthetic') is True,'CANONICAL_EVENT')
  if idx==1:
   require(row['kind']=='R40_INITIATIVE' and p0=={'kind':'INIT','seed':seed},'INIT_EVENT_NOT_CAUSAL')
   nat=d['native_initiative_R26'];rr=nat['rolls'];require(len(rr)==3,'INIT_ROLLS_COUNT')
   totals={}
   for k in IDS:
    o=next((x for x in rr if x['id']==k),None)
    require(o is not None,'INIT_ACTOR_MISSING')
    n=die(seed,0,'initiative:'+k);require(o['dice']==[n] and o['des']==8 and o['bonus']==0 and o['total']==n+8,'INIT_DICE_FALSIFIED')
    totals[k]=n+8
   # This seed creates initial B,C tie, with R26 reroll exactly the tied group.
   groups={};[groups.setdefault(v,[]).append(a) for a,v in totals.items()]
   transcript=nat['tie_resolution']['rerolls'];taken=set();result=[];index=0
   for v in sorted(groups,reverse=True):
    tied=groups[v]
    if len(tied)==1:result+=tied;continue
    # Same DES, reroll only this tied group. For seed 91001 resolved in first reroll.
    s=transcript[index];index+=1
    require(set(s['only_tied'])==set(tied) and s['initial_tie_total']==v and s['des']==8 and s['step']==1,'INIT_TIE_SCOPE')
    re_scores={a:die(seed,1,'R26-TIE-'+a)+8 for a in tied}
    require(len(set(re_scores.values()))==len(tied),'INIT_TIE_REQUIRES_MORE_REROLLS_NOT_COVERED')
    for draw in s['draws']:require(re_scores[draw['id']]==draw['roll_total'],'INIT_REROLL_NOT_NATIVE')
    result+=sorted(tied,key=lambda a:-re_scores[a])
   require(index==len(transcript) and result==d['order']==nat['order']==nat['tie_resolution']['order'],'INIT_ORDER_WRONG')
   order=result;active=order[0];round_=1;turn_ix=0
   require(d['first_actor']==active and d['refresh_own_turn_R26']['actor']==active,'INIT_REFRESH_ACTOR')
   continue
  require(row['kind']=='R40_TURN' and order is not None,'INVALID_TURN_KIND')
  require(d['action']=='CABRA_INVESTIDA_MESTRE_R34_FF300' and d['source']=='391c2b32-4ede-8252-b0cc-810423cdbfa6','UNAUTHORIZED_ACTION_SOURCE')
  a=d['actor'];t=d['target'];require(a==active==p0['actor'] and round_==p0['round'] and t==p0['target'],'ACTOR_OR_ROUND_WRONG')
  require(hp[a]>0 and hp[t]>0 and t!=a and standard[a]==1,'KO_OR_DOUBLE_STANDARD')
  candidates=[id for id in IDS if id!=a and hp[id]>0]
  target_rule=(B if B in candidates else sorted(candidates)[0]) if a in (A,C) else (A if A in candidates else sorted(candidates)[0])
  require(t==target_rule,'TARGET_AFTER_FACT')
  first_attackers.append(a)
  own_ix[a]+=1;tt=d['RNG'];require(p0['tape']==tt,'TAPE_VS_PAYLOAD_MISMATCH')
  require(tt['index']==own_ix[a] and tt['seed']==seed and tt['actor']==a and tt['luta']==6 and tt['for']==13,'RNG_PROVENANCE_OR_INDEX')
  crit=[die(seed,own_ix[a],'R40-CRIT-'+a+'-'+str(n)) for n in (1,2,3)]
  hit=die(seed,own_ix[a],'R40-HIT-'+a);dam=die(seed,own_ix[a],'R40-DAMAGE-'+a)
  require(tt['critical_dice']==crit and tt['hit_die']==hit and tt['damage_die']==dam,'RNG_TAPE_NOT_GENERATED')
  require(all(1<=q<=6 for q in tt['critical_dice']+[tt['hit_die'],tt['damage_die']]),'DICE_OUTSIDE_1_6')
  pos=crit[:2]==[6,6] and crit[2]>=5;neg=crit[:2]==[1,1] and crit[2]<=2
  require(not neg and tt['critical_negative'] is False and tt['critical_positive']==pos,'CRITICAL_SEQUENCE_NOT_AUTHORIZED')
  score=hit+13+6;raw=dam+13+(6 if pos else 0)
  require(tt['attack_total']==score==p0['tape']['attack_total'] and tt['damage_total']==raw,'IMPOSSIBLE_DAMAGE_OR_ATTACK')
  # geometric movement, up to the rank Bronze normal speed 10 m.
  distance=math.dist(xy[a],xy[t]);evmove=d['movement']
  if distance>1.5000001:
   require(evmove is not None and movement[a]==1,'MOVEMENT_UNAVAILABLE')
   needed=distance-1.5
   require(needed<=10 and abs(evmove['distance']-needed)<1e-6 and evmove['cost']=='ONE_MOVEMENT_ACTION','MOVEMENT_COST_OR_SPEED')
   end=[round(xy[a][k]+(xy[t][k]-xy[a][k])/distance*needed,8) for k in (0,1)]
   require(evmove['from']==xy[a] and evmove['to']==end,'GEOMETRY_FALSE_MOVE')
   xy[a]=end;movement[a]=0;moves+=1
  else:require(evmove is None,'UNNECESSARY_MOVEMENT')
  require(math.dist(xy[a],xy[t])<=1.5000002,'NO_MELEE_RANGE')
  wanted=(t==B)
  re=d['voluntary_reaction'];rj=d['rejected_second_reaction']
  if wanted and reaction[t]==1:
   require(re is not None and rj is None and re['by']==t and re['action']=='ESQUIVAR' and re['defense_exact']=='26' and re['attack_score']==score and re['source']=='BEFORE-ATTACK','REACTION_BAD_WINDOW')
   require(re['damage_negated'] is True and re['consumes_reaction'] is True,'REACTION_NEUTRALIZATION')
   reaction[t]=0;reactions+=1
  elif wanted:
   require(re is None and rj is not None and rj['reason']=='reaction not available' and rj['without_effects'] is True,'SECOND_REACTION_NOT_REJECTED');rej+=1
  else:require(re is None and rj is None,'UNAUTHORIZED_REACTION')
  effect=d['native_attack'];hit_bool=score>20
  net=0 if (not hit_bool or re is not None) else max(0,raw-5)
  before=hp[t];hp[t]=max(0,hp[t]-net);standard[a]=0
  require(effect['roll_score']==score and effect['ca_exact']=='20' and effect['hit']==hit_bool and effect['net']==net and effect['before_hp']==before and effect['after_hp']==hp[t],'MECHANICAL_DAMAGE_RD_OR_HP_FALSE')
  require(effect['raw']==(raw if net else 0) and effect['rd_applied']==(5 if net else 0) and effect['defense_negated']==(re is not None),'RD_OR_DEFENSE_WRONG')
  require(effect['from']==a and effect['to']==t and effect['type']=='impacto' and effect['defensive_reaction']==('ESQUIVAR' if re else None),'SOURCE_EFFECT_WRONG')
  # Must record correct physical loss (no post-hit push for failed/reaction).
  push=d['push']
  if net>0 and hit_bool:
   beforexy=xy[t][:];dd=math.dist(xy[a],xy[t]);to=[round(beforexy[k]+(beforexy[k]-xy[a][k])/dd*1.5,8) for k in (0,1)]
   require(push is not None and push['from']==beforexy and push['to']==to and push['m']==1.5 and push['ff']==310,'FORCED_PUSH_WRONG')
   xy[t]=to;pushes+=1
  else:require(push is None,'PUSH_WITHOUT_DAMAGE')
  require(d['after_hp']==hp and d['after_positions']==xy,'STATE_AFTER_OR_GEOMETRY_WRONG')
  if hp[t]==0:eliminated.append({'actor':t,'event':idx,'killer':a})
  live=[x for x in IDS if hp[x]>0]
  tr=d['turn_transition']
  if len(live)<=1:
   require(tr['completed'] is True and tr['winner']==(live[0] if live else None),'INVALID_BATTLE_END')
   active=None
  else:
   skips=[];prev=a
   for _ in range(3):
    turn_ix=(turn_ix+1)%3
    if turn_ix==0:round_+=1
    n=order[turn_ix]
    if hp[n]==0:skips.append(n);continue
    standard[n]=1;movement[n]=1;reaction[n]=1;active=n;break
   require(tr['completed'] is False and tr['active']==active and tr['round']==round_ and tr['skipped']==skips,'SCHEDULER_SKIP_KO_CAUSAL_DIFF')
   require(tr['refresh']['actor']==active and tr['refresh']['after']==1 and tr['refresh']['trigger']=='OWN_TURN_START','REFRESH_WRONG_WINDOW')
  require(d['after_reactions']==reaction,'REACTION_SLOTS_CAUSAL_DIFF')
  require(d['world_effects']==0,'OFFICIAL_EFFECT')
  attacks+=1
 require(previous==meta['head'],'STRUCTURAL_FINAL_HEAD')
 require(st['phase']=='COMPLETE_LAB_R40_3_GOAT_REAL_SOURCE' and active is None,'NOT_COMPLETED_AS_DECLARED')
 require(st['winner']==next(x for x in IDS if hp[x]>0) and {a:v['resource']['hp'] for a,v in st['actors'].items()}==hp,'FINAL_HP_OR_WINNER_FALSE')
 require({a:v['resource']['reaction'] for a,v in st['actors'].items()}==reaction,'FINAL_REACTION_FALSE')
 require({a:v['resource']['standard'] for a,v in st['actors'].items()}==standard,'FINAL_STANDARD_BUDGET_FALSE')
 require({a:v['resource']['movement'] for a,v in st['actors'].items()}==movement,'FINAL_MOVEMENT_BUDGET_FALSE')
 require({a:v['resource']['pa'] for a,v in st['actors'].items()}==pa,'FINAL_PA_BUDGET_FALSE')
 require(st['r40']['positions']==xy,'FINAL_POSITION_FALSE')
 require(st['r40']['attacks']==attacks and st['r40']['reaction_announcements']==reactions and st['r40']['reaction_rejections']==rej and st['r40']['pushes']==pushes and st['r40']['movements']==moves,'COUNTERS_FALSE')
 require(len(eliminated)==2,'NOT_TWO_NATIVE_KILLS')
 return {'status':'PASS','structural':'PASS','mechanical':'PASS','causal':'PASS','normative_scope':'R40_LAB_ONLY','seed':seed,'events':len(rows),'attacks':attacks,'reactions':reactions,'second_reactions_rejected':rej,'pushes':pushes,'movement_actions':moves,'eliminations':eliminated,'winner':st['winner'],'rounds':st['round'],'head':meta['head'],'RNG_type':'SHA256_seeded_Python_MT_experimental_not_canonical','source_page':'391c2b32-4ede-8252-b0cc-810423cdbfa6'}

if __name__=='__main__':
 try:print(json.dumps(inspect(sys.argv[1]),ensure_ascii=False,indent=2))
 except AuditFail as e:print('AUDIT_FAIL:',str(e),file=sys.stderr);sys.exit(2)
