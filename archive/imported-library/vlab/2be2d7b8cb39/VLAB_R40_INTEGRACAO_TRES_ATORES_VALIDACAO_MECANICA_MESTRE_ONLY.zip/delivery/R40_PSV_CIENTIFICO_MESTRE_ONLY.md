# PSV — VLAB R40 | Integração real-fonte com três atores e auditoria mecânica

**Operação existente:** CM-000006 — OP-VLAB-FUSION-SANDBOX-01 (Mestre-side). **Data:** 15/10/2026.

## ANTES
R39/R39B: bateria de três subsistemas separada, dano bruto20 inválido da R39 preservado por errata; R39B tem dano válido19 mas valor injetado no resolver. 16 full-fights real-fonte históricos em sandbox, 2 observações censuradas, 5 sondas isoladas, **0/17** contratos terminais, **0/1875** células canônicas. Baseline R18/R26/v0.8.1/gateway R31/R35/R36 preservada, seed53 R29 e UNKNOWN_EFFECT históricos não tocados.

## DEPOIS — A: CENA INTEGRADA NOVA
Duas cenas novas, três identidades experimentais de uma única ficha física Notion Mestre **Cabra de Chifres B1** (page 391c2b32-4ede-8252-b0cc-810423cdbfa6; ultima edição 2026-10-01 18:00:34Z), uma espécie oficial e TRÊS atores não canônicos. Fonte FOR13 DES8 CON10 CA20 Vida38 Alma22, FF310, RD Bronze geral5. Decisões Mestre já aplicadas: Investida +6 no acerto e zero PA, dano **1d6+FOR13**, Esquiva **20+6=26**, empate vence defesa, força empurra **1,5m após acerto com dano líquido positivo**, Reação R26 só renova no próprio turno. Bônus Iniciativa zero é premissa de cena LAB autorizada R33, **não valor impresso na ficha**. Arena livre com coordenadas A(0;0) B(1,5;0) C(0;1,5), Movimento Bronze 8+DES/4=10m.

Ator A/C prioriza B enquanto viva; B prioriza A; após KO do alvo, escolhe outra oponente viva. B anuncia Esquivar em TODO ataque enquanto slot1, A/C declinam. Políticas fixadas no estado GENESIS antes de rolar dados, nunca após resultados. A ordem R26 é derivada de **R18.dice(seed,0,initiative:ator,1,6)** com DES e desempate R26. O RNG R18 gera críticos em sequência 3×d6 e d6 para acerto/dano, **por atacante e índice próprio**, antes do score passado ao núcleo v0.8.1. Esse é RNG **nativo do LAB R18**, não fonte canônica da campanha.

- **Seed 91001 / com empate:** A total12, B11 e C11; DES idêntica8, rerrolagem apenas B/C (B10/C12) resolve A→C→B. **7 rodadas, 19 eventos (1 iniciativa+18 ataques), 5 Esquivas, 5 tentativas de segunda Esquiva recusadas, 9 empurrões, 11 Movimentos, vencedor C com Vida27**. B KO por Investida do C no evento15; scheduler R18 tentaria selecionar B, o adaptador R40 a salta SEM renovar padrão/movimento/reação; A KO por Investida do C no evento19. B e A tinham HP0 por DANO DO RESOLVEDOR NATIVO, não fixture.
- **Seed 91002 / sem empate:** iniciativa A13, C12, B10 → A→C→B. **10 rodadas, 25 eventos (1 iniciativa+24 ataques), 10 Esquivas, 4 segundas Esquivas recusadas, 11 empurrões, 13 Movimentos, vencedor B com Vida2**. A KO no evento13 e C KO no evento25 por dano de ataque nativo. A eliminada foi saltada em múltiplas transições, sem receber novo turno nem refresh.

**SOMA R40:** dois confrontos completos NOVOS em sandbox com três atores fonte derivada, **44 eventos, 42 ataques nativos, 15 Reações ESQUIVAR, 9 negativas de nova Esquiva, 20 empurrões, 24 ações de Movimento, 4 eliminações nativas**. Não contar iniciativas como ataques, nem fixtures como confrontos. **Histórico full-fight sandbox real-fonte 16→18**; patamares únicos continuam Bronze1 e Bronze5 (2/25), somente uma classificação Bronze. Campanha0.

## B — CORREÇÃO ADITIVA DO DEFeito R18
`R18._next_turn()` avança por índice e pode iniciar turno de ator com HP0, inclusive resetando standard/movement. O adaptador R40 `alive_advance()` usa o MESMO avanço R18; se o próximo selecionado estiver KO, restaura seus recursos EXATAMENTE ao valor anterior e avança ao próximo vivo, sem invocar refresh R26 no eliminado. O próximo participante vivo recebe sua própria renovação R26. **A camada histórica não foi editada.**

Diferença funcional demonstrada nos próprios eventos 15/17 da seed91001 e nas transições da seed91002: antes, ator KO poderia ser selecionado; depois, é saltado, recursos mortos preservados. Ao restar apenas um vivo, a transação encerra, sem avanço fictício. Estado nenhum sobrevivente só foi avaliado em fixture sintética (`NO_WINNER`), não creditado como morte nativa simultânea. Morte por Contra-ataque/Reação permanece **BLOCKED-NORMATIVE/NOT-TESTED**, não imputada como PASS.

## C — RNG, FÓRMULAS E AUDITORIA INDEPENDENTE
Oráculo `verify_r40_mechanics_standalone.py` usa apenas stdlib, **NÃO importa motor, catálogo ou gateway**. Reabre ledgers, checkpoints e fontes congeladas, recompõe dados por seed/label/index, iniciativa e desempate, ataca com `d6+13+6`, calcula dano `d6+13(+6 se crítico positivo)`, mitigação RD5, Esquiva26, recursos, transições, posições, KO, SHA e ordem causal. **2/2 cenas originais e 2/2 checkpoints PASS**, **44 eventos reproduzidos**. Ainda não testa IA adversarial geral nem paridade v0.9 original.

Caso discriminante: cópia descartável do ledger com SHA encadeado refeito e d6(7), dano20. **R18.load PASS estrutural, oráculo mecânico REJECT**. Oito outros cenários de alterações assinadas novamente de domínio, score, Luta, RD, dano, Vida, posição e ordem de ator: **8/8 rejeitados mecanicamente**. Reabertura do ZIP histórico R39 verificou bruto20 inválido; erro original não apagado.

Atomicidade: pré-reserva com ID inválido = 0 eventos, 0 intenções; falha controlada NOVA seed91011 após resolução nativa e antes do commit = revisão1 de iniciativa, 1 intenção pendente, **zero ataques publicados após falha**, HP/PA/slots intactos e loader bloqueado UNKNOWN_EFFECT. **Banco congelado, sem retentativa**; cópia de backup portátil preserva pending1. Tentativa de comando duplicado e uso de Ação Padrão gasta rejeitados em CLONES, sem efeitos oficiais.

## E — HOLDOUT MECÂNICO DE CRÍTICOS
Protocolo pré-registrado SHA256 `71594d97a8f67b8fc24f594745428f5ef0f3072b0be55f425225741588db6c6e`. 1200 seeds exclusivas 92001–93200, **3.600 dados em 1200 sequências ordenadas**, críticos positivos **4**, negativos **15**, outros **1181**. Enumeração exata dos 216 trios mostra somente (6,6,5/6) e (1,1,1/2), com probabilidades2/216 para cada. Pearson χ²=5.921038 (gl2), p≈0.051792, alpha0,01: **NÃO REJEITA hipótese de distribuição** nesse teste. Não prova uniformidade, independência, crítico em combate ou dados oficiais da campanha. **Zero críticos positivos ou negativos ocorreu nos 42 ataques das duas novas cenas; seus efeitos nativos permanecem NÃO TESTADOS nesta R40.**

## F — CONTRATOS, LIMITES E CRÉDITOS
Matriz delta `R40_DELTA_MATRIX_3_OF_17.json` preserva os IDs e critérios originais da R18 (original SHAs retidos), com PASS/FAIL/BLOCKED/NOT_TESTED e 4 camadas.

- `REACTION_TRIGGER_AND_SINGLE_USE`: **PASS técnico restrito** às janelas ESQUIVAR sequenciais/slot/refresco na ordem real 3-ator. Pendente concorrência realmente alcançável (ex. duas oportunidades ao sair adjacência) e precedência de Contra-atacar aninhado, outras Reações com fonte competente, gate externo.
- `TURN_SCHEDULER_EVENT_SOURCING`: **PASS técnico restrito** a 3 atores de uma mesma Besta com iniciativa R26, KO real, skip corrigido, posição/reação e checkpoint. Falta concorrência/interrupção legalmente admissível, eliminação durante Contra-ataque, cobertura de casos extremos e revisão externa.
- `RNG_REPLAY_STATISTICS`: **PASS técnico restrito** à fita determinística do LAB + auditor independente/holdout sequencial de crítico. **Fonte canônica de dados da campanha ainda não autenticada; efeito crítico nativo não ocorreu**.

**ACEITAÇÃO TÉCNICA INTEGRAL: 0/3; CERTIFICAÇÃO TERMINAL: 0/17; CÉLULAS CANÔNICAS: 0/1875; NAC-PASS PRODUTIVO: HOLD.** Não há promoção automática por prova num único escopo. IBX-56 BLOCKED-EXTERNAL, writer/lease/epoch/fencing/GREEN produtivos HOLD.

## G/H — PRESERVAÇÃO E FRONTEIRA
Novos estados têm IDs, sementes, SQLite, SHA chain, recibos e checkpoints próprios; R01–R39B (incluindo seed53 e UNKNOWN_EFFECT) não foram sobrescritos. SHA de R39 e R39B revalidado nesta rodada, não foi feita auditoria global redundante dos R01–R38. Ficheiro da Cabra, Sistema de Combate e OP Notion lidos, nenhum dado de campanha escrito.

**Retomada exata:** (1) inspecionar `R40_COLD_INDEPENDENT_AUDIT.json` + recibos de seeds91001/91002, não reexecutá-las; (2) conseguir fonte/precedência para Contra-ataque aninhado e oportunidades concorrentes comprovavelmente alcançáveis; (3) exercitar crítico real na fita nativa com seed previamente declarada, sem reetiquetar fixture; (4) ampliar scheduler em eliminação durante Reação e outros casos; (5) autenticar mecanismo canônico de dados, se existir.
