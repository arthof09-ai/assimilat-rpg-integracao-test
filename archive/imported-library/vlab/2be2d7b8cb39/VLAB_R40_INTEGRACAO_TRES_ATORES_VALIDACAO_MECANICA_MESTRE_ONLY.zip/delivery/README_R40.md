# R40 — execução recuperável e verificação independente

Este ZIP é um **delta** novo: preserva R01–R39B e não duplica os 17 contratos. Contém 2 cenários novos de três Cabras source-real em sandbox, checkpoints SQL, tape e 4 auditorias.

## Verificação sem importar o motor

Executar em uma extração limpa: `python extension/verify_r40_mechanics_standalone.py ledgers/R40_FIRST_ELIGIBLE_ACB_SEED91001.sqlite` e depois seed91002; repetir nos dois arquivos `checkpoints/CHECKPOINT_....sqlite`. Este verificador stdlib reconstitui dados, efeitos e turnos. O arquivo `evidence/R40_COLD_INDEPENDENT_AUDIT.json` contém a auditoria anteriormente verificada do conjunto.

## Motor histórico para reproduzir a execução APENAS em NOVA CENA

Requer as mesmas dependências autenticadas dos arquivos preservados R27, R31/R34, R35/R36, R18/R26 e v0.8.1, materializadas em `/mnt/data/vlab_r39/work/runtime_copy`. O script fonte `extension/r40_integrated_three_actors.py` liga essas dependências, NÃO fornece um segundo motor. Os bancos desta entrega estão TERMINAIS e NÃO DEVEM SER REEXECUTADOS, ID replicado, sobrescrito ou reaplicado a campanha. A seed 91001 foi a primeira do recorte [91001...] com ordem A,C,B segundo R26, incluindo B/C empatados no 1º lançamento; a seed91002 foi a primeira seguinte sem empate. Seleção de casos por condição não representa amostragem imparcial de vitórias.

O banco `evidence/R40_FAULT_PENDING_PORTABLE_FROZEN.sqlite` retém pending1 e é somente evidência de fail-closed. O arquivo `evidence/R40_TAMPERED_RECHAINED_MECHANICALLY_IMPOSSIBLE_TEST_ONLY.sqlite` foi adulterado de propósito em CÓPIA e deve ser REJEITADO pela auditoria mecânica; nunca dar crédito a esse banco.

## Resultados e limites

`evidence/R40_DELTA_MATRIX_3_OF_17.json` refere os três contratos da matriz R18. Fontes originais e decisões do Mestre são citadas no PSV. Nenhuma certificação terminal, writer, lease ou NAC-PASS produtivo foi concedido.
