#!/usr/bin/env python3
"""R244 independent, non-writing audit of VLAB R243 and DMG C31 math-only sources.
No speculative transformations of canon, no Notion or DMG writes.
"""
import collections, copy, hashlib, itertools, json, re, sys, zipfile
from fractions import Fraction
from pathlib import Path

VLAB=Path('/mnt/data/VLAB_R243_RD_LEDGER_MESTRE_ONLY')
DMG=Path('/mnt/data/vlab_r244_dmgsources')
OUT=Path('/mnt/data/VLAB_R244_DMG_RD_METHOD_BRIDGE_MESTRE_ONLY')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(cond,msg):
    if not cond: raise AssertionError(msg)
def check_row(r):
    required=['stage','sqlite','event_seq','raw','rd_applicable_nominal','rd_absorbed_actual','post_rd_effective','hp_loss_actual','overkill_or_nonhp']
    fail(all(k in r for k in required),'MISSING_FIELD')
    for k in required[3:]:fail(type(r[k]) is int and r[k]>=0,'BAD_NONNEGATIVE_'+k)
    b,n,a,p,h,o=(r[k] for k in required[3:])
    fail(a==min(b,n),'RD_ABSORBED_BAD')
    fail(p==max(0,b-n),'POST_RD_BAD')
    fail(h<=p,'HP_MORE_THAN_POST_RD')
    fail(o==p-h,'OVERKILL_BAD')
    fail(r['stage'] in ['R234','R235','R236','R237','R239','R240'],'BAD_STAGE')
    fail(isinstance(r['event_seq'],int),'BAD_EVENT_SEQUENCE')
    return True

def validate(rows,expected_counts=None):
    seen=set(); agg=collections.Counter(); stages=collections.defaultdict(collections.Counter)
    for r in rows:
        check_row(r)
        key=(r['stage'],r['sqlite'],r['event_seq'])
        fail(key not in seen,'DUPLICATE_EVENT_KEY');seen.add(key)
        for key2 in ['raw','rd_applicable_nominal','rd_absorbed_actual','post_rd_effective','hp_loss_actual','overkill_or_nonhp']:
            agg[key2]+=r[key2]; stages[r['stage']][key2]+=r[key2]
        agg['events']+=1;stages[r['stage']]['events']+=1
    fail(agg['raw']-agg['rd_absorbed_actual']==agg['post_rd_effective'],'GLOBAL_RD_MISMATCH')
    fail(agg['post_rd_effective']-agg['hp_loss_actual']==agg['overkill_or_nonhp'],'GLOBAL_HP_MISMATCH')
    if expected_counts: fail(agg==expected_counts,'SOURCE_ANCHOR_MISMATCH')
    return agg,stages

rawpath=VLAB/'evidence/R243_COMBAT_RD_PROVENANCE.jsonl'
rows=[json.loads(l) for l in rawpath.read_text().splitlines() if l.strip()]
agg,stages=validate(rows)
expected={'events':834,'raw':61092,'rd_applicable_nominal':37200,'rd_absorbed_actual':37019,'post_rd_effective':24073,'hp_loss_actual':23422,'overkill_or_nonhp':651}
fail(dict(agg)==expected,'R243_BASELINE_DIVERGENT')
# exact second implementation: integer distributions for four uniform six-sided dice.
c31zip=DMG/'DMG_C31_PLANO_SUPREMO_A6_F6_IDENTIDADE_MATH_MESTRE_ONLY.zip'
with zipfile.ZipFile(c31zip) as z:
    fail(z.testzip() is None,'DMG_C31_ZIP_CRC_FAIL')
    mathreport=json.loads(z.read('C31_MATHONLY_SENSITIVITY_24_CASES.json'))
    c31_text=z.read('C31_PARECER_E_CONTINUIDADE_MESTRE_ONLY.md').decode()
with zipfile.ZipFile(DMG/'DMG_C30_PLANO_SUPREMO_CENSO_F6_A7_VLAB_MESTRE_ONLY.zip') as z:
    fail(z.testzip() is None,'DMG_C30_ZIP_CRC_FAIL')
    c30_text=z.read('C30_PARECER_CIENTIFICO_MESTRE_ONLY.md').decode()
counts=collections.Counter(map(sum,itertools.product(range(1,7),repeat=4)))
fail(sum(counts.values())==1296,'4D6_DENOMINATOR')
comparison=[]
for item in mathreport['conditional_scenarios']:
    rd=item['rd_assumed'];external=item['external_bonus_assumed']
    e=Fraction(sum(n*max(0,d+external-rd) for d,n in counts.items()),1296)
    p=Fraction(sum(n*(d+external>rd) for d,n in counts.items()),1296)
    fail(e==Fraction(item['net_mean_exact']),'DMG_C31_EXPECTATION_MISMATCH')
    fail(p==Fraction(item['p_positive_exact']),'DMG_C31_PROBABILITY_MISMATCH')
    comparison.append({'rd':rd,'external_bonus':external,'expected_post_rd':str(e),'p_positive':str(p),'classification':'MATH_ONLY_CONDITIONAL'})
fail(len(comparison)==24,'SCENARIO_COUNT')
# Negative probes intentionally operate on derived read-only copies (source ZIP remains unchanged).
mutations=[('negative_gross',lambda x:x.__setitem__('raw',-1)),('negative_rd',lambda x:x.__setitem__('rd_applicable_nominal',-1)),('wrong_absorbed',lambda x:x.__setitem__('rd_absorbed_actual',x['rd_absorbed_actual']+1)),('wrong_post',lambda x:x.__setitem__('post_rd_effective',x['post_rd_effective']+1)),('hp_exceeds_post',lambda x:x.__setitem__('hp_loss_actual',x['post_rd_effective']+1)),('wrong_overkill',lambda x:x.__setitem__('overkill_or_nonhp',x['overkill_or_nonhp']+1)),('unknown_stage',lambda x:x.__setitem__('stage','R000')),('missing_raw',lambda x:x.pop('raw')),('float_rd',lambda x:x.__setitem__('rd_applicable_nominal',75.0)),('string_hp',lambda x:x.__setitem__('hp_loss_actual','42'))]
adversarial=[]
for name,fn in mutations:
    f=copy.deepcopy(rows[0]);fn(f)
    try: check_row(f);bad=False
    except AssertionError:bad=True
    fail(bad,'FAILED_TO_REJECT_'+name);adversarial.append({'case':name,'reject':bad})
try:validate(rows+[copy.deepcopy(rows[0])]);duplicates_rejected=False
except AssertionError:duplicates_rejected=True
fail(duplicates_rejected,'DUPLICATE_ACCEPTED');adversarial.append({'case':'duplicate_primary_key','reject':True})
try:
    altered=copy.deepcopy(rows)
    # Construct internally consistent fraud; only source-anchored known totals can reject it.
    altered[0]['raw']+=1;altered[0]['post_rd_effective']+=1;altered[0]['hp_loss_actual']+=1
    validate(altered,collections.Counter(expected));source_rejected=False
except AssertionError:source_rejected=True
fail(source_rejected,'SOURCE_LEVEL_FORGERY_ACCEPTED');adversarial.append({'case':'internally_consistent_wrong_source','reject':True})
# Crucial distinction: exact strings in source documents; this does not audit all DMG code or data.
search_tokens=['rd_applied','rd_absorbed_actual','post_rd_effective','overkill_or_nonhp']
scan={'C30':{key:len(re.findall(re.escape(key),c30_text,re.I)) for key in search_tokens},'C31':{key:len(re.findall(re.escape(key),c31_text,re.I)) for key in search_tokens}}
result={'stage':'R244','status':'PASS_LOCAL_METHOD_BRIDGE','source_VLAB_R243_jsonl_sha256':sha(rawpath),'source_DMG_C31_zip_sha256':sha(c31zip),'source_DMG_C30_zip_sha256':sha(DMG/'DMG_C30_PLANO_SUPREMO_CENSO_F6_A7_VLAB_MESTRE_ONLY.zip'),'event_rows':len(rows),'rd_nominal_minus_absorbed':agg['rd_applicable_nominal']-agg['rd_absorbed_actual'],'metrics':dict(agg),'stages':{x:dict(y) for x,y in stages.items()},'math_only_conditional_4d6_scenarios_verified':len(comparison),'DMG_report_token_occurrences':scan,'adversarial_rejections':len(adversarial),'no_verified_DMG_operational_bug':True,'DMG_C31_mathonly_not_live_engine':True,'official_cells':0,'terminal_certifications':0,'canonical_writes':0,'dmG_not_written':True}
(OUT/'reports/R244_READONLY_SOURCE_BRIDGE.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
(OUT/'reports/R244_DMGC31_4D6_24_CASES_VALIDATED.json').write_text(json.dumps(comparison,indent=2,ensure_ascii=False))
(OUT/'reports/R244_ADVERSARIAL_12.json').write_text(json.dumps(adversarial,indent=2,ensure_ascii=False))
print(json.dumps(result,indent=2,ensure_ascii=False))
