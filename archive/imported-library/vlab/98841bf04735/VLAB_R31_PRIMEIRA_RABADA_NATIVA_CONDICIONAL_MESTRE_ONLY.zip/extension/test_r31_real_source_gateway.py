import sys,json,sqlite3,tempfile,unittest,hashlib
from pathlib import Path
from copy import deepcopy
sys.path.insert(0,str(Path(__file__).resolve().parent))
import vlab_r31_real_source_gateway as g
from vlab_rd_v08 import mitigate,DamageComponent,Resistances
from vlab_action_catalog_v01 import action_menu,ActorActionState

class TestRealSourceR31(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='R31-TEST-')
  self.db=Path(self.tmp.name)/'scene.sqlite';g.create(self.db,211)
 def tearDown(self):self.tmp.cleanup()
 def test_two_real_fichas(self):
  st,_,v=g.checked(self.db)
  self.assertEqual(v,0);self.assertEqual([st['actors'][x]['source_page_id'] for x in (g.AID,g.TID)],[g.BEAST_SOURCE,g.TARGET_SOURCE])
  self.assertEqual(st['actors'][g.TID]['resource']['hp'],38)
  self.assertTrue(st['synthetic']) # LAB scene simulated, never actor kind
  self.assertEqual(st['actors'][g.AID]['source_kind'],'NOTION_MASTER_REAL')
 def test_ruling_bound(self):
  x=g.evidence_manifest();self.assertEqual(x['master_decision']['damage'],'1d6+FOR')
  self.assertEqual(x['master_decision']['economy'],'STANDARD')
  self.assertEqual(x['master_decision']['pa_extra'],0)
 def test_strict_catalog_ready_but_luta_unknown(self):
  c=g.catalog(self.db);self.assertEqual(c['status'],'ACTION_CATALOG_SOURCE_SIGNATURE_READY')
  self.assertFalse(c['attack_legal_complete'])
 def test_missing_luta_hold_before_intent(self):
  with self.assertRaisesRegex(g.Hold,'MESTRE_LUTA_DECISION_STILL_REQUIRED'):g.execute_authorized(self.db,{'foo':'bar'})
  st,_,rev=g.checked(self.db)
  self.assertEqual(rev,0);self.assertEqual(st['actors'][g.TID]['resource']['hp'],38)
  with sqlite3.connect(self.db) as con:self.assertEqual(con.execute('select count(*) from pending').fetchone()[0],0)
 def test_source_pin_tamper_reject(self):
  st,_,_=g.checked(self.db);st['r31_source']['source_manifest_sha']='0'*64
  with self.assertRaises(g.Hold):
   # Check proof pin consistency without modifying the persistent ledger
   if st['r31_source']['source_manifest_sha']!=g.sha(g.evidence_manifest()):raise g.Hold('tampered')
 def test_adjacency_required(self):
  st,_,_=g.checked(self.db)
  state=ActorActionState(g.AID,5,120,(g.ACTION_ID,),enemy_ids_visible=(g.TID,),range_confirmed=False)
  q=action_menu(state,(g.ability(),),strict=True,source_evidence=(g.proof(),))
  self.assertEqual(len(q.legal_options),0)
 def test_rd5_invariant_for_physical_subtags(self):
  out=[mitigate((DamageComponent(22,tag,'RABADA'),),Resistances(5,())).effective for tag in ('impacto','perfurante','cortante')]
  self.assertEqual(out,[17,17,17])
 def test_qa_native_0_receipt_replay(self):
  out=g.execute_conditioned_for_qa(self.db,0)
  self.assertFalse(out['effect']['official_death_derived']);self.assertEqual(out['effect']['roll_score'],21)
  self.assertEqual(out['effect']['before_hp'],38);self.assertEqual(out['effect']['after_hp'],21)
  self.assertEqual(g.replay_verify(self.db)['status'],'PASS_R18_JOURNAL_AND_NATIVE_V081_REPLAY')
 def test_qa_native_6_receipt_replay(self):
  out=g.execute_conditioned_for_qa(self.db,6)
  self.assertEqual(out['effect']['roll_score'],27)
  self.assertEqual(out['effect']['net'],17)
  self.assertFalse(g.replay_verify(self.db)['fully_admitted'])
 def test_no_duplicate_effect(self):
  g.execute_conditioned_for_qa(self.db,0)
  with self.assertRaises(g.Hold):g.execute_conditioned_for_qa(self.db,0)
  self.assertEqual(g.checked(self.db)[2],1)
 def test_no_extra_pa_or_reaction(self):
  g.execute_conditioned_for_qa(self.db,6);st,_,_=g.checked(self.db)
  self.assertEqual(st['actors'][g.AID]['resource']['pa'],120)
  self.assertEqual(st['actors'][g.AID]['resource']['standard'],0)
  self.assertEqual(st['actors'][g.TID]['resource']['pa'],22)
  self.assertEqual(st['actors'][g.TID]['resource']['reaction'],1)
 def test_sqlite_pending_zero(self):
  g.execute_conditioned_for_qa(self.db,6)
  with sqlite3.connect(self.db) as con:
   self.assertEqual(con.execute('pragma integrity_check').fetchone()[0],'ok')
   self.assertEqual(con.execute('select count(*) from pending').fetchone()[0],0)
   self.assertEqual(con.execute('select count(*) from events').fetchone()[0],1)
 def test_status_after_execution(self):
  g.execute_conditioned_for_qa(self.db,0)
  st=g.status(self.db)
  self.assertEqual(st['catalog']['status'],'ACTION_ALREADY_EXECUTED')
  self.assertEqual(st['hp'][g.TID],21)

if __name__=='__main__':unittest.main(verbosity=2)
