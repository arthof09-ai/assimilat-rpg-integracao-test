# VLAB R31 — Reprodução Mestre-only sem modificar história

## Pré-requisitos
Python 3.11+, biblioteca padrão. R27 original: `VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip` SHA `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`.

O presente ZIP R31 contém somente **incremento**, snapshots/reports, os dois bancos condicionais de R31 e checkpoints. Não reempacota 21 MB de runtime prévio. Extraia a R27 no subdiretório `r27/` e a R31 no mesmo diretório-pai, deixando `extension/` ao lado de `r27/`.

```
PYTHONPATH=./r27/fusion_stage12 python ./extension/test_r31_real_source_gateway.py
```

A execução acima usa diretórios temporários, valida fonte, catálogo, dois ensaios condicionais e replay, sempre em bases **novas**. NÃO toca a Biblioteca Notion.

Para reproduzir a evidência já emitida: carregar via Python `vlab_r31_real_source_gateway.replay_verify(path_para_sqlite)` e `verify_checkpoint(path_para_zip)`, preservando os arquivos originais.

O entrypoint `execute_authorized` recusa o despacho **plenamente autorizado** sem decisão expressa do Mestre sobre Luta e sua evidência lida fisicamente. O arquivo `authority/MESTRE_LUTA_DECISION_VERIFIED.json` NÃO acompanha esta entrega e **não deve ser inventado**. Após decisão e NAC-NORM, a evidência deve ser gerada por Comestre competente em continuidade, com escopo apenas B (sandbox).

A portabilidade depende de R27 original; nenhum código histórico foi patchado. O `unified_gateway.verify_pins` preserva hashes de quatro módulos antigos. O ramo de fonte real chama `vlab_effects_v08.apply_weapon_attack` e utiliza `vlab_r18_interactive.event_commit` para o journal. O nível v0.9+ continua explicitamente synthetic-only e não foi modificado.

Não use os resultados QA como acontecimentos da campanha, nem os 0/+6 condicionais como decisão normativa.
