# PSV — VLAB R31 | Gateway de fontes reais, Rabada nativa condicionada e decisão pendente

**Operação existente:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01  
**Emissão:** 15/10/2026 (Mestre-only)  
**Natureza:** Desenvolvimento aditivo isolado + prova nativa reproduzível + decisão Mestre no Notion  
**Baseline:** R27 ANTES, R28, R29, R30, DMG-RANK-01 v1.1 **intactos**  
**Limite:** experimentação com fichas *fonte real*, não personagem fictício, **não acontecimento canônico**.

## 1. Avanço funcional, sem crédito indevido

O R30 comprovou `NONCANONICAL_SCENE_ONLY` no **RebuiltManualRuntime v0.9+**. A R31 não suprimiu esse bloqueio nem editou esse motor. Implementou uma **porta aditiva de admissão de fonte real** que valida a proveniência documental e chama o **resolvedor ORIGINAL v0.8.1 `apply_weapon_attack`** diretamente, preservando o **journal original R18 SQLite WAL** (`init_db` / `event_commit` / `history` / `load`) e seus controles de intenção durável, `revision`, `head`, `before_sha`, `after_sha` e idempotência. Não criou uma nova física de combate.

**Fonte real admitida:** 2/2 combatentes; Frígido Ossário B5 e Cabra de Chifres B1, IDs de páginas reais e valores impressos conservados.  
**Ação fonte reconhecida pelo ActionCatalog `strict=True`:** 1/1, `FRIGIDO_RABADA_MESTRE_20261015`; campos Mestre expressamente decididos completos na descrição da habilidade.  
**Ações com TODOS os requisitos normativos admitidos:** **0/1** — o bônus individual de Luta da Rabada permanece NÃO DETERMINADO. Não creditar uma ação legal integral por um cenário de treinamento hipotético.

**Execuções nativas fonte-real condicionais, sem crédito de plena legalidade:** **2/2** (Luta 0 versus Luta +6, ambos declaradamente contrafactuais). O núcleo executou um ataque do mesmo Frígido contra a mesma Cabra em **dois bancos LAB distintos** com a mesma semente 211.  
**Replays nativos sobre estado novo:** **2/2 PASS**; SQLite integrity **2/2 ok**, `pending` **0/2**, checkpoints portáteis **2/2 PASS**, cabeçalhos `head` diferentes e estáveis.  
**Testes R31:** **13/13 PASS**; regressão R27 executada separadamente **10/10 PASS**. Teste não substitui certificação canônica.

## 2. Decisão expressa do Mestre: registrada e reaberta

- Mestre decidiu especificamente para `Rabada` do **Frígido Ossário**: ataque natural **físico**, **corpo a corpo**, **alvo adjacente**, **1 Ação Padrão**, **0 custo adicional de PA**, `1d6 + FOR`, **nenhum rider obrigatório**.
- Incluída e fisicamente reaberta na **OP-VLAB-FUSION-SANDBOX-01** como `DECISÃO EXPRESSA DO MESTRE — RABADA DO FRÍGIDO OSSÁRIO / R31 / 15-10-2026`.
- A ficha-mãe **não foi modificada**; a nota operacional na OP não é uma alteração normativa geral de ataques naturais. Nenhum bônus de proficiência foi decidido nessa seção.

## 3. Fichas fonte e cenário: o que é dado real versus escolha experimental

| Campo | Frígido Ossário | Cabra de Chifres | Proveniência |
|---|---:|---:|---|
| ID Notion | `f0dc2b32-4ede-820a-b947-0168d4a53315` | `391c2b32-4ede-8252-b0cc-810423cdbfa6` | páginas reais Mestre |
| Rank/estrela | Bronze 5 | Bronze 1 | fichas impressas |
| FOR | 18 | 13 | fichas |
| CON | 15 | 10 | fichas |
| CA | 31 | 20 | fichas |
| Vida inicial | 125 | 38 | fichas impressas preservadas |
| Alma inicial | 120 | 22 | fichas |
| RD geral do alvo | — | 5 | Criação de Besta vigente |
| Distância | A e B adjacentes | A e B adjacentes | **escolha de cena LAB autorizada**, não local de campanha |
| Ação inicial | Rabada | alvo passivo | **política experimental de uma ação**, não turno de combate canônico |
| Reações voluntárias | — | nenhuma declarada no ensaio | **política experimental**; a Cabra mantém 1 slot de Reação disponível |
| Bônus de Luta da Rabada | **INDETERMINADO** | — | ambiguidade de vínculo da proficiência geral +6 |

**Tag de dano:** o Mestre definiu natureza **física**, não subtipo impacto/perfurante/cortante. Para a chamada de transporte tipado do resolvedor v0.8.1 foi usada a etiqueta interna `impacto`, **sem atribuí-la à ficha/cânone**. A única defesa usada foi RD **geral 5**. O oráculo nativo demonstrou equivalência do dano líquido 17 para `impacto`, `perfurante` e `cortante` diante da RD5 geral; NÃO admitir essa etiqueta em cenários com resistência específica sem esclarecer o subtipo.

**Autenticação documental proporcional:** a fonte foi reaberta pelo conector Notion neste trabalho; os excertos observados, URLs, tempos de última edição e decisão da OP são congelados em `R31_SOURCE_ATTESTATION_MASTER_ONLY.json`. O SHA é de **snapshot local de transcrição**, NÃO assinatura criptográfica emitida pelo Notion. A fonte é real, mas não se declara estado vivo de campanha.

## 4. Recibos nativos: semente 211, Ação Padrão e HP ANTES/DEPOIS

O RNG histórico, separado por domínio/etiqueta para o evento, deu **d6 de ataque 3** e **d6 de dano 4** nas duas condições. Sequência verificadora de crítico `[4,5,5]`: não desencadeou positivo nem falha crítica. Um ataque foi executado **uma vez em cada banco novo**; nenhuma retentativa sobre estado comprometido.

| Medida | Luta 0 (hipótese) | Luta +6 (hipótese) |
|---|---:|---:|
| Ataque | 3+18+0 = **21** | 3+18+6 = **27** |
| CA | 20 | 20 |
| `hit` nativo | true | true |
| Dano bruto | 4+18 = **22** | **22** |
| RD geral | **5** | **5** |
| Dano líquido nativo | **17** | **17** |
| Vida Cabra LAB | **38 → 21** | **38 → 21** |
| Vida Frígido LAB | 125 → 125 | 125 → 125 |
| PA Frígido LAB | 120 → 120 | 120 → 120 |
| Ação Padrão | 1 → 0 | 1 → 0 |
| Reação Cabra | 1 → 1 | 1 → 1 |
| Replay | PASS | PASS |
| SQLite `integrity_check` | ok | ok |
| Intenções pendentes | 0 | 0 |
| Mundo oficial | **SEM EFEITO** | **SEM EFEITO** |

Os dois cenários têm **uma semente compartilhada**, não duas unidades independentes de amostragem estatística. Eles demonstram capacidade de trânsito até o núcleo e sensibilidade de precisão, não estimativa de probabilidade de vitória.

**Houve um reparo de validação do replay antes da entrega:** o `after_hp` era representado numa lista com ordem de inserção variável entre genesis e estado serializado por chaves. A normalização para ordem de IDs tornou o replay estável **sem modificar as linhas/eventos dos bancos já comprometidos**. O estado original foi preservado e reaberto.

## 5. Regras e limites de segurança concretos

- A porta admite somente dois **IDs físicos Notion Mestre** conhecidos e seu contrato específico, não uma autorização genérica de todas as fontes. O `RebuiltManualRuntime` original permanece intocado e rejeitando fonte real; a admissão nova é anterior ao **`apply_weapon_attack` v0.8.1 original**.
- `ActionCatalog(strict=True)` exige `EXPLICIT-CANON` para a ação, evidência de fonte congelada, slot padrão, adjacência e alvo válido. A assinatura da ação ficou pronta, mas a **execução plenamente legal exige bônus de Luta separado**.
- Ausência de decisão Luta faz `execute_authorized(...)` retornar `MESTRE_LUTA_DECISION_STILL_REQUIRED` **antes de criar intenção ou aplicar efeito**. Isso foi testado em banco novo e o `pending` permaneceu zero. Não existem defaults silenciosos de 0/+6.
- Uma decisão futura só ingressará no caminho integral mediante arquivo de evidência da decisão do Mestre fisicamente reaberta e vinculado à OP; o R31 não distribui esse arquivo porque a decisão não foi tomada.
- **Não executar a mesma ação duas vezes** sobre o mesmo save; proteção de revisão/ledger verificada.
- A política experimental `NO_VOLUNTARY_REACTION` não desabilita o recurso do alvo; não é prova de que a Cabra não reagiria em um combate.
- Fonte Mestre-only permanece em ambiente LAB. Nenhuma escrita em ficha de Besta, Party, O Primeiro, DMG-RANK, recursos produtivos ou gateway compartilhado.

## 6. Ciência independente e fronteiras

O novo experimento **não repete** R27 (320 configurações), R29 (iniciativa) ou R30 (oráculos). Usa uma habilidade natural autenticada e resolve nativamente seu custo de Ação Padrão e dano específico. A RD geral5 reduziu o bruto22 para17; a divergência de proficiência mudou o teste de21 para27 sem afetar o dano desta semente. O êxito do ataque no ensaio é robusto às duas hipóteses, mas a decisão normativa continua imprescindível para o crédito C.

Fronteira Bronze 5 → Prata 1 permanece **matemática/fonte-específica**, não combate integral. O Rinolupo mantém RDF10 e o problema de empilhamento RD15/RDF10 pendente. Não foram acrescentados novos testes de iniciativa, Reações integradas ou lutas completas entre ranks nesta rodada porque a prioridade material era abrir a via funcional de fontes reais.

## 7. PSV e retomada sem duplicata

| Indicador | R31 final |
|---|---:|
| Gateway real-source isolado | **Implementado, exercitado com receipts/replay condicionais** |
| Fichas reais admitidas como fontes | **2/2** |
| Assinaturas de ação nomeada documentalmente completas | **1/1** (Rabada) |
| Ações integralmente admitidas normativamente | **0/1** (Luta pendente) |
| Ações condicionais nativas real-source | **2/2** |
| Combates reais completos (fontes reais, ações integralmente admitidas) | **0/0 tentados** |
| Cenas condicionais novas | 2 |
| Cenas interrompidas novas | 0 |
| Replays/checkpoints novos | 2/2 cada |
| Scripts de regressão R31 | 13/13 PASS |
| Regressão baseline R27 | 10/10 PASS |
| Patamares com combates completos de Bestas reais | **0/25** |
| Patamares com combates condicionais R27 | **1/25** Bronze1 (histórico) |
| Fronteiras matemáticas herdadas | 4/4 |
| Fronteiras com lutas completas | 0/4 |
| Contratos terminais VLAB | **0/17** |
| Células canônicas | **0/1.875** |
| Fonte Mestre/Party/O Primeiro modificada | **0** |
| R01–R30 e estados UNKNOWN_EFFECT/seed53 | preservados, sem reabertura mutativa |
| DMG R31 integração binária F0–F6 | não reivindicada |

**NAC-PASS-02:** gates proporcionais da porta sandbox **PASS LOCAL (13/13, readback 2/2, source reread)**; NAC-PASS terminal de promoção e writer/lease/epoch/fencing/GREEN **HOLD**. Nenhum percentual global fictício.

**Retomada exata:** escolher o bônus de Luta aplicável à **Rabada do Frígido Ossário** sob autoridade Mestre (0, +6 ou outro expresso); registrar a decisão na OP / reabrir; gerar evidência vinculada de Luta; no mesmo gateway novo, criar um **novo** banco de evento plenamente admitido, preservar os dois históricos condicionais, executar 1 ação nativa, reabrir recibo e checkpoint/replay. Resolver subtipo físico somente se um alvo futuro possuir resistência específica. A RD/RDF do Rinolupo continua operação científica separada.

**Pergunta mínima ao Mestre:** qual bônus de **Luta** devo aplicar especificamente à Rabada do Frígido Ossário: +6 por proficiência geral Bronze, 0 por não possuir Luta treinada, ou outro valor explicitamente estabelecido?
