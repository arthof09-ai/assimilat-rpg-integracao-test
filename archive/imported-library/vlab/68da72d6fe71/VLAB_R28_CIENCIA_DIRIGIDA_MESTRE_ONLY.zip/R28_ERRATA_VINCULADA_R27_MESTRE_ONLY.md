# ERRATA VLAB R27 — correção vinculada, SEM reescrever baseline

**Operação existente:** OP-VLAB-FUSION-SANDBOX-01 · **Autoridade:** Ordem Suprema do Mestre — Continuidade Científica Pós-R27, 15/10/2026.  
**Natureza:** retificação documental sem mutação do R27, do DMG-RANK v1.1 ou de qualquer ficha.  
**Fonte preservada:** `/Comestre/OP-VLAB-FUSION-SANDBOX-01/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip`, SHA-256 `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`.

1. **Template de RD não resolvido:** no relatório R27 §7 aparece o literal `{t['sum_rd_mitigation_actual']}/{t['sum_raw_damage_observed']}`. O correto é **9.391/19.913 pontos de dano bruto de acertos absorvidos por RD = 47,16%**, conforme totais da R27. A errata corrige exibição, não reconta ataques.
2. **Template de perfis/sementes não resolvido:** no relatório R27 §8 aparece `{list(D['universe']['profiles'])}`. Perfis: OFENSIVO, DEFENSIVO, EQUILIBRADO, ASSIMETRICO. Sementes de cada célula: **11, 23, 37, 41, 53, 67, 71, 83, 97, 101, 113, 127, 131, 149, 157, 163, 173, 181, 191, 197**; 16 células ordenadas × 20 = 320 configurações, sendo 120 combates condicionais completos e 200 censuras por impossibilidade de acerto sob a política.
3. **Intervalos Wilson indevidos em células inteiramente censuradas:** intervalos como `0,0–16,1%` obtidos tratando 0/20 casos censurados como 20 derrotas NÃO são estimativas válidas de vitória. Retificar interpretação para **NÃO ESTIMÁVEL (0 combates executados naquela célula)**. As 20 configurações permanecem no denominador planejado como censuras estruturais, não derrotas.
4. **Precisão condicional:** “impossibilidade de acerto” na R27 significa *somente sob `1d6+FOR+Luta6`, comparação estrita `>CA`, sem habilidade, arma, vantagem/reação ou crítico autoacerto não documentado*. O documento de combate define crítico e dano crítico, mas não constitui autorização para classificar crítico positivo como acerto automático. Não extrapolar os 200 impasses para criaturas oficiais.
5. **Treinamento:** Criação de Besta documenta +6 de proficiência de Bronze normal, mas a R27 explicitou alocação experimental à perícia Luta; a ficha individual de Besta não certifica necessariamente essa seleção. `Luta+6` continua hipótese da coorte, não variável confirmada de toda Besta.
6. **Dependência pareada:** `28/40` vitórias do Equilibrado são 40 execuções organizadas em **20 blocos de semente**. Não usar erro padrão de 40 observações IID. A análise R28 encontrou todos os 40 jogos com Equilibrado atuando primeiro; a iniciativa não foi isolada na R27.

**Status:** CORRIGIDO em errata, **R27 histórica preservada**; nenhuma nova regra, homologação ou vitória canônica. Comparativos ANTES×DEPOIS deverão citar ambas as versões, baseline R27 e esta errata.
