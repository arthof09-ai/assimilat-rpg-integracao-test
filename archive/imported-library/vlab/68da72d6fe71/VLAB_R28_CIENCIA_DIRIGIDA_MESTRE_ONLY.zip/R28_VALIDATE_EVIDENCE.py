#!/usr/bin/env python3
"""Read-only audit of historical R27, new R28 contrasts, and controlled holds."""
import pathlib,sqlite3,hashlib,json,sys,zipfile,math
ROOT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT/'work'/'fusion_stage12'))
import vlab_r27_scientific_baseline as r
import R28_DIRECTED_FIXTURE_RUNNER as fixture
SRC=pathlib.Path('/mnt/data/vlab_recovery/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip')
EXPECT='d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1'
checks=[]
def check(name,passed,detail=None):
 checks.append({'name':name,'passed':bool(passed),'detail':detail})
 if not passed: print('FAIL',name)
check('R27_original_zip_hash_unchanged',hashlib.sha256(SRC.read_bytes()).hexdigest()==EXPECT)
check('R27_unknown_holds_unchanged_inside_immutable_archive',zipfile.is_zipfile(SRC))
# Native receipts from new contrast. Reopen with the right in-memory fixture and authenticate ledger.
base=ROOT/'runs'/'OFF_FIRST'/'LR'
valid=[]
for rp in sorted(base.glob('*.json')):
 doc=json.loads(rp.read_text()); db=base/(rp.stem+'.sqlite')
 fixture.bind_fixture('OFF_FIRST')
 st,head,rev=r.checked(db)
 rowcount=sqlite3.connect(db).execute('select count(*) from events').fetchone()[0]
 n=doc['summary']['native_trace_count']
 ok=(head==doc['head'] and rev==doc['revision'] and rowcount==rev and
     len(r.history(db)['events'])==rev and n==doc['summary']['attacks'] and
     hashlib.sha256(db.read_bytes()).hexdigest()==doc['sqlite_sha256'] and
     doc['status']=='COMPLETE_CONDITIONAL_RULE_DERIVED')
 check('R28_native_receipt_'+rp.stem,ok,{'attacks':n,'revision':rev,'events_a1':st['r21_control']['events'].__len__()})
 valid.append({'id':rp.stem,'status':doc['status'],'rev':rev,'sha':doc['sqlite_sha256']})
# Timeout interrupted seed53 but pending journal confirmed empty; it is not a completion.
p=base/'EQUILIBRADO__OFENSIVO__SEED_53.sqlite'
partial=None
if p.exists():
 fixture.bind_fixture('OFF_FIRST')
 st,head,rev=r.checked(p)
 conn=sqlite3.connect(p);n=conn.execute('select count(*) from pending').fetchone()[0];conn.close()
 partial={'status':st['phase'],'revision':rev,'pending':n,'head':head,'dbsha':hashlib.sha256(p.read_bytes()).hexdigest(),
          'action':'NO_RETRY_BEFORE_REOPEN_AND_INTENT_CLASSIFICATION'}
 check('R28_interrupted_seed53_kept_separate',st['phase']!='COMPLETE_LAB' and n==0)
# Basic exact math automated sanity.
maths=json.loads((ROOT/'results'/'R28_EXACT_MATH.json').read_text())
row=next(a for a in maths['matrix'] if a['attacker']=='EQUILIBRADO' and a['defender']=='DEFENSIVO')
check('R28_E_D_hit_threshold',row['base_p']==0 and row['change_accuracy_+1']==0 and row['change_accuracy_+2']==1/6)
check('R28_RD_DME',math.isclose(next(a for a in maths['rd_curves'] if a['rd']==5)['mean_net_on_hit'],1193/216,rel_tol=1e-14))
front=json.loads((ROOT/'results'/'R28_BOUNDARY_CONDITIONAL_DAMAGE_EXACT.json').read_text())
check('R28_B5_P1_ratio',math.isclose(front[0]['expected_net_ratio_if_both_hit'],230.4))
check('R28_ON5_L1_nonpositive',front[3]['lower_to_higher']['E_net_conditional_hit']==0)
paired=json.loads((ROOT/'results'/'R28_PAIRED_CAUSAL_ANALYSIS.json').read_text())
check('R28_20_cluster_40_fights',paired['paired_blocks_n']==20 and paired['mirrored_combat_records']==40 and paired['EQ_win_total']==28)
out={'operation':'OP-VLAB-FUSION-SANDBOX-01','mode':'READ_ONLY_MATH_AND_EXPERIMENTAL_SANDBOX',
 'checks':checks,'pass_count':sum(x['passed'] for x in checks),'check_count':len(checks),
 'new_native_complete':len(valid),'new_native_receipts':valid,
 'interrupted_new_seed53':partial,
 'historical_r27_held_intents_not_touched':2,'r27_source_sha256':EXPECT,'canonical_credit':0}
(ROOT/'results'/'R28_AUDIT_READBACK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('AUDIT',out['pass_count'],'/',out['check_count'],'new native',len(valid),'partial',partial)
assert out['pass_count']==out['check_count']
