import json,pathlib,random,statistics,collections,sqlite3
ROOT=pathlib.Path(__file__).parent
R=ROOT/'work'/'reconstruction'/'r27_delivery'/'runs'/'receipts'
S=[11,23,37,41,53,67,71,83,97,101,113,127,131,149,157,163,173,181,191,197]
pairs=[]
for seed in S:
 l=json.loads((R/f'EQUILIBRADO__OFENSIVO__SEED_{seed}.json').read_text());r=json.loads((R/f'OFENSIVO__EQUILIBRADO__SEED_{seed}.json').read_text())
 a=int(l['winner']=='LAB_PERSONALIZADO_1');b=int(r['winner']=='LAB_PERSONALIZADO_2')
 pairs.append({'seed':seed,'EQ_left_win':a,'EQ_right_win':b,'sum_Eq_wins_out_of2':a+b,'EQ_left_rounds':l['round_reached'],'EQ_right_rounds':r['round_reached']})
rng=random.Random(20261015)
N=30000
boots=[]
for _ in range(N):
 sample=[pairs[rng.randrange(len(pairs))] for _ in pairs]
 boots.append(sum(x['sum_Eq_wins_out_of2'] for x in sample)/(len(sample)*2))
boots.sort();ci=[boots[int(0.025*N)],boots[int(0.975*N)]]
assert sum(x['sum_Eq_wins_out_of2'] for x in pairs)==28
cnt=dict(collections.Counter(x['sum_Eq_wins_out_of2'] for x in pairs))

# Existing OFF_FIRST complete receipts are tiny, not an estimate with precision.
D=ROOT/'runs'/'OFF_FIRST'/'LR'
off=[]
for j in S:
 p=D/f'EQUILIBRADO__OFENSIVO__SEED_{j}.json'
 if p.exists():
  t=json.loads(p.read_text());orig=json.loads((R/f'EQUILIBRADO__OFENSIVO__SEED_{j}.json').read_text());
  off.append({'seed':j,'R27_EQ_win':int(orig['winner']=='LAB_PERSONALIZADO_1'),'OFF_FIRST_EQ_win':int(t['winner']=='LAB_PERSONALIZADO_1'),
  'new_rounds':t['round_reached'],'new_head':t['head'],'new_db_sha256':t['sqlite_sha256']})

# Source-informed reallocation, not proof of legitimate training.
trade=[]
for t in range(0,10):
 FOR=12+t; DES=9-t; CA=10+DES+2
 pE=sum((k+FOR+6)>25 for k in range(1,7))/6
 pD=sum((k+6+6)>CA for k in range(1,7))/6
 trade.append({'points_shift_DES_to_FOR':t,'FOR_E':FOR,'DES_E':DES,'CA_E':CA,
  'P_E_hit_DEF':pE,'P_DEF_hit_E':pD,'E_HP':50,'DEF_HP':55,'attribute_budget':43,
  'training_plus6_still_unattested':True,'effect_E_initiative':'decreases by shifted amount'})
res={'paired_20_seed_blocks':pairs,'EQ_win_total':28,'paired_blocks_n':20,'mirrored_combat_records':40,
 'paired_block_bootstrap95_E_win':ci,'bootstrap_draws':N,'seed':20261015,'per_block_distribution_0_1_2':cnt,
 'off_first_native_new_complete_n':len(off),'off_first_new_vs_old':off,'source_derived_tradeoff':trade,
 'interpretation':'R27 outcomes correlated by shared RNG seed across side inversion. Bootstrap treats each SEED pair as ONE independent cluster, not 40 fights.'}
(ROOT/'results'/'R28_PAIRED_CAUSAL_ANALYSIS.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print('CI',ci,'blocks',cnt,'counterfactuals',off,'trade',trade)
