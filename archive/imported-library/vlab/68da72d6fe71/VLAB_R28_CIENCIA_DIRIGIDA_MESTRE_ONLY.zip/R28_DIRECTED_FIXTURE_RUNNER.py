#!/usr/bin/env python3
"""OP-VLAB-FUSION-SANDBOX-01 / pós-R27.
Experimental fixture wrapper, NOT a new combat engine.
Imports unchanged historical R27/R26/R25/R18 + v0.7/v0.8.1, mutates only
in-memory fixture functions and pins the experimental contrast in SQLite genesis.
Never touches R27 files or UNKNOWN_EFFECT held intents.
"""
import json,sys,hashlib,pathlib,collections,statistics,argparse,os
ROOT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT/'work'/'fusion_stage12'))
import vlab_r27_scientific_baseline as r

ORIGINAL_ROSTER=r.roster
ORIGINAL_MANIFEST=r.manifest
SEEDS=list(r.SEEDS)

EXPERIMENTS={
 'OFF_FIRST':{'left':'EQUILIBRADO','right':'OFENSIVO','seeds':SEEDS,'max_rounds':24,
  'description':'Counterfactual +12 initiative bonus for OFF, guaranteed earlier turn; rest unchanged',
  'offsets':{'OFENSIVO':{'init_bonus':12}},'source_status':'CONTRAFACTUAL_NONCANONICAL'},
 'EQ_HP_PLUS5':{'left':'EQUILIBRADO','right':'OFENSIVO','seeds':SEEDS[:10],'max_rounds':24,
  'description':'One-factor sensitivity +5 lab HP to EQ, no claims of legit source',
  'offsets':{'EQUILIBRADO':{'hp':5}},'source_status':'CONTRAFACTUAL_NONCANONICAL'},
 'EQ_CA_PLUS6':{'left':'EQUILIBRADO','right':'OFENSIVO','seeds':SEEDS[:10],'max_rounds':24,
  'description':'One-factor sensitivity CA +6 to EQ (unproven standalone source)',
  'offsets':{'EQUILIBRADO':{'ca':6}},'source_status':'CONTRAFACTUAL_NONCANONICAL'},
 'EQ_D_FOR2_DES_MINUS2':{'left':'EQUILIBRADO','right':'DEFENSIVO','seeds':SEEDS[:8],'max_rounds':96,
  'description':'Redistribute EQ 2 attribute points DES->FOR, preserving total 43, CON, HP, PA; legal allocation mathematics, no trained Luta proof',
  'offsets':{'EQUILIBRADO':{'for':2,'des':-2,'ca':-2}},'source_status':'RULE_DERIVED_ALLOCATION_CONDITIONAL'},
 'EQ_D_LUTA_PLUS2':{'left':'EQUILIBRADO','right':'DEFENSIVO','seeds':SEEDS[:8],'max_rounds':96,
  'description':'Training +2 sensitivity isolated; not an authenticated individual proficiency',
  'offsets':{'EQUILIBRADO':{'luta':2}},'source_status':'CONTRAFACTUAL_NONCANONICAL'}
}

def bind_fixture(key):
 spec=EXPERIMENTS[key]
 def fx_roster(left,right):
  a=ORIGINAL_ROSTER(left,right)
  for i,who in enumerate((left,right)):
   for field,d in spec['offsets'].get(who,{}).items():
    a[i][field]+=d
  return a
 def fx_manifest(left,right,kind):
  m=ORIGINAL_MANIFEST(left,right,kind)
  m['experimental_contrast']={'id':key,'description':spec['description'],
   'offsets':spec['offsets'],'source_status':spec['source_status'],
   'run_protocol':'R28-P0-ISOLATED-FIXTURE-SENSITIVITY',
   'official_rules_unchanged':True,'canonical_credit':0,
   'module_sha256':hashlib.sha256((ROOT/'work'/'fusion_stage12'/'vlab_r27_scientific_baseline.py').read_bytes()).hexdigest()}
  return m
 r.roster=fx_roster; r.manifest=fx_manifest

def run_one(key,seed,swap=False):
 spec=EXPERIMENTS[key];bind_fixture(key)
 left,right=(spec['right'],spec['left']) if swap else (spec['left'],spec['right'])
 base=ROOT/'runs'/key/('RL' if swap else 'LR')
 db=base/(left+'__'+right+'__SEED_'+str(seed)+'.sqlite')
 # NEVER auto-resume a partial or unknown-effect native run after an interrupted tool.
 # This is a new fixture experiment, not a transaction recovery authority.
 receipt_file=base/(left+'__'+right+'__SEED_'+str(seed)+'.json')
 if db.exists() and not receipt_file.exists():
  raise RuntimeError('EXISTING_INCOMPLETE_OR_UNKNOWN_EFFECT_HOLD_NO_AUTO_RETRY: '+str(db))
 if db.exists() and receipt_file.exists():
  doc=json.loads(receipt_file.read_text())
  st,head,rev=r.checked(db)
  if hashlib.sha256(db.read_bytes()).hexdigest()!=doc['sqlite_sha256'] or head!=doc['head'] or rev!=doc['revision']:
   raise RuntimeError('EXISTING_RECEIPT_MISMATCH_HOLD: '+str(db))
  return doc
 res=r.run(base,seed,left,right,max_rounds=spec['max_rounds'])
 # verify event evidence and source pin without altering the SQLite.
 st,head,rev=r.checked(db)
 assert res['head']==head and res['revision']==rev
 assert st['r27_science']['configuration']['experimental_contrast']['id']==key
 assert hashlib.sha256(db.read_bytes()).hexdigest()==res['sqlite_sha256']
 output={k:res[k] for k in ('id','seed','status','censor_reason','left','right','winner','round_reached','revision','head','config_sha','sqlite_sha256','summary','initial_preflight')}
 output['experiment']=key;output['swap']=swap;output['first_actor']=None
 if res['revision']:
  import sqlite3
  con=sqlite3.connect(db)
  row=json.loads(con.execute('SELECT row_json FROM events WHERE seq=1').fetchone()[0]);con.close()
  order=row['detail']['inner']['order'];output['first_actor']=left if order[0].endswith('_1') else right
 else:
  output['first_actor']=None
 path=base/(res['id']+'.json')
 if not path.exists():path.write_text(json.dumps(output,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 else:assert json.loads(path.read_text())==output
 return output

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--experiment',choices=['ALL']+list(EXPERIMENTS),default='ALL');args=parser.parse_args()
 keys=list(EXPERIMENTS) if args.experiment=='ALL' else [args.experiment]
 findings=[]
 for key in keys:
  spec=EXPERIMENTS[key]
  for swap in (False,True):
   for seed in spec['seeds']:
    try:
     x=run_one(key,seed,swap=swap)
     findings.append(x)
     print(key,'swap',int(swap),'seed',seed,'status',x['status'],'win',x['winner'],'first',x['first_actor'],'rounds',x['round_reached'],flush=True)
    except Exception as ex:
     fail={'experiment':key,'seed':seed,'swap':swap,'error':type(ex).__name__+': '+str(ex)}
     findings.append(fail);print('FAILED',fail,flush=True)
  (ROOT/'results').mkdir(exist_ok=True)
  (ROOT/'results'/(key+'.json')).write_text(json.dumps([x for x in findings if x['experiment']==key],ensure_ascii=False,indent=2)+'\n')
 (ROOT/'results'/'INDEX.json').write_text(json.dumps(EXPERIMENTS,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 return 0 if not any('error' in f for f in findings) else 1
if __name__=='__main__':raise SystemExit(main())
