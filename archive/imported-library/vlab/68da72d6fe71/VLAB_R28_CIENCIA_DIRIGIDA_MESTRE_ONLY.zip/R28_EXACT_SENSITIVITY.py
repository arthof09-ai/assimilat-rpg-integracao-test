#!/usr/bin/env python3
"""Independent exhaustive mathematics, NOT battle execution or a new game engine."""
from collections import Counter
from fractions import Fraction
import json, math, pathlib,itertools,random,statistics
OUT=pathlib.Path(__file__).parent/'results'; OUT.mkdir(exist_ok=True)
P={
 'OFENSIVO':{'FOR':20,'DES':4,'CON':10},
 'DEFENSIVO':{'FOR':6,'DES':12,'CON':15},
 'EQUILIBRADO':{'FOR':12,'DES':9,'CON':10},
 'ASSIMETRICO':{'FOR':2,'DES':22,'CON':10}}

def ca(p):return 10+p['DES']+p['CON']//5

def probability_hit(a,b,luta=6,bonus=0,ca_delta=0):
 return sum(k+a['FOR']+luta+bonus>ca(b)+ca_delta for k in range(1,7))/6

matrix=[]
for x,y in itertools.product(P,repeat=2):
 p=P[x];q=P[y]
 row={'attacker':x,'defender':y,'CA':ca(q),'FOR':p['FOR'],'luta_base_experimental':6,'base_p':probability_hit(p,q)}
 for delta in [-2,-1,0,1,2]:
  row[f'change_accuracy_{delta:+d}']=probability_hit(p,q,bonus=delta)
  row[f'change_target_CA_{delta:+d}']=probability_hit(p,q,ca_delta=delta)
 for prof in [0,2,4,6,8,12,18]:row[f'luta_{prof}']=probability_hit(p,q,luta=prof)
 row['min_attack_accuracy_plus_to_open']=max(0,ca(q)+1-(6+p['FOR']+6))
 matrix.append(row)
# Count pair viability under equal modifiers to BOTH actors.
thresholds=[]
for bonus in range(0,13):
 viable=sum(probability_hit(P[x],P[y],bonus=bonus)>0 or probability_hit(P[y],P[x],bonus=bonus)>0 for x,y in itertools.product(P,repeat=2))
 thresholds.append({'bonus_both':bonus,'at_least_one_direction_hit_possible':viable,'old_censored_unlocked':viable-6})

DAMAGE=Counter(sum(x) for x in itertools.product(range(1,7),repeat=3))
def netdist(rd,positive_critical=False):
 out=Counter()
 for v,n in DAMAGE.items():
  net=max(v + (18 if positive_critical else 0)-rd,0)
  out[net]+=n
 return {k:Fraction(n,216) for k,n in out.items()}

def metrics_rd(rd):
 n=netdist(rd)
 avg=sum(k*v for k,v in n.items())
 prob_nonzero=sum(v for k,v in n.items() if k>0)
 return {'rd':rd,'mean_raw':10.5,'mean_net_on_hit':float(avg),'prob_zero_net_on_hit':float(n.get(0,0)),
  'fraction_raw_absorbed':(10.5-float(avg))/10.5, 'prob_positive_net_on_hit':float(prob_nonzero)}
rd_table=[metrics_rd(x) for x in [0,2,3,5,7,10,12,15,18,20]]

# One action: independent crit verification 3d6 with 2/216 positive, 2/216 negative.
# One hit die always >CA for E vs O; poscrit does NOT change hit resolution.
CRIT=Fraction(2,216)
ordinary=netdist(5,False);positive=netdist(5,True)
out=Counter()
for dmg,pr in ordinary.items():out[dmg]+=pr*(1-2*CRIT)
for dmg,pr in positive.items():out[dmg]+=pr*CRIT
out[0]+=CRIT
assert sum(out.values())==1
# For any stochastic independent identically-distributed attack processes in both actors,
# number of actions to KO is discrete variable T. The first actor wins if TA <= TB;
# due to exchangeability, P(first wins)=(1+P(TA=TB))/2.
# T distribution via absorbing Markov by HP remaining. DP with zero-dmg probabilities.
N=50
state=[0.0]*(N+1);state[N]=1.0
ko_time=[]
probs={k:float(v) for k,v in out.items()}
for turn in range(1,400):
 nxt=[0.0]*(N+1);ko=0.0
 for hp in range(1,N+1):
  if state[hp]==0:continue
  for dmg,prob in probs.items():
   if dmg>=hp:ko+=state[hp]*prob
   else:nxt[hp-dmg]+=state[hp]*prob
 ko_time.append(ko);state=nxt
 if sum(state)<1e-13:break
p_equal=sum(x*x for x in ko_time)
first_win=(1+p_equal)/2
exact_initiative={'model':'IID per-action damage; equal HP50 CA easily hit, RD5; no reactions','crit_positive_p':float(CRIT),'crit_negative_p':float(CRIT),
 'prob_hit_given_not_critfail':1.0,'expected_action_damage':sum(d*pr for d,pr in probs.items()),
 'expected_actions_until_HP0':sum((i+1)*p for i,p in enumerate(ko_time)),
 'same_number_attacks_probability':p_equal,'first_actor_win_probability':first_win,
 'second_actor_win_probability':1-first_win,'unabsorbed_survival_tail':sum(state),'enumerated_turns':len(ko_time)}
# If both sides are symmetric 50 HP and hit 100% with same damage, any base stat differences
# absent from modeled event except initiative; first actor advantage is mathematically provable.

# RD * hit grid: hit chance 0,1/6,1/3,1/2,1; crit negative remains explicit.
# ordinary DME = p(hit)*E[net on hit], independent from initiative.
scenarios=[]
for pp in [0,1/6,1/3,1/2,5/6,1]:
 for rd in [0,5,10,15]:
  scenarios.append({'theoretical_hit_probability':pp,'rd':rd,'mean_raw_dice':10.5,
   'expected_net_per_attempt_no_critical':pp*metrics_rd(rd)['mean_net_on_hit'],
   'status':'MATHEMATICAL_COUNTERFACTUAL_NOT_REAL_ATTACK'})

# Progression base crossing B5→P1 with matched allocation variable CON, INT.
# B5 count=5, P1 count=6. Beast normal attributes 35+8*n.
# HP recalculates at rank transition using current CON, INT on all levels; RD changes 5 to15,
# damage 3d6 to6d6, proficiency+6 -> +8 (not necessarily Luta).
# Using fixed 10 CON as a controlled scenario, total budget other attributes changes; cannot
# derive attack probability without allocation.
from collections import defaultdict

def dice_dist(n,faces=6):
 d=Counter({0:1})
 for i in range(n):
  out=Counter()
  for s,c in d.items():
   for k in range(1,faces+1):out[s+k]+=c
  d=out
 return {s:Fraction(c,faces**n) for s,c in d.items()}

def mean_after_rd(n,rd,faces=6):
 dist=dice_dist(n,faces)
 return float(sum(max(0,s-rd)*p for s,p in dist.items()))
frontier=[]
for rank,n,dice,rd,hp_step,pro in [('B5',5,3,5,10,6),('P1',6,6,15,20,8),('P5',10,6,15,20,8),('O1',11,9,25,30,10),('O5',15,9,25,30,10),('ON1',16,12,35,40,12),('ON5',20,12,35,40,12)]:
 con=int(10);intel=int(5)
 frontier.append({'rank':rank,'levels':n,'attribute_budget_base':35+8*n,'damage_dice':f'{dice}d6','rd_general':rd,
 'proficiency_available_not_auto_assigned_to_Luta':pro,
 'fixed_CON_assumption':con,'fixed_INT_assumption':intel,
 'HP_under_current_rank_formula':30+n*(hp_step+con),
 'Alma_under_current_rank_formula':30+n*(hp_step+intel),
 'mean_net_generic_damage_vs_own_rank_RD_on_hit':mean_after_rd(dice,rd),
 'mode':'MATH_ONLY_CON_FIXED_NOT_A_BUILD'})

# Theoretical defense reaction, given defender FOR etc, need fumble critical independent.
# No reaction admitted in R27; do not compute fake reactive fights.
summary={'schema':'R28_EXACT_MECHANICAL_SENSITIVITY','base_model':'R27 frozen 4 profiles; hit > CA strict; 1d6+FOR+experimental_Luta6',
 'matrix':matrix,'pair_viability_thresholds':thresholds,'rd_curves':rd_table,
 'expected_action_damage_examples':scenarios,'theoretical_initiative_symmetric_iid':exact_initiative,
 'rank_math_frontier':frontier,'no_canonical_credit':True}
(OUT/'R28_EXACT_MATH.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print('E vs D', next(a for a in matrix if a['attacker']=='EQUILIBRADO' and a['defender']=='DEFENSIVO'))
print('INIT',exact_initiative)
print('RD',rd_table)
print('FRONTIER',frontier)
