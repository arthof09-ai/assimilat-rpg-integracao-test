#!/usr/bin/env python3
"""Exact exhaustive dice convolution at canonical classification boundaries. No combat simulations."""
from collections import Counter
from fractions import Fraction
import json,pathlib
ROOT=pathlib.Path(__file__).parent

def dist(n,s):
 d={0:1}
 for _ in range(n):
  nxt={}
  for total,mult in d.items():
   for k in range(1,s+1):nxt[total+k]=nxt.get(total+k,0)+mult
  d=nxt
 assert sum(d.values())==s**n
 return d,s**n

def action(n,s,rd):
 d,total=dist(n,s)
 numer_net=sum(max(0,k-rd)*v for k,v in d.items());numer_positive=sum(v for k,v in d.items() if k>rd)
 return {'expression':f'{n}d{s}','RD':rd,'E_raw':n*(s+1)/2,'E_net_conditional_hit':numer_net/total,
  'P_positive_net_conditional_hit':numer_positive/total,'P_zero_net_conditional_hit':1-numer_positive/total,
  'support':[n,n*s],'exact_numerator_net':numer_net,'exact_denominator_net':total}

ranks=[('B5','Bronze',3,6,5),('P1','Prata',6,6,15),('P5','Prata',6,6,15),('O1','Ouro',9,6,25),('O5','Ouro',9,6,25),('ON1','Ouro Negro',12,6,35),('ON5','Ouro Negro',12,6,35),('L1','Lendário Titã',20,10,75)]
rows=[]
for a,b in [(0,1),(2,3),(4,5),(6,7)]:
 aa=ranks[a];bb=ranks[b]
 low=action(aa[2],aa[3],bb[4]);high=action(bb[2],bb[3],aa[4]);ratio=None if low['E_net_conditional_hit']==0 else high['E_net_conditional_hit']/low['E_net_conditional_hit']
 rows.append({'boundary':aa[0]+' -> '+bb[0],'lower_to_higher':low,'higher_to_lower':high,
   'expected_net_ratio_if_both_hit':ratio,'NOTE':'MATH ONLY: no attack accuracy, reactions, action cost, skill abilities, armor, transformations or crit included.'})
path=ROOT/'results'/'R28_BOUNDARY_CONDITIONAL_DAMAGE_EXACT.json';path.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
for row in rows:
 print(row['boundary'], 'L->H',round(row['lower_to_higher']['E_net_conditional_hit'],6), 'P+',round(row['lower_to_higher']['P_positive_net_conditional_hit']*100,5), 'H->L',round(row['higher_to_lower']['E_net_conditional_hit'],6), 'ratio',row['expected_net_ratio_if_both_hit'])
