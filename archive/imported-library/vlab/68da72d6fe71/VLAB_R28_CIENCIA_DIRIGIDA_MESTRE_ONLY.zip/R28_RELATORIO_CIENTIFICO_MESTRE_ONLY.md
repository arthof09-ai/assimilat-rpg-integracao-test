# PSV — VLAB / Continuidade científica dirigida pós-R27

**OP:** `OP-VLAB-FUSION-SANDBOX-01` | **Papel:** MESTRE-SIDE | **Data:** 15/10/2026 | **Natureza:** LAB matemática exata + coorte experimental adicional mínima + triagem Mestre de Bestas oficiais.  
**Proveniência:** R27 no ZIP histórico SHA-256 `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`, bancos SQLite e 320 recibos imutáveis. Nenhum número desta entrega altera a baseline ANTES.  
**Gates:** 0/1.875 células canônicas, 0/17 contratos VLAB terminais; DMG registra historicamente 1/18 certificados (não reaud itados nesta rodada). NAC-NORM/NAC-PASS produtivos HOLD, IBX-56 BLOCKED-EXTERNAL, IBX-90/91/92 preservadas; nenhum writer produtivo, fichas, Party ou O Primeiro tocados.

## 1. Resultado substantivo — os 200 impasses são sensíveis, mas não desaparecem

A regra observada no Sistema de Combate é teste de ataque = dados da classificação + atributo de Luta (normalmente FOR) + bônus de Luta, sucesso quando **supera** a defesa. A regra de Criação de Besta determina 43 pontos de atributo em Bronze1 (35+8), +6 de proficiência de Besta normal Bronze, dano-base genérico 3d6, RD5 e CA `10+DES+CON/5`. O local de aplicação da proficiência à perícia Luta de um indivíduo não foi comprovado.

**Exemplo crítico:** Equilibrado tem `FOR12+Luta6+1d6 = 19..24`, contra CA25 do Defensivo. Ataque+1 permanece 0%; ataque+2 chega a **1/6=16,667%**; ataque+3 a 2/6=33,333%; ataque+4 a 3/6=50%. CA-1 ainda 0%; CA-2 passa a 1/6. Tabelas exatas nos arquivos `R28_EXACT_MATH.json` e `R28_PAIRED_CAUSAL_ANALYSIS.json`.

**Contabilidade exata de células com ao menos uma direção de acerto, quando ambos os lados recebem a mesma variação de precisão, sem crédito oficial:** base +6 Luta: **6/16**; +1: 6/16; +2: **8/16** (40/200 cenários antes censurados destravariam matematicamente o pré-gate); +3: 10/16; +8: 13/16; +12: 15/16. Isso NÃO significa combate encerrado no limite de 24 turnos ou melhoria permitida.

**Se a hipótese +6 não for concedida:** com Luta=0, **5/16** células admitem alguma direção de acerto; com +2: 5/16; com +4: 6/16; com +6: 6/16; com +8: 8/16. O bloqueio não nasce exclusivamente de +6, mas a contagem muda e NÃO se deve extrapolar a taxa para todas as Bestas.

**Redistribuição do orçamento, sem criar pontos:** Equilibrado `FOR12 DES9 CON10` → `FOR14 DES7 CON10` (−2 DES/+2 FOR), os outros atributos constantes, conserva os 43 pontos e Vida50; CA cai de21 para19, iniciativa também cai 2, e sua chance de acertar o Defensivo sobe de 0 a 1/6 sob Luta+6. Esse ensaio é matemático com construção virtual, **não** a comprovação de treinamento de uma Besta. A mudança NÃO isola só acerto; também muda CA e iniciativa. Aplicar +2 direto em Luta seria um contrafactual separado sem fonte comprovada.

**Crítico:** chance-base de positivo/negativo é 2/216 cada (3d6 sequencial). O positivo da R27 aumenta dano após acerto; não há fonte que transforme crítico positivo em autoacerto; o negativo consome ação e não causa dano por política exclusiva LAB. Portanto o pré-gate de impossibilidade aplica-se à configuração R27, não ao combate integral com repertório real.

## 2. Efeito de iniciativa e economia de ações: decomposição causal

Na R27, Equilibrado × Ofensivo tem Vida50 × 50; ambos acertam em todas as faces normais, mesma fonte 3d6, mesma RD5, mesma política de Ação Padrão sem Reações, mesmo PA e ausência de gasto positivo. Logo **FOR12 vs20 e CA21 vs16 não explicam mecanicamente a diferença nesse confronto**, pois ambos saturaram precisão, a CA é superada em todas as faces e FOR não entra no 3d6 básico. O Equilibrado tem DES9 vs4, portanto sua iniciativa vence todas as combinações de 1d6, incluindo empate decidido por DES. Reabertura das 40 lutas originais: **40/40** Equilibrado primeiro, 28/40 vitórias do Equilibrado (13/20 como lado esquerdo, 15/20 como lado direito).

**Estatística correta:** são **20 blocos pareados** de sementes com duas posições por bloco, distribuição de vitórias EQ por bloco: 0 vitórias=1 bloco, 1 vitória=10, 2 vitórias=9. Bootstrap agrupado de 30.000 réplicas, seed fixa 20261015: proporção média 70%, IC percentil **57,5–82,5%**. Intervalo exploratório válido ao nível de bloco, não inferência para Bestas reais.

**Oráculo matemático adicional, não combate:** quando o dano em cada ação é IID e identicamente distribuído para dois atores com 50 HP, acerto garantido exceto política de falha crítica, dano 3d6 mitigado por RD5, crítico positivo +18 e falha crítica 0, a contagem de ações necessárias para KO é T. O primeiro vence se `T_1<=T_2`; por simetria `P(primeiro vence)=(1+P(T_1=T_2))/2`. Convolução exata dos 3d6 e recorrência absorvente dão `P(T_1=T_2)=0,160754525`, portanto **P(primeiro vence)=58,037726%**; ~9,462 ações próprias até terminar uma Vida50. Esse modelo independente NÃO é o RNG histórico da R27 e não explica sozinho um possível viés por indexação/ordem de rolagem.

**Contraste nativo dirigido de baixo N:** usei adaptador apenas de fixture sobre os mesmos módulos R27/R26/R25/R18, v0.7/v0.8.1, sem editar código-mãe. `OFF_FIRST` dá bônus de iniciativa +12 **contrafactual** ao Ofensivo, mantendo Vida, CA, FOR, Luta, dano, RD, regras de críticos e slots. **4/4 novos combates nativos encerrados com recibos + SQLite e ledger reaberto; Ofensivo 3/4, Equilibrado 1/4** nas seeds 11,23,37,41 (lado EQ esquerdo). Comparação daquelas quatro sementes na R27: Ofensivo 2/4, Equilibrado 2/4. Uma quinta tentativa (seed53) foi INTERROMPIDA PELO LIMITE DE EXECUÇÃO, preservada em `ACTIVE` rev12, pendentes0, sem crédito. O contraste muda a ordem e a atribuição de rolagens por nonce/ator; por isso NÃO atribuir efeito causal quantitativo puro com n4. Status: `CONTRAFACTUAL_NONCANONICAL`.

**Reações e economia:** R27 excluiu reações voluntárias; não há evidência nesta entrega sobre seu efeito quantitativo em lutas, apenas efeito mecânico de turno e uma oportunidade adicional para o primeiro atacante. Não misturar uma política de Reação nova ao estimar o efeito de iniciativa. Ação Padrão consumida pela falha crítica, sem dano e sem PA positivo novo, foi mantida.

## 3. RD: controlar precisão separadamente do dano

Matemática enumerada, dados genéricos 3d6, condicionado a acerto e antes de crítico/efeitos:

| RD | E(dano líquido\|acerto) | Acertos que causam dano líquido 0 | Absorção da média bruta |
|---:|---:|---:|---:|
| 0 | 10,500 | 0% | 0% |
| 5 | 5,523 | 4,63% | 47,40% |
| 7 | 3,662 | 16,20% | 65,12% |
| 10 | 1,458 | 50,00% | 86,11% |
| 15 | 0,0694 | 95,37% | 99,34% |
| 18 | 0 | 100% | 100% |

**Causalidade:** `E(dano líquido/ataque) = P(acertar) × E[dano líquido | acerto]` somente neste modelo independente de hit, sem crítico e efeitos adicionais. Dois ataques de precisão distinta podem ter DME parecida: `P(hit)=1/6, RD0` gera **1,750/ação**; `P(hit)=1/3,RD5` gera **1,841/ação**, apesar de acertos 2× mais frequentes no segundo. `P(hit)=1,RD18` resulta em **zero** com 3d6, mesmo acertando sempre. Alterar dados-base sem decompor esses fatores confundiria CA, treino e RD.

**Confronto com R27 observado:** 19.913 dano bruto em acertos; 9.391 mitigados (47,16% dos pontos brutos); 10.522 líquido antes do corte HP0; 10.131 Vida retirada, overkill391. Acertos: 1.890/2.506=75,42%, com composição desigual de matchups. Não usar essa taxa agregada como taxa teórica de todo Bronze1.

## 4. Fronteiras de rank: achado novo forte, ainda matemática sem duelo

É decisivo comparar **ataques cruzados** (dano do rank inferior contra RD superior e vice-versa), e não somente cada rank contra sua própria RD como fez a R27. Distribuições de dados exatas convoluídas, condicionadas a acerto, SEM crítico, habilidade, arma, bônus ou economia de ações:

| Fronteira | DME inferior→superior | P(dano>0\|hit) inferior→superior | DME superior→inferior | Razão superior/inferior |
|---|---:|---:|---:|---:|
| Bronze5→Prata1 | **0,0694** | **4,63%** | **16,0000** | **230,4×** |
| Prata5→Ouro1 | **0,3744** | **14,46%** | **16,5003** | **44,07×** |
| Ouro5→OuroNegro1 | **0,7533** | **22,04%** | **17,0022** | **22,57×** |
| OuroNegro5→Lendário1 Titã | **0** | **0%** | **75,0000** | razão indefinida (denominador zero) |

Ouro Negro normal possui `12d6` (máximo72) contra RD75 de Lendário Titã: o dano genérico não ultrapassa a RD nem se o ataque acertar. Isso é um **limiar matemático estrutural**, NÃO uma conclusão de que todos os ataques Ouro Negro são ineficazes contra Lendários. Esforço, magia, armamento, dano especial, vantagem elemental ou outras capacidades devem ser legitimamente consideradas antes de interpretação de gameplay.

**Primeira fronteira B5→P1 com CON10/INT5 como controle matemático e sem construir personagem:** atributos-base disponíveis `75→83`; proficiência geral `+6→+8` (atribuição a Luta não provada); dados de teste `1d6→2d6`; dano normal `3d6→6d6`; RD5→15; Vida natural `130→210` (+61,54%) e Alma `105→180`, usando regra de recálculo ao trocar classificação. Valores controlados de CON/INT são hipóteses matemáticas, não ficha; nenhuma transformação Bronze, nenhuma ação real habilitada, 0 combates completos cross-rank. As outras fronteiras têm cálculos estruturais análogos, sem construir builds completas.

**Interpretação científica:** o poder relativo perto de um limiar de classificação não pode ser resumido por “dano base subiu 2×”. A RD oposta pode criar uma transição quase descontínua de dano útil. Saber se isso é desejável requer objetivo de design do Mestre e comparações com habilidades/equipamentos reais e progressão esperada.

## 5. Bestas reais — busca ampliada e primeiro contrato prioritário

Quatro fichas herdadas da triagem R27: Galinha Demoníaca/Galidemus, Cabra de Chifres, Raposa Flamejante, Macaco Rei Titã. **Quatro fichas adicionais lidas fisicamente nesta continuidade:** Rato Flamejante Bronze1, Felpudo Bronze1, Cerebrato Bronze1, Insetos de Luz Bronze2. Universo dirigido: **8 fichas identificadas (4 herdadas + 4 reabertas), 0/8 ações integralmente admitidas**, sem pretensão de censo das Bestas.

**Candidatas mais próximas, nenhuma pronta:**

1. **Galidemus (eddc…429)**: Patada `1d4+DES13` cortante; a regra de ataque normal usa FOR5 salvo fonte específica que permita DES no teste. A DES no dano NÃO concede DES de acerto. Falta prova de bônus/treinamento individual de Luta, enquadramento de Patada como Ação Padrão genérica versus habilidade, custo PA e alcance/cena, fonte congelada e autoridade dos valores de HP/CA para snapshot. A ficha declara Vida32 e CA21; fórmula genérica B1 normal para CON6/DES13 daria HP46 e CA24,2 antes de regra de arredondamento. Esses conflitos documentais impedem chamar o snapshot de fiel sem decisão de precedência.
2. **Rato Flamejante (e29c…22a)**: Mordida flamejante `1d4+FOR6 perfurante` é mais alinhada ao atributo padrão do teste, mas a palavra “flamejante” não prova se existe componente Fogo adicional; não omitir uma consequência caso seja obrigatória. Faltam Luta/treinamento, categoria/custo/alcance, cena e revisão de fonte. Vida impressa14 versus previsão normativa B1 com CON4 igual44; CA impressa28, enquanto fórmula `10+17+4/5=27,8` demanda regra de arredondamento não explicitada.
3. **Cabra (391c…fa6)**: Investida `1d6+FOR13` com empurrão obrigatório; sem alcance, geometria, distância e controle, não despachar.
4. **Raposa (4d0c…60ca)**: Bola de fogo, rastro e custos/efeitos sem contrato fechado.
5. **Felpudo (40ec…cb)**: Espinhos e veneno/salvaguarda/recarga/regeneração tornam o contrato maior, apesar da ficha acessível.
6. **Cerebrato (00ac…3b)**: habilidades de peste/controle/sobrevida negativa complexas, não candidato inicial mínimo.
7. **Insetos de Luz (db7c…55d)**: nenhuma ação ofensiva expressa e dinâmica de grupo/ilusão específica.
8. **Macaco Rei Titã (301c…67a)**: fonte histórica de ações físicas e Poder Elemental, mas muitos contratos de efeito/contexto ainda incompletos.

**P0 recomendado:** resolver a admissão de um ataque natural simples de Galidemus ou Rato, privilegiando aquele com menos lacunas após fonte/hit/treino conferidos pelo produtor DMG e decisão do Mestre competente; nenhum recibo nativo da R24 com acerto forçado prova ação real legal. Os canais **IBX-90 (NOVA)** e **IBX-92 (NOVA)** foram consultados na INBOX única, sem criar cópias nem atribuir ACK. Os cinco gates A–E de DMG e writer produtivo permanecem HOLD.

**Pergunta normativa mínima para a próxima autorização real (NÃO respondida por suposição):** em uma Besta Bronze1 sem campo individual de treino, o bônus geral de proficiência **+6** aplica-se automaticamente ao teste de **Luta** de um ataque natural padrão, ou depende de seleção/treinamento comprovado? Resposta afeta a primeira ação de Galidemus/Rato e a generalização do resultado R27. Outros campos faltantes ainda exigem fonte ou decisão caso a caso.

## 6. Errata da R27 e limitações

Errata vinculada em arquivo independente `R28_ERRATA_VINCULADA_R27_MESTRE_ONLY.md`: (i) corrige placeholder RD para 9.391/19.913; (ii) troca placeholder lista de perfis pela lista exata de 4 perfis e 20 seeds; (iii) remove uso de IC Wilson como estimativa de vitória em 10 células de 0 combate; (iv) limita prova de impossibilidade à política R27; (v) mantém treinamento +6 e 40 combates como pressupostos dependentes. **O texto/SQLite originais R27 não foram reescritos.**

**Censura:** 200/320 `CENSORED_PROVABLE_NO_HIT_POTENTIAL` em R27; 120/320 `COMPLETE_CONDITIONAL_RULE_DERIVED`. Nova coorte dirigida 4/4 completas `OFF_FIRST`, 1 parcial em HOLD após timeout. Não confundir execução abortada com derrota ou empate. A conclusão de balanceamento geral é NÃO ESTIMÁVEL sem ações reais, critério normativo de funcionalidade e cenários variados.

**Riscos de RNG:** contraste nativo OFF_FIRST altera ordem de eventos e atribuição de rolagens ao nonce/ID. Mesmo com seed igual, isso não garante rolagem igual por personagem; efeito da iniciativa não foi isolado de todo o RNG. O oráculo IID é uma prova matemática sob hipótese independente, não um módulo de combate novo.

## 7. Reprodutibilidade / estado físico e PSV

**Reuso:** ZIP R27 bytes intocados e R26 integrado por herança; 2 tentativas `UNKNOWN_EFFECT` antigas permanecem em seus respectivos bancos dentro do ZIP histórico, sem retry. Código R27 inalterado. Ferramentas desta entrega:
- `R28_EXACT_SENSITIVITY.py`: matriz precisão/CA/proficiência, RD e modelo teórico IID de iniciativa;
- `R28_BOUNDARY_MATH.py`: convolução exata 4 fronteiras nos dois sentidos;
- `R28_PAIRED_ANALYSIS.py`: 40 resultados originais agrupados em 20 seeds e bootstrap;
- `R28_DIRECTED_FIXTURE_RUNNER.py`: alterador **somente da fixture em memória**, utiliza R27/R26/R25/R18 históricos, sem novo combat engine;
- `R28_VALIDATE_EVIDENCE.py`: checks de integridade, resultados e status de interrupção;
- `results/*.json`: matriz completa, totais, seeds e hashes.

**Reabertura material:** **12/12 verificações locais PASS** (não certificação mecânica), 4 resultados novos íntegros, 1 seed53 interrompida com banco `ACTIVE`, revisão12, **0 pending**, mantida sem conclusão; sem duplicação de ataques ou efeito de ação comprovado na revisão concluída. História preservada em diretório separado; nenhum original foi substituído. A existência de `0 pending` no instante da leitura NÃO autoriza retomar cegamente depois de timeout: aplicar o gate antes de qualquer continuação.

**Indicadores:** 16/16 células originais avaliadas, 320/320 configurações originais já congeladas, 120 completos antigos +4 novos contrafactuais nativos, **não somados como 124/320**; 200 censuras históricas permanecem 200. Patamares com matemática agora 5 grupos e quatro fronteiras completas em ambos sentidos, builds cross-rank completos 0/25; Besta real ação legal 0/8 candidatas examinadas; registros canônicos 0/1.875, VLAB terminal 0/17. Nenhuma ficha alterada.

**Fronteira seguinte:** reconciliar `Luta +6` de ataques naturais e o critério de snapshots conflitantes; admitir a primeira ação real de fonte, sem omitir rider; em paralelo realizar coorte legal-fundamentada B5↔P1 com ações/recursos/fonte e reações controladas. Não repetir R27 massivamente. Nunca publicar inferência como regra oficial.
