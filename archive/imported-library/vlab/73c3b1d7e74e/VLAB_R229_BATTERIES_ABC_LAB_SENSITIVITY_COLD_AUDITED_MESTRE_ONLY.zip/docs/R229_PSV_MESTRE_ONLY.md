# VLAB R229 — Primeira campanha de sensibilidade A/B/C vinculada ao R91 — PSV MESTRE-ONLY

**Operação:** `OP-VLAB-FUSION-SANDBOX-01`; CM-000006 lógico; TEST, produção/Party/O Primeiro/fichas/normas NO-WRITE. **NÃO** é o benchmark oficial, nem FULL-FIGHT nativo R18. Fonte do esquema: cópia byte-idêntica de `R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv` (104 posições). Fontes técnicas históricas: fábrica L04 e simulador legado v0.6, **reutilizados em cópia**.

## Entrega nova

Nova cópia experimental `v0.6.1-R229-CRIT-TEST-PATCH` corrigiu um defeito real detectado pelo auditor no legado: o teste `crit_draws[:2] == (6,6)` comparava lista contra tupla, ignorando críticos positivos. O adaptador isolado passou a reconhecer `[6,6,5/6]`, aplicar acerto automático de crítico positivo conforme R50 e preservar crítica negativa sem consequência extra como **LAB-ONLY**, não como norma. Não se fez write no motor produtivo, nas regras ou nos pacotes antigos.

**Experimento efetivamente admitido:** sete braços de formação, duas políticas laboratoriais de RD, **12 seeds novas `22910401`–`22910412`**, 168 execuções originais e **168 espelhos de rótulo** (não são seeds independentes). Horizonte de **12 rodadas**. Todos os ataques do sim legado são básicos, sem magia, movimento, reação ou journal R18. Auditor independente não importa o simulador e validou os eventos e seus cálculos um por um.

**Evidência auditada:** 2.332 eventos de ataque nos originais, 970 acertos, 12.236 unidades de dano solicitadas após RD, **10.852 PV efetivamente retirados** após limitar pela Vida restante; espelhos idênticos por actor-ID, movimento/cenário não modelados. **NÃO** chamar ataque de observação estatística independente, HP0 laboratorial de morte/campanha ou censura de vitória. Amostra global: 12 seeds compartilhadas entre sete formações; por configuração, n=12, com intervalos Wilson apenas descritivos.

| Frente R91 | Formação de sensibilidade | Resultado válido sob hipótese TEST |
|---|---|---|
| A | ED genérico Bronze1 × ED genérico Bronze1 | 2/12 atingiram limiar de HP0 LAB; 10/12 censurados em RD LAB |
| A | ED genérico Prata1 × ED genérico Prata1 | 0/12 limiar; 12/12 censurados, não são duelos equilibrados certificados |
| B | ED × Besta genérica Bronze1/Prata1/Ouro1 | 12/12 em cada braço chegaram a limiar LAB; a Besta não tem identidade de espécie |
| C | Dois e três ED genéricos × uma Besta genérica B1 | 12/12 em cada braço chegaram a limiar LAB; **somente ataques básicos**, não equipe cooperativa completa |
| D | Painel de 27 espécies distintas | **Nenhum monstro distinto admitido** nesta coorte; variantes genéricas de B são proibidas de contar como D |
| E | Comparação de equipamento físico/mágico | Não reexecutada; usar apenas R226–R227 semicanônicos já auditados, com fonte não-P4 |

### Sensibilidade de RD — experimental, não regulatória

No braço B/Ouro1, o RD LAB impediu **13 unidades de dano calculado** no agregado; no braço C/2×1 B1, **5 unidades**. As demais cinco configurações tiveram diferença agregada zero neste lote. Os braços RD ON/OFF compartilharam seed e snapshots, mas trajetórias futuras podem divergir; essa evidência é de sensibilidade, não calibração oficial de potência.

### Quarentenas e honestidade metodológica

- `229101xx`: falhas de pré-execução de role/parse e evidência parcial abandonada; não admitidas.
- `229102xx`: horizonte executado 30 em vez de 12 ao usar o default legado; **quarentena de discrepância de pré-registro**, NÃO REPLAY.
- `229103xx`: crítico `[6,6,5]` categorizado erroneamente como NORMAL pelo motor legado; **quarentena de defeito de crítica**, NÃO REPLAY.
- `229104xx`: nova coorte depois de corrigir teste e acerto de crítico positivo; auditada. Auditor reconstituiu 336 resultados (168 originais +168 espelhos).

**LAST-VERIFIED-UNIT:** R229 no escopo de audit script e cold package. **FIRST-PENDING:** integrar uma Besta source-derived com deslocamento real ao R18 e admitir espécies físicas para D, sem canonização. **NAC-PASS local:** PASS TEST condicional na cópia v0.6.1; **NAC-PASS global:** HOLD. Homologações 0/17 e 0/1.875.
