"""Additive R229 laboratory sensitivity; reuses existing v0.6 executable without altering it.
MESTRE_ONLY/TEST. B/C numeric outputs have noncanonical source allocation and LAB mechanics.
"""
from __future__ import annotations
from pathlib import Path
import sys,json,csv,hashlib,collections,copy
from dataclasses import asdict,replace
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'runtime/native'))
from vlab_l04 import build_human,build_beast
from vlab_beast_benchmark_v06 import make_actor,run,mirror

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def build_arm(name):
 def H(rank,star,seed,priority=('FOR','DES','CON','INT','SAB','CAR'),team='A',role='generalist'):
  return make_actor(build_human(rank,star,seed,priority=priority),team,role=role,seed=seed)
 def B(rank,star,seed,priority=('FOR','CON','DES','INT','SAB','CAR'),team='B'):
  return make_actor(build_beast(rank,star,seed,priority=priority),team,seed=seed)
 if name=='A_ED_BRONZE1_DUEL':return (H('Bronze',1,22911011),H('Bronze',1,22911012,('DES','CON','FOR','SAB','INT','CAR'),team='B',role='skirmisher'))
 if name=='A_ED_PRATA1_DUEL':return (H('Prata',1,22911021),H('Prata',1,22911022,('DES','CON','FOR','SAB','INT','CAR'),team='B',role='skirmisher'))
 if name.startswith('B_BE_'):
  rank=name.split('_')[2].replace('1','').title();return (H(rank,1,22911031+['Bronze','Prata','Ouro'].index(rank)), B(rank,1,22911041+['Bronze','Prata','Ouro'].index(rank)))
 if name=='C_TEAM_BRONZE1_2V1_BE':return(H('Bronze',1,22911111),H('Bronze',1,22911112,('DES','CON','FOR','SAB','INT','CAR'),team='A',role='skirmisher'),B('Bronze',1,22911113))
 if name=='C_TEAM_BRONZE1_3V1_BE':return(H('Bronze',1,22911121),H('Bronze',1,22911122,('DES','CON','FOR','SAB','INT','CAR'),team='A',role='skirmisher'),H('Bronze',1,22911123,('CON','SAB','DES','FOR','INT','CAR'),team='A',role='guardian'),B('Bronze',1,22911124))
 raise ValueError('unknown arm '+name)

def run_all():
 pre=json.loads((R/'sources/R229_PREREG_BEFORE_EXEC.json').read_text()); a=pre['arms'];seeds=pre['seeds'];modes=pre['rd_modes']
 out=R/'evidence/reports/R229_NEW_LAB_SENSITIVITY_JSONL';out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():raise FileExistsError('immutable R229 RESULTS ALREADY EXIST: '+str(out))
 roster_payload={};summary=[]
 with out.open('x') as f:
  for arm in a:
   roster=build_arm(arm); roster_payload[arm]=[dict(asdict(v),ca=str(v.ca)) for v in roster]
   for rd in modes:
    for seed in seeds:
     
     original=run(roster,seed,max_rounds=pre['horizon_rounds'],rd_mode=rd)
     # Label-only swap: actor IDs, sources, action roles, initiative and RNG inputs remain identical.
     swapped=tuple(replace(v,team=('B' if v.team=='A' else 'A')) for v in roster)
     label_swap=run(swapped,seed,max_rounds=pre['horizon_rounds'],rd_mode=rd)
     m={'original':original,'swapped':label_swap,
         'same_events':original['events']==label_swap['events'],
         'same_hp':original['HP']==label_swap['HP'],
         'same_initiative':original['initiatives']==label_swap['initiatives'],
         'same_trace_digest':original['trace_digest']==label_swap['trace_digest']}
     assert all(m[z] for z in ('same_events','same_hp','same_initiative','same_trace_digest'))
     for side,rr in [('ORIGINAL',m['original']),('LABEL_SWAP',m['swapped'])]:
      # Exact v0.6 trace as generated, not a new combat engine.
      row={'arm':arm,'seed':seed,'rd_mode':rd,'side_label':side,'source':'LEGACY_V06_EXISTING_EXECUTABLE_TEST',
           'result':rr,'snapshot_hash':sha(roster_payload[arm]),'mirror_ok':bool(m['same_events'] and m['same_hp'] and m['same_initiative'] and m['same_trace_digest'])}
      f.write(canon(row)+'\n')
      if side=='ORIGINAL':summary.append({'arm':arm,'seed':seed,'rd_mode':rd,'rounds':rr['rounds'],'events':rr['event_count'],'HP':rr['HP'],'stop':rr['stop_reason'],'complete':rr['complete'],'lab_winner':rr['winner_by_lab_hp_threshold'],'source_fully_eligible':rr['source_fully_eligible']})
 (R/'sources/R229_SOURCE_SNAPSHOTS_V06.json').write_text(json.dumps(roster_payload,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 aggreg=[]
 for arm in a:
  for rd in modes:
   q=[x for x in summary if x['arm']==arm and x['rd_mode']==rd]
   aggreg.append({'arm':arm,'rd_mode':rd,'seeds':len(q),'lab_hp_threshold_ends':sum(x['complete'] for x in q),
       'censures_or_stalemate':sum(not x['complete'] for x in q),'rounds_total':sum(x['rounds'] for x in q),
       'attack_events':sum(x['events'] for x in q),'full_fight_homologated':0})
 (R/'evidence/reports/R229_AGGREGATES.json').write_text(json.dumps({'status':'PRODUCED_PENDING_INDEPENDENT_AUDIT','arm_summaries':aggreg,'executions':len(summary),'side_swaps':len(summary),'events':sum(x['events'] for x in summary),'seeds_unique':len(seeds)},indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'executions':len(summary),'side_swaps':len(summary),'total_attack_events':sum(x['events'] for x in summary),'aggregates':aggreg},ensure_ascii=False,indent=2))
if __name__=='__main__':run_all()
