"""No engine import. Unit seed within arm; mirrors excluded. Counts not official power."""
import json,collections,statistics,math
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def wilson(k,n,z=1.959963984540054):
 if not n:return [None,None]
 ph=k/n;den=1+z*z/n;center=(ph+z*z/(2*n))/den;h=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
 return [round(max(0,center-h),4),round(min(1,center+h),4)]
def run():
 audit=json.load(open(R/'evidence/reports/R229_INDEPENDENT_AUDIT.json'))
 arms={}
 for r in audit['per_arm']:
  group=arms.setdefault(r['arm'],{})
  group[r['rd_mode']]={'n_independent_seed_units':r['seeds'],'lab_threshold_ends':r['lab_hp_threshold_ends'],
   'threshold_Wilson95':wilson(r['lab_hp_threshold_ends'],r['seeds']),
   'censored':r['censures_or_stalemate'],'attacks':r['attack_events'],'hits':r['hits'],
   'hit_fraction_events_NOT_independent':round(r['hits']/r['attack_events'],3) if r['attack_events'] else None,
   'requested_damage_after_RD':r['damage_post_rd_requested'],'effective_HP_removed':r['damage_effective_hp'],
   'overkill_requested_minus_HP':r['damage_post_rd_requested']-r['damage_effective_hp'],'RD_absorbed_LAB':r['rd_damage_blocked']}
 for arm,v in arms.items():
  x=v['SUBTRACT-LAB'];y=v['OFF-LAB'];v['rd_sensitivity']={'effective_HP_loss_delta_OFF_minus_RD':y['effective_HP_removed']-x['effective_HP_removed'],
   'requested_damage_delta_OFF_minus_RD':y['requested_damage_after_RD']-x['requested_damage_after_RD'],
   'comparable_seed_and_actor_snapshots':True,'causal_interpretation_limit':'Same source actor and seed, but dynamic HP can alter future target/action; compare trajectories not independent rolls'}
 obj={'status':'PASS_R229_SCIENCE_DESCRIPTIVE_TEST_CONDITIONAL','arms':arms,'total_independent_seeds_overall':12,
      'per_arm_seeds':12,'independent_seed_arm_pairs':84,'rd_regimes_per_arm':2,'new_original_runs':168,
      'label_swaps':168,'source_eligible':False,'native_r18':False,'official_reference_credit':0,
      'cautions':['A source-derivation can populate an experimental snapshot without validating user-allocated attributes','B generic BE is not a named Beast species','C 2v1/3v1 lacks spell/heal/retreat as legacy submodel','D cannot use generic Beast variants as distinct species','E historic PS item not P4','Wilson intervals on n12 broad; threshold is LAB not canonical death or victory']}
 (R/'evidence/reports/R229_SCIENCE_INTERPRETATION.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'arms':len(arms),'seed_arm_units':84,'validity':'TEST_CONDITIONAL_ONLY'},ensure_ascii=False))
if __name__=='__main__':run()
