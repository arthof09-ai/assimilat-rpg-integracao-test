"""Independent read-only verifier for labelled PRE-INTENT forecasts, NOT effect RNG.

R323 only. No import of runtime or mutating SQLite. It reconstructs forecast
labels and values separately from R321/R322 committed-effect traces.
"""
from pathlib import Path
import hashlib,json,random,sqlite3
VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
SOURCE='LAB_R323_PRE_INTENT_VALIDATION_TRACE_V1'
GEN='KEYED_SHA256_RANDOM_RANDOM_ACCESS_NOT_SEQUENTIAL_CANONICAL'
SCOPE='BEFORE_DURABLE_INTENT_READ_ONLY_NOT_EFFECT'
class R323AuditHold(ValueError):pass

def canon(o):return json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha(o):return hashlib.sha256(canon(o).encode()).hexdigest()
def roll(seed,nonce,label,count,faces=6):
    h=hashlib.sha256(f'{seed}|{nonce}|{label}|{count}d{faces}|{VERSION}'.encode()).digest()
    r=random.Random(int.from_bytes(h,'big'))
    return [r.randint(1,faces) for _ in range(count)]

def inspect(path):
    p=Path(path)
    if not p.is_file():raise R323AuditHold('R323_MISSING_DB')
    c=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True,timeout=5)
    try:
        m=dict(c.execute('SELECT key,value FROM meta'))
        if c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]:raise R323AuditHold('R323_PENDING_EFFECT')
        rows=[json.loads(x[0]) for x in c.execute('SELECT row_json FROM events ORDER BY seq')]
    finally:c.close()
    st=json.loads(m['state'])
    if st.get('r323_admission_source')!='R323_PRE_INTENT_SNAPSHOT_TRACE_TEST_V1':
        raise R323AuditHold('R323_UNMARKED_OR_LEGACY_SCENE')
    actors=st['actors'];seed=st['seed'];nonce=0;forecasts=0;calls=0
    if len(rows)!=int(m['revision']) or not rows or type(seed) is not int:
        raise R323AuditHold('R323_REVISION_OR_SEED')
    for i,e in enumerate(rows,1):
        if e['seq']!=i or e['kind']!='R21_DECISION':raise R323AuditHold('R323_EVENT_ORDER')
        action=e['detail']['decision'];request=e['payload']['request'];a=request.get('actor')
        if action=='START':
            if i!=1 or a!='':raise R323AuditHold('R323_INITIATIVE_POSITION')
            event_nonce=0
        elif action in ('HEAL','ATTACK'):
            nonce+=1;event_nonce=nonce
        elif action=='PASS':event_nonce=nonce
        else:raise R323AuditHold('R323_UNSUPPORTED_ACTION')
        ad=e['payload'].get('r323_admission')
        if not isinstance(ad,dict) or set(ad)!={'source','scope','generator','seed','nonce','state_sha_before','draws','trace_sha256','canonical_rng_certified','effect_calls_included'}:
            raise R323AuditHold('R323_ADMISSION_MISSING_OR_SCHEMA')
        if (ad['source'],ad['scope'],ad['generator'])!=(SOURCE,SCOPE,GEN) or ad['canonical_rng_certified'] is not False or ad['effect_calls_included'] is not False:
            raise R323AuditHold('R323_FALSE_CANONICAL_OR_EFFECT_CLAIM')
        if ad['seed']!=seed or ad['nonce']!=event_nonce or ad['state_sha_before']!=e['before_sha']:
            raise R323AuditHold('R323_PRE_INTENT_STATE_OR_NONCE')
        exp=[]
        def take(label,n=1):
            value=roll(seed,event_nonce,label,n)
            exp.append({'ordinal':len(exp)+1,'nonce':event_nonce,'label':label,'count':n,'faces':6,'values':value})
            return value
        if action=='START':
            for actor in actors:take('initiative:'+actor)
        elif action=='ATTACK' and request.get('reaction')=='COUNTERATTACK':
            b=request.get('target')
            if a not in actors or b not in actors or a==b:raise R323AuditHold('R323_ACTOR_SOURCE_INVALID')
            incoming=take('r317:critical-incoming:'+a,3)
            if incoming in ([1,1,1],[1,1,2]):raise R323AuditHold('R323_INVALID_NEGATIVE_CRIT_COMMITTED')
            attack_die=take('tohit:'+a)[0]
            score=attack_die+actors[a]['stats']['for']+actors[a]['stats']['luta']
            hit=(incoming in ([6,6,5],[6,6,6])) or score>actors[b]['stats']['ca']
            if not hit:
                crit=take('r317:critical-response:'+b,3)
                if crit in ([1,1,1],[1,1,2]):raise R323AuditHold('R323_RESPONSE_NEGATIVE_COMMITTED')
                advantage=take('r317:counter-advantage:'+b,2)
                counter_score=max(advantage)+actors[b]['stats']['for']+actors[b]['stats']['luta']+2
                if crit in ([6,6,5],[6,6,6]) or counter_score>actors[a]['stats']['ca']:
                    take('r317:counter-damage:'+b)
        is_r326_start=(action=='START' and
                       st.get('r326_scheduler_policy')=='R326_Q01_Q02_APPROVED_TEST_ONLY')
        if is_r326_start:
            # R326 Q01 recalculates tie-only draws during BEFORE-INTENT preflight.
            # Verify the complete forecast against an independent seeded Q01 oracle;
            # do not silently truncate extras or excuse altered hashes.
            from audit_r326_contract import audit_start,R326AuditHold
            execute=e['detail']['inner']['r322_rng_causality']['draws']
            try:audit_start(st,actors,e['detail']['inner'],seed)
            except (R326AuditHold,KeyError,TypeError,ValueError) as exc:
                raise R323AuditHold('R326_Q01_INDEPENDENT_SOURCE_HOLD:'+str(exc)) from exc
            if (execute[:len(exp)]!=exp or ad['draws']!=execute or
                ad['trace_sha256']!=sha(execute)):
                raise R323AuditHold('R326_Q01_PREINTENT_EFFECT_FULL_TRACE_DRIFT')
        else:
            if ad['draws']!=exp or ad['trace_sha256']!=sha(exp):
                raise R323AuditHold('R323_FORECAST_ORDER_VALUE_OR_HASH')
            if action=='START':
                execute=e['detail']['inner']['r322_rng_causality']['draws']
                if execute!=exp:raise R323AuditHold('R323_START_PREVIEW_EXECUTION_PARITY')
        if action=='ATTACK' and request.get('reaction')=='COUNTERATTACK':
            execution=e['detail']['inner']['r321_rng_causality']['draws']
            # The pre-intent calls are a separate stateless forecast, never a
            # second stream consumption or identical order to executed effect.
            seen={d['label']:d['values'] for d in execution}
            if any(d['label'] not in seen or seen[d['label']]!=d['values'] for d in exp):
                raise R323AuditHold('R323_FORECAST_EFFECT_VALUE_DRIFT')
        if action=='ATTACK' and request.get('reaction')!='COUNTERATTACK' and exp:
            raise R323AuditHold('R323_PHANTOM_PRE_INTENT_RNG')
        forecasts+=int(bool(exp));calls+=len(exp)
    if nonce!=st['roll_nonce']:raise R323AuditHold('R323_FINAL_NONCE')
    return {'status':'PASS_R323_PRE_INTENT_VS_EFFECT_DIFFERENTIAL_TEST_ONLY',
        'events':len(rows),'forecast_events':forecasts,'forecast_draw_calls':calls,
        'seed':seed,'official_rng_certified':False,'canonical_effects':0}
