"""Read-only differential audit of R322 START/PASS/HEAL and R321 ATTACK traces.

Scope: synthetic two-actor R21/R22 TEST history. Rebuilds dice and A1 event
order from committed SQLite events; not a canonical RNG, battle rules engine,
or a substitute for the existing R21/289 audit.
"""
import hashlib,json,random,sqlite3
from pathlib import Path
from audit_r321_rng import audit as audit_attack, R321AuditHold
from audit_r289_r21_heal import inspect as audit_heal, AuditHold

VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
SRC='LAB_R322_CONTROL_HEAL_EFFECT_TRACE_V1'
GEN='KEYED_SHA256_RANDOM_RANDOM_ACCESS_NOT_SEQUENTIAL_CANONICAL'
SCOPE='COMMITTED_EFFECT_ONLY_PRE_INTENT_EXCLUDED'
class R322AuditHold(ValueError):pass

def canon(a):return json.dumps(a,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def digest(a):return hashlib.sha256(canon(a).encode()).hexdigest()
def die(seed,nonce,label,n=1):
    ent=hashlib.sha256(f'{seed}|{nonce}|{label}|{n}d6|{VERSION}'.encode()).digest()
    rand=random.Random(int.from_bytes(ent,'big'))
    return [rand.randint(1,6) for _ in range(n)]
def check_trace(inner,kind,before,after,seed,labels):
    tr=inner.get('r322_rng_causality')
    if not isinstance(tr,dict) or set(tr)!={'source','scope','generator','kind','nonce_before','nonce_after','draws','trace_sha256','canonical_rng_certified'}:
        raise R322AuditHold('R322_TRACE_MISSING_OR_UNEXPECTED_FIELDS')
    if (tr['source'],tr['scope'],tr['generator'],tr['kind'])!=(SRC,SCOPE,GEN,kind) or tr['canonical_rng_certified'] is not False:
        raise R322AuditHold('R322_SCOPE_FALSE_CLAIM')
    if type(tr['nonce_before']) is not int or type(tr['nonce_after']) is not int or (tr['nonce_before'],tr['nonce_after'])!=(before,after):
        raise R322AuditHold('R322_NONCE_DRIFT')
    draws=[{'ordinal':i+1,'nonce':nonce,'label':label,'count':1,'faces':6,'values':die(seed,nonce,label)} for i,(nonce,label) in enumerate(labels)]
    if tr['draws']!=draws or tr['trace_sha256']!=digest(draws):
        raise R322AuditHold('R322_DRAW_ORDER_VALUES_OR_HASH')
    return draws

def inspect(path, *, verify_legacy=True):
    file=Path(path)
    if not file.is_file():raise R322AuditHold('R322_DB_MISSING')
    uri=file.resolve().as_uri()+'?mode=ro'
    con=sqlite3.connect(uri,uri=True,timeout=5)
    try:
        m=dict(con.execute('SELECT key,value FROM meta'))
        if con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]:raise R322AuditHold('R322_PENDING_UNKNOWN_EFFECT')
        events=[json.loads(v) for (v,) in con.execute('SELECT row_json FROM events ORDER BY seq')]
    finally:con.close()
    st=json.loads(m['state']);actors=st['actors'];seed=st['seed'];nonce=0;active=None;round_number=0;order=None
    if len(actors)!=2 or type(seed)!=int or not events or len(events)!=int(m['revision']):raise R322AuditHold('R322_BASE_INVALID')
    heals=passes=attacks=starts=0
    for seq,e in enumerate(events,1):
        if e['seq']!=seq or e['kind']!='R21_DECISION':raise R322AuditHold('R322_EVENT_KIND_OR_SEQUENCE')
        d=e['detail'];x=d['inner'];action=d['decision'];rows=d['a1_control_rows'];kinds=[r['kind'] for r in rows]
        if e['payload']['action']!=action or not isinstance(rows,list):raise R322AuditHold('R322_DECISION_LINEAGE')
        if action=='START':
            starts+=1
            if starts!=1 or seq!=1 or active is not None:raise R322AuditHold('R322_START_POSITION')
            labels=[(0,'initiative:'+aid) for aid in actors]
            if st.get('r326_scheduler_policy')=='R326_Q01_Q02_APPROVED_TEST_ONLY':
                from audit_r326_contract import audit_start, R326AuditHold
                try:order=audit_start(st,actors,x,seed)['order']
                except R326AuditHold as exc:raise R322AuditHold('R326_Q01_INDEPENDENT:'+str(exc)) from exc
            else:
                draw=check_trace(x,'START',0,0,seed,labels)
                score={aid:draw[i]['values'][0]+actors[aid]['stats']['des']+actors[aid]['stats']['init_bonus'] for i,aid in enumerate(actors)}
                if len(set(score.values()))!=2:raise R322AuditHold('R322_INITIATIVE_TIE_NO_AUTHORITY')
                order=sorted(score,key=lambda a:-score[a])
            if x['order']!=order or x['turn_started']!=order[0] or kinds!=['ROUND_START','TURN_START']:
                raise R322AuditHold('R322_INITIATIVE_OR_SCHEDULER')
            active=order[0];round_number=1
            if rows[1]['actor']!=active:raise R322AuditHold('R322_START_ACTOR')
            continue
        if starts!=1 or active is None and action not in ('ATTACK',):raise R322AuditHold('R322_MISSING_ACTIVE')
        committed=e['payload']['request']['actor']
        if committed!=active:raise R322AuditHold('R322_WRONG_ACTOR')
        before=nonce
        if action=='ATTACK':
            if st.get('r326_scheduler_policy')=='R326_Q01_Q02_APPROVED_TEST_ONLY':
                from audit_r326_contract import audit_q02_single, R326AuditHold
                try:audit_q02_single(st,x,seq)
                except R326AuditHold as exc:raise R322AuditHold('R326_Q02_INDEPENDENT:'+str(exc)) from exc
            attacks+=1;nonce+=1
            try:audit_attack(e,actors,seed,nonce)
            except R321AuditHold as exc:raise R322AuditHold('R322_ATTACK_TRACE:'+str(exc)) from exc
        elif action=='HEAL':
            heals+=1;nonce+=1
            draw=check_trace(x,'HEAL',before,nonce,seed,[(nonce,'LAB-R274-HEAL:'+active)])
            if x['actor']!=active or x['dice']!=draw[0]['values'] or x['pa_cost']!=0 or x['source_status']!='LAB_FIXTURE_COST_AND_1D6_NOT_CANON':
                raise R322AuditHold('R322_HEAL_SOURCE_DRIFT')
        elif action=='PASS':
            passes+=1
            check_trace(x,'PASS',before,before,seed,[])
            if x['actor']!=active:raise R322AuditHold('R322_PASS_ACTOR')
        else:raise R322AuditHold('R322_UNSUPPORTED_DECISION')
        control=x['control']
        if control['turn_end']!=active or not kinds or kinds[0]!='TURN_END' or rows[0]['actor']!=active:
            raise R322AuditHold('R322_TURN_END_MISMATCH')
        if control.get('combat_ended'):
            if control.get('next_turn') is not None or len(rows)!=1:raise R322AuditHold('R322_FINISH_SCHEDULER')
            if seq!=len(events):raise R322AuditHold('R322_POST_TERMINAL_EVENT')
            active=None;break
        idx=order.index(active);nextactor=order[(idx+1)%2];wrap=idx==1
        round_number+=int(wrap)
        expected=['TURN_END']+(['ROUND_END','ROUND_START'] if wrap else [])+['TURN_START']
        if (kinds!=expected or control.get('next_turn')!=nextactor or control.get('round')!=round_number or
            rows[-1]['actor']!=nextactor or control.get('reaction_auto_refresh') is not (st.get('r325_scheduler_mode')=='R325_R26_OWN_TURN_REFRESH_BRONZE_TEST_ONLY')):
            raise R322AuditHold('R322_SCHEDULER_OR_REFRESH')
        active=nextactor
    if st['roll_nonce']!=nonce or st['active']!=active or st['round']!=round_number:
        raise R322AuditHold('R322_FINAL_STATE_CONTROL_OR_NONCE')
    if st.get('r322_causality_scope')!='R322_SYNTHETIC_MULTI_ACTION_TRACE_REQUIRED_V1':
        raise R322AuditHold('R322_MISSING_SESSION_SOURCE_MARKER')
    if verify_legacy:
        try:prior=audit_heal(path)
        except AuditHold as exc:raise R322AuditHold('R322_PRIOR_AUDITOR:'+str(exc)) from exc
        if prior['heals']!=heals:raise R322AuditHold('R322_HEAL_COUNT_RECONCILIATION')
    return {'status':'PASS_R322_SYNTHETIC_MULTI_ACTION_ONLY','events':len(events),'heals':heals,'passes':passes,
            'attacks':attacks,'starts':starts,'final_nonce':nonce,'final_round':round_number,
            'seed':seed,'rng_type':'LABELLED_EXPERIMENTAL_NON_CANONICAL','terminal_contracts':0}
