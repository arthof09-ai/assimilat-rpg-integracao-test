# Recuperação R326 — notas de coordenação (MESTRE-ONLY, TEST)

## Não é um motor novo nem certificado terminal

A Biblioteca já contém os dois arquivos que o executor considerou ausentes: `vlab_effects_v08.py` está no ZIP interno R316 e `vlab_turn_runtime_v09plus_rebuilt.py` está no ZIP interno R319 do próprio Código-Mãe R326. Os SHA-256 dos dois batem EXATAMENTE com o gateway original. Não modificar o gateway, os pins, os arquivos de campanha ou a OP canônica.

## Reprodução executada nesta coordenação

1. Extrair o Stage12 original do pacote R326 em diretório TEST novo, preservando fontes originais.
2. Aplicar overlays R316→R325 em ordem cronológica sobre essa CÓPIA, sem omitir R316/R319. As pré-condições do instalador R325 e os 4 hashes pre-R326 foram conferidos.
3. Extrair o ZIP R326 interno e executar seu instalador original (`INSTALL_R326_TEST_COPY_ONLY.py`) sobre a cópia R325. Resultado efetivo: `INSTALLED_TEST_ONLY_PENDING_FULL_EXECUTION`, 5 arquivos, SHA anteriores e posteriores conferidos. Nenhum pin adulterado.
4. Rodar os 20 testes R326 com o diretório de engine de teste esperado. Resultado reproduzido: 20/20 PASS.
5. Ao executar a primeira cena NATIVE Q01 com empate, o auditor R323 original NÃO reconhece que a pré-validação inclui rolagens de desempate, e produz `R323_FORECAST_ORDER_VALUE_OR_HASH`. O SQLite já continha o evento confirmado; NÃO repetir o comando (consultar idempotência).
6. Na CÓPIA TEST, aplicar patch candidato em `audit_r323_admission.py`: antes de aceitar, recomputar os desempates com `audit_r326_contract.audit_start` (oráculo independente), exigir igualdade integral das previsões e efeitos. Não é bypass de auditoria.
7. Após nova ação com Reação Q02, auditor R322 rejeitava id da reação porque comparava seq-1 com o evento que usa seq de commit; patch candidato em `audit_r322_sequence.py`: verificar `audit_q02_single(st,x,seq)`, preservando auditoria causal.
8. Com esses dois diffs TEST, execução nativa do início à conclusão: **14 decisões SQLite, 7 rodadas, 11 ataques, 1 cura, 1 PASS, 11 declarações de Reação; empate real de Iniciativa; vencedor `LAB_PERSONALIZADO_2`**; auditorias R322 e R323 read-only PASS na cópia. TEST 2 atores Bronze; 0/17 contratos terminais certificados, 0/1875 células oficiais.

## Proteções

NÃO canonizar diffs automaticamente; dependem de revisão técnica, testes adversariais e atualização legítima do Código-Mãe por CM-000006. Recriar cenário novo para qualquer novo ensaio; nunca sobrescrever SQLite confirmado. Teste de fonte Q01/Q02 e um efeito de reação não demonstra multi-reações simultâneas com efeitos, nem RNG sequencial oficial, fontes 3+ ou NAC-PASS. Notion IBX-177/IBX-91 são rotas existentes; não criar OP ou auditor paralelo.

## Arquivos

- `historical_authenticated/*`: dois binários/fontes EXATOS extraídos dos overlays originais, com proveniência em `SOURCE_PROVENANCE.json`.
- `candidate_diff/*`: somente diferenças dos auditores existentes; não parte do Código-Mãe R326 canônico.
- `candidate_source/*`: arquivos de auditoria TEST após as diferenças.
- `evidence/*`: SQLite genuíno do laboratório + resumo, sem campanha.
- `scripts/recover_test_source.py`: auxiliar conservador opcional para casos com hash exato de Stage12 antigo; preferir reconstrução completa dos overlays históricos, pois mantém proveniência e outros patches.
- `scripts/native_demo_r326_test_only.py`: script de reprodução local para executor adaptar caminhos TEST; não usar por pressuposição em ambiente oficial.

## FIRST-PENDING real

CM-000006 deve revisar e absorver os dois diffs no mesmo motor, verificar replay e proteção por adulteração, obter prova que falhou antes/passou depois, persistir uma R326 versão revisada se apropriado; auditor competente CM-000003 via IBX-91, decisões aprovadas Q01/Q02 via NAC-NORM-01, gate NAC-PASS-02. Nenhuma atestação automática. Este pacote não substitui o executor e não muda os certificados terminais.
