import pathlib,sys,hashlib,json,shutil,sqlite3
BASE=pathlib.Path('/mnt/data/vlab_r326_recovery_TEST');sys.path.insert(0,str(BASE/'fusion_stage12'))
import vlab_r21_dynamic_a1 as r21,vlab_r20_configured as cfg,vlab_r18_interactive as core
out=pathlib.Path('/mnt/data/vlab_r326_native_fullfight_TEST');out.mkdir(exist_ok=True)
roster=cfg.defaults()
for obj in roster:obj.update({'des':20,'init_bonus':0,'hp':70,'ca':14,'for':14,'luta':1,'damage_bonus':8,'con':7,'fort':1,'reflex':0})
seed=20261018;db=out/'R326_Q01_Q02_FULLFIGHT_SYNTHETIC.sqlite'
if db.exists():raise Exception('ORIGINAL_TEST_DB_EXISTS_NO_OVERWRITE')
source_sha=hashlib.sha256(('R26_OWN_TURN_REFRESH|bronze_test|https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2|'+'SOURCE_RULE_IN_ORIGINAL_R26_AUDIT_NOT_PRODUCTION_CERTIFIED').encode()).hexdigest()
r21.create(db,seed,roster,defender=True);r21.activate_r325_scheduler_fixture(db,source_hash=source_sha);r21.activate_r326_scheduler_policy(db,decision_sha=r21.R326_POLICY_SOURCE_SHA)
heal=False;pass_done=False;reactions=0;actions=[]
for i in range(60):
 st,head,rev=r21.checked_load(db)
 if st['phase']=='COMPLETE_LAB':break
 actor=st['active'];target=next((a for a in st['actors'] if a!=actor),None)
 if st['phase']=='INIT':action='START';t='';reaction='NONE'
 elif st['round']>=2 and not heal and st['actors'][actor]['resource']['hp'] < st['actors'][actor]['stats']['hp']:
  action='HEAL';t='';reaction='NONE';heal=True
 elif st['round']>=2 and not pass_done:
  action='PASS';t='';reaction='NONE';pass_done=True
 else:
  action='ATTACK';t=target;reaction='DEFENDER' if st['actors'][target]['resource']['reaction']==1 else 'NONE'
 intent=hashlib.sha256(f'R326_TEST_ONLY_{seed}_{rev}_{action}'.encode()).hexdigest()[:32]
 try:
  rec=r21.validated_step(db,rev,head,action,t,reaction,intent,expected_actor=actor or '')
 except Exception as e:
  import traceback;traceback.print_exc();print('FAILED',i,rev,action,reaction,'db',db);break
 reactions+=reaction!='NONE';actions.append({'seq':rev+1,'action':action,'reaction':reaction})
else:print('HOLD max60 steps reached')
try:
 from audit_r322_sequence import inspect as audit322
 from audit_r323_admission import inspect as audit323
 a=audit322(db);b=audit323(db);final=r21.checked_history(db)
 print('RESULT',json.dumps({'events':len(actions),'reactions':reactions,'healed':heal,'passed':pass_done,'phase':final['state']['phase'],'rounds':final['state']['round'],'winner':final['state'].get('winner'),'audit322':a,'audit323':b},ensure_ascii=False,indent=2))
 (out/'R326_Q01_Q02_FULLFIGHT_LOCAL_PROOF.json').write_text(json.dumps({'events':actions,'audits':{'R322':a,'R323':b},'state':final['state'],'sha256':hashlib.sha256(db.read_bytes()).hexdigest()},indent=2,ensure_ascii=False))
except Exception as e:
 import traceback;traceback.print_exc()
