#!/usr/bin/env python3
"""Recover exactly two pinned R326 gateway sources from this evidence bundle.
Target: NEW local isolated TEST copy only, already constructed from authentic R325 baseline.
Does not run installer or patch gateway. Refuses mismatched files and unsafe existing targets.
"""
from pathlib import Path
import zipfile,hashlib,argparse,json
R=Path(__file__).resolve().parents[1]
P=argparse.ArgumentParser();P.add_argument('--target-test-copy',required=True,type=Path);args=P.parse_args()
target=args.target_test_copy.resolve(strict=True)
if target.is_symlink() or not target.is_dir() or any(v.lower() in ('party','o primeiro','campanha','official','original','notion') for v in target.parts):
 raise SystemExit('HOLD_UNSAFE_TARGET')
if not (target/'fusion_stage12/unified_gateway.py').is_file():raise SystemExit('HOLD_NO_ORIGINAL_GATEWAY')
manifest=json.loads((R/'SOURCE_PROVENANCE.json').read_text())
for name,meta in manifest['source_pins'].items():
 data=(R/'historical_authenticated'/name).read_bytes()
 expected=meta['expected_sha256'];actual=hashlib.sha256(data).hexdigest()
 if actual!=expected:raise SystemExit('HOLD_BAD_ORIGIN_HASH:'+name)
 dst=target/'working/historical_v09_documentary_rebuilt/comestre_vlab'/name
 if dst.is_symlink() or not dst.is_file():raise SystemExit('HOLD_TARGET_SOURCE_MISSING_OR_LINK:'+name)
 # No replacement if already pinned; otherwise replace only known R22 reconstructed old SHA.
 baseline={
  'vlab_effects_v08.py':'066ffe9636d07e09b192695cff94df21a1116d4e391452805bf13f37af440d29',
  'vlab_turn_runtime_v09plus_rebuilt.py':'2b301feadd8352c35deac629913cb5f86a380a60808da3ea6b1e5a21fdae5cd7'}
 current=hashlib.sha256(dst.read_bytes()).hexdigest()
 if current not in (baseline[name],expected):raise SystemExit('HOLD_TARGET_UNEXPECTED_DRIFT:'+name)
 if current!=expected:dst.write_bytes(data)
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==expected
 print('AUTHENTICATED_TEST_ONLY',name,expected)
