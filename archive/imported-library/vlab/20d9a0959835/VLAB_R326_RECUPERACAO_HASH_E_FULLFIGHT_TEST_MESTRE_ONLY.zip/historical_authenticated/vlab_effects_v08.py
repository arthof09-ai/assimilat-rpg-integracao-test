"""Source-gated event adapters for Combat / Magic / Transform / RD.

No random unverified RPG rule is introduced. A catalog menu proves option
availability; an effect resolver uses source-specific payloads. SourceProof
is an EVIDENCE POINTER only; it must be joined to a physically re-opened Notion
record by the external authoritative gate. Fixtures are LAB_ONLY until then.
"""
from __future__ import annotations
from dataclasses import dataclass,field,asdict
from fractions import Fraction
from copy import deepcopy
from hashlib import sha256
import json
from typing import Literal
from vlab_action_catalog_v01 import ActorActionState,AbilitySource,FrozenRuleEvidence,action_menu
from vlab_rd_v08 import DamageComponent,Resistances,mitigate,RDUnresolved

VERSION='COMBAT-EFFECT-ADAPTER-PARTIAL-v0.8'
COMBAT_PAGE='3ebc2b32-4ede-81f1-be4b-e8804ac113c0'
MAGIC_PAGE='3ebc2b32-4ede-81f7-b343-f7270ff91373'
TRANSFORM_PAGE='3f2c2b32-4ede-81c0-ae0e-e4e66212edc9'
class EffectBlocked(ValueError):pass

@dataclass
class Combatant:
    actor_id:str
    hp:int
    pa:int|None
    ca:Fraction
    constitution:int
    armor:int
    fortitude:int
    reflex:int
    position:str
    rank:str='Bronze'
    standard:int=1
    movement:int=1
    reaction:int=1
    mode:str='NORMAL'
    spirit_id:str|None=None
    form_overlay:dict|None=None
    transformation_remaining:int|None=None
    def __post_init__(self):
        if self.hp<0 or (self.pa is not None and self.pa<0):raise EffectBlocked('invalid resources')
        if self.standard not in (0,1) or self.movement not in (0,1) or self.reaction not in (0,1):raise EffectBlocked('invalid action budget')

@dataclass
class Scene:
    actors:dict[str,Combatant]
    events:list[dict]=field(default_factory=list)
    seed:int=0
    provenance:str='LAB-TEST-SYNTHETIC-NONCANON'
    def __post_init__(self):
        if any(i!=x.actor_id for i,x in self.actors.items()):raise EffectBlocked('actor map/ID mismatch')
    def record(self,entry):
        row={'seq':len(self.events)+1,'engine':VERSION,'provenance':self.provenance,**entry}
        self.events.append(row)
        return row
    def checksum(self):return sha256(json.dumps(self.events,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()


def _require_option(scene:Scene,actor_id:str,source:AbilitySource,state:ActorActionState,proofs:tuple[FrozenRuleEvidence,...], *, phase='TURN',strict=True,target=None):
    if actor_id not in scene.actors:raise EffectBlocked('actor not present')
    if state.actor_id!=actor_id:raise EffectBlocked('actor/ability context mismatch')
    compile=action_menu(state,(source,),phase=phase,strict=strict,source_evidence=proofs)
    matches=[o for o in compile.legal_options if o.target_id==target]
    if not matches:raise EffectBlocked('not source/legal/action-ready: '+str(compile.rejected))
    return matches[0]


def apply_weapon_attack(scene:Scene,attacker_id:str,defender_id:str,*, source:AbilitySource,
                        state:ActorActionState, proofs:tuple[FrozenRuleEvidence,...],
                        roll_score:int,damage:int,damage_tag:str,rd:Resistances,
                        strict:bool=True,defense_event:dict|None=None,
                        critical_rolls:tuple[int,int,int]|None=None,
                        critical_positive:bool=False, attack_economy:str="STANDARD"):
    a=scene.actors[attacker_id];d=scene.actors[defender_id]
    if attack_economy not in ('STANDARD','REACTION') or source.economy!=attack_economy or source.kind!='attack':
        raise EffectBlocked('attack source/economy mismatch')
    if attack_economy=='STANDARD' and a.standard!=1:raise EffectBlocked('standard already spent')
    if attack_economy=='REACTION' and a.reaction!=1:raise EffectBlocked('reaction already spent')
    if attack_economy=='REACTION' and source.reaction_trigger!='BEFORE-ATTACK':
        raise EffectBlocked('counter reaction trigger required')
    if critical_positive:
        if (not isinstance(critical_rolls,(tuple,list)) or len(critical_rolls)!=3 or
           any(type(n)!=int or n not in range(1,7) for n in critical_rolls) or
           tuple(critical_rolls) not in ((6,6,5),(6,6,6))):
            raise EffectBlocked('positive critical must have valid sequential 3d6 source')
    elif critical_rolls is not None:
        if (not isinstance(critical_rolls,(tuple,list)) or len(critical_rolls)!=3 or
            any(type(n)!=int or n not in range(1,7) for n in critical_rolls)):
            raise EffectBlocked('critical roll source invalid')
        if tuple(critical_rolls) in ((6,6,5),(6,6,6)):
            raise EffectBlocked('unrecognized positive critical')
        if tuple(critical_rolls) in ((1,1,1),(1,1,2)):
            raise EffectBlocked('negative critical mechanics source hold')
    if not isinstance(roll_score,int) or roll_score<0:raise EffectBlocked('invalid roll')
    _require_option(scene,attacker_id,source,state,proofs,phase=attack_economy if attack_economy=="REACTION" else "TURN",strict=strict,target=defender_id)
    if d.hp<=0 or a.hp<=0:raise EffectBlocked('not a current legal actor/target')
    hit=critical_positive or roll_score>d.ca
    negated=False
    if defense_event is not None:
        if not scene.events or scene.events[-1]!=defense_event or defense_event.get('seq')!=len(scene.events):
            raise EffectBlocked('defense event must be immediate and unconsumed')
        if defense_event.get('by')!=defender_id or defense_event.get('attack_score')!=roll_score:
            raise EffectBlocked('defense event does not match incoming attack')
        if defense_event.get('action') not in ('DEFENDER','ESQUIVAR'):
            raise EffectBlocked('unresolved defense')
        negated=bool(defense_event.get('damage_negated'))
    # DEFENDER can neutralize physical damage even when the raw hit landed.
    outcome=mitigate((DamageComponent(damage,damage_tag,source.action_id),),rd) if hit and not negated else None
    before=d.hp
    if attack_economy=="REACTION":a.reaction=0
    else:a.standard=0
    if outcome:d.hp=max(0,d.hp-outcome.effective)
    return scene.record({'action':'weapon_attack','from':attacker_id,'to':defender_id,
        'roll_score':roll_score,'ca_exact':str(d.ca),'hit':hit,
        'action_economy':attack_economy,'critical_positive':critical_positive,
        'critical_rolls':list(critical_rolls) if critical_rolls is not None else None,
        'defensive_reaction':defense_event.get('action') if defense_event else None,
        'defense_negated':negated,'raw':damage if outcome else 0,
        'type':damage_tag,'rd_applied':outcome.applicable_rd if outcome else 0,
        'net':outcome.effective if outcome else 0,'before_hp':before,'after_hp':d.hp,
        'official_death_derived':False,'status':'LAB-STOP-HP0-NOT-CANON'})


def react_defensively(scene:Scene,defender_id:str,*,kind:Literal['DEFENDER','ESQUIVAR'],
                       attack_score:int,announced_before:bool,trigger_source:str,
                       source:AbilitySource,state:ActorActionState,
                       proofs:tuple[FrozenRuleEvidence,...],strict:bool=True):
    defender=scene.actors[defender_id]
    if not announced_before:raise EffectBlocked('reaction must be declared BEFORE an attack')
    if defender.reaction!=1:raise EffectBlocked('reaction not available')
    if not trigger_source or source.reaction_trigger!=trigger_source:raise EffectBlocked('source trigger mismatch')
    if source.economy!='REACTION' or source.kind!='reaction':raise EffectBlocked('wrong reaction adapter')
    # Same ActionCatalog source proof and window gate as other actions.
    _require_option(scene,defender_id,source,state,proofs,phase='REACTION',strict=strict,target=defender_id)
    form=defender.form_overlay if defender.mode=='TRANSFORMED' else None
    if form is not None:
        # Do not silently use base defenses if the activated form did not publish them.
        if 'CA' not in form or 'CON' not in form or 'Fortitude' not in form or 'Reflexo' not in form or 'Armadura' not in form:
            raise EffectBlocked('transformed defense snapshot incomplete')
    ca=Fraction(form['CA']) if form is not None else defender.ca
    con=form['CON'] if form is not None else defender.constitution
    armor=form['Armadura'] if form is not None else defender.armor
    fort=form['Fortitude'] if form is not None else defender.fortitude
    reflex=form['Reflexo'] if form is not None else defender.reflex
    if kind=='DEFENDER':defense=6+con+armor+fort
    elif kind=='ESQUIVAR':defense=ca+reflex
    else:raise EffectBlocked('unresolved reaction kind')
    defender.reaction=0
    return scene.record({'action':kind,'by':defender_id,'attack_score':attack_score,
        'defense_exact':str(defense),'damage_negated':attack_score<=defense,
        'consumes_reaction':True,'source':trigger_source,
        'qualification':'DEFENDER: on success no damage; ESQUIVAR: evade hit on success'})


def move_via_verified_path(scene:Scene,actor_id:str,*,source:AbilitySource,state:ActorActionState,
                           proofs:tuple[FrozenRuleEvidence,...],destination:str,
                           path_evidence:str,travel_cost:Fraction,speed:Fraction,
                           strict:bool=True):
    a=scene.actors[actor_id]
    if a.movement!=1:raise EffectBlocked('movement spent')
    if source.kind!='move' or source.economy!='MOVEMENT':raise EffectBlocked('wrong move adapter')
    if not path_evidence or not destination:raise EffectBlocked('verified path and destination needed')
    if travel_cost<0 or speed<0 or travel_cost>speed:raise EffectBlocked('path beyond verified speed')
    # Scenario must already have reviewed legal adjacency/terrain/line-of-sight;
    # do not invent a 5ft square or metric conversion.
    _require_option(scene,actor_id,source,state,proofs,strict=strict,target=None)
    before=a.position;a.position=destination;a.movement=0
    return scene.record({'action':'move','by':actor_id,'from':before,'to':destination,
        'path_proof':path_evidence,'travel_cost':str(travel_cost),'speed':str(speed)})

TRANS_COST={'Bronze':(20,'FULL','1d4',1),'Prata':(40,'FULL','1d6',1),
            'Ouro':(80,'STANDARD','1d8',1),'Ouro Negro':(160,'MOVEMENT','1d10',1),
            'Lendário':(320,'FREE','1d12',2)}

@dataclass(frozen=True)
class AssimilatedSpirit:
    spirit_source_id:str
    maximum_level:int
    bap_per_level:Fraction
    overlay_delta:dict[str,int]
    overlay_precomputed:dict
    provenance:str
    def __post_init__(self):
        if not self.spirit_source_id or self.provenance=='':raise EffectBlocked('source spirit missing')
        if not 1<=self.maximum_level<=25:raise EffectBlocked('invalid spirit cap')
        if self.bap_per_level<0:raise EffectBlocked('invalid BAP')
        if any(type(n)!=int or n<0 for n in self.overlay_delta.values()):raise EffectBlocked('invalid overlay')
        if set(self.overlay_delta)!={'FOR','DES','CON','INT','SAB','CAR'}:raise EffectBlocked('missing six attribute overlay')
        if not self.overlay_precomputed:raise EffectBlocked('transformation stats not precomputed')


def transformed_budget(ordinal_level:int,spirit:AssimilatedSpirit):
    lv=min(ordinal_level,spirit.maximum_level)
    raw=spirit.bap_per_level*lv/2
    return lv,raw.numerator//raw.denominator,raw-(raw.numerator//raw.denominator)


def activate_transformation(scene:Scene,actor_id:str,*,source:AbilitySource,
        state:ActorActionState,proofs:tuple[FrozenRuleEvidence,...],spirit:AssimilatedSpirit,
        ordinal_level:int,duration_die_roll:int,compatible:bool,strict:bool=True,
        full_reaction_policy:Literal['PENDING','LAB-CONSUME','LAB-PRESERVE']='PENDING'):
    actor=scene.actors[actor_id]
    if actor.spirit_id is None or actor.spirit_id!=spirit.spirit_source_id:raise EffectBlocked('spirit must actually be assimilated')
    if actor.mode!='NORMAL':raise EffectBlocked('already transformed')
    if actor.rank not in TRANS_COST:raise EffectBlocked('unknown rank')
    cost,economy,die,plus=TRANS_COST[actor.rank]
    if (source.kind,source.economy,source.required_pa)!=('transform',economy,cost):
        raise EffectBlocked('source ability/rank activation mismatch')
    if actor.pa is None or actor.pa<cost:raise EffectBlocked('not enough verified PA')
    from re import fullmatch
    face=int(die.partition('d')[2]);
    if type(duration_die_roll)!=int or not 1<=duration_die_roll<=face:raise EffectBlocked('duration die out of bounds')
    lv,points,carry=transformed_budget(ordinal_level,spirit)
    if sum(spirit.overlay_delta.values())!=points:raise EffectBlocked('TAP accumulated checksum violated')
    if economy=='FULL' and full_reaction_policy=='PENDING':
        raise EffectBlocked('FULL normally consumes reaction: specify approved policy or explicit LAB overlay')
    _require_option(scene,actor_id,source,state,proofs,strict=strict,target=actor_id)
    if economy=='FULL':
        if actor.standard!=1 or actor.movement!=1:raise EffectBlocked('full action not available')
    elif economy=='STANDARD' and actor.standard!=1:raise EffectBlocked('standard action spent')
    elif economy=='MOVEMENT' and actor.movement!=1:raise EffectBlocked('movement spent')
    elif economy=='FREE' and not state.free_action_contract_ready:raise EffectBlocked('free action not certified')
    # Commit everything only after all gates have passed.
    if economy=='FULL':
        actor.standard=0;actor.movement=0
        if full_reaction_policy=='LAB-CONSUME':actor.reaction=0
    elif economy=='STANDARD':actor.standard=0
    elif economy=='MOVEMENT':actor.movement=0
    actor.pa-=cost;actor.mode='TRANSFORMED';actor.form_overlay=deepcopy(spirit.overlay_precomputed)
    actor.transformation_remaining=duration_die_roll+plus+(1 if compatible else 0)
    return scene.record({'action':'transform','by':actor_id,'spirit_id':spirit.spirit_source_id,
      'effective_level':lv,'TAP':str(spirit.bap_per_level/2),'overlay_points':points,
      'carry':str(carry),'PA_spent':cost,'duration_roll':duration_die_roll,
      'duration_total':actor.transformation_remaining,'duration_unit':'turns',
      'rank':actor.rank,'mode':actor.mode,'full_reaction_policy':full_reaction_policy,
      'expiration_timing_resolver':'PENDING-CANON-SOURCE',
      'ff_marks_preserved':True,'state':'TRANSFORMED-FORM-SNAPSHOT-LOADED'})


def cast_source_specified_spell(scene:Scene,caster_id:str,target_id:str,*,source:AbilitySource,
                                state:ActorActionState,proofs:tuple[FrozenRuleEvidence,...],
                                damage:int,damage_tag:str,rd:Resistances,
                                explicit_save_effect:Literal['NO-SAVE','SAVE-FULL-NEGATE','SAVE-HALF']='NO-SAVE',
                                target_save_exceeds_cd:bool|None=None,strict:bool=True):
    caster=scene.actors[caster_id];target=scene.actors[target_id]
    if source.kind!='spell':raise EffectBlocked('not a spell')
    if source.economy!='STANDARD':raise EffectBlocked('only default standard spell adapter supported')
    if source.required_pa<=0:raise EffectBlocked('spell PA cost source required for this adapter')
    if caster.pa is None or caster.pa<source.required_pa:raise EffectBlocked('PA unknown or low')
    if caster.standard!=1:raise EffectBlocked('action not available')
    _require_option(scene,caster_id,source,state,proofs,strict=strict,target=target_id)
    if explicit_save_effect!='NO-SAVE':
        if target_save_exceeds_cd is None:raise EffectBlocked('save outcome required')
        if explicit_save_effect=='SAVE-HALF':raise EffectBlocked('rounding of half damage needs source convention')
        if explicit_save_effect!='SAVE-FULL-NEGATE':raise EffectBlocked('unknown save effect')
    elif target_save_exceeds_cd is not None:raise EffectBlocked('cannot invent save')
    raw=0 if explicit_save_effect=='SAVE-FULL-NEGATE' and target_save_exceeds_cd else damage
    outcome=mitigate((DamageComponent(raw,damage_tag,source.action_id),),rd)
    before=target.hp
    caster.pa-=source.required_pa;caster.standard=0;target.hp=max(0,target.hp-outcome.effective)
    return scene.record({'action':'spell','by':caster_id,'target':target_id,'source_rule':source.rule_id,
      'save_effect':explicit_save_effect,'save_exceeds_cd':target_save_exceeds_cd,
      'critical':'NOT-APPLICABLE-BY-SISTEMA-DE-MAGIA','raw':raw,'damage_type':damage_tag,
      'rd_applied':outcome.applicable_rd,'effective':outcome.effective,
      'hp_before':before,'hp_after':target.hp,'PA_spent':source.required_pa,
      'death':'NOT-ADJUDICATED'})
