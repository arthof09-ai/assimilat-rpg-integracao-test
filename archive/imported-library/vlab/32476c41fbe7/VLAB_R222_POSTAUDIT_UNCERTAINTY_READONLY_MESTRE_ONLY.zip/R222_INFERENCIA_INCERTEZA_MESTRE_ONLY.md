# R222 — Pós-auditoria estatística de iniciativa × associação de RNG

**Projeto:** ASSIMILAÇÃO — VLAB, `CM-000006-WS0001` · **Ambiente:** MESTRE-SIDE / TEST · **Documento adicional:** pós-auditoria READ-ONLY da R222 publicada; não altera seus SQLite, código, manifesto ou PSV. **Produção, Party e O Primeiro:** NO-WRITE / HOLD.

## Fonte e unidade correta

Fonte independente dos runners de combate: `R222_R91_C20_SOURCE_LIMITED_FACTORIAL_EXPLORATORY.csv`, SHA-256 `7806f7362b66a38637fe8e5374c3e40648a59c65e382446d1d609a61e9e8f475`, preservado no pacote VLAB_R222 da Biblioteca Mestre. Cada observação é **uma seed única com as quatro combinações** `INIT_A/INIT_B × ROUND/ABILITY` completas. Há **14 seeds**, não 56 unidades independentes. Em 11 das 14, as duas agendas realmente diferem.

Os campos `delta_Arveth_HP_*` e `delta_Varok_HP_*` representam diferenças assinadas `INIT_A − INIT_B`; os campos `mapping_A/B_*` representam diferenças assinadas ROUND − ABILITY dentro da mesma iniciativa.

## Resultado fatorial e amplitude da incerteza

| Contraste de Arveth | Seeds com diferença / n | Fração observada | IC binomial exato 95%* | Média assinada HP no estrato | Intervalo de delta observado |
|---|---:|---:|---:|---:|---:|
| Iniciativa, fita indexada por rodada | 3/14 | 21,4% | 4,7%–50,8% | −5,50 | −69 a +1 |
| Iniciativa, fita indexada por ocorrência da habilidade | 1/14 | 7,1% | 0,18%–33,9% | −4,93 | −69 a 0 |
| Associação RNG por rodada versus habilidade, iniciativa A | 5/14 | 35,7% | 12,8%–64,9% | +2,21 | −11 a +27 |
| Associação RNG por rodada versus habilidade, iniciativa B | 5/14 | 35,7% | 12,8%–64,9% | +2,79 | −11 a +27 |

**Contraste complementar Varok:** diferença por iniciativa ocorre em **1/14** seeds sob ROUND e **1/14** sob ABILITY, em ambos os casos −35 HP naquela seed e zero nos demais; média −2,50 HP no conjunto. Os ICs de frequência para 1/14 são 0,18%–33,9%.

**Caso comprovado por dois mapeamentos:** seed `22288014`, `INIT_A − INIT_B` = **−69 PV Arveth**, **−35 PV Varok**, tanto ROUND como ABILITY. A ordem dos participantes difere e os dois regimes de RNG compartilham as comparações registradas. Isso é um **contraexemplo TEST** à hipótese de comutatividade universal da ordem; não é vitória, calibração de potência ou prova de efeito médio na campanha.

\* **IC Clopper–Pearson 95%:** intervalo de frequência binomial que serviria sob a hipótese simplificadora de seeds independentes e intercambiáveis para a mesma fixture. Dado o desenho fatorial condicionado à admissão (empates e `UNKNOWN_HALF_ODD` excluídos por bloqueio legítimo), as barras **não estimam a incidência em todo o sistema Assimilação**, não medem uma população canônica de Bestas ou campanhas, não demonstram significância de superioridade, e são especialmente amplas devido a n=14. Não usar os 76 braços válidos como denominador destas frequências.

## Auditoria READ-ONLY nova

A rotina `R222_UNCERTAINTY_POSTAUDIT.py` não importa motor nem SQLite writer. Ela rejeita SHA divergente da CSV, denominador incorreto, seed duplicada, fonte diferente de NPCs propostos, nível/célula alterados, evidência promovida indevidamente e resultados incompatíveis com as métricas preservadas. A execução produz `R222_POSTAUDIT_READONLY.json` e confere os seis campos de sensibilidade com intervalos exatos `scipy.stats.beta`, sem nova RNG e sem combate.

**Status:** `PASS_R222_POSTAUDIT_SOURCE_LIMITED_DESCRIPTIVE` — pós-auditoria estatística local; o checkpoint R222 principal continua intacto. Esta análise melhora a interpretação quantitativa da evidência **TEST exploratória** da posição C20 no esquema R91, sem preencher/homologar a célula (`0/1.875`) ou os contratos terminais (`0/17`).

## Próxima análise de maior valor

Uma comparação oficial requer: (i) iniciativa resolvida inclusive empates por norma competente; (ii) metade ímpar normativamente resolvida ou desenho independente que não omita seletivamente o ramo; (iii) adversários e armas fonte-canônicos; (iv) política independente de informação futura e comparação de streams pré-registrada; (v) validação de cenário, holdout e representatividade antes de inferir potência universal. Até lá, manter produção HOLD e nenhuma atualização do corpus DMG por este relatório.
