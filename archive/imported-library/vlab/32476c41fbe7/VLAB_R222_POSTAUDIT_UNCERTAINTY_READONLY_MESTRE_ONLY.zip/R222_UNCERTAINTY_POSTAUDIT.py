#!/usr/bin/env python3
"""Independent read-only sensitivity audit for existing R222 factorial CSV.
No VLAB engine, SQLite writers, network or combat runner imports.
"""
import csv, hashlib, json, sys
from pathlib import Path
from scipy.stats import beta

EXPECTED_SHA = '7806f7362b66a38637fe8e5374c3e40648a59c65e382446d1d609a61e9e8f475'
CSV_FILE = Path(__file__).resolve().parent / 'R222_R91_C20_SOURCE_LIMITED_FACTORIAL_EXPLORATORY.csv'
REPORT = Path(__file__).resolve().parent / 'R222_POSTAUDIT_READONLY.json'
fields = ['delta_Arveth_HP_ROUND','delta_Varok_HP_ROUND',
          'delta_Arveth_HP_ABILITY','delta_Varok_HP_ABILITY',
          'mapping_A_delta_Arveth_HP','mapping_B_delta_Arveth_HP']
raw=CSV_FILE.read_bytes()
assert hashlib.sha256(raw).hexdigest()==EXPECTED_SHA, 'INPUT_CSV_SHA_MISMATCH'
rows=list(csv.DictReader(raw.decode('utf-8').splitlines()))
assert len(rows)==14, 'DENOMINATOR'
assert len({r['seed'] for r in rows})==14, 'SEED_COLLISION'
assert all(r['schema_battery']=='C_BALANCED_TEAM_25' and r['power_position']=='20' and r['homologated']=='FALSE' and r['source_status']=='PROPOSED_MESTRE_SIDE' for r in rows), 'SOURCE_OR_AUTHORITY'
assert all(r['order_A'] and r['order_B'] for r in rows), 'ORDER_MISSING'
def clopper(k,n):
    return [0.0 if k==0 else float(beta.ppf(.025,k,n-k+1)),
            1.0 if k==n else float(beta.ppf(.975,k+1,n-k))]
metrics={}
for name in fields:
    values=[int(r[name]) for r in rows]
    k=sum(v!=0 for v in values)
    metrics[name]={
       'nonzero_count': k, 'denominator_independent_complete_quadruples': len(rows),
       'sample_fraction': k/len(rows), 'exact_clopper_pearson_95_percent':clopper(k,len(rows)),
       'mean_signed_HP_delta':sum(values)/len(rows), 'min_signed_HP_delta':min(values),
       'max_signed_HP_delta':max(values), 'sum_signed_HP_delta':sum(values)
    }
assert metrics['delta_Arveth_HP_ROUND']['nonzero_count']==3
assert metrics['delta_Arveth_HP_ABILITY']['nonzero_count']==1
assert metrics['mapping_A_delta_Arveth_HP']['nonzero_count']==5
assert metrics['mapping_B_delta_Arveth_HP']['nonzero_count']==5
s=[r for r in rows if r['seed']=='22288014']
assert len(s)==1
assert [int(s[0][x]) for x in fields[:4]]==[-69,-35,-69,-35]
note={'status':'PASS_R222_POSTAUDIT_SOURCE_LIMITED_DESCRIPTIVE', 'data_sha256':EXPECTED_SHA,
 'statistical_unit':'one unique seed with four complete paired factorial arms',
 'n_units':len(rows), 'initiative_order_changed_count':sum(r['order_A']!=r['order_B'] for r in rows),
 'metrics':metrics,'source_status':'PROPOSED_MESTRE_SIDE', 'official_cells_homologated':0,
 'inference_limitation':'Clopper-Pearson intervals are descriptive under hypothetical independent Bernoulli-seed sampling of this fixed TEST fixture. Not estimates of real RPG prevalence, general balance, or canonical superiority.'}
REPORT.write_text(json.dumps(note,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(note['status'], 'n',len(rows),'different_orders',note['initiative_order_changed_count'])
