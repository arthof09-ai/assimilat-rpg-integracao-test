from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'SHA256_MANIFEST_R298.json').read_text())
for n,v in m.items():
 p=root/n;assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==v,n
assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}==set(m)|{'SHA256_MANIFEST_R298.json','VERIFY_R298.py'}
print('R298_ARTIFACT_PASS',len(m))
