# R298 — Perfil de desempenho do replay A1 (MESTRE-ONLY)

R298 **não alterou nenhum código do motor**. É um diagnóstico dirigido posterior a R297, não uma rodada de combate oficial, uma aprovação de contrato ou uma implementação de otimização.

## Método e resultados

Instale R22+R295+R296 conforme manifests correspondentes. Rode o código portátil **já existente** do R297 pelo `python -m cProfile` usando semente 298354 e `--passes 14`. A execução instrumentada encerrou `EXIT 0`, processou iniciativa+14 decisões PASS e `checked_load`, no mesmo R21/R22. `R298_PROFILE_14PASS.prof` e `R298_CPROFILE_TOP.txt` permitem auditoria do perfil; são identificações de linhas originais, não código novo.

O perfil contabilizou 27.977.993 chamadas (25.156.519 primitivas), ~19,587s com overhead de profiler. O reprodutor `_fresh` do R21 foi chamado 129 vezes (18,773s **cumulativos**, incluindo chamadas filhas); o scheduler A1 `step` foi chamado 2864 vezes, os checkpoints do redutor A1 17184 vezes, a checagem `verify_pins` 23173 vezes e `pathlib.open` 162211 vezes. Isso identifica recalcular/reverificar origem em cascata como principal hipótese técnica de gargalo. Não confundir tempo cumulativo de funções aninhadas com partes independentes que somam o total.

As medições sem profiler do R297 são mais indicadas para a latência visível do Mestre. Este resultado é restrito a 2 atores TEST, decisões PASS, um host e uma semente; não extrapolar para 20x20 ou celular. A repetição de verificação de fontes pode ser custosa, mas **não deve ser eliminada sem invalidar caches corretamente e demonstrar equivalência/exclusividade**.

**R299 candidata:** investigar cache estritamente local à transação/requisição de arquivos de pin imutáveis, com invalidação por hash e alteração de fonte, replay A1 bytewise e provas adversariais (fonte alterada entre leitura e commit). Não criar segundo motor, nem alteração de regra. Identidade, writer, fencing, green e NAC-PASS global HOLD. Party/O Primeiro, Notion, DMG/LEVEL-UP: nenhuma escrita. 0/17 contratos e 0/1.875 células oficiais.
