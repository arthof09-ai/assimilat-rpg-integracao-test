# VLAB R301 — Batalhas nativas com ataque, reação e cura / paridade R299 (MESTRE-ONLY/TEST)

Esta unidade **não altera código**. Audita o comportamento do patch R299 sob carga diferente de `PASS`.

- Fonte de controle e experimental: mesmas árvores base R296; **somente módulo R21 diferente** como provado em R300. Cada par usa mesma semente, mesmo caminho local, mesmos IDs de combate e decisões.
- Sementes: 30101–30104; cada uma aplicada em dois braços: oito cenas completas de horizonte, 9 decisões por cena (1 iniciativa, 6 ataques, 2 curas); em cada uma 1 reação DEFENDER, total 72 decisões, 48 ataques nativos, 16 curas LAB (resolvedor v0.6) e 8 defesas v0.8.1. Estes 8 bancos são **ensaios sintéticos**, não células R91.
- Auditoria física: 4/4 pares retornaram **SQLite bytewise idêntico**, cadeia/eventos/estado/hash idênticos. Os oito SQLite estão arquivados e verificáveis com o auditor independente incluído (PRAGMA integrity + JSON + SHA-256).
- Tempo local agregado de `chat.decide`: controle **10.586 s**, otimizado **9.631 s**, redução observada **9.0%**. 4 pares apenas; uma variação de host pode alterar o sentido, e não é previsão de ganho geral. R300 PASS-only havia observado 13,2% com 4 pares. Esta diferença delimita custo de efeitos reais.
- Cópias históricos R22, R289–R295, R296, patch R299 mantidos intactos; nenhuma outra regra, módulo ou motor foi criado.
- Fonte P4 atual segue **HOLD**, iniciativa empatada/PA positivo/HP0 final dependem de norma. **0/17 contratos terminais e 0/1.875 células oficiais.** GitHub CI NOT_RUN, Notion, Party e O Primeiro NO-WRITE.

`R301_NATIVE_REPRODUCER.py` executa em cópia TEST do VLAB original. Informe o `--engine` e `--out`; ele apaga apenas o diretório dedicado `--root` do experimento, então nunca aponte `--root` para dados reais do Mestre. Use `VERIFY_R301.py` para verificações do pacote.
