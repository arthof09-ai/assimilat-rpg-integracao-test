# R301 errata portátil v2 — 2026-10-22

A primeira versão do verificador R301 abriu as cópias de SQLite em `mode=ro` e, conforme o ambiente SQLite, deixou arquivos `-wal` e `-shm` auxiliares, tornando a segunda verificação de conjunto exato inválida. **Nenhum dos oito bancos SQLite, relatórios JSON, resultados de combate, códigos do motor ou dados de fonte foi modificado.**

Correção exclusiva: usar `file:...?...mode=ro&immutable=1` para a cópia de banco arquivado após encerrar os escritores, sem criar sidecars. O verificador continua exigindo: hashes SHA-256, conjunto exato, `PRAGMA integrity_check`, paridade de bytes nos quatro pares e denominadores mecânicos. Essa imutabilidade é apropriada só para os artefatos congelados do ZIP; **não aplicar `immutable=1` a bancos vivos que podem conter WAL não integrado.**

Classificação: erro no leitor de prova, não no executor. A versão v1 foi preservada historicamente por SHA no checkpoint anterior; v2 substitui o pacote na Biblioteca após cold readback.
