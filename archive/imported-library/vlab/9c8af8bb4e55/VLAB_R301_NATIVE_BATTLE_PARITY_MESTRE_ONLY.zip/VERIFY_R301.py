from pathlib import Path
import json,hashlib,sqlite3
R=Path(__file__).resolve().parent
m=json.loads((R/'SHA256_MANIFEST_R301.json').read_text())
current={str(x.relative_to(R)) for x in R.rglob('*') if x.is_file() and x.name not in ('SHA256_MANIFEST_R301.json','VERIFY_R301.py')}
assert current==set(m),(current^set(m))
for name,digest in m.items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
pairs=0
for seed in range(30101,30105):
 base=R/'evidence'/f'{seed}_CONTROL.sqlite';opt=R/'evidence'/f'{seed}_OPT.sqlite'
 assert base.read_bytes()==opt.read_bytes(),seed
 for arm in ('CONTROL','OPT'):
  db=R/'evidence'/f'{seed}_{arm}.sqlite';record=json.loads((R/'evidence'/f'{seed}_{arm}.json').read_text())
  assert hashlib.sha256(db.read_bytes()).hexdigest()==record['sqlite_sha256']
  con=sqlite3.connect('file:'+str(db)+'?mode=ro&immutable=1',uri=True)
  try:assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  finally:con.close()
  assert record['revision']==9
  assert record['effects']=={'attacks':6,'heals':2,'defenses':1},record['effects']
 pairs+=1
print('PASS_R301_SOURCE_PARITY',pairs,'pairs',8,'sqlite databases',len(m),'hashed inputs')
