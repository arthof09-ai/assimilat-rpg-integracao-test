"""R301 bounded actual-native R18/R21/R22 attack/defend/heal workload, LAB only."""
from pathlib import Path
import argparse,json,sys,shutil,time,hashlib
p=argparse.ArgumentParser();p.add_argument('--engine',required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--out',required=True);p.add_argument('--root',default='/mnt/data/vlab_r301_workload_same_path');args=p.parse_args()
engine=Path(args.engine).resolve();sys.path.insert(0,str(engine/'fusion_stage12'))
import vlab_r22_chat_adapter as chat
import vlab_r21_dynamic_a1 as dyn
root=Path(args.root);shutil.rmtree(root,ignore_errors=True);root.mkdir(parents=True)
chat._combat_id=lambda:'vlab_00000000000000000000000000000301'
b=chat.create(root,{'scenario':'B','seed':args.seed})
trace=[]
for i in range(9):
 v=b['battle']
 if v['phase']=='COMPLETE_LAB':break
 req={'combat_id':v['combat_id'],'revision':v['revision'],'head':v['head'],'actor':v['active_actor'] or '',
      'intent_id':f'{i+1:032x}'}
 if v['phase']=='INIT':req['action']='START'
 else:
  legal={m['action']:m for m in v['available']}
  if 'HEAL' in legal and i%3==0:req['action']='HEAL'
  elif 'ATTACK' in legal:
   req['action']='ATTACK';a=legal['ATTACK'];req['target']=a['target']
   req['reaction']='DEFENDER' if 'DEFENDER' in a['reaction_choices'] and i%2==0 else 'NONE'
  elif 'PASS' in legal:req['action']='PASS'
  else:raise RuntimeError('NO_LEGAL_ACTION')
 start=time.perf_counter();b=chat.decide(root,req);cost=time.perf_counter()-start
 trace.append({'rev':b['battle']['revision'],'decision':req['action'],'reaction':req.get('reaction','NONE'),'cost_s':cost})
record=dyn.checked_history(chat.path_for(root,b['combat_id']))
db=chat.path_for(root,b['combat_id'])
final={'seed':args.seed,'mode':'TEST_ONLY','operations':trace,'total_decision_s':sum(v['cost_s'] for v in trace),
       'revision':record['revision'],'head':record['head'],'sqlite_sha256':hashlib.sha256(db.read_bytes()).hexdigest(),
       'state':record['state'],'events':record['events'],'effects':{'attacks':sum(v['decision']=='ATTACK' for v in trace),'heals':sum(v['decision']=='HEAL' for v in trace),'defenses':sum(v['decision']=='ATTACK' and v.get('reaction')=='DEFENDER' for v in trace)},'canonical_credits':0}
Path(args.out).write_text(json.dumps(final,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
shutil.copy2(db,Path(args.out).with_suffix('.sqlite'))
print(json.dumps({'status':'R301_NATIVE_TEST_COMPLETE','seed':args.seed,'revisions':len(trace),'attacks':final['effects']['attacks'],'heals':final['effects']['heals'],'elapsed_s':round(final['total_decision_s'],2)}))
