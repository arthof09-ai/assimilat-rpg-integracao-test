# PSV — CM-000006 / VLAB R47–R49 + R47B — três ciclos autônomos

**Data:** 16/10/2026. **Ambiente:** MESTRE-SIDE. **Operação persistente:** OP-VLAB-FUSION-SANDBOX-01, ID Notion `3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2`. **Autoridade:** ordem de Mestre para executar pelo menos três ciclos sem contato intermediário. **Resultado de engenharia:** três ciclos distintos executados mais ensaio complementar R47B, seis cenas novas, 15 eventos R18 SQLite, seis backups/checkpoints, 17/17 mutações adversariais rejeitadas e 6/6 guardas/idempotências PASS; **nenhum combate integral novo**.

## 1. Baseline ANTES e integridade

- Último checkpoint R46 de janelas AoO/Contra com fontes equipadas, prioridade expressa R43: mais DES, empate no dado maior e só empatados rerrolam pelo R26. R45 inicial causou ordem de declaração incorreta; R45B é prova corrigida, a primeira permanece quarentenada. Banco pending R46 e históricos R01–R46 nunca foram executados nem alterados nesta rodada.
- 17 contratos R18 originais (SHA `6303064ac97118ec1ed8763b94a5c014a641c1c67ac0efdb596c167abe6df744`), sem mudança no denominador nem nas exigências. Estado terminal 0/17; células canônicas 0/1.875; 18 combates completos históricos de sandbox até R40, outras cenas condicionais R41/R42 e sondas/censuras historicamente separadas. Campanha 0.
- Fontes verificadas Notion Mestre: Sistema de Combate `3ebc...`, Cabra `391c...`, Feryn `3f6c...1e31`, Varok `3f6c...1091`. Equipamentos documentados ativos: Feryn ON5 Luta 4d6+82, ataque equipado 4d6+92, dano 8d8+47, DES80, CA123, RD22, HP479, Reação1; Varok ON5 CA83, RD35, HP734. Cabra Bronze1 Investida individual 1d6+FOR13, bônus de Luta +6 apenas nessa habilidade, não ataque normal.
- R18 e R26 extraídos da R27 histórica autenticada, **mesmo SHA byte a byte**. Extensão R47–R49 separada; não se declara que R49 delega cada golpe diretamente ao resolvedor v0.8.1: o adaptador source-bound calcula ações de equipamento com RNG genuinamente gerado pelo R18 e persiste pelo `event_commit` histórico. Um oráculo separado recompõe sua legalidade sem importar esses módulos.

## 2. Ciclo R47 — positivo automático recebido sob Contra-atacar já declarado

**Conflito literal:** Sistema de Combate: o Contra-atacar pode ser anunciado antes do golpe e produz resposta com Vantagem se o ataque inimigo “não superar sua CA”. Decisão posterior do Mestre R41: **crítico positivo válido é acerto automático**, mesmo se ataque comum não superar a CA. São duas leituras possíveis: (A) condição estritamente numérica ainda autoriza resposta mesmo após acerto crítico; (B) sucesso automático do golpe prevalece e impede a resposta. Nenhuma precedência entre essas cláusulas foi fisicamente homologada. O adaptador **não faz resposta automática**, preserva reação declarada/consumida e aplica o acerto crítico e RD. Não cria regra mundial por inferência.

**R47, seed 98002:** primeira seed elegível entre **2 examinadas**, busca dirigida em [98001,99000], crítico 6→6→6 produzido pelo R18. Ataque comum baixo contra CA123; crítico acerta automaticamente; dano integralmente absorvido por RD22, HP Feryn479, reação1→0. Evento R18/checkpoint/replay independentes PASS. Este resultado levou ao novo teste discriminante positivo.

**R47B, seed 103182:** protocolo separado congelado ANTES da segunda busca: primeira seed com crítico positivo e dado de dano pelo menos4; **182 examinadas** em [103001,104000]. Crítico 6→6→6, dado dano4, bruto23, RD22, líquido**1**, Feryn479→478, reação1→0. Evento/checkpoint/auditoria PASS. Os dois casos são **selecionados**: nunca medir chance real do crítico a partir deles.

**Ponto residual:** resultado do golpe e custos foram processados; legalidade da resposta de Contra-atacar após esse crítico = `BLOCKED-NORMATIVE`, primeiro caso mínimo para o Mestre, sem inventar prioridade.

## 3. Ciclo R48 — aninhamento alcançável e fail-closed

**R48, seed 99001:** duas instâncias experimentais distintas Feryn (mesma fonte, CA123, Vida479, reação1 cada). A declara ataque normal (4d6+92) contra B; B anuncia Contra-atacar **antes dos dados**, consumindo slot1→0. O ataque de A dá **98**, não ultrapassa CA123. B executa resposta com Vantagem `max(4d6,4d6)+94 = 110`, também não ultrapassa CA123. HP ambos479. A ainda tem slot1: novo gatilho de Contra-atacar é alcançável durante a resposta. **A tentativa de segunda declaração foi bloqueada antes de nova reserva**, preservando causação e recursos, pois prioridade de aninhamento não está definida. R48 não é prova de contra-ataque aninhado completo e não admite impressão de vitória/dano.

**Guardas:** tentativa com slot ausente, novo comando pós-janela encerrada e replay idempotente tratados sem criar nova intenção nos bancos originais; 6/6 guards em CLONES descartáveis ou verificação pré-commit. A primeira resposta B está persistida dentro de único evento atômico; o segundo gatilho é diagnóstico em estado final, não contra-ataque executado.

## 4. Ciclo R49 — empate ON5 com 4d6 e dano fonte-equipado

**Regra R43:** maior DES age primeiro. Duas Feryns têm DES80 iguais: desempate no dado da classificação **4d6 para cada uma**; se o total empata, R26 rerrola somente essas empatadas, sem comparar IDs. Varok DES27 é alvo em deslocamento voluntário, não competidor na prioridade. Cada ataque AoO usa duas rolagens completas de 4d6 + bônus+2 (um nível de Vantagem), dano 8d8+47 e RD física35 do Varok.

Universo declarado antes de buscar: 100001–102000; selecionar primeira seed de três categorias de profundidade, não amostra probabilística:

| Seed | Disputa 4d6 Feryn A / B | Resultado | Dano líquido somado | Varok HP |
|---|---|---|---:|---:|
| 100001 | 9/13 | B primeiro, A segundo | 83 | 734→651 |
| 100013 | 17/17 → 16/14 | A primeiro após 1 empate | 104 | 734→630 |
| 100323 | 12/12 → 13/13 → 8/18 | B primeiro após 2 empates | 100 | 734→634 |

As cenas R49 possuem cada uma **4 eventos transacionais**: prioridade antes de qualquer efeito, ataque da primeira Feryn, ataque da segunda Feryn e só depois conclusão do Movimento do Varok. Duas Reações independentes são consumidas 1→0, Ações Padrão dos atacantes preservadas; checkpoints finais validam HP, RD35 e posição. **Total: seis AoOs reais-fonte em janelas de reação, 287 de dano líquido agregado em cenas independentes**, não um único combate nem dano oficial.

**Nota estatística:** foram inspecionadas até **323 seeds**, selecionadas por eventos de empate; não concluir probabilidade de empate ou uniformidade do gerador. Nas três cenas foram consumidas 12 rolagens COMPLETAS de 4d6 para prioridade (48 dados de seis lados) e demais rolagens separadas para ataque/dano.

## 5. Auditoria de quatro camadas

- **Estrutural:** seis ledgers R18/event_commit originais; 15 eventos com encadeamento SHA256, seis backups SQLite íntegros; zero pending. Sem reutilizar cmd IDs de cenas anteriores.
- **Mecânica:** verificador independente `verify_r47_r49_independent.py` STD-LIB, **não importa o executor, o R18, o R26 ou o v0.8.1**. Reconstrói crítica ordenada 3d6, ataques ON5 de duas rolagens 4d6, danos 8d8+47 e 1d6+13+6 crítico, RD22/35, HP, Reação, Ação e Movimento, eventos e estados SHA.
- **Causal:** R47 declaração antes do sorteio, hit crítico apesar de CA; R48 declaração antes do ataque com contra resposta; R49 prioridade antes dos golpes e deslocamento após dois golpes. Cabeça e checkpoints idênticos ao replay independente.
- **Normativa:** contra em hit crítico R47 e aninhamento R48 bloqueados por autoridade; R49 numericamente source-admitted, mas norma geral ainda não recebeu atualização escrita fora desta OP.
- **Falsificadores:** **17/17 adulterações em CLONES** com cadeia R18 recomposta estruturalmente válida, mas rejeitada pelo auditor independente: acerto automático negado, Counter inventado, reação dupla, dano/RD/HP incoerente, 1d6 no ON5, dado7, ordem invertida, score falso e Movimento prematuro. **6/6 guardas** adicionais de idempotência e preflight; regressões históricas R44–R46 e crítico R41 rodadas READ-ONLY PASS.

## 6. R18 — matriz dos 17 contratos preservada

Delta JSON mantém o ID, o requisito literal e os 17 registros; nenhum requisito foi reescrito. `REACTION_TRIGGER_AND_SINGLE_USE` avançou sobre crítico recebido, contador de slots, aninhamento alcançável e AoO duplo; `TURN_SCHEDULER_EVENT_SOURCING` ganhou prioridade ON5, window ordering e replay; `RNG_REPLAY_STATISTICS` ganhou fita ON5 4d6 e RNG crítico condicionado; `GENERAL_SPECIFIC_RD`, `ACTION_CATALOG_AIN01`, `ITEM_EQUIPMENT_AND_ENHANCEMENTS` e `AUTHORITATIVE_RULES_AND_ADAPTERS` receberam evidência incidental proporcional. Contratos restantes não exercitados. **0/17 terminalmente certificados, 0/1875 células canônicas**. Nenhum desses três ciclos exercitou um combate completo ou validou fonte de RNG canônico da campanha.

## 7. Continuidade — fronteira que realmente altera contrato

**FIRST-PENDING 1 (NAC-NORM):** definir se, depois de Contra-atacar declarado legalmente, um **crítico positivo que acerta automaticamente** ainda autoriza o golpe de resposta quando a pontuação comum não supera CA. Até lá, preservar `HOLD_R47_COUNTER_AFTER_CRIT` e não executar a resposta nesses bancos.

**FIRST-PENDING 2:** definir a precedência de aninhamento: quando A é alvo do Contra-atacar de B, pode A anunciar sua própria Reação e executar outro Contra-atacar antes de concluir a ação de B? Verificar se há proibição de Reação no próprio turno e como fechar a pilha; sem autoridade, fail-closed.

**FRONTEIRA INDEPENDENTE 3:** integração de prioridades ON5 em scheduler real de três atores, com iniciativa 4d6+82 e 4d6+29 publicadas, sem suposições de iniciativa da Cabra; testes completos e reação em turno próprio, com R26 e replay causal. Adicionar knockout durante AoO apenas se alcançado por dano realmente sorteado (não por HP sintético alterado).

**GATES INALTERADOS:** IBX-56 BLOCKED-EXTERNAL, writer/lease/epoch/fencing/GREEN produtivos HOLD; NAC-PASS-02 terminal HOLD; DMG-RANK v1.1 e todas as fichas/Party/O Primeiro/campanha e ledgers produtivos intocados. Bônus +6 de Cabra continua exclusivo de Investida, não AoO nem ataque normal.
