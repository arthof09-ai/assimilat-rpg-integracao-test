# R47–R49 — pacote delta Mestre-only

**Não reexecutar os seis bancos fechados.** Este pacote contém somente seis ledgers SQLite novos e seis checkpoints de suas operações, sem duplicar os 21 MB compactados da base R27 e sem representar atualização da Party ou da campanha.

## Verificação independente sem motor

1. Extraia o ZIP em diretório vazio.
2. Rode `python extension/verify_r47_r49_independent.py` dentro do pacote extraído. Ele usa apenas Python stdlib, reabre os seis bancos/checkpoints, reconstrói RNG, atributos, dano/mitigação e ordem causal a partir das fontes congeladas.
3. Para verificar CRC, manifesto e executar o auditor num diretório temporário limpo, rode `python extension/verify_r47_r49_package.py /caminho/do/arquivo.zip` em ambiente Python stdlib.
4. Os recibos de adversários (`evidence/R47_R49_RECHAINED_ADVERSARIAL.json`) foram obtidos com `extension/r47_r49_adversarial.py`, que requer R18 e R26 da R27 íntegra. **Não execute adversários contra bancos originais, apenas cópias**.

## Reconstrução histórica para desenvolvimento adicional

`extension/run_r47_r49.py` importa `vlab_r18_interactive.py` e `vlab_r26_master_rulings.py` do pacote original R27. Os hashes correspondentes constam em `evidence/R47_R49_PROVENANCE_IMMUTABILITY.json`. A base R27 e as dependências históricas NÃO estão neste delta; recupere-as da Biblioteca da operação e verifique SHA antes de quaisquer novos testes. O executor guarda caminhos absolutos para a pasta de trabalho do R47–R49; novo executor deve adequar sua cópia, jamais reexecutar os comandos anteriores.

## Status e decisões

- `R47`: Contra-atacar declarado antes de crítico positivo auto-hit: reação consumida e dano/mitigação aplicados; **resposta bloqueada por ambiguidade normativa**.
- `R47B`: discriminação adicional com RD22 e dano efetivo positivo, semente selecionada, não amostra aleatória.
- `R48`: primeira resposta de Contra-atacar com fonte real completa; segunda declaração aninhada não admitida sem precedência.
- `R49`: prioridade DES80 empatada entre instâncias Feryn ON5, desempate com 4d6 e R26, seis ataques equipados com dano e movimento depois da janela, três sementes dirigidas.
- `NAC-PASS` terminal 0/17, escritor produtivo HOLD, 0/1875 células canônicas, sem combates completos novos.
