"""Guards and safe copy-based replay/idempotency tests; no original writes."""
import copy,hashlib,json,sqlite3,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'fusion_stage12'));sys.path.insert(0,str(ROOT/'extension'))
import vlab_r18_interactive as core
import run_r47_r49 as e

def clone(src,dst):
 a=sqlite3.connect(f'file:{src}?mode=ro',uri=True);b=sqlite3.connect(dst)
 try:a.backup(b)
 finally:b.close();a.close()

def run():
 checks=[]
 with tempfile.TemporaryDirectory() as td:
  d=Path(td)
  for tag,f in [('R47','R47_POSITIVE_DAMAGE_NEW_SEED103182.sqlite'),('R48','R48_NESTED_COUNTER_SEED99001.sqlite'),('R49','R49_TWO_TIES_THEN_DECIDES_SEED100323.sqlite')]:
   q=d/f;clone(ROOT/'ledgers'/f,q)
   before,head,rev=core.load(q)
   con=sqlite3.connect(q);cmd,raw=con.execute('SELECT cmd_id,row_json FROM events ORDER BY seq LIMIT 1').fetchone();con.close();kind=json.loads(raw)['kind']
   blocked=False
   try:core.event_commit(q,cmd,kind,{'duplicate':True},lambda st,p,seq:{'bad_effect':True})
   except core.LabHold as ex:blocked='DUPLICATE' in str(ex)
   after,head2,rev2=core.load(q)
   assert blocked and before==after and head==head2 and rev==rev2
   checks.append({'tag':tag,'case':'SAME_CMD_ID_IDEMPOTENCY','pass':True,'revision':rev})
  # Guarded domain, not a new command reservation in original ledger.
  r48=core.load(ROOT/'ledgers/R48_NESTED_COUNTER_SEED99001.sqlite')[0]
  try:e.nested_preflight(copy.deepcopy(r48),'A');raise AssertionError('NESTED_SHOULD_HOLD')
  except e.Gate as g:assert str(g)=='BLOCKED_NORMATIVE_NESTED_COUNTER_PRIORITY'
  checks.append({'tag':'R48','case':'NESTED_NORMATIVE_BLOCK_BEFORE_INTENT','pass':True})
  # Risk of retrying an already closed AoO window with NEW cmd ID: must preflight
  r49=core.load(ROOT/'ledgers/R49_FIRST_ROLL_DECIDES_SEED100001.sqlite')[0]
  try:e.r49_attack(copy.deepcopy(r49),{'actor':'A','action':'AOO_EQUIPPED'},100);raise AssertionError('STALE_SHOULD_HOLD')
  except e.Gate as g:assert str(g)=='NO_PRIORITY_WINDOW'
  checks.append({'tag':'R49','case':'STALE_WINDOW_NEW_ID_PREINTENT_REJECT','pass':True})
  # Proposed unconditional reply after a positive critical is forbidden:
  r47=core.load(ROOT/'ledgers/R47_POSITIVE_DAMAGE_NEW_SEED103182.sqlite')[0]
  assert r47['phase']=='HOLD_R47_COUNTER_AFTER_CRIT' and r47['actors']['F']['reaction']==0
  checks.append({'tag':'R47','case':'AUTOMATIC_COUNTER_REPLY_NOT_GRANTED','pass':True})
 out={'checks':len(checks),'passed':sum(z['pass'] for z in checks),'no_original_mutations':True,'items':checks}
 (ROOT/'evidence/R47_R49_GUARD_TESTS.json').write_text(core.canonical(out)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':run()
