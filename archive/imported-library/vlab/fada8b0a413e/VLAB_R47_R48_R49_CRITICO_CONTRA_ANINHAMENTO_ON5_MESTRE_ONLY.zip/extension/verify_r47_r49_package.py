"""Verify delta ZIP members/CRC and independent auditor in fresh extraction."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,subprocess,sys

def run(p):
 p=Path(p)
 with zipfile.ZipFile(p) as z:
  err=z.testzip()
  if err:raise AssertionError('CRC_FAIL:'+err)
  manifest=json.loads(z.read('R47_R49_FILE_MANIFEST.json'))
  expected=manifest['members']
  assert sorted(z.namelist())==sorted(list(expected)+['R47_R49_FILE_MANIFEST.json']), 'MEMBERS_MISMATCH'
  for nm,sha in expected.items():
   assert hashlib.sha256(z.read(nm)).hexdigest()==sha,'HASH_MISMATCH:'+nm
  with tempfile.TemporaryDirectory() as td:
   z.extractall(td)
   r=subprocess.run([sys.executable,str(Path(td)/'extension/verify_r47_r49_independent.py')],capture_output=True,text=True,timeout=35)
   if r.returncode:raise AssertionError('AUDITOR_FAILED:'+r.stdout+r.stderr)
   summary=json.loads(r.stdout)
   assert summary['events']==15 and summary['scenes']==6 and summary['checkpoints']==6
 out={'zip_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'crc':'PASS','members':len(expected)+1,
      'member_sha256_pass':len(expected),'audit_events':summary['events'],
      'audit_scenes':summary['scenes'],'audit_checkpoints':summary['checkpoints'],'status':'PASS'}
 print(json.dumps(out,ensure_ascii=False,indent=2))
 return out

if __name__=='__main__':run(sys.argv[1])
