"""R47-R49 additive genuine R18 SQLite transactions; source-bound lab experiments.
Three cycles: positive critical while Counter was declared; nested Counter reachability;
ON5 4d6 AoO priority with two Feryn instances, actual attacks and movements.
Historical engine v0.8.1 and R18/R26 unmodified. No campaign writes.
"""
from __future__ import annotations
import copy, hashlib, json, random, sqlite3, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'fusion_stage12'))
import vlab_r18_interactive as core
import vlab_r26_master_rulings as r26
SOURCES=json.loads((ROOT/'evidence/R47_R49_MASTER_SOURCES_FROZEN.json').read_text())['sources']
SCHEMA='R47-R49-LAB-SOURCE-LOCK-v1'
class Gate(Exception):pass

def digest(x):return core.sha(x)
def draw(seed,index,label,n,faces=6):
    return {'label':label,'index':index,'n':n,'faces':faces,'dice':core.dice(seed,index,label,n,faces)}
def actors(which):
    pos={'G':[0.,0.],'F':[1.5,0.],'A':[1.5,0.],'B':[0.,1.5], 'V':[0.,0.]}
    return {aid:{'source':src,'hp':SOURCES[src]['hp'],'ca':SOURCES[src]['ca'],'rd':SOURCES[src]['rd'],'des':SOURCES[src]['des'],'reaction':1,'standard':1,'movement':1,'pa_extra':0,'position':pos[aid][:]} for aid,src in which.items()}

def initial(cycle,seed):
    which={'R47':{'G':'G','F':'F'},'R48':{'A':'F','B':'F'},'R49':{'A':'F','B':'F','V':'V'}}[cycle]
    st=core.initial('A',seed)
    st.update({'scene':cycle+'-LAB-SEED'+str(seed),'cycle':cycle,'seed':seed,'phase':'READY',
        'actors':actors(which),'issued':[],'attack_count':{'G':0,'F':0,'A':0,'B':0,'V':0},
        'lab_policy':{'schema':SCHEMA,'source_digest':digest(SOURCES),'experimental_rng':'R18_SHA256_PYTHON_MT',
                      'historical_mutations':0,'official_effects':0,'canonical_credit':0,
                      'crit_positive':'AUTO_HIT_MASTER_R41','reaction_policy':'BEFORE_ATTACK',
                      'counter_critical_conflict':'BLOCKED_NORMATIVE',
                      'counter_nesting':'BLOCKED_NORMATIVE',
                      'aoo_priority':'MASTER_R43_DES_THEN_RANK_DICE_ON5_4d6'}})
    if cycle=='R47': st['actors']['F']['position']=[1.5,0.]
    if cycle=='R48': st['actors']['A']['position']=[0.,0.];st['actors']['B']['position']=[1.5,0.]
    return st

def init(seed,cycle,tag=''):
    filename=f'{cycle}_{tag}_SEED{seed}.sqlite'
    path=ROOT/'ledgers'/filename
    core.init_db(path,'A',seed)
    st=initial(cycle,seed)
    h=digest({'scene':st['scene'],'seed':seed,'schema':SCHEMA,'source_digest':st['lab_policy']['source_digest'],'tag':tag})
    con=core.connect(path)
    try:
        con.execute('BEGIN IMMEDIATE')
        for k,v in [('scene',st['scene']),('state',core.canonical(st)),('genesis',h),('head',h)]:
            con.execute('UPDATE meta SET value=? WHERE key=?',(v,k))
        con.commit()
    except:con.rollback();raise
    finally:con.close()
    (ROOT/'evidence'/f'GENESIS_{cycle}_{tag}_{seed}.json').write_text(core.canonical(st)+'\n')
    return path

def commit(db,kind,payload,handler):
    st,head,rev=core.load(db)
    cmd='LAB-CMD-R47R49-'+digest({'scene':st['scene'],'kind':kind,'payload':payload,'head':head})[:31]
    row=core.event_commit(db,cmd,kind,payload,handler)
    core.load(db)
    return row

def checkpoint(db):
    dst=ROOT/'checkpoints'/db.name
    if dst.exists():raise Gate('DUPLICATE_CHECKPOINT')
    con=sqlite3.connect(f'file:{db}?mode=ro',uri=True);d=sqlite3.connect(dst)
    try:con.backup(d)
    finally:d.close();con.close()
    return dst

def record_r47(st,p,seq):
    if st['cycle']!='R47' or st['phase']!='READY' or seq!=1:raise Gate('NOT_WINDOW')
    G=st['actors']['G'];F=st['actors']['F']
    if G['standard']!=1 or F['reaction']!=1:raise Gate('RESOURCE_MISSING')
    # Declared BEFORE the first R18 draw. The original critically-hitting
    # enemy attack is resolved, but Counter reply is held for normative authority.
    stages=[];F['reaction']=0
    stages.append({'step':1,'name':'DECLARE_COUNTER','reaction_before':1,'reaction_after':0,'before_rng':True})
    tag='R47-G-INVESTIDA-F-1'
    crit_tape=[draw(st['seed'],1,tag+'-CRIT-'+str(k),1) for k in (1,2,3)]
    crit=[t['dice'][0] for t in crit_tape]
    hit_tape=draw(st['seed'],1,tag+'-HIT',1)
    damage_tape=draw(st['seed'],1,tag+'-DAMAGE',1)
    pos=crit[:2]==[6,6] and crit[2] in (5,6)
    if not pos:raise Gate('R47_SEED_WAS_NOT_POSITIVE')
    score=hit_tape['dice'][0]+19
    if score>=123:raise Gate('NOT_DISCRIMINATING_SCORE')
    raw=damage_tape['dice'][0]+13+6
    net=max(0,raw-F['rd'])
    before=F['hp'];F['hp']=max(0,before-net);G['standard']=0
    stages.append({'step':2,'name':'R18_DRAW_INCOMING','critical':crit,'hit_die':hit_tape['dice'][0], 'score':score,'ca':F['ca'], 'hit_reason':'POSITIVE_CRITICAL_AUTO_HIT'})
    stages.append({'step':3,'name':'APPLY_DAMAGE_AND_RD','raw':raw,'rd':F['rd'],'net':net,'hp_before':before,'hp_after':F['hp']})
    stages.append({'step':4,'name':'HOLD_COUNTER_REPLY','numeric_score_le_ca':score<=F['ca'],
        'attack_actually_hit':True,'source_text':'COUNTER_IF_ENEMY_ATTACK_DOES_NOT_EXCEED_CA',
        'conflict':'POSITIVE_CRITICAL_AUTO_HIT','reply_executed':False,'counter_priority_unresolved':True})
    st['phase']='HOLD_R47_COUNTER_AFTER_CRIT';st['issued'].append('R47-CRIT-INCOMING');
    return {'stages':stages,'tape':crit_tape+[hit_tape,damage_tape],
        'counter_reply':'BLOCKED_NORMATIVE_CRITICAL_COUNTER_INTERACTION',
        'normal_attack_roll':score,'crit_dice':crit,'critical_positive':True,'damage_raw':raw,
        'damage_net':net,'reaction_consumed':1,'goat_standard_consumed':1,'official_effects':0}

def r48_window(st,p,seq):
    if st['cycle']!='R48' or st['phase']!='READY' or seq!=1:raise Gate('DUPLICATE_R48')
    A=st['actors']['A'];B=st['actors']['B']
    if A['standard']!=1 or B['reaction']!=1:raise Gate('RESOURCES_MISSING')
    B['reaction']=0 # declared before R18 RNG
    tag='R48-FERYN-A-VS-FERYN-B'
    tapes=[draw(st['seed'],1,tag+'-CRIT-'+str(k),1) for k in (1,2,3)]
    crit=[t['dice'][0] for t in tapes]
    hit=draw(st['seed'],1,tag+'-HIT',4);tapes.append(hit)
    ordinary=sum(hit['dice'])+92
    if crit[:2]==[6,6] and crit[2] in (5,6):raise Gate('NOT_ORDINARY_NONCRITICAL_CASE')
    if crit[:2]==[1,1] and crit[2] in (1,2):raise Gate('NEG_CRIT_NOT_THIS_FIXTURE')
    if ordinary>=123:raise Gate('EXPECTED_MISS')
    A['standard']=0
    # B now makes advantage reply, 2 independent complete 4d6 rolls +2.
    replycrit=[draw(st['seed'],1,tag+'-COUNTER-CRIT-'+str(k),1) for k in (1,2,3)]
    replyc=[t['dice'][0] for t in replycrit]
    replyrolls=[draw(st['seed'],1,tag+'-COUNTER-HIT-'+str(i),4) for i in (1,2)]
    tapes+=replycrit+replyrolls
    reply=max(sum(x['dice']) for x in replyrolls)+94
    if replyc[:2]==[6,6] and replyc[2] in (5,6):raise Gate('NESTED_TEST_REPLY_CRIT_HOLD')
    if reply>=123:raise Gate('COUNTER_SHOULD_MISS_OTHER_FERYN')
    can_nested=A['reaction']==1 and reply<=A['ca']
    if not can_nested:raise Gate('EXPECTED_NESTED_TRIGGER')
    st['phase']='R48_FIRST_COUNTER_DONE_NESTED_GATE';st['issued'].append('R48-FIRST-COUNTER')
    return {'stages':[{'step':1,'name':'B_DECLARE_COUNTER_BEFORE_A_ATTACK','B_reaction_after':0},
                      {'step':2,'name':'A_ORDINARY_MISSES_B','attack_score':ordinary,'B_ca':123},
                      {'step':3,'name':'B_COUNTER_WITH_ADVANTAGE_MISSES_A','counter_score':reply,'A_ca':123,'counter_hit':False},
                      {'step':4,'name':'A_POTENTIAL_NESTED_COUNTER','A_reaction':1,'nested_reply_executed':False,'normative_order':'HOLD'}],
            'tape':tapes,'incoming_score':ordinary,'counter_score':reply,'before_hp':479,'after_hp':479,
            'B_reaction_spent':1,'A_reaction_spent':0,'nested_trigger_possible':True,
            'nested_execution':'BLOCKED_NORMATIVE_PRECEDENCE','official_effects':0}

def nested_preflight(st,who):
    if st['cycle']!='R48' or st['phase']!='R48_FIRST_COUNTER_DONE_NESTED_GATE' or who!='A':
        raise Gate('NO_NESTED_WINDOW')
    if st['actors']['A']['reaction']!=1:raise Gate('NO_SLOT')
    raise Gate('BLOCKED_NORMATIVE_NESTED_COUNTER_PRIORITY')

def r49_priority(st,p,seq):
    if st['cycle']!='R49' or st['phase']!='READY' or seq!=1:raise Gate('DUPLICATE_PRIORITY')
    if st['actors']['A']['des']!=80 or st['actors']['B']['des']!=80 or st['actors']['V']['des']!=27:raise Gate('SOURCE_MISMATCH')
    if st['actors']['A']['reaction']!=1 or st['actors']['B']['reaction']!=1:raise Gate('REACTION_UNAVAILABLE')
    # Dispute is 4d6 per contender, from ON5 rank, by Mestre R43. R26 ties reroll ONLY tied.
    tapes=[]
    def reroll(aid,ord):
        label='R49-AOO-ON5-'+aid+'-ROUND'+str(ord)
        t=draw(st['seed'],ord,label,4)
        tapes.append({'actor':aid,'round':ord,**t})
        return sum(t['dice'])
    tie=r26.tie_order([{'id':'A','total':0,'des':80},{'id':'B','total':0,'des':80}],reroll)
    first,second=tie['order']
    st['phase']='R49_PRIORITY_RESOLVED';st['priority']=[first,second];st['movement_request']={'actor':'V','from':[0.,0.],'to':[-1.5,-1.5],'voluntary':True,'completed':False}
    st['issued'].append('R49-PRIORITY')
    return {'tape':tapes,'order':[first,second], 'rule':'MASTER_R43_GREATER_DES_THEN_HIGHEST_4D6_R26_ONLY_TIED',
        'trace':tie['rerolls'],'rank':'Ouro Negro 5','rank_dice':'4d6','movement_published':False,
        'hp_changed':False,'reaction_consumed':0,'official_effects':0}

def r49_attack(st,p,seq):
    if st['phase'] not in ('R49_PRIORITY_RESOLVED','R49_FIRST_ATTACK') or st['cycle']!='R49':raise Gate('NO_PRIORITY_WINDOW')
    expected=st['priority'][0]
    if p!={'actor':expected,'action':'AOO_EQUIPPED'}:raise Gate('OUT_OF_ORDER_ATTACK')
    atk=st['actors'][expected];defender=st['actors']['V']
    if atk['reaction']!=1 or atk['hp']<=0 or defender['hp']<=0:raise Gate('KO_OR_SLOT_MISSING')
    if atk['position'] not in ([1.5,0.],[0.,1.5]):raise Gate('GEOMETRY_NOT_ELIGIBLE')
    n=st['attack_count'][expected]+1;st['attack_count'][expected]=n
    tag='R49-AOO-ON5-'+expected+'-'+str(n)
    crit=[draw(st['seed'],n,tag+'-CRIT-'+str(k),1) for k in (1,2,3)]
    c=[x['dice'][0] for x in crit]
    pos=c[:2]==[6,6] and c[2] in (5,6);neg=c[:2]==[1,1] and c[2] in (1,2)
    hitdraw=[draw(st['seed'],n,tag+'-HIT-'+str(i),4) for i in (1,2)]
    score=max(sum(t['dice']) for t in hitdraw)+94
    dmg=draw(st['seed'],n,tag+'-DAMAGE',8,8)
    raw=sum(dmg['dice'])+47+(8*8 if pos else 0)
    hit=not neg and (pos or score>defender['ca'])
    net=max(0,raw-defender['rd']) if hit else 0
    before=defender['hp'];defender['hp']=max(0,before-net);atk['reaction']=0
    st['priority'].pop(0)
    st['phase']='R49_FIRST_ATTACK' if st['priority'] else 'R49_BOTH_ATTACKS_RESOLVED'
    st['issued'].append('R49-AOO-'+expected)
    return {'actor':expected,'target':'V','source':'3f6c2b32-4ede-81ce-9c61-db8127bf0e31','tape':crit+hitdraw+[dmg],
      'critical':c,'score':score,'ca':defender['ca'],'hit_reason':'CRIT_POSITIVE_AUTO' if pos else 'CRIT_NEGATIVE_AUTO_MISS' if neg else 'NUMERIC',
      'advantage_rolls':[sum(t['dice']) for t in hitdraw],'advantage_plus':2,'damage_dice':dmg['dice'],
      'raw':raw,'rd':defender['rd'],'net':net,'hp_before':before,'hp_after':defender['hp'],
      'reaction_spent':1,'standard_spent':0,'remaining_queue':st['priority'][:],'official_effects':0}

def r49_close(st,p,seq):
    if st['cycle']!='R49' or st['phase']!='R49_BOTH_ATTACKS_RESOLVED' or st['priority'] or p!={'action':'MOVE_FINISH'}:raise Gate('NOT_READY_TO_MOVE')
    R=st['actors']['V'];
    if R['hp']<=0:raise Gate('MOVER_KO_NO_MOVEMENT')
    if R['movement']!=1:raise Gate('MOVEMENT_ALREADY_SPENT')
    R['movement']=0;R['position']=[-1.5,-1.5];st['movement_request']['completed']=True
    st['phase']='R49_AOO_WINDOW_CLOSED';st['issued'].append('R49-MOVE-FINISH')
    return {'from':[0.,0.],'to':R['position'],'movement_spent':1,'movement_after_attacks':True,
       'reaction_A':st['actors']['A']['reaction'],'reaction_B':st['actors']['B']['reaction'],'official_effects':0}

def find_r47(lo=98001,hi=99000):
    examined=0;tag='R47-G-INVESTIDA-F-1'
    for seed in range(lo,hi+1):
        examined+=1
        crit=[draw(seed,1,tag+'-CRIT-'+str(k),1)['dice'][0] for k in (1,2,3)]
        if crit[:2]==[6,6] and crit[2] in (5,6):
            return {'selection':'FIRST_VALID_POSITIVE_CRITICAL','range':[lo,hi], 'examined':examined,'seed':seed,'crit':crit,'selection_biased':True}
    raise Gate('NO_R47_CRITICAL_SEED_FOUND')

def r48_safe_seed(lo=99001,hi=99500):
    for seed in range(lo,hi+1):
        tag='R48-FERYN-A-VS-FERYN-B';a=[draw(seed,1,tag+'-CRIT-'+str(k),1)['dice'][0] for k in (1,2,3)]
        b=[draw(seed,1,tag+'-COUNTER-CRIT-'+str(k),1)['dice'][0] for k in (1,2,3)]
        if (a[:2]==[6,6] and a[2] in [5,6]) or (a[:2]==[1,1] and a[2] in [1,2]):continue
        if b[:2]==[6,6] and b[2] in [5,6]:continue
        return {'seed':seed,'examined':seed-lo+1,'range':[lo,hi],'first_ordinary_counter_candidate':True}
    raise Gate('NO_R48_SEED')

def find_r49(lo=100001,hi=102000):
    kinds={}
    for seed in range(lo,hi+1):
        a,b=[],[]
        for round_i in range(1,4):
            a.append(sum(draw(seed,round_i,'R49-AOO-ON5-A-ROUND'+str(round_i),4)['dice']))
            b.append(sum(draw(seed,round_i,'R49-AOO-ON5-B-ROUND'+str(round_i),4)['dice']))
        if a[0]!=b[0]:k='FIRST_ROLL_DECIDES'
        elif a[1]!=b[1]:k='ONE_TIE_THEN_DECIDES'
        elif a[2]!=b[2]:k='TWO_TIES_THEN_DECIDES'
        else:continue
        if k not in kinds:kinds[k]={'seed':seed,'a':a,'b':b,'examined_until_this_seed':seed-lo+1}
        if len(kinds)==3:break
    if len(kinds)<3:raise Gate('NOT_ENOUGH_TIE_CASES')
    return {'range':[lo,hi],'criteria':'FIRST_SEED_IN_ASCENDING_RANGE_FOR_EACH_KNOWN_TIE_DEPTH',
            'selection_biased':True,'cases':kinds,'seeds_examined':max(v['examined_until_this_seed'] for v in kinds.values())}

def run():
    pre={'R47':{'range':[98001,99000],'goal':'positive critical on low incoming score; no winner-rate inference'},
         'R48':{'range':[99001,99500],'goal':'first legal non-critical counter, nested candidate detection'},
         'R49':{'range':[100001,102000],'goal':'three earliest ON5 rank-4d6 tie-depth classes'}}
    (ROOT/'evidence/R47_R49_PREREGISTRATION.json').write_text(core.canonical(pre)+'\n')
    selections={'R47':find_r47(),'R48':r48_safe_seed(),'R49':find_r49()}
    (ROOT/'evidence/R47_R49_SELECTIONS.json').write_text(core.canonical(selections)+'\n')
    summary=[]
    seed=selections['R47']['seed'];db=init(seed,'R47','COUNTER_CRIT')
    row=commit(db,'R47_COUNTER_INCOMING_POSITIVE',{'actor':'G','defender':'F','declared_before_roll':True},record_r47)
    checkpoint(db);summary.append({'cycle':'R47','seed':seed,'rows':[row],'path':str(db)})
    seed=selections['R48']['seed'];db=init(seed,'R48','NESTED_COUNTER')
    row=commit(db,'R48_FIRST_COUNTER',{'attacker':'A','defender':'B','declared_before_roll':True},r48_window)
    st,head,rev=core.load(db)
    before=digest(st)
    try:nested_preflight(st,'A');raise RuntimeError('NESTED_SHOULD_BLOCK')
    except Gate as e: denial=str(e)
    after=digest(core.load(db)[0]);assert before==after
    checkpoint(db);summary.append({'cycle':'R48','seed':seed,'rows':[row],'nested_denied':denial,'before_after_same':before==after,'path':str(db)})
    for k,v in selections['R49']['cases'].items():
        seed=v['seed'];db=init(seed,'R49',k)
        rows=[commit(db,'R49_AOO_PRIORITY',{'action':'PRIORITY'},r49_priority)]
        for aid in core.load(db)[0]['priority'][:]:
            rows.append(commit(db,'R49_AOO_ATTACK',{'actor':aid,'action':'AOO_EQUIPPED'},r49_attack))
        rows.append(commit(db,'R49_MOVEMENT_FINISHED',{'action':'MOVE_FINISH'},r49_close))
        checkpoint(db);summary.append({'cycle':'R49','tag':k,'seed':seed,'rows':rows,'path':str(db)})
    clean=[]
    for x in summary:
        st,head,rev=core.load(x['path'])
        clean.append({'cycle':x['cycle'],'seed':x['seed'],'tag':x.get('tag'),'events':rev,'head':head,
            'status':st['phase'],'hp':{k:v['hp'] for k,v in st['actors'].items()},
            'reaction':{k:v['reaction'] for k,v in st['actors'].items()},
            'nested_denied':x.get('nested_denied'),'sources':{k:v['source'] for k,v in st['actors'].items()}})
    (ROOT/'evidence/R47_R49_RUN_RECEIPT.json').write_text(core.canonical(clean)+'\n')
    print(json.dumps({'selections':selections,'scenes':clean},indent=2,ensure_ascii=False))

if __name__=='__main__':run()
