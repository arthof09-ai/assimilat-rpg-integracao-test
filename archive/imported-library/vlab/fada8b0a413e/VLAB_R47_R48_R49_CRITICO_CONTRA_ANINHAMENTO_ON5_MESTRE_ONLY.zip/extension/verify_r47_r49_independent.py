"""Independent cold auditor for new R47--R49 ledger/cp events.
STD-LIB ONLY. Does not import executor or historical combat engine. Checks
SOURCE-domain, order, causal stages, RNG tape, HP/slot/movement, replay snapshots
and SQLite SHA journal. Mechanically invalid but structurally rehashed events fail.
"""
from __future__ import annotations
import copy, hashlib,json,random,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCES=json.loads((ROOT/'evidence/R47_R49_MASTER_SOURCES_FROZEN.json').read_text())['sources']
VER='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
class Invalid(Exception):pass

def enc(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def h(x):return hashlib.sha256(enc(x).encode()).hexdigest()
def check(ok,code):
 if not ok:raise Invalid(code)
def d(seed,idx,label,n,faces=6):
 token=f'{seed}|{idx}|{label}|{n}d{faces}|{VER}'
 r=random.Random(int.from_bytes(hashlib.sha256(token.encode()).digest(),'big'))
 return [r.randint(1,faces) for _ in range(n)]
def tape_check(t,seed):
 check(type(t)==list,'TAPE_NOT_LIST')
 for i,e in enumerate(t):
  check(e['dice']==d(seed,e['index'],e['label'],e['n'],e['faces']),f'RNG_FALSE_{i}')
  check(all(1<=v<=e['faces'] for v in e['dice']),'DIE_OUT_OF_RANGE')

def replay47(st,row):
 detail=row['detail'];seed=st['seed']
 check(row['kind']=='R47_COUNTER_INCOMING_POSITIVE','R47_WRONG_KIND')
 tape_check(detail['tape'],seed)
 check(len(detail['tape'])==5,'R47_TAPE_LENGTH')
 check(detail['tape'][0]['label']=='R47-G-INVESTIDA-F-1-CRIT-1','R47_CRIT_PROVENANCE')
 crit=[t['dice'][0] for t in detail['tape'][:3]]
 check(crit[:2]==[6,6] and crit[2] in (5,6),'R47_NOT_POSITIVE_CRIT')
 hitdie=detail['tape'][3]['dice'][0];dmg=detail['tape'][4]['dice'][0]
 score=hitdie+19;raw=dmg+13+6
 check(score<=SOURCES['F']['ca'],'R47_NOT_BELOW_CA')
 net=max(0,raw-SOURCES['F']['rd']);old=st['actors']['F']['hp']
 steps=detail['stages'];check([x['name'] for x in steps]==['DECLARE_COUNTER','R18_DRAW_INCOMING','APPLY_DAMAGE_AND_RD','HOLD_COUNTER_REPLY'],'R47_CAUSAL_SEQUENCE')
 check(steps[0]['reaction_before']==1 and steps[0]['reaction_after']==0 and steps[0]['before_rng'],'R47_DECLARE_AFTER_RNG')
 check(steps[1]['score']==score and steps[1]['hit_reason']=='POSITIVE_CRITICAL_AUTO_HIT','R47_AUTOHIT_LOST')
 check(steps[2]['raw']==raw and steps[2]['rd']==22 and steps[2]['net']==net and steps[2]['hp_before']==old and steps[2]['hp_after']==max(0,old-net),'R47_BAD_DAMAGE')
 check(steps[3]['counter_priority_unresolved'] is True and steps[3]['reply_executed'] is False and steps[3]['attack_actually_hit'] is True,'R47_UNAUTHORIZED_COUNTER')
 check(detail['counter_reply']=='BLOCKED_NORMATIVE_CRITICAL_COUNTER_INTERACTION','R47_GATE_BYPASS')
 check(detail['reaction_consumed']==1 and detail['goat_standard_consumed']==1,'R47_RESOURCE_COUNT')
 check(detail['normal_attack_roll']==score and detail['crit_dice']==crit and detail['critical_positive'] is True and detail['damage_raw']==raw and detail['damage_net']==net,'R47_MAIN_RECEIPT_NUMBERS')
 st['actors']['F']['reaction']=0;st['actors']['G']['standard']=0;st['actors']['F']['hp']=max(0,old-net)
 st['phase']='HOLD_R47_COUNTER_AFTER_CRIT';st['issued'].append('R47-CRIT-INCOMING')
 return {'r47_positive':1,'r47_net':net}

def replay48(st,row):
 detail=row['detail'];seed=st['seed'];check(row['kind']=='R48_FIRST_COUNTER','R48_KIND')
 tape_check(detail['tape'],seed)
 check(len(detail['tape'])==9,'R48_TAPE_LENGTH')
 check([x['name'] for x in detail['stages']]==['B_DECLARE_COUNTER_BEFORE_A_ATTACK','A_ORDINARY_MISSES_B','B_COUNTER_WITH_ADVANTAGE_MISSES_A','A_POTENTIAL_NESTED_COUNTER'],'R48_CAUSAL')
 crit=[x['dice'][0] for x in detail['tape'][:3]]
 check(not (crit[:2]==[6,6] and crit[2] in [5,6]) and not(crit[:2]==[1,1] and crit[2] in [1,2]),'R48_BAD_INCOMING_CRIT')
 score=sum(detail['tape'][3]['dice'])+92
 check(detail['tape'][3]['label'].endswith('-HIT'),'R48_HIT_LABEL')
 replycrit=[x['dice'][0] for x in detail['tape'][4:7]]
 check(not(replycrit[:2]==[6,6] and replycrit[2] in [5,6]),'R48_REPLY_CRIT_INVALID_FIXTURE')
 reply=max(sum(x['dice']) for x in detail['tape'][7:])+94
 check(detail['incoming_score']==score and score<123,'R48_INCOMING_CA')
 check(detail['counter_score']==reply and reply<123,'R48_REPLY_CA')
 check(detail['stages'][0]['B_reaction_after']==0 and detail['B_reaction_spent']==1 and detail['A_reaction_spent']==0,'R48_REACTION')
 check(detail['nested_trigger_possible'] is True and detail['nested_execution']=='BLOCKED_NORMATIVE_PRECEDENCE','R48_NESTING_RULE')
 check(detail['before_hp']==479 and detail['after_hp']==479,'R48_HP_BAD')
 st['actors']['B']['reaction']=0;st['actors']['A']['standard']=0
 st['phase']='R48_FIRST_COUNTER_DONE_NESTED_GATE';st['issued'].append('R48-FIRST-COUNTER')
 return {'r48_first_counter':1,'nested_candidates_blocked':1}

def replay49(st,row):
 detail=row['detail'];seed=st['seed'];kind=row['kind']
 if kind=='R49_AOO_PRIORITY':
  check(st['phase']=='READY' and detail['rank_dice']=='4d6','R49_BAD_PRIORITY_PHASE_OR_RANK')
  tapes=detail['tape'];check(len(tapes)%2==0,'R49_DICE_PAIR_COUNT')
  check(2<=len(tapes)<=256,'R49_TIE_MAX')
  for i,t in enumerate(tapes):
   who='A' if i%2==0 else 'B';rnd=i//2+1
   check(t['actor']==who and t['round']==rnd and t['n']==4 and t['faces']==6,'R49_RANK_DICE_TYPE')
   check(t['label']==f'R49-AOO-ON5-{who}-ROUND{rnd}','R49_RNG_LABEL')
   check(t['dice']==d(seed,rnd,t['label'],4,6),'R49_RNG_FALSE')
  for i in range(0,len(tapes)-2,2):check(sum(tapes[i]['dice'])==sum(tapes[i+1]['dice']),'R49_REROLL_NOT_REQUIRED')
  a=sum(tapes[-2]['dice']);b=sum(tapes[-1]['dice'])
  check(a!=b,'R49_UNRESOLVED_TIE')
  priority=['A','B'] if a>b else ['B','A']
  check(detail['order']==priority and detail['reaction_consumed']==0 and detail['movement_published'] is False,'R49_PRIORITY_CORRUPTED')
  check(detail['rank']=='Ouro Negro 5','R49_SOURCE_RANK')
  st['phase']='R49_PRIORITY_RESOLVED';st['priority']=priority[:];st['movement_request']={'actor':'V','from':[0.,0.],'to':[-1.5,-1.5],'voluntary':True,'completed':False};st['issued'].append('R49-PRIORITY')
  return {'on5_priority_events':1,'priority_draws':len(tapes),'repeated_tie':(len(tapes)-2)//2}
 if kind=='R49_AOO_ATTACK':
  check(st['phase'] in ('R49_PRIORITY_RESOLVED','R49_FIRST_ATTACK'),'R49_BAD_PHASE')
  who=st['priority'][0];check(detail['actor']==who and detail['target']=='V','R49_WRONG_ORDER')
  check(st['actors'][who]['reaction']==1 and st['actors']['V']['hp']>0,'R49_SLOT_OR_DEAD')
  tape_check(detail['tape'],seed)
  check(len(detail['tape'])==6,'R49_WRONG_TAPE')
  n=st['attack_count'][who]+1;tag=f'R49-AOO-ON5-{who}-{n}'
  for k in (1,2,3):check(detail['tape'][k-1]['label']==tag+'-CRIT-'+str(k),'R49_CRIT_ORDER')
  for k in (1,2):check(detail['tape'][2+k]['label']==tag+'-HIT-'+str(k) and detail['tape'][2+k]['n']==4,'R49_ATTACK_ROLL')
  check(detail['tape'][5]['label']==tag+'-DAMAGE' and detail['tape'][5]['n']==8 and detail['tape'][5]['faces']==8,'R49_DAMAGE_ROLL')
  crit=[t['dice'][0] for t in detail['tape'][:3]];pos=crit[:2]==[6,6] and crit[2] in (5,6);neg=crit[:2]==[1,1] and crit[2] in (1,2)
  score=max(sum(t['dice']) for t in detail['tape'][3:5])+94
  check(detail['advantage_rolls']==[sum(t['dice']) for t in detail['tape'][3:5]] and detail['advantage_plus']==2,'R49_ADVANTAGE_CORRUPTED')
  raw=sum(detail['tape'][5]['dice'])+47+(64 if pos else 0)
  hit=not neg and (pos or score>83);net=max(0,raw-35) if hit else 0
  old=st['actors']['V']['hp'];after=max(0,old-net)
  check(detail['score']==score and detail['ca']==83,'R49_HIT_SCORE')
  check(detail['raw']==raw and detail['rd']==35 and detail['net']==net and detail['hp_before']==old and detail['hp_after']==after,'R49_DAMAGE_RD_HP')
  check(detail['critical']==crit and detail['damage_dice']==detail['tape'][5]['dice'],'R49_CRITICAL_PROVENANCE')
  check(detail['reaction_spent']==1 and detail['standard_spent']==0,'R49_ACTION_BUDGET')
  st['actors']['V']['hp']=after;st['actors'][who]['reaction']=0;st['attack_count'][who]+=1;st['priority'].pop(0)
  st['phase']='R49_FIRST_ATTACK' if st['priority'] else 'R49_BOTH_ATTACKS_RESOLVED';st['issued'].append('R49-AOO-'+who)
  check(detail['remaining_queue']==st['priority'],'R49_REMAINING_ORDER')
  return {'on5_source_aoo_attacks':1,'on5_damage_net':net}
 if kind=='R49_MOVEMENT_FINISHED':
  check(st['phase']=='R49_BOTH_ATTACKS_RESOLVED' and st['priority']==[] and st['actors']['V']['hp']>0,'R49_MOVEMENT_EARLY')
  check(st['actors']['V']['movement']==1,'R49_MOVEMENT_DUPLICATE')
  st['actors']['V']['movement']=0;st['actors']['V']['position']=[-1.5,-1.5];st['movement_request']['completed']=True;st['phase']='R49_AOO_WINDOW_CLOSED';st['issued'].append('R49-MOVE-FINISH')
  check(detail['movement_spent']==1 and detail['reaction_A']==0 and detail['reaction_B']==0 and detail['to']==[-1.5,-1.5] and detail['movement_after_attacks'],'R49_BAD_CLOSE')
  return {'on5_movement_complete':1}
 raise Invalid('UNKNOWN_R49_KIND')

def db_read(path):
 c=sqlite3.connect(f'file:{path}?mode=ro',uri=True)
 try:
  check(c.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLITE_INTEGRITY')
  meta=dict(c.execute('SELECT key,value FROM meta'))
  ev=c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
  count=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
  return meta,ev,count
 finally:c.close()

def verify_one(db):
 meta,ev,pending=db_read(db);check(pending==0,'PENDING_IN_COMPLETED_SCENE')
 check(int(meta['revision'])==len(ev),'REVISION_COUNT')
 filename=db.name;cycle=filename[:3];seed=int(meta['scene'].split('SEED')[1]);tag=filename.split('_SEED')[0][4:]
 expected_genesis=ROOT/'evidence'/f'GENESIS_{cycle}_{tag}_{seed}.json'
 check(expected_genesis.exists(),'MISSING_GENESIS')
 st=json.loads(expected_genesis.read_text());check(st['seed']==seed and st['cycle']==cycle and meta['scene']==st['scene'],'GENESIS_SCENE')
 check(st['lab_policy']['source_digest']==h(SOURCES),'SOURCE_FINGERPRINT')
 prev=meta['genesis'];metrics={};check(meta['mode']=='EXPERIMENTAL_LAB_ONLY','MODE')
 for seq,cmd_id,prev_sha,js,row_sha,before_sha,after_sha in ev:
  row=json.loads(js)
  check(seq==row['seq'] and seq>0 and cmd_id==row['cmd_id'] and cmd_id.startswith('LAB-CMD-R47R49-'),'COMMAND_ID')
  check(prev==prev_sha==row['prev'] and row_sha==h(row),'JOURNAL_CHAIN')
  check(before_sha==row['before_sha']==h(st),'JOURNAL_BEFORE')
  check(row['synthetic'] is True and row['official_effects']==0,'OFFICIAL_EFFECT_FORBIDDEN')
  values=replay47(st,row) if cycle=='R47' else replay48(st,row) if cycle=='R48' else replay49(st,row)
  for k,v in values.items():metrics[k]=metrics.get(k,0)+v
  check(after_sha==row['after_sha']==h(st),'CAUSAL_AFTER_STATE')
  prev=row_sha
 check(prev==meta['head'] and meta['state']==enc(st),'FINAL_HEAD_SNAPSHOT')
 cp=ROOT/'checkpoints'/filename;check(cp.exists(),'CHECKPOINT_MISSING')
 cmeta,cev,cpending=db_read(cp)
 check(cmeta==meta and cev==ev and cpending==0,'BACKUP_NOT_IDENTICAL_LOGICAL_STATE')
 return {'scene':filename,'cycle':cycle,'seed':seed,'rev':len(ev),'head':prev,'result':st['phase'],
         'HP':{k:v['hp'] for k,v in st['actors'].items()},'metrics':metrics}

def audit_all(save=True):
 objs=sorted((ROOT/'ledgers').glob('*.sqlite'))
 check(len(objs)==6,'SIX_SCENES_REQUIRED')
 items=[verify_one(x) for x in objs]
 sums={}
 for ob in items:
  for k,v in ob['metrics'].items():sums[k]=sums.get(k,0)+v
 out={'all_ok':True,'scenes':len(items),'events':sum(z['rev'] for z in items),'checkpoints':len(items),
      'metrics':sums,'items':items,'auditor_independent':True,'executor_imported':False,
      'historical_modules_imported':False,'canonical_writes':0}
 if save:(ROOT/'evidence/R47_R49_COLD_AUDIT.json').write_text(enc(out)+'\n')
 return out

if __name__=='__main__':
 print(json.dumps(audit_all(),indent=2,ensure_ascii=False))
