"""Additive disambiguation: R47 first native critical was fully mitigated by RD22.
A new directed, source-bounded lab scene exercises positive NET damage while
preserving that first sample and all earlier ledgers unchanged.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'extension'))
import run_r47_r49 as e

if __name__=='__main__':
    prereg={'reason':'R47 first directed critical had net0 after real Feryn RD22',
            'range':[103001,104000], 'criterion':'first R18 positive critical AND 1d6 damage >=4 so net>=1',
            'selection_biased':True,'source':'same documented Goat/Feryn, independent new ledger',
            'time_of_selection':'before any R47B combat execution'}
    (ROOT/'evidence/R47B_POSITIVE_DAMAGE_PREREG.json').write_text(e.core.canonical(prereg)+'\n')
    seed=None;tests=0
    for n in range(*[prereg['range'][0],prereg['range'][1]+1]):
        tests+=1;tag='R47-G-INVESTIDA-F-1'
        crit=[e.draw(n,1,tag+'-CRIT-'+str(k),1)['dice'][0] for k in (1,2,3)]
        damage=e.draw(n,1,tag+'-DAMAGE',1)['dice'][0]
        if crit[:2]==[6,6] and crit[2] in (5,6) and damage>=4:
            seed=n;break
    if seed is None:raise e.Gate('NO_ELIGIBLE_SEED')
    (ROOT/'evidence/R47B_POSITIVE_DAMAGE_SELECTION.json').write_text(e.core.canonical({'seed':seed,'examined':tests,'crit':crit,'damage_die':damage})+'\n')
    db=e.init(seed,'R47','POSITIVE_DAMAGE_NEW')
    event=e.commit(db,'R47_COUNTER_INCOMING_POSITIVE',{'actor':'G','defender':'F','declared_before_roll':True},e.record_r47)
    e.checkpoint(db)
    st,head,rev=e.core.load(db)
    assert st['actors']['F']['hp']<479 and st['actors']['F']['reaction']==0
    out={'cycle':'R47B','seed':seed,'events':rev,'head':head,'positive_damage':479-st['actors']['F']['hp'],
         'F_hp':st['actors']['F']['hp'],'F_reaction':st['actors']['F']['reaction'],'crit':crit,'damage_die':damage,
         'reply':'BLOCKED_NORMATIVE','seeds_examined':tests}
    (ROOT/'evidence/R47B_NEW_RECEIPT.json').write_text(e.core.canonical(out)+'\n')
    print(json.dumps(out,ensure_ascii=False,indent=2))
