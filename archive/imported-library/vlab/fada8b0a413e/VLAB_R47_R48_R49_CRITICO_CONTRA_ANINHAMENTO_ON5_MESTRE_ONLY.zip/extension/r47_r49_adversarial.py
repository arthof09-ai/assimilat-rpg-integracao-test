"""Rechain malicious copies only; historical R18 structural read must accept,
independent mechanical/causal auditor must reject. No original file touched.
"""
import copy,hashlib,json,sqlite3,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'fusion_stage12'))
sys.path.insert(0,str(ROOT/'extension'))
import vlab_r18_interactive as j
import verify_r47_r49_independent as a

def rechain(inp,dst,mutator,position):
 source=sqlite3.connect(f'file:{inp}?mode=ro',uri=True);dest=sqlite3.connect(dst)
 try:source.backup(dest)
 finally:source.close()
 dest.execute('BEGIN IMMEDIATE')
 meta=dict(dest.execute('SELECT key,value FROM meta'))
 rows=dest.execute('SELECT seq,cmd_id,row_json FROM events ORDER BY seq').fetchall()
 prev=meta['genesis']
 for n,cid,raw in rows:
  row=json.loads(raw)
  if n==position:mutator(row)
  row['prev']=prev
  rh=j.sha(row)
  dest.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(prev,j.canonical(row),rh,n))
  prev=rh
 dest.execute("UPDATE meta SET value=? WHERE key='head'",(prev,))
 dest.commit();dest.close()

CASES=[
 ('R47_CRIT_REPLY_UNAUTHORIZED','R47_POSITIVE_DAMAGE_NEW_SEED103182.sqlite',1,lambda r:r['detail']['stages'][3].__setitem__('reply_executed',True)),
 ('R47_AUTOHIT_HIDDEN','R47_COUNTER_CRIT_SEED98002.sqlite',1,lambda r:r['detail']['stages'][1].__setitem__('hit_reason','NORMAL_NUMERIC_MISS')),
 ('R47_DAMAGE_BAD','R47_POSITIVE_DAMAGE_NEW_SEED103182.sqlite',1,lambda r:r['detail']['stages'][2].__setitem__('net',0)),
 ('R47_REACTION_DOUBLE','R47_POSITIVE_DAMAGE_NEW_SEED103182.sqlite',1,lambda r:r['detail']['reaction_consumed'].__class__ if False else r['detail'].__setitem__('reaction_consumed',2)),
 ('R48_DECLARATION_LATE','R48_NESTED_COUNTER_SEED99001.sqlite',1,lambda r:r['detail']['stages'][0].__setitem__('B_reaction_after',1)),
 ('R48_NESTED_PRETEND_EXECUTION','R48_NESTED_COUNTER_SEED99001.sqlite',1,lambda r:r['detail'].__setitem__('nested_execution','EXECUTED_WHILE_UNAUTHORIZED')),
 ('R48_REPLY_SCORE_BOGUS','R48_NESTED_COUNTER_SEED99001.sqlite',1,lambda r:r['detail'].__setitem__('counter_score',122)),
 ('R49_PRIORITY_INVERSION','R49_FIRST_ROLL_DECIDES_SEED100001.sqlite',1,lambda r:r['detail'].__setitem__('order',list(reversed(r['detail']['order'])))),
 ('R49_WRONG_RANK_1D6','R49_ONE_TIE_THEN_DECIDES_SEED100013.sqlite',1,lambda r:r['detail'].__setitem__('rank_dice','1d6')),
 ('R49_IMPOSSIBLE_D6_7','R49_TWO_TIES_THEN_DECIDES_SEED100323.sqlite',1,lambda r:r['detail']['tape'][0]['dice'].__setitem__(0,7)),
 ('R49_SCORE_TAMPER','R49_FIRST_ROLL_DECIDES_SEED100001.sqlite',2,lambda r:r['detail'].__setitem__('score',r['detail']['score']+1)),
 ('R49_RD_TAMPER','R49_ONE_TIE_THEN_DECIDES_SEED100013.sqlite',2,lambda r:r['detail'].__setitem__('rd',0)),
 ('R49_DAMAGE_NET_TAMPER','R49_TWO_TIES_THEN_DECIDES_SEED100323.sqlite',3,lambda r:r['detail'].__setitem__('net',r['detail']['net']+1)),
 ('R49_SLOT_DOUBLE','R49_FIRST_ROLL_DECIDES_SEED100001.sqlite',3,lambda r:r['detail'].__setitem__('reaction_spent',2)),
 ('R49_HP_TAMPER','R49_ONE_TIE_THEN_DECIDES_SEED100013.sqlite',2,lambda r:r['detail'].__setitem__('hp_after',1)),
 ('R49_PREMATURE_MOVEMENT','R49_TWO_TIES_THEN_DECIDES_SEED100323.sqlite',4,lambda r:r['detail'].__setitem__('movement_after_attacks',False)),
 ('R49_MOVEMENT_RESOURCE_FAKE','R49_FIRST_ROLL_DECIDES_SEED100001.sqlite',4,lambda r:r['detail'].__setitem__('reaction_B',1)),
]

def run():
 report=[]
 with tempfile.TemporaryDirectory() as td:
  for label,name,pos,mutator in CASES:
   o=ROOT/'ledgers'/name;dest=Path(td)/name
   rechain(o,dest,mutator,pos)
   try:
    j.load(dest);structural=True
   except Exception as e:structural=False;why=str(e)
   try:
    a.verify_one(dest);rejected=False;reason='MISSED_INVALID_MECHANICS'
   except Exception as e:rejected=True;reason=type(e).__name__+':'+str(e)
   report.append({'case':label,'original':name,'structural_accept':structural,'mechanical_reject':rejected,'reason':reason})
  assert all(x['structural_accept'] and x['mechanical_reject'] for x in report),report
 out={'cases':len(report),'structural_rechain_accepted':sum(x['structural_accept'] for x in report),
      'independent_mechanical_rejected':sum(x['mechanical_reject'] for x in report),
      'original_writes':0,'report':report}
 (ROOT/'evidence/R47_R49_RECHAINED_ADVERSARIAL.json').write_text(j.canonical(out)+'\n')
 print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__':run()
