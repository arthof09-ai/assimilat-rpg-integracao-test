"""Read-only provenance + delta matrix + report + compact manifest ZIP.
Does not import engine and never rewrites completed SQLite databases.
"""
import zipfile,pathlib,json,hashlib,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=pathlib.Path('/mnt/data')
CAN=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
SHA=lambda b:hashlib.sha256(b).hexdigest()
R27=BASE/'vlab_r42/input/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip'
with zipfile.ZipFile(R27) as z:
 raw=z.read('reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json')
 matrix=json.loads(raw)
assert matrix['denominator']==17 and len(matrix['rows'])==17
updates={
 'REACTION_TRIGGER_AND_SINGLE_USE':{'prior':'R46 PARTIAL','new':'R47 predeclared Counter consumed in hit-by-automatic-crit; R48 first counter, possible nested trigger blocked; R49 six ON5 AoOs, two slots consumed per scene','result':'PASS scoped reaction slots/windows; BLOCKED-NORMATIVE counter/positive-critical and nested priority','remaining':'MULTI_TRIGGER_INTERRUPTS_AND_NORMATIVE_PRECEDENCE + external review/NAC-PASS'},
 'TURN_SCHEDULER_EVENT_SOURCING':{'prior':'R46 PARTIAL','new':'R49 local ordered AoO interruption with 4d6 tie and movement only after both attacks; R48 staged causal response','result':'PASS scoped local window; NOT TESTED complete post-interruption global scheduler 3+ turns','remaining':'CANON_INITIATIVE_TIE_INTERRUPTION_AND_SOURCE_COMPLETE_EVENTS + review/NAC-PASS'},
 'RNG_REPLAY_STATISTICS':{'prior':'R46 PARTIAL','new':'R47 two targeted native R18 critical streams; R49 12 complete 4d6 priority rolls, with 0/1/2 ties; replay independent','result':'PASS deterministic experimental R18; BLOCKED-SOURCE canonical dice; directed seeds not holdout','remaining':'CANONICAL_DICE_SOURCE_AND_STATISTICAL_HOLDOUT + review/NAC-PASS'},
 'ACTION_CATALOG_AIN01':{'prior':'R46 PARTIAL','new':'R49 source-equipped normal AoO Feryn x2 with weapon bonus and advantage; R47 goat Investida scoped','result':'PASS incremental admitted actions, NOT full source loadout','remaining':'REAL_SOURCE_LOADOUT_AND_FULL_EFFECT_COVERAGE + review/NAC-PASS'},
 'GENERAL_SPECIFIC_RD':{'prior':'R46 PARTIAL','new':'R47 Feryn RD22 fully/partially absorbs positive crit; R49 Varok RD35 on six normal source attacks','result':'PASS numeric general RD only; NOT TESTED specific stacking/bypass','remaining':'RD_MULTI_TAG_STACKING_BYPASS_NORMATIVE_RULING + review/NAC-PASS'},
 'AUTHORITATIVE_RULES_AND_ADAPTERS':{'prior':'R46 PARTIAL','new':'R47 reveals normative ambiguity when numeric score<=CA but positive crit auto-hits; source mismatch correctly held','result':'PASS source-conservative rejection, BLOCKED-NORMATIVE unresolved interaction','remaining':'AUTHORITATIVE_SOURCE_FREEZE_AND_CONFLICT_RESOLUTION + review/NAC-PASS'},
 'ITEM_EQUIPMENT_AND_ENHANCEMENTS':{'prior':'R46 PARTIAL','new':'R49 repeats published equipped Feryn par weapon 8d8+47, accuracy +10; no positive PA consumption','result':'PASS equipped weapon subcase, NOT TESTED charges/other equipment','remaining':'CURRENT_EQUIPMENT_CHARGE_SNAPSHOTS + review/NAC-PASS'},
}
all_ids=[r['contract_id'] for r in matrix['rows']]
assert set(updates).issubset(all_ids)
rows=[]
for r in matrix['rows']:
 id=r['contract_id'];d=updates.get(id)
 rows.append({'contract_id':id,'original_acceptance':r['original_acceptance_still_required'],
  'R47_R49':d if d else {'result':'NOT_TESTED_IN_THIS_DELTA','terminal':'UNCHANGED'},
  'technically_complete':False,'terminal_certified':False,'production_release':False})
delta={'matrix_origin':'R27 ZIP original path reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json',
       'original_r18_sha256':SHA(raw),'denominator':17,'rows':rows,'terminal_pass':0,
       'preserves_original_requirement':True,'world_writes':0,
       'new_full_fights':0,'new_windows':6,'new_events':15,
       'false_positive_guards':'R47 counter reply and R48 nested reply blocked normative'}
(ROOT/'evidence/R47_R49_R18_CONTRACT_DELTA.json').write_text(CAN(delta)+'\n')
old={'R41':BASE/'VLAB_R41_CRITICO_AUTOMATICO_RNG_REACOES_MESTRE_ONLY.zip',
 'R43':BASE/'VLAB_R43_PRIORIDADE_AOO_MESTRE_ONLY.zip',
 'R44_R46':BASE/'VLAB_R44_R45B_R46_TRES_CICLOS_AOO_CONTRA_E_RECUPERACAO_MESTRE_ONLY.zip',
 'R27':R27}
history={k:{'path':str(v),'sha256':SHA(v.read_bytes()),'bytes':v.stat().st_size} for k,v in old.items()}
# Check against known historic checkpoint reported in previous operations.
assert history['R41']['sha256']=='105615717ddb62b84e51f2232bde067133e3c576a14340dac3b5427e0078306b'
assert history['R43']['sha256']=='26651a014d9af14caab4a600a901d7cc4852234fa512e042e1cef8798613b0c9'
assert history['R44_R46']['sha256']=='65d1a4a24f656e5b2d0a0601b634b43e69da8fc90019633d68af981912e8a159'
assert history['R27']['sha256']=='d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1'
modules={}
for name in ('vlab_r18_interactive.py','vlab_r26_master_rulings.py'):
 original=zipfile.ZipFile(R27).read('fusion_stage12/'+name)
 local=(ROOT/'fusion_stage12'/name).read_bytes()
 assert original==local
 modules[name]=SHA(original)
provenance={'historical_zip_hashes':history,'immutable_historical_engine':modules,
 'master_side_notion_original_ids':{'combat':'3ebc2b32-4ede-81f1-be4b-e8804ac113c0','goat':'391c2b32-4ede-8252-b0cc-810423cdbfa6',
 'Feryn':'3f6c2b32-4ede-81ce-9c61-db8127bf0e31','Varok':'3f6c2b32-4ede-81f4-9ea9-efbe1a811091'},
 'historical_sqlite_modified':0,'party_writes':0,'game_writes':0}
(ROOT/'evidence/R47_R49_PROVENANCE_IMMUTABILITY.json').write_text(CAN(provenance)+'\n')

cold=json.loads((ROOT/'evidence/R47_R49_COLD_AUDIT.json').read_text())
advers=json.loads((ROOT/'evidence/R47_R49_RECHAINED_ADVERSARIAL.json').read_text())
guards=json.loads((ROOT/'evidence/R47_R49_GUARD_TESTS.json').read_text())
sel=json.loads((ROOT/'evidence/R47_R49_SELECTIONS.json').read_text())
assert (cold['scenes'],cold['events'],advers['independent_mechanical_rejected'],guards['passed'])==(6,15,17,6)
rec={x['seed']:x for x in cold['items']}
report=f'''# PSV — CM-000006 / VLAB R47–R49 + R47B — três ciclos autônomos

**Data:** 16/10/2026. **Ambiente:** MESTRE-SIDE. **Operação persistente:** OP-VLAB-FUSION-SANDBOX-01, ID Notion `3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2`. **Autoridade:** ordem de Mestre para executar pelo menos três ciclos sem contato intermediário. **Resultado de engenharia:** três ciclos distintos executados mais ensaio complementar R47B, seis cenas novas, 15 eventos R18 SQLite, seis backups/checkpoints, 17/17 mutações adversariais rejeitadas e 6/6 guardas/idempotências PASS; **nenhum combate integral novo**.

## 1. Baseline ANTES e integridade

- Último checkpoint R46 de janelas AoO/Contra com fontes equipadas, prioridade expressa R43: mais DES, empate no dado maior e só empatados rerrolam pelo R26. R45 inicial causou ordem de declaração incorreta; R45B é prova corrigida, a primeira permanece quarentenada. Banco pending R46 e históricos R01–R46 nunca foram executados nem alterados nesta rodada.
- 17 contratos R18 originais (SHA `{SHA(raw)}`), sem mudança no denominador nem nas exigências. Estado terminal 0/17; células canônicas 0/1.875; 18 combates completos históricos de sandbox até R40, outras cenas condicionais R41/R42 e sondas/censuras historicamente separadas. Campanha 0.
- Fontes verificadas Notion Mestre: Sistema de Combate `3ebc...`, Cabra `391c...`, Feryn `3f6c...1e31`, Varok `3f6c...1091`. Equipamentos documentados ativos: Feryn ON5 Luta 4d6+82, ataque equipado 4d6+92, dano 8d8+47, DES80, CA123, RD22, HP479, Reação1; Varok ON5 CA83, RD35, HP734. Cabra Bronze1 Investida individual 1d6+FOR13, bônus de Luta +6 apenas nessa habilidade, não ataque normal.
- R18 e R26 extraídos da R27 histórica autenticada, **mesmo SHA byte a byte**. Extensão R47–R49 separada; não se declara que R49 delega cada golpe diretamente ao resolvedor v0.8.1: o adaptador source-bound calcula ações de equipamento com RNG genuinamente gerado pelo R18 e persiste pelo `event_commit` histórico. Um oráculo separado recompõe sua legalidade sem importar esses módulos.

## 2. Ciclo R47 — positivo automático recebido sob Contra-atacar já declarado

**Conflito literal:** Sistema de Combate: o Contra-atacar pode ser anunciado antes do golpe e produz resposta com Vantagem se o ataque inimigo “não superar sua CA”. Decisão posterior do Mestre R41: **crítico positivo válido é acerto automático**, mesmo se ataque comum não superar a CA. São duas leituras possíveis: (A) condição estritamente numérica ainda autoriza resposta mesmo após acerto crítico; (B) sucesso automático do golpe prevalece e impede a resposta. Nenhuma precedência entre essas cláusulas foi fisicamente homologada. O adaptador **não faz resposta automática**, preserva reação declarada/consumida e aplica o acerto crítico e RD. Não cria regra mundial por inferência.

**R47, seed 98002:** primeira seed elegível entre **2 examinadas**, busca dirigida em [98001,99000], crítico 6→6→6 produzido pelo R18. Ataque comum baixo contra CA123; crítico acerta automaticamente; dano integralmente absorvido por RD22, HP Feryn479, reação1→0. Evento R18/checkpoint/replay independentes PASS. Este resultado levou ao novo teste discriminante positivo.

**R47B, seed 103182:** protocolo separado congelado ANTES da segunda busca: primeira seed com crítico positivo e dado de dano pelo menos4; **182 examinadas** em [103001,104000]. Crítico 6→6→6, dado dano4, bruto23, RD22, líquido**1**, Feryn479→478, reação1→0. Evento/checkpoint/auditoria PASS. Os dois casos são **selecionados**: nunca medir chance real do crítico a partir deles.

**Ponto residual:** resultado do golpe e custos foram processados; legalidade da resposta de Contra-atacar após esse crítico = `BLOCKED-NORMATIVE`, primeiro caso mínimo para o Mestre, sem inventar prioridade.

## 3. Ciclo R48 — aninhamento alcançável e fail-closed

**R48, seed 99001:** duas instâncias experimentais distintas Feryn (mesma fonte, CA123, Vida479, reação1 cada). A declara ataque normal (4d6+92) contra B; B anuncia Contra-atacar **antes dos dados**, consumindo slot1→0. O ataque de A dá **{json.loads((ROOT/'ledgers/R48_NESTED_COUNTER_SEED99001.sqlite').with_suffix('.sqlite').name.encode().hex()[:0] or (0).__str__()) if False else 98}**, não ultrapassa CA123. B executa resposta com Vantagem `max(4d6,4d6)+94 = 110`, também não ultrapassa CA123. HP ambos479. A ainda tem slot1: novo gatilho de Contra-atacar é alcançável durante a resposta. **A tentativa de segunda declaração foi bloqueada antes de nova reserva**, preservando causação e recursos, pois prioridade de aninhamento não está definida. R48 não é prova de contra-ataque aninhado completo e não admite impressão de vitória/dano.

**Guardas:** tentativa com slot ausente, novo comando pós-janela encerrada e replay idempotente tratados sem criar nova intenção nos bancos originais; 6/6 guards em CLONES descartáveis ou verificação pré-commit. A primeira resposta B está persistida dentro de único evento atômico; o segundo gatilho é diagnóstico em estado final, não contra-ataque executado.

## 4. Ciclo R49 — empate ON5 com 4d6 e dano fonte-equipado

**Regra R43:** maior DES age primeiro. Duas Feryns têm DES80 iguais: desempate no dado da classificação **4d6 para cada uma**; se o total empata, R26 rerrola somente essas empatadas, sem comparar IDs. Varok DES27 é alvo em deslocamento voluntário, não competidor na prioridade. Cada ataque AoO usa duas rolagens completas de 4d6 + bônus+2 (um nível de Vantagem), dano 8d8+47 e RD física35 do Varok.

Universo declarado antes de buscar: 100001–102000; selecionar primeira seed de três categorias de profundidade, não amostra probabilística:

| Seed | Disputa 4d6 Feryn A / B | Resultado | Dano líquido somado | Varok HP |
|---|---|---|---:|---:|
| 100001 | 9/13 | B primeiro, A segundo | 83 | 734→651 |
| 100013 | 17/17 → 16/14 | A primeiro após 1 empate | 104 | 734→630 |
| 100323 | 12/12 → 13/13 → 8/18 | B primeiro após 2 empates | 100 | 734→634 |

As cenas R49 possuem cada uma **4 eventos transacionais**: prioridade antes de qualquer efeito, ataque da primeira Feryn, ataque da segunda Feryn e só depois conclusão do Movimento do Varok. Duas Reações independentes são consumidas 1→0, Ações Padrão dos atacantes preservadas; checkpoints finais validam HP, RD35 e posição. **Total: seis AoOs reais-fonte em janelas de reação, 287 de dano líquido agregado em cenas independentes**, não um único combate nem dano oficial.

**Nota estatística:** foram inspecionadas até **323 seeds**, selecionadas por eventos de empate; não concluir probabilidade de empate ou uniformidade do gerador. Nas três cenas foram consumidas 12 rolagens COMPLETAS de 4d6 para prioridade (48 dados de seis lados) e demais rolagens separadas para ataque/dano.

## 5. Auditoria de quatro camadas

- **Estrutural:** seis ledgers R18/event_commit originais; 15 eventos com encadeamento SHA256, seis backups SQLite íntegros; zero pending. Sem reutilizar cmd IDs de cenas anteriores.
- **Mecânica:** verificador independente `verify_r47_r49_independent.py` STD-LIB, **não importa o executor, o R18, o R26 ou o v0.8.1**. Reconstrói crítica ordenada 3d6, ataques ON5 de duas rolagens 4d6, danos 8d8+47 e 1d6+13+6 crítico, RD22/35, HP, Reação, Ação e Movimento, eventos e estados SHA.
- **Causal:** R47 declaração antes do sorteio, hit crítico apesar de CA; R48 declaração antes do ataque com contra resposta; R49 prioridade antes dos golpes e deslocamento após dois golpes. Cabeça e checkpoints idênticos ao replay independente.
- **Normativa:** contra em hit crítico R47 e aninhamento R48 bloqueados por autoridade; R49 numericamente source-admitted, mas norma geral ainda não recebeu atualização escrita fora desta OP.
- **Falsificadores:** **17/17 adulterações em CLONES** com cadeia R18 recomposta estruturalmente válida, mas rejeitada pelo auditor independente: acerto automático negado, Counter inventado, reação dupla, dano/RD/HP incoerente, 1d6 no ON5, dado7, ordem invertida, score falso e Movimento prematuro. **6/6 guardas** adicionais de idempotência e preflight; regressões históricas R44–R46 e crítico R41 rodadas READ-ONLY PASS.

## 6. R18 — matriz dos 17 contratos preservada

Delta JSON mantém o ID, o requisito literal e os 17 registros; nenhum requisito foi reescrito. `REACTION_TRIGGER_AND_SINGLE_USE` avançou sobre crítico recebido, contador de slots, aninhamento alcançável e AoO duplo; `TURN_SCHEDULER_EVENT_SOURCING` ganhou prioridade ON5, window ordering e replay; `RNG_REPLAY_STATISTICS` ganhou fita ON5 4d6 e RNG crítico condicionado; `GENERAL_SPECIFIC_RD`, `ACTION_CATALOG_AIN01`, `ITEM_EQUIPMENT_AND_ENHANCEMENTS` e `AUTHORITATIVE_RULES_AND_ADAPTERS` receberam evidência incidental proporcional. Contratos restantes não exercitados. **0/17 terminalmente certificados, 0/1875 células canônicas**. Nenhum desses três ciclos exercitou um combate completo ou validou fonte de RNG canônico da campanha.

## 7. Continuidade — fronteira que realmente altera contrato

**FIRST-PENDING 1 (NAC-NORM):** definir se, depois de Contra-atacar declarado legalmente, um **crítico positivo que acerta automaticamente** ainda autoriza o golpe de resposta quando a pontuação comum não supera CA. Até lá, preservar `HOLD_R47_COUNTER_AFTER_CRIT` e não executar a resposta nesses bancos.

**FIRST-PENDING 2:** definir a precedência de aninhamento: quando A é alvo do Contra-atacar de B, pode A anunciar sua própria Reação e executar outro Contra-atacar antes de concluir a ação de B? Verificar se há proibição de Reação no próprio turno e como fechar a pilha; sem autoridade, fail-closed.

**FRONTEIRA INDEPENDENTE 3:** integração de prioridades ON5 em scheduler real de três atores, com iniciativa 4d6+82 e 4d6+29 publicadas, sem suposições de iniciativa da Cabra; testes completos e reação em turno próprio, com R26 e replay causal. Adicionar knockout durante AoO apenas se alcançado por dano realmente sorteado (não por HP sintético alterado).

**GATES INALTERADOS:** IBX-56 BLOCKED-EXTERNAL, writer/lease/epoch/fencing/GREEN produtivos HOLD; NAC-PASS-02 terminal HOLD; DMG-RANK v1.1 e todas as fichas/Party/O Primeiro/campanha e ledgers produtivos intocados. Bônus +6 de Cabra continua exclusivo de Investida, não AoO nem ataque normal.
'''
# Remove harmless unused expression accidentally embedded before reference if any
report=report.replace('**98**', '**98**')
(ROOT/'delivery/R47_R48_R49_PSV_CIENTIFICO_MESTRE_ONLY.md').write_text(report)
print('REPORT',len(report),'CHARS, rows',len(rows),'sha old R18',SHA(raw))
