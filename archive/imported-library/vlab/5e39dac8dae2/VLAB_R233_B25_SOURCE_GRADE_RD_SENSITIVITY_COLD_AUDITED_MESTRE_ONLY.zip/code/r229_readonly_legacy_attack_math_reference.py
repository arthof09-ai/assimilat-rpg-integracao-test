"""R229 audit from frozen roster and JSONL only. NEVER imports the simulator."""
from __future__ import annotations
import csv,collections,hashlib,json,math
from pathlib import Path
from fractions import Fraction
R=Path(__file__).resolve().parents[1]
def c(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha(x):return hashlib.sha256(c(x).encode()).hexdigest()
def need(b,code):
 if not b:raise AssertionError(code)
def one(row,snap,pre):
 r=row['result'];team_labels={a['actor_id']:a['team'] for a in snap}
 if row['side_label']=='LABEL_SWAP':team_labels={aid:'B' if v=='A' else 'A' for aid,v in team_labels.items()}
 spec={a['actor_id']:a for a in snap};hp={aid:a['health'] for aid,a in spec.items()}
 need(row['snapshot_hash']==sha(snap),'ROSTER_SHA')
 need(r['seed']==row['seed'] and row['seed'] in pre['seeds'],'SEED')
 need(r['version']=='VLAB-MIXED-SENSITIVITY-v0.6.1-R229-CRIT-TEST-PATCH' and not r['source_fully_eligible'] and not r['can_credit_official_core'],'TEST_SOURCE_FENCE')
 need(r['mode']=='CONDITIONAL-SENSITIVITY-NOT-CANONICAL' and not r['canonical_rank_reclassification_allowed'],'CANON_FENCE')
 need(r['rd_mode']==row['rd_mode'] and r['event_count']==len(r['events']),'EVENT_TOTAL')
 need(r['rounds']<=pre['horizon_rounds'] and (len(r['events'])==0 or r['events'][-1]['round']<=pre['horizon_rounds']),'HORIZON')
 need(sha({k:v for k,v in r.items() if k!='digest'})==r['digest'],'RESULT_SHA')
 need(sha({k:v for k,v in r.items() if k not in ('digest','trace_digest','teams','winner_by_lab_hp_threshold')})==r['trace_digest'],'TRACE_SHA')
 need(sorted(r['turn_order'])==sorted(spec),'TURN_IDS')
 for a in spec:
  z=r['initiatives'][a];need(sum(z['dice'])+spec[a]['stats']['DES']==z['score'],'INIT_SUM')
 scores={a:(-r['initiatives'][a]['score'],-r['init_tie'][a],a) for a in spec}
 need(r['turn_order']==sorted(spec,key=lambda a:scores[a]),'TURN_PRIORITY')
 observed={(k,v) for k,v in zip(r['turn_order'],range(len(r['turn_order'])))}
 last_round=0;last_order=-1;attacks=0;total_rd=0;eff=0;actual_hp_removed=0;crit=0;misses=0
 for ev in r['events']:
  attacker=ev['actor_id'];target=ev['target_id'];a=spec[attacker];d=spec[target]
  need(attacker!=target and team_labels[attacker]!=team_labels[target],'ENEMY_ONLY')
  need(ev['source_kind']==a['kind'] and ev['action_id']==f'{attacker}:basic_attack:{target}','ACTION_SOURCE')
  need(ev['policy_version']=='TACTICAL-OBSERVABLE-v0.2','POLICY_VERSION')
  need(1<=ev['round']<=pre['horizon_rounds'],'ROUND_BOUND')
  if ev['round']!=last_round:last_round=ev['round'];last_order=-1
  ix=r['turn_order'].index(attacker);need(ix>last_order,'ROUND_ORDER_NO_EXTRA_ACTION');last_order=ix
  need(hp[target]>0 and hp[attacker]>0,'ALIVE_AT_EVENT')
  expn,expm=map(int,a['attack_dice'].split('d'))
  need(len(ev['attack_draws'])==expn and all(1<=x<=expm for x in ev['attack_draws']),'ATTACK_DICE')
  need(ev['attack_score']==sum(ev['attack_draws'])+a['attack_bonus'],'ATTACK_SCORE')
  need(Fraction(ev['CA_exact'])==Fraction(d['ca']),'DEFENSE_CA')
  cs=ev['crit_rolls'];need(len(cs)==3 and all(1<=x<=6 for x in cs),'CRIT_DICE')
  status=('CRIT' if cs[:2]==[6,6] and cs[2]>=5 else 'CRIT-FAIL-NO-EFFECT-LAB' if cs[:2]==[1,1] and cs[2]<=2 else 'NORMAL')
  need(status==ev['crit_status'],'CRIT_CATEGORIZATION')
  hit=(Fraction(ev['attack_score'])>Fraction(d['ca'])) or (status=='CRIT');need(ev['hit']==hit,'HIT_MATH')
  if status=='CRIT':crit+=1
  if hit:
   n,f=map(int,a['damage_dice'].split('d'))
   damage_rolls=ev['damage_rolls'];need(len(damage_rolls)==n and all(1<=x<=f for x in damage_rolls),'DAMAGE_DICE')
   raw=sum(damage_rolls)+a['damage_fixed']+(n*f if status=='CRIT' else 0)
   damage_net=max(0,raw-(d['rd'] or 0)) if row['rd_mode']=='SUBTRACT-LAB' else raw
   total_rd+=raw-damage_net;eff+=damage_net
  else:
   misses+=1;raw=damage_net=0;need(ev['damage_rolls']==[],'MISS_NO_DAMAGE_RNG')
  need(raw==ev['damage_raw'] and damage_net==ev['damage_net'],'DAMAGE_MATH')
  before=hp[target];hp[target]=max(0,before-damage_net)
  need(before==ev['before_hp'] and hp[target]==ev['after_hp'],'HP_CHAIN')
  actual_hp_removed+=before-hp[target]
  attacks+=1
 need(hp==r['HP'],'FINAL_HP')
 alive_teams={team_labels[a] for a in spec if hp[a]>0}
 if r['complete']:
  need(len(alive_teams)==1 and r['stop_reason']=='LAB-HP-THRESHOLD','LAB_STOP_LIMIT')
 else:need(r['winner_by_lab_hp_threshold'] is None and r['stop_reason']!='LAB-HP-THRESHOLD','CENSOR_NOT_VICTORY')
 return {'events':attacks,'post_rd_damage_requested':eff,'actual_hp_removed':actual_hp_removed,'rd_absorbed_lab':total_rd,'hit_count':attacks-misses,'crit_positive_lab':crit,'misses':misses,'censored':not r['complete']}

def run(root=R,write=True):
 root=Path(root);pre=json.loads((root/'sources/R229_PREREG_BEFORE_EXEC.json').read_text());snap=json.loads((root/'sources/R229_SOURCE_SNAPSHOTS_V06.json').read_text())
 assert len(pre['arms'])==7 and len(pre['seeds'])==12 and pre['horizon_rounds']==12
 refs=list(csv.DictReader((root/'sources/R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv').open()))
 need(len(refs)==104,'R91_104_POSITIONS')
 need(collections.Counter(x['battery'][0] for x in refs)=={'A':25,'B':27,'C':25,'D':27},'R91_COUNTS')
 need(sum(int(x['reference_homologated']) for x in refs)==0,'NO_MATRIX_WRITE')
 data=[json.loads(s) for s in (root/'evidence/reports/R229_NEW_LAB_SENSITIVITY_JSONL').read_text().splitlines() if s.strip()]
 need(len(data)==7*12*2*2,'DENOM')
 dictrows={};stats=[]
 for row in data:
  key=(row['arm'],row['seed'],row['rd_mode'],row['side_label']);need(key not in dictrows,'UNIQUE_RUN')
  need(row['arm'] in pre['arms'] and row['rd_mode'] in pre['rd_modes'] and row['mirror_ok'],'SCOPED_RUN')
  stats.append(dict({'arm':row['arm'],'seed':row['seed'],'rd_mode':row['rd_mode'],'side':row['side_label']},**one(row,snap[row['arm']],pre)))
  dictrows[key]=row['result']
 for arm in pre['arms']:
  for rd in pre['rd_modes']:
   for seed in pre['seeds']:
    a=dictrows[(arm,seed,rd,'ORIGINAL')];b=dictrows[(arm,seed,rd,'LABEL_SWAP')]
    need(a['events']==b['events'] and a['HP']==b['HP'] and a['initiatives']==b['initiatives'],'MIRROR_EVENTS_HP_INIT')
    need(a['trace_digest']==b['trace_digest'],'MIRROR_HASH')
    need(a['teams']!=b['teams'],'ACTUAL_TEAM_LABEL_CHANGE')
 by=collections.defaultdict(list)
 for x in stats:
  if x['side']=='ORIGINAL':by[(x['arm'],x['rd_mode'])].append(x)
 ag=json.loads((root/'evidence/reports/R229_AGGREGATES.json').read_text())
 need(ag['executions']==168 and ag['side_swaps']==168,'AGG_DENOM')
 rows=[]
 for v in ag['arm_summaries']:
  q=by[(v['arm'],v['rd_mode'])]
  need(len(q)==v['seeds']==12 and sum(x['events'] for x in q)==v['attack_events'],'AGG_EVENTS')
  need(sum(x['censored'] for x in q)==v['censures_or_stalemate'],'AGG_CENSORED')
  rows.append({**v,'native_r18':False,'source_complete':False,'rd_damage_blocked':sum(x['rd_absorbed_lab'] for x in q),'damage_effective_hp':sum(x['actual_hp_removed'] for x in q),'damage_post_rd_requested':sum(x['post_rd_damage_requested'] for x in q),'hits':sum(x['hit_count'] for x in q),'crit_lab':sum(x['crit_positive_lab'] for x in q)})
 out={'status':'PASS_R229_INDEPENDENT_BENCH_V06_TRACE_AUDIT_CONDITIONAL','new_original_executions':168,'label_swaps_not_independent':168,
       'arms':7,'seeds_per_arm':12,'rd_regimes':2,'total_reported_events_original':sum(x['events'] for x in stats if x['side']=='ORIGINAL'),
       'total_hit_count_original':sum(x['hit_count'] for x in stats if x['side']=='ORIGINAL'),
       'total_effective_hp_loss_original':sum(x['actual_hp_removed'] for x in stats if x['side']=='ORIGINAL'),
       'total_damage_post_rd_requested_original':sum(x['post_rd_damage_requested'] for x in stats if x['side']=='ORIGINAL'),
       'full_canonical_fights':0,'homologated_matrix_cells':0,'official_contracts_certified':0,
       'source_complete_species':0,'mechanical_scope':'LEGACY_V06_GENERIC_BASIC_ATTACK_ONLY_NO_NATIVE_R18','per_arm':rows}
 if write:(root/'evidence/reports/R229_INDEPENDENT_AUDIT.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k!='per_arm'},indent=2,ensure_ascii=False));return out
if __name__=='__main__':run()
