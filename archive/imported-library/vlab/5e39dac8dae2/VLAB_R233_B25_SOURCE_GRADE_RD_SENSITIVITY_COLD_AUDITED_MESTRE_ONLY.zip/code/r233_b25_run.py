"""B25 LAB sensitivity on corrected existing R229 legacy v0.6.1. No new combat engine."""
from pathlib import Path
from dataclasses import asdict,replace
import json,hashlib,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'runtime/native'))
from vlab_l04 import build_human,build_beast
from vlab_beast_benchmark_v06 import make_actor,run
PRE=json.loads((R/'sources/R233_B25_PREREG_BEFORE_EXEC.json').read_text())
def jdump(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha(x):return hashlib.sha256(jdump(x).encode()).hexdigest()
def start():
 path=R/'evidence/reports/R233_B25_FULL_TRACE.jsonl'
 if path.exists():raise FileExistsError('R233 immutable outputs already exist')
 roster={};summary=[]
 for ix,(rank,star) in enumerate(PRE['rank_stars'],1):
  h=make_actor(build_human(rank,star,23350000+ix,priority=('FOR','CON','DES','INT','SAB','CAR')),'A',role='generalist',seed=23350000+ix)
  b=make_actor(build_beast(rank,star,23360000+ix,priority=('FOR','CON','DES','INT','SAB','CAR')),'B',seed=23360000+ix)
  roster[str(ix)]=[dict(asdict(x),ca=str(x.ca)) for x in (h,b)]
 (R/'sources/R233_B25_ROSTER_SNAPSHOTS.json').write_text(json.dumps(roster,ensure_ascii=False,indent=2)+'\n')
 with path.open('x') as f:
  for ix,(rank,star) in enumerate(PRE['rank_stars'],1):
   p=roster[str(ix)]
   # Restoring frozen source L04 instance avoids depending on JSON coercion for Fraction.
   h=make_actor(build_human(rank,star,23350000+ix,priority=('FOR','CON','DES','INT','SAB','CAR')),'A',role='generalist',seed=23350000+ix)
   b=make_actor(build_beast(rank,star,23360000+ix,priority=('FOR','CON','DES','INT','SAB','CAR')),'B',seed=23360000+ix)
   for seed in PRE['seeds']:
    for rd in PRE['rd_modes']:
     normal=run((h,b),seed,max_rounds=PRE['horizon_rounds'],rd_mode=rd)
     flip=run((replace(h,team='B'),replace(b,team='A')),seed,max_rounds=PRE['horizon_rounds'],rd_mode=rd)
     assert normal['events']==flip['events'] and normal['HP']==flip['HP'] and normal['trace_digest']==flip['trace_digest'] and normal['initiatives']==flip['initiatives']
     for mode,v in [('ORIGINAL',normal),('LABEL_SWAP',flip)]:
      f.write(jdump({'position':ix,'rank':rank,'star':star,'seed':seed,'rd_mode':rd,'label_mode':mode,'roster_sha':sha(p),'mirror_ok':True,'result':v})+'\n')
     summary.append({'position':ix,'rank':rank,'star':star,'seed':seed,'rd_mode':rd,'terminal_HP':normal['HP'],'rounds':normal['rounds'],'stop':normal['stop_reason'],'event_count':normal['event_count'],'lab_threshold':normal['complete']})
 (R/'evidence/reports/R233_SUMMARY_TUPLES.json').write_text(json.dumps({'status':'PENDING_INDEPENDENT_AUDIT','original_runs':len(summary),'mirror_runs':len(summary),'position_count':25,'seeds_per_position':4,'rounds_cap':PRE['horizon_rounds'],'rows':summary},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'original':len(summary),'mirrors':len(summary),'position_count':25,'trace_lines':len(summary)*2,'lab_threshold_ends':sum(x['lab_threshold'] for x in summary)},ensure_ascii=False))
if __name__=='__main__':start()
