"""B25 read-only independent 400-log trace auditor. No imports of benchmark runner or engine."""
from pathlib import Path
import json,collections,csv,copy
from r229_readonly_legacy_attack_math_reference import one,sha,need
R=Path(__file__).resolve().parents[1]
def audit(root=R,write=True):
 root=Path(root);pre=json.loads((root/'sources/R233_B25_PREREG_BEFORE_EXEC.json').read_text());snap=json.loads((root/'sources/R233_B25_ROSTER_SNAPSHOTS.json').read_text())
 need(len(pre['rank_stars'])==25 and len(pre['seeds'])==4 and len(pre['rd_modes'])==2 and len(set(pre['seeds']))==4,'PREREG_25_4_2')
 refs=list(csv.DictReader((root/'sources/R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv').open()));need(len(refs)==104 and sum(int(x['reference_homologated']) for x in refs)==0,'R91_OFFICIAL_UNCHANGED')
 need(len(snap)==25,'ROSTER25');data=[json.loads(s) for s in (root/'evidence/reports/R233_B25_FULL_TRACE.jsonl').read_text().splitlines() if s.strip()]
 need(len(data)==25*4*2*2,'DENOM400');seen={};stats=[]
 for row in data:
  ix=row['position'];rank,star=pre['rank_stars'][ix-1]
  need((row['rank'],row['star'])==(rank,star),'RANK_STAR_MISMATCH')
  s=row['seed'];d=row['rd_mode'];m=row['label_mode'];need(s in pre['seeds'] and d in pre['rd_modes'] and m in ('ORIGINAL','LABEL_SWAP') and row['mirror_ok'] is True,'SOURCE_RUN_DOMAIN')
  key=(ix,s,d,m);need(key not in seen,'RUN_ID_DUPLICATION')
  rr={**row,'side_label':m,'snapshot_hash':row['roster_sha']};metric=one(rr,snap[str(ix)],pre)
  seen[key]=row['result'];stats.append({'position':ix,'rank':rank,'star':star,'seed':s,'rd_mode':d,'label_mode':m,**metric})
 for ix in range(1,26):
  for s in pre['seeds']:
   for d in pre['rd_modes']:
    a=seen[(ix,s,d,'ORIGINAL')];b=seen[(ix,s,d,'LABEL_SWAP')]
    need(a['events']==b['events'] and a['HP']==b['HP'] and a['initiatives']==b['initiatives'] and a['trace_digest']==b['trace_digest'],'INVARIANCE_LABEL_SWAP')
    need(a['teams']!=b['teams'],'LABEL_ACTUALLY_SWAPPED')
 paired_trace_identity=0;paired_terminal_difference=0;paired_hp_delta=0
 for ix in range(1,26):
  for seed in pre['seeds']:
   withrd=seen[(ix,seed,'SUBTRACT-LAB','ORIGINAL')];offrd=seen[(ix,seed,'OFF-LAB','ORIGINAL')]
   need(withrd['initiatives']==offrd['initiatives'] and withrd['turn_order']==offrd['turn_order'],'PAIRED_INITIATIVE_SCHEDULE')
   need(len(withrd['events'])==len(offrd['events']),'PAIRED_EVENT_COUNT')
   for a,b in zip(withrd['events'],offrd['events']):
    for field in ('round','actor_id','target_id','attack_draws','crit_rolls','damage_rolls','attack_score','hit'):
     need(a[field]==b[field],'PAIRED_OFFENSIVE_STREAM_'+field)
   paired_trace_identity+=1
   if withrd['HP']!=offrd['HP']:paired_terminal_difference+=1
   # Positive if the WITH-RD arm conserved HP versus NO-RD arm.
   paired_hp_delta+=sum(withrd['HP'].values())-sum(offrd['HP'].values())
 need(paired_trace_identity==100,'ONE_HUNDRED_PAIRED_STREAMS')
 summary=json.loads((root/'evidence/reports/R233_SUMMARY_TUPLES.json').read_text());need(len(summary['rows'])==200 and summary['original_runs']==200 and summary['mirror_runs']==200,'SUMMARY_DENOM')
 per=[];original=[x for x in stats if x['label_mode']=='ORIGINAL']
 for ix in range(1,26):
  rank,star=pre['rank_stars'][ix-1]
  for rd in pre['rd_modes']:
   v=[x for x in original if x['position']==ix and x['rd_mode']==rd];need(len(v)==4,'PER_POSITION_FOUR_SEEDS')
   per.append({'position':ix,'rank':rank,'star':star,'rd_mode':rd,'seed_units':4,'lab_hp_threshold':sum(not z['censored'] for z in v),'horizon_censored':sum(z['censored'] for z in v),'attacks':sum(z['events'] for z in v),'hits':sum(z['hit_count'] for z in v),'rd_absorbed_lab':sum(z['rd_absorbed_lab'] for z in v),'effective_hp_removed':sum(z['actual_hp_removed'] for z in v)})
 for row in summary['rows']:
  r=seen[(row['position'],row['seed'],row['rd_mode'],'ORIGINAL')]
  need(row['terminal_HP']==r['HP'] and row['event_count']==r['event_count'] and row['stop']==r['stop_reason'] and row['lab_threshold']==r['complete'],'SUMMARY_SNAPSHOT')
 need(len(list((root/'evidence/quarantine').glob('R233_V0*')))==1,'V0_BAD_RD_MODE_QUARANTINE')
 result={'status':'PASS_R233_INDEPENDENT_25_LEVEL_BATTERY_B_LAB_SENSITIVITY','regular_positions':25,'independent_seed_values':4,'original_runs':200,'label_swap_repeats_nonindependent':200,
 'original_attacks':sum(x['events'] for x in original),'original_hits':sum(x['hit_count'] for x in original),'actual_hp_removed':sum(x['actual_hp_removed'] for x in original),
 'post_rd_requested_including_overkill':sum(x['post_rd_damage_requested'] for x in original),'rd_absorbed_lab':sum(x['rd_absorbed_lab'] for x in original),
 'horizon_censures':sum(x['censored'] for x in original),'lab_hp_threshold_ends':sum(not x['censored'] for x in original),
 'exact_offensive_stream_paired_comparisons':paired_trace_identity,'terminal_HP_differed_paired_comparisons':paired_terminal_difference,'aggregate_HP_preserved_by_RD_across_100_pairs':paired_hp_delta,'official_battery_B_cells':0,'native_R18_battles':0,'full_Beast_spirit_skill_combat':0,'historical_replays':0,'per_position_rd':per}
 if write:(root/'evidence/reports/R233_INDEPENDENT_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='per_position_rd'},ensure_ascii=False,indent=2));return result
if __name__=='__main__':audit()
