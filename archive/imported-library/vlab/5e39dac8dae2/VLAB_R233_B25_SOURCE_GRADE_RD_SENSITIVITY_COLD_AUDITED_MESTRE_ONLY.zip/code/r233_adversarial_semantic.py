"""B25 adversarial audit of independently rehashed trace data; engine not imported."""
from pathlib import Path
from r233_independent_b25_audit import audit
from r229_readonly_legacy_attack_math_reference import sha
import json,copy,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1]
def rehash(r):
 r['trace_digest']=sha({k:v for k,v in r.items() if k not in ('digest','trace_digest','teams','winner_by_lab_hp_threshold')})
 r['digest']=sha({k:v for k,v in r.items() if k!='digest'})
def mutate(rows,typ):
 if typ=='PAIR_STREAM_DRIFT':
  for r in rows:
   if r['position']==6 and r['seed']==23349101 and r['rd_mode']=='OFF-LAB':
    ev=next(e for e in r['result']['events'] if len(e['attack_draws'])>=2 and e['attack_draws'][0]!=e['attack_draws'][1]);ev['attack_draws'][0],ev['attack_draws'][1]=ev['attack_draws'][1],ev['attack_draws'][0]
    rehash(r['result'])
 elif typ=='FALSE_CRITICAL':
  v=rows[0]['result'];v['events'][0]['crit_status']='CRIT';rehash(v)
 elif typ=='FALSE_OFFICIAL_PROMOTION':
  v=rows[0]['result'];v['source_fully_eligible']=True;rehash(v)
 elif typ=='FALSE_HP_AFTER':
  v=rows[0]['result'];v['events'][0]['after_hp']+=1;rehash(v)
 else:raise ValueError(typ)
def run():
 src=(ROOT/'evidence/reports/R233_B25_FULL_TRACE.jsonl').read_text().splitlines();out={}
 for typ in ['PAIR_STREAM_DRIFT','FALSE_CRITICAL','FALSE_OFFICIAL_PROMOTION','FALSE_HP_AFTER']:
  rows=[json.loads(s) for s in src]
  mutate(rows,typ)
  with tempfile.TemporaryDirectory(prefix='R233_REHASH_ADVERSARY_') as tmp:
   root=Path(tmp);(root/'sources').mkdir();(root/'evidence/reports').mkdir(parents=True);(root/'evidence/quarantine').mkdir()
   for name in ['R233_B25_PREREG_BEFORE_EXEC.json','R233_B25_ROSTER_SNAPSHOTS.json','R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv']:
    shutil.copy2(ROOT/'sources'/name,root/'sources'/name)
   shutil.copy2(ROOT/'evidence/reports/R233_SUMMARY_TUPLES.json',root/'evidence/reports/R233_SUMMARY_TUPLES.json')
   for q in (ROOT/'evidence/quarantine').glob('R233_V0*'):shutil.copy2(q,root/'evidence/quarantine'/q.name)
   (root/'evidence/reports/R233_B25_FULL_TRACE.jsonl').write_text('\n'.join(json.dumps(r,sort_keys=True,separators=(',',':'),ensure_ascii=False) for r in rows)+'\n')
   try:audit(root,write=False)
   except AssertionError as ex:out[typ]=str(ex)
   else:raise AssertionError('UNCHECKED_MUTATION '+typ)
 assert len(out)==4
 p=ROOT/'evidence/reports/R233_ADVERSARIAL_SEMANTIC.json';p.write_text(json.dumps({'status':'PASS_4_OF_4_SEMANTIC_REHASHED_ADVERSARIES_REJECTED','cases':out},ensure_ascii=False,indent=2)+'\n');print(p.read_text())
if __name__=='__main__':run()
