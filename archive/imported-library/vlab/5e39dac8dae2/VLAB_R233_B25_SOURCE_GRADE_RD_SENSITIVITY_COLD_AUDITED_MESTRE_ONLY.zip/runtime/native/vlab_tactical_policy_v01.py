"""Versioned noncanonical decision layer. Never grants an action or resolves a rule.
Receives ONLY externally supplied legal action options and visible observations.
Side labels are deliberately absent from the decision API.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Literal

Tier=Literal['instinct','basic','trained','expert']
Role=Literal['striker','protector','controller','support','skirmisher','generalist']

@dataclass(frozen=True)
class TacticalObservation:
    actor_id:str
    role:Role
    tier:Tier
    own_health_fraction:float
    ally_under_pressure:bool=False
    observed_enemy_count:int=1
    mission_requires_survival:bool=False
    # not exact enemy HP, secret spell lists, or unknown resistances

@dataclass(frozen=True)
class LegalAction:
    action_id:str
    kind:Literal['attack','heal','protect','control','retreat','move','buff']
    target_id:str|None
    # Observables are source-neutral lab descriptors, not mechanical buffs
    target_visible_condition:Literal['normal','injured','critical','unknown']='unknown'
    target_threat_level:Literal['low','medium','high','unknown']='unknown'
    ally_urgency:Literal['none','injured','critical']='none'
    cost_class:Literal['low','medium','high']='medium'
    success_estimate:float|None=None  # only if visible/model source, not hidden enemy stats

@dataclass(frozen=True)
class TacticalDecision:
    policy_version:str
    actor_id:str
    action_id:str
    target_id:str|None
    score:int
    reasons:tuple[str,...]
    candidate_count:int
    note:str='LABORATORY POLICY ONLY; NOT A CANONICAL RPG RULE'

VERSION='TACTICAL-OBSERVABLE-v0.1'
BASE={'attack':40,'control':36,'protect':26,'heal':27,'retreat':15,'move':10,'buff':22}
ROLE={'striker':{'attack':20},'protector':{'protect':25,'attack':5},
      'controller':{'control':25,'attack':4},'support':{'heal':24,'protect':14},
      'skirmisher':{'attack':7,'retreat':9,'move':9},'generalist':{}}

def choose(obs:TacticalObservation,legal:tuple[LegalAction,...])->TacticalDecision:
    if not legal:raise ValueError('NO-LEGAL-ACTIONS: combat must stop/declare no-action via competent rules')
    if obs.tier not in ('instinct','basic','trained','expert') or obs.role not in ROLE:
        raise ValueError('Unknown experimental role/tier')
    if not 0<=obs.own_health_fraction<=1:raise ValueError('Health ratio invalid')
    ids=[x.action_id for x in legal]
    if len(set(ids))!=len(ids):raise ValueError('Duplicate action IDs')
    scored=[]
    for a in legal:
        s=BASE[a.kind];why=[f'base-{a.kind}={s}']
        role_boost=ROLE[obs.role].get(a.kind,0)
        if role_boost:s+=role_boost;why.append(f'role-{obs.role}=+{role_boost}')
        if a.kind=='heal' and a.ally_urgency=='critical':s+=42;why.append('protect-critical-ally')
        if a.kind=='protect' and obs.ally_under_pressure:s+=25;why.append('ally-under-pressure')
        if a.kind=='attack' and a.target_visible_condition=='critical':s+=17;why.append('observed-critical-opponent')
        elif a.kind=='attack' and a.target_visible_condition=='injured':s+=8;why.append('observed-injured-opponent')
        if a.kind=='attack' and a.target_threat_level=='high' and obs.tier in ('trained','expert'):
            s+=10;why.append('observed-high-threat')
        if obs.own_health_fraction<0.3 and a.kind=='retreat':
            s+=46 if obs.mission_requires_survival else 22;why.append('self-preservation')
        if obs.own_health_fraction<0.3 and a.kind=='protect':s+=11;why.append('defensive-health')
        if obs.tier=='instinct' and a.kind in ('control','buff'):
            s-=22;why.append('instinct-repertoire-prefers-direct')
        if a.cost_class=='high':s-=7;why.append('cost-high')
        # Fixed-value math only if estimate has a legal, observed provenance; here not used.
        scored.append((s,a,why))
    # Stable deterministic tie break independent of side, roster ordering, or team name.
    scored.sort(key=lambda x:(-x[0],x[1].action_id,x[1].target_id or ''))
    s,a,why=scored[0]
    return TacticalDecision(VERSION,obs.actor_id,a.action_id,a.target_id,s,tuple(why),len(legal))
