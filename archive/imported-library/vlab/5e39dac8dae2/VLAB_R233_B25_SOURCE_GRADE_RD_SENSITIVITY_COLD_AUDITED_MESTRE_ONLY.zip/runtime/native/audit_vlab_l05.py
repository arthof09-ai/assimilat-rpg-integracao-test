"""Independent reference checker of JSON event trace, without invoking duel engine."""
from __future__ import annotations
import hashlib, json, random, pathlib, sys

def stable(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(x):return hashlib.sha256(stable(x).encode()).hexdigest()
def refdice(seed,key,label,sides,n=1):
    bits=hashlib.sha256(f'VL05-DUEL-0.1|{seed}|{key}|{label}'.encode()).digest()
    r=random.Random(int.from_bytes(bits,'big'))
    return [r.randint(1,sides) for _ in range(n)]
def audit(obj):
    problems=[];v='VL05-DUEL-0.1'
    def check(cond,msg):
        if not cond:problems.append(msg)
    a={x['side']:x for x in obj['actors']};key=obj['run_key'];seed=obj['rng_seed'];hp={s:a[s]['health'] for s in a}
    check(obj['protocol']==v,'wrong protocol')
    check(obj['fixture_hash']==digest({'actors':obj['actors'],'policy':obj['scenario_policy'],'version':v}),'fixture digest')
    check(key==obj['fixture_hash'][:16],'key mismatch')
    check(obj['run_digest']==digest({k:x for k,x in obj.items() if k!='run_digest'}),'run digest')
    ini={s:refdice(seed,key,f'INIT:{s}',6)[0] for s in a}
    totals={s:ini[s]+a[s]['attributes']['DES']+a[s]['initiative_bonus'] for s in a}
    check(totals==obj['initiative_totals'],'initiative totals')
    check(obj['initiative_rolls']==ini,'initiative rolls')
    order=sorted(a,key=lambda s:-totals[s]);check(obj['turn_order']==order,'turn order')
    seen=set()
    for idx,e in enumerate(obj['events']):
        rid=e['round'];s=e['turn_actor'];t=e['target']
        check((rid,s) not in seen,f'repeated turn {rid}/{s}');seen.add((rid,s))
        check(t in a and s in a and t!=s,f'invalid target event {idx}')
        check(e['actor_id']==a[s]['actor_id'] and e['target_actor_id']==a[t]['actor_id'],f'identity mismatch event {idx}')
        check(hp[s]>0 and hp[t]>0,f'actor inactive at event {idx}')
        check(e['target_hp_before']==hp[t],f'HP before wrong at event {idx}')
        check(e['action_budget_after']['standard']==0 and e['action_budget_after']['movement']==1 and e['action_budget_after']['reaction']==1, f'action budget invalid at {idx}')
        attack=refdice(seed,key,f'ROUND:{rid}:ATTACK:{s}',6)
        crit=refdice(seed,key,f'ROUND:{rid}:CRIT:{s}',6,3)
        check(e['attack_dice']==attack and e['critical_check_sequential']==crit,f'RNG mismatch at {idx}')
        roll=attack[0]+a[s]['attributes']['FOR']+a[s]['luta_prof_bonus']
        check(roll==e['attack_total'],f'attack arithmetic at {idx}')
        hit=roll>a[t]['defense_ca']
        check(hit==e['hit'],f'hit test at {idx}')
        check(e['target_CA']==a[t]['defense_ca'],f'CA at {idx}')
        crit_expected='POSITIVE-CRIT' if crit[:2]==[6,6] and crit[2] in (5,6) else 'CRITICAL-FAIL' if crit[:2]==[1,1] and crit[2] in (1,2) else 'NONE'
        check(e['critical_status']==crit_expected and crit_expected!='CRITICAL-FAIL',f'critical at {idx}')
        d4=refdice(seed,key,f'ROUND:{rid}:DAMAGE:{s}',4) if hit else []
        damage=(sum(d4)+a[s]['ff_damage_fixed']+(4 if crit_expected=='POSITIVE-CRIT' else 0)) if hit else 0
        check(e['weapon_dice_1d4']==d4,f'damage rng at {idx}')
        check(e['dmg_intrinsic']==sum(d4),f'intrinsic dmg at {idx}')
        check(e['dmg_final']==damage,f'final dmg at {idx}')
        hp[t]=max(0,hp[t]-damage)
        check(e['target_hp_after']==hp[t],f'HP after at {idx}')
    check(hp==obj['hp_final'],'HP final')
    check(len(obj['events'])==obj['action_events'],'event count')
    check(obj['classification']=='RUN-CONDITIONAL-LAB-NONCANON','must remain conditional')
    check(not obj['credit_core_full_fight_baseline'] and not obj['full_fight_in_canonical_system'],'improper ledger credit')
    check(obj['winner_by_lab_stop_condition'] in ('A','B') and hp[('B' if obj['winner_by_lab_stop_condition']=='A' else 'A')]==0,'winner/HP status')
    return {'pass':not problems,'checks':20+len(obj['events'])*16,'events':len(obj['events']),'problems':problems,
            'verified_by':'independent reference JSON trace checker (not human or external audit)'}
if __name__=='__main__':
    path=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path(__file__).parent/'samples/duel_bronze1_seed1_full_log.json'
    a=audit(json.loads(path.read_text(encoding='utf-8')))
    print(json.dumps(a,indent=2,ensure_ascii=False))
    if not a['pass']:sys.exit(1)
