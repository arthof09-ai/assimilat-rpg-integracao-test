"""Model-based, noncanonical RD / attack-reachability / transformation stress."""
from random import Random
from fractions import Fraction
from vlab_rd_v08 import *
from vlab_effects_v08 import transformed_budget,AssimilatedSpirit
from vlab_persistence_v08 import persist_basic_attacks

def run():
    rng=Random(20261008);n=0
    for i in range(5000):
        damage=rng.randrange(0,2001);rd=rng.randrange(0,2001)
        tag=rng.choice(sorted(VALID_TAGS))
        a=mitigate((DamageComponent(damage,tag,'STRESS'),),Resistances(general=rd))
        assert a.effective==max(0,damage-rd)
        assert 0<=a.effective<=damage
        n+=2
        specified=rng.choice(sorted(VALID_TAGS))
        b=mitigate((DamageComponent(damage,tag,'STRESS'),),Resistances(specific=((specified,rd),)))
        assert b.effective==(max(0,damage-rd) if rd_match_tag(tag)==rd_match_tag(specified) else damage)
        assert 0<=b.effective<=damage
        n+=2
        if rd>0:
            less=mitigate((DamageComponent(damage,tag,'STRESS'),),Resistances(general=rd-1))
            assert less.effective>=a.effective
            n+=1
    for i in range(1000):
        level=rng.randrange(1,26);spiritmax=rng.randrange(1,26);bap=Fraction(rng.randrange(0,41),2)
        cap=min(level,spiritmax);budget=bap*cap/2;floor=budget.numerator//budget.denominator
        delta={'FOR':floor,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0}
        spirit=AssimilatedSpirit('DEMO',spiritmax,bap,delta,{'CA':10},'SYNTHETIC')
        lv,p,c=transformed_budget(level,spirit)
        assert lv==cap and p==floor and c==budget-floor and 0<=c<1
        n+=3
    for i in range(250):
        a=persist_basic_attacks(attacker_id=f'a{i}',defender_id=f'b{i}',seed=i,dice_count=1,
            dice_faces=6,bonus=12,ca=Fraction(30),max_attempts=20)
        assert a['attempts']==20 and not a['basic_hit_possible'] and not any(event['hit'] for event in a['events'])
        n+=3
    print(f'RD / transform / persistence model checks: {n} PASS; randseed=20261008; no canonical claim')
    return n
if __name__=='__main__':run()
