"""MESTRE-SIDE LAB v0.6: mixed ED/BE combat *conditional sensitivity* harness.

All effects follow verified source where available. ASSUMPTIONS intentionally
noncanonical: strict fractional CA, RD applied as max(0,raw-RD) (compare OFF),
Beast proficiency interpreted for Luta, Beast basic attack allowed, all adjacent,
initiative ties via seeded actor-ID ordering, critical failure has no effect,
HP<=0 LAB stoppage, no movement/reactions/magic/buffs. A/B symmetric RNG.

This is NOT a canonical fight nor a calibration dataset. It identifies exact
blocking questions while letting software exercise mixed-actor flows.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from fractions import Fraction
from hashlib import sha256
import json,re
from typing import Literal
from vlab_l04 import ActorSnapshot, build_human, build_beast, RANK_TEST_DICE
from vlab_l05_duel import dice_for
from vlab_tactical_policy_v02 import (
    FighterDoctrine,VisibleContext,SourcedOption,choose_action,doctrine_from_snapshot)

VERSION='VLAB-MIXED-SENSITIVITY-v0.6.1-R229-CRIT-TEST-PATCH'
PROFILE='ALL-ADJACENT / BASE-ATTACK / NO-MOVEMENT-MAGIC-REACTION'
BEAST_PROF_NORMAL={'Bronze':6,'Prata':8,'Ouro':10,'Ouro Negro':12}
BEAST_PROF_TITAN={'Bronze':8,'Prata':11,'Ouro':14,'Ouro Negro':17,'Lendário':22}
BEAST_PROF_REF='Criação de Besta: Regra 4 — Proficiência'
BEAST_DAMAGE_REF='Criação de Besta: Regra 7 — Dano base'
ED_WEAPON_REF='DMG-RANK-01 v1.1 §8 Arma comum leve, 1d4'
SOURCE_REFS=('3ebc2b32-4ede-8144-9222-f3c06b840613',
             '3ebc2b32-4ede-81f4-992a-c88a3588cacd',
             '3ebc2b32-4ede-81f1-be4b-e8804ac113c0',
             '3f2c2b32-4ede-8154-98cd-db7844245f7e')
LAB_ASSUMPTIONS=(
    'BEAST: interpret generic prof as attack Luta bonus',
    'BEAST: natural base_attack_dice is accessible as one standard melee action',
    'BEAST: no reactive choice; all abilities besides basic attack ignored',
    'RD-subtract max(0,RAW-RD) is a lab-only possible interpretation; OFF alternate',
    'CA of BE uses exact rational comparison with no imposed rounding',
    'INIT-TIE: seeded actor-ID ordering (not official initiative tiebreak)',
    'CRITICAL-FAIL: no extra consequence (sensitivity only, not official)',
    'STOP-HP0: laboratory elimination threshold, not canonical death',
    'ALL-ADJACENT: no movement, line of sight, target range or positioning models',
    'ED: choose ordinary light 1d4 weapon, +2 selected Luta proficiency',
    'Critical sequence is rolled for each attack as a lab test timing assumption',
)

class FixtureUnsafe(ValueError):pass

@dataclass(frozen=True)
class SimActor:
    actor_id:str
    team:str
    kind:str
    rank:str
    star:int
    health:int
    stats:dict[str,int]
    ca:Fraction
    rd:int|None
    attack_dice:str
    attack_bonus:int
    damage_dice:str
    damage_fixed:int
    source_refs:tuple[str,...]
    doctrine:FighterDoctrine
    assumptions:tuple[str,...]


def unpack_fraction(data:dict)->Fraction:
    return Fraction(data['numerator'],data['denominator'])

def make_actor(snapshot:ActorSnapshot,team:str,*,role:str|None=None,style:str|None=None,
               seed:int=0) -> SimActor:
    if team not in ('A','B','C'):raise FixtureUnsafe('Team only A/B/C in this bench; labels are not rule inputs')
    if snapshot.actor_kind not in ('ED','BE') or snapshot.health is None:
        raise FixtureUnsafe('Missing actor kind or Life (special beast unresolved)')
    if snapshot.actor_kind=='BE' and ('ADM' in snapshot.traits or 'Besta Divina' in snapshot.traits):
        raise FixtureUnsafe('Special beast attributes are not yet eligible')
    ca=unpack_fraction(snapshot.ca)
    if snapshot.actor_kind=='ED':
        damage_dice='1d4'
        bonus=sum(m['fixed_roll'] for m in snapshot.ff_milestones if m['choice']=='damage')
        attack_bonus=snapshot.stats['FOR']+2 # LAB created with Luta proficiency
        assumptions=('ED lab build +2 Luta chosen','Common light weapon from DMG-RANK')
        attack_dice=snapshot.test_dice
    else:
        titan='Titã' in snapshot.traits
        prof=(BEAST_PROF_TITAN if titan else BEAST_PROF_NORMAL).get(snapshot.rank)
        if prof is None or snapshot.base_attack_dice is None:raise FixtureUnsafe('Bestial proficiency/damage absent')
        bonus=0
        attack_bonus=snapshot.stats['FOR']+prof
        damage_dice=snapshot.base_attack_dice
        attack_dice=RANK_TEST_DICE[snapshot.rank]
        assumptions=('BE Luta proficiency from generic prof (lab-only)','BE base damage used as one natural basic attack')
    d=doctrine_from_snapshot(snapshot.actor_id,snapshot.actor_kind,
          race_or_species=snapshot.race_or_species,source_traits=snapshot.traits,
          assigned_style=style,assigned_role=role,lab_seed=seed)
    return SimActor(snapshot.actor_id,team,snapshot.actor_kind,snapshot.rank,snapshot.star,
        snapshot.health,snapshot.stats,ca,snapshot.rd,attack_dice,attack_bonus,damage_dice,bonus,
        tuple(snapshot.source_refs.values()),d,assumptions)

def stable_dict(s:dict)->str:return json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def digest(value:dict)->str:return sha256(stable_dict(value).encode()).hexdigest()

def roll_expr(expression:str, seed:int, identity:str, path:str):
    m=re.fullmatch(r'(\d+)d(\d+)',expression or '')
    if not m:raise FixtureUnsafe('Unsupported dice '+str(expression))
    n,faces=map(int,m.groups())
    if not (1<=n<=100 and 2<=faces<=100):raise FixtureUnsafe('Invalid dice')
    draws=dice_for(seed,identity,path,faces,n)
    return sum(draws),draws,n*faces

def highest_possible_basic_hit(attacker:SimActor, defender:SimActor, rd_mode:str)->bool:
    '''Only basic attack submodel; no spells/control/movement, not an RPG rule.'''
    m=re.fullmatch(r'(\d+)d(\d+)', attacker.attack_dice)
    if not m:raise FixtureUnsafe('Attack dice unresolved')
    top=int(m.group(1))*int(m.group(2))+attacker.attack_bonus
    if Fraction(top)<=defender.ca:return False
    d=re.fullmatch(r'(\d+)d(\d+)',attacker.damage_dice)
    if not d:raise FixtureUnsafe('Damage dice unresolved')
    max_damage=int(d.group(1))*int(d.group(2))*2+attacker.damage_fixed # potential critical
    if rd_mode=='SUBTRACT-LAB':return max_damage>(defender.rd or 0)
    return max_damage>0

def run(roster:tuple[SimActor,...],seed:int,*,max_rounds:int=30,
        rd_mode:Literal['SUBTRACT-LAB','OFF-LAB']='SUBTRACT-LAB'):
    if rd_mode not in ('SUBTRACT-LAB','OFF-LAB'):raise ValueError('RD regime invalid')
    if not 2<=len(roster)<=40:raise FixtureUnsafe('2–40 only as benchmark, not a guarantee')
    if not 1<=max_rounds<=100:raise FixtureUnsafe('bad lab round bound')
    ids=[a.actor_id for a in roster]
    if len(set(ids))!=len(ids):raise FixtureUnsafe('Duplicate actor identity')
    if len({a.team for a in roster})!=2:raise FixtureUnsafe('Exact 2 teams for this benchmark')
    identities=sorted((a.actor_id,a.kind,a.rank,a.star,a.health,str(a.ca),a.rd,a.attack_bonus,a.attack_dice,a.damage_dice,a.damage_fixed) for a in roster)
    grouping=sorted(tuple(sorted(a.actor_id for a in roster if a.team==t)) for t in {a.team for a in roster})
    case=digest({'ids':identities,'teams':grouping,'profile':PROFILE,'version':VERSION})[:20]
    actor={x.actor_id:x for x in roster}
    hp={x.actor_id:x.health for x in roster}
    init_draw={}
    for a in roster:
        d,values,_=roll_expr(a.attack_dice,seed,case,f'INIT:{a.actor_id}')
        init_draw[a.actor_id]={'dice':values,'score':d+a.stats['DES']}
    # Lab-only tiebreak: stable draw keyed actor identity, never A/B label.
    tie={x:dice_for(seed,case,f'INIT-TIE:{x}',100000)[0] for x in ids}
    order=sorted(ids,key=lambda i:(-init_draw[i]['score'],-tie[i],i))
    events=[];complete=False;winner=None;rounds=0;stop_reason='MAX-ROUNDS-CENSORED'
    # Observed last damage is a LAB perception proxy from prior visible events;
    # not reading the opponent's unseen build or future rolls.
    observed_damage={x.actor_id:None for x in roster}
    for rnd in range(1,max_rounds+1):
        rounds=rnd
        # Determine impossible-to-damage states BEFORE wasting 30 rounds.
        # This is a submodel diagnostic, never a canonical draw or victory.
        alive_actors=[x for x in roster if hp[x.actor_id]>0]
        legal_effect_possible=any(highest_possible_basic_hit(x,y,rd_mode)
             for x in alive_actors for y in alive_actors if x.team!=y.team)
        if not legal_effect_possible:
            stop_reason='STALEMATE-NO-EFFECTIVE-BASIC-ATTACK';break
        for actor_id in order:
            a=actor[actor_id]
            if hp[actor_id]<=0:continue
            enemies=[x for x in roster if x.team!=a.team and hp[x.actor_id]>0]
            if not enemies:continue
            visible=VisibleContext(a.actor_id,hp[a.actor_id]/a.health,1,enemy_count_visible=len(enemies),
                    friendly_count_visible=sum(hp[x.actor_id]>0 for x in roster if x.team==a.team),
                    observation_mode='LAB-ASSUMPTION')
            prior_positive=[observed_damage[x.actor_id] for x in enemies if observed_damage[x.actor_id] is not None and observed_damage[x.actor_id]>0]
            lo=min(prior_positive) if prior_positive else None
            hi=max(prior_positive) if prior_positive else None
            def visible_threat(enemy_id):
                dmg=observed_damage[enemy_id]
                if dmg is None or lo is None or hi is None or hi==lo:return 'unknown'
                if dmg>=hi:return 'high'
                if dmg<=lo:return 'low'
                return 'medium'
            options=tuple(SourcedOption(action_id=f'{a.actor_id}:basic_attack:{x.actor_id}',kind='attack',
                    source_ref=ED_WEAPON_REF if a.kind=='ED' else BEAST_DAMAGE_REF,target_id=x.actor_id,
                    target_injury=('critical' if hp[x.actor_id]/x.health<=.30 else
                                   'injured' if hp[x.actor_id]/x.health<=.70 else 'normal'),
                    target_threat=visible_threat(x.actor_id),
                    verified_legal=True,rule_status='LAB-ASSUMPTION') for x in enemies)
            decision=choose_action(a.doctrine,visible,options)
            t=actor[decision.target_id]
            attack,attack_draws,_=roll_expr(a.attack_dice,seed,case,f'R:{rnd}:ATTACK:{a.actor_id}')
            score=attack+a.attack_bonus
            cd,crit_draws,_=roll_expr('3d6',seed,case,f'R:{rnd}:CRIT:{a.actor_id}')
            crit_status=('CRIT' if tuple(crit_draws[0:2])==(6,6) and crit_draws[2]>=5
                         else 'CRIT-FAIL-NO-EFFECT-LAB' if tuple(crit_draws[0:2])==(1,1) and crit_draws[2]<=2 else 'NORMAL')
            success=Fraction(score)>t.ca or crit_status=='CRIT' # R50 automatic hit in TEST copy
            raw=0;damage_rolls=();after_defense=0
            if success:
                rolled,damage_rolls,maxval=roll_expr(a.damage_dice,seed,case,f'R:{rnd}:DMG:{a.actor_id}')
                raw=rolled+a.damage_fixed+(maxval if crit_status=='CRIT' else 0)
                after_defense=max(0,raw-(t.rd or 0)) if rd_mode=='SUBTRACT-LAB' else raw
            before=hp[t.actor_id]
            hp[t.actor_id]=max(0,before-after_defense)
            if success:observed_damage[a.actor_id]=after_defense
            events.append({'round':rnd,'actor_id':a.actor_id,'target_id':t.actor_id,
                 'source_kind':a.kind,'action_id':decision.action_id,'style':a.doctrine.style,
                 'tier':a.doctrine.cognitive_tier,'policy_version':decision.version,
                 'attack_draws':attack_draws,'attack_score':score,'CA_exact':str(t.ca),
                 'hit':success,'crit_rolls':crit_draws,'crit_status':crit_status,
                 'damage_rolls':damage_rolls,'damage_raw':raw,'target_rd':t.rd,
                 'rd_mode':rd_mode,'damage_net':after_defense,
                 'before_hp':before,'after_hp':hp[t.actor_id],
                 'explanation':decision.reasons})
            alive={x.team for x in roster if hp[x.actor_id]>0}
            if len(alive)==1:
                winner=next(iter(alive));complete=True;stop_reason='LAB-HP-THRESHOLD';break
        if complete:break
    result={'version':VERSION,'mode':'CONDITIONAL-SENSITIVITY-NOT-CANONICAL',
      'seed':seed,'case_id':case,'profile':PROFILE,'rd_mode':rd_mode,
      'teams':{team:sorted(x.actor_id for x in roster if x.team==team) for team in sorted({x.team for x in roster})},
      'initiatives':init_draw,'init_tie':tie,'turn_order':order,'HP':hp,'events':events,
      'event_count':len(events),'rounds':rounds,'winner_by_lab_hp_threshold':winner,
      'winner_actor_ids':sorted(x.actor_id for x in roster if x.team==winner) if winner else [],
      'complete':complete,'stop_reason':stop_reason,
      'source_refs':SOURCE_REFS,'lab_assumptions':LAB_ASSUMPTIONS,
      'can_credit_official_core':False,'canonical_rank_reclassification_allowed':False,
      'source_fully_eligible':False}
    result['trace_digest']=digest({k:v for k,v in result.items() if k!='teams' and k!='winner_by_lab_hp_threshold'})
    result['digest']=digest(result)
    return result

def mirror(roster,seed,rd_mode='SUBTRACT-LAB'):
    if len({x.team for x in roster})!=2:raise FixtureUnsafe('two sides')
    a,b=sorted({x.team for x in roster})
    from dataclasses import replace
    swapped=tuple(replace(x,team=b if x.team==a else a) for x in roster)
    x=run(roster,seed,rd_mode=rd_mode);y=run(swapped,seed,rd_mode=rd_mode)
    # event logs have no team labels, so exact event trace should be identical.
    return {'same_events':x['events']==y['events'], 'same_hp':x['HP']==y['HP'],
            'same_initiative':x['initiatives']==y['initiatives'],
            'same_winner_actors':x['winner_actor_ids']==y['winner_actor_ids'],
            'same_trace_digest':x['trace_digest']==y['trace_digest'],
            'side_winner_inverted': x['winner_by_lab_hp_threshold']!=y['winner_by_lab_hp_threshold'] if x['complete'] else y['winner_by_lab_hp_threshold'] is None,
            'original':x,'swapped':y}

def sample_rosters():
    a=build_human('Bronze',1,101)
    b=build_human('Bronze',1,202,priority=('CON','DES','FOR','SAB','INT','CAR'))
    beast=build_beast('Bronze',1,303)
    return (make_actor(a,'A'),make_actor(beast,'B')),(
        make_actor(a,'A'),make_actor(b,'A'),make_actor(beast,'B'))

if __name__=='__main__':
    for roster in sample_rosters():
        for rd in ('SUBTRACT-LAB','OFF-LAB'):
            r=run(roster,101,rd_mode=rd)
            print(json.dumps({'roster_size':len(roster),'seed':101,'rd_mode':rd,
              'result':r['winner_by_lab_hp_threshold'],'rounds':r['rounds'],
              'events':r['event_count'],'hp':r['HP'],'digest':r['digest']},ensure_ascii=False))
