"""Retrospective diagnostic on v0.4, never modifies original campaign/ledger.
Samples complete conditional runs, explicitly counts blocked/censored selection.
"""
from __future__ import annotations
import copy, json, math
from collections import Counter
from vlab_l05_duel import build_sample_fixture, execute_duel
from vlab_l05_team import sample_team_roster, run_team, TeamNotEligible
from vlab_l05_preflight import RulesUnresolved

def wilson(k,n,z=1.959963984540054):
    if not n:return None
    p=k/n; c=(p+z*z/(2*n))/(1+z*z/n);r=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/(1+z*z/n)
    return [round(c-r,4),round(c+r,4)]

def audit(n=1500):
    f1,f2=build_sample_fixture()
    mirrored=[]
    for position in ('original','swapped'):
        a,b=copy.deepcopy((f1,f2))
        if position=='swapped':a['side'],b['side']='B','A'
        counts=Counter();actor_win=Counter();actor_side=Counter()
        for seed in range(1,n+1):
            try:run=execute_duel((a,b),seed=seed,max_rounds=30)
            except RulesUnresolved as e:
                if 'TIED-INITIATIVE' in str(e):counts['blocked_tie']+=1
                elif 'CRITICAL-FAIL' in str(e):counts['blocked_critfail']+=1
                else:counts['blocked_other']+=1
                continue
            winner=run['winner_by_lab_stop_condition']
            if not winner:counts['censored']+=1;continue
            counts['completed']+=1
            counts['win_side_'+winner]+=1
            actor=next(x for x in (a,b) if x['side']==winner)
            actor_win[actor['actor_id']]+=1
            actor_side[actor['actor_id']]=actor['side']
        k=counts['win_side_A'];d=counts['completed']
        f1win=actor_win[f1['actor_id']]
        mirrored.append({'orientation':position,'attempted':n,'counts':dict(counts),
                         'P_win_A_completed':round(k/d,4) if d else None,'CI95_win_A_completed':wilson(k,d),
                         'actor1_win_completed':f1win,'P_actor1_win_completed':round(f1win/d,4) if d else None,
                         'actor1_slot':'A' if position=='original' else 'B',
                         'pairing_quality':'NOT-CRN: fixture hash & RNG keys depend on side, so same seed is not a true matched random stream'} )
    # Symmetric specs, independent IDs. Equal talents, policies, and equips; but side is still used to seed streams.
    symmetrical=[]
    base=copy.deepcopy(f1)
    for side_order in ('identical-original','identical-slot-reversed'):
        a,b=copy.deepcopy(base),copy.deepcopy(base)
        b['actor_id']='IDENTICAL-ACTOR-CLONE-UNIQUE-ID'
        a['side'],b['side']=('A','B') if side_order=='identical-original' else ('B','A')
        c=Counter()
        for seed in range(1,n+1):
            try:r=execute_duel((a,b),seed=seed,max_rounds=30)
            except RulesUnresolved as e:
                if 'TIED-INITIATIVE' in str(e):c['blocked_tie']+=1
                elif 'CRITICAL-FAIL' in str(e):c['blocked_critfail']+=1
                else:c['blocked_other']+=1
                continue
            winner=r['winner_by_lab_stop_condition']
            if winner:c['completed']+=1;c['win_'+winner]+=1
            else:c['censored']+=1
        k=c['win_A'];d=c['completed']
        symmetrical.append({'orientation':side_order,'counts':dict(c),'P_win_A_completed':round(k/d,4) if d else None,'CI95':wilson(k,d),'attempted':n})
    # structural proof that asymmetric scheduler cannot swap two-actor team to B.
    team_reversal={'attempted':True}
    try:
        original=sample_team_roster()
        swapped=[]
        for r in original:
            x=copy.deepcopy(r)
            x['side']={'A1':'B1','A2':'B2','B1':'A1'}[x['side']]
            swapped.append(x)
        run_team(tuple(swapped),seed=2)
        team_reversal['supported']=True
    except (TeamNotEligible,RulesUnresolved) as e:
        team_reversal.update({'supported':False,'error_type':type(e).__name__,'error':str(e)})
    return {'protocol':'FAIR-AUDIT-READONLY-V01','n_seeds_each':n,'original_duel':mirrored,'identical_twins':symmetrical,
            'team_2x1_reverse_benchmark':team_reversal,'core_grid_credit':0,
            'limitations':['success rates computed conditional on non-blocked runs; fail-closed events are not ignorable missing completely at random',
                           'different seed/path for reversed side; a true A/B paired fixture and stream independence need new kernel',
                           'one sample seed is not representative of win rate or tactical quality',
                           'runs exclude tactical decisions, defense reactions, spells, movement and Bestas']}
if __name__=='__main__':print(json.dumps(audit(),ensure_ascii=False,indent=2))
