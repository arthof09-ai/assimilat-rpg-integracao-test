"""Damage reduction — Mestre's 2026-10-08 clarification implemented as a LAB adapter.

General RD reduces damage regardless of matching physical kind; tagged RD acts
ONLY when damage type matches. This is an interpretation approved *verbally by
Mestre* but normative Notion modification remains gated by NAC-NORM/NAC-PASS.
Composite hits, stack of general+specific, bypass are never silently inferred.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

VERSION='RD-MASTER-DIRECTION-PENDING-NORM-v0.8'
VALID_TAGS=frozenset(('perfurante','cortante','impacto','contundente','concussão','concussao','fogo','agua','gelo','vento','terra','raio','caos','dark','luz','planta','espectral','normal','veneno','toxina','psíquico','necrótico','radiante','ácido','alma','essência'))
# Only the *explicit* shared physical family in DMG-RANK v1.1 §21.1 is
# normalized for matching. Elemental/legacy nicknames MUST NOT be inferred.
PHYSICAL_FAMILY={'impacto':'impacto','contundente':'impacto','concussão':'impacto','concussao':'impacto'}
def rd_match_tag(tag:str)->str:return PHYSICAL_FAMILY.get(tag,tag)
class RDUnresolved(ValueError): pass

@dataclass(frozen=True)
class Resistances:
    general: int=0
    specific: tuple[tuple[str,int],...]=()
    provenance: str='MASTER-2026-10-08'
    def __post_init__(self):
        if isinstance(self.general,bool) or not isinstance(self.general,int) or self.general<0:
            raise RDUnresolved('invalid general RD')
        seen=set()
        for tag,value in self.specific:
            if tag not in VALID_TAGS:raise RDUnresolved('unrecognized damage tag')
            norm=rd_match_tag(tag)
            if norm in seen:raise RDUnresolved('duplicate damage-specific RD entry')
            if isinstance(value,bool) or not isinstance(value,int) or value<0:raise RDUnresolved('bad specific RD')
            seen.add(norm)

@dataclass(frozen=True)
class DamageComponent:
    amount:int
    tag:str
    source:str
    def __post_init__(self):
        if isinstance(self.amount,bool) or not isinstance(self.amount,int) or self.amount<0:raise RDUnresolved('damage cannot be negative')
        if self.tag not in VALID_TAGS:raise RDUnresolved('damage type not certified')
        if not self.source:raise RDUnresolved('damage requires source')

@dataclass(frozen=True)
class DamageOutcome:
    gross:int
    applicable_rd:int
    effective:int
    tag:str
    rd_origin:str
    rule_status:str=VERSION


def mitigate(components:tuple[DamageComponent,...], rd:Resistances, *,
             stacking:Literal['STRICT','LAB-MAX','LAB-ADD']='STRICT',
             bypass:bool=False)->DamageOutcome:
    if not components:raise RDUnresolved('empty damage event')
    if bypass:raise RDUnresolved('RD bypass is effect-specific and unresolved')
    if len(components)!=1:raise RDUnresolved('mixed damage components need authoritative per-instance distribution')
    c=components[0]
    spec={rd_match_tag(tag):value for tag,value in rd.specific}
    specific=spec.get(rd_match_tag(c.tag),0)
    general=rd.general
    if general and specific:
        if stacking=='STRICT':raise RDUnresolved('general + matching specific RD stacking has no current ruling')
        if stacking=='LAB-MAX':amount=max(general,specific)
        elif stacking=='LAB-ADD':amount=general+specific
        else:raise RDUnresolved('unknown lab stacking')
        origin='LAB-STACK-'+stacking
    else:
        amount=general if general else specific
        origin=('GENERAL' if general else ('TYPE-'+c.tag if specific else 'NONE'))
    return DamageOutcome(c.amount,amount,max(0,c.amount-amount),c.tag,origin)


def possible_basic_hit(attack_dice_count:int,faces:int,attack_bonus:int,ca_exact,
                       max_damage:int,damage_tag:str,rd:Resistances)->bool:
    """A diagnostic for a FIXED unmodified basic attack; never a canonical fight result."""
    from fractions import Fraction
    if isinstance(attack_dice_count,bool) or attack_dice_count<=0 or faces<2:raise ValueError('invalid dice')
    if not attack_dice_count*faces+attack_bonus > Fraction(ca_exact):return False
    return mitigate((DamageComponent(max_damage,damage_tag,'source-fixed-basic'),),rd).effective>0
