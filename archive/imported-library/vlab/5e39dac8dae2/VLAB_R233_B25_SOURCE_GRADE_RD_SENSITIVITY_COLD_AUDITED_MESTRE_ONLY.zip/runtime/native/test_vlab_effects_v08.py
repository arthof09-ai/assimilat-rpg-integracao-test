import unittest
from fractions import Fraction
from copy import deepcopy
from hashlib import sha256
from vlab_rd_v08 import Resistances,RDUnresolved
from vlab_effects_v08 import *

PAGES={'combat':COMBAT_PAGE,'magic':MAGIC_PAGE,'transform':TRANSFORM_PAGE}
def evidence(page,rule):return FrozenRuleEvidence(page,rule,sha256(f'NOTION-EXCERPT|{page}|{rule}'.encode()).hexdigest(),'2026-10-08','MOCK-UNIT-EXAMPLE-NOT-A-PHYSICAL-AUDIT')
# test-mock evidence is deliberately not valid authority for real fights.
def new_scene():return Scene({'a':Combatant('a',100,150,Fraction(10),5,0,2,3,'B1',spirit_id='spirit-source'), 'b':Combatant('b',80,50,Fraction(12),4,0,0,2,'B2')})
def source(kind='attack',economy='STANDARD',page=COMBAT_PAGE,rule='attack',cost=0,scope='ENEMY',trigger=None):
    return AbilitySource('test-'+rule,kind,economy,page,rule,'EXPLICIT-CANON',required_pa=cost,target_scope=scope,reaction_trigger=trigger,effect_adapter_ready=True,effect_adapter_id='V08-ADAPTER')
def state(kind='attack',pa=150,known=('test-attack',),actor='a',enemies=('b',),standard=True,movement=True,reaction=True,free=False,range_ok=True,geometry=True):
    return ActorActionState(actor,1,pa,known,standard_available=standard,movement_available=movement,reaction_available=reaction,free_action_contract_ready=free,enemy_ids_visible=enemies,range_confirmed=range_ok,los_confirmed=True,geometry_confirmed=geometry,environment_contract=geometry)
def reaction_args():
    src=source('reaction','REACTION',COMBAT_PAGE,'reaction',0,'SELF',trigger='BEFORE-ATTACK')
    st=ActorActionState('a',1,150,('test-reaction',),reaction_trigger_observed='BEFORE-ATTACK')
    return dict(trigger_source='BEFORE-ATTACK',source=src,state=st,proofs=(evidence(COMBAT_PAGE,'reaction'),))
class TestEffects(unittest.TestCase):
    def test_hit_RD_and_log(self):
        sc=new_scene();src=source();result=apply_weapon_attack(sc,'a','b',source=src,state=state(),proofs=(evidence(COMBAT_PAGE,'attack'),),roll_score=13,damage=70,damage_tag='perfurante',rd=Resistances(general=50));self.assertEqual((sc.actors['b'].hp,result['net']), (60,20));self.assertEqual(sc.actors['a'].standard,0)
    def test_miss_doesnt_reduce(self):
        sc=new_scene();src=source();r=apply_weapon_attack(sc,'a','b',source=src,state=state(),proofs=(evidence(COMBAT_PAGE,'attack'),),roll_score=12,damage=70,damage_tag='perfurante',rd=Resistances(general=50));self.assertFalse(r['hit']);self.assertEqual(sc.actors['b'].hp,80)
    def test_second_standard_blocked(self):
        sc=new_scene();src=source();proof=(evidence(COMBAT_PAGE,'attack'),)
        apply_weapon_attack(sc,'a','b',source=src,state=state(),proofs=proof,roll_score=13,damage=6,damage_tag='perfurante',rd=Resistances())
        with self.assertRaises(EffectBlocked):apply_weapon_attack(sc,'a','b',source=src,state=state(),proofs=proof,roll_score=13,damage=6,damage_tag='perfurante',rd=Resistances())
    def test_unfrozen_source_blocked_without_mutation(self):
        sc=new_scene();src=source();before=deepcopy(sc)
        with self.assertRaises(EffectBlocked):apply_weapon_attack(sc,'a','b',source=src,state=state(),proofs=(),roll_score=13,damage=6,damage_tag='perfurante',rd=Resistances())
        self.assertEqual(asdict(before.actors['b']),asdict(sc.actors['b']));self.assertEqual(sc.events,[])
    def test_missing_rd_stack_no_mutation(self):
        sc=new_scene();src=source()
        with self.assertRaises(RDUnresolved):apply_weapon_attack(sc,'a','b',source=src,state=state(),proofs=(evidence(COMBAT_PAGE,'attack'),),roll_score=13,damage=70,damage_tag='perfurante',rd=Resistances(10,(('perfurante',20),)))
        self.assertEqual((sc.actors['a'].standard,sc.actors['b'].hp,len(sc.events)),(1,80,0))
    def test_defender_success(self):
        sc=new_scene();r=react_defensively(sc,'a',kind='DEFENDER',attack_score=13,announced_before=True,**reaction_args());self.assertTrue(r['damage_negated']);self.assertEqual(sc.actors['a'].reaction,0)
    def test_defender_failure(self):
        sc=new_scene();r=react_defensively(sc,'a',kind='DEFENDER',attack_score=15,announced_before=True,**reaction_args());self.assertFalse(r['damage_negated'])
    def test_esquivar_exact(self):
        sc=new_scene();r=react_defensively(sc,'a',kind='ESQUIVAR',attack_score=13,announced_before=True,**reaction_args());self.assertTrue(r['damage_negated'])
    def test_reaction_timing_blocked(self):
        sc=new_scene()
        with self.assertRaises(EffectBlocked):react_defensively(sc,'a',kind='DEFENDER',attack_score=13,announced_before=False,**reaction_args())
        self.assertEqual(sc.actors['a'].reaction,1)
    def test_reaction_single_use(self):
        sc=new_scene();react_defensively(sc,'a',kind='DEFENDER',attack_score=15,announced_before=True,**reaction_args())
        with self.assertRaises(EffectBlocked):react_defensively(sc,'a',kind='ESQUIVAR',attack_score=15,announced_before=True,**reaction_args())
    def test_move_verified(self):
        sc=new_scene();spec=source('move','MOVEMENT',rule='movement',scope='POSITION');st=state(known=('test-movement',))
        r=move_via_verified_path(sc,'a',source=spec,state=st,proofs=(evidence(COMBAT_PAGE,'movement'),),destination='B3',path_evidence='LAB-PATH-SYNTHETIC',travel_cost=Fraction(2),speed=Fraction(4))
        self.assertEqual((sc.actors['a'].position,sc.actors['a'].movement),('B3',0))
    def test_move_unverified_blocked(self):
        sc=new_scene();spec=source('move','MOVEMENT',rule='movement',scope='POSITION');st=state(known=('test-movement',))
        with self.assertRaises(EffectBlocked):move_via_verified_path(sc,'a',source=spec,state=st,proofs=(evidence(COMBAT_PAGE,'movement'),),destination='B3',path_evidence='',travel_cost=Fraction(2),speed=Fraction(4))
        self.assertEqual(sc.actors['a'].position,'B1')
    def test_move_out_of_speed(self):
        sc=new_scene();spec=source('move','MOVEMENT',rule='movement',scope='POSITION');st=state(known=('test-movement',))
        with self.assertRaises(EffectBlocked):move_via_verified_path(sc,'a',source=spec,state=st,proofs=(evidence(COMBAT_PAGE,'movement'),),destination='B3',path_evidence='path',travel_cost=Fraction(6),speed=Fraction(4))
    def test_spell_basic_damage_type(self):
        sc=new_scene();src=source('spell','STANDARD',MAGIC_PAGE,'spell',20)
        st=state(known=('test-spell',));r=cast_source_specified_spell(sc,'a','b',source=src,state=st,proofs=(evidence(MAGIC_PAGE,'spell'),),damage=70,damage_tag='fogo',rd=Resistances(specific=(('perfurante',50),)))
        self.assertEqual((r['effective'],sc.actors['a'].pa,sc.actors['b'].hp),(70,130,10));self.assertEqual(r['critical'],'NOT-APPLICABLE-BY-SISTEMA-DE-MAGIA')
    def test_spell_save_full_negate(self):
        sc=new_scene();src=source('spell','STANDARD',MAGIC_PAGE,'spell',20)
        st=state(known=('test-spell',));r=cast_source_specified_spell(sc,'a','b',source=src,state=st,proofs=(evidence(MAGIC_PAGE,'spell'),),damage=70,damage_tag='fogo',rd=Resistances(),explicit_save_effect='SAVE-FULL-NEGATE',target_save_exceeds_cd=True)
        self.assertEqual(sc.actors['b'].hp,80);self.assertEqual(sc.actors['a'].pa,130)
    def test_spell_half_rounding_blocked(self):
        sc=new_scene();src=source('spell','STANDARD',MAGIC_PAGE,'spell',20);st=state(known=('test-spell',))
        with self.assertRaises(EffectBlocked):cast_source_specified_spell(sc,'a','b',source=src,state=st,proofs=(evidence(MAGIC_PAGE,'spell'),),damage=71,damage_tag='fogo',rd=Resistances(),explicit_save_effect='SAVE-HALF',target_save_exceeds_cd=True)
        self.assertEqual((sc.actors['b'].hp,sc.actors['a'].pa,sc.events),(80,150,[]))
    def test_magic_insufficient_pa(self):
        sc=new_scene();sc.actors['a'].pa=5;src=source('spell','STANDARD',MAGIC_PAGE,'spell',20);st=state(known=('test-spell',))
        with self.assertRaises(EffectBlocked):cast_source_specified_spell(sc,'a','b',source=src,state=st,proofs=(evidence(MAGIC_PAGE,'spell'),),damage=30,damage_tag='fogo',rd=Resistances())
    def test_transform_no_spirit_blocked(self):
        sc=new_scene();sc.actors['a'].spirit_id=None;spec=source('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF')
        with self.assertRaises(EffectBlocked):activate_transformation(sc,'a',source=spec,state=state(known=('test-T9',)),proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=self.spirit(),ordinal_level=1,duration_die_roll=2,compatible=False,full_reaction_policy='LAB-CONSUME')
    @staticmethod
    def spirit():return AssimilatedSpirit('spirit-source',8,Fraction(8),{'FOR':4,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0},{'CA':13,'FF':'LOCKED'},'LAB-EXAMPLE-SOURCE')
    def test_transform_tap_fraction_carry(self):
        z=AssimilatedSpirit('source',8,Fraction(11),{'FOR':5,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0},{'CA':12},'unit')
        self.assertEqual(transformed_budget(1,z),(1,5,Fraction(1,2)))
        self.assertEqual(transformed_budget(3,z),(3,16,Fraction(1,2)))
    def test_transform_happy(self):
        sc=new_scene();spec=source('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF');st=state(known=('test-T9',))
        r=activate_transformation(sc,'a',source=spec,state=st,proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=self.spirit(),ordinal_level=1,duration_die_roll=3,compatible=True,full_reaction_policy='LAB-CONSUME')
        self.assertEqual((sc.actors['a'].pa,sc.actors['a'].mode,sc.actors['a'].transformation_remaining,sc.actors['a'].reaction),(130,'TRANSFORMED',5,0))
        self.assertEqual(r['TAP'],'4')
    def test_transform_no_reaction_policy_blocked(self):
        sc=new_scene();spec=source('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF');st=state(known=('test-T9',))
        with self.assertRaises(EffectBlocked):activate_transformation(sc,'a',source=spec,state=st,proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=self.spirit(),ordinal_level=1,duration_die_roll=3,compatible=False)
        self.assertEqual(sc.actors['a'].pa,150)
    def test_transform_overlay_checksum(self):
        sc=new_scene();spec=source('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF');st=state(known=('test-T9',));bad=AssimilatedSpirit('spirit-source',8,Fraction(8),{'FOR':5,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0},{'CA':13},'unit')
        with self.assertRaises(EffectBlocked):activate_transformation(sc,'a',source=spec,state=st,proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=bad,ordinal_level=1,duration_die_roll=3,compatible=False,full_reaction_policy='LAB-CONSUME')
    def test_transform_insufficient_pa(self):
        sc=new_scene();sc.actors['a'].pa=4;spec=source('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF');st=state(known=('test-T9',))
        with self.assertRaises(EffectBlocked):activate_transformation(sc,'a',source=spec,state=st,proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=self.spirit(),ordinal_level=1,duration_die_roll=3,compatible=False,full_reaction_policy='LAB-CONSUME')
    def test_transform_spirit_cap(self):
        x=AssimilatedSpirit('source',2,Fraction(8),{'FOR':8,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0},{'CA':12},'unit')
        self.assertEqual(transformed_budget(13,x),(2,8,Fraction(0)))
    def test_transformed_does_not_write_normal(self):
        sc=new_scene();spec=source('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF');st=state(known=('test-T9',));ca_before=sc.actors['a'].ca
        activate_transformation(sc,'a',source=spec,state=st,proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=self.spirit(),ordinal_level=1,duration_die_roll=3,compatible=False,full_reaction_policy='LAB-CONSUME')
        self.assertEqual(sc.actors['a'].ca,ca_before)
if __name__=='__main__':unittest.main()

class TestEffectIntegration(unittest.TestCase):
    def test_defender_negates_hit_in_attack_pipeline(self):
        sc=new_scene();sc.actors['b'].constitution=10;sc.actors['b'].fortitude=4
        spec=source('reaction','REACTION',COMBAT_PAGE,'reaction',0,'SELF',trigger='BEFORE-ATTACK')
        st=ActorActionState('b',1,50,('test-reaction',),reaction_trigger_observed='BEFORE-ATTACK')
        defense=react_defensively(sc,'b',kind='DEFENDER',attack_score=15,announced_before=True,trigger_source='BEFORE-ATTACK',source=spec,state=st,proofs=(evidence(COMBAT_PAGE,'reaction'),))
        attack=apply_weapon_attack(sc,'a','b',source=source(),state=state(),proofs=(evidence(COMBAT_PAGE,'attack'),),roll_score=15,damage=70,damage_tag='perfurante',rd=Resistances(general=50),defense_event=defense)
        self.assertTrue(attack['hit']);self.assertTrue(attack['defense_negated']);self.assertEqual((attack['net'],sc.actors['b'].hp),(0,80))
    def test_no_double_use_of_defense_packet(self):
        sc=new_scene();sc.actors['b'].constitution=10;sc.actors['b'].fortitude=4
        spec=source('reaction','REACTION',COMBAT_PAGE,'reaction',0,'SELF',trigger='BEFORE-ATTACK')
        st=ActorActionState('b',1,50,('test-reaction',),reaction_trigger_observed='BEFORE-ATTACK')
        e=react_defensively(sc,'b',kind='DEFENDER',attack_score=15,announced_before=True,trigger_source='BEFORE-ATTACK',source=spec,state=st,proofs=(evidence(COMBAT_PAGE,'reaction'),))
        attackargs=dict(source=source(),state=state(),proofs=(evidence(COMBAT_PAGE,'attack'),),roll_score=15,damage=70,damage_tag='perfurante',rd=Resistances(),defense_event=e)
        apply_weapon_attack(sc,'a','b',**attackargs)
        sc.actors['a'].standard=1
        with self.assertRaises(EffectBlocked):apply_weapon_attack(sc,'a','b',**attackargs)

class TestFiveRankTransformation(unittest.TestCase):
    def test_all_rank_activation_cost_and_action(self):
        lv={'Bronze':1,'Prata':6,'Ouro':11,'Ouro Negro':16,'Lendário':21}
        for rank,n in lv.items():
            with self.subTest(rank=rank):
                cost,econ,die,plus=TRANS_COST[rank]
                scene=Scene({'a':Combatant('a',999,1000,Fraction(10),5,0,2,3,'B1',rank=rank,spirit_id='spirit')})
                overlay={'FOR':4*n,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0}
                spirit=AssimilatedSpirit('spirit',25,Fraction(8),overlay,{'CA':99,'CON':9,'Fortitude':0,'Reflexo':0,'Armadura':0},'LAB-MOCK')
                spec=source('transform',econ,TRANSFORM_PAGE,'T9',cost,'SELF')
                st=ActorActionState('a',n,1000,('test-T9',),free_action_contract_ready=(econ=='FREE'))
                result=activate_transformation(scene,'a',source=spec,state=st,proofs=(evidence(TRANSFORM_PAGE,'T9'),),spirit=spirit,ordinal_level=n,duration_die_roll=1,compatible=False,full_reaction_policy='LAB-CONSUME')
                self.assertEqual(scene.actors['a'].pa,1000-cost)
                self.assertEqual(result['duration_total'],1+plus)
                if econ=='FULL':self.assertEqual((scene.actors['a'].standard,scene.actors['a'].movement,scene.actors['a'].reaction),(0,0,0))
                elif econ=='STANDARD':self.assertEqual(scene.actors['a'].standard,0)
                elif econ=='MOVEMENT':self.assertEqual(scene.actors['a'].movement,0)
                elif econ=='FREE':self.assertEqual((scene.actors['a'].standard,scene.actors['a'].movement),(1,1))
