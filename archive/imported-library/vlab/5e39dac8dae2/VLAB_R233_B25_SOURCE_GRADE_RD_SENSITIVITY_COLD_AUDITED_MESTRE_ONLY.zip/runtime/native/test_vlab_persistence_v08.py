import unittest
from fractions import Fraction
from vlab_persistence_v08 import persist_basic_attacks,PersistenceError
class TestPersist(unittest.TestCase):
    def test_orc_beast_ceiling_never_hit(self):
        r=persist_basic_attacks(attacker_id='beast',defender_id='orc',seed=8,dice_count=1,dice_faces=6,bonus=14,ca=Fraction(93,4),max_attempts=50)
        self.assertFalse(r['basic_hit_possible']);self.assertEqual(r['attempts'],50);self.assertEqual(r['outcome'],'LAB-NO-HIT-POTENTIAL-BOUNDED-ATTEMPTS');self.assertTrue(all(not x['hit'] for x in r['events']))
    def test_other_side_ceiling_never_hit(self):
        r=persist_basic_attacks(attacker_id='orc',defender_id='beast',seed=8,dice_count=1,dice_faces=6,bonus=12,ca=Fraction(93,5),max_attempts=50)
        self.assertFalse(r['basic_hit_possible']);self.assertEqual(r['attempts'],50)
    def test_possible_hit_not_guaranteed(self):
        r=persist_basic_attacks(attacker_id='a',defender_id='b',seed=7,dice_count=1,dice_faces=6,bonus=10,ca=Fraction(14),max_attempts=10)
        self.assertTrue(r['basic_hit_possible']);self.assertIn(r['outcome'],('LAB-FIRST-HIT-FOUND','LAB-CENSORED-WITH-POTENTIAL'))
    def test_deterministic_replay(self):
        x=dict(attacker_id='a',defender_id='b',seed=6,dice_count=1,dice_faces=6,bonus=11,ca=Fraction(15),max_attempts=11)
        self.assertEqual(persist_basic_attacks(**x),persist_basic_attacks(**x))
    def test_bound_hardcap(self):
        with self.assertRaises(PersistenceError):persist_basic_attacks(attacker_id='a',defender_id='b',seed=1,dice_count=1,dice_faces=6,bonus=0,ca=Fraction(20),max_attempts=1001)
    def test_same_actor_invalid(self):
        with self.assertRaises(PersistenceError):persist_basic_attacks(attacker_id='a',defender_id='a',seed=1,dice_count=1,dice_faces=6,bonus=0,ca=Fraction(20),max_attempts=10)
    def test_no_canon_winner(self):
        r=persist_basic_attacks(attacker_id='a',defender_id='b',seed=2,dice_count=1,dice_faces=6,bonus=14,ca=Fraction(30),max_attempts=3)
        self.assertFalse(r['canon_outcome']);self.assertFalse(r['full_fight'])
if __name__=='__main__':unittest.main()
