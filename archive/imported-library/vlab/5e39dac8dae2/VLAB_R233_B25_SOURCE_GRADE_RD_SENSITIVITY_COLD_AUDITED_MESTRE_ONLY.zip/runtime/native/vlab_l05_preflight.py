"""L05 restricted combat preflight utilities, NOT a full-fight motor.

Only enforces rules the Notion Sistema de Combate explicitly establishes;
ambiguous simultaneous reactions and geometry fail closed.
"""
from dataclasses import dataclass
from typing import Literal
from vlab_l04 import ActorSnapshot

class RulesUnresolved(Exception):
    pass
class IllegalAction(Exception):
    pass

@dataclass
class ActionBudget:
    standard:int=1
    movement:int=1
    reaction:int=1
    def spend(self,kind:Literal['STANDARD','MOVEMENT','REACTION','COMPLETE'],*,complete_reaction_override:bool|None=None)->None:
        if kind=='COMPLETE':
            # Current source says complete normally consumes reaction; source-specific exceptions must be explicit.
            if complete_reaction_override is None:
                raise RulesUnresolved('Action Completa reaction cost uses "normally"; bind source-specific reaction cost')
            if self.standard<1 or self.movement<1 or (complete_reaction_override and self.reaction<1):
                raise IllegalAction('Not enough actions for Action Completa')
            self.standard-=1;self.movement-=1
            if complete_reaction_override:self.reaction-=1
        else:
            prop={'STANDARD':'standard','MOVEMENT':'movement','REACTION':'reaction'}.get(kind)
            if prop is None:raise IllegalAction('Unknown action kind')
            if getattr(self,prop)<1:raise IllegalAction('Insufficient action budget')
            setattr(self,prop,getattr(self,prop)-1)

def defensive_reaction(budget:ActionBudget,*,attack_declared:bool,reaction_kind:str)->str:
    """Consumes precisely one available reaction before attack resolution."""
    allowed={'CONTRA_ATACAR','DEFENDER','ESQUIVAR','REFLETIR_MAGIA'}
    if reaction_kind not in allowed:raise IllegalAction('Not an authorized defensive reaction')
    if not attack_declared:raise IllegalAction('Cannot retroactively declare defense')
    budget.spend('REACTION')
    return reaction_kind

def determine_attack_success(attack_score:int|float,defense_score:int|float)->bool:
    # Source: attack result must strictly exceed target defense.
    return attack_score>defense_score

def classify_critical_sequence(rolls:tuple[int,int,int])->str:
    """Three sequential d6 results, no margin bonus and no simultaneous rolling."""
    if len(rolls)!=3 or any(not isinstance(v,int) or isinstance(v,bool) or not 1<=v<=6 for v in rolls):
        raise IllegalAction('Critical check requires 3 sequential d6 results')
    if rolls[:2]==(6,6) and rolls[2] in (5,6):return 'POSITIVE-CRIT'
    if rolls[:2]==(1,1) and rolls[2] in (1,2):return 'CRITICAL-FAIL'
    return 'NONE'

def targeting(targeting_contract:str,available_actor_ids:tuple[str,...],selected_ids:tuple[str,...],*,
              explicit_aoe_membership:bool=False)->tuple[str,...]:
    """No automatic grid/AoE expansion if area geometry isn't authorized."""
    if len(selected_ids)!=len(set(selected_ids)):
        raise IllegalAction('Repeated target in same effect component')
    if not selected_ids or any(v not in available_actor_ids for v in selected_ids):
        raise IllegalAction('Target not available')
    if targeting_contract=='SINGLE':
        if len(selected_ids)!=1:raise IllegalAction('Single-target effect cannot hit many')
    elif targeting_contract=='AOE-EXPLICIT':
        if not explicit_aoe_membership:raise RulesUnresolved('AoE membership needs explicit supported source or scenario tag')
    else:raise RulesUnresolved('Undefined targeting type; no invented range/geometry')
    return selected_ids

def validate_actor_ready(actor:ActorSnapshot)->dict:
    gaps=list(actor.missing_for_full_fight)
    if not actor.ca['integer_ready']:gaps.append('CA_fraction_rounding_or_exact_comparison_confirmation')
    return {'actor_id':actor.actor_id,'full_fight_eligible':not gaps,'gaps':sorted(set(gaps)),
            'source_traceable':bool(actor.source_refs),'is_canonical_entity':actor.canonical_entity_id is not None}

def scenario_preflight(actors:tuple[ActorSnapshot,...])->dict:
    if not actors:raise ValueError('Empty actor roster')
    states=[validate_actor_ready(a) for a in actors]
    return {'actor_count':len(actors),'eligible_count':sum(s['full_fight_eligible'] for s in states),
            'blocked_count':sum(not s['full_fight_eligible'] for s in states),'full_fight_allowed':all(s['full_fight_eligible'] for s in states),
            'simulation_run_count':0,'status':'PREFLIGHT-ONLY; NO-RUN','actor_gaps':states}
