import unittest
from copy import deepcopy
from vlab_beast_benchmark_v06 import sample_rosters,run
from audit_vlab_beast_v06 import audit

class Checker(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.rosters=sample_rosters()
 def test_valid_two_sizes(self):
  for roster in self.rosters:
   for seed in range(1,20):
    self.assertTrue(audit(roster,run(roster,seed))['pass'])
 def test_detect_wrong_damage(self):
  r=run(self.rosters[0],101)
  corrupted=deepcopy(r)
  e=next(e for e in corrupted['events'] if e['hit'])
  e['damage_net']+=5
  with self.assertRaises(AssertionError):audit(self.rosters[0],corrupted)
 def test_detect_wrong_target(self):
  r=run(self.rosters[0],101)
  corrupted=deepcopy(r)
  e=corrupted['events'][0]
  e['target_id']=e['actor_id']
  with self.assertRaises(AssertionError):audit(self.rosters[0],corrupted)
 def test_detect_wrong_life(self):
  r=run(self.rosters[1],101)
  corrupted=deepcopy(r)
  corrupted['events'][0]['after_hp']+=1
  with self.assertRaises(AssertionError):audit(self.rosters[1],corrupted)

if __name__=='__main__':unittest.main()
