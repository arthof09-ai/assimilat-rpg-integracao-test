"""Research-only Bestiary calibration ledger validator.
Does not change rank, star, or stat of any creature. No imported D&D/PF2e mechanics.
"""
from dataclasses import dataclass,asdict
from statistics import median
from collections import Counter

STATUS={'DEFINED','MISSING-SOURCE','SOURCE-VALIDATED','ELIGIBLE','RUN-CONDITIONAL','RUN-EXECUTED','REPLAY-VERIFIED','INDEPENDENTLY-VERIFIED','CENSORED','INVALID'}

@dataclass(frozen=True)
class BeastEvaluation:
    beast_source_id:str
    beast_source_version:str
    beast_rank:str
    beast_star:int
    beast_traits:tuple[str,...]
    opponent_mode:str
    opponent_rank:str
    opponent_star:int
    party_size:int
    party_archetype:str
    policy_version:str
    seed:int
    run_id:str
    run_status:str
    winner_team:str|None
    rounds:int|None
    casualties_party:int|None
    beast_damage_to_party:int|None
    beast_damage_from_party:int|None
    final_beast_hp:int|None
    ruleset_version:str
    source_manifest_id:str
    quality_gate:str
    cohort:str='HYPOTHETICAL-EXAMPLE'

    def validate(self):
        if self.run_status not in STATUS:raise ValueError('bad state')
        if not 1<=self.beast_star<=5 or not 1<=self.opponent_star<=5:raise ValueError('bad star')
        if self.beast_rank not in ('Bronze','Prata','Ouro','Ouro Negro','Lendário'):raise ValueError('bad rank')
        if self.party_size<1 or self.party_size>40:raise ValueError('bad party size')
        if self.run_status in ('RUN-EXECUTED','REPLAY-VERIFIED','INDEPENDENTLY-VERIFIED'):
            if not self.run_id or self.rounds is None or self.winner_team is None:raise ValueError('executed must carry event evidence')
        if self.run_status in ('DEFINED','SOURCE-VALIDATED','MISSING-SOURCE','ELIGIBLE') and self.winner_team is not None:
            raise ValueError('status without executed fight cannot claim winner')
        if self.run_status in ('REPLAY-VERIFIED','INDEPENDENTLY-VERIFIED') and not self.source_manifest_id:raise ValueError('missing provenance')
        return self

def aggregate(records:list[BeastEvaluation]):
    for r in records:r.validate()
    if not records:return {'status':'NO-DATA','canonical_rank_change_authorized':False}
    beasts={(x.beast_source_id,x.beast_source_version,x.ruleset_version) for x in records}
    if len(beasts)!=1:raise ValueError('cannot pool different beasts, versions or rule versions')
    unique={(x.run_id,x.seed,x.cohort) for x in records if x.run_id}
    if len(unique)!=len([x for x in records if x.run_id]):raise ValueError('double-credited run')
    good=[x for x in records if x.run_status=='INDEPENDENTLY-VERIFIED' and x.cohort!='HYPOTHETICAL-EXAMPLE']
    return {'status':'EVIDENCE-INSUFFICIENT' if not good else 'OBSERVATIONAL-UNPROMOTED',
            'records_total':len(records),
            'independently_verified_nonhypothetical_runs':len(good),
            'median_rounds_if_evidence':median([r.rounds for r in good if r.rounds is not None]) if good else None,
            'party_casualties_if_evidence':sum(r.casualties_party or 0 for r in good) if good else None,
            'canonical_rank_change_authorized':False,
            'recommended_rank_star':None, # requires certified benchmarks + Mestre gate
            'pending':'certified comparators, balanced party roster, independent QA, frozen holdout and Mestre decision'}
