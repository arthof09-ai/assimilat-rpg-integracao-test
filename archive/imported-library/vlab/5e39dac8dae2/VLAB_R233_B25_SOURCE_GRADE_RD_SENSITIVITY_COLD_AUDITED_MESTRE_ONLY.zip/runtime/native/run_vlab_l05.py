"""Generate immutable first restricted duel and independent deterministic replay."""
import csv, json, hashlib, pathlib
from vlab_l05_duel import build_sample_fixture, execute_duel, independent_replay
ROOT=pathlib.Path(__file__).parent
OUT=ROOT/'samples';OUT.mkdir(exist_ok=True)
a,b=build_sample_fixture()
run=execute_duel((a,b),seed=1)
replay=independent_replay(run)
assert replay['replay_passed']
summary={
    'case_id':run['case_id'],'classification':run['classification'],'seed':run['rng_seed'],
    'protocol':run['protocol'],'fixture_hash':run['fixture_hash'],'run_digest':run['run_digest'],
    'winner_by_lab_stop_condition':run['winner_by_lab_stop_condition'],
    'rounds':run['rounds_completed'],'action_events':run['action_events'],
    'hp_initial':{a['side']:a['health'] for a in run['actors']},'hp_final':run['hp_final'],
    'initiative_total':run['initiative_totals'],'initiative_roll':run['initiative_rolls'],
    'attack_attempts':{side:sum(e['turn_actor']==side for e in run['events']) for side in 'AB'},
    'hits':{side:sum(e['turn_actor']==side and e['hit'] for e in run['events']) for side in 'AB'},
    'damage_dealt':{side:sum(e['dmg_final'] for e in run['events'] if e['turn_actor']==side) for side in 'AB'},
    'criticals':sum(e['critical_status']=='POSITIVE-CRIT' for e in run['events']),
    'replay':replay,
    'formal_credit':{'core_cells_fully_executed':0,'core_cells_verified':0,'human_playtests':0,
        'lab_conditional_full_duels_executed':1,'lab_conditional_full_duels_replayed':1},
    'scenario_notes':[
        'This scenario uses two ephemeral virtual actors (no campaign entities).',
        'Damage from DMG-RANK-01 v1.1 common light weapon 1d4, plus permanent FF bonus.',
        'Luta proficiency +2 was a legal laboratory selection from the character-creation proficiency choices.',
        'No actions other than regular melee attack; both sides decline optional reactions.',
        'Both actors are adjacent throughout, no movement and no area spells.',
        'HP<=0 ends the LAB run; not a new canon rule for death/incapacitation.',
        'Critical-check per attack is a lab protocol; unresolved critical failures abort the run.',
        'Replay is same-algorithm deterministic reexecution, not independent review.'
    ]
}
(OUT/'duel_bronze1_seed1_full_log.json').write_text(json.dumps(run,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
(OUT/'duel_bronze1_seed1_replay_report.json').write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
with (OUT/'duel_bronze1_seed1_events.csv').open('w',encoding='utf-8',newline='') as fh:
    writer=csv.DictWriter(fh,fieldnames=['round','turn_actor','target','attack_dice','attack_total','target_CA','hit','critical_check_sequential','critical_status','weapon_dice_1d4','ff_fixed_bonus','dmg_final','target_hp_before','target_hp_after'])
    writer.writeheader()
    for e in run['events']:
        record={k:e[k] for k in writer.fieldnames}
        for key in ['attack_dice','critical_check_sequential','weapon_dice_1d4']:
            record[key]=json.dumps(record[key],separators=(',',':'))
        writer.writerow(record)
text=[f'# Duelo virtual condicional — {run["case_id"]}', '',
      '**Mestre-only. Não canônico. Não é playtest humano.**',
      f'Semente: `{run["rng_seed"]}` · regras: `{run["protocol"]}` · hash da fixture: `{run["fixture_hash"]}`',
      f'Hash do log: `{run["run_digest"]}` · replay: **{"PASS" if replay["replay_passed"] else "FAIL"}**', '',
      f'**Resultado condicional:** vitória lado {run["winner_by_lab_stop_condition"]}, por Vida chegando a zero no protocolo experimental, após {run["rounds_completed"]} rodadas e {run["action_events"]} ações.',
      'Sem conclusão sobre morte canônica ou balanceamento oficial.', '',
      '## Parâmetros', '', '| Campo | Lado A | Lado B |', '|---|---|---|']
for key in ['rank','star','health','soul','defense_ca','weapon','luta_prof_bonus','ff_damage_fixed']:
    text.append(f'| {key} | {a[key]} | {b[key]} |')
for key in ['FOR','DES','CON','INT','SAB','CAR']:
    text.append(f'| {key} | {a["attributes"][key]} | {b["attributes"][key]} |')
text+=['','## Eventos', '', '| Rodada | Ator | Rolagem ataque | Contra CA | Acertou? | Dano | Vida-alvo (antes→depois) |','|---:|---|---|---:|---|---:|---|']
for e in run['events']:
    text.append(f'| {e["round"]} | {e["turn_actor"]} | {e["attack_dice"][0]} + {e["attribute_FOR"]} + {e["luta_prof_bonus"]} = {e["attack_total"]} | {e["target_CA"]} | {"SIM" if e["hit"] else "NÃO"} | {e["dmg_final"]} | {e["target_hp_before"]}→{e["target_hp_after"]} |')
text+=['','## Avisos metodológicos', '',
       '- Critério de término HP≤0 é **LAB ASSUMPTION**, não regra de morte/incapacitação canônica.',
       '- Aplicabilidade e momento do teste de crítico sequencial por tentativa precisam de gate competente; sorteios de falha crítica bloqueiam a execução.',
       '- Política “atacar sempre” e “não usar reação” são escolhas laboratoriais legítimas neste caso restrito, não previsão do comportamento de players.',
       '- O replay reproduz logs dentro do mesmo motor; **auditoria independente** ainda PENDENTE.',
       '- Crédito de células FULL-FIGHT/VERIFIED do ledger oficial permanece **0**.',
       '- A equipe do Coordenador 1 mantém fontes D0–D9; nenhuma regra do sistema foi alterada.', '',
       'Fontes: Criação de Ficha; Sistema de Combate; DMG-RANK-01 v1.1; plano e especificação L00–L03.', '']
(OUT/'duel_bronze1_seed1_analysis.md').write_text('\n'.join(text),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2))
for f in sorted(OUT.glob('duel_bronze1_seed1_*')):
    print(f'{f.name} {f.stat().st_size} sha256={hashlib.sha256(f.read_bytes()).hexdigest()}')
