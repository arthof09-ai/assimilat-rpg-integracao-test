"""MESTRE-SIDE: style-diverse tactical choice, never mechanics authority.

Ported principles (not rules) from Tormenta20, D&D, Call of Cthulhu,
PF2e GM Core and The Monsters Know What They're Doing.

This module does NOT invent new RPG abilities, solve damage, move creatures or
cast spells. Only chooses among action alternatives verified as legal by
source-specific rule adapters. Team labels and other actors' hidden statistics
are absent from the interface. All numerical WEIGHTS are experimental scoring
coefficients, NOT RPG bonuses or new canon. Version 0.2 experimental.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Literal

VERSION = 'TACTICAL-OBSERVABLE-v0.2'
Role = Literal['striker','vanguard','guardian','healer','controller','support','skirmisher','generalist']
Intellect = Literal['instinct','basic','trained','expert']
Style = Literal['ambusher','pack_hunter','predator','guardian','territorial','duelist','skirmisher','cautious','berserker','disciplined']
Kind = Literal['attack','spell','heal','control','protect','guard','move','retreat','buff','transform','reaction','ready','interact','pass']
Threat = Literal['none','low','medium','high','unknown']
Injury = Literal['normal','injured','critical','unknown']

@dataclass(frozen=True)
class FighterDoctrine:
    """LAB personality (not an official race/class/INT→tier mapping)."""
    actor_id: str
    role: Role
    style: Style
    cognitive_tier: Intellect
    aggression: int = 50
    caution: int = 50
    cooperation: int = 50
    discipline: int = 50
    resources_priority: int = 50
    objective: str = 'survive_and_win'
    provenance: str = 'LAB-CHOICE'  # may be SOURCE-TRAIT only with proper source

    def __post_init__(self):
        if not self.actor_id.strip(): raise ValueError('Missing stable actor ID')
        if self.cognitive_tier not in ('instinct','basic','trained','expert'):raise ValueError('Bad tier')
        if self.role not in ('striker','vanguard','guardian','healer','controller','support','skirmisher','generalist'):raise ValueError('Bad role')
        if self.style not in ('ambusher','pack_hunter','predator','guardian','territorial','duelist','skirmisher','cautious','berserker','disciplined'):raise ValueError('Bad style')
        if any(not isinstance(v,int) or isinstance(v,bool) or not 0 <= v <= 100 for v in (self.aggression,self.caution,self.cooperation,self.discipline,self.resources_priority)):
            raise ValueError('Style knobs 0..100')
        if self.provenance not in ('LAB-CHOICE','SOURCE-TRAIT','MASTER-RULING'): raise ValueError('No provenance')

@dataclass(frozen=True)
class VisibleContext:
    """Events the actor can legitimately know; no enemy exact HP, saves or secrets."""
    actor_id: str
    self_hp_fraction: float
    self_resources_fraction: float
    ally_in_danger: bool=False
    friendly_count_visible: int=1
    enemy_count_visible: int=1
    retreat_route_known: bool=False
    urgency: int=0
    objective_threatened: bool=False
    last_observed_enemy_action: str|None=None
    # Observability adapter must produce truthful, source-supported bands.
    observation_mode: Literal['STRICT-VISIBLE','LAB-ASSUMPTION']='STRICT-VISIBLE'

    def __post_init__(self):
        if not (0 <= self.self_hp_fraction <= 1 and 0 <= self.self_resources_fraction <= 1):
            raise ValueError('Bad own status; no silent bounds normalization')
        if self.friendly_count_visible<0 or self.enemy_count_visible<0:raise ValueError('Counts invalid')
        if self.urgency<0 or self.urgency>100:raise ValueError('Invalid urgency')

@dataclass(frozen=True)
class SourcedOption:
    """Only mechanically LEGAL actor-specific options supplied by rule adapter.

    src_ref is a real local authority (page/ability ID or versioned source key).
    For a LAB-ASSUMPTION fixture, assumptions must be explicit and cannot
    claim canonical completion. Neither side receives actions from this class.
    """
    action_id:str
    kind:Kind
    source_ref:str
    target_id:str|None=None
    target_injury:Injury='unknown'
    target_threat:Threat='unknown'
    ally_urgency:Injury='unknown'
    resource_fraction_required:float=0.
    expected_affordability:bool=True
    visible_target_count:int=1
    position_change:Literal['none','toward','away','cover','escape']='none'
    # Actor/context visibility, not omniscient reliability
    success_estimate:float|None=None
    estimate_provenance:Literal['NONE','OBSERVED','LAB-ORACLE']='NONE'
    verified_legal:bool=True
    rule_status:Literal['SOURCE-VALIDATED','LAB-ASSUMPTION']='SOURCE-VALIDATED'
    triggers_reaction:bool=False
    consumes_reaction:bool=False

    def __post_init__(self):
        if not self.action_id or not self.source_ref:raise ValueError('Action/source ID required')
        if self.visible_target_count<0:raise ValueError('Bad target count')
        if not 0<=self.resource_fraction_required<=1:raise ValueError('Bad resource cost')
        if self.success_estimate is not None and not 0<=self.success_estimate<=1:raise ValueError('Bad estimate')
        if self.success_estimate is not None and self.estimate_provenance=='NONE':raise ValueError('Estimate source required')

@dataclass(frozen=True)
class PolicyDecision:
    version:str
    actor_id:str
    action_id:str
    target_id:str|None
    score:int
    reasons:tuple[str,...]
    available_action_ids:tuple[str,...]
    rejected_action_ids:tuple[str,...]
    doctrine:str
    canonical_authority:bool=False

# All values below are scores of virtual policy, never dice modifiers.
BASE = {'attack':45,'spell':39,'heal':30,'control':37,'protect':32,
        'guard':19,'move':17,'retreat':16,'buff':25,'transform':31,
        'reaction':26,'ready':18,'interact':13,'pass':0}
ROLE_BONUS = {
 'striker':{'attack':20,'spell':7},'vanguard':{'attack':14,'guard':12,'protect':11},
 'guardian':{'protect':24,'guard':21,'reaction':10},
 'healer':{'heal':26,'protect':9},'controller':{'control':26,'spell':9},
 'support':{'heal':16,'buff':17,'protect':16},
 'skirmisher':{'move':16,'retreat':13,'attack':12},'generalist':{}}
STYLE_BONUS = {
 'ambusher':{'move':12,'attack':13,'retreat':3},
 'pack_hunter':{'attack':12,'control':9,'protect':3},
 'predator':{'attack':16,'retreat':3},
 'guardian':{'protect':18,'guard':14},
 'territorial':{'protect':17,'guard':9,'retreat':-20},
 'duelist':{'attack':12,'reaction':14},
 'skirmisher':{'move':18,'attack':7,'retreat':10},
 'cautious':{'guard':15,'retreat':18,'reaction':8},
 'berserker':{'attack':25,'retreat':-18,'guard':-9},
 'disciplined':{'ready':14,'protect':11,'buff':10}}


def choose_action(doctrine:FighterDoctrine, context:VisibleContext, legal:tuple[SourcedOption,...], *,
                  phase:Literal['TURN','REACTION']='TURN') -> PolicyDecision:
    if doctrine.actor_id != context.actor_id:raise ValueError('Identity mismatch')
    if not legal: raise ValueError('NO-LEGAL-ACTIONS: do not hallucinate pass')
    ids=[a.action_id for a in legal]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate action IDs, cannot disambiguate')
    rejected=[];scored=[]
    for a in legal:
        # The rule adapter must supply legal-source actions; never execute an unvalidated one.
        if not a.verified_legal or not a.expected_affordability or a.resource_fraction_required>context.self_resources_fraction:
            rejected.append(a.action_id);continue
        if phase=='REACTION' and not a.consumes_reaction and a.kind!='pass':
            rejected.append(a.action_id);continue
        if phase=='TURN' and a.consumes_reaction:
            rejected.append(a.action_id);continue
        if a.estimate_provenance=='LAB-ORACLE' and context.observation_mode=='STRICT-VISIBLE':
            rejected.append(a.action_id);continue
        if a.kind in ('attack','spell','heal','control','protect','reaction') and a.target_id is None and a.kind!='reaction':
            rejected.append(a.action_id);continue
        points=BASE[a.kind]
        reasons=[f'lab-policy-base-{a.kind}={points}']
        role=ROLE_BONUS[doctrine.role].get(a.kind,0)
        style=STYLE_BONUS[doctrine.style].get(a.kind,0)
        if role:points+=role;reasons.append('role='+str(role))
        if style:points+=style;reasons.append('style='+str(style))
        if a.kind in ('attack','spell'):
            adj=(doctrine.aggression-50)//4
            points+=adj;reasons.append('aggression='+str(adj))
            if a.target_injury=='critical':points+=17;reasons.append('observed-wounded-target')
            elif a.target_injury=='injured':points+=8
            if a.target_threat=='high' and doctrine.cognitive_tier in ('trained','expert'):
                points+=10;reasons.append('observed-dangerous-target')
            # Distinct target preferences from visible tactical facts only.
            if doctrine.style=='pack_hunter' and a.target_injury in ('injured','critical') and doctrine.cooperation>65:
                points+=12;reasons.append('visible-pack-focus')
            if doctrine.style=='ambusher' and a.target_threat=='high':
                points+=16;reasons.append('ambush-high-threat-if-visible')
            if doctrine.style=='duelist' and a.target_threat=='high':
                points+=15;reasons.append('duelist-challenge')
            if doctrine.style=='cautious' and a.target_threat=='low':
                points+=15;reasons.append('cautious-low-risk-target')
            if doctrine.style=='predator' and a.target_injury=='critical':
                points+=12;reasons.append('predator-finish-observed-prey')
            if doctrine.style=='territorial' and a.target_threat=='high':
                points+=13;reasons.append('territory-threat-control')
        if a.kind=='heal' and a.ally_urgency=='critical':points+=48;reasons.append('critical-visible-ally')
        if a.kind=='heal' and a.ally_urgency=='injured':points+=12
        if a.kind=='protect' and context.ally_in_danger:
            points+=19+doctrine.cooperation//10;reasons.append('ally-protection')
        if a.kind in ('guard','reaction','retreat') and context.self_hp_fraction<0.35:
            points+=12+doctrine.caution//5;reasons.append('self-preservation')
        if a.kind=='retreat' and context.retreat_route_known and context.self_hp_fraction<0.25:
            points+=30;reasons.append('known-retreat-route')
        if a.kind=='retreat' and not context.retreat_route_known:
            points-=40;reasons.append('no-observed-retreat-route')
        if a.kind=='control' and context.enemy_count_visible>=2 and doctrine.cognitive_tier in ('trained','expert'):
            points+=10;reasons.append('visible-group-control')
        if a.kind=='buff' and doctrine.cognitive_tier=='instinct':points-=18
        if a.kind=='move' and a.position_change in ('cover','escape') and context.self_hp_fraction<0.4:
            points+=28;reasons.append('survival-positioning')
        if a.kind=='spell' and a.visible_target_count>=2:points+=min(20,4*a.visible_target_count)
        if a.resource_fraction_required>0.3:
            points-=doctrine.resources_priority//5;reasons.append('resource-conservation')
        if context.objective_threatened and a.kind in ('protect','control','move'):
            points+=context.urgency//3;reasons.append('objective-threatened')
        # Adapt after witnessed enemy behavior, not from opponent's full sheet.
        if doctrine.cognitive_tier in ('trained','expert'):
            if context.last_observed_enemy_action in ('spell','control') and a.kind in ('protect','move','reaction'):
                points+=12;reasons.append('observed-spell-control-threat')
            if context.last_observed_enemy_action=='attack' and a.kind in ('guard','reaction') and context.self_hp_fraction<0.5:
                points+=8;reasons.append('observed-attack-response')
        # Personalized mistakes; no fixed perfect strategy, but never deny source-legal actions to other side.
        if doctrine.cognitive_tier=='instinct' and a.kind in ('spell','control','ready','buff'):
            points-=16;reasons.append('instinctive-priority')
        scored.append((points,a,tuple(reasons)))
    if not scored:raise ValueError('NO-AFFORDABLE-LEGAL-ACTIONS: fail closed')
    # sorting prevents team name/roster position affecting outcomes
    scored.sort(key=lambda t:(-t[0],t[1].action_id,t[1].target_id or ''))
    score,a,reasons=scored[0]
    return PolicyDecision(VERSION,doctrine.actor_id,a.action_id,a.target_id,score,reasons,
                          tuple(sorted(ids)),tuple(sorted(rejected)),doctrine.style)


def doctrine_from_snapshot(actor_id:str, actor_kind:str, *, race_or_species:str,
                           source_traits:tuple[str,...]=(), assigned_style:str|None=None,
                           assigned_role:str|None=None, lab_seed:int=0)->FighterDoctrine:
    """Seeded lab-personality, not a species/rank canonical fact.

    A real character's source traits or Maestro ruling may override this in a
    *different* builder after source validation. No automatic INT threshold.
    """
    if actor_kind not in ('ED','BE'):raise ValueError('Unknown combatant kind')
    pool=('predator','pack_hunter','territorial','ambusher','cautious') if actor_kind=='BE' else ('duelist','disciplined','skirmisher','guardian','cautious')
    key=int(sha256(f'{actor_id}|{race_or_species}|{lab_seed}'.encode()).hexdigest()[:8],16)
    style=assigned_style or pool[key%len(pool)]
    role=assigned_role or ('striker' if actor_kind=='ED' else 'vanguard')
    if actor_kind=='BE' and 'Titã' in source_traits and assigned_role is None:
        role='guardian'  # LAB-HYPOTHESIS ONLY, not claiming Titans have class
    return FighterDoctrine(actor_id=actor_id,role=role,style=style,cognitive_tier='basic',
        aggression=30+key%51,caution=20+(key>>5)%61,cooperation=25+(key>>10)%71,
        discipline=20+(key>>15)%61,resources_priority=35+(key>>20)%61,
        provenance='LAB-CHOICE')
