"""Coverage of supported conditional runs / intentional fail-closed status."""
import json
from collections import Counter
from vlab_l05_duel import build_sample_fixture, execute_duel
from vlab_l05_preflight import RulesUnresolved

def stress(n=500):
    a,b=build_sample_fixture();counts=Counter();events=0; max_rounds=0
    for seed in range(1,n+1):
        try:run=execute_duel((a,b),seed=seed,max_rounds=30)
        except RulesUnresolved as exc:
            s=str(exc)
            if 'TIED-INITIATIVE' in s:counts['TIE-INITIATIVE-BLOCKED']+=1
            elif 'CRITICAL-FAIL' in s:counts['CRITICAL-CONSEQUENCE-BLOCKED']+=1
            else:raise
            continue
        if run['winner_by_lab_stop_condition']:
            counts['CONDITIONAL-COMPLETE']+=1
            counts[f'WIN-{run["winner_by_lab_stop_condition"]}']+=1
            events+=len(run['events']);max_rounds=max(max_rounds,run['rounds_completed'])
        else:counts['CENSORED-MAX-ROUNDS']+=1
    if sum(counts[k] for k in ['CONDITIONAL-COMPLETE','TIE-INITIATIVE-BLOCKED','CRITICAL-CONSEQUENCE-BLOCKED','CENSORED-MAX-ROUNDS']) != n:
        raise AssertionError('Unaccounted seed')
    return {'seeds_attempted':n,'counts':dict(counts),'total_actions_in_completed_conditional_runs':events,
            'max_rounds_in_completed_conditional_runs':max_rounds,'core_cells_credited':0,
            'type':'ENGINE STRESS/CONDITIONAL SCENARIOS, NOT CANONICAL COMBAT EVIDENCE'}
if __name__=='__main__':print(json.dumps(stress(),indent=2,ensure_ascii=False))
