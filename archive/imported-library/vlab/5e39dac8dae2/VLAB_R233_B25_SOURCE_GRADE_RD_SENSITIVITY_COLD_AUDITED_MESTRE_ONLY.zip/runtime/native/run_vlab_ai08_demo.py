"""Deterministic, explicitly synthetic demonstrations of new effect bridges."""
import json
from dataclasses import asdict
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from vlab_rd_v08 import Resistances,DamageComponent,mitigate
from vlab_effects_v08 import *
from vlab_persistence_v08 import persist_basic_attacks

HERE=Path(__file__).parent
OUT=HERE/'samples'
OUT.mkdir(exist_ok=True)
def test_evidence(page,rule):return FrozenRuleEvidence(page,rule,sha256(f'TEST-PROOF|{page}|{rule}'.encode()).hexdigest(),'2026-10-08','EXPLICIT-MOCK-FIXTURE-NOT-SOURCE-AUDIT')
def make(kind,econ,page,rule,pa,scope='ENEMY',trigger=None,status='EXPLICIT-CANON'):
    return AbilitySource('FX-'+rule,kind,econ,page,rule,status,required_pa=pa,target_scope=scope,reaction_trigger=trigger,effect_adapter_ready=True,effect_adapter_id='V08-EXPERIMENT-ONLY')
def show():
    matrix=[]
    for title,amount,tag,rd in (
        ('GENERAL-70-50',70,'impacto',Resistances(50)),
        ('PIERCING-70-50',70,'perfurante',Resistances(specific=(('perfurante',50),))),
        ('BLUNT-70-PIERCING-ONLY',70,'impacto',Resistances(specific=(('perfurante',50),))),
        ('GENERAL-30-50',30,'cortante',Resistances(50))):
        r=mitigate((DamageComponent(amount,tag,title),),rd)
        matrix.append({'test':title,**asdict(r)})
    scene=Scene({'A':Combatant('A',120,160,Fraction(10),5,0,2,3,'P1',spirit_id='E-BRONZE-1'),
                 'B':Combatant('B',120,0,Fraction(12),10,0,4,3,'P2')})
    atk=make('attack','STANDARD',COMBAT_PAGE,'R3-attack',0)
    stateA=ActorActionState('A',1,160,('FX-R3-attack',),enemy_ids_visible=('B',))
    defense=make('reaction','REACTION',COMBAT_PAGE,'R4-defender',0,'SELF','BEFORE-ATTACK')
    stateB=ActorActionState('B',1,0,('FX-R4-defender',),reaction_trigger_observed='BEFORE-ATTACK')
    react_defensively(scene,'B',kind='DEFENDER',attack_score=15,announced_before=True,trigger_source='BEFORE-ATTACK',
                      source=defense,state=stateB,proofs=(test_evidence(COMBAT_PAGE,'R4-defender'),))
    apply_weapon_attack(scene,'A','B',source=atk,state=stateA,proofs=(test_evidence(COMBAT_PAGE,'R3-attack'),),
         roll_score=15,damage=70,damage_tag='impacto',rd=Resistances(50),defense_event=scene.events[-1])
    # In a separate turn, the spell's single-source damage is computed from a
    # declared LAB effect. It is NOT evidence a canonical named spell was cast.
    scene.actors['A'].standard=1
    spell=make('spell','STANDARD',MAGIC_PAGE,'LAB-FIRE-ABILITY-NOT-CANONICAL',20,status='LAB-ASSUMPTION')
    cast_source_specified_spell(scene,'A','B',source=spell,
        state=ActorActionState('A',1,160,('FX-LAB-FIRE-ABILITY-NOT-CANONICAL',),enemy_ids_visible=('B',)),
        proofs=(test_evidence(MAGIC_PAGE,'LAB-FIRE-ABILITY-NOT-CANONICAL'),),
        damage=70,damage_tag='fogo',rd=Resistances(specific=(('perfurante',50),)),strict=False)
    tscene=Scene({'A':Combatant('A',99,120,Fraction(11),5,0,2,3,'P1',spirit_id='DEMO-SPIRIT')})
    spirit=AssimilatedSpirit('DEMO-SPIRIT',10,Fraction(8),{'FOR':4,'DES':0,'CON':0,'INT':0,'SAB':0,'CAR':0},
              {'CA':12,'CON':6,'Fortitude':2,'Reflexo':2,'Armadura':0},'MOCK-OVERLAY')
    tsrc=make('transform','FULL',TRANSFORM_PAGE,'T9',20,'SELF')
    activate_transformation(tscene,'A',source=tsrc,
        state=ActorActionState('A',1,120,('FX-T9',)),proofs=(test_evidence(TRANSFORM_PAGE,'T9'),),
        spirit=spirit,ordinal_level=1,duration_die_roll=3,compatible=True,full_reaction_policy='LAB-CONSUME')
    impossible=persist_basic_attacks(attacker_id='Besta-demo',defender_id='Orc-demo',seed=42,
        dice_count=1,dice_faces=6,bonus=14,ca=Fraction(93,4),max_attempts=20)
    possible=persist_basic_attacks(attacker_id='Orc-demo',defender_id='Besta-demo',seed=42,
        dice_count=1,dice_faces=6,bonus=12,ca=Fraction(93,5),max_attempts=20)
    report={'version':VERSION,'class':'SYNTHETIC-LAB-NONCANON','rd_rule':'MASTER-DIRECTION-REQUIRES-NORM-CANON-GATE',
       'rd_matrix':matrix,'action_pipeline':{'events':scene.events,'last_hp':{'A':scene.actors['A'].hp,'B':scene.actors['B'].hp},'PA_A':scene.actors['A'].pa,'digest':scene.checksum()},
       'transform':{'events':tscene.events,'mode':tscene.actors['A'].mode,'PA':tscene.actors['A'].pa},
       'repeated_attempts':{'beast_to_orc':impossible,'orc_to_beast':possible},
       'limits':['Catalog proofs for this DEMO are MOCK not Notion attestation',
       'Magic spell is not a named canonical spell; effect demo only','No movement distance invented',
       'Full action normally-reaction uses explicit LAB-CONSUME','HP0 is lab stop, not canonical death',
       'No full fight, no core 1875 credit','RD simultaneous general+specific still blocked']}
    path=OUT/'AI08_RD_TRANSFORM_ACTION_PIPELINE_EXPERIMENT.json'
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print(json.dumps({'version':VERSION,'rd_cases':[(x['test'],x['effective']) for x in matrix],
      'pipeline_events':len(scene.events),'B_hp_final':scene.actors['B'].hp,'transformed_mode':tscene.actors['A'].mode,
      'transform_PA':tscene.actors['A'].pa,'persistent_basic_tries':(impossible['attempts'],possible['attempts']),
      'no_hit_potential_both':not(impossible['basic_hit_possible'] or possible['basic_hit_possible']),
      'file':str(path)},ensure_ascii=False))
    return report
if __name__=='__main__':show()
