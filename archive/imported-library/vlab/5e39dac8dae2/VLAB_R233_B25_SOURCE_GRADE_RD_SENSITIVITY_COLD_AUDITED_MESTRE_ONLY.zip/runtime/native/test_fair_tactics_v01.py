import unittest
from copy import deepcopy
from vlab_tactical_policy_v01 import TacticalObservation,LegalAction,choose
from vlab_fair_team_v01 import sample_2v1,run,mirrors,identity_key
from vlab_l05_preflight import RulesUnresolved

class Tactics(unittest.TestCase):
 def setUp(self):
  self.obs=TacticalObservation('unit1','striker','trained',0.9)
  self.opts=(LegalAction('a1','attack','enemy1','normal'),LegalAction('a2','attack','enemy2','critical'))
 def test_invariance_roster_order(self):
  self.assertEqual(choose(self.obs,self.opts),choose(self.obs,tuple(reversed(self.opts))))
 def test_unprivileged_side_name(self):
  self.assertFalse(hasattr(self.obs,'side'))
 def test_focus_visible_wound(self):
  self.assertEqual(choose(self.obs,self.opts).target_id,'enemy2')
 def test_no_illegal_choosing(self):
  self.assertEqual(choose(self.obs,self.opts).action_id,'a2')
 def test_empty_options_fail(self):
  with self.assertRaises(ValueError):choose(self.obs,())
 def test_duplicate_options_fail(self):
  with self.assertRaises(ValueError):choose(self.obs,(self.opts[0],self.opts[0]))
 def test_heal_critical_ally(self):
  obs=TacticalObservation('healer','support','expert',0.8,True)
  opts=(LegalAction('strike','attack','enemy','normal'),LegalAction('heal','heal','friend',ally_urgency='critical'))
  self.assertEqual(choose(obs,opts).action_id,'heal')
 def test_survival_policy(self):
  obs=TacticalObservation('scout','skirmisher','trained',0.15,mission_requires_survival=True)
  opts=(LegalAction('strike','attack','enemy'),LegalAction('escape','retreat',None))
  self.assertEqual(choose(obs,opts).action_id,'escape')
 def test_does_not_grant_action(self):
  opts=(LegalAction('attack','attack','enemy'),)
  self.assertEqual(choose(self.obs,opts).action_id,'attack')
 def test_tiebreak_stable_id(self):
  opts=(LegalAction('Z','move',None),LegalAction('A','move',None))
  self.assertEqual(choose(self.obs,opts).action_id,'A')

class TeamMirror(unittest.TestCase):
 def test_teams_reverse_slot(self):
  roster=sample_2v1()
  c=deepcopy(roster)
  for v in c:v['team']='B' if v['team']=='A' else 'A'
  self.assertEqual(identity_key(roster),identity_key(c))
 def test_order_independence(self):
  roster=sample_2v1()
  self.assertEqual(identity_key(roster),identity_key(list(reversed(roster))))
 def test_mirror_pairs_all_checks(self):
  roster=sample_2v1();done=0
  for seed in range(1,110):
   try:report=mirrors(roster,seed)
   except RulesUnresolved:continue
   for k in ['mirror_trace_equal','initiatives_equal','states_equal','winner_actor_set_equal','winner_side_swapped']:
    self.assertTrue(report[k],(seed,k,report))
   done+=1
  self.assertGreater(done,5)
 def test_team_equal_policy_name(self):
  roster=sample_2v1()
  for seed in range(1,110):
   try:result=run(roster,seed)
   except RulesUnresolved:continue
   self.assertEqual({x['policy'] for x in result['events']},{'TACTICAL-OBSERVABLE-v0.1'})
   return
  self.fail('no resolved case found')
 def test_runs_are_not_canonic(self):
  roster=sample_2v1()
  for seed in range(1,110):
   try:result=run(roster,seed)
   except RulesUnresolved:continue
   self.assertEqual(result['canonical_credit'],0)
   self.assertEqual(result['mode'],'LAB-CONDITIONAL-NOT-CANONICAL')
   return
  self.fail('no resolved case found')

if __name__=='__main__':unittest.main()
