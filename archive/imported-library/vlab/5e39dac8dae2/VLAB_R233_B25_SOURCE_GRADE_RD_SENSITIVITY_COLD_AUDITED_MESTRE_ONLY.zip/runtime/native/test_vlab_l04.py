import unittest
from fractions import Fraction
from vlab_l04 import *

class TestLaboratoryL04(unittest.TestCase):
    def test_rank_25_levels(self):
        vals=[ordinal(r,s) for r in RANKS for s in range(1,6)]
        self.assertEqual(vals,list(range(1,26)))
        for n in vals:self.assertEqual(ordinal(rank_at(n),(n-1)%5+1),n)
    def test_human_bronze(self):
        a=build_human('Bronze',1)
        self.assertEqual(a.level,1)
        self.assertEqual(sum(a.stats.values()),27) # 25 base, +2 Bronze1
        self.assertEqual(a.health,10+4+fixed60(6)+a.stats['CON'])
        self.assertEqual(a.ca['exact'],str(6+a.stats['DES']))
        self.assertFalse(a.full_fight_eligible)
    def test_human_all_levels_and_ranks(self):
        for rank in RANKS:
            for star in range(1,6):
                a=build_human(rank,star)
                self.assertEqual(sum(a.stats.values()),25+2*a.level)
                self.assertGreater(a.health,0);self.assertEqual(a.soul,a.pa_total)
                self.assertEqual(a.physical_force,sum(a.stats[x] for x in ('FOR','DES','CON'))*10)
                self.assertEqual(len(a.ff_milestones),a.physical_force//100)
                self.assertEqual(a.test_dice,RANK_TEST_DICE[rank])
    def test_human_reproducible_and_seed_specific(self):
        x=build_human('Ouro',4,seed=124)
        self.assertEqual(x.to_json(),build_human('Ouro',4,seed=124).to_json())
        y=build_human('Ouro',4,seed=125)
        self.assertNotEqual(x.actor_id,y.actor_id)
        self.assertNotEqual(x.to_json(),y.to_json())
    def test_beast_levels(self):
        for rank in RANKS:
            for star in range(1,6):
                a=build_beast(rank,star)
                self.assertEqual(sum(a.stats.values()),35+8*a.level+(0 if a.level<=20 else 11*a.level))
                self.assertGreater(a.health,0);self.assertGreater(a.rd,0)
                self.assertEqual(Fraction(a.ca['numerator'],a.ca['denominator']),Fraction(20 if rank=='Lendário' else 10)+a.stats['DES']+Fraction(a.stats['CON'],5))
                if rank=='Lendário':self.assertIn('Titã',a.traits)
                self.assertFalse(a.full_fight_eligible)
    def test_legendary_titan_damage(self):
        x=build_beast('Lendário',1)
        self.assertEqual(x.base_attack_dice,'20d10')
        self.assertEqual(x.rd,75)
        self.assertIsNone(x.pa_total)  # No invented Beast PA mapping
    def test_beast_specials_explicit(self):
        x=build_beast('Ouro',2,explicit_traits=('ADM',))
        self.assertIn('ADM',x.traits)
        self.assertEqual(x.actor_mode,'CONDITIONAL-SENSITIVITY')
        self.assertEqual(sum(x.stats.values()),35+(8+6)*x.level)
        with self.assertRaises(BuildError):build_beast('Ouro',1,explicit_traits=('ADM','ADM'))
        with self.assertRaises(BuildError):build_beast('Ouro',1,explicit_traits=('Elemental',))
        with self.assertRaises(BuildError):build_beast('Ouro',1,explicit_traits=('Rainbow Unicorn',))
        with self.assertRaises(BuildError):build_beast('Lendário',1,explicit_traits=('Titã',))
        divine=build_beast('Ouro',2,explicit_traits=('Besta Divina',))
        self.assertIsNone(divine.health)
        self.assertIsNone(divine.soul)
        self.assertIn('SPECIAL_VITALS_140_TABLE_APPLICABILITY_UNRESOLVED',divine.missing_for_full_fight)
    def test_fraction_no_implicit_round(self):
        x=build_beast('Bronze',1)
        self.assertIn(x.ca['denominator'],(1,5))
        if x.ca['denominator']!=1:self.assertIn('GAP-01_CA_fraction_without_rounding_authority',x.missing_for_full_fight)
    def test_exhaustive_actor_builds_deterministic(self):
        seen=set()
        for kind in (build_human,build_beast):
            for rank in RANKS:
                for star in range(1,6):
                    x=kind(rank,star,seed=101)
                    self.assertNotIn(x.actor_id,seen)
                    seen.add(x.actor_id)
        self.assertEqual(len(seen),50)
    def test_team_sizes_10_20_and_no_pages(self):
        a=tuple(build_human(RANKS[i%5],(i%5)+1,seed=110+i) for i in range(20))
        b=tuple(build_beast(RANKS[i%5],(i%5)+1,seed=210+i) for i in range(20))
        sim=scenario_template(a,b,'WAR20X20-PLAN-001')
        self.assertEqual(sim['roster_size'],40)
        self.assertEqual(sim['status'],'SCENARIO-TEMPLATE-NOT-RUN')
        self.assertEqual(sim['notion_character_pages_created'],0)
        self.assertEqual(sim['events_executed'],0)
        self.assertFalse(sim['ready_for_full_fight'])
        with self.assertRaises(BuildError):scenario_template(a,a,'dupe')
    def test_invalid_rank_and_human_points(self):
        with self.assertRaises(BuildError):build_human('Diamante',3)
        with self.assertRaises(BuildError):build_human('Bronze',6)
        with self.assertRaises(BuildError):distribute(25,ATTRS,minimum=2,maximum=3)

if __name__=='__main__':unittest.main(verbosity=2)

class TestOtherRaces(unittest.TestCase):
    def test_other_four_races_100_snapshots(self):
        for race,cfg in RACE_PROFILES.items():
            for rank in RANKS:
                for star in range(1,6):
                    a=build_other_race(rank,star,race,seed=455)
                    self.assertEqual(sum(a.stats.values()),25+cfg['extra']+a.level*cfg['growth'])
                    self.assertGreater(a.health,0)
                    self.assertGreater(a.soul,0)
                    self.assertFalse(a.full_fight_eligible)
                    self.assertEqual(a.to_json(),build_other_race(rank,star,race,seed=455).to_json())
                    self.assertIn(a.ca['denominator'],(1,2,4))
    def test_race_specific_ca(self):
        orc=build_other_race('Prata',1,'Orc')
        self.assertEqual(Fraction(orc.ca['numerator'],orc.ca['denominator']),Fraction(12)+Fraction(orc.stats['DES'],4)+orc.stats['CON'])
        supreme=build_other_race('Prata',1,'Raça Superior')
        self.assertEqual(supreme.ca['exact'],'9')
        sky=build_other_race('Prata',1,'Asa Prateada')
        self.assertEqual(sky.ca['exact'],str(9+sky.stats['DES']))
    def test_other_races_invalid(self):
        with self.assertRaises(BuildError):build_other_race('Bronze',1,'Mermaid')
