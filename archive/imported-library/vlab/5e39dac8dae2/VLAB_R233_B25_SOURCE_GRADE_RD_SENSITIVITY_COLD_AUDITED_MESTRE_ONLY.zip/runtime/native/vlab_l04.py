"""RPG Assimilação — L04 experimental virtual actor factory.

MESTRE-ONLY. Not a new RPG rule; not a complete combat engine.
References: Criação de Ficha, Criação de Besta, DMG-RANK-01 v1.1.
Only built-in Python modules; no network/file side effects.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
import hashlib
import json
import random
from typing import Any

RANKS = ('Bronze', 'Prata', 'Ouro', 'Ouro Negro', 'Lendário')
ATTRS = ('FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR')
RANK_TEST_DICE = {'Bronze':'1d6', 'Prata':'2d6', 'Ouro':'3d6', 'Ouro Negro':'4d6','Lendário':'6d6'}
LIFE_DICE = {'Bronze':6,'Prata':8,'Ouro':10,'Ouro Negro':12,'Lendário':20}
BESTIAL_BASE_ATTACK = {'Bronze':'3d6','Prata':'6d6','Ouro':'9d6','Ouro Negro':'12d6'}
TITAN_BASE_ATTACK = {'Bronze':'5d10','Prata':'8d10','Ouro':'11d10','Ouro Negro':'13d10','Lendário':'20d10'}
BEAST_RD_NORMAL = {'Bronze':5,'Prata':15,'Ouro':25,'Ouro Negro':35}
BEAST_RD_TITAN = {'Bronze':15,'Prata':30,'Ouro':45,'Ouro Negro':60,'Lendário':75}
REFS = {
    'character':'3ebc2b32-4ede-8144-9222-f3c06b840613',
    'beast':'3ebc2b32-4ede-81f4-992a-c88a3588cacd',
    'damage':'3f2c2b32-4ede-8154-98cd-db7844245f7e',
    'combat':'3ebc2b32-4ede-81f1-be4b-e8804ac113c0',
}
KNOWN_TRAITS = {'Elemental':3,'Titã':5,'Ressurgido':5,'Chefe de Reino Subsidiário':12,'ADM':6,'Besta Divina':12}

class BuildError(ValueError):
    pass

def ordinal(rank: str, star: int) -> int:
    if rank not in RANKS or not isinstance(star,int) or isinstance(star,bool) or not 1 <= star <= 5:
        raise BuildError('Rank/star invalid; expected one of 5 ranks with 1..5 stars')
    return 5 * RANKS.index(rank) + star

def rank_at(level:int) -> str:
    if not 1 <= level <= 25:
        raise BuildError('Level out of official bounds 1..25')
    return RANKS[(level-1)//5]

def deterministic_id(kind:str, rank:str, star:int, seed:int, trait_key:str='') -> str:
    raw=f'VL04|{kind}|{rank}|{star}|{seed}|{trait_key}'.encode()
    return 'VL04-'+hashlib.sha256(raw).hexdigest()[:16]

def distribute(total:int, priority:tuple[str,...], *, minimum:int=0, maximum:int|None=None) -> dict[str,int]:
    """A documented LAB choice, not a canonical distribution of points."""
    if not isinstance(total,int) or total < len(ATTRS)*minimum:
        raise BuildError('Not enough points for distribution')
    order=list(priority)
    if sorted(order)!=sorted(ATTRS):
        raise BuildError('Priority must list six attributes exactly once')
    data={a:minimum for a in ATTRS}
    remain=total-len(ATTRS)*minimum
    while remain:
        progressed=False
        for a in order:
            if maximum is None or data[a]<maximum:
                data[a]+=1
                remain-=1
                progressed=True
                if not remain:break
        if not progressed:
            raise BuildError('Distribution exceeds attribute cap')
    return data

def add_points(attrs:dict[str,int], qty:int, priority:tuple[str,...]) -> dict[str,int]:
    tmp=attrs.copy()
    for i in range(qty):tmp[priority[i%len(priority)]]+=1
    return tmp

def fixed60(die:int)->int:
    return int((Decimal(die)*Decimal('0.6')).quantize(Decimal('1'),rounding=ROUND_HALF_UP))

def fraction_payload(f:Fraction)->dict[str,Any]:
    return {'numerator':f.numerator,'denominator':f.denominator,'exact':str(f),'integer_ready':f.denominator==1}

@dataclass(frozen=True)
class ActorSnapshot:
    actor_id:str
    actor_kind:str
    actor_mode:str
    canonical_entity_id:str|None
    rank:str
    star:int
    level:int
    race_or_species:str
    stats:dict[str,int]
    health:int|None
    soul:int|None
    pa_total:int|None
    pa_free:int|None
    ca:dict[str,Any]
    rd:int|None
    physical_force:int
    ff_milestones:tuple[dict[str,Any],...]
    test_dice:str|None
    base_attack_dice:str|None
    traits:tuple[str,...]
    knowledge_state:str
    missing_for_full_fight:tuple[str,...]
    derivations:dict[str,str]
    source_refs:dict[str,str]
    seed:int
    policy:str
    schema_version:str='VL04-0.1'

    def to_json(self)->str:
        return json.dumps(asdict(self),ensure_ascii=False,sort_keys=True,separators=(',',':'))

    @property
    def full_fight_eligible(self)->bool:
        return not self.missing_for_full_fight


def _ff_locks(stats:dict[str,int], seed:int, preference:str='damage') -> tuple[dict[str,Any],...]:
    # Choice at each +100 FF is permanent. Choice preference here is LAB policy only.
    if preference not in ('damage','ca','health'):
        raise BuildError('Unknown FF preference')
    ff=sum(stats[a] for a in ('FOR','DES','CON'))*10
    result=[]
    for mark in range(100,(ff//100)*100+1,100):
        rng=random.Random(f'VL04:FF:{seed}:{mark}:{preference}')
        dice=(1,4) if preference!='health' else (2,6)
        total=sum(rng.randint(1,dice[1]) for _ in range(dice[0]))
        result.append({'milestone_ff':mark,'choice':preference,'fixed_roll':total,'roll_dice':f'{dice[0]}d{dice[1]}','status':'LAB-CHOICE-LOCKED'})
    return tuple(result)


def build_human(rank:str,star:int,seed:int=101,*,priority:tuple[str,...]=('FOR','DES','CON','INT','SAB','CAR'),ff_preference:str='damage')->ActorSnapshot:
    lv=ordinal(rank,star)
    # 25 initial points with Human 2..6 cap. +2/level, recorded as LAB policy.
    base=distribute(25,priority,minimum=2,maximum=6)
    stats=base.copy()
    birth_con=base['CON'];birth_int=base['INT']
    life=10+birth_con;soul=10+birth_int
    history=[]
    for level in range(1,lv+1):
        stats=add_points(stats,2,priority)
        current_rank=rank_at(level)
        rolled=fixed60(LIFE_DICE[current_rank])
        if level==1 or (level-1)%5==0:
            # Recalculation at classification change according to current CON/INT.
            life=(10+birth_con)+level*(rolled+stats['CON'])
            soul=(10+birth_int)+level*(rolled+stats['INT'])
        else:
            life+=rolled+stats['CON']
            soul+=rolled+stats['INT']
        history.append({'lv':level,'rank':current_rank,'CON':stats['CON'],'INT':stats['INT'],'growth_fixed':rolled})
    ff=sum(stats[x] for x in ('FOR','DES','CON'))*10
    locks=_ff_locks(stats,seed,ff_preference)
    bonus_hp=sum(x['fixed_roll'] for x in locks if x['choice']=='health')
    ca_base=6+stats['DES']
    bonus_ca=sum(x['fixed_roll'] for x in locks if x['choice']=='ca')
    return ActorSnapshot(
        actor_id=deterministic_id('ED-Human',rank,star,seed,ff_preference+','.join(priority)),actor_kind='ED',
        actor_mode='RULE-DERIVED-VIRTUAL',canonical_entity_id=None,rank=rank,star=star,level=lv,
        race_or_species='Humano - arquétipo experimental',stats=stats,health=life+bonus_hp,
        soul=soul,pa_total=soul,pa_free=soul,ca=fraction_payload(Fraction(ca_base+bonus_ca)),rd=None,
        physical_force=ff,ff_milestones=locks,test_dice=RANK_TEST_DICE[rank],base_attack_dice=None,
        traits=(),knowledge_state='RULE-DERIVED; no canonical existence',
        missing_for_full_fight=('known_attack_with_full_damage_expression','weapon_equipment','proficiencies','defense_reaction_policy','movement_range','tactical_policy'),
        derivations={'initial':'25 attribute points; each attribute 2..6 at birth; LAB allocation policy '+','.join(priority),
                     'progression':'+2 points per level, a documented laboratory interpretation of Human +2/estrela; confirm with source at edge Bronze1',
                     'life':'Initial 10+birth CON; fixed60 rank growth plus current CON, retro recomputation on rank change',
                     'soul':'Initial 10+birth INT; same rank growth and recomputation; PA is soul, not independent mana',
                     'CA':'6+DES; equipment=0 as explicit unarmored laboratory choice; FF bonuses included only if chosen',
                     'FF':'(FOR+DES+CON)*10; per 100 fixed seeded choice/roll persisted in actor snapshot',
                     'history_sha256':hashlib.sha256(json.dumps(history,sort_keys=True).encode()).hexdigest(),
                     'limitations':'No canonical proficiency/attack/weapon or tactics invented; full-fight blocked'},
        source_refs={k:REFS[k] for k in ('character','combat','damage')},seed=seed,policy='round_robin_allocation_'+ff_preference,
    )


def build_beast(rank:str,star:int,seed:int=101,*,priority:tuple[str,...]=('FOR','CON','DES','INT','SAB','CAR'),
                explicit_traits:tuple[str,...]=(),elements:tuple[str,...]=(),titan_before_legendary:bool=False)->ActorSnapshot:
    lv=ordinal(rank,star)
    if any(t not in KNOWN_TRAITS for t in explicit_traits):
        raise BuildError('Unknown bestial trait — no invention permitted')
    if len(set(explicit_traits))!=len(explicit_traits):
        raise BuildError('Duplicate traits')
    if ('Elemental' in explicit_traits) != bool(elements):
        raise BuildError('Elemental trait requires explicit elements, not inferred')
    if len(set(elements))!=len(elements):
        raise BuildError('Duplicate element names')
    # No special flags granted by the laboratory unless explicitly listed as premise.
    legendary=rank=='Lendário'
    traits=set(explicit_traits)
    if legendary:traits.add('Titã')  # expressly automatic on legendary ascension
    if titan_before_legendary and 'Titã' not in explicit_traits:
        raise BuildError('Prior Titan requires explicit Titan trait')
    if legendary and 'Titã' in explicit_traits and not titan_before_legendary:
        raise BuildError('Explicit Titan at Legendary requires prior-Titan provenance; omit to use automatic ascension')
    # For a non-legendary Titan, initial base=60. Ascension switches from 30 to 60.
    base=distribute(35,priority)
    st=base.copy()
    life=30;soul=30
    elem_count=len(elements)
    history=[]
    for level in range(1,lv+1):
        rl=rank_at(level)
        is_legend=rl=='Lendário'
        explicit_non_titan=sum(v for t,v in KNOWN_TRAITS.items() if t in explicit_traits and t not in ('Titã',))
        titan_delta=5 if 'Titã' in explicit_traits else (5 if is_legend else 0)
        bonus_level=8+explicit_non_titan+titan_delta
        if is_legend:
            # Retrospective Legendary +6 and +1 per element per level; if Titan was already present, add +2 vs new +5.
            retro=level*(6+elem_count+(2 if titan_before_legendary else 0))
            current_without_retro=add_points(base,bonus_level*level,priority)
            st=add_points(current_without_retro,retro,priority)
        else:
            st=add_points(base,bonus_level*level,priority)
        is_titan_now=('Titã' in explicit_traits) or is_legend
        hp_base=60 if is_titan_now else 30
        per_star={'Bronze':20,'Prata':40,'Ouro':60,'Ouro Negro':80,'Lendário':100}[rl] if is_titan_now else {'Bronze':10,'Prata':20,'Ouro':30,'Ouro Negro':40}[rl]
        if level==1 or (level-1)%5==0:
            life=hp_base+level*(per_star+st['CON'])
            soul=hp_base+level*(per_star+st['INT'])
        else:
            life+=per_star+st['CON']
            soul+=per_star+st['INT']
        history.append((level,st['CON'],st['INT'],is_titan_now))
    is_titan='Titã' in traits
    ca=Fraction(20 if is_titan else 10)+st['DES']+Fraction(st['CON'],5)
    use_rd_titan=is_titan or st['CON']>100
    rd=BEAST_RD_TITAN[rank] if use_rd_titan else BEAST_RD_NORMAL[rank]
    if 'Besta Divina' in traits:
        # Specialized table includes 120 RD and 30d12 damage, but source interaction with nominal rank needs QA.
        rd=120
    base_damage=('30d12' if 'Besta Divina' in traits else TITAN_BASE_ATTACK[rank] if is_titan else BESTIAL_BASE_ATTACK[rank])
    blocks=['proficiency/accuracy_source_and_attack_test','attack_action_contract','defense_reaction_policy','movement_range','tactical_policy','PA-usage_mapping_not_confirmed_for_beast']
    if ca.denominator!=1:blocks.append('GAP-01_CA_fraction_without_rounding_authority')
    if 'ADM' in traits or 'Besta Divina' in traits:blocks.append('special_flag_full_stats_and_access_validation')
    specialized_vitals=bool(traits.intersection({'Besta Divina','Chefe de Reino Subsidiário'}))
    if specialized_vitals: blocks.append('SPECIAL_VITALS_140_TABLE_APPLICABILITY_UNRESOLVED')
    return ActorSnapshot(
        actor_id=deterministic_id('BE',rank,star,seed,','.join(sorted(traits))+str(elements)+','.join(priority)),actor_kind='BE',
        actor_mode='RULE-DERIVED-VIRTUAL' if not explicit_traits else 'CONDITIONAL-SENSITIVITY',
        canonical_entity_id=None,rank=rank,star=star,level=lv,race_or_species='Besta virtual sem identidade canônica',
        stats=st,health=None if specialized_vitals else life,soul=None if specialized_vitals else soul,pa_total=None,pa_free=None,ca=fraction_payload(ca),rd=rd,
        physical_force=sum(st[a] for a in ('FOR','DES','CON'))*10,ff_milestones=(),
        test_dice=None,base_attack_dice=base_damage,traits=tuple(sorted(traits)),
        knowledge_state='RULE-DERIVED bestial base; conditional explicit traits, no canon instance',
        missing_for_full_fight=tuple(blocks),
        derivations={'initial':'35 points distributed under LAB priority '+','.join(priority),
                     'growth':'normal +8 per level; source-authorized explicit traits only; Legendary ascent is Titan + retrospective bonuses',
                     'life':'Beast rank per-star progression; reset on rank change; CON at each star preserved within rank',
                     'soul':'same with INT; special Divine/Chief 140 progression not auto-assumed; PA remains None without source',
                     'CA':'Exact rational: '+('20' if is_titan else '10')+'+DES+CON/5. NO invented rounding',
                     'RD':'Special Titan/CON>100 table when applicable; Divine row flagged conditional',
                     'attack':'bestial attack dice by normal/Titan table; damage attack event needs remaining accuracy/action/target sources',
                     'history_sha256':hashlib.sha256(repr(history).encode()).hexdigest()},
        source_refs={k:REFS[k] for k in ('beast','damage','combat')},seed=seed,policy='round_robin_attr_allocation',
    )

def scenario_template(team_a:tuple[ActorSnapshot,...],team_b:tuple[ActorSnapshot,...],case_id:str)->dict[str,Any]:
    """Plans a scenario; does not run an event. Supports N×M without new mechanics."""
    if not team_a or not team_b or len(team_a)+len(team_b)>200:
        raise BuildError('Scenario size out of laboratory preview limits')
    ids=[a.actor_id for a in (*team_a,*team_b)]
    if len(ids)!=len(set(ids)):
        raise BuildError('Actor ids must be unique per scenario: change each actor seed')
    return {'case_id':case_id,'mode':'DESIGN-ONLY','teams':{'A':ids[:len(team_a)],'B':ids[len(team_a):]},
            'roster_size':len(ids),'rule_version':'DMG-RANK-01-v1.1-READ-ONLY',
            'actor_fingerprints':{x.actor_id:hashlib.sha256(x.to_json().encode()).hexdigest() for x in (*team_a,*team_b)},
            'ready_for_full_fight':all(x.full_fight_eligible for x in (*team_a,*team_b)),
            'status':'SCENARIO-TEMPLATE-NOT-RUN','events_executed':0,'notion_character_pages_created':0}

# L04.1 expansion: four further canonical races as RULE-DERIVED laboratory builds.
RACE_PROFILES = {
    'Orc': {'extra':12,'growth':5,'life_steps':2,'soul_steps':0,'extra_scope':('FOR','DES','CON')},
    'Abissiano': {'extra':12,'growth':5,'life_steps':0,'soul_steps':2,'extra_scope':('INT','SAB','CAR')},
    'Asa Prateada': {'extra':5,'growth':4,'life_steps':0,'soul_steps':1,'extra_scope':('DES',)},
    'Raça Superior': {'extra':20,'growth':8,'life_steps':2,'soul_steps':2,'extra_scope':None},
}
DICE_LADDER = (6,8,10,12,20,30,40,50,60)

def build_other_race(rank:str,star:int,race:str,seed:int=101,
                     *,priority:tuple[str,...]=('FOR','DES','CON','INT','SAB','CAR'),
                     ff_preference:str='damage')->ActorSnapshot:
    """Build Orc/Abissiano/Asa Prateada/Raça Superior as synthetic noncanonical actors.

    This selects a legal LAB distribution; it does not claim the user chose it.
    """
    lv=ordinal(rank,star)
    if race not in RACE_PROFILES:raise BuildError('Not an implemented official race; no invented race')
    cfg=RACE_PROFILES[race]
    if race=='Raça Superior':
        initial=distribute(45,priority,minimum=4,maximum=15)
    else:
        initial=distribute(25,priority,minimum=0)
        extras=cfg['extra_scope']
        for i in range(cfg['extra']):initial[extras[i%len(extras)]]+=1
        if race in ('Orc','Abissiano') and any(not 5<=initial[a]<=15 for a in extras):
            raise BuildError('Initial constrained race attributes violate legal 5..15 bound')
        if race=='Asa Prateada' and initial['DES']>15:
            raise BuildError('Asa Prateada initial DES may not exceed 15')
    if sum(initial.values())!=25+cfg['extra']:
        raise AssertionError('Initial allocation checksum')
    birth_con=initial['CON'];birth_int=initial['INT']
    stats=initial.copy()
    life=10+birth_con;soul=10+birth_int
    history=[]
    for level in range(1,lv+1):
        stats=add_points(stats,cfg['growth'],priority)
        rk=rank_at(level);idx=RANKS.index(rk)
        hp_die=fixed60(DICE_LADDER[idx+cfg['life_steps']]);pa_die=fixed60(DICE_LADDER[idx+cfg['soul_steps']])
        if level==1 or (level-1)%5==0:
            life=(10+birth_con)+level*(hp_die+stats['CON'])
            soul=(10+birth_int)+level*(pa_die+stats['INT'])
        else:
            life+=hp_die+stats['CON'];soul+=pa_die+stats['INT']
        history.append((level,rk,stats['CON'],stats['INT'],hp_die,pa_die))
    locks=_ff_locks(stats,seed,ff_preference)
    ff=sum(stats[a] for a in ('FOR','DES','CON'))*10
    ff_hp=sum(m['fixed_roll'] for m in locks if m['choice']=='health')
    ff_ca=sum(m['fixed_roll'] for m in locks if m['choice']=='ca')
    if race=='Orc':ca=Fraction(12)+Fraction(stats['DES'],4)+stats['CON']+ff_ca
    elif race in ('Abissiano','Asa Prateada'):ca=Fraction(9+stats['DES']+ff_ca)
    else:ca=Fraction(9+ff_ca)
    gaps=['known_attack_with_full_damage_expression','weapon_equipment','proficiencies','defense_reaction_policy','movement_range','tactical_policy']
    if ca.denominator!=1:gaps.append('GAP-01_CA_fraction_without_rounding_authority')
    return ActorSnapshot(
        actor_id=deterministic_id('ED-'+race,rank,star,seed,ff_preference+','.join(priority)),
        actor_kind='ED',actor_mode='RULE-DERIVED-VIRTUAL',canonical_entity_id=None,
        rank=rank,star=star,level=lv,race_or_species=race+' - arquétipo experimental',
        stats=stats,health=life+ff_hp,soul=soul,pa_total=soul,pa_free=soul,
        ca=fraction_payload(ca),rd=None,physical_force=ff,ff_milestones=locks,
        test_dice=RANK_TEST_DICE[rank],base_attack_dice=None,traits=(),
        knowledge_state='LAB allocation for race; no canonical actor identity',
        missing_for_full_fight=tuple(gaps),
        derivations={'initial':f'{race}: {25}+{cfg["extra"]} attributes; extra restriction {cfg["extra_scope"]}; policy round_robin '+','.join(priority),
                     'progression':f'+{cfg["growth"]} per level for {race}; interpretation Bronze1 treated as first level of progression',
                     'life':f'die rank step +{cfg["life_steps"]}, fixed 60%, initial 10+birth CON, rank change recomputation',
                     'soul':f'die rank step +{cfg["soul_steps"]}, fixed 60%, initial 10+birth INT, rank change recomputation',
                     'CA':'exact Fraction race formula with explicit no-armor LAB choice and FF CA choice if present',
                     'FF':'(FOR+DES+CON)*10; seeded permanent milestones',
                     'history_sha256':hashlib.sha256(repr(history).encode()).hexdigest(),
                     'limitations':'No equipment, skills, spell or attack magnitude invented; full-fight blocked'},
        source_refs={k:REFS[k] for k in ('character','combat','damage')},seed=seed,
        policy='round_robin_racial_distribution_'+ff_preference,
    )
