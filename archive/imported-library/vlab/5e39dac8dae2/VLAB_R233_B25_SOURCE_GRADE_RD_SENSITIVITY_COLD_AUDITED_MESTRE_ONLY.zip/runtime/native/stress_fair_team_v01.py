"""Deterministic repeatability and mirror parity, v0.1 LAB ONLY."""
import json,hashlib
from collections import Counter
from vlab_fair_team_v01 import sample_2v1,mirrors,run,identity_key
from vlab_l05_preflight import RulesUnresolved

def assess(total=2000):
    roster=sample_2v1();c=Counter();one=None
    for seed in range(1,total+1):
        try:r=mirrors(roster,seed)
        except RulesUnresolved as e:
            kind=str(e)
            if 'TIED-INITIATIVE' in kind:c['blocked_tie']+=1
            elif 'CRITICAL-CONSEQUENCE' in kind:c['blocked_critical']+=1
            else:c['blocked_other']+=1
            continue
        c['completed']+=1
        for name in ('mirror_trace_equal','initiatives_equal','states_equal','winner_actor_set_equal','winner_side_swapped'):
            if not r[name]:c['FAILED_'+name]+=1
        if one is None:one={'seed':seed,'details':r}
    assert sum(c[k] for k in ('completed','blocked_tie','blocked_critical','blocked_other'))==total
    assert all(not k.startswith('FAILED') for k in c),c
    # Team size 40 is only a source of structurally valid ROSTER, not a realistic war.
    return {'protocol':'FAIR-MIRROR-2x1-v01','seeds_attempted':total,'counts':dict(c),'first_valid_sample':one,
            'fairness_result':'MIRROR-SYMMETRY-PASS among completed conditional runs, not equal-strength proof',
            'execution':'limited-attack-only LAB; NO spells/movement/defensive reactions/monsters',
            'canonical_grid_credit':0,'policy_version':'TACTICAL-OBSERVABLE-v0.1'}
if __name__=='__main__':
    print(json.dumps(assess(),ensure_ascii=False,indent=2))
