"""Side-symmetric team scheduler benchmark. Only vanilla Bronze1 ED attack adapter.
NO RD, magic, reaction, critical-failure consequence, movement. Side swaps are
exactly mirrored using per-actor RNG paths unaffected by side labels. Lab-only.
"""
from __future__ import annotations
import hashlib,json
from copy import deepcopy
from collections import Counter
from vlab_l05_duel import dice_for,_hash,_stable_json,build_sample_fixture,frozen_fixture
from vlab_l05_preflight import ActionBudget,RulesUnresolved,classify_critical_sequence,determine_attack_success
from vlab_l04 import build_human
from vlab_tactical_policy_v01 import TacticalObservation,LegalAction,choose

VERSION='VL07-SIDE-INVARIANT-0.1'


def identity_key(roster:list[dict])->str:
    """Normalize team by member IDs; team names and input order cannot affect RNG."""
    teams={x['team'] for x in roster}
    if len(teams)!=2:raise ValueError('Exactly two team IDs')
    pairs=sorted(tuple(sorted(x['actor_id'] for x in roster if x['team']==team)) for team in teams)
    identities=sorted((x['actor_id'],x['attributes'],x['health'],x['defense_ca'],x['ff_damage_fixed']) for x in roster)
    return _hash({'teams':pairs,'identities':identities,'scenario':'static-adjacent-basic-attack','version':VERSION})[:16]

def run(roster:list[dict],seed:int,max_rounds:int=30):
    if not 2<=len(roster)<=40:raise ValueError('Supported test roster 2..40, not production benchmark')
    if not 1<=max_rounds<=100:raise ValueError('invalid round budget')
    ids=[x['actor_id'] for x in roster]
    if len(set(ids))!=len(ids):raise ValueError('Actor IDs must be globally unique')
    if len({x['team'] for x in roster})!=2:raise ValueError('two teams')
    for x in roster:
        if not x.get('eligible_for_this_restricted_lab_profile') or x['rank']!='Bronze' or x['star']!=1:
            raise ValueError('fixture outside narrow conditional combat adapter')
    key=identity_key(roster)
    byid={x['actor_id']:x for x in roster}
    # one shared RNG keyed only to actor ID; same rolls in A/B permutation
    die={aid:dice_for(seed,key,f'INIT:{aid}',6)[0] for aid in ids}
    init={aid:die[aid]+byid[aid]['attributes']['DES']+byid[aid]['initiative_bonus'] for aid in ids}
    # canonical tiebreak still missing -> fail closed
    if len(set(init.values()))!=len(init):raise RulesUnresolved('TIED-INITIATIVE')
    order=sorted(ids,key=lambda aid:-init[aid]);hp={aid:byid[aid]['health'] for aid in ids}
    events=[];winning_team=None
    for rnd in range(1,max_rounds+1):
        budgets={aid:ActionBudget() for aid in ids}
        for aid in order:
            actor=byid[aid]
            if hp[aid]<=0:continue
            enemies=[byid[x] for x in ids if byid[x]['team']!=actor['team'] and hp[x]>0]
            if not enemies:continue
            # both teams call precisely SAME observation-based policy
            opts=tuple(LegalAction(action_id=f'attack:{e["actor_id"]}',kind='attack',target_id=e['actor_id'],
                target_visible_condition='critical' if hp[e['actor_id']]/e['health']<=0.30 else 'injured' if hp[e['actor_id']]/e['health']<=0.70 else 'normal',cost_class='low') for e in enemies)
            obs=TacticalObservation(actor_id=aid,role='striker',tier='basic',own_health_fraction=hp[aid]/actor['health'],observed_enemy_count=len(enemies))
            decision=choose(obs,opts)
            targetid=decision.target_id; target=byid[targetid]
            budgets[aid].spend('STANDARD')
            att=dice_for(seed,key,f'ROUND:{rnd}:ATTACK:{aid}',6)[0]
            score=att+actor['attributes']['FOR']+actor['luta_prof_bonus']
            hit=determine_attack_success(score,target['defense_ca'])
            crit=dice_for(seed,key,f'ROUND:{rnd}:CRIT:{aid}',6,3)
            status=classify_critical_sequence(tuple(crit))
            if status=='CRITICAL-FAIL':raise RulesUnresolved('CRITICAL-CONSEQUENCE-UNKNOWN')
            dmgdice=dice_for(seed,key,f'ROUND:{rnd}:DAMAGE:{aid}',4)[0] if hit else 0
            dmg=(dmgdice+actor['ff_damage_fixed']+(4 if status=='POSITIVE-CRIT' else 0)) if hit else 0
            before=hp[targetid];hp[targetid]=max(0,before-dmg)
            events.append({'round':rnd,'actor_id':aid,'target_id':targetid,'team':actor['team'],
                  'target_team':target['team'],'policy':decision.policy_version,'decision':decision.action_id,
                  'decision_reasons':decision.reasons,'attack_roll':att,'attack_score':score,'target_CA':target['defense_ca'],
                  'crit_rolls':crit,'critical_status':status,'damage_die':dmgdice,'damage':dmg,
                  'target_HP_before':before,'target_HP_after':hp[targetid]})
            alive={byid[x]['team'] for x in ids if hp[x]>0}
            if len(alive)==1:winning_team=next(iter(alive));break
        if winning_team:break
    result={'version':VERSION,'mode':'LAB-CONDITIONAL-NOT-CANONICAL','case_id':key,'seed':seed,
        'teams':{team:sorted([x['actor_id'] for x in roster if x['team']==team]) for team in sorted({x['team'] for x in roster})},
        'init_by_actor':init,'init_order':order,'HP_final_by_actor':hp,'rounds':rnd,
        'events':events,'event_count':len(events),'winner_by_lab_threshold':winning_team,
        'winner_actor_set':sorted(x['actor_id'] for x in roster if x['team']==winning_team) if winning_team else None,
        'canonical_credit':0,'limitations':['no magic/RD/reaction/position/movement','HP0 LAB END ONLY','crit failure abort','initiative ties abort']}
    result['digest']=_hash(result)
    return result

def canonical_event_trace(result:dict)->list[dict]:
    """Remove group *labels* while keeping actor identity; parity requires equality."""
    return [{k:v for k,v in ev.items() if k not in ('team','target_team')} for ev in result['events']]

def mirrors(roster:list[dict],seed:int):
    copy=deepcopy(roster)
    a,b=sorted({x['team'] for x in roster});
    for actor in copy:actor['team']=b if actor['team']==a else a
    r1=run(roster,seed);r2=run(copy,seed)
    return {'mirror_trace_equal':canonical_event_trace(r1)==canonical_event_trace(r2),
            'initiatives_equal':r1['init_by_actor']==r2['init_by_actor'],
            'states_equal':r1['HP_final_by_actor']==r2['HP_final_by_actor'],
            'winner_actor_set_equal':r1['winner_actor_set']==r2['winner_actor_set'],
            'winner_side_swapped':r1['winner_by_lab_threshold']!=r2['winner_by_lab_threshold'] if r1['winner_by_lab_threshold'] else r2['winner_by_lab_threshold'] is None,
            'events':len(r1['events']),'winner_original':r1['winner_by_lab_threshold'],'winner_swapped':r2['winner_by_lab_threshold'],
            'sha_original':r1['digest'],'sha_swapped':r2['digest']}

def sample_2v1():
    p1=('FOR','DES','CON','INT','SAB','CAR');p2=('DES','CON','FOR','SAB','INT','CAR');p3=('CON','FOR','DES','INT','SAB','CAR')
    actors=[frozen_fixture(build_human('Bronze',1,s,priority=p),side=team) for s,p,team in [(101,p1,'A'),(202,p2,'A'),(303,p3,'B')]]
    for a in actors:a['team']=a['side']
    return actors

if __name__=='__main__':
    r=sample_2v1()
    c=Counter();samples=[]
    for seed in range(1,2000):
        try:v=mirrors(r,seed)
        except RulesUnresolved:continue
        assert all(v[k] for k in ('mirror_trace_equal','initiatives_equal','states_equal','winner_actor_set_equal','winner_side_swapped')),v
        samples.append(v);c['valid']+=1
        if len(samples)>=100:break
    print(json.dumps({'valid_pairs':len(samples),'sample':samples[0] if samples else None},indent=2))
