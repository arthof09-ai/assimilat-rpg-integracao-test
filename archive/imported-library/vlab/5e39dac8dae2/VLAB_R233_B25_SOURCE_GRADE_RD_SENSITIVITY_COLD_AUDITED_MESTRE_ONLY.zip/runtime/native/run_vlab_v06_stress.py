"""QA harness for v0.6 conditional mixed ED/BE, NOT official simulated combats."""
from __future__ import annotations
import json,hashlib,time,random,statistics
from pathlib import Path
from collections import Counter
from dataclasses import replace,asdict
from vlab_beast_benchmark_v06 import sample_rosters,make_actor,run,mirror,digest
from audit_vlab_beast_v06 import audit
from vlab_l04 import build_human,build_beast,build_other_race

OUT=Path(__file__).resolve().parent/'samples';OUT.mkdir(exist_ok=True)

def write_json(name,obj):
 p=OUT/name;p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,default=str),encoding='utf-8')
 return {'filename':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}

def roster_nxn(n:int,seed=612):
 a=[]
 for i in range(n):
  rk,star=(('Bronze',1) if i%5<4 else ('Prata',1))
  a.append(make_actor(build_human(rk,star,seed+i*13),'A',seed=seed+i,style=('disciplined','duelist','cautious','skirmisher','guardian')[i%5]))
 for i in range(n):
  rk,star=(('Bronze',1) if i%5<4 else ('Prata',1))
  a.append(make_actor(build_beast(rk,star,seed+10000+i*17),'B',seed=seed+10_000+i,style=('predator','pack_hunter','territorial','cautious','ambusher')[i%5]))
 return tuple(a)

def party_vs_beast(n:int,seed=713):
    # Different canonical race templates, but the COMBAT MENU is still only one
    # common light attack per ED. Roles are metadata, NOT a real balanced party.
    races=('Humano','Orc','Abissiano','Asa Prateada','Raça Superior')
    roles=('vanguard','striker','controller','support','guardian')
    styles=('guardian','duelist','disciplined','skirmisher','cautious')
    players=[]
    for i in range(n):
        race=races[i%len(races)]
        snapshot=(build_human('Bronze',1,seed+i*17) if race=='Humano' else
                  build_other_race('Bronze',1,race,seed+i*17))
        players.append(make_actor(snapshot,'A',role=roles[i%len(roles)],style=styles[i%len(styles)],seed=seed+i))
    players.append(make_actor(build_beast('Bronze',1,seed+10000),'B',style='predator',seed=seed+10000))
    return tuple(players)

def check_mirror(r,seed,rd_mode):
 m=mirror(r,seed,rd_mode)
 keys=('same_events','same_hp','same_initiative','same_winner_actors','same_trace_digest','side_winner_inverted')
 assert all(m[k] for k in keys), {k:m[k] for k in keys}
 return {k:m[k] for k in keys}

def main():
 results={'version':'VLAB-MIXED-SENSITIVITY-v0.6','authority':'MESTRE-ONLY LAB-ASSUMPTION','official_cells_credited':0,
     'source_fully_eligible':False,'runs':{},'sources':['Criação de Ficha','Criação de Besta','Sistema de Combate','DMG-RANK-01 v1.1'],
     'limitations':['RD-subtract hypothetical','initiative tie seeded lab policy','critical fail no effect lab',
       'HP zero lab stop','BE generic proficiency as Luta hypothetical',
       'BE base attack as one attack assumption','ED common weapon +2 Luta chosen',
       'no spells/reactions/movement/control/positioning resolved in fight',
       'ranks mixed in 10x10 and 20x20 are not balanced challenge design']}
 files=[]
 for n,r in ([('1x1',sample_rosters()[0]),('2x1',sample_rosters()[1])]
             + [(f'{group}x1',party_vs_beast(group)) for group in (3,4,5)]):
  row={}
  for rd_mode in ('SUBTRACT-LAB','OFF-LAB'):
   started=time.perf_counter();wins=Counter();turns=[]; events=0;checks=0
   for seed in range(1,251):
    x=run(r,seed,rd_mode=rd_mode)
    v=audit(r,x)
    m=check_mirror(r,seed,rd_mode)
    checks+=v['checks'];events+=x['event_count']
    wins[x['winner_by_lab_hp_threshold'] or x['stop_reason']]+=1
    turns.append(x['rounds'])
   sample=run(r,101,rd_mode=rd_mode)
   row[rd_mode]={'seeds':250,'outcomes':dict(wins),'mean_rounds':sum(turns)/len(turns),
            'events_validated':events,'auditor_checks':checks,'mirrors_exact':250,
            'elapsed_seconds':round(time.perf_counter()-started,3),'example_seed101':{'outcome':sample['winner_by_lab_hp_threshold'],
            'rounds':sample['rounds'],'events':sample['event_count'],'hp':sample['HP'],
            'trace_digest':sample['trace_digest']}}
   files.append(write_json(f'vlab_v06_{n}_{rd_mode}_seed101_full_log.json',sample))
  results['runs'][n]=row
 for n in (10,20):
  r=roster_nxn(n)
  cases=[]
  for seed in (101,202,303):
   start=time.perf_counter()
   x=run(r,seed,max_rounds=20,rd_mode='SUBTRACT-LAB');auditout=audit(r,x)
   mirrored=check_mirror(r,seed,'SUBTRACT-LAB')
   cases.append({'seed':seed,'rounds':x['rounds'],'events':x['event_count'],
                 'winner':x['winner_by_lab_hp_threshold'],'complete':x['complete'],'stop_reason':x['stop_reason'],
                 'checks':auditout['checks'],'mirror':all(mirrored.values()),'runtime_seconds':round(time.perf_counter()-start,3),
                 'trace_digest':x['trace_digest']})
   if seed==101:files.append(write_json(f'vlab_v06_{n}x{n}_seed101_conditional_trace.json',x))
  results['runs'][f'{n}x{n}']={'cases':cases,'roster_size':2*n,'ranks':{'Bronze1':2*n-(2*n//5),'Prata1':2*n//5}}
 results['artifact_files']=files
 files.append(write_json('vlab_v06_stress_summary.json',results))
 print(json.dumps({k:v for k,v in results.items() if k!='artifact_files'},ensure_ascii=False,indent=2))
 print('artifacts',json.dumps(files,ensure_ascii=False))

if __name__=='__main__':main()
