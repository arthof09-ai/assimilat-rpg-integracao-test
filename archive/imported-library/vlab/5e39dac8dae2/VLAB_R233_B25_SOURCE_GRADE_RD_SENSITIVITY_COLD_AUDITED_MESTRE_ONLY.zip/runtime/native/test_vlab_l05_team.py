import unittest
from vlab_l05_preflight import RulesUnresolved
from vlab_l05_team import sample_team_roster, run_team, replay_team, TeamNotEligible
class TeamTests(unittest.TestCase):
    def setUp(self):self.actors=sample_team_roster()
    def completed(self):
        for i in range(1,1000):
            try:r=run_team(self.actors,seed=i)
            except RulesUnresolved:continue
            if r['winner_by_lab_threshold']:return r
        self.fail('No completed conditional team case')
    def test_team_distinct(self):self.assertEqual(len({a['actor_id'] for a in self.actors}),3)
    def test_team_size(self):self.assertEqual([v['side'] for v in self.actors],['A1','A2','B1'])
    def test_replay(self):self.assertTrue(replay_team(self.completed())['pass'])
    def test_no_core_credit(self):
        r=self.completed();self.assertEqual(r['core_grid_credit'],0);self.assertFalse(r['full_canon_combat'])
    def test_targeting_respects_teams(self):
        r=self.completed()
        for event in r['events']:
            self.assertNotEqual(event['actor'][0],event['target'][0])
    def test_hp_never_negative(self):
        r=self.completed();self.assertTrue(all(h>=0 for h in r['HP_final'].values()))
        self.assertEqual(len(r['events']),r['event_count'])
    def test_budget_independent(self):
        r=self.completed()
        for e in r['events']:
            self.assertEqual(e['action_budget_after']['standard'],0)
            self.assertEqual(e['action_budget_after']['reaction'],1)
    def test_reject_duplicates(self):
        with self.assertRaises(TeamNotEligible):run_team([self.actors[0]]*3,seed=1)
    def test_ties_fail_closed(self):
        count=0
        for s in range(1,100):
            try:run_team(self.actors,seed=s)
            except RulesUnresolved as e:
                if 'TEAM-INITIATIVE-TIE' in str(e):count+=1
        self.assertGreater(count,0)
if __name__=='__main__':unittest.main()
