"""Regression tests for restricted, explicitly hypothetical/conditional duel."""
import copy, unittest
from vlab_l04 import build_human
from vlab_l05_preflight import RulesUnresolved
from vlab_l05_duel import build_sample_fixture, execute_duel, independent_replay, dice_for, frozen_fixture, DuelNotEligible

class RestrictedDuelTests(unittest.TestCase):
    def setUp(self):self.a,self.b=build_sample_fixture()
    def _completed_seed(self):
        for s in range(1,1000):
            try:r=execute_duel((self.a,self.b),seed=s)
            except RulesUnresolved:continue
            if r['winner_by_lab_stop_condition']:return s,r
        self.fail('No verified completed seed found')
    def test_bronze_1_fixture_identity_and_provenance(self):
        self.assertEqual(self.a['rank'],'Bronze');self.assertEqual(self.b['rank'],'Bronze')
        self.assertEqual(self.a['star'],1);self.assertTrue(self.a['not_general_full_fight_eligible'])
        self.assertEqual(self.a['weapon_damage_dice'],'1d4');self.assertEqual(self.a['luta_prof_bonus'],2)
        self.assertEqual(self.a['defense_ca'],6+self.a['attributes']['DES'])
    def test_no_canonical_actor_or_magic(self):
        self.assertFalse(self.a.get('canonical_entity_id',False))
        self.assertTrue(self.a['actor_id']!=self.b['actor_id'])
    def test_replay_complete_round_trace_identical(self):
        _,r=self._completed_seed()
        proof=independent_replay(r)
        self.assertTrue(proof['replay_passed']);self.assertTrue(proof['matching_event_trace'])
        self.assertEqual(proof['run_digest'],proof['replay_digest'])
    def test_no_fictitious_canon_credit(self):
        _,r=self._completed_seed()
        self.assertFalse(r['full_fight_in_canonical_system'])
        self.assertFalse(r['credit_core_full_fight_baseline'])
        self.assertEqual(r['classification'],'RUN-CONDITIONAL-LAB-NONCANON')
    def test_immutability_and_source_consistency(self):
        before=copy.deepcopy(self.a)
        _,r=self._completed_seed()
        self.assertEqual(before,self.a)
        for e in r['events']:
            self.assertEqual(e['attack_total'],sum(e['attack_dice'])+e['attribute_FOR']+e['luta_prof_bonus'])
            self.assertEqual(e['hit'],e['attack_total']>e['target_CA'])
            self.assertEqual(e['target_hp_after'],max(0,e['target_hp_before']-e['dmg_final']))
            self.assertEqual(len(e['critical_check_sequential']),3)
    def test_seed_isolation(self):
        _,r=self._completed_seed()
        seed=r['rng_seed'];a=dice_for(seed,r['run_key'],'A',6)
        self.assertEqual(a,dice_for(seed,r['run_key'],'A',6))
        self.assertNotEqual(a+dice_for(seed,r['run_key'],'B',6),dice_for(seed+1,r['run_key'],'A',6)+dice_for(seed+1,r['run_key'],'B',6))
    def test_reject_duplicate_actors(self):
        with self.assertRaises(DuelNotEligible):execute_duel((self.a,self.a),seed=1)
    def test_reject_wrong_rank(self):
        with self.assertRaises(DuelNotEligible):frozen_fixture(build_human('Prata',1),side='A')
    def test_reject_unsupported_ff_profile(self):
        with self.assertRaises(DuelNotEligible):frozen_fixture(build_human('Bronze',1,ff_preference='ca'),side='A')
    def test_tied_initiative_fails_closed(self):
        ties=[]
        for s in range(1,120):
            try:execute_duel((self.a,self.b),seed=s)
            except RulesUnresolved as exc:
                if 'TIED-INITIATIVE' in str(exc):ties.append(s)
        self.assertGreater(len(ties),0)
    def test_critical_fail_fails_closed(self):
        found=False
        for s in range(1,1500):
            try:execute_duel((self.a,self.b),seed=s)
            except RulesUnresolved as exc:
                if 'CRITICAL-FAIL' in str(exc):found=True;break
        self.assertTrue(found)
    def test_no_armor_or_rd_created(self):
        self.assertIn('UNARMORED',self.a['rd_mode'])
        self.assertEqual(self.a['defense_ca'],11)
        self.assertGreater(self.a['health'],0)

if __name__=='__main__':unittest.main()
