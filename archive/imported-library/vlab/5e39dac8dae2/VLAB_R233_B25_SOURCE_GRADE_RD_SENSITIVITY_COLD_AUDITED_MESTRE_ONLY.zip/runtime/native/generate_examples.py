from vlab_l04 import RANKS, RACE_PROFILES, build_other_race, build_beast, build_human, scenario_template
import json, hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'samples';out.mkdir(exist_ok=True)
for old in out.glob('50_actor_templates.json'):old.unlink()
actors=[]
for typ in (build_human,build_beast):
    for rank in RANKS:
        for star in range(1,6):
            actors.append(typ(rank,star,seed=777))
for race in RACE_PROFILES:
    for rank in RANKS:
        for star in range(1,6):
            actors.append(build_other_race(rank,star,race,seed=777))
(out/'150_actor_templates.json').write_text(json.dumps([json.loads(a.to_json()) for a in actors],ensure_ascii=False,indent=2),encoding='utf-8')
a=tuple(build_human(RANKS[i%5],(i%5)+1,seed=110+i) for i in range(20))
b=tuple(build_beast(RANKS[i%5],(i%5)+1,seed=210+i) for i in range(20))
scenario=scenario_template(a,b,'WAR20X20-VIRTUAL-TEMPLATE-001')
(out/'war20x20_template.json').write_text(json.dumps(scenario,ensure_ascii=False,indent=2),encoding='utf-8')
manifest={'release':'L04-V0.2','type':'DESIGN-NOT-RUN','rank_star_levels':25,'actor_templates':150,'preview_20x20_actors':40,'full_fights':0,'notion_character_pages':0,'full_fight_eligible':sum(a.full_fight_eligible for a in actors),
          'files':{file.name:hashlib.sha256(file.read_bytes()).hexdigest() for file in sorted(out.iterdir()) if file.name!='manifest.json'}}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},ensure_ascii=False))
