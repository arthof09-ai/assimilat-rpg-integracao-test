"""Experimental small-team scheduler (2×1), same rule adapters as the duel.

All actors are unarmored Human Bronze 1 laboratory templates. No bestial
mitigation or missing source is silently substituted. Team targeting follows
recorded focus-first-alive LAB POLICY; adjacency is frozen as a scenario choice.
NOT a canonical team-combat system, human playtest, or 1,875-grid credit.
"""
from __future__ import annotations
from dataclasses import asdict
import hashlib,json
from vlab_l04 import build_human
from vlab_l05_duel import VERSION,SOURCE_IDS, dice_for, frozen_fixture, _hash, _stable_json
from vlab_l05_preflight import ActionBudget, RulesUnresolved, determine_attack_success, classify_critical_sequence

TEAM_VERSION='VL05-TEAM-0.1'
TEAM_POLICY={
  'formation':'ALL-PARTICIPANTS-ADJACENT-STATIC-LAB-POSITION',
  'weapon':'COMMON-LIGHT-1d4',
  'actions':'EACH-ACTOR-1-STANDARD-ATTACK-PER-ROUND',
  'defensive_reaction':'DECLINE-OPTIONAL',
  'target_choice':'FOCUS-FIRST-LIVE-TARGET-BY-ROSTER-ORDER',
  'end_condition':'ONE-TEAM-AT-LAB-HP-0-ALL; NONCANONICAL',
  'initiative_ties':'REJECT-FAIL-CLOSED',
  'crit_fail':'REJECT-FAIL-CLOSED',
}

class TeamNotEligible(ValueError):pass

def sample_team_roster():
    p1=('FOR','DES','CON','INT','SAB','CAR')
    p2=('DES','CON','FOR','SAB','INT','CAR')
    p3=('CON','FOR','DES','INT','SAB','CAR')
    return (
        frozen_fixture(build_human('Bronze',1,101,priority=p1),side='A1'),
        frozen_fixture(build_human('Bronze',1,202,priority=p2),side='A2'),
        frozen_fixture(build_human('Bronze',1,303,priority=p3),side='B1'),
    )

def run_team(roster, *, seed:int, max_rounds:int=30):
    if len(roster)!=3 or {x['side'] for x in roster}!={'A1','A2','B1'}:
        raise TeamNotEligible('This first team adapter is exactly A1,A2 vs B1')
    if len({x['actor_id'] for x in roster})!=3:raise TeamNotEligible('Duplicate actor snapshots')
    for a in roster:
        if not a['eligible_for_this_restricted_lab_profile'] or a['rank']!='Bronze' or a['star']!=1:
            raise TeamNotEligible('Unsupported actor or rank')
    if not 1<=max_rounds<=1000:raise ValueError('Invalid rounds')
    policy={**TEAM_POLICY,'first_team':'A','second_team':'B'}
    f_hash=_hash({'actors':roster,'policy':policy,'version':TEAM_VERSION})
    key=f_hash[:16]
    # Lab event RNG streams are independent of ordering, stable per team actor.
    init_roll={x['side']:dice_for(seed,key,f'TEAM:INIT:{x["side"]}',6)[0] for x in roster}
    init={x['side']:init_roll[x['side']]+x['attributes']['DES']+x['initiative_bonus'] for x in roster}
    if len(set(init.values()))<3:raise RulesUnresolved('TEAM-INITIATIVE-TIE; no canonical tie breaker')
    order=sorted(roster,key=lambda x:-init[x['side']]);actors={x['side']:x for x in roster}
    hp={x['side']:x['health'] for x in roster};events=[];winner=None
    for round_ix in range(1,max_rounds+1):
        budgets={x['side']:ActionBudget() for x in roster}
        for actor in order:
            own_side=actor['side'];own_team=own_side[0]
            if hp[own_side]<=0:continue
            enemies=[x['side'] for x in roster if x['side'][0]!=own_team and hp[x['side']]>0]
            if not enemies:break
            target_side=enemies[0];target=actors[target_side]
            budgets[own_side].spend('STANDARD')
            attack=dice_for(seed,key,f'ROUND:{round_ix}:TEAM-ATTACK:{own_side}',6)
            total=attack[0]+actor['attributes']['FOR']+actor['luta_prof_bonus']
            crit=dice_for(seed,key,f'ROUND:{round_ix}:TEAM-CRIT:{own_side}',6,3)
            status=classify_critical_sequence(tuple(crit))
            if status=='CRITICAL-FAIL':
                raise RulesUnresolved(f'UNRESOLVED-CRIT-FAIL:{own_side}:{round_ix}')
            hit=determine_attack_success(total,target['defense_ca'])
            d4=dice_for(seed,key,f'ROUND:{round_ix}:TEAM-DAMAGE:{own_side}',4) if hit else []
            damage=sum(d4)+actor['ff_damage_fixed']+(4 if status=='POSITIVE-CRIT' else 0) if hit else 0
            before=hp[target_side]
            hp[target_side]=max(0,hp[target_side]-damage)
            events.append({'round':round_ix,'actor':own_side,'actor_id':actor['actor_id'],
                           'team':own_team,'target':target_side,'action':'STANDARD-ATTACK',
                           'action_budget_after':asdict(budgets[own_side]),'attack_die':attack[0],
                           'FOR':actor['attributes']['FOR'],'Luta_prof':actor['luta_prof_bonus'],
                           'attack_total':total,'target_CA':target['defense_ca'],'hit':hit,
                           'crit_sequential':crit,'crit_status':status,'weapon_1d4':d4,
                           'FF_fixed_on_hit':actor['ff_damage_fixed'] if hit else 0,
                           'damage':damage,'target_HP_before':before,'target_HP_after':hp[target_side]})
            living_teams={side[0] for side,health in hp.items() if health>0}
            if len(living_teams)==1:
                winner=next(iter(living_teams));break
        if winner:break
    record={'protocol':TEAM_VERSION,'mode':'CONDITIONAL-LAB-TEAM-NONCANON',
            'scenario':'2 HUMANO BRONZE1 VS 1 HUMANO BRONZE1','source_refs':SOURCE_IDS,
            'roster':list(roster),'policy':policy,'seed':seed,
            'fixture_hash':f_hash,'run_key':key,'initiative_rolls':init_roll,
            'initiative_totals':init,'order':[x['side'] for x in order],
            'rounds':round_ix,'events':events,'event_count':len(events),
            'HP_final':hp,'winner_by_lab_threshold':winner,
            'status':'LAB-HP-THRESHOLD-REACHED' if winner else 'CENSORED',
            'core_grid_credit':0,'real_human_playtest':False,'full_canon_combat':False,
            'unresolved':['Cannonical consequences HP<=0','Crit failure consequence and timing',
                          'Group tactics/positioning are LAB POLICY; no AoE/reactions/skills'],
           }
    record['digest']=_hash(record)
    return record

def replay_team(run):
    v=run_team(tuple(run['roster']),seed=run['seed'],max_rounds=max(30,run['rounds']))
    return {'pass':_stable_json(v)==_stable_json(run),'events_match':v['events']==run['events'],
            'digest_match':v['digest']==run['digest'],'digest':run['digest']}

if __name__=='__main__':
    for s in range(1,1000):
        try:run=run_team(sample_team_roster(),seed=s)
        except RulesUnresolved:continue
        if run['winner_by_lab_threshold']:
            print(json.dumps({'seed':s,'team_win':run['winner_by_lab_threshold'],'rounds':run['rounds'],
                              'actions':len(run['events']),'hp':run['HP_final'],'replay':replay_team(run)},indent=2));break
