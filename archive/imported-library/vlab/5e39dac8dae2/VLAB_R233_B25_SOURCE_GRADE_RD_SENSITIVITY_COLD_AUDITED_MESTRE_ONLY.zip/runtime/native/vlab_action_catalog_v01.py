"""AIN01 laboratory rule-source action catalog (not an RPG rule).

The catalog only *exposes* legal options when all essential source/effect gates
are satisfied. It NEVER performs an action or grants an ability. Free-form RPG
mechanics from other systems are not imported. MESTRE-SIDE only.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Literal
from vlab_tactical_policy_v02 import SourcedOption

VERSION='ACTION-CATALOG-SOURCE-GATED-v0.1'
ActionEconomy=Literal['STANDARD','MOVEMENT','REACTION','FULL','FREE']
SourceStatus=Literal['EXPLICIT-CANON','RULE-DERIVED','LAB-ASSUMPTION','CONFLICT','UNKNOWN']
TargetScope=Literal['ENEMY','ALLY','SELF','NONE','POSITION','AREA-ENEMY','AREA-ALLY']
ValidKinds={'attack','spell','heal','control','protect','guard','move','retreat','buff','transform','reaction','ready','interact','pass'}

class CatalogError(ValueError):pass

@dataclass(frozen=True)
class FrozenRuleEvidence:
    '''A source proof pointer from a separate Notion reopen/audit, not automatic proof.'''
    source_page_id: str
    rule_id: str
    content_sha256: str
    audited_at: str
    audit_record_id: str

    def __post_init__(self):
        if len(self.content_sha256)!=64 or any(c not in '0123456789abcdef' for c in self.content_sha256):
            raise CatalogError('Need real SHA256 source snapshot fingerprint')
        if not self.audit_record_id or not self.audited_at:
            raise CatalogError('Need physical audit record and time')

@dataclass(frozen=True)
class AbilitySource:
    action_id:str
    kind:str
    economy:ActionEconomy
    source_page_id:str
    rule_id:str
    source_status:SourceStatus
    required_pa:int=0
    target_scope:TargetScope='ENEMY'
    max_targets:int=1
    min_rank_index:int=1
    requires_range_check:bool=False
    requires_line_of_sight:bool=False
    reaction_trigger:str|None=None
    effect_adapter_ready:bool=False
    effect_adapter_id:str|None=None
    cooldown_ready:bool=True

    def __post_init__(self):
        if not self.action_id or not self.source_page_id or not self.rule_id:raise CatalogError('source/action id required')
        if self.kind not in ValidKinds:raise CatalogError('Invalid kind')
        if self.economy not in ('STANDARD','MOVEMENT','REACTION','FULL','FREE'):raise CatalogError('Bad economy')
        if self.target_scope not in ('ENEMY','ALLY','SELF','NONE','POSITION','AREA-ENEMY','AREA-ALLY'):raise CatalogError('Bad target scope')
        if not isinstance(self.required_pa,int) or isinstance(self.required_pa,bool) or self.required_pa<0:raise CatalogError('Bad PA cost')
        if not 1<=self.min_rank_index<=25:raise CatalogError('Bad min rank index')
        if not 0<=self.max_targets<=200:raise CatalogError('Bad max targets')
        if self.economy=='REACTION' and not self.reaction_trigger:raise CatalogError('Reaction trigger required')
        if self.effect_adapter_ready and not self.effect_adapter_id:raise CatalogError('Effect-ready requires adapter ID')

@dataclass(frozen=True)
class ActorActionState:
    actor_id:str
    ordinal_level:int
    available_pa:int|None
    known_action_ids:tuple[str,...]
    standard_available:bool=True
    movement_available:bool=True
    reaction_available:bool=True
    free_action_contract_ready:bool=False
    # true only when legal positional/range/LoS source evaluation completed
    range_confirmed:bool|None=None
    los_confirmed:bool|None=None
    geometry_confirmed:bool|None=None
    reaction_trigger_observed:str|None=None
    enemy_ids_visible:tuple[str,...]=()
    ally_ids_visible:tuple[str,...]=()
    known_area_targets:tuple[str,...]=()
    environment_contract:bool=False

    def __post_init__(self):
        if not self.actor_id:raise CatalogError('actor_id absent')
        if not 1<=self.ordinal_level<=25:raise CatalogError('invalid ordinal')
        if self.available_pa is not None and self.available_pa<0:raise CatalogError('bad PA')
        if len(set(self.known_action_ids))!=len(self.known_action_ids):raise CatalogError('duplicate known abilities')
        if len(set(self.enemy_ids_visible))!=len(self.enemy_ids_visible):raise CatalogError('duplicate enemies')
        if len(set(self.ally_ids_visible))!=len(self.ally_ids_visible):raise CatalogError('duplicate allies')
        if self.actor_id in self.enemy_ids_visible:raise CatalogError('self is not opponent')

@dataclass(frozen=True)
class CatalogCompilation:
    version:str
    actor_id:str
    phase:str
    strict_canonical:bool
    legal_options:tuple[SourcedOption,...]
    rejected:tuple[tuple[str,str],...]
    does_not_resolve_effects:bool=True


def action_menu(actor:ActorActionState,sources:tuple[AbilitySource,...],*,
                phase:Literal['TURN','REACTION']='TURN',strict:bool=True,
                source_evidence:tuple[FrozenRuleEvidence,...]=())->CatalogCompilation:
    if phase not in ('TURN','REACTION'):raise CatalogError('unsupported phase')
    ids=[x.action_id for x in sources]
    if len(ids)!=len(set(ids)):raise CatalogError('duplicate action source IDs')
    if len({(x.source_page_id,x.rule_id) for x in source_evidence})!=len(source_evidence):
        raise CatalogError('Duplicate source proofs')
    proven={(p.source_page_id,p.rule_id) for p in source_evidence}
    result=[];blocked=[]
    for spec in sources:
        reason=None
        if spec.action_id not in actor.known_action_ids:reason='NOT-IN-ACTOR-LOADOUT'
        elif spec.source_status in ('CONFLICT','UNKNOWN'):reason='MISSING-AUTHORITY'
        elif strict and spec.source_status=='LAB-ASSUMPTION':reason='LAB-ASSUMPTION-NOT-CANONICAL'
        elif strict and (spec.source_page_id,spec.rule_id) not in proven:reason='SOURCE-EVIDENCE-NOT-FROZEN'
        elif not spec.effect_adapter_ready:reason='EFFECT-ADAPTER-NOT-READY'
        elif not spec.cooldown_ready:reason='COOLDOWN'
        elif actor.ordinal_level<spec.min_rank_index:reason='RANK-RESTRICTED'
        elif actor.available_pa is None and spec.required_pa>0:reason='PA-NOT-KNOWN'
        elif actor.available_pa is not None and spec.required_pa>actor.available_pa:reason='INSUFFICIENT-PA'
        elif phase=='REACTION' and (spec.economy!='REACTION' or not actor.reaction_available):reason='NOT-AVAILABLE-REACTION'
        elif phase=='REACTION' and actor.reaction_trigger_observed!=spec.reaction_trigger:reason='NO-SOURCE-TRIGGER'
        elif phase=='TURN' and spec.economy=='REACTION':reason='NO-REACTION-IN-TURN-DECISION'
        elif phase=='TURN' and spec.economy=='STANDARD' and not actor.standard_available:reason='STANDARD-SPENT'
        elif phase=='TURN' and spec.economy=='MOVEMENT' and not actor.movement_available:reason='MOVEMENT-SPENT'
        elif phase=='TURN' and spec.economy=='FULL' and (not actor.standard_available or not actor.movement_available):reason='FULL-UNAVAILABLE'
        elif phase=='TURN' and spec.economy=='FREE' and not actor.free_action_contract_ready:reason='FREE-ACTION-UNRESOLVED'
        elif spec.requires_range_check and actor.range_confirmed is not True:reason='RANGE-UNRESOLVED'
        elif spec.requires_line_of_sight and actor.los_confirmed is not True:reason='LINE-OF-SIGHT-UNRESOLVED'
        elif spec.target_scope in ('POSITION','AREA-ENEMY','AREA-ALLY') and actor.geometry_confirmed is not True:reason='GEOMETRY-UNRESOLVED'
        if reason:
            blocked.append((spec.action_id,reason));continue
        if spec.target_scope=='ENEMY':targets=actor.enemy_ids_visible
        elif spec.target_scope=='ALLY':targets=actor.ally_ids_visible
        elif spec.target_scope=='SELF':targets=(actor.actor_id,)
        elif spec.target_scope=='POSITION':
            if not actor.environment_contract:
                blocked.append((spec.action_id,'POSITION-NOT-SOURCE-CONTRACTED'));continue
            targets=(None,)
        elif spec.target_scope in ('AREA-ENEMY','AREA-ALLY'):
            candidates=set(actor.enemy_ids_visible if spec.target_scope=='AREA-ENEMY' else actor.ally_ids_visible)
            if not actor.known_area_targets or not set(actor.known_area_targets).issubset(candidates):
                blocked.append((spec.action_id,'AREA-TARGETS-UNVERIFIED'));continue
            if len(actor.known_area_targets)>spec.max_targets:
                blocked.append((spec.action_id,'TOO-MANY-TARGETS'));continue
            # The planner sees a virtual area action; the rules engine will need
            # target set (not a single target ID).  This is not yet full ready.
            targets=(None,)
        else:targets=(None,)
        if not targets:
            blocked.append((spec.action_id,'NO-VALID-TARGETS'));continue
        for target in targets:
            result.append(SourcedOption(action_id=f'{spec.action_id}:{target or "none"}',kind=spec.kind,
                 source_ref=f'{spec.source_page_id}#{spec.rule_id}',target_id=target,
                 verified_legal=True,rule_status='SOURCE-VALIDATED' if spec.source_status!='LAB-ASSUMPTION' else 'LAB-ASSUMPTION',
                 resource_fraction_required=0.,expected_affordability=True,
                 visible_target_count=len(actor.known_area_targets) if 'AREA' in spec.target_scope else 1,
                 consumes_reaction=spec.economy=='REACTION'))
    return CatalogCompilation(VERSION,actor.actor_id,phase,strict,tuple(result),tuple(blocked))
