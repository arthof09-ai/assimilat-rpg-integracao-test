"""Separate event-invariant checker for limited 2x1 roster, NOT human independent audit."""
import json,sys,pathlib,hashlib,random

def stable(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(x):return hashlib.sha256(stable(x).encode()).hexdigest()
def check_journal(r):
 issues=[];roster={x['side']:x for x in r['roster']};hp={k:v['health'] for k,v in roster.items()};seen=set()
 def check(c,msg):
  if not c:issues.append(msg)
 check(r['digest']==sha({k:v for k,v in r.items() if k!='digest'}),'digest mismatch')
 check(r['fixture_hash']==sha({'actors':r['roster'],'policy':r['policy'],'version':r['protocol']}),'fixture hash')
 check(r['run_key']==r['fixture_hash'][:16],'run key')
 check(len(r['events'])==r['event_count'],'event count')
 for i,e in enumerate(r['events']):
  key=(e['round'],e['actor']);check(key not in seen,f'double action {key}');seen.add(key)
  check(e['actor'][0]!=e['target'][0],f'friendly fire {i}')
  check(hp[e['actor']]>0 and hp[e['target']]>0,f'dead actor target {i}')
  check(e['target_HP_before']==hp[e['target']],f'before HP {i}')
  check(e['attack_total']==e['attack_die']+e['FOR']+e['Luta_prof'],f'attack score {i}')
  check(e['hit']==(e['attack_total']>e['target_CA']),f'hit {i}')
  check(e['damage']==sum(e['weapon_1d4'])+e['FF_fixed_on_hit']+(4 if e['crit_status']=='POSITIVE-CRIT' and e['hit'] else 0),f'damage {i}')
  check(e['action_budget_after']['standard']==0 and e['action_budget_after']['reaction']==1,f'actions {i}')
  hp[e['target']]=max(0,hp[e['target']]-e['damage'])
  check(e['target_HP_after']==hp[e['target']],f'after HP {i}')
 check(hp==r['HP_final'],'final HP')
 check(r['core_grid_credit']==0 and not r['full_canon_combat'],'misclassified')
 return {'pass':not issues,'checks':6+len(r['events'])*9,'events':len(r['events']),'issues':issues,
         'audit_type':'separate mechanical trace checker; no human or normative approval'}
if __name__=='__main__':
 p=pathlib.Path(__file__).parent/'samples/team2x1_seed2_full_log.json'
 j=json.loads(p.read_text(encoding='utf-8'));out=check_journal(j)
 print(json.dumps(out,ensure_ascii=False,indent=2))
 if not out['pass']:sys.exit(1)
