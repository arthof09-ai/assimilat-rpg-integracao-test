import unittest
from dataclasses import replace
from monster_calibration_v01 import BeastEvaluation,aggregate
class MonsterQuality(unittest.TestCase):
 def setUp(self):
  self.a=BeastEvaluation('beast-id','v1','Bronze',1,(),'RULE-DERIVED','Bronze',1,4,'balanced','TAC-v1',1,'', 'DEFINED',None,None,None,None,None,None,'DMG-v1.1','manifest','PENDING')
 def test_no_runs_no_rank_change(self):
  self.assertIsNone(aggregate([self.a])['recommended_rank_star'])
 def test_invalid_winner_status(self):
  with self.assertRaises(ValueError):replace(self.a,winner_team='A').validate()
 def test_bad_party_size(self):
  with self.assertRaises(ValueError):replace(self.a,party_size=0).validate()
 def test_bad_star(self):
  with self.assertRaises(ValueError):replace(self.a,beast_star=6).validate()
 def test_run_needs_source(self):
  with self.assertRaises(ValueError):replace(self.a,run_status='REPLAY-VERIFIED',run_id='r1',winner_team='A',rounds=2,source_manifest_id='').validate()
 def test_duplicate_run_rejected(self):
  r=replace(self.a,run_status='RUN-EXECUTED',run_id='r1',winner_team='A',rounds=3)
  with self.assertRaises(ValueError):aggregate([r,r])
 def test_mixed_rulesets_rejected(self):
  with self.assertRaises(ValueError):aggregate([self.a,replace(self.a,ruleset_version='DMG-v2')])
 def test_hypothetical_cannot_rank(self):
  r=replace(self.a,run_status='INDEPENDENTLY-VERIFIED',run_id='r1',winner_team='A',rounds=4)
  self.assertEqual(aggregate([r])['status'],'EVIDENCE-INSUFFICIENT')
 def test_real_runs_still_not_promoted(self):
  r=replace(self.a,run_status='INDEPENDENTLY-VERIFIED',run_id='r1',winner_team='A',rounds=4,cohort='CERTIFIED-CANONICAL')
  self.assertIsNone(aggregate([r])['recommended_rank_star'])
  self.assertFalse(aggregate([r])['canonical_rank_change_authorized'])
if __name__=='__main__':unittest.main()
