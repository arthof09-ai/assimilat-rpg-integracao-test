"""Bounded attempts for a fixed basic attack; never invent an impossible hit.

User/Mestre may instruct a character to keep attempting. We execute those
attempts up to a disclosed study cap, label the model's mathematical reachability,
and never classify a zero-hit scene as a canonical draw/death/win.
"""
from __future__ import annotations
from fractions import Fraction
from hashlib import sha256
from vlab_l05_duel import dice_for

VERSION='ATTACK-PERSISTENCE-LAB-v0.8'
class PersistenceError(ValueError):pass

def persist_basic_attacks(*,attacker_id:str,defender_id:str,seed:int,
                          dice_count:int,dice_faces:int,bonus:int,
                          ca:Fraction,max_attempts:int=12):
    if not attacker_id or not defender_id or attacker_id==defender_id:raise PersistenceError('invalid actors')
    if any(type(x)!=int for x in (seed,dice_count,dice_faces,bonus,max_attempts)):raise PersistenceError('wrong input types')
    if not 1<=dice_count<=30 or not 2<=dice_faces<=100 or not 1<=max_attempts<=1000:raise PersistenceError('out of bounds')
    ca=Fraction(ca)
    maximum=dice_count*dice_faces+bonus
    potential=Fraction(maximum)>ca
    events=[]
    for i in range(1,max_attempts+1):
        rolls=dice_for(seed,attacker_id,f'PERSIST:{defender_id}:ATTEMPT:{i}',dice_faces,dice_count)
        score=sum(rolls)+bonus
        hit=Fraction(score)>ca
        if hit and not potential:raise PersistenceError('unreachable hit: engine fault')
        events.append({'n':i,'rolls':list(rolls),'bonus':bonus,'score':score,'defense_exact':str(ca),'hit':hit})
        if hit:break
    outcome='LAB-FIRST-HIT-FOUND' if events[-1]['hit'] else (
        'LAB-NO-HIT-POTENTIAL-BOUNDED-ATTEMPTS' if not potential else 'LAB-CENSORED-WITH-POTENTIAL')
    digest=sha256(repr((attacker_id,defender_id,seed,events)).encode()).hexdigest()
    return {'version':VERSION,'actors':(attacker_id,defender_id),'seed':seed,'ceiling':maximum,
            'defender_ca':str(ca),'basic_hit_possible':potential,'attempt_cap':max_attempts,
            'attempts':len(events),'events':events,'outcome':outcome,
            'full_fight':False,'canon_outcome':False,'digest':digest}
