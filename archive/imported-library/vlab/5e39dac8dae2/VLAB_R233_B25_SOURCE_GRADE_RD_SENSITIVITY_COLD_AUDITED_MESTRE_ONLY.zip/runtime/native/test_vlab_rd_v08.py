import unittest
from fractions import Fraction
from vlab_rd_v08 import *
class TestRD(unittest.TestCase):
    def d(self,n,tag='perfurante'):
        return (DamageComponent(n,tag,'unit'),)
    def test_master_70_50(self):self.assertEqual(mitigate(self.d(70),Resistances(general=50)).effective,20)
    def test_general_independent_type(self):self.assertEqual(mitigate(self.d(70,'impacto'),Resistances(general=50)).effective,20)
    def test_piercing_only_lance(self):self.assertEqual(mitigate(self.d(70),Resistances(specific=(('perfurante',50),))).effective,20)
    def test_blunt_unaffected(self):self.assertEqual(mitigate(self.d(70,'impacto'),Resistances(specific=(('perfurante',50),))).effective,70)
    def test_impacto_contundente_concussao_family(self):
        for tag in ('contundente','concussão','concussao'):
            with self.subTest(tag=tag):
                self.assertEqual(mitigate(self.d(70,tag),Resistances(specific=(('impacto',50),))).effective,20)
        self.assertEqual(mitigate(self.d(70,'impacto'),Resistances(specific=(('contundente',50),))).effective,20)
    def test_physical_family_duplicate_blocked(self):
        with self.assertRaises(RDUnresolved):Resistances(specific=(('impacto',10),('contundente',10)))
    def test_no_legacy_elemental_alias_conversion(self):
        self.assertEqual(mitigate(self.d(70,'gelo'),Resistances(specific=(('ácido',50),))).effective,70)
    def test_rd_exceeds_damage_zero(self):self.assertEqual(mitigate(self.d(30),Resistances(general=50)).effective,0)
    def test_exact_zero(self):self.assertEqual(mitigate(self.d(50),Resistances(general=50)).effective,0)
    def test_zero_damage(self):self.assertEqual(mitigate(self.d(0),Resistances(general=50)).effective,0)
    def test_no_rd(self):self.assertEqual(mitigate(self.d(70),Resistances()).effective,70)
    def test_irrelevant_tag(self):self.assertEqual(mitigate(self.d(70,'fogo'),Resistances(specific=(('perfurante',50),))).effective,70)
    def test_stack_blocked(self):
        with self.assertRaises(RDUnresolved):mitigate(self.d(70),Resistances(10,(('perfurante',15),)))
    def test_stack_nonmatching_general(self):self.assertEqual(mitigate(self.d(70,'impacto'),Resistances(10,(('perfurante',15),))).effective,60)
    def test_stack_lab_max(self):self.assertEqual(mitigate(self.d(70),Resistances(10,(('perfurante',15),)),stacking='LAB-MAX').effective,55)
    def test_stack_lab_add(self):self.assertEqual(mitigate(self.d(70),Resistances(10,(('perfurante',15),)),stacking='LAB-ADD').effective,45)
    def test_composite_blocked(self):
        with self.assertRaises(RDUnresolved):mitigate(self.d(10)+(DamageComponent(8,'fogo','unit'),),Resistances(general=5))
    def test_bypass_blocked(self):
        with self.assertRaises(RDUnresolved):mitigate(self.d(70),Resistances(10),bypass=True)
    def test_negative_rd(self):
        with self.assertRaises(RDUnresolved):Resistances(general=-5)
    def test_negative_damage(self):
        with self.assertRaises(RDUnresolved):DamageComponent(-1,'perfurante','x')
    def test_duplicate_types(self):
        with self.assertRaises(RDUnresolved):Resistances(specific=(('perfurante',3),('perfurante',5)))
    def test_no_hit_prob_when_exact_ceiling(self):self.assertFalse(possible_basic_hit(1,6,12,Fraction(93,5),12,'impacto',Resistances()))
    def test_potential_with_larger_bonuses(self):self.assertTrue(possible_basic_hit(1,6,15,Fraction(93,5),12,'impacto',Resistances()))
    def test_hit_without_damage_due_rd(self):self.assertFalse(possible_basic_hit(1,6,15,Fraction(93,5),12,'impacto',Resistances(20)))
if __name__=='__main__':unittest.main()
