import unittest
from dataclasses import replace
from vlab_beast_benchmark_v06 import sample_rosters,run,mirror,make_actor,FixtureUnsafe
from vlab_l04 import build_beast

class BeastSensitivity(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.rosters=sample_rosters()
 def test_two_sizes(self):self.assertEqual([len(v) for v in self.rosters],[2,3])
 def test_1v1_conditional(self):
  r=run(self.rosters[0],31)
  self.assertTrue(r['event_count']>=1);self.assertFalse(r['can_credit_official_core'])
 def test_2v1_conditional(self):
  r=run(self.rosters[1],31)
  self.assertEqual(len(r['HP']),3)
 def test_replay_same_digest(self):
  r1=run(self.rosters[1],42);r2=run(self.rosters[1],42)
  self.assertEqual(r1['digest'],r2['digest'])
 def test_rational_beast_ca(self):
  r=self.rosters[0]; self.assertEqual(r[1].ca.denominator>0,True)
 def test_beast_attacks_from_source(self):
  self.assertEqual(self.rosters[0][1].damage_dice,'3d6')
 def test_beast_proficiency_assumption(self):
  self.assertTrue(any('Luta' in a for a in self.rosters[0][1].assumptions))
 def test_rd_sensitive(self):
  a=run(self.rosters[1],24,rd_mode='SUBTRACT-LAB')
  b=run(self.rosters[1],24,rd_mode='OFF-LAB')
  self.assertNotEqual(a['rd_mode'],b['rd_mode'])
 def test_side_mirror_1v1(self):
  x=mirror(self.rosters[0],19)
  self.assertTrue(all(x[k] for k in ('same_events','same_hp','same_initiative','same_winner_actors','same_trace_digest','side_winner_inverted')))
 def test_side_mirror_2v1(self):
  x=mirror(self.rosters[1],19)
  self.assertTrue(all(x[k] for k in ('same_events','same_hp','same_initiative','same_winner_actors','same_trace_digest','side_winner_inverted')))
 def test_no_divine_before_source(self):
  with self.assertRaises(FixtureUnsafe):make_actor(build_beast('Bronze',1,555,explicit_traits=('Besta Divina',)),'B')
 def test_no_unknown_team(self):
  with self.assertRaises(FixtureUnsafe):make_actor(build_beast('Bronze',1,23),'X')
 def test_no_duplicate_actor(self):
  a=self.rosters[0][0]
  with self.assertRaises(FixtureUnsafe):run((a,a),123)
 def test_clamp_hp(self):
  r=run(self.rosters[0],41)
  self.assertTrue(all(v>=0 for v in r['HP'].values()))
 def test_target_is_enemy(self):
  roster=self.rosters[1];teams={x.actor_id:x.team for x in roster}
  for e in run(roster,41)['events']:self.assertNotEqual(teams[e['actor_id']],teams[e['target_id']])
 def test_only_attacks_not_fullfight(self):
  r=run(self.rosters[1],91)
  self.assertTrue(all(x['action_id'].find('basic_attack')>=0 for x in r['events']))
 def test_policy_id_same(self):
  a=run(self.rosters[1],51)
  self.assertTrue(all(x['policy_version']=='TACTICAL-OBSERVABLE-v0.2' for x in a['events']))
 def test_cannot_claim_beast_reclass(self):self.assertFalse(run(self.rosters[0],17)['canonical_rank_reclassification_allowed'])
 def test_invalid_rd_policy(self):
  with self.assertRaises(ValueError):run(self.rosters[0],1,rd_mode='secret')
 def test_dice_source_rank(self):
  beast=self.rosters[0][1]; self.assertEqual(beast.attack_dice,'1d6')
 def test_same_char_team_swap(self):
  v=mirror(self.rosters[1],51)
  self.assertTrue(v['same_trace_digest'])

if __name__=='__main__':unittest.main()

class StalemateDiagnostics(unittest.TestCase):
 def test_impossible_basic_attacks_flagged(self):
  from fractions import Fraction
  from dataclasses import replace
  a,b=sample_rosters()[0]
  a=replace(a,ca=Fraction(1000));b=replace(b,ca=Fraction(1000))
  x=run((a,b),23)
  self.assertEqual(x['stop_reason'],'STALEMATE-NO-EFFECTIVE-BASIC-ATTACK')
  self.assertIsNone(x['winner_by_lab_hp_threshold'])
  self.assertEqual(x['event_count'],0)
 def test_stalemate_sides_unchanged(self):
  from fractions import Fraction
  from dataclasses import replace
  a,b=sample_rosters()[0]
  a=replace(a,ca=Fraction(1000));b=replace(b,ca=Fraction(1000))
  m=mirror((a,b),23)
  self.assertTrue(m['same_events'] and m['same_hp'] and m['side_winner_inverted'])
 def test_normal_battle_reaches_threshold(self):
  x=run(sample_rosters()[0],101)
  self.assertEqual(x['stop_reason'],'LAB-HP-THRESHOLD')
