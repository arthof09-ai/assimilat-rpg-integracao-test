import unittest
from dataclasses import replace
from vlab_tactical_policy_v02 import FighterDoctrine,VisibleContext,SourcedOption,choose_action,doctrine_from_snapshot

class TestPolicy02(unittest.TestCase):
 def base(self):
  d=FighterDoctrine('ED-X','striker','disciplined','expert')
  c=VisibleContext('ED-X',.8,1,enemy_count_visible=2)
  return d,c
 def option(self,name,kind='attack',**kw):return SourcedOption(name,kind,kw.pop('source_ref','source:rule:'+name),target_id=kw.pop('target_id','ENEMY'),**kw)
 def test_no_legal(self):
  d,c=self.base()
  with self.assertRaises(ValueError):choose_action(d,c,())
 def test_no_fabricated_spell(self):
  d,c=self.base()
  o=(self.option('s','spell',verified_legal=False), self.option('a'))
  x=choose_action(d,c,o)
  self.assertEqual(x.action_id,'a');self.assertEqual(x.rejected_action_ids,('s',))
 def test_no_omniscient_estimates(self):
  d,c=self.base()
  o=(self.option('s','spell',success_estimate=.99,estimate_provenance='LAB-ORACLE'),self.option('a'))
  self.assertEqual(choose_action(d,c,o).action_id,'a')
 def test_source_cost_blocks(self):
  d,c=self.base();c=replace(c,self_resources_fraction=.1)
  self.assertEqual(choose_action(d,c,(self.option('s','spell',resource_fraction_required=.2),self.option('a'))).action_id,'a')
 def test_same_policy_permutation(self):
  d,c=self.base();o=(self.option('1',target_id='E1'),self.option('2',target_id='E2'))
  self.assertEqual(choose_action(d,c,o).action_id,choose_action(d,c,tuple(reversed(o))).action_id)
 def test_side_absent(self):
  d,c=self.base();o=(self.option('1'),)
  self.assertFalse(hasattr(d,'team'));self.assertFalse(hasattr(c,'side'))
  self.assertEqual(choose_action(d,c,o).action_id,'1')
 def test_reaction_only(self):
  d,c=self.base();o=(self.option('attack'), self.option('reaction','reaction',consumes_reaction=True),)
  self.assertEqual(choose_action(d,c,o,phase='REACTION').action_id,'reaction')
 def test_reaction_budget_filter_turn(self):
  d,c=self.base();o=(self.option('attack'),self.option('react','reaction',consumes_reaction=True))
  self.assertEqual(choose_action(d,c,o).action_id,'attack')
 def test_no_affordable(self):
  d,c=self.base();c=replace(c,self_resources_fraction=0.)
  with self.assertRaises(ValueError):choose_action(d,c,(self.option('expensive',resource_fraction_required=1.),))
 def test_heal_critical_ally(self):
  d=FighterDoctrine('ED','healer','disciplined','trained');c=VisibleContext('ED',.9,1,ally_in_danger=True)
  o=(self.option('healer','heal',target_id='ALLY',ally_urgency='critical'),self.option('hit'))
  self.assertEqual(choose_action(d,c,o).action_id,'healer')
 def test_berserker_attack(self):
  d=FighterDoctrine('MON','striker','berserker','instinct',aggression=90);c=VisibleContext('MON',.8,1)
  self.assertEqual(choose_action(d,c,(self.option('hit'),self.option('guard','guard',target_id=None))).action_id,'hit')
 def test_survival_choice(self):
  d=FighterDoctrine('MON','skirmisher','cautious','trained',caution=100,aggression=0)
  c=VisibleContext('MON',.1,1,retreat_route_known=True)
  self.assertEqual(choose_action(d,c,(self.option('hit'),self.option('retreat','retreat',target_id=None))).action_id,'retreat')
 def test_spell_if_legal(self):
  d=FighterDoctrine('MAG','controller','disciplined','expert');c=VisibleContext('MAG',1.,1.)
  o=(self.option('spell1','spell',visible_target_count=3),self.option('hit'))
  self.assertEqual(choose_action(d,c,o).action_id,'spell1')
 def test_explicit_movement(self):
  d=FighterDoctrine('SKI','skirmisher','skirmisher','trained',caution=100);c=VisibleContext('SKI',.1,.8)
  o=(self.option('move','move',target_id=None,position_change='cover'),self.option('hit'))
  self.assertEqual(choose_action(d,c,o).action_id,'move')
 def test_tier_validation(self):
  with self.assertRaises(ValueError):FighterDoctrine('A','striker','duelist','wizard')
 def test_distinct_styles(self):
  styles={doctrine_from_snapshot('BE-%s'%i,'BE',race_or_species='sintético',lab_seed=i).style for i in range(45)}
  self.assertGreaterEqual(len(styles),3)
 def test_same_actor_same_style(self):
  self.assertEqual(doctrine_from_snapshot('BE-1','BE',race_or_species='esp'), doctrine_from_snapshot('BE-1','BE',race_or_species='esp'))
 def test_target_visible_bands_only(self):
  d,c=self.base();self.assertFalse(hasattr(c,'enemy_hp_exact'))
 def test_unauthorized_reaction_dropped(self):
  d,c=self.base()
  with self.assertRaises(ValueError):choose_action(d,c,(self.option('a'),),phase='REACTION')
 def test_no_fake_passthrough(self):
  d,c=self.base()
  with self.assertRaises(ValueError):choose_action(d,c,(self.option('s','spell',verified_legal=False),))
 def test_multi_role_different_actions(self):
  c=VisibleContext('X',.8,1.,ally_in_danger=True)
  opts=(self.option('protect','protect',target_id='ALLY'),self.option('attack'))
  defender=FighterDoctrine('X','guardian','guardian','trained')
  striker=FighterDoctrine('X','striker','berserker','trained')
  self.assertNotEqual(choose_action(defender,c,opts).action_id,choose_action(striker,c,opts).action_id)
 def test_no_duplicate(self):
  d,c=self.base()
  with self.assertRaises(ValueError):choose_action(d,c,(self.option('x'),self.option('x')))
 def test_bad_identity(self):
  d,c=self.base()
  with self.assertRaises(ValueError):choose_action(d,replace(c,actor_id='B'),(self.option('x'),))

if __name__=='__main__':unittest.main()

# Extra regression cases for personality-specific observable target choices.
class BehavioralIdentityTests(unittest.TestCase):
 def test_duelist_chooses_high_threat(self):
  d=FighterDoctrine('X','striker','duelist','trained')
  c=VisibleContext('X',.9,1)
  o=(SourcedOption('a_low','attack','r',target_id='LOW',target_threat='low'),SourcedOption('z_high','attack','r',target_id='HIGH',target_threat='high'))
  self.assertEqual(choose_action(d,c,o).target_id,'HIGH')
 def test_cautious_selects_low_threat(self):
  d=FighterDoctrine('X','striker','cautious','trained')
  c=VisibleContext('X',.9,1)
  o=(SourcedOption('a_high','attack','r',target_id='HIGH',target_threat='high'),SourcedOption('z_low','attack','r',target_id='LOW',target_threat='low'))
  self.assertEqual(choose_action(d,c,o).target_id,'LOW')
 def test_pack_prefers_injured_preys(self):
  d=FighterDoctrine('X','striker','pack_hunter','trained',cooperation=90)
  c=VisibleContext('X',.9,1)
  o=(SourcedOption('a','attack','r',target_id='FRESH',target_injury='normal'),SourcedOption('z','attack','r',target_id='HURT',target_injury='injured'))
  self.assertEqual(choose_action(d,c,o).target_id,'HURT')
 def test_trained_reacts_to_observed_cast(self):
  d=FighterDoctrine('X','guardian','guardian','expert')
  c=VisibleContext('X',.9,1,last_observed_enemy_action='spell')
  o=(SourcedOption('p','protect','r',target_id='ALLY'),SourcedOption('a','attack','r',target_id='FOE'))
  v=choose_action(d,c,o)
  self.assertIn('observed-spell-control-threat',v.reasons)
