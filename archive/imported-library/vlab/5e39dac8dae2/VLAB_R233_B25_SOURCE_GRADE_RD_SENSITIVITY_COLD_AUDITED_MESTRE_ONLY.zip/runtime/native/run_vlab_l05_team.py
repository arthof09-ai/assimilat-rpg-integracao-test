"""Run first limited 2x1 team event loop and persist deterministic trace."""
import json,pathlib,csv,hashlib
from vlab_l05_team import sample_team_roster,run_team,replay_team
ROOT=pathlib.Path(__file__).parent/'samples';ROOT.mkdir(exist_ok=True)
r=run_team(sample_team_roster(),seed=2);replay=replay_team(r)
assert replay['pass']
summary={
 'case_id':'VL05-TEAM-ED-BRONZE1-2x1','protocol':r['protocol'],'classification':r['mode'],
 'seed':r['seed'],'formation':'2×1 (two Humans vs one Human, no Bestas yet)',
 'rounds':r['rounds'],'events':len(r['events']),'winner_by_lab_threshold':r['winner_by_lab_threshold'],
 'hp_initial':{a['side']:a['health'] for a in r['roster']},'hp_final':r['HP_final'],
 'initial_initiative':r['initiative_totals'],'order':r['order'],
 'actor_actions':{a['side']:sum(e['actor']==a['side'] for e in r['events']) for a in r['roster']},
 'damage_by_actor':{a['side']:sum(e['damage'] for e in r['events'] if e['actor']==a['side']) for a in r['roster']},
 'fixture_hash':r['fixture_hash'],'run_digest':r['digest'],'replay':replay,
 'formal_ledger_credits':0,
 'notes':['Structural first team-engine test, does not model 2 ED versus Besta',
          'Actors are Human Bronze 1 laboratory templates; no new RPG page created',
          'Lab decisions: attacker always attacks; declines defense; static adjacency; focus first living roster target',
          'Victory only as HP<=0 lab stop, no canon death implication','Tie/crit-fail abort; no magical area or movement rules invented',
          'Group replay uses same engine independently re-invoked; no human audit or canon approval.']
}
(ROOT/'team2x1_seed2_full_log.json').write_text(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
(ROOT/'team2x1_seed2_summary.json').write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
with (ROOT/'team2x1_seed2_events.csv').open('w',encoding='utf-8',newline='') as o:
 f=['round','actor','target','attack_die','FOR','Luta_prof','attack_total','target_CA','hit','crit_sequential','weapon_1d4','FF_fixed_on_hit','damage','target_HP_before','target_HP_after']
 w=csv.DictWriter(o,fieldnames=f);w.writeheader()
 for e in r['events']:
  k={q:e[q] for q in f}
  for t in ('crit_sequential','weapon_1d4'):k[t]=json.dumps(k[t],separators=(',',':'))
  w.writerow(k)
print(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True))
for path in (ROOT/'team2x1_seed2_full_log.json',ROOT/'team2x1_seed2_summary.json',ROOT/'team2x1_seed2_events.csv'):
 print(path.name,path.stat().st_size,hashlib.sha256(path.read_bytes()).hexdigest())
