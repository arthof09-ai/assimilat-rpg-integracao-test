from vlab_l04 import RANKS,ATTRS,RACE_PROFILES,build_human,build_beast,build_other_race,scenario_template,BuildError
from vlab_l05_preflight import ActionBudget,scenario_preflight,targeting,RulesUnresolved,IllegalAction
import hashlib,json,random
rnd=random.Random(20261008)
checks=0
kinds=('human','beast',*RACE_PROFILES)
for i in range(1500):
    rank=rnd.choice(RANKS);star=rnd.randint(1,5);seed=rnd.randint(1,10**8)
    kind=rnd.choice(kinds)
    def make():
        if kind=='human':return build_human(rank,star,seed=seed)
        if kind=='beast':return build_beast(rank,star,seed=seed)
        return build_other_race(rank,star,kind,seed=seed)
    actor=make()
    assert actor.to_json()==make().to_json()
    assert sum(actor.stats.values())>0
    assert actor.level==5*RANKS.index(rank)+star
    assert actor.health is None or actor.health>0
    assert not actor.full_fight_eligible
    checks+=1
for i in range(400):
    budget=ActionBudget()
    budget.spend('REACTION')
    try:budget.spend('REACTION');raise AssertionError('reaction consumed twice')
    except IllegalAction:pass
    try:targeting('AOE-EXPLICIT',('a','b'),('a','b'));raise AssertionError('improper area target allowed')
    except RulesUnresolved:pass
    checks+=1
for size in (2,4,6,10,20,40):
    left=tuple(build_human(RANKS[i%5],i%5+1,seed=1000+j*500+i) for i in range(size//2) for j in (0,))
    right=tuple(build_beast(RANKS[i%5],i%5+1,seed=2000+j*500+i) for i in range(size//2) for j in (0,))
    s=scenario_template(left,right,f'STRESS-{size}')
    assert s['roster_size']==size and not s['ready_for_full_fight']
    assert scenario_preflight(left+right)['blocked_count']==size
    checks+=1
print(json.dumps({'checks':checks,'actor_property_checks':1500,'fail_closed_checks':400,'roster_sizes':[2,4,6,10,20,40], 'failures':0,'run_fights':0,'test_source':'synthetic_stress_not_canonical_simulation'}))
