"""Conditional, audit-friendly RPG Assimilação virtual duel prototype.

Strictly restricted first complete event-loop benchmark: Humano Bronze1 vs
Humano Bronze1, both with an ordinary LIGHT weapon (DMG-RANK-01 1d4), adjacent,
stationary, no optional defensive reaction or magic. Ending at HP<=0 is a LAB
stop condition, not a canonical death/incapacitation rule. No canon changes.

Sources: Criação de Ficha, Sistema de Combate, DMG-RANK-01 v1.1.
The 3d6 critical-check interpretation is logged as a LAB protocol. When an
unresolved critical-failure consequence occurs, refuse a finished-result claim.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, random
from typing import Any
from vlab_l04 import ActorSnapshot, build_human
from vlab_l05_preflight import ActionBudget, IllegalAction, RulesUnresolved, determine_attack_success, classify_critical_sequence

VERSION='VL05-DUEL-0.1'
SOURCE_IDS={
  'character':'3ebc2b32-4ede-8144-9222-f3c06b840613',
  'combat':'3ebc2b32-4ede-81f1-be4b-e8804ac113c0',
  'damage':'3f2c2b32-4ede-8154-98cd-db7844245f7e',
}
POLICY={
  'placement':'ONE-ADJACENT-BLOCK-STATIC',
  'weapon':'COMMON-LIGHT-1d4',
  'luta_proficiency':'TRAINED-INITIAL-PLUS-2',
  'initiative_proficiency':'UNTRAINED-ZERO',
  'actions':'ONE-STANDARD-ATTACK-EACH-TURN',
  'defensive_reaction':'DECLINE-OPTIONAL',
  'move':'NO-MOVEMENT',
  'spell':'NONE',
  'crit':'SEQUENTIAL-3D6-LAB-CHECK-PER-ATTEMPT; CRIT-FAIL-ABORT-UNRESOLVED',
  'end_condition':'LAB-HP-LE-ZERO; DOES-NOT-DEFINE-CANONICAL-DEATH',
}

class DuelNotEligible(ValueError): pass


def _stable_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',',':'))


def _hash(data: Any) -> str:
    return hashlib.sha256(_stable_json(data).encode()).hexdigest()


def dice_for(seed: int, run_key: str, logical_key: str, faces: int, count: int=1)-> list[int]:
    if not isinstance(seed,int) or isinstance(seed,bool) or faces<2 or count<1:
        raise ValueError('Invalid deterministic RNG request')
    digest=hashlib.sha256(f'{VERSION}|{seed}|{run_key}|{logical_key}'.encode()).digest()
    rng=random.Random(int.from_bytes(digest,'big'))
    return [rng.randint(1,faces) for _ in range(count)]


def frozen_fixture(actor:ActorSnapshot, *, side:str) -> dict[str,Any]:
    """Bind only source-derived & explicitly selected lab options, not mutate Snapshot."""
    if actor.actor_kind!='ED' or actor.rank!='Bronze' or actor.star!=1 or not actor.race_or_species.startswith('Humano'):
        raise DuelNotEligible('First duel adapter is human Bronze 1 only')
    if actor.actor_mode!='RULE-DERIVED-VIRTUAL' or actor.test_dice!='1d6' or not actor.ca['integer_ready']:
        raise DuelNotEligible('Actor source or defence unresolved')
    if actor.health is None or actor.health<=0 or actor.rd is not None:
        raise DuelNotEligible('Vital/RD claim outside plain unarmored human adapter')
    if any(lock['choice']!='damage' for lock in actor.ff_milestones):
        raise DuelNotEligible('First adapter only supports fixed FF-damage choice')
    if actor.physical_force!=(actor.stats['FOR']+actor.stats['DES']+actor.stats['CON'])*10:
        raise DuelNotEligible('Physical force integrity failure')
    if actor.stats['INT']<0 or (2+actor.stats['INT'])<1:
        raise DuelNotEligible('No legal Luta proficiency choice')
    if actor.ca['numerator']!=6+actor.stats['DES']:
        raise DuelNotEligible('CA mismatch or unexpected armor')
    return {
        'side':side,'actor_id':actor.actor_id,'kind':actor.actor_kind,'mode':actor.actor_mode,
        'rank':'Bronze','star':1,'health':actor.health,'soul':actor.soul,
        'attributes':actor.stats,'defense_ca':actor.ca['numerator'],
        'rd_mode':'NOT-APPLICABLE-FOR-UNARMORED-HUMAN; NO-UNRECORDED-RD',
        'initiative_dice':'1d6','initiative_bonus':0,
        'luta_dice':'1d6','luta_attr':'FOR','luta_prof_bonus':2,
        'attack_action':'STANDARD','weapon':'COMMON-LIGHT-1d4',
        'weapon_damage_dice':'1d4','attribute_damage_bonus':0,
        'ff_damage_fixed':sum(x['fixed_roll'] for x in actor.ff_milestones),
        'ff_locks':list(actor.ff_milestones),
        'position':'ADJACENT-STATIC','reaction_policy':'DECLINE',
        'source_refs':SOURCE_IDS,
        'actor_source_hash':_hash(json.loads(actor.to_json())),
        'proficiency_choice':{'Luta':2,'Iniciativa':0,'legal_limit':2+actor.stats['INT']},
        'eligible_for_this_restricted_lab_profile':True,
        'not_general_full_fight_eligible':True,
    }


def build_sample_fixture()->tuple[dict,dict]:
    p1=('FOR','DES','CON','INT','SAB','CAR')
    p2=('DES','CON','FOR','SAB','INT','CAR')
    return frozen_fixture(build_human('Bronze',1,101,priority=p1),side='A'), frozen_fixture(build_human('Bronze',1,202,priority=p2),side='B')


def execute_duel(actors:tuple[dict,dict], *, seed:int, max_rounds:int=30)->dict[str,Any]:
    if max_rounds<1 or max_rounds>1000:raise ValueError('Invalid rounds bound')
    if len(actors)!=2 or len({a['actor_id'] for a in actors})!=2 or {a['side'] for a in actors}!={'A','B'}:
        raise DuelNotEligible('Two distinct opposing participants required')
    for a in actors:
        if not a.get('eligible_for_this_restricted_lab_profile') or a['rank']!='Bronze' or a['star']!=1:
            raise DuelNotEligible('Fixture must be admitted by adapter')
    f_hash=_hash({'actors':actors,'policy':POLICY,'version':VERSION})
    key=f_hash[:16]
    rolls={a['side']:dice_for(seed,key,f'INIT:{a["side"]}',6)[0] for a in actors}
    initiatives={a['side']:rolls[a['side']]+a['attributes']['DES']+a['initiative_bonus'] for a in actors}
    if len(set(initiatives.values()))<2:
        raise RulesUnresolved('TIED-INITIATIVE: No canonical tie-break method; run rejected')
    order=sorted(actors,key=lambda a:-initiatives[a['side']])
    hp={a['side']:a['health'] for a in actors}
    side_to_actor={a['side']:a for a in actors}
    events=[]
    winner=None
    for round_index in range(1,max_rounds+1):
        budgets={a['side']:ActionBudget() for a in actors}
        for actor in order:
            side=actor['side'];target_side='B' if side=='A' else 'A'
            target=side_to_actor[target_side]
            if hp[side]<=0 or hp[target_side]<=0:continue
            budgets[side].spend('STANDARD')
            attack_dice=dice_for(seed,key,f'ROUND:{round_index}:ATTACK:{side}',6)
            attack_score=sum(attack_dice)+actor['attributes']['FOR']+actor['luta_prof_bonus']
            target_ca=target['defense_ca']
            hit=determine_attack_success(attack_score,target_ca)
            critical_dice=dice_for(seed,key,f'ROUND:{round_index}:CRIT:{side}',6,3)
            crit=classify_critical_sequence(tuple(critical_dice))
            if crit=='CRITICAL-FAIL':
                raise RulesUnresolved(f'CRITICAL-FAIL consequence not sourced at round {round_index}, actor {side}')
            weapon_roll=[];dmg=0
            if hit:
                weapon_roll=dice_for(seed,key,f'ROUND:{round_index}:DAMAGE:{side}',4)
                max_dice_bonus=4 if crit=='POSITIVE-CRIT' else 0
                dmg=sum(weapon_roll)+actor['ff_damage_fixed']+max_dice_bonus
            before=hp[target_side]
            hp[target_side]=max(0,hp[target_side]-dmg)
            event={
                'round':round_index,'turn_actor':side,'target':target_side,'action':'STANDARD-ATTACK',
                'actor_id':actor['actor_id'],'target_actor_id':target['actor_id'],
                'action_budget_after':asdict(budgets[side]),
                'attack_dice':attack_dice,'attribute_FOR':actor['attributes']['FOR'],
                'luta_prof_bonus':actor['luta_prof_bonus'],'attack_total':attack_score,
                'target_CA':target_ca,'hit':hit,'critical_check_sequential':critical_dice,
                'critical_status':crit,'weapon_dice_1d4':weapon_roll,
                'ff_fixed_bonus':actor['ff_damage_fixed'] if hit else 0,
                'dmg_intrinsic':sum(weapon_roll),
                'dmg_final':dmg,'target_hp_before':before,'target_hp_after':hp[target_side],
                'rule_trace':['Sistema de Combate > ataque/teste/acao','Criação de Ficha > Luta/FF/CA','DMG-RANK-01 v1.1 > arma comum leve 1d4'],
            }
            events.append(event)
            if hp[target_side]<=0:
                winner=side
                break
        if winner:break
    result={
        'protocol':VERSION,'classification':'RUN-CONDITIONAL-LAB-NONCANON',
        'scope':'MESTRE-ONLY','run_key':key,'case_id':'VL05-EDB1-EDB1-COMMON-LIGHT',
        'rng_seed':seed,'rng_protocol':'SHA256-DERIVED-PER-LOGICAL-EVENT',
        'fixture_hash':f_hash,'scenario_policy':POLICY,'source_ids':SOURCE_IDS,
        'actors':list(actors),'initiative_rolls':rolls,'initiative_totals':initiatives,
        'turn_order':[a['side'] for a in order],
        'rounds_completed':round_index,'action_events':len(events),'events':events,
        'outcome':'LAB-HP-THRESHOLD-REACHED' if winner else 'CENSORED-MAX-ROUNDS',
        'winner_by_lab_stop_condition':winner,'hp_final':hp,
        'full_fight_in_canonical_system':False,
        'credit_core_full_fight_baseline':False,
        'human_playtest':False,'canonical_death_rule_applied':False,
        'unresolved':['GAP: canonical consequence of HP <=0','GAP: precise timing/applicability of 3d6 critical check',
                      'NO AOE, NO MOVEMENT, NO MAGICS, NO REACTION REQUESTED by laboratory policy'],
    }
    result['run_digest']=_hash({k:v for k,v in result.items() if k!='run_digest'})
    return result


def independent_replay(run:dict[str,Any])->dict[str,Any]:
    actors=tuple(run['actors'])
    rerun=execute_duel(actors,seed=run['rng_seed'],max_rounds=max(30,run['rounds_completed']))
    # Compare all serialized run content including event stream, not merely winner.
    same=_stable_json(rerun)==_stable_json(run)
    return {'replay_passed':same,'event_count':len(run['events']),'run_digest':run['run_digest'],
            'replay_digest':rerun['run_digest'],
            'matching_initiative':run['initiative_totals']==rerun['initiative_totals'],
            'matching_event_trace':run['events']==rerun['events'],
            'matching_hp':run['hp_final']==rerun['hp_final']}

if __name__=='__main__':
    a,b=build_sample_fixture()
    for seed in range(1,100):
        try:run=execute_duel((a,b),seed=seed)
        except RulesUnresolved:continue
        if run['winner_by_lab_stop_condition'] is not None:
            replay=independent_replay(run)
            print(json.dumps({'seed':seed,'winner':run['winner_by_lab_stop_condition'],'rounds':run['rounds_completed'],'events':run['action_events'],'digest':run['run_digest'],'replay':replay},ensure_ascii=False,indent=2))
            break
