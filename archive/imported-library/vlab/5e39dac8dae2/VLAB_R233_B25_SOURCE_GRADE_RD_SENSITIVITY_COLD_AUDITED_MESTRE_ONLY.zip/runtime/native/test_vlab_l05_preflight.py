import unittest
from vlab_l04 import build_human,build_beast
from vlab_l05_preflight import *
class TestPreflightL05(unittest.TestCase):
    def test_std_move_react(self):
        a=ActionBudget();a.spend('STANDARD');a.spend('MOVEMENT');a.spend('REACTION')
        self.assertEqual((a.standard,a.movement,a.reaction),(0,0,0))
        with self.assertRaises(IllegalAction):a.spend('REACTION')
    def test_full_requires_source_override(self):
        a=ActionBudget()
        with self.assertRaises(RulesUnresolved):a.spend('COMPLETE')
        self.assertEqual(a.standard,1)
        a.spend('COMPLETE',complete_reaction_override=True)
        self.assertEqual((a.standard,a.movement,a.reaction),(0,0,0))
    def test_full_explicit_without_reaction(self):
        a=ActionBudget();a.spend('COMPLETE',complete_reaction_override=False)
        self.assertEqual((a.standard,a.movement,a.reaction),(0,0,1))
    def test_defense_before_attack_only(self):
        a=ActionBudget()
        with self.assertRaises(IllegalAction):defensive_reaction(a,attack_declared=False,reaction_kind='DEFENDER')
        defensive_reaction(a,attack_declared=True,reaction_kind='ESQUIVAR')
        with self.assertRaises(IllegalAction):defensive_reaction(a,attack_declared=True,reaction_kind='REFLETIR_MAGIA')
    def test_reaction_kind_authorized(self):
        with self.assertRaises(IllegalAction):defensive_reaction(ActionBudget(),attack_declared=True,reaction_kind='MAGICAL_WIN')
    def test_attack_strict_exceed(self):
        self.assertFalse(determine_attack_success(10,10));self.assertTrue(determine_attack_success(11,10))
        self.assertFalse(determine_attack_success(9,10))
    def test_critical_order(self):
        self.assertEqual(classify_critical_sequence((6,6,5)),'POSITIVE-CRIT')
        self.assertEqual(classify_critical_sequence((6,6,6)),'POSITIVE-CRIT')
        self.assertEqual(classify_critical_sequence((6,5,6)),'NONE')
        self.assertEqual(classify_critical_sequence((1,1,2)),'CRITICAL-FAIL')
        self.assertEqual(classify_critical_sequence((2,1,1)),'NONE')
    def test_critical_bad_rolls(self):
        with self.assertRaises(IllegalAction):classify_critical_sequence((6,6,7))
        with self.assertRaises(IllegalAction):classify_critical_sequence((6,6,True))
    def test_single_target(self):
        self.assertEqual(targeting('SINGLE',('a','b'),('a',)),('a',))
        with self.assertRaises(IllegalAction):targeting('SINGLE',('a','b'),('a','b'))
    def test_area_requires_explicit(self):
        with self.assertRaises(RulesUnresolved):targeting('AOE-EXPLICIT',('a','b'),('a','b'))
        self.assertEqual(targeting('AOE-EXPLICIT',('a','b'),('a','b'),explicit_aoe_membership=True),('a','b'))
    def test_duplicate_target(self):
        with self.assertRaises(IllegalAction):targeting('AOE-EXPLICIT',('a','b'),('a','a'),explicit_aoe_membership=True)
    def test_preflight_no_fight(self):
        actors=(build_human('Bronze',1),build_beast('Prata',3,seed=12))
        state=scenario_preflight(actors)
        self.assertEqual(state['blocked_count'],2)
        self.assertFalse(state['full_fight_allowed'])
        self.assertEqual(state['simulation_run_count'],0)
if __name__=='__main__':unittest.main(verbosity=2)
