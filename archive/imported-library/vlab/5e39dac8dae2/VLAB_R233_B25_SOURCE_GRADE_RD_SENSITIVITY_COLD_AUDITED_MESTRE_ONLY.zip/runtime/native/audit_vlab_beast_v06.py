"""Independent bookkeeping checks for mixed ED/BE lab-only fight journals."""
from __future__ import annotations
from fractions import Fraction
from collections import defaultdict
from vlab_beast_benchmark_v06 import SimActor,run,mirror

def audit(roster:tuple[SimActor,...], result:dict)->dict:
    roster_ids={x.actor_id:x for x in roster}
    hp={x.actor_id:x.health for x in roster}
    seen=set();checks=0
    for event in result['events']:
        actor=roster_ids[event['actor_id']];victim=roster_ids[event['target_id']]
        assert actor.team!=victim.team;checks+=1
        assert hp[actor.actor_id]>0 and hp[victim.actor_id]>0;checks+=1
        key=(event['round'],actor.actor_id)
        assert key not in seen;seen.add(key);checks+=1
        assert event['before_hp']==hp[victim.actor_id];checks+=1
        assert event['hit'] == (Fraction(event['attack_score']) > victim.ca)
        checks+=1
        assert event['CA_exact']==str(victim.ca);checks+=1
        assert event['crit_status'] in ('NORMAL','CRIT','CRIT-FAIL-NO-EFFECT-LAB');checks+=1
        if event['hit']:
            rolled=sum(event['damage_rolls'])
            maxdice=int(actor.damage_dice.split('d')[0])*int(actor.damage_dice.split('d')[1])
            raw=rolled+actor.damage_fixed+(maxdice if event['crit_status']=='CRIT' else 0)
            assert raw==event['damage_raw'];checks+=1
            net=max(0,raw-(victim.rd or 0)) if result['rd_mode']=='SUBTRACT-LAB' else raw
        else:
            net=0
            assert event['damage_raw']==0 and event['damage_rolls']==();checks+=1
        assert event['damage_net']==net;checks+=1
        hp[victim.actor_id]=max(0,hp[victim.actor_id]-net)
        assert event['after_hp']==hp[victim.actor_id];checks+=1
    assert hp==result['HP'];checks+=1
    return {'checks':checks,'mismatches':0,'pass':True,'events':len(result['events'])}

if __name__=='__main__':
 from vlab_beast_benchmark_v06 import sample_rosters
 for roster in sample_rosters():
  r=run(roster,101)
  print(len(roster),audit(roster,r))
