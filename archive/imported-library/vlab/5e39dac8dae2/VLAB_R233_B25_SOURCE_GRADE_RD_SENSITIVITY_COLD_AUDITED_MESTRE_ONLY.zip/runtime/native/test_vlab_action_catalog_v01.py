import unittest
from dataclasses import replace
from vlab_action_catalog_v01 import AbilitySource,ActorActionState,action_menu,CatalogError,FrozenRuleEvidence
from vlab_tactical_policy_v02 import FighterDoctrine,VisibleContext,choose_action

COMBAT='3ebc2b32-4ede-81f1-be4b-e8804ac113c0'
MAGIC='3ebc2b32-4ede-81f7-b343-f7270ff91373'
BEAST='3ebc2b32-4ede-81f4-992a-c88a3588cacd'

class TestActionCatalog01(unittest.TestCase):
 def source_proof(self,source=COMBAT,rule='TEST-SOURCED'):
  # Mock proof for software unit tests ONLY; never call this verified Notion evidence.
  import hashlib
  return FrozenRuleEvidence(source,rule,hashlib.sha256(f'{source}-{rule}'.encode()).hexdigest(),'2026-10-08T09:00:00-03:00','MOCK-UNIT-TEST-NOT-CANON')
 def actor(self,**kw):
  d=dict(actor_id='A1',ordinal_level=1,available_pa=20,known_action_ids=('atk','spell','dodge','move','heal','area','full'),enemy_ids_visible=('B1',),ally_ids_visible=('A2',),
         reaction_trigger_observed='ENEMY-ATTACK-DECLARED',reaction_available=True)
  d.update(kw);return ActorActionState(**d)
 def source(self,action_id='atk',kind='attack',economy='STANDARD',**kw):
  d=dict(action_id=action_id,kind=kind,economy=economy,source_page_id=COMBAT,rule_id='TEST-SOURCED',
         source_status='LAB-ASSUMPTION',effect_adapter_ready=True,effect_adapter_id='SYNTHETIC-SANDBOX-ONLY')
  d.update(kw);return AbilitySource(**d)
 def test_strict_requires_canon(self):
  r=action_menu(self.actor(),(self.source(),),strict=True)
  self.assertEqual(r.legal_options,());self.assertEqual(r.rejected[0][1],'LAB-ASSUMPTION-NOT-CANONICAL')
 def test_synthetic_lab_attack(self):
  x=action_menu(self.actor(),(self.source(),),strict=False)
  self.assertEqual(x.legal_options[0].target_id,'B1')
 def test_missing_rule(self):
  x=action_menu(self.actor(),(self.source(source_status='UNKNOWN'),),strict=False)
  self.assertEqual(x.rejected[0][1],'MISSING-AUTHORITY')
 def test_effect_adapter_not_ready(self):
  x=action_menu(self.actor(),(self.source(effect_adapter_ready=False,effect_adapter_id=None),),strict=False)
  self.assertEqual(x.rejected[0][1],'EFFECT-ADAPTER-NOT-READY')
 def test_canonical_spells_if_src_ready(self):
  spec=self.source('spell','spell','STANDARD',source_page_id=MAGIC,source_status='RULE-DERIVED',required_pa=10)
  r=action_menu(self.actor(),(spec,),source_evidence=(self.source_proof(MAGIC),))
  self.assertEqual(r.legal_options[0].kind,'spell')
 def test_spells_need_pa(self):
  spec=self.source('spell','spell','STANDARD',required_pa=10)
  x=action_menu(self.actor(available_pa=4),(spec,),strict=False)
  self.assertEqual(x.rejected[0][1],'INSUFFICIENT-PA')
 def test_unknown_pa_blocks(self):
  spec=self.source('spell','spell','STANDARD',required_pa=10)
  x=action_menu(self.actor(available_pa=None),(spec,),strict=False)
  self.assertEqual(x.rejected[0][1],'PA-NOT-KNOWN')
 def test_rank_gate(self):
  x=action_menu(self.actor(),(self.source(min_rank_index=3),),strict=False)
  self.assertEqual(x.rejected[0][1],'RANK-RESTRICTED')
 def test_standard_spent(self):
  x=action_menu(self.actor(standard_available=False),(self.source(),),strict=False)
  self.assertEqual(x.rejected[0][1],'STANDARD-SPENT')
 def test_full_needs_two_budgets(self):
  spec=self.source('full','attack','FULL')
  x=action_menu(self.actor(movement_available=False),(spec,),strict=False)
  self.assertEqual(x.rejected[0][1],'FULL-UNAVAILABLE')
 def test_reaction_trigger(self):
  s=self.source('dodge','reaction','REACTION',reaction_trigger='ENEMY-ATTACK-DECLARED',target_scope='SELF')
  x=action_menu(self.actor(),(s,),phase='REACTION',strict=False)
  self.assertEqual(x.legal_options[0].target_id,'A1')
 def test_reaction_wrong_trigger(self):
  s=self.source('dodge','reaction','REACTION',reaction_trigger='ENEMY-ATTACK-DECLARED',target_scope='SELF')
  x=action_menu(self.actor(reaction_trigger_observed=None),(s,),phase='REACTION',strict=False)
  self.assertEqual(x.rejected[0][1],'NO-SOURCE-TRIGGER')
 def test_reaction_not_on_turn(self):
  s=self.source('dodge','reaction','REACTION',reaction_trigger='ENEMY-ATTACK-DECLARED',target_scope='SELF')
  x=action_menu(self.actor(),(s,),phase='TURN',strict=False)
  self.assertEqual(x.rejected[0][1],'NO-REACTION-IN-TURN-DECISION')
 def test_reaction_spent(self):
  s=self.source('dodge','reaction','REACTION',reaction_trigger='ENEMY-ATTACK-DECLARED',target_scope='SELF')
  x=action_menu(self.actor(reaction_available=False),(s,),phase='REACTION',strict=False)
  self.assertEqual(x.rejected[0][1],'NOT-AVAILABLE-REACTION')
 def test_range_unknown_blocks(self):
  s=self.source(requires_range_check=True)
  x=action_menu(self.actor(range_confirmed=None),(s,),strict=False)
  self.assertEqual(x.rejected[0][1],'RANGE-UNRESOLVED')
 def test_los_unknown_blocks(self):
  s=self.source(requires_line_of_sight=True)
  x=action_menu(self.actor(los_confirmed=None),(s,),strict=False)
  self.assertEqual(x.rejected[0][1],'LINE-OF-SIGHT-UNRESOLVED')
 def test_movement_need_geometry(self):
  s=self.source('move','move','MOVEMENT',target_scope='POSITION')
  x=action_menu(self.actor(),(s,),strict=False)
  self.assertEqual(x.rejected[0][1],'GEOMETRY-UNRESOLVED')
 def test_movement_need_scenario(self):
  s=self.source('move','move','MOVEMENT',target_scope='POSITION')
  x=action_menu(self.actor(geometry_confirmed=True),(s,),strict=False)
  self.assertEqual(x.rejected[0][1],'POSITION-NOT-SOURCE-CONTRACTED')
 def test_movement_legal_with_source(self):
  s=self.source('move','move','MOVEMENT',target_scope='POSITION')
  x=action_menu(self.actor(geometry_confirmed=True,environment_contract=True),(s,),strict=False)
  self.assertEqual(x.legal_options[0].kind,'move')
 def test_area_no_source_target(self):
  s=self.source('area','spell','STANDARD',target_scope='AREA-ENEMY')
  x=action_menu(self.actor(geometry_confirmed=True),(s,),strict=False)
  self.assertEqual(x.rejected[0][1],'AREA-TARGETS-UNVERIFIED')
 def test_area_ready(self):
  s=self.source('area','spell','STANDARD',target_scope='AREA-ENEMY',max_targets=2)
  x=action_menu(self.actor(geometry_confirmed=True,known_area_targets=('B1',)),(s,),strict=False)
  self.assertEqual(x.legal_options[0].visible_target_count,1)
 def test_area_reject_invisible(self):
  s=self.source('area','spell','STANDARD',target_scope='AREA-ENEMY',max_targets=2)
  x=action_menu(self.actor(geometry_confirmed=True,known_area_targets=('SECRET',)),(s,),strict=False)
  self.assertEqual(x.rejected[0][1],'AREA-TARGETS-UNVERIFIED')
 def test_not_in_loadout(self):
  x=action_menu(self.actor(known_action_ids=('other',)),(self.source(),),strict=False)
  self.assertEqual(x.rejected[0][1],'NOT-IN-ACTOR-LOADOUT')
 def test_unknown_action(self):
  with self.assertRaises(CatalogError):self.source(kind='teleport_without_source')
 def test_duplicate_sources(self):
  with self.assertRaises(CatalogError):action_menu(self.actor(),(self.source(),self.source()),strict=False)
 def test_policy_can_use_compiled_spell(self):
  s=self.source('spell','spell','STANDARD',source_page_id=MAGIC,source_status='RULE-DERIVED')
  r=action_menu(self.actor(),(s,),source_evidence=(self.source_proof(MAGIC),))
  d=FighterDoctrine('A1','controller','disciplined','expert')
  v=VisibleContext('A1',1,1)
  decision=choose_action(d,v,r.legal_options)
  self.assertIn('spell',decision.action_id)
 def test_phase_unknown(self):
  with self.assertRaises(CatalogError):action_menu(self.actor(),(),phase='INVALID',strict=False)

if __name__=='__main__':unittest.main()

class SourceFreezeGate(unittest.TestCase):
 def test_unfrozen_canon_label_must_block_strict(self):
  spec=AbilitySource('atk','attack','STANDARD',COMBAT,'source-rule','RULE-DERIVED',effect_adapter_ready=True,effect_adapter_id='mock')
  actor=ActorActionState('ED',1,0,('atk',),enemy_ids_visible=('B',))
  x=action_menu(actor,(spec,),strict=True)
  self.assertEqual(x.rejected[0][1],'SOURCE-EVIDENCE-NOT-FROZEN')
 def test_bad_source_hash(self):
  with self.assertRaises(CatalogError):FrozenRuleEvidence(COMBAT,'X','not-hash','today','mock')
 def test_duplicate_source_proofs_rejected(self):
  p=FrozenRuleEvidence(COMBAT,'X','0'*64,'today','mock')
  with self.assertRaises(CatalogError):action_menu(ActorActionState('ED',1,0,()),(),source_evidence=(p,p))
