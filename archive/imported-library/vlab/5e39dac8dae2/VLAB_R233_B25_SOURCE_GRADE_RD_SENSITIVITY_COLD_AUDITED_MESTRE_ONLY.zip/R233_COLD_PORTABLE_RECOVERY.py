"""Cold check R233 manifest + independent arithmetic replay of recorded logs; NEVER reruns fights."""
import json,hashlib,zipfile,sys,tempfile,importlib.util
from pathlib import Path
def verify(zip_path):
 zpath=Path(zip_path)
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None,'ZIP_CRC'
  m=json.loads(z.read('SHA256_MANIFEST.json'));assert m['version']==233 and m['mestre_only'] is True
  assert set(z.namelist())==set(m['files'])|{'SHA256_MANIFEST.json'},'MEMBER_SET'
  for rel,v in m['files'].items():
   data=z.read(rel);assert len(data)==v['size'] and hashlib.sha256(data).hexdigest()==v['sha256'],'SHA '+rel
  with tempfile.TemporaryDirectory(prefix='R233_READONLY_RECHECK_') as temp:
   root=Path(temp);z.extractall(root)
   # Imported auditor functions read only frozen evidence, no imports of simulation runtime.
   sys.path.insert(0,str(root/'code'))
   try:
    import r233_independent_b25_audit
    out=r233_independent_b25_audit.audit(root,write=False)
   finally:sys.path.pop(0)
   assert out['status']=='PASS_R233_INDEPENDENT_25_LEVEL_BATTERY_B_LAB_SENSITIVITY'
  return {'status':'PASS_R233_COLD_PORTABLE_RECOVERY_LAB_CONDITIONAL','SHA256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'manifest_verified':len(m['files']),'CRC':'PASS','positions_B_regular':out['regular_positions'],'paired_rng_streams':out['exact_offensive_stream_paired_comparisons'],'original_runs':out['original_runs'],'official_cells_B':0,'historical_replays':0}
if __name__=='__main__':print(json.dumps(verify(sys.argv[1]),indent=2,ensure_ascii=False))
