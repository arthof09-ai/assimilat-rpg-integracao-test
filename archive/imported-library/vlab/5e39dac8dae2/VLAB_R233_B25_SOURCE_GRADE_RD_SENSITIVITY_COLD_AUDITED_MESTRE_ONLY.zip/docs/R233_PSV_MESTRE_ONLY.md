# R233 — Bateria B / 25 patamares / sensibilidade à RD — MESTRE-SIDE TEST

## Novo resultado mensurável

**25 posições regulares** de Bronze1★ até Lendário5★ foram exercitadas em uma **comparação LAB de ED virtual × Besta virtual de mesmo patamar**, com **4 seeds independentes por posição** e dois regimes de RD, total de **100 pares completos = 200 execuções originais**. Outros 200 espelhos apenas trocaram o rótulo de lado para detectar viés de implementação; **não são observações independentes**.

A auditoria read-only comprovou identidade exata de **iniciativas, ordem dos atores, dados de acerto, dados críticos, rolagens de dano e cronologia dos ataques nos 100 pares**. Dez pares terminaram com Vida diferente; a RD preservou **156 PV agregados** entre pares. Porém, a RD não alterou nenhum encerramento por limiar experimental de Vida nessa amostra: **182/200 braços** terminaram por LAB-HP-THRESHOLD; **18/200** foram censurados no horizonte de 12 rodadas. Essa observação NÃO significa que a RD seja irrelevante em lutas reais — apenas que a fonte/motor/fixture simplificados não observaram diferença no limiar terminal.

## Denominador e rastreabilidade

| Métrica | Resultado |
| --- | ---: |
| Posições B regulares investigadas | 25 |
| Seeds independentes por posição | 4 |
| Pares (RD ativada vs desativada) | 100 |
| Execuções originais por braço | 200 total |
| Espelhos de rótulo não independentes | 200 |
| Ataques nos braços originais | 3.162 |
| Acertos nos braços originais | 1.692 |
| Dano pós-RD solicitado, incluindo sobrevida excedida | 76.294 |
| Vida efetivamente retirada | 73.098 |
| Dano interceptado por RD neste LAB | 156 |
| Pares com fitas ofensivas idênticas | 100/100 |
| Pares com Vida terminal diferente | 10/100 |
| Encerramentos por limiar LAB | 182/200 |
| Censuras por horizonte | 18/200 |
| Adulterações semânticas com digest reconstruído rejeitadas | 4/4 |
| Células oficiais B | 0 |

## Limites científicos incontornáveis

- Submodelo legado existente **v0.6.1** corrigido e isolado desde R229 para crítico. **Não** é motor R18/v0.8.1, nem usa movimento, magia, cura, transformações ou habilidades de Besta.
- Personagens, equipamentos e espécies são **builds virtuais LAB**, não fichas físicas canônicas. O bônus genérico de proficiência da Besta usado como ataque e a interpretação de RD são hipóteses de LAB. Um par com RD OFF não deve ser entendido como uma criatura canônica desprovida de RD.
- Empates de iniciativa do legado seguem tiebreak por ID em vez de decisão universal competente; não servem como benchmark de scheduler oficial.
- O crítico negativo do legado ainda possui política de nenhuma consequência LAB; o positivo foi corrigido em cópia separada R229 com adversariais próprios.
- HP0 é critério de parada **laboratorial**, não morte/vitória canônica. Censura de 12 rodadas não é derrota nem empate oficial.
- Quatro seeds por posição não sustentam avaliação de balanceamento estatístico global. Os resultados são exploratórios com inferência delimitada ao corpus LAB.

## Segurança e persistência

`R233_B25_PREREG_BEFORE_EXEC.json`, `R233_B25_ROSTER_SNAPSHOTS.json`, 400 traços JSONL, auditor sem importação do motor e scorecard CSV permitem recuperação fria e recomputação de todos os cálculos. O primeiro ensaio V0 empregava token incorreto `NO-RD-LAB` em lugar de `OFF-LAB` e gerou 2 traços antes de interromper; esses 2 traços estão em `evidence/quarantine`, não contaminam o denominador nem foram reaproveitados como seed na V1.

O auditor rejeitou quatro adulterações rehash: permutar dados entre os braços mantendo a mesma soma, alterar classificação do crítico, fingir homologação canônica e alterar Vida após golpe.

## Continuidade

Este R233 apoia **B** no nível de sensibilidade **25/25 patamares regulares LAB**, mantendo ADM e Divina fora do denominador de rank regular. O benchmark científico de criatura completa permanece **0/27 células B homologadas**. VLAB global 0/17 contratos e 0/1.875 células. **Próxima missão prioritária:** fontes completas de Bestas específicas e ED para inserir suas habilidades no scheduler multiturmo real; passar de builds virtuais para duelos completos source-admissíveis. E continuará aguardando item P4.
