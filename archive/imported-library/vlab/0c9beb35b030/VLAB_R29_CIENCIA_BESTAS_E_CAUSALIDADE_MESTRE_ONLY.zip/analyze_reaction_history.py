import json,pathlib,statistics
ROOT=pathlib.Path('/mnt/data/vlab_research/work/reconstruction/r23_delivery/records_main/runs')
by={}
for path in ROOT.glob('*/FINAL_RUN_RECORD.json'):
 d=json.loads(path.read_text())
 if d['policy'] not in ('BASIC_ATTACK','DEFENDER_IF_ELIGIBLE'):continue
 by[(d['seed'],d['policy'])]=d
pairs=[]
for seed in sorted({x[0] for x in by}):
 a=by[(seed,'BASIC_ATTACK')]; b=by[(seed,'DEFENDER_IF_ELIGIBLE')]
 pairs.append({'seed':seed,'basic_hp_removed':sum(x['hp_removed'] for x in a['metrics']['actors'].values()),'defend_hp_removed':sum(x['hp_removed'] for x in b['metrics']['actors'].values()),'defend_reactions':b['metrics']['reactions'],'basic_turns':a['metrics']['rounds_observed'],'defend_turns':b['metrics']['rounds_observed'],'basic_winner':a['metrics']['winner'],'defend_winner':b['metrics']['winner'],'basic_attacks':a['metrics']['attacks'],'defend_attacks':b['metrics']['attacks'],'delta_hp_removed':sum(x['hp_removed'] for x in b['metrics']['actors'].values())-sum(x['hp_removed'] for x in a['metrics']['actors'].values())})
summary={'pairs':len(pairs),'total_reactions':sum(x['defend_reactions'] for x in pairs),'total_basic_removed':sum(x['basic_hp_removed'] for x in pairs),'total_defend_removed':sum(x['defend_hp_removed'] for x in pairs),'mean_delta_hp_removed':statistics.mean(x['delta_hp_removed'] for x in pairs),'pairs_lower_hp_removed':sum(x['delta_hp_removed']<0 for x in pairs),'pairs_equal_hp_removed':sum(x['delta_hp_removed']==0 for x in pairs),'pairs_higher_hp_removed':sum(x['delta_hp_removed']>0 for x in pairs),'pairs_winner_changed':sum(x['basic_winner']!=x['defend_winner'] for x in pairs),'prior_source':'VLAB_R23_EXPERIMENTAL_FICTITIOUS_NONCANONICAL','cross_policy_confounds':['conditional reaction decision affects number of attacks and RNG stream','R23 reaction does not renew at own turn unlike R26','RD0 damage fixture, not Bronze1 R27 RD5','observations paired by seed but not identical action RNG schedule']}
path=pathlib.Path('/mnt/data/vlab_r29/r29_r23_reaction_reanalysis.json');path.write_text(json.dumps({'summary':summary,'pairs':pairs},ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2));print('PAIRS',pairs)
