#!/usr/bin/env python3
"""R29 experimental input-level contrast using unchanged R27/R26/R25/R18 and v0.8.1.
The existing native resolver, A1 scheduler and transaction logic remain untouched.
All source and fixture changes scoped to this process; never changes historical ZIP.
"""
import sys,hashlib,copy,json,os,pathlib,argparse,sqlite3
ROOT=pathlib.Path(__file__).resolve().parent
HIST=pathlib.Path('/mnt/data/vlab_research/work')
sys.path.insert(0,str(HIST/'fusion_stage12'))
import vlab_r27_scientific_baseline as r
import vlab_r25_rule_derived_benchmark as r25
import vlab_r18_interactive as core

ORIG_ROSTER=r.roster;ORIG_MANIFEST=r.manifest;ORIG_PREVIEW=r25.preview
CURRENT=None
MODES=('EQ_FIRST','OFF_FIRST')
SEEDS=(11,23,37,41,53,67,71,83)

def install(mode):
 global CURRENT
 CURRENT=mode
 assert mode in MODES
 def roster(left,right):
  x=ORIG_ROSTER(left,right)
  if mode=='OFF_FIRST':
   for i,label in enumerate((left,right)):
    if label=='OFENSIVO':x[i]['init_bonus']+=12
  return x
 def manifest(left,right,kind):
  x=ORIG_MANIFEST(left,right,kind)
  x['r29_actor_tape']={'experiment':'R29_CONTROLLED_ORDER_ONLY','mode':mode,
    'initiative_intervention':{'OFENSIVO':12 if mode=='OFF_FIRST' else 0},
    'attack_tape':'seed+logical_profile+own_action_index; independent of turn order and side',
    'source_status':'LAB_CONTRAFACTUAL_NONCANONICAL','canonical_credit':0,
    'freeze':'historical engines unchanged; fixture in-memory only'}
  return x
 def preview(st,rev):
  p=ORIG_PREVIEW(st,rev)
  if p is None:return None
  actor=p['actor']
  profile='EQUILIBRADO' if 'EQUILIBRADO' in st['actors'][actor]['name'] else 'OFENSIVO'
  n=1+sum(1 for e in st['r21_control']['events'] if e['kind']=='TURN_END' and e['actor_id']==actor)
  seed=st['seed']
  critical=[core.dice(seed,n,'R29-CRITICAL-'+profile+'-'+str(j),1,6)[0] for j in (1,2,3)]
  trig='POSITIVE' if critical[:2]==[6,6] and critical[2]>=5 else ('NEGATIVE' if critical[:2]==[1,1] and critical[2]<=2 else None)
  hit=core.dice(seed,n,'R29-TOHIT-'+profile,1,6)
  dmg=core.dice(seed,n,'R29-DAMAGE-'+profile,3,6)
  fs=st['actors'][actor]['stats']
  p.update({'critical_sequence':critical,'critical_trigger':trig,'hit_dice':hit,
     'hit_total':sum(hit)+fs['for']+fs['luta'],'damage_dice':dmg,'damage_requested':sum(dmg)})
  return p
 r.roster=roster;r.manifest=manifest;r25.preview=preview

def run_case(mode,seed):
 install(mode)
 base=ROOT/'runs'/mode
 base.mkdir(parents=True,exist_ok=True)
 db=base/f'EQUILIBRADO__OFENSIVO__SEED_{seed}.sqlite'
 receipt=base/f'EQUILIBRADO__OFENSIVO__SEED_{seed}.json'
 if db.exists():
  if not receipt.exists():raise RuntimeError('PARTIAL_EFFECT_HOLD_DO_NOT_RETRY '+str(db))
  recorded=json.loads(receipt.read_text());hist=r.history(db)
  assert hist['head']==recorded['head'] and hist['revision']==recorded['revision']
  return recorded
 outcome=r.run(base,seed,'EQUILIBRADO','OFENSIVO',max_rounds=24)
 hist=r.history(db);events=[]
 for e in hist['events']:
  if e['detail'].get('action')!='ATTACK':continue
  p=e['detail']['inner']['preview'];prof='EQUILIBRADO' if 'EQUILIBRADO' in hist['state']['actors'][p['actor']]['name'] else 'OFENSIVO'
  events.append({'profile':prof,'actor':p['actor'],'crit':p['critical_sequence'],'hit':p['hit_dice'],
   'damage':p['damage_dice'],'trigger':p['critical_trigger'],
   'native_net':e['detail']['inner']['native']['effect']['net'],
   'native_hash':e['detail']['inner']['native']['native_trace_hash']})
 rows={'status':outcome['status'],'mode':mode,'seed':seed,'winner':outcome['winner'],
   'winner_profile':None if outcome['winner'] is None else ('EQUILIBRADO' if 'EQUILIBRADO' in hist['state']['actors'][outcome['winner']]['name'] else 'OFENSIVO'),
   'first_profile':'EQUILIBRADO' if mode=='EQ_FIRST' else 'OFENSIVO','events':events,
   'attacks':outcome['summary']['attacks'],'rounds':outcome['round_reached'],
   'revision':outcome['revision'],'head':outcome['head'],'db_sha256':outcome['sqlite_sha256'],
   'a1_events':outcome['a1_events'],'native_hits':outcome['summary']['hits'],'hp_removed':outcome['summary']['hp_removed'],
   'no_canonical_credit':True}
 receipt.write_text(json.dumps(rows,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 return rows

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--seeds',nargs='*',type=int,default=list(SEEDS));args=ap.parse_args()
 for seed in args.seeds:
  for mode in MODES:
   z=run_case(mode,seed);print(mode,seed,z['status'],z['winner_profile'],z['attacks'],z['rounds'],flush=True)
  a,b=(json.loads((ROOT/'runs'/m/f'EQUILIBRADO__OFENSIVO__SEED_{seed}.json').read_text()) for m in MODES)
  for profile in ('EQUILIBRADO','OFENSIVO'):
   aa=[(e['crit'],e['hit'],e['damage']) for e in a['events'] if e['profile']==profile]
   bb=[(e['crit'],e['hit'],e['damage']) for e in b['events'] if e['profile']==profile]
   assert aa[:min(len(aa),len(bb))]==bb[:min(len(aa),len(bb))],('RNG_TAPE_DIVERGED',seed,profile)
  print('ACTOR_TAPE_PREFIX_MATCH',seed,flush=True)
if __name__=='__main__':main()
