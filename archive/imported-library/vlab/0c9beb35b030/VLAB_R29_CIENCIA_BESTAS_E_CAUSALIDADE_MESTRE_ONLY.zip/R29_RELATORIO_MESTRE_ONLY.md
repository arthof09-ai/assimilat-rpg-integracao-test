# PSV — VLAB pós-R28: ação real, causalidade de iniciativa e fronteira de Besta

**Operação existente:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01. **Data:** 15/10/2026. **Escopo:** Mestre-only; experimental condicionado e matemática de fontes Notion. **Baseline:** DMG-RANK-01 v1.1 e R27 ANTES intocadas, assim como R28, seeds e UNKNOWN_EFFECT legados. **Sem nova regra ou motor paralelo.**

## 1. Progresso P0 — primeira ação de Besta real

**Resultado material honesto:** Estágio A (fonte documental) verificado para Galidemus/Patada e Rato Flamejante/Mordida; estágio B Galidemus tem recibo histórico R24 de *componente nativo* com acerto artificial 999 e alvo fictício, preservado e NÃO repetido nesta rodada; estágio C (ação integral admitida) **0/8** candidatas da coorte dirigida R28; estágio D (combate integral entre Bestas) **0/0 tentados com contrato válido**. Não fabricar preflight para simular C ou D. Quatro fontes adicionais Bronze5/Prata1 foram triadas para análise de fronteira, sem acrescentar essas quatro às oito candidatas históricas nem declarar censo global.

### Campos ainda faltantes e critério de escolha

- **Galidemus B1** `eddc2b32-4ede-829f-8a75-011e8acbf429`: `Patada 1d4+DES13` cortante (14–17; média 15,5), Vida32, CA21. Falta Luta competente, enquadramento como Ação Padrão/PA da habilidade nomeada, alcance/posição/alvo, precedência Vida/CA legados versus criação atual, snapshot autorizado, defesa/reação do alvo. **DES em dano não prova DES em acerto.** A cópia R24 tem *somente* componente nativo em alvo fictício.
- **Rato Flamejante B1** `e29c2b32-4ede-8370-8b21-81332d26422a`: `Mordida Flamejante 1d4+FOR6`, perfurante (7–10; média8,5), Vida impressa14, CA28. FOR coincide com teste básico padrão; mas a palavra *flamejante* não prova nem exclui efeito Fogo adicional. Falta o mesmo contrato individual/ação/PA/geometria/freeze; divergências de Vida/CA não corrigidas silenciosamente.
- **Aproximação de admissão:** a Mordida tem menos conflito de atributo **de acerto** (FOR no dano), a Patada já tem prova B nativa. Não há prova suficiente para declarar vencedor global de proximidade documental nem autorizar despacho; reconciliar campos concretos com DMG e decisão do Mestre por autoridade existente. IBX-90, IBX-92 consultadas anteriormente; estados NOVA sem ACK presumido, sem Inbox duplicada.
- **Questão normativa aberta:** se a proficiência geral Bronze normal +6 corresponde automaticamente à perícia Luta do ataque natural ou se requer treinamento individual. Testes condicionais apresentam Luta=0 e +6 como alternativas, nunca escolha canônica.

## 2. Ponte quantitativa com DMG — fórmula real versus 3d6 genérico

A Biblioteca contém `DMG_F0_F6_LOTE_CIENTIFICO_002.zip`, `libfile_84761c9a591c8191bc304533e4074ee9`; existência verificada, mas a materialização de bytes retornou **acesso negado**, inclusive ao fornecedor R31. Portanto **NÃO** reivindico leitura integral nem reprocessamento de 45 páginas do lote; reutilizo a fonte Notion Galidemus, as fórmulas explícitas e o contrato `DMG-CORPUS-TO-VLAB-READONLY-01 v0.2` existente (`libfile_f55d109ea3d4819184f1d7bd4f4b86f7`). Não criar corpus paralelo.

| Expressão de fonte | Bruto médio | RD5 hipotética | Líquido médio **por acerto** | P(líquido>0 por acerto) |
|---|---:|---:|---:|---:|
| Galidemus Patada `1d4+13` | 15,50 | 5 | **10,50** | 100% |
| Rato Mordida `1d4+6` | 8,50 | 5 | **3,50** | 100% |
| Genérico Bronze normal `3d6` | 10,50 | 5 | **5,5231** | 95,37% |

Galidemus possui **1,90×** o dano líquido médio do 3d6 genérico **SE atingir** e se a RD5 geral for aplicável sem resistência adicional. Não somar automaticamente o 3d6 à Patada nem inferir crítico, efeito ou PA. **Precisão condicional separada:** Galidemus FOR5+Luta6 tem máximo17 em 1d6; Rato FOR6+Luta6 máximo18. Contra CA impressas 28 e 21, respectivamente, a chance básica de cada um acertar o outro é **0%** nesse enquadramento específico, independentemente da magnitude de dano. Sem Luta+6 também não acertam. Isso ilustra que fórmula de dano real não basta para ação legal.

## 3. Experimento causal novo — iniciativa com tapes independentes por ator

**Protocolo predefinido:** quatro sementes históricas {11,23,37,41}; dois mesmos atores virtuais Equilibrado×Ofensivo, mesmas posições e atributos, HP50/50, dano3d6 e RD5; 2 condições de iniciativa EQ-first versus OFF-first por +12 somente ao bônus de iniciativa OFF. Núcleo **R27→R26→R25→R18 A1/v0.7/v0.8.1 inalterado**. A rolagem de cada evento usa `seed + perfil lógico + índice do próprio ataque`, desacoplada da ordem global e da posição; a política de falha crítica continua em laboratório R27. Alteração apenas de fixture/tape em memória, com manifesto no estado SQLite e recibo.

| Seed | Equilibrado primeiro | Ofensivo primeiro | Vencedor inverteu? |
|---:|---|---|---|
| 11 | Equilibrado | Ofensivo | Sim |
| 23 | Equilibrado | Equilibrado | Não |
| 37 | Ofensivo | Ofensivo | Não |
| 41 | Equilibrado | Ofensivo | Sim |

**Evidência:** **8/8 cenas nativas completas**, em **4/4 blocos de sementes pareadas**, com cabeçalho/journal, hash SQLite, integridade `PRAGMA`, nenhuma intenção pendente, hashes/efeitos do resolvedor e validação dos *prefixos idênticos* das rolagens de cada combatente nas duas condições. Em **2/4 sementes**, o vencedor mudou apenas pela prioridade de agir; quem agiu primeiro venceu **6/8 cenários**. Não tratar 8 cenas como oito sementes independentes. A pequena amostra **não estima** uma probabilidade geral, nem prova que todo resultado 28/40 da R27 é causado por iniciativa. Dá uma demonstração causal sob intervenção limitada, mais rigorosa que a R28, sem reatribuição de RNG por ordem.

**Interrupção protegida:** a quinta semente `53` ficou `ACTIVE` na condição EQ-first, revisão12, `pending=0`, SHA256 SQLite `714c8d6b49d2a5bd54989dc7177d72c3254a71d8cce34b02eb3b3d58743dfc0e`; classificação **PARCIAL/HOLD**, não foi retomada automaticamente após timeout e não compõe denominador 8/8. A semente53 prévia da R28 e as duas UNKNOWN_EFFECT da R27 também permanecem intocadas.

## 4. Fronteira real documental Bronze5→Prata1 — mecanismo discriminante

Fontes Mestre abertas:
- **Frígido Ossário** B5 (`f0dc2b32-4ede-820a-b947-0168d4a53315`), FOR18, CA31, Vida125, Rabada `1d6+FOR`.
- **Rinolupo** P1 (`034c2b32-4ede-83ff-a711-8144011beaf3`), FOR30, CA27, Vida228, Investida Feroz `2d6+FOR`, e **Pele Couraçada `RDF 10`**.

**R28, bruto genérico:** `3d6→RD15`: 0,06944 líquido médio **por acerto** (4,63% dos acertos causam dano). **Fonte real B5:** Rabada `1d6+18→RD15`: 6,5 líquido médio por acerto, **100%** dos acertos causam 4–9. O aumento equivale a ~93,6× a métrica genérica por acerto, se o mesmo RD e tipagem forem aplicáveis, sem supor que o 3d6 se soma à habilidade. Com teste `1d6+FOR18+Luta6` contra CA27: 3/6 faces acertam, 3,25 dano/ação estimado. **Com Luta0:** 0/6 faces. Portanto a proficiência é decisiva também para a fronteira.

**GATE CRÍTICO RDF:** Rinolupo possui `RDF10` físico. Não foi encontrada regra inequívoca que permita somar, substituir ou selecionar entre sua RDF10 e a RD geral Prata15 para a Rabada. Se somente RD15: média6,5/hit; se somente RDF10: média11,5/hit; **se RD15+RDF10 cumulativas (mera hipótese): média 0/hit**, pois máximo da Rabada24 é menor que25. **NÃO escolher por conveniência.** Seu efeito ativo, tipo de dano e ordem de mitigação exigem a fonte competente. Logo 0 duelos completos Bronze5↔Prata1; identificação de um experimento real de alto poder discriminatório.

**Sentido Prata1→Bronze5:** Investida Feroz `2d6+FOR30` tem bruto médio37. Contra RD5 geral Bronze normal apenas, líquido médio32 por acerto. Mesmo `2d6+FOR30` sem Luta já excede CA31 da ficha do Frígido Ossário em todas as 36 faces possíveis; porém Investida pode ter carga/geometria/rider e não há autorização para omiti-los nem substituir a ficha por derivação. Comparação **documental, não combate legal**.

## 5. Reações — reutilização científica de eventos R23, sem inflar execução nova

Em vez de repetir simulação antiga, foram reabertos os **16 recibos R23** da célula fictícia Bronze1 em duas políticas (8 sementes × 2). A política DEFENDER produziu **16 Reações nativas**, Vida total retirada **384→325** (−59, −15,36% em totais), e foi inferior em dano retirado nos **8/8 pares**; delta médio pareado de **−7,375 pontos/combate**, bootstrap por semente 95% indicativo [−8,375, −6,375]. Vencedor mudou em **1/8** sementes; média de duração **3,125→3,125** rodadas. Os eventos são **HISTÓRICOS R23**, não oito novos combates R29.

**Limites:** R23 usa RD0, dados 1d6 da fixture e não renova Reação por turno; não é compatível mecanicamente com a coorte R27 de RD5/críticos/R26. Não atribuir redução de 59 integralmente à reação isolada, porque alteração de política também pode mudar cadência e fluxos de RNG. Resultado: prova de efeito material de DEFENDER naquele ambiente, não efeito específico em Bronze1 real. Estudo R27+R26 com reações corretamente tipadas continua aberto.

## 6. Contabilidade e segurança

| Indicador | Contagem e denominador |
|---|---|
| Novas cenas nativas pareadas concluídas R29 | **8/8** (4 sementes × 2 condições) |
| Seed 53 R29 interrompida | **1/1 PARCIAL**, fora dos oito resultados |
| Ações reais integralmente admitidas | **0/8** candidatas herdadas/triadas |
| Combates reais completos/tentados legitimamente | **0/0** |
| Reações analisadas | **16**, provenientes de **8/8 pares históricos R23** |
| Fronteiras com matemática fonte-específica | **1/4** (B5↔P1) |
| Fronteiras com combates completos | **0/4** |
| Patamares com combate condicionado VLAB | **1/25** (Bronze1 sintético) |
| Patamares com combate de Bestas reais | **0/25** |
| Células canônicas | **0/1.875** |
| VLAB contratos terminais | **0/17** |
| DMG histórico | **1/18**, não reaud itado nesta rodada |

Nenhuma mutação em DMG-RANK v1.1, fichas oficiais, Party, O Primeiro, duelistas Vigias, ZIPs históricos ou nos bancos parciais. IBX-56 BLOCKED-EXTERNAL. IBX-90/91/92 sem ACK presumido. Writer/lease/epoch/fencing/GREEN produtivos HOLD. Nenhuma promoção sem NAC-PASS-02.

## 7. Próxima fronteira exata

(1) Resolver a proficiência `Luta +6` e precedência de Vida/CA para fonte de Besta natural, pelo Mestre/DMG e NAC-NORM-01 conforme competência, sem inventar regra. (2) Verificar escopo de RDF10 do Rinolupo (cumulatividade, tipo, aplicação permanente/ativa), distinguindo RD geral/temporal/específica. (3) Fechar geometria, classe/custo e target state da ação mais simples para habilitar C; somente depois usar motor nativo completo. (4) Conduzir estudo de reação com R26 renovação, com seeds e streams iguais, sem contaminar R27. (5) Integrar fisicamente o pacote DMG F0–F6 assim que o acesso byte/documental existir, não reconstruir corpus em paralelo.

**NAC-PASS-02:** verificação técnica local de artefatos PASS; certificação terminal, promoção normativa e release produtivo **HOLD**. Esta mensagem não representa autorização para a primeira execução real nem homologação de balanceamento.
