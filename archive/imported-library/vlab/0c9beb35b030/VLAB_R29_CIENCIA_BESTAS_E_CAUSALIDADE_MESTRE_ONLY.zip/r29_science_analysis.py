#!/usr/bin/env python3
"""R29 purely documentary mathematics + independent audit of native historical events."""
import json,hashlib,sqlite3,math,random,statistics,itertools,pathlib
from collections import defaultdict
ROOT=pathlib.Path(__file__).parent

def dist_expr(dice,faces,bonus=0):
 out={bonus:1}
 for _ in range(dice):
  nxt=defaultdict(int)
  for s,n in out.items():
   for j in range(1,faces+1):nxt[s+j]+=n
  out=dict(nxt)
 return out

def conditional_damage(n,f,b,rd):
 d=dist_expr(n,f,b);tot=sum(d.values());return {'dice':f'{n}d{f}+{b}','RD_assumption':rd,'min_raw':min(d),'max_raw':max(d),'mean_raw':sum(k*v for k,v in d.items())/tot,'mean_net':sum(max(0,k-rd)*v for k,v in d.items())/tot,'p_net_positive':sum(v for k,v in d.items() if k>rd)/tot}

cases={
 'GALIDEMUS_PATADA_RD5':conditional_damage(1,4,13,5),
 'RATO_MORDIDA_RD5':conditional_damage(1,4,6,5),
 'BRONZE1_GENERIC_RD5':conditional_damage(3,6,0,5),
 'FRIGIDO_RABADA_RD15':conditional_damage(1,6,18,15),
 'FRIGIDO_RABADA_RD10_ONLY':conditional_damage(1,6,18,10),
 'FRIGIDO_RABADA_RD25_HYPOTHETICAL_STACK':conditional_damage(1,6,18,25),
 'BRONZE_GENERIC_TO_PRATA_RD15':conditional_damage(3,6,0,15),
 'RINOLUPO_INVESTIDA_TO_BRONZE_RD5':conditional_damage(2,6,30,5),
}
hit=lambda faces,attr,bonus,ca:sum(f+attr+bonus>ca for f in range(1,faces+1))/faces
cases['conditional_precisions']={
 'FRIGIDO_FOR18_LUTA6_TO_RINOLUPO_CA27':hit(6,18,6,27),
 'FRIGIDO_FOR18_LUTA0_TO_RINOLUPO_CA27':hit(6,18,0,27),
 'GALIDEMUS_FOR5_LUTA6_TO_RATO_CA28':hit(6,5,6,28),
 'RATO_FOR6_LUTA6_TO_GAL_CA21':hit(6,6,6,21),
 'RINOLUPO_FOR30_LUTA0_TO_FRIGIDO_CA31':sum(a+b+30>31 for a in range(1,7) for b in range(1,7))/36,
}
cases['conditional_expected_damage_per_action']={
 'FRIGIDO_TO_RINOLUPO_IF_RD15_AND_LUTA6':cases['FRIGIDO_RABADA_RD15']['mean_net']*cases['conditional_precisions']['FRIGIDO_FOR18_LUTA6_TO_RINOLUPO_CA27'],
 'FRIGIDO_TO_RINOLUPO_IF_RD25_AND_LUTA6':cases['FRIGIDO_RABADA_RD25_HYPOTHETICAL_STACK']['mean_net']*cases['conditional_precisions']['FRIGIDO_FOR18_LUTA6_TO_RINOLUPO_CA27'],
 'GALIDEMUS_DAMAGE_ON_HIT_IF_RD5':cases['GALIDEMUS_PATADA_RD5']['mean_net'],
 'GALIDEMUS_GENERIC_DAMAGE_ON_HIT_IF_RD5':cases['BRONZE1_GENERIC_RD5']['mean_net']
}

runs=ROOT/'runs';audit=[]
for seed in (11,23,37,41):
 pair={}
 for mode in ('EQ_FIRST','OFF_FIRST'):
  p=runs/mode/f'EQUILIBRADO__OFENSIVO__SEED_{seed}'
  receipt=json.loads(p.with_suffix('.json').read_text())
  data=p.with_suffix('.sqlite').read_bytes()
  assert hashlib.sha256(data).hexdigest()==receipt['db_sha256']
  con=sqlite3.connect(p.with_suffix('.sqlite'))
  assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  meta=dict(con.execute('SELECT key,value FROM meta'))
  assert meta['head']==receipt['head'] and int(meta['revision'])==receipt['revision']
  assert con.execute('SELECT count(*) FROM pending').fetchone()[0]==0
  assert con.execute('SELECT count(*) FROM events').fetchone()[0]==receipt['revision']
  con.close()
  pair[mode]=receipt
 for profile in ('EQUILIBRADO','OFENSIVO'):
  a=[(e['crit'],e['hit'],e['damage']) for e in pair['EQ_FIRST']['events'] if e['profile']==profile]
  b=[(e['crit'],e['hit'],e['damage']) for e in pair['OFF_FIRST']['events'] if e['profile']==profile]
  assert a[:min(len(a),len(b))]==b[:min(len(a),len(b))]
 audit.append({'seed':seed,'eq_first_winner':pair['EQ_FIRST']['winner_profile'],
  'off_first_winner':pair['OFF_FIRST']['winner_profile'],
  'winner_changed':pair['EQ_FIRST']['winner_profile']!=pair['OFF_FIRST']['winner_profile'],
  'eq_first_attacks':pair['EQ_FIRST']['attacks'],'off_first_attacks':pair['OFF_FIRST']['attacks'],
  'RNG_actor_stream_prefix':'PASS','native_receipts_verified':True,
  'first_actor_wins_eq_first':pair['EQ_FIRST']['winner_profile']=='EQUILIBRADO',
  'first_actor_wins_off_first':pair['OFF_FIRST']['winner_profile']=='OFENSIVO'})
partial=runs/'EQ_FIRST'/'EQUILIBRADO__OFENSIVO__SEED_53.sqlite'
con=sqlite3.connect(partial)
meta=dict(con.execute('SELECT key,value FROM meta'))
partial_status={'db':str(partial),'phase':json.loads(meta['state'])['phase'],'revision':int(meta['revision']),
 'pending':con.execute('SELECT count(*) FROM pending').fetchone()[0],
 'sqlite_sha256':hashlib.sha256(partial.read_bytes()).hexdigest(),
 'action':'HOLD_UNKNOWN_EFFECT_NO_AUTOMATIC_RESUME'}
con.close()
react=json.loads((ROOT/'r29_r23_reaction_reanalysis.json').read_text())
rd=[p['delta_hp_removed'] for p in react['pairs']]
rng=random.Random(20261015)
bs=sorted(sum(rng.choices(rd,k=len(rd)))/len(rd) for _ in range(20000))
react['summary']['mean_delta_bootstrap_95pct_cluster_by_seed']=[bs[500],bs[19499]]
result={'schema':'R29_SCIENCE_EVIDENCE_NO_CANON','operation':'OP-VLAB-FUSION-SANDBOX-01',
 'source_library':{'r27':'libfile_1a06c19c497c819197d8f2284d8de09e','r28':'libfile_1baba668c96481919099f80d36ff9a0e','DMG_F0_F6':'libfile_84761c9a591c8191bc304533e4074ee9'},
 'evidence_status':{'R27':'IMMUTABLE','R28':'IMMUTABLE','DMG_F0_F6':'EXISTENCE_CONFIRMED_BYTES_UNAVAILABLE'},
 'math':cases,'causal_native':{'independent_seed_pairs':len(audit),'paired_native_scenes':2*len(audit),'winner_reversed_pairs':sum(a['winner_changed'] for a in audit),'first_actor_wins':sum(a['first_actor_wins_eq_first']+a['first_actor_wins_off_first'] for a in audit),'pairs':audit,'limitations':['4 seeds = small N','native deterministic same actor rolls but native reactions absent','source fixtures noncanonical']},
 'partial_r29_new':partial_status,
 'reactions_R23_reanalyzed':react,
 'first_real_action':{'stages':{'A':'2 DOCUMENTARY_ACTIONS_VERIFIED_GALIDEMUS_AND_RATO','B':'GALIDEMUS_R24_COMPONENT_PREVIOUSLY_NATIVELY_EXECUTED_WITH_FORCED_HIT_FICTITIOUS_TARGET','C':0,'D':0},'source_candidate_count_R28':8,'additional_boundary_sources_examined':2,'real_actions_admitted':0},
 'canon_credit':0}
(ROOT/'R29_RESULTS_MASTER_ONLY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print(json.dumps({'math':cases,'native':result['causal_native'],'partial':partial_status,'reactions':react['summary']},ensure_ascii=False,indent=2)[:13000])
