#!/usr/bin/env python3
"""MESTRE-ONLY: cold, read-only R160 selected offense receipt reconciliation.

Input: untouched R160 ZIP. Output: derived CSV/JSON/MD in a separate folder.
No Notion, network, or original SQLite writes. Python standard library only.
"""
import argparse, csv, hashlib, io, json, sqlite3, tempfile, zipfile
from collections import Counter
from pathlib import Path

def canon(row):
    return json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')

def sha256(b):
    return hashlib.sha256(b).hexdigest()

def check(condition, reason):
    if not condition:
        raise AssertionError(reason)

def run(src, out):
    original_sha = sha256(src.read_bytes())
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(src) as z:
        check(z.testzip() is None, 'ZIP CRC invalid')
        manifest = json.loads(z.read('R160_SHA256_MANIFEST.json'))
        entries = manifest['files']
        for f in entries:
            blob = z.read(f['path'])
            check(len(blob) == f['size'] and sha256(blob) == f['sha256'], 'manifest mismatch: ' + f['path'])
        data = list(csv.DictReader(io.StringIO(z.read('r151_r160/R160_NEW_NATIVE_OFFENSE_RECEIPTS_SOURCE_SCOPED.csv').decode('utf-8'))))
        filename_set = {r['ledger_file'] for r in data}
        indexed = {}
        event_count = 0
        per_bank = {}
        for filename in sorted(filename_set):
            pathname = 'r151_r160/runs/' + filename
            with tempfile.NamedTemporaryFile(suffix='.sqlite') as f:
                f.write(z.read(pathname))
                f.flush()
                # read-only to avoid changing original/checkpoints even in the temporary copy
                con = sqlite3.connect('file:' + f.name + '?mode=ro', uri=True)
                try:
                    check(con.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'SQLite corruption ' + filename)
                    check(con.execute('SELECT COUNT(*) FROM pending').fetchone()[0] == 0, 'UNKNOWN_EFFECT ' + filename)
                    meta = dict(con.execute('SELECT key,value FROM meta'))
                    previous, count = meta['genesis'], 0
                    for seq, row_json, rowsha, prev in con.execute('SELECT seq,row_json,row_sha,prev FROM events ORDER BY seq'):
                        row = json.loads(row_json)
                        check(seq == count + 1 and prev == previous and row['prev'] == prev, 'event sequence ' + filename)
                        check(sha256(canon(row)) == rowsha, 'hash chain ' + filename)
                        actions = row.get('detail', {}).get('native_actions', row.get('detail', {}).get('native_action', []))
                        if isinstance(actions, dict):
                            actions = [actions]
                        for index, action in enumerate(actions, 1):
                            indexed[(filename, seq, index)] = (row, action, rowsha)
                        previous = rowsha
                        count += 1
                    check(count == int(meta['revision']) and previous == meta['head'], 'terminal head ' + filename)
                    event_count += count
                    per_bank[filename] = {'commits': count, 'pending': 0, 'sha_chain': 'PASS'}
                finally:
                    con.close()
        corrected = []
        for raw in data:
            key = (raw['ledger_file'], int(raw['seq_R18']), int(raw['action_index_in_tx']))
            check(key in indexed, 'unmapped native event ' + repr(key))
            event, native, event_sha = indexed[key]
            if native.get('action') == 'weapon_attack':
                before, after = int(native['before_hp']), int(native['after_hp'])
                net, actual = int(native['net']), int(native['hp_loss_actual'])
                source_raw, source_rd = int(native['raw']), int(native['rd_applied'])
                actor, target = native['from'], native['to']
                hp_evidence = 'weapon_attack.before_hp/after_hp/hp_loss_actual'
            elif native.get('action') == 'spell':
                before, after = int(native['hp_before']), int(native['hp_after'])
                net = int(native['effective'])  # as logged pre-clamp in three terminal spell cases
                actual = before - after
                source_raw, source_rd = int(native['raw']), int(native['rd_applied'])
                actor, target = native['by'], native['target']
                hp_evidence = 'spell.hp_before/hp_after'
            else:
                raise AssertionError('Unexpected native action ' + repr((key, native.get('action'))))
            check(actor == raw['actor'] and target == raw['target'], 'actor/target mismatch ' + repr(key))
            check(int(raw['damage_raw']) == source_raw and int(raw['rd_applied']) == source_rd, 'raw/RD mismatch '+repr(key))
            check(int(raw['net_post_RD']) == net, 'post RD mismatch '+repr(key))
            check(0 <= after <= before and actual == before - after and net >= actual >= 0, 'HP invariant '+repr(key))
            updated = dict(raw)
            updated.update({'hp_before_native': before, 'hp_after_native': after,
                            'hp_effectively_lost_reconciled': actual, 'overkill_reconciled': net - actual,
                            'original_effective_overstatement': int(raw['hp_effectively_lost']) - actual,
                            'source_event_SHA256': event_sha, 'source_state_fields': hp_evidence,
                            'reconciled_status': 'PASS_SELECTED_NATIVE_SOURCE_READONLY'})
            corrected.append(updated)
    keys = ['net_post_RD','hp_effectively_lost','overkill','hp_effectively_lost_reconciled','overkill_reconciled','original_effective_overstatement']
    totals = {k: sum(int(x[k]) for x in corrected) for k in keys}
    mismatches = [{k: x[k] for k in ('run_id','seq_R18','action_index_in_tx','hp_before_native','hp_after_native','hp_effectively_lost','hp_effectively_lost_reconciled','original_effective_overstatement')}
                  for x in corrected if x['original_effective_overstatement'] != 0]
    check(len(corrected) == len(data), 'Not all receipts reconciled')
    check(totals['net_post_RD'] == totals['hp_effectively_lost_reconciled'] + totals['overkill_reconciled'], 'global net invariant')
    check(totals['hp_effectively_lost'] - totals['hp_effectively_lost_reconciled'] == totals['original_effective_overstatement'], 'difference invariant')
    csv_path = out/'VLAB_R160_RECONCILIACAO_154_MESTRE_ONLY.csv'
    with csv_path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(corrected[0]));writer.writeheader();writer.writerows(corrected)
    report = {'classification':'VERIFIED_NATIVE_READONLY_SELECTED_R160_NOT_OFFICIAL_CAMPAIGN',
              'source_file': src.name,'source_sha256':original_sha,'zip_member_count':len(entries)+2,
              'manifest_member_hashes_verified':len(entries),'selected_banks':len(filename_set),
              'verified_commits':event_count,'native_offense_receipts_reconciled':len(corrected),
              'original_totals':{k:totals[k] for k in ['net_post_RD','hp_effectively_lost','overkill']},
              'reconciled_totals':{'damage_post_rd':totals['net_post_RD'],'hp_actual_delta':totals['hp_effectively_lost_reconciled'], 'overkill':totals['overkill_reconciled']},
              'original_overstatement':totals['original_effective_overstatement'], 'mismatches':mismatches,
              'bank_reconciliation':per_bank, 'scope_limitations':['Only 9 selected R160 banks, not total VLAB corpus',
              'Engine tests and future hypothetical scenarios are not certified',
              'Production/Party writes and full external blind review not authorized',
              'Original R160 files and receipts untouched']}
    report['csv_sha256'] = sha256(csv_path.read_bytes())
    (out/'VLAB_R160_AUDIT_COORD_MESTRE_ONLY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    markdown = f'''# PSV — VLAB R160 / Reconciliação independente de dano (MESTRE-ONLY)\n\n**Fonte:** `{src.name}`\n\n**SHA-256 da fonte:** `{original_sha}`\n\n**Escopo VERIFICADO:** {len(filename_set)} bancos selecionados, {event_count} commits (cadeia SHA, integridade SQLite, pending=0), {len(corrected)} recibos ofensivos vinculados individualmente aos eventos nativos.\n\n| Campo | R160 rotulado | Reconciliado dos estados |\n|---|---:|---:|\n| Dano pós-RD | {totals['net_post_RD']} | {totals['net_post_RD']} |\n| Vida efetivamente retirada | {totals['hp_effectively_lost']} | **{totals['hp_effectively_lost_reconciled']}** |\n| Overkill | {totals['overkill']} | **{totals['overkill_reconciled']}** |\n\nForam encontrados **{len(mismatches)}** recibos que rotulavam dano maior que `hp_before - hp_after`, diferença total **{totals['original_effective_overstatement']}**.\n\nEm todos os {len(corrected)} casos o mapeamento ator/alvo, bruto, RD, pós-RD e HP foi reconciliado, usando `before_hp/after_hp` para ataques físicos e `hp_before/hp_after` para magias. O relatório derivado não corrige o registro original, não prova status oficial nem altera fichas ou personagens.\n\n**Reprodução:** `python reconcile_vlab_r160_master_only.py --zip <ZIP_R160_ORIGINAL> --out <PASTA_DE_DESTINO>`. Depende apenas da biblioteca padrão Python.\n'''
    (out/'VLAB_R160_AUDIT_COORD_MESTRE_ONLY.md').write_text(markdown,encoding='utf8')
    print(json.dumps({'source_sha':original_sha,'manifest_ok':len(entries),'banks':len(filename_set),'commits':event_count,'receipts':len(corrected),'totals':report['reconciled_totals'],'overstatement':totals['original_effective_overstatement'],'mismatches':len(mismatches),'csv_path':str(csv_path)},ensure_ascii=False))
    return report

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--zip', type=Path, required=True)
    p.add_argument('--out', type=Path, default=Path('.'))
    args=p.parse_args()
    run(args.zip, args.out)
