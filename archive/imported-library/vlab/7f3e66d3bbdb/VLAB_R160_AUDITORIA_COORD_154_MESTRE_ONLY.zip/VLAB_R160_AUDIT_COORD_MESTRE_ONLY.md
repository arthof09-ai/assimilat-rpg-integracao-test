# PSV — VLAB R160 / Reconciliação independente de dano (MESTRE-ONLY)

**Fonte:** `VLAB_R151_R160_TACTICAL_R42_R43_CASULO_ED_BE_VERIFIED_MESTRE_ONLY.zip`

**SHA-256 da fonte:** `7b208fe553809df6a999a1e4f9a70d7ad116033e929256bc71dbcd61843f3410`

**Escopo VERIFICADO:** 9 bancos selecionados, 466 commits (cadeia SHA, integridade SQLite, pending=0), 154 recibos ofensivos vinculados individualmente aos eventos nativos.

| Campo | R160 rotulado | Reconciliado dos estados |
|---|---:|---:|
| Dano pós-RD | 11870 | 11870 |
| Vida efetivamente retirada | 11845 | **11808** |
| Overkill | 25 | **62** |

Foram encontrados **3** recibos que rotulavam dano maior que `hp_before - hp_after`, diferença total **37**.

Em todos os 154 casos o mapeamento ator/alvo, bruto, RD, pós-RD e HP foi reconciliado, usando `before_hp/after_hp` para ataques físicos e `hp_before/hp_after` para magias. O relatório derivado não corrige o registro original, não prova status oficial nem altera fichas ou personagens.

**Reprodução:** `python reconcile_vlab_r160_master_only.py --zip <ZIP_R160_ORIGINAL> --out <PASTA_DE_DESTINO>`. Depende apenas da biblioteca padrão Python.
