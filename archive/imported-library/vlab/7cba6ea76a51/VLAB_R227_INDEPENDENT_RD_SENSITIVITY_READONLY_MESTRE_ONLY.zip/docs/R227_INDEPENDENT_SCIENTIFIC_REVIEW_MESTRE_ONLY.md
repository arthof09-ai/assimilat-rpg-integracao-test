# R227 — Auditoria independente READ-ONLY de sensibilidade à RD mágica

**As-of:** 21/10/2026. **Operação:** OP-VLAB-FUSION-SANDBOX-01. **Identidade:** CM-000006 lógica / MESTRE-SIDE. **Sem writer de produção.** Este é um **suplemento científico independente** sobre os bancos R227, não um segundo checkpoint R227 nem duplicação de outro PSV.

## Unidade experimental e comparação

- Item: Manopla do Trovão Cativo (Ouro, **PS/semicanônico**); fonte Mestre-side https://app.notion.com/p/3f5c2b324ede81f5ac62fb940204cdac.
- Variação: mesma peça fisicamente equipada, golpe físico e RNG de Raio compartilhados por seed; duas **hipóteses TEST de RD mágica** (0 e 100), nenhuma delas promovida a propriedade oficial de Varok.
- Controle: descarregar apenas após acerto, declarar antes do RNG do dano, custa 22 PA mesmo quando a RD anula completamente Raio, sem Ação Padrão extra; −3m de velocidade apenas se houve pelo menos 1 dano elétrico efetivo; expiração no fim do próprio turno seguinte do alvo.
- **Atores:** réplicas de Arveth e Varok como NPCs propostos. Hipótese de velocidade de 4m somente na fixture; não comprova velocidade canônica, conversão de bloco ou movimentação efetiva.

## Dados auditados

6 seeds pareadas; 12 braços executados; 24 commits e 132 eventos; 4/6 acertos; 2/6 erros sem disparo mágico; 100 PV de diferença agregada entre RD0 e RD100, exclusivamente nos quatro golpes acertados; 176 PA gastos nos dois braços em conjunto; 4 lentidões com RD0 e nenhuma com RD100. Todos os braços encerram em censura após janela de efeito, sem combate completo.

O auditor `code/r227_sql_readonly_rd_sensitivity.py` utiliza apenas JSON, hashlib e SQLite em modo read-only/immutable, reconstitui SHA de cada recibo R18, verifica eventos, fonte, ordem causal, custo, RD físico, RD mágico, Vida, velocidade, expiração e paridade das fitas por seed. Quatro clones deliberadamente adulterados com hashes reconstruídos são rejeitados por gates semânticos.

**Resultado:** `PASS_R227_INDEPENDENT_SQL_TEST_RD_SENSITIVITY`, com **PASS TEST condicional**, sem admissão científica de RD100 como atributo real, sem canonização do item e sem homologação da Bateria E (0/1.875 e 0/17 inalterados). **Nenhum banco histórico foi reexecutado.**

**Ressalvas:** O ramo de duas origens de dano depende de aplicar RD física apenas ao pool físico e RD mágica apenas ao pool elétrico. Item semicanônico não equivale a equipamento P4. A R227 não demonstra turnos de adversário ofensivos, mas apenas a janela de efeito.

**Continuar:** obter fonte de RD mágica efetiva de uma criatura/armadura adequada; executar movimento realmente limitado por −3m com velocidade canônica fonte-completa; aproximar Bateria E de um item P4; investigar controle de Besta e transformação; resolver iniciativa empatada/bloco↔métrica com decisões competentes. Sem duplicar a comunicação IBX-126 ou declarar ACK do DMG.
