import json,hashlib,zipfile,tempfile,subprocess,sys,importlib.util
from pathlib import Path

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(root):
 root=Path(root);m=json.loads((root/'SHA256_MANIFEST.json').read_text())
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256_MANIFEST.json'}
 if set(m)!=actual:raise AssertionError('MANIFEST_SET')
 for path,h in m.items():
  if digest(root/path)!=h:raise AssertionError('FILE_HASH:'+path)
 program=root/'code/r227_sql_readonly_rd_sensitivity.py'
 code=program.read_text()
 if 'vlab_effects_v08' in code or 'event_commit(' in code:raise AssertionError('SIMULATOR_LEAK')
 p=subprocess.run([sys.executable,str(program)],capture_output=True,text=True,cwd=root,timeout=60)
 if p.returncode:raise AssertionError(p.stderr)
 res=json.loads(p.stdout)
 if res['cases']!=12 or res['paired_seeds']!=6 or res['slow_RD0']!=4 or res['slow_RD100']!=0:raise AssertionError('SCIENCE_METRIC_DRIFT')
 spec=importlib.util.spec_from_file_location('cold_r227_sql',program);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
 pr=(root/'sources/R227_PREREG_BEFORE_EXEC.json').read_bytes();it=(root/'sources/R226_MANOPLA_PRIMARY_MECHANICAL_EXCERPT.json').read_bytes()
 ph=hashlib.sha256(pr).hexdigest();ih=hashlib.sha256(it).hexdigest()
 rejects=[]
 for name in ['PA_REFUNDED','MAGICAL_DAMAGE_FORGED','SLOW_ESCAPED_SOURCE','CANON_UNAUTHORIZED']:
  target=root/'evidence/adversarial'/f'R227_ADVERSARIAL_{name}.sqlite'
  try:a.read(22762002,'LIGHTNING_RD100',ph,ih,override_path=target)
  except AssertionError as e:rejects.append({'name':name,'reason':str(e)})
  else:raise AssertionError('TAMPER_ACCEPTED:'+name)
 return {'status':'PASS_R227_COLD_SCIENTIFIC_READONLY','manifest_hashes':len(m),'cases':12,'paired_seeds':6,'hits':4,'RD0_vs_RD100_extra_HP':100,'PA_spent_both':176,'adversarial_rejected':rejects,'historical_replays':0}
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--archive',required=True);x=p.parse_args()
 with tempfile.TemporaryDirectory(prefix='R227_REVIEW_COLD_') as d:
  with zipfile.ZipFile(x.archive) as z:
   if z.testzip() is not None:raise AssertionError('CRC')
   z.extractall(d)
  print(json.dumps(verify(d),ensure_ascii=False,indent=2))
