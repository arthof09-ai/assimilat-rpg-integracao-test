"""Independent R227 SQLite audit; intentionally no game engine imports/writes."""
import json,hashlib,sqlite3
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def sha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def req(cond,msg):
 if not cond:raise AssertionError(msg)
def read(seed,arm,presh,itemh,override_path=None):
 path=override_path or R/'evidence/db'/f'R227_MANOPLA_{arm}_S{seed}.sqlite'
 con=sqlite3.connect('file:'+str(path)+'?mode=ro&immutable=1',uri=True)
 try:
  meta=dict(con.execute('select key,value from meta'));st=json.loads(meta['state'])
  rows=[json.loads(x[0]) for x in con.execute('select row_json from events order by seq')]
  receipts=list(con.execute('select seq,cmd_id,prev,row_sha,before_sha,after_sha from events order by seq'))
  pending=con.execute('select count(*) from pending').fetchone()[0]
 finally:con.close()
 req(len(rows)==2 and int(meta['revision'])==2 and not pending,'R18_REV_PENDING')
 prev=meta['genesis']
 for i,(r,rec) in enumerate(zip(rows,receipts),1):
  req(r['seq']==i and rec==(i,r['cmd_id'],r['prev'],sha(r),r['before_sha'],r['after_sha']),'ROW_HASH')
  req(r['prev']==prev and r['official_effects']==0,'CHAIN_PRODUCTION');prev=sha(r)
 req(meta['head']==prev and sha(st)==rows[-1]['after_sha'],'STATE_HEAD_HASH')
 req(st['seed']==seed and st['r227']['arm']==arm and st['r227']['pre_sha256']==presh and st['r227']['item_excerpt_sha256']==itemh,'PREREG_SOURCE')
 req(st['r227']['world_canon'] is False and st['phase']=='CENSORED_SOURCE_EFFECT_WINDOW','TEST_ONLY_AND_CENSOR')
 es=st['native_events'];req(es==rows[0]['detail']['events_added']+rows[1]['detail']['events_added'],'R18_EVENTS')
 for i,e in enumerate(es,1):req(e['seq']==i,'EVENT_SEQUENCE')
 by={}
 for e in es:by.setdefault(e['action'],[]).append(e)
 h=by['R227_ATTACK_HIT_AND_CRITICAL_RNG'][0];a=by['weapon_attack'][0];d=by['R227_DAMAGE_RNG_AFTER_DECLARATION'][0]
 req(a['attack_roll_attempts'][0]==h['rolls'] and len(h['rolls'])==4 and all(1<=v<=6 for v in h['rolls']),'4D6')
 req(h['roll_score']==sum(h['rolls'])+72 and a['roll_score']==h['roll_score'],'HIT_SCORE')
 critical=h['critical'];positive=h['crit_rolls'][:2]==[6,6] and h['crit_rolls'][2]>=5;negative=h['crit_rolls'][:2]==[1,1] and h['crit_rolls'][2]<=2
 req(critical==('POSITIVE' if positive else 'NEGATIVE' if negative else 'NONE'),'CRITICAL')
 hit=(h['roll_score']>83 or positive) and not negative
 req(h['hit']==hit==a['hit'],'HIT_CA83')
 ph=sum(d['physical_rolls'])+35+(80 if positive and hit else 0)
 loss=max(0,ph-35) if hit else 0
 req(a['raw']==(ph if hit else 0) and a['hp_loss_actual']==loss and a['after_hp']==734-loss,'PHYSICAL_HP_RD35')
 req(len(d['physical_rolls'])==8 and all(1<=v<=10 for v in d['physical_rolls']),'8D10')
 it=by.get('R227_ITEM_LIGHTNING_AND_CONDITION',[]);cl=by.get('R227_ITEM_DECLARATION_BEFORE_DAMAGE_RNG',[])
 cost=22 if hit else 0
 if hit:
  req(len(it)==len(cl)==1,'ITEM_AFTER_HIT')
  light=it[0];de=cl[0]
  req(h['seq']<de['seq']<d['seq']<a['seq']<light['seq'],'PA_DECLARATION_BEFORE_DAMAGE')
  req(de['pa_spent']==22 and de['once_per_8h'] and de['item_equipped'] and de['no_extra_standard'],'PA_ONCE')
  req(len(d['lightning_rolls'])==5 and all(1<=v<=8 for v in d['lightning_rolls']),'LIGHTNING_5D8')
  raw=sum(d['lightning_rolls'])+3+(40 if positive else 0);rd=(0 if arm=='LIGHTNING_RD0' else 100)
  effective=max(0,raw-rd)
  req(light['magic_raw']==raw and light['magic_effective']==effective and light['magic_rd']==rd,'MAGIC_RD')
  req(light['hp_before']==734-loss and light['hp_after']==734-loss-effective,'MAGIC_HP')
  req(light['slow_applied']==(effective>0) and light['slow_m']==(3 if effective>0 else 0),'SLOW_ONLY_IF_MAGIC_EFFECTIVE')
  req(d['magic_active'] and de['page_id']=='3f5c2b324ede81f5ac62fb940204cdac','SOURCE_ITEM')
 else:
  req(not it and not cl and d['lightning_rolls']==[] and not d['magic_active'],'NO_MAGIC_AFTER_MISS')
  effective=0
 req(st['actors']['R']['pa']==344-cost and st['actors']['V']['hp']==734-loss-effective,'RESOURCE_FINAL')
 speed=by['R227_SLOWED_TARGET_TURN_OBSERVATION'][0]
 req(speed['available_speed_in_declared_4m_lab_fixture']==('1' if effective else '4'),'SPEED_TEST_HYPOTHESIS')
 req(speed['source_speed_4m_is_TEST_assumption'] and speed['no_metric_world_block_mapping'],'ANTI_CANON_GEO')
 req(len(by.get('R227_SOURCE_ITEM_SLOW_EXPIRES',[]))==(1 if effective else 0),'EXPIRATION')
 req(st['actors']['V']['timed_source_speed_penalty_m']==0,'EXPIRED_AT_END_OF_TURN')
 return {'seed':seed,'arm':arm,'hit':hit,'physical_damage_effective':loss,'lightning_damage_effective':effective,'item_cost':cost,'speed_during':speed['available_speed_in_declared_4m_lab_fixture'],'commits':2,'events':len(es)}
def run():
 pb=(R/'sources/R227_PREREG_BEFORE_EXEC.json').read_bytes();pr=json.loads(pb);presh=hashlib.sha256(pb).hexdigest();it=(R/'sources/R226_MANOPLA_PRIMARY_MECHANICAL_EXCERPT.json').read_bytes();ih=hashlib.sha256(it).hexdigest()
 req(pr['candidate']=='R227' and len(pr['seeds'])==6 and len(pr['arms'])==2,'REGISTERED_DESIGN')
 out=[read(seed,arm,presh,ih) for seed in pr['seeds'] for arm in pr['arms']]
 pairs=[]
 for seed in pr['seeds']:
  low=next(x for x in out if x['seed']==seed and x['arm']=='LIGHTNING_RD0');high=next(x for x in out if x['seed']==seed and x['arm']=='LIGHTNING_RD100')
  req(low['hit']==high['hit'] and low['physical_damage_effective']==high['physical_damage_effective'],'PAIR_SHARED_PHYSICAL')
  req(low['item_cost']==high['item_cost'],'RD_MUST_NOT_REFUND_PA')
  req(high['lightning_damage_effective']==0,'RD100_MUST_BLOCK_5D8+3')
  pairs.append({'seed':seed,'hit':low['hit'],'magic_effective_difference':low['lightning_damage_effective']-high['lightning_damage_effective'],'PA_both':low['item_cost'],'slow_RD0':low['speed_during']=='1','slow_RD100':high['speed_during']=='1'})
 req(len(list((R/'evidence/db').glob('*.sqlite')))==12,'HIDDEN_RUNS')
 return {'status':'PASS_R227_INDEPENDENT_SQL_TEST_RD_SENSITIVITY','cases':len(out),'paired_seeds':len(pairs),'hits':sum(p['hit'] for p in pairs),'damage_difference':sum(p['magic_effective_difference'] for p in pairs),'total_PA_both':2*sum(p['PA_both'] for p in pairs),'slow_RD0':sum(p['slow_RD0'] for p in pairs),'slow_RD100':sum(p['slow_RD100'] for p in pairs),'commits':sum(x['commits'] for x in out),'events':sum(x['events'] for x in out),'no_historical_replays':True,'pairs':pairs}
if __name__=='__main__':print(json.dumps(run(),indent=2,ensure_ascii=False))
