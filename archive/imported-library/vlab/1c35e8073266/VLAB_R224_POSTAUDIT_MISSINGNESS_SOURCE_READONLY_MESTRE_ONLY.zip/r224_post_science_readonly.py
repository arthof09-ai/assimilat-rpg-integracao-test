"""Read-only scientific classification of independent R223 and R224 results. No battle execution."""
from pathlib import Path
import hashlib,json,math
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'

def cdf_binomial(k,n,p):
 return sum(math.comb(n,i)*(p**i)*((1-p)**(n-i)) for i in range(k+1))
def cp(k,n,alpha=0.05):
 def lower():
  if k==0:return 0.
  lo,hi=0.,1.
  for _ in range(100):
   m=(lo+hi)/2
   # P(X>=k)=alpha/2: increasing in p
   s=1-cdf_binomial(k-1,n,m)
   if s<alpha/2:lo=m
   else:hi=m
  return (lo+hi)/2
 def upper():
  if k==n:return 1.
  lo,hi=0.,1.
  for _ in range(100):
   m=(lo+hi)/2
   # P(X<=k)=alpha/2: decreasing in p
   s=cdf_binomial(k,n,m)
   if s>alpha/2:lo=m
   else:hi=m
  return (lo+hi)/2
 return lower(),upper()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 p223=json.loads((DATA/'R223_INDEPENDENT_FACTORIAL_AUDIT.json').read_text())
 p224=json.loads((DATA/'R224_INDEPENDENT_PAIR_AUDIT.json').read_text())
 m=p224['metrics']
 assert p223['status']=='PASS_R223_READONLY_MASTER_TENTATIVE_FLOOR_FACTORIAL'
 assert p223['valid']==40 and p223['odd_half_floor_spells']==4 and p223['full_factorial_seed_units']==8
 assert p224['status']=='PASS_R224_INDEPENDENT_SQLITE_STRICT_VS_FLOOR_SOURCE_CENSURE'
 assert m['paired_seed_units']==20 and m['strict_unknown_intents']==2 and m['floor_censures']==20 and m['strict_censures']==18
 cp95=cp(2,20)
 assert abs(cp95[0]-.012348527170294808)<1e-10 and abs(cp95[1]-.31698271401908235)<1e-10
 assert len(p224['interrupted_pairs'])==2 and {x['seed'] for x in p224['interrupted_pairs']}=={22453002,22453022}
 return {'status':'PASS_R224_POSTSCIENCE_READONLY_NO_REPLAYS','r223_source_gate':'TEST_ONLY','r223_unique_new_tests':40,'r223_odd_half_events':4,'r224_seed_pairs':20,
  'r224_missing_strict_endpoints':2,'strict_incomplete_fraction':0.1,'strict_incomplete_95pct_exact_CP':list(cp95),
  'scientific_unit':'one paired seed; only 20 pairs analyzed','scope':'Fixture of proposed ON5 NPCs, not general RPG probability',
  'causal_interpretation':'Same event prefixes until first odd half, completed floor arm; no legitimate strict outcome on blocked arm',
  'historical_replays':0,'official_world_rounding':'PENDING_MASTER_RULING'}
if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
