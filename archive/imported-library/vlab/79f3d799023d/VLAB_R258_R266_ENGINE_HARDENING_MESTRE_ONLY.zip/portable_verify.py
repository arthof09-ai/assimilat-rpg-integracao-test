"""Portable bytewise verification of this incremental package, not execution of original R18."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
if __name__=='__main__':
 m=json.loads((R/'SHA256_MANIFEST.json').read_text())
 paths={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256_MANIFEST.json'}
 assert paths==set(m['files']),(sorted(set(m['files'])-paths),sorted(paths-set(m['files'])))
 for rel,expected in m['files'].items():
  assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==expected,rel
 state=json.loads((R/'reports/R266_CHECKPOINT.json').read_text())
 assert state['cold_original_unittest']['passed']==8 and state['cold_new_unittest']['passed']==54
 assert state['terminal_nac_pass']=='HOLD' and state['party_writes']==0 and state['notion_writes']==0
 print(json.dumps({'result':'PASS_PORTABLE_BYTES_ONLY','files':len(paths),'r18_tests_not_executed_by_this_script':True,'terminal_nac_pass':'HOLD'},indent=2))
