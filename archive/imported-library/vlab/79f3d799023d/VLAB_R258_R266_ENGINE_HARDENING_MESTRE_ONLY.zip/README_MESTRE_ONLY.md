# PSV — OP-VLAB-FUSION-SANDBOX-01 | R258–R266 | MESTRE-SIDE / TEST

**Status:** TEST nativo, patches incrementais sobre o **mesmo** R18 histórico. Não existe novo motor nem autorização de produção. **ANTES:** R257 tecnicamente verificado. **DEPOIS:** R266 passou auditoria de cópia limpa; 0/17 contratos terminais, 0/1.875 células oficiais. Party/O Primeiro, fichas vivas, DMG, Notion OP/Diário/Inbox: **0 writes** nesta rodada.

## Origem física e reprodução

- Arquivo histórico inteiro em Library Mestre: `VLAB_STAGE12_A1A2A3_INTERACTIVE_R18_SANDBOX.zip`, 14.691.125 bytes, SHA256 `e079da7aa5c16364a18515de3f4941583e394dc345493adabb9d2db06faceefc`. O histórico não é redistribuído neste ZIP incremental.
- Código original R18 `fusion_stage12/vlab_r18_interactive.py` SHA256 `f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368`. Também presente com hash idêntico no R237, cuja distribuição científica é parcial. Aplicação ao R237 **apenas dry-run**; não alegar regressão completa nesse pacote.
- Em cópia extraída limpa do ZIP R18, aplicar UMA VEZ o patch `patch/R266_CUMULATIVE_FROM_R18.patch` com `patch -p1`. O arquivo final terá SHA256 `3daefc05ffccb94d8fa5bec05727c7412cb09d53ff88749b6b5b1e839044dbcf`.
- Executar dentro da cópia, na raiz do R18: `PYTHONPATH=fusion_stage12:working/historical_v081_verified_original:reconstruction python -m unittest fusion_stage12/test_vlab_r18_interactive.py -q` e `VLAB_R18_ROOT="$PWD" PYTHONPATH=fusion_stage12 python -m unittest discover -s /caminho/deste_pacote/tests -p 'test_r*.py' -q`.
- O `portable_verify.py` do pacote verifica apenas integridade dos artefatos, NÃO reexecuta o R18 sem o ZIP original.

## Sequência executada (sem repetição)

| Unidade | Verificação ou correção | Resultado delimitado |
|---|---|---|
| R258 | `play --scene/--seed` para partida nova ou recuperada; incompatibilidade falha fechada | 8 testes novos PASS; 8 herdados PASS |
| R259 | Rejeição de opções silenciosamente ignoradas (`--reaction` fora B, `--crash-after` sem demo, `--output` fora export, etc.) | 13 testes novos PASS |
| R260 | Nova luta após reabrir arquivo usava semente `None`; corrigido para manter seed declarada ou persistida | Falha original reproduzida; 5 testes novos PASS |
| R261 | Interrupção REAL entre commit e retorno, e após intenção durável antes do efeito | 3 sementes recuperaram sem dupla execução; 2 intenções pendentes bloquearam replay; 2 métodos de teste PASS |
| R262 | TOCTOU em `export`: `os.replace` sobrescrevia arquivo produzido em corrida; publicação agora com hard-link exclusivo em mesmo diretório, sem sobrescrever e sem apagar temp estrangeiro | Falha original reproduzida; 6 testes novos PASS |
| R263 | Adulterações em SQLite journal/metadados/pending após extração | 14 casos rejeitados em 1 método de teste PASS |
| R264 | JSON parseável porém sem campos provocava `KeyError`/`TypeError`; bloqueio controlado de forma e estado | Falha evidenciada; 4 métodos de teste PASS |
| R265 | Adulteração de Vida/PA/estado na gênese com 0 eventos anteriormente aceita; verifica gênese e snapshot inicial esperado | Falha original reproduzida; 9 testes novos PASS |
| R266 | Reserva local exclusiva de arquivo `os.open(O_EXCL)` para inicialização SQLite, impedindo duas criações concorrentes do mesmo path | 24 competidores: 1 sucesso, 23 bloqueios; 6 testes novos PASS |

**Cold audit desta rodada:** 8/8 testes nativos históricos mais **54/54 testes novos** passaram sobre cópia recém-extraída do original, com o patch cumulativo aplicado UMA vez. Totais são testes `unittest`, não 62 contratos ou 62 combates. Os testes de R261 incluem cinco subcasos de falha real, com `os._exit` em processos filhos; nenhum dado oficial é afetado.

## Inbox / normas / gates

A Inbox Notion foi reconsultada como leitura: **17 itens destinados a CM-000006**, incluindo urgentes IBX-40, 62, 70 e 86; **14 exigem ACK e permanecem registrados NOVA**. Sem `CM-000006-I0001` legitimamente consumida e sem writer/fencing, **não marcar leitura/ACK/CONCLUÍDA** e não editar OP/Diário compartilhados. O comando funcional IBX-62 exige um único executor, e estes patches trabalham em seu módulo original sem bifurcação. Uso do GitHub é opcional (IBX-152/160); **GitHub CI NOT-RUN** nesta rodada.

Para ciência: R18 original e novos deltas ainda são **sandbox fictício**, sem fontes P4 admissíveis para duelos oficiais, e o estado inicial verificado por hash local não equivale a assinatura externa/autenticidade contra invasor capaz de recalcular toda a cadeia. O patch usa `os.link` no mesmo diretório para publicação sem substituição; se sistema de arquivos não oferecer suporte, a exportação recusa em vez de sobrescrever.

**NAC-PASS-02 proporcional:** integridade, regressões e novos contratos de controle de falha **PASS local**. Certificação terminal VLAB, regime STRICT, regra de desempate, crítico negativo, Jaku×Dragão, RD canônica, writer/epoch/lease/green e promoção: **HOLD**.

## Próximo checkpoint exato

`LAST VERIFIED = R266`; `FIRST PENDING = R267`, candidato para integração em módulo unificado mais recente após colisão/diff e para ensaio independente de publicação/recuperação no contrato IBX-62. Não fazer merge em engine oficial nem trocar o R18 histórico. Abrir esta README, os relatórios de regressão, verificar o ZIP original SHA e aplicar o patch em uma cópia limpa; não reaplicar R255/R256 isolados por cima. Outras pendências: fonte P4 para bestas, críticos negativos, desempate iniciativa, política HP0, 17 contratos e grade 1.875; Inbox 14 ACK aguardam instância legitimada.
