import importlib, tempfile, unittest, io
from pathlib import Path
from unittest.mock import patch
from contextlib import redirect_stdout,redirect_stderr
mod=importlib.import_module('vlab_r18_interactive')
class TestNewMatchSeed(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)/'case.sqlite'
 def play(self,inputs,extra=()):
  with patch('builtins.input',side_effect=inputs),redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()):
   return mod.main(['play','--save',str(self.p),*extra])
 def test_custom_seed_inherited_after_completed(self):
  mod.demo(self.p,'B',False,seed=26001)
  h=mod.load(self.p)[1]
  self.assertEqual(self.play(['3','a','0']),0)
  new=self.p.with_name('case_novo_002.sqlite')
  self.assertEqual((mod.load(new)[0]['seed'],mod.load(new)[0]['scene']),(26001,'A'))
  self.assertEqual(mod.load(self.p)[1],h)
 def test_default_seed_inherited_after_completed(self):
  mod.demo(self.p,'A',False)
  self.assertEqual(self.play(['3','b','0']),0)
  self.assertEqual(mod.load(self.p.with_name('case_novo_002.sqlite'))[0]['seed'],20261014)
 def test_custom_seed_inherited_mid_fight(self):
  mod.init_db(self.p,'A',26002)
  self.assertEqual(self.play(['1','6','b','0']),0)
  new=self.p.with_name('case_novo_002.sqlite')
  self.assertEqual(mod.load(new)[0]['seed'],26002)
  self.assertEqual(mod.load(self.p)[2],1)
 def test_explicit_seed_persists_for_new_match(self):
  mod.init_db(self.p,'A',26003)
  self.assertEqual(self.play(['1','6','b','0'],extra=('--seed','26003')),0)
  self.assertEqual(mod.load(self.p.with_name('case_novo_002.sqlite'))[0]['seed'],26003)
 def test_multiple_new_matches_use_seed_of_active_saved_match(self):
  mod.demo(self.p,'A',False,seed=26004)
  self.assertEqual(self.play(['3','b','0']),0)
  fresh=self.p.with_name('case_novo_002.sqlite')
  with patch('builtins.input',side_effect=['1','6','a','0']),redirect_stdout(io.StringIO()):
   self.assertIsNone(mod.play(fresh))
  self.assertEqual(mod.load(self.p.with_name('case_novo_002_novo_002.sqlite'))[0]['seed'],26004)
if __name__=='__main__':unittest.main()
