"""Isolated tests for R258 play CLI source-bound scenario/seed contracts."""
import importlib, io, tempfile, unittest
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path
from unittest.mock import patch

cli=importlib.import_module('vlab_r18_interactive')

class TestPlayCLI(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='vlab-r258-')
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/'trial.sqlite'

    def invoke(self,*args,inputs=('0',)):
        out=io.StringIO();err=io.StringIO()
        with patch('builtins.input',side_effect=list(inputs)),redirect_stdout(out),redirect_stderr(err):
            rv=cli.main(['play','--save',str(self.db),*args])
        return rv,out.getvalue(),err.getvalue()

    def test_explicit_scene_seed_in_new_play(self):
        rv,_,_=self.invoke('--scene','B','--seed','251001')
        self.assertEqual(rv,0)
        state,_,rev=cli.load(self.db)
        self.assertEqual((state['scene'],state['seed'],rev),('B',251001,0))

    def test_new_no_scene_prompts_and_seed_preserved(self):
        rv,_,_=self.invoke('--seed','251002',inputs=('a','0'))
        self.assertEqual(rv,0)
        self.assertEqual(cli.load(self.db)[0]['scene'],'A')
        self.assertEqual(cli.load(self.db)[0]['seed'],251002)

    def test_new_defaults_preserved(self):
        rv,_,_=self.invoke('--scene','A')
        self.assertEqual(rv,0)
        self.assertEqual(cli.load(self.db)[0]['seed'],20261014)

    def test_resume_unspecified_accepts_original_nondefault_seed(self):
        cli.init_db(self.db,'B',251003)
        rv,_,_=self.invoke()
        self.assertEqual(rv,0)
        self.assertEqual(cli.load(self.db)[0]['seed'],251003)

    def test_scene_mismatch_holds_without_new_events(self):
        cli.init_db(self.db,'A',251004)
        head=cli.load(self.db)[1]
        rv,_,err=self.invoke('--scene','B')
        self.assertEqual(rv,2)
        self.assertIn('EXISTING_SCENE_TYPE_MISMATCH',err)
        self.assertEqual(cli.load(self.db)[1],head)

    def test_seed_mismatch_holds_without_new_events(self):
        cli.init_db(self.db,'B',251005)
        head=cli.load(self.db)[1]
        rv,_,err=self.invoke('--seed','251006')
        self.assertEqual(rv,2)
        self.assertIn('EXISTING_SCENE_SEED_MISMATCH',err)
        self.assertEqual(cli.load(self.db)[1],head)

    def test_matching_both_resume(self):
        cli.init_db(self.db,'A',251007)
        rv,_,_=self.invoke('--scene','A','--seed','251007')
        self.assertEqual(rv,0)
        self.assertEqual(cli.load(self.db)[2],0)

    def test_invalid_scene_rejected_before_open(self):
        with self.assertRaises(SystemExit):
            self.invoke('--scene','C')
        self.assertFalse(self.db.exists())

if __name__=='__main__':unittest.main()
