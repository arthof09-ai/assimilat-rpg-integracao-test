"""R266: initial SQLite save path must be claimed exclusively (single host LAB, not Notion fencing)."""
import importlib,os,tempfile,unittest,concurrent.futures
from pathlib import Path
from unittest.mock import patch
cli=importlib.import_module('vlab_r18_interactive')
class TestExclusiveNewSave(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='vlab-r266-');self.addCleanup(self.tmp.cleanup)
  self.p=Path(self.tmp.name)/'deep'/'case.sqlite'
 def test_nested_directory_created_exclusively(self):
  cli.init_db(self.p,'A',26601)
  self.assertEqual(cli.load(self.p)[0]['seed'],26601)
  with self.assertRaisesRegex(cli.LabHold,'ARQUIVO JÁ EXISTE'):cli.init_db(self.p,'B',26602)
  self.assertEqual(cli.load(self.p)[0]['scene'],'A')
 def test_24_concurrent_attempts_one_winner_only(self):
  def attempt(j):
   try:cli.init_db(self.p,'A',26600+j);return ('won',j)
   except cli.LabHold:return ('blocked',j)
  with concurrent.futures.ThreadPoolExecutor(max_workers=24) as pool:r=list(pool.map(attempt,range(24)))
  wins=[z for z in r if z[0]=='won'];self.assertEqual(len(wins),1,r)
  self.assertEqual(cli.load(self.p)[2],0)
  self.assertEqual(cli.load(self.p)[0]['seed'],26600+wins[0][1])
 def test_file_created_between_precheck_and_claim_is_not_overwritten(self):
  self.p.parent.mkdir(parents=True,exist_ok=True)
  real=cli.os.open
  def race(path,flags,mode=0o777):
   Path(path).write_text('other creator')
   return real(path,flags,mode)
  with patch.object(cli.os,'open',side_effect=race):
   with self.assertRaisesRegex(cli.LabHold,'ARQUIVO JÁ EXISTE'):cli.init_db(self.p,'A',26603)
  self.assertEqual(self.p.read_text(),'other creator')
 def test_dangling_symlink_is_not_replaced(self):
  self.p.parent.mkdir(parents=True,exist_ok=True)
  self.p.symlink_to('nonexistent-target.sqlite')
  with self.assertRaisesRegex(cli.LabHold,'ARQUIVO JÁ EXISTE'):cli.init_db(self.p,'A',26604)
  self.assertTrue(self.p.is_symlink())
 def test_create_denied_is_controlled_hold(self):
  with patch.object(cli.os,'open',side_effect=PermissionError('deny')):
   with self.assertRaisesRegex(cli.LabHold,'CREATE_SAVE_EXCLUSIVE_FAILED'):cli.init_db(self.p,'A',26605)
  self.assertFalse(self.p.exists())
 def test_orphan_wal_prevents_new_save(self):
  self.p.parent.mkdir(parents=True,exist_ok=True)
  self.p.with_suffix('.sqlite-wal').write_text('orphan WAL')
  with self.assertRaises(cli.LabHold):cli.init_db(self.p,'A',26606)
  self.assertFalse(self.p.exists())
if __name__=='__main__':unittest.main()
