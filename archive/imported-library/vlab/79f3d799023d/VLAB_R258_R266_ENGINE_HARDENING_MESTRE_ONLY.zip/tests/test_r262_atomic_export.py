import importlib, io, tempfile, unittest, os
from pathlib import Path
from unittest.mock import patch
cli=importlib.import_module('vlab_r18_interactive')
class TestAtomicNoOverwrite(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.db=Path(self.tmp.name)/'fight.sqlite'
  cli.demo(self.db,'A',seed=26211)
  self.out=Path(self.tmp.name)/'receipt.json'
 def test_normal_export_produces_readable_receipt(self):
  receipt=cli.export(self.db,self.out)
  self.assertEqual(receipt['events'],cli.load(self.db)[2]);self.assertTrue(self.out.exists())
  self.assertEqual(receipt['hash'],__import__('hashlib').sha256(self.out.read_bytes()).hexdigest())
 def test_existing_receipt_never_overwritten(self):
  self.out.write_text('legitimate external output')
  with self.assertRaisesRegex(cli.LabHold,'NÃO SOBRESCREVER'):cli.export(self.db,self.out)
  self.assertEqual(self.out.read_text(),'legitimate external output')
 def test_concurrent_creation_prevents_overwrite(self):
  original=cli.os.link
  def race(src,dst):
   Path(dst).write_text('created by competing writer')
   return original(src,dst)
  with patch.object(cli.os,'link',side_effect=race):
   with self.assertRaisesRegex(cli.LabHold,'OCCUPIED_OR_CONCURRENT'):cli.export(self.db,self.out)
  self.assertEqual(self.out.read_text(),'created by competing writer')
  self.assertFalse(self.out.with_suffix(self.out.suffix+'.tmp').exists())
 def test_temp_collision_is_never_deleted_by_exporter(self):
  temp=self.out.with_suffix('.json.tmp');temp.write_text('foreign scratch file')
  with self.assertRaisesRegex(cli.LabHold,'OCCUPIED_OR_CONCURRENT'):cli.export(self.db,self.out)
  self.assertEqual(temp.read_text(),'foreign scratch file')
  self.assertFalse(self.out.exists())
 def test_failure_to_link_leaves_destination_absent(self):
  with patch.object(cli.os,'link',side_effect=PermissionError('blocked')):
   with self.assertRaisesRegex(cli.LabHold,'ATOMIC_PUBLISH_FAILED'):cli.export(self.db,self.out)
  self.assertFalse(self.out.exists());self.assertFalse(self.out.with_suffix('.json.tmp').exists())
 def test_reexport_same_filename_rejected(self):
  cli.export(self.db,self.out)
  original=self.out.read_bytes()
  with self.assertRaises(cli.LabHold):cli.export(self.db,self.out)
  self.assertEqual(self.out.read_bytes(),original)
if __name__=='__main__':unittest.main()
