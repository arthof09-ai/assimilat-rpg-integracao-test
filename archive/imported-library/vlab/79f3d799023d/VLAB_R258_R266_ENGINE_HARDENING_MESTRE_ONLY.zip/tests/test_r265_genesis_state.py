import importlib,tempfile,sqlite3,json,unittest
from pathlib import Path
from contextlib import closing
cli=importlib.import_module('vlab_r18_interactive')
class TestGenesisBound(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='vlab-r265-');self.addCleanup(self.tmp.cleanup)
  self.p=Path(self.tmp.name)/'new.sqlite';cli.init_db(self.p,'A',26500)
 def _state(self):
  with closing(sqlite3.connect(self.p)) as c:return json.loads(c.execute("SELECT value FROM meta WHERE key='state'").fetchone()[0])
 def _change(self,key,value):
  with closing(sqlite3.connect(self.p)) as c:c.execute('UPDATE meta SET value=? WHERE key=?',(value,key));c.commit()
 def test_valid_initial_accepted(self):
  self.assertEqual(cli.load(self.p)[2],0)
 def test_initial_hp_forgery_rejected(self):
  obj=self._state(); actor=next(iter(obj['actors']));obj['actors'][actor]['resource']['hp']=9999
  self._change('state',cli.canonical(obj))
  with self.assertRaisesRegex(cli.LabHold,'GENESIS_INITIAL_STATE_TAMPERED'):cli.load(self.p)
 def test_initial_pa_forgery_rejected(self):
  obj=self._state();actor=next(iter(obj['actors']));obj['actors'][actor]['resource']['pa']=8888
  self._change('state',cli.canonical(obj))
  with self.assertRaisesRegex(cli.LabHold,'GENESIS_INITIAL_STATE_TAMPERED'):cli.load(self.p)
 def test_initial_source_forgery_rejected(self):
  obj=self._state();obj['source_status']='STRICT_CERTIFIED'
  self._change('state',cli.canonical(obj))
  with self.assertRaises(cli.LabHold):cli.load(self.p)
 def test_altered_genesis_rejected(self):
  self._change('genesis','ATTACKER_GENESIS')
  with self.assertRaisesRegex(cli.LabHold,'GENESIS_HASH_MISMATCH'):cli.load(self.p)
 def test_modified_seed_without_genesis_rejected(self):
  obj=self._state();obj['seed']=26501
  self._change('state',cli.canonical(obj))
  with self.assertRaisesRegex(cli.LabHold,'GENESIS_HASH_MISMATCH'):cli.load(self.p)
 def test_change_scene_without_genesis_rejected(self):
  obj=self._state();obj['scene']='B'
  self._change('state',cli.canonical(obj))
  with self.assertRaisesRegex(cli.LabHold,'GENESIS_HASH_MISMATCH'):cli.load(self.p)
 def test_rev_one_valid(self):
  cli.event_commit(self.p,'LAB-CMD-START-R265','START',{},cli.do_start)
  self.assertEqual(cli.load(self.p)[2],1)
 def test_no_events_after_corrupt_first_snapshot(self):
  obj=self._state();obj['actors']['LAB_VIGIA_A']['resource']['hp']=999
  self._change('state',cli.canonical(obj))
  with self.assertRaises(cli.LabHold):cli.history(self.p)
if __name__=='__main__':unittest.main()
