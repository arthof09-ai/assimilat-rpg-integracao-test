"""R264 strict fail-closed validation of malformed / schema-incomplete SQLite snapshots and event rows."""
import importlib,tempfile,sqlite3,shutil,io,unittest
from contextlib import closing,redirect_stderr,redirect_stdout
from pathlib import Path
cli=importlib.import_module('vlab_r18_interactive')
class TestJsonShape(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.original=Path(self.tmp.name)/'baseline.sqlite'
  cli.demo(self.original,'B',seed=26416)
  with closing(sqlite3.connect(self.original)) as c:c.execute('PRAGMA wal_checkpoint(TRUNCATE)')
 def altered(self,sql):
  p=Path(self.tmp.name)/'malformed.sqlite'
  p.unlink(missing_ok=True);shutil.copyfile(self.original,p)
  with closing(sqlite3.connect(p)) as c:c.execute(sql);c.commit()
  return p
 def test_row_shape_errors_return_hold_and_main_error2(self):
  for bad in ('{}','[]','null','"STRING"','{"seq":1}','{"seq":1,"cmd_id":null}'):
   with self.subTest(bad=bad):
    # quote safely through sqlite placeholder
    p=Path(self.tmp.name)/'malformed.sqlite';p.unlink(missing_ok=True);shutil.copyfile(self.original,p)
    with closing(sqlite3.connect(p)) as c:
     c.execute('UPDATE events SET row_json=? WHERE seq=1',(bad,));c.commit()
    with self.assertRaisesRegex(cli.LabHold,'JOURNAL JSON ESTRUTURA INVÁLIDA|HISTÓRICO'):cli.load(p)
    e=io.StringIO()
    with redirect_stderr(e),redirect_stdout(io.StringIO()):rc=cli.main(['status','--save',str(p)])
    self.assertEqual(rc,2)
    self.assertIn('HOLD:',e.getvalue())
 def test_bad_state_shape_returns_hold(self):
  for bad in ('[]','null','"text"','123'):
   with self.subTest(bad=bad):
    p=Path(self.tmp.name)/'malformed.sqlite';p.unlink(missing_ok=True);shutil.copyfile(self.original,p)
    with closing(sqlite3.connect(p)) as c:
     c.execute('UPDATE meta SET value=? WHERE key="state"',(bad,));c.commit()
    with self.assertRaisesRegex(cli.LabHold,'METADATA STATE NÃO-OBJETO'):cli.load(p)
 def test_missing_scene_metadata_is_hold(self):
  p=self.altered("DELETE FROM meta WHERE key='scene'")
  with self.assertRaises(cli.LabHold):cli.load(p)
 def test_original_remains_valid(self):
  self.assertTrue(cli.load(self.original)[2]>1)
if __name__=='__main__':unittest.main()
