"""Independent negative tests against R262's unchanged journal verifier."""
import importlib,sqlite3,tempfile,shutil,unittest,json
from contextlib import closing
from pathlib import Path
cli=importlib.import_module('vlab_r18_interactive')
class TestR263Journal(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='vlab-r263-');self.addCleanup(self.tmp.cleanup)
  self.origin=Path(self.tmp.name)/'origin.sqlite'
  cli.demo(self.origin,'B',seed=26300)
  with closing(sqlite3.connect(self.origin)) as c:
   c.execute('PRAGMA wal_checkpoint(TRUNCATE)')
  self.assertTrue(cli.load(self.origin)[2]>=2)
 def mutation(self,sql,params=()):
  target=Path(self.tmp.name)/'attack.sqlite'
  target.unlink(missing_ok=True);shutil.copyfile(self.origin,target)
  with closing(sqlite3.connect(target)) as con:
   con.execute(sql,params);con.commit()
  with self.assertRaises(cli.LabHold):cli.load(target)
 def test_integrity_gate_rejects_mutations(self):
  cases=[
   ('head',"UPDATE meta SET value='fake-head' WHERE key='head'"),
   ('revision',"UPDATE meta SET value='999' WHERE key='revision'"),
   ('genesis',"UPDATE meta SET value='other-genesis' WHERE key='genesis'"),
   ('mode',"UPDATE meta SET value='STRICT' WHERE key='mode'"),
   ('snapshot',"UPDATE meta SET value='{}' WHERE key='state'"),
   ('row_hash',"UPDATE events SET row_sha='bad' WHERE seq=1"),
   ('row_content',"UPDATE events SET row_json='{}' WHERE seq=1"),
   ('before',"UPDATE events SET before_sha='bad' WHERE seq=1"),
   ('after',"UPDATE events SET after_sha='bad' WHERE seq=1"),
   ('prev',"UPDATE events SET prev='bad' WHERE seq=1"),
   ('cmd',"UPDATE events SET cmd_id='LAB-CMD-ATTACKER' WHERE seq=1"),
   ('seq',"UPDATE events SET seq=999 WHERE seq=1"),
   ('delete-last','DELETE FROM events WHERE seq=(SELECT MAX(seq) FROM events)'),
   ('pending',"INSERT INTO pending VALUES ('LAB-CMD-ATTACK','bad','START','{}')"),
  ]
  for name,statement in cases:
   with self.subTest(case=name):self.mutation(statement)
  self.assertEqual(cli.load(self.origin)[0]['scene'],'B')
if __name__=='__main__':unittest.main()
