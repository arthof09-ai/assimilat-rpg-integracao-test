"""R261, cold-path failpoint proof; no live or canonical actors."""
import os,subprocess,sys,tempfile,sqlite3,json,unittest
from contextlib import closing
from pathlib import Path
ROOT=Path(os.environ.get('VLAB_R18_ROOT',Path.cwd())).resolve()
ENTRY=ROOT/'fusion_stage12/vlab_r18_interactive.py'
ENV={**os.environ,'PYTHONPATH':str(ROOT/'fusion_stage12')}

def call(*args):return subprocess.run([sys.executable,str(ENTRY),*map(str,args)],capture_output=True,text=True,env=ENV)

def sql_meta(path):
 with closing(sqlite3.connect(path)) as c:return dict(c.execute('SELECT key,value FROM meta'))

def current_events(path):
 with closing(sqlite3.connect(path)) as c:return list(c.execute('SELECT seq,cmd_id,row_json FROM events ORDER BY seq'))

def mechanical(path):
 m=sql_meta(path);s=json.loads(m['state']);return (s['scene'],s['seed'],s['round'],s['winner'],s['finish_reason'],{x:(y['resource']['hp'],y['resource']['pa']) for x,y in s['actors'].items()})

class CrashTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(prefix='vlab-r261-');self.addCleanup(self.tmp.cleanup)
 def p(self,name):return Path(self.tmp.name)/name
 def test_commit_crash_can_resume_without_duplication(self):
  for seed in (26101,26102,26103):
   with self.subTest(seed=seed):
    p=self.p(f'crash-{seed}.sqlite');control=self.p(f'baseline-{seed}.sqlite')
    cr=call('demo','--save',p,'--scene','B','--seed',seed,'--crash-after',2)
    self.assertEqual(cr.returncode,77,cr.stderr)
    self.assertEqual(sql_meta(p)['revision'],'2')
    self.assertEqual(len(current_events(p)),2)
    resume=call('demo','--save',p)
    self.assertEqual(resume.returncode,0,resume.stderr)
    self.assertEqual(call('demo','--save',control,'--scene','B','--seed',seed).returncode,0)
    self.assertEqual(mechanical(p),mechanical(control))
    old=current_events(p)
    self.assertEqual(call('demo','--save',p).returncode,0)
    self.assertEqual(current_events(p),old)
 def test_durable_intent_crash_fails_closed(self):
  for scene in ('A','B'):
   with self.subTest(scene=scene):
    p=self.p(f'intent-{scene}.sqlite')
    code=f'''import sys\nsys.path.insert(0,{repr(str(ROOT/'fusion_stage12'))})\nimport vlab_r18_interactive as m\np={repr(str(p))}\nm.init_db(p,{scene!r},26198)\nm.event_commit(p,'LAB-CMD-R261-INTENT','START',{{}},m.do_start,failpoint='AFTER_INTENT')'''
    first=subprocess.run([sys.executable,'-c',code],capture_output=True,env=ENV)
    self.assertEqual(first.returncode,78,first.stderr)
    self.assertEqual(sql_meta(p)['revision'],'0')
    with closing(sqlite3.connect(p)) as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM pending').fetchone()[0],1)
    blocked=call('demo','--save',p)
    self.assertEqual(blocked.returncode,2)
    self.assertIn('UNKNOWN_EFFECT',blocked.stderr)
    self.assertEqual(sql_meta(p)['revision'],'0')
    self.assertEqual(len(current_events(p)),0)

if __name__=='__main__':unittest.main()
