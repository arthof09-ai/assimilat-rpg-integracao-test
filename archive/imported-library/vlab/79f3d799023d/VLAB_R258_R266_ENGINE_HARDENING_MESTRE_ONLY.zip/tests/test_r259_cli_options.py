import importlib, io, tempfile, unittest
from pathlib import Path
from contextlib import redirect_stdout,redirect_stderr
cli=importlib.import_module('vlab_r18_interactive')
class TestOptionContracts(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/'case.sqlite'
    def invoke(self,cmd,*args):
        o=io.StringIO();e=io.StringIO()
        with redirect_stdout(o),redirect_stderr(e):r=cli.main([cmd,'--save',str(self.db),*args])
        return r,e.getvalue()
    def test_reaction_a_new_holds_without_init(self):
        r,e=self.invoke('demo','--scene','A','--reaction')
        self.assertEqual(r,2);self.assertIn('SCENE_B',e);self.assertFalse(self.db.exists())
    def test_reaction_a_existing_holds_unmodified(self):
        cli.init_db(self.db,'A',12);h=cli.load(self.db)[1]
        r,_=self.invoke('demo','--reaction')
        self.assertEqual(r,2);self.assertEqual(cli.load(self.db)[1],h)
    def test_reaction_b_still_works(self):
        r,e=self.invoke('demo','--scene','B','--reaction','--seed','151')
        self.assertEqual(r,0,e);self.assertGreater(cli.load(self.db)[2],2)
    def test_play_cannot_take_reaction(self):
        r,e=self.invoke('play','--reaction','--scene','B')
        self.assertEqual(r,2);self.assertIn('DEMO_OPTION',e);self.assertFalse(self.db.exists())
    def test_non_demo_crash_option_rejected(self):
        r,e=self.invoke('status','--crash-after','2')
        self.assertEqual(r,2);self.assertIn('DEMO_OPTION',e)
    def test_status_seed_rejected(self):
        r,e=self.invoke('status','--seed','125')
        self.assertEqual(r,2);self.assertIn('CLI_UNUSED',e)
    def test_history_scene_rejected(self):
        r,e=self.invoke('history','--scene','A')
        self.assertEqual(r,2);self.assertIn('CLI_UNUSED',e)
    def test_export_seed_rejected(self):
        r,e=self.invoke('export','--seed','125','--output',str(self.db)+'.json')
        self.assertEqual(r,2);self.assertIn('CLI_UNUSED',e)
    def test_output_other_cmd_rejected(self):
        r,e=self.invoke('demo','--output','/tmp/shouldnotexist-777xyz')
        self.assertEqual(r,2);self.assertIn('OUTPUT_ONLY',e);self.assertFalse(self.db.exists())
    def test_negative_crash_rejected(self):
        r,e=self.invoke('demo','--crash-after','-1')
        self.assertEqual(r,2);self.assertIn('REQUIRES_ATTACK',e);self.assertFalse(self.db.exists())
    def test_crash_on_start_rejected(self):
        r,e=self.invoke('demo','--crash-after','1')
        self.assertEqual(r,2);self.assertIn('REQUIRES_ATTACK',e);self.assertFalse(self.db.exists())
    def test_demo_plain_still_works(self):
        r,e=self.invoke('demo','--seed','151','--scene','A')
        self.assertEqual(r,0,e)
    def test_existing_resume_no_flag_still_works(self):
        cli.init_db(self.db,'B',225)
        r,e=self.invoke('demo')
        self.assertEqual(r,0,e)

if __name__=='__main__':unittest.main()
