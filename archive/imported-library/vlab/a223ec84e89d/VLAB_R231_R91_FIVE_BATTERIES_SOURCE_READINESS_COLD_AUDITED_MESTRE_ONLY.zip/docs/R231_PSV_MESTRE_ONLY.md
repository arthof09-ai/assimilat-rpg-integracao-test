# R231 — CINCO BATERIAS: índice de fonte e completude R91, sem alterar a matriz canônica

**Mestre-side, somente TEST/documento instrumental.** **Fonte da estrutura:** original `R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv`, 104 posições exatas, 25 A + 27 B + 25 C + 27 D. A Bateria E é uma dimensão adicional de equipamento; as 1.875 células oficiais mantêm **0 homologadas**.

**Resultado físico novo:** construção determinística com o `vlab_l04` preexistente de **225 clones virtuais**: A (25 posições × 5 arquétipos/raciais = 125), B (25 posições regulares × uma Besta genérica = 25; ADM/Divina ficaram **HOLD**, sem 26º/27º rank ED inventado) e C (25 posições × 3 papéis virtuais = 75). Clones não têm source-bound loadout/economia de todas ações suficiente para FULL-FIGHT e não substituem fichas reais. Proveniência/rank/CA racional/HP e pendências por clone são legíveis em `R231_VIRTUAL_SNAPSHOTS.json`. A matriz original está copiada **sem qualquer alteração**; a camada aditiva tem 104 linhas em JSON/CSV.

**Bateria D:** triagem de 8 Bestas-fonte distintas do `SPIRIT-BEAST-PRECREATE-VZ-08` e seu runtime VZ: Arraia de Trovão Vítreo, Tatu Vulcânico de Cobalto, Coruja da Aurora Partida, Salamandra de Cinza Azul, Cervo Ferrolunar, Serpente Prismática de Geada, Grifo de Sílica Tempestuosa e Manta Ferromnésica. São candidatas documentadas **em pré-criação**, sem prova de oito páginas físicas canônicas de Besta; não preenchem oito posições oficiais da bateria D. `B` não conta como espécie D.

**Bateria E:** candidato Manopla do Trovão Cativo, **PS/semicanônico Ouro, NÃO P4**: contrastes R226–R227 associados read-only, sem execução histórica repetida. Próxima fonte necessária: equipamento P4 com chassi físico e magia separáveis, fonte de RD e custo, portador, tempo/descanso.

**Verificação independente:** 104/104 posições da cópia R91 conferidas; 225 clones com IDs únicos; 0 full fights arbitrariamente promovidos; **7/7 adulterações semânticas rejeitadas** (homologação falsa, páginas D fictícias, D duplicada, promoção de E P4, actor completo falso, ADM fabricada, denominador inflado). Nenhum write canônico/Party. `PASS_R231_INDEPENDENT_R91_SOURCE_READINESS_ADDITIVE_AUDIT`.

**NAC-PASS:** PASS de índice/source-admission preliminar, não homologação científica dos benchmarks. **Estado global:** 0/17 e 0/1.875; produção HOLD. **NEXT:** substituir clones genéricos por fontes físicas completas por posição, começar por estrato B1/ON5 já testado, amostras independentes com RD física/mágica, política e iniciativa realmente roladas; contratar espécies D e primeiro E P4.
