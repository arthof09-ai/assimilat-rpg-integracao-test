"""R231: build 104-row ADDITIVE overlay; NEVER edit R91 and NEVER count as canon.
Uses existing L04 source-derived snapshot builder; no new combat engine and no battles run.
"""
import csv,json,hashlib,collections,sys
from pathlib import Path
from dataclasses import asdict
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from vlab_l04 import build_human,build_other_race,build_beast

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def brief(s):
 return {'id':s.actor_id,'kind':s.actor_kind,'actor_mode':s.actor_mode,'race_or_species':s.race_or_species,'rank':s.rank,'star':s.star,
   'ordinal_level':s.level,'hp':s.health,'soul':s.soul,'CA_exact':s.ca['exact'],'RD':s.rd,'stats':s.stats,'ff':s.physical_force,
   'source_refs':s.source_refs,'traits':list(s.traits),'missing_for_full_fight':list(s.missing_for_full_fight),'full_fight_eligible':s.full_fight_eligible,
   'canonical_entity_id':s.canonical_entity_id,'source_status':s.knowledge_state}

def run():
 pre=json.load(open(R/'sources/R231_FIVE_BATTERIES_PREREG.json'));d=json.load(open(R/'sources/R231_EIGHT_BEASTS_PRECREATE_SOURCE_EXCERPT.json'))
 old=list(csv.DictReader((R/'sources/R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv').open()))
 if len(old)!=104:raise AssertionError('R91 104 denominator changed')
 out=[];snapshots={};D={}
 for row in old:
  b=row['battery'][0];pos=int(row['power_position']);rank=row['rank'];star=int(row['star']) if row['star'] else None
  r={'battery':b,'position':pos,'rank':rank,'star':star,'operational_type':row['operational_position_type'],'official_homologated':0,
     'source_ids':[],'virtual_actor_snapshots':0,'virtual_complete_full_fight':0,'experiment_test_only':True,
     'proposed_species_candidates':[],'gaps':[],'next_action':''}
  if b=='A':
   variants=[build_human(rank,star,23100000+pos*10),*(build_other_race(rank,star,race,seed=23100000+pos*10+i) for i,race in enumerate(['Orc','Abissiano','Asa Prateada','Raça Superior'],1))]
   arr=[brief(v) for v in variants];snapshots[f'A:{pos}']=arr;r['source_ids']=[v['id'] for v in arr];r['virtual_actor_snapshots']=len(arr)
   r['virtual_complete_full_fight']=sum(v['full_fight_eligible'] for v in arr);r['gaps']=['LAB-ALLOCATIONS-NOT-A-CANONICAL-ED','equipment/reaction/action timing/tactics not completed for full fight','Orc early HP and racial Level-Up source rebase pending']
   r['next_action']='Select one ED archetype and receive approved Level-Up source snapshot, equipment and source-gated full fight'
  if b=='B':
   if pos<=25:
    beast=build_beast(rank,star,seed=23110000+pos);v=brief(beast);snapshots[f'B:{pos}']=[v];r['source_ids']=[v['id']];r['virtual_actor_snapshots']=1;r['gaps']=['RULE_DERIVED_BE_WITHOUT_STABLE_SPECIES','PA/action, critical, reaction, tiebreak and genuine encounter preflight']
    r['next_action']='Anchor one physical source beast and reconcile LAB derived HP/CA/RD/Attack/Speed with canon source'
   else:
    r['gaps']=['ADM or Divine requires actual underlying rank/star, special traits/vitals and physical source','no auto-assigned 26th or 27th ED tier']
    r['next_action']='Find properly classified and source-complete ADM or Besta Divina; do not infer underlying rank'
  if b=='C':
   roster=[build_other_race(rank,star,'Orc',seed=23120000+pos*10),build_human(rank,star,seed=23120000+pos*10+1,priority=('DES','CON','FOR','INT','SAB','CAR')),build_other_race(rank,star,'Abissiano',seed=23120000+pos*10+2)]
   arr=[brief(v) for v in roster];snapshots[f'C:{pos}']=arr;r['source_ids']=[v['id'] for v in arr];r['virtual_actor_snapshots']=3
   r['gaps']=['THREE_VIRTUAL_ACTORS_NOT_A_CANONICAL_TEAM','healing/control/spells/source/loadout/time and actor-specific admissibility incomplete']
   r['next_action']='Bind named legal support, defender and threat to one coherent active 3-actor scheduler scene'
  if b=='D':
   candidates=[x for x in d['candidates'] if x['rank']==rank and x['star']==star] if star else []
   r['proposed_species_candidates']=[x['code']+'|'+x['name'] for x in candidates];r['gaps']=['UNIQUE_SPECIES_PANEL_PHYSICAL_SOURCE_NOT_PROVEN','PRECREATE_VZ_SCOPE_NOT_P4']
   r['next_action']='Admit species only after physical canon page + complete stats/ability/escape/gates and source readback'
   D[f'D:{pos}']=r['proposed_species_candidates']
  out.append(r)
 s=collections.Counter(x['battery'] for x in out)
 if s!={'A':25,'B':27,'C':25,'D':27}:raise AssertionError('R91 split mismatch')
 dsource={'source':'SPIRIT-BEAST-PRECREATE-VZ-08','unique_distinct_candidate_names':len(set(c['name'] for c in d['candidates'])),'sources_physical_canon_confirmed':0,
          'proposed_candidates_by_position':D,'eight_species_do_not_fill_27_distinct_canon_slots':True}
 e={'battery':'E','source_item':'Manopla do Trovão Cativo','source_page':'3f5c2b324ede81f5ac62fb940204cdac','rank':'Ouro','source_status':'PS_SEMICANON_NOT_P4',
    'historical_evidence_only':'R226 8 paired seeds, 16 SQL TEST, 7 hits, 187 lightning extra, 154 PA; R227 6 paired seeds RD hypothesis','new_E_battles':0,
    'comparison':'SAME_PHYSICAL_EQUIPMENT, WITH VS WITHOUT MAGIC','physical_world_canon':False,'official_E_cells':0,
    'next_action':'Find P4 source item, original owner/equipped legality, separate physical and magical components plus source RD and rest rules'}
 (R/'evidence/reports/R231_R91_104_ADDITIVE_OVERLAY.json').write_text(json.dumps({'status':'ADD_ONLY_NOT_R91','source_versions':{'R91':'R82-104-ORIGINAL-UNCHANGED','L04':'SYNTHETIC_FACTORY'},'rows':out,'D_panel':dsource,'E_panel':e},ensure_ascii=False,indent=2)+'\n')
 (R/'evidence/reports/R231_VIRTUAL_SNAPSHOTS.json').write_text(json.dumps(snapshots,ensure_ascii=False,indent=2)+'\n')
 with (R/'evidence/reports/R231_R91_104_READINESS.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['battery','position','rank','star','operational_type','virtual_actor_snapshots','virtual_complete_full_fight','proposed_species_candidate_count','official_homologated','scientific_status','next_action'])
  for x in out:w.writerow([x['battery'],x['position'],x['rank'],x['star'],x['operational_type'],x['virtual_actor_snapshots'],x['virtual_complete_full_fight'],len(x['proposed_species_candidates']),0,'SOURCE_DERIVED_DESIGN_ONLY_NOT_OFFICIAL',x['next_action']])
 totals={'status':'PASS_R231_LOCAL_SCHEMA_SOURCE_INDEX_DESIGN_NOT_BATTLE','A_ED_virtual_snapshots':sum(x['virtual_actor_snapshots'] for x in out if x['battery']=='A'),
         'B_generic_Beast_virtual_snapshots':sum(x['virtual_actor_snapshots'] for x in out if x['battery']=='B'),
         'C_3_actor_team_virtual_snapshots':sum(x['virtual_actor_snapshots'] for x in out if x['battery']=='C'),
         'D_eight_distinct_species_precreate_candidates':dsource['unique_distinct_candidate_names'],
         'E_semicanon_item_paired_historical_tests':8,'E_new_test_runs':0,'R91_positions':104,
         'official_cells_1875':0,'contract_17':0,'new_virtual_snapshots':sum(x['virtual_actor_snapshots'] for x in out),
         'new_combat_runs':0,'special_positions_declared_not_forged':4}
 (R/'evidence/reports/R231_TOTALS.json').write_text(json.dumps(totals,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(totals,ensure_ascii=False,indent=2))
if __name__=='__main__':run()
