"""Independent read-only semantic audit of 104-position ADDITIVE overlay. Does not import L04.
Note: source snapshots are virtual, not real actors.
"""
from pathlib import Path
import csv,json,collections,copy,hashlib
from fractions import Fraction
R=Path(__file__).resolve().parents[1]
def req(x,msg):
 if not x:raise AssertionError(msg)
def validate(r91,overlay,snap,source,e,totals):
 req(len(r91)==len(overlay['rows'])==104,'DENOM104')
 req(collections.Counter(x['battery'] for x in overlay['rows'])=={'A':25,'B':27,'C':25,'D':27},'BATTERY_R91_COUNTS')
 req(len(snap)==25*3,'SNAPSHOT_KEYS_75')
 req(all(int(x['reference_homologated'])==0 for x in r91),'ORIGINAL_R91_HOMOLOGATION_ZERO')
 ids=[];by={}
 for original,row in zip(r91,overlay['rows']):
  req(row['battery']==original['battery'][0] and row['position']==int(original['power_position']) and row['rank']==original['rank'],'IDENTICAL_SCHEMA_POSITIONS')
  req(row['official_homologated']==0 and row['experiment_test_only'] is True and row['virtual_complete_full_fight']==0,'NO_PROMOTION')
  b,p=row['battery'],row['position'];key=f'{b}:{p}'
  if b=='D':
   req(row['virtual_actor_snapshots']==0 and row['source_ids']==[],'NO_FAKE_BEAST_SNAPSHOTS')
   for c in row['proposed_species_candidates']:
    req(any(c.startswith(a['code']+'|') and c.endswith(a['name']) for a in source['candidates']),'PRECREATE_CANDIDATE')
  elif b=='B' and p>25:
   req(key not in snap and row['virtual_actor_snapshots']==0,'SPECIAL_ADM_DIVINE_HOLD')
  else:
   expected=5 if b=='A' else 3 if b=='C' else 1
   data=snap[key];req(len(data)==row['virtual_actor_snapshots']==expected,'VIRTUAL_COUNT')
   req(set(row['source_ids'])==set(z['id'] for z in data),'IDS_MATCH')
   for obj in data:
    ids.append(obj['id']);req(obj['canonical_entity_id'] is None and obj['full_fight_eligible'] is False,'NOT_REAL_ACTOR')
    req(len(obj['missing_for_full_fight'])>0 and obj['ordinal_level']==p,'GATED_ACTOR_LEVEL')
    req(obj['rank']==row['rank'] and obj['star']==row['star'] and obj['hp']>0,'SOURCED_RANK')
    req(Fraction(obj['CA_exact'])>=0,'CA_FRACTION')
    req(obj['kind']==('BE' if b=='B' else 'ED'),'RACE_CLASS')
    if b=='B':req(('Titã' in obj['traits'])==(p>=21),'LEGENDARY_TITAN_AUTO')
    by[obj['id']]=obj
 req(len(ids)==225 and len(set(ids))==225,'UNIQUE_225_ACTORS')
 req(len(source['candidates'])==8 and len({x['name'] for x in source['candidates']})==8,'EIGHT_DISTINCT_PRECREATE')
 req(len({x['code'] for x in source['candidates']})==8,'EIGHT_SOURCE_CODES')
 req(overlay['D_panel']['eight_species_do_not_fill_27_distinct_canon_slots'] is True,'D_NO_AUTO_PROMOTION')
 req(overlay['D_panel']['sources_physical_canon_confirmed']==0,'D_PHYSICAL_PAGES_ZERO')
 req(e['source_status']=='PS_SEMICANON_NOT_P4' and e['official_E_cells']==0 and e['new_E_battles']==0,'E_SEMICANON_FENCE')
 req(totals['A_ED_virtual_snapshots']==125 and totals['B_generic_Beast_virtual_snapshots']==25 and totals['C_3_actor_team_virtual_snapshots']==75,'TOTALS_CORRECT')
 req(totals['new_virtual_snapshots']==225 and totals['R91_positions']==104 and totals['official_cells_1875']==0 and totals['contract_17']==0,'ALL_OFFICIAL_HOLD')
 return {'verified_positions':104,'unique_virtual_snapshots':len(ids),'A':125,'B':25,'C':75,'D_distinct_candidate_names':8,'E_item_source_grade':'PS/SEMICANON','official_cells_certified':0,'full_source_species':0}
def audit(root=R,write=True):
 root=Path(root)
 old=list(csv.DictReader((root/'sources/R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv').open()))
 full=json.load(open(root/'evidence/reports/R231_R91_104_ADDITIVE_OVERLAY.json'))
 snap=json.load(open(root/'evidence/reports/R231_VIRTUAL_SNAPSHOTS.json'))
 source=json.load(open(root/'sources/R231_EIGHT_BEASTS_PRECREATE_SOURCE_EXCERPT.json'))
 total=json.load(open(root/'evidence/reports/R231_TOTALS.json'))
 result=validate(old,full,snap,source,full['E_panel'],total)
 rejections={}
 tests={
  'FAKE_A_OFFICIAL_PROMOTION':lambda a,b,c,d,e: a['rows'][0].__setitem__('official_homologated',1),
  'FAKE_D_CANON_PAGES':lambda a,b,c,d,e:a['D_panel'].__setitem__('sources_physical_canon_confirmed',8),
  'D_CANDIDATE_DUPLICATION':lambda a,b,c,d,e:c['candidates'][1].__setitem__('name',c['candidates'][0]['name']),
  'E_FAKE_P4_SOURCE':lambda a,b,c,d,e:a['E_panel'].__setitem__('source_status','P4-CANON'),
  'A_ACTOR_SOURCE_MISSING_FALSE':lambda a,b,c,d,e:b['A:1'][0].__setitem__('full_fight_eligible',True),
  'SPECIAL_26_FABRICATED':lambda a,b,c,d,e:a['rows'][next(i for i,x in enumerate(a['rows']) if x['battery']=='B' and x['position']==26)].__setitem__('virtual_actor_snapshots',1),
  'FALSE_NUMERATOR':lambda a,b,c,d,e:e.__setitem__('new_virtual_snapshots',226)
 }
 for name,fun in tests.items():
  a,b,c,d,e=copy.deepcopy(full),copy.deepcopy(snap),copy.deepcopy(source),copy.deepcopy(old),copy.deepcopy(total)
  fun(a,b,c,d,e)
  try:validate(d,a,b,c,a['E_panel'],e)
  except AssertionError as error:rejections[name]=str(error)
  else:raise AssertionError('ADVERSARY_NOT_DETECTED '+name)
 out={'status':'PASS_R231_INDEPENDENT_R91_SOURCE_READINESS_ADDITIVE_AUDIT','scientific_evidence':result,'semantic_adversaries_rejected':rejections,
      'adversarial_pass':len(rejections),'no_notional_P4_or_matrix_writes':True,'historical_replays':0,'source_snapshot_grade':'EXCERPT_ONLY'}
 if write:(root/'evidence/reports/R231_INDEPENDENT_AUDIT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(out,ensure_ascii=False,indent=2));return out
if __name__=='__main__':audit()
