#!/usr/bin/env python3
"""Read-only scientific transcription and normalization of physically fetched Notion leaf pages.
All records are explicitly limited to the cited excerpt and edited/version labels: not a full Notion archive.
This script never modifies canonical content, runs combat, or applies DMG-RANK v1.1.
"""
import csv,json,zipfile,io,hashlib,re,collections,itertools,statistics,math,pathlib
from fractions import Fraction
from datetime import datetime,timezone
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/mnt/data/dmg_succession')
oldzip=zipfile.ZipFile(ROOT/'historical/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip')
oldr04=list(csv.DictReader(io.StringIO(oldzip.read('readonly_sources/R04_ALL_INITIAL_ACTIONS.csv').decode('utf-8-sig'))))
oldr03=list(csv.DictReader(io.StringIO(oldzip.read('readonly_sources/R03_INITIAL_DAMAGE.csv').decode('utf-8-sig'))))
oldr02=list(csv.DictReader(io.StringIO(oldzip.read('readonly_sources/R02_DAMAGE_A_B_C.csv').decode('utf-8-sig'))))
old24=json.loads(oldzip.read('results/SOURCE_LEDGER_24.json'))
old_by={'R02':{x['page_id'] for x in oldr02},'R03':{x['page_id'] for x in oldr03},'R04':{x['page_id'] for x in oldr04},'REALIGNMENT_24':{x['id'] for x in old24}}
# exact bounded subtree: 8 rank-folder pages already fetched; every direct <page> child, and separately the <mention-page> count.
FOLDERS=[
('P1_VENTO','b05465a2e14f426d888b77f20c4de349','PRATA_1','Vento',2,0),
('P1_DARK','cf99e2973b7e4993bc2bccaa77d3bdbf','PRATA_1','Dark',2,1),
('P1_RAIO','0572a9a4196740f6a4671c7ec333192a','PRATA_1','Raio',1,0),
('P1_AGUA','098ed1d5b44943b3a152d2c499c860e2','PRATA_1','Água',1,0),
('B5_TERRA','9e20d43d55a3475f9f74d841094470d5','BRONZE_5','Terra',1,0),
('B5_AGUA','ee3707ddb1d34b47b95e2a11f5df1a74','BRONZE_5','Água',1,0),
('O5_TERRA','5f964dcff9cf4eedb9b900e87511b2eb','OURO_5','Terra',5,2),
('O5_VENTO','42ecf83be75f48c481b1e71bd36b5e87','OURO_5','Vento',3,5)]
folder_lookup={x[0]:x for x in FOLDERS}
# leaf primary: 16 explicit species children in these 8 rankfolders + 13 separately selected leaves (NON-EXHAUSTIVE supplement)
# helper tuple: id, tier scope, species parent id, ancestor label, body name, body class, rank/title, stats, documented effect list.
# Effects: (literal ability name, literal formula if complete, attr code, attr value, damage channel, extra conditions, PA cost, timing/action, eligibility marker)
SRC=[
('4bac2b324ede8321af6b01eb96452d04','P1_VENTO','46cc2b324ede83cf864e8159e97e9cba','Lupusventus','lobo da caverna','Prata 1','Prata 1',{'FOR':25},[('Patada','2d6 + força','FOR',25,'VIDA','Força Ancestral +2 FOR descrita separadamente; gatilho não definido',None,None,'CONDITIONAL_ATTR_BONUS')]),
('987c2b324ede82768b4c819713d0dc31','P1_VENTO','3c9c2b324ede83888c67810ed028a9ee','Morcego Gasoso','morcego fantasma','Prata 1','Prata 1',{'INT':36},[('Infecção fantasma','4d6 de alma temporário',None,None,'ALMA','perda temporária de Alma; não debitar PV',None,None,'SOUL_NOT_HP'),('Toque Tóxico','1d4 por turno',None,None,'DOT_POTENTIAL_HP','reflexo falho, envenenamento, duração não identificada',None,None,'CONDITIONAL_DOT')]),
('966c2b324ede83d7962b019b1861b6b1','P1_DARK','b5ac2b324ede82459e1c8133bd3a7643','Gambá Demoníaco','gambá','Prata 1','Prata 1',{'DES':25},[('Arranhão putrificador','2d6+Des','DES',25,'VIDA','ferida difícil de curar; fortitude para paralisia, CD não presente',None,None,'HP_FORMULA_CONDITIONAL')]),
('725c2b324ede8301baed01d62bd2b8e0','P1_DARK','d57c2b324ede837fb6f481e7d9c20b19','Tigre Dente de Sabre','Tigris Sombrio','Prata 1','Prata 1',{'FOR':24},[('Presas Fantasmais','2d6+força','FOR',24,'VIDA','paralisia por medo sem chance definida',None,None,'HP_FORMULA_CONDITIONAL')]),
('206c2b324ede835383a1818a6edd5273','P1_RAIO','b0ac2b324ede827daf8b813aff080e97','Águia Arranha Céu','arranha céus','Prata 1','Prata 1',{'INT':30},[('Raio paralisante','1d4 + inteligência','INT',30,'VIDA','fortitude para não ficar paralisado; CD ausente',None,None,'HP_FORMULA_CONDITIONAL')]),
('474c2b324ede82d08ea6819069c17043','P1_AGUA','931c2b324ede83e383b301e57b580457','Concha Marinha','Concha Marinha Luminosa','Prata 1','Prata 1',{'FOR':30},[('Mordida','3d6 + Força','FOR',30,'VIDA','fonte descreve comportamento Inanimada; capacidade de atacar incerta',None,None,'ATTACK_ELIGIBILITY_UNCERTAIN')]),
('92bc2b324ede834ca813812ff4783805','B5_TERRA','766c2b324ede83a082630190b562ac9f','Escorpião de Diamante','escorpião Ártico','Bronze 5','Bronze 5',{'FOR':22,'DES':25},[('Rabada','1d6+1d4+ força','FOR',22,'VIDA','conflito de identidade ancestral-corpo',None,None,'HP_FORMULA_CONDITIONAL'),('Corte','1d6+ destreza','DES',25,'VIDA','conflito de identidade ancestral-corpo',None,None,'HP_FORMULA_CONDITIONAL')]),
('cd7c2b324ede822f89e9015f9812673d','B5_AGUA','6d4c2b324ede83a8973881a562a0e393','Azuragon','Azuragon','Bronze 5','Bronze 5',{'INT':24,'DES':19},[('Jato de Bolhas','1d6+ int','INT',24,'VIDA','desorientação, CD não apresentada',None,None,'HP_FORMULA_CONDITIONAL'),('Cauda de Coral','1d6+Des','DES',19,'VIDA','golpe da cauda; efeito adicional não especificado',None,None,'HP_FORMULA_CONDITIONAL')]),
('0e2c2b324ede83fa8032016593efec3e','O5_TERRA','f48c2b324ede82c28163019f88540f9b','Cervatox','Cervatox','Bronze','Ouro 5',{'FOR':88},[('Investida de Chifres',None,None,None,'VIDA','ofensiva descritiva sem dado numérico; drops 1dN não são dano',None,None,'FORMULA_MISSING')]),
('371c2b324ede837fad4c01bbfe9a95fb','O5_TERRA','f45c2b324ede823c9b9c81409c7082ca','Cervídeo Petreo','Guardião Pétreo','Lendário','Ouro 5',{'FOR':62},[('Chifres Petrificados','5d6+ for','FOR',62,'VIDA','classificação no corpo Lendário diferente da pasta Ouro 5',None,None,'CLASS_CONFLICT_MATH_ONLY')]),
('4fdc2b324ede834b896f015b95600516','O5_TERRA','cccc2b324ede82dfb75f01fa7e76dd97','Golem','Golem de Cristal','Bronze','Ouro 5',{'FOR':80},[('Golpe de Cauda',None,None,None,'VIDA','ataque descrito sem fórmula; drops não são dano',None,None,'FORMULA_MISSING')]),
('290c2b324ede838dbde401437cb06f52','O5_TERRA','518c2b324ede8348ac178125282ec364','Ursocristal','Ursocristal','Ouro (estrela ausente)','Ouro 5',{'FOR':64},[('Garras de Cristal',None,None,None,'VIDA','ataque qualitativo',None,None,'FORMULA_MISSING'),('Rugido Glacial',None,None,None,'VIDA','ataque em área descrito sem fórmula',None,None,'FORMULA_MISSING')]),
('7bac2b324ede83348f04814b2daf220a','O5_TERRA','1abc2b324ede820e9a9a817962fb88c6','Espectro de Areia','Espectro de Areia','Lendário','Ouro 5',{'INT':86},[('Criação de Tempestade de Areia',None,None,None,'CONTROL','cegueira/desorientação sem dano numérico',None,None,'NON_NUMERIC_CONTROL')]),
('a48c2b324ede838282c281785212bc1f','O5_VENTO','845c2b324ede839f87eb01a3850f1729','Salamence','Dragão Alado','Bronze','Ouro 5',{'INT':67},[('Sopro de Fogo',None,None,None,'VIDA','ataque descritivo sem fórmula',None,None,'FORMULA_MISSING'),('Garras Afiadas',None,None,None,'VIDA','ataque descritivo sem fórmula; drops separados',None,None,'FORMULA_MISSING')]),
('597c2b324ede8242bd5881027ef8d21f','O5_VENTO','139c2b324ede8220b81901880deede16','Sussurro Celestial','Sussurro Celestial','Ouro 1','Ouro 5',{'INT':40},[('Lâmina de Brisa','2d4 + INT','INT',40,'VIDA','Ouro 1 no corpo apesar de Ouro 5 em título e ancestral',None,None,'CLASS_CONFLICT_MATH_ONLY')]),
('1ebc2b324ede8281a21201f93a2145fb','O5_VENTO','a6dc2b324ede83a78f31819746deee1d','Zephyrax','Soberano da Luz da Lua','Bronze','Ouro 5',{'INT':64},[('Conjuração de Tempestades',None,None,None,'CONTROL','invoca relâmpagos, mas sem dano declarado',None,None,'FORMULA_MISSING')]),
# Directed non-exhaustive leaf supplements. Do not treat rank-folder sampling as exhausted.
('45bc2b324ede823cb1328108c91421b4','DIRECTED_P1','394c2b324ede838b846f815c37fc23b8','Véu Noturno','Véu Noturno','Prata 1','Ouro 4',{'INT':14},[('Toque Sombrio','2d4+ INT de PA','INT',14,'PA','dreno de PA, não de Vida',None,None,'RESOURCE_DAMAGE_NOT_HP')]),
('be5c2b324ede832e8b7a81c5460571c1','DIRECTED_P1','b2ec2b324ede82c6a7610150a581f808','Lobo das Cavernas','lobo da caverna','Prata 1','Prata 5',{'FOR':24},[('Patada','1d6 + força','FOR',24,'VIDA','Força Ancestral +2 FOR sem gatilho definido',None,None,'CLASS_CONFLICT_MATH_ONLY')]),
('5fcc2b324ede8339a5bd01cd65ea103e','DIRECTED_P1','c12c2b324ede837cb34001ff00aabede','Demônio Vermelho','Demônios Vermelhos','Prata 1','Prata 1',{'FOR':21},[('Força Demoniaca','+3 de dano',None,None,'BONUS_ONLY','não constitui fórmula ofensiva autónoma',None,None,'NO_STANDALONE_DAMAGE')]),
('92bc2b324ede828f9b040180a09d926d','DIRECTED_P1','53cc2b324ede831a867a0191bc0e45d1','Mamute Antigo','Mamute Antigo','Prata 1','Prata 1',{'FOR':22},[('Chifrada','2d6+2d4+Força','FOR',22,'VIDA','danos físico; precisão não identificada',None,None,'HP_FORMULA_CONDITIONAL')]),
('034c2b324ede83ffa7118144011beaf3','DIRECTED_P1','29bc2b324ede831c9c62812e214cdff9','Rinolupo','Rinolupo','Prata 1','Ouro 5',{'FOR':30},[('Investida Feroz','2d6+ for','FOR',30,'VIDA','já consta no R04 histórico',None,None,'CLASS_CONFLICT_MATH_ONLY')]),
('8aac2b324ede837391a481ce32a03119','DIRECTED_P1','27ec2b324ede839e8e95017071c41087','Símio Demoníaco','Guardião da Floresta Sombria','Prata 1','Ouro 2',{'FOR':28},[('Força Sobre-Humana','+5 de dano',None,None,'BONUS_ONLY','não há ataque próprio enumerado',None,None,'NO_STANDALONE_DAMAGE')]),
('b34c2b324ede82a88079016b52ba498e','DIRECTED_P1','bc2c2b324ede8216b21481c16b7307ee','Ovelha de Chifres','Cabra de chifres','Prata 1','Prata 5',{'DES':25,'FOR':10},[('Aranhão duplo','2d4 + destreza','DES',25,'VIDA','dano cortante',None,None,'CLASS_CONFLICT_MATH_ONLY'),('Investida','1d6 + força','FOR',10,'VIDA','empurrão sem regra quantitativa completa',None,None,'CLASS_CONFLICT_MATH_ONLY')]),
('c70c2b324ede831c8f6c018c0b9295bd','DIRECTED_P1','360c2b324ede82d6a5e0015fa9bbd941','Crocossuário Corrompido','Crocossombra','Prata (sem estrela)','Ouro 1',{'FOR':28,'DES':25,'INT':23},[('Raio de Putrificação','2d6+Int','INT',23,'VIDA','Peste Negra / efeito Dark +1d4 condicional, não somar automaticamente',None,None,'CLASS_CONFLICT_MATH_ONLY'),('Mordida Necrótica','3d6+1d4+For','FOR',28,'VIDA','+1d4 Dark possível; não aplicado sem tipo demonstrado',None,None,'CLASS_CONFLICT_MATH_ONLY'),('Cauda Fantasma','2d6+Dês','DES',25,'VIDA','+5 para acertar explicitado; CA/Luta alvo desconhecidos',None,None,'CLASS_CONFLICT_MATH_ONLY')]),
('2a7c2b324ede836abefc81af3e7aeef6','DIRECTED_P1','1cfc2b324ede833aaf9501ce6db36905','Anjo','Ser de Energia Cósmica','Bronze','Lendário 2',{'INT':45},[('Manipulação de Energia',None,None,None,'VIDA','texto qualitativo, sem dano',None,None,'FORMULA_MISSING')]),
('945c2b324ede82a99ef201ead7561c49','DIRECTED_P1','0dcc2b324ede831e9f1e0151bbb83e03','Basilisco','Dracarídeo Verde','Bronze','Lendário 2',{'INT':30},[('Sopro de Pedregulho',None,None,None,'VIDA','fórmula ausente',None,None,'FORMULA_MISSING')]),
('102c2b324ede83da9f3381d817425372','DIRECTED_P1','487c2b324ede83eeb8cc01193f520ca5','Neve Cornífera','Fera Cornífera das Neves','Bronze','Prata 1',{'FOR':26},[('Garras Geladas',None,None,None,'VIDA','fórmula ausente',None,None,'FORMULA_MISSING')]),
('9d0c2b324ede83f2a3ca817b6475bd61','DIRECTED_P1','341c2b324ede830494c281722b4a00f9','Guepardo Luminoso','Guepardos Luminosos','Bronze','Ouro 2',{'DES':28},[('Garras Luminosas',None,None,None,'VIDA','dano extra de luz sem valor',None,None,'FORMULA_MISSING')]),
('c1ec2b324ede82e59b8181001666041f','DIRECTED_P1','1aec2b324ede836484de01a1bd141b1c','Gárgula','Dracapra','Bronze','Ouro Negro 5',{'FOR':38},[('Carga de Chifres',None,None,None,'VIDA','fórmula ausente',None,None,'FORMULA_MISSING')])
]
# Three layers: pages -> effects -> parsed die/attribute/fixed components. No numeric assumptions for omitted fields.
assert len(SRC)==29 and len({x[0] for x in SRC})==len(SRC)
fmt=lambda s: 'https://app.notion.com/p/'+s
source_rows=[];effect_rows=[];comps=[]
for entry in SRC:
 id,scope,parent,ancestral,bodyname,bodyrank,title,attrs,effects=entry
 rank_folder=folder_lookup[scope][1] if scope in folder_lookup else None
 triple=(bodyrank==title==folder_lookup[scope][2].replace('_',' ').title()) if scope in folder_lookup else (bodyrank==title and bodyrank.startswith('Prata 1'))
 # explicit, not automatic canonical adjudication
 rank_concordance='YES' if triple else ('BODY_TITLE_BUT_WRONG_FOLDER' if bodyrank==title and scope in folder_lookup and not triple else 'CONFLICT_OR_INCOMPLETE')
 old_flags=[k for k,ids in old_by.items() if id in ids]
 source_rows.append(dict(page_uuid=id,url=fmt(id),version='Notion source last edited 2026-10-01; fetched 2026-10-16',scope=scope,rank_folder_uuid=rank_folder or '',species_parent_uuid=parent,ancestor_name=ancestral,body_name=bodyname,rank_label=title,rank_body=bodyrank,rank_ancestor=folder_lookup[scope][2] if scope in folder_lookup else 'SCOPED_OUTSIDE_8_FOLDER',rank_triple_concordance=rank_concordance,entity_identity_status='ALIAS_PENDING' if ancestral.casefold()!=bodyname.casefold() else 'SAME_NAME',historical_overlap=';'.join(old_flags) or 'NONE_OF_RECOVERED_R02_R03_R04_REALIGNMENT_24',source_state='NOTION_MASTER_READ_BODY_EXCERPT',page_class='LEAF_CREATURE_VARIANT',master_only='TRUE',source_byte_archive='NO; literal excerpt transcribed, not complete binary snapshot',effect_rows_len=len(effects)))
 for j,(name,formula,attr,val,channel,conds,pa,action,elig) in enumerate(effects,1):
  eid=f'{id}::effect::{j:02d}'
  d=dict(effect_id=eid,source_page_uuid=id,url=fmt(id),name_literal=name,formula_literal=formula or '',attribute_code=attr or '',attribute_value=val if val is not None else '',channel=channel,cost_PA=pa if pa is not None else 'NOT_DOCUMENTED',action_economy=action or 'NOT_DOCUMENTED',hit_precision='NOT_DOCUMENTED',damage_type='NOT_UNAMBIGUOUS' if channel in ['VIDA','DOT_POTENTIAL_HP'] else channel,conditions_and_extra=conds,classification_eligibility=elig,provenance='CURRENT_READONLY_NOTION_EXCERPT_20261016',historical_page_overlap=';'.join(old_flags),math_state='UNASSESSED',gross_mean='',min_value='',max_value='',dice_fraction='',distribution_support='',max_rd_window='')
  if formula:
   # literal formula parser: dice + attribute, includes 4d6 de alma, 1d4 per turn, 2d4+INT PA
   matches=[(int(n),int(s)) for n,s in re.findall(r'(?<!\d)(\d+)d(\d+)',formula,re.I)]
   if matches:
    die_expect=sum(Fraction(n*(s+1),2) for n,s in matches)
    const=val or 0
    d.update(math_state='EXACT_FORMULA_PARSED_CONDITIONAL_NOT_HIT_PROB',gross_mean=str(float(die_expect+const)),min_value=sum(n for n,s in matches)+const,max_value=sum(n*s for n,s in matches)+const,dice_fraction=str(float(die_expect/(die_expect+const))) if die_expect+const else '0',distribution_support='EXACT_PMF_GENERABLE',max_rd_window=sum(n*s for n,s in matches)+const)
    for k,(n,s) in enumerate(matches,1):comps.append(dict(component_id=eid+f'::DIE{k}',effect_id=eid,kind='DICE',literal=f'{n}d{s}',count=n,faces=s,expected=str(Fraction(n*(s+1),2)),source_original_formula=formula))
    if attr:comps.append(dict(component_id=eid+'::ATTRIBUTE',effect_id=eid,kind='ATTRIBUTE',literal=f'{attr}={val}',count='',faces='',expected=str(val),source_original_formula=formula))
    if channel=='ALMA':d['math_state']='EXACT_RESOURCE_ALMA_NOT_HP'
    if channel=='PA':d['math_state']='EXACT_RESOURCE_PA_NOT_HP'
    if channel=='DOT_POTENTIAL_HP':d['math_state']='PER_TURN_ONLY_DURATION_MISSING'
  effect_rows.append(d)
# Individual probability function with exact rational arithmetic; independent direct Cartesian enumeration used later by auditor.
def pmf(formula,constant):
 matches=[(int(n),int(s)) for n,s in re.findall(r'(?<!\d)(\d+)d(\d+)',formula,re.I)]
 p={constant:Fraction(1)}
 for n,s in matches:
  for _ in range(n):
   d=collections.defaultdict(Fraction)
   for k,w in p.items():
    for v in range(1,s+1):d[k+v]+=w/Fraction(s)
   p=dict(d)
 assert sum(p.values())==1
 return p
curves=[];summaries=[]
for e in effect_rows:
 if e['math_state']!='EXACT_FORMULA_PARSED_CONDITIONAL_NOT_HIT_PROB':continue
 p=pmf(e['formula_literal'],int(e['attribute_value'] or 0)); mmax=max(p)
 for rd in [0,10,20,25,30,35,40,50,60]:
  curves.append(dict(effect_id=e['effect_id'],rd=rd,expected_post_rd=str(float(sum(Fraction(max(0,d-rd))*w for d,w in p.items()))),p_positive=str(float(sum(w for d,w in p.items() if d>rd))),channel=e['channel'],condition='ONE_HIT_SCALAR_RD_TYPE_COMPATIBILITY_ASSUMED_TEST'))
 summaries.append({'effect_id':e['effect_id'],'support':len(p),'expected':float(sum(Fraction(d)*w for d,w in p.items())),'min':min(p),'max':mmax,'p_above_rd35':float(sum(w for d,w in p.items() if d>35))})
# Compare rank-concordant P1 numeric HP effects, allowing identity/attack availability uncertainty to remain conditional.
strict=[e for e in effect_rows if e['channel']=='VIDA' and e['math_state'].startswith('EXACT') and next(s for s in source_rows if s['page_uuid']==e['source_page_uuid'])['rank_triple_concordance']=='YES' and next(s for s in source_rows if s['page_uuid']==e['source_page_uuid'])['rank_body']=='Prata 1']
# one action from each physical page for historical comparability
rank_action=list({e['source_page_uuid']:e for e in strict}.values()); rank_action.sort(key=lambda x:x['source_page_uuid'])
means=[float(e['gross_mean']) for e in rank_action]
rank_noconcha=[e for e in rank_action if e['source_page_uuid']!='474c2b324ede82d08ea6819069c17043']
median=lambda a:float(statistics.median(a)) if a else None
mad=lambda a:median([abs(x-median(a)) for x in a]) if a else None
p1_report=dict(selection='TRIPLE_MATCH_PRATA1_FROM_READ_ONLY_SOURCES; ALIASES_NOT_ADJUDICATED',pages=len(rank_action),effects=len(rank_action),values=means,mean=float(statistics.mean(means)) if means else None,median=median(means),mad=mad(means),range=[min(means),max(means)] if means else None,source_uuids=[e['source_page_uuid'] for e in rank_action],without_inanimate_concha=dict(pages=len(rank_noconcha),mean=float(statistics.mean(float(x['gross_mean']) for x in rank_noconcha)),median=median([float(x['gross_mean']) for x in rank_noconcha]),range=[min(float(x['gross_mean']) for x in rank_noconcha),max(float(x['gross_mean']) for x in rank_noconcha)]),eligible_full_combat='ZERO_WITH_COMPLETE_HIT_PA_TYPE_AND_ACTION_EVIDENCE')
# same creature only, not 2 independent creatures. new qualitative scientific comparisons; one conditional source with +5 attack, NOT a hit probability
pairs=[]
for pid in ['cd7c2b324ede822f89e9015f9812673d','b34c2b324ede82a88079016b52ba498e','c70c2b324ede831c8f6c018c0b9295bd']:
 es=[e for e in effect_rows if e['source_page_uuid']==pid and e['math_state'].startswith('EXACT')]
 for a,b in itertools.combinations(es,2):
  p=pmf(a['formula_literal'],int(a['attribute_value'] or 0));q=pmf(b['formula_literal'],int(b['attribute_value'] or 0))
  pgt=sum(x*y for u,x in p.items() for v,y in q.items() if u>v)
  eq=sum(x*y for u,x in p.items() for v,y in q.items() if u==v)
  inversions=[];tie=[]
  original=(float(a['gross_mean'])>float(b['gross_mean']))-(float(a['gross_mean'])<float(b['gross_mean']))
  for rd in range(0,max(max(p),max(q))+2):
   ea=sum(Fraction(max(0,u-rd))*w for u,w in p.items());eb=sum(Fraction(max(0,v-rd))*w for v,w in q.items());sgn=(ea>eb)-(ea<eb)
   if sgn and original and sgn!=original:inversions.append(rd)
   if ea==eb:tie.append(rd)
  pairs.append(dict(page_uuid=pid,effectA=a['name_literal'],effectB=b['name_literal'],meanA=float(a['gross_mean']),meanB=float(b['gross_mean']),prob_A_gt_B=float(pgt),prob_equal=float(eq),rd_strict_inversions=inversions,rd_tie_points=tie,statistical_unit='ONE_PHYSICAL_SOURCE_CLUSTER',rank_conflict=next(x for x in source_rows if x['page_uuid']==pid)['rank_triple_concordance'],interpretation='EXACT_CONDITIONAL_RD_ONLY_NOT_REAL_COMBAT'))
# Count source old intersections distinct, not sum duplicate ability components.
lineage=[]
for s in source_rows:
 lineage.append(dict(page_uuid=s['page_uuid'],url=s['url'],new_fetch='NOTION_MASTER_FETCH_20261016',historical_R02=s['page_uuid'] in old_by['R02'],historical_R03=s['page_uuid'] in old_by['R03'],historical_R04=s['page_uuid'] in old_by['R04'],historical_realignment24=s['page_uuid'] in old_by['REALIGNMENT_24'],historical_lot002='UNKNOWN_MEMBERSHIP_ORIGINAL_NOT_RECOVERED',historical_lot003='UNKNOWN_MEMBERSHIP_ORIGINAL_NOT_RECOVERED',count_as_new_against_known='NO' if s['historical_overlap']!='NONE_OF_RECOVERED_R02_R03_R04_REALIGNMENT_24' else 'POTENTIALLY_NEW_SOURCE_NOT_GLOBAL_CERTIFIED',hash_source='UNKNOWN_RAW_BINARY',historical_source='R02/R03/R04/REALIGNMENT24' if s['historical_overlap']!='NONE_OF_RECOVERED_R02_R03_R04_REALIGNMENT_24' else 'NONE_IN_ACCESSIBLE_MATRICES'))
def write_csv(name,rows):
 if not rows:return
 with open(OUT/name,'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write_csv('SOURCE_PAGE_CYCLE4_FORENSIC.csv',source_rows)
write_csv('DAMAGE_EFFECT_CYCLE4_NORMALIZED.csv',effect_rows)
write_csv('DAMAGE_COMPONENT_CYCLE4.csv',comps)
write_csv('SCOPED_RANK_FOLDERS_8.csv',[dict(scope=x[0],rank_folder_uuid=x[1],tier=x[2],element=x[3],direct_page_children=x[4],additional_page_mentions=x[5],source='NOTION_RANK_FOLDER_READ_ONLY') for x in FOLDERS])
write_csv('DAMAGE_EXPECTATION_RD_CYCLE4.csv',curves)
write_csv('HISTORICAL_LINEAGE_AND_EXCLUSIONS_CYCLE4.csv',lineage)
(OUT/'COHORT_PRATA1_AND_NEW_PAIRS.json').write_text(json.dumps(dict(p1=p1_report,within_creature_pairs=pairs,formula_distribution_summaries=summaries),ensure_ascii=False,indent=2),encoding='utf-8')
summary=dict(pages_read=len(source_rows),scoped_folder_direct_page_children=sum(x[4] for x in FOLDERS),scoped_folder_page_mentions_not_resolved=sum(x[5] for x in FOLDERS),target_species_leaf_pages=16,directed_extra_leaves=13,effects_documented=len(effect_rows),numerical_formula_effects=sum(e['math_state'].startswith('EXACT_FORMULA_PARSED') for e in effect_rows),soul_effects=sum(e['channel']=='ALMA' for e in effect_rows),PA_damage_effects=sum(e['channel']=='PA' for e in effect_rows),DOT_effects=sum(e['channel']=='DOT_POTENTIAL_HP' for e in effect_rows),missing_formula_effects=sum(e['formula_literal']=='' for e in effect_rows),pages_not_in_accessible_prior_R02_R03_R04_REALIGNMENT24=sum(s['historical_overlap']=='NONE_OF_RECOVERED_R02_R03_R04_REALIGNMENT_24' for s in source_rows),pages_already_in_accessible_prior=sum(s['historical_overlap']!='NONE_OF_RECOVERED_R02_R03_R04_REALIGNMENT_24' for s in source_rows),rank_triple_P1_effects=len(rank_action),rank_triple_P1_pages=len(rank_action),effect_formula_eligible_full_combat=0,lot002_original_authentic_recovered=False,lot003_original_authentic_recovered=False,source_edited_date='2026-10-01 (last_edit from Notion page fetch)',source_fetch='2026-10-16 after user task',source_notes='Literal formula/ability excerpts manually transcribed from direct Notion Mestre page reads, full body snapshots NOT archived; statistical sampling nonrandom; no official combat applications')
(OUT/'SOURCE_COHORT_COUNTERS_CYCLE4.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'summary':summary,'P1':p1_report,'pairs':pairs},ensure_ascii=False,indent=2))
