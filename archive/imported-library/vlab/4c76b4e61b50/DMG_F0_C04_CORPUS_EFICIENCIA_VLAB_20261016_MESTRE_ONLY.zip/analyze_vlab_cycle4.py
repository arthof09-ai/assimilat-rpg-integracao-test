#!/usr/bin/env python3
"""Independent read-only attack receipt audit. Never runs the VLAB engine."""
import csv,io,json,zipfile,hashlib,pathlib,collections,statistics
OUT=pathlib.Path(__file__).resolve().parent; BASE=pathlib.Path('/mnt/data/dmg_succession')
P125=BASE/'cycle3/vlab_r125/R125_NATIVE_RECEIPTS_165_FOR_DMG.csv'
Z137=BASE/'cycle4/readonly_vlab/VLAB_R126_R137_PA_REACAO_AOO_CURA_MESTRE_ONLY.zip'
Z150=BASE/'cycle4/readonly_vlab/VLAB_R146_R150_SPATIAL_CORRECTION_MULTIRROUND_MESTRE_ONLY.zip'
P150=BASE/'cycle4/readonly_vlab/R150_DMG_ATTACK_RECEIPTS_3.csv'
read=lambda path:list(csv.DictReader(open(path,encoding='utf-8-sig',newline='')))
r125=read(P125)
z137=zipfile.ZipFile(Z137);z150=zipfile.ZipFile(Z150)
r137=list(csv.DictReader(io.StringIO(z137.read('r126_r132/R135_DMG_ATTACK_RECEIPTS_7.csv').decode('utf-8-sig'))))
r150=read(P150)
assert len(r125)==165 and len(r137)==7 and len(r150)==3
assert P150.read_bytes()==z150.read('r146_r150/R150_DMG_ATTACK_RECEIPTS_3.csv')
# CRC full packages, no false claims about all semantic contracts verified.
assert z137.testzip() is None and z150.testzip() is None
# verify manifests files and counts for just original archive data, historical audits not rerun.
def check_manifest(z,entry):
 obj=json.loads(z.read(entry));print('manifest type',entry,type(obj).__name__,list(obj)[:5] if isinstance(obj,dict) else len(obj))
 return obj
m137=check_manifest(z137,'SHA256_FILE_MANIFEST_R137.json');m150=check_manifest(z150,'R150_SHA256_MANIFEST.json')
# safely inspect manifest layouts for verification.
def flatten_manifest(o):
 if isinstance(o,list):return o
 for k in ['files','members','entries','manifest','records']:
  if isinstance(o.get(k),list):return o[k]
 if isinstance(o.get('sha256_by_path'),dict):return [{'path':p,'sha256':h} for p,h in o['sha256_by_path'].items()]
 if isinstance(o.get('files'),dict):return [{'path':p,**v} for p,v in o['files'].items()]
 return None
manifest_cert={}
for ident,z,obj in [('R137',z137,m137),('R150',z150,m150)]:
 rows=flatten_manifest(obj);passes=0;fails=[]
 if rows:
  for v in rows:
   if not isinstance(v,dict):continue
   path=next((v[k] for k in ['path','file','name','relative_path','archive_path'] if isinstance(v.get(k),str)),None)
   hh=next((v[k] for k in ['sha256','SHA256','hash'] if isinstance(v.get(k),str) and len(v[k])==64),None)
   if not path or not hh:continue
   try:
    raw=z.read(path)
    if hashlib.sha256(raw).hexdigest()!=hh:fails.append((path,'sha'))
    else:passes+=1
   except KeyError:fails.append((path,'missing'))
 manifest_cert[ident]=dict(manifest_layout='list' if rows else 'UNKNOWN_SCHEMA',checked_members=passes,failures=fails,zip_crc='PASS',zip_entries=len(z.namelist()),zip_sha256=hashlib.sha256((Z137 if ident=='R137' else Z150).read_bytes()).hexdigest())
# data model for homogeneous audit independent of source schema
def tr(b):return str(b).strip().lower() in ('true','1','yes')
records=[]
for x in r125:
 records.append(dict(batch='R125',run=x['run_id'],event=x['event_seq']+':'+x['action_index'],phase=x['scene_phase'],origin=x['attack_origin'],critical=x['critical'],actor=x['actor_instance'],target=x['target_instance'],hit=tr(x['hit']),raw=int(x['raw']),rd=int(x['rd_applied']),net=int(x['effective_post_rd']),hp=int(x['hp_loss_actual']),overkill=int(x['overkill']),before=int(x['hp_before']),after=int(x['hp_after']),pa='ATTACK_PA_0;OTHER_ACTORS_SEPARATE',technical_status=x['status']))
for x in r137:
 records.append(dict(batch='R137',run=x['run_id'],event=x['event_seq'],phase='ONE_ROUND_TECHNICAL',origin=x['attack_origin'],critical=x['critical'],actor=x['actor'],target=x['target'],hit=tr(x['hit']),raw=int(x['source_raw']),rd=int(x['RD_applied']),net=int(x['net_after_RD']),hp=int(x['HP_loss_actual']),overkill=int(x['overkill']),before=int(x['HP_before']),after=int(x['HP_after']),pa=x['PA_paid_in_attack_event'],technical_status=x['audit']))
for x in r150:
 records.append(dict(batch='R150_R146_ONLY',run=x['RUN_ID'],event=x['event_ID'],phase=x['scene_status'],origin=x['attack_origin'],critical=x['critical'],actor=x['attacker'],target=x['target'],hit=True,raw=int(x['raw']),rd=int(x['RD_fisica']),net=int(x['post_RD']),hp=int(x['effective_HP_loss']),overkill=int(x['overkill']),before=int(x['HP_before']),after=int(x['HP_after']),pa=x['PA_consumed_by_attack'],technical_status=x['cold_audit']))
checks=0;seen=set()
for x in records:
 key=(x['batch'],x['run'],x['event']);assert key not in seen,key;seen.add(key);checks+=1
 assert x['raw']>=0 and x['rd']>=0 and x['net']>=0 and x['hp']>=0 and x['overkill']>=0;checks+=5
 assert x['net']==x['hp']+x['overkill'];checks+=1
 assert x['hp']==x['before']-x['after'];checks+=1
 if x['hit']:
  assert x['net']==max(0,x['raw']-x['rd']);checks+=1
 else:
  assert x['raw']==x['rd']==x['net']==x['hp']==x['overkill']==0;checks+=1

def roll(x):
 a=list(x);gross=sum(v['raw'] for v in a);rd=sum(v['rd'] for v in a);net=sum(v['net'] for v in a);hp=sum(v['hp'] for v in a);ov=sum(v['overkill'] for v in a)
 assert gross-rd==net and net==hp+ov
 return dict(rows=len(a),hits=sum(v['hit'] for v in a),raw=gross,rd=rd,post_rd=net,hp_loss=hp,overkill=ov,hit_frequency_observed=sum(v['hit'] for v in a)/len(a) if a else None,rd_fraction_raw=rd/gross if gross else None,overkill_fraction_raw=ov/gross if gross else None,realized_fraction_raw=hp/gross if gross else None,origin=dict(collections.Counter(v['origin'] for v in a)),critical=dict(collections.Counter(v['critical'] for v in a)),scene_phase=dict(collections.Counter(v['phase'] for v in a)))
batch={k:roll(v for v in records if v['batch']==k) for k in ['R125','R137','R150_R146_ONLY']}
byrun={k:roll(v for v in records if v['run']==k) for k in sorted({v['run'] for v in records})}
assert len(byrun)==10
scenes={k:dict(batch=next(v['batch'] for v in records if v['run']==k),**v) for k,v in byrun.items()}
# R125 first 3 x 3-actor runs; technical scale 5x5 censored (13), 10x10(41),20x20(79).
assert batch['R125']['raw']==29031 and batch['R125']['rd']==2587 and batch['R125']['post_rd']==26444 and batch['R125']['hp_loss']==18990 and batch['R125']['overkill']==7454
assert batch['R150_R146_ONLY']['hp_loss']==659
# R150 371 healing /430 PA across scene, not attack PA efficiency. R132 79 healed / 75PA explicitly credited to that one spell.
cohort=dict(source_paths={'R125':str(P125),'R137':str(Z137)+':r126_r132/R135_DMG_ATTACK_RECEIPTS_7.csv','R150':str(P150)},source_sha256={'R125':hashlib.sha256(P125.read_bytes()).hexdigest(),'R137_csv_member':hashlib.sha256(z137.read('r126_r132/R135_DMG_ATTACK_RECEIPTS_7.csv')).hexdigest(),'R150':hashlib.sha256(P150.read_bytes()).hexdigest()},packages=manifest_cert,distinct_scene_run_ids=len(byrun),rows_total=sum(x['rows'] for x in batch.values()),batch=batch,by_run=scenes,accounting_checks=checks,statistical_unit='RUN/SEED/FAMILY, not attack event independent',miss_denominator_note='misses have raw=0 in source receipt; hit frequency observed under specific technical scene policies',R150_healing_context=dict(scene='R146_ONLY',effective_heal_4rounds=371,scene_total_PA=430,observed_damage_to_heal=659/371,net_HP_loss_minus_heal=659-371,remark='Do not call 659/430 offense per PA; 430 PA includes defensive/support/healing effects, not causal attribution'),R137_healing_context=dict(scene='R132',source_cured_HP=79,cost_PA=75,ratio_observed_HP_per_PA=79/75,remark='ONE source-bound TEST spell with +20 equipment modifier, not damage efficiency or population estimate'),R138_spatial_hold='EXCLUDED_NOT_PARITY_CLEARED',official_credit='ZERO',isolated_readonly=True)
(OUT/'VLAB_R125_R137_R150_OBSERVATIONAL_DMG.json').write_text(json.dumps(cohort,ensure_ascii=False,indent=2),encoding='utf-8')
with open(OUT/'VLAB_R125_R137_R150_EVENT_IDENTITY.csv','w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print(json.dumps({'manifests':manifest_cert,'batch':batch,'by_run':scenes,'checks':checks},ensure_ascii=False,indent=2))
