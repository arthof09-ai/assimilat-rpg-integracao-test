#!/usr/bin/env python3
import csv,zipfile,json,hashlib,pathlib,collections,statistics
OUT=pathlib.Path(__file__).resolve().parent;BASE=pathlib.Path('/mnt/data/dmg_succession')
# Physical artifact inventory: prior checkpoint already authenticated; this passage adds cold physical ZIP checks R07-R10.
paths=[BASE/'DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip',BASE/'historical/DMG_REALINHAMENTO_SISTEMICO_20261016_MASTER_ONLY.zip',BASE/'historical/DMG-F1-R11-B02-CERTIFICACAO-E-INTEGRACAO-VLAB-R03-v01.zip']+sorted((OUT/'historical').glob('DMG-F1-*.zip'))
rows=[]
for p in paths:
 z=zipfile.ZipFile(p);bad=z.testzip()
 rows.append(dict(unit=p.stem,original_ref=p.name,archive_available='RECOVERED_BYTE_AUTHENTICATED',path=str(p),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),members=len(z.namelist()),CRC='PASS' if bad is None else 'FAIL '+bad,historical_source_members=';'.join(x for x in z.namelist() if ('SOURCE' in x.upper() or 'CORPUS' in x.upper() or 'R04_ALL' in x.upper()))[:800],remaining='Individual L002/L003 membership not authenticated from original lots'))
for label,original,note in [('L002','DMG_F0_F6_LOTE_CIENTIFICO_002.zip','Reported 45 pages; 58 mechanics; 38 offensive groups; 68 math components; 64 occurrences'),('L003','Historical LOTE_003 source ZIP/matrix (original identifier unresolved)','Reported +71 pages; 56 formula entries from 35 pages; 108 components; 36 incomplete/conflict pages')]:
 rows.append(dict(unit=label,original_ref=original,archive_available='REPORTED_ONLY_ORIGINAL_NOT_MATERIALIZED',path='UNKNOWN',size='',sha256='',members='',CRC='UNVERIFIED',historical_source_members='UNKNOWN',remaining=note+'; recover original byte archive and source-by-source membership'))
with open(OUT/'HISTORICAL_PACKAGES_AUTHENTICITY_LEDGER.csv','w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# New limited efficiency observable: 2 unique development seeds, mirror 4 rows; NOT 4 independent experiments.
rr=list(csv.DictReader(open(BASE/'vlab/R116_DMG_NATIVE_RECEIPTS_212.csv',encoding='utf-8-sig')))
spell=[x for x in rr if int(x['pa_spent'])>0]
assert len(rr)==212 and len(spell)==4 and len({x['seed'] for x in spell})==2 and {int(x['pa_spent']) for x in spell}=={55}
assert sorted([int(x['actual_HP_taken']) for x in spell])==[35,35,38,38]
R137=json.loads((OUT/'VLAB_R125_R137_R150_OBSERVATIONAL_DMG.json').read_text())
eff=dict(R116_source='readonly previously authenticated 212 receipts, 4 mirrored spell events',event_rows=4,independent_seed_clusters=2,spell_cost_PA=55,observed_loss_by_seed={'920801':35,'915133':38},observed_HP_per_PA_by_seed={'920801':35/55,'915133':38/55},RD_applied_in_selected_spells=0,overkill_in_selected_spells=0,site_limits='Only attack spell cost, NOT other scene action costs; mirror of same seeds dependent; no population inference; need targeting and hit/defense completeness for independent scenario',R137_heal=dict(proposed_source='Reconstituição de Seiva + Luvas',spell_PA=75,one_scene_HP_restored=79,one_scene_heal_per_PA=79/75,not_comparable_to_attack='Healing and damage have different outcome functions, no relative winner'),R125_notes=dict(ordinary_attack_pa='0 as recorded, not infinite efficiency',observed_hit_rate=R137['batch']['R125']['hit_frequency_observed'],scene_cluster=6),R150_context=dict(attack_HP_loss=659,scene_total_PA=430,scene_heal=371,not_ratio='Cannot attribute 430 PA to 3 attacks. Scene censored.'))
(OUT/'EFFICIENCY_ACTUAL_R116_R137_R150_CONDITIONAL.json').write_text(json.dumps(eff,ensure_ascii=False,indent=2),encoding='utf-8')
phases=json.loads(zipfile.ZipFile(BASE/'DMG_F0_CIENCIA_P0_PLANO_SUPREMO_20261016_MESTRE_ONLY.zip').read('products/PRODUTO_4_MATRIZ_PLANO_SUPREMO_19_FASES.json'))
updates={
'F0':('A6 validated technically at 571 in previous checkpoint; A5 7/7 fingerprints, 0/7 old binary readback','A6 frozen; 8 holdouts untouched. No new F0 PASS','A5 current physical text snapshot, A7 external second coder, A8 writer authority','External + material'),
'F1':('Pre-existing R02–R04 and A6 structural references','29 source leaves directly fetched; 16 within bounded folder traversal, 13 targeted; eight page-mentions still unread','Extend controlled enumeration to remaining page mentions/versions; global D0 denominator remains unknown','Scientific + material'),
'F2':('Duplicate exclusions R02/R03/R04 present but L002/L003 opaque','29 UUIDs joined to four accessible historical registers; 10 overlap / 19 not in those accessible lists','Recover original L002/L003 membership, identify aliases/versions and dedup abilities','Material'),
'F3':('Physical formula extraction present in historical cohorts','29 source records; 37 effect records and literal mechanics; positive/negative/controls separated','Full-body snapshots and second-coder review, broader breadth and missing costs','Material + external'),
'F4':('R02/R04 prior math normalization','37 effects with 19 HP numerical PMFs, component table and 171 postRD cells','Type-specific RD and resource gating, PAs, action details, precision','Scientific + normative'),
'F5':('Taxonomy and title/body conflicts','Five damage/resource channels; rank, species and alias adjudication pending','Type-specific resistance and competent authority classification','Normative'),
'F6':('No genuine v1.1 application found','No genuine v1.1 fallback in this bounded scan; explicit formulas not overridden','RE/FIP/RN/RI demonstrated on actual offensive source lacking formula','Scientific + normative'),
'F7':('Selected Prata1 sample 4 effects','Cohort now six rank-triple-matched HP formulas, two not in accessible R02–R04/24','New varied types with adjudicated creature identity and combat eligibility','Scientific + material'),
'F8':('Conditional gross/RD curves old','Median/MAD/sensitivity six P1; exact 19 PMFs; VLAB raw/RD/overkill decomposition','Cluster-aware confidence, representative D0, additional independent seeds','Scientific'),
'F9':('Eight historic R02 pairs and three R04 comparisons','Two genuinely new same-page clusters b34c and c70c; 4 comparisons, no strict inversion (Azuragon old pair not counted new)','Pairs with same rank/PA/action/defense and not classification conflicted','Scientific + source identity'),
'F10':('Historical Bronze5 / Prata1 comparisons','Rank-concordant Prata1 + conditional Bronze5 and disputed high rank body; no universal threshold','Classified crossrank/typedRD with source hit/CA','Scientific + normative'),
'F11':('VLAB R116/R125 observed','R137 7 receipts/3 one-round scenes and R150 3 receipts/1 censored scene cold-authenticated','Distinct scenario validity gates, target CA/hit and true full fight; no independent combat from DMG','Material + VLAB'),
'F12':('Prior warnings about selection/dependence','Explicit 10/29 duplicates, 16 page children/8 mentions, 4+6 scene clusters, bias from Concha eligibility','Independent second coder and family separated holdout','Scientific + external')}
phase_rows=[]
for row in phases['phases']:
 p=row['phase'];a,b,c,d=updates.get(p,(row['evidence'],'No new material evidence','Remains on original phase gate','Normative + scientific'))
 phase_rows.append(dict(phase=p,canonical_original_name=row['name'],before=a,development=b,after='PARTIAL_EVIDENCE_NO_TERMINAL_CERT' if p in updates else row['state'],minimum_pending=c,dependency=d,formal_phase='F0_ACTIVE' if p=='F0' else 'NO_FORMAL_PROMOTION',gate_status='HOLD' if p=='F0' else 'NOT_TERMINALLY_ACCEPTED'))
with open(OUT/'PLAN_SUPREMO_PHASE_DELTA_F0_F18.csv','w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(phase_rows[0]));w.writeheader();w.writerows(phase_rows)
gates=dict(phase_count=19,F0_historical_marcos=8,F0_terminal_validated_marcos=4,A6_structural_technical_PASS_previous_checkpoint=True,A5_original_binary_readback='0/7',A5_current_text_fingerprints='7/7 previously PASS, full-current-snapshot not frozen this cycle',A7_blind_independent='0/8 external review pending',A8_writer='NOT_ASSUMED, instance ACK lease epoch HOLD',E01_to_E24='24 existing items, no new independently certified terminal guarantees',transversal_8='8 existing transversal gates, no new terminal approval',F13_to_F18='NOT STARTED, do not initiate v2',NAC_PASS='LOCAL_EXECUTION_INTEGRITY_PASS_CANONICAL_HOLD',no_party_or_canon_writes=True,phase_updates_not_written_to_Notion=True)
(OUT/'GATES_F0_E01_E24_NAC_PASS_CYCLE4.json').write_text(json.dumps(gates,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(phase_delta=len(phase_rows),packages=len(rows),eff=eff),ensure_ascii=False,indent=2)[:3000])
