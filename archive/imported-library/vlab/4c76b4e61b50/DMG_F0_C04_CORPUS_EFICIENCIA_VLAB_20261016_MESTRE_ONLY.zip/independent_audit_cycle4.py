#!/usr/bin/env python3
"""Different algorithm: direct Cartesian dice enumeration, pandas run-level aggregation, and CSV ID checks.
Auditor is computationally independent from generation, not a blind human source adjudicator.
"""
import csv,json,zipfile,hashlib,statistics,itertools,re,collections,pathlib,math
import pandas as pd
from fractions import Fraction
BASE=pathlib.Path(__file__).resolve().parent
load=lambda f:list(csv.DictReader(open(BASE/f,encoding='utf-8-sig',newline='')))
sources=load('SOURCE_PAGE_CYCLE4_FORENSIC.csv');effects=load('DAMAGE_EFFECT_CYCLE4_NORMALIZED.csv');comp=load('DAMAGE_COMPONENT_CYCLE4.csv');lineage=load('HISTORICAL_LINEAGE_AND_EXCLUSIONS_CYCLE4.csv');graphs=load('PROVENANCE_GRAPH_NODES_CYCLE4.csv');edges=load('PROVENANCE_GRAPH_EDGES_CYCLE4.csv');curves=load('DAMAGE_EXPECTATION_RD_CYCLE4.csv')
summ=json.loads((BASE/'SOURCE_COHORT_COUNTERS_CYCLE4.json').read_text());r=json.loads((BASE/'COHORT_PRATA1_AND_NEW_PAIRS.json').read_text());v=json.loads((BASE/'VLAB_R125_R137_R150_OBSERVATIONAL_DMG.json').read_text())
checks=0
uid={s['page_uuid'] for s in sources};assert len(uid)==len(sources)==29;checks+=len(sources)
assert len({e['effect_id'] for e in effects})==len(effects)==37;checks+=len(effects)
assert all(e['source_page_uuid'] in uid and e['url']=='https://app.notion.com/p/'+e['source_page_uuid'] for e in effects);checks+=len(effects)
assert all(c['effect_id'] in {e['effect_id'] for e in effects} for c in comp);checks+=len(comp)
assert len(lineage)==29 and {x['page_uuid'] for x in lineage}==uid;checks+=29
assert len(graphs)==608 and len(edges)>=630;checks+=2
assert sum(x['from_A6']=='YES' for x in graphs)==571;checks+=1
assert len({x['uuid'] for x in graphs})==len(graphs);checks+=len(graphs)
assert set(s['page_uuid'] for s in sources).issubset({n['uuid'] for n in graphs});checks+=len(sources)
assert sum(x['historical_R02']=='True' or x['historical_R03']=='True' or x['historical_R04']=='True' or x['historical_realignment24']=='True' for x in lineage)==10;checks+=29
assert sum(x['count_as_new_against_known']=='POTENTIALLY_NEW_SOURCE_NOT_GLOBAL_CERTIFIED' for x in lineage)==19;checks+=29
numerics=[e for e in effects if e['math_state']=='EXACT_FORMULA_PARSED_CONDITIONAL_NOT_HIT_PROB'];assert len(numerics)==19;checks+=1
# Cartesian enumeration directly (not iterative convolution).
def distribution(e):
 dice=[(int(a),int(b)) for a,b in re.findall(r'(\d+)d(\d+)',e['formula_literal'],re.I)]
 faces=[range(1,s+1) for n,s in dice for _ in range(n)]
 nums=collections.Counter(sum(rolls)+int(e['attribute_value'] or 0) for rolls in itertools.product(*faces))
 den=sum(nums.values())
 return {k:Fraction(n,den) for k,n in nums.items()}
lookup={e['effect_id']:e for e in effects};dist={e['effect_id']:distribution(e) for e in numerics};
for e in numerics:
 d=dist[e['effect_id']];assert sum(d.values())==1;checks+=1
 avg=sum(Fraction(k)*p for k,p in d.items());assert abs(float(avg)-float(e['gross_mean']))<1e-12;checks+=1
 assert min(d)==int(e['min_value']) and max(d)==int(e['max_value']);checks+=2
# independent mean after RD vs generated curves
for x in curves:
 e=lookup[x['effect_id']];d=dist[e['effect_id']];rd=int(x['rd'])
 post=sum(Fraction(max(0,n-rd))*p for n,p in d.items())
 prob=sum(p for n,p in d.items() if n>rd)
 assert abs(float(post)-float(x['expected_post_rd']))<1e-11;checks+=1
 assert abs(float(prob)-float(x['p_positive']))<1e-12;checks+=1
# cluster pair exhaustive outcome probabilities and all RD integer order comparisons
for p in r['within_creature_pairs']:
 aa=next(x for x in numerics if x['source_page_uuid']==p['page_uuid'] and x['name_literal']==p['effectA'])
 bb=next(x for x in numerics if x['source_page_uuid']==p['page_uuid'] and x['name_literal']==p['effectB'])
 da=dist[aa['effect_id']]; db=dist[bb['effect_id']]
 gt=sum(x*y for u,x in da.items() for w,y in db.items() if u>w)
 eq=sum(x*y for u,x in da.items() for w,y in db.items() if u==w)
 assert abs(float(gt)-p['prob_A_gt_B'])<1e-12;checks+=1
 assert abs(float(eq)-p['prob_equal'])<1e-12;checks+=1
 orig=(p['meanA']>p['meanB'])-(p['meanA']<p['meanB'])
 inv=[];ties=[]
 for rd in range(max(max(da),max(db))+2):
  fa=sum(Fraction(max(0,u-rd))*prob for u,prob in da.items())
  fb=sum(Fraction(max(0,u-rd))*prob for u,prob in db.items())
  sign=(fa>fb)-(fa<fb)
  if orig and sign and orig!=sign: inv.append(rd)
  if fa==fb:ties.append(rd)
 assert inv==p['rd_strict_inversions'] and ties==p['rd_tie_points'];checks+=2
# R125 distinct transaction composite key matters: event_seq alone can repeat as counter is part of same transaction
attacks=pd.read_csv(BASE/'VLAB_R125_R137_R150_EVENT_IDENTITY.csv')
assert len(attacks)==175;checks+=1
assert not attacks.duplicated(['batch','run','event']).any();checks+=len(attacks)
assert not attacks.isna().any().any();checks+=1
for _,a in attacks.iterrows():
 assert a['net']==a['hp']+a['overkill'];checks+=1
 assert a['hp']==a['before']-a['after'];checks+=1
 assert a['raw']-a['rd']==a['net'];checks+=1
bdf=attacks.groupby('batch').agg(rows=('run','size'),hits=('hit','sum'),raw=('raw','sum'),rd=('rd','sum'),post_rd=('net','sum'),hp_loss=('hp','sum'),overkill=('overkill','sum'))
for k,vv in v['batch'].items():
 for col in bdf.columns:
  assert int(bdf.loc[k,col])==vv[col];checks+=1
assert attacks['run'].nunique()==10;checks+=1
# Coorte Prata1 manual-candidate scope rather than population, controls unknown eligibility
assert r['p1']['pages']==6 and sorted(r['p1']['values'])==[31,32,32,32.5,34,40.5];checks+=2
assert r['p1']['without_inanimate_concha']['pages']==5;checks+=1
# Source rank triple check excludes high-tier conflict / title confusions. Explicit page identity caveat.
assert not any(s['page_uuid']=='371c2b324ede837fad4c01bbfe9a95fb' and s['rank_triple_concordance']=='YES' for s in sources);checks+=1
# Manifest independently validated by VLAB analysis, independent audit checks again data SHA integrity.
for key in ('R137','R150'):
 cert=v['packages'][key];assert cert['checked_members']==(333 if key=='R137' else 25) and not cert['failures'] and cert['zip_crc']=='PASS';checks+=3
out=dict(status='PASS_LOCAL_MATH_AND_ARCHIVE',checks=checks,limitations=['Not independent human classification coder','Full Notion source body snapshots not archived','Historical L002/L003 original corpus missing','A7 holdout not unblinded','A8 writer HOLD','No VLAB scene was executed by DMG'],numeric_formula_count=len(numerics),source_page_count=len(sources),effect_count=len(effects),A6_inherited_rows=571,R125_R137_R150_events=175,run_clusters=10)
(BASE/'INDEPENDENT_COLD_AUDIT_CYCLE4.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
