#!/usr/bin/env python3
import zipfile,hashlib,json,sys,pathlib
p=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else __file__).resolve()
if p.suffix!='.zip':
 candidates=list(p.parent.glob('DMG_F0_C04_CORPUS*.zip'))
 assert candidates,"Pass the ZIP path as first argument";p=candidates[0]
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 m=json.loads(z.read('MANIFEST_SHA256_C04.json'))
 assert set(m['files'])==set(z.namelist())-{'MANIFEST_SHA256_C04.json'}
 for name,meta in m['files'].items():
  b=z.read(name)
  assert len(b)==meta['bytes'],(name,'size')
  assert hashlib.sha256(b).hexdigest()==meta['sha256'],(name,'hash')
 print('PASS manifest',len(m['files']),'CRC OK',p.name)
