#!/usr/bin/env python3
"""Graph audit from immutable A6 crosswalk plus physically read folder/species/leaf evidence."""
import csv,json,collections,pathlib
OUT=pathlib.Path(__file__).resolve().parent
A6=pathlib.Path('/mnt/data/dmg_succession/cycle3/A6_CROSSWALK_571_UUIDS_TWO_DEPTHS_RECONSTRUCTED.csv')
r=list(csv.DictReader(open(A6,encoding='utf-8-sig')))
src=list(csv.DictReader(open(OUT/'SOURCE_PAGE_CYCLE4_FORENSIC.csv',encoding='utf-8')))
folders=list(csv.DictReader(open(OUT/'SCOPED_RANK_FOLDERS_8.csv',encoding='utf-8')))
assert len(r)==571 and len({x['uuid'] for x in r})==571
f_by={x['scope']:x for x in folders};src_by={x['page_uuid']:x for x in src}
SCOPE_IDENTITY={
'P1_VENTO':['46cc2b324ede83cf864e8159e97e9cba','3c9c2b324ede83888c67810ed028a9ee'],
'P1_DARK':['b5ac2b324ede82459e1c8133bd3a7643','d57c2b324ede837fb6f481e7d9c20b19'],
'P1_RAIO':['b0ac2b324ede827daf8b813aff080e97'],
'P1_AGUA':['931c2b324ede83e383b301e57b580457'],
'B5_TERRA':['766c2b324ede83a082630190b562ac9f'],
'B5_AGUA':['6d4c2b324ede83a8973881a562a0e393'],
'O5_TERRA':['f48c2b324ede82c28163019f88540f9b','f45c2b324ede823c9b9c81409c7082ca','1abc2b324ede820e9a9a817962fb88c6','cccc2b324ede82dfb75f01fa7e76dd97','518c2b324ede8348ac178125282ec364'],
'O5_VENTO':['845c2b324ede839f87eb01a3850f1729','139c2b324ede8220b81901880deede16','a6dc2b324ede83a78f31819746deee1d']}
assert all(len(SCOPE_IDENTITY[k])==int(f_by[k]['direct_page_children']) for k in f_by)
# parent element Notion hierarchy established by rank folder fetch pages, not from ID structure.
ELEMENTS={
'P1_VENTO':'17bc2b324ede82ffb5028109bbee810c','P1_DARK':'805c2b324ede82708b9e81ba40cda2c1','P1_RAIO':'5dac2b324ede82ddbf4c81db6c5623b7','P1_AGUA':'824c2b324ede8232bc8c81ff7cf58802',
'B5_TERRA':'75fc2b324ede82f4a9fd01bba8d41833','B5_AGUA':'824c2b324ede8232bc8c81ff7cf58802','O5_TERRA':'75fc2b324ede82f4a9fd01bba8d41833','O5_VENTO':'17bc2b324ede82ffb5028109bbee810c'}
physical_species={p:(scope,f_by[scope]['rank_folder_uuid']) for scope,ps in SCOPE_IDENTITY.items() for p in ps}
node_rows=[];edges=[]
for x in r:
 id=x['uuid'];
 # type only if physical node fetched; otherwise classification is PENDING, not guessed from UUID format or index title
 physical_type='CREATURE_PARENT_VERIFIED' if id in physical_species else 'STRUCTURAL_UNREAD_REFERENCE'
 physical_parent=physical_species[id][1] if id in physical_species else 'PENDING'
 node_rows.append(dict(uuid=id,url=x['url'],node_type=physical_type,from_A6='YES',physical_parent_uuid=physical_parent,discovery_origin=x['origin'],A6_link_parent=x['parent_uuid'],depth_A6=x['depth'],Notion_edited_source=x['origin_version'],direct_body_read='YES' if id in physical_species else 'NO',master_side='YES',candidate_offense='YES; leaf must be fetched' if id in physical_species else 'UNASSESSED',authority='MESTRE_READ_ONLY',conflict='A6 link_parent is LINK-PROVENANCE, not necessarily immediate Notion ancestry' if id in physical_species and physical_parent!=x['parent_uuid'] else 'UNKNOWN_MIRROR'))
 edges.append(dict(parent=x['parent_uuid'],child=id,relation='A6_INDEX_VISIBLE_PAGE_LINK',verified='YES_20261016_INDEX_FETCH',sample_window='A6_FROZEN',unit='STRUCTURAL_REFERENCE'))
seen={x['uuid'] for x in node_rows}
for f in folders:
 id=f['rank_folder_uuid']
 if id not in seen:
  node_rows.append(dict(uuid=id,url='https://app.notion.com/p/'+id,node_type='RANK_STAR_FOLDER_VERIFIED',from_A6='NO',physical_parent_uuid=ELEMENTS[f['scope']],discovery_origin=f['scope'],A6_link_parent='',depth_A6='',Notion_edited_source='2026-10-01',direct_body_read='YES',master_side='YES',candidate_offense='NO_FOLDER',authority='MESTRE_READ_ONLY',conflict='NOT_MEMBER_A6_571_GRAPH_NODE_EXTENDED'))
  seen.add(id)
 edges.append(dict(parent=ELEMENTS[f['scope']],child=id,relation='NOTION_PHYSICAL_PARENT_VERIFIED_FROM_FOLDER_FETCH',verified='YES',sample_window=f['scope'],unit='RANK_FOLDER'))
for p,(scope,parent) in physical_species.items():
 edges.append(dict(parent=parent,child=p,relation='NOTION_PHYSICAL_PARENT_SPECIES',verified='YES_FROM_RANK_FOLDER_FETCH',sample_window=scope,unit='SPECIES_PARENT'))
for s in src:
 id=s['page_uuid'];parent=s['species_parent_uuid'];
 if id not in seen:
  node_rows.append(dict(uuid=id,url=s['url'],node_type='SOURCE_PAGE_CREATURE_VARIANT_VERIFIED',from_A6='NO',physical_parent_uuid=parent,discovery_origin=s['scope'],A6_link_parent='',depth_A6='',Notion_edited_source=s['version'],direct_body_read='YES',master_side='YES',candidate_offense='YES_NUMERIC' if any(e['source_page_uuid']==id and e['math_state'].startswith('EXACT') for e in csv.DictReader(open(OUT/'DAMAGE_EFFECT_CYCLE4_NORMALIZED.csv'))) else 'YES_DESCRIPTIVE_OR_RESOURCE',authority='MESTRE_READ_ONLY',conflict=s['rank_triple_concordance']+'; '+s['entity_identity_status']))
  seen.add(id)
 edges.append(dict(parent=parent,child=id,relation='NOTION_PHYSICAL_PARENT_LEAF',verified='YES_FROM_LEAF_FETCH',sample_window=s['scope'],unit='SOURCE_PAGE'))
# Known extra child variants, but not all fetched: record frontier, not fictional pages or complete tree certification.
frontier=[
 ('f45c2b324ede823c9b9c81409c7082ca','549c2b324ede8375b21181335038aad1','Prata 3'),('f45c2b324ede823c9b9c81409c7082ca','b0ec2b324ede835a927601b4cbd8fca6','Ouro 1'),
 ('139c2b324ede8220b81901880deede16','56ac2b324ede8352868101e11ea16355','Prata 1'),('139c2b324ede8220b81901880deede16','5e9c2b324ede83ed99078151805dec0b','Prata 5'),('139c2b324ede8220b81901880deede16','442c2b324ede8364870a814350dd5051','Ouro 1'),
 ('a6dc2b324ede83a78f31819746deee1d','3b0c2b324ede83cc931801874fb504b5','Prata 5')]
for p,id,tier in frontier:
 edges.append(dict(parent=p,child=id,relation='ADDITIONAL_VARIANT_NOT_IN_THIS_WINDOW',verified='NOTION_PARENT_LIST_READ',sample_window='NEXT_FRONTIER',unit='UNREAD_OR_HISTORICALLY_READ_LEAF'))
# NOT add 8 mention IDs as page verified. They remain untraversed references attached to rank folders.
for f in folders:
 if int(f['additional_page_mentions']):
  edges.append(dict(parent=f['rank_folder_uuid'],child=f"{f['additional_page_mentions']}_MENTION_REFERENCES_NOT_ENUMERATED",relation='DIRECT_MENTION_COUNT_ONLY',verified='COUNT_VERIFIED_IDS_NOT_INCLUDED',sample_window=f['scope'],unit='MENTION_NOT_VERIFIED_AS_CHILD'))
for fn,rows in [('PROVENANCE_GRAPH_NODES_CYCLE4.csv',node_rows),('PROVENANCE_GRAPH_EDGES_CYCLE4.csv',edges)]:
 with open(OUT/fn,'w',newline='',encoding='utf-8') as out:
  w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
metrics=dict(A6_frozen_reference_count=571,A6_rows_inherited_not_recomputed=len(r),rank_folders_physically_fetched=8,explicit_species_children_physically_fetched=16,rankfolder_extra_mention_references_unread=8,source_leaf_physically_fetched=29,leaf_in_scoped_rankfolders=16,leaf_directed_suppl=13,combined_graph_nodes=len(node_rows),combined_graph_edges=len(edges),extension_nodes_outside_A6=len(node_rows)-571,intersection_species_with_A6=len([p for p in physical_species if p in {x['uuid'] for x in r}]),source_leaf_intersection_with_A6=len([s for s in src if s['page_uuid'] in {x['uuid'] for x in r}]),readiness='PARTIAL_CLOSED_EXPLICIT_PAGE_CHILDREN_ONLY_NOT_8_MENTION_LINKS',next_frontier='eight mentor mentions under 3 selected folders, extra leaf variants, L002/L003 originals')
(OUT/'PROVENANCE_GRAPH_SCOPE_AND_DENOMINATORS.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(metrics,ensure_ascii=False,indent=2))
