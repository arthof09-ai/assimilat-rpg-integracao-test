# PSV — Registro integral de execução, pendências e retomada VLAB até R238 (MESTRE-ONLY)

**AS-OF:** 21/10/2026, horário local do Mestre (America/Recife). **Operação física existente:** `OP-VLAB-FUSION-SANDBOX-01`; **Comestre lógico:** `CM-000006`, `CM-000006-WS0001`; **ambiente:** MESTRE-SIDE/TEST. **Superfície persistente escolhida:** Biblioteca Mestre `/Comestre/OP-VLAB-FUSION-SANDBOX-01/`. **Documento:** handoff documental; não cria operação, motor ou norma. **Autoria concreta:** INSTANCE-ID/lease/epoch/fencing/writer NÃO VERIFICADOS; não reivindicados.

**NAC-PASS-02:** PASS apenas de consistência documental/readback da cópia de Biblioteca desta entrega, após checagem local; **HOLD global** de produção, writers, certificação terminal e publicação de jogo. NÃO confundir com certificado de 17 contratos ou combate oficial. A autorização do Mestre para registrar não substitui o claim formal de writer do domínio documental Notion. **Party, O Primeiro, fichas oficiais, Sistema de Combate, regras, DMG/LEVEL-UP e R91 oficial: NO-WRITE.**

## 1. Resumo executivo verificável

- **LAST-VERIFIED-UNIT:** `R238`, auditoria cruzada (somente leitura) dos quatro ZIPs R234–R237 e mapa R91 A–E, publicada na Biblioteca, com recuperações frias, verificadores e CRC PASS; **R238 não executou combate novo**.
- **FIRST-PENDING:** `R239` apenas como **candidato**, sujeito a busca de colisão e à fonte completa. Primeiro investigar P4 real de Besta e/ou item E; depois controle com duração e escape, transformação ED↔Espírito↔Besta, incremento de testes R18 admissíveis. Não chamar R239 de executada.
- **Indicadores oficiais preservados:** **0/17 contratos terminais certificados**, **0/1.875 células de confronto homologadas**; **104 posições primárias documentais R91**, distintas das células de confronto; produção HOLD.
- Os relatórios e ZIPs independentes R215–R238 continuam sob uma única pasta Library, sem sobrescrita de releases e sem refazer as seeds/SQLite anteriores. O trabalho registrado neste documento **não equivale à reauditoria de todo R01–R238**: o recorte detalhado é R215–R238 com documentos primários e consolidados consultados; R01–R214 são legado preservado.
- O perfil do Comestre no Notion apresenta **`BLOCK-PERMIT=RED`, `GREEN=HOLD` e writer/epoch/lease/fencing não verificados**. Por isso, este registro não altera a OP no Notion; a transcrição documental é **PENDENTE DE WRITER COMPETENTE**, e um resumo copy-ready acompanha o pacote. Fonte: https://app.notion.com/p/3f4c2b324ede81ff865ff17b0491301a.

## 2. Marcos anteriores preservados (R01–R214; não reexecutados nem reauditorados integralmente agora)

- Stage02–Stage12, reconstruções v0.8.1/A1/R18, fontes DMG e Combat, scheduler, RNG, ação/reação, chain hash e arquivos anteriores preservados em Library/OP. A OP Notion guarda histórico antigo de estágios e decisões R50/R51. **Não assumir que número de testes históricos = certificação terminal**.
- R50: Contra-atacar só reage ao **ERRO efetivo** do ataque normal original; crítico positivo é acerto automático mesmo se RD absorve 100% do dano. R51: não há contra-ataque do contra-ataque; A só pode responder a ataque normal posterior de B nas condições próprias.
- R205 Defesa de Vento/Anel; R206B tática adaptativa PASS condicional após R206 FAIL; R207 e R208 Pulso de Estabilização/luvas em testes nativos; R209 Tempestade de Esporos e R210 centros; R211–R214 movimento, Ataque de Oportunidade, Reações e prioridade R43. R214: 0/17 e 0/1.875 preservados.
- Regra crítica: empate Ataque × Defender/Esquivar favorece defesa; empurrão 1,5m por 300 FF; movimento forçado não gera AoO; saída da adjacência pode gerar AoO, mas bloco↔metro/diagonal ainda depende de norma. Não converter achados em mudança de fonte física.

## 3. Inventário cronológico detalhado — checkpoints R215–R238

| R | Entrega e unidade correta | Evidência medida | Limite/estado | Pacote preservado |
|---:|---|---|---|---|
| R215 | 24 cenas R18 (16 defesa, 3 contra-ataque, 5 equipe 2x1) | 212 commits; 914 eventos; 16 defesas; 12 respostas; 10 curas; 17 conjurações | 24 censuras; 0 KO; fonte de NPCs PROPOSTOS | `VLAB_R215_INTEGRATED_DEFENSE_COUNTER_TEAM_COLD_AUDITED_MESTRE_ONLY.zip` |
| R216 | 19 bancos R18 (17 equipe 2x1 + 2 controle terreno) | 208 commits; 1.258 eventos; 51 movimentos; 153 ataques; 14 curas; 68 magias | 17 cenas 2x1 e 2 controles terreno; 14 quarentenas | `VLAB_R216_INTEGRATED_MULTI_ACTOR_SCIENCE_CONTROL_COLD_AUDITED_MESTRE_ONLY.zip` |
| R217 | 10 cenas R18, 5 pares de ordem | 120 commits; 732 eventos; 90 ataques; 12 curas; 40 magias | permutações reais, nenhum delta terminal nos 5 pares; 14 quarentenas | `VLAB_R217_INITIATIVE_ORDER_PAIR_FAIRNESS_COLD_AUDITED_MESTRE_ONLY.zip` |
| R218 | 33 braços válidos / 48 tentativas; 13 pares completos | 396 commits; 2.452 eventos | iniciativa source-rolled e ordem registrada; 15 bloqueios | `VLAB_R218_SOURCE_ROLLED_INITIATIVE_NEGATIVE_AUDITED_MESTRE_ONLY.zip` |
| R219 | 36 braços válidos / 48 tentativas; 16 pares | 432 commits; 2.636 eventos | Varok ferido de início em TEST; 12 bloqueios | `VLAB_R219_WOUNDED_INITIATIVE_NEGATIVE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R220 | 33 braços válidos / 48 tentativas; 13 pares | 396 commits; 2.410 eventos | suporte/posição mudam decisões; RNG por rodada é confundidor | `VLAB_R220_ORDER_NONCOMMUTATIVE_TIMING_COLD_AUDITED_MESTRE_ONLY.zip` |
| R221 | 33 braços válidos / 48 tentativas; 13 pares | 396 commits; 2.409 eventos | RNG por ocorrência da habilidade; sem delta terminal de PV nos 13 pares | `VLAB_R221_ABILITY_INDEX_RNG_STABLE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R222 | 76 braços válidos / 96 tentativas; 14 quádruplas completas | 912 commits; 5.610 eventos | fatorial iniciativa A/B × RNG por rodada/ocorrência; 20 bloqueios | `VLAB_R222_FACTORIAL_INITIATIVE_RNG_ASSIGNMENT_COLD_AUDITED_MESTRE_ONLY.zip` |
| R223 | 40 execuções válidas de 48 braços TEST | 480 commits; 2.942 eventos; 4 metades ímpares | piso provisório na cópia, antes da confirmação posterior do Mestre | `VLAB_R223_MASTER_TENTATIVE_ODD_HALF_FLOOR_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R224 | 20 seeds pareadas; 38 braços terminais + 2 UNKNOWN | 465 commits; 2.841 eventos | braço piso 20/20 termina; conservador 18/20; duas quarentenas | `VLAB_R224_STRICT_HOLD_VS_TENTATIVE_FLOOR_CAUSAL_PAIRS_COLD_AUDITED_MESTRE_ONLY.zip` |
| R225 | 3 conjurações dirigidas R18 | 3 commits; 3 eventos | decisão expressa de piso; 3 tentativas preliminares em quarentena | `VLAB_R225_MASTER_CONFIRMED_COMBAT_DAMAGE_FLOOR_COLD_AUDITED_MESTRE_ONLY.zip` |
| R226 | 8 seeds pareadas, 16 braços R18 | 32 commits; 174 eventos; 187 PV extras e 154 PA | Manopla Ouro PS semicanônica, não P4; 7 acertos e 1 erro | `VLAB_R226_SEMICANON_ITEM_COMPARISON_SPLIT_DAMAGE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R227 | 6 seeds pareadas, 12 braços R18 | 24 commits; 132 eventos; 4 ataques acertados | RD elétrica 100 zera Raio/lentidão, sem restituição PA; E oficial HOLD | `VLAB_R227_ELECTRIC_RD_ITEM_SLOW_CAUSAL_PAIRS_COLD_AUDITED_MESTRE_ONLY.zip` |
| R228 | 2 ensaios dirigidos R18 | 6 commits; 21 eventos; 4 movimentos | Flecha de Trava e expiração em fixture de 12 m, não velocidade canônica | `VLAB_R228_NATIVE_FLECHA_TIMED_MOVEMENT_COLD_AUDITED_MESTRE_ONLY.zip` |
| R229 | 168 simulações LEGACY originais +168 espelhos | 2.332 eventos de ataque originais | A/B/C básico; corrigido crítico em cópia legado; não R18 | `VLAB_R229_BATTERIES_ABC_LAB_SENSITIVITY_COLD_AUDITED_MESTRE_ONLY.zip` |
| R230 | 5 turnos nativos de Bestas (Bronze–Lendário) | 5 commits; 15 eventos | velocidades pela Regra 8; Bestas virtuais, não espécies P4 | `VLAB_R230_NATIVE_BEAST_SOURCE_SPEED_COLD_AUDITED_MESTRE_ONLY.zip` |
| R231 | mapa documental R91, não combate | 104 posições; 225 snapshots A125/B25/C75 | D 8 candidatas VZ; E PS; 7/7 adulterações rejeitadas | `VLAB_R231_R91_FIVE_BATTERIES_SOURCE_READINESS_COLD_AUDITED_MESTRE_ONLY.zip` |
| R232 | 4 ataques isolados de espécies VZ PRECREATE | 4 commits; 8 eventos; 3 acertos/1 erro | não são 4 combates; sem ficheiro físico completo P4 | `VLAB_R232_VZ_NAMED_BEAST_ATTACK_ACTUATOR_COLD_AUDITED_MESTRE_ONLY.zip` |
| R233 | 200 simulações LEGACY originais +200 espelhos | 100 pares RD on/off; 3.162 ataques originais | 156 PV protegidos em 10/100 pares; nenhum delta encerramento | `VLAB_R233_B25_SOURCE_GRADE_RD_SENSITIVITY_COLD_AUDITED_MESTRE_ONLY.zip` |
| R234 | 8 cenas nativas R18, 4 seeds × solo/equipe | 120 commits; 500 eventos; 120 ataques | 3 Bestas FULLSPEC PRECREATE, 8 censuras, 0 KO | `VLAB_R234_VZ_BEAST_FULL_SOURCE_BILATERAL_TEAM_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R235 | 16 cenas fatoriais R18 +4 casts focais | 196 commits; 816 eventos; 28 conjurações | RD75/0, físico/magia e 3 metades ímpares; política TEST | `VLAB_R235_BEAST_MAGIC_PHYSICAL_RD_FACTORIAL_COLD_AUDITED_MESTRE_ONLY.zip` |
| R236 | 12 cenas R18, 6 seeds×solo/equipe | 59 commits; 264 eventos; 20 ataques em Fraco | Croc TEST começa 95 PV; 12 STOP_HP0 LAB, não morte | `VLAB_R236_VZ_BEAST_WEAK_HP0_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R237 | 8 cenas R18, 4 seeds×solo/equipe | 155 commits; 640 eventos; 8 cruzamentos | Normal→Fraco durante combate; 2 STOP_HP0 LAB +6 censuras | `VLAB_R237_LIVE_FRACO_TRANSITION_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip` |
| R238 | auditoria cruzada/readback; NÃO executa combate | 4 ZIPs R234–R237 CRC+verificadores PASS | R91 A–E cobertura; integridade local PASS, produção HOLD | `VLAB_R238_CROSS_AUDIT_R234_R237_R91_MESTRE_ONLY.zip` |

**Denominadores que NÃO podem ser somados como lutas equivalentes:** braços fatoriais vs seeds independentes; janelas de ataques/ações vs combates R18 de horizonte; LEGACY v0.6.1 vs motor R18/v0.8.1; snapshots virtuais vs ensaios; espelhos de rótulo vs novas amostras; encerramento `STOP_HP0_LAB_ONLY` vs morte/KO oficial; censuras por horizonte vs vitórias. Os totais medidos em cada PSV permanecem únicos de seu escopo.

### Principais resultados científicos testados

1. **R215–R217: integração R18** de ataque, RD, Reação, R50/R51, cura, área e equipe; R216 2×1 com terreno e tática; R217 permutação real de ordem com resultado negativo delimitado. Quarentenas conservadas e auditoria READ-ONLY independente.
2. **R218–R222: causalidade de iniciativa/RNG.** 288 braços tentados, 211 válidos, 77 bloqueados; 2.532 commits e 15.517 eventos; todos censurados. R222 14 quádruplas completas: alterações de iniciativa e do mapeamento RNG não são intercambiáveis; seed 22288014 mostra diferença por ordem sob dois mapeamentos. Empate de iniciativa ainda bloqueado.
3. **R223–R225: arredondamento.** Com orientação ainda provisória, R223 testou `floor(61/2)=30`. R224 comparou 20 pares, identificando duas interrupções no braço que exigia norma; depois o Mestre CONFIRMOU: **em ataques/dano de qualquer tipo cuja regra exija arredondamento, usar o inteiro inferior**. R225 reproduziu o comportamento com a decisão já expressa. **TAP/BAP conserva sua regra de carry** na Transformação; não aplicar piso genericamente para destruir acúmulo fracionário expresso.
4. **R226–R228: item e movimento.** Manopla Ouro PS com/sem Raio (+187 PV em oito pares condicionais), RD elétrica 0/100 sem devolver PA e Flecha de Trava reduzindo velocidade no movimento nativo; itens/NPCs PS ou propostas não viram P4.
5. **R229–R233: cinco baterias.** Correção de crítico positivo em clone LEGACY; 368 simulações originais LEGACY e 368 espelhos não independentes; nove turnos nativos R18; 225 snapshots A125/B25/C75; quatro ataques de espécies VZ; 100 pares B25 de RD em LEGACY com 156 PV agregados protegidos, sem desfecho terminal modificado nesta fixture.
6. **R234–R237: Bestas PRECREATE com ficha mecânica completa, mas sem P4.** Três Bestas (Grifo-Matriarca, Roc e Crocodilo Ancião L3) tiveram 1×1/2×1 nativos, ataque/dano, fonte de velocidade, RD, Física×Magia, saves, Fraco e HP0 LAB. R234 8 cenas censuradas; R235 fatorial 16 cenas+4 casts; R236 12 terminais HP0 LAB a partir de Crocodilo previamente ferido; R237 oito cenas com transição Normal→Fraco causada durante combate. Não comprova P4, linha multialvo plena, nem políticas universais.
7. **R238:** auditoria cruzada dos 4 pacotes, CSV R91, sem novos combates, sem alteração produtiva; recuperações frias reportadas PASS. A documentação mantém o recorte experimental e o déficit de fontes.

## 4. Cinco baterias R91: progresso, elegibilidade e lacunas reais

| Bateria | O que existe de fato | O que falta para admitir/completar |
|---|---|---|
| **A — Espiritualistas Demoníacos** | Orc ED-REF-01/duelos básicos, snapshots virtuais A125, R229 LEGACY e participação B25 | Arquétipos completos por nível/rank, atributo/perícia/Alma/PA e integração LEVEL-UP livre de discrepância; benchmarks R18 e incerteza |
| **B — Linhagem de Besta** | Regra 8 calcula velocidades; R230 cinco níveis nativos, R233 25 tiers LEGACY, R234–R237 Bestas PRECREATE L3 multi-turno | 25 regulares + ADM/Divina como **2 coortes especiais**, sem inventar novo rank; fichas P4, habilidades reais e cobertura de níveis |
| **C — Equipe** | R216/217 2×1 suporte e defesa, R234/236/237 2×1 de Bestas PRECREATE; C75 snapshots virtuais | Formações ED 2–5 por patamar, sinergia real, alvo, Reação, cura, geometria e adversários homologados |
| **D — Espécies distintas** | 8 candidatas VZ; R232 quatro ataques isolados; R234–R237 três Bestas fonte-completas PRECREATE | Painel diverso por rank com páginas físicas P4 e stats/skills completos; 4 ataques isolados ≠ 4 lutas completas |
| **E — Contribuição de equipamento** | R226/227 Manopla PS, R235 fatorial ataque físico×magia de Besta; inspeção Espada do Lendário/Mangual | **Item P4** com CHASSI FÍSICO idêntico nos braços COM/SEM magia, fonte do encantamento/PA/rank compatíveis, auditoria de split físico×mágico; nenhum E oficial |

**Cuidado:** `A125+B25+C75=225` snapshots documentais NÃO preenchem as 104 posições oficiais. `104` é desenho R91, `1.875` são células oficiais de confrontos, e `17` são contratos terminais distintos; três denominadores independentes.

## 5. Decisões de autoridade e fronteiras

- **CONFIRMADA PELO MESTRE:** arredondamento para baixo quando o cálculo de efeito de ataque/dano exigir um inteiro. Física, magia, elemento; mantém exceção operacional de carry quando a regra especializada assim especifica. A página canônica de normas ainda não recebeu esta edição nesta operação.
- **CONFIRMADAS PELO MESTRE:** crítico positivo acerta automaticamente mas RD pode zerar dano; desempate contra ataque em favor da defesa; R50 resposta só se ataque normal errou; R51 sem encadear contra-ataques; afastamento seguro usa Padrão + Movimento e movimento forçado não gera AoO; empurrão 1,5m/300 FF.
- **FONTE PRIMÁRIA e limites:** Sistema de Combate (https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0), Criação de Besta (https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd), BEAST-FULLSPEC-VZ-06 (https://app.notion.com/p/3f3c2b324ede813987deda0b382e83c7), Transformação Espiritual (https://app.notion.com/p/3f2c2b324ede81c0ae0ee4e66212edc9), plano R91 (https://app.notion.com/p/3f3c2b324ede81d480dbf11732734463). PRECREATE/PS ≠ P4. Exemplo Manopla (https://app.notion.com/p/3f5c2b324ede81f5ac62fb940204cdac); Flecha de Trava (https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966).
- **INFERIDO, NÃO VERIFICADO:** nenhuma independência de writer/INSTANCE-ID, nenhum ACK final de DMG/LEVEL-UP, nenhuma promoção das fichas VZ, nenhuma regra de desempate da iniciativa, nem de crítico negativo, nem de bloco↔metro. Sem tais provas, permanecer em HOLD.
- **Fronteira:** não escrever em Party/O Primeiro; não introduzir logs de auditoria nas fichas de jogo; não atualizar DMG, LEVEL-UP, cadastro de Bestas ou R91 oficial por conversão de dados TEST; não assumir writer/lease/epoch/fencing/GREEN por ler uma página.

## 6. Pendências ordenadas e critérios de conclusão

Cada tarefa abaixo possui ID e critério discriminante; a planilha `VLAB_PENDENCIAS_R238.csv` é o quadro de trabalho em formato legível por máquina, não motor concorrente.

| ID | Prioridade | Situação pendente | Gate mínimo |
|---|---|---|---|
| `GOV-001` | P0 | Confirmar writer/INSTANCE-ID/lease/epoch/fencing para a documentação Notion da OP | claim de writer verificado + collision check + reabertura; nunca takeover presumido |
| `DOC-002` | P0 | Sincronizar registro integral Biblioteca→OP/Diário sob writer competente | bloco documental aditivo no objeto existente, readback, sem logs nas fichas |
| `NORM-003` | P0 | Propagar decisão do Mestre de arredondar dano/efeito de ataque para baixo | norma consolidada + testes adversariais + fontes reabertas, sem alterar carry de Transformação |
| `NORM-004` | P0 | Determinar desempate oficial da iniciativa | regra fonte-completa; testes de empate novos; R218–R222 não reexecutadas |
| `NORM-005` | P0 | Resolver crítico negativo no motor nativo sem política LAB-only | regressão independente com fonte e evento causal |
| `GEO-006` | P1 | Determinar equivalência bloco↔metros, diagonais, AoO e movimento interrompido por HP0 | fonte fechada e 4+ fixtures discriminantes sem inventar raio |
| `TERM-007` | P0 | Certificar os 17 contratos terminais originais, sem atalhos | 17/17 provas integrais com replay/RNG/event sourcing/safety/independência |
| `R91-008` | P0 | Preencher legitimamente matriz oficial 1.875 células | amostras admissíveis com evidência e intervalos; jamais converter TEST em oficial |
| `A-009` | P1 | Validar ED-source completos por 25 patamares e múltiplos arquétipos | atributos/reservas/fichas e fontes válidas, seeds e auditoria R18 |
| `B-010` | P1 | Bestas de linhagem 25 patamares + 2 coortes ADM/Divina | fontes completas por tier, luta multi-turno, sem inventar ranks |
| `C-011` | P1 | Equipe ED de 2–5 com cura, Reação, controle e formações | formações distintas e integração bilateral com intervalos e economia de ações |
| `D-012` | P1 | Painel 27 Bestas distintas P4 sem substituir por snapshots PRECREATE | 27 candidatos admissíveis com simulação e incerteza; 4 ataques isolados não valem |
| `E-013` | P1 | Achar item P4 com chassi físico e magia separáveis | pares COM/SEM sob mesma base com controle do elemento e RD; zero E homologada |
| `SRC-014` | P1 | Materializar/verificar proveniência P4 de Bestas FULLSPEC-VZ-06 | ficha física aprovada, hashes do corpo real, relações e status corretos |
| `CTL-015` | P1 | Fonte integral para Controle de Besta: duração, oposição, escape, custo, alvo | primeiro efeito fonte-fechado numa cena R18; sem inventar duração |
| `TRF-016` | P1 | Transformação Demoníaca ED Prata1+ com Espírito e Besta reais | normal↔transformado com recursos/carry e regressão, sem fórmula inventada |
| `HP-017` | P1 | Resolver HP0, Fraco e Esforço Final em parada oficial | terminação nativa fonte-admissível, sem declarar morte automática |
| `MAG-018` | P1 | Habilidades mágicas de área/linha com geometria e RD aplicável | largura, cobertura, aliados, LoS, reações, salva, split física/mágica |
| `INBOX-019` | P1 | Conferir IBX-125 Orc↔LEVEL-UP e IBX-126 VLAB↔DMG sem duplicar | roteamento real, recibos de leitura/ACK legítimos e reconciliação |
| `LVL-020` | P1 | Resolver Orc B1→B2 Vida 37 vs39 e rebase B5→P1 ausente | prévia e execução em TEST após validação; não gravar em fichas Party |
| `SCI-021` | P2 | Consolidar estatística com seeds como unidade e censura explícita | intervalos, overkill vs Vida retirada, controles de RNG, efeitos e limites |
| `SCI-022` | P2 | Revisar fim de horizonte, economia, escala N×M e one-shot de equipe | pilotos progressivos, sem 10×10/20×20 declarados por simulação sintética |
| `XINT-023` | P1 | Repassar descobertas DMG/LEVEL-UP pela rota competente | remessa sem duplicata, com responsável final, readback e ACK verificável |
| `SRC-024` | P1 | Conferir snapshot fonte integral Eristan/Iskiel/Varok e carga de itens | proveniência por página primária fechada e efeito explícito |
| `CERT-025` | P0 | NAC-PASS-02 global, produção e fusão terminal | PASS terminal competente; não autoatribuir GREEN |

## 7. Quarentenas e problemas técnicos ainda não apagáveis

- R215/R217: metade ímpar inicialmente `UNKNOWN-EFFECT`; decisão posterior permite **novas** execuções com piso, mas bancos originais não são regravados/reexecutados. R217 14 quarentenas por dados de cena incoerentes e efeitos desconhecidos.
- R218–R222: empates de iniciativa bloqueados **antes do primeiro commit**; R222 18 ties e dois half-odd UNKNOWN dentre 20 bloqueados; seleção estatística por admissão impede extrapolação.
- R219: bug da **cópia do auditor** em precedência do crítico negativo corrigido sem alterar motor. R220 RNG por rodada confundia análise da iniciativa; R221/R222 separaram fatores; não retcon de R220.
- R223–R224: comparadores conservadores em `UNKNOWN-EFFECT` mantidos com intents; não imputar Vida terminal. R228: comando preliminar recusado preservado. R229: coorte anterior com horizonte indevido e bug legado de crítico preservada em quarentena; a correção em clone não promoveu motor produtivo.
- R230: reconstrução de `CA` racional exigiu reparo de serialização em clone, com `UNKNOWN-EFFECT` antigo preservado. R232: ensaio preliminar sem commit preservado. R236: `STOP_HP0_LAB_ONLY` é fim do modelo TEST, não uma morte/KO canônica. R237: não forçar identidade de fitas completas quando a condição Fraco muda o número de rolagens.
- **R59:** incidente histórico `LAB-CMD-R59-FAULT-FIRST-ONE` NO-RETRY. Todos os conjuntos históricos consumidos continuam `NO-REPEAT` salvo experimento NOVO previamente registrado e com seeds inéditas.

## 8. Interoperabilidade e mensagens

- `IBX-125` (Orc Bronze→LEVEL-UP) e `IBX-126` (VLAB→DMG) foram publicadas pela Coordenação, mas o destinatário nativo estava `CM-000001`; recebedor final e ACK/READ permanecem **não comprovados** nos dossiês consultados. Não criar duplicatas nem marcar ACK.
- `IBX-138` diretriz de encaminhamento integral foi adotada no trabalho; permanecia `NOVA` sem INSTANCE-ID para ACK no checkpoint R215. Não atualizar status retrospectivamente sem nova prova.
- R207 havia mostrado divergência de Vida Orc B1→B2 (37 vs 39) e rebase B5→P1 ausente; responsável LEVEL-UP. Evidências DMG R215–R238 devem ser encaminhadas por rota competente quando verificada, sem autoremediar rank, item ou ficha real.

## 9. Pontos de retomada (sem repetir)

**FIRST-PENDING imediato após R238:**

1. Confirmar que **R239 não existe** na pasta da operação; reler fontes e pre-reg novas seeds, SEM reusar R01–R238 ou seus bancos em quarentena.
2. Escolher ação executável de maior retorno: (a) localizar Besta **P4** com defesa/ataque/recursos/velocidade/condições completos para B/D; ou (b) localizar **item P4** com físico+magia separados para E; ou (c) fechar controle de Besta com duração e escape se fonte suficiente. Não preencher missingness com ficção.
3. Se nenhuma fonte P4 elegível, executar apenas cenário explicitamente PRECREATE/TEST com política e geometria fonte-gated, registrar o motivo de inadmissibilidade à matriz oficial e seguir outras pendências independentes.
4. Consolidar novo lote com pré-reg e validadores independentes, hashes R18, leitura fria Library, `ANTES → ALTERAÇÃO → DEPOIS` e checkpoint sem atribuir NAC-PASS global.
5. Para escrever no Notion OP/Diário ou normas, obter o **writer real**/Assignment/claim e fluxo NAC-CONT-03; depois acrescentar este índice ao objeto existente, reabrir e conferir, sem criar página nova ou alterar fichas. Qualquer atualização normativa exige NAC-NORM-01 adicional.

**LAST-VERIFIED-UNIT:** R238, recuperação fria R234–R237 + R91 mapa; para esta entrega, a nova cópia Library do registro deverá ser reaberta e hash verificado separadamente. **FIRST-PENDING:** R239 candidato; governança documental `GOV-001/DOC-002` continua HOLD para Notion. **NO-REPEAT:** todo R01–R238 e arquivos em quarentena; **NO-WRITE:** Party/O Primeiro/fichas/produção/normas/matriz. **NAC-PASS-02 global:** HOLD.

## 10. Inventário de fontes e localização persistente

- Operação principal Notion: https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2; identidade CM-000006: https://app.notion.com/p/3f4c2b324ede81ff865ff17b0491301a; bootstrap/Kit: https://app.notion.com/p/3edc2b324ede81d0b25ec2f3be128db6.
- Biblioteca Mestre ÚNICA: `/Comestre/OP-VLAB-FUSION-SANDBOX-01/`. Cada ZIP listado no quadro da seção 3 está nessa pasta; relatórios de R216–R217, R218–R222, R225–R228, R229–R233 e R238 já foram publicados separadamente.
- Fontes do R91: https://app.notion.com/p/3f3c2b324ede81d480dbf11732734463; combate: https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0; bestas: https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd; VZ: https://app.notion.com/p/3f3c2b324ede813987deda0b382e83c7.
- Este relatório não materializa todos os ZIPs novamente, nem afirma revalidação de cada hash R01–R214 nesta execução; liga evidência já existente por nomes exatos e fonte.
