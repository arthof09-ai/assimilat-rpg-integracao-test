#!/usr/bin/env python3
"""Verificação READ-ONLY do pacote documental VLAB até R238; não executa combates."""
from pathlib import Path
import csv, hashlib, json, sys
p=Path(__file__).resolve().parent
m=json.loads((p/'VLAB_REGISTRO_R238_SHA256_MANIFEST.json').read_text('utf-8'))
for name,info in m['files'].items():
    f=p/name
    assert f.is_file(), f'FALTA {name}'
    assert f.stat().st_size==info['size_bytes'], f'TAMANHO {name}'
    assert hashlib.sha256(f.read_bytes()).hexdigest()==info['sha256'], f'SHA {name}'
s=json.loads((p/'VLAB_ESTADO_RECUPERAVEL_R238_MESTRE_ONLY.json').read_text('utf-8'))
assert [x['r'] for x in s['checkpoints']]==list(range(215,239))
assert s['terminal_contracts_certified']==0 and s['official_cells_certified']==0
assert s['last_verified_unit']=='R238'
assert s['notion_update']=='NOT_PERFORMED'
with (p/'VLAB_PENDENCIAS_PRIORIZADAS_R238_MESTRE_ONLY.csv').open(encoding='utf-8',newline='') as f:
    tasks=list(csv.DictReader(f))
assert len(tasks)==25 and len(set(x['id'] for x in tasks))==25
print('PASS DOCUMENTARY READ-ONLY: files=',len(m['files']),'checkpoints=24 tasks=25; no replay/no writes')
