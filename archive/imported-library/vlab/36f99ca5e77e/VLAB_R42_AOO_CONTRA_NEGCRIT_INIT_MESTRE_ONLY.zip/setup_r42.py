from pathlib import Path
import shutil,zipfile
R=Path('/mnt/data/vlab_r42/work');rt=R/'runtime_copy';rt.mkdir(exist_ok=True)
for n in ('run_r35_native.py','run_r36_dodge.py'):
 shutil.copy2(R/'r36'/n,rt/n)
(rt/'extension').mkdir(exist_ok=True);(rt/'authority').mkdir(exist_ok=True)
shutil.copy2(R/'r35/extension/vlab_r31_real_source_gateway.py',rt/'extension/vlab_r31_real_source_gateway.py')
for p in (R/'r36/authority').glob('*.json'):shutil.copy2(p,rt/'authority'/p.name)
with zipfile.ZipFile('/mnt/data/vlab_r42/input/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip') as z:
 for n in z.namelist():
  if (n.startswith('fusion_stage12/') or n.startswith('working/historical_v081_verified_original/comestre_vlab/')) and n.endswith(('.py','.json')):
   p=rt/'r27'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
  if n.startswith('working/historical_v081_verified_original/comestre_vlab/') and n.endswith('.py'):
   p=rt/n.rsplit('/',1)[-1];p.write_bytes(z.read(n))
print('runtime files',len(list(rt.rglob('*.py'))))
