"""Exact Markov recursion for idealized symmetric Goat B1 vs Goat B1 with persistent ESQUIVAR.
Only valid under p_crit=1/108 per opportunity, independent uniform damage d6, no other hit,
negative critical misses, both continue and can always reestablish adjacency. Not canon.
No combat engine imports; does not infer experimental RNG statistical qualities.
"""
from functools import lru_cache
from pathlib import Path
import json,math
P=1/108;Q=1-P
@lru_cache(None)
def calc(hpa,hpb):
 if hpa<=0:return (0.,0.,0.,0.)
 if hpb<=0:return (0.,0.,1.,1.)
 x_e=x_p=0.
 for d in range(15,21):
  if hpb>d:
   _,eb,_,pb=calc(hpa,hpb-d)
   x_e+=P/6*eb;x_p+=P/6*pb
  elif hpb<=d:x_p+=P/6
 y_e=y_p=0.
 for d in range(15,21):
  if hpa>d:
   ea,_,pa,_=calc(hpa-d,hpb)
   y_e+=P/6*ea;y_p+=P/6*pa
 # A attacks first, B attacks second. E_A / E_B expected number of future attacks.
 denom=1-Q*Q
 ea=(1+Q+x_e+Q*y_e)/denom
 eb=1+Q*ea+y_e
 pa=(x_p+Q*y_p)/denom
 pb=Q*pa+y_p
 return ea,eb,pa,pb

def run():
 ea,eb,pa,pb=calc(38,38)
 a=[]
 for n in (100,200,260,308,360,500,1000):a.append({'attempts':n,'P_no_positive_crit':Q**n,'E_positive_crits':n*P})
 out={'p_positive_critical_per_valid_sequential_3d6':P,'p_negative':P,'hit_only_by_positive_under_continuous_ESQUIVAR_26':True,'positive_critical_net_damage_uniform_inclusive':[15,20],'E_positive_crits_needed_to_KO_one_full_HP38_target':17/6,'E_attacks_to_reach_target_KO_for_one_fixed_attacker':306.0,'sym_duel_first_actor_expected_total_attack_opportunities':ea,'second_actor_expected_attack_opportunities_if_B_next':eb,'first_actor_win_probability_under_model':pa,'B_win_probability_under_model':1-pa,'probability_A_win_if_B_to_move':pb,'condition':'Ideal iid model; assumes both have enough Movement for all pushes, successful chance per opportunity independent, negative critical no other penalty, no environmental restrictions, no initiative bonuses beyond common cancel, no max horizon','diagnostics_by_attacks':a,'source':'Mestre positive/negative critical LAB decisions and goat action; independent math oracle only','not_a_empirical_win_rate':True}
 p=Path('/mnt/data/vlab_r42/work/evidence/R42_IID_LONG_DUEL_MATHEMATICAL_ORACLE.json');p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:out[k] for k in ['sym_duel_first_actor_expected_total_attack_opportunities','first_actor_win_probability_under_model','E_positive_crits_needed_to_KO_one_full_HP38_target']},indent=2))
 return out
if __name__=='__main__':run()
