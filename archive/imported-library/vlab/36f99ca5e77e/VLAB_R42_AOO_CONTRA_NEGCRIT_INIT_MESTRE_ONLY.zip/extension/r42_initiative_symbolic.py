"""R42: demonstrate relative R26 initiative invariance under a common unknown bonus.
No claim that zero is the true Initiative stat. Read-only cloned R26 scenes.
"""
from __future__ import annotations
import json,copy,sys,hashlib
from pathlib import Path
R=Path('/mnt/data/vlab_r42/work');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r42_long_duel_core as h
j=h.j
BONUSES=[-20,-6,-1,0,6,12,30]
SEEDS=[95101,95102,95103,95104,95105,95106,95107,95108,95109,95110,95111,95112,95113,95114,95115,95116]

def run():
 results=[]
 for seed in SEEDS:
  before=h.make_state(j.initial('A',seed),seed)
  trials=[]
  for common in BONUSES:
   state=copy.deepcopy(before)
   for a in h.IDS:
    state['actors'][a]['stats']['init_bonus']=common
   r=h.r26.resolve_initial_state(state)
   roll={x['id']:(x['dice'],x['des'],x['total']-common) for x in r['rolls']}
   tie=[(x['only_tied'],sorted((z['id'],z['roll_total']-common) for z in x['draws'])) for x in r['tie_resolution']['rerolls']]
   trials.append({'bonus':common,'order':r['order'],'normalized_rolls':roll,'normalized_tie':tie})
  baseline=trials[0]
  assert all(t['order']==baseline['order'] and t['normalized_rolls']==baseline['normalized_rolls'] and t['normalized_tie']==baseline['normalized_tie'] for t in trials)
  results.append({'seed':seed,'order':baseline['order'],'initiative_die':{a:baseline['normalized_rolls'][a][0] for a in h.IDS},'tie_reroll_count':len(baseline['normalized_tie']),'common_bonus_range_tested':BONUSES})
 out={'result':'PASS','semantics':'Given same source sheet and same unknown fixed numeric initiative bonus B for both identical instances, adding B to all totals and tied re-roll totals cannot change R26 relative order. This DOES NOT determine actual B.','seeds':SEEDS,'bonus_representatives':BONUSES,'cases':len(results)*len(BONUSES),'ties':sum(r['tie_reroll_count']>0 for r in results),'results':results,'canonic_bonus':None,'notion_goat_source':'391c2b32-4ede-8252-b0cc-810423cdbfa6','rule':'R26 DEX then reroll only tied'}
 (R/'evidence/R42_INITIATIVE_COMMON_UNKNOWN_BONUS_INVARIANCE.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:out[k] for k in ('result','cases','ties','canonic_bonus')},ensure_ascii=False))
 return out
if __name__=='__main__':run()
