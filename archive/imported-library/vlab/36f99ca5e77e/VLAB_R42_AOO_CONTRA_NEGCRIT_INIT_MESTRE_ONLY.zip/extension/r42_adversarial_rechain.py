"""R42 independent adversarial mutation: reconstruct valid SQLite hash chains around
mechanically wrong negative-critical events; require independent oracle detection.
Source is a portable lab checkpoint; only temporary copies are edited.
"""
from __future__ import annotations
import json,hashlib,sqlite3,tempfile,shutil,subprocess,sys
from pathlib import Path
R=Path('/mnt/data/vlab_r42/work')
SOURCE=R/'checkpoints/CHECKPOINT_R42_LONG_NEGATIVE_POLICY_OBSERVATION_H130_SEED95101.sqlite'
AUDIT=R/'extension/verify_r42_duel_standalone.py'
def J(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def H(x):return hashlib.sha256(J(x).encode()).hexdigest()

def mutate(row,case):
 d=row['detail'];n=d['native_attack']
 if case=='FAKE_NEGATIVE_HIT':n['hit']=True
 elif case=='FAKE_DAMAGE_ON_NEGATIVE':n['net']=17
 elif case=='FAKE_ACTION_RESOURCE_DELTA':n['actor_pa_before_after']=[22,21]
 elif case=='FAKE_RNG_CRIT_TAPE':d['RNG']['critical_dice']=[6,6,5];row['payload']['tape']['critical_dice']=[6,6,5]
 elif case=='FAKE_CRIT_STATUS':n['r41_critical_status']='NONE'
 else:raise ValueError(case)

def execute():
 cases=['FAKE_NEGATIVE_HIT','FAKE_DAMAGE_ON_NEGATIVE','FAKE_ACTION_RESOURCE_DELTA','FAKE_RNG_CRIT_TAPE','FAKE_CRIT_STATUS'];results=[]
 for case in cases:
  with tempfile.TemporaryDirectory(prefix='r42_rechain_') as d:
   p=Path(d)/'mutated.sqlite';shutil.copy2(SOURCE,p)
   con=sqlite3.connect(p)
   meta=dict(con.execute('SELECT key,value FROM meta'));head=meta['genesis'];targetseq=None
   records=con.execute('SELECT seq,row_json FROM events ORDER BY seq').fetchall()
   con.execute('BEGIN IMMEDIATE')
   for seq,text in records:
    row=json.loads(text)
    if row['kind']=='R42_LONG_TURN' and row['detail']['RNG']['critical_negative'] and targetseq is None:
     targetseq=seq;mutate(row,case)
    row['prev']=head
    digest=H(row);con.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(head,J(row),digest,seq))
    head=digest
   con.execute("UPDATE meta SET value=? WHERE key='head'",(head,));con.commit();con.close()
   assert targetseq is not None
   # Structural R18 reopens valid chain, but should not certify mechanics.
   sys.path[:0]=[str(R/'runtime_copy/r27/fusion_stage12'),str(R/'runtime_copy')]
   import vlab_r18_interactive as j
   st,h,revision=j.load(p)
   assert revision==len(records) and h==head
   run=subprocess.run([sys.executable,str(AUDIT),str(p)],capture_output=True,text=True,timeout=30)
   assert run.returncode!=0 and 'AUDIT_FAIL' in run.stderr,case+': '+run.stderr
   results.append({'case':case,'modified_seq':targetseq,'structural_R18':'ACCEPTS_REHASHED_INTEGRITY','mechanical_external':'REJECTS','detected':run.stderr.strip().splitlines()[0]})
 out={'schema':'R42_RECHAINED_ADVERSARIAL_INDEPENDENCE','cases':len(results),'status':'PASS','results':results,'source_checkpoint':SOURCE.name,'changed_originals':0,'temporary_only':True,'lesson':'A structurally valid ledger can still represent mechanically impossible negative-critical behavior.'}
 (R/'evidence/R42_RECHAINED_ADVERSARIAL_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':'PASS','mutations':len(results),'R18_structure':'PASSED_EACH','mechanical':'REJECTED_EACH'}))
 return out
if __name__=='__main__':execute()
