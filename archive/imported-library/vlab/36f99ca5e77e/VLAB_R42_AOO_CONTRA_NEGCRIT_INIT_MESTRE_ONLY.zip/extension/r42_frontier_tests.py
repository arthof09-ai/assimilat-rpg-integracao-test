"""R42 narrow gates: concurrent AoO, Counter-atacar normal-Luta, and negative critical.
No canonical actions produced. Fixtures/geometry tests are labelled SYNTHETIC.
No invented priority, Luta value or initiative stat.
"""
from __future__ import annotations
import json,math,sys,copy
from pathlib import Path
R=Path('/mnt/data/vlab_r42/work');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
from r42_critical_bridge import apply_source_attack,ordered_critical
from vlab_effects_v08 import Scene,Combatant
from vlab_action_catalog_v01 import ActorActionState
from vlab_rd_v08 import Resistances
import r42_long_duel_core as g
S={};COUNT=0

def ok(name,value,notes):
 global COUNT
 COUNT+=1;S[name]={'status':'PASS' if bool(value) else 'FAIL','detail':notes,'domain':'SYNTHETIC_ADVERSARIAL_GATE' if name.startswith(('AO_','COUNTER_')) else 'LAB_MECHANICAL_DIRECTED_FIXTURE'}
 assert value, name

def geometry_aao(source='VOLUNTARY',safe_against=None,reactions=None,destination=(-1.5,-1.5)):
 if reactions is None:reactions={'B':1,'C':1}
 actor=(0.,0.);enemies={'B':(1.5,0.),'C':(0.,1.5)}
 triggers=[]
 for name,pos in enemies.items():
  d_before=math.dist(actor,pos);d_after=math.dist(destination,pos)
  if source=='VOLUNTARY' and d_before<=1.5000001 and d_after>1.5000001 and reactions[name]==1 and safe_against!=name:
   triggers.append({'actor':name,'trigger':'VOLUNTARY_EXIT_FROM_ADJACENT_BLOCK','reaction_slot':1,'source':'SISTEMA_COMBATE_RULE3_AOO','attack_normal_luta':None,'attack_advantage':1})
 if len(triggers)>1:return {'status':'BLOCKED_NORMATIVE_PRECEDENCE','triggers':triggers,'actor_moved':False,'reaction_consumed':0,'events_published':0,'world_effects':0}
 if triggers:return {'status':'TRIGGER_CONFIRMED_DAMAGE_BLOCKED_SOURCE_NORMAL_LUTA','triggers':triggers,'actor_moved':False,'reaction_consumed':0,'events_published':0,'world_effects':0}
 return {'status':'NO_OPPORTUNITY_TRIGGERS','triggers':[],'actor_moved':True,'reaction_consumed':0,'events_published':0,'world_effects':0}

def counter_gate(incoming,ca,has_slot,normal_luta=None,source='GOAT_BRONZE1'):
 if incoming>ca:return {'status':'NO_COUNTER_ATTACK_CA_TRIGGER','spent':0,'events':0}
 if not has_slot:return {'status':'BLOCKED_NO_REACTION_SLOT','spent':0,'events':0}
 if normal_luta is None:return {'status':'BLOCKED_SOURCE_NORMAL_LUTA_UNDOCUMENTED','spent':0,'events':0,'unknown_field':'LUTA_FOR_NORMAL_ATTACK_NOT_THE_INVESTIDA_ABILITY','advantage_dice':'2d6_KEEP_BEST_AND_BONUS_2','source':source}
 if source!='SYNTHETIC':return {'status':'UNAUTHORIZED_FICTITIOUS_LUTA','spent':0,'events':0}
 # Purely mathematical fixture: no native real-source action, no state commit.
 return {'status':'SYNTHETIC_MATH_ONLY','spent':0,'events':0,'value_for_2d6_5_6':13+normal_luta+max(5,6)+2,'actual_goat_training':None}

def negative_case(crit,attack_die=6,damage_die=6):
 a,t='R42-FIXTURE-A','R42-FIXTURE-B'
 sn=Scene({a:Combatant(a,38,22,20,10,None,None,6,'LAB-A'),t:Combatant(t,38,22,20,10,None,None,6,'LAB-B')},seed=0,provenance='SYNTHETIC_R42_EXPLICIT_MASTER_CHAT_LAB_POLICY')
 src=g.b.native_source();proof=g.b.proof('MIRROR')
 st=ActorActionState(actor_id=a,ordinal_level=1,available_pa=22,known_action_ids=(g.b.GO_ACTION,),standard_available=True,reaction_available=True,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(t,))
 out=apply_source_attack(sn,a,t,source=src,state=st,proofs=(proof,),attack_die=attack_die,damage_die=damage_die,critical_dice=crit,force=13,luta=6,rd=Resistances(general=5,specific=(),provenance='SYNTHETIC_BRONZE_RD5'),strict=True)
 return out,sn

def run():
 d=geometry_aao();ok('AO_TWO_DISTINCT_ENEMIES_CONCURRENT_REACHABLE',d['status']=='BLOCKED_NORMATIVE_PRECEDENCE' and len(d['triggers'])==2 and d['events_published']==0 and d['reaction_consumed']==0,d)
 x=geometry_aao(safe_against='B');ok('AO_SAFE_WITH_ONE_LEAVES_ONE',x['status']=='TRIGGER_CONFIRMED_DAMAGE_BLOCKED_SOURCE_NORMAL_LUTA' and [v['actor'] for v in x['triggers']]==['C'],x)
 x=geometry_aao(source='FORCED');ok('AO_FORCED_PUSH_NOT_AOO',x['status']=='NO_OPPORTUNITY_TRIGGERS',x)
 x=geometry_aao(reactions={'B':0,'C':1});ok('AO_SPENT_B_REACTION_IGNORED',len(x['triggers'])==1 and x['triggers'][0]['actor']=='C',x)
 x=geometry_aao(destination=(0.,0.));ok('AO_STAY_ADJACENT_NO_TRIGGER',len(x['triggers'])==0,x)
 x=geometry_aao(reactions={'B':0,'C':0});ok('AO_NO_SLOTS_NO_TRIGGER',len(x['triggers'])==0,x)
 c=counter_gate(20,20,True);ok('COUNTER_CA_TIE_TRIGGER_BLOCK_NORMAL_LUTA',c['status']=='BLOCKED_SOURCE_NORMAL_LUTA_UNDOCUMENTED',c)
 c=counter_gate(21,20,True);ok('COUNTER_ABOVE_CA_NO_TRIGGER',c['status']=='NO_COUNTER_ATTACK_CA_TRIGGER',c)
 c=counter_gate(20,20,False);ok('COUNTER_NO_SLOT_REJECTED',c['status']=='BLOCKED_NO_REACTION_SLOT',c)
 c=counter_gate(20,20,True,normal_luta=0,source='GOAT_BRONZE1');ok('COUNTER_NO_SYNTHETIC_TRAINING_FOR_REAL_GOAT',c['status']=='UNAUTHORIZED_FICTITIOUS_LUTA',c)
 c=counter_gate(20,20,True,normal_luta=0,source='SYNTHETIC');ok('COUNTER_MATH_LUTA_ZERO_FIXTURE_ONLY',c['status']=='SYNTHETIC_MATH_ONLY' and c['value_for_2d6_5_6']==21,c)
 c=counter_gate(20,20,True,normal_luta=6,source='SYNTHETIC');ok('COUNTER_MATH_LUTA_SIX_FIXTURE_ONLY',c['value_for_2d6_5_6']==27,c)
 for crit in ((1,1,1),(1,1,2)):
  out,sn=negative_case(crit)
  ok('NEGATIVE_'+''.join(map(str,crit))+'_ACTION_SPENT_NO_PENALTY',out['hit'] is False and out['net']==0 and out['before_hp']==out['after_hp']==38 and sn.actors['R42-FIXTURE-A'].standard==0 and sn.actors['R42-FIXTURE-A'].pa==22 and sn.actors['R42-FIXTURE-A'].hp==38 and out['r41_critical_status']=='NEGATIVE',{'crit':crit,'action_spent':True,'net':out['net'],'target_hp':out['after_hp'],'attacker_hp':sn.actors['R42-FIXTURE-A'].hp,'pa':sn.actors['R42-FIXTURE-A'].pa,'source':'MESTRE_EXPLICIT_PRIOR_CHAT_LAB_POLICY_ONLY'})
 out,sn=negative_case((1,1,2),attack_die=6)
 ok('NEGATIVE_OVERRIDES_NORMALLY_SUFFICIENT_SCORE',out['roll_score']==25 and not out['hit'] and out['net']==0,{'score':out['roll_score'],'hit':out['hit'],'source':'MASTER_LAB_POLICY'})
 out,sn=negative_case((6,6,5),attack_die=1,damage_die=4)
 ok('POSITIVE_CRIT_R41_REGRESSION',out['hit'] and out['r41_positive_auto_hit'] and out['net']==18 and out['after_hp']==20,{'hit_score':out['roll_score'],'critical':'665','net':out['net'],'HP':out['after_hp']})
 out={'result':'PASS','checks':COUNT,'results':S,'source':'Notion current Combat System and Goat B1 + historical user Mestre chat for negative policy','no_real_counterattack_execution':True,'no_real_AoO_damage_execution':True,'no_authority_promotion':True}
 path=R/'evidence/R42_FOUR_FRONTIERS_DIRECTED_TESTS.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':'PASS','checks':COUNT,'AoO':'TWO_TRIGGERS_REACHABLE_PRIORITY_PENDING','counter':'SOURCE_LUTA_MISSING','negative_crit':'TWO_SEQUENCES_EXECUTED','initiative':'SEE_SEPARATE_COMMON_BONUS_PROOF'},ensure_ascii=False))
 return out
if __name__=='__main__':run()
