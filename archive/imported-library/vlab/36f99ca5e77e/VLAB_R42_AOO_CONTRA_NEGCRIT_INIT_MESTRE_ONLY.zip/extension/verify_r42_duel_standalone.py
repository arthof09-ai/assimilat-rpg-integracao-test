"""R41 long-duel independent, stdlib-only causal/mechanical oracle (no combat-engine imports)."""
from __future__ import annotations
import json,hashlib,sqlite3,random,math,sys
from pathlib import Path
A='LAB_R42_GOAT_A';B='LAB_R42_GOAT_B';IDS=[A,B]
VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
class AuditError(ValueError):pass

def check(x,m):
 if not x:raise AuditError(m)
def J(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def H(x):return hashlib.sha256(J(x).encode()).hexdigest()
def die(seed,ix,label):
 h=hashlib.sha256(f'{seed}|{ix}|{label}|1d6|{VERSION}'.encode()).digest()
 return random.Random(int.from_bytes(h,'big')).randint(1,6)
def inspect(db):
 c=sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True)
 try:
  check(c.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLITE_CORRUPTED')
  check(c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0,'PENDING_UNRECONCILED')
  m=dict(c.execute('SELECT key,value FROM meta'))
  rows=c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
 finally:c.close()
 final=json.loads(m['state']);seed=final['seed']
 check(final['scene'].startswith('R42_LONG_DUEL_NEGATIVE_MISS_POLICY_CONDITIONAL_INIT_'),'WRONG_SCENE')
 check(final['synthetic'] is True and final['r40']['world_effects']==0,'CANONICAL_EFFECT')
 check(len(rows)==int(m['revision']) and len(rows)>1,'REVISION_EVENTS_DIFFER')
 check(set(final['actors'])==set(IDS),'ACTORS_NOT_TWO_GOAT_INSTANCES')
 for k in IDS:
  v=final['actors'][k]
  check(v['source_page_id']=='391c2b32-4ede-8252-b0cc-810423cdbfa6','SOURCE_PAGE_INVALID')
  check(all(v['stats'][q]==value for q,value in [('for',13),('des',8),('con',10),('luta_bonus',6)]),'ATTR_INVALID')
  check(v['resource']['ca']==20 and v['resource']['reflex']==6 and v['resource']['armor'] is None and v['resource']['fortitude'] is None,'DEFENSE_INVALID')
  check(v['stats']['init_bonus']==0 and v['stats']['init_bonus_origin']=='R42_COMMON_UNKNOWN_INIT_OFFSET_REPRESENTED_AS_0_ONLY_FOR_ORDER_TEST','INIT_PREMISE_NOT_LABELED')
 hp={A:38,B:38};rx={A:1,B:1};std={A:1,B:1};mov={A:1,B:1};pa={A:22,B:22};pos={A:[0.,0.],B:[1.5,0.]};index={A:0,B:0}
 order=None;active=None;rr=0;turn=0;attacks=0;critpos=0;previous=m['genesis'];past=None;pushes=0;movements=0;announcements=0
 for i,(seq,cmd,prev,row_json,row_sha,before,after) in enumerate(rows,1):
  row=json.loads(row_json)
  check(seq==i and row['seq']==i and cmd==row['cmd_id'] and prev==row['prev']==previous,'BROKEN_CAUSAL_HEAD')
  check(row['before_sha']==before and row['after_sha']==after and H(row)==row_sha,'INVALID_HASH')
  if past is not None:check(past==before,'STATE_HASH_NOT_CHAINED')
  previous=row_sha;past=after
  d=row['detail'];p=row['payload']
  check(row['synthetic'] and row['official_effects']==0,'OFFICIAL_WORLD_EVENT')
  if i==1:
   check(row['kind']=='R42_LONG_INITIATIVE' and p=={'kind':'INIT','seed':seed},'BAD_INIT_EVENT')
   ini=d['native_initiative_R26'];obs={x['id']:x for x in ini['rolls']}
   check(set(obs)==set(IDS),'INIT_SOURCE_ID')
   for a in IDS:
    check(obs[a]['dice']==[die(seed,0,'initiative:'+a)] and obs[a]['des']==8 and obs[a]['bonus']==0 and obs[a]['total']==8+die(seed,0,'initiative:'+a),'INIT_DIE_OR_BONUS_FALSE')
   if obs[A]['total']!=obs[B]['total']:
    result=sorted(IDS,key=lambda a:-obs[a]['total']);check(ini['tie_resolution']['rerolls']==[],'UNJUSTIFIED_TIE_REROLL')
   else:
    draws=ini['tie_resolution']['rerolls'];result=None
    for n,round_draw in enumerate(draws,1):
     check(round_draw['step']==n and set(round_draw['only_tied'])==set(IDS),'TIE_REROLL_WRONG_SCOPE')
     score={a:die(seed,n,'R26-TIE-'+a)+8 for a in IDS}
     check({x['id']:x['roll_total'] for x in round_draw['draws']}==score,'TIE_RNG_FALSE')
     if score[A]!=score[B]:result=sorted(IDS,key=lambda a:-score[a]);check(n==len(draws),'TIE_EXTRA_DICE');break
    check(result is not None,'TIE_UNRESOLVED')
   check(ini['order']==result==d['order']==ini['tie_resolution']['order'],'INIT_ORDER_FALSE')
   order=result;active=result[0];rr=1;turn=0;check(d['first_actor']==active,'FIRST_ACTOR_FALSE')
   continue
  check(row['kind']=='R42_LONG_TURN' and order is not None,'TURN_KIND')
  a=d['actor'];t=d['target'];check(a==active==p['actor'] and t==p['target'] and t in IDS and t!=a and p['round']==rr,'ACTOR_ACTIVE_OR_ROUND_FALSE')
  check(hp[a]>0 and hp[t]>0 and std[a]==1,'ILLEGAL_ATTACK_OR_DOUBLE_STANDARD')
  check(d['action']=='CABRA_INVESTIDA_MESTRE_R34_FF300' and d['source']=='391c2b32-4ede-8252-b0cc-810423cdbfa6','UNAUTHORIZED_ABILITY')
  index[a]+=1;tt=d['RNG'];check(tt==p['tape'] and tt['actor']==a and tt['index']==index[a] and tt['seed']==seed,'RNG_TAPE_NOT_PAYLOAD')
  dice=[die(seed,index[a],f'R42-CRIT-{a}-{v}') for v in (1,2,3)]
  hd=die(seed,index[a],'R42-HIT-'+a);dd=die(seed,index[a],'R42-DAMAGE-'+a)
  check(tt['critical_dice']==dice and tt['hit_die']==hd and tt['damage_die']==dd,'RNG_VALUE_OR_ORDER_FALSE')
  positive=dice[:2]==[6,6] and dice[2]>=5;negative=dice[:2]==[1,1] and dice[2]<=2
  check(tt['critical_positive']==positive and tt['critical_negative']==negative,'CRITICAL_VALIDITY')
  score=hd+19;gross=dd+13+(6 if positive else 0)
  check(tt['attack_total']==score and tt['damage_total']==gross and tt['luta']==6 and tt['for']==13 and 1<=hd<=6 and 1<=dd<=6,'ATTACK_OR_DAMAGE_FORMULA')
  # Move if pushed out of adjacency.
  dist=math.dist(pos[a],pos[t]);me=d['movement']
  if dist>1.5000001:
   check(mov[a]==1 and me is not None,'MOVE_SLOT_MISSING')
   need=dist-1.5;new=[round(pos[a][q]+(pos[t][q]-pos[a][q])/dist*need,8) for q in (0,1)]
   check(me['from']==pos[a] and me['to']==new and me['distance']==need and need<=10,'MOVE_CAUSAL_FALSE')
   pos[a]=new;mov[a]=0;movements+=1
  else:check(me is None,'EXTRA_MOVE')
  check(math.dist(pos[a],pos[t])<=1.5000002,'NOT_ADJACENT')
  defense=d['voluntary_reaction'];check(rx[t]==1 and defense is not None and d['rejected_second_reaction'] is None,'REACTION_NOT_ANNOUNCED')
  check(defense['action']=='ESQUIVAR' and defense['by']==t and defense['attack_score']==score and defense['defense_exact']=='26' and defense['damage_negated'] is True and defense['consumes_reaction'] is True,'DODGE_NUMERIC_WRONG')
  rx[t]=0;announcements+=1
  eff=d['native_attack'];hit=(not negative) and (positive or score>20)
  net=max(0,gross-5) if positive else 0
  # Because every normal score <=25 and EVERY attack is dodged with defense26.
  before_hp=hp[t];hp[t]=max(0,hp[t]-net);std[a]=0
  check(eff['hit']==hit and eff['net']==net and eff['before_hp']==before_hp and eff['after_hp']==hp[t], 'DAMAGE_OR_HP_MECHANIC_FALSE')
  check(eff['roll_score']==score and eff['raw']==(gross if net else 0) and eff['rd_applied']==(5 if net else 0) and eff['r41_critical_status']==('POSITIVE' if positive else 'NEGATIVE' if negative else 'NONE') and eff['r41_positive_auto_hit']==positive and eff['r41_max_dice_added']==(6 if positive else 0),'CRIT_RD_OR_SCORE_FALSE')
  check(eff['r41_critical_dice']==dice and eff['r41_hit_die']==hd and eff['r41_damage_die']==dd,'ATTACK_EVENT_NOT_TAPE')
  check(eff['defensive_reaction']=='ESQUIVAR' and eff['defense_negated']==(not positive),'DODGE_AUTOMATIC_CRITICAL_HANDLING')
  if negative:check(eff['critical_failure_policy']=='CRITICAL_FAILURE / VLAB-LAB-POLICY' and eff['hit'] is False and eff['raw']==0 and eff['net']==0 and eff['actor_pa_before_after']==[22,22],'NEGATIVE_CRITICAL_POLICY_INVALID')
  if positive:
   cr= d['push'];check(cr is not None and cr['m']==1.5 and cr['ff']==310 and cr['from']==pos[t],'POSITIVE_CRIT_PUSH')
   dt=math.dist(pos[a],pos[t]);new=[round(pos[t][q]+(pos[t][q]-pos[a][q])/dt*1.5,8) for q in (0,1)]
   check(cr['to']==new,'FORCED_PUSH_COORDINATES')
   pos[t]=new;pushes+=1;critpos+=1
  else:check(d['push'] is None,'PUSH_WHEN_ZERO_DAMAGE')
  check(d['after_hp']==hp and d['after_positions']==pos,'SCENE_STATE_FALSE')
  live=[x for x in IDS if hp[x]>0];tr=d['turn_transition']
  if len(live)<=1:
   check(tr['completed'] is True and tr['winner']==(live[0] if live else None),'END_INCORRECT')
   active=None
  else:
   turn=(turn+1)%2
   if turn==0:rr+=1
   active=order[turn];check(active in live,'KO_ACTOR_GAINED_TURN')
   std[active]=mov[active]=rx[active]=1
   check(tr['completed'] is False and tr['active']==active and tr['refresh']['actor']==active and tr['refresh']['after']==1 and tr['round']==rr,'TURN_AND_REFRESH_FALSE')
  check(d['after_reactions']==rx,'FINAL_REACTION_FALSE');attacks+=1
 check(previous==m['head'] and past==H(final),'FINAL_CHAIN_MISMATCH')
 check(final['r40']['attacks']==attacks and final['r40']['reaction_announcements']==announcements and final['r40']['pushes']==pushes and final['r40']['movements']==movements,'FINAL_COUNTS_FALSE')
 check({a:v['resource']['hp'] for a,v in final['actors'].items()}==hp and final['r40']['positions']==pos,'FINAL_HP_COORD_FALSE')
 check({a:v['resource']['reaction'] for a,v in final['actors'].items()}==rx,'FINAL_RX_FALSE')
 check({a:v['resource']['standard'] for a,v in final['actors'].items()}==std,'FINAL_STD_FALSE')
 if active is None:check(final['winner'] in IDS and final['phase']=='COMPLETE_LAB_R42_TWO_GOATS_CONDITIONAL_INIT','FINAL_WINNER_FALSE')
 else:check(final['winner'] is None and final['phase']=='ACTIVE' and final['active']==active,'CENSOR_STILL_ACTIVE')
 return {'status':'PASS','seed':seed,'events':len(rows),'native_attacks':attacks,'critical_positive':critpos,'critical_negative':sum(1 for seq,cmd,prev,row_json,row_sha,before,after in rows[1:] if json.loads(row_json)['detail']['RNG']['critical_negative']),'reactions':announcements,'pushes':pushes,'moves':movements,'final_hp':hp,'final_round':final['round'],'lab_winner':final['winner'],'checksum':m['head'],'init_scope':'CONDITIONAL_ZERO_PREMISE'}
if __name__=='__main__':
 try:print(json.dumps(inspect(sys.argv[1]),indent=2,ensure_ascii=False))
 except AuditError as e:print('AUDIT_FAIL',e,file=sys.stderr);raise SystemExit(2)
