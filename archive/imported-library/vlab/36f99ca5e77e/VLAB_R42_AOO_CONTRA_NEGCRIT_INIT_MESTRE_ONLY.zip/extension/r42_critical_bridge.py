"""R42 additive experimental negative-critical policy: Mestre chat decision recovered.
No modification to historical v0.8.1 or R41's positive-critical bridge.
Negative critical: automatic miss, zero target/self damage, consume legitimate action/cost,
no additional unapproved effect. This policy is LAB-specific, NOT campaign canon.
"""
from __future__ import annotations
from vlab_effects_v08 import EffectBlocked,_require_option
from r41_critical_bridge import ordered_critical,apply_source_attack as old_apply
POLICY='CRITICAL_FAILURE / VLAB-LAB-POLICY'

def apply_source_attack(scene,attacker_id,defender_id,*,source,state,proofs,
                        attack_die,damage_die,critical_dice,force,luta,rd,
                        reaction_event=None,strict=True,damage_tag='impacto',critical_margin=0):
    kind=ordered_critical(critical_dice,critical_margin)
    if kind!='NEGATIVE':
        return old_apply(scene,attacker_id,defender_id,source=source,state=state,proofs=proofs,
                         attack_die=attack_die,damage_die=damage_die,critical_dice=critical_dice,
                         force=force,luta=luta,rd=rd,reaction_event=reaction_event,strict=strict,
                         damage_tag=damage_tag,critical_margin=critical_margin)
    if type(attack_die) is not int or not 1<=attack_die<=6:raise EffectBlocked('HIT_DIE_INVALID')
    if type(damage_die) is not int or not 1<=damage_die<=6:raise EffectBlocked('DAMAGE_DIE_INVALID')
    if (force,luta)!=(13,6):raise EffectBlocked('R42_INDIVIDUAL_INVESTIDA_ONLY')
    a=scene.actors[attacker_id];d=scene.actors[defender_id]
    if a.hp<=0 or d.hp<=0 or a.standard!=1:raise EffectBlocked('KO_OR_NO_STANDARD')
    if source.kind!='attack' or source.economy!='STANDARD' or source.required_pa!=0:raise EffectBlocked('ACTION_ECONOMY_WRONG')
    _require_option(scene,attacker_id,source,state,proofs,strict=strict,target=defender_id)
    if reaction_event is not None:
        if not scene.events or scene.events[-1]!=reaction_event or reaction_event.get('by')!=defender_id or reaction_event.get('attack_score')!=attack_die+force+luta or reaction_event.get('seq')!=len(scene.events) or reaction_event.get('action')!='ESQUIVAR':
            raise EffectBlocked('NEGATIVE_CRIT_REACTION_UNLINKED')
    prev_hp=d.hp;prev_a_hp=a.hp;prev_pa=a.pa
    a.standard=0
    row=scene.record({
      'action':'weapon_attack','from':attacker_id,'to':defender_id,'roll_score':attack_die+force+luta,
      'ca_exact':str(d.ca),'hit':False,'r41_positive_auto_hit':False,
      'r41_hit_reason':'VLAB_NEGATIVE_CRITICAL_AUTOMATIC_MISS',
      'r41_critical_status':'NEGATIVE','r41_critical_dice':list(critical_dice),
      'r41_hit_die':attack_die,'r41_damage_die':damage_die,'r41_damage_formula':'1d6+FOR13',
      'r41_max_dice_added':0,'defensive_reaction':reaction_event['action'] if reaction_event else None,
      'defense_negated':bool(reaction_event and reaction_event['damage_negated']),
      'raw':0,'type':damage_tag,'rd_applied':0,'net':0,
      'before_hp':prev_hp,'after_hp':d.hp,'actor_hp_before_after':[prev_a_hp,a.hp],
      'actor_pa_before_after':[prev_pa,a.pa],
      'critical_failure_policy':POLICY,'effect_status':'LAB_AUTOMATIC_MISS_ZERO_DAMAGE_NO_OTHER_PENALTY',
      'official_death_derived':False,'status':'LAB-STOP-HP0-NOT-CANON'})
    assert row['after_hp']==row['before_hp'] and a.hp==prev_a_hp and a.pa==prev_pa
    return row
