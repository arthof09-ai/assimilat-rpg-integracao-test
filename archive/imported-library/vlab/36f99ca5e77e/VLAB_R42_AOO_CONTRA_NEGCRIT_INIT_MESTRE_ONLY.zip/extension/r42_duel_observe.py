"""R42 new LAB observation: negative critical now follows recovered historical Mestre LAB policy.
Two real-source goat instances. Novel seeds, new SQLite, no prior DB reopened for write.
"""
from __future__ import annotations
import json,sys,copy
from pathlib import Path
R=Path('/mnt/data/vlab_r42/work');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r42_long_duel_core as g
j=g.j

def execute(seed:int,horizon:int):
    tag='NEGATIVE_POLICY_OBSERVATION_H'+str(horizon)
    db,gen=g.create(seed,tag)
    g.commit(db,'R42_LONG_INITIATIVE',{'kind':'INIT','seed':seed},g.init_runner)
    stop=None
    # No artificial draw or winner after horizon.
    for _ in range(horizon*2+1):
        st,hd,rev=g.checked(db)
        if st['phase']!='ACTIVE':stop='HP_ZERO';break
        if st['round']>horizon:stop='HORIZON_CENSORED';break
        p=g.payload(st)
        g.commit(db,'R42_LONG_TURN',p,g.do_turn)
        if rev and rev%100==0:print('PROGRESS',seed,'round',st['round'],'events',rev,flush=True)
    else:raise AssertionError('R42_CONTROL_FLOW_OVERRUN')
    st,hd,rev=g.checked(db)
    replay=g.replay(db,gen);cp=g.backup(db,gen)
    ev=j.history(db)['events'];turns=[x for x in ev if x['kind']=='R42_LONG_TURN']
    pos=[x for x in turns if x['detail']['RNG']['critical_positive']]
    neg=[x for x in turns if x['detail']['RNG']['critical_negative']]
    receipt={'id':'OP-VLAB-R42-NEGATIVE_CRIT-NATIVE-'+str(seed),'seed':seed,'horizon_rounds':horizon,'stop':stop,'phase':st['phase'],'winner':st['winner'] if stop=='HP_ZERO' else None,'censored':stop!='HP_ZERO','round_at_stop':st['round'],'attacks':len(turns),'positive':len(pos),'negative':len(neg),'positive_event_seq':[r['seq'] for r in pos],'negative_event_seq':[r['seq'] for r in neg], 'hp':{a:v['resource']['hp'] for a,v in st['actors'].items()},'final_reactions':{a:v['resource']['reaction'] for a,v in st['actors'].items()},'positions':st['r40']['positions'],'movements':st['r40']['movements'],'pushes':st['r40']['pushes'],'reaction_announcements':st['r40']['reaction_announcements'],'initiative_scope':'SAME_SOURCE_COMMON_UNKNOWN_BONUS_B; ZERO_NUMERICAL_REPRESENTATIVE_ONLY; R26_ORDER_PROOF_SEPARATE','negative_rule_source':'MESTRE_CHAT_2026-10-15T12:02:54Z_LAB_ONLY_NOT_NOTION_CANON','ledger':{'file':db.name,'sha256':g.sha_file(db),'events':rev,'head':hd,'pending':0},'replay':replay,'checkpoint':cp,'official_effects':0,'previous_banks_touched':0}
    g.dump('evidence/R42_DUEL_SEED'+str(seed)+'_RECEIPT.json',receipt)
    print('RESULT',json.dumps({k:receipt[k] for k in ('seed','stop','round_at_stop','attacks','positive','negative','hp','winner')},ensure_ascii=False),flush=True)
    return receipt
if __name__=='__main__':execute(int(sys.argv[1]),int(sys.argv[2]))
