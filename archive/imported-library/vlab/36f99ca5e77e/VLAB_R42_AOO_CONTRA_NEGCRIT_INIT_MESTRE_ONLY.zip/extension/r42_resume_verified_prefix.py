"""R42 continuation for ONLY verified prefix 95103 after tool timeout.
Preflight expects precise original head/revision, independent oracle readback must pass first.
No old command replay, no pending recovery, no reinits.
"""
from pathlib import Path
import sys,json
R=Path('/mnt/data/vlab_r42/work');sys.path[:0]=[str(R/'extension'),str(R/'runtime_copy')]
import r42_long_duel_core as g
j=g.j
SEED=95103;HORIZON=180
DB=R/'ledgers/R42_LONG_NEGATIVE_POLICY_OBSERVATION_H180_SEED95103.sqlite'
expected_head='7736665c6e24508e104de39b9616c65ae283496434de2d1a0771190f20b8076b'
state,hd,rv=g.checked(DB)
assert (rv,hd,state['round'],state['phase'])==(178,expected_head,89,'ACTIVE'), 'NOT_THE_VERIFIED_PREFIX'
gen=g.make_state(j.initial('A',SEED),SEED)
assert g.replay(DB,gen)['events']==178,'PREFIX_CAUSAL_REPLAY_FAILED'
print('PREFIX_VERIFIED_REPLAY_PASS',rv,hd,flush=True)
stop=None
for _ in range(200):
 st,h,rev=g.checked(DB)
 if st['phase']!='ACTIVE':stop='HP_ZERO';break
 if st['round']>HORIZON:stop='HORIZON_CENSORED';break
 payload=g.payload(st)
 g.commit(DB,'R42_LONG_TURN',payload,g.do_turn)
 if rev and rev%60==0:print('CONTINUED',rev+1,'round',st['round'],flush=True)
else:raise AssertionError('ITERATIONS_OVERFLOW')
st,hd,rv=g.checked(DB)
rep=g.replay(DB,gen);cp=g.backup(DB,gen)
rows=j.history(DB)['events'];turns=[x for x in rows if x['kind']=='R42_LONG_TURN']
pos=[x for x in turns if x['detail']['RNG']['critical_positive']];neg=[x for x in turns if x['detail']['RNG']['critical_negative']]
out={'id':'OP-VLAB-R42-RESUMED-ONLY-VERIFIED-PREFIX','seed':SEED,'resume_checkpoint_before':{'revision':178,'head':expected_head,'prefix_causal_replay':'PASS'},'horizon_rounds':HORIZON,'stop':stop,'phase':st['phase'],'winner':st['winner'] if stop=='HP_ZERO' else None,'censored':stop!='HP_ZERO','round_at_stop':st['round'],'attacks':len(turns),'positive':len(pos),'negative':len(neg),'hp':{a:v['resource']['hp'] for a,v in st['actors'].items()},'positions':st['r40']['positions'],'ledger':{'file':DB.name,'sha256':g.sha_file(DB),'events':rv,'head':hd,'pending':0},'replay':rep,'checkpoint':cp,'official_effects':0}
g.dump('evidence/R42_DUEL_SEED95103_RECEIPT.json',out)
print('CONTINUATION_COMPLETE',json.dumps({k:out[k] for k in ('stop','round_at_stop','attacks','positive','negative','hp','winner')},ensure_ascii=False),flush=True)
