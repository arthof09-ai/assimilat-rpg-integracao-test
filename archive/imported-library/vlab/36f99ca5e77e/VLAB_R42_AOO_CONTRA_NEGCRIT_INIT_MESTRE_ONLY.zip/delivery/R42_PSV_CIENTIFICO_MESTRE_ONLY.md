# PSV — R42 | Continuidade da OP-VLAB-FUSION-SANDBOX-01

**Executor:** CM-000006 · **Autoridade:** Mestre · **Ambiente:** MESTRE-SIDE · **Data:** 15/10/2026 · **Natureza:** engenharia experimental, auditoria mecânica e governança preservacional.

## ANTES e fontes

Checkpoint R41. Foram reabertos fisicamente no Notion o Sistema de Combate, a Criação de Besta, a ficha Cabra de Chifres Bronze 1 e a OP-VLAB-FUSION-SANDBOX-01; R41 original preservado. O motor v0.8.1, o ledger/turnos R18 e o desempate/renovação R26 foram recuperados da baseline binária R27. Suas cópias byte a byte têm SHA256 iguais aos módulos originais.

- **Sistema de Combate atual:** `3ebc2b32-4ede-81f1-be4b-e8804ac113c0`; Ataque de Oportunidade após saída voluntária do bloco adjacente, Vantagem, consome Reação; Afastar-se com segurança custa Ação Padrão e protege contra **um** inimigo; Contra-atacar pode ser anunciado antes do ataque adversário e, se a pontuação deste não superar CA, concede ataque normal com Vantagem; iniciativa usa dado do rank, DES e bônus individual.
- **Cabra B1:** `391c2b32-4ede-8252-b0cc-810423cdbfa6`; Vida38, CA20, FOR13, DES8, CON10, Investida literal `1d6+força impacto`. Contratos específicos já aprovados: Investida Luta+6, RD Bronze5, empurrão1,5m em hit com dano líquido positivo, Esquivar CA20+Reflexo6=26, empate em defesa favorece defesa, crítico positivo válido é acerto automático.
- **Decisão do Mestre HISTÓRICA recuperada em conversa deste Projeto, 15/10/2026 aproximadamente 12:02:54 UTC:** para **VLAB apenas**, falha crítica negativa 111/112 = ataque falha automaticamente, dano zero, Ação e custos legítimos consumidos, nenhum dano próprio/perda de arma/penalidade adicional automaticamente. Designação `CRITICAL_FAILURE / VLAB-LAB-POLICY`. **Essa decisão não estava materializada como regra mundial na página Sistema de Combate**; R42 preserva proveniência de conversa e inscreveu-a em registro operacional ANTES, sem alegar canonização. As censuras R41 permanecem históricas, sem reclassificação.
- **Iniciativa individual da Cabra não publicada:** condição P5 +0 da R34 tinha escopo restrito àquela cena. R42 não a transforma em atributo oficial.

## Frente A — Ataques de Oportunidade concorrentes

**Legalmente alcançável:** um ator em (0;0), adjacente a inimigo B em (1,5;0) e inimigo C em (0;1,5), sai voluntariamente para (-1,5;-1,5). Ambos os inimigos, se mantiverem Reação, têm gatilho. Uma Ação Padrão de Afastar-se com segurança contra B ainda deixa C elegível; movimento forçado da Investida não gera AoO conforme Mestre. **BLOCKED-NORMATIVE:** o texto não indica a ordem/precedência dos dois Ataques de Oportunidade quando seus efeitos podem afetar a ação em andamento. Gate R42 recusa antes de intenção durável, publicação, movimento ou consumo de slot. Não foi inferida ordem por iniciativa sem norma.

Dos 16 testes dirigidos R42, seis cobrem dupla elegibilidade, proteção contra apenas um, movimento forçado, slot já consumido, ausência de saída e ambos os slots indisponíveis.

## Frente B — Contra-atacar

**VERIFICADO:** modalidade de Reação anunciada antes do ataque; se ataque entrante **não superar CA**, Contra-atacar habilita um **ataque normal com Vantagem**. A Vantagem vigente é 2d6, escolher maior e aplicar +2 (na classificação Bronze), além do atributo e bônus de Luta competentes. **BLOCKED-SOURCE:** nenhuma Luta da Cabra para o ataque NORMAL de resposta foi localizada. O +6 dado pelo Mestre é exclusivo da sua INVESTIDA; utilizar +6 ou +0 na reação sem fonte seria inventar competência. A comparação sintética `max(2d6)+2+FOR13+LutaX` mostra por que isso importa; **não é um Contra-ataque real-fonte executado**. Testes verificaram gatilho por empate em CA, falha acima da CA, ausência de slot e rejeição de Luta inventada.

## Frente C — Falha crítica negativa com efeito laboratorial recuperado

Foi implementada `extension/r42_critical_bridge.py` como **camada aditiva** sobre a ponte R41. Positivos e comuns continuam no resolvedor anterior, sem mudança; sequências negativas 111/112 resolvem `hit=False`, `net=0`, Ação Padrão 1→0, PA/HP próprios intactos, Reação previamente anunciada ainda consumida, sem dano adicional. Não são aplicadas penalidades que o Mestre não autorizou. A fita R18 é gerada pelo RNG experimental, com três dados de crítico ordenados e valores de ataque/dano ligados ao índice do ator. O ledger R18 persiste a decisão LAB `CRITICAL_FAILURE / VLAB-LAB-POLICY` e replay causal. Dados de dano pré-gerados e não aplicados em falhas são escolha técnica do RNG indexado experimental, não alegação de ordem canônica da rolagem.

**Três novas observações**, sementes 95101/95102/95103, sempre duas instâncias da ficha real Cabra B1, ambas anunciando Esquivar em todo ataque, início de turno R26, iniciativa com REPRESENTANTE ZERO do bônus comum desconhecido somente para cálculo de ordem, sem autenticar atributo +0. Nenhuma cena anterior foi repetida:

| Seed | Horizonte | Ataques | Positivos | Negativos | Última rodada | HP A/B | Resultado |
|---|---:|---:|---:|---:|---:|---|---|
| 95101 | 130 | 260 | 3 | 2 | 131 | 20 / 4 | Censura por horizonte |
| 95102 | 180 | 308 | 4 | 3 | 154 | 0 / 21 | **KO legítimo em sandbox**, B vencedora |
| 95103 | 180 | 360 | 2 | 2 | 181 | 38 / 1 | Censura por horizonte |

**Totais sustentados:** 928 ataques R18, 9 críticos positivos e **7 negativos efetivamente resolvidos**, 928 Esquivas anunciadas; 931 eventos SQLite (3 iniciativas +928 ataques). Duração de observação não é rodada encerrada oficialmente se censurada. R42 fornece uma nova prova de que Esquivar sempre não impede críticos positivos de produzir vitória legítima, ao mesmo tempo em que falhas críticas negativas LAB não precisam encerrar prematuramente a pesquisa. **Não há taxa de vitória representativa**, devido a apenas 3 sementes, horizontes diferentes e escolha sequencial de expansão.

**Recuperação sem reexecução:** durante a terceira cena a ferramenta interrompeu o processo no limite de execução, deixando o banco na revisão178, head `7736665c6e24508e104de39b9616c65ae283496434de2d1a0771190f20b8076b`, sem pendências. Foram executadas leitura bruta SQLite, auditor independente **178/178 eventos PASS** e replay mecânico causal antes de continuar com comandos novos a partir da revisão179. Nenhum evento anterior foi recalculado por commit nem nenhum ID antigo reutilizado. Checkpoint final R42 rev361 passou auditoria separada.

## Frente D — Iniciativa com bônus comum desconhecido

Prova matemática: para instâncias da **mesma ficha**, se o bônus individual desconhecido comum é B, cada participante tem `Iniciativa = 1d6 + DES8 + B`; em desempate R26 a repetição soma o mesmo B. Subtrair o mesmo B de todos os totais preserva diferenças, empates e ordens. Em `extension/r42_initiative_symbolic.py`, o R26 real recebeu sete representantes B = −20,−6,−1,0,+6,+12,+30 em cada uma das 16 sementes pré-listadas: **112/112 ordens e desempates congruentes**, incluindo duas sementes com rerrolagens. Assim a **ordem relativa de cópias idênticas** independe do valor não publicado. O estudo **não apura nem autentica o bônus individual**, não resolve iniciativa de Frígido × Cabra e não libera cenas multiespécies sem os respectivos bônus.

## Ciências e contraprovas

Oráculo matemático independente, sob hipóteses explícitas de dados ideais independentes, crítico positivo 1/108, negativo sem efeito, Esquiva contínua, crítico líquido uniforme 15–20 e Movimentos suficientes: 2 ou 3 críticos eliminam uma Cabra HP38 (2 são suficientes em 6/36 pares); média de críticos necessários num alvo =17/6. Corrida de dois atacantes simétricos prevê cerca de **411 oportunidades ofensivas até o primeiro KO** e vantagem muito pequena ao primeiro ator (≈50,088%). Esses números são **oráculo teórico condicionado**, não empiria nem homologação RNG. O observado nas três sementes não permite teste estatístico de taxa global.

O verificador R42 `verify_r42_duel_standalone.py`, escrito sem imports do motor, conferiu **3 ledgers +3 checkpoints** separadamente (6 bancos SQLite), reconstruindo a fita R18, as 931 cadeias de evento, decisões de Reação, domínio 1–6, críticos positivos/negativos, dano/RD/HP/empurrão, Movimento, avanço, iniciativa e recursos. Todos passaram. Cinquenta? **Não**: foram **5/5 adulterações** com reencadeamento criptográfico real em clones temporários, estruturalmente aceitas por R18 e rejeitadas pelo auditor mecânico (negative → hit falso, dano indevido, custo PA inventado, fita crítica falsa, classificação negativa omitida). `R42_FOUR_FRONTIERS_DIRECTED_TESTS.json`: **16/16 PASS** nos testes de alcance/gates e fixtures declaradas.

Verificações de preservação: ZIPs R27/R39B/R40/R41 mantêm seus hashes registrados; os bytes de `vlab_r18_interactive.py`, `vlab_r26_master_rulings.py` e `vlab_effects_v08.py` foram confrontados com os originais da baseline, todos idênticos. Nenhuma ficha, norma oficial, combate de campanha, Party ou O Primeiro escrita. Nenhuma intenção UNKNOWN_EFFECT histórica retomada.

## Contratos e gate de conclusão

Denominadores **imutáveis**: 17 contratos originais, 1.875 células canônicas, 18 combates historicamente reconhecidos até R40. R41 concluiu duas cenas experimentais com iniciativa condicionada, sem promovê-las ao contador fonte-completa. **R42 acrescenta 1 cena terminada condicionada e 2 censuradas por horizonte; não promove +1 ao contador histórico de 18.** Reações, scheduler e RNG recebem evidências técnicas parciais novas, mas `TECHNICALLY_COMPLETE=NO`, `TERMINAL_CERTIFIED=0/17`, `CANON_CELLS=0/1875`. `NAC-PASS-02` terminal, writer/lease/epoch/fencing/GREEN: **HOLD**. `IBX-56=BLOCKED-EXTERNAL`.

## Primeira pendência e NEXT exato

1. **AoO simultâneo:** decisão mínima do Mestre/autoridade competente sobre a precedência de dois inimigos que podem atacar por oportunidade durante o mesmo movimento voluntário, quando o primeiro efeito puder alterar a elegibilidade do segundo. A situação foi comprovada como alcançável e bloqueada antes de efeitos.
2. **Contra-atacar:** obter BÔNUS DE LUTA do ataque NORMAL de uma Besta da ficha real, sem transplantar a Luta +6 exclusiva da Investida. Com esse dado, executar Contra-ataque nativo com Vantagem e testar a interação com AoO e eliminação.
3. **Falha crítica negativa:** a decisão histórica do Mestre já autoriza a execução **somente LAB** e foi executada; para campanha, a sincronização normativa geral exige revisão independente NAC-NORM, não uma nova decisão improvisada.
4. **Iniciativa:** ordem de instâncias idênticas está matematicamente reconciliada; o valor individual de Cabra B1 e os bônus relativos de outras Bestas continuam não autenticados.

**FRONTEIRA OPERACIONAL:** novo banco apenas depois de autoridade pertinente, fontes e seeds reconferidas. Bancos R42 terminados/censurados ficam imutáveis; 95103 foi continuado somente após prova física da revisão178 e agora está fechado no horizonte. Não reexecutar. Auditoria e contrato originais no pacote delta R42; não criar operação paralela.
