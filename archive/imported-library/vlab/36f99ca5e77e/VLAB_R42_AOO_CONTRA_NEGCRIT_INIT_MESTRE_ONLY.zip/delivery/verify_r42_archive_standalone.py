"""R42 archive verifier. Python stdlib only; does not import VLAB or any combat engine.
Checks ZIP CRC/SHA, six SQLite mechanically with standalone R42 oracle,
three stored independent reports, and no invented terminal credit.
"""
from __future__ import annotations
import json,sys,hashlib,tempfile,zipfile,subprocess
from pathlib import Path

def sha(x):return hashlib.sha256(x).hexdigest()
def main(path):
 z=zipfile.ZipFile(path)
 assert z.testzip() is None,'CRC_ERROR'
 assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist()),'ZIP_PATH'
 manifest=json.loads(z.read('R42_FILE_MANIFEST.json'))
 assert set(z.namelist())==set(manifest['sha256'])|{'R42_FILE_MANIFEST.json'},'MANIFEST_SET'
 for n,h in manifest['sha256'].items():assert sha(z.read(n))==h,n
 with tempfile.TemporaryDirectory(prefix='r42_stdlib_audit_') as tmp:
  z.extractall(tmp)
  root=Path(tmp)
  audit=json.loads((root/'evidence/R42_COLD_AUDIT_3_DUELS.json').read_text())
  assert audit['status']=='PASS' and audit['scenes']==3 and audit['databases']==6
  total=neg=pos=attacks=0
  for row in audit['results']:
   assert len(row['results'])==2
   for item in row['results']:
    p=root/('ledgers' if item['type']=='ledger' else 'checkpoints')/item['name']
    assert sha(p.read_bytes())==item['sha256']
    cmd=[sys.executable,str(root/'extension/verify_r42_duel_standalone.py'),str(p)]
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
    assert r.returncode==0,'MECHANICAL_AUDIT_FAILED_'+str(row['seed'])+'_'+item['type']+' '+r.stderr
    observed=json.loads(r.stdout)
    assert observed==item['audit'],'EXPECTED_AUDIT_DIFF'
    if item['type']=='ledger':
     total+=observed['events'];attacks+=observed['native_attacks'];neg+=observed['critical_negative'];pos+=observed['critical_positive']
  assert (total,attacks,pos,neg)==(931,928,9,7),'TOTAL_COUNTER_INVALID'
  t=json.loads((root/'evidence/R42_FOUR_FRONTIERS_DIRECTED_TESTS.json').read_text())
  assert t['checks']==16 and all(x['status']=='PASS' for x in t['results'].values())
  j=json.loads((root/'evidence/R42_INITIATIVE_COMMON_UNKNOWN_BONUS_INVARIANCE.json').read_text())
  assert j['result']=='PASS' and j['cases']==112 and j['canonic_bonus'] is None
  a=json.loads((root/'evidence/R42_RECHAINED_ADVERSARIAL_RESULTS.json').read_text())
  assert a['status']=='PASS' and a['cases']==5 and all(q['mechanical_external']=='REJECTS' and q['structural_R18']=='ACCEPTS_REHASHED_INTEGRITY' for q in a['results'])
  b=json.loads((root/'evidence/R42_DELTA_CONTRACT_MATRIX.json').read_text())
  assert b['terminal_certified_after']==0 and b['total_original_contracts']==17 and b['cells_canonical']==0
  return {'status':'PASS','zip_members':len(z.namelist()),'checked_sha256':len(manifest['sha256']), 'sqlite_audited':6,'native_events':total,'attacks':attacks,'positive_criticals':pos,'negative_criticals':neg,'frontier_directed_tests':16,'symbolic_initiative_cases':112,'rehashed_semantic_tamper_cases':5,'terminal_contracts':'0/17','official_effects':0}
if __name__=='__main__':
 try:print(json.dumps(main(sys.argv[1]),indent=2,ensure_ascii=False))
 except Exception as e:print('FAIL',repr(e),file=sys.stderr);raise
