# R42 — Reproduzir SEM reexecutar combates históricos

Pacote delta Mestre-side da OP-VLAB-FUSION-SANDBOX-01. O ZIP não contém motores históricos R27, nem bancos anteriores R34–R41. Reutiliza-os por SHA/proveniência. Executar o verificador standalone no ZIP, sem importar motor:

```bash
python verify_r42_archive_standalone.py VLAB_R42_AOO_CONTRA_NEGCRIT_INIT_MESTRE_ONLY.zip
```

O auditor extrai para pasta temporária, confere CRC, SHA256 e executa o script autônomo `extension/verify_r42_duel_standalone.py` em **todos os seis** SQLite novos (3 live e 3 backups), sem gateway R31/R35, sem v0.8.1 e sem R18. Relê provas de 16 testes, 112 comparações R26 em clones e 5 mutações. O próprio `R42_COLD_AUDIT_3_DUELS.json` identifica seeds, hashes, heads, críticos, progresso de Vida e checkpoint.

Para reproduzir o **código de desenvolvimento** em novo diretório, recuperar os ZIPs imutáveis R27, R35, R36 e R41 da Biblioteca original, revalidar hashes, extrair conforme `setup_r42.py` **ajustando apenas o root local**. A ponte nova depende de `extension/r41_critical_bridge.py` anterior, preservada. Para qualquer execução nova escolher semente, banco e ID de comando nunca utilizados. **Nunca chamar `r42_duel_observe.py` com seeds 95101–95103 de novo**, nem continuar após censura já fechada, nem retentar `UNKNOWN_EFFECT`.

Os dados em `evidence/R42_AUTHORITY_AND_SCOPE.json` separam fontes Notion fisicamente reabertas de uma decisão de falha crítica negativa anteriormente expressa pelo Mestre em chat (escopo LAB, não norma geral). `R42_INITIATIVE_COMMON_UNKNOWN_BONUS_INVARIANCE.json` é prova de ordem RELATIVA com bônus comum B desconhecido, não autenticação de valor numérico.

`R42_FOUR_FRONTIERS_DIRECTED_TESTS.json` contém testes com GEOMETRIA/CONTRA **SINTÉTICOS**; não são ataques reais de oportunidade ou Contra-atacar executados. Nenhum combate canônico, nenhum writer produtivo e nenhum crédito terminal decorrem deste pacote.
