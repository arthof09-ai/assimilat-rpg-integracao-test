"""R39 additive Mestre-side test harness. NEVER edits historical modules, sources or official ledgers.
Executes v0.8.1 native reaction+attack on disposable real-source actor snapshots, an R18/R26
three-actor scheduler fixture and a deliberately frozen UNKNOWN_EFFECT failure. Technical-only.
"""
from __future__ import annotations
import copy, json, sqlite3, sys, hashlib, traceback
from pathlib import Path
from dataclasses import asdict
ROOT=Path('/mnt/data/vlab_r39/work')
RUNTIME=ROOT/'runtime_copy';sys.path.insert(0,str(RUNTIME))
import run_r36_dodge as m
j=m.j;r26=m.r26;b=m.b
from vlab_effects_v08 import Scene,Combatant,react_defensively,apply_weapon_attack,EffectBlocked
from vlab_rd_v08 import Resistances
from vlab_action_catalog_v01 import ActorActionState
OUT=Path('/mnt/data/vlab_r39b/delivery');OUT.mkdir(parents=True,exist_ok=True)
for x in ('ledgers','checkpoints','evidence'): (OUT/x).mkdir(exist_ok=True)

class R39Hold(RuntimeError):pass

def dump(name,data):
 p=OUT/'evidence'/name
 with p.open('x',encoding='utf8') as f:json.dump(data,f,indent=2,sort_keys=True,ensure_ascii=False,default=str);f.write('\n')
 return p

def sha_file(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def spawn(seed,tag):
 db=OUT/'ledgers'/f'R39_{tag}.sqlite'
 if db.exists():raise R39Hold('NEW_SCENE_REQUIRED')
 j.init_db(db,'A',seed)
 with j.connect(db) as c:
  c.execute('BEGIN IMMEDIATE')
  meta=dict(c.execute('SELECT key,value FROM meta'))
  if meta['revision']!='0':raise R39Hold('NOT_FRESH_GENESIS')
  st=json.loads(meta['state'])
  st['actors']={aid:b.make_actor(aid,b.GOAT_SOURCE) for aid in ('LAB_R39_GOAT_A','LAB_R39_GOAT_B','LAB_R39_GOAT_C')}
  for a in st['actors'].values():a['resource']['reflex']=6;a['stats']['init_bonus']=0
  st.update({'phase':'INIT','round':0,'turn':0,'active':None,'order':[],'winner':None,'roll_nonce':0,'r39':{'tag':tag,'source_page_id':b.GOAT,'no_canonical_effects':True,'refresh_own_turn_log':[],'events_handled':0,'skipped_dead':[]}})
  genesis=j.sha({'R39':tag,'seed':seed,'R18':j.VERSION,'source':b.GOAT,'EXP_ONLY':True})
  for key,val in (('state',j.canonical(st)),('genesis',genesis),('head',genesis)):
   c.execute('UPDATE meta SET value=? WHERE key=?',(val,key))
  c.commit()
 state,head,rev=j.load(db)
 if rev!=0 or state!=st:raise R39Hold('GENESIS_READBACK_FAIL')
 return db,copy.deepcopy(st)

def checked(db):
 state,head,rev=j.load(db)
 if len(state['actors'])!=3 or any(x['source_page_id']!=b.GOAT for x in state['actors'].values()):raise R39Hold('R39_PROVENANCE_BAD')
 with sqlite3.connect(f'file:{db}?mode=ro',uri=True) as c:
  if c.execute('SELECT COUNT(*) FROM pending').fetchone()[0] or c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise R39Hold('SQLITE_NOT_READY')
 return state,head,rev

def native_scene(st):
 return Scene({k:Combatant(**copy.deepcopy(v['resource'])) for k,v in st['actors'].items()},seed=st['seed'],provenance='R39_MASTER_REAL_BEAST_SOURCE_SANDBOX_NOT_CAMPAIGN')

def dodge(scene,target,score,valid=True,proof=True,window=True):
 src=m.source_reaction(); pf=m.proof_reaction()
 state=ActorActionState(actor_id=target,ordinal_level=1,available_pa=22,known_action_ids=(m.DODGE_ACTION,),reaction_available=scene.actors[target].reaction==1,reaction_trigger_observed='BEFORE-ATTACK' if window else 'AFTER-ATTACK',enemy_ids_visible=tuple(k for k in scene.actors if k!=target))
 return react_defensively(scene,target,kind='ESQUIVAR',attack_score=score,announced_before=valid,trigger_source='BEFORE-ATTACK' if window else 'AFTER-ATTACK',source=src,state=state,proofs=(pf,) if proof else (),strict=True)

def attack(scene,aid,target,score,def_event=None):
 src=b.native_source(); proof=b.proof('MIRROR')
 v=scene.actors[aid];state=ActorActionState(actor_id=aid,ordinal_level=1,available_pa=v.pa,known_action_ids=(b.GO_ACTION,),standard_available=v.standard==1,reaction_available=v.reaction==1,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(target,))
 return apply_weapon_attack(scene,aid,target,source=src,state=state,proofs=(proof,),roll_score=score,damage=19,damage_tag='impacto',rd=Resistances(general=5,specific=(),provenance='CREACAO_BESTA_BRONZE_NORMAL_RD5'),strict=True,defense_event=def_event)

def commit(db,kind,payload,runner):
 st,head,rev=checked(db)
 key='LAB-CMD-R39-'+j.sha({'head':head,'payload':payload,'kind':kind})[:35]
 row=j.event_commit(db,key,kind,payload,runner)
 checked(db)
 return row

def apply_changes(st,scene):
 for k,v in scene.actors.items():st['actors'][k]['resource']=asdict(v)
 st['r39']['events_handled']+=1

def reaction_first(st,p,seq):
 if st['r39']['tag']!='REACTION_SEQUENTIAL_VALID_DAMAGE' or seq!=1:raise R39Hold('R39_FIRST_BAD')
 a,b_,c=list(st['actors'])
 scene=native_scene(st);r=dodge(scene,b_,24);atk=attack(scene,a,b_,24,r);apply_changes(st,scene)
 if not(r['damage_negated'] and atk['net']==0 and st['actors'][b_]['resource']['reaction']==0 and st['actors'][b_]['resource']['hp']==38):raise R39Hold('FIRST_REACTION_NOT_PROTECTED')
 return {'native_events':scene.events,'reaction_slot_after':0,'damage':atk['net'],'hp_defender':38,'purpose':'FIRST_TRIGGER_ATOMIC_REACTION_ATTACK','campaign_effects':0}

def reaction_second(st,p,seq):
 if st['r39']['tag']!='REACTION_SEQUENTIAL_VALID_DAMAGE' or seq!=2:raise R39Hold('R39_SECOND_BAD')
 a,b_,c=list(st['actors']);scene=native_scene(st);before=scene.checksum();pre=asdict(scene.actors[b_]);err=None
 try:dodge(scene,b_,24)
 except EffectBlocked as e:err=str(e)
 if err!='reaction not available' or scene.checksum()!=before or asdict(scene.actors[b_])!=pre:raise R39Hold('SECOND_REACTION_NOT_ATOMICALLY_REJECTED')
 atk=attack(scene,c,b_,24,None);apply_changes(st,scene)
 if atk['net']!=14 or st['actors'][b_]['resource']['hp']!=24:raise R39Hold('SECOND_ATTACK_FAILED')
 return {'second_reaction_preflight':'REJECTED_NO_SLOT','reason':err,'native_events':scene.events,'effective_hp_after':24,'attacker_c_standard_spent':st['actors'][c]['resource']['standard']==0,'campaign_effects':0}

def reaction_refresh(st,p,seq):
 if st['r39']['tag']!='REACTION_SEQUENTIAL_VALID_DAMAGE' or seq!=3:raise R39Hold('R39_REFRESH_BAD')
 a,b_,c=list(st['actors'])
 if st['actors'][b_]['resource']['reaction']!=0:raise R39Hold('REFRESH_BEFORE_SLOT_SPENT')
 st['phase']='ACTIVE';st['order']=[a,b_,c];st['active']=a;st['round']=1;st['turn']=0
 transition=j._next_turn(st)
 if st['active']!=b_:raise R39Hold('REFRESH_NOT_OWN_TURN')
 r=r26.refresh_own_turn(st,b_)
 st['r39']['refresh_own_turn_log'].append({'actor':b_,'round':st['round'],'turn':st['turn']})
 if st['actors'][b_]['resource']['reaction']!=1:raise R39Hold('REFRESH_FAILED')
 return {'transition':transition,'refresh_R26':r,'next_actor':b_,'refresh_once':True,'campaign_effects':0}

def preflight_concurrent(db):
 st,head,rev=checked(db);before=(j.sha(st),head,rev)
 triggers=[{'id':'INCOMING_A','attacker':'LAB_R39_GOAT_A','defender':'LAB_R39_GOAT_B'},{'id':'INCOMING_C','attacker':'LAB_R39_GOAT_C','defender':'LAB_R39_GOAT_B'}]
 # no normative rule choosing between concurrent triggers -- reject BEFORE issuing intent
 err='CONCURRENT_TRIGGER_PRIORITY_UNDEFINED'
 if len(triggers)==1:raise R39Hold('TEST_NOT_CONCURRENT')
 now,h2,r2=checked(db)
 if (j.sha(now),h2,r2)!=before:raise R39Hold('CONCURRENT_REJECTION_MUTATED_LEDGER')
 return {'status':'BLOCKED_NORMATIVE_PRE_INTENT','reason':err,'triggers':triggers,'head_unchanged':True,'revision_unchanged':True,'pending':0,'priority_invented':False}

def preflight_nested(db):
 st,head,rev=checked(db);before=(j.sha(st),head,rev)
 # Contra-atacar is documented, but nesting with Esquivar lacks verified precedence.
 reason='NESTED_COUNTERATTACK_AND_DEFENSE_PRECEDENCE_UNDEFINED'
 x,h,v=checked(db)
 if (j.sha(x),h,v)!=before:raise R39Hold('NESTED_PREFLIGHT_MUTATION')
 return {'status':'BLOCKED_NORMATIVE_PRE_INTENT','reason':reason,'single_reaction_budget':1,'priority_invented':False,'head_unchanged':True}

def invalid_matrix(st):
 a,b_,c=list(st['actors']);out=[]
 for label,kwargs in [('AFTER_ATTACK',{'valid':False}),('WRONG_TRIGGER',{'window':False}),('PROOF_MISSING',{'proof':False})]:
  scene=native_scene(st);base=scene.checksum();res=asdict(scene.actors[b_]);error=None
  try:dodge(scene,b_,24,**kwargs)
  except Exception as e:error=type(e).__name__+':'+str(e)
  if error is None or scene.checksum()!=base or asdict(scene.actors[b_])!=res:raise R39Hold('INVALID_REACTION_MUTATES:'+label)
  out.append({'test':label,'status':'PASS_REJECTED_BEFORE_MUTATION','error':error})
 return out

def replay(db,genesis,runners):
 st,h,rev=checked(db);rows=j.history(db)['events'];cur=copy.deepcopy(genesis)
 for i,row in enumerate(rows,1):
  fx=runners[row['kind']];d=fx(cur,row['payload'],i)
  if j.sha(d)!=j.sha(row['detail']) or j.sha(cur)!=row['after_sha']:
   raise R39Hold('CAUSAL_REPLAY_DIFF_'+str(i)+'_'+row['kind'])
 if cur!=st or rev!=len(rows):raise R39Hold('REPLAY_FINAL_DIFF')
 return {'status':'PASS','events':rev,'head':h,'phase':st['phase'],'state_sha':j.sha(st)}

def backup(db,genesis,runners):
 ck=OUT/'checkpoints'/(db.stem+'_backup.sqlite')
 if ck.exists():raise R39Hold('CHECKPOINT_EXISTING')
 a=sqlite3.connect(db);z=sqlite3.connect(ck)
 try:a.backup(z)
 finally:z.close();a.close()
 r1=replay(db,genesis,runners);r2=replay(ck,genesis,runners)
 if r1!=r2:raise R39Hold('CHECKPOINT_REPLAY_MISMATCH')
 return {'name':ck.name,'sha256':sha_file(ck),'replay':'PASS','events':r1['events'],'head':r1['head']}

def run_reaction():
 db,gen=spawn(8129,'REACTION_SEQUENTIAL_VALID_DAMAGE')
 invalid=invalid_matrix(gen)
 concurrent=preflight_concurrent(db);nested=preflight_nested(db)
 runners={'REACTION_FIRST':reaction_first,'REACTION_SECOND':reaction_second,'REACTION_REFRESH':reaction_refresh}
 for kind,fn in runners.items():commit(db,kind,{'kind':kind,'tag':'REACTION_SEQUENTIAL_VALID_DAMAGE'},fn)
 audit=replay(db,gen,runners);ck=backup(db,gen,runners)
 # Repeated command is rejected before durable intent, independent later events no extra reaction.
 _,head,rev=checked(db)
 old=j.history(db)['events'][0]['cmd_id'];dupe=None
 try:j.event_commit(db,old,'REACTION_FIRST',{'kind':'REACTION_FIRST'},reaction_first)
 except j.LabHold as e:dupe=str(e)
 if dupe!='DUPLICATE COMMAND REJECTED':raise R39Hold('DUPLICATE_ID_NOT_REJECTED')
 st2,h2,r2=checked(db)
 if (h2,r2)!=(head,rev):raise R39Hold('DUPLICATE_MODIFIED_STATE')
 result={'scenario':'REACTION_SEQUENTIAL_VALID_DAMAGE','positive':'FIRST_TRIGGER_SLOT_SPENT;SECOND_REACTION_REJECTED;SECOND_ATTACK_UNBLOCKED;OWN_TURN_REFRESH','negative':invalid,'concurrent':concurrent,'nested':nested,'idempotency':'PASS_DUPLICATE_REJECTED','ledger':db.name,'ledger_sha':sha_file(db),'replay':audit,'checkpoint':ck,'world_effects':0}
 dump('R39B_REACTION_NEW_CASES.json',result)
 return result

def failure_runner(st,p,seq):
 # native mutation in discarded clone after prevalidation; never commits candidate.
 scene=native_scene(st);a,b_,c=list(st['actors']);d=dodge(scene,b_,24);_a=attack(scene,a,b_,24,d)
 if scene.actors[b_].reaction!=0:raise R39Hold('FAIL_INJECTION_PRECONDITION')
 raise RuntimeError('R39_CONTROLLED_FAULT_AFTER_NATIVE_BEFORE_SQLITE_COMMIT')

def run_failure():
 db,gen=spawn(8131,'REACTION_FAILURE_VALID_DAMAGE');s,h,v=checked(db)
 pending_message=None
 try:j.event_commit(db,'LAB-CMD-R39B-CONTROLLED-FAULT','R39_CONTROLLED_FAULT',{'fault':'AFTER_NATIVE_BEFORE_PUBLISH'},failure_runner)
 except j.LabHold as e:pending_message=str(e)
 with sqlite3.connect(f'file:{db}?mode=ro',uri=True) as c:
  meta=dict(c.execute('SELECT key,value FROM meta'));pending=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0];ev=c.execute('SELECT COUNT(*) FROM events').fetchone()[0];integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
 stored=json.loads(meta['state']);blocked=False
 try:j.load(db)
 except j.LabHold as e:blocked='UNKNOWN_EFFECT' in str(e)
 if any([pending!=1,ev!=0,int(meta['revision'])!=0,stored!=gen,meta['head']!=h,not blocked,integrity!='ok']):raise R39Hold('FAILPOINT_PARTIAL_PUBLISH')
 result={'scenario':'REACTION_FAILURE_VALID_DAMAGE','status':'EXPECTED_UNKNOWN_EFFECT_FROZEN_DO_NOT_RETRY','error':pending_message,'pending':pending,'events':ev,'revision':0,'head_unchanged':True,'hp_reaction_pa_unchanged':True,'loader_fail_closed':blocked,'integrity':'ok','intent_preserved_for_manual_reconciliation':True,'ledger':db.name,'ledger_sha':sha_file(db)}
 dump('R39B_FAILURE_AFTER_PREVALIDATION.json',result);return result

# Scheduler: 3 official species snapshots instantiated in an isolated synthetic turn fixture,
# WITHOUT claiming source-complete combat. R26 initiative tie rule, R18 turn engine,
# experimental skip of KO actor (R18 _next_turn did not implement this case).

def scheduler_initial(st,p,seq):
 if seq!=1 or st['phase']!='INIT':raise R39Hold('INIT_REJECT')
 result=r26.resolve_initial_state(st)
 refresh=r26.refresh_own_turn(st,st['active'])
 return {'initiative_native_R26':result,'refresh_R26':refresh,'source_kind':'SYNTHETIC_SCHEDULER_FIXTURE_GOAT_ATTRIBUTES','canonical_credit':0}

def scheduler_pass(st,p,seq):
 if st['phase']!='ACTIVE':raise R39Hold('NO_ACTIVE')
 before=st['active'];ifexpected=p['actor']
 if before!=ifexpected or st['actors'][before]['resource']['standard']!=1:raise R39Hold('INVALID_PASS_TURN')
 st['actors'][before]['resource']['standard']=0
 turn=j._next_turn(st)
 if st['actors'][st['active']]['resource']['hp']<=0:raise R39Hold('DEAD_TURN_LEGACY_BUG_DETECTED')
 refresh=r26.refresh_own_turn(st,st['active'])
 return {'passed':before,'turn_R18':turn,'refresh_R26':refresh,'actor_after':st['active'],'order':st['order'],'canonical_credit':0}

def scheduler_eliminate(st,p,seq):
 victim=p['actor']
 if st['phase']!='ACTIVE' or victim!=st['order'][1] or st['active']==victim:raise R39Hold('ELIMINATION_FIXTURE_WINDOW_INVALID')
 st['actors'][victim]['resource']['hp']=0
 return {'fixture':'SYNTHETIC_REMOVAL_NOT_AN_ATTACK','removed':victim,'hp':0,'canonical_credit':0}

def next_alive(st):
 if st['phase']!='ACTIVE':raise R39Hold('NOT_ACTIVE')
 before=st['active'];skipped=[]
 for i in range(len(st['order'])):
  event=j._next_turn(st)
  if st['actors'][st['active']]['resource']['hp']>0:
   return {'previous':before,'next':st['active'],'skipped_ko':skipped,'R18_advances':i+1,'round':st['round'],'underlying_turn':event}
  skipped.append(st['active'])
 raise R39Hold('NO_LIVING_ACTOR_NOT_AN_ACTIVE_COMBAT')

def scheduler_skip(st,p,seq):
 # demonstrate old next_turn will land on KO if next in order is dead,
 # and corrected additive wrapper safely skips without editing R18.
 if st['phase']!='ACTIVE':raise R39Hold('INVALID_PHASE')
 dead=[i for i in st['order'] if st['actors'][i]['resource']['hp']==0]
 if len(dead)!=1:raise R39Hold('NO_SINGLE_KO_FIXTURE')
 # force active to position just before the KO actor within order, as a synthetic turn fixture
 idx=st['order'].index(dead[0]);st['turn']=(idx-1)%len(st['order']);st['active']=st['order'][st['turn']]
 legacy=copy.deepcopy(st);j._next_turn(legacy)
 if legacy['active']!=dead[0]:raise R39Hold('LEGACY_DEAD_SKIP_NOT_REPRODUCED')
 fixed=next_alive(st)
 if st['active']==dead[0] or dead[0] not in fixed['skipped_ko']:raise R39Hold('R39_SKIP_FIX_INCOMPLETE')
 refresh=r26.refresh_own_turn(st,st['active'])
 st['r39']['skipped_dead'].append(dead[0])
 return {'legacy_failure_reproduced':True,'legacy_next':legacy['active'],'ko_actor':dead[0],'experimental_additive_fix':fixed,'refresh_R26':refresh,'canonical_credit':0}

def scheduler_seed(tied):
 for seed in range(7210,7470):
  t=[j.dice(seed,0,'initiative:'+aid,1,6)[0]+8 for aid in ('LAB_R39_GOAT_A','LAB_R39_GOAT_B','LAB_R39_GOAT_C')]
  flag=len(set(t))<3
  if flag==tied:return seed,t
 raise R39Hold('SEED_TIE_NOT_FOUND')

def run_scheduler(tied):
 seed,totals=scheduler_seed(tied);tag='SCHEDULER_TIED' if tied else 'SCHEDULER_UNTIED'
 db,gen=spawn(seed,tag)
 runners={'INIT_3_ACTORS':scheduler_initial,'TURN_PASS':scheduler_pass,'LAB_ELIMINATION':scheduler_eliminate,'SKIP_KO_CORRECTED':scheduler_skip}
 commit(db,'INIT_3_ACTORS',{'seed':seed},scheduler_initial)
 for i in range(5):
  st,_,_=checked(db)
  commit(db,'TURN_PASS',{'actor':st['active']},scheduler_pass)
 st,_,_=checked(db)
 # ensure victim is inactive for elimination
 victim=st['order'][1]
 if st['active']==victim:commit(db,'TURN_PASS',{'actor':st['active']},scheduler_pass)
 commit(db,'LAB_ELIMINATION',{'actor':victim},scheduler_eliminate)
 commit(db,'SKIP_KO_CORRECTED',{'kind':'SKIP_KO'},scheduler_skip)
 replay_result=replay(db,gen,runners)
 ck=backup(db,gen,runners)
 st,_,_=checked(db);init=j.history(db)['events'][0]['detail']['initiative_native_R26']
 if tied and not init['tie_resolution']['rerolls']:raise R39Hold('R26_TIE_NOT_TESTED')
 if not tied and init['tie_resolution']['rerolls']:raise R39Hold('UNEXPECTED_TIE_REROLL')
 result={'seed':seed,'initial_dice_totals':totals,'tied':tied,'authority':'R26_EXPLICIT_MASTER_DES_THEN_ONLY_TIED_REROLL','native_R26_tie':init['tie_resolution'],'source_kind':'SYNTHETIC_3_ACTOR_SCHEDULER_FIXTURE_SOURCE_MATCHING_GOAT_B1','new_bug':'R18__next_turn_does_not_skip_KO_IN_MULTI_ACTOR' if tied else None,'new_fix':'R39_NEXT_ALIVE_EXPERIMENTAL_ADDITIVE','replay':replay_result,'checkpoint':ck,'ledger_file':db.name,'ledger_sha':sha_file(db),'terminal_fight_credit':0,'canonical_effects':0}
 dump(f'R39_{tag}.json',result);return result

if __name__=='__main__':
 results={'schema':'R39B_SOURCE_CORRECTED_REACTION_TESTS_V1','REACTION':run_reaction(),'FAULT':run_failure(),'no_prior_fights_replayed':True, 'source_damage_range':'1d6+FOR13 = 14..19', 'source_validated_damage_used':19}
 dump('R39B_SOURCE_CORRECTED_RESULT.json',results)
 print(json.dumps({'reaction':results['REACTION']['replay'],'fault':results['FAULT']['status'],'scheduler':'NOT_RERUN_OR_RELABELED'},indent=2,ensure_ascii=False))
