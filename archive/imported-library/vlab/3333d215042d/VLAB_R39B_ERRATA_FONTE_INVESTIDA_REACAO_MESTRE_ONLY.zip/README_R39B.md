# R39B — Microcorreção, não uma nova rodada de combate

O ZIP R39 original continua na mesma Biblioteca e serve às provas sintéticas de scheduler e ao holdout estatístico. Seu teste de Reações com bruto20 é **mecanicamente inválido como fonte-real**, mesmo tendo hash/replay íntegros; esta R39B é a correção preservacional e **não reetiqueta os registros anteriores**.

Execute `python verify_r39b_standalone.py` após extração do pacote R39B; usa somente a stdlib e não importa o motor. Os arquivos de `ledgers/` são novos, com prefixo R39 mas tags diferentes; nunca misturar com R39 original. O failpoint `REACTION_FAILURE_VALID_DAMAGE` deve preservar revision0, pending1 e sem evento; não apague a intenção nem reaplique o comando.

A implementação nativa original pode ser auditada com os scripts R27/R36 já existentes na Biblioteca; `r39b_source_corrected_reactions.py` é apenas roteiro de cópia/adaptação para nova transação, não deve ser usado contra estas mesmas bases. Não foi modificada regra, ficha ou campanha.
