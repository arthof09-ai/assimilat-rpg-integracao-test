# ERRATA R39B — Fonte da Investida / reparo preservacional

**OP-VLAB-FUSION-SANDBOX-01 · CM-000006 · MESTRE-SIDE · 15/10/2026**

## Defeito detectado antes da sincronização documental R39

A primeira bateria técnica da R39 foi integralmente persistida na Biblioteca como `VLAB_R39_GATES_REACAO_SCHEDULER_RNG_MESTRE_ONLY.zip` (SHA256 `2a2a5f6774da7d917d61a66b1cdb206de5195e2665c8807bf5c8c4a46ca09892`). A auditoria do ledger e replay estava íntegra, mas sua segunda Investida usou **dano bruto 20**, maior que o máximo **19** da habilidade `1d6+FOR13` da Cabra Bronze1. O valor bruto foi aplicado após defesa declinada, resultando em líquido15 e HP38→23. Isso é **falha mecânica do dado de entrada**, não falha de SQLite. O verificador original avaliava cadeia/replay/slot/mitigação, mas **não verificava o domínio da fórmula da habilidade**. Portanto:

- A bateria R39 antiga de Reações é **QUARENTENADA para a afirmação de ação fonte-real integralmente legal**. Seu replay e seu ledger continuam historicamente verificáveis mas não autorizam esse crédito.
- As duas provas de scheduler **sintéticas com 3 atores** e o holdout600 **não dependem da fórmula do dano** e permanecem provas locais parciais. O pacote R39 original NÃO foi regravado, ocultado ou removido.
- As intenções de falha intencional R39 permanecem preservadas. Nenhum ataque R34–R38 foi repetido.

## Correção material executada em transação totalmente nova

A **R39B** usou scripts de teste em cópia nova de R27/R36, sem alterar v0.8.1/R18/R26. Um novo banco `R39_REACTION_SEQUENTIAL_VALID_DAMAGE.sqlite` com **seed8129**, totalmente separado da R39, testou novamente o requisito com entrada válida: ataque `1d6=5` + FOR13 + Luta6 = 24; dano `1d6=6` + FOR13 = **19** (máximo legítimo).

- Evento 1: Cabra B ativa Esquivar defesa26 antes do golpe24. Reação1→0; dano zero; Vida38.
- Evento 2: outra Cabra C provoca segundo gatilho no mesmo intervalo: nova Reação recusada sem modificar estado. Ataque24 legal resolve dano bruto19−RD5=**14**; B Vida38→**24**; ambos atacantes gastam separadamente suas Ações Padrão.
- Evento 3: início do turno próprio de B e refresh R26 reação0→1.

**3 eventos nativos publicados, 3/3 replay causal PASS e checkpoint lógico íntegro.** Auditor **independente do motor** agora exige, além de integridade, `attack_total ∈ [20,25]`, `bruto ∈ [14,19]`, conversão dos dados dentro de 1–6, mitigação RD5, consumo de slot e Vida. O arquivo `verify_r39b_standalone.py` comprovou tudo em modo só leitura. Gatilhos concorrentes/aninhados permanecem na R39 antiga classificados somente como **rejeição pré-intent sem prioridade inventada**.

A R39B preserva ainda um segundo ensaio em novo banco `R39_REACTION_FAILURE_VALID_DAMAGE.sqlite`, seed8131: simulação controlada após cálculo nativo no clone e antes do COMMIT, resultando em 1 intenção pendente, 0 eventos, revisão0, sem gasto/HP persistido. **Esse segundo banco fica congelado e não recebe retry**, como o primeiro failpoint R39. Não confundir essas duas intenções de engenharia com a seed53 histórica.

## Contratos terminais / continuidade

A prova corrigida cobre corretamente a dupla oportunidade sequencial e a atomicidade com dano fonte-válido. **Não resolve** precedência de gatilhos concorrentes/Contra-ataque aninhado. `REACTION_TRIGGER_AND_SINGLE_USE` continua **TÉCNICO PARCIAL / TERMINAL HOLD**, scheduler e RNG continuam técnicos parciais na R39 original, 0/17 terminais, 0/1.875 células, zero combates canônicos. Writer, lease, epoch, fencing, GREEN e NAC-PASS produtivo HOLD; IBX-56 BLOCKED-EXTERNAL.

**Ponto exato de retomada:** usar somente o banco/recibos **R39B** como prova nova de duplo gatilho sequencial fonte-válido. Manter os bancos/recibos R39 originais em histórico **com a ressalva**, utilizar R39 original somente para scheduler e RNG onde mecanicamente pertinente. Antes de qualquer nova bateria, verificar domínio de dados/dado/dano autorizado e não apenas resultados/ledger.
