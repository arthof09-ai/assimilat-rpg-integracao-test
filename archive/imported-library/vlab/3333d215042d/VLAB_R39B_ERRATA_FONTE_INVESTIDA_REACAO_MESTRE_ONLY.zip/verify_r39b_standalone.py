#!/usr/bin/env python3
"""Read-only independent test of source-corrected R39B attack events and frozen fault.
Does not import the combat engine. A valid Cabra Investida MUST be 1d6+FOR13=14..19.
"""
import json,hashlib,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parent
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
sha=lambda v:hashlib.sha256(canon(v).encode()).hexdigest()

def db(name):
 path=ROOT/'ledgers'/f'R39_{name}.sqlite'
 with sqlite3.connect(f'file:{path}?mode=ro',uri=True) as c:
  assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  meta=dict(c.execute('SELECT key,value FROM meta'))
  n=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
  rs=c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
 st=json.loads(meta['state']);h=meta['genesis'];last=None
 assert int(meta['revision'])==len(rs)
 for ix,cmd_id,prev,rjson,rsha,before,after in rs:
  row=json.loads(rjson)
  assert row['seq']==ix and row['cmd_id']==cmd_id and row['prev']==prev==h and sha(row)==rsha
  assert row['before_sha']==before and row['after_sha']==after
  assert row['official_effects']==0 and row['synthetic'] is True
  if last is not None:assert before==last
  h=rsha;last=after
 assert meta['head']==h and (last is None or last==sha(st))
 assert all(v['source_page_id']=='391c2b32-4ede-8252-b0cc-810423cdbfa6' for v in st['actors'].values())
 return {'head':h,'events':[json.loads(row[3]) for row in rs],'pending':n,'state':st}

a=db('REACTION_SEQUENTIAL_VALID_DAMAGE')
f=db('REACTION_FAILURE_VALID_DAMAGE')
assert len(a['events'])==3 and a['pending']==0
assert len(f['events'])==0 and f['pending']==1
assert [row['kind'] for row in a['events']]==['REACTION_FIRST','REACTION_SECOND','REACTION_REFRESH']
reaction=a['events'][0]['detail']['native_events'];assert reaction[0]['action']=='ESQUIVAR'
assert reaction[0]['attack_score']==24 and reaction[0]['defense_exact']=='26' and reaction[0]['consumes_reaction'] is True
assert reaction[1]['defense_negated'] and reaction[1]['net']==0 and reaction[1]['after_hp']==38
second=a['events'][1]['detail'];assert second['second_reaction_preflight']=='REJECTED_NO_SLOT'
att=second['native_events'][0]
# Independent mechanic check: source 1d6+13 = 14...19, score 1d6+13+6 = 20...25, RD5.
assert 20<=att['roll_score']<=25 and (att['roll_score']-19) in range(1,7)
assert 14<=att['raw']<=19 and (att['raw']-13) in range(1,7)
assert att['roll_score']==24 and att['raw']==19 and att['rd_applied']==5 and att['net']==14
assert att['before_hp']==38 and att['after_hp']==24
assert a['events'][2]['detail']['refresh_R26']['before']==0 and a['events'][2]['detail']['refresh_R26']['after']==1
assert f['state']['actors']['LAB_R39_GOAT_B']['resource']['hp']==38 and f['state']['actors']['LAB_R39_GOAT_B']['resource']['reaction']==1
for i in ('R39_REACTION_SEQUENTIAL_VALID_DAMAGE','R39_REACTION_FAILURE_VALID_DAMAGE'):
 src=db(i.removeprefix('R39_'))
 assert src['pending']==(1 if 'FAILURE' in i else 0)
 if 'FAILURE' not in i:
  with sqlite3.connect(f'file:{ROOT}/checkpoints/{i}_backup.sqlite?mode=ro',uri=True) as c:
   assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  # source and backup are logically equivalent
  b=ROOT/'checkpoints'/f'{i}_backup.sqlite';
  with sqlite3.connect(f'file:{b}?mode=ro',uri=True) as c:
   md=dict(c.execute('SELECT key,value FROM meta'))
   assert md['head']==src['head'] and json.loads(md['state'])==src['state']
result={'status':'PASS_R39B_SOURCE_CORRECTED','new_source_legal_reaction_transitions':3,'source_damage_gross':19,'source_damage_range':[14,19],'source_attack_score':24,'reaction_count':1,'second_reaction_rejected':True,'hp_after_second_attack':24,'fault_pending_frozen':1,'historical_r39_invalid_event_not_promoted':True,'terminal_contracts_certified':0}
print(json.dumps(result,indent=2,ensure_ascii=False))
