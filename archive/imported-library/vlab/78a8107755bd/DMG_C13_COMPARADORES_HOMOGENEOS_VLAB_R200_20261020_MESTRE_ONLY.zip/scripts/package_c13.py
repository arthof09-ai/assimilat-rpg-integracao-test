from pathlib import Path
import json,zipfile,hashlib
ROOT=Path(__file__).resolve().parent.parent
OUT=Path('/mnt/data/DMG_C13_COMPARADORES_HOMOGENEOS_VLAB_R200_20261020_MESTRE_ONLY.zip')
include=['README_C13_PORTABLE.md','PSV_DMG_C13_COBERTURA_E_VLAB_R200_20261020_MESTRE_ONLY.md',*sorted(str(x.relative_to(ROOT)) for x in (ROOT/'scripts').glob('*.py')),*sorted(str(x.relative_to(ROOT)) for x in (ROOT/'output').glob('*') if x.suffix in ('.json','.csv','.md'))]
assert len(include)==len(set(include))
files=[]
for n in include:
 d=(ROOT/n).read_bytes();files.append({'name':n,'size':len(d),'sha256':hashlib.sha256(d).hexdigest()})
manifest={'operation':'OP-DMG-CORPUS-EMP-01','as_of':'2026-10-20','scope':'MASTER_SIDE_READ_ONLY_SCIENTIFIC_DELTA_C13','baseline':'DMG-RANK-01 v1.1 UNCHANGED','formal_f0':'4/8 HOLD','files':files,'external_inputs':[{'name':'DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.zip','sha256':'d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e'},{'name':'DMG_C12_CIENCIA_CHASSIS_FIP_TRIAGEM_20261020_MESTRE_ONLY.zip','sha256':'19c9b8799d161e3eaa577ec30c8a10ec0ebe7cf22533f73c393b68df3e4218a4'},{'name':'VLAB_R200_R203_FISICO_GEOMETRIA_COMBATES_MESTRE_ONLY.zip','sha256':'6e462fa907f489ce72a5ee514203c69b995253f15cc2b05273fd44b7b8144f74'}],'note':'Does not embed external historical 18MB VLAB binary or all prior packages; original accessible in existing Library and re-verify by SHA'}
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in include: z.write(ROOT/n,arcname=n)
 z.writestr('C13_SHA256_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None and len(z.namelist())==len(include)+1
 for e in files:
  d=z.read(e['name']);assert hashlib.sha256(d).hexdigest()==e['sha256'] and len(d)==e['size']
print(json.dumps({'file':str(OUT),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'size':OUT.stat().st_size,'members':len(include)+1,'manifest_entries':len(include)},indent=2))
