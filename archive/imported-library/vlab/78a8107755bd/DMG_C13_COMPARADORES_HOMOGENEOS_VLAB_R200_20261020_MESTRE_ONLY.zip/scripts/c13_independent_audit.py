"""Independent C13 arithmetic and denominator audit without invoking build_c13 formulas."""
import csv,json,pathlib,itertools,collections,hashlib,zipfile,os,math
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'output'
def csvread(p):
 with (OUT/p).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
rows=csvread('C13_SOURCE_FAMILY_EFFECT_OCCURRENCES.csv')
pairs=csvread('C13_MATCHED_FAMILY_DECOMPOSITION.csv')
roots=csvread('C13_A6_STRUCTURAL_ROOT_TRAVERSAL_16.csv')
lineage=csvread('C13_LINEAGE_AND_NO_DUPLICATES.csv')
fights=csvread('C13_R200_DB_LEVEL_FIGHT_RECEIPTS_32.csv')
groups=csvread('C13_R200_SCOPED_GROUP_METRICS.csv')
thresholds=csvread('C13_R200_HIT_THRESHOLD_AND_RD_TEST.csv')
checks=[]
def verify(tag,x):checks.append((tag,bool(x)));assert x,tag
verify('14 sources',len(rows)==14 and len(set(r['page_uuid'] for r in rows))==14)
verify('6 definitions',len({(r['family'],r['effect_name']) for r in rows})==6)
verify('8 controlled same-family contrasts',len(pairs)==8)
verify('lineage matches',len(lineage)==14 and sum(r['already_in']=='NOT_IN_THESE_FOUR_LOCAL_BASELINES' for r in lineage)==9)
verify('A6 structural node counts',len(roots)==16 and sum(int(r['direct_child_refs']) for r in roots)==29)

# Rebuild arbitrary dice PMF by iterative convolution; don't use the original primary implementation.
lookup={r['url']:r for r in rows}
for r in rows:
 dist={int(r['attribute_literal_value']):1}
 for atom in r['intrinsic_dice_literal'].split('+'):
  n,f=map(int,atom.split('d'))
  for i in range(n):
   new=collections.defaultdict(int)
   for prev,count in dist.items():
    for roll in range(1,f+1):new[prev+roll]+=count
   dist=dict(new)
 N=sum(dist.values());mean=sum(k*c for k,c in dist.items())/N
 var=sum((k-mean)**2*c for k,c in dist.items())/N
 verify('PMF '+r['page_uuid'],abs(mean-float(r['gross_mean_conditional']))<1e-10 and abs(var-float(r['variance']))<5e-7 and min(dist)==int(r['gross_min']) and max(dist)==int(r['gross_max']))
for p in pairs:
 a,b=lookup[p['sourceA']],lookup[p['sourceB']]
 d=float(b['gross_mean_conditional'])-float(a['gross_mean_conditional'])
 verify('pair '+p['pair'],a['family']==b['family'] and a['effect_name']==b['effect_name'] and abs(d-float(p['delta_mean']))<1e-9 and abs(float(p['delta_attribute'])+float(p['delta_intrinsic_dice'])-d)<1e-9)
verify('Hidrargos printed suffix ambiguity',[(r['printed_fixed_damage_note'],float(r['gross_mean_conditional'])) for r in rows if r['family']=='Hidrargos']==[('161',159.0),('209',210.0),('295',296.5)])
verify('R200 32 attempts and 30 started',len(fights)==32 and sum(r['status']=='PRECOMMIT_TIE_HOLD' for r in fights)==2 and sum(r['status']!='PRECOMMIT_TIE_HOLD' for r in fights)==30)
verify('R200 16 KO 14 censored',sum(r['status']=='FINISHED' for r in fights)==16 and sum(r['status']=='CENSORED_HORIZON' for r in fights)==14)
verify('R200 1497 commits 1467 attack events',sum(int(r['commits']) for r in fights)==1497 and sum(int(r['attacks']) for r in fights)==1467)
verify('R200 group sum',len(groups)==4 and sum(int(r['started_fights']) for r in groups)==30 and sum(int(r['attacks']) for r in groups)==1467)
for r in thresholds:
 if r['attacker']=='ED-REF-01-P1':
  fixed=int(r['attack'].split('+')[1]);ca=34
 else:fixed=24;ca=float(r['opponent_CA'])
 results=[sum(d)+fixed for d in itertools.product(range(1,7),repeat=2)]
 count=sum(x>ca for x in results)
 verify('attack threshold '+r['attack']+' CA'+r['opponent_CA'],count==int(r['successful_outcomes']) and abs(count/36-float(r['chance_success']))<1e-14)
post=[max(0,sum(t)+6-15) for t in itertools.product(range(1,9),repeat=3)]
mean=sum(post)/len(post)
verify('3d8+6 post RD15',abs(mean-4.74609375)<1e-12)
verify('ordinary baseline expected zero',float(thresholds[0]['damage_per_ordinary_attempt_conditional'])==0)
verify('exact R200 baseline SHA',hashlib.sha256(pathlib.Path(os.environ.get('C13_SOURCE_DIR','/mnt/data/dmg_c13_incoming'),'VLAB_R200_R203_FISICO_GEOMETRIA_COMBATES_MESTRE_ONLY.zip').read_bytes()).hexdigest()=='6e462fa907f489ce72a5ee514203c69b995253f15cc2b05273fd44b7b8144f74')
result={'status':'PASS_INDEPENDENT_C13','checks':len(checks),'issues':[],'r200_original_db_30_were_inspected_by_build':'verify C13_R200_DB_LEVEL_FIGHT_RECEIPTS_32.csv and original R200 ZIP via builder','scope':'new C13 math and denominator checks, not C11/C12 regression rerun','source_fields_are_manual_not_live_notion_in_standalone_mode':True}
(OUT/'C13_INDEPENDENT_QA.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(result)
