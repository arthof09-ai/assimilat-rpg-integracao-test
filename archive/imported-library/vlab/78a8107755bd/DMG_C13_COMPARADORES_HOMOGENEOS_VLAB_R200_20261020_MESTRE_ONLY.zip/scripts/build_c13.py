"""DMG C13: scientific read-only extraction over Notion-reviewed literal snippets + VLAB R200 receipts.
All Notion source literals were manually transcribed from connected Mestre-side fetches 2026-10-20.
R200 SQLite source bytes are read from ZIP and inspected in temporary immutable READ-ONLY copies, never modified or executed as combat.
"""
from __future__ import annotations
import csv, json, zipfile, hashlib, pathlib, sqlite3, itertools, collections, math, tempfile, os
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
SOURCES=pathlib.Path(os.environ.get('C13_SOURCE_DIR','/mnt/data/dmg_c13_incoming'))
VLAB=SOURCES/'VLAB_R200_R203_FISICO_GEOMETRIA_COMBATES_MESTRE_ONLY.zip'
C11=SOURCES/'DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.zip'
C12=SOURCES/'DMG_C12_CIENCIA_CHASSIS_FIP_TRIAGEM_20261020_MESTRE_ONLY.zip'
SOURCE_DATE='2026-10-20'
# page-id, family, leaf title, body rank, item parent rank folder, ability, literal, attribute value, parsed dice, displayed note, mechanical context, primary reference status
PAGES=[
('56ac2b324ede8352868101e11ea16355','Sussurro Celestial','Prata 1','Prata 1','Ouro 5 · 8','Lâmina de Brisa','1d6 + INT',30,[(1,6)],'','vento; action/PA unspecified','discovery; family parent rank discordant'),
('5e9c2b324ede83ed99078151805dec0b','Sussurro Celestial','Prata 5','Prata 5','Ouro 5 · 8','Lâmina de Brisa','2d6 + INT',45,[(2,6)],'','vento; text 5 PA adjacent to technique; cadence must be verified','discovery; family parent rank discordant'),
('442c2b324ede8364870a814350dd5051','Sussurro Celestial','Ouro 1','Ouro 1','Ouro 5 · 8','Lâmina de Brisa','2d4 + INT',26,[(2,4)],'','vento; PA unspecified','discovery; family parent rank discordant'),
('597c2b324ede8242bd5881027ef8d21f','Sussurro Celestial','Ouro 5','Ouro 1','Ouro 5 · 8','Lâmina de Brisa','2d4 + INT',40,[(2,4)],'','vento; PA unspecified','TITLE_BODY_RANK_CONFLICT; exclude strict O5'),
('034c2b324ede83ffa7118144011beaf3','Rinolupo','Prata 1','Prata 1','Ouro 5 · 3','Investida Feroz','2d6+FOR',30,[(2,6)],'','charge; accuracy/PA unknown','discovery; parent top rank discordant'),
('a47c2b324ede821f834481bef49fb8e3','Rinolupo','Prata 4','Prata 4','Ouro 5 · 3','Investida Feroz','2d6+FOR',38,[(2,6)],'','charge; accuracy/PA unknown','discovery; parent top rank discordant'),
('d58c2b324ede8208b24b014eaaf3ac5c','Rinolupo','Ouro 5','Prata 4','Ouro 5 · 3','Investida Feroz','2d6+FOR',56,[(2,6)],'','charge; accuracy/PA unknown','TITLE_BODY_RANK_CONFLICT; exclude strict O5'),
('b85c2b324ede824dbfb301ccd441a96e','Hidrargos','Ouro 4 (Titã)','Ouro 4','Ouro 4','Mordida','6d12+120 / 161 de Dano',120,[(6,12)],'161','Titan; text slash numerical benchmark not necessarily mean','exploratory; numeric discrepancy'),
('bc7c2b324ede82ef97330199ec466b1b','Hidrargos','Ouro 5 (Titã)','Ouro 4','Ouro 4','Mordida','10d12+145 / 209 de Dano',145,[(10,12)],'209','Titan; text slash numerical benchmark not necessarily mean','TITLE_BODY_RANK_CONFLICT; exclude strict O5'),
('31ec2b324ede8305beae81f92349faa9','Hidrargos','Ouro Negro 1 (Titã)','Ouro 4','Ouro 4','Mordida','19d12+173 / 295 de Dano',173,[(19,12)],'295','Titan; text slash numerical benchmark not necessarily mean','TITLE_BODY_RANK_CONFLICT; exclude strict ON1'),
('a01c2b324ede8347b691819d3509d7d7','Crocossuário','Bronze 5','Bronze 5','Prata 2 · 5','Mordida Trituradora','1d6+1d4+FOR',22,[(1,6),(1,4)],'','physical bite; source already C05; body vs ancestor conflict','C05_KNOWN_NOT_NEW'),
('ca3c2b324ede83ef923501ae00136097','Crocossuário','Prata 2 (Titã)','Prata 2','Prata 2 · 5','Mordida Trituradora','2d6+FOR',32,[(2,6)],'','physical bite; Titan context changed','NEW_OCCURRENCE_P2_TITAN; not strict B5->P2 pair'),
('eddc2b324ede829f8a75011e8acbf429','Galinha Demoníaca','Bronze 1','Bronze 1','NOT_REOPENED_PARENT','Patada','1d4+DES',13,[(1,4)],'','physical slash; proficiency hypothesis VLAB','R200_TEST_ACTOR_ALREADY_KNOWN'),
('be5c2b324ede832e8b7a81c5460571c1','Lobo da Caverna','Prata 1','Prata 1','Prata 5 · 2','Patada','1d6+FOR',24,[(1,6)],'','physical; R200 Lobo profile conditional','R200_TEST_ACTOR_ALREADY_KNOWN'),
]
EDIT={'56ac2b324ede8352868101e11ea16355':'2026-10-01T18:00:42.552Z','5e9c2b324ede83ed99078151805dec0b':'2026-10-01T18:00:42.615Z','442c2b324ede8364870a814350dd5051':'2026-10-01T18:00:42.678Z','597c2b324ede8242bd5881027ef8d21f':'2026-10-01T18:00:42.749Z','034c2b324ede83ffa7118144011beaf3':'2026-10-01T18:00:46.623Z','a47c2b324ede821f834481bef49fb8e3':'2026-10-01T18:00:42.492Z','d58c2b324ede8208b24b014eaaf3ac5c':'2026-10-01T18:00:42.562Z','b85c2b324ede824dbfb301ccd441a96e':'2026-10-01T18:00:39.410Z','bc7c2b324ede82ef97330199ec466b1b':'2026-10-01T18:00:39.466Z','31ec2b324ede8305beae81f92349faa9':'2026-10-01T18:00:39.542Z','a01c2b324ede8347b691819d3509d7d7':'2026-10-01T18:00:40.722Z','ca3c2b324ede83ef923501ae00136097':'2026-10-01T18:00:42.086Z','eddc2b324ede829f8a75011e8acbf429':'2026-10-01T18:00:52.905Z','be5c2b324ede832e8b7a81c5460571c1':'2026-10-01T18:00:33.930Z'}
ROOT_NODES=['046c2b324ede821db383812b78d704ad','05bc2b324ede820ea4fa01c29fb8df0b','0a2c2b324ede8386880b01c6b7d57ef5','0a8c2b324ede82ad9a7d01ca4193f207','0a9c2b324ede832eb0388146569ad805','104c2b324ede836da57881fdfe668b06','104c2b324ede83ffa513014969fdb328','129c2b324ede836ba89e015bf903c37a','013c2b324ede82b9961601f3102a3719','139c2b324ede8220b81901880deede16','3c9c2b324ede83888c67810ed028a9ee','4e9c2b324ede82328cf201e22a567813','845c2b324ede839f87eb01a3850f1729','a6dc2b324ede83a78f31819746deee1d','b24c2b324ede82ebb78e0193497197ea','efac2b324ede8371a6eb01d9908e450a']

def save_csv(name,rows):
 if not rows: raise ValueError(name)
 fields=list(rows[0]);withopen=OUT/name
 with withopen.open('w',newline='',encoding='utf-8') as f:
  writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)

def save_json(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

def physical_math(dice,bonus):
 mean=sum(n*(s+1)/2 for n,s in dice)+bonus
 variance=sum(n*(s*s-1)/12 for n,s in dice)
 return mean,variance,sum(n for n,s in dice)+bonus,sum(n*s for n,s in dice)+bonus

def exact_pmf(dice,bonus):
 dist=collections.Counter({bonus:1})
 for n,faces in dice:
  for _ in range(n):
   nd=collections.Counter()
   for x,c in dist.items():
    for d in range(1,faces+1): nd[x+d]+=c
   dist=nd
 return dist

rows=[]
for id, family,title,body,parent,ability,literal,attr,dice,listed,context,status in PAGES:
 mean,variance,low,high=physical_math(dice,attr)
 assert sum(exact_pmf(dice,attr).values())==math.prod(s**n for n,s in dice)
 rows.append({'page_uuid':id,'url':f'https://app.notion.com/p/{id}','last_edited_at':EDIT[id],'readback_date':SOURCE_DATE,'family':family,'leaf_title_rank':title,'body_rank':body,'species_parent_rank':parent,'effect_name':ability,'formula_literal':literal,'attribute_literal_value':attr,'intrinsic_dice_literal':'+'.join(f'{n}d{s}' for n,s in dice),'attribute_is_external':True,'intrinsic_dice_mean':round(mean-attr,6),'gross_mean_conditional':round(mean,6),'variance':round(variance,6),'gross_min':low,'gross_max':high,'attribute_share':round(attr/mean,6),'printed_fixed_damage_note':listed or 'NONE','printed_minus_formula_mean':round(float(listed)-mean,6) if listed else 'NA','cost_or_condition_context':context,'admission_state':status,'claim_scope':'LAB_ANALYTICAL_NOT_CANONICAL_REBALANCE'})
save_csv('C13_SOURCE_FAMILY_EFFECT_OCCURRENCES.csv',rows)
# Existing corpus identities are reused rather than counted as new definitions.
with zipfile.ZipFile(C11) as z:
 known_c11={r['source_uuid'] for r in csv.DictReader(z.read('C11_19_EFFECTS_SOURCE_SCOPED.csv').decode('utf-8-sig').splitlines())}
 known_c05={r['page_uuid'] for r in csv.DictReader(z.read('source_snapshots/C05_DAMAGE_EFFECTS_NORMALIZED_58.csv').decode('utf-8-sig').splitlines())}
with zipfile.ZipFile(C12) as z:
 known_c12={r['page_uuid'] for r in csv.DictReader(z.read('output/C12_SCREENING_NOTION_25_PAGES.csv').decode('utf-8-sig').splitlines())}
known_vlab={'eddc2b324ede829f8a75011e8acbf429','be5c2b324ede832e8b7a81c5460571c1'}
lineage=[]
for x in rows:
 id=x['page_uuid'];references=[]
 if id in known_c11:references.append('C11')
 if id in known_c05:references.append('C05')
 if id in known_c12:references.append('C12_SCREEN_ONLY')
 if id in known_vlab:references.append('VLAB_R200')
 lineage.append({'page_uuid':id,'family':x['family'],'effect':x['effect_name'],'already_in':';'.join(references) or 'NOT_IN_THESE_FOUR_LOCAL_BASELINES','first_formula_admission_C13':not (id in known_c11 or id in known_c05 or id in known_vlab),'was_screened_C12':id in known_c12,'classification_issue':x['admission_state']})
save_csv('C13_LINEAGE_AND_NO_DUPLICATES.csv',lineage)

# Twenty-nine direct child URLs read from 16 A6 species-root pages; only a subset of child leaves have verified effect formulas.
ROOT_META=[('Camaratã',2),('Abissalvorax',3),('Espectro de Sangue',1),('Cavalo Marinho',1),('Hidrargos',3),('Tubarão com Tentáculos',1),('Dinossauro Aquático',3),('Draquilarto',1),('Leão Celestial',1),('Sussurro Celestial',4),('Morcego Gasoso',1),('Aetheria',2),('Salamence',1),('Zephyrax',2),('Grifo',2),('Águia Colossal',1)]
assert len(ROOT_META)==len(ROOT_NODES) and sum(n for _,n in ROOT_META)==29
save_csv('C13_A6_STRUCTURAL_ROOT_TRAVERSAL_16.csv',[{'a6_root_uuid':id,'family_readback':name,'direct_child_refs':n,'root_url':f'https://app.notion.com/p/{id}','state':'PHYSICAL_SPECIES_ROOT_FETCH_NOT_ALL_CHILD_LEAVES_READ','scope':'8 Água + 8 Vento; no universal coverage claim'} for id,(name,n) in zip(ROOT_NODES,ROOT_META)])

compare_groups=[('Sussurro P1→P5',0,1),('Sussurro P5→O1',1,2),('Sussurro O1→O5 CONFLICT',2,3),('Rinolupo P1→P4',4,5),('Rinolupo P4→O5 CONFLICT',5,6),('Hidrargos O4→O5 CONFLICT',7,8),('Hidrargos O5→ON1 CONFLICT',8,9),('Crocossuário B5→P2 TITAN / ANCESTOR-CONFLICT',10,11)]
comparisons=[]
for name,ai,bi in compare_groups:
 a,b=rows[ai],rows[bi];d=b['gross_mean_conditional']-a['gross_mean_conditional'];attr=b['attribute_literal_value']-a['attribute_literal_value'];dice=b['intrinsic_dice_mean']-a['intrinsic_dice_mean']; assert abs(d-attr-dice)<1e-9
 comparisons.append({'pair':name,'sourceA':a['url'],'sourceB':b['url'],'source_rankA':a['leaf_title_rank'],'source_rankB':b['leaf_title_rank'],'meanA':a['gross_mean_conditional'],'meanB':b['gross_mean_conditional'],'delta_mean':d,'delta_attribute':attr,'delta_intrinsic_dice':dice,'attribution_attribute_fraction_of_signed_delta':round(attr/d,8) if d else None,'rank_comparability':'EXPLORATORY_SOURCE_CLASSIFICATION_CONFLICT_OR_TITAN' if 'CONFLICT' in name or 'TITAN' in name else 'WITHIN_FAMILY_SOURCE_SCOPED_ONLY_NOT_RE_ADJUDICATED','caution':'NOT_INDEPENDENT_SAME_FAMILY; repeated named effect across variants; not population progression'})
save_csv('C13_MATCHED_FAMILY_DECOMPOSITION.csv',comparisons)

for fn,expected in [(C11,'d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e'),(C12,'19c9b8799d161e3eaa577ec30c8a10ec0ebe7cf22533f73c393b68df3e4218a4'),(VLAB,'6e462fa907f489ce72a5ee514203c69b995253f15cc2b05273fd44b7b8144f74')]:
 assert hashlib.sha256(fn.read_bytes()).hexdigest()==expected,fn

# Independent, in-memory SQLite readback of all 30 initiated R200 combat DBs, no engine execution.
with zipfile.ZipFile(VLAB) as z:
 manifest=json.loads(z.read('R200_SHA256_MANIFEST.json'))['files'];assert len(manifest)==85
 for fn,e in manifest.items():
  raw=z.read(fn);assert hashlib.sha256(raw).hexdigest()==e['sha256'] and len(raw)==e['size'],fn
 src=json.loads(z.read('new/evidence/R200_EXECUTED_FIGHTS.json'))
 stated=json.loads(z.read('new/evidence/R200_BENCHMARK_FROM_RECEIPTS.json'))
 fights=[];allatt=[]
 for battle in src:
  if battle['status']=='PRECOMMIT_TIE_HOLD':
   fights.append({'run_id':battle['id'],'level':battle['level'],'seed':battle['seed'],'policy':battle['policy'],'status':battle['status'],'winner':'','commits':0,'attacks':0,'hit_total':0,'ed_hits':0,'enemy_hits':0,'ed_hp_removed':0,'enemy_hp_removed':0,'hp_overkill_total':0,'db_sha':''})
   continue
  path='new/evidence/db/'+battle['db'];raw=z.read(path)
  with tempfile.TemporaryDirectory(prefix='c13_r200_readonly_') as tempdir:
   temp=pathlib.Path(tempdir)/'receipt.sqlite';temp.write_bytes(raw)
   db=sqlite3.connect('file:'+str(temp)+'?mode=ro&immutable=1',uri=True)
   entries=[json.loads(x[0]) for x in db.execute('select row_json from events order by seq')]
   db.close()
  assert len(entries)==battle['rev'] or len(entries)==battle['rev']+1,(battle['id'],len(entries),battle['rev'])
  atk=[q['detail']['attack'] for q in entries if q['kind']=='R200_SOURCE_SWORD_OR_BEAST_ATTACK']
  assert len(atk)==battle['attacks'],(battle['id'],len(atk),battle['attacks'])
  hits=collections.Counter();damage=collections.Counter();overkill=0
  for a in atk:
   who=a['from'];hits[who]+=bool(a['hit']);damage[who]+=a['hp_loss_actual'];overkill+=a['overkill']
   allatt.append({'run_id':battle['id'],'level':battle['level'],'seed':battle['seed'],'policy':battle['policy'],'attacker':who,'target':a['to'],'score':a['roll_score'],'target_ca':a['ca_exact'],'hit':bool(a['hit']),'critical':a['critical'],'gross':a['raw'],'rd':a['rd_applied'],'post_rd':a['net'],'actual_hp_removed':a['hp_loss_actual'],'overkill':a['overkill']})
  actor='ED-REF-01-B1' if battle['level']==1 else 'ED-REF-01-P1';enemy='GALINHA_B1' if battle['level']==1 else 'LOBO_P1'
  assert hits[actor]==battle['hits_by_actor'].get(actor,0),battle['id']
  assert hits[enemy]==battle['hits_by_actor'].get(enemy,0),battle['id']
  assert damage[actor]==battle['damage_effective_by_actor'].get(actor,0),battle['id']
  assert damage[enemy]==battle['damage_effective_by_actor'].get(enemy,0),battle['id']
  fights.append({'run_id':battle['id'],'level':battle['level'],'seed':battle['seed'],'policy':battle['policy'],'status':battle['status'],'winner':battle.get('winner') or '', 'commits':len(entries),'attacks':len(atk),'hit_total':len([a for a in atk if a['hit']]),'ed_hits':hits[actor],'enemy_hits':hits[enemy],'ed_hp_removed':damage[actor],'enemy_hp_removed':damage[enemy],'hp_overkill_total':overkill,'db_sha':hashlib.sha256(raw).hexdigest()})
 assert len(fights)==32 and len([f for f in fights if f['status']!='PRECOMMIT_TIE_HOLD'])==30
 assert sum(f['attacks'] for f in fights)==1467 and len(allatt)==1467
 assert sum(f['commits'] for f in fights)==1497
 group=collections.defaultdict(list)
 for f in fights:group[(f['level'],f['policy'])].append(f)
 grouped=[]
 for (lv,pol),ff in sorted(group.items()):
  ko=sum(f['status']=='FINISHED' for f in ff);cens=sum(f['status']=='CENSORED_HORIZON' for f in ff)
  edwins=sum(f['winner']==('ED-REF-01-B1' if lv==1 else 'ED-REF-01-P1') for f in ff)
  enemywins=sum(f['winner']==('GALINHA_B1' if lv==1 else 'LOBO_P1') for f in ff)
  g={'level':lv,'policy':pol,'attempted_policies':len(ff),'started_fights':len(ff)-sum(f['status']=='PRECOMMIT_TIE_HOLD' for f in ff),'precommit_ties':sum(f['status']=='PRECOMMIT_TIE_HOLD' for f in ff),'KO':ko,'censored':cens,'ed_wins':edwins,'enemy_wins':enemywins,'attacks':sum(f['attacks'] for f in ff),'ed_hits':sum(f['ed_hits'] for f in ff),'enemy_hits':sum(f['enemy_hits'] for f in ff),'ed_hp_removed':sum(f['ed_hp_removed'] for f in ff),'enemy_hp_removed':sum(f['enemy_hp_removed'] for f in ff)}
  known=stated['group_metrics'][f'{lv}|{pol}']
  for a,b in [('physical_fights','started_fights'),('terminal_KO','KO'),('censored','censored'),('attacks','attacks'),('ed_hits','ed_hits'),('enemy_hits','enemy_hits'),('hp_removed_by_ed','ed_hp_removed'),('hp_removed_by_enemy','enemy_hp_removed')]: assert known[a]==g[b],(lv,pol,a)
  grouped.append(g)
 save_csv('C13_R200_DB_LEVEL_FIGHT_RECEIPTS_32.csv',fights)
 save_csv('C13_R200_SCOPED_GROUP_METRICS.csv',grouped)
 # Exact prospective hit thresholds and post-RD for R200 P1, assuming ordinary no crit.
 d=exact_pmf([(3,8)],6);total=sum(d.values());mean_dmg=sum(max(0,k-15)*v for k,v in d.items())/total
 hit_table=[]
 for attack_modifier in [22,23,24,25,26]:
  pmf=exact_pmf([(2,6)],attack_modifier);den=sum(pmf.values());good=sum(v for k,v in pmf.items() if k>34);hit_table.append({'attacker':'ED-REF-01-P1','attack':f'2d6+{attack_modifier}','opponent_CA':'34','successful_outcomes':good,'total_outcomes':den,'chance_success':good/den,'sword_damage':'3d8+6','opponent_RD_physical':15,'conditional_post_RD_mean':mean_dmg,'damage_per_ordinary_attempt_conditional':good/den*mean_dmg,'status':'TEST_SENSITIVITY_NOT_LIVE_BUILD_MODIFICATION'})
 for targetca in [34.25,36.25]:
  pmf=exact_pmf([(2,6)],24);den=sum(pmf.values());good=sum(v for k,v in pmf.items() if k>targetca)
  hit_table.append({'attacker':'LOBO_P1','attack':'2d6+24','opponent_CA':str(targetca),'successful_outcomes':good,'total_outcomes':den,'chance_success':good/den,'sword_damage':'NO_APPLICATION','opponent_RD_physical':'NO_APPLICATION','conditional_post_RD_mean':'NO_APPLICATION','damage_per_ordinary_attempt_conditional':'NO_APPLICATION','status':'TEST_R200_NATIVE_ROLL_BONUS_EXTRACTED_NO_CRITICAL'})
 save_csv('C13_R200_HIT_THRESHOLD_AND_RD_TEST.csv',hit_table)
 assert grouped[0]['started_fights']==7 and grouped[1]['started_fights']==7
 assert sum(g['KO'] for g in grouped)==16 and sum(g['censored'] for g in grouped)==14
 assert sum(g['enemy_hits'] for g in grouped)==38
 summary={'operation':'OP-DMG-CORPUS-EMP-01','r200_original_sha256':hashlib.sha256(VLAB.read_bytes()).hexdigest(),'r200_manifest_sha_integrity_files':85,'r200_db_count':30,'r200_attempts':32,'r200_precommit_ties':2,'r200_KO':16,'r200_censored':14,'r200_attack_event_units':1467,'r200_commit_units':1497,'r200_unique_seeds_per_level':8,'r200_physical_fight_units_started':30,'r200_paired_seed_blocks':16,'r200_magic_rank':'UNKNOWN_PROXY_NOT_CERTIFIABLE','r200_proxy_daily_PA':'13 per entry TEST only','r200_P1_ed_vs_lobo_CAnormal_ordinary_hit':'0/36','r200_P1_lobo_vs_ed_CA_34_25':'3/36','r200_P1_lobo_vs_ed_CA_36_25':'0/36','r200_P1_sword_conditional_mean_post_RD15':mean_dmg,'r200_official_contracts':0,'r200_official_cells':0,'new_page_effect_records_absent_c05_c11_c12_and_r200':sum(x['already_in']=='NOT_IN_THESE_FOUR_LOCAL_BASELINES' for x in lineage),'a6_structural_direct_child_refs':29,'source_family_effect_rows':len(rows),'source_page_unique':len(set(r['page_uuid'] for r in rows)),'family_definitions':len(set((r['family'],r['effect_name']) for r in rows)),'family_comparisons':len(comparisons),'a6_species_root_traversed_new':len(ROOT_NODES),'r204_separate_source_zip_sha256':'80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2','r204_is_not_part_of_r200':True,'calibration_status':'NO_V2','formal_f0':'4/8 HOLD','notion_writes':0,'sqlite_writes':0,'party_writes':0}
 save_json('C13_SCOPED_SCIENCE_SUMMARY.json',summary)

print(json.dumps(summary,ensure_ascii=False,indent=2))
