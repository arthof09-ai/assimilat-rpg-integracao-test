# C13 — DIAGNÓSTICO CIENTÍFICO: COMPARADORES FAMILIARES, CENSO E VLAB R200

**AS-OF:** 20/10/2026 · **OP:** OP-DMG-CORPUS-EMP-01 · **MESTRE-SIDE** · **Baseline:** DMG-RANK-01 v1.1 OFICIAL, inalterada · **Produção:** HOLD · **F0:** 4/8 formal (não promovido).

## ANTES → DEPOIS

- **ANTES:** C11 original 19 efeitos/15 páginas/4 estratos; C12 25 páginas por títulos, 0 efeito novo elegível para estrato estrito, alerta H5 e 36 chassis TEST. A6 original 571 UUIDs (332 raiz+239 ramo), sem censo exaustivo. R200 informado mas ainda não analisado por DMG a partir dos SQLite primários deste ciclo.
- **DEPOIS:** traversal estrutural focalizado de 16 raízes de espécie A6 (8 Água+8 Vento), **29 filhos diretos identificados** sem afirmar que todos os filhos foram lidos, mais famílias conhecidas Rinolupo/Crocossuário e fontes de R200; 14 folhas documentais com fórmula extraída para comparação, 6 pares família/habilidade como definições distintas, 8 contrastes entre variantes. **9 páginas de fórmula ausentes especificamente das baselines locais C05/C11/C12-triagem/R200 e 10 admissões de fórmula novas em relação às bases C05/C11/VLAB**; nenhuma reivindicação de nove páginas inéditas em todo o Notion. **0 nova amostra estrita Bronze5→Prata1 certificada.**
- **VLAB R200:** recuperado ZIP exato SHA `6e462fa907f489ce72a5ee514203c69b995253f15cc2b05273fd44b7b8144f74`; todos 85 membros de manifesto autenticados; 30/30 SQLite de combates iniciados inspecionados READ-ONLY em cópias temporárias. 1.497 commits / 1.467 eventos de ataque comparados a recibos originais; zero combate reexecutado, zero SQLite original alterado.

## Evidência I — fronteira Prata 5 → Ouro 1 dentro de UMA família (H1/H5)

[Sussurro Celestial Prata 1](https://app.notion.com/p/56ac2b324ede8352868101e11ea16355): Lâmina de Brisa `1d6 + INT30` = 33,5 bruto, dados 3,5. [Prata 5](https://app.notion.com/p/5e9c2b324ede83ed99078151805dec0b): `2d6 + INT45` = 52, dados 7; a fonte escreve “5 PA”, sem prova independente de regime temporal para equivalência. [Ouro 1](https://app.notion.com/p/442c2b324ede8364870a814350dd5051): `2d4 + INT26` = 31, dados 5. P1→P5 cresce +18,5 (= +15 INT e +3,5 dados). P5→O1 **cai -21**, sendo **-19 do atributo e -2 dos dados**. Mesma família e mesma habilidade, mas sem garantia de mesma entrega/PA/RE/FIP. A página [intitulada Ouro 5](https://app.notion.com/p/597c2b324ede8242bd5881027ef8d21f) escreve **Ouro 1 no corpo**; não atribuir Ouro 5 àquela fórmula. O ancestral organizacional da família é Ouro 5 e não adjudica automaticamente ranks das folhas. Status **EXPLORATÓRIO, não inferência populacional de progressão**.

[Rinolupo Prata 1](https://app.notion.com/p/034c2b324ede83ffa7118144011beaf3) Investida `2d6+FOR30` = 37; [Prata 4](https://app.notion.com/p/a47c2b324ede821f834481bef49fb8e3) mesma fórmula com FOR38 = 45, **100% do aumento +8 externo**, zero aumento de DME dos dados. [Título Ouro 5](https://app.notion.com/p/d58c2b324ede8208b24b014eaaf3ac5c) mantém classificação Prata 4 no corpo — excluído de Ouro 5 estrito. Status **comparação intra-família provisória, progresso de rank não validado**.

[Crocossuário Bronze 5](https://app.notion.com/p/a01c2b324ede8347b691819d3509d7d7) Mordida `1d6+1d4+FOR22` = 28 (C05 preexistente); [Prata 2 Titã](https://app.notion.com/p/ca3c2b324ede83ef923501ae00136097) `2d6+FOR32` = 39. Diferença +11, dos quais +10 FOR e +1 DME dos dados. Bronze 5 está sob ancestral Prata 2; variante Prata 2 é Titã. **Não usar o par como fronteira homogênea certificada.**

## Evidência II — números auxiliares ambíguos no Hidrargos

- [Hidrargos Ouro 4 Titã](https://app.notion.com/p/b85c2b324ede824dbfb301ccd441a96e): `6d12+120 / 161 de Dano`, **média exata 159**, não 161.
- [Hidrargos título Ouro 5 Titã](https://app.notion.com/p/bc7c2b324ede82ef97330199ec466b1b): `10d12+145 / 209 de Dano`, **média exata 210**, não 209; corpo ainda Ouro 4.
- [Hidrargos título Ouro Negro 1 Titã](https://app.notion.com/p/31ec2b324ede8305beae81f92349faa9): `19d12+173 / 295 de Dano`, **média exata 296,5**, não 295; corpo ainda Ouro 4.

Um número após a barra pode ser exemplo, arredondamento anterior ou dano fixo anotado; não presumir que seja média até esclarecimento. Os ranks do corpo e os títulos também não são consistentes nas duas folhas superiores. **Evidência de anomalia documental matemática e de classificação**, não justificativa para retroajuste.

## Evidência III — R200: precisão e mitigação dominam o DME físico na fixture Prata 1

Fonte Mestre: [VLAB R200](https://app.notion.com/p/3ffc2b324ede810287dae914c3720030), ZIP primário SHA acima.

| Fixture / política | Seeds tentadas | Lutas iniciadas | KO | Censuras | Vitórias ED | Vitórias Besta | Ataques |
|---|---:|---:|---:|---:|---:|---:|---:|
| Bronze1/Galinha SEM magia | 8 | 7 | 7 | 0 | 4 | 3 | 152 |
| Bronze1/Galinha COM proxy +2CA | 8 | 7 | 7 | 0 | 7 | 0 | 239 |
| Prata1/Lobo SEM magia | 8 | 8 | 2 | 6 | 0 | 2 | 516 |
| Prata1/Lobo COM proxy +2CA | 8 | 8 | 0 | 8 | 0 | 0 | 560 |

- A R200 possui **32 tentativas** (8 seeds/nível×2 políticas), **30 lutas fisicamente iniciadas**, 2 empates pré-commit (mesma seed em ambas políticas), **16 KO**, **14 censuras**. Pares na mesma seed não são independentes, ataques na mesma luta também não.
- Bronze: 3/7 pares iniciados mudaram de derrota para vitória ED com +2CA **proxy sem rank**. A duração das cenas também mudou; comparar taxa bruta de acertos por ataque entre políticas diretamente induz viés de exposição.
- Prata: o Orc possui ataque ordinário `2d6+22` vs CA34 do Lobo, então `P(hit)=0/36`; a espada física `3d8+6` (inclui FF6 já documentada no TEST) tem DME bruto19,5 e, contra RD física15, **média exata pós-RD apenas 4,74609375 condicionado ao acerto**. DME por tentativa ordinária =0. VLAB pode registrar críticos residuais LAB: não misturar esses resultados com ataque ordinário nem garantir conversão a regra canônica.
- Sensibilidade TEST: elevar exclusivamente a parcela fixa do ataque de +22 para +23/+24/+25/+26 daria chances exatas `1/36`, `3/36`, `6/36`, `10/36`. Não é recomendação de buff; demonstra **limiares discretos** e necessidade de calibrar o binômio precisão×defesa antes de ajustar DME.
- Lobo da Caverna em R200: ataque modelado `2d6+24` vs CA 34,25 do ED = `3/36` chances ordinárias; anel proxy eleva CA do ED para36,25 = `0/36`. Assim +2CA produz descontinuidade defensiva nesta fixture; não prova eficiência universal do anel.
- O anel +2CA e 13 PA/dia tem rank NÃO PUBLICADO. Débito da cena é convenção TEST; **Bateria E 0 homologada**. O Orc Prata 1 é PROVISÓRIO, progressão LEVEL-UP não confirmada. Proficiências da Galinha e Lobo são hipóteses de adaptador. NÃO existe certificado oficial de balanceamento nem vitória baseada em censura. Oficial VLAB 0/17 contratos, 0/1.875 células.

## Interoperabilidade prospectiva RI/RE/FIP × chassi físico (H6)

[Decisão expressa prospectiva do Mestre](https://app.notion.com/p/3ffc2b324ede81c5a5c3d56cc6a29f84): quantidade física de dados do chassi `NdS` multiplicada por Comum×1/Bronze×2/Prata×3/Ouro×4/Ouro Negro×5/Lendário×6. [DMG-RANK v1.1 §§5/8/13/22](https://app.notion.com/p/3f2c2b324ede815498cddb7844245f7e): as bandas são de EFEITOS OFENSIVOS padrão, inclusive físicos; o orçamento refere-se à **ação/efeito inteiro** e seus componentes. [REC-MOD-ARM-01](https://app.notion.com/p/3f1c2b324ede8140b993cc62063b9649) ainda encaminha arma mágica ao orçamento intrínseco RI/FIP.

**CASO VÁLIDO COMO DECOMPOSIÇÃO TEST:** espada Prata `1d8×3 = 3d8` físico (média13,5) + rider hipotético de Fogo `1d4` (média2,5), total condicionado16, com parcelas identificadas e **sujeito a RI/RE/FIP e orçamento do pacote completo**. A presença do rider não cria um segundo orçamento gratuito.

**CASO INVÁLIDO COMO AUTOMATISMO:** classificar o item Prata Média, selecionar um efeito completo Prata Média `5d8` (média22,5) e somá-lo indiscriminadamente a `3d8` (média13,5) como se fossem dois efeitos integrais independentes: soma36, maior que a banda Prata Média23–26 sem revisão dos componentes/riders. Isso é **exemplo matemático de risco**, não item existente nem julgamento universal de dano.

**Encaminhamento normativo sem promover nova norma:** classificar RI e RE/FIP por Atlas/autoridade competente; atribuir parcela física prospectiva obrigatória; definir se o poder classificado pertence à ação completa ou ao rider separado; avaliar DME completo e riders uma única vez; anexar atributo/FF exclusivamente autorizados; testar extremos, RD, PA e acerto; submeter ponte à governança NAC-NORM/CRAFT/VLAB. Nem o piso de efeito é imposto ao chassi isolado nem há autorização para somar dois orçamentos integrais.

## Parecer científico, hipóteses, confiança

| Hipótese | Evidência C13 | Julgamento |
|---|---|---|
| H1 Atributos dominam | Sussurro P5→O1: 19/21 pontos de queda vêm de INT; Rinolupo P1→P4: 8/8 de FOR | APOIO EXPLORATÓRIO intra-família, não populacional |
| H2 Diferenças intrabesta | Sussurro, Rinolupo, Crocossuário variáveis por build; condições/custos nem sempre completos | AUMENTOU COMPARABILIDADE, sem equilíbrio certificado |
| H3 FIP base/rider | C11/C12 preservados; C13 não adicionou fonte nova com FIP adjudicado | INCONCLUSIVO; não duplicar C12 |
| H4 PA efetivo | R200 anel 13PA/dia TEST e custo marginal que altera CA; 14 censuras P1 | ALCANCE TEST; não reparametrizar PA universal |
| H5 ancestralidade/identidade | Sussurro O5, Rinolupo O5, Hidrargos O5/ON1 com títulos diferentes de corpo | FORTALECIDO COMO PROBLEMA DOCUMENTAL; não contaminar estratos |
| H6 chassi físico × orçamento | R200 2d8 Bronze,3d8 Prata materializados, mas o item mágico é proxy sem rank | NECESSIDADE DE PONTE demonstrada; v1.1 não refutada |

**DECISÃO:** manter DMG-RANK v1.1 oficial e inalterada; não produzir candidata v2; não reinterpretar valores antigos como incorretos. Determinar *quando* e *como* um efeito adicional entra no orçamento do pacote é mais prioritário que elevar bandas sem dados.

## Fonte posterior encontrada, não confundida com R200

`VLAB_R201_R204_MAGIA_REAL_EDREF_MESTRE_ONLY.zip` presente na Biblioteca VLAB, SHA `80a513dfc5f1c182597a576f416a752ca25a8b2aa8ba2634f9195fcc9c1cace2`, cronologia posterior. **Não incorporado aos denominadores R200** e não usado para inferir execução de R205–R209. Avaliar o R204 em coorte separada quando questão científica sobre dano de magia/alcance necessitar, preservando sua própria admissibilidade e ressalvas.

## Governança, F0–F18 e denominadores

**F0** = 4/8 formal, sem writer/holdout certificação adicional; **F1–F6** receberam *dados exploratórios locais*, não PASS formal; **F7–F12** receberam comparações/hipóteses delimitadas, não avanço formal; **F13–F18** = nenhuma candidata, regressão candidata, stress candidata, playtest humano, promoção ou migração iniciada. E01–E24 e oito gates seguem obrigatórios.

**D0–D9:** denominadores globais sem certificação e não renumerados. Denominadores locais deste delta: 16 páginas-raiz A6 efetivamente percorridas, 29 links-filhos localizados; 14 folhas com fórmulas reabertas (14 UUIDs), 6 definições distintas por `(família, habilidade)`, 14 ocorrências, 8 contrastes vinculados; 9 páginas ausentes especificamente das quatro baselines consultadas C05/C11/C12 triagem/R200; 10 admissões de fórmula não existentes como definições quantitativas em C05/C11/VLAB; 30 DBs VLAB + 2 tentativas sem DB, 16 blocos-pareados de seed, 1.467 eventos de ataque dependentes em combate. Não somar links+efeitos+commits.

**HOLDOUT:** não utilizado para propor parâmetros; particionamento formal por família ainda PENDENTE. **SECOND-REVIEW INDEPENDENTE:** PENDENTE; o oráculo matemático de código distinto NÃO equivale a auditor independente da classificação Notion. **L002/L003:** pertinência individual não recuperada, preservar HOLD. **UNKNOWN-EFFECT:** R156 permanece em quarentena; R138 permanece HOLD espacial; não usar tais casos como êxito. **NO-REPEAT:** C04–C12/A6/R162/R169 preservados; não reproduzidos como novas amostras.

**LAST-VERIFIED-UNIT:** novo contraste intrafamília + leitura read-only 30/30 bancos R200 autenticados.

**FIRST-PENDING:** adjudicação do RE/rank de Sussurro P5→O1 e origem dos valores auxiliares de Hidrargos; para R200 validar ED-REF P1 contra LEVEL-UP e obter fonte de item com rank para Bateria E. Sem impedir análise documental independente.

**NEXT-5:** (1) buscar família com mesmo efeito B5→P1 realmente concordante em folhas e caminho; (2) obter confirmação de rank de Sussurro e Hidrargos sem retcon automático; (3) avaliar precisão×CA×RD em novos alvos não presentes nesta descoberta (com holdout protegido); (4) propor ao VLAB um experimento condicionado com mesmo chassi, +2CA legítima por rank, mantendo seed e recursos, sem DMG executar combate; (5) submeter ponte física+RI/RE/FIP a NAC-NORM-01 e CRAFT/PA para consumo prospectivo somente quando autorizado.

**TARGET-REMAINDER:** A5/A7/A8, D0–D9, L002/L003, F0–F18, E01–E24, oito gates, revisão externa das fontes e futuros recibos VLAB legalizados.

**AUTHORITY/WRITER STATE:** COMESTRE-ID/INSTANCE/WRITER/LEASE/EPOCH/FENCING não reivindicados. Biblioteca DMG como destino de arquivo do delta se autorizada; Notion Mestre pesquisa READ-ONLY, Party/O Primeiro NO-WRITE, VLAB SQLite READ-ONLY. Nenhum novo motor DMG/VLAB, livro de regras ou censo duplicado.

**NAC-PASS-02:** apenas gate técnico local para cálculos e preservação do arquivo; `FORMAL-PASS=HOLD`, F0 não promovido, candidato DMG v2 inexistente.
