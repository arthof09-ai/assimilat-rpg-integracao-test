PSV — DMG C13 / EXPANSÃO EMPÍRICA DIRIGIDA E VLAB R200

**AS-OF:** 2026-10-20 · **OPERATION:** OP-DMG-CORPUS-EMP-01 · **SCOPE:** MESTRE-SIDE / EXPERIMENTAL / READ-ONLY FICHAS E VLAB · **BASELINE:** DMG-RANK-01 v1.1 OFICIAL, intacta · **F0:** 4/8 formal · **PRODUÇÃO:** HOLD.

## RESULTADOS MATERIAIS (ANTES → DEPOIS)

ANTES: C11 original 19 efeitos/15 páginas/4 estratos. C12 triagem título 25 páginas, 0 novas fórmulas estritas, 36 células prospectivas e H5. A6=571 UUIDs estruturais; não censo de dano. R200 citado pelo Coordenador sem análise DMG dos 30 DB nesta C13.

DEPOIS: **16 páginas-raiz A6 percorridas por relações estruturais e 29 filhos enumerados**, 14 folhas com fórmula e versão reabertas, **6 definições distintas `(família, habilidade)` e 14 ocorrências não independentes**, 8 contrastes fonte-fonte; **9 páginas de fórmulas ausentes de C05/C11/C12-triagem/R200 locais**, e 10 admissões quantitativas não presentes nas bases C05/C11/VLAB, incluindo uma folha previamente apenas triada. Não inventar que sejam novas em todo o RPG. Nenhuma B5→P1 estrita certificada.

Novo: Sussurro Celestial `1d6+INT30` P1 média33,5; `2d6+INT45` P5 média52; `2d4+INT26` O1 média31. P5→O1 delta bruto **−21**, composto de **−19 INT e −2 dados**. Própria espécie/magia, mas conflito ancestral e custo: **ALERTA EXPLORATÓRIO**, não lei entre ranks. Rinolupo P1→P4 `2d6+FOR30` 37 → `2d6+FOR38` 45, +8 exclusivamente FOR. Rinolupo Ouro5 e Sussurro Ouro5 têm título/corpo divergentes; segregar. Crocossuário B5→Prata2 Titã 28→39 com ancestralidade conflituosa, apenas controle exploratório.

Hidrargos Titã: `6d12+120` E159 vs nota161; `10d12+145` E210 vs nota209; `19d12+173` E296,5 vs nota295; sufixos **não demonstrados como médias** e ranks de duas folhas em conflito. Não alterar fichas nem tratar nota como DME certo.

R200 **ZIP original SHA** `6e462fa907f489ce72a5ee514203c69b995253f15cc2b05273fd44b7b8144f74` autenticado 85/85 membros, **30/30 DB SQLite físicos** auditados em cópias temporárias `mode=ro&immutable=1`; 32 tentativas pareadas com 2 pré-commit ties, 30 começadas, 16 KO, 14 censuras, 1.497 commits, 1.467 eventos de ataque. 16 blocos de seed (8 por patamar) não 32 seeds independentes. Bronze proxy +2CA: 3/7 pares iniciados trocaram perda ED por vitória ED, efeito TEST e anel sem rank. P1 Orc: `2d6+22` vs CA34 = 0/36 acertos comuns; espada física `3d8+6` contra RD15: 19,5 médio bruto, **4,74609375 médio pós-RD condicionado a acerto**. Com bônus de precisão TEST +1,+2,+3,+4: chances `1/36`,`3/36`,`6/36`,`10/36`; não buffs recomendados. Lobo `2d6+24` vs CA34,25 =3/36, vs CA36,25 após proxy +2 =0/36, críticos TEST separados. P1 COM=8/8 censurados, não vitórias. Bateria E 0 homologada, 0/17 contratos, 0/1.875 células VLAB.

**H6 físico:** decisão Mestre `NdS × {1,2,3,4,5,6}` é para chassi físico novo. DMG-RANK §§5/13/22 orça efeito/ação completo, físico OU mágico ou composto; **não** banda apenas mágica. Exemplo TEST Prata 3d8 físico +1d4 Fogo = média16, sem dois orçamentos; adição automática de pool completo `5d8` ao chassi 3d8 daria média36, acima da banda Prata Média23–26 sem análise — demonstrado como possível dupla contagem, não item real. Regra oficial não reescrita. R204 ZIP posterior identificado separadamente, não somado à R200.

## HIPÓTESES

- **H1** predomínio de atributos: apoio exploratório intrafamília Sussurro/Rinolupo; generalização populacional insuficiente.
- **H2** comparações naturais: novos pares identificados; mecânica completa/custos ausentes.
- **H3** FIP rider: C11/C12 preservados; C13 sem novo FIP adjudicado.
- **H4** PA/defesa: R200 mostra limiar forte de CA mas anel sem rank e custo por cena convencional TEST; sem recomendação universal de PA.
- **H5** linhagem/rank: suporte para problema documental específico (folhas tituladas O5/ON1 com corpo inferior); corrigir identidade antes de calibrar.
- **H6** chassi físico×orçamento: necessidade de contrato para novas armas confirmada; não justifica v2 imediata.

## DENOMINADORES / QUALIDADE

D0–D9 globais não certificados. A6=571 referências históricas (332+239) preservadas. Local C13: 16 raízes; 29 links-folha; 14 folhas lidas com dano numérico; 6 definições; 14 ocorrências; 8 contrastes não independentes; 9 páginas fora das baselines locais indicadas; 30 SQLite de luta+2 tentativas sem banco; 1.467 ataques dependentes dos 30 combates. **SECOND-CODER Notion=PENDING; HOLDOUT por família não lacrado e não utilizado para propor parâmetros.** Matriz matemática com código independente no ZIP; nenhum bloco VLAB duplicado ou reexecutado.

**F0–F18 STATUS:** F0 4/8 somente; F1–F6 coleta/extração local não homologada; F7–F12 resultados exploratórios não PASS; F13–F18 não iniciadas para candidata v2. E01–E24 + 8 gates sem certificação universal. **L002/L003** pertinência primária individual HOLD. **R156 UNKNOWN_EFFECT** quarentena; **R138 HOLD** espacial. R162/R169 separados, históricos intactos.

## CONTINUIDADE

**LAST-VERIFIED-UNIT:** C13 amostra intrafamília + leitura sem escrita do R200 30/30 DB; pacote científico e parâmetros externos SHA fechados.

**FIRST-PENDING:** reconciliar ranks de Sussurro e Hidrargos antes de usar esses efeitos em bandas RE/FIP; demanda VLAB: perfil P1 nativo validado e item mágico com rank para teste E legal.

**NO-REPEAT:** C04–C12/A6 intocados, C11 original prevalece; 25 triagens C12 não reutilizadas como fontes independentes; zero replays de combate pelo DMG.

**CONFLICTS:** ancestralidade Ouro5 Sussurro/Rinolupo, títulos O5/ON1 incoerentes, números auxiliares Hidrargos, RL histórico físico×v1.1, rank anel, custos e precisão condicionais.

**NEXT-5:** (1) busca A6 de pares B5→P1 de mesma família com rank realmente concordante; (2) adjudicar classificações e anotação `N de dano` da família Hidrargos; (3) calibrar nível de acerto×CA×RD em alvos não examinados, respeitando holdout; (4) consumir R204 somente como coorte distinta se relevante e fonte-admissível; (5) preparar consulta normativa de integração física+RI/RE/FIP sob NAC-NORM/CRAFT antes de produção.

**TARGET-REMAINDER:** D0–D9 globais, A5/A7/A8, L002/L003, F0–F18, E01–E24, 8 gates, famílias/itens comparáveis, VLAB referências legalizadas.

**AUTHORITY/WRITER STATE:** identidade de executor não reivindicada; writer/lease/epoch/fencing/ACK ausentes nesta sessão. Notion Mestre fontes READ-ONLY; fichas/Party/O Primeiro NO-WRITE; VLAB SQLite READ-ONLY; Biblioteca da OP usada somente para checkpoint, se publicação completada/readback. Nenhuma migração normativa.

**NAC-PASS-02:** PASS TÉCNICO LOCAL somente para cálculos novos, rastreabilidade, ZIP/replay/readback quando fisicamente confirmados; **HOLD FORMAL** sobre F0, independência de dupla classificação, v2 e produção.

**Parecer:** manter DMG-RANK-01 v1.1 oficial; investigar valor das ações compostas e falhas de precisão antes de mudar bandas. Não inventar coeficientes. Ciência principal sobre corpus de dano avançou sem motor novo.
