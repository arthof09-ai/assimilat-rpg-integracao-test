# C13 Delta científico — Recuperação portátil (MESTRE-SIDE)

Este ZIP contém **apenas** dados novos/exploratórios, relatório e código de reprodução. Não é outro consultor de dano. Não copia 18 MB de VLAB histórico ou C11/C12 inteiros. A integridade das fontes é verificada por SHA e manifesto.

## Pré-requisitos

Python 3.11+ com sqlite3, biblioteca padrão. Disponibilize em uma pasta de sua escolha os três ZIPs Mestre-side (não alterar nomes):

- `DMG_C11_DIAGNOSTICO_EMPIRICO_20261019_MESTRE_ONLY.zip` SHA d4a91fb7a0b7d0ab44cb8b39d652db0cab15f0a2532194ca2ec41dba2e0e089e
- `DMG_C12_CIENCIA_CHASSIS_FIP_TRIAGEM_20261020_MESTRE_ONLY.zip` SHA 19c9b8799d161e3eaa577ec30c8a10ec0ebe7cf22533f73c393b68df3e4218a4
- `VLAB_R200_R203_FISICO_GEOMETRIA_COMBATES_MESTRE_ONLY.zip` SHA 6e462fa907f489ce72a5ee514203c69b995253f15cc2b05273fd44b7b8144f74

Extraia este delta ZIP para uma pasta independente. Exemplo em shell local:

```bash
C13_SOURCE_DIR=/path/to/three/source/zips python scripts/build_c13.py
C13_SOURCE_DIR=/path/to/three/source/zips python scripts/c13_independent_audit.py
```

O primeiro script lê 30 DBs de dentro do ZIP R200 em arquivos temporários `mode=ro&immutable=1`, nunca no diretório VLAB e sem executar engine; todos os 85 arquivos de manifesto do pacote de origem são verificados. O segundo usa cálculos independentes sem chamar a função aritmética do primeiro. compare os CSV/JSON regenerados na pasta `output` aos arquivos congelados do ZIP.

Os excertos das fontes Notion são uma transcrição específica verificada nesta sessão (páginas/edições/links no CSV), **não uma sincronização live**. Para novo estudo, o Comestre reabre as fontes pelo Notion Mestre e atualiza a evidência; nenhuma escrita no Notion é realizada por estes scripts.

**Não misturar:** páginas, definições, ocorrências, simulações TEST e combates; não validar rank por título de uma folha isoladamente; não promover candidata normativa ou produzir RETCON. R204 é posterior e separado.
