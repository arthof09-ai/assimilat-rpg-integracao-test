"""64 independent fictional A/B healing episodes, native R18 with existing v06/v07 adapters."""
from pathlib import Path
import collections,csv,hashlib,json,sys
sys.path.insert(0,'/mnt/data/vlab_r274_ongoing/r274/runtime/fusion_stage12')
sys.path.insert(0,'/mnt/data/vlab_r274_ongoing/r277')
import vlab_r18_interactive as v
from audit_r274_heal_independent import check
out=Path('/mnt/data/vlab_r274_ongoing/r280');out.mkdir(exist_ok=True)
log=[]
for n in range(64):
    scene='A' if n%2==0 else 'B';seed=280500+n
    p=out/('r280_s'+str(seed)+'.sqlite')
    for suffix in ('','-wal','-shm'):
        f=Path(str(p)+suffix)
        if f.exists():f.unlink()
    v.init_db(p,scene,seed)
    st,_,rev=v.load(p)
    v.event_commit(p,v._uid(p,rev,'START'),'START',{},v.do_start,preflight=v.preflight_start)
    st,_,rev=v.load(p);att=st['active'];target=next(a for a in st['actors'] if a!=att)
    ar=v.event_commit(p,v._uid(p,rev,'ATTACK'),'ATTACK',{'target':target,'reaction':'NONE'},v.do_attack,preflight=v.preflight_attack)
    st,_,rev=v.load(p)
    if st['active']!=target or st['phase']!='ACTIVE':raise AssertionError('wrong scheduler')
    hr=v.event_commit(p,v._uid(p,rev,'HEAL'),'HEAL',{'origin':'LAB-V06-MAGIC-HEAL-1D6'},v.do_heal,preflight=v.preflight_heal)
    st,head,rev=v.load(p);report=check(p)
    if report['heals']!=1 or rev!=3 or report['events']!=3:raise AssertionError(report)
    d=hr['detail']
    if st['active']!=att or st['actors'][target]['resource']['hp']!=d['hp_after']:
        raise AssertionError('bad state')
    log.append({'seed':seed,'scene':scene,'attacker':att,'healer':target,
        'hp_before':d['hp_before'],'hp_after':d['hp_after'],'max_hp':st['actors'][target]['stats']['hp'],
        'heal_roll':d['dice'][0],'actual_healed':d['v06_receipt']['healed'],
        'incoming_damage':ar['detail']['native']['damage'],'pa_cost_lab':d['pa_cost'],
        'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
with (out/'R280_64_HEAL_CASES.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(log[0]));w.writeheader();w.writerows(log)
c=collections.Counter();c.update({'cases':len(log),'events':len(log)*3,'heals':len(log),'initial_attacks':len(log),
 'healed_hp':sum(x['actual_healed'] for x in log),'rolled_heal_total':sum(x['heal_roll'] for x in log),
 'A_cases':sum(x['scene']=='A' for x in log),'B_cases':sum(x['scene']=='B' for x in log),
 'healing_capped':sum(x['actual_healed']<x['heal_roll'] for x in log),'no_pa_spend':sum(x['pa_cost_lab']==0 for x in log)})
res={'status':'PASS_TEST_ONLY','metrics':dict(c),'basis':'64 independent seeds of a synthetic two-actor one-turn action+heal fixture; not official combat or representative game statistics',
 'read_only_independent_audits_pass':64,'original_v06_source_used':True,'not_17_contract_terminals':True,
 'not_R91_cells':True,'no_external_truth_claimed':True}
(out/'R280_SUMMARY.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
print(json.dumps(res,ensure_ascii=False))
