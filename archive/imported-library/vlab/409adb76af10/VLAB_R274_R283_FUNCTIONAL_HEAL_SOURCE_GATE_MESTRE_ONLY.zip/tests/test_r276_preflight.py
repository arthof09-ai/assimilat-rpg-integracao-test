"""R276 input preflight remains source-neutral: invalid intent is never journaled."""
import pathlib,tempfile,unittest
import vlab_r18_interactive as v

class Guard(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory(prefix='vlab-r276-');self.addCleanup(t.cleanup)
        self.db=pathlib.Path(t.name)/'fight.sqlite';v.init_db(self.db,'A',276109)
    def commit(self,kind,payload,runner,preflight):
        s,_,r=v.load(self.db)
        return v.event_commit(self.db,v._uid(self.db,r,kind),kind,payload,runner,preflight=preflight)
    def start(self):self.commit('START',{},v.do_start,v.preflight_start)
    def state(self):return v.load(self.db)[0]
    def test_01_invalid_pass_initial_preserves_save(self):
        with self.assertRaises(v.LabHold):self.commit('PASS',{},v.do_pass,v.preflight_pass)
        self.assertEqual(v.load(self.db)[2],0);self.start()
    def test_02_invalid_start_payload_no_pending(self):
        with self.assertRaises(v.LabHold):self.commit('START',{'fake':1},v.do_start,v.preflight_start)
        self.assertEqual(v.load(self.db)[2],0);self.start()
    def test_03_bad_attack_target_no_pending(self):
        self.start()
        with self.assertRaisesRegex(v.LabHold,'TARGET_INVALID'):
            self.commit('ATTACK',{'target':'LAB-GHOST','reaction':'NONE'},v.do_attack,v.preflight_attack)
        self.assertEqual(v.load(self.db)[2],1)
        s=self.state();target=next(a for a in s['actors'] if a!=s['active'])
        self.commit('ATTACK',{'target':target,'reaction':'NONE'},v.do_attack,v.preflight_attack)
        self.assertEqual(v.load(self.db)[2],2)
    def test_04_bad_reaction_no_pending(self):
        self.start()
        s=self.state();target=next(a for a in s['actors'] if a!=s['active'])
        with self.assertRaisesRegex(v.LabHold,'REACTION_INVALID'):
            self.commit('ATTACK',{'target':target,'reaction':'FAKE'},v.do_attack,v.preflight_attack)
        self.assertEqual(v.load(self.db)[2],1)
    def test_05_defender_forbidden_in_scene_a(self):
        self.start();s=self.state();target=next(a for a in s['actors'] if a!=s['active'])
        with self.assertRaisesRegex(v.LabHold,'REACTION_NOT_IN_SCENE'):
            self.commit('ATTACK',{'target':target,'reaction':'DEFENDER'},v.do_attack,v.preflight_attack)
        self.assertEqual(v.load(self.db)[2],1)
    def test_06_extra_key_rejected(self):
        self.start();s=self.state();target=next(a for a in s['actors'] if a!=s['active'])
        with self.assertRaisesRegex(v.LabHold,'PAYLOAD_INVALID'):
            self.commit('ATTACK',{'target':target,'reaction':'NONE','cost_pa':-1},v.do_attack,v.preflight_attack)
        self.assertEqual(v.load(self.db)[2],1)
    def test_07_pass_legitimate_once(self):
        self.start();who=self.state()['active']
        self.commit('PASS',{},v.do_pass,v.preflight_pass)
        self.assertEqual(v.load(self.db)[2],2)
        self.assertNotEqual(who,self.state()['active'])
    def test_08_start_repeated_not_journalled(self):
        self.start()
        with self.assertRaisesRegex(v.LabHold,'INIT_PRECHECK_DENIED'):
            self.commit('START',{},v.do_start,v.preflight_start)
        self.assertEqual(v.load(self.db)[2],1)
    def test_09_tied_initiative_is_preflight_hold(self):
        st=v.initial('A',1)
        actor_ids=list(st['actors']);actorA,actorB=actor_ids
        st['actors'][actorA]['stats']['des']=st['actors'][actorB]['stats']['des']
        tied=next(seed for seed in range(1000) if sum(v.dice(seed,0,'initiative:'+actorA,1,6))==sum(v.dice(seed,0,'initiative:'+actorB,1,6)))
        st['seed']=tied
        with self.assertRaisesRegex(v.LabHold,'INITIATIVE_TIE_NORMATIVE_HOLD'):
            v.preflight_start(st,{})
    def test_10_negative_phase_attack(self):
        with self.assertRaisesRegex(v.LabHold,'ATTACK_PRECHECK_NOT_ACTIVE'):
            v.preflight_attack(self.state(),{'target':'other','reaction':'NONE'})
    def test_11_after_bad_input_restart_process(self):
        self.start()
        try:self.commit('ATTACK',{'target':'GHOST','reaction':'NONE'},v.do_attack,v.preflight_attack)
        except v.LabHold:pass
        self.assertEqual(v.load(self.db)[2],1)
    def test_12_parameterless_pass_has_no_second_effect(self):
        self.start();self.commit('PASS',{},v.do_pass,v.preflight_pass)
        self.assertEqual(len(v.history(self.db)['events']),2)

if __name__=='__main__':unittest.main()
