"""R279 genuine CLI pipe sessions A/B, including invalid self-heal and recovery."""
from pathlib import Path
import hashlib,json,subprocess,sys,sqlite3
root=Path('/mnt/data/vlab_r274_ongoing/r279');root.mkdir(exist_ok=True)
engine=Path('/mnt/data/vlab_r274_ongoing/r274/runtime/fusion_stage12/vlab_r18_interactive.py')
rows=[]
for scenario,seed,inputs in [('A',279010,'1\n7\n1\n1\n7\n4\n'),('B',279011,'1\n7\n1\n1\n0\n7\n4\n')]:
  db=root/f'cli_{scenario}.sqlite'
  for suffix in ('','-wal','-shm'):
    f=Path(str(db)+suffix)
    if f.exists():f.unlink()
  cmd=[sys.executable,str(engine),'play','--save',str(db),'--scene',scenario,'--seed',str(seed)]
  run=subprocess.run(cmd,input=inputs,text=True,capture_output=True,timeout=45)
  if run.returncode!=0:raise RuntimeError((scenario,run.stderr,run.stdout))
  if 'Cura indisponível sem alterar salvamento' not in run.stdout or 'Cura LAB:' not in run.stdout:raise AssertionError(run.stdout)
  con=sqlite3.connect(db)
  try:
    events=[json.loads(t[0]) for t in con.execute('SELECT row_json FROM events ORDER BY seq')]
    meta=dict(con.execute('SELECT key,value FROM meta'))
  finally:con.close()
  if len(events)!=3 or [x['kind'] for x in events]!=['START','ATTACK','HEAL']:
    raise AssertionError((scenario,[x['kind'] for x in events]))
  history=subprocess.run([sys.executable,str(engine),'history','--save',str(db)],capture_output=True,text=True,timeout=25)
  if history.returncode!=0:raise RuntimeError(history.stderr)
  receipts=json.loads(history.stdout)
  if len(receipts['events'])!=3:raise AssertionError('history loss')
  rows.append({'scenario':scenario,'seed':seed,'rev':3,'heal_amount':events[-1]['detail']['v06_receipt']['healed'],
    'saved_sha256':hashlib.sha256(db.read_bytes()).hexdigest(),'stderr':run.stderr.strip(),
    'full_hp_heal_rejected_pre_intent':True,'pa_declared_fiction_only':0,'terminal':False})
(root/'R279_HUMAN_CLI_E2E.json').write_text(json.dumps({'status':'PASS','rows':rows,'official_credits':0},ensure_ascii=False,indent=2))
print(json.dumps(rows,ensure_ascii=False))
