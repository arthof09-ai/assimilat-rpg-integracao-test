"""R278 golden compatibility demo: same path, old original-patched R269 vs R276 copy."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile
OLD=Path('/mnt/data/vlab_r272_work/r18_patched/fusion_stage12/vlab_r18_interactive.py')
NEW=Path('/mnt/data/vlab_r274_ongoing/r274/runtime/fusion_stage12/vlab_r18_interactive.py')
root=Path('/mnt/data/vlab_r274_ongoing/r278');root.mkdir(exist_ok=True)
rows=[]
for scenario,reaction,seed in [('A',False,278001),('A',False,278002),('B',True,278003),('B',False,278004),('B',True,278005),('A',False,278006)]:
  file=root/('golden_'+str(seed)+'.sqlite')
  versions=[]
  for label,engine in [('R269',OLD),('R276',NEW)]:
    for suffix in ('','-wal','-shm'):
      p=Path(str(file)+suffix)
      if p.exists():p.unlink()
    cmd=[sys.executable,str(engine),'demo','--scene',scenario,'--seed',str(seed),'--save',str(file)]
    if reaction:cmd.append('--reaction')
    out=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=40)
    if out.returncode!=0:raise RuntimeError((label,cmd,out.stderr,out.stdout))
    report=json.loads(out.stdout.strip().splitlines()[-1]); sha=hashlib.sha256(file.read_bytes()).hexdigest()
    versions.append({'engine':label,'sqlite_sha256':sha,'receipt':report,'bytes':file.stat().st_size})
  if versions[0]['sqlite_sha256']!=versions[1]['sqlite_sha256']:
    raise AssertionError(('DIVERGENT',scenario,seed,versions))
  rows.append({'scenario':scenario,'seed':seed,'reaction':reaction,'matched':True,'versions':versions})
res={'phase':'R278','status':'PASS_BYTE_PARITY','matched':len(rows),'total':len(rows),'comparison':'R269 R18 historic-science patched baseline vs R274-R276 extended CLI on the SAME save path; identical demo SQLite bytes',
'cases':rows,'official_credits':0,'no_new_17_contract_certification':True}
(root/'R278_DIFFERENTIAL.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print(json.dumps({'status':res['status'],'cases':len(rows),'events':[x['versions'][0]['receipt']['events'] for x in rows]},ensure_ascii=False))
