"""R283 source-validated history and receipt export on isolated R18 TEST fixture."""
from __future__ import annotations
import pathlib,sqlite3,json,tempfile,shutil,unittest
import vlab_r18_interactive as v
SRC=pathlib.Path(__file__).resolve().parent.parent/'samples'

class R283History(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory(prefix='vlab-r283-');self.addCleanup(t.cleanup)
        self.db=pathlib.Path(t.name)/'heal.sqlite'
        shutil.copy2(SRC/'heal_quick.sqlite',self.db)
    def forge(self):
        c=sqlite3.connect(self.db)
        try:
            row=json.loads(c.execute('SELECT row_json FROM events WHERE seq=3').fetchone()[0])
            row['detail']['hp_after']=999
            new=v.sha(row)
            c.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=3',(v.canonical(row),new))
            c.execute("UPDATE meta SET value=? WHERE key='head'",(new,))
            c.commit()
        finally:c.close()
    def test_valid_heal_history(self):
        self.assertEqual(v.history(self.db)['revision'],3)
    def test_valid_old_attack_only_history(self):
        other=self.db.parent/'legacy.sqlite';shutil.copy2(SRC/'attack_only.sqlite',other)
        self.assertGreater(v.history(other)['revision'],0)
    def test_forgery_can_pass_generic_but_not_history(self):
        self.forge();self.assertEqual(v.load(self.db)[2],3)
        with self.assertRaisesRegex(v.LabHold,'HISTORY_SOURCE_AUDIT_HOLD'):v.history(self.db)
    def test_forged_export_creates_no_file(self):
        self.forge();dst=self.db.parent/'lie.json'
        with self.assertRaisesRegex(v.LabHold,'HISTORY_SOURCE_AUDIT_HOLD'):v.export(self.db,dst)
        self.assertFalse(dst.exists())
    def test_generic_crash_recovery_source_audit(self):
        # The original R18 regression covers a committed effect in WAL after
        # process crash. R283 must not reject it solely due to WAL presence.
        other=self.db.parent/'legacy.sqlite'
        shutil.copy2(SRC/'attack_only.sqlite',other)
        self.assertGreater(v.history(other)['revision'],0)

if __name__=='__main__':unittest.main()
