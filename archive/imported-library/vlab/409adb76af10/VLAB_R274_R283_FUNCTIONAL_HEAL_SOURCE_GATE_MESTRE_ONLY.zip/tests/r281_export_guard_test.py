"""R281 source-verified exports: valid v06 heals pass, rehashed lies fail."""
from pathlib import Path
import json,shutil,sqlite3,tempfile,sys
sys.path.insert(0,'/mnt/data/vlab_r274_ongoing/r274/runtime/fusion_stage12')
import vlab_r18_interactive as v
from audit_r274_heal_independent import canonical,digest,check
root=Path('/mnt/data/vlab_r274_ongoing/r281');root.mkdir(exist_ok=True)
source=Path('/mnt/data/vlab_r274_ongoing/r279/cli_A.sqlite')
valid=root/'real_lab.sqlite';shutil.copy2(source,valid)
valid_export=root/'real_lab_receipt.json';valid_export.unlink(missing_ok=True)
result=v.export(valid,valid_export)
assert valid_export.exists() and result['events']==3
negative=root/'forged_lab.sqlite';shutil.copy2(source,negative)
c=sqlite3.connect(negative)
try:
    row=json.loads(c.execute('SELECT row_json FROM events WHERE seq=3').fetchone()[0]);row['detail']['hp_after']=999
    row_sha=digest(row)
    c.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=3',(canonical(row),row_sha))
    c.execute('UPDATE meta SET value=? WHERE key="head"',(row_sha,))
    c.commit()
finally:c.close()
# R18 journal verifies this internally rehashed lie, but the independent audit rejects.
assert v.history(negative)['revision']==3
bad_export=root/'forged_lab_receipt.json';bad_export.unlink(missing_ok=True)
try:v.export(negative,bad_export)
except v.LabHold as exc:
    assert 'EXPORT_SOURCE_AUDIT_HOLD' in str(exc),str(exc)
else:raise AssertionError('forged receipt exported')
assert not bad_export.exists()
report={'stage':'R281','status':'PASS','valid_export':str(valid_export),'valid_events':3,
  'rehashed_forgery_journal_accepts':True,'source_audit_export_rejected':True,
  'forged_export_file_created':False,'zero_canonical_credits':True}
(root/'R281_EXPORT_PROVENANCE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
