from __future__ import annotations
import copy,hashlib,json,pathlib,shutil,sqlite3,tempfile,unittest
from audit_r274_heal_independent import check,AuditHold,digest,canonical
SRC=pathlib.Path(__file__).resolve().parent.parent/'samples'/'heal_quick.sqlite'

class R277Adversarial(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory(prefix='vlab-r277-');self.addCleanup(t.cleanup)
        self.db=pathlib.Path(t.name)/'audit.sqlite';shutil.copy2(SRC,self.db)
    def tamper(self,mutator):
        c=sqlite3.connect(self.db)
        try:
            j=c.execute('SELECT row_json FROM events WHERE seq=3').fetchone()[0]
            row=json.loads(j);mutator(row)
            rh=digest(row)
            c.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=3',(canonical(row),rh))
            c.execute("UPDATE meta SET value=? WHERE key='head'",(rh,));c.commit()
        finally:c.close()
    def test_01_original(self):
        self.assertEqual(check(self.db)['heals'],1)
    def test_02_receipt_healed_forged(self):
        self.tamper(lambda r:r['detail']['v06_receipt'].__setitem__('healed',999))
        with self.assertRaises(AuditHold):check(self.db)
    def test_03_health_after_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('hp_after',999))
        with self.assertRaises(AuditHold):check(self.db)
    def test_04_heal_dice_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('dice',[6]))
        with self.assertRaises(AuditHold):check(self.db)
    def test_05_heal_source_forged(self):
        self.tamper(lambda r:r['payload'].__setitem__('origin','OTHER'))
        with self.assertRaises(AuditHold):check(self.db)
    def test_06_pa_cost_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('pa_cost',5))
        with self.assertRaises(AuditHold):check(self.db)
    def test_07_actor_swap_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('actor','LAB_VIGIA_A'))
        with self.assertRaises(AuditHold):check(self.db)
    def test_08_canonical_credit_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('canonical_credits',1))
        with self.assertRaises(AuditHold):check(self.db)
    def test_09_source_classification_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('source_status','CANON'))
        with self.assertRaises(AuditHold):check(self.db)
    def test_10_benefit_before_forged(self):
        self.tamper(lambda r:r['detail'].__setitem__('hp_before',222))
        with self.assertRaises(AuditHold):check(self.db)
    def test_11_v06_locked_damage_claim(self):
        self.tamper(lambda r:r['detail']['v06_receipt'].__setitem__('locked_damage_after',5))
        with self.assertRaises(AuditHold):check(self.db)
    def test_12_next_turn_forged(self):
        self.tamper(lambda r:r['detail']['control'].__setitem__('next_turn','LAB_VIGIA_B'))
        with self.assertRaises(AuditHold):check(self.db)
    def test_13_wal_sidecar_rejected(self):
        (self.db.parent/(self.db.name+'-wal')).write_bytes(b'X')
        with self.assertRaisesRegex(AuditHold,'SQLITE_FILE_NOT_SAFELY_CLOSED'):check(self.db)
    def test_14_pending_blocks(self):
        c=sqlite3.connect(self.db)
        try:
            c.execute('INSERT INTO pending VALUES (?,?,?,?)',('LAB-CMD-X','0'*64,'HEAL','{}'));c.commit()
        finally:c.close()
        with self.assertRaisesRegex(AuditHold,'PENDING_UNKNOWN_EFFECT'):check(self.db)

if __name__=='__main__':unittest.main()
