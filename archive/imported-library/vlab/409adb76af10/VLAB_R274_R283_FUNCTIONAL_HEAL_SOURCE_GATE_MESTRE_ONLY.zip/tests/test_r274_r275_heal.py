"""VLAB test-only functional healing; requires existing R18 source tree on PYTHONPATH.
No Party/Notion data. Only temp SQLite fixtures."""
from __future__ import annotations
import contextlib, io, os, pathlib, subprocess, sys, tempfile, unittest
from unittest.mock import patch
import vlab_r18_interactive as v

SRC={'origin':'LAB-V06-MAGIC-HEAL-1D6'}

class R274R275Heal(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='vlab-r274-')
        self.addCleanup(self.tmp.cleanup)
        self.db=pathlib.Path(self.tmp.name)/'scene.sqlite'
        v.init_db(self.db,'A',274110)
    def start(self):
        st,_,r=v.load(self.db)
        v.event_commit(self.db,v._uid(self.db,r,'START'),'START',{},v.do_start)
    def attack(self):
        st,_,r=v.load(self.db)
        target=next(i for i in st['actors'] if i!=st['active'])
        row=v.event_commit(self.db,v._uid(self.db,r,'ATTACK'),'ATTACK',{'target':target,'reaction':'NONE'},v.do_attack)
        return row
    def heal(self):
        st,_,r=v.load(self.db)
        return v.event_commit(self.db,v._uid(self.db,r,'HEAL'),'HEAL',dict(SRC),v.do_heal,preflight=v.preflight_heal)
    def metadata(self):
        c=v.connect(self.db)
        try:return dict(c.execute('SELECT key,value FROM meta')),c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
        finally:c.close()
    def test_01_start_initiative(self):
        self.start();s,_,r=v.load(self.db)
        self.assertEqual((r,s['round'],s['phase']),(1,1,'ACTIVE'))
    def test_02_full_hp_rejected_before_intent(self):
        self.start()
        with self.assertRaisesRegex(v.LabHold,'NOT_INJURED'):self.heal()
        st,_,r=v.load(self.db)
        self.assertEqual(r,1);self.assertEqual(self.metadata()[1],0)
        self.attack();self.assertEqual(v.load(self.db)[2],2)
    def test_03_unstarted_rejected_without_quarantine(self):
        with self.assertRaisesRegex(v.LabHold,'ACTIVE_LAB_TURN'):self.heal()
        self.assertEqual(self.metadata()[1],0)
        self.start()
    def test_04_attack_then_heal_original_v06(self):
        self.start();self.attack()
        st,_,r=v.load(self.db);who=st['active']; before=st['actors'][who]['resource']['hp'];pa=st['actors'][who]['resource']['pa']
        self.assertLess(before,st['actors'][who]['stats']['hp'])
        row=self.heal();after=row['detail']['hp_after']
        self.assertEqual(row['detail']['hp_before'],before)
        self.assertEqual(after-before,row['detail']['v06_receipt']['healed'])
        self.assertEqual(row['detail']['v06_receipt']['mode'],'UNIT_FIXTURE')
        self.assertEqual(row['detail']['pa_cost'],0)
        st2,_,rv=v.load(self.db)
        self.assertEqual(rv,3);self.assertEqual(st2['actors'][who]['resource']['pa'],pa)
        self.assertEqual(st2['active'],next(i for i in st2['actors'] if i!=who))
        self.assertEqual(self.metadata()[1],0)
    def test_05_max_hp_cap(self):
        self.start();self.attack();row=self.heal()
        self.assertLessEqual(row['detail']['hp_after'],v.load(self.db)[0]['actors'][row['detail']['actor']]['stats']['hp'])
        self.assertLessEqual(row['detail']['v06_receipt']['healed'],sum(row['detail']['dice']))
    def test_06_bad_source_before_intent(self):
        self.start();self.attack();st,_,rv=v.load(self.db)
        with self.assertRaisesRegex(v.LabHold,'UNVERIFIED_HEAL_SOURCE'):
            v.event_commit(self.db,v._uid(self.db,rv,'HEAL'),'HEAL',{'origin':'UNAUTHORIZED'},v.do_heal,preflight=v.preflight_heal)
        self.assertEqual(v.load(self.db)[2],rv);self.assertEqual(self.metadata()[1],0)
        self.heal()
    def test_07_malformed_source_before_intent(self):
        self.start();self.attack();st,_,rv=v.load(self.db)
        with self.assertRaises(v.LabHold):
            v.event_commit(self.db,v._uid(self.db,rv,'HEAL'),'HEAL',{'origin':'LAB-V06-MAGIC-HEAL-1D6','amount':99999},v.do_heal,preflight=v.preflight_heal)
        self.assertEqual(self.metadata()[1],0)
    def test_08_bad_preflight_type_is_safe(self):
        self.start();self.attack();st,_,rv=v.load(self.db)
        with self.assertRaisesRegex(v.LabHold,'PREFLIGHT_CALLBACK_INVALID'):
            v.event_commit(self.db,v._uid(self.db,rv,'HEAL'),'HEAL',dict(SRC),v.do_heal,preflight='not_callable')
        self.assertEqual(self.metadata()[1],0)
    def test_09_direct_action_outside_standard(self):
        st=v.initial('A',274110);st['phase']='ACTIVE';st['active']=next(iter(st['actors']))
        st['actors'][st['active']]['resource']['hp']-=2
        st['actors'][st['active']]['resource']['standard']=0
        with self.assertRaisesRegex(v.LabHold,'STANDARD_ACTION_UNAVAILABLE'):v.preflight_heal(st,dict(SRC))
    def test_10_cannot_revive_hp_zero(self):
        st=v.initial('A',274110);st['phase']='ACTIVE';st['active']=next(iter(st['actors']))
        st['actors'][st['active']]['resource']['hp']=0
        with self.assertRaisesRegex(v.LabHold,'NOT_INJURED'):v.preflight_heal(st,dict(SRC))
    def test_11_heal_does_not_apply_twice(self):
        self.start();self.attack();self.heal();prev,_,rv=v.load(self.db)
        # Same deterministic command-id fails without native effect or state change.
        with self.assertRaises(v.LabHold):v.event_commit(self.db,v._uid(self.db,rv-1,'HEAL'),'HEAL',dict(SRC),v.do_heal,preflight=v.preflight_heal)
        self.assertEqual(v.load(self.db)[0],prev)
    def test_12_subprocess_reopen(self):
        self.start();self.attack();self.heal()
        code='import sys;sys.path.insert(0,sys.argv[1]);import vlab_r18_interactive as v;s,h,n=v.load(sys.argv[2]);assert n==3;print(h)'
        o=subprocess.run([sys.executable,'-c',code,str(pathlib.Path(v.__file__).parent),str(self.db)],capture_output=True,text=True,check=True)
        self.assertEqual(len(o.stdout.strip()),64)
    def test_13_intent_crash_fail_closed(self):
        self.start();self.attack();s,_,rev=v.load(self.db)
        code='import sys;sys.path.insert(0,sys.argv[1]);import vlab_r18_interactive as v;db=sys.argv[2];s,h,n=v.load(db);v.event_commit(db,v._uid(db,n,"HEAL"),"HEAL",{"origin":"LAB-V06-MAGIC-HEAL-1D6"},v.do_heal,failpoint="AFTER_INTENT",preflight=v.preflight_heal)'
        o=subprocess.run([sys.executable,'-c',code,str(pathlib.Path(v.__file__).parent),str(self.db)],capture_output=True)
        self.assertEqual(o.returncode,78)
        with self.assertRaisesRegex(v.LabHold,'UNKNOWN_EFFECT'):v.load(self.db)
        self.assertEqual(self.metadata()[1],1)
    def test_14_commit_crash_not_repeated(self):
        self.start();self.attack()
        code='import sys;sys.path.insert(0,sys.argv[1]);import vlab_r18_interactive as v;db=sys.argv[2];s,h,n=v.load(db);v.event_commit(db,v._uid(db,n,"HEAL"),"HEAL",{"origin":"LAB-V06-MAGIC-HEAL-1D6"},v.do_heal,failpoint="AFTER_COMMIT",preflight=v.preflight_heal)'
        o=subprocess.run([sys.executable,'-c',code,str(pathlib.Path(v.__file__).parent),str(self.db)],capture_output=True)
        self.assertEqual(o.returncode,77)
        st,_,rv=v.load(self.db);self.assertEqual(rv,3);self.assertEqual(self.metadata()[1],0)
        self.assertEqual(len(v.history(self.db)['events']),3)
    def test_15_v06_pin_matters(self):
        self.start();self.attack()
        import a2_r03_condition_gateway as g
        old=g.INTERLOCK_SHA256;g.INTERLOCK_SHA256='0'*64
        try:
            with self.assertRaises(v.LabHold):self.heal()
            with self.assertRaisesRegex(v.LabHold,'UNKNOWN_EFFECT'):v.load(self.db)
        finally:g.INTERLOCK_SHA256=old
    def test_16_independent_saves_same_seed_same_hp(self):
        self.start();a=self.attack();b=self.heal()
        d=pathlib.Path(self.tmp.name)/'replica.sqlite';v.init_db(d,'A',274110)
        v.event_commit(d,'LAB-CMD-p-start','START',{},v.do_start)
        st,_,rev=v.load(d);target=next(i for i in st['actors'] if i!=st['active'])
        v.event_commit(d,'LAB-CMD-p-attack','ATTACK',{'target':target,'reaction':'NONE'},v.do_attack)
        v.event_commit(d,'LAB-CMD-p-heal','HEAL',dict(SRC),v.do_heal,preflight=v.preflight_heal)
        s1,_,n1=v.load(self.db);s2,_,n2=v.load(d)
        self.assertEqual((s1,n1),(s2,n2))
    def test_17_preflight_clone_cannot_mutate_journal(self):
        self.start();self.attack();st,_,rv=v.load(self.db)
        def rogue(s,p):s['actors'][s['active']]['resource']['hp']=999999;p['origin']='INVALID'
        row=v.event_commit(self.db,v._uid(self.db,rv,'HEAL'),'HEAL',dict(SRC),v.do_heal,preflight=rogue)
        self.assertLess(row['detail']['hp_after'],999999)
    def test_18_phase_and_max_hold_after_heal(self):
        self.start();self.attack();self.heal();s,_,r=v.load(self.db)
        self.assertEqual(s['phase'],'ACTIVE')
        self.assertTrue(all(0<=o['resource']['hp']<=o['stats']['hp'] for o in s['actors'].values()))
        self.assertEqual(len(v.history(self.db)['events']),3)

if __name__=='__main__': unittest.main()
