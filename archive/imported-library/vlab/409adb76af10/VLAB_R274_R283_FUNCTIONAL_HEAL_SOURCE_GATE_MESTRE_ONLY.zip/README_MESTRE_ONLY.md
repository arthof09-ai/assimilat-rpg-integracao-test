# PSV — VLAB R274–R283 | Continuidade funcional Mestre-only / TEST

## O que mudou

Esta entrega é **um patch incremental do mesmo VLAB R18**, não outra distribuição ou motor. Exige o histórico R18 original e o patch acumulado R269, autenticados por SHA-256. Não altera motores históricos, Notion, Party, O Primeiro, fichas, registros oficiais nem outros Comestres.

- **R274:** opção humana `7 Curar-se` em cenário fictício A/B com `1d6` e custo `0 PA` exclusivamente LAB, integrando o resolvedor **original v0.6** (`combat_interlocks_v06.source_gated_heal`) e preflight de recurso **v0.7** (`turn_planner`). Ação Padrão única, HP máximo, turno e snapshot no mesmo SQLite R18.
- **R275:** preflight determinístico dentro de transação SQLite antes de intenção durável, para opções inválidas de cura. Efeitos desconhecidos após intenção continuam bloqueados.
- **R276:** preflight também para início, ataque e passar turno, inclusive empate de iniciativa sem regra; nada inventa desempate.
- **R277:** auditor `audit_r274_heal_independent.py`, read-only e sem import do motor; checksums, origem, PRNG, fonte e recibos v0.6. 14 ensaios de auditoria (13 negativos/1 positivo) aprovados. Na bateria ampliada foi descoberta e corrigida uma expectativa equivocada **somente no auditor** para `blocked_heal` quando a cura excede a Vida ausente.
- **R278:** seis demonstrações R269 vs R276 com o MESMO caminho SQLite/seed, 6/6 paridade exata de bytes, sem nova regra de combate.
- **R279:** CLI A e B com cura indevida em Vida cheia recusada sem interromper a sessão; depois ataque→cura→salvamento com três eventos cada.
- **R280:** 64 sementes independentes, 64 ações nativas TEST de cura, 192 commits/eventos, 64 relatórios independentes PASS; 247 Vida efetivamente restaurada de 249 rolada, 2 limiares de cap, 32 cenas A +32 B. **Não são eventos oficiais R91.**
- **R281:** exportação dos recibos somente após auditoria independente dos eventos de laboratório. Falsificação de resultado rehasheado aceito pelo journal genérico foi rejeitada na exportação, com zero arquivo criado.
- **R282:** fontes READ-ONLY de `Pulso de Estabilização` e `M - Cura espiritual` localizadas. Não são equivalentes à cura fictícia: Pulso é reação de 45 PA, alvo aliado a 3m, 3d10+10 Vida; Cura espiritual é 1d4+INT, custo publicado em 'mana', com lacunas. Ambos **HOLD** para integração em produção e não autorizaram mudança do cenário fictício.

- **R283:** a consulta humana ao histórico agora audita a proveniência antes de mostrar os recibos. O caminho de exportação reutiliza essa auditoria sem duplicar a execução. O teste de recuperação com WAL legítimo após crash continua PASS; estado WAL anterior ao recovery não tem autenticação externa (HOLD). Cinco testes específicos novos passaram.

## Fontes e provas

- ZIP histórico R18: `VLAB_STAGE12_A1A2A3_INTERACTIVE_R18_SANDBOX.zip` SHA256 `e079da7aa5c16364a18515de3f4941583e394dc345493adabb9d2db06faceefc`.
- Módulo R18 original: SHA256 `f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368`.
- Após patch histórico `R269_CUMULATIVE_R18_TO_R269.patch`: SHA256 `7d067adb99fe1f9e59e3c79791564c9c8e18b2d0f52c41339550ba1c09a94bd9`.
- Após `patch/R274_R283_INCREMENTAL_R269_TO_NEW.patch`: SHA256 `cc0527522e09f0a8b732adaf962f5ca3e018441b804cd9bf5fe32bcba0becc3d`.
- V06 interlock original SHA256 `3d5168e1bbdaddd365a3cab4eb2d418f66d14eaf68f4b7fe10e7a2ea3f9489fd`, verificação pela camada R03 legada. Não se reproduziu engine v0.9 histórico ausente.
- `verify_cold_install.py` recebe caminhos explícitos dos dois artefatos históricos, extrai R18 para diretório NOVO, aplica R269+R283 e executa 8 regressões históricas +49 testes novos. Foi executado fisicamente e passou nesta entrega.
- `portable_verify.py` confere todos os membros desta entrega. `SHA256_MANIFEST.json` contém SHA e tamanho dos arquivos.
- Os scripts R278/R279/R280/R281 foram preservados em `tests/` com seus relatórios em `reports/`; os caminhos locais podem precisar ser adaptados por outro executor. **Não incluem 64 arquivos SQLite duplicados**: `R280_64_HEAL_CASES.csv` contém os seeds e hashes, e o exemplo portátil de três eventos é `samples/heal_quick.sqlite`. Todos os programas de teste usam apenas cenários artificiais A/B.

### Como reproduzir a instalação fria

```bash
python verify_cold_install.py --historical-r18-zip /CAMINHO/VLAB_STAGE12_A1A2A3_INTERACTIVE_R18_SANDBOX.zip --r269-patch /CAMINHO/R269_CUMULATIVE_R18_TO_R269.patch --workdir /PASTA-NOVA-TEST
```

A ferramenta usa `patch` no sandbox criado, **nunca no ZIP original**. Requer Python 3.10+ e a ferramenta local `patch`. Sem componentes pagos, CI externo não foi executado.

## Gate, Inbox, estado

- `LAST-VERIFIED R283` condicionado a readback da Biblioteca; `FIRST-PENDING CANDIDATE R284`.
- NAC-PASS proporcional: **PASS local** de provas funcionais/cold install/ausência de alterações nos originais; **HOLD** para ações oficiais.
- `0/17` contratos terminais certificados; `0/1.875` células R91; não somar dados deste laboratório.
- Inbox Notion CM-000006: IBX-160/152 GitHub opcional; IBX-138 e anteriores sem ACK legítimo, perfil `BLOCK-PERMIT=RED`, `GREEN=HOLD`, writer/epoch/lease/fencing não verificados. Não escrever em Inbox/OP/Diário protegido.
- Próxima fronteira verdadeira: source-gate da cura com alvo externo e PA real, janela de reação, recibo nativo idempotente e alcance comprovado; se bloqueada, fonte P4 Besta/itens E; nunca incrementar contratos terminados por suíte sintética.
