"""Verify the incremental VLAB R274–R283 ZIP: CRC, exact members, file SHA."""
import argparse,hashlib,json,zipfile
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--zip',type=Path,required=True);args=ap.parse_args()
    with zipfile.ZipFile(args.zip) as f:
        bad=f.testzip()
        if bad:raise RuntimeError('CRC_ERROR:'+bad)
        names=set(f.namelist())
        if 'SHA256_MANIFEST.json' not in names:raise RuntimeError('MANIFEST_NOT_FOUND')
        manifest=json.loads(f.read('SHA256_MANIFEST.json'))
        expected=set(manifest['files'])|{'SHA256_MANIFEST.json'}
        if names!=expected:raise RuntimeError('MEMBER_COUNT_MISMATCH:'+repr(sorted(names.symmetric_difference(expected))))
        for name,info in manifest['files'].items():
            if Path(name).is_absolute() or '..' in Path(name).parts:raise RuntimeError('BAD_MEMBER_PATH')
            data=f.read(name)
            if sha(data)!=info['sha256'] or len(data)!=info['size']:
                raise RuntimeError('SHA_MISMATCH:'+name)
    print(json.dumps({'result':'PASS','members':len(names),'files_sha_checked':len(names)-1,'zip':str(args.zip)},ensure_ascii=False))
if __name__=='__main__':main()
