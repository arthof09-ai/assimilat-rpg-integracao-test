"""Read-only scientific audit of R18 TEST self-healing; no motor import.

Verifies the published synthetic fixture, event-chain, PRNG assignments and
historical v0.6 healing semantics for this strictly lab-only action.
"""
from __future__ import annotations
import hashlib,json,random,sqlite3
from pathlib import Path

VERSION='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
HEAL_SOURCE='LAB-V06-MAGIC-HEAL-1D6'
FIXTURES={
'A':{'LAB_VIGIA_A':{'hp':28,'des':20,'init_bonus':0,'for':13,'luta':0,'damage_bonus':4},'LAB_VIGIA_B':{'hp':28,'des':5,'init_bonus':0,'for':14,'luta':0,'damage_bonus':5}},
'B':{'LAB_SENTINELA_A':{'hp':24,'des':20,'init_bonus':0,'for':13,'luta':0,'damage_bonus':4},'LAB_SENTINELA_B':{'hp':30,'des':5,'init_bonus':0,'for':13,'luta':0,'damage_bonus':5}}
}
class AuditHold(RuntimeError):pass

def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def draw(seed,seq,label,count,faces):
    key=hashlib.sha256(f'{seed}|{seq}|{label}|{count}d{faces}|{VERSION}'.encode()).digest()
    r=random.Random(int.from_bytes(key,'big'))
    return [r.randint(1,faces) for _ in range(count)]

def _eq(a,b,label):
    if a!=b:raise AuditHold('HEAL_OR_JOURNAL_MISMATCH:'+label)

def check(db):
    p=Path(db)
    if not p.is_file() or p.with_name(p.name+'-wal').exists() or p.with_name(p.name+'-shm').exists():
        raise AuditHold('SQLITE_FILE_NOT_SAFELY_CLOSED')
    uri=p.resolve().as_uri()+'?mode=ro&immutable=1'
    con=sqlite3.connect(uri,uri=True)
    try:
        meta=dict(con.execute('SELECT key,value FROM meta'))
        if con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]:
            raise AuditHold('PENDING_UNKNOWN_EFFECT_HOLD')
        rows=list(con.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq'))
    except sqlite3.Error as e:raise AuditHold('SQLITE_SCHEMA_FAILURE') from e
    finally:con.close()
    try:st=json.loads(meta['state']);seed=st['seed'];scene=st['scene'];rev=int(meta['revision'])
    except (KeyError,ValueError,TypeError) as e:raise AuditHold('STATE_INVALID') from e
    if scene not in FIXTURES or type(seed) is not int or st.get('version')!=VERSION:
        raise AuditHold('SOURCE_NOT_SYNTHETIC_R18')
    if rev!=len(rows):raise AuditHold('REVISION_CARDINALITY_MISMATCH')
    prev=digest({'seed':seed,'scene':scene,'version':VERSION})
    if meta.get('genesis')!=prev:raise AuditHold('GENESIS_MISMATCH')
    actors=FIXTURES[scene]
    hp={a:v['hp'] for a,v in actors.items()};nonce=0;order=None;active=None;heals=0
    for i,cmd_id,stored_prev,j,stored_sha,before_sha,after_sha in rows:
        try:e=json.loads(j)
        except (ValueError,TypeError) as exc:raise AuditHold('MALFORMED_ROW') from exc
        _eq(i,e.get('seq'),'SEQUENCE')
        _eq(stored_prev,prev,'PREV')
        _eq(e.get('prev'),prev,'ROW_PREV')
        _eq(stored_sha,digest(e),'HASH')
        _eq(e.get('before_sha'),before_sha,'BEFORE_SHA')
        _eq(e.get('after_sha'),after_sha,'AFTER_SHA')
        _eq(e.get('synthetic'),True,'SYNTHETIC')
        _eq(e.get('official_effects'),0,'OFFICIAL_ZERO')
        _eq(cmd_id,e.get('cmd_id'),'CMD')
        d=e.get('detail')
        if not isinstance(d,dict):raise AuditHold('DETAIL_NOT_OBJECT')
        kind=e.get('kind')
        if kind=='START':
            if order is not None:raise AuditHold('START_DUPLICATE')
            _eq(d.get('kind'),'INITIATIVE','INIT_KIND')
            order=d.get('order')
            if not isinstance(order,list) or len(order)!=len(actors) or set(order)!=set(actors):
                raise AuditHold('INVALID_ORDER')
            totals={aid:sum(draw(seed,0,'initiative:'+aid,1,6))+cfg['des']+cfg['init_bonus'] for aid,cfg in actors.items()}
            expected=sorted(totals,key=lambda a:-totals[a])
            if len(set(totals.values()))!=len(totals):raise AuditHold('TIED_INITIATIVE_REQUIRES_NORM')
            _eq(order,expected,'INITIATIVE_ORDER')
            active=order[0]
        elif kind=='ATTACK':
            if order is None:raise AuditHold('ATTACK_BEFORE_START')
            nonce+=1
            att=d.get('attacker');target=d.get('target');dat=d.get('dice',{})
            if att!=active or target not in actors or target==att:raise AuditHold('BAD_ATTACK_ACTOR_TARGET')
            _eq(dat.get('attack'),draw(seed,nonce,'tohit:'+att,1,6),'TOHIT_DRAW')
            _eq(dat.get('damage'),draw(seed,nonce,'damage:'+att,1,6),'DAMAGE_DRAW')
            _eq(dat.get('attack_score'),sum(dat['attack'])+actors[att]['for']+actors[att]['luta'],'TOHIT_SCORE')
            _eq(dat.get('damage_requested'),sum(dat['damage'])+actors[att]['damage_bonus'],'DAMAGE_REQUESTED')
            later=d.get('state_hp')
            if not isinstance(later,dict) or set(later)!=set(actors):raise AuditHold('STATE_HP_SET')
            for aid,value in later.items():
                if type(value) is not int or not 0<=value<=actors[aid]['hp']:
                    raise AuditHold('STATE_HP_OUT_OF_RANGE')
                if aid!=target and value!=hp[aid]:raise AuditHold('UNRELATED_HP_DRIFT')
            hp=later.copy()
            next_actor=None if any(h<=0 for h in hp.values()) else order[(order.index(att)+1)%len(order)]
            _eq(d.get('control',{}).get('turn_end'),att,'ATTACK_TURN_END')
            _eq(d.get('control',{}).get('next_turn'),next_actor,'ATTACK_NEXT_TURN')
            active=next_actor
        elif kind=='HEAL':
            if order is None:raise AuditHold('HEAL_BEFORE_START')
            _eq(e.get('payload'),{'origin':HEAL_SOURCE},'SOURCE_PAYLOAD')
            _eq(d.get('kind'),'HEAL_V06_SYNTHETIC','HEAL_KIND')
            aid=d.get('actor')
            if aid!=active or aid not in actors:raise AuditHold('HEAL_WRONG_TURN')
            before=hp[aid];cap=actors[aid]['hp']
            if not 0<before<cap:raise AuditHold('HEAL_INVALID_LIVING_TARGET')
            nonce+=1
            amount=draw(seed,nonce,'LAB-R274-HEAL:'+aid,1,6)
            expected_amount=min(sum(amount),cap-before)
            expected_receipt={'eligible':True,'blockers':[],'hp_after':before+expected_amount,
                'ordinary_damage_after':cap-before-expected_amount,
                'locked_damage_after':0,'healed':expected_amount,'blocked_heal':sum(amount)-expected_amount,
                'mode':'UNIT_FIXTURE','winner':None,'canonical_credit':0}
            _eq(d.get('hp_before'),before,'HEAL_BEFORE')
            _eq(d.get('dice'),amount,'HEAL_DICE')
            _eq(d.get('hp_after'),before+expected_amount,'HEAL_AFTER')
            _eq(d.get('v06_receipt'),expected_receipt,'HISTORICAL_V06_RECEIPT')
            _eq(d.get('pa_cost'),0,'PA_COST_LAB_ONLY')
            _eq(d.get('source_status'),'LAB_FIXTURE_COST_AND_1D6_NOT_CANON','HEAL_SOURCE_STATUS')
            _eq(d.get('canonical_credits'),0,'NO_CREDIT')
            hp[aid]=before+expected_amount;heals+=1
            next_actor=order[(order.index(aid)+1)%len(order)]
            _eq(d.get('control',{}).get('turn_end'),aid,'HEAL_TURN_END')
            _eq(d.get('control',{}).get('next_turn'),next_actor,'HEAL_NEXT_TURN')
            active=next_actor
        elif kind=='PASS':
            if order is None or d.get('actor')!=active:raise AuditHold('PASS_OUTSIDE_ACTIVE_TURN')
            next_actor=order[(order.index(active)+1)%len(order)]
            _eq(d.get('control',{}).get('next_turn'),next_actor,'PASS_NEXT_TURN')
            active=next_actor
        else:raise AuditHold('UNSUPPORTED_EVENT_KIND:'+str(kind))
        if active is not None and active not in actors:raise AuditHold('CONTROL_UNKNOWN_NEXT_ACTOR')
        prev=stored_sha
    _eq(meta.get('head'),prev,'META_HEAD')
    _eq(st.get('roll_nonce'),nonce,'FINAL_NONCE')
    _eq(st.get('active'),active,'FINAL_ACTIVE')
    for aid,value in hp.items():_eq(st['actors'][aid]['resource']['hp'],value,'FINAL_HP_'+aid)
    return {'status':'PASS_LIMITED_SYNTHETIC_HEAL_SOURCE','heals':heals,'events':len(rows),
        'head':prev,'source':'R18 scenario A/B; original v0.6 heal semantics; LAB only','terminal_contracts':0}

if __name__=='__main__':
    import sys
    print(canonical(check(sys.argv[1])))
