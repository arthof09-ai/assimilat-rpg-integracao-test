"""Cold, non-destructive verification of VLAB R274–R283 incremental patch.

Requires authoritative R18 historical ZIP and existing R269 cumulative patch
from package R267–R271, both separately obtained from the Master's Library.
Writes only under a NEW supplied --workdir.
"""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
EXPECTED_R18_ZIP='e079da7aa5c16364a18515de3f4941583e394dc345493adabb9d2db06faceefc'
EXPECTED_R18_CORE='f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368'
EXPECTED_R269_CORE='7d067adb99fe1f9e59e3c79791564c9c8e18b2d0f52c41339550ba1c09a94bd9'
EXPECTED_R283_CORE='cc0527522e09f0a8b732adaf962f5ca3e018441b804cd9bf5fe32bcba0becc3d'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked_run(command,**kwargs):
    out=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,**kwargs)
    if out.returncode:raise RuntimeError(f'FAILED {command} (exit {out.returncode}):\n{out.stdout[-5000:]}')
    return out.stdout

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--historical-r18-zip',type=Path,required=True)
    ap.add_argument('--r269-patch',type=Path,required=True)
    ap.add_argument('--workdir',type=Path,required=True)
    a=ap.parse_args()
    release=Path(__file__).resolve().parent
    if a.workdir.exists():raise RuntimeError('WORKDIR_ALREADY_EXISTS: pass a new empty destination')
    if sha(a.historical_r18_zip)!=EXPECTED_R18_ZIP:raise RuntimeError('HISTORICAL_R18_ZIP_SHA_MISMATCH')
    a.workdir.mkdir(parents=True)
    with zipfile.ZipFile(a.historical_r18_zip) as f:
        if f.testzip() is not None:raise RuntimeError('HISTORICAL_R18_CRC_FAILURE')
        names=f.namelist()
        if any(Path(n).is_absolute() or '..' in Path(n).parts for n in names):raise RuntimeError('ZIP_PATH_TRAVERSAL')
        f.extractall(a.workdir)
    mod=a.workdir/'fusion_stage12'/'vlab_r18_interactive.py'
    if sha(mod)!=EXPECTED_R18_CORE:raise RuntimeError('HISTORICAL_R18_MODULE_SHA_MISMATCH')
    log=[]
    log.append(checked_run(['patch','-p1','--batch','-i',str(a.r269_patch.resolve())],cwd=a.workdir))
    if sha(mod)!=EXPECTED_R269_CORE:raise RuntimeError('R269_BASE_MODULE_SHA_MISMATCH')
    current=release/'patch'/'R274_R283_INCREMENTAL_R269_TO_NEW.patch'
    log.append(checked_run(['patch','-p1','--batch','-i',str(current.resolve())],cwd=a.workdir))
    if sha(mod)!=EXPECTED_R283_CORE:raise RuntimeError('R283_MODULE_SHA_MISMATCH')
    auditor=a.workdir/'fusion_stage12'/'audit_r274_heal_independent.py'
    shutil.copyfile(release/'code'/'audit_r274_heal_independent.py',auditor)
    env=dict(os.environ,PYTHONPATH=str(a.workdir/'fusion_stage12'))
    cwd=a.workdir/'fusion_stage12'
    old=checked_run([sys.executable,'-m','unittest','-q','test_vlab_r18_interactive'],cwd=cwd,env=env)
    new1=checked_run([sys.executable,'-m','unittest','discover','-q','-s',str(release/'tests'),'-p','test_r27*.py'],cwd=cwd,env=env)
    new2=checked_run([sys.executable,'-m','unittest','discover','-q','-s',str(release/'tests'),'-p','test_r283*.py'],cwd=cwd,env=env)
    # Audit independent source against a separately provided frozen synthetic fixture.
    checker=checked_run([sys.executable,str(auditor),str(release/'samples'/'heal_quick.sqlite')],cwd=cwd,env=env)
    result={'status':'PASS_COLD_FROM_ORIGINAL','r18_zip_sha':sha(a.historical_r18_zip),
      'r283_module_sha':sha(mod),'auditor_sha':sha(auditor),'native_historical_tests':8,
      'new_tests':49,'fixture_audit':json.loads(checker.strip()),
      'patch_log':log,'native_test_log':old[-600:],'new_test_log':[new1[-600:],new2[-600:]],
      'terminal_contracts_certified':0,'official_R91_cells':0}
    (a.workdir/'R283_COLD_VALIDATION.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
