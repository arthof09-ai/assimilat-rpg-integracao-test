# R37 — Reprodução e retomada (Mestre-only)

O ZIP contém 4 bancos SQLite e 4 backups recuperáveis e verificáveis sem motor por `code/verify_r37_standalone.py` (para conferir os hashes de R27–R36, colocar os dez ZIP históricos nas posições usadas pelo script ou adaptar somente esses caminhos de arquivos, sem modificar conteúdo).

Para reprodução nativa a partir de uma cópia limpa, usar **exatamente** os arquivos históricos do pacote R27 e o adaptador R36 (mais dependências R35). O script `code/run_r37_always_dodge.py` importa `run_r36_dodge` da árvore R36 sem editar o motor. Não reexecutar scripts `run_*.py` contra os quatro bancos R37 existentes: todos têm identidade transacional própria e são imutáveis. Para um novo estudo, usar diretório de trabalho/cena e sementes NOVOS e preservar a decisão Mestre no Notion.

A função `R37_CENSORED` é encerramento **analítico do horizonte de observação**, não uma regra canônica de combate, não aplica dano nem escolhe vencedor. Tabelas de contratos são uma reconciliação da matriz ORIGINAL dos 17 do R18 preservada em R27; não as promover só porque foram geradas.

Verificações rápidas: `python code/test_r37_tie.py` e `python code/verify_r37_standalone.py`; os scripts de testes de empate executam somente clones descartáveis. O programa original para gerar os quatro bancos está incluído para auditoria e eventual reprodução em diretório SEPARADO, não para execução de novo na mesma pasta.
