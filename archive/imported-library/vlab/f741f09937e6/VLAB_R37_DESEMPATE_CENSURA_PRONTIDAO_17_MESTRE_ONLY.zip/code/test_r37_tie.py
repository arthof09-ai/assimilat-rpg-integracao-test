"""Mestre-only: test exact tie in original native v0.8.1, using disposable synthetic boundary fixtures.
This does NOT confer real-source Defender admission to Cabra; Armor/Fortitude stay NULL in all official snapshots.
"""
import sys,copy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,'/mnt/data/vlab_r36')
import run_r36_dodge as m
from vlab_action_catalog_v01 import ActorActionState
from vlab_effects_v08 import Scene,Combatant,react_defensively,apply_weapon_attack,EffectBlocked
from vlab_rd_v08 import Resistances
from dataclasses import replace

def probe(kind,score,ca=20):
 st=m.init_state(m.b.initialize_state(m.j.initial('A',8000+score),'MIRROR'),m.POLICIES[1])
 a,b=m.b.ids('MIRROR')
 actors={k:Combatant(**copy.deepcopy(v['resource'])) for k,v in st['actors'].items()}
 if kind=='DEFENDER':
  actors[b].ca=10 # STRICTLY SYNTHETIC: exposed to an attack that passes CA but ties Defender 16
  actors[b].armor=0;actors[b].fortitude=0
  expected=16
 else:expected=26
 scene=Scene(actors,seed=8000+score,provenance='R37-EPHEMERAL-BOUNDARY-SYNTHETIC-NONCAN')
 src=m.source_reaction()
 if kind=='DEFENDER':src=replace(src,action_id='R37_DEFENDER_LAB_UNIT_PROBE')
 proof=m.proof_reaction()
 drstate=ActorActionState(actor_id=b,ordinal_level=1,available_pa=22,known_action_ids=(src.action_id,),reaction_available=True,reaction_trigger_observed='BEFORE-ATTACK',enemy_ids_visible=(a,))
 ev=react_defensively(scene,b,kind=kind,attack_score=score,announced_before=True,trigger_source='BEFORE-ATTACK',source=src,state=drstate,proofs=(proof,),strict=True)
 attack=m.b.native_source();pr=m.b.proof('MIRROR')
 attstate=ActorActionState(actor_id=a,ordinal_level=1,available_pa=22,known_action_ids=(m.b.GO_ACTION,),standard_available=True,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(b,))
 hit=apply_weapon_attack(scene,a,b,source=attack,state=attstate,proofs=(pr,),roll_score=score,damage=19,damage_tag='impacto',rd=Resistances(general=5,specific=(),provenance='R37-SYNTHETIC-LAB-RD5'),strict=True,defense_event=ev)
 expected_negated=score<=expected
 assert ev['defense_exact']==str(expected) and ev['damage_negated'] is expected_negated and scene.actors[b].reaction==0
 assert hit['hit'] and hit['defense_negated'] is expected_negated and hit['net']==(0 if expected_negated else 14)
 assert actors[a].pa==22 and scene.actors[a].standard==0
 return {'kind':kind,'attack_score':score,'defense':expected,'tie':score==expected,'defense_won':ev['damage_negated'],'hp_after':scene.actors[b].hp,'reaction_spent':True,'standard_spent':True,'native_engine':'v0.8.1.react_defensively+apply_weapon_attack','fixture':'SYNTHETIC_BOUNDARY_NOT_BEAST_SOURCE'}

if __name__=='__main__':
 rows=[probe('ESQUIVAR',26),probe('ESQUIVAR',27),probe('DEFENDER',16),probe('DEFENDER',17)]
 out={'schema':'R37_TIE_NATIVE_BOUNDARY_V1','checks':rows,'verified':len(rows),'total':len(rows),'exact_equalities_defense_wins':2,'strictly_higher_attacks_defense_loses':2,'gameworld_writes':0}
 p=ROOT/'evidence'/'R37_TIE_BOUNDARY_NATIVE.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(out,ensure_ascii=False))
