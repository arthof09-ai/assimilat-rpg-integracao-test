"""Existing-first: retain the EXACT 17 R18 gate requirements from original immutable R27 ZIP.
R34-R37 bounded evidence is not terminal certification. No new contract identities.
"""
from __future__ import annotations
import zipfile,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
BASE=Path('/mnt/data/vlab_recovery/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip')
EVID={
'ACTION_CATALOG_AIN01':('R31–R36','Rabada/Investida/Esquivar admissões estritas individuais','Catalogação de armas, magia, equipamento e efeitos restantes ainda incompleta'),
'ACTOR_SNAPSHOT_SCENARIO':('R31–R37','Snapshots de Cabra, Frígido, Galidemus usados em sandbox com proveniência de Notion','Não há freeze das fichas atuais, equipamentos nem 14 gates para todos os atores'),
'AUTHORITATIVE_RULES_AND_ADAPTERS':('R32–R37','Ordens expressas para Rabada, Investida, Reflexo e desempate auditadas','Outras regras e conflitos de precedência não reconciliados universalmente'),
'BATTLE_1X1_2X1_20X20':('R34–R37','Duelos 1x1 reais de mesmo/variado patamar, turnos, push e Reações','2x1, party e até 20x20 não certificados nem efeitos completos'),
'BLEED_AND_HEAL_RESTRICTIONS':('R27 legado','Intertravamentos sintéticos históricos; nenhuma prova real-fonte R34–R37','Sangramento e cura reais não integrados ponta a ponta'),
'ED_VS_BE_DAMAGE':('R27 legado','Ciência comparativa de Bestas, NÃO ED x Besta','Fontes reais ED e Besta e habilidades/magias completas não admitidas'),
'GENERAL_SPECIFIC_RD':('R34–R37','RD geral Bronze 5 aplicada nativamente em 1x1','Stacking RD geral/específica, RDF Rinolupo e bypass ainda sem ruling'),
'ITEM_EQUIPMENT_AND_ENHANCEMENTS':('R27 legado','Nenhum equip ativo real usado na bateria de Bestas','Snapshots ativos/custos/equipamento/aperfeiçoamentos não congelados'),
'OFFICIAL_QA_NAC_LEDGERS':('R34–R37','SQLite e replay APENAS sandbox; auditoria local','NAC-PASS independente, writer/ledger/células oficiais em HOLD'),
'PA_AND_PREBUFF_COSTS':('R34–R37','Ações 0 PA, Ação Padrão, slots comprovados','PA positiva, prebuff, custo sustentado e timing completos não provados'),
'REACTION_TRIGGER_AND_SINGLE_USE':('R36–R37','Esquiva antes do ataque, um slot, renovação e empate defesa vence','Reações múltiplas simultâneas, interrupções, Defender com bônus oficiais não provados'),
'RNG_REPLAY_STATISTICS':('R29–R37','RNG por ator, seeds pareadas, replay SQLite, censura declarada','Fonte de dados canônica, holdout/semântica ampla de estatísticas não certificadas'),
'SOURCE_FREEZE_AND_RANK':('R31–R37','Fichas reais via readback e IDs de Notion, rank Bronze1/Bronze5','Fonte atual completa, carga, digest oficial/14 gates não congelados'),
'TACTICAL_AI_AB_FAIRNESS':('R35–R37','Políticas experimentais DECLINE, EVADE e Movimento comparadas','IA tática autônoma com observabilidade, fairness e auditoria cega ausentes'),
'TRANSFORMATION_OVERLAY_AI08':('R27 legado','Adaptador histórico parcial documentado','Overlay real, PA, expiração e alterações de estatísticas não integrados'),
'TRANSFORMATION_PER_SCENE_AI09':('R27 legado','Reconstrução documental histórica; v0.9 binário original não entregue','Controle real de uso por cena/descanso/expiração e promoção ainda não comprovados'),
'TURN_SCHEDULER_EVENT_SOURCING':('R34–R37','Iniciativa R26, turnos R18, geometrias, ledger, replay, censura analítica','Iniciativa/tiebreak canônicos para todas fontes, interrupção e eventos completos ainda não provados'),
}
with zipfile.ZipFile(BASE) as z:
 obj=json.loads(z.read('reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json'))
rows=obj['rows'];assert len(rows)==17 and len({r['contract_id'] for r in rows})==17 and set(EVID)=={r['contract_id'] for r in rows}
result=[]
for r in rows:
 n=r['contract_id'];period,bounded,remaining=EVID[n]
 result.append({'contract_id':n,'r18_terminal_requirement_exact':r.get('original_acceptance_still_required'),
 'r18_state':'PARTIAL_LAB_ONLY','r37_latest_evidence_span':period,'experimental_evidence_only':bounded,
 'terminal_missing':remaining,'independent_terminal_audit':'NOT_PERFORMED','nac_pass_02_terminal':'HOLD',
 'formal_contract_certified':False,'promotion_eligible':False})
matrix={'schema':'R37_ORIGINAL_17_CONTRACTS_READINESS_EVIDENCE_V1','master_side':True,
 'source_archive':'VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip','source_archive_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),
 'baseline_matrix':'reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json',
 'denominator':17,'terminal_certified':0,'mapping_completed':17,'rows':result,
 'historical_v09_binary_missing_not_global_block_to_documented_reconstruction':True,
 'v09_binary_equivalence_claimed':False,'reconstructed_functionality_can_be_validated_separately':True,
 'prohibition':'No 0/17 to PASS without independent gate by contract and NAC-PASS; no canonical or Party writes',
 'canonical_cells':{'credited':0,'denominator':1875},'world_effects':0}
out=R/'evidence'/'R37_17_CONTRATOS_PRONTIDAO.json';out.write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
md=['# R37 — Prontidão dos 17 contratos VLAB existentes','',
 '**Resultado: 17/17 contratos mapeados; 0/17 terminais certificados.** Não são 17 combates, mas 17 capacidades de fusão preservacional. Evidência experimental recente ≠ homologação de integração/produção.','',
 '| Contrato existente | Evidência até R37 | Pendência terminal principal |','|---|---|---|']
for a in result:
 md.append(f"| `{a['contract_id']}` | {a['experimental_evidence_only']} | {a['terminal_missing']} |")
md += ['', '**Critério comum:** exigência R18 específica, auditoria independente, NAC-PASS-02 no marco aplicável, estado oficial e autorização produtiva independentes. A ausência do executável v0.9 impede alegar paridade binária histórica, mas não impede validar capacidades reconstruídas nos limites autorizados pelo Mestre.','',
 'Próximo lote recomendado, sem criar novos contratos: (1) REACTION_TRIGGER_AND_SINGLE_USE e TURN_SCHEDULER_EVENT_SOURCING — portas com evidência mais concreta; (2) SOURCE_FREEZE_AND_RANK e ACTION_CATALOG_AIN01 — cobertura de fontes; (3) capacidade de batalha 2x1/grupos. Não alterar 0/17 até critério integral fechado.']
(R/'R37_MATRIZ_PRONTIDAO_17.md').write_text('\n'.join(md)+'\n',encoding='utf8')
print('MATRIX',len(result),'CERT',sum(r['formal_contract_certified'] for r in result),'SHA',matrix['source_archive_sha256'])
