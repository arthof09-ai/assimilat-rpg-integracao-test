"""Package only NEW R37 evidence, preserving R27-R36 binaries unchanged."""
import json,hashlib,zipfile,os
from pathlib import Path
R=Path(__file__).resolve().parents[1]
OUT=R.parent/'VLAB_R37_DESEMPATE_CENSURA_PRONTIDAO_17_MESTRE_ONLY.zip'
exclude={'R37_PACKAGE_MANIFEST.json'}
files=sorted([p for p in R.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name not in exclude and not p.name.endswith(('-wal','-shm'))])
manifest={'schema':'R37_PACKAGE_FILE_MANIFEST_V1','file_count':len(files),'files':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'master_side':True,'old_files_embedded':False,'terminal_contracts_certified':0,'canonical_writes':0}
m=R/'R37_PACKAGE_MANIFEST.json';m.write_text(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in files+[m]:z.write(p,p.relative_to(R))
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)+1
 recovered=json.loads(z.read('R37_PACKAGE_MANIFEST.json'))
 assert recovered==manifest
 for n,h in manifest['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,(n,h)
print(json.dumps({'output':str(OUT),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'files':len(files),'zip_entries':len(files)+1,'hashes_verified':len(files),'CRC':'PASS'},ensure_ascii=False))
