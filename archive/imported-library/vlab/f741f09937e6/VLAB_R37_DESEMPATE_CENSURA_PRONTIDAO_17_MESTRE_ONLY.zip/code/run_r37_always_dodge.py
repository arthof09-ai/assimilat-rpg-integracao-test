"""R37: controlled policy extension over R36, original v0.8.1/R18/R26.
No new resolver, no R36 mutation; tenets: clean new ledger, shared seed independent streams,
crisp analytic censor rather than fabricated tie/winner after exactly 8 rounds.
"""
from __future__ import annotations
import sys,copy,json,sqlite3,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,'/mnt/data/vlab_r36')
import run_r36_dodge as m
from run_r36_dodge import Hold
j=m.j
ALWAYS='EVADE_EVERY_INCOMING'
if ALWAYS not in m.POLICIES:m.POLICIES=m.POLICIES+(ALWAYS,)
_original_choose=m.choose_reaction
def choose(st,target):
 if st['r36']['policy']==ALWAYS:return st['actors'][target]['resource']['reaction']==1
 return _original_choose(st,target)
m.choose_reaction=choose
AUTH=R/'evidence'/'R37_MASTER_TIE_READBACK.json'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(rel,obj):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
 return p

def censor(st,payload,seq):
 m.prereq(st)
 if payload.get('kind')!='R37_CENSOR' or payload.get('observed_attacks')!=16 or payload.get('policy')!=ALWAYS:raise Hold('BAD_CENSOR_PAYLOAD')
 x=st['r36']; hp=[v['resource']['hp'] for v in st['actors'].values()]
 if x['attacks']!=16 or x['net_damage']!=0 or x['reaction_announcements']!=16 or hp!=[38,38] or st['phase']!='ACTIVE':raise Hold('NOT_SAFE_CENSOR')
 st['phase']='CENSORED_LAB_AT_EIGHT_ROUNDS'
 st['winner']=None
 st['finish_reason']='OBSERVATION_BOUNDARY_NOT_GAME_ENDING_RULE'
 st['active']=None
 return {'event_type':'R37_ANALYTIC_CENSOR_NO_WINNER','observed_attacks':16,'rounds_observed':8,'hp_after':{k:v['resource']['hp'] for k,v in st['actors'].items()},'winner':None,'reason':'NO_DAMAGE_PROGRESS_AT_HORIZON','world_effects':0}

def replay(db,genesis):
 st,h,v=m.checked(db);log=j.history(db)
 cur=copy.deepcopy(genesis)
 for n,row in enumerate(log['events'],1):
  if row['kind']=='R37_INIT':detail=m.initialize(cur,row['payload'],n)
  elif row['kind']=='R37_NATIVE_TURN':detail=m.turn(cur,row['payload'],n)
  elif row['kind']=='R37_CENSORED':detail=censor(cur,row['payload'],n)
  else:raise Hold('UNKNOWN_EVENT_KIND')
  if j.sha(detail)!=j.sha(row['detail']) or j.sha(cur)!=row['after_sha']:raise Hold('REPLAY_MISMATCH_'+str(n))
 if cur!=st or v!=len(log['events']):raise Hold('HISTORY_STATE_MISMATCH')
 with sqlite3.connect(f'file:{db}?mode=ro',uri=True) as con:
  pending=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0];integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
 if pending!=0 or integrity!='ok':raise Hold('PENDING_OR_SQLITE_BAD')
 return {'status':'PASS','events':v,'pending':pending,'integrity':integrity,'head':h,'phase':st['phase'],'rounds':st['round'],'hp':{k:o['resource']['hp'] for k,o in st['actors'].items()},'winner':st['winner'],'native_attacks':st['r36']['attacks'],'reactions':st['r36']['reaction_announcements'],'dodge_success':st['r36']['dodge_success'],'damage':st['r36']['net_damage'],'pushes':st['r36']['forced_pushes'],'movements':st['r36']['voluntary_movements']}

def execute(seed,policy):
 if policy not in ['DECLINE',ALWAYS]:raise Hold('UNKNOWN_POLICY')
 proof=json.loads(AUTH.read_text())
 if proof.get('readback') is not True or proof.get('defense_wins_on_tie') is not True:raise Hold('R37_RULING_NOT_REOPENED')
 db=R/'runs'/f'R37_{seed}_{policy}.sqlite';backup=R/'checkpoints'/f'R37_{seed}_{policy}_backup.sqlite'
 if db.exists() or backup.exists():raise Hold('R37_NEVER_REUSE_DATABASE')
 st,head,rev=m.create(db,policy,seed)
 genesis=copy.deepcopy(st)
 j.event_commit(db,'LAB-CMD-R37-INIT-'+j.sha({'seed':seed,'policy':policy})[:24],'R37_INIT',{'kind':'INIT','seed':seed,'policy':policy,'auth_sha':m.b.sha_file(m.AUTH)},m.initialize)
 for n in range(16 if policy==ALWAYS else 24):
  st,head,rev=m.checked(db)
  if st['phase']!='ACTIVE':break
  p=m.payload_turn(st)
  j.event_commit(db,'LAB-CMD-R37-TURN-'+j.sha({'head':head,'payload':p})[:24],'R37_NATIVE_TURN',p,m.turn)
 else:
  if policy!=ALWAYS:raise Hold('DECLINE_FIGHT_NOT_FINISHED_AT_HORIZON')
 if policy==ALWAYS:
  st,head,rev=m.checked(db)
  if st['phase']!='ACTIVE':raise Hold('NOT_CENSORED_POLICY_TERMINATED_UNEXPECTEDLY')
  p={'kind':'R37_CENSOR','observed_attacks':16,'policy':ALWAYS}
  j.event_commit(db,'LAB-CMD-R37-CENSOR-'+j.sha({'head':head,'payload':p})[:24],'R37_CENSORED',p,censor)
 audit=replay(db,genesis)
 if policy==ALWAYS:
  if audit['phase']!='CENSORED_LAB_AT_EIGHT_ROUNDS' or audit['winner'] is not None or audit['native_attacks']!=16 or audit['reactions']!=16 or audit['damage'] or audit['pushes']:raise Hold('FALSE_CENSOR_CREDIT')
 else:
  if audit['phase']!='COMPLETE_LAB_REAL_SOURCE_REACTION_R36':raise Hold('CONTROL_NOT_COMPLETE')
 c=sqlite3.connect(db);o=sqlite3.connect(backup)
 try:c.backup(o)
 finally:o.close();c.close()
 checkpoint=replay(backup,genesis)
 if checkpoint!=audit:raise Hold('CHECKPOINT_REPLAY_FAILED')
 receipt={'schema':'R37_NATIVE_ALWAYS_DODGE_CENSOR_V1','seed':seed,'policy':policy,'source':'Cabra Bronze1 official snapshot x2, Mestre-only sandbox','contract':{'CA':20,'reflex':6,'dodge_defense':26,'tie_defense_wins':True,'Luta_specific_Investida':6},'r37_authority_sha256':sha(AUTH),'pre':{'hp':{k:v['resource']['hp'] for k,v in genesis['actors'].items()}},'after':audit,'ledger_file':db.name,'ledger_sha256':sha(db),'checkpoint_file':backup.name,'checkpoint_sha256':sha(backup),'checkpoint_replay':'PASS','campaign_effects':0,'full_fight_credit':int(policy=='DECLINE'),'censored_without_winner':policy==ALWAYS}
 write(f'evidence/R37_{seed}_{policy}_RECEIPT.json',receipt)
 return receipt

if __name__=='__main__':
 receipts=[execute(seed,policy) for seed in (503,509) for policy in ('DECLINE',ALWAYS)]
 write('evidence/R37_COMPARISON.json',{'schema':'R37_PAIRED_ALWAYS_DODGE_COMPARISON_V1','n_pairs':2,'runs':receipts,'full_fights_new':sum(r['full_fight_credit'] for r in receipts),'censored':sum(r['censored_without_winner'] for r in receipts),'causal_scope':'exploratory two seed pairs only; actor-local RNG; no invented terminal victory','campaign_effects':0})
 for r in receipts:print(r['seed'],r['policy'],r['after'])
