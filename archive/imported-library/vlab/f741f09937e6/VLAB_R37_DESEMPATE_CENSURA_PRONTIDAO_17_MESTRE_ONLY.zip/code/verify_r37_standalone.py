"""R37 independent, stdlib-only *read-only* integrity and rule evidence verification.
No engine import; open all SQLite with mode=ro. Not a canonical certification.
"""
from __future__ import annotations
import hashlib,json,sqlite3,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
ROOT=Path('/mnt/data')
def hpath(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sh(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')).hexdigest()
def ledger(p):
 with sqlite3.connect(f'file:{p}?mode=ro',uri=True) as c:
  assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
  assert c.execute('select count(*) from pending').fetchone()[0]==0
  meta=dict(c.execute('select key,value from meta'))
  rows=c.execute('select seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha from events order by seq').fetchall()
 assert int(meta['revision'])==len(rows)
 before=meta['genesis'];lastafter=None;history=[]
 for n,(seq,cmd,prev,row_json,row_sha,bsha,asha) in enumerate(rows,1):
  d=json.loads(row_json)
  assert n==seq==d['seq'] and cmd==d['cmd_id'] and cmd.startswith('LAB-CMD-R37-')
  assert prev==d['prev']==before and sh(d)==row_sha and d['before_sha']==bsha and d['after_sha']==asha
  if lastafter is not None:assert lastafter==bsha
  assert d['official_effects']==0 and d['kind'] in ('R37_INIT','R37_NATIVE_TURN','R37_CENSORED')
  history.append(d);before=row_sha;lastafter=asha
 state=json.loads(meta['state']);assert before==meta['head'] and sh(state)==lastafter
 assert state['source_status']=='SOURCE_REAL_READONLY_ISOLATED_SANDBOX'
 assert state['r35']['source_mode']=='MASTER_REAL_SOURCE_AUTHENTICATED_SANDBOX_NO_CANON'
 assert len(state['actors'])==2 and all(a['source_page_id']=='391c2b32-4ede-8252-b0cc-810423cdbfa6' for a in state['actors'].values())
 assert state['r36']['reflex_bonus']==6 and state['r36']['dodge_defense']==26
 assert state['r36']['world_effects']==0
 return {'meta':meta,'state':state,'events':history}

def main():
 assert (R/'evidence'/'R37_MASTER_TIE_READBACK.json').exists()
 boundary=json.loads((R/'evidence'/'R37_TIE_BOUNDARY_NATIVE.json').read_text())
 assert boundary['verified']==4 and boundary['exact_equalities_defense_wins']==2 and boundary['strictly_higher_attacks_defense_loses']==2
 matrix=json.loads((R/'evidence'/'R37_17_CONTRATOS_PRONTIDAO.json').read_text())
 assert matrix['denominator']==17 and matrix['mapping_completed']==17 and matrix['terminal_certified']==0
 assert len(matrix['rows'])==17 and len(set(x['contract_id'] for x in matrix['rows']))==17
 assert all(not x['promotion_eligible'] and not x['formal_contract_certified'] for x in matrix['rows'])
 origs={
 'VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip':('vlab_recovery/','d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1'),
 'VLAB_R28_CIENCIA_DIRIGIDA_MESTRE_ONLY.zip':('','68da72d6fe71020ce4a555089484514cc86cab67d90c92a77e52d2166c46fdfa'),
 'VLAB_R29_CIENCIA_BESTAS_E_CAUSALIDADE_MESTRE_ONLY.zip':('','0c9beb35b030f844cb109d44fa40bb2f5731665f0e056601252a7ec3c5ee2eb0'),
 'VLAB_R30_ACAO_REAL_PREFLIGHT_CIENCIA_MESTRE_ONLY.zip':('','55328526ce48c1acfa6568e6bc9e713762c8e33bf818b5aa2bc174c95c1838ae'),
 'VLAB_R31_PRIMEIRA_RABADA_NATIVA_CONDICIONAL_MESTRE_ONLY.zip':('','98841bf0473545005bdb107597981805199a35081e2dc84a4b6d150b97fa6835'),
 'VLAB_R32_PRIMEIRA_RABADA_INTEGRAL_REAL_FONTE_MESTRE_ONLY.zip':('','20530947c8349d8e544fa5ee506e7327b31a8e6d37eb3aab23c180d1639c4a53'),
 'VLAB_R33_PREPARACAO_COMBATE_REAL_FONTE_MESTRE_ONLY.zip':('','ceeab4d4786ee3670959be477c90c2dc42cce0806fb9d773e5814ca14bb9bb8b'),
 'VLAB_R34_PRIMEIRO_COMBATE_COMPLETO_BESTAS_REAIS_MESTRE_ONLY.zip':('','876236ebb34ee76f514b17d3ff765f32d40e1b8c81ef7f21248e0d34187705bc'),
 'VLAB_R35_EMPURRAO_GEOMETRIA_COMPARACAO_MESTRE_ONLY.zip':('','61c952c6d1896845fd2e96433bf65d1986eb313810304e708190109ce3b02413'),
 'VLAB_R36_ESQUIVA_NATIVA_PAREADA_MESTRE_ONLY.zip':('','b35f748db057f137a768d50e986037b87b7f8e0b2ddb17a70f23a5b2321506e5')}
 for name,(pre,dig) in origs.items():assert hpath(ROOT/pre/name)==dig,(name,hpath(ROOT/pre/name))
 runs=[]
 for seed in (503,509):
  for pol in ('DECLINE','EVADE_EVERY_INCOMING'):
   n=f'R37_{seed}_{pol}'
   db=R/'runs'/f'{n}.sqlite';b=R/'checkpoints'/f'{n}_backup.sqlite'
   x=ledger(db);y=ledger(b)
   assert x['meta']['head']==y['meta']['head'] and x['state']==y['state'] and x['events']==y['events']
   receipt=json.loads((R/'evidence'/f'{n}_RECEIPT.json').read_text())
   assert receipt['ledger_sha256']==hpath(db) and receipt['checkpoint_sha256']==hpath(b)
   assert receipt['checkpoint_replay']=='PASS'
   assert receipt['after']['events']==len(x['events'])
   st=x['state'];stat=st['r36'];assert st['phase']==receipt['after']['phase']
   if pol=='EVADE_EVERY_INCOMING':
    assert st['phase']=='CENSORED_LAB_AT_EIGHT_ROUNDS' and st['winner'] is None
    assert stat['attacks']==16 and stat['reaction_announcements']==16 and stat['dodge_success']==16
    assert stat['net_damage']==stat['forced_pushes']==stat['voluntary_movements']==0
    assert {k:v['resource']['hp'] for k,v in st['actors'].items()}=={'LAB_R35_GOAT_A':38,'LAB_R35_GOAT_B':38}
    assert len(x['events'])==18 and x['events'][-1]['kind']=='R37_CENSORED'
   else:
    assert st['phase']=='COMPLETE_LAB_REAL_SOURCE_REACTION_R36' and st['winner'] is not None
    assert stat['reaction_announcements']==0 and len(x['events'])==8
   runs.append({'seed':seed,'policy':pol,'events':len(x['events']),'native_attacks':stat['attacks'],'reactions':stat['reaction_announcements'],'hp':[v['resource']['hp'] for v in st['actors'].values()],'winner':st['winner']})
 report={'schema':'R37_STANDALONE_AUDIT_V1','status':'PASS','independent_of_combat_engine':True,'ledger_chains_verified':4,'sqlite_files_verified':8,'historical_archive_sha_verified':10,'tie_native_unit_cases':4,'contract_rows_original_ids':17,'terminal_certified':0,'runs':runs,'world_effects':0}
 (R/'evidence'/'R37_AUDIT_STANDALONE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
