# PSV — CM-000006 / OP-VLAB-FUSION-SANDBOX-01 — R37

**15/10/2026 · MESTRE-SIDE · teste e preparação terminal, não promoção.**

## ANTES / DECISÃO / DEPOIS

**ANTES:** R36 com 14 lutas completas entre fontes oficiais em sandbox, Esquiva da Cabra B1 por CA20+Reflexo6=26, 8 Reações voluntárias e 7 ataques que superariam CA20 neutralizados. Contratos terminais VLAB 0/17; células canônicas 0/1875; writer/lease/epoch/fencing/GREEN e NAC-PASS-02 produtivos HOLD. R01–R36, R29 seed53 interrompida e UNKNOWN_EFFECT anteriores preservados.

**DECISÃO MECÂNICA EXPRESSA DO MESTRE:** “Na esquiva ou defesa, se empatar, sempre quem ganha é a defesa.” Esta decisão foi escrita na OP existente e fisicamente reaberta em 2026-10-15T19:37:47.854Z. Aplica-se às Reações **ESQUIVAR** e **DEFENDER**; o ataque só vence se o placar superar a defesa. Não altera fórmula de CA, Reflexo ou dano. O motor v0.8.1 original já implementa `damage_negated = attack_score <= defense`, logo não foi modificado.

**VERIFICAÇÃO DE FRONTEIRA NATIVA (fixtures descartáveis):** 4/4: ESQUIVAR 26 × defesa26 → defesa vence/0 dano; ataque27 >26 → defesa perde/14 de dano após RD5; DEFENDER score16 × defesa16 → defesa vence/0; score17>16 → defesa perde/14 líquido. A prova DEFENDER usa **CA10/CON10/Armadura0/Fortitude0 hipotéticos em fixture sintética** para isolar a igualdade: NÃO é admissão de Defender para a Cabra, cuja ficha continua sem Armadura/Fortitude individualizados. Ambos usam `react_defensively()` + `apply_weapon_attack()` originais; Reação e Ação Padrão gastas no núcleo.

## R37 — ESQUIVAR CONTINUAMENTE, COM CENSURA

**Confronto:** duas instâncias efêmeras da mesma Cabra de Chifres Bronze1, cada qual identificada por referência à ficha Mestre oficial e contrato R34 da Investida, sem produzir duas espécies. Iniciativa LAB com bônus0 para ambas, Reações disponíveis e renovadas por R26 no início do próprio turno, geometria R35 e fontes reais congeladas R31–R36. Comparação com duas sementes **503 e 509**, fluxos de crítico/acerto/dano por ator e ordinal do próprio ataque. Políticas estabelecidas ANTES: `DECLINE` e `EVADE_EVERY_INCOMING` (anunciar Esquivar antes de todos os ataques enquanto o slot estiver disponível).

| Semente | Política | Observação | Ataques nativos | Esquivas | Dano líquido | Empurrões | Vencedor |
|---|---|---|---:|---:|---:|---:|---|
| 503 | Declinar | combate encerrou na rodada 4 | 7 | 0 | 65 (inclui overkill) | 5 | Cabra A |
| 503 | Esquivar sempre | 8 rodadas observadas; censurado | 16 | 16 | 0 | 0 | **Nenhum** |
| 509 | Declinar | combate encerrou na rodada 4 | 7 | 0 | 79 (inclui overkill) | 7 | Cabra B |
| 509 | Esquivar sempre | 8 rodadas observadas; censurado | 16 | 16 | 0 | 0 | **Nenhum** |

**CENSURA ≠ EMPATE OU COMBATE TERMINADO:** 8 rodadas foi um horizonte **experimental escolhido pelo laboratório**, não regra de encerramento da campanha. Ao fim dos 16 turnos, 38/38 HP para os dois atores; `winner=null`. Um evento **analítico** `R37_CENSORED` foi persistido e refeito em replay, separado das ações do motor. A fase final `CENSORED_LAB_AT_EIGHT_ROUNDS` não dá crédito de full-fight; também não concede imunidade global a críticos, outras ações, mudança de cenário ou reações indisponíveis. O estado `round=9` é o ponteiro da próxima rodada, não nove rodadas observadas.

**CRÉDITOS:** 2 novos combates completos (controles DECLINE); 2 ensaios censurados, 0 novos full-fights para os ensaios censurados. Total real-fonte sandbox histórico **16** (R34=1, R35=5, R36=8, controles R37=2). 32 novas Esquivas voluntárias observadas R37; 0 empurrões nas 2 cenas de Esquiva contínua. Cenários não canônicos.

## 17 CONTRATOS EXISTENTES — PRONTIDÃO, NÃO HOMOLOGAÇÃO

Recuperada literalmente a lista original de **17 contratos preservacionais** de `reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json` do R27, sem criar outra família/numeração. Cada linha contém a exigência terminal anterior, prova limitada R27–R37 e lacuna restante. **17/17 contratos mapeados para evidência**, **0/17 certificados**. Arquivo `evidence/R37_17_CONTRATOS_PRONTIDAO.json`; versão resumida `R37_MATRIZ_PRONTIDAO_17.md`.

**Capacidades mais maduras para próximo lote de validação:** `REACTION_TRIGGER_AND_SINGLE_USE`, `TURN_SCHEDULER_EVENT_SOURCING`, `ACTOR_SNAPSHOT_SCENARIO`, `ACTION_CATALOG_AIN01`, `RNG_REPLAY_STATISTICS`. Já há episódios funcionais auditáveis, mas faltam cobertura terminal específica, revisão independente competente, fonte congelada completa e NAC-PASS-02 conforme contrato.

**Lacunas materiais que impedem os 17/17:** RD geral/específica com stacking/bypass; PA positiva e prebuff; equipment/enhancements; ED×Besta com magia; sangramento/cura; transformação AI08/AI09; combate de grupos 2×1 até 20×20; IA tática auditada; créditos oficiais/ledger e gates de produção. Nenhuma dessas lacunas foi artificialmente fechada pelos combates da Cabra. A antiga v0.9 não possui executável original recuperado; isso impede alegar **paridade binária histórica**, sem impedir a validação independente de funcionalidades reconstruídas (autorização Mestre anterior).

**NORM-FUSION-ABSORB-01:** separa absorção arquitetural A–K (com revisão independente e NAC-PASS-ARQ) da absorção operacional com ABS-L, dependente de execução autorizada. Os resultados em sandbox são insumo experimental, não liberação produtiva.

## REPLAY, INTEGRIDADE E CONTINUIDADE

- Quatro transações SQLite novas, **4/4 replays nativos completos e 4/4 backups reabertos**; 52 eventos de ledger no total: 8+18+8+18; 4 eventos INIT, 46 eventos de ataque nativo, 2 censuras analíticas. Todas as 46 ações encaminhadas ao núcleo histórico v0.8.1, nenhuma intenção pendente; 4 `integrity_check=ok` originais e 4 checkpoints equivalentes.
- Auditor read-only independente **sem carregar motor**, `code/verify_r37_standalone.py`: cadeias/hashes de 4 ledgers, 8 SQLite, 10 hashes imutáveis históricos R27–R36, 4 unit-tests de empate, 17 identidades de contrato; **PASS**.
- Nunca reexecutar R36 ou quaisquer bancos R37 concluídos. Nenhum efeito em campanha, fichas, Party, O Primeiro, DMG-RANK-01 v1.1 ou motores preservados. Sem novos UNKNOWN_EFFECT.
- **PONTO EXATO:** a) submeter lote direcionado de contratos de Reação, scheduler e replay a uma auditoria independente sob requisitos terminais originais; b) fechar lacunas normativas e funcionais sob autoridade específica, sem inflar 0/17; c) executar futuras comparações de outras espécies legalmente admitidas; d) não normalizar censura como resultado de partida.

**NAC-PASS-02 terminal produtivo: HOLD.** O registro deste PSV e seus arquivos técnicos precisa de readback físico separado da matriz de certificação; a presente execução não declara promoção normativa nem writer produtivo.
