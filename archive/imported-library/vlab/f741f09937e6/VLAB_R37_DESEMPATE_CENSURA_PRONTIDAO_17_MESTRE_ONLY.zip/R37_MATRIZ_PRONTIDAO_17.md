# R37 — Prontidão dos 17 contratos VLAB existentes

**Resultado: 17/17 contratos mapeados; 0/17 terminais certificados.** Não são 17 combates, mas 17 capacidades de fusão preservacional. Evidência experimental recente ≠ homologação de integração/produção.

| Contrato existente | Evidência até R37 | Pendência terminal principal |
|---|---|---|
| `ACTION_CATALOG_AIN01` | Rabada/Investida/Esquivar admissões estritas individuais | Catalogação de armas, magia, equipamento e efeitos restantes ainda incompleta |
| `ACTOR_SNAPSHOT_SCENARIO` | Snapshots de Cabra, Frígido, Galidemus usados em sandbox com proveniência de Notion | Não há freeze das fichas atuais, equipamentos nem 14 gates para todos os atores |
| `AUTHORITATIVE_RULES_AND_ADAPTERS` | Ordens expressas para Rabada, Investida, Reflexo e desempate auditadas | Outras regras e conflitos de precedência não reconciliados universalmente |
| `BATTLE_1X1_2X1_20X20` | Duelos 1x1 reais de mesmo/variado patamar, turnos, push e Reações | 2x1, party e até 20x20 não certificados nem efeitos completos |
| `BLEED_AND_HEAL_RESTRICTIONS` | Intertravamentos sintéticos históricos; nenhuma prova real-fonte R34–R37 | Sangramento e cura reais não integrados ponta a ponta |
| `ED_VS_BE_DAMAGE` | Ciência comparativa de Bestas, NÃO ED x Besta | Fontes reais ED e Besta e habilidades/magias completas não admitidas |
| `GENERAL_SPECIFIC_RD` | RD geral Bronze 5 aplicada nativamente em 1x1 | Stacking RD geral/específica, RDF Rinolupo e bypass ainda sem ruling |
| `ITEM_EQUIPMENT_AND_ENHANCEMENTS` | Nenhum equip ativo real usado na bateria de Bestas | Snapshots ativos/custos/equipamento/aperfeiçoamentos não congelados |
| `OFFICIAL_QA_NAC_LEDGERS` | SQLite e replay APENAS sandbox; auditoria local | NAC-PASS independente, writer/ledger/células oficiais em HOLD |
| `PA_AND_PREBUFF_COSTS` | Ações 0 PA, Ação Padrão, slots comprovados | PA positiva, prebuff, custo sustentado e timing completos não provados |
| `REACTION_TRIGGER_AND_SINGLE_USE` | Esquiva antes do ataque, um slot, renovação e empate defesa vence | Reações múltiplas simultâneas, interrupções, Defender com bônus oficiais não provados |
| `RNG_REPLAY_STATISTICS` | RNG por ator, seeds pareadas, replay SQLite, censura declarada | Fonte de dados canônica, holdout/semântica ampla de estatísticas não certificadas |
| `SOURCE_FREEZE_AND_RANK` | Fichas reais via readback e IDs de Notion, rank Bronze1/Bronze5 | Fonte atual completa, carga, digest oficial/14 gates não congelados |
| `TACTICAL_AI_AB_FAIRNESS` | Políticas experimentais DECLINE, EVADE e Movimento comparadas | IA tática autônoma com observabilidade, fairness e auditoria cega ausentes |
| `TRANSFORMATION_OVERLAY_AI08` | Adaptador histórico parcial documentado | Overlay real, PA, expiração e alterações de estatísticas não integrados |
| `TRANSFORMATION_PER_SCENE_AI09` | Reconstrução documental histórica; v0.9 binário original não entregue | Controle real de uso por cena/descanso/expiração e promoção ainda não comprovados |
| `TURN_SCHEDULER_EVENT_SOURCING` | Iniciativa R26, turnos R18, geometrias, ledger, replay, censura analítica | Iniciativa/tiebreak canônicos para todas fontes, interrupção e eventos completos ainda não provados |

**Critério comum:** exigência R18 específica, auditoria independente, NAC-PASS-02 no marco aplicável, estado oficial e autorização produtiva independentes. A ausência do executável v0.9 impede alegar paridade binária histórica, mas não impede validar capacidades reconstruídas nos limites autorizados pelo Mestre.

Próximo lote recomendado, sem criar novos contratos: (1) REACTION_TRIGGER_AND_SINGLE_USE e TURN_SCHEDULER_EVENT_SOURCING — portas com evidência mais concreta; (2) SOURCE_FREEZE_AND_RANK e ACTION_CATALOG_AIN01 — cobertura de fontes; (3) capacidade de batalha 2x1/grupos. Não alterar 0/17 até critério integral fechado.
