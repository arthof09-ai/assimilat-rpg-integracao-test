# PSV — VLAB R284–R287 | Cura no navegador e recuperação verificável | MESTRE-ONLY

## Autoridade e continuidade

- Origem: `LAST-VERIFIED R283 → FIRST-PENDING R284`; esta unidade conclui `R284–R287` somente em TEST.
- OP única: `OP-VLAB-FUSION-SANDBOX-01`; CM lógico `CM-000006`, sem INSTANCE-ID/writer/lease/epoch/fencing comprovados. `BLOCK-PERMIT=RED`, `GREEN=HOLD`.
- Fontes físicas: ZIP R19 original SHA-256 `927e7fbee7fa25bac2bd4f84254552c9a7b2bf697c700cad10cab3170fdecfe9`, 2.223 membros; R18 central original SHA `f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368`. Motor v0.7/v0.8.1 preservado, v0.9 original historicamente ausente.
- Resultado: somente aplicação de **patches incrementais na própria UI R19**; nenhum segundo motor, nenhum núcleo histórico regravado, nenhuma ficha real, Party, O Primeiro, Notion, DMG ou ledger oficial escrito.

## Unidades concretas

- **R284:** opção `Curar-se (1d6 LAB, 0 PA fictício)` durante turno em cenas A/B. A UI delega preflight/comando ao R18; o R18 usa resolvedor histórico v0.6 com input puramente fictício. Histórico web/recibos expõem antes/depois. Cura inválida não envenena journal.
- **R285:** fonte auditada por `core.history` antes de listar um salvamento como válido, gravar nova ação, criar backup, reiniciar ou restaurar. Gatilhos adversariais: event row com SHA recalculado aceito pela cadeia genérica mas recusado pela fonte independente. Backup/restauração limpos seguem funcionais.
- **R286:** 64 seeds fixas, 64 curas HTTP realizadas, 249 Vida sintética restaurada, fontes e resultados checados por auditor independente (teste separado; não 64 duelos completos).
- **R287:** 8 pares de provas end-to-end HTTP `START→ATTACK→HEAL→BACKUP→RESTORE→CONTINUE→COMPLETE`, 16 SQLite finais, 146 eventos combinados. Por par: estados finais e detalhes mecânicos idênticos, hashes locais de journals podem diferir pelos IDs de salvamento. Um par reiniciou o servidor local, **não comprova crash distribuído**.

## Gate executado e números

O relatório `evidence/FINAL_COLD_EXECUTION_R284_R287.json` foi produzido por `PORTABLE_INSTALL_AND_TEST.py` diretamente de um novo diretório extraído do ZIP R19, aplicando os patches em ordem e executando:

1. R18 histórico 8 + R19 histórico 8 = **16 PASS**;
2. R284 novos **8 PASS**; R285 novos **8 PASS**;
3. R286 **64/64** seeds com HEAL e auditoria independente;
4. R287 **8/8** pares de restauro/continuação;
5. CRC do ZIP pai, SHA de origem e de módulos finais conferidos.

Resultado: **PASS local delimitado**; **NAC-PASS terminal HOLD**, **0/17 contratos**, **0/1.875 células R91**. Não há magia de campanha de custo zero canonizada. O modo web é `127.0.0.1` num computador com Python: não é site remoto nem app Android. UAT humana da Party ou Mestre não foi demonstrada.

## Reproduzir sem criar outro motor

Este ZIP contém apenas diffs, auditores e testes. **Não contém o ZIP R19 original de 15 MB e não o renomeia.** Disponibilize o arquivo R19 original íntegro, depois execute, em ambiente POSIX com Python 3.10+ e ferramenta `patch`:

`python PORTABLE_INSTALL_AND_TEST.py --parent /caminho/VLAB_STAGE12_A1A2A3_WEB_R19_SANDBOX.zip --out /caminho/relatorio_novo.json`

Ou use `--quick` para passar apenas 16 regressões históricas e 16 novas sem os testes extensos de 64 sementes e 8 pares.

`python PORTABLE_VERIFY_BUNDLE.py /caminho/VLAB_R284_R287_WEB_HEAL_RECOVERY_MESTRE_ONLY.zip` confere ZIP CRC e os hashes dos membros.

## Próximo ponto

`LAST-VERIFIED R287 → FIRST-PENDING CANDIDATE R288` após checar colisão e novidades de Inbox. Prioridade real: aumentar repertório da UI usando efeitos legítimos (cura com custo/ação/alvo só após source gate), conectar multi-ator/scheduler A1 quando normativamente admissível ou provar mais robustez transacional, sem inflar os 17 contratos e 1.875 células. Antes de qualquer escrita Notion, comprovar instance/writer/lease/epoch/fencing/GREEN. Handoffs e regras no mesmo OP, sem motor paralelo.
