#!/usr/bin/env python3
"""Install on an isolated copy of original R19 and exercise historical/new HTTP tests.

Only an R19 local server TEST; never modifies origin, Notion, Party or O Primeiro.
Needs Python 3.10+, standard library and POSIX patch executable; localhost HTTP.
"""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path

BUNDLE=Path(__file__).resolve().parent
SOURCE_SHA='927e7fbee7fa25bac2bd4f84254552c9a7b2bf697c700cad10cab3170fdecfe9'
CORE_ORIG='f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368'
WEB_ORIG='fc4062348ff2841682631309d798dde646addfb81e5c7d81f63a7fb3fbc712cb'
CORE_FINAL='cc0527522e09f0a8b732adaf962f5ca3e018441b804cd9bf5fe32bcba0becc3d'
WEB_FINAL='f3b7810e9d5b4743f49aed92b0f4963fc50f439ffe16f4e062aeff49c088de8b'
AUDITOR_SHA='69431d341a7473a33718de9eccabccb65711c806c760402af393a2023d77a115'
PATCHES=[
 ('R269_CUMULATIVE_R18_TO_R269.patch','007b9fbb0764dd0805c5c09de77437681db0cf92679e64ef85e3257ed2ae9448'),
 ('R274_R283_INCREMENTAL_R269_TO_NEW.patch','62790395ef4bc02043bca383eccd9381fc9af6291f2bdc4adfb58c918d343d5f'),
 ('R284_R19_HEAL_WEB.patch','31d8ef565885f9c5b291786973a34557e006747874b1206e5315c19259c71644'),
 ('R285_R19_SOURCE_GATE_WEB.patch','1137ba045ce8e342a2b0b5a004de0ff911283d01dd327f972798a403c0ccfc8f'),
]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def cmd(args,cwd,env=None,timeout=180):
 p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
 if p.returncode!=0:raise RuntimeError('CMD FAIL: '+repr(args)+'\n'+p.stdout[-6000:])
 return p.stdout.strip()

def main():
 a=argparse.ArgumentParser();a.add_argument('--parent',type=Path,required=True);a.add_argument('--out',type=Path,default=None);a.add_argument('--quick',action='store_true');args=a.parse_args()
 if shutil.which('patch') is None:raise RuntimeError('POSIX patch tool missing')
 if not args.parent.exists() or sha(args.parent)!=SOURCE_SHA:raise RuntimeError('HISTORICAL R19 ZIP SHA MISMATCH OR ABSENT')
 assert sha(BUNDLE/'code/audit_r274_heal_independent.py')==AUDITOR_SHA
 for fn,pin in PATCHES:
  if sha(BUNDLE/'patch'/fn)!=pin:raise RuntimeError('PATCH SHA FAILURE '+fn)
 with tempfile.TemporaryDirectory(prefix='VLAB_R284_287_PORTABLE_') as base:
  root=Path(base)/'R19';root.mkdir()
  with zipfile.ZipFile(args.parent) as z:
   if z.testzip() is not None:raise RuntimeError('HISTORICAL ZIP CRC FAILURE')
   names=z.namelist()
   if len(names)!=2223:raise RuntimeError('ZIP COUNT MISMATCH')
   for n in names:
    if n.startswith('/') or '..' in Path(n).parts:raise RuntimeError('ZIP TRAVERSAL')
   z.extractall(root)
  native=root/'fusion_stage12'
  if sha(native/'vlab_r18_interactive.py')!=CORE_ORIG or sha(native/'vlab_r19_web.py')!=WEB_ORIG:
   raise RuntimeError('ORIGINAL MODULE HASH MISMATCH')
  for fn,pin in PATCHES:
   cmd(['patch','-p1','--batch','--forward','-i',str(BUNDLE/'patch'/fn)],root)
  shutil.copy2(BUNDLE/'code/audit_r274_heal_independent.py',native/'audit_r274_heal_independent.py')
  if sha(native/'vlab_r18_interactive.py')!=CORE_FINAL or sha(native/'vlab_r19_web.py')!=WEB_FINAL:
   raise RuntimeError('PATCHED MODULE HASH MISMATCH')
  logs=[]
  logs.append(cmd([sys.executable,'-m','unittest','-q','test_vlab_r18_interactive','test_vlab_r19_web'],native,timeout=100))
  for fn,cls in [('test_r284_web_heal.py','WebHeal'),('test_r285_source_gated_web.py','TestR285')]:
   shutil.copy2(BUNDLE/'tests'/fn,native/fn)
   logs.append(cmd([sys.executable,'-m','unittest','-q',Path(fn).stem+'.'+cls],native,timeout=100))
  if not args.quick:
   evidence=Path(base)/'evidence';evidence.mkdir()
   env=os.environ.copy();env['PYTHONPATH']=str(native);env['VLAB_EVIDENCE_DIR']=str(evidence)
   logs.append(cmd([sys.executable,str(BUNDLE/'tests/stress_r286_http_web.py')],native,env,timeout=100))
   logs.append(cmd([sys.executable,str(BUNDLE/'tests/prove_r287_backup_roundtrip_web.py')],native,env,timeout=100))
   stress=json.loads((evidence/'R286_SEEDED_HTTP_REPORT.json').read_text())
   roundtrip=json.loads((evidence/'R287_END_TO_END_HTTP_ROUNDTRIP.json').read_text())
   assert stress['distribution']=={'HEAL_PASS':64}
   assert roundtrip['paired_cases']==8
  else:stress=roundtrip='NOT_EXECUTED_QUICK'
  result={'state':'PASS_TEST_ONLY','source_r19_sha256':SOURCE_SHA,'patches':[x[0] for x in PATCHES],
     'core_sha256':CORE_FINAL,'web_sha256':WEB_FINAL,'native_old_tests':'16/16 PASS',
     'r284_new_tests':'8/8 PASS','r285_new_tests':'8/8 PASS',
     'r286_stress':stress if isinstance(stress,str) else {'total_seeds':stress['total_seeds'],'distribution':stress['distribution'],'healed_hp':stress['recorded_heal_hp']},
     'r287_complete':roundtrip if isinstance(roundtrip,str) else {'paired_cases':roundtrip['paired_cases'],'sqlite':roundtrip['distinct_end_to_end_sqlite'],'events':roundtrip['http_event_count_each_pair']},
     'original_modified':False,'canonical_write_count':0,'contract_acceptance':'0/17','R91':'0/1875',
     'logs':[x[-350:] for x in logs]}
  if args.out:
   args.out.parent.mkdir(parents=True,exist_ok=True)
   args.out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
  print(json.dumps({k:v for k,v in result.items() if k!='logs'},indent=2,ensure_ascii=False))
if __name__=='__main__':main()
