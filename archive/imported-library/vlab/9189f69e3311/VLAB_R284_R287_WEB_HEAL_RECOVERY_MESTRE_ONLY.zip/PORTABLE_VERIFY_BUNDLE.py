#!/usr/bin/env python3
"""Offline read-only verifier for the exact R284-R287 ZIP snapshot."""
import hashlib,json,sys,zipfile
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()

def verify(path):
    with zipfile.ZipFile(path) as z:
        bad=z.testzip()
        if bad is not None:raise RuntimeError('CRC mismatch:'+bad)
        members={i.filename for i in z.infolist() if not i.is_dir()}
        if any(n.startswith('/') or '..' in Path(n).parts for n in members):raise RuntimeError('UNSAFE ZIP PATH')
        idx=json.loads(z.read('FILE_MANIFEST_R284_R287.json'))
        expected=set(idx['files'].keys())|{'FILE_MANIFEST_R284_R287.json'}
        if members!=expected:raise RuntimeError('MEMBER_SET_MISMATCH '+repr((sorted(members-expected), sorted(expected-members))))
        for name,h in idx['files'].items():
            if sha(z.read(name))!=h:raise RuntimeError('MANIFEST_HASH_MISMATCH '+name)
        assert idx['lineage']['parent_zip_sha256']=='927e7fbee7fa25bac2bd4f84254552c9a7b2bf697c700cad10cab3170fdecfe9'
        report=json.loads(z.read('evidence/FINAL_COLD_EXECUTION_R284_R287.json'))
        if report['state']!='PASS_TEST_ONLY' or report['r287_complete']['paired_cases']!=8 or report['r286_stress']['distribution']!={'HEAL_PASS':64}:
            raise RuntimeError('EVIDENCE_NOT_PASS')
        return {'status':'PASS_BUNDLE_FILE_SHA_CRC','files':len(members),'manifest_files':len(idx['files']),'R286':64,'R287_pairs':8,'terminal_accepted':0}

if __name__=='__main__':
    print(json.dumps(verify(sys.argv[1]),ensure_ascii=False,indent=2))
