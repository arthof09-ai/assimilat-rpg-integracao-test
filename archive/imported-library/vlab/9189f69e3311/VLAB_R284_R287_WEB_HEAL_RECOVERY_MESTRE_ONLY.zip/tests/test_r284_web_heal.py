"""R284 HTTP functional healing through original R19 server, no duplicate motor."""
import json,sqlite3,urllib.parse,urllib.request,urllib.error,unittest
from test_vlab_r19_web import R19WebTests
import vlab_r18_interactive as core

class WebHeal(unittest.TestCase):
    setUp=R19WebTests.setUp
    start_server=R19WebTests.start_server
    stop_server=R19WebTests.stop_server
    get=R19WebTests.get
    def get_any(self,path):
        try:
            return self.get(path)
        except urllib.error.HTTPError as err:
            return err.code,err.read().decode('utf8'),err.geturl()
    post=R19WebTests.post
    csrf=R19WebTests.csrf
    create=R19WebTests.create
    step=R19WebTests.step
    def prepared(self,scene='A'):
        name,_=self.create(scene=scene,seed=284201 if scene=='A' else 284202)
        self.assertEqual(self.step(name,'START')[0],200)
        self.assertEqual(self.step(name,'ATTACK')[0],200)
        return name
    def test_01_heal_not_offered_at_full_hp(self):
        name,_=self.create('A',seed=284201)
        _,page,_=self.get('/combat?save='+name)
        self.assertNotIn('action" value="HEAL',page)
        self.assertEqual(self.step(name,'START')[0],200)
        _,page,_=self.get('/combat?save='+name)
        self.assertNotIn('action" value="HEAL',page)
    def test_02_heal_button_available_after_damage(self):
        name=self.prepared()
        _,page,_=self.get('/combat?save='+name)
        self.assertIn('Curar-se (1d6 LAB, 0 PA fictício)',page)
        self.assertIn('name="action" value="HEAL"',page)
    def test_03_actual_http_heal_one_native_v06_event(self):
        name=self.prepared()
        db=self.root/name;state,head,rev=core.load(db)
        who=state['active'];hp=state['actors'][who]['resource']['hp'];pa=state['actors'][who]['resource']['pa']
        result=self.step(name,'HEAL')
        self.assertEqual(result[0],200,result[1])
        st,_,rv=core.load(db)
        self.assertEqual(rv,rev+1)
        self.assertGreater(st['actors'][who]['resource']['hp'],hp)
        self.assertEqual(st['actors'][who]['resource']['pa'],pa)
        self.assertEqual(core.history(db)['events'][-1]['kind'],'HEAL')
        _,page,_=self.get('/history?save='+name)
        self.assertIn('Cura fictícia',page)
    def test_04_invalid_heal_before_attack_is_preflighted(self):
        name,_=self.create('A',seed=284205)
        self.assertEqual(self.step(name,'START')[0],200)
        st,head,rev=core.load(self.root/name)
        code,page,_=self.step(name,'HEAL')
        self.assertEqual(code,409)
        self.assertIn('HEAL_TARGET_NOT_INJURED_LIVING_ACTOR',page)
        self.assertEqual(core.load(self.root/name)[2],rev)
        con=sqlite3.connect(self.root/name)
        try:
            self.assertEqual(con.execute('SELECT COUNT(*) FROM pending').fetchone()[0],0)
        finally:
            con.close()
        code,html,_=self.step(name,'ATTACK')
        self.assertEqual(code,200,html)
    def test_05_stale_client_heal_refused(self):
        name=self.prepared()
        st,head,rev=core.load(self.root/name)
        self.assertEqual(self.step(name,'HEAL')[0],200)
        code,html,_=self.step(name,'HEAL',rev=rev,head=head)
        self.assertEqual(code,409)
        self.assertIn('ESTADO ALTERADO',html)
        self.assertEqual(core.load(self.root/name)[2],rev+1)
    def test_06_restart_recovers_heal_and_no_duplicate(self):
        name=self.prepared('B');self.assertEqual(self.step(name,'HEAL')[0],200)
        old=core.history(self.root/name)
        self.stop_server();self.start_server()
        page=self.get('/combat?save='+name)[1]
        self.assertIn('3 eventos',self.get('/')[1]);self.assertIn('Vida',page)
        after=core.history(self.root/name)
        self.assertEqual(after,old)
    def test_07_rehashed_fake_heal_is_refused_in_browser_history(self):
        name=self.prepared();self.assertEqual(self.step(name,'HEAL')[0],200)
        db=self.root/name
        con=sqlite3.connect(db)
        try:
            row=json.loads(con.execute('SELECT row_json FROM events WHERE seq=3').fetchone()[0]);row['detail']['hp_after']=999
            digest=core.sha(row)
            con.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=3',(core.canonical(row),digest))
            con.execute("UPDATE meta SET value=? WHERE key='head'",(digest,));con.commit()
        finally:con.close()
        self.assertEqual(core.load(db)[2],3)
        code,page,_=self.get_any('/history?save='+name)
        self.assertEqual(code,409)
        self.assertIn('HISTORY_SOURCE_AUDIT_HOLD',page)
        code,body,_=self.get_any('/receipt?save='+name)
        self.assertEqual(code,409)
    def test_08_csrf_failure_does_not_trigger_heal(self):
        name=self.prepared();db=self.root/name;st,head,rev=core.load(db)
        body=urllib.parse.urlencode({'csrf':'BAD','save':name,'action':'HEAL','rev':rev,'head':head}).encode()
        try:self.browser.open(urllib.request.Request(self.base+'/act',body,headers={'Content-Type':'application/x-www-form-urlencoded'}),timeout=10)
        except urllib.error.HTTPError as e:self.assertEqual(e.code,409)
        else:self.fail('CSRF not enforced')
        self.assertEqual(core.load(db)[2],rev)

if __name__=='__main__':unittest.main()
