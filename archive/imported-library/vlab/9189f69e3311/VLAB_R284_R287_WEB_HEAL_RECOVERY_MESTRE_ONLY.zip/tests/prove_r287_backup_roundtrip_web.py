#!/usr/bin/env python3
import os
"""R287 end-to-end HTTP healing+backup+restore+continuation on original R19, strictly synthetic."""
import json,urllib.parse,sys,time
from pathlib import Path
from test_vlab_r19_web import R19WebTests
import vlab_r18_interactive as core
from audit_r274_heal_independent import check

sample_seeds=[286000,286001,286002,286003,286004,286005,286006,286007]
t=R19WebTests('test_A_full_browser_combat_and_receipt');t.setUp()
rows=[]
try:
 for i,seed in enumerate(sample_seeds):
    scene='B' if i%2 else 'A'
    name,_=t.create(scene,seed)
    assert t.step(name,'START')[0]==200
    assert t.step(name,'ATTACK')[0]==200
    assert t.step(name,'HEAL')[0]==200
    # checkpoint via actual HTTP request, not a manual SQLite copy
    before=core.history(t.root/name)
    status,html,_=t.post('/backup',{'save':name})
    assert status==200,(seed,status,html[-600:])
    snaps=list((t.root/'copias').glob(Path(name).stem+'.backup_*.sqlite'))
    assert len(snaps)==1
    assert core.history(snaps[0])==before
    if i==0:
        t.stop_server();t.start_server() # restart localhost gateway with existing SQLite files
    status,html,url=t.post('/restore',{'save':name,'backup':snaps[0].name})
    assert status==200,(seed,status,html[-600:])
    restored=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)['save'][0]
    assert restored!=name
    rstart=core.history(t.root/restored)
    assert rstart['state']==before['state']
    assert [x['detail'] for x in rstart['events']]==[x['detail'] for x in before['events']]
    dataA=t.complete(name,defense=scene=='B')
    dataB=t.complete(restored,defense=scene=='B')
    assert dataA['state']==dataB['state'],f'seed {seed} state mismatch'
    assert [x['detail'] for x in dataA['events']]==[x['detail'] for x in dataB['events']],f'seed {seed} details mismatch'
    assert dataA['revision']==dataB['revision']
    assert dataA['state']['phase']=='COMPLETE_LAB'
    assert check(t.root/name)['heals']==check(t.root/restored)['heals']==1
    assert t.get('/receipt?save='+name)[0]==200
    assert t.get('/receipt?save='+restored)[0]==200
    row={'seed':seed,'scene':scene,'winner_lab':dataA['state']['winner'],'events_each':dataA['revision'],'heals_each':1,'status':'PASS'}
    rows.append(row)
finally:
 t.stop_server();t.tmp.cleanup()
assert len(rows)==len(sample_seeds)
result={'schema':'R287_HTTP_REAL_BACKUP_RESTORE','status':'PASS_TEST_ONLY','paired_cases':len(rows),'distinct_end_to_end_sqlite':2*len(rows),'http_event_count_each_pair':sum(2*r['events_each'] for r in rows),'rows':rows,'terminal_official':0,'R91_credit':0,'note':'Source A/B and healing 1d6 zero PA synthetic; HTTP server restart same Python process, not full distributed crash.'}
path=Path(os.environ.get('VLAB_EVIDENCE_DIR',str(Path(__file__).resolve().parents[1]/'evidence')))/'R287_END_TO_END_HTTP_ROUNDTRIP.json';path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2,ensure_ascii=False))
