#!/usr/bin/env python3
import os
"""Fixed-seed HTTP smoke on R19+R284/R285 TEST, no Party/data writes."""
import json,sys,time,sqlite3
from pathlib import Path
from test_vlab_r19_web import R19WebTests
import vlab_r18_interactive as core
from audit_r274_heal_independent import check

# Run one local HTTPServer instance with real SQLite files to exercise the browser gateway.
case=R19WebTests('test_A_full_browser_combat_and_receipt')
case.setUp()
started=time.monotonic()
results=[]
try:
 for i in range(64):
    seed=286000+i;scene='B' if i%2 else 'A'
    name,_=case.create(scene,seed)
    row={'seed':seed,'scene':scene,'name':name,'result':None}
    code,body,_=case.step(name,'START')
    if code!=200:
        row.update(result='START_HOLD',revision=core.load(case.root/name)[2],error=body.split('<div class="flash">')[-1][:100]);results.append(row);continue
    code,body,_=case.step(name,'ATTACK')
    if code!=200:
        row.update(result='ATTACK_HOLD',revision=core.load(case.root/name)[2]);results.append(row);continue
    state,hd,rev=core.load(case.root/name)
    who=state['active'];hp=state['actors'][who]['resource']['hp'];maxhp=state['actors'][who]['stats']['hp']
    if not 0<hp<maxhp:
        row.update(result='NO_HEAL_SOURCE_GATE',revision=rev);results.append(row);continue
    code,body,_=case.step(name,'HEAL')
    if code!=200:
        row.update(result='HEAL_HOLD',revision=core.load(case.root/name)[2]);results.append(row);continue
    receipt=core.history(case.root/name)
    assert check(case.root/name)['heals']==1
    assert receipt['revision']==3
    assert receipt['events'][-1]['kind']=='HEAL'
    assert receipt['state']['actors'][who]['resource']['hp']>hp
    assert receipt['state']['actors'][who]['resource']['pa']==30
    page=case.get('/history?save='+name)[1]
    assert 'Cura fictícia' in page
    row.update(result='HEAL_PASS',revision=3,heal_hp=receipt['state']['actors'][who]['resource']['hp']-hp)
    results.append(row)
finally:
 case.stop_server();case.tmp.cleanup()
count={key:sum(r['result']==key for r in results) for key in set(r['result'] for r in results)}
assert len(results)==64
assert count.get('HEAL_PASS',0)>=40, count
out={'test':'R286_64_SEEDED_HTTP_CASES','status':'PASS_DOMAIN_LAB_ONLY','total_seeds':64,'distribution':count,'recorded_heal_hp':sum(r.get('heal_hp',0) for r in results),'elapsed_seconds':round(time.monotonic()-started,3),'rows':results,'official_credits':0}
path=Path(os.environ.get('VLAB_EVIDENCE_DIR',str(Path(__file__).resolve().parents[1]/'evidence')))/'R286_SEEDED_HTTP_REPORT.json';path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2,ensure_ascii=False))
