"""R285 real HTTP source-gated read/write paths; no alternative combat resolver."""
import json,sqlite3,urllib.error,urllib.parse,unittest
from test_vlab_r19_web import R19WebTests
import vlab_r18_interactive as core

class TestR285(unittest.TestCase):
    setUp=R19WebTests.setUp
    start_server=R19WebTests.start_server
    stop_server=R19WebTests.stop_server
    get=R19WebTests.get
    post=R19WebTests.post
    csrf=R19WebTests.csrf
    create=R19WebTests.create
    step=R19WebTests.step
    def http_get(self,path):
        try:return self.get(path)
        except urllib.error.HTTPError as e:return e.code,e.read().decode('utf-8'),e.geturl()
    def prep(self,seed=284201):
        name,_=self.create('A',seed=seed)
        self.assertEqual(self.step(name,'START')[0],200)
        self.assertEqual(self.step(name,'ATTACK')[0],200)
        self.assertEqual(self.step(name,'HEAL')[0],200)
        return name
    def adulterate(self,path):
        con=sqlite3.connect(path)
        try:
            row=json.loads(con.execute('SELECT row_json FROM events WHERE seq=3').fetchone()[0])
            row['detail']['v06_receipt']['healed']=9999
            digest=core.sha(row)
            con.execute('UPDATE events SET row_json=?,row_sha=? WHERE seq=3',(core.canonical(row),digest))
            con.execute("UPDATE meta SET value=? WHERE key='head'",(digest,))
            con.commit()
        finally:con.close()
        self.assertEqual(core.load(path)[2],3) # Generic chain alone still passes.
    def test_01_index_refuses_to_display_untrusted_winner(self):
        name=self.prep();self.adulterate(self.root/name)
        code,html,_=self.http_get('/')
        self.assertEqual(code,200)
        self.assertIn('Salvamento bloqueado ou inválido',html)
        self.assertNotIn('Abrir combate',html)
    def test_02_attack_after_rehashed_fake_heal_no_new_intent(self):
        name=self.prep();self.adulterate(self.root/name)
        old=core.load(self.root/name)
        code,html,_=self.step(name,'ATTACK')
        self.assertEqual(code,409)
        self.assertIn('HISTORY_SOURCE_AUDIT_HOLD',html)
        self.assertEqual(core.load(self.root/name),old)
        con=sqlite3.connect(self.root/name)
        try:self.assertEqual(con.execute('SELECT COUNT(*) FROM pending').fetchone()[0],0)
        finally:con.close()
    def test_03_backup_from_forged_chain_rejected_without_file(self):
        name=self.prep();self.adulterate(self.root/name)
        code,html,_=self.post('/backup',{'save':name})
        self.assertEqual(code,409)
        self.assertIn('HISTORY_SOURCE_AUDIT_HOLD',html)
        self.assertFalse(list((self.root/'copias').glob('*.sqlite')))
    def test_04_restart_from_forged_chain_rejected_without_new_db(self):
        name=self.prep();self.adulterate(self.root/name)
        code,html,_=self.post('/restart',{'save':name})
        self.assertEqual(code,409)
        self.assertIn('HISTORY_SOURCE_AUDIT_HOLD',html)
        self.assertEqual(len(list(self.root.glob('*.sqlite'))),1)
    def test_05_restore_from_corrupted_backup_refused_without_new_db(self):
        name=self.prep()
        code,html,_=self.post('/backup',{'save':name})
        self.assertEqual(code,200,html)
        backup=list((self.root/'copias').glob('*.sqlite'))[0]
        self.adulterate(backup)
        code,html,_=self.post('/restore',{'save':name,'backup':backup.name})
        self.assertEqual(code,409)
        self.assertIn('HISTORY_SOURCE_AUDIT_HOLD',html)
        self.assertEqual(len(list(self.root.glob('*.sqlite'))),1)
    def test_06_valid_backup_restore_and_restart_preserve_origin(self):
        name=self.prep()
        code,_,_=self.post('/backup',{'save':name})
        self.assertEqual(code,200)
        backup=list((self.root/'copias').glob('*.sqlite'))[0]
        self.assertEqual(core.history(backup)['revision'],3)
        code,html,url=self.post('/restore',{'save':name,'backup':backup.name})
        self.assertEqual(code,200,html)
        restored=urllib.parse.parse_qs(urllib.parse.urlparse(url).query)['save'][0]
        self.assertEqual(core.history(self.root/restored)['state'],core.history(self.root/name)['state'])
        code,html,url=self.post('/restart',{'save':name})
        self.assertEqual(code,200,html)
        new=urllib.parse.parse_qs(urllib.parse.urlparse(url).query)['save'][0]
        self.assertEqual(core.history(self.root/new)['revision'],0)
        self.assertEqual(len(list(self.root.glob('*.sqlite'))),3)
    def test_07_direct_web_combat_page_rejects_forged_event(self):
        name=self.prep();self.adulterate(self.root/name)
        code,html,_=self.http_get('/combat?save='+name)
        self.assertEqual(code,409)
        self.assertIn('HISTORY_SOURCE_AUDIT_HOLD',html)
    def test_08_new_clean_save_keeps_normal_attack_after_failed_inbox_list(self):
        name=self.prep();self.adulterate(self.root/name)
        self.assertEqual(self.http_get('/')[0],200)
        clean,_=self.create('A',seed=284202)
        self.assertEqual(self.step(clean,'START')[0],200)
        self.assertEqual(self.step(clean,'ATTACK')[0],200)
        self.assertEqual(core.history(self.root/clean)['revision'],2)

if __name__=='__main__':unittest.main()
