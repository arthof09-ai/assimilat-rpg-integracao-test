# R39 — Delta experimental preservacional (Mestre-side)

Este pacote NÃO substitui os motores R18, R26, v0.8.1 nem ZIPs R27–R38. Não contém dados Party ou alterações canônicas.

## Verificação autônoma sem motor

1. Extraia o ZIP novo em pasta isolada.
2. Execute `python verify_r39_standalone.py` nessa pasta com Python 3.11+; ele usa apenas stdlib.
3. Conferir `R39_STANDALONE_AUDIT.json`, `R39_DIRECTED_RESULT.json`, 4 novos bancos SQLite e 3 backups.
4. Não execute `r39_directed_gates.py` contra os bancos já existentes: ele é *roteiro técnico de reprodução a partir de genesis* para um novo diretório limpo, não mecanismo de retentativa.

## Reexecução somente de novos testes, quando legitimamente autorizada

`r39_directed_gates.py` depende do núcleo histórico nos pacotes imutáveis R27 e R36, que são referências na Biblioteca da **mesma OP**. O runtime local de R39 foi montado copiando o arquivo R36 `run_r36_dodge.py`, o arquivo R36 `run_r35_native.py`, a extensão `vlab_r31_real_source_gateway.py` de R34, o código Stage12/fusion histórico R27, módulos `comestre_vlab` originais v0.8.1 e os envelopes `authority` de R36. Todos copiados byte-identical; **não faça `pip install` de um motor novo**, não reexecute combates originais nem pretenda que esta nova camada promova a v0.9. Reproduza num diretório novo com paths adaptados para esse diretório, nunca num local contendo os bancos R39 originais.

## Pontos de atenção

- Banco `R39_REACTION_FAILURE_AFTER_PREVALIDATION.sqlite` deve ficar *pendente* com revision0, pending1, sem evento. Isso é um failpoint intencional, não erro de backup a limpar automaticamente.
- `SCHEDULER_TIED`/`UNTIED` são **fixtures de três instâncias derivadas da Cabra**, não novas lutas integrais.
- Holdout pré-registrado independe das seeds dos testes; sem autenticação de dado canônico.
- Arquivos produzidos antes de qualquer operação Notion/Library: `R39_*`. Fonte governante Notion da OP: `3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2`.
