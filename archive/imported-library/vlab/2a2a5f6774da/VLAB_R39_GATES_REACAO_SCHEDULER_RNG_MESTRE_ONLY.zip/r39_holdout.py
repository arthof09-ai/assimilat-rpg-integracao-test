"""Independent statistical holdout for original R18 deterministic experimental RNG.
Protocol is immutable and read before generation. No motor combat or historical fights are run.
"""
import json,hashlib,subprocess,sys,math,random
from pathlib import Path
from collections import Counter
ROOT=Path('/mnt/data/vlab_r39')
PROTO=ROOT/'delivery/R39_HOLDOUT_PROTOCOL_PREREGISTERED.json'
DATA=ROOT/'delivery/R39_HOLDOUT_RESULTS.json'
pre=json.loads(PROTO.read_text())
if DATA.exists():raise RuntimeError('CANNOT_RERUN_OR_OVERWRITE_HOLDOUT')
assert pre['status']=='FROZEN_BEFORE_SAMPLING' and pre['holdout_seeds']['count']==100
import importlib.util
p=ROOT/'work/runtime_copy/r27/fusion_stage12/vlab_r18_interactive.py'
# vlab import resolution relies on original module installation.
sys.path.insert(0,str(p.parent));sys.path.insert(0,str(ROOT/'work/runtime_copy/r27/working/historical_v081_verified_original/comestre_vlab'))
import vlab_r18_interactive as r18
seeds=range(pre['holdout_seeds']['start_inclusive'],pre['holdout_seeds']['stop_exclusive'])
rolls=[];seed_hash=[]
for seed in seeds:
 v=r18.dice(seed,0,'R39_PREDECLARED_HOLDOUT',6,6)
 if len(v)!=6 or not all(type(k)==int and 1<=k<=6 for k in v):raise RuntimeError('INVALID_DICE')
 rolls.extend(v);seed_hash.append({'seed':seed,'draws_sha256':hashlib.sha256(json.dumps(v,separators=(',',':')).encode()).hexdigest()})
counts={str(i):rolls.count(i) for i in range(1,7)}
expect=len(rolls)/6
chisq=sum((counts[str(i)]-expect)**2/expect for i in range(1,7))
reject=chisq>pre['primary_test']['reject_if_chi_square_greater']
from scipy.stats import chi2
pvalue=float(chi2.sf(chisq,5))
# independent standard-library reconstruction of the SHA256+MT pseudorandom algorithm
reference=[]
for seed in seeds:
 digest=hashlib.sha256(f'{seed}|0|R39_PREDECLARED_HOLDOUT|6d6|{r18.VERSION}'.encode()).digest()
 rng=random.Random(int.from_bytes(digest,'big'))
 reference.extend(rng.randint(1,6) for _ in range(6))
if reference!=rolls:raise RuntimeError('SHA256_RANDOM_REFERENCE_DIFF')
# Cross-process checks fixed before holdout in protocol
sample=[24001,24009,24037,24073,24099]
code="import sys,json;sys.path.insert(0,%r);sys.path.insert(0,%r);import vlab_r18_interactive as j;print(json.dumps([j.dice(x,0,'R39_PREDECLARED_HOLDOUT',6,6) for x in %r]))"%(str(p.parent),str(ROOT/'work/runtime_copy/r27/working/historical_v081_verified_original/comestre_vlab'),sample)
res=subprocess.check_output([sys.executable,'-c',code],text=True).strip()
readback=json.loads(res)
if readback!=[rolls[(s-24001)*6:(s-24001)*6+6] for s in sample]:raise RuntimeError('CROSS_PROCESS_REPLAY_FAIL')
# Wilson interval for number of 4/5/6 results among N draws, descriptively.
n=len(rolls);k=sum(v>=4 for v in rolls);z=1.959963984540054;phat=k/n;denom=1+z*z/n
center=(phat+z*z/(2*n))/denom
half=z*math.sqrt(phat*(1-phat)/n+z*z/(4*n*n))/denom
out={'schema':'R39_STAT_HOLDOUT_RESULT_V1','protocol_sha256':hashlib.sha256(PROTO.read_bytes()).hexdigest(),'fixed_seed_count':100,'roll_count':n,'counts':counts,'chi_square':chisq,'df':5,'p_value_chi_square':pvalue,'alpha_pre_registered':0.01,'primary_rejected':reject,'primary_result':'PASS_NOT_REJECTED_AS_GROSSLY_NONUNIFORM' if not reject else 'FAIL_REJECTED_NONUNIFORM','secondary_high_rolls_4_to_6':k,'secondary_rate':phat,'wilson_95CI':[center-half,center+half],'all_rolls_sha256':hashlib.sha256(json.dumps(rolls,separators=(',',':')).encode()).hexdigest(),'seed_digest_index':seed_hash,'source':'VLAB_R18_EXPERIMENTAL_DETERMINISTIC_RANDOM_RANDOM_SHA256_SEEDED','five_independent_subprocess_replays':True,'independent_formula_reconstruction_all_600':True,'fresh_holdout_seeds_disjoint_from_dev':True,'no_combat_runs':True,'official_dice_source_authenticated':False,'campaign_credits':0}
with DATA.open('x',encoding='utf8') as f:json.dump(out,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('seed_digest_index',)},ensure_ascii=False,indent=2))
