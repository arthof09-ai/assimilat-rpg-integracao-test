# PSV — R39 | Novos gates de Reações, scheduler de 3 atores e holdout RNG

**CM-000006 · OP-VLAB-FUSION-SANDBOX-01 · MESTRE-SIDE · 15/10/2026**  
**Status:** PROVAS FUNCIONAIS NOVAS VERIFICADAS; ACEITAÇÃO TÉCNICA INTEGRAL = NÃO COMPROVADA; CERTIFICAÇÃO TERMINAL = HOLD.

## 1. ANTES → AUTORIDADE → DEPOIS

**ANTES R38:** 16 combates reais-fonte **somente em sandbox** concluídos, 2 observações censuradas, 5 sondas isoladas; 23 cenas R34–R37 auditadas; 184 eventos históricos verificados, 40 Reações ESQUIVAR históricas; 3 contratos com provas parciais; 0/17 terminal; 0/1.875 células canônicas. Histórico R01–R38 imutável; R29 seed53 e UNKNOWN_EFFECT pré-existentes preservados.

**Autoridade normativa consultada:** Sistema de Combate Notion `3ebc2b32-4ede-81f1-be4b-e8804ac113c0` (gasto de 1 Reação por janela, reação declarada antes de ataque; Esquivar=CA+Reflexo; Defender=6+CON+Armadura+Fortitude; empate da defesa vence); decisões explícitas do Mestre no OP Notion `3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2` (Esquiva Cabra B1 CA20+Reflexo6=26; decisão iniciativa R26: maior DES em empate, dados só entre persistentes empatados; Reação renova ao começar o próprio turno); ficha de Cabra B1 `391c2b32-4ede-8252-b0cc-810423cdbfa6`. `NAC-CONT-03`, `NAC-NORM-01`, `NAC-PASS-02` e `NORM-FUSION-ABSORB-01` respeitados: não promover teste sintético a campanha, nem implementar prioridade normativa ausente.

**DEPOIS R39:** 4 novas cenas de engenharia experimental (3 com eventos e 1 com intenção congelada); 19 eventos R18 publicados, 3 checkpoints íntegros e replay causal integral das 3 cenas; uma falha `UNKNOWN_EFFECT` injetada/frozen em cópia experimental, sem publicação parcial. **0 combates completos novos**; 16 históricos permanecem. **3/3 contratos prioridades tiveram bateria nova, 0/3 aceitação técnica integral e 0/17 certificação terminal.** Nenhuma alteração produtiva ou canônica.

## 2. Contrato `REACTION_TRIGGER_AND_SINGLE_USE`

### Prova nova positiva (R39_REACTION_SEQUENTIAL)

Dois atacantes diferentes A e C usam a Investida autorizada da mesma espécie Cabra B1, contra B, sem renovar o slot de B entre os dois disparos. Fonte do motor v0.8.1, perfil de Reação e envelope de autoridade R36 referenciados dos pacotes históricos. Três transações R18, cada qual com recibo, `after_sha` e comando único:

1. A declara ataque score24 > CA20. B anuncia **Esquivar** válida, defesa26: `react_defensively` consome slot1→0 e `apply_weapon_attack` registra **0 dano**, B HP38. Ambos os eventos nativos são publicados **atomicamente** em uma transação R18.
2. C oferece segundo ataque score24 antes de renovação. Segunda tentativa Esquivar retorna **`reaction not available`** sem mutar estado nem eventos nativos. A ação do segundo atacante segue legalmente e `apply_weapon_attack` aplica bruto20−RD5=**15**, B HP38→23. O segundo atacante gasta sua própria Ação Padrão; a de A não é reutilizada.
3. Avanço R18 até **início do turno próprio de B**, seguido de renovação R26: Reação0→1, nunca 2. O checkpoint e o replay dos três eventos reproduzem mesmo `head`, HP e slots.

### Negativas e falha controlada

- Três pré-gates independentes sobre cópia: declaração **após** ataque, gatilho incorreto e prova de autoridade **ausente**: **3/3 rejeições sem efeito**.
- Dois gatilhos simultâneos de A e C contra B: **BLOCKED-NORMATIVE/PRE-INTENT**. Não foi inventada prioridade. Protocolo de Contra-ataque aninhado com Esquivar: **BLOCKED-NORMATIVE/PRE-INTENT**. Os testes provam *rejeição segura*, **não** resolução funcional da concorrência/nesting.
- Reutilização de `cmd_id`: rejeição duplicada sem alterar revisão/head.
- Falha depois da validação e da execução nativa **sobre um clone**, mas antes do COMMIT SQLite: intenção durável **1**, eventos confirmados **0**, revisão **0**, HP/PA/Reação não alterados no registro, `PRAGMA integrity_check=ok`. Reabertura pela API R18 **HOLD por UNKNOWN_EFFECT**. Este banco é congelado e **não** pode receber retry automático; ele é uma prova experimental, não a seed53 histórica.
- Igualdade Esquivar/Defender favorável à defesa comprovada anteriormente em R37, não repetida sem hipótese nova. `Defender` não foi aplicado à Cabra sem Fortitude/Armadura legítimas.

**Camadas:** A PASS limitado ao uso sequencial; B PASS positivo/negativo/falha; C PARTIAL — precedência de múltiplos gatilhos/Contra-atacar aninhado permanece indeterminada; D HOLD (revisor externo/NAC-PASS aplicável). **CRÉDITO: TÉCNICO PARCIAL, NÃO TERMINAL.**

## 3. Contrato `TURN_SCHEDULER_EVENT_SOURCING`

Dois **novos cenários sintéticos com 3 instâncias independentes da mesma ficha B1** (`SCHEDULER_UNTIED` e `SCHEDULER_TIED`) exercitaram **o próprio R26 `resolve_initial_state/tie_order`** e a passagem de turno existente **R18 `_next_turn`**. Instâncias são *fixtures source-derived*: **não são 3 combatentes fonte-completa legalmente admitidos para combate**; só provam organização de turnos, replay e renovação de slots. Cada cena publica 8 eventos com cadeia, 6+ turnos/atos de gestão, início de turno e uma eliminação **sintética explicitamente marcada**, sem dano/ficha canônica. Replays independentes evento a evento e checkpoint lógicos **PASS**.

### Defeito histórico descoberto e correção aditiva

O `_next_turn` do histórico R18 dá o próximo índice da ordem **sem verificar Vida**. Com A, B, C e C marcado com 0 HP por fixture sintética, o R18 seleciona C como próximo ator; isso é uma lacuna **reproduzida** de cenas multiator, não um efeito da campanha. **Correção implementada APENAS no adaptador experimental R39 `next_alive()`**: chamar R18 `_next_turn` em cópia até alcançar ator vivo, registrando `skipped_ko`, consumindo exatamente o avanço necessário e aplicando `refresh_own_turn` somente ao ator que recebeu o turno. Nenhum módulo R18/R26 original foi editado. **Regressões 2/2 cenários PASS; antigo defeito permanece no núcleo R18 para cenários onde a camada experimental não está ativa.** Não há autorização para incorporar essa mudança ao motor oficial antes da revisão normativa e de regressão de áreas maiores.

**Camadas:** A/B PASS restritos a scheduler com 3 fixtures, inclusive desempate e KO; C PARTIAL (ordem de iniciativa autorizada; sem autoridade generalizada para todos os modos de interrupção/eliminação); D HOLD. **CRÉDITO: TÉCNICO PARCIAL, NÃO TERMINAL.**

## 4. Contrato `RNG_REPLAY_STATISTICS`

**Pré-registro físico, congelado antes de gerar resultados:** `R39_HOLDOUT_PROTOCOL_PREREGISTERED.json`, SHA256 `8fb531fe7f4d1d2953e06541976e6aef8ef2dc097405b6b446d2a8a8e56bd5ab`; sementes 24001 a 24100, **100 sementes** × 6 dados = **600 lançamentos**. Nenhuma semente pertence aos lotes de desenvolvimento R34–R37 ou aos cenários técnicos R39. Teste **pré-especificado** χ² para 6 faces equiprováveis, nível 1%, corte χ²=15,08627 com 5 graus de liberdade.

**Contagens:** face1 106; face2 101; face3 116; face4 100; face5 92; face6 85. χ²=**5,82**, p=**0,324129624**, portanto **NÃO REJEITAR** distribuição uniforme nesse teste; isso **NÃO É prova de uniformidade/independência universal**. Em 600 lançamentos, 277 foram 4–6 (46,17%); intervalo de Wilson 95% [42,21%,50,17%]. Toda a fita de 600 dados foi reproduzida por referência separada SHA256+`random.Random`, com 5 seeds conferidas em novo processo, e novamente por **verificador stdlib independente, sem importar o motor**. Não houve reamostragem seletiva, censura ou combate nesta prova.

**Origem física do gerador:** `vlab_r18_interactive.dice` experimental = SHA256 de `seed|seq|label|NdFaces|version`, convertida em seed inteira para Python `random.Random` (Mersenne Twister). Garante determinismo observável; **não é verificação de RNG canônico da campanha**, não é criptograficamente seguro por inferência e não prova correção de todas as distribuições de ataque/dano/magia.

**Camadas:** A PASS fonte experimental determinística; B PASS restrito ao holdout e replay; C BLOCKED para origem de dados oficiais e mecânicas por fonte; D HOLD. **CRÉDITO: TÉCNICO PARCIAL, NÃO TERMINAL.**

## 5. Aceitação dos três contratos segundo matriz ORIGINAL R18

| Contrato | Requisito literal R18 ainda em aberto | A | B | C | D | Crédito |
|---|---|---|---|---|---|---|
| `REACTION_TRIGGER_AND_SINGLE_USE` | `MULTI_TRIGGER_INTERRUPTS_AND_NORMATIVE_PRECEDENCE` | PASS parcial | PASS casos | PARTIAL | HOLD | Técnico parcial |
| `TURN_SCHEDULER_EVENT_SOURCING` | `CANON_INITIATIVE_TIE_INTERRUPTION_AND_SOURCE_COMPLETE_EVENTS` | PASS parcial | PASS fixtures | PARTIAL | HOLD | Técnico parcial |
| `RNG_REPLAY_STATISTICS` | `CANONICAL_DICE_SOURCE_AND_STATISTICAL_HOLDOUT` | PASS experimental | PASS holdout | BLOCKED canônico | HOLD | Técnico parcial |

**Próxima condição que realmente altera um contrato:** (1) detectar autoridade existente ou solicitar decisão mínima do Mestre **somente** para concorrência/contra-ataque aninhado se continuar sem norma; provar resolução e não apenas rejeição. (2) promover corrigido `next_alive` à camada experimental principal após testes com ação/reação de 3 atores legais e verificar ordem causal de dano/eliminação. (3) identificar a fonte oficial de rolagens e congelar distribuições discriminantes de regras antes de novo holdout. Essas frentes são independentes do writer produtivo, mas a certificação terminal requer gate competente.

## 6. Arquitetura, auditoria e preservação

`r39_directed_gates.py` é camada de ensaio **aditiva**, chama originais `v0.8.1.react_defensively`, `v0.8.1.apply_weapon_attack`, R18 `event_commit` / `_next_turn` e R26 `resolve_initial_state` / `refresh_own_turn`. Sem motor paralelo. Os artefatos são: três SQLite event-sourced completos (3+8+8 = **19 eventos**), três backups SQLite, um SQLite com intenção durável sem commit (0 eventos), recibos de provas, protocolo e resultados do holdout, matriz A/B/C/D e auditoria. 

`verify_r39_standalone.py` **não importa o núcleo e não reexecuta os ataques**. Em leitura, verificou: integridade dos quatro SQLite, 3 checkpoints lógicos, hash por linha e por corrente, 19 eventos, dano/slot/renovação, ordem de iniciativa com e sem empate, reprodução do bug de KO com mitigação aditiva, intenção pendente intocada, 600 rolagens por reconstrução independente e matriz intacta. **PASS.**

**Preservação:** verificações feitas exclusivamente em novos arquivos R39 e código importado a partir de cópias dos pacotes R27/R36. Não houve gravação em R01–R38, SQLite anterior, Party, O Primeiro, fichas ou campanha. IBX-56 BLOCKED-EXTERNAL; writer, lease, epoch, fencing, GREEN, NAC-PASS produtivo: HOLD. `NORM-FUSION-ABSORB-01` e gate arquitetural/operacional da fusão não foram reivindicados.

**Contadores finais:** 17/17 objetos da matriz original preservados; **0/17 certificados**; 16 combates sandbox históricos, **0 novos**; 2 censurados e 5 sondas históricas, sem alterações; 0 combates canônicos; 0/1.875 células; 2/25 patamares Bronze1/Bronze5 com luta sandbox. **Progresso global percentual não determinável** sem pesos e gates definidos.

## 7. Checkpoint R39

Última unidade verificada: três ledgers R39 e seus checkpoints (19 eventos), ledger de falha congelado com 1 pending e 0 commits, holdout600 e matriz3 A/B/C/D. Primeiro pendente: precedência normativa concorrente/aninhada no contrato Reações; revisão e adaptação source-complete do scheduler três atores; prova de dados canônicos no contrato RNG. **Nunca retry do banco com pending** nem refaça as 16 lutas históricas.
