#!/usr/bin/env python3
"""R39 external stdlib auditor: independently examines SQLite mechanics, ledger integrity,
checkpoint equivalence, held intent and statistical holdout. Never imports or reruns the motor.
"""
from __future__ import annotations
import json,hashlib,sqlite3,math,random,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
canon=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
sha=lambda x:hashlib.sha256(canon(x).encode('utf-8')).hexdigest()
fsha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda x:json.loads((BASE/x).read_text(encoding='utf-8'))

def inspect(db,pending_expected=False):
 with sqlite3.connect(f'file:{db}?mode=ro',uri=True) as c:
  if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise AssertionError('SQLITE_INTEGRITY_FAIL')
  meta=dict(c.execute('SELECT key,value FROM meta'))
  rows=c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
  pending=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
 state=json.loads(meta['state']);rev=int(meta['revision']);prev=meta['genesis'];last=None
 if rev!=len(rows):raise AssertionError('REV_NOT_EVENT_COUNT')
 for ix,cmd_id,old,rowjson,rowhash,bs,ass in rows:
  row=json.loads(rowjson)
  assert ix==row['seq'] and rowhash==sha(row) and cmd_id==row['cmd_id']
  assert old==prev==row['prev'] and bs==row['before_sha'] and ass==row['after_sha']
  assert row['official_effects']==0 and row['synthetic'] is True
  if last is not None:assert bs==last
  last=ass;prev=rowhash
 assert prev==meta['head'] and (last is None or last==sha(state))
 assert all(a['source_page_id']=='391c2b32-4ede-8252-b0cc-810423cdbfa6' for a in state['actors'].values())
 assert state['r39']['no_canonical_effects'] is True
 assert pending==(1 if pending_expected else 0)
 return {'head':meta['head'],'revision':rev,'pending':pending,'state':state,'rows':[json.loads(r[3]) for r in rows],'event_sha':sha([json.loads(r[3]) for r in rows])}

def holdout():
 protocol=read('R39_HOLDOUT_PROTOCOL_PREREGISTERED.json');out=read('R39_HOLDOUT_RESULTS.json')
 assert out['protocol_sha256']==fsha(BASE/'R39_HOLDOUT_PROTOCOL_PREREGISTERED.json')
 assert protocol['status']=='FROZEN_BEFORE_SAMPLING'
 start=protocol['holdout_seeds']['start_inclusive'];stop=protocol['holdout_seeds']['stop_exclusive'];assert (start,stop)==(24001,24101)
 # Independent reimplementation of the documented SHA256+Python MT experimental RNG, no historical library imported.
 dice=[]
 for seed in range(start,stop):
  seed_bytes=hashlib.sha256(f'{seed}|0|R39_PREDECLARED_HOLDOUT|6d6|VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'.encode()).digest()
  g=random.Random(int.from_bytes(seed_bytes,'big'));dice.extend(g.randint(1,6) for _ in range(6))
 assert len(dice)==600
 counts={str(i):dice.count(i) for i in range(1,7)}
 assert counts==out['counts'] and sum(counts.values())==600
 chi=sum((counts[str(i)]-100)**2/100 for i in range(1,7));assert abs(chi-out['chi_square'])<1e-9
 z=chi/2
 # Chi-squared df=5, gamma Q(5/2, chi/2) closed form
 p=math.erfc(math.sqrt(z))+(2/math.sqrt(math.pi))*math.sqrt(z)*math.exp(-z)*(1+2*z/3)
 assert abs(p-out['p_value_chi_square'])<1e-10
 assert (chi>protocol['primary_test']['reject_if_chi_square_greater'])==out['primary_rejected']
 assert hashlib.sha256(json.dumps(dice,separators=(',',':')).encode()).hexdigest()==out['all_rolls_sha256']
 assert out['official_dice_source_authenticated'] is False
 return {'uniformity_chi2':chi,'p':p,'n':len(dice),'alpha':0.01,'reproducible':True,'canonical_source':False}

def audit():
 results=read('evidence/R39_DIRECTED_RESULT.json');matrix=read('R39_MATRIX_3_ACCEPTANCE.json')
 assert matrix['denominator_preserved']==17 and len(matrix['cases'])==3 and matrix['terminal_certified_count']==0
 expected={
 'R39_REACTION_SEQUENTIAL':3,
 'R39_SCHEDULER_UNTIED':8,
 'R39_SCHEDULER_TIED':8,
 'R39_REACTION_FAILURE_AFTER_PREVALIDATION':0,
 }
 ledger={}
 for name,events in expected.items():
  source=BASE/'ledgers'/f'{name}.sqlite';s=inspect(source,pending_expected='FAILURE' in name)
  assert s['revision']==events
  ledger[name]=s
  if events:
   chk=BASE/'checkpoints'/f'{name}_backup.sqlite';other=inspect(chk)
   assert s['head']==other['head'] and s['revision']==other['revision'] and s['state']==other['state'] and s['event_sha']==other['event_sha']
 # Independently verify mechanics of sequential attacks and slot state.
 a=ledger['R39_REACTION_SEQUENTIAL'];rows=a['rows'];assert [r['kind'] for r in rows]==['REACTION_FIRST','REACTION_SECOND','REACTION_REFRESH']
 first=rows[0]['detail']['native_events'];assert len(first)==2 and first[0]['action']=='ESQUIVAR' and first[1]['action']=='weapon_attack'
 assert first[0]['defense_exact']=='26' and first[0]['damage_negated'] is True and first[0]['consumes_reaction'] is True
 assert first[1]['net']==0 and first[1]['after_hp']==38 and first[1]['defense_negated'] is True
 second=rows[1]['detail'];assert second['reason']=='reaction not available'
 assert len(second['native_events'])==1 and second['native_events'][0]['action']=='weapon_attack'
 assert second['native_events'][0]['net']==15 and second['native_events'][0]['after_hp']==23
 third=rows[2]['detail'];assert third['refresh_R26']['before']==0 and third['refresh_R26']['after']==1
 assert a['state']['actors']['LAB_R39_GOAT_B']['resource']['reaction']==1
 failure=ledger['R39_REACTION_FAILURE_AFTER_PREVALIDATION'];assert failure['pending']==1 and failure['state']['actors']['LAB_R39_GOAT_B']['resource']['hp']==38
 assert failure['state']['actors']['LAB_R39_GOAT_B']['resource']['reaction']==1
 r=read('evidence/R39_REACTION_NEW_CASES.json')
 assert len(r['negative'])==3 and all(x['status']=='PASS_REJECTED_BEFORE_MUTATION' for x in r['negative'])
 assert r['concurrent']['status']=='BLOCKED_NORMATIVE_PRE_INTENT' and r['nested']['status']=='BLOCKED_NORMATIVE_PRE_INTENT'
 assert r['idempotency']=='PASS_DUPLICATE_REJECTED'
 for mode in ('TIED','UNTIED'):
  s=ledger[f'R39_SCHEDULER_{mode}'];events=s['rows'];init=events[0]['detail']['initiative_native_R26'];order=init['order']
  assert len(order)==3 and set(order)==set(s['state']['actors'])
  assert bool(init['tie_resolution']['rerolls']) == (mode=='TIED')
  assert all(row['detail']['canonical_credit']==0 for row in events if row['kind']!='INIT_3_ACTORS')
  skip=events[-1]['detail'];assert skip['legacy_failure_reproduced'] is True and skip['ko_actor']==skip['legacy_next']
  assert skip['experimental_additive_fix']['next']!=skip['ko_actor']
  assert skip['ko_actor'] in skip['experimental_additive_fix']['skipped_ko']
 stat=holdout()
 return {'status':'PASS_INDEPENDENT_STDLIB','sqlite_new_fresh_ledger':4,'checkpoints_new':3,'events_published':sum(x['revision'] for x in ledger.values()),'pending_frozen_fault':1,'independent_mechanics_checked':['native_defense_26','single_slot_reaction','second_attack_damage_15','own_turn_refresh','synthetic_tie_r26','skip_ko_additive','fault_no_partial_publish','holdout_deterministic_uniformity'],'holdout':stat,'original_battles_rerun':0,'contracts_terminal_certified':0,'canonical_cells':0}

if __name__=='__main__':
 z=audit()
 target=BASE/'R39_STANDALONE_AUDIT.json'
 if not target.exists():target.write_text(json.dumps(z,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 print(json.dumps(z,ensure_ascii=False,indent=2))
