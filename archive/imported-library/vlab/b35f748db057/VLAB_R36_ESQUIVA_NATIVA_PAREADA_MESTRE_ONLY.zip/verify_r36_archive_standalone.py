"""R36 package audit: stdlib-only, NO engine imports, read-only SQLite. Usage:
python verify_r36_archive_standalone.py /path/to/R36.zip
Checks each ZIP member SHA, CRC, 9 ledgers and 8 checkpoint mirrors, R18 chain,
R36 receipt metadata and source authorization. Does not certify Notion identity itself.
"""
from __future__ import annotations
import io,sys,zipfile,sqlite3,tempfile,json,hashlib,collections
from pathlib import Path

def canon(obj):return json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha_obj(o):return sha_bytes(canon(o).encode())
def inspect_one(p):
 c=sqlite3.connect(f'file:{p}?mode=ro',uri=True)
 try:
  meta=dict(c.execute('SELECT key,value FROM meta'));ints=c.execute('PRAGMA integrity_check').fetchone()[0]
  pending=c.execute('SELECT count(*) FROM pending').fetchone()[0]
  rows=c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
  prev=meta['genesis'];prior_state=None
  for n,(seq,cmd,old,rowjson,rowsha,bsha,asha) in enumerate(rows,1):
   row=json.loads(rowjson)
   if seq!=n or row['seq']!=n or cmd!=row['cmd_id'] or old!=prev or row['prev']!=prev:raise AssertionError('CHAIN_ROW')
   if sha_obj(row)!=rowsha or row['before_sha']!=bsha or row['after_sha']!=asha:raise AssertionError('HASH_MISMATCH')
   if prior_state is not None and bsha!=prior_state:raise AssertionError('BROKEN_STATE_CHAIN')
   prior_state=asha;prev=rowsha
  if ints!='ok' or pending!=0 or int(meta['revision'])!=len(rows) or meta['head']!=prev:raise AssertionError('POST_METADATA')
  state=json.loads(meta['state'])
  if rows and sha_obj(state)!=prior_state:raise AssertionError('POST_STATE_HASH')
  if not rows and meta['head']!=meta['genesis']:raise AssertionError('PRECOMMIT_HEAD')
  if state.get('source_status')!='SOURCE_REAL_READONLY_ISOLATED_SANDBOX' or state['r36']['world_effects']!=0:raise AssertionError('NON_CANONICAL_SOURCE_STATUS')
  if any(v['source_page_id']!='391c2b32-4ede-8252-b0cc-810423cdbfa6' or v['resource']['reflex']!=6 for v in state['actors'].values()):raise AssertionError('INVALID_SOURCE_REFLEX')
  if rows and state['phase']!='COMPLETE_LAB_REAL_SOURCE_REACTION_R36':raise AssertionError('NOT_TERMINAL')
  return {'head':meta['head'],'revision':len(rows),'events':len(rows),'integrity':ints,'pending':pending,'state':state,'rows':rows,'meta':meta}
 finally:c.close()

def verify(package):
 with zipfile.ZipFile(package) as z:
  assert z.testzip() is None,'ZIP_CRC_FAILURE'
  names=z.namelist()
  assert len(names)==len(set(names)),'DUPLICATE_NAMES'
  manifest=json.loads(z.read('R36_FILE_MANIFEST.json'))
  expected=manifest['files']
  assert set(names)==set(expected)|{'R36_FILE_MANIFEST.json'},'MANIFEST_MEMBERS_DIFFER'
  for f,hash_expected in expected.items():
   if sha_bytes(z.read(f))!=hash_expected:raise AssertionError('FILE_SHA_DIFF_'+f)
  authority=json.loads(z.read('authority/MESTRE_REFLEXO_ESQUIVAR_R36_VERIFIED.json'))
  assert authority['physical_readback'] and authority['reflex']==6 and authority['dodge_defense']==26 and authority['no_double_CA']
  scenes=[];dodge=collections.Counter();bytes_original={}
  with tempfile.TemporaryDirectory(prefix='vlab36_ro_') as td:
   for name in names:
    if name.startswith('runs/') and name.endswith('.sqlite'):
     p=Path(td)/Path(name).name;p.write_bytes(z.read(name));k=inspect_one(p)
     bytes_original[name]=sha_bytes(z.read(name));scenes.append((name,k));p.unlink()
   for fname,k in scenes:
    if 'SEED421' in fname:
     assert k['events']==0 and k['revision']==0 and k['pending']==0,'ABORTED_PREFLIGHT_NOT_INTACT';continue
    stem=Path(fname).stem
    ckname='checkpoints/'+stem+'_BACKUP.sqlite'
    cp=Path(td)/('ck_'+Path(ckname).name);cp.write_bytes(z.read(ckname));k2=inspect_one(cp);cp.unlink()
    assert k['head']==k2['head'] and k['state']==k2['state'] and k['rows']==k2['rows'],'CHECKPOINT_NOT_LOGICALLY_IDENTICAL'
    receipt=json.loads(z.read('evidence/'+stem+'_RECEIPT.json'))
    assert receipt['after']['head']==k['head'] and receipt['after']['events']==k['revision'],'RECEIPT_STATE_DIFF'
    assert receipt['ledger']['sha256']==bytes_original[fname] and receipt['checkpoint']['sha256']==sha_bytes(z.read(ckname)),'RECEIPT_BINARY_SHA_DIFF'
    assert receipt['replay_independent']['status']=='PASS' and receipt['replay_independent']['events']==k['revision'],'NO_REPLAY_PROOF'
    assert receipt['world_canon_credit']==0,'CANON_CREDIT_INVALID'
    for row in k['rows']:
     rec=json.loads(row[3]);detail=rec.get('detail',{})
     native=detail.get('native',{});attack=native.get('attack_native_event');reaction=native.get('reaction_native_event')
     if attack:
      if attack['ca_exact']!='20' or attack['roll_score']>25 or attack['roll_score']<20:raise AssertionError('ATTACK_SCORE_SOURCE_MISMATCH')
      if reaction:
       if reaction['action']!='ESQUIVAR' or reaction['defense_exact']!='26' or reaction['consumes_reaction'] is not True or reaction['damage_negated'] is not True:raise AssertionError('DODGE_WRONG')
       if attack['net']!=0 or attack['defensive_reaction']!='ESQUIVAR':raise AssertionError('DODGE_NOT_EFFECTIVE')
       dodge['all']+=1;dodge['native_hits_prevented']+=int(attack['hit']);dodge['spent_on_miss']+=int(not attack['hit'])
  actual_sc=len(scenes);total_events=sum(x['events'] for _,x in scenes)
  assert actual_sc==9,'WRONG_LEDGER_COUNT'
  assert sum(x['events']>0 for _,x in scenes)==8,'WRONG_COMPLETED_COUNT'
  assert dodge['all']==8 and dodge['native_hits_prevented']==7 and dodge['spent_on_miss']==1,'DODGE_COUNTS_DIFF'
  return {'status':'PASS','zip_members':len(names),'sha256_members':len(expected),'sqlite_ledgers':actual_sc,'completed_scenes':8,'quarantined_precommit_scenes':1,'checkpoints':8,'native_reactions':dodge['all'],'hits_prevented':dodge['native_hits_prevented'],'reaction_on_miss':dodge['spent_on_miss'],'chain_events':total_events,'crc':'PASS'}
if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('usage verify_r36_archive_standalone.py ARCHIVE.zip')
 print(json.dumps(verify(sys.argv[1]),indent=2,ensure_ascii=False))
