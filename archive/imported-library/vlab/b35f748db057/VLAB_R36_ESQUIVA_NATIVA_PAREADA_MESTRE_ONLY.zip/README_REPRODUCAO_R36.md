# R36 — Reflexo e Esquiva nativa / Mestre-side

**Operação original:** `CM-000006 / OP-VLAB-FUSION-SANDBOX-01`. R36 é uma extensão **aditiva, não canônica**, sobre o núcleo v0.8.1 e o ledger R18/R26. Nenhum arquivo de R01–R35 foi editado.

## Pacote de leitura independente

```bash
python verify_r36_archive_standalone.py VLAB_R36_ESQUIVA_NATIVA_PAREADA_MESTRE_ONLY.zip
```

O verificador utiliza exclusivamente a biblioteca-padrão de Python: confere CRC e SHA dos membros, cadeia de hashes R18, 9 SQLite (8 conclusos + 1 preflight sem evento), 8 checkpoints, readback lógico, recibos e os oito usos de Esquivar. Ele **não** substitui o replay no núcleo histórico nem certificação institucional.

## Replay histórico e reprodução

Requer descompactar e disponibilizar **a baseline já existente R27**, com módulos históricos `vlab_r18_interactive`, `vlab_r26_master_rulings`, `vlab_effects_v08`, `vlab_action_catalog_v01`, `vlab_rd_v08`; e o gateway R31 presente no pacote R35. A cópia `run_r35_native.py` no delta tem SHA idêntico à de R35. A versão R36 utiliza `run_r36_dodge.py` e `audit_science_r36.py` sem editar os motores históricos. A estrutura local `r27` e `extension` aponta somente para esses componentes históricos.

**NÃO execute novamente** `run_r36_dodge.py` sobre bancos/recibos existentes: o construtor é exclusivo e recusa duplicatas. Para conferir os oito resultados use `python audit_science_r36.py` em cópia extraída com dependências históricas. Para novas seeds, crie uma nova pasta do laboratório e um novo checkpoint de autoridade, sem reetiquetar históricos.

### Regras verificadas

- Reflexo Cabra Bronze1 = +6 (autoridade direta do Mestre, OP readback 15/10/2026).
- Esquivar = CA20 + Reflexo6 = **26**. Sem dupla CA.
- Esquivar é anunciado ANTES do ataque, consome **1 slot de Reação**, custo adicional PA0 e renova no início do próprio turno (R26).
- Políticas declaradas ANTES: `DECLINE` ou `EVADE_FIRST_INCOMING_EACH` (ambas as Cabras usam Esquivar apenas no PRIMEIRO ataque recebido; depois escolhem declinar). Não se trata de incapacidade de esquivar nas rodadas seguintes.
- Sementes pareadas 423, 433, 449, 457, RNG independente por ator e ordinal próprio de ataque. Um primeiro banco para seed421 foi bloqueado ANTES de qualquer evento por ID transacional inválido; 0 eventos, 0 pendências, conservado no arquivo e NÃO contado como luta.
- Snapshot real de Cabra (duas instâncias da mesma fonte), Investida autorizada, empurrão 1,5 m quando dano líquido positivo; reações defensoras válidas impediram sete acertos e consequentemente seus sete empurrões.
- Sem escrita Party, O Primeiro, Vida/Alma/inventário oficial, sem promoção DMG ou NAC-PASS terminal produtivo.
