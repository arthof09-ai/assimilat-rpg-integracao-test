"""R36 isolated native-reaction safety tests; NEVER writes official or archived DB."""
from __future__ import annotations
import copy,json
import run_r36_dodge as m
from dataclasses import asdict
from vlab_action_catalog_v01 import ActorActionState,action_menu
from vlab_effects_v08 import Scene,Combatant,react_defensively,apply_weapon_attack,EffectBlocked
from vlab_rd_v08 import Resistances

def test():
 a,b=m.b.ids('MIRROR');report=[]
 def check(label,ok):
  if not ok:raise AssertionError(label)
  report.append({'check':label,'status':'PASS'})
 # Fresh test actor clones with only the Reflex explicitly authorized.
 from run_r36_dodge import POLICIES
 st=m.init_state(m.b.initialize_state(m.j.initial('A',8101),'MIRROR'),POLICIES[1])
 fighters={k:Combatant(**copy.deepcopy(v['resource'])) for k,v in st['actors'].items()}
 base=Scene(fighters,seed=8101,provenance='R36-EPHEMERAL-TEST-NONCAN')
 defense=m.source_reaction();proof=m.proof_reaction()
 state=ActorActionState(actor_id=b,ordinal_level=1,available_pa=22,known_action_ids=(m.DODGE_ACTION,),reaction_available=True,reaction_trigger_observed='BEFORE-ATTACK',enemy_ids_visible=(a,))
 out=action_menu(state,(defense,),phase='REACTION',strict=True,source_evidence=(proof,))
 check('01_STRICT_SOURCE_DODGE_AVAILABLE',len(out.legal_options)==1 and out.rejected==())
 no_proof=action_menu(state,(defense,),phase='REACTION',strict=True,source_evidence=())
 check('02_REJECT_PROOF_ABSENT',len(no_proof.legal_options)==0 and no_proof.rejected[0][1]=='SOURCE-EVIDENCE-NOT-FROZEN')
 missing_trigger=ActorActionState(actor_id=b,ordinal_level=1,available_pa=22,known_action_ids=(m.DODGE_ACTION,),reaction_available=True,reaction_trigger_observed=None,enemy_ids_visible=(a,))
 untriggered=action_menu(missing_trigger,(defense,),phase='REACTION',strict=True,source_evidence=(proof,))
 check('03_REJECT_WRONG_TRIGGER',len(untriggered.legal_options)==0 and untriggered.rejected[0][1]=='NO-SOURCE-TRIGGER')
 try:react_defensively(copy.deepcopy(base),b,kind='ESQUIVAR',attack_score=24,announced_before=False,trigger_source='BEFORE-ATTACK',source=defense,state=state,proofs=(proof,),strict=True)
 except EffectBlocked:check('04_NO_LATE_ANNOUNCEMENT',True)
 else:check('04_NO_LATE_ANNOUNCEMENT',False)
 invalid=copy.deepcopy(base);invalid.actors[b].reaction=0
 try:react_defensively(invalid,b,kind='ESQUIVAR',attack_score=24,announced_before=True,trigger_source='BEFORE-ATTACK',source=defense,state=state,proofs=(proof,),strict=True)
 except EffectBlocked:check('05_SPENT_REACTION_REJECT',True)
 else:check('05_SPENT_REACTION_REJECT',False)
 scene=copy.deepcopy(base)
 ev=react_defensively(scene,b,kind='ESQUIVAR',attack_score=25,announced_before=True,trigger_source='BEFORE-ATTACK',source=defense,state=state,proofs=(proof,),strict=True)
 check('06_NATIVE_DODGE_DEFENSE_26',ev['defense_exact']=='26' and ev['damage_negated'] and scene.actors[b].reaction==0)
 attack=m.b.native_source();ap=m.b.proof('MIRROR')
 s=ActorActionState(actor_id=a,ordinal_level=1,available_pa=22,known_action_ids=(m.b.GO_ACTION,),standard_available=True,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(b,))
 hit=apply_weapon_attack(scene,a,b,source=attack,state=s,proofs=(ap,),roll_score=25,damage=19,damage_tag='impacto',rd=Resistances(general=5,specific=(),provenance='BRONZE_RD5'),strict=True,defense_event=ev)
 check('07_DODGE_PREVENTS_DAMAGE_AND_APPLIES_ATTACK_STANDARD',hit['hit'] and hit['net']==0 and scene.actors[b].hp==38 and scene.actors[a].standard==0)
 check('08_REACTION_COST_EXACTLY_ONE',scene.actors[b].reaction==0 and scene.actors[b].pa==22)
 try:react_defensively(scene,b,kind='ESQUIVAR',attack_score=25,announced_before=True,trigger_source='BEFORE-ATTACK',source=defense,state=state,proofs=(proof,),strict=True)
 except EffectBlocked:check('09_NO_DOUBLE_REACTION_SAME_SLOT',True)
 else:check('09_NO_DOUBLE_REACTION_SAME_SLOT',False)
 cloned=copy.deepcopy(st);cloned['actors'][b]['resource']['reaction']=0
 refresh=m.r26.refresh_own_turn(cloned,b)
 check('10_REFRESH_R26_ON_OWN_TURN',refresh['before']==0 and refresh['after']==1 and cloned['actors'][b]['resource']['reaction']==1)
 attack2=copy.deepcopy(base)
 try:apply_weapon_attack(attack2,a,b,source=attack,state=s,proofs=(ap,),roll_score=25,damage=19,damage_tag='impacto',rd=Resistances(general=5,specific=(),provenance='BRONZE_RD5'),strict=True,defense_event=ev)
 except EffectBlocked:check('11_NO_REUSING_FOREIGN_DEFENSE_EVENT',True)
 else:check('11_NO_REUSING_FOREIGN_DEFENSE_EVENT',False)
 # Unknown Fortitude+Armor from the official Beast record deliberately remain null.
 check('12_NO_MADE_UP_FORT_ARMOR',all(c.armor is None and c.fortitude is None for c in base.actors.values()))
 check('13_NO_WORLD_EFFECTS',base.provenance.endswith('NONCAN') and st['r36']['world_effects']==0)
 m.write_exclusive('evidence/R36_REACTION_NATIVE_GUARDS.json',{'schema':'R36_NATIVE_REFLEX_GUARDS_V1','passed':len(report),'total':len(report),'checks':report,'scope':'R36-EPHEMERAL-NOT-FULL-FIGHT'})
 print(json.dumps({'passed':len(report),'total':len(report),'status':'PASS'},ensure_ascii=False))
if __name__=='__main__':test()
