from pathlib import Path
import zipfile,hashlib,json
R=Path(__file__).resolve().parent
OUT=Path('/mnt/data/VLAB_R36_ESQUIVA_NATIVA_PAREADA_MESTRE_ONLY.zip')
files=[]
for name in ['README_REPRODUCAO_R36.md','R36_RELATORIO_MESTRE_ONLY.md','run_r36_dodge.py','run_r35_native.py','audit_science_r36.py','test_r36_guards.py','verify_r36_archive_standalone.py','build_r36_package.py']:
 files.append(R/name)
for sub in ('authority','evidence','runs','checkpoints'):
 files.extend(sorted((R/sub).glob('*')))
files=[x for x in files if x.is_file()]
info={str(x.relative_to(R)):hashlib.sha256(x.read_bytes()).hexdigest() for x in files}
manifest={'schema':'VLAB_R36_SHA256_FILE_MANIFEST_V1','operation':'OP-VLAB-FUSION-SANDBOX-01','historical_references':['R27 baseline','R31/R35 historical real-source gateway'],'r36_scenes_completed':8,'r36_pairs':4,'failed_precommit_not_counted':1,'files':info}
(R/'R36_FILE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
if OUT.exists():raise RuntimeError('PACKAGE_ALREADY_EXISTS_NO_OVERWRITE')
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for x in files:z.write(x,arcname=str(x.relative_to(R)))
 z.write(R/'R36_FILE_MANIFEST.json',arcname='R36_FILE_MANIFEST.json')
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)+1
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in info.items())
print(json.dumps({'archive':str(OUT),'size_bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'zip_entries':len(files)+1,'member_sha256':len(files),'crc':'PASS'},indent=2))
