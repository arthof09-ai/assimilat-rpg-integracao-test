"""R36 after-run replay, paired actor-local tape invariance, SQLite and official-source audit.
No event commits, no Notion writes.  Uses the same historical effect resolver on replay.
"""
from __future__ import annotations
from pathlib import Path
import json,hashlib,sqlite3,collections,statistics,copy,zipfile
import run_r36_dodge as g
R=Path(__file__).resolve().parent
SEEDS=(423,433,449,457)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_json(p):return json.loads(Path(p).read_text())
def rows_for(seed,policy):
 p=R/'runs'/f'R36_{policy}_SEED{seed}.sqlite'
 r=load_json(R/'evidence'/f'R36_{policy}_SEED{seed}_RECEIPT.json')
 genesis=load_json(R/'evidence'/f'R36_{policy}_SEED{seed}_GENESIS.json')['state']
 a=g.audit_db(p,genesis,policy)
 ck=R/'checkpoints'/f'R36_{policy}_SEED{seed}_BACKUP.sqlite'
 cb=g.audit_db(ck,genesis,policy)
 if a!=cb:raise RuntimeError(f'CHECKPOINT_REPLAY_DIFF {seed} {policy}')
 if r['after']!=a or r['ledger']['sha256']!=sha(p) or r['checkpoint']['sha256']!=sha(ck):raise RuntimeError(f'RECEIPT_DIFF {seed} {policy}')
 rows=g.j.history(p)['events'];
 native=[x for x in rows if x['kind']=='R36_NATIVE_GOAT_TURN']
 physical_reactions=[x['detail']['native']['reaction_native_event'] for x in native if x['detail']['native']['reaction_native_event']]
 for x in native:
  d=x['detail'];e=d['native']['attack_native_event'];rd=d['native']['reaction_native_event'];t=d['turn']
  if d['dice']['attack_total']!=d['dice']['attack_score_for_native']:raise RuntimeError('ATTACK_SUM_MISMATCH')
  if e['roll_score']!=d['dice']['hit_die']+19:raise RuntimeError('HIT_RULE_DIFF')
  if e['ca_exact']!='20' or e['rd_applied'] not in (0,5):raise RuntimeError('CA_RD_DIFF')
  if e['defensive_reaction']!=('ESQUIVAR' if rd else None):raise RuntimeError('REACTION_KIND_DIFF')
  if rd:
   if not t['reaction_announced_before'] or not rd['consumes_reaction'] or rd['defense_exact']!='26' or not rd['damage_negated']:raise RuntimeError('DODGE_ILLEGAL')
   if d['native']['engine_events'][0]!=rd or d['native']['engine_events'][1]!=e:raise RuntimeError('INCORRECT_NATIVE_EVENT_ORDER')
   if not d['reaction_refresh_R26'] or d['reaction_refresh_R26']['before']!=0:raise RuntimeError('REACTION_NOT_RENEWED')
  if rd and e['hit'] and e['net']!=0:raise RuntimeError('DODGE_DID_NOT_BLOCK_HP')
  if rd and e['hit'] and d['forced_push'] is not None:raise RuntimeError('DODGE_FAILED_TO_BLOCK_PUSH')
  if not rd and e['hit'] and e['net']!=max(0,d['dice']['damage_for_native']-5):raise RuntimeError('NATIVE_DAMAGE_RULE_DIFF')
  if (d['forced_push'] is not None) != (e['net']>0):raise RuntimeError('PUSH_TRIGGER_DIFF')
  if d['forced_push'] is not None and d['forced_push']['meters']!=1.5:raise RuntimeError('PUSH_METER_DIFF')
 return r,a,rows,native,physical_reactions

def main():
 out={'schema':'R36_INDEPENDENT_LAB_AUDIT_AND_SCIENCE_V1','seeds':list(SEEDS),'source_page_goat':g.b.GOAT,'notion_operation':g.b.OP,'master_reflex_auth_sha256':sha(g.AUTH),'paired':[],'scene_verification':[],'historic_untouched':{},'result':'PASS'}
 all_stats=collections.defaultdict(lambda:collections.Counter());nchecks=0
 for seed in SEEDS:
  pair={};tas={}
  for policy in g.POLICIES:
   receipt,a,rows,attacks,reactions=rows_for(seed,policy)
   pair[policy]=a;tas[policy]={}
   for row in attacks:
    die=row['detail']['dice'];actor=die['actor'];tas[policy].setdefault(actor,[]).append((die['hit_die'],die['damage_die'],tuple(die['crit_dice'])))
   if policy=='EVADE_FIRST_INCOMING_EACH' and len(reactions)!=2:raise RuntimeError('DEFENSE_COUNT_NE2')
   if policy=='DECLINE' and reactions:raise RuntimeError('UNEXPECTED_REACTION')
   if a['world_effects']!=0 or a['revision']!=len(rows) or a['events']!=len(rows) or a['pending']!=0:raise RuntimeError('TRANSACTION_WRONG')
   if a['stats']['dodge_success']!=len(reactions):raise RuntimeError('DODGE_SUCCESS_AGG_DIFF')
   if a['stats']['forced_pushes']!=sum(bool(x['detail']['forced_push']) for x in attacks):raise RuntimeError('PUSH_TOTAL_DIFF')
   if a['stats']['voluntary_movements']!=sum(bool(x['detail']['geometry_movement']) for x in attacks):raise RuntimeError('MOVE_TOTAL_DIFF')
   nchecks+=17
   out['scene_verification'].append({'seed':seed,'policy':policy,'status':'PASS','events':len(rows),'revision':a['revision'],'head':a['head'],'integrity':a['integrity'],'checkpoint_replay':'PASS','reaction_calls':len(reactions),'native_attacks':len(attacks),'winner':a['winner'],'rounds':a['rounds'],'sqlite_sha256':sha(R/'runs'/f'R36_{policy}_SEED{seed}.sqlite')})
   for k in ('attacks','native_hits','effective_hits','net_damage','dodge_success','reaction_announcements','forced_pushes','voluntary_movements'):
    all_stats[policy][k]+=a['stats'][k]
   all_stats[policy]['rounds']+=a['rounds'];all_stats[policy]['battles']+=1
  for actor in g.b.ids('MIRROR'):
   old=tas['DECLINE'].get(actor,[]);new=tas['EVADE_FIRST_INCOMING_EACH'].get(actor,[])
   if old[:min(len(old),len(new))]!=new[:min(len(old),len(new))]:raise RuntimeError('ACTOR_STABLE_RNG_DIFF')
  if pair['EVADE_FIRST_INCOMING_EACH']['rounds']<pair['DECLINE']['rounds']:raise RuntimeError('TIME_REVERSAL')
  out['paired'].append({'seed':seed,'baseline_winner':pair['DECLINE']['winner'],'dodge_winner':pair['EVADE_FIRST_INCOMING_EACH']['winner'],'baseline_rounds':pair['DECLINE']['rounds'],'dodge_rounds':pair['EVADE_FIRST_INCOMING_EACH']['rounds'],'delta_rounds':pair['EVADE_FIRST_INCOMING_EACH']['rounds']-pair['DECLINE']['rounds'],'same_actor_tape_common_prefix':True,'baseline_attacks':pair['DECLINE']['stats']['attacks'],'dodge_attacks':pair['EVADE_FIRST_INCOMING_EACH']['stats']['attacks']})
 # The initial attempt seed421 failed before event_commit due command id prefix; preserve it as rev0, NOT combat.
 p=R/'runs'/'R36_DECLINE_SEED421.sqlite'
 if not p.exists():raise RuntimeError('MISSING_PRECOMMIT_ATTEMPT')
 cn=sqlite3.connect(f'file:{p}?mode=ro',uri=True)
 try:
  meta=dict(cn.execute('SELECT key,value FROM meta'))
  z={'revision':int(meta['revision']),'events':cn.execute('SELECT count(*) FROM events').fetchone()[0],'pending':cn.execute('SELECT count(*) FROM pending').fetchone()[0],'integrity':cn.execute('PRAGMA integrity_check').fetchone()[0]}
 finally:cn.close()
 if z!={'revision':0,'events':0,'pending':0,'integrity':'ok'}:raise RuntimeError('PRECOMMIT_NOT_QUARANTINED')
 out['quarantined_precommit_seed421']=z;out['quarantined_precommit_seed421']['sha256']=sha(p)
 # Check historic R27-R35 ZIP (when present) without altering.
 names={
 'R27':'/mnt/data/vlab_r35/recovered/VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip',
 'R28':'/mnt/data/vlab_r35/recovered/VLAB_R28_CIENCIA_DIRIGIDA_MESTRE_ONLY.zip',
 'R29':'/mnt/data/vlab_r35/recovered/VLAB_R29_CIENCIA_BESTAS_E_CAUSALIDADE_MESTRE_ONLY.zip',
 'R30':'/mnt/data/vlab_r35/recovered/VLAB_R30_ACAO_REAL_PREFLIGHT_CIENCIA_MESTRE_ONLY.zip',
 'R31':'/mnt/data/vlab_r35/recovered/VLAB_R31_PRIMEIRA_RABADA_NATIVA_CONDICIONAL_MESTRE_ONLY.zip',
 'R32':'/mnt/data/vlab_r35/recovered/VLAB_R32_PRIMEIRA_RABADA_INTEGRAL_REAL_FONTE_MESTRE_ONLY.zip',
 'R33':'/mnt/data/vlab_r35/recovered/VLAB_R33_PREPARACAO_COMBATE_REAL_FONTE_MESTRE_ONLY.zip',
 'R34':'/mnt/data/vlab_r35/recovered/VLAB_R34_PRIMEIRO_COMBATE_COMPLETO_BESTAS_REAIS_MESTRE_ONLY.zip',
 'R35':'/mnt/data/VLAB_R35_EMPURRAO_GEOMETRIA_COMPARACAO_MESTRE_ONLY.zip'}
 expect={'R27':'d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1','R28':'68da72d6fe71020ce4a555089484514cc86cab67d90c92a77e52d2166c46fdfa','R29':'0c9beb35b030f844cb109d44fa40bb2f5731665f0e056601252a7ec3c5ee2eb0','R30':'55328526ce48c1acfa6568e6bc9e713762c8e33bf818b5aa2bc174c95c1838ae','R31':'98841bf0473545005bdb107597981805199a35081e2dc84a4b6d150b97fa6835','R32':'20530947c8349d8e544fa5ee506e7327b31a8e6d37eb3aab23c180d1639c4a53','R33':'ceeab4d4786ee3670959be477c90c2dc42cce0806fb9d773e5814ca14bb9bb8b','R34':'876236ebb34ee76f514b17d3ff765f32d40e1b8c81ef7f21248e0d34187705bc','R35':'61c952c6d1896845fd2e96433bf65d1986eb313810304e708190109ce3b02413'}
 for name,path in names.items():
  f=Path(path)
  if not f.exists():
   out['historic_untouched'][name]={'status':'NOT_PRESENT_NO_CREDIT'};continue
  digest=sha(f)
  if digest!=expect[name]:raise RuntimeError('HISTORIC_ARCHIVE_SHA_CHANGED '+name+' '+digest)
  out['historic_untouched'][name]={'status':'PRESERVED_SHA_MATCH','sha256':digest}
 # Distinguish reaction consumption (8) from truly prevented damaging hits (7).
 prevented_hits=0;reaction_on_miss=0
 for seed in SEEDS:
  rec,au,rows,native,_=rows_for(seed,'EVADE_FIRST_INCOMING_EACH')
  for ev in native:
   z=ev['detail']['native'];react=z['reaction_native_event'];attack=z['attack_native_event']
   if react and attack['hit'] and attack['net']==0:prevented_hits+=1
   if react and not attack['hit']:reaction_on_miss+=1
 out['native_reaction_damage_prevention']={'reactions_used':all_stats['EVADE_FIRST_INCOMING_EACH']['reaction_announcements'],'native_hits_prevented':prevented_hits,'spent_on_natural_miss':reaction_on_miss,'policy_first_incoming_for_each_actor_only':True}
 out['scenes_complete']=8;out['paired_independent_seeds']=len(SEEDS);out['existing_R35_complete_fights_preserved']=6;out['full_fights_after_R36']=14;out['stats_by_policy']={x:dict(v) for x,v in all_stats.items()};out['read_only_engine_replay_checks']=nchecks;out['global_balance_rate_not_determinable']=True
 f=g.write_exclusive('evidence/R36_AUDIT_AND_PAIRED_SCIENCE.json',out)
 print(json.dumps({'audit':out['result'],'full_scenes':out['scenes_complete'],'old_archives':out['historic_untouched'],'precommit421':out['quarantined_precommit_seed421'],'reaction':out['native_reaction_damage_prevention'],'stats':out['stats_by_policy'],'checks':nchecks},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
