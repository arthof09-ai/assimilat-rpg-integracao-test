# PSV — CM-000006 / OP-VLAB-FUSION-SANDBOX-01 — R36

**15/10/2026 · MESTRE-SIDE · artefato experimental, não regra oficial nova.**

## ANTES, DECISÃO E DEPOIS

**ANTES R35:** seis combates completos com fontes reais (R34=1, R35=5), dois patamares de um rank Bronze, 34 empurrões novos R35, **zero Reações voluntárias válidas** por falta de bônus individual de Reflexo nas fichas Bronze1. Motor legado v0.8.1, R26 refresh e ledger R18 existentes. R01–R35 congeladas, IBX-56 BLOCKED-EXTERNAL.

**DECISÃO VINCULANTE DO MESTRE:** “O reflexo é o bônus de sua proficiência mais sua CA, que no caso da classificação Bronze é+6”. Interpretação do Sistema de Combate atual para Esquivar: **CA20 + bônus Reflexo6 = defesa26**. NÃO somar CA duas vezes; não acrescentar Reflexo em ataque/dano, Fortitude ou Armadura. Decisão registrada na OP existente e reaberta em **2026-10-15T19:17:53.801Z**; fonte de Cabra Bronze1 reaberta com dados FOR13 DES8 CON10 HP38 CA20 e Investida validada de R34, nenhuma edição da ficha. A marca de evidência é um ponteiro de readback, NÃO assinatura digital do Notion.

**DEPOIS:** executor R36 aditivo usa estritamente **o mesmo `vlab_effects_v08.react_defensively` e `apply_weapon_attack`**, `ActionCatalog` strict, iniciativa e renovação R26, economia/ledger R18, fonte real Mestre no sandbox e empurrão transacional R35. Nenhum motor alternativo, nenhum arquivo histórico regravado.

## Experimento pareado com duas instâncias da MESMA Cabra B1

Conjunto exploratório de 4 sementes independentes (**423, 433, 449, 457**), duas cenas POR semente: `DECLINE` versus `EVADE_FIRST_INCOMING_EACH`. Ambas as políticas foram definidas explicitamente antes da ação: a segunda utiliza Esquivar no **primeiro ataque recebido por cada Cabra**, e posteriormente declina por decisão tática experimental; não se suprimiu o slot de Reação. A reação é anunciada antes do ataque, consome 1 slot e renova no início do próprio turno seguinte, conforme R26.

Sorteio de crítico, acerto e dano usa fluxos **independentes por ator e ordinal de seu próprio ataque**, iguais nos prefixos comuns dos pares. Não se reutilizaram bancos antigos. O ataque Investida mantém 1d6+13+Luta6, CA20, RD5 e empurrão1,5m para FF310; não há incremento de dano por Luta.

| Semente | Declina: vencedor | Declina: rodadas | Esquiva: vencedor | Esquiva: rodadas |
|---|---|---:|---|---:|
| 423 | Cabra B | 4 | Cabra B | 5 |
| 433 | Cabra B | 4 | Cabra B | 5 |
| 449 | Cabra A | 4 | Cabra A | 5 |
| 457 | Cabra A | 4 | Cabra A | 5 |

- **8/8 novos combates completos**, 4/4 pares com replay histórico e backup SQLite verificado, nenhuma alteração de vencedor (4/4), duração **4→5 rodadas em 4/4 pares**. Amostra pequena, NÃO taxa universal.
- Baseline: **30 ataques**, 26 acertos nativos com dano, 26 empurrões, 22 movimentos voluntários, 16 rodadas somadas.
- Com primeiro Esquivar: **38 ataques**, 34 acertos brutos, 27 acertos com dano positivo, 27 empurrões, 23 movimentos voluntários, 20 rodadas somadas.
- **8/8 Reações Esquivar executadas nativamente** com defesa26 e consumo de 1 slot; **7 impediram golpes que passariam CA20**, e **1 foi anunciada em ataque que já erraria CA20**. Todas as oito satisfizeram score≤26. O impedimento de dano também impediu empurrão.
- Não interpretar a soma bruta de dano das lutas como efeito isolado da Reação, pois a própria defesa altera a quantidade de turnos e golpes. O efeito local auditado são sete golpes realmente neutralizados e o prolongamento nos quatro pares.
- Um crítico positivo ocorreu em turno tardio de uma das cenas com defesa ativa, processado pelo núcleo; nenhum crítico negativo ocorreu nas oito cenas. Margens, efeitos de crítico e disponibilidade de Reação não foram inventados.

**Limite científico:** Esquiva total26 supera o teto25 da Investida comum; sob uma política hipotética de sempre esquivar com slot disponível, seria plausível censura por dano nulo recorrente. Isso é uma consequência matemática condicional, NÃO um combate completo executado nem uma regra universal de invulnerabilidade (outras habilidades, bônus, geometrias e escolha de Reação mudam o caso).

## Recibos, integridade e recuperação

- 8 novos SQLite terminados, 8 recibos, 8 backups, 8 replay nativo original+backup PASS. Auditoria posterior **136 verificações estruturadas** e **13/13 testes guardas de fonte, janela, consumo, dupla Reação, dano, replay** PASS.
- Uma nona tentativa seed421, política DECLINE, gerou somente gênese SQLite: revisão0, **zero eventos e zero intenções pendentes**, integrity OK. Falha antes de `event_commit` por prefixo de comando incorreto; conservada como **preflight interrompido sem efeito**. Próximas oito cenas usaram o prefixo obrigatório `LAB-CMD-` e IDs diferentes. Nenhum retry em banco incerto.
- ZIP histórico R27–R35: **9/9 hashes SHA256 coincidentes com os checkpoints preservados**, nenhum pacote alterado.
- Não se alegou certificação binária independente da Coordenação nem NAC-PASS terminal produtivo. Fichas oficiais, Party, O Primeiro e campanha: zero alterações.

## CONTADORES / MESTRE-SIDE

| Indicador | ANTES R35 | DEPOIS R36 |
|---|---:|---:|
| Combates completos real-fonte em sandbox | 6 | **14** (8 novos) |
| Instâncias/sources | duas Cabras B1 de mesma fonte | idem, nenhuma nova espécie |
| Reações voluntárias nativas reais-fonte | 0 | **8** |
| Novos hits neutralizados por Esquivar | 0 | **7** |
| Patamares representados por combate completo | 2/25 | **2/25** (Bronze1 e Bronze5) |
| Combates canônicos | 0 | **0** |
| Contratos terminais VLAB | 0/17 | **0/17** |
| Células canônicas | 0/1.875 | **0/1.875** |

**FRONTEIRA R37:** testar DEFENDER apenas se Armadura/Fortitude tiverem valores competentes; investigar política `Esquivar sempre` com censura explícita e regra de encerramento de stalemate; comparar entre **duas espécies** Bronze de patamar próximo somente após admitir a ação de ambas. Estudar RD geral×RDF do Rinolupo separadamente. Preservar R29 seed53 e UNKNOWN_EFFECT, e exigir NAC-PASS-02 antes de qualquer promoção canônica; writer/lease/epoch/fencing/GREEN/HOLD e IBX-56 bloqueado permanecem.
