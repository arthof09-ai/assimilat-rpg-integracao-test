"""R36 Mestre-side additive adapter: same v0.8.1 native attack AND native ESQUIVAR.
Sources: official Goat Bronze1, Combat Rule, Mestre express Reflex=+6, R34 Investida.
Scene is isolated, not campaign canon. Replays do not re-commit SQLite history.
Imports byte-identical R35 runner and original R18/R26/v0.8.1, never edits them.
"""
from __future__ import annotations
import copy,json,sqlite3,hashlib,sys,math
from pathlib import Path
from dataclasses import asdict
R=Path(__file__).resolve().parent
import run_r35_native as b
from vlab_action_catalog_v01 import ActorActionState, AbilitySource, FrozenRuleEvidence, action_menu
from vlab_effects_v08 import Scene,Combatant,apply_weapon_attack,react_defensively,COMBAT_PAGE
from vlab_rd_v08 import Resistances
j=b.j;r26=b.r26
DODGE_SOURCE_ID='MESTRE-REFLEXO-PROF-BRONZE-CABRA-20261015-R36'
DODGE_ACTION='R36_ESQUIVAR_MESTRE_B1_CABRA'
AUTH=R/'authority'/'MESTRE_REFLEXO_ESQUIVAR_R36_VERIFIED.json'
POLICIES=('DECLINE','EVADE_FIRST_INCOMING_EACH')
class Hold(RuntimeError):pass

def auth():
 x=json.loads(AUTH.read_text())
 if x.get('ruling_id')!=DODGE_SOURCE_ID or x.get('physical_readback') is not True or x.get('source_page')!=b.GOAT or x.get('ca_printed')!=20 or x.get('reflex')!=6 or x.get('dodge_defense')!=26 or x.get('no_double_CA') is not True:
  raise Hold('R36_RULING_NOT_AUTHENTICATED')
 if x.get('operation_page')!=b.OP or x.get('source_not_global_override') is not True:raise Hold('R36_RULING_SCOPE')
 b.authorization();b.g.verify_pins();return x

def write_exclusive(rel,obj):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8') as f:json.dump(obj,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
 return p

def fighters(st):return b.ids('MIRROR')
def other(st,aid):return next(x for x in fighters(st) if x!=aid)

def source_reaction():
 return AbilitySource(DODGE_ACTION,'reaction','REACTION',COMBAT_PAGE,DODGE_SOURCE_ID,'EXPLICIT-CANON',required_pa=0,target_scope='SELF',reaction_trigger='BEFORE-ATTACK',effect_adapter_ready=True,effect_adapter_id='NATIVE-v0.8.1-react_defensively')

def proof_reaction():
 return FrozenRuleEvidence(COMBAT_PAGE,DODGE_SOURCE_ID,b.sha_file(AUTH),'2026-10-15-NOTION-REOPEN-R36','OP-VLAB-R36-EXPRESS-MESTRE-REFLEX-6-CA-20')

def init_state(st,policy):
 auth()
 for aid,obj in st['actors'].items():
  if obj['source_page_id']!=b.GOAT:raise Hold('NO_CABRA_SOURCE')
  if obj['resource']['reflex'] is not None:raise Hold('R36_NOT_FRESH_GENESIS')
  obj['resource']['reflex']=6
  obj['stats']['reflex_bonus']=6
  obj['stats']['reflex_origin']=DODGE_SOURCE_ID
 st['scene']='R36-REAL-GOAT-MIRROR-'+policy
 st['r35']['reaction_policy']='R36_VOLUNTARY_'+policy+'_OWN_TURN_REFRESH_R26'
 st['r35']['source_mode']='MASTER_REAL_SOURCE_AUTHENTICATED_SANDBOX_NO_CANON'
 st['r36']={'schema':'R36_VOLUNTARY_REACTION_V1','master_authority_sha':b.sha_file(AUTH),
  'policy':policy,'source_goal':'CAPABILITY_REACTION_NATIVELY_ADMITTED',
  'choice_rule':'DEFENDER_ANNOUNCES_BEFORE_INCOMING_ATTACK; EITHER DECLINE OR FIRST_INCOMING_PER_ACTOR',
  'no_global_reflex_ruling_assumed':True,'reaction_kind':'ESQUIVAR','reflex_bonus':6,'dodge_defense':26,
  'roll_provenance':'actor-local independent R36 indexed critical/hit/damage tapes',
  'attack_indices':{aid:0 for aid in fighters(st)},'reactions_used':{aid:0 for aid in fighters(st)},
  'reaction_announcements':0,'dodge_success':0,'attacks':0,'native_hits':0,'effective_hits':0,'net_damage':0,
  'forced_pushes':0,'voluntary_movements':0,'no_reaction_reasons':[],'world_effects':0}
 return st

def create(db,policy,seed):
 if policy not in POLICIES:raise Hold('UNSUPPORTED_POLICY')
 if Path(db).exists():raise Hold('DB_EXISTING_NEVER_REUSE')
 _=auth();j.init_db(db,'A',seed)
 con=j.connect(db)
 try:
  con.execute('BEGIN IMMEDIATE')
  meta=dict(con.execute('SELECT key,value FROM meta'))
  if int(meta['revision'])!=0 or con.execute('SELECT COUNT(*) FROM events').fetchone()[0]:raise Hold('NOT_GENESIS')
  st=init_state(b.initialize_state(json.loads(meta['state']),'MIRROR'),policy)
  genesis=j.sha({'seed':seed,'policy':policy,'engine':j.VERSION,'r35_source_proof_sha':st['r35']['source_proof_hash'],'r36_authority_sha':st['r36']['master_authority_sha'],'experiment':True})
  for key,v in [('state',j.canonical(st)),('genesis',genesis),('head',genesis),('scene',st['scene'])]:con.execute('UPDATE meta SET value=? WHERE key=?',(v,key))
  con.commit()
 except:con.rollback();raise
 finally:con.close()
 return checked(db)

def checked(db):
 st,h,rev=j.load(db)
 if st['r36']['master_authority_sha']!=b.sha_file(AUTH):raise Hold('AUTHORITY_SHA_CHANGED')
 if st['r36']['policy'] not in POLICIES or st['r36']['world_effects']!=0:raise Hold('R36_POLICY_OR_WORLD')
 if st['r35']['source_proof_hash']!=j.sha(b.manifest('MIRROR')):raise Hold('R35_SOURCE_PROOF_CHANGED')
 for a in fighters(st):
  if st['actors'][a]['source_page_id']!=b.GOAT or st['actors'][a]['resource']['reflex']!=6:raise Hold('IDENTITY_OR_REFLEX_DIFF')
  if st['actors'][a]['resource']['armor'] is not None or st['actors'][a]['resource']['fortitude'] is not None:raise Hold('UNAUTHORIZED_OTHER_DEFENSE')
 return st,h,rev

def preview(st):
 aid=st['active'];idx=st['r36']['attack_indices'][aid]+1;seed=st['seed']
 crit=[j.dice(seed,idx,'R36-CRIT-'+aid+'-'+str(k),1,6)[0] for k in (1,2,3)]
 hit=j.dice(seed,idx,'R36-HIT-'+aid,1,6)[0]
 dmg=j.dice(seed,idx,'R36-DAMAGE-'+aid,1,6)[0]
 positive=crit[:2]==[6,6] and crit[2]>=5
 negative=crit[:2]==[1,1] and crit[2]<=2
 if negative:raise Hold('NEGATIVE_CRITICAL_UNRESOLVED_HOLD_BEFORE_INTENT')
 return {'actor':aid,'target':other(st,aid),'own_attack_index':idx,'crit_dice':crit,'critical':'POSITIVE' if positive else 'NONE',
  'hit_die':hit,'damage_die':dmg,'attack_total':hit+13+6,'raw_damage':dmg+13+(6 if positive else 0),
  'attack_score_for_native':hit+13+6,'damage_for_native':dmg+13+(6 if positive else 0),'attack_source':b.GO_ACTION}

def choose_reaction(st,target):
 pol=st['r36']['policy']
 if pol=='DECLINE':return False
 return (st['r36']['reactions_used'][target]==0 and st['actors'][target]['resource']['reaction']==1)

def native(st,p,use_dodge):
 aid=p['actor'];target=p['target'];actor=st['actors'][aid]['resource'];d=st['actors'][target]['resource']
 if b.dist(st)>b.ADJ+1e-8:raise Hold('ATTACK_WITHOUT_ADJACENCY')
 src=b.native_source();pf=b.proof('MIRROR');rr=b.Resistances(general=5,specific=(),provenance='CREACAO_BESTA_BRONZE_NORMAL_RD5')
 state=ActorActionState(actor_id=aid,ordinal_level=1,available_pa=actor['pa'],known_action_ids=(b.GO_ACTION,),standard_available=actor['standard']==1,reaction_available=actor['reaction']==1,range_confirmed=True,geometry_confirmed=True,enemy_ids_visible=(target,))
 catalog=action_menu(state,(src,),strict=True,source_evidence=(pf,))
 if len(catalog.legal_options)!=1 or catalog.rejected:raise Hold('ATTACK_SOURCE_STRICT_REJECT')
 scene=Scene({a:Combatant(**copy.deepcopy(v['resource'])) for a,v in st['actors'].items()},seed=st['seed'],provenance='MASTER_NOTION_REAL_BEAST_SANDBOX_R36')
 before={k:{'hp':v['resource']['hp'],'pa':v['resource']['pa'],'standard':v['resource']['standard'],'reaction':v['resource']['reaction']} for k,v in st['actors'].items()}
 re=None
 if use_dodge:
  if before[target]['reaction']!=1:raise Hold('REACTION_SLOT_MISSING')
  dr=source_reaction();df=proof_reaction()
  drstate=ActorActionState(actor_id=target,ordinal_level=1,available_pa=d['pa'],known_action_ids=(DODGE_ACTION,),standard_available=d['standard']==1,reaction_available=True,reaction_trigger_observed='BEFORE-ATTACK',enemy_ids_visible=(aid,))
  dec=action_menu(drstate,(dr,),phase='REACTION',strict=True,source_evidence=(df,))
  if len(dec.legal_options)!=1 or dec.rejected:raise Hold('DODGE_SOURCE_STRICT_REJECT')
  re=react_defensively(scene,target,kind='ESQUIVAR',attack_score=p['attack_score_for_native'],announced_before=True,trigger_source='BEFORE-ATTACK',source=dr,state=drstate,proofs=(df,),strict=True)
  if re.get('defense_exact')!='26' or re.get('consumes_reaction') is not True or scene.actors[target].reaction!=0:raise Hold('NATIVE_DODGE_INCONSISTENT')
 effect=apply_weapon_attack(scene,aid,target,source=src,state=state,proofs=(pf,),roll_score=p['attack_score_for_native'],damage=p['damage_for_native'],damage_tag='impacto',rd=rr,strict=True,defense_event=re)
 for k,v in scene.actors.items():st['actors'][k]['resource']=asdict(v)
 if st['actors'][aid]['resource']['standard']!=0:raise Hold('STANDARD_NOT_DEBITED')
 for k,v in st['actors'].items():
  if v['resource']['pa']!=before[k]['pa']:raise Hold('UNEXPECTED_PA_CHANGE')
  if v['resource']['hp']>before[k]['hp']:raise Hold('HP_INCREASE')
 if use_dodge:
  if effect['defensive_reaction']!='ESQUIVAR' or st['actors'][target]['resource']['reaction']!=0:raise Hold('REACTION_NOT_APPLIED')
 else:
  if effect['defensive_reaction'] is not None:raise Hold('UNREQUESTED_REACTION')
 return {'reaction_native_event':re,'attack_native_event':effect,'engine_events':copy.deepcopy(scene.events),'engine_checksum':scene.checksum(),'source_action':src.action_id,'reaction_source':DODGE_ACTION if use_dodge else None,'native_core':'original_v0.8.1.react_defensively + apply_weapon_attack'}

def prereq(st):
 _=auth()
 if st['r36']['master_authority_sha']!=b.sha_file(AUTH):raise Hold('AUTHORITY_TAMPER')
 if st['r36']['world_effects']!=0:raise Hold('CANON_WRITE_INVALID')
 if st['r35']['geometry']['goat_ff']!=310:raise Hold('FF_SOURCE_INVALID')
 if st['phase'] not in ('INIT','ACTIVE'):raise Hold('PHASE_INVALID')

def initialize(st,payload,seq):
 prereq(st)
 if seq!=1 or st['phase']!='INIT' or payload['seed']!=st['seed']:raise Hold('INIT_BAD')
 roll=r26.resolve_initial_state(st);refresh=r26.refresh_own_turn(st,st['active'])
 return {'initiative_native_R26':roll,'reaction_refresh_native_R26':refresh,'world_effects':0}

def turn(st,payload,seq):
 prereq(st);x=st['r36'];aid=st['active'];target=other(st,aid)
 if payload['kind']!='R36_TURN' or payload['actor']!=aid or payload['target']!=target or payload['round']!=st['round'] or payload['policy']!=x['policy']:raise Hold('TURN_PREVIEW_MISMATCH')
 moved=b.move_to_adjacent(st,aid)
 if st['actors'][aid]['resource']['standard']!=1:raise Hold('STANDARD_SPENT')
 p=preview(st);react=choose_reaction(st,target)
 if p!=payload['preview'] or react!=payload['reaction_announced_before']:raise Hold('RNG_OR_REACTION_DRIFT')
 native_result=native(st,p,react);effect=native_result['attack_native_event'];rea=native_result['reaction_native_event']
 push=b.push_if_hit(st,aid,target,effect)
 x['attacks']+=1;x['native_hits']+=int(effect['hit']);x['effective_hits']+=int(effect['net']>0);x['net_damage']+=effect['net'];x['attack_indices'][aid]+=1
 x['forced_pushes']+=int(bool(push));x['voluntary_movements']+=int(bool(moved))
 if react:
  x['reaction_announcements']+=1;x['reactions_used'][target]+=1;x['dodge_success']+=int(bool(rea['damage_negated']))
 st['r35']['attacks']+=1;st['r35']['hits']+=int(effect['hit']);st['roll_nonce']+=1
 if st['actors'][target]['resource']['hp']==0:
  st['phase']='COMPLETE_LAB_REAL_SOURCE_REACTION_R36';st['winner']=aid;st['finish_reason']='HP_ZERO_SANDBOX_NOT_CAMPAIGN';st['active']=None;transition={'combat_ended':True};refresh=None
 else:
  transition=j._next_turn(st)
  refresh=r26.refresh_own_turn(st,st['active'])
 return {'turn':{'attacker':aid,'target':target,'round':payload['round'],'own_attack_index':p['own_attack_index'],'reaction_policy':x['policy'],'reaction_announced_before':react},'dice':p,'geometry_movement':moved,'native':native_result,'forced_push':push,'transition_R18':transition,'reaction_refresh_R26':refresh,'phase_after':st['phase'],'hp_after':{k:v['resource']['hp'] for k,v in st['actors'].items()},'reaction_slots_after':{k:v['resource']['reaction'] for k,v in st['actors'].items()},'position_after':copy.deepcopy(b.positions(st)),'world_effects':0}

def payload_turn(st):
 p=preview(st);return {'kind':'R36_TURN','actor':st['active'],'target':p['target'],'round':st['round'],'preview':p,'reaction_announced_before':choose_reaction(st,p['target']),'policy':st['r36']['policy']}

def audit_db(db,before,expected_policy):
 st,h,v=checked(db)
 if st['r36']['policy']!=expected_policy:raise Hold('POLICY_DRIFT')
 con=sqlite3.connect(f'file:{db}?mode=ro',uri=True)
 try:
  pending=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0];integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
 finally:con.close()
 hist=j.history(db);rows=hist['events']
 replay=copy.deepcopy(before)
 for i,row in enumerate(rows,1):
  detail=initialize(replay,row['payload'],i) if row['kind']=='R36_INIT' else turn(replay,row['payload'],i)
  if j.sha(detail)!=j.sha(row['detail']) or j.sha(replay)!=row['after_sha']:raise Hold('REPLAY_DIFF_AT_'+str(i))
 if replay!=st or v!=len(rows) or pending!=0 or integrity!='ok':raise Hold('POST_REPLAY_STATE_DIVERGENCE')
 if st['phase']!='COMPLETE_LAB_REAL_SOURCE_REACTION_R36':raise Hold('NO_FULL_FIGHT_CREDIT')
 return {'status':'PASS','revision':v,'head':h,'events':len(rows),'pending':pending,'integrity':integrity,'rounds':st['round'],'stats':copy.deepcopy(st['r36']),'world_effects':0,'winner':st['winner'],'hp':{k:obj['resource']['hp'] for k,obj in st['actors'].items()},'reaction_slots':{k:obj['resource']['reaction'] for k,obj in st['actors'].items()},'position':copy.deepcopy(b.positions(st)),'replay_events':len(rows)}

def portable(db,destination):
 if Path(destination).exists():raise Hold('EXISTING_CHECKPOINT')
 c=sqlite3.connect(db);dest=sqlite3.connect(destination)
 try:c.backup(dest)
 finally:dest.close();c.close()
 if j.history(db)!=j.history(destination):raise Hold('CHECKPOINT_LOGICAL_DIFF')
 cn=sqlite3.connect(f'file:{destination}?mode=ro',uri=True)
 try:
  if cn.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise Hold('CHECKPOINT_CORRUPT')
 finally:cn.close()
 return {'sha256':b.sha_file(destination),'history_equivalent':True,'checkpoint_integrity':'ok'}

def run(seed,policy,max_events=60):
 tag=f'{policy}_SEED{seed}';db=R/'runs'/f'R36_{tag}.sqlite';p=R/'evidence'/f'R36_{tag}_RECEIPT.json';ck=R/'checkpoints'/f'R36_{tag}_BACKUP.sqlite';gen=R/'evidence'/f'R36_{tag}_GENESIS.json'
 if any(x.exists() for x in [db,p,ck,gen]):raise Hold('NEVER_REUSE_R36_TRANSACTION:'+tag)
 st,h,v=create(db,policy,seed)
 write_exclusive(f'evidence/R36_{tag}_GENESIS.json',{'state':st,'head':h,'revision':v})
 base=copy.deepcopy(st)
 initpay={'kind':'INIT','seed':seed,'policy':policy,'auth_sha':b.sha_file(AUTH)}
 j.event_commit(db,'LAB-CMD-R36-INIT-'+j.sha(initpay)[:24],'R36_INIT',initpay,initialize)
 for i in range(max_events):
  st,h,v=checked(db)
  if st['phase']!='ACTIVE':break
  pay=payload_turn(st)
  j.event_commit(db,'LAB-CMD-R36-TURN-'+j.sha({'head':h,'payload':pay})[:24],'R36_NATIVE_GOAT_TURN',pay,turn)
 else:raise Hold('MAX_EVENTS_CENSORED_NOT_COMPLETE')
 audit=audit_db(db,base,policy);checkpoint=portable(db,ck)
 # Replay from checkpoint independently, byte equality of sqlite not needed
 au2=audit_db(ck,base,policy)
 if au2['head']!=audit['head'] or au2['events']!=audit['events']:raise Hold('CHECKPOINT_REPLAY_DIVERGED')
 rec={'schema':'R36_REAL_SOURCE_NATIVE_ESQUIVAR_V1','seed':seed,'policy':policy,'source_pages':[b.GOAT],'attacker_defender_same_species_official_source':True,'authority_sha256':b.sha_file(AUTH),'before':{'hp':{k:v['resource']['hp'] for k,v in base['actors'].items()},'source':b.GOAT,'positions':copy.deepcopy(b.positions(base))},'after':audit,'ledger':{'name':db.name,'sha256':b.sha_file(db)},'checkpoint':checkpoint,'replay_independent':{'status':'PASS','events':audit['events'],'checkpoint_replay_status':'PASS'},'world_canon_credit':0,'full_fight_real_source_sandbox_credit':1}
 write_exclusive(f'evidence/R36_{tag}_RECEIPT.json',rec)
 print(json.dumps({'tag':tag,'result':{k:audit.get(k) for k in ('events','rounds','winner','hp','reaction_slots')},'stats':{k:audit['stats'][k] for k in ('attacks','native_hits','effective_hits','net_damage','reactions_used','dodge_success','forced_pushes','voluntary_movements')}},ensure_ascii=False))
 return rec

if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('USAGE: run_r36_dodge.py SEED DECLINE|EVADE_FIRST_INCOMING_EACH')
 run(int(sys.argv[1]),sys.argv[2])
