"""New seeds only, corrected internal RUN-ID incl matchup; never touch first 40 scenes."""
import json
from pathlib import Path
import r82_r91_benchmark_adapter as a
R=Path(__file__).resolve().parent
plan=json.loads((R/'PREREG_R82_CORRECTED_UNIQUE_RUN_IDS.json').read_text());results=[]
for m in a.FIXTURE['matchups']:
    a.configure(m)
    for group,seeds in plan['new_seeds'].items():
        for seed in seeds:
            for side in plan['sides']:
                r=a.run(seed,side,R/'runs'/m['id']);r['cohort']=group;results.append(r)
assert len(results)==len(set(r['run_id'] for r in results))==40
(R/'results_r82_r91_corrected_ids.json').write_text(a.canon(results)+'\n')
print(json.dumps({'fresh_runs':len(results),'unique_ids':len(set(r['run_id'] for r in results)),'seeds':plan['new_seeds'],'originals_unchanged':True}))
