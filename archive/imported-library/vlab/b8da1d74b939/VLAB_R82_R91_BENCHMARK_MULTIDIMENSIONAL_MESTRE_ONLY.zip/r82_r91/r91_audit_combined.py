"""Cold independent R82 + addendum audit; no import of execution module."""
from pathlib import Path
import json,sqlite3
from r91_cold_semantic_auditor import all_runs,audit,ensure,canon
R=Path(__file__).resolve().parent
base=all_runs(R)
a=json.loads((R/'ADDENDUM_M6_SOURCE_AND_PREREG.json').read_text())
f=json.loads((R/'fixture_r82_sources.json').read_text())
prof={'B':f['profiles'][a['matchup']['B']],'E':a['profile']}
extra=[]
for group,seeds in a['seeds'].items():
 for seed in seeds:
  pair=[]
  for side in a['sides']:
   p=R/'runs'/a['matchup']['id']/f'R82BENCH_{seed}_{side}.sqlite';cp=p.with_suffix('.checkpoint.sqlite')
   with sqlite3.connect(p) as c,sqlite3.connect(cp) as cc:
    for table in ('meta','events','pending'):
     ensure(c.execute('SELECT * FROM '+table+' ORDER BY 1').fetchall()==cc.execute('SELECT * FROM '+table+' ORDER BY 1').fetchall(),'M6_CHECKPOINT_'+table)
   res=audit(p,prof);res['matchup_id']=a['matchup']['id'];res['group']=group;pair.append(res);extra.append(res)
  ensure(pair[0]['winner']==pair[1]['winner'] and pair[0]['hp_final']==pair[1]['hp_final'] and pair[0]['attacks']==pair[1]['attacks'] and pair[0]['hits']==pair[1]['hits'] and pair[0]['events']==pair[1]['events'],'M6_SIDE_SWAP_BIAS')
all_r=base['runs']+extra
out={'all_pass':True,'runs':all_r,'matchups':base['matchups']+1,'unique_seed_values':len({x['seed'] for x in all_r}), 'independent_matchup_seed_blocks':len({(x['matchup_id'],x['seed']) for x in all_r}), 'mirrored_pairs':len({(x['matchup_id'],x['seed']) for x in all_r}), 'events':sum(x['events'] for x in all_r),'attacks':sum(x['attacks'] for x in all_r), 'hits':sum(x['hits'] for x in all_r),'censored_runs':sum(x['phase']=='CENSORED_HORIZON' for x in all_r),'completed_runs':sum(x['phase']=='COMPLETE' for x in all_r),'realized_damage':sum(x['hp_loss'] for x in all_r),'separate_auditor':True}
(R/'R91_COLD_AUDIT_COMBINED.json').write_text(canon(out)+'\n')
print(canon({k:v for k,v in out.items() if k!='runs'}))
