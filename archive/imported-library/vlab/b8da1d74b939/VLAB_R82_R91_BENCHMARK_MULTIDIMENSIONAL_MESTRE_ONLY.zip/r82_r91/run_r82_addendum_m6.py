"""Runs M6 as a new preregistered additive source snapshot. Never changes old source freeze or old runs."""
import json
from pathlib import Path
import r82_r91_benchmark_adapter as a
R=Path(__file__).resolve().parent
add=json.loads((R/'ADDENDUM_M6_SOURCE_AND_PREREG.json').read_text())
a.FIXTURE['profiles'][add['profile']['id']]=add['profile']
a.configure(add['matchup'])
out=[]
for group,seeds in add['seeds'].items():
    for sd in seeds:
        for side in add['sides']:
            res=a.run(sd,side,R/'runs'/add['matchup']['id']);res['cohort']=group;out.append(res)
(R/'results_r82_addendum_m6.json').write_text(a.canon(out)+'\n')
print(json.dumps([{k:r[k] for k in ('seed','side','winner','phase','turn_count','attacks','hits')} for r in out],indent=2))
