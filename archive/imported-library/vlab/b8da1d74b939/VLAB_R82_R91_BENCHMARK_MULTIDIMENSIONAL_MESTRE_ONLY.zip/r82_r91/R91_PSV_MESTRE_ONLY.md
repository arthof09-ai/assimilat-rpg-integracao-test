# PSV — VLAB R82–R91 | 27 posições operacionais, fontes verificadas e benchmark multidimensional

**AS-OF:** 2026-10-16, America/Recife  
**OPERATION:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01 (OP ORIGINAL, sem novo motor, laboratório, identidade ou Diary)  
**BASELINE:** R01–R81 preservada: pacote R81 SHA-256 `a6bd78736dc0eefb512e91acec337b9d0bb608e4b28610486abc3d8d5bb2885a`, ZIP 91 entradas, 90/90 hashes; R81 14 duelos originais NÃO reexecutados.  
**ENVIRONMENT:** MESTRE-SIDE, exclusivamente cópias locais e Biblioteca com versões novas.  
**AUTHORITY:** ordem autoral do Coordenador R82–R91 de 16/10/2026; diretriz autoral nova 27 posições prevalece no desenho experimental sobre modelo 25+2 anteriormente segregado. NAC-NORM-01 e NAC-PASS terminal continuam aplicáveis à canonização.

## 1 — Decisão central: escala de potência corrigida, sem rank fictício

A nova versão do esquema original preserva o histórico `R78_R80_BENCHMARK_COVERAGE_25.csv` (102 entradas) e introduz `R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv` com **104 posições primárias**:

- **A:** 25 posições regulares para referência de Espiritualistas em *duelos individuais de arquétipos*. Subgrade de 125 possibilidades (5 papéis × 25 patamares) **NÃO são builds completos**.
- **B:** **27 posições da Besta-âncora**, de Bronze1 a Lendário5 nas posições 1–25, **posição operacional 26 = Besta ADM**, **27 = Besta Divina**.
- **C:** 25 posições regulares de equipe equilibrada; 100 subcélulas por formação de 2, 3, 4 ou 5 membros. Nenhuma equipe certificada.
- **D:** **27 posições do painel de Bestas distintas** nos mesmos 25+ADM+Divina, com exigência de comprovar espécies e vínculos antes da seleção oficial.

**ADM e Divina integram a escala operacional autoral de potência como posições 26 e 27**, mas isto **não cria um rank ou estrela inexistente** e tampouco permite dispensar rank, estrela e modificadores próprios de cada fonte. Nenhuma posição fonte-candidata é marcada como pronta/homologada.

## 2 — Recuperação material e seleção de fontes

R81 original materializado e conferido (ZIP 91, 90/90 SHA, CRC PASS). R61/R71 preservados dentro do pacote R81. O plano Mestre `PLAN-SIM-DMG-VLAB-01`, a OP original, IBX-101 e os documentos de Criação de Besta, Criação de Ficha e Sistema de Combate foram reabertos no Notion Mestre. Identidade `CM-000006` ainda `PAUSED` e escritor produtivo HOLD. **Não houve ACK ou escrita em OP/Diário.**

**Bestas reais (3 fontes-ficha recuperadas):**
1. Frígido Ossário B5: `https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315`. Rabada 1d6+FOR18, Luta+6 **apenas decisão individual do Mestre**, Vida125/CA31, RD5 tabela Besta normal Bronze.
2. Behemoth Glacial O1: `https://app.notion.com/p/5dac2b324ede83f39cdb01a904ce3cfd`. Mordida 3d6+FOR18, Vida682/CA68, RD25 Ouro normal; bônus de Luta NÃO está na ficha: clone com perfil de **Luta destreinada/0**, NÃO afirma competência original.
3. Behemoth Selvagem O3 Titã: `https://app.notion.com/p/1e9c2b324ede833db9f601eac58d7de4`. Investida 2d6+FOR55, Vida1365/CA67, RD45 tabela Titã Ouro. Clone limitado, sem derrubada ou Força Titânica não especificada como ativada; Luta+0 virtual não comprovada na criatura original.

**Espiritualistas/projetos de comparação (3 fontes):**
1. Sunarco/Oceanus O3: `https://app.notion.com/p/fc7c2b324ede83c3986a813c6c48ca8b`. Ataque normal `3d6+81`, dano `5d8+1d8+4d8+119`, Vida325/CA86, RD5 declarada na **Armadura Média (ON)**; porém cabeçalho do estado diz **armadura leve**. Conflito de equipamento **NÃO resolvido**. Clone normal restrito, Vida reinicializada a 325 no LAB apesar de perda impressa 304, nunca cura de campanha.
2. Gorrok O1: `https://app.notion.com/p/257c2b324ede82a7b7b801b89fa13474`. Vida372/CA40, resistência natural física **15** explícita; espada 5d8 e bônus FF +7; teste físico `3d6+FOR50` em clone destreinado Luta+0. Tem Espírito Demoníaco na fonte, mas falta rótulo literal `Espiritualista Demoníaco`: **classe inferida, seleção operacional não homologada**.
3. Raya Vhassar L1, forma normal: `https://app.notion.com/p/36ec2b324ede8219afc2016bb6ec7bb9`. Ficha explicita Espiritualista Demoníaco, Vida1392, CA221, **RD físico14 da armadura**, ataque `6d6+245` e dano `16d8+12d6+4d12+294`, sem ativar outras habilidades. O texto `(+15)` junto do ataque não foi somado por não haver condição adicional comprovada. Este é o cenário mais próximo de **fonte-admissível para ataque básico**, NÃO é ficha de potência integral nem comparador de mesma classe.

A ficha anterior Capanga 1 (GO), cuja RD é ausente, permanece no R81 como **condicional**; nenhum R81 foi promovido ou repetido. Outras fontes faltantes não foram completadas por inferência.

## 3 — Execução, defeito de identificador e recuperação

**Primeira execução R82:** 40 duelos em cinco matchups, 4 seeds × dois espelhos. Auditoria semântica de eventos PASS, mas foi identificado **defeito de RUN-ID duplicado**: oito strings iguais apareciam em cinco confrontos diferentes. Os 40 SQLite, genesis e checkpoints foram preservados **sem modificar**, ERRATA `ERRATA_RUN_ID_COLLISION_R82.json`; **excluídos do conjunto científico válido de R82**. As seeds 382101/382102/382801/382802 NÃO foram repetidas. Não há efeito no histórico R59 ou R72.

**Correção:** o adaptador R82 foi corrigido para gerar `R82R91_<MATCHUP_ID>_<SEED>_<SIDE>` e pré-registrou quatro NOVAS seeds 385101/385102 desenvolvimento e 385801/385802 holdout. Novos 40 duelos executados sem reutilizar arquivos. A bateria complementar com Raya, isolada e pré-registrada em 384101/384102/384801/384802, gerou outros 8 duelos, cujos RUN-ID já eram únicos no conjunto selecionado.

**DENOMINATORS finais do conjunto selecionado:**
- **6 matchups**, **48 RUN-IDs únicos**, **24 blocos matchup×seed com troca de lados** (8 valores de seed, compartilhados entre alguns matchups e NÃO tratados como 24 probabilidades independentes universais).
- **40/48 combates completos**, **8/48 censurados**, que representam 4/24 blocos pareados de impasse O1×O1.
- **1.824 eventos**, **884 ataques**, **224 acertos**, mensurados por auditoria fria causal de todos os registros e verificação de checkpoints.
- **8/8 alterações semânticas com hash reconstruído REJEITADAS** pelo auditor, embora checagem de estrutura isolada as aceitasse.
- **5/5 tentativas negativas recusadas antes de gerar intenção durável** (pós-correção); sem mudança de Vida/PA/slot.
- **0/17 certificados terminais**, **0/1.875 células oficiais**, **0 linhas de potência integral homologadas** e **zero combate 2×1 executado neste ciclo**.
- Histórico R81: seus 14 duelos permanecem FORA desses denominadores; primeira bateria defeituosa R82 (40) fica preservada mas EXCLUÍDA.

## 4 — Resultados científicos por par, contabilizados por seed, não por lado

| Matched profiles | Patamares | Blocos únicos | Desfecho | Escopo da fonte |
|---|---|---:|---|---|
| Behemoth Selvagem × Oceanus | Ouro3 × Ouro3 | 4 | ED 4/4 | CONDICIONAL: Luta da Besta e armor do ED |
| Frígido Ossário × Oceanus | Bronze5 × Ouro3 | 4 | ED 4/4 | CONDICIONAL: armadura ED |
| Frígido Ossário × Gorrok | Bronze5 × Ouro1 | 4 | ED 4/4 | FONTE LIMITADA: Luta virtual destreinada + identidade ED inferida |
| Behemoth Selvagem × Gorrok | Ouro3 × Ouro1 | 4 | Besta 4/4 | CONDICIONAL: proficiências não impressas |
| Behemoth Glacial × Gorrok | Ouro1 × Ouro1 | 4 | **4/4 censurados aos 60 turnos** | CONDICIONAL: Luta virtual destreinada; hits críticos possíveis |
| Frígido Ossário × Raya | Bronze5 × Lendário1 | 4 | ED 4/4 | FONTE-ADMISSÍVEL para ataque normal/RD14, potencia integral NÃO |

**Observação finalística 1 — precisão defensiva:** no confronto Ouro1×Ouro1, Behemoth Glacial rola até `3d6+18=36` contra CA40; Gorrok destreinado rola até `3d6+50=68` contra CA68 (empate favorece defesa). Acertos comuns numericamente impossíveis sob ESSES perfis; críticos positivos permanecem possíveis. Foram observados danos ocasionais críticos insuficientes para matar antes do limite de 60 turnos. Não transformá-los em vitória nem alegar impasse universal de todos os combatentes Ouro1.

**Observação finalística 2 — condição e defesa:** Behemoth Selvagem e Oceanus compartilham Ouro3 nominal, mas o perfil virtual da Besta sem Luta treinada não supera a CA86 de Oceanus com acerto comum; ao mesmo tempo o teste normal de Oceanus supera facilmente CA67. O resultado mede esse emparelhamento e os itens/defesas escolhidos, não o ranking universal Ouro3.

**Observação finalística 3 — RD documentada:** Raya permite rastrear RD14 sem preenchimento arbitrário. O piloto resultou em quatro vitórias do ED em um turno cada por seed, resultado trivial dado o desnível enorme Lendário1×Bronze5. Demonstra admissão de dano/RD básico, NÃO compara forças equivalentes nem integra repertório completo.

**Fronteira DMG:** `R90_ATTACK_RECEIPTS_884.csv` separa por RUN-ID, source-ID, seed, side, score, hit, crítico, dano bruto, RD usada, dano após mitigação, perda real Vida e PA (zero por política). Entrega evidência, nenhuma proposta de recalibração DMG-RANK. `R90_PAIRED_BLOCKS_24.csv` e `R90_MULTIDIMENSIONAL_SCIENCE.json` explicitam denominadores e censura. Não estimar taxa universal de vitória a partir de 4 seeds.

## 5 — Quatro baterias: cobertura e próxima admissão

- **A indivíduos / 25 estrelas:** perfis candidatos Gorrok O1 (identidade ED a confirmar), Oceanus O3 (armadura em conflito), Raya L1 (RD explícita); 125 subcélulas para cinco funções (defesa, melee, ranged, arcano, suporte). Nenhuma escala legal de 1–25 completada para um arquétipo estável, nenhuma linha homologada.
- **B Besta-âncora / 27:** Frígido Ossário B5 é a primeira **candidata de linhagem com um único snapshot**. Sem progressão autorizada B1–L5 ou ADM/Divina no mesmo organismo. 1/27 candidata, 0/27 referências derivadas legitimamente.
- **C equipe / 25 estrelas × formação 2–5:** 100 subcélulas planejadas, **0/100 executadas**. One-shot Reino Superior/Puxi sem evidência satisfatória de nomes, participantes e fichas; não utilizar como composição confirmada. Alvos/side strategy e iniciativa de team 2×1 ainda precisam prova de integração, não confundir 2x1 com soma de duelos.
- **D painel 27 Bestas distintas:** candidatas nas posições Bronze5/Frígido, Ouro1/Behemoth Glacial e Ouro3/Behemoth Selvagem. **3/27 candidaturas documentadas; 0/27 referências homologadas**. Diversidade taxonômica Glacial/Selvagem e demais comparadores a comprovar; as demais posições vazias; ADM e Divina não inventados.

**NÃO SÃO RANKS 26 E 27.** São 26ª e 27ª posições operacionais de potência determinadas expressamente pelo Mestre para comparar Bestas especiais. O rank+estrela efetivos do ser especial ainda precisam existir individualmente em sua fonte.

## 6 — Matriz de contratos, gates e NAC-PASS

`R91_17_CONTRACTS_RECONCILED.md` reconcilia exatamente 17/17 contratos herdados sem substituir a definição R18. Evidência R82 concentra BATTLE1x1, SOURCE_FREEZE, RD, QA, RNG, scheduler e interface DMG. **0/17 contratos terminais** por QA oficial, fontes especiais, cobertura integral, writer e demais interlocks.

**NAC-PASS proporcional:** `PASS-LOCAL` para readback de arquivos, testes semânticos e integridade do pacote experimental. `HOLD` para avanço canônico, planilha oficial, caráter universal, produção e writer/lease/fencing. Source-bound / provisional ≠ fully homologated. Nenhuma escrita na Party, O Primeiro, DMG-RANK ou fichas originais.

## 7 — Estado operacional e sucessão

- **LAST-VERIFIED-UNIT:** R91 auditor frio em 48 ledgers + 24 pares + 8/8 adulterações rejeitadas + esquema 104 linhas. Último readback de Biblioteca detalhado em recibo de entrega; se não presente, NÃO alegar persistência.
- **FIRST-PENDING funcional:** validar competência Luta original, loadout da armadura Oceanus, comparador ED Ouro1 explícito completo e policy de 2×1, e construir 1 linhagem Besta admissível em >1 patamar sem misturar espécies.
- **FIRST-PENDING administrativo:** profile CM-000006 PAUSED, first instance pendente, writer/epoch/lease/fencing/GREEN e ACK IBX-101 pendentes. Não realizar atualizações OP/Diário sem autoridade.
- **DENOMINATORS:** 3 Bestas reais reabertas; 2 ED explícitos (Raya, Oceanus), 1 ED inferido (Gorrok), 6 confrontos, 48 RUN-IDs válidos, 40 completos/8 censurados, 24 pares seed×matchup, 884 ataques, 224 acertos, 1.824 eventos; 40 ledgers ID-colisão anteriores excluídos; 0/17 terminais, 0/1.875 células oficiais; posições 104 apenas esquema.
- **NO-REPEAT:** R01–R81 completos, 14 R81 duelos, R59 seed130011, R72 primeira tentativa seed160201 e primeira R82 seeds382101/382102/382801/382802 NÃO reexecutar.
- **CONFLICTS:** IBX101 antigo 25+2 vs decisão autoral posterior escala 27 (aplicar posterior às posições, sem sobrescrever plano canônico); Luta de Bestas não impresso, Gorrok ED inferido, armadura Oceanus leve × média, estado real de Vida Oceanus 21 após dano mas clone reinicializado HP325, críticas e controle somente mecanismo específico anterior. Nenhum conflito resolvido silenciosamente.
- **UNKNOWN-EFFECT:** R59 `LAB-CMD-R59-FAULT-FIRST-ONE` HOLD; R72 tentativa original INIT HOLD; R82 colisão de ID EXCLUÍDA sem sobrescrever.
- **NEXT-5:** (1) escolher ED do mesmo rank com RD e ataque físicos explícitos e sem loadout conflitante; (2) recuperar uma Besta com pontuação de Luta e RD completas; (3) homologar fonte e medir novo confronto mesmo patamar com 8+ seeds; (4) ensaio 2×1 baseado em lado/equipe causal e sem regras inventadas; (5) iniciar linhagem de Besta B5→outro patamar somente com derivação legal e primeira posição de painel de espécie distinta após auditoria taxonômica.
- **TARGET-REMAINDER:** 27 posições B, 27 posições D, 25 versões A de cada arquétipo, 25 versões C por formação; percentuais de cobertura **não são desempenho estatístico**. Diferenciar fonte-candidata vs snapshot legal vs duelo vs linha homologada.
- **AUTHORITY/WRITER STATE:** LAB réplica permitida; shared OP/Diary writer RED/HOLD; Profile PAUSED, sem instancia I0001 alocada/ACK; nenhuma mudança compartilhada.

**Ponto exato para sucessor:** reabrir o ZIP `VLAB_R82_R91_BENCHMARK_MULTIDIMENSIONAL_MESTRE_ONLY.zip`, validar SHA manifesto, executar `python r82_r91/r91_audit_corrected_ids.py` e `python r82_r91/r91_redteam_corrected.py` APENAS EM CÓPIA NOVA (a segunda recriaria casos existentes e deve ser adaptada para verificar os receipts já preservados, não reexecutada no diretório original). O comando independente de readback mais seguro é `python r82_r91/r91_audit_corrected_ids.py` (lê ledgers e gera resultado). NÃO chamar os runners de execução dos combates históricos.
