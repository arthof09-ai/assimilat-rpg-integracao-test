"""Versioned continuation of the existing benchmark scheme, not a competing database.
Separates 48 runs vs 24 paired matchup×seed blocks, no power scalar or canon promotion.
"""
import csv,hashlib,json,statistics,collections
from pathlib import Path
R=Path(__file__).resolve().parent
base=json.loads((R/'fixture_r82_sources.json').read_text())
add=json.loads((R/'ADDENDUM_M6_SOURCE_AND_PREREG.json').read_text())
profiles=base['profiles']|{add['profile']['id']:add['profile']}
matchups=base['matchups']+[add['matchup']]
runs=json.loads((R/'results_r82_r91_corrected_ids.json').read_text())+json.loads((R/'results_r82_addendum_m6.json').read_text())
assert len(runs)==48 and len({r['run_id'] for r in runs})==48
lookup={m['id']:m for m in matchups}

def writecsv(name,rows,cols):
    with open(R/name,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(rows)
    return len(rows)

metrics=[];attacks=[];blocks=[];gr=collections.defaultdict(list)
for r in runs:
    m=lookup[r['matchup_id']];pr={a:profiles[m[a]] for a in ('B','E')}
    actor=collections.defaultdict(lambda:{'attempts':0,'hits':0,'crit_plus':0,'damage_raw':0,'post_rd':0,'realized_hp_loss':0,'pa_spent':0})
    for ai,receipt in enumerate(r['attack_receipts'],1):
        a=receipt['actor'];z=actor[a];z['attempts']+=1;z['hits']+=int(receipt['hit']);z['crit_plus']+=int(receipt['crit_plus'])
        z['damage_raw']+=receipt['damage_raw'];z['post_rd']+=receipt['damage_net_potential'];z['realized_hp_loss']+=receipt['hp_loss_actual'];z['pa_spent']+=receipt['pa_spent']
        attacks.append({'run_id':r['run_id'],'matchup_id':r['matchup_id'],'seed':r['seed'],'side':r['side'],'cohort':r['cohort'],'attack_index':ai,'actor_side':a,'actor_id':pr[a]['id'],'target_id':pr['E' if a=='B' else 'B']['id'],'source_url':receipt['source'],'action':receipt['attack_name'],'attack_score':receipt['score'],'target_CA':receipt['ca'],'hit':int(receipt['hit']),'crit_plus':int(receipt['crit_plus']),'crit_minus':int(receipt['crit_minus']),'damage_raw':receipt['damage_raw'],'rd_used':receipt['rd'],'damage_post_rd_potential':receipt['damage_net_potential'],'hp_before':receipt['hp_before'],'hp_after':receipt['hp_after'],'hp_real_loss':receipt['hp_loss_actual'],'pa_spent':receipt['pa_spent'],'admission':r['admission'],'ledger':'runs/'+r['matchup_id']+'/'+r['ledger']})
    metrics.append({'run_id':r['run_id'],'matchup_id':r['matchup_id'],'cohort':r['cohort'],'seed':r['seed'],'side':r['side'],'B_id':pr['B']['id'],'B_rank':pr['B']['rank'],'E_id':pr['E']['id'],'E_rank':pr['E']['rank'],'B_source':pr['B']['source'],'E_source':pr['E']['source'],'source_gate':r['admission'],'winner_side':r['winner'] or 'NONE_CENSORED','winner_id':pr[r['winner']]['id'] if r['winner'] else 'NONE_CENSORED','phase':r['phase'],'turns':r['turn_count'],'rounds':r['rounds'],'events':r['events'],'attacks':r['attacks'],'hits':r['hits'],'B_attempts':actor['B']['attempts'],'B_hits':actor['B']['hits'],'B_raw':actor['B']['damage_raw'],'B_post_RD':actor['B']['post_rd'],'B_real_hp_loss':actor['B']['realized_hp_loss'],'E_attempts':actor['E']['attempts'],'E_hits':actor['E']['hits'],'E_raw':actor['E']['damage_raw'],'E_post_RD':actor['E']['post_rd'],'E_real_hp_loss':actor['E']['realized_hp_loss'],'B_HP_final':r['hp_final']['B'],'E_HP_final':r['hp_final']['E'],'B_PA_spent':actor['B']['pa_spent'],'E_PA_spent':actor['E']['pa_spent'],'control_status':'NOT_EXECUTED','other_reactions':'NONE_DECLARED','official_benchmark':0,'ledger':'runs/'+r['matchup_id']+'/'+r['ledger']})
    gr[(r['matchup_id'],r['seed'])].append(metrics[-1])
for (id,seed),v in sorted(gr.items()):
    assert len(v)==2 and {x['side'] for x in v}=={'B_LEFT','E_LEFT'}
    x,y=sorted(v,key=lambda u:u['side'])
    assert all(x[k]==y[k] for k in ('winner_id','phase','turns','events','attacks','hits','B_real_hp_loss','E_real_hp_loss','B_HP_final','E_HP_final'))
    blocks.append({'matchup_id':id,'seed':seed,'cohort':x['cohort'],'run_id_1':x['run_id'],'run_id_2':y['run_id'],'outcome':x['winner_id'],'phase':x['phase'],'turns':x['turns'],'B_id':x['B_id'],'B_rank':x['B_rank'],'E_id':x['E_id'],'E_rank':x['E_rank'],'source_gate':x['source_gate'],'B_attempts':x['B_attempts'],'B_hits':x['B_hits'],'B_damage_real':x['B_real_hp_loss'],'B_HP_final':x['B_HP_final'],'E_attempts':x['E_attempts'],'E_hits':x['E_hits'],'E_damage_real':x['E_real_hp_loss'],'E_HP_final':x['E_HP_final'],'mirror_consistent':True,'official_benchmark':0})
writecsv('R90_BENCHMARK_RUNS_48.csv',metrics,list(metrics[0]))
writecsv('R90_PAIRED_BLOCKS_24.csv',blocks,list(blocks[0]))
writecsv('R90_ATTACK_RECEIPTS_884.csv',attacks,list(attacks[0]))
assert len(attacks)==884 and len(blocks)==24

ranks=['Bronze','Prata','Ouro','Ouro Negro','Lendário']
level_slots=[(1+i*5+j,r,j+1) for i,r in enumerate(ranks) for j in range(5)]
slots=[]
for level,rank,star in level_slots:
    for bat in ('A_INDIVIDUAL_ARCHETYPE_ED_25','B_SINGLE_BEAST_LINEAGE_27','C_BALANCED_TEAM_25','D_DISTINCT_BEAST_PANEL_27'):
        source=None;status='SOURCE_MISSING';clone='NOT_BUILT';note=''
        if bat=='A_INDIVIDUAL_ARCHETYPE_ED_25':
            candidates=[x for x in profiles.values() if 'Espiritualista' in x['kind'] and x['rank']==f'{rank} {star}']
            if candidates:source=';'.join(x['id'] for x in candidates);status='CANDIDATE_NOT_REFERENCE';clone='VIRTUAL_SOURCE_SNAPSHOT'
            note='Five role slots stored separately; not ED-anchor level completion'
        elif bat=='B_SINGLE_BEAST_LINEAGE_27' and rank=='Bronze' and star==5:
            source='FOSSARIO_B5';status='LINEAGE_CANDIDATE_ONE_SNAPSHOT';clone='EXISTING_B5_SOURCE_ONLY';note='No legal same-species level transitions proved; 26 other positions empty'
        elif bat=='D_DISTINCT_BEAST_PANEL_27':
            pp={'Bronze 5':'FOSSARIO_B5','Ouro 1':'GLACIAL_O1','Ouro 3':'SELVAGEM_O3'}
            source=pp.get(f'{rank} {star}')
            if source:status='CANDIDATE_PENDING_SPECIES_ELIGIBILITY';clone='SOURCE_PAGE_REOPENED';note='Distinct species must still be reconciled, no universal comparator homologation'
        elif bat=='C_BALANCED_TEAM_25':note='Cohorts of 2..5 roles stored separately; historical one-shot party not identified'
        slots.append({'schema_version':'R82-V1-AMENDS-R81-102','battery':bat,'power_position':level,'rank':rank,'star':star,'operational_position_type':'REGULAR','source_identity':source or '', 'source_status':status,'clone_status':clone,'experimental_1v1_runs_observed':sum(1 for z in metrics if f'{rank} {star}' in (z['B_rank'],z['E_rank']) and (source and source in (z['B_id'],z['E_id'])) ) if source else 0,'reference_homologated':0,'source_gate':'SOURCE_CONDITIONAL_OR_CANDIDATE' if source else 'SOURCE_MISSING','next_required':note or 'select source species/profile; validate full mechanics and legal derivation'})
for pos,name in [(26,'ADM'),(27,'Besta Divina')]:
    for bat in ('B_SINGLE_BEAST_LINEAGE_27','D_DISTINCT_BEAST_PANEL_27'):
        slots.append({'schema_version':'R82-V1-AMENDS-R81-102','battery':bat,'power_position':pos,'rank':'', 'star':'','operational_position_type':name,'source_identity':'','source_status':'SOURCE_MISSING','clone_status':'NOT_BUILT','experimental_1v1_runs_observed':0,'reference_homologated':0,'source_gate':'SPECIAL_TRAIT_AUTHORITY_NOT_RESOLVED','next_required':f'Prepare legitimate {name} profile, underlying rank+star remains explicit; no invented 26th/27th canonical rank'})
assert len(slots)==104 and len({(x['battery'],x['power_position']) for x in slots})==104
writecsv('R82_CORRECTED_BENCHMARK_SCHEMA_PRIMARY_104.csv',slots,list(slots[0]))

roles=['frontline_defense','melee_offense','ranged_offense','arcane_damage','support_control']
role_candidates={'frontline_defense':[],'melee_offense':['GORROK_O1','RAYA_VHASSAR_L1'],'ranged_offense':[],'arcane_damage':['OCEANUS_O3'],'support_control':[]}
role_slots=[]
for lv,r,star in level_slots:
 for role in roles:
  matches=[a for a in role_candidates[role] if profiles[a]['rank']==f'{r} {star}']
  role_slots.append({'schema_version':'R82-ROLES-1','battery':'A_INDIVIDUAL_ARCHETYPE_ED_25','rank':r,'star':star,'power_position':lv,'role':role,'candidate_source_ids':';'.join(matches),'candidate_is_frozen':int(bool(matches)),'comparator_ready':0,'official_runs':0,'note':'Role inferred from abilities only; historic one-shot team not verified; not automatic ED scaling'})
assert len(role_slots)==125
writecsv('R82_BATTERY_A_ROLE_SLOTS_125.csv',role_slots,list(role_slots[0]))
team=[]
for lv,r,star in level_slots:
 for members in (2,3,4,5):
  team.append({'schema_version':'R82-TEAM-1','battery':'C_BALANCED_TEAM_25','power_position':lv,'rank':r,'star':star,'team_size':members,'historical_one_shot_identity':'NOT_ATTESTED','balanced_roles_validated':0,'team_profile_admitted':0,'team_battles':0,'gate':'legal builds + team policy/target selection + distinct loadout sources + auditor'})
assert len(team)==100
writecsv('R82_BATTERY_C_TEAM_SLOTS_100.csv',team,list(team[0]))

summary=[]
for m in matchups:
 bs=[b for b in blocks if b['matchup_id']==m['id']]
 summary.append({'matchup':m['id'],'besta':profiles[m['B']]['name'],'besta_rank':profiles[m['B']]['rank'],'ED':profiles[m['E']]['name'],'ED_rank':profiles[m['E']]['rank'],'seed_blocks':len(bs),'mirror_runs':len(bs)*2,'completed_blocks':sum(b['phase']=='COMPLETE' for b in bs),'censored_blocks':sum(b['phase']=='CENSORED_HORIZON' for b in bs),'B_wins':sum(b['outcome']==profiles[m['B']]['id'] for b in bs),'ED_wins':sum(b['outcome']==profiles[m['E']]['id'] for b in bs),'median_turns_per_block':statistics.median(b['turns'] for b in bs),'B_hits_total':sum(b['B_hits'] for b in bs),'B_attempts_total':sum(b['B_attempts'] for b in bs),'ED_hits_total':sum(b['E_hits'] for b in bs),'ED_attempts_total':sum(b['E_attempts'] for b in bs),'B_realized_HP_loss_total':sum(b['B_damage_real'] for b in bs),'ED_realized_HP_loss_total':sum(b['E_damage_real'] for b in bs),'source_admission':m['admission'],'official_homologation':False,'inference_scope':'Four seeds in controlled basic attack, not population win probability or complete class potency'})
(R/'R90_MULTIDIMENSIONAL_SCIENCE.json').write_text(json.dumps({'operation':base['operation'],'as_of':'2026-10-16','matchups':summary,'units':{'executions':48,'paired_seed_blocks':24,'numeric_seed_values':8,'source_beasts':3,'ED_source_candidates':3,'fully_integral_character_power_profiles':0,'source_attested_RD_basic_attack_matchups':1,'terminal_contracts':0,'canonical_benchmark_promotions':0},'data_cautions':['R82-M1,M2 Sunarco armor light/medium inconsistent','R82-M3,M4,M5 Gorrok ED identity and untrained Luta virtual','R82-M1,M4 Behemoth Luta0 and control omitted','R82-M5 censored at 60 turns; critical success possible but no victory observed','R82-M6 Raya basic attack only; title (+15) not auto stacked','No teams, no transformation, no active abilities or resource costs actually exercised']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'runs':len(runs),'attacks':len(attacks),'seed_blocks':len(blocks),'matchups':len(matchups),'grid_primary_slots':len(slots),'archetype_slot_rows':len(role_slots),'team_size_slot_rows':len(team),'science':summary},ensure_ascii=False,indent=2)[:13000])
