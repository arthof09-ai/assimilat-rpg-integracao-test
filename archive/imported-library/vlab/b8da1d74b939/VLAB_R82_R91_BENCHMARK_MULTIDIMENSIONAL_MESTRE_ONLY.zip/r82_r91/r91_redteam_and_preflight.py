"""Isolated adversarial copies only. Never modifies original or pending historical DBs."""
import copy,hashlib,json,shutil,sqlite3,tempfile
from pathlib import Path
from r91_cold_semantic_auditor import audit,ensure,canon,sha
import r82_r91_benchmark_adapter as adapter
R=Path(__file__).resolve().parent
fixture=json.loads((R/'fixture_r82_sources.json').read_text());matchup=fixture['matchups'][0];profile={a:fixture['profiles'][matchup[a]] for a in ('B','E')}

def structural(db):
    with sqlite3.connect(db) as con:
        meta=dict(con.execute('SELECT key,value FROM meta'));rows=list(con.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq'))
        ensure(len(rows)==int(meta['revision']),'STRUCTURAL_COUNT')
        prev=meta['genesis'];before=None
        for i,cmd_id,p,data,h,b,a in rows:
            row=json.loads(data)
            ensure(i==row['seq'] and cmd_id==row['cmd_id'] and p==row['prev']==prev,'STRUCTURAL_LINK')
            ensure(sha(row)==h and b==row['before_sha'] and a==row['after_sha'],'STRUCTURAL_FIELDS')
            if before:ensure(before==b,'STRUCTURAL_CAUSAL_CHAIN')
            before=a;prev=h
        ensure(prev==meta['head'],'STRUCTURAL_HEAD')
        ensure(sha(json.loads(meta['state']))==rows[-1][-1],'STRUCTURAL_FINAL')
    return True

mutations={
    'FLIP_HIT':lambda a:a.__setitem__('hit',not a['hit']),
    'SCORE_PLUS_1':lambda a:a.__setitem__('score',a['score']+1),
    'RAW_PLUS_1':lambda a:a.__setitem__('damage_raw',a['damage_raw']+1),
    'RD_MINUS_1':lambda a:a.__setitem__('rd',a['rd']-1),
    'HP_AFTER_PLUS_1':lambda a:a.__setitem__('hp_after',a['hp_after']+1),
    'FAKE_PA_SPEND':lambda a:a.__setitem__('pa_spent',1),
    'MOVE_FALSE':lambda a:a.__setitem__('no_movement',False),
    'TAPE_DIE_MOD':lambda a:a['tape'][0]['dice'].__setitem__(0,(a['tape'][0]['dice'][0]%6)+1),
}

def adversarial():
    root=R/'redteam';root.mkdir(exist_ok=True)
    orig=R/'runs'/matchup['id']/'R82BENCH_382101_B_LEFT.sqlite'
    out=[]
    for name,mutation in mutations.items():
        db=root/f'ADV_{name}.sqlite';ensure(not db.exists(),'DO_NOT_REPEAT_ADVERSARIAL')
        shutil.copy2(orig,db);shutil.copy2(orig.with_suffix('.genesis.json'),db.with_suffix('.genesis.json'))
        with sqlite3.connect(db) as con:
            rows=[json.loads(a[0]) for a in con.execute('select row_json from events order by seq')]
            attack_row=next(r for r in rows if r['kind']=='NORMAL_ATTACK');mutation(attack_row['detail']['attack'])
            prev=dict(con.execute('SELECT key,value FROM meta'))['genesis']
            for row in rows:
                row['prev']=prev
                digest=sha(row)
                con.execute('UPDATE events SET row_json=?,row_sha=?,prev=? WHERE seq=?',(canon(row),digest,prev,row['seq']))
                prev=digest
            con.execute("UPDATE meta SET value=? WHERE key='head'",(prev,))
        structural(db)
        rejected=False;error=''
        try:audit(db,profile)
        except Exception as e:rejected=True;error=str(e)
        ensure(rejected,'REDTEAM_FALSE_NEGATIVE_'+name)
        out.append({'mutation':name,'archive_chain_valid':True,'semantic_rejected':True,'reason':error,'artifact':db.name})
    return out

def preflight():
    root=R/'evidence';root.mkdir(exist_ok=True);db=root/'R82_COMMAND_REJECTION_UNIT.sqlite'
    ensure(not db.exists(),'NO_REPEAT_PREFLIGHT')
    adapter.configure(matchup);adapter.start(db,383101,'B_LEFT')
    adapter.commit(db,'INIT',{'operation':'INIT'},adapter.do_init)
    s,head,rev=adapter.core.load(db)
    active=s['active'];other='E' if active=='B' else 'B'
    bads=[('WRONG_TARGET',{'actor':active,'target':active,'reaction':'NONE'}),
          ('WRONG_ACTOR',{'actor':other,'target':active,'reaction':'NONE'}),
          ('UNAUTH_REACTION',{'actor':active,'target':other,'reaction':'COUNTER'}),
          ('UNKNOWN_KEY',{'actor':active,'target':other,'reaction':'NONE','free_hit':True})]
    res=[]
    for name,p in bads:
        try:adapter.commit(db,'NORMAL_ATTACK',p,adapter.do_attack);raise AssertionError('UNEXPECTED_ACCEPT_'+name)
        except adapter.Deny as e:res.append({'case':name,'blocked':str(e)})
        ensure(adapter.core.load(db)==(s,head,rev),'UNEXPECTED_PREVALIDATION_EFFECT')
    adapter.commit(db,'NORMAL_ATTACK',{'actor':active,'target':other,'reaction':'NONE'},adapter.do_attack)
    s,head,rev=adapter.core.load(db)
    try:adapter.commit(db,'NORMAL_ATTACK',{'actor':active,'target':other,'reaction':'NONE'},adapter.do_attack);raise AssertionError('ACCEPTED_DOUBLE_ACTION')
    except adapter.Deny as e:res.append({'case':'SECOND_STANDARD_SAME_TURN','blocked':str(e)})
    ensure(adapter.core.load(db)==(s,head,rev),'SECOND_ACTION_EFFECT')
    with sqlite3.connect(db) as con:ensure(con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0,'PREVALIDATION_LEFT_PENDING')
    return res

if __name__=='__main__':
    results={'mutations':adversarial(),'pre_intent_rejections':preflight(),'original_history_mutations':0}
    (R/'R91_ADVERSARIAL_AUDIT.json').write_text(canon(results)+'\n')
    print(json.dumps({'mutations':len(results['mutations']),'pre_intent':len(results['pre_intent_rejections']),'all_pass':True}))
