import json,csv,hashlib,collections,statistics
from pathlib import Path
R=Path(__file__).resolve().parent
old=json.loads((R.parent/'r72_r81'/'R81_17_CONTRACTS_RECONCILED.json').read_text())
cold=json.loads((R/'R91_COLD_AUDIT_CORRECTED.json').read_text())
science=json.loads((R/'R90_MULTIDIMENSIONAL_SCIENCE.json').read_text())
assert len(old['contracts'])==17
exp={
'BATTLE_1X1_2X1_20X20':'48 selected 1x1 mirror runs across 6 distinct matchups, 24 paired blocks, 40 finishes and 8 censures. Group 2x1 and 20x20 not exercised; 40 ID-collision runs excluded.',
'ED_VS_BE_DAMAGE':'3 physically reopened Besta profiles x 3 ED candidate profiles; 884 source-bound attack receipts, 224 hits across 48 accepted-identifier LAB runs. Only M6 has ED RD14 explicitly in sheet; reduced H attack, no integral build claim.',
'GENERAL_SPECIFIC_RD':'Beasts Bron5 RD5, Ouro normal RD25 and Titã Ouro RD45 by current Criação de Besta; Gorrok natural physical RD15; Raya physical armor RD14; Sunarco RD5 equipment conditional light-v-medium conflict. No general-specific stacking authority tested.',
'RNG_REPLAY_STATISTICS':'48/48 full-state cold replays, 1,824 events, 24 pair mirrors, 8 censored runs (4 independent seed blocks); old colliding RUN-ID batch quarantined, new identifiers unique.',
'SOURCE_FREEZE_AND_RANK':'R81 original 90/90 SHA; R82 3 Besta source profiles, 2 explicit ED and one inferred ED source; corrected scheme B27 D27 A25 C25 =104 primary slots; no 27 canonical ranks invented.',
'TACTICAL_AI_AB_FAIRNESS':'Source-label RNG mirrored 24/24 pairs outcomes, HP, events and hits. Fixed adjacent basic-attack policy only; not full adaptive AI or equipment activations.',
'TURN_SCHEDULER_EVENT_SOURCING':'48 valid-ID 1v1 source-bounded ledgers, 1,824 verified causal events, 40 terminal one-survivor and 8 censures; no grouped 2x1 certification.',
'OFFICIAL_QA_NAC_LEDGERS':'8/8 chain-rehashed semantic mutations rejected, 5/5 pre-intent invalid commands without side effects, 48/48 independent replay and SQLite checkpoint readback. No Notion writer/independent official terminal reviewers.',
'ITEM_EQUIPMENT_AND_ENHANCEMENTS':'Raya printed armor RD14 is frozen and applied; Sunarco medium RD5 remains conditional due header disagreement; Gorrok natural RD15 non-item. Equipment changes mid-fight not exercised.',
'PA_AND_PREBUFF_COSTS':'Only basic attack PA0 across all 884 attempts. Source PA balances frozen; no source-attested activation/prebuff PA spending proved in this stage.'}
root={'operation':'OP-VLAB-FUSION-SANDBOX-01','cycle':'R82-R91','baseline':'R81 17-contract original names and history preserved','terminal_certified':0,'official_benchmark_cells':0,'NAC_PASS_PRODUCTION':'HOLD','contracts':[]}
for obj in old['contracts']:
 id=obj['id'];root['contracts'].append({'id':id,'R81_lab_class':obj.get('R81_lab_class'),'R81_delta':obj.get('R72_R81_delta'),'R82_R91_evidence':exp.get(id,'NO_NEW_CONTRACT_WIDE_EVIDENCE: historic R81 baseline remains. Do not infer terminal certificate.'),'terminal_certificate':'HOLD','official_promotion':False,'remaining_gate':obj.get('R81_remaining') or obj.get('terminal_remaining')})
(R/'R91_17_CONTRACTS_RECONCILED.json').write_text(json.dumps(root,ensure_ascii=False,indent=2)+'\n')
lines=['# VLAB R91 — Crosswalk dos 17 contratos originais (MESTRE-SIDE)','', 'Baseline R81 preservada. Nenhum certificado terminal ou célula oficial promovida. Regra autoral de 27 posições operacionais para Bestas incluída sem converter em ranks.','', '| Contrato original R18 | Delta experimental R82–R91 | Certificação |', '|---|---|---|']
for x in root['contracts']:lines.append(f"| {x['id']} | {x['R82_R91_evidence'].replace('|','/')} | HOLD |")
lines.extend(['','## Gates','- 17 contratos conhecidos/17 reconciliados; certificados terminais **0/17**.','- Linhas fonte-admissíveis no banco oficial: **0** (writer/QA/homologação indisponíveis).','- Resultados técnicos: 48/48 auditoria fria; 40 completos/8 censurados; 24/24 pares espelhados consistentes.','- 8/8 mutações semânticas rejeitadas com hash válido; 5/5 pré-validações negadas sem intenção parcial.','- Primeira tentativa R82 40 execuções apresenta 8 RUN-ID duplicados entre 5 matchups: **quarentena experimental**, preservada sem alteração.','- R59/R72 UNKNOWN_EFFECT: NO-RETRY; writer Notion e ACK de Inbox HOLD.'])
(R/'R91_17_CONTRACTS_RECONCILED.md').write_text('\n'.join(lines)+'\n')
print('17 contracts reconciled, report pending')
