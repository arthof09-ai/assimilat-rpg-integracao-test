"""Standalone causal audit of corrected R82 40 + original M6 8; excludes duplicate-ID first 40.
Does not import any executor or historic module; relies on independent R91 semantic auditor.
"""
import json,sqlite3
from pathlib import Path
from r91_cold_semantic_auditor import audit,ensure,canon
R=Path(__file__).resolve().parent
f=json.loads((R/'fixture_r82_sources.json').read_text())
a=json.loads((R/'ADDENDUM_M6_SOURCE_AND_PREREG.json').read_text())
p=json.loads((R/'PREREG_R82_CORRECTED_UNIQUE_RUN_IDS.json').read_text())
executed=json.loads((R/'results_r82_r91_corrected_ids.json').read_text())+json.loads((R/'results_r82_addendum_m6.json').read_text())
all_r=[]
for m in f['matchups']+[a['matchup']]:
    prof={k:(a['profile'] if m[k]==a['profile']['id'] else f['profiles'][m[k]]) for k in ('B','E')}
    seeds=p['new_seeds'] if m['id']!=a['matchup']['id'] else a['seeds']
    for group,cohort in seeds.items():
        for sd in cohort:
            one=[]
            for side in ('B_LEFT','E_LEFT'):
                fp=R/'runs'/m['id']/f'R82BENCH_{sd}_{side}.sqlite'; cp=fp.with_suffix('.checkpoint.sqlite')
                with sqlite3.connect(fp) as con,sqlite3.connect(cp) as backup:
                    ensure(con.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLITE_CORRUPT')
                    for table in ('meta','events','pending'):
                        ensure(con.execute('SELECT * FROM '+table+' ORDER BY 1').fetchall()==backup.execute('SELECT * FROM '+table+' ORDER BY 1').fetchall(),'CP_MISMATCH')
                cold=audit(fp,prof);cold['matchup_id']=m['id'];cold['cohort']=group
                genesis=json.loads(fp.with_suffix('.genesis.json').read_text())
                ensure(genesis['run_id']==f'R82R91_{m["id"]}_{sd}_{side}' or (m['id']==a['matchup']['id'] and genesis['run_id']==f'R82R91_{sd}_{side}'),'UNIQUE_ID_GENESIS')
                ensure(genesis['experiment']['matchup_id']==m['id'] and genesis['source_gate']['admission']==m['admission'],'SOURCE_GATE_MISMATCH')
                one.append(cold);all_r.append(cold)
            ensure(one[0]['winner']==one[1]['winner'] and one[0]['hp_final']==one[1]['hp_final'] and one[0]['attacks']==one[1]['attacks'] and one[0]['hits']==one[1]['hits'] and one[0]['events']==one[1]['events'],'PAIR_MISMATCH')
assert len(all_r)==len(executed)==48
ids=[r['run_id'] for r in executed]
ensure(len(set(ids))==48,'RUN_ID_COLLISION_IN_CORRECTED_SET')
assert sorted((r['seed'],r['side'],r['matchup_id']) for r in executed)==sorted((r['seed'],r['side'],r['matchup_id']) for r in all_r)
out={'status':'PASS_CORRECTED_ID_SET_ONLY','runs':all_r,'valid_runs':len(all_r),'source_real_bestas':3,'source_ED_candidates':3,'matchups':6,'unique_seed_values':len({r['seed'] for r in all_r}),'paired_blocks':len({(r['matchup_id'],r['seed']) for r in all_r}),'events':sum(r['events'] for r in all_r),'attacks':sum(r['attacks'] for r in all_r),'hits':sum(r['hits'] for r in all_r),'completed':sum(r['phase']=='COMPLETE' for r in all_r),'censored':sum(r['phase']=='CENSORED_HORIZON' for r in all_r),'run_ids_unique':True,'legacy_collision_runs_excluded':40,'cold_independent_of_executor':True}
(R/'R91_COLD_AUDIT_CORRECTED.json').write_text(canon(out)+'\n')
print(canon({k:v for k,v in out.items() if k!='runs'}))
