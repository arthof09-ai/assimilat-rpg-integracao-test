# R38 — Reprodução SEM repetir combates

1. Com autorização de leitura Mestre-only, obtenha os arquivos originais: R27 baseline e ZIPs R34, R35, R36, R37 da Biblioteca `/Comestre/OP-VLAB-FUSION-SANDBOX-01`. Não sobrescreva os originais.
2. Coloque-os em `inputs/` com os nomes originais. Crie `work/R34`, `work/R35`, `work/R36`, `work/R37` e extraia o respectivo ZIP em cada pasta.
3. Extraia de R27 somente `reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json` para `work/reconstruction/r18_delivery/`.
4. Rode `python r38_acceptance_3_readonly.py`. O script abre SQLite em modo de leitura; as únicas alterações ocorrem em cópias SQLite temporárias descartáveis durante quatro testes negativos.
5. Compare o arquivo `R38_THREE_CONTRACT_ACCEPTANCE_EVIDENCE.json` gerado com o incluído neste pacote; em caso de divergência marque HOLD.

NÃO execute os scripts de simulação R34–R37, não altere as fichas, não reclassifique os 17 contratos como certificados e não libere produção.
