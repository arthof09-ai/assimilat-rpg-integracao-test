#!/usr/bin/env python3
"""R38 fresh read-only R18 contract-acceptance audit over preexisting R27/R34-R37 artifacts.
No game engine import, no historic fight execution, no modifications to recovered files.
Temporary adversarial SQLite clones only. Output path passed separately.
"""
from __future__ import annotations
import sys,os,json,sqlite3,hashlib,zipfile,shutil,tempfile,collections
from pathlib import Path

ROOT=Path(__file__).resolve().parent
W=ROOT/'work'
IN=ROOT/'inputs'
ORIG={
 'R27':('VLAB_STAGE12_A1A2A3_SCIENTIFIC_BASELINE_R27_SANDBOX.zip','d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1'),
 'R34':('VLAB_R34_PRIMEIRO_COMBATE_COMPLETO_BESTAS_REAIS_MESTRE_ONLY.zip','876236ebb34ee76f514b17d3ff765f32d40e1b8c81ef7f21248e0d34187705bc'),
 'R35':('VLAB_R35_EMPURRAO_GEOMETRIA_COMPARACAO_MESTRE_ONLY.zip','61c952c6d1896845fd2e96433bf65d1986eb313810304e708190109ce3b02413'),
 'R36':('VLAB_R36_ESQUIVA_NATIVA_PAREADA_MESTRE_ONLY.zip','b35f748db057f137a768d50e986037b87b7f8e0b2ddb17a70f23a5b2321506e5'),
 'R37':('VLAB_R37_DESEMPATE_CENSURA_PRONTIDAO_17_MESTRE_ONLY.zip','f741f09937e6b9e7277bcecc5581aed6b4e7b0793750165a72ec8fc79e0b3922'),
}
CONTRACTS=('REACTION_TRIGGER_AND_SINGLE_USE','TURN_SCHEDULER_EVENT_SOURCING','RNG_REPLAY_STATISTICS')
def H(b):return hashlib.sha256(b).hexdigest()
def hs(p):return H(Path(p).read_bytes())
def C(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sh(x):return H(C(x).encode())
def check(ok,label):
 if not ok:raise AssertionError(label)
 return True

def check_archives():
 r=[]
 for key,(name,expected) in ORIG.items():
  p=IN/name
  check(p.is_file(),f'{key} missing');check(hs(p)==expected,f'{key} SHA')
  with zipfile.ZipFile(p) as z:
   check(z.testzip() is None,f'{key} CRC')
   names=z.namelist();check(len(names)==len(set(names)),f'{key} duplicate members')
   if key!='R27':
    mn={'R34':'R34_FILE_MANIFEST.json','R35':'R35_FILE_MANIFEST.json','R36':'R36_FILE_MANIFEST.json','R37':'R37_PACKAGE_MANIFEST.json'}[key]
    m=json.loads(z.read(mn));exp=m.get('files',m.get('file_sha256'))
    check(set(names)==set(exp)|{mn},f'{key} manifest member mismatch')
    for fn,digest in exp.items():check(H(z.read(fn))==digest,f'{key} member corrupt {fn}')
   else:exp={}
  r.append({'archive':key,'sha256':expected,'crc':'PASS','members':len(names),'manifest_hashes_verified':len(exp)})
 return r

def ledger(p):
 uri=f'file:{Path(p).resolve()}?mode=ro'
 with sqlite3.connect(uri,uri=True) as c:
  check(c.execute('PRAGMA integrity_check').fetchone()[0]=='ok',f'integrity {p}')
  check(c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0,f'pending {p}')
  meta=dict(c.execute('SELECT key,value FROM meta'))
  rows=c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
 state=json.loads(meta['state']); old=meta['genesis'];before=None;out=[]
 for ix,(seq,cmd,prev,src,digest,bef,aft) in enumerate(rows,1):
  d=json.loads(src)
  check(seq==ix==d['seq'] and cmd==d['cmd_id'] and prev==old==d['prev'],f'chain seq {p}:{ix}')
  check(sh(d)==digest and bef==d['before_sha'] and aft==d['after_sha'],f'row sha {p}:{ix}')
  if before is not None:check(bef==before,f'state bridge {p}:{ix}')
  check(d['official_effects']==0,f'official-effects {p}:{ix}')
  check(d['detail'].get('world_effects',0)==0,f'world-effects {p}:{ix}')
  old=digest;before=aft;out.append(d)
 check(int(meta['revision'])==len(rows),f'revision {p}')
 check(meta['head']==old,f'head {p}')
 if rows:check(sh(state)==before,f'state sha {p}')
 check(state.get('source_status')=='SOURCE_REAL_READONLY_ISOLATED_SANDBOX',f'source isolation {p}')
 return {'path':str(p),'revision':len(rows),'head':meta['head'],'state':state,'events':out,'pending':0}

def inspect_scenes():
 allrun=[];count=collections.Counter();backups=0
 for k in ('R34','R35','R36','R37'):
  root=W/k
  for db in sorted((root/'runs').glob('*.sqlite')):
   # R35 bundles a READ-ONLY R34 reference DB: do not count or execute it twice.
   if k=='R35' and db.name.startswith('R34_'):continue
   # R36 aborted pre-event is independently examined by the archived R36 verifier.
   if k=='R36' and 'SEED421' in db.name:continue
   d=ledger(db);count['scenes']+=1;count['events']+=d['revision']
   st=d['state'];count['source_id_count']+=len(st['actors'])
   for actor in st['actors'].values():
    check(actor.get('source_page_id') in ['391c2b32-4ede-8252-b0cc-810423cdbfa6','f0dc2b32-4ede-820a-b947-0168d4a53315','eddc2b32-4ede-829f-8a75-011e8acbf429'],f'bad beast origin {db}')
   if k in ('R36','R37'):
    for actor in st['actors'].values():check(actor['resource']['reflex']==6,f'reflex authority {db}')
   checkpoint = {'R34':'R34_FULL_FIGHT_SEED347.sqlite','R35':db.stem+'_BACKUP.sqlite','R36':db.stem+'_BACKUP.sqlite','R37':db.stem+'_backup.sqlite'}[k]
   cp=root/'checkpoints'/checkpoint
   check(cp.exists(),f'checkpoint missing {cp}')
   b=ledger(cp);backups+=1
   check(b['state']==d['state'] and b['events']==d['events'] and b['head']==d['head'],f'checkpoint diverged {db}')
   saw_init=False;last_actor=None;last_round=0
   for ev in d['events']:
    kind=ev['kind'];dt=ev['detail']
    if 'INIT' in kind:
     check(not saw_init,f'multiple init {db}');saw_init=True;count['initiatives']+=1
     continue
    if 'CENSOR' in kind:
     check(st['winner'] is None and st['phase'].startswith('CENSORED'),f'fake winner {db}');count['censors']+=1
     continue
    count['attacks']+=1
    n=dt['native']
    e=n.get('effect') or n.get('native_effect') or n.get('attack_native_event')
    check(e is not None and e['engine']=='COMBAT-EFFECT-ADAPTER-PARTIAL-v0.8',f'not native {db}')
    check(e['official_death_derived'] is False and e['status']=='LAB-STOP-HP0-NOT-CANON',f'not sandbox {db}')
    check(e['roll_score']>=0 and e['net']>=0,f'bad score/damage {db}')
    check(e['hit']==(e['roll_score']>int(e['ca_exact'])),f'CA strict comparison {db}')
    if e['defense_negated']:
     check(e['defensive_reaction']=='ESQUIVAR' and e['net']==0,f'negated damage {db}')
    check(e['after_hp']==max(0,e['before_hp']-e['net']),f'HP ledger {db}')
    actor=e['from'];target=e['to'];check(actor!=target,f'self-hit {db}')
    if k in ('R36','R37'):
     r=n.get('reaction_native_event')
     if r:
      count['reactions']+=1
      check(r['by']==target and r['action']=='ESQUIVAR' and r['consumes_reaction'] is True and r['source']=='BEFORE-ATTACK',f'reaction trigger {db}')
      check(r['defense_exact']=='26' and r['damage_negated'] and e['net']==0,f'reaction defense {db}')
      check(e['roll_score']<=26,f'reaction tie boundary {db}')
     else:check(e['defensive_reaction'] is None,f'unbacked reaction {db}')
    refresh=(dt.get('reaction_refresh_native_R26') if k=='R34' else dt.get('reaction_refresh_R26'))
    transition=dt.get('transition_R18') or dt.get('advance_native_R18')
    check(transition is not None,f'no scheduler transition {db}')
    if transition.get('probe_only'):
     check(k=='R35' and d['revision']==1,f'nonisolated probe {db}')
     count['isolated_probes']+=1
    elif transition.get('end') or transition.get('combat_ended'):
     check(dt['phase_after'].startswith('COMPLETE_'),f'unexpected terminal event {db}')
     count['terminal_ends']+=1
    else:
     check(refresh is not None and refresh['trigger']=='OWN_TURN_START' and refresh['after']==1 and refresh['before'] in (0,1) and refresh['no_stockpiling'],f'refresh rule {db}')
     check(transition['turn_end']==actor and transition['reaction_auto_refresh'] is False,f'turn scheduler {db}')
     count['turn_transitions']+=1
    if last_actor is not None and len(st['actors'])==2:check(last_actor!=actor,f'nonalternating turn {db}')
    last_actor=actor
   check(saw_init or (k=='R35' and d['revision']==1),f'no initiative {db}')
   allrun.append({'archive':k,'scene':db.name,'events':d['revision'],'attacks':sum('INIT' not in e['kind'] and 'CENSOR' not in e['kind'] for e in d['events']),'reactions':sum(bool(e['detail'].get('native',{}).get('reaction_native_event')) for e in d['events'])})
 count['checkpoints']=backups
 check(count['scenes']==23,f'scene count {count}')
 check(count['events']==184,f'event count {count}')
 check(count['reactions']==40,f'reaction count {count}')
 check(count['initiatives']==18,f'initiative count {count}')
 check(count['censors']==2,f'censor count {count}')
 check(count['attacks']==164,f'attack count {count}')
 return {'counts':dict(count),'scenes':allrun}

def actor_stream(led):
 m=collections.defaultdict(list)
 for ev in led['events']:
  if ev['kind']!='R37_NATIVE_TURN':continue
  q=ev['detail']['dice']
  m[q['actor']].append((q['own_attack_index'],q['hit_die'],q['damage_die'],tuple(q['crit_dice'])))
 return m

def verify_rng_pairs():
 cases=[]
 for seed in (503,509):
  a=actor_stream(ledger(W/'R37/runs'/f'R37_{seed}_DECLINE.sqlite'))
  b=actor_stream(ledger(W/'R37/runs'/f'R37_{seed}_EVADE_EVERY_INCOMING.sqlite'))
  for actor in sorted(a):
   n=min(len(a[actor]),len(b[actor]));check(n>0,f'empty actor stream {seed}')
   check(a[actor][:n]==b[actor][:n],f'RNG actor stream differs {seed}:{actor}')
   cases.append({'seed':seed,'actor':actor,'prefix_len':n,'match':True,'stream_prefix':a[actor][:n]})
 return {'paired_prefix_matches':len(cases),'cases':cases,'note':'actor-local RNG, not a canonical dice-source or independent statistical holdout'}

def adversarial_clones():
 src=W/'R37/runs/R37_503_EVADE_EVERY_INCOMING.sqlite';results=[]
 with tempfile.TemporaryDirectory(prefix='r38_tests_only_') as td:
  for attack in ('alter_payload','alter_head','invent_pending','reuse_cmd_id'):
   tgt=Path(td)/(attack+'.sqlite');shutil.copy2(src,tgt)
   if attack=='alter_payload':
    with sqlite3.connect(tgt) as c:
     row=c.execute('SELECT row_json FROM events WHERE seq=3').fetchone()[0]
     corrupted=json.loads(row);corrupted['detail']['world_effects']=1
     c.execute('UPDATE events SET row_json=? WHERE seq=3',(C(corrupted),))
   elif attack=='alter_head':
    with sqlite3.connect(tgt) as c:c.execute("UPDATE meta SET value='incorrect_head' WHERE key='head'")
   elif attack=='invent_pending':
    with sqlite3.connect(tgt) as c:c.execute("INSERT INTO pending VALUES('LAB-CMD-BAD','bad_head','ATTACK','{}')")
   else:
    with sqlite3.connect(tgt) as c:
     first=c.execute('SELECT * FROM events LIMIT 1').fetchone()
     try:c.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?)',(999,first[1],*first[2:]));pass_flag=False
     except sqlite3.IntegrityError:pass_flag=True
     check(pass_flag,'duplicate cmd uniqueness failed')
   if attack!='reuse_cmd_id':
    denied=False
    try:ledger(tgt)
    except AssertionError:denied=True
    check(denied,f'not fail-closed {attack}')
   results.append({'negative_test':attack,'source':'temporary clone only','status':'PASS'})
 return results

def contracts():
 mat=json.loads((W/'reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json').read_text())
 check(mat['denominator']==17 and len(mat['rows'])==17,'R18 matrix denominator')
 rows={r['contract_id']:r for r in mat['rows']}
 check(len(rows)==17 and set(CONTRACTS)<=set(rows),'IDs')
 extras={
  'REACTION_TRIGGER_AND_SINGLE_USE':{
    'bounded_pass':['40 native ESQUIVAR callbacks validated','40 native BEFORE-ATTACK reaction receipts, defense26 and consumption','R26 own-turn refresh observed, no stockpiling','4 tie-boundary native old fixtures and 13 R36 guard tests previously reported'],
    'missing':['MULTI_TRIGGER_INTERRUPTS_AND_NORMATIVE_PRECEDENCE in original R18 gate','simultaneous reactions/Defender with complete real source and independent reviewer','applicable NAC-PASS-02 terminal'],
  },
  'TURN_SCHEDULER_EVENT_SOURCING':{
    'bounded_pass':['23 chains with R26 initiative start','159 alternating native turns and own-turn reaction renewal','2 analytical censor end states do not invent game winner','R18 chain and SQLite rollback protections'],
    'missing':['CANON_INITIATIVE_TIE_INTERRUPTION_AND_SOURCE_COMPLETE_EVENTS original gate','multi-actor interruptions and complete source-authenticated actions','independent reviewer + NAC-PASS-02 terminal'],
  },
  'RNG_REPLAY_STATISTICS':{
    'bounded_pass':['23 run ledgers and 23 independent backup logical mirrors','all R34–R37 archived manifest SHA+CRC','two pairs/four actor-local RNG prefixes identical','read-only tamper/duplicate/pending negative cloned tests'],
    'missing':['CANONICAL_DICE_SOURCE_AND_STATISTICAL_HOLDOUT original gate','external statistical holdout and independent reviewer','applicable NAC-PASS-02 terminal'],
  }
 }
 return {k:{'original_r18_gate':rows[k]['original_acceptance_still_required'],'r18_prior_state':rows[k]['terminal_after'],'r38_bounded_lab_subtests':'PASS','bounded_evidence':extras[k]['bounded_pass'],'terminal_missing':extras[k]['missing'],'terminal_certification':'HOLD','nac_pass_02':'HOLD'} for k in CONTRACTS}

def main():
 archive=check_archives()
 scenes=inspect_scenes()
 rng=verify_rng_pairs()
 negatives=adversarial_clones()
 cr=contracts()
 out={'schema':'R38_READONLY_THREE_CONTRACT_ACCEPTANCE_V1','operation':'OP-VLAB-FUSION-SANDBOX-01','source':'preserved R18/R27 and R34-R37 bytes, direct read-only independent audit; NOT original replay rerun','archive_gates':archive,'scene_integrity':scenes,'rng_pairing':rng,'adversarial_guards':negatives,'contracts':cr,'formal_terminal_certified_before':0,'formal_terminal_certified_after':0,'canonical_campagin_mutations':0,'terminal_NAC_PASS':'HOLD','writer':'HOLD','result':'BOUNDED_LAB_EVIDENCE_VERIFIED_TERMINAL_HOLD'}
 output=ROOT/'R38_THREE_CONTRACT_ACCEPTANCE_EVIDENCE.json';output.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'result':out['result'],'archives':len(archive),'source_scenes':scenes['counts'],'rng_prefixes':len(rng['cases']),'adversarial':len(negatives),'contracts':list(cr),'terminal':0},indent=2))
if __name__=='__main__':main()
