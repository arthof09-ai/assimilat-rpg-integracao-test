# R38 — Prova de aceitação dos três contratos VLAB mais maduros

**CM-000006 · OP-VLAB-FUSION-SANDBOX-01 · MESTRE-ONLY · 15/10/2026**

## 1. Regra da auditoria

- Nenhum combate antigo foi reexecutado, nenhum evento foi retransmitido ao motor, nenhum SQLite de R34–R37 foi modificado.
- O auditor independente R38 leu a matriz **R18 original**, arquivada no R27, e inspecionou diretamente os bancos e recibos persistidos nas entregas R34–R37.
- Os quatro testes adversariais mutaram **somente cópias temporárias**, descartadas após o teste.
- Verificador de hashes/CRC e reabertura SQLite comprova **integridade**. NÃO substitui revisão mecânica independente por outro agente, paridade com histórico v0.9, homologação produtiva ou NAC-PASS terminal.

## 2. Resultado material novo — rechecagem cruzada

| Unidade | Prova R38 |
|---|---:|
| ZIPs históricos verificados por SHA e CRC | 5/5 (R27, R34–R37) |
| Cenas/bancos originais terminados ou censurados/sondas | 23 |
| Checkpoints lógicos reabertos | 23/23 |
| Eventos transacionais com cadeia íntegra | 184 |
| Iniciativas documentadas | 18 |
| Ataques nativos em recibos | 164 |
| Reações ESQUIVAR nativas e antes do ataque | 40 |
| Transições normais de turno examinadas | 143 |
| Términos normais de luta | 16 |
| Sondas isoladas sem iniciativo completa | 5 |
| Censuras de observação sem vencedor | 2 |
| Prefixos actor-local RNG iguais entre políticas | 4/4 |
| Testes adversariais em clones | 4/4 |

**Denominadores separados:** 23 cenas = 16 combates completos + 2 observações censuradas + 5 sondas. A cópia R34 incorporada no ZIP R35 foi deliberadamente excluída da nova contagem. R36 incluiu ainda uma tentativa abortada antes de qualquer evento, validada pelo verificador preservado e excluída das 23 cenas.

## 3. Crosswalk do gate original para a prova disponível

| Contrato | Escopo experimental revalidado | Falta para terminal |
|---|---|---|
| `REACTION_TRIGGER_AND_SINGLE_USE` | 40 Esquivas antes do ataque, custo de 1 Reação, defesa 26, renovação R26 e sem estoque de slots | `MULTI_TRIGGER_INTERRUPTS_AND_NORMATIVE_PRECEDENCE` completo; concorrência/defesas adicionais; revisão independente e NAC-PASS |
| `TURN_SCHEDULER_EVENT_SOURCING` | R18 com 143 transições, 18 iniciativas, 16 finais legítimos e 2 censuras sem vencedor | `CANON_INITIATIVE_TIE_INTERRUPTION_AND_SOURCE_COMPLETE_EVENTS`, cenários multiator/interrupções e revisão independente |
| `RNG_REPLAY_STATISTICS` | Cadeias+23 backups, actor RNG em quatro prefixos pareados, 5 ZIPs SHA/CRC e quatro adulterações rejeitadas | `CANONICAL_DICE_SOURCE_AND_STATISTICAL_HOLDOUT`, auditoria estatística de holdout e NAC-PASS |

**Estado de cada contrato:** evidência funcional delimitada = PASS; aceitação técnica do contrato inteiro = INCOMPLETA; certificação terminal = HOLD. A matriz não credita qualquer um dos três contratos como certificado.

## 4. Proteções regressivas comprovadas

- Alterar payload de evento sem atualizar cadeia HASH ⇒ reabertura rejeitada.
- Alterar `meta.head` ⇒ reabertura rejeitada.
- Introduzir intenção pendente ⇒ gate de abertura rejeitado.
- Repetir `cmd_id` ⇒ índice UNIQUE SQLite rejeitou o segundo comando.
- Checkpoint é comparado por **estado, eventos e head**, sem exigir hash binário igual a backup SQLite.
- Nenhuma alteração de ficha Notion Mestre, Party, O Primeiro, campanha, DMG-RANK v1.1 ou escritor produtivo.

## 5. Ponto de retomada exato

1. Iniciar `REACTION_TRIGGER_AND_SINGLE_USE`: bateria de interrupções múltiplas e duas ofertas de Reação sobre um slot, priorizando testes de **rejeição** para precedências normativas ainda desconhecidas; só depois obter autoridade e demonstrar resolver sem duplo uso.
2. Em paralelo, `TURN_SCHEDULER_EVENT_SOURCING`: construir cenas teste com empate de iniciativa, 3+ atores e janelas de interrupção **sobre ações fonte-admitidas**; exigir replay e origem sem fixtures no crédito de fontes reais.
3. `RNG_REPLAY_STATISTICS`: pré-registrar holdout independente e prova de origem dos dados; comparar seed por ator e resultados de limites/censura, sem reclassificar as 2 sementes R37 como validação estatística.
4. Cada contrato somente muda de HOLD quando exigir **todos** os critérios da matriz R18, auditoria independente competente e NAC-PASS aplicável; writer/lease/epoch/fencing/GREEN seguem HOLD.

## 6. Preservação e certificação

- 17/17 identificadores canônicos mapeados desde R37; **0/17 terminais certificados** após R38.
- 0/1.875 células canônicas; 0 combates canônicos; 16 combates completos real-fonte em sandbox acumulados, nenhuma nova luta na R38.
- R27 ANTES, R28–R37, seed53 interrompida e UNKNOWN_EFFECT históricos não reexecutados; R38 inspecionou fisicamente SHA/CRC de R27 e R34–R37, enquanto R28–R33 são preservados por não escrita, com leitura independente histórica R37.
- **NAC-PASS-02 terminal: HOLD**; IBX-56 BLOCKED-EXTERNAL; nenhum ACK presumido.

## 7. Reprodução

Ao lado deste laudo estão `R38_THREE_CONTRACT_ACCEPTANCE_EVIDENCE.json` (todas as verificações, arquivos e contadores) e `r38_acceptance_3_readonly.py`. O script exige apenas Python stdlib e os ZIPs originais R27/R34/R35/R36/R37; execute após a extração conforme `README_R38.md`. Não execute scripts `run_full_fight_*` dos pacotes históricos.
