# R238 — Auditoria cruzada R234–R237 × cinco baterias R91

**CM-000006 · OP-VLAB-FUSION-SANDBOX-01 · MESTRE-SIDE TEST · 21/10/2026**

## Objetivo e escopo
Retomar a partir de R237 sem repetir cenas históricas; confrontar quatro arquivos de evidência recuperados da Biblioteca Mestre, verificar integridade, recuperabilidade e estatuto de fontes, atualizar prontidão das baterias A–E.

## Procedimento fisicamente executado
1. Consulta à Biblioteca Mestre encontrou R234, R235, R236 e R237, que não constavam do último consolidado R229–R233. Preflight evitou colisão e duplicação.
2. Recuperados os quatro ZIPs e quatro PSVs da Biblioteca, com IDs reais; CRC PASS em todos.
3. Extraídos em quatro diretórios limpos e executados os verificadores portáteis de recuperação fria, cada qual revalidando manifestos e auditorias READ-ONLY, sem replay de seeds.
4. Confrontadas fontes e lacunas das cinco baterias em CSV anexo; criada matriz de proveniência SHA-256 dos quatro ZIPs e PSVs.

## Evidência observada
- R234: 297 hashes, 8 SQLite R18, 120 commits, 500 eventos; 1×1/2×1 com Bestas VZ PRECREATE de estatísticas completas.
- R235: 311 hashes, 196 commits, 816 eventos; fatorial físico/magia/RD e salvaguardas, inclusive metade ímpar arredondada para baixo.
- R236: 303 hashes, 12 braços, 59 commits, 264 eventos; Fraco e HP0 em fixtures TEST.
- R237: 299 hashes, 8 braços, 155 commits, 640 eventos; transição real Normal→Fraco, sem KO canônico inventado.
- Nenhuma luta histórica reexecutada; nenhuma ficha, Party, O Primeiro, produção ou norma escrita.

## Limites científicos
A/B/C/D possuem resultados exploratórios, mas não se transformam automaticamente em células oficiais. PRECREATE ≠ P4. E continua sem chassi P4 demonstrado para contraste físico idêntico com/sem magia. Os 0/17 contratos e 0/1875 células permanecem HOLD. Somar commits de arquivos não equivale a somar combates independentes; a comparação de políticas exige pareamento adequado.

## LAST-VERIFIED / FIRST-PENDING
**LAST-VERIFIED-UNIT:** R238, auditoria cruzada de recuperação fria R234–R237, quatro pacotes CRC e quatro verificadores PASS, CSV R91 produzido.
**FIRST-PENDING:** selecionar fonte P4 integral para B/D e item P4 físico/mágico para E; investigar controle com duração e escape; produzir novo combate integrado com alvo e suporte, não repetir ensaios básicos já demonstrados. Verificar governança/autoridade antes de qualquer escrita no Notion.

**Gate local:** PASS para integridade e mapeamento; **gate global:** HOLD. Nenhuma certificação terminal reivindicada.
