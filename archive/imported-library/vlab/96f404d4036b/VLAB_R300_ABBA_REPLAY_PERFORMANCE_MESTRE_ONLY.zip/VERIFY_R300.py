from pathlib import Path
from hashlib import sha256
import json
R=Path(__file__).resolve().parent
m=json.loads((R/'SHA256_MANIFEST_R300.json').read_text())
actual={str(x.relative_to(R)) for x in R.rglob('*') if x.is_file() and x.name not in ('SHA256_MANIFEST_R300.json','VERIFY_R300.py')}
assert actual==set(m)
for k,h in m.items():assert sha256((R/k).read_bytes()).hexdigest()==h,k
print('PASS_R300_ABBA_SHA',len(m))
