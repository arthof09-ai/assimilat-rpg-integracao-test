# VLAB R300 — Controle emparelhado da otimização R299 (MESTRE-ONLY / TEST)

**Objetivo:** tornar a atribuição do ganho a R299 verificável, sem alterar mecânica, fontes canônicas ou motor. R300 é uma unidade de **medição**, não outro patch.

## Antes / depois físico

Foram comparadas duas cópias R296: **111 módulos Python comuns**, e **apenas** `fusion_stage12/vlab_r21_dynamic_a1.py` diferente — antiga vs R299. As fontes R22/R289-R295/R296 preservam seus hashes; os resultados de R299 são mantidos em pacote independente.

## Medição controlada

Quatro sementes fixadas (30001–30004), 12 ações `PASS` por semente e braço (48 por versão, 96 decisões observadas). A ordem foi alternada A/B e B/A. Tempos cumulativos da chamada de decisão: base **26.082s**, otimização **22.627s**. Redução agregada observada **13.25%**. Todos os quatro pares foram favoráveis à cópia otimizada; os dados brutos estão em oito JSONs separados.

**Perfil adicional, uma semente 30005 com oito PASS por versão**: `_fresh`: 75 vs 67 invocações; `verify_pins`: 8.089 vs 7.313; scheduler `step`: 992 vs 896. O tempo `cProfile` inclui instrumentação e não é latência humana. A redução de invocações está alinhada à alteração de R299, sem afirmar causalidade estatística generalizada.

**Limites:** n=4 pares, mesmo host/disco, só `PASS`, sem ataques/cura no benchmark de tempo; mudanças de host, seeds, I/O e número de atores podem alterar ou inverter ganhos. Portanto não há CI, nenhuma estimativa confiável de desempenho móvel, nenhuma aprovação canônica ou benefício de combate garantido.

## Regras de segurança e escopo

R299 já passou em teste local 73 históricos+4 adversariais e paridade bytewise num ensaio de 5 decisões; esta unidade R300 mede desempenho adicional. Os hashes locais SHA e perfis são para inspeção do Mestre. **0/17 terminal, 0/1.875 oficial; Notion writer/fencing/GREEN HOLD; Party/O Primeiro NO-WRITE.**

**Próxima candidata R301:** investigar limitação real de perfis longos/recursivos e proposta de reduzir cascatas de checkpoints somente se possível garantir verificação de fonte/replay e idempotência; não alterar o motor por impulso.
