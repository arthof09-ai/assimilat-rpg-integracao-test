"""Independent offline R234-R237 SQLite and ZIP structure cross-check.
Does not import fight engine, does not replay seeds, does not write source DBs.
"""
from pathlib import Path
import hashlib,json,sqlite3,zipfile,collections
ROOT=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()
def fail(s):raise AssertionError(s)

def check():
 p238=next(ROOT.glob('VLAB_R238_*.zip'))
 with zipfile.ZipFile(p238) as z:
  assert z.testzip() is None
  readback=json.loads(z.read('R238_CROSS_READBACK.json'))
  manifest=json.loads(z.read('R238_MANIFEST.json'))
  assert set(manifest)==set(z.namelist())-{'R238_MANIFEST.json'}
  for name,digest in manifest.items():assert sha(z.read(name))==digest,(name,'hash')
 out={'scope':'RECOVERY_REAUDIT_R234_R238_ONLY','mode':'READ_ONLY_NO_REPLAY','source_archive_count':4,'archive_checks':[],'sqlite_scenes':0,'sqlite_integrity_pass':0,'sqlite_pending_zero_count':0,'sqlite_ledger_commit_count':0,'sqlite_events_nested_count':0,'sqlite_state_native_events':0,'sqlite_focus_intent_extra':0,'sqlite_rehash_rows':0,'manifest_member_hashes':0,'source_grade':'VZ-PRECREATE-NOT-P4','global_NAC_PASS':'HOLD','official_terminal_contracts':0,'official_R91_cells':0}
 for r in readback['records']:
  fn=ROOT/r['zip']; b=fn.read_bytes()
  assert sha(b)==r['sha256'] and len(b)==r['bytes'],fn
  with zipfile.ZipFile(fn) as z:
   assert z.testzip() is None
   manifest=json.loads(z.read('SHA256_MANIFEST.json'))['files']
   assert set(manifest)==set(z.namelist())-{'SHA256_MANIFEST.json'}
   assert all(sha(z.read(n))==digest for n,digest in manifest.items())
   out['manifest_member_hashes']+=len(manifest)
  root=ROOT/'extracted'/r['checkpoint']/'evidence'/'db'
  files=sorted(root.glob('*.sqlite'))
  expected={'R234':8,'R235':20,'R236':12,'R237':8}[r['checkpoint']]
  assert len(files)==expected,(r['checkpoint'],len(files),expected)
  r_count={'checkpoint':r['checkpoint'],'zip_sha256':r['sha256'],'manifest_members':len(manifest),'scenes':len(files),'commits':0,'nested_events':0,'state_native_events':0,'focus_intent_extra':0,'integrity_pass':0,'pending_zero':0}
  for file in files:
   # Connect strictly read-only. Never alter the historical evidence.
   con=sqlite3.connect('file:'+file.absolute().as_posix()+'?mode=ro',uri=True)
   try:
    assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok',file
    r_count['integrity_pass']+=1
    assert con.execute('SELECT count(*) FROM pending').fetchone()[0]==0,file
    r_count['pending_zero']+=1
    meta=dict(con.execute('SELECT key,value FROM meta'))
    rows=con.execute('SELECT seq,cmd_id,prev,row_json,row_sha FROM events ORDER BY seq').fetchall()
    head=meta['genesis']
    for i,(seq,cmd,prev,raw,rsha) in enumerate(rows,1):
     assert seq==i and prev==head and sha(raw.encode())==rsha,(file,seq)
     event=json.loads(raw)
     assert event['cmd_id']==cmd and event['prev']==prev and event['seq']==seq,(file,seq,'fields')
     r_count['nested_events']+=len(event.get('detail',{}).get('events_new',[]))
     head=rsha
    assert head==meta['head'],(file,'final head')
    state=json.loads(meta['state'])
    num_native=len(state['native_events'])
    event_detail_count=sum(len(json.loads(row[3]).get('detail',{}).get('events_new',[])) for row in rows)
    extra=num_native-event_detail_count
    assert extra in (0,1),(file,'unexpected event count delta',extra)
    if extra:assert r['checkpoint']=='R235' and 'SAVE_FOCUS' in file.name and state['native_events'][1]['action']=='R235_FROZEN_MAGIC_TAPE',(file,'not documented save focus')
    r_count['focus_intent_extra']+=extra
    r_count['state_native_events']+=num_native
    r_count['commits']+=len(rows)
   finally:con.close()
  out['archive_checks'].append(r_count)
  out['sqlite_scenes']+=r_count['scenes']
  out['sqlite_integrity_pass']+=r_count['integrity_pass']
  out['sqlite_pending_zero_count']+=r_count['pending_zero']
  out['sqlite_ledger_commit_count']+=r_count['commits']
  out['sqlite_events_nested_count']+=r_count['nested_events']
  out['sqlite_state_native_events']+=r_count['state_native_events']
  out['sqlite_focus_intent_extra']+=r_count['focus_intent_extra']
  out['sqlite_rehash_rows']+=r_count['commits']
 assert [a['commits'] for a in out['archive_checks']]==[120,196,59,155]
 assert [a['nested_events'] for a in out['archive_checks']]==[500,812,264,640]
 assert [a['state_native_events'] for a in out['archive_checks']]==[500,816,264,640]
 assert out['sqlite_focus_intent_extra']==4 and out['sqlite_state_native_events']==2220
 assert out['sqlite_scenes']==48 and out['sqlite_ledger_commit_count']==530
 assert out['manifest_member_hashes']==1210
 out['status']='PASS_SQLITE_INTEGRITY_AND_HASH_CHAIN_LOCAL_SCOPE'
 return out
if __name__=='__main__':print(json.dumps(check(),indent=2,ensure_ascii=False))
