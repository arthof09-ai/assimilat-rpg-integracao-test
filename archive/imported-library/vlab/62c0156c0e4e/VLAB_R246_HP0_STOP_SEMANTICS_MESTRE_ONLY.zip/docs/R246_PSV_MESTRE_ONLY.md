PSV — R246 / OP-VLAB-FUSION-SANDBOX-01 / MESTRE-ONLY / TEST / NON-CANON

R246 — Auditoria dos 20 SQLite originais R236/R237; 14 paradas HP0 LAB, 6 censuras; sem turno apos parada; morte e vitoria oficiais NAO demonstradas.

AUTORIA: executor tecnico em sandbox isolada, nao reivindica CM-000006, Instance-ID, lease, epoch, fencing, writer, ou GREEN.

ANTES: ultimo checkpoint historico R243; corpus R01–R243 e motor original preservados.
DEPOIS: resultado restrito aos arquivos e relatorios deste pacote.
NO-WRITE: Party, O Primeiro, fichas, combate, norma, DMG, LEVEL-UP, matrizes oficiais.
NAC-PASS-02: verificacao local dos artefatos e consistencia delimitada; terminal/global = HOLD.
Fonte primaria VLAB: https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2
Plano: https://app.notion.com/p/3f3c2b324ede81d480dbf11732734463
Pasta unica persistente: /Comestre/OP-VLAB-FUSION-SANDBOX-01/

Verificacao portatil: python portable_verify.py VLAB_R246_HP0_STOP_SEMANTICS_MESTRE_ONLY.zip
Sem arquivo ZIP nao confere a execucao real; reports e codigo preservam metodo e resultado.
