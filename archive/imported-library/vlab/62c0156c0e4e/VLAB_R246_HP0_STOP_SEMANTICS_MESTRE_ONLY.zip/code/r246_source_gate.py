#!/usr/bin/env python3
"""R246 independent read-only HP0 semantics audit on R236/R237 source ZIPs."""
import collections,hashlib,io,json,sqlite3,tempfile,zipfile
from pathlib import Path
ROOT=Path('/mnt/data')
OUT=ROOT/'VLAB_R246_HP0_STOP_SEMANTICS_MESTRE_ONLY'
NAMES={'R236':'VLAB_R236_VZ_BEAST_WEAK_HP0_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip','R237':'VLAB_R237_LIVE_FRACO_TRANSITION_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip'}
entries=[]
for stage,name in NAMES.items():
    fn=ROOT/'vlab_recovery'/name
    with zipfile.ZipFile(fn) as z:
        assert z.testzip() is None
        manifest=json.loads(z.read('SHA256_MANIFEST.json'))['files']
        for member,expected_sha in manifest.items():
            assert hashlib.sha256(z.read(member)).hexdigest()==expected_sha,(stage,member)
        result=json.loads(z.read('evidence/reports/'+stage+'_RESULTS.json'))
        dbnames=[p for p in z.namelist() if p.startswith('evidence/db/') and p.endswith('.sqlite')]
        assert len(dbnames)==len(result['results'])
        outcome_index={(x['arm'],x['seed']):x for x in result['results']}
        for member in dbnames:
            # Use ephemeral standalone bytes in memory via SQLite deserialize; source archive never mutated.
            tmp=tempfile.NamedTemporaryFile(suffix='.sqlite')
            tmp.write(z.read(member)); tmp.flush()
            con=sqlite3.connect('file:'+tmp.name+'?mode=ro',uri=True)
            assert con.execute('pragma integrity_check').fetchone()[0]=='ok'
            meta=dict(con.execute('select key,value from meta'))
            state=json.loads(meta['state'])
            rows=[json.loads(x[0]) for x in con.execute('select row_json from events order by seq')]
            scene=state['scene'];keyrows=[x for (a,s),x in outcome_index.items() if a in scene and str(s) in scene]
            assert len(keyrows)==1,(scene,len(keyrows))
            record=keyrows[0]
            assert state['phase']==record['phase']
            assert record['outcome']['official_death'] is False
            assert record['outcome']['official_benchmark'] is False
            assert record['outcome']['source_P4'] is False
            assert state['terminal_contracts']==0 and state['winner'] is None
            assert len(rows)==record['commits']
            assert state['phase'] in ('STOP_HP0_LAB_ONLY','CENSORED_HORIZON')
            phases=[r['detail']['phase'] for r in rows]
            if state['phase']=='STOP_HP0_LAB_ONLY':
                assert state['finish_reason']=='HP0_NOT_CANONICAL_DEATH'
                assert phases.count('STOP_HP0_LAB_ONLY')==1
                assert phases[-1]=='STOP_HP0_LAB_ONLY'
                assert 0 in [x['hp'] for x in state['actors'].values()]
            else:
                assert 'STOP_HP0_LAB_ONLY' not in phases
                assert state['finish_reason']!='HP0_NOT_CANONICAL_DEATH'
            entries.append({'stage':stage,'db':member.split('/')[-1],'phase':state['phase'],'turns':len(rows),'hp0':state['phase']=='STOP_HP0_LAB_ONLY','official_death':False,'official_benchmark':False,'winner':None,'source_P4':False,'source_zip_sha256':hashlib.sha256(fn.read_bytes()).hexdigest()})
            con.close();tmp.close()
counts=collections.Counter(x['phase'] for x in entries)
assert counts=={'STOP_HP0_LAB_ONLY':14,'CENSORED_HORIZON':6},counts
assert len(entries)==20
summary={'status':'PASS_READONLY_HP0_INTEGRITY_WITH_SOURCE_GAP','scenes':len(entries),'by_phase':dict(counts),'official_death':0,'official_benchmark':0,'verified_after_stop_turns':0,'P4_sources':0,'source_semantic_gap':'Criação de Besta Regra 9 and Sistema de Combate Regra 7 do not supply global official death/KO conversion after Vida0','cannot_infer':'official KO or death or winner from STOP_HP0_LAB_ONLY','source_modified':False,'official_cells':0,'terminal_contracts':0,'canonical_writes':0}
(OUT/'reports/R246_SCENE_INDEX_20.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False))
(OUT/'reports/R246_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
print(json.dumps(summary,indent=2,ensure_ascii=False))
