"""R171 experimental, additive causal preflight for the preserved v0.8.1 R50/R51 adapter.
MESTRE-SIDE, no historical edits, no canonical promotion. Preconditions validated before
native effect; snapshots audited by separate test script. Not a substitute for R18 TX.
"""
from vlab_effects_v08 import EffectBlocked, execute_declared_counterattack

def execute_causally_linked_counter(scene, defender_id, attacker_id, *, declaration, incoming, **native_kwargs):
    # Only a live declaration already entered into THIS event log, preceding this
    # NORMAL (never counter/opportunity) attack exactly once, can trigger.
    # Reject BEFORE calling the native mutator if any causal edge fails.
    events=scene.events
    if len(events)<2 or events[-2] is not declaration or events[-1] is not incoming:
        raise EffectBlocked('R171 forged/stale declaration or attack; expected adjacent causal events')
    if declaration.get('seq')!=len(events)-1 or incoming.get('seq')!=len(events):
        raise EffectBlocked('R171 sequence not causally adjacent')
    if declaration.get('attack_origin')!='NORMAL' or incoming.get('attack_origin')!='NORMAL':
        raise EffectBlocked('R171 counter chains and AoO are not eligible original attacks')
    if declaration.get('action')!='COUNTER_DECLARE' or declaration.get('by')!=defender_id or declaration.get('against')!=attacker_id:
        raise EffectBlocked('R171 invalid declaration identity')
    if not declaration.get('before_attack_resolution') or declaration.get('consumes_reaction') is not True:
        raise EffectBlocked('R171 declaration not authorized/consuming')
    if incoming.get('action')!='weapon_attack' or incoming.get('from')!=attacker_id or incoming.get('to')!=defender_id:
        raise EffectBlocked('R171 invalid original attack linkage')
    # Guard against an event body changed after being appended without rechecking.
    if scene.actors[defender_id].reaction!=0:raise EffectBlocked('R171 declaration did not consume reaction')
    if any(e.get('action') in ('COUNTER_RESPONSE','COUNTER_NO_RESPONSE') and e.get('declaration_seq')==declaration['seq'] for e in events):
        raise EffectBlocked('R171 duplicated counter response')
    res=execute_declared_counterattack(scene,defender_id,attacker_id,declaration=declaration,incoming=incoming,**native_kwargs)
    # Add causal correlation solely to the newly made experimental event.
    res['declaration_seq']=declaration['seq']
    res['original_attack_seq']=incoming['seq']
    return res

def independent_validate_chain(events):
    """Independent (no native mutator) typed-trace checks, with negative-test support."""
    by_seq={}
    used_declarations=set()
    for i,e in enumerate(events,1):
        if e.get('seq')!=i:raise AssertionError('SEQ')
        by_seq[i]=e
        if e.get('action') in ('COUNTER_RESPONSE','COUNTER_NO_RESPONSE'):
            d=e.get('declaration_seq'); a=e.get('original_attack_seq')
            if not isinstance(d,int) or not isinstance(a,int) or a!=d+1 or i!=a+1:
                raise AssertionError('CHAIN_ADJACENCY')
            if d in used_declarations:raise AssertionError('DOUBLE_RESPONSE')
            dec=by_seq.get(d);atk=by_seq.get(a)
            if not dec or dec.get('action')!='COUNTER_DECLARE' or dec.get('consumes_reaction') is not True:
                raise AssertionError('NOT_DECLARED')
            if not atk or atk.get('attack_origin')!='NORMAL' or atk.get('action')!='weapon_attack':
                raise AssertionError('NOT_NORMAL_ORIGIN')
            if dec.get('by')!=atk.get('to') or dec.get('against')!=atk.get('from'):
                raise AssertionError('DIRECTION')
            if e.get('action')=='COUNTER_RESPONSE' and atk.get('hit') is not False:
                raise AssertionError('RESPONSE_TO_HIT')
            if e.get('action')=='COUNTER_NO_RESPONSE' and atk.get('hit') is not True:
                raise AssertionError('NO_RESPONSE_TO_MISS')
            used_declarations.add(d)
    return {'events':len(events),'counter_responses':len(used_declarations),'causal_trace':'PASS'}
