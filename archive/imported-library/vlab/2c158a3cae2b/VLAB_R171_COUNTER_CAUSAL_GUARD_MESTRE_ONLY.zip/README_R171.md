# PSV — R171 counterattack causal guard (MESTRE-SIDE)

OPERATION: OP-VLAB-FUSION-SANDBOX-01 (existing). This is an **additive local prototype**, not an original-engine replacement, canonical rule, official duel or official benchmark. No Notion/Party writes.

## Baseline and provenance
- Recovered R170 ZIP, SHA256 `ab34cad5a0b26455f9a0ad659735867fa3a9a430e526e08fa2dcd6a13b776ed0`, 150 entries, 149 SHA manifest records, cold auditor PASS.
- Existing `r161_r170/native_v081_controlled/vlab_effects_v08.py` R50/R51 adapters **reused unchanged**. New wrapper imports its existing `execute_declared_counterattack`, not a parallel damage/roll resolver.
- Normative source (read-only): [R50/R51 decision in VLAB OP](https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2) as of 2026-10-16. Actual test fixture fingerprints do **NOT** certify a full legal creature or independent rule freeze.

## New, narrowly proven capacity
- Before executing counter effects, guard checks live same-scene declaration and immediately succeeding original `NORMAL` attack event, monotonic sequence, actor direction, consumed reaction and no duplicate response.
- Prevents replay of stale/forged declaration or counter-chain response before invoking native effect. Links accepted response to original declaration/attack by sequence number.
- Independent read-only trace check detects provenance/causal mismatches, duplicate chain responses and improper responses to hit.
- Explicit R50/R51 checks: miss eligible; hit or hit-with-zero-damage ineligible; nested counter denied; single use; later distinct normal attack can counter in simplified fixture.
- **Scope caveat:** seven unit/integration checks with `R171-ENGINE-INTEGRATION-SYNTHETIC` actors, mock fixture source-pointer, fixed dice input, and no physical R18 transaction of the new adapter; no native scheduler proof, no blind holdout, no full fight, no source-complete actors, no official cell.

## Reproduce
1. Recover and verify original R170 ZIP from Library without changing it. Extract it to an empty directory and retain `r161_r170/native_v081_controlled` (including module dependencies).
2. Put the `R171_counter_causal_guard` folder next to an extracted `work` directory, or adjust the single import path line in the test script to reference the R170 controlled-native folder; do **not** edit the original native files.
3. Execute `python test_r171_counter.py` from the R171 folder (Python 3.11+). Expected: `Ran 7 tests ... OK`.
4. Check `R171_REPORT.json` and `R171_SHA256_MANIFEST.json` against the immutable delivery ZIP. The manifest covers every other ZIP member.

## Safety and gates
- R163 `FRESH_AFTER_INTENT`, R165 V2, R166 V1, R169 WAL V1, and all historical unknown-effect remain HOLD: none replayed.
- CM-000006-I0001 is candidate/not consumed; Notion writer/lease/epoch/fencing/GREEN unverified and NOT claimed.
- Contract `REACTION_TRIGGER_AND_SINGLE_USE` has additional technical evidence only; `0/17` terminal certification remains, benchmarks `0/1875` official.
- NAC-PASS technical limited to local test and package integrity. Independent external audit, R18 transactional integration, precedence beyond documented R50/R51 and full certification remain PENDING.
