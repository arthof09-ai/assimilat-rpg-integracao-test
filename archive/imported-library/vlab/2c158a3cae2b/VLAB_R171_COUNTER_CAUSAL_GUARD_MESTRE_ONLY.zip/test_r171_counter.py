import sys,unittest,json,hashlib,copy
from fractions import Fraction
from dataclasses import asdict
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'work/r161_r170/native_v081_controlled'))
from vlab_effects_v08 import Scene,Combatant,AbilitySource,ActorActionState,FrozenRuleEvidence,EffectBlocked,declare_counterattack,apply_weapon_attack,Resistances
from r171_counter_causal import execute_causally_linked_counter,independent_validate_chain
PAGE='https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2'
# Integrity of a TEST FIXTURE evidence pointer; not an independent signed source snapshot.
PROOF=FrozenRuleEvidence(PAGE,'R50-R51-TEST-FIXTURE',hashlib.sha256(b'R50-R51 controlled synthetic fixture').hexdigest(),'2026-10-17','R171-TEST-FIXTURE-NOT-PHYSICAL-AUDIT')
SRC=AbilitySource('r171-counter','reaction','REACTION',PAGE,'R50-R51-TEST-FIXTURE','RULE-DERIVED',target_scope='SELF',reaction_trigger='ATTACK_DECLARED',effect_adapter_ready=True,effect_adapter_id='V08-R50-R51')
ATT=AbilitySource('r171-attack','attack','STANDARD',PAGE,'R50-R51-TEST-FIXTURE','RULE-DERIVED',effect_adapter_ready=True,effect_adapter_id='V08-ATTACK')

def scene():
 return Scene({'A':Combatant('A',100,120,Fraction(20),5,0,0,2,'A',maximum_hp=100), 'B':Combatant('B',120,120,Fraction(20),5,0,0,2,'B',maximum_hp=120)},provenance='R171-ENGINE-INTEGRATION-SYNTHETIC')
def state(who,is_react=False):
 return ActorActionState(who,1,120,('r171-counter',) if is_react else ('r171-attack',),reaction_trigger_observed='ATTACK_DECLARED' if is_react else None,enemy_ids_visible=('A' if who=='B' else 'B',))
def declare(s,d,a):return declare_counterattack(s,d,a,source=SRC,state=state(d,True),proofs=(PROOF,),declared_before=True)
def attack(s,a,d,score=4):return apply_weapon_attack(s,a,d,source=ATT,state=state(a),proofs=(PROOF,),roll_score=score,damage=12,damage_tag='perfurante',rd=Resistances())
def execute(s,d,a,decl,inc,rolls=((1,), (2,))):
 return execute_causally_linked_counter(s,d,a,declaration=decl,incoming=inc,attack_attempts=rolls,attack_bonus=0,critical_sequence=(2,3,4),damage_groups=((1,6),),damage_roll_groups=((4,),),flat=0,damage_tag='perfurante',rd=Resistances())
def snap(s):return json.dumps({'actors':{k:asdict(v) for k,v in s.actors.items()},'events':s.events},sort_keys=True,default=str)
class R171(unittest.TestCase):
 def test_01_legitimate_miss_response_misses_and_nested_is_rejected(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B');r=execute(s,'B','A',d,a)
  self.assertFalse(r['hit']);self.assertEqual(s.actors['B'].reaction,0)
  before=snap(s)
  with self.assertRaises(EffectBlocked):declare_counterattack(s,'A','B',source=SRC,state=state('A',True),proofs=(PROOF,),declared_before=True,attack_origin='COUNTER')
  self.assertEqual(before,snap(s));self.assertEqual(independent_validate_chain(s.events)['counter_responses'],1)
 def test_02_second_trigger_same_turn_rejected_without_effect(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B');execute(s,'B','A',d,a)
  before=snap(s)
  with self.assertRaises(EffectBlocked):declare(s,'B','A')
  self.assertEqual(before,snap(s))
 def test_03_hit_and_full_rd_zero_are_not_misses(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B',score=25);self.assertTrue(a['hit'])
  r=execute(s,'B','A',d,a);self.assertEqual(r['action'],'COUNTER_NO_RESPONSE')
  self.assertEqual(independent_validate_chain(s.events)['counter_responses'],1)
  s2=scene();d2=declare(s2,'B','A');a2=apply_weapon_attack(s2,'A','B',source=ATT,state=state('A'),proofs=(PROOF,),roll_score=25,damage=12,damage_tag='perfurante',rd=Resistances(general=99))
  self.assertTrue(a2['hit']);self.assertEqual(a2['net'],0);self.assertEqual(execute(s2,'B','A',d2,a2)['action'],'COUNTER_NO_RESPONSE')
 def test_04_forged_declaration_and_reused_response_rejected(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B');before=snap(s)
  forged=copy.deepcopy(d)
  with self.assertRaises(EffectBlocked):execute(s,'B','A',forged,a)
  self.assertEqual(before,snap(s))
  execute(s,'B','A',d,a);before=snap(s)
  with self.assertRaises(EffectBlocked):execute(s,'B','A',d,a)
  self.assertEqual(before,snap(s))
 def test_05_attack_origin_mutation_rejected(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B');a['attack_origin']='COUNTER';before=snap(s)
  with self.assertRaises(EffectBlocked):execute(s,'B','A',d,a)
  self.assertEqual(before,snap(s))
 def test_07_new_normal_attack_can_trigger_later_counter_in_synthetic_phase(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B');execute(s,'B','A',d,a)
  # B's normal standard action is still unspent; this synthetic fixture does NOT
  # certify a full scheduler / official round boundary.
  d2=declare(s,'A','B');a2=attack(s,'B','A');r2=execute(s,'A','B',d2,a2)
  self.assertEqual(r2['action'],'COUNTER_RESPONSE')
  self.assertEqual(independent_validate_chain(s.events)['counter_responses'],2)
  self.assertEqual((s.actors['A'].reaction,s.actors['B'].reaction),(0,0))
 def test_06_independent_auditor_catches_forged_response(self):
  s=scene();d=declare(s,'B','A');a=attack(s,'A','B');execute(s,'B','A',d,a)
  forged=copy.deepcopy(s.events);forged[1]['hit']=True
  with self.assertRaises(AssertionError):independent_validate_chain(forged)
  forged=copy.deepcopy(s.events);forged[2]['original_attack_seq']=999
  with self.assertRaises(AssertionError):independent_validate_chain(forged)
if __name__=='__main__':unittest.main(verbosity=2)
