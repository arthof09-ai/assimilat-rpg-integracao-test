"""R30 source-real, context-conditional analytical oracle. No combat action/scene.
Works independently from native engine to prevent software bugs from masquerading as RPG balance.
All dice enumerated exactly; no unpublished rules imputed.
"""
from fractions import Fraction
from itertools import product
from collections import Counter
from pathlib import Path
import json,hashlib,os,sys
HIST=Path(os.environ.get('VLAB_R27_ROOT','/mnt/data/vlab_r30_work/r27'))
sys.path.insert(0,str(HIST/'working/historical_v081_verified_original/comestre_vlab'))
OUT=Path(os.environ.get('VLAB_R30_OUT',str(Path(__file__).resolve().parent.parent/'evidence')));OUT.mkdir(parents=True,exist_ok=True)
SOURCES={
 'FRIGIDO_B5':{'page':'f0dc2b32-4ede-820a-b947-0168d4a53315','for':18,'ca':31,'hp':125,'rank':'Bronze 5','attack':'Rabada','damage':'1d6+FOR','damage_type':None},
 'CABRA_B1':{'page':'391c2b32-4ede-8252-b0cc-810423cdbfa6','for':13,'ca':20,'hp':38,'rank':'Bronze 1','attack':'Investida','damage':'1d6+FOR','damage_type':'impacto','rider':'empurrão'},
 'GALIDEMUS_B1':{'page':'eddc2b32-4ede-829f-8a75-011e8acbf429','for':5,'des':13,'ca':21,'hp':32,'rank':'Bronze 1','attack':'Patada','damage':'1d4+DES','damage_type':'cortante'},
 'RATO_B1':{'page':'e29c2b32-4ede-8370-8b21-81332d26422a','for':6,'ca':28,'hp':14,'rank':'Bronze 1','attack':'Mordida Flamejante','damage':'1d4+FOR','damage_type':'perfurante','possible_rider':'Fogo ambíguo'},
 'RINOLUPO_P1':{'page':'034c2b32-4ede-83ff-a711-8144011beaf3','for':30,'ca':27,'hp':228,'rank':'Prata 1','attack':'Investida Feroz','damage':'2d6+FOR','damage_type':None,'specific_rd':'RDF10'},
}
CASES=[
 ('FRIGIDO_B5','CABRA_B1',1,6,18,1,6,18,5),
 ('FRIGIDO_B5','GALIDEMUS_B1',1,6,18,1,6,18,5),
 ('FRIGIDO_B5','RATO_B1',1,6,18,1,6,18,5),
 ('FRIGIDO_B5','RINOLUPO_P1',1,6,18,1,6,18,15),
 ('GALIDEMUS_B1','RATO_B1',1,6,5,1,4,13,5),
 ('RATO_B1','GALIDEMUS_B1',1,6,6,1,4,6,5),
 ('RINOLUPO_P1','FRIGIDO_B5',2,6,30,2,6,30,5),
]
def dist(n,sides):
 c=Counter(map(sum,product(range(1,sides+1),repeat=n)));return c

def exact(actor,target,dn,ds,fix,n_damage,s_damage,fixd,rd,bonus):
 ad=dist(dn,ds);dd=dist(n_damage,s_damage)
 p_hit=Fraction(sum(cnt for roll,cnt in ad.items() if roll+fix+bonus>SOURCES[target]['ca']),sum(ad.values()))
 pmiss=1-p_hit
 expected_raw=Fraction(sum((roll+fixd)*cnt for roll,cnt in dd.items()),sum(dd.values()))
 exp_net=Fraction(sum(max(0,roll+fixd-rd)*cnt for roll,cnt in dd.items()),sum(dd.values()))
 positive=Fraction(sum(cnt for roll,cnt in dd.items() if roll+fixd>rd),sum(dd.values()))
 per_attempt=p_hit*exp_net
 return {'attacker':actor,'target':target,'luta_assumption':bonus,'dice_to_hit':f'{dn}d{ds}+{fix}+{bonus}','target_CA_printed':SOURCES[target]['ca'],
         'dice_damage':f'{n_damage}d{s_damage}+{fixd}','rd_assumed':rd,
         'hit_faces_exact':f'{p_hit.numerator}/{p_hit.denominator}','p_hit_percent':round(float(p_hit*100),4),
         'damage_mean_raw':round(float(expected_raw),6), 'damage_mean_net_per_hit':round(float(exp_net),6),
         'p_net_positive_given_hit':round(float(positive),6), 'damage_mean_per_action':round(float(per_attempt),6),
         'caveat':'MATHEMATICS_NOT_FULL_ACTION; critical/reactions/PA/range/type effects omitted; target uses printed source values'}
rows=[]
for c in CASES:
 for bonus in [0,6]:rows.append(exact(*c,bonus))
# Experimental stacking sensitivity for physical-only assumption and source unspecified Rabada nature.
rd_variants=[]
for rd_kind,rd in [('GENERAL_ONLY_15',15),('SPECIFIC_ONLY_10',10),('LAB_MAX_15',15),('LAB_ADD_25',25)]:
 for bonus in [0,6]:
  rd_variants.append(dict(exact('FRIGIDO_B5','RINOLUPO_P1',1,6,18,1,6,18,rd,bonus),hypothetical_policy=rd_kind,
      specificity_condition='RDF applies only IF Rabada type is admitted as physical; source has no explicit damage tag'))

# First opponent minimal target: chance to finish target HP38 after two landed hits requires both damage die 6.
# Three landed hits always suffice because 3*14=42>38.
finish={'FRIGIDO_TO_CABRA':{'attacker':'FRIGIDO_B5','target':'CABRA_B1','printed_hp_target':38,
'net_damage_min_max_vs_rd5':[14,19],
'landed_hits_to_0_HP_exact_conditional':{'2_hits_probability':str(Fraction(1,36)),'3_hits_probability':str(Fraction(35,36))},
'expected_landed_hits_to_0_HP':float(Fraction(2,36)+Fraction(3*35,36)),
'expected_attempts_LUTA0_no_crits_reactions':float(Fraction(107,36)/Fraction(2,3)),
'expected_attempts_LUTA6_no_crits_reactions':float(Fraction(107,36)),
'note':'Target HP0 is a laboratory calculation only. Natural crits, initiative, reactions, cost, range and full legal actions unresolved.'}}
from vlab_rd_v08 import DamageComponent, Resistances,mitigate,RDUnresolved
rd_checks=[]
for mode in ['STRICT','LAB-MAX','LAB-ADD']:
 try:
  res=mitigate((DamageComponent(22,'impacto','R30_VIRTUAL_PHYSICAL_TAG_CONTRAFACTUAL'),),Resistances(general=15,specific=(('impacto',10),),provenance='RINOLUPO_RDF10_HYPOTHETICAL_DAMAGE_TAG'),stacking=mode)
  rd_checks.append({'mode':mode,'status':'LAB_RESULT','outcome':res.__dict__})
 except RDUnresolved as e:rd_checks.append({'mode':mode,'status':'DENIED_UNRESOLVED','reason':str(e)})
assert rd_checks[0]['status']=='DENIED_UNRESOLVED'
assert [x['outcome']['effective'] for x in rd_checks[1:]]==[7,0]
assert next(x for x in rows if x['attacker']=='FRIGIDO_B5' and x['target']=='CABRA_B1' and x['luta_assumption']==0)['p_hit_percent']==66.6667
# Symbolic DEFENDER reaction thresholds from System Combat: Defense=6+CON+Armor+Fortitude.
# Cabra has CON10, while its armor/fortitude individual modifiers were not source-attested.
reaction_thresholds=[]
for bonus in [0,6]:
 for extra in range(0,15):
  hit_faces=[d for d in range(1,7) if d+18+bonus>20]
  negated=[d for d in hit_faces if d+18+bonus <= 16+extra]
  reaction_thresholds.append({'luta_assumption':bonus,'unknown_armor_plus_fortitude_counterfactual':extra,
    'defender_value':16+extra,'ordinary_hit_faces':hit_faces,'defender_negated_hit_faces':negated,
    'p_hit_cancelled_per_all_attempts':f'{len(negated)}/6',
    'contract':'MATHEMATICS_ONLY; reaction declared before attack; no sourced target armor or Fortitude; actual usage not established'})
R={'schema':'R30_SOURCE_REAL_MATH_ONLY_1','canonical_credit':0,'not_full_action':True,'source_snapshots':SOURCES,
   'conditional_matrix':rows,'defender_reaction_thresholds':reaction_thresholds,'rd_stacking_counterfactuals':rd_variants,'exact_target_hp_math':finish,
   'native_rd_guard_reused':rd_checks,'source_rules':['Criação de Besta:3ebc2b32-4ede-81f4-992a-c88a3588cacd','Sistema de Combate:3ebc2b32-4ede-81f1-be4b-e8804ac113c0'],
   'normative_questions':{'proficiency':'Does general +6 proficiency automatically attach to Luta on natural attacks?',
                          'rd_rdf':'Do general RD and physically matching RDF stack, take max, or replace? Does unnamed Rabada carry physical tag?'}}
p=OUT/'R30_SOURCE_EXACT_ANALYSIS.json';p.write_text(json.dumps(R,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print('saved',p,'rows',len(rows),'RD',rd_checks)
