"""R30 gate checks on EXISTING VLAB modules, without bypass, write or fake receipt."""
import sys,json,pathlib,os
root=pathlib.Path(os.environ.get('VLAB_R27_ROOT','/mnt/data/vlab_r30_work/r27'))
sys.path.insert(0,str(root/'fusion_stage12'))
sys.path.insert(0,str(root/'working/historical_v081_verified_original/comestre_vlab'))
import vlab_r18_interactive as core
from vlab_action_catalog_v01 import ActorActionState,AbilitySource,action_menu
from vlab_effects_v08 import Combatant,Scene
from vlab_transformation_limit_v09_rebuilt import TransformationUseLedger
from unified_gateway import RebuiltManualRuntime

action=AbilitySource('FRIGIDO-RABADA-PENDING','attack','STANDARD',
 'f0dc2b32-4ede-820a-b947-0168d4a53315','FRIGIDO-RABADA-1D6-FOR',
 'LAB-ASSUMPTION',required_pa=0,target_scope='ENEMY',requires_range_check=True,
 effect_adapter_ready=False)
state=ActorActionState(actor_id='Frigido_Ossario_B5',ordinal_level=5,available_pa=120,
 known_action_ids=(action.action_id,),enemy_ids_visible=('Cabra_de_Chifres_B1',),
 range_confirmed=None,los_confirmed=None,geometry_confirmed=None)
menu=action_menu(state,(action,),strict=True)
assert len(menu.legal_options)==0 and menu.rejected
scene=Scene({'Frigido_Ossario_B5':Combatant('Frigido_Ossario_B5',125,120,31,15,0,0,0,'GEOMETRY_UNKNOWN',rank='Bronze'),
 'Cabra_de_Chifres_B1':Combatant('Cabra_de_Chifres_B1',38,22,20,10,0,0,0,'GEOMETRY_UNKNOWN',rank='Bronze')},
 provenance='SOURCE_REAL_AS_PRINTED_GEOMETRY_UNKNOWN')
ledger=TransformationUseLedger(test_fixture_authorized=True)
for a in scene.actors:ledger.register(a)
try:
 RebuiltManualRuntime(scene=scene,ledger=ledger,scene_id='R30-REAL-SOURCE-STRICT-ATTEMPT',test_fixture_authorized=True)
 runtime={'status':'UNEXPECTED_ADMISSION'}
except Exception as e:
 runtime={'status':'DENIED_BEFORE_EFFECT','exception_type':type(e).__name__,'reason':str(e)}
assert runtime['status']=='DENIED_BEFORE_EFFECT' and runtime['reason']=='NONCANONICAL_SCENE_ONLY'
r={'schema':'R30_NATIVE_GATE_REAL_SOURCE_PREFLIGHT','actor_source':'f0dc2b32-4ede-820a-b947-0168d4a53315',
 'target_source':'391c2b32-4ede-8252-b0cc-810423cdbfa6','source_values':{'HP_attacker':125,'CA_attacker':31,'HP_defender':38,'CA_defender':20},
 'action_menu':{'allowed':len(menu.legal_options),'rejected':list(menu.rejected),'rule_status':'NO_ASSUMPTION_CAN_BE_PROMOTED'},
 'native_runtime':runtime,'native_trace_count':0,'effect_applied':False,'receipt_count':0,
 'interpretation':'Source-authentic candidate was not processed. Real-source scenes cannot enter the existing synthetic-only native runtime; geometry, action type/PA and training remain unresolved.',
 'no_authority_inferred':True}
out=pathlib.Path(os.environ.get('VLAB_R30_OUT',str(pathlib.Path(__file__).resolve().parent.parent/'evidence')))/'R30_NATIVE_GATE_DENIAL.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print(json.dumps({'action_menu':r['action_menu'],'runtime':runtime,'no_effect':True},ensure_ascii=False))
