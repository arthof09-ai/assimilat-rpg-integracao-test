# PSV — VLAB / ação natural dirigida, preflight nativo e reconciliação normativa

**Data:** 15/10/2026 · **Operação EXISTENTE:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01 · **Classificação:** MESTRE-ONLY · **Estado:** CIÊNCIA MATEMÁTICA VERIFICADA + PREFLIGHT DE RECUSA VERIFICADO; **não** é ação integral legal nem combate oficial. **Baseline:** R27 ANTES; R28 e R29 preservadas; DMG-RANK v1.1 inalterada.

## 1. Antes → depois, sem inflação de crédito

**ANTES:** R29 tem 8/8 novos combates condicionais, 1 semente 53 interrompida, 0/8 ações reais plenamente admitidas, 0/1.875 células canônicas; R27 320 cenários experimentais e duas UNKNOWN_EFFECT originais. **DEPOIS:** seleção concreta de uma ação/alvo de fontes reais com menor distância documental, 14 cenários probabilísticos enumerados exatamente, 30 estados paramétricos de DEFENDER, três comportamentos do adaptador de RD testados, um preflight estrito de fonte efetivamente recusado e uma tentativa real-source de inicialização nativa recusada *antes de qualquer evento*. **Cenas nativas reais completas novas: 0.** Nenhum banco histórico alterado.

**Integridade revalidada apenas nos arquivos consultados:** R27 SHA-256 `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`, R28 `68da72d6fe71020ce4a555089484514cc86cab67d90c92a77e52d2166c46fdfa`, R29 `0c9beb35b030f844cb109d44fa40bb2f5731665f0e056601252a7ec3c5ee2eb0`; R27 e R29 ZIP CRC íntegros. Não repetir os 320 casos nem as 8 sementes R29.

## 2. Seleção por menor lacuna: Frígido Ossário → Cabra de Chifres

- Fonte real Frígido Ossário B5: `https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315`; **FOR18, CON15, DES18, CA31, HP125, PA120; Rabada `1d6+FOR`**. Fórmula sem rider explicitamente anexado à própria linha. **Tipo de dano da Rabada não foi explicitado na linha da fonte**: não rotular como impacto por inferência.
- Alvo real Cabra de Chifres B1: `https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6`; **FOR13, CON10, DES8, CA20, HP38, PA22**. A CA20 impressa é exatamente `10+8+10/5`. A investida da Cabra tem empurrão, mas **não será usada** nesta primeira ação candidata.
- Fontes normativas: `https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0` (ataque normal custa 1 Ação Padrão; dado de rank + atributo Luta + bônus Luta; teste supera CA); `https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd` (Bronze normal RD5, proficiência geral +6).
- **Divergências preservadas:** HP38 da Cabra e HP125 do Frígido são literais das fichas, mas não necessariamente batem com uma reconstrução retroativa da fórmula atual de Vida; não sobrescrever, e não declarar snapshot pós-reconciliação da ficha/cena. Para uma primeira ação isolada, os valores impressos são observações documentais, não permissão de comprometer o estado oficial.

**Matriz exata, dados uniformes e independentes, SEM crítico, Reação, custo especial ou posicionamento:**

| Ação/Alvo | Luta 0 | Luta +6 | Dano líquido médio / acerto com RD geral indicada |
|---|---:|---:|---:|
| Frígido Rabada → Cabra, CA20 / RD5 | **4/6 (66,67%)** | **6/6 (100%)** | **16,5** (14–19) |
| Frígido Rabada → Galidemus, CA21 / RD5 | 3/6 | 6/6 | 16,5 |
| Frígido Rabada → Rato, CA28 / RD5 | 0/6 | 2/6 | 16,5 |
| Frígido Rabada → Rinolupo, CA27 / RD15 somente | 0/6 | 3/6 | 6,5 |
| Galidemus Patada → Rato, CA28 / RD5 | 0/6 | 0/6 | 10,5 |
| Rato Mordida → Galidemus, CA21 / RD5 | 0/6 | 0/6 | 3,5 |
| Rinolupo Investida → Frígido, CA31 / RD5 | 36/36 | 36/36 | 32,0; geometria/carga pendentes |

**Hipótese de HP zero exclusivamente analítica:** contra os 38 HP impressos da Cabra e RD5, são necessários 2 acertos da Rabada SOMENTE se ambos os dados de dano forem 6 (chance 1/36 condicionada a dois acertos), ou 3 acertos nos demais casos. Esperança = `107/36 = 2,9722` acertos. Esperança de tentativas de ataque = **4,4583** para Luta0 e **2,9722** para +6, sob independência e sem intervenção do alvo. Não é duração de combate nem previsão com Reações.

**Impacto da proficiência:** Luta +6 muda Frígido→Cabra 66,67→100%; Frígido→Rinolupo 0→50%, mas NÃO supera CA alta em Galidemus↔Rato com FOR na rolagem. Logo, a dúvida de proficiência é importante, porém não universalmente suficiente.

## 3. Reconciliação de duas questões normativas

**Questão 1 — Bônus de Luta natural.** A Criação de Besta vigente e antiga declaram +6 de proficiência geral Bronze normal; Criação de Ficha distingue proficiência individual selecionada, e Combate usa especificamente bônus de Luta. A versão antiga de Combate dizia usar atributo de Luta, sem explicitar como +6 de Besta se vincula. **Não foi encontrada decisão expressa que resolve esse vínculo.** Alternativas ainda NÃO homologadas: A) +6 geral em toda Luta natural; B) só com treinamento/seleção comprovada; C) regra expressa diferente do Mestre. Frígido→Cabra aceita potencial de acerto mesmo na alternativa B sem treinamento, mas isso NÃO autoriza inventar o custo ou a geometria da Rabada.

**Questão 2 — RDF10 de Pele Couraçada.** Rinolupo P1 possui RDF10 descrita como resistência adicional física, além da RD15 geral de Prata. O componente histórico `vlab_rd_v08.mitigate` dá resultado físico-experimental **7** com `LAB-MAX` para bruto22, **0** com `LAB-ADD`, e **recusa STRICT** com `general + matching specific RD stacking has no current ruling`. A regra oficial de Criação de Besta de **pele muito grossa** não equivale automaticamente à habilidade **Pele Couraçada**. Além disso, a Rabada do Frígido não tem natureza expressa; só é legítimo aplicar RDF10 após atestar que ela afeta aquela natureza de ataque. A ordem entre duas reduções lineares (15 e 10) não altera a saída se forem efetivamente acumulativas e sem efeitos intermediários, mas a admissibilidade e a política de acúmulo são desconhecidas.

**Decisões objetivas a solicitar ao Mestre, sem pré-preenchimento de norma:**

1. Proficiência: `A = +6 geral automaticamente nos ataques naturais básicos` ou `B = +6 somente com Luta/treino da Besta individual comprovado` (ou texto diferente do Mestre).
2. Resistência: quando RD geral e RDF específica se aplicarem à mesma componente, `A = somam`, `B = usa-se a maior`, `C = apenas uma conforme prioridade/tipo definido` (ou decisão alternativa). Esclarecer se Pele Couraçada RDF10 é passiva e cobre toda natureza física, e se Rabada pode ser tipada física a partir das autoridades já existentes.
3. **Mais urgente para a primeira ação:** confirmar se Rabada do Frígido é **ataque natural normal, corpo a corpo, 1 Ação Padrão e sem custo positivo de PA**, utilizável contra um alvo adjacente; ou apontar fonte diferente. Isto não concede uma cena real: posição/alcance/turno e reação de alvo real ainda requerem snapshot/autorização material.

## 4. Tentativa funcional efetiva — prova negativa sem efeito

**Entrada:** Frígido (source actual B5; HP125, CA31) e Cabra (source actual B1; HP38, CA20) com geometria DESCONHECIDA, Rabada fonte-expressa, sem alegar treinamento, PA, alcance ou estado atual. Usadas as interfaces **históricas**, não novo motor.

1. `action_menu(strict=True)` com `LAB-ASSUMPTION` recusa ação com `LAB-ASSUMPTION-NOT-CANONICAL` — **0 opções legais**.
2. `RebuiltManualRuntime` com procedência real-source retorna `RuntimeBlocked: NONCANONICAL_SCENE_ONLY` durante a inicialização, **antes de evento, HP, PA, recibo ou efeito**. O código existente exige `LAB-TEST-SYNTHETIC-NONCANON` e não oferece um caminho source-authenticated para esta operação; mudar artificialmente a procedência para burlar esse intertravamento seria falso crédito.
3. Teste de RD estrita para geral15 + específica física10: `DENIED_UNRESOLVED`, sem dano aplicado; alternativas MAX e ADD somente contrafactuais.

**Classificação:** tentativa real de pré-admissão recusada, **NÃO ação C executada**. Nenhuma cena, efeito, commit ou tentativa pendente gerada. Esta é a primeira demonstração física nesta sucessão de que, além das lacunas documentais, o runtime atual é **test-only sintético**, independentemente de writer produtivo/IBX-56. A solução futura NÃO requer novo resolvedor: requer porta de admissão de fonte real no mesmo núcleo, após contrato e autorização competentes. Não autorizar contorno agora.

## 5. Reações reais — sensibilidade da Cabra

Fórmula oficial DEFENDER `Defesa=6+CON+Armadura+Fortitude`, logo Cabra `16+X`, com `X=Armadura+Fortitude` individual **não documentado**. No cenário condicional Frígido Luta0, os 4 acertos básicos possíveis são pontuações 21,22,23,24:

| X contrafactual | Defesa | Acertos cancelados por DEFENDER, se reação legal/declaração anterior |
|---:|---:|---:|
| 0–4 | 16–20 | 0/4 |
| 5 | 21 | 1/4 |
| 6 | 22 | 2/4 |
| 7 | 23 | 3/4 |
| 8 ou mais | 24 ou mais | 4/4 |

Com Luta+6, os acertos são 25–30 e o primeiro cancelamento por DEFENDER ocorre somente em X≥9. **São 30 pontos paramétricos matemáticos, não 30 reações nativas realizadas.** Nenhum experimento novo de Reações R26 foi alegado; resultados R23/R29 históricos permanecem separados.

## 6. Ponte DMG e limites

Fonte oficial numérica e contrato DMG→VLAB v0.2 reabertos/recuperados anteriormente. O ZIP `DMG_F0_F6_LOTE_CIENTIFICO_002.zip` existe em Library `libfile_84761c9a591c8191bc304533e4074ee9`, mas a materialização dos bytes retorna **sem caminho autorizado**. Portanto não se reivindica absorção integral das 45 páginas/58 registros nem duplicação do censo. Comparador legítimo Galidemus Patada 1d4+13 tem média bruta15,5 e líquida10,5 com apenas RD5 por acerto versus 3d6 genérico Bronze1 média bruta10,5/líquida5,523; precisão independente. Nenhum DMG-RANK v2 foi criado.

## 7. PSV — universo/contabilidade e fronteira

| Indicador | Estado após esta rodada |
|---|---|
| Ações reais **integralmente admitidas** | **0/5 candidatas dirigidas** (Frígido Rabada, Galidemus Patada, Rato Mordida, Cabra Investida, Rinolupo Investida); denominador não substitui coorte histórica de 8 |
| Pré-admissões source-authentic rejeitadas antes do efeito | **1/1**, `NONCANONICAL_SCENE_ONLY`; recibos reais 0 |
| Combates reais completos / tentados com admissão válida | **0/0** |
| Novos combates condicionais completos nesta rodada | **0** (R27–R29 intactos) |
| Novas tentativas interrompidas com efeito desconhecido | **0**; falha de inicialização conhecida NO-EFFECT |
| Cálculos novos de combinação atacante×alvo×Luta | **14/14** analíticos exatos, condicionais |
| Valores contrafactuais de DEFENDER | **30/30**, nenhum usado como treino oficial |
| Cenários do adaptador RD | **3/3** (STRICT recusa, LAB-MAX, LAB-ADD) |
| Fronteiras matemáticas já investigadas | **4/4** históricas; **1/4** com par de Bestas identificadas |
| Fronteiras com combate completo | **0/4** |
| Patamares com combate condicionado histórico | **1/25** (Bronze1 sintético); **0/25** com Besta real |
| VLAB terminal | **0/17** |
| Células canônicas creditadas | **0/1.875** |
| DMG critérios terminais | **1/18** histórico, não reaud itado |

**HOLD:** writer produtivo, lease, epoch, fencing, GREEN e NAC-PASS-02 terminal. IBX-56 BLOCKED-EXTERNAL; IBX-90/91/92 sem ACK assumido. Duelo dos Vigias congelado; nenhuma ficha canônica/Party/O Primeiro tocada. Baseline ANTES e todas as tentativas UNKNOWN_EFFECT legadas preservadas.

**CHECKPOINT EXATO / PRÓXIMA FRONTEIRA:** (1) obter decisão de mapeamento da Rabada a ataque normal/custo/alcance e fonte de posicionamento; (2) encaminhar decisões mínimas de Luta e RDF/stacking sem presumir ACK; (3) admitir o estado real-source via gateway competente sobre **o motor histórico**, sem remover guard de cena sintética; (4) somente então executar **um** ataque com recibo transacional e replay; (5) em paralelo continuar estudos matemáticos e Reações R26 controladas. As evidências desta rodada foram calculadas sem alterar qualquer objeto original.
