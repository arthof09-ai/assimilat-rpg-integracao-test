# PSV — OP-VLAB-FUSION-SANDBOX-01 / CICLOS R44 → R45B → R46

**Autoridade:** Mestre do RPG · **Executor:** CM-000006 / MESTRE-SIDE · **Natureza:** três ciclos consecutivos de engenharia experimental, sem alteração canônica · **Data de execução:** 15/10/2026 (fuso America/Recife; sessão continuada através da meia-noite UTC).

## Escopo e método de sucessão

A ordem do Mestre foi seguir automaticamente a próxima fronteira no mínimo três vezes, começando pela Luta de ataque normal de oportunidade, depois resolução sequencial de dano/Reações/morte. Em vez de atribuir à Cabra Bronze1 uma Luta que sua ficha não fornece, localizei **três fichas Mestre-side reais com equipamentos ativos, Luta, Iniciativa, CA, RD e HP completamente numerados**: Sikong Feryn ON5, Sikong Varok ON5 e Sikong Arveth ON5. Fichas consultadas no Notion conectado à área Mestre, **somente leitura**, data de última edição 11/10/2026. O arquivo `evidence/R44_R46_FROZEN_MASTER_SOURCE.json` fixa as fontes e valores numéricos e este PSV documenta os limites.

**Regras competentes:** Sistema de Combate (reação de Ataque de Oportunidade com Vantagem, um slot; Contra-atacar declarado antes do ataque, após ataque que não supera CA, ataque normal com Vantagem; Vantagem nível1 = duas rolagens completas do teste, escolher a maior e +2; crítico sequencial 3d6), Mestre R43 (concorrência AoO por maior DES, dado maior no empate), Mestre R41 (positivo auto-hit), Mestre R42 (negativo automatic miss, custo consumido, dano zero LAB). **RNG:** `vlab_r18_interactive.dice` SHA256-seeded Python MT, experimental, jamais dados canônicos. **Registro:** `vlab_r18_interactive.event_commit` original, SQLite WAL e dois estados lógicos por transação. **Iniciativa:** R26 `tie_order` e `refresh_own_turn`, não foram inventados bônus de Iniciativa. A prioridade não foi igualada a ordem de iniciativa.

### Fonte admitida e aritmética

| Instância | Fonte Notion | DES | Vida | CA | RD | Iniciativa publicada | Luta publicada | Ataque equipado | Dano equipado |
|---|---|---:|---:|---:|---:|---|---|---|---|
| F — Sikong Feryn | `3f6c2b32-4ede-81ce-9c61-db8127bf0e31` | 80 | 479 | 123 | 22 | 4d6+82 | 4d6+82 | 4d6+92 = +82 Luta +10 arma | 8d8+47 cortante |
| V — Sikong Varok | `3f6c2b32-4ede-81f4-9ea9-efbe1a811091` | 27 | 734 | 83 | 35 | 4d6+29 | 4d6+90 | 4d6+100 = +90 Luta +10 arma | 10d10+48 impacto/corte |
| R — Sikong Arveth | `3f6c2b32-4ede-8105-891f-c647242e61ca` | 23 | 806 | 93 | 30 | 4d6+25 | 4d6+60 | 4d6+72 = +60 Luta +12 arma | 8d10+35 perfurante |
| G — Cabra Bronze1 | `391c2b32-4ede-8252-b0cc-810423cdbfa6` | 8 | 38 | 20 | 5 | **ausente** | **normal ausente** | **1d6+FOR13+Luta6 somente Investida** | 1d6+13 impacto |

Os vínculos de armas de F/V/R são 90/95/85 PA **por dia**, já comprometidos na configuração equipada. Não foram debitados de novo por golpe ou Reação. Poderes pagos extra das armas NÃO foram ativados. Golpes ordinários com arma têm alcance adjacente em suas fichas. Para uso concedido por Reação de oportunidade ou Contra-atacar, aplicou-se custo de **1 Reação**, não uma nova Ação Padrão; esta interpretação deriva do direito de fazer ataque por Reação no Sistema de Combate e **não concede segunda Ação Padrão**. O saldo de Ação Padrão dos NPCs foi mantido.

## Ciclo 1 — R44 / AoO em fonte legítima e scheduler ON5

**ANTES:** R43 sabia ordenar dois AoOs, mas não aplicar golpes normais da Cabra/Frígido por Luta ausente. **DEPOIS:** nova cena `R44_SEED97011`, em SQLite próprio, três NPCs Mestre com Iniciativa completa. RNG 4d6+82 Feryn=93, 4d6+25 Arveth=44, 4d6+29 Varok=40; ordem global inicial **F → R → V**. F encerrou voluntariamente seu turno sem atacar, sem perder sua Reação. No turno seguinte de R, Arveth tentou movimentar-se voluntariamente de (0,0) a (-1,5,-1,5), saindo da adjacência de F(1,5;0) e V(0;1,5). Ambos tinham slot1. Ordem R43 por DES **F80 → V27**; nenhum dado de prioridade, pois DES é diferente.

1. Feryn: vantagem `max(4d6,4d6)+2`, resultado de ataque **113** vs CA93, dano **8d8+47=88**, RD30, **58 líquido**; R: HP806→748; F: Reação1→0.
2. Varok: vantagem `max(4d6,4d6)+2`, ataque **113** vs CA93, dano **10d10+48=106**, RD30, **76 líquido**; R: HP748→672; V: Reação1→0.
3. Com ambas as oportunidades resolvidas sem KO, o deslocamento do próprio R foi concluído, Movimento1→0, posição final (-1,5;-1,5).

**Recibo:** 6 eventos R18 (INIT, encerramento voluntário F, gatilho de deslocamento, dois ataques AoO, resolução de movimento), ledger/head `03f7fc398ff722c1916252e7d61836d5fea98335f68f0c657ec03082a9fba5f0`. **Auditoria fria** reproduziu 6/6 eventos, fonte, RNG, ações, recursos e checkpoint. **Crédito:** AoO fonte-documentada em janela legal de turno, NÃO full-fight nem aprovação terminal de scheduler geral.

## Ciclo 2 — R45 / Contra-atacar e correção de precedência temporal R45B

A primeira cena `R45_SEED97101` revelou uma **deficiência causal do próprio adaptador novo**: calculava a rolagem inimiga *antes* do consumo da Reação que teria de ser declarada antes do ataque. Embora o dano numérico estivesse dentro das fontes, **o primeiro ensaio está QUARENTENADO** para crédito de anúncio correto. Ledger de 1 evento e checkpoint mantidos imutáveis (head `36b972216684f20f039793a0f09586bc73c1e7ea4a7c6a258aac1637abe15581`). Não foi excluído nem relabelado como PASS.

A correção aditiva `extension/r45b_counter_causal.py` foi executada **num banco NOVO**, `R45B_SEED97102`:

1. **BEFORE_ATTACK:** Feryn declara Contra-atacar e seu slot passa 1→0 **antes de consumir os dados de ataque inimigo**.
2. Cabra G executa Investida fonte-válida: dado de ataque **2**, pontuação 2+13+6=**21** contra CA123 de Feryn, **erro**; Cabra gasta sua Ação Padrão1→0. Nenhum dano nem empurrão da Investida.
3. A condição escrita do Contra-atacar está satisfeita: ataque inimigo não superou CA. Feryn faz ataque equipado NORMAL com vantagem: **107** vs CA20; dano `8d8+47=82`, RD5, líquido **77**; G HP38→0. F: Reação0 e Ação Padrão preservada.
4. Tudo acima é um ÚNICO commit R18, com etapas internas numeradas e efeito atômico. Checkpoint, replay causal, dados e fórmula foram reconstituídos em auditor independente.

**Head R45B:** `330da1e57a8b259932c36c23386f0f1f31006fe2f3187e0e110133d0085e8f28`. **Limite:** cenário de janela de Reação fonte-válida com Cabra, MAS não combate com iniciativa fonte-completa (bônus individual da Cabra não publicado). A Cabra não declarou segunda Reação defensiva voluntária contra a resposta; a cadeia de Reação aninhada permanece não exercitada. Crítico positivo do ataque entrante e contra-ataque crítico no mesmo evento não receberam crédito nesta bateria.

## Ciclo 3 — R46 / AoO letal, cancelamento de segunda oportunidade, idempotência e recuperação

Nova cena `R46_SEED97201`: mover G Cabra Bronze1, janela voluntária `start(0,0)→destino(-1,5,-1,5)` com Feryn DES80 e Varok DES27 adjacentes e reação1 cada. O teste **não afirma iniciativa global da Cabra**, que carece do bônus individual publicado; admite apenas a janela de gatilho e as fontes dos dois atacantes. Ordem R43: F antes V. Feryn realiza ataque normal com vantagem **109** contra CA20, dano `8d8+47=89`, RD5, líquido **84**, G HP38→0. Seu slot1→0. **Varok NÃO atacou alvo morto, NÃO perdeu Reação (permaneceu1), NÃO recebeu dano fictício extra.** G não teve posição movimentada; fase final `LAB_KO_DURING_AOO_MOVEMENT_UNFINISHED`. O custo final da tentativa de Movimento interrompida por morte não tem fundamento normativo suficiente e foi rotulado **PENDENTE**, não inventado. Ledger **3 eventos** (gatilho, ataque, interrupção), head `98b1daeacb3e5d16c3c99c490bd7645d75b3203c38b9c883f4d04a13e10b64f1`, checkpoint e auditoria fria PASS. Cena de janela interrompida, **não é luta completa nem eliminação canônica**.

**Gates adversariais adicionais:** 13/13 mutações em cópias descartáveis tiveram hashes refeitos e foram aceitas estruturalmente no R18, mas rejeitadas pelo auditor mecânico autônomo. Mutantes cobriram d6=7, soma falsa, RD/dano/Vida alterados, prioridade invertida, PA indevido, crítico forjado, anúncio de Contra-atacar depois do dado, bônus de Luta falso, Reação não consumida e custo de movimento imposto após KO. Comando com **mesmo ID** recusado sem pendência ou segundo efeito. **5/5 reenvios semanticamente repetidos com ID novo** barrados antes de `event_commit` por gate aditivo de fase/recursos.

**Falha controlada `R46_SEED97202` (NÃO É CENA COMPLETA):** um novo banco independente confirmou gatilho como revisão1. O processo filho foi morto pelo failpoint histórico R18 `AFTER_INTENT` antes do ataque de Feryn. Readback físico: **revisão1, eventos1, pending1**, hp G38/F479/V734 e todas Reações1 inalterados, SQLite `integrity_check=ok`. `j.load` respondeu `UNKNOWN_EFFECT`, recusando replay/retentativa. Backup lógico preserva exatamente esse estado; **não retentar, não descartar nem declarar conclusão de efeito externo**. Arquivo de recibo `evidence/R46_FAULT_ISOLATION.json`.

## Matriz de contratos, crédito proporcional e limites

**Baseline:** a matriz ORIGINAL de R18 está em `reconstruction/r18_delivery/VLAB_R18_MATRIX_17_MASTER_ONLY.json` no pacote R27, SHA256 `6303064ac97118ec1ed8763b94a5c014a641c1c67ac0efdb596c167abe6df744`. A R44–R46 não redefiniu os 17 objetos. Deltas em `evidence/R44_R46_CONTRACT_DELTA_17.json`.

- `REACTION_TRIGGER_AND_SINGLE_USE`: nova prova positiva de prioridade DES, duas Reações de AoO em mesma janela, Contra-atacar com declaração causal corrigida, segunda Reação pós-KO não aplicada. **PASS parcial na arquitetura aditiva; terminal HOLD** por outras modalidades e precedências (Contra aninhado, críticos) não cobertas, gates externos NAC-PASS.
- `TURN_SCHEDULER_EVENT_SOURCING`: cena R44 fonte ON5 com bônus de Iniciativa publicados, ordem correta e evento causal, Ações não duplicadas; R46 KO em janela sem iniciativa autenticada da Cabra. **PASS parcial; terminal HOLD** para scheduler geral, múltiplas cenas/turnos extremos, aprovação competente.
- `RNG_REPLAY_STATISTICS`: 4d6 de Iniciativa, vantagem duas rolagens completas ON5, 8d8/10d10 de dano, crítico 3d6 sequencial; auditores fria/estrutural diferenciam dado falseado e ledger intacto. **PASS parcial; terminal HOLD** por fonte CANÔNICA de RNG, amplitude estatística e NAC-PASS.
- `AUTHORITATIVE_RULES_AND_ADAPTERS`, `ACTION_CATALOG_AIN01`, `ITEM_EQUIPMENT_AND_ENHANCEMENTS`, `GENERAL_SPECIFIC_RD`: ampliaram evidência em subcomponentes específicos de fontes/equipamentos e RD geral, sem provar cobertura terminal (ex.: poderes positivos PA, RD específica, snapshot canônico geral). Os demais contratos não foram ensaiados nesta rodada.

**Estado DEPOIS:** **3/3 ciclos materiais**, 3 cenas tecnicamente auditadas, 10 eventos R18 com crédito causal, 3 checkpoints verificados, 1 ensaio R45 causalmente quarantined, 1 banco adicional com pending frozen. **Nenhum novo combate completo**, nenhum efeito canônico, nenhuma alteração em Party, O Primeiro, bestiário ou NPCs oficiais. Histórico de 18 combates sandbox reconhecidos até R40 inalterado; cenas R41/R42 condicionais e censuras continuam apartadas. **Contratos terminais certificados 0/17; células canônicas 0/1.875; writer/lease/epoch/fencing/GREEN e NAC-PASS-02 terminal HOLD; IBX-56 BLOCKED-EXTERNAL.**

## Próxima fronteira física

1. **Contra-atacar com ataque entrante crítico positivo**, preservando declaração antecipada e sem converter um autoacerto em oportunidade indevida de Contra-atacar; os efeitos da defesa e mitigação devem ser registrados num novo teste.
2. **Interrupções aninhadas:** saber se o alvo da resposta de Contra-atacar pode anunciar nova Reação e qual precedência aplica, sem automatizar prioridade não documentada. Não importar +6 da Investida para ataque normal.
3. **Ataque de Oportunidade com empate de DES entre atores ON5**: a decisão Mestre determina disputa no dado; deve-se usar o dado competente 4d6 por rank, mantendo R26 para rerrolar apenas empatados, e depois executar ambos os ataques no mesmo movimento. A R43 já testou empates Bronze 1d6; ON5 ainda não foi exercitado no ledger integrado.
4. **Cenários multiator reais de vários turnos com morte durante Reação**, cobertura terminal da matriz, auditoria externa NAC-PASS e autenticação do RNG da campanha. Nenhuma dessas lacunas transforma os três ensaios R44–R46 em combates canônicos.

## Preservação e reprodução

Pacote delta contém apenas novos arquivos R44–R46, sem replicar motores históricos de dezenas de megabytes. Código de execução depende das versões R27/R18/R26 já presentes na Biblioteca original; **auditoria fria é executável com Python stdlib a partir de uma extração independente** sem importação desses motores. `extension/verify_r44_r46_standalone.py` reconstrói 10 eventos e 3 snapshots; `extension/verify_r44_r46_archive.py` verifica hashes, CRC, SQLite e o estado pending. Auditoria de adulteração (`extension/r44_r46_adversarial.py`) só opera em cópias temporárias. Fontes congeladas, genesis, logs de falha, recebos e hash original da R43 permitem sucessão sem chats. A operação existente no Notion receberá checkpoints R44/R45B/R46 e readback.
