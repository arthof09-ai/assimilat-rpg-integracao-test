"""Cold independent verifier of the R44/R45B/R46 causal source-bound experiment.
STDLIB only; never import R18/R26/event executors. Keeps R45 erroneous causal-order
artifact separate/quarantined. Checks structural chain, independent RNG and mechanics.
"""
from __future__ import annotations
import copy,hashlib,json,math,random,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RV='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
EXPECTED={'F':{'page':'3f6c2b32-4ede-81ce-9c61-db8127bf0e31','hp':479,'des':80,'ca':123,'rd':22,'init':82,'luta':82,'weapon_plus':10,'attack':92,'damage':(8,8,47),'rank':(4,6)},
'V':{'page':'3f6c2b32-4ede-81f4-9ea9-efbe1a811091','hp':734,'des':27,'ca':83,'rd':35,'init':29,'luta':90,'weapon_plus':10,'attack':100,'damage':(10,10,48),'rank':(4,6)},
'R':{'page':'3f6c2b32-4ede-8105-891f-c647242e61ca','hp':806,'des':23,'ca':93,'rd':30,'init':25,'luta':60,'weapon_plus':12,'attack':72,'damage':(8,10,35),'rank':(4,6)},
'G':{'page':'391c2b32-4ede-8252-b0cc-810423cdbfa6','hp':38,'des':8,'ca':20,'rd':5,'init':None,'luta':None,'attack':19,'damage':(1,6,13),'rank':(1,6)}}

def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def H(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def ck(test,msg):
 if not test:raise AssertionError(msg)
def dice(seed,idx,label,num,faces):
 inp=f'{seed}|{idx}|{label}|{num}d{faces}|{RV}'.encode()
 rng=random.Random(int.from_bytes(hashlib.sha256(inp).digest(),'big'))
 return [rng.randint(1,faces) for _ in range(num)]
def nearby(x,y):return math.dist(x,y)<=1.500001

def check_frozen():
 obj=json.loads((ROOT/'evidence/R44_R46_FROZEN_MASTER_SOURCE.json').read_text())
 frozen=obj['sources'];ck(set(frozen)==set(EXPECTED),'SOURCE_NAMES')
 for aid,f in frozen.items():
  e=EXPECTED[aid]
  for a,b in [('page','page'),('hp','hp'),('des','des'),('ca','ca'),('rd','rd'),('initiative_bonus','init'),('luta_bonus','luta'),('attack_bonus','attack')]:
   ck(f[a]==e[b],'BAD_FROZEN_'+aid+'_'+a)
  ck(tuple(f['rank_dice'])==e['rank'] and tuple(f['damage_dice'])==e['damage'][:2] and f['damage_bonus']==e['damage'][2],'BAD_DICE_'+aid)
  if aid!='G':ck(f['attack_bonus']==f['luta_bonus']+f['weapon_accuracy'],'BAD_WEAPON_BONUS_'+aid)
  else:ck(f['luta_bonus'] is None and f['attack_bonus']==19,'GOAT_UNAUTHORIZED_LUTA')
 return H(obj)

def attack(st,attacker,target,reason):
 a=EXPECTED[attacker];d=EXPECTED[target];ix=st['r44_46']['attack_indices'][attacker]+1
 tag=f"{st['cycle']}-{reason}-{attacker}-{target}-{ix}"
 tape=[];crit=[]
 for k in (1,2,3):
  v=dice(st['seed'],ix,tag+'-CRIT-'+str(k),1,6)
  tape.append({'label':tag+'-CRIT-'+str(k),'index':ix,'count':1,'faces':6,'results':v});crit.append(v[0])
 pos=crit[:2]==[6,6] and crit[2] in (5,6);neg=crit[:2]==[1,1] and crit[2] in (1,2)
 rolls=[]
 for i in range(1,2 if reason=='INVESTIDA' else 3):
  faces=6;num=1 if reason=='INVESTIDA' else a['rank'][0]
  label=tag+'-HIT-'+str(i);v=dice(st['seed'],ix,label,num,faces)
  tape.append({'label':label,'index':ix,'count':num,'faces':faces,'results':v});rolls.append(sum(v))
 label=tag+'-DAMAGE';dd=dice(st['seed'],ix,label,a['damage'][0],a['damage'][1]);tape.append({'label':label,'index':ix,'count':a['damage'][0],'faces':a['damage'][1],'results':dd})
 bonus=19 if reason=='INVESTIDA' else a['attack']+2
 score=max(rolls)+bonus;raw=sum(dd)+a['damage'][2]+(a['damage'][0]*a['damage'][1] if pos else 0)
 hit=False if neg else (pos or score>d['ca']);net=max(0,raw-d['rd']) if hit else 0
 return {'tag':tag,'reason':reason,'attacker':attacker,'target':target,'source_page_id':a['page'],
  'normal_luta_source':None if attacker=='G' else a['luta'],'attack_bonus':bonus,
  'attack_sums':rolls,'score':score,'ca':d['ca'],'critical_dice':crit,
  'critical_status':'POSITIVE' if pos else 'NEGATIVE' if neg else 'NONE',
  'hit_reason':'POSITIVE_AUTO_HIT' if pos else 'NEGATIVE_AUTOMATIC_MISS' if neg else 'NUMERIC_HIT' if hit else 'NUMERIC_MISS',
  'hit':bool(hit),'damage_dice':dd,'damage_formula':str(a['damage'][0])+'d'+str(a['damage'][1])+'+'+str(a['damage'][2]),
  'raw':raw,'rd_applied':min(raw,d['rd']) if hit else 0,'net':net,'tape':tape,
  'advantage_level':0 if reason=='INVESTIDA' else 1,
  'resource_cost':'ONE_STANDARD' if reason=='INVESTIDA' else 'ONE_REACTION',
  'pa_per_attack':0,'canonical_credit':0}

def progression(st,row):
 kind=row['kind'];p=row['payload'];cycle=st['cycle'];res=st['r44_46'];actors=st['actors']
 if kind=='INIT':
  ck(cycle=='R44' and st['phase']=='READY','INIT_ILLEGAL')
  rr=[];t=[]
  for aid in sorted(actors):
   e=EXPECTED[aid];label='R44-INIT-'+aid;vals=dice(st['seed'],0,label,*e['rank'])
   rr.append({'id':aid,'total':sum(vals)+e['init'],'des':e['des']})
   t.append({'label':label,'index':0,'count':e['rank'][0],'faces':e['rank'][1],'results':vals})
  ck(len({z['total'] for z in rr})==len(rr),'TIE_NOT_COVERED_BY_THIS_SCENE')
  order=[z['id'] for z in sorted(rr,key=lambda x:(-x['total'],-x['des']))]
  st.update({'order':order,'active':order[0],'phase':'TURN','round':1,'turn':0})
  res['turn_log'].append({'round':1,'active':st['active'],'kind':'INIT'})
  before=actors[st['active']]['resource']['reaction'];actors[st['active']]['resource']['reaction']=1
  expected={'initiative':rr,'rng':t,'tie_order':{'order':order,'rerolls':[],'rule':'MESTRE_EXPRESSA_DES_THEN_ONLY_TIED_REROLL'},'active':st['active'],
            'refresh':{'actor':st['active'],'before':before,'after':1,'trigger':'OWN_TURN_START','no_stockpiling':True,'ruling_id':'R26-MESTRE-REACTION-REFRESH'}}
  # The exact R26 ruling_id may differ: check independently the stable fields of returned payload.
  actual=row['detail'];ck({k:actual[k] for k in ('initiative','rng','tie_order','active')}=={k:expected[k] for k in ('initiative','rng','tie_order','active')},'INIT_DETAIL')
  for k in ('actor','before','after','trigger','no_stockpiling'):ck(actual['refresh'][k]==expected['refresh'][k],'INIT_REFRESH_'+k)
  return
 if kind=='TURN_WAIT':
  ck(cycle=='R44' and st['phase']=='TURN' and p['actor']==st['active'] and st['active']!='R','WAIT_OUT_OF_TURN')
  before=st['active'];st['turn']=(st['turn']+1)%len(st['order']);st['active']=st['order'][st['turn']]
  if st['turn']==0:st['round']+=1
  res['turn_log'].append({'round':st['round'],'active':st['active'],'kind':'VOLUNTARY_WAIT'})
  prev=actors[st['active']]['resource']['reaction'];actors[st['active']]['resource']['reaction']=1
  d=row['detail'];ck(d['old_active']==before and d['new_active']==st['active'] and d['round']==st['round'],'WAIT_DETAILS')
  ck(d['refresh']['before']==prev and d['refresh']['after']==1 and d['refresh']['actor']==st['active'],'WAIT_REACTION_REFRESH')
  return
 if kind=='AOO_TRIGGER':
  ck(cycle in ('R44','R46') and st['phase'] in ('TURN','READY'),'TRIGGER_PHASE')
  mover=p['mover'];ck(mover==('R' if cycle=='R44' else 'G'),'WRONG_MOVER')
  ck(cycle!='R44' or st['active']==mover,'MOVER_OUT_OF_TURN')
  ck(actors[mover]['resource']['movement']==1 and actors[mover]['resource']['hp']>0,'MOVER_RESOURCES')
  start=actors[mover]['position'];destination=p['to'];ck(start==[0.,0.] and destination==[-1.5,-1.5],'MOVER_GEOMETRY')
  people=[a for a in actors if a!=mover and actors[a]['resource']['reaction']==1 and nearby(start,actors[a]['position']) and not nearby(destination,actors[a]['position'])]
  ck(len(people)==2,'ELIGIBLE_COUNT');prio=sorted(people,key=lambda a:-EXPECTED[a]['des'])
  ck(len({EXPECTED[a]['des'] for a in people})==2,'TIE_OUT_OF_SCOPE')
  req={'actor':mover,'start':start[:],'to':destination[:],'voluntary':True,'triggered':people[:],'priority':prio[:],'not_yet_moved':True}
  res['movement_request']=req;res['priority_queue']=prio[:];st['phase']='AOO_PENDING'
  ck(row['detail']=={'movement_request':req,'ordered_by':'MESTRE_R43_DESCENDING_DEX','reaction_spent':0,'hp_changed':False},'TRIGGER_DETAIL')
  return
 if kind=='AOO_ATTACK':
  ck(st['phase']=='AOO_PENDING' and res['priority_queue'],'MISSING_AOO')
  actor=res['priority_queue'][0];target=res['movement_request']['actor']
  ck(actor==p['actor'],'WRONG_PRIORITY');a=actors[actor]['resource'];d=actors[target]['resource']
  ck(a['reaction']==1 and a['hp']>0 and d['hp']>0,'NO_REACTION_OR_DEAD')
  ck(nearby(actors[actor]['position'],actors[target]['position']),'NOT_ADJACENT')
  e=attack(st,actor,target,'AOO');old=d['hp'];d['hp']=max(0,old-e['net']);e.update({'before_hp':old,'after_hp':d['hp']})
  a['reaction']=0;res['attack_indices'][actor]+=1;res['attack_events'].append({'actor':actor,'target':target,'reason':'AOO','result':e});res['issued_attack_ids'].append(e['tag']);res['priority_queue'].pop(0)
  expected={'AOO_ATTACK':e,'remaining_queue':res['priority_queue'][:], 'movement_not_yet_completed':True,'target_KO':d['hp']<=0,'no_extra_standard_spent':True,'official_effects':0}
  ck(row['detail']==expected,'AOO_MECHANICS_OR_TAPE_INVALID');return
 if kind=='MOVEMENT_RESOLUTION':
  ck(st['phase']=='AOO_PENDING','MOVEMENT_PHASE')
  req=res['movement_request'];mover=req['actor'];d=actors[mover]['resource'];remaining=res['priority_queue'][:]
  if d['hp']==0:
   st['phase']='LAB_KO_DURING_AOO_MOVEMENT_UNFINISHED';res['blocked_uncertainties'].append('DEAD_MOVERS_MOVEMENT_COST_NOT_GROUNDED');res['movement_cost_uncertain_on_KO']=True
   detail={'status':'KO_BEFORE_MOVEMENT_COMPLETED','remaining_unspent_reactions':{a:actors[a]['resource']['reaction'] for a in remaining},'not_acted':remaining,'movement_state':'UNRESOLVED_MOVEMENT_COST_NO_CANONICAL_CREDIT'}
  else:
   ck(not remaining and d['movement']==1,'PENDING_AOO_OR_MOVEMENT')
   d['movement']=0;actors[mover]['position']=req['to'][:];res['movement_completed']=True;st['phase']='AOO_WINDOW_CLOSED_LAB'
   detail={'status':'MOVED_AFTER_TWO_RESOLVED_AOO','to':req['to'][:],'movement_spent':1,'reaction_spent_attacker':{a:actors[a]['resource']['reaction'] for a in req['priority']}}
  ck(row['detail']==detail,'MOVEMENT_RESULT_MISMATCH');return
 if kind=='COUNTER_BEFORE_ATTACK':
  ck(cycle=='R45B' and st['phase']=='READY' and p=={'kind':'COUNTER_BEFORE_ATTACK','attacker':'G','defender':'F'},'COUNTER_ADMISSION')
  G=actors['G']['resource'];F=actors['F']['resource'];ck(G['standard']==1 and F['reaction']==1 and nearby(actors['G']['position'],actors['F']['position']),'COUNTER_PRECONDITIONS')
  was=F['reaction'];F['reaction']=0
  steps=[{'ordinal':1,'step':'DECLARE_COUNTER_BEFORE_INCOMING_ROLL','F_reaction_before':was,'F_reaction_after':0,'cause':'ENEMY_ANNOUNCES_ADJACENT_INVESTIDA'}]
  incoming=attack(st,'G','F','INVESTIDA');steps.append({'ordinal':2,'step':'ROLL_AND_RESOLVE_INCOMING','score':incoming['score'],'critical':incoming['critical_status'],'hit':incoming['hit']})
  ck(incoming['hit'] is False,'POSITIVE_CRITICAL_COUNTER_BRANCH_OUTSIDE_CURRENT_VERIFICATION')
  G['standard']=0;incoming.update({'before_hp':F['hp'],'after_hp':F['hp']})
  counter=attack(st,'F','G','COUNTER');before=G['hp'];G['hp']=max(0,before-counter['net']);counter.update({'before_hp':before,'after_hp':G['hp']})
  steps.append({'ordinal':3,'step':'COUNTER_TRIGGERED_BY_MISS','inbound_score':incoming['score'],'F_ca':EXPECTED['F']['ca']})
  steps.append({'ordinal':4,'step':'COUNTER_NORMAL_EQUIPPED_WEAPON_WITH_ADVANTAGE','counter_score':counter['score'],'counter_damage':counter['net'],'G_hp_after':G['hp']})
  res['attack_indices']['G']+=1;res['attack_indices']['F']+=1
  res['attack_events'].extend([{'actor':'G','target':'F','reason':'INVESTIDA','result':incoming},{'actor':'F','target':'G','reason':'COUNTER','result':counter}])
  res['issued_attack_ids'].extend([incoming['tag'],counter['tag']]);st['phase']='COUNTER_PROPERLY_RESOLVED_TARGET_KO' if G['hp']==0 else 'COUNTER_PROPERLY_RESOLVED_TARGET_ALIVE'
  detail={'stages':steps,'incoming':incoming,'counter':counter,'reaction_was_consumed_BEFORE_roll':True,'G_standard_after':G['standard'],'F_reaction_after':F['reaction'],'F_standard_after':F['standard'],'official_effects':0}
  ck(row['detail']==detail,'COUNTER_MECHANIC_OR_ORDER_MISMATCH');return
 raise AssertionError('UNKNOWN_EVENT_'+kind)

def audit(db,quarantine=False):
 db=Path(db);co=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
 try:
  ck(co.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLITE_INTEGRITY')
  m=dict(co.execute('SELECT key,value FROM meta'));rows=co.execute('select seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha from events order by seq').fetchall()
  ck(m['mode']=='EXPERIMENTAL_LAB_ONLY','NOT_LAB');ck(co.execute('select count(*) from pending').fetchone()[0]==0,'PENDING_INTENT')
  ck(len(rows)==int(m['revision']),'REVISION_COUNT');prev=m['genesis'];prior=None
  for seq,cmd,reference,raw,rowsha,before,after in rows:
   row=json.loads(raw)
   ck(seq==row['seq'] and cmd==row['cmd_id'] and cmd.startswith('LAB-CMD-'),'ROW_ID')
   ck(reference==row['prev']==prev and H(row)==rowsha,'STRUCT_CHAIN')
   ck(row['before_sha']==before and row['after_sha']==after,'ROW_SHA')
   if prior is not None:ck(before==prior,'STRUCT_BEFORE_CHAIN')
   prev=rowsha;prior=after
  ck(prev==m['head'] and (prior is None or prior==H(json.loads(m['state']))),'STRUCT_HEAD_STATE')
  st=json.loads(m['state']);cycle=st['cycle'];seed=st['seed']
  if quarantine:
   ck(cycle=='R45' and st['phase']=='COUNTER_RESOLVED_TARGET_KO','QUARANTINE_CYCLE')
   ck(rows and rows[0][3].find('DECLARE_COUNTER_BEFORE_INCOMING_ROLL')<0,'CAUSAL_HOLE_NOT_PRESERVED')
   return {'cycle':cycle,'status':'QUARANTINED_CAUSAL_ORDER_UNPROVEN','events':len(rows),'head':prev}
  frozen_hash=check_frozen();gp=ROOT/'evidence'/('GENESIS_'+cycle+'_'+str(seed)+'.json')
  oracle=json.loads(gp.read_text());ck(oracle['r44_46']['frozen_sources_hash']==frozen_hash,'SOURCE_HASH_TAMPER')
  ck(oracle['synthetic'] is True and oracle['version']==RV and oracle['scene']==m['scene'],'GENESIS_WRONG')
  ck(oracle['actors']=={k:oracle['actors'][k] for k in oracle['actors']},'GENESIS_ACTOR_KEYS')
  for key,actor in oracle['actors'].items():
   ck(actor['source_page_id']==EXPECTED[key]['page'] and actor['resource']['hp']==EXPECTED[key]['hp'],'INIT_SOURCE_MISMATCH')
   ck(actor['resource']['reaction']==1 and actor['resource']['standard']==1 and actor['resource']['movement']==1,'INIT_ACTIONS')
  for seq,cmd,ref,raw,rowsha,before,after in rows:
   row=json.loads(raw);ck(H(oracle)==before,'CAUSAL_BEFORE_BAD_'+str(seq))
   progression(oracle,row)
   ck(H(oracle)==after,'CAUSAL_AFTER_BAD_'+str(seq))
   ck(row['synthetic'] is True and row['official_effects']==0,'OFFICIAL_EFFECTS_FORBIDDEN')
  ck(oracle==st,'CAUSAL_STATE_FINAL_BAD');ck(m['scene']==st['scene'],'SCENE_NAME_BAD')
  return {'cycle':cycle,'status':'PASS_CAUSAL_STRUCTURAL_MECHANICAL','seed':seed,'events':len(rows),'head':prev,'hp':{k:x['resource']['hp'] for k,x in st['actors'].items()},'reaction':{k:x['resource']['reaction'] for k,x in st['actors'].items()}}
 finally:co.close()

def all_files(root=ROOT):
 checks=[]
 for n in [('R44',97011),('R45B',97102),('R46',97201)]:
  file=Path(root)/'ledgers'/('%s_SEED%d.sqlite'%n)
  got=audit(file);cp=audit(Path(root)/'checkpoints'/file.name)
  ck(got['head']==cp['head'] and got['hp']==cp['hp'],'CHECKPOINT_NOT_EQUAL')
  checks.append(got)
 quarantine=audit(Path(root)/'ledgers/R45_SEED97101.sqlite',True)
 return {'status':'PASS','episodes':len(checks),'events':sum(x['events'] for x in checks),'checkpoints':len(checks),'legacy_quarantined':quarantine,'scenes':checks,'auditor':'INDEPENDENT_STDLIB_NO_EXECUTOR_OR_R18_IMPORT'}

if __name__=='__main__':
 try:
  print(json.dumps(all_files(),ensure_ascii=False,sort_keys=True,indent=2))
 except Exception as e:
  print('AUDIT_FAIL '+repr(e),file=sys.stderr);sys.exit(2)
