"""R46 independent new pending-intent test; never touch R44/R45/R45B/R46 terminal DBs.
Runs R18 failpoint AFTER_INTENT in isolated subprocess; preserves unknown effect.
"""
from __future__ import annotations
import sys,subprocess,json,sqlite3,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(HERE/'extension'))
import r44_r46_experimental as e
j=e.j

def snapshot(db):
 c=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
 try:
  if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise AssertionError('SQLITE_INTEGRITY')
  m=dict(c.execute('select key,value from meta'))
  return {'revision':int(m['revision']),'head':m['head'],'state':json.loads(m['state']),'events':c.execute('select count(*) from events').fetchone()[0],
          'pending':c.execute('select count(*) from pending').fetchone()[0],
          'pending_ids':[r[0] for r in c.execute('select cmd_id from pending')]}
 finally:c.close()

def run():
 db=e.init_db(97202,'R46')
 e.event(db,'AOO_TRIGGER',{'mover':'G','to':[-1.5,-1.5]},e.request_exit)
 before=snapshot(db)
 cmd='LAB-CMD-R46-FAULT-NEW-97202'
 script="""import sys
sys.path.insert(0,'/mnt/data/vlab_r44_46/extension')
import r44_r46_experimental as e
p=sys.argv[1]
e.j.event_commit(p,'LAB-CMD-R46-FAULT-NEW-97202','AOO_ATTACK',{'actor':'F'},e.aoo_attack,failpoint='AFTER_INTENT')
"""
 proc=subprocess.run([sys.executable,'-c',script,str(db)],text=True,capture_output=True)
 after=snapshot(db)
 if proc.returncode!=78 or after['revision']!=before['revision'] or after['head']!=before['head'] or after['events']!=before['events'] or after['state']!=before['state'] or after['pending']!=1 or after['pending_ids']!=[cmd]:raise AssertionError('FAULT_NONATOMIC_OR_WRONG_STATUS')
 loader=''
 try:j.load(db);raise AssertionError('LOADER_ALLOWED_PENDING')
 except j.LabHold as exc:loader=str(exc)
 assert 'UNKNOWN_EFFECT' in loader
 cp=HERE/'checkpoints'/db.name
 so=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True);de=sqlite3.connect(cp)
 try:so.backup(de)
 finally:so.close();de.close()
 cpstate=snapshot(cp)
 assert cpstate==after
 out={'status':'PASS_PENDING_FAIL_CLOSED','cycle':'R46_FAULT','seed':97202,'sqlite':db.name,
       'worker_exit':proc.returncode,'before':{'revision':before['revision'],'events':before['events'],'pending':before['pending'],'head':before['head'],'hp':{k:v['resource']['hp'] for k,v in before['state']['actors'].items()},'reaction':{k:v['resource']['reaction'] for k,v in before['state']['actors'].items()}},
       'after':{'revision':after['revision'],'events':after['events'],'pending':after['pending'],'head':after['head'],'hp':{k:v['resource']['hp'] for k,v in after['state']['actors'].items()},'reaction':{k:v['resource']['reaction'] for k,v in after['state']['actors'].items()}},
       'load_rejection':loader,'pending_cmd':cmd,'checkpoint_identical':True,'no_retry':True}
 with (HERE/'evidence/R46_FAULT_ISOLATION.json').open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
 return out
if __name__=='__main__':print(json.dumps(run(),indent=2))
