"""R44-R46 negative QA: tamper SQLite clones, rechain hashes, show R18 structural
acceptance can coexist with causal/mechanical rejection by independent oracle.
No original DB modified. Double-command and fault tests use new isolated DBs.
"""
from __future__ import annotations
import copy,json,sqlite3,sys,tempfile,hashlib,subprocess,os
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'extension'),str(Path('/mnt/data/vlab_r42/work/runtime_copy/r27/fusion_stage12')),str(Path('/mnt/data/vlab_r42/work/runtime_copy'))]
import r44_r46_experimental as e
import verify_r44_r46_standalone as audit
j=e.j

def chained_copy(src,dst,kind):
    source=sqlite3.connect('file:'+str(src)+'?mode=ro',uri=True)
    target=sqlite3.connect(dst)
    try:source.backup(target)
    finally:source.close()
    target.execute('PRAGMA journal_mode=DELETE')
    meta=dict(target.execute('select key,value from meta'))
    rows=list(target.execute('select seq,row_json from events order by seq'))
    prev=meta['genesis']
    for seq,raw in rows:
        row=json.loads(raw)
        if kind.startswith('AOO'):
            if row['kind']=='AOO_ATTACK' and (seq==4 or seq==2):
                eff=row['detail']['AOO_ATTACK']
                if kind=='AOO_DIE_7':eff['tape'][0]['results'][0]=7
                elif kind=='AOO_SCORE_WRONG':eff['score']+=3
                elif kind=='AOO_RD_WRONG':eff['rd_applied']-=1
                elif kind=='AOO_NET_WRONG':eff['net']+=1
                elif kind=='AOO_HP_WRONG':eff['after_hp']+=1
                elif kind=='AOO_WRONG_PRIORITY':eff['attacker']='V'
                elif kind=='AOO_PA_EXTRA':eff['pa_per_attack']=30
                elif kind=='AOO_CRITICAL_FALSE':eff['critical_status']='POSITIVE'
                break
        elif kind.startswith('COUNTER') and row['kind']=='COUNTER_BEFORE_ATTACK':
            if kind=='COUNTER_DECLARE_TOO_LATE':row['detail']['stages'][0]['step']='DECLARE_AFTER_INCOMING_ROLL'
            elif kind=='COUNTER_BONUS_FAKE':row['detail']['counter']['attack_bonus']+=6
            elif kind=='COUNTER_REACTION_NOT_CONSUMED':row['detail']['F_reaction_after']=1
            elif kind=='COUNTER_HP_FALSE':row['detail']['counter']['after_hp']=1
            break
        elif kind.startswith('MOVEMENT') and row['kind']=='MOVEMENT_RESOLUTION':
            if kind=='MOVEMENT_COST_ON_KO':row['detail']['movement_state']='SPENT_FAKE'
            break
    else:raise AssertionError('TARGET_MUTATION_MISSING_'+kind)
    # apply changed row & relink all later rows, without altering before/after state SHA.
    target.execute('BEGIN IMMEDIATE');head=meta['genesis']
    for seq,raw in rows:
        data=row if seq==row['seq'] else json.loads(raw)
        data['prev']=head
        sha=audit.H(data)
        target.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(head,audit.canon(data),sha,seq))
        head=sha
    target.execute("UPDATE meta SET value=? WHERE key='head'",(head,));target.commit();target.close()
    return head

def negative_suite():
    cases=[('R44',97011,'AOO_DIE_7'),('R44',97011,'AOO_SCORE_WRONG'),('R44',97011,'AOO_RD_WRONG'),('R44',97011,'AOO_NET_WRONG'),('R44',97011,'AOO_HP_WRONG'),('R44',97011,'AOO_WRONG_PRIORITY'),('R44',97011,'AOO_PA_EXTRA'),('R44',97011,'AOO_CRITICAL_FALSE'),('R45B',97102,'COUNTER_DECLARE_TOO_LATE'),('R45B',97102,'COUNTER_BONUS_FAKE'),('R45B',97102,'COUNTER_REACTION_NOT_CONSUMED'),('R45B',97102,'COUNTER_HP_FALSE'),('R46',97201,'MOVEMENT_COST_ON_KO')]
    out=[]
    with tempfile.TemporaryDirectory(prefix='VLAB_R44_46_MUTATION_COPIES_') as work:
        for cyc,seed,kind in cases:
            src=BASE/'ledgers'/f'{cyc}_SEED{seed}.sqlite';dest=Path(work)/(kind+'.sqlite')
            chained_copy(src,dest,kind)
            structural='FAIL';mechanical='FAIL'
            try:j.load(dest);structural='PASS'
            except Exception as exc:structural='REJECTED_'+str(exc)[:70]
            try:audit.audit(dest);mechanical='PASS_INVALIDLY'
            except Exception as exc:mechanical='REJECTED_'+str(exc)[:95]
            if structural!='PASS' or not mechanical.startswith('REJECTED_'):
                raise AssertionError('MUTANT_DOES_NOT_DISCRIMINATE_'+kind+' '+structural+' '+mechanical)
            out.append({'case':kind,'source_scene':f'{cyc}_SEED{seed}','original_preserved':True,'structural_after_rechain':structural,'independent_mechanical':mechanical})
    return {'count':len(out),'all_discriminated':True,'cases':out}

def check_duplicate():
    original=BASE/'ledgers/R44_SEED97011.sqlite'; temp=Path(tempfile.mkdtemp(prefix='R44_DUP_CLONE_'))/'clone.sqlite'
    src=sqlite3.connect('file:'+str(original)+'?mode=ro',uri=True);dst=sqlite3.connect(temp)
    try:src.backup(dst)
    finally:dst.close();src.close()
    pre=j.load(temp);co=sqlite3.connect(temp);cmd=co.execute('SELECT cmd_id FROM events WHERE seq=4').fetchone()[0];co.close()
    err=None
    try:j.event_commit(temp,cmd,'AOO_ATTACK',{'actor':'F'},lambda *a:None)
    except Exception as ex:err=str(ex)
    post=j.load(temp);cx=sqlite3.connect(temp);pending=cx.execute('SELECT COUNT(*) FROM pending').fetchone()[0];cx.close()
    if not err or 'DUPLICATE' not in err or pre!=post or pending!=0:raise AssertionError('DUPLICATE_GATE_FAILED')
    return {'status':'PASS','rejection':err,'original_id_reuse':'REJECTED','state_unchanged':True,'pending':0,'original_scene_unmodified':True}

if __name__=='__main__':
    result={'mutations':negative_suite(),'duplicate':check_duplicate()}
    target=BASE/'evidence/R44_R46_NEGATIVE_AUDIT.json'
    with target.open('x') as f:json.dump(result,f,indent=2,ensure_ascii=False,sort_keys=True);f.write('\n')
    print(json.dumps({'status':'PASS','mutations':result['mutations']['count'],'duplicate':result['duplicate']['status'],'artifact':str(target)}))
