"""Pure pre-reservation eligibility checks for fresh cmd IDs. Never leave new
UNKNOWN_EFFECT by sending an impossible post-KO attack to R18.event_commit.
"""
from __future__ import annotations
import json,sys,copy
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE/'extension'))
import r44_r46_experimental as e
j=e.j
class Declined(Exception):pass

def assert_legal(st,kind,payload):
    x=st['r44_46'];actors=st['actors']
    if kind=='AOO_ATTACK':
        a=payload.get('actor');req=x['movement_request'];mover=req and req['actor']
        if st['phase']!='AOO_PENDING' or not x['priority_queue']:raise Declined('AOO_WINDOW_NOT_ACTIVE')
        if a!=x['priority_queue'][0]:raise Declined('AOO_PRIORITY_WRONG')
        if actors[a]['resource']['reaction']!=1:raise Declined('REACTION_ALREADY_SPENT')
        if actors[mover]['resource']['hp']<=0:raise Declined('TARGET_KO')
        if any(z['actor']==a and z['reason']=='AOO' for z in x['attack_events']):raise Declined('SEMANTIC_DUPLICATE_AOO')
        return True
    if kind=='MOVEMENT_RESOLUTION':
        if st['phase']!='AOO_PENDING':raise Declined('MOVEMENT_ALREADY_RESOLVED')
        if actors[x['movement_request']['actor']]['resource']['hp']>0 and x['priority_queue']:raise Declined('AOO_UNRESOLVED_FIRST')
        return True
    if kind=='COUNTER_BEFORE_ATTACK':
        if st['phase']!='READY' or actors['F']['resource']['reaction']!=1 or actors['G']['resource']['standard']!=1:
            raise Declined('COUNTER_ALREADY_FINISHED')
        return True
    raise Declined('UNKNOWN_KIND')

def run():
    paths=[('R44',97011,'AOO_ATTACK',{'actor':'F'}),('R44',97011,'MOVEMENT_RESOLUTION',{'status':'CLOSE'}),
       ('R45B',97102,'COUNTER_BEFORE_ATTACK',{'kind':'COUNTER_BEFORE_ATTACK','attacker':'G','defender':'F'}),
       ('R46',97201,'AOO_ATTACK',{'actor':'V'}),('R46',97201,'MOVEMENT_RESOLUTION',{'status':'CLOSE'})]
    results=[]
    for cycle,seed,kind,pay in paths:
        db=BASE/'ledgers'/f'{cycle}_SEED{seed}.sqlite'
        old,head,rev=j.load(db);before=json.dumps(old,sort_keys=True)
        try:assert_legal(old,kind,pay);raise AssertionError('PRE_GATE_ACCEPTED_INVALID_COMMAND')
        except Declined as ex:reason=str(ex)
        after,head2,rev2=j.load(db)
        assert head==head2 and rev==rev2 and json.dumps(after,sort_keys=True)==before
        results.append({'scene':f'{cycle}_SEED{seed}','kind':kind,'new_cmd_id_eligible':False,'before_intent_rejection':reason,'no_new_pending':True})
    out={'status':'PASS','tested':len(results),'originals_unchanged':True,'cases':results}
    with (BASE/'evidence/R46_PRE_RESERVATION_REJECTION.json').open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    return out
if __name__=='__main__':print(json.dumps(run(),indent=2,ensure_ascii=False))
