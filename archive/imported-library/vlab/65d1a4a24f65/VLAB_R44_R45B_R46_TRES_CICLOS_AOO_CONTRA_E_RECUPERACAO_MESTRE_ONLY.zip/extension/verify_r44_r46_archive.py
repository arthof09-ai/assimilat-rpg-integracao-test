"""Portable independent verification of R44-R46 delta ZIP.
Only Python standard library and bundled extracted files; no historical engines.
"""
from __future__ import annotations
import hashlib,json,sqlite3,subprocess,sys,tempfile,zipfile
from pathlib import Path

def check(v,name):
 if not v:raise AssertionError(name)
def audit_fault(root):
 p=root/'ledgers/R46_SEED97202.sqlite';cp=root/'checkpoints/R46_SEED97202.sqlite'
 def state(f):
  co=sqlite3.connect('file:'+str(f)+'?mode=ro',uri=True)
  try:
   check(co.execute('PRAGMA integrity_check').fetchone()[0]=='ok','FAULT_SQLITE_INTEGRITY')
   meta=dict(co.execute('select key,value from meta'));st=json.loads(meta['state'])
   rows=co.execute('SELECT row_json FROM events ORDER BY seq').fetchall()
   check(len(rows)==int(meta['revision'])==1,'FAULT_REVISION')
   check(co.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==1,'FAULT_PENDING')
   pending=co.execute('SELECT cmd_id,kind FROM pending').fetchone()
   check(pending==('LAB-CMD-R46-FAULT-NEW-97202','AOO_ATTACK'),'FAULT_PENDING_ID')
   check(st['actors']['G']['resource']['hp']==38 and st['actors']['F']['resource']['reaction']==1 and st['actors']['V']['resource']['reaction']==1,'FAULT_UNPUBLISHED_DAMAGE')
   check(st['phase']=='AOO_PENDING','FAULT_PHASE')
   return {'rev':int(meta['revision']),'head':meta['head'],'state':st,'pending':pending}
  finally:co.close()
 a=state(p);b=state(cp);check(a==b,'FAULT_CHECKPOINT_MISMATCH');return {'status':'PASS_PENDING_FROZEN','events_before_failure':1,'pending':1,'no_additional_damage':True}

def verify(archive):
 with tempfile.TemporaryDirectory(prefix='VLAB_R44_46_COLD_') as tmp:
  root=Path(tmp)
  with zipfile.ZipFile(archive) as z:
   check(z.testzip() is None,'ZIP_CRC')
   members=z.namelist()
   check(len(set(members))==len(members),'DUPLICATE_ZIP_ENTRY')
   for m in members:check(not m.startswith('/') and '..' not in Path(m).parts,'ZIP_PATH_TRAVERSAL')
   z.extractall(root)
  manifest=json.loads((root/'R44_R46_FILE_MANIFEST.json').read_text());h=manifest['sha256']
  check(len(members)==len(h)+1,'MANIFEST_DENOMINATOR')
  check(set(members)==set(h)|{'R44_R46_FILE_MANIFEST.json'},'UNEXPECTED_FILES')
  for rel,digest in h.items():
   target=root/rel;check(target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest()==digest,'HASH_MISMATCH_'+rel)
  proc=subprocess.run([sys.executable,str(root/'extension/verify_r44_r46_standalone.py')],capture_output=True,text=True,cwd=root)
  check(proc.returncode==0,'INDEPENDENT_ORACLE_FAILED_'+proc.stderr)
  parsed=json.loads(proc.stdout)
  check(parsed['episodes']==3 and parsed['events']==10 and parsed['legacy_quarantined']['cycle']=='R45','WRONG_ACCEPTANCE_COUNTS')
  fault=audit_fault(root)
  neg=json.loads((root/'evidence/R44_R46_NEGATIVE_AUDIT.json').read_text());pre=json.loads((root/'evidence/R46_PRE_RESERVATION_REJECTION.json').read_text())
  check(neg['mutations']['all_discriminated'] and neg['mutations']['count']==13 and neg['duplicate']['status']=='PASS','NEGATIVE_CASE_RECEIPT')
  check(pre['status']=='PASS' and pre['tested']==5,'PREGATE_RECEIPT')
  matrix=json.loads((root/'evidence/R44_R46_CONTRACT_DELTA_17.json').read_text());check(matrix['original_denominator']==17 and len(matrix['rows'])==17 and matrix['terminal_after']==0,'CONTRACT_MATRIX')
  return {'status':'PASS','manifest_hashes':len(h),'zip_entries':len(members),'episodes_causally_verified':parsed['episodes'],
   'event_count_causal':parsed['events'],'checkpoints_verified':parsed['checkpoints'],'quarantined_old_counter':True,
   'fault_intent':fault,'adversarial_receipts':13,'duplicate_command_guard':'PASS','semantic_replay_guard':5,
   'terminal_contracts_certified':0,'canonical_cells':0}
if __name__=='__main__':
 try:
  r=verify(Path(sys.argv[1]));print(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2))
 except Exception as exc:print('ARCHIVE_FAIL '+repr(exc),file=sys.stderr);sys.exit(2)
