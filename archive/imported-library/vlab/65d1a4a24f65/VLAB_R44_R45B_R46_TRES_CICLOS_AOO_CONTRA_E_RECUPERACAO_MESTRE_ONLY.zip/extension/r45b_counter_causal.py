"""R45B additive corrected COUNTER event: explicit pre-attack declaration and consumption
precede RNG of the incoming attack. R45 original numerical fixture is quarantined for
causal correctness, preserved byte-for-byte. No game/campaign execution.
"""
from __future__ import annotations
import copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'extension'))
import r44_r46_experimental as e
j=e.j
class Hold(Exception):pass

def state(seed):
    st=e.initial(seed,'R45')
    st['cycle']='R45B';st['scene']='R45B-SCENE-'+str(seed)
    st['actors']['G']['position']=[0.,0.];st['actors']['F']['position']=[1.5,0.]
    st['r44_46']['declaration_order_policy']='BEFORE_RNG_INCOMING_ATTACK'
    return st

def init(seed):
    p=ROOT/'ledgers'/('R45B_SEED'+str(seed)+'.sqlite')
    j.init_db(p,'A',seed)
    st=state(seed)
    genesis=e.H({'schema':e.VERSION,'cycle':'R45B','seed':seed,'source':st['r44_46']['frozen_sources_hash'],'declared':'BEFORE_INCOMING_ROLL'})
    co=j.connect(p)
    try:
        co.execute('BEGIN IMMEDIATE')
        for k,v in [('state',j.canonical(st)),('scene',st['scene']),('genesis',genesis),('head',genesis)]:
            co.execute('UPDATE meta SET value=? WHERE key=?',(v,k))
        co.commit()
    except:co.rollback();raise
    finally:co.close()
    with (ROOT/'evidence'/('GENESIS_R45B_'+str(seed)+'.json')).open('x') as f:f.write(j.canonical(st)+'\n')
    return p

def execute(st,p,seq):
    if p!={'kind':'COUNTER_BEFORE_ATTACK','attacker':'G','defender':'F'} or st['phase']!='READY' or seq!=1:raise Hold('NO_COUNTER_WINDOW')
    G=st['actors']['G']['resource'];F=st['actors']['F']['resource']
    if G['hp']<=0 or F['hp']<=0 or G['standard']!=1 or F['reaction']!=1:raise Hold('RESOURCES_NOT_AVAILABLE')
    # Stage 1: own reaction DECLARED before caller knows what incoming RNG will yield.
    before_reaction=F['reaction'];F['reaction']=0
    stages=[{'ordinal':1,'step':'DECLARE_COUNTER_BEFORE_INCOMING_ROLL','F_reaction_before':before_reaction,'F_reaction_after':0,'cause':'ENEMY_ANNOUNCES_ADJACENT_INVESTIDA'}]
    # Stage 2: only now consume the incoming dice/critical stream.
    attack=e.roll_attack(st,'G','F','INVESTIDA')
    stages.append({'ordinal':2,'step':'ROLL_AND_RESOLVE_INCOMING','score':attack['score'],'critical':attack['critical_status'],'hit':attack['hit']})
    G['standard']=0;attack.update({'before_hp':F['hp'],'after_hp':F['hp']})
    # Against Feryn CA123 the nonpositive goat attack always misses. If positive
    # auto-hit, the announced COUNTER is consumed without a triggered counterstrike.
    if attack['hit']:
        stages.append({'ordinal':3,'step':'COUNTER_TRIGGER_NOT_MET','F_reaction':0})
        st['r44_46']['attack_events'].append({'actor':'G','target':'F','reason':'INVESTIDA','result':attack})
        st['r44_46']['issued_attack_ids'].append(attack['tag'])
        st['phase']='COUNTER_DECLARED_BUT_NO_RESPONSE'
        return {'stages':stages,'incoming':attack,'counter':None,'reaction_was_consumed_BEFORE_roll':True,'official_effects':0}
    # Stage 3: legal reply with sourced Feryn equipped normal attack + Advantage.
    counter=e.roll_attack(st,'F','G','COUNTER')
    before=G['hp'];G['hp']=max(0,before-counter['net']);counter.update({'before_hp':before,'after_hp':G['hp']})
    stages.append({'ordinal':3,'step':'COUNTER_TRIGGERED_BY_MISS','inbound_score':attack['score'],'F_ca':e.SOURCES['F']['ca']})
    stages.append({'ordinal':4,'step':'COUNTER_NORMAL_EQUIPPED_WEAPON_WITH_ADVANTAGE','counter_score':counter['score'],'counter_damage':counter['net'],'G_hp_after':G['hp']})
    st['r44_46']['attack_events'].extend([{'actor':'G','target':'F','reason':'INVESTIDA','result':attack},{'actor':'F','target':'G','reason':'COUNTER','result':counter}])
    st['r44_46']['issued_attack_ids'].extend([attack['tag'],counter['tag']])
    st['phase']='COUNTER_PROPERLY_RESOLVED_TARGET_KO' if G['hp']==0 else 'COUNTER_PROPERLY_RESOLVED_TARGET_ALIVE'
    return {'stages':stages,'incoming':attack,'counter':counter,'reaction_was_consumed_BEFORE_roll':True,
       'G_standard_after':G['standard'],'F_reaction_after':F['reaction'],'F_standard_after':F['standard'],'official_effects':0}

def run(seed):
    db=init(seed)
    e.event(db,'COUNTER_BEFORE_ATTACK',{'kind':'COUNTER_BEFORE_ATTACK','attacker':'G','defender':'F'},execute)
    cp=e.checkpoint(db)
    st,head,rev=j.load(db)
    return {'seed':seed,'events':rev,'head':head,'phase':st['phase'],'hp':{k:v['resource']['hp'] for k,v in st['actors'].items()},'reaction':{k:v['resource']['reaction'] for k,v in st['actors'].items()},'checkpoint':str(cp)}

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--seed',type=int,required=True);o=a.parse_args()
    print(json.dumps(run(o.seed),indent=2))
