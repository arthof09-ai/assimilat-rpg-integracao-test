"""R44/R45/R46: THREE NEW LAB EXPERIMENT CYCLES. Old modules never edited.
Real documented NPC equipped source profiles F/V/R, goat-specific INVESTIDA G;
R18 deterministic experimental RNG and durable SQLite; R26 tie_order/refresh.
AOOs/Counter: new additive reaction adapter, NOT historical v0.8.1 native counter.
"""
from __future__ import annotations
import copy,hashlib,json,math,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/mnt/data/vlab_r42/work/runtime_copy')
R27=BASE/'r27/fusion_stage12'
sys.path[:0]=[str(R27),str(BASE)]
import vlab_r18_interactive as j
import vlab_r26_master_rulings as r26
SOURCES=json.loads((ROOT/'evidence/R44_R46_FROZEN_MASTER_SOURCE.json').read_text())['sources']
VERSION='R44_R46_SOURCE_EQUIPPED_REACTION_ADAPTER_V1'
class Hold(Exception):pass

def H(x):return hashlib.sha256(j.canonical(x).encode()).hexdigest()

def initial(seed,cycle):
    template=j.initial('A',seed)
    who={'R44':['F','V','R'],'R45':['G','F'],'R46':['F','V','G']}[cycle]
    if len(set(who))!=len(who):raise Hold('DUPLICATE_ACTORS')
    t=copy.deepcopy(template)
    t.update({'scene':cycle+'-SCENE-'+str(seed),'cycle':cycle,'phase':'READY',
      'seed':seed,'round':1,'turn':0,'active':None,'order':[],'winner':None,
      'actors':{k:{'source_page_id':SOURCES[k]['page'],'resource':{'hp':SOURCES[k]['hp'],'pa_delta':0,'reaction':1,'standard':1,'movement':1},'position':{'F':[1.5,0.], 'V':[0.,1.5], 'R':[0.,0.], 'G':[0.,0.]}[k]} for k in who},
      'r44_46':{'schema':VERSION,'frozen_sources_hash':H(json.loads((ROOT/'evidence/R44_R46_FROZEN_MASTER_SOURCE.json').read_text())),
                  'world_effects':0,'dice_kind':'R18_DETERMINISTIC_EXPERIMENTAL_NOT_CANONICAL',
                  'turn_log':[],'movement_request':None,'priority_queue':[],'attack_events':[],
                  'attack_indices':{k:0 for k in who},'issued_attack_ids':[],
                  'blocked_uncertainties':[],'movement_completed':False,'movement_cost_uncertain_on_KO':False}})
    return t

def init_db(seed,cycle):
    p=ROOT/'ledgers'/(cycle+'_SEED'+str(seed)+'.sqlite')
    j.init_db(p,'A',seed)
    con=j.connect(p)
    try:
        st=initial(seed,cycle)
        base=H({'schema':VERSION,'cycle':cycle,'seed':seed,'sources':st['r44_46']['frozen_sources_hash']})
        con.execute('BEGIN IMMEDIATE')
        for key,val in [('scene',st['scene']),('state',j.canonical(st)),('genesis',base),('head',base)]:
            con.execute('UPDATE meta SET value=? WHERE key=?',(val,key))
        con.commit()
    except:con.rollback();raise
    finally:con.close()
    gp=ROOT/'evidence'/('GENESIS_'+cycle+'_'+str(seed)+'.json')
    with gp.open('x') as f:f.write(j.canonical(st)+'\n')
    return p

def rng(st,label,count,faces,index=1):
    result=j.dice(st['seed'],index,label,count,faces)
    return {'label':label,'index':index,'count':count,'faces':faces,'results':result}

def roll_attack(st,attacker, target, reason):
    a=SOURCES[attacker]
    if reason in ('AOO','COUNTER') and attacker=='G':raise Hold('GOAT_NORMAL_LUTA_NOT_AUTHORIZED')
    if reason=='INVESTIDA' and attacker!='G':raise Hold('INVESTIDA_ONLY_GOAT')
    st['r44_46']['attack_indices'][attacker]+=1
    idx=st['r44_46']['attack_indices'][attacker]
    tag=st['cycle']+'-'+reason+'-'+attacker+'-'+target+'-'+str(idx)
    tape=[rng(st,tag+'-CRIT-'+str(k),1,6,idx) for k in (1,2,3)]
    crit=[x['results'][0] for x in tape]
    pos=crit[:2]==[6,6] and crit[2] in [5,6]
    neg=crit[:2]==[1,1] and crit[2] in [1,2]
    if reason=='INVESTIDA':
        attack=[rng(st,tag+'-HIT-1',1,6,idx)]; bonus=19
    else:
        attack=[rng(st,tag+'-HIT-'+str(i),a['rank_dice'][0],6,idx) for i in (1,2)];bonus=a['attack_bonus']+2
    tape+=attack
    attack_sums=[sum(t['results']) for t in attack]
    score=max(attack_sums)+bonus
    damage=rng(st,tag+'-DAMAGE',*a['damage_dice'],index=idx);tape.append(damage)
    raw=sum(damage['results'])+a['damage_bonus']+(a['damage_dice'][0]*a['damage_dice'][1] if pos else 0)
    defender=SOURCES[target]
    hit=False if neg else (pos or score>defender['ca'])
    effective=max(0,raw-defender['rd']) if hit else 0
    return {'tag':tag,'reason':reason,'attacker':attacker,'target':target,
      'source_page_id':a['page'],'normal_luta_source':None if attacker=='G' else a['luta_bonus'],
      'attack_bonus':bonus,'attack_sums':attack_sums,'score':score,'ca':defender['ca'],
      'critical_dice':crit,'critical_status':'POSITIVE' if pos else 'NEGATIVE' if neg else 'NONE',
      'hit_reason':'POSITIVE_AUTO_HIT' if pos else 'NEGATIVE_AUTOMATIC_MISS' if neg else 'NUMERIC_HIT' if hit else 'NUMERIC_MISS',
      'hit':bool(hit),'damage_dice':damage['results'],'damage_formula':str(a['damage_dice'][0])+'d'+str(a['damage_dice'][1])+'+'+str(a['damage_bonus']),
      'raw':raw,'rd_applied':min(raw,defender['rd']) if hit else 0,'net':effective,
      'tape':tape,'advantage_level':0 if reason=='INVESTIDA' else 1,
      'resource_cost':('ONE_STANDARD' if reason=='INVESTIDA' else 'ONE_REACTION'),
      'pa_per_attack':0,'canonical_credit':0}

def apply_attack(st,attacker,target,reason):
    if attacker not in st['actors'] or target not in st['actors'] or attacker==target:raise Hold('INVALID_ACTORS')
    a=st['actors'][attacker]['resource'];d=st['actors'][target]['resource']
    if a['hp']<=0 or d['hp']<=0:raise Hold('KO_TARGET_OR_ATTACKER')
    if math.dist(st['actors'][attacker]['position'],st['actors'][target]['position'])>1.500001:raise Hold('NON_ADJACENT')
    if reason=='INVESTIDA' and a['standard']!=1:raise Hold('STANDARD_SPENT')
    if reason in ('COUNTER','AOO') and a['reaction']!=1:raise Hold('REACTION_SPENT')
    result=roll_attack(st,attacker,target,reason)
    before=d['hp'];d['hp']=max(0,before-result['net']);result.update({'before_hp':before,'after_hp':d['hp']})
    if reason=='INVESTIDA':a['standard']=0
    else:a['reaction']=0
    st['r44_46']['attack_events'].append({'actor':attacker,'target':target,'reason':reason,'result':result})
    st['r44_46']['issued_attack_ids'].append(result['tag'])
    return result

def init_turns(st,p,seq):
    if st['cycle']!='R44' or st['phase']!='READY' or seq!=1:raise Hold('INIT_NOT_ADMITTED')
    rows=[];tape=[]
    for aid in sorted(st['actors']):
        s=SOURCES[aid];r=rng(st,'R44-INIT-'+aid,s['rank_dice'][0],s['rank_dice'][1],0)
        tape.append(r);rows.append({'id':aid,'total':sum(r['results'])+s['initiative_bonus'],'des':s['des']})
    def reroll(aid,k):
        s=SOURCES[aid];r=rng(st,'R44-INIT-TIE-'+aid,s['rank_dice'][0],s['rank_dice'][1],k)
        tape.append(r);return sum(r['results'])+s['initiative_bonus']
    tie=r26.tie_order(rows,reroll);st['order']=tie['order'];st['phase']='TURN';st['active']=st['order'][0];st['round']=1;st['turn']=0
    st['r44_46']['turn_log'].append({'round':1,'active':st['active'],'kind':'INIT'})
    refresh=r26.refresh_own_turn(st,st['active'])
    return {'initiative':rows,'rng':tape,'tie_order':tie,'active':st['active'],'refresh':refresh,'scope':'MULTI_ACTOR_ACTUAL_EQUIPPED_SOURCES'}

def pass_turn(st,p,seq):
    if st['cycle']!='R44' or st['phase']!='TURN' or st['active']==p['mover'] or st['active']!=p['actor']:raise Hold('WRONG_PASS_TURN')
    past=st['active'];st['turn']=(st['turn']+1)%len(st['order']);st['active']=st['order'][st['turn']]
    if st['turn']==0:st['round']+=1
    st['r44_46']['turn_log'].append({'round':st['round'],'active':st['active'],'kind':'VOLUNTARY_WAIT'})
    ref=r26.refresh_own_turn(st,st['active'])
    return {'old_active':past,'new_active':st['active'],'round':st['round'],'refresh':ref,'note':'other NPCs voluntarily end own turns without attacks'}

def request_exit(st,p,seq):
    if st['cycle'] not in ('R44','R46') or st['phase'] not in ('TURN','READY'):raise Hold('WRONG_PHASE_MOVEMENT')
    mover=p['mover']
    if mover not in st['actors']:raise Hold('MOVER_MISSING')
    if st['cycle']=='R44' and st['active']!=mover:raise Hold('NOT_MOVERS_TURN')
    if st['actors'][mover]['resource']['hp']<=0 or st['actors'][mover]['resource']['movement']!=1:raise Hold('MOVER_UNAVAILABLE')
    here=st['actors'][mover]['position'];destination=p['to']
    if here!=[0.,0.] or destination!=[-1.5,-1.5]:raise Hold('GEOMETRY_MISMATCH')
    eligible=[]
    for aid,a in st['actors'].items():
        if aid==mover:continue
        if (a['resource']['hp']>0 and a['resource']['reaction']==1 and
            math.dist(here,a['position'])<=1.500001 and math.dist(destination,a['position'])>1.500001):eligible.append(aid)
    if len(eligible)!=2:raise Hold('NOT_TWO_AOO_TRIGGERS')
    # Mestre's priority: DES, then R26 tie-order. For this scene DES are distinct.
    if len(set(SOURCES[a]['des'] for a in eligible))!=len(eligible):raise Hold('R44_SOURCE_TIE_REQUIRES_DICE_WINDOW')
    queue=sorted(eligible,key=lambda k:SOURCES[k]['des'],reverse=True)
    st['r44_46']['movement_request']={'actor':mover,'start':here[:],'to':destination[:], 'voluntary':True,'triggered':eligible[:], 'priority':queue[:], 'not_yet_moved':True}
    st['r44_46']['priority_queue']=queue[:];st['phase']='AOO_PENDING'
    return {'movement_request':copy.deepcopy(st['r44_46']['movement_request']),'ordered_by':'MESTRE_R43_DESCENDING_DEX','reaction_spent':0,'hp_changed':False}

def aoo_attack(st,p,seq):
    if st['phase']!='AOO_PENDING':raise Hold('WRONG_AOO_PHASE')
    aid=st['r44_46']['priority_queue'][0];target=st['r44_46']['movement_request']['actor']
    if aid!=p['actor']:raise Hold('AOO_PRIORITY_VIOLATION')
    if st['actors'][target]['resource']['hp']<=0:raise Hold('TARGET_ALREADY_KO_NO_AOO')
    effect=apply_attack(st,aid,target,'AOO')
    st['r44_46']['priority_queue'].pop(0)
    return {'AOO_ATTACK':effect,'remaining_queue':st['r44_46']['priority_queue'][:],
      'movement_not_yet_completed':True,'target_KO':st['actors'][target]['resource']['hp']<=0,
      'no_extra_standard_spent':True,'official_effects':0}

def close_move(st,p,seq):
    if st['phase']!='AOO_PENDING' or st['r44_46']['priority_queue'] and st['actors'][st['r44_46']['movement_request']['actor']]['resource']['hp']>0:raise Hold('ATTACK_QUEUE_INCOMPLETE')
    req=st['r44_46']['movement_request'];target=req['actor'];r=st['actors'][target]['resource'];unspent=st['r44_46']['priority_queue'][:]
    if r['hp']==0:
        st['phase']='LAB_KO_DURING_AOO_MOVEMENT_UNFINISHED'
        st['r44_46']['blocked_uncertainties'].append('DEAD_MOVERS_MOVEMENT_COST_NOT_GROUNDED')
        st['r44_46']['movement_cost_uncertain_on_KO']=True
        return {'status':'KO_BEFORE_MOVEMENT_COMPLETED','remaining_unspent_reactions':{a:st['actors'][a]['resource']['reaction'] for a in unspent},'not_acted':unspent,'movement_state':'UNRESOLVED_MOVEMENT_COST_NO_CANONICAL_CREDIT'}
    if unspent:raise Hold('LIVE_MOVER_QUEUE_NOT_EMPTY')
    if r['movement']!=1:raise Hold('MOVEMENT_ALREADY_SPENT')
    r['movement']=0;st['actors'][target]['position']=req['to'][:];st['r44_46']['movement_completed']=True
    st['phase']='AOO_WINDOW_CLOSED_LAB';return {'status':'MOVED_AFTER_TWO_RESOLVED_AOO','to':req['to'][:],'movement_spent':1,'reaction_spent_attacker':{a:st['actors'][a]['resource']['reaction'] for a in req['priority']}}

def counter_transaction(st,p,seq):
    if st['cycle']!='R45' or st['phase']!='READY':raise Hold('COUNTER_INVALID_PHASE')
    if p!={'kind':'COUNTER_SEQUENCE','attacker':'G','defender':'F'}:raise Hold('WRONG_COUNTER_PRECONDITIONS')
    if st['actors']['F']['resource']['reaction']!=1 or st['actors']['G']['resource']['standard']!=1:raise Hold('NO_REACTION_OR_STANDARD')
    if math.dist(st['actors']['F']['position'],st['actors']['G']['position'])>1.500001:raise Hold('NOT_ADJACENT')
    # BEFORE_ATTACK counter declaration consumes reaction as part of this single atomic event.
    attacking=roll_attack(st,'G','F','INVESTIDA')
    if attacking['critical_status']=='POSITIVE':raise Hold('CRIT_AUTOHIT_COUNTER_TIMING_NOT_YET_ADMITTED')
    if attacking['score']>SOURCES['F']['ca']:raise Hold('COUNTER_TRIGGER_NOT_MET')
    if attacking['hit']:raise Hold('IMPOSSIBLE_GOAT_NORMAL_HIT_VS_FERYN')
    ar=st['actors']['G']['resource'];dr=st['actors']['F']['resource']
    ar['standard']=0;dr['reaction']=0
    attacking.update({'before_hp':dr['hp'],'after_hp':dr['hp']})
    # Counter-response is a NORMAL WEAPON ATTACK with one advantage, not Investida.
    counter=roll_attack(st,'F','G','COUNTER')
    before=ar['hp'];ar['hp']=max(0,before-counter['net']);counter.update({'before_hp':before,'after_hp':ar['hp']})
    st['r44_46']['attack_events'].extend([{'actor':'G','target':'F','reason':'INVESTIDA','result':attacking}, {'actor':'F','target':'G','reason':'COUNTER','result':counter}])
    st['r44_46']['issued_attack_ids'].extend([attacking['tag'],counter['tag']])
    st['phase']='COUNTER_RESOLVED_TARGET_KO' if ar['hp']==0 else 'COUNTER_RESOLVED_TARGET_ALIVE'
    return {'declaration':'COUNTER_ATTACK_BEFORE_INCOMING_ATTACK','trigger':'GOAT_SCORE_LESS_THAN_OR_EQUAL_FERYN_CA',
      'incoming':attacking,'counter':counter,'one_atomic_reaction_transaction':True,
      'goat_standard_after':ar['standard'],'feryn_reaction_after':dr['reaction'], 'feryn_standard_preserved':True,
      'counter_without_extra_pa':True,'official_effects':0}

def event(db,kind,p,runner):
    st,head,rev=j.load(db)
    cmd='LAB-CMD-'+st['cycle']+'-'+H({'kind':kind,'head':head,'payload':p})[:29]
    row=j.event_commit(db,cmd,kind,p,runner)
    j.load(db)
    return row

def checkpoint(db):
    # Logical SQLite backup with WAL state, never filesystem copy of live SQLite.
    dest=ROOT/'checkpoints'/Path(db).name
    if dest.exists():raise Hold('CHECKPOINT_ALREADY_EXISTS')
    src=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True);dst=sqlite3.connect(dest)
    try:src.backup(dst)
    finally:dst.close();src.close()
    return dest

def run_cycle(cycle,seed):
    db=init_db(seed,cycle)
    if cycle=='R44':
        event(db,'INIT',{'kind':'INIT'},init_turns)
        while True:
            st,head,rev=j.load(db)
            if st['active']=='R':break
            event(db,'TURN_WAIT',{'actor':st['active'],'mover':'R'},pass_turn)
        event(db,'AOO_TRIGGER',{'mover':'R','to':[-1.5,-1.5]},request_exit)
        for aid in ['F','V']:
            event(db,'AOO_ATTACK',{'actor':aid},aoo_attack)
        event(db,'MOVEMENT_RESOLUTION',{'status':'CLOSE'},close_move)
    elif cycle=='R45':
        # R45 is a SOURCE-COMPLETE REACTION WINDOW, not full goat initiative or combat.
        st,head,rev=j.load(db);st['actors']['G']['position']=[0.,0.];st['actors']['F']['position']=[1.5,0.]
        # Persist positions in genesis before first event; must not mutate an evented DB.
        co=j.connect(db)
        try:
            co.execute('BEGIN IMMEDIATE');co.execute('UPDATE meta SET value=? WHERE key=?',(j.canonical(st),'state'));co.commit()
        finally:co.close()
        gp=ROOT/'evidence'/('GENESIS_'+cycle+'_'+str(seed)+'.json');gp.write_text(j.canonical(st)+'\n')
        event(db,'COUNTER_ATOMIC',{'kind':'COUNTER_SEQUENCE','attacker':'G','defender':'F'},counter_transaction)
    elif cycle=='R46':
        # Scope: source-derived window with no assertion of goat's unknown initiative bonus.
        event(db,'AOO_TRIGGER',{'mover':'G','to':[-1.5,-1.5]},request_exit)
        event(db,'AOO_ATTACK',{'actor':'F'},aoo_attack)
        st,head,rev=j.load(db)
        if st['actors']['G']['resource']['hp']!=0:raise Hold('R46_EXPECT_LETHAL_FIRST_AOO')
        event(db,'MOVEMENT_RESOLUTION',{'status':'CLOSE'},close_move)
    else:raise Hold('UNKNOWN_CYCLE')
    checkpoint(db)
    st,head,rev=j.load(db)
    return {'cycle':cycle,'seed':seed,'sqlite':str(db),'events':rev,'head':head,'phase':st['phase'],'hp':{k:v['resource']['hp'] for k,v in st['actors'].items()},'reaction':{k:v['resource']['reaction'] for k,v in st['actors'].items()},'positions':{k:v['position'] for k,v in st['actors'].items()},'event_types':[r['kind'] for r in j.history(db)['events']]}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('cycle',choices=['R44','R45','R46']);ap.add_argument('--seed',type=int,required=True)
    a=ap.parse_args();print(json.dumps(run_cycle(a.cycle,a.seed),ensure_ascii=False,indent=2))
