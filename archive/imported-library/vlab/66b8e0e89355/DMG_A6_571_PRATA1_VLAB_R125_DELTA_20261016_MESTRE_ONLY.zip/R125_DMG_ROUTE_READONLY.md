# VLAB R125 — Handoff científico à operação DMG existente (MESTRE-ONLY)

**STATUS:** PREPARADO LOCALMENTE / ACK DMG AUSENTE / NO WRITE NO DOMÍNIO DMG.

- Arquivo novo `R125_NATIVE_RECEIPTS_165_FOR_DMG.csv`: 165 ocorrências técnicas (152 ataques normais + 13 respostas de contra-ataque), seis cenas, sementes 918201, 918515, 928801, 938211, 938311 e 938411.
- R119 3/3 cenas completas; R124 10x10 e 20x20 completos; 5x5 censurado por falha crítica sem consequência antes do intent.
- Cada registro mantém RUN-ID, seed, tipo, atacante/alvo, fonte Mestre-only, bruto, RD física, efetivo, Vida retirada, overkill e crítico.
- Feryn é NPC Ouro Negro 5 sem Espírito Demoníaco; dois perfis são repetidos em até 40 instâncias técnicas. Nenhuma equivalência de potência ED/Bestas, nenhuma probabilidade de vitória generalizável.
- Não concatenar com R97 1344 ou R116 212 sem reconciliar fonte, versão, classe, política, censura e unidade de análise.
- **Histórico:** R97 mantém errata de 6 críticos R93/R95 e `TECHNICAL_REPLAY_PASS / NORMATIVE_PARITY_HOLD`; R116 contém 212 recibos base R117 e handoff não aceito. Ambos residem no ZIP R117 imutável embutido no pacote R125.
- **Oficial:** DMG-RANK-01 v1.1 não alterado; sem ACK, sem writer DMG, sem importação para corpus oficial.
