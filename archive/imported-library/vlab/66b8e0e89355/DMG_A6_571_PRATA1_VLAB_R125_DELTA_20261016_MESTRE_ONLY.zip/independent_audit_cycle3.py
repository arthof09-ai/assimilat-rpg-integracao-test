#!/usr/bin/env python3
"""Independent cold checker with direct Cartesian product enumeration; no game engine imports."""
from pathlib import Path
import csv,hashlib,itertools,json,zipfile,math,collections
p=Path(__file__).parent
A=json.loads((p/'A6_571_CROSSWALK_CERTIFICATE.json').read_text(encoding='utf8'))
rows=list(csv.DictReader((p/'A6_CROSSWALK_571_UUIDS_TWO_DEPTHS_RECONSTRUCTED.csv').open(encoding='utf8')))
assert len(rows)==571
ids=[r['uuid'] for r in rows]
assert len(set(ids))==571
assert sum(r['depth']=='1' for r in rows)==332
assert sum(r['depth']=='2' for r in rows)==239
B=json.loads((p/'SCIENCE_PRATA1_4_PAGES_EXACT.json').read_text(encoding='utf8'))
C=list(csv.DictReader((p/'SCIENCE_PRATA1_ALL_RD_CURVES.csv').open(encoding='utf8')))
assert len(B['observations'])==4
assert len(C)==163
cases=0;checks=0
for r in B['observations']:
 vals=[sum(q)+r['attribute_value']+r['fixed'] for q in itertools.product(*(range(1,d+1) for d in r['dice']))]
 assert len(vals)==r['n_outcomes'];checks+=1
 assert math.isclose(sum(vals)/len(vals),r['mean_bruto'],abs_tol=1e-12);checks+=1
 assert collections.Counter(map(str,vals))==r['distribution_counts'];checks+=1
 g=[x for x in C if x['source_page_id']==r['id']]
 for y in g:
  rd=int(y['rd']);li=[max(0,n-rd) for n in vals]
  assert math.isclose(sum(li)/len(li),float(y['expected_post_rd']),abs_tol=1e-12);checks+=1
  assert sum(n>0 for n in li)==int(y['positive_outcomes']);checks+=1
  assert math.isclose(sum(n>0 for n in li)/len(li),float(y['probability_positive']),abs_tol=1e-12);checks+=1
  cases+=1
D=json.loads((p/'VLAB_R125_165_READONLY_DMG_AUDIT.json').read_text(encoding='utf8'))
rs=list(csv.DictReader((p/'vlab_r125/R125_NATIVE_RECEIPTS_165_FOR_DMG.csv').open(encoding='utf8')))
assert len(rs)==165 and D['events']==165
assert D['shared_run_ids_with_R116']==[]
for x in rs:
 raw,rd,post,hp,over=[int(x[k]) for k in ['raw','rd_applied','effective_post_rd','hp_loss_actual','overkill']]
 assert max(raw-rd,0)==post; checks+=1
 assert post==hp+over; checks+=1
 assert int(x['hp_before'])-int(x['hp_after'])==hp; checks+=1
assert sum(int(x['raw']) for x in rs)==D['stats_total']['raw'];checks+=1
assert sum(int(x['rd_applied']) for x in rs)==D['stats_total']['rd_applied'];checks+=1
assert sum(int(x['effective_post_rd']) for x in rs)==D['stats_total']['post_rd'];checks+=1
assert sum(int(x['hp_loss_actual']) for x in rs)==D['stats_total']['actual_life_lost'];checks+=1
assert sum(int(x['overkill']) for x in rs)==D['stats_total']['overkill'];checks+=1
zpath=p/'vlab_r125/VLAB_R118_R125_REACOES_SCHEDULER_ESCALA_MESTRE_ONLY.zip'
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 M=json.loads(z.read('SHA256_FILE_MANIFEST_R125.json'))['manifest']
 for name,meta in M.items():
  b=z.read(name);assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'];checks+=1
 assert z.read('r118_r125/R125_NATIVE_RECEIPTS_165_FOR_DMG.csv')==(p/'vlab_r125/R125_NATIVE_RECEIPTS_165_FOR_DMG.csv').read_bytes();checks+=1
 assert len(M)==242
res={'operation':'OP-DMG-CORPUS-EMP-01','method':'Independent brute force, exact UUID/CSV membership, ledger checks and SHA256 manifest verification','status':'PASS','a6_unique_ids':571,'a6_parent_direct':332,'a6_beast_branches':239,'a6_intersection':0,'prata1_sources':4,'exact_RD_cells':cases,'r125_receipts':165,'r125_manifest_members':242,'checks':checks,'f0_formal':'4/8 unchanged','a5_raw_attachment_readbacks':'0/7 blocked','scope':'technical integrity, not normative independent coder or holdout certification'}
(p/'INDEPENDENT_COLD_AUDIT_CYCLE3.json').write_text(json.dumps(res,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
print(json.dumps(res,ensure_ascii=False,indent=2))
