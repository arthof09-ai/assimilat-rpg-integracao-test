#!/usr/bin/env python3
"""Master-side read-only science: R04 Prata 1 rank-consistent cohort and VLAB R125 native ledger.
Do not import/write VLAB. No normative revisions.
"""
from pathlib import Path
import csv,json,hashlib,collections,itertools,statistics,math
P=Path(__file__).parent
S=[
 {'id':'206c2b324ede835383a1818a6edd5273','creature':'Águia Arranha Céu','page_body_name':'arranha céus','ability':'Raio paralisante','formula':'1d4+INT','dice':[4],'attribute':'INT','attribute_value':30,'fixed':0,'last_edited_at':'2026-10-01T18:00:49.453Z','parent_rank':'Prata 1 · 1','note':'Fortitude paralisante excluída de dano'},
 {'id':'4bac2b324ede8321af6b01eb96452d04','creature':'Lupusventus','page_body_name':'lobo da caverna','ability':'Patada','formula':'2d6+FOR','dice':[6,6],'attribute':'FOR','attribute_value':25,'fixed':0,'last_edited_at':'2026-10-01T18:00:45.677Z','parent_rank':'Prata 1 · 2','note':'Texto do corpo contém nomenclatura divergente do ancestral; rank confere'},
 {'id':'474c2b324ede82d08ea6819069c17043','creature':'Concha Marinha','page_body_name':'Concha Marinha Luminosa','ability':'Mordida','formula':'3d6+FOR','dice':[6,6,6],'attribute':'FOR','attribute_value':30,'fixed':0,'last_edited_at':'2026-10-01T18:00:39.179Z','parent_rank':'Prata 1 · 1','note':'Descrita como inanimada na própria ficha; existência de ataque contraditória para combate legal'},
 {'id':'725c2b324ede8301baed01d62bd2b8e0','creature':'Tigre Dente de Sabre','page_body_name':'Tigris Sombrio','ability':'Presas Fantasmais','formula':'2d6+FOR','dice':[6,6],'attribute':'FOR','attribute_value':24,'fixed':0,'last_edited_at':'2026-10-01T18:01:00.789Z','parent_rank':'Prata 1 · 3','note':'Paralisia por medo não precificada no dano bruto'},
]
assert len({x['id'] for x in S})==4
RDS=[0,15,25,30,31,32,33,34,35,36,37,38,40,42,45,48,50]
def dist(dice,bonus):
 c=collections.Counter({0:1})
 for sides in dice:
  q=collections.Counter()
  for val,ct in c.items():
   for face in range(1,sides+1):q[val+face]+=ct
  c=q
 return {k+bonus:v for k,v in sorted(c.items())}
def metrics(d,rd):
 n=sum(d.values());return {'expected_post_rd':sum(max(k-rd,0)*v for k,v in d.items())/n,'positive_outcomes':sum(v for k,v in d.items() if k>rd),'sample_space':n,'probability_positive':sum(v for k,v in d.items() if k>rd)/n,'support_min':min(d),'support_max':max(d)}
record=[];curve=[]
for x in S:
 d=dist(x['dice'],x['attribute_value']+x['fixed'])
 x['url']='https://app.notion.com/p/'+x['id']
 x['rank_body']='Prata 1';x['rank_title']='Prata 1';x['rank_ancestor']='Prata 1'
 x['source_classification']='CONSISTENT_RANK_PAGE_TITLE_BODY_ANCESTOR';x['cost_pa']='UNSPECIFIED';x['hit_model']='UNSPECIFIED';x['rd_domain']='SCALAR_HYPOTHETICAL_NOT_TYPE_ASSIGNED'
 x['intrinsic_dice_mean']=sum((s+1)/2 for s in x['dice']);x['mean_bruto']=sum(k*v for k,v in d.items())/sum(d.values());x['attribute_fraction_of_gross']=x['attribute_value']/x['mean_bruto'];x['support_min']=min(d);x['support_max']=max(d)
 x['distribution_counts']={str(k):v for k,v in d.items()};x['n_outcomes']=sum(d.values());record.append(x)
 for rd in range(0,max(d)+2):curve.append({'source_page_id':x['id'],'ability':x['ability'],'rd':rd,**metrics(d,rd)})
summary={'scope':'FOUR SELECTED CANONICAL-SOURCE PHYSICAL PAGES, reconciled title/body/ancestor Prata 1; distinct action source each; NOT representative census','as_of':'2026-10-16','n_pages':4,'n_actions':4,'n_root_entity_parents':4,'r04_actions_used':4,'not_extrapolatable':'4-page exploratory selected sample; attribute and effect costs vary; different damage types and scene eligibility; no hit probabilities','rank':'Prata 1','mean_gross_min':min(x['mean_bruto'] for x in S),'mean_gross_max':max(x['mean_bruto'] for x in S),'spread':max(x['mean_bruto'] for x in S)-min(x['mean_bruto'] for x in S),'observations':record,'selected_RD':{str(rd):{x['creature']:metrics(dist(x['dice'],x['attribute_value']+x['fixed']),rd) for x in S} for rd in RDS},'official_credit':0,'hypothesis':'Comparable rank does not fix effective post-RD distribution even when dice and attributes explicitly documented; test by more rank-consistent sourced cohorts with type/mode costs, not v2.'}
(P/'SCIENCE_PRATA1_4_PAGES_EXACT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
with (P/'SCIENCE_PRATA1_ALL_RD_CURVES.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.DictWriter(f,fieldnames=list(curve[0]));w.writeheader();w.writerows(curve)
# R125 read-only ledger
rfile=P/'vlab_r125/R125_NATIVE_RECEIPTS_165_FOR_DMG.csv'
rows=list(csv.DictReader(rfile.open(encoding='utf8',newline='')))
assert len(rows)==165
cols=['raw','rd_applied','effective_post_rd','hp_loss_actual','overkill','hp_before','hp_after','attack_score','event_seq']
assert all(x['run_id'] and x['actor_instance'] and x['target_instance'] for x in rows)
for x in rows:
 for c in cols:x[c]=int(x[c])
 x['hit_bool']={'True':True,'False':False}[x['hit']]
assert len({(x['run_id'],x['event_seq'],x['actor_instance'],x['target_instance'],x['attack_origin']) for x in rows})==165
checks=0
for x in rows:
 assert x['raw']>=0 and x['rd_applied']>=0 and x['effective_post_rd']>=0 and x['hp_loss_actual']>=0 and x['overkill']>=0;checks+=5
 assert x['effective_post_rd']==max(x['raw']-x['rd_applied'],0);checks+=1
 assert x['hp_loss_actual']+x['overkill']==x['effective_post_rd'];checks+=1
 assert x['hp_before']-x['hp_after']==x['hp_loss_actual'];checks+=1
 if not x['hit_bool']:
  assert x['raw']==x['rd_applied']==x['effective_post_rd']==x['hp_loss_actual']==x['overkill']==0;checks+=1
 assert x['official_credit']=='0';checks+=1
 assert x['pa_cost'].startswith('0 BASIC/REACTION');checks+=1
runs=sorted({x['run_id'] for x in rows})
assert len(runs)==6
hist_r116=P.parent/'vlab/R116_DMG_NATIVE_RECEIPTS_212.csv'
if hist_r116.exists():
 prior=list(csv.DictReader(hist_r116.open(encoding='utf8',newline='')))
 r116run={x.get('run_id','') for x in prior};r125run={x['run_id'] for x in rows};run_overlap=sorted(r116run&r125run)
else:run_overlap=None

def agg(g):
 return {'events':len(g),'hits':sum(x['hit_bool'] for x in g),'raw':sum(x['raw'] for x in g),'rd_applied':sum(x['rd_applied'] for x in g),'post_rd':sum(x['effective_post_rd'] for x in g),'actual_life_lost':sum(x['hp_loss_actual'] for x in g),'overkill':sum(x['overkill'] for x in g),'crit_positive':sum(x['critical']=='POSITIVE' for x in g)}
route=(P/'vlab_r125/R125_DMG_ROUTE_READONLY.md').read_text(encoding='utf8')
result={'as_of':'2026-10-16','operation':'OP-DMG-CORPUS-EMP-01','origin_operation':'OP-VLAB-FUSION-SANDBOX-01','evidence':'RECOVERED original R125 CSV and R118–R125 ZIP, 242/242 manifest hashes & CRC pass','file_sha256':hashlib.sha256(rfile.read_bytes()).hexdigest(),'zip_sha256':hashlib.sha256((P/'vlab_r125/VLAB_R118_R125_REACOES_SCHEDULER_ESCALA_MESTRE_ONLY.zip').read_bytes()).hexdigest(),'events':len(rows),'runs':len(runs),'phase_counts':dict(collections.Counter(x['scene_phase'] for x in rows)),'attack_origins':dict(collections.Counter(x['attack_origin'] for x in rows)),'technical_events':'152 normal attacks, 13 counter responses; 5x5 scenario censored before intent; technical mirrored execution, not official encounters','independent_ledger_checks':checks,'stats_total':agg(rows),'stats_by_run':{run:agg([x for x in rows if x['run_id']==run]) for run in runs},'stats_by_origin':{o:agg([x for x in rows if x['attack_origin']==o]) for o in sorted(set(x['attack_origin'] for x in rows))},'stats_by_phase':{p:agg([x for x in rows if x['scene_phase']==p]) for p in sorted(set(x['scene_phase'] for x in rows))},'shared_run_ids_with_R116':run_overlap,'stat_independence':'SCENE_SEED_FAMILY_NOT_INDEPENDENT_ATTACK','official_credit':0,'r125_ack_to_dmg':'ABSENT_PREPARED_LOCAL_READONLY','r93_r95_crit_errata':'quarantined; not used in normative comparisons','pa_efficiency':'NOT_DEFINED: PA=0 BASIC/REACTION; no spells, denominator zero','combat_outcome_claim':'NONE: 5x5 CENSORED and technical scale, not generic victory estimate'}
(P/'VLAB_R125_165_READONLY_DMG_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps({'prata1_means':{x['creature']:x['mean_bruto'] for x in S},'prata1_at_RD35':{x['creature']:metrics(dist(x['dice'],x['attribute_value']+x['fixed']),35)['expected_post_rd'] for x in S},'curve_rows':len(curve),'r125_ledger_checks':checks,'r125_totals':result['stats_total'],'r125_origin':result['stats_by_origin'],'r125_phase':result['stats_by_phase'],'r125_run_overlap':run_overlap},ensure_ascii=False,indent=2))
