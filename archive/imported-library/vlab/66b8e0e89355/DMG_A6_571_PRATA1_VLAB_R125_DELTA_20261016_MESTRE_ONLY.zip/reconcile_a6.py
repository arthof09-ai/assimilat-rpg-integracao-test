#!/usr/bin/env python3
"""Reconcile reconstructable structural UUIDs, not text original 332 Notion attachment.
Master-only / DMG / preserve holdout as ids only / no shared writes.
"""
from pathlib import Path
import csv, collections, json, hashlib, re, zipfile
base=Path(__file__).parent
raw=base/'root_reconstructed_compact.txt'
rows=[]
expected={'BEASTS':14,'CHARACTERS':233,'ITEMS':17,'WEAPONS':19,'SPELLS':26,'ARTIFACTS':15,'MATRICES':8,'INSCRIPTIONS':0}
parents={}
for line in raw.read_text(encoding='utf-8').splitlines():
 name,parent,edited,compact=line.split('|'); arr=compact.split(',') if compact else []
 assert len(arr)==expected[name], (name,len(arr));assert len(set(arr))==len(arr)
 parents[name]={'parent_uuid':parent,'edited_at':edited,'count':len(arr)}
 for item in arr:
  assert len(item)==24 and re.fullmatch('[0-9a-f]{24}',item)
  uid=item[:4]+'2b324ede'+item[4:]
  rows.append({'uuid':uid,'url':'https://app.notion.com/p/'+uid,'source_index':name,'source_branch':'','source_parent_uuid':parent,'depth':1,'evidence_of_access':'RECONSTRUCTED_FROM_NOTION_ROOT_FETCH_20261016','source_last_edited_at':edited,'identity_class':'STRUCTURAL_REFERENCE','possible_mirror':'UNDETERMINED_NON_UUID_ALIASES','physical_page_body_opened':'NO','version_class':'ROOT_DIRECT_LINK_AT_CAPTURE','provenance':'RECONSTRUCTED_NOT_ORIGINAL_CSV_READBACK'})
assert len(rows)==332
assert len({r['uuid'] for r in rows})==332
rootout=base/'A6_332_ROOT_DIRECT_CHILD_IDS_RECONSTRUCTED.csv'
with rootout.open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
branchfile=Path('/mnt/data/dmg_succession/readback/A6_239_BEAST_BRANCH_CHILD_IDENTITIES_VERIFIED_20261016.csv')
with branchfile.open(encoding='utf-8',newline='') as f: branch=list(csv.DictReader(f))
assert len(branch)==239 and len(set(r['uuid'] for r in branch))==239
rootids={r['uuid'] for r in rows};branchids={r['uuid'] for r in branch}
union=rootids|branchids; inter=rootids&branchids
assert not inter and len(union)==571
combined=[]
for r in rows:combined.append({'uuid':r['uuid'],'url':r['url'],'origin_type':'ROOT_INDEX_DIRECT','origin':r['source_index'],'parent_uuid':r['source_parent_uuid'],'depth':1,'origin_version':r['source_last_edited_at'],'evidence_of_access':r['evidence_of_access'],'origin_provenance':r['provenance'],'possible_mirror':'NOT_ADJUDICATED','source_status':'STRUCTURAL_REFERENCE_ONLY','offensive_effect_count':'UNASSESSED'})
for r in branch:combined.append({'uuid':r['uuid'],'url':r['url'],'origin_type':'BEAST_ELEMENT_BRANCH','origin':r['source_branch'],'parent_uuid':r['source_branch_uuid'],'depth':2,'origin_version':r['parent_last_edited_at'],'evidence_of_access':r['evidence_of_access'],'origin_provenance':'RECOVERED_SUCCESSOR_239_CSV_AND_PARENT_FETCH','possible_mirror':'NOT_ADJUDICATED','source_status':'STRUCTURAL_REFERENCE_ONLY','offensive_effect_count':'UNASSESSED'})
combined=sorted(combined,key=lambda x:(x['uuid'],x['depth']))
final=base/'A6_CROSSWALK_571_UUIDS_TWO_DEPTHS_RECONSTRUCTED.csv'
with final.open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(combined[0]));w.writeheader();w.writerows(combined)
with zipfile.ZipFile('/mnt/data/dmg_succession/historical/DMG_F0_CONTINUIDADE_SNAPSHOTS_HOLDOUT_20261016_MESTRE_ONLY.zip') as z:
 hold=json.loads(z.read('PRODUTO_B_HOLDOUT_PREREG_PRESEAL.json'))['records']
held={x['source_page_id'].replace('-','') for x in hold}
hit_root=held&rootids;hit_branch=held&branchids
res={'operation':'OP-DMG-CORPUS-EMP-01','as_of':'2026-10-16','baseline':'DMG-RANK-01 v1.1 unchanged','source_root_attachment':'DMG_F0_A6_DIRECT_CHILD_IDS_8_ROOTS_20261016.csv in IBX-102','source_root_attachment_bytes_readback':False,'root_332_provenance':'RECONSTRUCTED_FROM_EIGHT_CURRENT_ROOT_FETCHES_ONCE','branch_239_provenance':'RECOVERED_MATERIALIZED_CSV_WITH_PRIOR_PARENT_READS','root_count':len(rows),'root_unique_uuid':len(rootids),'branch_count':len(branch),'branch_unique_uuid':len(branchids),'root_branch_exact_uuid_intersection':len(inter),'two_depth_union_unique_uuid':len(union),'total_structural_rows':len(combined),'root_category_counts':dict(collections.Counter(r['source_index'] for r in rows)),'branch_counts':dict(collections.Counter(r['source_branch'] for r in branch)),'holdout_uuid_exact_hits_root':sorted(hit_root),'holdout_uuid_exact_hits_branch':sorted(hit_branch),'holdout_record_count':len(held),'holdout_independence_certified':False,'global_D0':'UNDETERMINED','representative':'Structural child references only; not 571 creatures, not 571 offensive sources or universe census','parent_version_scope':'Notion fetch last-edited time at parent; target child bodies not reopened','files':{}}
for p in (raw,rootout,branchfile,final):res['files'][p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(base/'A6_571_CROSSWALK_CERTIFICATE.json').write_text(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(res,ensure_ascii=False,indent=2))
