# PSV DE CONTINUIDADE DMG — FECHAMENTO MATERIAL A6 / COORTE PRATA1 / VLAB R125

**AS-OF:** 16/10/2026. **OPERATION:** OP-DMG-CORPUS-EMP-01. **HIST-ID:** CM-000001/DMG, sem claim de INSTANCE-ID. **BASELINE:** DMG-RANK-01 v1.1 inalterada. **MESTRE-SIDE.**

## PREDECESSOR-LAST-VERIFIED, SUCCESSOR-FIRST-VERIFIED E NO-REPEAT

Checkpoint inicial desta passagem: `DMG_DELTA_A5_HASH_A7_R04_PARES_20261016_MESTRE_ONLY.zip` (23.123 bytes SHA `f514e2fc5f0f3d0557d3dba8b9ec8c225fdfa09967b8188cda4abe85b6f06017`), já auditado pela Coordenação e persistido. Não reiniciado F0, não repetidas 1.616/683 verificações históricas, nem oito pares R02 ou três pares R04 nem os combates R125. Primeiro resultado novo: A6 571 linhas individuais e interseção zero. Última unidade desta passagem: cruzamento A6 571 e auditoria independente de coorte/165 R125. FIRST-PENDING: A5 readback de sete corpos integrais; certificação de holdout/instância/autoridade.

## A6 — DEMONSTRAÇÃO NOVA

- O CSV original `DMG_F0_A6_DIRECT_CHILD_IDS_8_ROOTS_20261016.csv` está na Inbox IBX-102, referência `COORD-DMG-A6-CHILD-ID-CROSSWALK-20261016-001`; a URL assinada existe, mas o download efetivo falhou em rota de transferência.
- Reconstrução ÚNICA AUTORIZADA: leitura dirigida dos oito índices existentes do Notion Mestre, extrair apenas `<page url>` dentro de `<content>`, sem recensear descendentes ou Party. CSV `A6_332_ROOT_DIRECT_CHILD_IDS_RECONSTRUCTED.csv`, 332 IDs distintos: Bestas14, Personagens233, Itens17, Armas19, Magias26, Artefatos15, Matrizes8, Inscrições0. Proveniência RECONSTRUÍDO, NÃO readback do original.
- Segundo conjunto: `A6_239_BEAST_BRANCH_CHILD_IDENTITIES_VERIFIED_20261016.csv` recuperado da Biblioteca existente. 239 IDs distintos em 12 ramos, proveniência RECUPERADO.
- Cruzamento `A6_CROSSWALK_571_UUIDS_TWO_DEPTHS_RECONSTRUCTED.csv`: 332+239−interseção0=**571 UUIDs distintos**, 571 linhas materializadas; certificação delimitada às duas profundidades e identidades exatas. Não são 571 Bestas, habilidades ou fontes de dano, nem D0 global.
- Para cada identidade: URL, origem, pai, profundidade, edição do índice pai e estado da evidência. Filhos individualmente não reabertos; espelhos, sinônimos, conteúdo e versões não adjudicados.

## A5 — STATUS SEM FALSO PASS

Sete corpos atuais possuíam fingerprints 7/7 já confirmados no checkpoint anterior; não repetidos. Sete anexos históricos na Inbox IBX-102 **0/7 bytes autenticados em download**. Nesta passagem a URL assinada do anexo A6 chegou à ferramenta de download, mas esta retornou bloqueio `url not viewed in conversation before`; tentativa de abertura da URL pelo web retornou indisponibilidade. A rota Notion `download_attachment` dera `{}` em passagens anteriores. A5 permanece `PARTIAL/HOLD`: snapshots UTF-8 integrais atuais também dependem de via que realmente transfira os textos para o contêiner. Não se fabricam arquivos `.md` com fingerprints sem corpo, nem históricos de 07/10 a partir dos corpos editados em 09/10. Diagnóstico em `A5_TRANSFER_BLOCKER_AND_SCOPE.json`.

## A7 E A8

IDs de oito holdouts estão nos 332 links de índice, 0/8 nos 239 ramos Bestas. Isso é exposição ESTRUTURAL por índice, não leitura dos oito conteúdos confirmatórios nem prova de vazamento ou independência. Holdout com certificação cega 0/8, revisor independente pendente. Identidade CM-000001 pertence historicamente ao Coordenador; esta sucessão de workstream não herda instance, Assignment, writer, epoch, lease, ACK ou collision domain. Nenhuma escrita Notion/Party/O Primeiro/Sistema/VLAB nesta execução.

## CIÊNCIA — COORTE CLASSIFICADA PRATA 1

Reabertas quatro páginas Mestre com título, corpo e ancestral todos `Prata 1`: Águia Arranha Céu `206c2b324ede835383a1818a6edd5273` Raio Paralisante `1d4+INT30`; Lupusventus `4bac2b324ede8321af6b01eb96452d04` Patada `2d6+FOR25`; Concha Marinha Luminosa `474c2b324ede82d08ea6819069c17043` Mordida `3d6+FOR30`; Tigris Sombrio `725c2b324ede8301baed01d62bd2b8e0` Presas Fantasmais `2d6+FOR24`. Quatro páginas independentes de identidade física, quatro ações, mas selecionadas do histórico R04, não novo censo populacional. Médias brutas condicionais: 32,5; 32,0; 40,5; 31,0. Spread bruto 9,5. Com RD TEST escalar 35, expectativas pós-RD respectivamente 0; 1/9; 5,523148; 1/36. Concha informa comportamento **inanimado**, tornando-a de admissibilidade em combate incerta: excluindo-a, spread do trio restante cai para 1,5. Assim, seleção/semântica de entidade alteram substancialmente a dispersão aparente. Tipos, acerto, custo, controle e legalidade de ações NÃO foram igualados. Fases exploratórias F1/F4/F8/F12, sem terminal.

## VLAB R125 — NOVA INTERFACE READ-ONLY

Recuperado ZIP nativo `VLAB_R118_R125_REACOES_SCHEDULER_ESCALA_MESTRE_ONLY.zip`, 11.965.498 bytes, SHA `5368fb31d176e8f52bb0bac01efa5a2f657a9cebb83af7c1cf4e22a5dcbf53b1`, 243 entradas, 242/242 hashes do manifesto e CRC PASS; CSV original R125 61.116 bytes, SHA `c130b59ae9c5c9718434470d16e76a3e97277a08446bbeac26e4ac5da1eabc69`, idêntico ao arquivo dentro do ZIP. **165 eventos técnicos, seis RUN-IDs; 152 ataques normais (104 acertos) e 13 respostas COUNTER_RESPONSE (13 acertos).** Críticos positivos 3. Bruto 29.031; RD 2.587; pós-RD 26.444; Vida efetiva 18.990; overkill 7.454; somas e ledger reconciliados.

Separar 152 eventos de cenas finalizadas de **13 da cena 5x5 CENSORED_PRE_INTENT**. Seis RUN-IDs não colidem literalmente com os de R116 (212 linhas), mas isso não prova independência entre famílias, instâncias, métodos ou cenas; não concatenar as amostras como ataques independentes. Handoff R125 **PREPARADO, ACK DMG AUSENTE**. Dados R93/R95 com crítico defeituoso continuam em quarentena. R125 apenas sandbox TEST, crédito oficial zero; PA=0 ação básica/reação sem denominador legítimo para eficiência por PA.

## LOTES 002/003 E APLICAÇÃO DA V1.1

Busca dirigida na Biblioteca recuperou referências históricas ao ZIP Lote002 (`libfile_84761c9a591c8191bc304533e4074ee9`), mas não seus bytes nesta passagem; Lote003 continua RELATADO e sem matriz individual autenticada. R04 histórico recuperado é uma fonte de estudo própria, não substituto do pertencimento aos lotes. Trilha v1.1 genuína desta passagem: **zero fontes novas elegíveis** — quatro ações têm dano EXPLÍCITO, logo a fórmula fonte prevalece. Não foi inventado RE/FIP. Nenhum v2 proposto.

## GATES, DENOMINATORS, CONFLICTS, UNKNOWN-EFFECT, NAC-PASS

- **F0 formal:** ANTES 4/8 → DEPOIS **4/8**. A1–A8 são crosswalk operacional, não certificados autônomos.
- **A6:** ANTES 239/239 materializados + 332 relato/anexo não recuperado → DEPOIS **571/571 identidades estruturais duas profundidades materializadas** com 332 RECONSTRUÍDOS +239 RECUPERADOS. Gate de identidade UUID estrutural PASS técnico, não PASS formal F0.
- **A5:** 7/7 fingerprints texto anterior, 0/7 anexos históricos readback; sem novo snapshot integral; PARTIAL/HOLD.
- **A7:** 8/8 IDs em índices raiz, 0/8 em Bestas; segundo codificador e independência externa HOLD.
- **A8:** Assignment, instance e writer/lease/epoch sem claim; HOLD.
- **Scientific:** quatro páginas Prata1 admissíveis somente para fórmulas documentadas e rank estrutural; 163 células RD analíticas, VLAB 165 recibos novos recebidos por recuperação técnica, sem ACK interexecutores.
- **Conflitos:** aliases nome do ancestral/corpo; Concha inanimada mas possui Mordida; Escorpião Diamante/Ártico preservado; classificações históricas e R93/R95 crítico errata preservados; materiais Lot002/3 ainda não autenticados nesta passagem.
- **UNKNOWN-EFFECT:** nenhum comando de escrita canônica nem combate executado; extração read-only e arquivos locais/Biblioteca aditivos. Não houve mutação Notion compartilhada.
- **NO-REPEAT:** P0, auditorias 1.616/683, R02 oito pares, R04 três pares e combates VLAB não executados novamente.
- **AUTHORITY/WRITER:** MESTRE-SIDE, sucessor com autoria física de delta local, sem herdar CM-000001-I*, lease, ACK nem writer.
- **NAC-PASS:** cálculo/crosswalk/ZIP/biblioteca PASS técnico proporcional; F0 terminal HOLD, produção/DMG v2 HOLD.
- **TARGET-REMAINDER/NEXT-5:** (1) caminho legítimo de bytes A5, (2) auditoria independente da reconstrução 332 vs anexo original quando acessível, (3) adjudicação cega dos oito holdouts por família/alias, (4) reconciliação identity/writer, (5) localizar Lot002/3 matriz original e ampliar coortes classificadas com PA/acerto/tipo. Sem nova matriz F0-F18.

**Não há certificação de 100% global; D0 do RPG não foi delimitado.**
