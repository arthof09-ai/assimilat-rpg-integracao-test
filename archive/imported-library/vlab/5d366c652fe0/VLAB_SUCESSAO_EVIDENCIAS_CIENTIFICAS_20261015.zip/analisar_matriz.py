import json,glob,math,statistics,collections,itertools,hashlib
from pathlib import Path
root=Path('/mnt/data/vlab_recovery/r27_extract/reconstruction/r27_delivery/runs/receipts')
records=[json.load(open(p)) for p in sorted(root.glob('*.json'))]
mat=[x for x in records if x['left']!='ORIGINAL_R26' and not x['id'].startswith('ORIGINAL')]
his=[x for x in records if x not in mat]
assert len(mat)==320 and len(his)==8
com=[x for x in mat if x['status'].startswith('COMPLETE')]
cens=[x for x in mat if not x['status'].startswith('COMPLETE')]
num=lambda xs,k:sum(x['summary'][k] for x in xs if x.get('summary'))
keys=['attacks','hits','a1_events','raw_damage','rd_mitigation','net_damage','hp_removed','overkill','critical_positive','critical_failure','reactions_used','positive_pa_spent']
sums={k:sum(x['a1_events'] for x in com) if k=='a1_events' else num(com,k) for k in keys}
by={}
for (a,b),xs0 in itertools.groupby(sorted(mat,key=lambda x:(x['left'],x['right'])),key=lambda x:(x['left'],x['right'])):
 xs=list(xs0); finished=[x for x in xs if x in com]; rr=[x['summary']['rounds'] for x in finished]
 by[f'{a}__{b}']={'evaluated':len(xs),'complete':len(finished),'censored':len(xs)-len(finished),'wins_left':sum(x['winner']=='LAB_PERSONALIZADO_1' for x in finished),'rounds_mean':round(statistics.mean(rr),3) if rr else None,'rounds_median':statistics.median(rr) if rr else None,'rounds_min_max':[min(rr),max(rr)] if rr else None,'attacks':num(finished,'attacks'),'hits':num(finished,'hits'),'raw':num(finished,'raw_damage'),'net':num(finished,'net_damage'),'hp':num(finished,'hp_removed'),'critical_pos':num(finished,'critical_positive'),'critical_neg':num(finished,'critical_failure')}
# independence reversal paired by same seed and identity, counting outcomes for chosen profile
paired={}
for (a,b) in [('EQUILIBRADO','OFENSIVO'),('OFENSIVO','DEFENSIVO')]:
 x={r['seed']:r for r in com if r['left']==a and r['right']==b}; y={r['seed']:r for r in com if r['left']==b and r['right']==a}
 ks=sorted(set(x)&set(y))
 w1=[r['winner']=='LAB_PERSONALIZADO_1' for r in (x[k] for k in ks)]
 w2=[r['winner']=='LAB_PERSONALIZADO_2' for r in (y[k] for k in ks)]
 paired[f'{a}__{b}']={'distinct_seeds':len(ks),'wins_a_left':sum(w1),'wins_a_right':sum(w2),'wins_both':sum(c and d for c,d in zip(w1,w2)),'wins_neither':sum(not c and not d for c,d in zip(w1,w2)),'wins_one_only':sum(c!=d for c,d in zip(w1,w2))}
# exact damage convolutions
rolls={0:1}
ranks=[('Bronze',3,6,5),('Prata',6,6,15),('Ouro',9,6,25),('Ouro Negro',12,6,35),('Lendario Tita',20,10,75)]
maths=[]
for label,n,faces,rd in ranks:
 c={0:1}
 for _ in range(n):
  p=collections.Counter()
  for s,k in c.items():
   for i in range(1,faces+1):p[s+i]+=k
  c=p
 total=faces**n
 maths.append({'rank':label,'damage_dice':f'{n}d{faces}','RD':rd,'mean_raw':n*(faces+1)/2,'mean_net':sum(max(s-rd,0)*k for s,k in c.items())/total,'p_zero_net':sum(k for s,k in c.items() if s<=rd)/total})
out={'method':'independent receipt JSON aggregation, complement to 328 receipt SQLite audit','dataset':{'matrix':len(mat),'historic':len(his),'complete_matrix':len(com),'censored_matrix':len(cens),'counts':sums,'hit_rate':sums['hits']/sums['attacks'],'raw_per_hit':sums['raw_damage']/sums['hits'],'net_per_hit':sums['net_damage']/sums['hits'],'net_per_attack':sums['net_damage']/sums['attacks'],'hp_removed_per_attack':sums['hp_removed']/sums['attacks'],'rd_fraction_raw':sums['rd_mitigation']/sums['raw_damage'],'mean_rounds':statistics.mean(x['summary']['rounds'] for x in com),'median_rounds':statistics.median(x['summary']['rounds'] for x in com),'min_rounds':min(x['summary']['rounds'] for x in com),'max_rounds':max(x['summary']['rounds'] for x in com)},'cells':by,'paired':paired,'rank_exact':maths}
Path('/mnt/data/vlab_recovery/R27_SUC_CIENTIFICA_ANALISE.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'dataset':out['dataset'],'paired':paired,'ranks':maths},ensure_ascii=False,indent=2))
