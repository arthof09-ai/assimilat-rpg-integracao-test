import json,hashlib,sqlite3,sys,collections,statistics, pathlib
BASE=pathlib.Path('/mnt/data/vlab_recovery/r27_extract')
sys.path.insert(0,str(BASE/'fusion_stage12'))
import vlab_r27_scientific_baseline as v
R=BASE/'reconstruction/r27_delivery/runs'
aggregate=collections.Counter(); fails=[];cells=collections.defaultdict(lambda:collections.Counter()); hits=[]
files=list(sorted((R/'receipts').glob('*.json')))
for j in files:
 d=json.loads(j.read_text());id=d['id'];db=R/'sqlite'/f'{id}.sqlite';cell=id.rsplit('__SEED_',1)[0];flag=d['status']
 if not db.exists():fails.append([id,'MISSING_DB']);continue
 if hashlib.sha256(db.read_bytes()).hexdigest()!=d['sqlite_sha256']:fails.append([id,'BYTE_SHA']);continue
 con=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
 try:
  if con.execute('pragma integrity_check').fetchone()[0]!='ok':fails.append([id,'SQLITE_INTEGRITY']);continue
  if con.execute('select count(*) from pending').fetchone()[0]:fails.append([id,'PENDING_INTENT']);continue
  rows=[json.loads(x[0]) for x in con.execute('select row_json from events order by seq')]
  ev=[x for x in rows if x.get('detail',{}).get('action')=='ATTACK']
  if len(ev)!=len(d['events']):fails.append([id,'EVENT_LENGTH']);continue
  for x,y in zip(ev,d['events']):
   n=x['detail']['inner']['native']['effect'];p=x['detail']['inner']['preview']
   if (n['hit'],n['net'],n['before_hp'],n['after_hp'],p['critical_trigger']) != (y['native_hit'],y['native_net'],y['before_hp'],y['after_hp'],y['critical']):
    fails.append([id,'EVENT_MISMATCH']);break
   if y['critical']=='NEGATIVE' and (y['native_hit'] or y['native_net'] or y['native_raw'] or y['after_hp']!=y['before_hp']):fails.append([id,'CRITICAL_NEGATIVE_INVALID'])
  if len(rows)!=d['revision']:fails.append([id,'REVISION']);continue
 finally:con.close()
 aggregate['verified']+=1;aggregate['attacks']+=d['summary']['attacks'];aggregate['hits']+=d['summary']['hits'];aggregate['a1']+=d['a1_events'];aggregate['gross']+=d['summary']['raw_damage'];aggregate['net']+=d['summary']['net_damage'];aggregate['hp']+=d['summary']['hp_removed'];aggregate['critical_pos']+=d['summary']['critical_positive'];aggregate['critical_neg']+=d['summary']['critical_failure'];aggregate['rd']+=d['summary']['rd_mitigation'];aggregate['overkill']+=d['summary']['overkill']
 aggregate[flag]+=1;cells[cell][flag]+=1;cells[cell]['victory_left']+=d['winner']=='LAB_PERSONALIZADO_1';cells[cell]['attempts']+=1
 if d['summary']['rounds'] is not None:cells[cell]['rounds'].append(d['summary']['rounds']) if isinstance(cells[cell]['rounds'],list) else None
out={'files':len(files),'checked':dict(aggregate),'errors':fails,'cells':{k:dict(v) for k,v in cells.items()}}
p=pathlib.Path('/mnt/data/vlab_recovery/R27_SUC_INDEPENDENT_AUDIT.json');p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'files':len(files),'checked':dict(aggregate),'failures':fails,'cell_count':len(cells)},ensure_ascii=False,indent=2))
