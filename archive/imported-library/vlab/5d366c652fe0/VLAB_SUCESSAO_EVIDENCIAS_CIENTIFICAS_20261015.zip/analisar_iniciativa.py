import sqlite3,glob,json,collections,statistics
from pathlib import Path
root=Path('/mnt/data/vlab_recovery/r27_extract/reconstruction/r27_delivery/runs')
records=[]
for pp in sorted((root/'receipts').glob('*.json')):
 x=json.load(open(pp));
 if not x['id'].startswith('ORIGINAL') and x['status'].startswith('COMPLETE'):
  db=root/'sqlite'/(pp.stem+'.sqlite');c=sqlite3.connect(db)
  row=json.loads(c.execute('SELECT row_json FROM events ORDER BY seq LIMIT 1').fetchone()[0]);c.close()
  ini=row['detail']['inner']; lead=ini['order'][0]; w=x['winner']; rolls=ini['rolls'];
  records.append({'cell':x['left']+'__'+x['right'],'seed':x['seed'],'lead':lead,'win':w,'lead_wins':lead==w,'initiative_diff':rolls[0]['total']-rolls[1]['total']})
assert len(records)==120
from collections import defaultdict
by=defaultdict(list)
for r in records:by[r['cell']].append(r)
out={'runs':120,'lead_won_total':sum(x['lead_wins'] for x in records),'lead_win_rate':sum(x['lead_wins'] for x in records)/120,'per_cell':{k:{'n':len(v),'first_wins':sum(x['lead_wins'] for x in v),'first_wins_pct':100*sum(x['lead_wins'] for x in v)/len(v)} for k,v in sorted(by.items())},'interpretation':'observational association only; initiative DES, accuracy FOR and matchup co-vary; no isolated causal effect claim'}
Path('/mnt/data/vlab_recovery/R27_SUC_INICIATIVA_ANALISE.json').write_text(json.dumps(out,indent=2,ensure_ascii=False));print(json.dumps(out,ensure_ascii=False,indent=2))
