"""Read-only independent campaign gate. Verify readback source hashes when present.
No simulations or native effects imported or called. Five original packages are required.
"""
import csv,json,hashlib,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
def chk(cond,key):
 if not cond:raise AssertionError(key)
def audit(files):
 ledger=json.loads((ROOT/'R229_R233_FIVE_ZIP_READBACK_LEDGER.json').read_text())
 rows=list(csv.DictReader((ROOT/'R229_R233_FIVE_BATTERIES_SCORECARD.csv').open()))
 chk(len(rows)==5 and {x['battery'] for x in rows}=={'A','B','C','D','E'},'FIVE_BATTERIES')
 chk(len(ledger['checkpoint_series'])==5 and ledger['official_matrix_1875']==0 and ledger['terminal_contract_17']==0,'OFFICIAL_ZERO')
 checks=[]
 for a,n in zip(ledger['checkpoint_series'],range(229,234)):
  chk(a['checkpoint']==f'R{n}' and a['cold_status'].startswith(f'PASS_R{n}') and a['historical_replays']==0,'HISTORY_COLD')
  path=pathlib.Path(files[n]);chk(path.exists() and path.stat().st_size==a['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==a['sha256'],'LIBRARY_BYTE_READBACK')
  text=(ROOT/f'R{n}_READBACK_COLD_RESULT.json').read_text();receipt=json.loads(text[text.rfind('{'):]);chk(receipt['status']==a['cold_status'],'COLD_RECEIPT_MATCH')
  checks.append({'version':n,'sha256':a['sha256'],'files':a['manifest_files'],'status':receipt['status']})
 chk(all(x['official_cells']=='0' for x in rows),'FALSE_CELL_CERTIFICATION')
 return {'status':'PASS_R229_R233_FIVE_BATTERY_CROSS_AUDIT_READONLY','readbacks_verified':5,'batteries':5,'official_matrix_cells':0,'contracts_terminal':0,'historical_replays':0,'cold_results':checks}
if __name__=='__main__':
 files={229:'/mnt/data/vlab_r231/library_readback_batch1/VLAB_R229_BATTERIES_ABC_LAB_SENSITIVITY_COLD_AUDITED_MESTRE_ONLY.zip',230:'/mnt/data/vlab_r231/library_readback_batch1/VLAB_R230_NATIVE_BEAST_SOURCE_SPEED_COLD_AUDITED_MESTRE_ONLY.zip',231:'/mnt/data/vlab_r231/library_readback_batch2/VLAB_R231_R91_FIVE_BATTERIES_SOURCE_READINESS_COLD_AUDITED_MESTRE_ONLY.zip',232:'/mnt/data/vlab_r232/library_readback/VLAB_R232_VZ_NAMED_BEAST_ATTACK_ACTUATOR_COLD_AUDITED_MESTRE_ONLY.zip',233:'/mnt/data/vlab_r233/library_readback/VLAB_R233_B25_SOURCE_GRADE_RD_SENSITIVITY_COLD_AUDITED_MESTRE_ONLY.zip'}
 x=audit(files);(ROOT/'R229_R233_CROSS_AUDIT_RESULT.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps(x,ensure_ascii=False,indent=2))
