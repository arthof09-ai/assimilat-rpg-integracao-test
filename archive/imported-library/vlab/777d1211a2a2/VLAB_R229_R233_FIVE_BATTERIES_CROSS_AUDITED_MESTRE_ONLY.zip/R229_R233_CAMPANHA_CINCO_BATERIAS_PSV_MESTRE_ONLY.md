# PSV CONSOLIDADO — Campanha VLAB R229–R233 · Cinco Baterias A–E · MESTRE-SIDE

**21/10/2026 · CM-000006 lógico · OP-VLAB-FUSION-SANDBOX-01 · TEST; Party/O Primeiro/fichas/normas oficiais NO-WRITE; produção HOLD.**

## 1. O que avançou concretamente

**Cinco checkpoints físicos incrementais (R229 a R233), cinco ZIPs publicados na Biblioteca Mestre e materializados de volta com SHA idêntico, cinco recuperações frias executadas sobre os readbacks.** Três avanços de engenharia/execução e dois de estrutura científica:

1. **R229:** corrigiu um defeito físico de classificação de crítico positivo no *submodelo legado*, em cópia isolada, e executou nova coorte com sete configurações A–C. **168 execuções originais + 168 trocas de rótulo não independentes**, 2.332 eventos de ataques originais. Os ensaios inválidos de horizonte e crítico foram preservados em quarentena, sem contaminarem o denominador.
2. **R230:** colocou cinco Bestas virtuais de cinco classificações (Bronze, Prata, Ouro, Ouro Negro e Lendário/Titã) em **movimento nativo R18 com velocidade calculada pela Regra 8 — Criação de Besta**, seguindo de um ataque físico. **5 SQLite, 5 commits, 15 eventos**, um turno por classificação. Não são cinco combates completos ou cinco espécies canônicas.
3. **R231:** confrontou 104 posições documentais R91 e produziu **225 snapshots virtuais distintos** sem criar fichas canônicas: A125, B25, C75; painel D com oito candidatas VZ de espécies distintas, ainda sem ficha física completa; E com comparador PS/semicanônico preservado. **7/7 adulterações semânticas rejeitadas**, nenhuma célula oficial preenchida.
4. **R232:** executou **quatro ataques físicos nativos** de quatro espécies VZ PRECRIADAS distintas (SB01 Arraia de Trovão Vítreo, SB02 Tatu Vulcânico de Cobalto, SB07 Grifo de Sílica Tempestuosa, SB08 Manta Ferromnésica) contra referência Varok, usando fórmulas source-bound, dados, RD, Vida em SQLite R18. **4 commits, 8 eventos, três acertos, um erro, quatro adulterações rejeitadas 4/4**. É um teste de atuador ofensivo de espécie, **não duelo**: atributos defensivos da Besta estão desconhecidos, placeholders de interface explicitamente LAB e não canônicos. 0/27 células oficiais D.
5. **R233:** investigou os **25 patamares regulares B** com ED virtual × Besta virtual de mesma classificação/estrela, 4 seeds por patamar e RD COM/SEM. **200 execuções originais, 200 espelhos não independentes, 3.162 ataques originais, 1.692 acertos, 18 censuras**, 100/100 pares com fitas ofensivas *e agenda* idênticas. A RD preservou 156 PV somados, alterou Vida terminal em 10/100 pares e não alterou encerramentos por limiar LAB. **4/4 adulterações com digest reconstruído rejeitadas**. Submodelo v0.6.1 básico, não R18, não valida potência global.

**Denominadores da campanha R229–R233:** 368 execuções **originais** no submodelo LEGADO (168+200) e 368 espelhos **não independentes**; **9 execuções nativas R18 de um turno/um ataque** (R230 cinco + R232 quatro), 9 commits e 23 eventos nativos. **225 snapshots são dados virtuais, NÃO execuções**. Não agregar indevidamente simulação básica, espelhos, snapshots e R18 como se fossem observações homogêneas.

## 2. A situação científica das cinco baterias

| Bateria | Evidência nova, escopo correto | Gate mais importante |
| --- | --- | --- |
| **A — ED** | Duas configurações de duelo básico R229; 125 snapshots ED virtuais documentais R231; ED participa da comparação B25 R233 | ED-source completo para todos os ranks e LEVEL-UP racial sem diferença Orc B1→B2 |
| **B — Linhagem de Besta** | Cinco velocidades source-derivadas efetivamente movimentadas no R18 R230; 25 níveis regulares comparados no LEGACY R233 | Besta viva source-completa com ações reais; ADM/Divina continuam posições especiais não-ED |
| **C — Equipe** | R229 executou configurações básicas 2×1 e 3×1; R231 75 snapshots de três atores; R216 histórico tem suporte real 2×1 em R18, sem novo replay | Equipe completa por patamar com cura, Reação, alvo, alcance e adversário realmente ativo |
| **D — Espécies distintas** | Oito identidades candidatas VZ (pré-criação); **quatro delas executaram um ataque source-bound** em R232 | Materializar/confirmar páginas físicas e atributos/PA/CA/skills para combates completos |
| **E — Equipamento** | Preservadas as comparações anteriores R226/R227 de Manopla PS — **8 pares + 6 pares**; nova triagem de Espada do Lendário e Mangual do Trovão confirmou ausência de separação autorizada de chassi/dano mágico | Item **P4** que separe físico e magia e portador/rank elegíveis |

O conjunto **não certifica 104/104 posições**, **não preenche nenhum dos 1.875 confrontos previstos** e **não homologa qualquer dos 17 contratos terminais**: permanece 0/1.875 e 0/17. Os denominadores 104 (posições R91), 225 (snapshots virtuais), 368 (execuções básicas originais), 9 (ensaios nativos unilaterais) e 4 (ataques de espécies VZ) são logicamente diferentes.

## 3. Ciência, justiça e limites

- Na R229, os controles de troca de rótulo foram rigorosamente iguais por ID e streams; isso só investiga viés de **rótulo**, não o de iniciativa, já estudado nos R217–R222 históricos.
- Na R233, **100 pares preservaram exatamente o mesmo calendário e as rolagens ofensivas**. A diferença observada no total de Vida (156 PV) é atribuível a aplicar ou desativar RD **na fixture LAB específica**, sem mudança de status terminal. É uma evidência negativa delimitada sobre desfecho, não alegação de irrelevância de RD.
- Em ambos os módulos LEGADOS, empates de iniciativa, efeitos de HP0, alcance, distribuição de atributos, proficiência genérica e política crítica negativa não constituem a totalidade canônica do combate. A correção do crítico positivo (R229) ocorreu exclusivamente em **cópia local LAB**, não foi promovida à produção.
- R230 e R232 usam o resolvedor nativo v0.8.1/R18, mas apenas **um turno ofensivo** cada. Não provaram transformação, cura, contragolpe, reação ou KO numa luta source-completa entre essas Bestas.
- Identidades VZ são **PRECREATE**, não automaticamente P4. A fonte dessas quatro fórmulas é um excerto mecânico primário Notion; não se afirma hashing do corpo integral da página.

## 4. Persistência demonstrada

O ledger `R229_R233_FIVE_ZIP_READBACK_LEDGER.json` especifica para cada pacote: nome exato, bytes, SHA-256, status do verificador após extração fria e quantidade de arquivos verificados. **Todos 5/5 PASS, CRC PASS, 0 histórico reexecutado.** A Biblioteca guarda os mesmos arquivos sob `/Comestre/OP-VLAB-FUSION-SANDBOX-01/`. Os arquivos nativos, traces legados, advertências e quarentenas continuam nos respectivos pacotes, em vez de ter sido mesclados com dados oficiais.

## 5. Autoridade, interoperabilidade e cinco próximas ações

Decisão do Mestre: **sempre arredondar para baixo quando uma regra exigir arredondamento**; os cálculos de dano com metade ímpar já foram exercitados nos checkpoints R223–R225. **A regra TAP/BAP na transformação preserva carry fracionário próprio**, não deve ser anulada por arredondamento genérico. Nenhuma atualização de norma canônica foi reivindicada sem writer/NAC-NORM.

As IBX-125 (Orc Level-Up) e IBX-126 (DMG R209–R214) já foram publicadas pela Coordenação; não houve mensagens duplicadas nem ACK inventado. Recibos R229–R233 para DMG estão **PREPARÁVEIS, NÃO ENVIADOS** até roteamento por Assignment/INSTANCE-ID competente. O VLAB não assume writer de DMG, LEVEL-UP ou Party.

**LAST-VERIFIED-UNIT:** R233 — readback frio do ZIP e auditor independente PASS; revisão consolidada read-only sobre R229–R233. **FIRST-PENDING:** R234 candidato, sujeito a preflight. **NO-REPEAT:** seeds de R229, R230, R232, R233 e quarentenas; não reexecutar R01–R228.

**NEXT-5 executáveis/priorizados:** (1) confirmar fonte física de uma das quatro Bestas VZ e reconstruir seus atributos reais, Vida/PA/CA/range sem placeholders; (2) integrá-la num **combate bilateral R18 real** com defesa, movimentos e turnos, e incluir suporte 2×1; (3) ampliar B25 além do submodelo legado com os tiers fonte-completos, controlando criticidade, RD, magia, espécie, duração e censuras; (4) investigar item **P4 fonte-separável** para primeiro E COM/SEM magia legítimo; (5) compartilhar apenas novo dado científico com DMG via rota competente, harmonizar Orc com LEVEL-UP, e posteriormente submeter certificações NAC-PASS terminal.

**NAC-PASS local:** PASS estritamente TEST para auditoria/rastreabilidade/recuperação e ciência exploratória. **NAC-PASS global/produção/contratos oficiais: HOLD.** Não houve mudança de fichas reais, regras, Party, O Primeiro nem matriz R91.
