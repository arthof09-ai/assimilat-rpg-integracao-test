"""Generate immutable R33 ZIP once. Requires review of outputs before upload.
Does not touch old archives, Notion files, old SQLite or user world.
"""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent
OUT=R.parent/'VLAB_R33_PREPARACAO_COMBATE_REAL_FONTE_MESTRE_ONLY.zip'
SELECT=[
 'R33_RELATORIO_MESTRE_ONLY.md','PROPOSTA_DECISAO_INVESTIDA_MESTRE_ONLY.md','README_REPRODUCAO_R33.md',
 'prepare_battle_r33.py','recover_and_audit_r33.py','test_turn_handoff_r33.py','VERIFY_R33_ARCHIVE_STANDALONE.py','BUILD_PACKAGE_R33.py',
 'runs/R33_BESTAS_REAL_SOURCE_INIT_CONDITIONAL_SEED307.sqlite',
 'checkpoints/R33_INIT_ONLY_PORTABLE_SEED307.sqlite',
 'evidence/R33_ANTES.json','evidence/R33_SCENE_PRE_REGISTERED.json','evidence/R33_INVESTIDA_ADMISSION_DENIED.json',
 'evidence/R33_INTEGRITY_RECEIPT.json','evidence/R33_TURN_HANDOFF_DETACHED_TEST.json','evidence/R33_EXACT_SCIENCE.json'
]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not OUT.exists(),'DO_NOT_OVERWRITE_ARCHIVE'
manifest={'schema':'R33_REAL_SOURCE_BATTLE_PREFLIGHT_DELTA_SHA256_MANIFEST_V1','operation':'OP-VLAB-FUSION-SANDBOX-01',
 'version':'R33','scope':'MESTRE_ONLY_SANDBOX_NONCANON','status':'CONDITIONAL_INIT_NATIVE_PASS_NO_FULL_FIGHT',
 'baseline_R27_sha256':'d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1',
 'parent_R32_zip_sha256':'20530947c8349d8e544fa5ee506e7327b31a8e6d37eb3aab23c180d1639c4a53',
 'files_sha256':{name:sha(R/name) for name in SELECT}}
mp=R/'R33_FILE_MANIFEST.json';assert not mp.exists()
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
import VERIFY_R33_ARCHIVE_STANDALONE as v
result=v.check(); assert result['status'].startswith('PASS')
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for name in SELECT+['R33_FILE_MANIFEST.json']:
  info=zipfile.ZipInfo(name, (2026,10,15,12,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  info.external_attr=0o644<<16;z.writestr(info,(R/name).read_bytes())
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(SELECT)+1
 m=json.loads(z.read('R33_FILE_MANIFEST.json'))
 for f,h in m['files_sha256'].items():assert hashlib.sha256(z.read(f)).hexdigest()==h
print(json.dumps({'status':'PASS_PACKAGE','path':str(OUT),'bytes':OUT.stat().st_size,'members':len(SELECT)+1,
 'sha256':sha(OUT),'manifest_files':len(SELECT),'standalone_check':result},ensure_ascii=False,indent=2))
