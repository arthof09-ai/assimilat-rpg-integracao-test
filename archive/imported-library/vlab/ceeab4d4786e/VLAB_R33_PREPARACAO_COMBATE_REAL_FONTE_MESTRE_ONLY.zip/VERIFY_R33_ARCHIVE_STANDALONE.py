"""Standalone source-independent integrity verification of R33 delta package.
No writes, no combat execution; validates two SQLite and file digests in package.
Does NOT replace full historical R26/R18 replay (see R33 report).
"""
from __future__ import annotations
import hashlib,json,sqlite3,zipfile,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def check():
  manifest=json.loads((ROOT/'R33_FILE_MANIFEST.json').read_text())
  for name,expected in manifest['files_sha256'].items():
    p=ROOT/name
    assert p.is_file(), f'MISSING:{name}'
    assert sha(p)==expected, f'MISMATCH:{name}'
  states=[];events=[]
  for name in ('runs/R33_BESTAS_REAL_SOURCE_INIT_CONDITIONAL_SEED307.sqlite','checkpoints/R33_INIT_ONLY_PORTABLE_SEED307.sqlite'):
    con=sqlite3.connect(ROOT/name)
    try:
      assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
      assert con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0
      assert con.execute('SELECT COUNT(*) FROM events').fetchone()[0]==1
      m=dict(con.execute('SELECT key,value FROM meta'))
      assert m['revision']=='1'
      st=json.loads(m['state']); assert st['r33_preflight']['complete_fight_certification'] is False
      assert st['r33_preflight']['native_goat_action_still_denied'] is True
      assert st['order']==['LAB_REAL_FRIGIDO_B5','LAB_REAL_CABRA_B1']
      assert st['actors']['LAB_REAL_FRIGIDO_B5']['resource']['hp']==125
      assert st['actors']['LAB_REAL_CABRA_B1']['resource']['hp']==38
      states.append((m['state'],m['head'],m['revision']))
      events.append(con.execute('SELECT row_json,row_sha,prev,before_sha,after_sha FROM events').fetchone())
    finally:con.close()
  assert states[0]==states[1] and events[0]==events[1]
  assert states[0][1]=='140defbe7df3e2bc8e697f7b4e55e100bcda2363cc8a16b0938807c7f335e850'
  e=json.loads(events[0][0]);assert e['kind']=='R33_CONDITIONAL_INITIATIVE_REAL_SOURCE'
  assert e['detail']['no_attack'] is True and e['official_effects']==0
  return {'status':'PASS_DELTA_FILE_HASH_SQLITE_LOGICAL_CHECKS','files':len(manifest['files_sha256']),'rev':1,'event_count':1,'complete_fights':0,'canon_effects':0}

if __name__=='__main__':print(json.dumps(check(),ensure_ascii=False,indent=2))
