# R33 — Continuidade fiel (MESTRE-SIDE)

## Resultados e limites
- **Não há combate integral concluído**. Novo banco contém somente um evento de **iniciativa condicionada em bônus0+0** das duas Bestas reais do Mestre, processado pela função histórica `R26.resolve_initial_state` dentro do journal R18.
- `runs/R33_BESTAS_REAL_SOURCE_INIT_CONDITIONAL_SEED307.sqlite` rev1, head `140defbe7df3e2bc8e697f7b4e55e100bcda2363cc8a16b0938807c7f335e850`.
- `checkpoints/R33_INIT_ONLY_PORTABLE_SEED307.sqlite` é BACKUP LÓGICO verificável por state/head/rows, não deve ter SHA idêntico ao SQLite original. Ambos têm `pending=0`, `PRAGMA integrity_check=ok`.
- O script `prepare_battle_r33.py` foi usado uma vez e bloqueia reexecução quando o DB existe. Uma validação ingênua pós-commit exigiu SHA idêntico do backup, falhou sem efeitos adicionais, e o pós-auditor recuperou **sem executar novamente**.
- `recover_and_audit_r33.py` faz read-only audit e já produziu `evidence/R33_INTEGRITY_RECEIPT.json`; para rodá-lo novamente em modo read-only, remova **somente** os arquivos de saída de nova auditoria `R33_EXACT_SCIENCE.json` e `R33_INTEGRITY_RECEIPT.json` numa cópia de estudo do pacote, nunca a cena/ledger originais. Não é necessário repetir.
- `test_turn_handoff_r33.py` roda somente em cópia profunda do estado e não escreve no ledger. Ele comprova chamada às funções existentes `_next_turn` e `refresh_own_turn` sob hipótese experimental.
- `PROPOSTA_DECISAO_INVESTIDA_MESTRE_ONLY.md` contém escolhas propostas P1–P6; não houve decisão oficial da Investida.

## Dependências históricas (não duplicadas no pacote delta)
Para reconstruir a aplicação fonte-real, recuperar os pacotes byte-preservados R27/R31/R32:
- R27 original SHA `d8a384f8d6d8b94ef494fc67bac704c1aa87c1ada64359342f8cdcab6da31ab1`;
- gateway R31 SHA `061a073f5aa0e3f079efe453cc7fb4fe069b5160ac90c92a603cdf4e7a2779b7` reaproveitado no R32;
- ZIP R32 SHA `20530947c8349d8e544fa5ee506e7327b31a8e6d37eb3aab23c180d1639c4a53`.
Os scripts nesta entrega foram testados no layout de trabalho de `/mnt/data/vlab_r31/r27` e `/mnt/data/vlab_r32`; adaptar apenas os caminhos da cópia local **fora da história oficial**. Sem ambiente com componentes originais não alegar replay independente reproduzido.

## Ponto de retomada exato
Primeira pendência normativa: Investida da Cabra (Luta, ação, custo, aproximação, empurrão, defesa e obstáculos) + bônus individuais de Iniciativa. Decisão específica do Mestre, registro/reabertura na **OP existente**, novo banco **não derivado como promoção do R33 condicional**, cena completa com efeitos e combate encerrado, replay e checkpoint. Não voltar à R27, não inventar proficiências e não chamar preparação condicional de FULL-FIGHT.
