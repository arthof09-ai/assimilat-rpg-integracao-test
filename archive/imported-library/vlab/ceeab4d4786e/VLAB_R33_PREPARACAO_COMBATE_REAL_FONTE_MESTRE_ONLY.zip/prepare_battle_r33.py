"""R33 — first real-source duel preflight with historical R18 & R26.
This is NOT a new combat engine and does NOT execute incomplete Cabra Investida.
Only a separately labeled CONDITIONAL R26 initiative event with master real-source actors.
Run once; existing DB is never overwritten or automatically resumed.
"""
from __future__ import annotations
import copy, json, sys, sqlite3, hashlib, zipfile, math
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
OLD=Path('/mnt/data/vlab_r31/r27/fusion_stage12')
R32=Path('/mnt/data/vlab_r32')
sys.path.insert(0,str(R32/'extension'))
sys.path.insert(0,str(OLD))
import vlab_r31_real_source_gateway as g
import vlab_r18_interactive as ledger
import vlab_r26_master_rulings as rules

SEED=307
DB=ROOT/'runs'/'R33_BESTAS_REAL_SOURCE_INIT_CONDITIONAL_SEED307.sqlite'
AUTH=R32/'authority'/'MESTRE_LUTA_DECISION_VERIFIED.json'


def write(name,thing):
 p=ROOT/'evidence'/name
 if p.exists():raise RuntimeError('NO_OVERWRITE_EXISTING_EVIDENCE:'+str(p))
 p.write_text(json.dumps(thing,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
 return p


def hashfile(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def admission_investida():
 """Reject INCOMPLETE contract without entering historical event_commit.
 No orphan durable intent; stage for competent Mestre decision.
 """
 actual=g.SOURCES['goat']['literal_ability']
 assert 'Investida' in actual and 'joga a pessoa para longe' in actual
 data={
  'schema':'R33_CABRA_INVESTIDA_STRICT_PRE_ADMISSION_V1',
  'entity':g.TARGET_SOURCE,'literal_ability':actual,'source_rank':'Bronze 1',
  'known':{'actor_for':13,'damage':'1d6+FOR13','nature':'impacto','required_rider':'push','target_ca':'source real when declared','critical_rule':'Combat System + bounded LAB negative policy only'},
  'unknown':{
   'attack_Luta':'not individually attested; no authority to transfer Frigido+6',
   'action_kind':'whether the named charge is STANDARD or FULL, and whether MOVE is also required',
   'extra_PA':'no explicit cost; unknown is not zero',
   'run_up':'whether movement/minimum distance or acceleration is required',
   'reach':'whether initial adjacency is legal or only charging into it',
   'push_distance':'the number of blocks',
   'push_direction':'along vector away from Cabra or another competent geometry rule',
   'saving_throw':'whether target can resist with a defense/save, and which attribute/CD',
   'push_trigger':'on hit, on damage, on failed save, or another condition',
   'obstacles':'stop/impact/collision, collision damage or no impact, adjacency downstream',
   'reaction_response':'target may declare voluntary Reaction; requires complete choice and source-supplied defense stats',
  },
  'status':'HOLD_MISSING_MESTRE_RULINGS',
  'full_fight_eligible':False,'native_goat_action_allowed':False,
  'do_not_invoke_r18_event_commit':True,'world_effects':0}
 return data


def initiative_distribution(fr_b: int,go_b:int):
 groups={'fr_first':0,'goat_first':0,'tie_total_fr_wins_on_des':0,'ties_same_des':0}
 for fr in range(1,7):
  for goat in range(1,7):
   vf=fr+18+fr_b;vg=goat+8+go_b
   if vf>vg:groups['fr_first']+=1
   elif vg>vf:groups['goat_first']+=1
   else:
    # R26 tie: DES 18 > 8, Frigido wins
    groups['tie_total_fr_wins_on_des']+=1
    groups['fr_first']+=1
 return {**groups,'denominator':36,'kind':'MATH_ONLY_CONDITIONED_INIT_BONUS','assumptions':{'fr_bonus':fr_b,'goat_bonus':go_b}}


def inject_conditional_into_genesis(st):
 st['phase']='INIT';st['round']=0;st['turn']=0;st['active']=None;st['order']=[]
 st['r31_source']['experimental_turn_override']=False
 st['r31_source']['reaction_policy']='ALL_VOLUNTARY_REACTIONS_REQUIRE_EXPLICIT_DECISION_AND_SOURCED_DEFENSE; NOT_DISABLED'
 st['r33_preflight']={'schema':'R33_CONDITIONAL_BATTLE_SETUP_ONLY',
   'intent':'prepare real source battle; NO goat attack, NO full fight credit',
   'source_ids':[g.BEAST_SOURCE,g.TARGET_SOURCE],
   'geometry':{'positions':{g.AID:[0,0],g.TID:[1,0]},'units':'abstract blocks, only LAB',
       'distance_blocks':1,'terrain':'UNDEFINED; do not infer obstacles or line of sight',
       'not_actual_world':True,'not_usable_for_push_until_ruling':True},
   'initiative_bonus_status':'MISSING_IN_REAL_SOURCES; BOTH_0_MATH_CONDITION_ONLY',
   'luta_fr':6,'luta_fr_provenance':'MASTER_R32_EXPLICIT',
   'luta_goat':None,'luta_goat_provenance':'PENDING',
   'goat_attack_status':'DENY_MISSING_REQUIRED_PUSH',
   'reactions':'1 initial each; renew OWN_TURN_START via R26; no unspecified reaction defense derived',
   'goat_behavior':'attempt named Investida only if admitted, else DO_NOT_FAKE_PASS_OR_FIGHT',
   'fight_end':'HP_ZERO_LAB_ONLY_AFTER_ALL_TURNS_LEGAL',
   'benchmark_source':'NOTION_REAL_SANDBOX_NONCANONICAL',
   'complete_fight_certification':False,'world_effects':0}
 for aid in st['actors']:
  st['actors'][aid]['stats']['init_bonus']=0
  st['actors'][aid]['stats']['init_bonus_status']='LAB_HYPOTHESIS_NOT_SOURCE_FACT'
 return st


def init_runner(st,payload,seq):
 if st['phase']!='INIT' or st['r33_preflight']['complete_fight_certification']:
  raise RuntimeError('PRECONDITION_DENIED')
 if payload['source_sha']!=g.sha(g.evidence_manifest()) or payload['status']!='INITIATIVE_CONDITIONAL_ONLY':
  raise RuntimeError('SOURCE_BINDING_MISMATCH')
 if not all(st['actors'][a]['stats']['init_bonus']==0 for a in st['actors']):
  raise RuntimeError('INVALID_CONDITIONED_INIT_BONUS')
 ev=rules.resolve_initial_state(st) # R26 historical, not new initiative logic
 refresh=rules.refresh_own_turn(st,st['active'])
 st['r33_preflight']['initiative_resolved']={'rolls':ev['rolls'],'order':ev['order'],'tie_resolution':ev['tie_resolution']}
 st['r33_preflight']['native_goat_action_still_denied']=True
 return {'resolver':'R26.resolve_initial_state','details':ev,'reaction_refresh':refresh,
         'no_attack':True,'no_damage':True,'complete_fight':False,'canonical_effects':0}


def independent_replay(st_initial,receipt,final):
 cp=copy.deepcopy(st_initial)
 expected=init_runner(cp,receipt['payload'],1)
 assert expected==receipt['detail']
 assert cp==final
 return {'status':'PASS_R26_INITIATIVE_REPLAY_FROM_GENESIS','decision_sha':ledger.sha(expected),
         'state_sha':ledger.sha(cp),'no_attack':True,'real_source':True}


def run():
 if DB.exists():raise RuntimeError('NO_REUSE_EXISTING_DB')
 auth=json.loads(AUTH.read_text(encoding='utf-8'))
 assert g._validated_luta_authority(auth)==6
 decl={
  'schema':'R33_PRE_REGISTERED_DUEL_MESTRE_SOURCE_V1','seed':SEED,
  'source_ids':{'actor':g.BEAST_SOURCE,'target':g.TARGET_SOURCE},
  'R32_authority_sha256':hashfile(AUTH),'R32_gateway_sha256':hashfile(R32/'extension'/'vlab_r31_real_source_gateway.py'),
  'R26_module_sha256':hashfile(OLD/'vlab_r26_master_rulings.py'),
  'source_manifest_sha':g.sha(g.evidence_manifest()),
  'first_event_scope':'INIT_ONLY_CONDITIONED_BONUSES_NOT_REAL_FIGHT',
  'initial_conditions':{'frigido':{'hp':125,'pa':120,'ca':31,'des':18},'cabra':{'hp':38,'pa':22,'ca':20,'des':8},'adjacent':True,'positions':{g.AID:[0,0],g.TID:[1,0]}},
  'R26_initiative_bonus_probe':{'frigido':0,'cabra':0,'not_official':True},
  'not_assuming_cabra_luta':True,'no_canon':True}
 write('R33_SCENE_PRE_REGISTERED.json',decl)
 write('R33_INVESTIDA_ADMISSION_DENIED.json',admission_investida())
 g.create(DB,SEED)
 con=ledger.connect(DB)
 try:
  con.execute('BEGIN IMMEDIATE')
  d=dict(con.execute('SELECT key,value FROM meta'))
  assert d['revision']=='0' and con.execute('SELECT COUNT(*) FROM events').fetchone()[0]==0
  st=inject_conditional_into_genesis(json.loads(d['state']))
  con.execute('UPDATE meta SET value=? WHERE key="state"',(ledger.canonical(st),))
  con.commit()
 except Exception:
  con.rollback();raise
 finally:con.close()
 st0,head0,rev0=g.checked(DB)
 assert rev0==0 and st0['phase']=='INIT'
 write('R33_ANTES.json',{'state':st0,'head':head0,'rev':0})
 # Conflicting/full goat action is denied BEFORE the R18 durable intent.
 denied=admission_investida()
 assert denied['native_goat_action_allowed'] is False
 payload={'source_sha':g.sha(g.evidence_manifest()),'status':'INITIATIVE_CONDITIONAL_ONLY',
          'bonus_condition':{'fr':0,'goat':0},'head_before':head0,'rev_before':0,
          'world_effects':0,'no_full_fight_credit':True}
 independent=init_runner(copy.deepcopy(st0),payload,1)
 assert independent['no_attack']
 cmd='LAB-CMD-R33-INIT-'+ledger.sha(payload)[:26]
 row=ledger.event_commit(DB,cmd,'R33_CONDITIONAL_INITIATIVE_REAL_SOURCE',payload,init_runner)
 st1,head1,rev1=g.checked(DB)
 assert rev1==1 and len(ledger.history(DB)['events'])==1
 re=independent_replay(st0,row,st1)
 assert st1['phase']=='ACTIVE' and st1['round']==1
 assert st1['r33_preflight']['native_goat_action_still_denied']
 assert [st1['actors'][a]['resource']['hp'] for a in (g.AID,g.TID)]==[125,38]
 assert [st1['actors'][a]['resource']['pa'] for a in (g.AID,g.TID)]==[120,22]
 con=ledger.connect(DB)
 try:
  integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
  pending=con.execute('SELECT COUNT(*) FROM pending').fetchone()[0]
  n=con.execute('SELECT COUNT(*) FROM events').fetchone()[0]
  assert integrity=='ok' and pending==0 and n==1
  backup=ROOT/'checkpoints'/'R33_INIT_ONLY_PORTABLE_SEED307.sqlite'
  if backup.exists():raise RuntimeError('CHECKPOINT_EXISTS')
  dst=sqlite3.connect(backup)
  try:con.backup(dst)
  finally:dst.close()
 finally:con.close()
 ck_state,ck_head,ck_rev=g.checked(backup)
 assert (ck_state,ck_head,ck_rev)==(st1,head1,rev1)
 # SQLite backup has different page/WAL binary representation despite identical logical ledger.
 # Always compare verified state, revision, head, rows and event hashes; not raw files.
 assert ledger.history(DB)['events']==ledger.history(backup)['events']
 write('R33_INTEGRITY_RECEIPT.json',{
  'schema':'R33_INIT_ONLY_SOURCE_REAL_NONCAN',
  'initial_state':{'frigido_hp':125,'goat_hp':38,'world_effects':0},
  'head_before':head0,'head_after':head1,'revision':rev1,'kind':row['kind'],
  'native_historical_event':row['detail'],'replay':re,
  'sqlite_integrity':integrity,'pending':pending,'events':n,
  'db_sha256':hashfile(DB),'backup_sha256':hashfile(backup),
  'first_attack_admitted':False,'goat_attack_admitted':False,'full_fight_completed':False,
  'strict_hold_reason':denied['unknown'],
  'source_kind':'MASTER_REAL_BESTAS_READONLY',
  'conditions':'INIT_BONUSES_BOTH_0_LAB_ONLY_NOT_MESTRE_RULING',
  'canonical_effects':0})
 exact={f'fr_{fr}_goat_{go}':initiative_distribution(fr,go) for fr,go in ((0,0),(0,6),(0,10),(0,12),(6,0),(6,6))}
 exact['goat_hit_faces_normal_for13']={str(l):[d for d in range(1,7) if d+13+l>31] for l in (0,6,12,13,14)}
 exact['goat_hit_condition']='d6+13+Luta>31; minimal Luta to allow any hit is +13'
 exact['fr_rabada_two_hit_KO_prob_given_two_hits']='1/36';exact['fr_rabada_max_3_hits_to_KO_without_defense']=3
 write('R33_EXACT_SCIENCE.json',exact)
 print(json.dumps({'result':'CONDITIONAL_INITIATIVE_PERSISTED_NOT_FULL_FIGHT',
  'init_order':st1['order'],'native_initiative_rolls':row['detail']['details']['rolls'],
  'events':n,'pending':pending,'db_sha':hashfile(DB),'replay':re['status'],
  'goat_contract':'HOLD','official_effects':0},ensure_ascii=False,indent=2))

if __name__=='__main__':run()
