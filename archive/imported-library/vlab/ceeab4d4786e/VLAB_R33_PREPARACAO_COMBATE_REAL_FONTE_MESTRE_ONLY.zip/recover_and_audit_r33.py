"""Read-only recovery and audit of existing R33 at revision1; NEVER re-run transaction."""
from pathlib import Path
import sys,json,sqlite3,copy,hashlib,importlib.util
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
import prepare_battle_r33 as t
j=t.ledger;g=t.g
orig=t.DB;backup=root/'checkpoints'/'R33_INIT_ONLY_PORTABLE_SEED307.sqlite'
assert orig.is_file() and backup.is_file()
state,head,rev=g.checked(orig)
state_b,head_b,rev_b=g.checked(backup)
assert rev==rev_b==1 and head==head_b and state==state_b
jo=j.history(orig);jb=j.history(backup)
assert jo['events']==jb['events'] and len(jo['events'])==1
row=jo['events'][0]
assert row['kind']=='R33_CONDITIONAL_INITIATIVE_REAL_SOURCE'
record=json.loads((root/'evidence'/'R33_ANTES.json').read_text())
pre=record['state']
assert t.ledger.sha(pre)==row['before_sha']
clone=copy.deepcopy(pre)
out=t.init_runner(clone,row['payload'],1)
assert clone==state and out==row['detail']
assert state['r33_preflight']['complete_fight_certification'] is False
assert state['r33_preflight']['native_goat_action_still_denied'] is True
assert set(state['actors'])=={g.AID,g.TID}
assert state['actors'][g.AID]['source_page_id']==g.BEAST_SOURCE
assert state['actors'][g.TID]['source_page_id']==g.TARGET_SOURCE
assert state['actors'][g.AID]['resource']['hp']==125 and state['actors'][g.TID]['resource']['hp']==38
assert state['actors'][g.AID]['resource']['pa']==120 and state['actors'][g.TID]['resource']['pa']==22
assert all(a['resource']['standard']==1 and a['resource']['reaction']==1 for a in state['actors'].values())
for p in (orig,backup):
 c=sqlite3.connect(p)
 try:
  assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  assert c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0
  assert c.execute('SELECT COUNT(*) FROM events').fetchone()[0]==1
  assert c.execute('SELECT COUNT(*) FROM meta').fetchone()[0]>=6
 finally:c.close()
assert t.admission_investida()['native_goat_action_allowed'] is False
# Idempotence check READ-ONLY: non-destructive duplicate detection by explicit existing row.
c=sqlite3.connect(orig)
try:
 assert c.execute('SELECT COUNT(*) FROM events WHERE cmd_id=?',(row['cmd_id'],)).fetchone()[0]==1
finally:c.close()
exact={f'fr_{fr}_goat_{go}':t.initiative_distribution(fr,go) for fr,go in ((0,0),(0,6),(0,10),(0,12),(6,0),(6,6))}
exact['goat_hit_faces_normal_for13']={str(l):[d for d in range(1,7) if d+13+l>31] for l in (0,6,12,13,14)}
exact['goat_hit_condition']='d6+13+Luta>31; minimal Luta to allow any hit is +13'
exact['fr_rabada_two_hit_KO_prob_given_two_hits']='1/36';exact['fr_rabada_max_3_hits_to_KO_without_defense']=3
exact['not_full_fight']=True
science=root/'evidence'/'R33_EXACT_SCIENCE.json'
assert not science.exists()
science.write_text(json.dumps(exact,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
report={
 'schema':'R33_AUDIT_RECONCILE_REV1_V1','status':'PASS_CONDITIONAL_INIT_ONLY_NOT_FULL_FIGHT',
 'source_mode':'MASTER_REAL_BESTAS_READONLY_LAB',
 'seed':307,'before_revision':0,'after_revision':rev,
 'head_after':head,'event_kind':row['kind'],'native_rule_method':'R26.resolve_initial_state',
 'rolls':row['detail']['details']['rolls'],'order':state['order'],
 'own_turn_reaction_refresh':row['detail']['reaction_refresh'],
 'state_after':{'phase':state['phase'],'round':state['round'],'turn':state['turn'],'active':state['active'],
                'hp':{k:v['resource']['hp'] for k,v in state['actors'].items()},
                'pa':{k:v['resource']['pa'] for k,v in state['actors'].items()},
                'reaction':{k:v['resource']['reaction'] for k,v in state['actors'].items()},
                'standard':{k:v['resource']['standard'] for k,v in state['actors'].items()}},
 'native_attacks':0,'complete_fights':0,'world_effects':0,
 'replay':{'status':'PASS_REPLAY_FROM_PRE_REGISTERED_GENESIS','expected_sha':j.sha(out),'final_sha':j.sha(clone)},
 'checkpoint':{'logical_identity':True,'same_events':True,
               'original_sha256':t.hashfile(orig),'backup_sha256':t.hashfile(backup),
               'binary_SHA_warning':'SQLite backup can be logically identical but byte-different; do NOT demand physical SHA equality'},
 'sqlite_integrity':'ok','pending':0,'event_count':1,
 'strict_denial':t.admission_investida()['unknown'],
 'incomplete_goat_action_attempted':False,'manual_combat_fake':False,
 'source_status':'Reopened the official Notion source pages Oct 15 2026; no source mutation'}
path=root/'evidence'/'R33_INTEGRITY_RECEIPT.json'
assert not path.exists()
path.write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:report[k] for k in ('status','rolls','order','checkpoint','sqlite_integrity','pending')},indent=2,ensure_ascii=False))
