# DECISÃO PENDENTE DO MESTRE — Investida da Cabra de Chifres Bronze 1

**OP existente:** OP-VLAB-FUSION-SANDBOX-01 · **R33** · **Natureza:** PROPOSTA, **NÃO** REGRA VIGENTE · MESTRE-SIDE.

## Fonte e última fronteira verificável

- Ficha oficial: https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6 (reaberta: 2026-10-15; última edição da fonte 2026-10-01T18:00:34.040Z).
- Literal: «Investida: joga a pessoa para longe, o alvo sofre 1d6 + força impacto.»
- Cabra: Bronze 1, FOR13, DES8, CON10, CA20, HP38, PA22. Fonte de RD normal Bronze = 5.
- Outra variante intitulada Bronze 5 (cujo corpo diz Bronze 4, conflito legado) e variante Prata 1 diz «joga [...] mais longe», sem distância em blocos. Não autoriza completar esta ficha automaticamente.
- Sistema de Combate e sua versão antiga: ataque normal `dados da classificação + atributo Luta + bônus Luta`, 1 Ação Padrão; sem contrato genérico de «Investida» com run-up, empurrão e salvaguarda.
- Mestre autorizou +6 **exclusivamente para Rabada do Frígido Ossário**; não se estende à Cabra.

## Proposta mínima conjunta para decisão expressa — preferir autorização ESPECÍFICA da Investida

**P1 — Luta:** Investida da Cabra Bronze 1 recebe **+6 para acertar**, exclusivamente esta habilidade, sem somar ao dano; se não aprovado, Mestre especifica o bônus válido. Isto NÃO torna acerto possível contra CA31 com `1d6+FOR13+6` sem outra vantagem/efeito legítimo: máximo25.

**P2 — ação e começo:** ataque natural de impacto, corpo a corpo, **1 Ação Padrão**, **0 PA adicional**, alvo precisa estar **adjacente no momento do ataque**. **Sem deslocamento mínimo obrigatório** para iniciar; se distante, aproximação gasta a Ação de Movimento existente, respeitando velocidade da Besta e geometria. A Investida não concede movimento gratuito nem permite atacar a distância.

**P3 — empurrão:** **somente quando acertar e causar dano líquido positivo**, empurra o alvo **1 bloco** na direção reta que vai da Cabra ao alvo, afastando-o da Cabra. Não há salvaguarda adicional; Reações defensivas normais podem impedir o acerto/dano. **Se errar, não empurra.** A decisão sobre «somente se dano positivo» precisa ser do Mestre; defender pode bloquear dano mesmo com contato físico.

**P4 — obstáculos e oportunidade:** só aplica o deslocamento em bloco livre; se estiver ocupado/fora do cenário, **interrompe o empurrão antes do obstáculo, sem dano de colisão não documentado**. Deslocamento forçado **não provoca ataque de oportunidade**, salvo decisão distinta; depois, distância/adjacência são recalculadas para ataques futuros. Não teletransportar, não atravessar paredes. A opção de regra do Mestre deve ser registrada em fonte competente e testada no sandbox antes de promover a habilidade.

**P5 — iniciativa desta cena:** se as fichas não demonstrarem bônus de Iniciativa, permitir **bônus 0 para as duas Bestas apenas nesta cena experimental**, de forma expressa; **NÃO** declarar que criaturas sem campo escrito possuem oficialmente +0. Alternativamente especificar os dois valores exatos. Com bônus iguais, Frígido DES18 age antes da Cabra DES8 nas 36/36 possibilidades de 1d6 por lado.

**P6 — Reações e política tática:** preservar a renovação R26 no início do próprio turno e direito a Reação voluntária antes de cada ataque. Para não inventar Fortitude/Reflexo/Armadura ausentes, declarar qual política de Reações usará a primeira luta: por exemplo `NENHUMA_REAÇÃO_VOLUNTÁRIA` escolhida antecipadamente por ambas as Bestas para ensaio de ataque puro, **sem concluir incapacidade física de reagir**, ou fornecer os valores defensivos verificáveis para permitir DEFENDER/ESQUIVAR. Preferível rodar uma segunda bateria com Reações após o primeiro combate válido.

**Estado:** nenhuma dessas seis propostas foi aprovada pela fonte canônica. Não criar `MESTRE_INVESTIDA_DECISION_VERIFIED.json` como se houvesse decisão. Pedir aceite/ajustes expressos e readback na operação. Ainda assim, é necessário programar/admitir o empurrão no fluxo R18/R26/v0.8.1 com geometria, sem recriar o motor.

## Alternativas válidas

- Mestre fornece texto específico alternativo para qualquer P1–P6.
- Mestre não autoriza proposta: manter HOLD da Investida; prosseguir apenas em matemática e preparação documental. Nunca inferir autorização de silêncio.
