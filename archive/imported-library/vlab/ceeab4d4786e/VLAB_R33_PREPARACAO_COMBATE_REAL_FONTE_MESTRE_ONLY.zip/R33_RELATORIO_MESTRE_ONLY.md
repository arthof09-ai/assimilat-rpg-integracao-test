# PSV — VLAB R33 | Primeiro combate completo: pré-admissão real-fonte e HOLD dirigido

**OP existente:** `CM-000006 / OP-VLAB-FUSION-SANDBOX-01` | **Ambiente:** MESTRE-SIDE / sandbox isolado | **Data:** 15/10/2026 | **Norma:** DMG-RANK-01 v1.1 inalterada | **R27 ANTES preservada**.

## 1. Resultado material

**Não foi possível concluir legitimamente o primeiro combate completo entre Frígido Ossário e Cabra de Chifres.** O registro agora contém um experimento **novo** de **abertura de iniciativa real-fonte em sandbox**, usando o resolvedor de iniciativa R26 e o mesmo journal transacional R18, e a recusa prévia da Investida incompleta **sem** efeitos indevidos.

- **Ação integral R32 preservada** (1 ação; não reaplicada): Rabada do Frígido, bônus específico Luta +6, ataque27/CA20, dano bruto21, RD5, líquido16, Cabra HP38→22 somente no sandbox R32.
- **Nova cena R33:** `runs/R33_BESTAS_REAL_SOURCE_INIT_CONDITIONAL_SEED307.sqlite`, **não é continuação do banco R32** nem repete sua Rabada. Duas fontes Notion oficiais reabertas, Frígido Bronze5 e Cabra Bronze1. Estado inicial Besta HP125 e HP38, PA120 e PA22, CA31 e CA20. Posições experimentais `[0,0]` e `[1,0]`, 1 bloco de adjacência; não há cenário de campanha.
- **Iniciativa R26 nativa com ledger R18:** semente **307**, bônus de Iniciativa **0+0 somente como condição matemática não normativa**; dados `d6=4` para Frígido, `d6=4` para Cabra, DES18 e DES8 ⇒ totais22 vs12, **Frígido age primeiro**. `R26.resolve_initial_state` foi invocado pelo R18 `event_commit` sobre clone transacional, gravando **1 evento `R33_CONDITIONAL_INITIATIVE_REAL_SOURCE`**, revisão `0→1`, sem ataque nem dano. `R26.refresh_own_turn` renovou Reação 1→1 do Frígido no início do próprio turno.
- **Readback/replay:** `R33_ANTES.json` mais evento R18 determinista: replay independente por reexecução em cópia do estado de origem **PASS**; SQLite `integrity_check=ok`, `pending=0`, eventos=1. Cópia de checkpoint SQLite restaurada/verificada com **mesmo estado/head/revisão/linhas de eventos**, embora o SHA dos arquivos SQLite fisicamente difira devido ao layout de backup (equivalência lógica, não byte idêntico).
- **Comportamento adicional:** um ensaio **somente em cópia de estado, sem commit** confirmou `core._next_turn` R18 transferindo turno Frígido→Cabra e renovação de Reação R26 de 0→1 quando chega novo turno próprio da Cabra. Esse ensaio não é turno real registrado, não é combate completo e não inventa Ação de Cabra.

**Status:** `SOURCE_REAL_INITIATIVE_CONDITIONAL_PASS` / `INVESTIDA_PRE_ADMISSION_DENIED_BEFORE_DURABLE_INTENT` / `FULL_FIGHT_HOLD`.

## 2. Fontes consultadas e precedência

- <https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6> — Cabra Bronze1, `Investida: joga a pessoa para longe, o alvo sofre 1d6+força impacto.` Sem alcance, corrida mínima, deslocamento em blocos, salvaguarda, gatilho do empurrão ou custo explícitos.
- <https://app.notion.com/p/f0dc2b324ede820ab9470168d4a53315> — Frígido Bronze5; Rabada já possui autorização específica de Mestre em R31/R32.
- <https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0> e versão antiga <https://app.notion.com/p/87fc2b324ede8309a84d01550e0c1b3e> — ataque normal, ação, reação e testes; **não** fixam empurrão universal para Investida.
- <https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd> — proficiência geral Bronzenormal+6 e RD5; o bônus geral não é automaticamente comprovado como Luta individual da Cabra.
- Variantes oficiais da Cabra intitulada Bronze5 (mas corpo diz Bronze4: DIVERGÊNCIA DOCUMENTAL) <https://app.notion.com/p/fe9c2b324ede83f6853f01b48b5b6df3> e Prata1 <https://app.notion.com/p/b34c2b324ede82a88079016b52ba498e> dizem apenas «joga [...] mais longe», sem número de blocos. Não usar suas versões para alterar a Bronze1.

A própria decisão R32 de Mestre limita Luta +6 **à Rabada do Frígido Ossário**, não à Investida. Não foi encontrada nesta pesquisa uma autoridade para converter «longe» em 1, 2 ou outro número de blocos, nem para definir que o empurrão ocorre mesmo em erro/salvaguarda.

## 3. Científico novo e exato (não é combate)

**Iniciativa:** Se os bônus de Iniciativa forem IGUAIS, diferença DES18−DES8=10; dois d6 podem criar diferença máxima5, portanto o Frígido sempre atua antes em 36/36 combinações. Outras sensibilidades, bônus da Cabra relativo ao Frígido:

| Delta bônus Cabra − Frígido | Frígido primeiro | Cabra primeiro | Empate inicial resolvido por DES do Frígido |
|---|---:|---:|---:|
| 0 | 36/36 | 0/36 | 0 |
| +6 | 35/36 | 1/36 | 2/36 |
| +10 | 21/36 | 15/36 | 6/36 |
| +12 | 10/36 | 26/36 | 4/36 |

**Ataque básico condicionado:** com FOR13 e 1d6 Bronze1 contra CA31, a Cabra exige `1d6+13+Luta>31`. Sem bônus Luta ≥+13, **0/6** faces acertam sob **essa fórmula normal**. Mesmo +6 hipotético não basta (`máximo 25`). Crítico positivo é verificado à parte; não assumir que uma verificação de crítico ignora automaticamente a CA. A Investida pode possuir regras específicas desconhecidas e essas devem prevalecer se homologadas.

**Rabada:** Frígido com Luta +6 garante acerto básico `1d6+18+6>CA20` em todas as seis faces, EXCETO políticas aplicáveis de crítico negativo, Reações e modificadores de combate. Dano líquido `1d6+13`, exigindo **3 acertos** para derrotar HP38 em geral; **2 acertos bastam somente quando ambos os d6 de dano são 6** (1/36 condicionado a dois acertos). Isso não substitui turnos nem prova vitória de combate real.

## 4. Gatilhos de HOLD restantes

**Cabra/Investida:** `Luta individual`, `Ação Padrão/Completa`, `PA`, `distância mínima e movimento de carga`, `alcance`, `distância+direção do empurrão`, `se existe salvaguarda`, `hit/net/defense trigger`, `obstáculos/colisão`, `efeito em adjacência/oportunidade`, `reação defensiva com bônus/armadura da fonte`. **Iniciativa:** bônus individuais não presentes. Nenhum campo foi preenchido com valor imaginário.

**Proposta decisória pronta:** `PROPOSTA_DECISAO_INVESTIDA_MESTRE_ONLY.md`, opções P1–P6, explicitamente **PROPOSTA NÃO VIGENTE**. O Mestre pode aprovar/alterar em uma única decisão de escopo experimental, e depois registrar NAC-NORM/readback; nada disso já foi aplicado.

**Fluxo proibido:** não registrar PASS do turno da Cabra por falta de autorização, não fazer o Frígido atacar repetidamente enquanto Cabra ficticiamente não age, não emprestar Luta do Frígido, não converter `3d6` genérico em ação da Cabra, não chamar abertura condicional de combate completo.

## 5. Auditoria física e falha recuperada

O primeiro executor R33 criou a nova cena, persistiu evento R18 e fez backup; um teste auxiliar incorretamente exigiu **SHA byte-a-byte igual** entre SQLite original e backup, ocasionando `AssertionError` APÓS o único commit, sem novo `pending`. **Não houve retry**. Reabertura verificou original e backup com mesma revisão1, mesmo head, mesma história/eventos, mesmo estado/HP/PA, `pending=0` e ambos com integridade OK. `recover_and_audit_r33.py` reconciliou a comparação pelo conteúdo lógico e por replay independente, mantendo os **dois arquivos intactos**. O script de criação foi corrigido para futuros casos e continua `NO_OVERWRITE`; **não foi executado novamente**. Detalhes: `evidence/R33_INTEGRITY_RECEIPT.json`.

Hashes antigos R28–R32 conferidos byte-a-byte contra manifestos anteriores. R27 original, R29 seed53 e antigos UNKNOWN_EFFECT não tocados.

## 6. PSV delimitado

| Contador | ANTES R32 | DEPOIS R33 |
|---|---:|---:|
| Ações integrais de fonte-real em sandbox | 1 (Rabada) | **1 (preservada)** |
| Cabra Investida integralmente admitida | 0/1 | **0/1** |
| Fonte oficial de Bestas na cena | 2/2 | 2/2 |
| Eventos R33 de abertura R26/R18 condicional | 0 | **1** |
| Ataques nativos R33 executados | 0 | **0** |
| Combates completos de Bestas reais | 0 | **0** |
| Combates canônicos | 0 | 0 |
| Células canônicas creditadas | 0/1.875 | **0/1.875** |
| Contratos terminais produtivos VLAB | 0/17 | **0/17** |
| Patamares com luta completa real-fonte | 0/25 | **0/25** |
| Novas ações em UNKNOWN_EFFECT | 0 | **0** |

**NAC-PASS-02 terminal produtivo:** HOLD. **Validação proporcional read-only/sandbox:** PASS da abertura condicional; não é promoção. Writer produtivo, lease, epoch, fencing, GREEN: HOLD. R01–R32/DMG-RANK v1.1 mantidos, nenhuma escrita em fichas oficiais/Party/O Primeiro. Nenhuma porcentagem global de ciência aberta.

## 7. Ponto exato de retomada

**R33:** banco `runs/R33_BESTAS_REAL_SOURCE_INIT_CONDITIONAL_SEED307.sqlite`, rev1, head `140defbe7df3e2bc8e697f7b4e55e100bcda2363cc8a16b0938807c7f335e850`, turno do Frígido ativo, **mas condicionado em Iniciativa bônus0+0**. NÃO continuar esse banco como luta integral por mero aceite posterior: nova decisão exige novo banco/seed com iniciativa autorizada e todas as ações elegíveis, sem reclassificar histórico.

**Dependência externa:** decisão expressa P1–P6 do Mestre sobre Investida e bônus de Iniciativa. Após aprovação e registro/reabertura: construir adaptador mínimo de empurrão para o motor existente, adicionar a Investida ao mesmo catálogo por fonte real, completar decisões de Reações, então executar combate novo, evento-a-evento, até HP0 ou outra condição de encerramento *legítima*, com todos os eventos, checkpoint e replay. Não reutilizar R32 nem alterar regra geral.
