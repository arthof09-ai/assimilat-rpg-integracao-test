"""Detached-copy A/B tests for historical R18 next-turn and R26 reaction refresh.
No commits, no real-source actions, no canonical credit.
"""
import copy,json
from pathlib import Path
import prepare_battle_r33 as c
j=c.ledger;r=c.rules;g=c.g
ROOT=Path(__file__).resolve().parent
st,head,rev=g.checked(c.DB)
assert rev==1 and st['active']==g.AID
probe=copy.deepcopy(st)
pre={k:copy.deepcopy(v['resource']) for k,v in probe['actors'].items()}
trans=j._next_turn(probe)
assert trans['next_turn']==g.TID and probe['active']==g.TID and probe['round']==1
refresh=r.refresh_own_turn(probe,g.TID)
assert refresh['after']==1 and trans['reaction_auto_refresh'] is False
assert probe['actors'][g.TID]['resource']['standard']==1
assert probe['actors'][g.TID]['resource']['movement']==1
assert probe['actors'][g.AID]['resource']['hp']==125 and probe['actors'][g.TID]['resource']['hp']==38
# Show that refresh function restores a used reaction at next own turn in isolated copy.
probe['actors'][g.TID]['resource']['reaction']=0
turn_again=j._next_turn(probe)
assert probe['active']==g.AID and probe['round']==2
ret=r.refresh_own_turn(probe,g.AID)
assert ret['after']==1
turn_go=j._next_turn(probe)
assert probe['active']==g.TID and probe['round']==2
ref2=r.refresh_own_turn(probe,g.TID)
assert ref2['before']==0 and ref2['after']==1
# The original committed R33 file is unchanged before/after this detached probe.
original,hh,rr=g.checked(c.DB)
assert (hh,rr)==(head,rev) and original==st
res={'schema':'R33_TURN_REACTION_DETACHED_ONLY','status':'PASS_HISTORICAL_R18_NEXT_TURN_R26_REFRESH',
    'initial_active':g.AID,'first_handoff':trans,'first_goat_refresh':refresh,
    'next_own_turn_refresh':ref2,'source_file_unchanged':True,'read_only':True,
    'combat_action_count':0,'goat_action_count':0,'official_effects':0,
    'not_full_fight':True,'note':'Detached copies of source-real state; not an executed round or PA/resource transaction'}
p=ROOT/'evidence'/'R33_TURN_HANDOFF_DETACHED_TEST.json'
assert not p.exists();p.write_text(json.dumps(res,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':res['status'],'first_handoff':trans['next_turn'],'round':trans['round'],'react_restored':ref2['after']},ensure_ascii=False))
