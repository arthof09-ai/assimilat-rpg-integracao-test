# R297 — Diagnóstico de custo da verificação/replay A1 (MESTRE-ONLY)

**Operação:** `OP-VLAB-FUSION-SANDBOX-01`, domínio TEST isolado, mesmo motor histórico. A unidade R297 **NÃO modifica programa**, não propõe alteração de regra e não credita contratos. R296 foi preservado. `LAST VERIFIED R297` somente como diagnóstico, `FIRST PENDING R298` sujeito a preflight.

## Protocolo reproduzível

- Origem: R22 original + overlay R289–R295 + R296 (hashes pinned em `R297_RESULTS_MESTRE_ONLY.json`); o executável usa `chat.create`, `chat.decide` PASS e `dyn.checked_load` de **código já existente**.
- Três sementes distintas: `[297350, 297351, 297352]`. Em cada uma, 1 START e 22 PASS, em 2 atores fictícios. Total: **3 execuções independentes, 69 decisões e 66 PASS**. Não são 69 combates, não são células oficiais e não há ataques/cura nestas medições.
- Cada ação e `checked_load` foi cronometrado separadamente com `time.perf_counter`. Variação entre sementes e cache da máquina são limitações de inferência; não há avaliação de host remoto ou de 20x20.

## Resultados médios simples (3 execuções)

| PASS nº | Latência média da decisão | Latência média de `checked_load` |
|--:|--:|--:|
| 1 | 0.081 s | 0.011 s |
| 5 | 0.398 s | 0.060 s |
| 10 | 0.769 s | 0.104 s |
| 15 | 1.275 s | 0.165 s |
| 20 | 2.007 s | 0.254 s |
| 22 | 2.176 s | 0.297 s |


A decisão PASS número 22 consumiu em média **26.7x** a duração da primeira. Este diagnóstico observa aumento dentro desse benchmark, mas **não prova sozinho** a ordem assintótica, qual função responde pelo custo ou uma falha semântica. Há duplicação intencional de validações da origem de combate, do journal e do redutor A1; qualquer otimização precisa preservar rejeição de adulterações, single-commit e recuperação após crash.

## Uso futuro

O arquivo `code/R297_PORTABLE_BENCH.py` aceita `--engine` apontando a extração histórica R22 com os overlays R289/R295/R296 já instalados e testados, e roda somente com módulos existentes. Ele NÃO instala pacotes e NÃO escreve Notion; suas cenas são temporárias. No R298, antes de otimizar, aplicar `cProfile` e atribuir custo por função; só se existir gargalo localizado, propor pequeno patch reversível com equivalência bytewise de eventos, fail-closed e regressão R18–R22. Evitar retirar auditoria apenas para acelerar.

**Gates:** PERF-EXPLORATORY-TEST; 0/17 terminais, 0/1.875 células R91. Inbox/OP/Diário sem escrita; Comestre instance/writer/lease/epoch/fencing GREEN HOLD. `GH-NOT-RUN` por uso proporcional. Party/O Primeiro NO-WRITE.
