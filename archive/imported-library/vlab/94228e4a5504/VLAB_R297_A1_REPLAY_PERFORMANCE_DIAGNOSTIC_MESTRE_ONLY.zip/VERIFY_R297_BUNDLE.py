from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
m=json.loads((p/'SHA256_MANIFEST_R297.json').read_text())
for n,h in m.items():
 f=p/n
 assert f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==h,n
assert {str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()}==set(m)|{'SHA256_MANIFEST_R297.json','VERIFY_R297_BUNDLE.py'}
print('R297_BUNDLE_INTEGRITY_PASS',len(m))
