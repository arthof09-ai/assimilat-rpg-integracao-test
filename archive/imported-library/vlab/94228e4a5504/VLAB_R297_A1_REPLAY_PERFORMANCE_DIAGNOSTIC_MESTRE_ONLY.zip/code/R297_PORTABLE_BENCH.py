"""Portable R297 benchmark: source-closed CHECKED load, zero canonical writes.

Example: python R297_PORTABLE_BENCH.py --engine /path/to/reconstructed_R22 --seed 297351 --passes 6
Assumes the caller already verified the source R22/R295/R296 chain and installed the patches.
"""
import argparse,sys,uuid,time,tempfile,json,pathlib
p=argparse.ArgumentParser()
p.add_argument('--engine',required=True,help='Root containing fusion_stage12')
p.add_argument('--seed',type=int,default=297350)
p.add_argument('--passes',type=int,default=22)
p.add_argument('--output',default=None)
a=p.parse_args()
root=pathlib.Path(a.engine).resolve()
if root.name=='fusion_stage12':mods=root
else:mods=root/'fusion_stage12'
if not (mods/'vlab_r21_dynamic_a1.py').is_file() or not (mods/'vlab_r22_chat_adapter.py').is_file():p.error('missing historical R21/R22')
if not 1<=a.passes<=40:p.error('bounded synthetic sample only')
sys.path.insert(0,str(mods))
import vlab_r22_chat_adapter as chat,vlab_r21_dynamic_a1 as dyn
results=[]
with tempfile.TemporaryDirectory(prefix='vlab-r297-') as t:
 dir=pathlib.Path(t);v=chat.create(dir,{'scenario':'A','seed':a.seed});cid=v['combat_id'];db=chat.path_for(dir,cid)
 def decide(action):
  global v
  s=v['battle'];q={'combat_id':cid,'revision':s['revision'],'head':s['head'],'actor':s['active_actor'] or '', 'intent_id':uuid.uuid4().hex,'action':action}
  tick=time.perf_counter();v=chat.decide(dir,q)
  return time.perf_counter()-tick
 decide('START')
 for i in range(a.passes):
  cost=decide('PASS');tick=time.perf_counter();st,h,r=dyn.checked_load(db);load=time.perf_counter()-tick
  if st['phase'] not in ('ACTIVE','COMPLETE_LAB'):raise RuntimeError('unexpected phase')
  results.append({'pass_n':i+1,'revision':r,'action_s':cost,'checked_load_s':load})
out={'status':'R297_LOCAL_DIAGNOSTIC_ONLY','seed':a.seed,'pass_count':len(results),'results':results,'canonical_credits':0,'notion_writes':0}
if a.output:pathlib.Path(a.output).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'seed':a.seed,'passed_decisions':len(results),'last_revision':results[-1]['revision'],'last_action_s':round(results[-1]['action_s'],5),'last_verified_load_s':round(results[-1]['checked_load_s'],5),'canonical_credits':0},indent=2))
