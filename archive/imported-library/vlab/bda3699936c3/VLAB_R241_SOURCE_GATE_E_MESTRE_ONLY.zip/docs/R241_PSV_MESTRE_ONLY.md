PSV — R241, Bateria E, triagem fonte READ-ONLY (MESTRE-ONLY).

ANTES: 0 fonte E completa; R238 e R240 preservados. Consultado módulo REC-MOD-ARM-01 (19 armas oficiais) e lista de armas com 18 apontadores mais Espada do Lendário. Reabertos os registros com o conector Notion; sem escrever, sem buscar/usar Party para completar a fonte.

DEPOIS: cinco candidatas detalhadas (Lança Sopro Congelante, Arco Exterminador Elemental, Adaga da Serpente Enfeitiçada, Espada Chamas Vivas, Espada do Lendário), com termos de dano/PA preservados e lacuna decisiva individualizada. Nenhuma atende simultaneamente (i) ataque físico base mensurável, (ii) magia comprovadamente separável no mesmo golpe, (iii) chassi idêntico com/sem efeito sob fonte, (iv) escopo de RD por componente e (v) teste e admissibilidade P4. Portanto, triagem de candidatas, NÃO ensaio nem prova de inexistência de item admissível em todo Notion.

PENDÊNCIA E-013 fica HOLD; alternativa executável segura é retomar outras frentes R18, sem criar novo chassi, inventar efeito ou alterar regras. Resultado canônico/Party/O Primeiro/escritas=ZERO. Checkpoint 0/17 terminais, 0/1875 células. NAC-PASS de leitura e extração da fonte, sem certificação produtiva.
