# R35 — PRIMEIRO EMPURRÃO NATIVO, GEOMETRIA E COMPARAÇÃO BRONZE 1 × BRONZE 1

**Mestre-side | CM-000006 | OP-VLAB-FUSION-SANDBOX-01 existente | 15/10/2026**  
**Estado:** rodada experimental materialmente concluída nas frentes A/B/D; defesa voluntária fonte-real em HOLD por dados de reação ausentes. **Não-canônico.** Esta rodada não altera `DMG-RANK-01 v1.1` nem produz crédito produtivo.

## 1. PSP — ANTES e autoridade

A R34 foi aprovada proporcionalmente pelo Mestre: **1 combate completo** entre Frígido Ossário Bronze5 e Cabra de Chifres Bronze1, 3 rodadas, 5 ataques, **0 empurrões acionados**, 0 reações voluntárias e testes locais declarados. A ação Investida da Cabra tem decisão expressa e específica do Mestre, fisicamente reconciliada no Notion: Luta +6 somente na Investida, `1d6+FOR13` de **impacto**, 1 Ação Padrão, 0 PA adicional, corpo a corpo adjacente, efeito de empurrão **1,5m a cada marco completo de 300 FF** após hit e dano líquido positivo, sem salvaguarda extra, direção para longe, impedimento por obstáculo sem dano de colisão presumido, Reações normais disponíveis, sem ataque de oportunidade por movimento forçado. FF `(FOR13+DES8+CON10)×10=310` => **1,5m** para esta Cabra. `P5` iniciativa bônus +0 e `P6` declinar voluntariamente Reações somente para a bateria experimental inicial. Não generalizar o +6 ou o efeito a outras Bestas.

Fontes reabertas nesta rodada, sem mudança de data de edição:
- Cabra B1: https://app.notion.com/p/391c2b324ede8252b0cc810423cdbfa6 — Vida38, Alma22, CA20, FOR13, DES8, CON10, Investida real;
- Galidemus/Galinha Demoníaca B1: https://app.notion.com/p/eddc2b324ede829f8a75011e8acbf429 — Vida32, Alma32, **CA impressa21**, FOR5, DES13, CON6, Patada real não executada aqui; não recalcular os impressos a partir da nova regra;
- Criação de Besta: https://app.notion.com/p/3ebc2b324ede81f4992ac88a3588cacd — RD Bronze normal5; velocidade Bronze normal `8+DES/4`, Cabra10m; 
- Sistema de Combate: https://app.notion.com/p/3ebc2b324ede81f1be4be8804ac113c0 — ataques, `Defender = 6+CON+Armadura+Fortitude`, `Esquivar = CA+Reflexo`;
- OP original: https://app.notion.com/p/3f3c2b324ede819496ddd7f93bd7e5d2 — decisões R32/R34, sem alteração das fichas originais.

`verify_pins()` do gateway R31 foi executado. O motor do dano/acerto/CA/RD/HP/Ação Padrão permanece **v0.8.1 histórico `apply_weapon_attack`**, não um resolvedor paralelo. Iniciativa e refresh da Reação são **R26**, turno **R18**, journaling SQLite WAL e replay são **R18**, arquivo de autoridade da Investida é cópia de leitura do pacote histórico R34.

## 2. R35-A — primeira Investida que acertou e empurrou outra espécie real

Cenas *isoladas*, com Cabra atacando Galidemus, posições LAB `Cabra (0,0)` e `Galidemus (1,5,0)` em metros, ambiente aberto e P6 ambas voluntariamente sem Reação.

| Semente | d6 acerto | Ataque total vs CA21 | Dano líquido | Empurrão | Resultado do alvo |
|---:|---:|---|---:|---|---|
| 353 | 2 | 21, empate = erro | 0 | 0 | 32 HP; em (1,5;0) |
| 359 | 2 | 21, empate = erro | 0 | 0 | 32 HP; em (1,5;0) |
| 373 | 1 | 20, erro | 0 | 0 | 32 HP; em (1,5;0) |
| **379** | **4** | **23 > 21, acerto** | **14** | **1,5m** | **32→18 HP; (1,5;0)→(3,0;0)** |
| 383 | 1 | 20, erro | 0 | 0 | 32 HP; em (1,5;0) |

**Importante:** todas as cinco tentativas foram mantidas; 379 não foi escolhida como se fosse a primeira. R35-379 é a **primeira prova de empurrão efetivo contra uma espécie real distinta** no laboratório. Evento de golpe = `v0.8.1.apply_weapon_attack` e deslocamento acoplado à mesma transação SQLite, sem novo ataque ou dano extra. Depois do acerto, distância Cabra–Galidemus **1,5m→3,0m** e adjacência falsa. A Patada da Galidemus não foi executada porque não possui contrato completo; **5 sondas não são combates completos**.

## 3. R35-B/D — primeiro confronto equilibrado com consequência espacial real

Uma segunda forma legítima de usar a fonte é criar **duas instâncias efêmeras da MESMA Cabra Bronze1 oficial** em arena experimental, mantendo atributos, HP38, CA20, RD5, Investida real e mesmo bônus Luta +6 específico. Isso não constitui criação de espécie nem modifica a ficha.

| Seed | Vencedora | Primeiro turno vence? | Ataques | Acertos | Empurrões | Movimentos de reaproximação |
|---:|---|---|---:|---:|---:|---:|
| 367 | Cabra B | Não | 8 | 6 | 6 | 5 |
| 389 | Cabra A | Sim | 9 | 7 | 7 | 6 |
| 397 | Cabra B | Não | 8 | 7 | 7 | 6 |
| 401 | Cabra A | Não | 8 | 7 | 7 | 6 |
| 409 | Cabra A | Sim | 7 | 6 | 6 | 5 |
| **TOTAL** | **5/5 terminais** | **2/5** | **40** | **33** | **33** | **28** |

**Mecânica do primeiro empurrão espelhado, seed 367:** A em (0;0) ataca B em (1,5;0), ataque acerta, dano líquido16, B é movida para (3,0;0). Distância agora **3m**, adjacência **não**. Em seu turno, B gasta **Ação de Movimento** e volta de (3,0;0) para (1,5;0), distância novamente 1,5m; somente então sua Investida é admitida. Sua Investida também acerta e empurra A de (0;0) para (-1,5;0). Ambos movimentos, ataques, recursos, coordenadas e resultados estão preservados no mesmo ledger transacional e comparados no replay. **No conjunto das 5 lutas há 33 empurrões realmente acionados**, não 33 testes artificiais.

No conjunto das **10 cenas novas** (5 sondas e 5 duelos), registraram-se **45 ataques nativos**, **34 acertos/empurrões** (1 nas sondas +33 nos duelos) e **28 Movimentos**; 5 + 5 bancos SQLite novos, cada qual com ID, seed, recibo, genesis, replay e backup. Sementes independentes: 10 cenas; várias ações dentro da mesma cena **não** são amostras independentes de vitória. História R34 não foi repetida e permanece uma luta distinta.

### Geometria e estresse

6/6 casos de guarda rodados em cópia **somente na memória, sem registrar combate**:
1. erro não empurra;
2. dano líquido zero não empurra;
3. obstáculo sem percurso legitimado -> HOLD sem atravessar;
4. limite de arena -> HOLD sem deslocar;
5. adulteração FF310→299 -> HOLD na decisão específica, sem redefinir regra de FF;
6. após empurrão legítimo 1,5m, alvo perde adjacência e uma Ação de Movimento com velocidade Bronze10m a restaura.

**Nenhum dano automático de colisão, reação de oportunidade por movimento forçado ou deslocamento através de paredes foi criado.** O ambiente aberto foi um **parâmetro da arena experimental**, não geografia canônica.

## 4. Ciência fonte-específica e incerteza

Comparação *sem críticos/reações*:

| Caso | Probabilidade de acertar (critério `>CA`) | Dano líquido por acerto (RD5) | E[líquido por tentativa] |
|---|---:|---:|---:|
| Cabra → Frígido B5, CA31 (R34) | 0/6 | `1d6+8` condicionado | **0** |
| Cabra → Galidemus B1, CA21 (R35 sondas) | **4/6** | `1d6+8`, média11,5 | **7,667** |
| Cabra → Cabra B1, CA20 (R35 espelho) | **5/6** | `1d6+8`, média11,5 | **9,583** |

O *oráculo matemático independente* R35 para espelho assume dados de ataque/dano independentes por tentativa, 1/108 crítico positivo com acréscimo máximo do dado6, 1/108 falha crítica LAB, sem Reações/obstáculos e com Movimento suficiente para recuperar adjacência. Ele estima **4,6303 tentativas próprias** até esgotar os 38 HP e **64,74%** de vitória para quem age primeiro por simetria e empate de contagem de ações. Essa é a previsão idealizada, **não** uma taxa de vitória observada nem conclusão canônica. O executor obteve somente **2/5** vitórias do primeiro ator; amostra pequena e RNG sequenciado por evento/ator, sem inferência populacional robusta. A R29 já alertara sobre fluxo de RNG: não declarar causalidade isolada aqui.

Os dados mostram por que **precisão contra CA, RD e geometria** importam mais que apenas comparar 1d6+13 bruto: contra Frígido nenhum acerto básico da Investida, contra pares Bronze1 há dano e controle espacial. A comparação preserva DMG-RANK v1.1 e não importa novas regras. R35 não demonstra balanceamento universal ou frequência ótima do efeito de empurrão.

## 5. R35-C — Reações defensivas: diagnóstico que impede certificação real

O Sistema de Combate especifica **Defender = 6 + CON + Armadura + Fortitude** e **Esquivar = CA + Reflexo**. A fonte Bronze1 da Cabra e a fonte da Galidemus **não publicam** os valores individuais de Armadura, Fortitude ou Reflexo. Em R35, o construtor deixa esses campos **`null`**, não `0`. O preflight de defesa fonte-real recusa precisamente:

- **DEFENDER:** `ARMADURA_INDETERMINADA` e `FORTITUDE_INDETERMINADA`;
- **ESQUIVAR:** `REFLEXO_INDETERMINADO`.

Nenhuma Reação foi consumida fraudulentamente ou anunciada automaticamente. Os slots 1/1, as janelas defensivas e sua renovação pelo R26 permanecem presentes, mas ambos recusaram voluntariamente nas 5 lutas P6; assim **0 Reações voluntárias efetivas** nesta rodada. Com Cabra atacante (escore 20..25) vs Cabra CA20, o primeiro acerto é21: DEFENDER só poderia neutralizá-lo com `Armadura+Fortitude >=5`; ESQUIVAR só poderia neutralizá-lo com `Reflexo >=1`. Esses **limiares são contrafactuais**, não bônus atribuídos à ficha.

A menor decisão futura capaz de viabilizar a primeira Esquiva é determinar o **Reflexo individual da Cabra de Chifres Bronze1**, sem transformar o valor em proficiência universal. Não é necessário novo motor para essa decisão: o histórico v0.8.1 já implementa `react_defensively` e aceita a janela fonte-legítima quando as entradas forem completas.

## 6. Auditoria e preservação

- **10/10 bancos novos** íntegros, `pending=0`, recibos e checkpoints únicos, fonte/autoridade vinculadas, nenhum efeito no mundo.
- **140/140 verificações read-only PASS**, incluindo comparação de SHA de cada SQLite, cadeia R18, snapshot, fonte, replay independente e estado lógico restaurado de cada checkpoint. Os **45 ataques** novos foram efetivamente produzidos pelo `v0.8.1.apply_weapon_attack` histórico, enquanto as integrações espaciais pertencem à camada aditiva e transacional R35.
- **6/6 regressões de geometria PASS** em clones efêmeros, zero eventos nativos contabilizados por esses testes.
- Códigos originais e arquivos legados R27–R34 não foram regravados. **8/8 ZIPs recuperados R27–R34 conferidos por SHA256 exato**, sem reexecutar R27 e sem retomar seed53/UNKNOWN_EFFECT.
- Os cinco confrontos espelhados são **completos somente no perfil de política P6 previamente autorizado**, sem Reações defensivas voluntárias. Não comprovar uma política que não foi utilizada.

### Contadores proporcionais

| Indicador | ANTES R34 | DEPOIS R35 |
|---|---:|---:|
| Combates completos real-fonte em sandbox | 1 | **6** (+5 espelhos) |
| Novos empurrões efetivos desde R34 | 0 | **34** (+33 espelho, +1 contra Galidemus) |
| Novos combates com outra espécie | — | **0** (Galidemus apenas alvo de sonda) |
| Novas sondas isoladas com outra espécie | 0 | **5** (1 hit, 4 miss) |
| Reações voluntárias efetivamente executadas R35 | 0 | **0** (snapshot da defesa incompleto) |
| Patamares distintos nos combates completos | Bronze1/Bronze5 | **Bronze1/Bronze5 =2/25**, sem novos |
| Contratos VLAB terminais | 0/17 | **0/17** |
| Células canônicas | 0/1.875 | **0/1.875** |
| Combates canônicos da campanha | 0 | **0** |

**NAC-PASS-02 produtivo:** HOLD; writer, lease, epoch, fencing e GREEN produtivos HOLD; IBX-56 permanece BLOCKED-EXTERNAL, IBX-90/91/92 sem ACK assumido. Nenhuma ação sobre fichas, Party ou O Primeiro.

## 7. Fronteira e ponto exato de retomada

**Última unidade verificada:** R35 dez cenas com dez checkpoints individuais e auditoria independente 140/140. **Primeira pendência que exige autoridade:** bônus individual de Reflexo da Cabra para **ESQUIVAR**, ou conjunto Armadura + Fortitude para **DEFENDER**; registrar uma decisão específica e testar reação em nova cena, nunca editar os bancos completos. **Hipótese científica seguinte:** duas Cabras de fonte real com mesmos dados, política P6 sem Reações versus defesa voluntária Esquivar com Reflexo explicitamente determinado, sementes pareadas e RNG por ator/evento comparável; verificar proteção, renovação, dano, HP, TTK e efeito sobre empurrão. Expandir para outra espécie somente quando a ação dela estiver completa; não presumir Luta da Galidemus. Preservar estudo independente RDF10 Rinolupo.

**Regra anti-reexecução:** cada banco `runs/R35_*.sqlite` está terminal. Auditar primeiro `R35_INDEPENDENT_AUDIT.json`, `R35_SCIENCE_AGGREGATION.json` e `checkpoints/`. Jamais chamar o runner para o mesmo arquivo ou reaproveitar intenção anterior sem reconciliação.
