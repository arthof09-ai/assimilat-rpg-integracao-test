"""R35 independent ZIP/SQLite checker using only Python standard library.
Does not re-run combat or change source/output. Read-only artifact gate, not NAC-PASS.
"""
from __future__ import annotations
import hashlib,json,sqlite3,sys,zipfile,io,tempfile,os
from pathlib import Path

def H(x):return hashlib.sha256(x).hexdigest()
def JS(obj):return json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
def SHA(obj):return H(JS(obj))
def DBinspect(raw):
 with tempfile.TemporaryDirectory() as d:
  p=Path(d)/'read_only.sqlite';p.write_bytes(raw)
  c=sqlite3.connect('file:'+str(p)+'?mode=ro&immutable=1',uri=True)
  try:
   assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
   meta=dict(c.execute('SELECT key,value FROM meta'));rows=list(c.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq'))
   assert c.execute('SELECT COUNT(*) FROM pending').fetchone()[0]==0
   revision=int(meta['revision']);assert len(rows)==revision
   st=json.loads(meta['state']);assert st['r35']['world_effects']==0
   assert st['source_status']=='SOURCE_REAL_READONLY_ISOLATED_SANDBOX'
   prev=meta['genesis'];last_after=None;computed=[]
   for n,cmd,past,row_s,row_sha,before,after in rows:
    row=json.loads(row_s)
    assert n==len(computed)+1 and cmd==row['cmd_id'] and n==row['seq']
    assert past==prev==row['prev'] and row['before_sha']==before and row['after_sha']==after
    assert SHA(row)==row_sha and (last_after is None or before==last_after)
    assert row['synthetic'] is True and row['official_effects']==0
    computed.append(row)
    prev=row_sha;last_after=after
   assert prev==meta['head'] and (last_after is None or last_after==SHA(st))
   assert st['r35']['mode'] in ('MIRROR','PROBE')
   assert all(a['source_kind']=='NOTION_MASTER_REAL' for a in st['actors'].values())
   assert len(computed)==st['r35']['attacks']+(1 if st['r35']['mode']=='MIRROR' else 0)
   return {'meta':meta,'state':st,'rows':computed,'revision':revision,'head':prev}
  finally:c.close()

def verify(path):
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None,'ZIP CRC'
  names=z.namelist();assert len(names)==len(set(names))
  manifest=json.loads(z.read('R35_FILE_MANIFEST.json'))
  files=manifest['files'];assert len(files)==len(names)-1
  for rel,sha in files.items():
   assert rel in names and H(z.read(rel))==sha,rel
  summary={'CRC':'PASS','file_hashes':len(files),'scenes':0,'revisions':0,'attacks':0,'pushes':0,'movement':0,'read_only_sqlite_integrity':0}
  for typ,ss in [('PROBE',[353,359,373,379,383]),('MIRROR',[367,389,397,401,409])]:
   for seed in ss:
    base=f'R35_{typ}_SEED{seed}';live=z.read(f'runs/{base}.sqlite');bak=z.read(f'checkpoints/{base}_BACKUP.sqlite');rec=json.loads(z.read(f'evidence/{base}_RECEIPT.json'));g=json.loads(z.read(f'evidence/{base}_GENESIS.json'))
    assert H(live)==rec['ledger']['sha256'] and H(bak)==rec['checkpoint']['sha256']
    orig=DBinspect(live);backup=DBinspect(bak)
    assert orig['state']==backup['state'] and orig['rows']==backup['rows'] and orig['head']==backup['head'] and orig['revision']==backup['revision']
    assert orig['revision']==rec['after']['revision'] and orig['head']==rec['after']['head']
    assert rec['replay']['status']=='PASS' and rec['replay']['events']==orig['revision']
    assert orig['state']['seed']==seed and orig['state']['r35']['mode']==typ
    assert rec['before']['hp']=={a:x['resource']['hp'] for a,x in g['state']['actors'].items()}
    assert orig['state']['r35']['world_effects']==0 and all(v in ('391c2b32-4ede-8252-b0cc-810423cdbfa6','eddc2b32-4ede-829f-8a75-011e8acbf429') for v in rec['source_pages'].values())
    # Confirm recorded movement and pushes from persisted event details; no counting cloned tests
    hit_events=[e for e in orig['rows'] if e['kind']=='R35_REAL_GOAT_NATIVE_ATTACK']
    n_push=sum(e['detail']['forced_push'] is not None for e in hit_events);n_move=sum(e['detail']['movement'] is not None for e in hit_events)
    assert n_push==rec['after']['pushes'] and n_move==rec['after']['movement_actions']
    assert len(hit_events)==rec['after']['attacks']
    if typ=='MIRROR':
     assert orig['state']['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS' and orig['state']['winner'] in orig['state']['actors']
     assert set(x['detail']['actor'] for x in hit_events)==set(orig['state']['actors'])
    else:
     assert orig['state']['phase'].startswith('COMPLETE_ISOLATED_') and len(hit_events)==1 and rec['full_fight_credit'] is False
    summary['scenes']+=1;summary['revisions']+=orig['revision'];summary['attacks']+=len(hit_events);summary['pushes']+=n_push;summary['movement']+=n_move;summary['read_only_sqlite_integrity']+=2
  assert summary['scenes']==10 and summary['revisions']==50 and summary['attacks']==45 and summary['pushes']==34 and summary['movement']==28
  return summary

if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('usage: python verify_r35_archive_standalone.py FILE.zip')
 result=verify(sys.argv[1]);print(json.dumps({'status':'PASS_STANDALONE_ARCHIVE_AND_SQLITE',**result},ensure_ascii=False,indent=2))
