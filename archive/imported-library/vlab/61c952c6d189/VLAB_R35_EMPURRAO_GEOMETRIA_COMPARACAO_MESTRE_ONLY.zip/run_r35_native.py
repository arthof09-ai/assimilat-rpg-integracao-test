"""R35 additive real-source geometry adapter. SAME v0.8.1 native attack, R26 initiative,
R18 SQLite event_commit and next_turn. Source pins/goat decision from verified R34.
Two modes: Goat->Galidemus one legally admitted push probe; mirror Goat vs Goat.
No production write or canonical credit, no alteration of archived engine files.
"""
from __future__ import annotations
import sys,json,copy,hashlib,sqlite3,math,os
from pathlib import Path
from dataclasses import asdict
R=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'extension'),str(R/'r27'/'fusion_stage12')]
import vlab_r31_real_source_gateway as g
import vlab_r18_interactive as j
import vlab_r26_master_rulings as r26
from vlab_action_catalog_v01 import ActorActionState,AbilitySource,FrozenRuleEvidence,action_menu
from vlab_effects_v08 import Combatant,Scene,apply_weapon_attack
from vlab_rd_v08 import Resistances
GOAT='391c2b32-4ede-8252-b0cc-810423cdbfa6';GALI='eddc2b32-4ede-829f-8a75-011e8acbf429';OP='3f3c2b32-4ede-8194-96dd-d7f93bd7e5d2'
AR=R/'authority'/'MESTRE_INVESTIDA_R34_VERIFIED.json'
GO_RULE='MESTRE-INVESTIDA-CABRA-B1-P1-P6-FF300-20261015'
GO_ACTION='CABRA_INVESTIDA_MESTRE_R34_FF300'
GOAT_SOURCE={'name':'Cabra de chifres','page':GOAT,'last_edit':'2026-10-01T18:00:34.040Z','rank':'Bronze','star':1,'hp':38,'pa':22,'ca':20,'for':13,'des':8,'con':10,'int':2,'sab':8,'car':2,'literal_ability':'Investida: joga a pessoa para longe, o alvo sofre 1d6 + força impacto.'}
GAL_SOURCE={'name':'galinha demoníaca','page':GALI,'last_edit':'2026-10-01T18:00:52.905Z','rank':'Bronze','star':1,'hp':32,'pa':32,'ca':21,'for':5,'des':13,'con':6,'int':6,'sab':3,'car':10,'literal_ability':'Patada: 1d4 + destreza cortante'}
MODE='MASTER_REAL_SOURCE_AUTHENTICATED_SANDBOX_NO_CANON';ADJ=1.5
class Hold(RuntimeError): pass

def canonical_write(rel,obj):
 p=R/rel;p.parent.mkdir(exist_ok=True,parents=True)
 with p.open('x',encoding='utf8') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
 return p

def sha_file(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def authorization():
 x=json.load(open(AR))
 if x.get('verified_by_comestre_after_notion_readback') is not True or x.get('master_explicit') is not True or x.get('operation_page')!=OP or x.get('goat_source_page')!=GOAT:raise Hold('GOAT_SOURCE_AUTHORITY')
 if x.get('luta_bonus')!=6 or x.get('damage')!='1d6+FOR13' or x.get('damage_tag')!='impacto' or x.get('action_kind')!='STANDARD' or x.get('additional_PA')!=0:raise Hold('GOAT_ACTION_TAMPER')
 if x.get('derived_goat_FF')!=310 or x.get('resulting_push_meters')!=1.5 or x.get('distance_formula')!='1.5 meters per complete 300 Forca Fisica':raise Hold('PUSH_RULING_DIFF')
 if x.get('push_trigger')!='HIT_AND_NET_DAMAGE_POSITIVE' or x.get('reactions')!='AVAILABLE_REFRESH_R26_BOTH_DECLINE_VOLUNTARY_REACTIONS_FIRST_BATTERY':raise Hold('REACTION_SCOPE_DIFF')
 return x

def manifest(mode):
 return {'schema':'R35_SOURCE_REAL_MASTER_READBACK_NOT_NOTION_SIGNED','mode':mode,'source_goat':GOAT_SOURCE,'source_target':GAL_SOURCE if mode=='PROBE' else GOAT_SOURCE,'authority':authorization(),'notion_rule':'3ebc2b32-4ede-81f1-be4b-e8804ac113c0','notion_beast_creation':'3ebc2b32-4ede-81f4-992a-c88a3588cacd','real_source_not_canonical_battle':True}

def ids(mode):return ('LAB_R35_GOAT_A','LAB_R35_GALIDEMUS_B') if mode=='PROBE' else ('LAB_R35_GOAT_A','LAB_R35_GOAT_B')

def source_of(mode,aid):return GOAT_SOURCE if (aid==ids(mode)[0] or mode=='MIRROR') else GAL_SOURCE

def make_actor(aid,src):
 resource=asdict(Combatant(aid,src['hp'],src['pa'],src['ca'],src['con'],None,None,None,'R35-COORD-'+aid,rank=src['rank']))
 return {'name':src['name'],'source_page_id':src['page'],'source_kind':'NOTION_MASTER_REAL','source_as_of':src['last_edit'],'stats':{'for':src['for'],'des':src['des'],'con':src['con'],'rank':src['rank'],'star':src['star'],'init_bonus':0,'init_bonus_origin':'MASTER_R34_LAB_P5_ONLY','luta_bonus':6 if src['page']==GOAT else None,'luta_origin':'MASTER_CABRA_INVESTIDA_ONLY' if src['page']==GOAT else 'UNRESOLVED_OTHER_ACTION'},'resource':resource}

def native_source():return AbilitySource(GO_ACTION,'attack','STANDARD',GOAT,GO_RULE,'EXPLICIT-CANON',required_pa=0,target_scope='ENEMY',max_targets=1,min_rank_index=1,requires_range_check=True,effect_adapter_ready=True,effect_adapter_id='NATIVE-V081-APPLY-WEAPON-ATTACK')

def proof(mode):return FrozenRuleEvidence(GOAT,GO_RULE,j.sha(manifest(mode)),'2026-10-15:NOTION_OP_READBACK','OP-VLAB-R34-MASTER-P1-P6-FF310')

def positions(st):return st['r35']['geometry']['positions']
def dist(st):
 aa,bb=ids(st['r35']['mode']);return math.dist(positions(st)[aa],positions(st)[bb])

def initialize_state(st,mode):
 a,b=ids(mode);st['actors']={aid:make_actor(aid,source_of(mode,aid)) for aid in (a,b)}
 st['phase']='INIT' if mode=='MIRROR' else 'ACTIVE';st['round']=0 if mode=='MIRROR' else 1;st['turn']=0;st['active']=None if mode=='MIRROR' else a;st['order']=[] if mode=='MIRROR' else [a,b];st['roll_nonce']=0;st['winner']=None;st['finish_reason']=None
 st['source_status']='SOURCE_REAL_READONLY_ISOLATED_SANDBOX';st['source_confidence']='PHYSICALLY_REOPENED_SOURCE_EXCERPTS_NOT_SIGNED';st['scene']='R35-'+mode
 st['r35']={'schema':'REAL_BEAST_GEO_NATIVE_R35_V1','mode':mode,'source_proof_hash':j.sha(manifest(mode)),'goat_authority_file_sha':sha_file(AR),'source_mode':MODE,'world_effects':0,'reaction_policy':'P6_BOTH_DECLINE_VOLUNTARY_WITH_R26_REFRESH','policy':'GOAT_INVESTIDA_IF_ADJACENT','attacks':0,'hits':0,'pushes':0,'movement_actions':0,'reactions_selected':0,'geometry':{'unit':'meters','positions':{a:[0.0,0.0],b:[1.5,0.0]},'bounds':[-25.0,25.0],'terrain':'OPEN_SCENARIO_NO_OBSTACLES','adjacency_m':1.5,'goat_ff':310,'goat_push_m':1.5,'speed_m':{a:10.0,b:10.0 if mode=='MIRROR' else 11.25}},'finished':False}
 return st

def create(db,mode,seed):
 if Path(db).exists():raise Hold('NO_REUSE_EXISTING_DB')
 _=authorization();g.verify_pins()
 j.init_db(db,'A',seed)
 c=j.connect(db)
 try:
  c.execute('BEGIN IMMEDIATE');m=dict(c.execute('SELECT key,value FROM meta'))
  assert int(m['revision'])==0 and not c.execute('SELECT 1 FROM events').fetchone()
  st=initialize_state(json.loads(m['state']),mode)
  base=j.sha({'seed':seed,'mode':mode,'engine':j.VERSION,'source_hash':j.sha(manifest(mode)),'LAB':True})
  for key,val in [('state',j.canonical(st)),('genesis',base),('head',base),('scene',st['scene'])]:c.execute('UPDATE meta SET value=? WHERE key=?',(val,key))
  c.commit()
 except: c.rollback();raise
 finally:c.close()
 return checked(db,mode)

def checked(db,mode=None):
 st,h,v=j.load(db);typ=st['r35']['mode']
 if mode and typ!=mode:raise Hold('SCENE_MODE_MISMATCH')
 if st['r35']['source_proof_hash']!=j.sha(manifest(typ)) or st['r35']['goat_authority_file_sha']!=sha_file(AR):raise Hold('SOURCE_AUTH_CHANGED')
 if st['r35']['world_effects']!=0:raise Hold('WORLD_EFFECT_TAMPER')
 if {k:x['source_page_id'] for k,x in st['actors'].items()}!={a:source_of(typ,a)['page'] for a in ids(typ)}:raise Hold('ACTOR_AUTH_MISMATCH')
 return st,h,v

def prereq(st):
 if st['r35']['source_proof_hash']!=j.sha(manifest(st['r35']['mode'])):raise Hold('SOURCEMANIFEST_INVALID')
 if dist(st)<0.000001:raise Hold('OVERLAPPING_ACTORS')
 if st['r35']['geometry']['goat_ff']!=310:raise Hold('GOAT_FF_CHANGED')
 if st['r35']['reaction_policy']!='P6_BOTH_DECLINE_VOLUNTARY_WITH_R26_REFRESH':raise Hold('UNAUTHORIZED_REACTION_POLICY')

def preview(st):
 aid=st['active'];p=st['roll_nonce']+1;seed=st['seed'];crit=[j.dice(seed,p,'R35-CRIT-'+aid+'-'+str(k),1,6)[0] for k in (1,2,3)];hit=j.dice(seed,p,'R35-HIT-'+aid,1,6)[0];dmg=j.dice(seed,p,'R35-DAMAGE-'+aid,1,6)[0]
 pos=crit[:2]==[6,6] and crit[2]>=5;neg=crit[:2]==[1,1] and crit[2]<=2
 return {'actor':aid,'target':next(x for x in ids(st['r35']['mode']) if x!=aid),'nonce':p,'hit_die':hit,'damage_die':dmg,'critical_sequence':crit,'crit_kind':'POSITIVE' if pos else 'NEGATIVE' if neg else 'NONE','hit_total':hit+13+6,'roll_score_to_native':0 if neg else hit+13+6,'damage_to_native':0 if neg else dmg+13+(6 if pos else 0),'ff':310,'luta':6}

def move_to_adjacent(st,actor):
 d=dist(st)
 if d<=ADJ+1e-8:return None
 b=st['r35'];res=st['actors'][actor]['resource'];speed=b['geometry']['speed_m'][actor];need=d-ADJ
 if res['movement']!=1 or need>speed:raise Hold('MOVEMENT_CANNOT_REGAIN_ADJACENCY')
 pp=positions(st);tar=next(x for x in ids(b['mode']) if x!=actor);v=[(pp[tar][i]-pp[actor][i])/d for i in range(2)];before=pp[actor][:];pp[actor]=[round(before[i]+v[i]*need,8) for i in range(2)];res['movement']=0;res['position']=f'R35-LAB-{pp[actor]}';b['movement_actions']+=1
 if abs(dist(st)-ADJ)>1e-6:raise Hold('POST_MOVE_ADJACENCY_NOT_REACHED')
 return {'by':actor,'from':before,'to':pp[actor][:],'distance_m':round(need,8),'speed_m':speed,'cost':'1 MOVEMENT ACTION','source':'Criação de Besta Bronze normal speed 8+DES/4','voluntary':True,'world_effects':0}

def push_if_hit(st,attacker,target,effect):
 if not effect['hit'] or effect['net']<=0:return None
 b=st['r35'];pp=positions(st);origin=pp[target][:];here=pp[attacker];d=dist(st);length=1.5*math.floor(b['geometry']['goat_ff']/300)
 if length!=1.5 or d<=0:raise Hold('PUSH_AMOUNT_OR_VECTOR')
 unit=[(origin[i]-here[i])/d for i in range(2)];dest=[round(origin[i]+unit[i]*length,8) for i in range(2)];lo,hi=b['geometry']['bounds'];
 if b['geometry']['terrain']!='OPEN_SCENARIO_NO_OBSTACLES' or any(not lo<=x<=hi for x in dest):raise Hold('BLOCKED_PUSH_REQUIRES_GEOMETRY_DECISION')
 pp[target]=dest;st['actors'][target]['resource']['position']=f'R35-LAB-PUSH-{dest}';b['pushes']+=1
 return {'event':'FORCED_PUSH_AFTER_GOAT_INVESTIDA','from':origin,'to':dest,'meters':length,'unit':unit,'source_ff':310,'threshold_ff':300,'adjacent_after':dist(st)<=ADJ+1e-8,'post_distance_m':round(dist(st),8),'physical_obstacles':'NONE','no_collision_damage':True,'no_forced_opportunity':True,'world_effects':0}

def native_attack(st,p):
 aid=p['actor'];target=p['target'];b=st['r35'];src=native_source();pf=proof(b['mode']);actors=st['actors'];before_hp={a:x['resource']['hp'] for a,x in actors.items()};before_pa={a:x['resource']['pa'] for a,x in actors.items()}
 res=actors[aid]['resource'];state=ActorActionState(actor_id=aid,ordinal_level=1,available_pa=res['pa'],known_action_ids=(GO_ACTION,),standard_available=res['standard']==1,reaction_available=res['reaction']==1,range_confirmed=dist(st)<=ADJ+1e-8,geometry_confirmed=True,enemy_ids_visible=(target,))
 out=action_menu(state,(src,),strict=True,source_evidence=(pf,))
 if len(out.legal_options)!=1 or out.rejected:raise Hold('STRICT_GOAT_INVESTIDA_REJECTED:'+str(out.rejected))
 scene=Scene({a:Combatant(**copy.deepcopy(x['resource'])) for a,x in actors.items()},seed=st['seed'],provenance='LAB-REAL-MASTER-FONTE-AUTENTICADA-NONCAN')
 eff=apply_weapon_attack(scene,aid,target,source=src,state=state,proofs=(pf,),roll_score=p['roll_score_to_native'],damage=p['damage_to_native'],damage_tag='impacto',rd=Resistances(general=5,specific=(),provenance='CREACAO_BESTA_BRONZE_NORMAL_RD5'),strict=True)
 if eff['before_hp']-eff['after_hp']!=min(eff['before_hp'],eff['net']):raise Hold('NATIVE_HP_DIFF')
 for k,v in scene.actors.items():actors[k]['resource']=asdict(v)
 if {a:x['resource']['pa'] for a,x in actors.items()}!=before_pa or actors[aid]['resource']['standard']!=0:raise Hold('RESOURCE_ERROR')
 if any(actors[a]['resource']['hp']>before_hp[a] for a in actors):raise Hold('HP_INCREASE')
 return {'native_effect':eff,'scene_checksum':scene.checksum(),'source_action':GO_ACTION,'source_page':GOAT,'native_resolver':'original_v0.8.1.apply_weapon_attack'}

def init_turn(st,payload,seq):
 prereq(st)
 if st['r35']['mode']!='MIRROR' or st['phase']!='INIT' or seq!=1:raise Hold('INIT_NOT_ALLOWED')
 event=r26.resolve_initial_state(st);refresh=r26.refresh_own_turn(st,st['active'])
 return {'initiative_R26':event,'refresh_R26':refresh,'world_effects':0}

def run_turn(st,payload,seq):
 prereq(st);b=st['r35'];mode=b['mode'];act=st['active'];tgt=next(x for x in ids(mode) if x!=act)
 if st['phase']!='ACTIVE' or act!=payload['actor'] or tgt!=payload['target'] or st['round']!=payload['round']:raise Hold('TURN_ORDER_INVALID')
 if mode=='PROBE' and b['attacks']>=1:raise Hold('PROBE_ALREADY_USED')
 if st['actors'][act]['source_page_id']!=GOAT:raise Hold('GALIDEMUS_ACTION_NOT_ADMITTED')
 moved=move_to_adjacent(st,act)
 p=preview(st)
 if p!=payload['preview']:raise Hold('PREVIEW_DIFF')
 native=native_attack(st,p);effect=native['native_effect'];push=push_if_hit(st,act,tgt,effect)
 b['attacks']+=1;b['hits']+=int(effect['hit']);st['roll_nonce']=p['nonce']
 if mode=='PROBE':st['phase']='COMPLETE_ISOLATED_PUSH_PROBE' if push else 'COMPLETE_ISOLATED_MISS_PROBE';st['active']=None;transition={'probe_only':True};refresh=None
 elif st['actors'][tgt]['resource']['hp']<=0:
  st['phase']='COMPLETE_LAB_REAL_SOURCE_BESTAS';st['winner']=act;st['finish_reason']='HP_ZERO_SANDBOX_NONCAN';st['active']=None;transition={'combat_ended':True};refresh=None
 else:
  transition=j._next_turn(st);refresh=r26.refresh_own_turn(st,st['active'])
 return {'actor':act,'target':tgt,'round':payload['round'],'roll':p,'movement':moved,'native':native,'forced_push':push,'transition_R18':transition,'reaction_refresh_R26':refresh,'defensive_policy':'VOLUNTARILY_DECLINE_BOTH_R34_P6','hp':{k:x['resource']['hp'] for k,x in st['actors'].items()},'positions':copy.deepcopy(positions(st)),'round_after':st['round'],'phase_after':st['phase'],'world_effects':0}

def event_payload(st):return {'kind':'TURN','actor':st['active'],'target':next(x for x in ids(st['r35']['mode']) if x!=st['active']),'round':st['round'],'preview':preview(st),'source_sha':st['r35']['source_proof_hash'],'policy':'GOAT_INVESTIDA_AUTHORIZED_LAB'}

def metadata(db):
 st,h,r=checked(db);c=j.connect(db)
 try:p=c.execute('SELECT COUNT(*) FROM pending').fetchone()[0];integ=c.execute('PRAGMA integrity_check').fetchone()[0]
 finally:c.close()
 return {'head':h,'revision':r,'integrity':integ,'pending':p,'phase':st['phase'],'attacks':st['r35']['attacks'],'hits':st['r35']['hits'],'pushes':st['r35']['pushes'],'movement_actions':st['r35']['movement_actions'],'hp':{k:x['resource']['hp'] for k,x in st['actors'].items()},'positions':copy.deepcopy(positions(st)),'distance_m':round(dist(st),8),'winner':st.get('winner'),'world_effects':0}

def replay(gen,rows,end):
 clone=copy.deepcopy(gen)
 for idx,row in enumerate(rows,1):
  detail=init_turn(clone,row['payload'],idx) if row['kind']=='R35_REAL_BEAST_INIT' else run_turn(clone,row['payload'],idx)
  if j.sha(detail)!=j.sha(row['detail']) or j.sha(clone)!=row['after_sha']:raise Hold('INDEPENDENT_REPLAY_DIFF_'+str(idx))
 if clone!=end:raise Hold('REPLAY_FINAL_STATE_DIFF')
 return {'status':'PASS','events':len(rows),'last_state_hash':j.sha(clone),'terminal':clone['phase']}

def portable(db,path):
 if path.exists():raise Hold('CHECKPOINT_ALREADY_EXISTS')
 src=sqlite3.connect(db);dst=sqlite3.connect(path)
 try:src.backup(dst)
 finally:dst.close();src.close()
 a=j.history(db);b=j.history(path)
 if a!=b:raise Hold('BACKUP_LOGICAL_CONTENT_DIFF')
 return {'sha256':sha_file(path),'logical_equivalence':True,'integrity':metadata(path)['integrity']}

def run(mode,seed,max_events=45):
 tag=f'{mode}_SEED{seed}';db=R/'runs'/f'R35_{tag}.sqlite';out=R/'evidence'/f'R35_{tag}_RECEIPT.json';backup=R/'checkpoints'/f'R35_{tag}_BACKUP.sqlite'
 if db.exists() or out.exists() or backup.exists():raise Hold('NEVER_RESUME_OR_OVERWRITE:'+tag)
 st,head,r=create(db,mode,seed)
 before={'state':st,'head':head,'revision':r};canonical_write('evidence/R35_'+tag+'_GENESIS.json',before)
 if mode=='MIRROR':
  pay={'kind':'INIT','source_sha':st['r35']['source_proof_hash'],'seed':seed};shadow=copy.deepcopy(st);init_turn(shadow,pay,1)
  j.event_commit(db,'LAB-CMD-R35-INIT-'+j.sha(pay)[:26],'R35_REAL_BEAST_INIT',pay,init_turn)
 for k in range(max_events):
  st,head,rev=checked(db,mode)
  if st['phase']!='ACTIVE':break
  pay=event_payload(st);shadow=copy.deepcopy(st);run_turn(shadow,pay,rev+1)
  j.event_commit(db,'LAB-CMD-R35-ATTACK-'+j.sha({'head':head,'payload':pay})[:24],'R35_REAL_GOAT_NATIVE_ATTACK',pay,run_turn)
 st,head,rev=checked(db,mode);events=j.history(db)['events'];ra=replay(before['state'],events,st);info=metadata(db);snap=portable(db,backup)
 if info['integrity']!='ok' or info['pending'] or rev!=len(events) or info['world_effects']!=0:raise Hold('LEDGER_POSTFAIL')
 receipt={'schema':'R35_NATIVE_SOURCE_REAL_LAB_V1','mode':mode,'seed':seed,'source_pages':{a:source_of(mode,a)['page'] for a in ids(mode)},'before':{'hp':{a:before['state']['actors'][a]['resource']['hp'] for a in ids(mode)},'positions':before['state']['r35']['geometry']['positions']},'after':info,'ledger':{'path':str(db.relative_to(R)),'sha256':sha_file(db)},'checkpoint':snap,'replay':ra,'events':[{'seq':e['seq'],'kind':e['kind'],'detail':e['detail']} for e in events],'full_fight_credit':mode=='MIRROR' and info['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS','probe_not_full_fight':mode=='PROBE','world_canon_credit':0}
 canonical_write('evidence/R35_'+tag+'_RECEIPT.json',receipt)
 print(json.dumps({'mode':mode,'seed':seed,'stats':info,'replay':ra,'ledger_sha':receipt['ledger']['sha256']},ensure_ascii=False,indent=2))
 return receipt

if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('run_r35_native.py PROBE|MIRROR SEED')
 run(sys.argv[1],int(sys.argv[2]))
