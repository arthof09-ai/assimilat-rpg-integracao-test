"""Read-only audit + source-specific science R35. Does not replay a live transaction.
Creates new QA evidence only. Native replay is calculated on detached Python copies.
"""
from __future__ import annotations
import json,copy,hashlib,math,sqlite3,collections,sys
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import run_r35_native as m
from vlab_action_catalog_v01 import AbilitySource,ActorActionState,FrozenRuleEvidence,action_menu
from vlab_effects_v08 import Scene,Combatant,react_defensively
P=[353,359,373,379,383];D=[367,389,397,401,409]

def report(rel,value):
 return m.canonical_write('evidence/'+rel,value)

def independent_checks():
 result=[];total=0
 for typ,ss in [('PROBE',P),('MIRROR',D)]:
  for seed in ss:
   base=f'R35_{typ}_SEED{seed}';receipt=json.loads((R/'evidence'/f'{base}_RECEIPT.json').read_text());db=R/'runs'/f'{base}.sqlite';bk=R/'checkpoints'/f'{base}_BACKUP.sqlite';init=json.loads((R/'evidence'/f'{base}_GENESIS.json').read_text())
   st,h,rev=m.checked(db,typ);hist=m.j.history(db);events=hist['events'];meta=m.metadata(db)
   test={}
   test['original_receipt_sha_match']=receipt['ledger']['sha256']==m.sha_file(db)
   test['db_integrity_and_no_pending']=meta['integrity']=='ok' and meta['pending']==0
   test['ledger_chain_revision']=len(events)==rev==meta['revision'] and rev>=1 and h==meta['head']
   test['state_before_after_match']=meta==receipt['after'] and len(events)==len(receipt['events'])
   test['source_and_noncanon']=st['r35']['world_effects']==0 and all(actor['source_kind']=='NOTION_MASTER_REAL' for actor in st['actors'].values())
   test['native_event_source_pins']=all(e['detail'].get('native',{}).get('native_resolver')=='original_v0.8.1.apply_weapon_attack' for e in events if e['kind']=='R35_REAL_GOAT_NATIVE_ATTACK')
   test['replay_independent']=m.replay(init['state'],events,st)['status']=='PASS'
   test['checkpoint_sha_match']=receipt['checkpoint']['sha256']==m.sha_file(bk)
   test['checkpoint_logically_equal']=m.j.history(db)==m.j.history(bk)
   test['checkpoint_state_equals_original']=m.checked(bk,typ)[0]==st
   test['phase_terminal']=st['phase'] in ('COMPLETE_ISOLATED_MISS_PROBE','COMPLETE_ISOLATED_PUSH_PROBE','COMPLETE_LAB_REAL_SOURCE_BESTAS')
   test['force_formula_and_meter_scale']=st['r35']['geometry']['goat_ff']==310 and st['r35']['geometry']['goat_push_m']==1.5
   if typ=='MIRROR':
    test['full_fight_ended']=st['phase']=='COMPLETE_LAB_REAL_SOURCE_BESTAS' and st['winner'] in st['actors'] and min(actor['resource']['hp'] for actor in st['actors'].values())==0
    test['actions_for_both_sides']=set(e['detail']['actor'] for e in events if e['kind']=='R35_REAL_GOAT_NATIVE_ATTACK')==set(st['actors'])
    test['geometry_and_movement']=sum(e['detail'].get('forced_push') is not None for e in events)==st['r35']['pushes'] and sum(e['detail'].get('movement') is not None for e in events)==st['r35']['movement_actions']
   else:
    test['probe_not_full_fight']=receipt['full_fight_credit'] is False and meta['attacks']==1 and meta['phase'].startswith('COMPLETE_ISOLATED_')
   result.append({'scene':base,'checks':test,'passed':sum(test.values()),'total':len(test),'all_pass':all(test.values()),'head':h,'ledger_sha256':m.sha_file(db)});total+=len(test)
 if not all(x['all_pass'] for x in result):raise AssertionError('R35 audit failed:'+str([x for x in result if not x['all_pass']]))
 return {'status':'PASS_READ_ONLY_ALL_COMPLETE_SCENES','scenes':len(result),'checks':total,'pass_count':total,'details':result}

def geo_regressions():
 st=json.loads((R/'evidence'/'R35_MIRROR_SEED367_GENESIS.json').read_text())['state'];a,b=m.ids('MIRROR');examples=[]
 def new():return copy.deepcopy(st)
 for label,effect in [('miss',{'hit':False,'net':50}),('net_zero',{'hit':True,'net':0})]:
  x=new();before=copy.deepcopy(m.positions(x));r=m.push_if_hit(x,a,b,effect);assert r is None and m.positions(x)==before and x['r35']['pushes']==0;examples.append({'case':label,'pass':True,'push':None})
 for label,edits in [('blocked_terrain',lambda x:x['r35']['geometry'].update(terrain='SCENE_HAS_UNRECONCILED_OBSTACLE')),('blocked_arena_edge',lambda x:x['r35']['geometry'].update(bounds=[-1.0,2.0]))]:
  x=new();edits(x);before=copy.deepcopy(m.positions(x));
  try:m.push_if_hit(x,a,b,{'hit':True,'net':9});raise AssertionError('expected strict hold '+label)
  except m.Hold as e:assert m.positions(x)==before and x['r35']['pushes']==0;examples.append({'case':label,'pass':True,'blocked_by':str(e)})
 x=new();x['r35']['geometry']['goat_ff']=299
 try:m.push_if_hit(x,a,b,{'hit':True,'net':10});raise AssertionError('required FF change hold')
 except m.Hold as e:examples.append({'case':'tampered_ff_does_not_grant_1_5m','pass':True,'error':str(e)})
 x=new();target_pos=m.positions(x)[b][:];r=m.push_if_hit(x,a,b,{'hit':True,'net':11});assert r['meters']==1.5 and r['to']==[3.0,0.0] and not r['adjacent_after']
 x['active']=b;movement=m.move_to_adjacent(x,b);assert movement and movement['distance_m']==1.5 and m.dist(x)==1.5 and x['actors'][b]['resource']['movement']==0;examples.append({'case':'push_broke_adjacency_and_next_movement_restored','pass':True,'pushed_to':r['to'],'move_to':movement['to']})
 # Every above executed only on in-memory detached genesis, not durable scenes.
 return {'status':'PASS_DETACHED_GEOMETRY_GUARDS','regressions':examples,'tests':len(examples),'persistent_events_created':0}

def reaction_contract():
 # Official Combat System §DEFENDER/ESQUIVAR; species printed sheets omit Armor/Fortitude/Reflexo.
 st=json.loads((R/'evidence'/'R35_MIRROR_SEED367_GENESIS.json').read_text())['state'];aa=st['actors']['LAB_R35_GOAT_A']['resource'];bb=st['actors']['LAB_R35_GOAT_B']['resource']
 mandatory={'DEFENDER':('armor','fortitude'),'ESQUIVAR':('reflex',)}
 out=[]
 for method,fields in mandatory.items():
  missing=[f for f in fields if bb.get(f) is None]
  assert missing
  out.append({'reaction':method,'combat_formula':'6+CON+Armadura+Fortitude' if method=='DEFENDER' else 'CA+Reflexo','source':'3ebc2b32-4ede-81f1-be4b-e8804ac113c0','source_data_missing':missing,'qualification':'BLOCKED_SOURCE_REAL_REACTION_PRE_GATE','target_hp':bb['hp'],'reaction_slot':bb['reaction'],'reason':'No evidence that the missing ability/stat modifier equals zero; can neither execute native reaction nor debit a slot'})
 assert all(x['reaction_slot']==1 for x in out)
 # Compute symbolic thresholds, NOT chosen values.
 return {'status':'REQUIRES_AUTHORIZED_SOURCE_SNAPSHOT_FOR_NATIVE_REACTION','options':out,'threshold_analysis':{'goat_base_attack_scores':[20,21,22,23,24,25],'goat_CA':20,'DEFENDER_against_own_kind':{'formula':'16 + X, where X=Armadura+Fortitude, not sourced','first_hitting_attack_total':21,'X_min_to_negate_first_hit':5},'ESQUIVAR_against_own_kind':{'formula':'20 + Reflexo, Reflexo not sourced','first_hitting_attack_total':21,'Reflexo_min_to_negate_first_hit':1}},'new_native_reaction_events':0}

def exact_math():
 # Independent idealized infinite-horizon IID repeated-attempt oracle of mirror, NOT claim of native statistical behavior.
 p_pos=1/108;p_neg=1/108;p_normal=1-p_pos-p_neg;hit=5/6
 pmf={0:p_neg+(1-p_neg)*(1-hit)}
 for d in range(1,7):
  pmf[8+d]=p_normal*hit/6
  pmf[14+d]=p_pos*hit/6
 assert abs(sum(pmf.values())-1)<1e-12
 active={38:1.0};finishes=[]
 for turn in range(1,121):
  next_active=collections.defaultdict(float);ended=0.0
  for hp,prob in active.items():
   for damage,p in pmf.items():
    if damage>=hp:ended+=prob*p
    else:next_active[hp-damage]+=prob*p
  finishes.append(ended);active=dict(next_active)
  if sum(active.values())<1e-13:break
 mass=sum(finishes);tie=sum(x*x for x in finishes);first=(1+tie)/2
 return {'schema':'R35_EXACT_BASELINE_MIRROR_IID_ORACLE_NONCAN','damage_pmf':{str(k):v for k,v in sorted(pmf.items())},'per_attempt_hit_chance_strict':hit,'ordinary_damage_if_hit':'1d6 + FOR13 - RD5 = 1d6+8','net_per_hit_no_critical':11.5,'expected_net_per_attempt_with_crit_lab_policy':sum(k*v for k,v in pmf.items()),'time_to_KO_tail_remaining':1-mass,'time_to_KO_mean_attempts':sum((i+1)*v for i,v in enumerate(finishes)),'tied_action_counts_probability':tie,'first_to_act_win_probability_IID_symmetric':first,'assumptions':['Each own attack independent identically distributed; five of six normal accuracy dice hit CA20','Negative crit overrides hit: 1/108; positive adds 1d6 maximum to damage if hit:1/108','No Reactions, no barriers, enough Movement to reapproach after each 1.5m push','Same attack and RD on both sides and no outside intervention'], 'not_natively_estimated_winrate':True}

def observed():
 scenes=[]
 for seed in D:
  rec=json.loads((R/'evidence'/f'R35_MIRROR_SEED{seed}_RECEIPT.json').read_text());z=rec['after'];init=rec['events'][0]['detail']['initiative_R26']['order'];atk=[e['detail'] for e in rec['events'] if e['kind'].endswith('ATTACK')];vict=z['winner']
  scenes.append({'seed':seed,'winner':vict,'first_actor':init[0],'first_actor_won':vict==init[0],'attacks':z['attacks'],'hits':z['hits'],'pushes':z['pushes'],'movement_actions':z['movement_actions'],'critical_positive':sum(a['roll']['crit_kind']=='POSITIVE' for a in atk),'critical_negative':sum(a['roll']['crit_kind']=='NEGATIVE' for a in atk),'end_hp':z['hp'],'replay':rec['replay']['status']})
 pp=[]
 for seed in P:
  rec=json.loads((R/'evidence'/f'R35_PROBE_SEED{seed}_RECEIPT.json').read_text());rr=rec['events'][0]['detail'];pp.append({'seed':seed,'hit_die':rr['roll']['hit_die'],'total':rr['roll']['hit_total'],'target_ca':21,'hit':rr['native']['native_effect']['hit'],'net':rr['native']['native_effect']['net'],'pushed':rr['forced_push'] is not None})
 return {'mirror':{'n_complete':len(scenes),'n_independent_seeds':len(scenes),'first_actor_wins':sum(x['first_actor_won'] for x in scenes),'attacks_total':sum(x['attacks'] for x in scenes),'hits_total':sum(x['hits'] for x in scenes),'pushes_total':sum(x['pushes'] for x in scenes),'movement_actions_total':sum(x['movement_actions'] for x in scenes),'scenes':scenes},'galidemus_probe':{'n_trials':len(pp),'n_hits':sum(x['hit'] for x in pp),'n_pushes':sum(x['pushed'] for x in pp),'trials':pp,'per_attempt_hit_probability_no_negative_crit_ordinary':4/6},'historic_R34_not_added':True}

if __name__=='__main__':
 for name,fn in [('R35_INDEPENDENT_AUDIT.json',independent_checks),('R35_GEOMETRY_GUARD_REGRESSIONS.json',geo_regressions),('R35_REACTION_SOURCE_PREFLIGHT.json',reaction_contract),('R35_EXACT_SAME_RANK_DAMAGE_ORACLE.json',exact_math),('R35_SCIENCE_AGGREGATION.json',observed)]:
  x=fn();report(name,x);print(name, str(x.get('status','CALCULATED')),len(json.dumps(x)),json.dumps({k:v for k,v in x.items() if k in ('scenes','checks','pass_count','tests','new_native_reaction_events','time_to_KO_mean_attempts','first_to_act_win_probability_IID_symmetric')})[:230])
