# R35 — Guia de reprodução / MESTRE-ONLY

1. Conserve os pacotes R27 e R34 originais (SHA256 registrados) e abra este ZIP R35 em diretório limpo.
2. O R35 **não contém motor reimplementado**. Ele usa os módulos originais `fusion_stage12/vlab_r18_interactive.py`, `fusion_stage12/vlab_r26_master_rulings.py`, `working/historical_v09_documentary_rebuilt/comestre_vlab/vlab_effects_v08.py`, `vlab_action_catalog_v01.py`, `vlab_rd_v08.py` da R27, mais `extension/vlab_r31_real_source_gateway.py` e a decisão R34.
3. Para **auditar sem reexecutar luta**, use `python verify_r35_archive_standalone.py /caminho/para/R35.zip` (stdlib, não precisa extrair o motor). Reabre os 10 SQLite em modo somente-leitura, valida integridade e cadeia de hashes/manifesto.
4. Para reproduzir o **replay nativo independentemente**, extraia o R27 em `r27/` sob esta raiz e rode `python audit_and_science_r35.py` **somente numa cópia limpa dos dados**: atenção que o script cria arquivos de resultados com modo 'x' e recusa sobrescrever. Uma cópia de trabalho destinada a auditoria deve isolar `evidence/` de resultados novos ou usar apenas `verify_r35_archive_standalone.py`.
5. `run_r35_native.py` serve de executor **para novos IDs/novas sementes somente**. **NÃO o execute** contra os dez bancos terminais: o código os recusa. As sementes observadas 353/359/373/379/383 são sondas isoladas Cabra→Galidemus; 367/389/397/401/409 são duelos completos duas instâncias de Cabra.
6. Luta+6 da Investida é **específica**; aplica-se ao acerto `1d6+13+6`, não ao dano `1d6+13`. RD5, FF310 e empurrão1,5m são contratos efetivamente sustentados. A política inicial P6 recusa Reações voluntárias sem desativar o recurso. Nenhum efeito no jogo oficial.
7. Arquivos `*_GENESIS.json`, `*_RECEIPT.json`, `runs/*.sqlite` e `checkpoints/*BACKUP.sqlite` são materialmente preservados. Replays em `R35_INDEPENDENT_AUDIT.json`; ciência em `R35_EXACT_SAME_RANK_DAMAGE_ORACLE.json` e `R35_SCIENCE_AGGREGATION.json`.

Não confunda `sandbox real-fonte` com `combate canônico`, nem testes geométricos em clone com empurrões efetivamente ocorridos em luta.
