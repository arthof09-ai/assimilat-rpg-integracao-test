"""R243 independent source-anchored re-audit: 6 ZIPs, 352 SQLite, 834 offensive events.
Can verify the saved JSONL locally without origins, or crosscheck actual originals via --source-root.
No imports from original VLAB engine/extractor.
"""
from __future__ import annotations
import json,hashlib,collections,zipfile,sqlite3,tempfile,sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
STAGES=('R234','R235','R236','R237','R239','R240')
def req(ok,tag):
 if not ok:raise AssertionError(tag)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def normalize(stage,db,e):
 raw=int(e['raw']);nom=int(e['rd_applied']);eff=int(e.get('net',e.get('effective')))
 hp=int(e['hp_loss_actual'] if e['action']=='weapon_attack' else e['hp_before']-e['hp_after'])
 return {'stage':stage,'sqlite':db,'event_seq':e['seq'],'kind':e['action'],'raw':raw,'rd_applicable_nominal':nom,'rd_absorbed_actual':min(raw,nom),
  'rd_excess_nominal':max(0,nom-raw),'post_rd_effective':eff,'hp_loss_actual':hp,'overkill_or_nonhp':eff-hp,'provenance':e.get('provenance','')}
def local(rows,index):
 req(len(rows)==834,'EXPECTED_834');req(index['_summary']['source_db_count']==352 and index['_summary']['unique_action_records']==834,'SOURCE_DENOMINATOR')
 expected={'R234':120,'R235':196,'R236':59,'R237':155,'R239':48,'R240':256}
 bystage=collections.defaultdict(list);seen=set()
 for x in rows:
  req((x['stage'],x['sqlite'],x['event_seq']) not in seen,'DUPLICATE_OFFENSIVE_EVENT');seen.add((x['stage'],x['sqlite'],x['event_seq']))
  req(x['stage'] in STAGES and x['kind'] in ('weapon_attack','spell'),'EXPECTED_STAGE_KIND')
  raw,nom,absorb,eff,hp=x['raw'],x['rd_applicable_nominal'],x['rd_absorbed_actual'],x['post_rd_effective'],x['hp_loss_actual']
  req(all(type(v)==int and v>=0 for v in [raw,nom,absorb,eff,hp]),'BAD_RESOURCE')
  req(absorb==min(raw,nom) and eff==max(0,raw-nom),'RD_MECHANICS_RECONCILIATION')
  req(hp<=eff and x['overkill_or_nonhp']==eff-hp,'HP_OVERKILL_RECONCILIATION')
  req(x['rd_excess_nominal']==max(0,nom-raw),'RD_NOMINAL_EXCESS')
  bystage[x['stage']].append(x)
 req({z:len(bystage[z]) for z in STAGES}==expected,'STAGE_ACTION_COUNTS')
 totals={'offensive_events':len(rows),'physical_weapon_attacks':sum(x['kind']=='weapon_attack' for x in rows),'spells':sum(x['kind']=='spell' for x in rows),'gross_damage':sum(x['raw'] for x in rows),
  'rd_nominal_applicable_sum':sum(x['rd_applicable_nominal'] for x in rows),'rd_actual_absorbed_sum':sum(x['rd_absorbed_actual'] for x in rows),
  'excess_nominal_over_absorbed':sum(x['rd_excess_nominal'] for x in rows),'post_rd_effective_sum':sum(x['post_rd_effective'] for x in rows),
  'hp_actual_loss_sum':sum(x['hp_loss_actual'] for x in rows),'overkill_nonhp_sum':sum(x['overkill_or_nonhp'] for x in rows),
  'rd_excess_count':sum(x['rd_excess_nominal']>0 for x in rows)}
 req(totals=={'offensive_events':834,'physical_weapon_attacks':806,'spells':28,'gross_damage':61092,
 'rd_nominal_applicable_sum':37200,'rd_actual_absorbed_sum':37019,'excess_nominal_over_absorbed':181,
 'post_rd_effective_sum':24073,'hp_actual_loss_sum':23422,'overkill_nonhp_sum':651,'rd_excess_count':9},'SCIENCE_TOTAL_EXPECTATION')
 req(sum(x['rd_excess_nominal'] for x in bystage['R235'])==181,'R235_NOMINAL_EXCESS_ONLY')
 return {'totals':totals,'by_stage':{s:{'actions':len(bystage[s]),'rd_nominal':sum(x['rd_applicable_nominal'] for x in bystage[s]),
 'rd_absorbed':sum(x['rd_absorbed_actual'] for x in bystage[s]),'postRD':sum(x['post_rd_effective'] for x in bystage[s]),
 'actualHP':sum(x['hp_loss_actual'] for x in bystage[s])} for s in STAGES}}
def find_source(name):
 paths=[Path('/mnt/data/vlab_recovery')/name,Path('/mnt/data')/name]
 for p in paths:
  if p.exists():return p
 return None
def source_check(rows,index):
 regen=[];count=0
 for stage in STAGES:
  item=index[stage];zp=find_source(item['archive'])
  req(zp is not None and sha(zp)==item['zip_sha256'],'SOURCE_ARCHIVE_HASH_MISSING_OR_DRIFT_'+stage)
  with zipfile.ZipFile(zp) as z:
   req(z.testzip() is None,'SOURCE_ZIP_CRC_'+stage)
   dbs=sorted(n for n in z.namelist() if n.startswith('evidence/db/') and n.endswith('.sqlite'))
   req(len(dbs)==item['source_database_count'],'SOURCE_DB_COUNT_'+stage)
   for name in dbs:
    with tempfile.NamedTemporaryFile(suffix='.sqlite') as tmp:
     tmp.write(z.read(name));tmp.flush();c=sqlite3.connect(f'file:{tmp.name}?mode=ro&immutable=1',uri=True)
     try:
      req(c.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SOURCE_SQLITE_'+stage)
      st=json.loads(c.execute("SELECT value FROM meta WHERE key='state'").fetchone()[0])
      for ev in st['native_events']:
       if ev.get('action') in ('weapon_attack','spell'):regen.append(normalize(stage,Path(name).name,ev))
     finally:c.close()
    count+=1
 req(count==352,'SOURCE_ALL_352_SQLITE')
 key=lambda q:(q['stage'],q['sqlite'],q['event_seq'])
 req(sorted(regen,key=key)==sorted(rows,key=key),'SOURCE_TO_DERIVED_EXACT_MATCH')
 return count
if __name__=='__main__':
 index=json.loads((ROOT/'sources/R243_SOURCE_ZIP_INDEX.json').read_text())
 p=ROOT/'evidence/R243_COMBAT_RD_PROVENANCE.jsonl';rows=[json.loads(z) for z in p.read_text().splitlines() if z]
 raw=json.loads((ROOT/'reports/R243_RAW_EXTRACTION.json').read_text())
 req(raw['file_sha256']==sha(p),'DERIVED_EXTRACT_SHA')
 out=local(rows,index)
 n=source_check(rows,index)
 report={'gate':'PASS_R243_SOURCE_ANCHORED_INDEPENDENT_READONLY','source_ZIP_SHA_count':6,'source_sqlite_integrity':n,'SOURCE_CRC':'PASS',
         'exact_derived_event_match':True,'counts':out,'interpretation':'rd_applied field = nominal applicable RD, not amount really absorbed when raw<RD; measure min(raw,RD) separately; overkill not actual Vida removed',
         'official_cells':0,'certified_terminals':0,'canonical_writes':0}
 (ROOT/'reports/R243_CROSS_SOURCE_INDEPENDENT_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'gate':report['gate'],'source_sqlite_integrity':n,'totals':out['totals']},ensure_ascii=False,indent=2))
