"""R243 read-only derived RD accounting from sealed R234-237, R239-240 sources.
NOT an alternative damage resolver: only distinguish nominal applicable RD vs amount actually absorbed.
"""
from __future__ import annotations
import json,sqlite3,glob,hashlib,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PARENT=Path('/mnt/data')
FILES={
 'R234':(PARENT/'vlab_recovery/extracted/R234/evidence/db',PARENT/'vlab_recovery/VLAB_R234_VZ_BEAST_FULL_SOURCE_BILATERAL_TEAM_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip'),
 'R235':(PARENT/'vlab_recovery/extracted/R235/evidence/db',PARENT/'vlab_recovery/VLAB_R235_BEAST_MAGIC_PHYSICAL_RD_FACTORIAL_COLD_AUDITED_MESTRE_ONLY.zip'),
 'R236':(PARENT/'vlab_recovery/extracted/R236/evidence/db',PARENT/'vlab_recovery/VLAB_R236_VZ_BEAST_WEAK_HP0_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip'),
 'R237':(PARENT/'vlab_recovery/extracted/R237/evidence/db',PARENT/'vlab_recovery/VLAB_R237_LIVE_FRACO_TRANSITION_NATIVE_COLD_AUDITED_MESTRE_ONLY.zip'),
 'R239':(PARENT/'VLAB_R239_THRESHOLD_MESTRE_ONLY/evidence/db',PARENT/'VLAB_R239_THRESHOLD_MESTRE_ONLY.zip'),
 'R240':(PARENT/'VLAB_R240_FRACO_PAIRS_MESTRE_ONLY/evidence/db',PARENT/'VLAB_R240_FRACO_PAIRS_MESTRE_ONLY.zip'),
}

def filehash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 rows=[];idx={};seqset=set()
 for stage,(dbroot,zipf) in FILES.items():
  assert zipf.is_file() and dbroot.is_dir(),stage
  idx[stage]={'archive':zipf.name,'zip_sha256':filehash(zipf),'source_database_count':len(list(dbroot.glob('*.sqlite'))),'input_archived':True}
  for dbpath in sorted(dbroot.glob('*.sqlite')):
   c=sqlite3.connect(f'file:{dbpath}?mode=ro&immutable=1',uri=True)
   try:
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    state=json.loads(c.execute("SELECT value FROM meta WHERE key='state'").fetchone()[0]);ev=state['native_events']
    for e in ev:
     if e.get('action') not in ('weapon_attack','spell'):continue
     key=(stage,dbpath.name,e['seq']);assert key not in seqset;seqset.add(key)
     raw=int(e['raw']);nom=int(e['rd_applied']);eff=int(e.get('net',e.get('effective')))
     hp=int(e['hp_loss_actual'] if e['action']=='weapon_attack' else e['hp_before']-e['hp_after'])
     absorbed=min(raw,nom);assert eff==max(0,raw-nom) and 0<=hp<=eff
     rows.append({'stage':stage,'sqlite':dbpath.name,'event_seq':e['seq'],'kind':e['action'],'raw':raw,'rd_applicable_nominal':nom,
      'rd_absorbed_actual':absorbed,'rd_excess_nominal':max(0,nom-raw),'post_rd_effective':eff,'hp_loss_actual':hp,'overkill_or_nonhp':eff-hp,
      'provenance':e.get('provenance','')})
   finally:c.close()
 idx['_summary']={'stages':len(FILES),'unique_action_records':len(rows),'source_db_count':sum(v['source_database_count'] for k,v in idx.items() if not k.startswith('_'))}
 (ROOT/'sources/R243_SOURCE_ZIP_INDEX.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
 f=ROOT/'evidence/R243_COMBAT_RD_PROVENANCE.jsonl'
 f.write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in rows))
 out={'status':'R243_EXTRACTED_NEEDS_INDEPENDENT_AUDIT','count':len(rows),'file_sha256':filehash(f),
      'input_zip_count':6,'source_db_count':idx['_summary']['source_db_count'],'official_cells':0,'terminal_contracts':0}
 (ROOT/'reports/R243_RAW_EXTRACTION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':run()
