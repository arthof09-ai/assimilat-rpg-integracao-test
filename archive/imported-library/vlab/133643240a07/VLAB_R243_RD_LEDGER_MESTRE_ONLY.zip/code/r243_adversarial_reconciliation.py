"""Tamper clones of derived RD ledger and verify independent math + true source anchored rejection."""
import json,copy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
import r243_independent_source_audit as a
orig=[json.loads(line) for line in (ROOT/'evidence/R243_COMBAT_RD_PROVENANCE.jsonl').read_text().splitlines() if line]
idx=json.loads((ROOT/'sources/R243_SOURCE_ZIP_INDEX.json').read_text())
passed=[]
def probe(name,fn,expected_source_only=False):
 z=copy.deepcopy(orig);fn(z)
 try:
  a.local(z,idx)
  if expected_source_only:a.source_check(z,idx)
 except AssertionError as e:
  passed.append({'test':name,'rejected':True,'source_only':expected_source_only,'gate':str(e)})
  return
 raise AssertionError('TAMPER_NOT_DETECTED:'+name)
probe('nominal_RD_nonnegative',lambda z:z[0].__setitem__('rd_applicable_nominal',-1))
probe('gross_delta_mismatch',lambda z:z[0].__setitem__('raw',100000))
probe('post_RD_forgery',lambda z:z[0].__setitem__('post_rd_effective',999))
probe('actual_HP_larger_than_effective',lambda z:z[0].__setitem__('hp_loss_actual',999))
probe('duplicate_row',lambda z:z.__setitem__(1,copy.deepcopy(z[0])))
probe('undocumented_source_status_forgery',lambda z:z[0].__setitem__('provenance','OFFICIAL-P4'),expected_source_only=True)
# Rebalance a row internally to be mathematically admissible; only original ZIP prevents false provenance.
def pure_semantic_forgery(z):
 good=[i for i,x in enumerate(z) if x['stage']=='R235' and x['raw']>120 and x['rd_applicable_nominal']==75 and x['hp_loss_actual']==x['post_rd_effective']]
 i,j=good[:2];assert i!=j
 for k,delta in [(i,-1),(j,+1)]:
  x=z[k];x['rd_applicable_nominal']+=delta;x['rd_absorbed_actual']+=delta
  x['post_rd_effective']-=delta;x['hp_loss_actual']-=delta
  x['overkill_or_nonhp']=0
probe('fully_consistent_fake_RD_source_anchored',pure_semantic_forgery,expected_source_only=True)
probe('wrong_source_sequence',lambda z:z[0].__setitem__('event_seq',z[0]['event_seq']+999),expected_source_only=True)
assert len(passed)==8
out={'gate':'PASS_R243_8_OF_8_DERIVED_LEDGER_ATTACKS_REJECTED','source_only_attacks':sum(x['source_only'] for x in passed),'details':passed,'original_archives_modified':False}
(ROOT/'reports/R243_ADVERSARIAL_GATES.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
