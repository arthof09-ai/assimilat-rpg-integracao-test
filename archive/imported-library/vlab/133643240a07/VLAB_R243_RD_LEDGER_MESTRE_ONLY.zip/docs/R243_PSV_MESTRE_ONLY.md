PSV — R243 / RD nominal vs RD realmente absorvida / MESTRE-ONLY / READ-ONLY.

**ANTES:** R242 mostrou que o adapter VLAB marca `rd_applied` como RD NOMINAL aplicável, não como dano efetivamente bloqueado. Ex.: bruto220, `rd_applied=1000`, dano efetivo0, absorção real220. Nenhuma regra é alterada: isto é interpretação de campos já existentes, verificada lendo o módulo nativo `vlab_rd_v08.mitigate` (DamageOutcome.applicable_rd).

**FONTE/ESCOPO:** R234, R235, R236, R237 existentes na Biblioteca da OP, além de R239/R240 novos. Seis ZIPs originais com hash SHA256 materializados e lidos novamente; 352 bancos SQLite integridade PASS. Lidos 834 eventos ofensivos (806 ataques físicos, 28 magias), 0 duplicações de chave arquivo/seq. Nenhum registro alterado. JSONL derivado guarda ID do ZIP, arquivo SQLite, seq, dano bruto, RD nominal, RD absorvida, pós-RD e Vida efetiva. 6 fontes distintas não significam seis estudos independentes; ataques, braços e seeds são denominadores diferentes.

**RESULTADOS AUDITADOS INDEPENDENTEMENTE:**
- Bruto 61.092; soma nominal de RD aplicável 37.200; absorção real 37.019; diferença de NOMINAL−ABSORVIDA 181 em 9 eventos (todos magias R235 RD75 com bruto inferior a75).
- Dano pós-RD 24.073 = 61.092−37.019; perda de Vida efetiva 23.422; 651 de excesso não convertido em perda de Vida real por HP já limitado (640 R236, 11 R237).
- Somar bruto−RD nominal globalmente daria 23.892, ERRADO por 181 para este conjunto. A prevenção REAL por evento é `min(raw,rd_applied)`; `post_RD=max(0,raw-rd_applied)`; `hp_loss=min(post_RD, Vida restante)` quando não há outra mitigação. Nunca confundir RD, pós-RD, overkill, cura e Vida efetivamente removida.
- Conferidos hashes dos 6 ZIPs, CRC, 352 SQLite e igualdade exata dos 834 eventos derivados com os ZIPs-fonte, usando auditor independente de extração.

**ESTADO:** verificação científica local/source-anchored PASS. Não reclassifica R234–R237, não certifica fórmulas gerais, não promove P4, não lança dados DMG sem pacote de coordenação; 0/17 contratos terminais; 0/1875 células oficiais. Quaisquer estatísticas publicadas por DMG que somem `rd_applied` como redução consumida exigem triagem, mas NÃO se afirma que o DMG fez tal erro sem inspecionar a metodologia dele. Notion canônico, DMG, Party, O Primeiro NO-WRITE; writer continua HOLD.

**PRÓXIMA PENDÊNCIA:** encaminhar achado por rota/Inbox competente para DMG após claim administrativo; inspecionar documentação DMG para possível confusão de colunas; continuar fonte P4/17 contratos. Não interromper por checkpoint se houver trabalho seguro.
