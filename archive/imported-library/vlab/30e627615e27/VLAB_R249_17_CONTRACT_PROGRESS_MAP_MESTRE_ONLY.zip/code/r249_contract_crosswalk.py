#!/usr/bin/env python3
"""R249 read-only contract continuity crosswalk; all 17 terminal gates remain HOLD."""
import ast,hashlib,json,collections
from pathlib import Path
R=Path('/mnt/data/VLAB_R249_17_CONTRACT_PROGRESS_MAP_MESTRE_ONLY')
P=Path('/mnt/data/VLAB_R239_THRESHOLD_MESTRE_ONLY/runtime/fusion_stage12')
def assignment(path,name):
 tree=ast.parse(path.read_text())
 for n in tree.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets):
   return ast.literal_eval(n.value)
 raise ValueError('MISSING_SOURCE_SYMBOL_'+name)
A=P/'a3_r03_contract_coverage.py';B=P/'a3_contract_gate_harness.py'
expected=assignment(A,'EXPECTED');deps=assignment(B,'MISSING_GATES')
assert len(expected)==17 and set(expected)==set(deps)
# Evidence from R244–R248 is narrower than terminal certification, even when a technical local test passes.
evidence={
 'GENERAL_SPECIFIC_RD':(['R244'],'READONLY_REAL_LEDGER_RD_NOMINAL_VS_ABSORBED_RECONCILIATION'),
 'RNG_REPLAY_STATISTICS':(['R247','R248'],'128_PAIRED_SEED_CLUSTER_REANALYSIS_AND_EXACT_6D6_MATHONLY'),
 'TURN_SCHEDULER_EVENT_SOURCING':(['R245','R246'],'SOURCE_GAP_INITIATIVE_TIE_AND_HP0_STOP_AUDIT'),
 'BATTLE_1X1_2X1_20X20':(['R246'],'READONLY_20_SCENE_HP0_CENSORING_NO_NEW_20X20'),
 'SOURCE_FREEZE_AND_RANK':(['R248'],'FROZEN_VZ_SPEC_HASH_REUSED_NOT_P4'),
 'ED_VS_BE_DAMAGE':(['R244'],'RD_MECHANICS_AUDIT_ONLY_NO_NEW_ED_X_BE_FULL_FIGHT'),
 'AUTHORITATIVE_RULES_AND_ADAPTERS':(['R244','R245','R246'],'CROSS_SOURCE_GAP_QUALIFICATION_ONLY')
}
rows=[]
for contract in expected:
 ev,scope=evidence.get(contract,([], 'NO_NEW_POST_R243_EVIDENCE'))
 rows.append({'contract_id':contract,'expected':expected[contract],'terminal_status':'HOLD_0_CREDIT','explicit_original_missing_gate':deps[contract],'new_evidence_stages':ev,'evidence_scope':scope,'official_promotion':False,'provenanced_registry':'Stage12 R03 A3', 'P4_proven':False})
assert all(r['terminal_status']=='HOLD_0_CREDIT' and r['official_promotion'] is False for r in rows)
results={'stage':'R249','operation':'OP-VLAB-FUSION-SANDBOX-01','matrix_rows':17,'matrix_sha256':hashlib.sha256(A.read_bytes()).hexdigest(),'gate_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'bounded_source_evidence_covered_contracts':sum(bool(r['new_evidence_stages']) for r in rows),'terminal_certified_count':0,'official_cells':0,'P4_missing':True,'writer_verified':False,'next_priorities':['NORM-004 initiative tie source','NORM-005 critical negative consequences','GEO-006 grid and diagonal conversion','HP-017 official HP0 resolution','B/D/E original source P4 and source-complete fixture','Independent terminal certification'],'policy':'NO-THEORETICAL_CREDIT_TO_OFFICIAL_MATRIX','status':'PASS_READONLY_TRACEABILITY_ONLY'}
(R/'reports/R249_MATRIX_17.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(R/'reports/R249_SUMMARY.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
