# C30 — Pacote de segunda codificação realmente independente (MESTRE-ONLY)

Status: PREPARADO, **NÃO EXECUTADO**. Revisor humano independente: NÃO DESIGNADO. Nenhum ACK presumido. A classificação anterior deve ser ocultada ao revisor antes de iniciar.

## Fonte de amostra e fronteira

12 fontes candidatas de inscrição oficial para F6, todas com URL/ID em `C30_F6_ADMISSIBILIDADE_12_TEST.csv`. Este arquivo com os rótulos *não* deve ser entregue ao avaliador cego. Amostra é dirigida, não aleatória representativa. Se usar IA como segundo leitor, identificar explicitamente como IA, não como humano.

## Formulário em branco para o revisor

Em cada fonte: Page-ID, URL, versão/data da leitura, tipo físico (regra/ficha/receita/espelho), condição canônica, texto literal ofensivo, dano numérico explícito? (SIM/NÃO/INDETERMINADO), RE independente? fonte/evidência, FIP independente? fonte/evidência, rank de item separado do RE, ação, custo PA, alvo/área e forma, duração/ticks, condições, defesa/save, natureza/tags, classificação FINAL [ADMISSÍVEL/INADMISSÍVEL/PENDENTE], motivo textual, grau de confiança, páginas relacionadas, imagens não verificadas.

## Blindagem e aceitação

Separar autora da coleta inicial e revisor, selar amostra antes da atribuição, não apresentar conclusões C29/C30 nem rankings de consenso. Codificar individualmente as 12 fontes, conciliar apenas após ambas as planilhas e timestamps fechados. Reportar percent agreement e Cohen kappa para categorias quando as marginais forem adequadas, mais confusão/padrão de erros; n=12 é pequeno, sem alegar validade estatística ampla. Discrepâncias mecânicas resolvidas com autoridade notional competente/Mestre, não por votação simples. Divergência sem autoridade = HOLD. Exigir assinatura/atribuição real do revisor e readback verificado; não enviar para Party.

## Separação de A7

Oito reservas históricas têm exposição de metadados/descrições documentada; não usá-las como validação cega até auditoria independente. Novo holdout, se necessário, escolhido por família e versão sem consulta aos efeitos antes do seal; preservar seed e denominador, não alterar Plano Supremo.
