#!/usr/bin/env python3
"""Self-contained zip integrity verifier; no network, no writes."""
import sys,zipfile,json,hashlib

def d(b):return hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None,'ZIP CRC failure'
    m=json.loads(z.read('FILE_MANIFEST_R288.json'))
    names={x.filename for x in z.infolist() if not x.is_dir()}
    assert names == set(m['files'])|{'FILE_MANIFEST_R288.json'},'ZIP member set mismatch'
    for k,sha in m['files'].items():assert d(z.read(k))==sha,f'SHA mismatch {k}'
    assert json.loads(z.read('evidence/R288_COLD_40_TESTS.json'))['status']=='PASS_TEST_ONLY'
    assert json.loads(z.read('evidence/R286_SEEDED_HTTP_REPORT.json'))['distribution']=={'HEAL_PASS':64}
    assert json.loads(z.read('evidence/R287_END_TO_END_HTTP_ROUNDTRIP.json'))['paired_cases']==8
    print(json.dumps({'status':'PASS_R288_ZIP_SHA_CRC','members':len(names),'cold_tests':40,'separate_stress':64,'separate_recovery_pairs':8,'terminal_contracts':0}))
