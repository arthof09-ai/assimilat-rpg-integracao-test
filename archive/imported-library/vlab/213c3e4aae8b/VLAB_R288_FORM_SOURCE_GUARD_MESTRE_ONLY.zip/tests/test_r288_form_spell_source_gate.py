"""R288 HTTP source-field safety: no silent conversion of a real spell to LAB self healing."""
import urllib.parse,urllib.request,urllib.error,sqlite3,unittest
from test_vlab_r19_web import R19WebTests
import vlab_r18_interactive as core

class FormSpellGate(unittest.TestCase):
    setUp=R19WebTests.setUp
    start_server=R19WebTests.start_server
    stop_server=R19WebTests.stop_server
    get=R19WebTests.get
    post=R19WebTests.post
    csrf=R19WebTests.csrf
    create=R19WebTests.create
    step=R19WebTests.step
    def setup_heal(self):
        n,_=self.create('A',seed=288000)
        self.assertEqual(self.step(n,'START')[0],200)
        self.assertEqual(self.step(n,'ATTACK')[0],200)
        return n
    def assert_clean_rejection(self,name,fields,needle):
        db=self.root/name;before=core.load(db)
        code,html,_=self.post('/act',fields)
        self.assertEqual(code,409)
        self.assertIn(needle,html)
        self.assertEqual(core.load(db),before)
        con=sqlite3.connect(db)
        try:self.assertEqual(con.execute('SELECT COUNT(*) FROM pending').fetchone()[0],0)
        finally:con.close()
    def fields(self,n,action='HEAL'):
        state,head,rev=core.load(self.root/n)
        return {'save':n,'rev':str(rev),'head':head,'action':action}
    def test_01_targeted_heal_denied(self):
        n=self.setup_heal();d=self.fields(n);d['target']='LAB_VIGIA_A'
        self.assert_clean_rejection(n,d,'LAB_HEAL_REJECTS_TARGETED_OR_REACTIVE_SPELL')
    def test_02_reactive_heal_denied(self):
        n=self.setup_heal();d=self.fields(n);d['reaction']='DEFENDER'
        self.assert_clean_rejection(n,d,'LAB_HEAL_REJECTS_TARGETED_OR_REACTIVE_SPELL')
    def test_03_real_spell_label_denied(self):
        n=self.setup_heal();d=self.fields(n);d['spell_id']='PULSO_DE_ESTABILIZACAO_45PA'
        self.assert_clean_rejection(n,d,'UNSUPPORTED_SPELL_FORM_FIELDS_REJECTED')
    def test_04_positive_pa_spoof_denied(self):
        n=self.setup_heal();d=self.fields(n);d['pa_cost']='45'
        self.assert_clean_rejection(n,d,'UNSUPPORTED_SPELL_FORM_FIELDS_REJECTED')
    def test_05_ability_name_spoof_denied_on_pass(self):
        n=self.setup_heal();d=self.fields(n,'PASS');d['ability']='M_Cura_Espiritual'
        self.assert_clean_rejection(n,d,'UNSUPPORTED_SPELL_FORM_FIELDS_REJECTED')
    def test_06_duplicate_action_key_denied(self):
        n=self.setup_heal();d=self.fields(n)
        before=core.load(self.root/n)
        # encode two distinct actions; malicious clients cannot rely on first-wins.
        pairs=list(d.items())+[('action','ATTACK'),('csrf',self.csrf())]
        body=urllib.parse.urlencode(pairs).encode()
        try:
            self.browser.open(urllib.request.Request(self.base+'/act',body,headers={'Content-Type':'application/x-www-form-urlencoded'}),timeout=15)
            self.fail('duplicate action accepted')
        except urllib.error.HTTPError as err:
            self.assertEqual(err.code,409)
            self.assertIn('DUPLICATE_FORM_FIELDS_REJECTED',err.read().decode())
        self.assertEqual(core.load(self.root/n),before)
    def test_07_valid_self_heal_still_supported(self):
        n=self.setup_heal();self.assertEqual(self.step(n,'HEAL')[0],200)
        self.assertEqual(core.history(self.root/n)['events'][-1]['kind'],'HEAL')
    def test_08_valid_attack_defender_still_supported(self):
        n,_=self.create('B',seed=288001)
        self.assertEqual(self.step(n,'START')[0],200)
        self.assertEqual(self.step(n,'ATTACK',reaction='DEFENDER')[0],200)
        self.assertEqual(core.history(self.root/n)['events'][-1]['kind'],'ATTACK')

if __name__=='__main__':unittest.main()
