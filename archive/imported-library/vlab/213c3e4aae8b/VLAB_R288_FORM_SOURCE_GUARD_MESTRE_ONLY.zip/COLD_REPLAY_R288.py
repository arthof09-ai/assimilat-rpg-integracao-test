#!/usr/bin/env python3
"""Rebuild R19+R269+R283+R284+R285+R288 and run historical + new HTTP tests."""
from __future__ import annotations
import argparse,hashlib,os,json,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
PARENT_SHA='927e7fbee7fa25bac2bd4f84254552c9a7b2bf697c700cad10cab3170fdecfe9'
PREV_SHA='9189f69e3311c078cfdcc66b0b45b0b04c59ae6dea6deb706b652c906ec365d0'
CORE_HASH='cc0527522e09f0a8b732adaf962f5ca3e018441b804cd9bf5fe32bcba0becc3d'
WEB_HASH='97ba521ba29b29fc85e3f022effb4520a143d13bd3d473a43f4c7db63ac020a1'
PATCH_SHA='1077225631332b37b6d783cdd4693acf6c4c68b4a8803358c08521bfaf51dee0'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def call(args,cwd,env=None,timeout=100):
 p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
 if p.returncode:raise RuntimeError(repr(args)+' FAIL\n'+p.stdout[-4000:])
 return p.stdout.strip()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--r19',type=Path,required=True);parser.add_argument('--previous-bundle',type=Path,required=True);parser.add_argument('--output',type=Path,default=None);parser.add_argument('--deep',action='store_true');a=parser.parse_args()
 if sha(a.r19)!=PARENT_SHA:raise RuntimeError('R19 source SHA invalid')
 if sha(a.previous_bundle)!=PREV_SHA:raise RuntimeError('R284–R287 prior artifact SHA invalid')
 if sha(HERE/'patch/R288_R19_REAL_SPELL_FORM_DENY.patch')!=PATCH_SHA:raise RuntimeError('R288 patch SHA invalid')
 with tempfile.TemporaryDirectory(prefix='VLAB_R288_COLD_') as scratch:
  root=Path(scratch)/'r19';root.mkdir()
  with zipfile.ZipFile(a.r19) as source:
   assert source.testzip() is None and len(source.namelist())==2223
   source.extractall(root)
  native=root/'fusion_stage12'
  with zipfile.ZipFile(a.previous_bundle) as previous:
   assert previous.testzip() is None
   manifest=json.loads(previous.read('FILE_MANIFEST_R284_R287.json'))
   for name,digest in manifest['files'].items():
    if hashlib.sha256(previous.read(name)).hexdigest()!=digest:raise RuntimeError('prior manifest SHA fail '+name)
   for name in ['R269_CUMULATIVE_R18_TO_R269.patch','R274_R283_INCREMENTAL_R269_TO_NEW.patch','R284_R19_HEAL_WEB.patch','R285_R19_SOURCE_GATE_WEB.patch']:
    f=Path(scratch)/name;f.write_bytes(previous.read('patch/'+name));call(['patch','-p1','--batch','--forward','-i',str(f)],root)
   (native/'audit_r274_heal_independent.py').write_bytes(previous.read('code/audit_r274_heal_independent.py'))
   for name in ('test_r284_web_heal.py','test_r285_source_gated_web.py'):
    (native/name).write_bytes(previous.read('tests/'+name))
   deep_tests={name:previous.read('tests/'+name) for name in ('stress_r286_http_web.py','prove_r287_backup_roundtrip_web.py')}
  call(['patch','-p1','--batch','--forward','-i',str(HERE/'patch/R288_R19_REAL_SPELL_FORM_DENY.patch')],root)
  (native/'test_r288_form_spell_source_gate.py').write_bytes((HERE/'tests/test_r288_form_spell_source_gate.py').read_bytes())
  if sha(native/'vlab_r18_interactive.py')!=CORE_HASH or sha(native/'vlab_r19_web.py')!=WEB_HASH:raise RuntimeError('final source SHA mismatch')
  tests=[]
  for testcase,count in [('test_vlab_r18_interactive test_vlab_r19_web',16),('test_r284_web_heal.WebHeal',8),('test_r285_source_gated_web.TestR285',8),('test_r288_form_spell_source_gate.FormSpellGate',8)]:
   logs=call([sys.executable,'-m','unittest','-q',*testcase.split()],native)
   if f'Ran {count} tests' not in logs:raise RuntimeError('unexpected test count')
   tests.append({'testcase':testcase,'pass':count,'log':logs[-120:]})
  evidence={'schema':'R288_SOURCE_FIELD_GATE_COLD','status':'PASS_TEST_ONLY','R19_source_sha256':PARENT_SHA,'R284_parent_sha256':PREV_SHA,'R288_patch_sha256':PATCH_SHA,'core_sha256':CORE_HASH,'web_sha256':WEB_HASH,'suite':tests,'official_credits':0,'terminal_certifications':0}
  if a.deep:
   target=Path(scratch)/'evidence';target.mkdir()
   env=os.environ.copy();env['PYTHONPATH']=str(native);env['VLAB_EVIDENCE_DIR']=str(target)
   for name in deep_tests:
    f=Path(scratch)/name;f.write_bytes(deep_tests[name]);call([sys.executable,str(f)],native,env=env,timeout=120)
   x=json.loads((target/'R286_SEEDED_HTTP_REPORT.json').read_text())
   y=json.loads((target/'R287_END_TO_END_HTTP_ROUNDTRIP.json').read_text())
   if x['distribution']!={'HEAL_PASS':64} or y['paired_cases']!=8:raise RuntimeError('deep stress failure')
   evidence['deep']={'R286':x['distribution'],'healed_hp':x['recorded_heal_hp'],'R287_pairs':y['paired_cases'],'R287_events':y['http_event_count_each_pair']}
  else:evidence['deep']='NOT_RUN'
  if a.output:
   a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(evidence,indent=2,ensure_ascii=False)+'\n')
  print(json.dumps(evidence,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
