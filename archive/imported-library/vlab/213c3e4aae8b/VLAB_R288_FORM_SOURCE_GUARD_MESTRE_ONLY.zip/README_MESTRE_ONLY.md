# PSV — R288 | Fail-closed do formulário de magia do VLAB web R19 (MESTRE-ONLY TEST)

**Continuidade:** `LAST-VERIFIED R287 → R288`, sem abrir nova operação ou segundo motor. R19 web como controlador do R18, resolvedores originais v0.6/v0.7/v0.8.1 preservados. Fonte pai R19 `927e7fbee7fa25bac2bd4f84254552c9a7b2bf697c700cad10cab3170fdecfe9`; pacote delta R284–R287 pai SHA `9189f69e3311c078cfdcc66b0b45b0b04c59ae6dea6deb706b652c906ec365d0`.

## Problema físico reproduzido

A rota web `/act` aceitava metadados desconhecidos e a ação HEAL sintética ignorava `target` e `reaction`. Isso permitia que uma tentativa de comando com `spell_id=Pulso...` ou `pa_cost=45` fosse executada como cura laboratorial `1d6/0PA`, sem advertir que não era a magia de campanha; campos duplicados usavam apenas o primeiro valor. Mesmo sem alterar os custos canônicos, podia induzir interpretação enganosa da prova.

## Correção localizada R288

- Apenas o controlador existente `fusion_stage12/vlab_r19_web.py` foi alterado em **cópia TEST**.
- HEAL rejeita alvo externo e pedido de reação em vez de substituir silenciosamente por autocura fictícia.
- POST `/act` recusa campos de magia/custo/rank não suportados e parâmetros duplicados antes de chamar o resolvedor ou gravar intenção durável.
- Mantém validação de CSRF, ataque com defesa DEFENDER, cura LAB legítima, histórico, backup, restauração e verificação independente R285.
- Não transforma o Pulso de Estabilização do NPC proposto (Reação / 45PA / 3d10+10 / aliado a 3m) em cura autônoma sem custo; a fonte da campanha permanece read-only, não implementada.

## Evidência e readback

- ZIP histórico R19 + delta R284–R287 + patch `R288_R19_REAL_SPELL_FORM_DENY.patch` reproduzidos em **extração limpa**, manifestos e SHA de código auditados por `COLD_REPLAY_R288.py` sem distribuição concorrente.
- `evidence/R288_COLD_40_TESTS.json`: **16/16 regressões originais**, **8/8 R284**, **8/8 R285**, **8/8 R288** PASS. Novo web SHA `97ba521ba29b29fc85e3f022effb4520a143d13bd3d473a43f4c7db63ac020a1`; módulo core SHA `cc0527522e09f0a8b732adaf962f5ca3e018441b804cd9bf5fe32bcba0becc3d` preservado.
- Bateria extensa da mesma árvore TEST com esses SHAs: `evidence/R286_SEEDED_HTTP_REPORT.json` 64/64 HEAL, 249 Vida fictícia; `evidence/R287_END_TO_END_HTTP_ROUNDTRIP.json` 8/8 pares, 16 bancos, 146 eventos. **A execução unificada --deep do instalador frio teve timeout sem prova final de conclusão; portanto estes ensaios extensos são atestados separadamente sobre árvore cujo SHA coincide com o resultado da instalação fria**, não alegados como --deep cold PASS.
- Novo pacote é só delta R288 (~KB), não inclui cópia do motor nem dos patches anteriores; não exige GitHub ou gasto. Verificador portátil confere ZIP CRC e hashes de seus membros.

## Como reproduzir

Na biblioteca Mestre, obter o ZIP original `VLAB_STAGE12_A1A2A3_WEB_R19_SANDBOX.zip`, o delta anterior `VLAB_R284_R287_WEB_HEAL_RECOVERY_MESTRE_ONLY.zip` e este novo ZIP. Em ambiente isolado Python 3.10+ com ferramenta POSIX `patch`:

`python COLD_REPLAY_R288.py --r19 /caminho/R19_original.zip --previous-bundle /caminho/VLAB_R284_R287_WEB_HEAL_RECOVERY_MESTRE_ONLY.zip --output /tmp/R288_replay.json`

`--deep` tenta refazer também 64 seeds e 8 pares, que exigem tempo maior. R19 web é apenas localhost Python, NÃO site hospedado nem aplicativo Android.

## Governança

Sem INSTANCE-ID/lease/epoch/fencing/GREEN, nenhum Notion/Inbox/Diário/Party/O Primeiro/DMG/LEVEL-UP editado. **0/17 contratos terminais**, **0/1.875 células oficiais R91**, `NAC-PASS` global HOLD. Dados e números exclusivamente de TEST; 0 efeitos canônicos escritos.

**Ponto exato**: `LAST-VERIFIED R288 → FIRST-PENDING CANDIDATE R289`, após inspeção de colisões na Biblioteca. Prioridade futura: admissibilidade de custos positivos e ação real sob fonte completa, ou interface de combate multiator/scheduler, sem simular custos de magia que ainda não estão implementados.
