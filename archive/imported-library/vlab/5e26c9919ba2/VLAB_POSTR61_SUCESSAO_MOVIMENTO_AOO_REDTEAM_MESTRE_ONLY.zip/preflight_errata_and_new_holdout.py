"""V1 rejection coverage fix and newly preregistered independent second holdout."""
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
import movement_integration as m
out=root/'runs'
# Pre-register new seeds BEFORE new outcome calculations.
pr={'revision':'V2_AFTER_V1_PRECHECK_BRANCH_ERROR','seeds':[['DUAL_EXIT',140201],['EXIT_AND_ATTACK',140202],['KO_INTERRUPT',140203]],
    'accept':'geometry/source-gated rejections reached while V is active, no published event or state mutation',
    'old_6_runs':'preserved; cold audit checks them; old preflight CHECKS are invalid branch coverage; new proof appended'}
(root/'ERRATA_PREFLIGHT_PREREG.json').write_text(m.canonical(pr)+'\n')
all_results=json.loads((root/'RESULTS.json').read_text())
errata=[]
for r in all_results:
    path=out/f'POSTR61_{r["case"]}_{r["seed"]}.sqlite'
    rechecked=m.preflight_regressions(path,r['case'])
    errata.append({'seed':r['seed'],'case':r['case'],'checks':rechecked,'invalid_v1_checks':'NOT_ACTOR_TURN branch was not the claimed safe/forced/overspeed proof'})
new=[]
for case,seed in pr['seeds']:
    r=m.run_case(seed,case,out);r['cohort']='holdout_v2';r['preflight_checks']=m.preflight_regressions(out/f'POSTR61_{case}_{seed}.sqlite',case)
    new.append(r)
(root/'ERRATA_PREFLIGHT_RESULTS.json').write_text(m.canonical(errata)+'\n')
(root/'HOLDOUT_V2_RESULTS.json').write_text(m.canonical(new)+'\n')
print(json.dumps({'historical_runs_rechecked':len(errata),'new_holdout':len(new),'events':sum(x['events'] for x in new),'aoo':sum(x['aoo'] for x in new),'old_checked':errata,'new_results':new},ensure_ascii=False,indent=2))
