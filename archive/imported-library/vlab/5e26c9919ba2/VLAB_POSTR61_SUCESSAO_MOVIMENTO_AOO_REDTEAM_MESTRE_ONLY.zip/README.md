# VLAB — DELTA PÓS-R61 | MESTRE-ONLY / NO-CANON

Este ZIP é **continuação experimental isolada** da operação CM-000006 / OP-VLAB-FUSION-SANDBOX-01. **NÃO** contém nem substitui o ZIP histórico R52–R61. Original SHA256 `04fd493f4e75c04093ad24278f84b2ae8e9b4880d27b40ba89ceb0914d5eda62` em Biblioteca `/Comestre/OP-VLAB-FUSION-SANDBOX-01/`.

## Auditoria independente sem motor original
Após extrair ZIP, execute `python cold_movement_audit.py`. Exige apenas stdlib Python. Ele verifica 9 ledgers, 59 eventos, 12 AoO, RNG R18 recomputado e 9 checkpoints. Examine `REDTEAM_RESULTS.json` e `ERRATA_PREFLIGHT_RESULTS.json` para controles adversariais e errata.

## Reexecutar desenvolvimento / novos seeds
1. Recuperar e validar original ZIP R52–R61 (80 membros/79 manifestados).
2. Recuperar ZIP R26 da Biblioteca `/Comestre/OP-VLAB-FUSION-SANDBOX-01/VLAB_STAGE12_A1A2A3_MASTER_RULINGS_R26_SANDBOX.zip` (17.541.213 bytes) e seus códigos R18/R26; verificação dos módulos originais no checkpoint R61: R18 SHA `f1336caa0255ab2c6d9e20f2f3f87edf682e97fe6d04c1e2373518d5ae74d368`, R26 SHA `f56e97a8a2e6f30024fcddb4f80a2c70e50f0eadb6c59d5244a193dafef283fd`.
3. Na mesma pasta pai que contém `post_r61_delta`, preparar `r61_extracted/work` e `r61_extracted/work/fusion_stage12` dos ZIPs autênticos, preservando originais. `movement_integration.py` importa desse caminho autenticado. Não retente seeds já publicadas, scripts `__main__` escritos para primeira execução recusam arquivos existentes.
4. Todo novo ensaio deve usar seeds/nomes próprios e prereg antes do resultado. O pacote não executa nada automaticamente.

**Cautelas:** não restaurar a R59 pending, não reproduzir os testes V1 como cobertura de forced/safe, não incluir as 18 cópias adulteradas como casos válidos, não usar 1.5m fixture como regra normativa. Não há writer/ACK/NAC-PASS terminal.

Leia `PSV_POSTR61_SUCESSAO_E_CONTINUIDADE.md`, `POSTR61_MATRIX_17.md`, `EXECUTION_SUMMARY.json` e `SHA256_MANIFEST.json` para iniciar sucessão.
