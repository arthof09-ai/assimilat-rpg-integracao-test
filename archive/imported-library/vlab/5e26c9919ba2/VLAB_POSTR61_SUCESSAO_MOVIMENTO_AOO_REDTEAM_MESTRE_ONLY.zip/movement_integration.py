"""POST-R61 incremental, TEST-ONLY movement scheduler extension for original VLAB.

Depends on SHA-matched R18/R26 imported from R26 historical package and original
R52--R61 code. Never reads/writes live Notion, originals, or historical ledger.
This is a proposed fixture-scoped integration, not an official speed/AoO ruling.
"""
from __future__ import annotations
import copy, hashlib, json, math, sqlite3, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'r61_extracted'
sys.path.insert(0,str(BASE/'work'))
import r52_r61_engine as old
core=old.core
r26=old.r26

class PreflightDeny(ValueError): pass

FIXTURE_STEP_METERS=1.5  # synthetic event geometry only; NOT game movement speed
CASE_LAYOUTS={
 'DUAL_EXIT':{'F':(0.,1.5),'R':(-1.5,0.),'V':(0.,0.),'dest':(1.5,0.)},
 'EXIT_AND_ATTACK':{'F':(0.,1.5),'R':(3.,0.),'V':(0.,0.),'dest':(1.5,0.)},
 'KO_INTERRUPT':{'F':(0.,1.5),'R':(-1.5,0.),'V':(0.,0.),'dest':(1.5,0.)},
}

def canonical(x): return core.canonical(x)
def sha(x): return hashlib.sha256(canonical(x).encode()).hexdigest()

def preflight(st,case,actor='V',to=None,mode='VOLUNTARY'):
    if st['phase']!='ACTIVE' or st['active']!=actor:raise PreflightDeny('NOT_ACTOR_TURN')
    r=st['actors'][actor]['resource']
    if r['hp']<=0 or r['movement']!=1:raise PreflightDeny('DEAD_OR_MOVEMENT_SPENT')
    if mode!='VOLUNTARY':raise PreflightDeny('SOURCE_GATE_FORCED_OR_SAFE_MOVE_NOT_PROVEN')
    if to is None:to=CASE_LAYOUTS[case]['dest']
    origin=r['position']
    if any(type(x) not in (float,int) for x in to):raise PreflightDeny('UNTRUSTED_COORDINATES')
    if not 0<math.dist(origin,to)<=FIXTURE_STEP_METERS+1e-8:raise PreflightDeny('FIXTURE_STEP_EXCEEDED')
    if any(math.dist(other['resource']['position'],to)<1e-8 for aid,other in st['actors'].items() if aid!=actor and other['resource']['hp']>0):raise PreflightDeny('OCCUPIED_DESTINATION')
    # Geometric exit-only test: no claim that all movements in RPG cause AoO.
    guards=[]
    for aid,o in st['actors'].items():
        if aid==actor or o['resource']['hp']<=0 or o['resource']['reaction']!=1:continue
        src=old.SOURCES[o['source']]
        if src.get('aoo_normal_attack_admitted') is False:continue
        if math.dist(o['resource']['position'],origin)<=1.500001 and math.dist(o['resource']['position'],to)>1.500001:
            guards.append(aid)
    # Historic decision: DES priority, rank dice only when DES ties; no need for a reroll here.
    guards.sort(key=lambda a:-old.SOURCES[st['actors'][a]['source']]['des'])
    return {'actor':actor,'from':list(origin),'to':list(to),'guards':guards,'case':case,'mode':mode,'fixture_step_m':FIXTURE_STEP_METERS}

def preflight_attack(st,a,b):
    if st['active']!=a or st['phase']!='ACTIVE':raise PreflightDeny('NOT_ACTIVE_ATTACKER')
    if st['actors'][a]['resource']['standard']!=1:raise PreflightDeny('STANDARD_SPENT')
    if math.dist(st['actors'][a]['resource']['position'],st['actors'][b]['resource']['position'])>1.500001:raise PreflightDeny('NOT_ADJACENT')
    if st['actors'][a]['resource']['hp']<=0 or st['actors'][b]['resource']['hp']<=0:raise PreflightDeny('KO')
    return True

def create(db,seed,case):
    if db.exists():raise FileExistsError('NO-REPEAT: refuse existing fixture')
    layout=CASE_LAYOUTS[case]
    st=old.snapshot('FIGHT',{'F':'F','V':'V','R':'R'},seed,f'POST-R61-{case}')
    st['lab_type']='POST_R61_MOVEMENT_EXPERIMENT'
    st['policy']['movement_fixture_m']=FIXTURE_STEP_METERS
    st['policy']['movement_scope']='GEOMETRY_FIXTURE_NOT_CANONICAL_SPEED'
    st['policy']['safe_forced_move']='SOURCE_GATE_HOLD'
    for a in ('F','R','V'):st['actors'][a]['resource']['position']=list(layout[a])
    if case=='KO_INTERRUPT':
        st['actors']['V']['resource']['hp']=1
        st['actors']['V']['resource']['ca']=1 # explicitly altered replica, not real V
        st['policy']['altered_replica']='V hp1 ca1 for deterministic KO branch'
    core.init_db(db,'A',seed)
    genesis=sha({'scene':st['scene'],'R18':core.VERSION,'purpose':'POST-R61-MOVEMENT-NEW-DELTA'})
    con=core.connect(db)
    try:
        con.execute('BEGIN IMMEDIATE')
        for k,v in [('scene',st['scene']),('state',canonical(st)),('head',genesis),('genesis',genesis)]:
            con.execute('UPDATE meta SET value=? WHERE key=?',(v,k))
        con.commit()
    except:con.rollback();raise
    finally:con.close()
    (db.parent/(db.stem+'.genesis.json')).write_text(canonical(st)+'\n')
    return st

def commit(db,name,payload,fn):
    st,head,n=core.load(db)
    cmd='LAB-CMD-POSTR61-'+sha({'scene':st['scene'],'prev':head,'name':name,'p':payload})[:25]
    return core.event_commit(db,cmd,name,payload,fn)

def _advance_if_not_v(st,p,seq):
    if st['phase']!='ACTIVE' or st['active']=='V':raise PreflightDeny('ONLY_PRE_V_YIELD')
    before=st['active'];re=old.advance(st)
    return {'phase':'PRE_MOVE_SCHEDULER_YIELD_FIXTURE','from':before,'to':st['active'],'transition':re,'official_action_claim':False}

def _declare_move(st,p,seq):
    pf=preflight(st,p['case'],to=p['to'])
    st['movement_request']={'case':p['case'],'mover':'V','from':pf['from'],'to':pf['to'],'pending_guards':pf['guards'][:],'movement_applied':False,'fixture_scope':True}
    st['phase']='MOVEMENT_WINDOW'
    return {'stage':'DECLARE_MOVE','preflight':pf,'guard_order':pf['guards'],'position_unchanged':True}

def _resolve_aoo(st,p,seq):
    if st['phase']!='MOVEMENT_WINDOW':raise PreflightDeny('NO_OPEN_WINDOW')
    req=st['movement_request']
    if not req['pending_guards'] or req['pending_guards'][0]!=p['guard']:raise PreflightDeny('WRONG_PRIORITY_OR_EMPTY')
    guard=p['guard'];m=req['mover']; old_position=st['actors'][m]['resource']['position'][:]
    if st['actors'][m]['resource']['hp']<=0:raise PreflightDeny('DEAD_MOVER')
    fx=old.attack(st,guard,m,'AOO',adv=1)
    req['pending_guards'].pop(0)
    if st['actors'][m]['resource']['hp']<=0:
        req['pending_guards']=[];st['phase']='MOVEMENT_CANCELLED_KO'
    assert st['actors'][m]['resource']['position']==old_position
    return {'stage':'REACTION_ATTACK_BEFORE_MOVEMENT','attacker':guard,'attack':fx,'mover_position':old_position,'remaining_guards':req['pending_guards'][:],'state':st['phase']}

def _apply_move(st,p,seq):
    if st['phase']!='MOVEMENT_WINDOW' or st['movement_request']['pending_guards']:raise PreflightDeny('UNFINISHED_WINDOW')
    req=st['movement_request'];actor=req['mover'];res=st['actors'][actor]['resource']
    if res['hp']<=0 or res['movement']!=1:raise PreflightDeny('DEAD_OR_SPENT')
    oldpos=res['position'][:]
    if oldpos!=req['from']:raise PreflightDeny('POSITION_STALE')
    res['position']=req['to'][:];res['movement']=0;req['movement_applied']=True;st['phase']='ACTIVE'
    return {'stage':'FINALIZE_MOVEMENT','from':oldpos,'to':res['position'][:],'movement_after':res['movement'],'official_speed_claim':False}

def _attack_after_move(st,p,seq):
    preflight_attack(st,'V','R')
    fx=old.attack(st,'V','R','NORMAL')
    return {'stage':'NORMAL_ATTACK_AFTER_MOVE','attack':fx,'position':st['actors']['V']['resource']['position'][:],'source':st['actors']['V']['source']}

def _advance_after(st,p,seq):
    if st['phase'] not in ('ACTIVE','MOVEMENT_CANCELLED_KO'):raise PreflightDeny('UNRESOLVED_MOVE')
    old_active=st['active']
    st['phase']='ACTIVE'
    change=old.advance(st)
    return {'stage':'TURN_END','actor':old_active,'transition':change,'mover_hp':st['actors']['V']['resource']['hp']}

def run_case(seed,case,out):
    path=out/f'POSTR61_{case}_{seed}.sqlite'
    create(path,seed,case)
    timeline=[]
    timeline.append(commit(path,'INIT',{'action':'INIT'},old.begin))
    # Multi-actor scheduler: actual initiative before mover, no fabricated priority order.
    for _ in range(3):
        st,_,_=core.load(path)
        if st['active']=='V':break
        timeline.append(commit(path,'FIXTURE_YIELD',{'actor':st['active']},_advance_if_not_v))
    st,_,_=core.load(path)
    assert st['active']=='V','V must appear in three-actor initiative order'
    pf=preflight(st,case)
    # A second declaration cannot run while pending and publication of each step is atomic.
    timeline.append(commit(path,'DECLARE_MOVE',{'case':case,'to':pf['to']},_declare_move))
    for guard in pf['guards']:
        st,_,_=core.load(path)
        if st['phase']=='MOVEMENT_CANCELLED_KO':break
        timeline.append(commit(path,'AOO',{'guard':guard},_resolve_aoo))
    st,_,_=core.load(path)
    if st['phase']=='MOVEMENT_WINDOW':
        timeline.append(commit(path,'APPLY_MOVE',{'actor':'V'},_apply_move))
        if case=='EXIT_AND_ATTACK':
            st,_,_=core.load(path);preflight_attack(st,'V','R')
            timeline.append(commit(path,'NORMAL_AFTER_MOVE',{'actor':'V','target':'R'},_attack_after_move))
    else:assert st['phase']=='MOVEMENT_CANCELLED_KO'
    timeline.append(commit(path,'ADVANCE',{'actor':'V'},_advance_after))
    st,head,rev=core.load(path)
    cp=out/(path.stem+'.checkpoint.sqlite')
    # Source-independent physical SQLite backup and reopen.
    conn=sqlite3.connect(path);dst=sqlite3.connect(cp)
    try:conn.backup(dst)
    finally:conn.close();dst.close()
    assert core.load(cp)==core.load(path)
    return {'case':case,'seed':seed,'events':rev,'head':head,'initiative':st['order'],'round':st['round'],
            'winner':st['winner'],'phase':st['phase'],'mover_hp':st['actors']['V']['resource']['hp'],
            'mover_position':st['actors']['V']['resource']['position'],'aoo':st['count']['aoos'],
            'normal_after_movement':case=='EXIT_AND_ATTACK',
            'movement_completed':st['movement_request']['movement_applied'],
            'event_kinds':[r['kind'] for r in timeline],'checkpoint':cp.name}

def preflight_regressions(db,case):
    st,h,n=core.load(db)
    # Isolated pre-publication state; do not mistake a completed turn for
    # a genuine forced/safe-move rejection. The failed V1 harness did this.
    genesis=json.loads((db.parent/(db.stem+'.genesis.json')).read_text())
    genesis['phase']='ACTIVE';genesis['active']='V'
    before=sha(genesis)
    statuses=[]
    for test,p in [('FORCED',{'mode':'FORCED'}),('SAFE',{'mode':'SAFE'}),('OVERSPEED',{'to':(3.1,3.1)})]:
        try:preflight(genesis,case,**p);raise AssertionError('unsafe accepted '+test)
        except PreflightDeny as e:statuses.append({'case':test,'denied':str(e)})
    assert before==sha(genesis) and core.load(db)[2]==n
    # Immutable real event ID duplicate command guard - reuse last completed ID.
    c=sqlite3.connect(db);cmd=c.execute('SELECT cmd_id FROM events ORDER BY seq DESC LIMIT 1').fetchone()[0];c.close()
    try:core.event_commit(db,cmd,'DUPLICATE',{},lambda *_:None);raise AssertionError('duplicate accepted')
    except core.LabHold as e:statuses.append({'case':'DUPLICATE','denied':str(e)})
    assert core.load(db)[2]==n
    return statuses

if __name__=='__main__':
    out=ROOT/'runs';out.mkdir(exist_ok=True)
    prereg={'dev':[['DUAL_EXIT',140001],['EXIT_AND_ATTACK',140002],['KO_INTERRUPT',140003]],
      'holdout':[['DUAL_EXIT',140101],['EXIT_AND_ATTACK',140102],['KO_INTERRUPT',140103]],
      'policy':'fixed before dev; no seed selection; 1.5m fixture step, no official speed claim',
      'success':'event chain and recovery valid, guards consumed once; if KO stops move; no original writes',
      'outcomes_not_claimed':'real battle victory rates, official speed, universal forced/safe AoO semantics'}
    (ROOT/'PREREGISTRATION.json').write_text(canonical(prereg)+'\n')
    results=[]
    for cohort in ('dev','holdout'):
        for case,seed in prereg[cohort]:
            res=run_case(seed,case,out);res['cohort']=cohort
            # Preflight rejection tests run after published ledger, without effects.
            res['preflight_checks']=preflight_regressions(out/f'POSTR61_{case}_{seed}.sqlite',case)
            results.append(res)
    (ROOT/'RESULTS.json').write_text(canonical(results)+'\n')
    print(json.dumps({'runs':len(results),'events':sum(x['events'] for x in results),
       'aoo':sum(x['aoo'] for x in results),'cohorts':{'dev':3,'holdout':3},
       'results':results},ensure_ascii=False,indent=2))
