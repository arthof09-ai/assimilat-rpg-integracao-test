# PSV — VLAB SUCESSÃO PÓS-R61 / DELTA TÉCNICO EM SANDBOX

**AS-OF:** 2026-10-16 | **OPERATION:** CM-000006 / OP-VLAB-FUSION-SANDBOX-01 | **SIDE:** MESTRE-ONLY  
**BASELINE:** R01–R51 preservados, R52–R61 original verificado, fonte R18/R26 autêntica importada em cópia isolada  
**AUTHORITY/WRITER STATE:** CM-000006 lógico, INSTANCE-ID I0001 NÃO CONSUMIDA, writer/epoch/lease/fencing/GREEN NÃO VERIFICADOS, OP/Diário Notion HOLD. Autorização de réplicas DIR-MESTRE-LABS-REPLICAS-20261016-001. 
**LAST-VERIFIED-UNIT:** delta pós-R61 9 cenários auditados independentemente, incluindo integração movimento + ataques AoO + ataque normal depois do deslocamento; 18 adulterações reencadeadas detectadas semanticamente.  
**FIRST-PENDING:** autoria/fencing de ENGINEERING-DOCS para persistência em OP/Diário; funcionalmente, caminhar até um combate completo multirrodada com movimento e fonte oficial de deslocamento/safe/forced, sem inferir norma.

## Fonte física e NO-REPEAT
Original `VLAB_R52_R61_DEZ_ETAPAS_INTEGRACAO_MESTRE_ONLY.zip`, SHA-256 `04fd493f4e75c04093ad24278f84b2ae8e9b4880d27b40ba89ceb0914d5eda62`, 328169 bytes, 80 entradas, 79 hashes manifestados e CRC íntegros. Auditor frio em extração limpa: 17 cenas, 264 eventos, 336 ataques, 87 Contra-atacar, 6 AoO, 8 combates completos, zero censurados. São números **EXCLUSIVOS do delta histórico**, não computados de novo nos testes atuais. Documento de sucessão e matriz R60 existentes preservados. R53B/R54B/R56B/R58B não reexecutados como pesquisa. R59 `LAB-CMD-R59-FAULT-FIRST-ONE` seed 130011: pending1/publicados0/HP e reação inalterados; UNKNOWN_EFFECT/HOLD, NÃO RETENTAR.

## Dez etapas: execução real / pendências
1. **Recuperação R61 — PASS local:** cinco arquivos recuperados da Biblioteca, hashes e manifesto do ZIP, R18/R26 pinados, auditor frio original reexecutado. Nenhum certificado terminal.
2. **Persistência Notion — HOLD documental específico:** OP permanece terminando em R51; autoridade da identidade mostra PAUSED, IBX-39/56 bloqueios; serviço compartilhado/ACL/fencing/STOP-ACK não evidenciados. Não simular writer, não usar outra página para declarar OP concluída. Desenvolvimento em cópia isolada.
3. **R50/R51 — PRESERVADO, cobertura incremental ainda pendente:** módulos e seeds R53B/R54B preservados; 0 nova regressão nativa de Counter neste delta. Não extrapolar guard R51 para todos os paths sem nova prova.
4. **Scheduler com movimento — NOVO PASS LAB LIMITADO:** 9 janelas em turnos reais dos 3 atores; prioridade e estado motor histórico integrados via R18/R26; 6 movimentos publicados e 3 cancelados por KO, checkpoints e causação auditados. Ainda não combate completo multirrodada com movimento.
5. **AoO — NOVO PASS LAB LIMITADO:** 12 AoO de saída de alcance em 9 cenas, 3 casos com dois guards, consumindo slots; preferência DES existente preservada. R56B histórico de empate não duplicado. Movimento safe/forced/novos turnos completos ainda source-gated e não são considerados aceitos.
6. **Dano, defesa e recursos — NOVO PARCIAL:** 15 invocações de ataque do adaptador histórico (12 AoO + 3 normais após mover), rolagens independentes recomputadas, RD/dano/HP conciliados; sem PA positivo, resistência específica, magia, sangramento/cura oficiais ou cargas.
7. **Formato de combate — NOVO TRABALHO DE CENA, NÃO combate completo:** 9 cenários de 3 atores e dois formatos (janela de dupla reação e janela de um guard + ataque posterior); zero novas batalhas completas, 1×1/2×1/20×20 ainda ausentes. Zero censura de combate no delta novo.
8. **Red team — DEFITO IDENTIFICADO, CONTROLE DE DETECÇÃO TESTADO:** 18 cópias adulteradas e reencadeadas. Validador de cadeia estrutural aceitou as 18 (não detecta semântica manipulada); oráculo frio separado rejeitou as 18. Falha de auditoria V1: verificações safe/forced/overspeed colidiam no gate prévio NOT_ACTOR_TURN, sem alcançar regra pretendida. V2 repetiu preflight apenas em cópias do genesis ativo, atingiu gates corretos, nenhuma escrita de evento. R59 intocado.
9. **Holdout e matriz — PASS parcial:** sementes 140101–140103 e 140201–140203 pré-registradas antes do respectivo ensaio; 6/6 cenas validadas, no total 9/9 incluindo desenvolvimento. Contratos originais 17/17 mapeados, 0 certificados terminais, 0 células oficiais. Amostra não permite probabilidade universal de vitória.
10. **Persistência/sucessão — pacote local íntegro + Biblioteca quando readback disponível:** novo delta versionado com manifesto de cada arquivo, script de auditor frio, ledgers, preimagens, checkpoints, errata e relatório. OP e Diário protegidos permanecem HOLD; writer e NAC-PASS terminal não inferidos.

## Diferenciação dos denominadores
| Unidade | Histórico R52–R61 | NOVO pós-R61 | Relação/limite |
|---|---:|---:|---|
| Cenas válidas | 17 | 9 | deltas diferentes, não universo global |
| Eventos SQLite | 264 | 59 | logs de cena, não efeito de campanha |
| Ataques | 336 | 15 | 12 AoO + 3 normais no novo delta |
| Contra-atacar | 87 | 0 | R50/R51 não retestado integralmente |
| Ataques de oportunidade | 6 | 12 | 18 ao somar dois deltas conhecidos, sem deduplicar histórico global |
| Combates completos | 8 | 0 | sem simular 20×20 |
| Combates censurados | 0 | 0 | ausência de confronto terminal novo |
| Red team | 24 mutações rejeitadas no histórico | 18 rejeições **semânticas**, 18 aceitações **estruturais** | NÃO converter em 42 aprovações equivalentes |
| Contratos originais | 17 mapeados, 0 terminais | os MESMOS 17 mapeados, 0 terminais | não há 34 contratos |
| Células oficiais | 0/1875 | +0 | nenhuma promoção |

## Questões científicas e defeitos
- As cenas isoladas mostram que um ator pode disparar duas AoO antes de concluir um movimento legal **apenas no fixture**; o segundo guard não causa reação duplicada do primeiro. Quando a primeira AoO mata o alvo V, `APPLY_MOVE` não é publicado, posição inicial preservada. O ator sobrevivente pode aplicar ataque normal depois de deslocar-se com consumo de Padrão uma vez, sob origem `NORMAL`.
- Adversarial: adulterar `hit=false` com dano e coordenada teleportada, recalcular hashes de toda cadeia é aceito pelo verificador estritamente estrutural. **Hash íntegro não prova causalidade verdadeira**. Oráculo frio verificou rolagens, trajetória e HP/RD e rejeitou 18/18. Ainda requer integrar a validação semântica ao gate de aceitação oficial.
- Errata V1 preservada, V2 não modifica resultados de combate antigos e só corrige cobertura de testes negativos. FALHA original registrada, não silenciada.
- O fixture usa passo de 1,5m como deslocamento da cena, NÃO como regra canônica de velocidade. Política de afastamento seguro, deslocamento forçado, prioridades simultâneas e parâmetros de resistência necessitam evidência normativa e adaptação; caso contrário DENY.

## Inbox / governança
Foram fisicamente consultadas as 12 linhas atualmente endereçadas a `CM-000006` na Inbox única: IBX-40,41,42,43,45,46,62,70,86,90,95,99. Todas apresentaram Estado=NOVA, Lida por INSTANCE-ID vazio, ACK ausente. Leitura nesta sucessão NÃO é ACK legitimado. IBX-39 e IBX-56 seguem bloqueios administrativos distintos. IBX-90 Jaku×Dragão permanece vedada por decisões normativas/fonte; nenhuma execução dessa cena. Escrever logs somente nos destinos operacionais quando houver writer; não contaminar páginas de história/Party. NAC-CONT-03: recuperação e ANTES/DEPOIS locais; gate de writer Notion NÃO satisfeito. NAC-NORM-01: nenhuma norma alterada. NAC-PASS terminal: HOLD.

## Artefatos e classificação
RECUPERADOS autenticados: ZIP original R52–R61 + ordem integral + PSV + recibo + R60, binários R18/R26 do R26 ZIP. NOVOS: `movement_integration.py`, 9 SQLite e 9 backups, 9 genesis, pré-registros/holdout, auditor frio, 18 mutações segregadas, matriz de 17, errata V1/V2, pacote novo com SHA manifesto. NÃO DISPONÍVEIS como homologação: certificado terminal, writer/fencing, circuito Notion, speed/safe/forced oficiais e validação independente institucional.

**NO-REPEAT:** nenhuma reexecução de combate histórico como dado novo; R59 congelada; R56/R58 protótipos rejeitados não importados. **CONFLICTS:** velocidade de deslocamento/fonte e custo positivo/efeitos de duração não resolvidos por inferência. **UNKNOWN_EFFECT:** R59 pending inalterada. **Persistência operacional Notion:** HOLD; **Biblioteca:** consultar recibo/readback específico da nova entrega; nenhum registro em OP passou a constar por implicação.

## NEXT-5 e ponto exato de retomada
1. Conferir ZIP delta+manifesto SHA e executar `cold_movement_audit.py` em extração limpa (sem chamar motor de origem); testar 9 arquivos SQLite e checkpoints.
2. Recuperar da Biblioteca o R26 ZIP original e o R61 ZIP original; conferir SHA pin, recompor `work/fusion_stage12/`, executar novos **casos** sem tocar históricos.
3. Integrar movimento na agenda realmente multi-turno (não apenas uma janela) com comandos causais, reação renovada e derrota, usando só campos de fonte admissíveis.
4. Integrar semântica de preflight/oráculo independente ao gate de publicação, recusar adulteração reencadeada; congelar novos holdouts antes de rodar.
5. Com prova material externa de gateway+ACL/fencing e instância legitimada, reconciliar R61 + este delta na OP/Diário original, readback e ACK legítimos sem duplicação; atualizar 17 contratos sem auto-homologação.

**LAST-VERIFIED-UNIT:** POST-R61 / independent cold audit 9/9; **FIRST-PENDING FUNCIONAL:** multi-turno com movimento e fontes autorizadas; **FIRST-PENDING ADMIN:** exclusivo INSTANCE-ALLOC e writer ENGINEERING-DOCS comprovados. **NAC-PASS:** HOLD terminal; PASS somente para integridade local do delta se manifesto/readback final confirmado.
