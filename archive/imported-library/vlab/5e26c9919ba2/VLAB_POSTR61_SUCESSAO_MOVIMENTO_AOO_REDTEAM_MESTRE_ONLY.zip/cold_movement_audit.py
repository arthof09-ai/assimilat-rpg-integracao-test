"""Independent stdlib cold audit of post-R61 new scene ledgers.
No import of experiment runner, R18/R26, or historical R52 engine.
"""
import hashlib,json,sqlite3,math,random,sys,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parent
R18VER='VLAB-R18-INTERACTIVE-CLI-0.1-EXPERIMENTAL'
DES={'F':80,'R':23,'V':27}
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def dice(seed,seq,label,n,faces):
  ent=hashlib.sha256(f'{seed}|{seq}|{label}|{n}d{faces}|{R18VER}'.encode()).digest()
  rng=random.Random(int.from_bytes(ent,'big'))
  return [rng.randint(1,faces) for _ in range(n)]
def audit(path,strict=True):
  p=Path(path);db=sqlite3.connect(p)
  try:
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    meta=dict(db.execute('SELECT key,value FROM meta'));rows=db.execute('SELECT seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha FROM events ORDER BY seq').fetchall()
    assert db.execute('SELECT count(*) FROM pending').fetchone()[0]==0
  finally:db.close()
  assert int(meta['revision'])==len(rows)
  genesis=json.loads((p.parent/(p.stem+'.genesis.json')).read_text());state=json.loads(meta['state'])
  assert genesis['scene']==meta['scene']==state['scene']
  assert state['seed']==genesis['seed'] and state['policy']['movement_fixture_m']==1.5
  assert state['synthetic'] is True and state['claims']['official']==0
  assert set(state['actors'])=={'F','R','V'}
  head=meta['genesis'];prev_state=sha(genesis)
  kinds=[];aoo=[];init=None;declare=None;attack_after=None;moved=False
  for idx,cmd_id,prev,row_json,row_sha,before_sha,after_sha in rows:
    r=json.loads(row_json);kind=r['kind'];kinds.append(kind)
    assert r['seq']==idx and idx==len(kinds) and r['cmd_id']==cmd_id
    assert r['prev']==prev==head and sha(r)==row_sha and r['before_sha']==before_sha==prev_state
    assert r['after_sha']==after_sha and r['official_effects']==0 and r['synthetic'] is True
    detail=r['detail'];head=row_sha;prev_state=after_sha
    if kind=='INIT':
      assert idx==1;init=detail
      for entry in detail['initial']:
        assert entry['dice']==dice(state['seed'],entry['seq'],entry['label'],entry['n'],entry['faces'])
    elif kind=='DECLARE_MOVE':
      assert declare is None;declare=detail['preflight']; assert declare['actor']=='V'
      assert declare['mode']=='VOLUNTARY' and declare['fixture_step_m']==1.5
      assert declare['from']==genesis['actors']['V']['resource']['position']
      assert 0<math.dist(declare['from'],declare['to'])<=1.500001
      expected=[]
      for a in ('F','R'):
        pos=genesis['actors'][a]['resource']['position']
        if math.dist(pos,declare['from'])<=1.500001 and math.dist(pos,declare['to'])>1.500001:expected.append(a)
      assert declare['guards']==detail['guard_order']==sorted(expected,key=lambda a:-DES[a])
    elif kind=='AOO':
      assert declare is not None and not moved
      a=detail['attacker'];fx=detail['attack'];assert a==fx['actor'] and fx['target']=='V' and fx['origin']=='AOO'
      assert a in declare['guards'] and a not in aoo
      assert len(aoo)<len(declare['guards']) and a==declare['guards'][len(aoo)]
      assert detail['mover_position']==declare['from']
      assert fx['reaction_after']==0 and fx['standard_after']==1
      for t in fx['tape']:assert t['dice']==dice(state['seed'],t['seq'],t['label'],t['n'],t['faces'])
      if fx['hit']:
        assert fx['hp_before']-fx['hp_after']==min(fx['hp_before'],fx['damage_net'])
        assert fx['damage_net']==max(0,fx['damage_raw']-fx['rd'])
      else: assert fx['hp_before']==fx['hp_after'] and fx['damage_net']==0
      aoo.append(a)
    elif kind=='APPLY_MOVE':
      assert declare is not None and not moved
      assert aoo==declare['guards']
      assert detail['from']==declare['from'] and detail['to']==declare['to']
      assert detail['movement_after']==0 and detail['official_speed_claim'] is False
      moved=True
    elif kind=='NORMAL_AFTER_MOVE':
      assert moved;fx=detail['attack'];assert fx['actor']=='V' and fx['target']=='R' and fx['origin']=='NORMAL'
      assert detail['position']==declare['to']
      assert math.dist(detail['position'],genesis['actors']['R']['resource']['position'])<=1.500001
      assert fx['standard_after']==0
      for t in fx['tape']:assert t['dice']==dice(state['seed'],t['seq'],t['label'],t['n'],t['faces'])
      attack_after=detail
    elif kind in ('FIXTURE_YIELD','ADVANCE'):
      if kind=='FIXTURE_YIELD':assert detail['official_action_claim'] is False
    else:raise AssertionError('UNKNOWN_EVENT_KIND:'+kind)
  assert declare is not None and init is not None
  assert kinds[-1]=='ADVANCE' and state['count']['aoos']==len(aoo)
  assert (state['movement_request']['movement_applied'] is True)==moved
  if moved:
    assert state['actors']['V']['resource']['position']==declare['to']
    assert state['actors']['V']['resource']['hp']>0
  else:
    assert state['actors']['V']['resource']['hp']==0
    assert state['actors']['V']['resource']['position']==declare['from']
  assert prev_state==sha(state) and head==meta['head']
  if strict:
    cp=p.with_name(p.stem+'.checkpoint.sqlite');c=sqlite3.connect(cp)
    try:
      cmeta=dict(c.execute('SELECT key,value FROM meta'));assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
      assert c.execute('SELECT count(*) FROM events').fetchone()[0]==len(rows)
    finally:c.close()
    assert cmeta==meta
  return {'case':state['scene'].split('POST-R61-')[1].rsplit('-',1)[0], 'seed':state['seed'],'events':len(rows),
          'aoo':len(aoo),'normal_after_move':bool(attack_after),'moved':moved,'rng_tapes':'RECOMPUTED',
          'chain':'PASS','geometry':'PASS','checkpoint':'PASS' if strict else 'NOT_TESTED'}

if __name__=='__main__':
  files=sorted((ROOT/'runs').glob('POSTR61_*.sqlite'))
  # exclude checkpoints, which include .checkpoint.sqlite suffix
  files=[p for p in files if '.checkpoint.' not in p.name]
  results=[audit(f) for f in files]
  (ROOT/'COLD_AUDIT_RESULTS.json').write_text(canon(results)+'\n')
  print(json.dumps({'scenes':len(results),'events':sum(x['events'] for x in results), 'aoo':sum(x['aoo'] for x in results),'attacks_after_move':sum(x['normal_after_move'] for x in results),'moving_completed':sum(x['moved'] for x in results),'audited':results},ensure_ascii=False,indent=2))
