"""Rehash/rechain adversarial copies, proving semantic cold check beyond checksum."""
import json,sqlite3,hashlib,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import cold_movement_audit as cold
sys.path.insert(0,str(ROOT.parent/'r61_extracted'/'work'))
import r52_r61_engine as old
core=old.core
out=ROOT/'redteam';out.mkdir(exist_ok=True)

def mutate(src,variant):
    dst=out/(src.stem+'.'+variant+'.sqlite')
    if dst.exists():raise FileExistsError('REDTEAM_COPY_NO_RETRY')
    shutil.copy2(src,dst)
    shutil.copy2(src.parent/(src.stem+'.genesis.json'),out/(dst.stem+'.genesis.json'))
    c=sqlite3.connect(dst)
    try:
        meta=dict(c.execute('SELECT * FROM meta'));rows=c.execute('SELECT seq,row_json FROM events ORDER BY seq').fetchall()
        prev=meta['genesis'];changed=False
        for seq,content in rows:
            r=json.loads(content)
            if r['kind']=='AOO' and not changed:
                if variant=='FALSE_MISS':r['detail']['attack']['hit']=False
                elif variant=='TELEPORT':r['detail']['mover_position']=[999.,999.]
                else:raise AssertionError('unknown variant')
                changed=True
            r['prev']=prev
            row_sha=cold.sha(r)
            c.execute('UPDATE events SET prev=?,row_json=?,row_sha=? WHERE seq=?',(prev,cold.canon(r),row_sha,seq))
            prev=row_sha
        assert changed
        c.execute('UPDATE meta SET value=? WHERE key="head"',(prev,))
        c.commit()
    finally:c.close()
    # Structural auditor accepts attack fiction if hash is consistently recomputed.
    try:
        core.load(dst);structural='ACCEPTED_STRUCTURALLY'
    except Exception as exc:structural='FAILED_'+type(exc).__name__
    try:cold.audit(dst,strict=False);semantic='ACCEPTED_BAD'
    except Exception as e:semantic='REJECTED_'+type(e).__name__
    assert structural=='ACCEPTED_STRUCTURALLY' and semantic=='REJECTED_AssertionError',(dst,structural,semantic)
    return {'case':src.stem,'tamper':variant,'integrity':'RECHAINED','structural':structural,'independent_oracle':semantic}

if __name__=='__main__':
    inputs=[p for p in sorted((ROOT/'runs').glob('POSTR61_*.sqlite')) if '.checkpoint.' not in p.name]
    results=[mutate(p,variant) for p in inputs for variant in ('FALSE_MISS','TELEPORT')]
    (ROOT/'REDTEAM_RESULTS.json').write_text(cold.canon(results)+'\n')
    print(json.dumps({'source_scenes':len(inputs),'mutations':len(results),'rejected_by_cold':sum(x['independent_oracle'].startswith('REJECTED_') for x in results),'results':results},indent=2))
