"""PESQ008 independent, repeatable browser audit; verifies LIVE TEST26 behavior without mutating its source."""
import json,hashlib, pathlib, random, argparse
from playwright.sync_api import sync_playwright
BASE=pathlib.Path(__import__('os').environ.get('TEST26_PUBLIC_DIR',str(pathlib.Path(__file__).resolve().parent/'src')))
H=(BASE/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
CSS=(BASE/'styles.css').read_text();JS=(BASE/'app.js').read_text()
OUTPUT=pathlib.Path(__file__).resolve().parent/'evidence'/('CROSS_LAYER_BROWSER_'+__import__('os').environ.get('BASELINE_LABEL','TEST26')+'_008.json')
results=[]
def add(id,expect,actual,detail=None):results.append({'id':id,'expected':expect,'observed':actual,'product_pass':expect==actual,'detail':detail})
def setup(b):
 p=b.new_page(viewport={'width':390,'height':844})
 p.set_content(H);p.add_style_tag(content=CSS)
 p.evaluate("window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db.get(k)??null,setItem:(k,v)=>window.__db.set(k,String(v)),removeItem:k=>window.__db.delete(k)}})")
 p.add_script_tag(content=JS)
 return p
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].walls=['02,01'];let valid=a.validateWorkspace(w),persisted=a.restoreCandidate(w);let cell=document.querySelector('[data-xy="2,1"]');return {valid,persisted,wallSerialized:a.scene().walls,wallRendered:cell.classList.contains('wall'),stored:window.__db.size>0}}''')
 add('wall_padded_key_rejected',False,out['valid'],out)
 add('wall_after_import_visually_shown',True,out['wallRendered'],out)
 add('wall_import_saved',True,out['stored'],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].walls=['02,01'];a.restoreCandidate(w);a.mode('play');const before=a.scene().units[0];a.cell(2,1);const after=a.scene().units[0];return {before:[before.x,before.y],after:[after.x,after.y],walls:a.scene().walls}}''')
 add('wall_blocks_movement_at_physical_cell',True,out['after']!=[2,1],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].danger=['02,01'];a.restoreCandidate(w);a.mode('play');a.cell(2,1);let logs=a.scene().logs;return {danger:a.scene().danger,warnings:logs.filter(x=>x.includes('Terreno perigoso')),lastLog:logs[0]}}''')
 add('danger_warning_at_physical_cell',True,len(out['warnings'])>0,out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].terrain['02,01']='water';a.restoreCandidate(w);let cell=document.querySelector('[data-xy="2,1"]');return {accepted:a.validateWorkspace(w),terrain:a.scene().terrain,drawn:cell.classList.contains('ground-water')}}''')
 add('terrain_padded_rejected',False,out['accepted'],out)
 add('terrain_matches_visual_cell',True,out['drawn'],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].walls=Array.from({length:7},(_,i)=>`02,0${i}`);let aliased=a.validateWorkspace(w);a.restoreCandidate(w);const aliasVisible=a.shadowcast({x:1,y:2,radius:8}).includes('3,2');let good=a.state();good.scenes[0].walls=Array.from({length:7},(_,i)=>`2,${i}`);a.restoreCandidate(good);let valid=a.validateWorkspace(good);const normalVisible=a.shadowcast({x:1,y:2,radius:8}).includes('3,2');return {aliased,aliasVisible,valid,normalVisible}}''')
 add('shadowcasting_wall_barrier_is_opaque_for_alias',True,out['aliasVisible']==out['normalVisible'],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].danger=['02,02'];w.scenes[0].walls=['2,2'];return {accepted:a.validateWorkspace(w),danger:w.scenes[0].danger,walls:w.scenes[0].walls}}''')
 add('alias_conflict_between_layers_rejected',False,out['accepted'],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].walls=['02,02','2,2'];return {accepted:a.validateWorkspace(w)}}''')
 add('alias_duplicate_wall_rejected',False,out['accepted'],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].explored=['02,02'];w.scenes[0].fovEnabled=true;a.restoreCandidate(w);return {accepted:a.validateWorkspace(w),keys:a.scene().explored.filter(x=>x==='02,02'),canonicalPresent:a.scene().explored.includes('2,2')}}''')
 add('alias_explored_rejected',False,out['accepted'],out)
 # Existing undo and ruler regressions to serve as contract witnesses.
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;a.mode('wall');a.cell(2,2);a.undo();a.mode('erase');a.cell(4,4);a.redo();return {walls:a.scene().walls,message:document.getElementById('message').textContent}}''')
 add('noop_preserves_redo',True,'2,2' in out['walls'],out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;a.resize(20);a.mode('measure');a.cell(15,15);a.cell(19,19);a.resize(7);let r=a.ruler();return {ruler:r,n:a.scene().n,allPointsValid:[r.start,r.end].every(q=>q===null||(q.x<a.scene().n&&q.y<a.scene().n))}}''')
 add('ruler_after_shrink_in_bounds',True,out['allPointsValid'],out)
 p.close();p=setup(browser)
 # New hypothesis: same number scenes, content replaced, no in-context review.
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].notes='versão alternativa';let review=a.restoreReview(w);return review}''')
 add('same_id_changed_scene_flagged',1,out['changedCount'],out)
 add('same_id_changed_scene_triggers_review',True,out['requiresReview'],out)
 # Positive guards, to avoid an all-red test suite.
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;a.mode('wall');a.cell(2,2);a.capture();a.mode('erase');a.cell(2,2);return {valid:a.validateWorkspace(a.state()),frames:a.scene().frames.length}}''')
 add('legitimate_topology_invalidation',True,out['valid'] and out['frames']==0,out)
 p.close();p=setup(browser)
 out=p.evaluate('''() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].walls=['2,2'];return {valid:a.validateWorkspace(w),canonical:'2,2'}}''')
 add('canonical_wall_is_valid',True,out['valid'],out)
 p.close();p=setup(browser)
 seed=20261022; rng=random.Random(seed); counts={'valid':0,'valid_rejected':0,'padded':0,'padded_accepted':0};dims=[5,7,10,20]
 for idx in range(240):
  n=dims[idx%4]; x=rng.randrange(n);y=rng.randrange(n)
  if (x,y) in [(1,1),(1,3),(n-2,2)]:continue
  key=f'{x},{y}' if idx%2==0 else f'{x:02},{y:02}'
  if idx%2==1 and key==f'{x},{y}': key=f'0{x},{y}'  # every invalid case now explicitly NONCANONICAL
  ret=p.evaluate('''arg => {const a=__tabletopTEST;let w=a.state();w.scenes[0].n=arg.n;w.scenes[0].units[2].x=arg.n-2;w.scenes[0].walls=[arg.key];return a.validateWorkspace(w)}''',{'key':key,'n':n})
  if idx%2==0:
   counts['valid']+=1;counts['valid_rejected']+=not ret
  else:
   counts['padded']+=1;counts['padded_accepted']+=bool(ret)
 add('generated_canonical_keys_all_accepted',0,counts['valid_rejected'],counts)
 add('generated_noncanonical_keys_all_rejected',0,counts['padded_accepted'],counts)
 record={'baseline':'TEST26 RUN008','code_sha256':hashlib.sha256(JS.encode()).hexdigest(),'browser_engine':browser.version,'browser_environment':'Linux headless browser with injected Map-based localStorage; NOT Android physical','seed':seed,'cases':results,'summary':{'total':len(results),'product_pass':sum(x['product_pass'] for x in results),'product_fail':sum(not x['product_pass'] for x in results)},'generated':counts}
 OUTPUT.write_text(json.dumps(record,indent=2,ensure_ascii=False))
 print(json.dumps(record['summary'],ensure_ascii=False))
 print('PRODUCT FAIL:',[x['id'] for x in results if not x['product_pass']])
 print('GENERATED:',counts)
 browser.close()
