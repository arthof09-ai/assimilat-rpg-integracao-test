# PESQ-INOV-008 — execução independente

Este pacote inclui **somente** scripts autorais, evidências sintéticas, capturas de experimento e manifesto. **Não contém** o `app.js` do Desenvolvedor, seu arquivo ZIP, replays privados, dados R205 ou assets de jogos.

## Preparação

Instalar Node 22+ e Python com Playwright e Chromium ou adaptar `executable_path` do script de navegador. Em máquina autorizada, fornecer uma **cópia TEST** do ZIP público TEST26 recuperado da Library do Mestre e conferir SHA256 `4e56b4d1208aa7165d412fe446996e53240f199959c0bf6ff4d076ed51fe39b9` antes de extrair. Colocar `index.html`, `styles.css`, `app.js` juntos em `src/` ao lado destes scripts. Nenhuma alteração ao código original é necessária.

```bash
node test_plan_migration_008.js
python audit_cross_layer_008.py
python integration_migration_008.py
```

Para outras versões autenticadas, passar o diretório de fontes:

```bash
TEST26_PUBLIC_DIR=/copia-autorizada/TESTXX BASELINE_LABEL=TESTXX python audit_cross_layer_008.py
```

A `lineage_probe_008.py` pede `legacy/test18`, `legacy/test22` e `src` com o trio HTML/CSS/JS de cada versão. São fontes externas ao ZIP de pesquisa; os códigos dos testes continuam independentes.

**Interpretação:** `product_pass=false` indica que a versão TEST observada NÃO atendeu ao contrato proposto; uma execução do teste sem exceção NÃO significa produto homologado. Testes de POC `pass=true` aprovam só o algoritmo sintético. Títulos de vídeo e resultados de outros Comestres não são tratados como testes desta pesquisa.

**Privacidade:** não rodar scripts nem publicar fixtures com dados VLAB reais, Party ou outras fontes privadas. Não copiar o pacote para GitHub Pages. Não criar nova operação ou delegar direitos ao código oficial.
