const {planScene}=require('./plan_migration_008');
let text='';process.stdin.on('data',x=>text+=x);process.stdin.on('end',()=>{const s=JSON.parse(text);process.stdout.write(JSON.stringify(planScene(s)))});
