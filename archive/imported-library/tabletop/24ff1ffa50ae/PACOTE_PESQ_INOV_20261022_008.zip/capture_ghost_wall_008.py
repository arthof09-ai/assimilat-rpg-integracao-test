from pathlib import Path
from playwright.sync_api import sync_playwright
BASE=Path(__file__).resolve().parent
html=(BASE/'src/index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
css=(BASE/'src/styles.css').read_text();js=(BASE/'src/app.js').read_text();o=BASE/'artifacts'
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844})
 page.set_content(html);page.add_style_tag(content=css)
 page.evaluate("window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db.get(k)??null,setItem:(k,v)=>window.__db.set(k,String(v)),removeItem:k=>window.__db.delete(k)}})")
 page.add_script_tag(content=js)
 for field in ('02,01','2,1'):
  data=page.evaluate('''key => {let a=__tabletopTEST,w=a.state();w.scenes[0].walls=[key];a.restoreCandidate(w);const t=document.querySelector('[data-xy="2,1"]');return {key,isWall:t.classList.contains('wall'),valid:a.validateWorkspace(a.state())}}''',field)
  page.locator('#viewport').screenshot(path=str(o/('CAPTURA_GHOST_WALL_008.png' if field=='02,01' else 'CAPTURA_CANONICAL_WALL_008.png')))
  print(data)
 browser.close()
