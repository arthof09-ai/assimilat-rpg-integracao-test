'use strict';
/* Read-only research planner for legacy scene coordinate aliases. No imports from TEST26. */
const RESERVED=new Set(['__proto__','constructor','prototype']);
const has=(obj,key)=>Object.prototype.hasOwnProperty.call(obj,key);
const own=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
function canonical(key,n){
 if(typeof key!=='string'||!/^[0-9]+,[0-9]+$/.test(key)||key.length>70)return null;
 const [sx,sy]=key.split(','),x=Number(sx),y=Number(sy);
 if(!Number.isSafeInteger(x)||!Number.isSafeInteger(y)||x<0||y<0||x>=n||y>=n)return null;
 return `${x},${y}`;
}
function planScene(scene){
 const errors=[],changes=[], warnings=[];
 if(!own(scene)||![5,7,10,20].includes(scene.n)||!Array.isArray(scene.walls)||!Array.isArray(scene.danger)||!Array.isArray(scene.explored)||!own(scene.terrain)||!Array.isArray(scene.units)||!Array.isArray(scene.frames))return {status:'INVALID_SOURCE',errors:['schema_invalid'],changes:[]};
 const copy=JSON.parse(JSON.stringify(scene)),n=scene.n;
 const layers={walls:new Map(),danger:new Map(),explored:new Map(),terrain:new Map()};
 for(const name of Object.keys(layers)){
  const original=name==='terrain'?Object.keys(scene.terrain):scene[name];
  for(const key of original){
   const can=canonical(key,n);
   if(can===null){errors.push({code:'INVALID_COORDINATE',layer:name,key});continue;}
   if(layers[name].has(can))errors.push({code:'DUPLICATE_CANONICAL',layer:name,canonical:can,keys:[layers[name].get(can),key]});
   else layers[name].set(can,key);
   if(can!==key)changes.push({layer:name,from:key,to:can});
  }
 }
 if(scene.units.some(u=>!own(u)||typeof u.id!=='string'||!Number.isInteger(u.x)||!Number.isInteger(u.y)||u.x<0||u.y<0||u.x>=n||u.y>=n))errors.push({code:'UNIT_INVALID'});
 const usedUnits=new Set(),unitPositions=new Set();
 for(const u of scene.units.filter(own)){
   if(usedUnits.has(u.id))errors.push({code:'UNIT_ID_DUPLICATE',id:u.id});usedUnits.add(u.id);
   const where=`${u.x},${u.y}`;if(unitPositions.has(where))errors.push({code:'UNIT_POSITION_DUPLICATE',where});unitPositions.add(where);
 }
 for(const [coord,value] of Object.entries(scene.terrain)){if(!['grass','sand','water'].includes(value))errors.push({code:'INVALID_TERRAIN_VALUE',coord})}
 const occupants=new Set(scene.units.filter(own).map(u=>`${u.x},${u.y}`));
 for(const key of layers.walls.keys()){
  if(occupants.has(key))errors.push({code:'WALL_TOKEN_CONFLICT',key});
  if(layers.danger.has(key))errors.push({code:'WALL_DANGER_CONFLICT',key});
  if(layers.terrain.has(key))errors.push({code:'WALL_TERRAIN_CONFLICT',key});
 }
 if(scene.frames.length||scene.frameTopology!==null){
  const changedWalls=changes.some(c=>c.layer==='walls');
  if(changedWalls)errors.push({code:'REPLAY_TOPOLOGY_REQUIRES_REVIEW',frameCount:scene.frames.length});
 }
 if(errors.length)return {status:'CONFLICT',errors,changes,originalUnchanged:true};
 for(const name of ['walls','danger','explored'])copy[name]=[...layers[name].keys()];
 const terrain={};
 for(const [key,old] of layers.terrain.entries())terrain[key]=scene.terrain[old];
 copy.terrain=terrain;
 const status=changes.length?'SAFE_NORMALIZATION':'NO_CHANGE';
 return {status,changes,errors:[],scene:copy,warnings,originalUnchanged:true};
}
module.exports={planScene,canonical};
