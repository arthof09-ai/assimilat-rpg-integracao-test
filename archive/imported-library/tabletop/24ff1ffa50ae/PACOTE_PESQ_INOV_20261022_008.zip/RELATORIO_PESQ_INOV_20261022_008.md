# PESQ-INOV-20261022-008 — Auditoria de integridade entre camadas e migração segura de coordenadas

**Emissão:** 22/10/2026  
**Identidade funcional:** Terceiro Comestre Inovador — Pesquisador / MESTRE-SIDE / TEST  
**Autoridade:** continuação da PESQ-007 por ordem direta do Mestre; protocolo NAC-AUTO-01 recebido **como proposta operacional**, não homologado nem convertido em norma canônica por esta pesquisa.  
**Escopo:** cópias físicas imutáveis TEST18, TEST22, TEST26, fixtures sintéticas, sem escrita em código do Desenvolvedor, GitHub, Party/O Primeiro ou bancos VLAB.

## Síntese executiva

- **VERIFICADO:** a representação não canônica de casas (por exemplo `02,01`) aceita pelo validador TEST26 causa divergência **real em quatro camadas**: desenho do tabuleiro, bloqueio de movimentação, aviso de terreno perigoso e FOV. O backup é aceito/persistido como válido, mas o jogo visual interpreta outra topologia. **Esse é um único defeito de contrato com consequências distintas**, não uma nova regra do RPG.
- **VERIFICADO:** a mesma aceitação de aliases em `walls`, `danger`, `terrain`, `explored`, a duplicação `2,2`/`02,02` e a perda de Refazer após clique sem efeito ocorreram nas **três versões físicas TEST18, TEST22 e TEST26**. Não foram introduzidas pela régua TEST25.
- **VERIFICADO:** `restoreReview` em TEST22 e TEST26 reconhece `changedCount=1` para backup com mesmo ID de cena e conteúdo alterado, mas deixa `requiresReview=false`; a importação ainda oferece confirmação genérica. **Classificação:** oportunidade de informação ao Mestre, **não** prova de perda silenciosa.
- **PROPOSTO, TESTADO SOMENTE EM POC:** leitor não destrutivo classifica migrações em `NO_CHANGE`, `SAFE_NORMALIZATION`, `CONFLICT`, `INVALID_SOURCE`. Bloqueia colapso de aliases, sobreposição física de parede/token, parede/perigo/terreno e alteração de parede com replay vinculado à assinatura antiga. **25/25 testes dirigidos, 400/400 casos gerados PASS; 15/15 verificações de reaplicação em navegador PASS**, sem tocar produto oficial.

## Proveniência e denominadores

**Pacote técnico RUN008 recuperado previamente da Library:** `PACOTE_TECNICO_TABLETOP_TEST24_A_TEST26_20261022.zip`, 7.806.415 bytes, SHA-256 `747e8bc2cb59d96d9e4c3bc64b6d348813d8f6a3844f44f4a0707161db3bf0f0`. **Site público TEST26 (arquivo de laboratório, não URL hospedada):** ZIP 22.935 bytes, SHA-256 `4e56b4d1208aa7165d412fe446996e53240f199959c0bf6ff4d076ed51fe39b9`. **Privado:** ZIP original TEST26 SHA-256 `31450ed2cbb20da44f310493b2cbb795082ee0ba3cf7dfc166bfc82bdb07da53`, lido apenas para custódia, não redistribuído.

Código público `app.js` SHA-256 (três versões autenticadas por ZIPs próprios):

| Base | SHA-256 `app.js` |
|---|---|
| TEST18 | `664f543c785fa346e0d0e230b5e88b520532fe32951fc08a47a6bc29cce861d9` |
| TEST22 | `23be2ff6009964ce7f173d22c76bd74fc1f91c40ed8223612b26a5c69f0b4d81` |
| TEST26 | `218a0cee00e37d14dcc9666ba491f0287b72d1cda4633f24b1416c5ec3acf0c5` |

O Desenvolvedor declarou **561/561** PASS para RUN008; **não reexecutados nesta pesquisa**. Todos os novos ensaios abaixo pertencem ao Pesquisador.

**Bancada de navegador:** Chromium 144.0.7559.96, Linux headless, 390×844, `page.set_content`, armazenamento sintético `Map`; CSP da página desabilitada apenas no *harness*, nunca no ZIP original. Não representa Chrome Android físico nem HTTPS. `JS` oficial intocado.

### ONDA A — auditoria transversal no produto

Script `audit_cross_layer_008.py`, JSON `CROSS_LAYER_BROWSER_TEST26_008.json`:

- **19 critérios distintos:** **5 PASS de contrato e 14 FAIL de contrato**. PASS de uma asserção de observação não deve ser confundido com homologação; os 14 FAIL concentram classes de problema preexistentes, incluindo redo, régua e contrato UX de backup.
- **240 tentativas pseudoaleatórias de entradas, 224 executadas:** 111 chaves canônicas aceitas, 0 canônicas rejeitadas; 113 chaves *deliberadamente não canônicas* aceitas pelo TEST26, 0 rejeitadas. `seed=20261022`. 113 aliases não são 113 bugs diferentes.
- **Paredes:** import `walls=['02,01']` → `validateWorkspace=true`, `restoreCandidate=true`, `localStorage` sintético contém estado e elemento físico `data-xy="2,1"` não tem classe `wall`. Em modo play token desloca-se à casa; a parede canônica bloquearia.
- **Perigo:** `danger=['02,01']` → movimento pela casa sem log `Terreno perigoso`, embora a mesma casa com `2,1` produzisse o aviso de TEST. Não extrapolar para dano canônico.
- **Terreno:** `terrain={'02,01':'water'}` validado, mas classe `ground-water` ausente na casa física.
- **FOV:** parede contínua com chaves `02,0y` deixa célula do outro lado visível; a mesma parede com chaves `2,y` altera visibilidade. Isto é desacordo de representação, **não defeito demonstrado do Symmetric Shadowcasting quando recebe entrada canônica**.
- **Colisões:** `walls=['2,2','02,02']` e parede `2,2` com perigo `02,02` passam no validador sem serem o mesmo registro textual, apesar da mesma posição física.
- **Histórico:** após Parede→Desfazer→Apagar em casa vazia, Refazer perde o futuro sem mudança efetiva (PESQ007 confirmada de novo).
- **Régua:** endpoints válidos em 20² continuam sendo exibidos ao reduzir para 7² (PESQ007 reconfirmada).
- **Backup UX:** `changedCount=1`, `requiresReview=false` sob mesmo ID, versão alterada. Há confirmação genérica; apenas a revisão detalhada deixa de ser oferecida. Classificar como PROPOSTO P2.

**Prova visual:** `CAPTURA_GHOST_WALL_008.png` e `CAPTURA_CANONICAL_WALL_008.png`: mesma posição física, entrada alias aceita/invisível versus canônica visível.

### ONDA B — linhagem 18 → 22 → 26

`lineage_probe_008.py`, JSON `LINEAGE_TEST18_TEST22_TEST26_008.json`: versões TEST18, TEST22 e TEST26 passaram a mesma bancada com **cinco condições de alias/duplicação e uma condição de redo** por versão. Todos os três aceitaram aliases nas quatro camadas e duplicata equivalente, e todos perderam refazer em no-op. `restoreReview` existe em TEST22 e TEST26 e apresentou a oportunidade de UX já descrita. Régua não existia em TEST18/22: **não tratada como teste negativo nessas versões**.

### ONDA C — plano de migração não destrutiva

`plan_migration_008.js`: função **isolada de pesquisa**, API `planScene(scene) -> {status,changes,errors,scene?}`. Não é patch do Tabletop, não usa dados privados.

Regras experimentais:
1. `canonical(key,n)` interpreta apenas dois inteiros decimais não negativos, na grade e `Number.isSafeInteger`, produz `${x},${y}`.
2. Cada camada `walls,danger,explored,terrain` é normalizada no clone, sem tocar original.
3. Colisões de aliases na mesma camada são `CONFLICT`; parede com token/perigo/terreno também é `CONFLICT`; IDs e posições duplicados de tokens e valor de terreno inválido geram conflito.
4. Mudança textual de parede com `frames`/`frameTopology` vinculados exige revisão: `REPLAY_TOPOLOGY_REQUIRES_REVIEW`. Não reescrever silenciosamente assinatura do replay.
5. `SAFE_NORMALIZATION` somente quando não há conflito; se não muda nada, `NO_CHANGE`. Se o dado nem respeita formato básico, `INVALID_SOURCE`.

**Resultados:** `test_plan_migration_008.js` **25/25 dirigido PASS**, mais **400/400 normalizações geradas PASS**; verificação de idempotência e entrada original imutável. Após corrigir um defeito no *próprio* POC (objeto null-prototype não aceito por contrato plain do Tabletop), testes repetidos PASS. Esse ajuste de pesquisa não foi defeito do Tabletop.

`integration_migration_008.py` aciona de fato as versões normalizadas no **TEST26 original** com storage sintético: **15/15 PASS**, incluindo parede passa a bloquear caminho, perigo gera aviso, terreno recebe classe visual, explorado ganha chave canônica, conflito bloqueado sem tocar fonte e assinatura de replay protegida.

**LIMITAÇÃO IMPORTANTE:** o POC não substitui `validateWorkspace` integral e não migra automaticamente backups com replay; é apenas planejador. Integração real exige validação do workspace inteiro, modelo de confirmação/backup e teste Android. Decisões são do Desenvolvedor/Mestre.

## Encaminhamentos — sem duplicar D-INOV

**Adendo de evidência ao D-INOV-20261022-029 (P0/P1):** elevar de *ghost wall visual* para **inconsistência transversal entre desenho, pathfinding, aviso de perigo e FOV**. Entregar nova suíte como aceite. Solução mínima: validar chave canônica em `validateScene` e migrar somente casos seguros com export preventivo; conflitos ou topologia de replay exigem decisão explícita. **Não criar outro despacho para o mesmo defeito**.

**D-INOV-030 e D-INOV-031:** as falhas de redo e régua persistem TEST26 e também possuem testemunha reproduzível no novo `audit_cross_layer_008.py`; aguardam RUN posterior. Não reimplementar no lugar do Desenvolvedor.

**Adendo de baixa urgência ao D-INOV-020 (restauro de backup):** `restoreReview` reconhece cena alterada no mesmo ID e não força revisão detalhada. Sugestão: se `changedCount>0`, mostrar resumo, mas avaliar custo adicional de toques no Android e manter opção cancelar. É UX proposta, não bug de corrupção.

## Gates, segurança e FIRST NEXT

- **VERIFICADO:** fontes TEST18/22/26 autenticadas, novos ensaios Chromium, migração independente, comparação visual, manifestos e proveniência. **NÃO** medidos Android físico, hospedagem pública ou duas abas reais.
- **NAC-AUTO-01:** apenas diretriz PROPOSTA usada neste ciclo para planejar→auditar→executar→verificar→continuar; sem homologar nova norma, delegação ou poder de modificar código alheio.
- **NAC-PASS-02 proporcional:** PASS somente para **artefatos e experimentos científicos**, NÃO PASS de produto (14 critérios falhando), Party, VLAB ou infraestrutura.
- **PRÓXIMO PASSO EXATO:** consultar RUN-009+; se nova versão existir, executar `audit_cross_layer_008.py` sobre seu app.js/HTML/CSS, depois teste positivo do plano de migração; reclassificar D029/030/031 somente com evidência nova. Se versão permanecer TEST26, encaminhar dossiê ao Coordenador responsável por D029 e preservar a suíte sem criar escrita no ramo público.
