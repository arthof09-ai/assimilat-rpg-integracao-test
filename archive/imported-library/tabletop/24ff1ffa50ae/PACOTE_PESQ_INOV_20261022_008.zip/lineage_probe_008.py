"""Historical audit: minimal behavior contract shared by TEST18, TEST22 and TEST26 without assuming newer APIs."""
import pathlib,json,hashlib
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent
PATHS={'TEST18':ROOT/'legacy/test18','TEST22':ROOT/'legacy/test22','TEST26':ROOT/'src'}
results=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for version,path in PATHS.items():
  html=(path/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
  js=(path/'app.js').read_text();css=(path/'styles.css').read_text()
  p=b.new_page(viewport={'width':390,'height':844})
  p.set_content(html);p.add_style_tag(content=css)
  p.evaluate("window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db.get(k)??null,setItem:(k,v)=>window.__db.set(k,String(v)),removeItem:k=>window.__db.delete(k)}})")
  p.add_script_tag(content=js)
  outcome=p.evaluate('''() => {const a=window.__tabletopTEST;let checks={};let types=['walls','danger','explored','terrain'];for(const layer of types){const w=a.state();if(layer==='terrain')w.scenes[0].terrain['02,02']='water';else w.scenes[0][layer]=['02,02'];checks[layer]=a.validateWorkspace(w);}let w=a.state();w.scenes[0].walls=['02,02','2,2'];checks.aliasDuplicate=a.validateWorkspace(w);let noEffect=null;if(a.undo&&a.redo&&a.cell&&a.mode){a.mode('wall');a.cell(2,2);a.undo();a.mode('erase');a.cell(4,4);a.redo();noEffect=a.scene().walls.includes('2,2')}let review=null;if(a.restoreReview){w=a.state();w.scenes[0].notes='new state';review=a.restoreReview(w)}return {checks,redoAfterNoop:noEffect,review,api:{ruler:typeof a.ruler==='function',restoreReview:typeof a.restoreReview==='function'}};}''')
  results.append({'version':version,'js_sha256':hashlib.sha256(js.encode()).hexdigest(),'observed':outcome,'engine':b.version})
  p.close()
 (ROOT/'evidence'/'LINEAGE_TEST18_TEST22_TEST26_008.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(json.dumps(results,ensure_ascii=False,indent=2))
 b.close()
