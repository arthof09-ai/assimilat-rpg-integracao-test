const assert=require('node:assert/strict');
const {planScene,canonical}=require('./plan_migration_008');
const cases=[];function test(name,fn){try{fn();cases.push({name,pass:true})}catch(e){cases.push({name,pass:false,error:e.message})}}
const scene=()=>({n:7,walls:[],danger:[],explored:[],terrain:{},units:[{id:'u1',x:1,y:1}],frames:[],frameTopology:null});
test('canonical_number',()=>{assert.equal(canonical('02,003',7),'2,3');assert.equal(canonical('2,3',7),'2,3')});
test('invalid_unsafe_integer',()=>assert.equal(canonical('9999999999999999999,1',7),null));
test('out_of_range',()=>assert.equal(canonical('7,1',7),null));
test('negative',()=>assert.equal(canonical('-1,1',7),null));
test('invalid_syntax',()=>assert.equal(canonical('1e1,1',20),null));
test('padded_walls_normalize',()=>{let s=scene();s.walls=['02,02'];let p=planScene(s);assert.equal(p.status,'SAFE_NORMALIZATION');assert.deepEqual(p.scene.walls,['2,2']);assert.deepEqual(s.walls,['02,02'])});
test('padded_danger_normalize',()=>{let s=scene();s.danger=['02,02'];assert.deepEqual(planScene(s).scene.danger,['2,2'])});
test('padded_explored_normalize',()=>{let s=scene();s.explored=['02,02'];assert.deepEqual(planScene(s).scene.explored,['2,2'])});
test('padded_terrain_normalize',()=>{let s=scene();s.terrain={'02,02':'water'};assert.equal(planScene(s).scene.terrain['2,2'],'water')});
test('duplicate_walls_fails',()=>{let s=scene();s.walls=['2,2','02,02'];assert.equal(planScene(s).status,'CONFLICT')});
test('duplicate_danger_fails',()=>{let s=scene();s.danger=['2,2','02,02'];assert.equal(planScene(s).status,'CONFLICT')});
test('duplicate_explored_fails',()=>{let s=scene();s.explored=['2,2','02,02'];assert.equal(planScene(s).status,'CONFLICT')});
test('wall_unit_fails',()=>{let s=scene();s.walls=['01,01'];assert(planScene(s).errors.some(e=>e.code==='WALL_TOKEN_CONFLICT'))});
test('wall_danger_fails',()=>{let s=scene();s.walls=['02,02'];s.danger=['2,2'];assert(planScene(s).errors.some(e=>e.code==='WALL_DANGER_CONFLICT'))});
test('wall_terrain_fails',()=>{let s=scene();s.walls=['02,02'];s.terrain['2,2']='sand';assert(planScene(s).errors.some(e=>e.code==='WALL_TERRAIN_CONFLICT'))});
test('wall_replay_blocks_automatic_rewrite',()=>{let s=scene();s.walls=['02,02'];s.frames=[{title:'frame'}];s.frameTopology='legacy';assert(planScene(s).errors.some(e=>e.code==='REPLAY_TOPOLOGY_REQUIRES_REVIEW'))});
test('only_explored_normalizes_with_replay',()=>{let s=scene();s.explored=['02,02'];s.frames=[{title:'frame'}];s.frameTopology='legacy';assert.equal(planScene(s).status,'SAFE_NORMALIZATION')});
test('duplicate_terrain_alias_fails',()=>{let s=scene();s.terrain={'2,2':'water','02,02':'sand'};assert.equal(planScene(s).status,'CONFLICT')});
test('duplicate_unit_id_fails',()=>{let s=scene();s.units.push({id:'u1',x:3,y:3});assert(planScene(s).errors.some(e=>e.code==='UNIT_ID_DUPLICATE'))});
test('duplicate_unit_cell_fails',()=>{let s=scene();s.units.push({id:'u2',x:1,y:1});assert(planScene(s).errors.some(e=>e.code==='UNIT_POSITION_DUPLICATE'))});
test('invalid_terrain_value_fails',()=>{let s=scene();s.terrain['02,02']='lava';assert(planScene(s).errors.some(e=>e.code==='INVALID_TERRAIN_VALUE'))});
test('no_change_unchanged',()=>{let s=scene();s.walls=['2,2'];assert.equal(planScene(s).status,'NO_CHANGE')});
test('idempotence',()=>{let s=scene();s.walls=['02,02'];let p=planScene(s);assert.equal(planScene(p.scene).status,'NO_CHANGE')});
test('invalid_source_fails',()=>{let s=scene();s.n=8;assert.equal(planScene(s).status,'INVALID_SOURCE')});
test('blocked_is_non_mutating',()=>{let s=scene();s.walls=['01,01'];const str=JSON.stringify(s);planScene(s);assert.equal(JSON.stringify(s),str)});
let seed=20261022>>>0;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed};const gen={seed:20261022,iterations:400,pass:0,fail:0,failures:[]};for(let i=0;i<400;i++){
 let s=scene(),x=2+(rnd()%4),y=2+(rnd()%4);const key=`${String(x).padStart(2,'0')},${String(y).padStart(2,'0')}`;s.walls=[key];const p=planScene(s);if(p.status==='SAFE_NORMALIZATION'&&p.scene.walls[0]===`${x},${y}`&&JSON.stringify(s.walls)===JSON.stringify([key]))gen.pass++;else{gen.fail++;if(gen.failures.length<5)gen.failures.push({key,p})}
}
if(gen.fail)process.exitCode=1;
if(cases.some(x=>!x.pass))process.exitCode=1;
console.log(JSON.stringify({tests:cases.length,passed:cases.filter(x=>x.pass).length,failed:cases.filter(x=>!x.pass),generated:gen},null,2));
require('node:fs').writeFileSync(__dirname+'/evidence/MIGRATION_PLANNER_008.json',JSON.stringify({tests:cases,generated:gen,scope:'synthetic standalone, not Tabletop developer code'},null,2));
