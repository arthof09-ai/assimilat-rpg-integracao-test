"""Execute migration candidate through physical TEST26 browser, without changing product code.
Requires TEST26_PUBLIC_DIR or local src read-only mount.
"""
import json,subprocess,os,pathlib,hashlib
from playwright.sync_api import sync_playwright
DIR=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path(os.getenv('TEST26_PUBLIC_DIR',str(DIR/'src')))
H=(BASE/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
CSS=(BASE/'styles.css').read_text();JS=(BASE/'app.js').read_text()
def migrate(s):
 r=subprocess.run(['node',str(DIR/'bridge_migration_008.js')],input=json.dumps(s),text=True,capture_output=True,check=True)
 return json.loads(r.stdout)
checks=[]
def add(name,expect,actual,detail=None):checks.append({'name':name,'expected':expect,'actual':actual,'pass':expect==actual,'detail':detail})
def page_new(browser):
 p=browser.new_page(viewport={'width':390,'height':844});p.set_content(H);p.add_style_tag(content=CSS)
 p.evaluate("window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db.get(k)??null,setItem:(k,v)=>window.__db.set(k,String(v)),removeItem:k=>window.__db.delete(k)}})")
 p.add_script_tag(content=JS);return p
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=page_new(b)
 original=p.evaluate('() => __tabletopTEST.state()')
 for family in ['walls','danger','terrain','explored']:
  scene=json.loads(json.dumps(original['scenes'][0]))
  if family=='terrain':scene[family]={'02,01':'water'}
  else:scene[family]=['02,01']
  res=migrate(scene)
  add(f'{family}_candidate_safe', 'SAFE_NORMALIZATION',res['status'])
  if res['status']!='SAFE_NORMALIZATION':continue
  w=json.loads(json.dumps(original));w['scenes'][0]=res['scene']
  check=p.evaluate('''arg => {const a=__tabletopTEST;a.restoreCandidate(arg.w);let tile=document.querySelector('[data-xy="2,1"]'),view={valid:a.validateWorkspace(a.state()),wall:tile.classList.contains('wall'),terrain:tile.classList.contains('ground-water'),danger:a.scene().danger.includes('2,1'),explored:a.scene().explored.includes('2,1')};if(arg.family==='walls'){a.mode('play');a.cell(2,1);view.wallBlocks=a.scene().units[0].x!==2||a.scene().units[0].y!==1}if(arg.family==='danger'){a.mode('play');a.cell(2,1);view.alert=a.scene().logs.some(s=>s.includes('Terreno perigoso'))}return view;}''',{'w':w,'family':family})
  add(f'{family}_valid_after_rehydrate',True,check['valid'],check)
  if family=='walls':add('normalized_wall_blocks_path',True,check['wallBlocks'],check)
  if family=='terrain':add('normalized_terrain_drawn',True,check['terrain'],check)
  if family=='danger':add('normalized_danger_raises_warning',True,check['alert'],check)
  if family=='explored':add('normalized_explored_key_present',True,check['explored'],check)
  p.close();p=page_new(b)
 s=json.loads(json.dumps(original['scenes'][0]));s['walls']=['02,02','2,2'];before=json.dumps(s,sort_keys=True);m=migrate(s);add('collision_blocks_migration','CONFLICT',m['status']);add('collision_preserves_input',before,json.dumps(s,sort_keys=True))
 s=json.loads(json.dumps(original['scenes'][0]));s['walls']=['02,02'];s['frames']=[{'title':'legacy','positions':{}}];s['frameTopology']='legacy';m=migrate(s);add('replay_blocks_automatic_migration','CONFLICT',m['status'])
 record={'baseline_SHA':hashlib.sha256(JS.encode()).hexdigest(),'browser':b.version,'cases':checks,'summary':{'total':len(checks),'passed':sum(c['pass'] for c in checks),'failed':[c['name'] for c in checks if not c['pass']]},'scope':'standalone proposal for test browser, never applied to developer code'}
 (DIR/'evidence'/'INTEGRATION_MIGRATION_008.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
 print(json.dumps(record['summary'],ensure_ascii=False));b.close()
