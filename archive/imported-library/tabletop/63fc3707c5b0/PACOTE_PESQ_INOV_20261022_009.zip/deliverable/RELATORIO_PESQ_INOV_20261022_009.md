# PESQ-INOV-20261022-009 — Auditoria independente RUN-009 / TEST 29→32

**Projeto:** RPG Assimilação · Tabletop Assimilação · Terceiro Comestre Inovador Pesquisador. **Ambiente:** MESTRE-SIDE / TEST, Laboratório do Inovador existente. **Data:** 22/10/2026. **Prioridade:** integridade espacial P0. **Orçamento adicional:** R$0.

## Sumário executivo (VERIFICADO, INFERIDO, PROPOSTO, PENDENTE)

- **VERIFICADO — Fonte mais recente:** o Notion contém RUN-009 **TEST27–32**, não somente o antigo checkpoint TEST29. A Library guarda os ZIPs autoritativos. O pacote técnico final TEST32 contém 65 entradas, manifesto **64/64 SHA e tamanhos PASS**, CRC PASS. O aplicativo público contém três arquivos, CRC PASS; fonte JS público e técnico coincidentes.
- **VERIFICADO — RED TEST29:** a suíte original PESQ008 reproduziu **5/19 critérios atendidos, 14/19 falhos**, incluindo aliases de coordenadas, paredes fantasmas, caminho, perigo, FOV, histórico Refazer, régua e revisão de backup. São critérios, NÃO 14 bugs autônomos.
- **VERIFICADO — GREEN majoritário TEST32:** **37/39 critérios PASS** na suíte independente adaptada. Houve **dois contratos FAIL** relacionados a uma mesma classe residual: salvar marcador sem mudança e confirmar nota de cena idêntica ainda derrubam a pilha Refazer. Correções de paredes/terreno, régua e backup parcial são reais, não apenas relatadas.
- **VERIFICADO — geração e migração:** 187 chaves canônicas testadas aceitas, 189 chaves não canônicas rejeitadas na mesma suíte; mais **1.280/1.280 casos gerados** de oito famílias no planejador efetivo TEST32. **8/8 testes de interface de importação PASS**, **3/3 observações** de inicialização/recuperação/FOV, **8/8 mutantes intencionais detectados**, **6/6 testes RED→GREEN** da pequena correção de Refazer em cópia de memória. Todas as famílias têm denominadores separados.
- **NOVA OBSERVAÇÃO / REGRA VISUAL PENDENTE:** marcadores na SVG são exibidos acima de células `fov-hidden` não exploradas; o FOV atual é apenas visual, MESTRE-SIDE, **NÃO** mecanismo de sigilo Party, logo não denominar vazamento de segurança. Escolher política de camadas.
- **PENDENTE:** Chrome Android real; duas abas verdadeiras HTTPS, CAS atômico; migração de backups reais historicamente autorizados, replays reais, canonicalização formal Party; não implantar nada nesta pesquisa.

## 1. Proveniência, estado ANTES→DEPOIS

| Distribuição | Nome e SHA-256 SHA autenticado | Integridade |
|---|---|---|
| RUN-009 TEST29 técnico | `PACOTE_TECNICO_TABLETOP_TEST27_A_TEST29_20261022.zip` · `28bbbdae410f11590d7151870d6069aaab09173530ccf9946ed140483e29c163` | CRC PASS |
| RUN-009 TEST29 público | `TABLETOP_SITE_SINTETICO_TEST29.zip` · `5ef67741e5b858170d5fc40ff2a4cda94501b17cf933e1f2316747161d1d8a86` | CRC PASS |
| RUN-009 TEST32 técnico | `PACOTE_TECNICO_TABLETOP_TEST27_A_TEST32_20261022.zip` · `d51bb0cfb2eef55797ea0f9c71d34b90b56c4965309c727a71c33e50804d2de8` | CRC PASS · 64/64 manifesto |
| RUN-009 TEST32 público | `TABLETOP_SITE_SINTETICO_TEST32.zip` · `f7ac82dc4945a45734d11f52e1b1ea3c502615c065edd2ace7ac6884b783d7c7` | CRC PASS |
| PESQ-008 (baseline teste) | `24ff1ffa50aeedb7aaa0efb35002f508a9af2ebb04ae5b383841fdfe8ccb8ff4` | CRC PASS |

**App JS TEST29:** SHA `c098bfbb44724993f181b729f9767bba4ebaa1a1f6b77f654a78cc881d26c034`. **App JS TEST32:** SHA `758a16a29d0ae8c584ab62956351761dba846e640518543bc3fb30a898d86c2a`. O SHA aplica-se aos bytes originais extraídos; scripts de auditoria usam esse JS sem edição, com CSP desabilitada exclusivamente para `page.set_content` da bancada isolada. É Chromium 144/Linux, não Chrome físico Android.

**Resultados do Segundo Desenvolvedor:** RUN009 Notion declara **757/757 casos dirigidos** (561 anteriores, 196 novos), **1.500 entradas geradas** e **12/12 mutações**, do próprio executor. **NÃO foram reexecutados integralmente por este Pesquisador** e não entram nos denominadores acima.

## 2. Integridade espacial e migração — testes científicos

O TEST29 ainda aceitava `walls=['02,01']` e em bancada persistia uma barreira textual invisível, permitindo movimento, omitindo aviso de perigo quando aplicado à respectiva camada, perdendo visualização de terreno e fazendo FOV atravessar paredes com zeros à esquerda. O TEST32 mudou o contrato: `isCanonicalCoord` obriga chave igual a `${x},${y}`; `planCoordinateMigration` normaliza cada camada antes de importar, bloqueia colisões entre aliases, tokens, camadas e snapshots com topologia afetada.

**TEST32 matriz dirigida — 39 critérios (separados da PESQ008):**

| ID contrato | TEST 32 | Observação principal |
|---|---|---|
| `safe_migration_persists_and_renders_wall` | PASS | Aceite demonstrado |
| `safe_migration_blocks_real_path` | PASS | Aceite demonstrado |
| `safe_migration_danger_warning` | PASS | Aceite demonstrado |
| `safe_migration_fov_wall_barrier` | PASS | Aceite demonstrado |
| `collision_wall_semantic_duplicates_blocked` | PASS | Aceite demonstrado |
| `topology_replay_changed_wall_requires_review` | PASS | Aceite demonstrado |
| `ruler_shrink_clears_endpoints` | PASS | Aceite demonstrado |
| `marker_resize_confirms_loss_and_can_cancel` | PASS | Aceite demonstrado |
| `changed_same_scene_review_required` | PASS | Aceite demonstrado |
| `marker_update_identical_does_not_drop_redo` | FAIL | Refazer descartado por ação sem alteração |
| `scene_notes_identical_does_not_drop_redo` | FAIL | Refazer descartado por ação sem alteração |
| `generated_alias_keys_all_rejected` | PASS | Aceite demonstrado |
| `generated_canonical_keys_all_accepted` | PASS | Aceite demonstrado |

**Gerador simples de validação:** seed 20261022, 400 candidatos, **376 efetivamente elegíveis** após exclusão de células com tokens (187 canônicos e 189 não canônicos), 376/376 atendidos. O número 400 é tentativas, não 400 executados. 

**Gerador de migração:** seed 20261022, **1.280/1.280** casos avaliados, 160 de cada grupo: SAFE, IDENTITY, DUPLICATE, CROSS_LAYER, TOKEN, FRAMES, MARKER, LEGACY. Verifica entrada imutável, candidato validado, idempotência, bloqueio de ambiguidades e preservação de marcações. PASS nessa amostra não certifica toda migração possível nem dados privados reais.

**Importação pela UI efetiva:** 8/8 PASS: aviso de normalização, cancelar sem mutação, confirmar com assinatura canônica e releitura fria, recusar duplicata, recusar replay topológico, revisar backup cuja única alteração são marcadores, detectar falha `QuotaExceededError` injetada antes de gravar sem falso sucesso. **Inicialização com armazenamento legado real simulado:** 2/2 estados observados corretamente — alias único reconciliado com consentimento e original ambíguo preservado e bloqueado.

**Contrato mínimo para D-INOV-029:**

```json
{"map_schema":"workspace.v1","layers":{"walls":["02,01"],"danger":[],"terrain":{},"explored":[]},"expected":"SAFE_NORMALIZATION_AFTER_PREVIEW"}
```

- Entrada nova deve rejeitar alias diretamente. Leitura LEGADA autorizada pode devolver `NO_CHANGE`, `SAFE_NORMALIZATION`, `CONFLICT` ou `INVALID_SOURCE` sem escrever na origem.
- `SAFE_NORMALIZATION` só oferece candidato novo, original intacto, com prévia. Não transformar replay/topologia automaticamente quando a parede antiga mudar de representação.
- Rejeitar colisões parede/marker? No contrato atual marcador visual pode sobrepor parede; é representação de apresentação, não obstáculo. Rejeitar parede/token, paredes duplicadas e conflito parede/perigo/terreno; não inventar regra adicional sem Mestre.
- Replay TEST03, TEST15 e novas versões ainda precisam de regressão de importação quando patch mudar; a suíte atual não é homologação global dos replays.

## 3. Histórico Refazer — residuais REALMENTE falhos

**D-INOV-030, NOVA extensão evidenciada no TEST32:** `clickCell()` agora preserva `future` se um modo de terreno nada alterou. **Porém** `markerCommand('UPDATE')` salva snapshot ao confirmar tipo+texto iguais; e handler `sceneNotes.change` chama `snap()` mesmo quando a string não mudou. Ambos descartam `future`, acrescentam operação/log/revisão desnecessária. O erro é o mesmo princípio de identidade de mutação do D030, sem abrir D duplicado.

**Provas mínimas:**
1. Criar marcador A; criar parede; Desfazer; abrir marcador A e confirmar mesmos campos; Refazer → "Nada para refazer", parede não volta (RED original).
2. Criar parede; Desfazer; disparar change no textarea sem mudança; Refazer → não volta (RED original).
3. **POC copy-in-memory** compara `{kind,text}` antes de `snap()`, e `value===s.notes` antes de snapshot; testa também alterações reais. **6/6 diferenciais PASS**: RED observável no original, GREEN na cópia, alterações verdadeiras ainda invalidam Refazer.

**Patch conceitual mínimo:**

```javascript
// No ramo UPDATE, APÓS validar payload e ANTES de snap():
if (oldMarker.kind === payload.kind && oldMarker.text === payload.text) {
  closeMarkerDialog(); return;
}
// No handler de change da nota, ANTES de snap():
if (value === currentScene.notes) return;
```

As variáveis são nomes EXPLICATIVOS do contrato, não patch pronto para colar literalmente. Não mudar o motor de histórico nem editar fonte do Desenvolvedor nesta pesquisa. **ACEITE:** redo preservado para no-op, perdido para mutação real, sem log e incremento de revisão por no-op. 

## 4. Régua, marcações e FOV

- TEST32 limpa endpoints fora da grade, preserva medição com zoom, mantém marcações em múltiplas cenas, exige confirmação se resize excluir marcações. **Contratos executados PASS** na matriz.
- **Questão geométrica nova:** marcador visual SVG ainda é desenhado `visibility:visible` sobre célula com `fov-hidden`, `explored=false`, fora de `fovNow()`. Reproduzido com raio4, marcador sintético (6,6), origem (1,1), overlay independente e `validateWorkspace=true`. Não há padrão canônico dizendo que Mestre deva ocultar o marcador, portanto **POLÍTICA VISUAL PENDENTE**, não bug de segurança.
- **Decisão sugerida:** se FOV representar percepção de personagens, ocultar/diminuir marcações de cena fora da área visível conforme escolha do Mestre; se FOV for apenas ajuda visual do Mestre, manter visibilidade com legenda explícita. Em qualquer caso, não usar CSS ou client FOV como filtro de segredos Party e não encaminhar R205 privado para hospedagem.
- **D-INOV-032 adendo**, não novo despacho: validar com testes de estado/DOM (não só screenshots), reforçar acessibilidade e `pointer-events:none` sem substituir SVG/engine.

## 5. Testes de mutação e ambiente

**Oito mutantes em memória** detectados 8/8 (fonte original PASS no contrato e variante adulterada FAIL): aceitar aliases, ignorar colisão parede/token, apagar guard de redo, retirar guarda de régua, desativar prévia de cena alterada, aceitar marcador fora da grade, omitir normalização de perigo, desligar invalidação de cache FOV por parede. Esses são defeitos PROPOSITAIS só para medir a sensibilidade dos testes, não incidentes adicionais do produto.

**Fonte externa:** RFC 8785 (https://www.rfc-editor.org/rfc/rfc8785.html) fundamenta necessidade geral de representação JSON determinística, mas NÃO determina formato de chave espacial nem exige biblioteca JCS. JSON Schema 2020-12 (https://json-schema.org/specification) é outra referência de validação de contratos. MDN Web Storage (https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API) observa que localStorage é síncrono, sem CAS atômico; a proteção multiaba do TEST27 segue otimista. Nenhuma dependência instalada nem custo extra.

**Limitação de teste real entre abas:** a tentativa de servir fontes por `page.route` sob domínio HTTPS fictício em Chromium terminou **ERR_BLOCKED_BY_ADMINISTRATOR** ANTES do carregamento. Portanto não houve experimento válido com `localStorage` real compartilhado entre duas abas. O harness injectado é simulado. Não afirmar garantia Android multiaba.

## 6. GATES, próximos passos e anti-desvio

**PASS NAC-PASS-02 de pesquisa independente:** hashes externos, extração, 39 contratos (37 positivos, 2 falhas reproduzidas), 8 casos de import real na UI, 1.280 gerados, mutantes 8/8, POC 6/6, experimentos de inicialização. **Produto TEST32 como um todo: NÃO HOMOLOGADO**; duas falhas reais de ação sem efeito em uma classe histórica, política FOV pendente, multiaba HTTPS/Android/cânone HOLD.

**Despachos existentes e status:** D-INOV-029 migração/espacial VERIFICADA na amostra TEST32; D-INOV-030 terreno corrigido mas extensões marker/notes ainda FALHAM; D-INOV-031 régua corrigida na amostra; D-INOV-020 backup alterado agora aciona review; D-INOV-032 marcador/FOV precisa decisão UX. **Não abrir D-INOV-033 só para repetir esses achados. Nenhum ACK presumido.**

**LAST-VERIFIED-UNIT:** código TEST32 SHA autenticado + matriz 37/39 + 1.280/1.280 migração + 8/8 UI + 8/8 mutants + 6/6 POC, artefato/releitura Biblioteca e Notion a conferir após escrita.

**FIRST-PENDING:** entregar à Coordenação a extensão D-INOV-030 (marker UPDATE/notes no-op) e a decisão visual D-INOV-032 de marcador sob FOV; solicitação de patch ao Desenvolvedor por canal competente. **NEXT:** quando RUN010+ aparecer, auditá-lo com apenas testes afetados, preservando versões; quando Chrome Android estiver disponível, verificar na URL da Coordenação e duas abas reais. **NO-REPEAT:** não reexecutar 757 testes do Desenvolvedor, não substituir a engine Symmetric nem reabrir migração que passou 1.280 fixtures sem novo indício, não criar novo projeto/diário/ID, nenhum WRITE Party/O Primeiro/VLAB/GitHub/developer package.
