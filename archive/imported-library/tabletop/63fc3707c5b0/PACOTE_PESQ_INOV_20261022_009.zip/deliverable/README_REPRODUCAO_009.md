# PESQ-INOV-20261022-009 — Como reproduzir (MESTRE-SIDE/TEST)

O pacote contém SOMENTE código independente de teste, JSON sintético, resultados e relatório; NÃO contém JS, ZIP técnico, VLAB R205 real, Party, tokens privados, ROM ou assets externos.

## Pré-requisitos

- Python 3 + playwright e Chromium headless (bancada original executou Linux Chromium 144).
- Bibliotecas ZIP originais sob controle do Mestre; extraia separadamente `TABLETOP_SITE_SINTETICO_TEST29.zip` e `TABLETOP_SITE_SINTETICO_TEST32.zip` na pasta `extracted/`, cada um com index.html/app.js/styles.css.
- Para P008 baseline reproduzir original `audit_cross_layer_008.py` de `PACOTE_PESQ_INOV_20261022_008.zip` usando variável TEST26_PUBLIC_DIR apontando para TEST29.

## Scripts e denominadores

Execute da pasta da PESQ009:

```bash
python experiments/audit_test32_independent.py
python experiments/test_restore_ui_009.py
python experiments/seeded_migration_properties_009.py
python experiments/mutate_test32_copy.py
python experiments/test_legacy_startup_009.py
python experiments/poc_noop_history_patch_009.py
```

- 39 contratos TEST32: 37 PASS / 2 FAIL do produto; os dois FAIL são reais e NÃO contam como teste bem-sucedido do produto.
- Propriedades de migração: 1.280/1.280 PASS.
- Testes de importação UI: 8/8 PASS.
- Mutação: 8/8 mutantes rejeitados.
- POC RED→GREEN no-op: 6/6 provas de diferença PASS em CÓPIA.
- Inicialização e FOV: 3/3 observações confirmadas; FOV mostra questão de política, NÃO defeito de privacidade confirmado.

`page.set_content` requer desabilitar CSP SOMENTE NO TEST HARNESS e injetar armazenamento Map; isso não altera ZIP original, não é navegador Android físico e não testa site hospedado. `probe_https_same_origin_009.py` registra bloqueio administrativo de navegação e não integra o denominador PASS.

Verifique SHA dos ZIPs públicos comparando com o Relatório antes de executar. Não importe dados reais VLAB ou Party; toda fixture é sintética.
