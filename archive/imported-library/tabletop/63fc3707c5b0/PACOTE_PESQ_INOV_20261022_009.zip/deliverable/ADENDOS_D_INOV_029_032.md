# DESPACHOS — ADENDOS CIENTÍFICOS (SEM NOVOS IDs)

**D-INOV-029 — VERIFICADO TEST32 NA AMOSTRA:** rejeição de aliases, preview de migração, impedimento replay/collisions, render/caminho/terreno/FOV congruentes; 1.280/1.280 migração e 8/8 UI; não pedir implementação duplicada. Continuar regressão.

**D-INOV-030 — P1 LACUNA RESIDUAL:** marker UPDATE idêntico e sceneNotes change idêntico zeram redo no TEST32. RED reproduzido em Chromium. Proposta: igualdade antes do snap, sem gravar/revisionar/logar no-op; seis testes diferenciais RED→GREEN numa cópia em memória. Aceite: tanto redo de cenário real quanto no-op marker+notes, mutação real invalida redo, outros fluxos preservados.

**D-INOV-031 — TEST32 PASS NO RECORTE:** régua limpa endpoint fora dos limites após resize e mantém zoom. Preservar canários e confirmar no Chrome Android.

**D-INOV-020 — TEST31/32 PASS:** backup mesmo número de cenas e ID, mas conteúdo alterado, agora abre revisão; importação com normalização alias requer consentimento e cancelamento preserva origem; 8/8 UI.

**D-INOV-032 — POLÍTICA VISUAL A DECIDIR:** marcador SVG permanece visível em célula `fov-hidden`. TEST é Mestre-only; fog NÃO é barreira Party. Decidir se marcadores devem permanecer sempre visíveis para Mestre ou ocultar no modo percepção visual; não alegar falha de confidencialidade.

**Rota:** Desenvolvedor aplica mudanças somente em seu código próprio; Coordenador distribui recomendações. Nenhum ACK foi observado. Não alterar hospedagem nem dados canônicos.
