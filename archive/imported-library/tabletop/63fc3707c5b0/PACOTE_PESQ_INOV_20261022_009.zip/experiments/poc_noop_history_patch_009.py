"""Independent RED→GREEN for 2 no-op editor cases, patch applied IN MEMORY ONLY."""
import json,pathlib,hashlib
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1];d=R/'extracted'/'TABLETOP_SITE_SINTETICO_TEST32';H=(d/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"');CSS=(d/'styles.css').read_text();JS=(d/'app.js').read_text()
old='snap();s.markers[idx]={...s.markers[idx],kind:payload.kind,text:payload.text};'
new="if(s.markers[idx].kind===payload.kind&&s.markers[idx].text===payload.text){closeMarkerDialog();note('Marcação inalterada.');return;}snap();s.markers[idx]={...s.markers[idx],kind:payload.kind,text:payload.text};"
old2="if(value.length>800)return note('Nota muito longa.');snap();s.notes=value;saveLocal();"
new2="if(value.length>800)return note('Nota muito longa.');if(value===s.notes)return;snap();s.notes=value;saveLocal();"
assert JS.count(old)==1 and JS.count(old2)==1
CANDIDATE=JS.replace(old,new,1).replace(old2,new2,1)
CASES=[
 ('marker_identical_preserves_redo',"""() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'A'});a.mode('wall');a.cell(3,3);a.undo();a.openMarkerDialog(2,2);a.markerCommand('UPDATE',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'A'});a.redo();return a.scene().walls.includes('3,3');}""",False,True),
 ('notes_identical_preserves_redo',"""() => {const a=__tabletopTEST;a.mode('wall');a.cell(3,3);a.undo();document.querySelector('#sceneNotes').dispatchEvent(new Event('change',{bubbles:true}));a.redo();return a.scene().walls.includes('3,3');}""",False,True),
 ('marker_identical_is_no_mutation',"""() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'A'});a.openMarkerDialog(2,2);const before=JSON.stringify(a.state()),revision=a.state().revision;a.markerCommand('UPDATE',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'A'});return JSON.stringify(a.state())===before&&revision===a.state().revision;}""",False,True),
 ('notes_identical_is_no_mutation',"""() => {const a=__tabletopTEST;const before=JSON.stringify(a.state());document.querySelector('#sceneNotes').dispatchEvent(new Event('change',{bubbles:true}));return JSON.stringify(a.state())===before;}""",False,True),
 ('marker_changed_must_invalidate_redo',"""() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'A'});a.mode('wall');a.cell(3,3);a.undo();a.openMarkerDialog(2,2);a.markerCommand('UPDATE',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'B'});a.redo();return !a.scene().walls.includes('3,3')&&a.scene().markers[0].text==='B'&&document.querySelector('#message').textContent.includes('Nada para refazer');}""",True,True),
 ('notes_changed_must_invalidate_redo',"""() => {const a=__tabletopTEST;a.mode('wall');a.cell(3,3);a.undo();let f=document.querySelector('#sceneNotes');f.value='ALTERAÇÃO REAL';f.dispatchEvent(new Event('change',{bubbles:true}));a.redo();return !a.scene().walls.includes('3,3')&&a.scene().notes==='ALTERAÇÃO REAL';}""",True,True)
]
res=[]
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for name,probe,expectedOriginal,expectedCandidate in CASES:
  outcomes={}
  for label,code in [('BEFORE',JS),('AFTER_COPY_POC',CANDIDATE)]:
   p=br.new_page(viewport={'width':390,'height':844});p.set_content(H);p.add_style_tag(content=CSS);p.evaluate("window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__db.get(k)??null,setItem:(k,v)=>__db.set(k,String(v)),removeItem:k=>__db.delete(k)}})");p.add_script_tag(content=code)
   try:outcomes[label]=p.evaluate(probe)
   except Exception as e:outcomes[label]=str(e)[:320]
   p.close()
  okay=outcomes['BEFORE']==expectedOriginal and outcomes['AFTER_COPY_POC']==expectedCandidate
  res.append({'name':name,'baseline_expected':expectedOriginal,'candidate_expected':expectedCandidate,'observed':outcomes,'differential_pass':okay})
 br.close()
out={'experiment':'NOOP-REDO-POC-009','baseline':'TEST32 original untouched','original_js_sha256':hashlib.sha256(JS.encode()).hexdigest(),'candidate_js_sha256_in_memory':hashlib.sha256(CANDIDATE.encode()).hexdigest(),'results':res,'summary':{'total':len(res),'pass':sum(x['differential_pass'] for x in res)}};(R/'evidence'/'NOOP_REDO_RED_GREEN_009.json').write_text(json.dumps(out,indent=2,ensure_ascii=False));print(out['summary']);print([(x['name'],x['observed']) for x in res]);
