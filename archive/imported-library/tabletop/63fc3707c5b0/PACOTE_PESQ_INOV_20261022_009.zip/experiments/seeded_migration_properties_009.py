"""Seeded property probes against real TEST32 planner; no framework, no mutation of product."""
import json,pathlib,hashlib
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1];d=R/'extracted'/'TABLETOP_SITE_SINTETICO_TEST32';H=(d/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);p=b.new_page(viewport={'width':390,'height':844});p.set_content(H);p.add_style_tag(content=(d/'styles.css').read_text());p.evaluate("window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__db.get(k)??null,setItem:(k,v)=>__db.set(k,String(v)),removeItem:k=>__db.delete(k)}})");p.add_script_tag(content=(d/'app.js').read_text())
 r=p.evaluate('''() => {
   const a=__tabletopTEST, base=a.state(), errors=[],totals={}, seed=20261022;let state=seed;
   const rand=()=>{state=(Math.imul(1664525,state)+1013904223)>>>0;return state;};
   const clone=x=>JSON.parse(JSON.stringify(x));
   const groups=['SAFE','IDENTITY','DUPLICATE','CROSS_LAYER','TOKEN','FRAMES','MARKER','LEGACY'];
   const t0=performance.now();
   for(const g of groups){totals[g]={tested:0,passed:0};
    for(let i=0;i<160;i++){
     const w=clone(base),s=w.scenes[0],n=[5,7,10,20][i%4];s.n=n;s.units[2].x=n-2;
     let x,y;do{x=rand()%n;y=rand()%n;}while(s.units.some(u=>u.x===x&&u.y===y));
     const k=`${x},${y}`,alias=`00${x},00${y}`;let want='',detail={g,k,alias};
     if(g==='SAFE'||g==='MARKER'||g==='LEGACY'){s.walls=[alias];want='SAFE_NORMALIZATION';}
     else if(g==='IDENTITY'){s.walls=[k];want='NO_CHANGE';}
     else if(g==='DUPLICATE'){s.walls=[k,alias];want='CONFLICT';}
     else if(g==='CROSS_LAYER'){s.walls=[alias];s.danger=[k];want='CONFLICT';}
     else if(g==='TOKEN'){s.walls=['01,01'];want='CONFLICT';}
     else if(g==='FRAMES'){s.walls=[alias];s.frames=[{title:'Frame TEST',positions:Object.fromEntries(s.units.map(u=>[u.id,[u.x,u.y]]))}];s.frameTopology=JSON.stringify({n:s.n,walls:[],ids:s.units.map(u=>u.id).sort()});want='CONFLICT';}
     if(g==='MARKER')s.markers=[{id:'m1',x:Math.max(0,n-1),y:Math.max(0,n-1),kind:'note',text:'OWN TEST'}];
     if(g==='LEGACY'){delete s.markers;delete w.revision;}
     let before=JSON.stringify(w);const m=a.planCoordinateMigration(w);let good=m.status===want&&JSON.stringify(w)===before;
     if(g==='SAFE'||g==='MARKER'||g==='LEGACY'||g==='IDENTITY'){
      const c=m.candidate,again=c&&a.planCoordinateMigration(c);
      good=good&&Boolean(c)&&a.validateWorkspace(c)&&again?.status==='NO_CHANGE'&&JSON.stringify(again.candidate)===JSON.stringify(c);
      if(g==='MARKER')good=good&&c.scenes[0].markers[0]?.text==='OWN TEST';
      if(g==='LEGACY')good=good&&Array.isArray(c.scenes[0].markers)&&Number.isInteger(c.revision);
     }else good=good&&(!m.candidate);
     totals[g].tested++;if(good)totals[g].passed++;else if(errors.length<12)errors.push({...detail,status:m.status,reason:m.reason});
    }
   }
   return {seed,totals,failures:errors,elapsedMs:Math.round(performance.now()-t0)};
 }''')
 p.close();b.close()
out={'baseline':'TEST32 RUN009','engine':'Chromium Linux simulated localStorage, no Android','properties':r,'summary':{'tested':sum(v['tested'] for v in r['totals'].values()),'passed':sum(v['passed'] for v in r['totals'].values())}};(R/'evidence'/'SEEDED_MIGRATION_TEST32_009.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(out['summary'],'elapsed',r['elapsedMs']);print('GROUPS',r['totals']);print('failures',r['failures'][:3]);
