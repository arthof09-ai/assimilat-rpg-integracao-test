#!/usr/bin/env python3
"""Independent TEST29/TEST32 contract audit. Original public JS unmodified.
Chromium/Linux, injected map storage, synthetic fixtures; never a product patch.
"""
import json,hashlib,os,pathlib,random,sys,time
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(os.environ.get('PESQ009_HOME',str(pathlib.Path(__file__).resolve().parents[1])))
SOURCES=ROOT/'extracted'
OUT=ROOT/'evidence'/'TEST32_CONTRACT_MATRIX_009.json'
DIR=SOURCES/'TABLETOP_SITE_SINTETICO_TEST32'
HTML=(DIR/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
CSS=(DIR/'styles.css').read_text();JS=(DIR/'app.js').read_text();SHA=hashlib.sha256(JS.encode()).hexdigest()
CASES=[]
def record(name, expected, observed, detail=None):
    CASES.append({'id':name,'expected':expected,'observed':observed,'pass':expected==observed,'detail':detail})
def setup(browser,w=390,h=844):
    p=browser.new_page(viewport={'width':w,'height':h},accept_downloads=True)
    p.set_content(HTML);p.add_style_tag(content=CSS)
    p.evaluate("""() => {window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db.get(k)??null,setItem:(k,v)=>window.__db.set(k,String(v)),removeItem:k=>window.__db.delete(k)}});window.confirm=()=>true;}""")
    p.add_script_tag(content=JS);return p

def case(browser, name, code, expected=True):
    p=setup(browser)
    try:
      v=p.evaluate(code)
      ok=v.get('ok') if isinstance(v,dict) else v
      record(name,expected,ok,v)
    except Exception as e:
      record(name,expected,'EXCEPTION',str(e)[:550])
    finally:p.close()

with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    # CRITICAL: latest validator must reject noncanonical coordinates BEFORE state mutations.
    for layer in ('walls','danger','terrain','explored'):
      setter={'walls':"s.walls=['02,01'];",'danger':"s.danger=['02,01'];",'terrain':"s.terrain={'02,01':'water'};",'explored':"s.explored=['02,01'];"}[layer]
      case(browser,'reject_padded_'+layer,f'''() => {{const a=__tabletopTEST,w=a.state(),s=w.scenes[0];{setter}return {{ok:!a.validateWorkspace(w),layer:{json.dumps(layer)}}};}}''')
    case(browser,'reject_double_aliases',"""() => {let w=__tabletopTEST.state();w.scenes[0].walls=['2,2','002,002'];return {ok:!__tabletopTEST.validateWorkspace(w)};}""")
    case(browser,'reject_cross_layer_alias',"""() => {let w=__tabletopTEST.state();w.scenes[0].walls=['2,2'];w.scenes[0].danger=['02,02'];return {ok:!__tabletopTEST.validateWorkspace(w)};}""")
    case(browser,'reject_wall_on_unit_alias',"""() => {let w=__tabletopTEST.state();w.scenes[0].walls=['01,01'];return {ok:!__tabletopTEST.validateWorkspace(w)};}""")
    case(browser,'reject_direct_restore_and_preserve_ram',"""() => {let a=__tabletopTEST,w=a.state(),before=JSON.stringify(w);w.scenes[0].walls=['02,01'];let error='';try{a.restoreCandidate(w)}catch(e){error=e.storageStatus||e.message}return {ok:error==='FAILED_CONFIRMED'&&JSON.stringify(a.state())===before&&a.validateWorkspace(a.state()),error};}""")
    case(browser,'planner_normalizes_single_wall',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,01'];let orig=JSON.stringify(w),m=a.planCoordinateMigration(w);return {ok:m.status==='SAFE_NORMALIZATION'&&m.changes===1&&m.candidate.scenes[0].walls[0]==='2,1'&&JSON.stringify(w)===orig,status:m.status,changes:m.changes};}""")
    case(browser,'safe_migration_persists_and_renders_wall',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,01'];let m=a.planCoordinateMigration(w);let committed=a.restoreCandidate(m.candidate);return {ok:committed&&a.validateWorkspace(a.state())&&document.querySelector('[data-xy="2,1"]').classList.contains('wall')&&a.state().scenes[0].walls[0]==='2,1'&&window.__db.size===1};}""")
    case(browser,'safe_migration_blocks_real_path',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,01'];a.restoreCandidate(a.planCoordinateMigration(w).candidate);a.mode('play');a.cell(2,1);return {ok:!(a.scene().units[0].x===2&&a.scene().units[0].y===1),message:document.querySelector('#message').textContent};}""")
    case(browser,'safe_migration_danger_warning',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].danger=['02,01'];a.restoreCandidate(a.planCoordinateMigration(w).candidate);a.mode('play');a.cell(2,1);return {ok:a.scene().logs.some(x=>x.includes('Terreno perigoso não resolvido'))};}""")
    case(browser,'safe_migration_terrain_visual',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].terrain['02,01']='water';a.restoreCandidate(a.planCoordinateMigration(w).candidate);return {ok:document.querySelector('[data-xy="2,1"]').classList.contains('ground-water')};}""")
    case(browser,'safe_migration_fov_wall_barrier',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=Array.from({length:7},(_,y)=>`02,0${y}`);let m=a.planCoordinateMigration(w);a.restoreCandidate(m.candidate);return {ok:!a.shadowcast({x:1,y:2,radius:8}).includes('3,2'),status:m.status};}""")
    case(browser,'safe_migration_explored',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].explored=['02,02'];let m=a.planCoordinateMigration(w);a.restoreCandidate(m.candidate);return {ok:a.scene().explored.includes('2,2')&&!a.scene().explored.includes('02,02')};}""")
    case(browser,'safe_migration_idempotent',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].danger=['02,01'];let m=a.planCoordinateMigration(w),again=a.planCoordinateMigration(m.candidate);return {ok:m.status==='SAFE_NORMALIZATION'&&again.status==='NO_CHANGE'&&again.changes===0};}""")
    case(browser,'collision_wall_semantic_duplicates_blocked',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,02','2,2'];let before=JSON.stringify(w),m=a.planCoordinateMigration(w);return {ok:m.status==='CONFLICT'&&!('candidate' in m)&&JSON.stringify(w)===before,status:m.status};}""")
    case(browser,'collision_cross_layer_blocked',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,02'];w.scenes[0].danger=['2,2'];let m=a.planCoordinateMigration(w);return {ok:m.status==='CONFLICT',status:m.status};}""")
    case(browser,'collision_wall_unit_blocked',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['01,01'];let m=a.planCoordinateMigration(w);return {ok:m.status==='CONFLICT',status:m.status};}""")
    case(browser,'topology_replay_changed_wall_requires_review',"""() => {const a=__tabletopTEST;a.capture();let w=a.state();w.scenes[0].walls=['02,02'];let m=a.planCoordinateMigration(w);return {ok:m.status==='CONFLICT'&&m.reason.includes('Replay'),status:m.status};}""")
    case(browser,'topology_replay_explored_normalize_allowed',"""() => {const a=__tabletopTEST;a.capture();let w=a.state();w.scenes[0].explored=['02,02'];let m=a.planCoordinateMigration(w);return {ok:m.status==='SAFE_NORMALIZATION'&&m.candidate.scenes[0].frames.length===w.scenes[0].frames.length,status:m.status};}""")
    case(browser,'legacy_test26_absent_markers_migrated',"""() => {const a=__tabletopTEST,w=a.state();delete w.scenes[0].markers;w.scenes[0].walls=['02,01'];let m=a.planCoordinateMigration(w);return {ok:m.status==='SAFE_NORMALIZATION'&&Array.isArray(m.candidate.scenes[0].markers)&&m.candidate.scenes[0].markers.length===0};}""")
    case(browser,'migrate_with_markers_preserves_data',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,01'];w.scenes[0].markers=[{id:'m1',x:3,y:3,kind:'note',text:'TAG TEST'}];let m=a.planCoordinateMigration(w);a.restoreCandidate(m.candidate);return {ok:a.scene().markers.length===1&&a.scene().markers[0].text==='TAG TEST'&&a.validateWorkspace(a.state())};}""")
    case(browser,'migrate_multiple_scenes_isolated',"""() => {const a=__tabletopTEST,w=a.state();let s=JSON.parse(JSON.stringify(w.scenes[0]));s.id='c2';s.name='Cena 2 TEST';s.walls=['02,01'];w.scenes.push(s);let m=a.planCoordinateMigration(w);a.restoreCandidate(m.candidate);return {ok:a.state().scenes.length===2&&a.state().scenes[0].walls.length===0&&a.state().scenes[1].walls[0]==='2,1'};}""")
    case(browser,'invalid_unrelated_marker_blocks_migration',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].walls=['02,01'];w.scenes[0].markers=[{id:'m1',x:999,y:999,kind:'pin',text:'BAD'}];let m=a.planCoordinateMigration(w);return {ok:m.status==='CONFLICT',status:m.status};}""")
    case(browser,'redo_after_erase_noop_preserved',"""() => {const a=__tabletopTEST;a.mode('wall');a.cell(2,2);a.undo();a.mode('erase');a.cell(4,4);a.redo();return {ok:a.scene().walls.includes('2,2')};}""")
    case(browser,'redo_after_wall_real_change_invalidated',"""() => {const a=__tabletopTEST;a.mode('wall');a.cell(2,2);a.undo();a.mode('wall');a.cell(3,3);a.redo();return {ok:a.scene().walls.length===1&&a.scene().walls[0]==='3,3'&&document.querySelector('#message').textContent.includes('Nada para refazer')};}""")
    case(browser,'ruler_shrink_clears_endpoints',"""() => {const a=__tabletopTEST;a.resize(20);a.mode('measure');a.cell(15,15);a.cell(19,19);a.resize(7);let r=a.ruler();return {ok:a.scene().n===7&&r.start===null&&r.end===null,ruler:r};}""")
    case(browser,'ruler_zoom_preserves_valid_geometry',"""() => {const a=__tabletopTEST;a.mode('measure');a.cell(2,2);a.cell(4,5);a.zoom(68);let r=a.ruler();return {ok:r.start.x===2&&r.end.y===5&&r.text.includes('Manhattan 5 casas')};}""")
    case(browser,'marker_undo_redo_basic',"""() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'marker A'});let made=a.scene().markers.length;a.undo();let undone=a.scene().markers.length;a.redo();return {ok:made===1&&undone===0&&a.scene().markers.length===1};}""")
    case(browser,'marker_scene_copy_retains_own_copy',"""() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'marker A'});a.copyScene();let w=a.state();return {ok:w.scenes.length===2&&w.scenes[0].markers[0].text==='marker A'&&w.scenes[1].markers[0].text==='marker A'&&w.scenes[0].markers!==w.scenes[1].markers};}""")
    case(browser,'marker_resize_confirms_loss_and_can_cancel',"""() => {const a=__tabletopTEST;a.resize(20);a.markerCommand('ADD',{x:15,y:15,sceneId:'c1'},{kind:'pin',text:'marker A'});window.confirm=()=>false;a.resize(7);return {ok:a.scene().n===20&&a.scene().markers.length===1};}""")
    case(browser,'marker_resize_confirm_removes_outside',"""() => {const a=__tabletopTEST;a.resize(20);a.markerCommand('ADD',{x:15,y:15,sceneId:'c1'},{kind:'pin',text:'marker A'});window.confirm=()=>true;a.resize(7);return {ok:a.scene().n===7&&a.scene().markers.length===0};}""")
    case(browser,'changed_same_scene_review_required',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].notes='Outra versao';let v=a.restoreReview(w);return {ok:v.changedCount===1&&v.requiresReview===true,review:v};}""")
    case(browser,'changed_only_marker_review_required',"""() => {const a=__tabletopTEST,w=a.state();w.scenes[0].markers.push({id:'m1',x:2,y:2,kind:'pin',text:'marker A'});let v=a.restoreReview(w);return {ok:v.changedCount===1&&v.requiresReview===true,review:v};}""")
    # Hypothesis: no-op marker UPDATE also must preserve redo (same semantic contract as TEST31 terrain fix).
    case(browser,'marker_update_identical_does_not_drop_redo',"""() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'mark A'});a.mode('wall');a.cell(3,3);a.undo();a.openMarkerDialog(2,2);a.markerCommand('UPDATE',{x:2,y:2,sceneId:'c1'},{kind:'pin',text:'mark A'});a.redo();return {ok:a.scene().walls.includes('3,3'),message:document.querySelector('#message').textContent,markers:a.scene().markers};}""")
    case(browser,'scene_notes_identical_does_not_drop_redo',"""() => {const a=__tabletopTEST;a.mode('wall');a.cell(3,3);a.undo();document.querySelector('#sceneNotes').dispatchEvent(new Event('change',{bubbles:true}));a.redo();return {ok:a.scene().walls.includes('3,3'),message:document.querySelector('#message').textContent};}""")
    # Deterministic generation: 200 valid + 200 noncanonical, dynamically validate without restoration.
    p=setup(browser)
    rng=random.Random(20261022);stats={'canonical_total':0,'canonical_accepted':0,'aliased_total':0,'aliased_rejected':0}
    for i in range(400):
      n=[5,7,10,20][i%4];x=rng.randrange(n);y=rng.randrange(n)
      if (x,y) in [(1,1),(1,3),(n-2,2)]:continue
      noncanonical=i%2==1
      k=f'0{x},0{y}' if noncanonical else f'{x},{y}'
      result=p.evaluate("""v=>{let w=__tabletopTEST.state();w.scenes[0].n=v.n;w.scenes[0].units[2].x=v.n-2;w.scenes[0].walls=[v.key];return __tabletopTEST.validateWorkspace(w)}""",{'n':n,'key':k})
      if noncanonical:
        stats['aliased_total']+=1;stats['aliased_rejected']+=not result
      else:
        stats['canonical_total']+=1;stats['canonical_accepted']+=bool(result)
    p.close()
    record('generated_alias_keys_all_rejected',stats['aliased_total'],stats['aliased_rejected'],stats)
    record('generated_canonical_keys_all_accepted',stats['canonical_total'],stats['canonical_accepted'],stats)
    browser.close()
record_obj={'research':'PESQ-INOV-20261022-009','version':'TEST32/RUN009','app_js_sha256':SHA,'engine':'Chromium '+str(browser.version),'fixture':'Synthetic only; Linux headless 390x844; localStorage Map injected; CSP disabled only in harness','cases':CASES,'summary':{'total':len(CASES),'pass':sum(x['pass'] for x in CASES),'fail':sum(not x['pass'] for x in CASES)},'generated':stats}
OUT.write_text(json.dumps(record_obj,ensure_ascii=False,indent=2))
print('SUMMARY',record_obj['summary'],'GENERATED',stats)
for item in CASES:
    if not item['pass']:print('PRODUCT CONTRACT FAIL:',item['id'],str(item['detail'])[:240])
