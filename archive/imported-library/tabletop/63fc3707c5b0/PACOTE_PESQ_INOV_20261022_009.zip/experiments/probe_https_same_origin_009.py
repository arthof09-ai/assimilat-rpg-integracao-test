from pathlib import Path
from playwright.sync_api import sync_playwright
D=Path('/mnt/data/pesq_inov_009/extracted/TABLETOP_SITE_SINTETICO_TEST32')
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);ctx=br.new_context();
 def route(r):
  path=r.request.url.split('?')[0].split('/')[-1] or 'index.html'
  if path not in ('index.html','app.js','styles.css'):r.fulfill(status=404,body='not found');return
  ct='text/html' if path.endswith('html') else 'text/javascript' if path.endswith('js') else 'text/css'
  r.fulfill(status=200,content_type=ct,body=(D/path).read_bytes())
 ctx.route('https://tabletop-synthetic.test/**',route)
 page=ctx.new_page()
 try:
  resp=page.goto('https://tabletop-synthetic.test/index.html',wait_until='load',timeout=10000)
  print('NAV_OK',resp.status,'TITLE',page.title(),'LOCAL_STORAGE',page.evaluate('localStorage.length'),'GRID',page.locator('[data-xy]').count())
  pg2=ctx.new_page();pg2.goto('https://tabletop-synthetic.test/index.html',wait_until='load',timeout=10000)
  print('PAGE2_OK',pg2.title(),pg2.evaluate('localStorage.length'))
 except Exception as e:print('UNAVAILABLE',type(e).__name__,str(e)[:450])
 br.close()
