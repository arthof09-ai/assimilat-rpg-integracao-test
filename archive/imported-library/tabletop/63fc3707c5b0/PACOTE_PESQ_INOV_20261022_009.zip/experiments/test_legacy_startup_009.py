"""Actual TEST32 startup recovery with simulated localStorage (not Android / storage real)."""
import json,pathlib
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1];d=R/'extracted'/'TABLETOP_SITE_SINTETICO_TEST32';H=(d/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"');CSS=(d/'styles.css').read_text();JS=(d/'app.js').read_text();tests=[]
def page(b,raw=None):
 p=b.new_page(viewport={'width':390,'height':844},accept_downloads=True);p.set_content(H);p.add_style_tag(content=CSS);p.evaluate('''raw=> {window.__db=new Map();if(raw!==null)__db.set('assim.tabletop.synthetic.workspace.v1',raw);Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__db.get(k)??null,setItem:(k,v)=>__db.set(k,String(v)),removeItem:k=>__db.delete(k)}});window.confirm=()=>true;}''',raw);p.add_script_tag(content=JS);return p
def probe(p):return p.evaluate('''() => ({conflict:__tabletopTEST.externalConflict(),work:__tabletopTEST.state(),stored:Array.from(__db.values()),banner:document.querySelector('#storageConflictInfo').textContent,notes:document.querySelector('#message').textContent})''')
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=page(b);base=p.evaluate('__tabletopTEST.state()');p.close()
 for label,w,expect_status in [('legacy_padded_wall',dict(base),'EXTERNAL_AVAILABLE'),('collision_alias_wall',dict(base),'INVALID_EXTERNAL')]:
  w=json.loads(json.dumps(w));w['scenes'][0]['walls']=['02,01'] if label=='legacy_padded_wall' else ['2,2','02,02'];orig=json.dumps(w,ensure_ascii=False)
  p=page(b,orig);initial=probe(p);status=p.evaluate('__tabletopTEST.inspectReconcile()');mid=probe(p);okay=initial['conflict'] and initial['stored'][0]==orig and status==expect_status
  if label=='legacy_padded_wall':
   adopted=p.evaluate('__tabletopTEST.adoptReconciled()');after=probe(p)
   okay=okay and adopted and after['work']['scenes'][0]['walls']==['2,1'] and json.loads(after['stored'][0])['scenes'][0]['walls']==['2,1'] and not after['conflict']
   detail={'initial_conflict':initial['conflict'],'reconcile':status,'adopted':adopted,'after_walls':after['work']['scenes'][0]['walls']}
  else:
   adopted=p.evaluate('__tabletopTEST.adoptReconciled()');after=probe(p);okay=okay and not adopted and after['stored'][0]==orig and after['conflict']
   detail={'initial_conflict':initial['conflict'],'reconcile':status,'adopted':adopted,'unchanged':after['stored'][0]==orig}
  tests.append({'id':label,'pass':bool(okay),'detail':detail});p.close()
 p=page(b);v=p.evaluate('''() => {const a=__tabletopTEST;a.markerCommand('ADD',{x:6,y:6,sceneId:'c1'},{kind:'note',text:'OUTSIDE FOV TEST'});const radius=document.querySelector('#fovRadius');radius.value='4';radius.dispatchEvent(new Event('change',{bubbles:true}));let f=document.querySelector('#layerFov');f.checked=true;f.dispatchEvent(new Event('change',{bubbles:true}));const m=document.querySelector('#markerOverlay .visual-mark'),tile=document.querySelector('[data-xy="6,6"]');return {hiddenTile:tile.classList.contains('fov-hidden'),unexplored:!a.scene().explored.includes('6,6'),graphicVisible:getComputedStyle(m).visibility==='visible',markerCount:a.scene().markers.length,valid:a.validateWorkspace(a.state()),inVision:a.fovNow()?.includes('6,6')};}''');tests.append({'id':'marker_overlay_visually_visible_beyond_FOV','pass':v['hiddenTile'] and v['unexplored'] and v['graphicVisible'] and v['valid'],'detail':v,'classification':'UX_POLICY_UNRESOLVED_NOT_SECURITY'});p.close()
 b.close()
record={'baseline':'TEST32/RUN009','scope':'Chromium 144 Linux / synthetic localStorage, no actual Android','tests':tests,'summary':{'total':len(tests),'observations_confirmed':sum(v['pass'] for v in tests)}};(R/'evidence'/'STARTUP_AND_FOV_TEST32_009.json').write_text(json.dumps(record,indent=2,ensure_ascii=False));print(record['summary']);print(json.dumps(tests,ensure_ascii=False,indent=2))
