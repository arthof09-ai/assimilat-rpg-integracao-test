"""Eight targeted mutations ONLY in in-memory TEST32 JS copies; never change source."""
import hashlib,json,pathlib
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];d=ROOT/'extracted'/'TABLETOP_SITE_SINTETICO_TEST32'
H=(d/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"');CSS=(d/'styles.css').read_text();JS=(d/'app.js').read_text()
mutants=[
 {'id':'CANONICAL_ALIAS_VALIDATION','old':'Boolean(p&&key===p.key)','new':'Boolean(p)','check':"""() => {let w=__tabletopTEST.state();w.scenes[0].walls=['02,01'];return !__tabletopTEST.validateWorkspace(w)}"""},
 {'id':'WALL_UNIT_COLLISION','old':'!isCanonicalCoord(key,s.n)||where.has(key)','new':'!isCanonicalCoord(key,s.n)||false','check':"""() => {let w=__tabletopTEST.state();w.scenes[0].walls=['1,1'];return !__tabletopTEST.validateWorkspace(w)}"""},
 {'id':'NOOP_REDO_GUARD','old':'future=redoBeforeNoop;return;','new':'future=[];return;','check':"""() => {const a=__tabletopTEST;a.mode('wall');a.cell(2,2);a.undo();a.mode('erase');a.cell(4,4);a.redo();return a.scene().walls.includes('2,2')}"""},
 {'id':'RULER_BOUND_GUARD','old':'if(rulerSceneId!==s.id||rulerA&&!inside(rulerA.x,rulerA.y,s.n)||rulerB&&!inside(rulerB.x,rulerB.y,s.n))','new':'if(rulerSceneId!==s.id)','check':"""() => {const a=__tabletopTEST;a.resize(20);a.mode('measure');a.cell(15,15);a.cell(19,19);a.resize(7);return a.ruler().start===null&&a.ruler().end===null;}"""},
 {'id':'SAME_ID_CHANGED_BACKUP_REVIEW','old':'removed.length>0||changed.length>0','new':'removed.length>0','check':"""() => {let w=__tabletopTEST.state();w.scenes[0].notes='Changed';return __tabletopTEST.restoreReview(w).requiresReview===true;}"""},
 {'id':'MARKER_OUTSIDE_GRID','old':'!inside(m.x,m.y,s.n)||','new':'false||','check':"""() => {let w=__tabletopTEST.state();w.scenes[0].markers=[{id:'m1',x:99,y:99,kind:'pin',text:'TEST'}];return !__tabletopTEST.validateWorkspace(w);}"""},
 {'id':'DANGER_NORMALIZATION','old':"for(const prop of ['walls','danger','explored'])","new":"for(const prop of ['walls','explored'])",'check':"""() => {let a=__tabletopTEST,w=a.state();w.scenes[0].danger=['02,01'];let m=a.planCoordinateMigration(w);return m.status==='SAFE_NORMALIZATION'&&m.candidate.scenes[0].danger[0]==='2,1'}"""},
 {'id':'FOV_CACHE_WALL_KEY','old':'[...s.walls].sort()]); // topology fingerprint','new':'[]]); // topology fingerprint','check':"""() => {const a=__tabletopTEST;let w=a.state();w.scenes[0].fovEnabled=true; a.restoreCandidate(w);let before=a.fovNow().includes('3,1');a.mode('wall');a.cell(2,1);let after=a.fovNow().includes('3,1');return !after||!before;}"""}
]
results=[]
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for m in mutants:
  assert JS.count(m['old'])==1,(m['id'],JS.count(m['old']))
  def evaluate(code):
   p=br.new_page(viewport={'width':390,'height':844});p.set_content(H);p.add_style_tag(content=CSS);p.evaluate("""() => {window.__db=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db.get(k)??null,setItem:(k,v)=>window.__db.set(k,String(v)),removeItem:k=>window.__db.delete(k)}});window.confirm=()=>true;}""");p.add_script_tag(content=code)
   try: v=p.evaluate(m['check']);return {'value':v,'error':None}
   except Exception as e:return {'value':False,'error':str(e)[:240]}
   finally:p.close()
  base=evaluate(JS);corrupt=evaluate(JS.replace(m['old'],m['new'],1));killed=base['value'] is True and corrupt['value'] is not True
  results.append({'id':m['id'],'baseline':base,'mutant':corrupt,'detected':killed,'scope':'in-memory copy only'})
 br.close()
out={'baseline':'TEST32 RUN009','source_sha256':hashlib.sha256(JS.encode()).hexdigest(),'mutants':results,'summary':{'total':len(results),'detected':sum(v['detected'] for v in results)}}
(ROOT/'evidence'/'MUTATION_TEST32_009.json').write_text(json.dumps(out,indent=2,ensure_ascii=False));print(out['summary']);
for t in results:print(t['id'],t['detected'],t['baseline'],t['mutant'])
