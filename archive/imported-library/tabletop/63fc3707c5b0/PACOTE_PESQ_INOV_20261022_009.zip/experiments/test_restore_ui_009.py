"""Browser-level UI restore, no real files or RPG data. Independent TEST32 import QA."""
import json,pathlib,hashlib
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1];D=R/'extracted'/'TABLETOP_SITE_SINTETICO_TEST32';H=(D/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"');CSS=(D/'styles.css').read_text();JS=(D/'app.js').read_text();CASES=[]
def put(i,condition,data):CASES.append({'case':i,'pass':bool(condition),'observed':data})
def page(b):
 p=b.new_page(viewport={'width':390,'height':844},accept_downloads=True);p.set_content(H);p.add_style_tag(content=CSS);p.evaluate("""() => {window.__db = new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__db.get(k)??null,setItem:(k,v)=>__db.set(k,String(v)),removeItem:k=>__db.delete(k)}});window.confirm=()=>true;}""");p.add_script_tag(content=JS);return p
def import_json(p,obj):
 p.locator('#restore').set_input_files({'name':'fixture_sintetica.json','mimeType':'application/json','buffer':json.dumps(obj,ensure_ascii=False).encode()})
 p.wait_for_timeout(60)
def check(p):return p.evaluate("""() => ({review:!document.querySelector('#restoreReview').hidden,summary:document.querySelector('#restoreReviewSummary').textContent,message:document.querySelector('#message').textContent,state:__tabletopTEST.state(),saved:Array.from(__db.values()),storage:document.querySelector('#storageStatus').textContent})""")
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=page(b);raw=p.evaluate('''() => __tabletopTEST.state()''');raw['scenes'][0]['walls']=['02,01'];import_json(p,raw);v=check(p)
 put('legacy_wall_opens_explicit_review',v['review'] and 'normalizadas' in v['summary'] and '1 chave' in v['summary'],{'review':v['review'],'summary':v['summary']})
 p.locator('#restoreReviewCancel').click();v=check(p)
 put('cancel_migration_preserves_original',not v['review'] and not v['state']['scenes'][0]['walls'] and v['saved']==[],{'storage':v['storage'],'walls':v['state']['scenes'][0]['walls']});p.close()
 p=page(b);raw=p.evaluate('''() => __tabletopTEST.state()''');raw['scenes'][0]['walls']=['02,01'];import_json(p,raw);p.locator('#restoreReviewConfirm').click();v=check(p);k=v['state']['scenes'][0]['walls'];saved=json.loads(v['saved'][0]) if v['saved'] else {}
 put('confirm_migration_normalizes_and_persists',k==['2,1'] and saved.get('scenes',[{}])[0].get('walls')==['2,1'] and bool(p.locator('[data-xy="2,1"]').get_attribute('class') and 'wall' in p.locator('[data-xy="2,1"]').get_attribute('class')),{'walls':k,'revision':saved.get('revision')});
 # Cold readback: create isolated new page with exact saved string preinstalled.
 snap=v['saved'][0];p.close();p=page(b);p.evaluate('''raw => {let key='assim.tabletop.synthetic.workspace.v1';__db.set(key,raw)}''',snap);
 # Fresh content+script in same test harness after installing state before JS initialization
 p2=b.new_page(viewport={'width':390,'height':844});p2.set_content(H);p2.add_style_tag(content=CSS);p2.evaluate('''raw => {window.__db=new Map([['assim.tabletop.synthetic.workspace.v1',raw]]);Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__db.get(k)??null,setItem:(k,v)=>__db.set(k,String(v)),removeItem:k=>__db.delete(k)}})}''',snap);p2.add_script_tag(content=JS);q=p2.evaluate('''() => ({walls:__tabletopTEST.state().scenes[0].walls,status:document.querySelector('#storageStatus').textContent})''');put('cold_reload_migration_persists',q['walls']==['2,1'],q);p.close();p2.close()
 p=page(b);raw=p.evaluate('''() => __tabletopTEST.state()''');raw['scenes'][0]['walls']=['2,2','02,02'];import_json(p,raw);v=check(p);put('collision_backup_rejected_without_mutation',not v['review'] and v['state']['scenes'][0]['walls']==[] and not v['saved'] and 'incompatível' in v['message'],{'message':v['message']});p.close()
 p=page(b);p.evaluate('''() => __tabletopTEST.capture()''');raw=p.evaluate('''() => __tabletopTEST.state()''');raw['scenes'][0]['walls']=['02,02'];import_json(p,raw);v=check(p);put('replay_topology_requires_manual_review',not v['review'] and 'Replay' in v['message'] and v['state']['scenes'][0]['walls']==[],{'message':v['message']});p.close()
 p=page(b);raw=p.evaluate('''() => __tabletopTEST.state()''');raw['scenes'][0]['markers'].append({'id':'m1','x':2,'y':2,'kind':'pin','text':'NEW MARKER'});import_json(p,raw);v=check(p);put('marker_only_change_requires_review',v['review'] and '1 seriam alteradas' in v['summary'],{'summary':v['summary']});p.close()
 p=page(b);raw=p.evaluate('''() => __tabletopTEST.state()''');raw['scenes'][0]['danger']=['02,01'];import_json(p,raw);p.evaluate('''() => {localStorage.setItem=(k,v)=>{throw new DOMException('storage full','QuotaExceededError')}}''');p.locator('#restoreReviewConfirm').click();v=check(p);put('quota_rejects_migration_without_ui_success',v['state']['scenes'][0]['danger']==[] and not v['saved'] and 'rejeitado' in v['message'].lower(),{'message':v['message'],'storage':v['storage']});p.close()
 b.close()
out={'scope':'TEST32 RUN009; Chromium/Linux synthetic localStorage; no Android physical','cases':CASES,'summary':{'total':len(CASES),'pass':sum(x['pass'] for x in CASES),'fail':sum(not x['pass'] for x in CASES)}};(R/'evidence'/'RESTORE_UI_TEST32_009.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(out['summary']);
for v in CASES:print(v['case'],v['pass'],str(v['observed'])[:150]);
