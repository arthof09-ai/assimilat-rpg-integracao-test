/* TEST40 DEV-only add-on to the ORIGINAL Codex 0.4 transport. Served from
 * its loopback origin, not by the public or offline build. Browser fetch() is
 * the sole sender; Playwright is NOT a request transport. NO REAL CREDENTIALS.
 * VLAB mechanics unavailable; only the original Authority/SQLite replies.
 */
(()=>{'use strict';
 const client=window.TabletopRoomTEST?.client;
 const A=window.__tabletopTEST;
 const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&
   !!client && !!A && typeof window.PonteTEST?.request==='function';
 if(!enabled)return;
 const PROFILE='p1';
 const ROOM='arena-test';
 const TOKEN='FAKE_TEST_PLAYER1';// Explicitly synthetic, never user auth.
 const SCOPE=Object.freeze({roomId:ROOM,principalId:PROFILE});
 let loseAck=false;
 let fatalJournal=false;
 let ready=false;
 const mark=(s)=>{const el=document.getElementById('connected40Status');if(el)el.textContent=s;};
 const b=document.createElement('p');b.id='connected40Status';b.setAttribute('role','status');
 b.textContent='TEST40 conectado somente a 127.0.0.1 · credenciais FAKE · VLAB indisponível.';
 const heading=document.getElementById('roomHeading');if(heading)heading.textContent='🌐 Sala HTTP LOCAL TEST40 — identidades FAKE';
 const notice=document.getElementById('roomModeNotice');if(notice)notice.textContent='TRANSPORTE HTTP nativo TEST: 127.0.0.1, credenciais FAKE, sem mecânica VLAB.';
 const banner=document.getElementById('bridgeImport')?.parentElement;
 if(banner)banner.append(b);
 // Codex0.4 pins a TEST38 synthetic fixture provenance. Its hash is NOT a
 // hash of the TEST40 frontend. Permit import ONLY for the byte-semantically
 // equivalent untouched TEST synthetic geometry; reject edited scenes.
 const referenceScene=()=>{
  const scene=A.scene();
  const expected=[['u1','Exploradora TEST','E','ally',1,1],['u2','Conjurador TEST','C','ally',1,3],['u3','Criatura TEST','X','enemy',5,2]];
  return scene?.id==='c1'&&scene.n===7&&Array.isArray(scene.walls)&&scene.walls.length===0&&Array.isArray(scene.danger)&&scene.danger.length===0&&Object.keys(scene.terrain||{}).length===0&&
    Array.isArray(scene.markers)&&scene.markers.length===0&&Array.isArray(scene.units)&&scene.units.length===3&&
    expected.every(([id,name,mark,team,x,y])=>scene.units.some(u=>u.id===id&&u.name===name&&u.mark===mark&&u.team===team&&u.x===x&&u.y===y));
 };
 const importButton=document.getElementById('bridgeImport');
 if(importButton)importButton.addEventListener('click',event=>{
  if(!referenceScene()){event.preventDefault();event.stopImmediatePropagation();
   const feedback=document.getElementById('bridgeResult');
   if(feedback)feedback.textContent='IMPORTAÇÃO BLOQUEADA: a ponte 0.4 só reconhece a geometria sintética de referência TEST38. Faça backup e use a cena TEST limpa; não atribua seu mapa editado ao hash antigo.';}
 },true);
 // Use EXACTLY the existing RoomClient outbox/journal key and JSON v1 format.
 try{
  const old=window.sessionStorage.getItem(client.journalKey);
  const now=window.localStorage.getItem(client.journalKey);
  if(old!==null&&now===null){
   const obj=JSON.parse(old);
   if(!obj||!Array.isArray(obj.entries)||obj.entries.length||obj.external)throw Error('session-journal-has-pending');
  }
  client.journalStore=window.localStorage;
  client.loadJournal();
  if(client.journalError)throw Error('journal-unverified');
  ready=true;
 }catch(_err){fatalJournal=true;mark('TEST40 BLOQUEADO: journal local indisponível/ambíguo. Exporte o estado e não tente outra intenção.');}
 const idValid=v=>typeof v==='string'&&/^[a-z][a-z0-9_-]{0,31}$/.test(v);
 const requestValid=r=>r&&Object.keys(r).sort().join(',')==='action,actorId,commandId,sceneId,targetId'&&
  r.action==='ATTACK_REQUEST'&&r.actorId==='u1'&&r.targetId==='u3'&&r.sceneId==='c1'&&idValid(r.commandId);
 const packet=async(body)=>{
  // This fetch is executed by browser JavaScript and is SAME-ORIGIN only.
  const res=await fetch('/bridge',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+TOKEN},body:JSON.stringify(body),cache:'no-store'});
  const raw=await res.text();if(raw.length>65536)throw Error('response-too-large');
  const out=JSON.parse(raw);
  if(!res.ok||!out||out.ok!==true)throw Error('unverified-bridge-response');
  return out;
 };
 const receipt=(out,id)=>{
  if(out.lookup==='NOT_FOUND')return {commandId:id,status:'NOT_FOUND',scope:SCOPE};
  const r=out.receipt;
  // Until VLAB ABI is homologated, ATTACK_REQUEST can NEVER be APPLIED.
  // An ACCEPTED receipt may belong to a DIFFERENT synthetic operation with
  // the same room/principal/ID: refuse to call it a confirmed attack.
  if(r?.status==='ACCEPTED')throw Error('ATTACK_NOT_AVAILABLE_ACCEPTED_OTHER_OPERATION');
  if(!r||r.client_action_id!==id||r.status!=='REJECTED'||typeof r.code!=='string'||
     !Number.isSafeInteger(r.revision)||typeof r.receipt_id!=='string')throw Error('malformed-authority-receipt');
  if(r.status==='REJECTED'&&!['MECHANICS_UNAVAILABLE','FORBIDDEN','STALE_REVISION','ID_REUSE_CONFLICT','UNKNOWN_EFFECT'].includes(r.code))throw Error('unrecognized-receipt-reason');
  return {commandId:id,status:r.status,code:r.code,revision:r.revision,receiptId:r.receipt_id,scope:SCOPE};
 };
 const newId=()=>{
  const bytes=new Uint8Array(10);crypto.getRandomValues(bytes);
  return 'atk40_'+Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
 };
 const sessionReady=()=>ready&&!fatalJournal&&client.profile===PROFILE&&client.protocol==='v2'&&client.connected&&client.selfId===PROFILE&&client.role==='player'&&client.roomId===ROOM&&!client.journalError;
 const pendingInScope=(id)=>{const e=client.externalRecord();return Boolean(e&&e.profile===PROFILE&&e.payload.commandId===id&&client.sameExternalScope(e.scope,SCOPE));};
 const port={
  scope:SCOPE,canQuery:()=>sessionReady()&&!!client.externalRecord()?.scope&&client.sameExternalScope(client.externalRecord().scope,SCOPE),
  newId,
  reserve:r=>{
   if(!ready||fatalJournal||!requestValid(r)||!referenceScene()||!document.getElementById('bridgeResult')?.textContent?.startsWith('Cena visual TEST importada')||client.protocol!=='v2'||!client.connected||
      client.profile!==PROFILE||client.journalError){mark('BLOQUEADO: importe a cena, entre em Sala v2 como Player 1 e verifique o journal.');return false;}
   return client.reserveExternal(PROFILE,r,SCOPE);
  },
  restore:()=>client.externalRecord(),
  markUnknown:id=>client.externalUnknown(id),
  finish:(id,status)=>sessionReady()&&pendingInScope(id)&&client.resolveExternal(id,status,SCOPE),
  send:async r=>{
   if(!requestValid(r)||!referenceScene()||!sessionReady()||!pendingInScope(r.commandId)||
      !client.externalPending||JSON.stringify(client.externalPending.payload)!==JSON.stringify(r))
      throw Error('unauthorized-unjournaled-command');
   const revision=client.revision;
   const out=await packet({schema_version:2,op:'submit',room_id:ROOM,
    client_action_id:r.commandId,expected_revision:revision,actor_id:'actor-1',
    action:{kind:'ATTACK_REQUEST',target:{kind:'UNIT',actor_id:'actor-m'},turn_id:'turn-test-1',
     context:{scene_id:'scene-test-1',ability_id:'basic-attack'}}});
   // Controlled test switch, not real packet loss. SQLite already committed.
   if(loseAck){loseAck=false;throw Error('TEST41-after-commit-reply-suppressed');}
   return receipt(out,r.commandId);
  },
  query:async id=>{
   if(!idValid(id)||!sessionReady()||!pendingInScope(id))
      throw Error('receipt-id-not-journaled');
   const out=await packet({schema_version:2,op:'receipt_query',room_id:ROOM,client_action_id:id});
   return receipt(out,id);
  }
 };
 window.TabletopTestAuthorityPort=port;
 window.TabletopNativeTEST={loseNextAttackAck:()=>{loseAck=true;},journal:()=>client.externalRecord(),ready:()=>ready&&!fatalJournal};
 if(ready){mark('HTTP LOCAL TEST40 ATIVO (FAKE): importe cena e conecte Sala v2 · Player 1. Apenas recibos, sem mecânica.');
  document.dispatchEvent(new Event('tabletop:connected-test-authority'));}
})();
