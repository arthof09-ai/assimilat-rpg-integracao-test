"""Deploy TEST41 frontend onto an isolated copy of the EXISTING Codex 0.4 Authority.
No new HTTP handler, engine, server, credentials or production deployment.
Requires separately supplied, SHA-verified, Mestre-only Codex ZIP.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,os,shutil,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1]
ZIP_SHA='5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a'
PUBLIC=['index.html','app.js','styles.css','room-v2-adapter.js','room-client.js']
def stage(codex_zip,where):
 blob=codex_zip.read_bytes()
 if hashlib.sha256(blob).hexdigest()!=ZIP_SHA:raise ValueError('Codex0.4 ZIP not approved SHA')
 with zipfile.ZipFile(codex_zip) as z:
  if z.testzip() is not None:raise ValueError('Corrupted ZIP')
  z.extractall(where)
 server=where/'experiments'/'tabletop_vlab_bridge'
 if not (server/'authority.py').is_file():raise ValueError('Missing original Authority')
 original=(server/'arena_transport.js').read_bytes()
 for f in PUBLIC:shutil.copyfile(ROOT/'public'/f,server/'vendor'/'test38'/f)
 # Preserve complete Codex transport: append an independent DEV-only capability.
 (server/'arena_transport.js').write_bytes(original+b'\n'+(ROOT/'connected_test'/'native_port.js').read_bytes())
 assert (server/'arena_transport.js').read_bytes().startswith(original)
 return server

def main():
 p=argparse.ArgumentParser(description='TEST41 original Codex Authority, TEST-only same-origin frontend')
 p.add_argument('--codex-zip',type=Path,required=True)
 p.add_argument('--db',type=Path,default=Path('test41-work/arena.sqlite'))
 p.add_argument('--port',type=int,default=8765)
 a=p.parse_args()
 a.db.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='tabletop-test41-authority-') as td:
  serverdir=stage(a.codex_zip,Path(td))
  sys.path.insert(0,str(serverdir))
  from authority import Authority,make_server
  server=make_server(Authority(a.db.resolve()),a.port,arena_assets=True)
  print(f'TEST41 ONLY: http://127.0.0.1:{server.server_port}/ | HTTP same origin | FAKE credentials | VLAB HOLD',flush=True)
  try:server.serve_forever()
  except KeyboardInterrupt:pass
  finally:server.server_close()
if __name__=='__main__':main()
