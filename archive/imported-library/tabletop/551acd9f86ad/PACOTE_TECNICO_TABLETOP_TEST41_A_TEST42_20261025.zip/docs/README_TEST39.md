# Tabletop Assimilação — RUN-016 / TEST39 (laboratório, MESTRE-SIDE)

## Resultado material

A Arena EXISTENTE TEST38 agora aceita, **somente quando um TEST harness injeta uma capacidade explicitamente confiável**, transmitir o rascunho visual `ATACAR` associado a um ator e alvo **sintéticos** ao HTTP Codex 0.3 original. A autoridade Codex rejeita a ação por `MECHANICS_UNAVAILABLE`, grava o recibo em SQLite, e o HUD mostra a rejeição real. O teste injeta a perda do ACK *depois do commit*, encerra/reinicia o HTTP Codex em cima do mesmo SQLite e recupera o MESMO `commandId` por `receipt_query`. O HTML não altera Vida/Alma/PA, tokens, turnos nem geometria. **Não há batalha oficial ainda.**

### O que isto NÃO é

* Nenhuma implantação no GitHub Pages; o site atual é TEST32 conforme última verificação.
* Nenhum VLAB consultado, nenhuma regra mecânica JS, nenhuma decisão de ataque ou dano.
* Nenhum WSS, Cloudflare, backend ou RoomV2Adapter concorrente criado.
* **Browser → Playwright binding → HTTP Codex original**: o navegador NÃO conectou por HTTP diretamente. O Codex 0.3 original nega CORS de propósito; não enfraquecer isso para acomodar o site.
* O mapeamento `u1`→`actor-1` / `u3`→`actor-2` existe SOMENTE no teste e exige prova de identidade em integração futura. O frontend não inventa geometria oficial.
* Identidades `FAKE_TEST_*` não são credenciais reais de usuário e **jamais** podem validar a privacidade da Party de produção.
* O port externo deste ensaio não constitui outbox durável do navegador nem contrato autoritativo aprovado. Em ausência de port, CONFIRMAR continua exibindo `MECÂNICA INDISPONÍVEL / NÃO ENVIADA`. Em caso de falha, o HUD mantém a ID até consulta ou reinicialização; fechar a página antes de exportar a ID é um risco residual.

## Teste do produto contra autoridade HTTP real

Requisitos: Python 3, Playwright+Chromium, fonte privado Codex0.3 descompactada em diretório fora do frontend TEST39. O pacote Codex deve ser obtido somente da Biblioteca Mestre autorizada, verificado por SHA256 `78760b79e842f83625daf8c17c2f1bf56c1320a9b35408f949f6fb82648afda`; **NÃO** está incluído no pacote público/técnico.

```bash
export CODEX_BRIDGE_ROOT=/CAMINHO/para/experiments/tabletop_vlab_bridge
python3 tests/test39_real_authority.py
python3 tests/test39_authority_security.py
python3 tests/test39_frontend_failclosed.py
```

`test39_real_authority.py` executa a fonte `authority.py` e `make_server` do Codex **inalterados**. Cria um `battle39` puramente sintético numa base SQLite temporária; abre o app TEST39 em Chromium e clica ator u1, ATACAR, u3, CONFIRMAR. Uma função Playwright no processo Python envia o envelope JSON real para o servidor HTTP Codex. O pacote `ATTACK_REQUEST` é rejeitado duravelmente (`REJECTED/MECHANICS_UNAVAILABLE`); o ACK é descartado pelo teste; o servidor é reiniciado; o botão da mesma tela consulta a mesma ID e mostra o recibo persistido. Verifique `evidence/TEST39_real_http_results.json` e screenshot real. Não houve HTTP nativo do navegador nem rede externa.

`test39_authority_security.py`: chaves de teste role-safe, recibos por principal, ator alheio, ID reutilizada com payload diferente, payload inválido, ausência de evento/mecânica e revisão inalterada. A inspeção de bytes é da **resposta HTTP local** original, não segurança produtiva.

`test39_frontend_failclosed.py`: UNKNOWN, `NOT_FOUND`, ID divergente, código de rejeição desconhecido, ausência de reenvio automático e workspace preservado. Usa port sintético controlado; conta SEPARADA de HTTP real.

Regressões da Arena e sala usam scripts originais preservados em `tests/`. Execução de testes precisa de Chrome/Chromium disponível; testes por viewport não certificam Android físico.

## Decisão de implementação

Somente `public/app.js`, `public/index.html` e `public/styles.css` foram alterados sobre TEST38. Os arquivos `public/room-client.js` e `public/room-v2-adapter.js` são **byte-idênticos** aos do baseline. A ABI v2 Codex (`assim.tabletop.room.bridge.test.v2`) não foi promovida ao contrato de sala da aplicação (`presentation.v1` e `v2` TEST). A função **opcional** `window.TabletopTestAuthorityPort` é inserida exclusivamente por instrumentação de teste, não existe no aplicativo normal. São preservados mapa, tokens, histórico, FOV, replay, journal, recepção DEMO e controles Android existentes.

### Continuidade

FIRST-PENDING: definir contrato único de identidade e cena com geometria autorizada `sceneId/n/walls/units/markers`, clientes reais e servidor competente. Em seguida validar a ligação HTTP/WebSocket **nativa** do navegador com autorização efetiva e outbox/receipt persistentes no cliente; só então ABI/VLAB oficial homologada. Nenhuma publicação na branch `gh-pages` nesta etapa.

## Incremento independente confrontado com Codex 0.4.0, recuperado durante a rodada

O checkpoint `CP-INOV-CODEX-040-TEST38-VERTICAL-20261024-001` apareceu enquanto este RUN era executado. O ZIP original Codex0.4 recuperado via Drive privado, SHA256 **`5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a`**, continha integração HTTP visual TEST38 com `arena_room.py`, preservando a Authority SQLite, a mesma outbox e testes. **O código Codex NÃO foi editado nem incorporado aos assets públicos ou ao ZIP técnico deste Desenvolvedor.**

O novo instrumento `tests/test39_codex04_combined.py` executa o próprio Authority0.4/arena_room HTTP/SQLite, importa explicitamente uma geometria sintética do estado VISUAL de `window.__tabletopTEST.scene()` com proveniência/hash de TEST38, liga o `RoomClient` e o adaptador v2 ORIGINAIS do frontend TEST39 ao HTTP Codex0.4 por ligação Playwright, confirma um movimento visual autorizado no quadro de sala, envia o `ATTACK_REQUEST` pela nova capacidade opcional do HUD, perde ACK depois do commit, reinicia o servidor original e recupera a rejeição mecânica persistida pela MESMA ID. O banco contém exatamente **1 evento visual aceito**, **2 recibos persistidos** (movimento ACCEPTED e ataque REJECTED), **revisão 1**, e **zero ataques mecânicos aplicados**. P2 vê somente sua unidade; consulta do recibo de P1 retorna NOT_FOUND. **23/23 verificações PASS** em Chromium 390×844.

Reprodução separada, com fonte Codex0.4 fisicamente providenciada por canal Mestre-only:

```bash
export CODEX_040_ROOT=/CAMINHO/para/experiments/tabletop_vlab_bridge
python3 tests/test39_codex04_combined.py
```

Limite: o browser chama uma função de transporte via Playwright **host binding**, que remete os bytes por HTTP genuíno ao servidor Codex original. O JavaScript TEST39 é REAL e a `Authority/SQLite` Codex0.4 é REAL, mas o socket HTTP **não é aberto diretamente pelo Chromium** nesta prova; a navegação direta 127.0.0.1 falhou ERR_BLOCKED_BY_ADMINISTRATOR. Não promover esta interface da bancada a infraestrutura oficial. O Codex0.4 TEM uma demonstração nativa HTTP local própria em seu pacote; não a duplicar, nem afirmar que ocorreu no browser deste Desenvolvedor. O port TEST39 é intencionalmente opcional e sua ID fica apenas em RAM, devendo futura integração aderir ao journal/outbox já existente e à identidade efetiva aprovada, sem second writer.

Esta comparação reduz a lacuna de integração sem concluir a batalha: o evento visual e sua revisão são válidos apenas em TEST; sem ABI VLAB competente e autorização de sala/Party, `ATTACK_REQUEST` permanece bloqueado com recibo correto.
