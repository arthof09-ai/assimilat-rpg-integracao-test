# RUN-017 — TEST40: Transporte nativo do navegador (candidato TEST)

**Identidade:** Comestre Inovador Desenvolvedor, MESTRE-SIDE, continuação da operação existente. **Não é combate oficial.** O VLAB permanece fonte mecânica exclusiva. O Codex 0.4.0 é a Authority original (não existe servidor novo no TEST40).

## Resultado material

- A Arena TEST39, antes dependente de `window.TabletopTestAuthorityPort` injetada pelo Playwright, agora possui uma extensão de **transporte de navegador via `fetch('/bridge')`**, carregada somente quando servida pelo **mesmo processo da Authority Codex 0.4.0** na origem autorizada de loopback.
- O launcher DEV `connected_test/start_test40.py` valida o SHA do ZIP *externo e privado* Codex 0.4.0, extrai uma **cópia temporária da versão original**, substitui apenas os cinco assets estáticos pelo TEST40, e acrescenta `native_port.js` ao final do `arena_transport.js` original. Os arquivos Python Codex não são modificados nem redistribuídos neste pacote.
- `room-client.js` acrescenta um campo **opcional** `external` ao JSON **do MESMO journal v1** usado no TEST36; não existe segundo journal/outbox nem outra chave. A intenção tática precisa ser gravada e relida ANTES do HTTP. Após reinício da página, o código recupera o mesmo `commandId`; nunca repete automaticamente um ataque UNKNOWN. Se o journal for ilegível, bloqueia o envio sem destruí-lo.
- Exige **importação explícita** da cena sintética referência; impedido importar um mapa editado com o antigo identificador fixado `TEST38_EXPLICIT_VISUAL_IMPORT` da ponte 0.4.0. Esse identificador do Codex NÃO autentica o binário frontend TEST40.
- Fora desse modo autorizado, como no HTML independente ou no ZIP estático público, `TabletopTestAuthorityPort` inexiste, CSP permanece `connect-src 'none'`, o botão mantém `NÃO ENVIADA`, a sala continua DEMO e nenhuma mecânica é inventada.

## Como abrir TEST40 com o servidor já existente, em computador com Python 3

1. Obter **separadamente**, em área privada Mestre-only, o ZIP ORIGINAL 
   `ponte-vlab-tabletop-0.4.0-test38.zip` (SHA-256: `5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a`). Este ZIP privado **NÃO está incorporado à distribuição TEST40**.
2. Extrair o ZIP técnico TEST40; em um terminal com `python3`:

   ```bash
   python3 connected_test/start_test40.py \
     --codex-zip /CAMINHO_PRIVADO/ponte-vlab-tabletop-0.4.0-test38.zip \
     --db ./test40-work/arena.sqlite --port 8765
   ```

3. Abrir **no mesmo computador** `http://127.0.0.1:8765/` com navegador que permita loopback HTTP. O Codex escuta somente em `127.0.0.1`, não na rede local: não abre a URL diretamente de outro aparelho.
4. Na faixa **PONTE HTTP LOCAL TEST**, escolher **Mestre TEST: importar cena atual**. A importação só é permitida para a geometria sintética intocada de referência. Evite reutilizar uma base SQLite real/canônica.
5. Na Sala, selecionar **protocolo v2** e **Player 1 DEMO**; clicar **Entrar**. O painel diferenciará `HTTP LOCAL TEST40` de DEMO. O perfil `FAKE_TEST_PLAYER1` NÃO representa autenticação.
6. Na Arena, selecionar a unidade `Exploradora TEST`, abrir **⚔ Ações**, escolher **Atacar TEST**, tocar **Criatura TEST** e confirmar. A Authority responderá `REJECTED / MECHANICS_UNAVAILABLE`. Isso significa: recebida e rejeitada, sem acerto, dano ou PA gasto.
7. Para exercitar o recibo perdido em laboratório, na aba Console do mesmo navegador autorizado executar `TabletopNativeTEST.loseNextAttackAck()` ANTES do envio. O servidor gravará o resultado e a resposta será deliberadamente descartada pela extensão TEST. Fechar e reiniciar o servidor **com o mesmo arquivo SQLite e a mesma porta 8765**; ao reabrir a página, a ID original é recuperada do journal e pode ser consultada no HUD. Esse passo é experimental, não rotina obrigatória do Mestre.

## PROVAS REALMENTE EXECUTADAS NESTA INSTÂNCIA

- SHA256/CRC do original TEST39 e do Codex0.4 verificados; GET de arquivos TEST40 via Authority Codex REAL com CSP de mesma origem: **14/14 PASS**.
- Código `native_port.js` + métodos `RoomClient` originais do TEST40 executados pelo **Node.js com `fetch` HTTP real** contra a Authority Python/SQLite: `ATTACK_REQUEST` persistido, ACK suprimido, processo Python reiniciado, nova instância JavaScript recuperou o MESMO `commandId`, **1 recibo e 0 eventos mecânicos**. Não houve Playwright encaminhando o HTTP nesse ensaio.
- Chromium Linux: **30/30 verificações do HUD e do journal** em 390×844 e 360×740, porém com resposta `fetch` SIMULADA e **substituição explícita somente no TESTE** da checagem de origem opaca. Não é prova de HTTP real em Chrome.
- Chromium tentou a navegação direta para a Authority em loopback e recebeu `net::ERR_BLOCKED_BY_ADMINISTRATOR`; **a prova HTTP nativa do navegador não foi possível nesta instância**. Não contornar política; repetir o teste em navegador normal autorizado. Não declarar esse gate PASS.
- Regressões pertinentes: sala v2, recuperação, journal fail-closed, HUD, Arena-first, ações e FOV. Veja logs em `evidence/`.

## LIMITES E GATES

**PASS:** preparação real de assets TEST40 pelo servidor original (não novo server), JS `fetch` contra Authority real no Node, recebimento e recuperação de recibo, mudança segura e retrocompatível do journal e testes de UI digitais.

**HOLD:** HTTP browser-originado até navegação permitida, autenticação real, LAN/WSS, Android físico, garantia geral de transação localStorage, migração de qualquer cena canônica, integração VLAB e ataque oficial. A Authority 0.4 usa credenciais FAKE, sem suporte de combate VLAB; a rejeição durável é o único resultado mecânico TEST demonstrado.

## Rollback e segurança

O original `baseline/TEST39_TECH_ORIGINAL.zip` está incorporado imutavelmente. O startup modifica **cópia TEMPORÁRIA** do Codex 0.4 e não altera as fontes Codex nem `main`/`gh-pages`. O banco TEST40 fica fora do código e não deve receber dados privados do RPG. Para voltar ao TEST39, use o ZIP preservado. Não publique `connected_test/native_port.js` como cliente autenticado; ele contém apenas um token FAKE e explicitamente serve testes locais de origem controlada. O pacote público OFFLINE continua **desconectado**.
