# RUN-018 / TEST41 — Correção de atribuição de recibos

**MESTRE-SIDE / TEST.** Continuação do RUN-017 original. Sem servidor novo, regras mecânicas, autenticação real ou deploy.

## O que foi implementado

1. **Cena:** a intenção do HUD guarda `sceneId`, `actorId`, `targetId`, tipo da ação e a cena ativa; ao trocar de cena ou reabrir a página, o recibo mostra claramente a **cena de origem**, não atribui efeito à cena atual e não altera Vida/Alma/PA.
2. **Sala:** o HUD prende o port usado no envio à intenção. Uma porta de outra sala com o mesmo `commandId` não pode confirmar a solicitação anterior. O port Codex TEST retorna escopo verificado `{roomId,principalId}` na resposta, sem pedir mudança no servidor original.
3. **Perfil e reabertura:** o mesmo journal `assim-tabletop-room-pending-test` agora possui campo **opcional** `scope` (roomId/principalId), mantendo schema/version=1 e a compatibilidade dos registros anteriores. A porta nativa verifica sala, perfil, `selfId`, papel `player`, estado de conexão, contexto do journal e ID antes de consultar ou finalizar. Uma entrada legada sem escopo é preservada mas não consultada automaticamente: `LEGACY_SCOPE_HOLD`, exigindo reconciliação confiável. Não armazena token no journal.
4. **Servidor:** `start_test41.py` monta uma cópia temporária da mesma Authority Codex0.4, sem editar seu Python, e injeta `native_port.js` só na origem loopback TEST. HTML offline e ZIP público continuam `connect-src 'none'` e sem porta.

## Rodar no computador em ambiente autorizado

```bash
python3 connected_test/start_test41.py --codex-zip /CAMINHO_PRIVADO/ponte-vlab-tabletop-0.4.0-test38.zip --db ./test41-work/arena.sqlite --port 8765
```

Abrir `http://127.0.0.1:8765/` **no próprio computador**; importar somente geometria sintética ORIGINAL de referência; conectar Sala v2 / Player 1 TEST; selecionar u1, Atacar TEST, u3, Confirmar. A resposta **deve** ser `REJECTED / MECHANICS_UNAVAILABLE`, sem efeito de combate. Não funciona como site remoto nem representa autenticação de produção. Para testar perda de ACK (cenário de laboratório): executar `TabletopNativeTEST.loseNextAttackAck()` no console do mesmo navegador antes do ataque, depois reiniciar a Authority sobre o mesmo SQLite; retomar mesma origem/sala e consultar a mesma ID.

## Evidência e limite

- PESQ020/021 RED originais preservados como relatórios científicos; novos canários `tests/test41_scene_room.py` e `tests/test41_cold_profile.py` testam fontes originais e alteradas em Chromium, com transporte **simulado**.
- `tests/test41_native_node.py` usa JavaScript `fetch` nativo do Node à Authority HTTP/SQLite Codex ORIGINAL, inclusive reinício e restauração de ID no journal. **Não é prova de POST do Chromium**.
- `tests/test41_http_assets.py` confere bytes efetivamente servidos, CSP estrita e que fonte Codex original permanece igual; `tests/test40_native_probe.py` tenta navegador HTTP nativo, que pode retornar `ERR_BLOCKED_BY_ADMINISTRATOR`. Se bloqueado, G4 HOLD, nunca simular PASS.
- A Authority usa credenciais FAKE e ainda responde `MECHANICS_UNAVAILABLE`; VLAB oficial e autorização real Mestre/Party HOLD. A filtragem de dados de Party deve ocorrer antes da transmissão no servidor competente.

**NO-REPEAT:** não reconstruir TEST33–40, PESQ012–021 nem Codex0.4.
