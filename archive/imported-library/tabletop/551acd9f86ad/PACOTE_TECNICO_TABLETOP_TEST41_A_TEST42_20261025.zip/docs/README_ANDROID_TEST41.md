# Para o Mestre: TEST41

**Modo sem servidor:** abra `TABLETOP_ASSIMILACAO_TEST41_OFFLINE.html` no Chrome Android. A Arena é interativa, mas o botão ATACAR **não transmite**: não há motor mecânico e o site público não é a Authority. O ZIP público é candidato, não foi publicado no site oficial.

**Modo conectado TEST (por enquanto PC com Python 3):** veja `README_TEST41.md`; exige o ZIP Codex0.4 privado obtido na área Mestre-only, outro que NÃO acompanha este pacote. O servidor escuta só no próprio PC em `127.0.0.1`; o celular não acessa esse loopback do computador. Use a cena sintética intacta, sala v2 Player1 FAKE, selecione Exploradora TEST → Atacar TEST → Criatura TEST → Confirmar. Esperado: REJECTED/MECHANICS_UNAVAILABLE. Nada disso é combate oficial VLAB.

**Cuidados:** guarde backup, não use dados da campanha real, não compartilhe ZIP Codex privado, não exponha a porta, não suponha que CSS/FOV autorizam a Party. Se sair de uma sala/cena durante um recibo UNKNOWN, volte ao perfil original e consulte a mesma ID; nunca reenvie o ataque criando outra ID.

**Gates:** navegador HTTP nativo TEST ainda precisa de ambiente onde localhost seja permitido; Chrome Android físico, autenticação Party real, multiplayer entre dispositivos e ABI VLAB permanecem HOLD.
