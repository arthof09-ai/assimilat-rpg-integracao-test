# Tabletop Assimilação — TEST42: visão 2.5D HTML

**Identidade:** Segundo Comestre Inovador Desenvolvedor / MESTRE-SIDE / TEST — continuidade do RUN-018 TEST41, sem nova operação, motor ou servidor. **RUN-019.**

## Para abrir e jogar no Android (sem custo)

1. Abra `TABLETOP_ASSIMILACAO_TEST42_OFFLINE.html` no navegador que permita arquivos HTML locais; se o Android não permitir abertura local, use os três arquivos públicos servidos por uma origem HTTP/HTTPS que o Mestre autorize.
2. O mapa abre por padrão em **◆ 2.5D**, com tabuleiro isométrico, unidades em pé, sombras, paredes/platô em volume e marcadores/régua projetados.
3. Toque na unidade e em **⚔ Ações**, escolha a ação TEST, toque o alvo no tabuleiro e confirme ou cancele. Nenhuma ação cria dano nem gasto de PA sem VLAB oficial.
4. Abra **⚙ Ferramentas do Mestre** para editar, criar parede, alterar terreno, marcar, medir, desfazer, refazer, ajustar zoom ou mover mapa. Arraste com ✋ Mapa; dois dedos realizam pinça.
5. Toque em **◆ 2.5D** para alternar à vista **▦ 2D**, e volte a qualquer momento. O modo de câmera **não altera a cena salva**; a grade, as coordenadas e os identificadores permanecem os mesmos. Minimap é sempre a visão superior 2D.
6. **Salvar no aparelho** salva o mesmo workspace local anterior; **↓ Backup** baixa o JSON independente, com o mesmo contrato. **Não envie dados reais Mestre-only nem use arquivos canônicos na distribuição pública.**

## Implementação real (alteração material)

A visão 2.5D reusa os `button.tile[data-xy]` da Arena e seus callbacks originais, com projeção geométrica `screen(x,y)` da mesma grade inteira. Não duplica SceneStore, caminhos, replay, sistema de ações, journal, regras de FOV ou motor.

- CSS isométrico via clip-path de losango, textura leve de terreno e sombras.
- SVG **estritamente decorativo** (`pointer-events:none`) para relevo perimetral da arena, paredes extrudidas, miniaturas verticais, sombras e marca de seleção por equipe. NÃO é camada de autorização ou colisor 3D.
- Régua SVG e marcadores usam a MESMA função de projeção de coordenadas, mantendo os valores Manhattan/Euclidiano anteriores. Preview de ataque e FOV são calculados **antes** na grid lógica já existente; a visão somente os desenha.
- Zoom, centralização, foco e pan reutilizam os controles originais e atualizam as projeções. O botão 2D volta exatamente ao layout retangular anterior.
- Compatível com 5, 7, 10 e 20 casas por lado, cenas diferentes, seleção, edição, zoom e backups antigos.

### Limitações

- É uma **projeção tática 2.5D** isométrica em HTML/CSS/SVG, não um motor 3D verdadeiro, nem jogo completo com animações de combate oficiais.
- FOV/alcance/previews permanecem EXPERIMENTAIS e apenas visuais; mecânica oficial VLAB **HOLD**. O TEST41 manteve HTTP navegador local **HOLD** por política de navegação, não modificado pelo TEST42.
- O app offline e pacote público permanecem desconectados da Authority; HTML não inclui tokens, dados reais da Party ou Codex privado.
- Testes de viewport Chromium Linux não equivalem a testes em Chrome Android físico. Periféricos/toque Android real **HOLD**.

### QA

`python tests/test42_25d.py` — ações, seleção, FOV, régua, marcadores, modo 2D e 2.5D (3 viewports).  
`python tests/test42_stress.py` — mapa 20×20, zoom, FOV, redimensionamento, paredes, toque sem force, paisagem (3 viewports).  
`python tests/test42_offline.py` — HTML único com CSP hash, script e CSS reais, sem rede (3 viewports).  
`python tools/build_test42.py` — ZIP técnico, ZIP público sintético e HTML offline; hashes, CRC, readback e build determinístico.

**Fonte persistente:** Biblioteca Mestre existente, página original do Laboratório do Inovador Notion. Publicação em GitHub Pages **NÃO executada** neste RUN. Site oficial permanece TEST32 até gate de publicação.
