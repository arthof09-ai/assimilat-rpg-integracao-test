from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
async def mount(page):
    pub=ROOT/'public'
    html=(pub/'index.html').read_text()
    html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html)
    html=html.replace('<link rel="stylesheet" href="styles.css">','')
    for name in ['app.js','room-v2-adapter.js','room-client.js']:
      html=html.replace(f'<script src="{name}" defer></script>','')
    await page.set_content(html)
    await page.evaluate('''() => {const mem={};for(const field of ['localStorage','sessionStorage'])Object.defineProperty(window,field,{configurable:true,value:{getItem:k=>mem[k]??null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}}});}''')
    await page.add_style_tag(content=(pub/'styles.css').read_text())
    for name in ['app.js','room-v2-adapter.js','room-client.js']:
      await page.add_script_tag(content=(pub/name).read_text())

