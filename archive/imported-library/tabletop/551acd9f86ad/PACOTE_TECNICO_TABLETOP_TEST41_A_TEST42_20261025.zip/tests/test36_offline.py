"""TEST36 HTML standalone smoke in a Chromium context. No Android hardware/WSS."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  total=0
  for w,h in ((390,844),(360,740)):
   p=await b.new_page(viewport={'width':w,'height':h});errors=[];net=[]
   p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda e:net.append(e.url))
   file=ROOT/'dist/TABLETOP_ASSIMILACAO_TEST36_OFFLINE.html'; file=file if file.exists() else ROOT/'offline/TABLETOP_ASSIMILACAO_TEST36_OFFLINE.html'
   await p.set_content(file.read_text())
   async def check(label,yes):
    assert yes,(label,errors);return 1
   count=0
   count+=await check('TEST36 version text', 'TEST 36' in await p.locator('header').inner_text())
   count+=await check('Arena 49 cells', await p.locator('.tile').count()==49)
   await p.locator('#roomConnect').click()
   count+=await check('Legacy fixture still connects',await p.evaluate('window.TabletopRoomTEST.client.connected'))
   await p.locator('#roomProtocol').select_option('v2');await p.locator('#roomConnect').click()
   count+=await check('V2 fixture WELCOME',await p.evaluate('window.TabletopRoomTEST.client.connected'))
   count+=await check('V2 snapshot synthetic',await p.locator('#roomGrid button').count()==49)
   count+=await check('No runtime exception',not errors)
   count+=await check('No external network',len(net)==0)
   count+=await check('No horizontal overflow',await p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   if w==390:
    await p.screenshot(path=str(ROOT/'evidence/TEST36_mobile_390x844.png'),full_page=True)
   print(f'{w}x{h} {count}/{count} PASS')
   total+=count;await p.close()
  print('OFFLINE',total,'/',total,'PASS')
  await b.close()
if __name__=='__main__':asyncio.run(main())
