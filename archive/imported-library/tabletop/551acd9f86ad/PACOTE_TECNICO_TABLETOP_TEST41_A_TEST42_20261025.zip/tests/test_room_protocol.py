"""Protocol: three independently instantiated role clients in the same Chromium page.
Not WebSocket / server / multiple physical browsers. Source fixtures only.
"""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
from test_room_browser import mount
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':390,'height':844})
  await mount(page)
  results=await page.evaluate('''() => {
  const T=window.TabletopRoomTEST;const f=T.demoTransportFactory;const make=(profile,id)=>{const c=new T.RoomClient({transportFactory:f,nonce:id});c.connect(profile);return c;};
  const master=make('gm','mastertest'),p1=make('p1','playerone'),p2=make('p2','playertwo');
  const assert=(name,bool)=>{checks.push({name,pass:!!bool});if(!bool)throw Error(name);};let checks=[];
  assert('3 clients connected',master.connected&&p1.connected&&p2.connected);
  assert('GM sees 3 characters',master.snapshot.units.length===3);
  assert('P1 sees own only',p1.snapshot.units.map(x=>x.id).join()==='demo_a');
  assert('P2 sees own only',p2.snapshot.units.map(x=>x.id).join()==='demo_b');
  assert('No private keys in P1 wire projection',Object.keys(p1.snapshot).join()==='n,walls,units');
  const beforeP2=JSON.stringify(p2.snapshot);
  assert('P1 cannot command P2 unit',p1.sendIntent('demo_b',3,4)===false);
  assert('P1 can request its unit move',p1.sendIntent('demo_a',2,2)===true);
  assert('P1 confirmed own position',p1.snapshot.units[0].x===2&&p1.revision===1);
  assert('GM sees committed event',master.snapshot.units.find(x=>x.id==='demo_a').x===2&&master.revision===1);
  assert('P2 gets revision but not hidden actor',p2.revision===1&&JSON.stringify(p2.snapshot)===beforeP2);
  assert('P2 wire does not expose P1 id',!p2.log.some(x=>x.includes('demo_a')));
  assert('All instances align to server fixture revision',master.revision===p1.revision&&p1.revision===p2.revision);
  assert('Command to wall refused client-side',p1.sendIntent('demo_a',3,3)===false);
  assert('No mutation after rejection',p1.snapshot.units[0].x===2);
  assert('Old revision intention rejected',p1.sendIntent('demo_a',4,4)===true);
  assert('Revision increment with valid request',p1.revision===2);
  assert('P2 still receives filtered snapshot',p2.snapshot.units.length===1&&p2.revision===2);
  const prior=p1.revision;p1.disconnect();p1.connect('p1');
  assert('Rejoin restores current snapshot',p1.revision===prior&&p1.snapshot.units[0].x===4);
  assert('Client id generator survives reconnect',p1.sendIntent('demo_a',4,5)===true&&p1.revision===prior+1);
  assert('Role switch cannot reuse old identity',p1.role==='player'&&p1.selfId==='p1');
  p2.disconnect();p1.disconnect();master.disconnect();
  assert('Close clears projection',p1.snapshot===null&&master.snapshot===null);
  // Passive transport: no instant ack; intent stays pending until server event.
  let emit,wire=[];const dummy=({onMessage})=>{emit=onMessage;return {send:x=>wire.push(JSON.parse(x)),close:()=>{}};};
  const isolated=new T.RoomClient({transportFactory:dummy,nonce:'isolated'});isolated.connect('p1');
  assert('JOIN is structured allowlist',wire[0].type==='ROOM_JOIN'&&Object.keys(wire[0]).sort().join()==='profile,roomId,schema,type');
  const unit={id:'u',name:'Synthetic',mark:'S',team:'ally',ownerId:'p1',x:1,y:1};const snap={n:7,walls:[],units:[unit]};
  const base=(type,revision,seq)=>({schema:T.SCHEMA,roomId:'arena-test',type,revision,seq});
  emit(JSON.stringify({...base('ROOM_JOINED',0,0),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:snap}));
  assert('Passive client entered',isolated.connected);
  isolated.sendIntent('u',2,2);
  assert('Intent packet sends no authority claim',wire[1].type==='ROOM_INTENT'&&!Object.keys(wire[1]).includes('role')&&!Object.keys(wire[1]).includes('hp'));
  assert('No optimistic position mutation',isolated.snapshot.units[0].x===1);
  assert('Pending stays until server ack',isolated.pending.size===1);
  let intentId=wire[1].intentId;
  emit(JSON.stringify({...base('ROOM_REJECT',0,0),intentId,reason:'NOT_OWNER'}));
  assert('Reject preserves previous position',isolated.snapshot.units[0].x===1);
  assert('Reject cleans pending',isolated.pending.size===0);
  isolated.sendIntent('u',2,2);intentId=wire.at(-1).intentId;
  emit(JSON.stringify({...base('ROOM_EVENT',1,1),intentId,kind:'MOVE_CONFIRMED',actorId:'u',snapshot:{...snap,units:[{...unit,x:2,y:2}]}}));
  assert('Confirmed packet moves only upon ack',isolated.snapshot.units[0].x===2&&isolated.pending.size===0);
  assert('Revision 1 applied',isolated.revision===1&&isolated.seq===1);
  emit(JSON.stringify({...base('ROOM_EVENT',3,3),intentId:'fake',kind:'ROOM_UPDATED',actorId:'u',snapshot:snap}));
  assert('Gap triggers resync request',wire.at(-1).type==='ROOM_RESYNC');
  assert('Gap packet never mutates',isolated.snapshot.units[0].x===2&&isolated.revision===1);
  emit(JSON.stringify({...base('ROOM_SNAPSHOT',3,3),snapshot:{...snap,units:[{...unit,x:3,y:2}]}}));
  assert('New snapshot recovers gap',isolated.snapshot.units[0].x===3&&isolated.revision===3);
  const malformed={...base('ROOM_SNAPSHOT',4,4),snapshot:{...snap,secret:'GM-ONLY'}};
  emit(JSON.stringify(malformed));
  assert('Private projection rejected fail closed',isolated.status==='error'&&isolated.snapshot===null);
  assert('No private string exposed to logs',!isolated.log.some(x=>x.includes('GM-ONLY')));
  const oldEmitter=emit;isolated.connect('p1');
  oldEmitter(JSON.stringify({...base('ROOM_JOINED',9,9),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:snap}));
  assert('Late packet from previous transport ignored',isolated.status==='connecting'&&isolated.snapshot===null);
  emit(JSON.stringify({...base('ROOM_JOINED',3,3),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:snap}));
  assert('New transport packet accepted',isolated.connected&&isolated.revision===3);

  // Seeded property-style negative checks for exact-key policy.
  let seed=20261023;const rnd=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
  for(let i=0;i<180;i++){
    const candidate={...base('ROOM_SNAPSHOT',i+4,i+4),snapshot:{n:7,walls:[],units:[]}};
    Object.defineProperty(candidate,['adminToken','secret','privateNotes','__proto__','revisionBypass'][Math.floor(rnd()*5)],{value:String(i),enumerable:true,configurable:true});
    assert('Generated hidden field rejected '+i,T.checkPacket(JSON.parse(JSON.stringify(candidate)))===false);
  }
  return checks;
 }''')
  failures=[x for x in results if not x['pass']]
  print(f"Protocol directed {len(results)-180}/ {len(results)-180} PASS, seeded negative payloads 180/180 PASS, errors {failures}")
  await browser.close()
asyncio.run(main())
