"""Original Codex HTTP server serves the NEW DEV assets, not vendor TEST38.
No browser forwarding; this is raw HTTP/asset provenance and CSP inspection.
"""
from pathlib import Path
import os
import hashlib,sys,tempfile,threading,urllib.request,urllib.error
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'connected_test'))
from start_test41 import stage
checks=[]
def ck(label,yes):
 assert yes,label
 checks.append(label)
with tempfile.TemporaryDirectory(prefix='assets-test41-') as td:
 d=Path(td);folder=stage(Path(os.environ.get('TEST41_CODEX_ZIP','/mnt/data/ponte-vlab-tabletop-0.4.0-test38.zip')),d/'runtime');sys.path.insert(0,str(folder))
 from authority import Authority,make_server
 old=(Path(os.environ.get('TEST41_CODEX_SOURCE_DIR','/mnt/data/tabletop_run018/codex/experiments/tabletop_vlab_bridge'))/'arena_transport.js').read_bytes()
 new=(folder/'arena_transport.js').read_bytes()
 ck('Original Codex transport prefix unchanged',new.startswith(old))
 ck('Native addon present only in TEST runtime',b'TabletopNativeTEST' in new)
 authorityOriginal=(Path(os.environ.get('TEST41_CODEX_SOURCE_DIR','/mnt/data/tabletop_run018/codex/experiments/tabletop_vlab_bridge'))/'authority.py').read_bytes()
 ck('Authority original unchanged', (folder/'authority.py').read_bytes()==authorityOriginal)
 server=make_server(Authority(d/'db.sqlite'),0,arena_assets=True)
 threading.Thread(target=server.serve_forever,daemon=True).start()
 url=f'http://127.0.0.1:{server.server_port}/'
 def get(p):
  with urllib.request.urlopen(url+p) as res:return res.getcode(),res.headers, res.read()
 for name in ['app.js','styles.css','room-client.js','room-v2-adapter.js']:
  c,h,b=get(name)
  ck('GET /'+name+' byte exact TEST41',c==200 and b==(ROOT/'public'/name).read_bytes())
 c,h,b=get('index.html')
 ck('HTML TEST41 served instead of TEST38',b'TEST 41' in b and b'tacticAuthorityQuery' in b)
 ck('CSP same origin only',b"connect-src 'self'" in b and b'http://' not in b)
 ck('Transport injected by existing Codex handler',b'<script src="arena_transport.js" defer></script>' in b)
 c,h,b=get('arena_transport.js')
 ck('Native capability served by original handler',c==200 and b==new)
 ck('No-store cache headers',h.get('Cache-Control')=='no-store')
 try:get('../secret')
 except urllib.error.HTTPError as e:ck('No arbitrary file serving',e.code==400)
 ck('No REAL campaign or VLAB fields in served addon',all(x not in new for x in [b'VLAB_R205_',b'PRIVATE_MASTER_CORPUS',b'BEGIN PRIVATE KEY']))
 server.shutdown();server.server_close()
print('TEST41 REAL HTTP GET',len(checks),'PASS')
