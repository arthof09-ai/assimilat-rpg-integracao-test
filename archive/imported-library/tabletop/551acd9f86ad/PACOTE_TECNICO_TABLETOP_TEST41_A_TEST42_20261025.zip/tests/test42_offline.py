"""Standalone HTML real CSP hash + isometric view smoke in Chromium; no backend/Android claims."""
from pathlib import Path
import asyncio,json
from playwright.async_api import async_playwright
R=Path(__file__).resolve().parents[1];OUT=R/'evidence'
async def run(page,w,h):
 errors=[];requests=[];violations=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
 await page.set_content((R/'dist'/'TABLETOP_ASSIMILACAO_TEST42_OFFLINE.html').read_text());await page.evaluate('window.addEventListener("securitypolicyviolation",e=>{window.__violations=(window.__violations||[]).concat([e.violatedDirective])})')
 checks=[]
 async def ck(k,v):
  assert v,(w,h,k,errors,requests);checks.append(k)
 async def ev(j):return await page.evaluate(j)
 await ck('version42', 'TEST 42' in await page.locator('header .tag').inner_text())
 await ck('49 original cells',await page.locator('.tile').count()==49)
 await ck('default 2.5D',await ev('window.__tabletopTEST.projection()')=='iso')
 await ck('isometric class',await ev('document.querySelector("#board").classList.contains("isometric")'))
 await ck('isometric pawns',await page.locator('#isoArt text').count()==3)
 await ck('floating base volume',await page.locator('#isoBase polygon').count()==14)
 await ck('room module exists',await ev('typeof window.TabletopRoomTEST.RoomClient==="function"'))
 await ck('server port absent',await ev('window.TabletopTestAuthorityPort===undefined'))
 await ck('fetch forbidden', "connect-src 'none'" in await page.locator('meta[http-equiv="Content-Security-Policy"]').get_attribute('content'))
 await ck('no script errors',not errors)
 await ck('no external requests',not requests)
 await page.locator('#tacticToggle').click();await page.locator('#tacticAction').select_option('attack')
 await page.locator('.tile[data-xy="5,2"]').click(force=True);await page.locator('#tacticConfirm').click()
 await ck('attack unavailable, not sent','NÃO ENVIADA' in await page.locator('#tacticReadout').inner_text())
 await ck('HP unchanged',await ev('window.__tabletopTEST.scene().units[0].hp===100'))
 await ck('no requests after attack',not requests)
 await page.locator('#view25d').click();await ck('2D works',await ev('window.__tabletopTEST.projection()')=='flat')
 await page.locator('#view25d').click();await ck('2.5D returns',await ev('window.__tabletopTEST.projection()')=='iso')
 await ck('no errors final',not errors)
 await ck('no CSP violations',not await ev('window.__violations?.length||0'))
 await page.screenshot(path=str(OUT/f'TEST42_OFFLINE_{w}x{h}.png'))
 return {'viewport':f'{w}x{h}','checks':checks,'count':len(checks)}
async def main():
 results=[]
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(360,740),(844,390)]:
   p=await b.new_page(viewport={'width':w,'height':h},is_mobile=w<700,has_touch=w<700);results.append(await run(p,w,h));await p.close()
  await b.close()
 (OUT/'TEST42_OFFLINE_QA.json').write_text(json.dumps(results,indent=2,ensure_ascii=False));print('TEST42 offline HTML/CSP',sum(x['count'] for x in results),'PASS')
if __name__=='__main__':asyncio.run(main())
