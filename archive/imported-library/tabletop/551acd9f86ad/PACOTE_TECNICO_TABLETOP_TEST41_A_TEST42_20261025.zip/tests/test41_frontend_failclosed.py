"""TEST41: preserve original negative assertions with newly required explicit room/profile scope.
Test-only synthetic port, NOT real server authorization or network.
"""
from pathlib import Path
import asyncio,json,sys
from playwright.async_api import async_playwright
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test39_mount import mount
ROOT=Path(__file__).resolve().parents[1]
async def suite(browser,w,h):
 p=await browser.new_page(viewport={'width':w,'height':h},is_mobile=w<800,has_touch=w<800)
 await mount(p);checks=[]
 async def check(label,yes):
  assert yes,f'{w}x{h} {label}'
  checks.append(label)
 async def ready_attack():
  await p.locator('#tacticAction').select_option('attack')
  await p.locator('.tile[data-xy="5,2"]').click(force=True)
 await p.locator('#tacticToggle').click()
 ws=await p.evaluate('window.__tabletopTEST.state()')
 await p.evaluate('''() => {let id=0;window.fakePortLog=[];window.TabletopTestAuthorityPort={scope:{roomId:'arena-test',principalId:'p1'},newId:()=>`check39_${++id}`,send:async r=>{window.fakePortLog.push({...r});return {commandId:r.commandId,status:'UNKNOWN'};},query:async id=>({commandId:id,status:'NOT_FOUND',scope:{roomId:'arena-test',principalId:'p1'}})};}''')
 await ready_attack();await p.locator('#tacticConfirm').click()
 await p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
 await check('malformed UNKNOWN submit response is not success','UNKNOWN' in await p.locator('#tacticReadout').inner_text())
 await check('submission exactly once',await p.evaluate('window.fakePortLog.length')==1)
 await check('query active when result ambiguous',not await p.locator('#tacticAuthorityQuery').is_disabled())
 await ready_attack();await p.locator('#tacticConfirm').click()
 await check('cannot create another command while unknown',await p.evaluate('window.fakePortLog.length')==1)
 await check('unknown id retained',await p.evaluate('window.__tabletopTEST.authority().id')=='check39_1')
 await p.locator('#tacticAuthorityQuery').click()
 await p.wait_for_function('window.__tabletopTEST.authority()?.status==="NOT_FOUND"')
 await check('not found still unknown','UNKNOWN' in await p.locator('#tacticAuthorityState').inner_text())
 await check('not found query remains available',not await p.locator('#tacticAuthorityQuery').is_disabled())
 await check('no new command after not found',await p.evaluate('window.fakePortLog.length')==1)
 await check('workspace untouched',ws==await p.evaluate('window.__tabletopTEST.state()'))
 # Wrong-ID fake receipt cannot become terminal.
 await p.evaluate('''() => {window.TabletopTestAuthorityPort.query=async id=>({commandId:'WRONG',status:'ACCEPTED'});}''')
 await p.locator('#tacticAuthorityQuery').click()
 await p.wait_for_function('window.__tabletopTEST.authority()?.code==="INVALID_RECEIPT"')
 await check('foreign id accepted rejected',await p.evaluate('window.__tabletopTEST.authority().status')=='UNKNOWN')
 await check('foreign id cannot mutate workspace',ws==await p.evaluate('window.__tabletopTEST.state()'))
 # New page, malformed/forged accepted packet cannot be treated as authoritative success.
 await p.close()
 p=await browser.new_page(viewport={'width':w,'height':h},has_touch=w<800,is_mobile=w<800)
 await mount(p);await p.locator('#tacticToggle').click()
 await p.evaluate('''() => {window.TabletopTestAuthorityPort={scope:{roomId:'arena-test',principalId:'p1'},newId:()=>`check39_1`,send:async r=>({commandId:r.commandId,status:'REJECTED',code:'BAD_UNEXPECTED_CODE',scope:{roomId:'arena-test',principalId:'p1'}}),query:async id=>({commandId:id,status:'NOT_FOUND',scope:{roomId:'arena-test',principalId:'p1'}})};}''')
 await p.locator('#tacticAction').select_option('attack');await p.locator('.tile[data-xy="5,2"]').click(force=True)
 await p.locator('#tacticConfirm').click()
 await p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
 await check('unknown server rejection code does not become terminal','INVALID_RECEIPT' in await p.locator('#tacticAuthorityState').inner_text())
 await check('no fake VLAB completion','ACEITO' not in await p.locator('#tacticReadout').inner_text())
 await check('tactical mode unchanged',await p.evaluate('window.__tabletopTEST.scene().units[0].hp')==100)
 await p.close()
 return {'viewport':f'{w}x{h}','cases':checks,'count':len(checks)}
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  results=[]
  for w,h in [(360,740),(390,844),(1100,850)]:
   r=await suite(browser,w,h);results.append(r);print('FAILCLOSED UI',r['viewport'],r['count'],'PASS',flush=True)
  await browser.close()
 (ROOT/'evidence'/'TEST41_frontend_failclosed.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print('TOTAL',sum(r['count'] for r in results))
if __name__=='__main__':asyncio.run(main())
