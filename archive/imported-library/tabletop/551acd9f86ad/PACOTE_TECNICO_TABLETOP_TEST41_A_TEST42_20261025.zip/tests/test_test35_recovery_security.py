"""Directed TEST35 v1/v2 semantics, in-memory journal and adversarial payloads.
Fixture only; no WSS, Cloudflare, auth, Android or external VLAB.
"""
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
from test_room_browser import mount
V2=(Path(__file__).resolve().parents[1]/'public'/'room-v2-adapter.js').read_text()
JS=r'''() => {
 const T=window.TabletopRoomTEST,V=window.TabletopRoomV2TEST,checks=[];
 const assert=(label,pass)=>{checks.push({label,pass:!!pass});if(!pass)throw Error(label)};
 const mkStore=()=>{const db=new Map();return {getItem:k=>db.get(k)??null,setItem:(k,v)=>db.set(k,String(v)),removeItem:k=>db.delete(k)};};
 // Reset separate client mock and retain authoritative local-fixture state.
 const s=V.mock;s.revision=0;s.sessionEpoch=1;s.walls=['3,3'];s.receipts.clear();s.units=[
 {id:'demo_a',name:'A TEST',mark:'A',team:'ally',ownerId:'p1',x:1,y:1},
 {id:'demo_b',name:'B TEST',mark:'B',team:'ally',ownerId:'p2',x:1,y:4},
 {id:'demo_n',name:'N TEST',mark:'X',team:'enemy',ownerId:null,x:5,y:3}];
 // Client A persists intent BEFORE sending. Server commits but suppresses acknowledgement.
 const store=mkStore(),factory=V.createV2AdapterTransport(V.mockV2TransportFactory);
 let sent=[];
 const instrumented=({onMessage,onClose})=>{const inner=factory({onMessage,onClose});return {send:raw=>{sent.push(JSON.parse(raw));inner.send(raw)},close:()=>inner.close()};};
 const first=new T.RoomClient({transportFactory:instrumented,nonce:'stable_id_a',protocol:'v2',journalStore:store});first.connect('p1');
 assert('JOIN v1 maps to real schema-v2 shape',sent[0].type==='ROOM_JOIN'&&first.connected);
 s.dropNextAck=true;
 assert('Intent accepted for transmission',first.sendIntent('demo_a',2,2)===true);
 const commandId=[...first.pending.keys()][0];
 assert('Pending preserved despite server commit',first.pending.size===1&&s.revision===1&&first.snapshot.units[0].x===1);
 assert('Journal contains command but no secrets',!!store.getItem(first.journalKey)&&!/(ticket|password|secret|admin|MASTER)/i.test(store.getItem(first.journalKey)));
 assert('Same payload recognized',first.comparePendingCommand(commandId,first.pending.get(commandId).payload));
 assert('Different payload rejected by compare',!first.comparePendingCommand(commandId,{...first.pending.get(commandId).payload,x:4}));
 first.disconnect();assert('Explicit disconnect retains UNKNOWN',first.pending.size===1&&first.status==='unknown');
 // Simulated tab reload: same sessionStorage object, new client instance, same mock fixture.
 const wire=[];const second=new T.RoomClient({transportFactory:({onMessage,onClose})=>{const tr=factory({onMessage,onClose});return {send:raw=>{wire.push(JSON.parse(raw));tr.send(raw)},close:()=>tr.close()};},nonce:'reload_new_nonce',protocol:'v2',journalStore:store});
 assert('Readback recreates unknown with same command ID',second.pending.has(commandId)&&second.pending.get(commandId).state==='UNKNOWN');
 second.connect('p1');
 assert('Rejoin automatically queries receipt by SAME ID',wire.some(x=>x.type==='ROOM_RECEIPT_QUERY'&&x.intentId===commandId));
 assert('No new intent during receipt recovery',wire.filter(x=>x.type==='ROOM_INTENT').length===0);
 assert('Commit stays once',s.revision===1&&second.pending.size===0&&second.snapshot.units[0].x===2);
 assert('Journal clears after accepted receipt',JSON.parse(store.getItem(second.journalKey)).entries.length===0);
 // Replay exact same ID/bytes directly to mock service: receipt idempotence.
 let rawResponses=[];const rawV2=V.mockV2TransportFactory({onMessage:raw=>rawResponses.push(JSON.parse(raw)),onClose:()=>{}});
 rawV2.send(JSON.stringify({v:2,type:'JOIN',roomId:'arena-test',ticket:'test-local-p1'}));
 let original={v:2,type:'INTENT',roomId:'arena-test',commandId,baseRevision:0,kind:'MOVE_VISUAL_TEST',unitId:'demo_a',payload:{x:2,y:2}};
 rawV2.send(JSON.stringify(original));
 assert('Repeat ID+identical bytes returns same ACCEPTED receipt',rawResponses.at(-1).status==='ACCEPTED'&&s.revision===1);
 rawV2.send(JSON.stringify({...original,payload:{x:3,y:2}}));
 assert('ID reuse with different payload REJECTED',rawResponses.at(-1).reason==='ID_REUSE_CONFLICT'&&s.revision===1);
 rawV2.send(JSON.stringify({...original,commandId:'different_id',baseRevision:0}));
 assert('Stale revision REJECTED',rawResponses.at(-1).reason==='STALE_REVISION'&&s.revision===1);
 rawV2.send(JSON.stringify({...original,commandId:'unauth_id',baseRevision:1,unitId:'demo_b'}));
 assert('Another player unit denied',rawResponses.at(-1).reason==='NOT_OWNER'&&s.revision===1);
 assert('Outright admin command invalid',!V.validV2Outgoing({...original,kind:'ADMIN_RESET'}));
 assert('Role claim forbidden in INTENT',!V.validV2Outgoing({...original,role:'MASTER'}));
 assert('Foreign ticket format rejected by fixture',!V.validV2Outgoing({v:2,type:'JOIN',roomId:'arena-test',ticket:'production-key'}));
 // Incoming projection: allowlist rejects nested admin even inside allowed arrays.
 const snap={sceneId:'scene-test',n:7,walls:[],units:[{id:'demo_a',name:'a',mark:'A',team:'ally',ownerId:'p1',x:1,y:1}],markers:[{id:'m',x:2,y:2,label:'Note'}]};
 const base={v:2,type:'SNAPSHOT',roomId:'arena-test',revision:2,snapshot:snap};
 assert('Known projection accepted',V.validV2Response(base));
 const mutated=[
 {...base,snapshot:{...snap,units:[{...snap.units[0],adminNote:'CANARY'}]}},
 {...base,snapshot:{...snap,markers:[{...snap.markers[0],adminSourceId:'CANARY'}]}},
 {...base,snapshot:{...snap,adminMarkers:['CANARY']}},
 {...base,snapshot:{...snap,units:[{...snap.units[0],lastEvent:{private:'CANARY'}}]}},
 {...base,snapshot:{...snap,markers:[{...snap.markers[0],notes:{admin:'CANARY'}}]}},
 {...base,internalMasterOnly:'CANARY'},
 {...base,snapshot:{sceneId:'scene-test',units:[],markers:[]}}
 ];
 for(let i=0;i<mutated.length;i++)assert('Nested admin injection rejected '+i,!V.validV2Response(mutated[i]));
 // Both roles receive different payloads BEFORE browser presentation in the mock transport.
 const inbox1=[],inbox2=[],peer1=V.mockV2TransportFactory({onMessage:r=>inbox1.push(JSON.parse(r)),onClose:()=>{}}),peer2=V.mockV2TransportFactory({onMessage:r=>inbox2.push(JSON.parse(r)),onClose:()=>{}});
 peer1.send(JSON.stringify({v:2,type:'JOIN',roomId:'arena-test',ticket:'test-local-p1'}));peer2.send(JSON.stringify({v:2,type:'JOIN',roomId:'arena-test',ticket:'test-local-p2'}));
 assert('Player 1 sees own-only units at origin',inbox1[0].snapshot.units.every(x=>x.ownerId==='p1'));
 assert('Player 2 sees own-only units at origin',inbox2[0].snapshot.units.every(x=>x.ownerId==='p2'));
 assert('No admin fields in RAW player transport',!JSON.stringify(inbox1).includes('admin')&&!JSON.stringify(inbox2).includes('admin'));
 assert('No hidden Player 2 unit in Player 1 transport',!JSON.stringify(inbox1).includes('demo_b'));
 // Unknown receipt for entirely absent ID does not mark command as rejected.
 const testStore=mkStore();const third=new T.RoomClient({transportFactory:factory,nonce:'unknowncase',protocol:'v2',journalStore:testStore});third.connect('p1');
 // Synthetic transport that drops before committing then returns NOT_FOUND for receipt.
 const fakeFactory=({onMessage,onClose})=>{
  const send=(str)=>{const m=JSON.parse(str);if(m.type==='ROOM_JOIN'){const u={id:'demo_a',name:'A TEST',mark:'A',team:'ally',ownerId:'p1',x:2,y:2};onMessage(JSON.stringify({schema:T.SCHEMA,type:'ROOM_JOINED',roomId:'arena-test',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'P1',role:'player'}],snapshot:{n:7,walls:[],units:[u]}}));}
  if(m.type==='ROOM_RECEIPT_QUERY')onMessage(JSON.stringify({schema:T.SCHEMA,type:'ROOM_RECEIPT',roomId:'arena-test',revision:0,seq:0,intentId:m.intentId,status:'NOT_FOUND'}));};
  return {send,close:()=>onClose()};};
 const fourth=new T.RoomClient({transportFactory:fakeFactory,protocol:'v2',nonce:'testnotfound',journalStore:mkStore()});fourth.connect('p1');fourth.sendIntent('demo_a',3,2);
 assert('No answer leaves pending',fourth.pending.size===1);
 fourth.queryReceipt();
 assert('NOT_FOUND does not clear unknown',fourth.pending.size===1&&fourth.status==='unknown'&&fourth.pending.values().next().value.state==='NOT_FOUND');
 assert('Unknown blocks new command IDs',!fourth.sendIntent('demo_a',4,2));
 rawV2.close();peer1.close();peer2.close();first.disconnect();second.disconnect();third.disconnect();fourth.disconnect();
 return checks;
}'''
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=await b.new_page(viewport={'width':390,'height':844})
  await mount(p);await p.add_script_tag(content=V2)
  results=await p.evaluate(JS)
  failed=[x for x in results if not x['pass']]
  print('Recovery + security tests',len(results)-len(failed),'/',len(results),'PASS' if not failed else failed)
  await b.close()
if __name__=='__main__':asyncio.run(main())
