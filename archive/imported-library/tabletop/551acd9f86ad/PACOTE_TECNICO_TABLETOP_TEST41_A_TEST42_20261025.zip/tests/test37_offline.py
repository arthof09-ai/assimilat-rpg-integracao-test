"""Actual Chromium execution of inline hash-CSP offline TEST37; no Android/WSS claim."""
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];FILE=ROOT/'dist/TABLETOP_ASSIMILACAO_TEST37_OFFLINE.html'
async def main():
 assert FILE.exists(),FILE
 outcomes=[]
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in ((360,740),(390,844),(844,390),(1100,850)):
   p=await b.new_page(viewport={'width':w,'height':h},accept_downloads=True)
   errors=[];req=[]
   p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda e:req.append(e.url))
   await p.set_content(FILE.read_text())
   checks=[]
   async def ck(label,condition):
    if not condition:raise AssertionError(f'{w}x{h} {label}: {errors}')
    checks.append(label)
   await ck('TEST37 title','TEST 37' in await p.locator('.header').text_content())
   await ck('old Arena intact',await p.locator('.tile').count()==49)
   await ck('action panel available',await p.locator('#tacticToggle').count()==1)
   await ck('arena visible',await p.locator('.viewport').evaluate('(e)=>e.getBoundingClientRect().top<innerHeight'))
   await ck('selected actor', 'Exploradora' in await p.locator('#tacticActor').inner_text())
   await p.locator('#tacticToggle').click()
   await ck('action options exposed',await p.locator('#tacticAction').is_visible())
   await p.select_option('#tacticAction','attack')
   await p.evaluate('window.__tabletopTEST.cell(5,2)')
   await ck('test targeting works','MECÂNICA INDISPONÍVEL' in await p.locator('#tacticReadout').inner_text())
   await p.locator('#tacticCancel').click()
   await ck('cancel no pending intent',(await p.evaluate('window.__tabletopTEST.tactical()'))['draft'] is None)
   await ck('room module',await p.evaluate('typeof window.TabletopRoomTEST==="object"'))
   await ck('no JavaScript error',not errors)
   await ck('no external HTTP request',not req)
   outcomes.append({'viewport':f'{w}x{h}','checks':len(checks),'names':checks})
   print(w,h,len(checks),'PASS')
   await p.close()
  await b.close()
 (ROOT/'evidence/TEST37_offline_results.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2))
 print('TOTAL',sum(x['checks'] for x in outcomes))
if __name__=='__main__':asyncio.run(main())
