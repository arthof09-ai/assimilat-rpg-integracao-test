import asyncio,sys
sys.path.insert(0,'/mnt/data/tabletop_25d/test42/tests')
from test42_25d import mount, OUT
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(360,740),(1100,850)]:
   pg=await b.new_page(viewport={'width':w,'height':h},is_mobile=w<700,has_touch=w<700)
   await mount(pg)
   await pg.screenshot(path=str(OUT/f'TEST42_INITIAL_{w}x{h}.png'),full_page=False)
   await pg.evaluate('window.__tabletopTEST.setProjectionMode("iso")')
   await pg.locator('#arenaTools summary').click()
   await pg.locator('[data-mode="wall"]').click()
   await pg.locator('.tile[data-xy="3,5"]').click(force=True)
   await pg.locator('.tile[data-xy="3,4"]').click(force=True)
   await pg.locator('[data-mode="play"]').click()
   await pg.locator('#arenaTools summary').click()
   await pg.screenshot(path=str(OUT/f'TEST42_WALLS_{w}x{h}.png'),full_page=False)
   await pg.close()
  await b.close()
asyncio.run(main())
