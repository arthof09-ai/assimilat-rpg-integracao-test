"""Negative journal persistence/ACK ordering TEST35 (fixture, no real server)."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
from test_room_browser import mount
JS=r'''() => {
 const T=window.TabletopRoomTEST,results=[];
 const check=(name,x)=>{results.push(name);if(!x)throw Error(name)};
 const snap={n:7,walls:[],units:[{id:'demo_a',name:'A',mark:'A',team:'ally',ownerId:'p1',x:1,y:1}]};
 for(const kind of ['setItemThrow','readbackThrow','readbackMismatch']){
  let wire=[],emit,raw='';const store={getItem:()=>{if(kind==='readbackThrow'&&raw)throw Error('read fail');return kind==='readbackMismatch'&&raw?'different':raw||null;},setItem:(_k,v)=>{if(kind==='setItemThrow')throw Error('quota');raw=v;}};
  const tr=({onMessage})=>{emit=onMessage;return {send:p=>wire.push(JSON.parse(p)),close:()=>{}}};
  const c=new T.RoomClient({transportFactory:tr,nonce:'storagecase',protocol:'v2',journalStore:store});
  c.connect('p1');emit(JSON.stringify({schema:T.SCHEMA,type:'ROOM_JOINED',roomId:'arena-test',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'P1',role:'player'}],snapshot:snap}));
  check('Connected before '+kind,c.connected);
  check('Reject unrecorded command '+kind,c.sendIntent('demo_a',2,2)===false);
  check('Never sent failed-journal INTENT '+kind,wire.filter(m=>m.type==='ROOM_INTENT').length===0);
  check('Failed journal does not mutate snapshot '+kind,c.snapshot.units[0].x===1);
  c.disconnect();
 }
 // Receipt for different command must NOT clear uncertain state.
 let wire=[],emit;const tr=({onMessage})=>{emit=onMessage;return {send:p=>wire.push(JSON.parse(p)),close:()=>{}}};
 let persistent=null;const c=new T.RoomClient({transportFactory:tr,nonce:'mismatched',protocol:'v2',journalStore:{getItem:()=>persistent,setItem:(_k,v)=>{persistent=String(v)}}});c.connect('p1');emit(JSON.stringify({schema:T.SCHEMA,type:'ROOM_JOINED',roomId:'arena-test',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'P1',role:'player'}],snapshot:snap}));c.sendIntent('demo_a',2,2);
 emit(JSON.stringify({schema:T.SCHEMA,type:'ROOM_RECEIPT',roomId:'arena-test',revision:1,seq:1,intentId:'other_command',status:'ACCEPTED'}));
 check('Unknown receipt cannot clear original',c.pending.size===1);
 check('Unknown receipt causes error without applying snapshot',c.snapshot===null&&c.revision===0);
 check('Unknown receipt remains unresolved',c.pending.size===1&&c.pending.values().next().value.state==='UNKNOWN');
 c.disconnect();
 return results;
}'''
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=await b.new_page()
  await mount(p);r=await p.evaluate(JS);print('Journal fail-closed + receipts',len(r),'/',len(r),'PASS');await b.close()
if __name__=='__main__':asyncio.run(main())
