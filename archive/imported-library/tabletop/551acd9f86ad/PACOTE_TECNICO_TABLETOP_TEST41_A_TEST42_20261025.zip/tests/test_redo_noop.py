import asyncio, re, pathlib, json, sys
from playwright.async_api import async_playwright
PUBLIC=pathlib.Path(__file__).resolve().parents[1]/'public'
HTML=(PUBLIC/'index.html').read_text().replace('<details id="arenaTools"','<details open id="arenaTools"'); JS=(PUBLIC/'app.js').read_text(); CSS=(PUBLIC/'styles.css').read_text()
async def mount(page):
    html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',HTML).replace('<link rel="stylesheet" href="styles.css">','').replace('<script src="app.js" defer></script>','').replace('<script src="room-client.js" defer></script>','')
    await page.set_content(html)
    await page.evaluate('''() => {window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return window.__store[k]??null},setItem(k,v){window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}});}''')
    await page.add_style_tag(content=CSS);await page.add_script_tag(content=JS)
async def has_wall(page): return await page.evaluate("window.__tabletopTEST.scene().walls.includes('4,4')")
async def start_wall_undo(page):
    await page.locator('[data-mode="wall"]').click()
    await page.evaluate('window.__tabletopTEST.cell(4,4)')
    assert await has_wall(page), 'wall missing before undo'
    await page.evaluate('window.__tabletopTEST.undo()')
    assert not await has_wall(page), 'undo failed'
async def marker_test(b,viewport):
    ctx=await b.new_context(viewport=viewport);p=await ctx.new_page();await mount(p)
    await p.locator('[data-mode="mark"]').click();await p.evaluate('window.__tabletopTEST.cell(3,3)')
    await p.locator('#markerText').fill('Marco TEST');await p.locator('#markerSave').click()
    await start_wall_undo(p)
    await p.locator('[data-mode="mark"]').click();await p.evaluate('window.__tabletopTEST.cell(3,3)')
    assert await p.locator('#markerDialog').is_visible()
    await p.locator('#markerSave').click() # same payload; should be no-op
    await p.evaluate('window.__tabletopTEST.redo()')
    ok=await has_wall(p)
    await ctx.close();return ok
async def notes_test(b,viewport):
    ctx=await b.new_context(viewport=viewport);p=await ctx.new_page();await mount(p)
    await start_wall_undo(p)
    await p.locator('#sceneNotes').evaluate('(el)=>{el.value="";el.dispatchEvent(new Event("change",{bubbles:true}));}')
    await p.evaluate('window.__tabletopTEST.redo()')
    ok=await has_wall(p)
    await ctx.close();return ok
async def rename_test(b,viewport):
    ctx=await b.new_context(viewport=viewport);p=await ctx.new_page();await mount(p)
    await start_wall_undo(p)
    await p.evaluate('window.prompt=(msg,value)=>value;')
    await p.locator('#renameScene').click()
    await p.evaluate('window.__tabletopTEST.redo()')
    ok=await has_wall(p)
    await ctx.close();return ok
async def run():
    mode=sys.argv[1] if len(sys.argv)>1 else 'green'
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        all_results=[]
        for wh in [(390,844),(360,740)]:
            viewport={'width':wh[0],'height':wh[1]}
            for label,fn in [('marker no-op',marker_test),('notes no-op',notes_test),('rename no-op',rename_test)]:
                result=await fn(browser,viewport)
                all_results.append(result)
                print(f'{wh[0]}x{wh[1]} {label}: {"PASS" if result else "FAIL"}')
        await browser.close()
    print(f'{sum(all_results)}/{len(all_results)} PASS')
    if mode=='green' and not all(all_results):sys.exit(1)
    if mode=='red' and all(all_results):sys.exit(1)
if __name__=='__main__':asyncio.run(run())
