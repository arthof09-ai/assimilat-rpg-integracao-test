"""TEST41: actual Chromium page/UI+RoomClient/native_port with mocked fetch.
NO browser HTTP claim; verifies cold reopen, profile, room scope, no duplicate send.
"""
import asyncio,json,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
NATIVE=(ROOT/'connected_test/native_port.js').read_text()
assert "const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&" in NATIVE
NATIVE=NATIVE.replace("const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&", "const enabled=true &&")
async def mount(page,raw=None):
    html=(ROOT/'public/index.html').read_text()
    html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html)
    html=html.replace('<link rel="stylesheet" href="styles.css">','')
    for name in ('app.js','room-v2-adapter.js','room-client.js'):
        html=html.replace(f'<script src="{name}" defer></script>','')
    await page.set_content(html)
    await page.evaluate('''raw=>{const data={};if(raw!==null)data['assim-tabletop-room-pending-test']=raw;
     for(const field of ['localStorage','sessionStorage'])Object.defineProperty(window,field,{configurable:true,value:{getItem:k=>data[k]??null,setItem:(k,v)=>{data[k]=String(v)},removeItem:k=>{delete data[k]}}});}''',raw)
    await page.add_style_tag(content=(ROOT/'public/styles.css').read_text())
    for name in ('app.js','room-v2-adapter.js','room-client.js'):
        await page.add_script_tag(content=(ROOT/'public'/name).read_text())
    await page.evaluate('''()=>{
      window.calls41=[];
      window.fetch=async(url,options)=>{
       const packet=JSON.parse(options.body);window.calls41.push(packet);
       return {ok:true,text:async()=>JSON.stringify(packet.op==='receipt_query'?{ok:true,receipt:{client_action_id:packet.client_action_id,status:'REJECTED',code:'MECHANICS_UNAVAILABLE',revision:0,receipt_id:'receipt-real-proxy-fixture'}}:{ok:true,receipt:{client_action_id:packet.client_action_id,status:'REJECTED',code:'MECHANICS_UNAVAILABLE',revision:0,receipt_id:'receipt-real-proxy-fixture'}})};
      };
      window.PonteTEST={request:()=>{}};
      const c=window.TabletopRoomTEST.client;c.protocol='v2';c.profile='p1';c.selfId='p1';c.role='player';c.connected=true;c.selfId='p1';c.role='player';c.revision=0;
      let e=document.getElementById('bridgeResult');if(!e){e=document.createElement('p');e.id='bridgeResult';document.body.append(e)};
      e.textContent='Cena visual TEST importada · SHA fixture';
    }''')
    await page.add_script_tag(content=NATIVE)

async def main():
 results=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for w,h in [(390,844),(360,740)]:
   checks=[]
   def ck(name,ok):
    if not ok:raise AssertionError(f'{w}x{h}: {name}')
    checks.append(name)
   p=await browser.new_page(viewport={'width':w,'height':h},has_touch=True,is_mobile=True)
   await mount(p)
   ck('native port active under fixture',await p.evaluate('window.TabletopNativeTEST.ready()'))
   await p.locator('#tacticToggle').click();await p.locator('#tacticAction').select_option('attack');await p.locator('.tile[data-xy="5,2"]').click(force=True)
   await p.evaluate('window.TabletopNativeTEST.loseNextAttackAck()');await p.locator('#tacticConfirm').click()
   await p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
   raw=await p.evaluate('localStorage.getItem(window.TabletopRoomTEST.client.journalKey)')
   saved=json.loads(raw);id=saved['external']['payload']['commandId']
   ck('journal in existing v1 key',saved['version']==1 and len(saved['entries'])==0)
   ck('context persisted inside external entry',saved['external']['payload']['sceneId']=='c1' and saved['external']['payload']['actorId']=='u1' and saved['external']['payload']['targetId']=='u3')
   ck('new scoped journal',saved['external'].get('scope')=={'roomId':'arena-test','principalId':'p1'})
   ck('single submit happened',await p.evaluate('window.calls41.filter(x=>x.op==="submit").length')==1)
   await p.close()
   # New REAL Chromium page, fresh JS objects, exact previous journal bytes.
   p=await browser.new_page(viewport={'width':w,'height':h},has_touch=True,is_mobile=True)
   await mount(p,raw)
   ck('cold restored original ID',await p.evaluate('window.__tabletopTEST.authority()?.id')==id)
   ck('cold restored original origin',await p.evaluate('window.__tabletopTEST.authority()?.origin?.sceneId')=='c1')
   await p.evaluate('window.__tabletopTEST.createScene()')
   ck('scene switched to c2',await p.evaluate('window.__tabletopTEST.scene().id')=='c2')
   ck('cold HUD identifies original and active scenes','CENA c1' in await p.locator('#tacticAuthorityState').inner_text() and 'c2' in await p.locator('#tacticAuthorityState').inner_text())
   ck('tactical readout identifies original scene','c1' in await p.locator('#tacticReadout').inner_text() and 'c2' in await p.locator('#tacticReadout').inner_text())
   await p.evaluate('window.TabletopRoomTEST.client.profile="p2"')
   ck('p2 cannot query with p1 token',not await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
   ck('p2 query throws before HTTP',await p.evaluate('''async()=>{try{await window.TabletopTestAuthorityPort.query(window.__tabletopTEST.authority().id);return false}catch(e){return /receipt-id-not-journaled/.test(String(e))}}'''))
   ck('p2 cannot finish journal',not await p.evaluate('''()=>window.TabletopTestAuthorityPort.finish(window.__tabletopTEST.authority().id,'REJECTED')'''))
   ck('journal preserved on failed role switch',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()?.payload.commandId')==id)
   ck('no fetch leaked under p2',await p.evaluate('window.calls41.length')==0)
   await p.evaluate('window.TabletopRoomTEST.client.profile="p1"')
   ck('restored p1 may query',await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
   await p.locator('#tacticToggle').click()
   await p.locator('#tacticAuthorityQuery').click()
   await p.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
   ck('same original receipt recovered','MECHANICS_UNAVAILABLE' in await p.locator('#tacticAuthorityState').inner_text())
   ck('query single ID same room',await p.evaluate('window.calls41.length===1&&window.calls41[0].op==="receipt_query"&&window.calls41[0].room_id==="arena-test"&&window.calls41[0].client_action_id===window.__tabletopTEST.authority().id'))
   ck('journal cleared only after proper role',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()===null'))
   ck('no combat changes in either scene',await p.evaluate('window.__tabletopTEST.state().scenes.every(s=>s.units[0].hp===100&&s.units[0].pa===60)'))
   await p.screenshot(path=str(ROOT/'evidence'/f'TEST41_COLD_SCENE_ROLE_{w}x{h}.png'))
   await p.close()
   results.append({'viewport':f'{w}x{h}','assertions':checks})
  await browser.close()
 (ROOT/'evidence'/'TEST41_cold_profile_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
 print('TEST41 cold Chromium independent pages + scope/profile + recovery:',sum(len(x['assertions']) for x in results),'PASS; HTTP mocked explicitly')
if __name__=='__main__':asyncio.run(main())
