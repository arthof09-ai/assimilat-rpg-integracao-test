"""Genuine Node JS fetch -> Original Codex Authority HTTP/SQLite; NOT Chromium native."""
from pathlib import Path
import os
import json,subprocess,tempfile,sys,threading,sqlite3,hashlib,os
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'connected_test'))
from start_test40 import stage
with tempfile.TemporaryDirectory(prefix='test40-native-node-') as td:
 d=Path(td);serv=stage(Path(os.environ.get('TEST40_CODEX_ZIP','/mnt/data/ponte-vlab-tabletop-0.4.0-test38.zip')),d/'runtime');sys.path.insert(0,str(serv))
 from authority import Authority,make_server
 db=d/'db.sqlite';server=make_server(Authority(db),0,arena_assets=True);port=server.server_port
 threading.Thread(target=server.serve_forever,daemon=True).start()
 env={**os.environ,'TEST40_URL':f'http://127.0.0.1:{port}/','TEST40_JOURNAL':str(d/'store.json')}
 r=subprocess.run(['node',str(ROOT/'tests/test40_native_node.mjs'),'submit'],capture_output=True,text=True,env=env,timeout=40)
 print(r.stdout,r.stderr);assert r.returncode==0,r.stderr
 server.shutdown();server.server_close()
 server=make_server(Authority(db),port,arena_assets=True);threading.Thread(target=server.serve_forever,daemon=True).start()
 r=subprocess.run(['node',str(ROOT/'tests/test40_native_node.mjs'),'recover'],capture_output=True,text=True,env=env,timeout=40)
 print(r.stdout,r.stderr);assert r.returncode==0,r.stderr
 server.shutdown();server.server_close()
 with sqlite3.connect(db) as conn:
  receipts=conn.execute('select count(*) from receipts').fetchone()[0]
  events=conn.execute('select count(*) from events').fetchone()[0]
  rev=conn.execute('select revision from rooms').fetchone()[0]
  assert (receipts,events,rev)==(1,0,0),(receipts,events,rev)
 print('PASS 2 phases; actual HTTP from Node fetch (not Playwright): 1 persisted receipt; 0 events; rev0')
