"""A REAL Codex0.3 Authority/SQLite/HTTP, with the unchanged TEST39 Arena DOM.
Browser -> Playwright host binding -> real Codex HTTP 127.0.0.1 -> SQLite.
Host binding is a TEST transport fixture. It is NOT native browser HTTP,
WSS, production login, VLAB or a new room authority.
"""
from __future__ import annotations
import asyncio
import os
import json
import re
import sys
import tempfile
import threading
import urllib.request
import urllib.error
from pathlib import Path
from playwright.async_api import async_playwright
from test39_mount import mount

ROOT=Path(__file__).resolve().parents[1]
CODEX=Path(os.environ.get('CODEX_BRIDGE_ROOT',str(ROOT/'external_codex_unpacked'/'experiments'/'tabletop_vlab_bridge')))
sys.path.insert(0,str(CODEX))
from authority import Authority,make_server

def http_json(port,token,payload):
    raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
    req=urllib.request.Request(f'http://127.0.0.1:{port}/bridge',data=raw,
      headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    try:
      with urllib.request.urlopen(req,timeout=10) as resp:return resp.status,json.loads(resp.read())
    except urllib.error.HTTPError as error:return error.code,json.loads(error.read())

def receipt_brief(response,expected):
    if response.get('op')=='receipt_query' and response.get('lookup')=='NOT_FOUND':
      return {'commandId':expected,'status':'NOT_FOUND'}
    r=response.get('receipt') or {}
    if r.get('client_action_id')!=expected or r.get('status') not in {'ACCEPTED','REJECTED'}:
      return {'commandId':expected,'status':'NOT_FOUND'}
    return {'commandId':expected,'status':r['status'],'code':r.get('code'),'revision':r.get('revision'),'receiptId':r.get('receipt_id')}


async def run_browser(browser,w,h,server_ctx,flags):
    p=await browser.new_page(viewport={'width':w,'height':h},has_touch=w<800,is_mobile=w<800)
    errors=[];p.on('pageerror',lambda x:errors.append(str(x)))
    seen=[]
    def send(payload):
      assert set(payload)=={'commandId','sceneId','actorId','targetId','action'}
      assert payload['sceneId']=='c1' and payload['actorId']=='u1' and payload['targetId']=='u3'
      assert payload['action']=='ATTACK_REQUEST' and re.fullmatch(r'bridge39_\d+',payload['commandId'])
      sent={'schema_version':2,'op':'submit','room_id':'battle39','client_action_id':payload['commandId'],
        'expected_revision':0,'actor_id':'actor-1',
        'action':{'kind':'ATTACK_REQUEST','target':{'kind':'UNIT','actor_id':'actor-2'},'turn_id':'turn-test-1',
          'context':{'scene_id':'scene-test-1','ability_id':'basic-attack'}}}
      status,result=http_json(server_ctx['port'],'FAKE_TEST_PLAYER1',sent);seen.append({'kind':'submit','request':sent,'http':status,'result':result})
      assert status==200 and result['receipt']['status']=='REJECTED' and result['receipt']['code']=='MECHANICS_UNAVAILABLE'
      if flags.get('drop_ack'):flags['drop_ack']=False;raise RuntimeError('Injected loss of HTTP response AFTER durable COMMIT')
      return receipt_brief(result,payload['commandId'])
    def query(command_id):
      assert re.fullmatch(r'bridge39_\d+',command_id)
      request={'schema_version':2,'op':'receipt_query','room_id':'battle39','client_action_id':command_id}
      status,result=http_json(server_ctx['port'],'FAKE_TEST_PLAYER1',request)
      seen.append({'kind':'query','request':request,'http':status,'result':result})
      assert status==200
      return receipt_brief(result,command_id)
    await p.expose_function('integrationSubmitRealHTTP',send)
    await p.expose_function('integrationQueryRealHTTP',query)
    await mount(p)
    checks=[]
    async def chk(label,value):
      if not value:raise AssertionError(f'{w}x{h} {label}, errors={errors}')
      checks.append(label)
    await chk('Arena TEST39 original grid',await p.locator('.tile').count()==49)
    await chk('No network port by default',await p.evaluate('window.TabletopTestAuthorityPort===undefined'))
    await chk('mechanical gate visible','Mecânica VLAB indisponível' in await p.locator('#tacticAuthorityState').inner_text())
    before=await p.evaluate('window.__tabletopTEST.state()')
    await p.locator('#tacticToggle').click()
    await p.locator('#tacticAction').select_option('attack')
    await p.locator('.tile[data-xy="5,2"]').click(force=True)
    await p.locator('#tacticConfirm').click()
    await chk('without transport no send','NÃO ENVIADA' in await p.locator('#tacticReadout').inner_text())
    await chk('without transport workspace untouched',before==await p.evaluate('window.__tabletopTEST.state()'))
    # The harness mounts a TEST-only explicit capability. No key/token is sent to browser.
    await p.evaluate('''() => {let serial=0;window.TabletopTestAuthorityPort={newId:()=>`bridge39_${++serial}`,send:request=>window.integrationSubmitRealHTTP(request),query:id=>window.integrationQueryRealHTTP(id)};document.querySelector('#tacticAuthorityState').textContent='Servidor local de laboratório disponível (fixture), VLAB HOLD';}''')
    await p.locator('#tacticAction').select_option('attack')
    await p.locator('.tile[data-xy="5,2"]').click(force=True)
    flags['drop_ack']=True
    await p.locator('#tacticConfirm').click()
    await p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
    await chk('ACK lost shows UNKNOWN', 'UNKNOWN' in await p.locator('#tacticAuthorityState').inner_text())
    cid=await p.evaluate('window.__tabletopTEST.authority().id')
    await chk('original command ID preserved',cid=='bridge39_1')
    await chk('UNKNOWN forbids implicit resend', len([v for v in seen if v['kind']=='submit'])==1)
    server_ctx['restart']() # Actual HTTP server closed/reopened over SAME SQLite DB.
    await chk('server restarted after durable commit',server_ctx['restarts']==1)
    await chk('query button enabled',not await p.locator('#tacticAuthorityQuery').is_disabled())
    await p.locator('#tacticAuthorityQuery').click()
    await p.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
    await chk('durable server receipt recovered','MECHANICS_UNAVAILABLE' in await p.locator('#tacticAuthorityState').inner_text())
    await chk('same ID queried',seen[-1]['kind']=='query' and seen[-1]['request']['client_action_id']==cid)
    await chk('receipt detail in HUD','REJEIÇÃO MECHANICS_UNAVAILABLE' in await p.locator('#tacticReadout').inner_text())
    await chk('never changes workspace',before==await p.evaluate('window.__tabletopTEST.state()'))
    await chk('receipt query no duplicate effect', len([v for v in seen if v['kind']=='submit'])==1)
    await chk('query button disables after receipt',await p.locator('#tacticAuthorityQuery').is_disabled())
    await chk('no JS error',not errors)
    if w==390:
      path=ROOT/'evidence'/'TEST39_REAL_CODEX_RECEIPT_390x844.png'
      path.parent.mkdir(exist_ok=True,parents=True)
      await p.screenshot(path=str(path),full_page=False)
    await p.close()
    return {'viewport':f'{w}x{h}','checks':checks,'wire':seen}

async def main():
    with tempfile.TemporaryDirectory(prefix='codex-existing-test-') as tmp:
      async with async_playwright() as pw:
        browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        results=[]
        from sqlite3 import connect
        for i,(w,h) in enumerate([(390,844),(360,740)]):
          db=Path(tmp)/f'authority{i}.sqlite'
          authority=Authority(db);server=make_server(authority,0)
          threading.Thread(target=server.serve_forever,daemon=True).start()
          server_ctx={'port':server.server_port,'restarts':0}
          def restart():
            nonlocal server
            server.shutdown();server.server_close()
            server=make_server(Authority(db),0)
            threading.Thread(target=server.serve_forever,daemon=True).start()
            server_ctx['port']=server.server_port;server_ctx['restarts']+=1
          server_ctx['restart']=restart
          status,created=http_json(server_ctx['port'],'FAKE_TEST_MASTER',{'schema_version':1,'op':'create','room_id':'battle39',
            'client_action_id':'bootstrap39','expected_revision':0})
          assert status==200 and created.get('ok')
          status,view=http_json(server_ctx['port'],'FAKE_TEST_PLAYER1',{'schema_version':1,'op':'view','room_id':'battle39'})
          assert status==200 and view['view']['own_actor_id']=='actor-1'
          assert {'actor-1','actor-2'}.issubset({u['actor_id'] for u in view['view']['actors']})
          out=await run_browser(browser,w,h,server_ctx,{'drop_ack':False});results.append(out)
          print('REAL_AUTHORITY',w,h,len(out['checks']),'PASS with REAL server restart',flush=True)
          q=out['wire'][-1]
          assert q['result']['receipt']['client_action_id']=='bridge39_1'
          assert q['result']['receipt']['status']=='REJECTED'
          assert q['result']['receipt']['code']=='MECHANICS_UNAVAILABLE'
          server.shutdown();server.server_close()
          with connect(db) as con:
            receipts=con.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]
            events=con.execute('SELECT COUNT(*) FROM events').fetchone()[0]
            assert receipts==1 and events==0,(db,receipts,events)
        await browser.close()
      result={'kind':'REAL_CODEX_030_HTTP_SERVER_WITH_BROWSER_HOST_BINDING', 'server_restarted_between_ack_loss_and_query':True,
        'browser_http_direct':False,'codex_original_source_changed':False,'mechanics_official_executed':False,
        'chrome_android_physical':False,'results':results,'server_persistence':'SQLite receipts 1, events 0 per case; server restarted'}
      (ROOT/'evidence'/'TEST39_real_http_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
      print('TOTAL CHECKS',sum(len(x['checks']) for x in results),'PASS')

if __name__=='__main__':asyncio.run(main())
