"""Selective reproducible gate. Separate directed vs generated counts.
Test frontend only; no server, TLS, authenticated Party or Android hardware.
"""
from pathlib import Path
import subprocess,sys,json,time,re
ROOT=Path(__file__).resolve().parents[1]
CASES=[
 ('journal_red_green','test36_journal_safety.py',['--expect-green'],28,0),
 ('v1_browser','test_room_browser.py',[],60,0),
 ('v1_protocol','test_room_protocol.py',[],37,180),
 ('v2_browser','test_test35_v2.py',[],54,0),
 ('v2_recovery_security','test_test35_recovery_security.py',[],34,0),
 ('receipt_failclosed','test35_journal_failclosed.py',[],15,0),
 ('history_noop','test33_history_contract.py',[],30,0),
 ('redo_noop','test_redo_noop.py',[],6,0),
 ('legacy_test03','test_legacy_replay.py',[],3,0),
 ('arena','test_integrated.py',[],128,0),
 ('offline','test36_offline.py',[],16,0),
]
records=[];total=0;generated=0
for name,filename,args,expected,gen in CASES:
 result=subprocess.run([sys.executable,str(ROOT/'tests'/filename),*args],capture_output=True,text=True,timeout=95,cwd=str(ROOT/'tests'))
 output=result.stdout+'\n'+result.stderr
 # Number of executable assertions comes from named verified suites, not stdout line counts.
 assert result.returncode==0,(name,output)
 if name=='legacy_test03':assert 'legacy loaded True counter 1/4 state unmoved True' in output
 elif name=='redo_noop':assert '6/6 PASS' in output
 elif name=='journal_red_green':assert output.count('14/14 PASS')==2
 else:
  match=re.search(r'(\d+)\s*/\s*(\d+)\s*PASS',output)
  assert match,(name,output)
  if name not in ('v1_browser','v2_browser','history_noop','arena','offline'):
   assert int(match.group(1))==expected,(name,output)
  if name in ('v1_browser','v2_browser','history_noop','arena','offline'):
   counts=[(int(a),int(b)) for a,b in re.findall(r'(\d+)\s*/\s*(\d+)\s*PASS',output)]
   assert (len(counts)==2 and counts==[(64,64),(64,64)] and 'TOTAL PASSES 128' in output) if name=='arena' else any(a==expected and b==expected for a,b in counts),(name,counts)
 if gen:assert f'{gen}/{gen}' in output,(name,output)
 records.append({'suite':name,'script':filename,'directed_pass':expected,'directed_total':expected,'generated_pass':gen,'generated_total':gen,'status':'PASS'})
 total+=expected;generated+=gen
 print(f'{name} {expected}/{expected} PASS'+(f'; generated {gen}/{gen}' if gen else ''),flush=True)
res={'label':'TEST36 Chromium Linux Playwright targeted execution','chromium':'/usr/bin/chromium','environment':'set_content, injected sessionStorage for browser-suite; standalone hashed CSP; no real network','directed_pass':total,'directed_total':total,'generated_pass':generated,'generated_total':generated,'suites':records}
(ROOT/'evidence/GATE_TEST36_RESULT.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print('TOTAL DIRECTED',total,'/',total,'PASS; GENERATIVE',generated,'/',generated,'PASS')
