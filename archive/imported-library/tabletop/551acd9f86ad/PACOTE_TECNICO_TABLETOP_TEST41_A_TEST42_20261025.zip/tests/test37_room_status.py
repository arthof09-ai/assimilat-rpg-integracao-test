import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
from test37_tactical import mount
async def main():
 outcome=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(360,740),(390,844)]:
   p=await browser.new_page(viewport={'width':w,'height':h},has_touch=True,is_mobile=True)
   errors=[];p.on('pageerror',lambda x:errors.append(str(x)))
   await mount(p)
   a=[]
   async def ck(name,pred):
    if not pred:raise AssertionError(f'{w}x{h} {name} {errors}')
    a.append(name)
   await p.locator('#tacticToggle').tap()
   await ck('initial disconnected', 'Desconectado' in await p.locator('#tacticRoomState').inner_text())
   await p.locator('#tacticRoomJump').tap()
   await ck('jump room reachable',await p.evaluate('document.querySelector("#roomPanel").getBoundingClientRect().top<innerHeight'))
   await p.locator('#roomConnect').tap()
   await ck('legacy fixture connects',await p.evaluate('window.TabletopRoomTEST.client.connected'))
   await ck('HUD mirrors state','DEMO conectada' in await p.locator('#tacticRoomState').inner_text())
   await ck('HUD warns no tactical server','NÃO transmitidas' in await p.locator('#tacticRoomState').inner_text())
   await p.locator('#roomDisconnect').tap()
   await ck('status disconnect','Desconectado' in await p.locator('#tacticRoomState').inner_text())
   await p.locator('#roomProtocol').select_option('v2')
   await p.locator('#roomConnect').tap()
   await ck('v2 demo connects',await p.evaluate('window.TabletopRoomTEST.client.connected'))
   await ck('v2 status reflected','DEMO conectada' in await p.locator('#tacticRoomState').inner_text())
   await ck('no JS errors',not errors)
   outcome.append({'viewport':f'{w}x{h}','count':len(a),'cases':a})
   print(w,h,len(a),'PASS')
   await p.close()
  await browser.close()
 (Path(__file__).resolve().parents[1]/'evidence/TEST37_room_status.json').write_text(json.dumps(outcome,indent=2,ensure_ascii=False))
asyncio.run(main())
