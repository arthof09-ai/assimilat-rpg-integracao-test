import asyncio,pathlib,json
from playwright.async_api import async_playwright
from test_integrated import mount,ROOT
LEGACY=ROOT.parent/'tests'/'fixtures'/'legacy_test03.json'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':390,'height':844})
  await mount(page)
  original=await page.evaluate('window.__tabletopTEST.state()')
  await page.locator('#replayImport').set_input_files(str(LEGACY))
  await page.wait_for_timeout(80)
  result=await page.evaluate('window.__tabletopTEST.replay()')
  print('legacy loaded',bool(result),'counter',await page.locator('#replayCounter').inner_text(),'state unmoved',original==await page.evaluate('window.__tabletopTEST.state()'),'message',await page.locator('#message').inner_text())
  assert result and len(result['events'])==4
  assert original==await page.evaluate('window.__tabletopTEST.state()')
  await page.locator('#replaySeek').fill('3')
  await page.locator('#replaySeek').dispatch_event('input')
  assert '4/4'==await page.locator('#replayCounter').inner_text()
  await browser.close()
if __name__=='__main__':asyncio.run(main())
