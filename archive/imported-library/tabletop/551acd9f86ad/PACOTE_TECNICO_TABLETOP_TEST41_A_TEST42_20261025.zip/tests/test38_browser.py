import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test37_tactical import mount
OUT=Path(__file__).resolve().parents[1]/'evidence';OUT.mkdir(exist_ok=True)

async def run(browser,w,h):
 page=await browser.new_page(viewport={'width':w,'height':h},is_mobile=w<800,has_touch=w<800)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 await mount(page)
 passed=[]
 async def check(name,cond):
  if not cond:raise AssertionError(f'{w}x{h} {name}: {errors}')
  passed.append(name)
 async def js(src):return await page.evaluate(src)
 await check('arena exists',await page.locator('.tile').count()==49)
 await check('receipt summary present',await page.locator('#roomLastOutcome').count()==1)
 await check('receipt shortcut disabled',await page.locator('#tacticReceiptQuery').is_disabled())
 await check('initial state demo disclaimer','NÃO transmitidas' in await page.locator('#tacticRoomState').inner_text())
 await page.locator('#tacticToggle').click()
 await page.locator('#tacticAction').select_option('attack')
 await page.locator('.tile[data-xy="5,2"]').click(force=True)
 initial=await js('window.__tabletopTEST.state()')
 await page.locator('#tacticConfirm').click()
 await check('unavailable mechanic visible','MECÂNICA INDISPONÍVEL' in await page.locator('#tacticReadout').inner_text())
 await check('tactical not transmitted','NÃO ENVIADA' in await page.locator('#tacticReadout').inner_text())
 await check('tactical keeps workspace',await js('window.__tabletopTEST.state()')==initial)
 await page.locator('#roomProtocol').select_option('v2')
 await page.locator('#roomProfile').select_option('p1')
 await page.locator('#roomConnect').click()
 await check('v2 fixture connected',await js('window.TabletopRoomTEST.client.connected'))
 await check('connection HUD reflects fixture','DEMO conectada' in await page.locator('#tacticRoomState').inner_text())
 await check('journal enabled',await js('Boolean(window.TabletopRoomTEST.client.journalStore)'))
 await check('receipt shortcut still disabled',await page.locator('#tacticReceiptQuery').is_disabled())
 # Fabricate only the loss of the ACK inside the explicitly local fixture.
 await js('window.TabletopRoomV2TEST.mock.dropNextAck=true')
 await page.locator('#roomGrid .roomCell').nth(8).click(force=True)
 await page.locator('#roomGrid .roomCell').nth(16).click(force=True)
 await check('intention pending',await js('window.TabletopRoomTEST.client.pending.size')==1)
 await check('status pending',await js('window.TabletopRoomTEST.client.status')=='pending')
 await check('visible pending','pendente' in (await page.locator('#roomStatus').inner_text()).lower())
 await check('journal is on sessionStorage',await js('Boolean(sessionStorage.getItem("assim-tabletop-room-pending-test"))'))
 await check('HUD receipt enabled',not await page.locator('#tacticReceiptQuery').is_disabled())
 await check('no local arena mutation after remote intent',await js('window.__tabletopTEST.state()')==initial)
 await page.locator('#roomDisconnect').click()
 await check('unknown on lost ack',await js('window.TabletopRoomTEST.client.status')=='unknown')
 await check('same command preserved',await js('window.TabletopRoomTEST.client.pending.size')==1)
 await page.locator('#roomConnect').click()
 await check('receipt confirmed after rejoin',await js('window.TabletopRoomTEST.client.lastReceipt?.status')=='ACCEPTED')
 await check('outbox cleared after receipt',await js('window.TabletopRoomTEST.client.pending.size')==0)
 await check('receipt visible in room','ACCEPTED' in await page.locator('#roomLastOutcome').inner_text())
 await check('receipt visible in Arena HUD','ACCEPTED' in await page.locator('#tacticRoomState').inner_text())
 await check('short cut now disabled',await page.locator('#tacticReceiptQuery').is_disabled())
 await check('no mechanics invented','NÃO transmitidas' in await page.locator('#tacticRoomState').inner_text())
 # A second synthetic participant attempts a cell secretly occupied by a fixture unit.
 await page.locator('#roomProfile').select_option('p2')
 await page.locator('#roomConnect').click()
 await check('player p2 connected in fixture',await js('window.TabletopRoomTEST.client.connected&&window.TabletopRoomTEST.client.selfId==="p2"'))
 await page.locator('#roomGrid .roomCell').nth(29).click(force=True) # own actor at (1,4)
 await page.locator('#roomGrid .roomCell').nth(26).click(force=True) # hidden fixture enemy at (5,3)
 await check('rejected by fixture',await js('window.TabletopRoomTEST.client.lastReceipt?.status')=='REJECTED')
 await check('rejection reason explicit',await js('window.TabletopRoomTEST.client.lastReceipt?.reason')=='INVALID_INTENT')
 await check('rejection visible in HUD','REJECTED' in await page.locator('#tacticRoomState').inner_text())
 await check('rejection clears terminal pending',await js('window.TabletopRoomTEST.client.pending.size')==0)
 await check('foreign actor blocked before fixture send',not await js('window.TabletopRoomTEST.client.sendIntent("demo_a",2,2)'))
 await check('still no arena workspace mutation',await js('window.__tabletopTEST.state()')==initial)
 await check('no scripts errors',not errors)
 if w<800:
  await page.locator('#tacticRoomJump').click()
  await page.screenshot(path=str(OUT/f'TEST38_RECEIPT_{w}x{h}.png'),full_page=False)
 # Independent client on real code: generic update does not close pending.
 outcome=await js('''() => {
 const R=window.TabletopRoomTEST,schemas=R.SCHEMA;let sent=[];
 const client=new R.RoomClient({protocol:'v1',nonce:'inspect38',journalStore:null,transportFactory:()=>({send:r=>sent.push(JSON.parse(r)),close:()=>{}})});
 client.connect('p1'); const unit={id:'demo_a',name:'Unidade de prova',mark:'A',team:'ally',ownerId:'p1',x:1,y:1};
 const base={schema:schemas,roomId:'arena-test'};
 client.receive(JSON.stringify({...base,type:'ROOM_JOINED',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'P1',role:'player'}],snapshot:{n:7,units:[unit],walls:[]}}));
 const sentOk=client.sendIntent('demo_a',2,2),id=[...client.pending.keys()][0];
 client.receive(JSON.stringify({...base,type:'ROOM_EVENT',revision:1,seq:1,intentId:'event38',kind:'ROOM_UPDATED',actorId:'demo_a',snapshot:{n:7,units:[unit],walls:[]}}));
 const update={pending:client.pending.size,kind:client.lastRoomEvent?.kind,revision:client.revision,status:client.status,report:client.log[0]};
 client.receive(JSON.stringify({...base,type:'ROOM_EVENT',revision:2,seq:2,intentId:id,kind:'MOVE_CONFIRMED',actorId:'demo_a',snapshot:{n:7,units:[{...unit,x:2,y:2}],walls:[]}}));
 return {sentOk,update,move:{pending:client.pending.size,lastReceipt:client.lastReceipt?.status,lastEvent:client.lastRoomEvent?.kind},wire:sent.length};
 }''')
 await check('actual client command prepared',outcome['sentOk'])
 await check('ROOM_UPDATED preserves outbox',outcome['update']['pending']==1)
 await check('ROOM_UPDATED stays generic',outcome['update']['kind']=='ROOM_UPDATED')
 await check('ROOM_UPDATED explicit non move','NÃO é movimento' in outcome['update']['report'])
 await check('ROOM_UPDATED revision true',outcome['update']['revision']==1)
 await check('ROOM_UPDATED does not turn PENDING into UNKNOWN',outcome['update']['status']=='pending')
 await check('MOVE_CONFIRMED resolves v1 pending',outcome['move']['pending']==0)
 await check('MOVE_CONFIRMED explicit confirmed v1',outcome['move']['lastReceipt']=='CONFIRMED_BY_EVENT_V1')
 await check('MOVE_CONFIRMED actual kind',outcome['move']['lastEvent']=='MOVE_CONFIRMED')
 # same-position forged move is rejected, not announced.
 fail=await js('''() => {
 const R=window.TabletopRoomTEST;const c=new R.RoomClient({transportFactory:()=>({send:()=>{},close:()=>{}})});
 c.connect('p1');const u={id:'demo_a',name:'Ator',mark:'A',team:'ally',ownerId:'p1',x:1,y:1};const h={schema:R.SCHEMA,roomId:'arena-test'};
 c.receive(JSON.stringify({...h,type:'ROOM_JOINED',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'P1',role:'player'}],snapshot:{n:7,units:[u],walls:[]}}));
 c.receive(JSON.stringify({...h,type:'ROOM_EVENT',revision:1,seq:1,intentId:'intent_1',kind:'MOVE_CONFIRMED',actorId:'demo_a',snapshot:{n:7,units:[u],walls:[]}}));
 return {status:c.status,connected:c.connected,reason:c.error};
 }''')
 await check('same position fake move rejected',fail['status']=='error' and not fail['connected'])
 await check('error mentions no position change','sem alteração' in fail['reason'])
 await check('application remains error-free',not errors)
 await page.close()
 return {'viewport':f'{w}x{h}','count':len(passed),'cases':passed}
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  results=[]
  for w,h in [(360,740),(390,844),(1100,850)]:
   r=await run(browser,w,h);results.append(r);print(r['viewport'],r['count'],'PASS',flush=True)
  await browser.close()
 (OUT/'TEST38_browser_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
 print('TOTAL',sum(r['count'] for r in results))
asyncio.run(main())
