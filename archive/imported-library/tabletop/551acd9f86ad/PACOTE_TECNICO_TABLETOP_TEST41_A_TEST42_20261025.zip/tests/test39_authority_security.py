"""Independent security check against the SAME unmodified Codex 0.3 authority."""
from __future__ import annotations
from pathlib import Path
import json,sys,tempfile,sqlite3,os
ROOT=Path(__file__).resolve().parents[1]
CODEX=Path(os.environ.get('CODEX_BRIDGE_ROOT',str(ROOT/'external_codex_unpacked'/'experiments'/'tabletop_vlab_bridge')))
sys.path.insert(0,str(CODEX))
from authority import Authority
checks=[];trace=[]
def verify(label,condition):
 assert condition,label
 checks.append(label)
with tempfile.TemporaryDirectory(prefix='codex39-sec-') as tmp:
    auth=Authority(Path(tmp)/'auth.sqlite')
    def call(token,request):
        status,raw=auth.handle(json.dumps(request,separators=(',',':')).encode(),token)
        payload=json.loads(raw)
        trace.append({'who':token.replace('FAKE_TEST_','TEST_'), 'request':request,'status':status,'result':payload})
        return status,payload
    status,created=call('FAKE_TEST_MASTER',{'schema_version':1,'op':'create','room_id':'security39','client_action_id':'bootstrap39','expected_revision':0})
    verify('master creates synthetic room',status==200 and created.get('ok'))
    actions={'schema_version':2,'op':'submit','room_id':'security39','client_action_id':'security-id-1','expected_revision':0,'actor_id':'actor-1','action':{'kind':'ATTACK_REQUEST','target':{'kind':'UNIT','actor_id':'actor-2'},'turn_id':'t1','context':{'scene_id':'scene-test','ability_id':'attack-test'}}}
    st,rejected=call('FAKE_TEST_PLAYER1',actions)
    verify('mechanical command is durably rejected',st==200 and rejected['receipt']['code']=='MECHANICS_UNAVAILABLE' and rejected['receipt']['status']=='REJECTED')
    st,receipt=call('FAKE_TEST_PLAYER1',{'schema_version':2,'op':'receipt_query','room_id':'security39','client_action_id':'security-id-1'})
    verify('same person retrieves same receipt',st==200 and receipt.get('lookup')=='FOUND' and receipt['receipt']==rejected['receipt'])
    st,other=call('FAKE_TEST_PLAYER2',{'schema_version':2,'op':'receipt_query','room_id':'security39','client_action_id':'security-id-1'})
    verify('other player cannot retrieve receipt',st==200 and other['lookup']=='NOT_FOUND' and other['receipt'] is None)
    swapped=dict(actions,client_action_id='security-actor-forged',actor_id='actor-2')
    st,forbidden=call('FAKE_TEST_PLAYER1',swapped)
    verify('other player actor rejected',st==200 and forbidden['receipt']['code']=='FORBIDDEN')
    st,stored=call('FAKE_TEST_PLAYER1',{'schema_version':2,'op':'receipt_query','room_id':'security39','client_action_id':'security-actor-forged'})
    verify('forbidden receipt durable',st==200 and stored['receipt']==forbidden['receipt'])
    changed=json.loads(json.dumps(actions));changed['action']['target']['actor_id']='actor-m'
    st,conflict=call('FAKE_TEST_PLAYER1',changed)
    verify('reuse same id different payload blocked',st==409 and conflict['error']['code']=='ID_REUSE_CONFLICT')
    st,retained=call('FAKE_TEST_PLAYER1',{'schema_version':2,'op':'receipt_query','room_id':'security39','client_action_id':'security-id-1'})
    verify('id reuse does not overwrite original receipt',retained['receipt']==rejected['receipt'])
    st,prior=call('FAKE_TEST_PLAYER1',actions)
    verify('same identical request returns original receipt',st==200 and prior['receipt']==rejected['receipt'])
    for role,token in [('p1','FAKE_TEST_PLAYER1'),('p2','FAKE_TEST_PLAYER2')]:
        st,view=call(token,{'schema_version':1,'op':'view','room_id':'security39'})
        verify(f'{role} view excludes master/other private data',st==200 and not any(x in json.dumps(view) for x in ['FAKE_MASTER_ONLY','master_note','private_notes','FAKE_P1_ONLY' if role=='p2' else 'FAKE_P2_ONLY']))
    st,invalid=call('FAKE_TEST_PLAYER1',dict(actions,client_action_id='unknown_action',admin=True))
    verify('unexpected administrative field refused',st==400 and invalid['error']['code']=='INVALID_SCHEMA')
    st,invalid_token=call('INVALID_TOKEN',{'schema_version':1,'op':'view','room_id':'security39'})
    verify('invalid fake token denied',st==403 and invalid_token['error']['code']=='FORBIDDEN')
    with sqlite3.connect(Path(tmp)/'auth.sqlite') as db:
      verify('no mechanical event generated',db.execute('select count(*) from events').fetchone()[0]==0)
      verify('revision unchanged at zero',db.execute('select revision from rooms').fetchone()[0]==0)
      verify('two durable rejection receipts, no extra receipt from invalid',db.execute('select count(*) from receipts').fetchone()[0]==2)
    assert all('Traceback' not in json.dumps(x) for x in trace)
    verify('no stacktrace leaked',True)
(ROOT/'evidence').mkdir(exist_ok=True)
(ROOT/'evidence'/'TEST39_security_authority.json').write_text(json.dumps({'checks':checks,'trace':trace,'note':'Synthetic role fixture; not production authentication or ACL proof.'},ensure_ascii=False,indent=2))
print('SECURITY CODEX ACTUAL 0.3.0',len(checks),'PASS')
