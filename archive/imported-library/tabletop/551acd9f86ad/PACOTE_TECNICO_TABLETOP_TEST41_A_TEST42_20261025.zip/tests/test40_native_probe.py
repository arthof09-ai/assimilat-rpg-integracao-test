import asyncio,hashlib,sys,tempfile,threading
from pathlib import Path
import os
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'connected_test'))
from start_test40 import stage
async def main():
 with tempfile.TemporaryDirectory() as td:
  d=Path(td);serverdir=stage(Path(os.environ.get('TEST40_CODEX_ZIP','/mnt/data/ponte-vlab-tabletop-0.4.0-test38.zip')),d/'runtime');sys.path.insert(0,str(serverdir))
  from authority import Authority,make_server
  server=make_server(Authority(d/'db.sqlite'),0,arena_assets=True)
  threading.Thread(target=server.serve_forever,daemon=True).start()
  async with async_playwright() as pw:
   b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
   p=await b.new_page(viewport={'width':390,'height':844})
   try:
    response=await p.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='domcontentloaded',timeout=7500)
    print('NAVIGATION SUCCESS',response.status, await p.title())
   except Exception as e:
    print('NAVIGATION BLOCKED',str(e).splitlines()[0]);
   await b.close()
  server.shutdown();server.server_close()
asyncio.run(main())
