"""Chromium UI + ACTUAL RoomClient/native_port methods; mocked fetch because
localhost navigation is administratively blocked here. No browser-native
Authority proof claimed; tests UI, journal and fail-closed behavior only.
"""
import asyncio,json,re
from pathlib import Path
from playwright.async_api import async_playwright
from test39_mount import mount
ROOT=Path(__file__).resolve().parents[1]
NATIVE=(ROOT/'connected_test/native_port.js').read_text()
# Test-only substitution of origin gate for opaque page.set_content fixture.
assert "const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&" in NATIVE
NATIVE=NATIVE.replace("const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&", "const enabled=true &&")
async def main():
 all=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(360,740)]:
   p=await browser.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True)
   errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
   await mount(p)
   await p.evaluate('''() => {
    let hits=0;window.fakeFetchHits=()=>hits;
    window.fetch=async()=>{hits++;return {ok:true,text:async()=>JSON.stringify({ok:true,receipt:{client_action_id:window.__tabletopTEST.authority().id,status:'REJECTED',code:'MECHANICS_UNAVAILABLE',revision:0,receipt_id:'receipt-fixture'}})};};
    window.PonteTEST={request:()=>{}};
    const c=window.TabletopRoomTEST.client;c.profile='p1';c.protocol='v2';c.connected=true;c.selfId='p1';c.role='player';c.revision=0;
   }''')
   await p.evaluate('''() => {let el=document.getElementById('bridgeResult');if(!el){el=document.createElement('p');el.id='bridgeResult';document.body.append(el);}el.textContent='Cena visual TEST importada · SHA fixture';}''')
   await p.add_script_tag(content=NATIVE)
   tests=[]
   async def chk(label,yes):
    assert yes,f'{w}x{h} {label}; {errors}'
    tests.append(label)
   await chk('native add-on active under explicitly mocked origin',await p.evaluate('window.TabletopNativeTEST.ready()'))
   await chk('no new outbox key before intent',await p.evaluate('window.localStorage.getItem(window.TabletopRoomTEST.client.journalKey)===null'))
   await p.locator('#tacticToggle').click();await p.locator('#tacticAction').select_option('attack')
   await p.locator('.tile[data-xy="5,2"]').click(force=True)
   await p.evaluate('window.TabletopNativeTEST.loseNextAttackAck()')
   await p.locator('#tacticConfirm').click()
   await p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
   raw=await p.evaluate('window.localStorage.getItem(window.TabletopRoomTEST.client.journalKey)')
   cid=await p.evaluate('window.__tabletopTEST.authority().id')
   await chk('unknown UI after controlled ACK suppression','UNKNOWN' in await p.locator('#tacticAuthorityState').inner_text())
   await chk('journal v1 optionally stores external command',json.loads(raw)['external']['payload']['commandId']==cid)
   await chk('one browser fetch from app JS (mock fulfillment only)',await p.evaluate('window.fakeFetchHits()')==1)
   await chk('no invented mechanics',await p.evaluate('window.__tabletopTEST.scene().units[0].hp')==100)
   await chk('no second attack while unresolved',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()!==null'))
   await p.close()
   # Reopen independent renderer with the exact recorded JSON, same synthetic origin fixture.
   p=await browser.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True)
   await mount(p)
   await p.evaluate('''raw => {
     window.PonteTEST={request:()=>{}};window.localStorage.setItem(window.TabletopRoomTEST.client.journalKey,raw);
     const c=window.TabletopRoomTEST.client;c.profile='p1';c.protocol='v2';c.connected=true;c.selfId='p1';c.role='player';c.revision=0;
     window.fetch=async()=>({ok:true,text:async()=>JSON.stringify({ok:true,receipt:{client_action_id:window.__tabletopTEST.authority().id,status:'REJECTED',code:'MECHANICS_UNAVAILABLE',revision:0,receipt_id:'receipt-fixture'}})});
   }''',raw)
   await p.add_script_tag(content=NATIVE)
   await chk('original journal reloaded and ID restored',await p.evaluate('window.__tabletopTEST.authority()?.id')==cid)
   await chk('reloaded attempt stays UNKNOWN','UNKNOWN' in await p.locator('#tacticAuthorityState').inner_text())
   await p.locator('#tacticToggle').click()
   await p.locator('#tacticAuthorityQuery').click()
   await p.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
   await chk('recovered receipt visible','MECHANICS_UNAVAILABLE' in await p.locator('#tacticAuthorityState').inner_text())
   await chk('original outbox cleared after readback',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()===null'))
   await chk('still no mechanical mutation',await p.evaluate('window.__tabletopTEST.scene().units[0].hp')==100)
   await p.close()
   p=await browser.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True)
   await mount(p)
   await p.evaluate('''() => {window.PonteTEST={request:()=>{}};window.localStorage.setItem(window.TabletopRoomTEST.client.journalKey,'{corrupt!');const c=window.TabletopRoomTEST.client;c.protocol='v2';c.connected=true;c.profile='p1';}''')
   await p.add_script_tag(content=NATIVE)
   await chk('corrupt journal blocks all sending',not await p.evaluate('window.TabletopNativeTEST.ready()'))
   await chk('bytes of corrupt journal untouched',await p.evaluate("window.localStorage.getItem(window.TabletopRoomTEST.client.journalKey)")=='{corrupt!')
   await chk('no second journal created',await p.evaluate('Object.keys(JSON.parse(JSON.stringify({}))).length===0'))
   all.append({'viewport':f'{w}x{h}','assertions':tests})
   await p.close()
  await browser.close()
 (ROOT/'evidence'/'TEST40_browser_journal_results.json').write_text(json.dumps(all,indent=2,ensure_ascii=False))
 print('TEST40 CHROMIUM UI MOCKED-FETCH',sum(len(x['assertions']) for x in all),'PASS (not real network)',flush=True)
if __name__=='__main__':asyncio.run(main())
