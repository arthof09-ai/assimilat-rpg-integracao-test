"""TEST41: real Chromium UI RED original TEST40, GREEN patched.
Only page.set_content and explicit synthetic authority-port mocks; no browser HTTP claim.
"""
import asyncio,os,json,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE=Path(os.environ.get('TEST41_BASELINE','/mnt/data/tabletop_run018/baseline'))
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
async def mount(page,root):
    html=(root/'public/index.html').read_text();html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html)
    html=html.replace('<link rel="stylesheet" href="styles.css">','')
    for n in ['app.js','room-v2-adapter.js','room-client.js']:html=html.replace(f'<script src="{n}" defer></script>','')
    await page.set_content(html)
    await page.evaluate('''() => {const mem={};for(const key of ['localStorage','sessionStorage'])Object.defineProperty(window,key,{configurable:true,value:{getItem:k=>mem[k]??null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}}});}''')
    await page.add_style_tag(content=(root/'public/styles.css').read_text())
    for n in ['app.js','room-v2-adapter.js','room-client.js']:
        await page.add_script_tag(content=(root/'public'/n).read_text())
async def prep(p):
    await p.evaluate('''() => {
     window.__41={queries:[],sends:[],pending:[]};
     const A={roomId:'rooma',principalId:'p1'}, B={roomId:'roomb',principalId:'p1'};
     const port=(scope,status)=>({scope,newId:()=>"same_41_aa",reserve:r=>{window.__41.sends.push(r);return true;},
      send:r=>Promise.reject(new Error('ACK_LOST_AFTER_COMMIT')),
      query:id=>{window.__41.queries.push(scope.roomId);return Promise.resolve({commandId:id,status,
       code:status==='REJECTED'?'MECHANICS_UNAVAILABLE':null,scope});},
      finish:(id,status)=>{window.__41.finished=true;return true;},markUnknown:()=>true});
     window.__41.a=port(A,'REJECTED');window.__41.b=port(B,'ACCEPTED');
     window.TabletopTestAuthorityPort=window.__41.a;
    }''')
async def start(p):
    await p.locator('#tacticToggle').click()
    await p.locator('#tacticAction').select_option('attack')
    await p.locator('.tile[data-xy="5,2"]').click(force=True)
    await p.locator('#tacticConfirm').click()
    await p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
async def run(pw,root,tag):
    b=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    p=await b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    await mount(p,root);await prep(p);await start(p)
    before=await p.locator('#tacticAuthorityState').inner_text()
    await p.evaluate('window.__tabletopTEST.createScene()')
    current=await p.evaluate('window.__tabletopTEST.scene().id')
    afterScene=await p.locator('#tacticAuthorityState').inner_text()
    await p.evaluate('window.TabletopTestAuthorityPort=window.__41.b')
    await p.locator('#tacticAuthorityQuery').click()
    await p.wait_for_function('window.__tabletopTEST.authority()?.status!=="UNKNOWN"')
    result={'tag':tag,'current':current,'before':before,'scene':afterScene,'after':await p.locator('#tacticAuthorityState').inner_text(),
      'tactic':await p.locator('#tacticReadout').inner_text(),
      'status':await p.evaluate('window.__tabletopTEST.authority().status'),
      'queries':await p.evaluate('window.__41.queries'),
      'sends':await p.evaluate('window.__41.sends.length'),
      'hp':await p.evaluate('window.__tabletopTEST.state().scenes[0].units[0].hp')}
    await p.screenshot(path=str(OUT/('TEST41_'+tag+'.png')),full_page=False)
    await b.close();return result
async def main():
    async with async_playwright() as pw:
      red=await run(pw,BASE,'BASELINE_RED');green=await run(pw,ROOT,'INSTALLED_GREEN')
    assert red['status']=='ACCEPTED' and red['queries']==['roomb'] and 'CENA c1' not in red['after'],red
    assert green['status']=='REJECTED' and green['queries']==['rooma'] and green['sends']==1,green
    assert 'c1' in green['scene'] and green['current']!='c1' and green['current'] in green['scene'],green
    assert 'c1' in green['tactic'] and green['current'] in green['tactic'],green
    assert green['hp']==red['hp']==100
    (OUT/'TEST41_RED_GREEN_020.json').write_text(json.dumps({'RED':red,'GREEN':green},indent=2,ensure_ascii=False))
    print('TEST41 PESQ020 RED original TEST40, GREEN installed TEST41; rooma REJECTED not roomb ACCEPTED; origin c1 labeled after switch; 8/8 checks PASS')
if __name__=='__main__':asyncio.run(main())
