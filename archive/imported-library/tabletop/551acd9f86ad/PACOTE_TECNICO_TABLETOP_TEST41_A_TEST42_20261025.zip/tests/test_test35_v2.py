"""TEST35: Playwright real DOM + synthetic v2 fixture. Never WebSocket/auth/cloud."""
import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
from test_room_browser import mount
V2=(Path(__file__).resolve().parents[1]/'public'/'room-v2-adapter.js').read_text()
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  alltests=[]
  for w,h in [(390,844),(360,740)]:
   page=await browser.new_page(viewport={'width':w,'height':h})
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await mount(page);await page.add_script_tag(content=V2)
   tests=[]
   async def check(name,passed):
    if not passed:raise AssertionError(f'{w}x{h}: {name} errors={errors}; status={await page.locator("#roomStatus").inner_text()}')
    tests.append(name)
   await check('Arena original preservada',await page.locator('.tile').count()==49)
   await check('Protocolo v1 disponível',await page.locator('#roomProtocol').input_value()=='v1')
   await page.locator('#roomProtocol').select_option('v2');await page.locator('#roomProfile').select_option('p1');await page.locator('#roomConnect').click()
   await check('v2 WELCOME conecta',await page.evaluate('window.TabletopRoomTEST.client.connected'))
   await check('v2 perfil derivado do mock',await page.evaluate('window.TabletopRoomTEST.client.role')=='player')
   await check('v2 Player 1 só vê unidade própria',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units.map(x=>x.id).join()')=='demo_a')
   await check('v2 não permite unidade da Player 2',await page.evaluate('window.TabletopRoomTEST.client.sendIntent("demo_b",2,2)') is False)
   local=await page.evaluate('JSON.stringify(window.__tabletopTEST.state())')
   await page.locator('#roomGrid button').nth(8).click();await page.locator('#roomGrid button').nth(16).click()
   await check('v2 ACK + snapshot confirma',await page.evaluate('window.TabletopRoomTEST.client.snapshot?.units?.[0]?.x')==2)
   await check('v2 pendências resolvidas com ACK',await page.evaluate('window.TabletopRoomTEST.client.pending.size')==0)
   await check('v2 não altera Arena',await page.evaluate('JSON.stringify(window.__tabletopTEST.state())')==local)
   await check('v2 status final connected',await page.evaluate('window.TabletopRoomTEST.client.status')=='connected')
   # Simulate ack lost after commit; visible state must remain UNKNOWN and preserve command ID.
   await page.locator('#roomGrid button').nth(16).click()
   await check('Destino parede rejeitado',await page.evaluate('window.TabletopRoomTEST.client.sendIntent("demo_a",3,3)') is False)
   await page.evaluate('window.TabletopRoomV2TEST.mock.dropNextAck=true')
   await check('Movimento parede não emite comando',await page.evaluate('window.TabletopRoomTEST.client.pending.size')==0)
   await page.locator('#roomGrid button').nth(18).click()
   await check('ACK perdido cria UNKNOWN pendente',await page.evaluate('window.TabletopRoomTEST.client.pending.size')==1)
   await check('Sem avanço otimista no client',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].x')==2)
   await check('Comando armazenado com ID',await page.evaluate('Array.from(window.TabletopRoomTEST.client.pending.keys())[0].length')>0)
   cid=await page.evaluate('Array.from(window.TabletopRoomTEST.client.pending.keys())[0]')
   await page.locator('#roomDisconnect').click()
   await check('Desconectar preserva UNKNOWN',await page.evaluate('window.TabletopRoomTEST.client.pending.size')==1)
   await page.locator('#roomConnect').click()
   await check('Reentrada consulta recibo mesmo ID',await page.evaluate('window.TabletopRoomTEST.client.pending.size')==0)
   await check('Comando não duplicado',await page.evaluate('window.TabletopRoomV2TEST.mock.revision')==2)
   await check('Snapshot reconciliado',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].x')==4)
   await check('Cliente conecta novamente',await page.evaluate('window.TabletopRoomTEST.client.connected'))
   await check('Sem erro de JavaScript',not errors)
   await check('Sem overflow horizontal',await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
   # Candidate v2 strict guards against nested leaks, role claims, inconsistent body.
   result=await page.evaluate('''() => {const V=window.TabletopRoomV2TEST;const p={v:2,type:'SNAPSHOT',roomId:'arena-test',revision:10,snapshot:{sceneId:'scene-test',n:7,units:[],walls:[],markers:[]}};
   const fake=JSON.parse(JSON.stringify(p));fake.snapshot.markers=[{id:'m',x:1,y:1,label:'safe',adminSourceId:'MASTER_SECRET'}];
   return {valid:V.validV2Response(p),nested:V.validV2Response(fake),extra:V.validV2Response({...p,adminRevision:10}),missingTopo:V.validV2Response({...p,snapshot:{sceneId:'scene-test',units:[],markers:[]}}),badRole:V.validV2Response({v:2,type:'WELCOME',roomId:'arena-test',participantId:'p1',role:'MASTER',revision:0,sessionEpoch:1,snapshot:p.snapshot,members:[]})};}''')
   await check('Snapshot sintético válido',result['valid'])
   await check('Segredo aninhado rejeitado',not result['nested'])
   await check('Campo adminRevision rejeitado',not result['extra'])
   await check('Topologia ausente falha explicitamente',not result['missingTopo'])
   await check('Role de WELCOME requer checagem de identidade no adapter',result['badRole']) # shape valid, client identity rejects
   print(f'{w}x{h}: {len(tests)}/{len(tests)} PASS')
   alltests+=tests
   if w==390 and os.environ.get("TABLETOP_CAPTURE")=="1":
    (Path(__file__).resolve().parents[1]/'evidence').mkdir(exist_ok=True)
    await page.screenshot(path=str(Path(__file__).resolve().parents[1]/'evidence'/'TEST35_v2_receipt_recovery_390.png'),full_page=True)
   await page.close()
  await browser.close()
  print(f'TEST35 UI DIRECTED: {len(alltests)}/{len(alltests)} PASS')
if __name__=='__main__':asyncio.run(main())
