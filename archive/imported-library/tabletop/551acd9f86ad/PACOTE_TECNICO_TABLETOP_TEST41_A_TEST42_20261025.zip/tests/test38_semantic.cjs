'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),path=require('path');
const root=path.resolve(__dirname,'..'),src=fs.readFileSync(path.join(root,'public/room-v2-adapter.js'),'utf8');
const frames=JSON.parse(fs.readFileSync(path.join(root,'tests/fixtures/FRAME_VECTORS_TEST38.json'),'utf8'));
function build(source){let connection,wire=[];const context=vm.createContext({window:{},console});vm.runInContext(source,context);const v=context.window.TabletopRoomV2TEST;
 const t=v.createV2AdapterTransport(cb=>{connection=cb;return{send(x){wire.push(JSON.parse(x))},close(){}}})({onMessage:x=>wire.push(JSON.parse(x)),onClose(){}});
 t.send(JSON.stringify({schema:'assim.tabletop.room.presentation.v1',type:'ROOM_JOIN',roomId:'arena-test',profile:'p1'}));
 connection.onMessage(JSON.stringify(frames.joinPlayer1));
 return {connection,wire,t,frame(x){connection.onMessage(JSON.stringify(x));return wire.at(-1);},v};}
const t=build(src);const generic=t.frame(frames.eventSynthetic);assert.equal(generic.kind,'ROOM_UPDATED','Generic room update MUST not become MOVE_CONFIRMED');
let visual={...frames.eventSynthetic,kind:'MOVE_VISUAL_TEST',revision:2,commandId:'move001',snapshot:{...frames.eventSynthetic.snapshot,units:frames.eventSynthetic.snapshot.units.map(u=>({...u,x:3,y:4}))}};
assert.equal(t.frame(visual).kind,'MOVE_CONFIRMED');
console.log('2/2 semantic assertions PASS');
