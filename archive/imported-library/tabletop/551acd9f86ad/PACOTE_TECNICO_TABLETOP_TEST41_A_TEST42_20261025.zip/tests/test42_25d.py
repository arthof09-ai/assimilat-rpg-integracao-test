"""TEST42 browser functionality: real tile DOM iso, not image-only mock; scene remains source of truth."""
import asyncio,re,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public';OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
async def mount(page):
 html=(P/'index.html').read_text();html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html).replace('<link rel="stylesheet" href="styles.css">','')
 for f in ['app.js','room-v2-adapter.js','room-client.js']:html=html.replace(f'<script src="{f}" defer></script>','')
 await page.set_content(html)
 await page.evaluate('''() => {const v={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>v[k]??null,setItem:(k,x)=>{v[k]=String(x)},removeItem:k=>delete v[k]}});}''')
 await page.add_style_tag(content=(P/'styles.css').read_text())
 for f in ['app.js','room-v2-adapter.js','room-client.js']:await page.add_script_tag(content=(P/f).read_text())
async def run(page,w,h):
 counts=[];errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 async def ck(name,v):
  if not v:raise AssertionError(f'{w}x{h}: {name}: {errors}')
  counts.append(name)
 async def ev(code):return await page.evaluate(code)
 async def state():return await ev('window.__tabletopTEST.state()')
 async def touch(sel):
  if w<700:await page.locator(sel).tap(force=True)
  else:await page.locator(sel).click(force=True)
 await mount(page)
 await ck('no JS errors',not errors)
 await ck('2.5D default',await ev('window.__tabletopTEST.projection()')=='iso')
 await ck('isometric board CSS',await ev('document.querySelector("#board").classList.contains("isometric")'))
 await ck('49 tiles same workspace',await page.locator('.tile').count()==49)
 # A fixture has no walls; create one with the ORIGINAL editor, then verify visible extrusion.
 await page.locator('#arenaTools summary').click()
 await page.locator('[data-mode="wall"]').click()
 await touch('.tile[data-xy="3,5"]')
 await page.locator('[data-mode="play"]').click()
 await ck('wall written by original editor','3,5' in (await state())['scenes'][0]['walls'])
 await ck('wall extruded svg',await page.locator('#isoArt polygon').count()>=3)
 await page.locator('#arenaTools summary').click()
 await ck('standee SVG exists',await page.locator('#isoArt text').count()==3)
 await ck('tile widths projected',await ev('''() => {const r=document.querySelector('.tile[data-xy="1,1"]').getBoundingClientRect();return r.width>30&&r.height>20;}'''))
 await ck('diamond clipping', 'polygon(' in await ev('getComputedStyle(document.querySelector(".tile")).clipPath'))
 await ck('board first on mobile',True if w>870 else await ev('document.querySelector("#arenaMain").getBoundingClientRect().top<document.querySelector("#managementToolbar").getBoundingClientRect().top'))
 await ck('no page overflow',await ev('document.documentElement.scrollWidth<=innerWidth+2'))
 before=await state()
 # click actual tile by projected center, preserving actor and target
 await touch('.tile[data-xy="1,1"]')
 await ck('tap actor via iso tile', (await state())['scenes'][0]['selected']=='u1')
 before=await state()
 await page.locator('#tacticToggle').click();await page.locator('#tacticAction').select_option('attack')
 await touch('.tile[data-xy="5,2"]')
 await ck('target actor B via iso tile',(await ev('window.__tabletopTEST.tactical()'))['draft']['targetId']=='u3')
 await ck('target visibly drawn',await page.locator('.tile[data-xy="5,2"]').evaluate('(e)=>e.classList.contains("tactic-target")'))
 await ck('no resource consumption',(await state())==before)
 await page.locator('#tacticConfirm').click()
 await ck('no invented attack','NÃO ENVIADA' in await page.locator('#tacticReadout').inner_text())
 await ck('attack doesnt change scene',(await state())==before)
 # change projection should not alter workspace or selection
 await page.locator('#view25d').click()
 await ck('2D works',await ev('window.__tabletopTEST.projection()')=='flat')
 await ck('same 49 tiles 2D',await page.locator('.tile').count()==49)
 await ck('2D art hidden',await ev('document.querySelector("#isoArt").hidden'))
 await ck('mode switch no state modification',(await state())==before)
 await page.locator('#view25d').click()
 await ck('return 2.5D',await ev('window.__tabletopTEST.projection()')=='iso')
 await ck('same state on round trip',(await state())==before)
 # inspect projection math distinct and invertible by DOM positions
 pt=await ev('window.__tabletopTEST.boardPoint(5,2)')
 bbox=await page.locator('.tile[data-xy="5,2"]').bounding_box()
 boardbox=await page.locator('#board').bounding_box()
 await ck('iso point matches real tile',abs((bbox['x']+bbox['width']/2)-(boardbox['x']+pt['x']))<1.6 and abs((bbox['y']+bbox['height']/2)-(boardbox['y']+pt['y']))<1.6)
 # zoom and scene geometry
 old=pt;await page.locator('#arenaTools summary').click();await page.locator('#zoomIn').click()
 await ck('zoom set',await ev('document.getElementById("zoomLabel").textContent.includes("48")'))
 new=await ev('window.__tabletopTEST.boardPoint(5,2)');await ck('2.5D zoom updates actual positions',new['x']>old['x'])
 await ck('wall remains 3D on zoom',await page.locator('#isoArt polygon').count()>=3)
 await page.locator('[data-mode="measure"]').click();await touch('.tile[data-xy="1,1"]');await touch('.tile[data-xy="4,3"]')
 await ck('ruler true grid Manhattan','Manhattan 5 casas' in await page.locator('#rulerStatus').inner_text())
 await ck('ruler projected line',await ev('document.querySelector("#rulerSegment").getAttribute("x2")!==document.querySelector("#rulerSegment").getAttribute("x1")'))
 await page.locator('[data-mode="play"]').click()
 # FOV iso visual maps same fov function
 await page.locator('#layerFov').check()
 await ck('FOV enabled', (await state())['scenes'][0]['fovEnabled'])
 await ck('FOV has explored/readable',await ev('window.__tabletopTEST.fovNow().length>0'))
 await ck('FOV does not destroy iso overlays',await page.locator('#isoArt text').count()>=1)
 await page.locator('#layerFov').uncheck()
 # mark existing coordinate with visual SVG; transient mode is not stored; native dialogue
 await page.locator('[data-mode="mark"]').click();await touch('.tile[data-xy="4,4"]');await page.locator('#markerText').fill('Passagem TEST');await page.locator('#markerSave').click()
 await ck('marker stored in EXISTING scene',len((await state())['scenes'][0]['markers'])==1)
 await ck('iso svg marks present',await page.locator('#markerOverlay .visual-mark').count()==1)
 await ck('mark on iso point',abs(float(await ev('document.querySelector("#markerOverlay .visual-mark").getAttribute("cx")'))-(await ev('window.__tabletopTEST.boardPoint(4,4)'))['x'])<1)
 await page.locator('#undo').click();await ck('marker undo',len((await state())['scenes'][0]['markers'])==0)
 await page.locator('#redo').click();await ck('marker redo',len((await state())['scenes'][0]['markers'])==1)
 # pan and center
 await page.locator('[data-mode="pan"]').click()
 await ck('pan mode active',(await state())['scenes'][0]['mode']=='pan')
 await page.locator('#center').click();await ck('center method available',await ev('window.__tabletopTEST.center!==undefined'))
 # 2D backup mode no persistence; scene backups structural compatible
 await ck('schema remains original',await ev('window.__tabletopTEST.validateWorkspace(window.__tabletopTEST.state())'))
 await ck('projection absent from canonical workspace','projectionMode' not in json.dumps(await state()))
 await ck('no errors final',not errors)
 await page.screenshot(path=str(OUT/f'TEST42_2_5D_{w}x{h}.png'),full_page=False)
 return {'viewport':f'{w}x{h}','count':len(counts),'cases':counts}
async def main():
 results=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(360,740),(1100,850)]:
   page=await b.new_page(viewport={'width':w,'height':h},has_touch=w<700,is_mobile=w<700)
   results.append(await run(page,w,h));await page.close()
  await b.close()
 (OUT/'TEST42_2_5D_QA.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
 print('TEST42 2.5D',sum(x['count'] for x in results),'PASS',[(x['viewport'],x['count']) for x in results])
if __name__=='__main__':asyncio.run(main())
