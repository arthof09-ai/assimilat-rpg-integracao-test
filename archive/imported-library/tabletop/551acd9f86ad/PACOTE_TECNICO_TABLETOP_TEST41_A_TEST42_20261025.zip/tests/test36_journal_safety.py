"""TEST36 regression for corrupted/unavailable outbox. Deliberately red on TEST35.
Uses genuine Chromium JS, synthetic room fixture, no authentic network or secrets.
"""
import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
JS=r'''() => {
 const T=window.TabletopRoomTEST, checks=[];
 const snap={n:7,walls:[],units:[{id:'demo_a',name:'Demo',mark:'D',team:'ally',ownerId:'p1',x:1,y:1}]};
 function check(label,ok){checks.push({label,pass:!!ok});}
 function create({initial=null,throwRead=false,missing=false}={}){
  let raw=initial,writes=0,wire=[],emit;
  const store=missing?null:{getItem:()=>{if(throwRead)throw Error('read blocked');return raw;},setItem:(_,v)=>{raw=v;writes++;},raw:()=>raw,writes:()=>writes};
  const c=new T.RoomClient({transportFactory:({onMessage})=>{emit=onMessage;return {send:x=>wire.push(JSON.parse(x)),close:()=>{}}},protocol:'v2',nonce:'journal_test',journalStore:store});
  c.connect('p1');emit(JSON.stringify({schema:T.SCHEMA,type:'ROOM_JOINED',roomId:'arena-test',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'Player',role:'player'}],snapshot:snap}));
  const result=c.sendIntent('demo_a',2,2);
  return {c,wire,store,result};
 }
 const bad='{ "version": 1, "entries": ["CORRUPTED"], "counter": 1 }';
 const malformed=create({initial:bad});
 check('Malformed journal must not authorize sending',malformed.result===false);
 check('Malformed journal preserved byte-exact',malformed.store.raw()===bad&&malformed.store.writes()===0);
 check('Malformed journal clearly marked unsafe',malformed.c.journalError===true);
 check('Malformed journal no outgoing intent',!malformed.wire.some(x=>x.type==='ROOM_INTENT'));
 const unreadable=create({throwRead:true});
 check('Unreadable journal blocks send',unreadable.result===false);
 check('Unreadable journal no outgoing intent',!unreadable.wire.some(x=>x.type==='ROOM_INTENT'));
 const absent=create({missing:true});
 check('Missing journal store blocks v2 send',absent.result===false);
 check('Missing journal store no outgoing intent',!absent.wire.some(x=>x.type==='ROOM_INTENT'));
 const repeated=create({initial:JSON.stringify({version:1,counter:4,entries:[{profile:'p1',payload:{schema:T.SCHEMA,type:'ROOM_INTENT',roomId:'arena-test',revision:0,intentId:'same_id',action:'MOVE_REQUEST',unitId:'demo_a',x:2,y:2},state:'UNKNOWN'},{profile:'p1',payload:{schema:T.SCHEMA,type:'ROOM_INTENT',roomId:'arena-test',revision:0,intentId:'other_id',action:'MOVE_REQUEST',unitId:'demo_a',x:3,y:2},state:'UNKNOWN'}]})});
 check('Too many unresolved entries are blocked, never overwritten',repeated.result===false&&repeated.store.writes()===0);
 const oversized=create({initial:'X'.repeat(5000)});
 check('Oversized journal is preserved and blocked',oversized.result===false&&oversized.store.raw().length===5000&&oversized.store.writes()===0);
 check('Unreadable journal is flagged, not silently ignored',unreadable.c.journalError===true);
 check('Missing store exposes visible safety error',absent.c.status==='error'&&absent.c.log.some(x=>x.includes('não enviado')));
 const clean=create({initial:null});
 check('Empty working journal still sends',clean.result===true);
 check('Good journal written before send',clean.store.writes()===1&&clean.wire.some(x=>x.type==='ROOM_INTENT'));
 return checks;
}'''
async def main():
 from pathlib import Path
 import re,os
 src=Path(os.environ.get('TEST_ROOT',str(ROOT))) / 'public'
 async def mount(page):
  html=(src/'index.html').read_text()
  html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '', html)
  html=html.replace('<link rel="stylesheet" href="styles.css">','')
  for f in ('app.js','room-v2-adapter.js','room-client.js'):
   html=html.replace(f'<script src="{f}" defer></script>','')
  await page.set_content(html)
  await page.add_style_tag(content=(src/'styles.css').read_text())
  await page.add_script_tag(content=(src/'app.js').read_text())
  await page.add_script_tag(content=(src/'room-v2-adapter.js').read_text())
  await page.add_script_tag(content=(src/'room-client.js').read_text())
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in ((390,844),(360,740)):
   p=await b.new_page(viewport={'width':w,'height':h});await mount(p)
   r=await p.evaluate(JS);print(f'{w}x{h}: {sum(x["pass"] for x in r)}/{len(r)} PASS')
   for x in r:
    if not x['pass']:print(' RED:',x['label'])
   if '--expect-green' in sys.argv:assert all(x['pass'] for x in r),r
   await p.close()
  await b.close()
if __name__=='__main__':asyncio.run(main())
