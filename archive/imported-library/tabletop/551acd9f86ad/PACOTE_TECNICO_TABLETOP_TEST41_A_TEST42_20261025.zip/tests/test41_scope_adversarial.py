"""Scoped-journal/adversarial role tests on actual Chromium/JS; HTTP is MOCKED.
Original Authority may not be exposed; never mark production ACL verified.
"""
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
from test41_cold_profile import mount
ROOT=Path(__file__).resolve().parents[1]
SCOPE={'roomId':'arena-test','principalId':'p1'}
BASE={'version':1,'counter':0,'entries':[], 'external':{'profile':'p1','payload':{'commandId':'atk41_adversarial','sceneId':'c1','actorId':'u1','targetId':'u3','action':'ATTACK_REQUEST'},'state':'UNKNOWN'}}
async def main():
    results=[]
    async with async_playwright() as pw:
      browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
      async def check(name,yes):
       if not yes: raise AssertionError(name)
       results.append(name)
      async def page(raw):
       p=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
       await mount(p,raw);return p
      bad=json.loads(json.dumps(BASE));bad['external']['scope']={'roomId':'arena-test','principalId':'p2'}
      raw=json.dumps(bad);p=await page(raw)
      await check('invalid scope journal flagged as unsafe',await p.evaluate('window.TabletopRoomTEST.client.journalError') is True)
      await check('invalid bytes still preserved',await p.evaluate('localStorage.getItem(window.TabletopRoomTEST.client.journalKey)')==raw)
      await check('port refuses invalid journal',not await p.evaluate('window.TabletopNativeTEST.ready()'))
      await check('no POST of corrupted journal',await p.evaluate('window.calls41.length')==0)
      await p.close()
      legacy=json.dumps(BASE);p=await page(legacy)
      await check('legacy journal parsed for preservation',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()?.payload?.commandId')=='atk41_adversarial')
      await check('legacy request no scope cannot query',not await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
      await check('legacy receipt shown as HOLD','LEGACY_SCOPE_HOLD' in await p.locator('#tacticAuthorityState').inner_text())
      await check('legacy request cannot clear',not await p.evaluate('window.TabletopTestAuthorityPort.finish("atk41_adversarial","REJECTED")'))
      await check('legacy bytes preserved',await p.evaluate('localStorage.getItem(window.TabletopRoomTEST.client.journalKey)')==legacy)
      await p.close()
      scoped=json.loads(json.dumps(BASE));scoped['external']['scope']=SCOPE
      p=await page(json.dumps(scoped))
      await check('scoped valid journal parsed',not await p.evaluate('window.TabletopRoomTEST.client.journalError'))
      await check('original scope available',await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
      await p.evaluate('window.TabletopRoomTEST.client.roomId="roomb"')
      await check('changed room blocks query',not await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
      await check('changed room cannot clear receipt',not await p.evaluate('window.TabletopTestAuthorityPort.finish("atk41_adversarial","REJECTED")'))
      await p.evaluate('window.TabletopRoomTEST.client.roomId="arena-test";window.TabletopRoomTEST.client.selfId="p2"')
      await check('mismatched selfId blocks query',not await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
      await p.evaluate('window.TabletopRoomTEST.client.selfId="p1";window.TabletopRoomTEST.client.role="gm"')
      await check('mismatched role blocks query',not await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
      await p.evaluate('window.TabletopRoomTEST.client.role="player"')
      await check('restore confirmed role and room',await p.evaluate('window.TabletopTestAuthorityPort.canQuery()'))
      await check('no query without explicit click',await p.evaluate('window.calls41.length')==0)
      await p.close()
      # Tampered but correctly shaped receipt from a DIFFERENT room with same ID.
      p=await page(json.dumps(scoped))
      await p.evaluate('''()=>{let cleared=0;window.try41Clears=()=>cleared;
       const original=window.TabletopTestAuthorityPort;
       const replacement={...original,query:async id=>({commandId:id,status:'ACCEPTED',scope:{roomId:'roomb',principalId:'p1'}}),finish:()=>{cleared++;return true}};
       window.TabletopTestAuthorityPort=replacement;
       document.dispatchEvent(new Event('tabletop:connected-test-authority'));
      }''')
      # Native port from original remains pinned in attempt, not the replaced global object.
      await check('original port pinned after external swap',await p.evaluate('window.__tabletopTEST.authority()?.scope.roomId')=='arena-test')
      await check('global replacement cannot change original attempt',await p.evaluate('window.__tabletopTEST.authority()?.port===window.TabletopTestAuthorityPort') is False)
      await check('journal not cleared by replacement',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()?.payload.commandId')=='atk41_adversarial')
      await check('no spurious accepted receipt',await p.evaluate('window.__tabletopTEST.authority()?.status')=='UNKNOWN')
      await p.close()
      p=await page(json.dumps(scoped))
      await p.evaluate("""()=>{window.fetch=async()=>({ok:true,text:async()=>JSON.stringify({ok:true,receipt:{client_action_id:'atk41_adversarial',status:'ACCEPTED',code:'APPLIED',revision:1,receipt_id:'receipt-same-id-other-operation'}})});}""")
      await check('accepted other operation refused by attack-only TEST port',await p.evaluate("""async()=>{try{await window.TabletopTestAuthorityPort.query('atk41_adversarial');return false}catch(e){return /ATTACK_NOT_AVAILABLE_ACCEPTED/.test(String(e))}}"""))
      await check('no clearance on accepted other operation',await p.evaluate('window.TabletopRoomTEST.client.externalRecord()?.payload.commandId')=='atk41_adversarial')
      await check('no mechanical change from forged acceptance',await p.evaluate('window.__tabletopTEST.scene().units[0].hp===100'))
      await p.close()
      await browser.close()
    (ROOT/'evidence'/'TEST41_scope_adversarial.json').write_text(json.dumps({'count':len(results),'checks':results},ensure_ascii=False,indent=2))
    print('TEST41 scope/legacy adversarial Chromium mocked',len(results),'PASS')
if __name__=='__main__':asyncio.run(main())
