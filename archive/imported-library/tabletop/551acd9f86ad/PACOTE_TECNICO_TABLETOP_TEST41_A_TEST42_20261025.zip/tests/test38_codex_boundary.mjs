// Independent boundary proof; DOES NOT modify or distribute private Codex source.
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
const codexRoot=process.env.CODEX_ROOT;if(!codexRoot)throw Error('Explicit CODEX_ROOT path required');
const {validateFrame,ROOM_SCHEMA}=await import(pathToFileURL(codexRoot+'/room_adapter.ts').href);
const src=fs.readFileSync(new URL('../public/room-v2-adapter.js',import.meta.url),'utf8');
const ctx=vm.createContext({window:{}});vm.runInContext(src,ctx);const v=ctx.window.TabletopRoomV2TEST;
let count=0;const check=(name,ok)=>{assert(ok,name);console.log('PASS',name);count++};
const intent={schema:ROOM_SCHEMA,type:'INTENT',roomId:'demo',commandId:'test38',baseRevision:0,actorId:'actor-1',action:{kind:'MOVE_VISUAL_TEST',payload:{x:1,y:2}}};
try{validateFrame(intent);throw Error('Bridge accepted unsupported move')}catch(e){check('Codex 0.2 rejects invented MOVE_VISUAL_TEST',e.code==='INVALID_FRAME'||e.code==='UNSUPPORTED_ACTION')}
const frontendIntent={v:2,type:'INTENT',roomId:'arena-test',commandId:'test38',baseRevision:0,kind:'MOVE_VISUAL_TEST',unitId:'demo_a',payload:{x:2,y:2}};
check('Frontend v2 fixture admits test movement',vm.runInContext(`window.TabletopRoomV2TEST.validV2Outgoing(${JSON.stringify(frontendIntent)})`,ctx));
try{validateFrame(frontendIntent);throw Error('Codex accepted frontend frame')}catch(e){check('Codex rejects raw frontend frame (namespace/shape)',e.code==='INVALID_FRAME')}
const codexWelcome={schema:ROOM_SCHEMA,type:'WELCOME',roomId:'demo',revision:0,view:{actors:[{actor_id:'actor-1',label:'TEST'}],mode:'FAKE_RULES_FOR_TRANSPORT_TEST'}};
check('Frontend rejects raw Codex WELCOME (no board projection)',!vm.runInContext(`window.TabletopRoomV2TEST.validV2Response(${JSON.stringify(codexWelcome)})`,ctx));
const codexAck={schema:ROOM_SCHEMA,type:'ACK',roomId:'demo',commandId:'test38',status:'ACCEPTED',code:'APPLIED',receipt:{receipt_version:1}};
check('Frontend rejects raw Codex ACK (different namespace)',!vm.runInContext(`window.TabletopRoomV2TEST.validV2Response(${JSON.stringify(codexAck)})`,ctx));
check('Codex accepts its own synthetic label frame',(()=>{try{validateFrame({...intent,action:{kind:'FAKE_SET_LABEL',label:'TEST'}});return true;}catch{return false;}})());
check('Codex accepts mechanics-hold ATTACK_REQUEST envelope',(()=>{try{validateFrame({...intent,action:{kind:'ATTACK_REQUEST',turn_id:'turn-test-1',target:{kind:'UNIT',actor_id:'actor-2'},context:{scene_id:'scene-test-1',ability_id:'basic-attack'}}});return true;}catch{return false;}})());
console.log(`${count}/${count} boundary assertions PASS — incompatible as wired, NOT a backend integration`);
