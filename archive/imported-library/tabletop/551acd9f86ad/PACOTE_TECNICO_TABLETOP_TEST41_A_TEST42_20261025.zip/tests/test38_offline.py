"""Browser smoke of standalone TEST38 HTML with the actual CSP hashes."""
from pathlib import Path
import asyncio,json
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OFFLINE=ROOT/'dist/TABLETOP_ASSIMILACAO_TEST38_OFFLINE.html'
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
async def main():
 result=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(844,390)]:
   page=await browser.new_page(viewport={'width':w,'height':h},has_touch=True)
   errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda req:requests.append(req.url))
   await page.set_content(OFFLINE.read_text())
   checks=[]
   async def check(name,test):
    if not test:raise AssertionError(f'OFFLINE {w}x{h} {name} errors={errors} req={requests}')
    checks.append(name)
   await check('TEST38 version displayed','TEST 38' in await page.locator('header .tag').inner_text())
   await check('49 arena cells',await page.locator('.tile').count()==49)
   await check('room receipt info present',await page.locator('#roomLastOutcome').count()==1)
   await check('action HUD available',await page.locator('#tacticToggle').count()==1)
   await check('no JavaScript error',not errors)
   await check('CSP blocked network',not requests)
   await page.locator('#roomProtocol').select_option('v1')
   await page.locator('#roomConnect').click()
   await check('v1 demo usable',await page.evaluate('window.TabletopRoomTEST.client.connected'))
   await check('Arena preserved',await page.locator('.tile').count()==49)
   await page.screenshot(path=str(OUT/f'TEST38_OFFLINE_{w}x{h}.png'),full_page=False)
   result.append({'viewport':f'{w}x{h}','count':len(checks),'checks':checks})
   print('OFFLINE',w,h,len(checks),'PASS')
   await page.close()
  await browser.close()
 (OUT/'TEST38_offline_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
 print('OFFLINE TOTAL',sum(x['count'] for x in result))
asyncio.run(main())
