"""Geometry/interaction/resize/FOV stress of isometric projection, not mechanics."""
import asyncio,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test42_25d import mount,OUT
from playwright.async_api import async_playwright

async def suite(browser,w,h):
 p=await browser.new_page(viewport={'width':w,'height':h},is_mobile=w<=600,has_touch=w<=600)
 errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 await mount(p);a=[]
 async def ck(k,v):
  assert v,(w,h,k,errors);a.append(k)
 async def ev(js):return await p.evaluate(js)
 # single real pointer taps (no force): hit testing must be correct even in projection
 await p.locator('.tile[data-xy="5,2"]').click()
 await ck('real click no force works on isometric cell', (await ev('window.__tabletopTEST.scene()'))['selected']=='u3')
 await p.locator('#view25d').click()
 await p.locator('.tile[data-xy="1,1"]').click()
 await ck('2d selection', (await ev('window.__tabletopTEST.scene()'))['selected']=='u1')
 await p.locator('#view25d').click()
 await ck('2.5d after 2d', await ev('window.__tabletopTEST.projection()')=='iso')
 # no programmatic touching official mechanics; change board size through native selection
 await p.locator('#gridSize').select_option('20')
 await ck('20x20 cells displayed',await p.locator('.tile').count()==400)
 await ck('20x20 grid logic preserved', (await ev('window.__tabletopTEST.scene()'))['n']==20)
 await ck('stage dimensions 20x20',await ev('document.querySelector("#board").clientWidth>1000'))
 await ck('20x20 art present',await p.locator('#isoArt text').count()==3)
 await ck('no page-wide scroll overflow',await ev('document.documentElement.scrollWidth<=innerWidth+3'))
 await p.locator('#arenaTools summary').click()
 await p.locator('[data-mode="wall"]').click()
 await p.locator('.tile[data-xy="18,18"]').click()
 await ck('distant wall created with projection', '18,18' in (await ev('window.__tabletopTEST.scene()'))['walls'])
 await ck('raised wall visible 3d', await p.locator('#isoArt polygon').count()>=3)
 await p.locator('[data-mode="play"]').click()
 before=await ev('window.__tabletopTEST.state()')
 # settings/render changes cannot mutate scene
 for _ in range(3):await p.locator('#zoomOut').click()
 await ck('zoom down retained 20 grid',await p.locator('.tile').count()==400)
 await ck('20x20 state unchanged by camera',before==await ev('window.__tabletopTEST.state()'))
 await p.locator('#layerFov').check()
 await ck('fov functional',len(await ev('window.__tabletopTEST.fovNow()'))>0)
 await ck('FOV darkens unseen tiles',await p.locator('.tile.fov-hidden').count()>0)
 await p.locator('#layerFov').uncheck()
 # Resize board to 7 only after units/wall in bounds? wall 18,18 is trimmed; original parser supports.
 await p.locator('#gridSize').select_option('7')
 await ck('resize shrinks iso grid',await p.locator('.tile').count()==49)
 await ck('extruded wall outside disappears',await p.locator('#isoArt polygon').count()==0)
 await ck('state validates after shrink',await ev('window.__tabletopTEST.validateWorkspace(window.__tabletopTEST.state())'))
 await ck('no JS errors',not errors)
 await p.close();return {'viewport':f'{w}x{h}','checks':a}
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  vals=[]
  for dim in [(390,844),(844,390),(1100,850)]: vals.append(await suite(b,*dim))
  await b.close()
 (OUT/'TEST42_STRESS.json').write_text(json.dumps(vals,indent=2,ensure_ascii=False));print('TEST42 stress',sum(len(x['checks']) for x in vals),'PASS')
if __name__=='__main__':asyncio.run(main())
