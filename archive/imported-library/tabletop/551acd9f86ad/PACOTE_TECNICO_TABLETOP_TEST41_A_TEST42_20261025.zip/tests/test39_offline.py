"""Actual standalone CSP smoke; optional authority port absent and remains fail-closed."""
from pathlib import Path
import asyncio,json
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'
async def main():
 rs=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(844,390)]:
   page=await browser.new_page(viewport={'width':w,'height':h},has_touch=True)
   errors=[];requests=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda req:requests.append(req.url))
   await page.set_content((ROOT/'dist'/'TABLETOP_ASSIMILACAO_TEST39_OFFLINE.html').read_text())
   checks=[]
   async def test(label,value):
    assert value,f'{w}x{h} {label}: JS={errors} HTTP={requests}'
    checks.append(label)
   await test('correct version','TEST 39' in await page.locator('header .tag').inner_text())
   await test('Arena 49 cells',await page.locator('.tile').count()==49)
   await test('HUD original',await page.locator('#tacticToggle').count()==1)
   await test('bridge receipt panel exists',await page.locator('#tacticAuthorityState').count()==1)
   await test('no authority injected',await page.evaluate('window.TabletopTestAuthorityPort===undefined'))
   await test('query disabled',await page.locator('#tacticAuthorityQuery').is_disabled())
   await test('CSP prohibits requests',not requests)
   await test('no JS exception',not errors)
   await page.locator('#tacticToggle').click()
   await page.locator('#tacticAction').select_option('attack')
   await page.locator('.tile[data-xy="5,2"]').click(force=True)
   await page.locator('#tacticConfirm').click()
   await test('without bridge remains HOLD','NÃO ENVIADA' in await page.locator('#tacticReadout').inner_text())
   await test('no workspace corruption',await page.evaluate('window.__tabletopTEST.scene().units[0].hp')==100)
   await test('no unexpected transmission',not requests)
   await test('no errors after intent',not errors)
   rs.append({'viewport':f'{w}x{h}','checks':checks})
   await page.screenshot(path=str(OUT/f'TEST39_OFFLINE_{w}x{h}.png'),full_page=False)
   await page.close()
  await browser.close()
 (OUT/'TEST39_offline_results.json').write_text(json.dumps(rs,indent=2,ensure_ascii=False))
 print('OFFLINE',sum(len(x['checks']) for x in rs),'PASS')
if __name__=='__main__':asyncio.run(main())
