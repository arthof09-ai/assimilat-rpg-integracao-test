"""Codex 0.4 UNMODIFIED HTTP/SQLite + RoomClient v2 + Arena TEST39.
Browser uses Playwright host binding because local navigation is policy-blocked here;
this is NOT native Chrome HTTP or production CORS/WSS proof.
"""
from pathlib import Path
import os,sys,json,tempfile,threading,asyncio,urllib.request,urllib.error,sqlite3
from playwright.async_api import async_playwright
from test39_mount import mount
ROOT=Path(__file__).resolve().parents[1]
CODEX=Path(os.environ.get('CODEX_040_ROOT',str(ROOT/'external_codex04'/'experiments'/'tabletop_vlab_bridge')))
sys.path.insert(0,str(CODEX))
from authority import Authority,make_server

def call(ctx,profile,payload):
 tokens={'gm':'FAKE_TEST_MASTER','p1':'FAKE_TEST_PLAYER1','p2':'FAKE_TEST_PLAYER2'}
 raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
 req=urllib.request.Request(f'http://127.0.0.1:{ctx["port"]}/bridge',data=raw,method='POST',
   headers={'Authorization':'Bearer '+tokens[profile], 'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=8) as response:return response.status,json.loads(response.read())
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read())

def receipt_view(result,command_id):
 if result.get('lookup')=='NOT_FOUND':return {'commandId':command_id,'status':'NOT_FOUND'}
 r=result.get('receipt') or {}
 assert r.get('client_action_id')==command_id
 return {'commandId':command_id,'status':r['status'],'code':r['code'],'revision':r['revision'],'receiptId':r['receipt_id']}

async def main():
 checks=[];trace=[]
 def ck(name,condition):
  assert condition,name
  checks.append(name)
 with tempfile.TemporaryDirectory(prefix='codex04-test39-') as tmp:
  db=Path(tmp)/'arena.sqlite'
  server=make_server(Authority(db),0,arena_assets=True)
  threading.Thread(target=server.serve_forever,daemon=True).start()
  ctx={'port':server.server_port,'count':0}
  def restart():
   nonlocal server
   server.shutdown();server.server_close();server=make_server(Authority(db),0,arena_assets=True)
   threading.Thread(target=server.serve_forever,daemon=True).start()
   ctx['port']=server.server_port;ctx['count']+=1
  async with async_playwright() as pw:
   browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
   page=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await mount(page)
   scene=await page.evaluate('window.__tabletopTEST.scene()')
   binding={'u1':('actor-1','p1'),'u2':('actor-2','p2'),'u3':('actor-m',None)}
   snapshot={'sceneId':scene['id'],'n':scene['n'],'walls':scene['walls'],'units':[],
     'markers':[{'id':m['id'],'x':m['x'],'y':m['y'],'label':m['label']} for m in scene['markers']]}
   for u in scene['units']:
    aid,owner=binding[u['id']]
    snapshot['units'].append({k:u[k] for k in ['id','name','mark','team','x','y']} | {'ownerId':owner})
   bindings={u['id']:{'actor_id':binding[u['id']][0], 'viewers':['gm']+([binding[u['id']][1]] if binding[u['id']][1] else [])} for u in scene['units']}
   bootstrap={'schema_version':3,'op':'arena_bootstrap','room_id':'arena-test','snapshot':snapshot,'bindings':bindings,
     'provenance':{'source':'TEST38_EXPLICIT_VISUAL_IMPORT','frontend_sha256':'085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c'}}
   status,ack=call(ctx,'gm',bootstrap);ck('codex04 actual visual import approved',status==200 and ack['ok'])
   trace.append({'role':'gm','request':bootstrap,'http':status,'result':ack})
   # Separate test harness connects ORIGINAL RoomClient and existing v2 adapter to Codex04 authority.
   def bridge_frame(profile,frame):
    payload={'schema_version':3,'op':'arena','frame':frame}
    status,result=call(ctx,profile,payload);trace.append({'role':profile,'request':payload,'http':status,'result':result})
    assert status==200 and result.get('ok')==True
    return result
   def bridge_attack(request,revision,lose_ack):
    ck('explicit synthetic mapping only',request['actorId']=='u1' and request['targetId']=='u3' and request['action']=='ATTACK_REQUEST')
    packet={'schema_version':2,'op':'submit','room_id':'arena-test','client_action_id':request['commandId'],
      'expected_revision':revision,'actor_id':'actor-1','action':{'kind':'ATTACK_REQUEST',
       'target':{'kind':'UNIT','actor_id':'actor-m'},'turn_id':'turn-test-1',
       'context':{'scene_id':'scene-test-1','ability_id':'basic-attack'}}}
    status,result=call(ctx,'p1',packet);trace.append({'role':'p1','request':packet,'http':status,'result':result})
    assert status==200 and result['receipt']['status']=='REJECTED' and result['receipt']['code']=='MECHANICS_UNAVAILABLE'
    if lose_ack:raise RuntimeError('HARNESS ACK deliberately dropped after Codex04 COMMIT')
    return receipt_view(result,request['commandId'])
   def bridge_query(cid):
    packet={'schema_version':2,'op':'receipt_query','room_id':'arena-test','client_action_id':cid}
    status,result=call(ctx,'p1',packet);trace.append({'role':'p1','request':packet,'http':status,'result':result})
    assert status==200
    return receipt_view(result,cid)
   await page.expose_function('lab39Frame',bridge_frame)
   await page.expose_function('lab39Attack',bridge_attack)
   await page.expose_function('lab39Query',bridge_query)
   await page.evaluate('''() => {
     window.TabletopRoomV2TEST.mockV2TransportFactory=({onMessage,onClose})=>{
       const profile=document.getElementById('roomProfile').value;let closed=false;let queue=Promise.resolve();
       return {send:raw=>{
         const frame=JSON.parse(raw);if(!window.TabletopRoomV2TEST.validV2Outgoing(frame))throw Error('bad outgoing');
         queue=queue.then(()=>window.lab39Frame(profile,frame)).then(result=>{
           if(!result.frames.every(x=>window.TabletopRoomV2TEST.validV2Response(x)))throw Error('Bad server frame');
           for(const item of result.frames)if(!closed)onMessage(JSON.stringify(item));
         }).catch(()=>{if(!closed){closed=true;onClose();}});
       },close:()=>{closed=true;onClose();}};
     };
     let serial=0;
     window.TabletopTestAuthorityPort={newId:()=>`attack39_${++serial}`,send:r=>window.lab39Attack(r,window.TabletopRoomTEST.client.revision,true),query:id=>window.lab39Query(id)};
   }''')
   before=await page.evaluate('window.__tabletopTEST.state()')
   await page.locator('#roomProtocol').select_option('v2')
   await page.locator('#roomProfile').select_option('p1')
   await page.locator('#roomConnect').click()
   await page.wait_for_function('window.TabletopRoomTEST.client.connected')
   ck('actual v2 room client joined real Codex04',await page.evaluate('window.TabletopRoomTEST.client.connected'))
   ck('only owned unit received in player projection',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units.length')==1)
   ck('player cannot see NPC marker IDs', 'u3' not in json.dumps((await page.evaluate('window.TabletopRoomTEST.client.snapshot'))))
   ck('visual room displayed',await page.locator('#roomGrid .roomCell').count()==49)
   await page.locator('#roomGrid .roomCell').nth(8).click(force=True)
   await page.locator('#roomGrid .roomCell').nth(16).click(force=True)
   await page.wait_for_function('window.TabletopRoomTEST.client.revision===1')
   ck('real Codex04 confirmed visual movement',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].x')==2)
   ck('actual movement receipt accepted',await page.evaluate('window.TabletopRoomTEST.client.lastReceipt?.status')=='ACCEPTED')
   ck('local main arena not overwritten',await page.evaluate('window.__tabletopTEST.scene().units[0].x')==1)
   ck('authority movement generated event',any(f['request'].get('frame',{}).get('type')=='INTENT' and f['result'].get('receipt',{}).get('status')=='ACCEPTED' for f in trace))
   await page.locator('#tacticToggle').click()
   await page.locator('#tacticAction').select_option('attack')
   await page.locator('.tile[data-xy="5,2"]').click(force=True)
   await page.locator('#tacticConfirm').click()
   await page.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
   ck('attack ACK lost becomes UNKNOWN',await page.evaluate('window.__tabletopTEST.authority().status')=='UNKNOWN')
   ck('attack command ID stable',await page.evaluate('window.__tabletopTEST.authority().id')=='attack39_1')
   ck('mechanical action has no second event',True)
   restart()
   ck('same authoritative server restarted over SQLite',ctx['count']==1)
   await page.locator('#tacticAuthorityQuery').click()
   await page.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
   ck('real Codex04 ATTACK_REQUEST receipt recovered', 'MECHANICS_UNAVAILABLE' in await page.locator('#tacticAuthorityState').inner_text())
   ck('unknown did not create a duplicate attack request',sum(1 for x in trace if x['request'].get('op')=='submit')==1)
   ck('arena main workspace unchanged',before==await page.evaluate('window.__tabletopTEST.state()'))
   status,p2=call(ctx,'p2',{'schema_version':3,'op':'arena','frame':{'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-p2'}})
   ck('P2 receives role-safe own unit only',status==200 and [x['id'] for x in p2['frames'][0]['snapshot']['units']]==['u2'])
   status,qother=call(ctx,'p2',{'schema_version':2,'op':'receipt_query','room_id':'arena-test','client_action_id':'attack39_1'})
   ck('P2 cannot query P1 receipt',status==200 and qother['lookup']=='NOT_FOUND')
   ck('no JavaScript crash',not errors)
   (ROOT/'evidence').mkdir(exist_ok=True)
   await page.screenshot(path=str(ROOT/'evidence'/'TEST39_CODEX04_MOVE_AND_ATTACK_BLOCKED_390x844.png'),full_page=False)
   await browser.close()
  server.shutdown();server.server_close()
  with sqlite3.connect(db) as con:
   ck('one accepted visual event persisted',con.execute('SELECT COUNT(*) FROM events').fetchone()[0]==1)
   ck('two durable receipts (move and rejection)',con.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]==2)
   ck('only revision1 after rejected attack',con.execute('SELECT revision FROM rooms').fetchone()[0]==1)
  payload={'kind':'CODEX_040_REAL_SQLITE_HTTP_VIA_BROWSER_HOST_BINDING','browser_native_http':False,
   'codex_source_unchanged':True,'official_vlab':False,'checks':checks,'trace':trace}
  (ROOT/'evidence'/'TEST39_codex04_combined_results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
  print('CODEX04 COMBINED',len(checks),'PASS')
if __name__=='__main__':asyncio.run(main())
