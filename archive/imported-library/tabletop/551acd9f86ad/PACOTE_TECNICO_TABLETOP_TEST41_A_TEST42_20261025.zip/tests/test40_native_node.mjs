/* Executes ACTUAL TEST40 native_port.js and ACTUAL RoomClient journal methods
 * against REAL existing Codex Authority /bridge using Node's HTTP fetch.
 * Not a Chromium-native test, no Playwright forwarding. Two-phase restart.
 */
import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import path from 'node:path';
const ROOT=path.resolve(import.meta.dirname,'..');
const url=process.env.TEST40_URL,storeFile=process.env.TEST40_JOURNAL,mode=process.argv[2];
assert(url?.startsWith('http://127.0.0.1:')&&storeFile&&['submit','recover'].includes(mode));
let rawStore=fs.existsSync(storeFile)?JSON.parse(fs.readFileSync(storeFile,'utf8')):{};
const storage={getItem:k=>Object.hasOwn(rawStore,k)?rawStore[k]:null,setItem:(k,v)=>{rawStore[k]=String(v);fs.writeFileSync(storeFile,JSON.stringify(rawStore));}};
const elements=new Map();
function elt(id){if(!elements.has(id))elements.set(id,{id,textContent:'',parentElement:{append(){}},append(){},setAttribute(){},addEventListener(){}});return elements.get(id);}
const globalFetch=globalThis.fetch;
const context=vm.createContext({
 console,Promise,Uint8Array,TextEncoder,crypto:crypto.webcrypto,
 window:{},document:{getElementById:id=>id==='roomPanel'?null:elt(id),createElement:()=>({setAttribute(){},textContent:''}),dispatchEvent(){}},
 location:{protocol:'http:',hostname:'127.0.0.1'},Event:class Event{constructor(type){this.type=type}},
 fetch:(relative,options)=>globalFetch(new URL(relative,url),options),
 localStorage:storage,sessionStorage:{getItem:()=>null}
});
// Instrument ONLY this test copy to expose the same original RoomClient class.
let rc=fs.readFileSync(ROOT+'/public/room-client.js','utf8');
const anchor="const room=byId('roomPanel');";assert(rc.includes(anchor));
rc=rc.replace(anchor,`window.TestRoomClient=RoomClient;\n${anchor}`);
vm.runInContext(rc,context,{filename:'room-client.js'});
vm.runInContext(`window.TabletopRoomTEST={client:new window.TestRoomClient({protocol:'v2',journalStore:localStorage,nonce:'test40'})};
window.TabletopRoomTEST.client.profile='p1';window.TabletopRoomTEST.client.selfId='p1';window.TabletopRoomTEST.client.role='player';window.TabletopRoomTEST.client.connected=true;
window.TabletopRoomTEST.client.revision=0;window.__tabletopTEST={scene:()=>({id:'c1',n:7,walls:[],danger:[],terrain:{},markers:[],units:[{id:'u1',name:'Exploradora TEST',mark:'E',team:'ally',x:1,y:1},{id:'u2',name:'Conjurador TEST',mark:'C',team:'ally',x:1,y:3},{id:'u3',name:'Criatura TEST',mark:'X',team:'enemy',x:5,y:2}]})};
window.PonteTEST={request:()=>{}};window.localStorage=localStorage;window.sessionStorage=sessionStorage;`,context);
vm.runInContext(fs.readFileSync(ROOT+'/connected_test/native_port.js','utf8'),context,{filename:'native_port.js'});
const port=context.window.TabletopTestAuthorityPort,client=context.window.TabletopRoomTEST.client;
assert(port,'native port not enabled');
async function originalPacket(profile,p){const r=await globalFetch(new URL('/bridge',url),{method:'POST',headers:{Authorization:'Bearer '+({gm:'FAKE_TEST_MASTER',p1:'FAKE_TEST_PLAYER1'})[profile],'Content-Type':'application/json'},body:JSON.stringify(p)});return r.json();}
function makeReq(id){return vm.runInContext(`({commandId:'${id}',sceneId:'c1',actorId:'u1',targetId:'u3',action:'ATTACK_REQUEST'})`,context);}
if(mode==='submit'){
 const snapshot={sceneId:'c1',n:7,walls:[],units:[
  {id:'u1',name:'Exploradora TEST',mark:'E',team:'ally',ownerId:'p1',x:1,y:1},
  {id:'u2',name:'Conjurador TEST',mark:'C',team:'ally',ownerId:'p2',x:1,y:3},
  {id:'u3',name:'Criatura TEST',mark:'X',team:'enemy',ownerId:null,x:5,y:2}],markers:[]};
 const bindings={u1:{actor_id:'actor-1',viewers:['gm','p1']},u2:{actor_id:'actor-2',viewers:['gm','p2']},u3:{actor_id:'actor-m',viewers:['gm']}};
 const b=await originalPacket('gm',{schema_version:3,op:'arena_bootstrap',room_id:'arena-test',snapshot,bindings,provenance:{source:'TEST38_EXPLICIT_VISUAL_IMPORT',frontend_sha256:'085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c'}});
 assert.equal(b.ok,true,'Original Codex04 imports explicit scene');
 elt('bridgeResult').textContent='Cena visual TEST importada · SHA fixture';
 const id=port.newId(),request=makeReq(id);
 const originalScene=context.window.__tabletopTEST.scene;
 context.window.__tabletopTEST.scene=()=>({...originalScene(),walls:['3,3']});
 assert.equal(port.reserve(request),false,'edited geometry cannot reuse Codex TEST38 fixture SHA');
 context.window.__tabletopTEST.scene=originalScene;
 assert.equal(port.reserve(request),true,'original journal reserves before send');
 assert.equal(client.externalRecord()?.payload.commandId,id);
 // Shared outbox prevents movement intent while an attack receipt is unresolved.
 vm.runInContext(`window.TabletopRoomTEST.client.snapshot={n:7,units:[{id:'u1',ownerId:'p1',x:1,y:1}],walls:[]};window.TabletopRoomTEST.client.status='connected';window.TabletopRoomTEST.client.role='player';window.TabletopRoomTEST.client.selfId='p1';`,context);
 assert.equal(client.sendIntent('u1',2,2),false,'no second movement while tactical receipt unknown');
 assert.equal(client.externalRecord()?.payload.commandId,id);
 // Shared outbox prevents movement intent while an attack receipt is unresolved.
 vm.runInContext(`window.TabletopRoomTEST.client.snapshot={n:7,units:[{id:'u1',ownerId:'p1',x:1,y:1}],walls:[]};window.TabletopRoomTEST.client.status='connected';window.TabletopRoomTEST.client.role='player';window.TabletopRoomTEST.client.selfId='p1';`,context);
 assert.equal(client.sendIntent('u1',2,2),false,'no second movement while tactical receipt unknown');
 context.window.TabletopNativeTEST.loseNextAttackAck();
 await assert.rejects(()=>port.send(request),/TEST40-after-commit-reply-suppressed/);
 assert.equal(port.markUnknown(id),true);
 assert.equal(client.externalRecord().state,'UNKNOWN');
 assert.equal(port.reserve(makeReq('secondattack')),false,'cannot create another while unknown');
 assert.equal(Object.keys(rawStore).length,1,'NO second outbox key');
 fs.writeFileSync(storeFile+'.id',id);
 console.log('TEST40 NODE HTTP submit PASS id='+id+' journal='+Object.keys(rawStore)[0]+' ack=lost');
}else{
 const id=fs.readFileSync(storeFile+'.id','utf8').trim();
 assert.equal(client.externalRecord().payload.commandId,id,'same original journal ID after new runtime');
 const result=await port.query(id);
 assert.equal(result.status,'REJECTED');assert.equal(result.code,'MECHANICS_UNAVAILABLE');
 assert.equal(port.finish(id,result.status),true);
 assert.equal(client.externalRecord(),null);
 assert(!rawStore[client.journalKey].includes(id),'resolved journal no longer carries ID');
 const probe=await originalPacket('p1',{schema_version:2,op:'receipt_query',room_id:'arena-test',client_action_id:id});
 assert.equal(probe.receipt.status,'REJECTED');assert.equal(probe.receipt.code,'MECHANICS_UNAVAILABLE');
 console.log('TEST40 NODE HTTP recover PASS id='+id+' receipt='+probe.receipt.receipt_id+' revision='+probe.receipt.revision);
}
