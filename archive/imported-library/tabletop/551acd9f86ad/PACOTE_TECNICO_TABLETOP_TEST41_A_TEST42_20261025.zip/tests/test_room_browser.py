"""TEST34: UI integration and contract tests in Chromium; fixture transport only."""
from pathlib import Path
import asyncio, json, re, sys
from playwright.async_api import async_playwright
BASE=Path(__file__).resolve().parents[1];ROOT=BASE/'work/public' if (BASE/'work/public').exists() else BASE/'public'
HTML=(ROOT/'index.html').read_text().replace('<details id="arenaTools"','<details open id="arenaTools"');CSS=(ROOT/'styles.css').read_text();JS=(ROOT/'app.js').read_text();ROOM=(ROOT/'room-client.js').read_text()
async def mount(page):
    html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',HTML)
    html=html.replace('<link rel="stylesheet" href="styles.css">','').replace('<script src="app.js" defer></script>','').replace('<script src="room-client.js" defer></script>','')
    await page.set_content(html)
    await page.evaluate('''() => {const store={},session={};window.__store=store;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return store[k]??null},setItem(k,v){store[k]=String(v)},removeItem(k){delete store[k]}}});Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem(k){return session[k]??null},setItem(k,v){session[k]=String(v)},removeItem(k){delete session[k]}}});}''')
    await page.add_style_tag(content=CSS)
    await page.add_script_tag(content=JS)
    await page.add_script_tag(content=ROOM)
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  total=0
  for w,h in [(390,844),(360,740)]:
   page=await browser.new_page(viewport={'width':w,'height':h})
   errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
   await mount(page)
   tests=[]
   async def ck(label,val):
    if not val:raise AssertionError(f'{w}x{h}: {label}; JS errors={errors}; requests={requests}')
    tests.append(label)
   await ck('legacy arena ready',await page.locator('.tile').count()==49)
   await ck('public demo starts disconnected',await page.locator('#roomStatus').inner_text()=='Desconectado')
   await page.locator('#roomConnect').click()
   await ck('GM connects to fixture', 'conectada' in await page.locator('#roomStatus').inner_text())
   await ck('GM gets 3 units',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units.length')==3)
   await ck('Roster 3 members',await page.locator('#roomRoster span').count()==3)
   await ck('Grid 49 cells',await page.locator('#roomGrid button').count()==49)
   await ck('No resources leaked into snapshot',await page.evaluate('Object.keys(window.TabletopRoomTEST.client.snapshot.units[0]).sort().join(",")')=='id,mark,name,ownerId,team,x,y')
   await ck('Connection revision=0',await page.evaluate('window.TabletopRoomTEST.client.revision')==0)
   await page.locator('#roomGrid button').nth(8).click() # (1,1)
   await ck('Unit selected',await page.evaluate('window.TabletopRoomTEST.selected()')=='demo_a')
   local_before=await page.evaluate('JSON.stringify(window.__tabletopTEST.state())')
   await page.locator('#roomGrid button').nth(16).click() # (2,2)
   await ck('Intent confirmed by synthetic transport',await page.evaluate('window.TabletopRoomTEST.client.revision')==1)
   await ck('Remote x=2',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units.find(u=>u.id==="demo_a").x')==2)
   await ck('Local arena untouched by remote event',await page.evaluate('JSON.stringify(window.__tabletopTEST.state())')==local_before)
   await ck('No network access',len(requests)==0)
   await page.locator('#roomProfile').select_option('p1');await page.locator('#roomConnect').click()
   await ck('Player connected',await page.evaluate('window.TabletopRoomTEST.client.role')=='player')
   await ck('Player sees only owned fixture unit',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units.length')==1)
   await ck('Player snapshot excludes hidden enemy',await page.evaluate('window.TabletopRoomTEST.client.snapshot.units[0].id')=='demo_a')
   await ck('Player cannot intent for foreign id',await page.evaluate('window.TabletopRoomTEST.client.sendIntent("demo_b",2,2)')==False)
   await ck('Player cannot command admin mode',await page.evaluate('window.TabletopRoomTEST.checkOutgoing({schema:window.TabletopRoomTEST.SCHEMA,type:"ROOM_INTENT",roomId:"arena-test",revision:0,intentId:"a1",action:"ADMIN_RESET",unitId:"demo_a",x:1,y:1})')==False)
   await ck('Unknown field rejected',await page.evaluate('''() => window.TabletopRoomTEST.checkPacket({...{schema:window.TabletopRoomTEST.SCHEMA,type:'ROOM_SNAPSHOT',roomId:'arena-test',revision:1,seq:1,snapshot:{n:7,units:[],walls:[]}},masterOnly:{secret:'x'}})''')==False)
   await ck('Illegal prototype key rejected',await page.evaluate('''() => window.TabletopRoomTEST.checkPacket(JSON.parse('{"schema":"assim.tabletop.room.presentation.v1","type":"ROOM_SNAPSHOT","roomId":"arena-test","revision":1,"seq":1,"snapshot":{"n":7,"walls":[],"units":[]},"__proto__":{"unsafe":1}}'))''')==False)
   await ck('Duplicate unit rejected',await page.evaluate('''() => window.TabletopRoomTEST.checkSnapshot({n:7,walls:[],units:[{id:'a',name:'A',mark:'A',team:'ally',ownerId:'p1',x:1,y:1},{id:'a',name:'B',mark:'B',team:'ally',ownerId:'p2',x:2,y:2}]})''')==False)
   await ck('Invalid coord rejected',await page.evaluate('window.TabletopRoomTEST.checkSnapshot({n:7,walls:["01,01"],units:[]})')==False)
   await ck('Transport cannot send role spoof',await page.evaluate('window.TabletopRoomTEST.checkOutgoing({schema:window.TabletopRoomTEST.SCHEMA,type:"ROOM_INTENT",roomId:"arena-test",revision:0,intentId:"a1",action:"MOVE_REQUEST",unitId:"demo_a",x:2,y:2,role:"gm"})')==False)
   # force invalid server payload - should fail closed before DOM injection.
   await page.evaluate('''() => {const c=window.TabletopRoomTEST.client;c.receive(JSON.stringify({schema:window.TabletopRoomTEST.SCHEMA,type:'ROOM_SNAPSHOT',roomId:'arena-test',revision:2,seq:2,snapshot:{n:7,walls:[],units:[],secret:'PRIVATE'}}));}''')
   await ck('Malformed server packet disconnects client',await page.evaluate('window.TabletopRoomTEST.client.status')=='error')
   await ck('Malformed server packet clears snapshot',await page.evaluate('window.TabletopRoomTEST.client.snapshot===null'))
   await ck('Malformed packet not shown as private info', 'PRIVATE' not in await page.locator('#roomPanel').inner_text())
   await page.locator('#roomConnect').click()
   await ck('Recover via reconnect',await page.evaluate('window.TabletopRoomTEST.client.connected'))
   await page.locator('#roomResync').click()
   await ck('Resync keeps state',await page.evaluate('window.TabletopRoomTEST.client.status')=='connected')
   await ck('Mobile no horizontal overflow',await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
   await ck('No JS errors',not errors)
   print(f'{w}x{h}: {len(tests)}/{len(tests)} PASS')
   total+=len(tests)
   if w==390:
    await page.screenshot(path='/mnt/data/tabletop_run011/evidence/TEST34_room_demo_390x844.png',full_page=True)
   await page.close()
  await browser.close()
  print(f'TOTAL {total}/{total} PASS')
if __name__=='__main__':asyncio.run(main())
