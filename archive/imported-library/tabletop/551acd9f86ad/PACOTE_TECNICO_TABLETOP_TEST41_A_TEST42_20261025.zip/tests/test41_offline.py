"""Real Chromium standalone HTML/CSP smoke, deliberately no native authority."""
from pathlib import Path
import asyncio,json
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'
async def main():
 results=[]
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(390,844),(360,740),(844,390)]:
   p=await b.new_page(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600)
   errors=[];requests=[];p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda req:requests.append(req.url))
   await p.set_content((ROOT/'dist'/'TABLETOP_ASSIMILACAO_TEST41_OFFLINE.html').read_text())
   checks=[]
   def ck(name,yes):
    assert yes,(name,errors,requests)
    checks.append(name)
   ck('TEST41 version', 'TEST 41' in await p.locator('header .tag').inner_text())
   ck('arena 49 tiles',await p.locator('.tile').count()==49)
   ck('original HUD',await p.locator('#tacticToggle').count()==1)
   ck('no native port from public standalone',await p.evaluate('window.TabletopTestAuthorityPort===undefined'))
   ck('journal still available via RoomClient class',await p.evaluate('typeof window.TabletopRoomTEST.RoomClient==="function"'))
   ck('query disabled',await p.locator('#tacticAuthorityQuery').is_disabled())
   ck('CSP connect-src none', 'connect-src \'none\'' in await p.locator('meta[http-equiv="Content-Security-Policy"]').get_attribute('content'))
   ck('no JS errors',not errors)
   ck('no external requests',not requests)
   await p.locator('#tacticToggle').click();await p.locator('#tacticAction').select_option('attack');await p.locator('.tile[data-xy="5,2"]').click(force=True);await p.locator('#tacticConfirm').click()
   ck('attack not sent without competent server','NÃO ENVIADA' in await p.locator('#tacticReadout').inner_text())
   ck('HP not modified',await p.evaluate('window.__tabletopTEST.scene().units[0].hp===100'))
   ck('no invented authority after click',await p.evaluate('window.__tabletopTEST.authority()===null'))
   ck('no external requests after click',not requests)
   OUT.mkdir(exist_ok=True)
   await p.screenshot(path=str(OUT/f'TEST41_OFFLINE_{w}x{h}.png'),full_page=False)
   results.append({'viewport':f'{w}x{h}','checks':checks})
   await p.close()
  await b.close()
 (OUT/'TEST41_offline_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
 print('TEST41 offline chromium',sum(len(r['checks']) for r in results),'PASS')
if __name__=='__main__':asyncio.run(main())
