"""RUN011 TEST33: no-op cannot destroy redo, logs, revisions or persisted bytes.
Chromium Linux, in-memory localStorage fixture; never claims real Android/storage durability.
"""
import asyncio,json
from playwright.async_api import async_playwright
from test_redo_noop import mount,start_wall_undo,has_wall
KEY='assim.tabletop.synthetic.workspace.v1'
async def run_case(browser,width,height):
    checks=[]
    ctx=await browser.new_context(viewport={'width':width,'height':height})
    async def ck(name,ok):
        if not ok:raise AssertionError(f'{width}x{height} {name}')
        checks.append(name)
    async def data(page):
        return await page.evaluate('''(key)=>({state:JSON.stringify(window.__tabletopTEST.state()),raw:window.__store[key]??null})''',KEY)
    # MARKER SAME VALUES
    m=await ctx.new_page();await mount(m)
    await m.locator('[data-mode="mark"]').click();await m.evaluate('window.__tabletopTEST.cell(3,3)')
    await m.locator('#markerText').fill('Ponte TEST');await m.locator('#markerSave').click()
    await start_wall_undo(m)
    await m.locator('[data-mode="mark"]').click();await m.evaluate('window.__tabletopTEST.cell(3,3)')
    before=await data(m)
    await m.locator('#markerSave').click()
    after=await data(m)
    await ck('marker no-op preserves state',after['state']==before['state'])
    await ck('marker no-op preserves stored bytes',after['raw']==before['raw'])
    await ck('marker no-op closes dialog',not await m.locator('#markerDialog').is_visible())
    await m.evaluate('window.__tabletopTEST.redo()')
    await ck('marker no-op preserves redo',await has_wall(m))
    # NOTES SAME VALUE
    n=await ctx.new_page();await mount(n);await start_wall_undo(n)
    before=await data(n)
    await n.locator('#sceneNotes').evaluate('(el)=>{el.value="";el.dispatchEvent(new Event("change",{bubbles:true}));}')
    after=await data(n)
    await ck('notes no-op preserves state',after['state']==before['state'])
    await ck('notes no-op preserves stored bytes',after['raw']==before['raw'])
    await n.evaluate('window.__tabletopTEST.redo()')
    await ck('notes no-op preserves redo',await has_wall(n))
    # RENAME SAME VALUE
    r=await ctx.new_page();await mount(r);await start_wall_undo(r)
    before=await data(r)
    await r.evaluate('window.prompt=(message,initial)=>initial')
    await r.locator('#renameScene').click();after=await data(r)
    await ck('rename no-op preserves state',after['state']==before['state'])
    await ck('rename no-op preserves stored bytes',after['raw']==before['raw'])
    await r.evaluate('window.__tabletopTEST.redo()')
    await ck('rename no-op preserves redo',await has_wall(r))
    # REAL edit must invalidate redo and persist once
    e=await ctx.new_page();await mount(e)
    await e.locator('[data-mode="mark"]').click();await e.evaluate('window.__tabletopTEST.cell(3,3)')
    await e.locator('#markerText').fill('Original');await e.locator('#markerSave').click()
    await start_wall_undo(e)
    await e.locator('[data-mode="mark"]').click();await e.evaluate('window.__tabletopTEST.cell(3,3)')
    before=await data(e)
    await e.locator('#markerText').fill('Modificado')
    await e.locator('#markerSave').click()
    after=await data(e)
    await ck('real update changes scene',json.loads(after['state'])['scenes'][0]['markers'][0]['text']=='Modificado')
    await ck('real update changes saved bytes',after['raw']!=before['raw'])
    await ck('real update increases revision',json.loads(after['state'])['revision']>json.loads(before['state'])['revision'])
    await e.evaluate('window.__tabletopTEST.redo()')
    await ck('real update invalidates redo',not await has_wall(e))
    await e.evaluate('window.__tabletopTEST.undo()')
    await ck('real update undo restores original marker',(await e.evaluate('window.__tabletopTEST.scene().markers[0].text'))=='Original')
    await ctx.close()
    print(f'{width}x{height} {len(checks)}/{len(checks)} PASS')
    return len(checks)
async def main():
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        results=[await run_case(browser,*size) for size in [(390,844),(360,740)]]
        await browser.close()
    print(f'TOTAL {sum(results)}/{sum(results)} PASS')
if __name__=='__main__':asyncio.run(main())
