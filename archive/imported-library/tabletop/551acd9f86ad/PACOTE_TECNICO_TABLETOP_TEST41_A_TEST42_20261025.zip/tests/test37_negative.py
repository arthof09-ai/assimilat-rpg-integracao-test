"""Focused TEST37 negative/gesture/FOV/backups/landscape validation; not Android hardware."""
import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
from test37_tactical import mount
async def main():
 results=[];root=Path(__file__).resolve().parents[1]
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(360,740),(390,844),(844,390)]:
   p=await b.new_page(viewport={'width':w,'height':h},has_touch=True,is_mobile=True,accept_downloads=True)
   errors=[];p.on('pageerror',lambda e:errors.append(str(e)));await mount(p)
   checks=[]
   async def ck(label,assertion):
    if not assertion:raise AssertionError(f'{w}x{h}: {label} ({errors})')
    checks.append(label)
   async def state():return await p.evaluate('window.__tabletopTEST.state()')
   async def tactic():return await p.evaluate('window.__tabletopTEST.tactical()')
   async def cell(x,y):await p.evaluate('([x,y])=>window.__tabletopTEST.cell(x,y)',[x,y])
   coords=await p.evaluate('''()=>({top:document.querySelector('.viewport').getBoundingClientRect().top,whole:document.documentElement.scrollWidth<=innerWidth,collapsed:!document.querySelector('#arenaTools').open,overlay:document.querySelector('#tacticHud').classList.contains('expanded')})''')
   await ck('viewport first screen',coords['top']<h)
   await ck('no horizontal scroll',coords['whole'])
   await ck('editor compact',coords['collapsed'])
   await ck('tactics initially folded',not coords['overlay'])
   await p.locator('#tacticToggle').tap()
   await ck('tactic panel opens',await p.locator('#tacticBody').is_visible())
   await p.locator('#tacticToggle').tap()
   await ck('tactic panel folds',not await p.locator('#tacticBody').is_visible())
   await p.locator('#tacticToggle').tap()
   await p.select_option('#tacticAction','attack')
   init=await state()
   await cell(1,1)
   await ck('self target rejected',(await tactic())['draft']['target'] is None)
   await cell(4,3)
   await ck('empty target rejected',(await tactic())['draft']['target'] is None)
   await ck('self and empty did not move',(await state())==init)
   await cell(5,2)
   await ck('enemy valid target',(await tactic())['draft']['targetId']=='u3')
   await p.locator('#tacticCancel').tap()
   await ck('cancel no side effect',(await state())==init)
   await p.select_option('#tacticAction','cone')
   await cell(1,1)
   await ck('cone origin direction rejected',(await tactic())['draft']['target'] is None)
   await cell(5,2)
   num=await p.locator('.tile.tactic-area').count()
   await ck('cone draws nonzero cells',num>=1)
   await ck('cone bounded to <=14 cells',num<=14)
   await ck('cone no mechanical state mutation',(await state())==init)
   await p.locator('#tacticConfirm').tap()
   await ck('cone confirmation is mechanic hold','MECÂNICA INDISPONÍVEL' in await p.locator('#tacticReadout').inner_text())
   await ck('cone no PA/life change',(await state())==init)
   await p.locator('#tacticCancel').tap()
   # Ensure a pointer gesture longer than threshold in play mode cannot select/move a tile.
   await p.evaluate('''()=>{
    const v=document.getElementById('viewport');
    const opts=(type,x,y)=>new PointerEvent(type,{bubbles:true,cancelable:true,pointerId:101,pointerType:'touch',clientX:x,clientY:y,isPrimary:true});
    v.dispatchEvent(opts('pointerdown',55,320));v.dispatchEvent(opts('pointermove',100,400));v.dispatchEvent(opts('pointerup',100,400));
    document.querySelector('[data-xy="2,1"]').dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));
   }''')
   await ck('long pointer movement prevents accidental move',(await state())==init)
   # Drop stale click and allow next explicit tap.
   await p.locator('[data-xy="2,1"]').tap(force=True)
   await ck('subsequent tap still functional',(await state())['scenes'][0]['units'][0]['x']==2)
   # FOV and action preview coexist without changing game resources.
   await p.locator('#arenaTools summary').tap()
   await p.locator('#layerFov').check()
   await ck('fov enabled',(await state())['scenes'][0]['fovEnabled'])
   resources={z['id']:(z['hp'],z['soul'],z['pa']) for z in (await state())['scenes'][0]['units']}
   await p.select_option('#tacticAction','radius')
   await cell(6,6)
   await ck('edge preview clipped inside board',await p.locator('.tile.tactic-area').count()<=6)
   await ck('fov preview no JS error',not errors)
   await p.locator('#tacticCancel').tap()
   final={z['id']:(z['hp'],z['soul'],z['pa']) for z in (await state())['scenes'][0]['units']}
   await ck('all fixture resources unchanged',final==resources)
   # Return to arena from below / management toolbar.
   await p.locator('#jumpArena').click()
   near=await p.evaluate('''()=>{const y=document.querySelector('#arenaMain').getBoundingClientRect().top;return y>=-5&&y<innerHeight}''')
   await ck('jump Arena scroll action performed',near)
   # Replay capture and undo still accessible within same session.
   await p.locator('#record').click()
   await ck('replay capturable',len((await state())['scenes'][0]['frames'])>=1)
   await ck('no javascript error end',not errors)
   results.append({'viewport':f'{w}x{h}','count':len(checks),'cases':checks,'y':coords['top'],'coneCells':num})
   print(w,h,len(checks),'PASS',flush=True)
   await p.close()
  await b.close()
 out=root/'evidence/TEST37_negative_results.json';out.write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print('TOTAL',sum(x['count'] for x in results))
if __name__=='__main__':asyncio.run(main())
