"""Deterministic RUN019 TEST42: 2.5D view, synthetic-only distribution."""
from pathlib import Path
import base64,hashlib,json,re,zipfile
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public';D=ROOT/'dist';D.mkdir(exist_ok=True)
NAMES=['index.html','styles.css','app.js','room-v2-adapter.js','room-client.js']
site={n:(P/n).read_bytes() for n in NAMES};html=site['index.html'].decode()
assert 'TEST 42' in html and 'id="isoArt"' in html and 'id="isoBase"' in html
for n in NAMES[1:]:assert (f'href="{n}"' if n.endswith('.css') else f'src="{n}"') in html
assert "connect-src 'none'" in html
sha=lambda b:hashlib.sha256(b).hexdigest()
for n,b in site.items():
 for term in (b'VLAB_R205_',b'FAKE_MASTER_ONLY',b'FAKE_P1_ONLY',b'FAKE_P2_ONLY',b'PRIVATE_MASTER_CORPUS',b'app.notion.com/',b'ghp_',b'BEGIN PRIVATE KEY',b'ponte-vlab-tabletop',b'master_note',b'private_notes',b'FAKE_TEST_PLAYER1'):
  assert term not in b,(n,term)
 assert not re.search(rb'(sk-[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9]{20,})',b),n
def append(z,n,b):
 info=zipfile.ZipInfo(n,date_time=(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
public=D/'TABLETOP_SITE_SINTETICO_TEST42_CANDIDATE.zip'
with zipfile.ZipFile(public,'w') as z:
 for n in NAMES:append(z,n,site[n])
css=site['styles.css'].decode();scripts={n:site[n].decode() for n in ['app.js','room-v2-adapter.js','room-client.js']}
sha64=lambda s:base64.b64encode(hashlib.sha256(s.encode()).digest()).decode()
csp="default-src 'none'; script-src "+' '.join("'sha256-"+sha64(scripts[n])+"'" for n in scripts)+f"; style-src 'sha256-{sha64(css)}'; img-src data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"
offline=html.replace("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'",csp)
offline=offline.replace('<link rel="stylesheet" href="styles.css">','<style>'+css+'</style>')
for n in scripts:offline=offline.replace(f'<script src="{n}" defer></script>','<script>'+scripts[n]+'</script>')
assert '<script src=' not in offline and "connect-src 'none'" in offline
out=D/'TABLETOP_ASSIMILACAO_TEST42_OFFLINE.html';out.write_text(offline)
files=[]
for n in NAMES:files.append(('public/'+n,P/n))
files.append(('baseline/TEST41_TECH_ORIGINAL.zip',ROOT/'baseline/TEST41_TECH_ORIGINAL.zip'))
for folder,pat in [('tests','*.py'),('tests','*.mjs'),('tests','*.cjs'),('docs','*.md'),('evidence','*.json'),('evidence','*.png'),('evidence','*.txt'),('evidence','*.log'),('connected_test','*.py'),('connected_test','*.js')]:
 for f in sorted((ROOT/folder).glob(pat)):
  if f.is_file():files.append((folder+'/'+f.name,f))
for f in sorted((ROOT/'patches').glob('*.diff')):files.append(('patches/'+f.name,f))
for f in sorted((ROOT/'tests'/'fixtures').glob('*.json')):files.append(('tests/fixtures/'+f.name,f))
files.extend([('offline/'+out.name,out),('tools/build_test42.py',Path(__file__))])
manifest={'schema':'assim.tabletop.test42.manifest.v1','run':'RUN-019','baseline':'RUN-018/TEST41','publicFiles':NAMES,'files':{}}
for n,p in files:
 b=p.read_bytes();manifest['files'][n]={'size':len(b),'sha256':sha(b)}
tech=D/'PACOTE_TECNICO_TABLETOP_TEST41_A_TEST42_20261025.zip'
with zipfile.ZipFile(tech,'w') as z:
 for n,p in sorted(files):append(z,n,p.read_bytes())
 append(z,'MANIFEST_SHA256.json',json.dumps(manifest,sort_keys=True,ensure_ascii=False,indent=2).encode())
for f in [public,tech]:
 with zipfile.ZipFile(f) as z:
  assert z.testzip() is None
  if f==tech:
   for n,m in manifest['files'].items():
    raw=z.read(n);assert len(raw)==m['size'] and sha(raw)==m['sha256']
for f in [public,tech,out]:print(f.name,f.stat().st_size,sha(f.read_bytes()))
print('manifest',len(manifest['files']),'PASS; ZIP files',len(manifest['files'])+1)
