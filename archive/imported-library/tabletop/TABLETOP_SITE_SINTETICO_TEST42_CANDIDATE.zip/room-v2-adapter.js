/* Tabletop Assimilação TEST35 — v2 candidate adapter, not a server.
 * PESQ-INOV-20261023-013 proposal is NOT an adopted network contract.
 * Frontend never authenticates: ticket-test-* is a local fixture, never a credential.
 * Projection must be allowlisted by authoritative backend BEFORE transmitting to players.
 */
(()=>{'use strict';
const V2=2, V1='assim.tabletop.room.presentation.v1';
const safe=s=>typeof s==='string'&&/^[a-z][a-z0-9_-]{0,31}$/.test(s)&&!['__proto__','constructor','prototype'].includes(s);
const obj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
const exact=(x,req,opt=[])=>obj(x)&&req.every(k=>Object.hasOwn(x,k))&&Object.keys(x).every(k=>req.includes(k)||opt.includes(k));
const nat=n=>Number.isSafeInteger(n)&&n>=0;
const validProfile=x=>['gm','p1','p2'].includes(x);
const coord=(x,y,n)=>Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<n&&y<n;
function validProjection(s){
 // Explicit TEMPORARY extension over PESQ013 example: n/walls/markers and unit shape.
 // An actual backend missing this extension is incompatible, never guessed from sceneId.
 if(!exact(s,['sceneId','n','walls','units','markers'])||!safe(s.sceneId)||![5,7,10,20].includes(s.n)||!Array.isArray(s.walls)||!Array.isArray(s.units)||!Array.isArray(s.markers)||s.markers.length>40)return false;
 const ids=new Set(),occupied=new Set(),walls=new Set();
 for(const c of s.walls){if(typeof c!=='string'||!/^(0|[1-9]\d*),(0|[1-9]\d*)$/.test(c))return false;let [x,y]=c.split(',').map(Number);if(!coord(x,y,s.n)||walls.has(c))return false;walls.add(c);}
 for(const u of s.units){if(!exact(u,['id','name','mark','team','ownerId','x','y'])||!safe(u.id)||ids.has(u.id)||typeof u.name!=='string'||!u.name.length||u.name.length>45||/[<>\x00-\x1f]/.test(u.name)||typeof u.mark!=='string'||u.mark.length<1||u.mark.length>2||/[<>\x00-\x1f]/.test(u.mark)||!['ally','enemy','neutral'].includes(u.team)||!(u.ownerId===null||safe(u.ownerId))||!coord(u.x,u.y,s.n)||walls.has(`${u.x},${u.y}`)||occupied.has(`${u.x},${u.y}`))return false;
  occupied.add(`${u.x},${u.y}`);ids.add(u.id);
 }
 for(const m of s.markers){if(!exact(m,['id','x','y','label'])||!safe(m.id)||!coord(m.x,m.y,s.n)||typeof m.label!=='string'||m.label.length>100||/[<>\x00-\x1f]/.test(m.label))return false;}
 return true;
}
function validV2Response(p){
 if(!obj(p)||p.v!==V2||!safe(p.roomId)||!['WELCOME','SNAPSHOT','EVENT','ACK','RECEIPT'].includes(p.type))return false;
 if(p.type==='WELCOME')return exact(p,['v','type','roomId','participantId','role','revision','sessionEpoch','snapshot','members'])&&safe(p.participantId)&&['MASTER','PLAYER'].includes(p.role)&&nat(p.revision)&&nat(p.sessionEpoch)&&validProjection(p.snapshot)&&Array.isArray(p.members)&&p.members.length<=3&&p.members.every(m=>exact(m,['id','label','role'])&&safe(m.id)&&typeof m.label==='string'&&m.label.length>0&&m.label.length<=34&&['MASTER','PLAYER'].includes(m.role));
 if(p.type==='SNAPSHOT')return exact(p,['v','type','roomId','revision','snapshot'])&&nat(p.revision)&&validProjection(p.snapshot);
 if(p.type==='EVENT')return exact(p,['v','type','roomId','revision','commandId','kind','actorId','snapshot'])&&nat(p.revision)&&safe(p.commandId)&&['MOVE_VISUAL_TEST','ROOM_UPDATED'].includes(p.kind)&&safe(p.actorId)&&validProjection(p.snapshot);
 if(p.type==='ACK')return exact(p,['v','type','roomId','commandId','status'],['revision','eventId','reason','currentRevision'])&&safe(p.commandId)&&['ACCEPTED','REJECTED'].includes(p.status)&&(p.status==='ACCEPTED'?nat(p.revision)&&safe(p.eventId)&&!Object.hasOwn(p,'reason')&&!Object.hasOwn(p,'currentRevision'):['STALE_REVISION','NOT_OWNER','INVALID_INTENT','ID_REUSE_CONFLICT','UNAUTHORIZED','ROOM_ERROR','MECHANICS_HOLD'].includes(p.reason)&&nat(p.currentRevision)&&!Object.hasOwn(p,'revision')&&!Object.hasOwn(p,'eventId'));
 if(p.type==='RECEIPT')return exact(p,['v','type','roomId','commandId','status'])&&safe(p.commandId)&&p.status==='NOT_FOUND';
 return false;
}
function validV2Outgoing(p){
 if(!obj(p)||p.v!==2||!safe(p.roomId))return false;
 if(p.type==='JOIN')return exact(p,['v','type','roomId','ticket'])&&typeof p.ticket==='string'&&/^test-local-(gm|p1|p2)$/.test(p.ticket); // fixture ONLY
 if(p.type==='INTENT')return exact(p,['v','type','roomId','commandId','baseRevision','kind','unitId','payload'])&&safe(p.commandId)&&nat(p.baseRevision)&&p.kind==='MOVE_VISUAL_TEST'&&safe(p.unitId)&&exact(p.payload,['x','y'])&&coord(p.payload.x,p.payload.y,20);
 if(p.type==='RECEIPT_QUERY')return exact(p,['v','type','roomId','commandId'])&&safe(p.commandId);
 if(p.type==='RESYNC')return exact(p,['v','type','roomId','afterRevision'])&&nat(p.afterRevision);
 return false;
}
// This translator intentionally rejects genuine v2 payloads lacking n/walls/units
// or unknown fields. No role/owner claim is sent with intents; only the TEST ticket
// is sent with JOIN. Never turn a client-selected GM role into actual authority.
function createV2AdapterTransport(v2Factory){
 if(typeof v2Factory!=='function')throw Error('v2 transport missing');
 return ({onMessage,onClose})=>{
  let profile=null,roomId=null,revision=0,connected=false;
  const emit=p=>onMessage(JSON.stringify(p));
  const base=(type,r)=>({schema:V1,type,roomId,revision:r,seq:r});
  const projection=s=>({n:s.n,walls:s.walls,units:s.units});
  const rawTransport=v2Factory({onMessage:raw=>{
   try{if(typeof raw!=='string'||raw.length>65536)throw Error('Frame inválido');
    const p=JSON.parse(raw);if(!validV2Response(p)||p.roomId!==roomId)throw Error('v2: schema incompatível ou projeção privada');
    if(p.type==='WELCOME'){
     const expect=p.role==='MASTER'?'gm':p.participantId;
     if(connected||!profile||p.participantId!==profile||expect!==profile)throw Error('v2: identidade divergente');
     revision=p.revision;connected=true;
     emit({...base('ROOM_JOINED',revision),role:p.role==='MASTER'?'gm':'player',selfId:p.participantId,members:p.members.map(m=>({id:m.id,label:m.label,role:m.role==='MASTER'?'gm':'player'})),snapshot:projection(p.snapshot)});return;
    }
    if(!connected)throw Error('v2: frame antes de WELCOME');
    if(p.type==='SNAPSHOT'){revision=p.revision;emit({...base('ROOM_SNAPSHOT',revision),snapshot:projection(p.snapshot)});return;}
    if(p.type==='EVENT'){if(p.revision<=revision)return;revision=p.revision;emit({...base('ROOM_EVENT',revision),intentId:p.commandId,kind:p.kind==='MOVE_VISUAL_TEST'?'MOVE_CONFIRMED':'ROOM_UPDATED',actorId:p.actorId,snapshot:projection(p.snapshot)});return;}
    if(p.type==='ACK'){const rev=p.status==='ACCEPTED'?p.revision:p.currentRevision;
     emit({...base('ROOM_RECEIPT',rev),intentId:p.commandId,status:p.status,...(p.status==='REJECTED'?{reason:p.reason}:{})});return;
    }
    if(p.type==='RECEIPT'){emit({...base('ROOM_RECEIPT',revision),intentId:p.commandId,status:'NOT_FOUND'});return;}
   }catch(_err){onMessage('{"malformedV2Projection":true}');} // fail-closed in RoomClient, no raw data in log
  },onClose});
  return {send:raw=>{
   const m=JSON.parse(raw);if(m.schema!==V1||m.roomId!=='arena-test')throw Error('v1 incompatible');
   let p;
   if(m.type==='ROOM_JOIN'){if(!validProfile(m.profile))throw Error('Perfil DEMO inválido');profile=m.profile;roomId=m.roomId;p={v:2,type:'JOIN',roomId,ticket:'test-local-'+profile};}
   else if(m.type==='ROOM_INTENT'){p={v:2,type:'INTENT',roomId,commandId:m.intentId,baseRevision:m.revision,kind:'MOVE_VISUAL_TEST',unitId:m.unitId,payload:{x:m.x,y:m.y}};}
   else if(m.type==='ROOM_RECEIPT_QUERY'){p={v:2,type:'RECEIPT_QUERY',roomId,commandId:m.intentId};}
   else if(m.type==='ROOM_RESYNC'){p={v:2,type:'RESYNC',roomId,afterRevision:m.knownRevision};}
   else throw Error('Envelope de saída incompatível');
   if(!validV2Outgoing(p))throw Error('Comando v2 rejeitado');rawTransport.send(JSON.stringify(p));
  },close:()=>rawTransport.close()};
 };
}
// Server-shaped fixture only; this is NOT WebSocket, authentication or Durable Object.
const mock={roomId:'arena-test',revision:0,n:7,walls:['3,3'],units:[
 {id:'demo_a',name:'Exploradora TEST',mark:'E',team:'ally',ownerId:'p1',x:1,y:1},
 {id:'demo_b',name:'Conjurador TEST',mark:'C',team:'ally',ownerId:'p2',x:1,y:4},
 {id:'demo_n',name:'Criatura TEST',mark:'X',team:'enemy',ownerId:null,x:5,y:3}],
 peers:new Set(),receipts:new Map(),dropNextAck:false,sessionEpoch:1};
const members=[{id:'gm',label:'Mestre TEST',role:'MASTER'},{id:'p1',label:'Player 1 TEST',role:'PLAYER'},{id:'p2',label:'Player 2 TEST',role:'PLAYER'}];
function mockV2TransportFactory({onMessage,onClose}){
 const peer={id:null,closed:false,onMessage,onClose};mock.peers.add(peer);
 const emit=(p,target=peer)=>{if(!target.closed)target.onMessage(JSON.stringify(p));};
 const base=type=>({v:2,type,roomId:mock.roomId});
 const project=id=>({sceneId:'scene-test',n:mock.n,walls:[...mock.walls],markers:[],units:mock.units.filter(u=>id==='gm'||u.ownerId===id).map(u=>({...u}))});
 const ack=(id,p)=>{mock.receipts.set(id+':'+p.commandId,{payload:JSON.stringify(p),response:p.response});};
 return {send:raw=>{
  const p=JSON.parse(raw);if(!validV2Outgoing(p)||p.roomId!==mock.roomId)throw Error('Mock packet invalid');
  if(p.type==='JOIN'){peer.id=p.ticket.slice('test-local-'.length);emit({...base('WELCOME'),participantId:peer.id,role:peer.id==='gm'?'MASTER':'PLAYER',revision:mock.revision,sessionEpoch:mock.sessionEpoch,snapshot:project(peer.id),members:members.map(m=>({...m}))});return;}
  if(!peer.id)throw Error('JOIN before actions');
  if(p.type==='RECEIPT_QUERY'){
   const found=mock.receipts.get(peer.id+':'+p.commandId);emit(found?found.response:{...base('RECEIPT'),commandId:p.commandId,status:'NOT_FOUND'});return;
  }
  if(p.type==='RESYNC'){emit({...base('SNAPSHOT'),revision:mock.revision,snapshot:project(peer.id)});return;}
  const key=peer.id+':'+p.commandId,old=mock.receipts.get(key),fingerprint=JSON.stringify(p);
  if(old){if(old.payload===fingerprint){emit(old.response);return;}
   emit({...base('ACK'),commandId:p.commandId,status:'REJECTED',reason:'ID_REUSE_CONFLICT',currentRevision:mock.revision});return;}
  const u=mock.units.find(u=>u.id===p.unitId);let reason=null;
  if(p.baseRevision!==mock.revision)reason='STALE_REVISION';
  else if(!u||(peer.id!=='gm'&&u.ownerId!==peer.id))reason='NOT_OWNER';
  else if((p.payload.x===u.x&&p.payload.y===u.y)||p.payload.x>=mock.n||p.payload.y>=mock.n||mock.walls.includes(`${p.payload.x},${p.payload.y}`)||mock.units.some(x=>x.id!==u.id&&x.x===p.payload.x&&x.y===p.payload.y))reason='INVALID_INTENT';
  if(reason){const response={...base('ACK'),commandId:p.commandId,status:'REJECTED',reason,currentRevision:mock.revision};mock.receipts.set(key,{payload:fingerprint,response});emit(response);return;}
  // Synthetic authoritative fixture: only visual XY; no PA/damage/pathing/turn calculations.
  u.x=p.payload.x;u.y=p.payload.y;mock.revision++;
  const response={...base('ACK'),commandId:p.commandId,status:'ACCEPTED',revision:mock.revision,eventId:'ev-'+mock.revision};
  mock.receipts.set(key,{payload:fingerprint,response});
  const drop=mock.dropNextAck;mock.dropNextAck=false;
  if(!drop)emit(response);
  for(const target of [...mock.peers]){
   if(target.closed||!target.id||drop&&target===peer)continue;
   if(target.id==='gm'||u.ownerId===target.id)emit({...base('EVENT'),revision:mock.revision,commandId:p.commandId,kind:'MOVE_VISUAL_TEST',actorId:u.id,snapshot:project(target.id)},target);
   else emit({...base('SNAPSHOT'),revision:mock.revision,snapshot:project(target.id)},target);
  }
 },close:()=>{if(peer.closed)return;peer.closed=true;mock.peers.delete(peer);onClose();}};
}
window.TabletopRoomV2TEST={createV2AdapterTransport,mockV2TransportFactory,mock,validV2Response,validV2Outgoing,validProjection};
})();
