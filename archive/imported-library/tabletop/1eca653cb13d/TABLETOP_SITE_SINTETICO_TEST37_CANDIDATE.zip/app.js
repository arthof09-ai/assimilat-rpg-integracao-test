/* Tabletop Assimilação — TEST27–33, FRONT-END AUTORAL / SINTÉTICO.
 * Não contém motores de combate, contas, rede, credenciais ou dados canônicos.
 * TEST 06 original preservado separadamente; esta é evolução do modelo visual.
 */
(()=>{'use strict';
const $=id=>document.getElementById(id), clone=x=>JSON.parse(JSON.stringify(x));
const MAX_SCENES=8, MAX_UNITS=30, MAX_EVENTS=100, MAX_LOGS=80, MAX_MARKERS=40, MAX_FILE=750000;
const KEY='assim.tabletop.synthetic.workspace.v1', WORKSCHEMA='assim.tabletop.synthetic.workspace.v1', REPLAYSCHEMA='assim.lab.vlab.readonly.v1';
const validId=x=>typeof x==='string'&&/^[a-z0-9_-]{1,32}$/.test(x)&&!['__proto__','constructor','prototype'].includes(x);
const textOK=(x,max=80)=>typeof x==='string'&&x.length>0&&x.length<=max&&!/[<>\u0000-\u001f]/.test(x);
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
const safeKeys=(x)=>plain(x)&&Object.keys(x).every(k=>!['__proto__','constructor','prototype'].includes(k));
const allowedSize=[5,7,10,20], xy=(x,y)=>`${x},${y}`, inside=(x,y,n)=>Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<n&&y<n;
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
// TEST30: only one textual encoding represents each map cell. No leading zero aliases.
const parseCoord=(key,n)=>{
 if(typeof key!=='string'||!/^\d+,\d+$/.test(key))return null;
 const [x,y]=key.split(',').map(Number);return inside(x,y,n)?{x,y,key:xy(x,y)}:null;
};
const isCanonicalCoord=(key,n)=>{const p=parseCoord(key,n);return Boolean(p&&key===p.key);};
// Pure planner for explicit legacy-backup normalization. It never edits input/storage.
function planCoordinateMigration(raw){
 if(!safeKeys(raw)||raw.schema!==WORKSCHEMA||raw.version!==1||!Array.isArray(raw.scenes))return {status:'INVALID_SOURCE',reason:'Schema incompatível'};
 const w=migrateWorkspace(clone(raw));let changes=0;
 try{for(const sc of w.scenes){
  if(!safeKeys(sc)||!allowedSize.includes(sc.n)||!safeKeys(sc.terrain))throw Error('Cena inválida');
  let changedWalls=false;
  for(const prop of ['walls','danger','explored']){
   if(!Array.isArray(sc[prop]))throw Error('Camada inválida: '+prop);
   const mapped=[],unique=new Set();
   for(const key of sc[prop]){
    const canon=parseCoord(key,sc.n);if(!canon)throw Error('Coordenada inválida em '+prop);
    if(unique.has(canon.key))return {status:'CONFLICT',reason:'Coordenadas equivalentes duplicadas em '+prop};
    unique.add(canon.key);mapped.push(canon.key);
    if(key!==canon.key){changes++;if(prop==='walls')changedWalls=true;}
   }sc[prop]=mapped;
  }
  const terrain={},terrainIds=new Set();
  for(const [key,val] of Object.entries(sc.terrain)){
   const canon=parseCoord(key,sc.n);if(!canon)throw Error('Terreno em coordenada inválida');
   if(terrainIds.has(canon.key))return {status:'CONFLICT',reason:'Terrenos equivalentes duplicados'};
   terrainIds.add(canon.key);terrain[canon.key]=val;if(key!==canon.key)changes++;
  }sc.terrain=terrain;
  if(changedWalls&&(sc.frames?.length||sc.frameTopology!==null))return {status:'CONFLICT',reason:'Replay vinculado à topologia anterior; exporte e revise antes de normalizar paredes'};
 }
 }catch(e){return {status:'INVALID_SOURCE',reason:String(e.message||e)};}
 if(!validateWorkspace(w))return {status:'CONFLICT',reason:'Colisão de topologia, unidade, perigo ou outro dado inválido após normalização'};
 return {status:changes?'SAFE_NORMALIZATION':'NO_CHANGE',changes,candidate:w};
}

const stamp=()=>new Date().toISOString().slice(0,19);
const unit=(id,name,mark,team,x,y)=>({id,name,mark,team,x,y,range:1,hp:100,soul:50,pa:60});
function newScene(id='c1',name='Cena de exploração TEST',n=7){return {id,name,n,walls:[],danger:[],terrain:{},markers:[],units:[unit('u1','Exploradora TEST','E','ally',1,1),unit('u2','Conjurador TEST','C','ally',1,3),unit('u3','Criatura TEST','X','enemy',n-2,2)],selected:'u1',mode:'play',round:1,stepsUsed:0,acted:false,logs:['Cena sintética criada; nenhuma fonte oficial.'],notes:'',frames:[],frameTopology:null,explored:[],fovEnabled:false,fovRadius:8};}
const defaultWorkspace=()=>({schema:WORKSCHEMA,version:1,revision:0,active:'c1',scenes:[newScene()]});
let workspace=defaultWorkspace(),history=[],future=[],zoom=44,playTimer=null,viewReplay=null,replayOrigin=null,frameIndex=0,renderLast=0;
let editingNew=false,editingId=null,lastCell=null,gesture={pointers:new Map(),start:null,suppress:false,dragged:false};
let storageState='COMMITTED_VERIFIED',storageUncertain=null,externalConflict=null,lastVerifiedRaw=null,pendingRestore=null,restoreDialogOpen=false,markerDialogOpen=false,markerEditId=null,markerTarget=null,toastTimer=null;
// Régua visual, não persistida e sem regras oficiais: um par de células da cena ativa.
let rulerA=null,rulerB=null,rulerSceneId=null;
// TEST37: tactical intentions are ephemeral presentation, NOT effects or persistence.
let tactical=null, tacticalResult=null;
const TACTIC_ACTIONS=Object.freeze({inspect:'Examinar TEST',attack:'Atacar TEST',line:'Linha TEST',radius:'Círculo TEST',cone:'Cone TEST'});
function clearTactical(){tactical=null;tacticalResult=null;}
function chooseTacticalAction(value){
 if(value&&!Object.hasOwn(TACTIC_ACTIONS,value))return;
 storageGuard();const s=scene(),u=selected();clearTactical();
 if(value){if(!u){note('Selecione uma unidade antes de escolher uma ação.');renderTactical();return;}
  if(s.mode!=='play')s.mode='play';
  tactical={sceneId:s.id,actorId:u.id,action:value,targetId:null,target:null};
  note('Ação '+TACTIC_ACTIONS[value]+': escolha alvo no tabuleiro.');
 }
 render();
}
function tacticArea(s){
 const t=tactical;if(!t||t.sceneId!==s.id||!t.target)return new Set();
 const result=new Set(),x=t.target.x,y=t.target.y;
 if(t.action==='radius'){
  for(let ry=0;ry<s.n;ry++)for(let rx=0;rx<s.n;rx++)if((rx-x)**2+(ry-y)**2<=4)result.add(xy(rx,ry));
 }else if(t.action==='cone'){
  const actor=s.units.find(u=>u.id===t.actorId);if(!actor)return result;
  const vx=x-actor.x,vy=y-actor.y,len=Math.hypot(vx,vy);
  if(len===0)return result;
  // Visual fixture only: cone de 60° por 3 células, não alcance oficial.
  for(let cy=0;cy<s.n;cy++)for(let cx=0;cx<s.n;cx++){
   const dx=cx-actor.x,dy=cy-actor.y,d=Math.hypot(dx,dy);
   if(d>0&&d<=3&&(dx*vx+dy*vy)/(d*len)>=Math.cos(Math.PI/6))result.add(xy(cx,cy));
  }
 }else if(t.action==='line'){
  const actor=s.units.find(u=>u.id===t.actorId);if(!actor)return result;
  let x0=actor.x,y0=actor.y,dx=Math.abs(x-x0),sx=x0<x?1:-1,dy=-Math.abs(y-y0),sy=y0<y?1:-1,err=dx+dy;
  for(let i=0;i<=s.n*2;i++){if(inside(x0,y0,s.n))result.add(xy(x0,y0));if(x0===x&&y0===y)break;const e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}
 }else result.add(xy(x,y));
 return result;
}
function renderTactical(){
 const s=scene(),u=selected(),t=tactical;
 if(t&&(!u||t.sceneId!==s.id||t.actorId!==u.id))clearTactical();
 const active=tactical, phase=tacticalResult?'hold':!active?'idle':!active.target?'target':'ready';
 const summary=u?u.name+' · '+u.team+' · Vida '+u.hp+' / Alma '+u.soul+' / PA '+u.pa+' (fictícios)':'Nenhuma unidade';
 $('tacticActor').textContent=summary;$('tacticHud').dataset.phase=phase;
 $('tacticAction').value=active?.action||'';$('tacticConfirm').disabled=!active?.target;
 $('tacticCancel').disabled=!active&&!tacticalResult;
 if(tacticalResult){$('tacticReadout').textContent=tacticalResult;return;}
 if(!active){$('tacticReadout').textContent='Toque numa unidade, escolha a ação e indique o alvo. MECÂNICA INDISPONÍVEL — TEST.';return;}
 if(!active.target){$('tacticReadout').textContent=TACTIC_ACTIONS[active.action]+' · AGUARDANDO ALVO. Toque na unidade/casa desejada; cancelar não muda recursos.';return;}
 const target=s.units.find(z=>z.id===active.targetId),name=target?.name||`casa ${active.target.x+1},${active.target.y+1}`;
 const total=tacticArea(s).size;
 $('tacticReadout').textContent=`PRÉVIA TEST: ${u.name} → ${TACTIC_ACTIONS[active.action]} → ${name}; ${total} casa(s) destacada(s) VISUALMENTE. MECÂNICA INDISPONÍVEL — TEST.`;
}
function chooseTacticalTarget(x,y,at){
 const s=scene(),t=tactical,u=selected();if(!t||!u)return false;
 if(t.action==='inspect'||t.action==='attack'){
  if(!at||at.id===u.id){note('Escolha outra unidade como alvo, não uma casa vazia ou o próprio ator.');return true;}
 }
 if(t.action==='cone'&&u.x===x&&u.y===y){note('Escolha a direção do cone tocando outra casa.');return true;}
 t.target={x,y};t.targetId=at?.id||null;tacticalResult=null;renderBoard(s);renderTactical();
 note('Prévia TEST pronta. Confirme ou cancele; nenhum efeito mecânico será executado.');return true;
}
function confirmTactical(){
 const s=scene(),t=tactical,u=selected();if(!t||!t.target||!u)return;
 const target=s.units.find(z=>z.id===t.targetId);
 tacticalResult=`INTENÇÃO VISUAL CONFIRMADA · ${u.name} / ${TACTIC_ACTIONS[t.action]} / ${target?.name||'casa '+(t.target.x+1)+','+(t.target.y+1)}. MECÂNICA INDISPONÍVEL — TEST. NÃO ENVIADA; sem dano, PA, turno, efeito ou ACK.`;
 tactical=null;renderBoard(s);renderTactical();note(tacticalResult);
}


const scene=()=>workspace.scenes.find(s=>s.id===workspace.active), selected=()=>scene().units.find(u=>u.id===scene().selected);
const note=t=>{$('message').textContent=t;};
function pushLog(s,t){s.logs.unshift(`[${stamp()}] ${t}`);s.logs=s.logs.slice(0,MAX_LOGS);}
function migrateWorkspace(w){
 // Migration limited to TEST15 v1 fields; do not rewrite unknown schema versions.
 if(!safeKeys(w)||w.schema!==WORKSCHEMA||w.version!==1||!Array.isArray(w.scenes))return w;
 if(!Object.hasOwn(w,'revision'))w.revision=0;
 for(const sc of w.scenes){if(safeKeys(sc)){
   if(!Object.hasOwn(sc,'markers'))sc.markers=[];
   if(!Object.hasOwn(sc,'explored'))sc.explored=[];
   if(!Object.hasOwn(sc,'fovEnabled'))sc.fovEnabled=false;
   if(!Object.hasOwn(sc,'fovRadius'))sc.fovRadius=8;
 }}return w;
}
function validateScene(s){
 if(!safeKeys(s)||!validId(s.id)||!textOK(s.name,70)||!allowedSize.includes(s.n)||!Array.isArray(s.units)||s.units.length>MAX_UNITS||!Array.isArray(s.walls)||!Array.isArray(s.danger)||!safeKeys(s.terrain)||!Array.isArray(s.logs)||s.logs.length>MAX_LOGS||!textOK(s.mode,20)||!['play','pan','wall','danger','terrain','erase','place','measure','mark'].includes(s.mode)||!Number.isSafeInteger(s.round)||s.round<1||s.round>999999||!Number.isSafeInteger(s.stepsUsed)||s.stepsUsed<0||s.stepsUsed>4||typeof s.acted!=='boolean'||typeof s.notes!=='string'||s.notes.length>800||!Array.isArray(s.frames)||s.frames.length>MAX_EVENTS)return false;
 const ids=new Set(),where=new Set();for(const u of s.units){if(!safeKeys(u)||!validId(u.id)||ids.has(u.id)||!textOK(u.name,48)||!textOK(u.mark,2)||!['ally','enemy','neutral'].includes(u.team)||!inside(u.x,u.y,s.n)||where.has(xy(u.x,u.y))||!Number.isInteger(u.range)||u.range<1||u.range>20||![u.hp,u.soul,u.pa].every(v=>Number.isInteger(v)&&v>=0&&v<=99999))return false;ids.add(u.id);where.add(xy(u.x,u.y));}
 if(s.selected!==null&&!ids.has(s.selected))return false;
 for(const list of [s.walls,s.danger]){if(list.length>s.n*s.n||new Set(list).size!==list.length)return false;for(const key of list){if(!isCanonicalCoord(key,s.n)||where.has(key))return false;}}
 if(s.walls.some(x=>s.danger.includes(x)||Object.hasOwn(s.terrain,x)))return false;
 for(const [k,v] of Object.entries(s.terrain)){if(!isCanonicalCoord(k,s.n)||!['grass','sand','water'].includes(v))return false;}
 // Markers are independent presentation data, scoped to a scene and never gameplay units.
 if(!Array.isArray(s.markers)||s.markers.length>MAX_MARKERS)return false;
 const markerIds=new Set(),markerCells=new Set();for(const m of s.markers){
  if(!safeKeys(m)||!validId(m.id)||markerIds.has(m.id)||markerCells.has(xy(m.x,m.y))||!inside(m.x,m.y,s.n)||
     !['pin','note','highlight'].includes(m.kind)||!textOK(m.text,100)||
     Object.keys(m).some(k=>!['id','x','y','kind','text'].includes(k)))return false;
  markerIds.add(m.id);markerCells.add(xy(m.x,m.y));
 }
 if(s.logs.some(x=>typeof x!=='string'||x.length>400||/[<>]/.test(x)))return false;
 if(s.frameTopology!==null&&s.frameTopology!==topology(s))return false;
 if(s.frames.length>0&&s.frameTopology===null)return false;
 if(!Array.isArray(s.explored)||s.explored.length>s.n*s.n||new Set(s.explored).size!==s.explored.length||typeof s.fovEnabled!=='boolean'||!Number.isSafeInteger(s.fovRadius)||s.fovRadius<2||s.fovRadius>20)return false;
 for(const k of s.explored){if(!isCanonicalCoord(k,s.n))return false;}
 for(const f of s.frames){if(!safeKeys(f)||!textOK(f.title,100)||!safeKeys(f.positions)||Object.keys(f.positions).length!==ids.size)return false;const occupied=new Set();for(const id of ids){const p=f.positions[id];if(!Array.isArray(p)||p.length!==2||!inside(p[0],p[1],s.n)||s.walls.includes(xy(...p))||occupied.has(xy(...p)))return false;occupied.add(xy(...p));}if(Object.keys(f.positions).some(k=>!ids.has(k)||!validId(k)))return false;}
 return true;
}
function validateWorkspace(w){if(!safeKeys(w)||w.schema!==WORKSCHEMA||w.version!==1||!(w.revision===undefined||(Number.isSafeInteger(w.revision)&&w.revision>=0&&w.revision<1000000000))||!Array.isArray(w.scenes)||w.scenes.length<1||w.scenes.length>MAX_SCENES||!validId(w.active))return false;const ids=new Set();for(const s of w.scenes){if(!validateScene(s)||ids.has(s.id))return false;ids.add(s.id);}return ids.has(w.active);}
// TEST20: three-valued durability; failed readback is NEVER proof of rollback.
function persistError(status,message,cause){const error=new Error(message||String(cause?.message||cause||status));error.storageStatus=status;return error;}
function storageGuard(){
 if(storageUncertain)throw persistError('UNKNOWN_AFTER_WRITE','Persistência ainda indeterminada; exporte a memória e reconcilie antes de editar.');
 if(externalConflict)throw persistError('EXTERNAL_CONFLICT','Outra aba alterou o salvamento. Exporte a memória e confira a versão gravada antes de editar.');
}
function showToast(kind,message){
 const toast=$('saveToast');if(!toast)return;
 if(toastTimer!==null)clearTimeout(toastTimer);
 toast.hidden=false;toast.dataset.kind=kind;toast.textContent=message;
 if(kind==='success')toastTimer=setTimeout(()=>{toast.hidden=true;toastTimer=null;},3600);
}
function externalAlert(observed,reason){
 if(storageUncertain)return;
 externalConflict={observed,reason,verifiedCandidate:null,verifiedRaw:null};
 storageState='EXTERNAL_CONFLICT';stopReplay();
 if(restoreDialogOpen)cancelRestoreReview();
 if(markerDialogOpen)closeMarkerDialog();
 storageBanner('Outra aba alterou o salvamento ou há divergência de revisão. Exporte a memória, confira o armazenamento e escolha a versão. Nenhuma substituição automática será feita.');
 showToast('warning','⚠ Conflito entre abas: alterações não foram sobrescritas.');
 note('CONFLITO: outra aba modificou o salvamento. Exportar memória → Conferir armazenamento → Adotar explicitamente se desejar.');
}

function updateModalIsolation(){const root=document.querySelector('.shell');if(root)root.inert=Boolean(storageUncertain||externalConflict||restoreDialogOpen||markerDialogOpen);}
function storageBanner(message){
 updateModalIsolation();
 const panel=$('storageConflict');if(!panel)return;
 const active=Boolean(storageUncertain||externalConflict);
 panel.hidden=!active;
 $('storageConflictHeading').textContent=externalConflict?'⚠ Conflito entre abas':'⚠ Persistência indeterminada';
 $('storageConflictInfo').textContent=active?(message||'O armazenamento pode conter dados diferentes. Exporte primeiro o estado aberto e confira o armazenamento.') : '';
 if(active){$('storageStatus').textContent=externalConflict?'CONFLITO: OUTRA ABA ALTEROU O SALVAMENTO — confira antes de editar':'ATENÇÃO: PERSISTÊNCIA INDETERMINADA — exporte e reconcilie';$('storageExport').focus();}
}
// TEST27: optimistic localStorage check. Detection, NOT an atomic compare-and-swap.
function persistChecked(candidate){
 storageGuard();
 if(!validateWorkspace(candidate))throw persistError('FAILED_CONFIRMED','Estado TEST inválido');
 let previous;
 try{previous=localStorage.getItem(KEY);}catch(e){storageState='FAILED_CONFIRMED';throw persistError('FAILED_CONFIRMED','Não foi possível ler o estado anterior; nenhuma gravação foi iniciada.',e);}
 if(previous!==lastVerifiedRaw){externalAlert(previous,'PRE_WRITE_REVISION_MISMATCH');throw persistError('EXTERNAL_CONFLICT','O salvamento mudou desde que esta aba o leu. Nenhum write foi iniciado.');}
 let previousRevision=workspace.revision??0;
 if(previous!==null){try{const stored=JSON.parse(previous);if(Number.isSafeInteger(stored.revision)&&stored.revision>=0)previousRevision=stored.revision;else previousRevision=0;}catch(e){throw persistError('FAILED_CONFIRMED','Salvamento existente ilegível: exporte original antes de substituir.');}}
 if(previousRevision>=999999998)throw persistError('FAILED_CONFIRMED','Limite de revisões atingido. Exporte backup.');
 const next=clone(candidate);next.revision=previousRevision+1;
 if(!validateWorkspace(next))throw persistError('FAILED_CONFIRMED','Estado candidato inválido');
 const serialized=JSON.stringify(next);
 if(serialized.length>MAX_FILE)throw persistError('FAILED_CONFIRMED','Salvamento acima de 750 KB; exporte um backup menor.');
 let wrote=false,reason;
 try{
  localStorage.setItem(KEY,serialized);wrote=true;
  if(localStorage.getItem(KEY)!==serialized)throw Error('Verificação de leitura local divergente');
  storageState='COMMITTED_VERIFIED';candidate.revision=next.revision;lastVerifiedRaw=serialized;return true;
 }catch(e){reason=e;}
 try{
  const now=localStorage.getItem(KEY);
  if(now===previous){storageState='FAILED_CONFIRMED';throw persistError('FAILED_CONFIRMED','Gravação não confirmada; estado anterior relido. '+reason.message,reason);}
  if(now!==previous){
   if(previous===null)localStorage.removeItem(KEY);else localStorage.setItem(KEY,previous);
   if(localStorage.getItem(KEY)===previous){storageState='FAILED_CONFIRMED';throw persistError('FAILED_CONFIRMED','Restauração recusada e estado anterior revalidado. '+reason.message,reason);}
  }
 }catch(e){if(e.storageStatus==='FAILED_CONFIRMED')throw e;}
 storageState='UNKNOWN_AFTER_WRITE';
 storageUncertain={previous,serialized,candidate:next,previousWorkspace:clone(workspace),cause:String(reason?.message||reason),wrote};
 storageBanner('O navegador não confirmou o salvamento nem a reversão. Exporte o estado aberto ANTES de recarregar. Depois confira o armazenamento.');
 throw persistError('UNKNOWN_AFTER_WRITE','Estado do armazenamento INDETERMINADO após tentativa de gravação; nenhum rollback confirmado.');
}
function saveLocal(quiet=true){
 try{persistChecked(workspace);$('storageStatus').textContent='✓ Salvo e relido neste navegador · revisão '+workspace.revision+' · '+stamp();if(!quiet){note('✓ Salvo neste navegador, conferido por leitura. Backup é um arquivo separado.');showToast('success','✓ Salvo neste navegador — confirmado por leitura.');}return true;}
 catch(e){
  if(storageUncertain||externalConflict){storageBanner();note(externalConflict?'CONFLITO entre abas: exporte a memória e reconcilie; não houve sobrescrita.':'ATENÇÃO: persistência INDETERMINADA. Exporte o estado aberto; confira o armazenamento antes de editar.');showToast('warning',externalConflict?'⚠ Outra aba salvou alterações.':'⚠ Salvamento não confirmado.');}
  else{$('storageStatus').textContent='NÃO SALVO: '+e.message+' • exporte backup';if(!quiet){note('FALHA ao salvar: '+e.message+'. As alterações atuais podem se perder ao reabrir.');showToast('error','✕ Salvamento não confirmado.');}}
  return false;
 }
}
function restoreCandidate(raw){
 storageGuard();const candidate=migrateWorkspace(clone(raw));
 persistChecked(candidate);
 stopReplay();workspace=candidate;history=[];future=[];clearReplay();closeTokenForm();render();center();
 $('storageStatus').textContent='Backup restaurado, gravado e relido · '+stamp();
 return true;
}
function inspectReconcile(){
 if(externalConflict){
  let raw;try{raw=localStorage.getItem(KEY);}catch(e){storageBanner('Leitura indisponível: '+e.message+'. Exporte o estado aberto.');return 'UNREADABLE';}
  if(raw===lastVerifiedRaw){externalConflict=null;storageState='COMMITTED_VERIFIED';storageBanner();note('Armazenamento alinhado novamente; nenhum dado substituído.');return 'ALIGNED';}
  try{if(!raw||raw.length>MAX_FILE)throw Error('Salvamento ausente ou acima do limite');const planned=planCoordinateMigration(JSON.parse(raw));if(!['NO_CHANGE','SAFE_NORMALIZATION'].includes(planned.status))throw Error(planned.reason||planned.status);
   const candidate=planned.candidate;externalConflict.verifiedCandidate=candidate;externalConflict.verifiedRaw=raw;externalConflict.migrationCount=planned.changes||0;
   storageBanner((planned.changes?'Formato antigo: '+planned.changes+' chave(s) de coordenadas podem ser normalizadas mediante confirmação. ':'Versão externa válida encontrada. ')+candidate.scenes.length+' cena(s), revisão '+(candidate.revision??0)+'. Exporte a memória antes de decidir adotar.');return 'EXTERNAL_AVAILABLE';}
  catch(e){storageBanner('Conteúdo externo inválido ou divergente. Preserve o estado aberto e o backup; não haverá importação automática. '+e.message);return 'INVALID_EXTERNAL';}
 }
 if(!storageUncertain)return 'CLEAR';
 let current;try{current=localStorage.getItem(KEY);}catch(e){storageBanner('Leitura ainda indisponível: '+e.message+'. Preserve e exporte o estado aberto.');return 'UNREADABLE';}
 const p=storageUncertain;
 if(current===p.previous){storageUncertain=null;storageState='FAILED_CONFIRMED';storageBanner();$('storageStatus').textContent='Reconciliado: estado anterior confirmado no armazenamento.';note('Estado anterior confirmado; pode continuar a editar.');return 'STORED_PREVIOUS';}
 if(current===p.serialized){storageBanner('O armazenamento contém o candidato restaurado, mas a tela mantém a versão anterior. Exporte antes de escolher “Adotar o gravado”.');return 'STORED_CANDIDATE';}
 storageBanner('Armazenamento divergente do anterior e do candidato. Não substitua; exporte o estado em memória e reconcilie manualmente.');return 'DIVERGED';
}
function adoptReconciled(){
 if(externalConflict){
  if(inspectReconcile()!=='EXTERNAL_AVAILABLE')return false;
  const known=externalConflict.verifiedRaw;
  if(!window.confirm('A versão em outra aba tem '+externalConflict.verifiedCandidate.scenes.length+' cena(s). Adotá-la e DESCARTAR o estado em memória? Exporte primeiro se necessário.'))return false;
  try{if(localStorage.getItem(KEY)!==known){storageBanner('Outra gravação ocorreu enquanto você confirmava. Confira novamente.');return false;}}
  catch(e){storageBanner('Leitura falhou durante a confirmação. Nenhuma versão adotada.');return false;}
  const restored=clone(externalConflict.verifiedCandidate),mig=externalConflict.migrationCount||0;
  if(mig){
   if(!window.confirm('O armazenamento contém '+mig+' chave(s) antigas de coordenadas. Normalizar e SALVAR agora, preservando a cópia bruta que você exportou?'))return false;
   const held=externalConflict,originalExpected=lastVerifiedRaw;
   externalConflict=null;lastVerifiedRaw=known;
   try{persistChecked(restored);}catch(e){if(!storageUncertain){externalConflict=held;lastVerifiedRaw=originalExpected;storageBanner('Falha ao normalizar: '+e.message+'. Original preservado ou estado indeterminado.');}return false;}
   workspace=restored;
  }else{workspace=restored;lastVerifiedRaw=known;externalConflict=null;storageState='COMMITTED_VERIFIED';}
  history=[];future=[];clearReplay();closeTokenForm();invalidateFov();storageBanner();render();center();
  $('storageStatus').textContent='Versão externa adotada após leitura — revisão '+workspace.revision;note('Versão externa reconciliada sem sobrescrever o armazenamento.');return true;
 }
 if(!storageUncertain)return false;
 const status=inspectReconcile();if(status!=='STORED_CANDIDATE')return false;
 if(!window.confirm('O navegador contém o backup importado, diferente da cena aberta. Adotar a versão gravada agora? Exporte primeiro a cena aberta se precisar preservá-la.'))return false;
 const p=storageUncertain;
 try{if(localStorage.getItem(KEY)!==p.serialized){storageBanner('O armazenamento mudou durante a confirmação. Confira novamente.');return false;}}catch(e){return false;}
 workspace=clone(p.candidate);lastVerifiedRaw=p.serialized;storageUncertain=null;storageState='COMMITTED_VERIFIED';history=[];future=[];clearReplay();closeTokenForm();storageBanner();render();center();
 $('storageStatus').textContent='Versão gravada verificada e adotada · '+stamp();note('Versão persistida adotada após reconciliação.');return true;
}
function restoreReview(candidate){
 const active=workspace.scenes, next=candidate.scenes, removed=active.filter(sc=>!next.some(v=>v.id===sc.id));
 const changed=active.filter(sc=>next.some(v=>v.id===sc.id&&!equal(sc,v)));
 return {currentCount:active.length,incomingCount:next.length,removedCount:removed.length,changedCount:changed.length,requiresReview:next.length<active.length||removed.length>0||changed.length>0};
}
function showRestoreReview(raw,stats){
 pendingRestore=clone(raw);restoreDialogOpen=true;updateModalIsolation();
 $('restoreReview').hidden=false;
 $('restoreReviewSummary').textContent=`Agora: ${stats.currentCount} cena(s). Backup: ${stats.incomingCount} cena(s). ${stats.removedCount} cena(s) desapareceriam e ${stats.changedCount} seriam alteradas.${stats.migrationCount?' '+stats.migrationCount+' chave(s) antigas de coordenadas serão normalizadas após sua confirmação.':''} Esta ação substitui TODO o conjunto local. Exporte o atual para não perdê-lo.`;
 $('restoreReviewConfirm').focus();
}
function cancelRestoreReview(){pendingRestore=null;restoreDialogOpen=false;$('restoreReview').hidden=true;updateModalIsolation();}
function loadLocal(){let raw=null;
 try{raw=localStorage.getItem(KEY);if(!raw)return;if(raw.length>MAX_FILE)throw Error('Salvamento acima do limite');const val=JSON.parse(raw);migrateWorkspace(val);if(!validateWorkspace(val))throw Error('Estado anterior inválido ou coordenadas ambíguas');workspace=val;lastVerifiedRaw=raw;}
 catch(e){$('storageStatus').textContent='Salvamento anterior sob revisão: '+e.message+'; dados originais preservados.';
  if(raw){externalAlert(raw,'INVALID_STORED_WORKSPACE');storageBanner('O armazenamento contém formato antigo ou dados inválidos. Exporte a cópia bruta antes de importar uma versão normalizada. Nenhuma gravação ocorreu.');}
 }
}
function download(obj,name){const blob=new Blob([JSON.stringify(obj)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function readJSON(file){if(!file||file.size>MAX_FILE)throw Error('Arquivo acima do limite de 750 KB');return JSON.parse(await file.text());}
function positions(s){return Object.fromEntries(s.units.map(u=>[u.id,[u.x,u.y]]));}
function topology(s){return JSON.stringify({n:s.n,walls:[...s.walls].sort(),ids:s.units.map(x=>x.id).sort()});}
function captureFrame(s,title){const top=topology(s);if(s.frameTopology!==top){s.frames=[];s.frameTopology=top;}s.frames.push({title,positions:positions(s)});if(s.frames.length>MAX_EVENTS)s.frames.shift();}
function snap(){storageGuard();history.push(clone(workspace));if(history.length>40)history.shift();future=[];}
function commit(s,msg,record=false){pushLog(s,msg);if(record)captureFrame(s,msg);render();saveLocal();}
function undo(){clearTactical();storageGuard();if(!history.length)return note('Nada para desfazer.');stopReplay();future.push(clone(workspace));workspace=history.pop();render();saveLocal();note('Alteração desfeita.');}
function redo(){clearTactical();storageGuard();if(!future.length)return note('Nada para refazer.');stopReplay();history.push(clone(workspace));workspace=future.pop();render();saveLocal();note('Alteração refeita.');}
function nextId(prefix,existing){let i=1;while(existing.has(`${prefix}${i}`))i++;return `${prefix}${i}`;}
function neighbors(s,x,y){return [[1,0],[-1,0],[0,1],[0,-1]].map(([dx,dy])=>[x+dx,y+dy]).filter(([nx,ny])=>inside(nx,ny,s.n));}
function allRoutes(s,active){const dist=new Map([[xy(active.x,active.y),0]]),prev=new Map(),queue=[[active.x,active.y]],blocked=new Set([...s.walls,...s.units.filter(u=>u.id!==active.id).map(u=>xy(u.x,u.y))]);for(let i=0;i<queue.length;i++){const [x,y]=queue[i],d=dist.get(xy(x,y));for(const [nx,ny] of neighbors(s,x,y)){const k=xy(nx,ny);if(blocked.has(k)||dist.has(k))continue;dist.set(k,d+1);prev.set(k,xy(x,y));queue.push([nx,ny]);}}return {dist,prev};}
function routeTo(routes,from,to){const dest=xy(to.x,to.y),start=xy(from.x,from.y);if(!routes.dist.has(dest))return null;const path=[];let p=dest;while(p!==start){const [x,y]=p.split(',').map(Number);path.unshift({x,y});p=routes.prev.get(p);if(!p)return null;}return path;}
function dangerWarning(s,path){return path.filter(p=>s.danger.includes(xy(p.x,p.y))).length;}
function aooWarning(s,u,path){let prev={x:u.x,y:u.y},count=0;for(const p of path){if(s.units.some(v=>v.team!==u.team&&v.team!=='neutral'&&Math.abs(v.x-prev.x)+Math.abs(v.y-prev.y)===1))count++;prev=p;}return count;}
function clickCell(x,y){if(gesture.suppress)return;const s=scene(),key=xy(x,y),at=s.units.find(u=>u.x===x&&u.y===y),u=selected();lastCell={x,y};
 if(s.mode==='play'&&tactical&&chooseTacticalTarget(x,y,at))return;
 if(s.mode==='pan')return;
 if(s.mode==='measure'){
  if(rulerSceneId!==s.id||rulerA===null||rulerB!==null){rulerA={x,y};rulerB=null;rulerSceneId=s.id;}
  else rulerB={x,y};
  renderBoard(s);renderRuler();
  return;
 }
 if(s.mode==='mark'){openMarkerDialog(x,y);return;}
 if(s.mode==='play'){
   if(at){s.selected=at.id;clearTactical();invalidateFov();render();saveLocal();return note('Selecionado: '+at.name);}
   if(!u||u.team!=='ally')return note('Selecione um aliado TEST para mover.');
   const routes=allRoutes(s,u),path=routeTo(routes,u,{x,y});if(!path||!path.length)return note('Casa bloqueada ou inalcançável.');if(path.length>4-s.stepsUsed)return note('Movimento TEST: passos restantes '+(4-s.stepsUsed)+'.');
   const warn=aooWarning(s,u,path),danger=dangerWarning(s,path);snap();if(!s.frames.length)captureFrame(s,"Início da movimentação TEST");u.x=x;u.y=y;s.stepsUsed+=path.length;commit(s,`${u.name} moveu ${path.length} casa(s).${warn?' Alerta de oportunidade não resolvido.':''}${danger?' Terreno perigoso não resolvido.':''}`,true);note('Movimento visual TEST executado; sem dano ou resultado oficial.');return;
 }
 if(s.mode==='place'){
   if(!u)return note('Selecione o token a posicionar.');if(at&&at.id!==u.id)return note('Casa ocupada.');if(s.walls.includes(key))return note('Parede bloqueia token.');if(u.x===x&&u.y===y)return;
   snap();if(!s.frames.length)captureFrame(s,"Início do posicionamento TEST");u.x=x;u.y=y;s.stepsUsed=0;commit(s,`Token ${u.name} reposicionado na cena TEST.`,true);return;
 }
 if(at)return note('Não edite terreno sob unidades.');
 const old=JSON.stringify({walls:s.walls,danger:s.danger,terrain:s.terrain});
 const previousTopology=topology(s);
 const redoBeforeNoop=future;
 snap();
 if(s.mode==='wall'){
   const had=s.walls.includes(key);
   s.walls=s.walls.filter(z=>z!==key);
   if(!had){s.walls.push(key);s.danger=s.danger.filter(z=>z!==key);delete s.terrain[key];}
 }else if(s.mode==='danger'){
   const had=s.danger.includes(key);
   s.danger=s.danger.filter(z=>z!==key);
   if(!had){s.danger.push(key);s.walls=s.walls.filter(z=>z!==key);delete s.terrain[key];}
 }else if(s.mode==='terrain'){
   const steps=[undefined,'grass','sand','water'],cur=s.terrain[key],next=steps[(steps.indexOf(cur)+1)%steps.length];
   if(next)s.terrain[key]=next;else delete s.terrain[key];s.danger=s.danger.filter(z=>z!==key);s.walls=s.walls.filter(z=>z!==key);
 }else if(s.mode==='erase'){
   s.walls=s.walls.filter(z=>z!==key);s.danger=s.danger.filter(z=>z!==key);delete s.terrain[key];
 }
 if(old===JSON.stringify({walls:s.walls,danger:s.danger,terrain:s.terrain})){history.pop();future=redoBeforeNoop;return;}
 // Topologia é propriedade do mapa, não do botão escolhido: qualquer modo
 // pode remover paredes. Alteração cosmética/perigo preserva replay válido.
 if(topology(s)!==previousTopology){s.frames=[];s.frameTopology=null;if(replayOrigin==='local')clearReplay();}
 commit(s,'Terreno TEST editado em '+(x+1)+','+(y+1)+'.');
}
// Edição por toque, com snapshots isolados e sem efeitos em motores oficiais.
function changeMode(mode){storageGuard();const s=scene();if(!['play','pan','wall','danger','terrain','erase','place','measure','mark'].includes(mode))return;
 if(mode!==s.mode){rulerA=null;rulerB=null;rulerSceneId=null;if(mode!=='play')clearTactical();}
 s.mode=mode;gesture.suppress=false;render();}
function resize(n){clearTactical();storageGuard();const s=scene();if(!allowedSize.includes(n)||n===s.n)return; if(s.units.some(u=>u.x>=n||u.y>=n)){return note('Não é possível reduzir: existem unidades fora da nova grade.');}const lostMarkers=s.markers.filter(m=>m.x>=n||m.y>=n).length;if(lostMarkers&&!window.confirm(`Reduzir a grade removerá ${lostMarkers} marcação(ões) fora do mapa. Exporte um backup antes, se necessário. Continuar?`))return;snap();s.n=n;s.walls=s.walls.filter(key=>key.split(',').every(v=>Number(v)<n));s.danger=s.danger.filter(key=>key.split(',').every(v=>Number(v)<n));for(const key of Object.keys(s.terrain))if(key.split(',').some(v=>Number(v)>=n))delete s.terrain[key];s.frames=[];s.frameTopology=null;s.explored=s.explored.filter(key=>key.split(',').every(v=>Number(v)<n));s.markers=s.markers.filter(m=>m.x<n&&m.y<n);invalidateFov();commit(s,'Grade alterada para '+n+'×'+n+'.');if(s.fovEnabled&&selected())centerAt(selected().x,selected().y);else center();}
const board=$('board'),vp=$('viewport'),rulerSvg=$('rulerOverlay'),markerSvg=$('markerOverlay');let cachedN=0,tiles=[];
function ensureBoard(n){if(cachedN===n)return;cachedN=n;tiles=[];const frag=document.createDocumentFragment();for(let y=0;y<n;y++)for(let x=0;x<n;x++){const b=document.createElement('button');b.type='button';b.className='tile';b.dataset.xy=xy(x,y);b.setAttribute('role','gridcell');b.innerHTML='<span class="coord"></span><span class="token" hidden></span><span class="markerCue" hidden aria-hidden="true"></span>';frag.append(b);tiles.push(b);}board.replaceChildren(frag);board.append(rulerSvg,markerSvg);board.style.setProperty('--n',n);}
// TEST18 VISUAL FOV: author-written symmetric shadowcasting implementation for synthetic maps.
// This is neither a canonical light/perception rule nor a client-side security filter.
let fovCacheKey='',fovCache=null;
function invalidateFov(){fovCacheKey='';fovCache=null;}
function symmetricShadowcast(s,origin,radius){
 const walls=new Set(s.walls),visible=new Set([xy(origin.x,origin.y)]),rad2=radius*radius;
 const blocked=(x,y)=>!inside(x,y,s.n)||walls.has(xy(x,y));
 // Four quadrants, depths progressing outwards, slope bounds -1 .. 1.
 const orient=[(d,c)=>[origin.x+c,origin.y-d],(d,c)=>[origin.x+c,origin.y+d],(d,c)=>[origin.x+d,origin.y+c],(d,c)=>[origin.x-d,origin.y+c]];
 const roundUp=v=>Math.floor(v+0.5),roundDown=v=>Math.ceil(v-0.5);
 for(const project of orient){
  const scan=(depth,start,end)=>{
   if(depth>radius||start>end)return;
   let prevWall=null,low=start;
   for(let col=roundUp(depth*start);col<=roundDown(depth*end);col++){
    const [x,y]=project(depth,col),wall=blocked(x,y);
    if(inside(x,y,s.n)&&((col>=depth*start&&col<=depth*end)||wall)&&((x-origin.x)**2+(y-origin.y)**2<=rad2))visible.add(xy(x,y));
    const boundary=(2*col-1)/(2*depth);
    if(prevWall===true&&!wall)low=boundary;
    if(prevWall===false&&wall)scan(depth+1,low,boundary);
    prevWall=wall;
   }
   if(prevWall===false)scan(depth+1,low,end);
  };
  scan(1,-1,1);
 }
 return visible;
}
function currentFov(s){
 if(!s.fovEnabled)return null;
 const u=selected();if(!u)return null;
 const key=JSON.stringify([s.id,s.n,u.id,u.x,u.y,s.fovRadius,[...s.walls].sort()]); // topology fingerprint invalidates on edits
 if(key!==fovCacheKey){fovCacheKey=key;fovCache=symmetricShadowcast(s,u,s.fovRadius);}
 const old=new Set(s.explored);for(const k of fovCache)old.add(k);
 if(old.size!==s.explored.length)s.explored=[...old].sort();
 return fovCache;
}
function reachable(s){const u=selected();if(!u||u.team!=='ally'||s.mode!=='play')return new Set();const r=allRoutes(s,u),remaining=4-s.stepsUsed;return new Set([...r.dist].filter(([k,d])=>d>0&&d<=remaining).map(([k])=>k));}
function renderBoard(s){
 ensureBoard(s.n);
 const occupied=new Map(s.units.map(u=>[xy(u.x,u.y),u]));const marked=new Map(s.markers.map(m=>[xy(m.x,m.y),m]));
 const walls=new Set(s.walls),danger=new Set(s.danger);
 const reach=$('layerReach').checked?reachable(s):new Set();const tacticAreaCache=tacticArea(s);
 const showCoords=$('layerCoords').checked,showDanger=$('layerDanger').checked,fov=currentFov(s),explored=fov?new Set(s.explored):null;if($('fovStatus'))$('fovStatus').textContent=fov?`${fov.size} visíveis · ${s.explored.length} exploradas`:'FOV desligado';
 for(let i=0;i<tiles.length;i++){
  const b=tiles[i],x=i%s.n,y=Math.floor(i/s.n),key=xy(x,y),u=occupied.get(key),marker=marked.get(key);
  let cls='tile'+((x+y)%2?' alt':'');
  if(s.terrain[key])cls+=' ground-'+s.terrain[key];
  if(walls.has(key))cls+=' wall';
  if(danger.has(key)&&showDanger)cls+=' danger';
  if(reach.has(key))cls+=' reachable';
  if(rulerSceneId===s.id&&rulerA&&xy(rulerA.x,rulerA.y)===key)cls+=' ruler-point ruler-start';
  if(rulerSceneId===s.id&&rulerB&&xy(rulerB.x,rulerB.y)===key)cls+=' ruler-point ruler-end';
  if(marker)cls+=' has-marker';if(u?.id===s.selected)cls+=' chosen';
  if(tactical?.sceneId===s.id){if(u?.id===tactical.actorId)cls+=' tactic-actor';if(tactical.target&&key===xy(tactical.target.x,tactical.target.y))cls+=' tactic-target';if(tacticAreaCache?.has(key))cls+=' tactic-area';}
  if(fov&&!fov.has(key))cls+=explored.has(key)?' fov-explored':' fov-hidden';
  // TEST07: atualiza somente casas cujo conteúdo visual realmente mudou.
  const sig=cls+'|'+showCoords+'|'+(u?u.id+':'+u.mark+':'+u.team+':'+u.name:'')+'|'+(marker?marker.id+':'+marker.kind+':'+marker.text:'');
  if(b.dataset.sig===sig)continue;
  b.dataset.sig=sig;b.className=cls;
  b.setAttribute('aria-label',`Coluna ${x+1}, linha ${y+1}${u?', '+u.name:''}${walls.has(key)?', parede':''}${marker?', marcação '+marker.kind+': '+marker.text:''}`);
  const coord=b.firstElementChild;coord.hidden=!showCoords;
  if(showCoords)coord.textContent=`${x+1}.${y+1}`;
  const p=b.querySelector('.token');p.hidden=!u;const cue=b.querySelector('.markerCue');cue.hidden=!marker;if(marker){cue.textContent=marker.kind==='note'?'✎':marker.kind==='highlight'?'◎':'◆';cue.title=marker.text;}
  if(u){p.className='token '+u.team;p.textContent=u.mark;p.title=u.name;}
 }
}

// TEST28: marker data shares the EXISTING scene/history/backup; no parallel event store.
function openMarkerDialog(x,y){
 storageGuard();const s=scene(),prior=s.markers.find(m=>m.x===x&&m.y===y);
 markerTarget={x,y,sceneId:s.id};markerEditId=prior?.id||null;markerDialogOpen=true;
 $('markerHeading').textContent=prior?'Editar marcação TEST':'Nova marcação TEST';
 $('markerKind').value=prior?.kind||'pin';$('markerText').value=prior?.text||'';
 $('markerDelete').hidden=!prior;$('markerFormError').textContent='';$('markerDialog').hidden=false;
 updateModalIsolation();$('markerText').focus();
}
function closeMarkerDialog(){markerDialogOpen=false;markerEditId=null;markerTarget=null;$('markerDialog').hidden=true;updateModalIsolation();}
function markerCommand(action,target,payload){
 const s=scene();if(!target||target.sceneId!==s.id||!inside(target.x,target.y,s.n))throw Error('Cena ou coordenada inválida');
 if(!['ADD','UPDATE','REMOVE'].includes(action))throw Error('Comando visual desconhecido');
 if(action==='ADD'){
  if(s.markers.length>=MAX_MARKERS)throw Error('Limite de 40 marcações por cena');
  if(s.markers.some(m=>m.x===target.x&&m.y===target.y))throw Error('Casa já marcada');
  if(!payload||!textOK(payload.text,100)||!['pin','note','highlight'].includes(payload.kind))throw Error('Texto ou tipo de marcação inválido');
  const id=nextId('m',new Set(s.markers.map(m=>m.id)));snap();s.markers.push({id,x:target.x,y:target.y,kind:payload.kind,text:payload.text});
 }else{
  const idx=s.markers.findIndex(m=>m.id===markerEditId&&m.x===target.x&&m.y===target.y);
  if(idx<0)throw Error('Marcação original não existe mais');
  if(action==='UPDATE'){
   if(!payload||!textOK(payload.text,100)||!['pin','note','highlight'].includes(payload.kind))throw Error('Texto ou tipo de marcação inválido');
   const prior=s.markers[idx];
   if(prior.kind===payload.kind&&prior.text===payload.text){
    closeMarkerDialog();note('Marcação TEST sem alteração; histórico de Refazer preservado.');return false;
   }
   snap();s.markers[idx]={...prior,kind:payload.kind,text:payload.text};
  }else{snap();s.markers.splice(idx,1);}
 }
 closeMarkerDialog();commit(s,action==='REMOVE'?'Marcação TEST removida.':'Marcação TEST atualizada.');
 note('Marcação visual TEST '+(action==='REMOVE'?'removida':'salva')+'; nenhum efeito mecânico.');
}
function saveMarkerDialog(){
 const target=markerTarget;
 try{storageGuard();const payload={kind:$('markerKind').value,text:$('markerText').value.trim()};
  if(!textOK(payload.text,100)||!['pin','note','highlight'].includes(payload.kind))throw Error('Texto: 1 a 100 caracteres, sem HTML ou controles.');
  markerCommand(markerEditId?'UPDATE':'ADD',target,payload);
 }catch(e){$('markerFormError').textContent=e.message;}
}
function deleteMarkerDialog(){try{storageGuard();markerCommand('REMOVE',markerTarget,null);}catch(e){$('markerFormError').textContent=e.message;}}
function renderMarkerOverlay(s){
 const svg=$('markerOverlay'),unit=zoom+2,ns='http://www.w3.org/2000/svg';
 svg.setAttribute('viewBox',`0 0 ${s.n*unit} ${s.n*unit}`);svg.setAttribute('width',s.n*unit);svg.setAttribute('height',s.n*unit);
 const frag=document.createDocumentFragment();
 for(const m of s.markers){const x=(m.x+.5)*unit,y=(m.y+.5)*unit;
  const el=document.createElementNS(ns,m.kind==='highlight'?'rect':'circle');
  if(m.kind==='highlight'){el.setAttribute('x',x-unit*.41);el.setAttribute('y',y-unit*.41);el.setAttribute('width',unit*.82);el.setAttribute('height',unit*.82);el.setAttribute('rx',5);}
  else{el.setAttribute('cx',x);el.setAttribute('cy',y);el.setAttribute('r',m.kind==='note'?unit*.22:unit*.16);}
  el.setAttribute('class','visual-mark '+m.kind);frag.appendChild(el);
 }
 svg.replaceChildren(frag);
}
function renderMarkerList(s){const root=$('markerList');root.replaceChildren();$('markerCount').textContent=s.markers.length+' / '+MAX_MARKERS;
 for(const m of s.markers){const btn=document.createElement('button');btn.type='button';btn.className='markerItem';btn.textContent=`${m.kind==='note'?'✎':m.kind==='highlight'?'◎':'◆'} ${m.text} (${m.x+1},${m.y+1})`;
  btn.addEventListener('click',()=>{changeMode('mark');centerAt(m.x,m.y);openMarkerDialog(m.x,m.y);});root.append(btn);}
}
function renderUnits(s){const root=$('unitList');root.replaceChildren();for(const u of s.units){const b=document.createElement('button');b.type='button';b.className='unitBtn'+(u.id===s.selected?' sel':'');const bubble=document.createElement('span');bubble.className='bubble '+u.team;bubble.textContent=u.mark;const label=document.createElement('span'),strong=document.createElement('strong'),small=document.createElement('small');strong.textContent=u.name;small.textContent=`${u.team==='ally'?'Aliado':u.team==='enemy'?'Adversário':'Neutro'} • ${u.x+1},${u.y+1} • Vida ${u.hp} • Alma ${u.soul} • PA ${u.pa}`;label.append(strong,small);b.append(bubble,label);b.addEventListener('click',()=>{s.selected=u.id;clearTactical();invalidateFov();render();saveLocal();note('Selecionado '+u.name);});root.append(b);}}
function renderSceneSelector(){const root=$('scenes'),s=scene();root.replaceChildren();for(const sc of workspace.scenes){const opt=document.createElement('option');opt.value=sc.id;opt.textContent=sc.name;root.append(opt);}root.value=s.id;}
function renderLog(s){const root=$('log');root.replaceChildren();for(const msg of s.logs.slice(0,12)){const p=document.createElement('p');p.textContent=msg;root.append(p);}}
function renderRuler(){
 const s=scene(),root=$('rulerOverlay'),line=$('rulerSegment'),status=$('rulerStatus');
 if(rulerSceneId!==s.id||rulerA&&!inside(rulerA.x,rulerA.y,s.n)||rulerB&&!inside(rulerB.x,rulerB.y,s.n)){rulerA=null;rulerB=null;rulerSceneId=null;}
 const show=Boolean(s.mode==='measure'&&rulerSceneId===s.id&&rulerA);
 root.toggleAttribute('hidden',!show);const cell=zoom+2;root.setAttribute('width',String(s.n*cell));root.setAttribute('height',String(s.n*cell));
 if(!show){status.textContent='Régua: dois toques no mapa · nenhuma regra de alcance.';return;}
 if(!rulerB){line.setAttribute('x1',String((rulerA.x+.5)*cell));line.setAttribute('y1',String((rulerA.y+.5)*cell));line.setAttribute('x2',String((rulerA.x+.5)*cell));line.setAttribute('y2',String((rulerA.y+.5)*cell));status.textContent=`Régua: início ${rulerA.x+1},${rulerA.y+1} · toque a segunda casa.`;return;}
 line.setAttribute('x1',String((rulerA.x+.5)*cell));line.setAttribute('y1',String((rulerA.y+.5)*cell));line.setAttribute('x2',String((rulerB.x+.5)*cell));line.setAttribute('y2',String((rulerB.y+.5)*cell));
 const dx=Math.abs(rulerA.x-rulerB.x),dy=Math.abs(rulerA.y-rulerB.y);
 status.textContent=`Régua TEST: ${rulerA.x+1},${rulerA.y+1} → ${rulerB.x+1},${rulerB.y+1} · Manhattan ${dx+dy} casas · reta ${Math.hypot(dx,dy).toFixed(2)} casas (geométrico, não canônico).`;
}
function render(){const t0=performance.now(),s=scene();renderSceneSelector();$('gridSize').value=String(s.n);$('sceneHeading').textContent=s.name;$('sceneMeta').textContent=' · '+s.n+'×'+s.n;$('unitCount').textContent=s.units.length+' unidades';$('roundCount').textContent='Rodada TEST '+s.round;$('activeSceneCount').textContent=workspace.scenes.length+' cena(s)';$('sceneNotes').value=s.notes;$('layerFov').checked=s.fovEnabled;$('fovRadius').value=String(s.fovRadius);renderBoard(s);renderMarkerOverlay(s);renderMarkerList(s);renderUnits(s);renderLog(s);renderTactical();for(const b of document.querySelectorAll('[data-mode]')){const active=b.dataset.mode===s.mode;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));}drawMinimap();renderRuler();renderReplay();renderLast=performance.now()-t0;$('perf').textContent=`Render ${renderLast.toFixed(1)} ms (medição local)`;}
function cameraScale(next,anchor){const prior=zoom,after=Math.min(84,Math.max(28,Math.round(Number(next)/4)*4));if(!Number.isFinite(after))return;const x=anchor?.x??vp.clientWidth/2,y=anchor?.y??vp.clientHeight/2;const worldX=(vp.scrollLeft+x)/prior,worldY=(vp.scrollTop+y)/prior;zoom=after;document.documentElement.style.setProperty('--cell',after+'px');$('zoom').value=String(after);$('zoomLabel').textContent=after+' px';vp.scrollLeft=worldX*after-x;vp.scrollTop=worldY*after-y;drawMinimap();renderRuler();renderMarkerOverlay(scene());}
function center(){vp.scrollLeft=Math.max(0,(board.scrollWidth-vp.clientWidth)/2);vp.scrollTop=Math.max(0,(board.scrollHeight-vp.clientHeight)/2);drawMinimap();}
function centerAt(x,y){const s=scene();vp.scrollLeft=Math.max(0,(x+.5)*(zoom+2)-vp.clientWidth/2);vp.scrollTop=Math.max(0,(y+.5)*(zoom+2)-vp.clientHeight/2);drawMinimap();}
function drawMinimap(){const s=scene(),canvas=$('minimap'),ctx=canvas.getContext('2d'),W=canvas.width,step=W/s.n,walls=new Set(s.walls),danger=new Set(s.danger);ctx.clearRect(0,0,W,W);for(let y=0;y<s.n;y++)for(let x=0;x<s.n;x++){const key=xy(x,y);ctx.fillStyle=walls.has(key)?'#8b94a1':danger.has(key)?'#aa634d':s.terrain[key]==='grass'?'#327963':s.terrain[key]==='water'?'#316a9b':s.terrain[key]==='sand'?'#9c8254':'#324e69';ctx.fillRect(x*step,y*step,step-.5,step-.5);}for(const u of s.units){ctx.beginPath();ctx.arc((u.x+.5)*step,(u.y+.5)*step,Math.max(2.5,step*.3),0,Math.PI*2);ctx.fillStyle=u.id===s.selected?'#fbe08a':u.team==='enemy'?'#d7757a':'#67bdf1';ctx.fill();}const rect=vp.getBoundingClientRect(),br=board.getBoundingClientRect();if(br.width&&br.height){const x=Math.max(0,(rect.left-br.left)/br.width*W),y=Math.max(0,(rect.top-br.top)/br.height*W);ctx.strokeStyle='#ffffb5';ctx.lineWidth=2;ctx.strokeRect(x,y,Math.min(W-x,rect.width/br.width*W),Math.min(W-y,rect.height/br.height*W));}}
function cameraGesture(){const points=gesture.pointers,xyList=[...points.values()];if(xyList.length!==2)return null;const a=xyList[0],b=xyList[1];return {mid:{x:(a.x+b.x)/2,y:(a.y+b.y)/2},distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y))};}
vp.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;if(gesture.pointers.size===0)gesture.suppress=false;gesture.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY});gesture.dragged=false;const g=cameraGesture();if(g){const r=vp.getBoundingClientRect();gesture.start={zoom,distance:g.distance,worldX:(vp.scrollLeft+g.mid.x-r.left)/zoom,worldY:(vp.scrollTop+g.mid.y-r.top)/zoom};gesture.suppress=true;}if(scene().mode==='pan'||gesture.pointers.size>1)try{vp.setPointerCapture(e.pointerId);}catch{}});
vp.addEventListener('pointermove',e=>{const previous=gesture.pointers.get(e.pointerId);if(!previous)return;gesture.pointers.set(e.pointerId,{...previous,x:e.clientX,y:e.clientY});if(scene().mode!=='pan'&&Math.hypot(e.clientX-previous.startX,e.clientY-previous.startY)>12){gesture.dragged=true;gesture.suppress=true;}const g=cameraGesture();if(g&&gesture.start){const rect=vp.getBoundingClientRect();cameraScale(gesture.start.zoom*g.distance/gesture.start.distance,{x:g.mid.x-rect.left,y:g.mid.y-rect.top});vp.scrollLeft=gesture.start.worldX*zoom-(g.mid.x-rect.left);vp.scrollTop=gesture.start.worldY*zoom-(g.mid.y-rect.top);gesture.suppress=true;gesture.dragged=true;drawMinimap();e.preventDefault();}else if(scene().mode==='pan'&&gesture.pointers.size===1){const dx=e.clientX-previous.x,dy=e.clientY-previous.y;if(dx||dy){vp.scrollLeft-=dx;vp.scrollTop-=dy;gesture.suppress=true;gesture.dragged=true;drawMinimap();e.preventDefault();}}});
function endPointer(e){if(!gesture.pointers.has(e.pointerId))return;gesture.pointers.delete(e.pointerId);if(gesture.pointers.size<2)gesture.start=null;if(gesture.pointers.size===0&&gesture.dragged){gesture.suppress=true;}else if(gesture.pointers.size===0&&scene().mode!=='pan'){gesture.suppress=false;}}
for(const type of ['pointerup','pointercancel','lostpointercapture'])vp.addEventListener(type,endPointer);
vp.addEventListener('click',e=>{if(gesture.suppress||scene().mode==='pan'){e.preventDefault();e.stopPropagation();gesture.suppress=false;}},true);
board.addEventListener('click',e=>{const b=e.target.closest('[data-xy]');if(!b)return;const [x,y]=b.dataset.xy.split(',').map(Number);clickCell(x,y);});
$('minimap').addEventListener('click',e=>{const r=e.currentTarget.getBoundingClientRect(),s=scene(),x=Math.min(s.n-1,Math.max(0,Math.floor((e.clientX-r.left)/r.width*s.n))),y=Math.min(s.n-1,Math.max(0,Math.floor((e.clientY-r.top)/r.height*s.n)));centerAt(x,y);});vp.addEventListener('scroll',drawMinimap,{passive:true});
function editToken(create=false){const s=scene(),u=selected();if(!create&&!u)return note('Selecione uma unidade para editar.');if(create&&s.units.length>=MAX_UNITS)return note('Limite de 30 unidades por cena.');editingNew=create;editingId=create?null:u.id;const t=create?unit('','Token TEST','T','neutral',0,0):u;$('tokName').value=t.name;$('tokMark').value=t.mark;$('tokTeam').value=t.team;$('tokHp').value=t.hp;$('tokSoul').value=t.soul;$('tokPa').value=t.pa;$('tokRange').value=t.range;$('tokenForm').classList.remove('hidden');}
function commitToken(){const s=scene(),name=$('tokName').value.trim(),mark=$('tokMark').value.trim(),team=$('tokTeam').value,range=Number($('tokRange').value),values=[$('tokHp'),$('tokSoul'),$('tokPa')].map(el=>Number(el.value));if(!textOK(name,48)||!textOK(mark,2)||!['ally','enemy','neutral'].includes(team)||!Number.isInteger(range)||range<1||range>20||values.some(v=>!Number.isInteger(v)||v<0||v>99999))return note('Dados TEST inválidos. Confira nome, marca e valores.');if(editingNew){const occupied=new Set(s.units.map(u=>xy(u.x,u.y))),walls=new Set(s.walls);let pos=null;for(let y=0;y<s.n&&!pos;y++)for(let x=0;x<s.n;x++)if(!occupied.has(xy(x,y))&&!walls.has(xy(x,y))){pos={x,y};break;}if(!pos)return note('Mapa sem casa livre para token.');snap();const id=nextId('u',new Set(s.units.map(u=>u.id)));s.units.push({...unit(id,name,mark,team,pos.x,pos.y),range,hp:values[0],soul:values[1],pa:values[2]});s.selected=id;s.frames=[];s.frameTopology=null;commit(s,'Novo token TEST criado: '+name);}else{const u=selected();if(!u||u.id!==editingId)return note('Seleção alterada; reabra o editor.');snap();Object.assign(u,{name,mark,team,range,hp:values[0],soul:values[1],pa:values[2]});commit(s,'Token TEST editado: '+name);}closeTokenForm();}
function closeTokenForm(){$('tokenForm').classList.add('hidden');editingNew=false;editingId=null;}
function removeToken(){const s=scene(),u=selected();if(!u)return; if(!confirm(`Remover ${u.name} desta cena TEST?`))return;snap();s.units=s.units.filter(x=>x.id!==u.id);s.selected=s.units[0]?.id||null;s.frames=[];s.frameTopology=null;commit(s,'Token TEST removido: '+u.name);}
function createScene(){if(workspace.scenes.length>=MAX_SCENES)return note('Limite de oito cenas.');snap();const id=nextId('c',new Set(workspace.scenes.map(s=>s.id)));const sc=newScene(id,'Nova cena TEST '+id);workspace.scenes.push(sc);workspace.active=id;history=[];future=[];clearReplay();render();saveLocal();note('Cena independente criada.');}
function copyScene(){if(workspace.scenes.length>=MAX_SCENES)return note('Limite de oito cenas.');const id=nextId('c',new Set(workspace.scenes.map(s=>s.id))),sc=clone(scene());sc.id=id;sc.name=(sc.name.slice(0,52)+' (cópia)');snap();workspace.scenes.push(sc);workspace.active=id;clearReplay();render();saveLocal();note('Cena duplicada sem modificar a original.');}
function deleteScene(){if(workspace.scenes.length<=1)return note('Mantenha ao menos uma cena TEST.');const s=scene();if(!confirm(`Excluir a cena TEST “${s.name}”?`))return;snap();workspace.scenes=workspace.scenes.filter(x=>x.id!==s.id);workspace.active=workspace.scenes[0].id;clearReplay();render();saveLocal();note('Cena experimental excluída.');}
function switchScene(id){storageGuard();if(!workspace.scenes.some(s=>s.id===id))return;workspace.active=id;invalidateFov();clearReplay();history=[];future=[];closeTokenForm();render();saveLocal();center();}
function renameScene(){const s=scene(),name=prompt('Nome da cena TEST (máximo 70 caracteres):',s.name);if(name===null)return;const value=name.trim();if(!textOK(value,70))return note('Nome TEST inválido.');if(value===s.name)return note('Nome da cena inalterado; Refazer preservado.');snap();s.name=value;commit(s,'Cena renomeada.');}
function resetScene(){const s=scene();if(!confirm(`Limpar o mapa, tokens e histórico de “${s.name}” nesta cena TEST?`))return;snap();const restored=newScene(s.id,s.name,s.n);restored.notes=s.notes;workspace.scenes=workspace.scenes.map(x=>x.id===s.id?restored:x);history=[];future=[];clearReplay();render();saveLocal();note('Cena reiniciada.');}
function nextRound(){const s=scene();snap();s.round++;s.stepsUsed=0;s.acted=false;commit(s,'Nova rodada TEST; não executa iniciativa oficial.');}
function addEventFrame(){const s=scene();snap();captureFrame(s,'Quadro TEST '+(s.frames.length+1));commit(s,'Quadro de replay TEST capturado.');loadCurrentReplay();}
function makeReplay(s){const frames=s.frames.length?s.frames:[{title:'Posições atuais TEST',positions:positions(s)}];return {schema:REPLAYSCHEMA,source:{kind:'SYNTHETIC_FIXTURE',scope:'MESTRE_ONLY',isolatedCopy:true,reference:'TABLETOP-PUBLIC-TEST29',exportedAt:stamp()},grid:{width:s.n,height:s.n,walls:s.walls.map(v=>v.split(',').map(Number))},units:s.units.map(u=>({id:u.id,label:u.name,mark:u.mark,team:u.team})),events:frames.map((f,i)=>({id:'frame-'+String(i+1).padStart(3,'0'),type:i?'POSITION':'ROUND_NOTE',title:f.title,description:'Snapshot visual sintético; sem cálculo do RPG.',frame:{positions:f.positions}}))};}
function validateReplay(d){if(!safeKeys(d)||d.schema!==REPLAYSCHEMA||!safeKeys(d.source)||d.source.kind!=='SYNTHETIC_FIXTURE'||d.source.scope!=='MESTRE_ONLY'||d.source.isolatedCopy!==true||!textOK(d.source.reference,100)||!textOK(d.source.exportedAt,40)||!safeKeys(d.grid)||!allowedSize.includes(d.grid.width)||d.grid.width!==d.grid.height||!Array.isArray(d.grid.walls)||d.grid.walls.length>200||!Array.isArray(d.units)||d.units.length<1||d.units.length>MAX_UNITS||!Array.isArray(d.events)||d.events.length<1||d.events.length>MAX_EVENTS)return false;
 const walls=new Set();for(const w of d.grid.walls){if(!Array.isArray(w)||w.length!==2||!inside(w[0],w[1],d.grid.width)||walls.has(xy(...w)))return false;walls.add(xy(...w));}
 const ids=new Set();for(const u of d.units){if(!safeKeys(u)||!validId(u.id)||ids.has(u.id)||!textOK(u.label,70)||!textOK(u.mark,2)||!['ally','enemy','neutral'].includes(u.team))return false;ids.add(u.id);}const eventIds=new Set();let previousNumeric=null,previousPrefix=null,hadSequence=null,prevSequence=null;
 const idsClassification=d.events.map(e=>typeof e.id==='string'&&/^(frame|ev)-\d+$/.test(e.id));
 const numericIds=idsClassification.every(Boolean),mixedIds=idsClassification.some(Boolean)&&!numericIds;
 if(mixedIds&&!d.events.every(e=>safeKeys(e)&&Number.isSafeInteger(e.sequence)&&e.sequence>=0))return false;
 for(const e of d.events){
  if(Object.hasOwn(e,'sequence')){if(!Number.isSafeInteger(e.sequence)||e.sequence<0||hadSequence===false||(prevSequence!==null&&e.sequence<=prevSequence))return false;prevSequence=e.sequence;hadSequence=true;}
  else if(hadSequence===true)return false;else hadSequence=false;
  if(numericIds){const m=/^(frame|ev)-(\d+)$/.exec(e.id);const num=Number(m[2]);if(!Number.isSafeInteger(num)||num<0||(previousPrefix!==null&&m[1]!==previousPrefix)||(previousNumeric!==null&&num<=previousNumeric))return false;previousNumeric=num;previousPrefix=m[1];}
if(!safeKeys(e)||!textOK(e.id,55)||eventIds.has(e.id)||!['POSITION','ATTACK_DECLARED','AO0_ALERT','DAMAGE_RECORDED','ROUND_NOTE','EFFECT_DECLARED'].includes(e.type)||!textOK(e.title,120)||!textOK(e.description,500)||!safeKeys(e.frame)||!safeKeys(e.frame.positions))return false;eventIds.add(e.id);if(Object.keys(e.frame.positions).length!==ids.size)return false;const occupied=new Set();for(const id of ids){const p=e.frame.positions[id];if(!Array.isArray(p)||p.length!==2||!inside(p[0],p[1],d.grid.width)||walls.has(xy(...p))||occupied.has(xy(...p)))return false;occupied.add(xy(...p));}if(Object.keys(e.frame.positions).some(k=>!ids.has(k)||!validId(k)))return false;}return true;}
function stopReplay(){if(playTimer!==null){clearInterval(playTimer);playTimer=null;}$('replayPlay').textContent='▶ Reproduzir';}
function clearReplay(){stopReplay();viewReplay=null;replayOrigin=null;frameIndex=0;drawnTopology='';}
let drawnTopology='';
function loadCurrentReplay(){const d=makeReplay(scene());if(!validateReplay(d))return note('Não foi possível gerar replay TEST: snapshots incompatíveis.');loadReplay(d,'local');}
function loadReplay(d,origin='external'){if(!validateReplay(d))throw Error('Replay inválido ou não sintético; dados VLAB reais permanecem HOLD.');stopReplay();viewReplay=clone(d);replayOrigin=origin;frameIndex=0;drawnTopology='';renderReplay();}
function renderReplay(){const d=viewReplay,root=$('replayGrid'),overlay=$('replayPieces'),list=$('eventList');if(!d){$('replayCounter').textContent='0/0';$('replayInfo').textContent='Capture um quadro ou importe replay sintético.';root.replaceChildren();overlay.replaceChildren();list.replaceChildren();return;}
 const n=d.grid.width,event=d.events[frameIndex],prev=frameIndex?d.events[frameIndex-1]:null,size=n===20?20:28,gap=2;const signature=n+':'+d.grid.walls.map(w=>w.join(',')).join('|');if(signature!==drawnTopology){drawnTopology=signature;root.replaceChildren();overlay.replaceChildren();root.style.setProperty('--n',n);root.style.setProperty('--t',size+'px');overlay.style.setProperty('--t',size+'px');const walls=new Set(d.grid.walls.map(w=>xy(...w)));for(let y=0;y<n;y++)for(let x=0;x<n;x++){const tile=document.createElement('div');tile.className='replayCell'+(walls.has(xy(x,y))?' wall':'');root.append(tile);}for(const u of d.units){const piece=document.createElement('div');piece.className='replayPiece '+u.team;piece.dataset.id=u.id;piece.style.width=size+'px';piece.style.height=size+'px';const inner=document.createElement('span');inner.textContent=u.mark;piece.append(inner);overlay.append(piece);}}
 for(const piece of overlay.children){const p=event.frame.positions[piece.dataset.id];piece.style.transform=`translate(${p[0]*(size+gap)}px,${p[1]*(size+gap)}px)`;}
 let delta='Quadro inicial.';if(prev){const changes=d.units.filter(u=>!equal(prev.frame.positions[u.id],event.frame.positions[u.id])).map(u=>`${u.label}: ${prev.frame.positions[u.id].join(',')} → ${event.frame.positions[u.id].join(',')}`);delta=changes.join('\n')||'Nenhuma posição mudou.';}
 $('replayCounter').textContent=`${frameIndex+1}/${d.events.length}`;$('replayInfo').textContent=event.title+'\n'+event.description+'\n'+delta;$('replaySeek').max=d.events.length-1;$('replaySeek').value=frameIndex;list.replaceChildren();for(let i=0;i<d.events.length;i++){const b=document.createElement('button');b.type='button';b.className=i===frameIndex?'current':'';b.textContent=`${i+1}. ${d.events[i].title}`;b.onclick=()=>seek(i);list.append(b);}}
function seek(i){if(!viewReplay)return;frameIndex=Math.max(0,Math.min(viewReplay.events.length-1,i));renderReplay();}
function togglePlayback(){if(playTimer!==null){stopReplay();return;}if(!viewReplay)return note('Capture ou importe replay TEST primeiro.');if(frameIndex>=viewReplay.events.length-1)seek(0);$('replayPlay').textContent='⏸ Pausar';playTimer=setInterval(()=>{if(!viewReplay||frameIndex>=viewReplay.events.length-1){stopReplay();return;}seek(frameIndex+1);},Number($('replaySpeed').value));}
function exportReplay(){if(!viewReplay)loadCurrentReplay();if(viewReplay)download(viewReplay,'TABLETOP_TEST15_REPLAY_SINTETICO.json');}
function initialize(){loadLocal();document.documentElement.style.setProperty('--cell',zoom+'px');render();center();}
// CONTROLES DE CENA, EDITOR, TOKEN, PERSISTÊNCIA.
function updateTacticalRoomState(){const room=$('roomStatus'),hint=$('tacticRoomState');if(!room||!hint)return;hint.textContent='Sala DEMO: '+room.textContent.trim()+'. Ações táticas NÃO enviadas ao servidor/VLAB.';}
new MutationObserver(updateTacticalRoomState).observe($('roomStatus'),{attributes:true,childList:true,characterData:true,subtree:true});
updateTacticalRoomState();
$('tacticRoomJump').onclick=()=>{$('roomPanel').scrollIntoView({block:'start',behavior:'instant'});};
$('jumpArena').onclick=()=>{$('arenaMain').scrollIntoView({block:'start',behavior:'instant'});note('Arena em foco; use ⚔ Ações para prévias TEST.');};$('tacticToggle').onclick=()=>{const hud=$('tacticHud'),expanded=!hud.classList.contains('expanded');hud.classList.toggle('expanded',expanded);$('tacticToggle').setAttribute('aria-expanded',String(expanded));$('tacticToggle').textContent=expanded?'⚔ Ocultar ▴':'⚔ Ações ▾';};$('tacticAction').onchange=e=>chooseTacticalAction(e.target.value);$('tacticCancel').onclick=()=>{clearTactical();renderBoard(scene());renderTactical();note('Intenção visual TEST cancelada; nenhum recurso alterado.');};$('tacticConfirm').onclick=confirmTactical;
$('scenes').onchange=e=>{clearTactical();switchScene(e.target.value);};$('newScene').onclick=createScene;$('copyScene').onclick=copyScene;$('deleteScene').onclick=deleteScene;$('renameScene').onclick=renameScene;$('resetScene').onclick=resetScene;$('gridSize').onchange=e=>resize(Number(e.target.value));$('nextRound').onclick=nextRound;
for(const b of document.querySelectorAll('[data-mode]'))b.onclick=()=>changeMode(b.dataset.mode);$('undo').onclick=undo;$('redo').onclick=redo;$('zoomOut').onclick=()=>cameraScale(zoom-4);$('zoomIn').onclick=()=>cameraScale(zoom+4);$('zoom').oninput=e=>cameraScale(Number(e.target.value));$('center').onclick=center;$('focus').onclick=()=>{const u=selected();if(u)centerAt(u.x,u.y);};
for(const id of ['layerCoords','layerReach','layerDanger'])$(id).onchange=()=>{renderBoard(scene());drawMinimap();};$('layerFov').onchange=e=>{scene().fovEnabled=e.target.checked;invalidateFov();render();saveLocal();if(e.target.checked){const u=selected();if(u)centerAt(u.x,u.y);}note(e.target.checked?'Campo de visão EXPERIMENTAL: não aplica regras oficiais.':'FOV visual desligado.');};$('fovRadius').onchange=e=>{scene().fovRadius=Number(e.target.value);invalidateFov();render();saveLocal();};$('newToken').onclick=()=>editToken(true);$('editToken').onclick=()=>editToken(false);$('removeToken').onclick=removeToken;$('commitToken').onclick=commitToken;$('cancelToken').onclick=closeTokenForm;
$('sceneNotes').addEventListener('change',e=>{const s=scene();const value=e.target.value;if(value.length>800)return note('Nota muito longa.');if(value===s.notes)return; snap();s.notes=value;saveLocal();});
// The storage event is delivered by the browser to OTHER same-origin tabs (never used as a lock).
window.addEventListener('storage',e=>{
 if(e.key!==KEY||storageUncertain)return;
 try{const observed=localStorage.getItem(KEY);if(observed!==lastVerifiedRaw)externalAlert(observed,'STORAGE_EVENT');}
 catch(err){externalAlert(e.newValue,'STORAGE_EVENT_UNREADABLE');}
});
$('save').onclick=()=>saveLocal(false);$('backup').onclick=()=>{if(validateWorkspace(workspace))download(workspace,'TABLETOP_ASSIMILACAO_BACKUP_TEST15.json');};
$('restore').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{
 storageGuard();const w=await readJSON(f),planned=planCoordinateMigration(w);
 if(!['NO_CHANGE','SAFE_NORMALIZATION'].includes(planned.status))throw Error('Backup incompatível: '+(planned.reason||planned.status)+'; original não alterado.');
 const candidate=planned.candidate;
 if(!validateWorkspace(candidate))throw Error('Schema, topologia, cena ou conteúdo inválido');
 const stats=restoreReview(candidate);stats.migrationCount=planned.changes||0;
 stats.requiresReview=stats.requiresReview||planned.status==='SAFE_NORMALIZATION';
 if(stats.requiresReview){showRestoreReview(candidate,stats);note('Backup: revise a substituição/migração antes de confirmar.');return;}
 if(!confirm(`Substituir ${stats.currentCount} cena(s) atuais pelas ${stats.incomingCount} do backup TEST? Você pode cancelar e usar ↓ Backup antes de continuar.`))return;
 restoreCandidate(w);note('Backup sintético restaurado e persistência local conferida.');
 }catch(err){note(err.storageStatus==='UNKNOWN_AFTER_WRITE'?'ATENÇÃO: armazenamento INDETERMINADO; exporte e reconcilie antes de continuar.':'Backup rejeitado: '+err.message);}finally{e.target.value='';}};
$('restoreReviewCancel').onclick=cancelRestoreReview;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&restoreDialogOpen){e.preventDefault();cancelRestoreReview();note('Restauração cancelada; suas cenas continuam intactas.');}});
$('restoreReviewExport').onclick=()=>{download(workspace,'TABLETOP_BACKUP_ANTES_DE_RESTAURAR.json');note('Backup do estado atual exportado; confira o arquivo baixado antes de confirmar.');};
$('markerCancel').onclick=closeMarkerDialog;$('markerSave').onclick=saveMarkerDialog;$('markerDelete').onclick=deleteMarkerDialog;
$('restoreReviewConfirm').onclick=()=>{if(!pendingRestore)return;const raw=pendingRestore;cancelRestoreReview();try{restoreCandidate(raw);note('Backup restaurado e persistência conferida.');}catch(e){note(e.storageStatus==='UNKNOWN_AFTER_WRITE'?'ATENÇÃO: persistência INDETERMINADA; exporte e reconcilie.':'Backup rejeitado: '+e.message);}};
$('storageRecheck').onclick=()=>inspectReconcile();$('storageAdopt').onclick=()=>adoptReconciled();
$('storageExport').onclick=()=>{download(workspace,'TABLETOP_RECUPERACAO_MEMORIA_TEST.json');note('Estado em memória exportado; guarde o download antes de recarregar.');};
$('storageRawExport').onclick=()=>{try{const raw=localStorage.getItem(KEY);if(!raw)throw Error('Nenhum salvamento disponível');const blob=new Blob([raw],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='TABLETOP_ARMAZENAMENTO_ORIGINAL_SEM_ALTERAR.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);note('Bytes do armazenamento exportados sem alterações.');}catch(e){note('Não foi possível exportar o armazenamento bruto: '+e.message);}};
$('record').onclick=addEventFrame;$('replayExport').onclick=exportReplay;$('replayPlay').onclick=togglePlayback;$('replaySpeed').onchange=()=>{if(playTimer!==null){stopReplay();togglePlayback();}};$('replayPrev').onclick=()=>{stopReplay();seek(frameIndex-1);};$('replayNext').onclick=()=>{stopReplay();seek(frameIndex+1);};$('replayFirst').onclick=()=>{stopReplay();seek(0);};$('replaySeek').oninput=e=>{stopReplay();seek(Number(e.target.value));};
function checkExternalOnResume(){
 if(storageUncertain||externalConflict)return;
 try{const observed=localStorage.getItem(KEY);if(observed!==lastVerifiedRaw)externalAlert(observed,'RESUME_REVISION_CHECK');}
 catch(e){externalAlert(null,'RESUME_READ_UNAVAILABLE');}
}
document.addEventListener('visibilitychange',()=>{
 if(document.hidden&&playTimer!==null){stopReplay();note('Replay pausado: a aba ficou em segundo plano.');}
 if(!document.hidden)checkExternalOnResume();
});
window.addEventListener('focus',checkExternalOnResume);

$('replayImport').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{const v=await readJSON(f);loadReplay(v);note('Replay TEST importado; nenhuma cena foi modificada.');}catch(err){note('Replay rejeitado: '+err.message);}finally{e.target.value='';}};
// API ESTRITAMENTE TEST para ensaios externos; nenhuma escrita remota.
window.__tabletopTEST={tactical:()=>({draft:tactical?clone(tactical):null,result:tacticalResult}),tacticalAction:chooseTacticalAction,tacticalConfirm:confirmTactical,tacticalCancel:()=>{clearTactical();renderBoard(scene());renderTactical();},storageState:()=>storageState,externalConflict:()=>Boolean(externalConflict),lastVerifiedRaw:()=>lastVerifiedRaw,planCoordinateMigration,markers:()=>clone(scene().markers),markerCommand,openMarkerDialog,inspectReconcile,adoptReconciled,restoreReview,uncertain:()=>Boolean(storageUncertain),state:()=>clone(workspace),scene:()=>clone(scene()),validateWorkspace,validateReplay,restoreCandidate,shadowcast:({x,y,radius})=>[...symmetricShadowcast(scene(),{x,y},radius)].sort(),fovNow:()=>currentFov(scene())?[...currentFov(scene())].sort():null,mode:changeMode,cell:clickCell,undo,redo,save:saveLocal,createScene,copyScene,switchScene,resize,addToken:()=>editToken(true),capture:addEventFrame,replay:()=>viewReplay?clone(viewReplay):null,seek,makeReplay:()=>makeReplay(scene()),zoom:v=>cameraScale(v),ruler:()=>({scene:rulerSceneId,start:rulerA?clone(rulerA):null,end:rulerB?clone(rulerB):null,text:$('rulerStatus').textContent}),lastRenderMs:()=>renderLast,render,center};
initialize();
})();
