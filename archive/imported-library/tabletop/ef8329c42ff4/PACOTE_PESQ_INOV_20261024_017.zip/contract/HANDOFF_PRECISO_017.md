# Handoff científico imediato — PESQ-017

**Nenhum patch instalado.** Propostas para responsáveis exclusivos, fundamentadas nos testes novos. Reutilizar TEST37 e Codex existentes; não criar backend nem motor concorrente.

## Para Desenvolvedor TEST37

1. Preservar canário **PESQ-016** `ROOM_UPDATED` não vira `MOVE_CONFIRMED`. TEST37 código atual continua RED. Corrigir no adaptador titular, não no código do Pesquisador.
2. Ao receber uma integração Codex candidata, executar `tests/audit_client_state_017.cjs` e `tests/audit_resync_017.mjs` sobre **bytes da versão real**. A segunda resposta durante RESYNC deve converter-se em `SNAPSHOT`, nunca novo `WELCOME`.
3. Não modificar `ROOM_INTENT` só para transportar ações fictícias; o HUD unidade→ação→alvo deve indicar MECÂNICA INDISPONÍVEL, sem gastar Vida/Alma/PA até ABI VLAB homologada.
4. Sem objeto geométrico autorizado `sceneId,n,walls,units,markers`, falhar fechado de forma comunicável; não derivar posições de `actors[].label` e não atribuir proprietário por perfil DEMO.

## Para Codex / dono único do servidor de sala

1. A recuperação de recibos **já existe na 0.2.0**. Não replicar a pesquisa antiga. Reutilizar receipt `client_action_id`, `receipt_id`, `status`, `revision`, `code`, `public_event_id`, `mechanics` e validar original por origem autorizada.
2. **Adapter de saída TEST37 proposto:** `ACCEPTED receipt` → `ACK(status=ACCEPTED, revision, eventId)`, *somente* se o evento corresponde a um tipo homologado de apresentação; `FORBIDDEN` → `UNAUTHORIZED` sem eco de IDs secretos; `MECHANICS_UNAVAILABLE` → `MECHANICS_HOLD`; `STALE_REVISION` → `STALE_REVISION`; `ID_REUSE_CONFLICT` → `ID_REUSE_CONFLICT`. Não assumir homologação desta tabela; obter ACK de proprietários e testes de regressão.
3. `receipt_query(lookup=NOT_FOUND)` → frame TEST37 `RECEIPT(status=NOT_FOUND)` para **preservar UNKNOWN e ID original**, jamais ACK de rejeição terminal nem nova ID. A prova está no cliente original. `reply.ok=false` sem recibo durável segue UNKNOWN, porém deve caber num envelope que o cliente consiga tratar sem desconectar prematuramente.
4. `RESYNC` exige **snapshot autorizado da sala e revisão**, não WELCOME duplicado. Separar JOIN/RESYNC e não derivar `seq` simplesmente de `revision`: Codex explicita que isso não é equivalência canônica.
5. `view` Codex 0.2.0 retorna labels, notas por papel, mas **não** o tabuleiro TEST37. A geometria e ownership devem vir da fonte competente; filtrar **antes da serialização/transmissão**, com testes negativos raw por player. Nunca entregar `master_note`, `private_notes`, ZIP VLAB nem notas de player de outra pessoa a cliente Party.
6. A 0.3.0 com `EVENT_QUERY` foi documentada no Notion. Conferir **bytes exatos e TEST37** em nova linha antes de afirmar que supre evento/RESYNC/geometry.

## Para o VLAB competente

Precisamos de ABI homologada para `TURN_START_REQUEST`, `ATTACK_REQUEST` e `DEFENSE_REQUEST/REACTION`, com versão, ator/alvo/turno/ação, intent correlator, revisão de aplicação, resultado público/individual/Mestre, causalidade e idempotência. **Nenhuma fórmula nem consumo de recurso novo foi implementado**. Enquanto ausente, conservar `MECHANICS_UNAVAILABLE` com recibo persistente TEST, sem evento mecânico falso.

## Gates de aceitação da futura integração

- Um JOIN do Mestre e dois participantes **realmente autenticados**, papel e unidade derivados no servidor.
- TEST37 aceita WELCOME com tabuleiro real/autorizado; eventos REVISÃO/SEQ com causalidade explícita, RESYNC produz SNAPSHOT segura, não re-JOIN.
- Ação sintética legítima gera recibo; ACK perdido permite consultar o mesmo ID após restart, sem segundo efeito; terceiro participante não lê recibo de outro.
- Logs RAW na fronteira de envio player seguros, incluindo erro e replay; `master_note`/campos aninhados/segredos não cruzam rede.
- Só declarar combate VLAB quando execução homologada do motor oficial e gate separado forem demonstrados.

**Execução local:** `bash run_all.sh` usa somente CPython 3, Node 22.16+ com `--experimental-strip-types` e fontes preservadas. Os testes HTTP são loopback e não realizam deploy.
