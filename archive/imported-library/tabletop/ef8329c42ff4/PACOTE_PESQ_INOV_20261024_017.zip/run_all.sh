#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python verify_manifest.py
python tests/audit_http.py
python tests/audit_security_extra_017.py
node --experimental-strip-types tests/audit_wire_017.mjs
node tests/audit_client_state_017.cjs
node --experimental-strip-types tests/audit_resync_017.mjs
