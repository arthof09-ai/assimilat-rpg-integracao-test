# PESQ-INOV-20261024-017 — Auditoria diferencial física (MESTRE-ONLY)

Continuação da Pesquisa do Tabletop; **não é novo servidor, engine, frontend ou operação**. Fontes físicas TEST37 (RUN014) e Codex 0.2.0 provêm dos ZIPs preservados na Biblioteca Mestre, checksums no manifesto. PESQ016 usada como baseline documental e para canário conhecido; não foi reexecutada integralmente.

Execute `bash run_all.sh`. Testes independentes:

- `tests/audit_http.py`: sobe o **servidor HTTP original** Codex com SQLite original em diretório temporário, identidades FAKE e porta loopback efêmera; inspeciona o corpo HTTP após projeção/antes da interface, sem credencial real. 30 verificações (incluem 17 requisições HTTP e asserts adicionais).
- `tests/audit_security_extra_017.py`: cenários negativos de autenticação fake, administração, payloads malformados e recibos cruzados na autoridade HTTP original.
- `tests/audit_wire_017.mjs`: carrega JS real TEST37 em VM e importa TS real `RoomV2Adapter` Codex; verificações positivas de identidade contratual e controles negativos esperados, candidatos limitados sem patch.
- `tests/audit_client_state_017.cjs`: executa estado real de `RoomClient`/adaptador TEST37 em VM, sem DOM, e avalia conexão incompatível, ACK UNKNOWN vs RECEIPT NOT_FOUND.
- `tests/audit_resync_017.mjs`: demonstra com ambos os módulos originais `RESYNC→WELCOME` produzindo falha em sessão já conectada, e `SNAPSHOT` sendo aceito.

**Não** há WSS, Cloudflare, Android físico, autenticação de produção, VLAB oficial, iniciativa ou dano. Experimentos não demonstram um ataque mecânico real. **Não publique** este pacote Mestre-only em GitHub/Party.

Consulte `report/MATRIZ_DIFERENCIAL_017.md`, `contract/HANDOFF_PRECISO_017.md`, `report/PSV_017.md`, `evidence/*.json` e `MANIFEST_SHA256.json`. A manutenção futura deve basear-se na versão atual dos executores; a 0.3.0 Codex foi registrada depois, mas não auditada fisicamente aqui.
