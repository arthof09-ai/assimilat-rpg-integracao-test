'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const base=path.resolve(__dirname,'..');
const srcAdapter=fs.readFileSync(path.join(base,'dev/public/room-v2-adapter.js'),'utf8');
const original=fs.readFileSync(path.join(base,'dev/public/room-client.js'),'utf8');
const cut=original.indexOf("const room=byId('roomPanel')");assert(cut>0);
const clientScript=original.slice(0,cut).replace(/\s*$/,'')+'\n window.__RoomClient=RoomClient;\n})();';
function setup(){const ctx=vm.createContext({window:{},console,crypto:{getRandomValues:b=>b.fill(1)}});vm.runInContext(srcAdapter,ctx);vm.runInContext(clientScript,ctx);return ctx;}
const ledger=[];
function run(name,fn){fn();ledger.push(name)}
function storage(){const values=new Map();return {getItem:k=>values.has(k)?values.get(k):null,setItem:(k,v)=>values.set(k,String(v))};}
function attach(ctx){let socket;const sent=[];
 const factory=ctx.window.TabletopRoomV2TEST.createV2AdapterTransport(c=>{socket=c;return {send:raw=>sent.push(JSON.parse(raw)),close:()=>{}}});
 const C=ctx.window.__RoomClient;const c=new C({transportFactory:factory,protocol:'v2',nonce:'newtest',journalStore:storage(),onUpdate:()=>{}});
 c.connect('p1');return {c,socket:()=>socket,sent};
}
function welcome(ctx){const m=ctx.window.TabletopRoomV2TEST.mock;return {v:2,type:'WELCOME',roomId:'arena-test',participantId:'p1',role:'PLAYER',revision:0,sessionEpoch:1,snapshot:{sceneId:'scene-test',n:m.n,walls:[...m.walls],markers:[],units:m.units.filter(x=>x.ownerId==='p1').map(x=>({...x}))},members:[{id:'gm',label:'Mestre TEST',role:'MASTER'},{id:'p1',label:'Player 1 TEST',role:'PLAYER'},{id:'p2',label:'Player 2 TEST',role:'PLAYER'}]};}
const http=JSON.parse(fs.readFileSync(path.join(base,'evidence/codex_http_raw_017.json')));
let ctx=setup(),flow=attach(ctx);
run('TEST37 emits old v2 JOIN ticket in actual client',()=>assert(flow.sent.some(x=>x.type==='JOIN'&&x.ticket==='test-local-p1')));
const codexSourceView=http.records.join_p1_view.json;
const codexAdapterWelcome={schema:'assim.tabletop.room.bridge.test.v2',type:'WELCOME',roomId:'arena-test',revision:codexSourceView.revision,view:codexSourceView.view};
flow.socket().onMessage(JSON.stringify(codexAdapterWelcome));
run('CODEX 0.2 WELCOME cannot establish TEST37 client session',()=>assert.equal(flow.c.connected,false));
run('TEST37 rejects Codex WELCOME without rendering private projection',()=>assert.equal(flow.c.snapshot,null));
run('TEST37 enters error after Codex WELCOME mismatch',()=>assert.equal(flow.c.status,'error'));
ctx=setup();flow=attach(ctx);flow.socket().onMessage(JSON.stringify(welcome(ctx)));
run('Control: TEST37 native WELCOME connects client',()=>assert.equal(flow.c.connected,true));
run('Control: native projection matches p1 unit',()=>assert(flow.c.snapshot.units.some(x=>x.ownerId==='p1')));
flow.c.sendIntent('demo_a',2,1);
run('TEST37 native visual intent journaled',()=>assert.equal(flow.c.pending.size,1));
run('TEST37 visual intent reaches v2 mock transport before server decision',()=>assert(flow.sent.some(x=>x.type==='INTENT')));
const command=flow.sent.find(x=>x.type==='INTENT').commandId;
// 0.2 wrapper uses ACK status UNKNOWN for NOT_FOUND, but TEST37 only allows RECEIPT status NOT_FOUND.
const bad={v:2,type:'ACK',roomId:'arena-test',commandId:command,status:'UNKNOWN',code:'NOT_FOUND',receipt:null};
flow.socket().onMessage(JSON.stringify(bad));
run('Codex UNKNOWN ACK semantics incompatible with TEST37 framing',()=>assert.equal(flow.c.status,'unknown')); // handler markUnknown after validation error
run('Fail closed retains unresolved local intent',()=>assert.equal(flow.c.pending.size,1));
run('Fail closed prevents local state mutation',()=>assert.equal(flow.c.snapshot,null));
ctx=setup();flow=attach(ctx);flow.socket().onMessage(JSON.stringify(welcome(ctx)));flow.c.sendIntent('demo_a',2,1);
const command2=flow.sent.find(x=>x.type==='INTENT').commandId;
assert.equal(http.records.p2_foreign_receipt.json.lookup,'NOT_FOUND');
const safe={v:2,type:'RECEIPT',roomId:'arena-test',commandId:command2,status:'NOT_FOUND'};
flow.socket().onMessage(JSON.stringify(safe));
run('Candidate NOT_FOUND→RECEIPT status NOT_FOUND accepted by TEST37',()=>assert.equal(flow.c.status,'unknown'));
run('Candidate retained SAME pending ID',()=>assert.equal(flow.c.pending.size,1));
run('Candidate keeps session established without false rejection',()=>assert.equal(flow.c.connected,true));
run('Candidate preserves known authorized position',()=>assert(flow.c.snapshot.units.some(x=>x.id==='demo_a'&&x.x===1&&x.y===1)));
fs.writeFileSync(path.join(base,'evidence/client_state_017.json'),JSON.stringify({executed:ledger.length,checks:ledger,observation:'actual TEST37 RoomClient code and v2 adapter in JS VM; Codex HTTP outputs only synthetic; candidate NOT_FOUND mapping is PROPOSED, not integrated',auth:'FAKE_TEST',officialMechanics:false},null,2));
console.log(JSON.stringify({pass:ledger.length,checks:ledger}));
