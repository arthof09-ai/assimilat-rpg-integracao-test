"""Focused adversarial HTTP input probes on ORIGINAL Codex server; no new backend."""
import sys, pathlib, tempfile, threading, json, urllib.request,urllib.error
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'codex/experiments/tabletop_vlab_bridge'))
from authority import Authority,make_server

def wire(endpoint,token,raw):
    if isinstance(raw,dict):raw=json.dumps(raw,separators=(',',':')).encode()
    req=urllib.request.Request(endpoint,raw,headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=4) as r:return r.status,r.read()
    except urllib.error.HTTPError as e:return e.code,e.read()
with tempfile.TemporaryDirectory() as td:
    server=make_server(Authority(pathlib.Path(td)/'db.sqlite'),0)
    th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    url=f'http://127.0.0.1:{server.server_port}/bridge';checks=[];examples={}
    def check(name,tok,req,status,code=None):
        s,b=wire(url,tok,req); j=json.loads(b); assert s==status,(name,s,b)
        if code:assert j['error']['code']==code,(name,j)
        if status!=200: assert b'FAKE_MASTER_ONLY' not in b and b'FAKE_P2_ONLY' not in b
        checks.append(name);examples[name]={'status':s,'body':j};return j
    try:
        M='FAKE_TEST_MASTER';P='FAKE_TEST_PLAYER1';Q='FAKE_TEST_PLAYER2'
        check('create_test_room',M,{'schema_version':1,'op':'create','room_id':'arena-test','client_action_id':'create01','expected_revision':0},200)
        check('player_cannot_create_other_room',P,{'schema_version':1,'op':'create','room_id':'badroom','client_action_id':'create02','expected_revision':0},403,'FORBIDDEN')
        check('unknown_token_rejected', 'FAKE_TEST_UNKNOWN', {'schema_version':1,'op':'view','room_id':'arena-test'},403,'FORBIDDEN')
        check('prototype_injection_rejected',P,{'schema_version':1,'op':'view','room_id':'arena-test','data':{'__proto__':{'access':'master'}}},400,'INVALID_SCHEMA')
        check('duplicate_json_key_rejected',P,b'{"schema_version":1,"op":"view","room_id":"arena-test","op":"create"}',400,'INVALID_SCHEMA')
        accepted=check('valid_own_receipt_create',P,{'schema_version':2,'op':'submit','room_id':'arena-test','client_action_id':'cmd01','expected_revision':0,'actor_id':'actor-1','effect':{'kind':'FAKE_SET_LABEL','label':'First'}} ,200)
        assert accepted['receipt']['status']=='ACCEPTED';checks.append('own_receipt_durable')
        check('mutated_payload_same_id_rejected',P,{'schema_version':2,'op':'submit','room_id':'arena-test','client_action_id':'cmd01','expected_revision':0,'actor_id':'actor-1','effect':{'kind':'FAKE_SET_LABEL','label':'Mutated'}} ,409,'ID_REUSE_CONFLICT')
        own=check('same_receipt_still_recoverable',P,{'schema_version':2,'op':'receipt_query','room_id':'arena-test','client_action_id':'cmd01'},200)
        assert own['receipt']==accepted['receipt'];checks.append('mutation_does_not_destroy_original')
        cross=check('other_player_cannot_see_original',Q,{'schema_version':2,'op':'receipt_query','room_id':'arena-test','client_action_id':'cmd01'},200)
        assert cross['lookup']=='NOT_FOUND' and cross['receipt'] is None;checks.append('cross_owner_receipt_redacted')
    finally:
        server.shutdown();server.server_close();th.join(timeout=2)
    out={'checks':checks,'count':len(checks),'examples':examples,'notes':'Original Codex HTTP service; known fake identities; no revoke/expiry capacity in this artifact; tokens must not be mistaken for real auth.'}
    (BASE/'evidence/security_extra_017.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'pass':len(checks),'scope':'codex0.2 original HTTP'}))
