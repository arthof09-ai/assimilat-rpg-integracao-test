/** PESQ017 independent boundary test: REAL TEST37 JS + REAL Codex 0.2.0 TS, read-only originals. */
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const base=path.resolve(import.meta.dirname,'..');
const actual=JSON.parse(fs.readFileSync(path.join(base,'evidence/codex_http_raw_017.json')));
const codexRoot=path.join(base,'codex/experiments/tabletop_vlab_bridge');
const {validateFrame,RoomV2Adapter,ROOM_SCHEMA}=await import(pathToFileURL(path.join(codexRoot,'room_adapter.ts')).href);
const devSrc=fs.readFileSync(path.join(base,'dev/public/room-v2-adapter.js'),'utf8');
const context=vm.createContext({window:{},console});vm.runInContext(devSrc,context,{filename:'TEST37-real-room-v2-adapter.js'});
function devCheck(fn,value){context.testFrame=JSON.stringify(value);return vm.runInContext(`window.TabletopRoomV2TEST.${fn}(JSON.parse(testFrame))`,context);}
function redFrame(call){let failed=false;try{validateFrame(call);}catch(e){failed=e.code==='INVALID_FRAME'||e.code==='UNSUPPORTED_ACTION';}assert(failed);}
const checks=[],negative=[];
function pass(name,fn){fn();checks.push(name)}
function reject(name,fn){fn();negative.push(name)}
const c=actual.records;
const oldJoin={v:2,type:'JOIN',roomId:'arena-test',ticket:'test-local-p1'};
const oldIntent={v:2,type:'INTENT',roomId:'arena-test',commandId:'lab001',baseRevision:0,kind:'MOVE_VISUAL_TEST',unitId:'demo_a',payload:{x:2,y:2}};
const oldReceipt={v:2,type:'RECEIPT_QUERY',roomId:'arena-test',commandId:'lab001'};
pass('TEST37 original accepts its fixture JOIN',()=>assert(devCheck('validV2Outgoing',oldJoin)));
pass('TEST37 original accepts its MOVE_VISUAL_TEST fixture intent',()=>assert(devCheck('validV2Outgoing',oldIntent)));
pass('TEST37 original accepts its receipt query',()=>assert(devCheck('validV2Outgoing',oldReceipt)));
reject('Codex0.2 rejects TEST37 JOIN wire — SCHEMA/shape',()=>redFrame(oldJoin));
reject('Codex0.2 rejects TEST37 INTENT wire — schema+movement unsupported',()=>redFrame(oldIntent));
reject('Codex0.2 rejects TEST37 RECEIPT_QUERY wire — namespace+type',()=>redFrame(oldReceipt));
reject('TEST37 rejects Codex canonical receipt_query JSON body as direct frame',()=>assert(!devCheck('validV2Response',c.p1_receipt.json)));
reject('TEST37 rejects Codex canonical view JSON body as direct WELCOME',()=>assert(!devCheck('validV2Response',c.join_p1_view.json)));
reject('TEST37 rejects Codex projection as geometry (n/walls/units absent)',()=>assert(!devCheck('validProjection',c.join_p1_view.json.view)));
const bridgeFake={request:async x=>c.join_p1_view.json,requestV2:async x=>x.op==='receipt_query'?c.p1_receipt.json:c.p1_submit.json};
const bridge=new RoomV2Adapter(bridgeFake);
const normalizedFrame={schema:ROOM_SCHEMA,type:'JOIN',roomId:'arena-test'};
validateFrame(normalizedFrame);checks.push('Codex join validates its own frame');
const codexWelcome=await bridge.exchange(normalizedFrame);
reject('TEST37 rejects authentic Codex RoomV2Adapter WELCOME (schema/view/membership)',()=>assert(!devCheck('validV2Response',codexWelcome)));
const codexAck=await bridge.exchange({schema:ROOM_SCHEMA,type:'RECEIPT_QUERY',roomId:'arena-test',commandId:'lab001'});
reject('TEST37 rejects authentic Codex RoomV2Adapter ACK (schema/receipt DTO)',()=>assert(!devCheck('validV2Response',codexAck)));
pass('Codex ACK receipt preserves original commandId',()=>assert.equal(codexAck.commandId,'lab001'));
pass('Codex receipt owner returned same stored result',()=>assert.deepEqual(codexAck.receipt,c.p1_submit.json.receipt));
// Condition for a safely designed mapping is NOT a conversion of fake labels into combat.
const receipt=c.p1_submit.json.receipt;
const mappedAck={v:2,type:'ACK',roomId:'arena-test',commandId:receipt.client_action_id,status:receipt.status,revision:receipt.revision,eventId:receipt.public_event_id};
pass('Candidate mapping ACCEPTED+eventId from real Codex receipt accepted by TEST37',()=>assert(devCheck('validV2Response',mappedAck)));
const mapping=[['p2_wrong_actor','UNAUTHORIZED'],['p1_attack_hold','MECHANICS_HOLD'],['p2_stale','STALE_REVISION']];
for (const [record,safeCode] of mapping){
 const r=c[record].json.receipt;
 const wrong={v:2,type:'ACK',roomId:'arena-test',commandId:r.client_action_id,status:r.status,reason:r.code,currentRevision:r.revision};
 reject(`Direct Codex reason ${r.code} -> TEST37 ${devCheck('validV2Response',wrong)?'ACCEPTED':'RED'} (${record})`,()=>{if(['FORBIDDEN','MECHANICS_UNAVAILABLE'].includes(r.code))assert(!devCheck('validV2Response',wrong));else assert(devCheck('validV2Response',wrong))});
 const safe={...wrong,reason:safeCode};pass(`Candidate explicit status-mapping ${r.code} to ${safeCode}`,()=>assert(devCheck('validV2Response',safe)));
}
// Critical: DISPLAY gap. TEST37 cannot infer canvas geometry from synthetic fake labels in Codex projection.
pass('Original Codex view contains exact role-projected actor labels',()=>assert.equal(c.join_p1_view.json.view.actors.length,3));
pass('Original Codex view has no official XY topology',()=>{let v=c.join_p1_view.json.view;assert(!('n' in v)&&!('units' in v)&&!('walls' in v))});
const history=c.p1_history.json;
pass('Codex history uses own event revisions and no seq field',()=>{assert.equal(history.events[0].revision,1);assert(!('seq' in history.events[0]))});
reject('TEST37 requires EVENT snapshot and implicit seq revision, absent Codex history',()=>{let ev=history.events[0];assert(!devCheck('validV2Response',{v:2,type:'EVENT',roomId:'arena-test',revision:ev.revision,commandId:'lab001',kind:'ROOM_UPDATED',actorId:'demo_a',snapshot:ev}))});
// Projection security. These raw HTTP frames were sent from the real server before any client filtering.
pass('Codex p1 raw HTTP response excludes master private notes',()=>assert(!c.join_p1_view.raw_utf8.includes('FAKE_MASTER_ONLY')));
pass('Codex p2 raw HTTP response excludes p1 note',()=>assert(!c.join_p2_view.raw_utf8.includes('FAKE_P1_ONLY')));
pass('Codex player2 raw receipt response hides player1 transaction',()=>assert.equal(c.p2_foreign_receipt.json.lookup,'NOT_FOUND'));
pass('Codex invalid payload role forged rejected server-side',()=>assert.equal(c.role_forged_json.json.error.code,'INVALID_SCHEMA'));
pass('Codex 0.2 has no CORS for browser cross-origin use',()=>assert(!('access-control-allow-origin' in c.join_p1_view.headers)));
// Keep legacy canary known bug: no claim of new discovery.
pass('Legacy semantic RED canary preserved, not counted as new defect',()=>{assert(devSrc.includes("kind:'MOVE_CONFIRMED'"));});
const artifact={baseline:['TEST37 real public/room-v2-adapter.js','Codex0.2 real room_adapter.ts/client.ts/authority.py'],newChecks:checks.length,negativeCases:negative.length,checks,negative,redNew:['wire_namespace_shape','role_view_no_board','reason_code_mismatch','event_sequence_not_defined','browser_CORS_not_available'],existingCanary:['ROOM_UPDATED->MOVE_CONFIRMED'],conclusion:'RUNTIME compatibility NOT established. No server or game rules implemented.',run:'node --experimental-strip-types tests/audit_wire_017.mjs'};
fs.writeFileSync(path.join(base,'evidence/wire_diff_017.json'),JSON.stringify(artifact,null,2));
console.log(JSON.stringify({pass:checks.length,negative:negative.length,newGaps:artifact.redNew,legacyCanaryPreserved:true}));
