"""PESQ017: run REAL Codex 0.2 HTTP server as-is; inspect raw post-projection HTTP bodies.
No new backend, no real authentication or gameplay. Public FAKE identities exclusively.
"""
import sys,json, tempfile,threading,urllib.request,urllib.error, pathlib,hashlib
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'codex/experiments/tabletop_vlab_bridge'))
from authority import Authority, make_server

def payload(op, room='arena-test', **kwargs):return {'schema_version':2 if op in ('submit','receipt_query') else 1,'op':op,'room_id':room,**kwargs}
def post(endpoint,token,req):
    data=json.dumps(req,sort_keys=True,separators=(',',':')).encode()
    request=urllib.request.Request(endpoint,data=data,headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    try:
        with urllib.request.urlopen(request,timeout=5) as f: return f.status,f.read(),dict(f.headers)
    except urllib.error.HTTPError as e:return e.code,e.read(),dict(e.headers)

with tempfile.TemporaryDirectory(prefix='pesq017-') as td:
    auth=Authority(pathlib.Path(td)/'codex_original.sqlite')
    server=make_server(auth,0)
    task=threading.Thread(target=server.serve_forever,daemon=True);task.start()
    endpoint=f'http://127.0.0.1:{server.server_port}/bridge'; records={}; checks=[]
    def call(name,token,req,expected_status=None):
        code,body,headers=post(endpoint,token,req)
        assert expected_status is None or code==expected_status, (name,code,body)
        result=json.loads(body)
        assert not any(w in body for w in [b'FAKE_MASTER_ONLY',b'FAKE_P2_ONLY']) if token=='FAKE_TEST_PLAYER1' else True
        assert not any(w in body for w in [b'FAKE_MASTER_ONLY',b'FAKE_P1_ONLY']) if token=='FAKE_TEST_PLAYER2' else True
        records[name]={'http':code,'json':result,'raw_utf8':body.decode(),'headers':{k.lower():v for k,v in headers.items() if k.lower() in ('cache-control','access-control-allow-origin','content-type')}}
        checks.append(name)
        return result
    try:
        gm='FAKE_TEST_MASTER';p1='FAKE_TEST_PLAYER1';p2='FAKE_TEST_PLAYER2'
        call('create',gm,payload('create',client_action_id='create001',expected_revision=0),200)
        v1=call('join_p1_view',p1,payload('view'),200)
        v2=call('join_p2_view',p2,payload('view'),200)
        vg=call('join_master_view',gm,payload('view'),200)
        assert 'own_note' in v1['view'] and 'master_note' not in v1['view'];checks.append('projection_p1')
        assert 'own_note' in v2['view'] and 'master_note' not in v2['view'];checks.append('projection_p2')
        assert 'master_note' in vg['view'];checks.append('projection_master')
        good=payload('submit',client_action_id='lab001',expected_revision=0,actor_id='actor-1',effect={'kind':'FAKE_SET_LABEL','label':'Synthetic-L1'})
        accepted=call('p1_submit',p1,good,200)
        assert accepted['receipt']['status']=='ACCEPTED';checks.append('accepted_synthetic')
        q=payload('receipt_query',client_action_id='lab001')
        own=call('p1_receipt',p1,q,200);notowner=call('p2_foreign_receipt',p2,q,200)
        assert own['receipt']==accepted['receipt'] and notowner['receipt'] is None and notowner['lookup']=='NOT_FOUND';checks.append('private_receipt')
        wrong=payload('submit',client_action_id='bad001',expected_revision=1,actor_id='actor-1',effect={'kind':'FAKE_SET_LABEL','label':'Fake-attack'})
        forbidden=call('p2_wrong_actor',p2,wrong,200)
        assert forbidden['receipt']['code']=='FORBIDDEN' and forbidden['receipt']['status']=='REJECTED';checks.append('wrong_actor_durable')
        stale=call('p2_stale',p2,payload('submit',client_action_id='stale001',expected_revision=0,actor_id='actor-2',effect={'kind':'FAKE_SET_LABEL','label':'stale'}),200)
        assert stale['receipt']['code']=='STALE_REVISION';checks.append('revision_competition')
        attack=call('p1_attack_hold',p1,payload('submit',client_action_id='attack001',expected_revision=1,actor_id='actor-1',action={'kind':'ATTACK_REQUEST','target':{'kind':'UNIT','actor_id':'actor-2'},'turn_id':'turn-1','context':{'scene_id':'scene-1','ability_id':'abil-1'}}),200)
        assert attack['receipt']['code']=='MECHANICS_UNAVAILABLE' and attack['receipt']['status']=='REJECTED';checks.append('mechanics_hold_without_state_effect')
        call('query_attack_hold',p1,payload('receipt_query',client_action_id='attack001'),200)
        call('p1_history',p1,payload('history',after_revision=0),200)
        call('p2_history',p2,payload('history',after_revision=0),200)
        call('p1_resync_view',p1,payload('view'),200)
        error=call('role_forged_json',p1,{**payload('view'),'role':'master'},400)
        assert error['error']['code']=='INVALID_SCHEMA';checks.append('role_forgery_failclosed')
        err=call('nested_admin_json',p1,{**payload('view'),'payload':{'private_notes':{'hidden':'FAKE_MASTER_ONLY'}}},400)
        assert err['error']['code']=='INVALID_SCHEMA';checks.append('nested_schema_failclosed')
        err=call('missing_room',p2,payload('view',room='nonexistent'),403)
        assert err['error']['code']=='FORBIDDEN';checks.append('room_presence_masked')
        assert 'access-control-allow-origin' not in records['join_p1_view']['headers'];checks.append('http_no_cors')
        assert records['p1_resync_view']['json']['revision']==1;checks.append('hold_without_revision_advance')
    finally:
        server.shutdown();server.server_close();task.join(timeout=3)
    data={'source':'Codex 0.2.0 original authority.py via loopback HTTP; TEST FAKE identity','server':'127.0.0.1 ephemeral port; NO cloud NO WSS','checks':checks,'count':len(checks),'records':records,'retained_private_bytes':False}
    target=BASE/'evidence/codex_http_raw_017.json'
    target.write_text(json.dumps(data,indent=2,ensure_ascii=False))
    print(json.dumps({'pass':len(checks),'names':checks,'safety':'FAKE_HTTP_LOOPBACK'}))
