"""Verify immutable snapshot bytes BEFORE running tests (tests regenerate random fake receipts)."""
import pathlib,hashlib,json,sys
root=pathlib.Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST_SHA256.json').read_text())
assert m['checkpoint']=='PESQ-INOV-20261024-017'
checks=m['files'];assert len(checks)>=20
for rel,item in checks.items():
    p=root/rel
    assert p.is_file(),rel
    content=p.read_bytes()
    assert len(content)==item['bytes'],(rel,'size')
    assert hashlib.sha256(content).hexdigest()==item['sha256'],(rel,'sha')
print(json.dumps({'manifest':'PASS','files':len(checks),'checkpoint':m['checkpoint']}))
