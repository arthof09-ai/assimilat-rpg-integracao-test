import json
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);pg=b.new_page();pg.set_content('<!doctype html><body>FOV sandbox</body>');pg.add_script_tag(content=(P/'fov_independent_004.js').read_text());r=pg.evaluate('''()=>{
 const tests=[];const add=(n,ok,detail={})=>tests.push({name:n,pass:!!ok,detail});const g={width:20,height:20,walls:[]};const wall={...g,walls:[[11,10]]};
 for(const method of ['recursive','symmetric']){
  let a=Pesq004FOV[method](g,[10,10],5),z=Pesq004FOV[method](g,[10,10],0),b=Pesq004FOV[method](wall,[10,10],5);
  add(method+' radius0 singleton',z.size===1&&z.has('10,10'));
  add(method+' unblocked near target visible',a.has('12,10'));
  add(method+' wall visible',b.has('11,10'));
  add(method+' occludes behind wall',!b.has('12,10'));
  add(method+' invalidation responds immediately',a.has('12,10')&&!b.has('12,10'));
  const expl=Pesq004FOV.explored(new Set(['1,1']),b);add(method+' explored monotone',expl.has('1,1')&&[...b].every(k=>expl.has(k)));
 }
 try{Pesq004FOV.symmetric(g,[-1,2],4);add('invalid origin rejected',false)}catch(e){add('invalid origin rejected',true)}
 return tests;
 }''');b.close()
print('PROPERTIES',sum(t['pass'] for t in r),'/',len(r),[x for x in r if not x['pass']]);(P/'evidence'/'FOV_JS_PROPERTIES_004.json').write_text(json.dumps({'tests':r},ensure_ascii=False,indent=2))
