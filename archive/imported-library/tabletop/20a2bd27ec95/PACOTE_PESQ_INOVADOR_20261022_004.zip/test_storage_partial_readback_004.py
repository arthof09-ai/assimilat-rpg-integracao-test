"""TEST18 fault-injection: storage write succeeds but subsequent reads throw. Synthetic condition, not actual Android behavior."""
import re,json
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent;R=P/'run006/public';O=P/'evidence';O.mkdir(exist_ok=True)
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text());css=(R/'styles.css').read_text();js=(R/'app.js').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);pg=b.new_page();pg.set_content(html);pg.add_style_tag(content=css)
 pg.evaluate('''()=>{window.__store={};window.__writes=0;window.__gets=0;window.__fault=false;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){window.__gets++;if(window.__fault&&window.__writes>0)throw new DOMException('Read denied after write','SecurityError');return window.__store[k]??null},setItem(k,v){window.__writes++;window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}})}''')
 pg.add_script_tag(content=js);w=pg.evaluate('__tabletopTEST.state()');proposed=json.loads(json.dumps(w));proposed['scenes'][0]['name']='PRIVATE-STORAGE-HALF-WRITTEN'
 result=pg.evaluate('''candidate=>{window.__fault=true;let ok=true,err='';try{__tabletopTEST.restoreCandidate(candidate)}catch(e){ok=false;err=e.name+':'+e.message}return {ok,err,active:__tabletopTEST.state().scenes[0].name,backing:JSON.parse(window.__store['assim.tabletop.synthetic.workspace.v1']).scenes[0].name}}''',proposed)
 # try read again after simulated storage recovers
 readback=pg.evaluate('''()=>{window.__fault=false;return JSON.parse(localStorage.getItem('assim.tabletop.synthetic.workspace.v1')).scenes[0].name}''');b.close()
 result['after_access_recovers']=readback
 (O/'TEST18_PARTIAL_STORAGE_READBACK_004.json').write_text(json.dumps({'browser':'Chromium mocked Storage methods, injected persistent read denial after successful write','observed':result},indent=2))
 print(result)
