"""PESQ004 independent adversarial TEST15 checks; isolated Chromium set_content, synthetic storage.
No source changes to developer product. Assert desired invariants, not known implementation structure.
"""
import json,re
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent; R=P/'baseline/public'; O=P/'evidence'; O.mkdir(exist_ok=True)
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text())
css=(R/'styles.css').read_text();code=(R/'app.js').read_text();results=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 def make(store=None):
  c=b.new_context(viewport={'width':390,'height':844},accept_downloads=True); pg=c.new_page();pg.set_content(html);pg.add_style_tag(content=css)
  pg.evaluate('''obj=>{window.__store=obj||{}; window.__storageFault='';Object.defineProperty(window,'localStorage',{configurable:true,get(){if(window.__storageFault==='access')throw new DOMException('Access denied','SecurityError');return {getItem(k){if(window.__storageFault==='get')throw new DOMException('Denied','SecurityError');return Object.hasOwn(window.__store,k)?window.__store[k]:null},setItem(k,v){if(window.__storageFault==='quota')throw new DOMException('Quota exceeded','QuotaExceededError');if(window.__storageFault==='set-security')throw new DOMException('Denied','SecurityError');window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}}})}''',store)
  pg.add_script_tag(content=code);pg.wait_for_function('!!window.__tabletopTEST');pg.on('dialog',lambda d:d.accept());return c,pg
 def state(pg):return pg.evaluate('__tabletopTEST.state()')
 def inject(pg,payload,name='restore'):
  data=payload if isinstance(payload,str) else json.dumps(payload,ensure_ascii=False)
  pg.locator('#'+name).set_input_files({'name':'synthetic.json','mimeType':'application/json','buffer':data.encode()});pg.wait_for_timeout(180)
 def run(name,fn):
  try:
   x=fn();x['name']=name;x['status']='PASS' if x['invariant_met'] else 'FAIL'; results.append(x);print(x['status'],name,str(x.get('observed'))[:170],flush=True)
  except Exception as e:results.append({'name':name,'status':'ERROR','invariant_met':False,'observed':repr(e)});print('ERROR',name,repr(e),flush=True)
 def scenario(mutation=None,fault='',success=False):
  c,pg=make();before=state(pg);fixture=json.loads(json.dumps(before));fixture['scenes'][0]['name']='CENA_IMPORTADA_004'
  if mutation: mutation(fixture)
  if fault:pg.evaluate('(x)=>window.__storageFault=x',fault)
  inject(pg,fixture);after=state(pg);msg=pg.locator('#message').inner_text();status=pg.locator('#storageStatus').inner_text()
  raw=pg.evaluate('()=>window.__store["assim.tabletop.synthetic.workspace.v1"]??null')
  expected=bool(raw and json.loads(raw)['scenes'][0]['name']=='CENA_IMPORTADA_004')
  ok=(after['scenes'][0]['name']=='CENA_IMPORTADA_004' and expected and 'restaurad' in msg.lower()) if success else (after==before and 'restaurad' not in msg.lower())
  c.close();return {'invariant_met':ok,'observed':{'before_unchanged':after==before,'saved_correct':expected,'status':status[:90],'ui':msg[:95]},'type':'Chromium with injected storage'}
 run('backup válido -> persistência e sucesso',lambda:scenario(success=True))
 run('quota setItem -> rollback e sem falso sucesso',lambda:scenario(fault='quota'))
 run('SecurityError setItem -> rollback',lambda:scenario(fault='set-security'))
 run('SecurityError acesso localStorage -> rollback',lambda:scenario(fault='access'))
 run('versão futura -> fail closed',lambda:scenario(mutation=lambda w:w.update(version=9)))
 run('cena de dimensão inválida -> fail closed',lambda:scenario(mutation=lambda w:w['scenes'][0].update(n=400)))
 run('ID duplicado de cena -> fail closed',lambda:scenario(mutation=lambda w:w['scenes'].append(json.loads(json.dumps(w['scenes'][0])))))
 run('conjunto com uma cena inválida -> fail closed',lambda:scenario(mutation=lambda w:w['scenes'].append(dict(w['scenes'][0],id='c2',walls=['900,0']))))
 run('chave perigosa __proto__ -> fail closed',lambda:scenario(mutation=lambda w:w['scenes'][0].update({'__proto__':{'admin':True}})))
 run('ID token duplicado -> fail closed',lambda:scenario(mutation=lambda w:w['scenes'][0]['units'].append(dict(w['scenes'][0]['units'][0]))))
 def wrong_format():
  c,pg=make();before=state(pg);inject(pg,'{"x":');after=state(pg);msg=pg.locator('#message').inner_text();c.close();return {'invariant_met':after==before and 'rejeitad' in msg.lower(),'observed':msg}
 run('JSON sintaticamente inválido -> fail closed',wrong_format)
 def size_limit():
  c,pg=make();before=state(pg);pg.locator('#restore').set_input_files({'name':'too_big.json','mimeType':'application/json','buffer':b' '*750001});pg.wait_for_timeout(170);after=state(pg);msg=pg.locator('#message').inner_text();c.close();return {'invariant_met':after==before and 'rejeitad' in msg.lower(),'observed':msg}
 run('arquivo >750KB -> fail closed',size_limit)
 def durable():
  c,pg=make();w=state(pg);w['scenes'][0]['name']='DURAVEL004';inject(pg,w);raw=pg.evaluate('window.__store');c.close();c2,pg2=make(raw);v=state(pg2)['scenes'][0]['name'];c2.close();return {'invariant_met':v=='DURAVEL004','observed':{'reopened_name':v},'type':'two Chromium documents + explicit simulated storage transfer'}
 run('restauração recuperável em nova instância simulada',durable)
 def read_failure():
  c,pg=make();pg.evaluate("window.__storageFault='get'");pg.evaluate('''()=>{try{window.localStorage.getItem('anything')}catch(e){window.__caught=e.name}}''');caught=pg.evaluate('window.__caught');before=state(pg);w=json.loads(json.dumps(before));w['scenes'][0]['name']='VALID_WITH_GET_ERROR';inject(pg,w);after=state(pg);c.close();return {'invariant_met':after['scenes'][0]['name']=='VALID_WITH_GET_ERROR','observed':{'getItem_error':caught,'restored':after['scenes'][0]['name']},'type':'getItem forced; backup restore does not normally read getItem'}
 run('getItem falha mas restauração não depende dele',read_failure)
 def boot_read_failure():
  c,pg=make();pg.evaluate("window.__storageFault='get'");pg.add_script_tag(content=code.replace('window.__tabletopTEST=', 'window.__tabletopTEST2=')) if False else None
  # New simulated browser document with injected fault BEFORE source JS initialization
  c.close();c2=b.new_context();q=c2.new_page();q.set_content(html);q.add_style_tag(content=css)
  q.evaluate('''()=>{Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(){throw new DOMException('Blocked','SecurityError')},setItem(){} }})}''');q.add_script_tag(content=code)
  x=q.evaluate('({valid:!!window.__tabletopTEST,state:__tabletopTEST.state(),status:document.querySelector("#storageStatus").textContent})');c2.close();return {'invariant_met':x['valid'] and len(x['state']['scenes'])==1 and 'rejeitado' in x['status'].lower(),'observed':x['status']}
 run('getItem SecurityError no boot -> inicializa seguro',boot_read_failure)
 def modify_replay(mode):
  c,pg=make();r=pg.evaluate('__tabletopTEST.makeReplay()');e=json.loads(json.dumps(r['events'][0]));e['id']='frame-000';e['type']='POSITION';r['events'].append(e)
  if mode=='missing':r['events'][1]['frame']['positions'].pop(r['units'][0]['id'])
  if mode=='danger':r['grid']['walls']=[[r['events'][0]['frame']['positions'][r['units'][0]['id']][0],r['events'][0]['frame']['positions'][r['units'][0]['id']][1]]]
  accepted=pg.evaluate('d=>__tabletopTEST.validateReplay(d)',r);c.close();return {'invariant_met':not accepted,'observed':{'validator_accepted':accepted,'mode':mode}}
 run('replay ID regressivo -> contrato rejeita',lambda:modify_replay('reverse'))
 run('replay com ator ausente -> rejeita',lambda:modify_replay('missing'))
 run('replay com parede sob token -> rejeita',lambda:modify_replay('danger'))
 def topology():
  c,pg=make();w=state(pg);s=w['scenes'][0];s['frameTopology']='INVALIDO_004';s['frames']=[{'title':'quadro','positions':{u['id']:[u['x'],u['y']] for u in s['units']}}];ok=pg.evaluate('w=>__tabletopTEST.validateWorkspace(w)',w);c.close();return {'invariant_met':not ok,'observed':{'accepted':ok}}
 run('frameTopology divergente -> rejeita',topology)
 def two_tabs():
  # storage shared by origin is modelled as same backing dictionary explicitly passed, no real cross-tab browsing
  c,a=make();first=state(a);a.evaluate('__tabletopTEST.createScene()');stale=json.loads(json.dumps(first));stale['scenes'][0]['name']='Edição obsoleta';stale['schema']=first['schema'];stale['version']=first['version']
  inject(a,stale);after=state(a);c.close();return {'invariant_met':len(after['scenes'])==2,'observed':{'expected_scene_count':2,'after_stale_import':len(after['scenes'])},'type':'synthetic stale backup overwrite, NOT real multi-tab session'}
 run('backup obsoleto não perde cena nova',two_tabs)
 def interrupted():
  c,pg=make();before=state(pg);w=json.loads(json.dumps(before));w['scenes'][0]['name']='Cancelled import';uploadtext=json.dumps(w)
  # Input read promise never resolves: file.text() monkeypatch through injected input.files impossible; browser File.prototype.text override
  pg.evaluate("File.prototype.text=function(){return new Promise((resolve,reject)=>setTimeout(()=>reject(new DOMException('Interrupted','NotReadableError')),40))}");
  try:pg.locator('#restore').set_input_files({'name':'fixture.json','mimeType':'application/json','buffer':uploadtext.encode()})
  except Exception as ex:injected_error=type(ex).__name__
  else:injected_error=None
  pg.wait_for_timeout(150);after=state(pg);c.close();return {'invariant_met':after==before,'observed':{'state_unchanged':after==before,'injected_error':injected_error},'type':'simulated file.text rejects with NotReadableError'}
 # BLOCKED: File.text NotReadableError propagates through Playwright injection; excluded from meaningful denominator.
 # run('leitura interrompida sem commit -> cena preservada',interrupted)
 b.close()
summary={'baseline':'TEST15 (SHA256 be0b088f5cedd2be1ad32df9e09a9b424fbb13369d98bee4470b8a88637c903b)','environment':'Chromium via set_content, actual DOM+app.js, localStorage simulated; HTTP blocked by administrator','cases':results,'counts':{k:sum(x['status']==k for x in results) for k in ['PASS','FAIL','ERROR']}}
(O/'MATRIZ_TEST15_004.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print('SUMMARY',summary['counts'],'TOTAL',len(results))
