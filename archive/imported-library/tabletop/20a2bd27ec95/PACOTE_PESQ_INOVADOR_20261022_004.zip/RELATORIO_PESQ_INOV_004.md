# PESQ-INOV-20261022-004 — Engenharia preventiva do Tabletop Assimilação

**22/10/2026 | Terceiro Comestre Inovador Pesquisador | MESTRE-SIDE/TEST | orçamento adicional R$ 0**  
**Natureza:** auditoria independente, testes de regressão, experimentos sintéticos e contrato de leitura de VLAB. Nenhuma escrita no código do Desenvolvedor, VLAB, GitHub, Party, O Primeiro ou cânone.

## 1. Fonte, continuidade e autoridade

- Laboratório do Inovador existente: https://app.notion.com/p/401c2b324ede809585d3d1907c194df9 . Último RUN material ao iniciar: **RUN-005/TEST15**; RUN-006 ausente no readback de partida. As pesquisas 001–003 e os despachos 001–009 foram consultados, não duplicados.
- TEST15 técnico final original, recuperado da Biblioteca: `PACOTE_TECNICO_TABLETOP_TEST07_A_TEST15_20261022.zip`, SHA-256 `be0b088f5cedd2be1ad32df9e09a9b424fbb13369d98bee4470b8a88637c903b`. Fonte auditada `public/app.js` (176 linhas, 33.377 bytes), `public/index.html`, `public/styles.css`. Arquivos originais preservados.
- Pacote público original TEST15: SHA-256 `e6f8eda189af26f94518ddbf1afcb1a8333bacfe94bb83419aca084a4563e613`. Não publicado nem alterado pelo Pesquisador.
- Execução digital deste ciclo exclusivamente por scripts **novos desta pesquisa**. Não se repetiu a bateria histórica 185/185 do Desenvolvedor nem os testes 912/912 de FOV em Python.

## 2. Onda A — Matriz adversarial independente de salvamento/importação/replay

**Ambiente observado:** Chromium headless com DOM/CSS/JS **originais do TEST15**, viewport 390×844. `page.goto` para HTTP local foi bloqueado pelo ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`), por isso a bateria válida usou `page.set_content` com remoção **somente em bancada** da CSP e um `localStorage` injetado/isolado; o código e a CSP do site público não foram modificados. **20 casos válidos = 14 PASS / 6 FAIL / 0 erro instrumental**. Um caso `File.text()` artificialmente interrompido foi excluído: a injeção propagou `NotReadableError` pela automação, portanto não há resultado do aplicativo para ele.

**PASS verificáveis:** backup válido e reabertura simulada com transferência explícita do armazenamento; rejeição sem mutação de JSON truncado, >750KB, versão futura, dimensão inválida, cena duplicada, um único membro inválido de conjunto, `__proto__`, ID de token duplicado; `getItem` indisponível no boot resulta em cena segura e alerta; `getItem` forçado a falhar não afeta o fluxo de importação que só depende de `setItem`; rejeição de referência de ator ausente e de parede sobre token num replay.

**FAIL — invariantes desejados NÃO satisfeitos pela baseline:**

| ID / origem concreta | Falha reproduzida | Correção que deverá ser avaliada pelo Desenvolvedor | Aceite |
| --- | --- | --- | --- |
| ST-01 `app.js:170` + `saveLocal():37` | `QuotaExceededError` simulado: cena em RAM muda e UI anuncia sucesso embora não tenha sido salva | Persistência de candidato ANTES de substituir o estado ativo; resultado explícito de falha, sem success toast | RAM e cópia recuperável anteriores intactas se gravação falha |
| ST-02 mesmos | `SecurityError` lançado por `setItem`: mesma mutação indevida | Idem + catch defensivo explícito | Nenhum estado falso ou sucesso falso |
| ST-03 mesmos | `window.localStorage` lança `SecurityError` no acesso: mesma mutação | Transação com tratamento de acesso indisponível | Aplicação apresenta erro e preserva cena |
| ST-04 `validateReplay():147–149` | IDs regressivos únicos passam validação; ordem temporal não está contratada | Se V2 exigir ordenação, declarar `ordinal` explícito ou index como autoridade, sem usar lexicalidade de IDs herdados | TEST03 legado continua válido; replays V2 contraditórios rejeitados |
| ST-05 `validateScene():32–34` + `topology():42` | `frameTopology` string incompatível passa com frames preenchidos | Comparar assinatura com topologia real, ou migrar legado explicitamente | Snapshot adulterado bloqueado; mudanças legítimas são versionadas |
| ST-06 `restore`:170 e `createScene():138` | Um backup sintético antigo de uma cena restaura sobre duas cenas novas sem aviso de conflito além da confirmação genérica | Confirmação específica de destruição, revisão/backup anterior ou política de conflito; para duas abas futuras detectar mudança externa | Importação obsoleta não apaga silenciosamente trabalho recente |

**Qualificação importante:** o cenário ST-06 foi uma restauração obsoleta sintética, **não duas abas Chromium conectadas ao mesmo storage real**; a ausência de listener `storage` e de versionamento concorrente em `app.js` é um risco de arquitetura observado em fonte, mas não uma disputa de corrida real reproduzida no Android. O handler `#restore` recebe `File.text()` assíncrono; mudança concorrente durante a leitura precisa de caso adicional.

**Invariantes de implementação:** (A) falha de persistência não altera workspace ativo; (B) documento rejeitado mantém todas as cenas; (C) UI nunca anuncia sucesso após falha; (D) restauro confirmado é recuperável; (E) versão e fixtures TEST03 seguem regra de migração explícita. `localStorage.setItem` é síncrono, mas pode falhar ou ser negado: fontes [MDN Storage](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API) e [Storage quotas](https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria).

### D-INOV-20261022-010 — P0 | Restauração robusta

**Destinatário:** Desenvolvedor e Coordenador 1. **Gravidade:** alta para integridade de cena. **Versão:** TEST15 final, SHA acima. **Evidência:** ST-01..03, `app.js:37,170`, matriz JSON. **Proposta:** `persistCandidate(candidate)` que valida e grava o candidato sem ler variável global mutável; obter sucesso de `setItem` e só então substituir `workspace`, limpar histórico e renderizar. Em erro, manter ativo e mostrar mensagem inequívoca; criar rollback explícito se for obrigatório chamar render antes. Avaliar gravações subsequentes em `commit`, `undo`, `redo`, `createScene`, `copyScene`, `deleteScene`, `renameScene`: também ignoram retorno booleano de `saveLocal`. **Aceite:** todos ST-01..03 PASS, fluxo normal e reload PASS, 185 testes legados do Desenvolvedor PASS, Android físico pendente. **Estado:** PROPOSTO, sem ACK/implementação confirmados.

### D-INOV-20261022-011 — P0 | Replay e integridade de importação

**Destinatário:** Desenvolvedor e Coordenador 1. **Gravidade:** média, contrato de replay; versão TEST15. **Evidência:** ST-04/05 e positivos de rejeição. **Proposta:** topologia canônica estável (`n`, paredes ordenadas, IDs) validada contra `frameTopology` se frames existem; `frameTopology:null` em arquivo legado requer migração definida, não rejeição indiscriminada. Separar ordem de apresentação (índice do vetor) de eventual evento temporal/rodada; V2 com `ordinal` monotônico, tipo conhecido, política de gaps explícita, ou V1 com índice autoritativo. **Aceite:** corruptos rejeitados e TEST03 legado permanece importável, sem alterar cena ao importar replay. **Estado:** PROPOSTO.

## 3. Onda B — Symmetric vs Recursive Shadowcasting em JavaScript

**Fontes técnicas:** [Albert Ford — Symmetric Shadowcasting](https://www.albertford.com/shadowcasting/) (CC0 da implementação publicada; adaptação independente), [RogueBasin — Recursive Shadowcasting](https://chizaruu.github.io/roguebasin/fov_using_recursive_shadowcasting). Código autoral de bancada: `fov_independent_004.js`, sem integração ao TEST15. O port Symmetric usa razões racionais para limites de setor e divisão em ponto flutuante apenas para determinar colunas de borda; isso foi testado em grades até 70×70, mas NÃO é prova matemática para tamanhos arbitrários.

- Chromium HeadlessChrome/144 Linux via Playwright; **40 cenários distintos** = 10 layouts sintéticos × 4 escalas 20×20, 30×30, 50×50, 70×70, raios 8/12/18/24. **31 execuções medindo cada algoritmo/cenário** = 2.480 medições; aquecimento separado. Tempos pela função `performance.now()` e precisão limitada em valores abaixo de 0,1 ms; medianas por cenário, percentil 95 auditável no JSON.
- **272/272 invariantes PASS** em quatro escalas (origem, limites do mapa, limites do raio e teste limitado de mudança de parede). **17.297 pares direcionais** entre pisos e dentro do raio examinado na versão Symmetric, **zero violações observadas**. **13/13 propriedades adicionais PASS**: raio 0, oclusão de parede isolada, atualização, exploração monotônica e entrada inválida.
- Mediana das medianas entre dez layouts, ms (Recursive / Symmetric): 20² 0,10/0,00*; 30² 0,10/0,10; 50² 0,20/0,20; 70² 0,40/0,40. *Valor 0,00 é abaixo da resolução do temporizador, não tempo físico nulo.* Mediana de p95 entre layouts, ms: 20² 0,20/0,20; 30² 0,20/0,20; 50² 0,45/0,40; 70² 0,65/0,80. Essas medições não têm poder estatístico de prever Chrome Android modesto.
- **12 combinações cenário×escala com divergência geométrica** entre Recursive e Symmetric (paredes isoladas, portas, diagonais). Divergência de visibilidade não equivale automaticamente a bug, pois política de cantos é não canonizada.
- Nenhuma medição confiável do uso de memória do JavaScript foi obtida; marcar **MEMÓRIA PENDENTE**, não supor benefício sem profiler.

### D-INOV-20261022-012 — P0/P1 | FOV experimental

**Situação atual:** FOV ainda não integrado ao TEST15. **Recomendação atualizada:** Symmetric Shadowcasting continua candidato adequado à maquete, mas não por vantagem comprovada de tempo; sua simetria observada favorece consistência geométrica. Recursive é referência de comparação, ligeiramente melhor em alguns percentis altos de 70². **Interface proposta:** `computeVisible({width,height,walls}, [x,y], radius) -> Set<"x,y">`; `exploredNext = union(exploredPrevious,visibleNow)`; `hidden = all - exploredNext`; cache `topologyVersion+origin+radius+policyVersion`; invalidar diante de parede, mudança de mapa, raio ou origem. **Aceite:** 10 fixtures + cantos novos, sem blind corner especificado, piso ↔ piso simétrico quando prometido, no máximo desempenho compatível com Android real após medição; não definir regras canônicas de visão. FOV público futuro deve receber somente projeções de dados previamente autorizadas.

## 4. Onda B — Confiabilidade móvel, acessibilidade e armazenamento

Auditoria adicional Chromium (não Android real) em 360×740 e 390×844 com viewport móvel: **nenhum overflow horizontal observado**, 49 células em grade 7² e 400 em 20², CSS `touch-action:none` restrito ao viewport. O layout móvel define botões `.btn` de 43 px de altura; 43 px não é por si violação demonstrada, mas pode ser elevado a 44 px+ por conforto do toque em botões primários. Há controle exposto de zoom do mapa e controles acessíveis via botão, manter.

**Comparação incremental:** `localStorage` é síncrono, simples e suficiente ao MVP se houver escrita com confirmação, teste de quotas, backup e aviso antes de substituição. IndexedDB possui transações e melhor gerenciamento de objetos maiores, mas também aumenta complexidade de assincronia, migração/recuperação e testes, além de não impedir perda por limpeza de dados do navegador. Não migrar agora sem medidas reais de tamanho, bloqueio ou concorrência. [MDN Storage Quotas](https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria) e [MDN IndexedDB Transaction](https://developer.mozilla.org/en-US/docs/Web/API/IDBDatabase/transaction). Testes físicos ainda necessários: matar navegador, segundo plano, troca orientação, atualização, export/import real e 2 abas reais.

### D-INOV-20261022-013 — P1 | Robustez Android e testabilidade

**Evidência:** `app.js` mistura UI, mutações, `saveLocal` e replay na mesma closure (funções `commit`, `undo`, `createScene`, `restore`, `loadReplay`); isso é **acoplamento observado**, não bug automático. **Proposta incremental:** extrair `validateWorkspace`, `validateReplay` e `persistCandidate` como módulos/pure functions testáveis sem DOM; manter aplicação e testes atuais, não reescrever para framework. Fazer injeção simples de armazenamento para testes; testes reais Android/Chromium, alvos táteis 44 px e feedback de status. **Aceite:** regressões sem DOM passam, matriz adversarial e 185 do Desenvolvedor verde na nova versão, sem duplicação do estado persistido.

## 5. Onda C — Contrato proposto de timeline VLAB R205

**Fonte real reaberta por leitura privada:** ZIP R205 autenticado SHA-256 `62a9851b3a5ae7919b9225d9379a3d32c8736448e76bfcea4729dcbfe933cead`, 20 SQLite identificados, sem runners nem escrita em VLAB. Neste ciclo **UMA base física** foi inspecionada por leitor novo com conexão somente leitura: 49 commits e 147 eventos de apresentação gerados internamente; **não são novos totais do corpus** e não substituir 945/2.812 da PESQ003. Linha `events(seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha)`, com `row_sha=SHA256(row_json)` observado; payload possui `detail` e `payload`, eventos compostos `detail.new_native_events[]` e `detail.events_added[]`. O campo `prev` é encadeado ao hash anterior, exceto origem inicial cuja âncora externa ainda precisa ser validada contra checkpoint de proveniência. Identificadores `cmd_id` únicos por banco, não universalmente; usar ID composto ZIP/banco/seq/origem/nestedIndex.

**POC independente:** `timeline_r205_contract_004.py` aceita bytes SQLite **apenas de fonte já autenticada** e gera evento privado read-only com `event_key`, `commit_seq`, `kind/action`, `actor`, `target` opcionais, `source_seq`, `provenance.row_sha` e `confirmed_coords:null` invariável. Ausência de evento derivável vira linha de commit genérica, não intenção calculada. **14/14 testes PASS**, incluindo ZIP, rejeição de corrupção sintética de `row_json`, `prev`, `cmd_id`, `seq`, entrada truncada, SQLite inválido, uma base R205 real e ausência de XY inventado. Bancos físicos nunca integram o ZIP da pesquisa. O teste de adulteração recalcula apenas fixture sintética em memória; não converte sintético em evento oficial.

**Critérios de segurança:** só leitor mestre em ambiente privado, sem incluir bancos, IDs/atores reais ou hashes individualizados de `row_json` em GitHub Pages, JS distribuído ou arquivos Party. Autenticidade provém da cadeia de custódia ZIP e hash de fonte confiável, não somente de `row_sha` autorreferencial. O visualizador deve confirmar dados para display sem serializar informações brutas não autorizadas. Projeção de Party futura requer autenticação e autorização no servidor, **não CSS**. Ausência de mapa e XY físicos mantém a movimentação automática 2D em HOLD.

### D-INOV-20261022-014 — P1 | Timeline VLAB privada read-only

**Destinatário:** Desenvolvedor e Coordenador 1. **Dependências:** fonte autorizada R205, ZIP autenticado e ambiente Mestre-only. **Proposta:** adaptador local privado de SQLite eventos para timeline textual sintética de prova; identificar `commit_seq` + subevent index, preservar `source.kind=VLAB_R205_LAB_TEST` apenas na cópia privada realmente autenticada, campos ausentes como null/UNKNOWN e nenhuma geometria. **Aceite:** falsificação/hash incorreto bloqueia, IDs compostos não colidem, ordem de commit estável, eventos desconhecidos exibidos como desconhecidos, nenhuma alteração no VLAB nem publicação de payload Mestre. **Estado:** POC independente entregue, **não** integrado no TEST15 ou site público.

## 6. Multiplayer (P2) — somente contratos futuros

`authoritative state -> validated commands -> canonical event log -> client-specific projections -> incremental sync` é a arquitetura PROPOSTA. Desde agora, evitar anexar `MESTRE_ONLY` a estruturas enviadas ao cliente Party; prever `sceneRevision`, IDs estáveis, origem e projeções de permissão. Não se desenvolveu servidor, Bluetooth nem WebRTC nesta execução. GitHub Pages permanece competência exclusiva Mestre/Coordenador 1, nenhuma ação feita.

## 7. Gate de encerramento / checkpoint

**PASS experimental limitado:** 14/20 casos adversariais **desejados** passaram; 6/20 falharam **na baseline TEST15** — portanto o **gate de correção de salvamento e replay segue FAIL/HOLD**, embora a bancada tenha executado corretamente. FOV 272/272 invariantes + 13/13 propriedades + 17.297 verificações direcionais sem contraexemplo; timeline 14/14. Comparativos JS e Android headless NÃO certificam hardware Android. **NAC-PASS-02 proporcional: documentação/pesquisa PASS condicionado ao readback Notion; promoção/integração PROD HOLD.** Sem ACK do Desenvolvedor, nenhuma nova versão assumida.

**FIRST PENDING:** quando RUN-006/TEST16 existir, recuperar ZIP final + SHA e rodar `test_storage_replay_004.py` intacto/adaptado apenas para entrada, exigir eliminar 6 FAIL **sem quebrar validação legítima e TEST03**, reabrir fonte pertinente; em paralelo instrumentar Shadowcasting no Android físico e formalizar política de canto. Depois timeline VLAB privada com fonte autenticada e prova de origem/segredo. Ponto de retomada: este relatório + `MATRIZ_TEST15_004.json`, `BENCH_FOV_JAVASCRIPT_004.json`, `TIMELINE_R205_004_RESULTS.json` e scripts correspondentes. Zero escrita fora do Laboratório do Inovador.

---

## 8. ADENDO DE CONTINUIDADE — RUN-006 SURGIU DURANTE A PESQUISA

**FATO NOVO VERIFICADO por reabertura do Notion:** após a bateria de baseline TEST15 e antes da conclusão documental, o Desenvolvedor registrou **RUN-006 / TEST16–19** na mesma sala. Sua implementação posterior supersede a baseline TEST15 apenas nos campos modificados; histórico e os 6 FAILs TEST15 permanecem como evidência do ANTES, **não como bugs atualmente presentes**.

**Recuperação física independente:** `PACOTE_TECNICO_TABLETOP_TEST16_A_TEST19_20261022.zip` da Biblioteca existente, 4.014.146 bytes, SHA256 **`cf113d247b88e72327f6586204e9d42f56990b5813a36a31cd51f7cc585e3bc9`**, 37 entradas, CRC PASS. Distribuição TEST18 somente sintética `TABLETOP_SITE_SINTETICO_TEST18.zip`, 18.873 bytes, SHA256 **`02590273486fd8160869954b21e7e1bf9fad95cb6cc8d96a9db834e7d090993c`**, três arquivos, CRC PASS. Pacote privado TEST19 foi documentado no RUN-006 mas **não distribuído nem inspecionado nesta pesquisa**; não inclui seus bytes em nenhum artefato PESQ004.

**Mudanças de código REALMENTE inspecionadas no TEST18:** `app.js:49–70 persistChecked/restoreCandidate`, `validateScene:33–46`, `validateReplay:219–226`, `symmetricShadowcast:131–153`. O código atual faz `setItem` e releitura antes da troca do workspace; valida `frameTopology` e proíbe frame em parede; exige monotonicidade de IDs numéricos `frame-N` / `ev-N` (ou sequence explícita), preservando IDs legados arbitrários na ordem declarada. O FOV Symmetric já existe e tem cache por cena/parede/origem/raio. **Não apresentar nenhuma dessas funcionalidades novamente como lacuna ou implementação pendente.**

### Reexecução incremental da MATRIZ PESQ004 no TEST18

**20 casos de comportamento desejado, ambiente idêntico de Chromium com storage injetado: 19 PASS / 1 FAIL / 0 erros instrumentais.** Matriz física `MATRIZ_TEST18_004.json`. Comparado aos 20 casos baseline (14 PASS / 6 FAIL), foram corrigidos os casos `QuotaExceededError`, `SecurityError` no setter/getter, topologia divergente e replay numérico regressivo. O único FAIL que permaneceu foi **backup obsoleto contendo 1 cena sobre 2 cenas mais recentes**: a importação foi confirmada pelo usuário no teste e substituiu corretamente o workspace, mas não expôs conflito/revisão prévia. Isso é uma **oportunidade de aviso/backup e concorrência**, não corrupção silenciosa provada — prioridade P1, sem bloquear TEST18 no escopo sintético.

**Novos testes incrementais 3/3 PASS:** (1) fixture legada TEST03 aceita pelo validador TEST18; (2) importação visualiza 4 quadros e preserva workspace; (3) backup TEST15 v1 sem campos novos migra adequadamente para `explored=[]`, `fovEnabled=false`, `fovRadius=8`. Fonte: `COMPAT_TEST03_TEST15_RUN006_004.json`.

**Cross-check FOV contra o produto mais novo:** a implementação Symmetric da PESQ004 foi comparada **diretamente** com `__tabletopTEST.shadowcast` do TEST18 em 10 cenários sintéticos × 3 raios (4, 8, 12): **30/30 conjuntos de casas visíveis idênticos**, sem alterar o produto; prova diferencial independente, não nova implementação requerida. Fonte `FOV_COMPARE_TEST18_004.json`. Benchmarks JS da pesquisa continuam válidos como comparação sintética, mas não são benchmarks da engine TEST18 no Chrome Android físico.

**UX TEST18 reavaliado** em 360×740 e 390×844: zero overflow horizontal observado, grade 7² e 20² renderizada, botões da toolbar móvel de 43 px de altura. Melhorar conforto tátil para ≥44 px continua opcional e não classificado como bug. Fonte `AUDITORIA_MOBILE_TEST18_004.json`.

### Falha parcial nova, mais sutil — adversarial P1/P0 sob falha extraordinária

No `persistChecked` TEST18, **sob injeção sintética de `getItem` que passa ANTES da escrita mas lança `SecurityError` depois de um `setItem` bem-sucedido e durante o rollback**, a função rejeita a restauração e mantém o workspace antigo em memória, mas o armazenamento contém o candidato novo. Quando o acesso de leitura volta, o candidato reaparece da store. **Reproduzido somente por fault injection controlada, não no Android real.** Evidência: `TEST18_PARTIAL_STORAGE_READBACK_004.json`, script `test_storage_partial_readback_004.py`. Limite de engenharia: se o próprio storage nega leitura e rollback, não é possível garantir rollback atômico; distinguir `falha com estado conhecido` de `persistência indeterminada`, orientar recarga/reconciliação antes de novas alterações e preservar o backup exportado. Isso não invalida as correções normais do TEST18.

### DESPACHO D-INOV-20261022-015 — P1 (novo, pós-RUN-006)

**Destinatário:** Desenvolvedor e Coordenador 1; **versão:** TEST18/RUN-006. **Problema:** falha persistente de releitura depois de `setItem` pode deixar disco/RAM divergentes mesmo com restore rejeitado; import de backup obsoleto confirmado não diferencia substituição de alterações recentes. **Evidência:** `test_storage_partial_readback_004.py`, `MATRIZ_TEST18_004.json`, `app.js:49–70,248`. **Proposta:** um estado de persistência `UNKNOWN_AFTER_WRITE` quando a reconciliação falhar, recomendação de exportar antes de reabrir/reconciliar, bloqueio de mensagens de sucesso e proteção contra sobrescritas cegas até ler armazenamento de novo; caso de backup antigo, aviso contextual com contagem de cenas e possibilidade de cancelar/exportar. **Aceite:** sem sucesso falso, sem descarte automático de trabalho em RAM, estado indeterminado identificado, restauro confirmado após releitura íntegra, e testes em Chrome Android físico. **Estado:** proposta, não patch aplicado; técnica concreta de resiliência não representa garantia de atomicidade sem acesso à store.

### DESPACHO D-INOV-20261022-016 — P1 (novo, pós-RUN-006)

**Destinatário:** Desenvolvedor e Coordenador 1; **versão:** TEST18/RUN-006. **Problema:** FOV implementado precisa de auditoria geométrica/adversarial e física, não de reinvenção de algoritmo. **Evidência:** `30/30` acordos diretos produto vs módulo independente, `17.297` pares piso↔piso, diferenças entre Recursive/Symmetric por canto, `13/13` testes adicionais. **Recomendação:** manter Symmetric no TEST18, acrescentar fixtures de cantos exteriores, portas estreitas e raio variável; instrumentar cache com alteração de paredes e mudança de cena; conferir no Chrome Android real com reprodução offline HTTPS sob coordenação. Sem trocar por Recursive por microbenchmark de Linux. **Aceite:** invariantes geométricos, mudança de topologia invalida cache, exploração por cena é preservada e nenhum dado privado é incluído no site público. **Estado:** recomendação após evidência, sem alteração de código.

### Gate atualizado pós-RUN-006

- PESQ004 baseline TEST15: 20 testes / 14 PASS, 6 FAIL. Histórico material **não vigente para campos corrigidos**.
- PESQ004 RUN-006/TEST18: 20 testes / 19 PASS, 1 ressalva de conflito de backup. Compatibilidade TEST03/TEST15 **3/3 PASS**. Concordância FOV com TEST18 **30/30 PASS**. Robustez sob falha impossível de reconciliar pela store: **risco demonstrado por injeção**, não caso Chrome Android confirmado.
- FOV standalone: 272/272 invariantes + 13/13 propriedades + 17.297 comparações de direção sem contraexemplo. Timeline em leitor PESQ: 14/14 testes PASS em fixture e uma base real R205, sem exportar evento real. Nenhum desses denominadores equivale a homologação do RPG, FOV canônico ou segurança multiplayer.
- **FIRST PENDING pós-RUN006:** avaliar GET-after-SET storage loss no TEST20+ com mensagens de estado indeterminado, usar Android físico para FOV/backup com prova, auditar sincronização de abas reais sob origem HTTPS, comparar cache do TEST18 em mudanças de paredes, e observar novos RUNs para não duplicar entrega. Hospedagem continua exclusiva Mestre/Coordenador.

## 9. ADENDO 004-A — Verificação de downgrade de contrato na mistura de IDs de replay

**Descoberta física adicional na baseline TEST18/RUN006 (Chromium com JSON sintético, script `test_run006_mixed_ids_004.py`):** `validateReplay()` usa `numericIds = events.every(id => /^(frame|ev)-\\d+$/.test(id))`. A validação de monotonicidade só acontece se **TODOS** os IDs forem numéricos do padrão. Uma única entrada arbitrária desativa essa verificação para a sequência inteira. Os resultados observados foram:

| Teste sintético | `validateReplay` |
| --- | --- |
| `frame-001,frame-002` | true |
| `frame-002,frame-001` | false |
| `frame-002,custom-case-x,frame-001` | **true** |
| `legacy-x,legacy-y` | true, conforme compatibilidade intencional |
| `frame-001,frame-001` | false |
| `custom-1 seq=2,custom-2 seq=1` | false |

**Interpretação limitada:** não se observou corrupção de cena ou elevação de privilégio; existe uma **mudança silenciosa de semântica** ao misturar os dois sistemas de IDs. O produto declara suporte legado a IDs arbitrários com ordem por índice, portanto a mistura pode ser válida se essa for a política explícita. O risco é permitir que um documento que aparenta seguir IDs ordenados efetivamente entre no modo legado. **P1, requer decisão do Desenvolvedor sobre contrato e migração**, não impor regra universal sem inspeção do replay TEST03.

**Despacho D-INOV-20261022-017 — P1, contrato de replay misto:** manter o suporte a replays integralmente legados e `sequence` explícita; definir regra independente do input para formatos mistos (rejeitar mistura com aviso, ou declarar explicitamente a ordem pelo índice no schema V1); testar casos acima, além do fixture TEST03 e duplicatas. Aceite: a escolha é deliberada, documentada e verificada pelo próprio Desenvolvedor; nenhum replay legado válido descartado arbitrariamente. **Estado:** PROPOSTO, sem ACK.
