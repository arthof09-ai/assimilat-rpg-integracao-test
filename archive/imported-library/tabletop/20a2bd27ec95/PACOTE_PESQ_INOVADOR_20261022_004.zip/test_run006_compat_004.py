import json,re,zipfile
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent;R=P/'run006/public';O=P/'evidence';O.mkdir(exist_ok=True)
with zipfile.ZipFile(P/'new_run006/PACOTE_TECNICO_TABLETOP_TEST16_A_TEST19_20261022.zip') as z:
 oldbackup=json.loads(z.read('baseline_test15/index.html').decode()) if False else json.loads(z.read('evidence/backup_390.json'))
 legacy=json.loads(z.read('tests/fixtures/legacy_test03.json'))
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text());css=(R/'styles.css').read_text();js=(R/'app.js').read_text()
checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);pg=b.new_page();pg.set_content(html);pg.add_style_tag(content=css)
 pg.evaluate('''()=>{window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return window.__store[k]??null},setItem(k,v){window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}})}''');pg.add_script_tag(content=js)
 # package evidence/backup_390 might be generated from TEST18; inspect before tests
 print('BACKUP shape',oldbackup.get('version'),[(x.get('fovEnabled','MISSING'),len(x.get('explored',[]))) for x in oldbackup['scenes']])
 valid_legacy=pg.evaluate('obj=>__tabletopTEST.validateReplay(obj)',legacy);checks.append({'name':'TEST03 replay fixture validation','pass':valid_legacy})
 initial=pg.evaluate('__tabletopTEST.state()')
 pg.locator('#replayImport').set_input_files({'name':'legacy.json','mimeType':'application/json','buffer':json.dumps(legacy).encode()});pg.wait_for_timeout(120)
 observed=pg.evaluate('''()=>({count:document.querySelector('#replayCounter').textContent,source:__tabletopTEST.state().scenes.length,last:document.querySelector('#message').textContent})''')
 checks.append({'name':'TEST03 imported view only','pass':observed['count'].endswith('/4') and pg.evaluate('__tabletopTEST.state()')==initial,'detail':observed})
 # TEST15 v1 restore fixture generate by removing FOV fields from current valid source
 source=pg.evaluate('__tabletopTEST.state()')
 for scene in source['scenes']:
  for k in ('explored','fovEnabled','fovRadius'):scene.pop(k,None)
 source['scenes'][0]['name']='TEST15_LEGACY_MIGRATION'
 res=pg.evaluate('''w=>{try{__tabletopTEST.restoreCandidate(w);return {error:null,state:__tabletopTEST.state()}}catch(e){return {error:String(e)}}}''',source)
 migrated=res.get('state',{}).get('scenes',[{}])[0]
 checks.append({'name':'TEST15 v1 backup migrates to TEST18 fields','pass':res.get('error') is None and migrated.get('name')=='TEST15_LEGACY_MIGRATION' and migrated.get('fovEnabled') is False and migrated.get('fovRadius')==8 and migrated.get('explored')==[],'detail':{'error':res.get('error'),'fovEnabled':migrated.get('fovEnabled'),'fovRadius':migrated.get('fovRadius')}})
 b.close()
print('CHECKS',sum(x['pass'] for x in checks),'/',len(checks));O.joinpath('COMPAT_TEST03_TEST15_RUN006_004.json').write_text(json.dumps({'checks':checks},ensure_ascii=False,indent=2))
