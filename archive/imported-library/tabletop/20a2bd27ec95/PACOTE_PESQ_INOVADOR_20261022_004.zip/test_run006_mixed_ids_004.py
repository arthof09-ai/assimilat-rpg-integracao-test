"""TEST18 regression probe of mixed semantic event IDs, synthetic only."""
import re,json
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent;R=P/'run006/public';O=P/'evidence';O.mkdir(exist_ok=True)
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text());css=(R/'styles.css').read_text();js=(R/'app.js').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);pg=b.new_page();pg.set_content(html);pg.add_style_tag(content=css)
 pg.evaluate('''()=>{window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return window.__store[k]??null},setItem(k,v){window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}})}''');pg.add_script_tag(content=js)
 r=pg.evaluate('''()=>{
 const original=__tabletopTEST.makeReplay();
 const event=(id)=>({...structuredClone(original.events[0]),id});
 const normal={...structuredClone(original),events:[event('frame-001'),event('frame-002')]};
 const regression={...structuredClone(original),events:[event('frame-002'),event('frame-001')]};
 const mixed={...structuredClone(original),events:[event('frame-002'),event('custom-case-x'),event('frame-001')]};
 const legacy={...structuredClone(original),events:[event('legacy-x'),event('legacy-y')]};
 const duplicate={...structuredClone(original),events:[event('frame-001'),event('frame-001')]};
 const sequenced={...structuredClone(original),events:[{...event('custom-1'),sequence:2},{...event('custom-2'),sequence:1}]};
 return {normal:__tabletopTEST.validateReplay(normal),numeric_regression:__tabletopTEST.validateReplay(regression),mixed_regression:__tabletopTEST.validateReplay(mixed),legacy_ids:__tabletopTEST.validateReplay(legacy),duplicate:__tabletopTEST.validateReplay(duplicate),explicit_sequence_regression:__tabletopTEST.validateReplay(sequenced)};
 }''');b.close()
 (O/'REPLAY_TEST18_MIXED_IDS_004.json').write_text(json.dumps({'source':'RUN006 authenticated TEST18; Chromium UI + JS, synthetic inputs only','observed':r},indent=2))
 print(json.dumps(r,indent=2))
