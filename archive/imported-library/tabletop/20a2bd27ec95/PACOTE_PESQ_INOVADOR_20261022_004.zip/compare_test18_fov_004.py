"""Independent differential testing developer TEST18 versus isolated research FOV JS, synthetic only."""
import re,importlib.util,sys,json
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent;R=P/'run006/public';O=P/'evidence';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('fovprev','/mnt/data/inovador_pesq_pos15/fov_research.py');mod=importlib.util.module_from_spec(spec);sys.modules['fovprev']=mod;spec.loader.exec_module(mod)
fixtures=[]
for name,(walls,origin) in mod.scenes(20).items():
  if origin in walls:continue
  fixtures.append({'name':name,'walls':list(sorted(walls)),'origin':origin})
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>', '',(R/'index.html').read_text());js=(R/'app.js').read_text();css=(R/'styles.css').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);pg=b.new_page(viewport={'width':390,'height':844});pg.set_content(html);pg.add_style_tag(content=css)
 pg.evaluate('''()=>{window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return window.__store[k]??null},setItem(k,v){window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}})}''')
 pg.add_script_tag(content=js);pg.add_script_tag(content=(P/'fov_independent_004.js').read_text())
 r=pg.evaluate('''scenes=>{
 let findings=[];for(const f of scenes){const w=window.__tabletopTEST.state(),s=w.scenes[0];s.n=20;s.walls=f.walls.map(([x,y])=>x+','+y);s.danger=[];s.terrain={};s.frames=[];s.frameTopology=null;s.fovEnabled=false;s.explored=[];
 s.units[0].x=f.origin[0];s.units[0].y=f.origin[1];const blocked=new Set(s.walls);let index=0;
 for(let i=1;i<s.units.length;i++){while(blocked.has((index%20)+','+Math.floor(index/20))||(index%20===f.origin[0]&&Math.floor(index/20)===f.origin[1]))index++;s.units[i].x=index%20;s.units[i].y=Math.floor(index/20);index++;}
 window.__tabletopTEST.restoreCandidate(w);
 for(let radius of [4,8,12]){const actual=new Set(window.__tabletopTEST.shadowcast({x:f.origin[0],y:f.origin[1],radius}));const own=Pesq004FOV.symmetric({width:20,height:20,walls:f.walls},f.origin,radius);const onlyActual=[...actual].filter(x=>!own.has(x)),onlyOwn=[...own].filter(x=>!actual.has(x));findings.push({scenario:f.name,radius,actual:actual.size,independent:own.size,only_actual:onlyActual.length,only_independent:onlyOwn.length,samples:[...onlyActual.slice(0,3),...onlyOwn.slice(0,3)]});}
 }return findings;}''',fixtures)
 b.close()
obj={'baseline':'TEST18 source from authenticated RUN006 ZIP cf113d247b88e72327f6586204e9d42f56990b5813a36a31cd51f7cc585e3bc9','experiments':r,'equal':sum(x['only_actual']==0 and x['only_independent']==0 for x in r),'total':len(r)}
(O/'FOV_COMPARE_TEST18_004.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False))
print('EQUAL',obj['equal'],'/',obj['total']);print('DIFF', [x for x in r if x['only_actual'] or x['only_independent']][:8])
