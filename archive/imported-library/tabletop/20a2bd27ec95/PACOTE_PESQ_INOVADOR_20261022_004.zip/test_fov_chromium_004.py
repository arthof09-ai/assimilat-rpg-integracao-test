"""JavaScript FOV benchmark in actual Chromium JS engine via Playwright set_content.
Algorithms and 10 deterministic fixtures, synthetic research only; no game rules.
"""
import json,statistics,importlib.util
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent;O=P/'evidence';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('prior_fov','/mnt/data/inovador_pesq_pos15/fov_research.py');m=importlib.util.module_from_spec(spec);import sys;sys.modules['prior_fov']=m;spec.loader.exec_module(m)
maps=[]
for n in (20,30,50,70):
 for label,(wall,orig) in m.scenes(n).items():
  if orig in wall:continue
  maps.append({'name':label,'n':n,'map':{'width':n,'height':n,'walls':[list(x) for x in sorted(wall)]},'origin':list(orig),'radius':{20:8,30:12,50:18,70:24}[n]})
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);pg=b.new_page(viewport={'width':390,'height':844});pg.set_content('<!doctype html><html><body>FOV TEST ONLY</body></html>');pg.add_script_tag(content=(P/'fov_independent_004.js').read_text());
 bench=pg.evaluate('''async specs=>{
 const algorithms=['recursive','symmetric'];const samples=[];let checks=[];let failureExamples=[];
 const percent=(a,p)=>a[Math.max(0,Math.ceil(p*a.length)-1)];
 for(let item of specs){const n=item.n,r=item.radius,g=item.map,o=item.origin;
   const vis={};for(let method of algorithms){const fn=Pesq004FOV[method];const warm=fn(g,o,r);vis[method]=warm;let times=[];for(let rep=0;rep<31;rep++){const t0=performance.now(),out=fn(g,o,r);let dt=performance.now()-t0;times.push(dt);if(out.size!==warm.size)failureExamples.push('non-determinism '+item.name+' '+method);}
   const sorted=[...times].sort((a,b)=>a-b);samples.push({algorithm:method,scenario:item.name,size:n,radius:r,count:times.length,median_ms:percent(sorted,.5),p95_ms:percent(sorted,.95),visible_count:warm.size});
   const origKey=o.join(',');checks.push({kind:'origin',pass:warm.has(origKey),scenario:item.name,algo:method});
   checks.push({kind:'inbounds',pass:[...warm].every(k=>{let [x,y]=k.split(',').map(Number);return x>=0&&y>=0&&x<n&&y<n}),scenario:item.name,algo:method});
   checks.push({kind:'radius',pass:[...warm].every(k=>{let [x,y]=k.split(',').map(Number);return (x-o[0])**2+(y-o[1])**2<=r*r}),scenario:item.name,algo:method});
  }
  const diff1=[...vis.symmetric].filter(x=>!vis.recursive.has(x));const diff2=[...vis.recursive].filter(x=>!vis.symmetric.has(x));
  if(diff1.length||diff2.length)failureExamples.push({kind:'semantic_difference_expected_not_a_bug',scenario:item.name,n,symmetric_only:diff1.length,recursive_only:diff2.length});
  const [x,y]=o, changed=g.walls.filter(([a,b])=>a!==x+1||b!==y);if(changed.length===g.walls.length&&x+1<n){changed.push([x+1,y]);const newMap={...g,walls:changed};const after=Pesq004FOV.symmetric(newMap,o,r);checks.push({kind:'invalidate_wall_change',scenario:item.name,algo:'symmetric',pass:!after.has((x+2)+','+y)||[...after].length<g.width*g.height});}
 }
 // floor-to-floor symmetric test: for selected viewpoints and bounded 7x7 region, avoiding wall origins.
 let comparisons=0,violations=[];for(const item of specs.filter(s=>s.n===20).slice(0,10)){
 const g=item.map,r=item.radius,walls=new Set(g.walls.map(p=>p.join(',')));const [cx,cy]=item.origin;
 const floors=[];for(let y=Math.max(0,cy-3);y<Math.min(g.height,cy+4);y++)for(let x=Math.max(0,cx-3);x<Math.min(g.width,cx+4);x++)if(!walls.has(x+','+y))floors.push([x,y]);
 const cache=new Map(floors.map(a=>[a.join(','),Pesq004FOV.symmetric(g,a,r)]));
 for(let a of floors)for(let b of floors){if((a[0]-b[0])**2+(a[1]-b[1])**2>r*r)continue;const ab=cache.get(a.join(',')).has(b.join(',')),ba=cache.get(b.join(',')).has(a.join(','));comparisons++;if(ab!==ba&&violations.length<30)violations.push({scene:item.name,a,b,ab,ba});}
 }
 return {engine:navigator.userAgent,bench:samples,checks,semantic_differences:failureExamples,symmetric_floor_pairs:{comparisons,violations}};
 }''',maps)
 b.close()
summary={'fixture_count':len(maps),'browser':bench['engine'],'executions_per_case':31,'benchmarks':bench['bench'],'checks':{'total':len(bench['checks']),'passed':sum(x['pass'] for x in bench['checks']),'failed':[x for x in bench['checks'] if not x['pass']]},'symmetric_floor_pairs':bench['symmetric_floor_pairs'],'differences':bench['semantic_differences']}
O.joinpath('BENCH_FOV_JAVASCRIPT_004.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
print('BROWSER:',bench['engine']);print('FIXTURES',len(maps),'INVARIANTS',summary['checks']['passed'],'/',summary['checks']['total'],'SYMMETRIC_PAIRS',summary['symmetric_floor_pairs']['comparisons'],'VIOLATIONS',len(summary['symmetric_floor_pairs']['violations']))
for n in (20,30,50,70):
 for alg in ('recursive','symmetric'):
  x=[z['median_ms'] for z in summary['benchmarks'] if z['size']==n and z['algorithm']==alg]
  print(n,alg,'median of medians ms',round(statistics.median(x),4),'max scenario',round(max(x),4))
print('SEMANTIC_DIFF_EXAMPLES',summary['differences'][:6])
