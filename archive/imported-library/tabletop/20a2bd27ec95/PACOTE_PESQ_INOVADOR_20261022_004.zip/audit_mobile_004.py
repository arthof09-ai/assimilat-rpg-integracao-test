"""Mobile design audit on actual TEST15 DOM in headless Chromium, NOT physical Android."""
import re,json,statistics
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).parent;R=P/'baseline/public'; O=P/'evidence';O.mkdir(exist_ok=True)
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text());style=(R/'styles.css').read_text();js=(R/'app.js').read_text()
out=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);
 for width,height in [(360,740),(390,844)]:
  pg=b.new_page(viewport={'width':width,'height':height},is_mobile=True,has_touch=True,device_scale_factor=2);pg.set_content(html);pg.add_style_tag(content=style);pg.evaluate('''()=>{window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__store[k]??null,setItem:(k,v)=>window.__store[k]=v}})}''');pg.add_script_tag(content=js)
  pg.wait_for_function('!!window.__tabletopTEST');v=pg.evaluate('''()=>{
 const arr=[...document.querySelectorAll('.btn,.filelabel,.unitBtn,.eventList button')].filter(el=>{let r=el.getBoundingClientRect();return r.width&&r.height});
 const small=arr.map(el=>({label:el.textContent.trim().slice(0,26),width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height})).filter(x=>x.width<44||x.height<44);
 return {count:arr.length,small,bodyOverflow:document.documentElement.scrollWidth>innerWidth,viewportTouchAction:getComputedStyle(document.querySelector('#viewport')).touchAction,
      sceneCount:window.__tabletopTEST.state().scenes.length,boardCellCount:document.querySelectorAll('#board .tile').length};
 }''')
  pg.evaluate('__tabletopTEST.resize(20)');v['20x20']=pg.evaluate('''()=>({cells:document.querySelectorAll('#board .tile').length,scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth})''');out.append({'viewport':f'{width}x{height}','observed':v});pg.close()
 b.close()
O.joinpath('AUDITORIA_MOBILE_CHROMIUM_004.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
for x in out:print(x['viewport'],{k:v for k,v in x['observed'].items() if k!='small'},'small targets:',x['observed']['small'][:12])
