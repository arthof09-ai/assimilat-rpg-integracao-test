import io,json,hashlib,sqlite3,tempfile,zipfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from timeline_r205_contract_004 import ingest_sqlite,TimelineError,digest
root=Path(__file__).parent;zpath=Path('/mnt/data/inovador_pesq_pos15/vlab_readonly/VLAB_R205_DEFESA_DE_VENTO_ANEL_CLASSIFICADO_MESTRE_ONLY.zip')
expected='62a9851b3a5ae7919b9225d9379a3d32c8736448e76bfcea4729dcbfe933cead'
checks=[]
def check(name,passed,detail=None):checks.append({'name':name,'pass':bool(passed),'detail':detail});print(('PASS' if passed else 'FAIL'),name,detail)
def build(rows):
 c=sqlite3.connect(':memory:');c.execute('create table meta(k text primary key,v text)');c.execute('create table pending(k text)');c.execute('create table events(seq integer primary key,cmd_id text unique,prev text,row_json text,row_sha text,before_sha text,after_sha text)')
 prev='0'*64
 for seq in range(1,rows+1):
  doc={'seq':seq,'cmd_id':f'SYNTH-{seq}','prev':prev,'before_sha':'a'*64,'after_sha':'b'*64,'payload':{'actor':'DUMMY'},'detail':{'kind':'SYNTH_TEST','new_native_events':[{'seq':seq,'action':'ACTION_SYNTH','by':'ACTOR_SYNTH'}]}}
  raw=json.dumps(doc,sort_keys=True,separators=(',',':'));sha=digest(raw.encode());c.execute('insert into events values(?,?,?,?,?,?,?)',(seq,doc['cmd_id'],prev,raw,sha,doc['before_sha'],doc['after_sha']));prev=sha
 c.commit();result=c.serialize();c.close();return result
ok=build(3);a=ingest_sqlite(ok,'SYNTH');check('três commits sintéticos e três eventos',a['commit_count']==3 and a['event_count']==3)
check('chave composta com banco e sequência',len({e['event_key'] for e in a['events']})==3)
check('nenhuma posição inventada',all(e['confirmed_coords'] is None for e in a['events']))
check('não interpreta o sintético como VLAB real',all(e['provenance']['db']=='SYNTH' for e in a['events']))
for name,blob in [('truncated',ok[:60]),('not SQLite',b'not SQLite')]:
 try:ingest_sqlite(blob);passed=False
 except (TimelineError,sqlite3.Error):passed=True
 check('rejeita '+name,passed)
# Tamper database rows with SQLite controlled and reserialize
for field,value in [('row_json','{}'),('prev','ffff'),('seq',8),('cmd_id','CORRUPTED-ID')]:
 c=sqlite3.connect(':memory:');c.deserialize(ok);
 # destructive fixtures then modify first other row / no valid chain
 if field=='seq':c.execute('update events set seq=8 where seq=3')
 elif field=='cmd_id':
  try:c.execute('update events set cmd_id=? where seq=3',(value,))
  except sqlite3.IntegrityError:pass
 else:c.execute('update events set '+field+'=? where seq=3',(value,))
 c.commit();blob=c.serialize();c.close()
 try:ingest_sqlite(blob);passed=False
 except (TimelineError,sqlite3.Error,ValueError):passed=True
 check('rejeita corrupção '+field,passed)
# ZIP R205 real physical proof only: read ONE database, no writes, no actual sensitive events output.
sha=hashlib.sha256(zpath.read_bytes()).hexdigest();check('ZIP R205 SHA autenticado',sha==expected)
with zipfile.ZipFile(zpath) as z:
 dbs=[n for n in z.namelist() if n.startswith('new/r205/evidence/db/') and n.endswith('.sqlite')]
 check('20 bases físicas no pacote',len(dbs)==20)
 if dbs:
  physical=ingest_sqlite(z.read(dbs[0]),root_id='R205_PRIVATE_CASE_0')
  check('base real lida com hash+cadeia válidos',physical['commit_count']>0 and physical['event_count']>0,{'commits':physical['commit_count'],'events':physical['event_count']})
  check('sem conversão real em XY',all(x['confirmed_coords'] is None for x in physical['events']))
# Serialized output ONLY coarse research stats, no raw records.
summary={'zip_sha':sha,'source_private':'R205 ZIP only, read in-memory; not attached','checks':checks,'totals':{'pass':sum(x['pass'] for x in checks),'total':len(checks)},'synthetic_fixture':{'origin':'SYNTHETIC_FIXTURE','events':a['events']}}
(root/'evidence'/'TIMELINE_R205_004_RESULTS.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
print('SUMMARY',summary['totals'])
