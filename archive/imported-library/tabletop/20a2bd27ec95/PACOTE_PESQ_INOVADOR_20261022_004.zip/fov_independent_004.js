/* PESQ004: independent TEST algorithm research, no RPG mechanics; CC0-style geometric approach
 * adapted from Albert Ford specification (https://www.albertford.com/shadowcasting/).
 * Floor origin only; diagonal/corner policy uncanonized. All sets of 'x,y'.
 */
(function(root){'use strict';
const key=(x,y)=>x+','+y;
function validateMap(g,origin,r){if(!Number.isInteger(g.width)||!Number.isInteger(g.height)||g.width<1||g.height<1||!Array.isArray(g.walls)||!Number.isInteger(origin[0])||!Number.isInteger(origin[1])||origin[0]<0||origin[1]<0||origin[0]>=g.width||origin[1]>=g.height||!Number.isInteger(r)||r<0||r>200)throw Error('invalid FOV inputs');}
function recursive(g,origin,r){validateMap(g,origin,r);const walls=new Set(g.walls.map(p=>key(...p)));const inside=(x,y)=>x>=0&&x<g.width&&y>=0&&y<g.height;const shown=new Set([key(...origin)]);const transforms=[[1,0,0,1],[0,1,1,0],[0,-1,1,0],[-1,0,0,1],[-1,0,0,-1],[0,-1,-1,0],[0,1,-1,0],[1,0,0,-1]];
function cast(row,start,end,xx,xy,yx,yy){if(start<end||row>r)return;let blocked=false,newstart=start;for(let dist=row;dist<=r;dist++){let dx=-dist-1,dy=-dist;while(dx<0){dx++;let x=origin[0]+dx*xx+dy*xy,y=origin[1]+dx*yx+dy*yy;let left=(dx-0.5)/(dy+0.5),right=(dx+0.5)/(dy-0.5);if(start<right)continue;if(end>left)break;const ok=inside(x,y),wall=!ok||walls.has(key(x,y));if(ok&&(x-origin[0])**2+(y-origin[1])**2<=r*r)shown.add(key(x,y));if(blocked){if(wall){newstart=right;continue;}blocked=false;start=newstart;}else if(wall&&dist<r){blocked=true;cast(dist+1,start,left,xx,xy,yx,yy);newstart=right;}}if(blocked)break;}}for(const t of transforms)cast(1,1,0,...t);return shown;}
function symmetric(g,origin,r){validateMap(g,origin,r);const walls=new Set(g.walls.map(p=>key(...p)));const inside=(x,y)=>x>=0&&x<g.width&&y>=0&&y<g.height;const shown=new Set([key(...origin)]);
 const frac=(a,b)=>{if(b<=0)throw Error('slope denominator');return {a,b}},value=(s)=>s.a/s.b;
 function pos(card,depth,col){switch(card){case 0:return [origin[0]+col,origin[1]-depth];case 1:return [origin[0]+col,origin[1]+depth];case 2:return [origin[0]+depth,origin[1]+col];default:return [origin[0]-depth,origin[1]+col];}}
 function scan(card,row){if(row.depth>r)return;const lo=Math.floor(row.depth*value(row.start)+0.5),hi=Math.ceil(row.depth*value(row.end)-0.5);let was=null;for(let col=lo;col<=hi;col++){const [x,y]=pos(card,row.depth,col),within=inside(x,y),wall=!within||walls.has(key(x,y));let floorSym=(col*row.start.b>=row.depth*row.start.a&&col*row.end.b<=row.depth*row.end.a);if(within&&(x-origin[0])**2+(y-origin[1])**2<=r*r&&(wall||floorSym))shown.add(key(x,y));if(was===true&&!wall)row.start=frac(2*col-1,2*row.depth);if(was===false&&wall)scan(card,{depth:row.depth+1,start:row.start,end:frac(2*col-1,2*row.depth)});was=wall;}if(was===false)scan(card,{depth:row.depth+1,start:row.start,end:row.end});}
 for(let card=0;card<4;card++)scan(card,{depth:1,start:frac(-1,1),end:frac(1,1)});return shown;}
const explored=(prev,now)=>new Set([...prev,...now]);
root.Pesq004FOV={recursive,symmetric,explored};
})(typeof window==='undefined'?globalThis:window);
