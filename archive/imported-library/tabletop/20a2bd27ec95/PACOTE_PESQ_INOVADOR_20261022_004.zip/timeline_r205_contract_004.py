"""PESQ004 RESEARCH-ONLY read adapter. Input: authenticated private SQLite DB bytes.
No public export of R205, no XY inference, no official VLAB execution. Strict fail closed.
Proposed presentation events: synthetic fixtures only for tests. DB kept in memory.
"""
import hashlib,json,sqlite3,tempfile,os
from dataclasses import dataclass

def digest(b):return hashlib.sha256(b).hexdigest()

class TimelineError(ValueError):pass

def validate_row(row, prev=None):
    # (seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha)
    seq,cmd_id,prevsha,source,rowsha,before,after=row
    if not isinstance(seq,int) or seq<=0 or not isinstance(cmd_id,str) or not cmd_id:raise TimelineError('invalid seq/cmd_id')
    if not isinstance(source,str) or digest(source.encode('utf-8'))!=rowsha:raise TimelineError('row SHA mismatch')
    doc=json.loads(source)
    if not isinstance(doc,dict) or any(doc.get(k)!=v for k,v in [('seq',seq),('cmd_id',cmd_id),('prev',prevsha),('before_sha',before),('after_sha',after)]):raise TimelineError('row columns/JSON differ')
    if prev is not None and prevsha!=prev:raise TimelineError('chain predecessor mismatch')
    if not isinstance(doc.get('payload'),dict) or not isinstance(doc.get('detail'),dict):raise TimelineError('missing source payload/detail')
    return doc

def ingest_sqlite(db_bytes,root_id='RESEARCH-PRIVATE'):
    if not db_bytes.startswith(b'SQLite format 3\x00'):raise TimelineError('not sqlite')
    tmp=tempfile.NamedTemporaryFile(prefix='pesq004_private_sqlite_',suffix='.db',delete=False);tmp.write(db_bytes);tmp.close()
    db=sqlite3.connect('file:'+tmp.name+'?mode=ro&immutable=1',uri=True)
    try:
        tables={r[0] for r in db.execute('select name from sqlite_master where type="table"')};
        if not {'events','meta','pending'}.issubset(tables):raise TimelineError('schema mismatch')
        columns=[r[1] for r in db.execute('PRAGMA table_info(events)')];want=['seq','cmd_id','prev','row_json','row_sha','before_sha','after_sha'];
        if columns!=want:raise TimelineError('events schema mismatch')
        rows=db.execute('select seq,cmd_id,prev,row_json,row_sha,before_sha,after_sha from events order by seq').fetchall()
        if len(rows)>100000:raise TimelineError('too many rows')
        out=[];previous=None;ids=set()
        for idx,row in enumerate(rows,1):
            doc=validate_row(row,previous)
            if row[0]!=idx:raise TimelineError('noncontinuous commit seq')
            if row[1] in ids:raise TimelineError('repeated command id')
            ids.add(row[1]);previous=row[4]
            detail=doc['detail'];payload=doc['payload']
            for origin_field in ('new_native_events','events_added'):
                nested=detail.get(origin_field,[])
                if not isinstance(nested,list):raise TimelineError('nested events must be array')
                for j,e in enumerate(nested):
                    if not isinstance(e,dict):raise TimelineError('event must be object')
                    action=e.get('action')
                    if not isinstance(action,str):action='UNKNOWN'
                    # Emit private normalized event in memory only. Coordinates NEVER inferred.
                    out.append({'event_key':f'{root_id}:{idx}:{origin_field}:{j}',
                                'commit_seq':idx,'kind':action,'actor':e.get('by') if isinstance(e.get('by'),str) else None,
                                'target':e.get('target') if isinstance(e.get('target'),str) else None,
                                'action':action,'source_field':origin_field,'source_seq':e.get('seq'),
                                'confirmed_coords':None,'has_grid':False,
                                'provenance':{'db':root_id,'row_sha':row[4],'commit_id':row[1]}})
            # commit itself remains visible as a scoped event if there are no nested events
            if not detail.get('new_native_events') and not detail.get('events_added'):
                out.append({'event_key':f'{root_id}:{idx}:commit:0','commit_seq':idx,
                    'kind':str(detail.get('kind') or doc.get('kind') or 'UNKNOWN'),
                    'actor':payload.get('actor') if isinstance(payload.get('actor'),str) else None,
                    'target':payload.get('target') if isinstance(payload.get('target'),str) else None,
                    'action':None,'confirmed_coords':None,'has_grid':False,
                    'provenance':{'db':root_id,'row_sha':row[4],'commit_id':row[1]}})
        return {'commit_count':len(rows),'event_count':len(out),'events':out}
    finally:
        db.close()
        os.unlink(tmp.name)

# This file never writes any actual R205 event to disk; only structural counts/field names should be released.
