'use strict';const assert=require('node:assert/strict'),{classifyReplay,compareBackup,ruler}=require('./contratos_interacao_005');let cases=[];
function run(name,fn){try{fn();cases.push({name,status:'PASS'})}catch(e){cases.push({name,status:'FAIL',error:String(e)})}}
const ev=(id,sequence)=>Object.assign({id},sequence===undefined?{}:{sequence});const legacy=es=>({schemaVersion:1,events:es});
run('v1 numeric ascending accepted',()=>assert.equal(classifyReplay(legacy([ev('frame-001'),ev('frame-003')])).ok,true));
run('v1 numeric regressive rejected',()=>assert.equal(classifyReplay(legacy([ev('frame-002'),ev('frame-001')])).reason,'REGRESSIVE_NUMERIC_IDS'));
run('v1 arbitrary legacy indexed',()=>assert.equal(classifyReplay(legacy([ev('legacy-x'),ev('legacy-y')])).order,'ARRAY_INDEX_LEGACY'));
run('v1 mixed IDs explicitly warning',()=>assert.equal(classifyReplay(legacy([ev('frame-002'),ev('misc-x'),ev('frame-001')])).warning,'IDS_ARBITRARY_OR_MIXED_NO_TEMPORAL_AUTHORITY'));
run('v2 numeric mixed with increasing seq accepted',()=>assert.equal(classifyReplay({schemaVersion:2,events:[ev('frame-002',10),ev('misc-x',15),ev('frame-001',20)]}).ok,true));
run('v2 missing sequence fail closed',()=>assert.equal(classifyReplay({schemaVersion:2,events:[ev('misc-a',1),ev('misc-b')]}).ok,false));
run('v2 duplicate sequence rejected',()=>assert.equal(classifyReplay({schemaVersion:2,events:[ev('misc-a',1),ev('misc-b',1)]}).reason,'REGRESSIVE_SEQUENCE'));
run('v2 gaps allowed',()=>assert.equal(classifyReplay({schemaVersion:2,events:[ev('custom-1',1),ev('custom-2',6)]}).ok,true));
run('duplicate IDs always rejected',()=>assert.equal(classifyReplay(legacy([ev('id-x'),ev('id-x')])).ok,false));
run('preview detects scene removed, not age',()=>{let x=compareBackup({scenes:[{id:'c1',a:1},{id:'c2',a:2}]},{scenes:[{id:'c1',a:1}]});assert.deepEqual(x.removedIds,['c2']);assert.equal(x.neverGuessFreshness,true)});
run('preview same IDs but content diff',()=>{let x=compareBackup({scenes:[{id:'c1',n:1}]},{scenes:[{id:'c1',n:2}]});assert.deepEqual(x.changedSameId,['c1'])});
run('preview refuses duplicate scenes',()=>assert.throws(()=>compareBackup({scenes:[{id:'x'},{id:'x'}]},{scenes:[{id:'x'}]})));
run('ruler 20-grid independent noncanonical',()=>{let r=ruler({n:20,from:{x:1,y:2},to:{x:4,y:6}});assert.equal(r.manhattanCells,7);assert.equal(r.straightLineCells,5);assert.equal(r.nonCanonical,true)});
run('ruler out of grid rejected',()=>assert.throws(()=>ruler({n:7,from:{x:1,y:2},to:{x:10,y:2}})));
const out={scope:'Pure research contracts only; no canonical mechanics or developer code changed',cases,pass:cases.filter(x=>x.status==='PASS').length,total:cases.length};require('node:fs').writeFileSync(__dirname+'/CONTRATOS_INTERACAO_TESTES_005.json',JSON.stringify(out,null,2));console.log('SUMMARY',out.pass,'/',out.total);if(out.pass!==out.total)process.exitCode=1;
