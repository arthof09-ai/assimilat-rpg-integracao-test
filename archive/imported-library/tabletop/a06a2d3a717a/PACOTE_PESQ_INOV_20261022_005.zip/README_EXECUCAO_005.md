# Reproduzir PESQ-INOV-20261022-005 (laboratório isolado, R$0)

**Não copiar o código do Desenvolvedor para o pacote de pesquisa.** Use arquivos autorizados já existentes na Biblioteca do projeto. Não incluir dados reais VLAB no Github, site público, Party ou artefatos compartilháveis.

## Pré-requisitos da bancada de pesquisa (não do Android do Mestre)
- Python 3.11+, `playwright` e um Chromium já instalado (scripts usam `/usr/bin/chromium` no ambiente de origem), Node.js 18+.
- Extrair **somente** `TABLETOP_SITE_SINTETICO_TEST18.zip` da Library, SHA256 `02590273486fd8160869954b21e7e1bf9fad95cb6cc8d96a9db834e7d090993c`, para uma pasta privada de trabalho com `app.js`, `index.html`, `styles.css`.
- Definir variável `TABLETOP_PUBLIC_SOURCE=/pasta/da/copia` para executar os três testes do app. O pacote PESQ005 não contém os três arquivos.
- Para a auditoria do leitor privado, obter apenas com autorização `TIMELINE_VLAB_R205_MESTRE_ONLY_TEST19.html` do pacote privado original SHA `83789339278890aca456b2504af805228402d172da8628400b720227ca3bb6f2` e definir `VLAB_TEST19_VIEWER=/pasta/privada/...html`. **Não distribuir JSON de eventos real.** A suíte usa fixture sintética criada em memória.

## Execução das suítes

```bash
export TABLETOP_PUBLIC_SOURCE=/CAMINHO/DA/COPIA/TEST18
python audit_005_browser.py
python fov_cache_and_recovery_005.py
python benchmark_ui_test18_005.py
node test_poc_reconciliacao_005.js
node test_poc_topologia_005.js
node test_contratos_interacao_005.js
export VLAB_TEST19_VIEWER=/CAMINHO/PRIVADO/TIMELINE_VLAB_R205_MESTRE_ONLY_TEST19.html
python audit_private_timeline_contract_005.py
```

Os navegadores não usam o site público nem criam deploys; o HTML é montado no Chromium `set_content`. A CSP do site real é retirada **somente da cópia em memória da bancada**, para permitir injeção de `localStorage` TEST. Não interpretar resultados como uma verificação da CSP publicada ou de armazenamento real em Android.

## Evidência e limites
- Arquivos `*.json` presentes são resultados agregados ou objetos totalmente sintéticos de pesquisa. Não contêm payloads reais R205.
- `AUDITORIA_BROWSER_005.json` contém **13/13 observações PASS**, incluindo comportamentos indesejados reproduzidos. Não equivale a 13 PASS do produto.
- O teste com duas abas na mesma origem não pôde ser executado porque o Chromium retornou `ERR_BLOCKED_BY_ADMINISTRATOR` na tentativa de navegar a origem interceptada. **Nenhum teste multiaba real é alegado.**
- O RUN007 TEST20–23 foi confirmado no Notion durante a pesquisa, mas seus arquivos não foram recuperados: os resultados de código executável permanecem associados ao TEST18/RUN006.
- Testes Node correspondem a **POCs de engenharia independentes**, não mudança oficialmente integrada.
