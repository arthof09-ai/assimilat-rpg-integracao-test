'use strict';
const assert=require('node:assert/strict'),{createGuard}=require('./poc_reconciliacao_005');
let cases=[];function check(name,fn){try{fn();cases.push({name,result:'PASS'})}catch(e){cases.push({name,result:'FAIL',error:String(e)})}}
function store(){let values={};let fault='',writes=0;return {getItem(k){if(fault==='read'||fault==='read_after_write'&&writes>0)throw new Error('InjectedRead');return values[k]??null},setItem(k,v){if(fault==='throw_before')throw new Error('InjectedWrite');writes++;values[k]=v;},raw(k){return values[k]},force(k,v){values[k]=v},fault(v){fault=v},reset(){fault=''}}}
const KEY='tabletop.synthetic';
check('confirmed readback',()=>{const s=store(),g=createGuard(s,KEY);assert.equal(g.attempt({n:1}).phase,'CONFIRMED')});
check('write throw no claim success',()=>{const s=store(),g=createGuard(s,KEY);s.fault('throw_before');assert.notEqual(g.attempt({n:1}).phase,'CONFIRMED')});
check('unknown post-write lock',()=>{const s=store(),g=createGuard(s,KEY);s.fault('read_after_write');assert.equal(g.attempt({n:1}).phase,'UNKNOWN_AFTER_WRITE');assert.match(g.attempt({n:2}).message,/BLOQUEADO/);assert.equal(JSON.parse(s.raw(KEY)).n,1)});
check('recover candidate readback',()=>{const s=store(),g=createGuard(s,KEY);s.fault('read_after_write');g.attempt({n:1});s.reset();assert.equal(g.reconcile().phase,'CONFIRMED_AFTER_RECONCILIATION')});
check('recover previous when write not persisted',()=>{const s=store(),g=createGuard(s,KEY);s.force(KEY,JSON.stringify({n:0}));s.fault('throw_before');g.attempt({n:1});s.reset();assert.equal(g.reconcile().phase,'FAILED_CONFIRMED')});
check('detect newer external version during reconciliation',()=>{const s=store(),g=createGuard(s,KEY);s.fault('read_after_write');g.attempt({n:1});s.reset();s.force(KEY,JSON.stringify({n:7}));assert.equal(g.reconcile().phase,'CONFLICT')});
check('block conflict writes',()=>{const s=store(),g=createGuard(s,KEY);g.externalChange();assert.equal(g.attempt({n:2}).phase,'CONFLICT')});
check('reject malformed candidate',()=>{const s=store(),g=createGuard(s,KEY,x=>x?.schema==='v1');assert.equal(g.attempt({schema:'v2'}).phase,'REJECTED')});
let result={kind:'POC test only; no deployed application and no actual Android storage',cases,summary:{total:cases.length,pass:cases.filter(x=>x.result==='PASS').length,fail:cases.filter(x=>x.result==='FAIL').length}};
require('node:fs').writeFileSync(__dirname+'/POC_RECONCILIACAO_TESTES_005.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result.summary));if(result.summary.fail)process.exitCode=1;
