/* PESQ-INOV-005 — Propostas independentes, não código do Desenvolvedor. No game rules.
 * Replay v1 legacy preserved by explicit classifier; v2 requires sequence.
 * Backup preview compares known IDs only; does NOT claim temporal freshness.
 * Visual ruler measures cell geometry, not RPG official movement or reach.
 */
'use strict';
const forbid=new Set(['__proto__','prototype','constructor']);
function classifyReplay(replay){
 if(!replay||!Array.isArray(replay.events)||replay.events.length===0)return {ok:false,reason:'NO_EVENTS'};
 if(replay.events.length>100)return {ok:false,reason:'TOO_MANY_EVENTS'};
 const ids=new Set(); let countSeq=0;
 for(const e of replay.events){if(!e||typeof e.id!=='string'||!e.id||ids.has(e.id)||forbid.has(e.id))return {ok:false,reason:'BAD_OR_DUPLICATE_ID'};ids.add(e.id);if(Object.hasOwn(e,'sequence')){if(!Number.isSafeInteger(e.sequence)||e.sequence<0)return {ok:false,reason:'BAD_SEQUENCE'};countSeq++}}
 if(countSeq!==0&&countSeq!==replay.events.length)return {ok:false,reason:'PARTIAL_SEQUENCE'};
 if(replay.schemaVersion===2){if(countSeq!==replay.events.length)return {ok:false,reason:'V2_REQUIRES_SEQUENCE'}}
 if(countSeq===replay.events.length){for(let i=1;i<replay.events.length;i++){if(replay.events[i].sequence<=replay.events[i-1].sequence)return {ok:false,reason:'REGRESSIVE_SEQUENCE'}}return {ok:true,order:'EXPLICIT_SEQUENCE',warning:null}}
 const numeric=replay.events.map(e=>/^(frame|ev)-(\d+)$/.exec(e.id));
 if(numeric.every(Boolean)){
  let prefix=numeric[0][1],prev=-1;
  for(const m of numeric){const n=Number(m[2]);if(!Number.isSafeInteger(n)||n<=prev||m[1]!==prefix)return {ok:false,reason:'REGRESSIVE_NUMERIC_IDS'};prev=n}
  return {ok:true,order:'NUMERIC_IDS_LEGACY',warning:null};
 }
 // Historically allowed by TEST18, preserve v1 order but indicate explicitly in UI.
 return {ok:true,order:'ARRAY_INDEX_LEGACY',warning:'IDS_ARBITRARY_OR_MIXED_NO_TEMPORAL_AUTHORITY'};
}
function compareBackup(current,incoming){
 if(!current||!incoming||!Array.isArray(current.scenes)||!Array.isArray(incoming.scenes))throw Error('Invalid backup preview');
 const cur=new Map(current.scenes.map(s=>[s.id,s])),inc=new Map(incoming.scenes.map(s=>[s.id,s]));
 if(cur.size!==current.scenes.length||inc.size!==incoming.scenes.length)throw Error('Duplicate scene id');
 const removed=[...cur.keys()].filter(x=>!inc.has(x)),added=[...inc.keys()].filter(x=>!cur.has(x));
 const same=[...cur.keys()].filter(x=>inc.has(x));
 const potentiallyChanged=same.filter(id=>JSON.stringify(cur.get(id))!==JSON.stringify(inc.get(id)));
 return {currentCount:cur.size,backupCount:inc.size,removedIds:removed,addedIds:added,changedSameId:potentiallyChanged,neverGuessFreshness:true};
}
function ruler({n,from,to}){
 if(!Number.isInteger(n)||n<1||n>50||![from,to].every(p=>p&&Number.isInteger(p.x)&&Number.isInteger(p.y)&&p.x>=0&&p.y>=0&&p.x<n&&p.y<n))throw Error('Outside synthetic grid');
 const dx=to.x-from.x,dy=to.y-from.y;return {from,to,manhattanCells:Math.abs(dx)+Math.abs(dy),straightLineCells:Math.hypot(dx,dy),nonCanonical:true};
}
module.exports={classifyReplay,compareBackup,ruler};
