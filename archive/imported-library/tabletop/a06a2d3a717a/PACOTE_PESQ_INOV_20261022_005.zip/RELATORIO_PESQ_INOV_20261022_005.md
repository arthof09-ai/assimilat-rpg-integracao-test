# PESQ-INOV-20261022-005 — Engenharia preventiva do Tabletop Assimilação

**22/10/2026 • Terceiro Comestre Inovador/Pesquisador • MESTRE-SIDE/TEST • R$0 • NÃO CANÔNICO**  
**Destino:** Laboratório do Inovador existente, coordenação do Mestre/CM-000001.  
**Autoria:** somente scripts, POCs e relatório desta pesquisa; nada escrito nos códigos do Desenvolvedor, VLAB, Party, O Primeiro, GitHub ou outros labs.

## 1. Baseline e mudança de fronteira (NAC-CONT-03)

- **ANTES:** RUN-006/TEST18-19 último físico na Biblioteca; pacote técnico TEST16–19 SHA-256 `cf113d247b88e72327f6586204e9d42f56990b5813a36a31cd51f7cc585e3bc9` (4.014.146 bytes), público TEST18 SHA `02590273486fd8160869954b21e7e1bf9fad95cb6cc8d96a9db834e7d090993c` (18.873 bytes), privado R205 TEST19 SHA `83789339278890aca456b2504af805228402d172da8628400b720227ca3bb6f2` (225.145 bytes); **os três ZIPs foram materializados/rehashados nesta pesquisa; CRC PASS**. `public/app.js` TEST18 SHA `664f543c785fa346e0d0e230b5e88b520532fe32951fc08a47a6bc29cce861d9`.
- **MUDANÇA DURANTE A PESQUISA:** Notion passou a registrar **RUN-007 TEST20–23**. Executor relata TEST20 persistência UNKNOWN, TEST21 prévia de backup e escolha exportar/substituir, TEST22 IDs mistos com sequência obrigatória + FOV cache, TEST23 timeline privada. Regressão integral **423/423 é HISTÓRICO RELATADO** do Desenvolvedor, NÃO teste desta pesquisa. O pacote RUN-007 final registrado é `PACOTE_TECNICO_TABLETOP_TEST20_A_TEST23_20261022.zip`, SHA `02187d4ad5cf211982c5882ae963c2d2ce712334e525955982f183e506dc7ba9`; público TEST22 SHA `8b53f137b06434f4340788cacc99ad017eddfec7e15d517b8401e681798bbf89`; privado TEST23 SHA `6551817551f061cae5334b19a17fd57ea80a590f8aa8f1d8780ce4f0700e8750`. **Os três não estavam localizáveis nos arquivos acessíveis desta pesquisa** (Library RUN007 upload documentou `container_session_expired`, Projects/Files e `/mnt/data` sem esses bytes). Portanto **ÚLTIMA BASELINE FISICAMENTE AUDITADA: TEST18/RUN006**; RUN007 é a versão documental mais nova, mas sua correção não foi validada por este Pesquisador. Não presumir defeito de RUN006 reproduzido em RUN007.
- RUN007 documenta que a hospedagem já tem demonstração visual Android TEST18 via prints; isso é evidência do Desenvolvedor/Coordenação, **não** teste físico de interações executado pelo Pesquisador. A hospedagem pertence exclusivamente à Coordenação/Mestre.

## 2. ONDA A — novas descobertas reais de confiabilidade

### Achado A1: BUG DE TOPOLOGIA após apagar/substituir parede (P0)

**VERIFICADO no código físico TEST18**: `app.js`, `clickCell()`, linhas 101–120. Apenas modo `wall` invalida `frames=[]; frameTopology=null` (linha 119). Os modos `erase`, `danger` e `terrain` também **podem remover uma parede**, mas não invalidam a assinatura dos frames. Teste com `#record` depois de erguer uma parede em `2,1`, seguido de uma dessas três edições na mesma casa: **3/3 reproduções do defeito**; `__tabletopTEST.validateWorkspace()` retorna `false`; status real `NÃO SALVO: Estado TEST inválido • exporte backup` e o botão Backup não gera arquivo (**1/1 ensaio**). `undo` recupera estado válido (**1/1**), mas não justifica tratar o erro como inofensivo. Evidência: `AUDITORIA_BROWSER_005.json`, `FOV_CACHE_RECOVERY_005.json`, captura PNG.

**Proposta**: comparar `topology(scene)` antes/depois de **qualquer** transição de terreno, e, se mudou, aplicar a invalidação **já existente** aos quadros. Não limpar frames por mudança apenas cosmética de terreno/perigo quando paredes e IDs permanecerem iguais. Guard autoral `poc_topologia_005.js` + **5/5 tests PASS**, nunca aplicado ao produto. **Aceite:** 3 transições + backup + reload + replay TEST03/regressão normal sem perda de histórico quando a topologia não mudou. **Primeiro gate:** verificar se a correção já existe no ZIP RUN007 quando disponível.

### Achado A2: resultado indeterminado e reentrada após falha de releitura (P0 para TEST18; RUN007 não verificado)

`persistChecked()` `app.js` linhas 49–63; `restoreCandidate()` 65–71. Injeção de Storage TEST: `setItem` grava candidato; `getItem` falha depois e durante rollback. Observado: RAM antiga, armazenamento candidato novo, sem transição explícita UNKNOWN no TEST18. Quando leitura retorna, divergência persiste; clique posterior `+Cena` sobrescreve o candidato anterior. Também foram testados `QuotaExceededError` antes de escrita, `getItem` transitório com rollback e recuperação posterior. **5 observações PASS do próprio ensaio** documentam comportamento, NÃO cinco casos de aceite do aplicativo. `poc_reconciliacao_005.js` e `test_poc_reconciliacao_005.js`: máquina de estados mínima autoral **8/8 PASS**, não promete transações reais nem elimina corrida interabas.

**PROPOSTO**: estados `READY`, `CONFIRMED`, `FAILED_CONFIRMED`, `UNKNOWN_AFTER_WRITE`, `CONFLICT`; bloquear substituições destrutivas sob UNKNOWN; ao recuperar leitura, confrontar armazenamento com candidato e anterior, validar versão e exigir reconciliação. **RUN007 relata TEST20 implementado**, por isso a entrega principal é a suíte de auditoria pronta; **não reapresentar como funcionalidade ausente** na versão documental atual.

### Achado A3: backup antigo, decisão e informação (P1 para TEST18; RUN007 relata solução)

No TEST18, backup de **uma cena substituiu duas cenas** após diálogo genérico `Substituir suas cenas locais...`; cancelar preservou tudo. **2 observações PASS** de reprodução/proteção. O contrato de dados não traz `modified_at` confiável e comparar IDs não prova frescor temporal. `compareBackup(current, incoming)` prova independente mostra contagem 2→1, IDs removidos/novos/alterados, sem classificar arbitrariamente como mais velho. RUN007 documenta diálogo TEST21 com opção Exportar atual/Cancelar/Substituir, **sem readback físico nesta pesquisa**. Próxima etapa auditar acessibilidade, foco, Escape, estado sem perdas e recuperação no ZIP RUN007.

### Achado A4: IDs mistos de replay; contrato formal (P1 para TEST18; RUN007 relata solução)

A função `validateReplay()` TEST18 linhas 219–227 aceita `frame-002, custom-x, frame-001` sem `sequence` apesar de rejeitar `frame-002, frame-001` isolados. **Caracterização real de 8 entradas** no navegador, incluindo sequências explícitas crescentes/regressivas. Não derivar tempo de uma string de ID. POC pura `contratos_interacao_005.js` adota proposta de migração: **v1** preserva IDs legados arbitrários por ordem de array, mas identifica modo `ARRAY_INDEX_LEGACY`/aviso para mistos; **v2** exige sequência explícita em todos os eventos, estritamente crescente, permitindo saltos. Duplicatas e sequência parcial rejeitadas. POC de comparação de backups e régua visual completam **14/14 testes de contrato PASS**. RUN007 relata TEST22 com mistura exigindo `sequence`; confirmar fisicamente no futuro.

## 3. ONDA B — FOV, UX e desempenho reais

- **FOV TEST18 dinâmico:** `currentFov` calcula chave com cena/origem/raio/paredes ordenadas. 6 verificações de navegador PASS: parede→undo→redo, raio 4→12 em 20², duplicação de cena sem alterar origem, histórico explorado recuperado em reabertura simulada, undo saindo de topologia inválida, backup indisponível quando estado inválido. Na amostra, cache e separação de cenas **PASS**; **não recomendo substituir Symmetric Shadowcasting**. Esses PASS não certificam cantos, diagonal ou política canônica de visibilidade.
- **Benchmark do código real TEST18 (Chromium/Linux headless, 390×844, 12 aquecimentos e 75 amostras por condição):** 7²/3 tokens/1 cena mediana `1,0 ms`, p95 `1,4 ms`; 20²/3 tokens `1,5 / 2,4`; 20²/30 tokens `3,0 / 4,3`; 20²/30 tokens/8 cenas `2,9 / 4,4`. São tempos internos de `render()`, não latência de toque nem Android físico. Valores variaram moderadamente na segunda execução; não prometer desempenho estável em aparelho modesto. Oito cenas sintéticas ocuparam ~28 KB de JSON neste cenário, muito abaixo dos limites escolhidos, sem comprovação de durabilidade do storage.
- **Acessibilidade/usabilidade:** usar prévia de backup com duas linhas e ações claras; não exigir formulário grande. `Page Visibility API` permite pausar reprodução ao ocultar a página; não confiar em `unload` para garantir save. `storage` event avisa **outras abas da mesma origem** e não substitui concorrência/locking. [MDN Web Storage](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API), [storage event](https://developer.mozilla.org/en-US/docs/Web/API/Window/storage_event), [visibilitychange](https://developer.mozilla.org/en-US/docs/Web/API/Document/visibilitychange_event), [persist](https://developer.mozilla.org/en-US/docs/Web/API/StorageManager/persist). 
- **Nova capacidade prioritária P2:** régua geométrica TEST sem mutação de jogo, resposta `manhattanCells` e `straightLineCells` para dois pontos de grade, com alerta explícito “não é cálculo oficial de deslocamento/alcance”. Código isolado e testes (parte dos 14/14). Em Android, preferir dois toques em células com botão limpar, sem conflitar com pan/pinça. Não substituir movimentação BFS existente.
- **Multiplayer preventivo:** nenhuma implementação nem backend. Para futuro, servidor autoritativo por sessão, evento/versão, filtro de campo Mestre/Party **antes da transmissão**, estratégia explícita para reconnect e concorrência. POC não simula permissão canônica.

## 4. ONDA C — auditoria do visualizador privado VLAB TEST19

**Fonte local privada autenticamente recuperada:** `PACOTE_PRIVADO_VLAB_R205_TIMELINE_TEST19_MESTRE_ONLY.zip`, SHA `83789339278890aca456b2504af805228402d172da8628400b720227ca3bb6f2`. `TIMELINE_VLAB_R205_MESTRE_ONLY_TEST19.html`, função `validate(d)` examinada. **10/10 mutações sintéticas observadas conforme previstas**: rejeita `seq` repetido, `prevHash` divergente, `rowHash` malformado, `command` duplicado e `chainValid:false`, e aceita tipo desconhecido para fallback. **Três lacunas de proveniência observadas por injeção sintética:** (1) `source.sha256` 64 hex arbitrários passa, (2) hash de linha arbitrário com `prev` correspondente passa, (3) `summary.innerEventsTotal` fictício passa. Isso é compatível com o README do Desenvolvedor: **o visualizador não autentica criptograficamente os bancos**; não declarar “bug de segurança explorado” sem autoridade/ameaça. Ele valida estrutura e continuidade textual, não digest de `row_json` original que não está no payload do visualizador.

**Recomendação:** manter a proveniência ancorada em pacote privado autenticado fora do navegador; na interface rotular `origem declarada/formatos verificados`, sem afirmar prova criptográfica local. Conferir resumo de eventos deriváveis do payload; se realmente necessário, acrescentar manifesto SHA256 confiável verificado fora de banda. **RUN007 relata TEST23 melhorias de IDs/fallback**, não demonstrou verificação criptográfica; auditar a implementação nova apenas quando bytes forem recuperados. **Nenhum evento privado ou SQLite é exportado neste pacote PESQ005.**

## 5. Despachos ao Desenvolvedor/Coordenador (sem ACK)

**D-INOV-20261022-018 — P0 / BUG topológico** — Baseline física RUN006 TEST18. Evidência `clickCell` L103–120, 3 edições de parede reproduzidas e backup bloqueado. Propor invalidar replay sempre que `topology` mudar; teste 3 modos + arquivo + reload + legado. RUN007 status físico **NÃO VERIFICADO**. Destinatário Desenvolvedor, Coordenação recebe ciência.

**D-INOV-20261022-019 — P0 / UNKNOWN e reentrada** — Baseline TEST18; 5 cenários navegador + POC 8/8. Tratar estado UNKNOWN_AFTER_WRITE sem falso rollback/sucesso, bloquear writes até conciliação. RUN007 **IMPLEMENTADO SEGUNDO RELATO** TEST20, auditoria independente do binário HOLD. Destinatário Desenvolvedor.

**D-INOV-20261022-020 — P1 / BACKUP preview** — Baseline TEST18; 2→1 cenas e cancelamento verificados. Contar/remover IDs, apresentar exportação atual, não inventar timestamp ou merge. RUN007 **IMPLEMENTADO SEGUNDO RELATO** TEST21, físico HOLD. Destinatário Desenvolvedor.

**D-INOV-20261022-021 — P1 / REPLAY IDs mistos** — Baseline TEST18; mistura rebaixa proteção dos IDs, prova v1/v2 com 14/14 testes combinados. Sequência explícita integral na versão moderna; preservar TEST03 e v1 índice. RUN007 **IMPLEMENTADO SEGUNDO RELATO** TEST22, físico HOLD. Destinatário Desenvolvedor.

**D-INOV-20261022-022 — P1 / FOV e Android + capacidade régua** — Baseline TEST18; cache 6/6 invariantes, render 75 amostras por configuração, prova de régua sem game rules. Não substituir algoritmo; testar hardware Android, visibilidadechange/pause e gestos, eventualmente overlay de medidas com controles de dois toques. Destinatário Desenvolvedor.

**D-INOV-20261022-023 — P1 / TIMELINE contratos** — Baseline física privada TEST19; 10/10 mutações, três falsificações semânticas aceitas. Separar estrutura de autenticação; proibir transpor JSON privado para GitHub Pages/Party; mostrar UNKNOWN e contadores apenas ancorados. RUN007 TEST23 novo código ainda não acessível para auditoria. Destinatário Desenvolvedor.

## 6. Ensaios e denominadores (nunca somar como contratos RPG)

| Conjunto | Resultado independente desta pesquisa | Interpretação |
|---|---:|---|
| Browser TEST18 (restauração/replay/defeitos) | 13/13 cenários observados | 3 novos testes reproduzem **falha do produto**, mas o teste passou ao capturá-la |
| Browser FOV/recovery | 6/6 observados | Inclui teste de backup indisponível (comportamento indesejado) |
| POC estado de persistência | 8/8 | Modelo PROPOSTO, não integrado |
| POC semântica replay + preview + régua | 14/14 | Modelo PROPOSTO, não integrado |
| POC proteção de topologia | 5/5 | Guarda PROPOSTO, não aplicado |
| Viewer timeline TEST19 | 10/10 mutações observadas | 3 padrões de falsificação aceitos: limites documentados |
| Render TEST18 | 4 configurações × 75 amostras | Métricas; **não** PASS de funcionalidade |
| Android real / duas abas com origem real | NOT RUN / HOLD | Tentativa de origem interceptada bloqueada `ERR_BLOCKED_BY_ADMINISTRATOR` |
| TEST20–23 nova fonte | NÃO VERIFICADO | RUN007 Notion disponível, ZIP da Library não encontrado |

**NAC-PASS-02:** PASS científico proporcional para scripts/fixtures/hashes/fatos de bancada TEST18 e viewer TEST19; **HOLD** para nova versão RUN007, Android físico, Party/multiplayer, integração canônica e publicação. Nenhuma escrita em outras OPs, código oficial ou repositório.

## 7. Primeiro ponto exato de retomada

1. **P0:** recuperar ZIPs RUN007 TEST20–23 da fonte legítima (Library quando upload persistir, ou anexo autorizado do Desenvolvedor); autenticar SHA e reexecutar **somente** os três modos de edição de parede/frames, estado UNKNOWN+reentrada, backup prévia/Cancel e IDs mistos. NÃO presumir que RUN007 contém o bug topológico de TEST18.
2. Validar integridade da timeline TEST23 em **cópia privada**, sem publicar eventos reais nem testar VLAB de novo.
3. FOV/visibilidade em Chrome Android físico e estudo de duas abas na origem HTTPS efetiva sob autorização da Coordenação, sem assumir a hospedagem.
4. Avaliar pequeno incremental de régua geométrica e botão de backup com erro compreensível; nunca canonizar regra de jogo.
