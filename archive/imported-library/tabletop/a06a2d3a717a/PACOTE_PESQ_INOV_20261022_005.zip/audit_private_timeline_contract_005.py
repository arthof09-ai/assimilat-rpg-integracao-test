"""TEST19 private timeline validator adversarial characterization. Fixtures built in memory,
never store real VLAB row/event data. This is NOT a parser of actual R205 data.
"""
import copy,json,hashlib,os
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(os.environ.get('PESQ005_WORKDIR',str(Path(__file__).resolve().parent.parent)));O=Path(__file__).resolve().parent;HTML=Path(os.environ.get('VLAB_TEST19_VIEWER',str(R/'private/TIMELINE_VLAB_R205_MESTRE_ONLY_TEST19.html'))).read_text()
# This spoofed test envelope is intentionally synthetic. Viewer requires isSynthetic false.
# NEVER distribute the resulting fake envelope as a VLAB event.
H=lambda x: x*64
E=lambda n,cmd,prev,rh:{'seq':n,'command':cmd,'kind':'DUMMY_RESEARCH','detailKind':None,'actor':None,'target':None,'action':None,'nextTurn':None,'attack':None,'resources':None,'nativeCount':0,'addedCount':0,'prevHash':prev,'rowHash':rh,'beforeSha':H('c'),'afterSha':H('d')}
def fixture():
 a=E(1,'synthetic-001',H('0'),H('a'));b=E(2,'synthetic-002',H('a'),H('b'))
 return {'schema':'assim.vlab.r205.timeline.private.v1','scope':'MESTRE_ONLY','isSynthetic':False,'source':{'name':'SYNTHETIC-VALIDATOR-TEST','sha256':H('f')},'summary':{'databases':1,'commits':2,'nativeEvents':0,'addedEvents':0,'innerEventsTotal':0,'attackRows':0},'cases':[{'id':'SYNTHETIC_CASE_01','commits':2,'chainValid':True,'events':[a,b]}]}
case=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);q=b.new_page();q.set_content(HTML);q.wait_for_function('!!window.__r205TEST')
 def check(n,change,expected,annotation):
  d=fixture();change(d);got=q.evaluate('d=>window.__r205TEST.validate(d)',d);case.append({'name':n,'accepted':bool(got),'expected_current':expected,'matches_current_behavior':bool(got)==expected,'classification':annotation});print(('PASS' if bool(got)==expected else 'FAIL'),n,got)
 check('synthetic valid-shaped envelope',lambda x:None,True,'format acceptance only, not authentic event')
 check('bad seq duplicate',lambda x:x['cases'][0]['events'][1].update(seq=1),False,'schema guard')
 check('prev mismatch',lambda x:x['cases'][0]['events'][1].update(prevHash=H('e')),False,'chain guard')
 check('row hash wrong length',lambda x:x['cases'][0]['events'][1].update(rowHash='xyz'),False,'shape guard')
 check('duplicate cmd',lambda x:x['cases'][0]['events'][1].update(command='synthetic-001'),False,'identity guard')
 check('source SHA spoof but valid hex',lambda x:x['source'].update(sha256=H('e')),True,'provenance NOT cryptographically validated in viewer')
 check('row SHA spoof with prev consistent',lambda x:(x['cases'][0]['events'][0].update(rowHash=H('e')),x['cases'][0]['events'][1].update(prevHash=H('e'))),True,'chain self-consistent yet arbitrary')
 check('summary innerEventsTotal spoof',lambda x:x['summary'].update(innerEventsTotal=999),True,'summary display count not crosschecked')
 check('event kind unknown',lambda x:x['cases'][0]['events'][0].update(kind='UNKNOWN_EXPERIMENTAL'),True,'forward compatibility fallback')
 check('case flag forged',lambda x:x['cases'][0].update(chainValid=False),False,'flag only, no independent proof')
 b.close()
r={'scope':'private viewer TEST19; entirely synthetic in-memory mutation probes; no actual R205 events disclosed','source_file':'TIMELINE_VLAB_R205_MESTRE_ONLY_TEST19.html, validate(d) inline','engine':'Chromium headless Linux','cases':case,'total':len(case),'matched':sum(x['matches_current_behavior'] for x in case)}
(O/'AUDITORIA_TIMELINE_CONTRATO_005.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print('SUMMARY',r['matched'],'/',r['total'])
