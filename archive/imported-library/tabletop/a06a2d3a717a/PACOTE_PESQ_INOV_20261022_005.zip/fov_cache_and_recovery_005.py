"""RUN006/TEST18 FOV and recovery dynamic, independent Playwright, synthetic-only.
No browser-origin/Android guarantees. No game rule engine execution.
"""
import json,re,hashlib,os
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(os.environ.get('TABLETOP_PUBLIC_SOURCE',str(Path(__file__).resolve().parent.parent/'baseline')));O=Path(__file__).resolve().parent;H=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','', (R/'index.html').read_text());JS=(R/'app.js').read_text();CSS=(R/'styles.css').read_text();data=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 def mk(seed=None):
  c=b.new_context(viewport={'width':390,'height':844},accept_downloads=True);q=c.new_page();q.set_content(H);q.add_style_tag(content=CSS)
  q.evaluate('''s=>{window.__store=s||{}; Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return window.__store[k]??null},setItem(k,v){window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}})}''',seed)
  q.add_script_tag(content=JS);return c,q
 def test(name,fn):
  try:
   result=fn();ok=result.pop('ok');data.append({'name':name,'outcome':'PASS' if ok else 'FAIL','observed':result});print(('PASS' if ok else 'FAIL'),name,str(result)[:120]);
  except Exception as e:data.append({'name':name,'outcome':'ERROR','observed':{'error':str(e)[:300]}});print('ERROR',name,str(e)[:250]);
 def fov_case():
  c,q=mk();q.locator('#layerFov').check();before=q.evaluate('__tabletopTEST.fovNow()');q.evaluate("__tabletopTEST.mode('wall');__tabletopTEST.cell(2,1)");on=q.evaluate('__tabletopTEST.fovNow()');q.locator('#undo').click();undo=q.evaluate('__tabletopTEST.fovNow()');q.locator('#redo').click();redo=q.evaluate('__tabletopTEST.fovNow()');c.close();return {'ok':before==undo and on==redo and before!=on,'lengths':[len(x) for x in [before,on,undo,redo]]}
 test('FOV parede -> undo -> redo invalida corretamente',fov_case)
 def radius_case():
  c,q=mk();q.locator('#gridSize').select_option('20');q.locator('#layerFov').check();q.locator('#fovRadius').select_option('4');a=q.evaluate('__tabletopTEST.fovNow()');q.locator('#fovRadius').select_option('12');z=q.evaluate('__tabletopTEST.fovNow()');c.close();return {'ok':len(z)>len(a) and set(a).issubset(z),'small':len(a),'large':len(z)}
 test('FOV raio 4->12 atualiza visibilidade',radius_case)
 def clone_explored():
  c,q=mk();q.locator('#layerFov').check();a=q.evaluate('__tabletopTEST.scene()');q.locator('#copyScene').click();b=q.evaluate('__tabletopTEST.scene()');q.evaluate("__tabletopTEST.mode('wall');__tabletopTEST.cell(2,1)");q.locator('#scenes').select_option(a['id']);aa=q.evaluate('__tabletopTEST.scene()');c.close();return {'ok':a['id']!=b['id'] and len(a['explored'])>0 and aa['id']==a['id'] and aa['walls']==a['walls'],'source_walls':len(aa['walls']),'copy_after_wall':1,'copied_explored':len(b['explored'])}
 test('FOV cena duplicada mantém independente origem',clone_explored)
 def reload_explored():
  c,q=mk();q.locator('#layerFov').check();a=q.evaluate('__tabletopTEST.scene()');raw=q.evaluate('window.__store');c.close();c2,q2=mk(raw);s=q2.evaluate('__tabletopTEST.scene()');c2.close();return {'ok':a['explored']==s['explored'] and s['fovEnabled'],'explored_before':len(a['explored']),'explored_after':len(s['explored'])}
 test('FOV explorado persiste em recarga simulada',reload_explored)
 def frames_save_undo():
  c,q=mk();q.evaluate("__tabletopTEST.mode('wall');__tabletopTEST.cell(2,1)");q.locator('#record').click();q.evaluate("__tabletopTEST.mode('erase');__tabletopTEST.cell(2,1)");bad=q.evaluate('__tabletopTEST.validateWorkspace(__tabletopTEST.state())');before=q.evaluate('__tabletopTEST.scene()');q.locator('#undo').click();good=q.evaluate('__tabletopTEST.validateWorkspace(__tabletopTEST.state())');status=q.locator('#storageStatus').inner_text();c.close();return {'ok':not bad and good and 'NÃO SALVO' not in status,'after_erase_walls':len(before['walls']),'recoverable_through_undo':good,'last_storage_status':status[:100]}
 test('Estado inválido após erase pode ser recuperado por undo',frames_save_undo)
 def no_backup_when_invalid():
  c,q=mk();q.evaluate("__tabletopTEST.mode('wall');__tabletopTEST.cell(2,1)");q.locator('#record').click();q.evaluate("__tabletopTEST.mode('erase');__tabletopTEST.cell(2,1)");downloads=[];q.on('download',lambda d:downloads.append(d.suggested_filename));q.locator('#backup').click();q.wait_for_timeout(100);valid=q.evaluate('__tabletopTEST.validateWorkspace(__tabletopTEST.state())');c.close();return {'ok':not valid and downloads==[],'backup_download_count':len(downloads),'valid':valid,'risk':'silent no-op when workspace invalid'}
 test('Backup manual torna-se indisponível em estado inválido',no_backup_when_invalid)
 b.close()
O.joinpath('FOV_CACHE_RECOVERY_005.json').write_text(json.dumps({'baseline':'TEST18 SHA256 '+hashlib.sha256(JS.encode()).hexdigest(),'environment':'Chromium/Linux set_content, mock localStorage, no Android hardware','results':data,'counts':{k:sum(x['outcome']==k for x in data) for k in ['PASS','FAIL','ERROR']}},ensure_ascii=False,indent=2));print('SUMMARY',len(data),[x['outcome'] for x in data])
