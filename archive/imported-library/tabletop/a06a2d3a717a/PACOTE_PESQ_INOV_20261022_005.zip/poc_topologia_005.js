/* PESQ005: pure proposed guard for future developer integration, NOT product patch.
 * This does not calculate RPG mechanics. Works on synthetic TEST scene objects.
 */
'use strict';
function topology(s){return JSON.stringify({n:s.n,walls:[...s.walls].sort(),ids:s.units.map(u=>u.id).sort()})}
function safeTerrainTransition(s,change){
 const before=topology(s),next=JSON.parse(JSON.stringify(s));change(next);
 const changed=topology(next)!==before;
 if(changed){next.frames=[];next.frameTopology=null;}
 return {next,topologyChanged:changed,framesInvalidated:changed};
}
module.exports={topology,safeTerrainTransition};
