"""TEST18 real render() benchmark in Chromium Linux, synthetic data, UI only.
Compare 7x7,20x20,30 units; 8 scenes optional. This is NOT Android hardware.
"""
import re,json,hashlib,statistics,os
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(os.environ.get('TABLETOP_PUBLIC_SOURCE',str(Path(__file__).resolve().parent.parent/'baseline')));O=Path(__file__).resolve().parent;H=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text());CSS=(R/'styles.css').read_text();JS=(R/'app.js').read_text();result=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);q=b.new_page(viewport={'width':390,'height':844});q.set_content(H);q.add_style_tag(content=CSS);q.evaluate('''()=>{window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return window.__store[k]??null},setItem(k,v){window.__store[k]=String(v)},removeItem(k){delete window.__store[k]}}})}''');q.add_script_tag(content=JS)
 def cfg(n,unitCount,scenes):
  return q.evaluate('''({n,unitCount,scenes})=>{const initial=__tabletopTEST.state(),s=initial.scenes[0];s.n=n;s.walls=[];s.danger=[];s.terrain={};s.explored=[];s.fovEnabled=true;s.fovRadius=8;s.frames=[];s.frameTopology=null;
   s.units=[];for(let i=0;i<unitCount;i++){s.units.push({id:'u'+(i+1),name:'Synthetic '+i,mark:'S',team:i%2?'enemy':'ally',x:i%n,y:Math.floor(i/n),range:1,hp:100,soul:40,pa:70})};s.selected='u1';s.notes='';s.logs=[];initial.scenes=[s];for(let j=2;j<=scenes;j++){let duplicate=JSON.parse(JSON.stringify(s));duplicate.id='c'+j;duplicate.name='CENA SINTÉTICA '+j;initial.scenes.push(duplicate)};
  __tabletopTEST.restoreCandidate(initial);let samples=[];for(let i=0;i<12;i++)__tabletopTEST.render();for(let i=0;i<75;i++){__tabletopTEST.render();samples.push(__tabletopTEST.lastRenderMs())} samples.sort((a,b)=>a-b);return {size:n+'x'+n,unitCount,scenes,measurements:samples.length,medianMs:samples[Math.floor(samples.length/2)],p95Ms:samples[Math.floor(samples.length*.95)],maxMs:samples.at(-1),payloadBytes:JSON.stringify(__tabletopTEST.state()).length,visibleFov:__tabletopTEST.fovNow().length,storageBytes:window.__store['assim.tabletop.synthetic.workspace.v1']?.length||0}}''',{'n':n,'unitCount':unitCount,'scenes':scenes})
 for n,k,c in [(7,3,1),(20,3,1),(20,30,1),(20,30,8)]:
  try:
   d=cfg(n,k,c);result.append(d);print('BENCH',d)
  except Exception as e:result.append({'size':n,'count':k,'scenes':c,'error':str(e)[:260]});print('ERROR',n,k,c,str(e)[:220])
 b.close()
O.joinpath('BENCH_UI_TEST18_005.json').write_text(json.dumps({'baseline':'TEST18 sha256 '+hashlib.sha256(JS.encode()).hexdigest(),'environment':'Chromium Linux headless, set_content, storage test double, 12 warmups + 75 samples per configuration, run same script to replicate','results':result},ensure_ascii=False,indent=2))
