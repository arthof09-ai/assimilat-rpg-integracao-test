/* PESQ-INOV-005 — POC AUTORAL DE MÁQUINA DE ESTADOS, NÃO PATCH TABLETOP.
 * R$0, local, sem rede, fixtures sintéticas. Não oferece transação ACID.
 * Interface: createGuard(storage, key, validate) -> attempt(candidate), reconcile(), state().
 */
'use strict';
function createGuard(storage, key, validate=(x)=>x&&typeof x==='object') {
 let phase='READY', previous=null, candidate=null, evidence=null, lastMessage='';
 const raw=(x)=>JSON.stringify(x);
 function setPhase(next,msg){phase=next;lastMessage=msg;return {phase,message:msg};}
 function attempt(value){
  if(phase==='UNKNOWN_AFTER_WRITE'||phase==='CONFLICT')return setPhase(phase,'BLOQUEADO: resolver armazenamento antes de novas substituições');
  if(!validate(value))return setPhase('REJECTED','Estado candidato inválido');
  let current;
  try{current=storage.getItem(key)}catch(e){return setPhase('FAILED_CONFIRMED','Não conseguiu ler antes da escrita; escrita não iniciada: '+e.name)}
  const desired=raw(value);
  previous=current;candidate=desired;evidence=null;
  try {storage.setItem(key,desired)}catch(e){return setPhase('UNKNOWN_AFTER_WRITE','Falha de setItem; resultado observado indeterminado até conferência: '+e.name)}
  try{
   if(storage.getItem(key)===desired){evidence='readback-match';return setPhase('CONFIRMED','Gravação confirmada por releitura')}
  }catch(e){return setPhase('UNKNOWN_AFTER_WRITE','Gravação executada, confirmação não obtida: '+e.name)}
  return setPhase('UNKNOWN_AFTER_WRITE','Gravação divergente; exigir reconciliação');
 }
 function reconcile(){
  if(phase!=='UNKNOWN_AFTER_WRITE'&&phase!=='CONFLICT')return setPhase(phase,'Sem conflito pendente');
  let got;
  try{got=storage.getItem(key)}catch(e){return setPhase('UNKNOWN_AFTER_WRITE','Leitura ainda indisponível: '+e.name)}
  if(got===candidate){evidence='candidate-readback';return setPhase('CONFIRMED_AFTER_RECONCILIATION','Candidato preservado; confirmar adoção visual após validação')}
  if(got===previous){evidence='previous-readback';return setPhase('FAILED_CONFIRMED','Estado anterior encontrado; candidato não persistido')}
  evidence='other-version';return setPhase('CONFLICT','Versão divergente; exportar antes de sobrescrever');
 }
 function externalChange(){if(phase==='READY'||phase==='CONFIRMED')setPhase('CONFLICT','Alteração em outra aba; recarregar/reconciliar antes de salvar');}
 return {attempt,reconcile,externalChange,state:()=>({phase,evidence,lastMessage,previous,candidate})};
}
module.exports={createGuard};
