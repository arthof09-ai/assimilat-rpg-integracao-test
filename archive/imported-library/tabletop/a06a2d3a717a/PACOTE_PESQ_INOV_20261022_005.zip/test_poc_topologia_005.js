'use strict';const assert=require('node:assert/strict'),{topology,safeTerrainTransition}=require('./poc_topologia_005');let results=[];
function test(name,fn){try{fn();results.push({name,result:'PASS'})}catch(e){results.push({name,result:'FAIL',error:String(e)})}}
function base(){const s={n:7,walls:['2,1'],units:[{id:'u1'},{id:'u2'}],frames:[{id:'f1'}],frameTopology:null,danger:[],terrain:{}};s.frameTopology=topology(s);return s}
test('erase wall clears stale frames',()=>{const x=safeTerrainTransition(base(),s=>s.walls=[]);assert.equal(x.topologyChanged,true);assert.equal(x.next.frames.length,0);assert.equal(x.next.frameTopology,null)});
test('danger over wall clears frames',()=>{const x=safeTerrainTransition(base(),s=>{s.walls=[];s.danger=['2,1']});assert.equal(x.next.frames.length,0)});
test('terrain over wall clears frames',()=>{const x=safeTerrainTransition(base(),s=>{s.walls=[];s.terrain['2,1']='grass'});assert.equal(x.next.frames.length,0)});
test('adding danger elsewhere retains frames',()=>{const x=safeTerrainTransition(base(),s=>s.danger.push('3,1'));assert.equal(x.framesInvalidated,false);assert.equal(x.next.frames.length,1)});
test('editing grass only retains frames',()=>{const x=safeTerrainTransition(base(),s=>s.terrain['3,1']='water');assert.equal(x.next.frames.length,1)});
const out={scope:'Synthetic independent guard; no Tabletop code modified',results,total:results.length,pass:results.filter(x=>x.result==='PASS').length};require('node:fs').writeFileSync(__dirname+'/POC_TOPOLOGIA_TESTES_005.json',JSON.stringify(out,null,2));console.log(out.pass+'/'+out.total);if(out.pass!==out.total)process.exitCode=1;
