"""PESQ-INOV-005 independent TEST18/run006 audit. No developer code writes.
Chromium UI code from authenticated public ZIP; storage injected in test context only.
"""
import json, re, hashlib, statistics, sys, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(os.environ.get('PESQ005_WORKDIR',str(Path(__file__).resolve().parent.parent))); R=Path(os.environ.get('TABLETOP_PUBLIC_SOURCE',str(ROOT/'baseline'))); O=Path(__file__).resolve().parent;O.mkdir(exist_ok=True)
HTML=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(R/'index.html').read_text());CSS=(R/'styles.css').read_text();JS=(R/'app.js').read_text()
KEY='assim.tabletop.synthetic.workspace.v1'
RESULT=[]
STORAGE_JS=r'''seed=>{
 window.__storageData=seed||{}; window.__fault={set:'',getAfterWrite:'',get:'',partial:false,readCounter:0,writes:0,lockDown:false};
 Object.defineProperty(window,'localStorage',{configurable:true,value:{
  getItem(k){let x=window.__fault;x.readCounter++;
   if(x.get==='always')throw new DOMException('Injected storage read','SecurityError');
   if(x.getAfterWrite==='always'&&x.writes>0)throw new DOMException('Injected post-write read','SecurityError');
   if(x.getAfterWrite==='once'&&x.writes>0){x.getAfterWrite='';throw new DOMException('Injected once','SecurityError');}
   return Object.hasOwn(window.__storageData,k)?window.__storageData[k]:null},
  setItem(k,v){let x=window.__fault;x.writes++;
   if(x.set==='quota')throw new DOMException('Injected quota','QuotaExceededError');
   if(x.set==='deny')throw new DOMException('Injected deny','SecurityError');
   window.__storageData[k]=String(v);},
  removeItem(k){if(window.__fault.getAfterWrite==='always')throw new DOMException('Injected remove','SecurityError');delete window.__storageData[k];}
 }});
}'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 def mk(seed=None):
  ctx=browser.new_context(viewport={'width':390,'height':844},accept_downloads=True); pg=ctx.new_page();pg.set_content(HTML);pg.add_style_tag(content=CSS);pg.evaluate(STORAGE_JS,seed);pg.add_script_tag(content=JS);pg.wait_for_function('!!window.__tabletopTEST');return ctx,pg
 def run(name,fn,kind='observed'):
  try:
   res=fn(); ok=res.pop('ok');RESULT.append({'name':name,'result':'PASS' if ok else 'FAIL','type':kind,'evidence':res});print(('PASS' if ok else 'FAIL'),name,str(res)[:165],flush=True)
  except Exception as e:
   RESULT.append({'name':name,'result':'ERROR','type':kind,'evidence':{'error':type(e).__name__+':'+str(e)[:450]}});print('ERROR',name,type(e).__name__,str(e)[:250],flush=True)
 def backup(s):
  t=json.loads(json.dumps(s));t['scenes'][0]['name']='BACKUP_PESQ005';return t
 def restore_state(pg,w):
  return pg.evaluate('''w=>{const before=__tabletopTEST.state();let err=null;try{__tabletopTEST.restoreCandidate(w);}catch(e){err=e.name+':'+e.message};return {before:before.scenes[0].name,after:__tabletopTEST.state().scenes[0].name,error:err,save:document.getElementById('storageStatus').textContent,backing:(window.__storageData||{})['assim.tabletop.synthetic.workspace.v1']??null}}''',w)
 def fail_before_set():
  c,q=mk();src=q.evaluate('__tabletopTEST.state()');q.evaluate("__fault.set='quota'");out=restore_state(q,backup(src));c.close();return {'ok':bool(out['error']) and out['before']==out['after'] and out['backing'] is None,'ui':out['save'],'ram_changed':out['before']!=out['after']}
 run('SET antes da gravação: RAM/custódia intocadas',fail_before_set)
 def write_no_read():
  c,q=mk();src=q.evaluate('__tabletopTEST.state()');q.evaluate("__fault.getAfterWrite='always'");out=restore_state(q,backup(src));raw=q.evaluate('window.__storageData');c.close();return {'ok':out['after']==out['before'] and out['backing'] is not None and bool(out['error']),'ram':out['after'],'stored':json.loads(out['backing'])['scenes'][0]['name'],'message':out['save'],'classification':'UNKNOWN_AFTER_WRITE despite rejection; expected explicit uncertainty'}
 run('SET completo, GET/rollback indisponíveis: divergência demonstrada',write_no_read,kind='fault reproduction')
 def resume_after_unknown():
  c,q=mk();src=q.evaluate('__tabletopTEST.state()');q.evaluate("__fault.getAfterWrite='always'");out=restore_state(q,backup(src));q.evaluate("__fault.getAfterWrite=''");later=q.evaluate('JSON.parse(localStorage.getItem("assim.tabletop.synthetic.workspace.v1")).scenes[0].name');active=q.evaluate('__tabletopTEST.state().scenes[0].name');c.close();return {'ok':later!=active and later=='BACKUP_PESQ005','stored_after_recovery':later,'active_in_ram':active,'observed':'no automatic reconciliation'}
 run('Recuperação de leitura: divergência persiste até reconciliação',resume_after_unknown,kind='fault reproduction')
 def verify_error_then_rollback():
  c,q=mk();s=q.evaluate('__tabletopTEST.state()');q.evaluate("__fault.getAfterWrite='once'");out=restore_state(q,backup(s));last=out['backing'];c.close();return {'ok':out['before']==out['after'] and last is None and bool(out['error']),'rollback_removed_new':last is None,'error':out['error']}
 run('Falha GET transitória: rollback observável',verify_error_then_rollback)
 def unsafe_reentry():
  c,q=mk();s=q.evaluate('__tabletopTEST.state()');q.evaluate("__fault.getAfterWrite='always'");out=restore_state(q,backup(s));q.evaluate("__fault.getAfterWrite=''");q.locator('#newScene').click();after=q.evaluate('__tabletopTEST.state()');saved=q.evaluate('JSON.parse(window.__storageData["assim.tabletop.synthetic.workspace.v1"]).scenes.length');c.close();return {'ok':len(after['scenes'])==2 and saved==2,'scenes_saved_after_reentry':saved,'risk':'state with unknown previous candidate overwritten without explicit user resolution'}
 run('Reentrada UI após UNKNOWN sobrescreve candidato anterior',unsafe_reentry,kind='risk demonstration')
 def stale_dialog():
  c,q=mk();q.locator('#newScene').click();live=q.evaluate('__tabletopTEST.state()');stale=json.loads(json.dumps(live));stale['scenes']=stale['scenes'][:1];stale['active']=stale['scenes'][0]['id'];prompts=[];# sole handler attached below
  def dial(d):prompts.append(d.message);d.accept()
  q.on('dialog',dial)
  q.locator('#restore').set_input_files({'name':'backup.json','mimeType':'application/json','buffer':json.dumps(stale).encode()});q.wait_for_timeout(130)
  after=q.evaluate('__tabletopTEST.state()');msg=q.locator('#message').inner_text();c.close();return {'ok':len(live['scenes'])==2 and len(after['scenes'])==1 and any('Substituir' in z for z in prompts),'before':len(live['scenes']),'after':len(after['scenes']),'dialog':prompts[-1:] or [],'ui':msg[:130],'classification':'generic confirm without scene-count diff'}
 run('Importação backup antigo reduz duas cenas para uma',stale_dialog,kind='risk demonstration')
 def stale_cancel():
  c,q=mk();q.locator('#newScene').click();live=q.evaluate('__tabletopTEST.state()');stale=json.loads(json.dumps(live));stale['scenes']=stale['scenes'][:1];q.on('dialog',lambda d:d.dismiss());q.locator('#restore').set_input_files({'name':'backup.json','mimeType':'application/json','buffer':json.dumps(stale).encode()});q.wait_for_timeout(150);after=q.evaluate('__tabletopTEST.state()');c.close();return {'ok':live==after,'state_unchanged':live==after}
 run('Cancelar restauração preserva estado',stale_cancel)
 def replay_contract():
  c,q=mk();base=q.evaluate('__tabletopTEST.makeReplay()');e=base['events'][0];ids_variants=[(['frame-001','frame-002'],True),(['frame-002','frame-001'],False),(['frame-002','custom-case-x','frame-001'],True),(['custom-x','custom-y'],True),(['frame-001','frame-001'],False),(['frame-010','frame-013'],True)]
  cases=[]
  for ids,expected in ids_variants:
   d=json.loads(json.dumps(base));d['events']=[dict(e,id=x) for x in ids];ok=q.evaluate('d=>__tabletopTEST.validateReplay(d)',d);cases.append({'ids':ids,'accepted':ok,'expected_current':expected})
  d=json.loads(json.dumps(base));d['events']=[dict(e,id='custom-a',sequence=1),dict(e,id='custom-b',sequence=2)];good=q.evaluate('d=>__tabletopTEST.validateReplay(d)',d)
  d['events'][1]['sequence']=1;bad=q.evaluate('d=>__tabletopTEST.validateReplay(d)',d)
  c.close();return {'ok':all(x['accepted']==x['expected_current'] for x in cases) and good and not bad,'cases':cases,'sequence_accept':good,'sequence_reject':bad}
 run('Contrato real de replay: IDs e sequência explícita',replay_contract,kind='contract characterization')
 def terrain_frame_trap(mode):
  c,q=mk();q.evaluate('__tabletopTEST.capture()');pre=q.evaluate('__tabletopTEST.scene()');q.evaluate(f"__tabletopTEST.mode('wall');__tabletopTEST.cell(2,1);")
  q.evaluate('__tabletopTEST.capture()');fr=q.evaluate('__tabletopTEST.scene().frames.length');q.evaluate(f"__tabletopTEST.mode('{mode}');__tabletopTEST.cell(2,1);")
  new=q.evaluate('__tabletopTEST.scene()');valid=q.evaluate('__tabletopTEST.validateWorkspace(__tabletopTEST.state())');storage=q.locator('#storageStatus').inner_text();c.close();return {'ok':fr>0 and len(new['walls'])==0 and not valid and 'NÃO SALVO' in storage,'frames_before':fr,'frames_after':len(new['frames']),'topology_valid':valid,'storage_status':storage,'mode':mode}
 run('Edição erase removendo parede preserva replay obsoleto (defeito novo)',lambda:terrain_frame_trap('erase'),kind='bug reproduction')
 run('Edição danger substitui parede e invalida replay antigo (defeito novo)',lambda:terrain_frame_trap('danger'),kind='bug reproduction')
 run('Edição terrain substitui parede e invalida replay antigo (defeito novo)',lambda:terrain_frame_trap('terrain'),kind='bug reproduction')
 def fov_mutation():
  c,q=mk();q.locator('#layerFov').check();origin=q.evaluate('__tabletopTEST.scene().units[0]');a=q.evaluate('__tabletopTEST.fovNow()');q.evaluate("__tabletopTEST.mode('wall');__tabletopTEST.cell(2,1)");b=q.evaluate('__tabletopTEST.fovNow()');q.evaluate("__tabletopTEST.mode('erase');__tabletopTEST.cell(2,1)");d=q.evaluate('__tabletopTEST.fovNow()');c.close();return {'ok':a!=b and a==d,'before':len(a),'wall':len(b),'restored':len(d),'fov_cache':'pass'
  }
 run('FOV cache invalida após inserir/remover parede',fov_mutation)
 def fov_scene_separation():
  c,q=mk();q.locator('#layerFov').check();a=q.evaluate('__tabletopTEST.scene()');q.locator('#newScene').click();b=q.evaluate('__tabletopTEST.scene()');q.locator('#layerFov').check();bb=q.evaluate('__tabletopTEST.scene()');q.locator('#scenes').select_option(a['id']);q.wait_for_timeout(120);csc=q.evaluate('__tabletopTEST.scene()');c.close();return {'ok':a['id']!=b['id'] and len(bb['explored'])>0 and bb['id']==b['id'] and csc['id']==a['id'] and len(csc['explored'])>0,'a_explored':len(csc['explored']),'b_explored':len(bb['explored']),'b_initial':len(b['explored'])}
 run('FOV por cena separada após troca',fov_scene_separation)
 browser.close()
O.joinpath('AUDITORIA_BROWSER_005.json').write_text(json.dumps({'baseline':'RUN006 TEST18 public app.js SHA256 '+hashlib.sha256(JS.encode()).hexdigest(),'environment':'/usr/bin/chromium headless, Playwright set_content CSP removed only for harness; storage monkey-patched unless noted','results':RESULT,'counts':{k:sum(z['result']==k for z in RESULT) for k in ['PASS','FAIL','ERROR']}},ensure_ascii=False,indent=2))
print('TOTAL',len(RESULT),'COUNTS',{k:sum(z['result']==k for z in RESULT) for k in ['PASS','FAIL','ERROR']})
