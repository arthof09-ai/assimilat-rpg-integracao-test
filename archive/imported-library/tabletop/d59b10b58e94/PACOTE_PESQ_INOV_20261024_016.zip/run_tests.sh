#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export CODEX_AUTHORITY_READONLY="$PWD/baseline-readonly/codex_authority.py"
export TEST36_ADAPTER_READONLY="$PWD/baseline-readonly/room-v2-adapter.js"
python -m unittest discover -s tests -p 'test_receipt_overlay_016.py' -v
python tests/make_frame_vectors_016.py
node tests/test_actual_adapter_016.cjs
node tests/test_semantic_patch_candidate_016.cjs
