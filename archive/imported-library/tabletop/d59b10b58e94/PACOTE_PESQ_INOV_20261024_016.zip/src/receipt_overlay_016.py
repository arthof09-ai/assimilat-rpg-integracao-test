"""PESQ-016: independent TEST research overlay on Codex Authority (import read-only).
FAKE_LABEL_TEST only; no gameplay adjudication, real auth, VLAB, or official backend.
A Codex submit/event and its queryable receipt COMMIT in one sqlite transaction.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
import re
import sqlite3
from pathlib import Path

IDENT = re.compile(r"[a-z][a-z0-9_-]{0,31}\Z")
ACTOR = {"demo_m":"actor-m","demo_a":"actor-1","demo_b":"actor-2"}
VISUAL = {"demo_m":("gm",2,1,"M","ally"),"demo_a":("p1",1,2,"A","ally"),"demo_b":("p2",4,4,"B","enemy")}
ROLES = {"master":"gm","player1":"p1","player2":"p2"}
MEMBERS = [{"id":"gm","label":"Mestre TEST","role":"MASTER"},{"id":"p1","label":"Player 1 TEST","role":"PLAYER"},{"id":"p2","label":"Player 2 TEST","role":"PLAYER"}]

class Overlay:
    def __init__(self, codex_authority_path, db_path):
        spec=importlib.util.spec_from_file_location("codex_authority_readonly_016",str(codex_authority_path))
        mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        self.mod=mod
        self.core=mod.Authority(db_path)
        self.db=Path(db_path)
        with self.core.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS research_receipts_016 (room_id TEXT NOT NULL, principal TEXT NOT NULL, command_id TEXT NOT NULL, fingerprint TEXT NOT NULL, ack_json TEXT NOT NULL, PRIMARY KEY(room_id, principal, command_id))")

    @staticmethod
    def exact(obj, fields):
        return type(obj) is dict and set(obj)==set(fields)

    @staticmethod
    def identifier(s):
        return type(s) is str and bool(IDENT.fullmatch(s))

    def principal(self, token):
        # Still MOCK identities. Never claim this as login/authentication.
        if token not in self.mod.SESSIONS:return None
        role, actor=self.mod.SESSIONS[token]
        return role,actor,ROLES[role]

    @staticmethod
    def _ack(room,id,status,**kw):
        return {"v":2,"type":"ACK","roomId":room,"commandId":id,"status":status,**kw}

    def error(self, room,id,reason,revision=0):
        return self._ack(room,id,"REJECTED",reason=reason,currentRevision=revision)

    def project(self,db,room,role,actor):
        # No arbitrary state copy, no master note or own note on v2 wire.
        row=db.execute("SELECT revision,state FROM rooms WHERE room_id=?",(room,)).fetchone()
        if not row:return None
        revision,state=row[0],json.loads(row[1]);units=[]
        for unit_id,(owner,x,y,mark,team) in VISUAL.items():
            if role!='master' and owner!=ROLES[role]:continue
            label=state['actors'][ACTOR[unit_id]]['label']
            if type(label) is not str or not 1<=len(label)<=45 or re.search(r'[<>\x00-\x1f]',label):
                raise ValueError('unsafe label in source; fail closed')
            units.append({"id":unit_id,"name":label,"mark":mark,"team":team,"ownerId":owner,"x":x,"y":y})
        return revision,{"sceneId":"scene_test_016","n":7,"walls":[],"units":units,"markers":[]}

    def handle(self,packet,token,*,inject_abort=False):
        """Return single v2 frame dictionary. No HTTP/WebSocket used. No credentials in output."""
        auth=self.principal(token)
        room=packet.get('roomId') if type(packet) is dict else None
        command=packet.get('commandId') if type(packet) is dict else None
        if not auth:return {"error":"UNAUTHORIZED_TEST"}
        role,actor,principal=auth
        if not self.identifier(room):return {"error":"INVALID_SCHEMA_TEST"}
        typ=packet.get('type')
        if packet.get('v')!=2:return {"error":"INVALID_SCHEMA_TEST"}
        if typ=='JOIN':
            # In production: there must be server-side ticket authentication and room membership.
            if not self.exact(packet,['v','type','roomId','ticket']):return {"error":"INVALID_SCHEMA_TEST"}
            if packet['ticket']!='test-local-'+principal:return {"error":"UNAUTHORIZED_TEST"}
            with self.core.connect() as db: projection=self.project(db,room,role,actor)
            if projection is None:return {"error":"ROOM_UNKNOWN_TEST"}
            revision,snapshot=projection
            return {"v":2,"type":"WELCOME","roomId":room,"participantId":principal,"role":"MASTER" if role=='master' else "PLAYER","revision":revision,"sessionEpoch":1,"snapshot":snapshot,"members":MEMBERS}
        if typ=='RESYNC':
            if not self.exact(packet,['v','type','roomId','afterRevision']) or type(packet['afterRevision']) is not int or packet['afterRevision']<0:return {"error":"INVALID_SCHEMA_TEST"}
            with self.core.connect() as db: projection=self.project(db,room,role,actor)
            if projection is None:return {"error":"ROOM_UNKNOWN_TEST"}
            revision,snapshot=projection
            return {"v":2,"type":"SNAPSHOT","roomId":room,"revision":revision,"snapshot":snapshot}
        if typ=='RECEIPT_QUERY':
            if not self.exact(packet,['v','type','roomId','commandId']) or not self.identifier(command):return {"error":"INVALID_SCHEMA_TEST"}
            with self.core.connect() as db:
                row=db.execute('SELECT ack_json FROM research_receipts_016 WHERE room_id=? AND principal=? AND command_id=?',(room,principal,command)).fetchone()
                # If Codex already handled this before the overlay, there is no durable receipt:
                # do NOT fabricate NOT_FOUND and ask the client to submit a NEW ID.
                legacy=db.execute('SELECT fingerprint FROM intents WHERE room_id=? AND principal=? AND action_id=?',(room,role,command)).fetchone()
            if row:return json.loads(row[0])
            if legacy:return {"error":"LEGACY_RECEIPT_UNRESOLVABLE_TEST"}
            return {"v":2,"type":"RECEIPT","roomId":room,"commandId":command,"status":"NOT_FOUND"}
        if typ!='INTENT':return {"error":"INVALID_SCHEMA_TEST"}
        if not self.exact(packet,['v','type','roomId','commandId','baseRevision','kind','unitId','payload']) or not self.identifier(command) or not self.identifier(packet['unitId']) or type(packet['baseRevision']) is not int or packet['baseRevision']<0:
            return {"error":"INVALID_SCHEMA_TEST"}
        # Never claim the Codex FAKE_SET_LABEL is a move, an attack, or a mechanic.
        if packet['kind']!='FAKE_LABEL_TEST':
            # Proposed tactical envelopes are syntactically checked but NEVER executed.
            expected={'ATTACK_REQUEST':{'targetUnitId','declaredActionRef'},
                      'DEFENSE_REQUEST':{'againstCommandId'},
                      'TURN_START_REQUEST':set(),
                      'MOVE_VISUAL_TEST':{'x','y'}}
            if packet['kind'] not in expected or not self.exact(packet['payload'],expected[packet['kind']]):
                return self.error(room,command,'INVALID_INTENT')
            for value in packet['payload'].values():
                if type(value) is str and not self.identifier(value):return self.error(room,command,'INVALID_INTENT')
                if type(value) is int and not 0<=value<20:return self.error(room,command,'INVALID_INTENT')
                if type(value) not in (str,int):return self.error(room,command,'INVALID_INTENT')
            return self.error(room,command,'MECHANICS_HOLD')
        payload=packet['payload']
        if not self.exact(payload,['label']) or type(payload['label']) is not str or not 1<=len(payload['label'])<=45 or re.search(r'[<>\x00-\x1f]',payload['label']):
            return self.error(room,command,'INVALID_INTENT')
        if packet['unitId'] not in ACTOR:return self.error(room,command,'INVALID_INTENT')
        fingerprint=hashlib.sha256(json.dumps(packet,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        try:
            with self.core.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                # Read receipts before revision check: same ID must work after revision changes.
                old=db.execute('SELECT fingerprint,ack_json FROM research_receipts_016 WHERE room_id=? AND principal=? AND command_id=?',(room,principal,command)).fetchone()
                if old:
                    if old[0]==fingerprint:return json.loads(old[1])
                    rev=db.execute('SELECT revision FROM rooms WHERE room_id=?',(room,)).fetchone()
                    return self.error(room,command,'ID_REUSE_CONFLICT',rev[0] if rev else 0)
                # Legacy Codex intent recorded with no corresponding receipt must never be retried.
                legacy=db.execute('SELECT 1 FROM intents WHERE room_id=? AND principal=? AND action_id=?',(room,role,command)).fetchone()
                if legacy:return {"error":"LEGACY_RECEIPT_UNRESOLVABLE_TEST"}
                original={"schema_version":1,"op":"submit","room_id":room,"client_action_id":command,"expected_revision":packet['baseRevision'],"actor_id":ACTOR[packet['unitId']],"effect":{"kind":"FAKE_SET_LABEL","label":payload['label']}}
                self.mod.validate(original)
                # Original Codex Authority performs owner check, serializes SQLite state + event + intent.
                result=self.core.dispatch(db,original,role,actor)
                if inject_abort:raise RuntimeError('TEST injected after Codex event, before durable receipt')
                ack=self._ack(room,command,'ACCEPTED',revision=result['revision'],eventId=result['public_event_id'].replace('event-','ev-'))
                db.execute('INSERT INTO research_receipts_016 VALUES (?,?,?,?,?)',(room,principal,command,fingerprint,json.dumps(ack,sort_keys=True,separators=(',',':'))))
            return ack
        except self.mod.Fault as e:
            with self.core.connect() as db:
                row=db.execute('SELECT revision FROM rooms WHERE room_id=?',(room,)).fetchone()
            current_revision=row[0] if row else 0
            return self.error(room,command,{'STALE_REVISION':'STALE_REVISION','FORBIDDEN':'NOT_OWNER','DUPLICATE_INTENT':'ID_REUSE_CONFLICT'}.get(e.code,'INVALID_INTENT'),current_revision)
        except Exception:
            return {"error":"INTERNAL_ERROR_TEST"}
