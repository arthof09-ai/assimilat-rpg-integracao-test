import hashlib,json,pathlib,sys
base=pathlib.Path(__file__).resolve().parent
manifest=json.loads((base/'MANIFEST_SHA256_PESQ016.json').read_text())
failed=[]
for rel,details in manifest['files'].items():
    p=base/rel
    if not p.is_file() or len(p.read_bytes())!=details['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=details['sha256']:
        failed.append(rel)
print(f"manifest verified {len(manifest['files'])-len(failed)}/{len(manifest['files'])}; failed={failed}")
sys.exit(bool(failed))
