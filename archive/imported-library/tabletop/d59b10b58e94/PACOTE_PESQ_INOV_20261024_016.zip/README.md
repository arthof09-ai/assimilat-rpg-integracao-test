# PESQ-INOV-20261024-016 | PESQUISADOR INOVADOR

**MESTRE-ONLY · TEST / NÃO CANÔNICO · R$0 · Sem motor VLAB paralelo.**

Experimento que enfrenta lacuna real: recuperar, sem dupla aplicação, o recibo de uma intenção já COMMITada em SQLite no código físico da ponte Codex. Cruza as saídas com os validadores reais do adaptador TEST36 e detecta bug semântico de tradução de eventos. Não conecta o Codex ao frontend de batalha, nem executa ações mecânicas.

## Execução portátil

Instalar apenas Python >=3.10 e Node >=18. Não requer pacote npm, rede, conta, deploy ou navegador.

```bash
bash run_tests.sh
```

Resultados esperados: **22/22 Python**, **18/18 validações sobre adaptador real**, **3/3 diferenciais de patch TEST**. Evidências geradas em `evidence/`. O script importa as duas fontes em `baseline-readonly/` sem editá-las. Não execute junto a banco do Codex, VLAB ou Party: o SQLite da suíte é criado num `TemporaryDirectory`.

## Material de entrega

- `src/receipt_overlay_016.py`: POC local de ledger de recibos transacional envolvendo `Authority.dispatch` do Codex original, apenas `FAKE_LABEL_TEST`.
- `tests/*`: 22 verificações Python, 18 do adaptador real em Node, 3 do patch semântico candidato, gerador de frames.
- `baseline-readonly/codex_authority.py` e `room-v2-adapter.js`: cópias hash-preservadas, sem writer sobre as fontes do Desenvolvedor/Codex.
- `report/MATRIZ_DIFERENCIAL_MINIMA_016.md`: diferenças reais e o que permanece HOLD.
- `contract/CONTRATO_MINIMO_RECIBO_TATICO_016.md`: proposta pronta para revisão pelos donos do código.
- `evidence/`: transcripts e frames sintéticos, sem secrets/Party reais.

**Limites não negociáveis:** tokens Codex são `FAKE_TEST_*` públicos, não credenciais; SQLite local não é Durable Objects; sem transporte HTTP/WSS novo; sem VLAB; sem Android real; dados sintéticos de três participantes não comprovam autenticação real. Nenhuma equivalência dos commits Codex divergentes foi alegada.
