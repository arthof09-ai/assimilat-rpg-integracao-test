# PESQ-016 — Matriz diferencial executada, Mestre-only / TEST

Fontes físicas imutáveis: `baseline-readonly/room-v2-adapter.js` (TEST36), `baseline-readonly/codex_authority.py` (POC Codex); contrato anterior PESQ015. Experimento importa o Código Codex original em runtime Python com SQLite efêmero e chama os validadores JS reais do TEST36 em Node VM. Nenhuma homologação oficial.

| Etapa | TEST36 real | Codex real | PESQ-016 evidencia | Fronteira atual |
|---|---|---|---|---|
| CREATE vs JOIN | `JOIN` converte para `ROOM_JOIN` demo | `create` só Mestre cria registro SQLite | overlay distingue create preparado no TEST de JOIN de sessão sintética | não equivalente: precisa criação/convite e autenticação legítimas |
| Identidade/autorização | tickets públicos `test-local-*`; checa `ownerId` no mock | Bearer `FAKE_TEST_*` fixa `role/actor`; autorização de `submit` servidor | token diferente / ator de outra pessoa => negativo; 22 testes | somente FIXTURE; não há login/revogação/ACL real por sala |
| ID de intenção | `commandId` v2 ↔ `intentId` v1 | `client_action_id`, scope `room_id+role` | overlay mapeia `commandId -> client_action_id`, fingerprint sobre pacote inteiro; colisão testada | precisa principal autenticado e versão persistente de protocolo |
| Revision | `baseRevision` v2, `revision` v1 | `expected_revision` | colisão concorrente retornou `STALE_REVISION`, revisão atual verificada | seq v1 ≠ commit revision para jogo VLAB; contract HOLD |
| COMMIT de comando | mock visual em memória | `submit` persiste estado/evento/intent no mesmo COMMIT SQLite | overlay insere ACK consultável NA MESMA TRANSAÇÃO da `Authority.dispatch` original; rollback deliberado testado | somente fake `FAKE_SET_LABEL`, não movimento/dano |
| ACK perdido | cliente v2 preserva UNKNOWN e query mesmo ID | retorna DUPLICATE_INTENT sem ACK original | overlay retorna ACK idêntico na `RECEIPT_QUERY` após restart e novas revisões; 22 testes | extensão TEST, requer decisão do dono do servidor para produção |
| Histórico/resync | RESYNC de apresentação e query de ACK independentes | `history`, `view` filtrados na fonte | overlay RESYNC projeta DTO permitido; legados sem recibo retornam `LEGACY_RECEIPT_UNRESOLVABLE_TEST` | history ≠ receipt, não é seguro fabricar resultado |
| Projeção | `validV2Response` rígido; cliente filtra antes de DOM | reconstrução servidor de DTO para master/player | `WELCOME/SNAPSHOT/ACK` cruzados com validador original JS; bytes da fixture sem notas privadas | precisa autenticação real + filtro confiável no backend antes da transmissão |
| Evento v2 | `EVENT` aceita `MOVE_VISUAL_TEST` ou `ROOM_UPDATED` | `FAKE_SET_LABEL` privado não possui evento XY v2 | **RED REAL:** TEST36 mapeia ambos para `MOVE_CONFIRMED`; patch experimental não destrutivo 3/3 | Desenvolvedor corrigir ramo por espécie de evento antes de consumir efeitos |
| Ação de ataque | não aceita `ATTACK_REQUEST` | só `FAKE_SET_LABEL` | `ATTACK_REQUEST` tipado proposto => `MECHANICS_HOLD` sem efeito, sem receipt ACCEPTED | VLAB ABI + motor oficial + servidor |
| Movimento | MOVE visual sintético | nenhum XY persistido | `MOVE_VISUAL_TEST` não é convertido para `FAKE_SET_LABEL` | precisa autoridade posicional competente / contrato separado |
| Transporte | memória/mock de `transportFactory` | HTTP loopback; sem WS | Node VM + sqlite3/CPython; sem socket interligado aqui | WSS/DO/Android real HOLD |
| Persistência | outbox em `sessionStorage`, journal fail-closed | SQLite real transacional | SQLite local + readback frio e rollback real | Cloudflare DO runtime não testado |

**Resultados executados nesta rodada:** Python `22/22 PASS`, JavaScript com os validadores reais `18/18 PASS`, patch semântico apenas em memória `3/3 PASS` = **43 asserts dirigidos sem duplicar suites antigas**. Houve demonstração deliberada de **1 bug semântico RED no TEST36 não alterado**; PASS do teste que detecta RED não significa PASS da funcionalidade original. Não executadas regras VLAB, Cloudflare, WSS, Android ou autenticação de produção.

**Nota importante:** `FAKE_LABEL_TEST` é somente sentinela de persistência/replay do Codex e *não atravessa* a whitelist de envio TEST36. Não é ação da Arena, não é ataque e não é substituto de movimento. Nenhum loop cliente→server de combate real foi demonstrado.
