# PSV — PESQ-INOV-20261024-016 — Contrato de recibo Codex × Arena TEST36

**Natureza:** MESTRE-ONLY, pesquisa independente de continuidade, sem modificação dos executores, produção, canonização, deploy, conta ou API oficial. Baseline PESQ015 + RUN013 / TEST36 + ponte Codex bytes verificados.

**ANTES:** Codex só registrava fingerprint de `client_action_id`, estado/evento em COMMIT SQLite, mas não RECUPERAVA ACK de ID perdido. TEST36 consulta recibo por `commandId` mas não aceita tipo de ação de combate. `EVENT` `ROOM_UPDATED` era traduzido como `MOVE_CONFIRMED`.

**DEPOIS:** Overlay TEST importa `Authority` do código original e insere registro de recibo na MESMA transação do evento/estado/intenção. Consulta por ID depois de COMMIT, mesmo após reabrir SQLite e após revisões posteriores, retorna ACK originalmente persistido. Ataques e defesa tipados são respondidos `MECHANICS_HOLD` sem execução. Payloads Mestre-only não cruzam projeções reconstruídas, testes de corrupção aninhada e resposta raw JSON da fixture; segurança de rede não comprovada. Identificada e testada correção candidata da confusão `ROOM_UPDATED` × movimento no frontend, original intocado.

**EXECUTADO:** Python sqlite3 com `authority.py` do Codex real, Node 22.16.0 com `room-v2-adapter.js` original; 22/22 Python + 18/18 Node + 3/3 patch candidate, com corrida, rollback, cold restore, lookup por role e payload malicioso. Denominador novo = 43/43 verificações dirigidas; bug semântico da baseline permanece RED até o desenvolvedor corrigir sua fonte. Não somar 34 Python / 15 Node da auditoria Codex anterior.

**STATUS:** VERIFICADO TEST; projeto sem backend final e sem `ATTACK_REQUEST` homologado; sem HTTP/WSS rede no experimento novo, sem Cloudflare, sem três Android reais, sem autenticação legítima. Notion e Library devem ser reabertos após escrita.

**LAST-VERIFIED-UNIT:** suite reproduzível PESQ016 em cópia de pesquisa; fonte Codex/test36 preservada byte-a-byte.
**FIRST-PENDING:** servidor único de sala com identidade real + ABI de decisão VLAB homologada; corrigir EVENT semântico e idempotência de recibos no executor responsável.
**NEXT:** Desenvolvedor pode incorporar patch de EVENT e semântica segura de HOLD, Codex/dono do servidor avaliar transaction/receipt+recovery; VLAB autorizar ABI e mecanismo de reconciliação interprocessual. Pesquisador audita primeiro comando real com logs de RAW WSS por papel e recibos sem duplo efeito.
**NO-REPEAT:** PESQ012–015, RUN013, export/recover Codex já feito, varreduras de vídeos e áudio, motores paralelos.
**NAC-PASS proporcional:** PASS científico local e custódia após readback; HOLD produção, wire seguro e jogo oficial.
