# Runtime / segurança — gate atual PESQ-016

- **Node v22.16.0 / npm 10.9.2 / CPython 3.13.5** disponíveis na bancada desta execução. SQLite da biblioteca Python executado em arquivo de `TemporaryDirectory`, com teste de readback após reconstruir instância.
- `require.resolve` para `miniflare`, `wrangler`, `@cloudflare/vitest-pool-workers`: **NOT_INSTALLED**. O bloqueio npm `EAI_AGAIN registry.npmjs.org` foi documentado na PESQ015; **não repetimos consulta idêntica nem declaramos Docker/workerd testado**.
- **0/10** testes no runtime real Durable Objects; código pesquisa usa SQLite CPython original, não `ctx.storage.sql`/`transactionSync` de DO.
- Não há autenticação real: tokens conhecidos `FAKE_TEST_*`; toda autorização demonstrada é fixture, não login/convite/role revocation reais. Room membership real, identidade no WSS, epoch e revogação requerem implementação competente.
- Nenhuma integração VLAB. A análise R315 Mestre-only documenta Python com `create/decide/view/checkpoint/restore/history` em adaptadores históricos, mas **não há ABI multiplayer homologada ou mecânica de ataque autorizada nesta pesquisa**; `MECHANICS_HOLD` é resposta experimental proposta.
- Commit Codex dentro do ZIP = `bad500...`, mensagem externa `7fd033...`; proveniência dos bytes é garantida por SHA do ZIP, **equivalência Git entre commits não comprovada**.
- JavaScript testado por Node VM com o código real; **não se testou um browser real, WSS, TCP do overlay, Wi-Fi, 3 Android físicos, perda de rede, TLS ou Cloudflare**.

**NAC-PASS:** local/integridade PASS; runtime Cloudflare/produção/autenticidade/ABI VLAB e segurança WSS HOLD.
