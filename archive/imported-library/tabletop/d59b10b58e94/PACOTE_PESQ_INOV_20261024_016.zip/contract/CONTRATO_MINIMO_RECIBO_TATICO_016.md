# PESQ-016 — Interface mínima TEST/PROPOSTA, não homologada

## Divisão de competência

1. **Arena TEST36:** selecionar unidade/ação/alvo, compor intenção com `commandId` estável, salvar outbox antes de enviar; usar `RECEIPT_QUERY` após UNKNOWN. Nunca declarar dano, PA, iniciativa ou escolha de defesa como fato.
2. **Servidor de sala competente:** vincular `commandId` à identidade autenticada real, sala, epoch e fingerprint; conferir ACL, posse, revisão, ordenação e quotas. Registrar **decisão competente+evento+receipt** de maneira recuperável sem aplicar efeito duas vezes. O experimento prova atomicidade só para SQLite local e efeito sintético no mesmo processo.
3. **VLAB competente:** única autoridade de legalidade de turno, ataque, defesa/reação, RNG, custo de PA, Vida/Alma, efeito, condições e transformação. A ABI histórica R22/R315 não é uma ABI multiplayer homologada. A integração interprocessual não pode assumir transação distribuída: necessitará correlação idempotente também no executor VLAB.
4. **Projeção:** `WELCOME`, `ACK`, `RECEIPT`, `SNAPSHOT`, `EVENT`, `HISTORY` precisam de reconstrução allowlist por destinatário **antes da transmissão**. Erros não ecoam dados privados. Nenhuma propriedade mestre administrativa via spread/cópia recursiva.

## Envelope tático PROPOSTO

```json
{
  "v": 2,
  "type": "INTENT",
  "roomId": "arena-test",
  "commandId": "stable_001",
  "baseRevision": 7,
  "kind": "ATTACK_REQUEST",
  "unitId": "demo_a",
  "payload": {
    "targetUnitId": "demo_b",
    "declaredActionRef": "action_test"
  }
}
```

**Responder `ACK:REJECTED reason=MECHANICS_HOLD`** enquanto não existir ligação autorizada à ABI. É proibido produzir `ACK:ACCEPTED` alegando combate ou sintetizar Vida/PA. O overlay exemplar implementa `FAKE_LABEL_TEST` somente para medir idempotência, uma função extra que a UI TEST36 não expõe.

## RECOVERY e idempotência

- `client_action_id` Codex → `commandId` Test36 em função de mapeamento TEST, sem equiparar `eventId` ou `seq`.
- `expected_revision` Codex → `baseRevision` Test36 como pré-condição, não como número de evento. A revisão de resposta deve vir do COMMIT.
- Após COMMIT e ACK perdido, retorno de `RECEIPT_QUERY` deve ser **o mesmo ACK persistido**. Mesmo ID e payload diferentes: `ID_REUSE_CONFLICT`; outro participante: `NOT_FOUND` sem expor existência do recibo. Não reutilizar comando ou mudar ID silenciosamente.
- Se o Codex legado possui ID sem recibo, resposta TEST `LEGACY_RECEIPT_UNRESOLVABLE_TEST` preserva ambiguidade (não mentir `NOT_FOUND`). Migração/recuperação de histórico requer processo separado e competente.
- A implementação final precisa de expiração/revogação/retorno WSS, retenção de recibos, resolução após crash intermediário VLAB, verificação de `sessionEpoch` e projeção entre revisões públicas/admin. Tudo HOLD.

## Patch mínimo ao Desenvolvedor (somente candidato, não aplicado)

Arquivo original `room-v2-adapter.js` trata TODO `EVENT` válido como `MOVE_CONFIRMED`:

```diff
- kind:'MOVE_CONFIRMED',actorId:p.actorId
+ kind:p.kind==='ROOM_UPDATED'?'ROOM_UPDATED':'MOVE_CONFIRMED',actorId:p.actorId
```

Foi testado com fonte original carregada em VM e versão alterada **somente em memória**, sem mudar o repositório. Resultado antes: `ROOM_UPDATED -> MOVE_CONFIRMED` (RED); candidato: `ROOM_UPDATED -> ROOM_UPDATED` (PASS), `MOVE_VISUAL_TEST -> MOVE_CONFIRMED` preservado (PASS). O Desenvolvedor deve avaliar impacto no fluxo de pending/resync e acrescentar teste de regressão próprio.

## Menor ganho para o Desenvolvedor

Sem construir motor mecânico, ele pode: (a) corrigir a representação de EVENT `ROOM_UPDATED`; (b) reaproveitar o exemplo de ledger de recibos pesquisado para especificar `RECEIPT_QUERY` persistente no **único servidor autorizado**; (c) acrescentar UI unidade→ação→alvo com `MECHANICS_HOLD` explícito e outbox estável para os tipos não suportados, mantendo domínio TEST. **Nada disso autoriza `FAKE_LABEL_TEST` no jogo final.**
