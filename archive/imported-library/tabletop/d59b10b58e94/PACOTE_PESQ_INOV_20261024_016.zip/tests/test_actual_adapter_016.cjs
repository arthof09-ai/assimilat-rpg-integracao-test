// Test original TEST36 room-v2-adapter.js in node VM, no frontend modifications.
'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const script=fs.readFileSync(process.env.TEST36_ADAPTER_READONLY,'utf8');
const frames=JSON.parse(fs.readFileSync(require('path').join(__dirname,'../evidence/FRAME_VECTORS_016.json'),'utf8'));
const context=vm.createContext({window:{},console});vm.runInContext(script,context,{filename:'room-v2-adapter.js'});
function validResponse(p){context.__raw=JSON.stringify(p);return vm.runInContext('window.TabletopRoomV2TEST.validV2Response(JSON.parse(__raw))',context)}
function validOutgoing(p){context.__raw=JSON.stringify(p);return vm.runInContext('window.TabletopRoomV2TEST.validV2Outgoing(JSON.parse(__raw))',context)}
const v=context.window.TabletopRoomV2TEST;let passed=0,checks=[];
function t(name,fn){fn();passed++;checks.push(name)}
t('original validator JOIN master',()=>assert(validResponse(frames.joinMaster)));
t('original validator JOIN player1',()=>assert(validResponse(frames.joinPlayer1)));
t('original validator persisted ACK',()=>assert(validResponse(frames.accepted)));
t('original validator query recovered ACK',()=>assert(validResponse(frames.recovered)));
t('original validator RESYNC projection',()=>assert(validResponse(frames.resync)));
t('original validator event ROOM_UPDATED',()=>assert(validResponse(frames.eventSynthetic)));
t('original validator mechanics HOLD',()=>assert(validResponse(frames.holdAttack)));
t('player projection has no nested master secret',()=>{let raw=JSON.stringify(frames.joinPlayer1);assert(!raw.includes('FAKE_MASTER_ONLY'));assert(!raw.includes('FAKE_P2_ONLY'));});
t('same ACK survives query',()=>assert.deepEqual(frames.recovered,frames.accepted));
t('original outgoing ATTACK incompatible',()=>assert(!validOutgoing({v:2,type:'INTENT',roomId:'arena-test',commandId:'att001',baseRevision:1,kind:'ATTACK_REQUEST',unitId:'demo_a',payload:{targetUnitId:'demo_b',declaredActionRef:'atk_test'}})));
t('original outgoing Codex label incompatible',()=>assert(!validOutgoing({v:2,type:'INTENT',roomId:'arena-test',commandId:'label001',baseRevision:0,kind:'FAKE_LABEL_TEST',unitId:'demo_a',payload:{label:'Personagem TEST'}})));
t('original outgoing MOVE allowed but Codex has no XY op',()=>assert(validOutgoing({v:2,type:'INTENT',roomId:'arena-test',commandId:'move001',baseRevision:1,kind:'MOVE_VISUAL_TEST',unitId:'demo_a',payload:{x:2,y:3}})));
t('nested injected master field rejected by TEST36',()=>{let p=JSON.parse(JSON.stringify(frames.joinPlayer1));p.snapshot.units[0].private={nested:'FAKE_MASTER_ONLY'};assert(!validResponse(p))});
// REAL SEMANTIC RED: v2 EVENT kind ROOM_UPDATED becomes ROOM_EVENT kind MOVE_CONFIRMED.
const wire=[];const emitted=[];let callbacks;
const factory=v.createV2AdapterTransport(x=>{callbacks=x;return {send:s=>wire.push(JSON.parse(s)),close:()=>{}}});
const client=factory({onMessage:s=>emitted.push(JSON.parse(s)),onClose:()=>{}});
client.send(JSON.stringify({schema:'assim.tabletop.room.presentation.v1',type:'ROOM_JOIN',roomId:'arena-test',profile:'p1'}));
callbacks.onMessage(JSON.stringify(frames.joinPlayer1));
callbacks.onMessage(JSON.stringify(frames.eventSynthetic));
callbacks.onMessage(JSON.stringify(frames.accepted));
t('outgoing JOIN converts to v2 ticket test',()=>assert.equal(wire[0].ticket,'test-local-p1'));
t('incoming WELCOME reaches old client as JOINED',()=>assert(emitted.some(x=>x.type==='ROOM_JOINED')));
t('EVENT with generic ROOM_UPDATED mislabels MOVE_CONFIRMED — RED observed',()=>{const e=emitted.find(x=>x.type==='ROOM_EVENT');assert(e);assert.equal(e.kind,'MOVE_CONFIRMED');assert.equal(frames.eventSynthetic.kind,'ROOM_UPDATED')});
t('synthetic receipt accepted maps ID',()=>assert(emitted.some(x=>x.type==='ROOM_RECEIPT'&&x.intentId==='label001'&&x.status==='ACCEPTED')));
t('REFUSE unsupported ATTACK at actual room frontend send',()=>assert.throws(()=>client.send(JSON.stringify({schema:'assim.tabletop.room.presentation.v1',type:'ROOM_INTENT',roomId:'arena-test',revision:1,intentId:'att001',action:'ATTACK_REQUEST',unitId:'demo_a',targetUnitId:'demo_b'})),/incompatible|rejeitado/));
fs.writeFileSync(require('path').join(__dirname,'../evidence/TEST36_ADAPTER_ACTUAL_016.json'),JSON.stringify({passed,checks,semanticRed:{v2Kind:'ROOM_UPDATED',v1Kind:'MOVE_CONFIRMED'},allSimulationOnly:true},null,2));
console.log('PASS',passed,'/',passed,'original adapter validations; SEMANTIC_RED proven separately');
