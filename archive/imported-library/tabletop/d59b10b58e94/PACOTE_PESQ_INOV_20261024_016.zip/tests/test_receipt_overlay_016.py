"""Tests against the original imported Codex Authority.py; no edited Codex file."""
import importlib.util
import json
import os
import sqlite3
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('research_overlay_016',ROOT/'src/receipt_overlay_016.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
Overlay=module.Overlay
ORIGINAL=Path(os.environ['CODEX_AUTHORITY_READONLY'])
TOK={'gm':'FAKE_TEST_MASTER','p1':'FAKE_TEST_PLAYER1','p2':'FAKE_TEST_PLAYER2'}

def intent(cmd='cmd001',unit='demo_a',rev=0,label='Synthetic changed',kind='FAKE_LABEL_TEST',payload=None):
    return {'v':2,'type':'INTENT','roomId':'arena-test','commandId':cmd,'baseRevision':rev,'kind':kind,'unitId':unit,'payload':{'label':label} if payload is None else payload}

def query(cmd):return {'v':2,'type':'RECEIPT_QUERY','roomId':'arena-test','commandId':cmd}

def join(p):return {'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-'+p}

class TestCodexReceiptOverlay(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=Path(self.tmp.name)/'arena.sqlite';self.o=Overlay(ORIGINAL,self.db)
        create={'schema_version':1,'op':'create','room_id':'arena-test','client_action_id':'boot_016','expected_revision':0}
        status,raw=self.o.core.handle(json.dumps(create).encode(),TOK['gm'])
        assert status==200,(status,raw)
    def tearDown(self):self.tmp.cleanup()
    def revision(self):
        with sqlite3.connect(self.db) as con:return con.execute("SELECT revision FROM rooms WHERE room_id='arena-test'").fetchone()[0]
    def count(self):
        with sqlite3.connect(self.db) as con:return (con.execute("SELECT COUNT(*) FROM events WHERE room_id='arena-test'").fetchone()[0],con.execute("SELECT COUNT(*) FROM research_receipts_016").fetchone()[0])
    def test_01_master_and_players_join_projection(self):
        for p in TOK:
            frame=self.o.handle(join(p),TOK[p]);self.assertEqual('WELCOME',frame['type']);self.assertEqual(p,frame['participantId'])
            raw=json.dumps(frame,ensure_ascii=False)
            if p!='gm':
                self.assertNotIn('FAKE_MASTER_ONLY',raw);self.assertNotIn('FAKE_P1_ONLY',raw);self.assertNotIn('FAKE_P2_ONLY',raw)
                self.assertEqual([p],[u['ownerId'] for u in frame['snapshot']['units']])
    def test_02_wrong_ticket_for_identity(self):
        self.assertEqual('UNAUTHORIZED_TEST',self.o.handle(join('gm'),TOK['p1'])['error'])
    def test_03_unknown_token_no_wire_private(self):
        self.assertEqual({'error':'UNAUTHORIZED_TEST'},self.o.handle(join('gm'),'bad-token'))
    def test_04_wrong_actor_rejected_without_commit(self):
        a=self.o.handle(intent(unit='demo_b'),TOK['p1']);self.assertEqual('NOT_OWNER',a['reason']);self.assertEqual((0,0),self.count())
    def test_05_commit_ack_query_same_id(self):
        f=intent();ack=self.o.handle(f,TOK['p1']);self.assertEqual('ACCEPTED',ack['status']);self.assertEqual(ack,self.o.handle(query('cmd001'),TOK['p1']));self.assertEqual((1,1),self.count())
    def test_06_lost_ack_retransmit_same_id(self):
        f=intent();original=self.o.handle(f,TOK['p1']);duplicate=self.o.handle(f,TOK['p1']);self.assertEqual(original,duplicate);self.assertEqual((1,1),self.count())
    def test_07_cold_restart_query_receipt(self):
        ack=self.o.handle(intent(),TOK['p1']);self.o=Overlay(ORIGINAL,self.db);self.assertEqual(ack,self.o.handle(query('cmd001'),TOK['p1']))
    def test_08_changed_payload_same_id_conflict(self):
        self.o.handle(intent(),TOK['p1']);x=self.o.handle(intent(label='Different'),TOK['p1']);self.assertEqual('ID_REUSE_CONFLICT',x['reason']);self.assertEqual((1,1),self.count())
    def test_09_player_cannot_query_others_receipt(self):
        self.o.handle(intent(),TOK['p1']);r=self.o.handle(query('cmd001'),TOK['p2']);self.assertEqual('NOT_FOUND',r['status'])
    def test_10_transaction_abort_rolls_back_event_intent_receipt(self):
        x=self.o.handle(intent(),TOK['p1'],inject_abort=True);self.assertEqual('INTERNAL_ERROR_TEST',x['error']);self.assertEqual(0,self.revision());self.assertEqual((0,0),self.count());self.assertEqual('ACCEPTED',self.o.handle(intent(),TOK['p1'])['status'])
    def test_11_two_clients_same_revision_serialized(self):
        a=intent(cmd='cmd001');b=intent(cmd='cmd002',unit='demo_b',label='B altered')
        with ThreadPoolExecutor(max_workers=2) as pool:
            f1=pool.submit(self.o.handle,a,TOK['p1']);f2=pool.submit(self.o.handle,b,TOK['p2']);result=[f1.result(),f2.result()]
        self.assertEqual(['ACCEPTED','REJECTED'],sorted((x['status'] for x in result)));self.assertEqual((1,1),self.count())
        self.assertTrue(any(x.get('reason')=='STALE_REVISION' and x.get('currentRevision')==1 for x in result))
    def test_12_tactical_attack_stopped_no_fake_damage(self):
        p=intent(kind='ATTACK_REQUEST',payload={'targetUnitId':'demo_b','declaredActionRef':'attack_test'})
        x=self.o.handle(p,TOK['p1']);self.assertEqual('MECHANICS_HOLD',x['reason']);self.assertEqual((0,0),self.count())
    def test_13_defense_and_turn_hold(self):
        for kind,payload in [('DEFENSE_REQUEST',{'againstCommandId':'cmd_other'}),('TURN_START_REQUEST',{})]:
            x=self.o.handle(intent(kind=kind,payload=payload),TOK['gm']);self.assertEqual('MECHANICS_HOLD',x['reason'])
        self.assertEqual((0,0),self.count())
    def test_14_extra_nested_role_rejected(self):
        p=intent(kind='ATTACK_REQUEST',payload={'targetUnitId':'demo_b','declaredActionRef':'attack_test','role':'MASTER'})
        self.assertEqual('INVALID_INTENT',self.o.handle(p,TOK['p1'])['reason'])
    def test_15_extra_top_level_metadata_rejected(self):
        p=intent();p['masterOnly']={'private':{'nested':'FAKE_MASTER_ONLY'}}
        self.assertEqual('INVALID_SCHEMA_TEST',self.o.handle(p,TOK['p1'])['error'])
    def test_16_legacy_receipt_ambiguity_not_not_found(self):
        raw={'schema_version':1,'op':'submit','room_id':'arena-test','client_action_id':'legacy01','expected_revision':0,'actor_id':'actor-1','effect':{'kind':'FAKE_SET_LABEL','label':'Old'}}
        self.assertEqual(200,self.o.core.handle(json.dumps(raw).encode(),TOK['p1'])[0]);self.assertEqual('LEGACY_RECEIPT_UNRESOLVABLE_TEST',self.o.handle(query('legacy01'),TOK['p1'])['error'])
    def test_17_wrong_revision_no_commit(self):
        p=intent(rev=5);self.assertEqual('STALE_REVISION',self.o.handle(p,TOK['p1'])['reason']);self.assertEqual((0,0),self.count())
    def test_18_resync_player_is_allowlisted(self):
        self.o.handle(intent(),TOK['p1']);r=self.o.handle({'v':2,'type':'RESYNC','roomId':'arena-test','afterRevision':0},TOK['p2']);self.assertEqual('SNAPSHOT',r['type']);self.assertEqual(1,r['revision']);self.assertEqual(['p2'],[u['ownerId'] for u in r['snapshot']['units']]);self.assertNotIn('FAKE_P1_ONLY',json.dumps(r))
    def test_19_query_after_second_commit_retains_first_ack(self):
        a=self.o.handle(intent(),TOK['p1']);b=self.o.handle(intent(cmd='cmd002',unit='demo_b',rev=1),TOK['p2']);self.assertEqual('ACCEPTED',b['status']);self.assertEqual(a,self.o.handle(query('cmd001'),TOK['p1']));self.assertEqual((2,2),self.count())
    def test_20_server_projection_omits_tampered_nested_notes(self):
        with sqlite3.connect(self.db) as db:
            state=json.loads(db.execute('SELECT state FROM rooms').fetchone()[0]);state['actors']['actor-1']['private_note']={'nested':{'secret':'CANNOT_LEAK_NESTED'}};state['master_note']={'secret':'CANNOT_LEAK_MASTER'}
            db.execute('UPDATE rooms SET state=?',(json.dumps(state),))
        r=self.o.handle(join('p1'),TOK['p1']);wire=json.dumps(r,ensure_ascii=False).encode();self.assertNotIn(b'CANNOT_LEAK_',wire)
    def test_21_create_not_equivalent_to_join(self):
        x=self.o.handle({'v':2,'type':'CREATE','roomId':'arena-test'},TOK['gm']);self.assertEqual('INVALID_SCHEMA_TEST',x['error'])
    def test_22_invalid_move_not_mapped_to_label(self):
        x=self.o.handle(intent(kind='MOVE_VISUAL_TEST',payload={'x':3,'y':4}),TOK['p1']);self.assertEqual('MECHANICS_HOLD',x['reason']);self.assertEqual((0,0),self.count())

if __name__=='__main__':unittest.main(verbosity=2)
