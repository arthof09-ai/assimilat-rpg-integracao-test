'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const original=fs.readFileSync(process.env.TEST36_ADAPTER_READONLY,'utf8');
const frames=JSON.parse(fs.readFileSync(path.join(__dirname,'../evidence/FRAME_VECTORS_016.json')));
const oldExpr="kind:'MOVE_CONFIRMED',actorId:p.actorId";
const newExpr="kind:p.kind==='ROOM_UPDATED'?'ROOM_UPDATED':'MOVE_CONFIRMED',actorId:p.actorId";
assert.equal(original.split(oldExpr).length-1,1,'exactly one original expression required');
function run(code,event){
 const ctx=vm.createContext({window:{},console});vm.runInContext(code,ctx);
 const v=ctx.window.TabletopRoomV2TEST;let on,events=[];
 const transport=v.createV2AdapterTransport(cb=>{on=cb;return{send:()=>{},close:()=>{}}})({onMessage:x=>events.push(JSON.parse(x)),onClose:()=>{}});
 transport.send(JSON.stringify({schema:'assim.tabletop.room.presentation.v1',type:'ROOM_JOIN',roomId:'arena-test',profile:'p1'}));
 on.onMessage(JSON.stringify(frames.joinPlayer1));on.onMessage(JSON.stringify(event));
 return events.find(x=>x.type==='ROOM_EVENT');
}
const before=run(original,frames.eventSynthetic);
const after=run(original.replace(oldExpr,newExpr),frames.eventSynthetic);
assert.equal(before.kind,'MOVE_CONFIRMED');assert.equal(after.kind,'ROOM_UPDATED');
const visual={...frames.eventSynthetic,kind:'MOVE_VISUAL_TEST'};
const preserve=run(original.replace(oldExpr,newExpr),visual);
assert.equal(preserve.kind,'MOVE_CONFIRMED');
assert.deepEqual(after.snapshot,before.snapshot);
const report={before:{incoming:'ROOM_UPDATED',outgoing:before.kind,status:'RED'},after:{incoming:'ROOM_UPDATED',outgoing:after.kind,status:'PASS_TEST_ONLY'},preservesVisualMove:preserve.kind==='MOVE_CONFIRMED',originalSourceUnchanged:true};
fs.writeFileSync(path.join(__dirname,'../evidence/SEMANTIC_PATCH_DIFFERENTIAL_016.json'),JSON.stringify(report,null,2));
console.log('3/3 semantic patch candidate assertions PASS; original RED remains untouched');
