import importlib.util,json,os,tempfile,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('overlay016',root/'src/receipt_overlay_016.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as temp:
 o=mod.Overlay(os.environ['CODEX_AUTHORITY_READONLY'],Path(temp)/'room.sqlite')
 req={'schema_version':1,'op':'create','room_id':'arena-test','client_action_id':'init_016','expected_revision':0}
 assert o.core.handle(json.dumps(req).encode(),'FAKE_TEST_MASTER')[0]==200
 frames={'joinMaster':o.handle({'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-gm'},'FAKE_TEST_MASTER'),
         'joinPlayer1':o.handle({'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-p1'},'FAKE_TEST_PLAYER1')}
 intent={'v':2,'type':'INTENT','roomId':'arena-test','commandId':'label001','baseRevision':0,'kind':'FAKE_LABEL_TEST','unitId':'demo_a','payload':{'label':'Personagem TEST'}}
 frames['accepted']=o.handle(intent,'FAKE_TEST_PLAYER1')
 frames['recovered']=o.handle({'v':2,'type':'RECEIPT_QUERY','roomId':'arena-test','commandId':'label001'},'FAKE_TEST_PLAYER1')
 frames['resync']=o.handle({'v':2,'type':'RESYNC','roomId':'arena-test','afterRevision':0},'FAKE_TEST_PLAYER1')
 frames['eventSynthetic']={'v':2,'type':'EVENT','roomId':'arena-test','revision':1,'commandId':'label001','kind':'ROOM_UPDATED','actorId':'demo_a','snapshot':frames['resync']['snapshot']}
 frames['holdAttack']=o.handle({'v':2,'type':'INTENT','roomId':'arena-test','commandId':'att001','baseRevision':1,'kind':'ATTACK_REQUEST','unitId':'demo_a','payload':{'targetUnitId':'demo_b','declaredActionRef':'atk_test'}},'FAKE_TEST_PLAYER1')
 p=root/'evidence/FRAME_VECTORS_016.json';p.write_text(json.dumps(frames,sort_keys=True,indent=2,ensure_ascii=False),encoding='utf-8')
 print('vectors',len(frames),'bytes',p.stat().st_size)
