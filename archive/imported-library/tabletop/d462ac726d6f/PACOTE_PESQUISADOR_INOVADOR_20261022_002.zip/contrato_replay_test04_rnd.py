"""Auditoria EXPERIMENTAL independente do envelope sintético TEST04.
NÃO é um adaptador do VLAB e NÃO substitui o validador TEST03.
"""
import json, hashlib, math
MAX_BYTES=150_000

def keys(obj, required):
    return isinstance(obj,dict) and set(obj)==set(required)
def fail(reason): raise ValueError(reason)
def validate(raw:bytes):
    if len(raw)>MAX_BYTES:fail('LIMIT_BYTES')
    try:doc=json.loads(raw)
    except (json.JSONDecodeError,UnicodeDecodeError):fail('INVALID_JSON')
    if not keys(doc,['schema','source','grid','units','events']):fail('ROOT_FIELDS')
    if doc['schema']!='assim.lab.vlab.readonly.v1':fail('SCHEMA')
    src=doc['source']
    if not keys(src,['kind','scope','isolatedCopy','reference','exportedAt']):fail('SOURCE_FIELDS')
    if src['kind']!='SYNTHETIC_FIXTURE' or src['scope']!='MESTRE_ONLY' or src['isolatedCopy'] is not True or src['reference']!='INOVADOR-TEST04-ARENA-LOCAL':fail('SOURCE_UNTRUSTED')
    if not isinstance(src['exportedAt'],str) or not src['exportedAt'] or len(src['exportedAt'])>48:fail('SOURCE_TIME')
    grid=doc['grid']
    if not keys(grid,['width','height','walls']) or type(grid['width']) is not int or type(grid['height']) is not int or grid['width'] not in (5,7,10,20) or grid['height']!=grid['width']:fail('GRID_SIZE')
    n=grid['width']
    def xy(p):return isinstance(p,list) and len(p)==2 and all(type(v) is int and 0<=v<n for v in p)
    walls=grid['walls']
    if not isinstance(walls,list) or len(walls)>n*n or any(not xy(p) for p in walls) or len(set(map(tuple,walls)))!=len(walls):fail('WALLS')
    units=doc['units']
    if not isinstance(units,list) or len(units)!=4:fail('UNITS')
    ids=[]
    for u in units:
        if not keys(u,['id','label','mark','team']):fail('UNIT_FIELDS')
        if u['id'] not in ('b','w','e','f') or u['team'] != ('ally' if u['id'] in ('b','w') else 'enemy') or not isinstance(u['label'],str) or len(u['label'])>60 or not isinstance(u['mark'],str) or len(u['mark'])>2:fail('UNIT_VALUE')
        ids.append(u['id'])
    if len(set(ids))!=4:fail('UNIT_IDS')
    events=doc['events']
    if not isinstance(events,list) or not 1<=len(events)<=128:fail('EVENT_COUNT')
    wallset=set(map(tuple,walls))
    for i,e in enumerate(events,1):
        if not keys(e,['id','type','title','description','frame']):fail('EVENT_FIELDS')
        if e['id']!=f'test04-{i:03d}' or e['type'] not in ('POSITION','ROUND_NOTE') or any(not isinstance(e[z],str) or len(e[z])>240 for z in ('title','description')):fail('EVENT_META')
        if not keys(e['frame'],['positions']):fail('FRAME_FIELDS')
        poses=e['frame']['positions']
        if not isinstance(poses,dict) or set(poses)!=set(ids) or any(not xy(v) for v in poses.values()):fail('POSITIONS')
        if len(set(map(tuple,poses.values())))!=4 or any(tuple(v) in wallset for v in poses.values()):fail('COLLISION')
    return {'n':n,'events':len(events),'sha256':hashlib.sha256(raw).hexdigest()}

def synthetic(n=7):
    obj={'schema':'assim.lab.vlab.readonly.v1','source':{'kind':'SYNTHETIC_FIXTURE','scope':'MESTRE_ONLY','isolatedCopy':True,'reference':'INOVADOR-TEST04-ARENA-LOCAL','exportedAt':'2026-10-22'},'grid':{'width':n,'height':n,'walls':[]},'units':[{'id':v,'label':v+' TEST','mark':v.upper(),'team':'ally' if v in 'bw' else 'enemy'} for v in 'bwef'],'events':[{'id':'test04-001','type':'ROUND_NOTE','title':'Snapshot sintético','description':'SYNTHETIC_FIXTURE','frame':{'positions':{'b':[0,0],'w':[1,0],'e':[n-2,n-1],'f':[n-1,n-1]}}}]}
    return obj

def encoded(v):return json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()
