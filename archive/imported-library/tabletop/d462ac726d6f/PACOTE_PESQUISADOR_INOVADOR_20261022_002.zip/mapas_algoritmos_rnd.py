"""BFS, A* e LOS em cópias sintéticas; não reproduz regras do RPG."""
from collections import deque
from heapq import heappush,heappop
import time,random
D=((1,0),(-1,0),(0,1),(0,-1))
def neigh(p,n,walls):
 for dx,dy in D:
  x=p[0]+dx;y=p[1]+dy
  if 0<=x<n and 0<=y<n and (x,y) not in walls:yield (x,y)
def bfs(a,b,n,walls):
 q=deque([a]); prev={a:None}
 while q:
  p=q.popleft()
  if p==b:break
  for nx in neigh(p,n,walls):
   if nx not in prev:prev[nx]=p;q.append(nx)
 return trace(prev,b)
def astar(a,b,n,walls):
 h=lambda p:abs(p[0]-b[0])+abs(p[1]-b[1])
 q=[(h(a),0,a)];prev={a:None};cost={a:0}
 while q:
  _,g,p=heappop(q)
  if g!=cost[p]:continue
  if p==b:break
  for nx in neigh(p,n,walls):
   if nx not in cost or g+1<cost[nx]:
    cost[nx]=g+1;prev[nx]=p;heappush(q,(g+1+h(nx),g+1,nx))
 return trace(prev,b)
def trace(prev,b):
 if b not in prev:return None
 result=[]
 while b is not None:result.append(b);b=prev[b]
 return result[::-1]
def bresenham(a,b):
 x0,y0=a;x1,y1=b;dx=abs(x1-x0);dy=-abs(y1-y0);sx=1 if x0<x1 else -1;sy=1 if y0<y1 else -1;err=dx+dy
 while True:
  yield x0,y0
  if (x0,y0)==(x1,y1):return
  e2=err*2
  if e2>=dy:err+=dy;x0+=sx
  if e2<=dx:err+=dx;y0+=sy

def visible(a,b,walls):
 # Obstáculo-alvo é visível; o obstáculo INTERMEDIÁRIO bloqueia o fundo.
 return all(p not in walls for p in list(bresenham(a,b))[1:-1])
def fov(a,n,walls,radius=None):
 return {(x,y) for x in range(n) for y in range(n) if (radius is None or (x-a[0])**2+(y-a[1])**2<=radius*radius) and visible(a,(x,y),walls)}
def party_projection(scene, visible_cells):
 # Fonte allowlist construída da visão AUTORIZADA, não filtro CSS de uma cópia mestre.
 return {'grid':scene['grid'],'visible':sorted([list(p) for p in visible_cells]),'tokens':[{'id':u['id'],'x':u['x'],'y':u['y']} for u in scene['tokens'] if (u['x'],u['y']) in visible_cells and u.get('public',False)]}
