import json,copy,random,time,statistics
from pathlib import Path
from contrato_replay_test04_rnd import synthetic,validate,encoded
from mapas_algoritmos_rnd import bfs,astar,fov,visible,party_projection
D=Path(__file__).parent; results=[]
def check(n,condition):
 results.append({'test':n,'PASS':bool(condition)})
 if not condition:raise AssertionError(n)
def reject(n,edit):
 o=copy.deepcopy(synthetic());edit(o)
 try:validate(encoded(o));check(n,False)
 except ValueError:check(n,True)
check('valid_7',validate(encoded(synthetic(7)))['n']==7)
check('valid_20',validate(encoded(synthetic(20)))['n']==20)
for name,edit in [
 ('wrong_schema',lambda o:o.update(schema='vlab.official')),
 ('spoof_party',lambda o:o['source'].update(scope='PARTY')),
 ('spoof_kind',lambda o:o['source'].update(kind='VLAB_REAL')),
 ('no_isolation',lambda o:o['source'].update(isolatedCopy=False)),
 ('unknown_extra_root',lambda o:o.update(extra='boom')),
 ('unexpected_src_key',lambda o:o['source'].update(secret='oops')),
 ('wrong_grid',lambda o:o['grid'].update(width=8)),
 ('non_square',lambda o:o['grid'].update(height=10)),
 ('wall_duplicate',lambda o:o['grid'].update(walls=[[2,2],[2,2]])),
 ('wall_out_of_bounds',lambda o:o['grid'].update(walls=[[7,1]])),
 ('wall_bool_coord',lambda o:o['grid'].update(walls=[[True,1]])),
 ('unit_duplicate',lambda o:o['units'][3].update(id='e')),
 ('unit_extra_key',lambda o:o['units'][0].update(hp=500)),
 ('unit_bad_team',lambda o:o['units'][0].update(team='enemy')),
 ('event_duplicate_pos',lambda o:o['events'][0]['frame']['positions'].update(w=[0,0])),
 ('event_wall_collision',lambda o:o['grid'].update(walls=[[0,0]])),
 ('event_pos_outside',lambda o:o['events'][0]['frame']['positions'].update(b=[-1,0])),
 ('event_extra_field',lambda o:o['events'][0].update(script='<img onerror=alert(1)>')),
 ('event_id_repeated',lambda o:o['events'][0].update(id='test04-888')),
 ('event_type_unknown',lambda o:o['events'][0].update(type='DAMAGE_REAL')),
 ('event_missing_positions',lambda o:o['events'][0]['frame'].update(positions={})),
 ('event_id_bad_order',lambda o:o['events'].append(copy.deepcopy(o['events'][0]))),
 ('zero_events',lambda o:o.update(events=[])),
 ('too_many_events',lambda o:o.update(events=[o['events'][0]]*129)),
]:reject(name,edit)
try:validate(b'{broken');check('invalid_json',False)
except ValueError:check('invalid_json',True)
try:validate(b' '*150001);check('size_limit',False)
except ValueError:check('size_limit',True)
# replay deterministic: frame states never recalc HP/PA and exact bytes/hash stable
obj=synthetic();raw=encoded(obj)
check('stable_hash',validate(raw)['sha256']==validate(raw)['sha256'])
check('no_derived_combat_keys',all('hp' not in ev and 'pa' not in ev for ev in obj['events']))
# 3 scenarios 7/20 with deterministic walls, compares shortest path or impossibility
stats={}
for n in (7,20):
 rng=random.Random(n+20261022);walls={(x,y) for x in range(n) for y in range(n) if rng.random()<.20};a=(0,0);b=(n-1,n-1);walls.discard(a);walls.discard(b)
 start=time.perf_counter();P=bfs(a,b,n,walls);t_b=(time.perf_counter()-start)*1e3
 start=time.perf_counter();Q=astar(a,b,n,walls);t_a=(time.perf_counter()-start)*1e3
 check(f'{n}_bfs_astar_shortest', (P is None and Q is None) or (P is not None and Q is not None and len(P)==len(Q)))
 check(f'{n}_path_avoids_walls',P is None or all(c not in walls for c in P))
 check(f'{n}_blocked_destination',bfs(a,b,n,walls|{b}) is None)
 check(f'{n}_los_self',visible(a,a,walls))
 w={(1,0)};v=fov((0,0),n,w)
 check(f'{n}_wall_visible', (1,0) in v)
 check(f'{n}_behind_wall_hidden',(2,0) not in v)
 # Strict allowlist client projection
 scene={'grid':{'width':n,'height':n},'tokens':[{'id':'visible-public','x':0,'y':0,'public':True},{'id':'secret-monster','x':2,'y':0,'public':False},{'id':'secret-nearby','x':0,'y':1,'public':False}]}
 projection=party_projection(scene,v)
 check(f'{n}_no_master_only_tokens',all(z['id']=='visible-public' for z in projection['tokens']) and 'secret-monster' not in json.dumps(projection))
 stats[str(n)]={'cells':n*n,'walls_count':len(walls),'path_length':len(P)-1 if P else None,'bfs_ms_single':round(t_b,6),'astar_ms_single':round(t_a,6),'fov_cells':len(v)}
# 100 deterministic path scenario checks with fixed seeds, not a perf benchmark
rng=random.Random(4401)
for i in range(100):
 n=7 if i%2 else 20;w={(x,y) for x in range(n) for y in range(n) if rng.random()<.25};a=(0,0);b=(n-1,n-1);w.discard(a);w.discard(b);p=bfs(a,b,n,w);q=astar(a,b,n,w)
 if (p is None)!=(q is None) or (p is not None and len(p)!=len(q)):raise AssertionError('property shortest mismatch')
check('100_property_path_agreement',True)
results_data={'environment':'Python stdlib, deterministic synthetic fixtures ONLY','passed':sum(z['PASS'] for z in results),'total':len(results),'cases':results,'stats_sample_not_benchmark':stats}
(D/'RESULTADOS_REPLAY_FOV_PATH.json').write_text(json.dumps(results_data,indent=2,ensure_ascii=False))
(D/'FIXTURE_REPLAY_TEST04_SINTETICO.json').write_bytes(encoded(synthetic(7)))
print(json.dumps({'passed':results_data['passed'],'total':results_data['total'],'sample':stats},ensure_ascii=False))
