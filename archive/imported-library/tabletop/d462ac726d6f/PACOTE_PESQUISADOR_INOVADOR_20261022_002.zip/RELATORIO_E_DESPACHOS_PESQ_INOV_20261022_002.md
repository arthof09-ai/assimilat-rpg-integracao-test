# PESQ-INOV-20261022-002 — Engenharia prática do Tabletop Assimilação

**Função:** terceiro chat / Comestre Inovador Pesquisador; MESTRE-SIDE / TEST / R$ 0.
**Autoridade:** Mestre humano. **Integração PROD:** HOLD. **Party/O Primeiro:** NO-WRITE.
**Data:** 22/10/2026. **Nenhum código do desenvolvedor foi modificado.**

## 1. Pergunta A — o VLAB exporta mapa/posições em R205?

### Fontes fisicamente consultadas
- Notion [R205](https://app.notion.com/p/3ffc2b324ede81c895eaeb0cd64d1c66): 20 combates TEST, 945 commits, 2.812 eventos, 462 ataques, 20 SQLite, JSON/TSV, auditor de recuperação 58/58 relatados; arquivo reportado `/Comestre/OP-VLAB-FUSION-SANDBOX-01/VLAB_R205_DEFESA_DE_VENTO_ANEL_CLASSIFICADO_MESTRE_ONLY.zip`, 20.800.905 bytes, SHA-256 `62a9851b3a5ae7919b9225d9379a3d32c8736448e76bfcea4729dcbfe933cead`.
- Notion [Laboratório do Inovador](https://app.notion.com/p/401c2b324ede809585d3d1907c194df9), RUN-002 e PESQ-001.
- Project Files (busca por R205, ZIP, recovery) e Biblioteca (buscas por nome): arquivo ZIP R205 **não recuperado** nesta execução. Não foi calculado SHA físico desse ZIP ou lida sua estrutura interna. Busca negativa não prova ausência global.
- Código **texto indexado**, acessado via Files, `ARENA_PONTE_REPLAY_INOVADOR_TEST_04.html` (106 linhas; `bridgeMake`, `bridgeCapture`, `bridgeRender`), **sem materialização binária disponível**: o exportador produz somente `schema='assim.lab.vlab.readonly.v1'`, `source.kind='SYNTHETIC_FIXTURE'`, `grid.width/height/walls`, `units` e `events` com `frame.positions`, a partir de estados locais TEST02.
- Arquivo físico de Biblioteca `VLAB_ESTADO_RECUPERAVEL_R238_MESTRE_ONLY.json` (20.825 bytes) aberto **para inspecionar metadados de handoff**, não é exportador de eventos R205. Seus campos incluem `checkpoints`, `tasks`, `operation_id`, `notion_writer`, sem prova de posições por evento.

### Distinções de certeza
**VERIFICADO:** R205 é uma página documental que referencia ZIP e bancos; TEST04 tem envelope sintético com posições; arquivo R238 é checkpoint de continuidade, não lote de eventos.
**HISTÓRICO RELATADO:** os 20 bancos SQLite, 2.812 eventos e SHA do ZIP foram verificados pelo executor anterior, não reabertos neste trabalho.
**PENDENTE/HOLD:** formato SQL/JSON real R205, IDs estáveis, schema físico, topologia de mapas, posição dos atores, integridade binária independente.
**NÃO INFERIR:** coordenadas a partir de alcance de ataque ou retorno de anel; não misturar `eventId` hipotético com campo físico do VLAB; não atribuir cenário espacial completo a séries de dano.

### Crosswalk seguro proposto — sem pretensão de identidade de schemas
| Origem/estado | TEST04 sintético observado | Ponte TEST05 proposta |
|---|---|---|
| R205 documenta commits/eventos | `events[].id/type/frame.positions` | export real precisa ser recuperado; eventos sem posições viram texto de linha do tempo, NÃO movimento |
| R205 não prova topologia neste checkpoint | `grid.{width,height,walls}` | ausência de mapa/parede real => vídeo/linha do tempo sem tabuleiro ou cenário TEST marcado |
| R205 registra 10 seeds pareadas e casos | `source` fixo `SYNTHETIC_FIXTURE` | referência/hash/seed original em envelope separado, sem declarar campo nativo VLAB |
| R205 descreve recursos e ataque | `frame.positions` apenas | snapshots de HP/PA só quando explícitos no recibo, nunca recalcular |
| VLAB eventos causais | TEST04 `POSITION` ou `ROUND_NOTE` | adaptador somente leitura, schema versionado, ordem congelada, rejeitar lacunas críticas |

**Próximo passo P0:** obter ZIP R205 autêntico por rota de Biblioteca autorizada; comparação SHA e 58 arquivos, inspeção SQLite `PRAGMA table_info` e amostras `SELECT ... LIMIT`, schema JSON real, identificação de coordenadas e estabilidade de ordenação. **Não executar os scripts de combate.** Abrir ZIP como dado não implica executar Python nele. Se amostra não tiver mapas, preservar linha do tempo sem renderizar posições inventadas.

## 2. Pergunta B — pan/pinch Android sem engine pesada

### Fontes e mecanismo
- [MDN Pointer Events multi-touch](https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events/Multi-touch_interaction), [MDN Pinch](https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events/Pinch_zoom_gestures), [touch-action](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/touch-action), [W3C Pointer Events](https://www.w3.org/TR/pointerevents/).
- Pointer Events unem mouse/caneta/toque e usam `pointerId` estável; capturar ponteiro, tratar `pointercancel`/`lostpointercapture`; limitar `touch-action:none` à área de mapa para não eliminar scroll da página. Gestos são processamento de câmera, não comando de movimento tático.
- Transformação: **tela** `s = pan + zoom × mundo`; inversa `mundo = (tela - pan)/zoom`. Para dar zoom centrado no meio dos dedos, fixe `m = (mid_antigo-pan_antigo)/zoom_antigo` e calcule `pan_novo = mid_novo - zoom_novo × m`. Clamp 0,65…3,5 apenas experimental.

### Experimento isolado A
`POC_ANDROID_POINTER_TEST_PESQUISADOR.html` é código autoral independente e autocontido. `test_pointers.py` usa Playwright e Chromium headless com `page.set_content` (abertura `file://` foi bloqueada pelo administrador); eventos de ponteiro artificiais. Resultado **26/26 PASS** em 390×844 e 360×740. Matrizes: 7×7, 20×20, seleção, arraste, pinça, âncora, translação com pinça, prevenção de seleção indesejada, cancelamento, zoom máximo/mínimo, transformações e zero requisições de rede.
**Não provado:** gesto físico em Android real, latência de device modesto, comportamento dos navegadores Firefox/WebView, arquivos locais em Android, acessibilidade completa. Nenhuma mudança no TEST05.

### Primeira implementação sugerida ao Desenvolvedor
1. Manter câmera/viewport separada de `gameState`/fichas; nenhum drag da câmera altera token.
2. Adicionar `pointerdown/move/up/cancel` à superfície da Arena, `touch-action:none` somente ali, pointer capture com tratamento de falhas; cancelar tap após segundo dedo ou deslocamento maior que 7 pixels.
3. Implementar inversa exata da transformação para hit test dos tokens; preservar a posição sob o ponto médio durante a pinça. Navegação por botões +/− e recentrar disponível.
4. Testar células 7×7/20×20, zoom com scroll de página, duas e três pontas, dedo saindo do componente, alternância dedo/mouse, 1→2→1 dedos, rotação/nova dimensão. Verificar também comportamento de `lostpointercapture` real no Android.
5. Medir tempo de renderização e memória antes de introduzir PixiJS/Phaser. Evitar WebGL como dependência inicial sem pressão real de sprites/efeitos.

## 3. Pesquisa P1 — validação sintética de replay

**Modelo:** auditor Python independente (`contrato_replay_test04_rnd.py`) implementa restrições explícitas sobre envelope TEST04 para fins de pesquisa, NÃO é certificação do Observatório. Exige `SYNTHETIC_FIXTURE`, `MESTRE_ONLY`, `isolatedCopy:true`, schema exato e tamanho até 150.000 bytes; rejeita chaves extras, IDs repetidos/fora de ordem, coordenadas fora da grade, paredes duplicadas e colisões, payload de tipo desconhecido. Esta restrição é mais severa que o comportamento original observado, não substitui o validador TEST03.
**Prova:** `test_replay_fov_path.py`, 45/45 asserts PASS **somados de replay, caminho e FOV**. Inclui 24 cenários negativos de replay mais checks positivos, hashes estáveis e invariantes.
**Riscos:** flags de escopo dentro do JSON são declarações não confiáveis; SHA256 atesta igualdade dos bytes com um hash de referência autenticado, não a autorização do portador ou segredo. Hash calculado de upload não cria proveniência sozinho. Nunca colocar HTML dinâmico externo em `innerHTML` sem escaping: usar `textContent` para descrições de evento. Nunca enviar a clientes Party um objeto completo Mestre para 'esconder' depois.

## 4. Pesquisa P1 — algoritmo de caminho e visão

`mapas_algoritmos_rnd.py` compara BFS e A* para caminhos ortogonais sintéticos; usa Bresenham de grade como aproximação de linha de visão, com política experimental: parede de destino visível, paredes intermediárias bloqueiam. 100 cenários aleatórios reproduzíveis compararam BFS e A* sem divergência de tamanho de caminho. Para 7×7 (49 casas) e 20×20 (400 casas), tempos de uma execução local foram de décimos ou centésimos de milissegundo em Python desktop, **não benchmark Android**. Quadro de testes do script: 45/45 PASS. **Sem prova de regra oficial** para diagonais, cantos opacos, cobertura ou alcance.
**Recomendação:** BFS com custo uniforme e grade ortogonal 7×7/20×20 enquanto há até 400 nós; A* se mapas crescentes e múltiplas rotas se tornarem gargalo medido. Para neblina, manter `explored` (histórico descoberto) separado de `visible_now` (visão presente), com retângulos ou bitset por mapa. Antes de qualquer cliente Party, servidor autorizado precisa construir allowlist de células e tokens públicos **antes da serialização**, não enviar universo Mestre com CSS `display:none`.
**Pendência:** algoritmo FOV de referência shadowcasting, política de oclusão de cantos, multiplicidade de fontes de visão, benchmark em Android físico e autenticação para multiplayer. O teste da projeção Party foi apenas sobre fixture sintética, sem publicação nem ligação ao RPG real.

## 5. Pesquisa de padrões existentes e licenças

- **Foundry VTT, documentação pública da API v14:** separa Scene/Document, Canvas WebGL/PixiJS, Placeables e camadas de fog, walls, tokens, lighting; fonte [API](https://foundryvtt.com/api/). **Não foi examinado código interno privado**. Ideia: separar modelo de cena de sua renderização.
- **Owlbear Rodeo SDK:** API pública [Items](https://docs.owlbear.rodeo/extensions/apis/scene/items/), [Viewport](https://docs.owlbear.rodeo/extensions/apis/viewport/), [Permissions](https://docs.owlbear.rodeo/docs/permissions/); SDK MIT no [README](https://github.com/owlbear-rodeo/sdk/blob/main/README.md), mas extensões oficiais exemplares como [dynamic-fog](https://github.com/owlbear-rodeo/dynamic-fog) usam GPLv3. **Atenção**: licença de SDK não contamina automaticamente o código das extensões; não copiar arquivos GPL para produto sem revisão.
- **VirtualTabletop.io**: examinados [server/websocket.mjs](https://github.com/ArnoldSmith86/virtualtabletop/blob/main/server/websocket.mjs) e [server/room.mjs](https://github.com/ArnoldSmith86/virtualtabletop/blob/main/server/room.mjs) da branch `main`, sem commit fixado; WebSocketServer gerencia conexões; room mantém estado e transmite eventos/deltas. Em `addPlayer`, código visível envia `player.send('state', this.state)`; em `broadcast`, percorre os participantes. **Isso é uma referência de sincronização, NÃO uma autorização para enviar estado Mestre inteiro à Party**. Repositório GPLv3; conhecimento de padrões, sem reutilização de código.
- **FreeBeeGee**: [README](https://github.com/ludus-leonis/FreeBeeGee), árvore [src/js](https://github.com/ludus-leonis/FreeBeeGee/tree/release/src/js), branch `release`, sem commit fixado. PHP no servidor e JavaScript no cliente, camadas, backup em arquivos, licença AGPL-3.0, compatibilidade touch limitada no README. Não foi lido o núcleo completo, nem extraído código.
- **Licenças:** não copiar código GPLv3/AGPLv3 como dependência sem verificar deveres da forma de distribuição/hospedagem; estudar comportamento público e fazer implementação própria é a rota inicial de menor risco. README sozinho não prova performance mobile.

## 6. Despachos ao Desenvolvedor

**D-INOV-20261022-002 / P0 / Contrato R205:** obter arquivo físico correto e verificar SHA; inspecionar bancos e JSON reais *somente leitura*; publicar crosswalk dos campos comprovados; adaptar TEST05 a eventos de linha do tempo antes de mapa se posições faltarem; rejeitar schema incompleto e falsos movimentos. Aceite: 1 payload real + manifesto/proveniência + ordem/IDs verificados; zero eventos inventados; nenhum motor oficial recalculado. Estado atual HOLD por falta de bytes R205.

**D-INOV-20261022-003 / P0 / Android gestos:** transportar apenas a técnica de Pointer Events e transformações da POC autoral para código TEST do Desenvolvedor, sem editar originais deste relatório; testes de toque/tap/pinch/cancelamento e viewport; 26/26 teste do Pesquisador como referência, NÃO como aprovação do TEST05 nem prova Android real. Aceite: pan/pinch sem mover token ou selecionar por engano, hit-test estável e retorno após cancelamento.

**D-INOV-20261022-004 / P1 / Replays e visão:** validar JSON com allowlist versionada e limites; manter índices de evento/identificador único, separar câmera de estado de jogo, e para FOV adotar protótipo Bresenham sintético como oráculo exploratório de bloqueios simples; não ativar fog para players até filtragem confiável na origem. Aceite: falhas de schema/collisions rejeitadas sem efeitos e cenário Mestre-only ausente do payload permitido às players.

## 7. Estado e continuidade

Resultados da execução corrente: **26/26** em testes de Pointer via Chromium; **45/45** asserts em testes Python independentes; **71/71** somados apenas como execuções de duas suítes diferentes — não 71 contratos oficiais nem teste Android físico. POC e scripts preservados como arquivos de pesquisa, com checksums locais. Registros no Notion e seu readback são uma etapa separada. **Nenhum SHA de ZIP R205 recuperado fisicamente.**

**NEXT:** bytes autênticos R205; inspeção SQL real; política de visão de cantos/cobertura; benchmark incremental de FOV/raycasting contra shadowcasting; revisão de autorização de payloads antes de multiplayer. Desenvolvedor ACK/implementação **não confirmados**. Sem alteração de Party/O Primeiro ou produção.
