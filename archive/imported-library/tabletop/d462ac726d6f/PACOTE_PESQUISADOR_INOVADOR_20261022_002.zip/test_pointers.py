from playwright.sync_api import sync_playwright
from pathlib import Path
import math, json, random
p=Path(__file__).with_name('POC_ANDROID_POINTER_TEST_PESQUISADOR.html').resolve().as_uri()
results=[]
def check(name,ok):
    results.append({'test':name,'PASS':bool(ok)})
    if not ok: raise AssertionError(name)

def ptr(page,t,pid,x,y):
    page.evaluate('''({t,pid,x,y})=>{const e=document.querySelector('#surface');e.dispatchEvent(new PointerEvent(t,{pointerId:pid,pointerType:'touch',clientX:x,clientY:y,bubbles:true,isPrimary:pid===1}));}''',{'t':t,'pid':pid,'x':x,'y':y})
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for vp in [(390,844),(360,740)]:
        page=browser.new_page(viewport={'width':vp[0],'height':vp[1]},device_scale_factor=2,has_touch=True,is_mobile=True)
        requests=[];page.on('request',lambda req:requests.append(req.url))
        page.set_content(Path(__file__).with_name('POC_ANDROID_POINTER_TEST_PESQUISADOR.html').read_text())
        state=lambda:page.evaluate('window.__pesquisa.state()')
        rect=page.locator('#surface').bounding_box();ox=rect['x'];oy=rect['y']
        check(f'{vp} initial 7x7',page.locator('.tile').count()==49 and state()['n']==7)
        ptr(page,'pointerdown',1,ox+100,oy+150);ptr(page,'pointerup',1,ox+100,oy+150)
        check(f'{vp} tap select',state()['selected']=={'x':2,'y':3})
        ptr(page,'pointerdown',1,ox+100,oy+100);ptr(page,'pointermove',1,ox+140,oy+120);ptr(page,'pointerup',1,ox+140,oy+120)
        check(f'{vp} drag translate',abs(state()['panX']-40)<1e-7 and abs(state()['panY']-20)<1e-7 and state()['selected']=={'x':2,'y':3})
        page.evaluate('window.__pesquisa.reset()')
        anchor_before=page.evaluate('''([x,y])=>window.__pesquisa.worldAt(x,y)''',[ox+150,oy+160])
        ptr(page,'pointerdown',1,ox+100,oy+160);ptr(page,'pointerdown',2,ox+200,oy+160)
        ptr(page,'pointermove',1,ox+70,oy+160);ptr(page,'pointermove',2,ox+230,oy+160)
        a=state();anchor_after=page.evaluate('''([x,y])=>window.__pesquisa.worldAt(x,y)''',[ox+150,oy+160])
        check(f'{vp} 2-finger zoom',abs(a['zoom']-1.6)<1e-7)
        check(f'{vp} pinch anchor invariant',math.dist([anchor_before['x'],anchor_before['y']],[anchor_after['x'],anchor_after['y']])<1e-7)
        ptr(page,'pointermove',1,ox+90,oy+180);ptr(page,'pointermove',2,ox+250,oy+180)
        translate_world=page.evaluate('''([x,y])=>window.__pesquisa.worldAt(x,y)''',[ox+170,oy+180])
        check(f'{vp} two finger pan+zoom anchored',math.dist([anchor_before['x'],anchor_before['y']],[translate_world['x'],translate_world['y']])<1e-7)
        ptr(page,'pointerup',1,ox+90,oy+180);ptr(page,'pointerup',2,ox+250,oy+180)
        check(f'{vp} no pinch click',state()['selected'] is None)
        page.evaluate('window.__pesquisa.reset()')
        ptr(page,'pointerdown',1,ox+80,oy+80);ptr(page,'pointercancel',1,ox+80,oy+80);ptr(page,'pointerup',1,ox+80,oy+80)
        check(f'{vp} cancel no click',state()['selected'] is None and state()['active']==0)
        page.locator('#size').select_option('20')
        check(f'{vp} 20x20 count',page.locator('.tile').count()==400)
        rng=random.Random(20261022);valid=True
        for i in range(100):
            z=rng.uniform(.65,3.5);x=rng.uniform(0,300);y=rng.uniform(0,300)
            page.evaluate('''([z,x,y])=>window.__pesquisa.setZoom(z,{x,y})''',[z,ox+x,oy+y])
            w=page.evaluate('''([x,y])=>window.__pesquisa.worldAt(x,y)''',[ox+x,oy+y])
            if not all(math.isfinite(w[k]) for k in ('x','y')): valid=False
        check(f'{vp} 100 anchor transforms finite',valid)
        page.evaluate('''()=>{window.__pesquisa.setZoom(999,{x:100,y:100})}''');check(f'{vp} zoom max clamp',abs(state()['zoom']-3.5)<1e-8)
        page.evaluate('''()=>{window.__pesquisa.setZoom(.0001,{x:100,y:100})}''');check(f'{vp} zoom min clamp',abs(state()['zoom']-.65)<1e-8)
        check(f'{vp} zero external request',len(requests)==0)
        if vp==(390,844):page.screenshot(path=str(Path(__file__).with_name('POC_ANDROID_VIEWPORT_390x844.png')),full_page=True)
        page.close()
    browser.close()
result={'environment':'Chromium headless Playwright; synthetic PointerEvents (NOT physical Android)', 'passed':sum(z['PASS'] for z in results),'total':len(results),'cases':results}
Path(__file__).with_name('RESULTADOS_POINTERS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps({'passed':result['passed'],'total':result['total'],'failed':[x for x in results if not x['PASS']]},ensure_ascii=False))
