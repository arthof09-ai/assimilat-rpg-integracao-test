import json,pathlib
from playwright.sync_api import sync_playwright
p=pathlib.Path(__file__).parent
with sync_playwright() as x:
 b=x.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
 page.set_content('<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><svg id="v" width="390" height="390"></svg><canvas id="c" width="390" height="390"></canvas></body></html>')
 info=page.evaluate('''() => {
 const svg=document.querySelector('#v'),canvas=document.querySelector('#c'),ctx=canvas.getContext('2d');
 const pct=(a,p)=>a[Math.min(a.length-1,Math.floor((a.length-1)*p))];const report=[];
 for (const count of [50,200,500]){
 for (const mode of ['svg','canvas']){
 const s=[];
 function draw(){if(mode==='svg'){svg.replaceChildren();const frag=document.createDocumentFragment();for(let i=0;i<count;i++){let o=document.createElementNS('http://www.w3.org/2000/svg','circle');o.setAttribute('cx',(i*47)%390);o.setAttribute('cy',(i*89)%390);o.setAttribute('r',3);o.setAttribute('fill','#89cff0');frag.append(o)}svg.append(frag)}else{ctx.clearRect(0,0,390,390);ctx.fillStyle='#89cff0';for(let i=0;i<count;i++){ctx.beginPath();ctx.arc((i*47)%390,(i*89)%390,3,0,2*Math.PI);ctx.fill();}}}
 for(let i=0;i<15;i++)draw();for(let i=0;i<100;i++){let t=performance.now();draw();s.push(performance.now()-t)}s.sort((a,b)=>a-b);report.push({mode,count,n:100,median_ms:pct(s,.5),p95_ms:pct(s,.95),max_ms:s[s.length-1]});
 }}return {userAgent:navigator.userAgent,view:innerWidth+'x'+innerHeight,results:report,limitations:['Synthetic visual mark drawing only','Canvas raster vs SVG nodes','No product UI frame, no true Android hardware','performance.now() resolution limits small measurements']};
 }''')
 b.close()
 (p/'BENCH_OVERLAY_SVG_CANVAS.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
 print(json.dumps(info,ensure_ascii=False,indent=2))
