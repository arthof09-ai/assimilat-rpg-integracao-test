# Fluxo enxuto de IA programadora — laboratório / proposta, não nova norma

**Escopo:** melhorar o trabalho dos Comestres existentes, sem novo executor ou sistema; ferramenta nativa do ChatGPT + GitHub conectado quando pertinente, R$ 0 adicional, foco Android. Inspirado em documentação pública PhotoCraft (AGENTS.md, control-protocol, comando central + corpus), fast-check e Playwright. Não copiar código externo para o Tabletop sem auditoria de licença.

1. **Fonte e fronteira (ANTES).** Ler o último RUN Notion, versão binária SHA-256 recuperada, arquivo/função alvo, limites Mestre-only/Party, e quem possui writer. Resultado `VERIFICADO` ou `HOLD`, nunca presumir.
2. **Hipótese pequena.** Escrever um único contrato testável, exemplo: “alterar parede por Apagar invalida snapshots com topologia antiga, e terreno puro não invalida”. Descrever casos positivo, negativo e legado antes de código.
3. **RED demonstrado.** Executar contra cópia TEST original e capturar falha; se fonte não disponível, marcar `NOT_RUN` e não usar “RED” indevidamente.
4. **GREEN isolado do Desenvolvedor.** Implementar pelo executor titular (não pelo Pesquisador), preservando contratos/versões/fixtures; jamais registrar PASS antes de executar a versão final.
5. **Auditor paralelo.** Comestre Pesquisador usa um teste independente de API/saída, casos gerados por semente fixa, `__proto__`, sequências, IDs, 7 cenários de mutação pontual; falha injetada prova sensibilidade do teste, não segurança absoluta.
6. **Regressão proporcional + navegador.** Rodar testes da operação afetada, legados obrigatórios, e Playwright em viewports móveis; screenshot diff somente mesmo ambiente/engine/fontes; teste Android real continua separado. Não confundir matriz sintética com campanha oficial.
7. **Custódia e entrega.** Manifesto de hashes, logs curtos, GitHub PR TEST se responsável autorizar, Notion laboratório + readback; `RUN-AFTER`/FIRST PENDING claros. Nunca atualizar `main`/Pages ou módulo de outro executor pela pesquisa. `NAC-PASS-02` apenas do escopo efetivamente rodado.

**Modelo de entrada breve ao Desenvolvedor:** fonte/hash → falha concreta → mudança candidata mínima → contratos `input/output/invariants` → testes RED/GREEN/negativos/legados → limite Android/segredos → ponto de retomada. O mesmo tipo de comando deve poder ser invocado pela UI e por um harness isolado, com diferenciação entre comando visual e ação oficial do VLAB.

**Recomendação de implementação incremental:** um registro de comandos *visuais não-canônicos* para marcador/anotação/régua/efeito somente de apresentação; manter modelo do RPG como autoridade, viewer como projeção e writer oficial protegido. Não recriar motor de combate nem backend.
