import tempfile,subprocess,json,pathlib
root=pathlib.Path(__file__).parent;src=(root/'command_overlay_research.js').read_text()
models=[
('duplicate_event','if(s.events.some(v=>v.id===e.id))throw Error(\'EVENT_DUP\');',';',"const a=R.event('a','SELECT_SET',{ids:[]});const b=R.apply(R.initial(),a);assert.throws(()=>R.apply(b,a))"),
('off_by_one','p.x>=0&&p.x<scene.w&&p.y>=0&&p.y<scene.h','p.x>=0&&p.x<=scene.w&&p.y>=0&&p.y<scene.h',"assert.throws(()=>R.apply(R.initial(),R.event('a','MEASURE_LINE',{a:{x:0,y:0},b:{x:20,y:0}})))"),
('synthetic_scope','e.syntheticFixture!==true','false',"assert.throws(()=>R.projectExternal({syntheticFixture:false,id:'a',sequence:1,kind:'ACTION'}))"),
('dangerous_props',"!['__proto__','constructor','prototype'].includes(k)&&cleanValue(x[k],depth+1)","cleanValue(x[k],depth+1)","const a=JSON.parse('{\"schema\":\"assim.inov.visual.test.v1\",\"id\":\"a\",\"sceneId\":\"scene-1\",\"type\":\"SELECT_SET\",\"payload\":{\"ids\":[],\"__proto__\":{\"forbidden\":true}}}');assert.throws(()=>R.apply(R.initial(),a))"),
('duplicate_selection','new Set(p.ids).size===p.ids.length&&p.ids.every(validId)','true&&p.ids.every(validId)',"assert.throws(()=>R.apply(R.initial(),R.event('a','SELECT_SET',{ids:['u1','u1']})))"),
('unknown_command','!COMMANDS.includes(e.type)','false',"assert.throws(()=>R.apply(R.initial(),R.event('a','DELETE_ALL',{})))"),
('no_scene_gate','if(!scene)throw Error(\'SCENE_MISSING\');',';',"assert.throws(()=>R.apply(R.initial(),R.event('a','SELECT_SET',{ids:[]},'scene-999')))"),
]
out=[]
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td)/'lib.js'
 for name,needle,repl,check in models:
  count=src.count(needle)
  if count!=1:
   out.append(dict(name=name,status='INVALID_MUTATION',occurrences=count));continue
  script=f"const R=require({json.dumps(str(p))});const assert=require('node:assert/strict');{check};"
  p.write_text(src)
  baseline=subprocess.run(['node','-e',script],capture_output=True,text=True)
  p.write_text(src.replace(needle,repl))
  mutated=subprocess.run(['node','-e',script],capture_output=True,text=True)
  status='KILLED' if baseline.returncode==0 and mutated.returncode!=0 else 'SURVIVED' if baseline.returncode==0 else 'BASELINE_BROKEN'
  out.append(dict(name=name,status=status,baseline_rc=baseline.returncode,mutated_rc=mutated.returncode,mutated_error=mutated.stderr.splitlines()[-1] if mutated.stderr else ''))
result=dict(suite='PESQ-INOV-006 intentional mutations of independent research model (NOT developer code)',mutants=len(out),killed=sum(x['status']=='KILLED' for x in out),failed=sum(x['status']!='KILLED' for x in out),results=out)
(root/'RESULT_MUTATION_006.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if result['failed']:raise SystemExit(1)
