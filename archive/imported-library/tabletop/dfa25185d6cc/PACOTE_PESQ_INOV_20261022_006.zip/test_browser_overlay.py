import json, pathlib, statistics
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).parent
html=(ROOT/'POC_VISUAL_OVERLAY_ANDROID_TEST.html').read_text()
checks=[];timings={}
def ok(name,result,detail=None):checks.append({'name':name,'status':'PASS' if result else 'FAIL', 'detail':detail});
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h in [(390,844),(360,740)]:
  page=browser.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,device_scale_factor=1)
  urls=[];page.on('request',lambda r:urls.append(r.url));js_errors=[];page.on('pageerror',lambda e:js_errors.append(str(e)))
  page.set_content(html,wait_until='load')
  suffix=f'{w}x{h}';init=page.evaluate('window.__inspect()')
  ok(f'{suffix}: 400 cells',init['boardCells']==400,init)
  ok(f'{suffix}: no overflow',page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
  page.locator('[data-x="2"][data-y="3"]').click()
  a=page.evaluate('window.__inspect()');ok(f'{suffix}: mark via click',a['annotations']==1 and a['overlayChildren']==2,a)
  page.locator('#measure').click()
  page.locator('[data-x="1"][data-y="1"]').click()
  page.locator('[data-x="4"][data-y="5"]').click()
  b=page.evaluate('window.__inspect()')
  ok(f'{suffix}: geometry no RPG',b['measurement']['cellsManhattan']==7 and b['measurement']['cellsStraight']==5,b['measurement'])
  ok(f'{suffix}: accessible status', 'não é deslocamento oficial' in page.locator('#status').inner_text())
  page.locator('#scene').click();c=page.evaluate('window.__inspect()')
  ok(f'{suffix}: scenes separate',c['activeScene']=='scene-2' and c['measurement'] is None,c)
  page.locator('#mark').click();page.locator('[data-x="6"][data-y="7"]').click()
  page.locator('#scene').click();d=page.evaluate('window.__inspect()');ok(f'{suffix}: notes isolated',d['overlayChildren']==2,d)
  ok(f'{suffix}: no network',len(urls)==0,urls)
  ok(f'{suffix}: no JS exception',len(js_errors)==0,js_errors)
  if w==390:page.screenshot(path=str(ROOT/'CAPTURA_BANCADA_390x844.png'),full_page=True)
  timings[suffix]=page.evaluate('''() => {
   const svg=document.querySelector('svg'),board=document.querySelector('#board');const times=[];
   for(let k=0;k<60;k++){let t0=performance.now();svg.replaceChildren();for(let j=0;j<50;j++){const el=document.createElementNS('http://www.w3.org/2000/svg','circle');el.setAttribute('cx',j*3);el.setAttribute('cy',j*3);el.setAttribute('r',2);svg.append(el)}times.push(performance.now()-t0)}
   times.sort((a,b)=>a-b);return {n:times.length,median:times[30],p95:times[Math.floor(times.length*.95)]};
  }''')
  page.close()
 browser.close()
summary={'suite':'Independent synthetic HTML/SVG overlay in Chromium Linux, mobile viewport emulation only','assertions':len(checks),'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'check_details':checks,'benchmark_svg_50_circle_60_rebuilds_ms':timings,'limitations':['Not Chrome Android physical','No website HTTP; HTML via Playwright page.set_content','No imported engine libraries','No real gameplay state, no canonical mechanics','SVG redraw microbenchmark not product performance']}
(ROOT/'RESULT_BROWSER_OVERLAY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:summary[k] for k in ('assertions','passed','failed','benchmark_svg_50_circle_60_rebuilds_ms')},ensure_ascii=False,indent=2))
if summary['failed']:raise SystemExit(1)
