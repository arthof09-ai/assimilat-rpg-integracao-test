const assert=require('node:assert/strict');const R=require('./command_overlay_research.js');
let checks=[];function T(name,f){try{f();checks.push({name,status:'PASS'});}catch(e){checks.push({name,status:'FAIL',error:String(e)});}}
const E=(id,type,p)=>R.event(id,type,p);
const base=R.initial();
T('initial valid',()=>assert.equal(R.assertState(base),true));
T('annotate produces one only',()=>{let s=R.apply(base,E('a1','ANNOTATION_ADD',{annotationId:'mark1',text:'  Fog test ',at:{x:2,y:3}}));assert.equal(s.scenes[0].annotations[0].text,'Fog test');assert.equal(base.scenes[0].annotations.length,0)});
T('remove annotation',()=>{let s=R.apply(base,E('a2','ANNOTATION_ADD',{annotationId:'mark1',text:'x',at:{x:2,y:3}}));s=R.apply(s,E('a3','ANNOTATION_REMOVE',{annotationId:'mark1'}));assert.equal(s.scenes[0].annotations.length,0)});
T('geometry sample',()=>{let s=R.apply(base,E('a4','MEASURE_LINE',{a:{x:1,y:1},b:{x:4,y:5}}));assert.equal(s.measurement.cellsManhattan,7);assert.equal(s.measurement.cellsStraight,5);assert.equal(s.measurement.kind,'GEOMETRY_ONLY_NO_RPG_RULE')});
T('selection stable',()=>{let s=R.apply(base,E('a5','SELECT_SET',{ids:['u1','u2']}));assert.deepEqual(s.selected,['u1','u2'])});
T('fx no gameplay',()=>{let s=R.apply(base,E('a6','FX_PULSE',{at:{x:2,y:2},style:'ring',durationMs:400}));assert.equal(s.fx.length,1);assert.equal(s.scenes[0].annotations.length,0)});
T('scene switch resets ephemeral',()=>{let s=R.initial();s.scenes.push({id:'scene-2',w:7,h:7,annotations:[]});s=R.apply(s,R.event('a7','SCENE_SET',{},'scene-2'));assert.equal(s.activeScene,'scene-2');assert.deepEqual(s.fx,[])});
T('replay deterministic',()=>{const ev=[E('b1','ANNOTATION_ADD',{annotationId:'mark1',text:'x',at:{x:2,y:3}}),E('b2','MEASURE_LINE',{a:{x:1,y:1},b:{x:4,y:5}})];assert.deepEqual(R.replay(base,ev),R.replay(base,ev))});
const negatives=[
 ['duplicate event',()=>{const e=E('q1','ANNOTATION_ADD',{annotationId:'one',text:'x',at:{x:1,y:1}});let s=R.apply(base,e);R.apply(s,e)}],
 ['duplicate annotation',()=>{let s=R.apply(base,E('q2','ANNOTATION_ADD',{annotationId:'one',text:'x',at:{x:1,y:1}}));R.apply(s,E('q3','ANNOTATION_ADD',{annotationId:'one',text:'x',at:{x:1,y:1}}))}],
 ['out-of-bounds',()=>R.apply(base,E('q4','MEASURE_LINE',{a:{x:0,y:0},b:{x:22,y:1}}))],
 ['nonfinite',()=>R.apply(base,E('q5','MEASURE_LINE',{a:{x:0,y:0},b:{x:NaN,y:1}}))],
 ['unknown command',()=>R.apply(base,E('q6','DELETE_ALL',{a:1}))],
 ['unknown scene',()=>R.apply(base,R.event('q7','FX_PULSE',{at:{x:0,y:0},style:'ring',durationMs:2},'scene-9'))],
 ['invalid type',()=>R.apply(base,E('q8','FX_PULSE',{at:{x:0,y:0},style:'flash',durationMs:2}))],
 ['too many selected',()=>R.apply(base,E('q9','SELECT_SET',{ids:Array.from({length:102},(_,i)=>'u'+i)}))],
 ['duplicate selection',()=>R.apply(base,E('q10','SELECT_SET',{ids:['u1','u1']}))],
 ['oversized text',()=>R.apply(base,E('q11','ANNOTATION_ADD',{annotationId:'aa',text:'A'.repeat(82),at:{x:2,y:2}}))],
 ['unbounded event',()=>R.apply(base,E('q12','MEASURE_LINE',{a:{x:0,y:0},b:{x:1,y:1},extra:'B'.repeat(4000)}))],
 ['scope gate',()=>R.projectExternal({syntheticFixture:false,id:'a',sequence:1,kind:'ACTION'})],
 ['invalid external',()=>R.projectExternal({syntheticFixture:true,id:'a',sequence:-1,kind:'ACTION'})],
 ['reserved key nested',()=>{const q=JSON.parse('{"schema":"'+R.VERSION+'","id":"q13","sceneId":"scene-1","type":"MEASURE_LINE","payload":{"a":{"x":0,"y":0},"b":{"x":1,"y":1},"__proto__":{"xx":1}}}');R.apply(base,q)}]
];
for(const [name,f] of negatives)T('reject: '+name,()=>{assert.throws(f)});
T('private fields stripped',()=>{const o=R.projectExternal({syntheticFixture:true,id:'a',sequence:1,kind:'ACTION',label:'test',secret:'should not leak',units:[{hp:999}]});assert.equal(JSON.stringify(o).includes('999'),false);assert.equal(o.geometry,null)});
T('unknown event fallback',()=>{const o=R.projectExternal({syntheticFixture:true,id:'a',sequence:1,kind:'NEW_KIND'});assert.equal(o.kind,'UNKNOWN')});
let seed=70622;function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
let accepted=0,rejected=0;
for(let i=0;i<700;i++){
 const a={x:Math.floor(rnd()*24)-2,y:Math.floor(rnd()*24)-2},b={x:Math.floor(rnd()*24)-2,y:Math.floor(rnd()*24)-2};
 const valid=[a,b].every(q=>q.x>=0&&q.x<20&&q.y>=0&&q.y<20);
 const before=JSON.stringify(base);
 try{const s=R.apply(base,E('f'+i,'MEASURE_LINE',{a,b}));assert.equal(valid,true);assert.equal(s.events.length,1);accepted++;}
 catch(err){assert.equal(valid,false);rejected++;}
 assert.equal(JSON.stringify(base),before)
}
T('700 seeded property probes accepted/rejected',()=>assert.equal(accepted+rejected,700));
T('event count bounded by test',()=>assert.equal(R.replay(base,[E('c1','SELECT_SET',{ids:[]}),E('c2','SELECT_SET',{ids:['u1']})]).revision,2));
const summary={suite:'PESQ-INOV-006 command/bridge synthetic',unit_assertions:checks.length,passed:checks.filter(x=>x.status==='PASS').length,failed:checks.filter(x=>x.status==='FAIL').length,property_probes:700,accepted,rejected,checks};
console.log(JSON.stringify(summary,null,2));if(summary.failed)process.exitCode=1;
