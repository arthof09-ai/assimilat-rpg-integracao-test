/* PESQ-INOV-006 independent, original synthetic study; no official Tabletop source. */
(function (root) {
'use strict';
const VERSION='assim.inov.visual.test.v1';
const COMMANDS=Object.freeze(['ANNOTATION_ADD','ANNOTATION_REMOVE','MEASURE_LINE','SELECT_SET','FX_PULSE','SCENE_SET']);
function isPlain(x){return x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;}
function cleanValue(x,depth=0){
 if(depth>9)return false;
 if(x===null||typeof x==='string'||typeof x==='boolean')return true;
 if(typeof x==='number')return Number.isFinite(x);
 if(Array.isArray(x))return x.length<=800&&x.every(v=>cleanValue(v,depth+1));
 if(!isPlain(x))return false;
 const keys=Object.keys(x);return keys.length<=80&&keys.every(k=>!['__proto__','constructor','prototype'].includes(k)&&cleanValue(x[k],depth+1));
}
const clone=x=>JSON.parse(JSON.stringify(x));
function validId(x){return typeof x==='string' && /^[a-zA-Z][a-zA-Z0-9_-]{0,39}$/.test(x);}
function initial(){return {schema:VERSION,revision:0,activeScene:'scene-1',scenes:[{id:'scene-1',w:20,h:20,annotations:[]}],selected:[],measurement:null,fx:[],events:[]};}
function findScene(state,id){return state.scenes.find(s=>s.id===id);}
function point(p,scene){return isPlain(p)&&Number.isInteger(p.x)&&Number.isInteger(p.y)&&p.x>=0&&p.x<scene.w&&p.y>=0&&p.y<scene.h;}
function assertState(s){if(!isPlain(s)||s.schema!==VERSION||!Number.isSafeInteger(s.revision)||s.revision<0||!Array.isArray(s.scenes)||s.scenes.length<1||s.scenes.length>8)throw Error('STATE_SCHEMA');if(!s.scenes.every(v=>validId(v.id)&&Number.isInteger(v.w)&&Number.isInteger(v.h)&&v.w>0&&v.w<=70&&v.h>0&&v.h<=70&&Array.isArray(v.annotations)&&v.annotations.length<=500))throw Error('SCENE');if(new Set(s.scenes.map(v=>v.id)).size!==s.scenes.length)throw Error('SCENE_DUP');if(!findScene(s,s.activeScene))throw Error('SCENE_REF');return true;}
function validateCommand(s,e){
 assertState(s);
 if(!isPlain(e)||!cleanValue(e)||e.schema!==VERSION||!validId(e.id)||!COMMANDS.includes(e.type)||!validId(e.sceneId)||!isPlain(e.payload)||JSON.stringify(e).length>2048)throw Error('COMMAND_SCHEMA');
 if(s.events.some(v=>v.id===e.id))throw Error('EVENT_DUP');
 const scene=findScene(s,e.sceneId);if(!scene)throw Error('SCENE_MISSING');
 const p=e.payload;
 if(e.type==='ANNOTATION_ADD'&&!(validId(p.annotationId)&&typeof p.text==='string'&&p.text.length<=80&&p.text.trim()&&point(p.at,scene)&&!scene.annotations.some(a=>a.id===p.annotationId)))throw Error('ANNOTATION_INVALID');
 if(e.type==='ANNOTATION_REMOVE'&&!(validId(p.annotationId)&&scene.annotations.some(a=>a.id===p.annotationId)))throw Error('ANNOTATION_MISSING');
 if(e.type==='MEASURE_LINE'&&!(point(p.a,scene)&&point(p.b,scene)))throw Error('MEASURE_INVALID');
 if(e.type==='SELECT_SET'&&!(Array.isArray(p.ids)&&p.ids.length<=100&&new Set(p.ids).size===p.ids.length&&p.ids.every(validId)))throw Error('SELECT_INVALID');
 if(e.type==='FX_PULSE'&&!(point(p.at,scene)&&['ring','spark'].includes(p.style)&&Number.isInteger(p.durationMs)&&p.durationMs>=0&&p.durationMs<=2500))throw Error('FX_INVALID');
 if(e.type==='SCENE_SET'&&e.sceneId!==s.activeScene&&!findScene(s,e.sceneId))throw Error('SCENE_INVALID');
 return scene;
}
function apply(s,e){
 const sc=validateCommand(s,e);
 const n=clone(s);const dest=findScene(n,e.sceneId),p=e.payload;
 if(e.type==='ANNOTATION_ADD')dest.annotations.push({id:p.annotationId,text:p.text.trim(),at:p.at});
 else if(e.type==='ANNOTATION_REMOVE')dest.annotations=dest.annotations.filter(a=>a.id!==p.annotationId);
 else if(e.type==='MEASURE_LINE'){
 const manhattan=Math.abs(p.b.x-p.a.x)+Math.abs(p.b.y-p.a.y);
 const euclidean=Math.hypot(p.b.x-p.a.x,p.b.y-p.a.y);
 n.measurement={sceneId:e.sceneId,a:p.a,b:p.b,cellsManhattan:manhattan,cellsStraight:Number(euclidean.toFixed(5)),kind:'GEOMETRY_ONLY_NO_RPG_RULE'};
 }
 else if(e.type==='SELECT_SET')n.selected=[...p.ids];
 else if(e.type==='FX_PULSE')n.fx=[...n.fx,{at:p.at,style:p.style,durationMs:p.durationMs,sceneId:e.sceneId}].slice(-15);
 else if(e.type==='SCENE_SET'){n.activeScene=e.sceneId;n.measurement=null;n.fx=[];n.selected=[];}
 n.revision++;n.events.push(clone(e));return n;
}
function replay(start,events){return events.reduce((s,e)=>apply(s,e),clone(start));}
function event(id,type,payload,sceneId='scene-1'){return {schema:VERSION,id,sceneId,type,payload};}
// Presentation boundary for synthetic external events; will not materialize privileged fields.
function projectExternal(e){
 if(!isPlain(e)||!cleanValue(e)||e.syntheticFixture!==true||!validId(e.id)||!Number.isSafeInteger(e.sequence)||e.sequence<0||typeof e.kind!=='string')throw Error('EXTERNAL_SCHEMA');
 const kind=['ACTION','RESOURCE','TURN','UNKNOWN'].includes(e.kind)?e.kind:'UNKNOWN';
 return {schema:'assim.inov.presentation.test.v1',id:e.id,sequence:e.sequence,kind,label:(typeof e.label==='string'?e.label:'').slice(0,60),geometry:null,scope:'SYNTHETIC_TEST_ONLY'};
}
const API={VERSION,COMMANDS,initial,apply,replay,event,projectExternal,assertState};
if(typeof module!=='undefined'&&module.exports)module.exports=API;
if(root)root.InovadorOverlayResearch=API;
})(typeof globalThis==='undefined'?undefined:globalThis);
