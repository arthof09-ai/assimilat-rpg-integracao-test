# PESQ-018 — Resultados objetivos / status

**ANTES:** TEST38 e Codex0.3.0 eram executáveis separadamente, sem uma intenção do frontend atravessando o HTTP do Codex e voltando à Arena. PESQ017 já havia provado incompatibilidades TEST37 × Codex0.2; NÃO refazer essas descobertas.

**DEPOIS:** canários versionados executaram **os componentes originais atuais** juntos nos testes científicos, confirmaram comportamento do transporte original, os pontos onde o frontend rejeita os frames e, separadamente, o bloqueio do browser atual por CSP e mock. Não foi implementada/implantada integração final; a pesquisa **evita um falso PASS** e especifica o menor trabalho do proprietário.

## Escopo de execução novo

| Evidência | Denominador | Resultado | Interpretação |
|---|---:|---|---|
| `tests/audit_crossversion030_018.mjs` | 22/22 | PASS | Codex Python original + Node TypeScript original, HTTP loopback/SQLite temporário. Inclui teste negativo de incompatibilidade TEST38, histórico Codex0.3, restore/papel e mecânica HOLD. |
| `tests/audit_live_browser_018.py` | 6/6 | PASS | HTTP Codex original respondeu; Chromium carregou HTML/JS originais pelo inspetor; conexão v2 ligada a fixture; CSP impediu fetch HTTP. **Não é browser HTTP E2E.** |
| Gate de sessão TEST38 ↔ Codex0.3 | — | **RED** | WELCOME/ACK/EVENT_BATCH Codex não são aceitos pelo validador TEST38, e o próprio frontend escolhe mock. |
| Gate de decisão VLAB | — | **HOLD** | ATTACK_REQUEST dá `MECHANICS_UNAVAILABLE`; sem ABI/mecânica oficial, nenhum recurso alterado. |

**28/28 checagens dirigidas novas PASS** nos instrumentos de pesquisa. Esse número mede **observações/asserções**, não funcionalidades. As incompatibilidades de integração são RED, portanto não anunciar 28/28 integração PASS.

## Falhas/restrições realmente encontradas

1. **Fronteira de execução (teste atual):** `public/room-client.js` atribui 
   `window.TabletopRoomV2TEST.createV2AdapterTransport(window.TabletopRoomV2TEST.mockV2TransportFactory)` em `roomConnect`. Portanto a opção v2 entra em fixture local, e não no Codex. **Responsável: Desenvolvedor** após pacto do contrato único.
2. **Restrição deliberada de conexão:** `public/index.html` tem `connect-src 'none'`. O Chromium aplicou a restrição durante `fetch` de teste. **Responsável: Desenvolvedor + owner único de rede**, manter política fechada até haver origem autorizada; ajustar apenas a origem concreta aprovável para a bancada TEST de conexão, sem abrir wildcard nem expor segredos.
3. **Contrato v2 diferente:** `ROOM_SCHEMA='assim.tabletop.room.bridge.test.v2'`, WELCOME com `view.actors` (rótulos, sem mapa), `ACK` com recibo tipado, `EVENT_BATCH`/`EVENT_QUERY`, `RESYNC→WELCOME` contrastam com `v:2` / `WELCOME.snapshot`/`ROOM_SNAPSHOT`, `ROOM_RECEIPT` e evento único. Os validadores TEST38 **rejeitam**; nenhuma transformação dinâmica inventada substitui geometria/owner/seq. **Responsável: Codex + Desenvolvedor**, fronteira única.
4. **Privacidade RESTORE observada:** Codex0.3 gerou `EVENT_BATCH` após restore via SQLite original; JSON para player2 omitiu `master_note/private_notes/FAKE_P1_ONLY` e preservou a nota da própria player2. O seletor TypeScript rejeitou injeção `master_note` aninhada. **PASS para identidades TEST**, não para auth/revogação/TLS real.
5. **Ambiente de pesquisa:** navegador Chromium bloqueou navegação a endereço de loopback (`ERR_BLOCKED_BY_ADMINISTRATOR`). Não forçar bypass para falsificar browser-E2E. Recurso TCP Python/Node em loopback **funcionou**, mas JavaScript do browser foi carregado da fonte original num DOM via inspector. Não foi testado CORS real do browser por essa razão.

## Gate A–F

| Gate | Estado | Prova necessária para avançar |
|---|---|---|
| A — contrato único | RED | executar módulo real TEST38 consumindo o wire real Codex versão convergida + geometria legitimada |
| B — intenção TEST ida-e-volta | RED | clique no frontend original -> HTTP/WebSocket competente -> recibo -> mesmo frontend, sem mock |
| C — ACK perdido/recuperação | PASS no Codex TEST, HOLD ponta a ponta | usar o mesmo ID após perda no UI conectado |
| D — privacidade pré-transmissão | PASS na projeção fake do Codex, HOLD produção | comparar RAW HTTP/WSS por identidade real e ACL do servidor |
| E — primeira batalha oficial VLAB | HOLD | ABI, resultado mecânico real, persistência, UI |
| F — multiplayer entre aparelhos | HOLD | HTTP/WSS seguro, roles reais, pelo menos dois aparelhos |

**Não chamar RESTORE fake de vitória de batalha, não converter relatório em código produtivo.**
