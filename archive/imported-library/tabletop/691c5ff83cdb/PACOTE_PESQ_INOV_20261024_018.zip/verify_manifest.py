#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
m=root/'MANIFEST_SHA256.json'
if not m.is_file():print('MANIFEST not yet created (staging)');sys.exit(0)
entries=json.loads(m.read_text())['files']
bad=[]
for name,expected in entries.items():
 p=root/name
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:bad.append(name)
print(f'MANIFEST {len(entries)-len(bad)}/{len(entries)} PASS')
if bad:print(bad);sys.exit(1)
