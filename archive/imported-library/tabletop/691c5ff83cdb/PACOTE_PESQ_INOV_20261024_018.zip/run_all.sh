#!/usr/bin/env bash
set -euo pipefail
: "${DEV38_ROOT:?Point to UNZIPPED original TEST38 source root}"
: "${CODEX030_ROOT:?Point to UNZIPPED original Codex 0.3.0 source root}"
test -f "$DEV38_ROOT/public/room-client.js"
test -f "$CODEX030_ROOT/experiments/tabletop_vlab_bridge/authority.py"
export NODE_OPTIONS="${NODE_OPTIONS:---experimental-strip-types}"
python3 verify_manifest.py
python3 tests/assert_sources_018.py
export PESQ018_EVIDENCE_DIR="${PESQ018_EVIDENCE_DIR:-${PWD}/reproduction_out}"
mkdir -p "$PESQ018_EVIDENCE_DIR"
python3 tests/audit_live_browser_018.py
node tests/audit_crossversion030_018.mjs
python3 verify_manifest.py
