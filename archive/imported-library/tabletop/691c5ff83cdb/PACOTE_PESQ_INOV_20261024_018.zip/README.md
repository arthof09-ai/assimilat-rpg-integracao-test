# PESQ-INOV-20261024-018 — Auditoria científica orientada à primeira ação funcional

**MESTRE-SIDE / TEST / sem publicação.** Continua PESQ-017. Não há backend, engine, combate, jogo ou frontend alternativo neste pacote. Todas as identidades são `FAKE_TEST_*` e todos os efeitos Codex são `FAKE_SET_LABEL` ou `MECHANICS_UNAVAILABLE`.

## Achado principal

O **TEST38** ainda não tem um caminho funcional para enviar uma intenção ao servidor Codex 0.3: `room-client.js` liga a opção v2 diretamente a `mockV2TransportFactory`; `public/index.html` define `connect-src 'none'`; Codex usa HTTP loopback, identidade FAKE e outro esquema. Isso é uma fronteira de produto intencional/incompleta, **não uma falha de segurança a consertar abrindo CSP sem autorização**. Testes da versão 0.3 demonstram recibos, EVENT_BATCH, projeção antes da serialização e `ATTACK_REQUEST` bloqueado; o validador TEST38 real continua rejeitando seus envelopes. Não bastam duas suítes PASS independentes para anunciar Gate A/B.

## Novidade em relação à PESQ-017

- Inspeção e execução dos **bytes físicos TEST38 e Codex 0.3.0**; PESQ017 testava TEST37 × Codex0.2.0.
- Prova Chromium sobre DOM/JS original, confirmando conexão DEMO ligada a mock e CSP original efetivamente bloqueando `fetch`. Limitação de ambiente: Chromium desta instância impede navegação para URL HTTP loopback por política do administrador; HTML exato injetado em DOM e JS exato avaliado por inspector, **não é browser↔Codex E2E**.
- Execução **HTTP TCP real** do servidor Python Codex0.3 com SQLite descartável e TypeScript original (`RoomV2Adapter`,`BridgeClient`,`selectNewEvents`) contra validadores JS TEST38: `WELCOME`, `ACK`, `EVENT_BATCH`, `RESYNC`, EVENT_QUERY e recibos.
- Auditoria adicional `FAKE_RESTORE` no **EVENT_BATCH entregue à player2**: payload bruto depois de projetado não contém notas Mestre nem player1; injeção de `master_note` aninhada é recusada pelo seletor antes da apresentação. Autenticação real/revogação não demonstradas.

## Como reproduzir

1. Recuperar de Biblioteca Mestre **originais**:
   - `PACOTE_TECNICO_TABLETOP_TEST37_A_TEST38_20261024.zip`, SHA `085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c`.
   - `ponte-vlab-tabletop-0.3.0-test-events.zip`, SHA `78760b79e842f83625daf8c17c2f1bf56c1320a9b35408f949f6fb82648afda`.
2. Descompactar os dois para caminhos distintos (sem sobrescrever). Definir `DEV38_ROOT` apontando ao primeiro diretório, `CODEX030_ROOT` ao segundo.
3. Rodar `bash run_all.sh`. Requer **Python 3.11+**, **Node 22.16+**, `NODE_OPTIONS=--experimental-strip-types` para Node 22, Chromium + Playwright Python para teste DOM, sockets TCP loopback para teste HTTP. Não utiliza npm install nem conta, não faz deploy. Se Chromium/site localhost for bloqueado pelo ambiente, o teste usa DOM/JS originais via inspector, nunca contabiliza isso como E2E via navegador.
4. Conferir `evidence/live_browser_018.json` e `evidence/crossversion030_018.json`. A aprovação dos canários é **PASS sobre a detecção fiel de incompatibilidades**; o contrato integrado é **RED**.

## Proibições de interpretação

- `ROOM_UPDATED` nunca é `MOVE_CONFIRMED` por conveniência; TEST38 já corrigiu o bug da PESQ016.
- `FAKE_SET_LABEL` não vira mapa, unidade XY, ataque ou consequência oficial.
- `EVENT_BATCH` identificável não substitui snapshot de geometria legitimada ou revisão/seq tático do frontend.
- `ACK ACCEPTED` de transporte sintético não aplica Vida/Alma/PA/dano.
- Não contornar CSP/ACL para obter PASS cosmético; nenhuma autenticação real é produzida pelos tokens `FAKE_TEST_*`.

Ver `report/RESULTADOS_E_GATES_018.md` e `contract/HANDOFF_PROPRIETARIOS_018.md`. A estrutura canônica continua no **Laboratório do Inovador existente**, sem duplicar operação ou normativas.
