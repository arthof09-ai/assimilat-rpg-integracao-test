#!/usr/bin/env python3
import hashlib,os,pathlib,json
root=pathlib.Path(__file__).resolve().parents[1]
dev=pathlib.Path(os.environ['DEV38_ROOT']);codex=pathlib.Path(os.environ['CODEX030_ROOT'])/'experiments/tabletop_vlab_bridge'
files={
 'TEST38/index.html': (dev/'public/index.html','42e30d86bb441219ae3bcb5c92ea070e838de12757ec0ff69e445493cb1681b9'),
 'TEST38/room-client.js': (dev/'public/room-client.js','bce07e7e0278deac1ad00a84ddf31a19ec8d0d41cbb4113addc0da1308492d1e'),
 'TEST38/room-v2-adapter.js': (dev/'public/room-v2-adapter.js','7fb90ffee1a089fbe9ba9501c8f2b42bbb889602a6b1b2a658df4787dee7264b'),
 'Codex0.3/authority.py': (codex/'authority.py','51453fc77fa6cae6f2801e0e6038cbf9082e2a00bc1c86833eff6b7797484cb4'),
 'Codex0.3/client.ts': (codex/'client.ts','25726f5009f56b5afd17d25f4be18d452533083fa495d57ba07d93aeb5722cbf'),
 'Codex0.3/room_adapter.ts': (codex/'room_adapter.ts','922ac08153f14b3199297ceb840a85a96707d3ae5ad004a4564388e94ef583d6'),
 'Codex0.3/receipt_contract.py': (codex/'receipt_contract.py','f2ae774e0bd3ac47e5f27bf4b83a21308a450f0c1720a9b7a54083689bd98699'),
}
for name,(p,h) in files.items():
 if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise SystemExit('FAIL source changed: '+name)
print(f'SOURCE BYTE HASHES {len(files)}/{len(files)} PASS')
