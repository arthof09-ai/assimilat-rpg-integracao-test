/* PESQ018: Original Codex 0.3.0 HTTP+SQLite vs TEST38 original JS validators.
 * No patches or motor. Synthetic FAKE_* data; failures intentionally tested.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync,mkdirSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const codeRoot=process.env.CODEX030_ROOT;
const devRoot=process.env.DEV38_ROOT;
if(!codeRoot||!devRoot)throw Error('set CODEX030_ROOT and DEV38_ROOT');
const core=path.join(codeRoot,'experiments/tabletop_vlab_bridge');
const {BridgeClient}=await import(pathToFileURL(path.join(core,'client.ts')).href);
const {RoomV2Adapter,ROOM_SCHEMA,selectNewEvents}=await import(pathToFileURL(path.join(core,'room_adapter.ts')).href);
const ctx=vm.createContext({window:{}});
vm.runInContext(fs.readFileSync(path.join(devRoot,'public/room-v2-adapter.js'),'utf8'),ctx);
const dev=ctx.window.TabletopRoomV2TEST;
const temp=mkdtempSync(path.join(tmpdir(),'pesq018-codex-'));
const p=spawn('python3',['-u',path.join(core,'authority.py'),'--db',path.join(temp,'temp.sqlite'),'--port','0'],{stdio:['ignore','pipe','pipe']});
const buf=await new Promise((resolve,reject)=>{let s='';p.stdout.on('data',d=>{s+=d;const i=s.indexOf('\n');if(i>=0)resolve(s.slice(0,i));});p.on('exit',c=>reject(Error('python exit '+c)));});
const endpoint=JSON.parse(buf).url;
let checks=[];
function check(name,ok,detail=''){checks.push({name,pass:Boolean(ok),detail});assert(ok,name+' '+detail)}
const roomId='audit18';
const master=new BridgeClient(endpoint,'FAKE_TEST_MASTER','master');
const p1=new BridgeClient(endpoint,'FAKE_TEST_PLAYER1','player1');
const p2=new BridgeClient(endpoint,'FAKE_TEST_PLAYER2','player2');
const m=new RoomV2Adapter(master),a=new RoomV2Adapter(p1),b=new RoomV2Adapter(p2);
const frame=(type,more={})=>({schema:ROOM_SCHEMA,type,roomId,...more});
const manifest={environment:'Node22.16 strip-types + Codex original CPython HTTP+SQLite, no browser network/production',checks};
try {
 const created=await master.request({schema_version:1,op:'create',room_id:roomId,client_action_id:'create18',expected_revision:0});
 check('Created TEST room on original HTTP authority',created.ok&&created.revision===0);
 const welcomes=await Promise.all([m.exchange(frame('JOIN')),a.exchange(frame('JOIN')),b.exchange(frame('JOIN'))]);
 check('Original Codex returns role-scoped WELCOME for three FAKE profiles',welcomes.every(x=>x.type==='WELCOME'&&x.revision===0));
 check('TEST38 original validator RED against Codex WELCOME',welcomes.every(x=>dev.validV2Response(x)===false),'No geometry, player ID, session epoch, members');
 const bytes=welcomes.map(x=>JSON.stringify(x));
 check('Codex player response bytes omit synthetic master and other-player notes',bytes.slice(1).every((x,i)=>!x.includes('master_note')&&!x.includes('private_notes')&&!x.includes('FAKE_MASTER_ONLY')&& !x.includes(i===0?'FAKE_P2_ONLY':'FAKE_P1_ONLY')));
 const submitted=await a.exchange(frame('INTENT',{commandId:'label18',actorId:'actor-1',baseRevision:0,action:{kind:'FAKE_SET_LABEL',label:'TEST public label'}}));
 check('Codex actual SQLite transaction returns durable ACK for fake label',submitted.status==='ACCEPTED'&&submitted.receipt?.public_event_id==='event-1');
 const found=await a.exchange(frame('RECEIPT_QUERY',{commandId:'label18'}));
 check('Codex same-ID receipt reproducible after submit',JSON.stringify(found)===JSON.stringify(submitted));
 check('TEST38 original validator RED against authenticated Codex ACK',dev.validV2Response(found)===false);
 const batch=await b.exchange(frame('EVENT_QUERY',{afterRevision:0}));
 check('Codex 0.3 actual HTTP history produces EVENT_BATCH',batch.type==='EVENT_BATCH'&&batch.events.length===1&&batch.events[0].kind==='ROOM_UPDATED');
 check('TEST38 original cannot ingest EVENT_BATCH',dev.validV2Response(batch)===false);
 const selected=selectNewEvents(batch,roomId,0,'player2');
 check('Codex 0.3 event selector applies one display event without declaring movement',selected.status==='APPLY'&&selected.events[0].sourceKind==='FAKE_SET_LABEL'&&selected.events[0].kind==='ROOM_UPDATED');
 const selectedAgain=selectNewEvents(batch,roomId,1,'player2');
 check('Codex selector suppresses duplicate playback',selectedAgain.status==='DUPLICATE'&&selectedAgain.events.length===0);
 const resync=await a.exchange(frame('RESYNC'));
 check('Codex 0.3 RESYNC returns WELCOME, not TEST38 SNAPSHOT',resync.type==='WELCOME'&&dev.validV2Response(resync)===false);
 const before=await p1.request({schema_version:1,op:'view',room_id:roomId});
 const blocked=await a.exchange(frame('INTENT',{commandId:'attack18',actorId:'actor-1',baseRevision:1,action:{kind:'ATTACK_REQUEST',turn_id:'turn18',target:{kind:'UNIT',actor_id:'actor-2'},context:{scene_id:'scene18',ability_id:'basic_attack'}}}));
 const after=await p1.request({schema_version:1,op:'view',room_id:roomId});
 check('ATTACK_REQUEST rejected without official VLAB; no state changed',blocked.status==='REJECTED'&&blocked.code==='MECHANICS_UNAVAILABLE'&&JSON.stringify(before)===JSON.stringify(after));
 const afterBatch=await b.exchange(frame('EVENT_QUERY',{afterRevision:1}));
 check('Rejected attack creates no spurious event',afterBatch.events.length===0&&afterBatch.revision===1);
 const noResult=await b.exchange(frame('RECEIPT_QUERY',{commandId:'label18'}));
 check('Other FAKE identity does not obtain original receipt',noResult.status==='UNKNOWN'&&noResult.code==='NOT_FOUND');
 // New adversarial role-projection gate on Codex 0.3 EVENT_BATCH after RESTORE.
 const cp=await master.request({schema_version:1,op:'checkpoint',room_id:roomId,client_action_id:'cp18',expected_revision:1});
 check('Master may checkpoint TEST room without advancing revision',cp.ok===true&&cp.revision===1);
 const next=await a.exchange(frame('INTENT',{commandId:'label18b',actorId:'actor-1',baseRevision:1,action:{kind:'FAKE_SET_LABEL',label:'TEST later public label'}}));
 check('Second synthetic label creates revision two',next.status==='ACCEPTED'&&next.receipt?.revision===2);
 const restored=await master.request({schema_version:1,op:'restore',room_id:roomId,client_action_id:'restore18',expected_revision:2,checkpoint_id:cp.checkpoint_id});
 check('Master RESTORE emits revision three under original authority',restored.ok===true&&restored.revision===3);
 const playerHistory=await b.exchange(frame('EVENT_QUERY',{afterRevision:1}));
 const historyBytes=JSON.stringify(playerHistory);
 check('P2 event batch has proper event order and RESTORE data',playerHistory.events.length===2&&playerHistory.events[0].revision===2&&playerHistory.events[1].revision===3&&playerHistory.events[1].sourceKind==='FAKE_RESTORE');
 check('P2 raw EVENT_BATCH excludes master and P1 synthetic notes before presentation',!historyBytes.includes('master_note')&&!historyBytes.includes('private_notes')&&!historyBytes.includes('FAKE_MASTER_ONLY')&&!historyBytes.includes('FAKE_P1_ONLY')&&historyBytes.includes('FAKE_P2_ONLY'));
 const benign=selectNewEvents(playerHistory,roomId,1,'player2');
 check('Codex selector accepts role-projected history after RESTORE',benign.status==='APPLY'&&benign.events.length===2);
 const malicious=JSON.parse(historyBytes);malicious.events[1].data.view.master_note='FAKE_MASTER_ONLY_INJECTED';
 let rejected=false;
 try{selectNewEvents(malicious,roomId,1,'player2')}catch(e){rejected=e.code==='INVALID_FRAME'}
 check('Codex selector rejects nested master-only injection before rendering',rejected);
 manifest.security={checkpoint:cp.checkpoint_id,historyAfterRestore:playerHistory,clientSelection:benign.status,maliciousFrameRejected:rejected};
 manifest.p0={roomId,submitted,receipt:found,history:batch,selected,blocked,playerViews:welcomes.slice(1)};
 manifest.status='PASS directed probes, FAIL frontend protocol integration';
} finally {p.kill('SIGTERM');rmSync(temp,{recursive:true,force:true});}
const dst=path.resolve(process.env.PESQ018_EVIDENCE_DIR || 'evidence','crossversion030_018.json');mkdirSync(path.dirname(dst),{recursive:true});
writeFileSync(dst,JSON.stringify({checks,total:checks.length,passed:checks.filter(c=>c.pass).length,...manifest},null,2)+'\n');
console.log(JSON.stringify({passed:checks.length,total:checks.length,result:'SOURCE_PROTOCOL_RED',codex_runtime:'TRUE_LOCAL_HTTP',vLab:'NOT_EXECUTED'}));
