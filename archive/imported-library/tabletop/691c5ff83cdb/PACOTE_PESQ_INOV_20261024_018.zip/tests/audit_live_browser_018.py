#!/usr/bin/env python3
"""Read-only cross-boundary research: original TEST38 DOM/JS vs original Codex03 TCP/SQLite. Synthetic only."""
import json,os,pathlib,subprocess,sys,tempfile,urllib.request
from playwright.sync_api import sync_playwright
DEV=pathlib.Path(os.environ['DEV38_ROOT']); CODEX=pathlib.Path(os.environ['CODEX030_ROOT']);
EVIDENCE=pathlib.Path(os.environ.get('PESQ018_EVIDENCE_DIR',str(pathlib.Path(__file__).resolve().parents[1]/'evidence')));EVIDENCE.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name,ok,observed=None):
 checks.append({'gate':name,'pass':bool(ok),'observed':observed})
 if not ok:raise AssertionError(name+': '+str(observed))

def send(url,token,body):
 req=urllib.request.Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
 with urllib.request.urlopen(req,timeout=5) as response:return response.status,json.loads(response.read())
with tempfile.TemporaryDirectory(prefix='pesq018-http-') as temp:
 auth=CODEX/'experiments/tabletop_vlab_bridge/authority.py'
 process=subprocess.Popen([sys.executable,'-u',str(auth),'--db',str(pathlib.Path(temp)/'test.sqlite'),'--port','0'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  line=process.stdout.readline();url=json.loads(line)['url']
  check('Codex original running on loopback',url.startswith('http://127.0.0.1:') and url.endswith('/bridge'),url)
  status,resp=send(url,'FAKE_TEST_MASTER',{'schema_version':1,'op':'create','room_id':'audit018','client_action_id':'create018','expected_revision':0})
  check('Codex original TCP+SQLite POST success',status==200 and resp.get('ok') is True and resp.get('revision')==0,{'http':status,'revision':resp.get('revision')})
  with sync_playwright() as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
   try:
    page=browser.new_page(viewport={'width':390,'height':844})
    # Browser administrator blocks local URL navigation; the unmodified HTML/JS
    # is loaded from bytes into DOM, with JS via inspector evaluation. Not a network E2E.
    page.set_content((DEV/'public/index.html').read_text(),wait_until='load')
    for file in ('app.js','room-v2-adapter.js','room-client.js'):page.evaluate((DEV/'public'/file).read_text())
    meta=page.evaluate('''() => ({csp:document.querySelector('meta[http-equiv="Content-Security-Policy"]').content,api:!!window.TabletopRoomTEST,v2:!!window.TabletopRoomV2TEST})''')
    check('Unmodified TEST38 original HTML and JS loaded into Chromium',meta['api'] and meta['v2'])
    check('TEST38 original CSP blocks fetch and WebSocket by default',"connect-src 'none'" in meta['csp'],meta['csp'])
    page.select_option('#roomProtocol','v2');page.click('#roomConnect')
    state=page.evaluate('''() => ({connected:window.TabletopRoomTEST.client.connected, status:window.TabletopRoomTEST.client.status, protocol:window.TabletopRoomTEST.client.protocol, mockPeerCount:window.TabletopRoomV2TEST.mock.peers.size})''')
    check('TEST38 v2 connection bound to mock, not bridge TCP',state['connected'] and state['mockPeerCount']>=1,state)
    page.evaluate('''() => {window.__violations=[];document.addEventListener('securitypolicyviolation',e=>window.__violations.push({directive:e.violatedDirective,blocked:e.blockedURI}));}''')
    fetchresult=page.evaluate('''async u => {try{await fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});return 'allowed'}catch(e){return 'blocked:'+e.name}}''',url)
    page.wait_for_timeout(100);violations=page.evaluate('window.__violations')
    check('Chromium enforces TEST38 original CSP against HTTP',fetchresult.startswith('blocked:') and any('connect-src' in e['directive'] for e in violations),{'fetch':fetchresult,'violations':violations})
   finally:browser.close()
 finally:
  process.terminate();process.wait(timeout=5)
summary={'pass':len(checks),'total':len(checks),'checks':checks,'end_to_end':'RED_NOT_CONNECTED','connection_type':'Codex TCP original + TEST38 DOM inspector; NO browser TCP integration','environment_blocker':'Browser administrator prevents navigation to 127.0.0.1; DOM and JS original still executed','roles':'FAKE ONLY','official_vlab':False}
(EVIDENCE/'live_browser_018.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks_pass':len(checks),'checks_total':len(checks),'integration':'RED_NOT_CONNECTED','csp':'BLOCKED','transport':'MOCK'},ensure_ascii=False))
