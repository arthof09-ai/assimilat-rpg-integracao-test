# Handoff de aceitação mínima da integração — executores competentes

## Desenvolvedor TEST38 (único frontend original)

**GATE REAL antes de qualquer HUD extra:** executar o teste de modo TEST com `RoomClient` e `room-v2-adapter.js` existentes, sem sobrescrever suas bases, num modo explicitamente distinto de `mockV2TransportFactory`. `ROOM_JOINED` deve resultar de um frame validado da autoridade, e o HUD jamais pode dizer “sala compartilhada conectada” quando apenas mock está ativo. Proteger v1/v2 journal existente e conservar o modo DEMO offline.

**Security fence:** `connect-src 'none'` é defesa atual intencional. Não remover por conveniência: quando uma origem única segura e competente estiver escolhida, adicionar SOMENTE a origem de conexão necessária na CSP da versão TEST autorizada, com autenticação e projeção pré-rede. Para ambiente Android remoto, `127.0.0.1` aponta ao próprio celular; não é endereço do host Codex. A origem HTTP do Codex0.3 em loopback não está pronta para autenticação remota/TLS.

**Canários de aceite:** (1) view ligada à identidade realmente autenticada; (2) geometria vem de fonte competente — `sceneId,n,walls,units,markers`, propriedade/owner IDs; (3) `WELCOME` uma vez, `RESYNC→SNAPSHOT` ou novo protocolo consensuado; (4) `RECEIPT NOT_FOUND` mantém UNKNOWN e mesmo ID; (5) EVENT_BATCH não vira movimento; (6) click unidade→ação→alvo não envia `ATTACK_REQUEST` até VLAB válido; (7) tokens de player nunca veem bytes de Mestre.

## Codex 0.3.0 (único owner de ponte e autoridade de teste)

Não duplicar recibo/outbox: ele já funciona para FX em Python+SQLite. Confrontar/negociar exatamente 1 protocolo final com Dev, entregando vector real produzido pela ponte; **não transformar `FAKE_SET_LABEL` em movimento**. Demonstrar ID, `revision`, ordem de eventos e `ROOM_SNAPSHOT`/`EVENT_BATCH` sem inventar `seq`; schema coerente. A geometria autorizada deve vir do estado visual sob owner competente, não de `view.actors` transformado em XY arbitrário. Manter retorno `MECHANICS_UNAVAILABLE` sem alterar Vida/Alma/PA.

**Canário de integração obrigatório:** validar no navegador real o fluxo cliente→autoridade→recibo→cliente sem usar só demonstração `integration_example.mjs`. Após a primeira ação, simular perda ACK e consultar o mesmo commandId sem duplicar efeito. Capturar bytes de saída por player. Nenhuma mudança em `main` ou `gh-pages` sem autorização.

## Executor VLAB (autoridade mecânica exclusiva)

Aguardar/fornecer ABI homologada com versão, provenance do estado do combate e identidade do actor/action/target, escopo legal, autorização de reação, correlacionamento de `commandId` e `revision` da sala, receipt mecânico idempotente e projeção pré-transporte. **PROPOSTO**, não disponível nesta pesquisa. Nenhuma fórmula paralela.

## Pesquisador (próxima auditoria)

Executar primeiro canários PESQ018 contra **NOVOS bytes** Codex/Dev, reabrir RED/FAIL afetados e somente então fazer regressão proporcional. Evitar repetir PESQ012–017, provas mecânicas fictícias, fazer demonstração de lobby ou expandir matrizes por si só.
