/* Assimilação Tabletop TEST34 — FRONTEND de sala, somente fixtures sintéticas.
 * Sem autenticação, autoridade VLAB, coordenação de servidor ou ACL de produção.
 * Dados reais só podem chegar de backend competente com projeção por papel ANTES do envio.
 * A seleção de perfil aqui é uma DEMO local e nunca concede permissões reais.
 */
(()=>{'use strict';
const SCHEMA='assim.tabletop.room.presentation.v1';
const LIMIT=65536, VALID_N=[5,7,10,20];
const byId=id=>document.getElementById(id);
const safeId=s=>typeof s==='string'&&/^[a-z][a-z0-9_-]{0,31}$/.test(s)&&!['constructor','prototype','__proto__'].includes(s);
const exact=(v,required,optional=[])=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.getPrototypeOf(v)===Object.prototype&&required.every(k=>Object.hasOwn(v,k))&&Object.keys(v).every(k=>required.includes(k)||optional.includes(k));
const cellKey=(x,y)=>`${x},${y}`;
const coord=(s,n)=>{if(typeof s!=='string'||!/^\d+,\d+$/.test(s))return false;const [x,y]=s.split(',').map(Number);return Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<n&&y<n&&cellKey(x,y)===s;};
const validRole=x=>x==='gm'||x==='player';
function checkSnapshot(s){
 if(!exact(s,['n','units','walls'])||!VALID_N.includes(s.n)||!Array.isArray(s.units)||s.units.length>30||!Array.isArray(s.walls)||s.walls.length>s.n*s.n)return false;
 const occupied=new Set(),ids=new Set(),walls=new Set();
 for(const k of s.walls){if(!coord(k,s.n)||walls.has(k))return false;walls.add(k);}
 for(const u of s.units){
  if(!exact(u,['id','name','mark','team','ownerId','x','y'])||!safeId(u.id)||ids.has(u.id)||typeof u.name!=='string'||u.name.length>45||!u.name.length||/[<>\u0000-\u001f]/.test(u.name)||typeof u.mark!=='string'||u.mark.length<1||u.mark.length>2||/[<>\u0000-\u001f]/.test(u.mark)||!['ally','enemy','neutral'].includes(u.team)||!(u.ownerId===null||safeId(u.ownerId))||!Number.isInteger(u.x)||!Number.isInteger(u.y)||u.x<0||u.y<0||u.x>=s.n||u.y>=s.n||walls.has(cellKey(u.x,u.y))||occupied.has(cellKey(u.x,u.y)))return false;
  ids.add(u.id);occupied.add(cellKey(u.x,u.y));
 }return true;
}
function checkPacket(p){
 if(!exact(p,['schema','type','roomId','revision','seq'],['role','selfId','members','snapshot','intentId','reason','kind','actorId'])||p.schema!==SCHEMA||!safeId(p.roomId)||!Number.isSafeInteger(p.revision)||p.revision<0||!Number.isSafeInteger(p.seq)||p.seq<0)return false;
 if(p.type==='ROOM_JOINED'){
  if(!exact(p,['schema','type','roomId','revision','seq','role','selfId','members','snapshot'])||!validRole(p.role)||!safeId(p.selfId)||!Array.isArray(p.members)||p.members.length>3||!checkSnapshot(p.snapshot))return false;
  const unique=new Set();for(const m of p.members){if(!exact(m,['id','label','role'])||!safeId(m.id)||unique.has(m.id)||!validRole(m.role)||typeof m.label!=='string'||m.label.length<1||m.label.length>34||/[<>\u0000-\u001f]/.test(m.label))return false;unique.add(m.id);}return p.members.some(m=>m.id===p.selfId&&m.role===p.role);
 }
 if(p.type==='ROOM_SNAPSHOT')return exact(p,['schema','type','roomId','revision','seq','snapshot'])&&checkSnapshot(p.snapshot);
 if(p.type==='ROOM_EVENT')return exact(p,['schema','type','roomId','revision','seq','intentId','kind','actorId','snapshot'])&&safeId(p.intentId)&&['MOVE_CONFIRMED','ROOM_UPDATED'].includes(p.kind)&&safeId(p.actorId)&&checkSnapshot(p.snapshot);
 if(p.type==='ROOM_REJECT')return exact(p,['schema','type','roomId','revision','seq','intentId','reason'])&&safeId(p.intentId)&&['STALE_REVISION','NOT_OWNER','INVALID_INTENT','DUPLICATE_INTENT','UNAUTHORIZED','ROOM_ERROR'].includes(p.reason);
 return false;
}
function checkOutgoing(p){
 if(p?.schema!==SCHEMA||!safeId(p.roomId))return false;
 if(p.type==='ROOM_JOIN')return exact(p,['schema','type','roomId','profile'])&&['gm','p1','p2'].includes(p.profile);
 if(p.type==='ROOM_RESYNC')return exact(p,['schema','type','roomId','knownRevision','knownSeq'])&&Number.isSafeInteger(p.knownRevision)&&p.knownRevision>=0&&Number.isSafeInteger(p.knownSeq)&&p.knownSeq>=0;
 return p.type==='ROOM_INTENT'&&exact(p,['schema','type','roomId','revision','intentId','action','unitId','x','y'])&&Number.isSafeInteger(p.revision)&&p.revision>=0&&safeId(p.intentId)&&p.action==='MOVE_REQUEST'&&safeId(p.unitId)&&Number.isInteger(p.x)&&Number.isInteger(p.y)&&p.x>=0&&p.y>=0&&p.x<20&&p.y<20;
}
class RoomClient{
 constructor({transportFactory,onUpdate,nonce='session'}={}){this.factory=transportFactory;this.onUpdate=onUpdate||(()=>{});this.nonce=safeId(nonce)?nonce:'session';this.epoch=0;this.reset();}
 reset(){this.connected=false;this.connecting=false;this.roomId='arena-test';this.selfId=null;this.role=null;this.profile=null;this.revision=0;this.seq=0;this.counter=this.counter||0;this.snapshot=null;this.members=[];this.pending=new Map();this.transport=null;this.error='';this.status='offline';this.log=[];}
 update(message){if(message){this.log.unshift(message);this.log=this.log.slice(0,10);}this.onUpdate(this);}
 connect(profile='gm'){
  if(!['gm','p1','p2'].includes(profile))throw Error('Perfil de demonstração inválido');
  this.disconnect();this.profile=profile;this.status='connecting';this.connecting=true;this.update('Abrindo transporte sintético local…');
  if(typeof this.factory!=='function')throw Error('Transportador de sala ainda não disponível');
  try{const epoch=this.epoch;this.transport=this.factory({onMessage:data=>{if(epoch===this.epoch)this.receive(data);},onClose:()=>{if(epoch===this.epoch)this.handleDisconnect();}});const msg={schema:SCHEMA,type:'ROOM_JOIN',roomId:this.roomId,profile};if(!checkOutgoing(msg))throw Error('Entrada não validada');this.transport.send(JSON.stringify(msg));}catch(e){this.error='Não foi possível conectar: '+e.message;this.status='error';this.connecting=false;this.update(this.error);}
 }
 handleDisconnect(){this.connected=false;this.connecting=false;if(this.status==='error'){this.update();return;}this.status='offline';this.update('Transporte encerrado; nenhum evento local aplicado.');}
 disconnect(){this.epoch++;const old=this.transport;this.transport=null;if(old){try{old.close();}catch(e){}}this.reset();this.onUpdate(this);}
 receive(raw){
  try{
   if(typeof raw!=='string'||raw.length>LIMIT)throw Error('Pacote excede limite');
   const p=JSON.parse(raw);if(!checkPacket(p)||p.roomId!==this.roomId)throw Error('Projeção rejeitada pelo contrato fechado');
   if(p.type==='ROOM_JOINED'){
    if(!this.connecting||p.selfId!==this.profile||(this.profile==='gm')!==(p.role==='gm'))throw Error('Identidade ou papel divergente');
    this.selfId=p.selfId;this.role=p.role;this.revision=p.revision;this.seq=p.seq;this.members=p.members;this.snapshot=p.snapshot;this.connected=true;this.connecting=false;this.status='connected';this.pending.clear();this.update('Sala sintética conectada; snapshot de revisão '+p.revision);return;
   }
   if(!this.connected)throw Error('Mensagem recebida antes da entrada autorizada');
   if(p.type==='ROOM_REJECT'){
    if(!this.pending.has(p.intentId))throw Error('Rejeição de intenção desconhecida');
    this.pending.delete(p.intentId);this.update('Intenção rejeitada: '+p.reason+'. Nenhum movimento local aplicado.');
    if(p.reason==='STALE_REVISION')this.resync();return;
   }
   if(p.type==='ROOM_EVENT'){
    if(p.revision!==this.revision+1||p.seq!==this.seq+1){this.status='resync';this.update('Ordem de eventos divergente; solicitando snapshot autorizado.');this.resync();return;}
    this.revision=p.revision;this.seq=p.seq;this.snapshot=p.snapshot;this.pending.delete(p.intentId);this.update('Evento confirmado por fixture · revisão '+p.revision);return;
   }
   if(p.type==='ROOM_SNAPSHOT'){
    if(p.revision<this.revision||p.seq<this.seq)throw Error('Snapshot regressivo');
    this.revision=p.revision;this.seq=p.seq;this.snapshot=p.snapshot;this.status='connected';this.pending.clear();this.update('Snapshot sincronizado · revisão '+p.revision);return;
   }
  }catch(e){this.error='Pacote rejeitado: '+e.message;this.connected=false;this.connecting=false;this.status='error';this.pending.clear();this.snapshot=null;this.update(this.error);try{this.transport?.close();}catch(_e){}}
 }
 sendIntent(unitId,x,y){
  if(!this.connected||!this.snapshot||this.status!=='connected')return false;
  const u=this.snapshot.units.find(u=>u.id===unitId);if(!u||!(this.role==='gm'||u.ownerId===this.selfId)){
   this.update('Este personagem não está sob seu controle na projeção recebida.');return false;
  }
  if(this.pending.size){this.update('Aguardando confirmação anterior; não aplicou movimento local.');return false;}
  const intentId=`${this.nonce}_${++this.counter}`;
  const p={schema:SCHEMA,type:'ROOM_INTENT',roomId:this.roomId,revision:this.revision,intentId,action:'MOVE_REQUEST',unitId,x,y};
  if(!checkOutgoing(p)||x>=this.snapshot.n||y>=this.snapshot.n||this.snapshot.walls.includes(cellKey(x,y))){this.update('Destino ou intenção inválida.');return false;}
  this.pending.set(intentId,p);this.update('Intenção enviada; aguardando confirmação.');
  try{this.transport.send(JSON.stringify(p));return true;}catch(e){this.pending.delete(intentId);this.status='resync';this.update('Falha ao enviar; ação não confirmada.');return false;}
 }
 resync(){if(!this.transport)return false;const p={schema:SCHEMA,type:'ROOM_RESYNC',roomId:this.roomId,knownRevision:this.revision,knownSeq:this.seq};if(!checkOutgoing(p))return false;try{this.transport.send(JSON.stringify(p));return true;}catch(e){this.status='error';this.update('Reconexão indisponível: '+e.message);return false;}}
}
// Fixture sintética com papéis para UX e testes, NÃO backend ou autenticação.
// Em produção a autoridade e o filtro por escopo precisam ocorrer fora do cliente.
// Uma única fixture compartilhada apenas ENTRE instâncias deste MESMO JS/contexto.
// Isso não sincroniza navegadores/dispositivos e NÃO é o futuro backend multiplayer.
const demoRoom={revision:0,seq:0,n:7,walls:['3,3'],units:[
 {id:'demo_a',name:'Exploradora TEST',mark:'E',team:'ally',ownerId:'p1',x:1,y:1},
 {id:'demo_b',name:'Conjurador TEST',mark:'C',team:'ally',ownerId:'p2',x:1,y:4},
 {id:'demo_n',name:'Criatura TEST',mark:'X',team:'enemy',ownerId:null,x:5,y:3}
],peers:new Set(),seen:new Map()};
const demoMembers=[{id:'gm',label:'Mestre TEST',role:'gm'},{id:'p1',label:'Player 1 TEST',role:'player'},{id:'p2',label:'Player 2 TEST',role:'player'}];
function demoTransportFactory({onMessage,onClose}){
 const peer={profile:null,closed:false,onMessage,onClose};demoRoom.peers.add(peer);
 const base=type=>({schema:SCHEMA,type,roomId:'arena-test',revision:demoRoom.revision,seq:demoRoom.seq});
 const projection=recipient=>({n:demoRoom.n,walls:demoRoom.walls.slice(),units:demoRoom.units.filter(u=>recipient==='gm'||u.ownerId===recipient).map(u=>({...u}))});
 const wire=(target,p)=>{if(!target.closed)target.onMessage(JSON.stringify(p));};
 return {send(raw){
  if(peer.closed)throw Error('Transporte fechado');if(typeof raw!=='string'||raw.length>LIMIT)throw Error('Pacote inválido');const m=JSON.parse(raw);
  if(!checkOutgoing(m))throw Error('Comando com propriedades não permitidas');
  if(m.type==='ROOM_JOIN'){peer.profile=m.profile;wire(peer,{...base('ROOM_JOINED'),role:m.profile==='gm'?'gm':'player',selfId:m.profile,members:demoMembers.map(x=>({...x})),snapshot:projection(m.profile)});return;}
  if(!peer.profile)throw Error('Entrada obrigatória');
  if(m.type==='ROOM_RESYNC'){wire(peer,{...base('ROOM_SNAPSHOT'),snapshot:projection(peer.profile)});return;}
  const key=peer.profile+':'+m.intentId;
  if(demoRoom.seen.has(key)){wire(peer,demoRoom.seen.get(key));return;}
  const u=demoRoom.units.find(u=>u.id===m.unitId);
  let reason=null;
  if(m.revision!==demoRoom.revision)reason='STALE_REVISION';
  else if(!u||(peer.profile!=='gm'&&u.ownerId!==peer.profile))reason='NOT_OWNER';
  else if((m.x===u.x&&m.y===u.y)||m.x>=demoRoom.n||m.y>=demoRoom.n||demoRoom.walls.includes(cellKey(m.x,m.y))||demoRoom.units.some(x=>x.id!==u.id&&x.x===m.x&&x.y===m.y))reason='INVALID_INTENT';
  if(reason){const rej={...base('ROOM_REJECT'),intentId:m.intentId,reason};demoRoom.seen.set(key,rej);wire(peer,rej);return;}
  // A fixture só atualiza uma posição sintética; não faz regras de movimento/alcance/dano.
  u.x=m.x;u.y=m.y;demoRoom.revision++;demoRoom.seq++;
  for(const target of [...demoRoom.peers]){
   if(target.closed||!target.profile)continue;
   // O ID de ator oculto NÃO viaja em evento da projeção de outra player.
   const canSee=target.profile==='gm'||u.ownerId===target.profile;
   const event=canSee?{...base('ROOM_EVENT'),intentId:m.intentId,kind:'MOVE_CONFIRMED',actorId:u.id,snapshot:projection(target.profile)}:{...base('ROOM_SNAPSHOT'),snapshot:projection(target.profile)};
   if(target===peer)demoRoom.seen.set(key,event);
   wire(target,event);
  }
 },close(){if(peer.closed)return;peer.closed=true;demoRoom.peers.delete(peer);peer.onClose();}};
}

const room=byId('roomPanel');
if(!room)return;
const client=new RoomClient({transportFactory:demoTransportFactory,nonce:'demo',onUpdate:draw});
let selectedId=null;
function draw(c){
 const st=byId('roomStatus');st.textContent=c.status==='connected'?'● DEMO conectada':c.status==='connecting'?'Conectando…':c.status==='resync'?'⚠ Sincronizando':c.status==='error'?'✕ Pacote recusado':'Desconectado';st.dataset.state=c.status;
 byId('roomIdentity').textContent=c.connected?`Sala ${c.roomId} · ${c.role==='gm'?'Mestre DEMO':'Player DEMO'} (${c.selfId}) · rev ${c.revision} · seq ${c.seq}`:'Nenhuma conexão real. Use o transporte sintético de demonstração.';
 const roster=byId('roomRoster');roster.replaceChildren();for(const m of c.members){const tag=document.createElement('span');tag.textContent=m.label+' · '+(m.role==='gm'?'Mestre':'Player');roster.append(tag);}
 const grid=byId('roomGrid');grid.replaceChildren();
 if(c.snapshot){const s=c.snapshot;grid.style.setProperty('--room-n',String(s.n));
  if(!s.units.some(u=>u.id===selectedId))selectedId=null;
  for(let y=0;y<s.n;y++)for(let x=0;x<s.n;x++){
   const key=cellKey(x,y),u=s.units.find(u=>u.x===x&&u.y===y);
   const b=document.createElement('button');b.type='button';b.className='roomCell';
   if(s.walls.includes(key)){b.classList.add('wall');b.textContent='▣';b.disabled=true;}
   else{b.textContent=u?u.mark:'·';if(u?.team==='enemy')b.classList.add('enemy');if(u&&(c.role==='gm'||u.ownerId===c.selfId))b.classList.add('owned');if(u?.id===selectedId)b.classList.add('selected');b.setAttribute('aria-label',`${x+1},${y+1}`+(u?' · '+u.name:''));b.addEventListener('click',()=>{
     if(u&&(c.role==='gm'||u.ownerId===c.selfId)){selectedId=u.id;draw(c);return;}
     if(selectedId)c.sendIntent(selectedId,x,y);else{c.update('Escolha uma unidade sob seu controle primeiro.');}
   });}grid.append(b);
  }
 }
 byId('roomHint').textContent=selectedId?'Unidade selecionada: '+selectedId+'. Escolha destino TEST — só muda após evento confirmado.':'Selecione unidade sob seu controle e escolha destino; nenhuma ação altera a arena local.';
 const log=byId('roomEvents');log.replaceChildren();for(const v of c.log){const p=document.createElement('p');p.textContent=v;log.append(p);}
}
byId('roomConnect').addEventListener('click',()=>{selectedId=null;client.connect(byId('roomProfile').value);});
byId('roomDisconnect').addEventListener('click',()=>{selectedId=null;client.disconnect();});
byId('roomResync').addEventListener('click',()=>{client.resync();});
byId('roomProfile').addEventListener('change',()=>{selectedId=null;client.disconnect();});
window.TabletopRoomTEST={client,RoomClient,checkPacket,checkSnapshot,checkOutgoing,demoTransportFactory,SCHEMA,selected:()=>selectedId};
draw(client);
})();
