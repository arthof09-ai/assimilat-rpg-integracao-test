"""Differential API probes against original TEST34 RoomClient, source read-only.
Does NOT authenticate players; exercises client validation and semantic holes.
"""
import asyncio,json,hashlib,pathlib,sys
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
async def main():
 sys.path.insert(0,str(ROOT/'base34/tests'))
 from test_room_browser import mount
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':390,'height':844});await mount(page)
  result=await page.evaluate('''() => {
    const T=window.TabletopRoomTEST,S=T.SCHEMA,roomId='arena-test',checks=[];
    const ck=(name,expected,actual)=>checks.push({name,expected,actual,pass:JSON.stringify(expected)===JSON.stringify(actual)});
    const snap={n:7,walls:[],units:[{id:'player_a',name:'Player',mark:'P',team:'ally',ownerId:'p1',x:1,y:1}]};
    const base=(type,revision=1,seq=1)=>({schema:S,type,roomId,revision,seq});
    const joined={...base('ROOM_JOINED'),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:snap};
    ck('v1 joined baseline valid',true,T.checkPacket(joined));
    ck('v1 v2 WELCOME is not a v1 packet',false,T.checkPacket({v:2,type:'WELCOME',roomId,participantId:'p1',role:'PLAYER',revision:1,snapshot:snap}));
    ck('v1 cannot parse v2 ACK',false,T.checkPacket({v:2,type:'ACK',roomId,commandId:'c1',status:'ACCEPTED',revision:2}));
    ck('v1 cannot parse v2 RECEIPT',false,T.checkPacket({v:2,type:'RECEIPT',roomId,commandId:'c1',status:'ACCEPTED',revision:2}));
    ck('v1 v2 RECEIPT_QUERY not outgoing',false,T.checkOutgoing({v:2,type:'RECEIPT_QUERY',roomId,commandId:'c1'}));
    ck('v1 outbound JOIN DEMO profile accepted',true,T.checkOutgoing({schema:S,type:'ROOM_JOIN',roomId,profile:'p1'}));
    ck('v1 outbound JOIN with opaque ticket rejected',false,T.checkOutgoing({schema:S,type:'ROOM_JOIN',roomId,profile:'p1',ticket:'test_ticket'}));
    ck('v1 role MASTER incompatible with lowercase gm/player',false,T.checkPacket({...joined,role:'MASTER'}));
    ck('v1 event baseline accepted',true,T.checkPacket({...base('ROOM_EVENT',2,2),intentId:'a1',kind:'MOVE_CONFIRMED',actorId:'player_a',snapshot:snap}));
    ck('v1 ROOM_EVENT cannot include ACK status',false,T.checkPacket({...base('ROOM_EVENT',2,2),intentId:'a1',kind:'MOVE_CONFIRMED',actorId:'player_a',snapshot:snap,status:'ACCEPTED'}));
    ck('v1 ROOM_EVENT cannot carry adminRevision',false,T.checkPacket({...base('ROOM_EVENT',2,2),intentId:'a1',kind:'MOVE_CONFIRMED',actorId:'player_a',snapshot:snap,adminRevision:5}));
    ck('v1 ROOM_SNAPSHOT cannot include sceneId',false,T.checkPacket({...base('ROOM_SNAPSHOT',2,2),snapshot:{...snap,sceneId:'s1'}}));
    ck('v1 room player snapshot cannot include markers',false,T.checkPacket({...base('ROOM_SNAPSHOT',2,2),snapshot:{...snap,markers:[]}}));
    ck('v1 client checks canonical coords',false,T.checkSnapshot({...snap,walls:['02,02']}));
    ck('v1 validator rejects direct admin field',false,T.checkPacket({...base('ROOM_SNAPSHOT',2,2),snapshot:{...snap,adminMarkers:[]}}));
    // Correctly shaped objects can still contain unauthorized *values*.
    ck('v1 structural validation DOES NOT prove ownership ACL',true,T.checkSnapshot({...snap,units:[...snap.units,{id:'master_secret',name:'Master unit',mark:'M',team:'enemy',ownerId:null,x:2,y:2}]}));
    ck('v1 structural packet accepts hidden actor ID inside otherwise valid event',true,T.checkPacket({...base('ROOM_EVENT',2,2),intentId:'a1',kind:'MOVE_CONFIRMED',actorId:'private_actor',snapshot:snap}));
    // Identity p1 selected in UI; server-issued ID different cannot be mapped safely.
    let emit;const dummy=({onMessage})=>{emit=onMessage;return {send:()=>{},close:()=>{}}};const c=new T.RoomClient({transportFactory:dummy,nonce:'diff14'});c.connect('p1');
    emit(JSON.stringify({...joined,selfId:'account_7',members:[{id:'account_7',role:'player',label:'Player'}]}));
    ck('v1 client rejects server-issued identity not equal DEMO profile','error',c.status);
    ck('v1 rejected identity leaves no snapshot',null,c.snapshot);
    return checks;
  }''')
  await browser.close()
  out={'source':'TEST34 original, Chromium, no code changes','total':len(result),'passed':sum(x['pass'] for x in result),'failed':sum(not x['pass'] for x in result),'tests':result,'caveat':'Some TRUE values deliberately show weak validation, not product PASS.'}
  (ROOT/'results/CONTRACT_DIFFERENTIAL_014.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
  print(json.dumps({k:v for k,v in out.items() if k!='tests'},ensure_ascii=False));print('FAIL:',[x['name'] for x in result if not x['pass']]);return 1 if out['failed'] else 0
if __name__=='__main__':sys.exit(asyncio.run(main()))
