"""Create test-only research archive. DO NOT include base34/base13/sources or secrets."""
import pathlib,zipfile,hashlib,json,sys
root=pathlib.Path(__file__).resolve().parents[1]
names=(sorted(str(x.relative_to(root)) for folder in ['work','report','results'] for x in (root/folder).rglob('*') if x.is_file() and x.suffix!='.pyc' and '__pycache__' not in str(x)) + ['README_REPRODUCAO_014.md'])
names=sorted(set(names))
# Don't include builder's own output and no original Developer or previous PESQ packages.
assert not any(n.startswith(('sources/','base13/','base34/')) for n in names)
assert all(not any(k in n.lower() for k in ['secret','vlab_r315','party_original']) for n in names)
manifest={n:{'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest(),'bytes':(root/n).stat().st_size} for n in names}
output=root/'PACOTE_PESQ_INOV_20261023_014.zip'
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in names:z.write(root/n,arcname=n)
 z.writestr('MANIFEST_SHA256_PESQ014.json',json.dumps({'schema':'pesq.inov.014.manifest.v1','files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 obj=json.loads(z.read('MANIFEST_SHA256_PESQ014.json'))
 assert all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in obj['files'].items())
print(json.dumps({'archive':str(output),'size':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'entries':len(names)+1,'files_SHA_PASS':len(names),'CRC':'PASS'}))
