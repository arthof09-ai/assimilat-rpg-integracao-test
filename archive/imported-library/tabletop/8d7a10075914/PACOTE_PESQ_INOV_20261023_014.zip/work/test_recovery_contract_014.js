'use strict';const assert=require('node:assert/strict');const crypto=require('node:crypto');const {issue,SyntheticOutbox,memoryStore,stable,buildPartyDto,validateServerProjection}=require('./recovery_contract_014');
let ok=0,fail=[];function ck(name,fn){try{fn();ok++;}catch(e){fail.push({name,error:String(e)})}}
const I=()=>issue('arena-test','p1','cmd001',7,'u1',2,3);
ck('issue envelope well typed',()=>{assert.equal(I().type,'INTENT');assert.equal(I().commandId,'cmd001');});
ck('issue rejects bad id',()=>assert.throws(()=>issue('arena-test','p1','__proto__',7,'u1',2,3)));
ck('issue rejects negative revision',()=>assert.throws(()=>issue('arena-test','p1','c',-1,'u1',2,3)));
ck('issue never claims role',()=>assert.equal(Object.hasOwn(I(),'role'),false));
const store=memoryStore(),o=new SyntheticOutbox(store);let i=I();
ck('register exact intent',()=>assert.equal(o.register('p1',i).commandId,'cmd001'));
ck('duplicate attempt while unresolved refused',()=>assert.throws(()=>o.register('p1',i)));
ck('timeout becomes UNKNOWN',()=>assert.equal(o.markUnknown(),'UNKNOWN'));
ck('stored UNKNOWN survives client re-instantiation',()=>assert.equal(new SyntheticOutbox(store).current.status,'UNKNOWN'));
ck('resume same participant queries SAME id',()=>assert.deepEqual(new SyntheticOutbox(store).resume('arena-test','p1'),{v:2,type:'RECEIPT_QUERY',roomId:'arena-test',commandId:'cmd001'}));
ck('resume other participant holds',()=>assert.equal(new SyntheticOutbox(store).resume('arena-test','p2').action,'HOLD_IDENTITY_MISMATCH'));
ck('resume other room holds',()=>assert.equal(new SyntheticOutbox(store).resume('other','p1').action,'HOLD_IDENTITY_MISMATCH'));
let good={v:2,type:'RECEIPT',roomId:'arena-test',commandId:'cmd001',status:'ACCEPTED',fingerprint:stable(i),revision:8,reason:null};
ck('receipt wrong ID HOLD',()=>assert.equal(new SyntheticOutbox(store).reconcile('arena-test','p1',{...good,commandId:'new'}).action,'HOLD_WRONG_RECEIPT'));
ck('receipt mutated payload fingerprint HOLD',()=>assert.equal(new SyntheticOutbox(store).reconcile('arena-test','p1',{...good,fingerprint:stable({...i,payload:{x:3,y:3}})}).action,'HOLD_WRONG_RECEIPT'));
ck('receipt extra field HOLD',()=>assert.equal(new SyntheticOutbox(store).reconcile('arena-test','p1',{...good,secret:'MASTER'}).action,'HOLD_INVALID_RECEIPT'));
ck('receipt without revision HOLD',()=>assert.equal(new SyntheticOutbox(store).reconcile('arena-test','p1',{...good,revision:null}).action,'HOLD_INVALID_RECEIPT'));
ck('accepted receipt requests RESYNC instead of replay',()=>assert.deepEqual(new SyntheticOutbox(store).reconcile('arena-test','p1',good),{action:'RESYNC_REQUIRED',revision:8}));
ck('accepted receipt clears outbox only after verified reply',()=>assert.equal(new SyntheticOutbox(store).current,null));
const s2=memoryStore();const j=issue('arena-test','p1','cmd002',8,'u1',3,3);new SyntheticOutbox(s2).register('p1',j);
const base={v:2,type:'RECEIPT',roomId:'arena-test',commandId:'cmd002',fingerprint:stable(j),revision:8,reason:'NOT_OWNER'};
ck('reject receipt clears outbox',()=>{assert.equal(new SyntheticOutbox(s2).reconcile('arena-test','p1',{...base,status:'REJECTED'}).action,'REJECTED');assert.equal(new SyntheticOutbox(s2).current,null)});
const s3=memoryStore();const k=issue('arena-test','p1','cmd003',8,'u1',3,4);new SyntheticOutbox(s3).register('p1',k);
ck('not found cannot become rejected',()=>assert.equal(new SyntheticOutbox(s3).reconcile('arena-test','p1',{v:2,type:'RECEIPT',roomId:'arena-test',commandId:'cmd003',status:'NOT_FOUND',fingerprint:stable(k),revision:null,reason:null}).action,'HOLD_UNKNOWN'));
ck('not found retains same ID',()=>assert.equal(new SyntheticOutbox(s3).current.commandId,'cmd003'));
ck('unknown receipt does not clear outbox',()=>assert.equal(new SyntheticOutbox(s3).current.status,'UNKNOWN'));
ck('rehydrate tampered storage fails',()=>{const st=memoryStore();st.write('{"roomId":"arena-test","participantId":"p1","commandId":"cmd004","status":"UNKNOWN","baseRevision":8,"fingerprint":"fake","intent":{"commandId":"cmd004","roomId":"arena-test"}}');assert.throws(()=>new SyntheticOutbox(st))});
const room={sceneId:'s1',revision:5,n:7,walls:[],units:[{id:'u1',ownerId:'p1',x:1,y:1,mark:'A',adminHP:999},{id:'u2',ownerId:'p2',x:2,y:2,mark:'B',adminHP:222}],markers:[{id:'m1',x:1,y:2,text:'shared',secret:'top'},{id:'m2',x:2,y:4,text:'private',secret:'top'}],adminMarkers:[{id:'m3',x:4,y:4}],adminNotes:'secret',lastEvent:{GM_TOKEN:'canary'}};
const dto=buildPartyDto(room,['s1:m1'],'p1');
ck('party DTO accepted',()=>assert.equal(validateServerProjection(dto),true));
ck('party DTO drops admin top level',()=>assert.equal(JSON.stringify(dto).includes('adminNotes'),false));
ck('party DTO drops nested extra on unit',()=>assert.equal(JSON.stringify(dto).includes('adminHP'),false));
ck('party DTO drops nested extra on marker',()=>assert.equal(JSON.stringify(dto).includes('secret'),false));
ck('party DTO only includes own unit',()=>assert.deepEqual(dto.units.map(u=>u.id),['u1']));
ck('party DTO only allowed marker',()=>assert.deepEqual(dto.markers.map(x=>x.id),['m1']));
ck('same marker id OTHER scene grant no effect',()=>assert.equal(buildPartyDto(room,['s2:m1'],'p1').markers.length,0));
ck('unknown marker property rejected by receiving validator',()=>assert.equal(validateServerProjection({...dto,markers:[{...dto.markers[0],private:'bad'}]}),false));
ck('unknown top level rejected by receiving validator',()=>assert.equal(validateServerProjection({...dto,other:'admin'}),false));
ck('non canonical wall rejected',()=>assert.equal(validateServerProjection({...dto,walls:['02,01']}),false));
ck('wall outside map rejected',()=>assert.equal(validateServerProjection({...dto,walls:['7,0']}),false));
ck('duplicate wall rejected',()=>assert.equal(validateServerProjection({...dto,walls:['1,1','1,1']}),false));
ck('unlicensed role never conveyed in dto',()=>assert.equal(Object.hasOwn(dto,'role'),false));
// Deterministic adversarial cases: varying hidden fields & cross-scene grants.
let seed=20261023;function rnd(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
let generated=0;for(let n=0;n<240;n++){const candidate=JSON.parse(JSON.stringify(room)),leak='GM_CANARY_'+n,key='secret_'+Math.floor(rnd()*1000);candidate.markers[0][key]=leak;candidate.units[0][key]=leak;candidate.lastEvent={...candidate.lastEvent,[key]:leak};const d=buildPartyDto(candidate,['s1:m1'],'p1');if(JSON.stringify(d).includes(leak))throw Error('leak iteration '+n);generated++;}
console.log(JSON.stringify({directed:ok,failed:fail,generated,seed:20261023}));if(fail.length)process.exit(1);
