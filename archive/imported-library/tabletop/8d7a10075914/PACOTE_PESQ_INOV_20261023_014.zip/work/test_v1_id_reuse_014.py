"""RUN011 TEST34 DEMO fixture: same ID with altered payload must be distinguished by real server.
Source unmodified. Results demonstrate demo limitation, not production exploit.
"""
import asyncio,sys,json,pathlib
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
async def main():
 sys.path.insert(0,str(ROOT/'base34/tests'));from test_room_browser import mount
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await b.new_page();await mount(page)
  res=await page.evaluate('''()=>{
   const T=window.TabletopRoomTEST, wire=[];let closed=false;
   const tr=T.demoTransportFactory({onMessage:raw=>wire.push(JSON.parse(raw)),onClose:()=>{closed=true}});
   tr.send(JSON.stringify({schema:T.SCHEMA,type:'ROOM_JOIN',roomId:'arena-test',profile:'p1'}));
   const mk=(revision,x,y)=>({schema:T.SCHEMA,type:'ROOM_INTENT',roomId:'arena-test',revision,intentId:'collision_014',action:'MOVE_REQUEST',unitId:'demo_a',x,y});
   tr.send(JSON.stringify(mk(0,2,2)));const first=wire.at(-1);
   tr.send(JSON.stringify(mk(1,4,4)));const second=wire.at(-1);
   return {first:{type:first.type,revision:first.revision,x:first.snapshot?.units?.[0]?.x,y:first.snapshot?.units?.[0]?.y},second:{type:second.type,revision:second.revision,x:second.snapshot?.units?.[0]?.x,y:second.snapshot?.units?.[0]?.y},samePacket:JSON.stringify(first)===JSON.stringify(second),checks:[{name:'first action accepted in synthetic fixture',pass:first.type==='ROOM_EVENT'},{name:'modified payload with same id returns cached previous event',pass:second.type==='ROOM_EVENT'&&first.revision===second.revision},{name:'received reply is same older event',pass:JSON.stringify(first)===JSON.stringify(second)},{name:'v1 fixture has no ID_REUSE_CONFLICT reason',pass:!['ID_REUSE_CONFLICT'].includes(second.reason)},{name:'cached movement remains x2,y2',pass:second.snapshot.units[0].x===2&&second.snapshot.units[0].y===2}]};
  }''');await b.close()
 out={'baseline':'TEST34 original demoTransportFactory','tests':res['checks'],'passed':sum(t['pass'] for t in res['checks']),'failed':sum(not t['pass'] for t in res['checks']),'observations':{k:v for k,v in res.items() if k!='checks'},'interpretation':'Fixture reuses prior event for same intentId with altered payload, lacks fingerprint conflict. Server v2 must reject changed payload; do not classify as exploitable product server vulnerability.'}
 (ROOT/'results/ID_REUSE_PAYLOAD_014.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
 print(json.dumps({k:v for k,v in out.items() if k!='tests'},ensure_ascii=False));return 0 if not out['failed'] else 1
if __name__=='__main__':sys.exit(asyncio.run(main()))
