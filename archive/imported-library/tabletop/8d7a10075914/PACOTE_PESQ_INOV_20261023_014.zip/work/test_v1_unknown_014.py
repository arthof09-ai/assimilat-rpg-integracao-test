"""PESQ014: tests original TEST34 RoomClient in an isolated Chromium page.
Only synthetic payloads; no modification to the Developer files.
"""
import asyncio, json, sys, pathlib, hashlib
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'base34/public'
SCHEMA='assim.tabletop.room.presentation.v1'
async def mount(page):
    # Use source scripts without editing them: reuse the Developer's own offline mounting helper.
    sys.path.insert(0,str(ROOT/'base34/tests'))
    from test_room_browser import mount as official_mount
    await official_mount(page)

async def main():
  alltests=[]; observations={}
  async with async_playwright() as pw:
    b=await pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    p=await b.new_page(viewport={'width':390,'height':844});await mount(p)
    res=await p.evaluate('''() => {
      const T=window.TabletopRoomTEST, schema=T.SCHEMA, roomId='arena-test';
      const ctests=[], obs={};const t=(label,expected,actual)=>ctests.push({label,pass:JSON.stringify(expected)===JSON.stringify(actual),expected,actual});
      let emitter, closer, sent=[];
      const factory=({onMessage,onClose})=>{emitter=onMessage;closer=onClose;return {send:x=>sent.push(JSON.parse(x)),close:()=>{}}};
      const c=new T.RoomClient({transportFactory:factory,nonce:'audit14'});c.connect('p1');
      const unit={id:'u1',name:'Sintetica',mark:'S',team:'ally',ownerId:'p1',x:1,y:1};
      const s={n:7,walls:[],units:[unit]};
      const base=(type,revision=0,seq=0)=>({schema,type,roomId,revision,seq});
      emitter(JSON.stringify({...base('ROOM_JOINED'),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:s}));
      t('v1 initial JOIN received',true,c.connected);
      t('v1 no optimistic position change',true,c.sendIntent('u1',2,1)&&c.snapshot.units[0].x===1);
      const command=sent.at(-1);obs.firstCommand=command;
      t('v1 intent has ID',true,typeof command.intentId==='string'&&command.intentId.length>0);
      t('v1 intent pending before ambiguous loss',1,c.pending.size);
      closer();t('v1 goes offline on lost ACK','offline',c.status);
      t('v1 keeps pending temporarily after WS close',1,c.pending.size);
      obs.pendingBeforeReconnect=c.pending.size;
      c.connect('p1');t('v1 loses pending on reconnect',0,c.pending.size);
      t('v1 reconnect sends JOIN not RECEIPT_QUERY','ROOM_JOIN',sent.at(-1).type);
      t('v1 handshake contains DEMO profile',true,sent.at(-1).profile==='p1');
      t('v1 protocol does not accept receipt reply',false,T.checkPacket({...base('ROOM_RECEIPT',1,1),intentId:command.intentId,status:'ACCEPTED'}));
      t('v1 protocol does not accept ACK reply',false,T.checkPacket({...base('ACK',1,1),intentId:command.intentId,status:'ACCEPTED'}));
      emitter(JSON.stringify({...base('ROOM_JOINED',1,1),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:{...s,units:[{...unit,x:2,y:1}]}}));
      t('v1 reconnect sees new snapshot',2,c.snapshot.units[0].x);
      t('v1 not tracking prior command after reconnect',0,c.pending.size);
      // second ambiguous outcome: a resync snapshot at unchanged revision erases pending.
      c.sendIntent('u1',3,1);t('v1 pending new intent before resync',1,c.pending.size);
      const secondId=sent.at(-1).intentId;
      emitter(JSON.stringify({...base('ROOM_SNAPSHOT',1,1),snapshot:{...s,units:[{...unit,x:2,y:1}]}}));
      t('v1 snapshot clears unresolved pending',0,c.pending.size);
      obs.idBeforeReconnect=command.intentId;obs.idNew=secondId;
      // Explicit reconnect without command retention means no query or retry.
      t('v1 no outbound RECEIPT_QUERY ever',false,sent.some(x=>x.type==='RECEIPT_QUERY'));
      // SEND MAY COMPLETE SERVER-SIDE BEFORE A TRANSPORT ERROR IS THROWN.
      let emit2, outbound2=[];const sendingThenThrows=({onMessage})=>{emit2=onMessage;return {send:raw=>{const payload=JSON.parse(raw);outbound2.push(payload);if(payload.type==='ROOM_INTENT')throw Error('connection disappeared AFTER send');},close:()=>{}}};
      const fragile=new T.RoomClient({transportFactory:sendingThenThrows,nonce:'fragile'});fragile.connect('p1');
      emit2(JSON.stringify({...base('ROOM_JOINED',2,2),role:'player',selfId:'p1',members:[{id:'p1',role:'player',label:'Player'}],snapshot:s}));
      t('v1 synthetic transport throws after intent send',false,fragile.sendIntent('u1',2,1));
      t('v1 transport error erases outbound intent tracking',0,fragile.pending.size);
      t('v1 sent command before exception is observable',true,outbound2.some(x=>x.type==='ROOM_INTENT'));
      obs.transportThrow=outbound2.map(x=>x.type);
      // Late rejection for an intent whose pending entry was discarded after resync.
      emitter(JSON.stringify({...base('ROOM_REJECT',1,1),intentId:secondId,reason:'STALE_REVISION'}));
      t('v1 unexpected late rejection closes client', 'error', c.status);
      t('v1 late rejection clears projected snapshot', null, c.snapshot);
      // Unknown/safety policy checks (intended FAIL on current baseline).
      t('TARGET unresolved command preserved through reconnect',1,obs.pendingBeforeReconnect && c.pending.size);
      t('TARGET first reconnect sends receipt query','RECEIPT_QUERY',sent[2]?.type||'ABSENT');
      return {tests:ctests,observations:obs,wires:sent.map(x=>({type:x.type,intentId:x.intentId??null,profile:x.profile??null}))};
    }''')
    alltests=res['tests'];observations=res['observations'];observations['wire']=res['wires'];await b.close()
  out={'baseline':'RUN-011 / TEST34 original room-client.js','sha256':hashlib.sha256((PUBLIC/'room-client.js').read_bytes()).hexdigest(),'browser':'Chromium headless, viewport 390x844, synthetic passive transport','tests':alltests,'pass':sum(x['pass'] for x in alltests),'fail':sum(not x['pass'] for x in alltests),'observations':observations,'note':'Last 2 TARGET checks are deliberate contract requirements and fail on v1; others are observations, not endorsements of behavior.'}
  (ROOT/'results/BASELINE_V1_UNKNOWN_014.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
  print(json.dumps({'pass':out['pass'],'fail':out['fail'],'failed':[x['label'] for x in alltests if not x['pass']],'wires':observations['wire']},ensure_ascii=False,indent=2))
  return 0
if __name__=='__main__':sys.exit(asyncio.run(main()))
