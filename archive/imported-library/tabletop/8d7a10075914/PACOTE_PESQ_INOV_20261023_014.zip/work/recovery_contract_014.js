/* Research-only client-side contract. NOT transport/server/VLAB implementation.
   Never import as production code without competent review. Synthetic data only. */
'use strict';
const V2=2, ACCEPTED='ACCEPTED',REJECTED='REJECTED',UNKNOWN='UNKNOWN';
function exact(o,keys){return o && typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).every(k=>keys.includes(k));}
function ident(s){return typeof s==='string'&&/^[A-Za-z0-9_-]{1,80}$/.test(s)&&!['constructor','prototype','__proto__'].includes(s);}
function stable(v){if(Array.isArray(v))return '['+v.map(stable).join(',')+']'; if(v&&typeof v==='object'){if(!exact(v,Object.keys(v)))throw Error('invalid object');return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';}return JSON.stringify(v);}
function issue(roomId,participantId,commandId,baseRevision,unitId,x,y){
 if(![roomId,participantId,commandId,unitId].every(ident)||!Number.isSafeInteger(baseRevision)||baseRevision<0||!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>500||y>500)throw Error('INVALID_INTENT');
 return {v:V2,type:'INTENT',roomId,commandId,baseRevision,kind:'MOVE_VISUAL_TEST',unitId,payload:{x,y}};
}
const memoryStore=()=>{let t='';return {read:()=>t,write:x=>{t=x;}}};
class SyntheticOutbox {
 constructor(store){this.store=store;this.current=this.read();}
 read(){let a=this.store.read();if(!a)return null;let v=JSON.parse(a);if(!exact(v,['roomId','participantId','commandId','baseRevision','fingerprint','intent','status']))throw Error('STORED_OUTBOX_INVALID');if(!['SENT',UNKNOWN].includes(v.status)||!ident(v.roomId)||!ident(v.participantId)||!ident(v.commandId)||v.commandId!==v.intent?.commandId||v.roomId!==v.intent?.roomId||v.fingerprint!==stable(v.intent))throw Error('STORED_OUTBOX_INVALID');return v;}
 write(v){this.current=v;this.store.write(v?JSON.stringify(v):'');}
 register(participantId,intent){if(this.current)throw Error('UNRESOLVED_EXISTS');if(!ident(participantId)||!exact(intent,['v','type','roomId','commandId','baseRevision','kind','unitId','payload'])||intent.v!==V2||intent.type!=='INTENT'||!ident(intent.commandId)||!ident(intent.roomId)||intent.kind!=='MOVE_VISUAL_TEST'||!exact(intent.payload,['x','y']))throw Error('INVALID_INTENT');this.write({roomId:intent.roomId,participantId,commandId:intent.commandId,baseRevision:intent.baseRevision,fingerprint:stable(intent),intent,status:'SENT'});return intent;}
 markUnknown(){if(!this.current)throw Error('NO_PENDING');this.write({...this.current,status:UNKNOWN});return UNKNOWN;}
 resume(roomId,participantId){if(!this.current)return {action:'NO_PENDING'};if(this.current.roomId!==roomId||this.current.participantId!==participantId)return {action:'HOLD_IDENTITY_MISMATCH'};this.markUnknown();return {v:V2,type:'RECEIPT_QUERY',roomId,commandId:this.current.commandId};}
 reconcile(roomId,participantId,receipt){let old=this.current;if(!old)return {action:'IGNORE_NOT_PENDING'};if(old.roomId!==roomId||old.participantId!==participantId)return {action:'HOLD_IDENTITY_MISMATCH'};
 if(!exact(receipt,['v','type','roomId','commandId','status','fingerprint','revision','reason']))return {action:'HOLD_INVALID_RECEIPT'};
 if(receipt.v!==V2||receipt.type!=='RECEIPT'||receipt.roomId!==roomId||receipt.commandId!==old.commandId||receipt.fingerprint!==old.fingerprint)return {action:'HOLD_WRONG_RECEIPT'};
 if(receipt.status===ACCEPTED){if(!Number.isSafeInteger(receipt.revision)||receipt.revision<0)return {action:'HOLD_INVALID_RECEIPT'};this.write(null);return {action:'RESYNC_REQUIRED',revision:receipt.revision};}
 if(receipt.status===REJECTED){if(typeof receipt.reason!=='string')return {action:'HOLD_INVALID_RECEIPT'};this.write(null);return {action:'REJECTED',reason:receipt.reason};}
 // Even a NOT_FOUND receipt cannot guarantee the previous command never committed
 // if retention/compaction or a different storage epoch is possible.
 this.markUnknown();return {action:'HOLD_UNKNOWN'};
 }
}
function validateServerProjection(p){
 // Public DTO is reconstructed, not spread from VLAB/GM object.
 const fields=['schema','sceneId','revision','n','walls','units','markers'];
 if(!exact(p,fields)||p.schema!=='assim.tabletop.room.presentation.authorized.v2'||!ident(p.sceneId)||!Number.isSafeInteger(p.revision)||p.revision<0||![5,7,10,20].includes(p.n)||!Array.isArray(p.walls)||!Array.isArray(p.units)||!Array.isArray(p.markers))return false;
 const ids=new Set();for(const u of p.units){if(!exact(u,['id','ownerId','x','y','mark'])||!ident(u.id)||ids.has(u.id)||!ident(u.ownerId)||!Number.isInteger(u.x)||!Number.isInteger(u.y)||u.x<0||u.y<0||u.x>=p.n||u.y>=p.n||typeof u.mark!=='string'||u.mark.length>2)return false;ids.add(u.id);}for(const m of p.markers)if(!exact(m,['id','x','y','text'])||!ident(m.id)||!Number.isInteger(m.x)||!Number.isInteger(m.y)||m.x<0||m.y<0||m.x>=p.n||m.y>=p.n||typeof m.text!=='string'||m.text.length>80)return false;
 return p.walls.every(w=>{if(typeof w!=='string'||!/^\d+,\d+$/.test(w))return false;const [x,y]=w.split(',').map(Number);return Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<p.n&&y<p.n&&w===x+','+y;})&&new Set(p.walls).size===p.walls.length;
}
function buildPartyDto(room,allowedMarkers,unitOwner){
 if(!room||!ident(room.sceneId)||!Array.isArray(room.units)||!Array.isArray(room.markers)||!Array.isArray(allowedMarkers)||!ident(unitOwner))throw Error('INVALID_SOURCE');
 let m=room.markers.filter(v=>allowedMarkers.includes(room.sceneId+':'+v.id)).map(v=>({id:v.id,x:v.x,y:v.y,text:v.text}));
 let u=room.units.filter(v=>v.ownerId===unitOwner).map(v=>({id:v.id,ownerId:v.ownerId,x:v.x,y:v.y,mark:v.mark}));
 let dto={schema:'assim.tabletop.room.presentation.authorized.v2',sceneId:room.sceneId,revision:room.revision,n:room.n,walls:room.walls.slice(),units:u,markers:m};if(!validateServerProjection(dto))throw Error('DTO_REJECTED');return dto;
}
module.exports={issue,SyntheticOutbox,memoryStore,stable,buildPartyDto,validateServerProjection};
