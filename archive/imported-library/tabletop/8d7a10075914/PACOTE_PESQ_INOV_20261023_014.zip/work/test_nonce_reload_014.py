"""RUN011 / TEST34 original: replay id collision across independent browser contexts.
This checks the current synthetic DEMO nonce, not production auth or real backend.
"""
import asyncio,sys,json,pathlib
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
async def main():
 sys.path.insert(0,str(ROOT/'base34/tests'));from test_room_browser import mount
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  ids=[];labels=[]
  for i in range(2):
   page=await b.new_page(viewport={'width':390,'height':844});await mount(page)
   info=await page.evaluate('''() => {const T=window.TabletopRoomTEST;let wire=[];let emit;const transport=({onMessage})=>{emit=onMessage;return {send:raw=>wire.push(JSON.parse(raw)),close:()=>{}}};const c=new T.RoomClient({transportFactory:transport,nonce:'demo'});c.connect('p1');let schema=T.SCHEMA;emit(JSON.stringify({schema,type:'ROOM_JOINED',roomId:'arena-test',revision:0,seq:0,role:'player',selfId:'p1',members:[{id:'p1',label:'P',role:'player'}],snapshot:{n:7,walls:[],units:[{id:'u1',ownerId:'p1',name:'Unit',mark:'U',team:'ally',x:1,y:1}]}}));let ok=c.sendIntent('u1',2,1);return {ok,intentId:wire.at(-1).intentId,revision:wire.at(-1).revision,counter:c.counter,status:c.status}}''')
   ids.append(info);await page.close()
  await b.close()
 checks=[{'name':'first generated id valid','pass':ids[0]['ok'] and ids[0]['intentId']=='demo_1'},{'name':'second generated id valid','pass':ids[1]['ok'] and ids[1]['intentId']=='demo_1'},{'name':'same room and revision','pass':ids[0]['revision']==ids[1]['revision']==0},{'name':'ID collision across browser contexts','pass':ids[0]['intentId']==ids[1]['intentId']},{'name':'new instance resets counter','pass':ids[0]['counter']==ids[1]['counter']==1},{'name':'not globally unique for v2 semantics','pass':len({a['intentId'] for a in ids})<len(ids)}]
 out={'tests':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'observed':ids,'classification':'Fixture-only demonstration; do not promote nonce=demo into real transport; server must bind participant and globally unique command IDs.'}
 (ROOT/'results/ID_COLLISION_DEMO_014.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
 print(json.dumps(out,indent=2,ensure_ascii=False));return 1 if out['failed'] else 0
if __name__=='__main__':sys.exit(asyncio.run(main()))
