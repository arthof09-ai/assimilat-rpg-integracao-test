"""Synthetic CPython portability probe, not Pyodide or VLAB execution.
Tests JSON/crypto/exceptions/schema only, no combat math, no real VLAB.
"""
from __future__ import annotations
import hashlib, json, decimal, unittest, sys, tempfile, pathlib, copy

SCHEMA="assim.transport.synthetic.research.v1"
class Blocked(Exception):pass

def encode_contract(room_id,seq,source,fields):
 if not isinstance(seq,int) or seq<0 or not room_id or any(k not in {'kind','actor','target','origin','test'} for k in fields):raise Blocked('invalid synthetic envelope')
 payload={'schema':SCHEMA,'roomId':room_id,'seq':seq,'source':source,'payload':fields}
 raw=json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
 return {'payload':payload,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

def decode_contract(encoded):
 if not isinstance(encoded,dict) or set(encoded)!={'payload','sha256','bytes'}:raise Blocked('unexpected fields')
 p=encoded['payload'];ifields=p['payload'];other=encode_contract(p['roomId'],p['seq'],p['source'],ifields)
 if other!=encoded:raise Blocked('tampered transport')
 return copy.deepcopy(p)

class Tests(unittest.TestCase):
 def setUp(self):self.msg=encode_contract('arena-test',2,'SYNTHETIC',{'kind':'MOVE_VISUAL_TEST','actor':'TEST-p1','target':'4,4'})
 def test_schema(self):self.assertEqual(self.msg['payload']['schema'],SCHEMA)
 def test_room(self):self.assertEqual(self.msg['payload']['roomId'],'arena-test')
 def test_json_roundtrip(self):self.assertEqual(decode_contract(json.loads(json.dumps(self.msg))),self.msg['payload'])
 def test_deterministic_ordering(self):self.assertEqual(self.msg,encode_contract('arena-test',2,'SYNTHETIC',{'target':'4,4','actor':'TEST-p1','kind':'MOVE_VISUAL_TEST'}))
 def test_deterministic_hash(self):self.assertEqual(self.msg['sha256'],encode_contract('arena-test',2,'SYNTHETIC',self.msg['payload']['payload'])['sha256'])
 def test_utf8(self):self.assertEqual(decode_contract(encode_contract('arena-test',0,'SYNTHETIC',{'actor':'ação'}))['payload']['actor'],'ação')
 def test_invalid_revision(self):
  with self.assertRaises(Blocked):encode_contract('arena-test',-1,'SYNTHETIC',{})
 def test_extra_unknown(self):
  with self.assertRaises(Blocked):encode_contract('arena-test',1,'SYNTHETIC',{'adminSecret':'NO'})
 def test_tamper_detected(self):
  c=copy.deepcopy(self.msg);c['payload']['payload']['actor']='MASTER'
  with self.assertRaises(Blocked):decode_contract(c)
 def test_hash_corruption(self):
  c=copy.deepcopy(self.msg);c['sha256']='f'*64
  with self.assertRaises(Blocked):decode_contract(c)
 def test_decimal_reference(self):self.assertEqual(str(decimal.Decimal('0.1')+decimal.Decimal('0.2')),'0.3')
 def test_ephemeral_filesystem_is_not_durability(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'fake_event.json';p.write_text(json.dumps(self.msg));self.assertTrue(p.exists())
  self.assertFalse(p.exists())
 def test_decode_is_copy(self):
  restored=decode_contract(self.msg);restored['payload']['actor']='changed';self.assertNotEqual(restored['payload'],self.msg['payload'])

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
 result=unittest.TextTestRunner(verbosity=0).run(suite)
 print(json.dumps({'environment':'CPython local (NOT Pyodide/Cloudflare Workers)','pythonVersion':sys.version.split()[0],'testsRun':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'pass':result.testsRun-len(result.errors)-len(result.failures)}))
 sys.exit(0 if result.wasSuccessful() else 1)
