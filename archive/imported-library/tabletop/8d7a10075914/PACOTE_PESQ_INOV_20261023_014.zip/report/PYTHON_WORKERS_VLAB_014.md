# PESQ-014 — Python Workers / Pyodide × VLAB: avaliação de ABI sem acesso à fonte mecânica

**Fontes Cloudflare (consultadas em 23/10/2026):**
- https://developers.cloudflare.com/workers/languages/python/
- https://developers.cloudflare.com/changelog/post/2025-05-14-python-worker-durable-object/
- https://developers.cloudflare.com/workers/languages/python/packages/
- https://developers.cloudflare.com/workers/languages/python/stdlib/
- https://developers.cloudflare.com/workers/testing/vitest-integration/test-apis/

**Confirmado pela documentação:** Python Workers e classes Durable Object em Python existem; o runtime Python usa **Pyodide/CPython compilado para WebAssembly**, `python_workers` flag e tooling `pywrangler`, dependências Python puras ou com wheels PyEmscripten/Pyodide. O exemplo oficial de DO Python acessa `ctx.storage.sql.exec()` por bindings Workers. O sistema de arquivos da instância é **efêmero e não compartilhado**, inadequado para SQLite persistente `sqlite3.connect('/tmp/...')`. `threading` e `multiprocessing` não são funcionais e diversos módulos dependentes de SO são excluídos. Implementação deve usar DO SQLite para estado durável; há limites Free de CPU/memória/armazenamento e riscos de cold start. **Nenhuma dessas afirmações significa que o VLAB roda no Pyodide.**

| Requisito do VLAB (hipótese a investigar por executor competente) | API Python Workers | Estado nesta pesquisa |
|---|---|---|
| Versão Python real, paths/imports do VLAB atual | Pyodide com versão ligada a compatibility date | **PENDENTE** leitura autorizada de manifest e import graph |
| Código Python puro, JSON, hashlib, decimal | API documenta stdlib majoritária | **SOMENTE CPython local TEST 13/13 PASS**, NÃO runtime Workers |
| SQLite de combate e jornal de eventos | DO fornece `ctx.storage.sql.exec` | **HOLD**: não reusar arquivo SQLite local como armazenamento durável |
| Transações/evento-recibo-estado | DO `transactionSync` na variante JS; Python FFI precisa teste real | **HOLD** sem execução runtime |
| `threading` / `multiprocessing` e processos de fundo | não funcionais no Pyodide | **POTENCIAL IMPEDIMENTO** se motor depender deles |
| bibliotecas nativas/arquivos C | requer wheels PyEmscripten/Pyodide | **PENDENTE** inventário de dependências reais e versões |
| Determinismo e sementes RNG | hash/serialização determinísticos possíveis | **HOLD** equivalência cross-runtime, precisão e energia de CPU |
| Python callable por DO JavaScript | Python Worker suporta FFI, mas ABI real exige prova | **HOLD** escolher só após recuperar ponte Codex e manifest VLAB atuais |
| Turnos, PA, dano, CD e reações reais | VLAB Python é única autoridade homologável | **PROIBIDO REIMPLEMENTAR**, nenhum teste de combate feito |

**Bancada autoral:** `work/python_worker_abi_probe_014.py`, 13 testes sintéticos executados no **CPython 3.13.5 local**, com JSON determinístico, SHA-256, Unicode, exceções, integridade de recibo e ilustração de arquivo efêmero. A primeira execução teve dois ERROS DO PRÓPRIO TESTE ao interpretar retorno de `decode_contract`; fixture foi corrigida e reexecutada 13/13 PASS. Não usar esses resultados para inferir Pyodide, startup, memória, hibernação, Rust/WASM, compatibilidade do VLAB ou custo Cloudflare.

**Gate recomendado ao responsável:** (1) recuperar VLAB live privado e lista de imports; (2) identificar C extensions, sqlite3 arquivo/journal/threads/sockets; (3) extrair módulo autoral **sintético** com mesma ABI, sem regras oficiais; (4) executar **no Workers/Python DO real**, testar exceptions e restart; (5) benchmark CPU/tempo e storage Free; (6) se incompatível, manter executor Python nativo em serviço privado distinto ou solução homologada pelo Mestre; (7) jamais publicar arquivos VLAB num Worker acessível às players ou JS do navegador.
