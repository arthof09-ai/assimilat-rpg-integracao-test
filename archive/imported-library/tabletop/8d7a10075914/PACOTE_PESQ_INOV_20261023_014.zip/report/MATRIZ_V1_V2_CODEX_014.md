# PESQ-014 — Matriz diferencial física de contratos TEST34 × PESQ013 × Codex

**Status:** Auditoria científica MESTRE-SIDE/TEST. Nenhum protocolo homologado. Fonte 1: `PACOTE_TECNICO_TABLETOP_TEST33_A_TEST34_20261023.zip` → `public/room-client.js`, SHA256 `4c2f9edde0175ec933832e283a886e3688afd6ca8247e6b30acd40cb1ff7a6fc`, 23/23 manifestos PASS. Fonte 2: PESQ013 → `report/PROTOCOLO_SALA_V2_013.md`, proposta D-INOV-033. Fonte 3: Codex `test/tabletop-vlab-bridge-poc`, commit **apenas relatado** `3f5caadfd376a63a949ca63815c0b68a0ea73a57` sem bytes legíveis no GitHub conectado (API 422); não comparar envelopes ausentes, nem inferir semântica de seis envelopes do relato.

| Aspecto | TEST34 `presentation.v1` — **FÍSICO** | PESQ013 `v=2` — **PROPOSTO** | Codex — **HOLD** | Tradução admissível/risco |
|---|---|---|---|---|
| Envelope versão | `schema:'assim.tabletop.room.presentation.v1'` | `v:2` | Bytes ausentes | Não há equivalência direta; negociar versão no JOIN |
| Sala | `roomId` literal `'arena-test'` no RoomClient | `roomId` + ticket/sessão confiável | Não lido | Sala deve vir de binding autenticado, não confiar no perfil DEMO |
| Identidade real | `selfId` deve ser IGUAL ao perfil escolhido `p1/p2/gm` | `participantId` do servidor, opaco | Não lido | **BREAKING:** IDs reais distintos de perfil DEMO geram erro no TEST34 |
| Papel | `gm/player` nas mensagens; `profile` selecionado pelo cliente | `MASTER/PLAYER` emitido pelo servidor | Não lido | Mapear role sob auth, nunca permitir elevar perfil selecionado |
| Posse de personagem | `unit.ownerId===selfId` no UI | servidor associa sessão ↔ unidade | Não lido | UI apenas conveniência; segurança é server-side |
| JOIN | `ROOM_JOIN {schema,type,roomId,profile}` | `JOIN {v,type,roomId,ticket}` | Não lido | Sem ticket/expiração/revogação no v1; nunca traduzir profile em autorização |
| WELCOME | `ROOM_JOINED` com `members,snapshot,revision,seq` | `WELCOME` com `participantId,role,sessionEpoch,snapshot` | Não lido | Snapshot v2 não necessariamente representa `n,walls,units` v1; criar DTO explícito |
| Revisão pública | `revision` única | `revision` ou `publicRevision` | Não lido | Precisa decidir o que avança em evento invisível |
| Revisão Mestre | Inexistente | `adminRevision` distinta para dados privados | Não lido | NUNCA sincronizar adminRevision com a revisão pública de PLAYER |
| Sequência de eventos | `seq` incrementa 1 por `ROOM_EVENT`; gaps pedem resync | `eventId`/cursor/afterRevision | Não lido | Sequência de evento visível ≠ necessariamente global; resync se lacuna |
| Comando | `ROOM_INTENT`, `intentId` | `INTENT`, `commandId`, `baseRevision` | Não lido | Mapeamento possível de campos, **não suficiente** para idempotência |
| Origem de IDs | `nonce:'demo'`, contador em memória | commandId estável, único por participante/room e retries | Não lido | **BREAKING:** duas instâncias novas geraram `demo_1`; rejeitar como estratégia de produção |
| Ação | `MOVE_REQUEST` x/y/unitId; sem regra mecânica | `MOVE_VISUAL_TEST` payload x/y/unitId | Não lido | Só transporte visual sintético; combate VLAB HOLD |
| ACK aceito | `ROOM_EVENT` confirmado via snapshot; não há ACK genérico | `ACK ACCEPTED` após persistência | Não lido | Não sintetizar evento antes de snapshot projetado consistente |
| ACK rejeitado | `ROOM_REJECT` com reason pré-definida | `ACK REJECTED` | Não lido | Podem divergir códigos de motivo; mapear tabela fechada |
| `UNKNOWN` | Não representado | Estado do cliente sem confirmação | Não lido | **BLOCKER**: v1 apaga pending no reconnect/snapshot/erro de send |
| Consulta recibo | Não há `RECEIPT_QUERY` | `RECEIPT_QUERY {roomId,commandId}` | Não lido | **BLOCKER**: v1 não pode reconciliar após COMMIT/ACK perdido |
| Persistência outbox | `pending = new Map()` só memória; `connect/disconnect/reset` apagam | outbox até recibo com ID original | Não lido | Exigir armazenamento cliente best-effort e recibo durável no servidor |
| Mesmo ID + payload distinto | Fixture `seen` só indexa perfil+ID, sem fingerprint | conflito `ID_REUSE_CONFLICT` persistido | Não lido | Não reaproveitar sem política de hash fiel |
| Reconnect | `ROOM_JOIN` gera novo snapshot e `pending.clear()` | nova sessão+`RECEIPT_QUERY`+RESYNC | Não lido | Restaurar ID pendente antes de habilitar nova ação |
| Snapshot | `ROOM_SNAPSHOT` com `n,walls,units` | DTO tipado por cena+visibilidade | Não lido | v1 rejeita `sceneId`, `markers` e campos extras; projeção explícita requerida |
| Marcadores | Não fazem parte de `checkSnapshot` room v1 | markers autorizáveis por `sceneId:markerId` | Não lido | Elementos administrativos não podem chegar por spread/copiar objetos |
| FOV e Party | Cliente valida chaves, não autorização de valores | A+C filtra antes do envio | Não lido | `checkPacket` aceita `actorId` privado SE tiver formato válido; filtro deve atuar antes da rede |
| Eventos do VLAB | Sem VLAB; `ROOM_EVENT` só MOVE_CONFIRMED/ROOM_UPDATED | evento mecânico obtido de VLAB homologado | Não lido | Não inferir dano/PA, posição XY ou efeito de envelope desconhecido |
| Tipos novos | Rejeita propriedades/pacotes desconhecidos | protocolo versionado | Não lido | Falha fechada + version negotiation, sem descartar UNKNOWN silenciosamente |
| Integridade | Cliente valida estrutura, não autentica servidor | ingresso e ordem autenticados no serviço confiável | Não lido | Projeção aninhada só por allowlist, recibos sem segredos |

## Evidência executada

- `work/test_contract_differential_014.py`: **19/19 comportamentos previstos** do `checkPacket/checkOutgoing/checkSnapshot`, incluindo inadmissibilidade do v2 e aceitação estrutural de `actorId` privado. Alguns resultados TRUE mostram precisamente os LIMITES da validação, **não certificação de segurança**.
- `work/test_v1_unknown_014.py`: **21 observações do TEST34 atendidas, 2 contratos-alvo RED**; comando `audit14_1` sem consulta de recibo após reconnect, `ROOM_SNAPSHOT` apaga pending, rejeição tardia desliga cliente; `send` pode lançar erro depois de ter transmitido dados, e o cliente perde tracking.
- `work/test_nonce_reload_014.py`: **6/6** observações de duas instâncias independentes que geram `demo_1`. É fixture DEMO e NÃO bug de produção, mas não pode fundamentar ID de comando real.
- `work/recovery_contract_014.js` + Node: **35 testes + 240 casos gerados PASS**, contrato sintético de referência que conserva commandId+identidade; nunca aplica combate, não é patch do Desenvolvedor.

**Tradução segura mínima:** manter `transportFactory` e a UI existente; adaptar exclusivamente fronteira cliente para identidade autenticada, outbox `UNKNOWN`, consulta de recibo, snapshot de projeção autorizada, versão de schema, revisões e IDs únicos. Sem side-effect no App principal e sem novo servidor. Exigir decisão competente sobre versão final somente após reabrir bytes do Codex; tratar v1 e v2 como versões candidatas e não como protocolo homologado.
