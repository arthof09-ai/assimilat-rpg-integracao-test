# PESQ-INOV-20261023-014 — Auditoria diferencial do TEST34 e recuperação de comandos ambíguos

**Data:** 23/10/2026. **Agente:** Terceiro Comestre Inovador / Pesquisador / MESTRE-SIDE/TEST. **Escopo:** mesmo Laboratório do Inovador; custo adicional R$0; NO-WRITE para Desenvolvedor, Codex, GitHub/gh-pages, VLAB, Party e O Primeiro. Não implantar Cloudflare, comprar pacotes, treinar IA, copiar código VLAB ou criar motor paralelo.

## Síntese executiva e ANTES→DEPOIS

**ANTES:** PESQ013 comprovava 3 Chromium WebSocket reais em um host e ACK ambíguo no servidor local. RUN011/TEST34 desenvolvia frontend `transportFactory`, mas v1 DEMO sem servidor/auth/UNKNOWN/RECEIPT_QUERY. Codex Python↔TS relatado com 6 envelopes e commit local, sem artefatos exportáveis aqui.

**DEPOIS:** Testei o CLIENTE REAL TEST34 em Chromium sem modificá-lo, reproduzindo **descarte da intenção após reconexão, após snapshot e após exceção de envio**; uma rejeição tardia após descarte derruba cliente. Verifiquei identidade DEMO dependente de profile, 19 campos/condutas diferenciais, colisão de IDs `demo_1` entre instâncias, replay silencioso de payload divergente no demo. Projeto separado de referência de outbox/recibos sintético passou em Node, sem reivindicar patch real. Cloudflare Python/DO investigado oficialmente, mas não executado no Workers Runtime pela indisponibilidade de dependências/conta. Nenhum VLAB real utilizado.

## Custódia de baselines

| Fonte REAL | SHA256 | Validação |
|---|---|---|
| Pacote técnico TEST34 | `e6bc5a780238690d415a4e37faa7bd9bb63ee669c3c95ecb2c49cb857109c1eb` | 492.513B, ZIP CRC PASS, manifesto 23/23 PASS |
| ZIP público TEST34 | `69617f492d23466fa4bcac7513925b4f8499ed03f8febcfd0ef1d7a63438a926` | 35.241B, ZIP CRC PASS |
| room-client.js orig TEST34 | `4c2f9edde0175ec933832e283a886e3688afd6ca8247e6b30acd40cb1ff7a6fc` | 15.743B, bytes mantidos originais |
| PESQ013 prévia | `ccf2193d9ee64a02e905c86c62ba801725ed392ace3b0121cddd1ecf50c47f9d` | 180.318B, CRC PASS, não repetir 98 testes |
| Codex local `3f5caad...` | SEM BYTES | GitHub API retornou HTTP 422 para commit local, pacote não listado em Library; *relato* não é prova física |

**Estado canônico:** RUN011 presente no Notion, TEST34 CANDIDATE, TEST32 último site gh-pages publicado que foi confirmado documentalmente. Nenhum RUN posterior na leitura anterior à escrita; PESQ014 inexistente antes da escrita.

## Resultados científicos independentes (não somar com testes do Desenvolvedor)

| Suíte | Denominador | Resultado / categoria |
|---|---:|---|
| `test_v1_unknown_014.py` | 23 | **21 observações esperadas PASS, 2 requisitos da futura integração RED**: sobreviver ao reconnect e enviar RECEIPT_QUERY |
| `test_contract_differential_014.py` | 19 | 19/19 comportamentos esperados; alguns resultados demonstram limites inseguros do formato, **não PASS de segurança** |
| `test_nonce_reload_014.py` | 6 | 6/6 provas de ID DEMO repetido em dois contextos novos |
| `test_v1_id_reuse_014.py` | 5 | 5/5 provas de retorno de evento antigo para payload distinto com mesmo ID no **demo**, sem denúncia de vulnerabilidade de servidor real |
| `test_recovery_contract_014.js` | 35 dirigidos + 240 gerados | 35/35 + 240/240 PASS do **contrato sintético de referência**, não TEST34 corrigido |
| `python_worker_abi_probe_014.py` | 13 | 13/13 PASS em **CPython 3.13.5 local**, NÃO Pyodide/Workers |
| Runtime Durable Objects verdadeiro | 0 | **NÃO EXECUTADO / HOLD** — sem wrangler/vitest/plugin instalados ou em cache, sem credenciais Cloudflare; não inventar PASS |

**Total informativo:** 101 verificações dirigidas (99 condutas observadas/esperadas + 2 requisitos RED), e 240 geradas separadas. São baterias heterogêneas; nenhum desses totais é homologação do Tabletop ou do VLAB.

## Três bloqueios novos concretamente delimitados

**B1 — UNKNOWN/RECIBO:** o TEST34 é um viewer de projeção DEMO, não um cliente de comandos duráveis. `reset()` zera `pending` ao reconectar e `ROOM_SNAPSHOT` também; `sendIntent` apaga após throw. Isso viola futura semântica de retry idempotente. Ação recomendada: contrato cliente com outbox persistente best-effort e recibo autoritativo server-side, `ACCEPTED/REJECTED/UNKNOWN`, query após reautenticação. **Rejeição tardia** deve ser reconciliada em vez de forçar fatal error, observando epoch e hashes.

**B2 — identities + scopes:** `ROOM_JOINED.selfId` iguala `profile` `gm/p1/p2`; em produto autenticado participantId não pode ser perfil escolhido. O schema snapshot v1 só aceita `{n,walls,units}` e não tem sceneId/markers. Evento estruturado pode incluir identificador privado de ator, embora o validator rejeite campos extras. Converter apenas nomes não impõe A+C; projeção deve acontecer antes do envio.

**B3 — idempotência/colisões:** perfil DEMO em nova instância gera `demo_1`, de novo. Ao reenviar mesma ID com payload diverso, demo retorna evento antigo em vez de `ID_REUSE_CONFLICT`. Trata-se de **limite da fixture**, não falha de servidor de produção. Padrão mínimo servidor: key `(room,participant,commandId)` + fingerprint do payload; cliente ID único resistente a reload e mesmo ID no retry. Se recibo expirar ou sessão for revogada, HOLD_UNKNOWN até política demonstrada.

## Python Workers, Durable Objects e VLAB

A Cloudflare suporta Python Workers e Durable Objects em Python; runtime usa Pyodide/JS FFI e filesystem em memória não durável. `threading/multiprocessing` não funcionam. Dependências devem ser pure Python ou wheels PyEmscripten/Pyodide e a API de storage durável é do DO, não arquivo local `sqlite3`. Experimento próprio local de serialização/integridade CPython 13/13 PASS (primeira versão do teste tinha duas asserções erradas, corrigidas antes da medição final). **Compatibilidade com VLAB atual NÃO demonstrada**: sem inventário autorizado dos imports, binários e interfaces/SQLite; bridge Codex não entregue fisicamente. Ver 
`report/PYTHON_WORKERS_VLAB_014.md`.

O runtime Vitest+DO **não foi executado**: Node v22.16.0 disponível, npm cache vazio para wrangler/vitest-plugin e nenhum package instalado; não presumir conta Cloudflare nem instalar/deploy. Gate `evictDurableObject`, `transactionSync`, SQL, hibernation auth e rollback pronto em `report/CLOUDFLARE_RUNTIME_GATE_014.md`.

## Adendo ao único D-INOV-033

Ver `report/ADENDO_D_INOV_033_014.md`; não criar D-INOV-034. O backend único deve ter proprietário/lease definidos pela Coordenação após recuperar pacote Codex; codificar apenas a camada de cliente quando a interface contratual estiver definida. VLAB Python permanece autoridade mecânica; nenhum ataque/dano/PA processado nesta pesquisa.

## Riscos, limites e NAC-PASS

PASS proporcional: fonte TEST34 física autenticada, cliente ORIGINAL em Chromium, reprodução RED de ACK ambíguo, comparativo por campo, PoC de recuperação com testes gerados, pesquisa das APIs oficiais, documentação e custódia/notion após readback. **HOLD:** código Codex real, runtime Workers/Pyodide, testes WSS Cloudflare, autenticação de produção, três Android reais, rollback na DO, VLAB real, versão/tempo mecânico e implantação.

**LAST-VERIFIED-UNIT:** `RUN011/TEST34` original room-client.js SHA 4c2f, 23 checks baseline, 19 schema, 6 DEMO reload, 5 changed payload demo, 35+240 outbox, 13 CPython, pacote frio e Notion readback.
**FIRST-PENDING:** obter artefato/revisões oficiais do Codex e escritor competente para escolher semântica única; então implementar em TEST34 cliente outbox/receipt/version negotiation (sem motor paralelo).
**NEXT:** operador autorizado executar Workers Vitest DO real/eviction, Python Workers ABI de módulo sintético, rollback, WSS seguro e três aparelhos Chrome Android em sala autenticada; somente após isso expor interface VLAB homologada.
**NO-REPEAT:** não rerodar PESQ013, não construir servidor alternativo, não converter VLAB a JS, não reescrever TEST34, não pedir FOV A+C novamente, não usar PixelLab, não deploy Cloudflare/gh-pages ou conceder auth real sem autoridade.
