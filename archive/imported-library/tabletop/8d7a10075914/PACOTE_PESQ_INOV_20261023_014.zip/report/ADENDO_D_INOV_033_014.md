# D-INOV-033 — ADENDO PESQ-014 (SEM NOVO DESPACHO / SEM ACK)

**Destinatário:** Coordenação CM-000001 e Segundo Comestre Inovador, somente pela rota competente. **Produto atual:** RUN-011 / TEST34 CANDIDATE, `room-client.js` SHA256 `4c2f9edde0175ec933832e283a886e3688afd6ca8247e6b30acd40cb1ff7a6fc`. **Artefato Codex:** commit local relatado, código não disponível; não executar ponte concorrente. **Fonte da proposta:** PESQ013 `PROTOCOLO_SALA_V2_013.md` não homologado. **Garantias estudadas:** cliente deve sobreviver a ACK incerto e servidor deve persistir recibo/estado/evento antes de ACK.

## Defeito de integração comprovado no cliente atual

- `ROOM_INTENT audit14_1` enviado; transporte fechado; `connect()` chama `disconnect()`/`reset()`, apaga `pending` e reenvia só `ROOM_JOIN`. Não existe `RECEIPT_QUERY`; o cliente deixa de acompanhar a ação possivelmente gravada. O recebimento de snapshot da mesma revisão também apaga entradas pendentes.
- Se o transporte enviar bytes e em seguida lançar exceção, `sendIntent()` apaga a intenção. Essa chamada não tem como provar que o servidor não executou.
- Rejeição atrasada depois do descarte do pending resulta em `status='error'` e limpeza de snapshot.
- Dois clientes DEMO novos geram `demo_1` e a fixture, ao receber mesmo ID com payload alterado, retorna evento antigo, não conflito. **Fixture TEST, não vulnerabilidade de servidor real.**
- `ROOM_JOINED` exige `selfId===profile` (`gm/p1/p2`), incompatível com identidade de participante opaca autenticada. Projeção v1 não carrega `sceneId` ou marcadores; `ROOM_EVENT` v1 aceita ator privado estruturado. Não adaptar renomeando pacotes indiscriminadamente.

## Contrato mínimo de correção PROPOSTO (sem reescrever o editor)

1. Manter `transportFactory` e quadro da sala do TEST34. Ao escolher transporte real, negociar `schemaVersion` e ingressar com **ticket autenticado** pelo servidor. Cliente recebe participantId/role autorizados; perfil DEMO não concede identidade.
2. `commandId` tem unicidade por `(roomId,participantId,commandId)`, origem persistente e NÃO `demo_1`. Antes de enviar, guardar outbox local *best-effort* em IndexedDB/solução autorizada, com fingerprint e baseRevision. Nenhuma segunda intenção enquanto primeira estiver incerta.
3. Quando enviar, tratar fechamento, exceção de transporte ou timeout como `UNKNOWN`. **Nunca gerar novo ID** para a mesma tentativa. Reabrir, autenticar participante, consultar recibo do mesmo ID. Até obter `ACCEPTED` ou `REJECTED` confiável, manter pendência (snapshot isolado não a substitui).
4. O serviço autoritativo persiste `state+receipt+event` atomicamente, vincula unit ao participantId autenticado, verifica seq/revision, role/epoch e fingerprint. `commandId` igual e payload igual retorna recibo; payload divergente gera `ID_REUSE_CONFLICT`. `NOT_FOUND` só permite retry com **mesmo** ID e sob política de retenção/epoch inequívoca; sem essa garantia, `HOLD_UNKNOWN`.
5. Após recibo `ACCEPTED`, fazer `RESYNC` de projeção autorizada, sem sintetizar evento nem resolver VLAB no cliente. `REJECTED` confirmado pode liberar outbox. Snapshots fora de ordem devem ser descartados/fazer resync.
6. D-INOV-032 A+C: DTO por allowlist de campos, inclusive propriedades aninhadas, filtrado **antes de enviar bytes à player**. Jamais confiar em checkPacket do browser para prover autorização. Evitar `actorId` de criatura oculta em evento PLAYER.
7. Código Codex precisa ser reaberto para decidir nomes exatos, compatibilidade de envelopes, produtor de recibos e origem de revision/intentId. **Não há liberação para construir outro backend ou usar fonte VLAB privada.**

## Critérios mensuráveis para Desenvolvedor TEST (não executados pelo Pesquisador na aplicação modificada)

- RED original TEST34: `21 observações PASS, 2 contratos alvo FAIL`, outras `19/19` probes semânticas, `6/6` nonce DEMO e `5/5` replay fixture; detalhes no pacote.
- GREEN proposicional protótipo cliente sintético: `35/35` checks e `240/240` dados gerados, em Node **sem login real**.
- Gate futuro: `ROOM_INTENT → COMMIT → ACK perdido → reconnect mesma identidade → RECEIPT_QUERY ID original → ACCEPTED → RESYNC`; simular queda durante commit e reinício; revogação/expiração, duas revisões, canários mestre e adversarial em três aparelhos Chrome Android **reais**.
- Não confundir v2 proposta, seis envelopes Codex relatados e TEST34 v1 original. No Work/Codex/Desenvolvedor, executar só sob autorização e branch isolada, sem substituir contrato oficial existente, sem novo motor ou custo.

**Estado:** evidência independente recebível pela Coordenação, D-INOV-033 permanece PROPOSTO / SEM ACK; componente de cliente oficial NÃO corrigido nesta pesquisa.
