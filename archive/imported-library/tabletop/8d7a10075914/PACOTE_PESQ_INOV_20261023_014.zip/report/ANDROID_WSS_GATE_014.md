# PESQ-014 — Guia de aceite Android REAL (planejamento, não execução)

Só após implantação WSS HTTPS num TEST gratuito autorizado e gate Workers PASS. Necessários 1 Android Mestre e 2 aparelhos das players, sem dados reais em primeira execução e sem depender de notebook permanentemente.

1. Abrir **URL HTTPS TEST com certificado válido** nos três aparelhos (registrar versão Chrome, modelo, rede, data, URL, código test ref). Nunca ignorar erro de certificado.
2. Gerar três tickets temporários em servidor, dois PLAYER e um MASTER, vinculados à sala/unidades; conferir datas de expiração e revogação antes de conectar. Não embutir ticket em código público, screenshot nem logs.
3. JOIN de três aparelhos; comparar roomId, role real e revision pública. Inspecionar bytes transmitidos por serviço de observabilidade de TEST com mascaramento de tickets. Confirmar ausência de notes/adminMarkers/adminRevision/event actorId privados em **payloads crús PLAYER**.
4. Player 1 envia movimento TEST com `commandId` único e `baseRevision`. Todos recebem snapshot autorizado. Cronometrar RTT externo, bytes e desconexões; 10 movimentos simples, sem chamadas VLAB mecânicas.
5. Forçar queda da rede após `INTENT` e antes de ACK quando possível; mostrar UNKNOWN, restaurar Wi-Fi, `RECEIPT_QUERY` mesmo ID; sem duplicar evento. Se não for possível controlar o timing num aparelho, emular falha no serviço TEST e provar recibo no SQLite DO.
6. Reabrir a mesma sala e solicitar RESYNC após evento perdido; verificar `eventId` monotônico e ausência de snapshot regressivo. Revoke ticket MASTER e checar bloqueio mesmo com WS antiga/hibernada.
7. Simular interrupção/redeploy sob competência do Desenvolvedor; confirmar estado/recibos após DO eviction; registrar logs/hashes sem dados secretos.
8. Atualizar contador de uso Free Cloudflare e testar acesso sob plano sem cobrança. Não declarar `R$0 para sempre` sem checagem da conta.

**STOP/HOLD:** Certificado inválido; segredo em payload PLAYER; falha de recibo pós-restart; mais de um servidor autoritativo; persistência sem atomicidade; conta/tarifa exigindo pagamento; VLAB invocado sem homologação. **Estado atual: NÃO REALIZADO.**
