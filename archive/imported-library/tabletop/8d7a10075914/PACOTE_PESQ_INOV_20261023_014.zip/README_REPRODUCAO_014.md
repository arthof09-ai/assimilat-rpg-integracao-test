# Reexecução fria PESQ-014 — MESTRE-SIDE/TEST

1. Extrair o pacote autoral em diretório novo. Os ZIPs TEST34 originais e PESQ013 **NÃO** estão dentro deste pacote; recuperar na Biblioteca Mestre seus nomes/hashes conforme relatório, validar CRC/manifesto e extrair em `base34/` e `base13/` ao lado de `work/` (mesmo formato do relatório). Assim nenhum arquivo autoritativo é editado.
2. Requer Python 3.13 (Playwright), Chromium Linux `/usr/bin/chromium` ou ajuste controlado do executável, Node 22.16.0. Sem internet, conta Cloudflare, VLAB, login ou gasto adicional.
3. `python work/test_v1_unknown_014.py` → 21 observações PASS, 2 alvos RED esperados; grava `results/BASELINE_V1_UNKNOWN_014.json`.
4. `python work/test_contract_differential_014.py` → 19/19 comportamentos TEST34 confirmados.
5. `python work/test_nonce_reload_014.py` → 6/6 comportamento de IDs DEMO duplicados. `python work/test_v1_id_reuse_014.py` → 5/5 resposta cacheada DEMO, payload alterado.
6. `node work/test_recovery_contract_014.js` → 35 testes dirigidos e 240 gerados. `python work/python_worker_abi_probe_014.py` → 13/13 **CPython local**; **não Pyodide**.
7. `python -m zipfile -t PACOTE_PESQ_INOV_20261023_014.zip` / `MANIFEST_SHA256_PESQ014.json`: validar hashes SHA256 de todos os outros arquivos e CRC. Reexecução fria deve produzir mesmos totais, não necessariamente mesmos tempos.

**Sem linha de comando Cloudflare executada:** seguir `report/CLOUDFLARE_RUNTIME_GATE_014.md` apenas quando houver runtime real sob executor competente. Não instalar `wrangler` com npm como efeito colateral deste README.

**Fixtures sintéticas:** os scripts montam `public/room-client.js` TEST34 original em Chromium sem modificar o arquivo. Dados e IDs fake. Não há bancos reais VLAB nem Party, não há segredos. Alguns testes intencionalmente marcam FAIL para mostrar lacunas do produto candidato: não transformar RED em PASS por editar expectativa.
