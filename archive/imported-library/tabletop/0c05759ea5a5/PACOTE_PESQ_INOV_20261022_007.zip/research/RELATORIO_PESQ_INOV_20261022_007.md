# PESQ-INOV-20261022-007 — Auditoria aplicada TEST26 e investigação tecnológica em vídeo

**Data:** 22/10/2026. **Escopo:** Terceiro Comestre Inovador Pesquisador, MESTRE-SIDE/TEST, Laboratório do Inovador existente. **Autoridade:** ordem expressa do Mestre. **Custo adicional:** R$0. **NO-WRITE:** código do Desenvolvedor, outros laboratórios, VLAB, Party, O Primeiro, GitHub e site público. **Fonte canônica interna:** [Laboratório do Inovador](https://app.notion.com/p/401c2b324ede809585d3d1907c194df9). **Governança:** BOOTSTRAP, NAC-CONT-03, NAC-NORM-01 quando aplicável, NAC-PASS-02 proporcional, REG-ROUTE-03.

## 1. Versão materialmente auditada

O último desenvolvimento documental encontrado foi **RUN-008 / TEST24–26** (561/561 afirmações digitais PASS do Desenvolvedor, NÃO reexecutadas integralmente). Três ZIPs reais da Library foram recuperados e autenticados:

| Origem | Bytes | SHA-256 e validação |
|---|---:|---|
| `PACOTE_TECNICO_TABLETOP_TEST24_A_TEST26_20261022.zip` | 7.806.415 | `747e8bc2cb59d96d9e4c3bc64b6d348813d8f6a3844f44f4a0707161db3bf0f0`, CRC PASS; 57/57 manifesto SHA PASS |
| `TABLETOP_SITE_SINTETICO_TEST26.zip` | 22.935 | `4e56b4d1208aa7165d412fe446996e53240f199959c0bf6ff4d076ed51fe39b9`, três arquivos, CRC PASS |
| `PACOTE_PRIVADO_VLAB_R205_TIMELINE_TEST26_MESTRE_ONLY.zip` | 481.564 | `31450ed2cbb20da44f310493b2cbb795082ee0ba3cf7dfc166bfc82bdb07da53`, CRC PASS; 10/10 manifesto SHA PASS, somente leitura |

`public/app.js` do ZIP técnico = `app.js` do ZIP público, SHA-256 **`218a0cee00e37d14dcc9666ba491f0287b72d1cda4633f24b1416c5ec3acf0c5`**. Fonte intocada na bancada, execução Chromium headless Linux com 390×844; `page.set_content` e CSP desativada **somente na montagem da bancada**, CSP original preservada no pacote. `localStorage` substituído por implementação determinística no contexto do teste; não afirmar Chrome Android físico. Dados VLAB privados NÃO extraídos para artefatos compartilháveis.

**Estado PESQ-006 versus TEST26:** D024 núcleo central de comandos **NÃO IMPLANTADO**, mas `snap()/commit()`+`scene()` já oferecem primitives suficientes para extensão incremental; D025 **régua SVG já implementada**, overlay de anotações ainda experimento; D026 suíte digital do Desenvolvedor 561/561 alegada, auditoria adicional gerativa/mutacional aqui executada; D027 timeline R205 Mestre-only TEST26 existe, nenhuma ponte autorizada para Party; D028 manter DOM/JS nativo e não migrar Phaser/Pixi/REA sem gargalo.

## 2. Descobertas materiais do TEST26 original

**D-INOV-029 — P0/P1 — alias de coordenadas em JSON canônico (NOVO, VERIFICADO):** `validateScene()` usa `/^\d+,\d+$/` para paredes, perigos, exploração e chaves de terreno. Isso permite `02,02`, `01,01` e até duplicatas semânticas `2,2`+`02,02`. Renderização, FOV, ocupação e editor usam `${x},${y}`. Na bancada uma importação de backup real da UI sintética com `walls=['02,02']` foi **aceita, gravada, validada e não desenhada como parede**. `walls=['01,01']` foi aceita apesar de unidade em (1,1). Estado em bytes é sintético, não ficha do RPG. Gerador seeded `20261022`: **400 variantes**, 200 canônicas aceitas e 200 não canônicas também aceitas (o esperado pelo contrato recomendado seria rejeitar estas últimas). Variantes não são 200 bugs distintos, mas uma classe de equivalência. Perigo/terreno/explored também aceitam alias.

**Correção proposta D029:** validar representação canônica (`key===String(x)+','+String(y)`) em todos os campos pertinentes; para backups anteriores, migrar com normalização EXPLÍCITA, rejeitar colisão entre aliases, parede sobre unidade e topologia/replay que exija revisão. Não descartar silenciosamente histórico legado. Prova isolada `coord_contract_007.js`, `test_coord_contract_007.js`: **12/12 PASS**, não aplicada ao TEST26.

**D-INOV-030 — P1 — ação de edição sem efeito apaga Refazer (NOVO, VERIFICADO):** `clickCell()` faz `snap()` ANTES de saber se houve alteração; `snap()` limpa `future=[]`; quando clique Apagar é no vazio, `history.pop()` desfaz apenas o snapshot novo, mas não restaura `future`. Passos: criar parede, Desfazer, selecionar Apagar, tocar casa vazia, Refazer. Mensagem observada `Nada para refazer.`. **Correção mínima:** efetuar `snap` só quando mutação real ocorrer, ou preservar/restaurar o `future` anterior na via no-op; teste de aceite com quatro modos, cenários copiados e replay. Não confundir com falha da topologia, já corrigida no TEST24.

**D-INOV-031 — P1 — régua não invalidada por redimensionamento (NOVO, VERIFICADO):** mapa 20×20, régua pontos (15,15) e (19,19) zero-based, reduzir para 7×7 (unidades permanecem internas). API de leitura de régua continua reportando `16,16 → 20,20`, fora da grade, enquanto `validateWorkspace()==true`. Isso é estado de interface efêmero inválido, não corrupção de save. **Correção mínima:** quando `resize/undo/redo/restore` alterarem geometria, descartar/regenerar régua com checagem `inside`; reaproveitar `renderRuler()`, não criar motor de comandos.

**Regressões positivas confirmadas:** nova invalidação de replay por parede usando o modo Apagar funciona; mixed-ID sem `sequence` continua rejeitado; o replay numérico regressivo é rejeitado; cópia de cena não desenha régua herdada; campos de unidade com ID duplicado e coordenadas fora da grade são rejeitados.

**Bateria independente:** `audit_contracts_007.py` registra **27 contratos**, **15 alinhados** e **12 não alinhados com os invariantes desejados**, com três classes principais (alias, redo noop, régua stale). As 400 variantes seed estão agregadas no mesmo arquivo, NÃO somar aos 27 como assertivas equivalentes. Seis mutantes fonte-intencionais `mutation_test26_007.py`: **6/6 detectados**, tendo a fonte original **6/6 PASS** nestes seis contratos históricos; modificações SOMENTE temporárias em memória. A contagem de mutantes nunca deve ser somada aos testes oficiais 561 do Desenvolvedor.

## 3. Prova de integração incremental, NÃO novo núcleo oficial

**D-INOV-032 — P1 / experimento controlado:** em vez de introduzir outro estado autoritativo, o adaptador `overlay_adapter_007.js` lê `window.__tabletopTEST.state()/scene()` (API limitada a TEST) e desenha marcadores SVG leves **sobre o mesmo `#board`**. Mantém IDs de marcadores puramente visuais por cena, whitelist, coordenadas inteiras, máximos, `pointer-events:none` e texto escapado. Como o `ensureBoard()` recria o DOM ao redimensionar, a prova explicita `draw()` após mudança de cena/zoom/grade (não pressupor integração automática). Testes `overlay_browser_007.py`: **16/16 PASS**, incluindo alinhamento antes/depois do zoom, régua original intacta, ausência de vazamento entre cenas, marcador fora da grade descartado, ausência de rede e código oficial do Desenvolvedor preservado. Captura `CANARIO_OVERLAY_TEST26_390x844.png` no pacote.

**Contrato sugerido D032:** `renderPresentationOverlay(sceneId, annotations, boardGeometry)` como *função de apresentação*, sem writer de `workspace`, sem PA/vida/movimento, sem quebrar undo/redo; persistência só se for aprovada uma extensão versionada ao schema atual. Não transformar ocultação CSS de FOV em proteção da Party. **Nenhum benefício de migração Phaser, Pixi ou Canvas foi demonstrado por este ensaio.** SVG atende poucos marcadores TEST; Chrome Android real continua pendente.

**Eventos externos:** `event_projection_007.js` + `test_event_projection_007.js`, **12/12 PASS** com fixtures sintéticas. API de teste `presentSyntheticTimeline` produz `originDB,commitSeq,sourceCommand,sourceRowSHA,kind,actor,target,resourceChange,positionXY:null`. Valida identidades compostas banco/commit/lista/índice, fallback UNKNOWN, rejeita duplicatas e tentativa de scope PARTY. Nenhuma coordenada XY inferida, nenhum dado real R205 incluído, nenhum hash de conteúdo autentica sozinho origem. Este é exercício de contrato derivado de D027, não nova integração canônica, nem substituto do visualizador TEST26 existente.

## 4. Radar YouTube e a qualidade real de acesso

**Quatro links da ordem foram tentados diretamente. Não assisti integralmente a nenhum vídeo e não obtive transcrição integral verificável.** A matriz `YOUTUBE_RADAR_007.json` discrimina por URL o que veio de editor original, metadados secundários e a ausência de conteúdo. Priorizei equivalentes primários verificáveis em vez de resumir conteúdo presumido de uma URL.

1. [Google Cloud Tech — vídeo de design de jogo com IA](https://www.youtube.com/watch?v=tHO9vbS62M0): descrito por um espelho como **How to design a game with Claude code on Gemini Agent Platform**, 28/07/2026 (data de fonte SECUNDÁRIA, não validada diretamente). Descrição menciona wireframes HTML, agentes e jogo com várias fases. **Sem transcrição completa, sem execução, sem repo encontrado de vínculo comprovado.** Conclusão útil como HIPÓTESE: contrato visual pequeno + revisão de browser; não recomendar Gemini Agent Platform nem infraestrutura Cloud para o Tabletop.
2. [Jackson Mittag — Claude + Ghidra MCP](https://www.youtube.com/watch?v=ybSWI2cZzIU): [post do próprio autor no LinkedIn](https://www.linkedin.com/posts/theemperorspath_stop-manually-reversing-use-claude-ghidra-activity-7449995155337555968-8LaB) descreve desafio CrackMe e seis minutos, **relato do autor, não benchmark independente**. Vídeo/legenda/código do desafio não foram examinados; não usar engenharia reversa de terceiros, anti-debug, DRM ou crack. Inaplicável ao nosso JS autoral e telefone Android atual.
3. [Google Cloud Tech — agentes programadores](https://www.youtube.com/watch?v=pIq2s5BKpkw): acesso direto indisponível; título, publicação, transcrição e repositório específico **NÃO VERIFICADOS**. Não atribuo conteúdo a esta URL. Substitutos PRIMÁRIOS: [Google Developers, 09/09/2026 — Anatomy of Harness Engineering](https://developers.googleblog.com/the-anatomy-of-harness-engineering-how-to-evaluate-iterate-and-guard-ai-coding-agents/) (avaliações comportamentais, casos observáveis) e [Google Codelabs — Beyond vibe coding for the web](https://codelabs.developers.google.com/codelabs/beyond-vibe-coding-for-the-web) (especificações, revisão por agente independente, canário de navegador). **Aplicação já reproduzida**: 6 mutantes contra TEST26 real.
4. [freeCodeCamp — Godot Game Development for Beginners](https://www.youtube.com/watch?v=MiPkcTaRbfQ): [artigo OFICIAL da freeCodeCamp, 10/09/2025](https://www.freecodecamp.org/news/learn-game-development-by-building-your-first-platformer-with-godot) identifica curso de Sarah e Reem: tilemap, cenas, animação e export web. Landing YouTube vista, porém vídeo longo/transcrição NÃO integralmente vistos. **Utilidade pontual:** isolamento visual de cenas e separação de inputs; Godot não é dependência indicada para nosso site estático.

**Investigação adicional útil:** [Google Codelabs — Launch your web-based video game with AI](https://codelabs.developers.google.com/codelabs/cloud-run/launch-your-web-based-video-game-with-ai), atualizada em 09/09/2026, confirma padrão Event Sourcing, mas seu exemplo usa Firestore, Firebase Auth e Cloud Run; no RPG NÃO provisionar backend nem custo. O método de registrar evento/projeção já existe em forma documental no VLAB e TEST, sob autoridades distintas.

**Guia para agentes do RPG:** recuperar versão/hash → fixar contrato observable → RED reprodutível → mudança autorizada pelo Desenvolvedor → GREEN + legacy → mutantes negativos/seeded → replay frio e readback → NAC-PASS proporcional. Sem criar operação, agente pago ou sistema paralelo. [Google Developers 09/09/2026](https://developers.googleblog.com/the-anatomy-of-harness-engineering-how-to-evaluate-iterate-and-guard-ai-coding-agents/) sustenta micro-avaliações comportamentais como complemento à pontuação end-to-end. Isso é continuidade de D026, não despacho duplicado.

## 5. Status de cada despacho anterior

| Código | Estado aplicado |
|---|---|
| D-INOV-024 | Núcleo autônomo de comandos **não recomendado neste ciclo**: reutilizar workspace, scene, snap/commit. Anotação genérica ainda não incorporada. |
| D-INOV-025 | TEST26 já contém régua SVG, novo overlay complementar **somente POC 16/16**. |
| D-INOV-026 | Seguimento concreto entregue: 400 inputs gerados, 27 contratos, 6 mutantes mortos e novas lacunas. |
| D-INOV-027 | TEST26 continua timeline Mestre-only existente; evento→projeção sintético POC 12/12, ligação canônica HOLD. |
| D-INOV-028 | Não migrar para Phaser/Pixi/Godot ou novos serviços; não há benchmark material que sustente troca. |

## 6. Próximos gates e retomada

**Entregáveis:** scripts/testes JSON/PNG, relatório, radar de vídeos, projeto sintético. O ZIP da pesquisa contém APENAS código original do pesquisador e estatísticas/fixtures sintéticas, sem app do Desenvolvedor, sem ZIP/R205 real, sem código comercial/ROM, sem dados Party/O Primeiro.

**NAC-PASS-02 proporcional:** manifestos/CRC dos RUN008 57/57 técnico, 10/10 privado verificados; auditorias dirigidas e mutações executadas em cópias isoladas; arquivos de pesquisa preservados por hash; readback Notion/Library somente quando comprovados. **NÃO** homologar produto TEST26: três classes de defeitos com reprodução real em Chromium, Android físico e concorrência multiaba HOLD; sem ACK do Desenvolvedor.

**FIRST PENDING:** verificar RUN-009 ou posterior antes de reabrir os bugs; entregá-los pelo Coordenador ao Desenvolvedor como D029 (alias coordenadas), D030 (redo noop) e D031 (régua fora da grade), priorizar D029 pela inconsistência importação/render, sem outra engine; D032 overlay é opção incremental para avaliação após consertos. Em seguida auditoria Android física do TEST atualizado e vídeo pIq/Ghidra somente se houver transcrição/repo confiável, sem impedir progresso.
