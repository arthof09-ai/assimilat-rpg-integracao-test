/* PESQ-007 canonical-coordinate contract proof. Independent, not developer patch. */
'use strict';
function canonicalCellKey(key,n,legacy=false){
 if(typeof key!=='string'||!/^\d+,\d+$/.test(key))throw Error('Malformed cell key');
 const [x,y]=key.split(',').map(Number);if(!Number.isSafeInteger(x)||!Number.isSafeInteger(y)||x<0||y<0||x>=n||y>=n)throw Error('Out of bounds');
 const canonical=`${x},${y}`;if(!legacy&&canonical!==key)throw Error('Noncanonical coordinate');return canonical;
}
function migrateSyntheticCellKeys(scene){
 const s=JSON.parse(JSON.stringify(scene)), original={walls:s.walls.slice(),danger:s.danger.slice(),explored:s.explored.slice(),terrain:{...s.terrain}};
 const normalize=list=>{const items=list.map(key=>canonicalCellKey(key,s.n,true));if(new Set(items).size!==items.length)throw Error('Alias collision');return items;};
 s.walls=normalize(s.walls);s.danger=normalize(s.danger);s.explored=normalize(s.explored);
 const terrain={};for(const [key,value] of Object.entries(s.terrain)){const newKey=canonicalCellKey(key,s.n,true);if(Object.hasOwn(terrain,newKey))throw Error('Terrain alias collision');terrain[newKey]=value;}s.terrain=terrain;
 const occupied=new Set(s.units.map(u=>`${u.x},${u.y}`));if(s.walls.some(x=>occupied.has(x)))throw Error('Legacy wall overlaps token');
 if(s.walls.some(x=>s.danger.includes(x)||Object.hasOwn(s.terrain,x)))throw Error('Legacy topology conflict');
 // Source frameTopology serializes wall keys: migration would invalidate snapshots.
 const changed=JSON.stringify(original)!==JSON.stringify({walls:s.walls,danger:s.danger,explored:s.explored,terrain:s.terrain});
 if(changed&&(s.frames.length>0||s.frameTopology!==null))throw Error('Replay topology requires explicit review before migration');
 return s;
}
module.exports={canonicalCellKey,migrateSyntheticCellKeys};
