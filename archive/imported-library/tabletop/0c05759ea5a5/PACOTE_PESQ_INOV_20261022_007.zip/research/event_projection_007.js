/* Synthetic event contract experiment, PESQ-007. Not VLAB production source.
   No XY invented, no combat mechanics, no network or Party projection.
*/
'use strict';
function presentSyntheticTimeline(input){
 if(!input||input.schema!=='assim.research.synthetic-event.v1'||input.scope!=='MESTRE_ONLY'||!Array.isArray(input.events)||input.events.length>1000)throw Error('Invalid or unapproved synthetic stream');
 const key=/^[a-z0-9_-]{1,60}$/;const hash=/^[a-f0-9]{64}$/i;const seen=new Set();const out=[];
 for(const event of input.events){
  if(!event||typeof event!=='object'||!key.test(event.bank)||!Number.isSafeInteger(event.seq)||event.seq<1||!['new_native_events','events_added'].includes(event.list)||!Number.isSafeInteger(event.index)||event.index<0||!hash.test(event.rowSHA)||!key.test(event.cmdId))throw Error('Invalid provenance');
  const id=[event.bank,'commit'+event.seq,event.list,'event'+event.index].join(':');if(seen.has(id))throw Error('Duplicate event identity');seen.add(id);
  const allowed=new Set(['turn_start','turn_end','weapon_attack','wait','unknown']);
  const kind=typeof event.action==='string'&&allowed.has(event.action)?event.action:'UNKNOWN';
  const clean=v=>typeof v==='string'&&v.length<=70&&!/[<>\u0000-\u001f]/.test(v)?v:null;
  out.push(Object.freeze({id,originDB:event.bank,commitSeq:event.seq,sourceCommand:event.cmdId,sourceRowSHA:event.rowSHA,kind,actor:clean(event.actor),target:clean(event.target),resourceChange:Number.isFinite(event.resourceChange)?event.resourceChange:null,positionXY:null,unknownKind:kind==='UNKNOWN'}));
 }
 out.sort((a,b)=>a.originDB.localeCompare(b.originDB)||a.commitSeq-b.commitSeq||a.id.localeCompare(b.id));
 return Object.freeze(out);
}
module.exports={presentSyntheticTimeline};
