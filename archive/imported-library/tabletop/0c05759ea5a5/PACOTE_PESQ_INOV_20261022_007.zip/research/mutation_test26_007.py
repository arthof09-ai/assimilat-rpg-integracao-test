"""Controlled mutations of in-memory TEST26 source copy only, not RUN008 artifact."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json, os
BASE=Path(os.environ.get('TEST26_PUBLIC_DIR', str(Path(__file__).resolve().parents[1]/'work/public')));OUT=Path(__file__).resolve().parent/'evidence'
html=(BASE/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"');js=(BASE/'app.js').read_text()
mutants=[
 ('topology_guard','if(topology(s)!==previousTopology){s.frames=[];', 'if(false){s.frames=[];', 'topology'),
 ('scene_id_validation',"const validId=x=>typeof x==='string'&&/^[a-z0-9_-]{1,32}$/.test(x)&&!['__proto__','constructor','prototype'].includes(x);", "const validId=x=>typeof x==='string';", 'bad_id'),
 ('duplicate_unit_guard','||ids.has(u.id)||','||false||','duplicate_unit'),
 ('frame_topology_validation','if(s.frameTopology!==null&&s.frameTopology!==topology(s))return false;', 'if(false)return false;', 'topology_mismatch'),
 ('replay_order_guard','num<=previousNumeric','false', 'replay_out_of_order'),
 ('ruler_scene_guard',"const show=Boolean(s.mode==='measure'&&rulerSceneId===s.id&&rulerA);", "const show=Boolean(s.mode==='measure'&&rulerA);", 'ruler_isolation'),
]
js_test={
 'topology':"a.mode('wall');a.cell(2,2);a.capture();a.mode('erase');a.cell(2,2);return a.scene().frames.length===0&&a.validateWorkspace(a.state());",
 'bad_id':"let w=a.state();w.scenes[0].id='bad!';w.active='bad!';return !a.validateWorkspace(w);",
 'duplicate_unit':"let w=a.state();w.scenes[0].units[1].id=w.scenes[0].units[0].id;return !a.validateWorkspace(w);",
 'topology_mismatch':"let w=a.state();w.scenes[0].frameTopology='mismatch';return !a.validateWorkspace(w);",
 'replay_out_of_order':"a.capture();a.capture();let d=a.makeReplay();d.events[0].id='frame-002';d.events[1].id='frame-001';return !a.validateReplay(d);",
 'ruler_isolation':"a.mode('measure');a.cell(2,2);a.cell(4,4);a.copyScene();return document.getElementById('rulerOverlay').hasAttribute('hidden');"
}
res=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for name,needle,replacement,key in [('original','NO_MUTATION_SENTINEL','NO_MUTATION_SENTINEL',k) for k in js_test]+mutants:
  if name=='original': source=js
  else:
   assert js.count(needle)>=1,(name,js.count(needle))
   source=js.replace(needle,replacement,1)
  page=browser.new_page(viewport={'width':390,'height':844})
  page.set_content(html)
  page.evaluate("window.st=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.st.get(k)||null,setItem:(k,v)=>window.st.set(k,String(v))}})")
  page.add_script_tag(content=source)
  try: good=page.evaluate('() => {const a=window.__tabletopTEST;'+js_test[key]+'}')
  except Exception as e:good=False
  res.append({'version':name,'contract':key,'contractPass':bool(good),'mutationKilled':name!='original' and not bool(good)})
  page.close()
 browser.close()
OUT.joinpath('MUTACOES_TEST26_007.json').write_text(json.dumps({'mutants':res,'original_pass':sum(x['contractPass'] for x in res if x['version']=='original'),'killed':sum(x['mutationKilled'] for x in res),'totalMutations':len(mutants),'interpretation':'Mutants are deliberate temporary source modifications; original suite outcome separate.'},indent=2))
print(json.dumps(res,indent=2))
