# PESQ-INOV-20261022-007 — how to rerun (synthetic research only)

Artifacts are original research / synthetic fixtures. **No official Tabletop source, R205 data, or commercial assets are inside this ZIP.**

Obtain a separate, authorized copy of the developer's original `TABLETOP_SITE_SINTETICO_TEST26.zip` from `/RPG-Assimilacao/Tabletop-Inovador/` (SHA256 `4e56b4d1208aa7165d412fe446996e53240f199959c0bf6ff4d076ed51fe39b9`). Unzip it into a working folder, for example `/tmp/test26_public/` (must contain `index.html`, `styles.css`, and `app.js`). Do **not** edit the original or upload its copy publicly as this research's source.

```
export TEST26_PUBLIC_DIR=/tmp/test26_public
python research/audit_contracts_007.py
python research/mutation_test26_007.py
python research/overlay_browser_007.py
node research/test_coord_contract_007.js
node research/test_event_projection_007.js
```

Requires Python 3 with Playwright + Chromium and Node.js. Chromium browser executable `/usr/bin/chromium` is used for this reproducible Linux lab; adjust executable_path only in an authorized local research copy if your system differs. The test rig injects a synthetic `localStorage` and removes the CSP header in its ephemeral HTML for local script injection. The distributed HTML/JS and production CSP are untouched. These browser tests are **not** physical Android results.

Interpretation: the JSON suite scores conformity with a **proposed stricter canonical-coordinate contract**; red rows are observations of current TEST26 behavior. Seeded examples count inputs rather than independent bugs; mutant kills are against source copies; the official RUN-008 561 tests are NOT part of this research's denominator.

VLAB remains MESTRE-ONLY and NO-WRITE. `event_projection_007.js` uses invented *synthetic* stream events only and intentionally returns `positionXY: null`.
