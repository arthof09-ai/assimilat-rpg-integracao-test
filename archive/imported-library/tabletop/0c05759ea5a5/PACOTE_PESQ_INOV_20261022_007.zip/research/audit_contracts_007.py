"""PESQ-007: browser contract audit on verbatim TEST26 public JS (read-only)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from hashlib import sha256
from collections import Counter
import json, random, os
BASE=Path(os.environ.get('TEST26_PUBLIC_DIR', str(Path(__file__).resolve().parents[1]/'work/public')))
OUT=Path(__file__).resolve().parent/'evidence';OUT.mkdir(exist_ok=True,parents=True)
html=(BASE/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
css=(BASE/'styles.css').read_text(); js=(BASE/'app.js').read_text()
checks=[]; samples=[]; seed=20261022

def record(name,expected,actual,category='contract',detail=''):
 checks.append(dict(name=name,expected=expected,actual=actual,pass_=expected==actual,category=category,detail=detail))

def page_new(browser):
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.set_content(html);page.add_style_tag(content=css)
 page.evaluate("window.__store=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__store.get(k)||null,setItem:(k,v)=>window.__store.set(k,String(v)),removeItem:k=>window.__store.delete(k)}})")
 page.add_script_tag(content=js)
 return page
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=page_new(browser)
 raw=page.evaluate("""() => {let a=window.__tabletopTEST;const check=key=>{let w=a.state();w.scenes[0].walls=[key];return a.validateWorkspace(w)};const fields={};for(const f of ['walls','danger','explored','terrain']){let w=a.state();if(f==='terrain')w.scenes[0].terrain['02,02']='grass';else w.scenes[0][f]=['02,02'];fields[f]=a.validateWorkspace(w);}let dup=a.state();dup.scenes[0].walls=['2,2','02,02'];let token=a.state();token.scenes[0].walls=['01,01'];return {canonical:check('2,2'),noncanonical:check('02,02'),negative:check('-1,2'),outOfBounds:check('99,99'),duplicateAlias:a.validateWorkspace(dup),tokenOverlap:a.validateWorkspace(token),fields};}""")
 for key,expected in [('canonical',True),('noncanonical',False),('negative',False),('outOfBounds',False),('duplicateAlias',False),('tokenOverlap',False)]:record('coord_'+key,expected,raw[key],'coordinate')
 for key,val in raw['fields'].items():record('field_'+key+'_noncanonical',False,val,'coordinate')
 # Distinct negative test families, instantiated in page, not copied from Developer tests.
 others=page.evaluate("""() => {let a=window.__tabletopTEST;const checks={};for(const [name,fn] of Object.entries({unitOut:w=>w.scenes[0].units[0].x=99,unitDup:w=>w.scenes[0].units[1].id='u1',outBoundWall:w=>w.scenes[0].walls=['22,22'],duplicateWall:w=>w.scenes[0].walls=['2,2','2,2'],invalidProto:w=>w.scenes[0].terrain['__proto__']='grass',validDanger:w=>w.scenes[0].danger=['2,2'],validExplored:w=>w.scenes[0].explored=['2,2']})){let w=a.state();fn(w);checks[name]=a.validateWorkspace(w);}return checks;}""")
 # __proto__ property assignment JS sets prototype and creates no own key; don't infer security rejection from that.
 for name,expected in [('unitOut',False),('unitDup',False),('outBoundWall',False),('duplicateWall',False),('validDanger',True),('validExplored',True)]:record(name,expected,others[name],'contract')
 # Seeded property series: 400 scene checks, baseline 200 canonical must accept, 200 padded must reject.
 generated=page.evaluate("""seed => {let a=window.__tabletopTEST;let state=seed>>>0;const rnd=()=>{state=(1664525*state+1013904223)>>>0;return state;};let out={valid:0,invalidRejected:0,invalidAccepted:0,unexpectedCanonicalRejected:0,examples:[]};for(let i=0;i<400;i++){let w=a.state();let x,y;do{x=rnd()%7;y=rnd()%7}while(['1,1','1,3','5,2'].includes(`${x},${y}`));let valid=(i%2===0);let key=valid?`${x},${y}`:`${String(x).padStart(2,'0')},${String(y).padStart(2,'0')}`;w.scenes[0].walls=[key];let accepted=a.validateWorkspace(w);if(valid){out.valid++;if(!accepted)out.unexpectedCanonicalRejected++}else {if(!accepted)out.invalidRejected++;else {out.invalidAccepted++;if(out.examples.length<10)out.examples.push(key)}}}return out;}""",seed)
 record('generated_valid_canonical_all',0,generated['unexpectedCanonicalRejected'],'generated',f"n={generated['valid']}")
 record('generated_noncanonical_rejected_all',200,generated['invalidRejected'],'generated',f"n={generated['invalidAccepted']+generated['invalidRejected']}")
 detail=page.evaluate("""() => {const a=window.__tabletopTEST,w=a.state();w.scenes[0].walls=['02,02'];let initial=a.validateWorkspace(w);a.restoreCandidate(w);const t=document.querySelector('[data-xy="2,2"]');return {accepted:initial,stored:a.scene().walls,wallDisplayed:t.classList.contains('wall'),storageEntry:window.__store.size,hiddenForRenderer:!t.classList.contains('wall')};}""")
 record('accepted_invalid_coord',False,detail['accepted'],'ui-observation')
 record('render_matches_imported_wall',True,detail['wallDisplayed'],'ui-observation')
 # independent fresh copies for UI sequences
 page.close();page=page_new(browser)
 no_op=page.evaluate("""() => {const a=window.__tabletopTEST;a.mode('wall');a.cell(2,2);a.undo();const before=a.scene().walls.slice();a.mode('erase');a.cell(4,4);a.redo();return {before,after:a.scene().walls,message:document.getElementById('message').textContent};}""")
 record('redo_retained_after_noop',True,'2,2' in no_op['after'],'ui-lifecycle',str(no_op))
 page.close();page=page_new(browser)
 ruler=page.evaluate("""() => {const a=window.__tabletopTEST;a.resize(20);a.mode('measure');a.cell(15,15);a.cell(19,19);let before=a.ruler();a.resize(7);return {before,after:a.ruler(),size:a.scene().n,valid:a.validateWorkspace(a.state())};}""")
 record('ruler_coordinates_inside_after_resize',True,all(point is None or (point['x']<ruler['size'] and point['y']<ruler['size']) for point in [ruler['after']['start'],ruler['after']['end']]),'ui-lifecycle',str(ruler))
 page.close();page=page_new(browser)
 topology=page.evaluate("""() => {const a=window.__tabletopTEST;a.mode('wall');a.cell(2,2);a.capture();let before=a.scene().frames.length;a.mode('erase');a.cell(2,2);return {before,after:a.scene().frames.length,valid:a.validateWorkspace(a.state()),walls:a.scene().walls};}""")
 record('topology_replay_invalidated',True,topology['before']>0 and topology['after']==0 and topology['valid'],'regression',str(topology))
 # Replay mixed IDs rejected, legacy valid.
 page.close();page=page_new(browser)
 replay=page.evaluate("""() => {let a=window.__tabletopTEST,r=a.makeReplay();let good=a.validateReplay(r);r.events.push(structuredClone(r.events[0]));r.events[0].id='frame-002';r.events[1].id='custom-x';let mixed=a.validateReplay(r);let strict=structuredClone(r);strict.events[1].id='frame-001';let regression=a.validateReplay(strict);return {good,mixed,regression};}""")
 record('replay_valid_fixture',True,replay['good'],'replay')
 record('replay_mixed_without_sequence',False,replay['mixed'],'replay')
 record('replay_regress_numeric',False,replay['regression'],'replay')
 # safe scene separation upon copy and switch: ruler cannot appear on duplicated scene.
 page.close();page=page_new(browser)
 scenes=page.evaluate("""() => {const a=window.__tabletopTEST;a.mode('measure');a.cell(2,2);a.cell(4,4);const origin=a.ruler();a.copyScene();return {origin,dest:a.ruler(),active:a.state().active,scene:a.scene().id,visible:!document.getElementById('rulerOverlay').hasAttribute('hidden')};}""")
 record('scene_copy_ruler_hidden',False,scenes['visible'],'scene-isolation')
 (OUT/'TEST26_AUDITORIA_GERATIVA_007.json').write_text(json.dumps({'baselineSHA256':sha256(js.encode()).hexdigest(),'chromium':browser.version,'seed':seed,'checks':checks,'negativeExamples':generated,'ui':{'import_alias':detail,'noop_redo':no_op,'ruler_resize':ruler,'topology':topology,'replay':replay,'copy_scene':scenes},'classification':'Observed product FAIL means PASS reproduction, not approval'},indent=2,ensure_ascii=False))
 print(json.dumps({'checks':len(checks),'passes':sum(x['pass_'] for x in checks),'fails':sum(not x['pass_'] for x in checks),'failNames':[x['name'] for x in checks if not x['pass_']],'generated':generated,'ui':{'alias':detail,'redo':no_op,'ruler':ruler}},indent=2,ensure_ascii=False))
 browser.close()
