/* PESQ-007, Mestre-side / TEST: non-invasive presentation overlay SPIKE.
   No RPG mechanics, no network, no persistence, no Party authorization.
   Prototype only: developer must review API and lifecycles before integration.
*/
(function(global){'use strict';
 const NS='http://www.w3.org/2000/svg';
 const ident=/^[a-z0-9_-]{1,32}$/;
 const coord=(x,y,n)=>Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<n&&y<n;
 function createExperimentalOverlay(api,board=document.getElementById('board')){
  if(!api||!board)throw Error('Test API + board required');
  const scenes=new Map();
  const svg=document.createElementNS(NS,'svg');
  svg.id='pesq007-overlay';svg.setAttribute('aria-hidden','true');svg.style.cssText='position:absolute;inset:0;pointer-events:none;overflow:visible;z-index:8';
  function add({sceneId,id,x,y,label}){
   if(!ident.test(sceneId)||!ident.test(id)||typeof label!=='string'||label.length>40||/[<>\u0000-\u001f]/.test(label))return false;
   const state=api.state(),scene=state.scenes.find(v=>v.id===sceneId);
   if(!scene||!coord(x,y,scene.n))return false;
   const items=scenes.get(sceneId)||new Map();
   if(items.size>=12&&!items.has(id))return false;
   items.set(id,{x,y,label});scenes.set(sceneId,items);return true;
  }
  function erase(sceneId,id){return scenes.get(sceneId)?.delete(id)??false;}
  function draw(){
   const scene=api.scene();
   // ensureBoard(n) discards former children. Attach to the NEW board only when asked to refresh.
   if(svg.parentNode!==board)board.append(svg);
   svg.replaceChildren();
   const rects=new Map([...board.querySelectorAll('button.tile[data-xy]')].map(v=>[v.dataset.xy,v]));
   let displayed=0;
   for(const [id,v] of scenes.get(scene.id)||[]){
    if(!coord(v.x,v.y,scene.n))continue;
    const t=rects.get(`${v.x},${v.y}`);if(!t)continue;
    const cx=t.offsetLeft+t.offsetWidth/2,cy=t.offsetTop+t.offsetHeight/2;
    const g=document.createElementNS(NS,'g');g.dataset.markerId=id;
    const circle=document.createElementNS(NS,'circle');
    circle.setAttribute('cx',cx);circle.setAttribute('cy',cy);circle.setAttribute('r',Math.min(t.offsetWidth/3,11));
    circle.setAttribute('fill','none');circle.setAttribute('stroke','#fff09a');circle.setAttribute('stroke-width','3');
    g.append(circle);
    const title=document.createElementNS(NS,'title');title.textContent=v.label;g.append(title);svg.append(g);displayed++;
   }
   const width=board.scrollWidth||board.getBoundingClientRect().width;
   const height=board.scrollHeight||board.getBoundingClientRect().height;
   svg.setAttribute('width',String(width));svg.setAttribute('height',String(height));
   return displayed;
  }
  return {add,erase,draw,svg,ids:sceneId=>[...(scenes.get(sceneId)||new Map()).keys()]};
 }
 global.createExperimentalOverlay007=createExperimentalOverlay;
})(window);
