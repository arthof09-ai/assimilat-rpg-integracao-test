"""Independent Chromium canary of small overlay mounted over unmodified TEST26."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,os
root=Path(os.environ.get('PESQ007_ROOT',str(Path(__file__).resolve().parents[1])))
S=Path(os.environ.get('TEST26_PUBLIC_DIR',str(root/'work/public')));R=Path(__file__).resolve().parent;out=R/'evidence'
html=(S/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','data-disabled="Content-Security-Policy"')
css=(S/'styles.css').read_text();app=(S/'app.js').read_text();overlay=(R/'overlay_adapter_007.js').read_text()
checks=[]
def ok(k,actual,expected=True):checks.append(dict(name=k,pass_=actual==expected,actual=actual,expected=expected))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 requests=[];page.on('request',lambda r:requests.append(r.url))
 page.set_content(html);page.add_style_tag(content=css)
 page.evaluate("window.st=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.st.get(k)||null,setItem:(k,v)=>window.st.set(k,String(v))}})")
 page.add_script_tag(content=app)
 page.add_script_tag(content=overlay)
 result=page.evaluate("""() => {const a=window.__tabletopTEST, o=window.ov=createExperimentalOverlay007(a);let test={};test.add=o.add({sceneId:'c1',id:'mark1',x:2,y:2,label:'Alerta sintético'});test.draw=o.draw();test.pointerEvents=getComputedStyle(o.svg).pointerEvents;test.centerAligned=()=>{let tile=document.querySelector('button.tile[data-xy="2,2"]'),circle=o.svg.querySelector('circle');return !!circle&&Math.abs(+circle.getAttribute('cx')-(tile.offsetLeft+tile.offsetWidth/2))<1;};test.beforeZoom=test.centerAligned();a.zoom(68);o.draw();test.afterZoom=test.centerAligned();test.badCoordinate=o.add({sceneId:'c1',id:'bad',x:99,y:0,label:'a'});test.badName=o.add({sceneId:'c1',id:'bad2',x:1,y:0,label:'<img src=x>'});test.badScene=o.add({sceneId:'unknown',id:'id3',x:1,y:0,label:'x'});a.mode('measure');a.cell(1,1);a.cell(3,3);o.draw();test.rulerUnaffected=a.ruler().text.includes('Manhattan 4');a.copyScene();test.copySceneId=a.scene().id;test.copySceneMarks=o.draw();a.switchScene('c1');test.returnMarks=o.draw();a.resize(20);o.add({sceneId:'c1',id:'mark2',x:19,y:19,label:'Test'});test.beforeDownsize=o.draw();a.resize(7);test.afterDownsize=o.draw();test.overlayAlive=o.svg.isConnected;test.stateUnaffected=!Object.hasOwn(a.scene(),'overlay')&&!Object.hasOwn(a.scene(),'markers');return {...test,beforeZoom:test.beforeZoom,afterZoom:test.afterZoom};}""")
 ok('marker_added',result['add']);ok('marker_drawn',result['draw']==1);ok('does_not_intercept_touch',result['pointerEvents']=='none');ok('alignment_before_zoom',result['beforeZoom']);ok('alignment_after_zoom',result['afterZoom']);ok('reject_invalid_coords',result['badCoordinate']==False);ok('reject_unsafe_label',result['badName']==False);ok('reject_unknown_scene',result['badScene']==False);ok('ruler_works_under_overlay',result['rulerUnaffected']);ok('copy_scene_isolation',result['copySceneMarks']==0);ok('scene_return_recovered',result['returnMarks']==1);ok('two_markers_before_resize',result['beforeDownsize']==2);ok('out_of_bounds_marker_hidden',result['afterDownsize']==1);ok('overlay_attached',result['overlayAlive']);ok('no_canonical_mutation',result['stateUnaffected']);ok('no_external_requests',len([x for x in requests if x.startswith('http')])==0)
 page.screenshot(path=str(R/'CANARIO_OVERLAY_TEST26_390x844.png'),full_page=True)
 (out/'OVERLAY_CANARIO_007.json').write_text(json.dumps({'engine':'Chromium '+b.version,'viewport':'390x844 emulated, Linux','checks':checks,'raw':{k:v for k,v in result.items() if not callable(v)},'notInProduct':True},ensure_ascii=False,indent=2))
 print('checks',len(checks),'PASS',sum(x['pass_'] for x in checks),'FAIL',[x for x in checks if not x['pass_']]);print('raw',result)
 page.close();b.close()
