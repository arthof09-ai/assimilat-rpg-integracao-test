import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST_SHA256.json').read_text())
for p,expected in m['files'].items():
 f=r/p
 assert f.is_file(),p
 assert hashlib.sha256(f.read_bytes()).hexdigest()==expected,p
print('PESQ020 manifest',len(m['files']),'/',len(m['files']),'PASS')
