# PESQ-INOV-20261024-020 · Independent scientific tests

**Existing Tabletop Inovador research / MESTRE-SIDE only.** Status: tested against original TEST39 + original Codex0.4. Code changes in memory ONLY. This archive does not distribute original sources and is not a server, a combat engine, or a playable multiplayer product.

## Why this is new
1. Original TEST39 displays a pending/rejected c1 receipt while the current Arena scene is c2, without a source-scene label. In-memory candidate adds explicit original/current scene and updates on scene switch.
2. Original Codex0.4 correctly supports the same ID in distinct rooms with different results. After the *fake laboratory port* changes room between submit and query, TEST39 original accepts the wrong room's ACK and misattributes status. In-memory candidate pins the source port (minimal experiment, not a full session/identity protocol).

**Reproduction:** supply immutable source ZIPs from the private Mestre Library, filenames and hashes below; run `python prepare_sources.py path/to/PACOTE_TECNICO_TABLETOP_TEST38_A_TEST39_20261024.zip path/to/ponte-vlab-tabletop-0.4.0-test38.zip`, then `bash run_all.sh`. It runs ten directed checks. Browser is a Chromium DOM test; server-side Codex is original Python+SQLite called in-process, not HTTP from browser.

- TEST39 SHA256 `73ef8107ff14348f700809727b1750377005a483fe7d52a7e7113b9790e7545b`
- Codex0.4 SHA256 `5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a`
- Prior PESQ019 SHA256 `a246148954712e71b7e908900135b0140d603d934c0f6726fd0ecf169a6d7366` (not rerun).

Handoff: `report/HANDOFF_PESQ020.md`. New JSON output and four screenshots: `evidence/`.

**Known HOLD:** browser-native HTTP on authorised origin, user auth & credential rotation, hot/cold reconnect provenance, VLAB ABI, mechanical effects, Android physical, Codex executor quota. No Party/O Primeiro writes or public GitHub.
