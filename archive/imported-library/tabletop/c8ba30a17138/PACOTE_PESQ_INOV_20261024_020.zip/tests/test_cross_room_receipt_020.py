"""PESQ020: cross-room same ID negative for the original TEST39 HUD. Test only.
Original Codex0.4 Authority remains untouched, and there is no browser-to-server HTTP.
"""
import json,sys,tempfile,hashlib,re
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__import__('os').environ.get('PESQ020_CODEX','/mnt/data/PESQ019/work/codex/experiments/tabletop_vlab_bridge'))
DEV=Path(__import__('os').environ.get('PESQ020_DEV','/mnt/data/PESQ019/work/dev/public'))
OUT=Path(__import__('os').environ.get('PESQ020_EVIDENCE',str(Path(__file__).resolve().parents[1]/'evidence')));OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT));from authority import Authority
APP=(DEV/'app.js').read_text()
OLD="const a={id,status:'PENDING',code:null,querying:false};authorityAttempt=a;"
REPL="const a={id,port,sceneId:t.sceneId,actorId:u.id,targetId:target.id,status:'PENDING',code:null,querying:false};authorityAttempt=a;"
OLD2="const port=window.TabletopTestAuthorityPort,a=authorityAttempt;"
REPL2="const a=authorityAttempt,port=a?.port??window.TabletopTestAuthorityPort;"
assert APP.count(OLD)==1 and APP.count(OLD2)==1
PATCHED=APP.replace(OLD,REPL).replace(OLD2,REPL2)
def mount(page,js):
 h=(DEV/'index.html').read_text();h=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',h).replace('<link rel="stylesheet" href="styles.css">','')
 for f in ('app.js','room-v2-adapter.js','room-client.js'):h=h.replace(f'<script src="{f}" defer></script>','')
 page.set_content(h);page.evaluate('''() => {const s={};for(const k of ['localStorage','sessionStorage'])Object.defineProperty(window,k,{configurable:true,value:{getItem:n=>s[n]??null,setItem:(n,v)=>s[n]=String(v),removeItem:n=>delete s[n]}});}''')
 page.add_style_tag(content=(DEV/'styles.css').read_text());page.add_script_tag(content=js)
 for f in ('room-v2-adapter.js','room-client.js'):page.add_script_tag(content=(DEV/f).read_text())

def sess(a,role,msg):
 s,raw=a.handle(json.dumps(msg).encode(),{'master':'FAKE_TEST_MASTER','p1':'FAKE_TEST_PLAYER1'}[role]);assert s==200,(s,raw);return json.loads(raw)

with tempfile.TemporaryDirectory() as t:
 a=Authority(Path(t)/'original_codex.sqlite')
 for room in ('rooma','roomb'):
  sess(a,'master',{'schema_version':1,'op':'create','room_id':room,'client_action_id':'create-'+room,'expected_revision':0})
 rejected=sess(a,'p1',{'schema_version':2,'op':'submit','room_id':'rooma','client_action_id':'test020mix','expected_revision':0,'actor_id':'actor-1','action':{'kind':'ATTACK_REQUEST','target':{'kind':'UNIT','actor_id':'actor-2'},'turn_id':'turn-test-1','context':{'scene_id':'scene-test-1','ability_id':'basic-attack'}}})['receipt']
 accepted=sess(a,'p1',{'schema_version':2,'op':'submit','room_id':'roomb','client_action_id':'test020mix','expected_revision':0,'actor_id':'actor-1','effect':{'kind':'FAKE_SET_LABEL','label':'SYNTHETIC_OTHER_ROOM'}})['receipt']
 assert rejected['status']=='REJECTED' and rejected['code']=='MECHANICS_UNAVAILABLE' and accepted['status']=='ACCEPTED'
 rA=sess(a,'p1',{'schema_version':2,'op':'receipt_query','room_id':'rooma','client_action_id':'test020mix'})['receipt']
 rB=sess(a,'p1',{'schema_version':2,'op':'receipt_query','room_id':'roomb','client_action_id':'test020mix'})['receipt']
 assert rA['receipt_id']!=rB['receipt_id'] and rA['client_action_id']==rB['client_action_id']
 def run(b,app,tag):
  p=b.new_page(viewport={'width':390,'height':844});mount(p,app)
  payloadA={'commandId':'test020mix','status':rA['status'],'code':rA['code']}
  payloadB={'commandId':'test020mix','status':rB['status'],'code':rB['code']}
  p.evaluate('''({receiptA,receiptB}) => {
    window.__P020={queries:[],sent:[],room:'rooma'};
    const portA={newId:()=>"test020mix",send:x=>{window.__P020.sent.push(x);return Promise.reject(new Error('ACK_LOST_AFTER_COMMIT_ROOM_A'))},query:id=>{window.__P020.queries.push('A:'+id);return Promise.resolve(receiptA)}};
    const portB={newId:()=>"test020mix",send:x=>{window.__P020.sent.push(x);return Promise.resolve(receiptB)},query:id=>{window.__P020.queries.push('B:'+id);return Promise.resolve(receiptB)}};
    window.__P020.a=portA;window.__P020.b=portB;window.TabletopTestAuthorityPort=portA;
  }''',{'receiptA':payloadA,'receiptB':payloadB})
  p.locator('#tacticToggle').click();p.locator('#tacticAction').select_option('attack');p.locator('.tile[data-xy="5,2"]').click(force=True);p.locator('#tacticConfirm').click()
  p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
  p.evaluate('window.TabletopTestAuthorityPort=window.__P020.b;window.__P020.room="roomb"')
  p.locator('#tacticAuthorityQuery').click();p.wait_for_function('window.__tabletopTEST.authority()?.status!=="UNKNOWN"')
  r={'tag':tag,'display':p.locator('#tacticAuthorityState').inner_text(),'status':p.evaluate('window.__tabletopTEST.authority().status'),'queries':p.evaluate('window.__P020.queries'),'sends':p.evaluate('window.__P020.sent'),'same_id_across_rooms':rA['client_action_id']==rB['client_action_id']}
  p.screenshot(path=str(OUT/f'{tag}.png'));p.close();return r
 with sync_playwright() as pw:
  b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  red=run(b,APP,'baseline_room_mix_RED');green=run(b,PATCHED,'candidate_pinned_port_GREEN');b.close()
 assert red['queries']==['B:test020mix'] and red['status']=='ACCEPTED',red
 assert green['queries']==['A:test020mix'] and green['status']=='REJECTED',green
 assert len(red['sends'])==len(green['sends'])==1
 out={'classification':'SCIENTIFIC TEST/PROPOSED PORT PIN, NOT IMPLEMENTED','backend':'original Codex0.4 Authority.handle with ephemeral SQLite; no browser HTTP or real auth','frontend':'original TEST39 app.js Chromium DOM, with in-memory candidate','server_receipts':{'rooma':rA,'roomb':rB},'baseline':red,'candidate':green,'checks':{'separate_backend_room_receipts':True,'same_id_different_outcome_valid':True,'original_global_port_swap_misattributes':True,'pinned_port_preserves_receipt_owner':True,'no_reexecution_during_query':True},'test_status':'5/5 PASS directed; baseline RED, candidate GREEN', 'sha_app':hashlib.sha256(APP.encode()).hexdigest()}
 (OUT/'cross_room_020.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 print('PESQ020 Codex real DB rooma rejected / roomb accepted same ID; TEST39 original RED via swapped port, isolated pin port GREEN; 5/5 checks PASS')
