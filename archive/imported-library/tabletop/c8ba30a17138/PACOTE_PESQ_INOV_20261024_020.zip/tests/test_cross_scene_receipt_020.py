import json,re,sys,os,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
DEV=Path(os.environ.get('PESQ020_DEV','/mnt/data/PESQ019/work/dev/public'))
OUT=Path(__import__('os').environ.get('PESQ020_EVIDENCE',str(Path(__file__).resolve().parents[1]/'evidence')))
OUT.mkdir(parents=True,exist_ok=True)
APP=(DEV/'app.js').read_text()
PATCH="""const a={id,sceneId:t.sceneId,actorId:u.id,targetId:target.id,status:'PENDING',code:null,querying:false};authorityAttempt=a;"""
OLD="""const a={id,status:'PENDING',code:null,querying:false};authorityAttempt=a;"""
PREFIX="""const a=authorityAttempt,available=Boolean(window.TabletopTestAuthorityPort?.send);
 if(!a){"""
NEWPREFIX="""const a=authorityAttempt,available=Boolean(window.TabletopTestAuthorityPort?.send);
 if(a&&a.sceneId&&a.sceneId!==workspace.active){
  out.textContent='Recibo TEST da cena '+a.sceneId+' (cena atual '+workspace.active+') — ID '+a.id+' — '+a.status+'. Não atribuir este resultado à cena atual.';
  query.disabled=!available||!['UNKNOWN','NOT_FOUND'].includes(a.status);
  return;
 }
 if(!a){"""
assert APP.count(OLD)==1 and APP.count(PREFIX)==1
PATCH_APP=APP.replace(OLD,PATCH).replace(PREFIX,NEWPREFIX).replace("renderBoard(s);renderMarkerOverlay(s);renderMarkerList(s);renderUnits(s);renderLog(s);renderTactical();", "renderBoard(s);renderMarkerOverlay(s);renderMarkerList(s);renderUnits(s);renderLog(s);renderTactical();paintAuthority();")
assert PATCH_APP!=APP and PATCH_APP.count('paintAuthority();')>APP.count('paintAuthority();')

def mount(p,code):
 h=(DEV/'index.html').read_text();h=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',h).replace('<link rel="stylesheet" href="styles.css">','')
 for f in ['app.js','room-v2-adapter.js','room-client.js']:h=h.replace(f'<script src="{f}" defer></script>','')
 p.set_content(h)
 p.evaluate('''() => {const s={};for(const k of ['localStorage','sessionStorage'])Object.defineProperty(window,k,{configurable:true,value:{getItem:n=>s[n]??null,setItem:(n,v)=>s[n]=String(v),removeItem:n=>delete s[n]}});}''')
 p.add_style_tag(content=(DEV/'styles.css').read_text());p.add_script_tag(content=code)
 for f in ['room-v2-adapter.js','room-client.js']:p.add_script_tag(content=(DEV/f).read_text())

def scenario(b,app,tag):
 p=b.new_page(viewport={'width':390,'height':844});mount(p,app)
 p.evaluate('''() => {window.__P020={resolve:null,queries:[],sent:[]};window.TabletopTestAuthorityPort={newId:()=>"test020scene",send:x=>{window.__P020.sent.push(x);return new Promise(r=>window.__P020.resolve=r)},query:id=>{window.__P020.queries.push(id);return Promise.resolve({commandId:id,status:'REJECTED',code:'MECHANICS_UNAVAILABLE'});}};}''')
 p.locator('#tacticToggle').click();p.locator('#tacticAction').select_option('attack');p.locator('.tile[data-xy="5,2"]').click(force=True);p.locator('#tacticConfirm').click()
 p.wait_for_function('window.__P020.sent.length===1')
 before=p.locator('#tacticAuthorityState').inner_text();src=p.evaluate('window.__P020.sent[0]')
 p.locator('#newScene').click();p.wait_for_function('window.__tabletopTEST.state().active!=="c1"');newscene=p.evaluate('window.__tabletopTEST.state().active')
 afterswitch=p.locator('#tacticAuthorityState').inner_text()
 p.evaluate('''() => window.__P020.resolve({commandId:'test020scene',status:'REJECTED',code:'MECHANICS_UNAVAILABLE'})''')
 p.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
 afterreceipt=p.locator('#tacticAuthorityState').inner_text();tactical=p.locator('#tacticReadout').inner_text()
 snap={'tag':tag,'source_scene':src['sceneId'],'current_scene':newscene,'request':src,'before':before,'after_switch':afterswitch,'after_receipt':afterreceipt,'tactic_readout':tactical,'receipt_result':p.evaluate('window.__tabletopTEST.authority()'),'original_js_sha256':hashlib.sha256(APP.encode()).hexdigest()}
 p.screenshot(path=str(OUT/f'{tag}.png'))
 p.close();return snap

with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 red=scenario(b,APP,'baseline_original_RED');green=scenario(b,PATCH_APP,'candidate_memory_GREEN');b.close()
assert red['source_scene']=='c1' and red['current_scene']!='c1'
assert 'test020scene' in red['after_receipt'] and 'REJECTED' in red['after_receipt']
assert 'c1' not in red['after_receipt'] and red['current_scene'] not in red['after_receipt']
assert 'c1' in green['after_receipt'] and green['current_scene'] in green['after_receipt']
assert green['source_scene']==red['source_scene'] and green['request']==red['request']
assert 'Não atribuir' in green['after_receipt']
result={'status':'SCIENTIFIC_TEST/RESEARCH_ONLY','executed':True,'source':'TEST39 original JS from physically verified ZIP, DOM mount via Chromium, no backend/network','checks':[{'case':'original shows receipt after different scene (RED)', 'pass':True},{'case':'baseline fails to display origin/current scene on receipt', 'pass':True},{'case':'candidate in-memory explicitly identifies origin scene/current scene (GREEN)', 'pass':True},{'case':'command id, actor, target unchanged', 'pass':True},{'case':'original dev source unmodified', 'pass':True}], 'baseline':red,'candidate':green,'native_http':False,'vlab':False}
(OUT/'cross_scene_020.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('PESQ020 cross-scene baseline RED and candidate GREEN; 5/5 checks PASS (scientific; candidate NOT applied to Developer source)')
