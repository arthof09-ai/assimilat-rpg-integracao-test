#!/usr/bin/env python3
"""Recover two already-existing MASTER-SIDE ZIPs for independent tests, read-only."""
import os,sys,zipfile,hashlib,json
from pathlib import Path
if len(sys.argv)!=3:
 raise SystemExit('usage: python prepare_sources.py TEST39-original.zip CODEX040-original.zip')
EXPECTED=(('TEST39','73ef8107ff14348f700809727b1750377005a483fe7d52a7e7113b9790e7545b'),('Codex040','5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a'))
root=Path(__file__).resolve().parent/'sources';root.mkdir(exist_ok=True)
proof=[]
for (name,sha),arg,outname in zip(EXPECTED,sys.argv[1:],('dev','codex')):
 p=Path(arg);got=hashlib.sha256(p.read_bytes()).hexdigest()
 assert got==sha,(name,'HASH_MISMATCH',got)
 with zipfile.ZipFile(p) as z:
  names=z.namelist()
  assert z.testzip() is None
  for n in names:
   parts=Path(n).parts
   assert not n.startswith('/') and '..' not in parts and '\\' not in n, ('UNSAFE_ZIP_PATH',n)
  z.extractall(root/outname)
 proof.append({'name':name,'size':p.stat().st_size,'sha256':got,'zip_entries':len(names),'crc':'PASS'})
assert (root/'dev/public/app.js').exists()
assert (root/'codex/experiments/tabletop_vlab_bridge/authority.py').exists()
print(json.dumps({'result':'SOURCE_PREP_PASS','originals_untouched':True,'sources':proof},indent=2))
