#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PESQ020_DEV="$ROOT/sources/dev/public"
export PESQ020_CODEX="$ROOT/sources/codex/experiments/tabletop_vlab_bridge"
export PESQ020_EVIDENCE="${PESQ020_EVIDENCE:-$ROOT/run_outputs}"
mkdir -p "$PESQ020_EVIDENCE"
python "$ROOT/tests/test_cross_scene_receipt_020.py"
python "$ROOT/tests/test_cross_room_receipt_020.py"
python "$ROOT/verify_manifest.py"
