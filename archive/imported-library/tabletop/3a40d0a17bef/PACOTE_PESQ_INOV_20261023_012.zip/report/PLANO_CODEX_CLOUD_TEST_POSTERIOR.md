# Proposta futura Codex Cloud — ramo TEST mínimo, não executar nesta pesquisa

**Decisor:** Mestre/Coordenação. **Executor autoritativo de integração:** Desenvolvedor. **Pesquisador:** apenas prova, parâmetros e revisão independente. **Custo adicional:** R$0; só usar franquia já disponível, verificar `Configurações → Uso`, elegibilidade do Codex Cloud na própria conta e permissões GitHub antes de iniciar. Nenhum ambiente/conta foi criado nesta PESQ.

## Escopo sugerido (após mais recente RUN e autorização expressa)

1. Recuperar o SHA real de `gh-pages` e do pacote TEST mais recente; consultar `AGENTS.md` já existente na `main` e as normas do Notion, sem substituir as fontes. **Não usar main nem gh-pages como superfície de escrita.**
2. Criar por responsável autorizado um ramo TEST isolado, ou disponibilizar ao Codex uma cópia descartável dos arquivos públicos `index.html/styles.css/app.js`, com path allowlist; nenhum dado real de Party, VLAB, fichas ou chaves privadas.
3. Primeira tarefa minúscula: implementar SOMENTE contrato `roomTransport` com `connect()`, `sendIntent()`, `onAuthorizedSnapshot()`, `disconnect()` em módulo TEST, preservando `renderBoard()` e as estruturas TEST33. Fornecedor mock injetável; nenhum websocket externo obrigatório; nenhuma regra de combate.
4. Testes: payload sem dados admin, comando com `commandId/baseRevision`, rejeição de staleness, reconexão snapshot, 3 clientes fake. Ativar integração real SOMENTE em próximo gate de cloud segura, com tokens não versionados no código.
5. Revisão humana do diff, testes, manifesto, SHA e readback antes de qualquer PR/merge. Se uso da conta insuficiente ou setup bloquear, STATUS `HOLD` e continuar pelo Desenvolvedor nativo, sem comprar créditos.

## Prompt de referência (não enviado ao Codex, não é ordem de escrita)

> Você atua estritamente como implementador TEST no repositório fornecido em ambiente restrito. Primeira etapa somente leitura: confirme o commit de base, `AGENTS.md` da branch indicada, convenções dos arquivos existentes e disponibilidade dos testes. **Não toque main, gh-pages, Party, O Primeiro, VLAB, fichas ou código de outros laboratórios.** Objetivo limitado: preparar um adaptador de transporte injetável para um servidor autoritativo externo; preservar a engine e as ações do Tabletop atuais. NÃO crie motor de regras nem faça deploy. Mensagens usam `commandId`, `baseRevision` e snapshot autorizado. Nenhuma nota administrativa pode ser enviada a cliente Player; o servidor é responsável por filtrar antes do envio. Implemente ou, se não autorizado a escrever, proponha um patch isolado; forneça testes RED→GREEN, adversariais e prova de reconexão. Reporte arquivos alterados, SHA anterior/posterior, testes realizados e não realizados, licenças, riscos e FIRST-PENDING. Não instale serviços pagos nem grave chaves em arquivos. Aguarde aprovação do responsável para qualquer commit/PR.

**Nota:** Codex Cloud executa tarefas em computadores gerenciados pela OpenAI, pode ser orientado/revisado pelo celular, conforme documentação oficial; não é sinônimo de Codex local nem acesso irrestrito ao notebook. Disponibilidade e quotas variam; verifique antes. Fontes: https://learn.chatgpt.com/docs/cloud ; https://learn.chatgpt.com/docs/mobile ; https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan .
