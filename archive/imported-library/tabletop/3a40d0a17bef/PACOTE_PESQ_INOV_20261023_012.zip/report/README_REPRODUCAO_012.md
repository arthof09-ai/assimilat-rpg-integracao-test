# PESQ-012 — Reproduzir exclusivamente a bancada sintética

**Conteúdo:** 1 servidor `aiohttp` WebSocket/SQLite, UI HTML estilizada de TEST 7×7 (não o Tabletop do Desenvolvedor), suíte de transporte com três clientes aiohttp independentes, suíte de apresentação Chromium com snapshots **injetados estaticamente**, teste de corrida concorrente/fan-out em loopback e prova de priorização tática apenas a partir de ações sintéticas pré-validadas.

**Sem conta, GitHub API, Cloudflare, Supabase, VLAB, Party ou PixelLab.** Python `>=3.11`, `aiohttp==3.13.3` para a rede; `playwright==1.57.0` e executável Chromium para as capturas de DOM. São dependências de pesquisa, não novas assinaturas ou requisitos de produto. aiohttp (Apache-2.0 AND MIT), Playwright (Apache-2.0); verifique licenças das distribuições ao instalar.

No ambiente que já disponibilize as dependências:

```bash
cd prototype
python test_room_network.py
python test_race_and_latency.py
python decision_ranking_test.py
```

Resultados esperados no ambiente verificado: **51/51 PASS**, onde 1–43 são clientes WebSocket reais de **teste no mesmo processo/host**, 44–51 são apresentação DOM sem rede Chromium (a navegação de loopback foi bloqueada administrativamente, `ERR_BLOCKED_BY_ADMINISTRATOR`). Corrida separada **1 aceito/1 stale**, 80 atualizações broadcast em loopback, 4 conexões, e ranking sintético **10/10**. No hardware do usuário resultados podem variar, inclusive o navegador/navegação; nenhum desses resultados equivale a Android físico.

Para explorar localmente no host que execute Python e onde a rede local seja autorizada:

```bash
cd prototype
python room_server.py --db room_test.sqlite
# Usar os convites aleatórios mostrados no terminal ao abrir http://127.0.0.1:8765/
```

**SECURITY HOLD:** servidor vinculado a 127.0.0.1 por padrão; não abra publicamente a porta, não copie tokens para prints públicos, não use para dados reais. Em Android/outra máquina, `localhost` aponta para o próprio aparelho; LAN exige configurar host/IP, firewall, conexão segura e aprovação competente. Este laboratório não é servidor Android nem WSS. Não envie uma página GitHub Pages HTTPS para `ws://IP_LAN` e suponha funcionamento: mixed content e contexto seguro precisam de arquitetura adequada. Nem CLI nem o cliente providenciam TLS, login real, revogação, proteção DDoS ou quotas.

Os tokens fixos definidos em `test_room_network.py` são **fixtures públicas de TEST**; produção nunca deve reutilizá-los. A persistência cold executa a mesma fixture nos dois processos; o uso real deve definir credenciais seguras de longa duração/expiradas e identidade verificável.

Ações no protótipo `MOVE`, `END_TURN` e `MOCK_ACTION` são demonstrações de **transporte**. A regra de um passo serve apenas para diferenciar comando aceito/rejeitado, **não é regra mecânica do Assimilação**. `MOCK_ACTION` não tira Vida/PA/Alma, não rola dado, não altera recursos e não representa execução VLAB.

## Artefatos

- `results/NETWORK_TEST_RESULTS.json`: contratos individualizados e denominadores.
- `results/RACE_FANOUT_LOCAL.json`: prova corrida + benchmark loopback, sem latência Android/cloud.
- `results/TACTICAL_RANKING_SYNTHETIC.json`: priorização sugestiva, não combat engine.
- `results/SCREEN_STATIC_MASTER.png`, `SCREEN_STATIC_PLAYER.png`: DOM renderizado de cópias role-specific injetadas, não screenshot de uma conexão navegador-WebSocket.
- `report/`: comparação Free, contrato, integração, Codex, áudio/visuais, checkpoints e referências externas.

**Nunca executar estas fixtures com credenciais, fichas ou eventos reais Mestre/Party.**
