# Contrato de sala v1 — pesquisa sintética PESQ-012

**Classificação:** PROPOSTO / MESTRE-SIDE / TEST. O protocolo abaixo foi validado no banco de pesquisa `room_server.py`, NÃO no Tabletop oficial, no VLAB ou em Cloudflare. Seu foco é transporte e sincronização, não a mecânica de combate.

## Fluxo

```text
Mestre/Player Android ou notebook (UI web existente)
    |  JOIN + credencial; depois COMMAND(id, baseRevision, intenção)
    v
Fronteira HTTPS/WSS confiável  [FUTURO: Worker / servidor local autenticado]
    |  verifica autenticação, identidade, participação na sala, quotas
    v
Objeto autoritativo único da sala  [FUTURO: Durable Object SQLite]
    |  valida role, owner, ordem, versão, idempotência, input
    |  FUTURO: solicita/recebe decisão mecânica do VLAB homologado
    |  commita estado e evento uma vez, sob fence transacional
    +----> projeta snapshot por participante, ANTES de transmissão
                  |      \-- MASTER: campos administrativos autorizados
                  \--------- PLAYER: SOMENTE whitelist permitida
```

## Mensagens de pesquisa verificadas

**JOIN** (`client -> server`): `{"type":"JOIN","token":"<convite sintético>"}`. A função `identity()` consulta a credencial no servidor e **não aceita o papel alegado pelo cliente**. A implementação TEST armazena hashes SHA-256 em memória e NÃO substitui login/identidade de produção, revogação ou TLS.

**COMMAND** (`client -> server`):

```json
{"type":"COMMAND","command":{"type":"MOVE","commandId":"unique_actor_request_001","baseRevision":2,"unitId":"unit-p1","x":4,"y":2}}
```

Campos: `type` definido por allowlist; `commandId` exclusivo por ator, persistido com fingerprint; `baseRevision` da **revisão pública compartilhada**; proprietário da unidade validado exclusivamente no servidor; `x,y` números inteiros estritos e dentro da grade; verificação de turno pelo estado do servidor. No protótipo, MOVE usa uma regra **fictícia de adjacência para demonstrar rejeição**, nunca distância mecânica canônica. No produto real, a decisão de legalidade de movimento/PA virá do VLAB competente, sem duplicar suas regras.

**SNAPSHOT** (`server -> client`):

```json
{"type":"SNAPSHOT","data":{"schema":"assim.multiplayer.synthetic.v1","room":"SYNTH-ROOM","revision":3,"turn":"p1","turnNumber":1,"grid":{"width":7,"height":7},"units":[],"markers":[],"lastEvent":{"kind":"MOCK_VISUAL_ACTION_ONLY","mechanics":"NOT_EXECUTED"},"you":"p1"}}
```

Amostra resumida: dados de unidades e marcadores públicos vazios só aqui para clareza. Para MASTER, campos extras `adminMarkers` e `adminRevision` são serializados separadamente; para players, **esses campos não existem nem trafegam**. Eventos administrativos não alteram a revisão pública, evitando vazamento trivial de atividade via contadores. O produto real ainda precisará examinar outros canais laterais (timing, tamanho de mensagens, logs, mensagens de erro, cache e histórico).

**ACK** (`server -> cliente executor`): `{"type":"ACK","commandId":"...","ok":true,"revision":3}`. Tipos de erro testados: `UNAUTHORIZED`, `AUTH_REQUIRED`, `FORBIDDEN`, `NOT_YOUR_TURN`, `STALE_REVISION`, `INVALID_ID`, `INVALID_COORD`, `UNIT_NOT_OWNED`, `OCCUPIED`, `ID_REUSE_CONFLICT`, `SYNTHETIC_ADJACENCY_ONLY`.

**PRIVATE_MARK** (`master -> server`): usa **`baseRevision = adminRevision`**, não a revisão pública; gera broadcast apenas para conexões do Mestre. **PUBLIC_MARK** altera revisão pública e é distribuído às players depois de autorização explícita do Mestre. O campo `scope` enviado por jogador NUNCA concede autoridade.

## Ordem, concorrência, falha e retomada

1. Sequência única de comandos de uma sala, serializada no servidor. No experimento, `asyncio.Lock` e transação SQLite; em Cloudflare, aproveitar serialização/armazenamento transacional dos Durable Objects.
2. `baseRevision` desatualizado deve receber `STALE_REVISION`, seguido de recuperação do snapshot autorizado e nova intenção humana; **não resolver divergência substituindo silenciosamente o estado Mestre**.
3. Mesmo `(actor,commandId)` + mesmo payload = ACK idempotente sem aplicar de novo, inclusive após reinício. Mesmo ID com payload diferente = `ID_REUSE_CONFLICT`.
4. Credenciais revogadas, expiradas ou de sala errada devem ser negadas. **NÃO implementado** no experimento: revogação em tempo real, expiração, login de player, contas e múltiplas salas.
5. Persistência: commit atômico de mudança e recibo; snapshot em SQLite. Recuperação testa reiniciar o servidor local sobre o mesmo arquivo com as mesmas credenciais de fixture. Em nuvem, preservar recibos/versionamento sob hibernação ou reinício.
6. Queda da conexão: reconectar, autenticar novamente, buscar snapshot filtrado e revisar comandos pendentes. **Nunca aplicar fila offline automaticamente**: verificar versão, revogação e autoridade antes do envio.
7. Uso sem internet: cliente web pode mostrar a cena já conhecida em somente leitura; **não oferecer batalha divergente em cada celular**. Host LAN dedicado requer infra operacional e segurança próprias.

## Fronteira com VLAB, IA e apresentação

- **VLAB** fornece ações legais, economia de ações/PA, CDs, acerto/defesa/dano, efeitos e recursos por meio de contratos HOMOLOGADOS, ainda não conectados. O servidor de sala é coordenador de comandos, NÃO outro simulador.
- **IA tática**: somente escolhe dentre ações já validadas pelo motor competente. Sua recomendação não escreve Vida, PA, dano nem resultado. O experimento `decision_ranking_test.py` demonstra só ordenação de ações pré-validada com pesos inteiramente sintéticos.
- **Modos CINEMÁTICA / EQUILIBRADA / OBJETIVA** consomem o mesmo evento verificado; não alteram RNG, dano ou turnos, e não podem publicar segredos administrativos.
- **D-INOV-032 A+C**: A = marcador administrativo sempre visível ao Mestre; C = futura Party só recebe dados autorizados antes do transporte. FOV CSS jamais é autorização.

## Aceite antes de uma cloud REAL ou integração canônica

1. Cloudflare Workers Free + SQLite Durable Object configurados **sem cartão/cobrança**, quotas atuais e falha controlada confirmadas na conta; Worker público em HTTPS/WSS; credenciais fortes/expiráveis para Mestre e players.
2. Duas sessões Chrome Android físico + Mestre em Android/notebook: três conexões WSS para a mesma sala; toque real; desconexão de Wi-Fi e reconexão; atualização de todos os aparelhos.
3. Verificação de payloads **brutos** de player: 0 campos `admin`, notas, nomes secretos, logs privados, coordenadas não autorizadas, replay privado, identificadores administrativos; teste negativo com cliente malicioso.
4. Disputa simultânea: exatamente um commit, outro STALE; idempotência e recibos permanecem após hibernação/reinício.
5. Backup sob responsabilidade do Mestre, migração reversível, resto de UI TEST33 preservado, sem perda de dados locais.
6. Motor VLAB invocado somente após aprovação de interface/versão/hashes e fences; se indisponível, `MECHANICS_HOLD`, nunca calcular por heurística.

**NÃO ALEGAR:** este protótipo fornece segurança de produção, salas Cloudflare existentes, Android real, projeto de combate, integração Party/VLAB, ou serviço livre de limites.
