# Mapa de integração incremental TEST33 (leitura estática)

**Origem física:** `TABLETOP_SITE_SINTETICO_TEST33_CANDIDATE.zip` na Biblioteca (não incluído no pacote PESQ012); `app.js` SHA256 `7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4`. Última publicação confirmada TEST32; TEST33 permanece candidato enquanto não surgir nova evidência.

## O que já existe

- `WORKSCHEMA = 'assim.tabletop.synthetic.workspace.v1'`, `workspace`, `scenes`, validações `validateWorkspace/validateScene`, migração `migrateWorkspace`, persistência `persistChecked/saveLocal` e ferramentas de edição.
- `history/future`, `snap()`, `undo()`, `redo()` com revisão/cheque de armazenamento TEST33.
- `renderBoard(s)` compõe unidades, paredes, perigos, terreno, FOV visual, SVG de marcações, zoom e régua. `markerCommand()` cria/edita/remove marcadores por cena.
- `clickCell()` usa modos de ferramenta, seleção de unidade e movimentos TEST locais; controle local de alcance/steps é **sintético**, NÃO VLAB canônico.
- `REPLAYSCHEMA` para histórico read-only experimental; não transformar timeline privada em protocolo de batalha multiplayer sem competência e autorização.

## Pontos mínimos de adaptação PROPOSTOS

1. **Não** fazer broadcast de `workspace` ou de `scene()` inteiro: podem conter logs, notas, dados Mestre ou atributos futuros. Nem uma exclusão CSS evita vazamento.
2. Extrair APENAS entrada de intenção da UI, via `roomTransport.sendIntent({commandId, baseRevision, ...})`; se OFFLINE ou sala não autorizada, desativar edição remota e conservar edição local TEST em workspace separado/rotulado.
3. Quando chegar `SNAPSHOT` assinado e autorizado pelo servidor, converter para uma **projeção de apresentação**, preservando o `renderBoard`/camera existentes. Evitar `workspace = snapshot` cego: schema do Tabletop atual e de rede são diferentes, há flags de edição/privacidade e a origem não é a mesma.
4. **Mestre** recebe campos administrativos apenas quando autenticado; players recebem projeção *server-side* explícita e `id` de unidade própria, sem logs nem notas de outras cenas, seguindo a decisão A+C.
5. `saveLocal()` continua como rascunho/backup do editor quando adequado, não como fonte autoritativa da batalha sincronizada. Autoridade pública deve usar revision e eventos do servidor; concorrência de abas existentes não substitui arbitragem da sala.
6. Motor mecânico futuro: adaptador de evento VLAB versionado, read-only para a Party, **NENHUM resultado mecânico no protótipo**. Render mode não altera resultado.

**Teste de aceite:** 1 Mestre + 2 players reais conectados ao backend autorizado, snapshots só permitidos, ordenação, reconexão, nenhum dado admin em captura bruta das players, regression TEST33, Chrome Android real e alocação Cloudflare Free sob limite. Nenhuma edição ou publicação foi realizada neste estudo.
