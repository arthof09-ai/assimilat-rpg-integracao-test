# D-INOV-033 (PROPOSTO — CONFERIR NÃO DUPLICIDADE NO NOTION ANTES DE RESERVAR)

**Título:** Primeira sala multiplayer TEST R$0 / D-INOV-032 A+C / transporte autoritativo antes do VLAB.

**Problema real:** o TEST32 publicado e TEST33 candidato são editores/ensaios locais, sem servidor confiável de batalha ou prova entre aparelhos. O Mestre exige 1 Mestre + 2 players sincronizados sem custo adicional e com dados Mestre-only isolados.

**Baselines comprovadas:** TEST32 gh-pages commit `0aa9bc817844fa4ce0e16a2103a3a89988df577c` (última documentação canônica); TEST33 candidato fonte `app.js` SHA `7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4`, sem nova publicação confirmada. Desenvolvimento próprio do PESQUISADOR apenas transporte POC sintético, NÃO aplicação oficial.

**Evidência empírica:** 43/43 contratos de três clientes aiohttp sobre TCP/WebSocket local PASS, 8/8 de apresentação DOM por snapshots injetados PASS (não browser WebSocket direto), corrida simultânea 1 aceito/1 stale, restart SQLite, marker admin não enviado, idempotência, reconexão e 80 fan-outs sintéticos. Sem Android físico, autenticação real, WSS Cloudflare e mecânicas VLAB.

**Referências externas:** Cloudflare Durable Objects Free SQLite + Hibernation API (preços/quotas oficiais); Workers Chat Demo BSD-3-Clause; Supabase Realtime RLS e limites; exemplos Colyseus MIT. Não instalar Colyseus nem engine nova para o MVP. Fontes no Relatório PESQ012.

**Recomendação P0:** Desenvolvedor com autorização competente implementar em TEST e sem mexer em main/gh-pages: (1) `roomTransport` injetável sobre UI web existente; (2) backend Cloudflare DO Free SQLite em ambiente de TEST só se conta Free/card/quotas avaliadas e autorização do Mestre; (3) JOIN autenticado e mapeamento seguro role/room; (4) comandos `id,baseRev` arbitrados; (5) projeção allowlist no servidor antes do envio, A+C; (6) SQLite persist + reconexão; (7) uma ação claramente rotulada VISUAL FICTÍCIA, sem engine combate paralelo.

**Contrato mínimo:** `JOIN` → snapshot por role → `COMMAND(commandId,baseRevision,intent)` → `ACK` → `SNAPSHOT(revision,event,authorizedFields)`; rejeições `FORBIDDEN`, `NOT_YOUR_TURN`, `STALE`, `ID_REUSE_CONFLICT`; replay cold, reversão dos dados de TEST; WSS seguro; cliente Android e notebook.

**Aceite obrigatório:** três APARELHOS/NAVEGADORES conectados ao mesmo backend quando implantado; player A move unidade autorizada e Mestre/B veem; player B tenta agir fora de turno, negado; duas ações concorrentes têm um único commit; reconexão não perde estado; nenhuma nota/marker admin no payload bruto de players; célula/câmera/gestos mantêm TEST33; quota Free satisfaz sessão real; nenhuma despesa/cartão se isso exigir cobrança; SSL/TLS; GitHub Pages só pelo Desenvolvedor autorizado. Android físico e integração VLAB ficam HOLD até prova/contrato competente.

**Riscos:** credenciais roubadas, persistência incorreta, quota Free esgotada, Cloudflare/Internet indisponíveis, colapso de cliente Android, mensagens ocultas ainda transmitidas, token de reconexão/ACL não revogado, perda de backup. Falha segura sempre; não divulgar dados reais. Capturas DOM são estáticas e não certificam Chrome real na rede.

**Relações:** D-INOV-032 já é decisão A+C, não reabrir; D-INOV-026 testes; D-INOV-030 correção TEST33; D-INOV-028 não migrar engine. Este despacho novo refere-se à **infraestrutura compartilhada**, ausente dos anteriores. **NENHUM ACK ou LEASE/WRITER do Desenvolvedor é presumido.**
