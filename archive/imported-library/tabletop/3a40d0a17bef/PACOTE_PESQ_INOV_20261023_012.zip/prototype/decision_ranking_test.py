"""Pure recommendation ranking, NOT a combat simulator or RPG rules engine."""
import json, math
from pathlib import Path

# All scores below are SYNTHETIC proxies supplied by an external trusted engine.
# No PA, attacks, magic, defenses, or legal actions are calculated here.
WEIGHTS={'objective':3.0,'survival':2.0,'control':1.0,'resourceReserve':1.0,'teamSynergy':1.0}
def recommend(candidates):
 if not isinstance(candidates,list):return []
 eligible=[]
 for c in candidates:
  if not isinstance(c,dict) or c.get('legality')!='PREVALIDATED_EXTERNAL' or not isinstance(c.get('id'),str) or not c['id'] or not all(type(c.get(k)) in (int,float) and math.isfinite(c[k]) and 0<=c[k]<=1 for k in WEIGHTS):continue
  score=sum(c[k]*v for k,v in WEIGHTS.items())
  eligible.append({'actionId':c['id'],'score':round(score,5),'mechanicalResult':None,'warning':'ADVISORY_ONLY'})
 return sorted(eligible,key=lambda x:(-x['score'],x['actionId']))

def c(id,**kw):return {'id':id,'legality':'PREVALIDATED_EXTERNAL',**{k:kw.get(k,0.5) for k in WEIGHTS}}

tests=[
 ('no_input',lambda:recommend(None)==[]),
 ('empty',lambda:recommend([])==[]),
 ('reject_unverified',lambda:recommend([{'id':'x','legality':'UNVERIFIED'}])==[]),
 ('valid_single',lambda:len(recommend([c('a')]))==1),
 ('favor_objective',lambda:recommend([c('b',objective=0),c('a',objective=1)])[0]['actionId']=='a'),
 ('favor_survival_when_objective_equal',lambda:recommend([c('b',survival=0),c('a',survival=1)])[0]['actionId']=='a'),
 ('avoid_invalid_nan',lambda:recommend([c('a',objective=float('nan'))])==[]),
 ('avoid_out_of_range',lambda:recommend([c('a',objective=-1)])==[]),
 ('stable_tie',lambda:recommend([c('z'),c('a')])[0]['actionId']=='a'),
 ('never_fake_mechanics',lambda:all(q['mechanicalResult'] is None for q in recommend([c('a')]))),
]
res=[{'test':name,'pass':bool(fn())} for name,fn in tests]
Path(__file__).resolve().parent.parent.joinpath('results/TACTICAL_RANKING_SYNTHETIC.json').write_text(json.dumps({'tests':res,'pass':sum(t['pass'] for t in res),'total':len(res),'scope':'advisory ranking of prevalidated synthetic candidates, not official mechanics'},indent=2))
assert all(x['pass'] for x in res),res
print('ADVISORY',len(res),'/',len(res),'PASS')
