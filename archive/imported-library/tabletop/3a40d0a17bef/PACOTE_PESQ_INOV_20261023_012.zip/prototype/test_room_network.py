"""Independent acceptance on 3 real browser WebSockets + SQLite cold restart (synthetic-only)."""
import asyncio, copy, json, os, tempfile, time, contextlib
from pathlib import Path
from aiohttp import web, ClientSession, WSMsgType
from playwright.async_api import async_playwright
from room_server import create_server

TOKENS={'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'}
OUT=Path(__file__).resolve().parent.parent/'results'
results=[];errors=[]
def ck(name,success,detail=''):
 results.append({'test':name,'pass':bool(success),'detail':str(detail)[:250]})
 if not success:errors.append(name)
 print(('PASS' if success else 'FAIL'),name, detail)
async def start(db):
 app=create_server(db,TOKENS)
 runner=web.AppRunner(app.app,access_log=None);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
 port=site._server.sockets[0].getsockname()[1]
 return app,runner,port
async def send(ws,role,typ,revision,**extra):
 cid=extra.pop('commandId',f'fixture_{role}_{time.time_ns()}')
 cmd={'type':typ,'baseRevision':revision,'commandId':cid,**extra}
 await ws.send_json({'type':'COMMAND','command':cmd})
 while True:
  m=await ws.receive_json(timeout=3)
  if m.get('type')=='ACK':return m,cmd
async def ws_auth(session,port,role):
 ws=await session.ws_connect(f'http://127.0.0.1:{port}/ws')
 await ws.send_json({'type':'JOIN','token':TOKENS[role]})
 m=await ws.receive_json(timeout=5)
 assert m['type']=='SNAPSHOT',m
 return ws,m['data']
async def snap_after(ws,version):
 for _ in range(5):
  x=await ws.receive_json(timeout=3)
  if x.get('type')=='SNAPSHOT' and x['data']['revision']>=version:return x['data']
 raise AssertionError('no frame')

async def run():
 OUT.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='assim_p012_') as td:
  db=Path(td)/'room.sqlite'
  app,runner,port=await start(db)
  async with ClientSession() as sess:
   # Independent actual TCP websocket clients, not state clones.
   mw,m=await ws_auth(sess,port,'master');aw,a=await ws_auth(sess,port,'p1');bw,b=await ws_auth(sess,port,'p2')
   ck('01_three_actual_websocket_clients',len(app.clients['master'])==len(app.clients['p1'])==len(app.clients['p2'])==1)
   ck('02_initial_revision_consensus',m['revision']==a['revision']==b['revision']==0)
   ck('03_master_admin_marker_visible',bool(m.get('adminMarkers')))
   ck('04_player1_admin_marker_absent',not any(k in a for k in ('adminMarkers','adminRevision')) and 'PRIVADO' not in json.dumps(a))
   ck('05_player2_admin_marker_absent',not any(k in b for k in ('adminMarkers','adminRevision')) and 'PRIVADO' not in json.dumps(b))
   ck('06_public_marker_both_players',len(a['markers'])==len(b['markers'])==1)
   # unauthorized token
   bad=await sess.ws_connect(f'http://127.0.0.1:{port}/ws');await bad.send_json({'type':'JOIN','token':'WRONG_TOKEN'});err=await bad.receive_json(timeout=3)
   ck('07_unknown_token_denied',err.get('code')=='UNAUTHORIZED');await bad.close()
   bad=await sess.ws_connect(f'http://127.0.0.1:{port}/ws');await bad.send_json({'type':'COMMAND','command':{}});err=await bad.receive_json(timeout=3)
   ck('08_command_before_auth_denied',err.get('code')=='AUTH_REQUIRED');await bad.close()
   ack,_=await send(aw,'p1','PRIVATE_MARK',0,text='should fail')
   ck('09_player_private_marker_denied',ack.get('error')=='FORBIDDEN')
   ack,_=await send(aw,'p1','MOVE',0,unitId='unit-p1',x=4,y=2)
   ck('10_out_of_turn_rejected',ack.get('error')=='NOT_YOUR_TURN')
   # master turn -> p1, all receive new revision
   ack,_=await send(mw,'master','END_TURN',0);ck('11_master_turn_accepted',ack['ok'] and ack['revision']==1)
   ma=await snap_after(mw,1);aa=await snap_after(aw,1);bb=await snap_after(bw,1)
   ck('12_turn_broadcast_three_clients',ma['turn']==aa['turn']==bb['turn']=='p1' and ma['revision']==aa['revision']==bb['revision']==1)
   # stale wrong version
   ack,_=await send(aw,'p1','MOVE',0,unitId='unit-p1',x=4,y=2)
   ck('13_stale_command_rejected',ack.get('error')=='STALE_REVISION')
   ack,cmd=await send(aw,'p1','MOVE',1,unitId='unit-p1',x=4,y=2,commandId='MOVE_0000001')
   ck('14_valid_move_accepted',ack['ok'] and ack['revision']==2)
   ma=await snap_after(mw,2);aa=await snap_after(aw,2);bb=await snap_after(bw,2)
   ck('15_movement_synced_all_three',all(next(u for u in q['units'] if u['id']=='unit-p1')['x']==4 for q in (ma,aa,bb)))
   # same command id same payload => accepted idempotently, no new revision
   await aw.send_json({'type':'COMMAND','command':cmd});ack=await aw.receive_json(timeout=3)
   ck('16_idempotent_command_retry',ack.get('deduplicated') is True and ack.get('revision')==2)
   badcmd={**cmd,'x':5};await aw.send_json({'type':'COMMAND','command':badcmd});ack=await aw.receive_json(timeout=3)
   ck('17_id_reused_different_payload_rejected',ack.get('error')=='ID_REUSE_CONFLICT')
   ack,_=await send(aw,'p1','MOVE',1,unitId='unit-p1',x=5,y=2,commandId='MOVE_0000002')
   ck('18_race_stale_second_move_denied',ack.get('error')=='STALE_REVISION')
   ack,_=await send(aw,'p1','MOVE',2,unitId='unit-master',x=2,y=1)
   ck('19_player_cannot_move_master_unit',ack.get('error')=='UNIT_NOT_OWNED')
   ack,_=await send(aw,'p1','MOVE',2,unitId='unit-p1',x=6,y=2)
   ck('20_illegal_move_denied',ack.get('error')=='SYNTHETIC_ADJACENCY_ONLY')
   ack,_=await send(aw,'p1','MOCK_ACTION',2,unitId='unit-p1',targetId='unit-p2')
   ck('21_mock_action_accepted',ack.get('ok') and ack.get('revision')==3)
   ma=await snap_after(mw,3);aa=await snap_after(aw,3);bb=await snap_after(bw,3)
   ck('22_mock_has_no_RPG_damage',ma['lastEvent']['mechanics']=='NOT_EXECUTED' and not any(k in ma for k in ('vida','PA','damage')))
   ck('23_event_visible_to_clients',aa['lastEvent']==bb['lastEvent'])
   # publish by player denied
   ack,_=await send(aw,'p1','PUBLIC_MARK',3,text='NOPE')
   ck('24_player_cannot_set_shared_marker',ack.get('error')=='FORBIDDEN')
   # force next turn and reconnect p2
   ack,_=await send(aw,'p1','END_TURN',3)
   ck('25_player_turn_advances',ack['ok'] and ack['revision']==4)
   ma=await snap_after(mw,4);aa=await snap_after(aw,4);bb=await snap_after(bw,4)
   await bw.close()
   bw,b2=await ws_auth(sess,port,'p2')
   ck('26_reconnect_authorized_snapshot',b2['revision']==4 and b2['turn']=='p2' and len(b2['units'])==3)
   ck('27_reconnect_no_admin',not any(k in b2 for k in ('adminMarkers','adminRevision')))
   # private mark should not increment shared revision; only master gets broadcast
   ack,_=await send(mw,'master','PRIVATE_MARK',0,text='segredo-teste-restrito',commandId='PRIVATE_0001')
   ck('28_private_marker_updated',ack.get('ok') and ack.get('revision')==1)
   pm=await snap_after(mw,4)
   ck('29_private_revision_separate',pm['revision']==4 and pm['adminRevision']==1)
   ck('30_secret_seen_only_by_master','segredo-teste-restrito' in json.dumps(pm,ensure_ascii=False))
   # Reconnect player and verify private updates totally excluded
   await aw.close();aw,p1b=await ws_auth(sess,port,'p1')
   ck('31_no_secret_in_player_reconnect','segredo-teste-restrito' not in json.dumps(p1b,ensure_ascii=False) and 'adminRevision' not in p1b)
   # p2 moves valid then end turn
   ack,_=await send(bw,'p2','MOVE',4,unitId='unit-p2',x=5,y=3)
   ck('32_second_player_can_move',ack.get('ok') and ack.get('revision')==5)
   ma=await snap_after(mw,5);aa=await snap_after(aw,5);bb=await snap_after(bw,5)
   ck('33_second_player_move_synced',all(next(u for u in q['units'] if u['id']=='unit-p2')['y']==3 for q in (ma,aa,bb)))
   ack,_=await send(bw,'p2','END_TURN',5)
   ck('34_round_ends_to_master',ack.get('ok') and ack.get('revision')==6)
   ma=await snap_after(mw,6);aa=await snap_after(aw,6);bb=await snap_after(bw,6)
   ck('35_round_count_increment',ma['turn']=='master' and ma['turnNumber']==2)
   ack,_=await send(mw,'master','PUBLIC_MARK',6,text='marcador-autorizado-2')
   ck('36_master_shared_marker_change',ack.get('ok') and ack.get('revision')==7)
   ma=await snap_after(mw,7);aa=await snap_after(aw,7);bb=await snap_after(bw,7)
   ck('37_shared_marker_realtime',all(q['markers'][0]['text']=='marcador-autorizado-2' for q in (ma,aa,bb)))
   ck('38_no_private_field_after_public_update',all('adminMarkers' not in q and 'segredo-teste-restrito' not in json.dumps(q) for q in (aa,bb)))
   ck('39_sqlite_receipts_persisted',app.store.db.execute('SELECT COUNT(*) FROM command_receipt').fetchone()[0]>=7)
   await mw.close();await aw.close();await bw.close()
  await runner.cleanup()
  # cold restart: same sqlite, room state and receipts survive process recreation
  app2,runner2,port2=await start(db)
  async with ClientSession() as s:
   mw,x=await ws_auth(s,port2,'master');aw,y=await ws_auth(s,port2,'p1');bw,z=await ws_auth(s,port2,'p2')
   ck('40_cold_restart_room_revision',x['revision']==y['revision']==z['revision']==7)
   ck('41_cold_restart_units',next(t for t in x['units'] if t['id']=='unit-p1')['x']==4)
   ck('42_cold_restart_private_marker_scope','segredo-teste-restrito' in json.dumps(x,ensure_ascii=False) and 'segredo-teste-restrito' not in json.dumps(y,ensure_ascii=False))
   ack,_=await send(aw,'p1','MOVE',1,unitId='unit-p1',x=4,y=2,commandId='MOVE_0000001')
   ck('43_idempotence_after_restart',ack.get('deduplicated') is True and ack.get('revision')==2)
   await mw.close();await aw.close();await bw.close()
  await runner2.cleanup()
  # Browser NETWORK navigation is blocked by container administrator (ERR_BLOCKED_BY_ADMINISTRATOR).
  # Test page DOM with role-appropriate snapshots injected as fixture; DO NOT call it 3 browser WebSockets.
  app3,runner3,port3=await start(Path(td)/'browser.sqlite')
  async with async_playwright() as pw:
   browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
   contexts=[await browser.new_context(viewport={'width':w,'height':h},is_mobile=i!=2,has_touch=i!=2) for i,(w,h) in enumerate(((390,844),(360,740),(820,900)))]
   pages=[await c.new_page() for c in contexts]
   markup=Path(__file__).with_name('index.html').read_text()
   for i,role in enumerate(('master','p1','p2')):
    await pages[i].set_content(markup)
    await pages[i].evaluate('(s)=>{snap=s;render()}',app3.store.projection(role))
   ck('44_three_browser_DOM_contexts_STATIC',len(pages)==3 and all([await p.locator('#flag').inner_text()==r+' conectado' for p,r in zip(pages,('master','p1','p2'))]))
   ck('45_static_browser_mobile_viewports',all([await p.evaluate('document.documentElement.scrollWidth <= innerWidth') for p in pages[:2]]))
   ck('46_static_browser_hidden_marker_not_in_player_DOM',not await pages[1].locator('.adminmark').count() and not await pages[2].locator('.adminmark').count())
   ck('47_static_browser_master_marker_visible',await pages[0].locator('.adminmark').count()==1)
   v=await app3.store.execute('master',{'commandId':'browser_turn_0001','type':'END_TURN','baseRevision':0})
   for i,role in enumerate(('master','p1','p2')):await pages[i].evaluate('(s)=>{snap=s;render()}',app3.store.projection(role))
   ck('48_static_browser_turn_refresh',v['ok'] and all(['Turno p1' in await p.locator('#summary').inner_text() for p in pages]))
   v=await app3.store.execute('p1',{'commandId':'browser_move_0001','type':'MOVE','baseRevision':1,'unitId':'unit-p1','x':4,'y':2})
   for i,role in enumerate(('master','p1','p2')):await pages[i].evaluate('(s)=>{snap=s;render()}',app3.store.projection(role))
   ck('49_static_browser_move_p2_DOM',v['ok'] and await pages[2].locator('.cell[data-xy="4,2"]').inner_text()=='P1')
   ck('50_static_browser_move_master_DOM',await pages[0].locator('.cell[data-xy="4,2"]').inner_text()=='P1')
   await pages[0].screenshot(path=str(OUT/'SCREEN_STATIC_MASTER.png'))
   await pages[2].screenshot(path=str(OUT/'SCREEN_STATIC_PLAYER.png'))
   ck('51_static_browser_screenshots',all((OUT/x).exists() for x in ('SCREEN_STATIC_MASTER.png','SCREEN_STATIC_PLAYER.png')))
   for ctx in contexts:await ctx.close()
   await browser.close()
  await runner3.cleanup()
  assert not errors, '\n'.join(errors)
 out={'baseline':'synthetic aiohttp+SQLite websockets localhost (NOT Tabletop/VLAB)','environment':'Tests 1-43 actual Python aiohttp WebSocket connections via localhost; tests 44-51 browser DOM with snapshots injected (network navigation blocked by administrator); Chromium Linux mobile emulated 390x844/360x740 + desktop 820x900; NO real Android or direct browser-WebSocket','pass':sum(x['pass'] for x in results),'total':len(results),'fail':errors,'tests':results}
 (OUT/'NETWORK_TEST_RESULTS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
 print('SUMMARY',out['pass'],'/',out['total'],'failed',out['fail'])

if __name__=='__main__':asyncio.run(run())
