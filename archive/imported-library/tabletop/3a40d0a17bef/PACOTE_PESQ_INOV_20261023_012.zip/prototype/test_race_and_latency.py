"""Separate runtime behavior/latency analysis; all local synthetic messages only."""
import asyncio, tempfile, json, statistics, time
from pathlib import Path
from aiohttp import ClientSession,web
from room_server import create_server
OUT=Path(__file__).resolve().parent.parent/'results'
T={'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'}
async def connect(s,port,role):
 ws=await s.ws_connect(f'http://127.0.0.1:{port}/ws');await ws.send_json({'type':'JOIN','token':T[role]});x=await ws.receive_json(timeout=2);assert x['type']=='SNAPSHOT';return ws,x['data']
async def nextack(ws):
 for _ in range(3):
  x=await ws.receive_json(timeout=4)
  if x['type']=='ACK':return x
 raise Exception('ack timeout')
async def nextsnap(ws,rev):
 for _ in range(4):
  x=await ws.receive_json(timeout=4)
  if x['type']=='SNAPSHOT' and x['data']['revision']>=rev:return x['data']
 raise Exception('snapshot timeout')
async def ack_and_snap(ws,rev):
 ack=snap=None
 for _ in range(6):
  m=await ws.receive_json(timeout=4)
  if m.get('type')=='ACK':ack=m
  if m.get('type')=='SNAPSHOT' and m.get('data',{}).get('revision',-1)>=rev:snap=m['data']
  if ack is not None and snap is not None:return ack,snap
 raise RuntimeError('missing ack or snapshot')
async def run():
 OUT.mkdir(exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='p012load_') as td:
  app=create_server(Path(td)/'room.sqlite',T);runner=web.AppRunner(app.app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
  async with ClientSession() as s:
   mw,_=await connect(s,port,'master');p1a,_=await connect(s,port,'p1');p1b,_=await connect(s,port,'p1');p2,_=await connect(s,port,'p2')
   await mw.send_json({'type':'COMMAND','command':{'type':'END_TURN','baseRevision':0,'commandId':'race_start_00001'}})
   await nextack(mw)
   await asyncio.gather(nextsnap(mw,1),nextsnap(p1a,1),nextsnap(p1b,1),nextsnap(p2,1))
   cmds=[{'type':'MOVE','baseRevision':1,'commandId':'race_dual_00001','unitId':'unit-p1','x':4,'y':2},{'type':'MOVE','baseRevision':1,'commandId':'race_dual_00002','unitId':'unit-p1','x':3,'y':3}]
   await asyncio.gather(p1a.send_json({'type':'COMMAND','command':cmds[0]}),p1b.send_json({'type':'COMMAND','command':cmds[1]}))
   pair=await asyncio.gather(ack_and_snap(p1a,2),ack_and_snap(p1b,2),nextsnap(mw,2),nextsnap(p2,2))
   acks=[pair[0][0],pair[1][0]]
   accepted=sum(bool(x.get('ok')) for x in acks);rejected=sum(x.get('error')=='STALE_REVISION' for x in acks)
   assert accepted==1 and rejected==1,acks
   print('RACE',accepted,'accepted',rejected,'stale')
   # master can send marker even when not active; send an action and await frames on all four clients.
   samples=[];total=80;rev=2
   for i in range(total):
    cmd={'type':'PUBLIC_MARK','baseRevision':rev,'commandId':f'perf_marker_{i:04d}','text':f'autorizado-{i}'}
    start=time.perf_counter()
    await mw.send_json({'type':'COMMAND','command':cmd})
    ack=await nextack(mw)
    assert ack.get('ok') and ack['revision']==rev+1,ack
    recv=await asyncio.gather(nextsnap(mw,rev+1),nextsnap(p1a,rev+1),nextsnap(p1b,rev+1),nextsnap(p2,rev+1))
    assert all(x['markers'][0]['text']==f'autorizado-{i}' for x in recv)
    samples.append((time.perf_counter()-start)*1000)
    rev+=1
   result={'environment':'aiohttp synthetic loopback 127.0.0.1 one process, 4 sockets (2 same role); NOT Cloudflare/network mobile latency','race':{'accepted':accepted,'stale':rejected},'messages':total,'receivers_per_message':4,'median_ack_and_fanout_ms':round(statistics.median(samples),3),'p95_ack_and_fanout_ms':round(sorted(samples)[int((len(samples)-1)*.95)],3),'max_ms':round(max(samples),3),'limit_note':'Includes local Python+TCP only; not browser rendering, real WAN, Android or service billables'}
   (OUT/'RACE_FANOUT_LOCAL.json').write_text(json.dumps(result,indent=2))
   print('FANOUT',result)
   for x in (mw,p1a,p1b,p2):await x.close()
  await runner.cleanup()
if __name__=='__main__':asyncio.run(run())
