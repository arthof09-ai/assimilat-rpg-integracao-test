"""PESQ-012 — isolated, synthetic-only WebSocket room research bench.

NOT a combat engine, RPG mechanic, Party integration, or production auth.
Uses aiohttp & stdlib SQLite. Bind 127.0.0.1 by default.
"""
from __future__ import annotations
import asyncio, hashlib, json, os, secrets, sqlite3
from pathlib import Path
from aiohttp import web, WSMsgType

ROLES=("master","p1","p2")
INITIAL={
 "room":"SYNTH-ROOM","revision":0,"adminRevision":0,"turn":"master","turnNumber":1,
 "grid":{"width":7,"height":7},
 "units":[{"id":"unit-master","owner":"master","x":1,"y":1},
          {"id":"unit-p1","owner":"p1","x":3,"y":2},
          {"id":"unit-p2","owner":"p2","x":5,"y":4}],
 "markers":[{"id":"public-1","sceneId":"arena","x":4,"y":1,"text":"Runa sintética"}],
 "adminMarkers":[{"id":"admin-1","sceneId":"arena","x":2,"y":5,"text":"PLANO PRIVADO DO MESTRE — TEST"}],
 "lastEvent":{"kind":"INIT"}
}

def clone(v): return json.loads(json.dumps(v,ensure_ascii=False))

def digest(token:str)->str: return hashlib.sha256(token.encode()).hexdigest()

class RoomStore:
 def __init__(self,db_path,invites):
  self.path=str(db_path);self.invites={digest(v):k for k,v in invites.items()};self.lock=asyncio.Lock()
  self.db=sqlite3.connect(self.path,isolation_level=None,check_same_thread=False)
  self.db.execute("PRAGMA journal_mode=WAL")
  self.db.execute("CREATE TABLE IF NOT EXISTS room(id TEXT PRIMARY KEY,payload TEXT NOT NULL)")
  self.db.execute("CREATE TABLE IF NOT EXISTS command_receipt(actor TEXT NOT NULL,cid TEXT NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(actor,cid))")
  if not self.db.execute("SELECT 1 FROM room WHERE id='SYNTH-ROOM'").fetchone():
   self.db.execute("INSERT INTO room VALUES (?,?)",('SYNTH-ROOM',json.dumps(INITIAL,ensure_ascii=False)))
 def identity(self,token):return self.invites.get(digest(token)) if isinstance(token,str) else None
 def state(self):return json.loads(self.db.execute("SELECT payload FROM room WHERE id='SYNTH-ROOM'").fetchone()[0])
 def projection(self,role):
  s=self.state()
  allowed={"schema":"assim.multiplayer.synthetic.v1","room":s['room'],"revision":s['revision'],"turn":s['turn'],"turnNumber":s['turnNumber'],"grid":s['grid'],"units":s['units'],"markers":s['markers'],"lastEvent":s['lastEvent'],"you":role}
  if role=='master':allowed['adminMarkers']=s['adminMarkers'];allowed['adminRevision']=s['adminRevision']
  return clone(allowed)
 async def execute(self,role,p):
  if not isinstance(p,dict):return {'ok':False,'error':'INVALID_PAYLOAD'}
  cid=p.get('commandId'); typ=p.get('type');base=p.get('baseRevision')
  if not isinstance(cid,str) or not 8<=len(cid)<=70 or not all(ch.isalnum() or ch in '-_' for ch in cid):return {'ok':False,'error':'INVALID_ID'}
  if typ not in ('MOVE','END_TURN','MOCK_ACTION','PUBLIC_MARK','PRIVATE_MARK'):return {'ok':False,'error':'INVALID_COMMAND'}
  async with self.lock:
   prev=self.db.execute("SELECT payload FROM command_receipt WHERE actor=? AND cid=?",(role,cid)).fetchone()
   if prev:
    old=json.loads(prev[0])
    stamp=json.dumps(p,sort_keys=True,ensure_ascii=False)
    if old['request']!=stamp:return {'ok':False,'error':'ID_REUSE_CONFLICT'}
    return {**old['ack'],'deduplicated':True}
   s=self.state();private=(typ=='PRIVATE_MARK')
   if private and role!='master':return {'ok':False,'error':'FORBIDDEN'}
   if type(base)!=int or base!=(s['adminRevision'] if private else s['revision']):
    return {'ok':False,'error':'STALE_REVISION','current':s['adminRevision'] if private and role=='master' else s['revision']}
   if typ in ('MOVE','END_TURN','MOCK_ACTION') and s['turn']!=role:return {'ok':False,'error':'NOT_YOUR_TURN'}
   before=json.dumps(s,sort_keys=True)
   if typ=='MOVE':
    u=next((u for u in s['units'] if u['id']==p.get('unitId')),None)
    x,y=p.get('x'),p.get('y')
    if u is None or u['owner']!=role:return {'ok':False,'error':'UNIT_NOT_OWNED'}
    if type(x)!=int or type(y)!=int or not(0<=x<7 and 0<=y<7):return {'ok':False,'error':'INVALID_COORD'}
    if abs(x-u['x'])+abs(y-u['y'])!=1:return {'ok':False,'error':'SYNTHETIC_ADJACENCY_ONLY'}
    if any(t['x']==x and t['y']==y for t in s['units']):return {'ok':False,'error':'OCCUPIED'}
    u['x'],u['y']=x,y
    s['lastEvent']={'kind':'SYNTHETIC_MOVE','unitId':u['id'],'x':x,'y':y}
   elif typ=='END_TURN':
    i=ROLES.index(role);s['turn']=ROLES[(i+1)%3]
    if s['turn']=='master':s['turnNumber']+=1
    s['lastEvent']={'kind':'SYNTHETIC_TURN','active':s['turn']}
   elif typ=='MOCK_ACTION':
    u=next((u for u in s['units'] if u['id']==p.get('unitId')),None)
    target=next((u for u in s['units'] if u['id']==p.get('targetId')),None)
    if not u or u['owner']!=role:return {'ok':False,'error':'UNIT_NOT_OWNED'}
    if not target or target['id']==u['id']:return {'ok':False,'error':'BAD_TARGET'}
    # Explicitly no Vida/PA/Alma/attack roll; VLAB is NOT simulated.
    s['lastEvent']={'kind':'MOCK_VISUAL_ACTION_ONLY','unitId':u['id'],'targetId':target['id'],'mechanics':'NOT_EXECUTED'}
   elif typ=='PUBLIC_MARK':
    if role!='master':return {'ok':False,'error':'FORBIDDEN'}
    text=p.get('text')
    if not isinstance(text,str) or not 1<=len(text)<=80:return {'ok':False,'error':'BAD_TEXT'}
    s['markers']=[{'id':'public-1','sceneId':'arena','x':4,'y':1,'text':text}]
    s['lastEvent']={'kind':'SHARED_MARKER_CHANGED'}
   elif typ=='PRIVATE_MARK':
    text=p.get('text')
    if not isinstance(text,str) or not 1<=len(text)<=80:return {'ok':False,'error':'BAD_TEXT'}
    s['adminMarkers']=[{'id':'admin-1','sceneId':'arena','x':2,'y':5,'text':text}]
    s['adminRevision']+=1
   if before==json.dumps(s,sort_keys=True):return {'ok':True,'noop':True,'revision':s['revision']}
   if not private:s['revision']+=1
   ack={'ok':True,'revision':s['adminRevision'] if private else s['revision'],'kind':typ}
   # transaction protects event+state persistence if interrupted; CID unique for retry.
   self.db.execute('BEGIN IMMEDIATE')
   try:
    self.db.execute("UPDATE room SET payload=? WHERE id='SYNTH-ROOM'",(json.dumps(s,ensure_ascii=False),))
    self.db.execute('INSERT INTO command_receipt VALUES (?,?,?)',(role,cid,json.dumps({'request':json.dumps(p,sort_keys=True,ensure_ascii=False),'ack':ack})))
    self.db.execute('COMMIT')
   except Exception:self.db.execute('ROLLBACK');raise
   return ack
 def close(self):self.db.close()

class RoomApp:
 def __init__(self,store):self.store=store;self.clients={r:set() for r in ROLES};self.app=web.Application();self.app.router.add_get('/',self.html);self.app.router.add_get('/ws',self.websocket);self.app.on_cleanup.append(self.cleanup)
 async def html(self,request):
  return web.FileResponse(Path(__file__).with_name('index.html'),headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})
 async def send_frame(self,ws,role):
  await ws.send_json({'type':'SNAPSHOT','data':self.store.projection(role)})
 async def broadcast(self,admin_only=False):
  for role,clients in self.clients.items():
   if admin_only and role!='master':continue
   for ws in tuple(clients):
    if not ws.closed:await self.send_frame(ws,role)
 async def websocket(self,request):
  ws=web.WebSocketResponse(max_msg_size=8192,heartbeat=25)
  await ws.prepare(request)
  role=None
  try:
   async for msg in ws:
    if msg.type!=WSMsgType.TEXT:continue
    try:p=json.loads(msg.data)
    except json.JSONDecodeError:await ws.send_json({'type':'ERROR','code':'INVALID_JSON'});continue
    if role is None:
     if not isinstance(p,dict) or p.get('type')!='JOIN':await ws.send_json({'type':'ERROR','code':'AUTH_REQUIRED'});await ws.close();break
     role=self.store.identity(p.get('token'))
     if not role:await ws.send_json({'type':'ERROR','code':'UNAUTHORIZED'});await ws.close();break
     self.clients[role].add(ws)
     await self.send_frame(ws,role)
     continue
    if not isinstance(p,dict) or p.get('type')!='COMMAND':await ws.send_json({'type':'ERROR','code':'BAD_ENVELOPE'});continue
    cmd=p.get('command');ack=await self.store.execute(role,cmd)
    await ws.send_json({'type':'ACK','commandId':cmd.get('commandId') if isinstance(cmd,dict) else None,**ack})
    if ack.get('ok') and not ack.get('deduplicated') and not ack.get('noop'):
     await self.broadcast(admin_only=cmd.get('type')=='PRIVATE_MARK')
  finally:
   if role:self.clients[role].discard(ws)
  return ws
 async def cleanup(self,app):self.store.close()


def create_server(db,invites):
 store=RoomStore(db,invites);return RoomApp(store)

def cli():
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765);p.add_argument('--db',default='room_test.sqlite');p.add_argument('--test-fixtures',action='store_true')
 a=p.parse_args()
 invites= {'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'} if a.test_fixtures else {r:secrets.token_urlsafe(24) for r in ROLES}
 print('ROOM SYNTHETIC ONLY. Invite tokens below are private to session; no real user authentication.',flush=True)
 for k,v in invites.items():print(f'{k}: {v}',flush=True)
 web.run_app(create_server(a.db,invites).app,host=a.host,port=a.port,print=lambda *x:print(*x,flush=True))
if __name__=='__main__':cli()
