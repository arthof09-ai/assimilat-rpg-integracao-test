# PESQ-INOV-20261022-010 — Continuidade científica TEST33, cinco vídeos e Xbox Labs

**Papel:** Terceiro Comestre Inovador — Pesquisador, Mestre-side/TEST, no Laboratório do Inovador já existente; nenhuma alteração em GitHub Pages, branch, app autoritativo, VLAB, Party, O Primeiro, CRAFT, DMG ou LEVEL-UP.

## ANTES / Recuperação canônica

Notion RUN-010 registra TEST32 publicado em `gh-pages` commit `0aa9bc817844fa4ce0e16a2103a3a89988df577c` com GitHub Pages workflow `39845848140 completed/success`, mas **sem smoke de HTTP/Android físico**. TEST33 é candidato não publicado, acrescentando tratamento para marker UPDATE, sceneNotes change e renameScene no-op. Fonte canônica RUN-010 + documentos de PESQ009 e despachos D029–032 lidos, sem RUN-011 observado na checagem mais recente anterior ao registro.

**Binários originais físicos:** TEST33 técnico `PACOTE_TECNICO_TABLETOP_TEST33_20261022.zip` 72.801 bytes SHA256 `aa85ba2647073d3707646e13dc4099d57b60d89fdc9da0b839d782af354768bc`, 14 entradas / 13/13 manifesto SHA / CRC PASS. TEST33 público candidato `TABLETOP_SITE_SINTETICO_TEST33_CANDIDATE.zip` 28.752 bytes SHA `25160fc798916d660d94b58e16bd43596c0f38ea2b4dcd55cd1d0f0c519d8c8d`, 3 entradas / CRC PASS. TEST32 público SHA `f7ac82dc4945a45734d11f52e1b1ea3c502615c065edd2ace7ac6884b783d7c7`; produto código app JS TEST33 = técnico byte-a-byte SHA `7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4`, TEST32 SHA `758a16a29d0ae8c584ab62956351761dba846e640518543bc3fb30a898d86c2a`. Nenhum material Mestre-only do pacote privado R205 foi recuperado, alterado ou incluído.

## Auditoria independente D030 — GREEN focal

O Desenvolvedor relata 30/30 novos testes; **estes são resultados DELE**, não nossos.

`audit_noop_independent_010.py` executado em cópias do app REAL com Chromium Linux Headless 144, viewports 390x844 / 360x740, Mock de armazenamento com contadores explícitos `setItem`. São **44 instâncias** (11 cenários ×2 versões ×2 telas). TEST32 **14/22 critérios PASS + 8/22 FAIL (RED esperado)**. TEST33 **22/22 PASS**. Casos: marker UPDATE exato, marker mesmo valor com whitespace, scene notes sem mudança, rename com valor idêntico, cancelar marker, marcador inválido, Apagar casa vazia após undo, edição REAL marker kind, edição REAL marker text, nova sceneNote e rename REAL. Critérios: estado JSON idêntico em no-op, revisão/log armazenado idênticos, nenhuma nova gravação, redo possível; mutações reais produzem escrita, invalidam redo e undo restaura estado. RESULTADO: D030 **corrigido no recorte TEST33 candidato**. Um problema de instrumentação da bancada de pré-teste confundiu mudança de modo com edição de cena; foi diagnosticado/corrigido ANTES da coleta final; números preliminares descartados, nenhuma falsa deficiência atribuída ao produto.

**Limites:** Não prova Android físico, duas abas verdadeiras, persistência real de quota/storage/security, todas ações futuras ou deploy. Sem alteração autoritativa do Desenvolvedor, sem ACK presumido.

## FOV/marker D032 — decisão do Mestre, não regra RPG

`audit_fov_markers_010.py` em TEST33 original: 2 viewports ×4 condições = **8/8 testes observacionais conforme hipótese**. Marcador `6,6` fora raio 4 é `fov-hidden`, porém SVG mantém `visibility:visible`; marcador `2,1` dentro da visão permanece. (A) visível ao Mestre funciona hoje; (B) filtro visual `markerOverlay` + `markerCue` pode ocultar, mas **CSS inline aplicado uma vez É INVALIDADO APÓS ZOOM**, porque `renderMarkerOverlay` reconstrói elementos SVG; (C) projeção sintética fail-closed de `MASTER` para eventual Party retorna 0/2, mas não autentica direitos, não testa backend e NÃO é segurança canônica. A recomendação é manter (A) como comportamento Mestre-only sem mudar política, avaliar (C) para arquitetura futura se Mestre decidir introduzir cliente Party-safe; não confundir CSS com controle de acesso. (B) opcional em modo TEST, reavaliado em cada render.

## Xbox Labs / WebAssembly / WebGPU — primário vs marketing

[Xbox Wire 13/out/2026](https://news.xbox.com/en-us/2026/10/13/introducing-xbox-labs/) anuncia grupo experimental de criadores, engenheiros e cientistas para exploração de adaptação/reimplementação de jogos e IA, respeitando IP. Não apresenta SDK/artefato aberto para integração no Tabletop. [labs.xbox.com](https://labs.xbox.com/) possui interface pública de demonstração interativa, atalhos e experimento ASCII de vídeo que afirma processamento local, não provamos código aberto ou disponibilização de engine. [MDN GPU](https://developer.mozilla.org/en-US/docs/Web/API/Navigator/gpu) exige contexto seguro e hardware; [Chrome WebGPU Android](https://developer.chrome.com/blog/new-in-webgpu-121?hl=pt-BR) descreve disponibilidade em alguns dispositivos Android 12+ com Qualcomm/ARM. WebAssembly disponível em muitos browsers mas não demonstra melhora no DOM atual. Não migrar engine, não instalar Xbox SDK inexistente, não quebrar DRM/asset IP.

**Teste físico de software:** `web_tech_and_render_bench_010.py`: TEST33 fonte original 20×20; 15 aquecimentos + **60 renders/condição** para 0/10/30/40 marcadores com Chromium/Linux headless 144 viewport 390×844. Medianas em ms **1,75 / 2,45 / 3,0 / 4,1**; p95 **2,3 / 4,5 / 4,4 / 7,8**. Estado serializado 815/1.929/4.195/5.328 bytes. `WebAssembly` disponível no browser de TEST; `navigator.gpu=false`, WebGL2 indisponível e `isSecureContext=false` no contexto `about:blank` usado no harness — **NÃO são resultados de suporte WebGPU/Android**, nem benchmarks WASM vs JS. A medição não justifica substituir renderizador.

## Cinco links YouTube, integralidade e evidências

`VIDEOS_LOTE05_EVIDENCIAS_010.json`: cinco IDs do Mestre, cinco aberturas YouTube com `cache miss`, tentativas de pesquisa por ID/título e endpoints de metadados públicos sem retorno confiável; consultas HTTPS diretas no container falharam DNS. A ausência de metadados **não implica remoção nem privacidade do vídeo**. Nenhum dos cinco vídeos foi assistido integralmente; não há transcrição oficial nem repositórios demonstrados verificados. Somente títulos provisórios 1 e 4 da Coordenação, sem autoria/data comprovadas. IDs 2,3,5 permanecem sem tema confirmado. Não inventar vencedor de comparação de IAs, método de geração de jogos, engine ou performance.

**Utilidade científica efetivamente comprovada fora dos vídeos:** [Google Developers, 09/set/2026](https://developers.googleblog.com/the-anatomy-of-harness-engineering-how-to-evaluate-iterate-and-guard-ai-coding-agents/) fundamenta testes comportamentais; nesta pesquisa demonstramos diretamente avaliação com o **MESMO contrato** sobre duas versões oficiais, capturando falso snapshot+write. Não alegar que essa metodologia foi explicada pelos vídeos não acessados.

## Resultado, limites e despachos

- D-INOV-030: acrescentar ADENDO DE AUDITORIA TEST33 GREEN; não abrir novo D-id nem promover a produto implantado.
- D-INOV-032: três propostas A/B/C; Mestre decide política; cobertura de renderer e marcadores na camada de tiles, sem CSS como sigilo.
- D-INOV-026 e D-INOV-028: reforçar contratos de comportamento e evitar migração prematura. Nenhum novo despacho ID requerido.
- NAC-PASS-02 **PASS científico proporcional**: arquivos recuperados autenticados, ensaios independentes TEST33 22/22, FOV 8/8 de observação, benchmark 4×60, documentação e pacote/Library readback; **HOLD produto global**, hardware Chrome Android, HTTP live, concorrência multiaba, decisões FOV Party, implantação TEST33 e efeitos do VLAB canônico.
- **LAST-VERIFIED-UNIT:** TEST33 candidato bytes SHA7b1 + QA 22/22, FOV 8/8, bench quatro condições, fontes primárias oficiais lidas, documento e pacote após readback.
- **FIRST-PENDING:** avaliação Coordenador/Mestre sobre A/B/C e aceite D030; publicação TEST33 é responsabilidade delegada do Desenvolvedor/Coordenador, não do Pesquisador.
- **NEXT:** auditar RUN posterior para regressões no-op + render policy se implementada, Chrome Android físico e origem HTTPS para duas abas reais; atualizar vídeos somente com transcrições/metadados de fonte auditável.
- **NO-REPEAT:** não repetir PESQ006–009, não recriar ruler ou FOV, não reexecutar 719/719 do Desenvolvedor, não publicar TEST33 nem criar motor/projeto/norma paralela.
