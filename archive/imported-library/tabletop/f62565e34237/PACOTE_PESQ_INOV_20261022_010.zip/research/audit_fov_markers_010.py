"""Read-only/DOM-only policy research on TEST33, synthetic cells; never Party or VLAB."""
import pathlib,asyncio,json,sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from audit_noop_independent_010 import mount,ROOT
from playwright.async_api import async_playwright

async def configure(page):
    await mount(page,'test33')
    await page.select_option('#gridSize','20')
    await page.locator('[data-mode="mark"]').click()
    for x,y,txt in [(2,1,'Alvo visível TEST'),(6,6,'Nota escondida TEST')]:
      await page.evaluate('([x,y])=>window.__tabletopTEST.cell(x,y)',[x,y])
      await page.locator('#markerText').fill(txt)
      await page.locator('#markerSave').click()
    await page.select_option('#fovRadius','4')
    await page.locator('#layerFov').check()
    await page.evaluate('window.__tabletopTEST.render()')

async def probe(page):
    return await page.evaluate('''() => {
        const scene=window.__tabletopTEST.scene();const v=new Set(window.__tabletopTEST.fovNow());
        const shapes=Array.from(document.querySelectorAll('#markerOverlay .visual-mark'));
        const cls=p=>document.querySelector('.tile[data-xy="'+p+'"]')?.className;
        return {radius:scene.fovRadius,fovEnabled:scene.fovEnabled,
            marks:scene.markers.map((m,i)=>({id:m.id,key:m.x+','+m.y,visible:v.has(m.x+','+m.y),
               explored:scene.explored.includes(m.x+','+m.y),tile:cls(m.x+','+m.y),
               svgVisibility:getComputedStyle(shapes[i]).visibility,
               cueHidden:document.querySelector('.tile[data-xy="'+m.x+','+m.y+'"] .markerCue').hidden})),
            markerListCount:document.querySelectorAll('#markerList .markerItem').length,
            stored:window.__store['assim.tabletop.synthetic.workspace.v1']??null,
            revision:scene.round,
        }
    }''')

async def main():
    async with async_playwright() as pw:
      b=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
      cases=[]
      for size in [(390,844),(360,740)]:
        p=await b.new_page(viewport={'width':size[0],'height':size[1]})
        await configure(p)
        before=await probe(p)
        cases.append({'size':size,'mode':'A baseline always visible master','observation':before,'pass':
           bool(before['marks'][0]['visible'] and not before['marks'][1]['visible'] and
           before['marks'][1]['svgVisibility']=='visible' and before['marks'][1]['tile'].find('fov-hidden')>=0)})
        # Experimental policy B, DOM-only, two render-layer targets. No writes.
        await p.evaluate('''() => {
            const v=new Set(window.__tabletopTEST.fovNow()); const s=window.__tabletopTEST.scene();
            const nodes=Array.from(document.querySelectorAll('#markerOverlay .visual-mark'));
            s.markers.forEach((m,i)=>{const key=m.x+','+m.y;const show=v.has(key);
                nodes[i].style.visibility=show?'visible':'hidden';
                const cue=document.querySelector('.tile[data-xy="'+key+'"] .markerCue');
                if(cue)cue.style.visibility=show?'visible':'hidden';
            });
        }''')
        filtered=await probe(p)
        cases.append({'size':size,'mode':'B proposed visual-only filter','observation':filtered,'pass':
          bool(filtered['marks'][0]['svgVisibility']=='visible' and filtered['marks'][1]['svgVisibility']=='hidden' and
               filtered['stored']==before['stored'] and filtered['markerListCount']==before['markerListCount'])})
        # C: synthetic projection fail-closed: only explicit allowlist is projected; never send MASTER marks.
        proj=await p.evaluate('''() => {
           const data=window.__tabletopTEST.scene().markers.map(m=>({...m,scope:'MASTER'}));
           const out=data.filter(m=>m.scope==='PUBLIC_APPROVED').map(m=>({x:m.x,y:m.y,kind:m.kind,text:m.text}));
           return {count:out.length,originalCount:data.length,types:Object.keys(out[0]||{})}
        }''')
        cases.append({'size':size,'mode':'C projection conceptual synthetic','observation':proj,'pass':proj['count']==0 and proj['originalCount']==2})
        # Refresh rebuild proof: post-render DOM one-time filter is NOT durable.
        await p.evaluate('window.__tabletopTEST.zoom(72)')
        refreshed=await probe(p)
        cases.append({'size':size,'mode':'B one-time CSS invalidated by zoom/re-render','observation':refreshed,'pass':
            bool(refreshed['marks'][1]['svgVisibility']=='visible' and refreshed['marks'][1]['tile'].find('fov-hidden')>=0 and refreshed['stored']==before['stored'])})
        await p.close()
      await b.close()
    result={'run':'PESQ010-FOV-POLICY','environment':'Chromium Linux via playwright synthetic mocked localStorage; TEST33 original; no real Party data','checks':len(cases),'passed':sum(v['pass'] for v in cases),'cases':cases}
    o=ROOT/'evidence/FOV_MARKER_POLICIES_010.json';o.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(result['passed'],'/',result['checks'])
    for r in cases:print(r['size'],r['mode'],r['pass'])
if __name__=='__main__':asyncio.run(main())
