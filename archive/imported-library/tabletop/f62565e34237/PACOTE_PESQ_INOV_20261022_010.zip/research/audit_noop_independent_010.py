"""Independent browser differential for TEST32/TEST33; synthetic only. Not Developer tests."""
import asyncio, pathlib, json, re, hashlib, sys
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
KEY='assim.tabletop.synthetic.workspace.v1'

async def mount(page, version):
    d=ROOT/'work'/version
    h=(d/'index.html').read_text(); js=(d/'app.js').read_text(); css=(d/'styles.css').read_text()
    h=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',h)
    h=h.replace('<link rel="stylesheet" href="styles.css">','').replace('<script src="app.js" defer></script>','')
    await page.set_content(h)
    await page.evaluate("""() => {
      window.__writes=0; window.__reads=0;window.__store={};
      Object.defineProperty(window,'localStorage',{configurable:true,value:{
        getItem(k){window.__reads++;return window.__store[k]??null},
        setItem(k,v){window.__writes++;window.__store[k]=String(v)},
        removeItem(k){delete window.__store[k]}
      }});
      window.__events=[]; window.prompt=(msg,v)=>v;
    }""")
    await page.add_style_tag(content=css)
    await page.add_script_tag(content=js)

async def snap(p):
    return await p.evaluate("""() => ({
      scene:JSON.stringify(window.__tabletopTEST.scene()),
      state:JSON.stringify(window.__tabletopTEST.state()),
      rev:window.__tabletopTEST.state().revision,
      writes:window.__writes,
      raw:window.__store['assim.tabletop.synthetic.workspace.v1']??null,
      log:JSON.stringify(window.__tabletopTEST.scene().logs),
      markers:JSON.stringify(window.__tabletopTEST.markers())
    })""")

async def wall_undo(p):
    await p.locator('[data-mode="wall"]').click()
    await p.evaluate('window.__tabletopTEST.cell(4,4)')
    assert await p.evaluate("window.__tabletopTEST.scene().walls.includes('4,4')")
    await p.evaluate('window.__tabletopTEST.undo()')
    assert not await p.evaluate("window.__tabletopTEST.scene().walls.includes('4,4')")

async def new_marker(p,kind='pin',text='Ponte TEST'):
    await p.locator('[data-mode="mark"]').click()
    await p.evaluate('window.__tabletopTEST.cell(3,3)')
    await p.locator('#markerKind').select_option(kind)
    await p.locator('#markerText').fill(text)
    await p.locator('#markerSave').click()
    assert len(await p.evaluate('window.__tabletopTEST.scene().markers')) ==1

async def marker_edit(p,kind=None,text=None):
    await p.locator('[data-mode="mark"]').click()
    await p.evaluate('window.__tabletopTEST.cell(3,3)')
    if kind is not None:await p.locator('#markerKind').select_option(kind)
    if text is not None:await p.locator('#markerText').fill(text)
    await p.locator('#markerSave').click()

async def test_case(b,version,scenario,viewport=(390,844)):
    ctx=await b.new_context(viewport={'width':viewport[0],'height':viewport[1]})
    p=await ctx.new_page();errors=[];p.on('pageerror',lambda x:errors.append(str(x)))
    await mount(p,version)
    if scenario.startswith('marker') or scenario=='invalid_marker_text':
        await new_marker(p)
        await wall_undo(p)
    else:await wall_undo(p)
    if scenario.startswith('marker') or scenario=='invalid_marker_text':
        await p.locator('[data-mode="mark"]').click()
        await p.evaluate('window.__tabletopTEST.cell(3,3)')
        if scenario=='marker_equivalent_trim': await p.locator('#markerText').fill('   Ponte TEST   ')
        if scenario=='marker_kind_real':await p.locator('#markerKind').select_option('highlight')
        if scenario=='marker_text_real':await p.locator('#markerText').fill('Outra ponte TEST')
        if scenario=='invalid_marker_text':await p.locator('#markerText').fill(' ')
    elif scenario=='no_op_erase':await p.locator('[data-mode="erase"]').click()
    before=await snap(p)
    if scenario in ['marker_exact','marker_equivalent_trim','marker_kind_real','marker_text_real','invalid_marker_text']:
        await p.locator('#markerSave').click()
    elif scenario=='marker_cancel':await p.locator('#markerCancel').click()
    elif scenario=='notes_exact':
        await p.locator('#sceneNotes').evaluate("e=>{e.dispatchEvent(new Event('change',{bubbles:true}))}")
    elif scenario=='rename_exact':await p.locator('#renameScene').click()
    elif scenario=='notes_real':
        await p.locator('#sceneNotes').evaluate("e=>{e.value='Nova nota TEST';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    elif scenario=='rename_real':
        await p.evaluate("window.prompt=(msg,v)=>v+' modificado'")
        await p.locator('#renameScene').click()
    elif scenario=='no_op_erase':await p.evaluate('window.__tabletopTEST.cell(4,3)')
    else:raise ValueError(scenario)
    after=await snap(p)
    real=scenario.endswith('_real')
    preserved={k:before[k]==after[k] for k in ('state','rev','writes','raw','log','scene')}
    observations={
        'version':version,'case':scenario,'viewport':viewport,'expectedMutation':real,
        'noErrors':not errors,'payloadStateSame':preserved['state'],
        'revisionSame':preserved['rev'],'writesSame':preserved['writes'],
        'storageSame':preserved['raw'],'sceneLogSame':preserved['log'],
        'sceneSame':preserved['scene'],
        'writeDelta':after['writes']-before['writes'],
        'revisionDelta':after['rev']-before['rev'],
        'markerDialogOpen':await p.locator('#markerDialog').is_visible(),
        'markerError':await p.locator('#markerFormError').inner_text(),
    }
    await p.evaluate('window.__tabletopTEST.redo()')
    observations['redoRestoredWall']=await p.evaluate("window.__tabletopTEST.scene().walls.includes('4,4')")
    observations['PASS']= bool(not errors and (not real)==all(preserved.values()) and observations['redoRestoredWall']==(not real))
    if real:
        await p.evaluate('window.__tabletopTEST.undo()')
        observations['undoAfterReal']=(await snap(p))['scene']!=after['scene']
        observations['PASS']=observations['PASS'] and observations['undoAfterReal']
    await ctx.close()
    return observations

CASES=['marker_exact','marker_equivalent_trim','notes_exact','rename_exact','marker_cancel','invalid_marker_text','no_op_erase','marker_kind_real','marker_text_real','notes_real','rename_real']
async def main():
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        res=[]
        for v in ('test32','test33'):
            for size in [(390,844),(360,740)]:
                for case in CASES:
                    try:r=await test_case(browser,v,case,size)
                    except Exception as ex:r={'version':v,'case':case,'viewport':size,'PASS':False,'error':str(ex)}
                    res.append(r);print(v,size,case,'PASS' if r['PASS'] else 'FAIL', 'writes',r.get('writeDelta'), 'redo',r.get('redoRestoredWall'))
        await browser.close()
    out=ROOT/'evidence'/'AUDITORIA_DIFERENCIAL_TEST32_TEST33_010.json'
    out.write_text(json.dumps({'environment':'Chromium Linux 144, Playwright, mocked localStorage; NOT Android physical','total':len(res),'pass':sum(r['PASS'] for r in res),'results':res},indent=2,ensure_ascii=False))
    print('TOTAL',sum(r['PASS'] for r in res),'/',len(res));print(out)
if __name__=='__main__':asyncio.run(main())
