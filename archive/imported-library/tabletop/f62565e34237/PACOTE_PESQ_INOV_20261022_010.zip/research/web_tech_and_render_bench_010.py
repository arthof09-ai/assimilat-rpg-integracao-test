"""Small synthetic TEST33 rendering measurement; not GPU/Android or a whole app benchmark."""
import asyncio,json,pathlib,statistics,sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from audit_noop_independent_010 import mount,ROOT
from playwright.async_api import async_playwright

async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=await b.new_page(viewport={'width':390,'height':844})
    await mount(page,'test33')
    features=await page.evaluate('''() => ({userAgent:navigator.userAgent,secure:window.isSecureContext,hasWebAssembly:typeof WebAssembly==='object',hasWebGPU:!!navigator.gpu,hasWebGL2:!!document.createElement('canvas').getContext('webgl2'),origin:location.origin})''')
    await page.select_option('#gridSize','20')
    cases=[]
    for count in (0,10,30,40):
      current=await page.evaluate('window.__tabletopTEST.scene().markers.length')
      # Add up to count distinct synthetic coordinates, excluding default unit cells.
      for i in range(current,count):
        x=3+i%10;y=4+i//10
        await page.evaluate('''({x,y,i})=>{
          const id=window.__tabletopTEST.scene().id;
          window.__tabletopTEST.markerCommand('ADD',{x,y,sceneId:id},{kind:'pin',text:'MARCA TEST '+i});
        }''',{'x':x,'y':y,'i':i})
      numbers=await page.evaluate('''()=>{let vals=[];for(let k=0;k<15;k++)window.__tabletopTEST.render();for(let k=0;k<60;k++){const a=performance.now();window.__tabletopTEST.render();vals.push(performance.now()-a)}return vals}''')
      number_sorted=sorted(numbers)
      cases.append({'marks':count,'n':len(numbers),'median_ms':statistics.median(numbers),'p95_ms':number_sorted[int(len(numbers)*.95)-1],'max_ms':max(numbers),'min_ms':min(numbers),'bytes_saved':len((await page.evaluate('JSON.stringify(window.__tabletopTEST.state())')).encode())})
    await page.close();await b.close()
  result={'conditions':'TEST33 public unmodified, mock localStorage, 20x20 grid, Chromium Linux headless 144, 390x844, 15 warmups + 60 renders per count; no Android/GPU comparison','features':features,'measurements':cases}
  out=ROOT/'evidence/TEST33_RENDER_AND_WEB_CAPABILITIES_010.json'
  out.write_text(json.dumps(result,ensure_ascii=False,indent=2))
  print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':asyncio.run(main())
