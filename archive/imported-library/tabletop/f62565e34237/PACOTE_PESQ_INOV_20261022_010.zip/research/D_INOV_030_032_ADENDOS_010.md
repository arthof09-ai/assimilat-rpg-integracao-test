# Adendos científicos — D-INOV-030 e D-INOV-032, PESQ-010

## D-INOV-030 — Auditoria independente GREEN TEST33 candidato (P1)

- **BASELINE:** TEST32 original publicado vs TEST33 candidato não publicado, ZIP público + técnico autenticados, `app.js` byte-equivalente entre public e technical.
- **Problema histórico:** confirmação de `marker UPDATE` idêntico, nota `change` idêntica, `renameScene` sem alteração eliminavam Refazer em TEST32, com snapshots/revisões/gravações adicionais.
- **Evidência:** `audit_noop_independent_010.py`, Chromium Linux, viewports 390×844 e 360×740, mock `localStorage` com contadores de `setItem`. 44 instâncias em 11 famílias × 2 versões × 2 viewports. TEST32 14/22 PASS; TEST33 22/22 PASS. Oito RED no TEST32 eram quatro ações no-op por dois viewports. Um teste inválido inicial que confundia mudança de modo com mutação do conteúdo foi corrigido no harness **ANTES** desta contagem e excluído.
- **Contrato:** sem mudança material, preservar `state`, `revision`, `scene.logs`, string JSON no storage, contador `setItem`, `future` (testada indiretamente via Refazer). Mudanças reais devem realizar uma gravação, invalidar Refazer e permanecer desfeitas após Undo, como compatível com seu histórico.
- **Resultados adicionais:** texto com espaços removidos antes de comparar, cancelamento de marcador, payload de texto inválido, clique Apagar no-op, mudança real de kind, texto, nota e nome.
- **Prioridade:** P1, correção TEST33 adequada no recorte; recomenda-se fechar D030 **apenas para estes contratos** após aceite do Coordenador, NÃO homologar produto/Android nem afirmar que TEST33 foi publicado.
- **Risco residual:** races multiaba reais, hardware Android e todas as formas de ações no-op futuras fora da bateria. Guardar a suíte como regressão leve, sem refatoração geral.
- **Destinatário:** Desenvolvedor / Coordenação. **ACK:** desconhecido.

## D-INOV-032 — FOV visual e marcações (P1 decisão de UX)

- **BASELINE:** TEST33 original. FOV é efeito visual Mestre-only, jamais controle de acesso Party.
- **Reprodução:** marca TEST em casa 6,6 fora do raio4 da unidade (1,1); `.tile.fov-hidden` enquanto `#markerOverlay .visual-mark` mantém `visibility:visible`. Casa 2,1 visível normal.
- **Alternativa A:** marcas sempre visíveis ao Mestre — zero custo e preserva planejamento, mas exige rótulo que diferencie anotação administrativa de percepção simulada.
- **Alternativa B:** seguir FOV — ocultar simultaneamente SVG + `.markerCue` quando não visível; excluir do tabuleiro sem ocultar da lista administrativa, mostrar indicação do porquê. **Proof:** ocultação DOM-only funciona, mas após `zoom(72)` `renderMarkerOverlay` reconstrói SVG e marca volta a aparecer. Portanto política deve ser aplicada em toda renderização, não filtro CSS one-shot. Nunca usar CSS como sigilo.
- **Alternativa C:** camada Mestre explícita e futura projeção Party autorizada; custo maior por escopo/migração. Exigir filtro **antes da transmissão**, com allowlist, nunca confiar no browser para esconder bytes proibidos. Uma POC `scope=MASTER` produziu projeção sintética de 0/2 marcas para Party, MAS isto não autentica autorização real. A definição canônica de acesso é do Mestre.
- **Recomendação:** **A temporariamente no produto Mestre-only**, por preservar fluxos existentes, e **C como arquitetura preferida se houver cliente Party no futuro**. B deve ser opcional e experimental, nunca regra oficial de percepção por decisão deste Pesquisador.
- **Evidência:** `audit_fov_markers_010.py`, 8/8 verificações observacionais em duas resoluções (inclui falha esperada do CSS one-shot sob zoom). No-op de filtro no storage documentado.
- **Estado:** pesquisa/POC verificada; produto não alterado, decisão Mestre pendente.

## Engenharia com IA / Xbox Labs — sem novo despacho

O anúncio Xbox Wire de 13/10/2026 confirma LABS como iniciativa exploratória, não SDK de terceiros pronto. MDN/Chrome confirmam que WebGPU depende de plataforma, contexto seguro e GPU, não um requisito para 40 marcadores. Bench TEST33 nativo 20×20, 60 renders por cardinalidade, mediana 0/10/30/40 = 1,75/2,45/3,0/4,1 ms Chromium/Linux, **não Android físico**. Conservar D-INOV-026 (harness behavioral RED/GREEN) e D-INOV-028 (não migrar engine) sem duplicar tickets. Os cinco links YouTube permanecem com metadados insuficientes para atribuir benchmark ou método concreto aos autores.
