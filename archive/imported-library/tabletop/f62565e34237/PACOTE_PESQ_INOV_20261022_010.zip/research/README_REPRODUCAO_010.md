# Reproduzir PESQ-INOV-010 — somente Mestre-Side TEST

Dependências de pesquisa: Python 3.11+, Playwright Python, Chromium local (nos testes `/usr/bin/chromium`). Não instalar no celular do Mestre; scripts de auditoria pertencem ao laboratório científico e não ao site publicado.

1. Recuperar de forma **autorizada** os ZIPs públicos sintéticos originais `TABLETOP_SITE_SINTETICO_TEST32.zip` e `TABLETOP_SITE_SINTETICO_TEST33_CANDIDATE.zip` da Biblioteca do Mestre. Verificar SHA completos listados no relatório.
2. Extrair **fora** do pacote de pesquisa: `<work>/test32/index.html,app.js,styles.css` e `<work>/test33/index.html,app.js,styles.css`.
3. Extrair este pacote dentro do diretório raiz; manter os scripts no subdiretório `research/` e criar `work/test32`, `work/test33` como na etapa anterior.
4. `python -u research/audit_noop_independent_010.py` — resultado esperado, sobre fontes TEST32/33: 36/44 checks PASS, sendo 8 falhas RED intencionais da baseline TEST32 e 22/22 PASS no TEST33. Todo teste considera estado, logs, revision, storage bytes e chamadas de setItem, undo/redo.
5. `python -u research/audit_fov_markers_010.py` — 8/8 observações de A/B/C e invalidação do filtro DOM one-shot no zoom. B e C são ensaios visuais/sintéticos, NÃO implementação de segurança Party.
6. `python -u research/web_tech_and_render_bench_010.py` — render 60 amostras após 15 aquecimentos para 0/10/30/40 marcas, dados de performance não determinísticos, úteis somente em comparação contextual.

Os testes montam HTML no `page.set_content`, removem CSP **somente no harness**, injetam mock de localStorage e usam Chrome Linux; origem é `null`, sem demonstração de HTTPS/Android, WebGPU real, armazenamento real multiaba ou cache/cookies. Não são exploits nem controles do aplicativo público.

**Nenhum código autoritativo, ZIP do Desenvolvedor ou dados reais do VLAB/R205/Party está incluído** neste pacote.
