# PESQ-019 — auditoria independente TEST39 × Codex 0.4.0

Pesquisa Mestre-only na operação existente, sem nova implementação de backend nem engine.

**Execute em um ambiente Python com `playwright`, Chromium e as fontes autorizadas:**

```bash
python3 prepare_sources.py /path/PACOTE_TECNICO_TABLETOP_TEST38_A_TEST39_20261024.zip /path/ponte-vlab-tabletop-0.4.0-test38.zip
bash run_all.sh
```

A preparação verifica SHA256, CRC e path seguro, extraindo fontes somente em `sources/` sob a pasta da pesquisa; não modifica os ZIPs originais. O pacote de pesquisa **não contém** os dois ZIPs originais por questões de custódia. Use as cópias já existentes na Biblioteca Mestre ou os anexos autorizados.

O script de DOM remove a meta CSP **apenas no mount de teste**, pois Chromium aqui bloqueou navegação normal por política administrativa. A CSP original é comprovada separadamente pela leitura exata de `index.html`. Nenhum resultado desse mount deve ser anunciado como browser-native HTTP. O HTTP executado pelo teste é via Python host, como explicado no relatório.

A verificação de ligação nativa precisa ocorrer em browser com navegação local permitida, rodando o próprio servidor Codex com `--arena` sem Playwright intermediário; confirmar que o asset servido é TEST39 e não o TEST38 legado. O TEST38 Codex native existente serve como baseline, não como aceite do TEST39. VLAB oficial permanece HOLD.

Veja `report/PSV_PESQ019.md` para handoffs e evidência.

**Canário opcional em outra bancada:** `python3 tests/audit_native_boundary_019.py` percorre primeiro a página TEST39 normal e depois a DEMO nativa Codex0.4 vendorizada TEST38. **Não foi executado até concluir** aqui porque o navegador bloqueou toda navegação; não significa gate TEST39 nativo PASS mesmo se ambos os módulos separados passarem. Não promover o resultado ao produto.
