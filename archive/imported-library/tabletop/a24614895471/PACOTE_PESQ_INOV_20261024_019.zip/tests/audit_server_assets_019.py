"""GET/POST differential on unmodified Codex0.4 local server. Not browser-native."""
import json, hashlib, sys, tempfile, threading, urllib.request, urllib.error, os
from pathlib import Path
S=Path(os.environ.get('PESQ019_SOURCES',str(Path(__file__).resolve().parents[1]/'sources')))
CODEX=S/'codex'/'experiments'/'tabletop_vlab_bridge'
DEV=S/'dev'/'public'
OUT=Path(os.environ.get('PESQ019_EVIDENCE_OUT',str(Path(__file__).resolve().parents[1]/'evidence')))
sys.path.insert(0,str(CODEX))
from authority import Authority, make_server
checks=[]
def ck(name,truth):
 checks.append({'case':name,'pass':bool(truth)})
 if not truth:raise AssertionError(name)
def req(port,url,payload=None,token='FAKE_TEST_PLAYER1',origin=None):
 headers={}
 data=None
 if payload is not None:
  data=json.dumps(payload).encode();headers={'Content-Type':'application/json','Authorization':'Bearer '+token}
 if origin:headers['Origin']=origin
 try:
  with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}/{url}',data=data,headers=headers),timeout=5) as r:return r.status,r.read(),dict(r.headers)
 except urllib.error.HTTPError as e:return e.code,e.read(),dict(e.headers)
with tempfile.TemporaryDirectory() as tmp:
 srv=make_server(Authority(Path(tmp)/'codex.sqlite'),0,arena_assets=True)
 t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
 try:
  port=srv.server_port
  stat,app,hdr=req(port,'app.js');ck('Codex served app.js HTTP200',stat==200)
  ck('GET app.js exact TEST38 vendor',app==(CODEX/'vendor'/'test38'/'app.js').read_bytes())
  ck('GET app.js differs TEST39 app',app!=(DEV/'app.js').read_bytes())
  stat,room,hdr=req(port,'room-client.js');ck('GET room client exact TEST38 vendor',room==(CODEX/'vendor'/'test38'/'room-client.js').read_bytes())
  stat,html,hdr=req(port,'');txt=html.decode();ck('GET Codex HTML200',stat==200)
  ck('Codex origin-only connect-src self',"connect-src 'self'" in txt)
  ck('Codex HTML inserts native HTTP harness script','src="arena_transport.js"' in txt)
  ck('Original TEST39 CSP still forbids HTTP',"connect-src 'none'" in (DEV/'index.html').read_text())
  stat,js,hdr=req(port,'arena_transport.js');ck('GET native harness byte exact',stat==200 and js==(CODEX/'arena_transport.js').read_bytes())
  ck('Native transport directly calls fetch /bridge',"fetch('/bridge'" in js.decode())
  ck('Native harness has no TEST39 attack port',b'TabletopTestAuthorityPort' not in js and b'TabletopTestAuthorityPort' not in app)
  wrong={'schema_version':3,'op':'arena','frame':{'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-gm'}}
  stat,body,hdr=req(port,'bridge',wrong);ck('uninitialized room fails closed',stat!=200)
  ck('failed bridge response contains no stack traces or private data',b'Traceback' not in body and b'FAKE_MASTER_ONLY' not in body)
  stat,body,hdr=req(port,'bridge',wrong,origin='https://untrusted.invalid');ck('forged cross origin returns 403',stat==403)
  ck('no permissive CORS header',not any(k.lower()=='access-control-allow-origin' for k in hdr))
 finally:srv.shutdown();srv.server_close();t.join(timeout=4)
OUT.mkdir(parents=True,exist_ok=True)
result={'checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),'native_browser_http':False,'codex_serves':'vendor/test38, not TEST39','served_app_sha256':hashlib.sha256(app).hexdigest(),'test39_app_sha256':hashlib.sha256((DEV/'app.js').read_bytes()).hexdigest()}
(OUT/'server_assets_019.json').write_text(json.dumps(result,indent=2)+'\n')
print('SERVER ASSETS + RAW HTTP',result['passed'],'/',result['total'],'PASS')
