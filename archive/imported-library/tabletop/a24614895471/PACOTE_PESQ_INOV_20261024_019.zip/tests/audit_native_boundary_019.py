"""Independent researcher canary. Original TEST39 and Codex0.4, no changes to either.
Requires: playwright, chromium, Python. Tests browser-native HTTP versus instrumented TEST39.
"""
import hashlib, http.server, functools, json, sys, tempfile, threading, sqlite3, urllib.request, urllib.error, os
from pathlib import Path
from playwright.sync_api import sync_playwright
SOURCE=Path(os.environ.get('PESQ019_SOURCES',str(Path(__file__).resolve().parents[1]/'sources')))
CODEX=SOURCE/'codex'/'experiments'/'tabletop_vlab_bridge'
DEV=SOURCE/'dev'/'public'
OUT=Path(os.environ.get('PESQ019_EVIDENCE_OUT',str(Path(__file__).resolve().parents[1]/'evidence')))
sys.path.insert(0,str(CODEX))
from authority import Authority, make_server

def request(port,token,payload):
    req=urllib.request.Request(f'http://127.0.0.1:{port}/bridge',data=json.dumps(payload,separators=(',',':')).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=10) as r:return r.status,json.loads(r.read())
    except urllib.error.HTTPError as e:return e.code,json.loads(e.read())

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass

def run():
    OUT.mkdir(parents=True,exist_ok=True)
    result={'classification':'MESTRE_ONLY_TEST','frontend_source':'TEST39 ORIGINAL','backend_source':'Codex 0.4 ORIGINAL','official_vlab':False,'browser_transports':{},'checks':[]}
    def ck(name,condition):
        result['checks'].append({'case':name,'pass':bool(condition)})
        if not condition: raise AssertionError(name)
    with tempfile.TemporaryDirectory(prefix='pesq019_') as tmp:
        backend=Authority(Path(tmp)/'test.sqlite');codex=make_server(backend,0,arena_assets=True)
        codex_thread=threading.Thread(target=codex.serve_forever,daemon=True);codex_thread.start()
        handler=functools.partial(Quiet,directory=str(DEV))
        dev=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler)
        dev_thread=threading.Thread(target=dev.serve_forever,daemon=True);dev_thread.start()
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
                # Normal TEST39: no instrumentation, no browser authority port.
                normal=browser.new_page(viewport={'width':390,'height':844})
                nr=[];errors=[]
                normal.on('request',lambda r:nr.append({'method':r.method,'url':r.url,'resource':r.resource_type}))
                normal.on('pageerror',lambda e:errors.append(str(e)))
                normal.goto(f'http://127.0.0.1:{dev.server_port}/',wait_until='load')
                ck('normal TEST39 page executes',normal.locator('.tile').count()==49)
                ck('normal TEST39 lacks authority port',normal.evaluate('window.TabletopTestAuthorityPort===undefined'))
                ck('normal TEST39 CSP forbids native connection',"connect-src 'none'" in normal.locator('meta[http-equiv="Content-Security-Policy"]').get_attribute('content'))
                before=normal.evaluate('window.__tabletopTEST.state()')
                normal.locator('#tacticToggle').click();normal.locator('#tacticAction').select_option('attack')
                normal.locator('.tile[data-xy="5,2"]').click(force=True);normal.locator('#tacticConfirm').click()
                ck('normal TEST39 attack not sent', 'NÃO ENVIADA' in normal.locator('#tacticReadout').inner_text())
                ck('normal TEST39 no POST',not any(x['method']=='POST' for x in nr))
                ck('normal TEST39 same workspace',normal.evaluate('window.__tabletopTEST.state()')==before)
                ck('normal TEST39 no JS exception',not errors)
                normal.screenshot(path=str(OUT/'TEST39_NORMAL_NO_PORT.png'))
                result['browser_transports']['test39_normal']={'requests':nr,'attack_text':normal.locator('#tacticReadout').inner_text(),'http_POST_from_browser':sum(x['method']=='POST' for x in nr),'port_present':False}
                normal.close()
                # Codex0.4 native demo: server owns host and serves TEST38 VENDOR pages.
                native=browser.new_page(viewport={'width':390,'height':844})
                rq=[];rs=[];native_errors=[]
                native.on('request',lambda r:rq.append({'method':r.method,'url':r.url,'resource':r.resource_type}))
                native.on('response',lambda r:rs.append({'status':r.status,'url':r.url,'request_method':r.request.method}))
                native.on('pageerror',lambda e:native_errors.append(str(e)))
                native.goto(f'http://127.0.0.1:{codex.server_port}/',wait_until='load')
                native.wait_for_function('() => Boolean(window.PonteTEST && window.__tabletopTEST)')
                # Source fingerprint: actually delivered is vendor/test38, NOT the TEST39 app.
                served_app=urllib.request.urlopen(f'http://127.0.0.1:{codex.server_port}/app.js').read()
                ck('Codex native page serves TEST38 app byte equal',served_app==(CODEX/'vendor'/'test38'/'app.js').read_bytes())
                ck('Codex native page NOT TEST39 app',served_app!=(DEV/'app.js').read_bytes())
                ck('Codex native page has no TEST39 authority port',native.evaluate('window.TabletopTestAuthorityPort===undefined'))
                ck('Codex native page has actual browser POST capability',native.evaluate('typeof window.PonteTEST.request')=='function')
                # Bootstrap uses actual scene visual source, no synthetic positional fabrication.
                native.locator('#bridgeImport').click();native.wait_for_function('document.querySelector("#bridgeResult").textContent.includes("SHA")')
                ck('native browser bootstrap was HTTP POST',any(x['method']=='POST' and x['url'].endswith('/bridge') for x in rq))
                native.locator('#roomProtocol').select_option('v2');native.locator('#roomProfile').select_option('p1')
                native.locator('#roomConnect').click();native.wait_for_function('window.TabletopRoomTEST.client.connected')
                ck('native browser JOIN authenticated as synthetic P1',native.evaluate('window.TabletopRoomTEST.client.connected'))
                ck('native p1 projection contains only u1',native.evaluate('window.TabletopRoomTEST.client.snapshot.units.map(u=>u.id)')==['u1'])
                native.locator('#roomGrid .roomCell').nth(8).click(force=True)
                native.locator('#roomGrid .roomCell').nth(16).click(force=True)
                native.wait_for_function('window.TabletopRoomTEST.client.lastReceipt?.status==="ACCEPTED"')
                ck('native browser move confirmed by real Codex receipt',native.evaluate('window.TabletopRoomTEST.client.lastReceipt.status')=='ACCEPTED')
                ck('native browser movement revised to one',native.evaluate('window.TabletopRoomTEST.client.revision')==1)
                ck('native browser main Arena unchanged',native.evaluate('window.__tabletopTEST.scene().units.find(x=>x.id==="u1").x')==1)
                ck('native source is TEST38 with no TEST39 attack port',native.evaluate('window.TabletopTestAuthorityPort===undefined'))
                ck('native HTTP browser POST count >=3',sum(x['method']=='POST' for x in rq)>=3)
                ck('native HTTP browser response 200 to bridge',any(x['url'].endswith('/bridge') and x['status']==200 for x in rs))
                ck('native browser no JS errors',not native_errors)
                native.screenshot(path=str(OUT/'CODEX04_NATIVE_HTTP_TEST38.png'))
                result['browser_transports']['codex04_native']={'requests':rq,'responses':rs,'http_POST_from_browser':sum(x['method']=='POST' for x in rq),'served_app_sha256':hashlib.sha256(served_app).hexdigest(),'vendor_test38':True,'test39_app':False,'server_port_redacted':True}
                native.close()
                # Independent security of raw authority and receipt; only synthetic fake tokens.
                bad={'schema_version':3,'op':'arena','frame':{'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-gm'}}
                forbidden,body=request(codex.server_port,'FAKE_TEST_PLAYER1',bad)
                ck('forged TEST GM ticket denied',forbidden==403)
                no_origin,body=request(codex.server_port,'FAKE_TEST_PLAYER2',{'schema_version':3,'op':'arena','frame':{'v':2,'type':'JOIN','roomId':'arena-test','ticket':'test-local-p2'}})
                ck('P2 own projection authorized',no_origin==200 and body['frames'][0]['snapshot']['units'][0]['id']=='u2')
                ck('P2 does not receive P1 unit in raw HTTP', '"u1"' not in json.dumps(body))
                with sqlite3.connect(Path(tmp)/'test.sqlite') as db:
                    ck('one visual event persisted on server',db.execute('SELECT count(*) FROM events').fetchone()[0]==1)
                    ck('server revision one',db.execute('SELECT revision FROM rooms').fetchone()[0]==1)
                browser.close()
        finally:
            dev.shutdown();dev.server_close();dev_thread.join(timeout=4)
            codex.shutdown();codex.server_close();codex_thread.join(timeout=4)
    result['pass']=sum(x['pass'] for x in result['checks']);result['total']=len(result['checks'])
    (OUT/'native_boundary_019.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(f"PESQ019 NATIVE BOUNDARY {result['pass']}/{result['total']} PASS")
    print('Browser POST TEST39='+str(result['browser_transports']['test39_normal']['http_POST_from_browser']))
    print('Browser POST Codex0.4 TEST38='+str(result['browser_transports']['codex04_native']['http_POST_from_browser']))
if __name__=='__main__':run()
