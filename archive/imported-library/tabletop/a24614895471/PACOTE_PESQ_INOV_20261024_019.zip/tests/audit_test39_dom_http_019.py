"""Independent TEST39/Codex0.4 source audit under locked-down Chromium.
NO browser HTTP: Playwright host binding is explicitly measured and labeled.
"""
import json, re, hashlib, sqlite3, tempfile, threading, sys, urllib.request, urllib.error, collections, os
from pathlib import Path
from playwright.sync_api import sync_playwright
BASE=Path(os.environ.get('PESQ019_SOURCES',str(Path(__file__).resolve().parents[1]/'sources')))
DEV=BASE/'dev'/'public'
CODEX=BASE/'codex'/'experiments'/'tabletop_vlab_bridge'
OUT=Path(os.environ.get('PESQ019_EVIDENCE_OUT',str(Path(__file__).resolve().parents[1]/'evidence')))
sys.path.insert(0,str(CODEX))
from authority import Authority,make_server

def post(port,token,obj):
 req=urllib.request.Request(f'http://127.0.0.1:{port}/bridge',data=json.dumps(obj,separators=(',',':')).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=5) as resp:return resp.status,json.loads(resp.read())
 except urllib.error.HTTPError as err:return err.code,json.loads(err.read())

def mount(p):
 html=(DEV/'index.html').read_text()
 html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html)
 html=html.replace('<link rel="stylesheet" href="styles.css">','')
 for f in ('app.js','room-v2-adapter.js','room-client.js'):
  html=html.replace(f'<script src="{f}" defer></script>','')
 p.set_content(html)
 p.evaluate('''() => {const d={};for(const k of ['localStorage','sessionStorage'])Object.defineProperty(window,k,{configurable:true,value:{getItem:n=>d[n]??null,setItem:(n,v)=>d[n]=String(v),removeItem:n=>delete d[n]}});}''')
 p.add_style_tag(content=(DEV/'styles.css').read_text())
 for f in ('app.js','room-v2-adapter.js','room-client.js'):p.add_script_tag(content=(DEV/f).read_text())

def run():
 OUT.mkdir(parents=True,exist_ok=True)
 checks=[];capture={'status':'SCIENTIFIC_TEST','transport':'PYTHON_HOST_BINDING_NOT_NATIVE_BROWSER','checks':checks,'raw_server_responses':[],'browser_requests':[]}
 def check(name,v):
  checks.append({'case':name,'pass':bool(v)})
  if not v:raise AssertionError(name)
 with tempfile.TemporaryDirectory() as temp:
  path=Path(temp)/'codex.sqlite';server=make_server(Authority(path),0,arena_assets=True)
  t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
  try:
   s,created=post(server.server_port,'FAKE_TEST_MASTER',{'schema_version':1,'op':'create','room_id':'battle39','client_action_id':'create019','expected_revision':0})
   check('Codex0.4 original initialized fake room',s==200 and created.get('ok')==True)
   with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    p=b.new_page(viewport={'width':390,'height':844})
    p.on('request',lambda r:capture['browser_requests'].append({'method':r.method,'url':r.url}))
    mount(p)
    check('original TEST39 app rendered',p.locator('.tile').count()==49)
    check('original TEST39 authority port missing',p.evaluate('window.TabletopTestAuthorityPort===undefined'))
    check('original TEST39 CSP connect-src none',"connect-src 'none'" in (DEV/'index.html').read_text())
    before=p.evaluate('window.__tabletopTEST.state()')
    p.locator('#tacticToggle').click();p.locator('#tacticAction').select_option('attack');p.locator('.tile[data-xy="5,2"]').click(force=True);p.locator('#tacticConfirm').click()
    check('without port attack displayed NOT SENT','NÃO ENVIADA' in p.locator('#tacticReadout').inner_text())
    check('without port no browser POST',not any(r['method']=='POST' for r in capture['browser_requests']))
    check('without port local state intact',before==p.evaluate('window.__tabletopTEST.state()'))
    p.screenshot(path=str(OUT/'test39_no_port_019.png'))
    serial={'sends':0,'queries':0,'lost_once':True}
    def send(req):
     serial['sends']+=1
     assert req['actorId']=='u1' and req['targetId']=='u3' and req['action']=='ATTACK_REQUEST'
     payload={'schema_version':2,'op':'submit','room_id':'battle39','client_action_id':req['commandId'],'expected_revision':0,'actor_id':'actor-1','action':{'kind':'ATTACK_REQUEST','target':{'kind':'UNIT','actor_id':'actor-2'},'turn_id':'turn-test-1','context':{'scene_id':'scene-test-1','ability_id':'basic-attack'}}}
     status,result=post(server.server_port,'FAKE_TEST_PLAYER1',payload)
     capture['raw_server_responses'].append({'source':'PYTHON_HTTP_NOT_BROWSER','op':'submit','status':status,'receipt':result.get('receipt')})
     assert status==200 and result['receipt']['status']=='REJECTED' and result['receipt']['code']=='MECHANICS_UNAVAILABLE'
     if serial['lost_once']:
      serial['lost_once']=False;raise RuntimeError('LAB_INJECTED_ACK_LOSS_AFTER_COMMIT')
     rec=result['receipt'];return {'commandId':rec['client_action_id'],'status':rec['status'],'code':rec['code']}
    def query(cid):
     serial['queries']+=1
     status,result=post(server.server_port,'FAKE_TEST_PLAYER1',{'schema_version':2,'op':'receipt_query','room_id':'battle39','client_action_id':cid})
     capture['raw_server_responses'].append({'source':'PYTHON_HTTP_NOT_BROWSER','op':'receipt_query','status':status,'receipt':result.get('receipt')})
     assert status==200
     if result.get('lookup')=='NOT_FOUND':return {'commandId':cid,'status':'NOT_FOUND'}
     rec=result['receipt'];return {'commandId':rec['client_action_id'],'status':rec['status'],'code':rec['code']}
    p.expose_function('TEST39_HOST_SEND',send);p.expose_function('TEST39_HOST_QUERY',query)
    p.evaluate('''() => {window.TabletopTestAuthorityPort={newId:()=>"pesq019_attack1",send:x=>window.TEST39_HOST_SEND(x),query:id=>window.TEST39_HOST_QUERY(id)};}''')
    p.locator('#tacticAction').select_option('attack');p.locator('.tile[data-xy="5,2"]').click(force=True);p.locator('#tacticConfirm').click()
    p.wait_for_function('window.__tabletopTEST.authority()?.status==="UNKNOWN"')
    check('instrumented browser receives lost ACK status UNKNOWN',p.evaluate('window.__tabletopTEST.authority().status')=='UNKNOWN')
    check('command ID stable after lost ACK',p.evaluate('window.__tabletopTEST.authority().id')=='pesq019_attack1')
    check('ACK loss sends one request only',serial['sends']==1)
    with sqlite3.connect(path) as db:
     stored=db.execute("SELECT receipt FROM receipts WHERE action_id='pesq019_attack1'").fetchone()
    check('original Codex0.4 saved durable attack rejection',bool(stored) and json.loads(stored[0])['code']=='MECHANICS_UNAVAILABLE')
    p.locator('#tacticAuthorityQuery').click();p.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
    check('original TEST39 HUD shows recovered rejection','MECHANICS_UNAVAILABLE' in p.locator('#tacticAuthorityState').inner_text())
    check('query same ID without replay',serial['queries']==1 and serial['sends']==1)
    check('browser did not send HTTP even with instrumented host',not any(r['method']=='POST' for r in capture['browser_requests']))
    check('no attack mutated visual scene',before==p.evaluate('window.__tabletopTEST.state()'))
    p.screenshot(path=str(OUT/'test39_host_binding_recovered_019.png'))
    # Context resets as expected when browser page is replaced (not a native reload test).
    other=b.new_page(viewport={'width':390,'height':844});mount(other)
    check('new TEST39 tab lacks port',other.evaluate('window.TabletopTestAuthorityPort===undefined'))
    check('new TEST39 tab has no pending in RAM',other.evaluate('window.__tabletopTEST.authority()===null'))
    check('new TEST39 tab cannot query lost ID without port',other.locator('#tacticAuthorityQuery').is_disabled())
    with sqlite3.connect(path) as db:
     check('durable receipt remains in Codex after new tab',db.execute("SELECT count(*) FROM receipts WHERE action_id='pesq019_attack1'").fetchone()[0]==1)
     check('no mechanical event applied',db.execute('SELECT count(*) FROM events').fetchone()[0]==0)
    check('TEST39 native transport remains unverified by browser',True) # classification marker
    b.close()
  finally:server.shutdown();server.server_close();t.join(timeout=3)
 capture['checks_pass']=sum(x['pass'] for x in checks);capture['checks_total']=len(checks);capture['host_sends']=serial['sends'];capture['host_queries']=serial['queries'];capture['native_http_verified']=False
 (OUT/'dom_http_019.json').write_text(json.dumps(capture,indent=2,ensure_ascii=False)+'\n')
 print('TEST39 DOM + original CODEX0.4 HTTP via HOST',capture['checks_pass'],'/',capture['checks_total'],'PASS; native browser HTTP HOLD')
if __name__=='__main__':run()
