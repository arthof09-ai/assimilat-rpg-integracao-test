#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PESQ019_SOURCES="${PESQ019_SOURCES:-$(pwd)/sources}"
export PESQ019_EVIDENCE_OUT="$(mktemp -d)"
trap 'rm -rf "$PESQ019_EVIDENCE_OUT"' EXIT
python3 tests/audit_server_assets_019.py
python3 tests/audit_test39_dom_http_019.py
python3 verify_manifest.py
