# PESQ-INOV-20261024-019 — Auditoria independente TEST39 × Codex 0.4.0

**MESTRE-SIDE / TEST.** Continuidade da pesquisa, não outra operação. Originais imutáveis, sem nova autoridade/backend/journal/engine.

## Resultado verificável

**TEST39 normal:** página original sem `window.TabletopTestAuthorityPort` (vide `public/app.js` linhas 69–126), CSP `connect-src 'none'` (HTML original) e HUD `MECÂNICA INDISPONÍVEL / NÃO ENVIADA` ao escolher personagem/ataque/alvo; zero POST pelo browser no ensaio de DOM isolado. Nenhum servidor oficial foi chamado.

**TEST39 instrumentado:** o mesmo JS original aceitou um `TabletopTestAuthorityPort` injetado por Playwright, cujo callback **Python** fez HTTP ao `Authority` **Codex0.4 original** com SQLite TEST. Após COMMIT e perda deliberada de ACK, mostrou UNKNOWN; query da mesma ID recuperou REJECTED/MECHANICS_UNAVAILABLE; nenhum efeito mecânico/evento e workspace local intacto. **A origem do HTTP é Python, não navegador.** Novo contexto sem port não tem a ID em RAM, embora o recibo permaneça no banco: lacuna relevante de recuperabilidade do botão tático entre sessões. Não transformar isso em substituição do journal original; integrar via contrato idempotente existente pelo dono competente.

**Codex0.4 HTTP nativo:** `authority.py:make_server(arena_assets=True)` entrega fisicamente `vendor/test38/app.js`, NÃO o TEST39. Ele reescreve CSP `connect-src 'self'` **apenas no HTML servido** e injeta `arena_transport.js` com `fetch('/bridge')`. GET real do servidor e SHA dos bytes confirmados por script. Logo a demonstração HTTP do Codex cobre TEST38, sem porta tática TEST39: não é TEST39 nativo. Seus POSTs do navegador só são reivindicados pelo pacote original Codex, não reexecutados nesta bancada.

**Limite do laboratório:** Chromium administrativamente impediu navegação para HTTP 127.0.0.1, `file://` e `data:` com `net::ERR_BLOCKED_BY_ADMINISTRATOR` (arquivo `evidence/browser_navigation_blocked_019.json`). Executados DOM via `page.set_content` com meta CSP removida só no *mount* de teste (CSP original auditada separadamente), GET/POST HTTP via Python. Portanto **0 gates browser-native HTTP**, nenhum Android nem VLAB real. Não recomendar bypass da política do ambiente nem relaxar CORS.

## Diferenças de compatibilidade e proprietários

| Fronteira | Estado material | Dono / menor passo |
| --- | --- | --- |
| TEST39 aberto normalmente | **FAIL**: não existe port, ato não enviado | Desenvolvedor: conectar botão tático ao transporte TEST único homologado, sem novos serviços; preservar HOLD VLAB |
| TEST39 com port injetado | **PASS limitado**: host Python→HTTP Codex0.4→SQLite→recibo→HUD | Desenvolvedor/Codex: trocar host binding por transmissão navegador same-origin autorizada e testá-la, sem prometer cobertura já existente |
| Codex0.4 native demo | HTTP GET comprova TEST38 vendorizado + `arena_transport.js`; **TEST39 não é servido** | Codex: consumir arquivos TEST39 legitimados e fazer contrato de port em origem autorizada, não modificar código Dev unilateralmente |
| ACK perdido e query mesma ID | **PASS** durante vida da página, via host | Dono do frontend: recuperar pendente na reabertura sem nova ID, usando journal/outbox existente e vínculo identity/room válido |
| Recuperação após página totalmente nova | **FAIL/HOLD**: ID só existe em RAM do port tático; banco mantém receipt | Frontend: plano de retomada e testes cold-new-page, sem escrever segredo no localStorage |
| Segurança do backend | Origin hostil 403; sem CORS permissivo; erro sanitizado; proteção TEST | Codex: preservar ACL/projeção antes da rede e manter tokens FAKE estritamente TEST; produção HOLD |
| Rejeição ATTACK_REQUEST | `REJECTED/MECHANICS_UNAVAILABLE` durável, evento mecânico = zero | VLAB escritor: fornecer ABI oficial com ator/alvo/ação, turno, recurso, correlação e projeções; nunca deduzir mecânica de ACK |

## Gate de aceite único, implementável

1. **Sem instrumentação**: abrir os HTML/JS **TEST39** por origem autorizada do mesmo servidor, confirmar hash do `app.js` servido e capturar com DevTools **POST iniciado pelo navegador** para `/bridge` (não callbacks Playwright/Python).
2. Escolher unidade→ação→alvo no HUD TEST39, confirmar; request deve preservar ID, ator, alvo e revisão. Para ATTACK_REQUEST sem VLAB, resultado correto é REJECTED/MECHANICS_UNAVAILABLE persistido, não golpe nem movimento.
3. Fechar aba ANTES de receber ACK e reiniciá-la; ID original reaparece via outbox existente/protocolo autorizado, consulta receipt persistido sem reenvio e sem duplicação; tela apresenta o resultado.
4. P1/P2 recebem projeções distintas nos **bytes HTTP/WSS da autoridade**, sem informações Mestre-only ou recibos alheios. Confirmar erro em Origin ou ID/role forjados.
5. Após PASS desses gates de transporte: homologação mecânica VLAB para exatamente uma ação real, uma revisão consistente e um recibo público autorizado. Nunca importar fórmula/dano/PA fake.

## Testes executados nesta rodada (NÃO regressões do desenvolvedor)

- `tests/audit_server_assets_019.py`: **15/15** checks GET/POST nos fontes servidor reais, SHA vendorizado, CSP, Origin.
- `tests/audit_test39_dom_http_019.py`: **21/21** checks DOM TEST39, ausência de port, recuperação Codex0.4 via **host Python**, persistência e novo contexto sem ID em RAM.
- **36/36 checks locais**, com vários controles negativos; não são 36 capacidades. **0/1** teste de HTTP browser-native executável nesta bancada por política administrativa; HOLD, não convertido em PASS.
- Os resultados do pacote Codex0.4 e Desenvolvedor TEST39 são evidência **RELATADA/RECONHECIDA PELOS PACOTES**, não contam como reexecução independente desses suites.

## Prova e custódia

Executar `python prepare_sources.py TEST39_original.zip Codex040_original.zip` usando ZIPs originais de origem Mestre autorizada e SHA exatos, depois `bash run_all.sh`. Os scripts importam código imutável descompactado em `sources/dev` e `sources/codex`. O runner escreve novas evidências em pasta efêmera para preservar o manifesto. O ZIP PESQ019 não redistribui fontes privadas de terceiros nem inventa uma segunda autoridade.

**LAST-VERIFIED:** servidor original Codex0.4 ativo por HTTP Python, carga original TEST39 isolada em Chromium DOM, recibo de rejeição persistido consultado; auditoria dos assets servidos TEST38 verificada. **FIRST-PENDING:** TEST39 sem port nativo e sem retomada cold-new-page; além do runtime desta bancada não permitir certificar nativo browser HTTP. **NEXT:** Dev/Codex fechar botão TEST39 no mesmo servidor/contrato, validar no ambiente browser autorizado e auditar VLAB sem writer de mecânica; Pesquisador reexecuta canários no próximo artefato. **NO-REPEAT:** PESQ012–018, recuperação backend existente, Codex0.4 native TEST38, TEST39 host-binding, testes massivos e frameworks alternativos.

**NAC-PASS proporcional:** PASS dos 36 checks locais e integridade do pacote; HOLD porta nativa TEST39, ACK após cold reload, login real, VLAB, produção, Android físico. Tempo instrumentado indisponível; nenhuma duração reivindicada.
