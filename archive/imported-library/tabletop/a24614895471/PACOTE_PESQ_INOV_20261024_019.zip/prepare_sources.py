"""Prepare exact user-authorized original ZIPs externally; originals remain unchanged.
Usage: python prepare_sources.py /absolute/path/TEST39.zip /absolute/path/CODEX040.zip
This only copies ZIP entries to sources/, never edits original or uploads them.
"""
import hashlib, sys, zipfile
from pathlib import Path
EXPECTED={'dev':'73ef8107ff14348f700809727b1750377005a483fe7d52a7e7113b9790e7545b',
          'codex':'5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a'}
if len(sys.argv)!=3:raise SystemExit('Use: python prepare_sources.py TEST39.zip CODEX040.zip')
root=Path(__file__).resolve().parent/'sources'
for role,path in zip(('dev','codex'),sys.argv[1:]):
 p=Path(path);sha=hashlib.sha256(p.read_bytes()).hexdigest()
 if sha!=EXPECTED[role]:raise SystemExit(f'{role}: SHA mismatch, stop')
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in z.namelist())
  z.extractall(root/role)
 print(role,'SOURCE VERIFIED',sha)
print('Source tree:',root)
