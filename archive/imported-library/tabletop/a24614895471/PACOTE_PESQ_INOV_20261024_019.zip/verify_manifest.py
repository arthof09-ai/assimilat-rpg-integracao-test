import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
m=json.loads((p/'MANIFEST_SHA256.json').read_text());n=0
for rel,digest in m['files'].items():
 assert '..' not in Path(rel).parts
 f=p/rel
 assert f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==digest,rel
 n+=1
print('PESQ019 MANIFEST',n,'/',len(m['files']),'PASS')
