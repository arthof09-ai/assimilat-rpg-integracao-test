"""PESQ-021: SHA+CRC-gated extraction of separate read-only source ZIPs."""
from pathlib import Path
import hashlib,zipfile,sys
ROOT=Path(__file__).resolve().parent
SPEC={
 'dev40':('PACOTE_TECNICO_TABLETOP_TEST39_A_TEST40_20261024.zip','88cda222272436f1d30acae87852c6a27416118b514c56e4c0c3f10ff251fd8e'),
 'codex04':('ponte-vlab-tabletop-0.4.0-test38.zip','5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a'),
 'pesq020':('PACOTE_PESQ_INOV_20261024_020.zip','c8ba30a17138e417fca1008224bb4a951ed3f7df948166edcc9168d531b16209')}
src=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('/mnt/data/PESQ021_sources')
for folder,(name,expected) in SPEC.items():
    f=src/name;raw=f.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha==expected,(name,sha)
    with zipfile.ZipFile(f) as z:
        assert z.testzip() is None,name
        for entry in z.namelist():
            p=Path(entry)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in entry,entry
        dest=ROOT/folder
        if not dest.exists():
            dest.mkdir(parents=True)
            z.extractall(dest)
            (dest/'.source_sha256').write_text(sha+'\n')
        assert (dest/'.source_sha256').read_text().strip()==sha
        print(f'{folder}: sha256 PASS, ZIP CRC PASS, {len(z.namelist())} entries')
print('Sources prepared in isolated TEST copy; original ZIPs untouched')
