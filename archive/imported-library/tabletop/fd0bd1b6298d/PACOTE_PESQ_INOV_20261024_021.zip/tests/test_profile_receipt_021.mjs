/* Independent TEST40 × existing Codex0.4 HTTP/SQLite audit.
 * Tests identity selected in DEMO UI vs the token actually used by the existing
 * native_port.js receipt query. No new backend, no VLAB effects, no modifications
 * to original executors' files. Node HTTP != browser-native HTTP.
 */
import fs from 'node:fs';import vm from 'node:vm';import crypto from 'node:crypto';import assert from 'node:assert/strict';import path from 'node:path';
const ROOT=path.resolve(import.meta.dirname,'..');const url=process.env.PESQ021_TEST_URL;assert(url?.startsWith('http://127.0.0.1:'));
const receipts=JSON.parse(fs.readFileSync(process.env.PESQ021_RECEIPTS,'utf8'));
const entry={profile:'p1',payload:{commandId:receipts.id,sceneId:'c1',actorId:'u1',targetId:'u3',action:'ATTACK_REQUEST'},state:'UNKNOWN'};
const originalSrc=fs.readFileSync(ROOT+'/dev40/connected_test/native_port.js','utf8');const originalRC=fs.readFileSync(ROOT+'/dev40/public/room-client.js','utf8');
const checks=[];function ck(label,ok){assert(ok,label);checks.push(label)};
const HTTP=[];
async function trial(useCandidate){
 const localData={'assim-tabletop-room-pending-test':JSON.stringify({version:1,counter:0,entries:[],external:entry})};
 const storage={getItem:k=>Object.hasOwn(localData,k)?localData[k]:null,setItem:(k,v)=>localData[k]=String(v)};
 const elements=new Map();function elt(id){if(!elements.has(id))elements.set(id,{id,textContent:'',dataset:{},classList:{add(){},remove(){},toggle(){}},style:{setProperty(){}},children:[],parentElement:{append(){}},append(){},replaceChildren(){},setAttribute(){},addEventListener(){}});return elements.get(id)};
 const fakeScene={id:'c1',n:7,walls:[],danger:[],terrain:{},markers:[],units:[{id:'u1',name:'Exploradora TEST',mark:'E',team:'ally',x:1,y:1},{id:'u2',name:'Conjurador TEST',mark:'C',team:'ally',x:1,y:3},{id:'u3',name:'Criatura TEST',mark:'X',team:'enemy',x:5,y:2}]};
 const ctx=vm.createContext({console,Promise,Uint8Array,TextEncoder,crypto:crypto.webcrypto,location:{protocol:'http:',hostname:'127.0.0.1'},Event:class Event{constructor(type){this.type=type}},CustomEvent:class CustomEvent{constructor(type,opts){this.type=type;this.detail=opts?.detail}},
 window:{},document:{getElementById:elt,createElement:()=>({setAttribute(){},textContent:''}),dispatchEvent(){}},
 fetch:async(route,params)=>{const headers=params.headers||{};const r=await fetch(new URL(route,url),params);const result={status:r.status,body:await r.text()};HTTP.push({candidate:useCandidate,uiProfile:ctx.window.TabletopRoomTEST.client.profile,token:headers.Authorization,op:JSON.parse(params.body).op,http:result.status,raw:result.body});return {ok:r.ok,text:async()=>result.body};},
 localStorage:storage,sessionStorage:{getItem:()=>null}});
 const anchor="const room=byId('roomPanel');";assert(originalRC.includes(anchor));vm.runInContext(originalRC.replace(anchor,'window.TestRoomClient=RoomClient;\n'+anchor),ctx,{filename:'room-client.js'});
 vm.runInContext(`window.localStorage=localStorage;window.sessionStorage=sessionStorage;window.TabletopRoomTEST={client:new window.TestRoomClient({protocol:'v2',journalStore:localStorage,nonce:'p021'})};window.TabletopRoomTEST.client.profile='p2';window.TabletopRoomTEST.client.connected=true;window.TabletopRoomTEST.client.revision=0;window.__tabletopTEST={scene:()=>(${JSON.stringify(fakeScene)})};window.PonteTEST={request:()=>{}};`,ctx);
 let src=originalSrc;
 if(useCandidate){const old='if(!idValid(id)||!client.externalPending||';const added="if(client.profile!==PROFILE||client.protocol!=='v2'||!client.connected)throw Error('identity-not-confirmed-by-ui');\n   if(!idValid(id)||!client.externalPending||";assert(src.includes(old));src=src.replace(old,added);const finishOriginal='finish:(id,status)=>client.resolveExternal(id,status),';assert(src.includes(finishOriginal));src=src.replace(finishOriginal,"finish:(id,status)=>(client.profile===PROFILE&&client.protocol==='v2'&&client.connected?client.resolveExternal(id,status):false),")}
 vm.runInContext(src,ctx,{filename:'native_port.js'});
 const port=ctx.window.TabletopTestAuthorityPort;ck('original port initializes',!!port);
 ck('recovered journal is owned by p1',ctx.window.TabletopRoomTEST.client.externalPending?.profile==='p1');
 let test;
 try{test=await port.query(receipts.id)}catch(err){test={blocked:String(err.message)}}
 ck('baseline selected p2 receives p1 receipt' + (useCandidate?' (candidate blocks it)':' (RED expected)'),useCandidate?test.blocked==='identity-not-confirmed-by-ui':test.status==='REJECTED');
 if(useCandidate){
   ck('candidate p2 cannot finalize p1 pending command',port.finish(receipts.id,'REJECTED')===false&&ctx.window.TabletopRoomTEST.client.externalPending?.payload.commandId===receipts.id);
   ctx.window.TabletopRoomTEST.client.profile='p1';const result=await port.query(receipts.id);
   ck('candidate retains p1 receipt query',result.status==='REJECTED'&&result.code==='MECHANICS_UNAVAILABLE');
   ck('candidate p1 can finally reconcile its own journal',port.finish(receipts.id,result.status)===true&&ctx.window.TabletopRoomTEST.client.externalPending===null);
 }else{
   ck('original p2 context can finish and clear p1 journal (RED)',port.finish(receipts.id,test.status)===true&&ctx.window.TabletopRoomTEST.client.externalPending===null);
 }
 ck('no submit or new effect occurred during audit',HTTP.every(x=>x.op==='receipt_query'));
 return {status:test,originalSHA:crypto.createHash('sha256').update(originalSrc).digest('hex'),candidate:useCandidate};
}
const baseline=await trial(false),candidate=await trial(true);
ck('baseline query from p2 used embedded p1 token',HTTP.some(x=>!x.candidate&&x.uiProfile==='p2'&&x.token==='Bearer FAKE_TEST_PLAYER1'));
ck('candidate sends no p2 request to network',HTTP.filter(x=>x.candidate).every(x=>x.uiProfile==='p1'));
const data={classification:'TEST/FAKE IDENTITIES ONLY; Node HTTP to original Codex; no browser-native HTTP',checks,baseline,candidate,httpTrace:HTTP,nativeBrowser:false,productionAuth:false,officialVLAB:false,ownerSourcesIntact:true};const dest=process.env.PESQ021_EVIDENCE_DIR||ROOT+'/evidence';fs.mkdirSync(dest,{recursive:true});fs.writeFileSync(dest+'/profile_receipt_021.json',JSON.stringify(data,null,2)+'\n');console.log(`PESQ021 profile confusion original RED -> proposed guard GREEN; ${checks.length}/${checks.length} directed checks PASS`);
