"""Independent browser DOM test: existing TEST40 journal retains scene context, but
original TEST40 app.js loses it upon cold page restore. No backend, no real network.
Candidate only modifies app.js string in memory; owners' files remain untouched."""
import json,re,hashlib,os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
DEV=ROOT/'dev40'/'public'; NATIVE=(ROOT/'dev40'/'connected_test'/'native_port.js').read_text();APP=(DEV/'app.js').read_text()
EV=Path(os.environ.get('PESQ021_EVIDENCE_DIR',str(ROOT/'evidence')));EV.mkdir(parents=True,exist_ok=True)
checks=[]
def ck(title,truth):
    if not truth:raise AssertionError(title)
    checks.append(title)
# Only neutralize origin gate within this scientific DOM harness. Browser fetch is mocked.
assert "const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&" in NATIVE
NATIVE=NATIVE.replace("const enabled=location.protocol==='http:' && location.hostname==='127.0.0.1' &&","const enabled=true &&")
# Candidate restores existing fields from the existing journal; no new outbox, storage or engine.
old_restore="authorityAttempt={id:e.payload.commandId,status:'UNKNOWN',code:'REOPENED',querying:false};"
new_restore="authorityAttempt={id:e.payload.commandId,origin:{sceneId:e.payload.sceneId,actorId:e.payload.actorId,targetId:e.payload.targetId,action:e.payload.action},status:'UNKNOWN',code:'REOPENED',querying:false};"
old_pending="const a={id,status:'PENDING',code:null,querying:false};authorityAttempt=a;"
new_pending="const a={id,origin:{sceneId:t.sceneId,actorId:u.id,targetId:target.id,action:'ATTACK_REQUEST'},status:'PENDING',code:null,querying:false};authorityAttempt=a;"
old_status="query.disabled=!available||!['UNKNOWN','NOT_FOUND'].includes(a.status);"
new_status="if(a.origin?.sceneId&&a.origin.sceneId!==workspace.active)out.textContent+=' RECIBO DA CENA '+a.origin.sceneId+' (cena atual '+workspace.active+'); não atribuir à cena atual.';\n "+old_status
old_render='renderTactical();for(const b of document.querySelectorAll(\'[data-mode]\'))'
new_render='renderTactical();paintAuthority();for(const b of document.querySelectorAll(\'[data-mode]\'))'
patch=APP
for a,b in [(old_restore,new_restore),(old_pending,new_pending),(old_status,new_status),(old_render,new_render)]:
    assert patch.count(a)==1,(a,patch.count(a))
    patch=patch.replace(a,b)
ck('candidate is in-memory only',patch!=APP and (DEV/'app.js').read_text()==APP)

def mount(p,script,raw=None):
    h=(DEV/'index.html').read_text();h=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',h).replace('<link rel="stylesheet" href="styles.css">','')
    for f in ('app.js','room-v2-adapter.js','room-client.js'):
        h=h.replace(f'<script src="{f}" defer></script>','')
    p.set_content(h)
    p.evaluate('''raw=>{
      const mem={};if(raw!==null)mem['assim-tabletop-room-pending-test']=raw;
      Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem:k=>Object.hasOwn(mem,k)?mem[k]:null,setItem:(k,v)=>mem[k]=String(v),removeItem:k=>delete mem[k]}});
      Object.defineProperty(window,"sessionStorage",{configurable:true,value:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});
      window.fetch=async (_p,opts)=>({ok:true,text:async()=>JSON.stringify({ok:true,receipt:{client_action_id:JSON.parse(opts.body).client_action_id,status:'REJECTED',code:'MECHANICS_UNAVAILABLE',revision:0,receipt_id:'SYNTHETIC_REOPEN_021'}})});
      window.PonteTEST={request:()=>{}};
    }''',raw)
    p.add_style_tag(content=(DEV/'styles.css').read_text())
    p.add_script_tag(content=script)
    for f in ('room-v2-adapter.js','room-client.js'):p.add_script_tag(content=(DEV/f).read_text())
    p.evaluate('''()=>{const c=window.TabletopRoomTEST.client;c.profile='p1';c.protocol='v2';c.connected=true;c.revision=0;
       let el=document.getElementById('bridgeResult');if(!el){el=document.createElement('p');el.id='bridgeResult';document.body.appendChild(el)}el.textContent='Cena visual TEST importada · SHA fixture';}''')
    p.add_script_tag(content=NATIVE)

def run(pw,script,raw,tag):
    b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    p=b.new_page(viewport={'width':390,'height':844});mount(p,script,raw)
    obj=p.evaluate('window.__tabletopTEST.authority()')
    before=p.locator('#tacticAuthorityState').inner_text()
    p.locator('#newScene').click()
    current=p.evaluate('window.__tabletopTEST.state().active')
    after_scene=p.locator('#tacticAuthorityState').inner_text()
    p.evaluate('window.__tabletopTEST.queryAuthorityReceipt()')
    p.wait_for_function('window.__tabletopTEST.authority()?.status==="REJECTED"')
    receipt=p.locator('#tacticAuthorityState').inner_text()
    t=p.locator('#tacticReadout').inner_text()
    res={'tag':tag,'restored':obj,'before':before,'new_scene':current,'after_scene':after_scene,'receipt_ui':receipt,'readout':t,'journal_after':p.evaluate('window.localStorage.getItem(window.TabletopRoomTEST.client.journalKey)'),'browser_network':'MOCKED_FETCH','status':p.evaluate('window.__tabletopTEST.authority()?.status')}
    p.screenshot(path=str(EV/f'{tag}.png'));p.close();b.close();return res

# Seed using the actual RoomClient reserveExternal method, not a synthetic fabricated journal.
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    p=b.new_page();mount(p,APP,None)
    x=p.evaluate('''()=>{const c=window.TabletopRoomTEST.client;const req={commandId:'atk21cold001',sceneId:'c1',actorId:'u1',targetId:'u3',action:'ATTACK_REQUEST'};
      if(!c.reserveExternal('p1',req))throw Error('original reserve failed '+JSON.stringify({journal:!!c.journalStore,err:c.journalError,pending:c.pending.size,external:c.externalPending,record:c.journalStore?.getItem(c.journalKey)}));
      return {raw:window.localStorage.getItem(c.journalKey),req,record:c.externalRecord()};}''')
    p.close();b.close()
    raw=x['raw'];j=json.loads(raw)
    ck('original journal persisted exact request',j['external']['payload']==x['req'])
    red=run(pw,APP,raw,'TEST40_REOPEN_ORIGIN_RED')
    green=run(pw,patch,raw,'TEST40_REOPEN_CONTEXT_CANDIDATE_GREEN')
ck('cold reopened original restores same command ID',red['restored']['id']=='atk21cold001' and red['status']=='REJECTED')
ck('original restored scene context absent',not red['restored'].get('origin'))
ck('original UI after scene switch omits scene origin',red['new_scene']!='c1' and 'c1' not in red['receipt_ui'])
ck('candidate recovers original metadata via journal',green['restored']['origin']=={'sceneId':'c1','actorId':'u1','targetId':'u3','action':'ATTACK_REQUEST'})
ck('candidate UI labels original scene and current scene', 'c1' in green['receipt_ui'] and green['new_scene'] in green['receipt_ui'])
ck('candidate maintains same id and rejects synthetic combat',green['restored']['id']==red['restored']['id'] and green['status']=='REJECTED' and 'MECHANICS_UNAVAILABLE' in green['receipt_ui'])
ck('resolved original journal does not automatically replay command','atk21cold001' not in green['journal_after'])
out={'classification':'TEST/SCIENTIFIC; frontend original source READ_ONLY; in-memory candidate NOT installed','passed':len(checks),'checks':checks,'baseline':red,'candidate':green,'source_hash':hashlib.sha256(APP.encode()).hexdigest(),'native_browser_http':False,'vlab_mechanical':False}
(EV/'cold_reopen_021.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(f'COLD REOPEN CONTEXT original RED -> candidate GREEN {len(checks)}/{len(checks)} PASS; original not altered; no network')
