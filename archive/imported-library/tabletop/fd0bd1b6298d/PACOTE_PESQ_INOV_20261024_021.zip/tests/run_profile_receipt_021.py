"""Run original Codex0.4 Authority only, in ephemeral SQLite, with Node audit client."""
import tempfile,threading,subprocess,os,json,sys,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'codex04/experiments/tabletop_vlab_bridge'))
from authority import Authority,make_server
with tempfile.TemporaryDirectory(prefix='pesq021-original-codex-') as td:
 d=Path(td);server=make_server(Authority(d/'db.sqlite'),0,arena_assets=True);threading.Thread(target=server.serve_forever,daemon=True).start()
 from urllib.request import Request,urlopen
 def call(token,body):
  u=f'http://127.0.0.1:{server.server_port}/bridge';data=json.dumps(body).encode();req=Request(u,data=data,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST')
  try:
   with urlopen(req,timeout=5) as r: return json.loads(r.read())
  except Exception as e:
   print("HTTP ERROR",str(e),getattr(e,"read",lambda:b"")().decode(errors="replace")[:1300],body);raise
 try:
  snap={'sceneId':'c1','n':7,'walls':[],'units':[{'id':'u1','name':'Exploradora TEST','mark':'E','team':'ally','ownerId':'p1','x':1,'y':1},{'id':'u2','name':'Conjurador TEST','mark':'C','team':'ally','ownerId':'p2','x':1,'y':3},{'id':'u3','name':'Criatura TEST','mark':'X','team':'enemy','ownerId':None,'x':5,'y':2}],'markers':[]}
  bindings={'u1':{'actor_id':'actor-1','viewers':['gm','p1']},'u2':{'actor_id':'actor-2','viewers':['gm','p2']},'u3':{'actor_id':'actor-m','viewers':['gm']}}
  b=call('FAKE_TEST_MASTER',{'schema_version':3,'op':'arena_bootstrap','room_id':'arena-test','snapshot':snap,'bindings':bindings,'provenance':{'source':'TEST38_EXPLICIT_VISUAL_IMPORT','frontend_sha256':'085fe620b26a590157702cc96b6f9e8d5cf0098cd552bb4d1023dbe0d31e9b4c'}})
  assert b['ok'],b
  i='atk21profile001'
  reply=call('FAKE_TEST_PLAYER1',{'schema_version':2,'op':'submit','room_id':'arena-test','client_action_id':i,'expected_revision':0,'actor_id':'actor-1','action':{'kind':'ATTACK_REQUEST','target':{'kind':'UNIT','actor_id':'actor-m'},'turn_id':'turn-test-1','context':{'scene_id':'scene-test-1','ability_id':'basic-attack'}}})
  assert reply['receipt']['status']=='REJECTED' and reply['receipt']['code']=='MECHANICS_UNAVAILABLE',reply
  other=call('FAKE_TEST_PLAYER2',{'schema_version':2,'op':'receipt_query','room_id':'arena-test','client_action_id':i})
  assert other.get('receipt') is None and other['lookup']=='NOT_FOUND',other
  inp=d/'id.json';inp.write_text(json.dumps({'id':i}))
  e={**os.environ,'PESQ021_TEST_URL':f'http://127.0.0.1:{server.server_port}/','PESQ021_RECEIPTS':str(inp)}
  p=subprocess.run(['node',str(ROOT/'tests/test_profile_receipt_021.mjs')],capture_output=True,text=True,env=e,timeout=35)
  print(p.stdout,p.stderr);assert p.returncode==0,p.stderr
  with sqlite3.connect(d/'db.sqlite') as db:
   num=db.execute('SELECT count(*) FROM receipts').fetchone()[0];events=db.execute('SELECT count(*) FROM events').fetchone()[0]
  assert (num,events)==(1,0),(num,events)
  result={'server':'original Codex0.4 Authority /bridge and SQLite, separate p1/p2 FAKE tokens','p2_authoritative_query':other,'p1_original_receipt':reply['receipt'],'receipts':num,'events':events,'node_stdout':p.stdout,'browser_native':False,'no_server_writes_outside_temporary_db':True}
  (Path(os.environ.get('PESQ021_EVIDENCE_DIR',str(ROOT/'evidence')))/'profile_authority_021.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
  print('PESQ021 AUTHORITY P1/P2 FAKE isolation verified; 1 original receipt, 0 combat events')
 finally:server.shutdown();server.server_close()
