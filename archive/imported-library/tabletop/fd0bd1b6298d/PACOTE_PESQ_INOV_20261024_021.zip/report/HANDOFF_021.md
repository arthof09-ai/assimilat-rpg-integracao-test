# PESQ-021 — TEST40 × Codex0.4 · handoff operacional MESTRE-SIDE

**Baseline VERIFICADA:** TEST40/RUN017 SHA `88cda222272436f1d30acae87852c6a27416118b514c56e4c0c3f10ff251fd8e`; PESQ020 SHA `c8ba30a17138e417fca1008224bb4a951ed3f7df948166edcc9168d531b16209`; Codex0.4 SHA `5d3155e25ab9b1a6fa07e85ef43e92cf42de16c12e0cae25e70d868556f31a4a` READ-ONLY. Notion `CP-INOV-AUDIT-R4-TEST40-PESQ020-20261024-001` lido; as falhas da PESQ020 já eram conhecidas e não foram contadas como novidades.

## Achado A — o cold-reopen perde metadados já persistidos

**Código original:** `public/room-client.js::reserveExternal/loadJournal/externalRecord` persiste `commandId`, `sceneId`, `actorId`, `targetId`, `action` na entrada `external` da mesma outbox/journal v1. `public/app.js`, ao receber `tabletop:connected-test-authority`, reconstrói a tentativa apenas como `{id,status,code,querying}`, descartando o contexto existente. Em `paintAuthority`, o recibo recuperado aparece sem atribuição inequívoca à cena de origem.

**Teste executado:** usando `RoomClient.reserveExternal` ORIGINAL, gerar journal de `c1,u1,u3,ATTACK_REQUEST,atk21cold001`; fechar página, carregar o mesmo journal em outro contexto Chromium, criar `c2`, consultar `MECHANICS_UNAVAILABLE` via `fetch` SIMULADO. **RED** do original: `REJECTED... ID atk21cold001`, sem `c1`. **GREEN candidato em memória:** lê os campos já validados do journal e exibe `RECIBO DA CENA c1 (cena atual c2)` sem duplicar outbox. **9/9 checagens científicas PASS**; correção **NÃO INSTALADA** pelo Desenvolvedor; o `tacticReadout` exige auditoria adicional antes do gate integral da UI.

**Handoff:** Desenvolvedor deve vincular origem na tentativa e na UI (incluindo `tacticReadout`), revalidar cena atual e receipt, e executar o canário no código realmente alterado, inclusive após fechamento/reabertura; não reaplicar ataque nem gravar Vida/PA/Alma.

## Achado B — perfil DEMO da UI não governa consulta/finalização do recibo

**Código original:** `connected_test/native_port.js::reserve/send` valida `client.profile==='p1'`, mas `query` e `finish` não repetem a guarda. Seu `fetch('/bridge')` sempre envia o token fixo **`FAKE_TEST_PLAYER1`**.

**Teste executado em original Codex0.4 HTTP/SQLite:** p1 possui 1 recibo legítimo `REJECTED/MECHANICS_UNAVAILABLE`; consulta com token p2 recebeu **NOT_FOUND**, mostrando isolamento correto no servidor sintético. Porém, com `client.profile='p2'` no `RoomClient` da UI, o `native_port.js` original consultou o recibo usando o token p1 embutido e **pôde limpar o journal p1** com `finish`. Isso é um **RED de inconsistência entre perfil exibido e credencial FAKE enviada**, não invasão Party ou falha de ACL na Authority.

**GREEN candidato em memória:** `query` e `finish` exigem `client.profile==='p1'`, sessão v2 conectada; alternar para p2 bloqueia consulta e finalização, preservando outbox. Retornar ao perfil p1 recupera o mesmo recibo e finaliza. **14/14 checagens científicas PASS**, 1 recibo/0 evento mecânico no SQLite. **Não representa autenticação real**, não resolve por si só identidade após `restore` e não foi instalado.

**Handoff:** Desenvolvedor deve impedir que alteração de perfil DEMO use credencial ou journal de outra identidade, inclusive `restore`, consulta e finalização, sem persistir segredo/token em storage exposto. Identidade de produção exige backend/servidor competente com credenciais reais; Codex 0.4 segue NO-WRITE enquanto seu executor está indisponível.

## Fronteira navegador e VLAB

**Navegação direta Chromium** ao TEST40 servido pela Authority foi ensaiada uma vez, mas retornou `net::ERR_BLOCKED_BY_ADMINISTRATOR`. **G4 HOLD**, independentemente de 23/23 testes científicos PASS. Não se tentou contornar política nem imputar HTTP Node como prova browser-native.

**VLAB oficial:** Notion `CONSULTA-INOV-VLAB-INTEROP-20261023-001` / IBX-176 consultado; é solicitação com estado `NOVA`, não ACK nem ABI mecânica homologada. Contrato mínimo PENDENTE com executor próprio: identidade/versão da batalha, ator/ação/alvo, turno/legalidade, recursos e decisão oficial, revisão, idempotência, efeitos aplicados e projeção Mestre/Party **antes da transmissão**. Sem fórmulas falsas; `MECHANICS_UNAVAILABLE` segue resposta legítima.

## Gates PESQ021

| Gate | Resultado independente |
|---|---|
| G1 cena | **RED** original no cold-reopen; **GREEN in-memory**, não instalado |
| G2 sala/perfil | Sala Codex isolada no teste; **RED** perfil UI/test token; **GREEN in-memory**, não instalado |
| G3 journal/ACK | Mesmo `commandId` recuperado e sem reenvio em DOM; contexto ainda RED na fonte |
| G4 Chromium HTTP nativo | **HOLD** bloqueio administrativo (`Page.goto`) |
| G5 sigilo | Servidor FAKE p2 `NOT_FOUND` e p1 com recibo correto; produção **HOLD** |
| G6 VLAB oficial | **HOLD** (sem ABI/decisão homologada) |

**LAST-VERIFIED-UNIT:** canários RED/GREEN sobre TEST40 original e Codex0.4 original, manifests e Library readback. **FIRST-PENDING:** correção física do vínculo cena/perfil pelo Desenvolvedor na sua árvore, e G4 em navegador legítimo. **NEXT:** confrontar próxima versão Dev com estes mesmos canários (evitar criação de outro laboratório/motor) e depois gate VLAB homologado. **NO-REPEAT:** PESQ012–020 e R4/83 checks, Codex histórico, pesquisas de vídeo, recibos e motor paralelos.
