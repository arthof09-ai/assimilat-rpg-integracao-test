#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PESQ021_EVIDENCE_DIR="$PWD/runtime_evidence"
mkdir -p "$PESQ021_EVIDENCE_DIR"
python prepare_sources.py "${1:-/mnt/data/PESQ021_sources}"
python tests/test_reopen_context_021.py
python tests/run_profile_receipt_021.py
python verify_manifest.py
