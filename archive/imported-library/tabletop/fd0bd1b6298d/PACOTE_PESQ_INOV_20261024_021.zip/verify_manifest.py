import json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
x=json.loads((r/'MANIFEST_SHA256.json').read_text())
for name,item in x['files'].items():
    b=(r/name).read_bytes()
    assert len(b)==item['size'] and hashlib.sha256(b).hexdigest()==item['sha256'],name
print(f'MANIFEST {len(x["files"])}/{len(x["files"])} PASS')
