# PESQ-INOV-20261024-021 — Pesquisa incremental do Tabletop Assimilação

**MESTRE-SIDE, TEST independente, OP PESQUISA EXISTENTE.** Sem mudanças no código original do Desenvolvedor, Codex, VLAB, Party, O Primeiro ou GitHub.

**Antes → depois:** a PESQ020 detectara duas falhas de contexto. A PESQ021 demonstrou um aspecto novo do TEST40: *o journal preserva a origem mas o HUD a perde após cold-reopen*; e detectou que *um perfil p2 da interface DEMO pode consultar/finalizar o recibo p1 porque o token da extensão é fixo*. Guardas candidatas foram testadas só em memória, sem promover a backend/implementação oficial.

## Reprodução

São necessários Python 3, Node 22+, Chromium e Playwright Python instalados. Disponibilizar separadamente numa pasta privada, sem republicar, os três ZIPs originais nomeados a seguir:

- `PACOTE_TECNICO_TABLETOP_TEST39_A_TEST40_20261024.zip`
- `ponte-vlab-tabletop-0.4.0-test38.zip`
- `PACOTE_PESQ_INOV_20261024_020.zip`

Rodar `bash run_all.sh /CAMINHO/ZIPs`.

O comando verifica SHA256+CRC, extrai cópias isoladas e executa:

1. `tests/test_reopen_context_021.py`: JS TEST40 original no **Chromium DOM** com fetch simulado; original RED e candidato GREEN; **9/9** checagens.
2. `tests/run_profile_receipt_021.py`: **Codex0.4 Authority original + SQLite temporário + HTTP Node** e o `native_port.js` original, com p1/p2 FAKE; original RED e candidato GREEN; **14/14** checagens.

**23/23 verificações científicas PASS ≠ 23 funções produtivas.** Resultados e screenshots estáticos em `evidence/`; resultados da reexecução em `runtime_evidence/`. `patches/` inclui diffs **NÃO APLICADOS**, apenas handoff ao proprietário. `verify_manifest.py` confere SHA de todos os artefatos estáticos empacotados. ZIPs de fontes originais ficam fora deste pacote.

**Limites:** Chromium navegador→Authority bloqueado pelo ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`), G4 HOLD. Identidades são FAKE, não autenticação. Sem ataque ou consumo VLAB. Sem serialização de dados canônicos de RPG. Para implicações e gates consultar `report/HANDOFF_021.md`.
