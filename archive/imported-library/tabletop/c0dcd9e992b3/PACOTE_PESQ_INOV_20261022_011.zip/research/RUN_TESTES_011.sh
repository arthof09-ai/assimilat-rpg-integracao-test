#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
node "$HERE/test_party_projection_011.js"
node "$HERE/test_projection_mutants_011.js"
node "$HERE/test_acceptance_contract_011.js"
node "$HERE/test_handoff_guard_011.js"
