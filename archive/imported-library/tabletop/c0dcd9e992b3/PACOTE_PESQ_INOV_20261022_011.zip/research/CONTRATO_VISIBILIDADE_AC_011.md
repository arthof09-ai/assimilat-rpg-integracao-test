# D-INOV-032 — Política A+C (DECISÃO DO MESTRE; contrato de pesquisa)

**A — interface Mestre:** manter marcadores administrativos visíveis independentemente de FOV visual. Não retirar recursos já existentes.

**C — futura interface Party:** um serviço em ambiente confiável verifica identidade/consentimento e monta *projeção por allowlist* ANTES de transmitir ou exportar. A Party nunca recebe o estado Mestre integral para depois escondê-lo via CSS, FOV ou JavaScript do cliente.

## Contrato sintético mínimo, sem integração real

Input de serviço: `workspaceMestre` (não publicável), `grant` produzido pela autorização competente (não pelo browser da Party). A função `projectAllowedMarkers(workspaceMestre, grant)` é apenas filtragem determinística, **NÃO autenticação**. A saída contém apenas `schema`, `scenes[] { id,n, markers[] { id,x,y,kind,text } }`. Sem logs, notas administrativas, unidades, FOV, replay, recursos, IDs internos de bancos ou arquivos VLAB.

Política fechada: scene e marcador exigem autorização explícita por par `sceneId:markerId` (IDs de marcador podem se repetir entre cenas); se o grant estiver ausente/malformado, **não produzir payload**; desconhecidos não são publicados; validação rejeita duplicatas, texto de controle, HTML e coordenadas fora da grade. Mudança de grant exige calcular projeção nova e invalidar cache de projeção anterior. O cliente só desenha texto como texto, nunca HTML.

## Testes antes de implementar futuramente

1. Criação da cena e revogação; dois viewers com permissões diferentes.
2. Arrays com IDs diferentes mas mesma posição; mudanças de cena e backup.
3. Campos secretos aninhados e extras inesperados; HTML, `__proto__`, Unicode e payloads grandes.
4. Grants fabricados por browser nunca são aceitos por backend; token/ACL autorizado não é substituído por bool no JSON.
5. Captura de rede e exportação Party não contêm nenhum canário Mestre; testar antes/depois de refresh, FOV, zoom, duas abas e importação.

**Limite:** prova Node sintética 21/21 +1.500/1.500 +6/6 mutações testou apenas a função de filtro; não autentica usuário, não estabelece ACL, não cria API pública, não testa transporte nem dá autorização para criar Party.
