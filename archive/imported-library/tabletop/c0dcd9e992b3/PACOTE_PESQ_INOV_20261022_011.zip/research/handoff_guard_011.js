'use strict';
const fs=require('node:fs');const crypto=require('node:crypto');
const SHA=/^[a-f0-9]{64}$/;
const FENCE=['sourceFile','sourceSha256','baseline','lastVerified','firstPending','next','noRepeat','authority','prohibitions'];
function validateHandoff(handoff,fsApi=fs){
 if(!handoff||typeof handoff!=='object'||Array.isArray(handoff))return {ok:false,reason:'INVALID_OBJECT'};
 for(const k of FENCE)if(!(k in handoff))return {ok:false,reason:'MISSING_'+k};
 if(typeof handoff.sourceFile!=='string'||!SHA.test(handoff.sourceSha256))return {ok:false,reason:'INVALID_SOURCE'};
 if(!/^TEST\d+$/.test(handoff.baseline))return {ok:false,reason:'INVALID_BASELINE'};
 if(!Array.isArray(handoff.noRepeat)||!Array.isArray(handoff.prohibitions)||handoff.noRepeat.length===0||handoff.prohibitions.length===0)return {ok:false,reason:'MISSING_LIMITS'};
 if(typeof handoff.lastVerified!=='string'||typeof handoff.firstPending!=='string'||typeof handoff.next!=='string'||!handoff.authority||!handoff.firstPending.trim()||!handoff.next.trim())return {ok:false,reason:'EMPTY_CRITICAL_FIELD'};
 if(handoff.noRepeat.includes(handoff.firstPending))return {ok:false,reason:'DUPLICATE_COMPLETED_TASK'};
 let bytes;try{bytes=fsApi.readFileSync(handoff.sourceFile)}catch{return {ok:false,reason:'BYTES_UNAVAILABLE'}}
 const actual=crypto.createHash('sha256').update(bytes).digest('hex');
 return actual===handoff.sourceSha256?{ok:true,sha256:actual,baseline:handoff.baseline}:{ok:false,reason:'HASH_MISMATCH',actual};
}
module.exports={validateHandoff};
