'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const os=require('node:os');const crypto=require('node:crypto');const {validateHandoff}=require('./handoff_guard_011');
let pass=0;const dir=fs.mkdtempSync(path.join(os.tmpdir(),'handoff011-'));
const app=path.join(dir,'app.js'),alt=path.join(dir,'other.js');fs.writeFileSync(app,'const x=32;\n');fs.writeFileSync(alt,'const x=33;\n');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const base=()=>({sourceFile:app,sourceSha256:sha(app),baseline:'TEST33',lastVerified:'TEST33 independent audit',firstPending:'party projection test',next:'audit approved scope',noRepeat:['noop redo recheck'],authority:'research sandbox',prohibitions:['no official write','no party data']});
function t(name,fn){try{fn();pass++}catch(e){console.error('FAIL',name,e);process.exitCode=1}}
t('valid physical checkpoint',()=>assert.equal(validateHandoff(base()).ok,true));
t('detect wrong file bytes',()=>{const h=base();h.sourceFile=alt;assert.equal(validateHandoff(h).reason,'HASH_MISMATCH')});
t('detect truncated hash',()=>{const h=base();h.sourceSha256=h.sourceSha256.slice(0,8);assert.equal(validateHandoff(h).reason,'INVALID_SOURCE')});
t('detect missing LAST',()=>{const h=base();delete h.lastVerified;assert.equal(validateHandoff(h).reason,'MISSING_lastVerified')});
t('detect missing NEXT',()=>{const h=base();delete h.next;assert.equal(validateHandoff(h).reason,'MISSING_next')});
t('detect missing limits',()=>{const h=base();h.prohibitions=[];assert.equal(validateHandoff(h).reason,'MISSING_LIMITS')});
t('detect repeated closed task',()=>{const h=base();h.firstPending=h.noRepeat[0];assert.equal(validateHandoff(h).reason,'DUPLICATE_COMPLETED_TASK')});
t('detect absent file',()=>{const h=base();h.sourceFile='/not/here';assert.equal(validateHandoff(h).reason,'BYTES_UNAVAILABLE')});
t('detect wrong baseline field',()=>{const h=base();h.baseline='RUN010';assert.equal(validateHandoff(h).reason,'INVALID_BASELINE')});
t('detect missing authority',()=>{const h=base();delete h.authority;assert.equal(validateHandoff(h).reason,'MISSING_authority')});
t('detect bad body',()=>assert.equal(validateHandoff(null).reason,'INVALID_OBJECT'));
t('normalization no irrelevant file mutation',()=>{const h=base();validateHandoff(h);assert.equal(fs.readFileSync(app,'utf8'),'const x=32;\n')});
const REAL=process.env.TABLETOP_TEST33_APP;
if(REAL&&fs.existsSync(REAL)){
 t('verify TEST33 real JS bytes',()=>{const h=base();h.sourceFile=REAL;h.sourceSha256='7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4';assert.equal(validateHandoff(h).ok,true)});
 t('reject TEST32 hash against TEST33 bytes',()=>{const h=base();h.sourceFile=REAL;h.sourceSha256='758a16a29d0ae8c584ab62956351761dba846e640518543bc3fb30a898d86c2a';assert.equal(validateHandoff(h).reason,'HASH_MISMATCH')});
}
fs.rmSync(dir,{recursive:true,force:true});console.log(JSON.stringify({passed:pass,realSourceChecked:Boolean(REAL&&fs.existsSync(REAL)),writesToSource:0}));
