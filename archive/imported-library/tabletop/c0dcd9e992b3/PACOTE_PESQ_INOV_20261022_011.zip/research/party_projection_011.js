'use strict';
// PESQ-011: NOT a Party interface. Research-only pure projection of fabricated data.
// Caller must be a trusted, authorized service; passing a policy object is NOT authentication.
const ID=/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;
const KINDS=new Set(['pin','note','highlight']);
function validId(s){return typeof s==='string'&&ID.test(s)&&!['__proto__','constructor','prototype'].includes(s);}
function validateText(s){return typeof s==='string'&&s.length>0&&s.length<=100&&!/[<>\x00-\x1F\x7F]/.test(s);}
function own(o,k){return Object.prototype.hasOwnProperty.call(o,k);}
function ordinary(o){return o!==null && typeof o==='object' && !Array.isArray(o) && (Object.getPrototypeOf(o)===Object.prototype||Object.getPrototypeOf(o)===null);}
function allowedInteger(x,n){return Number.isSafeInteger(x)&&x>=0&&x<n;}
// This function explicitly omits admin notes, token info, fog, attacks, resources, logs, private metadata.
function projectAllowedMarkers(master, grants){
  if(!ordinary(master)||!Array.isArray(master.scenes)||!ordinary(grants)||!Array.isArray(grants.sceneIds)||!Array.isArray(grants.markerKeys))throw Error('CONTRACT_INVALID');
  if(master.scenes.length>50||grants.sceneIds.length>50||grants.markerKeys.length>2000)throw Error('LIMIT_EXCEEDED');
  const scenes=new Set(grants.sceneIds), ids=new Set(grants.markerKeys);
  if(scenes.size!==grants.sceneIds.length||ids.size!==grants.markerKeys.length||![...scenes].every(validId)||![...ids].every(k=>typeof k==='string'&&/^([A-Za-z0-9][A-Za-z0-9_-]{0,63}):([A-Za-z0-9][A-Za-z0-9_-]{0,63})$/.test(k)&&k.split(':').every(validId)))throw Error('GRANT_INVALID');
  const out=[];const seenScenes=new Set(),seenMarkers=new Set();
  for(const scene of master.scenes){
    if(!ordinary(scene)||!validId(scene.id)||seenScenes.has(scene.id)||!Number.isSafeInteger(scene.n)||scene.n<1||scene.n>100||!Array.isArray(scene.markers)||scene.markers.length>500)throw Error('SOURCE_INVALID');
    seenScenes.add(scene.id);
    if(!scenes.has(scene.id))continue;
    const marks=[];
    for(const marker of scene.markers){
      if(!ordinary(marker)||!validId(marker.id)||seenMarkers.has(scene.id+':'+marker.id)||!allowedInteger(marker.x,scene.n)||!allowedInteger(marker.y,scene.n)||!KINDS.has(marker.kind)||!validateText(marker.text))throw Error('SOURCE_INVALID');
      seenMarkers.add(scene.id+':'+marker.id);
      if(ids.has(scene.id+':'+marker.id))marks.push({id:marker.id,x:marker.x,y:marker.y,kind:marker.kind,text:marker.text});
    }
    out.push({id:scene.id,n:scene.n,markers:marks});
  }
  return {schema:'PESQ011-SYNTHETIC-PARTY-PROJECTION-V1',scenes:out};
}
function canonicalJson(x){return JSON.stringify(x);}
module.exports={projectAllowedMarkers,canonicalJson};
