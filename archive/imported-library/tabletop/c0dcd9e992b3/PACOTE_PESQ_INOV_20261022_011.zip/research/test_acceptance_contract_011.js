'use strict';
// Controlled research fixture: the SAME synthetic input is evaluated by vague and explicit contracts.
// NOT a comparison of language models and NOT developer product code.
const assert=require('node:assert/strict');const {projectAllowedMarkers}=require('./party_projection_011');
const master=()=>({scenes:[{id:'sceneA',n:7,notes:'MASTER_NOTE_Q',markers:[{id:'share',x:2,y:2,kind:'pin',text:'Porta',adminMeta:'MASTER_META_Q'},{id:'private',x:5,y:5,kind:'note',text:'Inimigo secreto'}]},{id:'sceneB',n:7,notes:'NO_ACCESS_SCENE',markers:[{id:'other',x:3,y:3,kind:'pin',text:'Reforço secreto'}]}]});
const grants=()=>({sceneIds:['sceneA'],markerKeys:['sceneA:share']});
// Intentionally unsafe implementation for evaluating acceptance criteria, not a recommended solution.
const demoBroad=(s,g)=>({schema:'EXAMPLE',scenes:s.scenes.map(sc=>({...sc,markers:sc.markers.filter(m=>g.markerKeys.includes(sc.id+':'+m.id))}))});
const candidates={demoBroad,contractAllowlist:(s,g)=>projectAllowedMarkers(s,g)};
const suites={
 vague:[['returns any scene array',(impl)=>Array.isArray(impl(master(),grants()).scenes)]],
 explicit:[
 ['one granted scene',(impl)=>impl(master(),grants()).scenes.length===1],
 ['one granted marker',(impl)=>impl(master(),grants()).scenes[0].markers.length===1],
 ['no master field',(impl)=>!JSON.stringify(impl(master(),grants())).includes('MASTER_NOTE_Q')],
 ['no extra marker field',(impl)=>!JSON.stringify(impl(master(),grants())).includes('MASTER_META_Q')],
 ['scene revocation',(impl)=>impl(master(),{sceneIds:[],markerKeys:['sceneA:share']}).scenes.length===0]
 ]};
const result={};for(const [k,impl] of Object.entries(candidates)){result[k]={};for(const [suite,tests] of Object.entries(suites)){const outcomes=tests.map(([name,test])=>({name,pass:Boolean(test(impl))}));result[k][suite]={pass:outcomes.filter(x=>x.pass).length,total:outcomes.length,checks:outcomes}}}
assert.equal(result.demoBroad.vague.pass,1);assert.equal(result.contractAllowlist.vague.pass,1);assert.equal(result.contractAllowlist.explicit.pass,5);assert.equal(result.demoBroad.explicit.pass,1);console.log(JSON.stringify({result,analysis:'Comparison of test contracts on intentionally different synthetic implementations; NOT proof of model performance.'},null,2));
