# Tabletop Assimilação — proposta de AGENTS.md enxuto (NÃO PUBLICADO)

Escopo: suporte para **cópia TEST** do Tabletop sintético. A autoridade permanece no Mestre, nas normas vigentes do Notion, no Coordenador e no Desenvolvedor autorizado. Este arquivo não é uma norma, um novo Diário ou um lease de escrita.

1. Antes de editar, identificar RUN/TEST, fonte física e SHA-256; não supor que a branch publicada é a versão candidata.
2. Alterar somente arquivos TEST autorizados para a tarefa; nunca tocar VLAB, LEVEL-UP, DMG, CRAFT, Party, O Primeiro ou GitHub Pages por iniciativa própria.
3. Preservar formatos antigos de save/replay; normalizar coordenadas com plano de migração sem perda e bloquear ambiguidades.
4. Operação sem alteração material não muda revision, histórico Refazer ou armazenamento. Alteração real precisa passar undo/redo.
5. FOV é visual. Marcadores administrativos ficam visíveis ao Mestre (decisão A); Party futura só recebe dados filtrados em serviço autorizado antes do envio (decisão C). CSS não é confidencialidade.
6. Antes de criar motor/módulo/cópia de regra, verificar função e contrato existentes; o Tabletop não executa mecânica oficial do VLAB.
7. Executar o menor teste dirigido que cubra o novo comportamento, adversarial e legado; relatar RED original, GREEN de cópia, denominador e limitações.
8. Guardar resultado no Diário/Notion já existentes com LAST-VERIFIED-UNIT, FIRST-PENDING, NEXT, NO-REPEAT, fonte/hash e gate NAC-PASS proporcional, quando competente.

Fonte de verdade normativa: BOOTSTRAP-COMESTRE, NAC-CONT-03, NAC-NORM-01, NAC-PASS-02, LONG-RUN-01, REG-ROUTE-03 no workspace Mestre. **Não copie regras integrais neste arquivo nem o publique sem coordenação/autoridade**.
