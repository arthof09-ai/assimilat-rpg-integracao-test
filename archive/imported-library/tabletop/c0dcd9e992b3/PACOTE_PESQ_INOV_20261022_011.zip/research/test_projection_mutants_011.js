'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'proj011mut-'));
const original=fs.readFileSync(path.join(__dirname,'party_projection_011.js'),'utf8');
fs.copyFileSync(path.join(__dirname,'test_party_projection_011.js'),path.join(dir,'test_party_projection_011.js'));
const muts=[
 ['leak marker private fields','marks.push({id:marker.id,x:marker.x,y:marker.y,kind:marker.kind,text:marker.text});','marks.push({...marker});'],
 ['allow scene never granted','if(!scenes.has(scene.id))continue;','if(false)continue;'],
 ['allow marker without explicit grant',"if(ids.has(scene.id+':'+marker.id))marks.push",'if(true)marks.push'],
 ['return forbidden scene notes','out.push({id:scene.id,n:scene.n,markers:marks});','out.push({id:scene.id,n:scene.n,markers:marks,notes:scene.notes});'],
 ['skip label validation','!validateText(marker.text)','false'],
 ['skip coordinate upper bound','!allowedInteger(marker.x,scene.n)||!allowedInteger(marker.y,scene.n)','false']
];let killed=0;
for(const [name,from,to] of muts){assert(original.includes(from),'missing mutation anchor '+name);const mutated=original.replace(from,to);fs.writeFileSync(path.join(dir,'party_projection_011.js'),mutated);const r=cp.spawnSync(process.execPath,[path.join(dir,'test_party_projection_011.js')],{encoding:'utf8',timeout:10000});const detected=r.status!==0;if(detected)killed++;console.log(JSON.stringify({name,detected,exit:r.status,error:(r.stderr??'').split('\n')[0]?.slice(0,200)}));}
fs.rmSync(dir,{recursive:true,force:true});console.log(JSON.stringify({mutants:muts.length,killed,sourceModified:false,productModified:false}));if(killed!==muts.length)process.exitCode=1;
