'use strict';
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {projectAllowedMarkers,canonicalJson}=require('./party_projection_011');
let directed=0,generated=0;
function expect(name,fn){try{fn();directed++}catch(e){console.error('FAIL',name,e.message);process.exitCode=1;}}
const fixture=()=>({revision:9,masterOnlyNotes:'DRAGON_SECRET_987',logs:['ADMIN_ONLY'],resourceLedger:{pa:9999},scenes:[
 {id:'c1',n:20,notes:'MASTER_EXCLUSIVE_01',fog:{hidden:'YES'},units:[{id:'SECRET_ENEMY'}],markers:[{id:'m1',x:2,y:3,kind:'pin',text:'Ponto público',adminData:'MASTER_ONLY_A1'},{id:'m2',x:4,y:7,kind:'note',text:'Marcador reservado',owner:'MASTER_ONLY_A2'}]},
 {id:'c2',n:7,notes:'REVEAL_NO',markers:[{id:'m3',x:1,y:1,kind:'highlight',text:'Ponto 2',adminData:'MASTER_ONLY_A3'}]}
]});
const grant=()=>({sceneIds:['c1'],markerKeys:['c1:m1']});
function throws(f){assert.throws(f);}
expect('only allowed marker emitted',()=>{let r=projectAllowedMarkers(fixture(),grant());assert.equal(r.scenes.length,1);assert.equal(r.scenes[0].markers.length,1);assert.equal(r.scenes[0].markers[0].id,'m1');});
expect('default deny',()=>{let r=projectAllowedMarkers(fixture(),{sceneIds:[],markerKeys:[]});assert.deepEqual(r.scenes,[]);});
expect('no secret strings in output',()=>{let s=canonicalJson(projectAllowedMarkers(fixture(),grant()));for(const secret of ['DRAGON_SECRET_987','MASTER_EXCLUSIVE_01','MASTER_ONLY_A1','SECRET_ENEMY','MASTER_ONLY_A2','REVEAL_NO'])assert.equal(s.includes(secret),false);});
expect('explicit scene grant needed',()=>{let r=projectAllowedMarkers(fixture(),{sceneIds:[],markerKeys:['c1:m1']});assert.equal(r.scenes.length,0);});
expect('explicit marker grant needed',()=>{let r=projectAllowedMarkers(fixture(),{sceneIds:['c1'],markerKeys:[]});assert.deepEqual(r.scenes[0].markers,[]);});
expect('known safe marker',()=>assert.equal(projectAllowedMarkers(fixture(),grant()).scenes[0].markers[0].text,'Ponto público'));
expect('scene-scoped grants prevent cross-scene ID collision',()=>{const w=fixture();w.scenes[1].markers[0].id='m1';const r=projectAllowedMarkers(w,{sceneIds:['c1','c2'],markerKeys:['c1:m1']});assert.equal(r.scenes[0].markers.length,1);assert.equal(r.scenes[1].markers.length,0);});
expect('source immutability',()=>{let v=fixture();let before=canonicalJson(v);projectAllowedMarkers(v,grant());assert.equal(canonicalJson(v),before);});
expect('no marker coords outside grid',()=>{let w=fixture();w.scenes[0].markers[0].x=20;throws(()=>projectAllowedMarkers(w,grant()));});
expect('duplicates semantic ids rejected',()=>{let w=fixture();w.scenes[0].markers.push({...w.scenes[0].markers[0]});throws(()=>projectAllowedMarkers(w,grant()));});
expect('duplicate grants rejected',()=>throws(()=>projectAllowedMarkers(fixture(),{sceneIds:['c1','c1'],markerKeys:['c1:m1']})));
expect('no prototype ids',()=>throws(()=>projectAllowedMarkers(fixture(),{sceneIds:['__proto__'],markerKeys:['c1:m1']})));
expect('forbid HTML in shared text',()=>{let w=fixture();w.scenes[0].markers[0].text='<script>';throws(()=>projectAllowedMarkers(w,grant()));});
expect('forbid controls in shared text',()=>{let w=fixture();w.scenes[0].markers[0].text='ok\nSECRET';throws(()=>projectAllowedMarkers(w,grant()));});
expect('unknown attrs never passed',()=>{let w=fixture();w.scenes[0].markers[0].nested={secret:'MASTER_ONLY_A4'};let s=canonicalJson(projectAllowedMarkers(w,grant()));assert.equal(s.includes('MASTER_ONLY_A4'),false);});
expect('revocation',()=>{let w=fixture();let g=grant();assert.equal(projectAllowedMarkers(w,g).scenes[0].markers.length,1);g.markerKeys=[];assert.equal(projectAllowedMarkers(w,g).scenes[0].markers.length,0);});
expect('scene isolation',()=>{let w=fixture();let r=projectAllowedMarkers(w,{sceneIds:['c2'],markerKeys:['c2:m3','c1:m1']});assert.equal(r.scenes.length,1);assert.equal(r.scenes[0].markers[0].id,'m3');});
expect('error on malformed source',()=>throws(()=>projectAllowedMarkers({scenes:[{id:'c1',n:7,markers:[null]}]},{sceneIds:['c1'],markerKeys:[]})));
expect('non-object policy denied',()=>throws(()=>projectAllowedMarkers(fixture(),null)));
expect('share only allowlist',()=>{let r=projectAllowedMarkers(fixture(),grant());assert.deepEqual(Object.keys(r.scenes[0].markers[0]),['id','x','y','kind','text']);});
expect('encoded JSON round trip',()=>{let r=projectAllowedMarkers(fixture(),grant());assert.deepEqual(JSON.parse(canonicalJson(r)),r);});
// Seeded property probes, distinct from directed tests.
let seed=20261022;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
for(let i=0;i<1500;i++){
 const w=fixture(),g=grant(),m=w.scenes[0].markers[0];
 const x=Math.floor(rand()*40)-5,y=Math.floor(rand()*40)-5;
 m.x=x;m.y=y;m.extra={onlyMaster:'NO_SHARE_'+i};
 const valid=x>=0&&x<20&&y>=0&&y<20;
 try{const r=projectAllowedMarkers(w,g);assert.equal(valid,true);const out=canonicalJson(r);assert.equal(out.includes('NO_SHARE_'+i),false);assert.equal(out.includes('MASTER_ONLY_A1'),false);}
 catch(e){if(valid){console.error('GENERATED_FAIL',i,x,y,e.message);process.exitCode=1;break;}assert.match(e.message,/SOURCE_INVALID/);}
 generated++;
}
console.log(JSON.stringify({directedPassed:directed,generatedPassed:generated,total:directed+generated,seed:20261022,source:'fabricated',auth:'NOT_AUTHENTICATED',productIntegrated:false},null,2));
