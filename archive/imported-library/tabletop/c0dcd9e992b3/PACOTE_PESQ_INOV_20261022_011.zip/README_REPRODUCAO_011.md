# PESQ-INOV-20261022-011 — reprodução independente

Conteúdo **autoral/sintético** do Terceiro Comestre Inovador Pesquisador; NÃO é versão do Tabletop nem do VLAB. Nenhum texto integral de transcrição ou código de terceiros foi redistribuído. Sem projetos comerciais/ativos protegidos. As fontes originais TEST33 devem ser obtidas separadamente no workspace Mestre por executor autorizado.

## Pré-requisitos

- Node.js 22 ou compatível; nenhuma dependência npm instalada/necessária.
- Opcional: variável `TABLETOP_TEST33_APP` apontando para uma cópia isolada AUTÊNTICA do `app.js` extraído de `TABLETOP_SITE_SINTETICO_TEST33_CANDIDATE.zip`. SHA-256 esperado: `7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4`. Não inclua fonte oficial no ZIP público científico.

## Comandos

```bash
unzip PACOTE_PESQ_INOV_20261022_011.zip -d pesq011
cd pesq011
bash research/RUN_TESTES_011.sh
# Para confirmar também os dois testes de proveniência sobre a fonte real:
TABLETOP_TEST33_APP=/caminho/isolado/app.js bash research/RUN_TESTES_011.sh
```

### Denominadores independentes

- 21/21 testes dirigidos + 1.500/1.500 probes gerados (seed 20261022): contrato de projeção Mestre→Party sintético, **NÃO implementação real de autorização**.
- 6/6 mutantes INTENCIONAIS detectados em cópias de código de pesquisa, não no programa do Desenvolvedor.
- Teste de aceitação: mesmo input, requisito vago 1/1 em dois exemplos, contrato explícito 1/5 no exemplo deliberadamente inseguro e 5/5 no exemplo allowlist; NÃO comparação de modelos LLM.
- Handoff: 12/12 casos sintéticos e mais 2/2 verificações de SHA com a fonte TEST33 real, quando a variável for fornecida; total observado no estudo 14/14.

## Fontes externas

Video metadata/transcription via conexão vidIQ nesta pesquisa. Os cinco transcripts não estão neste pacote: apenas análises e tabela de acesso. O link completo Rentry do Maurii não pôde ser obtido, não declarar análise do texto integral. `AGENTS.md` real do GitHub do projeto já existe em main, não criar duplicata ou editar sem competência.

## Segurança e autorização

`research/party_projection_011.js` recebe um objeto de permissões no TEST como se uma fonte confiável o tivesse produzido, mas **não autentica origem, sessão, identidade, transporte ou ACL**. Nunca colocar a lógica de autorização somente no cliente Party. Dados Mestre-only não devem ser transmitidos ao cliente não autorizado. Não publica Party, GitHub Pages ou regra do RPG.

## Integridade

`MANIFEST_SHA256_PESQ011.json` registra SHA-256 e tamanho de cada arquivo não-manifestado; validar hashes e CRC do ZIP após transferência e comparar arquivo recuperado do armazenamento persistente. Relatório central: `research/RELATORIO_PESQ_INOV_20261022_011.md`.
