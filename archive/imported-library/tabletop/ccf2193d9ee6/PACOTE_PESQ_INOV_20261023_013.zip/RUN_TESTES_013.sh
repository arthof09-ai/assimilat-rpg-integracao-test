#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p results
python research/audit_three_browser_real_ws_013.py
python research/audit_wss_loopback_013.py
python research/audit_commit_unknown_013.py 2>results/FAULT_EXPECTED_EXCEPTIONS.log
python research/audit_nested_projection_013.py
python research/audit_auth_edges_013.py
python research/audit_frame_limits_013.py
python research/quota_model_013.py >results/QUOTA_MODEL_STDOUT.log
printf '\nPESQ013 suites finished. Consult results/*.json and README.\n'
