# PESQ-013 — Contrato técnico mínimo de sala v2 (PROPOSTO / TEST)

**Papel:** contrato de transporte e segurança para o Desenvolvedor do Tabletop existente. Não é uma nova implementação de backend, engine ou VLAB. Decisão D-INOV-032 A+C permanece vigente. D-INOV-033 continua PROPOSTO, sem ACK.

## Objetivo e dados imutáveis

- Uma sala por autoridade durável. Um comando é uma **intenção** com `commandId` único, `roomId`, `schemaVersion`, `baseRevision` e, se aplicável, `unitId` declarado. O servidor **NÃO confia** em `actor`, `role`, `owner` ou dano que venham no JSON do cliente.
- Identidade e unidade controlável derivam de sessão autenticada no **servidor**; convites temporários vinculados a `roomId:participantId:role:ownedUnitIds`, expiração, limitação e revogação. Uma conexão de teste com token compartilhado **NÃO equivale** a autenticação real.
- Duas revisões separadas quando necessário: `publicRevision` para estado compartilhado e `adminRevision` para dados Mestre-only. Eventos de sessão pertencem à sala; revisão mecânica futura deve vir de recibo homologado do VLAB, nunca de heurística da interface.
- Estado, recibo de comando e evento público/projetável são persistidos **atomicamente** antes de transmitir confirmação `ACCEPTED`. Nenhum envio de dados privados a canais das players, inclusive por `lastEvent`, `markers`, replay, histórico, mensagens de erro ou logs.
- Interface atual HTML/CSS/JS/SVG permanece responsável somente por interação e apresentação. VLAB continua única autoridade de Vida, Alma, PA, defesa, magias, ataques, transformações e mecânicas canônicas. Até integração homologada, `MECHANICS_HOLD` é obrigatório.

## Envelopes JSON propostos

Exemplos **totalmente sintéticos**, sem ficha real, segredo ou conexão oficial:

```json
{"v":2,"type":"JOIN","roomId":"arena-test","ticket":"<ephemeral-test-ticket>"}
```

`ticket` deve ser avaliado no serviço confiável; não incluir token real em URL, GitHub Pages ou logs. Preferir emissão de convite de uso único pelo Mestre autenticado, com expiração e estado hashado. Validar origem do WS e limitar conexões antes de aceitar quando possível; `Origin` não substitui autenticação.

```json
{"v":2,"type":"WELCOME","roomId":"arena-test","participantId":"synthetic-p1","role":"PLAYER","revision":7,"sessionEpoch":2,"snapshot":{"sceneId":"scene-1","units":[],"markers":[]}}
```

A presença de `role` em `WELCOME` **é derivada pelo servidor**, não concedida pelo cliente. O snapshot é uma projeção exclusivamente autorizada para aquele participante.

```json
{"v":2,"type":"INTENT","roomId":"arena-test","commandId":"cmd-008-unique","baseRevision":7,"kind":"MOVE_VISUAL_TEST","unitId":"synthetic-p1-unit","payload":{"x":3,"y":4}}
```

`MOVE_VISUAL_TEST` é uma intenção de movimentação sintética, não uma regra oficial de deslocamento do RPG. O executor confiável ainda validará posse, turno, cena, versão e legalidade competente; valores mecânicos exigem VLAB.

```json
{"v":2,"type":"ACK","commandId":"cmd-008-unique","status":"ACCEPTED","revision":8,"eventId":"ev-008"}
```

```json
{"v":2,"type":"ACK","commandId":"cmd-008-unique","status":"REJECTED","reason":"STALE_REVISION","currentRevision":8}
```

**Quando a conexão cai antes do ACK:** o cliente exibe `UNKNOWN / RECONCILIAR`, não `REJECTED`. Reabre sessão, recupera snapshot e consulta o recibo pelo MESMO `commandId`; não envia nova ID automaticamente. Mesmo ID + mesmo payload retorna comprovante deduplicado sem novo commit; mesmo ID + payload diferente é `ID_REUSE_CONFLICT`.

```json
{"v":2,"type":"RECEIPT_QUERY","roomId":"arena-test","commandId":"cmd-008-unique"}
```

```json
{"v":2,"type":"RESYNC","roomId":"arena-test","afterRevision":7}
```

O servidor retorna eventos **filtrados e autorizados**, ou um novo snapshot de nível apropriado se houve lacuna, histórico não disponível ou mudança de epoch. Nunca mandar log mecânico/Mestre-only integral como fallback.

## Pipeline de commit proposto

1. Verificar versão, frame máximo, Origem, ticket/sessão ativa, limite de comandos e escopo da sala.
2. Vincular papel e unidades controláveis a identidade **armazenada no servidor**. Ignorar role/owner/master reivindicados em JSON.
3. Buscar recibo `(roomId, participantId, commandId)`; se existir, comparar hash exato do envelope normalizado e responder sem executar de novo.
4. Conferir `baseRevision`, turno e posse; para ação mecânica real exigir interface VLAB competente. Sem homologação: `MECHANICS_HOLD` e nenhuma alteração mecânica.
5. Executar transação única: atualizar revisão/estado autorizado + inserir recibo idempotente + guardar evento com tipagem/visibilidade explícita. Falha antes do COMMIT: rollback e não responder ACCEPTED.
6. Confirmar persistência/flush e só depois enviar ACK; em seguida distribuir projeções distintas por papel. Se ACK sumir depois do commit, recibo devolvido na reconciliação.
7. Na entrega a PLAYER, reconstruir evento e marcador somente por **allowlist recursiva**, não copiar `lastEvent` ou `markers` arbitrários do banco. Para `MASTER`, preservar apresentação administrativa exclusiva.

## Porte para Cloudflare Durable Objects (não executado)

- Worker recebe requisição HTTPS, valida origem e autenticação/ticket antes de conceder sala; roteia para DO por ID seguro de sala.
- DO SQLite: `ctx.storage.sql.exec()` com parâmetros e `ctx.storage.transactionSync(()=>{ ... })` para estado/recibo/evento, **sem `BEGIN TRANSACTION` literal via SQL** (API oficial não suporta). Consumir cursores antes de cruzar `await`.
- `ctx.acceptWebSocket(serverSocket)` ativa hibernação; `serializeAttachment({participantId,role,sessionEpoch,roomId})` armazena só metadados pequenos (máximo 16.384 bytes), **não segredos ou snapshot inteiro**.
- Após acordar, `ctx.getWebSockets()` + `deserializeAttachment()` reconstroem sessões, verificando epoch/revogação persistidos em SQLite antes de aceitar intents. Código em memória não é verdade durável.
- `setWebSocketAutoResponse` pode aliviar ping/pong, mas temporizadores que despertam a cada poucos segundos comprometem hibernação e quota.
- Gates oficiais recomendados para TEST real: Workers Vitest `runInDurableObject`, `evictDurableObject`, `abortAllDurableObjects`, `reset` apenas em teste; comparar recibo e sala após eviction/hibernação, rollback de exceção SQL, envelopes + A+C; depois `wrangler dev` e Cloudflare Free sob quota real verificada por Mestre/Desenvolvedor autorizado.

Fontes primárias: [Cloudflare DO WebSocket Hibernation](https://developers.cloudflare.com/durable-objects/best-practices/websockets/), [SQLite API](https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/), [Vitest APIs](https://developers.cloudflare.com/workers/testing/vitest-integration/test-apis/), [Pricing](https://developers.cloudflare.com/durable-objects/platform/pricing/), [MDN WebSocket Security](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API/Writing_WebSocket_servers).

## Testes de aceite mínimos, ainda não homologados para produção

- 3 navegadores reais no mesmo backend, 3 identidades distintas, 1 revision comum. Movimento aparece nos três, intenção hostil rejeitada.
- Repetição de commandId após perda de ACK e após reinício/hibernação devolve recibo antigo; não duplica alteração.
- Corrida de intents com mesma revisão dá 1 aceito e 1 stale; rejeição não dispara confirmação positiva.
- Falha de SQLite UPDATE e falha de INSERT de recibo: estado/recibo juntos rollback; nunca ACK de sucesso antes commit.
- `adminMarkers`, `adminRevision`, notas, logs e metadados internos ausentes de **payloads brutos** da Party (não apenas DOM/CSS); canários de subcampos testados.
- Ticket expirado/revogado, reutilizado, de outra sala ou outro usuário rejeitado. Não aceitar master só porque o JSON diz `role=master`.
- Snapshot/resync após reconnect com lacuna: revisão consistente; nenhum mecanismo do VLAB inventado.
- WSS publicamente confiável, Android físico Mestre + duas players, origem diferente, latência/dados/perda de rede, quota Cloudflare REAL medida. **Nenhum desses requisitos finais foi certificado pela PESQ-013.**
