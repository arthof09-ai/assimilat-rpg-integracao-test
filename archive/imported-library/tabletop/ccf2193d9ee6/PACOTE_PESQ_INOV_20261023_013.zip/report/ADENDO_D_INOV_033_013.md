# ADENDO à D-INOV-033 (sem criar outro despacho) — PESQ-INOV-013

**Prioridade P0.** Destino: CM-000001 / Segundo Comestre Inovador quando encaminhado, sem afirmar ACK. Preserva D-INOV-033 proposta.

**Problema material solucionado em ciência:** PESQ-012 havia conectado três clientes aiohttp, mas as telas Chromium usavam snapshots injetados, não WebSocket próprio. PESQ-013 executou três contextos Chromium independentes, com botões reais da mesma interface PESQ-012 enviando WebSocket para um servidor original copiado. **33/33 PASS** de conexão, movimentação sincronizada, reconexão, filtragem e persistência após restart. Adicionalmente **10/10 PASS via WSS local com certificado autossinado** (confiança da CA ignorada deliberadamente apenas em TEST). Não são três aparelhos ou Cloudflare.

**Novo problema revelado:** COMMIT pode persistir embora o ACK tenha desaparecido. Falhas injetadas antes do COMMIT geram rollback; falha após COMMIT deixa ação aplicada mas cliente sem ACK. **26/26 PASS** para integridade e reconciliação, inclusive dupla intenção na mesma revisão: 1 aceita, 1 stale. Contrato novo necessário: estados `ACCEPTED`, `REJECTED`, `UNKNOWN / RECONCILIAR`, consulta por `commandId`, recibo persistido atomicamente antes ACK. Nunca tratar timeout como falha mecânica para retransmitir com novo ID.

**Segurança por subcampo:** Projeção PESQ-012 já omite `adminMarkers` top-level, mas copia objetos `lastEvent` e marcadores autorizados sem saneamento recursivo. Em DB local DELIBERADAMENTE adulterado, segredo-canarinho colocado em `lastEvent.internalMasterOnly` e `markers[].adminSourceId` apareceu nas projeções sintéticas de PLAYER. Uma função allowlist proposta eliminou os dois e passou **15/15 contratos**. Isso **não é vulnerabilidade remota comprovada do TEST33**; é um risco de evolução do esquema que se tornaria relevante ao conectar VLAB/Party.

**Autenticador ainda insuficiente:** **8/8 verificações** documentaram que os convites reutilizáveis TEST permitem duas conexões Mestre simultâneas e reentrada; papel falsificado em comando não funciona, mas falta expiração, revogação, epoch e gate antes WebSocket upgrade. Exigir auth real, sessão vinculada a sala+participante+unidade e WSS certificado confiável. Não criar autenticação DIY sem revisão.

**Contrato mínimo:** arquivo `PROTOCOLO_SALA_V2_013.md`; uma sala autoritativa, state+receipt+event no mesmo SQLite commit, projeções por destinatário, tokens temporários e expulsão/revogação, DTO VLAB somente após liberação competente. UI local TEST33 não deve enviar workspace/admin bruto, nem escrever `main` ou `gh-pages`.

**Fontes:** ZIP PESQ012 autenticamente SHA256 `3a40d0a17bef49d521895483ca93a652c8bf732e8f945980415a6136169b311f`; arquivos base `room_server.py` e `index.html` SHA individual preservados. Documentação Cloudflare DO SQLite / Hibernation / Vitest (URLs no contrato).

**Compatibilidade:** Chrome Android plausível pela API WebSocket padrão, não provada fisicamente; alternativa desktop via browser. GitHub Pages frontend pode continuar, desde que não exponha segredos e WSS backend seja HTTPS confiável. Gratuito dentro de limites Cloudflare Free **dependente de conta e quota confirmadas**. Sem login Cloudflare, sem gasto.

**Teste de aceite do Desenvolvedor:** ver protocolo anexo; executar Workers Vitest no runtime real (hibernação via evictDurableObject), 3 browsers e depois 3 dispositivos de verdade, negativa de ACL, concorrência e rollback, e captar tráfego player bruto. Fornecer hash, branch TEST autorizada, estado antes/depois e rollback. **Não duplicar tarefa Codex Python↔TypeScript já iniciada pelo Mestre.**

**Risco residual:** WSS local selfsigned não é público, Python aiohttp não é DO, auth/test ticket não é produção, estado 7x7 fictício, VLAB e arena mecânica HOLD. Nenhuma implantação ou ACK reivindicados.
