# Mapa mínimo de integração TEST33 (leitura estática, não alterado)

**Fonte autêntica:** ZIP `TABLETOP_SITE_SINTETICO_TEST33_CANDIDATE.zip`, SHA256 `25160fc798916d660d94b58e16bd43596c0f38ea2b4dcd55cd1d0f0c519d8c8d`, `app.js` 65.254 bytes SHA256 `7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4`. Código consultado/read-only nesta PESQ013. Último deploy confirmado TEST32, TEST33 candidato.

Funções fisicamente identificadas: `validateWorkspace` (validação TEST), `persistChecked` (localStorage), `snap()` / `undo()` / `redo()` (histórico local), `clickCell` (interação), `markerCommand` (marcas por cena), `renderBoard` / `renderRuler` (apresentação, FOV visual). Não são API de combate VLAB, não aceitam automaticamente schema de rede.

**Proposta incremental:** inserir no frontend TEST autorizado um adaptador fino `RoomTransport` que conhece somente JOIN, INTENT, ACK, SNAPSHOT, RESYNC, RECEIPT_QUERY. As ferramentas existentes chamam `sendIntent` somente quando modo sala está ativo e o usuário/turno está autorizado, sem mudar `workspace` Mestre nem salvar estado compartilhado como verdade local. `renderBoard` recebe uma projeção visual adaptada de snapshot sanitizado; não fazer `workspace = networkSnapshot` em bloco. Animações e zoom são consequências visuais do recibo de estado; um único resultado mecânico autorizado para modos cinematográfico/equilibrado/objetivo. Nunca expor JSON do Mestre inteiro no HTML cliente da Party.

**Primeira ação compatível:** testar `END_TURN` sintético e `MOVE_VISUAL_TEST` em cópia isolada. Ataques, dano, PA, Vida, Alma, regras de movimento oficiais, transformação e tática canônica dependem de interface VLAB homologada e permanecem `MECHANICS_HOLD`. Sem D-INOV-033 ACK nem Codex bridge final não escrever frontend oficial.

**Regressões mínimas do atual TEST33:** NO-OP Refazer da PESQ010, fallback local/restore, FOV A+C, marker scenes, ruler, pan/zoom/touch. Não repetir 22/22 por rotina; executar somente regressões das funções tocadas pelo Desenvolvedor após diff.
