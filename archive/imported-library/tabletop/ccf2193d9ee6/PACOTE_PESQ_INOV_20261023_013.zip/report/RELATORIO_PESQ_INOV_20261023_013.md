# PESQ-INOV-20261023-013 — Da prova de rede à sala entre navegadores com WSS local e falhas adversariais

**Projeto:** RPG Assimilação / Tabletop Assimilação. **Autor:** Terceiro Comestre Inovador — Pesquisador, MESTRE-SIDE/TEST. **Data:** 23/10/2026. **Custo externo adicional:** R$0. **Operação:** pesquisa existente, continuação de PESQ012 e adendo a D-INOV-033 **PROPOSTA**, sem ACK, implementação oficial ou cloud deploy.

## Resumo executivo — mudança material ANTES → DEPOIS

**ANTES (PESQ012):** três clientes Python `aiohttp` tinham provado WebSocket real localhost com estado autoritativo; três telas Chromium usavam snapshots estáticos injetados. Persistência SQLite, idempotência e conflito foram observados mas não haviam sido submetidos a falhas controladas de commit/ACK. Cloudflare era hipótese documentada, sem conta/credencial, e a autorização era apenas convite de TEST.

**DEPOIS (PESQ013):** 1 Mestre + 2 players agora abriram **três WebSockets realmente originados de três contextos distintos Chromium**, com comandos pelo botão da interface real da bancada PESQ012, movimentação sincronizada, reconexão e cold SQLite reboot. **33/33 verificações PASS** no WS `localhost`. Segundo teste com **WSS TLS local real e certificado EFÊMERO AUTOSSINADO sob trust bypass do Chromium**: **10/10 PASS**. Falhas injetadas antes e depois do COMMIT: **26/26 PASS**, demonstrando por que timeout sem ACK é **UNKNOWN**, não rejeição. Cenário de evento e marcador explicitamente adulterados no banco sintético: teste mostrou vazamento de subcampo se backend copiar objetos aninhados; allowlist recursiva experimental preservou dados permitidos: **15/15 PASS**. Contornos dos convites reutilizáveis: **8/8 PASS** demonstrando **falta de autenticação de produção**, não invasão de produto. Frames malformados / maiores que 8KB: **6/6 PASS**. **Total 98/98 contratos DIRIGIDOS de subestudos distintos**, não homologação de Cloudflare, VLAB, Android real ou Tabletop oficial.

Os seis denominadores devem permanecer separados (33 + 10 + 26 + 15 + 8 + 6); os resultados positivos em P02/P03 da suíte de canário significam que a **injeção deliberada foi detectada** na cópia PESQ012, não que o produto deva vazar. Testes não originais do Desenvolvedor nem do Codex.

## Baseline e governança

- [Laboratório do Inovador no Notion](https://app.notion.com/p/401c2b324ede809585d3d1907c194df9) atualizado, última sessão consultada em 23/10/2026. **RUN010** último RUN documental no momento do readback anterior à pesquisa; TEST32 publicado na `gh-pages` sob `0aa9bc817844fa4ce0e16a2103a3a89988df577c`; TEST33 somente candidato (site ZIP 28.752B SHA256 `25160fc798916d660d94b58e16bd43596c0f38ea2b4dcd55cd1d0f0c519d8c8d`, `app.js` 65.254B SHA256 `7b1cce98bfcfc4e86ea5978472bfe5ce5e24b2d6827b284e342c2992e82faba4`). Não houve reexecução dos 22/22 de Refazer, 1.500 entradas ou suites de Desenvolvedor.
- `PACOTE_PESQ_INOV_20261023_012.zip` (arquivo PESQ012, guardado separadamente na Biblioteca) fisicamente SHA256 `3a40d0a17bef49d521895483ca93a652c8bf732e8f945980415a6136169b311f`. `prototype/room_server.py` SHA256 `a49d6fc134590060514f3ca00b9e99078ebaf8246b27c49a1a41f368b380173e`; `prototype/index.html` SHA256 `e58d9227c0eb9bca7166015b4cbd0840f87de047c9675b4c92c518110854c413`. Ambos extraídos em **cópias exatas**, sem editar seu conteúdo/implementação mecânica; incluídos neste arquivo de estudo apenas como **fixture autoral antiga** para permitir replay frio.
- BOOTSTRAP-COMESTRE/Kit, LONG-RUN-01 vigente, NAC-CONT-03/NAC-NORM-01/NAC-PASS-02/REG-ROUTE-03, Diário competente consultados. D-INOV-032 A+C decisão APROVADA do Mestre, sem reabrir. D-INOV-033 segue PROPOSTA P0. Codex Cloud Python↔TypeScript já INICIADO pelo Mestre em TEST; sem resultado final auditado, **não iniciar tarefa paralela** nem editar backend/arquivos do Codex. VLAB R315 é fonte histórica Mestre-only, status de 0/17 terminais pelo último relato, **não foi executado**; eventual versão VLAB nova precisa de writer autorizado.
- Ambiente: Python 3.13.5 Linux, aiohttp, Playwright, Chromium 144.0.7559.96; navegação HTTP localhost foi **bloqueada pelo administrador** (`ERR_BLOCKED_BY_ADMINISTRATOR`). Script carregou DOM do HTML por `page.set_content`, substituiu SOMENTE endereço WS e gerador de `commandId` experimental porque `about:blank` não expõe `crypto.randomUUID()`. **WebSocket originado pelo browser foi REAL**, e não rota de snapshots injetados. O gerador experimental NÃO É SEGURO PARA PRODUÇÃO.

## Resultados por bateria e provas

### E013-A — Três browsers WS (`audit_three_browser_real_ws_013.py`) — 33/33 PASS

- Três contextos Playwright distintos (Mestre 390×844, player 1 360×740, player 2 820×840) conectaram WS a `127.0.0.1`, cada um recebeu `SNAPSHOT` após `JOIN` com token fixture. Rede de browser confirmada por `page.on('websocket')` e frames de envio/recepção reais.
- Botão **Passar turno** do Mestre elevou revisão a 1, três browsers viram p1 ativo; botão **Mover minha unidade +1 X** da player 1 elevou revisão a 2, três views concordaram em x=4 e a célula da player2 exibiu P1.
- Mestre enviou `PRIVATE_MARK` durante turno alheio sem alterar revisão pública; segredo-canarinho só apareceu na sua projeção. Inspeção dos **frames recebidos** nas duas players e do DOM indicou ausência do canário e colunas `adminMarkers/adminRevision`.
- Pedido ADMIN e claim falsa de `role=master` pela player foram rejeitados. Fechar WebSocket e reabrir em browser player2 restaurou revisão, unidades e turno com payload filtrado. Mesmo `commandId` repetido recebeu recibo `deduplicated`; ação visual fictícia marcou `mechanics='NOT_EXECUTED'`. SQLite reiniciado fez browser novo recuperar revisão 3 e unidade x=4, ainda sem segredo.
- Capturas **REAL WS** para Mestre, P1 e P2 em `results/BROWSER_*_REAL_WS.png`. Não são screenshots de celulares reais; apenas dispositivos emulados e servidor local no mesmo host.
- Volume experimental pela captura bruta: 11 frames enviados (1.081 bytes), 21 frames recebidos (8.820 bytes), maior recebido 710 bytes, tudo numa grade 7×7 com três unidades. Não confundir com estimativa de mapa grande, tráfego Cloudflare ou latência WAN.

### E013-B — WSS TLS de laboratório (`audit_wss_loopback_013.py`) — 10/10 PASS

Mesmo protocolo e três interfaces Chromium, **TLS de fato habilitado via ssl.SSLContext** com certificado autossinado gerado em diretório efêmero (`openssl`). Flags `--ignore-certificate-errors` e `ignore_https_errors=True` usadas **deliberadamente** na bancada: nenhuma cadeia pública de confiança validada. Funcionaram conexão de três navegadores WSS, sincronização de turno/movimento, reconexão de browser e ausência de segredo administrativo nos frames player. **Não existe endpoint cloud nem certificado público confiável**; não afirmar implantação nem autenticação real.

### E013-C — Falhas antes/depois COMMIT (`audit_commit_unknown_013.py`) — 26/26 PASS

Falha SQLite provocada no UPDATE: revision=0 e recibo ausente, **nenhum ACK positivo**, retry mesmo commandId após remover fault aceita. Falha no INSERT de recibo após UPDATE: transação faz **ROLLBACK do estado e do recibo**, também sem sucesso prematuro. **Falha artificial depois do COMMIT antes de enviar ACK:** cliente percebe apenas socket fechado (resultado `UNKNOWN`), mas room/revision e receipt estão persistidos; após reconnect/restart, retry com MESMO commandId retorna `deduplicated`, sem ação extra. Reutilizar ID com payload modificado dá `ID_REUSE_CONFLICT`. Dois comandos simultâneos para a mesma revision produziram **exatamente 1 ACCEPTED + 1 STALE_REVISION**. Frames de erro/traceback presentes nos logs foram **induzidos de propósito** nos pontos de falha, não bug acidental do programa original.

**NOVO REQUISITO P0:** preservar `ACCEPTED / REJECTED / UNKNOWN` no cliente e `RECEIPT_QUERY`/`RESYNC` no servidor. Se ACK foi perdido, não gerar uma nova ID para a mesma intenção. `ACK(ACCEPTED)` só após estado+recibo persistentes.

### E013-D — Canário em campos aninhados (`audit_nested_projection_013.py`) — 15/15 PASS

Teste científico com **ALTERAÇÃO DIRETA DELIBERADA** de SQLite descartável para inserir `internalMasterOnly=MASTER_PRIVATE_CANARY_X013` num `lastEvent` e `adminSourceId` extra em marcador de aparência pública. A projeção antiga PESQ012 omitira campos administrativos do topo, MAS copiou os objetos aninhados verbatim, levando canários ao payload da player nesse cenário artificial. Uma função experimental construiu DTO dos eventos/marcadores somente por campos permitidos, e os canários desapareceram, preservando evento/marca válidos. **Não foi demonstrado caminho remoto capaz de introduzir esses campos no fluxo normal e NÃO é falha explorável verificada no Tabletop TEST33.** É prova de que futura integração VLAB/eventos dinâmicos requer **allowlist recursiva**. Não confiar em CSS.

### E013-E — Contratos de identidade (`audit_auth_edges_013.py`) — 8/8 PASS

O WS de TEST faz upgrade 101 antes do JOIN, aceita **duas conexões Mestre com o mesmo convite** e aceita reutilizar convite depois de desconectar. Ação sem JOIN é rejeitada, token errado negado, campo `role=master` no JSON após JOIN de player não dá acesso admin. Esses são efeitos **esperados do convite estático sintético**, não login seguro. Para produção exigem: ticket curto gerado por Mestre autenticado, vínculo sala/personagem, alta entropia, sessão/epoch, revogação e rotação, limitação de conexões e gate de upgrade. Uma credencial roubada é uma credencial válida para esse protótipo, logo **NÃO aprovar deploy público** com ele.

### E013-F — Limites de mensagens (`audit_frame_limits_013.py`) — 6/6 PASS

JSON inválido é rejeitado sem mudar estado; envelope desconhecido recebe erro; quadro de 9.000 bytes excede `max_msg_size=8192` da bancada, fecha WS, não altera revisão. **Esse limite é código PESQ012, não limite Cloudflare:** DO oficial aceita até **32 MiB de mensagem recebida**, mas recomendação é definir teto bem menor por contrato do RPG para evitar DoS/memória/quotas.

### Modelo de franquia (`quota_model_013.py`) — analítico, NÃO teste Cloudflare

Fonte Cloudflare **atualizada 18/10/2026**: Worker Free 100k requisições/dia, 10ms CPU por Worker; DO Free 100k requisições/dia (20 mensagens WS recebidas equivalem a uma requisição para cálculo), duração 13k GB-s/dia, SQLite 5 milhões linhas lidas/dia, 100k escritas/dia, 5 GB stored total; exceder faz falhar, não dá capacidade infinita. Free exige DO SQLite, não KV legacy. Hibernação reduz compute ociosa, mas timers frequentes, I/O e processamento podem impedir. **Attachment de WS** máximo **16.384 bytes** — guardar somente identidade/epoch mínimo, não snapshot; **SQLite DO transactionSync** para estado/recibo/evento e `evictDurableObject()` em Vitest para verificar reativação. Documentação:

- https://developers.cloudflare.com/durable-objects/platform/pricing/
- https://developers.cloudflare.com/durable-objects/platform/limits/
- https://developers.cloudflare.com/workers/platform/limits/
- https://developers.cloudflare.com/durable-objects/best-practices/websockets/
- https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/
- https://developers.cloudflare.com/workers/testing/vitest-integration/test-apis/

Exemplo **assumido** 4h × 6 intenções/min = 1.440 comandos; se 2 linhas gravadas/ação = 2.880 linhas, abaixo do limite diário nominal. Worker requests, SQL indexes, reconnect, erros, reads, tráfego de outros apps, CPU, duração e rate-limit não estão contabilizados; não é bill real. O extremo 4h × 500/min com 2 linhas/ação = 240k escritas ultrapassa o limite, apesar de mensagens WS poderem ficar abaixo da franquia compute. Quotas da conta do Mestre e requisito de cartão não foram vistos: **HOLD**. Zero custo externo adicional realizado.

## Contrato e implementação futura — sem duplicar executor

- Entregável [PROTOCOLO_SALA_V2_013.md](PROTOCOLO_SALA_V2_013.md) cobre envelopes versionados, ordenação, revisão, ticket, admin/public DTO recursivo, `UNKNOWN`, recibos, reconciliação e Durable Objects hibernação. **Não é PR, código Cloudflare executado ou backend oficial**.
- [MAPA_TEST33_TRANSPORTE_013.md](MAPA_TEST33_TRANSPORTE_013.md) identifica funções reais `clickCell`, `markerCommand`, `renderBoard`, `validateWorkspace`, `persistChecked`, `snap`, `undo`, `redo`, `renderRuler`, e explica por que não sobrescrever `workspace` com snapshot da rede. Sem modificar `app.js`.
- [PLANO_VALIDACAO_CLOUDFLARE_ANDROID_013.md](PLANO_VALIDACAO_CLOUDFLARE_ANDROID_013.md) define checks Workers Vitest, WSS público, autenticação confiável e três aparelhos reais.
- [ADENDO_D_INOV_033_013.md](ADENDO_D_INOV_033_013.md) acrescenta evidência original à D-INOV-033 sem criar novo ID/despacho, nem interferir em Codex já iniciado. O Coordenador faz encaminhamento quando competente.

## NAC-PASS-02 proporcional / fronteiras

**PASS científico:** fonte ZIP antiga autenticada e copiada byte a byte; 33/33 browser WS real; 10/10 WSS autossinado de TEST; 26/26 injeções de falha e corrida; 15/15 projeção com canários artificiais; 8/8 borda de convites; 6/6 frames; replay frio; manifesto/Library/Notion após readback. **98/98 no total mas denominadores originais preservados.**

**HOLD real:** Cloudflare Workers/DO runtime, hibernação física, conta/cartão/quota, WSS de CA pública, tokens produção/revogação, três aparelhos Android ou redes WAN reais, frontend TEST33 oficial conectado, ação legal do VLAB (0/17 terminal segundo relatório histórico R315), Codex Python↔TypeScript sem resultado final inspecionado, publicação/site e segurança Party final. Nenhuma ferramenta paga, dados reais ou assets externos executados.

## Custódia / sucessão

**Pacote deste marco:** `PACOTE_PESQ_INOV_20261023_013.zip`, manifesto SHA256 de todos os artefatos, todos os scripts originais e fixtures autorais exatas PESQ012; nenhum source oficial TEST33 ou VLAB, nenhuma conta/credencial real, nenhuma Party. Scripts requerem Python 3.13, aiohttp, Playwright, Chromium local, `openssl` para teste WSS; instructions em `README_REPRODUCAO_013.md`. Screenshots e JSONs no pacote como evidências separadas.

**LAST-VERIFIED-UNIT:** 3 contextos Chromium WS interativos + WSS local e cold SQLite, execuções adversariais, contrato atualizado e pacote auditado.
**FIRST-PENDING:** Coordenação e Desenvolvedor avaliar adendo D033 e status Codex sem concorrência de writer; conta CF Free/DO só com autorização do Mestre.
**NEXT:** Workers Vitest DO real (hibernação/receipt/revogação), WSS público grátis sob quotas, e 3 Chrome Android físicos vendo uma sala com login real e payload filtrado; SOMENTE depois adapter TEST33 + VLAB competente.
**NO-REPEAT:** não reexecutar PESQ009–012, nunca duplicar Codex bridge, regras VLAB, backend autoritativo ou Party, não mexer main/gh-pages, não reinstalar Godot, não questionar FOV A+C e não chamar loopback de cloud multiplayer.
