# Cloudflare Free / três Android — Gate de execução futura (NÃO EXECUTADO)

## Decisão de pesquisa, não provisionamento

Cloudflare Workers Free + Durable Objects SQLite por sala continua primeira hipótese. Documentação oficial consultada em 23/10/2026. Limites do plano Free: **100.000 requisições DO/dia**, **13.000 GB-s/dia**, **5 milhões de linhas SQLite lidas/dia**, **100.000 linhas escritas/dia**, **5 GB armazenamento total**. Worker Free: **100.000 requests/dia e 10 ms CPU por invocação Worker**; dimensionar Worker separadamente do DO. 20 mensagens WebSocket recebidas contam como uma requisição de compute para a quota DO; handshake equivale a requisição; mensagens de saída sem essa tarifa. Outros limites se acumulam. No Free, excesso causa falhas e quotas diárias reiniciam 00:00 UTC. DO Free exige SQLite, não KV legado.

Fontes: https://developers.cloudflare.com/durable-objects/platform/pricing/ ; https://developers.cloudflare.com/durable-objects/platform/limits/ ; https://developers.cloudflare.com/workers/platform/limits/ ; https://developers.cloudflare.com/durable-objects/best-practices/websockets/ .

Cálculo simples em `results/QUOTA_MODELLING_013.json`: 4h, 6 ações/min = 1.440 comandos, cerca de **75** requisições DO equivalentes **sob hipóteses irreais simplificadas** de 3 handshakes, 1 WS recebido por ação e nenhuma outra invocação; com 2 linhas SQL por comando = **2.880 linhas escritas**. Exclui índices, read/write adicionais, CPU, evictions, mídia, conexão, HTTP Worker, falhas e outros usuários da conta. Não é cobrança verificada. A PESQ013 mediu somente 11 frames enviados e 21 frames recebidos pela UI em um ensaio, com 8.820 bytes recebidos no total e 710 bytes como maior frame recebido naquele mapa 7x7.

**Acesso e custo em conta real:** solicitação de conta/credenciais/implantação pertence ao Mestre e Desenvolvedor autorizado; não presumir que nenhuma forma de pagamento seja solicitada no cadastro; se plataforma pedir cobrança, STOP sem comprar. Conferir cota real no dashboard antes e depois da sessão.

## Etapa 1 — execução local DO no runtime compatível

1. Coordenador confirma quem possui writer de TEST e status da missão Codex Python↔TypeScript, evitando backend/branch concorrente.
2. Desenvolvedor implementa pequena sala DO, Worker dispatcher e schema v2 autorizado; não importa `room_server.py` Python como produção nem cria motor mecânico.
3. Executar testes Workers Vitest com `runInDurableObject`, `evictDurableObject`, `abortAllDurableObjects`: retenção de attachments pela hibernação; recuperação SQLite; perda do ACK pós commit; corrida de duas intents; SQL rollback; sanitização recursiva; revogação de ticket; limite de tamanho.
4. Inspecionar pacote real e estado do GitHub TEST. Não editar `main`, `gh-pages` ou VLAB até autoridade explícita.

## Etapa 2 — hospedagem autorizada R$0 e WSS real

1. Mestre confirma Cloudflare Free habilitada sem compra; Coordenador autoriza missão, branch e localização de segredos. Tickets do Mestre gerados em área confiável e temporários.
2. Verificar HTTPS, WSS com CA pública, checagem `Origin` contra domínio permitido, política de rate limit, autenticador, rotação/revogação, CSP adequada, não passar token em URL ou páginas estáticas.
3. Teste browser em dois tipos de rede para separar WAN de Wi-Fi presencial; medir RTT p50/p95, disconnection, reconnection, bytes e filas de comandos; nunca alegar latência Cloud com dados de loopback.
4. Proteger snapshots admin, histórico/replay, logs, eventos aninhados e nomes ocultos; varrer payload das players em capture de WS.

## Etapa 3 — três aparelhos

Mestre e duas players, dispositivos com URLs distintos mas mesma sala. Cada pessoa usa convite individual de TEST, papel controlado pelo servidor. Testar rodada com movimento de cada unidade, reconnect após Wi-Fi off/on, logout/revogação e retorno, uso em foreground/background, rotação de tela, entrada por toque, PWA se instalada e conflito de duas abas. Testar 4G/Wi-Fi se autorizado. Não ligar combate VLAB nem Party oficial nessa etapa.

**Gate final P0:** 1 Mestre e 2 players reais conectados ao DO/WSS; todos veem mesmo turno, cada cliente só seu payload, ao menos 1 movimento/1 mock action com recibo e idempotência, reconexão e rollback de falhas, quota Free medida e sem custo. Se não houver conta ou 3 aparelhos, manter HOLD apenas nessas dimensões, não fingir PASS.
