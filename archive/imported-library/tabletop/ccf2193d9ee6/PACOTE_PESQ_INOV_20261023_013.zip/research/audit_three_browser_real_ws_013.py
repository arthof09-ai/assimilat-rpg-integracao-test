#!/usr/bin/env python3
"""PESQ-013: 3 REAL Chromium browser WebSocket contexts on ONE LOCAL computer.
Uses ONLY copied/verified PESQ-012 code + a browser-only URL bootstrap because
managed Chromium blocks localhost HTTP navigation. No official RPG mechanics.
"""
import asyncio, tempfile, json, hashlib, os, sys, time, contextlib
from pathlib import Path
from aiohttp import web
from playwright.async_api import async_playwright, Error as PWError
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'sources'/'prototype'
sys.path.insert(0,str(SRC))
from room_server import create_server
TOKENS={'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'}
RESULTS=[];PAGE_ERRORS=[];TRACE={}
def ck(label,condition,detail=None):
    RESULTS.append({'name':label,'pass':bool(condition),'detail':detail})
    print(('PASS' if condition else 'FAIL')+' '+label+(f' :: {detail}' if detail else ''),flush=True)
async def start(db):
    instance=create_server(db,TOKENS)
    runner=web.AppRunner(instance.app,access_log=None);await runner.setup()
    site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
    port=site._server.sockets[0].getsockname()[1]
    return instance,runner,port
async def eventually(fn,seconds=5):
    for _ in range(int(seconds*20)):
        if await fn():return True
        await asyncio.sleep(.05)
    return False
async def snap(page):return await page.evaluate('snap')
async def rev(page):return await page.evaluate('snap && snap.revision')
async def waitrev(page,n):return await eventually(lambda:check_revision(page,n))
async def check_revision(page,n):return (await rev(page))>=n
async def ackwait(page,fragment,timeout=5):
    return await eventually(lambda:trace_contains(page,fragment),seconds=timeout)
async def trace_contains(page,fragment):return fragment in await page.locator('#trace').inner_text()
async def connect(page,role,port):
    await page.evaluate('([tok])=>connectToken(tok)',[TOKENS[role]])
    return await snap(page)
async def send(page,kind,payload=None,cid=None):
    return await page.evaluate('({kind,payload,cid})=>sendCommand(kind,payload,cid)',{'kind':kind,'payload':payload or {},'cid':cid})
async def browser_suite():
    template=(SRC/'index.html').read_text(encoding='utf-8')
    assert 'new WebSocket(`ws://${location.host}/ws`)' in template,'baseline changed'
    # Minimal browser-only substitution of URL, NOT of gameplay, auth, snapshots or state:
    modified=template.replace('new WebSocket(`ws://${location.host}/ws`)','new WebSocket(window.__TEST_WS_URL__)').replace('crypto.randomUUID()', 'window.__fixtureUUID()')
    with tempfile.TemporaryDirectory(prefix='p013_') as td:
      db=Path(td)/'test.sqlite'
      inst,runner,port=await start(db)
      async with async_playwright() as pw:
        browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        contexts=[];pages=[];frames={}
        try:
          for role,screen in [('master',(390,844)),('p1',(360,740)),('p2',(820,840))]:
            ctx=await browser.new_context(viewport={'width':screen[0],'height':screen[1]},is_mobile=(role!='p2'),has_touch=(role!='p2'))
            page=await ctx.new_page();contexts.append(ctx);pages.append(page)
            role_frames=[];frames[role]=role_frames
            page.on('pageerror',lambda e,role=role:PAGE_ERRORS.append({'role':role,'error':str(e)}))
            def on_ws(ws,role=role):
              frames[role].append({'event':'connection','url':ws.url})
              def recv(x):frames[role].append({'event':'received','data':x})
              def sent(x):frames[role].append({'event':'sent','data':x})
              ws.on('framereceived',recv);ws.on('framesent',sent)
            page.on('websocket',on_ws)
            await page.evaluate('(v)=>{window.__TEST_WS_URL__=v;window.__fixtureCounter=0;window.__fixtureUUID=()=>"fixture_"+(++window.__fixtureCounter)+"_"+Math.random().toString(36).slice(2)}',f'ws://127.0.0.1:{port}/ws')
            await page.set_content(modified)
          ck('B01_three_isolated_browser_contexts',len(set(id(c) for c in contexts))==3)
          initial=[await connect(p,r,port) for p,r in zip(pages,TOKENS)]
          ck('B02_three_browser_websocket_handshakes',all(len(frames[r])>1 for r in TOKENS))
          ck('B03_consensus_initial_snapshots',len(set(x['revision'] for x in initial))==1 and all(x['room']=='SYNTH-ROOM' for x in initial))
          ck('B04_role_bound_to_authenticated_token',all(x['you']==role for role,x in zip(TOKENS,initial)))
          ck('B05_master_admin_visible',bool(initial[0]['adminMarkers']))
          ck('B06_player1_no_admin_payload',not any(y in initial[1] for y in ['adminMarkers','adminRevision']))
          ck('B07_player2_no_admin_payload',not any(y in initial[2] for y in ['adminMarkers','adminRevision']))
          ck('B08_player_DOM_no_admin',all([await p.locator('.adminmark').count()==0 for p in pages[1:]]))
          ck('B09_master_DOM_admin',await pages[0].locator('.adminmark').count()==1)
          # The actual UI button sends the command; no direct Store execute calls.
          await pages[0].locator('[data-cmd="END_TURN"]').click()
          ck('B10_master_button_accepted',await ackwait(pages[0],'"kind": "END_TURN"') or await ackwait(pages[0],'"kind":"END_TURN"'))
          ck('B11_master_button_all_three_updated',all([await waitrev(p,1) for p in pages]))
          ck('B12_turn_is_p1_everywhere',all([(await snap(p))['turn']=='p1' for p in pages]))
          await pages[1].locator('[data-cmd="MOVE"]').click()
          ck('B13_p1_real_button_command_accepted',await eventually(lambda:check_revision(pages[1],2)))
          ck('B14_move_broadcast_three_browsers',all([await waitrev(p,2) for p in pages]))
          ck('B15_move_same_coordinates_all_browsers',all([next(u for u in (await snap(p))['units'] if u['id']=='unit-p1')['x']==4 for p in pages]))
          ck('B16_browser_player2_visual_movement',await pages[2].locator('.cell[data-xy="4,2"]').inner_text()=='P1')
          # Authorized private mutation when it is NOT the master's turn; separate admin revision.
          await send(pages[0],'PRIVATE_MARK',{'text':'INVISIVEL-P013-TEST'},'private_b01301')
          ck('B17_master_private_no_public_revision',await eventually(lambda:admin_rev(pages[0],1)) and all([(await snap(p))['revision']==2 for p in pages]))
          ck('B18_private_note_never_in_player_WS_frames',all(['INVISIVEL-P013-TEST' not in json.dumps(frames[r],ensure_ascii=False) for r in ['p1','p2']]))
          ck('B19_private_note_not_in_player_DOM',all(['INVISIVEL-P013-TEST' not in await p.locator('body').inner_text() for p in pages[1:]]))
          # A page tries unauthorized admin action; rejection is in-browser, no remote role inference.
          await send(pages[1],'PRIVATE_MARK',{'text':'HACK_ADMIN'},'bad_priv_b013')
          ck('B20_player_admin_request_denied',await ackwait(pages[1],'FORBIDDEN'))
          # Spoof role/master in client JSON; server derives from WS JOIN token.
          await send(pages[1],'MOVE',{'unitId':'unit-master','x':2,'y':1,'role':'master','you':'master'},'spoof_b0131')
          ck('B21_client_actor_spoof_denied',await ackwait(pages[1],'UNIT_NOT_OWNED'))
          # Reconnection actually closes WS and opens a distinct connection from same browser.
          await pages[2].evaluate('ws.close()')
          ck('B22_disconnect_flag',await eventually(lambda:flag_is(pages[2],'Desconectado')))
          recon=await connect(pages[2],'p2',port)
          ck('B23_reconnect_correct_snapshot',recon['revision']==2 and recon['turn']=='p1' and recon['you']=='p2')
          ck('B24_reconnect_no_secret',not any(y in recon for y in ['adminMarkers','adminRevision']) and 'INVISIVEL-P013-TEST' not in json.dumps(recon))
          # Idempotence across browser transport after reconnect and stale revision.
          await send(pages[1],'MOCK_ACTION',{'unitId':'unit-p1','targetId':'unit-p2'},'mock_b01301')
          ck('B25_mock_action_accepted',all([await waitrev(p,3) for p in pages]))
          await send(pages[1],'MOCK_ACTION',{'unitId':'unit-p1','targetId':'unit-p2','baseRevision':2},'mock_b01301')
          ck('B26_replayed_same_command_ack_dedup',await ackwait(pages[1],'deduplicated'))
          ck('B27_mock_no_RPG_mechanics',all([(await snap(p))['lastEvent'].get('mechanics')=='NOT_EXECUTED' for p in pages]))
          # Wire-level inspection: only 3 independent connections, no private values in sent frames.
          ck('B28_multiple_real_ws_frames_received',all([sum(1 for v in frames[r] if v.get('event')=='received')>=4 for r in TOKENS]),{k:len(v) for k,v in frames.items()})
          ck('B29_no_js_exceptions',not PAGE_ERRORS,PAGE_ERRORS)
          ck('B30_mobile_no_horizontal_overflow',all([await p.evaluate('document.documentElement.scrollWidth<=innerWidth') for p in pages[:2]]))
          await pages[0].screenshot(path=str(ROOT/'results'/'BROWSER_MASTER_REAL_WS.png'))
          await pages[1].screenshot(path=str(ROOT/'results'/'BROWSER_P1_REAL_WS.png'))
          await pages[2].screenshot(path=str(ROOT/'results'/'BROWSER_P2_REAL_WS.png'))
          ck('B31_three_real_ws_screenshots',all((ROOT/'results'/f'BROWSER_{x}_REAL_WS.png').exists() for x in ('MASTER','P1','P2')))
          # cold DB restart after browser windows closed then actual fresh browser connections
          for p in pages: await p.evaluate('ws.close()')
          await asyncio.sleep(.2)
        finally:
          for ctx in contexts:await ctx.close()
          await browser.close()
      await runner.cleanup()
      inst2,runner2,port2=await start(db)
      async with async_playwright() as pw:
        browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        ctx=await browser.new_context(viewport={'width':390,'height':844});page=await ctx.new_page()
        await page.evaluate('(v)=>{window.__TEST_WS_URL__=v;window.__fixtureCounter=0;window.__fixtureUUID=()=>"fixture_"+(++window.__fixtureCounter)+"_"+Math.random().toString(36).slice(2)}',f'ws://127.0.0.1:{port2}/ws');await page.set_content(modified)
        restored=await connect(page,'p1',port2)
        ck('B32_cold_restart_restores_movement',restored['revision']==3 and next(u for u in restored['units'] if u['id']=='unit-p1')['x']==4)
        ck('B33_cold_restart_party_no_secret','INVISIVEL-P013-TEST' not in json.dumps(restored,ensure_ascii=False) and 'adminMarkers' not in restored)
        await browser.close()
      await runner2.cleanup()
    # JSON results sans tokens / secrets
    out={'research':'PESQ013','source':'PESQ012 server and UI except test-only WebSocket URL and synthetic ID generator injection (about:blank lacks crypto.randomUUID)','browser':'Chromium Linux headless, 3 distinct contexts: 390x844 mobile,360x740 mobile,820x840 desktop; real browser WebSocket over localhost; HTTP navigation blocked','pass':sum(v['pass'] for v in RESULTS),'total':len(RESULTS),'fail':[v['name'] for v in RESULTS if not v['pass']],'tests':RESULTS,'frames_summary':{r:{'received':sum(1 for v in fs if v.get('event')=='received'),'sent':sum(1 for v in fs if v.get('event')=='sent'),'received_bytes_utf8':sum(len(v.get('data','').encode('utf8')) if isinstance(v.get('data'),str) else 0 for v in fs if v.get('event')=='received'),'sent_bytes_utf8':sum(len(v.get('data','').encode('utf8')) if isinstance(v.get('data'),str) else 0 for v in fs if v.get('event')=='sent'),'max_received_frame_bytes':max([len(v.get('data','').encode('utf8')) for v in fs if v.get('event')=='received' and isinstance(v.get('data'),str)] or [0])} for r,fs in frames.items()},'warnings':['Not three physical devices','Not WSS, Cloudflare, production authentication, mechanics or official Tabletop','Browser page loaded via set_content to bypass admin-blocked localhost HTTP navigation; WebSocket transport is real']}
    ROOT.joinpath('results','BROWSER_REAL_WS_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print('SUMMARY',out['pass'],'/',out['total'],flush=True)
    return out
async def admin_rev(page,n):return (await page.evaluate('snap.adminRevision'))==n
async def flag_is(page,expected):return await page.locator('#flag').inner_text()==expected
if __name__=='__main__':
   o=asyncio.run(browser_suite())
   sys.exit(0 if o['total']==o['pass'] else 2)
