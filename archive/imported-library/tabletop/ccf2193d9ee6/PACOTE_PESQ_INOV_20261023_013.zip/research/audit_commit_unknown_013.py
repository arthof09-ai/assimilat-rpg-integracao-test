#!/usr/bin/env python3
"""PESQ013 — new fault/ambiguous ACK research on PESQ012 copied synthetic server.
No VLAB/Party; ephemeral localhost only. Faults injected in disposable SQLite or function copy.
"""
import asyncio, contextlib, json, sqlite3, sys, tempfile
from pathlib import Path
from aiohttp import web, ClientSession, WSMsgType
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'sources'/'prototype'))
from room_server import create_server
TOKENS={'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'}
R=[]
def ck(name,ok,detail=None):
 R.append(dict(name=name,pass_=bool(ok),detail=detail))
 print(('PASS' if ok else 'FAIL'),name,detail or '',flush=True)
async def start(path):
 obj=create_server(path,TOKENS);run=web.AppRunner(obj.app,access_log=None);await run.setup();site=web.TCPSite(run,'127.0.0.1',0);await site.start();return obj,run,site._server.sockets[0].getsockname()[1]
async def auth(sess,port,who):
 w=await sess.ws_connect(f'http://127.0.0.1:{port}/ws');await w.send_json({'type':'JOIN','token':TOKENS[who]});j=await w.receive_json(timeout=4);assert j['type']=='SNAPSHOT',j;return w,j['data']
async def attempt(ws,cmd,timeout=2):
 await ws.send_json({'type':'COMMAND','command':cmd})
 try:
  while True:
   m=await ws.receive(timeout=timeout)
   if m.type==WSMsgType.TEXT:
    obj=json.loads(m.data)
    if obj.get('type')=='ACK':return obj
   if m.type in (WSMsgType.CLOSE,WSMsgType.CLOSING,WSMsgType.CLOSED,WSMsgType.ERROR):return {'connection_closed':True,'type':str(m.type)}
 except Exception as e:return {'connection_error':str(type(e).__name__)}
async def audit():
 with tempfile.TemporaryDirectory(prefix='p013_faults_') as tmp:
  db=Path(tmp)/'room.sqlite';obj,runner,port=await start(db)
  async with ClientSession() as sess:
   master,state=await auth(sess,port,'master')
   assert state['revision']==0
   cmd={'commandId':'F013_MOVE_0001','type':'END_TURN','baseRevision':0}
   # 1. SQL update fails before commit, state remains unchanged; server socket is dropped.
   obj.store.db.execute("CREATE TRIGGER fail_update BEFORE UPDATE ON room BEGIN SELECT RAISE(ABORT, 'test_abort_update'); END")
   ack=await attempt(master,cmd)
   ck('F01_update_failure_does_not_advance_revision',obj.store.state()['revision']==0)
   ck('F02_update_failure_has_no_durable_receipt',obj.store.db.execute('SELECT COUNT(*) FROM command_receipt').fetchone()[0]==0)
   ck('F03_no_success_ACK_on_failed_update',not ack.get('ok'),ack)
   obj.store.db.execute('DROP TRIGGER fail_update')
   # reconnect stale original socket, replay CID, succeeds once
   await master.close();master,state=await auth(sess,port,'master')
   ack=await attempt(master,cmd)
   ck('F04_retry_same_CID_after_rollback_commits',ack.get('ok') is True and ack['revision']==1)
   ck('F05_new_revision_persisted',obj.store.state()['revision']==1)
   # 2. Insert receipt aborts AFTER UPDATE, transaction rollback must roll back update.
   cmd2={'commandId':'F013_MOVE_0002','type':'END_TURN','baseRevision':1}
   p1,state=await auth(sess,port,'p1')
   obj.store.db.execute("CREATE TRIGGER fail_receipt BEFORE INSERT ON command_receipt BEGIN SELECT RAISE(ABORT, 'test_abort_receipt'); END")
   ack=await attempt(p1,cmd2)
   ck('F06_receipt_failure_rolls_back_room_state',obj.store.state()['revision']==1)
   ck('F07_receipt_failure_preserves_old_command_count',obj.store.db.execute('SELECT COUNT(*) FROM command_receipt').fetchone()[0]==1)
   ck('F08_receipt_failure_no_success_ACK',not ack.get('ok'))
   obj.store.db.execute('DROP TRIGGER fail_receipt')
   await p1.close();p1,state=await auth(sess,port,'p1')
   ack=await attempt(p1,cmd2)
   ck('F09_retry_receipt_failure_succeeds_once',ack.get('ok') and ack.get('revision')==2)
   # 3. Simulate critical window: COMMIT succeeds, ACK transmission lost.
   original=obj.store.execute;armed={'once':True}
   async def commit_then_lost(role,packet):
    result=await original(role,packet)
    if armed['once'] and packet.get('commandId')=='F013_MOVE_0003':
     armed['once']=False;raise RuntimeError('SYNTHETIC_LOST_ACK_AFTER_COMMIT')
    return result
   obj.store.execute=commit_then_lost
   p2,state=await auth(sess,port,'p2')
   cmd3={'commandId':'F013_MOVE_0003','type':'END_TURN','baseRevision':2}
   ack=await attempt(p2,cmd3)
   ck('F10_commit_survives_lost_ACK',obj.store.state()['revision']==3)
   ck('F11_receipt_survives_lost_ACK',obj.store.db.execute("SELECT COUNT(*) FROM command_receipt WHERE cid='F013_MOVE_0003'").fetchone()[0]==1)
   ck('F12_lost_ACK_indeterminate_on_client',not ack.get('ok'),ack)
   await p2.close();p2,state=await auth(sess,port,'p2')
   ck('F13_reconnect_recovers_committed_revision',state['revision']==3)
   ack=await attempt(p2,cmd3)
   ck('F14_retry_returns_deduplicated_receipt',ack.get('ok') and ack.get('deduplicated') and ack.get('revision')==3)
   ck('F15_retry_does_not_increment_revision',obj.store.state()['revision']==3)
   ack=await attempt(p2,{**cmd3,'type':'MOVE','unitId':'unit-p2','x':5,'y':3})
   ck('F16_same_CID_changed_payload_rejected',ack.get('error')=='ID_REUSE_CONFLICT')
   obj.store.execute=original
   # 4. Auth and role forgery after cold committed state (turn master currently).
   anon=await sess.ws_connect(f'http://127.0.0.1:{port}/ws');await anon.send_json({'type':'JOIN','token':'not-a-ticket'});result=await anon.receive_json(timeout=2)
   ck('F17_fake_ticket_rejected',result.get('code')=='UNAUTHORIZED');await anon.close()
   # actor injected in payload should not override actual session role
   p1bad={'commandId':'F013_SPOOF_0001','type':'MOVE','baseRevision':3,'unitId':'unit-master','x':2,'y':1,'actor':'master','role':'master'}
   ack=await attempt(p1,p1bad)
   ck('F18_player_spoof_cannot_control_master',ack.get('error') in ('NOT_YOUR_TURN','UNIT_NOT_OWNED'))
   # 5. The public wire view must not inherit admin payload after arbitrary turns.
   chk=obj.store.projection('p1')
   ck('F19_public_projection_excludes_private_columns','adminMarkers' not in chk and 'adminRevision' not in chk)
   ck('F20_room_snapshot_after_recovery_complete',len(chk['units'])==3 and chk['turn']=='master' and chk['revision']==3)
   # 6. Unknown command no DB revision
   ack=await attempt(master,{'commandId':'F013_BAD_00001','type':'IMPORT_REAL_VLAB','baseRevision':3})
   ck('F21_unapproved_mechanical_command_denied',ack.get('error')=='INVALID_COMMAND' and obj.store.state()['revision']==3)
   # 7. Concurrent same revision with TWO actual browser-account connections in same role.
   master2,_=await auth(sess,port,'master')
   cmds=[{'commandId':'F013_RACE_0001','type':'END_TURN','baseRevision':3},{'commandId':'F013_RACE_0002','type':'END_TURN','baseRevision':3}]
   acks=await asyncio.gather(attempt(master,cmds[0]),attempt(master2,cmds[1]))
   ck('F22_racing_commands_exactly_one_accepted',sum(x.get('ok') is True for x in acks)==1,acks)
   ck('F23_racing_commands_one_stale',sum(x.get('error')=='STALE_REVISION' for x in acks)==1)
   ck('F24_race_revision_incremented_once',obj.store.state()['revision']==4)
   await master2.close();await p2.close();await p1.close();await master.close()
  await runner.cleanup()
  # 8. Cold restart confirms ACK after commit window recorded
  obj,runner,port=await start(db)
  async with ClientSession() as sess:
   p2,s=await auth(sess,port,'p2')
   ck('F25_reboot_preserves_resolved_unknown_command',s['revision']==4)
   ack=await attempt(p2,cmd3)
   ck('F26_lost_ACK_replay_after_cold_restart_deduplicates',ack.get('deduplicated') is True)
   await p2.close()
  await runner.cleanup()
 out={'research':'PESQ013','source':'PESQ012 room_server.py verified copy; disposable SQLite fault injection','environment':'Python aiohttp localhost real network clients, no Chromium in this suite; lost ACK is deliberately injected AFTER SQL commit','pass':sum(x['pass_'] for x in R),'total':len(R),'fail':[x['name'] for x in R if not x['pass_']],'tests':[{'name':x['name'],'pass':x['pass_'],'detail':x['detail']} for x in R],'caution':['NOT a Cloudflare DO test','No production auth/Android or VLAB mechanics','Client ACK absence after committed action means UNKNOWN until reconciliation; never blindly claim action failed']}
 ROOT.joinpath('results','FAULT_INJECTION_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 print('SUMMARY',out['pass'],'/',out['total']);return out
if __name__=='__main__':
 o=asyncio.run(audit());sys.exit(0 if o['pass']==o['total'] else 2)
