#!/usr/bin/env python3
"""Scope check: the existing PESQ012 invites are fixtures, NOT production authentication.
Observe limits without guessing a real attacker or executing on any external service.
"""
import asyncio,sys,tempfile,json
from pathlib import Path
from aiohttp import ClientSession,web,WSMsgType
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'sources'/'prototype'))
from room_server import create_server
TOKENS={'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'}
R=[]
def ck(s,v):R.append({'name':s,'pass':bool(v)});print(('PASS' if v else 'FAIL'),s,flush=True)
async def audit():
 with tempfile.TemporaryDirectory(prefix='p013_auth_') as td:
  a=create_server(Path(td)/'db.sqlite',TOKENS);runner=web.AppRunner(a.app,access_log=None);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
  async with ClientSession() as client:
   async def join(token):
    s=await client.ws_connect(f'http://127.0.0.1:{port}/ws')
    await s.send_json({'type':'JOIN','token':token})
    m=await s.receive_json(timeout=3)
    return s,m
   # 101 upgrade precedes authentication; resource governance is missing, not exploit proof.
   early=await client.ws_connect(f'http://127.0.0.1:{port}/ws')
   ck('A01_websocket_upgrade_before_auth_frame_possible',not early.closed)
   await early.send_json({'type':'COMMAND','command':{}});m=await early.receive_json(timeout=2)
   ck('A02_pre_auth_action_denied',m.get('code')=='AUTH_REQUIRED');await early.close()
   s1,m1=await join(TOKENS['master']);s2,m2=await join(TOKENS['master'])
   ck('A03_same_fixture_master_bearer_allows_two_active_connections',m1.get('data',{}).get('you')==m2.get('data',{}).get('you')=='master')
   ck('A04_server_registers_two_master_connections',len(a.clients['master'])==2)
   await s1.close();await s2.close()
   s3,m3=await join(TOKENS['master'])
   ck('A05_static_fixture_ticket_reusable_after_disconnect',m3.get('data',{}).get('you')=='master')
   await s3.close()
   bad,mb=await join('WRONG_BAD_TOKEN');ck('A06_invalid_ticket_rejected',mb.get('code')=='UNAUTHORIZED');await bad.close()
   # No token grants semantics for JSON-injected role after join.
   p1,m=await join(TOKENS['p1']);await p1.send_json({'type':'COMMAND','role':'master','command':{'commandId':'AUTH_F013_0001','type':'PRIVATE_MARK','baseRevision':0,'text':'NOPE','role':'master'}})
   reply=await p1.receive_json(timeout=2)
   ck('A07_claimed_master_role_does_not_upgrade_session',reply.get('error')=='FORBIDDEN')
   await p1.close()
   ck('A08_no_fixture_mutations_committed',a.store.state()['revision']==0 and a.store.state()['adminRevision']==0)
  await runner.cleanup()
 out={'name':'PESQ013_AUTH_EDGES','pass':sum(x['pass'] for x in R),'total':len(R),'checks':R,'classification':{'A03_A05':'expected behavior of REUSABLE STATIC TEST bearer invite, NOT production identity authentication','A01':'resource/security hardening needed before public host; NOT proof of exploitable DoS','A07':'server session role bound to server-side token mapping, claim ignored'},'production_requirements':['short-lived master-approved room ticket bound to roomId/participantId/unitId/role','expiry, single-use, revocation, epoch/rotation, rate limiting and WSS trusted origin','no secrets in URL/HTML, per-role projection before send, recheck revocation after DO hibernation','auth gateway should reject nonauthorized upgrade requests where possible']}
 ROOT.joinpath('results','AUTH_GAP_RESULTS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
 print('SUMMARY',out['pass'],'/',out['total']);return out
if __name__=='__main__':
 o=asyncio.run(audit());sys.exit(0 if o['pass']==o['total'] else 2)
