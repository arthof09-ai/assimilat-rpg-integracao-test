#!/usr/bin/env python3
"""PESQ013 WSS localhost with EPHEMERAL SELF-SIGNED CERT, browser trust bypass TEST.
Demonstrates TLS-capable browser WebSocket in lab only; NOT publicly trusted WSS.
"""
import asyncio, tempfile, ssl, subprocess, json, sys
from pathlib import Path
from aiohttp import web
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'sources'/'prototype';sys.path.insert(0,str(SRC))
from room_server import create_server
TOKENS={'master':'PESQ012_TEST_MASTER_0001','p1':'PESQ012_TEST_P1_0000001','p2':'PESQ012_TEST_P2_0000002'}
R=[]
def ck(k,v):
 R.append({'name':k,'pass':bool(v)});print(('PASS' if v else 'FAIL'),k,flush=True)
async def wait(page,predicate,timeout=4):
 for _ in range(int(timeout*20)):
  if await page.evaluate(predicate):return True
  await asyncio.sleep(.05)
 return False
async def main():
 with tempfile.TemporaryDirectory(prefix='p013tls_') as d:
  d=Path(d);key=d/'key.pem';crt=d/'cert.pem'
  subprocess.run(['openssl','req','-x509','-nodes','-newkey','rsa:2048','-days','1','-subj','/CN=127.0.0.1','-keyout',str(key),'-out',str(crt)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
  ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(crt,key)
  a=create_server(d/'state.sqlite',TOKENS);runner=web.AppRunner(a.app,access_log=None);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0,ssl_context=ctx);await site.start();port=site._server.sockets[0].getsockname()[1]
  tpl=(SRC/'index.html').read_text();tpl=tpl.replace('new WebSocket(`ws://${location.host}/ws`)','new WebSocket(window.__TEST_WS_URL__)').replace('crypto.randomUUID()','window.__fixtureUUID()')
  async with async_playwright() as pw:
   browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--ignore-certificate-errors'])
   pages=[];contexts=[];frames={}
   try:
    for who in TOKENS:
     cx=await browser.new_context(ignore_https_errors=True,viewport={'width':390,'height':844});p=await cx.new_page();contexts.append(cx);pages.append(p);frames[who]=[]
     p.on('websocket',lambda ws,who=who:(frames[who].append(('opened',ws.url)),ws.on('framereceived',lambda frame:frames[who].append(('recv',frame)))))
     await p.evaluate('(u)=>{window.__TEST_WS_URL__=u;let n=0;window.__fixtureUUID=()=>"P013_WSS_"+(++n)+"_"+Math.random().toString(36).slice(2)}',f'wss://127.0.0.1:{port}/ws')
     await p.set_content(tpl)
    for p,who in zip(pages,TOKENS):
     await p.evaluate('(t)=>connectToken(t)',TOKENS[who])
    ck('W01_three_WSS_browser_connections',len([1 for fr in frames.values() if any(e[0]=='opened' and e[1].startswith('wss://') for e in fr)])==3)
    ck('W02_three_distinct_roles',all([await p.evaluate('snap.you')==r for p,r in zip(pages,TOKENS)]))
    ck('W03_master_administrative_visible',await pages[0].locator('.adminmark').count()==1)
    ck('W04_players_administrative_absent',all([await p.locator('.adminmark').count()==0 for p in pages[1:]]))
    await pages[0].locator('[data-cmd="END_TURN"]').click()
    ck('W05_three_receive_round_increment',all([await wait(p,'snap.revision===1 && snap.turn==="p1"') for p in pages]))
    await pages[1].locator('[data-cmd="MOVE"]').click()
    ck('W06_three_receive_move_over_WSS',all([await wait(p,'snap.revision===2 && snap.units.find(u=>u.id==="unit-p1").x===4') for p in pages]))
    await pages[2].evaluate('ws.close()')
    ck('W07_browser_close_reflected',await wait(pages[2],'document.querySelector("#flag").textContent==="Desconectado"'))
    await pages[2].evaluate('(t)=>connectToken(t)',TOKENS['p2'])
    ck('W08_reconnect_WSS_snapshot',await pages[2].evaluate('snap.revision===2&&snap.you==="p2"'))
    ck('W09_master_secret_stays_out_of_player_WSS_frames',all(['PLANO PRIVADO' not in json.dumps(frames[r],ensure_ascii=False) for r in ('p1','p2')]))
    ck('W10_WSS_net_frames_real',all([sum(1 for v in frames[r] if v[0]=='recv')>=2 for r in TOKENS]))
   finally:
    for c in contexts:await c.close()
    await browser.close()
  await runner.cleanup()
 out={'research':'PESQ013','tls_type':'localhost self-signed, ephemeral, Chromium --ignore-certificate-errors and ignore_https_errors=True; NOT a trusted public WSS service','pass':sum(x['pass'] for x in R),'total':len(R),'tests':R,'limits':['No account Cloudflare, no certificate authority, no Android physical, no multi-device, no VLAB']}
 ROOT.joinpath('results','WSS_LOOPBACK_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('SUMMARY',out['pass'],'/',out['total'])
 return out
if __name__=='__main__':
 o=asyncio.run(main());sys.exit(0 if o['total']==o['pass'] else 2)
