#!/usr/bin/env python3
"""Deterministic, assumption-labelled Cloudflare Free feasibility calculator.
NOT a Cloudflare bill or benchmark. Consumes actual wire frame sizes from browser.
"""
import json,math,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
wire=json.loads((ROOT/'results'/'BROWSER_REAL_WS_RESULTS.json').read_text())['frames_summary']
roles=list(wire)
received=sum(v['received_bytes_utf8'] for v in wire.values())
sent=sum(v['sent_bytes_utf8'] for v in wire.values())
inmessages=sum(v['sent'] for v in wire.values())
outmessages=sum(v['received'] for v in wire.values())
scenarios=[]
for hrs,actions_min,rows_action in [(4,1,2),(4,6,2),(4,60,2),(8,60,3),(4,500,2)]:
 actions=hrs*60*actions_min;ws_handshakes=3
 req=ws_handshakes+math.ceil(actions/20) # billing-equivalent, not exact account analytics
 writes=actions*rows_action
 # duration: illustrative MAX if pinned all session, 128MB reserved; real hibernation lower
 gbsec_pinned=hrs*3600*0.125
 scenarios.append({'session_hours':hrs,'accepted_actions_per_min':actions_min,'assumed_SQL_rows_written_per_action':rows_action,'actions':actions,'DO_request_equivalent_approx':req,'DO_SQL_rows_written_approx':writes,'DO_pinned_no_hibernation_GBs_approx':gbsec_pinned,'within_DO_free_100k_requests':req<100000,'within_DO_free_100k_rows_written':writes<100000,'within_DO_free_13000_GBs_if_pinned':gbsec_pinned<13000})
r={'classification':'MODELLING only, not Cloudflare runtime/actual billing; CPU, indexes, reads, alarms, Worker requests, reconnection and failures omitted','official_limits_checked':['100000 DO requests/day','13000 GB-s/day','100000 SQLite rows written/day','5000000 SQLite rows read/day','5GB SQLite stored total','20 incoming WebSocket messages per billed compute request'],'from_actual_browser_fixture':{'browser_contexts':3,'sent_frames':inmessages,'received_frames':outmessages,'sent_bytes':sent,'received_bytes':received,'max_received_frame_bytes':max(v['max_received_frame_bytes'] for v in wire.values()),'average_received_bytes_per_frame':round(received/outmessages,1)},'scenarios':scenarios,'warnings':['Do not use for money charging; free quotas depend on all project traffic.','Rows per action counts can differ when creating indexes / audit receipts.','Cloudflare account registration/card availability not audited.','No internet latency or Android battery measured.']}
(ROOT/'results'/'QUOTA_MODELLING_013.json').write_text(json.dumps(r,indent=2,ensure_ascii=False))
print(json.dumps(r,ensure_ascii=False,indent=2));
