#!/usr/bin/env python3
"""PESQ-013 — explicit transport framing limits on PESQ-012 synthetic WS server."""
import asyncio,json,sys,tempfile
from pathlib import Path
from aiohttp import web,ClientSession,WSMsgType
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'sources'/'prototype'))
from room_server import create_server
R=[]
def ck(k,v):R.append({'name':k,'pass':bool(v)});print(('PASS' if v else 'FAIL'),k,flush=True)
async def f():
 with tempfile.TemporaryDirectory(prefix='p013frame_') as td:
  a=create_server(Path(td)/'db.sqlite',{'master':'A'});runner=web.AppRunner(a.app,access_log=None);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
  async with ClientSession() as s:
   w=await s.ws_connect(f'http://127.0.0.1:{port}/ws');await w.send_str('not-json');m=await w.receive_json(timeout=3)
   ck('Z01_invalid_JSON_returns_error_without_auth',m.get('code')=='INVALID_JSON')
   ck('Z02_invalid_JSON_does_not_mutate_state',a.store.state()['revision']==0)
   await w.send_json({'type':'JOIN','token':'A'});m=await w.receive_json(timeout=3)
   ck('Z03_valid_auth_after_invalid_JSON',m.get('type')=='SNAPSHOT')
   await w.send_json({'type':'UNKNOWN_ENVELOPE'});m=await w.receive_json(timeout=3)
   ck('Z04_unknown_envelope_denied',m.get('code')=='BAD_ENVELOPE')
   await w.send_str('x'*9000)
   m=await w.receive(timeout=3)
   ck('Z05_oversized_9KB_frame_disconnects_WS',m.type in (WSMsgType.CLOSE,WSMsgType.CLOSING,WSMsgType.CLOSED,WSMsgType.ERROR))
   ck('Z06_oversize_no_state_commit',a.store.state()['revision']==0)
   await w.close()
  await runner.cleanup()
 out={'tests':R,'pass':sum(v['pass'] for v in R),'total':len(R),'source':'PESQ012 server max_msg_size=8192, real aiohttp localhost WS; NOT Cloudflare max 32MiB','note':'Client must handle close/reconnect; actual payload limits are an application contract distinct from provider maximum.'}
 ROOT.joinpath('results','FRAME_LIMITS_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('SUMMARY',out['pass'],'/',out['total']);return out
if __name__=='__main__':sys.exit(0 if (o:=asyncio.run(f()))['pass']==o['total'] else 2)
