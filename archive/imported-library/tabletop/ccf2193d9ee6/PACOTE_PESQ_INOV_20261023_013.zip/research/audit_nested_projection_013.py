#!/usr/bin/env python3
"""PESQ013 — nested projection canary on *poisoned synthetic DB state*.
This is a research-level hazard model, NOT a remote exploit in original TEST33/PESQ012.
"""
import sys,json,tempfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'sources'/'prototype'))
from room_server import RoomStore
OUT=ROOT/'results';R=[]
def check(label,v,detail=None):
 R.append({'test':label,'pass':bool(v),'detail':detail});print(('PASS' if v else 'FAIL'),label,flush=True)

def clean_event(event):
 if not isinstance(event,dict):return {'kind':'UNKNOWN'}
 k=event.get('kind')
 if k=='SYNTHETIC_TURN' and event.get('active') in ('master','p1','p2'):
  return {'kind':k,'active':event['active']}
 if k=='SYNTHETIC_MOVE' and isinstance(event.get('unitId'),str) and all(type(event.get(t)) is int and 0<=event[t]<7 for t in ('x','y')):
  return {'kind':k,'unitId':event['unitId'],'x':event['x'],'y':event['y']}
 if k=='MOCK_VISUAL_ACTION_ONLY' and all(isinstance(event.get(t),str) for t in ('unitId','targetId')):
  return {'kind':k,'unitId':event['unitId'],'targetId':event['targetId'],'mechanics':'NOT_EXECUTED'}
 return {'kind':'UNKNOWN'}

def clean_marker(m):
 if not isinstance(m,dict):return None
 id,scene,x,y,text=(m.get(n) for n in ('id','sceneId','x','y','text'))
 if not all(isinstance(v,str) and 1<=len(v)<=80 for v in (id,scene,text)) or not all(type(v) is int and 0<=v<7 for v in (x,y)):return None
 return {'id':id,'sceneId':scene,'x':x,'y':y,'text':text}

def scrub_public(view):
 clean={k:json.loads(json.dumps(view[k],ensure_ascii=False)) for k in ('schema','room','revision','turn','turnNumber','grid','units','you')}
 clean['markers']=[v for m in view.get('markers',[]) if (v:=clean_marker(m)) is not None]
 clean['lastEvent']=clean_event(view.get('lastEvent'))
 return clean

def main():
 with tempfile.TemporaryDirectory(prefix='p013_projection_') as td:
  db=RoomStore(Path(td)/'db.sqlite',{'master':'fixtureA','p1':'fixtureB','p2':'fixtureC'})
  ck='MASTER_PRIVATE_CANARY_X013';
  orig=db.projection('p1');check('P01_baseline_no_admin',not any(k in orig for k in ('adminMarkers','adminRevision')))
  poisoned=db.state();poisoned['lastEvent']={'kind':'SYNTHETIC_MOVE','unitId':'unit-p1','x':4,'y':2,'internalMasterOnly':ck}
  poisoned['markers'][0]['adminSourceId']=ck
  db.db.execute('UPDATE room SET payload=? WHERE id=?',(json.dumps(poisoned,ensure_ascii=False),'SYNTH-ROOM'))
  raw=db.projection('p1')
  # RED demonstrates latent *nested* data hazard under deliberate backend poisoning.
  check('P02_poisoned_lastEvent_leaks_to_player_in_original_PESQ012_projection',ck in json.dumps(raw['lastEvent']))
  check('P03_poisoned_marker_extension_leaks_to_player_in_original_PESQ012_projection',ck in json.dumps(raw['markers']))
  projected=scrub_public(raw)
  check('P04_nested_event_canary_removed_by_strict_allowlist',ck not in json.dumps(projected['lastEvent']))
  check('P05_nested_marker_canary_removed_by_strict_allowlist',ck not in json.dumps(projected['markers']))
  check('P06_player_has_no_top_level_admin',not any(k in projected for k in ('adminMarkers','adminRevision')))
  check('P07_allowed_public_event_still_works',projected['lastEvent']=={'kind':'SYNTHETIC_MOVE','unitId':'unit-p1','x':4,'y':2})
  check('P08_allowed_marker_still_works',len(projected['markers'])==1 and projected['markers'][0]['id']=='public-1')
  check('P09_unknown_event_fails_closed',clean_event({'kind':'CUSTOM_MECHANICAL_DAMAGE','Vida':123,'adminSecret':ck})=={'kind':'UNKNOWN'})
  check('P10_mock_action_fixed_mechanics_flag',clean_event({'kind':'MOCK_VISUAL_ACTION_ONLY','unitId':'A','targetId':'B','mechanics':'DAMAGE_10000','adminSecret':ck})=={'kind':'MOCK_VISUAL_ACTION_ONLY','unitId':'A','targetId':'B','mechanics':'NOT_EXECUTED'})
  check('P11_bad_coordinates_do_not_flow',clean_event({'kind':'SYNTHETIC_MOVE','unitId':'A','x':-10,'y':2})=={'kind':'UNKNOWN'})
  check('P12_marker_extras_never_exported',set(projected['markers'][0])=={'id','sceneId','x','y','text'})
  check('P13_malformed_marker_fail_closed',clean_marker({'id':'x','sceneId':'arena','x':-1,'y':1,'text':'hi'}) is None)
  check('P14_master_still_gets_private_data_on_separate_master_channel',len(db.projection('master')['adminMarkers'])==1)
  check('P15_deep_nested_note_NOT_in_public_json',ck not in json.dumps(projected,ensure_ascii=False))
  db.close()
  out={'source':'PESQ012 RoomStore poisoned ONLY by direct SQLite update inside disposable temp fixture','classification':'P02/P03 observe an intentionally injected hazard, NOT a remotely reachable exploit or bug found in TEST33','pass':sum(x['pass'] for x in R),'total':len(R),'results':R,'warning':'sanitizer is an experimental contract oracle, not a production auth layer'}
  OUT.joinpath('NESTED_PROJECTION_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
  print('SUMMARY',out['pass'],'/',out['total']);return out
if __name__=='__main__':sys.exit(0 if (o:=main())['pass']==o['total'] else 2)
