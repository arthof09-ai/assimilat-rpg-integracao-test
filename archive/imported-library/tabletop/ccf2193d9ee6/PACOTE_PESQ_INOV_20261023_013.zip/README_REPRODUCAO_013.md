# PESQ-INOV-20261023-013 — Como reproduzir as provas

**Não é o aplicativo Tabletop oficial**, nem Cloudflare DO implantado, nem VLAB. É somente TEST autoral sobre cópia da bancada PESQ012.

Requisitos observados: Python 3.13, `aiohttp`, `playwright`, Chromium instalado em `/usr/bin/chromium`, `openssl` (WSS local), Linux. Executados localmente sem custo adicional. Sem internet, credenciais Cloudflare ou Android físico para rodar as suites.

Na raiz do ZIP extraído:

```bash
bash RUN_TESTES_013.sh
```

Reexecuta os scripts de PESQ013, não as 43+8 rotinas da PESQ012:

1. `research/audit_three_browser_real_ws_013.py` — 33 verificações em 3 **contextos Chromium reais via WS**. O HTTP localhost é bloqueado no ambiente onde a prova foi produzida; por isso o HTML é carregado por `page.set_content`, com endereço WS de teste e gerador experimental de commandId adaptados **somente em memória**. O backend é cópia EXATA de `sources/prototype/room_server.py` da PESQ012. Salva capturas próprias.
2. `research/audit_wss_loopback_013.py` — 10 verificações em WSS TLS real localhost com certificado AUTOSSINADO de 1 dia, gerado só em pasta temporária. Chromium usa bypass deliberado de confiança; **não equivale a HTTPS/WSS público seguro**.
3. `research/audit_commit_unknown_013.py` — 26 verificações de falhas SQLite e ACK perdido depois do commit. Tracebacks `test_abort_update`, `test_abort_receipt`, `SYNTHETIC_LOST_ACK_AFTER_COMMIT` são **injetados propositalmente** e constam em `results/FAULT_EXPECTED_EXCEPTIONS.log`, se produzidos pelo runner; não reprovar a suite por essas linhas quando exit code=0.
4. `research/audit_nested_projection_013.py` — 15 verificações de canário privado injetado diretamente em SQLite e sanitização allowlist recursiva experimental; **não prova exploit remoto do Tabletop**.
5. `research/audit_auth_edges_013.py` — 8 verificações de fraquezas assumidas de convites estáticos e controles que já funcionam. **Não é autenticação de produção**.
6. `research/audit_frame_limits_013.py` — 6 verificações de JSON inválido e frame maior que 8192 bytes definido pelo protótipo.
7. `research/quota_model_013.py` — cenários determinísticos, NÃO uso real de Cloudflare.

**Denominadores próprios:** 33+10+26+15+8+6 = **98/98 verificações** no ambiente reportado; número agregado serve apenas para inventário. Os subtestes têm significados distintos e PASS de canário = injeção detectada/mitigação sintética, não proteção real da Party.

**Fixtures preservadas:** `sources/prototype/room_server.py` e `sources/prototype/index.html` são cópias byte-idênticas do ZIP PESQ012 SHA256 `3a40d0a17bef49d521895483ca93a652c8bf732e8f945980415a6136169b311f`; códigos de TEST33, VLAB, Codex e Party NÃO incluídos no pacote.

**Reprodução fria:** extraia o ZIP em um diretório diferente do local onde foi produzido e execute novamente o runner. Compare exit code, JSONs PASS/FAIL, manifesto, hashes e CRC. Screenshots podem variar em pixels entre versões/ambientes do Chromium; conferir os testes funcionais e procedência, não igualdade visual byte a byte.

**Permissões:** nunca fazer bind de servidor de prova em `0.0.0.0`; usa `127.0.0.1` e convites totalmente sintéticos. Não implantar os arquivos da bancada em ambiente acessível pela internet: não possuem login/controle antiabuso próprios de produção, nem regras oficiais de combate.
