# PROJETO RPG ASSIMILAÇÃO — LABORATÓRIO DO INOVADOR
## Intercâmbio técnico: engenharia de jogos e Virtual Tabletop (VTT)

**Data de pesquisa:** 22/10/2026  
**Identidade:** Comestre Inovador, MESTRE-SIDE  
**Natureza:** pesquisa técnica + protótipo TEST; **não canônico**  
**Mandato:** celular Android, custo adicional R$ 0, sem recriar VLAB/DMG/LEVEL-UP/CRAFT ou interferir nas originais.  
**Estado de Notion:** HOLD. Duas tentativas de consulta/identificação retornaram `link_id must identify an eligible linked account`. **Não houve gravação ou leitura autenticada do Laboratório do Inovador.**

## 1. Objetivo e pergunta de pesquisa

**Questão:** Como construir uma mesa digital interativa própria do RPG Assimilação — comparável em experiência ao Tabletop Simulator ou a simuladores digitais de RPG — usando referências abertas, sem copiar regras, arte e código sem licença, sem custos extras, com forte separação Mestre/Party e mantendo os motores existentes como verdade de regras?

**Conclusão:** uma camada web de apresentação Android-first, com componentes substituíveis e eventos explícitos, é o melhor primeiro caminho. Projeto do tipo VTT **não** deve se tornar novo motor de cálculo. A transição de um HTML local para PWA e depois servidor multiplayer é incremental, exigindo validação real e orçamento explícito para hospedagem quando e se necessária.

**Escopo de evidência:** páginas oficiais, documentação e repositórios públicos. As funcionalidades e licenças são verificadas *conforme publicadas pelas fontes*, mas **nenhum projeto inteiro foi auditado linha a linha**, nem se executaram seus sistemas em produção. Não houve download ou incorporação de código de terceiros ao protótipo TEST 03. Não houve teste no Android físico do Mestre.

## 2. Referências analisadas e o que adaptar

| Referência / endereço | Evidência publicada | O que aproveitar como IDEIA / interface | Alerta |
|---|---|---|---|
| [MapTool](https://github.com/RPTools/maptool) | VTT maduro, iluminação, parede, visão, tokens, iniciativa. AGPL-3.0. | Modelo de obstruções, visibilidade por token, camadas. | Programa Java com binários desktop; código AGPL precisa cuidado. |
| [Owlbear Rodeo SDK](https://docs.owlbear.rodeo/extensions/getting-started/) | Extensões com manifest, ações, menus, ferramentas; SDK MIT. | Microinterfaces plugáveis e contratos de extensão. | SDK MIT não torna a plataforma toda livre/relicenciável. |
| [FreeBeeGee](https://github.com/ludus-leonis/FreeBeeGee) | Quadrado/hex, peças, camadas, salas, backup JSON/ZIP; AGPL. | Editor de mapas, biblioteca de peças. | Suporte mobile/toque reconhecido como limitado. |
| [VirtualTabletop.io](https://github.com/ArnoldSmith86/virtualtabletop) | Mesa genérica e jogos compartilhados, GPLv3. | Estado de cena e objetos configuráveis. | Copyleft; arte dos jogos possui licenças próprias. |
| [Open Source RPG — Ordem Paranormal inspired](https://github.com/jvdutrag/open-source-rpg) | Next.js, MySQL, Prisma, Socket.io; ficha, mestre, OBS; MIT. | Padrões de painel Mestre e apresentação de fichas. | Complexidade excessiva para primeira fase offline. |
| [Simple VTT](https://github.com/TomBen-org/simple-vtt) | Canvas, TypeScript, WebSocket, linhas/círculos/cones, cenas; MIT. | Ferramentas de régua/áreas, separação cena/medição. | README informa que não há login e todos têm acesso completo: **incompatível** com sigilo Mestre/Party sem redesenho. |
| [Foundry — guia desenvolvimento de sistemas](https://foundryvtt.com/article/system-development/) | Modelo de dados Actor/Item, sistema modular, recomenda começar pequeno. | Contratos mínimos e separação dados vs. visualização. | Não assumir licença de todo código/plataforma. |
| [Tabletop Simulator Lua API](https://api.tabletopsimulator.com/) | Scripts globais e por objeto; estados no save JSON. | Entender automações por objeto e eventos de tabuleiro. | Não transplantar seu runtime/produtos proprietários para HTML. |
| [Pokérole VTT](https://github.com/slateharbor/pokerole-vtt) | Dois HTMLs autônomos Mestre/player, código MIT, fontes/arte com atribuições distintas. | Empacotamento portátil e separação de UIs. | Não aproveitar conteúdo proprietário Pokémon; parte da sincronização deve ser revista. |

### 2.1 Bibliotecas recomendadas para investigação prática

| Tecnologia | Função possível | Decisão no Assimilação |
|---|---|---|
| [Phaser](https://docs.phaser.io/phaser/concepts/input) | Entrada unificada de toque, mouse e gamepad; cena e sprites | P2: protótipo isolado se DOM ficar lento ou se desejarmos animações. |
| [PixiJS 8](https://pixijs.com/8.x/guides/components/events) | Renderização de muitos tokens/efeitos, hit testing e pointer events | P2: provável candidato para renderizador, sem substituir contratos. |
| [PathFinding.js](https://github.com/qiao/PathFinding.js) | A*, BFS, Dijkstra para grades; MIT | P1: estudar algoritmo/testes e comparar com BFS TEST 02. Biblioteca modifica grade no cálculo, devendo clonar. |
| [boardgame.io](https://github.com/boardgameio/boardgame.io) | Fluxos por turno, eventos e logs, multiplayer MIT | P2/P3: estudar máquina de estados **sem** transplantar regra oficial. |
| [Colyseus](https://docs.colyseus.io/) | Salas e servidor autoritativo com sincronização em tempo real; MIT | P3: candidato multiplayer se houver servidor seguro e controle de acesso. |
| [Yjs](https://github.com/yjs/yjs) | Sincronização colaborativa de dados por CRDT; MIT | Apenas mapas/anotações simultâneas. Nunca usar sincronização permissiva para revelar mestre-only. |
| [MDN Tilemaps](https://developer.mozilla.org/en-US/docs/Games/Techniques/Tilemaps) | Grade lógica, colisão, editor e renderização eficiente | P1: base conceitual do tabuleiro. |
| [MDN PWA](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable) | Instalação Android e offline mediante HTTPS/localhost e manifest | P2: quando houver local de hospedagem permitido e arquitetura de atualização. |

### 2.2 Recursos gráficos gratuitos

- [Screaming Brain Studios — Tiny Top Down Pack](https://screamingbrainstudios.itch.io/tiny-top-down-pack): peças 32×32, declaradas CC0.
- [Screaming Brain Studios — Top Down Dungeon Pack](https://screamingbrainstudios.itch.io/top-down-dungeon-pack): mosaicos de masmorra declarados CC0.
- [Foozle — Lucifer Dungeon Tileset](https://foozlecc.itch.io/lucifer-dungeon-tileset): tiles 32×32 CC0.

Arquivos e arte **não foram incorporados** nesta entrega. Mesmo em CC0, conferir a licença no arquivo exato antes de redistribuir.

### 2.3 Leituras profissionais (currículo do Co-mestre)

1. [Game Programming Patterns — capítulos](https://gameprogrammingpatterns.com/contents.html): Command, State, Observer, Event Queue, Component, Game Loop; li a estrutura e o capítulo Game Loop. Aplicação: ações auditáveis, reversão e desacoplamento do renderizador.
2. [MDN — Tilemaps](https://developer.mozilla.org/en-US/docs/Games/Techniques/Tilemaps): separar grade lógica de sprite visual.
3. [Phaser — Input](https://docs.phaser.io/phaser/concepts/input): unificação de cliques/toque e seleção de objetos.
4. [PixiJS — Events](https://pixijs.com/8.x/guides/components/events): interatividade por ponteiro em objetos gráficos.
5. [Foundry — System development](https://foundryvtt.com/article/system-development/): modelo de dados antes de interface detalhada.
6. [boardgame.io — Phases](https://boardgame.io/documentation/phases.html): fases e turnos organizados; usar somente se compatível com o VLAB.
7. [Colyseus + Phaser tutorial](https://docs.colyseus.io/learn/tutorial/phaser): sincronização multiplayer e separação de simulação/renderização.
8. [MDN — PWA Best Practices](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Best_practices): acessibilidade, toque, offline, responsividade.

## 3. Análise de arquitetura

### 3.1 Caminho recomendado — não duplicar motores

```text
[FONTES CANÔNICAS: Notion / VLAB / DMG / LEVEL-UP]
                      │
             CÓPIA TEST VALIDADA
                      ▼
     [EXPORTADOR ADAPTADOR READ-ONLY — futuro]
                      │
             JSON tipado, v1, versionado
                      ▼
          [FIREWALL DE DADOS MESTRE]
            ├── Dados autorizados ao Mestre
            └── Dados filtrados e aprovados à Party (futuro)
                      ▼
             [INTERFACE ARENA WEB]
         mapa · tokens · eventos · camadas
                      │
           interações e intenção do usuário
                      ▼
       [NO PRESENTE: TEST LOCAL SEM ESCRITA]
       [NO FUTURO: resolver oficial mediante gate]
```

**Regra principal:** o HTML **não calcula** dano, redução de dano, PA, iniciativa oficial, cura, transformação ou nível. Ele mostra números/eventos retornados pelo sistema correto, quando este for homologado. Não inferir 'real' de um rótulo no JSON; verificar ID, proveniência, integridade e versão externamente.

### 3.2 Segurança: Mestre e Party são visões diferentes

No protótipo **somente Mestre** não há saída para outras pessoas. No futuro, se existir multiplayer, **não enviar dados ocultos ao navegador da Party**. Esconder por CSS/JavaScript não é proteção; o servidor precisa construir mensagens com campos mínimos, autorização por papel e sessão. Sem servidor com ACL testada, permanece Mestre-only e offline.

### 3.3 Offline e hospedagem

- **P0 TEST:** HTML único que roda sem internet, salvo no aparelho; import/export local JSON.
- **P1:** melhoria de toque, mapa, zoom, medidor, overlays; sem rede.
- **P2:** eventual PWA em HTTPS/localhost com manifest e cache offline (após decidir hospedagem gratuita permitida).
- **P3:** sessões reais multiplayer e autoria de Mestre no servidor. Serviços cloud gratuitos podem impor limites/alterar políticas; nenhum foi contratado.

### 3.4 Licenciamento (não misturar cegamente)

- MIT: permite normalmente usar, modificar e distribuir, preservando avisos de copyright/licença.
- GPLv3 e AGPLv3: copyleft que pode afetar distribuição e, em AGPL, serviços acessados pela rede; revisar obrigações antes de usar código.
- CC0: adequado para arte de cenários quando declaração de autoria/licença do arquivo for comprovada.
- **Código publicamente acessível sem licença explícita NÃO está automaticamente autorizado para cópia/redistribuição.**
- Conceitos e algoritmos gerais podem inspirar implementação independente. Não copiar identidade visual, marcas, assets, narrativas ou regras protegidas de outros RPGs.

## 4. Análise do TEST 02 recuperado

**Fonte local verificada:** `ARENA_INOVADOR_TEST_02.html` com checkpoint e ZIP existentes nesta conversa.

**Aproveitar:** células touch, BFS ortogonal, obstáculos, zonas perigosas, alerta de saída de adjacência, recuo seguro manual, desfazer, eventos, JSON de cenário e testes Playwright. Já havia teste 35/35 documentado na sessão anterior; não contei esses 35 como reexecutados nesta pesquisa.

**Correções antes de uso real:** todas as unidades usavam alcance sintético e 4 passos; remover números fictícios quando conectar dados de verdade; impedir visualização de informações ocultas para Party; investigar performance 20×20; validar comportamento Android real e gesto de pinça; definir propriedades oficiais e critérios de raio, alcance, cobertura e terreno no VLAB antes de qualquer cálculo.

## 5. Entrega nova: Observatório VLAB TEST 03

**Arquivo:** `ADAPTADOR_VLAB_READONLY_TEST_03.html`  
**Fixture:** `VLAB_TEST03_FIXTURE_SINTETICA.json`  
**Código de teste:** `test_observatorio.py`  
**Preview:** `OBSERVATORIO_TEST_03_MOBILE.png`

**Poderes:** arquivo JSON TEST isolado → mapa com tokens, obstáculos, lista de eventos, navegação por linha do tempo, visualização de posições registradas. **Sem** estimar, calcular ou efetivar qualquer combate. **Sem** conexão ou writes. Trata `source.kind='VLAB_TEST_EXPORT'` como uma declaração da fonte, **não prova de autenticidade**, logo só pode ser alimentado por um exportador confiável após autorização e validação.

**Contrato de amostra:** `schema='assim.lab.vlab.readonly.v1'`; `source={kind:'SYNTHETIC_FIXTURE', scope:'MESTRE_ONLY', isolatedCopy:true, reference, exportedAt}`; `grid={width,height,walls}`; `units[]`; `events[]={id,type,title,description,frame:{positions:{id:[x,y]}}}`.

**Limites:** 5×5, 7×7, 10×10 e 20×20; no máximo 25 unidades; 100 eventos; arquivos até 250 KB; posições completas sem sobreposição de tokens ou paredes; texto incluído via `textContent`; nada executado de arquivos importados. Formato atual exige snapshot integral por evento: mais seguro e fácil de depurar, porém deve ser reavaliado para casos grandes.

**Regressão efetivamente executada em 22/10/2026:** **35/35 PASS** em Chromium Linux headless, viewport móvel 390×844, Playwright. Inclui limite visual 20×20, navegação, UI sem erro JS, bloqueios de entrada maliciosa e violação de escopo, posições inválidas e IDs duplicados. **PASS digital somente.** Não é benchmark formal, nem Android físico, nem NAC-PASS canônico.

## 6. Próxima sequência de pendências, sem criar novos motores

| Ordem | Pendência | Critério de saída verificável | Dependência |
|---|---|---|---|
| 1 | Reautenticar Notion e ler Lab do Inovador + BOOTSTRAP-COMESTRE, NAC-CONT-03, NAC-NORM-01, NAC-PASS, Diário | IDs canônicos, leitura em tempo real e norma vigente registrada | Conexão Notion elegível |
| 2 | Inventariar TEST 01 antigo sem duplicar | Fonte/ID/hash ou status não autenticado | Busca no laboratório / anexos |
| 3 | Android físico: abrir TEST 02 e TEST 03; testes toque, 7×7/20×20, exportação e importação | Evidência do aparelho do Mestre; falhas reproduzíveis | Experiência real |
| 4 | Encontrar schema REAL de eventos VLAB via fonte autorizada **somente leitura** | Campos, unidades e proveniência confirmados, contrato mapeado | VLAB autenticado |
| 5 | Exportador explícito por cópia TEST, sem alterações no VLAB | JSON de evento idempotente, hashes, validação, nenhuma escrita na origem | Schema v1 e revisão de permissões |
| 6 | Comparar algoritmo de percurso com PathFinding.js e com VLAB | casos de obstáculos, adjacência, diagonal e empate determinísticos | regras VLAB lidas |
| 7 | Testar Phaser ou PixiJS em laboratório sem substituir TEST 02 | protótipos com métricas de FPS, memória e toque em Android | feedback Mestre, fixtures |
| 8 | Planejar publicador PWA / multiplayer seguro | autorização/ACL, não vazamento Mestre→Party, custo R$0 confirmado | canonização e políticas |

## 7. Checkpoint e gate

- **LAST VERIFIED:** TEST 02 anterior disponível com checksum ainda não revalidado nesta etapa; TEST 03 construído do zero e 35/35 testes de UI locais aprovados.
- **FIRST PENDING:** conexão Notion e leitura integral das normas vigentes. A própria fonte VLAB não foi consultada; o TEST 03 só possui formato de interoperabilidade PROPOSTO e fixture inventada.
- **NÃO FEITO:** nenhum push GitHub, nenhum merge, nenhum Notion escrito, nenhuma execução no Android físico, nenhuma instalação de biblioteca externa ou reuso de código copiado dos VTTs.
- **Gate:** TEST 03 **PASS digital restrito**; validação de fonte, sigilo operacional em multiplayer, testes físicos e NAC-PASS oficial **HOLD**.

## 8. Referências (conferência de links)

*Última consulta via buscas web em 22/10/2026.* Consultar novamente termos de licença e versões antes de download/integração.

- https://github.com/RPTools/maptool
- https://docs.owlbear.rodeo/extensions/getting-started/
- https://github.com/owlbear-rodeo/sdk
- https://github.com/ludus-leonis/FreeBeeGee
- https://github.com/ArnoldSmith86/virtualtabletop
- https://github.com/jvdutrag/open-source-rpg
- https://github.com/TomBen-org/simple-vtt
- https://github.com/slateharbor/pokerole-vtt
- https://foundryvtt.com/article/system-development/
- https://api.tabletopsimulator.com/
- https://docs.phaser.io/phaser/concepts/input
- https://pixijs.com/8.x/guides/components/events
- https://github.com/qiao/PathFinding.js
- https://github.com/boardgameio/boardgame.io
- https://docs.colyseus.io/
- https://github.com/yjs/yjs
- https://developer.mozilla.org/en-US/docs/Games/Techniques/Tilemaps
- https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable
- https://gameprogrammingpatterns.com/contents.html
- https://screamingbrainstudios.itch.io/tiny-top-down-pack
- https://foozlecc.itch.io/lucifer-dungeon-tileset
