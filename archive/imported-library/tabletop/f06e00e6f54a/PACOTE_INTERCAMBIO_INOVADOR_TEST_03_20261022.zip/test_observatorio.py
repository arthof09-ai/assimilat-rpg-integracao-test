from pathlib import Path
import json
from playwright.sync_api import sync_playwright
HTML=Path(__file__).with_name('ADAPTADOR_VLAB_READONLY_TEST_03.html').read_text()
checks=[]
def check(name,predicate):
    assert predicate,name
    checks.append(name)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
    errors=[]
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.set_content(HTML,wait_until='load')
    check('sem erros no início',not errors)
    check('inicia sem estado',page.locator('#detail').inner_text()=='Sem evento')
    check('botões desabilitados vazios',page.locator('#next').is_disabled() and page.locator('#prev').is_disabled())
    page.locator('#demo').click()
    state=page.evaluate('window.__vlabObserverTest.get()')
    check('fixture aprovada',state['source']['kind']=='SYNTHETIC_FIXTURE')
    Path(__file__).with_name('VLAB_TEST03_FIXTURE_SINTETICA.json').write_text(json.dumps(page.evaluate('window.__vlabObserverTest.fixture'),ensure_ascii=False,indent=2))
    check('quatro eventos carregados',page.locator('#stepLabel').inner_text()=='Evento 1/4')
    check('49 casas de mapa',page.locator('.tile').count()==49)
    check('3 tokens visíveis',page.locator('.tok').count()==3)
    check('3 paredes',page.locator('.tile.wall').count()==3)
    check('quatro itens da timeline',page.locator('#events button').count()==4)
    check('avançar habilitado',page.locator('#next').is_enabled())
    page.locator('#next').click()
    check('avança',page.locator('#stepLabel').inner_text()=='Evento 2/4')
    check('posição marcada',page.locator('.tile.focus').count()==1)
    page.locator('#seek').fill('3')
    check('slider pula evento',page.locator('#stepLabel').inner_text()=='Evento 4/4')
    check('next desabilitado último',page.locator('#next').is_disabled())
    page.locator('#prev').click()
    check('voltar funcional',page.locator('#stepLabel').inner_text()=='Evento 3/4')
    valid=page.evaluate('window.__vlabObserverTest.validate(window.__vlabObserverTest.fixture)')
    check('validador aceita schema',valid is None)
    def mutate(script):return page.evaluate('''(script)=>{const x=structuredClone(window.__vlabObserverTest.fixture);(new Function('x',script))(x);return window.__vlabObserverTest.validate(x)}''',script)
    for name,code in [
        ('rejeita cânone','x.source.isolatedCopy=false'),
        ('rejeita Party','x.source.scope="PARTY"'),
        ('rejeita origem desconhecida','x.source.kind="NOTION"'),
        ('rejeita markup','x.units[0].label="<img src=x>"'),
        ('rejeita evento duplicado','x.events[1].id=x.events[0].id'),
        ('rejeita unidade duplicada','x.units[1].id=x.units[0].id'),
        ('rejeita sobreposição de unidades','x.events[0].frame.positions.u2=[1,1]'),
        ('rejeita unidades fora da grade','x.events[0].frame.positions.u1=[99,0]'),
        ('rejeita unidade em parede','x.events[0].frame.positions.u1=[3,1]'),
        ('rejeita snapshot parcial','delete x.events[1].frame.positions.u1'),
        ('rejeita mapas desconhecidos','x.grid.width=11;x.grid.height=11'),
        ('rejeita eventos extra','x.events=Array(101).fill(x.events[0])'),
        ('rejeita evento desconhecido','x.events[0].type="WRITE_VLAB"'),
        ('rejeita nome estranho','x.source.reference="<script>"'),
        ('rejeita parede duplicada','x.grid.walls.push([3,1])')]:
        check(name, isinstance(mutate(code),str))
    before=page.evaluate('JSON.stringify(window.__vlabObserverTest.get())')
    page.locator('#clear').click()
    check('limpar apaga memória local',page.evaluate('window.__vlabObserverTest.get()') is None)
    check('sem erro de execução',not errors)
    # test 20x20 legitimate input
    page.evaluate('''()=>{let x=structuredClone(window.__vlabObserverTest.fixture);x.grid.width=20;x.grid.height=20;window.__vlabObserverTest.load(x)}''')
    check('20x20 renderiza 400 casas',page.locator('.tile').count()==400)
    check('viewport móvel sem overflow horizontal externo',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
    page.evaluate('window.__vlabObserverTest.load(window.__vlabObserverTest.fixture)')
    page.screenshot(path=str(Path(__file__).with_name('OBSERVATORIO_TEST_03_MOBILE.png')),full_page=True)
    browser.close()
print(f'{len(checks)}/{len(checks)} PASS')
for i,name in enumerate(checks,1): print(f'{i:02d} PASS {name}')
