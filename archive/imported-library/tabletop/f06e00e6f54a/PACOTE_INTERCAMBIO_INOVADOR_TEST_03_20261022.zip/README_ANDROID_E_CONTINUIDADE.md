# ASSIMILAÇÃO • LAB INOVADOR • TEST 03

## Como experimentar no Android (sem instalar programas pagos)

1. Salve `ADAPTADOR_VLAB_READONLY_TEST_03.html` no celular e abra pelo navegador/visualizador HTML que aceite arquivos locais. A compatibilidade depende do navegador e gerenciador de arquivos. Se o app do ChatGPT não oferecer prévia HTML executável, use a opção de salvar e abrir em navegador; não se afirma integração à conversa.
2. Toque em **Carregar exemplo fictício**. Percorra a barra da linha do tempo e use as setas.
3. Toque em **Limpar visualizador**, depois **Importar JSON TEST** e selecione `VLAB_TEST03_FIXTURE_SINTETICA.json`.
4. Confira a troca de posições ao avançar. Nada disso usa fichas reais. Não enviar arquivos Mestre-only à Party.
5. Experimente também o tabuleiro 20×20 da Arena TEST 02 e registre se há travamentos, falta de zoom ou erros no toque.

## Para desenvolvedores

`python test_observatorio.py` exige Playwright Python e Chromium instalados. Se o executável não estiver em `/usr/bin/chromium`, ajuste `executable_path`. Executar em diretório isolado; não altera Notion.

## Aviso de autorização

O contrato `VLAB_TEST_EXPORT` é apenas uma **interface futura proposta**. Até que um exportador oficial read-only seja validado, só importar dados sintéticos e cópias TEST autorizadas. A etiqueta `MESTRE_ONLY` no arquivo não comprova segurança nem autenticidade; armazenamento local também não equivale a autenticação.

**Estado de continuidade:** Notion HOLD, integração VLAB REAL HOLD, Android físico HOLD, PROTO TEST 03 35/35 PASS digital.
