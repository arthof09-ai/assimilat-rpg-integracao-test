# PESQ-015 — Confronto físico TEST36 ↔ PESQ-013 (somente pesquisa)

Fonte: `baseline-readonly/room-client.js` e `room-v2-adapter.js`, cópias bit-a-bit do ZIP TEST36 de Library. Confrontado com `report/PROTOCOLO_SALA_V2_013.md` e PESQ014. **O TEST36 não é um servidor, e `validV2Response` local não certifica sigilo de bytes transmitidos.** Uma linha com status CORRIGIDO comprova presença no TEST36/TEST35, não autoridade/produção.

| # | Requisito | Classificação atual | Evidência e lacuna |
|---|---|---|---|
| 01 | Protocolo v1/v2 adaptável | CORRIGIDO EM TEST 35/36 | `createV2AdapterTransport`; sem negociação de versão real |
| 02 | Ticket de identidade real | PENDENTE DE SERVIDOR | `test-local-(gm\|p1\|p2)` é ticket público de fixture; rejeita ticket opaco real |
| 03 | `participantId` autenticado | PENDENTE DE SERVIDOR | Exige `participantId===profile` DEMO, não suporta IDs reais sem adaptação |
| 04 | Papéis MASTER/PLAYER | FUNCIONAL APENAS EM FIXTURE | V2 WELCOME traduz papel para v1; não autentica cliente |
| 05 | Propriedade de unidades | PENDENTE DE SERVIDOR | Mock confere posse; não há associação servidor-sessão real |
| 06 | `roomId` e JOIN reais | PENDENTE DE SERVIDOR | Literal `arena-test`, sem sala dinâmica autenticada |
| 07 | Revisão pública | FUNCIONAL APENAS EM FIXTURE | `revision` no mock; não há isolamento de revisão por visibilidade |
| 08 | `adminRevision` Mestre | PENDENTE DE SERVIDOR | Não há campo separado autorizado por identidade/ACL real |
| 09 | Sequência/resync sem eventos perdidos | CORRIGIDO EM TEST 35/36 | `ROOM_EVENT` checa incremento, `ROOM_RESYNC` em gap; sequência mock=v2 revision |
| 10 | `commandId` estável | CORRIGIDO EM TEST 35/36 | `intentId` persiste na outbox; UUID/nonce gerado pela UI TEST, não identidade real |
| 11 | Fingerprint idempotente | FUNCIONAL APENAS EM FIXTURE | Fixture indexa participante+ID e compara JSON; SQL transacional HOLD |
| 12 | UNKNOWN pós-ACK ambíguo | CORRIGIDO EM TEST 35/36 | `markUnknown`, preservação da pending, recarga e proteção contra nova ID |
| 13 | `RECEIPT_QUERY` mesmo ID | CORRIGIDO EM TEST 35/36 | Adapter consulta recibo após reconnect; 015 confirmou no fonte real |
| 14 | Recuperação após restart | FUNCIONAL APENAS EM FIXTURE | Journal `sessionStorage` por aba; persistência do servidor e restart físico HOLD |
| 15 | Journal corrompido/indisponível | CORRIGIDO EM TEST 35/36 | `journalError` impede INTENT v2 sem readback; TEST36 411/411 regressões |
| 16 | Mesmo ID/payload alterado | FUNCIONAL APENAS EM FIXTURE | Mock responde `ID_REUSE_CONFLICT`; durability servidor HOLD |
| 17 | Corrida de duas ações mesma revisão | PENDENTE DE SERVIDOR | Fixture é síncrona; não prova transação concorrente em DO |
| 18 | Recibo/estado/evento em 1 COMMIT | PENDENTE DE SERVIDOR | Nenhuma tabela/transactionSync no frontend; DO 0 casos reais |
| 19 | Revogação/expiração/role switching | PENDENTE DE SERVIDOR | Nenhum autenticação/ACL verdadeira implementada |
| 20 | Projeção nested Mestre/Party | PENDENTE DE SERVIDOR | 256/256 rejeições estruturais no cliente e mock filtrado, mas segredos já estariam na rede se servidor falhar |
| 21 | Erros/recibos/replay/RAW seguros | PENDENTE DE SERVIDOR | Receipts do mock não incluem diagnóstico privado; nenhuma captura WSS real |
| 22 | Movimento TEST compartilhado | FUNCIONAL APENAS EM FIXTURE | 1 Mestre+2 players no mesmo processo, `MOVE_VISUAL_TEST` válido e resync |
| 23 | Ataque/defesa/reação/turno real | PENDENTE DE VLAB | TEST36 adapter rejeita esses kinds; VLAB ABI homologada ausente |
| 24 | Compatibilidade ponte Python/TS Codex | PENDENTE DE CODEX | Commit local relatado sem bytes físicos, não reimplementar |
| 25 | Durable Objects + WebSocket Android | PENDENTE DE SERVIDOR | DNS npm `EAI_AGAIN` nesta instância; zero workerd/3 Android/HTTPS publicados |

**RED ATUAL COM PROVA:** a UI/adapter TEST36 é incapaz de transportar uma solicitação ATTACK_REQUEST / DEFENSE_REQUEST / TURN_START, como demonstra o teste 015. Não é regressão de recuperação, e sim lacuna explícita de produto aguardando contrato VLAB + servidor. Não tratar os RED de TEST34 como red atual. A linha 23 permanece PENDENTE DE VLAB para efeito canônico.

## Evidência nova PESQ015

- Executado: `node tests/test_actual_test36_015.cjs` com fontes físicas TEST36; 15/15 dirigidas + 256/256 entradas geradas (seed 20261023). Sem navegador, sistema operacional Android, WSS ou servidores reais.
- Executado: `node tests/test_boundary_contract_015.cjs` 35/35 checks **estruturais** da especificação; não são testes de mecanismo VLAB.
- Negativo importante: o adapter rejeita envelope contendo `masterOnly` aninhado, mas quando esse envelope alcançou a entrada do cliente o byte privado já foi transmitido. Proteção de segredo tem que ser no emissor, antes da rede.
- Não modificado: fontes do Desenvolvedor, Codex, VLAB, Site público ou Party.
