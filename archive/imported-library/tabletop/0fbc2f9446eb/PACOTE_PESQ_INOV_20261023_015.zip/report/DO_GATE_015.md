# PESQ015 — tentativas reais de obtenção runtime Workers sem credenciais

Ambiente usado: Node `v22.16.0`, npm `10.9.2`, Python `3.13.5`; nenhum pacote workerd/wrangler/Workers Vitest no executável ou cache npm acessível. Runtime real executado: **0/10 gates**.

Tentativas sem deploy e sem credenciais (23/10/2026, horário local):

```
timeout 12s npm view @cloudflare/vitest-pool-workers version --fetch-retries=0 --fetch-timeout=8000
# EAI_AGAIN: getaddrinfo registry.npmjs.org

timeout 12s npm view @cloudflare/vitest-plugin version --fetch-retries=0 --fetch-timeout=8000
# EAI_AGAIN: getaddrinfo registry.npmjs.org
```

Conclusão de diagnóstico: resolução DNS falhou **antes** de qualquer consulta de versão. Não prova indisponibilidade do pacote, incompatibilidade, custo, problema de Cloudflare nem ausência permanente de acesso. Sem downloads não é possível executar `runInDurableObject`, `evictDurableObject`, SQLite `transactionSync`, hibernação ou transmissão real. Fonte primária de API oficial: https://developers.cloudflare.com/workers/testing/vitest-integration/test-apis/ e https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/ (rever versão antes de instalar). Nunca substituir esse gate por Python mock.

**NEXT condicional e não bloqueante:** quando runtime oficial local estiver acessível, num lab TEST isolado e sem deploy executar 10 gates da ordem: persistência, rollback, COMMIT/ACK, RECEIPT_QUERY mesmo ID, fingerprint, concorrência, evicção, hibernação+revogação, expiração, RAW Mestre/Party. Registrar Node/npm/plugin/workerd/compatibility_date e resultados verdadeiros; não reivindicar conta/lease nem writer Cloudflare.
