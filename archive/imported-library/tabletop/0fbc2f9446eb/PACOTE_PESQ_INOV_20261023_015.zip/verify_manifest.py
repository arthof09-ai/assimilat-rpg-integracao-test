from pathlib import Path
import hashlib,json,sys
base=Path(__file__).resolve().parent
m=json.loads((base/'MANIFEST_SHA256_PESQ015.json').read_text())
wrong=[]
for item in m['files']:
 p=base/item['path']
 if not p.exists() or p.stat().st_size!=item['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']: wrong.append(item['path'])
print(f"MANIFEST PESQ015 {len(m['files'])-len(wrong)}/{len(m['files'])} PASS" if not wrong else 'FAIL '+repr(wrong))
sys.exit(bool(wrong))
