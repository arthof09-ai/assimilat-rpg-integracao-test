'use strict';
/* Research-only TEST36 actual-source bridge differential. No replacement engine, server, or modifications to Developer. */
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const path = require('node:path');
const SITE = process.env.TABLETOP_TEST36_SITE || path.resolve(__dirname,'../baseline-readonly');
const srcClient = fs.readFileSync(path.join(SITE,'room-client.js'),'utf8');
const srcAdapter = fs.readFileSync(path.join(SITE,'room-v2-adapter.js'),'utf8');
const hashes = Object.fromEntries([['room-client.js',srcClient],['room-v2-adapter.js',srcAdapter]].map(([k,v])=>[k,crypto.createHash('sha256').update(v).digest('hex')]));
const ctx = {window:{},document:{getElementById:()=>null},crypto:crypto.webcrypto,console};
ctx.window.window = ctx.window;
vm.createContext(ctx);
vm.runInContext(srcAdapter,ctx,{filename:'REAL_TEST36_room-v2-adapter.js'});
// TEST-only in-memory export: original source on disk is not altered, caller gains access to class normally behind DOM.
const injected = srcClient.replace('const room=byId(\'roomPanel\');', 'window.__Research015={RoomClient,checkPacket,checkSnapshot,checkOutgoing,SCHEMA};\nconst room=byId(\'roomPanel\');');
assert.notEqual(injected,srcClient,'actual class export anchor exists');
vm.runInContext(injected,ctx,{filename:'REAL_TEST36_room-client.js_TEST_ONLY_EXPORT'});
const V = ctx.window.TabletopRoomV2TEST, R = ctx.window.__Research015;
const results = [], wire=[]; let instanceCounter=0;
const check=(label,fn)=>{try{fn();results.push({label,status:'PASS'});}catch(e){results.push({label,status:'FAIL',error:String(e)});}};
const clone=x=>JSON.parse(JSON.stringify(x));
const store=()=>{const m=new Map();return {getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v),dump:()=>Object.fromEntries(m)}};
const mk=(id,opts={})=>{
  const s=opts.store||store();let n=0;
  // Capture the REAL v2 transport boundary before the adapter transforms/sanitizes it.
  const tappedV2Factory=({onMessage,onClose})=>{
    const actual=V.mockV2TransportFactory({onMessage:raw=>{
      wire.push({direction:'SERVER_TO_CLIENT_V2_RAW',participant:id,bytes:raw});
      onMessage(raw);
    },onClose});
    return {send:raw=>{
      wire.push({direction:'CLIENT_TO_SERVER_V2_RAW',participant:id,bytes:raw});
      actual.send(raw);
    },close:()=>actual.close()};
  };
  const origFactory=V.createV2AdapterTransport(tappedV2Factory);
  const factory=args=>{
    const tr=origFactory({onMessage:raw=>{wire.push({direction:'ADAPTER_TO_CLIENT_V1',participant:id,bytes:raw});args.onMessage(raw);},onClose:args.onClose});
    return {send:raw=>{wire.push({direction:'CLIENT_TO_ADAPTER_V1',participant:id,bytes:raw});tr.send(raw);},close:()=>tr.close()};
  };
  const c=new R.RoomClient({transportFactory:factory,protocol:'v2',nonce:'p015'+id+'nonce'+(++instanceCounter),journalStore:s,onUpdate:()=>{n++}});
  return {client:c,store:s,updates:()=>n};
};
const M=V.mock;
M.revision=0;M.sessionEpoch=1;M.dropNextAck=false;M.receipts.clear();M.walls=['3,3'];
M.units=[{id:'demo_a',name:'A TEST',mark:'A',team:'ally',ownerId:'p1',x:1,y:1},{id:'demo_b',name:'B TEST',mark:'B',team:'ally',ownerId:'p2',x:1,y:4},{id:'demo_n',name:'N TEST',mark:'X',team:'enemy',ownerId:null,x:5,y:3}];
let gm=mk('gm'),p1=mk('p1'),p2=mk('p2');
gm.client.connect('gm');p1.client.connect('p1');p2.client.connect('p2');
check('T36 real v2 bridge: three profiles reach mock fixture',()=>{for(const o of [gm,p1,p2])assert.equal(o.client.connected,true)});
check('T36 real v2: projections are recipient-scoped at RAW ingress',()=>{
  const w1=wire.find(x=>x.participant==='p1'&&x.direction==='SERVER_TO_CLIENT_V2_RAW');
  const w2=wire.find(x=>x.participant==='p2'&&x.direction==='SERVER_TO_CLIENT_V2_RAW');
  const mg=wire.find(x=>x.participant==='gm'&&x.direction==='SERVER_TO_CLIENT_V2_RAW');
  assert(w1&&w2&&mg);assert.deepEqual(JSON.parse(w1.bytes).snapshot.units.map(x=>x.id),['demo_a']);
  assert.deepEqual(JSON.parse(w2.bytes).snapshot.units.map(x=>x.id),['demo_b']);
  assert.equal(JSON.parse(mg.bytes).snapshot.units.length,3);
});
check('T36 real bridge: P1 sends visual-only move, all three receive updated revision',()=>{
  assert.equal(p1.client.sendIntent('demo_a',2,2),true);for(const o of [gm,p1,p2]) assert.equal(o.client.revision,1);
  assert.equal(p1.client.snapshot.units[0].x,2);assert.equal(M.revision,1);
  assert.equal(p2.client.snapshot.units.length,1);assert.equal(p2.client.snapshot.units[0].id,'demo_b');
});
check('T36 real bridge: disallowed player other-unit move generates no command',()=>{
  const before=wire.filter(x=>x.participant==='p2'&&x.direction==='CLIENT_TO_ADAPTER_V1').length;
  assert.equal(p2.client.sendIntent('demo_a',5,5),false);
  assert.equal(wire.filter(x=>x.participant==='p2'&&x.direction==='CLIENT_TO_ADAPTER_V1').length,before);
});
check('T36 real adapter: incoming private nested field structurally refused',()=>{
  const payload={v:2,type:'SNAPSHOT',roomId:'arena-test',revision:2,snapshot:{sceneId:'scene-test',n:7,walls:[],markers:[],units:[{id:'demo_a',name:'A TEST',mark:'A',team:'ally',ownerId:'p1',x:2,y:2,stats:{masterSecret:'canary_015'}}]}};
  assert.equal(V.validV2Response(payload),false);
});
check('T36 real: production-like auth ticket not supported by current fixture',()=>{
  const m={v:2,type:'JOIN',roomId:'arena-test',ticket:'signed-production-ticket-opaque'};
  assert.equal(V.validV2Outgoing(m),false);
});
check('T36 real: unauthorized combat INTENT not accepted by existing adapter',()=>{
  for(const kind of ['ATTACK_REQUEST','REACTION_REQUEST','DEFEND_REQUEST','TURN_START','TURN_END','CAST_REQUEST']){
   assert.equal(V.validV2Outgoing({v:2,type:'INTENT',roomId:'arena-test',commandId:'valid_cmd',baseRevision:1,kind,unitId:'demo_a',payload:{targetId:'demo_n'}}),false);
  }
});
check('T36 real: reject nested role/owner/source claims even in mock movement',()=>{
 const common={v:2,type:'INTENT',roomId:'arena-test',commandId:'id_new',baseRevision:1,kind:'MOVE_VISUAL_TEST',unitId:'demo_a',payload:{x:2,y:3}};
 for(const extra of [{role:'MASTER'},{participantId:'gm'},{adminRevision:100},{payload:{x:2,y:3,damage:9999}},{payload:{x:2,y:3,mechanics:{PA:0}}}]) assert.equal(V.validV2Outgoing({...common,...extra}),false);
});
check('T36 real: adversarial RAW packet contains secret before any browser-side reject',()=>{
 const secret='canary_MESTRE_ONLY_015', malicious={v:2,type:'SNAPSHOT',roomId:'arena-test',revision:2,snapshot:{sceneId:'scene-test',n:7,walls:[],markers:[],units:[{id:'demo_a',name:'A',mark:'A',team:'ally',ownerId:'p1',x:2,y:2,masterOnly:secret}]}};
 const raw=JSON.stringify(malicious);assert(raw.includes(secret));assert.equal(V.validV2Response(malicious),false);
 // Deliberate negative control: reader cannot undo a RAW transmission. Therefore server send-filtering must be tested separately.
});
// Lost ACK and client reload with real TEST36 interface + real TEST36 v2 fixture.
let gone=mk('p1lost');gone.client.disconnect(); // no effects beyond synthetic harness
const replayStore=store(),first=mk('p1',{store:replayStore});first.client.connect('p1');M.dropNextAck=true;
check('T36 real recovery: commit with missing ACK preserves UNKNOWN and stores identical intent',()=>{
 assert.equal(first.client.sendIntent('demo_a',3,2),true);
 assert.equal(M.revision,2);assert.equal(first.client.pending.size,1);
 assert.equal(first.client.snapshot.units[0].x,2);
 assert.equal(JSON.parse(replayStore.getItem(first.client.journalKey)).entries.length,1);
});
const originalCommand=[...first.client.pending.keys()][0];first.client.disconnect();
let reboot=mk('p1',{store:replayStore});
check('T36 real recovery: pending bytes survive restart with original commandId',()=>{
 assert.equal(reboot.client.pending.size,1);assert.equal([...reboot.client.pending.keys()][0],originalCommand);
});
reboot.client.connect('p1');
check('T36 real recovery: reconnection queries same receipt, not another INTENT',()=>{
 const w=wire.filter(x=>x.participant==='p1'&&x.direction==='CLIENT_TO_ADAPTER_V1').map(x=>JSON.parse(x.bytes));
 assert(w.some(x=>x.type==='ROOM_RECEIPT_QUERY'&&x.intentId===originalCommand));
 assert.equal(M.revision,2);assert.equal(reboot.client.pending.size,0);
});
check('T36 real recovery: accepted receipt produces fresh snapshot and coordinates',()=>{
 assert.equal(reboot.client.snapshot.units[0].x,3);
 assert.equal(reboot.client.snapshot.units[0].y,2);
});
// A new property can be rejected by v2 validator, but this alone is NOT a proof of server-side privacy.
const projection={sceneId:'scene-test',n:7,walls:[],units:[{id:'demo_a',name:'A',mark:'A',team:'ally',ownerId:'p1',x:1,y:1}],markers:[{id:'mk1',x:3,y:3,label:'M'}]};
const seed=20261023;let rng=seed;
const next=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng;};
let injectionPass=0;
for(let i=0;i<256;i++){
 const msg={v:2,type:'SNAPSHOT',roomId:'arena-test',revision:3,snapshot:clone(projection)};
 const loc=next()%5;const k='canary_'+i;
 if(loc===0)msg.snapshot[k]='MASTER_015';
 if(loc===1)msg.snapshot.units[0][k]='MASTER_015';
 if(loc===2)msg.snapshot.markers[0][k]='MASTER_015';
 if(loc===3)msg[k]='MASTER_015';
 if(loc===4)msg.snapshot.units[0].stats={nested:{[k]:'MASTER_015'}};
 if(!V.validV2Response(msg))injectionPass++;
}
check('T36 actual adapter: 256/256 generated unknown nested/flat payloads rejected',()=>{assert.equal(injectionPass,256)});
const rawP1=wire.filter(x=>x.participant==='p1'&&x.direction==='SERVER_TO_CLIENT_V2_RAW').map(x=>x.bytes);
const rawP2=wire.filter(x=>x.participant==='p2'&&x.direction==='SERVER_TO_CLIENT_V2_RAW').map(x=>x.bytes);
check('T36 actual mock: ALL captured P1/P2 RAW frames contain no demo_n/hidden other owner',()=>{
 for(const r of [...rawP1,...rawP2])assert(!r.includes('demo_n')&&!r.includes('canary_MESTRE_ONLY_015'));
 for(const r of rawP1)assert(!r.includes('demo_b'));
 for(const r of rawP2)assert(!r.includes('demo_a'));
});
const observations={status:'TEST_FIXTURE_ONLY',baseline:'PESQ-014',target:'ACTUAL_TEST36',siteHashes:hashes,directed:results.length,passed:results.filter(x=>x.status==='PASS').length,failed:results.filter(x=>x.status==='FAIL').length,generatedCases:256,generatedRejected:injectionPass,trace:{participants:['gm','p1','p2'],mockRevision:M.revision,moveP1:{to:[2,2],status:'MOCK_CONFIRMED'},ackLostRecovery:{commandId:originalCommand,unknownThenReceipt:true,to:[3,2]},gameCombat:'MECHANICS_HOLD',server:'NOT_EXECUTED',durableObjects:'NOT_EXECUTED'},results};
const root=path.resolve(__dirname,'../results');fs.mkdirSync(root,{recursive:true});
fs.writeFileSync(path.join(root,'TEST36_DIFFERENTIAL_015.json'),JSON.stringify(observations,null,2)+'\n');
// RAW captures from the synthetic fixture, not Internet: sanitize and preserve for auditing privacy assertions.
fs.writeFileSync(path.join(root,'RAW_FIXTURE_FRAMES_015.jsonl'),wire.map(x=>JSON.stringify(x)).join('\n')+'\n');
for(const c of [gm,p1,p2,first,reboot])c.client.disconnect();
console.log(`ACTUAL TEST36 DIRECTED ${observations.passed}/${observations.directed} | GENERATED ${injectionPass}/256 | status ${observations.failed===0?'PASS':'FAIL'}`);
for(const e of results.filter(x=>x.status==='FAIL'))console.error(e.label+': '+e.error);
process.exitCode=observations.failed?1:0;
