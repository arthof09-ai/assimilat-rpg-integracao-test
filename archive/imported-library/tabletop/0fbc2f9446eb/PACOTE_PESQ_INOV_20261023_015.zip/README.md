# PACOTE PESQ015 — Tabletop Assimilação / Pesquisador

Pesquisa pós-PESQ014 sobre **fontes reais** de TEST36, com cópias read-only das duas fontes auditadas para permitir replay independente. NÃO é produto de jogo, não é backend novo, não é parte do VLAB e não substitui a Arena do Desenvolvedor.

Reproduzir no Node 22+ (nenhuma dependência externa):

```
node tests/test_actual_test36_015.cjs
node tests/test_boundary_contract_015.cjs
```

Há 15 verificações dirigidas na fonte TEST36, 256 entradas maliciosas geradas e 35 checks estruturais, **denominadores separados**. Para refazer com outra cópia TEST36, defina TABLETOP_TEST36_SITE para um diretório contendo room-client.js e room-v2-adapter.js.

Arquivos:
- `baseline-readonly/` hash-identificados e não editados; no JS dos testes há APENAS export de classe em memória isolada VM, nunca um patch no original.
- `contract/` fronteira sem cálculo mecânico.
- `report/` matriz com 25 requisitos, evidência Workers bloqueado, PSV.
- `results/` inclui captura literal dos frames v2 da fixture ANTES do adaptador v2→v1, além dos frames depois da tradução; não é captura WSS real.
- `MANIFEST_SHA256_PESQ015.json` atesta entradas, não certificação cloud.

Segurança: apenas unidades e identificadores DEMO. Não anexar dados Mestre-only reais, segredos de partidas, credenciais, tickets de produção ou fichas ao pacote. **Contrato proposto de VLAB ABI NÃO homologada**.
