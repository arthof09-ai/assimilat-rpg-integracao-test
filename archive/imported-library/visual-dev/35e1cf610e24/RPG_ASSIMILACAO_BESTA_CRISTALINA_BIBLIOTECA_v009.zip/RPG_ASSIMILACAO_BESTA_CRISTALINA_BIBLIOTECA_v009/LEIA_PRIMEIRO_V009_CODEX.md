# LEIA PRIMEIRO — BIBLIOTECA VISUAL DA BESTA CRISTALINA v009

**MESTRE-SIDE / TEST / somente autoridades autorizadas.** Não publicar em GitHub público, Party ou O Primeiro.

## Status real e fontes

O ZIP agora contém **16 PNGs originais ou auxiliares**: duas pranchas originais A/B de 4 ângulos cada, oito recortes auxiliares dessas pranchas, quatro PNGs de ataques aprovados (Dobra de Terra partes 1, 2 e 3; Investida + Soco) e **duas folhas de locomoção de seis quadros** (2 linhas × 3 colunas). O original aprovado NÃO foi reamostrado nem rasterizado novamente.

**NOVIDADE v008/v009:** `04_ATIVOS_APROVADOS/MOVIMENTO/` contém as folhas de movimento. Os nomes dos arquivos identificam função, não representam texto escrito nos pixels da arte.

- **v008 — frente/costas:** linha superior 3 estados de frente; inferior 3 estados de costas; cauda alternando esquerda-centro-direita, leitura de cada linha da esquerda para a direita. Recuperado de um anexo anterior cujo nome fora reutilizado posteriormente, usando o ID e o hash do arquivo, não por aproximação.
- **v009 — esquerda/direita solicitadas:** linha superior deslocamento pedido para esquerda; inferior pedido para direita; três poses por linha. **ATENÇÃO:** os quadros continuam visualmente quase frontais, portanto CODEx precisa avaliar se essas folhas representam movimentos laterais suficientemente corretos; não assumir que são perfis genuínos só pelo nome.

A aprovação do Mestre é **artística**, não prova de importação no Godot nem de adequação de movimento lateral.

## Limitação geométrica IMPORTANTE

As duas folhas são arquivos originais `RGBA` de **1672 × 941**. Matematicamente, **1672 não divide por 3** e **941 não divide por 2**, portanto os cortes por grade uniforme com coordenadas inteiras devem ser decididos pelo Codex em artefatos DERIVADOS. Não modificar os PNGs originais. O alvo visual 16:9 é aproximado nestes arquivos, não geometricamente exato.

## O que Codex tem que fazer (não aceitar extração auxiliar como resultado)

1. Abrir **pranchas A/B completas originais** e todas as quatro imagens de ataque e duas de movimento.
2. Inspecionar alfa, respingos de fundo, vazamentos de efeitos/cauda e possível corte nas fronteiras de células.
3. Verificar visualmente ângulos solicitados vs mostrados, tamanho/pivô, animação real, fluidez, continuidade da cauda e olho da câmera.
4. Fazer **extração própria** e calcular uma grade técnica exata, padding/crop/pivô nos DERIVADOS, com readback.
5. Testar reprodução em loop e possibilidade de ordem ping-pong (por exemplo 1-2-3-2-1), sempre conforme validação e aprovação do Mestre. O padrão 2 linhas × 3 quadros é EXCEÇÃO expressa; não substituir a norma padrão de 4+ quadros por direção automaticamente.
6. Documentar resultado PASS/FAIL/HOLD com capturas/evidências e não presumir compatibilidade Godot/Tabletop.

**Futuras aprovações:** gerar v010, depois v011 etc, usando `tools/atualizar_biblioteca_aprovacao.py`, preservando hashes/originais; atualizar índice Notion e Biblioteca privada. O número de quadros não atribui efeitos mecânicos VLAB.

## Arquivos principais

- `01_PRANCHAS_COMPLETAS/` fontes visuais originais A/B.
- `02_VISTAS_INDIVIDUAIS/` oito recortes AUXILIARES, sem certificação Codex.
- `04_ATIVOS_APROVADOS/ATAQUES/` quatro PNGs de ataques aceitos.
- `04_ATIVOS_APROVADOS/MOVIMENTO/` dois PNGs de locomoção aceitos.
- `manifest.json` índices, hashes e linhagem; `06_MOVIMENTO_QA_V009.json` contém limitações técnicas.
- `HISTORICO_VERSOES.md` rastreabilidade da evolução do catálogo.
