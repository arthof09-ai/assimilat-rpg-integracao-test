# Historico

## v001 — 2026-10-26/27 (registro deste pacote)
- Fonte: duas imagens enviadas pelo Mestre neste chat como Pranchas A/B.
- Status: versao de biblioteca de arte aceita pelo Mestre no dialogo, tecnico/engine ainda TEST/HOLD.
- Acao: preservar os 2 PNGs originais, exportar 8 recortes por quadrante sem reamostragem, produzir JSON/QA.
- Nenhuma arte gerada ou retocada neste processo de empacotamento.
- Proxima versao ao receber e confirmar novos ativos aceitos, mantendo v001 imutavel.

## v002 — 2026-10-26 (correção de responsabilidade técnica, sem arte nova)
- Decisão expressa do Mestre: análise, confirmação de orientações, recorte técnico e integração de pranchas A/B são atribuições do Codex; Comestre apenas disponibiliza recortes auxiliares.
- Não houve aprovação de imagens adicionais; pranchas A/B e 8 recortes idênticos byte a byte aos de v001, preservados com SHA-256.
- README, MANIFESTO, manifesto JSON, QA e contrato de reporte atualizados. Novo contrato `CODEX-INDEPENDENT-SHEET-QA-01` e modelo de relatório `RELATORIO_CODEX_PENDENTE.json`.
- Nenhuma inspeção independente, correção de alfa, pivô, importação ou animação foi executada pelo Codex. Primeiro passo pendente permanece essa análise.
- v001 permanece como versão anterior imutável e disponível separadamente.


## v003 — regulamento de custódia incremental e arte sem inscrição

Nenhuma nova imagem de arte incluída. As dez imagens herdadas de v002 foram preservadas byte a byte; adicionada ferramenta de incorporação de novas aprovações, contrato de conteúdo visual limpo e roteamento para QA independente Codex.

## v004 — aceite unitário incremental

- Fonte acrescentada: `04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PRANCHA_01_3X3_APROVADA_1ba609dce766.png`
- Aprovação do Mestre: Mestre disse: A que eu mais gostei foi essa, A primeira parte do ataque ficou Perfeita, agora podemos fazer a segunda parte do ataque
- Referência: Pranchas A e B originais, e imagem aprovada 504199.png (primeira parte do ataque de dobra de terra)
- SHA-256: `1ba609dce7669546556e3eec199546fb7d066108fed45ff804c9086d17661782`
- Codex QA independente: PENDENTE
- ZIP anterior `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v003.zip` preservado sem alteração.

## v005 — aceite unitário incremental

- Fonte acrescentada: `04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PARTE_02_PROJETIL_VOO_3X3_APROVADA_fd77c2af53f3.png`
- Aprovação do Mestre: Mestre em 27/10/2026: Perfeito, aprovado. Referente a prancha da Parte 2 rocha em voo entregue no turno imediatamente anterior.
- Referência: Parte 1 aprovada / 504199.png, Besta Cristalina / Pranchas A e B; continuidade visual da rocha original, sem nova criatura.
- SHA-256: `fd77c2af53f3c1c6a8e57129d8f9dae35a072076647781aa95522c48e902b5d4`
- Codex QA independente: PENDENTE
- ZIP anterior `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v004.zip` preservado sem alteração.

## v006 — aceite unitário incremental

- Fonte acrescentada: `04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PARTE_03_IMPACTO_E_FRAGMENTACAO_3X3_APROVADA_e0af42ed7d15.png`
- Aprovação do Mestre: Mestre: Perfeito, agora o primeiro ataque tá criado; aprovação contextual da Parte 3 recém-gerada e conclusão artística do primeiro ataque.
- Referência: DOBRA_TERRA_PARTE_02_PROJETIL_VOO_3X3_APROVADA_fd77c2af53f3.png; marco inicial do primeiro quadro da Parte 3 é o último da Parte 2
- SHA-256: `e0af42ed7d15d9973258f205c51a00607c49b6ddd7b3ac4c917c4dbf8fe7184b`
- Codex QA independente: PENDENTE
- ZIP anterior `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v005.zip` preservado sem alteração.

## v007 — aceite unitário incremental

- Fonte acrescentada: `04_ATIVOS_APROVADOS/ATAQUES/ATAQUE_02_INVESTIDA_SERPENTINA_SOCO_DEMOLIDOR_3X3_APROVADA_b9b6b992b3f0.png`
- Aprovação do Mestre: Mestre: Ficou perfeito
- Referência: Pranchas A/B originais Besta Cristalina; Ataque 01 Dobra Terra aprovado; PROMPT_ATAQUE_02_INVESTIDA_SERPENTINA_SOCO_DEMOLIDOR_TEST.md
- SHA-256: `b9b6b992b3f0aceb14821ffd494343d50dab224e6403e5487fb680c770b7699e`
- Codex QA independente: PENDENTE
- ZIP anterior `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v006.zip` preservado sem alteração.

## v008 — aceite unitário incremental

- Fonte acrescentada: `04_ATIVOS_APROVADOS/MOVIMENTO/CAMINHADA_FRENTE_COSTAS_2X3_3_POSES_APROVADA_e2e1c96e041f.png`
- Aprovação do Mestre: Mestre: Beleza, perfeito. Agora faca a movimentacao dele para a esquerda e para a direita [aprova a prancha anterior de frente/costas com cauda oscilante].
- Referência: Pranchas A/B aprovadas; sprite sheet revisada de frente/costas, recuperada do anexo file_00000000b884820e9f3c5798b0f20372; nao confundir com outro arquivo de mesmo nome.
- SHA-256: `e2e1c96e041fa628a0f2b793f8f9153f8964465f681f9875eb51b520e6828e07`
- Codex QA independente: PENDENTE
- ZIP anterior `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v007.zip` preservado sem alteração.

## v009 — aceite unitário incremental

- Fonte acrescentada: `04_ATIVOS_APROVADOS/MOVIMENTO/CAMINHADA_ESQUERDA_DIREITA_2X3_3_POSES_APROVADA_c22747e67216.png`
- Aprovação do Mestre: Mestre: Perfeito, cade o arquivo? [aprova a ultima prancha criada, pedida como frente indo para esquerda e abaixo para direita].
- Referência: Pranchas A/B e sprite de frente/costas v008; mesma fonte de anexo cujo nome repetiu arquivo anterior. A intencao de movimento lateral nao comprova vista lateral genuina, QA Codex PENDENTE.
- SHA-256: `c22747e6721620190a25af097f311a629a3b8e9754c51620d2cdcd3ac143634a`
- Codex QA independente: PENDENTE
- ZIP anterior `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v008.zip` preservado sem alteração.

## v009 — catálogo cumulativo com duas folhas de movimento (27/10/2026)

- v008 adicionou frente/costas (2×3), arquivo antigo recuperado por ID do anexo; v009 adicionou esquerda/direita solicitadas (2×3), arquivo posterior de mesmo nome.
- Os PNGs antigos foram preservados byte a byte; novas folhas também foram copiadas como originais completos.
- Aprovadas artisticamente pelo Mestre; ângulos efetivos, animação, pivôs, alpha residual, loop e engine ainda pendentes da avaliação independente do Codex.
- Atenção: `1672×941` não se divide exatamente em 3 colunas ou 2 linhas inteiras. Qualquer ajuste ocorre nos derivados técnicos, não nos originais.
