# RPG ASSIMILAÇÃO — PRODUÇÃO VISUAL 2.5D
## ATAQUE 02 — INVESTIDA SERPENTINA + SOCO DEMOLIDOR

**ESTADO:** PROPOSTO/TEST; não há sprite sheet 02 aprovada ainda.
**REFERÊNCIAS OBRIGATÓRIAS:** Besta Cristalina aprovada nas Pranchas A/B (2 PNGs integrais) e na Dobra de Terra finalizada (Partes 1, 2 e 3). Não inventar criatura nova, não transformar a cauda em pernas nem copiar o projétil da Dobra de Terra.

### MISSÃO

Produzir uma única imagem PNG RGBA com transparência REAL, formato horizontal 16:9 exato e exatamente nove quadros distribuídos em uma grade **3 linhas x 3 colunas geometricamente iguais**, a mesma criatura executando uma única ação: compressão da cauda, impulso serpentino, avanço, carregamento do punho direito, soco no ALVO INVISÍVEL e recuperação. Frames são lidos da esquerda para a direita; ao final da linha passam à próxima linha, retomando pela esquerda. Sem texto, bordas, rótulos ou marcações dentro do PNG.

### IDENTIDADE ANATÔMICA FIXA

Criatura enorme de corpo cinza-escuro rochoso segmentado, rachaduras magenta fluorescentes, cristais grandes nos ombros e costas, braços rochosos maciços terminados em mãos cristalinas, cabeça encapuzada com cavidade triangular interna cristalina escura, **parte inferior sem pernas, constituída por uma cauda muito longa, grossa na base, afilada e com cristais laterais**. Preservar distribuição assimétrica dos cristais, material, proporções e orientação em TODOS os quadros, sem duplicar braços, quebrar cauda ou transformá-la em bola.

### COREOGRAFIA 3x3 (descrições pertencem SOMENTE ao manifesto externo, jamais gravar números no sprite)

- **LINHA 1 / QUADRO 1 — Guarda:** postura sólida, punhos preparados, cauda estendida em curva sustentando o tronco.
- **LINHA 1 / QUADRO 2 — Comprimir:** curvar a cauda mais fortemente para carregar energia cinética; ombros abaixam e tronco recua.
- **LINHA 1 / QUADRO 3 — Impulso:** contração se converte em onda progressiva da cauda, fazendo o tronco avançar para a direita.
- **LINHA 2 / QUADRO 4 — Aceleração:** a onda serpentina transmite deslocamento e inércia à massa de rocha; tronco inclina e braço esquerdo estabiliza.
- **LINHA 2 / QUADRO 5 — Carregar o soco:** o braço DIREITO anatômico recolhe-se ao lado/atrás do tronco enquanto este gira. A cauda ancora o contragolpe; energia magenta concentra-se nas juntas e punho.
- **LINHA 2 / QUADRO 6 — CONTATO ÚNICO:** soco DIREITO explode para a direita, como descarga de toda a massa do corpo; o punho encosta em ALVO INVISÍVEL e produz única onda de choque local de energia magenta e lascas minerais, sem mostrar alvo ou parede.
- **LINHA 3 / QUADRO 7 — Follow-through:** braço permanece estendido brevemente, ombro e tronco concluem rotação e onda de choque se expande (NÃO ocorre outro impacto).
- **LINHA 3 / QUADRO 8 — Recuperação:** punho regressa, tronco desfaz a torção, cauda amortece inércia com uma onda contrária e partículas diminuem.
- **LINHA 3 / QUADRO 9 — Guarda restabelecida:** cauda longa readquire curva estável, punhos voltam à defesa, sem segundo ataque e sem fragmentos em excesso.

### DINÂMICA BIOMECÂNICA E CONTINUIDADE

A cauda deve MUDAR visivelmente em cada pose, transmitir energia às placas abdominais e aos ombros; o monstro se arrasta/impulsiona como serpente erguida, NÃO corre nem salta com pernas invisíveis. A cadeia cinética é **cauda → cintura/torso → ombro direito → punho direito → impacto**. O braço esquerdo mantém função de equilíbrio e proteção. Evitar teleportes de postura: cada frame deriva fisicamente do anterior. Não mudar o punho de direito para esquerdo, não alterar altura do tronco arbitrariamente. Preservar a posição de referência/pivô e o tamanho aparente por célula para facilitar eventual recorte Codex; deslocamento cinemático visual não altera distância mecânica do VLAB.

### CÂMERA / ENQUADRAMENTO / QUALIDADE

Câmera 2.5D consistentemente elevada, com alvo aproximado de 35 graus sobre horizontal (não declarar precisão calibrada sem câmera real). Foco isométrico/três quartos, suficiente para revelar topo do torso, cristais, cauda e soco. Sem virar vista de frente num quadro e de costas em outro. Cada célula rigorosamente igual; a folha inteira 16:9 exata, tamanho final adequado a detalhes da besta. Prioridade para resolução NATIVA realmente disponível, definição de placas/cortes/cristais, arestas nítidas e efeitos de impacto legíveis, preservando margens em cada célula. Não redimensionar animal para caber sacrificando detalhes, não sobrepor quadros. Fundo literalmente RGBA 0 fora do desenho, não checkerboard desenhado.

### PROIBIÇÕES

NÃO desenhar inimigo, humano, alvo de treino, parede, solo, cenário, rocha arremessada, explosão da Dobra de Terra, pernas, pés, braços extras, duas caudas, socos duplicados, UI, bordas, caixas, separadores, títulos, letras, números, palavras, códigos, setas, logo, assinatura, etiqueta ou marca d’água; nenhum elemento informativo dentro dos pixels. Apenas monstro e os efeitos INTRÍNSECOS do soco. Não pintar fundo quadriculado.

### GATE

Nove estados cronológicos de UMA única investida + soco; mesma Besta Cristalina original, cauda longa e verdadeiramente animada, soco anatômico direito, contato uma só vez no quadro 6, recuperação até quadro 9, câmera consistente, 16:9, grade uniforme 3x3, PNG RGBA transparente sem inscrições. Se qualquer requisito crítico falhar, estado FAIL/TEST e NÃO incorporar a biblioteca dos ativos aprovados. Codex fará avaliação independente dos PNGs originais, pivôs e cortes antes de integrar ao jogo. Quantidade de frames não altera regra mecânica de dano, distância, PA ou turnos no VLAB.
