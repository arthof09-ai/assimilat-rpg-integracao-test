# ZIPs de origem — proveniência criptográfica

**Atenção:** os três ZIPs originais NÃO estão duplicados aqui; cada um foi lido e todas as suas entradas de arquivo foram copiadas byte a byte para pastas prefixadas. Os SHA-256 dos ZIPs de entrada são registrados para confrontar com as cópias externas que o Mestre mantém.

## BESTA_CRISTALINA — v009
- Nome: `RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v009.zip`
- SHA-256 fonte ZIP: `35e1cf610e24d824221d705ac7bf8d71761ad2264bbf09233acb7be81f459553`
- Bytes do ZIP fonte: 28155877
- CRC fonte: PASS
- Entradas copiadas: 32 (PNG: 16)
- Pasta destino: `01_BESTA_CRISTALINA_v009/`

## CAPRILEO_ESCAMOSO_OURO1 — v001
- Nome: `RPG_ASSIMILACAO_CAPRILEO_ESCAMOSO_OURO1_BIBLIOTECA_v001.zip`
- SHA-256 fonte ZIP: `fe7ed3fe37efeb68f3bdba213820bd5cd8b157c163758fb265dd4fa17ab241af`
- Bytes do ZIP fonte: 21293731
- CRC fonte: PASS
- Entradas copiadas: 14 (PNG: 8)
- Pasta destino: `02_CAPRILEO_ESCAMOSO_OURO1_v001/`

## ORC — TEST
- Nome: `ORC_ATIVOS_PNG_PARA_CODEX_SEM_WORD_TEST.zip`
- SHA-256 fonte ZIP: `1a4f2bdd719004edd770b6741ef8dd9b44c85cdf79ddd23ab6c8789e16072196`
- Bytes do ZIP fonte: 42818329
- CRC fonte: PASS
- Entradas copiadas: 15 (PNG: 13)
- Pasta destino: `03_ORC_TEST/`

## Política de conservação
- Cada arquivo interno teve bytes mantidos; apenas ganhou novo prefixo de caminho para evitar colisões entre bibliotecas.
- Manifestos históricos ficam intactos, inclusive eventuais caminhos internos antigos; o `INVENTARIO_GERAL.json` mapeia caminho original→novo.
- Imagens não foram redimensionadas, convertidas, recortadas, desenhadas nem regeneradas.