# PROMPT PRONTO PARA ENVIAR AO CODEX

Sou o Mestre do RPG Assimilação. Anexei um ZIP chamado `RPG_ASSIMILACAO_ACERVO_VISUAL_UNIFICADO_CODEX_v001.zip`.

Você é o executor Codex, trabalhando estritamente do lado do Mestre. Primeiro EXTRAIA O ZIP e leia `00_COMECE_AQUI/LEIA_PRIMEIRO_CODEX.md`, `00_COMECE_AQUI/INVENTARIO_GERAL.json`, `00_COMECE_AQUI/QA_EMPACOTAMENTO.json`. Depois leia os manifestos/READMEs originais de CADA uma das três bibliotecas.

MISSÃO INICIAL: auditoria independente completa das imagens e sequências das três criaturas, inclusive fontes-mãe, folhas integrais, recortes auxiliares, oito direções quando existentes, animações, ataques e o machado do Orc. Confirme hashes, transparência genuína, integridade, consistência de silhueta e escala, sequência biomecânica de frames, número/direção real de vistas e grade geométrica, vazamentos entre células, chifres/patas/caudas, pivôs e se há material suficiente para integrar no jogo 2.5D. Use as imagens ORIGINAIS como fonte principal, sem tratar recortes auxiliares como prova de QA. Gere tabela de PASS/FAIL/HOLD específica para cada PNG/família e a lista de correções propostas. Mostre evidências verificáveis de qualquer teste.

Prioridades e cuidados:
- Nunca modificar, recomprimir com perdas, sobrescrever nem excluir as fontes originais. Arte derivada é outra pasta e tem SHA e proveniência próprios.
- O aceite visual do Mestre NÃO significa que Godot, pivôs, alfa, FPS ou loops estejam tecnicamente validados.
- Besta Cristalina v009 tem observação de ângulo lateral possivelmente inadequado; Capríleo v001 tem folha com alfa máximo 254; Orc TEST inclui estudos de ataque, não animações prontas.
- Preserve MESTRE-SIDE; nada para Party, O Primeiro, GitHub público ou serviços externos sem autorização.
- VLAB continua autoridade mecânica. Não mudar números de dano, alcance, PA ou regras por inferência visual.
- Caso algum original esteja ilegível ou faltante, identifique o caminho/SHA exato e não adivinhe.

Não precisa redesenhar criaturas. Faça auditoria e uma proposta técnica objetiva de recortes/pivôs/importação. Nesta primeira etapa, não escreva no Notion, não faça push GitHub e não altere o projeto de jogo sem autorização adicional.
