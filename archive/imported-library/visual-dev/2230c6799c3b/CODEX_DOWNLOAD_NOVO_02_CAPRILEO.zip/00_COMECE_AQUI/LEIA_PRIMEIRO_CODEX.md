# RPG ASSIMILAÇÃO — ACERVO VISUAL UNIFICADO · CODEX v001

**CLASSIFICAÇÃO:** MESTRE-SIDE / PRIVADO. NÃO publicar no GitHub público, Party, O Primeiro nem serviços externos sem autorização do Mestre.

## COMO ABRIR — UM ÚNICO ZIP, 3 BIBLIOTECAS, IMAGENS DIRETAS

Este pacote é um ZIP *único* com os **conteúdos originais extraídos** dos três ZIPs fornecidos pelo Mestre. NÃO contém três ZIPs aninhados e NÃO duplica os PNGs. Basta extrair este ZIP uma única vez e abrir os PNGs em cada pasta de criatura. Os nomes internos e o conteúdo binário de cada arquivo foram preservados, somente com prefixos diferentes de pasta para separar as bibliotecas.

1. `01_BESTA_CRISTALINA_v009/` — 16 PNGs, incluindo as pranchas A/B originais, 8 recortes AUXILIARES, quatro folhas de ataque e 2 folhas de caminhada (versão original *v009*). Leia `LEIA_PRIMEIRO_V009_CODEX.md` e `06_MOVIMENTO_QA_V009.json`. **ATENÇÃO**: a folha esquerda/direita de Cristalina é visualmente quase frontal; orientação lateral precisa de verificação independente.
2. `02_CAPRILEO_ESCAMOSO_OURO1_v001/` — 8 PNGs aprovados pelo Mestre (2 pranchas dos 8 ângulos, 2 ataques, 4 folhas de caminhada) + 1 JPEG original de referência. Leia `00_CONTROLE/README_CODEX.md` e `00_CONTROLE/manifest.json`. **ATENÇÃO**: a folha `CAMINHADA_02_ESQUERDA_DIREITA_2x5_APROVADA.png` possui alpha máximo 254; preservar fonte e verificar matting. Ouro 4★ Titã NÃO é a variante desta biblioteca.
3. `03_ORC_TEST/` — 13 PNGs (8 vistas individuais, 2 pranchas A/B, 2 estudos de ataque, 1 prancha de 12 vistas do machado). Leia `LEIA_ME.txt` e `MANIFESTO_ORC.json`. Arte TEST não implica animação funcional, especialmente nas folhas de ataque.
4. `00_COMECE_AQUI/` — instrução, catálogo global, mapa dos arquivos, hashes/QA do empacotamento e prompt pronto para Codex.

## FONTES E INTEGRIDADE

- `INVENTARIO_GERAL.json`: SHA-256, dimensão, tipo, bytes, caminho original no ZIP fonte e caminho novo em todos os 61 arquivos herdados.
- `INDICE_IMAGENS.csv`: índice compacto dos 38 arquivos de imagem (37 PNG + 1 JPG).
- `ORIGENS_E_VERSOES.md`: tamanho/hash dos três ZIPs de entrada. Como os arquivos internos foram preservados byte a byte, os hashes de cada fonte foram mantidos; o *byte stream* dos ZIPs de entrada não está repetido dentro deste pacote, para evitar dobrar o tamanho do upload.
- `QA_EMPACOTAMENTO.json`: resultados de testes reais do unificado; não é QA artístico ou de engine.
- Os manifestos e READMEs específicos de cada besta são sempre autoritativos para ordem, grade, histórico de aprovação e pendências daquela fonte. Um rótulo `APROVADO` significa aceite artístico documentado, não homologação do Codex.

## RESPONSABILIDADES / POLÍTICA

Mestre aprova a arte; Comestre guarda fontes e hashes; **Codex audita as folhas integrais por conta própria**, cria recortes derivados/pivôs/atlas e testa integração sem alterar fontes; VLAB governa dano, PA, alcance, condições e turnos. Nunca inferir mecânica a partir de VFX ou de quantidade de imagens. Não executar scripts presentes no pacote sem revisão, e preservar originais sempre que gerar derivados.

## ORDEM RECOMENDADA AO CODEX

1. Conferir `QA_EMPACOTAMENTO.json` + `INVENTARIO_GERAL.json`, localizar PNGs integrais e seus documentos de origem.
2. Verificar hashes/dimensões em vez de confiar apenas nos nomes e fazer inspeção visual independente.
3. Listar por besta: ângulos, consistência de anatomia/armas, séries de caminhada, ataques, efeitos e cobertura incompleta.
4. Testar recortes **derivados**, transparência real, bordas, frames, direção, sequência, continuidade, pivô/footprint/hitbox visual, qualidade de loop e mapa de frames com evidências.
5. Apresentar PASS/FAIL/HOLD e recomendações por besta, sem editar os originais e sem presumir engine já importada.
6. Não publicar nem compartilhar material Mestre-only. Se a tarefa for SOMENTE ANALISAR, não fazer push, commit, mudanças de Notion ou Godot sem nova ordem.

## LINKS DE ÍNDICES NOTION (APENAS REFERÊNCIAS)

- Cristalina: https://app.notion.com/p/406c2b324ede81859909cf00a5031609
- Capríleo: https://app.notion.com/p/406c2b324ede81f38af7f3f620baf05c
- Orc: https://app.notion.com/p/405c2b324ede816ca88af5f66f103a2a
- Portal Visual 2.5D: https://app.notion.com/p/405c2b324ede81eb80cfecc4ba47abdb

**PONTO DE RETOMADA:** entrega consolidada para avaliação Codex; arte original preservada. Não classificar como `CODEX_PASS` sem auditoria independente.
