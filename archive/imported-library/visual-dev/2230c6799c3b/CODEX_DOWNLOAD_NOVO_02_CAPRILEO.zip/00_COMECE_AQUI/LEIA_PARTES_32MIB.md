# RPG ASSIMILAÇÃO — ACERVO VISUAL DIVIDIDO PARA CODEX CLOUD (32 MiB)

ESTE É UM DOS 4 ZIPS INDEPENDENTES E EXTRAÍVEIS. Não é arquivo .001/.002 a ser remontado. Cada ZIP contém parte do conjunto, com caminhos originais do ZIP unificado e documentação de índice comum.

**ATENÇÃO:** os arquivos `00_COMECE_AQUI/LEIA_PRIMEIRO_CODEX.md` e `00_COMECE_AQUI/PROMPT_PRONTO_CODEX.md` vieram do ZIP unificado e mencionam um único ZIP. Isso é histórico. Use PRIMEIRO esta instrução e a ordem do Mestre; leia os quatro pacotes como um conjunto lógico; jamais conclua auditoria total antes dos quatro chegarem e seus conteúdos serem verificados.

Partes necessárias:
1. 01_BESTA_CRISTALINA_v009 — todas as fontes e documentos da Besta Cristalina.
2. 02_CAPRILEO_ESCAMOSO_v001 — todas as fontes e documentos do Capríleo.
3. 03_ORC_ANGULOS_CARDINAIS — 4 vistas do Orc e prancha A, manifesto.
4. 04_ORC_DIAGONAIS_ATAQUES — 4 vistas diagonais, prancha B, dois ataques e machado, manifesto.

`INVENTARIO_GERAL.json` lista TODOS os 61 arquivos das bibliotecas originais. Não interprete ausências das demais partes como corrupção do pacote corrente. Não comprima, redesenhe ou altere originais. Codex deve aplicar verificação independente; os PNGs continuam fonte primária para vistas e animações.

PROCEDIMENTO: extraia cada ZIP para a MESMA pasta privada de trabalho, preservando a árvore de caminhos. Os nomes repetidos em `00_COMECE_AQUI/` e os 2 arquivos de documentação do Orc possuem conteúdo idêntico e hashes idênticos; evite sobrescrever sem comparar hashes. Isso NÃO gera imagens duplicadas.

STATUS: empacotamento abaixo do limite de 32 MiB por parte. Limite real de aceitação do Codex ainda deve ser verificado; um arquivo abaixo do limite não garante que a interface montou a referência, portanto exija leitura dos arquivos e SHA no ambiente do Codex.

Classificação MESTRE-SIDE, não transferir à Party, O Primeiro ou repositório público.

**ESTA PARTE: 2/4 — 02_CAPRILEO_ESCAMOSO_v001.**

**Arquivos específicos desta parte:**
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/00_CONTROLE/HISTORICO_VERSOES.md`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/00_CONTROLE/README_CODEX.md`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/00_CONTROLE/RELATORIO_QA_v001.md`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/00_CONTROLE/manifest.json`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/00_REFERENCIA_MAE/IMAGEM_MAE_CAPRILEO_FORNECIDA_PELO_MESTRE_ORIGINAL.jpg`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/01_ANGULOS_ORIGINAIS/PRANCHA_A_CARDINAIS_2x2_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/01_ANGULOS_ORIGINAIS/PRANCHA_B_DIAGONAIS_2x2_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/02_ATAQUES_ORIGINAIS/ATAQUE_01_RABADA_3x4_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/02_ATAQUES_ORIGINAIS/ATAQUE_02_INVESTIDA_CABECADA_IMPACTO_3x4_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/03_CAMINHADA_ORIGINAIS/CAMINHADA_01_FRENTE_COSTAS_2x5_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/03_CAMINHADA_ORIGINAIS/CAMINHADA_02_ESQUERDA_DIREITA_2x5_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/03_CAMINHADA_ORIGINAIS/CAMINHADA_03_FRENTE_ESQUERDA_FRENTE_DIREITA_2x4_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/03_CAMINHADA_ORIGINAIS/CAMINHADA_04_COSTAS_ESQUERDA_COSTAS_DIREITA_2x4_APROVADA.png`
- `02_CAPRILEO_ESCAMOSO_OURO1_v001/tools/atualizar_biblioteca.py`
