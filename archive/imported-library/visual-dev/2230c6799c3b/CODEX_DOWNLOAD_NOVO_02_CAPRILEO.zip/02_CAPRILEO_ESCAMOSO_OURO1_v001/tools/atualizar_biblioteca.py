#!/usr/bin/env python3
"""Append one Mestre-approved PNG to an existing immutable library ZIP.

Usage:
  python atualizar_biblioteca.py previous.zip approved.png CATEGORY NAME
New version output is adjacent to `previous.zip`.
Does not modify `previous.zip`; refuses duplicate SHA or unknown category.
Does not automatically canonize the image, it requires explicit Mestre approval.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from io import BytesIO
from PIL import Image
from datetime import datetime, timezone
import sys, re, hashlib, json

if len(sys.argv)!=5:
    raise SystemExit("Usage: python atualizar_biblioteca.py previous.zip approved.png ANGULOS|ATAQUE|CAMINHADA NAME")
previous,source,category,name=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3].upper(),sys.argv[4]
if category not in ('ANGULOS','ATAQUE','CAMINHADA'):raise SystemExit('INVALID CATEGORY')
if not re.fullmatch(r'[A-Za-z0-9_-]{2,100}',name):raise SystemExit('INVALID NAME')
with ZipFile(previous) as z:
    if z.testzip() is not None: raise SystemExit('BROKEN ZIP')
    existing={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(existing['00_CONTROLE/manifest.json'])
    for it in manifest['files']:
        if hashlib.sha256(existing[it['path']]).hexdigest()!=it['sha256']:
            raise SystemExit('SOURCE MANIFEST MISMATCH')
raw=source.read_bytes(); im=Image.open(BytesIO(raw)); im.verify(); im=Image.open(BytesIO(raw))
if im.format!='PNG': raise SystemExit('PNG REQUIRED')
h=hashlib.sha256(raw).hexdigest()
if h in {x['sha256'] for x in manifest['files']}:raise SystemExit('DUPLICATE SHA256')
old_v=int(manifest['version'][1:]); new_v='v'+str(old_v+1).zfill(3)
if new_v!=('v'+str(old_v+1).zfill(3)):raise SystemExit('VERSION ERROR')
folder={'ANGULOS':'01_ANGULOS_ORIGINAIS','ATAQUE':'02_ATAQUES_ORIGINAIS','CAMINHADA':'03_CAMINHADA_ORIGINAIS'}[category]
path=f'{folder}/{name}_{h[:10]}.png'
manifest['files'].append({'path':path,'original_filename':source.name,'category':category,'purpose':name,'directions':[],'sheet':{'reading_order':'VERIFY_AND_RECORD'},'dimensions':{'width':im.width,'height':im.height},'mime':'image/png','image_mode':im.mode,'bytes':len(raw),'sha256':h,'approval_status':'APROVADO_ARTISTICAMENTE_PELO_MESTRE','approval_evidence':'MANUAL_RECORD_REQUIRED','pixel_preservation':'ORIGINAL_BYTES','qa':{'png_decode':'PASS','codex_visual_analysis':'PENDING','sprite_extraction':'PENDING'}})
manifest['version']=new_v
manifest['version_history'].append({'version':new_v,'date':datetime.now(timezone.utc).strftime('%Y-%m-%d'),'action':f'approved PNG append: {name}','retained_approved_pngs':len(manifest['files'])})
existing[path]=raw
existing['00_CONTROLE/manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
oldstr=f'_v{old_v:03d}.zip'
if not previous.name.endswith(oldstr):raise SystemExit('INVALID ZIP NAME')
out=previous.with_name(previous.name[:-len(oldstr)]+'_'+new_v+'.zip')
if out.exists():raise SystemExit('OUTPUT EXISTS: '+str(out))
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for n,b in existing.items():z.writestr(n,b)
with ZipFile(out) as z:
    if z.testzip() is not None:raise SystemExit('ZIP CRC FAIL')
    assert all(hashlib.sha256(z.read(it['path'])).hexdigest()==it['sha256'] for it in manifest['files'])
print(out)
