# RPG ASSIMILAÇÃO — BIBLIOTECA VISUAL DO CAPRÍLEO ESCAMOSO · OURO 1★

VERSÃO: v001 | ESCOPO: MESTRE-SIDE / TEST / PRIVADO-MESTRE-ONLY

## Acesso rápido ao Codex

Este arquivo armazena OITO PNGs ORIGINAIS de pranchas aprovadas artisticamente pelo Mestre.
**Não são sprites recortados prontos para engine e não representam homologação mecânica.**
Extraia o ZIP preservando os nomes, abra os PNGs integrais um por um e use `00_CONTROLE/manifest.json` para validar cada SHA-256.
Leia a imagem-mãe JPG como referência anatômica, não como uma nova sprite aprovada.

## Diretórios

- `00_REFERENCIA_MAE/` — JPEG da referência principal enviada pelo Mestre, intacto.
- `01_ANGULOS_ORIGINAIS/` — duas pranchas 2×2 de ângulos estáticos; não são movimento temporal.
- `02_ATAQUES_ORIGINAIS/` — ataque 01 rabada e ataque 02 corrida curta / salto / cabeçada / impacto.
- `03_CAMINHADA_ORIGINAIS/` — quatro pranchas de caminhada, contendo as oito direções.
- `00_CONTROLE/` — JSON, relatório de verificação, histórico e instruções de atualização.
- `tools/` — script auxiliar de validação/acréscimo cumulativo local, sem execução automática.

## Identidade visual

Besta demoníaca Capríleo Escamoso, **Ouro 1★ (NÃO Ouro 4★ Titã)**. Porte comparável a cavalo robusto, tronco quadrúpede com marcha inspirada no leão; cabeça ovino-reptiliana, grande juba creme-acinzentada, chifres gigantescos de carneiro com múltiplas curvas na referência, escamas cinza-pedra, espinhos dorsais, quatro membros e uma cauda longa espinhosa. Câmera especificada ~35° (não foi calibrada fisicamente). Preservar a geometria dos chifres e lados anatômicos; não espelhar indiscriminadamente.

## Mapeamento das vistas

`PRANCHA_A_CARDINAIS_2x2`:

- linha 1: frente | costas
- linha 2: esquerda | direita

`PRANCHA_B_DIAGONAIS_2x2`:

- linha 1: frente-diagonal-esquerda | frente-diagonal-direita
- linha 2: costas-diagonal-esquerda | costas-diagonal-direita

Este é o arranjo HISTÓRICO dos arquivos anexados; NÃO reordenar para outro protocolo posteriormente.

## Mapeamento da caminhada

| Prancha | Linha superior | Linha inferior | Colunas por linha |
| --- | --- | --- | --- |
| 01 | Frente | Costas | 5 |
| 02 | Esquerda | Direita | 5 |
| 03 | Frente diagonal esquerda | Frente diagonal direita | 4 |
| 04 | Costas diagonal esquerda | Costas diagonal direita | 4 |

Regra: **caminhada = uma linha para cada orientação, esquerda→direita, último quadro → primeiro da mesma linha.** A linha seguinte NÃO é continuação temporal.
A marcha deve alternar patas, deslocar cauda e juba e preservar massa/escala; Codex verifica independentemente se a arte efetivamente cumpre isso.
Total visual informado pela grade: 5+5+5+5+4+4+4+4 = **36 posições de caminhada**. Quantidade em grade não certifica 36 frames recortáveis perfeitos.

## Ataques — ordem temporal

Cada prancha de ataque contém **3 linhas × 4 colunas**, 12 quadros esperados por ataque.
Leia da esquerda para direita, linha 1→2→3, como uma única ação (row-major):

- Ataque 01: antecipação, elevação/rotação da cauda, chicotada, deslocamento e recuperação. A ordenação segue posição geométrica; Codex determinará contatos reais e timing.
- Ataque 02: preparação, corrida curta, pequeno salto, cabeçada e impacto, dissipação e retorno à postura. O impacto desenhado NÃO implica automaticamente dano/alcance VLAB.

## Sequência de análise obrigatória do Codex

1. Verificar SHA-256 e CRC/estrutura do ZIP; guardar fonte original imutável.
2. Abrir as duas pranchas ANGULARES completas antes de recortar qualquer coisa.
3. Conferir localização e continuidade de cauda, horns/chifres, juba, escamas, espinhos e quatro membros em oito direções.
4. Inspecionar transparência efetiva: RGBA não garante ausência de halos, fundos residuais ou contaminação de cores de borda. Alguns arquivos contêm pixels de alfa parcial nas margens; 504205 apresenta alfa máximo 254. Não alterar fontes originais para corrigir.
5. Definir células/limites reais, calcular pivôs, baseline, caixas de colisão separadas de VFX e teste de continuidade temporal; não pressupor células perfeitamente regulares sem inspeção.
6. Exportar DERIVADOS com manifestos novos que citam o hash original; os originais permanecem intactos. Usar no Godot/HTML autorizado, depois validar sprites animados visual e mecanicamente em gates distintos.
7. Não publicar em GitHub público; nenhum arquivo é Party-ready. Manter MESTRE-SIDE.

## Fronteiras de responsabilidade

Mestre = aprovação visual; Comestre = conservação e rastreabilidade; **Codex = análise independente e extração definitiva dos PNGs originais**; VLAB = regras/dano/alcance. Nenhuma habilidade mecânica é inferida dos VFX.

## Governança e atualização

PV-2.5D-BIB-04: cada nova arte aprovada exige atualização incremental na PRIMEIRA RODADA ATIVA com arquivos fisicamente disponíveis, nunca operação em background invisível.
Preservar v001 e anteriores; criar v002 etc, reutilizar a estrutura de pastas, deduplicar por SHA-256 e registrar toda alteração no `version_history` do manifesto. Não arquivar tentativas não aprovadas como oficiais.
Referência do modelo existente: https://app.notion.com/p/406c2b324ede81859909cf00a5031609
Referência mecânica Ouro 1 (possui legado interno divergente de rank/elemento): https://app.notion.com/p/80cc2b324ede82af80a1815df3cac448
