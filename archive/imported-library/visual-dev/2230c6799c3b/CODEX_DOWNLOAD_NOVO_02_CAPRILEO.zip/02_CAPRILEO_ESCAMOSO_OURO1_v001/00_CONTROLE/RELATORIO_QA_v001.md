# Gate técnico local — Capríleo v001

**ESCOPO:** bytes/formatos/ZIP, não homologação de arte ou ciclo. Fontes não sofreram modificações.

| Fonte | Resolução | Modo | Tamanho bytes | SHA prefixo | alfa min/max |
|---|---:|---|---:|---|---|
| `504200.png` | 1254×1254 | RGBA | 2,477,937 | `5138ad9e084a48` | (0, 255) |
| `504201.png` | 1774×887 | RGBA | 2,259,478 | `89ac68daf48948` | (0, 255) |
| `504202.png` | 1448×1086 | RGBA | 2,662,421 | `0718fb6a202e74` | (0, 255) |
| `504203.png` | 1448×1086 | RGBA | 2,699,786 | `49e3c1df0a762e` | (0, 255) |
| `504204.png` | 1774×887 | RGBA | 2,735,532 | `f55e767feb0375` | (0, 255) |
| `504205.png` | 1536×1024 | RGBA | 2,948,485 | `f429ea23e13d18` | (0, 254) |
| `504207.png` | 1448×1086 | RGBA | 2,351,890 | `f83d32a39cda64` | (0, 255) |
| `504208.png` | 1536×1024 | RGBA | 2,911,397 | `b00cfb8167f3bc` | (0, 255) |

- Decodificação: oito PNGs abertos e `verify()` PASS.
- Comparação SHA fonte→ZIP: PASS para oito PNGs e JPEG referência.
- Transparência: todos possuem RGBA com valores alfa variáveis. Isto não prova ausência de halos ou todos os pixels de fundo transparentes; verificar no Codex.
- Quadro legível, anatomia, câmera 35°, contagem isolada e pivô: NÃO CERTIFICADOS por esta auditoria binária.
- Ataques/vistas/walk: aceites artísticos documentados; engine e VLAB não testados.
- **PENDÊNCIA CONCRETA:** `504205.png` possui alfa máximo 254 (não há pixel completamente opaco, conforme fonte original). Preservado sem correção, cabe inspeção do Codex.
- **PENDÊNCIA:** as oito fontes PNG não estão anexadas binariamente à página do Notion pelo simples fato de existir a documentação. O armazenamento físico primário é o ZIP na Library privada e a conversa.
