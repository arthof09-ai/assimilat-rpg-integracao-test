# Histórico cumulativo

## v001 — 2026-10-27

- Criada a primeira versão da biblioteca do Capríleo Escamoso Ouro 1★.
- Guardados os 8 PNGs entregues pelo Mestre como fontes aprovadas: 2 pranchas angulares, 2 ataques, 4 pranchas de caminhada.
- Incluída referência primária JPEG fornecida em conversa, separada dos oito PNGs.
- Criados manifesto JSON, README Codex e verificações locais.
- Nenhum PNG/arte foi convertido, recortado ou alterado.
- Arquivo pronto para custódia privada; vinculação e readback do Notion/Library devem constar de recibos externos após upload efetivo.
