# Historico

## v001 — 2026-10-26/27 (registro deste pacote)
- Fonte: duas imagens enviadas pelo Mestre neste chat como Pranchas A/B.
- Status: versao de biblioteca de arte aceita pelo Mestre no dialogo, tecnico/engine ainda TEST/HOLD.
- Acao: preservar os 2 PNGs originais, exportar 8 recortes por quadrante sem reamostragem, produzir JSON/QA.
- Nenhuma arte gerada ou retocada neste processo de empacotamento.
- Proxima versao ao receber e confirmar novos ativos aceitos, mantendo v001 imutavel.

## v002 — 2026-10-26 (correção de responsabilidade técnica, sem arte nova)
- Decisão expressa do Mestre: análise, confirmação de orientações, recorte técnico e integração de pranchas A/B são atribuições do Codex; Comestre apenas disponibiliza recortes auxiliares.
- Não houve aprovação de imagens adicionais; pranchas A/B e 8 recortes idênticos byte a byte aos de v001, preservados com SHA-256.
- README, MANIFESTO, manifesto JSON, QA e contrato de reporte atualizados. Novo contrato `CODEX-INDEPENDENT-SHEET-QA-01` e modelo de relatório `RELATORIO_CODEX_PENDENTE.json`.
- Nenhuma inspeção independente, correção de alfa, pivô, importação ou animação foi executada pelo Codex. Primeiro passo pendente permanece essa análise.
- v001 permanece como versão anterior imutável e disponível separadamente.


## v003 — regulamento de custódia incremental e arte sem inscrição

Nenhuma nova imagem de arte incluída. As dez imagens herdadas de v002 foram preservadas byte a byte; adicionada ferramenta de incorporação de novas aprovações, contrato de conteúdo visual limpo e roteamento para QA independente Codex.
