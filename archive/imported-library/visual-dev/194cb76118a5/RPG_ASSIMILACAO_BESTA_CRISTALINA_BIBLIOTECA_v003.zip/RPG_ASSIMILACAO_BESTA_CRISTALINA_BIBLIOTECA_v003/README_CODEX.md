# Besta Cristalina | Biblioteca Visual v002 — LEIA PRIMEIRO (Codex)

**MESTRE-SIDE / TEST / não publicar em GitHub público ou Party.**

## DIRETRIZ CENTRAL DO MESTRE — CODEX É O RESPONSÁVEL

**O Codex deve fazer análise TÉCNICA INDEPENDENTE das duas pranchas originais antes de escolher, corrigir ou extrair sprites.**
A extração do Comestre na pasta `02_VISTAS_INDIVIDUAIS/` é trabalho AUXILIAR de organização, comparação e navegação: **NÃO é uma extração aprovada pelo Codex e NÃO significa que esteja pronta para integração na engine.**
Não reutilize os oito crops apenas por estarem na pasta. O Codex deve estudar os originais visuais, validar as oito orientações, localizar os limites efetivos de cada criatura, checar regiões alfa, margens, proporções, pose, pivôs e outras necessidades reais do jogo. Pode aproveitar, corrigir, substituir ou descartar o trabalho auxiliar, documentando a justificativa. O Mestre aprova a direção artística; o Codex responde pela validação técnica e integração autorizada.

## Prioridade obrigatória de leitura
1. **FONTES PRIMÁRIAS:** `01_PRANCHAS_COMPLETAS/PRANCHA_A_CARDINAIS.png` e `01_PRANCHAS_COMPLETAS/PRANCHA_B_DIAGONAIS.png`, íntegras e em resolução original 1536×1024, RGBA. Os hashes SHA-256 estão no `manifest.json`.
2. **MAPA INICIAL:** A: frente, costas, esquerda, direita; B: frente-esquerda, frente-direita, costas-esquerda, costas-direita. Em cada prancha, a ordem proposta está em 2×2 (superior esquerdo, superior direito, inferior esquerdo, inferior direito). Mapas de rótulos são organização humana e merecem inspeção visual independente, não são laudos de geometria.
3. **ARQUIVOS AUXILIARES:** `02_VISTAS_INDIVIDUAIS/...`, oito PNGs recortados das células de tamanho 768×512 (sem resampling) e sem certificação semântica de sprite. Um recorte de quadrante pode incluir grandes margens, fundo residual ou partes cortadas; integridade de pixels não prova adequação à engine.
4. **PROCESSO TÉCNICO CODEx:** ler `03_QA_CODEX_INDEPENDENTE/CONTRATO_EXECUTOR_CODEX.md` e iniciar `RELATORIO_CODEX_PENDENTE.json` com status PENDENTE. Fazer seu próprio exame visual, recorte técnico e validação no projeto autorizado. Não declarar PASS sem relatório e evidência de execução.

## Continuidade e versões
A v002 modifica APENAS metadados e instruções; todos os 10 PNGs são preservados byte a byte de v001. **Preservar v001 imutável** e não tratar v002 como novas imagens aprovadas. Quando o Mestre aprovar NOVAS pranchas/animacões, incluir originais, manter linhagem e gerar v003 (ou próxima versão) com hashes e readback, sem recriar o personagem do zero.

## Limites técnicos comprovados
Os PNGs têm canal alfa e pixels transparentes, mas limpeza completa das bordas, resíduos roxos, valor EXATO 35° da câmera, pivôs, hitbox, time-based animations, escala em tiles e importação Godot continuam **NÃO VALIDADOS PELO CODEX**. VLAB mantém autoridade sobre combate e regras mecânicas; uma arte ou crop não aprova impacto, dano, PA ou movimentação.

## Notion
Biblioteca visual: https://app.notion.com/p/406c2b324ede81859909cf00a5031609
Portal de regras: https://app.notion.com/p/405c2b324ede81eb80cfecc4ba47abdb
Esta página do Notion **não contém os bytes dos PNGs**; fornecer o ZIP completo ao executor Codex de forma autorizada.


## ATUALIZAÇÃO v003 — LEIA PRIMEIRO

Aplicar `ATUALIZACAO_INCREMENTAL_E_ARTE_LIMPA.md`: atualização por cada aprovação, arte sem qualquer inscrição nos pixels, Codex avalia independentemente originais. v003 é revisão documental/técnica; as 10 imagens de v002 estão byte-idênticas.
