# Biblioteca Visual Besta Cristalina — v003

**Estado:** MESTRE-SIDE / TEST; conteúdo novo: PROCESSO e FERRAMENTA, sem nova imagem.

## Regra do Mestre: aprovação implica atualização imediata

Ao dizer que uma imagem está aprovada/oficial, atualize, nesse mesmo turno de trabalho, o pacote da entidade, desde que os bytes PNG e o ZIP anterior estejam acessíveis. Não acumule aprovações aguardando um pedido posterior para reunir imagens.

Se faltar o ZIP anterior ou bytes da imagem, recuperar de fontes privadas autorizadas antes de solicitar novo envio. Caso não seja possível, registrar HOLD e o arquivo faltante, sem declarar atualização realizada e sem prometer trabalho em segundo plano.

Cada versão é um ZIP imutável. Uma nova aprovação gera a versão seguinte; não altera nem apaga imagens originais aprovadas de versões anteriores. Inserir PNG sem reamostragem; SHA-256, origem, nome, categoria, aprovação e linhagem vão em `manifest.json` e `HISTORICO_VERSOES.md` **FORA** das imagens.

## Regra definitiva de arte limpa

A imagem PNG pode conter **somente** o personagem/criatura/item/arma/equipamento e os VFX intrínsecos à cena solicitada. **ZERO** números, letras, palavras, nomes de ângulo, títulos, índices, códigos, legendas, etiquetas, setas, separadores desenhados, grades, logos, assinaturas, marca-d'água, molduras ou UI, inclusive nas margens. Conteúdo informativo e ordem exclusivamente no nome do arquivo, JSON ou README externo. Imagens aprovadas exigem exame visual. A ferramenta automatizada verifica PNG/RGBA/hash, mas NÃO comprova ausência de símbolos desenhados na arte: esse gate continua PENDENTE até inspeção manual/independente.

## Responsabilidades

Mestre = aprovar arte; Comestre = organização/custódia e recortes opcionais auxiliares; Codex = análise independente de cada prancha ORIGINAL completa, seus ângulos, transparência, limites e extração técnica. Os recortes prontos nunca transferem a responsabilidade do Codex.

## Como anexar UMA nova imagem aprovada

```bash
python tools/atualizar_biblioteca_aprovacao.py \
  --base RPG_ASSIMILACAO_BESTA_CRISTALINA_BIBLIOTECA_v003.zip \
  --imagem /caminho/imagem_aprovada.png \
  --categoria ATAQUES \
  --descricao "Habilidade aprovada pelo Mestre" \
  --aprovacao "Mestre aprovou explicitamente a imagem" \
  --referencia "Prancha B original; perspectiva e cores preservadas" \
  --nome ATAQUE_APROVADO
```

O programa emite `v004.zip`, sem alterar `v003.zip`, rejeita duplicatas por hash e valida os PNGs; não incorpora recortes artificiais nem faz OCR ou leitura imaginária. O Codex verifica independentemente as pranchas originais e decide recortes/atlas do jogo.

## Estado v003

- 2 pranchas originais íntegros e 8 recortes auxiliares íntegros, exatamente como v002.
- Novo script `tools/atualizar_biblioteca_aprovacao.py` e este contrato de execução.
- Nenhuma nova imagem aprovada neste turno; próxima aprovação = v004.
- Nenhum PASS de animação, Godot, qualidade de borda, ausência total de caracteres nos PNGs herdados, ou extração Codex foi declarado.
