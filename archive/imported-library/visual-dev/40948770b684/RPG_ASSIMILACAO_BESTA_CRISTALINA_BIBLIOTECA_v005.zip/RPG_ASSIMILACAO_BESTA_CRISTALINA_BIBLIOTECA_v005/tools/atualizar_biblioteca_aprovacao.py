#!/usr/bin/env python3
"""Atualiza biblioteca visual do RPG após aprovação explícita do Mestre.

Uso: python atualizar_biblioteca_aprovacao.py --base arquivo_v003.zip \
  --imagem imagem_aprovada.png --categoria ATAQUES --descricao '...' \
  --aprovacao 'Mestre aprovou esta imagem' --referencia 'PRANCHA_A_CARDINAIS.png'

Cria vNNN+1, NÃO modifica vNNN e nunca gera/desenha/recorta PNG novo.
Status de análise independente Codex permanece PENDENTE.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

try:
    from PIL import Image
except ImportError as exc:
    raise SystemExit("Instale Pillow: python -m pip install pillow") from exc

CATS = ("ANGULOS", "MOVIMENTO", "ATAQUES", "HABILIDADES", "MAGIAS", "ITENS", "ARMAS", "OUTROS")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require_png(file: Path) -> dict:
    data = file.read_bytes()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Arquivo de origem não é PNG real")
    with Image.open(file) as img:
        img.load()
        if img.format != "PNG" or img.mode != "RGBA":
            raise ValueError("É exigido PNG RGBA original; não converter silenciosamente nem inventar transparência")
        alpha = img.getchannel("A")
        a_min, a_max = alpha.getextrema()
        if a_min >= 255:
            raise ValueError("Sem transparência comprovada: alfa totalmente opaco (HOLD)")
        return dict(width=img.width, height=img.height, format="PNG", mode=img.mode,
                    alpha_min=a_min, alpha_max=a_max, bytes=len(data), sha256=sha(data))


def safe_unpack(archive: Path, target: Path) -> Path:
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError("Falha de CRC no pacote de entrada")
        names=[i.filename for i in z.infolist() if not i.is_dir()]
        if not names:
            raise ValueError("ZIP vazio")
        roots={n.split("/")[0] for n in names}
        if len(roots) != 1:
            raise ValueError("ZIP deve ter apenas uma pasta raiz")
        for item in z.infolist():
            n=item.filename
            if n.startswith("/") or "\\" in n or any(x in ("..", "") for x in n.rstrip("/").split("/")):
                raise ValueError(f"Caminho suspeito no ZIP: {n}")
        z.extractall(target)
    root=target/next(iter(roots))
    if not (root/"manifest.json").exists():
        raise ValueError("manifest.json ausente")
    return root


def valid_name(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "_", name.strip()).strip("_")
    if not s or len(s) > 95:
        raise ValueError("Nome de arquivo precisa ser identificável (até 95 caracteres A-Z/0-9/_/-)")
    return s.upper()


def check_predecessors(root: Path, manifest: dict):
    for rec in manifest.get("sheet_sources", []) + manifest.get("assets", []) + manifest.get("approved_additions", []):
        path = root / rec["file"]
        if not path.is_file() or sha(path.read_bytes()) != rec["sha256"]:
            raise ValueError(f"HASH/FONTE do catálogo anterior inválido: {rec['file']}")


def repackage(root: Path, output: Path):
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                archive.write(path, arcname=f"{root.name}/{path.relative_to(root).as_posix()}")
    with zipfile.ZipFile(output) as z:
        if z.testzip() is not None:
            raise ValueError("ZIP gerado com CRC inválido")


def main():
    p=argparse.ArgumentParser(description="Edição cumulativa de biblioteca visual SEM alterar imagens originais")
    p.add_argument("--base",type=Path,required=True,help="ZIP vigente vNNN, que permanece intacto")
    p.add_argument("--imagem",type=Path,required=True,help="PNG aprovado pelo Mestre")
    p.add_argument("--categoria",choices=CATS,required=True)
    p.add_argument("--descricao",required=True)
    p.add_argument("--aprovacao",required=True,help="Trecho verificável da aprovação expressa do Mestre")
    p.add_argument("--referencia",required=True,help="Ativo original ou etapa anterior usada como referência")
    p.add_argument("--nome",help="Slug sem extensão para a imagem, fora dos pixels")
    p.add_argument("--saida",type=Path,help="Caminho do ZIP seguinte; padrão vNNN+1 na mesma pasta")
    args=p.parse_args()
    if not args.base.is_file() or not args.imagem.is_file():
        p.error("É indispensável fornecer o ZIP anterior e um PNG fisicamente acessível")
    if not args.aprovacao.strip() or not args.descricao.strip() or not args.referencia.strip():
        p.error("Aprovação, descrição e referência são obrigatórias")
    detail = require_png(args.imagem)
    with tempfile.TemporaryDirectory(prefix="visual_assets_") as tmp:
        root=safe_unpack(args.base,Path(tmp))
        manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"))
        check_predecessors(root,manifest)
        all_png=[x for x in root.rglob("*.png") if x.is_file()]
        found=[str(x.relative_to(root)) for x in all_png if sha(x.read_bytes())==detail["sha256"]]
        if found:
            raise ValueError("A imagem já existe neste pacote (mesmo SHA): "+", ".join(found))
        old_v=int(manifest.get("version_number",0))
        if old_v < 1 or manifest.get("catalog_version") != f"v{old_v:03d}":
            raise ValueError("Versionamento do manifesto anterior inconsistente")
        new_v=old_v+1
        if new_v > 999:
            raise ValueError("Versão excedeu três dígitos")
        new_version=f"v{new_v:03d}"
        out=args.saida or args.base.with_name(re.sub(r"v\d{3}(?=\.zip$)",new_version,args.base.name))
        if out.resolve()==args.base.resolve() or out.exists():
            raise ValueError("O destino não pode sobrescrever ZIP anterior nem arquivo existente")
        out.parent.mkdir(parents=True,exist_ok=True)
        # Renomear apenas a pasta que encapsula a biblioteca; NUNCA mudar os PNGs aprovados.
        name=re.sub(r"v\d{3}$",new_version,root.name)
        if name==root.name:
            raise ValueError("Pasta raiz sem sufixo de versão")
        newroot=root.with_name(name)
        root.rename(newroot)
        root=newroot
        slug=valid_name(args.nome or args.imagem.stem)
        dest_rel=f"04_ATIVOS_APROVADOS/{args.categoria}/{slug}_{detail['sha256'][:12]}.png"
        dest=root/dest_rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():
            raise ValueError("Destino duplicado")
        shutil.copyfile(args.imagem,dest)
        rec={"asset_id":f"BC-APP-{new_v:03d}","file":dest_rel,"category":args.categoria,
             "description":args.descricao,"approval_evidence":args.aprovacao,
             "reference_lineage":args.referencia,"approval_status":"APROVADO_ARTISTICAMENTE_PELO_MESTRE",
             "codex_independent_assessment":"PENDENTE", "asset_role":"APPROVED_ORIGINAL_FOR_CODEX_ANALYSIS",
             "editorial_text_in_pixels":"PENDENTE_INSPECAO_VISUAL",
             "approved_at_utc":datetime.now(timezone.utc).isoformat(),**detail}
        manifest.setdefault("approved_additions",[]).append(rec)
        manifest["catalog_version"]=new_version
        manifest["version_number"]=new_v
        manifest["last_update_type"]="single_master_approved_visual_asset"
        manifest["image_content_policy"]="ONLY_VISUAL_ART, NO_TEXT_LETTERS_NUMBERS_LABELS_CODES_TITLES_WATERMARKS_IN_PIXELS"
        manifest["codex_qa_policy"]="INDEPENDENTLY_INSPECT_ORIGINAL_IMAGES; AUXILIARY_CROPS_NOT_CERTIFICATION"
        manifest["approved_assets_count"] = len(manifest["sheet_sources"])+len(manifest["approved_additions"])
        (root/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        hist=root/"HISTORICO_VERSOES.md"
        with hist.open("a",encoding="utf-8") as f:
            f.write(f"\n## {new_version} — aceite unitário incremental\n\n- Fonte acrescentada: `{dest_rel}`\n- Aprovação do Mestre: {args.aprovacao}\n- Referência: {args.referencia}\n- SHA-256: `{detail['sha256']}`\n- Codex QA independente: PENDENTE\n- ZIP anterior `{args.base.name}` preservado sem alteração.\n")
        check_predecessors(root,manifest)
        repackage(root,out)
        with zipfile.ZipFile(out) as z:
            saved=json.loads(z.read(f"{root.name}/manifest.json"))
            if saved["catalog_version"]!=new_version or len(saved["approved_additions"])!=len(manifest["approved_additions"]):
                raise ValueError("Readback do manifesto no novo ZIP FAIL")
        print(json.dumps({"status":"PASS_INTEGRIDADE_NAO_QA_VISUAL","zip":str(out),"size_bytes":out.stat().st_size,
                          "sha256":sha(out.read_bytes()),"version":new_version,"new_image":dest_rel,
                          "originals_preserved":True,"codex_qa":"PENDENTE"},ensure_ascii=False,indent=2))

if __name__ == "__main__":
    main()
