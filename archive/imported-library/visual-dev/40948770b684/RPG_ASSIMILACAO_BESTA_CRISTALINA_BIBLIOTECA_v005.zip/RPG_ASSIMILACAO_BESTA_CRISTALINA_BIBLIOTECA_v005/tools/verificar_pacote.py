#!/usr/bin/env python3
"""Verifier for catalog paths/metadata. Requires only Python 3 + Pillow for image QA."""
from pathlib import Path
import hashlib, json
try:
 from PIL import Image
except ImportError:
 raise SystemExit('Instale pillow para verificar PNG: python -m pip install pillow')
root=Path(__file__).resolve().parent.parent
m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
assert len(m['sheet_sources'])==2 and len(m['assets'])==8
for rec in m['sheet_sources']+m['assets']:
 path=root/rec['file']; assert path.is_file(),path
 assert hashlib.sha256(path.read_bytes()).hexdigest()==rec['sha256'],path
 with Image.open(path) as im:
  assert im.mode=='RGBA' and im.size==(rec['width'],rec['height'])
for rec in m['assets']:
 source=next(x for x in m['sheet_sources'] if x['sheet']==rec['sheet'])
 with Image.open(root/source['file']) as orig, Image.open(root/rec['file']) as crop:
  assert orig.crop(tuple(rec['crop_box_source_px'])).tobytes()==crop.tobytes()
print('PASS: 2 pranchas RGBA e 8 vistas recortadas sem reamostragem. Hashes e posicoes confirmados.')
