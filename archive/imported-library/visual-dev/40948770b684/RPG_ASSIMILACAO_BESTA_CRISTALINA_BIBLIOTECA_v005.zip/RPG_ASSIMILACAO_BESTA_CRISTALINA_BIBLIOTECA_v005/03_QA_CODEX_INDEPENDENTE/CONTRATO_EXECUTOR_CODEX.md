# CONTRATO CODEX-INDEPENDENT-SHEET-QA-01

**Origem:** correção expressa do Mestre do RPG Assimilação. **Escopo:** análise e segmentação das Pranchas A/B aprovadas da Besta Cristalina. **Status:** Ordem de trabalho, não comprovação de execução.

## Separação de responsabilidades
- **Mestre:** autoriza e aprova a estética, vistas e versões.
- **Comestre:** recebe, preserva e cataloga originais/hashes; pode fornecer propostas auxiliares de crops/metadados, sem substituir o executor.
- **Codex:** inspeciona independentemente A/B completas, valida direções, alfa, mascaramento, limites, pivô, dimensão, coerência da anatomia e adequação dos recortes ao Tabletop/Godot; pode gerar sua própria extração e deve registrar PASS/FAIL/HOLD e evidências.

## Checkpoints independentes obrigatórios
1. Extraia o pacote inteiro e confirme SHA-256 dos dois PNGs de `01_PRANCHAS_COMPLETAS`, antes de analisar crops.
2. Abra visualmente ambas as folhas originais completas; compare os 4 blocos por folha com a tabela de direção do manifesto. Observe se o sprite invade quadrantes, se cristal/cauda são cortados, se geometria e assimetrias são consistentes e se o fundo do original contém resíduos.
3. **Não deduza a região ótima de recorte a partir de uma grade fixa sem testar.** Identifique limites reais, margens seguras, preservação de cauda e cristais, máscara alfa e antialias, e posição do pivô/root ou âncora da criatura para o jogo.
4. Compare com os oito crops **auxiliares do Comestre** em `02_VISTAS_INDIVIDUAIS` apenas APÓS a sua análise; aprove-os, reprocesse-os ou rejeite-os com fundamento. Atenção: 'crop pixel perfect' pode ser inadequado ao jogo.
5. Se autorizado, crie em sua área de trabalho `CODEX_OUTPUT/` com imagens novas, manifesto de orientações e relatório. **Não sobrescreva** originais ou as referências originais do Mestre.
6. Execute os testes de importação/preview no Godot/Tabletop apenas se tiver acesso autorizado. Não invente resultados nem informe PASS da integração se não executado.
7. Entregue diferenças originais vs auxiliar vs resultado do Codex, com dimensões, SHA, critério de aprovação e FIRST-PENDING. Encaminhe ao Mestre quando houver dúvida de lado, anatomia ou fidelidade visual.

## PASS por dimensão
- `file_integrity` pode ser PASS independente de `angle_semantics`, `crop_quality`, `true_alpha_matte`, `pivot`, `animation`, `runtime`.
- `Codex_execution`: PENDENTE até o Codex ler/praticar sua análise de verdade e assinar sua evidência.
- `master_art_approval`: aprovado para a referência gráfica; não implica aprovação automática para exportação final na engine.

## Escopo
MESTRE-ONLY, Party/O Primeiro NO-WRITE, sem motor paralelo. As regras visuais vigentes estão no Portal 2.5D. As regras mecânicas permanecem com VLAB.
