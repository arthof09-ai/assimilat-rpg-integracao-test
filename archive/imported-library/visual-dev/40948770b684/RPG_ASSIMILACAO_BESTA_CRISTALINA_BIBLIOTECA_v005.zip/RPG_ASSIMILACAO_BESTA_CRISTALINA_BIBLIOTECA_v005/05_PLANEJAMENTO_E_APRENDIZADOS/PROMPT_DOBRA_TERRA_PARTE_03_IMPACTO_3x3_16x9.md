# RPG ASSIMILAÇÃO — DOBRA DE TERRA · PARTE 3/3
## PROMPT DE PRODUÇÃO: IMPACTO, FRAGMENTAÇÃO E DISSIPAÇÃO

**ESTADO: PROPOSTO / TEST — ainda não gerado nem aprovado.**
**REFERÊNCIA PRIMÁRIA INEGOCIÁVEL:** PNG completo da Parte 2/3 **APROVADA** armazenada neste ZIP em `04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PARTE_02_PROJETIL_VOO_3X3_APROVADA_fd77c2af53f3.png`.
**LINHAGEM:** Pranchas A/B do monstro → Parte 1 (elevação/arremesso) APROVADA → Parte 2 (rocha em voo) APROVADA → Parte 3 (este pedido de colisão) PENDENTE.

### EXCLUSIVAMENTE O QUE DEVE APARECER

Uma sprite sheet **só da mesma rocha** da Parte 2, chocando-se contra um **alvo invisível**, fragmentando-se e dissipando-se, com grande massa geológica marrom-acinzentada, irregular, formada de facetas e placas, fissuras magenta pulsantes e rastro de energia roxa já estabelecidos. Não mostrar a Besta Cristalina, cabeça, cauda, braços, corpo, inimigo, parede, chão, cratera, cenário ou objeto-alvo. Não reapresentar levantamento nem voo longo anterior. A Parte 3 acontece exclusivamente durante a curta janela do impacto.

**FORMATO:** UM PNG RGBA realmente transparente; retângulo **16:9 EXATO**; grade **3 LINHAS × 3 COLUNAS com células iguais**; nove quadros, leitura esquerda→direita, depois linha seguinte; nenhum número, letra, título, seta, rótulo, moldura, divisor, marca d’água, UI ou checkerboard rasterizado. Alta qualidade de detalhe nativo, pixels nítidos, texturas geológicas e bordas limpas, sem zoom de fachada e sem perdas por redimensionamento.

### COREOGRAFIA 1–9 (somente manifesto; números NÃO aparecem no PNG)

01. A mesma rocha **inteira** que aparece no último quadro da Parte 2, com forma, proporção, orientação, energia, cristais, velocidade e rastro coerentes; está próxima do alvo invisível à direita.
02. Aproximação crítica, direção constante; concentração visível de energia e partículas atrás; NÃO há explosão.
03. **Primeiro contato** com uma resistência invisível à direita: leve achatamento na face frontal e primeiras trincas; rocha principal ainda inteira e reconhecível.
04. Trincas percorrem frontal→centro; soltam-se os primeiros fragmentos coerentes com lascas já visíveis, a luz magenta atravessa as fissuras.
05. **ÚNICO CLÍMAX**: ruptura súbita e potente da rocha em grandes blocos, médios fragmentos, poeira e faíscas minerais magenta no MESMO ponto de impacto.
06. Grandes blocos se afastam do centro da colisão; nenhum segundo projétil completo e nenhuma explosão adicional.
07. Fragmentos mantêm as mesmas trajetórias e tamanhos coerentes; energia já começa a perder intensidade.
08. Fragmentos menores e poeira permanecem suspensos e dispersam; efeito magenta esmaece gradualmente.
09. Apenas resíduos discretos, fragmentos pequenos e partículas magenta se apagando; próximo quadro poderia ser transparência total, sem cena, alvo ou criatura.

**FÍSICA TEMPORAL:** continuidade frame a frame; a mesma massa se transforma nos fragmentos dos quadros posteriores; não criar material ou rocha do nada; não teletransportar partículas; ponto de colisão e perspectiva 2.5D estáveis; a rocha não reconstitui a massa no final. Preservar espaço seguro entre células; manter pivô de efeito/impacto descrito em metadados, não sobre os pixels. Impacto marcado por pico isolado no quadro 05, com dissipação — NÃO nove impactos independentes.

### RESTRIÇÕES ABSOLUTAS (GATE DE REJEIÇÃO)

- **ZERO MONSTRO:** nenhuma anatomia, cauda, braço, garra, silhueta ou rosto.
- **ZERO ALVO VISÍVEL:** adversário, solo, coluna, parede, cratera e cenário proibidos; colisão inferida fisicamente pelo contato/ruptura da rocha.
- **ZERO REPETIÇÃO:** não recontar Parte 1 (preparação/arremesso) nem Parte 2 (voo prolongado).
- **ZERO FUNDO OU INSCRIÇÃO:** canal alfa 0 onde não há efeito; checkerboard visual em preview NÃO é transparência; nenhuma codificação textual rasterizada.
- **UMA ROCHA, UMA COLISÃO, UMA FRAGMENTAÇÃO E UM ENCERRAMENTO.**

### GATE DE ACEITE

Só aceitar se a composição contiver **9 quadros distintos, progressivos** da mesma pedra aprovada na Parte 2; o primeiro quadro conectar diretamente ao último da Parte 2, o choque for inteligível mesmo sem desenhar o adversário, o efeito se quebrar e dissipar sem mostrar outra criatura, a proporção for 16:9 EXATA, células 3×3 IGUAIS, pixels de alta qualidade, PNG RGBA REAL com fundo não pintado. Qualquer falha = TEST REPROVADO, sem entrada na biblioteca oficial.

**GOVERNANÇA:** Mestre aprova o resultado artístico; Comestre organiza fontes, versões e QA documental; Codex deve analisar os PNGs integrais independentemente para segmentação, pivôs, escala e importação. A animação NÃO define por si dano, alcance, PA, iniciativa ou custos VLAB.
