# RPG ASSIMILAÇÃO — APRENDIZADOS DA DOBRA DE TERRA — 27/10/2026

**STATUS DAS ETAPAS:** Parte 1/3 do monstro erguendo/lançando rocha: APROVADA pelo Mestre e incluída em v004, com original intacto. Parte 2/3 somente rocha em voo: APROVADA EXPRESSAMENTE pelo Mestre no turno “Perfeito, aprovado.”, incorporada em v005, original intacto. Parte 3/3 colisão/estilhaçamento: PROMPT PROPOSTO, SEM IMAGEM GERADA/APROVADA; primeira execução PENDENTE.

## REGISTRO DE FALHAS TEST ANTERIORES — NÃO APROVADOS

- As tentativas da Parte 2 foram reprovadas pelo Mestre ao incluírem a Besta Cristalina, o arremesso completo, cratera, impacto e explosão antecipada; a ferramenta misturou etapas em vez de renderizar um ativo isolado.
- Uma tentativa exibiu quadriculado rasterizado simulando transparência, proibido pela norma. O simples nome .png não prova canal alfa.
- Melhor caminho comprovado de DIREÇÃO CRIATIVA: especificar **somente a rocha**, sem qualquer criatura, alvo ou colisão, e descrever 9 fases cronológicas distintas; resultado correspondente foi aprovado. Isso não prova interpolação 3D ou importação na engine.
- **Para Parte 3**, não repetir a falha: a pedra do último quadro da Parte 2 deve chegar intacta ao choque, então rachar uma vez, explodir em fragmentos coerentes e dissipar sem desenhar inimigo, cenário, personagem ou chão. Não reintroduzir o monstro.

## VERIFICAÇÃO DE ARQUIVOS

- Partes 1 e 2 estão fisicamente neste ZIP e são fontes de pixels aprovadas artisticamente.
- Nenhuma das imagens TEST reprovadas foi incluída na pasta de ativos APROVADOS.
- Partes A/B originais e 8 recortes auxiliares preservados; responsabilidade do Codex sobre análise própria dos integrais permanece.
- PNG RGBA e geometria verificáveis, mas perfeição do matting, persistência de massa na animação, pivôs, fps e importação Godot/Tabletop NÃO certificados pelo Codex.

## NEXT

Gerar **somente** a Parte 3 usando o arquivo de prompt deste diretório, inspecionar 9 quadros e alfa/grade; se Mestre aprovar expressamente, emitir v006, preservar v005, documentar arquivo/hash, executar readback e atualizar Notion + Biblioteca privada; análise de integração técnica continua do Codex.
