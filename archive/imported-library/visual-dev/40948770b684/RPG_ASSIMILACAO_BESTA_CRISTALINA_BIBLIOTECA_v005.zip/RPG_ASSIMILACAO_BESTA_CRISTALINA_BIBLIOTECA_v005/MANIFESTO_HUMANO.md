# Ordem e função dos arquivos — v002

| Prancha | Superior esquerda | Superior direita | Inferior esquerda | Inferior direita |
|:--|:--|:--|:--|:--|
| A — cardinal | Frente | Costas | Esquerda | Direita |
| B — diagonal | Frente-esquerda | Frente-direita | Costas-esquerda | Costas-direita |

**FONTES PRIMÁRIAS:** os 2 PNGs em `01_PRANCHAS_COMPLETAS/` aprovados pelo Mestre e imutáveis da v001. **RECORTES `02_VISTAS_INDIVIDUAIS`:** apenas material auxiliar do Comestre, NÃO certificados pelo Codex e NÃO homologados para jogo. A classificação posicional da tabela é indicação para revisão, não prova de orientação final.

**Responsável técnico por análise/extração:** Codex, que precisa examinar as pranchas integrais e registrar seu próprio relatório, podendo rejeitar os recortes auxiliares. As quatro perspectivas de cada imagem são estáticas, não frames de caminhada. A elevação de 35° é alvo artístico, não medição física demonstrada.
