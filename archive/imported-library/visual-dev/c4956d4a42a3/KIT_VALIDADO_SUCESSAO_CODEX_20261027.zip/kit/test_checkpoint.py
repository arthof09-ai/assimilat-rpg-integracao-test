import importlib.util,pathlib,tempfile,unittest,json
spec=importlib.util.spec_from_file_location('cp',pathlib.Path(__file__).with_name('checkpoint.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class CheckpointTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.r=pathlib.Path(self.temp.name);self.src=self.r/'src';self.src.mkdir();(self.src/'a.txt').write_text('estado recuperável');(self.src/'assets').mkdir();(self.src/'assets/x.bin').write_bytes(bytes(range(256))*100);self.dest=self.r/'backups'
 def tearDown(self):self.temp.cleanup()
 def snap(self):
  x=m.backup({'project':str(self.src)},self.dest);return self.dest/x['snapshot']/'INDEX.json'
 def test_roundtrip_and_history(self):
  idx=self.snap();out=self.r/'restore';m.restore(idx,out);self.assertEqual((out/'project/assets/x.bin').read_bytes(),(self.src/'assets/x.bin').read_bytes());(self.src/'a.txt').write_text('novo');idx2=self.snap();self.assertNotEqual(idx,idx2);self.assertTrue(idx.exists())
 def test_unchanged(self):
  self.snap();self.assertEqual(m.backup({'project':str(self.src)},self.dest)['status'],'UNCHANGED')
 def test_corrupt_part_rejected(self):
  idx=self.snap();data=json.loads(idx.read_text());p=idx.parent/data['parts'][0]['name'];p.write_bytes(b'corrupt');target=self.r/'rejected'
  with self.assertRaises(ValueError):m.restore(idx,target)
  self.assertFalse(target.exists())
 def test_existing_target_preserved(self):
  idx=self.snap();target=self.r/'keep';target.mkdir();(target/'keep').write_text('intacto')
  with self.assertRaises(ValueError):m.restore(idx,target)
  self.assertEqual((target/'keep').read_text(),'intacto')
 def test_no_recursive_backup(self):
  nested=self.src/'backups';nested.mkdir();(nested/'old.zip').write_bytes(b'old');x=m.backup({'project':str(self.src)},nested);manifest=json.loads((nested/x['snapshot']/'FILES.json').read_text());self.assertFalse(any('/backups/' in n for n in manifest))
if __name__=='__main__':unittest.main(verbosity=2)
