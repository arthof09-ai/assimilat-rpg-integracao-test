"""Backup/restore sem dependências, versões imutáveis, SHA256 e divisão em 30MiB."""
import argparse,datetime,hashlib,json,os,pathlib,tempfile,zipfile,shutil,uuid
P=pathlib.Path
def sha(p):
 h=hashlib.sha256()
 with P(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):P(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def backup(roots,dest):
 dest=P(dest).resolve();dest.mkdir(parents=True,exist_ok=True)
 lock=dest/'.checkpoint.lock'
 fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.close(fd)
 stage=None
 try:
  files=[]
  for label,root in roots.items():
   root=P(root).resolve()
   if not root.is_dir():raise ValueError('Fonte ausente: '+str(root))
   for p in sorted(root.rglob('*')):
    if p.is_symlink():raise ValueError('Symlink exige decisão explícita: '+str(p))
    if not p.is_file() or dest==p or dest in p.parents:continue
    rel=p.relative_to(root)
    if any(s in {'.godot','__pycache__','node_modules','.pytest_cache'} for s in rel.parts):continue
    files.append((label+'/'+rel.as_posix(),p))
  manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in files}
  previous=dest/'LATEST.json'
  if previous.exists():
   last=json.loads(previous.read_text());old=dest/last['snapshot']/'FILES.json'
   if old.exists() and json.loads(old.read_text())==manifest:return {'status':'UNCHANGED','snapshot':last['snapshot']}
  name=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
  stage=dest/('.staging-'+name);stage.mkdir()
  dump(stage/'FILES.json',manifest)
  archive=stage/'snapshot.zip'
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
   for n,p in files:
    z.write(p,n)
    if sha(p)!=manifest[n]['sha256']:raise RuntimeError('Fonte mudou durante cópia: '+n)
   z.write(stage/'FILES.json','FILES.json')
  with zipfile.ZipFile(archive) as z:
   bad=z.testzip()
   if bad:raise RuntimeError('CRC inválido: '+bad)
  parts=[]
  with archive.open('rb') as f:
   i=1
   while b:=f.read(30*1024*1024):
    part=stage/f'ASSIMILACAO_{name}.zip.part{i:03}'
    part.write_bytes(b);parts.append({'name':part.name,'bytes':len(b),'sha256':sha(part)});i+=1
  dump(stage/'INDEX.json',{'version':1,'snapshot':name,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_sha256':sha(archive),'files_manifest_sha256':sha(stage/'FILES.json'),'file_count':len(files),'parts':parts,'excluded_reconstructible':['.godot','__pycache__','node_modules','.pytest_cache']})
  # Partes e manifesto são a cópia portátil; arquivo integral permanece preservado.
  final=dest/name;stage.rename(final);stage=None
  dump(previous,{'snapshot':name})
  return {'status':'PASS','snapshot':name,'files':len(files),'parts':len(parts),'directory':str(final)}
 finally:
  lock.unlink(missing_ok=True)
  # Staging de falha é conservado para diagnóstico, nunca promovido a LATEST.
def restore(index,target):
 index=P(index).resolve();meta=json.loads(index.read_text(encoding='utf-8-sig'));target=P(target).resolve()
 if target.exists():raise ValueError('Destino de restauração deve ser novo: '+str(target))
 if sha(index.parent/'FILES.json')!=meta['files_manifest_sha256']:raise ValueError('Manifesto divergente')
 expected=json.loads((index.parent/'FILES.json').read_text(encoding='utf-8'))
 with tempfile.TemporaryDirectory(prefix='assim-restore-',dir=target.parent) as temp:
  archive=P(temp)/'joined.zip'
  with archive.open('wb') as out:
   for entry in meta['parts']:
    p=index.parent/entry['name']
    if p.name!=entry['name'] or p.stat().st_size!=entry['bytes'] or sha(p)!=entry['sha256']:raise ValueError('Parte inválida '+entry['name'])
    with p.open('rb') as f:shutil.copyfileobj(f,out)
  if sha(archive)!=meta['archive_sha256']:raise ValueError('ZIP reconstituído divergente')
  stage=P(temp)/'files';stage.mkdir()
  with zipfile.ZipFile(archive) as z:
   names=z.namelist()
   if len(names)!=len(set(names)) or set(names)!=set(expected)|{'FILES.json'}:raise ValueError('Inventário ZIP inesperado')
   for n in names:
    q=P(n)
    if q.is_absolute() or '..' in q.parts or ':' in n or '\\' in n:raise ValueError('Caminho inseguro')
   z.extractall(stage)
  for n,entry in expected.items():
   p=stage/n
   if p.stat().st_size!=entry['bytes'] or sha(p)!=entry['sha256']:raise ValueError('Arquivo restaurado divergente '+n)
  stage.rename(target)
 return {'status':'PASS','restored_files':len(expected),'target':str(target),'windows_verified':os.name=='nt'}
if __name__=='__main__':
 ap=argparse.ArgumentParser();sp=ap.add_subparsers(dest='command',required=True)
 b=sp.add_parser('backup');b.add_argument('--roots',required=True);b.add_argument('--dest',required=True)
 r=sp.add_parser('restore');r.add_argument('--index',required=True);r.add_argument('--target',required=True)
 args=ap.parse_args()
 result=backup(json.loads(P(args.roots).read_text(encoding='utf-8-sig')),args.dest) if args.command=='backup' else restore(args.index,args.target)
 print(json.dumps(result,ensure_ascii=False))
