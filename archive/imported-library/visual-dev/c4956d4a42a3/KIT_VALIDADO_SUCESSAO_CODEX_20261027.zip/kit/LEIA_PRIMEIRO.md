# Sucessão Cloud → Windows — Assimilação, 27/10/2026

**Estado: preservação Cloud; migração Windows HOLD.** Este kit continua a conversa “Criar documentos do novo projeto RPG ART”. Nada aqui afirma que o notebook foi alterado.

## LAST-VERIFIED

- Projeto real `/workspace/assimilacao-combate`; protótipo funcional em `battle/index.html`, instruções `battle/README.md`, ZIP anterior `ASSIMILACAO_PROTOTIPO_BATALHA_v001.zip` de 59.103.909 bytes. Docs/contexto/manual/regras e todas as fontes continuam no snapshot.
- Logs da execução de 27/10 em `vertical_slice_v002/reports/`: 25/25 testes motor e 28 controles Chromium. Estes são recibos daquela execução, não nova certificação Windows. Os 1.877 arquivos do baseline foram comparados novamente nesta preservação: nenhuma divergência.
- Rig `vertical_slice_v002/blender/modular_humanoid.blend` e `.glb`: um esqueleto real de 22 ossos, dois corpos, equipamentos separados, nove animações. Recibo salvo tem 69 controles; hashes dos três artefatos conferidos novamente e coincidem. Isso não certifica qualidade artística final ou retargeting de ossaturas distintas.
- Godot `vertical_slice_v002/godot`: projeto, GLB, modular_actor.gd, head_attention.gd e inspector salvos. Cena referencia `scripts/forest.gd`, que NÃO existe. `web/` vazia: floresta/build web INCOMPLETOS. Não apresentar o projeto como nova versão jogável.
- Quatro ZIPs de transporte recebidos e extraídos em `reference_audit/acervo`; auditoria interrompida, scripts/métricas intermediários preservados. Não repetir censo Claude nem assumir auditoria integral concluída. Besta Cristalina serpentina é diferente do Espectro humanoide do primeiro protótipo.
- Legado local consultado: branch work, commit 046f6cc3d67ab6f8ae9a5c6eda6eaf03cd8d2267, sem diffs staged/unstaged. Projeto novo não possui repositório Git próprio; fontes são preservadas por manifesto, não por commit fictício.

## FIRST-PENDING

Restaurar o snapshot em área isolada no Windows, verificar hashes e executar teste representativo. Ler primeiro `Claude-Assimilacao/2026-10-27_onboarding/` existente; o conteúdo físico dessa pasta e o derivado alpha do Capríleo não estão acessíveis na Cloud.

## NEXT

1. Baixar este kit, INDEX.json, FILES.json e todas as partes listadas no índice para a mesma pasta.
2. Confirmar fisicamente `C:\Users\Antônio Tiburtino\OneDrive\Área de Trabalho\RPG Assimilação` no computador DESKTOP-P43I7M4. Não criar um caminho alternativo presumido.
3. Com Python disponível, criar apenas o PAI do destino e executar `python checkpoint.py restore --index "CAMINHO\INDEX.json" --target "CAMINHO\RESTORE_CLOUD_NOVO"`. O destino deve ser inexistente. Todos os hashes são verificados antes de promover a restauração.
4. Na pasta restaurada `assimilacao-combate`, executar `node --test battle/engine.test.cjs` e servir `python -m http.server 8765 --bind 127.0.0.1`; abrir http://127.0.0.1:8765/battle/. Usar perfil de navegador de teste para preservar saves pessoais.
5. Registrar ao menos um hash Windows e o teste executado. Só então comparar com produção e decidir integração; preservar ambas as versões em conflito.
6. Instalar backup pelo script abaixo, validar tarefa/logs e restaurar amostra no Windows. Retomar integração Godot do GLB, corrigindo a cena incompleta sem reconstruir a batalha anterior.

## NO-REPEAT

Não recriar o VLAB, não promover fixtures a cânone, não repetir microtestes de instalação ou os 61 hashes/38 dimensões já auditados por Claude sem nova causa. Não mover instalações, não sobrescrever produção, não baixar/publicar os 12 ZIPs VLAB de novo. Não copiar ao público este snapshot MESTRE-SIDE. Código publicável deve ser selecionado/revisado separadamente.

## Ferramentas e dependências

Cloud observada: Linux, Blender4.3.2, Godot4.6.3, Node24.19.0 e Chromium154. Relatos de Blender5.2.3/Godot4.7.2 no Windows são históricos até comando local. Backup/restore usa Python3 padrão. Scripts de render usam Blender/Pillow; QA browser usa Playwright/Chromium. Templates Godot4.6.3 foram instalados na Cloud (relatório `godot_templates_install.json`); redistribuição do instalador de1,2GB é desnecessária e não está no snapshot. Reobter versão compatível no Windows se necessário.

## Estrutura local, sem movimentos cegos

Usar o censo Claude antes de enumerar de novo. Criar/reutilizar índices `00_CENTRAL`, `03_CODEX`, `05_TESTES`, `06_ENTREGAS`, `07_BACKUPS`, `08_DIARIOS`, `09_REFERENCIAS`. Apontar `01_JOGO_INTERATIVO_2_5D` ao ÚNICO projeto integrado escolhido após comparação; não copiar fontes como várias produções. Manter mesa em `02_RPG_DE_MESA_NARRACAO`. Reutilizar `Claude-Assimilacao`; não criar04_CLAUDE duplicado. Primeiro escrever tabela ANTES→DEPOIS/índice; conservar arquivos nas posições atuais quando mover quebraria dependências. Nenhuma organização Windows foi executada aqui.

## Backup independente da IA

`checkpoint.py backup --roots roots.json --dest DIRETORIO_BACKUPS` cria versões imutáveis, manifesto SHA256, ZIP completo e partes30MiB. Exclui apenas caches reconstruíveis; não apaga históricos. Evita recursão do destino e bloqueia execução concorrente. Fonte alterada durante cópia provoca falha e não promove LATEST; staging conservado para diagnóstico. Após queda que deixe `.checkpoint.lock`, conferir que não há processo ativo antes de remover esse único lock. Arquivos abertos podem exigir pausar gravação dos aplicativos durante o checkpoint.

No Windows: `powershell -NoProfile -File .\Instalar-Backup.ps1 -ProjectRoot "PROJETO_REAL" -BackupRoot "PASTA_FORA_DO_PROJETO" -Python python`. O instalador realiza backup e restore verificado antes de registrar tarefa a cada30min. Requer Python e permissões do Agendador; **script preparado, não executado no Windows**. Tarefa existente não é sobrescrita. No Agendador conferir usuário/privilégios e disponibilidade quando fora da sessão; nenhuma senha é coletada pelo script. Teste efetivo em Cloud é registrado separadamente; não substitui restore Windows.

Drive externo: upload e verificação desta entrega conforme recibo externo, quando disponível. O parâmetro DriveMirror não instala sincronização; integração automática local depende do Google Drive Desktop real ou conector autorizado. OneDrive NÃO é Google Drive. Backup local agendado funciona sem IA/cota, mas não foi instalado nesta Cloud nem no Windows. Sem observação de saldo:30%/15%/5% são alertas manuais oportunísticos; agenda e marcos independem deles.

## Cooperação

Codex: próprio kit/snapshot e integração experimental Godot. Claude CM-000008-I0001: área Claude existente, QA de arte/derivado, documentação. CM-000006: VLAB. Nenhum writer/lease/epoch herdado; antes de editar produção registrar arquivo, autor responsável, hash inicial e escopo. Em conflito preservar duas versões e produzir diff. Diário local é índice de evidências, não norma canônica nova. Quadro e Área Codex apontam ao checkpoint, sem alterar Diário alheio.

## Cobertura da preservação

Snapshot inclui projeto inteiro (frames avulsos inclusive), documentos, fontes Blender/Godot, logs, referências extraídas, uploads recebidos em attachments, repositório legado com `.git` e kit. Não inclui credenciais, pastas privadas de configuração, ferramentas instaladas ou caches reconstruíveis. Não é possível exportar por ferramenta o histórico textual integral desta conversa; decisões, ordens disponíveis, relatórios e prompt de retomada são preservados. Não declarar transcript completo. ZIP unificado inicial >32MiB nunca materializado; suas quatro partes recebidas estão preservadas.
