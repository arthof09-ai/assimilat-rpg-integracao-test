extends SceneTree
var skeletons: Array[Skeleton3D] = []
var players: Array[AnimationPlayer] = []
var meshes: Array[MeshInstance3D] = []
func _initialize() -> void:
	call_deferred("inspect")
func scan(n: Node) -> void:
	if n is Skeleton3D: skeletons.append(n)
	if n is AnimationPlayer: players.append(n)
	if n is MeshInstance3D: meshes.append(n)
	for c in n.get_children(): scan(c)
func inspect() -> void:
	var packed = load("res://assets/modular_humanoid.glb") as PackedScene
	if packed == null:
		push_error("GLB ausente"); quit(1); return
	var model = packed.instantiate()
	root.add_child(model)
	scan(model)
	var checks: Dictionary = {}
	checks["one_skeleton"] = skeletons.size() == 1
	checks["one_animation_player"] = players.size() == 1
	if skeletons.size() != 1 or players.size() != 1:
		print(JSON.stringify(checks)); quit(1); return
	checks["bones22"] = skeletons[0].get_bone_count() == 22
	var animations = players[0].get_animation_list()
	for clip in ["idle", "walk", "run", "attack", "guard", "hit", "cast", "fall", "rise"]:
		checks["clip_" + clip] = animations.has(clip)
	var variants = {"Body_Mannequin": false, "Body_Orc": false}
	for mesh in meshes:
		if variants.has(str(mesh.name)):
			variants[str(mesh.name)] = true
			mesh.visible = false
			checks["hide_" + str(mesh.name)] = not mesh.visible
			mesh.visible = true
			checks["show_" + str(mesh.name)] = mesh.visible
	checks["two_bodies"] = variants.values().all(func(v): return v)
	players[0].play("walk"); players[0].advance(0.25)
	checks["walk_advances"] = players[0].current_animation_position > 0.0
	var ok = checks.values().all(func(v): return v)
	print("ASSIM_IMPORT_QA " + JSON.stringify({"status": "PASS" if ok else "FAIL", "checks": checks, "animations": animations, "meshes": meshes.size(), "bone_count": skeletons[0].get_bone_count(), "engine": Engine.get_version_info().string, "render_validation": false}))
	model.queue_free()
	quit(0 if ok else 1)
