Here is the result of "fetch" for the Page with URL https://app.notion.com/p/406c2b324ede81cca425d651d55b9b40 as of 2026-10-27T17:55:09.064Z:
<page url="https://app.notion.com/p/406c2b324ede81cca425d651d55b9b40" icon="⚔️">
<ancestor-path>
<parent-page url="https://app.notion.com/p/406c2b324ede81548b70e872c64d29a0" title="Portal do Jogo Interativo 2.5D — Coordenação Codex / Claude / Inovador (TEST)"/>
<ancestor-2-page url="https://app.notion.com/p/3fbc2b324ede80589434f8a5619fa7e5" title="Laboratórios das Operações "/>
<ancestor-3-page url="https://app.notion.com/p/181c2b324ede82278778012fb533228f" title="RPG"/>
</ancestor-path>
<properties>
{"title":"PROMPT CODEX — Retomada Cloud → Windows, Backup, Sucessão e Cooperação CM-000008 (v2.0, 27/10/2026)"}
</properties>
<iconMetadata>{"type":"emoji","emoji":"⚔️"}</iconMetadata>
<content>
<callout icon="🎮" color="blue_bg">
<b>ORDEM DO MESTRE — CODEX CLOUD / RETOMADA v2.0 / 27-10-2026.</b> Este é o prompt de sucessão que substitui operacionalmente o arquivo de prompt v001, sem apagá-lo nem abandonar a missão atual "Criar documentos do novo projeto RPG ART". <b>O Mestre ordenou pausa mínima para preservação integral, organização local e backup; depois continuar a desenvolver o mesmo jogo</b>. Documento preparado pela coordenação; execução pelo Codex apenas após o Mestre entregar o prompt. Não declarar artefatos físicos transferidos sem readback.
</callout>

# ORDEM EXECUTIVA — RETOMADA CODEX CLOUD → WINDOWS, BACKUPS, SUCESSÃO E JOGO 2.5D

<b>Destinatário:</b> Codex na mesma conversa <b>Cloud</b> "Criar documentos do novo projeto RPG ART". <b>Objetivo final:</b> desenvolver o mesmo RPG Assimilação 2.5D, sem reconstrução, perda de trabalho ou dependência de um único chat. <b>Prioridade imediata:</b> pausa controlada e curta somente para PRESERVAR TUDO O QUE ESTA CONVERSA JÁ FEZ e criar passagem confiável para um próximo chat <b>LOCAL</b> no notebook Windows. Só então retomar a implementação de onde parou.

<b>AUTORIZAÇÃO DO MESTRE:</b> inventariar, organizar e proteger reversivelmente os arquivos da missão e da pasta local \`RPG Assimilação\`, desde que respeite o cânone, backups, revisão dos objetos existentes e direitos operacionais. Não há autorização para eliminar originais, sobrescrever trabalho alheio, iniciar motor mecânico paralelo ou declarar concluído sem provas. Custo adicional: R\$ 0.

## 1. Identidade e coordenação: NOTÍCIA IMPORTANTE

O Claude da Anthropic não é mais "estagiário": foi instituído <b>CM-000008 — Comestre Coordenador Claude 1</b>, com <b>autoridade funcional de coordenação paritária ao Comestre ChatGPT</b>, ambos subordinados ao Mestre, sem hierarquia entre esses dois coordenadores. Primeira instância real <b>CM-000008-I0001</b> registrada no Notion, já leu onboarding e gravou Diário. <b>Codex é executor técnico; coopera profissionalmente com esses coordenadores e com o Inovador, mas não se atribui COMESTRE-ID ou writer/lease/epoch automático.</b> O Comestre VLAB CM-000006 conserva atribuições de sua operação.

Fontes:

- <mention url="https://app.notion.com/p/406c2b324ede81548b70e872c64d29a0">Portal do Jogo Interativo 2.5D — Coordenação Codex / Claude / Inovador (TEST)</mention>
- <mention url="https://app.notion.com/p/406c2b324ede81bea8cbd7368542908c" />
- <mention url="https://app.notion.com/p/406c2b324ede81459c57f4cef02620b1" />
- <mention url="https://app.notion.com/p/406c2b324ede815cbbeafce36491d5c8" />
- <mention url="https://app.notion.com/p/406c2b324ede81f6ade4e954137701af" />
- <mention url="https://app.notion.com/p/406c2b324ede81728b82edc135f424ce" />
- <mention url="https://app.notion.com/p/401c2b324ede809585d3d1907c194df9" />
- [Protocolo ponte no GitHub](https://github.com/arthof09-ai/assimilat-rpg-integracao-test/blob/main/docs/ai/COORDENACAO_CLAUDE_CHATGPT_2026-10-27.md)

Antes de qualquer edição Notion/VLAB compartilhada, ler as normas existentes BOOTSTRAP-COMESTRE, NAC-CONT-03, NAC-NORM-01, NAC-PASS-02, COMM-BILAT-01, REG-ROUTE-03, Diário Operacional e direitos atuais. Pedido→aceite→execução→readback/recibo onde aplicável. Nunca deduzir "posso escrever" apenas de ter acesso técnico. Evitar criar diários, inbox, motores ou páginas canônicas duplicadas. Party e O Primeiro NO-WRITE.

## 2. PRIMEIRO: congelar a missão apenas o suficiente para criar um checkpoint REAL

Antes de novos recursos, GUI, modelagens ou refatoração:

1. Abrir o estado real desta conversa Cloud: \`/workspace\` ou caminho efetivamente existente, branch/commit, \`git status\`, diffs não commitados, arquivos alterados/gerados, builds, assets, scripts, cenas, testes, resultados dos agentes auxiliares e diretórios de projeto.
2. Preservar resultados de <b>TODAS</b> as atividades já realizadas neste chat: documentação, pesquisa, decisões, implementação, scripts, HTML/browser, Godot, Blender, rigs, animações, arquivos de origem, protótipo, testes, logs, TODOs e caches que sejam indispensáveis. Não limitar o backup aos quatro ZIPs de imagens. O protótipo relatado de <b>\~59 MB</b> (andar, atacar, defender, Vida, Alma, salvar/carregar) é prioridade alta.
3. Confrontar alegações antigas de <b>25 testes de motor + 28 verificações de interface</b>, <b>1.877 arquivos preexistentes intactos</b>, e tarefas Governança v002, Assets audit v002, Baseline qa v002, Rig finish v002 e Godot finish v002 com o disco e o estado real. São informações anteriores, NÃO resultados atuais automaticamente PASS. Não repetir testes caros sem necessidade; conferir saídas existentes e repetir apenas amostras/contratos necessários.
4. Criar <b>snapshot ORIGINAL imutável</b> com manifesto de arquivos/versões/SHAs, branch + commit + arquivos não commitados, estado de execução, comparação ANTES→DEPOIS e instruções de recuperação. Nomear arquivos por missão/data/versão sem inventar "v003" se já existir.
5. Respeitar limite de upload observado (houve falha no ZIP \~92 MB por 32 MiB): dividir em partes verificáveis apenas se necessário, com índice de partes, hash total e individual e instruções de restauração. Testar extração/reconstituição. Não apagar a única cópia Cloud.

<b>Critério para avançar:</b> um executor independente consegue encontrar os bytes REAIS, reconstituir o diretório e identificar o FIRST-PENDING sem depender do histórico desta conversa. Se não conseguir transferir, declare HOLD preciso, mantenha arquivos onde estão e apresente meio operacional viável que não exija custo.

## 3. SEGUNDO: migrar o mesmo trabalho Cloud para um chat LOCAL no notebook

<b>Ambientes diferentes:</b> esta conversa Codex Cloud NÃO possui, por definição, os programas e arquivos do Windows \`DESKTOP-P43I7M4\`; notebook ligado NÃO provoca migração automática. Não afirmar Windows verificado apenas por login remoto.

Destino pretendido: \`C:\\Users\\Antônio Tiburtino\\OneDrive\\Área de Trabalho\\RPG Assimilação\` — confirmar caminho físico antes de atuar. O Mestre quer continuar pelo celular com computador ligado, mas o processo local deve estar efetivamente vinculado ao notebook.

Ordem:

1. Exportar/commit/empacotar checkpoint da Cloud por meio real (artefato, GitHub, Drive ou outro caminho já conectado), sem substituir a versão corrente do Windows.
2. Criar pacote de HANDOFF legível por sessão LOCAL: resumo da missão, artefatos e hashes, arquivos necessários, ferramentas, testes, pendências, links e prompt de retomada; documentar para que outro chat possa executar sem recomeçar.
3. Na sessão Codex LOCAL ou executor local com autorização e acesso confirmado, comparar snapshot com arquivos existentes; restaurar inicialmente em <b>diretório isolado</b>, revalidar SHA, abrir protótipo e testar antes de integrar à pasta de produção.
4. Se ainda não tiver acesso local, concluir tudo que for possível na Cloud e escrever o menor próximo passo para o Mestre. <b>Não declarar transferência concluída sem arquivo reaberto no Windows</b>.
5. Depois do handoff/restauração, iniciar o <b>próximo chat LOCAL</b> para continuar a mesma missão. Não deixar o chat Cloud executando independentemente em cima dos mesmos arquivos quando o local assumir.

## 4. TERCEIRO: ORGANIZAR A PASTA DESKTOP PARA CODEX + CLAUDE (sem apagar histórico)

A pasta raiz <b>RPG Assimilação</b> pertence ao Mestre e servirá tanto ao Codex quanto ao Claude Code. O Claude já fez censo recente da área e criou \`Claude-Assimilacao\\2026-10-27\_onboarding\`; LEIA o Diário antes de refazer o trabalho. Primeiro inventário diferencial, evitando novo censo integral.

<b>Estrutura lógica-alvo, reaproveitando diretórios equivalentes em vez de duplicá-los:</b>

- \`00\_CENTRAL\`: START\_HERE, estado atual do jogo, índice único, manifestos, último snapshot testado, handoffs.
- \`01\_JOGO\_INTERATIVO\_2\_5D\`: uma versão integrada do jogo, Godot, Blender, assets-fonte, HTML/browser quando cabível.
- \`02\_RPG\_DE\_MESA\_NARRACAO\`: campanha, sessões, mapas e materiais da narração do Mestre; não misturar com código, não apagar.
- \`03\_CODEX\`: experimentos e arquivos de trabalho isolados do Codex, sem criar segunda fonte de produção.
- \`04\_CLAUDE\` ou <b>REUTILIZAR \`Claude-Assimilacao\` EXISTENTE</b>: análises, patches e testes do Claude; não mover ou duplicar cegamente.
- \`05\_TESTES\`: execuções e fixtures reproduzíveis, ambiente TEST, relatórios.
- \`06\_ENTREGAS\`: versões aceitas, exportações, builds.
- \`07\_BACKUPS\`: snapshots e manifests, versionados, sem misturar com originais.
- \`08\_DIARIOS\`: diário Codex, diário Claude e índice compartilhado apontando a Diário Operacional/Notion; não fazer diários canônicos paralelos.
- \`09\_REFERENCIAS\`: pranchas, prompts, guias, pesquisas e links.

<b>Obrigatório:</b> enumerar BEFORE→AFTER, registrar mapa da árvore anterior para a nova, preservar IDs, nomes de originais, dependências e caminhos do Godot; identificar links quebrados antes de qualquer mudança. Pastas do OneDrive não são pastas Google Drive. Nunca mover a instalação do Blender/Godot, nunca deletar/limpar em massa. Quando for arriscado mover, manter a pasta antiga e criar índices/atalhos; organizar incrementalmente. <b>Nenhuma IA modifica ao mesmo tempo os mesmos arquivos de produção; branches/worktrees e integração revisada.</b>

## 5. QUARTO: BACKUP LOCAL AUTOMÁTICO E DRIVE INDEPENDENTE DA COTA

<b>Não depender do token/saldo do Codex.</b> Criar mecanismo gratuito e verificável no Windows (PowerShell + Agendador de Tarefas, se autorizado e disponível, ou equivalente) que salve por intervalo e por marcos, mesmo sem IA ativa. Manter versões e backups históricos necessários, logs de sucesso/falha, manifestos/SHAs, exclusão somente de caches reconstruíveis comprovados e proteção contra sobrescrita. Evitar recursão \`backup/backup\`, explosão de gigabytes, arquivos em uso/cópias inconsistentes e loops de OneDrive.

<b>Preferência do Mestre:</b> quando restarem cerca de <b>30%, 15% e 5%</b> da cota visível de 5 horas, antecipar checkpoint e preparar sucessão. Não alegar que existe API de saldo ou gatilho percentual automático; se saldo não for observável, usar marcos de trabalho + agenda/alterações para proteção contínua.

<b>Drive como backup externo oficial:</b> [RPG ASSIMILAÇÃO](https://drive.google.com/drive/folders/1RPl9yOjGrhO73vfRU0jmmGHZkvkKHG1B), [JOGO\_INTERATIVO](https://drive.google.com/drive/folders/10wp-f3QNv0pHmjzJ28eqZU4c444dav4u), [RPG\_DE\_MESA](https://drive.google.com/drive/folders/13pRBEakmlTDikJHMe7a8ERFBKho1oCIo). O Drive já tem [12 backups do Código-Mãe VLAB R315–R326](https://drive.google.com/drive/folders/1dV_oQjtRVHRp0KA3FSJX5Wt1EqPrVW_3), não duplicar. Identificar pasta e nome+versão+SHA antes do upload. Verificar subida por listagem, <b>re-download/bytes</b> e hash; se indisponível, registrar o nível de prova. Arquivos grandes vão ao Drive, não forçar upload >5 MB no Notion.

<b>Teste de restauração obrigatório:</b> recuperar ao menos um snapshot representativo em diretório isolado no Windows e verificar arquivos/abertura/teste; demonstrar que Codex OU Claude pode continuar após limite de uso. Não certificar BACKUP-PASS só com criação de pasta ou comando agendado.

## 6. GitHub e Notion: fontes complementares, sem falsos recibos

<b>GitHub:</b> [assimilat-rpg-integracao-test](https://github.com/arthof09-ai/assimilat-rpg-integracao-test), público por decisão do Mestre. Antes de push/PR verificar branch HEAD, \`git status\`, remotes, diffs, worktrees, commits e autoria; preservar trabalho alheio, commits pequenos/testados, não fazer force push, \`reset --hard\` ou mescla destrutiva. Priorizar fonte de código, scripts, Godot/HTML, testes e README; grandes arquivos ZIP/.sqlite/.blend preferencialmente no Drive, conforme tamanho/revisão real e sem gastos adicionais. <b>É permitido desenvolver e publicar código de jogo no GitHub público; respeitar fronteira narrativa Mestre→Party, sem tratar todo código como segredo nem publicar conteúdo da Party por acidente.</b> Não inventar CI-PASS sem job efetivamente rodado.

<b>Notion:</b> é a referência persistente de normas e organização de operações; não é depósito obrigatório de mídia grande. Portal e Quadro apontam aos laboratórios. Atualizar seu checkpoint na <b>Área Codex</b> e o Diário da OP competente, depois reabrir para readback, deixando RUN/versão/hash/diff/resultado/bloqueio/quem assume. Não copiar logs em fichas de personagens. Seguir NAC-CONT-03, NAC-NORM-01, NAC-PASS-02 e COMM-BILAT-01 conforme necessidade. Não criar um segundo centro normativo.

## 7. Handoff específico com CLAUDE — já há trabalho útil, NÃO REPETIR

Claude CM-000008-I0001 informou acesso PASS a Notion, Drive e GitHub; Windows PARCIAL por falta de terminal. Registrou <b>61/61 SHA e 38/38 dimensões</b> do acervo Orc/Capríleo/Besta Cristalina, relatou 55/55 testes de oito arquivos GitHub em sua nuvem e identificou que os quatro \`CODEX\_DOWNLOAD\_NOVO\` são as partes de transporte do MESMO acervo, não novos assets. <b>Tais PASS são relato registrado de Claude, não testes executados por este Codex.</b>

Encontrou <b>alfa residual 1–10 em \~41% da imagem de caminhada lateral do Capríleo</b>, criou derivado TEST com transparência limpa sem tocar o original. Local: \`RPG Assimilação\\Claude-Assimilacao\\2026-10-27\_onboarding\`. Faça QA pontual da equivalência de pixels, dimensão, recorte e adequação para sprites/Godot; não promover automaticamente o derivado à produção. A ponte de transferência de PNG pode recodificar os bytes preservando os pixels; distinguir SHA binário de equivalência de pixels. No Diário Claude constam detalhes e NEXT.

<b>Divisão recomendada:</b> Codex cuida de preservar/restaurar seu próprio protótipo Cloud, projeto de jogo, versões e testes; Claude trabalha em arte/QA, documentação e scripts em espaço separado quando sua cota permitir; Comestre ChatGPT/Inovador reconciliam direção técnica/cânone; CM-000006 VLAB mantém seu contrato mecânico. A coordenação é <b>paritária entre Claude e ChatGPT</b>, sem excluir Codex das decisões técnicas de sua implementação. Antes de escolher quem altera um arquivo, validar escopo/reserva e troca de checkpoint.

## 8. A missão original de DESENVOLVIMENTO DO JOGO continua depois da pausa

Assim que houver snapshot/restauração e sistema de backups minimamente testado, retomar desenvolvimento — não ficar indefinidamente organizando pastas. O projeto HTML/browser e seus testes existentes devem ser preservados; comparar migração incremental para Godot isolado, sem substituir o que já funciona. Protótipo deve demonstrar andar, atacar, defender, consumir Vida/Alma, salvar/carregar; depois expandir combates, animações e exportação web segundo prioridades verificadas da missão original.

<b>Direção artística expressa:</b> referência de fluidez/impacto Hades 1 (método 3D→quadros 2D útil quando apropriado), magia corporal marcial Avatar, legibilidade BG3/LoL; não copiar conteúdo protegido. Orc como humanoide modular com grande machado reto e em escala; rigs para bestas (Capríleo, Besta Cristalina) próprios; preservar dimensões e silhuetas, espaço nas pranchas e arma proporcional. Animação frame a frame é VISUAL, não gera múltiplos ataques mecânicos. Testar sprites, transparência, pivôs, 8 direções e sequências reais em vez de inventar novas imagens sem necessidade.

<b>Hitbox/footprint:</b> criatura pode ser maior que um humanoide; distinguir sprite visual, footprint de células (inclusive 1×6, T, L) e área atingível. Não miniaturizar bestas para caber em 1 tile; cauda, arma, VFX não são footprint automático; uma criatura em vários tiles NÃO recebe dano por tile sem regra. Conferir tile real, rotação, colisão, alcance, LoS, replay e hitboxes com o contrato vigente.

<b>VLAB:</b> motor mecânico oficial ÚNICO. O Drive contém R315–R326, R325 manifesto interno 98/98 e R326 ZIP externo idêntico ao da Biblioteca, mas manifesto interno <b>95/98</b>, três divergências (\`README\_MESTRE\_[ONLY.md](http://ONLY.md)\`, \`index.html\`, \`manifest.json\`); terminal VLAB <b>HOLD, 0/17</b>. Contrato R326 \`TURN\_SCHEDULER\_EVENT\_SOURCING\` é área do Comestre VLAB, não sua autorização para reimplementar combate. R50/R51 decisões do Mestre sobre contra-atacar prevalecem sobre resumos Claude R205. No protótipo use fixtures TEST rotuladas quando adaptador real ainda não foi autorizado.

## 9. Gates, trabalho contínuo e produto final

<b>Sequência não negociável:</b> (A) recuperar o estado real da Cloud, (B) checkpoint completo e pacote restaurável, (C) disponibilizar para o Windows com bytes verificados ou fornecer caminho mais curto em HOLD, (D) organizar e testar backup local quando houver acesso real, (E) retomar jogo original. Se etapa C exige mudar de conversa/ambiente, conclua TUDO de A/B e entregue comando de handoff pronto. Não mentir dizendo ter transferido arquivos. Se uma atividade estiver fora da capacidade de sua sessão Cloud, prossiga nas outras atividades seguras do mesmo escopo.

<b>Trabalhe com autonomia técnica, sem pedir autorização redundante para tarefas reversíveis</b>, e aplique o núcleo LONG-RUN-01 §15.2 já previsto na governança: autoplanear→autoauditar→executar→readback→próxima pendência, sem ficar ocioso, repetir tarefas ou inventar passagem de tempo. A parada é somente por missão cumprida, necessidade de decisão Mestre/autoridade, STOP/HOLD/RED, falta real de acesso/cota ou segurança. O checkpoint por si NÃO significa que pode abandonar o jogo.

<b>PSV final de cada ambiente/rodada:</b>

- RUN e ambiente, LAST-VERIFIED (arquivos reais + hashes/commits e readback), resultados de testes (com denominador), arquivo/branch criados, upload Drive e GitHub comprovados, estado do backup e RESTORE TEST;
- FIRST-PENDING, NEXT e NO-REPEAT; conflitos de writer, decisões Mestre eventualmente necessárias, estados VERIFICADO/RELATADO/INFERIDO/PROPOSTO/PENDENTE/HOLD;
- <b>PROMPT DE SUCESSÃO PARA O PRÓXIMO CHAT LOCAL</b> completo, minimalista e executável, com a pasta e o ZIP/commit/snapshot corretos. Este é um produto OBRIGATÓRIO desta rodada;
- Entrega de jogo funcional somente se REALMENTE testado, sem confundir testes do ambiente Cloud com testes feitos no Windows.

<b>Não reiniciar, não abandonar, não perder o trabalho. Pausa curta para a continuidade; depois progresso material do jogo.</b>

## FIM DO PROMPT INTEGRAL

### Rastreabilidade pré-envio

- Base: \`PROMPT\_CODEX\_RETOMADA\_APOS\_LIMITE\_[v001.md](http://v001.md)\` da Biblioteca privada + \`CP-INOV-CODEX-LIMITE-20261027-001\` no Inovador.
- Novo: \`PROMPT-CODEX-RETOMADA-CLOUD-LOCAL-SUCESSAO-CM8-20261027-v2.0\`.
- Status agora: DOCUMENTO PREPARADO PARA O MESTRE ENVIAR; Codex não deu ACK, não executou migração e nenhum backup Windows novo foi declarado.
- Tarefa original Cloud: "Criar documentos do novo projeto RPG ART" (mesma conversa).
</content>
</page>
