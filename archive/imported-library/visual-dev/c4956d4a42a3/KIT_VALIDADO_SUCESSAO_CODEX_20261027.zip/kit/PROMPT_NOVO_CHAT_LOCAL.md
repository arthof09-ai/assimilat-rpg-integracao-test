# Prompt para colar no novo chat LOCAL

Continue a MESMA missão RPG Assimilação 2.5D da conversa “Criar documentos do novo projeto RPG ART”. Ordem Mestre27/10/2026: https://app.notion.com/p/406c2b324ede81cca425d651d55b9b40. Não recomece nem recrie o motor VLAB.

Primeiro confirme que esta sessão tem terminal Windows no DESKTOP-P43I7M4. Use Test-Path -LiteralPath 'C:\Users\Antônio Tiburtino\OneDrive\Área de Trabalho\RPG Assimilação'. Leia o censo já existente Claude-Assimilacao\2026-10-27_onboarding e o kit LEIA_PRIMEIRO.md, ESTADO_REAL.json, INDEX.json e recibos. Não repetir censo ou supor transferência automática por trocar de chat.

Baixe as partes e o kit pelo índice de sucessão entregue pelo Codex Cloud. Restaure com checkpoint.py em diretório NOVO isolado usando INDEX.json. Confira hashes, registre caminho Windows real e rode Node battle/engine.test.cjs e smoke browser do diretório assimilacao-combate restaurado. Confirme um arquivo por SHA e execução antes de declarar migração concluída. Não sobrescreva produção/saves. Se houver conflito preserve duas versões e diffs.

LAST-VERIFIED Cloud: projeto antigo preservado1877/1877, logs25 testes motor e28 controles UI da execução27/10; rig real22ossos/2corpos/9clips com fonteBlend/GLB e relatório69controles. FIRST-PENDING jogo: projeto Godot parcial referencia forest.gd AUSENTE, web vazia; continuar integração/arena, não alegar floresta pronta. Equipamentos modular_actor.gd e biblioteca GLB já existem. Não redesenhar sem comparar. VLAB terminalHOLD0/17; somente fixturesTEST até contrato autorizado.

Após restore, reaproveite estrutura local sem mover dependências cegamente. Instale/teste backup periódico com Instalar-Backup.ps1 em destino fora do projeto, valide tarefa e restauração; logue versão/caminhos/resultado. SincronizaçãoDrive deve ser comprovada separadamente. Quota30/15/5 só se observável; agenda funciona sem isso.

Coopere com Claude CM-000008 (Diário https://app.notion.com/p/406c2b324ede81f6ade4e954137701af), sem herdar writer/lease. Faça QA pontual do derivado alpha Capríleo existente na áreaClaude; compare pixelsRGBA e SHA binário separadamente, não repetir61/61 ou promover automaticamente.

Continue o jogo: validar GLB/Skeleton/AnimationPlayer, terminar floresta2.5D câmera35°, modularidade e equipamentos, estilos/continuidade de movimento, exportWebCompatibility/GDScript e smoke Chromium. Preservar HTML funcional como baseline. Consultar contrato footprint irregular e anatomias próprias (Besta serpentina, Capríleo quadrúpede). Registrar LAST-VERIFIED/FIRST-PENDING/NEXT/NO-REPEAT e evidências no Quadro/ÁreaCodex, sem Party, sem norma nova e sem proclamar engenhariaVLAB homologada.
