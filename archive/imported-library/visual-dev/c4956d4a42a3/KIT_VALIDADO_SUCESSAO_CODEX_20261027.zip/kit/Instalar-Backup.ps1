param([Parameter(Mandatory=$true)][string]$ProjectRoot,[Parameter(Mandatory=$true)][string]$BackupRoot,[string]$Python='python',[string]$DriveMirror='')
$ErrorActionPreference='Stop'
$ProjectRoot=(Resolve-Path -LiteralPath $ProjectRoot).Path
$backupFull=[IO.Path]::GetFullPath($BackupRoot)
if ($backupFull.StartsWith($ProjectRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Use destino de backup fora do projeto para evitar recursão.' }
New-Item -ItemType Directory -Path $backupFull -Force | Out-Null
if ((Test-Path -LiteralPath (Join-Path $backupFull 'roots.json')) -or (Test-Path -LiteralPath (Join-Path $backupFull 'Backup-Agora.ps1'))) { throw 'Configuração de backup já existe; consultar e reconciliar sem sobrescrever.' }
# Usar instalação persistente do kit; não aponta à pasta temporária de download.
$tool=Join-Path $backupFull 'checkpoint.py'
if(Test-Path -LiteralPath $tool){if((Get-FileHash $tool).Hash -ne (Get-FileHash (Join-Path $PSScriptRoot 'checkpoint.py')).Hash){throw 'Ferramenta já existe com conteúdo diferente; preservar e reconciliar.'}}else{Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'checkpoint.py') -Destination $tool}
$config=Join-Path $backupFull 'roots.json'
@{projeto=$ProjectRoot}|ConvertTo-Json|Set-Content -LiteralPath $config -Encoding UTF8
$runner=Join-Path $backupFull 'Backup-Agora.ps1'
$body=@'
param([string]$Python='python')
$ErrorActionPreference='Stop'
$log=Join-Path $PSScriptRoot ('backup-'+(Get-Date -Format 'yyyyMMdd')+'.log')
& $Python (Join-Path $PSScriptRoot 'checkpoint.py') backup --roots (Join-Path $PSScriptRoot 'roots.json') --dest (Join-Path $PSScriptRoot 'snapshots') 2>&1 | Tee-Object -FilePath $log -Append
if($LASTEXITCODE -ne 0){throw 'Backup falhou; consulte log.'}
'@
$body|Set-Content -LiteralPath $runner -Encoding UTF8
$py=(Get-Command $Python -ErrorAction Stop).Source
& $py $tool backup --roots $config --dest (Join-Path $backupFull 'snapshots')
if($LASTEXITCODE -ne 0){throw 'Primeiro backup falhou. Tarefa não instalada.'}
# Teste real de restore do primeiro snapshot antes de agendar.
$latest=Get-Content -LiteralPath (Join-Path $backupFull 'snapshots\LATEST.json') -Raw|ConvertFrom-Json
$index=Join-Path $backupFull ('snapshots\'+$latest.snapshot+'\INDEX.json')
$restore=Join-Path $backupFull ('restore-test-'+(Get-Date -Format 'yyyyMMddHHmmss'))
& $py $tool restore --index $index --target $restore
if($LASTEXITCODE -ne 0){throw 'Restore falhou; tarefa não instalada.'}
$name='Assimilacao-Checkpoint-Local'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'Tarefa existente: conferir configuração antes de substituir.'}
$action=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -File "'+$runner+'" -Python "'+$py+'"')
$trigger=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 30)
$settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 2)
Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Settings $settings -Description 'Snapshots versionados; sem poda automática; independente da IA.' | Out-Null
Get-ScheduledTask -TaskName $name
if($DriveMirror){Write-Output 'Mirror Drive informado: conferir que é Google Drive real. Sincronização automática não foi instalada por este script.'}
