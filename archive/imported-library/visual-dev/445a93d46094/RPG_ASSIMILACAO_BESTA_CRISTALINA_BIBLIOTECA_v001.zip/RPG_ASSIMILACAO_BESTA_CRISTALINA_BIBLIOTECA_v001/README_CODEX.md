# Biblioteca da Besta Cristalina — instrucoes para Codex e Comestres

Versao v001. Escopo: MESTRE-SIDE, uso de referencia/ativos visuais. Nao publicar em repositorio publico nem exportar para Party sem autorizacao do Mestre.

## Abertura

1. Extraia este ZIP inteiro. Nao tente fazer o Codex interpretar apenas a miniatura do ZIP.
2. Abra `manifest.json` primeiro. Em seguida, abra os PNGs verdadeiros em `01_PRANCHAS_COMPLETAS/` e `02_VISTAS_INDIVIDUAIS/`.
3. As imagens sao dados binarios PNG, nao links ou prompts. Os hash SHA-256 permitem confirmar a origem de cada uma.
4. Prancha A = Frente, Costas, Esquerda, Direita (row-major, superior esquerda, superior direita, inferior esquerda, inferior direita).
5. Prancha B = Frente-Esquerda, Frente-Direita, Costas-Esquerda, Costas-Direita, na mesma ordem de quadrantes.
6. Quadros individuais sao recortes EXATOS dos quadrantes dos originais, sem reamostragem/redesenho. Nao confundir com frames de animacao.

## Credenciais e validacao

- O Mestre aceitou estas duas pranchas como referencias. A ficha, classificacao, status canonico e as regras mecanicas da criatura NAO foram alteradas.
- A camera de 35 graus foi uma intencao artistica, nao medida geometrica calibrada no Blender.
- PNG RGBA comprovado, com pixels de alpha 0, MAS as bordas e residuais de fundo podem exigir revisao no Godot. O manifesto nao atesta limpeza absoluta da transparencia nem operacao ja testada na engine.
- `tools/verificar_pacote.py` confere integridade/hash, dimensoes, formatos e direcoes a partir dos arquivos.

## Atualizacao por autorizacao expressa

- Quando o Mestre declarar nova prancha/vista APROVADA, adicionar PNG(s) originais ao conjunto, preservar os anteriores e criar nova versao: v002, v003, etc.
- Na nova versao, atualizar `manifest.json` com identificacao unica, SHA-256, origem, aprovacao, data, sucessao de referencias e testes.
- Nao sobrescrever uma imagem aprovada por outra reinterpretada sem autorizacao. Nao criar de zero se ha referencia aprovada.
- Se outro chat/Codex nao tiver acesso a este arquivo ZIP, o Mestre precisa anexar o pacote ou disponibiliza-lo por fonte privada autorizada; o Notion nao converte automaticamente este ZIP em bytes acessiveis ao Codex.
- Um catalogo de metadados pode estar registrado no Notion. O ZIP com os PNGs deve ser passado ao Codex ou guardado em armazenamento acessivel de fato.

## Normas relacionadas

PV-2.5D-ANG-01 — quatro/eight vistas estaticas em duas pranchas; PV-2.5D-MOV-02 v1.1 — caminhada: uma direcao por LINHA e movimento esquerda->direita; PV-2.5D-QUAL-03 — qualidade maxima efetivamente disponivel. Os sprites de movimento NAO sao parte desta versao do catalogo.
