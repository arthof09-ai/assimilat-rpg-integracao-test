# Ordem e posicao dos angulos

| Prancha | Superior esquerda | Superior direita | Inferior esquerda | Inferior direita |
|:--|:--|:--|:--|:--|
| A — cardinal | Frente | Costas | Esquerda | Direita |
| B — diagonal | Frente-esquerda | Frente-direita | Costas-esquerda | Costas-direita |

**Importante**: ambas as pranchas contêm imagens estaticas, não uma caminhada; imagem de cada quadrante sem redesenho. O 35° e alvo artístico, não comprovacao fisica de câmera.

Para atualizar, iniciar o novo arquivo ZIP da versão ANTERIOR, anexar apenas imagens novas com autorização explícita do Mestre, manter cópias e hashes dos aceitos, e emitir ZIP versionado.
