# RPG ASSIMILAÇÃO — ACERVO VISUAL DIVIDIDO PARA CODEX CLOUD (32 MiB)

ESTE É UM DOS 4 ZIPS INDEPENDENTES E EXTRAÍVEIS. Não é arquivo .001/.002 a ser remontado. Cada ZIP contém parte do conjunto, com caminhos originais do ZIP unificado e documentação de índice comum.

**ATENÇÃO:** os arquivos `00_COMECE_AQUI/LEIA_PRIMEIRO_CODEX.md` e `00_COMECE_AQUI/PROMPT_PRONTO_CODEX.md` vieram do ZIP unificado e mencionam um único ZIP. Isso é histórico. Use PRIMEIRO esta instrução e a ordem do Mestre; leia os quatro pacotes como um conjunto lógico; jamais conclua auditoria total antes dos quatro chegarem e seus conteúdos serem verificados.

Partes necessárias:
1. 01_BESTA_CRISTALINA_v009 — todas as fontes e documentos da Besta Cristalina.
2. 02_CAPRILEO_ESCAMOSO_v001 — todas as fontes e documentos do Capríleo.
3. 03_ORC_ANGULOS_CARDINAIS — 4 vistas do Orc e prancha A, manifesto.
4. 04_ORC_DIAGONAIS_ATAQUES — 4 vistas diagonais, prancha B, dois ataques e machado, manifesto.

`INVENTARIO_GERAL.json` lista TODOS os 61 arquivos das bibliotecas originais. Não interprete ausências das demais partes como corrupção do pacote corrente. Não comprima, redesenhe ou altere originais. Codex deve aplicar verificação independente; os PNGs continuam fonte primária para vistas e animações.

PROCEDIMENTO: extraia cada ZIP para a MESMA pasta privada de trabalho, preservando a árvore de caminhos. Os nomes repetidos em `00_COMECE_AQUI/` e os 2 arquivos de documentação do Orc possuem conteúdo idêntico e hashes idênticos; evite sobrescrever sem comparar hashes. Isso NÃO gera imagens duplicadas.

STATUS: empacotamento abaixo do limite de 32 MiB por parte. Limite real de aceitação do Codex ainda deve ser verificado; um arquivo abaixo do limite não garante que a interface montou a referência, portanto exija leitura dos arquivos e SHA no ambiente do Codex.

Classificação MESTRE-SIDE, não transferir à Party, O Primeiro ou repositório público.

**ESTA PARTE: 1/4 — 01_BESTA_CRISTALINA_v009.**

**Arquivos específicos desta parte:**
- `01_BESTA_CRISTALINA_v009/01_PRANCHAS_COMPLETAS/PRANCHA_A_CARDINAIS.png`
- `01_BESTA_CRISTALINA_v009/01_PRANCHAS_COMPLETAS/PRANCHA_B_DIAGONAIS.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/A/01_FRENTE.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/A/02_COSTAS.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/A/03_ESQUERDA.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/A/04_DIREITA.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/B/05_FRENTE_ESQUERDA.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/B/06_FRENTE_DIREITA.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/B/07_COSTAS_ESQUERDA.png`
- `01_BESTA_CRISTALINA_v009/02_VISTAS_INDIVIDUAIS/B/08_COSTAS_DIREITA.png`
- `01_BESTA_CRISTALINA_v009/03_QA_CODEX_INDEPENDENTE/CONTRATO_EXECUTOR_CODEX.md`
- `01_BESTA_CRISTALINA_v009/03_QA_CODEX_INDEPENDENTE/CONTROLE_IMUTABILIDADE_PNG.json`
- `01_BESTA_CRISTALINA_v009/03_QA_CODEX_INDEPENDENTE/RELATORIO_CODEX_PENDENTE.json`
- `01_BESTA_CRISTALINA_v009/04_ATIVOS_APROVADOS/ATAQUES/ATAQUE_02_INVESTIDA_SERPENTINA_SOCO_DEMOLIDOR_3X3_APROVADA_b9b6b992b3f0.png`
- `01_BESTA_CRISTALINA_v009/04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PARTE_02_PROJETIL_VOO_3X3_APROVADA_fd77c2af53f3.png`
- `01_BESTA_CRISTALINA_v009/04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PARTE_03_IMPACTO_E_FRAGMENTACAO_3X3_APROVADA_e0af42ed7d15.png`
- `01_BESTA_CRISTALINA_v009/04_ATIVOS_APROVADOS/ATAQUES/DOBRA_TERRA_PRANCHA_01_3X3_APROVADA_1ba609dce766.png`
- `01_BESTA_CRISTALINA_v009/04_ATIVOS_APROVADOS/MOVIMENTO/CAMINHADA_ESQUERDA_DIREITA_2X3_3_POSES_APROVADA_c22747e67216.png`
- `01_BESTA_CRISTALINA_v009/04_ATIVOS_APROVADOS/MOVIMENTO/CAMINHADA_FRENTE_COSTAS_2X3_3_POSES_APROVADA_e2e1c96e041f.png`
- `01_BESTA_CRISTALINA_v009/05_PLANEJAMENTO_E_APRENDIZADOS/PROMPT_ATAQUE_02_INVESTIDA_SERPENTINA_SOCO_DEMOLIDOR_TEST.md`
- `01_BESTA_CRISTALINA_v009/05_PLANEJAMENTO_E_APRENDIZADOS/PROMPT_DOBRA_TERRA_PARTE_03_IMPACTO_3x3_16x9.md`
- `01_BESTA_CRISTALINA_v009/05_PLANEJAMENTO_E_APRENDIZADOS/RELATORIO_ETAPAS_FALHAS_E_GATES.md`
- `01_BESTA_CRISTALINA_v009/06_MOVIMENTO_QA_V009.json`
- `01_BESTA_CRISTALINA_v009/ATUALIZACAO_INCREMENTAL_E_ARTE_LIMPA.md`
- `01_BESTA_CRISTALINA_v009/HISTORICO_VERSOES.md`
- `01_BESTA_CRISTALINA_v009/LEIA_PRIMEIRO_V009_CODEX.md`
- `01_BESTA_CRISTALINA_v009/MANIFESTO_HUMANO.md`
- `01_BESTA_CRISTALINA_v009/QA_VERIFICACOES.json`
- `01_BESTA_CRISTALINA_v009/README_CODEX.md`
- `01_BESTA_CRISTALINA_v009/manifest.json`
- `01_BESTA_CRISTALINA_v009/tools/atualizar_biblioteca_aprovacao.py`
- `01_BESTA_CRISTALINA_v009/tools/verificar_pacote.py`
