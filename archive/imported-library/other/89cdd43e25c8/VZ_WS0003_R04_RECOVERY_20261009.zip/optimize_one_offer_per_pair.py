import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
stores=['KH','MY','KV','AU']
F=['Magias','Artefatos/Acessórios','Roupas','Armaduras','Armas','Ervas','Minérios','Pílulas','Inscrições','Espíritos Demoníacos','Taxas/Serviços','Drops/Materiais','Poções','Outros']
q=np.array([[20,28,18,16,20,12,24,10,24,12,6,22,14,26],[14,18,20,12,16,34,14,18,14,12,6,28,28,18],[12,18,14,28,32,10,30,10,16,10,6,28,12,26],[24,32,26,12,18,20,12,18,26,10,6,14,16,18]])
assert all(q.sum(axis=1)==252)
M=list(range(1,16));K=len(M)*len(F)
# unique commercial sources each one fixed family, maximum one listing per store
A=lil_matrix((len(F)*4+4+1,K)); rhs=[]
for f in range(len(F)):
 for si in range(4):
  row=len(rhs); rhs.append(q[si,f]);
  for mi,m in enumerate(M):
   if m&(1<<si):A[row,mi*len(F)+f]=1
for si in range(4):
 row=len(rhs);rhs.append(60)
 for f in range(len(F)): A[row,((1<<si)-1)*len(F)+f]=1
row=len(rhs);rhs.append(84)
for f in range(len(F)):A[row,14*len(F)+f]=1
lo=np.array(rhs,float); hi=lo.copy();hi[4*len(F):]=np.inf
res=milp(c=np.ones(K),integrality=np.ones(K),bounds=Bounds(np.zeros(K),np.full(K,np.inf)),constraints=LinearConstraint(A.tocsr(),lo,hi),options={'time_limit':25,'mip_rel_gap':0.001})
print('status',res.status,res.message,'min',res.fun,'lower_bound',getattr(res,'mip_dual_bound',None))
if res.x is not None:
 x=np.rint(res.x).astype(int).reshape((15,len(F)))
 print('by_multiplicity',{p:int(sum(x[i].sum() for i,m in enumerate(M) if m.bit_count()==p)) for p in range(1,5)})
 print('singletons',[int(x[i].sum()) for i in [0,1,3,7]],'all_common',int(x[14].sum()))
 print('total_unique',int(x.sum()),'total_listings',int(sum(x[i].sum()*m.bit_count() for i,m in enumerate(M))))
 print('family all-common min supply',dict(zip(F,np.min(q,axis=0).tolist())),'sum min',int(np.min(q,axis=0).sum()))
 print('mask matrix')
 for i,m in enumerate(M):print(f'{m:04b}',int(x[i].sum()),';'.join(F[j]+':'+str(v) for j,v in enumerate(x[i]) if v))
 np.savez('/mnt/data/vz_r04_opt_solution.npz',x=x,q=q,stores=np.array(stores),families=np.array(F))
