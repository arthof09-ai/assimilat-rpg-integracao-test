from pathlib import Path
import numpy as np,csv,json,hashlib
root=Path('/mnt/data/vz_ws0003_r04');a=np.load('/mnt/data/vz_r04_opt_solution.npz');b=np.load('/mnt/data/vz_r04_scenario420.npz');x442=a['x'];x420=b['x'];d=b['d'];q=a['q'];F=a['families'].tolist();stores=a['stores'].tolist();masks=range(1,16)
assert x442.shape==(15,14) and x420.shape==(15,14) and d.shape==(14,4)
assert x442.sum()==442 and x420.sum()==420 and d.sum()==50
for x in [x442,x420]:
 for f in range(14):
  for si in range(4):
   s=sum(x[m-1,f] for m in masks if m&(1<<si))
   if x is x420:s+=d[f,si]
   assert s==q[si,f],(f,si,s,q[si,f])
 for si in range(4):assert sum(x[(1<<si)-1,:])==60
assert x442[-1].sum()==168 and x420[-1].sum()==178
fields=['SCENARIO','FAMILY_EXISTING','FAMILY_INDEX','STORE_SUBSET_MASK_4BIT_KH_MY_KV_AU','STORE_SET','ITEM_IDENTITY_COUNT_SIMULATION_ONLY','NUMBER_OF_STORE_LISTINGS_NO_DUPLICATES','CANONICAL_ITEM_ID','STATUS']
rows=[]
for label,x in [('S1-442 ONE-ITEM-STORE',x442),('S2-420 CONDITIONAL-REPEATED-OFFER',x420)]:
 for f,fam in enumerate(F):
  for m in masks:
   n=int(x[m-1,f]);
   if n==0:continue
   rows.append({'SCENARIO':label,'FAMILY_EXISTING':fam,'FAMILY_INDEX':f+1,'STORE_SUBSET_MASK_4BIT_KH_MY_KV_AU':format(m,'04b'),'STORE_SET':'|'.join(stores[si] for si in range(4) if m&(1<<si)),'ITEM_IDENTITY_COUNT_SIMULATION_ONLY':n,'NUMBER_OF_STORE_LISTINGS_NO_DUPLICATES':n*m.bit_count(),'CANONICAL_ITEM_ID':'NONE — mathematical allocations only','STATUS':'MATHEMATICAL-FEASIBILITY/NO ITEMS CREATED'})
with (root/'VZ_R04_MATH_FAMILY_ALLOCATION_442_AND_420.csv').open('w',newline='',encoding='utf-8') as w:
 wr=csv.DictWriter(w,fieldnames=fields);wr.writeheader();wr.writerows(rows)
rows2=[]
for fi,fam in enumerate(F):
 for si,st in enumerate(stores):
  v=int(d[fi,si]);
  if v:rows2.append({'SCENARIO':'S2-420-CONDITIONAL','STORE_ID_SHORT':st,'FAMILY_EXISTING':fam,'EXTRA_SAME_ITEM_STORE_OFFERS_SIMULATED':v,'REQUIRED_REAL_COMMERCIAL_DIFFERENTIATION':'INDEPENDENT-GATE - distinct channel/lot/licence/quality with real identity authority; not invented','EXISTING_REAL_OFFER_IDS':'0','CANONICAL_AUDIT_STATUS':'SPEC-PENDING / NOT AUTHORIZED'})
with (root/'VZ_R04_MATH_420_REPEATED_PAIR_SENSITIVITY.csv').open('w',newline='',encoding='utf-8') as w:
 wr=csv.DictWriter(w,fieldnames=list(rows2[0]));wr.writeheader();wr.writerows(rows2)
mt={
'four_store_quota_by_family':{fam:dict(zip(stores,map(int,q[:,fi]))) for fi,fam in enumerate(F)},
'fixed_56_quota_sum':[int(v) for v in q.sum(axis=1)],
'sum_per_family_minimum':int(np.min(q,axis=0).sum()),
'S1_zero_repeat_one_family_per_item':{'MILP_integer_optimum':442,'exclusive_unique':240,'common_4_stores':168,'unique_shared_3_stores':28,'unique_shared_2_stores':6,'listings':1008,'420_minimum_satisfied':True,'420_UAT_exact_baseline_unchanged':False,'potential_extra_source_UAT_requires_approval':22,'canonical_source_items_created':0},
'S1b_exact84_global_staples':{'MILP_integer_optimum':468,'exclusive_unique':240,'common_4_stores_exact':84,'unique_shared_3_stores':144,'shared_2':0,'listings':1008,'normal_minimum_staples_clause_is_greater_equal':True},
'S2_420_unique_conditional_same_store_multiple_true_offers':{'unique_identities':420,'exclusive_unique':240,'common_4_stores':178,'shared_3':2,'extra_item_store_pair_offers_min':50,'listings':1008,'condition':'at most 2 legitimate offers per item×store, constant family; each additional offer has its own verified economic distinction and authorized identity'},
'source_of_family_quotas':'https://app.notion.com/p/3f2c2b324ede8141b3beecc19564305a',
'legal_interpretation':'PR-ITEM-02 and SHOP-VZ-EXEC-01 do not by mere silence authorize duplicate offers; remains NAC-NORM/MASTER DECISION',
'solver':'scipy.optimize.milp / HiGHS integer optimal result, 15 nonempty store subsets ×14 families; bounds certified=objectives; S2 duplicate 56 variables',
'note':'S1 simulations do not generate ITEM-ID, SOURCE-ID or OFFER-ID, and do not approve denominator changes.'}
(root/'VZ_R04_MATH_SCENARIOS_AND_ASSUMPTIONS.json').write_text(json.dumps(mt,ensure_ascii=False,indent=2),encoding='utf-8')
print('allocation nonzero rows',len(rows),'duplicate rows',len(rows2),'family minima',int(np.min(q,axis=0).sum()),'s1 identities',int(x442.sum()),'s2 identities',int(x420.sum()),'dup',int(d.sum()))
