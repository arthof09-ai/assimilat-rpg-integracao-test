import csv,unicodedata,re,difflib,json,collections
from pathlib import Path
p=Path('/mnt/data/vz_ws0003_r04')
with (p/'VZ_R04_SOURCE420_WITH_HISTORIC50_HOLD.csv').open(encoding='utf-8') as f: rows=[x for x in csv.DictReader(f) if x['EXISTING_BLUEPRINT_REFERENCE_ID']]
def norm(s):
 s=unicodedata.normalize('NFKD',s.casefold());s=''.join(c for c in s if not unicodedata.combining(c));return ' '.join(re.findall('[a-z0-9]+',s))
entries=[{'id':x['EXISTING_BLUEPRINT_REFERENCE_ID'],'name':x['EXISTING_BLUEPRINT_NAME'],'key':norm(x['EXISTING_BLUEPRINT_NAME']),'class':x['BOOKING_CLASS'],'url':x['EXISTING_BLUEPRINT_SOURCE_URL']} for x in rows]
seen={};dupids=[];dupnames=[]
for e in entries:
 if e['id'] in seen:dupids.append(e['id'])
 seen[e['id']]=e
byname=collections.defaultdict(list)
for e in entries:byname[e['key']].append(e['id'])
dupnames=[(k,v) for k,v in byname.items() if len(v)>1]
triage=[]
for i,a in enumerate(entries):
 for b in entries[i+1:]:
  # exclude same individual with identical name, record as exact otherwise
  score=difflib.SequenceMatcher(None,a['key'],b['key']).ratio()
  tokensA=set(a['key'].split());tokensB=set(b['key'].split());jacc=len(tokensA&tokensB)/max(1,len(tokensA|tokensB))
  if a['key']==b['key'] or score>=.77 or jacc>=.55:
   triage.append({'REFERENCE_A':a['id'],'NAME_A':a['name'],'CLASS_A':a['class'],'REFERENCE_B':b['id'],'NAME_B':b['name'],'CLASS_B':b['class'],'NORMALIZED_EXACT_EQUAL':str(a['key']==b['key']),'NAME_SEQUENCE_SIMILARITY':f'{score:.3f}','TOKEN_JACCARD':f'{jacc:.3f}','AUDIT_VERDICT':'LEXICAL-TRIAGE-ONLY/NO SEMANTIC EQUIVALENCE PROVED','SOURCE_URL_A':a['url'],'SOURCE_URL_B':b['url'],'REQUIRED_NEXT':'compare material/provenance/function/parent processing and existing aliases before any SOURCE-credit merge'})
triage.sort(key=lambda x:(-float(x['NAME_SEQUENCE_SIMILARITY']),-float(x['TOKEN_JACCARD']),x['REFERENCE_A']))
with (p/'VZ_R04_LEXICAL_ALIAS_TRIAGE_169_REFERENCES.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(triage[0]) if triage else ['REFERENCE_A']);w.writeheader();w.writerows(triage)
stats={'existing_blueprint_references_reviewed':len(entries),'unique_ids':len(seen),'duplicate_exact_existing_ids':dupids,'duplicate_normalized_exact_name_groups':dupnames,'lexical_similarity_alerts':len(triage),'semantic_aliases_approved':0,'deduplication_is_not_final':True}
(p/'VZ_R04_LEXICAL_ALIAS_QA.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(stats,ensure_ascii=False));print('top 12',json.dumps(triage[:12],ensure_ascii=False)[:5800])
