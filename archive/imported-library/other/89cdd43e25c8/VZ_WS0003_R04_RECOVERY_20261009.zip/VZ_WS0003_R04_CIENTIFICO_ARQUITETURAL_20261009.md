# VZ / CM-000005-I0011 / WS0003 — R04

**MESTRE-SIDE — pacote de pesquisa científica, documentação de design e verificação local. NÃO é decisão normativa, inventário material, autorização de agendamento, nem avaliação independente NC-05.**

## PSV / continuidade

- **Último estado físico de referência:** R03 (`c00f5344ec9e8adcaba826ca485eb65005c22de4c1e01eb5e7bbd438bf8d1d62`) recuperado por Biblioteca com comparação de SHA. R01/R02/R03 preservados separadamente. Sem retomar VLAB; artefatos do desvio pertencem ao domínio VLAB e não recebem write/authority deste WS.
- **T16** `VZ-IBX18-PATCH035-I0011-20261008`: Control com `PENDING-READBACK`, sem `ACTIVE`/`PASS`; Diário contém BEFORE, IBX-18 não recebeu checkpoint. Nenhuma tentativa de escrita na IBX-18. Regularização requer autoridade e fencing, jamais contorno.
- **Material:** `0/1649` UAT verificados; `420 SOURCE` e `1008 OFFER` permanecem baselines, sem alteração. `R07=HOLD`, `ABS-L=DENY`, scheduler não armado, Party/O Primeiro zero escrita.
- **FUSION-E3**: PATCH-03/04/05 documentais anteriores preservados; 15/16 = regressão científica reconstruída HISTÓRICA, 11/16 = última regressão INDEPENDENTE histórica; NC-05 não repetida, NAC-PASS arquitetural HOLD.

## 1. Modelo matemático — 1.008 ofertas x identidade comercial

**Fonte atual:** [SHOP-VZ-EXEC-01](https://app.notion.com/p/3f2c2b324ede8141b3beecc19564305a) impõe quatro lojas com 252 ocorrências cada, 56 cotas (4×14 famílias), **no mínimo 420** itens-fonte comerciais distintos, ao menos 60 itens assinatura **exclusivos de cada cidade** e ao menos 84 itens **comuns nas quatro lojas**. `OFFER ≠ ITEM`; cada ocorrência demanda ITEM/STORE, preço, estoque, licença, origem e disponibilidade. O contrato não diz que só 420 itens devem existir. `420` é, entretanto, número EXATO de unidades SOURCE no denominador físico vigente de [VZ-MATERIAL-MANIFEST-01](https://app.notion.com/p/3f2c2b324ede81fc9a31e1b6472a0418).

### Hipóteses explicitadas para os cenários

- **H1 — Item com família fixa:** um SKU comercial corresponde a uma categoria dentre as 14 para todas as lojas. Variantes com efeito/função material diferente exigem identidade própria até prova contrária de PR-ITEM-02.
- **H2 — Uma ocorrência por par ITEM×STORE:** evita multiplicar o mesmo item no mesmo estabelecimento sem distinção real/identidade oferta e impede duplicatas fictícias.
- **H3 — Exclusivo:** ID comercial aparece em apenas uma das quatro lojas, e por isso os 60 exclusivos de cada cidade são conjuntos disjuntos (240 no total).
- **H4 — Comum:** pelo menos 84 IDs aparecem nas quatro lojas; 84 é piso, NÃO máximo nem valor exato obrigatório.
- **H5 — Não equivaler recurso, produto, serviço e ocorrência:** item pessoal, serviço, drop, RV e fórmula RC podem ter autoridades distintas. Uma relação de blueprint não vira ficha comercial/UAT física.

### Resultados MILP reproduzíveis (cotas 56×1, 15 subconjuntos não-vazios de lojas, variáveis inteiras)

| Cenário | Mínimo matemático | Construção suficiente / prova | Efeito normativo |
|---|---:|---|---|
| S0 — H2 sem restrição por família | 432 IDs | 240 exclusivos e 192 comuns ×4 = 1.008 | Só limite inferior; não satisfaz necessariamente as 56 cotas reais |
| **S1 — H1–H4 e 56 cotas** | **442 IDs** | 240 exclusivos, 168 comuns ×4, 28 compartilhados por 3 e 6 por 2 → 240+672+84+12=1.008. MILP ótimo certificado. | Satisfaz o mínimo 420; implicaria +22 fichas SOURCE sobre baseline físico 420 se cada ID exigir uma ficha separada |
| S1b — S1 com exatos 84 comuns | 468 IDs | 240 exclusivos, 84 comuns ×4, 144 compartilhados por 3 → 1.008 | 84 **não é teto no contrato**; cenário de sensibilidade |
| **S2 — 420 IDs, autorizadas ofertas distintas para mesmo par ITEM×STORE** | **50 pareamentos repetidos adicionais** | 240 exclusivos; 178 comuns ×4; 2 compartilhados por 3 → 958 pares diferentes; +50 ocorrências comerciais justificadamente distintas = 1.008. MILP ótimo, **com permissão adicional hipotética** de no máximo duas ofertas por par. | Depende de autorização, identidade comercial distinta, sem fingir que remessa/lote é novo item; zero ofertas verificadas |

A família comum máxima de um único ITEM é limitada pelas cotas menores das quatro lojas; a soma dos mínimos por família é 178, mas exclusividade simultânea obriga uma combinação mais específica. Os modelos S1/S2 estão em `VZ_R04_MATH_FAMILY_ALLOCATION_442_AND_420.csv`; os 50 repetidos S2 em `VZ_R04_MATH_420_REPEATED_PAIR_SENSITIVITY.csv`; regras/modelo em JSON. **NENHUMA variável da simulação é ITEM-ID/SOURCE-ID/OFFER-ID real.**

**Stress normativo (NAC-NORM-01, recomendação não canonizada):** `SHOP` especifica `OFFER ≠ ITEM`, e `PR-ITEM-02` governa identidade/variante/ocorrência do produto. Não foi encontrada autorização universal explícita para dois OFFER por mesmo ITEM+STORE; silêncio ≠ permissão. Serviço/taxa pode integrar SOURCE comercial por autoridade própria, mas não pode ser disfarçado como ITEM físico. `SOURCE comercial` no Manifesto e `ITEM-ID` mínimo no SHOP precisam de definição de contagem coerente. A igualdade 420 física x mínimo 442 (sob S1) é **interlock de design**, não autorização de modificar 1649.

**Opções para decisão competente:**

- **Recomendação prioritária:** manter SHOP com `≥420`, preservar agora 1649, adotar **S1 (442 IDs únicos como estudo de distribuição)** e submeter à autoridade responsável a rederivação física +22 apenas quando os IDs reais, escopos e deduplicação estiverem demonstrados. A meta documental não implica criação de 22 itens fictícios. Independência de famílias e 60 exclusivas deve ser real e demonstrável.
- **Alternativa S2:** manter 420 fichas únicas com pelo menos 50 ofertas adicionais por par ITEM×STORE, apenas se diferenciação econômica concreta for reconhecida e testável (versão comercial juridicamente distinta, regime licenciado, canal/lote com independência de preço/estoque, não listagem duplicada). Submeter ao Mestre/NAC-NORM; sem permissão = FAIL-CLOSED.
- **Alternativa de renegociar categorias/quota/exclusividade:** mudança de regra superior e impacto funcional no conteúdo urbano; **não autorizada** nesta entrega.

## 2. Avanço efetivo de R16 / ledger sem fabricar UAT

| Métrica | R03 → R04 | Prova |
|---|---:|---|
| Posições de análise SOURCE existentes | 420 → **420** | Schema R03 preservado e novas colunas/status apenas quando necessário |
| RV80 já existentes em fonte canônica | 80 → **80** | Fonte RESOURCE-VZ-FAL/PAN/FEN/BOS-20 e R02 |
| Produtos RC comerciais sob proposta anterior | 39 → **39** | R03, 9 de 48 não presumidos varejáveis |
| **Novas identidades históricas encaminhadas à análise**, NÃO novas SOURCE aptas | 0 → **50** | `UAT-B-D01A…D10E` de LEGACY-B e crosswalk R01, com Besta atual e eco-HOLD |
| SOURCE candidatas RV/RC já catalogadas | **119 → 119** | Sem promoção/sem contagem indevida dos 50 históricos |
| Posições sem qualquer identidade investigada | 301 → **251** | 50 vagas passaram a fila `LEGACY50/ECO-HOLD` |
| OFFER propostas anteriormente RC×loja | **39 → 39** | Quatro cadeias E2E documentais entre as 39 |
| **Novos vínculos propostos RV×loja de origem** | 0 → **80** | 20 recursos/bioma x 4 lojas; família dentro da cota; gate supply |
| Total de vagas com proposta RV ou RC | 39 → **119** | `VZ_R04_OFFER1008_PLUS80_RV_PROPOSED.csv` |
| Cotas ainda sem produto | 969 → **889** | Faltam IDs e consumidores, nunca ofertar filler |
| SOURCE-ID/ITEM-ID/OFFER-ID materiais, estoque, preço, carga | **0** | `R07 HOLD`, nenhum desses campos preenchido |

**Diferença epistemológica:** foram localizadas 50 identidades DROP HISTÓRICAS com lastro nominal, mas nenhuma passou a ser nova `SOURCE-ID` comercial. O avanço é `INDEXADO/PENDENTE`, não `SOURCE VALIDADA`. Os 80 RV agora possuem *candidatos de associação local* a categoria e loja, mas nenhuma venda ou quantidade de colheita foi atestada. `1008 posições` ≠ `1008 OFERTAS`.

### Ecologia dos drops históricos

As 50 identidades pertencem às dez espécies históricas B01–B10 e foram cruzadas aos `B-VZ-*` correntes do R01, mantendo STATUS histórico `BLOCKED-BEAST`. Sob B04, fonte Terra/Spectral antiga x Água/Spectral E3 não foi arbitrada; em B09/B10 não foi provada ocorrência local para D09B/D09D/D10D. D02B/D03B/D08B seguem alternativas condicionais; nenhuma CORE substituída. Os registros possuem anatomia proposta, modo legítimo de obtenção e review ecológico; **necropsia, coleta sensível ou pós-morte não originam estoque por inferência**. As 150 V2 estão preservadas e não foram importadas para vagas SOURCE material.

### Gatilhos de mercado para os RV

Os novos 80 candidatos locais respeitam as cotas `H→Ervas`, `M→Minérios`, `E→Outros` e `O→Drops/Materiais` **como propostas de família**, não classificação final. Para 20 RV de cada região há 20 propostas por loja, sem exceder nenhuma das 56 cotas e sem colidir com as 39 RC de R03. O mapa local **não demonstra colheita, oferta, valor MED nem licença**. A família O contém derivados processados; dupla contagem com insumos deve ser afastada por proveniência, rendimento e uma única identidade física por tipo de produto.

Onze relações de origem **textualmente sustentadas** entre RV processados e insumos estão em `VZ_R04_PROCESSED_RV_ORIGIN_11_EDGES.csv`; exemplos: `RV-FAL-O04 ← RV-FAL-M05 + RV-FAL-O02`, `RV-FEN-O05 ← RV-FEN-M01 + RV-FEN-O01 + RV-FEN-M03`, `RV-PAN-E05 ← RV-PAN-O01`. Sua materialidade permanece inexistente.

### Triagem adicional de aliases e semântica (169 referências documentais)

A análise de 80 RV + 39 RC comerciais condicionais + 50 históricos encontráveis possui **169/169 IDs distintos e 169/169 nomes normalizados exatos distintos**. Uma triagem lexical comparativa (não uma auditoria semântica completa) sinalizou **25 pares para revisão manual**, zero aliases ou merges promovidos. Ex.: `RV-PAN-E05 Essência de Eco Pálido` versus `RV-PAN-O01 Resina de Eco Pálido` não são duplicatas: a fonte regional informa que a essência é destilada da resina; cadeia parental/processamento não é identidade idêntica. Da mesma forma `RC-VZ-BOS-08 Arco de Geada Clara` versus `UAT-B-D07C Garra de Geada Clara` só compartilham linguagem e não pertencem sequer à mesma família material. Arquivo: `VZ_R04_LEXICAL_ALIAS_TRIAGE_169_REFERENCES.csv`. 25 alertas não são 25 duplicatas comprovadas.

## 3. Pré-criação: 48/48 receitas com protocolos propostos

Os oito protocolos R02 e os 16 R03 mantêm seus arquivos e identidades. R04 acrescenta **24/24 protocolos faltantes**, por RC existente, completando **48/48 em cobertura autoral experimental** — não 48/48 executados nem aprovados. Cada novo protocolo tem:

- ingredientes RV originais intactos e valores numéricos **índices de comparação por 100 partes**, NÃO medidas normativas, dosagens, rendimento, potência, preço ou custos autorizados;
- processo particularizado, ferramentas de bancada, condições de conservação, ensaio de contraste/ablação, aceitação/rejeição, riscos específicos, licença ecológica, rota de design quando ingrediente vem de outro bioma;
- `SOURCE-ID/ITEM-ID/OFFER-ID=NONE`, `R07=HOLD`, prova empírica zero, `UAT=0`.

As 24 linhas estão em `VZ_R04_PRE24_COMPLETION.csv`. Casos deliberadamente contidos: gás E01 nunca supre ar respirável, pó M03 nunca sem cabine, produto de infraestrutura nunca serviço público automaticamente aprovado, recursos botânicos sensíveis nunca retirada da planta-mãe inteira, amostra forense nunca captura memória real por alegação.

## 4. Fusão, NC-05 e interlock de comunicação

- **Autoridade corrente:** VZ-CANON-01 / FUSION-E3; D01–D17 preservados. PATCH-03 harmonizado em oito consumidores na etapa anterior; PATCH-04 tríade B04/B09/B10 em HOLD; PATCH-05 quatro cadeias e sete topologias anteriores preservadas, agora complementadas por vínculos RV→loja/parentais. O R04 não reescreve patches.
- **ABS-A–K:** sem novo aceite independente integral. Novos dados ajudam ABS-D (denominador rederivado por hipóteses), ABS-E (fanout SOURCE/OFFER), ABS-J (cenários regressivos), porém não atestam PASS. `R16=HOLD` por identidades e ofertas, além da escolha normativa entre cenários; `NAC-PASS-ARQ=HOLD`.
- **NC-05:** [IBX-20](https://app.notion.com/p/3f3c2b324ede814c853ef5a6089ac453) preserva 11/16 avaliação independente histórica NEGATIVA. R16 do Cientista (15/16 reconstruída anteriormente) não substitui predicados originais. Dossiê R04 está pronto para revisão independente, **não enviado por falta de gate específico de escrita/readback no domínio competente; sem ACK**. Não criar outra NC-05.
- **T16:** `VZ-IBX18-PATCH035-I0011-20261008` continuava `PENDING-READBACK` no Control; Diário BEFORE existe; IBX-18 não contém o checkpoint. NÃO reutilizar, NÃO inferir desbloqueio. Resolver administrativamente o PENDING/fencing antes de novo claim autorizado. Esse domínio não foi escrito neste ciclo.
- **Materialização:** baseline material `1.649 = 1.008+420+96+40+1+32+48+4`, `0/1649` UAT; mesmo quando arquitetura R16 passar, R07, HARD-PROJECT-BIND, writer e NAC-PASS material permanecem gates distintos. Nenhum scheduler foi armado; nada em Party ou O Primeiro.

## 5. Próximas fronteiras recuperáveis

**P0.** Validar a interpretação de identidade comercial e regime OFFER. Se H2/H1 obrigatórios, submeter `S1 min442` com prova de identidade/denominador ao Mestre/NAC-NORM; se S2 permitido, exigir 50 diferenciações comerciais reais verificáveis, nunca clones. Converter a fila 50 DROP/251 vazios em candidatos fundamentados de SOURCE existente-first, sem promover históricos bloqueados. Qualificar 80 ligações RV→loja por fonte, licença, produção/estoque e semântica do item. Só então distribuir outras ocorrências com ≥84 staples e ≥60 exclusivas reais.

**P1.** Obter validação científica de proporções de projeto para os 48 RC quando houver autoridade de ensaio, selecionar protótipos comparativos sob controle, calibrar rendimento/tempo/perdas e integrar protocolos como adendos REC-EXEC sob writer legítimo; especificar as 15 RV sem consumidor RC somente com função comprovada. Tudo por fases PROPOSTO→VALIDADO→APROVADO PARA MATERIALIZAÇÃO→MATERIALIZADO, nunca salto.

**NÃO REPETIR:** R01/R02/R03, R01 crosswalk 200, 150 V2, 40 bestas, 50 históricos, quatro E2E, sete rotas, D01–D17, 24 protocolos anteriores, testes históricos, nenhuma operação VLAB nesta instância.
