exec(open('/mnt/data/vz_r04_opt.py').read().split('res=milp')[0])
from scipy.sparse import lil_matrix
# existing A rows = 56 quotas, 4 city-exclusive, 1 shared. add 56 duplicated-listing count cols, 1 total source count, limit duplicate slots <= x present in same family/store (at most 2 offers per pair)
K2=K+56; rows=56+4+1+1+56
B=lil_matrix((rows,K2));B[:61,:K]=A[:61,:]
for f in range(14):
 for si in range(4):
  B[f*4+si,K+f*4+si]=1
B[61,:K]=1
for f in range(14):
 for si in range(4):
  rr=62+f*4+si
  B[rr,K+f*4+si]=1
  for mi,m in enumerate(M):
   if m&(1<<si):B[rr,mi*14+f]=-1
lb=np.array(rhs+[420]+[-np.inf]*56,float)
ub=np.array(rhs[:56]+[np.inf]*5+[420]+[0]*56,float)
# objective 1000 * duplicate + n (n=420 exact); reduce repeated offers
c=np.r_[np.zeros(K),np.ones(56)]
res=milp(c=c,integrality=np.ones(K2),bounds=Bounds(np.zeros(K2),np.inf),constraints=LinearConstraint(B.tocsr(),lb,ub),options={'time_limit':25,'mip_rel_gap':0.001})
print('scenario420 status',res.status,res.message,'min repeated pairs',res.fun,'dual',getattr(res,'mip_dual_bound',None))
if res.x is not None:
 x=np.rint(res.x[:K]).astype(int).reshape(15,14);d=np.rint(res.x[K:]).astype(int).reshape(14,4)
 print('N',x.sum(),'total duplicates',d.sum(),'common4',x[14].sum(),'exclusive per city',[x[(1<<i)-1].sum() for i in range(4)])
 print('masks', {f'{m:04b}':int(x[i].sum()) for i,m in enumerate(M) if x[i].sum()>0})
 print('duplicates by city',d.sum(axis=0).tolist(),'by family',list(zip(F,d.sum(axis=1).tolist())))
 print('max pair duplicate fraction', d.sum() / 1008)
 np.savez('/mnt/data/vz_r04_scenario420.npz',x=x,d=d,q=q,stores=np.array(stores),families=np.array(F))
