#!/usr/bin/env python3
"""Monta PNGs numerados em 5 colunas sem redimensionar quadros originais.
Projeto RPG Assimilacao — TEST, MESTRE-SIDE. Requer Pillow.
"""
from pathlib import Path
from PIL import Image
from datetime import datetime, timezone
import argparse, hashlib, json, math, re, sys


def order(path):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)', path.name)]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(folder, output, cols=5, margin=16, fps=10, actor='orc', action='ataque',
        direction='S', pivot_path=None, durations_path=None, preview_path=None):
    if not (cols >= 1 and margin >= 0 and fps >= 1):
        raise ValueError('colunas >= 1, margem >= 0 e fps >= 1')
    files = sorted(folder.glob('*.png'), key=order)
    if not files:
        raise ValueError('Nenhum frame PNG na pasta de entrada')
    if output.resolve() in [p.resolve() for p in files]:
        raise ValueError('Saida nao pode sobrescrever um frame de entrada')
    pivots = json.loads(pivot_path.read_text('utf-8')) if pivot_path else {}
    delays = json.loads(durations_path.read_text('utf-8')) if durations_path else {}
    if not isinstance(pivots, dict) or not isinstance(delays, dict):
        raise ValueError('Pivos e duracoes devem ser objetos JSON')
    images, anchor, timing = [], [], []
    for path in files:
        with Image.open(path) as f:
            if f.format != 'PNG':
                raise ValueError(f'Arquivo nao PNG: {path.name}')
            img = f.convert('RGBA')
        amin, amax = img.getchannel('A').getextrema()
        if amin == amax:
            raise ValueError(f'Falta transparencia real ou imagem vazia: {path.name}')
        corners = [(0, 0), (img.width-1, 0), (0, img.height-1), (img.width-1, img.height-1)]
        if any(img.getpixel(pos)[3] != 0 for pos in corners):
            raise ValueError(f'Objeto/fundo tocando canto em: {path.name}')
        x, y = pivots.get(path.name, [img.width // 2, img.height])
        x, y = int(x), int(y)
        if not (0 <= x <= img.width and 0 <= y <= img.height):
            raise ValueError(f'Pivo fora do frame: {path.name}')
        delay = int(delays.get(path.name, round(1000/fps)))
        if not 10 <= delay <= 10000:
            raise ValueError(f'Duracao fora do intervalo 10–10000 ms: {path.name}')
        images.append(img)
        anchor.append((x, y))
        timing.append(delay)

    left = max(x for x, y in anchor)
    right = max(im.width-x for im, (x, y) in zip(images, anchor))
    top = max(y for x, y in anchor)
    bottom = max(im.height-y for im, (x, y) in zip(images, anchor))
    cw, ch = left + right + margin*2, top + bottom + margin*2
    pivot_cell = [margin+left, margin+top]
    rows = math.ceil(len(files)/cols)
    atlas = Image.new('RGBA', (cw*cols, ch*rows), (0,0,0,0))
    cells, records = [], []
    for i, (file, image, (px, py), delay) in enumerate(zip(files, images, anchor, timing)):
        col, row = i % cols, i // cols
        cell = Image.new('RGBA', (cw, ch), (0,0,0,0))
        cell.alpha_composite(image, (pivot_cell[0]-px, pivot_cell[1]-py))
        atlas.alpha_composite(cell, (col*cw, row*ch))
        cells.append(cell)
        records.append({'index': i+1, 'name': file.name, 'sha256': digest(file),
                        'row': row, 'column': col, 'x': col*cw, 'y': row*ch,
                        'pivot_source': [px, py], 'duration_ms': delay})
    output.parent.mkdir(parents=True, exist_ok=True)
    atlas.save(output)
    if preview_path:
        cells[0].save(preview_path, format='WEBP', save_all=True,
                      append_images=cells[1:], duration=timing, loop=0, lossless=True)
    meta = {'schema': 'assim.sprite.sheet.TEST.v1', 'status': 'TEST_NOT_CANONICAL',
            'actor': actor, 'action': action, 'direction': direction,
            'columns': cols, 'rows': rows, 'count': len(files),
            'cell': [cw, ch], 'pivot_cell': pivot_cell,
            'order': 'left-to-right, top-to-bottom', 'frames': records,
            'atlas_sha256': digest(output),
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'warning': 'PASS do empacotamento nao prova qualidade ou fluidez de animacao'}
    output.with_suffix('.json').write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
    return meta


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('frames', type=Path)
    p.add_argument('saida', type=Path)
    p.add_argument('--colunas', type=int, default=5)
    p.add_argument('--margem', type=int, default=16)
    p.add_argument('--fps', type=int, default=10)
    p.add_argument('--ator', default='orc')
    p.add_argument('--acao', default='ataque')
    p.add_argument('--direcao', default='S')
    p.add_argument('--pivos-json', type=Path)
    p.add_argument('--duracoes-json', type=Path)
    p.add_argument('--preview-webp', type=Path)
    a = p.parse_args()
    try:
        m = run(a.frames, a.saida, a.colunas, a.margem, a.fps, a.ator,
                a.acao, a.direcao, a.pivos_json, a.duracoes_json, a.preview_webp)
        print(f"TEST PASS: {m['count']} frames, {m['columns']} colunas, {m['rows']} linhas, celula {m['cell']}")
    except (OSError, ValueError, json.JSONDecodeError) as e:
        sys.exit(f'ERRO: {e}')


if __name__ == '__main__':
    main()
