"""Testes offline de montagem, pivô, ordem e alfa. Sem assets do RPG."""
from pathlib import Path
from tempfile import TemporaryDirectory
from PIL import Image, ImageDraw
from montar_sprite_sheet import run
import json

with TemporaryDirectory() as temp:
    root=Path(temp)
    source=root/'quadros'; source.mkdir()
    for i in range(1,12):
        img=Image.new('RGBA',(60+i,90+i),(0,0,0,0))
        d=ImageDraw.Draw(img)
        d.ellipse((15,15,45,45),fill=(90,140,90,255))
        d.rectangle((25,46,36,79),fill=(130,70,65,255))
        img.save(source/f'frame_{i:03}.png')
    out=root/'saida'/'sprite.png'
    preview=root/'saida'/'previa.webp'
    m=run(source,out,cols=5,margin=12,fps=10,preview_path=preview)
    assert (m['count'],m['columns'],m['rows']) == (11,5,3)
    assert len(m['frames'])==11
    assert m['frames'][0]['name']=='frame_001.png'
    assert m['frames'][10]['row']==2 and m['frames'][10]['column']==0
    assert out.exists() and preview.exists() and out.with_suffix('.json').exists()
    with Image.open(out) as im:
        assert im.mode=='RGBA'
        assert im.size == (m['cell'][0]*5,m['cell'][1]*3)
        assert im.getpixel((im.width-1, im.height-1))[3]==0
    # Rejeitar fundo opaco disfarçado de PNG.
    fake=root/'fake';fake.mkdir()
    Image.new('RGBA',(100,100),(0,0,0,255)).save(fake/'frame_001.png')
    try:
        run(fake,root/'erro.png')
    except ValueError as e:
        assert 'transparencia' in str(e)
    else:
        raise AssertionError('PNG sem alfa nao foi rejeitado')
    # Duracao e pivo especificos.
    p=root/'pivos.json'; p.write_text(json.dumps({'frame_001.png':[20,70]}))
    t=root/'tempos.json'; t.write_text(json.dumps({'frame_001.png':210}))
    m2=run(source,root/'outra.png',pivot_path=p,durations_path=t)
    assert m2['frames'][0]['pivot_source']==[20,70]
    assert m2['frames'][0]['duration_ms']==210
print('PASS — 11 frames/3 linhas, PNG RGBA, pivot, tempos e rejeicao de fundo opaco')
