# Pipeline de sequência visual 2.5D — RPG Assimilação (TEST)

Este kit offline junta **quadros PNG já produzidos**; não cria personagens, golpes ou efeitos, não modifica Godot, VLAB ou Notion e não testa mecânicas. Seu objetivo é preservar o padrão aprovado pelo Mestre: **cinco colunas por linha, da esquerda para a direita, depois a linha seguinte, sem limite rígido de linhas**.

## Preparação

Requer Python 3.10+ e Pillow: `python -m pip install pillow`.

Organize os quadros da ação na pasta `quadros`, por exemplo `frame_001.png` a `frame_020.png` (ou qualquer quantidade). Cada imagem deve ter fundo alfa transparente. O script não remove fundos nem redimensiona desenhos, evitando deformações.

## Exemplo

```bash
python montar_sprite_sheet.py quadros orc_ataque.png --colunas 5 --margem 16 --fps 10 --ator orc --acao ataque_pesado --direcao S --preview-webp animacao.webp
```

Saídas: `orc_ataque.png` (prancha), `orc_ataque.json` (ordem, pivô, hash e tempo por frame) e, se requisitado, `animacao.webp` (prévia em movimento). Últimas células sobressalentes ficam transparentes.

## Pivôs e duração customizados

Por padrão, o pivô é a base central do quadro **de entrada**, não necessariamente o ponto real do pé. Para fixar o pé ou o centro de ação em outro pixel, crie `pivos.json`:

```json
{"frame_001.png": [128, 220], "frame_002.png": [130, 220]}
```

E, se quiser ajustar timing, crie `duracoes.json`:

```json
{"frame_001.png": 140, "frame_002.png": 80, "frame_003.png": 50}
```

Passe `--pivos-json pivos.json --duracoes-json duracoes.json`. As células terão tamanho uniforme e **as imagens não serão esticadas**. Para movimentos que se deslocam no espaço do jogo, conservar e declarar esse deslocamento na animação; não recentralizar os pés sem considerar a trajetória.

## Gates antes de aprovação

A ferramenta rejeita arquivos sem alfa real, frames vazios e cantos opacos. Ainda é necessário **inspecionar manualmente**: anatomia e equipamento fixos, lâmina/cabo consistentes, cabeça de lobo no ombro esquerdo do Orc, trajetória e peso, antecipação→execução→clímax→recuperação, câmera constante, margens legíveis, e VFX que seguem o movimento. FPS é parâmetro de prévia, não é canonização.

## Fontes de inspiração

A linguagem gestual de artes marciais e dobra elemental de Avatar inspira fluidez e integração entre gestos/energia. Não incluir personagens, pergaminhos ou ilustrações protegidas. O produto final deve ser autoral.

**Estado:** pacote TEST; somente Mestre-side, sem alteração de regras do RPG, Party ou O Primeiro.
