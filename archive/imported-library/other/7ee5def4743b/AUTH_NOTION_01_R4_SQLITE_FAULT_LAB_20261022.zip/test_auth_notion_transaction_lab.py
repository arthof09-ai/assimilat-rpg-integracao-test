#!/usr/bin/env python3
"""TEST ONLY: fault-injected SQLite persistence lab to exercise AUTH-NOTION write gates.
Does NOT connect to Notion, Party, or other RPG databases.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from hashlib import sha256
from collections import Counter
import sqlite3,json

class GateRejected(RuntimeError):pass
class SimulatedTimeout(RuntimeError):pass
class SimulatedAbort(RuntimeError):pass

def init_db(path):
    conn=sqlite3.connect(path,timeout=0.3,isolation_level=None)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.executescript('''CREATE TABLE writers(scope TEXT PRIMARY KEY,epoch INTEGER,token TEXT);
       CREATE TABLE applied(id TEXT PRIMARY KEY,scope TEXT,content_class TEXT,payload_hash TEXT);
       INSERT INTO writers VALUES('mestre',5,'lease-m-5');
       INSERT INTO writers VALUES('party',7,'lease-p-7');''')
    return conn

def apply(conn,request_id,scope,content_class,payload,epoch,token,*,fail_at=None):
    # Safe request validation happens before transaction; authorization inside transaction is rechecked.
    if scope=='party' and content_class=='mestre_only':raise GateRejected('PARTY_DENY')
    digest=sha256(payload.encode()).hexdigest()
    conn.execute('BEGIN IMMEDIATE')
    try:
        row=conn.execute('SELECT epoch,token FROM writers WHERE scope=?',(scope,)).fetchone()
        if not row or row!=(epoch,token):raise GateRejected('STALE_WRITER')
        was=conn.execute('SELECT scope,payload_hash FROM applied WHERE id=?',(request_id,)).fetchone()
        if was:
            if was!=(scope,digest):raise GateRejected('IDEMPOTENCY_CONFLICT')
            conn.execute('COMMIT')
            return 'VERIFIED_NOOP_ALREADY_APPLIED'
        conn.execute('INSERT INTO applied VALUES(?,?,?,?)',(request_id,scope,content_class,digest))
        if fail_at=='before_commit':raise SimulatedAbort('ABORT_BEFORE_COMMIT')
        conn.execute('COMMIT')
        if fail_at=='after_commit':raise SimulatedTimeout('TIMEOUT_AFTER_COMMIT')
        return 'APPLIED_NEEDS_READBACK'
    except Exception:
        if conn.in_transaction:conn.execute('ROLLBACK')
        raise

def readback(conn,request_id):
    return conn.execute('SELECT scope,content_class,payload_hash FROM applied WHERE id=?',(request_id,)).fetchone()

results=[]
with TemporaryDirectory(prefix='auth_notion_01_sqlite_test_') as td:
 for j in range(8):
  for kind in ('normal','duplicate','timeout_after_commit','rollback_before_commit','stale_writer','cross_workspace','forbidden_party','writer_switched','readonly_attempt','uncommitted_intent'):
   name=f'{kind}-{j:02d}'
   path=Path(td)/f'{name}.sqlite'
   conn=init_db(path)
   req=f'req-{j}'
   payload=f'proof-{kind}-{j}'
   try:
    if kind=='normal':
     assert apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')=='APPLIED_NEEDS_READBACK'
     assert readback(conn,req)[2]==sha256(payload.encode()).hexdigest()
    elif kind=='duplicate':
     assert apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')=='APPLIED_NEEDS_READBACK'
     assert apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')=='VERIFIED_NOOP_ALREADY_APPLIED'
     assert conn.execute('SELECT count(*) FROM applied').fetchone()[0]==1
    elif kind=='timeout_after_commit':
     try: apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5',fail_at='after_commit')
     except SimulatedTimeout:pass
     else:raise AssertionError('Timeout not injected')
     # Real SQLite readback verifies commit; the request must not be reapplied.
     assert readback(conn,req) is not None
     assert apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')=='VERIFIED_NOOP_ALREADY_APPLIED'
     assert conn.execute('SELECT count(*) FROM applied').fetchone()[0]==1
    elif kind=='rollback_before_commit':
     try:apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5',fail_at='before_commit')
     except SimulatedAbort:pass
     else:raise AssertionError('Abort not injected')
     assert readback(conn,req) is None
     assert apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')=='APPLIED_NEEDS_READBACK'
    elif kind=='stale_writer':
     try:apply(conn,req,'mestre','mestre_only',payload,4,'lease-m-4')
     except GateRejected as e:assert str(e)=='STALE_WRITER'
     else:raise AssertionError('Stale writer accepted')
     assert readback(conn,req) is None
    elif kind=='cross_workspace':
     try:apply(conn,req,'party','party_safe',payload,5,'lease-m-5')
     except GateRejected as e:assert str(e)=='STALE_WRITER'
     else:raise AssertionError('Cross-account token accepted')
     assert readback(conn,req) is None
    elif kind=='forbidden_party':
     try:apply(conn,req,'party','mestre_only',payload,7,'lease-p-7')
     except GateRejected as e:assert str(e)=='PARTY_DENY'
     else:raise AssertionError('Master secret written to Party')
     assert readback(conn,req) is None
    elif kind=='writer_switched':
     conn.execute("UPDATE writers SET epoch=6, token='lease-m-6' WHERE scope='mestre'")
     try:apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')
     except GateRejected as e:assert str(e)=='STALE_WRITER'
     else:raise AssertionError('Old epoch accepted')
     assert apply(conn,req,'mestre','mestre_only',payload,6,'lease-m-6')=='APPLIED_NEEDS_READBACK'
    elif kind=='readonly_attempt':
     try:apply(conn,req,'mestre','mestre_only',payload,0,'')
     except GateRejected as e:assert str(e)=='STALE_WRITER'
     else:raise AssertionError('Uncredentialed write accepted')
     assert readback(conn,req) is None
    elif kind=='uncommitted_intent':
     conn.execute('BEGIN IMMEDIATE')
     conn.execute('INSERT INTO applied VALUES(?,?,?,?)',(req,'mestre','mestre_only',sha256(payload.encode()).hexdigest()))
     conn.execute('ROLLBACK') # simulates incomplete pre-crash intent
     assert readback(conn,req) is None
     assert apply(conn,req,'mestre','mestre_only',payload,5,'lease-m-5')=='APPLIED_NEEDS_READBACK'
    assert conn.execute("SELECT count(*) FROM applied WHERE scope='party'").fetchone()[0]==0
    results.append({'case':name,'family':kind,'status':'PASS','technology':'SQLite temp file TEST'})
   finally:
    conn.close()

counts=dict(Counter(x['family'] for x in results))
assert len(results)==80
summary={'type':'FAULT_INJECTION_SQLITE_LOCAL_TEST_NOT_NOTION','passed':len(results),'families':counts,'notion_calls':0,'party_writes':0,'official_writes':0,'s4_certified':False,'note':'Locally tested persistence and idempotency; does not authenticate real Notion, establish writer, or change canonical norm.'}
out=Path(__file__).resolve().parent/'AUTH_NOTION_01_SQLITE_FAULT_LAB_20261022.json'
out.write_text(json.dumps({'summary':summary,'results':results},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
