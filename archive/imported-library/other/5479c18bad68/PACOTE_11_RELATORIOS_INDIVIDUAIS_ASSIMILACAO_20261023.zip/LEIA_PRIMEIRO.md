# RPG Assimilação — 11 vídeos: síntese de coordenação e resultados TEST

**Data de corte de fontes:** 23/10/2026, America/Recife. **Contexto:** Mestre-side, operação EXISTENTE Tabletop, Android, R$0 adicional. **Total:** 11 MP4, agrupados em Lotes 01–03. **Artefatos individuais:** 11 relatórios Markdown e 11 contratos JSON de aceite, um de cada vídeo.

## Resposta à exigência do Mestre

Relatórios individuais produzidos e reconciliação com TEST36 feita. Todos os vídeos foram verificados como arquivos originais por SHA-256, e os relatórios consolidam uma análise temporal de cenas concretas com as limitações da amostragem. Todos contêm problema específico, técnica inferida (claramente rotulada), risco, alternativas gratuitas, critérios de aceite e owner.

**PENDÊNCIA IMPORTANTE E NÃO OCULTADA:** não foi produzida transcrição integral das falas, porque os 11 arquivos não têm streams de legendas e não há modelo ASR instalado para reconhecer português nesse runtime. As narrativas NÃO foram transcritas nem presumidas com base nos quadros. Para completar a análise do conteúdo oral, é preciso obter legenda autorizada, transcrição de origem ou executar uma ferramenta ASR adequada com os MP4 (sem enviar material Mestre-only a serviços externos). Não declarar essa etapa PASS. Alguns recursos citados nas cenas foram identificados por texto legível, não por fala.

## Escala de prioridade por efeito no jogo original

| Ordem | Vídeo | Entrega individual | Critério que o Mestre pode julgar |
|---:|---|---|---|
| 1 | `495943` | Painel contextual de ação e alvo na própria Arena | A seleção de unidades vem da lista real TEST36 em vez de nomes inventados. |
| 2 | `495980` | Teste de viewport arena-first e ação no mesmo campo | Em 390×844, mapa visível no primeiro viewport. |
| 3 | `496008` | Contrato de intenção e recibo com HOLD mecânico | Enviar preview contém action_type, actor_display e target_display. |
| 4 | `495967` | Roteiro de ação tática ponta-a-ponta com estado HOLD | Toque em uma ação não aplica dano sem recibo competente. |
| 5 | `495923` | Ciclo de aceite de batalha com evidência visual | Dado uma Arena TEST36 carregada, escolher unidade, ação e alvo na primeira tela. |
| 6 | `496003` | Especificação e prova de atlas 4-direções e 2 quadros | Atlas tem células consistentes em dimensões e pivô. |
| 7 | `496016` | Prova de não regressão da arena em refino visual | Grade permanece idêntica antes/depois. |
| 8 | `495950` | Integridade geométrica sob troca de camada artística | 49 casas TEST permanecem 49 depois de trocar CSS/asset. |
| 9 | `495988` | Contrato de camadas de arena e grade imutável | Renderer não altera IDs de casas. |
| 10 | `495933` | Contrato ambiente visual fail-closed | O evento ambiental pode ser renderizado sem mudar Vida/PA/posição dos tokens. |
| 11 | `495957` | Rubrica de prova de jogabilidade versus vídeo promocional | Relatório distingue ambiente visual de combate funcional. |


## Entrega física nova — prova integrada ao HTML offline existente

`prova_test36/TABLETOP_TEST36_PREVIA_ACAO_NAO_ENVIA.html` é uma cópia TEST do arquivo offline preexistente `TABLETOP_TEST36_ARENA_PRIMEIRO_OFFLINE_TEST_20261024.html`:

- Usa a lista de unidades **realmente renderizada pelo TEST36** para escolher ator e alvo (não inventa novos personagens).
- Oferece **Ataque / Defesa / Reação / Magia / Movimento** como intenções visuais de interface, todas explicitamente VLAB HOLD.
- Gera somente objeto `PREVIEW_ONLY_NOT_DISPATCHABLE` com `transmission: NOT_SENT` e `status: MECANICA_INDISPONIVEL` — não é contrato v2 oficial nem mensagem pronta para o WebSocket.
- Não altera Vida, Alma, PA, posição, rodadas, inimigos, histórico ou estado da sala, e **não faz requisição de rede** (`connect-src 'none'`).
- Adiciona interface em drawer responsivo sem substituir código original. CSP atualizado por SHA-256 dos dois novos blocos inline. Sem API, credenciais, login, origem VLAB, conteúdo de Party ou dados privados.
- Teste de navegador em Chromium Linux emulado nas resoluções **360×740, 390×844 e 412×915**: 30/30 verificações direcionadas PASS (10 por resolução), incluindo três unidades originais, 49/49 casas, geração de intenção, ação/alvo, HOLD, invariância de unidades/rodada, zero requests, zero erros JS e botão de fechar. **Não é teste no Android físico.**

**Utilidade concreta:** permite ao Mestre ver no próprio tabuleiro a primeira camada de seleção ator→alvo→ação, e entrega aos desenvolvedores um contrato funcional de UX e teste, SEM falsificar regra mecânica. Não publicar como TEST37 nem usar em produção.

## Onde a pesquisa deve parar e a programação começar

O próximo trabalho competente é **conectar o seletor de ação/ator/alvo à operação de sala já existente** através da matriz PESQ015, mas SOMENTE após writer verificado, identidade server-side, protocolo v2 escolhido, pacote Codex acessível e ABI autorizada. A prova desta rodada não implementa esses componentes. Os 11 contratos independentes funcionam como lista de aceites, não ordens de 11 implementações paralelas.

### Prioridades

**P0 — Jogabilidade e clareza:** 495943, 495980, 496008, 495967 e 495923. A primeira batalha deve ter seleção de unidade/alvo/ação, feedback e motivo de HOLD ou recibo VLAB.

**P1/P2 — Arte e cenários:** 496003, 496016, 495950, 495988. Variações de sprites, terrenos, oclusão e layout depois de uma ação de combate comprovada e sempre preservando o grid.

**P3/P4 — Adições não bloqueantes:** 495933 (clima sem modificador mecânico improvisado) e 495957 (rapidez promocional não é critério de qualidade).

**Não fazer:** três backends, novo VLAB JS, cópia de sprites do vídeo, gastar em PixelLab/Claude/Mixamo, transformar batalha do Assimilação em Pokémon/idle/caminhada, reiniciar Codex, alterar Party, O Primeiro, gh-pages ou main.

## Alternativas gratuitas com status

| Necessidade | Rota preferida | Prova atual | Observação |
|---|---|---|---|
| UI de combate | HTML/CSS/JS do TEST36 | Drawer de ação real TEST, 30/30 Chromium | Mecânica VLAB HOLD |
| Sprite e atlas | PNG autoral + Pillow; Kenney CC0 | Pipeline Lote01 em Chromium | Arte final não homologada |
| Mapas 2D | Editor TEST36 e assets com licença | Modo Arena Primeiro Lote02 | Android físico pendente |
| Editor de pixel art | Piskel Web | NÃO testado no Android | README declara sem suporte móvel |
| Rig/animação 3D | Mixamo + exportação 2D, se necessário | Regras de acesso documentadas, não usado | Mais complexo que sprite autoral |
| Renderização 2D otimizada | Phaser (MIT) | Fonte de licença checada; não instalado | Adotar só mediante benchmark |
| Editor gráfico geral | Godot Android já baixado segundo Mestre | Só capacidade documental, no aparelho ainda sem prova | Não migrar jogo existente |

Fontes primárias: https://kenney.nl/assets/roguelike-rpg-pack ; https://github.com/piskelapp/piskel ; https://docs.godotengine.org/en/4.6/tutorials/editor/using_the_android_editor.html ; https://phaser.io/download/license ; https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html

## PSV / sucessão

**LAST-VERIFIED:** 11 MP4 íntegros, 11 relatórios, 11 contratos e demonstração seletor de ação executada com 30/30 verificações em Chromium; Notion PESQ015/RUN013 reaberto anteriormente nesta rodada. **FIRST-PENDING:** transcrição/narração completa dos MP4, teste físico no Android, decisão/ABI VLAB, backend role-safe, pacote Codex e integração do comando. **NEXT:** Desenvolvedor auditar essa prova e incorporá-la no código dele se autorizada, testando ação real sem fórmulas paralelas; Pesquisador auditar fronteira e privacy antes de promoção. **NO-REPEAT:** não reabrir Lotes 01–03 sem nova evidência de fala/código e não reiniciar análises vagas. **NAC-PASS proporcional:** PASS artefatos de relatório, rastreabilidade, experimento UI seguro; HOLD transcrição integral, mecânicas, Android e servidor oficial.
