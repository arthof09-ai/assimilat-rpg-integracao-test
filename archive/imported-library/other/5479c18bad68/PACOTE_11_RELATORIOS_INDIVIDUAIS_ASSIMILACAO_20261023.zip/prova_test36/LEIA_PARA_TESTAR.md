# Prova de seleção de ação — somente TEST36, não oficial

Arquivo: `TABLETOP_TEST36_PREVIA_ACAO_NAO_ENVIA.html`.

No navegador Android compatível com HTML local, abra o arquivo e toque **⚔ Ação TEST**. Selecione a unidade ator, outra unidade alvo e a ação **Ataque / Defesa / Reação / Magia / Movimento**. Toque **Gerar intenção TEST**. O JSON de prévia aparecerá com `transmission=NOT_SENT` e `MECANICA_INDISPONIVEL`.

**Nada é enviado nem calculado.** Não representa multiplayer, dano ou PA reais. Não adicione personagens oficiais, fichas ou segredos ao protótipo.

O Chromium emulado foi testado com `page.set_content`; abertura `file://` e comportamento no Android físico NÃO foram validados.

Para reproduzir o experimento automatizado, ver `RESULTADOS_CHROMIUM.json`, `HASHES_FONTE.json` e os arquivos CSS/JS isolados. O script de teste de montagem está no diretório de scripts do pacote.
