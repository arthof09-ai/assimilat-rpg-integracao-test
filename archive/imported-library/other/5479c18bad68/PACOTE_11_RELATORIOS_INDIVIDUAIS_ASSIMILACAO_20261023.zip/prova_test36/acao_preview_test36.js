/* EXTENSÃO TEST ISOLADA — apenas PREVIEW de intenção de combate; nenhum comando enviado. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const opener=$('actionPreviewToggle'), drawer=$('actionPreviewDrawer'),actor=$('previewActor'),target=$('previewTarget');
const action=$('previewAction'), btn=$('previewBuild'),status=$('previewStatus'),raw=$('previewJSON');
let lastCommand=0;
const names=()=>[...document.querySelectorAll('#unitList .unitBtn strong')].map(x=>x.textContent.trim()).filter(Boolean).slice(0,30);
function populate(){
 const list=names(),a=actor.value,t=target.value;
 for(const [node,old] of [[actor,a],[target,t]]){
  node.replaceChildren();for(const name of list){const option=document.createElement('option');option.value=name;option.textContent=name;node.append(option)}
  if(list.includes(old))node.value=old;
 }
 if(list.length>1&&actor.value===target.value) target.value=list.find(x=>x!==actor.value)||'';
 status.textContent=list.length?'Aguardando seleção. Prévia não envia comandos.':'Nenhuma unidade TEST disponível.';
 btn.disabled=list.length<2;
}
function preview(){
 const a=actor.value,t=target.value,act=action.value;
 if(!a||!t||a===t||!names().includes(a)||!names().includes(t)){
  status.textContent='Selecione duas unidades diferentes da Arena TEST.';raw.textContent='';return;
 }
 const rev=$('roundCount')?.textContent?.trim()||null;
 // Não usar formato de comando válido: impedir promoção acidental de uma prévia para ação de rede.
 const candidate={type:'PREVIEW_ONLY_NOT_DISPATCHABLE',schema_version:'assim.tabletop.battle.intent.preview.v0',
 preview_id:'TEST-PREVIEW-'+(++lastCommand), actor_display:a,target_display:t,action_ui:act,
 scene_round_label:rev,actor_authenticated_id:null,server_revision:null,
 status:'MECANICA_INDISPONIVEL',transmission:'NOT_SENT',mechanical_result:null,
 safety:'Nenhum dano, Vida, Alma, PA, iniciativa, turno ou regra foram calculados.'};
 raw.textContent=JSON.stringify(candidate,null,2);
 status.textContent='Prévia gerada — MECANICA_INDISPONIVEL / NÃO ENVIADA.';
}
opener.addEventListener('click',()=>{const active=drawer.hidden;drawer.hidden=!active;opener.setAttribute('aria-expanded',String(active));if(active)populate();});
actor.addEventListener('change',()=>{if(actor.value===target.value){const other=names().find(x=>x!==actor.value);if(other)target.value=other;}});
btn.addEventListener('click',preview);
$('previewRefresh').addEventListener('click',populate);
const units=$('unitList');if(units)new MutationObserver(()=>{if(!drawer.hidden)populate()}).observe(units,{childList:true,subtree:false});
})();
