# Relatório técnico-científico individual 496003 — Produção de assets e Mixamo — pipeline responsável de animação

**Projeto:** RPG Assimilação / Tabletop, MESTRE-SIDE. **Classificação:** auditoria visual aprofundada e especificação de implementação, não transcrição de narração ou certificação do produto do vídeo. **Prioridade:** P2: personagem animado com licença e atlas.

## 1 — Fonte, integridade e limites da pesquisa

`496003.mp4` · 47min38s · 135.158.768 bytes · SHA-256 `5b2cb496cc84e504f7eb7a76d5d4f069f80f6aba1bbd71c1c20ece652df06494`

O MP4 original foi localizado e confirmado por hash nesta nova rodada. A análise temporal abaixo consolida inspeções diretas de quadros realizadas nos Lotes 01–03 e conferência dos respectivos dossiês, com identificação dos quadros mais informativos. **Faixas são intervalos aproximados observáveis, não frases citadas do narrador nem uma anotação de cada segundo da gravação.** Audio `aac` presente; legenda embutida: **não**.

**Estado da fala:** PENDENTE DE TRANSCRIÇÃO CONFIÁVEL. Não há no ambiente desta rodada pesos de um modelo ASR local nem legenda embutida no MP4. Não inventar declarações, ferramentas mencionadas apenas oralmente ou custos informados verbalmente. O vídeo contém áudio, mas isso não autoriza presumir seu conteúdo. Qualquer legenda/texto efetivamente legível no frame está descrito como tela e não como transcrição.

**Pergunta de pesquisa própria:** como aproveitar *sprites, poses, modelagem 3d, mixamo e correções iterativas* para acelerar o **combate tático multiplayer do RPG Assimilação**, sem criar um jogo substituto?

## 2 — Reconstrução cronológica por evidência de imagem

| Janela do vídeo | Demonstração efetivamente observável |
|---|---|
| 00:00–09:00 | Criação de imagens de personagens/recursos de UI com prompts e variações visuais. |
| 09:00–15:30 | Ensaios de poses e personagens, revisão de resultados. |
| ~16:04 | Tela identificável Mixamo para rigging/animação 3D. |
| 17:16–19:38 | Tentativas de transformar poses/modelos em quadros e corrigir sprite sheets. |
| 27:59–30:22 | Editor tridimensional, objetos posicionados e testes. |
| 31:33–35:00 | Tabuleiro colorido/protótipo com UI/peças. |
| 36:19–44:39 | Código, correções e inspeção; não é homologação de combate. |

**Interpretação sustentada pelas imagens:** Pipeline repetível de assets com consistência de direção e licença é mais importante que escolher gerador caro.

**O que o vídeo não permite concluir:** não há acesso ao código original, execução independente da aplicação do autor, logs/commits correspondentes, licenças dos assets, medição de custo real nem validação de três aparelhos Android conectados. Uma animação aparentemente fluida em vídeo comprimido não é benchmark de FPS no nosso celular. A existência de menu de login também não é prova de backend autenticado.

## 3 — Decomposição de engenharia aplicável ao RPG original

**Requisito funcional prioritário:** Especificação e prova de atlas 4-direções e 2 quadros.

1. Definir contrato de atlas 4 direções x quadros com pivô, escala, transparência e ID de skin.
2. Tratar Mixamo como opção gratuita condicionada a conta/requisitos 3D, sem obrigatoriedade.
3. Testar sprite 2D no mesmo grid e em aparelhos Android antes de ampliar elenco.

**Fronteira de autoridade:** a interface controla intenção/seleção/apresentação; o servidor competente controla sala/identidade/revisões/recibos/filtro role-safe; o VLAB Python autorizado decide custos, acertos, reações, Vida, Alma, PA, defesa e demais consequências. Tudo isso permanece sujeito aos gates canônicos. Enquanto não houver ABI, mostrar `MECANICA_INDISPONIVEL` e jamais aplicar um resultado numérico inventado.

**Risco específico a evitar:** Sprites incoerentes gerados individualmente e arquivo sem licença comprometem segurança jurídica e visual.

**Hipótese técnica para teste:** essa função poderá ser acrescentada como componente superficial ou adaptador ao bundle TEST36, sem alterar geometria da grade e sem desenvolver segundo motor. A hipótese só se torna verificada quando ocorrer execução de código com critérios de aceite abaixo.

## 4 — Ferramentas encontradas, capacidade de substituição e custo

**Ferramentas/abordagens que aparecem nas evidências de vídeo:**

- **Adobe Mixamo visível**
- **Editor 3D não identificado com certeza**
- **Geradores de imagem sem provedor único verificado**

**Alternativa sob as restrições do Mestre:** Atlas próprio Pillow e CC0 Kenney testados em Lote01; Mixamo livre com Adobe ID mas não testado neste ambiente.

**Auditoria de direitos:** nenhum código, mapa, personagem, áudio ou screenshot do autor foi transplantado ao TEST36. Assets Kenney Roguelike/RPG Pack possuem declaração CC0 na página oficial; Piskel registra ausência de suporte móvel oficial; Godot possui editor Android mas UX de telefone limitada; Phaser é MIT. Essas fontes oferecem rotas possíveis, não demonstram que a estética ou integração final já existe. Mixamo, quando relevante, exige comprovação dos direitos do modelo utilizado e fluxo próprio para exportar a animação. Se a alternativa requer ferramenta adicional e não foi executada, classificar como PROPOSTA ou PENDENTE, jamais como FUNCIONAL.

## 5 — Comparação estrita com a Arena TEST36 existente

**Baseline recuperado:** `TABLETOP_SITE_SINTETICO_TEST36_CANDIDATE.zip`, não o site público TEST32. A Arena já dispõe de mapa, 49 células em cena padrão, edição de unidades, rodada visual DEMO, cliente de sala sintética e ensaios de recibo. TEST36 não traz uma execução oficial de ataque/defesa/magia nem VLAB autenticado; isso é confirmado pela auditoria de código, não é uma falha atribuída ao autor do vídeo. O modo Arena Primeiro já diminuiu a distância do mapa à primeira tela de celular em cópia TEST, sem publicação.

**Definição de ganho mensurável para este vídeo:** ao abrir a mesma Arena, o Mestre deve conseguir notar e testar **especificação e prova de atlas 4-direções e 2 quadros** com origem de dados explícita. Se não houver ação ou diferença observável, classificar a alteração como infraestrutura/arte TEST e não como progresso de combate.

| Critério | Estado anterior TEST36 | Estado de aceite |
|---|---|---|
| Identidade Mestre/Party | Perfis DEMO, sem autenticação | Papel vem de servidor autorizado; fora disso DEMO visível |
| Mecânica | Sem recibo VLAB oficial | Resultado VLAB certificado ou HOLD, nunca fórmula improvisada |
| Visual/experiência | Editor e bancada sintética | Especificação e prova de atlas 4-direções e 2 quadros reproduzível na própria Arena |
| Android | Chromium com viewport emulado | Chrome Android físico precisa de prova separada |
| Segurança | Client checks/fixtures | Filtro por papel no servidor antes dos bytes chegarem à player |

## 6 — Entregável individual pronto para implementação

**Arquivo de contrato:** `contratos/VID_496003_ACEITE.json`, integrante do pacote de relatórios. Esse contrato identifica fonte/hashes, proprietário competente, escopo, aceites e PROIBIÇÕES. É uma **especificação verificável e roteável**, não código já integrado para todos os 11 vídeos.

**Critérios de aceite específicos:**

- [ ] Atlas tem células consistentes em dimensões e pivô.
- [ ] A troca de quadro não muda célula lógica no TEST36.
- [ ] Licença, origem e versão de cada PNG são arquivadas.

**Plano de execução de risco mínimo:**

1. Reabrir o último RUN canônico do Desenvolvedor e obter writer/epoch atual, sem confiar no TEST36 como eternamente último.
2. Executar teste RED que represente o requisito concreto descrito; preservar hash do baseline.
3. Construir prova numa cópia TEST sem alterar main, gh-pages, VLAB, Party ou laboratório de outro executor.
4. Reexecutar o teste, documentar captura ANTES→DEPOIS e quaisquer regressões da grade/unidades.
5. Confrontar o protocolo com PESQ015/Codex quando houver arquivos reais; fazer promoção só após gate NAC-PASS.

**Critério de parada legítimo:** ausência de writer competente, ABI autorizada ou infraestrutura Cloudflare/Android; nesses casos o bloqueio específico fica HOLD e trabalho independente de UI/contrato segue permitido, sem mentira de funcionalidade mecânica.

## 7 — Parecer editorial e de coordenação

**Valor para o produto:** P2: personagem animado com licença e atlas. O objetivo não é reproduzir o vídeo ou seu jogo, e sim acrescentar ao Assimilação o comportamento selecionado sem perder o compromisso com regras, permissões, durabilidade e Android.

**Verificado:** vídeo original/hashes e cenas visuais temporais documentadas; existência de mecanismos TEST de edição/viewport; alternativas gratuitas com fontes oficiais citadas abaixo. **Inferido:** técnica interna exata do autor e facilidade de adaptação. **Proposto:** contrato e testes de aceite. **Pendente:** fala integral, código do autor, teste Android físico e incorporação da função no Tabletop oficial.

**LAST-VERIFIED:** arquivo `496003.mp4` e auditoria anterior reaberta. **FIRST-PENDING:** teste executável específico `Especificação e prova de atlas 4-direções e 2 quadros` ou validação de fala que altere o parecer. **NEXT:** aplicar contrato via Desenvolvedor competente, confrontar versão atual, executar teste e preservar recibo. **NO-REPEAT:** não reexecutar pesquisa só para aumentar relatório, não criar outro sistema nem ressuscitar som rejeitado.

## 8 — Fontes públicas de licenciamento/capacidade (não confundidas com a origem do vídeo)

- Kenney — https://kenney.nl/assets/roguelike-rpg-pack
- Piskel, suporte móvel — https://github.com/piskelapp/piskel
- Godot editor Android — https://docs.godotengine.org/en/4.6/tutorials/editor/using_the_android_editor.html
- Phaser licença — https://phaser.io/download/license
- Mixamo FAQ (aplicável quando vídeo exibe Mixamo) — https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html

**NAC-PASS proporcional:** PASS documental da fonte, hash, análise visual rastreada e contrato de aceite; HOLD fala integral, implementação individual no TEST36, combate oficial, Cloudflare real e validação física no Android.
