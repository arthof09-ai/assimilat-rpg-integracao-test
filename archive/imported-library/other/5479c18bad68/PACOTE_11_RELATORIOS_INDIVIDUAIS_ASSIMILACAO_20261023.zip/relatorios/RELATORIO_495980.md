# Relatório técnico-científico individual 495980 — Dunloc Online — arena-first, HUD e hierarquia visual 2.5D

**Projeto:** RPG Assimilação / Tabletop, MESTRE-SIDE. **Classificação:** auditoria visual aprofundada e especificação de implementação, não transcrição de narração ou certificação do produto do vídeo. **Prioridade:** P0: UX Android e combate na primeira tela.

## 1 — Fonte, integridade e limites da pesquisa

`495980.mp4` · 39min25s · 77.349.797 bytes · SHA-256 `c515556003432c8e3faa0b9e2c2a392324115708841d5091ff64beef93183f04`

O MP4 original foi localizado e confirmado por hash nesta nova rodada. A análise temporal abaixo consolida inspeções diretas de quadros realizadas nos Lotes 01–03 e conferência dos respectivos dossiês, com identificação dos quadros mais informativos. **Faixas são intervalos aproximados observáveis, não frases citadas do narrador nem uma anotação de cada segundo da gravação.** Audio `aac` presente; legenda embutida: **não**.

**Estado da fala:** PENDENTE DE TRANSCRIÇÃO CONFIÁVEL. Não há no ambiente desta rodada pesos de um modelo ASR local nem legenda embutida no MP4. Não inventar declarações, ferramentas mencionadas apenas oralmente ou custos informados verbalmente. O vídeo contém áudio, mas isso não autoriza presumir seu conteúdo. Qualquer legenda/texto efetivamente legível no frame está descrito como tela e não como transcrição.

**Pergunta de pesquisa própria:** como aproveitar *ambientes, masmorras, personagem, login e combate 2.5d* para acelerar o **combate tático multiplayer do RPG Assimilação**, sem criar um jogo substituto?

## 2 — Reconstrução cronológica por evidência de imagem

| Janela do vídeo | Demonstração efetivamente observável |
|---|---|
| 01:40–06:00 | Áreas exteriores com terreno/vegetação, camadas e personagem sob HUD. |
| 06:30–12:00 | Interior de masmorra, iluminação e objetos com oclusão/efeitos. |
| 14:00–18:00 | Login e seleção de personagem do Dunloc Online; UI não certifica autenticação. |
| 18:00–23:00 | Sprites e quadros visíveis; cidade, inventário e barra de habilidades. |
| 25:00–31:00 | Cenas de combate de masmorra e indicadores de ação. |
| 31:00–39:25 | Campo, HUD, minimapa, equipamento e navegação contínua. |

**Interpretação sustentada pelas imagens:** A arena deve ocupar a primeira tela e as ações devem estar ao alcance do polegar.

**O que o vídeo não permite concluir:** não há acesso ao código original, execução independente da aplicação do autor, logs/commits correspondentes, licenças dos assets, medição de custo real nem validação de três aparelhos Android conectados. Uma animação aparentemente fluida em vídeo comprimido não é benchmark de FPS no nosso celular. A existência de menu de login também não é prova de backend autenticado.

## 3 — Decomposição de engenharia aplicável ao RPG original

**Requisito funcional prioritário:** Teste de viewport arena-first e ação no mesmo campo.

1. Conservar Modo Arena Primeiro aprovado somente em TEST; agregar seleção de ator/alvo/ação compacta.
2. Criar painel contextual recolhível sem ocultar tabuleiro e com acessibilidade.
3. Projetar módulos de camadas 2.5D depois de validar ação e alvo sem quebrar o grid.

**Fronteira de autoridade:** a interface controla intenção/seleção/apresentação; o servidor competente controla sala/identidade/revisões/recibos/filtro role-safe; o VLAB Python autorizado decide custos, acertos, reações, Vida, Alma, PA, defesa e demais consequências. Tudo isso permanece sujeito aos gates canônicos. Enquanto não houver ABI, mostrar `MECANICA_INDISPONIVEL` e jamais aplicar um resultado numérico inventado.

**Risco específico a evitar:** Falso login de demo ser chamado segurança; bela UI não comprova role-based filtering server-side.

**Hipótese técnica para teste:** essa função poderá ser acrescentada como componente superficial ou adaptador ao bundle TEST36, sem alterar geometria da grade e sem desenvolver segundo motor. A hipótese só se torna verificada quando ocorrer execução de código com critérios de aceite abaixo.

## 4 — Ferramentas encontradas, capacidade de substituição e custo

**Ferramentas/abordagens que aparecem nas evidências de vídeo:**

- **Ferramenta de sprites vista em tela, marca não confirmada**
- **Projeto Dunloc Online, código proprietário não disponibilizado**

**Alternativa sob as restrições do Mestre:** HTML/CSS/JS + assets originais, sem copiar Dunloc ou migrar engine.

**Auditoria de direitos:** nenhum código, mapa, personagem, áudio ou screenshot do autor foi transplantado ao TEST36. Assets Kenney Roguelike/RPG Pack possuem declaração CC0 na página oficial; Piskel registra ausência de suporte móvel oficial; Godot possui editor Android mas UX de telefone limitada; Phaser é MIT. Essas fontes oferecem rotas possíveis, não demonstram que a estética ou integração final já existe. Mixamo, quando relevante, exige comprovação dos direitos do modelo utilizado e fluxo próprio para exportar a animação. Se a alternativa requer ferramenta adicional e não foi executada, classificar como PROPOSTA ou PENDENTE, jamais como FUNCIONAL.

## 5 — Comparação estrita com a Arena TEST36 existente

**Baseline recuperado:** `TABLETOP_SITE_SINTETICO_TEST36_CANDIDATE.zip`, não o site público TEST32. A Arena já dispõe de mapa, 49 células em cena padrão, edição de unidades, rodada visual DEMO, cliente de sala sintética e ensaios de recibo. TEST36 não traz uma execução oficial de ataque/defesa/magia nem VLAB autenticado; isso é confirmado pela auditoria de código, não é uma falha atribuída ao autor do vídeo. O modo Arena Primeiro já diminuiu a distância do mapa à primeira tela de celular em cópia TEST, sem publicação.

**Definição de ganho mensurável para este vídeo:** ao abrir a mesma Arena, o Mestre deve conseguir notar e testar **teste de viewport arena-first e ação no mesmo campo** com origem de dados explícita. Se não houver ação ou diferença observável, classificar a alteração como infraestrutura/arte TEST e não como progresso de combate.

| Critério | Estado anterior TEST36 | Estado de aceite |
|---|---|---|
| Identidade Mestre/Party | Perfis DEMO, sem autenticação | Papel vem de servidor autorizado; fora disso DEMO visível |
| Mecânica | Sem recibo VLAB oficial | Resultado VLAB certificado ou HOLD, nunca fórmula improvisada |
| Visual/experiência | Editor e bancada sintética | Teste de viewport arena-first e ação no mesmo campo reproduzível na própria Arena |
| Android | Chromium com viewport emulado | Chrome Android físico precisa de prova separada |
| Segurança | Client checks/fixtures | Filtro por papel no servidor antes dos bytes chegarem à player |

## 6 — Entregável individual pronto para implementação

**Arquivo de contrato:** `contratos/VID_495980_ACEITE.json`, integrante do pacote de relatórios. Esse contrato identifica fonte/hashes, proprietário competente, escopo, aceites e PROIBIÇÕES. É uma **especificação verificável e roteável**, não código já integrado para todos os 11 vídeos.

**Critérios de aceite específicos:**

- [ ] Em 390×844, mapa visível no primeiro viewport.
- [ ] Ação/alvo acessível com um toque.
- [ ] Zero promessa de login/servidor real.

**Plano de execução de risco mínimo:**

1. Reabrir o último RUN canônico do Desenvolvedor e obter writer/epoch atual, sem confiar no TEST36 como eternamente último.
2. Executar teste RED que represente o requisito concreto descrito; preservar hash do baseline.
3. Construir prova numa cópia TEST sem alterar main, gh-pages, VLAB, Party ou laboratório de outro executor.
4. Reexecutar o teste, documentar captura ANTES→DEPOIS e quaisquer regressões da grade/unidades.
5. Confrontar o protocolo com PESQ015/Codex quando houver arquivos reais; fazer promoção só após gate NAC-PASS.

**Critério de parada legítimo:** ausência de writer competente, ABI autorizada ou infraestrutura Cloudflare/Android; nesses casos o bloqueio específico fica HOLD e trabalho independente de UI/contrato segue permitido, sem mentira de funcionalidade mecânica.

## 7 — Parecer editorial e de coordenação

**Valor para o produto:** P0: UX Android e combate na primeira tela. O objetivo não é reproduzir o vídeo ou seu jogo, e sim acrescentar ao Assimilação o comportamento selecionado sem perder o compromisso com regras, permissões, durabilidade e Android.

**Verificado:** vídeo original/hashes e cenas visuais temporais documentadas; existência de mecanismos TEST de edição/viewport; alternativas gratuitas com fontes oficiais citadas abaixo. **Inferido:** técnica interna exata do autor e facilidade de adaptação. **Proposto:** contrato e testes de aceite. **Pendente:** fala integral, código do autor, teste Android físico e incorporação da função no Tabletop oficial.

**LAST-VERIFIED:** arquivo `495980.mp4` e auditoria anterior reaberta. **FIRST-PENDING:** teste executável específico `Teste de viewport arena-first e ação no mesmo campo` ou validação de fala que altere o parecer. **NEXT:** aplicar contrato via Desenvolvedor competente, confrontar versão atual, executar teste e preservar recibo. **NO-REPEAT:** não reexecutar pesquisa só para aumentar relatório, não criar outro sistema nem ressuscitar som rejeitado.

## 8 — Fontes públicas de licenciamento/capacidade (não confundidas com a origem do vídeo)

- Kenney — https://kenney.nl/assets/roguelike-rpg-pack
- Piskel, suporte móvel — https://github.com/piskelapp/piskel
- Godot editor Android — https://docs.godotengine.org/en/4.6/tutorials/editor/using_the_android_editor.html
- Phaser licença — https://phaser.io/download/license
- Mixamo FAQ (aplicável quando vídeo exibe Mixamo) — https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html

**NAC-PASS proporcional:** PASS documental da fonte, hash, análise visual rastreada e contrato de aceite; HOLD fala integral, implementação individual no TEST36, combate oficial, Cloudflare real e validação física no Android.
