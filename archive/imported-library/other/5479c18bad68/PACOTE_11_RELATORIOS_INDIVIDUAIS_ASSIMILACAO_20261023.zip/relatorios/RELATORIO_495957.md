# Relatório técnico-científico individual 495957 — RPG em cinco horas — limites de demonstração promocional

**Projeto:** RPG Assimilação / Tabletop, MESTRE-SIDE. **Classificação:** auditoria visual aprofundada e especificação de implementação, não transcrição de narração ou certificação do produto do vídeo. **Prioridade:** P4: referência de ritmo, não stack.

## 1 — Fonte, integridade e limites da pesquisa

`495957.mp4` · 0min35s · 2.470.627 bytes · SHA-256 `b5433fa08f0c62b3a61ccbe35ef11ed85af3a413e72ec4ef99b53ef9015f8ec8`

O MP4 original foi localizado e confirmado por hash nesta nova rodada. A análise temporal abaixo consolida inspeções diretas de quadros realizadas nos Lotes 01–03 e conferência dos respectivos dossiês, com identificação dos quadros mais informativos. **Faixas são intervalos aproximados observáveis, não frases citadas do narrador nem uma anotação de cada segundo da gravação.** Audio `aac` presente; legenda embutida: **não**.

**Estado da fala:** PENDENTE DE TRANSCRIÇÃO CONFIÁVEL. Não há no ambiente desta rodada pesos de um modelo ASR local nem legenda embutida no MP4. Não inventar declarações, ferramentas mencionadas apenas oralmente ou custos informados verbalmente. O vídeo contém áudio, mas isso não autoriza presumir seu conteúdo. Qualquer legenda/texto efetivamente legível no frame está descrito como tela e não como transcrição.

**Pergunta de pesquisa própria:** como aproveitar *demo 3d com alegação de velocidade de produção* para acelerar o **combate tático multiplayer do RPG Assimilação**, sem criar um jogo substituto?

## 2 — Reconstrução cronológica por evidência de imagem

| Janela do vídeo | Demonstração efetivamente observável |
|---|---|
| 00:00–00:10 | Texto promocional com alegação de criação de RPG em cinco horas. |
| 00:12–00:25 | Menu, cena 3D, gramado, árvores e personagens. |
| 00:25–00:35 | Trechos finais da demo sem exposição de código, banco, multiplayer ou motor. |

**Interpretação sustentada pelas imagens:** Separar protótipo audiovisual rápido de produto confiável; não aceitar prazo como teste.

**O que o vídeo não permite concluir:** não há acesso ao código original, execução independente da aplicação do autor, logs/commits correspondentes, licenças dos assets, medição de custo real nem validação de três aparelhos Android conectados. Uma animação aparentemente fluida em vídeo comprimido não é benchmark de FPS no nosso celular. A existência de menu de login também não é prova de backend autenticado.

## 3 — Decomposição de engenharia aplicável ao RPG original

**Requisito funcional prioritário:** Rubrica de prova de jogabilidade versus vídeo promocional.

1. Criar vídeo de 30–60s da Arena do Mestre mostrando ação real e não apenas cenário.
2. Separar evidência: vídeo de tela, log/recibo de ação e auditoria de segurança.
3. Adotar versões pequenas com um efeito visível por lote.

**Fronteira de autoridade:** a interface controla intenção/seleção/apresentação; o servidor competente controla sala/identidade/revisões/recibos/filtro role-safe; o VLAB Python autorizado decide custos, acertos, reações, Vida, Alma, PA, defesa e demais consequências. Tudo isso permanece sujeito aos gates canônicos. Enquanto não houver ABI, mostrar `MECANICA_INDISPONIVEL` e jamais aplicar um resultado numérico inventado.

**Risco específico a evitar:** Migrar para 3D e perder a identidade tática 2.5D sem ter resolvido mecânica.

**Hipótese técnica para teste:** essa função poderá ser acrescentada como componente superficial ou adaptador ao bundle TEST36, sem alterar geometria da grade e sem desenvolver segundo motor. A hipótese só se torna verificada quando ocorrer execução de código com critérios de aceite abaixo.

## 4 — Ferramentas encontradas, capacidade de substituição e custo

**Ferramentas/abordagens que aparecem nas evidências de vídeo:**

- **Ferramentas 3D não comprovadas individualmente na gravação**

**Alternativa sob as restrições do Mestre:** Manter stack web; produzir demonstrações curtas do próprio TEST36 com rastros.

**Auditoria de direitos:** nenhum código, mapa, personagem, áudio ou screenshot do autor foi transplantado ao TEST36. Assets Kenney Roguelike/RPG Pack possuem declaração CC0 na página oficial; Piskel registra ausência de suporte móvel oficial; Godot possui editor Android mas UX de telefone limitada; Phaser é MIT. Essas fontes oferecem rotas possíveis, não demonstram que a estética ou integração final já existe. Mixamo, quando relevante, exige comprovação dos direitos do modelo utilizado e fluxo próprio para exportar a animação. Se a alternativa requer ferramenta adicional e não foi executada, classificar como PROPOSTA ou PENDENTE, jamais como FUNCIONAL.

## 5 — Comparação estrita com a Arena TEST36 existente

**Baseline recuperado:** `TABLETOP_SITE_SINTETICO_TEST36_CANDIDATE.zip`, não o site público TEST32. A Arena já dispõe de mapa, 49 células em cena padrão, edição de unidades, rodada visual DEMO, cliente de sala sintética e ensaios de recibo. TEST36 não traz uma execução oficial de ataque/defesa/magia nem VLAB autenticado; isso é confirmado pela auditoria de código, não é uma falha atribuída ao autor do vídeo. O modo Arena Primeiro já diminuiu a distância do mapa à primeira tela de celular em cópia TEST, sem publicação.

**Definição de ganho mensurável para este vídeo:** ao abrir a mesma Arena, o Mestre deve conseguir notar e testar **rubrica de prova de jogabilidade versus vídeo promocional** com origem de dados explícita. Se não houver ação ou diferença observável, classificar a alteração como infraestrutura/arte TEST e não como progresso de combate.

| Critério | Estado anterior TEST36 | Estado de aceite |
|---|---|---|
| Identidade Mestre/Party | Perfis DEMO, sem autenticação | Papel vem de servidor autorizado; fora disso DEMO visível |
| Mecânica | Sem recibo VLAB oficial | Resultado VLAB certificado ou HOLD, nunca fórmula improvisada |
| Visual/experiência | Editor e bancada sintética | Rubrica de prova de jogabilidade versus vídeo promocional reproduzível na própria Arena |
| Android | Chromium com viewport emulado | Chrome Android físico precisa de prova separada |
| Segurança | Client checks/fixtures | Filtro por papel no servidor antes dos bytes chegarem à player |

## 6 — Entregável individual pronto para implementação

**Arquivo de contrato:** `contratos/VID_495957_ACEITE.json`, integrante do pacote de relatórios. Esse contrato identifica fonte/hashes, proprietário competente, escopo, aceites e PROIBIÇÕES. É uma **especificação verificável e roteável**, não código já integrado para todos os 11 vídeos.

**Critérios de aceite específicos:**

- [ ] Relatório distingue ambiente visual de combate funcional.
- [ ] Sem alegar tempo total de criação com base no corte do vídeo.
- [ ] Vídeo de aceitação precisa mostrar clique, resultado e origem mecânica.

**Plano de execução de risco mínimo:**

1. Reabrir o último RUN canônico do Desenvolvedor e obter writer/epoch atual, sem confiar no TEST36 como eternamente último.
2. Executar teste RED que represente o requisito concreto descrito; preservar hash do baseline.
3. Construir prova numa cópia TEST sem alterar main, gh-pages, VLAB, Party ou laboratório de outro executor.
4. Reexecutar o teste, documentar captura ANTES→DEPOIS e quaisquer regressões da grade/unidades.
5. Confrontar o protocolo com PESQ015/Codex quando houver arquivos reais; fazer promoção só após gate NAC-PASS.

**Critério de parada legítimo:** ausência de writer competente, ABI autorizada ou infraestrutura Cloudflare/Android; nesses casos o bloqueio específico fica HOLD e trabalho independente de UI/contrato segue permitido, sem mentira de funcionalidade mecânica.

## 7 — Parecer editorial e de coordenação

**Valor para o produto:** P4: referência de ritmo, não stack. O objetivo não é reproduzir o vídeo ou seu jogo, e sim acrescentar ao Assimilação o comportamento selecionado sem perder o compromisso com regras, permissões, durabilidade e Android.

**Verificado:** vídeo original/hashes e cenas visuais temporais documentadas; existência de mecanismos TEST de edição/viewport; alternativas gratuitas com fontes oficiais citadas abaixo. **Inferido:** técnica interna exata do autor e facilidade de adaptação. **Proposto:** contrato e testes de aceite. **Pendente:** fala integral, código do autor, teste Android físico e incorporação da função no Tabletop oficial.

**LAST-VERIFIED:** arquivo `495957.mp4` e auditoria anterior reaberta. **FIRST-PENDING:** teste executável específico `Rubrica de prova de jogabilidade versus vídeo promocional` ou validação de fala que altere o parecer. **NEXT:** aplicar contrato via Desenvolvedor competente, confrontar versão atual, executar teste e preservar recibo. **NO-REPEAT:** não reexecutar pesquisa só para aumentar relatório, não criar outro sistema nem ressuscitar som rejeitado.

## 8 — Fontes públicas de licenciamento/capacidade (não confundidas com a origem do vídeo)

- Kenney — https://kenney.nl/assets/roguelike-rpg-pack
- Piskel, suporte móvel — https://github.com/piskelapp/piskel
- Godot editor Android — https://docs.godotengine.org/en/4.6/tutorials/editor/using_the_android_editor.html
- Phaser licença — https://phaser.io/download/license
- Mixamo FAQ (aplicável quando vídeo exibe Mixamo) — https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html

**NAC-PASS proporcional:** PASS documental da fonte, hash, análise visual rastreada e contrato de aceite; HOLD fala integral, implementação individual no TEST36, combate oficial, Cloudflare real e validação física no Android.
