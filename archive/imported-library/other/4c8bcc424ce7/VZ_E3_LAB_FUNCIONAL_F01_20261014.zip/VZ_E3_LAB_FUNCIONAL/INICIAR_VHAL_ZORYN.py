#!/usr/bin/env python3
"""Entrypoint único para o Mestre. Python 3.10+; sem pip e sem credenciais."""
from lab.server import main
if __name__ == '__main__':
    main()
