#!/usr/bin/env python3
"""One-time R09 snapshot construction from read-only documented Notion source excerpts.
This file is part of the reproducible packaged source, not a canon mutation.
"""
import json
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'data'
P.mkdir(parents=True,exist_ok=True)
def dump(name,obj):(P/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
source='https://app.notion.com/p/3f3c2b324ede812d83e1ed6f4fefacdd'
names=['Protocolo de Pré-criação','14 identidades principais','Combate autoral P1','Manifesto de combate','8 Bestas-fonte','Runtime das Bestas-fonte','Matriz transformada','Sistema Transformação Espiritual','Chassi Auralítia','16 itens pessoais existentes','Proficiências P1','Danos P1','Atalhos A-H 64/64','Beast FULLSPEC 6/6','Auditorias de suporte','Manifestos e handoff','Pacote pós-fusão e absorção']
source_page_ids=['3f2c2b324ede815a96ffdee216bdfdcb','3f2c2b324ede81e5aa9ecd23cf0280e3','3f2c2b324ede8144bcc5cc73d9dd3167','3f2c2b324ede813db3dcfb13efb7e4c7','3f2c2b324ede812cb509e9dec64e6e79','3f3c2b324ede810a8208c364d64f808d','3f2c2b324ede816198a5f0fb525223ee','3f2c2b324ede81c0ae0ee4e66212edc9','3f2c2b324ede81739636c041df8cebd5','3f2c2b324ede815c93f4d6bf024b0202','3f2c2b324ede8192891accfc709c0d40','3f2c2b324ede812d8c21fe3afc4748b7','3f2c2b324ede8182b42df53af65dab8e','3f3c2b324ede813987deda0b382e83c7','3f3c2b324ede814fb582c038344a3d92','3f3c2b324ede8156a091f09a0368c007','3f2c2b324ede81288152ec0f8c2066d8']
consumers=['CONTROL+RUNBOOK','CORPUS','DRIVER+P1','HANDOFF-E3','SPIRIT-BESTIARY','BEAST-RUNTIME','TRANSFORM-ADAPTER','SYSTEM-LINK','P1-RACIAL','CORPUS-ITEM','P1-PROF','P1-DAMAGE','PRECREATE-MANIFEST','P2P3-BEAST','AUDIT-GATE','HANDOFF-E3+DRIVER','IBX18+RECEIVER-GATE']
deltas=[]
for i,(name,pid,consumer) in enumerate(zip(names,source_page_ids,consumers),1):
 deltas.append({'id':f'D{i:02d}','name':name,'source_url':f'https://app.notion.com/p/{pid}','receiver_consumer':consumer,
                'status':'DOCUMENTARY_E3_INGESTED_LOCAL_NO_CANON_WRITE',
                'receiver_behavior':'RESOLVE_TO_E3_ONLY; preserve historical sources read-only'})
protagonists=[{'id':f'P1-{i:02d}','name':n,'npc_slot':i} for i,n in enumerate(['Serah Vhal-Teren','Darek Kor-Vhal','Nym Rhae','Urosh Vek-Marr','Sel-Myr Ivara','Kael Soryn','Rhovan Kher-Tal / Veyr-Khal','Asha Velar'],1)]
main=[{'id':'P2-01','name':'Vaelthyr','species_id':'BD-VZ-01','species_scope':'DIVINE_EXISTING'}]
main+= [{'id':f'P3-{i:02d}','name':n,'species_id':s,'species_scope':'REGIONAL_EXISTING_INDIVIDUAL_NOT_NEW_SPECIES'} for i,(n,s) in enumerate([
 ('Grifo-Matriarca de Sílica','B-VZ-FAL-02'),('Crocodilo de Lodo Astral Ancião','B-VZ-PAN-02'),('Serpente Prismática Regente','B-VZ-BOS-02'),('Leviatã de Ferro Mnemônico','B-VZ-PAN-04'),('Roc da Tempestade de Vidro','B-VZ-FAL-04')],1)]
spirit=[{'id':f'SB-{i:02d}','p1_id':f'P1-{i:02d}','species_id':s,'species_scope':'REGIONAL_EXISTING_NOT_NEW_SPECIES'} for i,s in enumerate(['B-VZ-FAL-01','B-VZ-FEN-02','B-VZ-BOS-01','B-VZ-FEN-01','B-VZ-PAN-01','B-VZ-BOS-02','B-VZ-FAL-02','B-VZ-PAN-03'],1)]
personal=[{'id':f'ITEM-VZ-PERS-{i:02d}','owner_p1':f'P1-{(i-1)//2+1:02d}','state':'EXISTING_CORPUS_ID_NO_NEW_UAT'} for i in range(1,17)]
dump('e3_crosswalk.json',{'active_authority_fp':'VZ-CANON-01/FUSION-E3/1649UAT/20G/AR36/EH10/4S',
 'active_entrypoint':'VZ-CANON-01::FUSION-E3::R09-EXPERIMENTAL-RECEIVER',
 'obsolete_entrypoints':['FUSION-E2','VZ-CANON-01::FUSION-E2','VZ-HO-02','HO-02','LEGACY-DRIVER-E2'],
 'upstream_documentary_fusion_pass':True,'receiver_canonical_absorption_pass':False,'material_admission':'DENY','scheduler':'DO-NOT-ARM','t16':'PENDING-READBACK','nc05':'NEGATIVE_11_OF_16_HISTORICAL',
 'source_page':source,'deltas':deltas,'protagonists':protagonists,'main_beasts':main,'spirit_sources':spirit,'personal_items':personal,
 'denominator_justification':{'NPC_P1_subset':8,'B_VZ_40_P3_subset':5,'BD_one_existing':1,'SPIRITS_REGIONAL_SUBSET':8,'ITEM_PERSONAL_EXISTING':16,'new_material_units_added_by_fusion':0,'effective_material_denominator':1649},
 'epistemic':'SOURCE_DOCUMENTED_E3_AND_CANDIDATE_LOCAL_EXECUTION_NOT_NORMATIVE'})
legsource='https://app.notion.com/p/3f1c2b324ede81b39225fc1a7733c602'
names10=['Arraia de Trovão Vítreo','Grifo de Sílica Tempestuosa','Cervo Ferrolunar','Crocodilo de Lodo Astral','Salamandra de Cinza Azul','Tatu Vulcânico de Cobalto','Coruja da Aurora Partida','Serpente Prismática de Geada','Lobo de Bruma Nula','Besouro do Horizonte Fendido']
canonical=['B-VZ-FAL-01','B-VZ-FAL-02','B-VZ-PAN-01','B-VZ-PAN-02','B-VZ-FEN-01','B-VZ-FEN-02','B-VZ-BOS-01','B-VZ-BOS-02',None,None]
drops=[['Asa de Sílica Condutora','Nódulo de Arco Torácico','Membrana Isolante Ventral','Espinho de Pressão Eólica','Humor Vítreo Eletrificado'],['Pena de Turbulência','Garra de Sílica Negra','Tendão de Rajada','Crista de Carga','Saco de Nuvem Seca'],['Galhada de Ferro Vivo','Pelo de Lua Ferrosa','Casco de Turfa Densa','Glândula de Eco Manso','Semente Ruminal Espectral'],['Placa de Lodo Vitrificado','Dente de Turfa Negra','Bolsa de Gás Fantasma','Tendão de Brejo','Pérola Estomacal Oca'],['Escama de Cobalto Térmico','Glândula de Calor Retido','Sangue de Cinza Azul','Membrana Antifissura','Dente de Escória'],['Placa Basáltica Dorsal','Garra de Perfuração Azul','Medula Cerâmica','Bolsa de Poeira Fria','Tendão de Compressão'],['Pena de Reflexo Branco','Lente Ocular Prismática','Garra de Geada Clara','Bolsa de Luz Fria','Osso Oco de Aurora'],['Escama Prismática de Geada','Presa de Luz Fria','Veneno de Refração','Tendão Transparente','Cristal Gular de Aurora'],['Pelo de Bruma Nula','Presa de Vácuo Curto','Almofada de Passo Silente','Pulmão de Névoa','Nó de Eco Predatório'],['Carapaça de Horizonte','Mandíbula de Quartzo Fosco','Resina de Túnel Prismático','Antena de Linha Luminosa','Núcleo de Muda Estratificado']]
registry={}
for i,(n,can,ds) in enumerate(zip(names10,canonical,drops),1):
 registry[f'UAT-B-B{i:02d}']={'name':n,'canonical_id':can,'notion_source':legsource,'legacy_state':'PENDING','drops':{f'UAT-B-D{i:02d}{chr(65+j)}':d for j,d in enumerate(ds)},'drops_material_state':'BLOCKED-BEAST'}
dump('legacy_beast_drop_extract.json',registry)
regions={'KH':'Falésias de Vidro Trovejante','MY':'Pântano da Lua Ferrosa','KV':'Fenda de Cinza Azul','AU':'Bosque da Aurora Partida'}
rids={'KH':'B01','MY':'B03','KV':'B05','AU':'B07'}
dids={'KH':'D01B','MY':'D03A','KV':'D05A','AU':'D07A'}
resources={'KH':'RV-FAL-M02','MY':'RV-PAN-H01','KV':'RV-FEN-M01','AU':'RV-BOS-M02'}
recipes={'KH':'RC-VZ-FAL-04','MY':'RC-VZ-PAN-01','KV':'RC-VZ-FEN-01','AU':'RC-VZ-BOS-02'}
stores={'KH':'STORE-VZ-KH-01','MY':'STORE-VZ-MY-01','KV':'STORE-VZ-KV-01','AU':'STORE-VZ-AU-01'}
cities={'KH':'CITY-VZ-01','MY':'CITY-VZ-02','KV':'CITY-VZ-03','AU':'CITY-VZ-04'}
illustrated={'KH':['RV-FAL-M02'],'MY':['RV-PAN-H01','RV-PAN-O01'],'KV':['RV-FEN-M01','RV-FEN-M03','RV-FEN-O01'],'AU':['RV-BOS-M02','RV-BOS-E01','RV-BOS-O02']}
chains={}
for short in ['KH','MY','KV','AU']:
 chains['CH-E2E-'+short]={'source_id':'UAT-B-'+rids[short],'drop_id':'UAT-B-'+dids[short],
    'resource':resources[short],'recipe':recipes[short], 'illustrated_e2e40_resources':illustrated[short],'store':stores[short],'city':cities[short],'region':regions[short],
    'region_source':'https://app.notion.com/p/3f2c2b324ede817ab731c0d0b44cf454',
    'bridge_notice':'NO CANONICAL DROP->RV RELATION. Laboratory-only synthetic pairing of co-regional drop and existing harvested resource, not conversion, item ingredient, or biological parentage.',
    'epistemic':'BESTA_DROP_DOCUMENTED__DROP_RESOURCE_SYNTHETIC_FIXTURE__RV_RC_SHOP_DOCUMENTED'}
dump('e2e_chains.json',chains)
dump('route_topology.json',{'source':'https://app.notion.com/p/3f2c2b324ede81b49c0ae60cb6fc1751',
 'epistemic':'DOCUMENTARY_TOPOLOGY_NOT_REAL_FREIGHT',
 'routes':{
 'ROUTE-VZ-PULSO-01':{'endpoints':['CITY-VZ-01','CITY-VZ-04'],'name':'Kher-Vhal ↔ Auren-Zor'},
 'ROUTE-VZ-FERROLUNAR-01':{'endpoints':['CITY-VZ-02','CITY-VZ-03'],'name':'Myr-Zoryn ↔ Khar-Vek'},
 'ROUTE-VZ-DUAS-CINZAS-01':{'endpoints':['CITY-VZ-03','CITY-VZ-04'],'name':'Khar-Vek ↔ Auren-Zor'},
 'ROUTE-VZ-CANAL-MEMORIA-01':{'endpoints':['CITY-VZ-02',None],'name':'Myr-Zoryn ↔ Cicatriz; endpoint ID not supplied','executable_anchor_connection':False}},
 'home_city_by_rv_prefix':{'RV-FAL-':'CITY-VZ-01','RV-PAN-':'CITY-VZ-02','RV-FEN-':'CITY-VZ-03','RV-BOS-':'CITY-VZ-04'}})

print('WROTE_DATA',len(deltas),'deltas',len(registry),'beast excerpts',len(chains),'chains')
