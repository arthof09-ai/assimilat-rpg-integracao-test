#!/usr/bin/env python3
"""CLI for one unique functional receptor. No external API or writes."""
import argparse,json,sys
from .receptor import Receiver,GateError

def main(argv=None):
 p=argparse.ArgumentParser(description='Vhal-Zoryn E3 read-only receiver + isolated fixture transaction runner')
 sub=p.add_subparsers(dest='command',required=True)
 sub.add_parser('status',help='E3 current scope and material guards')
 sub.add_parser('before-after',help='Observed software delta from R08 to R09')
 sub.add_parser('import-audit',help='Validate 7 existing cross-region recipe routes as topology only')
 rt=sub.add_parser('route',help='Validate one cross-region recipe and optional blocked route');rt.add_argument('--recipe',default='RC-VZ-FAL-01');rt.add_argument('--closed',default=None)
 d=sub.add_parser('delta',help='Resolve any original D01-D17 to E3 consumer');d.add_argument('id')
 q=sub.add_parser('trace',help='Trace one of 4 historical nominal E2E chains');q.add_argument('--chain',default='CH-E2E-MY');q.add_argument('--fixture',action='store_true')
 x=sub.add_parser('execute',help='Attempt atomic one-item sandbox-only trade');x.add_argument('--chain',default='CH-E2E-MY');x.add_argument('--fixture',action='store_true');x.add_argument('--intent',default='R09-DEMO-001');x.add_argument('--actor',default='MASTER-SANDBOX');x.add_argument('--p1',default='P1-05');x.add_argument('--entrypoint',default=None);x.add_argument('--fault',choices=['PRECOMMIT_FAIL','POSTSTAGE_FAIL']);x.add_argument('--save-state',default=None)
 a=sub.add_parser('resume',help='Load a saved sandbox fixture and replay an idempotent intent');a.add_argument('state_file');a.add_argument('--chain',default='CH-E2E-MY');a.add_argument('--intent',default='R09-DEMO-001');a.add_argument('--p1',default='P1-05')
 z=sub.add_parser('negative',help='Show rejection of known invalid operations');z.add_argument('--kind',choices=['legacy','official','party','drop','mismatch'],default='legacy')
 args=p.parse_args(argv)
 try:
  r=Receiver()
  if args.command=='status':out=r.status()
  elif args.command=='before-after':out=r.inspect_before_after()
  elif args.command=='import-audit':out=r.inspect_imported_recipe_fanout()
  elif args.command=='route':out=r.validate_import_plan(args.recipe,closed_routes=[args.closed] if args.closed else [])
  elif args.command=='delta':out=r.delta(args.id)
  elif args.command=='trace':out=r.trace(args.chain,args.fixture)
  elif args.command=='execute':
   out=r.execute(args.chain,fixture=args.fixture,intent=args.intent,actor=args.actor,entrypoint=args.entrypoint,fault=args.fault,p1_actor=args.p1)
   if args.save_state:out['saved_state']=r.save_fixture_state(args.save_state)
  elif args.command=='resume':
   out={'loaded':r.load_fixture_state(args.state_file),'replay':r.execute(args.chain,fixture=True,intent=args.intent,p1_actor=args.p1)}
  elif args.command=='negative':
   if args.kind=='legacy':r.authorize_entrypoint('VZ-HO-02')
   elif args.kind=='official':r.execute(fixture=False)
   elif args.kind=='party':r.execute(fixture=True,actor='PARTY')
   elif args.kind=='drop':r.chains['CH-E2E-MY']['drop_id']='UAT-B-D02B';r.trace('CH-E2E-MY')
   else:r.execute(fixture=True,p1_actor='P1-06')
   raise AssertionError('EXPECTED_REJECTION_BUT_ACCEPTED')
  print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
  return 0
 except GateError as exc:
  print(json.dumps({'status':'REJECTED','gate_code':exc.code,'reason':str(exc),'official_writes':0},ensure_ascii=False,indent=2))
  return 2

if __name__=='__main__':sys.exit(main())
