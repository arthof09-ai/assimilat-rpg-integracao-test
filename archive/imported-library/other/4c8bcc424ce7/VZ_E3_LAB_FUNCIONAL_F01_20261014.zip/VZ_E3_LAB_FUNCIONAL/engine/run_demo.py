#!/usr/bin/env python3
"""Reproducible R09 scenario suite. Generates evidence, does not touch external state."""
import csv,json,hashlib,sys
from pathlib import Path
from .receptor import Receiver,GateError,digest

OUT=Path(__file__).resolve().parents[1]/'results'
OUT.mkdir(exist_ok=True)
def write(n,obj): (OUT/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def rows_csv(n,rows):
 keys=list(rows[0]) if rows else []
 with (OUT/n).open('w',newline='',encoding='utf-8') as h:
  w=csv.DictWriter(h,fieldnames=keys);w.writeheader();w.writerows(rows)

def run():
 r=Receiver();before=r.inspect_before_after();write('R09_BEFORE_AFTER.json',before)
 write('R09_STATUS_BEFORE.json',r.status())
 doc=[];fixture=[];positives=[]
 for key in ['CH-E2E-KH','CH-E2E-MY','CH-E2E-KV','CH-E2E-AU']:
  doc.append(r.trace(key,False));fixture.append(r.trace(key,True))
  actor={'CH-E2E-KH':'P1-01','CH-E2E-MY':'P1-05','CH-E2E-KV':'P1-04','CH-E2E-AU':'P1-03'}[key]
  assert r.prepare_p1(actor)['spirit_beast_species_id']==fixture[-1]['nodes'][0]['id']
  # Each transaction produces actual result/ledger in this in-memory sandbox process.
  positives.append(r.execute(key,fixture=True,intent='R09-LOCAL-'+key,p1_actor=actor))
 write('R09_DOCUMENTARY_TRACES.json',doc)
 write('R09_FIXTURE_TRACES.json',fixture)
 write('R09_POSITIVE_TRANSACTIONS.json',positives)
 write('R09_INMEMORY_LEDGER.json',r.state)
 imported=r.inspect_imported_recipe_fanout()
 write('R09_IMPORTED_RECIPE_ROUTE_PREFLIGHT.json',imported)
 rows_csv('R09_BOM_CONSUMER_RECONCILIATION.csv',[r.reconcile_e2e_bom(k) for k in ['CH-E2E-KH','CH-E2E-MY','CH-E2E-KV','CH-E2E-AU']])
 write('R09_LEDGER_VALIDATION.json',r.validate_event_ledger())
 write('R09_STATUS_AFTER.json',r.status())

 # Independent in-memory isolated error probes; each starts with pristine source, no committed state.
 cases=[]
 def negative(name,fn,expected):
  before_state=digest(r.state)
  try:fn()
  except GateError as exc:
   cases.append({'case':name,'verdict':'EXPECTED_REJECTION','gate_code':exc.code,'expected':expected,'state_unchanged':digest(r.state)==before_state,'message':str(exc)})
   assert exc.code==expected and digest(r.state)==before_state
  else:raise AssertionError(f'INCORRECT_ACCEPT: {name}')
 negative('N01 obsolete E2 authority',lambda:r.authorize_entrypoint('VZ-CANON-01::FUSION-E2'),'STALE_ENTRYPOINT')
 negative('N02 obsolete HO-02',lambda:r.authorize_entrypoint('VZ-HO-02'),'STALE_ENTRYPOINT')
 negative('N03 unapproved official material',lambda:r.execute('CH-E2E-MY',fixture=False,intent='N03'),'OFFICIAL_MATERIAL_DENY')
 negative('N04 Party actor',lambda:r.execute('CH-E2E-MY',fixture=True,intent='N04',actor='PARTY'),'ACTOR_DENIED')
 negative('N05 P1 wrong beast species',lambda:r.execute('CH-E2E-MY',fixture=True,intent='N05',p1_actor='P1-01'),'SPIRIT_BEAST_MISMATCH')
 negative('N06 fail before commit',lambda:r.execute('CH-E2E-MY',fixture=True,intent='N06',fault='PRECOMMIT_FAIL'),'PRECOMMIT_FAIL')
 negative('N07 fail after stage',lambda:r.execute('CH-E2E-MY',fixture=True,intent='N07',fault='POSTSTAGE_FAIL'),'POSTSTAGE_FAIL')
 negative('N08 official mutate not implemented',lambda:r.official_mutation(),'OFFICIAL_MUTATION_IMPOSSIBLE')
 negative('N09 unknown chain',lambda:r.trace('CH-E2E-UNKNOWN'),'UNKNOWN_CHAIN')
 bad=Receiver();bad.chains['CH-E2E-MY']['drop_id']='UAT-B-D02B'
 b0=digest(bad.state)
 try:bad.trace('CH-E2E-MY')
 except GateError as exc:
  assert exc.code=='BEAST_DROP_MISMATCH' and digest(bad.state)==b0
  cases.append({'case':'N10 wrong beast-drop', 'verdict':'EXPECTED_REJECTION','gate_code':exc.code,'expected':exc.code,'state_unchanged':True,'message':str(exc)})
 else:raise AssertionError('N10 incorrectly accepted')
 negative('N11 route segment unavailable',lambda:r.validate_import_plan('RC-VZ-FAL-01',closed_routes=['ROUTE-VZ-DUAS-CINZAS-01']),'ROUTE_BLOCKED')
 write('R09_NEGATIVE_CASES.json',cases)
 rows_csv('R09_NEGATIVE_CASES.csv',cases)
 # Replay existing transaction and verify no new events.
 old_head=digest(r.state)
 replay=r.execute('CH-E2E-MY',fixture=True,intent='R09-LOCAL-CH-E2E-MY',p1_actor='P1-05')
 assert replay['status']=='IDEMPOTENT_REPLAY_NO_SECOND_EFFECT' and old_head==digest(r.state)
 write('R09_IDEMPOTENT_REPLAY.json',replay)
 # Local persisted state can be loaded in a new fresh receiver instance.
 state_path=OUT/'FIXTURE-R09-WORLD-FOUR-CITIES-v02.json'
 if state_path.exists():
  previous=Receiver()
  previous.load_fixture_state(state_path)
  assert digest(previous.state)==digest(r.state), 'NO_CLOBBER: existing fixture state differs from replay; preserve it and bump filename'
  saved={'path':str(state_path),'sha256':hashlib.sha256(state_path.read_bytes()).hexdigest(),'existing_immutable_replay':True}
 else:
  saved=r.save_fixture_state(state_path)
 fresh=Receiver();fresh.load_fixture_state(saved['path'])
 persisted_replay=fresh.execute('CH-E2E-MY',fixture=True,intent='R09-LOCAL-CH-E2E-MY',p1_actor='P1-05')
 assert persisted_replay['status']=='IDEMPOTENT_REPLAY_NO_SECOND_EFFECT'
 write('R09_RESTART_READBACK.json',{'saved':saved,'journal':fresh.validate_event_ledger(),'replay':persisted_replay,'state_sha256_equal':digest(r.state)==digest(fresh.state)})
 # Delta-to-consumer fanout is explicit but only local on E3 receptor; no physical Notion update.
 rows_csv('R09_DELTA_CONSUMER_MATRIX.csv',[{'D_ID':d['id'],'NAME':d['name'],'E3_SOURCE':d['source_url'],'LOCAL_RECEIVER_CONSUMER':d['receiver_consumer'],'LOCAL_INGESTION':'R09_READ_ONLY_RESOLVED', 'NOTION_CONSUMER_CHANGED':'NO', 'NAC_PASS':'HOLD'} for d in r.e3['deltas']])
 rows_csv('R09_NODE_EDGE_STATUS.csv',[
  {'CHAIN':c['chain'],'SOURCE':e['source'],'TARGET':e['target'],'TYPE':e['kind'],'STATUS':e['state'],'REFERENCE':e['reference']} for c in doc for e in c['edges']])
 coverage={'source_package_sha256':'292e2e89d5d3fc50d40aef48855c9bf6bb7409b00c807eb4f7eb976de8a1861e','deltas':17,'existing_p1':8,'existing_main_beasts':6,'existing_spirits':8,'existing_personal_items':16,'corpus_resources':80,'corpus_recipes':48,'source_recipe_edges':143,'quotas_56':56,'offer_slots':1008,'commercial_proposals':119,'end_to_end_documentary_traces':len(doc),'executable_fixture_transactions':len(positives),'negative_cases':len(cases),'negative_rejections':sum(c['state_unchanged'] for c in cases),'journal_events':len(r.state['events']),'imported_recipe_preflights':imported['recipes_with_imports'],'foreign_rv_refs':imported['foreign_ingredient_occurrences'],'calculated_route_hops':imported['route_hop_requirements'],'notion_dep32_reported_route_hops':11,'route_hop_discrepancy_preserved':imported['route_hop_requirements']!=11,'local_restart_idempotent':True,'official_material_verified':'0/1649','official_notion_writes':0,'official_nac_pass':'HOLD','t16':'PENDING-READBACK','scheduler':'DO-NOT-ARM','classification':'R09_SANDBOX_EXECUTABLE_NOT_CANONICAL'}
 write('R09_DEMO_SUMMARY.json',coverage)
 print('R09_FUNCTIONAL_DEMO',json.dumps(coverage,ensure_ascii=False,sort_keys=True))
 return coverage

if __name__=='__main__':run()
