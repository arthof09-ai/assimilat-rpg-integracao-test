#!/usr/bin/env python3
"""Vhal-Zoryn FUSION-E3 / R09: ONE receiver, isolated documentary+synthetic operations.

Uses exact archival R08->R07 frozen CSV snapshots. Canonical writes are deliberately impossible.
No scheduler, Notion connection, Party, O Primeiro, or material item creation.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import io,csv,zipfile,json,copy,hashlib,sys,re
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT/'data'/'R08_IMMUTABLE_ORIGINAL.zip'
E3=ROOT/'data'/'e3_crosswalk.json'
BEASTS=ROOT/'data'/'legacy_beast_drop_extract.json'
CH_SPECS=ROOT/'data'/'e2e_chains.json'
REQUIRED_FP='VZ-CANON-01/FUSION-E3/1649UAT/20G/AR36/EH10/4S'
PREFIX='FIXTURE-R09-'
OFFICIAL_DENOMINATORS={'SOURCE':420,'OFFER':1008,'MATERIAL':1649,'NPC':96,'BESTA_REGIONAL':40,'BESTA_DIVINA':1,'ITEM_ESPECIAL':32,'RECEITA':48,'CATALOGOS':4}

class GateError(RuntimeError):
 def __init__(self, code:str, message:str):
  self.code=code;super().__init__(f'{code}: {message}')

def digest(o: Any)->str:
 return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()

def csv_in_archive(name:str):
 with zipfile.ZipFile(ARCHIVE) as archive:
  legacy=archive.read('VZ_WS0003_R07_SCIENCE_LONGRUN_20261009.zip')
 with zipfile.ZipFile(io.BytesIO(legacy)) as second:
  return list(csv.DictReader(io.StringIO(second.read(name).decode('utf-8-sig'))))

def jsonfile(f):return json.loads(Path(f).read_text(encoding='utf-8'))

def deepjson(obj):return json.loads(json.dumps(obj,ensure_ascii=False))

@dataclass(frozen=True)
class Edge:
 source: str
 target: str
 state: str
 kind: str
 reference: str

class Receiver:
 """Read-only source adapter + event-sourced in-memory fixture commerce.

 Legacy vE2 is readable as history but CANNOT be dispatch authority.
 """
 def __init__(self):
  self.e3=jsonfile(E3);self.beast_registry=jsonfile(BEASTS);self.chains=jsonfile(CH_SPECS);self.route_topology=jsonfile(ROOT/'data'/'route_topology.json')
  self.resource_rows=csv_in_archive('R07_NEW/VZ_WS0003_R07_RV80_FULL_LINEAGE_AUDIT.csv')
  self.recipe_rows=csv_in_archive('R06_FROZEN/files/VZ_WS0003_R02_RC48_BOM_Evidence_20261008.csv')
  self.offer_rows=csv_in_archive('R06_FROZEN/files/VZ_R04_OFFER1008_PLUS80_RV_PROPOSED.csv')
  self.quota_rows=csv_in_archive('R07_NEW/VZ_WS0003_R07_SHOP56_STATUS_QUOTAS.csv')
  self.resource={r['RESOURCE_ID']:r for r in self.resource_rows}
  self.recipe={r['RC_ID_EXISTING']:r for r in self.recipe_rows}
  self.offer={r['QUOTA_POSITION_ONLY_NOT_OFFER_ID']:r for r in self.offer_rows}
  self.store={r['STORE_ID_EXISTING']:r['CITY_ID_EXISTING'] for r in self.offer_rows}
  self.state={'stock':{},'resource_stock':{},'produced':{},'sold':{},'events':[],'idempotency':{},'official_write_count':0,'processed_txns':0}
  self._validate_snapshot()

 def _validate_snapshot(self):
  if self.e3['active_authority_fp']!=REQUIRED_FP:raise GateError('E3_FP_MISMATCH','expected frozen E3 authority')
  if self.e3['material_admission']!='DENY' or self.e3['scheduler']!='DO-NOT-ARM':raise GateError('OFFICIAL_GATES_MISMATCH','material/scheduler permissions changed')
  if len(self.resource_rows)!=80 or len(self.recipe_rows)!=48 or len(self.offer_rows)!=1008 or len(self.quota_rows)!=56:raise GateError('DENOMINATOR_DRIFT','current source row-count mismatch')
  if len(self.resource)!=80 or len(self.recipe)!=48 or len(self.offer)!=1008:raise GateError('DENOMINATOR_DRIFT','indexed corpus mismatch')
  if set(r['QUOTA_POSITION_ONLY_NOT_OFFER_ID'] for r in self.offer_rows)!=set(self.offer):raise GateError('CACHE_SOURCE_DIVERGENCE','quota cache diverged from source')
  if len(set(self.offer))!=1008:raise GateError('DUP_QUOTA','duplicate quota position')
  if any(r['MATERIAL_UAT_CREDIT']!='0' for r in self.offer_rows):raise GateError('FALSE_MATERIAL','offer payload indicates fake credit')
  if any(r['ITEM_ID_MATERIAL'] or r['OFFER_ID_MATERIAL'] for r in self.offer_rows):raise GateError('FALSE_MATERIAL','official material IDs found unexpectedly')
  rc_edges=0
  for r in self.recipe_rows:
   rv_ids=r['INGREDIENT_RV_IDS_BLUEPRINT'].split('|')
   rc_edges+=len(rv_ids)
   if any(x not in self.resource for x in rv_ids):raise GateError('DANGLING_RV','recipe ingredient absent')
  if rc_edges!=143:raise GateError('EDGE_DRIFT',f'expected 143, got {rc_edges}')
  if len(self.e3['deltas'])!=17 or {d['id'] for d in self.e3['deltas']}!={f'D{x:02d}' for x in range(1,18)}:raise GateError('MISSING_E3_DELTA','D01-D17 coverage mismatch')
  if len(self.e3['protagonists'])!=8 or len(self.e3['main_beasts'])!=6 or len(self.e3['spirit_sources'])!=8 or len(self.e3['personal_items'])!=16:raise GateError('IDENTITY_SCOPE','E3 named identities incomplete')
  if len(self.beast_registry)!=10:raise GateError('BEAST_REGISTRY','expected legacy 10 beast exemplars')
  if any(len(z['drops'])!=5 for z in self.beast_registry.values()):raise GateError('BEAST_DROP_FIVE','legacy five drops by beast')
  if len([r for r in self.offer_rows if r['RC_PRODUCT_BLUEPRINT_REF'] or r['RESOURCE_BLUEPRINT_REF']])!=119:raise GateError('CANDIDATE_QUOTA_DRIFT','119 proposals invariant')
  if any(s not in self.store for s in ['STORE-VZ-KH-01','STORE-VZ-MY-01','STORE-VZ-KV-01','STORE-VZ-AU-01']):raise GateError('SHOP_MAPPING','missing store')

 def status(self):
  return {'active_entrypoint':'VZ-CANON-01::FUSION-E3::R09-EXPERIMENTAL-RECEIVER',
   'source_authority':REQUIRED_FP,'deltas_loaded':len(self.e3['deltas']),
   'identity_registry':{'P1':len(self.e3['protagonists']),'P2_P3':len(self.e3['main_beasts']),'SPIRIT':len(self.e3['spirit_sources']),'PERSONAL_ITEMS':len(self.e3['personal_items'])},
   'corpus':{'resources':len(self.resource),'recipes':len(self.recipe),'rv_recipe_edges':143,'quota_positions':len(self.offer),'shop_family_quotas':len(self.quota_rows),'proposals':119},
   'official_uat':{'verified':0,'denominator':1649},'official_writes':self.state['official_write_count'],
   'material_permit':'DENY','scheduler':'DO-NOT-ARM','notion_sync':'NOT_PERFORMED',
   'documentary_e3_certified':True,'absorption_official_certified':False,
   'in_memory_demo_transactions':self.state['processed_txns']}

 def authorize_entrypoint(self, entrypoint:str):
  active=self.e3['active_entrypoint'];old=self.e3['obsolete_entrypoints']
  if entrypoint!=active:
   if entrypoint in old or ('FUSION-E2' in entrypoint or 'HO-02' in entrypoint):raise GateError('STALE_ENTRYPOINT',f'{entrypoint} is historical not operational')
   raise GateError('UNKNOWN_ENTRYPOINT',entrypoint)
  return active

 def delta(self,did:str):
  match=next((d for d in self.e3['deltas'] if d['id']==did),None)
  if not match:raise GateError('D_NOT_FOUND',did)
  return deepjson(match)

 def trace(self,chain_id='CH-E2E-MY', bridge=False):
  if chain_id not in self.chains:raise GateError('UNKNOWN_CHAIN',chain_id)
  c=self.chains[chain_id]
  if c['source_id'] not in self.beast_registry:raise GateError('UNKNOWN_BEAST',c['source_id'])
  beast=self.beast_registry[c['source_id']]
  if not beast['canonical_id']:raise GateError('BEAST_CANONICAL_XW_HOLD',c['source_id'])
  if c['drop_id'] not in beast['drops']:raise GateError('BEAST_DROP_MISMATCH',c['drop_id'])
  if c['recipe'] not in self.recipe:raise GateError('UNKNOWN_RECIPE',c['recipe'])
  r=self.recipe[c['recipe']]
  ingredient_ids=r['INGREDIENT_RV_IDS_BLUEPRINT'].split('|')
  if c['resource'] not in ingredient_ids:raise GateError('NOT_RECIPE_INGREDIENT',c['resource'])
  if any(x not in self.resource for x in ingredient_ids):raise GateError('MISSING_RECIPE_PARENT','one of original BOM resources not in frozen catalog')
  if c['store']!=r['STORE_ID_EXISTING']:raise GateError('STORE_ORIGIN_MISMATCH','recipe city/store mismatch')
  if self.store[c['store']]!=c['city']:raise GateError('CITY_MISMATCH','store city linkage failure')
  if c['region']!=r['REGION_OUTPUT']:raise GateError('REGION_MISMATCH','recipe region mismatch')
  if c['resource'] not in self.resource:raise GateError('UNKNOWN_RESOURCE',c['resource'])
  match=[o for o in self.offer_rows if o['RC_PRODUCT_BLUEPRINT_REF']==c['recipe'] and o['STORE_ID_EXISTING']==c['store']]
  if len(match)!=1:raise GateError('STORE_OFFER_CANDIDATE_COUNT',f'got {len(match)}')
  o=match[0]
  nodes=[{'kind':'BEAST','id':beast['canonical_id'],'legacy_id':c['source_id'],'name':beast['name'],'epistemic':'VERIFIED-DOCUMENTARY-BLUEPRINT','material':'NOT_VERIFIED'},
   {'kind':'DROP','id':c['drop_id'],'name':beast['drops'][c['drop_id']],'epistemic':'VERIFIED-DOCUMENTARY-LEGACY-ID','material':'BLOCKED-BEAST'},
   {'kind':'RESOURCE','id':c['resource'],'name':self.resource[c['resource']]['NAME'],'epistemic':'VERIFIED-DOCUMENTARY-BLUEPRINT','material':'NONE'},
   {'kind':'RECIPE','id':c['recipe'],'name':r['PRODUCT_NAME_EXISTING_BLUEPRINT'],'epistemic':'VERIFIED-DOCUMENTARY-BLUEPRINT','material':'NONE'},
   {'kind':'ITEM','id':f'{PREFIX}ITEM::{c["recipe"]}' if bridge else None,'name':r['PRODUCT_NAME_EXISTING_BLUEPRINT'],'epistemic':'SYNTHETIC-FIXTURE' if bridge else 'NOMINAL-NAME-ONLY','material':'NONE'},
   {'kind':'COMMERCE','id':f'{PREFIX}OFFER::{o["QUOTA_POSITION_ONLY_NOT_OFFER_ID"]}' if bridge else None,'quota_reference':o['QUOTA_POSITION_ONLY_NOT_OFFER_ID'],'epistemic':'SYNTHETIC-FIXTURE' if bridge else 'QUOTA-PROPOSAL-ONLY','material':'NONE'},
   {'kind':'CITY','id':c['city'],'name':o['CITY_EXISTING'],'epistemic':'VERIFIED-DOCUMENTARY-STRUCTURE'},
   {'kind':'REGION','id':c['region'],'epistemic':'VERIFIED-DOCUMENTARY-BIOME'}]
  edges=[Edge(nodes[0]['id'],nodes[1]['id'],'DOCUMENTARY-LEGACY-ID','DROPS',beast['notion_source']),
   Edge(nodes[1]['id'],nodes[2]['id'],'SYNTHETIC-LAB-BRIDGE' if bridge else 'UNVALIDATED-MISSING','FIXTURE-ECOLOGICAL-ASSOCIATION',c['bridge_notice']),
   Edge(nodes[2]['id'],nodes[3]['id'],'DOCUMENTARY-RECIPE-BOM','INGREDIENT',r['SOURCE_DOCUMENT']),
   Edge(nodes[3]['id'],nodes[4]['id'] or 'UNMATERIALIZED-ITEM','SYNTHETIC-ITEM-ID' if bridge else 'NOMINAL-PRODUCT-NO-ITEM-ID','PRODUCES',r['SOURCE_DOCUMENT']),
   Edge(nodes[4]['id'] or 'UNMATERIALIZED-ITEM',nodes[5]['id'] or 'UNMATERIALIZED-OFFER','SYNTHETIC-OFFER-ID' if bridge else 'PROPOSED-SHOP-ASSOCIATION','LISTED_AT',o['SHOP_SOURCE_URL']),
   Edge(nodes[5]['id'] or 'UNMATERIALIZED-OFFER',c['city'],'DOCUMENTARY-SHOP-CITY','LOCATED_IN',o['SHOP_SOURCE_URL']),
   Edge(c['city'],c['region'],'DOCUMENTARY-REGIONAL-ANCHOR','REGION',c['region_source'])]
  return {'chain':chain_id,'authority':REQUIRED_FP,'fixture_enabled':bridge,'nodes':nodes,'edges':[vars(e) for e in edges],
    'verified_documentary_edges':sum(e.state.startswith('DOCUMENTARY') for e in edges),
    'synthetic_edges':sum(e.state.startswith('SYNTHETIC') for e in edges),
    'unverified_edges':sum(e.state.startswith('UNVALIDATED') or e.state.startswith('NOMINAL') or e.state.startswith('PROPOSED') for e in edges),
    'stage':'FIXTURE-EXECUTABLE' if bridge else 'DOCUMENTARY-ONLY / NO MATERIAL',
    'recipe_ingredient_ids':ingredient_ids,'bom_reconciliation':self.reconcile_e2e_bom(chain_id),
    'recipe_ingredient_material_states':['NONE']*len(ingredient_ids),
    'official_material_credit':0}

 def reconcile_e2e_bom(self,chain_id):
  if chain_id not in self.chains:raise GateError('UNKNOWN_CHAIN',chain_id)
  chain=self.chains[chain_id];r=self.recipe[chain['recipe']]
  declared=set(chain['illustrated_e2e40_resources']);effective=set(r['INGREDIENT_RV_IDS_BLUEPRINT'].split('|'))
  return {'chain':chain_id,'official_recipe_id':chain['recipe'],'source':'R02_RC48_BOM_Evidence_20261008.csv',
   'e2e40_source':'https://app.notion.com/p/3f2c2b324ede817ab731c0d0b44cf454',
   'illustrated_e2e40':sorted(declared),'full_existing_recipe_bom':sorted(effective),
   'missing_from_illustration':sorted(effective-declared),'extra_in_illustration_not_original_bom':sorted(declared-effective),
   'experimental_receiver_effective_inputs':sorted(effective),'original_recipe_modified':False,
   'assessment':'EXACT_MATCH' if declared==effective else 'EXPERIMENTAL_VIEW_CORRECTED_USING_EXISTING_RECIPE_BOM'}

 def validate_import_plan(self, recipe_id, *, closed_routes=()):
  """Verify exact existing route-ID sequences; never claim freight or material eligibility."""
  if recipe_id not in self.recipe:raise GateError('UNKNOWN_RECIPE',recipe_id)
  recipe=self.recipe[recipe_id]
  declared=recipe['IMPORT_RV_PATHS_DESIGN']
  count=int(recipe['IMPORTED_RV_OCCURRENCES'])
  imported=[]
  if count==0:
   if declared!='NONE/LOCAL':raise GateError('ROUTE_DESCRIPTOR_DRIFT','local recipe has route string')
   return {'recipe_id':recipe_id,'import_count':0,'imports':[],'hop_count':0,'material_transport':'NOT_PERFORMED'}
  # No route reinterpretation: parse only the exact recovered notation.
  for part in declared.split('|'):
   m=re.fullmatch(r'(RV-[A-Z]{3}-[A-Z][0-9]{2})\((ROUTE-VZ-[A-Z0-9-]+(?:>ROUTE-VZ-[A-Z0-9-]+)*)\)',part)
   if m is None:raise GateError('ROUTE_DESCRIPTOR_INVALID',part)
   resource_id,chain=m.groups()
   if resource_id not in self.resource or resource_id not in recipe['INGREDIENT_RV_IDS_BLUEPRINT'].split('|'):
    raise GateError('ROUTE_RESOURCE_MISMATCH',resource_id)
   origin=next((city for prefix,city in self.route_topology['home_city_by_rv_prefix'].items() if resource_id.startswith(prefix)),None)
   target=recipe['CITY_ID_EXISTING']
   position=origin
   legs=[]
   if origin is None or target is None:raise GateError('UNKNOWN_ROUTE_ENDPOINT',resource_id)
   for route_id in chain.split('>'):
    if route_id in closed_routes:raise GateError('ROUTE_BLOCKED',route_id)
    route=self.route_topology['routes'].get(route_id)
    if not route or not route.get('endpoints') or None in route['endpoints']:
     raise GateError('ROUTE_NOT_BINDABLE',route_id)
    ends=route['endpoints']
    if position not in ends:raise GateError('ROUTE_DISCONNECTED',f'{position} cannot board {route_id}')
    next_city=ends[1] if ends[0]==position else ends[0]
    legs.append({'route_id':route_id,'depart_city':position,'arrive_city':next_city})
    position=next_city
   if position!=target:raise GateError('ROUTE_WRONG_DESTINATION',f'{resource_id} reached {position}, not {target}')
   imported.append({'ingredient_id':resource_id,'source_city':origin,'destination_city':target,'design_route_legs':legs,'freight_verified':False})
  if len(imported)!=count:raise GateError('IMPORTED_SOURCE_COUNT_DRIFT',f'{len(imported)} vs {count}')
  return {'recipe_id':recipe_id,'import_count':count,'imports':imported,'hop_count':sum(len(x['design_route_legs']) for x in imported),
   'material_transport':'NOT_PERFORMED','route_status':'DOCUMENTARY_TOPOLOGY_ONLY','official_material_credit':0}

 def inspect_imported_recipe_fanout(self):
  imported=[r['RC_ID_EXISTING'] for r in self.recipe_rows if r['IMPORTED_RV_OCCURRENCES']!='0']
  plans=[self.validate_import_plan(i) for i in imported]
  return {'recipes_with_imports':len(plans),'foreign_ingredient_occurrences':sum(p['import_count'] for p in plans),
   'route_hop_requirements':sum(p['hop_count'] for p in plans),'plans':plans,
   'freight_materialized':0,'official_material_credit':0}

 def prepare_p1(self, protagonist_id):
  protagonist=next((p for p in self.e3['protagonists'] if p['id']==protagonist_id),None)
  if protagonist is None:raise GateError('UNKNOWN_P1',protagonist_id)
  spirit=next((p for p in self.e3['spirit_sources'] if p['p1_id']==protagonist_id),None)
  items=[i['id'] for i in self.e3['personal_items'] if i['owner_p1']==protagonist_id]
  if spirit is None or len(items)!=2:raise GateError('P1_E3_CROSSWALK_INCOMPLETE',protagonist_id)
  return {'actor_id':protagonist_id,'name':protagonist['name'],'spirit_beast_species_id':spirit['species_id'],
    'existing_personal_items':items,'source_deltas':['D02','D05','D06','D07','D10','D13'],
    'no_spirit_base_damage_inheritance':True,'no_material_p1_write':True}

 def validate_event_ledger(self, state=None):
  cur=state if state is not None else self.state
  previous='GENESIS'; sequence=0
  for e in cur['events']:
   sequence+=1
   if e['seq']!=sequence or e['previous_hash']!=previous:raise GateError('EVENT_JOURNAL_ORDER','event order or previous hash mismatch')
   blob={k:v for k,v in e.items() if k!='hash'}
   if e['hash']!=digest(blob):raise GateError('EVENT_JOURNAL_TAMPERED',f'event #{sequence}')
   if e['epistemic']!='SYNTHETIC-ONLY' or e['official_material_credit']!=0:raise GateError('EVENT_CANON_LEAK',str(sequence))
   previous=e['hash']
  if cur['official_write_count']!=0:raise GateError('CANON_MUTATION','official writes nonzero')
  return {'events':sequence,'head_hash':previous,'verified':True}

 def save_fixture_state(self, path):
  self.validate_event_ledger()
  path=Path(path)
  if not path.name.startswith('FIXTURE-R09-'):raise GateError('UNSAFE_OUTPUT_NAME','fixture filename must identify noncanonicity')
  if path.exists():raise GateError('NO_CLOBBER','never overwrite existing receipt/state')
  snapshot=deepjson(self.state)
  data={'schema':'R09-LOCAL-FIXTURE-STATE-V1','source_fp':REQUIRED_FP,'state_sha256':digest(snapshot),'state':snapshot}
  path.parent.mkdir(exist_ok=True,parents=True)
  path.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
  return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

 def load_fixture_state(self,path):
  data=json.loads(Path(path).read_text(encoding='utf-8'))
  if data.get('schema')!='R09-LOCAL-FIXTURE-STATE-V1' or data.get('source_fp')!=REQUIRED_FP:raise GateError('BAD_LOCAL_STATE','schema/authority fingerprint mismatch')
  state=data['state']
  if digest(state)!=data.get('state_sha256'):raise GateError('FIXTURE_SNAPSHOT_TAMPERED','saved in-memory fixture checksum mismatch')
  self.validate_event_ledger(state)
  if any(not k.startswith(PREFIX) for k in state['stock']):raise GateError('OFFICIAL_ID_IN_FIXTURE_STOCK','invalid stock identifier')
  if any(k not in self.resource for k in state['resource_stock']):raise GateError('OFFICIAL_ID_IN_FIXTURE_STOCK','unknown resource in fixture inventory')
  if state['produced']!=state['sold'] or any(v!=0 for v in state['stock'].values()):raise GateError('PRODUCT_LEDGER_DIVERGENCE','newly made fixture item must have matching sale in current demo')
  if state['processed_txns']!=len(state['idempotency']):raise GateError('STATE_CONFLICT','transaction count mismatch')
  self.state=deepjson(state)
  return self.validate_event_ledger()

 def execute(self, chain_id='CH-E2E-MY', *, fixture=False,intent='R09-DEMO-001',actor='MASTER-SANDBOX',entrypoint=None,fault=None,quantity=1,p1_actor=None):
  """One atomic in-memory demo transaction; replay idempotent and failures rollback."""
  self.authorize_entrypoint(entrypoint or self.e3['active_entrypoint'])
  if actor!='MASTER-SANDBOX':raise GateError('ACTOR_DENIED','no Party/O Primeiro in the fixture')
  if not fixture:raise GateError('OFFICIAL_MATERIAL_DENY','enable explicit fixture flag for isolated synthetic execution')
  if not intent or quantity!=1:raise GateError('BAD_INTENT','only exact one synthetic unit per demo')
  self.validate_event_ledger()
  actor_binding=self.prepare_p1(p1_actor) if p1_actor else None
  before=digest(self.state)
  if intent in self.state['idempotency']:
   if self.state['idempotency'][intent]['request']!={'chain':chain_id,'quantity':quantity,'p1_actor':p1_actor}:
    raise GateError('IDEMPOTENCY_CONFLICT',intent)
   return {'status':'IDEMPOTENT_REPLAY_NO_SECOND_EFFECT','before_state_hash':before,'after_state_hash':before,'original_receipt':self.state['idempotency'][intent]['receipt']}
  trace=self.trace(chain_id,bridge=True)
  if any(e['state']=='UNVALIDATED-MISSING' for e in trace['edges']):raise GateError('UNKNOWN_BRIDGE','fixture refused to bridge')
  if actor_binding and actor_binding['spirit_beast_species_id']!=trace['nodes'][0]['id']:
   raise GateError('SPIRIT_BEAST_MISMATCH','P1 E3 spirit species does not match tested beast')
  # Staged local transaction: untouched global state until commit; failures do not debit inventory.
  staged=deepjson(self.state)
  item=trace['nodes'][4]['id'];offer=trace['nodes'][5]['id']
  # No official BOM quantities known: fixture uses one arbitrary synthetic unit per input.
  # Each raw source starts at two demo-only units and is debited atomically.
  for inp in trace['recipe_ingredient_ids']:
   if inp not in staged['resource_stock']:staged['resource_stock'][inp]=2
  if item not in staged['stock']:staged['stock'][item]=0
  if fault=='PRECOMMIT_FAIL':raise GateError('PRECOMMIT_FAIL','simulated crash before commit; state untouched')
  if any(staged['resource_stock'][inp]<quantity for inp in trace['recipe_ingredient_ids']):
   raise GateError('SOURCE_STOCK_EXHAUSTED','synthetic raw resource inventory depleted')
  for inp in trace['recipe_ingredient_ids']:staged['resource_stock'][inp]-=quantity
  staged['stock'][item]+=quantity
  staged['produced'][item]=staged['produced'].get(item,0)+quantity
  if staged['stock'][item]<quantity:raise GateError('PRODUCT_STOCK_EXHAUSTED','product unavailable even after fixture assembly')
  staged['stock'][item]-=quantity
  staged['sold'][item]=staged['sold'].get(item,0)+quantity
  tasks=[('PROVENANCE_FIXTURE',trace['nodes'][1]['id'])]+[('SOURCE_STAGED_FIXTURE',x) for x in trace['recipe_ingredient_ids']]+[('RESOURCE_CONSUME_FIXTURE',x) for x in trace['recipe_ingredient_ids']]+[('RECIPE_EXECUTE_FIXTURE',trace['nodes'][3]['id']),('ITEM_PRODUCE_FIXTURE',item),('OFFER_ATTACH_FIXTURE',offer),('PURCHASE_FIXTURE',trace['nodes'][6]['id']),('CITY_REGION_RESOLVED',trace['nodes'][7]['id'])]
  if actor_binding:tasks.insert(0,('E3_CHARACTER_CONTEXT_BIND',actor_binding['actor_id']))
  previous=staged['events'][-1]['hash'] if staged['events'] else 'GENESIS'
  for i,(event,target) in enumerate(tasks,1):
   payload={'seq':len(staged['events'])+1,'intent':intent,'step':i,'event':event,'target':target,'epistemic':'SYNTHETIC-ONLY','official_material_credit':0,'previous_hash':previous}
   payload['hash']=digest(payload);previous=payload['hash']
   staged['events'].append(payload)
  if fault=='POSTSTAGE_FAIL':raise GateError('POSTSTAGE_FAIL','simulated failure after stage before atomic swap; state untouched')
  staged['processed_txns']+=1
  receipt={'intent':intent,'chain':chain_id,'entrypoint':self.e3['active_entrypoint'],'trace_digest':digest(trace),'synthetic_item_id':item,'synthetic_offer_id':offer,'stock_after_fixture':staged['stock'][item],'produced_synthetic_total':staged['produced'][item],'sold_synthetic_total':staged['sold'][item], 'resource_remaining_fixture':{x:staged['resource_stock'][x] for x in trace['recipe_ingredient_ids']},'not_canonical_recipe_quantities':True,'bom_reconciliation':trace['bom_reconciliation'], 'event_count_for_intent':len(tasks),'e3_actor_binding':actor_binding,'journal_head':previous,'official_material_credit':0,'official_source_item_offer_writes':0,'epistemic':'SYNTHETIC-SANDBOX-ONLY'}
  staged['idempotency'][intent]={'request':{'chain':chain_id,'quantity':quantity,'p1_actor':p1_actor},'receipt':receipt}
  if staged['official_write_count']!=0:raise GateError('CANON_MUTATION','official state mutated unexpectedly')
  self.validate_event_ledger(staged)
  self.state=staged
  return {'status':'COMMITTED_SANDBOX_ONLY','before_state_hash':before,'after_state_hash':digest(self.state),'receipt':receipt,'trace':trace}

 def official_mutation(self,*args,**kwargs):raise GateError('OFFICIAL_MUTATION_IMPOSSIBLE','sandbox adapter has no implementation of official writes')

 def inspect_before_after(self):
  return {'before':{'mode':'R08-SCIENCE-READONLY','executable_e3_ingestion':False,'dynamic_trace':False,'event_sourced_fixture_transaction':False,'atomic_rollback':False,'idempotent_sales':False,'legacy_stale_entrypoint_guard':False},
 'after':{'mode':'R09-E3-ONE-RECEIVER-SANDBOX','executable_e3_ingestion':True,'dynamic_trace':True,'event_sourced_fixture_transaction':True,'atomic_rollback':True,'idempotent_sales':True,'legacy_stale_entrypoint_guard':True},
 'common':{'official_material_verified':'0/1649','canon_sync':False,'source': 'same immutable R08 / R07 frozen source files'}}
