#!/usr/bin/env python3
from pathlib import Path
import json,csv
from .receptor import Receiver
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'docs';D.mkdir(exist_ok=True)
R=ROOT/'results'
def write(name,s):(D/name).write_text(s.strip()+'\n',encoding='utf-8')
def csv_out(name,rows,fields):
 with (D/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
r=Receiver()
reconciliations=[r.reconcile_e2e_bom(c) for c in ('CH-E2E-KH','CH-E2E-MY','CH-E2E-KV','CH-E2E-AU')]
imported=r.inspect_imported_recipe_fanout()
csv_out('R09_BOM_DELTA_RECEIVER.csv',[{'CHAIN':x['chain'],'RECIPE':x['official_recipe_id'],'E2E40_ILLUSTRATED':';'.join(x['illustrated_e2e40']),'BOM_EXISTING_EFFECTIVE':';'.join(x['full_existing_recipe_bom']),'MISSING_E2E40':';'.join(x['missing_from_illustration']),'EXTRA_E2E40_NOT_BOM':';'.join(x['extra_in_illustration_not_original_bom']),'RECEIVER_STATUS':x['assessment'],'ORIGINAL_EDIT':'NO'} for x in reconciliations],['CHAIN','RECIPE','E2E40_ILLUSTRATED','BOM_EXISTING_EFFECTIVE','MISSING_E2E40','EXTRA_E2E40_NOT_BOM','RECEIVER_STATUS','ORIGINAL_EDIT'])

statuses=[('E3_FUSION_DOCUMENTAL','VERIFIED-UPSTREAM-DOC-PASS','FUSION report D01–D17 17/17'),('ABS_A_K_OFFICIAL','HOLD-NO-NAC-PASS','NC05 negative; no legitimate claim of receiver material updates'),('ABS_L','DENY','R07 material runtime blocked and 0/1649'),('T16','PENDING-READBACK','Control T16 pending; IBX18 checkpoint not present'),('NC05','NEGATIVE-HISTORIC','Independent audit pending after authorized changes'),('B04','HOLD-NORM','Legacy Earth/Spectral versus E3 Water/Spectral'),('B09','HOLD-CORE-REGION','D09B/D09D habitat eligibility unresolved'),('B10','HOLD-CORE-REGION','D10D habitat eligibility unresolved'),('PATCH03','DOC-PARTIAL/HOLD','No new normative acceptance'),('PATCH04','ECO-HOLD','200 positions 50 HIST+150 V2 proposals, no material'),('PATCH05','COMMERCIAL-HOLD','119 source candidate,119 offers design,no real item'),('PATCH06','RE-AUDIT-HOLD','Original 16 conditions and NC05 required'),('IBX61','NOVA-ACK-PENDING','Read master-side; no instance allocation'),('IBX65','NOVA-ACK-PENDING','Read master-side; no writer'),('OFFICIAL_WRITER','NONE','No legitimate claim, lease, epoch or technical fencing'),('SCHEDULER','DO-NOT-ARM','Project-binding external gate'),('PARTY_O_PRIMEIRO','ZERO_WRITES','Master-only sandbox')]
csv_out('R09_GATE_DISPOSITION.csv',[{'GATE':a,'STATE':b,'EVIDENCE_OR_BLOCKER':c,'CHANGE_THIS_RUN':'NONE/OFFICIAL'} for a,b,c in statuses],['GATE','STATE','EVIDENCE_OR_BLOCKER','CHANGE_THIS_RUN'])

write('README_REPRODUCAO.md',r'''
# Vhal-Zoryn R09 — receptor FUSION-E3 executável em cópia isolada

**MESTRE-SIDE / TEST-ONLY / sem acesso externo / sem Notion writer / sem Party.**

## Capacidade nova

A pasta `engine/` é o único receptor experimental ativo, com entrada `python -m engine.cli`.
Carrega o arquivo original R08 (imutável), abre o ZIP R07 aninhado, lê os CSVs congelados
80 RV, 48 RC, 143 arestas RV→RC, 1.008 cotas comerciais (119 candidatas) e 56 cotas loja×família,
e o crosswalk documental E3 D01–D17, P1(8), principais(6), Bestas-fonte(8), itens pessoais(16).
Não faz scraping da rede, não escreve Notion, não usa scheduler e não expõe dados à Party.

A capacidade usa os dados existentes; **não refaz a fusão** nem os 48 protocolos e **não implementa produção/canonização**.
O *adapter* reutiliza os CSVs exportados R02/R04/R07/R08. Os novos `data/e3_crosswalk.json`,
`data/legacy_beast_drop_extract.json`, `data/e2e_chains.json` e `data/route_topology.json`
são **cópias de leitura / índices de demonstração**, subordinados ao E3 do Notion, e não autoridades adicionais.

## Ambiente e comandos (Python 3.10+; somente biblioteca padrão)

Na pasta `R09` após extrair o ZIP:

```bash
python -m engine.cli status
python -m engine.cli delta D05
python -m engine.cli before-after
python -m engine.cli trace --chain CH-E2E-MY
python -m engine.cli trace --chain CH-E2E-MY --fixture
python -m engine.cli execute --chain CH-E2E-MY --fixture --p1 P1-05 --intent MEU-TESTE-0001 --save-state results/FIXTURE-R09-meu-teste-0001.json
python -m engine.cli resume results/FIXTURE-R09-meu-teste-0001.json --chain CH-E2E-MY --intent MEU-TESTE-0001 --p1 P1-05
python -m engine.cli negative --kind legacy       # SAÍDA ESPERADA: código 2, STALE_ENTRYPOINT
python -m engine.cli negative --kind official     # SAÍDA ESPERADA: código 2, OFFICIAL_MATERIAL_DENY
python -m engine.cli import-audit
python -m engine.cli route --recipe RC-VZ-FAL-01 --closed ROUTE-VZ-DUAS-CINZAS-01  # código 2, ROUTE_BLOCKED
python -m unittest discover -s tests -v
python -m engine.run_demo
```

**Observação:** comandos `negative` retornam exit code 2 quando rejeitam corretamente.
Não chamar `--save-state` no nome de arquivo de saída já existente (NO_CLOBBER);
um novo nome `FIXTURE-R09-*` é exigido. A execução reiniciada de `run_demo`
valida a cópia anterior, sem apagá-la; se tiver alterado dados, gera conflito em vez de substituí-la.

## Fontes e cadeia de prova

- E3 final: `https://app.notion.com/p/3f3c2b324ede812d83e1ed6f4fefacdd`
- IBX18: `https://app.notion.com/p/3f3c2b324ede81618d96dc600798bcff`
- IBX61: `https://app.notion.com/p/3f4c2b324ede81129d58e2f0a2056b0d`
- IBX65: `https://app.notion.com/p/3f4c2b324ede8105a2d6c8ffd337eae0`
- E2E40: `https://app.notion.com/p/3f2c2b324ede817ab731c0d0b44cf454`
- Matriz09: `https://app.notion.com/p/3f1c2b324ede8145be13d394780e6d2c`
- DEP32: `https://app.notion.com/p/3f2c2b324ede81b49c0ae60cb6fc1751`
- SHOP26: `https://app.notion.com/p/3f2c2b324ede8141b3beecc19564305a`
- Beast legacy: `https://app.notion.com/p/3f1c2b324ede81b39225fc1a7733c602`

Exemplo principal Myr-Zoryn: `B-VZ-PAN-01` (B03 Cervo Ferrolunar) → `UAT-B-D03A`
(Galhada de Ferro Vivo) → **ponte sintética `D03A ↔ RV-PAN-H01`, sem causalidade canônica**
→ `RV-PAN-H01` Junco de Lua Ferrosa + os outros dois insumos **da BOM original da receita**
→ `RC-VZ-PAN-01` Manto Ferrolunar → `FIXTURE-R09-ITEM::*`
→ `FIXTURE-R09-OFFER::*` na cota histórica `STORE-VZ-MY-01::Roupas::001`
→ `STORE-VZ-MY-01` → `CITY-VZ-02` Myr-Zoryn → Pântano da Lua Ferrosa.

A evidência E3 é adicional: `P1-05` Sel-Myr Ivara → `SB-05` (Besta-fonte B-VZ-PAN-01),
com dois itens pessoais já existentes (`ITEM-VZ-PERS-09/10`). Isso verifica identidade e
ligação ao E3 **no receptor experimental**; não ativa transformação ou dano canônico.

## Três fronteiras epistêmicas, nunca fundidas

1. **DOCUMENTÁRIO VERIFICADO:** IDs de blueprint, BOM original, estrutura de loja/cidade/região,
   crosswalk E3 como texto oficialmente documentado.
2. **CANDIDATO/PROPOSTO:** 119 posições de oferta, SOURCE 119/420, 50 drops históricos bloqueados,
   150 propostas V2 sem aceite ecológico; nenhum desses é item comprado ou produzido.
3. **SINTÉTICO/EXPERIMENTAL:** ponte drop→RV, unidades e cotas da fixture, estoque inicial hipotético
   de **2 unidades de cada insumo** por cenário, consumo de **1 unidade fictícia** por ingrediente,
   ITEM/OFFER `FIXTURE-R09-*`, venda fictícia e journal com SHA-256. Não existem quantidades reais
   dos BOMs, preços ou estoque oficial aqui.

**Ledger**: dados do mundo ficam em RAM. O método salva um arquivo JSON local de fixture
com hash SHA-256 de integridade e hash encadeado de eventos; SHA-256 não autentica um emissor
malicioso que reescreva o arquivo e recalcule o hash. Nem ledger de fixture nem arquivo
local contabilizam UAT, ITEM, SOURCE ou OFFER oficiais.

## Incompatibilidades reais reveladas

- E2E40 ilustra parcialmente insumos. R02/R07 BOM completo deve prevalecer *para fins experimentais*.
  `RC-VZ-BOS-02` é caso de conflito: E2E40 menciona `RV-BOS-O02`, mas o BOM existente
  utiliza `RV-BOS-M01`. O receptor usa o BOM sem alterar documento algum.
- DEP32 documenta **11 trechos** em sete topologias. O parser estrito das sete strings
  de receita contabiliza **12 trechos** (2+2+1+2+2+1+2). Preservar divergência para
  revisão de fonte; nenhuma rota é criada e nenhuma viagem é alegada.
- Aresta do drop para qualquer recurso comercial NÃO FOI comprovada. Receptor executa
  fixture explicitamente ou mostra ponto de interrupção no modo documental.
- Falta ITEM-ID real, OFFER-ID real, preço, estoque, licença, atestado de origem e todas as UAT.
- R07 MATERIAL/HARD-PROJECT-BIND, T16, sucessão/fencing, B04/B09/B10, NC05, NAC-PASS e ABS-L HOLD.

## Critério de reprodução

`unittest` deve aprovar todos os testes; `run_demo` deve gerar quatro commits de fixture,
11 negativas detectadas e replay sem efeito duplicado; `import-audit` deve recuperar 7 RC,
8 referências RV estrangeiras e 12 hops literais. `results/` contém recibos e logs
provenientes de execução real de Python, não narrativas construídas manualmente.
R08 está no pacote byte a byte, preservando ZIPs R07/R06/R05/R01–R04 internos disponíveis.
''')

write('R09_PSV_RELATORIO.md',f'''
# PSV R09 — CM-000005 / WS0003 — FUSION-E3 receptor funcional

**Classificação:** EXECUTADO EM SANDBOX / DEMONSTRÁVEL / NÃO CANÔNICO.
**Identidade:** CM-000005 existente; nenhuma nova INSTANCE-ID, writer, lease ou epoch reivindicados.
**Origem:** ordem Mestre R09 e IBX61/65, estado lido pela conexão Mestre-side do Notion; IBX18 BLOQUEADA.

## BEFORE / AFTER mensurável

| Critério | R08 recuperado | R09 isolado |
| --- | --- | --- |
| Corpus R01–R08 | 80 RV,48 RC,143 RV→RC,119 candidatos | EXATAMENTE IGUAL (R08 binário aninhado) |
| Delta E3 | D01–D17 documental; sem CLI operacional nestes arquivos | 17/17 IDs indexados em um receptor; consumidor explicitado, sem escrita oficial |
| P1 / principais / Spirit / itens pessoais | Registros no Notion E3, não executados no R08 | 8/6/8/16 referenciados e verificados por contrato local; P1-05 vinculado a B-VZ-PAN-01 |
| Grafo econômico | 4 cadeias nominais relatadas e 119 propostas | 4 rastros dinâmicos, 4 commits em memória, BOM completo por receita |
| Atomicidade | R08 sem motor transacional de comércio | commit em RAM, rollback de duas falhas injetadas, replay idempotente entre reinícios |
| Operação logística | 7 rotas documentais, sem preflight executável neste pacote | 7 planos parseados com topologia, falha de rota rejeitada |
| Estado material oficial | 0/1649 | 0/1649 sem mudança |
| Cânone/Notion/Party | 0 writes na pesquisa | 0 writes na pesquisa |

## Prova funcional / entradas-processo-saída

**Entradas:** ZIP R08 (SHA-256 `292e2e89d5d3fc50d40aef48855c9bf6bb7409b00c807eb4f7eb976de8a1861e`) contendo R07/R06 anteriores; fontes Notion reabertas para E3, E2E40, IBX18/61/65, Control.

**Processamento:** `engine.receptor.Receiver`, entrypoint único `VZ-CANON-01::FUSION-E3::R09-EXPERIMENTAL-RECEIVER`; consulta R02 BOM, R07 80 RV/1008 quotas, E3 D01–D17; valida espécie/drop, receita, família/loja/cidade, três ingredientes em cada receita de demonstração, guarda ponte de fixture e transaciona **somente RAM**.

**Saídas observadas:** 4/4 fluxos de cidade produzidos; 4/4 commits experimentais; 52 eventos sintéticos encadeados no journal; 11/11 negativas rejeitadas; replay com 0 efeito repetido após salvar e reabrir estado local. Todos os valores são demonstração de algoritmo, não produção de artefatos canônicos.

**Relação D05-D06/D07/D10 com a cadeia:** no caso de Myr-Zoryn, P1-05 Sel-Myr Ivara referencia SB-05 de espécie `B-VZ-PAN-01` já existente e dois `ITEM-VZ-PERS-09/10`; o mesmo ID de espécie aparece no nó Besta do grafo econômico. Isso NÃO mistura capacidade de Espírito com dano-base de Besta viva e NÃO cria um segundo NPC/especie.

**Negativas comprovadas:** E2/HO02 obsoletos `STALE_ENTRYPOINT`; escrita real `OFFICIAL_MATERIAL_DENY`; Party `ACTOR_DENIED`; Besta/drop errado `BEAST_DROP_MISMATCH`; P1/Spirit divergente `SPIRIT_BEAST_MISMATCH`; rota fechada `ROUTE_BLOCKED`; crash pré-commit e pós-stage preservam hash do estado; guarda contra cache de cotas divergente. Ver `R09_NEGATIVE_CASES.json`, 56 testes locais e `tests/test_receiver.py`.

## Divergências encontradas e correções experimentais

1. **BOM incompleto nos exemplos E2E40**: KH faltavam dois ingredientes, MY um, KV nenhum, AU faltava `RV-BOS-M01` e trazia `RV-BOS-O02` não presente no BOM R02. Corrigido na visão de montagem da cópia por uso do BOM existente, sem tocar REC31 nem E2E40 no Notion.
2. **Cache fonte 1008 posições**: defeito de teste capturado no R09 protótipo (remoção de linha após indexação não detectada); corrigido validando fontes e índice separadamente, 56/56 testes finais aprovados.
3. **Topologia de importação**: sete receitas / oito RV estrangeiros; soma direta dos caminhos de receita = **12** hops, apesar de DEP32 registrar **11**. Diferença documental preservada e não corrigida silenciosamente.
4. **Aresta inexistente drop→RV**: não se inventa causalidade; fixture exige flag explícita. Sem flag, rastreamento marca elo `UNVALIDATED-MISSING` e a execução material é negada.

## Governança e materialização

**VERIFICADO:** R08 bytes recuperados e integridade; script executado; 4 fluxos e logs; 56 regressões + negativas; conexão Mestre-side de leitura do Notion; D01–D17 na fonte documental final E3; IBX18/61/65 lidas; Control T16 pendente.

**PROPOSTO/SINTÉTICO:** passagens de fixture, 1 unidade por ingrediente, dois estoques virtuais por insumo, comércio e transações RAM. Identificador `FIXTURE-R09-*` nunca é ITEM-ID, SOURCE-ID ou OFFER-ID real.

**PENDENTE:** claims/STOP-ACK/fencing, NC05 independente, PATCH03–06 autorizados e recepcionados, B04/B09/B10, fontes físicas reais, UAT, quota real, rota fretada, absorção A–K com NAC-PASS, ABS-L. IBX61/65 continuam NOVA/ACK pendente.

**SEM AUTORIZAÇÃO:** nenhuma escrita oficial Notion, Party ou O Primeiro; nenhum scheduler. `MATERIAL=0/1649`, `ABS-L=DENY`, `R07(material)=HOLD`.

## Gate terminal

**PASS proporcional:** pacote local integro, algoritmo demonstrado, QA local aprovado, replay/negativas; não é NAC-PASS operacional/produção. **NAC-PASS final = HOLD** por NC05, T16 e writer. `D01–D17 local registry 17/17 ≠ ABS-A–K 11/11 ≠ ABS-L`.

## Próxima fronteira da operação

Após R09 local, atacar: (a) resolução documental BOM/E2E40 e 12 vs 11 sem mudar canônico, (b) autorização de sucessão/fencing T16 sem reivindicar I0012, (c) grafo de transporte transacional com custos/restrições de fonte verificada e independente, (d) medir equivalência original das 16 condições NC05 com auditor terceiro, (e) cessar hold material somente quando houver gate legítimo. R09 já acrescentou preflight das 7 receitas importadas; a próxima melhoria funcional deve ser fluxo multi-etapas sem falsear estoque real.
''')

write('R09_NOTION_SYNC_PENDING.md',r'''
# PENDING SYNC — NÃO APLICAR SEM AUTORIDADE

Destinos existentes (sem criar página duplicada): IBX18, IBX61, IBX65, Control/Diário e FUSION-E3.
**Nenhuma operação de Notion realizada nesta rodada além de LEITURA.**
T16 `VZ-IBX18-PATCH035-I0011-20261008` permanece PENDING-READBACK no Control;
IBX18 BLOQUEADA; IBX61/65 NOVA com ACK sem INSTANCE-ID.
Próxima operação LEGÍTIMA: alocação de instância somente pela sequência ID-COMESTRE-01,
prova de STOP-ACK/fencing técnico do I0011, claim de touch-set sem colisão,
REGISTRO ANTES, intervenção mínima/condicional em objeto existente, reopen/verify,
REGISTRO DEPOIS, REPA, NAC-NORM quando aplicável, NAC-PASS apropriado.
Não reivindicar autor, writer, epoch ou lease com base nesta nota.
Arquivar o ZIP na Biblioteca Mestre-side não equivale a sincronização com o Notion.
''')
print('REPORTS GENERATED',len(list(D.iterdir())))
if __name__=='__main__':pass
