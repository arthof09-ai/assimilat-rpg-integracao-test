#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 INICIAR_VHAL_ZORYN.py
