"""Proportional tests for the authorized isolated interface, not NC-05."""
from __future__ import annotations
import copy
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from engine.receptor import GateError, digest
from lab.server import MasterLab, build_server


class LocalLabTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=MasterLab(Path(self.tmp.name))
        c=self.lab.engine.chains['CH-E2E-MY']
        self.payload={'beast':c['source_id'],'drop':c['drop_id'],'resource':c['resource'],'recipe':c['recipe'],
                      'fixture':True,'intent':'MASTER-TEST-INTEGRATION-0001'}
    def tearDown(self):self.tmp.cleanup()
    def test_r09_real_data_reused_without_material_credit(self):
        c=self.lab.catalog()
        self.assertEqual((len(c['beasts']),len(c['resources']),len(c['recipes']),len(c['deltas'])),(10,80,48,17))
        self.assertEqual(len(c['chains']),4)
        self.assertEqual(self.lab.engine.status()['corpus']['quota_positions'],1008)
        self.assertEqual(c['gates']['official_material'],'0/1649')
        self.assertEqual(c['gates']['historical_drop_ids'],50)
        self.assertEqual(c['gates']['additional_proposed_positions'],150)
        self.assertEqual(self.lab.state_view()['official_writes'],0)

    def test_all_four_preserved_chain_adapters_can_commit(self):
        for key, c in self.lab.engine.chains.items():
            self.lab=MasterLab(Path(self.tmp.name)/key)
            q={'beast':c['source_id'],'drop':c['drop_id'],'resource':c['resource'],'recipe':c['recipe'],
               'fixture':True,'intent':'MASTER-'+key+'-RUN-00001'}
            receipt=self.lab.execute(q)
            self.assertEqual(receipt['status'],'COMMITTED_SANDBOX_ONLY',receipt)
            self.assertEqual(receipt['receipt']['official_material_credit'],0)
            self.assertEqual(receipt['journal_validation']['verified'],True)

    def test_missing_bridge_fails_without_fabrication(self):
        payload={**self.payload,'drop':'UAT-B-D03B'}
        before=self.lab.state_view()['state_hash']
        response=self.lab.execute(payload)
        self.assertEqual(response['status'],'REJECTED')
        self.assertEqual(response['code'],'NO_DOCUMENTED_DROP_RESOURCE_BRIDGE')
        self.assertEqual(self.lab.state_view()['state_hash'],before)
        self.assertEqual(self.lab.state_view()['processed_txns_current_branch'],0)

    def test_official_and_unapproved_fixture_blocked(self):
        response=self.lab.execute({**self.payload,'fixture':False})
        self.assertEqual(response['code'],'DOCUMENTARY_MODE_ONLY')
        self.assertEqual(self.lab.state_view()['official_writes'],0)

    def test_bom_precedence_from_original_recipe(self):
        out=self.lab.inspect(**{k:self.payload[k] for k in ['beast','drop','resource','recipe']},fixture=True)
        self.assertEqual(out['trace']['recipe_ingredient_ids'],['RV-PAN-H01','RV-PAN-O01','RV-PAN-O04'])
        self.assertEqual(out['trace']['synthetic_edges'],3)
        self.assertTrue(out['can_execute_local_fixture'])

    def test_scenario_a_commit_receipt_and_frozen_record(self):
        out=self.lab.execute(self.payload)
        self.assertEqual(out['status'],'COMMITTED_SANDBOX_ONLY')
        self.assertEqual(out['receipt']['produced_synthetic_total'],1)
        self.assertEqual(out['receipt']['sold_synthetic_total'],1)
        self.assertEqual(len(out['receipt']['resource_remaining_fixture']),3)
        self.assertEqual(self.lab.state_view()['processed_txns_current_branch'],1)
        self.assertEqual(self.lab.state_view()['journal_validation']['events'],out['receipt']['event_count_for_intent'])
        self.assertEqual(self.lab.state_view()['official_writes'],0)
        self.assertTrue((Path(self.tmp.name)/'FIXTURE-R09-LIVE.json').exists())
        self.assertEqual(MasterLab(Path(self.tmp.name)).state_view()['state_hash'],self.lab.state_view()['state_hash'])

    def test_scenario_b_missing_unlinked_rv_and_fault_do_not_change_state(self):
        before=self.lab.state_view()['state_hash']
        response=self.lab.execute({**self.payload,'resource':'RV-BOS-M02'})
        self.assertEqual(response['code'],'RV_NOT_IN_RECIPE_BOM')
        self.assertEqual(self.lab.state_view()['state_hash'],before)
        response=self.lab.execute({**self.payload,'fault':'POSTSTAGE_FAIL'})
        self.assertEqual(response['code'],'POSTSTAGE_FAIL')
        self.assertEqual(self.lab.state_view()['state_hash'],before)

    def test_scenario_c_replay_no_double_count_and_restore(self):
        h0=self.lab.state_view()['state_hash']
        a=self.lab.execute(self.payload)
        h1=self.lab.state_view()['state_hash']
        b=self.lab.execute(self.payload)
        self.assertEqual(b['status'],'IDEMPOTENT_REPLAY_NO_SECOND_EFFECT')
        self.assertEqual(self.lab.state_view()['state_hash'],h1)
        self.assertEqual(self.lab.state_view()['processed_txns_current_branch'],1)
        restore=self.lab.restore({'snapshot_id':a['rollback_snapshot']})
        self.assertEqual(restore['status'],'RESTORED_LOCAL_FIXTURE')
        self.assertEqual(self.lab.state_view()['state_hash'],h0)
        self.assertEqual(MasterLab(Path(self.tmp.name)).state_view()['state_hash'],h0)
        self.assertEqual([a['kind'] for a in self.lab.state_view()['local_history']],['COMMIT','REPLAY','RESTORE'])

    def test_conflicting_replay_is_denied(self):
        self.lab.execute(self.payload)
        before=self.lab.state_view()['state_hash']
        x=self.lab.execute({**self.payload,'resource':'RV-BOS-M02'})
        self.assertEqual(x['status'],'REJECTED')
        # Native engine's conflicting intent must also fail closed, rather than dedupe incorrectly.
        with self.assertRaises(GateError) as cm:
            self.lab.engine.execute('CH-E2E-AU',fixture=True,intent=self.payload['intent'])
        self.assertEqual(cm.exception.code,'IDEMPOTENCY_CONFLICT')
        self.assertEqual(self.lab.state_view()['state_hash'],before)

    def test_corrupted_local_state_cannot_be_reopened(self):
        self.lab.execute(self.payload)
        live=Path(self.tmp.name)/'FIXTURE-R09-LIVE.json'
        data=json.loads(live.read_text(encoding='utf-8'))
        data['state']['official_write_count']=99
        live.write_text(json.dumps(data),encoding='utf-8')
        with self.assertRaises(GateError):MasterLab(Path(self.tmp.name))


class HttpFunctionalTests(LocalLabTests):
    def setUp(self):
        super().setUp()
        self.server=build_server(self.lab,port=0)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.base=f'http://127.0.0.1:{self.server.server_address[1]}'
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=4)
        super().tearDown()
    def _call(self,method,path,data=None,token=True):
        req=urllib.request.Request(self.base+path,method=method,
            data=json.dumps(data).encode('utf8') if data is not None else None,
            headers={'X-VZ-Token':self.lab.token if token else 'INVALID','Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=3) as r:return r.status,json.loads(r.read())
        except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
    def test_http_full_human_ui_backend_scenarios(self):
        with urllib.request.urlopen(self.base+'/',timeout=3) as r:
            text=r.read().decode('utf8')
        self.assertIn(self.lab.token,text)
        self.assertIn('Configure sua cadeia',text)
        status,c=self._call('GET','/api/catalog')
        self.assertEqual(status,200)
        self.assertEqual(len(c['beasts']),10)
        status,inp=self._call('GET','/api/inspect?'+urllib.parse.urlencode({**self.payload,'fixture':'true'}))
        self.assertEqual(status,200);self.assertTrue(inp['can_execute_local_fixture'])
        status,result=self._call('POST','/api/execute',self.payload)
        self.assertEqual((status,result['status']),(200,'COMMITTED_SANDBOX_ONLY'))
        status,replay=self._call('POST','/api/execute',self.payload)
        self.assertEqual((status,replay['status']),(200,'IDEMPOTENT_REPLAY_NO_SECOND_EFFECT'))
        status,state=self._call('GET','/api/state')
        self.assertEqual((status,state['processed_txns_current_branch']),(200,1))
        status,restore=self._call('POST','/api/restore',{'snapshot_id':result['rollback_snapshot']})
        self.assertEqual((status,restore['status']),(200,'RESTORED_LOCAL_FIXTURE'))
        status,state=self._call('GET','/api/state')
        self.assertEqual(state['processed_txns_current_branch'],0)
    def test_http_post_without_token_rejected(self):
        status,r=self._call('POST','/api/execute',self.payload,token=False)
        self.assertEqual((status,r['error']),(403,'INVALID_CSRF_TOKEN'))
        self.assertEqual(self.lab.state_view()['official_writes'],0)


if __name__=='__main__':unittest.main()
