# VHAL-ZORYN · Laboratório Experimental do Mestre (FUSION-E3)

**Ferramenta funcional local.** Abre no navegador, não exige editar código, não acessa Notion e não altera fichas oficiais. Usa o **motor original R09** e os arquivos documentais recuperados do R11. A primeira operação produz um resultado **somente de laboratório**.

## Começar em menos de um minuto

1. **Extraia o ZIP inteiro** para uma pasta no computador (não abra o `.py` de dentro do ZIP).
2. Instale Python 3.10 ou superior caso ainda não tenha: [python.org](https://www.python.org/downloads/). No Windows, habilite "Add Python to PATH".
3. **Windows:** abra `INICIAR_NO_WINDOWS.bat` (ou execute `py -3 INICIAR_VHAL_ZORYN.py` no terminal).
   **macOS/Linux:** no terminal, na pasta extraída: `python3 INICIAR_VHAL_ZORYN.py`.
4. Uma página será aberta automaticamente no navegador. Se isso não acontecer, abra **http://127.0.0.1:8765/**. Não é necessário configurar ambiente, credencial, banco de dados nem servidor externo.
5. Para sair, retorne ao terminal e pressione **Ctrl+C**. Para continuar mais tarde, inicie de novo: o estado local foi preservado em `runtime/`.

**Dependências:** somente Python e sua biblioteca padrão. O navegador pode ser Chrome, Firefox, Edge ou Safari. Se a porta 8765 estiver ocupada, rode `python INICIAR_VHAL_ZORYN.py --port 8766` e abra a porta indicada. A ferramenta somente escuta em `127.0.0.1`; não hospede a pasta em serviço público.

## Primeira operação (cenário A)

O formulário já abre no primeiro caso recomendado:

1. **Besta:** Cervo Ferrolunar (`UAT-B-B03` / `B-VZ-PAN-01`).
2. **Drop:** Galhada de Ferro Vivo (`UAT-B-D03A`).
3. **Recurso:** Junco de Lua Ferrosa (`RV-PAN-H01`).
4. **Receita:** Manto Ferrolunar (`RC-VZ-PAN-01`).
5. Leia a seção **Rastreamento da cadeia**. Antes de marcar a opção de fixture, a ferramenta identifica a relação drop→recurso como não comprovada.
6. Marque **Permitir pontes fictícias apenas nesta execução**.
7. Clique em **Executar operação**. O motor R09 consome insumos fictícios, produz e comercializa um item fictício, vincula à loja de Myr-Zoryn, registra os eventos e emite um recibo com hashes.
8. Clique em **Exportar recibo JSON** para guardar o resultado.

**Importante:** os três insumos são os da **BOM original da receita**, não uma quantidade canônica: `RV-PAN-H01 + RV-PAN-O01 + RV-PAN-O04`. A fixture começa com duas unidades sintéticas por insumo e consome uma de cada. Não há quantidade material, estoque, preço, ITEM-ID ou OFFER-ID oficial. O vínculo drop→RV é inteiramente *sintético*, por isso o programa não afirma que o drop se converte realmente nesse recurso.

## Cenário B — ausência ou falha controlada

Sem mudar de Besta, selecione o drop **Pelo de Lua Ferrosa** (`UAT-B-D03B`). A aplicação apresenta `NO_DOCUMENTED_DROP_RESOURCE_BRIDGE` e recusa a operação: não inventa associação para completar a cadeia.

Para provocar uma falha transacional sobre a cadeia suportada, volte a **Galhada de Ferro Vivo**, mantenha a fixture marcada, gere uma **nova intenção** (ícone ↻), ative **Simular falha pós-estágio**, e clique em Executar. O motor responde `POSTSTAGE_FAIL` e não altera o estoque nem o journal confirmado.

## Cenário C — replay e restauração

Depois de uma operação bem-sucedida:

- **Repetir mesma intenção:** retorna o recibo já existente. O número de transações e o hash do estado não aumentam (`IDEMPOTENT_REPLAY_NO_SECOND_EFFECT`).
- **Restaurar estado local:** escolha o ponto **Antes de...** e clique para restaurar. A ferramenta carrega e valida o snapshot R09 e grava o estado restaurado. As operações registradas no histórico de auditoria local não são apagadas. Nunca há rollback oficial porque nenhum estado oficial foi alterado.

Gerar uma intenção **nova** é diferente de repetir a mesma intenção; uma nova operação pode consumir mais estoque fictício. O cenário inicial comporta até duas operações novas consecutivas por receita antes de `SOURCE_STOCK_EXHAUSTED`, que também é controlado.

## Dados recuperados e escopo funcional

- Motor **`engine/receptor.py` do R09**, reutilizado sem alteração; em `engine/` também estão os demais módulos existentes do R09.
- Fontes originais congeladas: R08 dentro de R09, que contém R07 (e sua linhagem anterior), além de índices E3 e quatro cadeias demonstrativas.
- A interface expõe **10 Bestas históricas diretamente identificadas no receptor R09**, cada uma com cinco IDs históricos de drop; **4 combinações** possuem adaptadores R09 para cadeia com fixture; as outras podem ser consultadas, mas não recebem vínculos fabricados.
- Índices locais disponíveis: 80 RV; 48 RC, 143 ligações RV→RC; 1.008 posições comerciais, sendo 119 candidatas; 56 posições loja×família; D01–D17 indexadas.
- As **40 Bestas planejadas de Vhal-Zoryn**, os **50 drops históricos** e as **150 posições adicionais propostas** são categorias distintas. A interface NÃO transforma os 150 candidatos em drops existentes, não cria 41ª Besta, não cria oficiais nem acresce 1.649 UAT.
- `arquivo_historico/R11_ORIGINAL_IMUTAVEL.zip` preserva o pacote R11 original, incluindo R10→R09→R08→R07. Não é usado como segundo receptor de runtime.

## Fontes, proveniência e limitações

Cada cadeia executável conserva os oito estágios `BEAST → DROP → RESOURCE → RECIPE → ITEM → COMMERCE → CITY → REGION`, porém suas **sete relações** não são todas canônicas: são **quatro arestas documentais e três sintéticas** na fixture. O painel marca cada uma. Um ITEM e OFFER de fixture possuem o prefixo reservado `FIXTURE-R09-`.

Os parâmetros de estoque e quantidades da fixture não são regras canônicas de fabricação. A aplicação é uma demonstração de processamento de dados e transações locais, não uma economia oficial homologada. A consulta é baseada em snapshots de Notion previamente arquivados, **não numa sincronização ao vivo**. Para receber novos dados no futuro, exigir adaptador de leitura com proveniência e autorização próprios, jamais promover fixture automaticamente.

**Estados oficiais preservados:** NC-05 original 0/16 critérios individuais recuperados, resultado histórico 11/16 agregado com voto CORREÇÕES NECESSÁRIAS; ABS-A–K 3 PASS/4 PARCIAL/4 FAIL; ABS-L DENY; T16 PENDING-READBACK; consumidores certificados 0/13; classes oficiais absorvidas 0/17; materialização 0/1.649; NAC-PASS arquitetural HOLD; scheduler DO-NOT-ARM. Não reivindicamos escrita ou identidade I0012.

## Arquivos e reprodução técnica (opcional)

- **Entrada única para utilização:** `INICIAR_VHAL_ZORYN.py`.
- `lab/server.py` contém o adaptador HTTP local, persistência e verificação sem novos motores de regras.
- `lab/static/` contém HTML/CSS/JS, sem serviços externos.
- `engine/` e `data/` são cópias byte-a-byte dos arquivos existentes no R09. `arquivo_historico/` é a prova histórica imutável.
- `runtime/` é criado na primeira execução, somente no computador local. Contém snapshots `FIXTURE-R09-BEFORE-*`, arquivo atual `FIXTURE-R09-LIVE.json` e journal UI `FIXTURE-R09-OPLOG.jsonl`.
- `evidencias/PROVA_PONTA_A_PONTA.json` documenta execução real da API HTTP local A/B/C, inclusive hashes, erros e readback após reinicialização.
- `evidencias/INTERFACE_*.png` são capturas da interface renderizada em navegador durante o percurso; a automação visual foi ligada ao backend local por uma ponte de teste porque o Chromium deste ambiente bloqueia navegação direta para localhost. A API HTTP real foi testada separadamente por HTTP direto.
- `python -m scripts.provar_operacao` reproduz os três cenários em diretório temporário sem tocar sua sessão. Este comando é **somente para desenvolvedores**, não exigido para jogar/operar.
- `python -m unittest discover -s tests -v` valida as proteções da interface. A suíte original R09 de 56 testes também foi executada sem alteração.

## Próximos passos, somente quando houver benefício funcional

**P1:** ampliar adaptadores para mais Bestas/cadeias **com identidades, BOM e relações comprovadas**; exportar relatórios agregados das operações experimentais; opção de operador P1 que utilize `prepare_p1` do motor sem regra de dano.

**P2:** resolver oficialmente NC-05, T16, writer/exclusividade, Runbook e ABS-L em canais preexistentes; somente então discutir integração produtiva. As minutas permanecem no R11 original. Nenhuma nova solicitação equivalente foi criada nesta entrega.
