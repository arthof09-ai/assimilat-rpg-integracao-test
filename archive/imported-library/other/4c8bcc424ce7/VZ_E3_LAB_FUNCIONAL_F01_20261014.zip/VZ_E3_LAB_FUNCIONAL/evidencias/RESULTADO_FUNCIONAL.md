# Evidência de entrega funcional FUSION-E3 — Interface do Mestre

## Objeto entregue

Uma aplicação web local que executa o motor **`R09/engine/receptor.py`** recuperado do R11 sem alterar seu código, com selectors humanos de Besta/drop/RV/RC, inspeção de proveniência, transações fixture event-sourced, recibos, replay idempotente e restauração em disco.

## Antes → Depois

| Dimensão | Antes (R11) | Depois (entrega experimental) |
|---|---|---|
| Motor R09 E3 | Operável por CLI com comandos e parâmetros | **Operável por interface web local** |
| Besta/drop | 10 Bestas legadas indexadas, 5 drops históricos por exemplo | 10 selecionáveis e detalhes visíveis na interface |
| Recursos/receitas | 80 RV, 48 RC e 143 arestas BOM em CSV | 80 RV e 48 RC selecionáveis; BOM consultável |
| Cadeias | Quatro exemplos R09 programáveis via flags CLI | Quatro combinações suportadas selecionáveis sem código |
| Execução | R09 execute em RAM + snapshot manual | Botão Executar com intenção gerada na interface; snapshot automático por commit |
| Recibo | JSON via CLI | Recibo na página e exportação JSON |
| Replay | CLI com mesma intenção | Botão Repetir mesma intenção |
| Rollback | R09 load_fixture_state() via script | Botão Restaurar estado local com snapshot validado |
| Falha | GateError via CLI | Motivo de falha legível e sem efeito |
| Persistência | `save_fixture_state()` / `load_fixture_state()` isolados | Estado salvo automaticamente em `runtime/` e reaberto ao reiniciar |
| FUSION-E3 oficial | 0/1649; NC05 negativa; T16 pendente | **Sem mudanças** |

## Cenário A — resultado real do programa experimental

- `CH-E2E-MY` — `UAT-B-B03` Cervo Ferrolunar → `UAT-B-D03A` Galhada de Ferro Vivo → *ponte fixture explicitamente sintética* → `RV-PAN-H01` Junco de Lua Ferrosa → `RC-VZ-PAN-01` Manto Ferrolunar → `FIXTURE-R09-ITEM::RC-VZ-PAN-01` → `FIXTURE-R09-OFFER::STORE-VZ-MY-01::Roupas::001` → Myr-Zoryn → Pântano da Lua Ferrosa.
- A BOM efetiva usou `RV-PAN-H01 + RV-PAN-O01 + RV-PAN-O04` (documentária), sem alterar a receita.
- Resultado `COMMITTED_SANDBOX_ONLY`: item fictício produzido=1, venda fictícia=1, estoque fictício dos três RV após=1/unidade cada, journal do R09 com **12 eventos** e hash encadeado validado, oficial=0.

## Cenário B — falha controlada

- Selecionando drop `UAT-B-D03B` sem adaptador: `NO_DOCUMENTED_DROP_RESOURCE_BRIDGE` e 0 alteração do estado.
- Falha `POSTSTAGE_FAIL`: simula parada após montagem em memória, antes do commit; mesmo SHA-256 de estado antes/depois, sem débito.

## Cenário C — repetição / restauração

- Mesmo intent: `IDEMPOTENT_REPLAY_NO_SECOND_EFFECT`; hash não mudou e contagem continuou 1.
- Rollback do snapshot ANTES: `RESTORED_LOCAL_FIXTURE`; hash do estado restaurado igual ao hash inicial e contagem voltou a 0. O diário UI retém `COMMIT`, `REPLAY`, `RESTORE`.

## O que ainda falta — sem confundir funcional com oficial

1. **Aresta drop→RV** não atestada cientificamente: somente fixture. Não existe transformação material drop→recurso.
2. **ITEM-ID e OFFER-ID** de produção não comprovados: dois identificadores artificiais de fixture.
3. 40 Bestas planejadas: a GUI expõe somente os 10 exemplares legados efetivamente empacotados no receptor R09; ampliar exigirá crosswalk de fonte, não geração arbitrária de espécie.
4. D01–D17: 17 classes indexadas não equivalem a 17 engines mecânicos executados. Matriz individual em `D01_D17_REUTILIZACAO_EPISTEMICA.csv`.
5. Documentário E3 em cache, não sincronização Notion. NC05/ABS-A–L/T16/autoridade e admission permanecem inalterados.

**Prova máquina a máquina:** `PROVA_PONTA_A_PONTA.json`; execução real em servidor HTTP loopback com testes A/B/C, incluindo reinicialização fria e readback dos hashes. Screenshots `INTERFACE_*.png` são do frontend browser sob ponte de teste para o HTTP local, porque a política do navegador automatizado deste ambiente impede navegar diretamente no localhost; isso não afeta o aplicativo quando executado normalmente no computador do Mestre.
