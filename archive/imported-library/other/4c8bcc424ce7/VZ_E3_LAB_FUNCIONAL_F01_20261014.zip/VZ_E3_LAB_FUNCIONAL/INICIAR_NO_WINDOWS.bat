@echo off
cd /d "%~dp0"
py -3 INICIAR_VHAL_ZORYN.py
if errorlevel 1 python INICIAR_VHAL_ZORYN.py
pause
