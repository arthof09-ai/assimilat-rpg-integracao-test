'use strict';
const $=id=>document.getElementById(id);
const esc=x=>String(x??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ICONS=['♞','◇','♧','⚗','✦','▤','⌂','◈'];
const KINDS=['Besta','Drop','Recurso','Receita','Item','Comércio','Cidade','Região'];
let catalog=null,lastInspect=null,lastReceipt=null,lastState=null,lastSelection='',busy=false;
const initialBeast='UAT-B-B03';
const headers={'Content-Type':'application/json','X-VZ-Token':document.querySelector('body')?.dataset?.token||'__LAB_TOKEN__'};
async function getJson(path){const r=await fetch(path,{cache:'no-store'});const x=await r.json();if(!r.ok)throw Error(x.message||x.error||r.status);return x;}
async function postJson(path,obj){const r=await fetch(path,{method:'POST',headers,body:JSON.stringify(obj)});const x=await r.json();return x;}
function option(value,label){const el=document.createElement('option');el.value=value;el.textContent=label;return el;}
function populate(el,rows,value,labeler,placeholder){el.replaceChildren();if(placeholder)el.append(option('',placeholder));for(const r of rows)el.append(option(value(r),labeler(r)));}
function beastData(){return catalog?.beasts.find(b=>b.id===$('beast').value);}
function preferredChain(beast,drop){return catalog?.chains.find(c=>c.source_id===beast&&c.drop_id===drop);}
function newIntent(){const rnd=(globalThis.crypto?.randomUUID?.()||String(Date.now())+'-'+Math.random().toString(36).slice(2));$('intent').value='MASTER-LAB-'+rnd.slice(0,25);}
function onBeastChange(){const b=beastData();if(!b)return;
 const chain=catalog.chains.find(c=>c.source_id===b.id);
 populate($('drop'),b.drops,r=>r.id,r=>`${r.name} · ${r.id}`);
 if(chain)$('drop').value=chain.drop_id;
 $('beast-info').innerHTML=`ID documental: <b>${esc(b.canonical_id||'pendente')}</b> · ${b.drops.length} drops históricos · <a href="${esc(b.documentary_source)}" target="_blank" rel="noopener noreferrer">Fonte ↗</a>`;
 onDropChange();
}
function onDropChange(){const c=preferredChain($('beast').value,$('drop').value);
 if(c){$('resource').value=c.resource;$('recipe').value=c.recipe;}
 else {$('resource').value='';$('recipe').value='';}
 onSelectionChange();
}
function onResourceChange(){const rv=$('resource').value;
 const current=catalog.recipes.find(r=>r.id===$('recipe').value);
 if(rv && (!current || !current.ingredients.includes(rv))){const suggested=catalog.recipes.find(r=>r.ingredients.includes(rv));$('recipe').value=suggested?.id||'';}
 onSelectionChange();
}
function getSelection(){return{beast:$('beast').value,drop:$('drop').value,resource:$('resource').value,recipe:$('recipe').value,fixture:$('fixture').checked};}
function onSelectionChange(){let r=catalog.recipes.find(x=>x.id===$('recipe').value);
 $('recipe-bom').textContent=r?`BOM recuperada: ${r.ingredients.join(' + ')} · ${r.store_id}`:'Selecione uma receita; o banco preserva 48 propostas documentais.';
 clearTimeout(onSelectionChange.timeout);
 onSelectionChange.timeout=setTimeout(inspect,70);
}
async function inspect(){if(!catalog)return;let selection=getSelection();const q=new URLSearchParams(Object.entries(selection).map(([k,v])=>[k,String(v)]));
 try{const data=await getJson('/api/inspect?'+q);lastInspect=data;renderInspect(data);}
 catch(e){$('dependency').innerHTML=`<span class="depitem">Falha na consulta: ${esc(e.message)}</span>`;}
}
function renderInspect(data){const nodes=data.trace?.nodes||[];
 const fallback=[data.documentary.beast,data.documentary.drop,data.documentary.resource,data.documentary.recipe,{}, {},{},{ }];
 const safeKind=(node,i)=>node?.name||node?.id||(['','','','','ITEM-ID ausente','OFFER-ID ausente','Cidade: dependente','Região: dependente'][i])||'Indisponível';
 const raw=data.trace?nodes:fallback;
 let html='';for(let i=0;i<8;i++){
  let node=raw[i]||{},kind=KINDS[i],id=node.id||node.canonical_id||(i===0?data.selection.beast:''),name=safeKind(node,i);
  if(i===0 && data.documentary.beast?.name){name=data.documentary.beast.name;id=data.documentary.beast.canonical_id||data.documentary.beast.id;}
  if(i===1 && data.documentary.drop?.name){name=data.documentary.drop.name;id=data.documentary.drop.id;}
  if(i===2 && data.documentary.resource?.name){name=data.documentary.resource.name;id=data.documentary.resource.id;}
  if(i===3 && data.documentary.recipe?.name){name=data.documentary.recipe.name;id=data.documentary.recipe.id;}
  const epi=node.epistemic||'';
  let cls=(i===4||i===5)?'fixture':'verified';if(!data.trace&&i>=4)cls='missing';if(data.trace&&i===1&&node.material==='BLOCKED-BEAST')cls='verified';
  if(data.trace&&!data.trace.fixture_enabled&&(i===4||i===5))cls='missing';
  html+=`<div class="stage"><div class="stage-icon ${cls}">${ICONS[i]}</div><div class="stage-label ${cls}">${kind}</div><div class="stage-name">${esc(name)}</div><div class="stage-id">${esc(id||'SEM ID OFICIAL')}</div></div>`;
 }
 $('journey').innerHTML=html;
 $('chainBadge').textContent=data.can_execute_local_fixture?'EXECUTÁVEL • FIXTURE':data.matched_reusable_r09_chain?'CADEIA PARCIAL DOCUMENTAL':'SEM ADAPTADOR R09';
 $('chainBadge').className='pill '+(data.can_execute_local_fixture?'pill-proposed':data.blocking_dependencies.length?'pill-blocked':'pill-neutral');
 $('btnRun').disabled=!data.can_execute_local_fixture;
 $('btnReplay').disabled=!data.can_execute_local_fixture;
 let deps=data.blocking_dependencies;
 if(!deps.length){$('dependency').innerHTML=`<span class="depitem good">✓ Associação documental e adaptador ${esc(data.matched_reusable_r09_chain)} recuperados. A ponte drop → RV, ITEM-ID e OFFER-ID continuam sintéticos.</span>`;}
 else $('dependency').innerHTML=deps.map(d=>`<span class="depitem">${esc(d.code)} — ${esc(d.detail)}</span>`).join('');
 let details=[];const t=data.trace;
 if(t){details.push('<div class="edge-head">Arestas e proveniência do motor original</div><div class="edge-table">');
  for(const edge of t.edges){const flag=edge.state.startsWith('SYNTHETIC')?'<b>FIXTURE</b>':edge.state.startsWith('DOCUMENTARY')?'DOCUMENTAL':'PENDENTE';
   const src=edge.source||'—';details.push(`<div class="edge-row"><span>${esc(edge.kind)} <small>(${flag})</small></span><span>${esc(src)} → ${esc(edge.target)}<div style="font-size:10px;margin-top:2px;color:#9bb1c1">${esc(edge.state)} · ${edge.reference?.startsWith('https://')?`<a href="${esc(edge.reference)}" target="_blank" rel="noopener noreferrer">Fonte ↗</a>`:esc(edge.reference)}</div></span></div>`);}
  details.push('</div>');
  details.push(`<div class="source-line">BOM efetiva da receita: ${esc(t.recipe_ingredient_ids.join(' + '))}. Arestas documentais: ${t.verified_documentary_edges}; sintéticas: ${t.synthetic_edges}; não validadas: ${t.unverified_edges}. Nenhum crédito material.</div>`);
 }else{
  details.push(`<div class="edge-head">Consulta permitida sem inferir relações</div>`);
  if(data.documentary.recipe?.bom?.length){const d=data.documentary.recipe;details.push(`<div class="source-line">A BOM da receita ${esc(d.id)} contém ${esc(d.bom.join(' + '))}. Fonte: <a href="${esc(d.source)}" target="_blank" rel="noopener noreferrer">Documento de receita ↗</a>. Isto não implica relação com a Besta/drop.</div>`);}
  else details.push(`<div class="source-line">A associação exigida não foi encontrada no índice R09. Escolha um dos quatro modelos recuperados ou mantenha somente a consulta documental.</div>`);
 }
 $('details').innerHTML=details.join('');
}
function drawReceipt(result){lastReceipt=result;
 let good=['COMMITTED_SANDBOX_ONLY','IDEMPOTENT_REPLAY_NO_SECOND_EFFECT','RESTORED_LOCAL_FIXTURE'].includes(result.status),type=good?'ok':'fail';
 const label=({COMMITTED_SANDBOX_ONLY:'OPERAÇÃO EXPERIMENTAL CONFIRMADA',IDEMPOTENT_REPLAY_NO_SECOND_EFFECT:'REPLAY SEM SEGUNDO EFEITO',RESTORED_LOCAL_FIXTURE:'ESTADO EXPERIMENTAL RESTAURADO'})[result.status]||'PROCESSAMENTO RECUSADO';
 let x=`<h3>${good?'✓':'!'} ${label}</h3>`;
 if(result.receipt || result.original_receipt){const r=result.receipt||result.original_receipt;
  x+=`<dl><div><dt>INTENÇÃO</dt><dd>${esc(r.intent)}</dd></div><div><dt>ITEM (SINTÉTICO)</dt><dd>${esc(r.synthetic_item_id)}</dd></div><div><dt>OFERTA (SINTÉTICA)</dt><dd>${esc(r.synthetic_offer_id)}</dd></div><div><dt>GERADO / VENDIDO FICTÍCIO</dt><dd>${esc(r.produced_synthetic_total)} / ${esc(r.sold_synthetic_total)}</dd></div><div><dt>EVENTOS DA INTENÇÃO</dt><dd>${esc(r.event_count_for_intent)}</dd></div><div><dt>UAT OFICIAL</dt><dd>0</dd></div></dl>`;
  x+=`<p>Saldo experimental dos insumos: ${esc(Object.entries(r.resource_remaining_fixture||{}).map(([k,v])=>`${k}: ${v}`).join(' · '))}</p>`;
  x+=`<p class="hash">Cabeça do journal: ${esc(r.journal_head)}</p>`;
  if(result.status==='IDEMPOTENT_REPLAY_NO_SECOND_EFFECT')x+='<p>A mesma intenção e os mesmos parâmetros devolveram o recibo original, sem criar outro item nem debitar insumos.</p>';
 }else if(result.status==='RESTORED_LOCAL_FIXTURE'){
  x+=`<p>A cópia anterior foi restaurada. Journal e saldo foram revalidados pelo motor R09.</p>`;
 }else{
  x+=`<p>${esc(result.code||result.error||'FALHA')} — ${esc(result.reason||result.message||'Não existe adaptador ou requisito para esta transação.')}</p>`;
  for(const d of (result.dependencies||[]))x+=`<p>${esc(d.detail||d)}</p>`;
 }
 x+=`<p class="hash">BEFORE: ${esc(result.before_state_hash||'sem mutação')}<br>AFTER: ${esc(result.after_state_hash||result.state_hash||'sem mutação')}</p>`;
 x+='<button class="textbutton" id="downloadReceipt">Exportar recibo JSON ↗</button>';
 $('receipt').className='receipt '+type;$('receipt').innerHTML=x;
 $('downloadReceipt').addEventListener('click',()=>downloadFile('RECIBO-VZ-EXPERIMENTAL.json',result));
}
async function execute(){if(busy)return;busy=true;$('btnRun').disabled=true;try{
 const req={...getSelection(),intent:$('intent').value,fault:$('fault').checked?'POSTSTAGE_FAIL':null};
 const result=await postJson('/api/execute',req);drawReceipt(result);await refreshState();
 }catch(e){drawReceipt({status:'REJECTED',code:'NETWORK_OR_APP_ERROR',reason:e.message});}
 finally{busy=false;if(lastInspect)renderInspect(lastInspect);}
}
async function replay(){if(busy)return;$('fault').checked=false;await execute();}
async function refreshState(){let s=await getJson('/api/state');lastState=s;
 $('txnCount').textContent=s.processed_txns_current_branch;$('eventCount').textContent=s.journal_validation.events;$('officialWrites').textContent=s.official_writes;
 $('stateHash').textContent='Estado '+s.state_hash.slice(0,14)+'…';
 const old=$('snapshots').value;populate($('snapshots'),s.snapshots,x=>x.id,x=>x.label,s.snapshots.length?'':'Nenhum ponto anterior');
 if(s.snapshots.some(x=>x.id===old))$('snapshots').value=old;
 $('btnRestore').disabled=!s.snapshots.length;
 $('historyList').innerHTML=s.local_history.length?s.local_history.slice().reverse().slice(0,22).map(e=>`<div class="history-entry"><span><b>${esc(e.kind)}</b><small>${esc(e.utc)} · ${esc(e.intent||e.snapshot_id||'restauração')}</small></span><em>${esc((e.after||'').slice(0,18))}…</em></div>`).join(''):'<div class="emptylist">Nenhuma operação local persistida ainda. Você pode explorar o corpus sem executar nada.</div>';
}
async function restore(){if(busy||!$('snapshots').value)return;if(!confirm('Restaurar somente o estado experimental desta cópia? Nenhuma ficha oficial será alterada.'))return;
 busy=true;$('btnRestore').disabled=true;
 try{const out=await postJson('/api/restore',{snapshot_id:$('snapshots').value});drawReceipt(out);await refreshState();}
 catch(e){drawReceipt({status:'REJECTED',code:'RESTORE_ERROR',reason:e.message});}
 finally{busy=false;}
}
function downloadFile(name,obj){let blob=new Blob([JSON.stringify(obj,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function connectEvents(){
 $('beast').addEventListener('change',onBeastChange);$('drop').addEventListener('change',onDropChange);
 $('resource').addEventListener('change',onResourceChange);$('recipe').addEventListener('change',onSelectionChange);
 $('fixture').addEventListener('change',onSelectionChange);$('btnInspect').addEventListener('click',inspect);
 $('btnNewIntent').addEventListener('click',newIntent);$('btnRun').addEventListener('click',execute);
 $('btnReplay').addEventListener('click',replay);$('btnRefresh').addEventListener('click',refreshState);
 $('btnRestore').addEventListener('click',restore);
 $('btnDownloadState').addEventListener('click',()=>downloadFile('VZ-ESTADO-EXPERIMENTAL.json',{exported_at:new Date().toISOString(),...lastState}));
}
async function initialize(){try{
 // Token supplied by HTML page, not by the public JS asset.
 const meta=document.querySelector('meta[name="vz-token"]');headers['X-VZ-Token']=meta?.content||'';
 catalog=await getJson('/api/catalog');
 populate($('beast'),catalog.beasts,b=>b.id,b=>`${b.name} · ${b.canonical_id||'ID pendente'}`);
 populate($('resource'),catalog.resources,r=>r.id,r=>`${r.name} · ${r.id}`,'Selecione um recurso (sem inferência)');
 populate($('recipe'),catalog.recipes,r=>r.id,r=>`${r.name} · ${r.id}`,'Selecione uma receita');
 $('beast').value=initialBeast;connectEvents();newIntent();onBeastChange();await refreshState();
 }catch(e){document.querySelector('.workspace').innerHTML=`<div class="depitem">O motor local não iniciou: ${esc(e.message)}. Verifique o pacote e seu ZIP histórico.</div>`;}
}
initialize();
