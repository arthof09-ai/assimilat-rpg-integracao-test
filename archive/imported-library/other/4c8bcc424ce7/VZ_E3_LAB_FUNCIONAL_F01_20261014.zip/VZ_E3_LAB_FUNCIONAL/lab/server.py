"""Vhal-Zoryn FUSION-E3 isolated local master UI adapter over unmodified R09 engine.
No Notion connector, no production writer, no external network client or scheduler.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from engine.receptor import Receiver, GateError, digest, REQUIRED_FP

ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / 'lab' / 'static'
MAX_JSON_BYTES = 16384


def pack(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')


class MasterLab:
    def __init__(self, runtime: Path | None = None):
        self.runtime = Path(runtime or (ROOT / 'runtime')).resolve()
        self.runtime.mkdir(parents=True, exist_ok=True)
        self.snap_dir = self.runtime / 'snapshots'
        self.snap_dir.mkdir(parents=True, exist_ok=True)
        self.live = self.runtime / 'FIXTURE-R09-LIVE.json'
        self.operations = self.runtime / 'FIXTURE-R09-OPLOG.jsonl'
        self.lock = threading.RLock()
        self.engine = Receiver()  # Preexisting R09 motor; authoritative data archives read-only.
        if self.live.exists():
            self.engine.load_fixture_state(self.live)  # Fail closed if tampered.
        self.token = secrets.token_urlsafe(32)

    def _stamp(self):
        return time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '-' + uuid.uuid4().hex[:10]

    def _persist_live(self):
        """R09 validates hashes and refuses overwrites; use temp+atomic local replacement."""
        temp = self.runtime / ('FIXTURE-R09-TMP-' + self._stamp() + '.json')
        try:
            self.engine.save_fixture_state(temp)
            os.replace(temp, self.live)
        finally:
            if temp.exists():
                temp.unlink()

    def _record(self, kind, **data):
        event = {'kind':kind, 'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **data,
                 'official_write_count':0, 'scope':'ISOLATED-MASTER-LAB-ONLY'}
        with self.operations.open('ab') as f:
            f.write((json.dumps(event,ensure_ascii=False,sort_keys=True,separators=(',',':')) + '\n').encode('utf-8'))
            f.flush()
            os.fsync(f.fileno())
        return event

    def _operations(self):
        if not self.operations.exists():
            return []
        # A local journal for UI audit, not an independently authenticated log.
        return [json.loads(line) for line in self.operations.read_text(encoding='utf-8').splitlines() if line.strip()][-100:]

    def catalog(self):
        r = self.engine
        beast = []
        for key, b in r.beast_registry.items():
            ch = [k for k,v in r.chains.items() if v['source_id']==key]
            beast.append({'id':key,'name':b['name'],'canonical_id':b.get('canonical_id'),
                          'drops':[{'id':k,'name':v,'source':b['notion_source'], 'material':'BLOCKED-BEAST'} for k,v in b['drops'].items()],
                          'documentary_source':b['notion_source'],'demo_chains':ch})
        resources = [{'id':x['RESOURCE_ID'],'name':x['NAME']} for x in r.resource_rows]
        recipes = [{'id':x['RC_ID_EXISTING'], 'name':x['PRODUCT_NAME_EXISTING_BLUEPRINT'],
                    'ingredients':x['INGREDIENT_RV_IDS_BLUEPRINT'].split('|'),
                    'store_id':x['STORE_ID_EXISTING'], 'region':x['REGION_OUTPUT'],
                    'source':x['SOURCE_DOCUMENT']} for x in r.recipe_rows]
        return {'beasts':beast,'resources':resources,'recipes':recipes,
                'chains':[{'id':k,**v} for k,v in r.chains.items()],
                'deltas':[{'id':d['id'],'name':d['name'],'consumer':d['receiver_consumer'],'source':d['source_url'],
                           'behavior':d['receiver_behavior']} for d in r.e3['deltas']],
                'gates':{'nc05_original_predicates':'0/16','nc05_historical_aggregate':'11/16',
                         'nc05_vote':'CORREÇÕES NECESSÁRIAS', 'abs_ak':'3 PASS / 4 PARCIAL / 4 FAIL',
                         'abs_l':'DENY', 't16':'PENDING-READBACK', 'consumer_accept':'0/13',
                         'absorbed_classes':'0/17', 'official_material':'0/1649',
                         'scheduler':'DO-NOT-ARM', 'beasts_design':40,'historical_drop_ids':50,
                         'additional_proposed_positions':150}}

    def _match(self, beast, drop, resource, recipe):
        for key, c in self.engine.chains.items():
            if (c['source_id'],c['drop_id'],c['resource'],c['recipe']) == (beast,drop,resource,recipe):
                return key
        return None

    def inspect(self, beast, drop, resource, recipe, fixture=False):
        """No inferred transitions: only R09's four explicitly described chain specs execute."""
        r=self.engine
        problems=[]
        b=r.beast_registry.get(beast)
        rv=r.resource.get(resource)
        rc=r.recipe.get(recipe)
        if b is None:
            problems.append({'code':'UNKNOWN_BEAST','detail':f'Besta {beast!r} ausente do índice histórico R09.'})
        elif drop not in b['drops']:
            problems.append({'code':'DROP_NOT_IN_BEAST','detail':'O drop escolhido não pertence à Besta selecionada.'})
        if rv is None:
            problems.append({'code':'UNKNOWN_RESOURCE','detail':f'Recurso {resource!r} não encontrado nos 80 RV preservados.'})
        if rc is None:
            problems.append({'code':'UNKNOWN_RECIPE','detail':f'Receita {recipe!r} não encontrada nas 48 RC preservadas.'})
        elif rv and resource not in rc['INGREDIENT_RV_IDS_BLUEPRINT'].split('|'):
            problems.append({'code':'RV_NOT_IN_RECIPE_BOM','detail':f'O recurso {resource} não consta da BOM documental da receita {recipe}.'})
        matches=[k for k,c in r.chains.items() if c['source_id']==beast and c['drop_id']==drop]
        if b and drop in b['drops'] and not matches:
            problems.append({'code':'NO_DOCUMENTED_DROP_RESOURCE_BRIDGE',
                             'detail':'Não existe associação recuperada deste drop com RV/receita nos quatro cenários R09. Não é gerada outra relação.'})
        elif b and drop in b['drops'] and matches and not self._match(beast,drop,resource,recipe):
            problems.append({'code':'NO_RECEIVER_ADAPTER_FOR_SELECTED_CHAIN',
                             'detail':'O recurso/receita escolhidos não têm o adaptador exato R09 para esta Besta/drop. O sistema não infere uma nova ponte.'})
        chain=self._match(beast,drop,resource,recipe)
        preview=None
        if chain and not problems:
            try:
                preview=r.trace(chain,bridge=fixture)
            except GateError as exc:
                problems.append({'code':exc.code,'detail':str(exc)})
        if not fixture and not problems and chain:
            problems.append({'code':'DOCUMENTARY_MODE_ONLY',
                             'detail':'O corpus não comprova drop→RV nem ITEM/OFFER material. Marque o modo fixture explícito para executar localmente.'})
        bname=b['name'] if b else None
        documentary={'beast':{'id':beast,'name':bname,'canonical_id':b.get('canonical_id') if b else None,
                             'source':b['notion_source'] if b else None},
                     'drop':{'id':drop,'name':b['drops'].get(drop) if b else None,'material_state':'BLOCKED-BEAST'},
                     'resource':{'id':resource,'name':rv['NAME'] if rv else None,
                                 'source_row':rv if rv else None},
                     'recipe':{'id':recipe,'name':rc['PRODUCT_NAME_EXISTING_BLUEPRINT'] if rc else None,
                               'bom':rc['INGREDIENT_RV_IDS_BLUEPRINT'].split('|') if rc else [],
                               'store':rc['STORE_ID_EXISTING'] if rc else None,
                               'region':rc['REGION_OUTPUT'] if rc else None,
                               'source':rc['SOURCE_DOCUMENT'] if rc else None}}
        return {'selection':{'beast':beast,'drop':drop,'resource':resource,'recipe':recipe,'fixture':bool(fixture)},
                'documentary':documentary,'matched_reusable_r09_chain':chain,
                'candidate_chains_for_drop':matches,'trace':preview,
                'can_execute_local_fixture':bool(chain and fixture and not problems),
                'blocking_dependencies':problems,
                'epistemic_warning':'Associação drop→recurso e IDs ITEM/OFFER são FIXTURES SINTÉTICAS mesmo em execução bem-sucedida.',
                'official_writes':0}

    def state_view(self):
        with self.lock:
            state=self.engine.state
            return {'engine_status':self.engine.status(),
                    'journal_validation':self.engine.validate_event_ledger(),
                    'state_hash':digest(state), 'processed_txns_current_branch':state['processed_txns'],
                    'receipts_current_branch':[v['receipt'] for v in state['idempotency'].values()],
                    'resource_stock_fixture':copy.deepcopy(state['resource_stock']),
                    'local_history':self._operations(),
                    'snapshots':self._snapshots(),
                    'official_writes':0}

    def _snapshots(self):
        return [{'id':x.name,'label':x.stem.replace('FIXTURE-R09-BEFORE-', 'Antes de ')}
                for x in sorted(self.snap_dir.glob('FIXTURE-R09-BEFORE-*.json'),reverse=True)[:50]]

    def execute(self, request):
        with self.lock:
            selected={k:str(request.get(k,'')) for k in ['beast','drop','resource','recipe']}
            fixture=request.get('fixture') is True
            selection=self.inspect(**selected,fixture=fixture)
            if not selection['can_execute_local_fixture']:
                return {'status':'REJECTED','code':selection['blocking_dependencies'][0]['code'] if selection['blocking_dependencies'] else 'NOT_ALLOWED',
                        'dependencies':selection['blocking_dependencies'], 'state_hash':digest(self.engine.state), 'official_writes':0}
            intent=request.get('intent','')
            if not isinstance(intent,str) or not (8<=len(intent)<=96) or not all(c.isalnum() or c in '._-:' for c in intent):
                return {'status':'REJECTED','code':'INVALID_INTENT','dependencies':['A intenção deve ter 8 a 96 caracteres seguros.'], 'official_writes':0}
            fault=request.get('fault')
            if fault not in (None,'PRECOMMIT_FAIL','POSTSTAGE_FAIL'):
                return {'status':'REJECTED','code':'INVALID_FAULT','official_writes':0}
            chain=selection['matched_reusable_r09_chain']
            before=copy.deepcopy(self.engine.state)
            hbefore=digest(before)
            replay=intent in before['idempotency']
            try:
                result=self.engine.execute(chain,fixture=True,intent=intent,actor='MASTER-SANDBOX',fault=fault)
            except GateError as exc:
                return {'status':'REJECTED','code':exc.code,'reason':str(exc),
                        'before_state_hash':hbefore,'after_state_hash':digest(self.engine.state),
                        'official_writes':0}
            if replay:
                self._record('REPLAY',intent=intent,chain=chain,before=hbefore,after=digest(self.engine.state))
                return {**result,'official_writes':0, 'journal_validation':self.engine.validate_event_ledger()}
            snapshot=self.snap_dir/('FIXTURE-R09-BEFORE-'+self._stamp()+'.json')
            try:
                self.engine.state=before
                self.engine.save_fixture_state(snapshot)
                self.engine.state=copy.deepcopy(before)
                # Recompute exact transaction deterministically; same intent+state -> same receipt/digest.
                final=self.engine.execute(chain,fixture=True,intent=intent,actor='MASTER-SANDBOX',fault=fault)
                if digest(final)!=digest(result):
                    raise GateError('RECOMPUTE_DIVERGENCE','atomic execution changed during snapshot commit')
                self._persist_live()
                event=self._record('COMMIT',intent=intent,chain=chain, before=hbefore,
                                   after=digest(self.engine.state),snapshot_id=snapshot.name,
                                   receipt_sha256=digest(result['receipt']))
                return {**final,'rollback_snapshot':snapshot.name,'operation_event':event,
                        'journal_validation':self.engine.validate_event_ledger(), 'official_writes':0}
            except Exception:
                self.engine.state=before
                # If persistence already completed but audit failed, fail closed and do not silently continue.
                if self.live.exists():
                    self.engine.load_fixture_state(self.live)
                raise

    def restore(self, request):
        with self.lock:
            file_name=request.get('snapshot_id','')
            if file_name not in {v['id'] for v in self._snapshots()}:
                return {'status':'REJECTED','code':'UNKNOWN_LOCAL_SNAPSHOT','official_writes':0}
            backup=copy.deepcopy(self.engine.state)
            old=digest(backup)
            try:
                loaded=self.engine.load_fixture_state(self.snap_dir/file_name)
                self._persist_live()
                event=self._record('RESTORE',snapshot_id=file_name,before=old,after=digest(self.engine.state))
            except Exception:
                self.engine.state=backup
                raise
            return {'status':'RESTORED_LOCAL_FIXTURE','before_state_hash':old,
                    'after_state_hash':digest(self.engine.state), 'validation':loaded,
                    'operation_event':event,'official_writes':0}


class LocalHandler(BaseHTTPRequestHandler):
    lab: MasterLab = None

    def log_message(self, fmt, *args):
        # Keep localhost access logs quiet; no network/credentials.
        pass

    def _send(self, status, raw, mime='application/json; charset=utf-8',extra=None):
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'")
        for k,v in (extra or {}).items():self.send_header(k,v)
        self.end_headers()
        self.wfile.write(raw)

    def _ok_host(self):
        host=self.headers.get('Host','').split(':')[0].lower()
        return host in ('localhost','127.0.0.1','[::1]')

    def _method(self, handler):
        if not self._ok_host():return self._send(403,pack({'error':'LOCAL_ONLY_HOST'}))
        try: handler()
        except (ConnectionResetError, BrokenPipeError):pass
        except (GateError,ValueError,KeyError) as exc:
            self._send(400,pack({'status':'REJECTED','error':getattr(exc,'code',type(exc).__name__),
                                 'message':str(exc),'official_writes':0}))
        except Exception as exc:
            self._send(500,pack({'status':'ERROR_LOCAL','error':type(exc).__name__,
                                 'message':str(exc),'official_writes':0}))

    def do_GET(self):self._method(self._get)

    def _get(self):
        url=urlsplit(self.path)
        if url.path in ('/','/index.html'):
            html=(STATIC/'index.html').read_bytes().replace(b'__LAB_TOKEN__',self.lab.token.encode('ascii'))
            return self._send(200,html,'text/html; charset=utf-8')
        if url.path in ('/app.js','/app.css'):
            path=STATIC/url.path.lstrip('/')
            return self._send(200,path.read_bytes(),'application/javascript; charset=utf-8' if path.suffix=='.js' else 'text/css; charset=utf-8')
        if url.path=='/api/catalog':return self._send(200,pack(self.lab.catalog()))
        if url.path=='/api/state':return self._send(200,pack(self.lab.state_view()))
        if url.path=='/api/inspect':
            q=parse_qs(url.query)
            def take(k):return q.get(k,[''])[0]
            data=self.lab.inspect(take('beast'),take('drop'),take('resource'),take('recipe'),take('fixture')=='true')
            return self._send(200,pack(data))
        return self._send(404,pack({'error':'NOT_FOUND'}))

    def do_POST(self):self._method(self._post)

    def _post(self):
        if self.headers.get('X-VZ-Token')!=self.lab.token:return self._send(403,pack({'error':'INVALID_CSRF_TOKEN'}))
        origin=self.headers.get('Origin','')
        if origin and not (origin.startswith('http://localhost:') or origin.startswith('http://127.0.0.1:')):
            return self._send(403,pack({'error':'INVALID_ORIGIN'}))
        try:size=int(self.headers.get('Content-Length','0'))
        except ValueError:return self._send(400,pack({'error':'INVALID_LENGTH'}))
        if size<1 or size>MAX_JSON_BYTES:return self._send(413,pack({'error':'BODY_LIMIT'}))
        data=json.loads(self.rfile.read(size))
        if not isinstance(data,dict):return self._send(400,pack({'error':'EXPECTED_OBJECT'}))
        if self.path=='/api/execute':result=self.lab.execute(data)
        elif self.path=='/api/restore':result=self.lab.restore(data)
        else:return self._send(404,pack({'error':'NOT_FOUND'}))
        return self._send(200 if result.get('status')!='REJECTED' else 422,pack(result))


def build_server(lab:MasterLab,host='127.0.0.1',port=0):
    class Handler(LocalHandler):pass
    Handler.lab=lab
    return ThreadingHTTPServer((host,port),Handler)


def main(argv=None):
    p=argparse.ArgumentParser(description='Vhal-Zoryn E3 — ferramenta experimental do Mestre (localhost)')
    p.add_argument('--port',type=int,default=8765)
    p.add_argument('--no-browser',action='store_true')
    p.add_argument('--runtime-dir',type=Path,default=None)
    args=p.parse_args(argv)
    if args.port<0 or args.port>65535:p.error('porta inválida')
    lab=MasterLab(args.runtime_dir)
    server=build_server(lab,port=args.port)
    port=server.server_address[1]
    url=f'http://127.0.0.1:{port}/'
    print(f'VHAL-ZORYN E3 / EXPERIMENTAL / LOCAL ONLY\nAbra: {url}\nCtrl+C para encerrar. Dados experimentais: {lab.runtime}',flush=True)
    if not args.no_browser:
        import webbrowser
        threading.Timer(0.45,lambda:webbrowser.open(url)).start()
    try:server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
