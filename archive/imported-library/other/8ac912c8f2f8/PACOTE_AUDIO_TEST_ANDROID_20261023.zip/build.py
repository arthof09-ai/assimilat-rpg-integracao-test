#!/usr/bin/env python3
"""Gera prototipo de Mesa de Sons TEST do RPG Assimilacao com sintetizadores originais, sem SDK externo de IA."""
from pathlib import Path
import base64, io, json, math, wave, zipfile, hashlib, textwrap
import numpy as np

ROOT=Path(__file__).resolve().parent
SR=22050

def norm(x,peak=.75):
    x=np.asarray(x,dtype=np.float64)
    x=np.nan_to_num(x)
    maxval=np.max(np.abs(x))
    if maxval: x=x/maxval*peak
    duration=min(len(x),int(SR*.016))
    if duration:
        f=np.linspace(0,1,duration)
        x[:duration]*=f
        x[-duration:]*=f[::-1]
    return x

def tobytes(x):
    b=np.int16(np.clip(norm(x),-1,1)*32767).tobytes()
    out=io.BytesIO()
    with wave.open(out,'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(SR);wav.writeframes(b)
    return out.getvalue()

def step(seed):
    rng=np.random.default_rng(seed)
    n=int(.84*SR);x=np.zeros(n)
    for t in [.085,.48]:
        start=int(t*SR);length=int(.29*SR)
        ns=rng.normal(size=length)
        filt=np.convolve(ns,np.ones(60)/60,mode='same')
        e=np.exp(-np.linspace(0,9,length))
        thump=np.sin(2*np.pi*72*np.arange(length)/SR)*np.exp(-np.linspace(0,12,length))
        x[start:start+length]+= .52*filt*e + .21*thump
    return x

def sword(seed):
    rng=np.random.default_rng(seed); n=int(1.0*SR);t=np.arange(n)/SR
    noise=rng.normal(size=n)
    whoosh=np.convolve(noise,np.ones(25)/25,mode='same')*np.exp(-((t-.25)/.18)**2)*.65
    impact=np.sin(2*np.pi*(430*t+360*t*t))*np.exp(-np.maximum(t-.46,0)*8)*(.28*(t>.46))
    ring=(np.sin(2*np.pi*1280*t)+.4*np.sin(2*np.pi*1910*t))*np.exp(-np.maximum(t-.48,0)*8)*(.24*(t>.48))
    return whoosh+impact+ring

def magic(seed):
    rng=np.random.default_rng(seed); n=int(1.55*SR); t=np.arange(n)/SR
    f=450+320*t+70*np.sin(2*np.pi*3*t)
    phase=2*np.pi*np.cumsum(f)/SR
    tw=np.sin(phase)+.25*np.sin(phase*1.997)+.08*rng.normal(size=n)
    sw=np.sin(2*np.pi*(175+200*t)*t)*np.exp(-t*4)*.35
    env=(1-np.exp(-t*25))*np.exp(-t*1.9)
    return env*tw+sw

def initiative():
    n=int(1.2*SR);t=np.arange(n)/SR;x=np.zeros(n)
    for start,fr,dur in [(0,392,.40),(.47,523.25,.47)]:
        q=t-start;mask=(q>=0)&(q<dur)
        z=q[mask];env=np.minimum(1,z*35)*np.exp(-z*3.2)
        x[mask]+=.35*env*(np.sin(2*np.pi*fr*z)+.4*np.sin(2*np.pi*fr*2*z))
    return x

def victory():
    n=int(2.25*SR);t=np.arange(n)/SR;x=np.zeros(n)
    for start,fr,dur in [(0,392,.28),(.28,493.88,.28),(.56,587.33,.33),(.90,784,.94)]:
        q=t-start;mask=(q>=0)&(q<dur)
        z=q[mask];env=np.minimum(1,z*30)*np.exp(-z*(2 if dur<.5 else 2.8))
        x[mask]+=.33*env*(np.sin(2*np.pi*fr*z)+.15*np.sin(2*np.pi*fr*3*z))
    return x

def forest(seed):
    rng=np.random.default_rng(seed);n=int(5.1*SR);t=np.arange(n)/SR
    raw=rng.normal(0,1,n)
    air=np.convolve(raw,np.ones(85)/85,mode='same')*(.65+.2*np.sin(2*np.pi*.17*t))
    leaves=np.convolve(raw,np.ones(11)/11,mode='same')*.16
    birds=np.zeros(n)
    for pos,base in [(1.15,1700),(2.62,2200),(3.7,1900)]:
        q=t-pos;mask=(q>=0)&(q<.29);qq=q[mask]
        freq=base+320*np.sin(2*np.pi*3.5*qq)
        ph=2*np.pi*np.cumsum(freq)/SR
        birds[mask]+=np.sin(ph)*(np.sin(np.pi*qq/.29)**2)*.018
    return air*.57+leaves+birds

sounds=[
 ("ambiente_floresta","Ambiente · floresta", "🌲",forest(2801),True,"Suno: substituir por trilha instrumental de exploração, quando houver exportação e licença compatíveis."),
 ("passos_pedra","Passos · movimento", "👣",step(903),False,"ElevenLabs SFX: dois passos rápidos de botas em pedra, som de jogo, sem voz."),
 ("espada_impacto","Espada · impacto", "⚔️",sword(204),False,"ElevenLabs SFX: golpe único de espada com whoosh curto e impacto metálico controlado."),
 ("magia_arcana","Magia · arcana", "✨",magic(455),False,"ElevenLabs SFX: energia arcana ascendente e pulso mágico cristalino, 1 segundo, sem música."),
 ("inicio_turno","Início de turno", "⏱️",initiative(),False,"ElevenLabs SFX: sinal de turno com duas notas suaves, medieval fantástico, sem fala."),
 ("vitoria","Vitória curta", "🏆",victory(),False,"Suno: tema instrumental curto de vitória para RPG de fantasia, sem vocais; exportação depende do plano."),
]
assets={}
for slug,label,icon,x,loop,prompt in sounds:
    b=tobytes(x)
    (ROOT/f"{slug}.wav").write_bytes(b)
    assets[slug]={"label":label,"icon":icon,"loop":loop,"data":"data:audio/wav;base64,"+base64.b64encode(b).decode(),"filename":f"{slug}.wav"}

html=r'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#111b24"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; media-src data: blob:; connect-src 'none'; object-src 'none'; form-action 'none'"><title>RPG Assimilação — Mesa de Sons TEST</title>
<style>
:root{color-scheme:dark;--bg:#0c141c;--panel:#18242f;--stroke:#344453;--accent:#b4dfa6;--text:#ebf1f5;--mute:#b5c5d0}*{box-sizing:border-box}body{font:15px/1.45 system-ui,Roboto,sans-serif;background:radial-gradient(circle at top left,#26383f 0%,#0c141c 65%);color:var(--text);margin:0;min-height:100vh}header,main,footer{max-width:880px;margin:auto;padding:20px}header h1{font-size:clamp(1.7rem,5vw,2.4rem);margin:.2rem 0}header p,footer,.muted{color:var(--mute)}.mark{font-size:.72rem;font-weight:800;letter-spacing:.12em;color:var(--accent)}.note{border:1px solid #50616e;border-radius:12px;padding:12px;background:#1b2c35;margin-top:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(255px,1fr));gap:12px}.card{background:var(--panel);border:1px solid var(--stroke);border-radius:16px;padding:16px;display:flex;flex-direction:column;gap:12px;min-width:0}.card h2{font-size:1.09rem; margin:0}.line{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}.pill{font-size:.7rem;border:1px solid #64746b;padding:3px 8px;border-radius:20px;color:var(--accent)}button,.file{font:inherit;touch-action:manipulation;display:inline-flex;align-items:center;justify-content:center;text-align:center;min-height:46px;padding:10px 15px;border:1px solid #80949f;border-radius:12px;background:#294357;color:var(--text);font-weight:650;cursor:pointer}button:hover,.file:hover{background:#345267}button.primary{background:#405b4a;border-color:#94b99e}button:focus-visible,.file:focus-within{outline:3px solid var(--accent)}button:disabled{opacity:.4}input[type=file]{display:none}input[type=range]{width:100%;accent-color:#b4dfa6}.tiny{font-size:.76rem;color:var(--mute)}.controls{display:flex;gap:8px;flex-wrap:wrap}.controls>*{flex:1}#status{min-height:25px;color:var(--accent);font-weight:650}.extra{border-top:1px solid var(--stroke);margin-top:25px;padding-top:14px}a{color:var(--accent)}footer{font-size:.8rem}strong{color:white}
</style></head><body>
<header><div class="mark">MESTRE-SIDE • DEMONSTRAÇÃO OFFLINE • NÃO CANÔNICA</div><h1>🎛️ Mesa de Sons — RPG Assimilação</h1><p>Um protótipo real de áudio para testar no Android, separado do Tabletop oficial. Os seis sons de exemplo foram sintetizados localmente, <strong>não</strong> gerados pelo Suno nem pela ElevenLabs.</p><div class="note"><strong>Como usar:</strong> toque em ▶ Tocar. Pode substituir cada som por um MP3/WAV criado no ElevenLabs ou Suno usando “Escolher arquivo”. O arquivo escolhido fica só nesta sessão da página, sem envio pela internet.</div></header>
<main><div class="line"><p id="status" role="status" aria-live="polite">Pronto para o primeiro toque.</p><button id="stopAll" type="button">■ Parar tudo</button></div><div class="grid" id="grid"></div>
<div class="extra"><h2>Uso no jogo</h2><p class="muted">Efeitos de passos no deslocamento, espada quando um golpe for <strong>confirmado</strong>, magia quando a ação for resolvida, sinal de turno e áudio de ambiente em loop. A música não altera a mecânica do VLAB.</p><p class="tiny">Sem rede, contas, rastreadores, pagamento, API ou acesso às fichas. Arquivos externos não são persistidos automaticamente. Se o Chrome bloquear reprodução antes do primeiro toque, pressione um botão novamente.</p></div></main><footer>TEST de áudio isolado · Open-source procedural deste protótipo · A integração ao frontend TEST34 dependerá do Desenvolvedor e de validação de licenças.</footer>
<script>
'use strict';
const DATA=__DATA__;
const grid=document.getElementById('grid');const status=document.getElementById('status');
const controls=new Map();
function text(el,v){el.textContent=v;}
function stopAll(){for(const [,o] of controls){o.audio.pause();o.audio.currentTime=0;o.playBtn.textContent='▶ Tocar';}text(status,'Todos os sons parados.');}
document.getElementById('stopAll').addEventListener('click',stopAll);
for(const [slug,record] of Object.entries(DATA)){
 const card=document.createElement('section');card.className='card';card.dataset.sound=slug;
 const top=document.createElement('div');top.className='line';const title=document.createElement('h2');text(title,record.icon+' '+record.label);const pill=document.createElement('span');pill.className='pill';text(pill,record.loop?'AMBIENTE / LOOP':'EVENTO');top.append(title,pill);
 const btns=document.createElement('div');btns.className='controls';const playBtn=document.createElement('button');playBtn.className='primary';playBtn.type='button';text(playBtn,'▶ Tocar');const fileLabel=document.createElement('label');fileLabel.className='file';text(fileLabel,'📁 Escolher áudio');const file=document.createElement('input');file.type='file';file.accept='audio/*,.wav,.mp3,.ogg,.m4a';file.setAttribute('aria-label','Substituir '+record.label);fileLabel.append(file);btns.append(playBtn,fileLabel);
 const desc=document.createElement('div');desc.className='tiny';text(desc,'Som original incluído • '+record.filename);const volumeCaption=document.createElement('label');volumeCaption.className='tiny';text(volumeCaption,'Volume '+record.label);const volume=document.createElement('input');volume.type='range';volume.min='0';volume.max='100';volume.value=record.loop?'25':'55';volume.setAttribute('aria-label','Volume '+record.label);
 const audio=new Audio(record.data);audio.loop=record.loop;audio.preload='auto';audio.volume=Number(volume.value)/100;let currentURL=null;
 volume.addEventListener('input',()=>audio.volume=Number(volume.value)/100);
 playBtn.addEventListener('click',async()=>{if(!audio.paused){audio.pause();text(playBtn,'▶ Tocar');return;}if(!record.loop){audio.currentTime=0;}try{await audio.play();text(playBtn,'❚❚ Pausar');text(status,'Tocando: '+record.label);}catch(err){text(status,'Navegador bloqueou áudio: '+String(err?.message||err));}});
 audio.addEventListener('ended',()=>text(playBtn,'▶ Tocar'));
 file.addEventListener('change',()=>{const chosen=file.files?.[0];if(!chosen)return;if(!chosen.type.startsWith('audio/')&&!/\.(wav|mp3|ogg|m4a)$/i.test(chosen.name)){text(status,'Escolha um arquivo de áudio.');return;}audio.pause();if(currentURL)URL.revokeObjectURL(currentURL);currentURL=URL.createObjectURL(chosen);audio.src=currentURL;audio.load();text(playBtn,'▶ Tocar');text(desc,'Arquivo local escolhido: '+chosen.name);text(status,'Carregado: '+chosen.name+'. Toque em Tocar.');});
 card.append(top,btns,desc,volumeCaption,volume);grid.append(card);controls.set(slug,{audio,playBtn});
}
</script></body></html>'''
html=html.replace('__DATA__',json.dumps(assets,ensure_ascii=False,separators=(',',':')))
(ROOT/'MESA_DE_SONS_TEST_ANDROID_OFFLINE.html').write_text(html,encoding='utf-8')
contract={"prototype":"MESA_DE_SONS_TEST_AUDIO_20261023","source_status":"synthetic_procedural_audio_no_provider_AI_used","safety":"MESTRE-SIDE TEST only; no data to Party; no API/no upload","events": {"SALA_AMBIENTE_ON":"ambiente_floresta","MOVE_CONFIRMED":"passos_pedra","ATTACK_RESOLVED":"espada_impacto","SPELL_RESOLVED":"magia_arcana","TURN_CHANGED":"inicio_turno","SCENE_VICTORY":"vitoria"},"provider_mapping":{"Suno":"trilha musical instrumental: ambiente_floresta, vitoria; sujeito à exportação/licença","ElevenLabs":"efeitos curtos e vozes: passos_pedra, espada_impacto, magia_arcana, inicio_turno; sujeito ao crédito/licença"},"do_not_connect_to_canonical_vlab":True}
(ROOT/'MAPA_EVENTOS_AUDIO_TEST.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
readme='''# Mesa de Sons TEST — RPG Assimilação (23/10/2026)

**TEST ISOLADO MESTRE-ONLY. NÃO é Tabletop TEST34, não é canônico, não é integração à Party, não é um arquivo gerado por Suno ou ElevenLabs.**

## Entrega física

- `MESA_DE_SONS_TEST_ANDROID_OFFLINE.html`: interface de seis sons tocáveis, um único HTML offline com WAV embutidos e opção de substituição por arquivos MP3/WAV locais. Abra no Chrome Android pelo app Arquivos. Toque nos botões de reprodução para permitir som. A importação de arquivos externos NÃO é permanente; a cada abertura selecione os arquivos novamente.
- `*.wav`: seis efeitos procedurais de referência, originalmente sintetizados pelo próprio script `build.py`, sem conteúdo de terceiros.
- `MAPA_EVENTOS_AUDIO_TEST.json`: convenção proposta de eventos UI (somente tocar depois de evento confirmado), não regras mecânicas do VLAB.
- `build.py`: fonte reproduzível deste laboratório; Python+NumPy. `manifest_sha256.json` audita os arquivos.

## Uso futuro com Suno / ElevenLabs (sem prometer direitos não verificados)

1. ElevenLabs > Playground > Sound Effects: gere um efeito de 1–3s; baixe somente se os termos e a conta permitirem; use `Escolher áudio` no slot certo. Use Text to Speech separadamente para locução curta, se desejar.
2. Suno > Create > Instrumental: gere tema sem voz para exploração ou vitória; faça teste de escuta. O plano gratuito não garante download recorrente; use apenas áudio que o serviço permitir exportar e cuja licença seja aplicável.
3. Valide nome, autoria/provedor, link de geração, tipo de conta na geração, licença, data, atribuição, se foi baixado de modo permitido, duração, volume e tamanho em bytes antes de distribuir ou subir para GitHub Pages.
4. Só depois encaminhe o material autorizado ao Desenvolvedor como arquivo local e contrato de eventos. Não enviar segredos ou informações Mestre-only para provedores externos.

## Escopo e limitações

- 0 R$ adicionais e zero API keys.
- Os sons de exemplo NÃO são de qualidade final; são prova de botões, importação local, volume, loop, pausa e correspondência evento→slot.
- Não há automação de ataques; a UI de sons precisa receber eventos CONFIRMADOS de sala/VLAB competente no futuro.
- Nenhum dado privado do RPG é carregado; áudio não vai à Party.
- Android físico não foi testado pelo criador; testes automatizados locais são feitos no Chromium.
'''
(ROOT/'README_TEST_AUDIO.md').write_text(readme,encoding='utf-8')

manifest={}
for f in ROOT.iterdir():
    if f.is_file() and f.name not in ['manifest_sha256.json','PACOTE_AUDIO_TEST_ANDROID_20261023.zip']:
        b=f.read_bytes();manifest[f.name]={"sha256":hashlib.sha256(b).hexdigest(),"bytes":len(b)}
(ROOT/'manifest_sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
zipfile_path=ROOT/'PACOTE_AUDIO_TEST_ANDROID_20261023.zip'
with zipfile.ZipFile(zipfile_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(ROOT.iterdir()):
        if f.is_file() and f!=zipfile_path:z.write(f,arcname=f.name)
print('PACKAGE',str(zipfile_path),'SIZE',zipfile_path.stat().st_size,'SHA',hashlib.sha256(zipfile_path.read_bytes()).hexdigest())
print('HTML',len(html.encode()),'SOUNDS',[(x[0],len((ROOT/(x[0]+'.wav')).read_bytes())) for x in sounds])
