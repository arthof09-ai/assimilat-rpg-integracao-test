# Mesa de Sons TEST — RPG Assimilação (23/10/2026)

**TEST ISOLADO MESTRE-ONLY. NÃO é Tabletop TEST34, não é canônico, não é integração à Party, não é um arquivo gerado por Suno ou ElevenLabs.**

## Entrega física

- `MESA_DE_SONS_TEST_ANDROID_OFFLINE.html`: interface de seis sons tocáveis, um único HTML offline com WAV embutidos e opção de substituição por arquivos MP3/WAV locais. Abra no Chrome Android pelo app Arquivos. Toque nos botões de reprodução para permitir som. A importação de arquivos externos NÃO é permanente; a cada abertura selecione os arquivos novamente.
- `*.wav`: seis efeitos procedurais de referência, originalmente sintetizados pelo próprio script `build.py`, sem conteúdo de terceiros.
- `MAPA_EVENTOS_AUDIO_TEST.json`: convenção proposta de eventos UI (somente tocar depois de evento confirmado), não regras mecânicas do VLAB.
- `build.py`: fonte reproduzível deste laboratório; Python+NumPy. `manifest_sha256.json` audita os arquivos.

## Uso futuro com Suno / ElevenLabs (sem prometer direitos não verificados)

1. ElevenLabs > Playground > Sound Effects: gere um efeito de 1–3s; baixe somente se os termos e a conta permitirem; use `Escolher áudio` no slot certo. Use Text to Speech separadamente para locução curta, se desejar.
2. Suno > Create > Instrumental: gere tema sem voz para exploração ou vitória; faça teste de escuta. O plano gratuito não garante download recorrente; use apenas áudio que o serviço permitir exportar e cuja licença seja aplicável.
3. Valide nome, autoria/provedor, link de geração, tipo de conta na geração, licença, data, atribuição, se foi baixado de modo permitido, duração, volume e tamanho em bytes antes de distribuir ou subir para GitHub Pages.
4. Só depois encaminhe o material autorizado ao Desenvolvedor como arquivo local e contrato de eventos. Não enviar segredos ou informações Mestre-only para provedores externos.

## Escopo e limitações

- 0 R$ adicionais e zero API keys.
- Os sons de exemplo NÃO são de qualidade final; são prova de botões, importação local, volume, loop, pausa e correspondência evento→slot.
- Não há automação de ataques; a UI de sons precisa receber eventos CONFIRMADOS de sala/VLAB competente no futuro.
- Nenhum dado privado do RPG é carregado; áudio não vai à Party.
- Android físico não foi testado pelo criador; testes automatizados locais são feitos no Chromium.
