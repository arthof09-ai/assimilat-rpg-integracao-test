import json,zipfile,hashlib,os,time,re
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
bundle=root/'PACOTE_AUDIO_TEST_ANDROID_20261023.zip'
with zipfile.ZipFile(bundle) as z:
 assert z.testzip() is None
 m=json.loads(z.read('manifest_sha256.json'))
 for name,stamp in m.items():
  data=z.read(name)
  assert len(data)==stamp['bytes'] and hashlib.sha256(data).hexdigest()==stamp['sha256'], name
 assert len([n for n in z.namelist() if n.endswith('.wav')])==6
print('ZIP CRC PASS / MANIFEST',len(m),'PASS')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=False)
 errs=[];req=[]
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('request',lambda r:req.append(r.url))
 page.set_content((root/'MESA_DE_SONS_TEST_ANDROID_OFFLINE.html').read_text(encoding='utf-8'),wait_until='load')
 assert page.locator('.card').count()==6
 assert len(req)==0,req
 assert not errs,errs
 for slug in ['passos_pedra','espada_impacto','magia_arcana','inicio_turno','vitoria']:
  card=page.locator(f'.card[data-sound="{slug}"]')
  card.locator('button').click();page.wait_for_timeout(75)
  assert 'Tocando' in page.locator('#status').inner_text()
  assert 'Pausar' in card.locator('button').inner_text()
  page.locator('#stopAll').click()
  assert 'Tocar' in card.locator('button').inner_text()
 card=page.locator('.card[data-sound="ambiente_floresta"]')
 card.locator('button').click();page.wait_for_timeout(200)
 assert 'Pausar' in card.locator('button').inner_text()
 card.locator('button').click()
 assert 'Tocar' in card.locator('button').inner_text()
 card.locator('input[type="file"]').set_input_files(str(root/'espada_impacto.wav'))
 assert 'espada_impacto.wav' in card.locator('.tiny').first.inner_text()
 card.locator('button').click();page.wait_for_timeout(100)
 assert 'Pausar' in card.locator('button').inner_text()
 assert not errs,errs
 print('CHROMIUM 390x844: SIX PLAYBACK BUTTONS PASS, STOP/PAUSE PASS, LOCAL AUDIO IMPORT PASS, NO PAGE ERROR, NO NETWORK PASS')
 page.screenshot(path=str(root/'test_browser_390x844.png'),full_page=True)
 browser.close()
