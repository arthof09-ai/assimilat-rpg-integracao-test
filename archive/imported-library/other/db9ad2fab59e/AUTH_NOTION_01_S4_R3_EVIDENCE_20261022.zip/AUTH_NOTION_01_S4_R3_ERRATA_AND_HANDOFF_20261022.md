# PSV — AUTH-NOTION-01 / R3: correção de idempotência e certificação parcial

**NAC-PASS-02:** laboratório sintético local PASS; **S4 normativa GLOBAL HOLD**.

## ANTES → DEPOIS

- **R2:** 192 parametrizações de teste, apenas **38 combinações efetivas de entradas distintas**; 12 mutações deliberadas rejeitadas; 12 canários locais de decisão; TEE na mãe em FAIL documental.
- **R3:** erro identificado na função sintética para timeout/rejeição com readback **positivo**. Ela retornava `READBACK_BEFORE_RETRY` mesmo com estado desejado comprovadamente persistido. Isso não autorizava explicitamente retentar, porém perdia a classificação correta de idempotência.
- **Correção TEST:** ao receber `timeout`/`reject` **e** constatar `readback_confirmed=True`, classificar `VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE`. Se o readback não confirma efeito, manter `READBACK_BEFORE_RETRY` e examinar persistência antes de qualquer reenvio. Não considerar apenas `success` como prova de escrita.
- **R3:** 208 parametrizações testadas, **41 estados de entrada distintos** entre elas, **20 classes de decisão na suíte**, **14/14 mutantes capturados**, **13/13 canários locais da decisão**. Transparência: 208 ≠ 208 cenários independentes.
- **Propriedades:** matriz cartesiana de 12 estados booleanos × 16 modos de escrita/destino/tipo/readback = **65.536 verificações sintéticas** de invariantes. **0 violações**, 14 classes de saída observadas no teste de propriedades. Isso não constitui 65.536 chamadas reais ao Notion.
- **Canários reais de fontes Notion:** 12/12 presença documental verificada no Kit, Modelo Recuperação, ID-COMESTRE, Painel e seção mãe; observada também **ausência da chamada AUTH dentro da mãe**. TEE ainda FAIL.

## Avaliação metodológica

O novo laboratório agora discrimina explicitamente resultados incertos que foram de fato persistidos. Ele verifica a **lógica de políticas**, não a autenticidade de eventos de rede. Revogação, erro pós-escrita real, conta trocada em mid-session e escritor concorrente não foram induzidos em qualquer workspace oficial. `writer_authorized=True` é parâmetro sintético, jamais concessão de writer vivo.

## Gate de promoção ainda pendente

1. **NAC-CONT-03 v2**: chamada direta nas etapas E0/E1/E3/E5/E6/E9/E11; patch candidato já preparado e preservado, **NÃO APLICADO** à mãe.
2. **MIE/TEE**: reconciliar e aprovar mapa de 13 categorias, executar canários após eventual patch.
3. **S4/STRESS REGRESSÃO REAL:** cenários controlados em TEST sob direitos comprovados, sem provocar revogação destrutiva da conta real e sem escrita Party.
4. **Independência:** revisor/instância competente e blind successor; não declarar segundo humano por dois scripts.
5. **NAC-NORM/GP-NAC/NAC-PASS:** promoção e atualização de status somente após provas.

**LAST VERIFIED:** 208/208 sintéticos, 14/14 mutações, 65.536/65.536 assertivas de propriedades, source canaries 12/12. **FIRST PENDING:** autorização/writer normativo da mãe para patch controlado. **CONTINUAR SEM REPRODUZIR R2:** verificação formal de titular de edição, teste de bridge E0–E11, regressões S4 restantes, depois gates de promoção.
