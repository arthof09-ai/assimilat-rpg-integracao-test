#!/usr/bin/env python3
"""AUTH-NOTION-01: laboratório S4 sintético para decisões de conexão.
Não abre Notion, não simula testes E2E reais, não fornece autenticação, e não promulga norma.
"""
from dataclasses import dataclass, asdict, replace
from typing import Optional
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

@dataclass(frozen=True)
class Scenario:
    name: str
    category: str
    tool_available: bool=True
    link_present: bool=True
    link_eligible: bool=True
    account_authenticated: bool=True
    workspace_match: bool=True
    permission_known: bool=True
    resource_exists: bool=True
    permission_granted: bool=True
    write: bool=False
    writer_authorized: bool=False
    collision_free: bool=False
    write_sent: bool=False
    write_outcome: str='not_sent'  # not_sent | success | timeout | reject
    readback_confirmed: bool=False
    previously_verified: bool=False
    connection_changed: bool=False
    session_changed: bool=False
    error: str='none' # none, link_required, revoked, transient, not_found
    retry_identical: bool=False
    independent_test_allowed: bool=True
    destination: str='mestre' # mestre | party
    content_kind: str='mester_only' # mester_only | party_safe
    requested_reconnect: bool=False
    expected: str=''

# Outcomes are intentionally more discriminating than a Boolean "Notion OK".
def decision(s: Scenario) -> str:
    if s.connection_changed or s.session_changed:
        return 'REVALIDATE_CONNECTION'
    if not s.tool_available:
        return 'BLOCKED_TOOL_CONTINUE_TEST' if s.independent_test_allowed else 'BLOCKED_TOOL'
    if not s.link_present or s.error=='link_required':
        return 'SELECT_ELIGIBLE_LINK'
    if not s.link_eligible:
        return 'REDISCOVER_LINK'
    if s.error == 'revoked':
        return 'STOP_REVOKED'
    if not s.account_authenticated:
        return 'INVESTIGATE_AUTH'
    if not s.workspace_match:
        return 'STOP_WRONG_WORKSPACE'
    if not s.permission_known:
        return 'CHECK_PERMISSIONS'
    if not s.resource_exists or s.error=='not_found':
        return 'DIAGNOSE_RESOURCE_NOT_AUTH'
    if not s.permission_granted:
        return 'ACCESS_DENIED'
    if s.destination == 'party' and s.content_kind == 'mester_only':
        return 'DENY_MASTER_ONLY_EXPOSURE'
    if s.retry_identical:
        return 'STOP_IDENTICAL_RETRY'
    if s.error == 'transient' and not s.write_sent:
        return 'RETRY_ONLY_DIFFERENT_CAUSE'
    if s.write:
        if not s.writer_authorized or not s.collision_free:
            return 'DENY_WRITE_AUTHORITY'
        if not s.write_sent:
            return 'ALLOW_MINIMAL_WRITE_TEST_ONLY'
        if s.write_outcome in ('timeout','reject'):
            return 'VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE' if s.readback_confirmed else 'READBACK_BEFORE_RETRY'
        if s.write_outcome == 'success' and not s.readback_confirmed:
            return 'REOPEN_CONFIRM_WRITE'
        if s.write_outcome == 'success' and s.readback_confirmed:
            return 'VERIFIED_WRITE'
        return 'INDETERMINATE_WRITE'
    return 'OPERATIONAL_READ'

seed=Scenario('','','expected') if False else Scenario(name='base', category='base')
cases=[]
def add(group,tag,expected,**kw):
    s=replace(seed,name=f'{group}.{tag}',category=group,expected=expected,**kw)
    cases.append(s)

# 14 named categories track all adversarial cases from Mestre's Articles 12/13.
for j in range(1,9): add('N01_TWO_ACCOUNTS',f'eligible_master_{j}','OPERATIONAL_READ',destination='mestre',content_kind='party_safe',previously_verified=bool(j%2))
for j in range(1,9): add('N02_LINK_OMITTED',f'entrypoint_{j}','SELECT_ELIGIBLE_LINK',link_present=False,account_authenticated=False,resource_exists=(j%2==0))
for j in range(1,9): add('N03_LINK_WRONG',f'case_{j}','REDISCOVER_LINK',link_eligible=False,link_present=True,write=bool(j%2))
for j in range(1,9): add('N04_AUTH_OK',f'case_{j}','OPERATIONAL_READ',destination='mestre',content_kind='party_safe')
for j in range(1,9): add('N05_AUTHED_PAGE_MISSING',f'case_{j}','DIAGNOSE_RESOURCE_NOT_AUTH',resource_exists=False,permission_granted=bool(j%2))
for j in range(1,9): add('N06_MASTER_ACCOUNT_TO_PARTY',f'case_{j}','STOP_WRONG_WORKSPACE',workspace_match=False,destination='party',content_kind='party_safe')
for j in range(1,9): add('N07_PARTY_ACCOUNT_TO_MASTER',f'case_{j}','STOP_WRONG_WORKSPACE',workspace_match=False,destination='mestre',content_kind='party_safe')
for j in range(1,9): add('N08_TOOL_DOWN',f'case_{j}','BLOCKED_TOOL_CONTINUE_TEST' if j%2 else 'BLOCKED_TOOL',tool_available=False,independent_test_allowed=bool(j%2))
for j in range(1,9): add('N09_REVOKED',f'case_{j}','STOP_REVOKED',error='revoked',write=bool(j%2))
for j in range(1,9): add('N10_WRITER_TOOL_NOT_AUTHORITY',f'case_{j}','DENY_WRITE_AUTHORITY',write=True,writer_authorized=bool(j%2),collision_free=not bool(j%2))
for j in range(1,9): add('N11_WRITE_TIMEOUT',f'case_{j}','READBACK_BEFORE_RETRY',write=True,writer_authorized=True,collision_free=True,write_sent=True,write_outcome='timeout',readback_confirmed=False)
for j in range(1,9): add('N12_ACCOUNT_CHANGED',f'case_{j}','REVALIDATE_CONNECTION',connection_changed=True,write=bool(j%2))
for j in range(1,9): add('N13_NEW_SUCCESSOR',f'case_{j}','REVALIDATE_CONNECTION',session_changed=True,previously_verified=True)
for j in range(1,9): add('N14_TEST_CAN_CONTINUE',f'case_{j}','BLOCKED_TOOL_CONTINUE_TEST',tool_available=False,independent_test_allowed=True,write=bool(j%2))
# Additional attack classes and idempotency regression.
for j in range(1,9): add('N15_UNAUTHORIZED_PARTY_EXPOSURE',f'case_{j}','DENY_MASTER_ONLY_EXPOSURE',destination='party',content_kind='mester_only',write=bool(j%2))
for j in range(1,9): add('N16_RETRY_IDENTICAL',f'case_{j}','STOP_IDENTICAL_RETRY',retry_identical=True,write=bool(j%2))
for j in range(1,9): add('N17_WRITE_UNCONFIRMED',f'case_{j}','REOPEN_CONFIRM_WRITE',write=True,writer_authorized=True,collision_free=True,write_sent=True,write_outcome='success',readback_confirmed=False)
for j in range(1,9): add('N18_WRITE_VERIFIED',f'case_{j}','VERIFIED_WRITE',write=True,writer_authorized=True,collision_free=True,write_sent=True,write_outcome='success',readback_confirmed=True)
for j in range(1,9): add('N19_DENIED_PERMISSIONS',f'case_{j}','ACCESS_DENIED',permission_granted=False,write=bool(j%2))
for j in range(1,9): add('N20_WRITER_SENT_REJECTED',f'case_{j}','READBACK_BEFORE_RETRY',write=True,writer_authorized=True,collision_free=True,write_sent=True,write_outcome='reject',readback_confirmed=False)
for j in range(1,9): add('N21_PERMISSION_UNKNOWN',f'case_{j}','CHECK_PERMISSIONS',permission_known=False,write=bool(j%2))
for j in range(1,9): add('N22_FRESH_CLEAN_WRITE',f'case_{j}','ALLOW_MINIMAL_WRITE_TEST_ONLY',write=True,writer_authorized=True,collision_free=True,write_sent=False)
for j in range(1,9): add('N25_TIMEOUT_VERIFIED_NOOP',f'case_{j}','VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE',write=True,writer_authorized=True,collision_free=True,write_sent=True,write_outcome='timeout',readback_confirmed=True,content_kind='party_safe' if j%2 else 'mester_only')
for j in range(1,9): add('N26_REJECT_VERIFIED_NOOP',f'case_{j}','VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE',write=True,writer_authorized=True,collision_free=True,write_sent=True,write_outcome='reject',readback_confirmed=True,previously_verified=bool(j%2))
for j in range(1,9): add('N23_TRANSIENT',f'case_{j}','RETRY_ONLY_DIFFERENT_CAUSE',error='transient',write=bool(j%2))
for j in range(1,9): add('N24_ACCOUNT_AUTH_FAILED',f'case_{j}','INVESTIGATE_AUTH',account_authenticated=False,write=bool(j%2))

actual=[{'id':s.name,'category':s.category,'expected':s.expected,'result':decision(s),'pass':decision(s)==s.expected} for s in cases]
assert len(cases)==208 and all(x['pass'] for x in actual)

# Mutational checks: independent attack attempts show the oracle catches policy violations.
mutations={
 'missing_link_as_disconnect': lambda s: 'STOP_REVOKED' if s.category=='N02_LINK_OMITTED' else decision(s),
 'not_found_as_auth_failure':lambda s:'INVESTIGATE_AUTH' if s.category=='N05_AUTHED_PAGE_MISSING' else decision(s),
 'cross_workspace_relabel':lambda s:'OPERATIONAL_READ' if s.category=='N06_MASTER_ACCOUNT_TO_PARTY' else decision(s),
 'party_secrets_mishandled':lambda s:'OPERATIONAL_READ' if s.category=='N15_UNAUTHORIZED_PARTY_EXPOSURE' else decision(s),
 'writer_assumed':lambda s:'VERIFIED_WRITE' if s.category=='N10_WRITER_TOOL_NOT_AUTHORITY' else decision(s),
 'timeout_is_success':lambda s:'VERIFIED_WRITE' if s.category=='N11_WRITE_TIMEOUT' else decision(s),
 'no_revalidation_on_change':lambda s:'OPERATIONAL_READ' if s.category=='N12_ACCOUNT_CHANGED' else decision(s),
 'old_session_reused':lambda s:'OPERATIONAL_READ' if s.category=='N13_NEW_SUCCESSOR' else decision(s),
 'repeat_unbounded':lambda s:'OPERATIONAL_READ' if s.category=='N16_RETRY_IDENTICAL' else decision(s),
 'unverified_as_pass':lambda s:'VERIFIED_WRITE' if s.category=='N17_WRITE_UNCONFIRMED' else decision(s),
 'no_separation_of_scope':lambda s:'OPERATIONAL_READ' if s.category=='N08_TOOL_DOWN' else decision(s),
 'unknown_permission_granted':lambda s:'OPERATIONAL_READ' if s.category=='N21_PERMISSION_UNKNOWN' else decision(s),
 'duplicate_write_after_verified_timeout':lambda s:'READBACK_BEFORE_RETRY' if s.category=='N25_TIMEOUT_VERIFIED_NOOP' else decision(s),
 'duplicate_write_after_verified_reject':lambda s:'READBACK_BEFORE_RETRY' if s.category=='N26_REJECT_VERIFIED_NOOP' else decision(s),
}
mutation_results=[]
for name, bad in mutations.items():
    caught=sum(bad(s)!=s.expected for s in cases)
    assert caught>0
    mutation_results.append({'mutant':name,'caught_by_oracle':caught,'caught':True})

# Local model canaries only are assertions over the frozen draft semantics, not a blind-agent test.
canaries={
  'C01 account explicit': 'SELECT_ELIGIBLE_LINK',
  'C02 authorized auth': 'OPERATIONAL_READ',
  'C03 absent resource': 'DIAGNOSE_RESOURCE_NOT_AUTH',
  'C04 mismatch workspace': 'STOP_WRONG_WORKSPACE',
  'C05 revoke': 'STOP_REVOKED',
  'C06 no writer': 'DENY_WRITE_AUTHORITY',
  'C07 no ACK without readback': 'REOPEN_CONFIRM_WRITE',
  'C08 timeout readback': 'READBACK_BEFORE_RETRY',
  'C09 Party secret isolation': 'DENY_MASTER_ONLY_EXPOSURE',
  'C10 successor revalidates': 'REVALIDATE_CONNECTION',
  'C11 independent TEST': 'BLOCKED_TOOL_CONTINUE_TEST',
  'C12 do not retry same thing': 'STOP_IDENTICAL_RETRY',
  'C13 uncertain write verified means NOOP': 'VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE',
}
for val in canaries.values(): assert val in {x['result'] for x in actual}

summary={'protocol':'AUTH-NOTION-01','normative_status':'S4 PROPOSTA — NAC-PASS GLOBAL HOLD',
  'kind':'SYNTHETIC MOCK STATE MACHINE - no Notion, OAuth, revocation, or live writes',
  'cases':len(actual),'passed':sum(x['pass'] for x in actual),
  'categories':dict(Counter(x['category'] for x in actual)),
  'unique_input_combinations':len({tuple(sorted((k,v) for k,v in asdict(x).items() if k not in ('name','category','expected'))) for x in cases}),
  'mutation_cases':len(mutation_results),'mutations_detected':sum(x['caught'] for x in mutation_results),
  'canary_cases':len(canaries),'canaries_local_pass':len(canaries),
  'live_not_proven':['Account revocation','Post-write timeout tested only by simulation','Concurrent writer conflict','Mid-session external link reassignment','Real blind reviewer','Direct NAC-CONT-03 mother TEE']}
folder=Path(__file__).resolve().parent
(folder/'AUTH_NOTION_01_S4_R3_LAB_REPORT_20261022.json').write_text(json.dumps({'summary':summary,'results':actual,'mutations':mutation_results,'canaries':canaries},ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'AUTH_NOTION_01_S4_R3_SUMMARY_20261022.md').write_text('# AUTH-NOTION-01 — laboratório sintético isolado\n\n'+ '\n'.join(f'- **{k}:** {v}' for k,v in summary.items())+'\n\n**Limite:** este teste é simulado e NÃO autoriza reivindicar NAC-STRESS-01 S4 integral, TEE, GNN, GP-NAC nem NAC-PASS.\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
