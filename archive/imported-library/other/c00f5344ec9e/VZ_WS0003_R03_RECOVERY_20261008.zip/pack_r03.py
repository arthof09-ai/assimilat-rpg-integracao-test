import pathlib,hashlib,json,zipfile,shutil
p=pathlib.Path('/mnt/data/vz_ws0003_r03')
workbook=pathlib.Path('/mnt/data/VZ_WS0003_R03_SOURCE420_OFFER1008_PRECREACAO_20261008.xlsx')
assert workbook.exists() and workbook.stat().st_size>100000
files=sorted(x for x in p.iterdir() if x.suffix in {'.csv','.md','.json','.py'} and x.name!='VZ_WS0003_R03_MANIFEST_SHA256_20261008.json')+[workbook]
manifest={'name':'VZ_WS0003_R03_RECOVERY_20261008.zip','status':'DESIGN AND LAB PROPOSAL ONLY / NO NOTION WRITER / NO MATERIAL / T16 PENDING','op':'CM-000005/WS0003 / FUSION-E3 R16','baseline_UAT':1649,'materialized_UAT':0,'source_register_positions':420,'source_booked_identity_candidates':119,'offer_quota_positions':1008,'offer_conditional_candidates':39,'tests':'R03-PROVENANCE-TESTS 74/74 PASS, workbook formula scan 0 errors','requirements':'R01 & R02 are separate frozen upstream artifacts, do not replace them','files':{x.name:{'size':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files}}
manifestfile=p/'VZ_WS0003_R03_MANIFEST_SHA256_20261008.json';manifestfile.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
zip_path=pathlib.Path('/mnt/data/VZ_WS0003_R03_RECOVERY_20261008.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for x in files+[manifestfile]:z.write(x,x.name)
# verify CRC + byte exact member proof in detached context
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for x in files+[manifestfile]:
  assert z.read(x.name)==x.read_bytes(),x.name
assert len({x.name for x in files+[manifestfile]})==len(files)+1
assert len(files)>=12
print('R03 ZIP',zip_path,'size',zip_path.stat().st_size,'sha256',hashlib.sha256(zip_path.read_bytes()).hexdigest())
print('ZIP members',len(files)+1,'manifest content entries',len(files),'CRC AND BYTE COMPARE PASS')
for name in sorted(x.name for x in files+[manifestfile]):print('FILE',name)
