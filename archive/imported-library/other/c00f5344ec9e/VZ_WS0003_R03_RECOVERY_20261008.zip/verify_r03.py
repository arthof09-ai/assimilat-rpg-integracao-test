#!/usr/bin/env python3
"""Read-only verifier: cannot promote any SOURCE/OFFER or UAT. Uses frozen R02 + design R03."""
import pathlib,csv,hashlib,json,collections,re
I=pathlib.Path('/mnt/data/vz_ws0003_resume');R=pathlib.Path(__file__).resolve().parent
r02=json.loads((I/'VZ_WS0003_R02_QA_Provenance_20261008.json').read_text())
passed=[]
def check(label,cond):
 assert cond,label
 passed.append(label)

def rows(name):
 with open(R/name,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
for file,meta in r02['files'].items():
 check('R02-bytes-'+file,(I/file).stat().st_size==meta['bytes'] and hashlib.sha256((I/file).read_bytes()).hexdigest()==meta['sha256'])
s=rows('VZ_WS0003_R03_SOURCE420_POSITION_REGISTER_20261008.csv')
o=rows('VZ_WS0003_R03_OFFER1008_POSITION_REGISTER_20261008.csv')
e=rows('VZ_WS0003_R03_RV_RC143_VERIFIED_EDGES_20261008.csv')
p=rows('VZ_WS0003_R03_PRE16_NEW_PROTOCOLS_20261008.csv')
f=rows('VZ_WS0003_R03_RV15_FOLLOWUP_PLANS_20261008.csv')
x=rows('VZ_WS0003_R03_EXCLUSIONS_20261008.csv')
y=rows('VZ_WS0003_R03_RC48_SHOP_CLASSIFICATION_20261008.csv')
metrics=json.loads((R/'VZ_WS0003_R03_QA_20261008.json').read_text())['metrics']
check('SOURCE420-exact-positions',len(s)==420 and set(int(r['POSITION_ONLY_NOT_SOURCE_ID']) for r in s)==set(range(1,421)))
check('SOURCE119-booked-others-unbound',sum(bool(r['EXISTING_BLUEPRINT_REFERENCE_ID']) for r in s)==119 and sum(not r['EXISTING_BLUEPRINT_REFERENCE_ID'] for r in s)==301)
check('SOURCE80-existing-RV-and-39-proposed-RC',collections.Counter(r['BOOKING_CLASS'] for r in s)=={'RV80 EXISTING-BLUEPRINT':80,'RC48 OUTPUT/PRODUCT-NAME-BLUEPRINT':39,'VACANT-SOURCE-POSITION-NO-ENTITY':301})
check('SOURCE-no-fake-ids-no-credit',all(not r['SOURCE_ID_MATERIAL'] and not r['ITEM_ID_MATERIAL'] and not r['OFFER_ID_MATERIAL'] and r['MATERIAL_UAT_CREDIT']=='0' for r in s))
check('SOURCE-candidate-no-alias-assumed',all(not r['ALIAS_ID'] and r['SEMANTIC_DEDUPE_VERDICT']=='REQUIRES-INDEPENDENT-SEMANTIC-REVIEW' for r in s))
check('OFFER1008-exact-positions',len(o)==1008 and len({r['QUOTA_POSITION_ONLY_NOT_OFFER_ID'] for r in o})==1008)
check('OFFER4x252',dict(collections.Counter(r['STORE_ID_EXISTING'] for r in o))=={'STORE-VZ-KH-01':252,'STORE-VZ-MY-01':252,'STORE-VZ-KV-01':252,'STORE-VZ-AU-01':252})
check('OFFER39-candidates-969-unbound',sum(bool(r['RC_PRODUCT_BLUEPRINT_REF']) for r in o)==39 and sum(not r['RC_PRODUCT_BLUEPRINT_REF'] for r in o)==969)
check('OFFER4-E2E-preexisting-design',sum(bool(r['E2E_DOCUMENTARY_ANCHOR']) for r in o)==4)
check('OFFER-no-fake-ids-no-credit',all(not r['QUALIFIED_SOURCE_ID'] and not r['ITEM_ID_MATERIAL'] and not r['OFFER_ID_MATERIAL'] and r['MATERIAL_UAT_CREDIT']=='0' for r in o))
check('BOM143-exact-linked-edges',len(e)==143 and len({r['RV_ID_EXISTING'] for r in e})==65 and len({r['RECIPE_ID_EXISTING'] for r in e})==48)
check('BOM8-interregional-12-hops',sum(r['CROSS_BIOME_DESIGN']=='YES' for r in e)==8 and sum(int(r['ROUTE_HOPS_BY_INGREDIENT_DESIGN']) for r in e)==12)
check('BOM-no-physical-claim',all(not r['RV_MATERIAL_SOURCE_ID'] and not r['BOM_APPROVED_QTY'] and not r['STOCK_SHIPMENT_RECEIPT'] for r in e))
check('RC48-nonfiller-commercial-rejection',len(y)==48 and len([r for r in y if r['PROPOSED_COMMERCIAL_ELIGIBILITY'].startswith('CONDITIONAL')])==39 and len(x)==25)
check('PRE16-new-do-not-repeat-R02-eight',len(p)==16 and not {r['EXISTING_RC_ID'] for r in p}&{r['EXISTING_RECIPE_ID'] for r in csv.DictReader(open(I/'VZ_WS0003_R02_PRE8_Lab_Prototypes_20261008.csv',encoding='utf-8-sig'))})
rc48={r['RC_ID_EXISTING']:r for r in csv.DictReader(open(I/'VZ_WS0003_R02_RC48_BOM_Evidence_20261008.csv',encoding='utf-8-sig'))}
for row in p:
 pairs=[z.split(':') for z in row['PROPOSED_LAB_MASS_PARTS_PER_100'].split('|')]
 check('PRE16-ingredients-and-100-parts-'+row['EXISTING_RC_ID'],row['EXISTING_BOM_RV_IDS']==rc48[row['EXISTING_RC_ID']]['INGREDIENT_RV_IDS_BLUEPRINT'] and [x[0] for x in pairs]==row['EXISTING_BOM_RV_IDS'].split('|') and sum(int(x[1]) for x in pairs)==100)
check('PRE16-fences',all(not r['MATERIAL_SOURCE_IDS'] and not r['ITEM_ID'] and not r['OFFER_ID'] and not r['BOM_REAL_QTY'] and r['STATUS']=='PRÉ-CRIAÇÃO PROPOSTA' for r in p))
check('RV15-followup-no-invention',len(f)==15 and len({r['EXISTING_RV_ID'] for r in f})==15 and all(r['EXPERIMENTAL_NEGATIVE_CONTROL'] and r['SECOND_INDEPENDENT_MEASURE'] and not r['MATERIAL_SOURCE_ID'] and not r['OFFER_ID'] for r in f))
check('QUOTA-SHOP56-true-exact',sum(int(r['OFFER_COUNT_BLUEPRINT_QUOTA']) for r in csv.DictReader(open(I/'VZ_WS0003_R02_SHOP56_Quota_vs_Identity_20261008.csv',encoding='utf-8-sig')))==1008)
check('CAPACITY-if-one-offer-per-item-store',420*4-240*3==960 and 1008-960==48 and (1008+240*3+3)//4==432)
check('R03-not-canonic-unchanged-R01',len(list(csv.DictReader(open(I/'VZ_WS0003_INTEGRACAO_R01_Crosswalk_200_Evidencia_20261008.csv',encoding='utf-8-sig'))))==200)
for k,v in metrics.items():
 if isinstance(v,int):check('metrics-'+k,v>=0)
print('R03-PROVENANCE-TESTS PASS: %d/%d'% (len(passed),len(passed)))
for critical in ['SOURCE420-exact-positions','SOURCE119-booked-others-unbound','OFFER1008-exact-positions','OFFER39-candidates-969-unbound','BOM143-exact-linked-edges','BOM8-interregional-12-hops','CAPACITY-if-one-offer-per-item-store','R03-not-canonic-unchanged-R01']:
 print('PASS',critical)
