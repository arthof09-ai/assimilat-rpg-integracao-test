from __future__ import annotations
import csv, json, re, hashlib, unicodedata, collections, pathlib, zipfile
from datetime import datetime
IN=pathlib.Path('/mnt/data/vz_ws0003_resume'); OUT=pathlib.Path('/mnt/data/vz_ws0003_r03'); OUT.mkdir(exist_ok=True)
BASE='https://app.notion.com/p/'
URLS={'SHOP':'3f2c2b324ede8141b3beecc19564305a','MANIFEST':'3f2c2b324ede81fc9a31e1b6472a0418','RECIPE':'3f2c2b324ede818ab73edfd8e5ffc525','MATRIX':'3f1c2b324ede8145be13d394780e6d2c','DEP':'3f2c2b324ede81b49c0ae60cb6fc1751','E2E':'3f2c2b324ede817ab731c0d0b44cf454','IBX18':'3f3c2b324ede81618d96dc600798bcff','CONTROL':'3f1c2b324ede81ed832becc1845029cf','NC05':'3f3c2b324ede814c853ef5a6089ac453','B04':'3f2c2b324ede81f4857edfd583fb58f9'}
URLS={k:BASE+v for k,v in URLS.items()}

def readcsv(name):
 with open(IN/name,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def writecsv(name, rows, headers=None):
 if headers is None: headers=list(rows[0])
 path=OUT/name
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=headers,lineterminator='\n',extrasaction='ignore');w.writeheader();w.writerows(rows)
 return path

def norm(s):
 s=unicodedata.normalize('NFD',s.lower());s=''.join(c for c in s if unicodedata.category(c)!='Mn');return re.sub(r'[^a-z0-9]+',' ',s).strip()
rv=readcsv('VZ_WS0003_R02_RV80_Consumer_Register_20261008.csv')
rc=readcsv('VZ_WS0003_R02_RC48_BOM_Evidence_20261008.csv')
sh=readcsv('VZ_WS0003_R02_SHOP56_Quota_vs_Identity_20261008.csv')
rv15=readcsv('VZ_WS0003_R02_RV15_NonRecipe_Research_20261008.csv')
r01=readcsv('VZ_WS0003_INTEGRACAO_R01_Crosswalk_200_Evidencia_20261008.csv')
pre8=readcsv('VZ_WS0003_R02_PRE8_Lab_Prototypes_20261008.csv')
assert len(rv)==80 and len(rc)==48 and len(sh)==56 and len(rv15)==15 and len(r01)==200 and len(pre8)==8
rv_by={r['RV_ID_EXISTING_BLUEPRINT']:r for r in rv}
rc_by={r['RC_ID_EXISTING']:r for r in rc}
assert len(rv_by)==80 and len(rc_by)==48
assert len({norm(r['NAME_EXISTING_BLUEPRINT']) for r in rv})==80
assert len({norm(r['PRODUCT_NAME_EXISTING_BLUEPRINT']) for r in rc})==48
assert set(norm(r['NAME_EXISTING_BLUEPRINT']) for r in rv).isdisjoint(set(norm(r['PRODUCT_NAME_EXISTING_BLUEPRINT']) for r in rc))
no_rc={r['EXISTING_RV_ID']:r for r in rv15}; assert len(no_rc)==15
# Category assessment of existing RC products — design classification, NOT canonical ITEM classification.
family_map={
 'FAL':['Armas','Artefatos/Acessórios','Roupas','Artefatos/Acessórios','Artefatos/Acessórios','Artefatos/Acessórios','Outros','Outros','Outros','Artefatos/Acessórios','Inscrições','Outros'],
 'PAN':['Roupas','Artefatos/Acessórios','Outros','Outros','Roupas','Artefatos/Acessórios','Poções','Outros','Outros','Artefatos/Acessórios','Outros','Outros'],
 'FEN':['Armaduras','Artefatos/Acessórios','Artefatos/Acessórios','Outros','Armas','Outros','Outros','Roupas','Outros','Artefatos/Acessórios','Outros','Outros'],
 'BOS':['Armaduras','Artefatos/Acessórios','Artefatos/Acessórios','Roupas','Outros','Outros','Artefatos/Acessórios','Armas','Outros','Outros','Outros','Artefatos/Acessórios']}
nonretail={'RC-VZ-FAL-12','RC-VZ-PAN-09','RC-VZ-PAN-11','RC-VZ-FEN-06','RC-VZ-FEN-09','RC-VZ-FEN-12','RC-VZ-BOS-11'}
restricted={'RC-VZ-PAN-07','RC-VZ-FEN-07'}
e2e={'RC-VZ-FAL-04','RC-VZ-PAN-01','RC-VZ-FEN-01','RC-VZ-BOS-02'}
assert len(nonretail)==7 and len(restricted)==2 and not (nonretail&restricted)
products=[]
for r in rc:
 id=r['RC_ID_EXISTING'];prefix,idx=re.fullmatch(r'RC-VZ-(FAL|PAN|FEN|BOS)-(\d{2})',id).groups()
 fam=family_map[prefix][int(idx)-1]
 if id in nonretail:status='INSTITUTIONAL-PROJECT / NO PUBLIC OFFER BY DEFAULT'; reason='infraestrutura/manutenção pública: exige contrato institucional e licença'
 elif id in restricted:status='RESTRICTED-SAFETY / NO PUBLIC OFFER';reason='consumível de risco: eficácia/armazenamento dependem de validação especializada'
 else:status='CONDITIONAL-PROPOSED-RETAIL-CANDIDATE';reason='produto de receita existente; qualificação ITEM/STORE/OFFER ainda não demonstrada'
 products.append({**r,'PROPOSED_FAMILY_CLASSIFICATION':fam,'PROPOSED_COMMERCIAL_ELIGIBILITY':status,'ELIGIBILITY_REASON':reason,'E2E_DOCUMENTED_ANCHOR':id in e2e})
assert len([r for r in products if r['PROPOSED_COMMERCIAL_ELIGIBILITY'].startswith('CONDITIONAL')])==39
store_city={r['STORE_ID_EXISTING']:(r['CITY_ID_EXISTING'],r['CITY_NAME']) for r in sh}
# 420 slots are planning positions, not SOURCE IDs. No new identities invented.
source_rows=[]
def source_core(i, role,orig_id,name,region,store,family,consumer_ids,doc,elig,gate,note):
 city=store_city.get(store,('',''))[0]
 return {'POSITION_ONLY_NOT_SOURCE_ID':i,'BOOKING_CLASS':role,'EXISTING_BLUEPRINT_REFERENCE_ID':orig_id,'EXISTING_BLUEPRINT_NAME':name,'NORMALIZED_NAME_FOR_DEDUPE':norm(name),'ORIGIN_REGION':region,'CITY_ID_ANCHOR_BLUEPRINT':city,'STORE_ID_ANCHOR_BLUEPRINT':store,'PROPOSED_SHOP_FAMILY':family,'CONSUMER_RC_IDS_BLUEPRINT':consumer_ids,'EXISTING_BLUEPRINT_SOURCE_URL':doc,'COMMERCIAL_ELIGIBILITY_GATE':elig,'SUSTAINABILITY_OR_SAFETY_GATE':gate,'ALIAS_ID': '', 'SEMANTIC_DEDUPE_VERDICT':'REQUIRES-INDEPENDENT-SEMANTIC-REVIEW','SOURCE_ID_MATERIAL':'','ITEM_ID_MATERIAL':'','OFFER_ID_MATERIAL':'','STATE':'PROVEN-IDENTITY-BLUEPRINT / COMMERCIAL-SOURCE-NOT-VERIFIED','MATERIAL_UAT_CREDIT':0,'OWNER_OR_PRODUCER_UNVERIFIED':'','NEXT_REQUIRED_PROOF':note}
for row in rv:
 name=row['NAME_EXISTING_BLUEPRINT']; id=row['RV_ID_EXISTING_BLUEPRINT']; gate=row['SUSTAINABILITY_AND_HARVEST_GATE']
 eligible='RV-80 MANDATORY-COMPOSITION; ADMISSION CONDICIONAL / NÃO MATERIAL'
 if id in no_rc:eligible+='; USO CIENTÍFICO PROPOSTO, COMÉRCIO NÃO COMPROVADO'
 source_rows.append(source_core(len(source_rows)+1,'RV80 EXISTING-BLUEPRINT',id,name,row['PRIMARY_REGION'],row['STORE_ORIGIN_ANCHOR_ID'],({'ERVA':'Ervas','MINERIO':'Minérios','ESSENCIA':'Outros','OUTRO-MATERIAL':'Outros'}.get(row['FAMILY'],'PENDING-CATEGORY')),row['RECIPE_CONSUMER_IDS_VERIFIED_BLUEPRINT'],row['SOURCE_NOTION_PAGE'],eligible,gate,'fonte comercial final, licenças/lote, alias e dedupe; NÃO assumir venda'))
for row in products:
 if not row['PROPOSED_COMMERCIAL_ELIGIBILITY'].startswith('CONDITIONAL'):continue
 source_rows.append(source_core(len(source_rows)+1,'RC48 OUTPUT/PRODUCT-NAME-BLUEPRINT',row['RC_ID_EXISTING'],row['PRODUCT_NAME_EXISTING_BLUEPRINT'],row['REGION_OUTPUT'],row['STORE_ID_EXISTING'],row['PROPOSED_FAMILY_CLASSIFICATION'],row['INGREDIENT_RV_IDS_BLUEPRINT'],URLS['RECIPE'],row['PROPOSED_COMMERCIAL_ELIGIBILITY'],'REC-EXEC + SUPPLY/QA + ITEM-CLASSIFICATION + PRICE/STOCK/ROUTE','ITEM-ID/PRODUCT source qualification and consumer route; proposal only'))
booked=len(source_rows);assert booked==119
for i in range(booked+1,421):
 source_rows.append(source_core(i,'VACANT-SOURCE-POSITION-NO-ENTITY','','','','','','',URLS['MANIFEST'],'NO-ID; NO-FILLER','NO-SPECIFICATIONS-IN-CANON','existing-first search, name/function/provenance, dedupe and eligibility before admission'))
assert len(source_rows)==420
# 1008 offer QUOTA positions, exact categories/store from Shop26. Position cannot serve as OFFER-ID.
offer_rows=[];queue=collections.defaultdict(list)
for r in sh:
 store=r['STORE_ID_EXISTING'];family=r['FAMILY_EXISTING'];count=int(r['OFFER_COUNT_BLUEPRINT_QUOTA'])
 for k in range(1,count+1):
  entry={'QUOTA_POSITION_ONLY_NOT_OFFER_ID':f'{store}::{family}::{k:03d}','STORE_ID_EXISTING':store,'CITY_ID_EXISTING':r['CITY_ID_EXISTING'],'CITY_EXISTING':r['CITY_NAME'],'FAMILY_QUOTA_EXISTING':family,'FAMILY_POSITION':k,'FAMILY_QUOTA_TOTAL':count,'RC_PRODUCT_BLUEPRINT_REF':'','PRODUCT_NAME_BLUEPRINT':'','BINDING_CLASS':'UNBOUND-QUOTA-ONLY','E2E_DOCUMENTARY_ANCHOR':'','QUALIFIED_SOURCE_ID':'','ITEM_ID_MATERIAL':'','OFFER_ID_MATERIAL':'','SOURCE_ORIGIN_ID':'','ROUTE_ID_CHAIN':'','HARVEST_OR_PROCESS_GATES':'','PRICE':'','STOCK':'','AVAILABILITY':'','REGULATORY_OR_AUTHORITY_GATES':'','STATE':'QUOTA-RESERVATION/NOT AN OFFER','MATERIAL_UAT_CREDIT':0,'SHOP_SOURCE_URL':URLS['SHOP']}
  offer_rows.append(entry);queue[(store,family)].append(entry)
assert len(offer_rows)==1008
# Prioritize E2E-verified chains, then other eligible RC product names.
for p in sorted([x for x in products if x['PROPOSED_COMMERCIAL_ELIGIBILITY'].startswith('CONDITIONAL')],key=lambda p:(p['RC_ID_EXISTING'] not in e2e,p['RC_ID_EXISTING'])):
 key=(p['STORE_ID_EXISTING'],p['PROPOSED_FAMILY_CLASSIFICATION']);available=queue[key]
 assert available,(key,p['RC_ID_EXISTING'])
 slot=available.pop(0)
 slot['RC_PRODUCT_BLUEPRINT_REF']=p['RC_ID_EXISTING'];slot['PRODUCT_NAME_BLUEPRINT']=p['PRODUCT_NAME_EXISTING_BLUEPRINT']
 slot['BINDING_CLASS']='PROPOSED-STORE-FAMILY-FIT / NO-OFFER-APPROVAL'
 slot['E2E_DOCUMENTARY_ANCHOR']=URLS['E2E'] if p['RC_ID_EXISTING'] in e2e else ''
 slot['SOURCE_ORIGIN_ID']=p['INGREDIENT_RV_IDS_BLUEPRINT']
 slot['ROUTE_ID_CHAIN']=p['IMPORT_RV_PATHS_DESIGN'] if p['IMPORTED_RV_OCCURRENCES']!='0' else 'LOCAL-BLUEPRINT / ROUTE-EXECUTION-UNVERIFIED'
 slot['HARVEST_OR_PROCESS_GATES']='REC-EXEC UNKNOWN + ecological/legal/source checks'
 slot['REGULATORY_OR_AUTHORITY_GATES']='R07 HOLD; quality; ITEM-ID; source-id; material gate'
 slot['STATE']='SPEC-PROPOSAL-ONLY / NOT-OFFER-ID / NOT-STOCK / NOT-SOLD'
assert sum(bool(x['RC_PRODUCT_BLUEPRINT_REF']) for x in offer_rows)==39
assert sum(bool(x['E2E_DOCUMENTARY_ANCHOR']) for x in offer_rows)==4
assert all(not x['ITEM_ID_MATERIAL'] and not x['OFFER_ID_MATERIAL'] for x in offer_rows)
# 143 source-reference edges to exact existing RV + recipe IDs, NOT commercial SOURCE.
bom_rows=[]
for r in rc:
 recipe=r['RC_ID_EXISTING'];ids=r['INGREDIENT_RV_IDS_BLUEPRINT'].split('|');names=r['INGREDIENT_NAMES_BLUEPRINT'].split('|');assert len(ids)==len(names)
 for k,(rv_id,rv_name) in enumerate(zip(ids,names),1):
  assert rv_id in rv_by,(recipe,rv_id)
  assert rv_by[rv_id]['NAME_EXISTING_BLUEPRINT']==rv_name,(recipe,rv_id,rv_name)
  imp=(rv_id.split('-')[1]!=recipe.split('-')[2]);paths=r['IMPORT_RV_PATHS_DESIGN']
  path=''
  if imp:
   m=re.search(rf'{re.escape(rv_id)}\(([^)]*)\)',paths); assert m,(recipe,rv_id,paths)
   path=m.group(1)
  bom_rows.append({'RECIPE_ID_EXISTING':recipe,'PRODUCT_NAME_BLUEPRINT':r['PRODUCT_NAME_EXISTING_BLUEPRINT'],'INGREDIENT_ORDER_DOCUMENTARY':k,'RV_ID_EXISTING':rv_id,'RV_NAME_EXISTING':rv_name,'ORIGIN_CITY_ID_EXISTING':rv_by[rv_id]['CITY_ID_ORIGIN'],'DESTINATION_CITY_ID_EXISTING':r['CITY_ID_EXISTING'],'CROSS_BIOME_DESIGN':'YES' if imp else 'NO','EXISTING_ROUTE_ID_CHAIN_DESIGN':path,'ROUTE_HOPS_BY_INGREDIENT_DESIGN':len(path.split('>')) if path else 0,'BLUEPRINT_EDGE_STATUS':'VERIFIED-NOMINAL-RV→RC','RV_MATERIAL_SOURCE_ID':'','BOM_APPROVED_QTY':'','STOCK_SHIPMENT_RECEIPT':'','SOURCE_RV_DOCUMENT':rv_by[rv_id]['SOURCE_NOTION_PAGE'],'RECIPE_SOURCE_DOCUMENT':URLS['RECIPE']})
assert len(bom_rows)==143 and len({x['RV_ID_EXISTING'] for x in bom_rows})==65
assert sum(x['CROSS_BIOME_DESIGN']=='YES' for x in bom_rows)==8
assert sum(x['ROUTE_HOPS_BY_INGREDIENT_DESIGN'] for x in bom_rows)==12
# Proven exclusivity restrictions; existing personal objects are never turned into commercial sources implicitly.
exclusions=[]
for p in products:
 if p['PROPOSED_COMMERCIAL_ELIGIBILITY'].startswith('CONDITIONAL'):continue
 exclusions.append({'DOCUMENT_REFERENCE':p['RC_ID_EXISTING'],'NAME':p['PRODUCT_NAME_EXISTING_BLUEPRINT'],'EXCLUSION_CLASS':p['PROPOSED_COMMERCIAL_ELIGIBILITY'],'REASON':p['ELIGIBILITY_REASON'],'SOURCE_URL':URLS['RECIPE'],'ALLOW_REVERSAL':'requires specialized safety/contract decision; no automatic offer'})
for i in range(1,17):
 exclusions.append({'DOCUMENT_REFERENCE':f'ITEM-VZ-PERS-{i:02d}','NAME':'existing personal item — name in ITEM-VZ-PERS page','EXCLUSION_CLASS':'PERSONAL/OUTSIDE-420','REASON':'existing owner-linked item: do not convert to store catalog without independent title/rights','SOURCE_URL':'https://app.notion.com/p/3f2c2b324ede8113aba6d601fd71cfa0','ALLOW_REVERSAL':'Mestre-authorized license/identity proof'})
assert len(exclusions)==25
# 16 genuinely distinct supplementary lab protocols (additional to frozen R02 8), all names/ingredients pulled from existing RC.
# Each tuple: ratios of current ingredients, stages, tools, technical acceptance, failure trigger, principle, risks, institutional/user.
protos={
'RC-VZ-FAL-02':([35,40,25],'inspecionar fibras sem abrasão; construir arnês sem carga viva; travar magnetita em costuras internas; registrar cinco ciclos de tração controlada','molde de arnês; bancada de tração protegida; gabarito de costuras','retenção do eixo e costuras estáveis em cinco ciclos sintéticos, sem desprendimento abrasivo','deformação de fivela, fratura de fibra ou descarga eletrostática','equipamento de mobilidade somente para manequim de bancada','quedas, carga elétrica e origem da fibra','oficina vertical do Mercado Suspenso'),
'RC-VZ-FAL-04':([40,35,25],'separar grãos de magnetita; orientar campo sem energizar bobina; fixar sensor feldspato; testar alinhamento versus referência do Observatório','goniômetro; mesa isolante; referência barométrica; gabarito de eixo','leitura reproduzível em amostras cegas sob três mudanças de pressão simuladas','deriva de leitura, inversão de pólo ou interferência de ferramenta','instrumento de navegação NÃO substitui cartografia nem testemunho climático','tempestade, interferência magnética','cartógrafo e mercador em Kher-Vhal'),
'RC-VZ-FAL-08':([15,45,40],'secar feltro; encapsular sal de ionização sem dispersão; sobrepor mica; comparar fluxo de partículas em recinto inerte sem ser humano','câmara selada; balança de bancada; medidor de partículas; luvas inertes','redução de partículas comparada a controle sem filtro, sem fuga de sal e sem alteração do instrumento','cristalização, vazamento de sais ou corrosão dos contatos','filtro de instrumento, NÃO proteção respiratória','irritantes, aerossóis e estilhaços de mica','oficina de sensores Kher-Vhal'),
'RC-VZ-FAL-11':([45,25,30],'laminar magnetita; aplicar Erva-Agulha como indicador de carga em forma inertizada; calibrar com orvalho seco; ensaiar aterramento em circuito fictício','placa isolante; fonte elétrica simulada; medidor de continuidade; lupa','continuidade rastreável e resposta do indicador em réplicas sem arco exposto','arco não controlado, solda fria ou variação de leitura','selo de referência experimental, não inscrição de combate','choque elétrico, umidade','Observatório de Tensão'),
'RC-VZ-PAN-02':([50,35,15],'moldar argila ferruginosa; intercalar fibras de junco; dosar essência em cápsula cega; aferir passagem de marcador espectral sintético','molde de máscara; câmara de teste inerte; indicador espectral; microscópio','integridade da vedação e retenção de marcador SOMENTE no cenário sintético, sem alegar proteção real','fuga no perímetro, mudança de odor sem correlação ou degradação por umidade','proteção não certificada até prova de filtragem por autoridade competente','contaminação, engano em EPI','Mercado das Nove Balsas'),
'RC-VZ-PAN-03':([55,20,25],'cozer recipiente de argila; usar salmoura como referência química mnemônica simulada; selar com resina; comparar amostra e branco durante transporte de maquete','forno controlado; lacre numerado; recipientes de controle; caderno de cadeia de custódia','marcador de amostra reproduzível e branco não contaminado, com lacre íntegro','migração de salmoura, violação do lacre ou efeito de memória sem fonte','forense / não uso clínico','amostras corrompidas, falsificação de procedência','Arquivo de Lodo'),
'RC-VZ-PAN-07':([40,25,35],'descrever composição qualitativa do lótus; registrar flor como marcador colorimétrico; estabilizar orvalho espectral em célula isolada; comparar marcador ferríneo inerte','vidraria selada; medidor de cor; testemunho negativo; cabine protegida','consistência colorimétrica de bancada em três lotes sintéticos, sem alegação de neutralização biológica','precipitado desconhecido, contaminação ou reação não prevista','ANTÍDOTO NÃO VALIDADO; proibir uso em seres vivos e comércio','eficácia clínica desconhecida, flora do Pântano sensível','Santuário das Águas Negras'),
'RC-VZ-PAN-11':([50,30,20],'preparar argila; incorporar turfa em baixa umidade; reforçar com junco de origem rastreada; ensaiar amostras versus argila pura em célula de canal','molde de amostras; estufa de baixa energia; bancada de cisalhamento; tanque de maquete','coesão e permeabilidade registradas contra argila controle sob três ciclos hídricos','lixiviação ferrífera, fissura ao secar ou perda de fibras','compósito de infraestrutura, não produto vendido sem teste de obra','erosão de canal e extração de junco','oficina de diques Myr-Zoryn'),
'RC-VZ-FEN-03':([20,60,20],'moldar corpo refratário; instalar lírio mineral só como indicador; usar Gás de Fissura Inerte em teste positivo de vedação, NÃO como filtro respirável','câmara de gás inerte; detector; molde de argila; lacre de teste','resposta ao gás de calibração em branco e teste, sem vazamento, sem reivindicar proteção respiratória','gás aparece fora do confinamento, indicador não responde ou máscara falha em vedação','EPI NÃO CERTIFICADO; E01 não filtra e não substitui oxigênio','asfixia, vapores de forja','Labirinto de Ventilação'),
'RC-VZ-FEN-05':([50,35,15],'selecionar vidro vulcânico; sobrepor obsidiana em gabarito protegido; aplicar pasta basáltica ao encaixe; ensaiar flexão em manequim rígido','molde de aresta; proteção contra estilhaços; durômetro comparativo; gabarito de punho','não desprender lâminas ou vedação nas três flexões sintéticas','fratura abrupta, projeção de cacos ou aderência deficiente','ferramenta de corte inerte somente em bancada','cortes, fragmentos','Forjas do Ventre Azul'),
'RC-VZ-FEN-07':([20,55,25],'isolar câmara de argila; reforçar com basalto; dosar gás E01 APENAS em recipiente de teste selado; registrar pressão ambiente, não industrial','recipiente de controle certificado; detector de fuga; massa inerte; bancada ventilada','nenhum sinal de fuga no ensaio selado e rastreabilidade completa da amostra','qualquer fuga, pressurização indevida ou recipiente não certificado','não fabricar tanque pressurizado; conceito de instrumento','asfixia, pressão, faísca','Labirinto de Ventilação'),
'RC-VZ-FEN-10':([30,45,25],'desidratar flor indicadora; preparar geodo reserva térmica; adicionar essência apenas em cápsula isolada; comparar contraste versus termômetro de referência em três gradientes','mesa térmica protegida; termômetro calibrado; caixa isolante; lupa','contraste correlacionado ao padrão sintético sem contaminação da flor','reflexo invertido, degradação térmica ou sinal negativo','indicador não é termostato; não prevê explosões','queimaduras, vapor','Elevador de Escória'),
'RC-VZ-BOS-02':([15,60,25],'separar orvalho prisma sob escuro; lapidar lente de quartzo em maquete; calibrar cristal da Aurora com luz de referência; testar distorção óptica em alvo não vivo','gabarito óptico; luxímetro; suporte antirreflexo; lente de referência','erro e dispersão registrados em três posições relativas, sem efeito visual não explicado','reflexo fantasma, aberração excessiva ou perda de selagem','EPI óptico somente após testes independentes','luminosidade intensa, deposição de gelo','Galeria dos Mil Reflexos'),
'RC-VZ-BOS-06':([45,25,30],'coletar pólen de forma não destrutiva sob licença; separar orvalho; misturar cera; marcar substrato de controle e medir contraste ao longo de ciclos de luz fria','placa de impressão; medidor de cor; câmara de luz; controle branco','persistência do marcador superior ao controle de cera, sem migração para água','esmaecimento, vazamento de pólen ou interferência na fauna','reagente de calibração, não tinta mágico-canônica','polinizadores, dispersão','Jardins de Geada'),
'RC-VZ-BOS-07':([40,35,25],'alinhar Musgo Espelho sem arrancar matriz viva; controlar camada de Pedra de Sombra Fria; vedar com Resina de Gelo-Luz; comparar reflexo e transparência','câmara de iluminação; polarímetro sintético; suporte de lente; alvo inerte','reduzir reflexo comparado ao suporte nu sem perder visibilidade de referência','sombreamento excessivo, quebradiço ou dispersão lumínica','proteção óptica somente após replicação','coleta sensível de musgo e refração','Galeria dos Mil Reflexos'),
'RC-VZ-BOS-09':([55,25,20],'inspecionar resina; estabilizar condensado boreal; adicionar pólen somente como marcador de qualidade; ensaiar selagem frio-seco versus controle sem resina','moldes de juntas; câmara fria; medidor de adesão; marcador fluorescente','adesão estável em três ciclos frios com identificação da amostra e sem emissão lumínica imprevista','falha de junta, perfuração ou emissão não autorizada','material técnico sem promessa de efeito mágico','polinização, frio, quebra de substrato','Galeria dos Mil Reflexos'),
}
assert len(protos)==16 and not set(protos)&{r['EXISTING_RECIPE_ID'] for r in pre8}
pre16=[]
for rid,(weights,steps,tools,accept,fail,principle,hazards,site) in protos.items():
 r=rc_by[rid];ids=r['INGREDIENT_RV_IDS_BLUEPRINT'].split('|');assert len(weights)==len(ids) and sum(weights)==100,(rid,ids,weights)
 pre16.append({'PROPOSED_SPEC_REFERENCE':'R03-RESEARCH-ONLY:'+rid,'EXISTING_RC_ID':rid,'EXISTING_PRODUCT_BLUEPRINT_NAME':r['PRODUCT_NAME_EXISTING_BLUEPRINT'],'EXISTING_BOM_RV_IDS':'|'.join(ids),'PROPOSED_LAB_MASS_PARTS_PER_100':'|'.join(f'{x}:{w}' for x,w in zip(ids,weights)),'RATIO_STATUS':'EXPERIMENTAL-DESIGN/NOT-APPROVED','PROCESS_STEPS_PROPOSED':steps,'TOOLS_BENCH_ONLY_PROPOSED':tools,'ACCEPTANCE_CANDIDATE':accept,'REJECTION_AND_DISPOSAL':fail,'PROHIBITED_INFERENCE':principle,'RISK_ECOLOGY':hazards,'KNOWN_ANCHOR_SITE':site,'CROSS_BIOME_ROUTE_DESIGN':r['IMPORT_RV_PATHS_DESIGN'],'MATERIAL_SOURCE_IDS':'','ITEM_ID':'','OFFER_ID':'','BOM_REAL_QTY':'','STATUS':'PRÉ-CRIAÇÃO PROPOSTA','PRODUCTION_ADMISSION':'DENY / R07 HOLD / NO REC-EXEC','DOCUMENT_AUTHORITY':URLS['RECIPE']})
# RV15 analytical advancement: exact existing site and R02 experimental proposal, add controls and negative test.
rv15_refinement={
'RV-BOS-E02':('parcelas espelhadas sem intervenção, com e sem presença de polinizadores','curva diária de assinatura lumínica por período e indivíduo vegetal','qualquer queda de visitação ou mudança do ciclo reprodutivo → interromper','Jardins de Geada; observador botânico, sem captura de fauna'),
'RV-BOS-H02':('herbário não destrutivo versus lâmina contaminada controlada','erro de detecção óptica da contaminação, antes e depois da limpeza','remoção de espécie rara, dano ao tecido vegetal ou falso positivo → HOLD','Galeria dos Mil Reflexos; curadoria botânica'),
'RV-BOS-H03':('trechos de solo sem perturbação contra áreas naturalmente abertas','densidade foliar e recuperação do corredor em duas estações documentais','erosão acelerada ou interferência de trilhas da fauna → STOP','Jardins de Geada; guarda ecológica'),
'RV-FAL-H03':('floração antes/depois de frente de pressão versus amostra abrigada','correlação pressão-reação com medição instrumental cega','falsa previsão perigosa para navegação → NOT-ADMITTED','Observatório de Tensão; meteorologia'),
'RV-FAL-H04':('placa de musgo fotografada contra cabo inerte sem musgo','tempo de retenção de umidade e marcador de descarga não energizado','colheita viva de superfície estrutural ou quebra de cabo → STOP','Ponte dos Sete Arcos; inspeção civil'),
'RV-FAL-H05':('observação fotográfica de raízes em encosta versus erosão em substrato falso','adesão radicular e perda superficial após chuva controlada em maquete','retirada de nichos animais, perda de estabilidade ou corte de planta matriz → REJECT','Ninhos Altos de Sílica; ecologia de encostas'),
'RV-FAL-M03':('catálogo de referência de vidro de raio mineral contra lâminas de carapaça animal','três assinaturas óticas independentes antes de rotular origem','amostra animal confundida com mineral ou origem ignorada → REJECT','Observatório de Tensão; geologia e perícia animal'),
'RV-FAL-O04':('painel de maquete com fissura conhecida e lâmina sem defeito','taxa de detecção visual e integridade em choque mecânico sem carga humana','fragmentação e risco de corte → parar; não usar em ponte viva','Ponte dos Sete Arcos; inspeção técnica'),
'RV-FEN-E02':('levantamento de vapor em dois dutos conhecidos versus trecho sem vapor','gradiente espacial medido fora do ponto de exposição direta','trabalho em ventilação sem proteção ou acúmulo de vapor → cancelar','Forjas do Ventre Azul; segurança de dutos'),
'RV-FEN-E03':('comparar frasco inerte de teste versus sensor de pressão de referência','erro de desvio no tempo, sem pressurizar recipientes artesanais','vazamento, corrosão e leitura falsa → não usar','Labirinto de Ventilação; oficina de metrologia'),
'RV-FEN-E05':('comparar mapa de névoa em zonas de barreira e corredor sem presença humana','alerta de exposição por local e evolução temporal sem coleta livre','risco respiratório ou poeira difusa → suspender e isolar','Elevador de Escória; segurança ambiental'),
'RV-FEN-H03':('área em sucessão natural versus escória removida por obra autorizada','cobertura vegetal e diversidade sem corte de cacto vivo','ninho destruído, solo instável ou espécie sentinela prejudicada → STOP','Elevador de Escória; fiscalização de recuperação'),
'RV-FEN-H04':('mapa radicular por método não invasivo versus fissura sem cobertura vegetal','orientação de raiz e integridade da matriz rochosa sem escavação profunda','fenda ampliada ou raiz seccionada → REJECT','Labirinto de Ventilação; geologia/ecologia'),
'RV-PAN-E04':('marcador de amostra contra controle salino não mnemônico, ambos sob lacre','consistência de fingerprint e taxa de troca detectada em prova cega','efeitos narrativos sem fonte, uso clínico ou fraude de laudo → HOLD','Arquivo de Lodo; arquivista autorizado'),
'RV-PAN-O05':('cerâmica em mini-dique experimental contra argila referência','permeabilidade e integridade após ciclo de inundação simulada','erosão de canal real, fissura por excesso de calor → REJECT','Mercado Flutuante de Nhar; engenharia de canais'),
}
assert set(rv15_refinement)==set(no_rc)
rv15_new=[]
for r in rv15:
 rid=r['EXISTING_RV_ID'];control,measure,stop,site=rv15_refinement[rid]
 rv15_new.append({'EXISTING_RV_ID':rid,'BLUEPRINT_NAME_EXISTING':r['EXISTING_BLUEPRINT_NAME'],'EXISTING_SITE_REFERENCE':r['EXISTING_SITE_ANCHOR_NAME'],'SOURCE_DOCUMENT':rv_by[rid]['SOURCE_NOTION_PAGE'],'EXISTING_R02_HYPOTHESIS':r['NON_RECIPE_FUNCTION_PROPOSED'],'EXPERIMENTAL_NEGATIVE_CONTROL':control,'SECOND_INDEPENDENT_MEASURE':measure,'REJECTION_OR_ENVIRONMENTAL_STOP':stop,'RESPONSIBLE_SITE_CANDIDATE':site,'EVIDENCE_BUNDLE_REQUEST':'origem+amostra licenciada+controle cego+metrologia+licença+revisão de impacto+readback','USE_CLASS':'NON-RECIPE SCIENCE / NOT-COMMERCIAL-BY-DEFAULT','FOLLOWUP_STATUS':'PROPOSTO-SEM-VALIDAÇÃO / NO-RC48-CONSUMER','MATERIAL_SOURCE_ID':'','OFFER_ID':'','SAFETY_FENCE':'no live subject, no Party, no economy credit'})
# Quota max feasibility tests with a uniqueness assumption (no hidden invented rules).
MIN_E=4*60;N=420;MAX_NO_REPEAT=MIN_E+4*(N-MIN_E);DIFFERENCE=1008-MAX_NO_REPEAT;MIN_DISTINCT=(1008+3*MIN_E+3)//4
assert MIN_E==240 and MAX_NO_REPEAT==960 and DIFFERENCE==48 and MIN_DISTINCT==432
# Stronger optional 'exactly 84 staples and remaining <=3 cities' constraint, not canon assertion.
MAX84=MIN_E+84*4+(N-MIN_E-84)*3
assert MAX84==864
source_file=writecsv('VZ_WS0003_R03_SOURCE420_POSITION_REGISTER_20261008.csv',source_rows)
offer_file=writecsv('VZ_WS0003_R03_OFFER1008_POSITION_REGISTER_20261008.csv',offer_rows)
edge_file=writecsv('VZ_WS0003_R03_RV_RC143_VERIFIED_EDGES_20261008.csv',bom_rows)
proto_file=writecsv('VZ_WS0003_R03_PRE16_NEW_PROTOCOLS_20261008.csv',pre16)
follow_file=writecsv('VZ_WS0003_R03_RV15_FOLLOWUP_PLANS_20261008.csv',rv15_new)
exclude_file=writecsv('VZ_WS0003_R03_EXCLUSIONS_20261008.csv',exclusions)
prod_file=writecsv('VZ_WS0003_R03_RC48_SHOP_CLASSIFICATION_20261008.csv',products)
source_by_ref={x['EXISTING_BLUEPRINT_REFERENCE_ID']:x for x in source_rows if x['EXISTING_BLUEPRINT_REFERENCE_ID']}
assert len(source_by_ref)==119
metrics={'rv_existing_blueprints':80,'rv_in_rc48':65,'rv_without_rc48':15,'rc_existing_blueprints':48,'rv_to_rc_edges':143,'source_420_planning_positions':420,'source_positions_booked_identity_candidate':119,'source_positions_remaining_without_identity':301,'source_positions_rv':80,'source_positions_rc_product_candidate':39,'rc_outputs_restricted_or_institutional_not_booked':9,'offer_1008_quota_positions':1008,'offer_positions_conditional_rc_candidate':39,'offer_positions_unbound':969,'offer_positions_e2e_existing_documentary':4,'offer_material_records':0,'source_material_records':0,'store_family_quotas':56,'store_count':4,'extra_new_recipe_protocols_R03':16,'existing_recipe_protocols_R02':8,'recipe_protocol_spec_total_R02plusR03':24,'new_field_test_followups_R03':15,'distinct_product_or_resource_names_existing_blueprint':128,'excluded_personal_items':16,'r01_design_slot_preserved':200,'uats_total_unchanged':1649,'uats_material':0,'capacity_bound_if_1_ITEM_x_1_STORE_offer_unique_and_60_exclusive_each':960,'capacity_shortfall_conditional':48,'min_distinct_sources_same_conditions_if_1008_offers':432,'optional_bound_if_exactly_84_four_store_staples_rest_at_most_3_stores':864}
assert sum(int(x['OFFER_COUNT_BLUEPRINT_QUOTA']) for x in sh)==1008
assert collections.Counter(x['STORE_ID_EXISTING'] for x in offer_rows)==collections.Counter({'STORE-VZ-KH-01':252,'STORE-VZ-MY-01':252,'STORE-VZ-KV-01':252,'STORE-VZ-AU-01':252})
assert all(x['MATERIAL_UAT_CREDIT']==0 for x in source_rows+offer_rows)
assert len({x['QUOTA_POSITION_ONLY_NOT_OFFER_ID'] for x in offer_rows})==1008
assert len({x['POSITION_ONLY_NOT_SOURCE_ID'] for x in source_rows})==420
assert all(p['EXISTING_RC_ID'] in rc_by and p['MATERIAL_SOURCE_IDS']=='' for p in pre16)
assert all(x['COMMERCIAL_ELIGIBILITY_GATE']!='APPROVED' for x in source_rows)
# Source files hash coverage included; do not copy R01/V1/V2.
input_hashes={f:hashlib.sha256((IN/f).read_bytes()).hexdigest() for f in ['VZ_WS0003_R02_RV80_Consumer_Register_20261008.csv','VZ_WS0003_R02_RC48_BOM_Evidence_20261008.csv','VZ_WS0003_R02_SHOP56_Quota_vs_Identity_20261008.csv','VZ_WS0003_R02_RV15_NonRecipe_Research_20261008.csv','VZ_WS0003_R02_PRE8_Lab_Prototypes_20261008.csv','VZ_WS0003_INTEGRACAO_R01_Crosswalk_200_Evidencia_20261008.csv']}
qa={'operation':'CM-000005 / WS0003 VHAL-ZORYN R03','version':'R03-20261008','status':'RESEARCH-PRECREATE / DESIGN-ONLY / NO-WRITER-OR-MATERIAL','source_t16':'PENDING-READBACK confirmed Control; IBX18 unchanged','mestre_correction':'VLAB order revoked for this instance; stop all VLAB engineering; archive only','metrics':metrics,'source_readbacks':{'R01_CROSSWALK':'LIBRARY BYTE READBACK','R02_CORPUS':'LIBRARY BYTE READBACK','Notion':'SOURCE/T16/FUSION readback 2026-10-08'},'input_sha256':input_hashes,'originals_untouched':True,'B04_B09_B10':'3 crosswalk identities previously verified; CORE decisions remain 0/3 approved','NC05':'Historical negative; postpatch independent review pending','T16':'PENDING-READBACK, not ACTIVE, no IBX-18 write','material':'0/1649; SOURCE0/420 and OFFER0/1008'}
(OUT/'VZ_WS0003_R03_QA_20261008.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('R03 data built, metrics:')
for k,v in metrics.items(): print(f'{k}: {v}')
