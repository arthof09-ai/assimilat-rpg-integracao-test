
"""PLAN75 P1: deterministic scheduler-gate study, non-production, no network or Notion writes."""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from dataclasses import dataclass
import re, html, json, hashlib
from collections import Counter

TZ = ZoneInfo("America/Recife")
WINDOW_SECONDS = 900
MARKER = re.compile(
    r"^SCI-P75-R04-S[123]-W0[1-5] \| (?:COMMENT|WRITE)=COMMITTED-UNVERIFIED$"
)

@dataclass(frozen=True)
class TemporalObservation:
    id: str
    nominal_hhmmss: str
    observed_hhmmss: str
    provenance: str  # native Notion effect timestamp vs scheduler's last_run

OBSERVATIONS = (
    TemporalObservation("R03-D01", "06:52:00", "06:48:39.393", "COMMENT-TIMESTAMP"),
    TemporalObservation("R04-S1-W02", "10:10:00", "10:14:36.017", "COMMENT-TIMESTAMP"),
    TemporalObservation("R04-S1-W01", "09:10:00", "09:08:24.627", "SCHEDULER-LAST-RUN"),
    TemporalObservation("R04-S2-W02", "10:22:00", "10:22:28.826", "SCHEDULER-LAST-RUN"),
    TemporalObservation("R03-C01", "06:45:00", "06:46:22.073", "SCHEDULER-LAST-RUN"),
)

def wall_time(s):
    return datetime.fromisoformat(f"2026-10-09T{s}").replace(tzinfo=TZ)

def jitter_seconds(item):
    return (wall_time(item.observed_hhmmss)-wall_time(item.nominal_hhmmss)).total_seconds()

def temporal_gate(actual_time, service_nominal, max_window=WINDOW_SECONDS):
    """No physical effect may occur before service nominal or after deadline."""
    delta = (actual_time-service_nominal).total_seconds()
    if delta < 0:
        return "EARLY-NO-WRITE"
    if delta > max_window:
        return "LATE-NO-WRITE"
    return "ELIGIBLE"

def exact_marker(text):
    """Match standalone marker only; repeated pipes may be escaped by Notion serialization."""
    candidate = html.unescape(text).strip().strip("`").strip()
    candidate = re.sub(r"\\+\|", "|", candidate)
    candidate = re.sub(r"\s*\|\s*", " | ", candidate)
    return bool(MARKER.fullmatch(candidate))

def eligible_to_write(actual_time, nominal, current_real_comments, marker,
                      permission, unknown=False, task_active=True):
    status = temporal_gate(actual_time, nominal)
    if status != "ELIGIBLE":
        return status
    if not task_active:
        return "INACTIVE-NO-WRITE"
    hits = sum(exact_marker(c) and normalized(c) == normalized(marker)
               for c in current_real_comments)
    if hits > 1:
        return "DUPLICATE-HOLD"
    if hits == 1:
        return "NOOP-EXISTS"
    if unknown:
        return "UNKNOWN-HOLD"
    if not permission:
        return "DENIED-HOLD"
    return "ONE-WRITE"

def normalized(text):
    s = html.unescape(text).strip().strip("`").strip()
    s = re.sub(r"\\+\|", "|", s)
    s = re.sub(r"\s*\|\s*", " | ", s)
    return s

def scorer(effect_timestamps, service_nominal, expected_marker, first_wake=True):
    """Conservative score: a single exact independent effect, within contractual window."""
    exact_effects = [(text, ts) for text, ts in effect_timestamps
                     if exact_marker(text) and normalized(text) == normalized(expected_marker)]
    if len(exact_effects) > 1:
        return "DUPLICATE-FAIL"
    if len(exact_effects) == 0:
        return "ABSENT"
    if not first_wake:
        return "RECOVERY-NOT-FRPE"
    ts = exact_effects[0][1]
    if ts is None:
        return "TEMPORAL-PROVENANCE-UNKNOWN"
    return "TEMPORAL-SUCCESS" if temporal_gate(ts, service_nominal) == "ELIGIBLE" else "OUT-OF-WINDOW"

def bias_table(observations=OBSERVATIONS):
    # Model-only study: assumes future scheduling jitter identical to five observed offsets;
    # never a claim that changing schedule fixes actual connector failures.
    rows = []
    for bias_minutes in range(0, 11):
        accepted = sum(0 <= jitter_seconds(x) + bias_minutes*60 <= WINDOW_SECONDS
                       for x in observations)
        comment_only = sum(0 <= jitter_seconds(x) + bias_minutes*60 <= WINDOW_SECONDS
                           for x in observations if x.provenance == "COMMENT-TIMESTAMP")
        rows.append(dict(bias_minutes=bias_minutes,
                         model_all_observations=f"{accepted}/{len(observations)}",
                         model_native_comments=f"{comment_only}/2"))
    return rows

def tests():
    checks = 0
    cases = 0
    counter = Counter()
    marker = "SCI-P75-R04-S1-W02 | COMMENT=COMMITTED-UNVERIFIED"
    malformed = [
        f"EXPECTED {marker}", f"{marker} suffix", f"prefix {marker}",
        "SCI-P75-R04-S1-W02 | COMMENT=COMMITTED-UNVERIFIED\nSECOND",
        "SCI-P75-R04-S1-W02 | EFFECT=COMMITTED-UNVERIFIED",
        "SCI-P75-R04-S1-W02 | COMMENT=COMMITTED-UNVERIFIEDXX",
        "SCI-P75-R04-S1-W02 | COMMENT=COMMITTED-UNVERIFIED EXTRA",
        "SCI-P75-R04-S1-W99 | COMMENT=COMMITTED-UNVERIFIED",
    ]
    for m in malformed:
        cases += 1; checks += 1
        assert not exact_marker(m), ("FALSE-POSITIVE", m)
    for m in [marker, marker.replace("|", "\\|"),
              marker.replace("|", "\\\\|"), f"`{marker}`"]:
        cases += 1; checks += 1
        assert exact_marker(m), ("FALSE-NEGATIVE", m)
    start = wall_time("10:10:00")
    # Exhaustive each second across 40 minutes, 2 methods, 2 permissions,
    # 2 knowledge states, 2 activity states, all marker multiplicities.
    for shift in range(-600, 1801):
        now = start + timedelta(seconds=shift)
        for method in ("COMMENT","WRITE"):
            cur = marker.replace("COMMENT", method)
            for permission in (True,False):
                for unknown in (True,False):
                    for active in (True,False):
                        for multiplicity in (0,1,2):
                            cases += 1
                            present = [cur.replace("|","\\|")]*multiplicity
                            action = eligible_to_write(now,start,present,cur,permission,unknown,active)
                            counter[action] += 1
                            checks += 1
                            assert action in {"EARLY-NO-WRITE","LATE-NO-WRITE",
                                              "INACTIVE-NO-WRITE","DUPLICATE-HOLD",
                                              "NOOP-EXISTS","UNKNOWN-HOLD",
                                              "DENIED-HOLD","ONE-WRITE"}
                            if shift < 0: checks+=1; assert action=="EARLY-NO-WRITE"
                            if shift > WINDOW_SECONDS: checks+=1; assert action=="LATE-NO-WRITE"
                            if action=="ONE-WRITE":
                                checks+=4
                                assert shift>=0 and shift<=900 and permission and active and not unknown
    # Verify scorer distinguishes late effect, duplicate, recovery and unknown timestamps.
    for entries,fw,expected in [
        ([(marker,start)],True,"TEMPORAL-SUCCESS"),
        ([(marker,start-timedelta(seconds=1))],True,"OUT-OF-WINDOW"),
        ([(marker,start+timedelta(seconds=900))],True,"TEMPORAL-SUCCESS"),
        ([(marker,start+timedelta(seconds=901))],True,"OUT-OF-WINDOW"),
        ([(marker,None)],True,"TEMPORAL-PROVENANCE-UNKNOWN"),
        ([(marker,start)],False,"RECOVERY-NOT-FRPE"),
        ([(marker,start),(marker,start)],True,"DUPLICATE-FAIL"),
        ([],True,"ABSENT"),
        ([(f"EXPECTED {marker}",start)],True,"ABSENT"),
    ]:
        cases+=1;checks+=1
        assert scorer(entries,start,marker,fw)==expected
    # Actual observed jitter kept as two provenance classes.
    model=bias_table()
    assert next(r for r in model if r["bias_minutes"]==4)["model_native_comments"]=="2/2"
    cases+=1;checks+=1
    return dict(cases=cases,checks=checks,failures=0,
                decisions=dict(counter),bias_study=model,
                observed_jitter=[dict(id=x.id,origin=x.provenance,
                                      jitter_seconds=round(jitter_seconds(x),3))
                                 for x in OBSERVATIONS],
                warning="Deterministic replay of observed offsets is NOT field FRPE or an independent scheduler trial.")

if __name__=="__main__":
    print(json.dumps(tests(),indent=2,ensure_ascii=False))
