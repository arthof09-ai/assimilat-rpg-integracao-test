
"""PLAN75 P1 robust bias sensitivity, deterministic, no service access."""
import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from plan75_p1_clock import OBSERVATIONS, jitter_seconds, WINDOW_SECONDS

def analyze(perturb_seconds=180):
    obs = [jitter_seconds(o) for o in OBSERVATIONS]
    rows = []
    for bias_minutes in range(11):
        shifted = [j+60*bias_minutes for j in obs]
        early_margin=min(shifted)
        late_margin=WINDOW_SECONDS-max(shifted)
        robust_margin=min(early_margin,late_margin)
        count=total=0
        for jitter in shifted:
            for epsilon in range(-perturb_seconds,perturb_seconds+1):
                total+=1
                count+= int(0 <= jitter+epsilon <= WINDOW_SECONDS)
        rows.append({"shift_minutes":bias_minutes,
                     "observed_eligible":sum(0<=x<=900 for x in shifted),
                     "observed_sample":len(obs),
                     "earliest_margin_seconds":round(early_margin,3),
                     "latest_margin_seconds":round(late_margin,3),
                     "min_margin_seconds":round(robust_margin,3),
                     "adversarial_perturbation_eligible":count,
                     "adversarial_total":total,
                     "universal_plusminus_3min":count==total})
    best=max(rows,key=lambda r:r["min_margin_seconds"])
    assert best["shift_minutes"]==7
    assert best["universal_plusminus_3min"]
    assert not next(x for x in rows if x["shift_minutes"]==5)["universal_plusminus_3min"]
    assert rows[0]["observed_eligible"]==3
    return {"assumption":"Each historical jitter could deviate independently by +/- 180sec in a future call; this is a stress model, not a probabilistic forecast.",
            "best_margin":best,"all_biases":rows,
            "hard_reliability_bound":"P(FRPE)<=P(connector-write-authorized) in one-write workflow: timing-only patches cannot compensate for connector-denied.",
            "n_observations":len(obs),"n_notions_native":2,"n_scheduler_last_run_proxies":3,
            "tests":{"assertions":4,"failures":0},
            "status":"MODEL-ONLY; NAC-HOLD; no canonic or worker mutations"}
if __name__=="__main__":
    print(json.dumps(analyze(),indent=2,ensure_ascii=False))
