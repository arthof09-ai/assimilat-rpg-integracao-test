# SCI-WS0003 / INTEGRACAO-R01 — Auditoria ecológica e econômica pós-FUSION-E3

**Classificação:** MESTRE-SIDE · CM-000005-I0011 · OP-SCI-CX99-02 / WS0003 · 08/10/2026. **READ-ONLY nas autoridades normativas e materiais.** Avaliação do Cientista, **não é NC-05**, nem NAC-PASS arquitetural nem validação ecológica independente.

## 1. Evidências sem reconstrução do V2

A matriz derivada **VZ_WS0003_INTEGRACAO_R01_Crosswalk_200_Evidencia_20261008.csv** tem **200 posições** já conhecidas (40 Bestas, 50 históricos LEGACY-B, 150 V2). É **índice de evidências e limites**, não nova ficha, drop, SOURCE ou receita; V1/V2 originais permanecem congelados.

| Origem congelada | SHA256 observado |
|---|---|
| VZ_WS0003_Crosswalk_200_Drops_20261008.csv | `061d77f1d83e632adec3d8c81a4f97c4a4e24add766665360310d6b264b36bdd` |
| VZ_WS0003_V2_Precriacao_150_Drops_20261008.csv | `e251fe0de087cdd39f522dc47c59acda2cc1dbb2422614b72f9afedb1a49aede` |
| VZ_WS0003_V2_Deltas_Renames_20261008.csv | `af23b31a8b800cdb3c6347617e10fb6fdbca8eeb1ea1ed30d05044d4cc749bf9` |

**Fontes Notion reabertas:** BEAST-VZ-CORPUS-40 (40 espécies, niches/primário), quatro RESOURCE-VZ-20 (80 RV nominais), RECIPE-VZ-CORPUS-48 (48 RC), SHOP-VZ-EXEC-01 (quatro lojas × 252), MANIFEST 1649, DEP-VZ-ECO-01, VZ-ECO-E2E-01, NORM-BEAST-DROP-ECO-01, PRECREATE e parecer independente AUD-5XB-FUSION-E3 / IBX-35. Números citados destas páginas não constituem mutação delas.

## 2. Auditoria de integridade nominal — verificada no projeto documental

| Teste | Resultado | Limite |
|---|---:|---|
| Design-slot único / identidade Besta na V1/V2 | **200/200** | somente estrutura, não drop material |
| Nome V2 = V1 exceto delta explícito | **150/150; 12 deltas** | renomes são candidatos, sem substituir V1 |
| Bioma primário de cada slot = corpus de 40 | **200/200** | não valida bindings secundários |
| Campos anatômicos e coleta + 2 compatibilidades/1 incompatibilidade preenchidos | **150/150** | valida completude da hipótese, não eficácia |
| IDs RV atuais confrontados | **80/80 nomes** | 80 fontes blueprint, não registro material de 420 |
| IDs RC atuais e nomes confrontados | **48/48** | produto efetivo/receita executada não provado |
| SOURCE-ID e OFFER-ID materialmente atribuídos | **0/200** | não fabricar crédito |
| Drops legados CORE sem objeção geográfica específica | **17/20** | não equivale a 17 CORE qualificados fisicamente |
| CORE com proveniência regional pendente | **3/20** | D09B, D09D, D10D; NÃO excluir legado |

## 3. Ligações verdadeiras versus hipóteses de consumo

**Evidência documental obtida:** 137/150 posições V2 propõem participação em receitas existentes, com 138 arestas porque `DESIGN-SLOT:B-VZ-BOS-07:01` cita RC-VZ-BOS-04 e RC-VZ-BOS-09. **Quatro LEGACY** recebem candidatos explícitos em anexo de calibração da Recipe31: `UAT-B-D01C → RC-VZ-FAL-08`, `UAT-B-D04A → RC-VZ-PAN-05`, `UAT-B-D05A → RC-VZ-FEN-01`, `UAT-B-D08A → RC-VZ-BOS-02`. O texto da Recipe31 diz expressamente que não são substituições ou ingredientes atuais da BOM.

**Total comprovado como DOCUMENTÁRIO E CANDIDATO:** **141/200 posições** com **142 arestas de intenção** direcionadas a **42/48 RC distintos**; **59 posições** sem RC nomeada (13 V2 e 46 LEGACY), sem obrigatoriedade de forçar destino comercial. **Material BOM aprovado: 0 vínculo de drop V2** nesta matriz; `SOURCE-ID=NONE`, `OFFER-ID=NONE`, `ITEM-ID material=NONE`, `PRICE=NOT-DEFINED`, `YIELD=NOT-MEASURED`. As 48 RC canônicas são RV-based até nova validação; não inserir ingredientes implícitos.

**RC sem candidato V2 nominal na matriz:** RC-VZ-BOS-03, RC-VZ-FAL-01, RC-VZ-FAL-11, RC-VZ-FEN-05, RC-VZ-FEN-12, RC-VZ-PAN-06. Isto é observação da V2, não prova de falta de consumidores de outras fontes.

## 4. Escassez ecológica e capacidade de oferta

| Categoria de obtenção na V2 | Quantidade/150 | Decisão de engenharia |
|---|---:|---|
| NECROPSIA-ONLY | **66** | lote apenas com carcaça licenciada e morte natural; não orçar reposição constante |
| ESPÉCIE-SENSÍVEL | **15** | licença, estudo de população, quotas e não perturbação antes de comércio |
| COLETA PASSIVA | **31** | frequência real, contaminação e sazonalidade pendentes |
| AMOSTRAGEM CONDICIONADA | **38** | janela segura e conservação ainda não testadas |

Das **137 posições V2 com RC candidata**, **74** pertencem às duas primeiras classes de risco. São **hipóteses de componentes opcionais**, não cadeia de suprimento ativa. O exemplo da `RC-VZ-PAN-09` possui seis V2 candidatas; quatro exigem necropsia e duas são sensíveis. Inserir todos como ingredientes necessários criaria receita praticamente inexequível, contradizendo REC-EXEC, DEP-VZ-ECO e NO-FILLER. O alinhamento recomendado é ensaio **substitutivo/opcional**, comparado a RV existente, nunca requisito automático.

As quatro lojas SHOP26 têm **22+28+28+14 = 92 OFFER** da categoria Drops/Materiais. **Se** todos os 200 drops precisassem de exposição direta nessa categoria nas quatro lojas, faltariam **pelo menos 108 ocorrências** (200−92), antes da duplicação entre lojas. **Esse requisito NÃO existe**: drop verdadeiro biológico ≠ drop comercial ≠ SOURCE ≠ OFFER. Portanto, o cenário de 200 SOURCE comerciais não deve ser assumido por simples paridade biológica. Consumidores de pesquisa, NPCs e crafting podem existir sem loja, mas não contam como SOURCE comercial UAT sem elegibilidade real.

Para alcançar 420 SOURCE únicos sob SHOP26, 4×60 exclusivos + 84 compartilhados exigem **ao menos 324 identidades comerciais distintas com tais padrões de distribuição**, sob dedupe (240 exclusivos + 84 staples comuns). A existência dos 80 RV e 48 RC *blueprints* não comprova a cobertura dos 420 ITEM-ID comerciais. Uma `SOURCE_ID` pode aparecer em mais de uma OFFER, sem duplicar sua identidade; uma mesma Besta em bioma secundário não vira segundo ID nem crédito CORE sem binding comprovado.

## 5. Duplicidade lexical versus duplicidade real

Triagem automatizada de sobreposição de tokens, **não uma prova de equivalência ontológica**: **10 alertas altos** (Jaccard ≥ 0,5) e **7 médios** (0,33–0,49) comparando os 200 nomes de drops contra 80 RV. São **17 casos para revisão de origem**, não 17 duplicatas. Nenhum nome final de design coincide exatamente com nome RV.

- `UAT-B-D03A Galhada de Ferro Vivo` x `RV-PAN-M03 Nódulo de Ferro Vivo`: galhada animal versus biomineral de raízes e micróbios; nomes compartilham função mas espécies/fontes são distintas no desenho.
- `B-VZ-FEN-09:01 Carapaça de Vidro Vulcânico` x `RV-FEN-M02 Vidro Vulcânico Azul`: carapaça secretada pelo Escorpião e minério eruptivo; exigir microscopia de cutícula/impurezas, não atribuir novo SOURCE sem teste.
- `B-VZ-BOS-07:01 Seda de Gelo-Luz` x `RV-BOS-M02 Quartzo de Gelo-Luz`: proteína secretada pela aranha versus cristal mineral; risco de nome comercial ambíguo, resolver por etiqueta/proveniência, não por fusão dos objetos.

Essas três distinções são **plausíveis no blueprint**. Necessária inspeção independente de identidade e material antes de classificá-las comercialmente. Outros 14 alertas mantidos para revisão, sem inventar exclusões.

## 6. B04/B09/B10 — proposta reversível sem mutar espécies ou CORE históricos

- **B04** (`UAT-B-B04 → B-VZ-PAN-02`): LEGACY Terra/Espectral versus E3 Água/Espectral, bioma Pântano em ambas. Não alterar elemento. Registrar qual versão é autoridade atual e qual é legado; validar anatomia D04A/C/E e P3-02 como indivíduo, não espécie.
- **B09** (`UAT-B-B09 → B-VZ-BOS-03`): Bosque primário E3; LEGACY Falésias/Pântano como transição candidata. `UAT-B-D09B` CORE Falésias e `UAT-B-D09D` CORE Pântano ficam HOLD sem REGION-BINDING.
- **B10** (`UAT-B-B10 → B-VZ-FEN-03`): Fenda primária E3; LEGACY Bosque secundário candidato. `UAT-B-D10D` CORE Bosque HOLD sem prova da presença da espécie nessa região.

**Reserva de substituição CORE sem criar Besta ou drop:** caso bindings antigos não se sustentem, testar `UAT-B-D02B Garra de Sílica Negra` de `B-VZ-FAL-02` para Falésias; `UAT-B-D03B Pelo de Lua Ferrosa` de `B-VZ-PAN-01` para Pântano; `UAT-B-D08B Presa de Luz Fria` de `B-VZ-BOS-02` para Bosque. São **três IDs históricos EXTRA existentes** nas espécies primárias desses biomas. **PROPOSTO** apenas: não alterar 20 CORE históricos, não certificar coleta, não adicionar UAT. Ensaio de anatomia, sazonalidade, origem, espécie VERIFIED, comparabilidade comercial e autorização obrigatórios antes de qualquer reclassificação.

## 7. R14–R16 — critérios restantes e saída objetivamente mensurável

| Predicado do Cientista | Causa verificada | Critério de saída (ainda NÃO alcançado) |
|---|---|---|
| **R14** | Canon E3 qualifica Mestre 5×B como SUPERSEDED-VZ; parecer independente do Auditor confirma precedência Mestre, mas voto de absorção é CORREÇÕES NECESSÁRIAS/HOLD | NAC-NORM-01 completo, autoridade competente, texto Canon qualificado sem apagar histórico, readback e REPA |
| **R15** | PRECREATE §10 e NORM 5×B divergem de VZ-CANON, Quality37, Matrix09 e consumidores | 5 drops verdadeiros/Besta e 5 CORE/bioma em campos distintos, fanout consistente, 16 predicados refeitos na fonte nova |
| **R16** | Manifest 420 SOURCE comerciais únicos sem crosswalk nominal integral 200↔SOURCE↔RC/BOM↔STORE/OFFER | SOURCE-ID atual ou NONE para cada um; 420 SOURCE/1008 OFFER/48 RC e 24 células conciliados, dedupe, identidades do produto e preço/estoque com gate, 1649 NO-CHANGE-PROVEN ou nova D aprovada |

**Este documento NÃO promove PATCH03, NÃO declara 16/16.** Auditoria original NC-05 permanece negativa. A entrega do parecer independente IBX-35 foi recebida e marcada `ACK` por CM-000005-I0011, comprovando bilateralidade; o voto pede CORREÇÕES e não concede writer.

## 8. Ponto exato de retomada e governança

**LAST-VERIFIED:** 40 BLUEPRINT E3; 50 drop LEGACY; 150 V2 bytes congelados; 80 RV nominais das quatro páginas RESOURCE-20; 48 RC nominais; 4 STORES / 1008 OFFER de design; parecer independente 5×B IBX-35 lido e ACK; 200 posições por script local; 142 RC candidature edges; 3 CORE-region HOLD.

**FIRST-PENDING:** reservar domínio documental Matriz09/IBX18 para anexar esta reconciliação como EVIDÊNCIA/PROPOSTA, sem mutar Canon/PROMO/Norm/Manifest/SHOP/RC; depois solicitar NAC-NORM completo/autorização do PATCH03 com riscos, fanout e critérios. Manter NAC-PASS arquitetural, ABS-L, R07 e material DENY/HOLD. **NO-REPEAT:** V1/V2, seis arquivos íntegros, FUSION-E3 D01–D17, votos NC-05.

**Estados:** `AUDIT-SCI-LOCAL=STRUCTURAL-PASS`, `SEMANTIC-ECO=AUDIT-PENDING`, `SOURCE420=UNRECONCILED`, `PATCH03=HOLD`, `R14=HOLD`, `R15=HOLD`, `R16=HOLD`, `R07=HOLD`, `MATERIAL=0/1649`, `PARTY/O-PRIMEIRO=0`, `SCHEDULER=DO-NOT-ARM`.
