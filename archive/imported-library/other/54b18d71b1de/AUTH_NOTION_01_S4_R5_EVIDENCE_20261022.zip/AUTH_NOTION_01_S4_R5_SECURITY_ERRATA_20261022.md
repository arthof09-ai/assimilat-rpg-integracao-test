# PSV — AUTH-NOTION-01 R5 | Correção de vazamento sintético por classificação inadequada

**Status:** S4 PROPOSTA. **NAC-PASS global:** HOLD. **Alvo:** exclusivamente laboratório de decisão isolado. **Nenhum vazamento real observado.**

## Falha reproduzida na revisão adversarial

Na R3 a condição de veto usava `content_kind == 'mester_only'` (grafia incorreta), e o default também era `mester_only`. Uma entrada com o identificador semanticamente correto `mestre_only` no destino `party`, sem outras restrições ativas, era incorretamente classificada como `OPERATIONAL_READ`.

**Reprodução antes do patch:** `destination='party'` + `content_kind='mestre_only'` → `OPERATIONAL_READ` (BUG LAB). Este resultado não foi observado no Notion; decorre apenas do classificador sintético.

## Correção R5 — regra da lista permitida

1. `content_kind` canônico padrão passou a `mestre_only`.
2. Para destino Party, negar tudo que **não seja explicitamente `party_safe`**, sem tentar enumerar grafias sigilosas; rótulos desconhecidos também são negados.
3. `content_class_verified` deve ser explicitamente verdadeiro para permitir o fluxo Party. **Default `False` (fail-closed)**; marcar `party_safe` sem prova documental não autoriza transferir dados.
4. Destino/workspace desconhecido → `DENY_UNKNOWN_WORKSPACE`.
5. Escrita sem `idempotency_key_present` → `DENY_MISSING_IDEMPOTENCY_KEY`.
6. Preserva a R3: timeout/reject após commit e readback positivo → `VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE`.

## Aceites isolados

- **R5:** 248 parametrizações, **63 combinações distintas de entradas**, 248/248 PASS.
- **Mutação negativa:** 19/19 falhas deliberadas detectadas pela suíte, incluindo bypass de classificação Mestre-only, rótulo não comprovado, destino desconhecido e ausência de idempotência.
- **Canários locais:** 16/16.
- **Propriedades sintéticas:** 65.536/65.536 invariantes PASS.
- **Persistência funcional local SQLite R4:** 80/80 testes reais de arquivo temporário PASS, com zero páginas Notion escritas. Não é transação real de Notion.

O resultado sintético do BUG ficou preservado nos pacotes R2/R3; a correção está no pacote R5. **Não apagar histórico nem atribuir efeito a Party/O Primeiro.**

## GATE

A nova defesa do modelo é materialmente melhor, mas não atribui dados canônicos, não confere verificação independente do tipo de conteúdo, nem protege por si só sistemas sem essa camada conectada. Exige revisão de integração, código real de produção sob writer autorizado, teste de Sucessor Cego, S4 live controlado, MIE/TEE na mãe, GNN, GP-NAC e NAC-PASS terminal. **HOLD.**
