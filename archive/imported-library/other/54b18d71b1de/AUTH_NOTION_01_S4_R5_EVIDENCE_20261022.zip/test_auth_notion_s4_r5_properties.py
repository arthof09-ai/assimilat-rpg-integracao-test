#!/usr/bin/env python3
"""Property-based exhaustive state combinations for AUTH-NOTION-01 R5 (mock model only)."""
import contextlib,io,importlib.util,json,itertools,sys
from dataclasses import replace
from pathlib import Path
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('auth_notion_s4_r5',p/'test_auth_notion_s4_r5.py')
mod=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=mod
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(mod)
flags=['tool_available','link_present','link_eligible','account_authenticated','workspace_match','permission_known','resource_exists','permission_granted','writer_authorized','collision_free','connection_changed','session_changed']
SAFE={'OPERATIONAL_READ','ALLOW_MINIMAL_WRITE_TEST_ONLY','VERIFIED_WRITE','VERIFIED_NOOP_AFTER_UNCERTAIN_WRITE'}
counts={}
passed=0
for vals in itertools.product([False,True],repeat=12):
  kw=dict(zip(flags,vals))
  for write,dest,kind,readback in itertools.product([False,True],['mestre','party'],['mestre_only','party_safe'],[False,True]):
    s=replace(mod.seed,**kw,write=write,destination=dest,content_kind=kind,write_sent=write,write_outcome=('success' if write else 'not_sent'),readback_confirmed=readback,content_class_verified=True)
    result=mod.decision(s)
    guards=all(kw[k] for k in flags[:8]) and not kw['connection_changed'] and not kw['session_changed']
    if not guards or (dest=='party' and kind=='mestre_only') or (write and (not kw['writer_authorized'] or not kw['collision_free'])):
      assert result not in SAFE, (kw,write,dest,kind,readback,result)
    if guards and not(write) and not(dest=='party' and kind=='mestre_only'):
      assert result=='OPERATIONAL_READ',(kw,dest,kind,result)
    if guards and write and kw['writer_authorized'] and kw['collision_free'] and not (dest=='party' and kind=='mestre_only'):
      assert result==('VERIFIED_WRITE' if readback else 'REOPEN_CONFIRM_WRITE'), (kw,result)
    passed+=1
    counts[result]=counts.get(result,0)+1
res={'type':'EXHAUSTIVE_STATE_MATRIX_MODEL_NOT_LIVE_NOTION','all_boolean_states':2**12,'write_destination_content_readback_modes':16,'assertions_passed':passed,'unique_decisions_observed':len(counts),'outcomes':counts,'normative_status':'S4 PROPOSTA - HOLD'}
(p/'AUTH_NOTION_01_S4_R5_PROPERTIES_20261022.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in res.items() if k!='outcomes'},ensure_ascii=False))
