# PSV — OP-DMG-CORPUS-EMP-01 | AUTO10-REPLICAS-20261016

**CLASSIFICAÇÃO:** MESTRE-ONLY, nunca transmitir à Party. **OP:** CM-000001 / OP-DMG-CORPUS-EMP-01. **AS-OF:** 16/10/2026. **ANTES:** POST-C11-AUTO10-R12_R21 (local, arquivo verificado quando montado). **DEPOIS:** AUTO10-REPLICAS-20261016 (local). **Governo:** DIRETRIZ `DIR-MESTRE-LABS-REPLICAS-20261016-001` / INBOX-98. **Autoridade principal:** Mestre, DMG-RANK-01 v1.1 intacta. **NAC-PASS produtivo:** HOLD.

## 1. Fronteira/autoria/risco

As réplicas foram criadas **somente como JSON/arquivos TEST locais isolados**: 6 cópias, fontes Galidemus e Iskiel; 0 páginas TEST Notion criadas, 0 writes Notion, 0 writes Party/O Primeiro, 0 execuções VLAB nativas, 0 writers/leases/epochs assumidos. A permissão Mestre de réplicas não resolve a identidade de instância/escritor Notion, nem proteção de relações externas em cópia Notion. Por isso a fronteira de laboratório Notion permanece **PENDENTE DE PREFLIGHT**; os oráculos locais continuam autorizados. Não afirmar 'laboratório Notion preenchido'.

A Inbox única foi lida em modo view, incluindo INBOX-98, 94, 92 e as mensagens antigas. **Modo SQL/rows `query_data_sources` bloqueado por cota nesta sessão**; view funcionou. Nenhum ACK assinado foi feito. Orientação de REG-ROUTE-03 / INBOX-81 sobre não contaminar conteúdo preservada. As ordens R13-R23 são histórico, não tarefas para refazer de olhos fechados.

## 2. Recuperação de fontes e integridade

- ZIP original R11 materializado da Library: `DMG-F1-R11-B02-CERTIFICACAO-E-INTEGRACAO-VLAB-R03-v01.zip`; **SHA256 `5467c6decb19ce3fcbd3eaf2190c4cb3f22e42e056aaf76b9ef615786db2cdb8`**, ZIP CRC PASS, **10/10 SHA interno PASS**. Fonte **RECUPERADA**.
- R11 contém a matriz integral de 18 gates B01-B18, auditada em `results/B01_B18_RECOVERED_R11.json`. **18/18 inspecionados**, não 18 certificações. **Histórico R11:** 1 PASS B02 (somente documental), 9 PARTIAL, 6 BLOCKED, 2 NOT-TESTED. Fontes R23 mais recentes informam o mesmo estado, mas seu arquivo bruto R23 não foi materializado com sucesso nesta sessão: **RELATADO R23**.
- `R12_R21_CHECKPOINT_SHA256.json`: manifest com **12 entradas**, dentre elas **6 montadas** e **6 hashes compatíveis** no runtime; ausências são *não montadas*, não 'deletadas'.
- I0003 nove CSV históricos: **0/9 arquivos originais autenticados nesta sessão**. Relatos parciais de 198 IDs e derivados não provam 9/9. Não reiniciar scans genéricos de 47 CSV/114 ZIP sem novo localizador.
- F0=4/8 documentais, Lote003=0/71 autenticados individualmente, duas batalhas STRICT=0/2, DMG B inteiros=1/18 reportados/documental R11; VLAB=0/17 terminal e 0/1875 canônico no último Notion físico R51. Sem incremento imaginário.

## 3. Dez etapas e aceites reais

Etapas 1–10 foram **materialmente tentadas**, com resultado detalhado em `results/TEN_STEP_GATE_MATRIX.json`. Recovery/CSV/cross-rank e ponte VLAB permaneceram parciais; réplicas/experimentos/QA/relatório alcançaram PASS local. Não apresentar 10/10 PASS terminal.

## 4. Experimento A — Galidemus Bronze1, base vs variantes TEST

Fonte literal física `<https://app.notion.com/p/eddc2b324ede829f8a75011e8acbf429>`: Patada **1d4+DES13 cortante**, Vida32, CA21; a fonte **não traz Luta/to-hit/PA/ação**. RD comparativa deriva de Criação de Besta vigente: Bronze normal 5, Prata normal 15, Ouro normal 25. Alvo Cabra Bronze1, Vida38. **Todos os resultados abaixo pressupõem que cada ataque acerte**; não modelam chance de acerto real nem combate nativo.

| Réplica | Dano literal TEST | Esperança líquida RD5 por acerto | E golpes para 38 Vida com acerto garantido | P(dano positivo) RD15 | E líquido RD15 |
|---|---:|---:|---:|---:|---:|
| BASE / fonte | 1d4+13 | 10,5 | 4,01953125 | 1/2 | 0,75 |
| +2 DES | 1d4+15 | 12,5 | 3,5 | 1 | 2,5 |
| D4→D6 | 1d6+13 | 11,5 | 3,84182099 | 2/3 | 1,66666667 |
| +1D4 | 2d4+13 | 13 | 3,29589844 | 15/16 | 3 |

**Resultado científico:** contra RD15, mudar somente DES em +2 altera P(dano líquido positivo) de 50% para 100%; adicionar um d4 eleva para 93,75%. Em RD25 todas as quatro variantes produzem 0 dano (mesmo máximo TEST menor que25); é uma barreira de mitigação, não estatística de vitória. Réplicas **não são 4 novas criaturas**.

## 5. Experimento B — Extensão Corporal do arco de Iskiel

Fonte física `<https://app.notion.com/p/3f6c2b324ede81a78a59d3d81fd5e966>`: ON5, ataque equipado 4d6+101, dano 9d8+47 Vento/perfurante, Extensão Corporal **+5d13 em um disparo** por **65 PA e Ação de Movimento**, PA livre484. Fontes-alvo `<https://app.notion.com/p/3f6c2b324ede81ce9c61db8127bf0e31>` Feryn CA123 e `<https://app.notion.com/p/3f6c2b324ede81f49ea9efbe1a811091>` Varok CA83.

Sob o kernel abstrato *EXPERIMENTAL* reaproveitado de R12 (crítico positivo P1/108, negativo P1/108 **exclusivamente LAB R42** e neutral106/108), sem Reações, movimento, linha de visão nem resistência específica Vento: P(acerto) Iskiel→Feryn é 913/69984 ≈ 1,304584%; Iskiel→Varok é 107/108 ≈ 99,074074%.

A **parcela extra** +5d13 (esperança 35), quando o crítico NÃO maximiza o rider, produz E adicional por tentativa **0.456604367** contra Feryn versus **34.675925926** contra Varok, uma razão **75.94×**. Na hipótese de adicionar também **+65** ao rider em crítico, valores crescem para ~1,058456 e ~35,277778 respectivamente. Não escolher esse ramo como regra vigente sem autoridade do crítico específico.

PA: 484//65=**7** ativações máximas, gasto455, saldo29 (sem custos adicionais, sem recuperação); custos de vínculos já comprometidos **não cobrados novamente**. Os números são marginais em cópias TEST, **não teste de arena, não previsão de vitória** e não afirmam que RD física de Feryn/Varok mitigue toda a parcela Vento.

## 6. B01–B18 e VLAB

A matriz integral R11 está salva imutavelmente como derivação leitura, com status histórico. B04/B09 dependem do ledger temporal Liu. B11 e B12 dependem das cinco decisões DEC-B11-A/B/C e DEC-B12-A/B no dossiê R23; nenhuma alternativa é imposta como cânone. B15 requer evento realmente documentado de fraqueza elemental física. O VLAB recebeu **ZERO** execuções ou writes desta sessão; arquivo `results/VLAB_HANDOFF_READONLY.json` está apenas **PREPARADO**, não entregue, aceito ou executado. Decisões R50 (Contra-atacar só miss real) e R51 (não encadear Counter) vigentes em Notion, regressões R52+ não comprovadas na OP no último fetch.

## 7. QA independente, preservação e errata

- 64/64 verificações independentes (`INDEPENDENT_QA.py`), incluindo **12 mutações negativas** deliberadamente recusadas pelo gate de réplicas local. Os 12 casos NÃO são defeitos encontrados no VLAB.
- Cópias TEST 6/6 com source-id, variação, sem links externos ativos. Nenhum campo original modificado por este script.
- **Errata aditiva:** texto histórico C11 usou mínimo '4d6+94→102'; mínimo real = **98**, comprovado `4×1+94`; arquivo `ERRATA_C11_COUNTER_MIN_98.md`, sem alterar histórico.
- No bloco final, manifesto SHA e pacote ZIP permitem recuperação byte-a-byte.

## 8. PSV / Sucessão / ponto exato de retomada

**AS-OF:** 2026-10-16. **OPERATION:** CM-000001/OP-DMG-CORPUS-EMP-01. **BASELINE:** DMG-RANK v1.1. **LAST-VERIFIED-UNIT:** 6 TEST locales + `results/RESULTS.json` + `INDEPENDENT_QA.json` + R11 original SHA/CRC+manifest 10/10. **FIRST-PENDING:** localizar autoridade e evidência de tempo/salvaguardas de B11/B12; fonte original I0003 por ID ou path novo; autenticar caso VLAB de extensão Iskiel se a engenharia admitir. **NO-REPEAT:** R11 B02, R12–R21, R47–R51, 64 QA atuais. **CONFLICTS:** RD mista Vento/perfurante, maximização do rider em crítico, Luta ausente da Galidemus, duração veneno B12. **UNKNOWN-EFFECT:** zero chamadas com efeito de escrita; desconhecidos normativos não preenchidos. **WRITER STATE:** não assumido e NOTION-WRITE=HOLD. **NAC-PASS:** PASS de matemática local/arquivos, HOLD terminal e canônico.

**NEXT-5 para sucessor**: (1) reabrir fontes e arquivos/hashes deste pacote; (2) efetuar sweep da Inbox e reconciliação da instância/writer, registrar ACK próprio se legitimado; (3) decidir o mínimo sobre B11/B12 somente por fonte Mestre existente ou ordem nova, sem perguntar novamente o que já está decidido; (4) descobrir por localizador preciso I0003 9 CSV originais ou aceitar blocked sem scans redundantes; (5) preparar ensaio VLAB com snapshot Iskiel, source-gate e seed próprio, sem a DMG assumir o motor. **TARGET REMAINDER:** F0 4/8, B 1/18, STRICT 0/2, I0003 0/9, Lote003 0/71, VLAB 0/17; universos diferentes.

**Registro permanente:** os artefatos locais serão copiados para a Biblioteca pessoal existente da OP se upload com readback for bem-sucedido; não pressupor sincronização com OP Notion.
