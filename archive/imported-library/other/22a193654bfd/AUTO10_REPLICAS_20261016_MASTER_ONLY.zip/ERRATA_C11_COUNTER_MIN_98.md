# ERRATA ADITIVA — DMG C11 / SCORE MÍNIMO DO CONTRA-ATAQUE

**Registro:** 16/10/2026, autoria DMG laboratório. **Alvo histórico:** PSV_DMG_C07_C11.md. **Não sobrescrever histórico.**

O texto anterior escreveu `4d6+94 → 102` como valor mínimo. O correto é `4d6+94`: **mínimo 98** (4×1+94), máximo 118 (4×6+94). O código histórico já continha `4+92+2=98`; a falha era textual, e não altera o confronto com CA20 da Cabra. Corrigir em relatórios futuros como errata rastreada, sem atribuir rerun VLAB ou mudança canônica.
