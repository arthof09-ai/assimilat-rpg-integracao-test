#!/usr/bin/env python3
"""Independent QA: no import of DMG model; brute force separate implementation."""
from pathlib import Path
import hashlib,json,itertools,zipfile
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
A=json.loads((ROOT/'results'/'RESULTS.json').read_text())
N=0;fails=[]
def ok(cond,label):
    global N
    N+=1
    if not cond:fails.append(label)

def samples(dice,faces,bonus,rd):
    for t in itertools.product(range(1,faces+1),repeat=dice):yield max(0,sum(t)+bonus-rd)

def brute_ttk(dice,faces,bonus,rd,hp):
    one=tuple(samples(dice,faces,bonus,rd)); mean=F(sum(one),len(one))
    ppos=F(sum(v>0 for v in one),len(one))
    tails=[]
    for n in range(1,6):
        # concatenate sums of n iid hits but only enumerate n <= 4 when feasible
        if len(one)**n > 131072:break
        P=F(sum(sum(seq)<hp for seq in itertools.product(one,repeat=n)),len(one)**n)
        tails.append(P)
        if P==0:break
    if not tails or tails[-1]!=0:
        # exact DP using rational but independent implementation by polynomial coefficients
        dist={0:1}
        tails=[]
        for n in range(1,10):
            nxt={}
            for accum,weight in dist.items():
                for v in one:
                    k=min(hp,accum+v)
                    nxt[k]=nxt.get(k,0)+weight
            dist=nxt
            tail=F(sum(weight for s,weight in dist.items() if s<hp),len(one)**n)
            tails.append(tail)
            if tail==0:break
    expectation=1+sum(tails,F(0))
    return mean,ppos,expectation

for name,n,side,add in [('BASE',1,4,13),('ATTR_PLUS2',1,4,15),('DIE_SWAP_D4_TO_D6',1,6,13),('PLUS_ONE_D4',2,4,13)]:
    for rd in [5,15,25]:
        val=A['galidemus']['variants'][name]['targets'][str(rd)]
        one=tuple(samples(n,side,add,rd))
        mean=F(sum(one),len(one));pos=F(sum(v>0 for v in one),len(one))
        ok(mean==F(val['expected_post_RD_per_hit']['fraction']),f'{name}/RD{rd}/mean')
        ok(pos==F(val['prob_positive_post_RD_conditional_hit']['fraction']),f'{name}/RD{rd}/positive')
    one=tuple(samples(n,side,add,5))
    dist={0:1};tails=[]
    for nstep in range(1,10):
        nxt={}
        for accum,w in dist.items():
            for amt in one:
                s=min(38,accum+amt);nxt[s]=nxt.get(s,0)+w
        dist=nxt;tail=F(sum(w for s,w in dist.items() if s<38),len(one)**nstep);tails.append(tail)
        if tail==0:break
    ok(tails[-1]==0,f'{name}/TTK converged')
    exp=1+sum(tails,F(0))
    ok(exp==F(A['galidemus']['variants'][name]['targets']['5']['ttk_hp38_assume_every_attack_hits']['expected_hits_to_KO']['fraction']),f'{name}/TTK')

# Independent 4d6 enumeration and ext expectation
pplus=F(1,108);pneutral=F(106,108)
for name,CA in [('Feryn',123),('Varok',83)]:
    scores=[sum(q)+101 for q in itertools.product(range(1,7),repeat=4)]
    ordinary=F(sum(a>CA for a in scores),len(scores))
    pnormal=ordinary*pneutral;ptotal=pnormal+pplus
    no_rider=ptotal*35
    yes_rider=pnormal*35+pplus*(35+5*13)
    row=A['iskiel']['targets'][name]
    ok(ordinary==F(row['p_common_success_given_neutral']['fraction']),name+' ordinary')
    ok(ptotal==F(row['p_hit_lab']['fraction']),name+' total')
    ok(no_rider==F(row['expected_incremental_per_activation_no_crit_rider_max']['fraction']),name+' expected extra noncrit')
    ok(yes_rider==F(row['expected_incremental_per_activation_if_rider_crit_max']['fraction']),name+' crit branch')
    ok(row['max_activations_at_PA_484']==7 and 484-7*65==29,name+' PA ledger')

# Mutation/adversarial safety tests on pure TEST replica boundary (not VLAB engine).
mutations=[
 ('negative cost', {'cost':-65}),('cost zero', {'cost':0}),('target Party', {'destination':'PARTY'}),
 ('target original', {'destination':'ORIGINAL'}),('external alias', {'external_links':['notion-original']}),
 ('missing source', {'source_id':None}),('not experimental',{'mode':'CANON'}),
 ('claim writer',{'writer':'CM-000006'}),('crit magic',{'magic_crit':True}),('invent accuracy',{'to_hit':6}),
 ('reset official',{'official_write':True}),('false independence',{'independent_subjects':4})]
def admission(payload):
    return (payload.get('cost',65)>0 and payload.get('destination','LOCAL_TEST')=='LOCAL_TEST' and
            payload.get('external_links',[])==[] and bool(payload.get('source_id','source')) and
            payload.get('mode','TEST')=='TEST' and payload.get('writer') is None and
            not payload.get('magic_crit',False) and payload.get('to_hit') is None and
            not payload.get('official_write',False) and payload.get('independent_subjects',1)==1)
for name,patch in mutations:
    ok(not admission({'mode':'TEST','source_id':'documented','external_links':[],**patch}),'reject mutation: '+name)
# old report C11 arithmetical typo documented no rewrite
ok(4+92+2==98,'erratum prior C11 4d6+94 min98 not102')
# physical R11 archive original preserved
archive=ROOT/'evidence_readonly'/'DMG-F1-R11-B02-CERTIFICACAO-E-INTEGRACAO-VLAB-R03-v01.zip'
ok(hashlib.sha256(archive.read_bytes()).hexdigest()=='5467c6decb19ce3fcbd3eaf2190c4cb3f22e42e056aaf76b9ef615786db2cdb8','original SHA')
with zipfile.ZipFile(archive) as z:ok(z.testzip() is None,'original CRC')
# 100% local copy isolation from Notion by filename vs canonical ids
replicas=list((ROOT/'TEST_REPLICAS').glob('*.json'))
ok(len(replicas)==6,'expected six local TEST copies')
for path in replicas:
    q=json.loads(path.read_text());ok(q.get('source_id') not in [None,''] and q.get('external_links')==[],'local replica no external live ptr '+path.name)

report={'QA_checks':N,'QA_failed':fails,'result':'PASS' if not fails else 'FAIL','independent_method':'itertools full enumeration and direct integer recurrence; no import of scientific model','scope':'math and local TEST copies; no native VLAB, canon or Notion writes','adversarial_mutation_cases':len(mutations),'critical_model':'LAB abstraction only','original_r11_zip_sha256':'5467c6decb19ce3fcbd3eaf2190c4cb3f22e42e056aaf76b9ef615786db2cdb8','notion_SQL_read_limit':'query_data_sources SQL/rows allowance reached; view allowed'}
(ROOT/'results'/'INDEPENDENT_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False));assert not fails
