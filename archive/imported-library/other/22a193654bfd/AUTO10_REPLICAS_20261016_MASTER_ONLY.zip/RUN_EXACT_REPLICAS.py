#!/usr/bin/env python3
"""DMG scientific only. All test replicas are local, isolated JSON. No Notion writes or VLAB calls.
Pure exact-probability engine; no game engine imports, no campaign event. Zero automatic policy promotions.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import hashlib,itertools,json,zipfile
ROOT=Path(__file__).resolve().parent
PR=json.loads((ROOT/'PREREG_SCIENCE.json').read_text())
TESTS=0

def insist(x,msg):
    global TESTS
    TESTS+=1
    if not x: raise AssertionError(msg)

def fld(x): return {'fraction':str(x),'decimal':round(float(x),12)}
def hist(n,faces):
    counts=Counter({0:1})
    for _ in range(n):
        r=Counter()
        for v,m in counts.items():
            for d in range(1,faces+1):r[v+d]+=m
        counts=r
    assert sum(counts.values())==faces**n
    return {d:F(v,faces**n) for d,v in sorted(counts.items())}

def target(dist,bonus,rd):
    damage=Counter()
    for v,p in dist.items():damage[max(0,v+bonus-rd)]+=p
    mean=sum((v*p for v,p in damage.items()),F(0))
    pinj=sum((p for v,p in damage.items() if v>0),F(0))
    return damage,mean,pinj

def tail_fight(damage,hp):
    """Conditional successive independent hits, HP finite. TTK n tail & exact expected hits."""
    dist=Counter({0:F(1)})
    out=[]
    for turn in range(1,65):
        nxt=Counter()
        for cum,pp in dist.items():
            for amt,p in damage.items():nxt[min(hp,cum+amt)]+=pp*p
        dist=nxt
        tail=sum((v for k,v in dist.items() if k<hp),F(0))
        out.append({'n':turn,'prob_not_KO':fld(tail),'prob_KO':fld(F(1)-tail)})
        if tail==0:break
    if out[-1]['prob_not_KO']['fraction']!='0':return {'state':'NOT_FINITE_OR_EXCEEDS64','horizon':out[:8]}
    # E[N] = sum_{n>=0} P(TTK > n), with P(TTK >0)=1
    E=F(1)+sum((F(a['prob_not_KO']['fraction']) for a in out),F(0))
    return {'state':'FINITE_CONDITIONAL_ALWAYS_HIT','expected_hits_to_KO':fld(E),'horizon':out[:min(len(out),8)]}

source={'source_id':'eddc2b324ede829f8a75011e8acbf429','source_edited':'2026-10-01T18:00:52.905Z','title':'Galidemus Bronze1 Patada','tag':'cortante','frozen_literal':'1d4+DES13','mode':'SOURCE_DOCUMENTARY_ONLY','attack_ability_source':None,'accuracy':None,'score_possible':None}
variants={'BASE':(1,4,13),'ATTR_PLUS2':(1,4,15),'DIE_SWAP_D4_TO_D6':(1,6,13),'PLUS_ONE_D4':(2,4,13)}
results={}
for name,(n,faces,bonus) in variants.items():
    copy={**source,'replica_id':'TEST_DMG_GAL_'+name,'modified_formula':f'{n}d{faces}+{bonus}','source_kind':'TEST_LOCAL_REPLICA','source_canonicity':'NOT_CANON','mutation':name,'external_links':[],'write_to_original':False}
    p=ROOT/'TEST_REPLICAS'/f'{copy["replica_id"]}.json';p.write_text(json.dumps(copy,ensure_ascii=False,indent=2)+'\n')
    d=hist(n,faces)
    outs={}
    for rd in (5,15,25):
        dam,E,P=target(d,bonus,rd)
        outs[str(rd)]={'support':[min(dam),max(dam)],'expected_post_RD_per_hit':fld(E),'prob_positive_post_RD_conditional_hit':fld(P),'raw_mean_intrinsic_plus_attribute':fld(F(n*(faces+1),2)+bonus),'target_kind':'NORMAL_BRONZE1_Goat' if rd==5 else 'RD_STRATUM_COMPARATIVE_ONLY'}
        if rd==5:outs[str(rd)]['ttk_hp38_assume_every_attack_hits']=tail_fight(dam,38)
    results[name]={'replica_id':copy['replica_id'],'formula':copy['modified_formula'],'targets':outs}
insist(results['BASE']['targets']['5']['expected_post_RD_per_hit']['fraction']=='21/2','BASE RD5 E=10.5')
insist(results['BASE']['targets']['15']['expected_post_RD_per_hit']['fraction']=='3/4','BASE RD15 E=.75')
insist(results['BASE']['targets']['25']['expected_post_RD_per_hit']['fraction']=='0','BASE RD25 E=0')
insist(results['BASE']['targets']['5']['ttk_hp38_assume_every_attack_hits']['expected_hits_to_KO']['fraction']=='1029/256','BASE expected #hits=4+5/256')
insist(results['ATTR_PLUS2']['targets']['5']['ttk_hp38_assume_every_attack_hits']['expected_hits_to_KO']['fraction']=='7/2','ATTR expected #hits=3.5')

# Iskiel: source-complete listed weapon and Extension, but only abstract attack kernel; mixed damage mitigation undefined.
isk={'source_id':'3f6c2b324ede81a78a59d3d81fd5e966','source_edited':'2026-10-16T10:33:53.226Z','title':'Iskiel bow + Extension','weapon_attack':'4d6+101','weapon_damage':'9d8+47 Vento/perfurante','extension':'5d13 per discharge, 65 PA Movement, max 7 uses from PA livre 484', 'copy_scope':'TEST_LOCAL_REPLICA'}
Pplus=F(1,108);Pminus=F(1,108);Pneutral=1-Pplus-Pminus
rows={}
for target_name,ca,rd in [('Feryn',123,22),('Varok',83,35)]:
    attacks=hist(4,6)
    prob_common=sum((p for v,p in attacks.items() if v+101>ca),F(0))
    pnormal=Pneutral*prob_common;phit=pnormal+Pplus
    # P(hit) and base crit are LAB MODEL (prior abstract approximation), NOT native VLAB RNG dependence.
    bow_mean=F(9*9,2)+47
    branch_add_only=phit*F(5*14,2)
    branch_crit_add_max=pnormal*F(5*14,2)+Pplus*(F(5*14,2)+5*13)
    row={'target':target_name,'CA':ca,'physical_RD':rd,'p_common_success_given_neutral':fld(prob_common),'p_auto_critical_lab':fld(Pplus),'p_hit_lab':fld(phit),'expected_incremental_per_activation_no_crit_rider_max':fld(branch_add_only),'expected_incremental_per_activation_if_rider_crit_max':fld(branch_crit_add_max),'extra_dice_mean':fld(F(5*14,2)),'PA_per_activation':65,'max_activations_at_PA_484':484//65,'PA_after7':484-7*65,'efficiency_extra_damage_per_spent_PA_no_rider_max':fld(branch_add_only/65),'hypotheses':['no explicit target reaction or attack range state', 'base mixed wind/piercing type resistances unknown','positive crit R41 model, negative crit R42 LAB only, independent approximation to existing R12, not native dice streams']}
    rows[target_name]=row
    rep={**isk,'replica_id':'TEST_DMG_ISK_EXT_'+target_name,'target_snapshot':target_name,'external_links':[],'mode':'LAB_BRANCH_EXPLORATORY_NOT_NATIVE'}
    (ROOT/'TEST_REPLICAS'/(rep['replica_id']+'.json')).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+'\n')
insist(rows['Feryn']['p_common_success_given_neutral']['fraction']=='5/1296','Iskiel target Feryn 5/1296')
insist(rows['Varok']['p_common_success_given_neutral']['fraction']=='1','Iskiel target Varok common all')
insist(rows['Varok']['max_activations_at_PA_484']==7,'PA 7 max')

# Read unchanged historical matrix R11 from physically authenticated archive.
file=ROOT/'evidence_readonly'/'DMG-F1-R11-B02-CERTIFICACAO-E-INTEGRACAO-VLAB-R03-v01.zip'
insist(hashlib.sha256(file.read_bytes()).hexdigest()=='5467c6decb19ce3fcbd3eaf2190c4cb3f22e42e056aaf76b9ef615786db2cdb8','R11 SHA')
with zipfile.ZipFile(file) as zin:
    insist(zin.testzip() is None,'R11 CRC')
    bm=json.loads(zin.read('DMG-F1-R11-MATRIZ-B01-B18-v01.json'))
    histB={x['id']:{'name':x['name_original'],'original_gate':x['original_gate'],'original_requirement':x['original_requirement'],'r11_state':x['r11_status'],'missing':x['specific_terminal_gap'],'has_required_event':x['engineer_event_required'],'source_urls':x.get('source_urls',[])} for x in bm['records']}
insist(len(histB)==18,'18 contracts')
status={name:r['r11_state'] for name,r in histB.items()}
insist(sum(s=='PASS' for s in status.values())==1,'R11 1 PASS');insist(status['B02']=='PASS','R11 B02 only')
result={'mode':'MATH_ONLY_NOT_VLAB','pre_registration':'PREREG_SCIENCE.json','galidemus':{'source':'literal 1d4+DES13; to-hit not source-valid','status':'DOCUMENTARY_MATH_ONLY','variants':results},'iskiel':{'source':'documented equipped bow+extension 65PA','status':'LAB_CONDITIONAL_BRANCH_ONLY','model_kernel':'prior R12-R21 abstraction Pplus=1/108 Pminus=1/108, neutral106/108; NOT VLAB RNG','targets':rows},'historical_B01_B18':{'verified_r11_zip_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'B01_B18':histB,'R11_state_counts':dict(Counter(status.values())),'later_R23':'Library preview reports unchanged 1 PASS, 9 PARTIAL, 6 BLOCKED, 2 NOT-TESTED. R23 raw file unavailable for independent hash','STRICT':'0/2 historical no native execution in this work'},'frozen_design':PR,'assertions_passed':TESTS}
(ROOT/'results'/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
(ROOT/'results'/'B01_B18_RECOVERED_R11.json').write_text(json.dumps(histB,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print('PASS',TESTS,'Galidemus baseline E hits',results['BASE']['targets']['5']['ttk_hp38_assume_every_attack_hits']['expected_hits_to_KO'],'Iskiel extra vs Feryn',rows['Feryn']['expected_incremental_per_activation_no_crit_rider_max'],'vs Varok',rows['Varok']['expected_incremental_per_activation_no_crit_rider_max'])
