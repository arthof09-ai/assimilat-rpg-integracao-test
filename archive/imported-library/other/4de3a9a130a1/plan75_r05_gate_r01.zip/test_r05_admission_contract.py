"""Deterministic regression/adversarial R05 admission contract. NO external I/O."""
from __future__ import annotations
from dataclasses import replace
from datetime import timedelta
from collections import Counter
import itertools, json
from r05_admission_contract import *


def main():
    failures=0
    scenarios=0
    checks=0
    outcomes=Counter()
    baseline=fake_green_fixture()
    def record(cond,msg):
        nonlocal checks
        checks+=1
        if not cond: raise AssertionError(msg)
    def case(p:Plan, should_allow:bool=False):
        nonlocal scenarios
        scenarios+=1
        g=gate(p,NOMINAL)
        record(g.approved==should_allow,(g,p))
        if not should_allow:
            record(len(g.reasons)>0,'Missing reason')
        outcomes['ADMIT' if g.approved else 'DENY']+=1
        return g
    case(baseline,True)
    case(Plan(AttestedEnvelope(),BoundNotion(),Ownership()))

    # Every single trust/capability and boundary dimension must fail closed.
    env_mutants=[
      {'provider_readback_authenticated':False}, {'origin':'PROMPT'},
      {'runtime_metadata_id':None}, {'mode':'UNKNOWN'}, {'mode':'VERIFIED_HEADLESS'},
      {'project_id':'SOME-OTHER-PROJECT'}, {'project_id':None},
      {'chat_destination':'GENERAL-CHAT'}, {'chat_destination':None},
      {'output_none':False}, {'notifications_off':False},
      {'notifications_off':None}, {'email_off':False}, {'email_off':None},
      {'expires_at':NOMINAL-timedelta(seconds=1)}, {'expires_at':None},
    ]
    notion_mutants=[
      {'master_link_id':None},{'master_link_id':PARTY_LINK},
      {'provider_readback_authenticated':False}, {'account_is_party':True},
      {'target_page_id':'WRONG-PAGE'}, {'target_page_id':None},
      {'ledger_page_id':'WRONG-DIARY'}, {'ledger_page_id':None},
      {'read_permission':False},{'write_permission':False},
    ]
    ownership_mutants=[
      {'owner':None},{'closure_owner':None},{'recovery_owner':None},
      {'task_id':None},{'worker_id':None},{'claim_token':None},
      {'claim_expires_at':NOMINAL-timedelta(seconds=1)},
      {'claim_expires_at':None}, {'gateway_proven':False},
      {'recorded_preflight':False},{'run_receipts_contract_proven':False},
      {'max_firings':None},{'max_firings':0},{'max_firings':6},
      {'max_firings':2},{'schedule_count':None},{'schedule_count':0},
      {'no_retry':False},{'max_material_writes_per_wake':2},
      {'max_material_writes_per_wake':0}
    ]
    for m in env_mutants: case(replace(baseline,envelope=replace(baseline.envelope,**m)))
    for m in notion_mutants: case(replace(baseline,notion=replace(baseline.notion,**m)))
    for m in ownership_mutants:case(replace(baseline,ownership=replace(baseline.ownership,**m)))
    for k,v in [
       ('safety_mode','OTHER'),('party_write',True),('canon_write',True),
       ('stage','EXECUTING'),('project_id','WRONG'),('target_page_id','WRONG'),
       ('ledger_page_id','WRONG'),('master_link_id',PARTY_LINK),
       ('marker','EXPECTED: '+MARKER),('marker','SCI-P75-R05-S1-W99 | COMMENT=COMMITTED-UNVERIFIED'),
       ('deadline',NOMINAL+timedelta(minutes=16)),('deadline',NOMINAL+timedelta(minutes=14))]:
        case(replace(baseline,**{k:v}))
    # Verified headless is the theoretical permitted alternative; no chat allowed.
    headless=replace(baseline,envelope=replace(baseline.envelope,mode='VERIFIED_HEADLESS',
         project_id=None,chat_destination=None,headless_no_chat=True))
    case(headless,True)
    for m in [{'headless_no_chat':False},{'chat_destination':PROJECT},{'output_none':False}]:
        case(replace(headless,envelope=replace(headless.envelope,**m)))

    # Exhaustive 12-dimension red-gate combinations for 2^12=4096 evidence states.
    for bits in itertools.product((False,True),repeat=12):
        e=baseline.envelope
        n=baseline.notion
        o=baseline.ownership
        e=replace(e,provider_readback_authenticated=bits[0],
                notifications_off=bits[1],email_off=bits[2],
                origin='PROVIDER' if bits[3] else 'PROMPT',
                chat_destination=PROJECT if bits[4] else 'GENERAL-CHAT')
        n=replace(n,provider_readback_authenticated=bits[5],
                master_link_id=MASTER_LINK if bits[6] else PARTY_LINK,
                account_is_party=not bits[7],write_permission=bits[8])
        o=replace(o,gateway_proven=bits[9],recorded_preflight=bits[10],
                  run_receipts_contract_proven=bits[11])
        p=replace(baseline,envelope=e,notion=n,ownership=o)
        case(p,all(bits))

    # Firing scenarios sample exactly pre/on/deadline/post + two modes, one effect
    # exists/absent/duplicate, provider ACK/denied/unknown, with/no CHECKIN.
    for second, prior, provider, checkin, admission_valid in itertools.product(
      (-301,-1,0,1,899,900,901,3600),(0,1,2),
      ('ACK','DENIED','COMMIT-THEN-UNKNOWN','TIMEOUT-NO-COMMIT'),
      (False,True),(False,True)):
        scenarios+=1
        p=baseline if admission_valid else replace(baseline,envelope=replace(baseline.envelope,mode='UNKNOWN'))
        g=MockGateway()
        start=NOMINAL+timedelta(seconds=second)
        effects=[Event(MARKER,'COMMENT',NOMINAL,TARGET,'X','R',MASTER_LINK,True,True)
                 for _ in range(prior)]
        rr=execute_model(p,start,g,provider,checkin,effects)
        outcomes[rr.status]+=1
        record(rr.effect_attempts<=1,'Write budget exceeded')
        if not admission_valid or not checkin or second<0 or second>900 or prior>0:
            record(rr.effect_attempts==0,'Unexpected write')
        if rr.effect_attempts:
            record(admission_valid and checkin and 0<=second<=900 and prior==0,
                   'Write happened despite admission rejection')
            if provider=='COMMIT-THEN-UNKNOWN':
                record(rr.status=='UNKNOWN-EFFECT-HOLD','Unknown post commit not held')
                record(len(g.committed)==1,'Must model unknown persisted')
            if provider=='TIMEOUT-NO-COMMIT':
                record(rr.status=='UNKNOWN-EFFECT-HOLD','Unknown uncommitted must remain unknown')
        record(rr.model_only,'Simulation must stay model only')

    # Two writers using one shared atomic reservation: at most one commit.
    for outcome_a,outcome_b in itertools.product(('ACK','DENIED','COMMIT-THEN-UNKNOWN'),repeat=2):
        scenarios+=1
        g=MockGateway()
        a=execute_model(baseline,NOMINAL,g,outcome_a)
        b=execute_model(baseline,NOMINAL,g,outcome_b)
        record(a.effect_attempts+b.effect_attempts<=1,'Double write despite exclusive gateway')
        record(len(g.committed)<=1,'Physical duplicate')
        record(b.status in ('FENCING-DENY','NOOP-EXISTS'),'Concurrent second actor must fail closed')

    # Audit never attributes FRPE to page presence alone.
    proto=Event(MARKER,'COMMENT',NOMINAL,TARGET,'API-1','RUN-1',MASTER_LINK,True,True)
    audit_cases=[
      ([], 'ABSENT'),([proto],'PHYSICAL-FIRST-RUN-CANDIDATE-NOT-NAC-PASS'),
      ([proto,proto],'DUPLICATE-FAIL'),
      ([replace(proto,timestamp=None)],'TIMING-UNKNOWN'),
      ([replace(proto,timestamp=NOMINAL-timedelta(seconds=1))],'EARLY-EVENT-NO-FRPE'),
      ([replace(proto,timestamp=NOMINAL+timedelta(seconds=901))],'LATE-EVENT-NO-FRPE'),
      ([replace(proto,independent_readback=False)],'UNVERIFIED-INDEPENDENCE'),
      ([replace(proto,provider_operation_id=None)],'RUN-OPERATION-PROVENANCE-MISSING'),
      ([replace(proto,task_run_id=None)],'RUN-OPERATION-PROVENANCE-MISSING'),
      ([replace(proto,first_run=None)],'FIRST-RUN-PROVENANCE-MISSING'),
      ([replace(proto,connector_link_id=PARTY_LINK)],'WRONG-CONNECTOR-FAIL'),
      ([replace(proto,target='OTHER')],'ABSENT')
    ]
    for events,expected in audit_cases:
        scenarios+=1
        actual=audit_model(baseline,events,NOMINAL+timedelta(minutes=16))
        record(actual==expected,(expected,actual))
    # Explicitly audit the real observed R04 comment without authenticated
    # linkage: it is physical/on-time but first-run STRICT remains unverified.
    historical=replace(proto,marker='SCI-P75-R04-S1-W02 | COMMENT=COMMITTED-UNVERIFIED',
                       task_run_id=None,provider_operation_id=None,first_run=None,
                       timestamp=datetime(2026,10,9,10,14,36,tzinfo=TZ))
    historical_plan=replace(baseline,marker=historical.marker,
                       nominal=datetime(2026,10,9,10,10,tzinfo=TZ),
                       deadline=datetime(2026,10,9,10,25,tzinfo=TZ))
    # This check is about *audit* causality only, not admission of historical worker.
    scenarios+=1
    record(audit_model(historical_plan,[historical],datetime(2026,10,13,tzinfo=TZ))==
           'RUN-OPERATION-PROVENANCE-MISSING','Historic first-run falsely certified')

    # Extended schedule property sweep, 24,001 offsets x two modes; no writes
    # outside the closed [0,900] seconds contract.
    for sec in range(-12000,12001):
        scenarios+=1
        now=NOMINAL+timedelta(seconds=sec)
        g=MockGateway()
        r=execute_model(baseline,now,g)
        record(r.effect_attempts==int(0<=sec<=900),'Clock boundary fail')
        if sec<0:record(r.status=='EARLY-NO-WRITE','Incorrect early classification')
        if 900<sec<3600:record(r.status=='LATE-NO-WRITE','Incorrect late classification')
        if sec>=3600:record(r.status=='ADMISSION-DENY','Expired attestation did not fail closed')
    real=real_platform_now_gate()
    scenarios+=1
    record(not real.approved,'Actual observed platform R07 must fail closed')
    record('PROJECT-HEADLESS-UNPROVEN' in real.reasons, 'Missing principal blocker')
    return {'case_count':scenarios,'assertions':checks,'failures':failures,
           'outcome_counts':dict(outcomes), 'known_external_capability':real.__dict__,
           'provenance_case':'R04 1/15 physical; strict run→API linkage unavailable',
           'capability':'No scheduler primitive implemented. No Notion writes.',
           'scope':'NAC-AUTO-CONT-01 v1.13 / R07 / SCI-P75-R05 PROPOSED-ONLY',
           'status':'MODEL-PASS / MATERIAL-ARM-HOLD / NAC-PASS-02=HOLD'}

if __name__=='__main__':
    print(json.dumps(main(),indent=2,ensure_ascii=False))
