# SCI-P75-R05-GATE-R01 — Contrato de admissão, recibos e fencing

**13 de outubro de 2026 — CM-000005 / WS0001 — somente Mestre-side, laboratório lógico.**

## Estado e fronteira

- R04 física concluída em 09/10/2026: um comentário observável e único S1-W02 dentro da janela, em **15 oportunidades planejadas**. Cobertura eventual **1/15 (6,67%)**. Não classificar como FRPE estrita com causalidade completa, pois falta o vínculo independente nativo `task_run_id → connector_operation_id → Notion effect`.
- IBX-89 da coordenação está como `NOVA`, sem ACK observado na última reabertura em 13/10/2026. R07 continua `HARD-PROJECT-BIND=UNPROVEN`; regras NAC-AUTO-CONT-01 v1.13 e NAC-CONT-03 aplicáveis. `R05-ARM=HOLD`.
- **Nenhuma parte deste pacote arma Task, lê ou grava Notion, cria chat, envia email/notificação, libera Party/O Primeiro ou altera cânone.**

## Artefatos

- `r05_admission_contract.py`: gate testável exigindo prova autenticamente reabrível do projeto/headless, flags OFF, vínculo específico da conexão Mestre e alvo/diário, claim/owner/contagem finita, recibos e orçamento `uma escrita material por wake`. `fake_green_fixture()` é **simulação de um provedor futuro ideal**, não afirma que a plataforma atual possui tais recursos.
- `test_r05_admission_contract.py`: testes negativos para proof omission, wrong-connector, Party, wrong target, expiry, no-fence, no checkin, erradas janelas e provenance.
- `r05_receipt_fsm.py`: máquina de estados simulada `CHECKIN → REOPEN → FENCE → uma mutação no gateway simulado → REPORT → REOPEN → auditor`. Declara `UNKNOWN` se o efeito ou relatório não puder ser reaberto.
- `test_r05_receipt_fsm.py`: faults em recibos e reinicialização por RUN-ID; não conta o recibo como efeito experimental.
- `test_r05_recovery_fuzz.py`: estresse reprodutível com seed fixa, crashes e replays, além de **testemunha negativa** demonstrando que dois gateways isolados continuam capazes de duplicar efeitos.
- Resultados JSON, testes P1 R01–R03 históricos e manifesto de integridade.

## Defeitos detectados e sua resolução limitada

**R05-DEF-001 — Replay quando CHECKIN falha:** versão inicial consultava só o Diário e permitia replay se o CHECKIN nunca se materializou. Correção no modelo: reservar `RUN-ID` em serviço **compartilhado, atômico e durável ANTES** do CHECKIN e nunca repetir escrita sobre efeito `UNKNOWN`. A função `claim_run_id()` é apenas um mock; a implementação efetiva depende do gateway compartilhado sob governança própria (não criar nova autoridade). Não está corrigido em produção.

**R05-DEF-002 — Gate expirado classificado incorretamente como atraso:** o ensaio inicial esperava LATE após expiração da prova sintética, enquanto a admissão recusava corretamente o RUN com `ADMISSION-DENY`. A correção foi do critério de teste, distinguindo `PROOF-STALE` de `LATE-NO-WRITE`. Não é defeito comprovado da plataforma.

**R05-DEF-003 — Dois gateways independentes podem duplicar efeito:** ensaio negativo intencional comprova que a simulação só é segura com um **repositório atômico único** ou mecanismo legítimo equivalente. Sem gateway externo/fencing real, não existe exatamente-uma-vez garantido.

## Resultados determinísticos

Os contadores vêm dos relatórios JSON executados, e podem ser reproduzidos com:

```bash
python test_r05_admission_contract.py
python test_r05_receipt_fsm.py
python test_r05_recovery_fuzz.py
```

Esses cenários são **MODEL-ONLY**; jamais adicioná-los aos denominadores N4=20, R03=2, R04=15 ou P7=100. Mesmo zero falhas em regressão lógica não é FRPE da plataforma nem PASS de NAC.

## Gate de retomada exato

1. Coordenador/IBX-89 apresenta primitive autenticável e reabrível para `project_id` vinculado ao Projeto Comestre OU headless-no-chat real; flags email/push OFF e bloqueio de saída externa.
2. A plataforma de execução vincula o `link_id` Mestre a `Notion create_comment/update_page` sem seleção implícita Party; prova negativa de ausência de modo alternativo inseguro.
3. Serviço de fencing/escritor exclusivo legítimo e durável, aceitando `RUN-ID/epoch/claim` e fornecendo recibos nativos com auditabilidade; não confiar em `read-before-write` sem exclusão atômica.
4. Auditor independente valida prova de destino, receita de RUN-CHECKIN/REPORT, segurança e primeiro efeito. Só então a operação R05 pode ser armada em coorte fresca mínima com denominador e autorização específicos. P7 exige pelo menos 84/100 e 52/60 baseline, sem violações críticas.

**NEXT:** IBX-89 → capacidade física nova/ACK → readback e revisão NAC → piloto R05. Na ausência, `ARM=HOLD`; pesquisa e teste manual continuam permitidos, sem prometer implementação externa.
