"""Adversarial exhaustive receipt-state fault injection, including replay."""
from dataclasses import replace
from datetime import timedelta
from collections import Counter
from itertools import product
import json
from r05_admission_contract import *
from r05_receipt_fsm import *


def main():
    p=fake_green_fixture()
    outcomes=Counter()
    checks=0; cases=0
    for sec,fail_checkin,fail_terminal,fail_reopen,fail_checkin_crash,after_effect_crash,write_mode,replay in product(
        (-1,0,15,899,900,901,3601),
        (False,True),(False,True),(False,True),(False,True),(False,True),
        ('ACK','DENIED','COMMIT-THEN-UNKNOWN','TIMEOUT-NO-COMMIT'),
        (False,True)):
        cases+=1
        t=NOMINAL+timedelta(seconds=sec)
        led=MockLedger();gateway=MockGateway()
        r=wake(p,led,gateway,t,'R05:S1:W01',fail_checkin=fail_checkin,
            fail_terminal=fail_terminal,fail_readback=fail_reopen,
            fail_after_checkin=fail_checkin_crash,crash_after_effect=after_effect_crash,
            write_mode=write_mode)
        outcomes[r.state]+=1
        checks+=1; assert r.experimental_writes<=1
        if fail_checkin or fail_reopen or fail_checkin_crash or sec<0 or sec>900:
            checks+=1; assert r.experimental_writes==0
        if r.experimental_writes>0:
            checks+=1;assert 0<=sec<=900 and not fail_checkin and not fail_reopen and not fail_checkin_crash
            checks+=1;assert r.ledger_writes>=1
        if r.state in TERMINAL:
            checks+=2
            assert 'R05:S1:W01' in led.data
            assert led.data['R05:S1:W01'].receipt_reopened
        if replay:
            # Reentry never creates a second physical attempt, even after crash.
            second=wake(p,led,gateway,t,'R05:S1:W01',write_mode='ACK')
            outcomes['REPLAY:'+second.state]+=1
            checks+=2
            assert second.experimental_writes==0
            assert second.state not in ('RUN-CLOSED-EFFECT','RUN-CLOSED-FAIL')
        checks+=1;assert len(gateway.committed)<=1
    # Diagnostic monotonicity: completed receipt cannot regress to STARTED
    cases+=1
    led=MockLedger();gatew=MockGateway()
    r=wake(p,led,gatew,NOMINAL,'RUN-1')
    assert r.state=='RUN-CLOSED-EFFECT'
    a=led.data['RUN-1']
    assert a.run_closed and a.receipt_reopened
    assert not led.report('RUN-1','RUN-UNKNOWN',NOMINAL)
    checks+=3
    # The historical R04 lone native comment cannot be certified by this new
    # ledger: no R05 RUN-CHECKIN or run_id operation trace existed then.
    cases+=1
    blank=closure(p,MockLedger(),MockGateway(),['R05:S1:W01','R05:S2:W01'],NOMINAL+timedelta(minutes=16))
    assert blank['planned']==2 and blank['receipts'].get('MISSING-RUN-RECEIPT')==2
    checks+=1
    return {'scenarios':cases,'assertions':checks,'failures':0,
            'outcomes':dict(outcomes),'witness':blank,
            'invariants':['never mutate after failed or unreadable check-in',
                          'one material write max per wake',
                          'replay run-id cannot produce second material write',
                          'missing report is UNKNOWN not success',
                          'independent closure has fixed denominator'],
            'status':'MODEL-ONLY / R05-ARM-HOLD / P7-NOT-CERTIFIED'}

if __name__=='__main__':
    print(json.dumps(main(),indent=2,ensure_ascii=False))
