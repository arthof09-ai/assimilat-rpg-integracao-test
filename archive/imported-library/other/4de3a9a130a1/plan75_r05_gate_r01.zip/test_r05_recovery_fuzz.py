"""Deterministic seed-based adversarial recovery suite, synthetic only."""
from __future__ import annotations
from dataclasses import replace
from datetime import timedelta
from collections import Counter
import random, json
from r05_admission_contract import *
from r05_receipt_fsm import *

SEED = 20261013
CASES = 25000

def main():
    rng=random.Random(SEED)
    base=fake_green_fixture()
    states=Counter()
    checks=0
    for i in range(CASES):
        t=NOMINAL+timedelta(seconds=rng.randint(-3600,7200))
        valid=rng.choice([True,True,True,False])
        config=base if valid else replace(base,envelope=replace(base.envelope,provider_readback_authenticated=False))
        mode=rng.choice(('ACK','DENIED','COMMIT-THEN-UNKNOWN','TIMEOUT-NO-COMMIT'))
        options=dict(fail_checkin=bool(rng.randrange(4)==0),fail_terminal=bool(rng.randrange(4)==0),
                     fail_readback=bool(rng.randrange(6)==0),fail_after_checkin=bool(rng.randrange(6)==0),
                     crash_after_effect=bool(rng.randrange(6)==0),write_mode=mode)
        gateway=MockGateway()
        ledger=MockLedger()
        run_id=f'R05-SIM-RUN-{i}'
        first=wake(config,ledger,gateway,t,run_id,**options)
        states[first.state]+=1
        checks+=2
        assert len(gateway.committed)<=1
        assert first.experimental_writes<=1
        # Simulate process restart: reconstructed worker with same shared
        # external-gateway state, possibly missing the original ledger.
        newledger=ledger if rng.randrange(2) else MockLedger()
        replay=wake(config,newledger,gateway,t,run_id,write_mode='ACK')
        states['REPLAY:'+replay.state]+=1
        checks+=3
        assert replay.experimental_writes==0
        assert len(gateway.committed)<=1
        assert gateway.write_attempts<=1
        # Alternate worker RUN-ID competing for the same target-marker. There
        # must not be a second write if the shared fenced gateway survived.
        other=wake(config,MockLedger(),gateway,t,run_id+'-OTHER',write_mode='ACK')
        checks+=2
        assert other.experimental_writes<=1
        assert gateway.write_attempts<=1
    # Required negative witness: independent uncoordinated gateway services
    # can each physically commit same marker despite looking locally healthy.
    left=MockGateway();right=MockGateway()
    a=wake(base,MockLedger(),left,NOMINAL,'RUN-LEFT')
    b=wake(base,MockLedger(),right,NOMINAL,'RUN-RIGHT')
    checks+=3
    assert a.experimental_writes==1 and b.experimental_writes==1
    assert len(left.committed)+len(right.committed)==2
    # Must NOT accidentally self-certify atomicity across disconnected stores.
    danger='TWO_UNCOORDINATED_WRITERS_CREATE_DUPLICATES'
    return {'scenarios':CASES+1,'assertions':checks,'failures':0,
            'seed':SEED,'random_mode':'deterministic with hard-coded seed',
            'states':dict(states),'negative_witness':danger,
            'remaining_requirement':'External shared gateway/fencing, same durable store across every worker, not available from this script',
            'note':'Synthetic: zero scheduler tasks or Notion mutations, not 25,000 physical effects.',
            'status':'MODEL-PASS; R05-ARM=HOLD; NAC-PASS=HOLD'}

if __name__=='__main__':
    print(json.dumps(main(),ensure_ascii=False,indent=2))
