"""R05 proposed receipt/closure finite-state machine; isolated simulation only.

RUN-CHECKIN and RUN-REPORT are separate telemetry, not experimental effects.
A failed receipt never licenses a compensating effect or blind retry.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
from collections import Counter
from r05_admission_contract import Plan,MockGateway,Event,gate,audit_model,MARKER,MASTER_LINK,TARGET,NOMINAL

TERMINAL=('RUN-CLOSED-EFFECT','RUN-CLOSED-NOOP','RUN-CLOSED-FAIL','RUN-UNKNOWN')

@dataclass
class RunReceipt:
    run_id:str
    current:str='UNSEEN'
    ledger_target:Optional[str]=None
    checkin_timestamp:Optional[datetime]=None
    report_timestamp:Optional[datetime]=None
    observed_effect:str='UNKNOWN'
    provenance:str='NOT-INDEPENDENT'
    write_attempts:int=0
    receipt_reopened:bool=False
    run_closed:bool=False
    history:list[str]=field(default_factory=list)

@dataclass
class MockLedger:
    """Atomic in-memory receipt map, NOT a Notion transaction."""
    data:dict[str,RunReceipt]=field(default_factory=dict)
    writes:int=0
    def checkin(self,run_id:str,at:datetime,target:str,fail:bool=False)->Optional[RunReceipt]:
        if fail: return None
        if run_id in self.data: return self.data[run_id]
        r=RunReceipt(run_id,'RUN-CHECKIN',target,at,history=['CHECKIN'])
        self.data[run_id]=r
        self.writes+=1
        return r
    def report(self,run_id:str,state:str,at:datetime,fail:bool=False)->bool:
        if fail or run_id not in self.data: return False
        if state not in TERMINAL: return False
        r=self.data[run_id]
        if r.report_timestamp is not None: return False
        r.current=state
        r.report_timestamp=at
        r.history.append(state)
        self.writes+=1
        return True
    def reopen(self,run_id:str,fail:bool=False)->Optional[RunReceipt]:
        if fail:return None
        r=self.data.get(run_id)
        if r:r.receipt_reopened=True
        return r

@dataclass(frozen=True)
class WaveResult:
    run_id:str
    state:str
    experimental_writes:int
    ledger_writes:int
    physically_present:bool
    model_only:bool=True


def wake(plan:Plan, ledger:MockLedger, gateway:MockGateway, at:datetime,
         run_id:str, *, fail_checkin=False, fail_terminal=False,
         fail_readback=False, fail_after_checkin=False,
         crash_after_effect=False, write_mode='ACK')->WaveResult:
    """One wake, no retry. Re-entry with same RUN-ID remains NOOP/UNKNOWN."""
    before_gateway=gateway.write_attempts
    before_ledger=ledger.writes
    def finish(status):
        return WaveResult(run_id,status,gateway.write_attempts-before_gateway,
                          ledger.writes-before_ledger,
                          (plan.target_page_id,plan.marker) in gateway.committed)
    if not gate(plan,at).approved: return finish('ADMISSION-DENY')
    if at<plan.nominal: return finish('EARLY-NO-WRITE')
    if at>plan.deadline: return finish('LATE-NO-WRITE')
    # CRITICAL: reserve RUN-ID in a shared atomic provider BEFORE check-in.
    # If check-in failed, there may be no ledger receipt to catch a replay.
    # Losing this fence caused a model-based duplicate-writing defect R05-DEF-001.
    if not gateway.claim_run_id(run_id):
        return finish('RUN-ID-FENCED')
    if run_id in ledger.data:
        return finish('RUN-ID-UNKNOWN-FENCE')
    checkin=ledger.checkin(run_id,at,plan.ledger_page_id,fail=fail_checkin)
    if checkin is None: return finish('RUN-CHECKIN-FAIL-CLOSED')
    # mandatory readback; if no durable check-in proof, no material mutation.
    read=ledger.reopen(run_id,fail=fail_readback)
    if read is None or read.ledger_target!=plan.ledger_page_id:
        return finish('CHECKIN-REOPEN-UNKNOWN-HOLD')
    if fail_after_checkin: return finish('CRASH-AFTER-CHECKIN-HOLD')
    if (plan.target_page_id,plan.marker) in gateway.committed:
        state='RUN-CLOSED-NOOP'
    elif not gateway.reserve(plan.target_page_id,plan.marker):
        state='RUN-UNKNOWN'
    else:
        event=Event(plan.marker,'COMMENT',at,plan.target_page_id,
                    'SYNTHETIC-OP',run_id,plan.master_link_id,False,True)
        result=gateway.commit(event,write_mode)
        if result=='COMMITTED-UNVERIFIED':state='RUN-CLOSED-EFFECT'
        elif result=='DENIED':state='RUN-CLOSED-FAIL'
        else:state='RUN-UNKNOWN'
    if crash_after_effect:return finish('CRASH-AFTER-EFFECT-UNKNOWN')
    if not ledger.report(run_id,state,at,fail=fail_terminal):
        return finish('RUN-REPORT-MISSING-HOLD')
    confirmed=ledger.reopen(run_id,fail=fail_readback)
    if confirmed is None or confirmed.current!=state:
        return finish('REPORT-REOPEN-UNKNOWN-HOLD')
    confirmed.run_closed=True
    return finish(state)


def closure(plan:Plan,ledger:MockLedger,gateway:MockGateway,
            expected_run_ids:list[str],observer_at:datetime):
    """Independent accounting, N planned run IDs including missed opportunities."""
    found=list(gateway.committed.values())
    status_counts=Counter()
    for run_id in expected_run_ids:
        receipt=ledger.data.get(run_id)
        if receipt is None: status_counts['MISSING-RUN-RECEIPT']+=1
        elif not receipt.run_closed:status_counts['OVERDUE-UNKNOWN']+=1
        else:status_counts[receipt.current]+=1
    # Candidate audit status intentionally remains below real NAC-PASS.
    audit=audit_model(plan,found,observer_at,readback_ok=True)
    return {'planned':len(expected_run_ids),'receipts':dict(status_counts),
            'physical_count':len([x for x in found if x.marker==plan.marker]),
            'audit':audit,'status':'MODEL-CLOSURE-ONLY'}
