"""PLAN75 candidate runtime driver, OFFLINE. Does not access Notion or the scheduler.

It models one physical effect per authorized wake and expressly refuses to
claim exactly-once guarantees from read-before-write if concurrent actors race.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable
from zoneinfo import ZoneInfo
from collections import Counter
import hashlib
import json
import re

TZ = ZoneInfo('America/Recife')

class ReadError(Exception): pass
class ConnectorDenied(Exception): pass
class UnknownEffect(Exception): pass

@dataclass(frozen=True)
class Spec:
    task: str
    marker: str
    target: str
    nominal: datetime
    method: str = 'COMMENT'
    allowed_window_seconds: int = 900
    project_binding_proved: bool = True
    notify_enabled: bool = False
    email_enabled: bool = False
    legitimate_writer: bool = True
    exclusive_writer_proved: bool = False  # external gateway/claim, NEVER self-certify

@dataclass(frozen=True)
class Effect:
    marker: str
    timestamp: datetime | None
    author: str

@dataclass
class MockConnector:
    target: str
    effects: list[Effect] = field(default_factory=list)
    read_outcome: str = 'OK'
    write_outcome: str = 'ACK'
    write_attempts: int = 0
    read_attempts: int = 0
    wrong_target_calls: int = 0

    def read(self, target: str) -> list[Effect]:
        self.read_attempts += 1
        if target != self.target:
            self.wrong_target_calls += 1
            raise ReadError('wrong target')
        if self.read_outcome == 'ERROR': raise ReadError('unavailable')
        if self.read_outcome == 'STALE': raise ReadError('freshness not provable')
        return self.effects.copy()

    def write_once(self, target: str, marker: str, at: datetime, author: str) -> None:
        self.write_attempts += 1
        if target != self.target:
            self.wrong_target_calls += 1
            raise ConnectorDenied('wrong target')
        if self.write_outcome == 'DENIED': raise ConnectorDenied('write refused')
        if self.write_outcome in ('ACK', 'COMMIT_THEN_UNKNOWN'):
            self.effects.append(Effect(marker, at, author))
        if self.write_outcome == 'COMMIT_THEN_UNKNOWN':
            raise UnknownEffect('provider did not return acknowledgement')
        if self.write_outcome == 'UNKNOWN_UNCOMMITTED':
            raise UnknownEffect('effect unknown')

MARKER_RE = re.compile(r'^SCI-P75-[A-Z0-9-]+-S[0-9]+-W[0-9]+ \| (?:COMMENT|WRITE)=COMMITTED-UNVERIFIED$')

def normalize(line: str) -> str:
    s = line.strip().strip('`').strip()
    s = re.sub(r'\\+\|', '|', s)
    s = re.sub(r'\s*\|\s*', ' | ', s)
    return s

def real_effect_count(effects: list[Effect], marker: str) -> int:
    return sum(normalize(x.marker) == normalize(marker) and
               bool(MARKER_RE.fullmatch(normalize(x.marker)))
               for x in effects)

def run(spec: Spec, connector: MockConnector, at: datetime) -> str:
    """One run. NO in-run retry, NO auto-PASS, NO second mutation."""
    if not spec.project_binding_proved or spec.notify_enabled or spec.email_enabled or not spec.legitimate_writer or not spec.exclusive_writer_proved:
        return 'ADMISSION-HOLD'
    if spec.method not in ('COMMENT', 'WRITE') or not MARKER_RE.fullmatch(normalize(spec.marker)):
        return 'BAD-SPEC-HOLD'
    if at.tzinfo is None or spec.nominal.tzinfo is None:
        return 'CLOCK-UNKNOWN-HOLD'
    delta = (at - spec.nominal).total_seconds()
    if delta < 0: return 'EARLY-NO-WRITE'
    if delta > spec.allowed_window_seconds: return 'LATE-NO-WRITE'
    try:
        snapshot = connector.read(spec.target)
    except ReadError:
        return 'READ-UNKNOWN-HOLD'
    n = real_effect_count(snapshot, spec.marker)
    if n > 1: return 'DUPLICATE-HOLD'
    if n == 1: return 'NOOP-EXISTS'
    try:
        connector.write_once(spec.target, spec.marker, at, spec.task)
    except ConnectorDenied:
        return 'CONNECTOR-DENIED'
    except UnknownEffect:
        return 'UNKNOWN-EFFECT-HOLD'
    return 'COMMITTED-UNVERIFIED'

def audit(spec: Spec, connector: MockConnector, now: datetime,
          scheduler_fired_first_run: bool, independent_provenance: bool) -> str:
    """Independent observer; never creates effects and never emits terminal NAC-PASS."""
    try:
        snapshot = connector.read(spec.target)
    except ReadError:
        return 'AUDIT-UNKNOWN'
    exact = [x for x in snapshot if normalize(x.marker) == normalize(spec.marker)]
    if len(exact) > 1: return 'DUPLICATE-FAIL'
    if not exact: return 'PHYSICAL-ABSENT'
    if exact[0].timestamp is None: return 'TIME-PENDING'
    dt = (exact[0].timestamp - spec.nominal).total_seconds()
    if dt < 0: return 'EARLY-EFFECT-NO-FRPE'
    if dt > spec.allowed_window_seconds: return 'LATE-EVENTUAL-NO-FRPE'
    if now < exact[0].timestamp: return 'BAD-OBSERVATION-HOLD'
    if not scheduler_fired_first_run or not independent_provenance:
        return 'FRPE-UNVERIFIED'
    return 'PHYSICAL-FIRST-WINDOW-EFFECT'  # still not NAC-PASS

def stress():
    fixed_time=datetime(2026,10,9,10,10,tzinfo=TZ)
    marker='SCI-P75-R05-S1-W01 | COMMENT=COMMITTED-UNVERIFIED'
    target='3f2c2b32-4ede-817c-b441-cdde97763d83'
    count=Counter()
    cases=checks=0
    # Exhaustive actual time offsets, connector outcomes, prior effects and admission gates.
    # Restrained to a single remote-write budget per wake by design.
    for seconds in range(-601, 1202, 3):
        for pre in (0,1,2):
            for outcome in ('ACK','DENIED','COMMIT_THEN_UNKNOWN','UNKNOWN_UNCOMMITTED'):
                for bind in (True,False):
                    for notify in (False,True):
                        for read in ('OK','ERROR','STALE'):
                            cases+=1
                            fixture=[Effect(marker, fixed_time, 'earlier') for _ in range(pre)]
                            c=MockConnector(target,effects=fixture,write_outcome=outcome,read_outcome=read)
                            s=Spec('S1',marker,target,fixed_time,project_binding_proved=bind,notify_enabled=notify,exclusive_writer_proved=True)
                            status=run(s,c,fixed_time+timedelta(seconds=seconds))
                            count[status]+=1
                            checks+=4
                            assert c.write_attempts<=1
                            assert c.wrong_target_calls==0
                            assert status not in ('VERIFIED','PASS','NAC-PASS')
                            if seconds<0: assert c.write_attempts==0
                            if seconds>900: assert c.write_attempts==0
                            if not bind or notify: assert c.write_attempts==0
                            if status == 'COMMITTED-UNVERIFIED':
                                checks+=3
                                assert outcome=='ACK' and pre==0 and bind and not notify and read=='OK'
                                assert 0<=seconds<=900
                                assert len(c.effects)>=1
    # Adversarial fixed probes: a provider can commit then return UNKNOWN; NEVER retry.
    c=MockConnector(target,write_outcome='COMMIT_THEN_UNKNOWN')
    s=Spec('S1',marker,target,fixed_time,exclusive_writer_proved=True)
    status=run(s,c,fixed_time)
    assert status=='UNKNOWN-EFFECT-HOLD' and c.write_attempts==1 and len(c.effects)==1
    assert audit(s,c,fixed_time,True,False)=='FRPE-UNVERIFIED'
    cases+=1; checks+=4
    # A race between two independent read-before-write workers cannot be safe
    # WITHOUT a shared serializable transaction/idempotency gateway.
    race=MockConnector(target)
    a=race.read(target);b=race.read(target)
    assert not a and not b
    race.write_once(target,marker,fixed_time,'S1')
    race.write_once(target,marker,fixed_time,'S1-reentrant')
    assert real_effect_count(race.effects,marker)==2
    assert audit(s,race,fixed_time,True,True)=='DUPLICATE-FAIL'
    cases+=1;checks+=4
    # A standalone textual mention in instructions cannot masquerade as an effect.
    c=MockConnector(target,[Effect('EXPECTED: '+marker,fixed_time,'instruction')])
    assert audit(s,c,fixed_time,True,True)=='PHYSICAL-ABSENT'
    cases+=1;checks+=1
    # A persisted first-run physical effect does not independently prove author/capability.
    c=MockConnector(target,[Effect(marker,fixed_time+timedelta(seconds=28),'worker')])
    assert audit(s,c,fixed_time+timedelta(seconds=50),True,False)=='FRPE-UNVERIFIED'
    assert audit(s,c,fixed_time+timedelta(seconds=50),True,True)=='PHYSICAL-FIRST-WINDOW-EFFECT'
    cases+=1;checks+=2
    return {'scenarios':cases,'assertions':checks,'failures':0,'model':'non-production candidate',
            'status_counts':dict(count),'critical_finding':'Read-before-write cannot guarantee single effect under concurrent writers; canonical gateway/fencing required.',
            'diagnostic_only':True}

if __name__=='__main__':
    print(json.dumps(stress(),ensure_ascii=False,indent=2))
