"""PLAN-75 R05 — non-production executable contract and fail-closed simulator.

DISCLAIMER:
  - Never talks to ChatGPT Tasks, Notion, RPG, Party, or O Primeiro.
  - Platform/provider attestation fields in synthetic fixtures are NOT proof.
  - Real production admission must use provider-verifiable metadata and a real
    external atomic claim/idempotency gateway; this module supplies neither.
  - Rules modeled: NAC-AUTO-CONT-01 v1.13, NAC-CONT-03, PLAN-75 R05 draft.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta
from typing import Optional
from collections import Counter
from zoneinfo import ZoneInfo
import re, json

TZ = ZoneInfo('America/Recife')
MASTER_LINK = 'MASTER-ONLY-CONNECTION-PLACEHOLDER'
PARTY_LINK = 'PARTY-NEVER-ACCEPT'
PROJECT = 'COMESTRE-PROJECT-PLACEHOLDER'
TARGET = 'MASTER-REFLEX-LAB-PLACEHOLDER'
LEDGER = 'MASTER-DIARY-PLACEHOLDER'
MARKER = 'SCI-P75-R05-S1-W01 | COMMENT=COMMITTED-UNVERIFIED'
NOMINAL = datetime(2026, 10, 14, 11, 0, tzinfo=TZ)
MARKER_RE = re.compile(r'^SCI-P75-R05-S[12]-W0[1-4] \| COMMENT=COMMITTED-UNVERIFIED$')

@dataclass(frozen=True)
class AttestedEnvelope:
    # Modeling only. True cannot be supplied by an LLM or prompt in real use.
    provider_readback_authenticated: bool = False
    project_id: Optional[str] = None
    mode: str = 'UNKNOWN' # VERIFIED_PROJECT / VERIFIED_HEADLESS / UNKNOWN
    origin: str = ''
    chat_destination: Optional[str] = None
    headless_no_chat: bool = False
    output_none: bool = False
    notifications_off: Optional[bool] = None
    email_off: Optional[bool] = None
    runtime_metadata_id: Optional[str] = None
    expires_at: Optional[datetime] = None

@dataclass(frozen=True)
class BoundNotion:
    # The worker must never choose credentials based on a prompt or default.
    master_link_id: Optional[str] = None
    provider_readback_authenticated: bool = False
    target_page_id: Optional[str] = None
    ledger_page_id: Optional[str] = None
    read_permission: bool = False
    write_permission: bool = False
    account_is_party: bool = True

@dataclass(frozen=True)
class Ownership:
    owner: Optional[str] = None
    closure_owner: Optional[str] = None
    recovery_owner: Optional[str] = None
    task_id: Optional[str] = None
    worker_id: Optional[str] = None
    claim_token: Optional[str] = None
    claim_expires_at: Optional[datetime] = None
    gateway_proven: bool = False
    recorded_preflight: bool = False
    run_receipts_contract_proven: bool = False
    max_firings: Optional[int] = None
    schedule_count: Optional[int] = None
    no_retry: bool = False
    max_material_writes_per_wake: int = 0

@dataclass(frozen=True)
class Plan:
    envelope: AttestedEnvelope
    notion: BoundNotion
    ownership: Ownership
    wave_id: str = 'SCI-P75-R05'
    target_page_id: str = TARGET
    ledger_page_id: str = LEDGER
    project_id: str = PROJECT
    master_link_id: str = MASTER_LINK
    nominal: datetime = NOMINAL
    deadline: datetime = NOMINAL + timedelta(minutes=15)
    marker: str = MARKER
    safety_mode: str = 'MESTRE-SIDE-TEST-ONLY'
    party_write: bool = False
    canon_write: bool = False
    stage: str = 'PREARM'

@dataclass(frozen=True)
class Gate:
    approved: bool
    reasons: tuple[str, ...]
    evidence_domain: str = 'MODEL-ONLY'

def fake_green_fixture():
    """A synthetic ideal future platform — never evidence of current availability."""
    env=AttestedEnvelope(True,PROJECT,'VERIFIED_PROJECT','PROVIDER',PROJECT,False,True,
                         True,True,'opaque-native-proof',NOMINAL+timedelta(hours=1))
    notion=BoundNotion(MASTER_LINK,True,TARGET,LEDGER,True,True,False)
    ownership=Ownership('CM-000005','CM-000005-CLOSURE','CM-000005-RECOVERY',
                        'TASK-FUTURE','S1','EXCLUSIVE-FENCE',NOMINAL+timedelta(hours=1),
                        True,True,True,4,4,True,1)
    return Plan(env,notion,ownership)

def gate(plan:Plan, at:datetime)->Gate:
    """Fail closed: absence of trusted *platform* proof cannot be overcome by text."""
    reasons=[]
    if at.tzinfo is None or plan.nominal.tzinfo is None or plan.deadline.tzinfo is None:
        reasons.append('TIMEZONE/PROVENANCE-UNKNOWN')
    if plan.stage != 'PREARM': reasons.append('NOT-PREARM')
    if plan.safety_mode!='MESTRE-SIDE-TEST-ONLY' or plan.party_write or plan.canon_write:
        reasons.append('PRIVACY-BOUNDARY')
    e=plan.envelope
    if not e.provider_readback_authenticated or e.origin!='PROVIDER' or not e.runtime_metadata_id:
        reasons.append('PLATFORM-PROOF-MISSING')
    if e.expires_at is None or at.tzinfo is None or (e.expires_at is not None and at >= e.expires_at):
        reasons.append('PROOF-STALE')
    if e.mode=='VERIFIED_PROJECT':
        if e.project_id!=plan.project_id or e.chat_destination!=plan.project_id or not e.output_none:
            reasons.append('PROJECT/DELIVERY-BIND-UNPROVEN')
    elif e.mode=='VERIFIED_HEADLESS':
        if not e.headless_no_chat or not e.output_none or e.chat_destination is not None:
            reasons.append('HEADLESS-OUTPUT-BIND-UNPROVEN')
    else: reasons.append('PROJECT-HEADLESS-UNPROVEN')
    if e.notifications_off is not True or e.email_off is not True:
        reasons.append('NOTIFICATION-GATE')
    n=plan.notion
    if not n.provider_readback_authenticated or n.master_link_id!=plan.master_link_id:
        reasons.append('NOTION-MASTER-LINK-UNPROVEN')
    if n.account_is_party: reasons.append('PARTY-ACCOUNT-DENY')
    if n.target_page_id!=plan.target_page_id or n.ledger_page_id!=plan.ledger_page_id:
        reasons.append('NOTION-TARGET-BIND-MISMATCH')
    if not n.read_permission or not n.write_permission: reasons.append('NOTION-AUTH-DENIED')
    o=plan.ownership
    if not all((o.owner,o.closure_owner,o.recovery_owner,o.task_id,o.worker_id,o.claim_token)):
        reasons.append('OWNER/RUN-ID-MISSING')
    if not o.gateway_proven: reasons.append('EXCLUSIVE-GATEWAY-UNPROVEN')
    if not o.claim_expires_at or at.tzinfo is None or (o.claim_expires_at and at >= o.claim_expires_at):
        reasons.append('CLAIM-STALE')
    if not o.recorded_preflight: reasons.append('REGISTER-BEFORE-MISSING')
    if not o.run_receipts_contract_proven: reasons.append('RUN-RECEIPTS-UNPROVEN')
    if o.max_firings is None or o.schedule_count is None or o.max_firings!=o.schedule_count or not 1<=o.max_firings<=5:
        reasons.append('FINITE-SCHEDULE-MISMATCH')
    if not o.no_retry or o.max_material_writes_per_wake!=1: reasons.append('WRITE-BUDGET-INVALID')
    if not MARKER_RE.fullmatch(plan.marker): reasons.append('BAD-MARKER')
    if plan.deadline-plan.nominal!=timedelta(minutes=15): reasons.append('WINDOW-POLICY-MISMATCH')
    if plan.nominal.tzinfo is None or plan.nominal.tzinfo!=TZ:
        reasons.append('LOCAL-TIMEZONE-MISMATCH')
    return Gate(not reasons,tuple(sorted(set(reasons))))

@dataclass(frozen=True)
class Event:
    marker: str
    method: str
    timestamp: Optional[datetime]
    target: str
    provider_operation_id: Optional[str]
    task_run_id: Optional[str]
    connector_link_id: Optional[str]
    independent_readback: bool
    first_run: Optional[bool]

@dataclass
class MockGateway:
    """External fenced writer stand-in. MUST be replaced in production."""
    committed: dict[tuple[str,str],Event]=field(default_factory=dict)
    reservations: set[tuple[str,str]]=field(default_factory=set)
    run_id_claims: set[str]=field(default_factory=set)
    write_attempts: int=0
    def claim_run_id(self, run_id:str)->bool:
        """Atomic durable run identity fence, simulated only."""
        if run_id in self.run_id_claims: return False
        self.run_id_claims.add(run_id)
        return True
    def reserve(self, target:str, marker:str)->bool:
        key=(target,marker)
        if key in self.reservations or key in self.committed: return False
        self.reservations.add(key)
        return True
    def commit(self, event:Event, write_mode:str)->str:
        self.write_attempts+=1
        key=(event.target,event.marker)
        if key not in self.reservations: return 'NO-LEASE'
        if write_mode=='DENIED': return 'DENIED'
        if write_mode not in ('ACK','COMMIT-THEN-UNKNOWN','TIMEOUT-NO-COMMIT'):
            return 'WRITE-UNKNOWN'
        if write_mode=='TIMEOUT-NO-COMMIT': return 'UNKNOWN'
        self.committed[key]=event
        self.reservations.remove(key)
        return 'UNKNOWN' if write_mode=='COMMIT-THEN-UNKNOWN' else 'COMMITTED-UNVERIFIED'

@dataclass(frozen=True)
class RunResult:
    status:str
    effect_attempts:int
    receipts:tuple[str,...]=()
    model_only:bool=True

def execute_model(plan:Plan, at:datetime, gateway:MockGateway,
                  write_mode:str='ACK', checkin_ok:bool=True,
                  effect_before:Optional[list[Event]]=None)->RunResult:
    """Single-wake emulator with no retry and explicit receipt failures."""
    before=gateway.write_attempts
    def finish(state,*receipts):
        return RunResult(state,gateway.write_attempts-before,tuple(receipts))
    if not gate(plan,at).approved: return finish('ADMISSION-DENY')
    if at < plan.nominal: return finish('EARLY-NO-WRITE')
    if at > plan.deadline: return finish('LATE-NO-WRITE')
    if not checkin_ok: return finish('RUN-CHECKIN-FAIL-CLOSED')
    effects=effect_before if effect_before is not None else list(gateway.committed.values())
    hits=[e for e in effects if e.target==plan.target_page_id and e.marker==plan.marker]
    if len(hits)>1: return finish('DUPLICATE-HOLD','CHECKIN-RECORDED')
    if len(hits)==1: return finish('NOOP-EXISTS','CHECKIN-RECORDED')
    if not gateway.reserve(plan.target_page_id,plan.marker):
        return finish('FENCING-DENY','CHECKIN-RECORDED')
    event=Event(plan.marker,'COMMENT',at,plan.target_page_id,
                'SYNTHETIC-OP','SYNTHETIC-RUN',plan.master_link_id,False,True)
    state=gateway.commit(event,write_mode)
    if state=='DENIED': return finish('CONNECTOR-DENIED','CHECKIN-RECORDED')
    if state in ('UNKNOWN','WRITE-UNKNOWN'): return finish('UNKNOWN-EFFECT-HOLD','CHECKIN-RECORDED')
    return finish(state,'CHECKIN-RECORDED','REPORT-PENDING-READBACK')


def audit_model(plan:Plan, events:list[Event], now:datetime, readback_ok:bool=True)->str:
    """No self-PASS. Requires independent native event + run/operation causality."""
    if not readback_ok: return 'AUDIT-UNAVAILABLE'
    hits=[e for e in events if e.target==plan.target_page_id and e.marker==plan.marker]
    if len(hits)>1: return 'DUPLICATE-FAIL'
    if len(hits)==0: return 'ABSENT'
    e=hits[0]
    if e.timestamp is None: return 'TIMING-UNKNOWN'
    if e.timestamp<plan.nominal: return 'EARLY-EVENT-NO-FRPE'
    if e.timestamp>plan.deadline: return 'LATE-EVENT-NO-FRPE'
    if now.tzinfo is None or now<e.timestamp: return 'CLOCK/OBSERVATION-UNKNOWN'
    if not e.independent_readback: return 'UNVERIFIED-INDEPENDENCE'
    if e.task_run_id is None or e.provider_operation_id is None:
        return 'RUN-OPERATION-PROVENANCE-MISSING'
    if e.connector_link_id!=plan.master_link_id: return 'WRONG-CONNECTOR-FAIL'
    if e.first_run is not True: return 'FIRST-RUN-PROVENANCE-MISSING'
    return 'PHYSICAL-FIRST-RUN-CANDIDATE-NOT-NAC-PASS'


def real_platform_now_gate()->Gate:
    """Represents the actual known R07 capability observation in this turn.
    Actual tasks cannot be armed; fixture defaults are intentionally RED.
    """
    real=Plan(AttestedEnvelope(),BoundNotion(),Ownership())
    return gate(real,datetime(2026,10,13,13,26,tzinfo=TZ))

if __name__=='__main__':
    print(json.dumps({'observed_R07_platform_gate':real_platform_now_gate().__dict__,
                      'example_synthetic_success':gate(fake_green_fixture(),NOMINAL).__dict__},indent=2))
