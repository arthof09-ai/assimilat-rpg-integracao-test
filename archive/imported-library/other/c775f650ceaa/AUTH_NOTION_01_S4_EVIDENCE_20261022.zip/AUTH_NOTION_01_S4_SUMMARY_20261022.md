# AUTH-NOTION-01 — laboratório sintético isolado

- **protocol:** AUTH-NOTION-01
- **normative_status:** S4 PROPOSTA — NAC-PASS GLOBAL HOLD
- **kind:** SYNTHETIC MOCK STATE MACHINE - no Notion, OAuth, revocation, or live writes
- **cases:** 192
- **passed:** 192
- **categories:** {'N01_TWO_ACCOUNTS': 8, 'N02_LINK_OMITTED': 8, 'N03_LINK_WRONG': 8, 'N04_AUTH_OK': 8, 'N05_AUTHED_PAGE_MISSING': 8, 'N06_MASTER_ACCOUNT_TO_PARTY': 8, 'N07_PARTY_ACCOUNT_TO_MASTER': 8, 'N08_TOOL_DOWN': 8, 'N09_REVOKED': 8, 'N10_WRITER_TOOL_NOT_AUTHORITY': 8, 'N11_WRITE_TIMEOUT': 8, 'N12_ACCOUNT_CHANGED': 8, 'N13_NEW_SUCCESSOR': 8, 'N14_TEST_CAN_CONTINUE': 8, 'N15_UNAUTHORIZED_PARTY_EXPOSURE': 8, 'N16_RETRY_IDENTICAL': 8, 'N17_WRITE_UNCONFIRMED': 8, 'N18_WRITE_VERIFIED': 8, 'N19_DENIED_PERMISSIONS': 8, 'N20_WRITER_SENT_REJECTED': 8, 'N21_PERMISSION_UNKNOWN': 8, 'N22_FRESH_CLEAN_WRITE': 8, 'N23_TRANSIENT': 8, 'N24_ACCOUNT_AUTH_FAILED': 8}
- **mutation_cases:** 12
- **mutations_detected:** 12
- **canary_cases:** 12
- **canaries_local_pass:** 12
- **live_not_proven:** ['Account revocation', 'Post-write timeout', 'Concurrent writer conflict', 'Mid-session external link reassignment', 'Real blind reviewer', 'Direct NAC-CONT-03 mother TEE']

**Limite:** este teste é simulado e NÃO autoriza reivindicar NAC-STRESS-01 S4 integral, TEE, GNN, GP-NAC nem NAC-PASS.
