# AUTH-NOTION-01 — BRIDGE PROPOSTA PARA A MÃE NAC-CONT-03 v2

**Estado:** PROPOSTA DE PATCH, NÃO APLICADA. **Alvo:** seção `NAC-CONT-03 v2.0` dentro da [página canônica Comestre](https://app.notion.com/p/3ecc2b324ede8197911cdd9fe0a4998c). **Objetivo:** TEE direto; não criar norma independente. **Proibido aplicar sem o gate de writer/lease/epoch/fencing e sem a reconciliação NAC-NORM.**

## Local e texto candidato de integração

**E0 / entrar:**
> Se a operação exigir Notion, ao primeiro uso ou após mudança material de conta/conexão chamar o protocolo candidato `AUTH-NOTION-01`, quando ele estiver aprovado/vigente: N0 descoberta de contas e N1 seleção explícita do `link_id` elegível na sessão, N2 identificação autenticada. Enquanto candidato não promovido, esses passos são boa prática de leitura e devem ser tratados como consultivos, sem alegar nova obrigação normativa S4. Não reutilizar IDs de outro chat.

**E1 / estabelecer verdade:**
> Antes de declarar erro do Notion, aplicar N3 capacidades/autorização e N4 leitura do alvo pela conta competente. `NOT_FOUND` do recurso não prova desconexão. Classificar separadamente ferramenta, vínculo, autenticação, autorização e recurso. Não trocar Mestre por Party para ultrapassar fronteiras.

**E3 / validar autoridade antes de escrever:**
> Em escrita Notion, identificação correta e `notion_get_tool_access` demonstram apenas conexão/capacidade técnica; exigir objeto-alvo, escopo Mestre, escritor competente, epoch/lease/fencing, collision domain e leitura de guarda. Não testar autenticação por escrita em páginas oficiais. Sem writer, READ-ONLY/HOLD.

**E5 / verificar:**
> Após qualquer escrita Notion, reabrir o destino sob o vínculo correto e comprovar estado persistido, content/parent, duplicatas e efeitos colaterais. `success` de ferramenta isolado não encerra verificação.

**E6 / tratar falha e retry:**
> Em `link_id must identify an eligible linked account`, primeiro conferir parâmetro omitido e vínculo elegível da sessão, corrigir e repetir uma leitura. Uma segunda tentativa só com hipótese técnica diferente. Timeout/incerteza após escrita exige readback antes de retry; preservar idempotência. Não pedir reconexão por reflexo.

**E9 / qualidade e continuidade:**
> Incidentes recorrentes de confusão de vínculo devem ser convertidos em regressão e ponte de bootstrap; falhas de Notion não bloqueiam trabalhos TEST independentes. Propor sucessão por acesso somente após S1–S5 da frente de recuperação, salvo decisão expressa do Mestre ou causa distinta.

**E11 / PASS e comunicação:**
> O NAC-PASS-02 deve vedar afirmações de desconexão, escrita verificada, ACK, conta selecionada ou promoção normativa se não existirem provas proporcionais. Estado de candidata permanece claro até GNN/GP-NAC e aceite competente; não transmitir dados Mestre-only à Party.

## Estratégia transacional de alteração quando autorizada

1. Reabrir a seção NAC-CONT-03 v2 e confirmar hash/versão e ausência de bridge atual, idempotência.
2. Classificar a escrita como MESTRE-SIDE/registro normativo e demonstrar competência do escritor e colisões.
3. Inserir patch mínimo por `update_content` em trechos exatos, nunca substituir os 950 mil caracteres da página inteira.
4. Reabrir e confirmar os sete pontos, sem duplicatas; validar históricos v1 e outras normas não afetados.
5. Executar regressão real de entrypoint e teste de sucessor; registrar MIE/TEE no Diário e Central.
6. Promover **somente após** NAC-STRESS S4, GNN/GP-NAC e NAC-PASS. Se falhar, deixar bridge candidata inativa/registrada com estado HOLD, não alegar vigência.
